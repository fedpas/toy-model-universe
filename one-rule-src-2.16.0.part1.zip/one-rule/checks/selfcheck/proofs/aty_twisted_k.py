#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""aty_twisted_k.py: Atiyah and Segal, "Twisted K-theory and cohomology", read with the labels: the K-theory of a point from the
graded Clifford modules of the bit rule (the coefficients of the Atiyah-Hirzebruch spectral sequence), and the twisted de Rham
complex D = d - H on forms, which are the bit rule with null generators.      python3 aty_twisted_k.py [--fault NAME]

A. Clifford modules and the clock (aty.A1 .. A6).
   A graded Cl(p,q)-module is a Cl(p,q)-module with an involution that anticommutes with every generator: one more label of square
   +1, so the graded modules of Cl(p,q) are the ungraded modules of Cl(p+1,q).  The group of the pair "Cl(p,q) inside Cl(p,q+1)" is
   the cokernel of the restriction N(Cl(p+1,q+1)) -> N(Cl(p+1,q)) (N: the free group on the irreducible modules), and of the pair
   "Cl(p,q) inside Cl(p+1,q)" the cokernel of N(Cl(p+2,q)) -> N(Cl(p+1,q)).  For every cell with p + q <= 7 (72 cokernels) the first
   is the entry KO^(p-q)(point) and the second KO^(q-p)(point) of the recalled table Z, Z2, Z2, 0, Z, 0, 0, 0 (Atiyah-Bott-Shapiro):
   the clock c = p - q alone decides.  Along Cl(0,n), n = 0..9: Z, Z2, Z2, 0, Z, 0, 0, 0, Z, Z2.  Without the grading label the list
   moves by one (Z2, Z2, 0, Z, 0, 0, 0, Z, Z2 for n = 0..8); the ungraded lists of Cl(n,0) and Cl(0,n) differ by a shift of two.
   Over C (complex modules, the centre counts the simple summands) the graded groups are Z for p + q even and 0 for p + q odd, so
   in the complex spectral sequence every even differential vanishes.  Products by concatenation of labels (the graded tensor
   product with the Koszul sign): eta^2 is not 0 in the Z2 of n = 2, alpha^2 = 4 beta in the Z of n = 8 (alpha and beta the
   irreducibles of Cl(1,4) and Cl(1,8) on which the volume element is +1), eta.beta is not 0 in the Z2 of n = 9.
   [bit]  minimal left ideals of the bit rule (steps15_17/bitcliff.py), f = prod (1 + e_a)/2 over commuting labels of square +1,
          signed permutation matrices, irreducibility from the exact commutant (solid_cube.py's commutant_basis and classify), the
          two irreducibles of a two-summand cell told apart by the central volume element, multiplicities from exact ranks of its
          eigenspaces, integer Smith normal form.
   [std]  numpy: real (and complex) Kronecker words of 2 x 2 matrices as gamma matrices, never a label; irreducible modules as the
          eigenspaces of a random symmetric element of the commutant (the group average), multiplicities as intertwiner dimensions
          by SVD, cokernels from determinantal divisors (gcd of minors); cells with p + q <= 7, so pairs with p + q <= 5.
   [ctl]  UNGRADED (the grading label dropped: Z2 at n = 0), SIGN (the added generator of the other sign), NOSWAP (the two
          irreducibles of the smaller cell assumed kept, not swapped, by the dropped generator), CPLX (the real summand count in
          place of the complex one).
B. The twisted de Rham complex (aty.B1 .. B5).
   On polynomial forms on R^5 (null labels, coefficients of degree <= 2, seeded integers): (d - H)^2 = -(dH) for every odd form H,
   so D^2 = 0 exactly for a closed odd H (degrees 1, 3, 5), and not for a 3-form with dH != 0 or for an even closed 2-form;
   D_(H+dz) e^z = e^z D_H for a 2-form z (e^z a finite sum), (da) b = D(a b) when D b = 0.  On invariant-form models (the
   exterior algebra of the dual of a nilpotent or compact Lie algebra, Chevalley-Eilenberg d, times H*(CP^m) = R[t]/t^(m+1)):
   twisted cohomology (even, odd) = (3,3) on T^3, (6,6) on T^4 with H = e123, (0,0) on SU(2), (2,2) on the Heisenberg nilmanifold Y
   with H = xyz; on M = Y x CP^2 with H = xt (the Appendix example): the pages of the degree filtration have dimensions E2 = 18,
   E4 = 10, E6 = E_infinity = 8 (the d3-cycles: 14), twisted cohomology (4,4), d5(y) = -{xt, xt, y} = -x z t^2 != 0; on
   Y3 x CP^3 (the next manifold of the tower, du = x z) E2 = 32, E4 = E6 = 20, E8 = E_infinity = 16, d7(y) = -x u t^3 != 0;
   every even page differential is zero.  The pages printed in
   the Appendix (18, 14, 10) are not those of the model: 14 is the dimension of the d3-cycles and 10 that of E4.
   [bit]  the labels with null squares (bitcliff Alg(sig(0,0,r))), polynomial coefficients, exact Fractions and integer ranks.
   [std]  forms on index tuples with the sign of the sorting permutation (no label), the component formula for d, numpy ranks and
          scipy null spaces for the twisted cohomology and the pages.
   [ctl]  EVENTWIST (a closed 2-form as the twist), OPENH (a 3-form with dH != 0), GAUGE (e^-z in place of e^z), FORMAL (E4 =
          E_infinity, true for formal spaces, asserted on M), PRINTED (the Appendix ranks 14 and 10 asserted).
Scope: the cells p + q <= 9 and Cl(1,9), Cl(1,10) (A, bit); the cells p + q <= 7, so the pairs p + q <= 5 (A, std); five random
forms per identity on R^5 (B1, B2); the six models (B3 .. B5).  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen; the
controls are the faults above.  Options: --fault NAME (one of the nine above) must exit with code 1.
Command: python3 aty_twisted_k.py   (from this folder, or python3 selfcheck/proofs/aty_twisted_k.py from the root of the checks;
standard library, numpy and scipy)."""
import os, sys, io, random, itertools, contextlib, time
from fractions import Fraction as Fr
from math import gcd
import numpy as np
import scipy.linalg

_here = os.path.dirname(os.path.abspath(__file__))                         # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                         # selfcheck/
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p); sys.path.insert(0, _here)
from bitcliff import Alg, sig
_argv = sys.argv; sys.argv = [_argv[0]]
try:
    with contextlib.redirect_stdout(io.StringIO()):
        from solid_cube import commutant_basis, classify               # exact commutant of a signed-permutation module, its type
finally:
    sys.argv = _argv

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('UNGRADED', 'SIGN', 'NOSWAP', 'CPLX', 'EVENTWIST', 'OPENH', 'GAUGE', 'FORMAL', 'PRINTED')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
KOM = ['Z', 'Z2', 'Z2', '0', 'Z', '0', '0', '0']        # KO^(-j)(point), j mod 8: the recalled table, used only to compare
T0 = time.time()

# ------------------------------------------------------------------------------------------------ exact integer linear algebra
def _norm(r):
    g = 0
    for x in r: g = gcd(g, x)
    return [x // g for x in r] if g > 1 else r
def echelon(rows):
    """incremental row echelon form over Q with integer rows; returns the list of (pivot column, row)"""
    piv = []
    for r in rows:
        r = [int(x) for x in r]
        for c, pr in piv:
            if r[c]:
                a, b = pr[c], r[c]; r = _norm([a * x - b * y for x, y in zip(r, pr)])
        nz = next((i for i, x in enumerate(r) if x), None)
        if nz is not None: piv.append((nz, r))
    return piv
def rank_int(rows): return len(echelon(rows)) if rows else 0
def nullspace_int(rows, ncols):
    """integer basis of {x : A x = 0} for the integer matrix A given by its rows"""
    piv = echelon(rows)
    piv.sort()
    red = []                                                               # full reduction: each pivot column zero in the other rows
    for c, r in piv:
        for k in range(len(red)):
            c2, r2 = red[k]
            if r2[c]:
                a, b = r[c], r2[c]; red[k] = (c2, _norm([a * x - b * y for x, y in zip(r2, r)]))
        red.append((c, r))
    pc_ = {c for c, _ in red}; basis = []
    for f in range(ncols):
        if f in pc_: continue
        v = [Fr(0)] * ncols; v[f] = Fr(1)
        for c, r in red: v[c] = Fr(-r[f], r[c])
        L = 1
        for x in v: L = L * x.denominator // gcd(L, x.denominator)
        basis.append([int(x * L) for x in v])
    return basis
def matvec(D, v): return [sum(a * b for a, b in zip(row, v)) for row in D]

def smith(A):
    """integer Smith normal form: returns (invariant factors, U) with U A V diagonal; A given by its rows"""
    A = [[int(x) for x in r] for r in A]; r = len(A); c = len(A[0]) if r else 0
    U = [[int(i == j) for j in range(r)] for i in range(r)]
    diag = []; t = 0
    def swap_rows(i, j): A[i], A[j] = A[j], A[i]; U[i], U[j] = U[j], U[i]
    def swap_cols(i, j):
        for row in A: row[i], row[j] = row[j], row[i]
    while t < min(r, c):
        nz = [(abs(A[i][j]), i, j) for i in range(t, r) for j in range(t, c) if A[i][j]]
        if not nz: break
        _, i, j = min(nz); swap_rows(t, i); swap_cols(t, j)
        while True:
            changed = False
            for i in range(t + 1, r):
                if A[i][t]:
                    qq = A[i][t] // A[t][t]
                    A[i] = [a - qq * b for a, b in zip(A[i], A[t])]; U[i] = [a - qq * b for a, b in zip(U[i], U[t])]
                    if A[i][t]: swap_rows(t, i); changed = True
            for j in range(t + 1, c):
                if A[t][j]:
                    qq = A[t][j] // A[t][t]
                    for row in A: row[j] -= qq * row[t]
                    if A[t][j]: swap_cols(t, j); changed = True
            if changed: continue
            bad = [(i, j) for i in range(t + 1, r) for j in range(t + 1, c) if A[i][j] % A[t][t]]
            if not bad: break
            i = bad[0][0]; A[t] = [a + b for a, b in zip(A[t], A[i])]; U[t] = [a + b for a, b in zip(U[t], U[i])]
        if A[t][t] < 0: A[t] = [-a for a in A[t]]; U[t] = [-a for a in U[t]]
        diag.append(A[t][t]); t += 1
    return diag, U
def group_name(free, tors):
    parts = ['Z'] * free + ['Z%d' % d for d in tors]
    return '+'.join(parts) if parts else '0'
def coker(M):
    """cokernel of the integer matrix M (rows: the target irreducibles) as a name, with the data to read a class"""
    diag, U = smith(M)
    free = len(M) - len(diag)
    return group_name(free, [d for d in diag if d > 1]), (diag, U)
def coker_class(cdata, v):
    diag, U = cdata; w = [sum(a * b for a, b in zip(row, v)) for row in U]
    return tuple([w[i] % diag[i] for i in range(len(diag)) if diag[i] > 1] + w[len(diag):])

# ================================================================================================ A. the bit-rule modules
def comm_set(alg, norders):
    """a maximal set of commuting labels of square +1 whose F2-span squares to +1 (best of 2 + norders orders)"""
    best = []; rg = random.Random(7 + 31 * alg.n + sum(1 for e in alg.eps if e > 0))
    orders = [list(range(1, alg.N)), list(range(alg.N - 1, 0, -1))]
    for _ in range(norders):
        o = list(range(1, alg.N)); rg.shuffle(o); orders.append(o)
    for order in orders:
        gens = []; span = {0}
        for a in order:
            if a in span or alg.sq(a) != 1: continue
            if all(alg.comm_sign(a, g) == 1 for g in gens):
                new = {s ^ a for s in span}
                if all(alg.sq(x) == 1 for x in new): gens.append(a); span |= new
        if len(gens) > len(best): best = gens
    return best

def mprod(mats, m):
    out = np.eye(m, dtype=np.int64)
    for R in mats: out = out @ R
    return out

def build_cell(p, q):
    """the minimal module(s) of Cl(p,q) from the bit rule"""
    alg = Alg(sig(p, q)); n = alg.n; N = alg.N
    if n == 0:
        rho, m = [], 1
    else:
        gens = comm_set(alg, 24 if n <= 9 else 6)
        k = len(gens); span = {0}
        for a in gens: span |= {s ^ a for s in span}
        tau = {}
        for J in range(1 << k):
            prod = {0: 1}
            for j in range(k):
                if J >> j & 1: prod = alg.mul(prod, {gens[j]: 1})
            (mm, cf), = prod.items(); tau[mm] = cf                                     # e_mm f = cf f
        coset = {}; reps = []
        for a in range(N):
            if a not in coset:
                reps.append(a)
                for mm in span: coset[a ^ mm] = (a, mm)
        m = len(reps); idx = {r: i for i, r in enumerate(reps)}
        rho = []
        for i in range(n):
            R = np.zeros((m, m), dtype=np.int64)
            for r in reps:
                s, c = alg.blade_mul(1 << i, r); r2, mm = coset[c]; s2, _ = alg.blade_mul(r2, mm)
                R[idx[r2], idx[r]] = s * s2 * tau[mm]
            rho.append(R)
    I = np.eye(m, dtype=np.int64)
    ok_rel = all(np.array_equal(rho[i] @ rho[j] + rho[j] @ rho[i], (2 * alg.eps[i] if i == j else 0) * I) for i in range(n) for j in range(n))
    basis = commutant_basis(rho, m) if n else [I]
    typ, _ = classify(basis, m)
    d = len(basis); summ = Fr(N * d, m * m)
    om = mprod(rho, m)
    irreps = [rho]
    if summ == 2:
        s = 1 if np.array_equal(om, I) else (-1 if np.array_equal(om, -I) else 0)
        neg = [-R for R in rho]
        irreps = [rho, neg] if s == 1 else [neg, rho]
    else:
        s = None
    ncent = len(alg.center_blades())
    return {'p': p, 'q': q, 'n': n, 'eps': alg.eps, 'alg': alg, 'm': m, 'irreps': irreps, 'type': typ, 'd': d, 'summ': summ,
            'ok_rel': ok_rel, 'om_sign': s, 'ncent': ncent}

def restrict(big, drop, small, noswap=False):
    """integer matrix: rows the irreducibles of `small`, columns those of `big`, restricted by dropping generator `drop`"""
    assert tuple(e for i, e in enumerate(big['eps']) if i != drop) == small['eps']
    mT, mS = big['m'], small['m']; cols = []; swap_ok = True
    for T in big['irreps']:
        R = [T[i] for i in range(len(T)) if i != drop]
        if len(small['irreps']) == 1:
            assert mT % mS == 0; cols.append([mT // mS])
        else:
            W = mprod(R, mT); I = np.eye(mT, dtype=np.int64)
            assert np.array_equal(W @ W, I)
            swap_ok = swap_ok and np.array_equal(T[drop] @ W, -(W @ T[drop]))
            dp = mT - rank_int((W - I).tolist()); dm = mT - rank_int((W + I).tolist())
            assert dp % mS == 0 and dm % mS == 0
            cols.append([mT // mS, 0] if noswap else [dp // mS, dm // mS])
    M = [[cols[j][i] for j in range(len(cols))] for i in range(len(small['irreps']))]
    return M, swap_ok

def ccounts(cell, cplx_fault=False):
    """complex data from the labels: number of simple summands of C (x) Cl(p,q) (= the centre), complex dimension"""
    nC = int(cell['summ']) if cplx_fault else cell['ncent']
    mC = cell['m'] // (1 if cell['type'] == 'R' else 2)
    return nC, mC
def crestrict(big, drop, small, cplx_fault=False):
    nB, mB = ccounts(big, cplx_fault); nS, mS = ccounts(small, cplx_fault)
    if nS == 2:
        vol = (1 << big['n']) - 1 - (1 << drop)
        swap = big['alg'].comm_sign(1 << drop, vol) == -1
        col = [mB // (2 * mS)] * 2
    else:
        swap = True; col = [mB // mS]
    return [[col[i]] * nB for i in range(nS)], swap

CELL = {}
for nn in range(0, 10):
    for pp in range(0, nn + 1): CELL[(pp, nn - pp)] = build_cell(pp, nn - pp)
for key in ((1, 9), (1, 10)): CELL[key] = build_cell(*key)
TA = time.time() - T0

def graded_pair(p, q, sign, noswap=False):
    """cokernel of the pair Cl(p,q) inside Cl(p,q+1) (sign -1) or Cl(p+1,q) (sign +1), graded modules as Cl(p+1,q)-modules"""
    small = CELL[(p + 1, q)]
    if sign < 0: big, drop = CELL[(p + 1, q + 1)], p + 1 + q
    else: big, drop = CELL[(p + 2, q)], p + 1
    M, sw = restrict(big, drop, small, noswap)
    return coker(M), M, sw
def ungraded_pair(p, q, sign, noswap=False):
    small = CELL[(p, q)]
    if sign < 0: big, drop = CELL[(p, q + 1)], p + q
    else: big, drop = CELL[(p + 1, q)], p
    M, sw = restrict(big, drop, small, noswap)
    return coker(M), M, sw

# ------------------------------------------------------------------------------------------------ A, the standard route (numpy, no label)
_X = np.array([[0., 1.], [1., 0.]]); _Z = np.diag([1., -1.]); _E = np.array([[0., 1.], [-1., 0.]]); _I = np.eye(2)
def kron_gammas(eps, cplx=False):
    G = []
    for k in range(len(eps)):
        A = _X if eps[k] > 0 else (1j * _X if cplx else _E)
        M = np.array([[1.]], dtype=complex if cplx else float)
        for B in [_Z] * k + [A] + [_I] * (len(eps) - k - 1): M = np.kron(M, B)
        G.append(M)
    return G
def hom_dim(S, T):
    """dim of {X : X S_i = T_i X} (S, T lists of matrices for the same generators)"""
    mS = S[0].shape[0] if S else 1; mT = T[0].shape[0] if T else 1
    if not S: return mS * mT
    cplx = np.iscomplexobj(S[0]) or np.iscomplexobj(T[0])
    rows = [np.kron(Si.T, np.eye(mT)) - np.kron(np.eye(mS), Ti) for Si, Ti in zip(S, T)]
    A = np.vstack(rows)
    return mS * mT - np.linalg.matrix_rank(A, tol=1e-8 * max(1.0, np.abs(A).max()))
def std_cell(p, q, cplx=False, seed=0):
    eps = [1] * p + [-1] * q; n = p + q; dim = 2 ** n
    G = kron_gammas(eps, cplx)
    prods = [np.eye(dim, dtype=complex if cplx else float)]
    for a in range(1, dim):
        i = (a & -a).bit_length() - 1; prods.append(G[i] @ prods[a ^ (1 << i)])
    rng = np.random.default_rng(1000 + 37 * p + 101 * q + seed)
    X = rng.standard_normal((dim, dim))
    if cplx: X = X + 1j * rng.standard_normal((dim, dim))
    X = X + X.conj().T
    Y = sum(P @ X @ P.conj().T for P in prods) / dim
    w, V = np.linalg.eigh(Y)
    groups = []; start = 0; scale = max(1.0, np.abs(w).max())
    for i in range(1, dim + 1):
        if i == dim or w[i] - w[i - 1] > 1e-7 * scale: groups.append(V[:, start:i]); start = i
    sizes = sorted(set(g.shape[1] for g in groups))
    om = prods[-1]
    two = n % 2 == 1 and all(np.allclose(om @ g, g @ om) for g in G)
    if two and not cplx: two = np.allclose(om @ om, np.eye(dim))
    if cplx and two and np.allclose(om @ om, -np.eye(dim)): om = 1j * om
    irreps = []
    if two:
        for sgn in (1, -1):
            Q = next(g for g in groups if (np.trace(g.conj().T @ om @ g).real) * sgn > 0.5)
            irreps.append([Q.conj().T @ Gk @ Q for Gk in G])
    else:
        Q = groups[0]; irreps.append([Q.conj().T @ Gk @ Q for Gk in G])
    m = groups[0].shape[1]
    d = hom_dim(irreps[0], irreps[0])
    return {'p': p, 'q': q, 'n': n, 'm': m, 'sizes': sizes, 'irreps': irreps, 'd': d, 'two': two}
def std_restrict(big, drop, small):
    M = [[0] * len(big['irreps']) for _ in small['irreps']]
    for j, T in enumerate(big['irreps']):
        R = [T[i] for i in range(len(T)) if i != drop]
        for i, S in enumerate(small['irreps']):
            M[i][j] = int(round(hom_dim(S, R) / hom_dim(S, S)))
    return M
def _det(M):
    M = [[Fr(x) for x in r] for r in M]; n = len(M); det = Fr(1)
    for c in range(n):
        piv = next((i for i in range(c, n) if M[i][c] != 0), None)
        if piv is None: return 0
        if piv != c: M[c], M[piv] = M[piv], M[c]; det = -det
        det *= M[c][c]
        for i in range(c + 1, n):
            f = M[i][c] / M[c][c]; M[i] = [a - f * b for a, b in zip(M[i], M[c])]
    return int(det)
def coker_divisors(M):
    """cokernel from determinantal divisors d_k = gcd of the k x k minors (no elimination of the integer matrix itself)"""
    r = len(M); c = len(M[0]) if r else 0; ds = [1]
    for k in range(1, min(r, c) + 1):
        g = 0
        for rows in itertools.combinations(range(r), k):
            for cols in itertools.combinations(range(c), k):
                g = gcd(g, abs(_det([[M[i][j] for j in cols] for i in rows])))
        if g == 0: break
        ds.append(g)
    inv = [ds[k] // ds[k - 1] for k in range(1, len(ds))]
    return group_name(r - len(inv), [e for e in inv if e > 1])

# ------------------------------------------------------------------------------------------------ A, items
head('A1. the minimal modules of the bit rule (cells p + q <= 9, and Cl(1,9), Cl(1,10))')
TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']                     # T4 at c = 0..7, used only to compare
okrel = all(c['ok_rel'] for c in CELL.values())
okdiv = all(c['type'] in ('R', 'C', 'H') and c['d'] in (1, 2, 4) for c in CELL.values())
okclock = all((c['type'] + ('2' if c['summ'] == 2 else '')) == TYPES[(c['p'] - c['q']) % 8] for c in CELL.values())
okdim = all(c['summ'] * c['m'] * c['m'] == (1 << c['n']) * c['d'] for c in CELL.values())
okom = all(c['om_sign'] in (1, -1) for c in CELL.values() if c['summ'] == 2)
chk('bit', okrel and okdiv, 'aty.A1: %d cells: the ideal matrices obey the Clifford relations and the exact commutant is R, C or H (the ideal is irreducible)' % len(CELL))
chk('bit', okclock and okdim and okom, 'aty.A1: the commutant type and the number of simple summands follow the clock p - q mod 8 at every cell; on the two-summand cells the volume element is +1 or -1 on the ideal')
dims_g = [CELL[(1, n)]['m'] for n in range(0, 11)]
nirr_g = [len(CELL[(1, n)]['irreps']) for n in range(0, 11)]
chk('bit', dims_g == [1, 2, 4, 8, 8, 16, 16, 16, 16, 32, 64] and nirr_g == [2, 1, 1, 1, 2, 1, 1, 1, 2, 1, 1],
    'aty.A1: irreducible graded Cl(0,n)-modules (ungraded Cl(1,n)), n = 0..10: dimensions %s, number %s' % (dims_g, nirr_g))

head('A2. the graded groups along Cl(0,n) and the shift without the grading')
gl = []; swaps = True
for n in range(0, 10):
    if FAULT == 'UNGRADED':
        if n > 8: break
        (nm, _), M, sw = ungraded_pair(0, n, -1)
    elif FAULT == 'SIGN':
        if n > 7: break
        (nm, _), M, sw = graded_pair(0, n, +1)
    else: (nm, _), M, sw = graded_pair(0, n, -1, noswap=(FAULT == 'NOSWAP'))
    gl.append(nm); swaps = swaps and sw
want_g = [KOM[n % 8] for n in range(10)]
chk('bit', gl == want_g, 'aty.A2: graded, Cl(0,n) inside Cl(0,n+1), n = 0..9: %s; the recalled KO^(-n)(point): %s' % (' '.join(gl), ' '.join(want_g)))
chk('bit', swaps, 'aty.A2: where the smaller cell has two irreducibles, the dropped generator anticommutes with its volume element (exact): the two appear equally')
ul = [ungraded_pair(0, n, -1)[0][0] for n in range(0, 9)]
want_u = [KOM[(n + 1) % 8] for n in range(9)]
chk('bit', ul == want_u, 'aty.A2: ungraded, Cl(0,n) inside Cl(0,n+1), n = 0..8: %s = KO^(-(n+1))(point), the list of str_clock.py bd.str.2 with k = n + 1' % ' '.join(ul))
ulp = [ungraded_pair(n, 0, +1)[0][0] for n in range(0, 9)]
chk('bit', ulp == [KOM[(n - 1) % 8] for n in range(9)], 'aty.A2: ungraded, Cl(n,0) inside Cl(n+1,0), n = 0..8: %s = KO^(-(n-1))(point): the two ungraded lists differ by a shift of two (Cl(n+2,0) = Cl(0,n) x M2(R))' % ' '.join(ulp))
chk('ctl', ul != want_g and ul[0] == 'Z2', 'aty.A2: without the grading label the list is not KO^(-n)(point): Z2 at n = 0 where the graded list has Z (UNGRADED)')
sl = [graded_pair(0, n, +1)[0][0] for n in range(0, 8)]
chk('ctl', sl != want_g[:8], 'aty.A2: Cl(0,n) extended by a generator of square +1 gives %s, not the KO^(-n) list (SIGN)' % ' '.join(sl))
nl = [graded_pair(0, n, -1, noswap=True)[0][0] for n in range(0, 9)]
chk('ctl', nl != want_g[:9], 'aty.A2: with the two irreducibles kept, not swapped, the list reads %s (NOSWAP)' % ' '.join(nl))

head('A3. the clock alone decides: 72 graded cokernels, p + q <= 7')
bad = []; byclock = {}
for n in range(0, 8):
    for p in range(0, n + 1):
        q = n - p; c = (p - q) % 8
        for sg in (-1, 1):
            nm = graded_pair(p, q, sg, noswap=(FAULT == 'NOSWAP'))[0][0]
            want = KOM[(q - p) % 8] if sg < 0 else KOM[(p - q) % 8]
            if nm != want: bad.append((p, q, sg, nm))
            byclock.setdefault((c, sg), set()).add(nm)
chk('bit', not bad and all(len(v) == 1 for v in byclock.values()),
    'aty.A3: for all 36 cells, adding a generator of square -1 gives KO^(p-q)(point) and of square +1 gives KO^(q-p)(point); %d cokernels, mismatches %s' % (72, bad[:4]))
chk('bit', [next(iter(byclock[(c, -1)])) for c in range(8)] == [KOM[(-c) % 8] for c in range(8)],
    'aty.A3: by the clock c = 0..7 (square -1 added): %s' % ' '.join(next(iter(byclock[(c, -1)])) for c in range(8)))
gp = [graded_pair(n, 0, +1)[0][0] for n in range(0, 8)]
chk('bit', gp == want_g[:8], 'aty.A3: graded, Cl(n,0) inside Cl(n+1,0), n = 0..7: %s, the same list as Cl(0,n): the even parts of Cl(V,Q) and Cl(V,-Q) agree' % ' '.join(gp))

head('A4. the standard route (numpy Kronecker words, intertwiners, determinantal divisors), cells p + q <= 7')
STD = {}
for n in range(0, 8):
    for p in range(0, n + 1): STD[(p, n - p)] = std_cell(p, n - p)
okm = all(len(s['sizes']) == 1 and s['m'] == CELL[k]['m'] and s['d'] == CELL[k]['d'] and len(s['irreps']) == len(CELL[k]['irreps']) for k, s in STD.items())
chk('std', all(len(s['sizes']) == 1 for s in STD.values()), 'aty.A4: 36 cells: the eigenspaces of a random symmetric commutant element all have one dimension (the irreducible)')
chk('bit==std', okm, 'aty.A4: dimension, commutant dimension and number of irreducibles agree with the bit rule on the 36 cells')
agree = True; stdl = {}
for n in range(0, 6):
    for p in range(0, n + 1):
        q = n - p
        for sg in (-1, 1):
            small = STD[(p + 1, q)]
            big, drop = (STD[(p + 1, q + 1)], p + 1 + q) if sg < 0 else (STD[(p + 2, q)], p + 1)
            Ms = std_restrict(big, drop, small)
            Mb = graded_pair(p, q, sg)[1]
            stdl[(p, q, sg)] = coker_divisors(Ms)
            agree = agree and Ms == Mb and stdl[(p, q, sg)] == graded_pair(p, q, sg)[0][0]
chk('std', all(stdl[(p, q, sg)] == (KOM[(q - p) % 8] if sg < 0 else KOM[(p - q) % 8]) for (p, q, sg) in stdl),
    'aty.A4: 42 graded cokernels (p + q <= 5) from intertwiner dimensions and determinantal divisors are the KO entries of the clock')
chk('bit==std', agree, 'aty.A4: the 42 restriction matrices and cokernels agree with the bit rule entry by entry')
chk('std', [stdl[(0, n, -1)] for n in range(6)] == want_g[:6], 'aty.A4: graded Cl(0,n), n = 0..5: %s' % ' '.join(stdl[(0, n, -1)] for n in range(6)))

head('A5. complex modules: period 2')
cf = FAULT == 'CPLX'
okc = all(ccounts(c)[0] * ccounts(c)[1] ** 2 == (1 << c['n']) for c in CELL.values())
chk('bit', okc, 'aty.A5: centre dimension times (complex dimension)^2 = 2^n at every cell (one simple summand of C (x) Cl for n even, two for n odd)')
cl = []; cbad = []; cswap = True
for n in range(0, 8):
    for p in range(0, n + 1):
        q = n - p
        for sg in (-1, 1):
            small = CELL[(p + 1, q)]
            big, drop = (CELL[(p + 1, q + 1)], p + 1 + q) if sg < 0 else (CELL[(p + 2, q)], p + 1)
            M, sw = crestrict(big, drop, small, cf); cswap = cswap and sw
            nm = coker(M)[0]
            if nm != ('Z' if n % 2 == 0 else '0'): cbad.append((p, q, sg, nm))
            if p == 0 and sg < 0: cl.append(nm)
chk('bit', not cbad and cswap, 'aty.A5: complex graded groups for the 72 pairs, p + q <= 7: Z for p + q even, 0 for p + q odd, whatever the clock; along Cl(0,n): %s' % ' '.join(cl))
okcs = True
for n in range(0, 6):
    for p in range(0, n + 1):
        q = n - p
        small = std_cell(p + 1, q, cplx=True); big = std_cell(p + 1, q + 1, cplx=True)
        okcs = okcs and coker_divisors(std_restrict(big, p + 1 + q, small)) == ('Z' if n % 2 == 0 else '0')
chk('std', okcs, 'aty.A5: complex Kronecker words (numpy), 21 cells p + q <= 5: the complex graded groups are Z for p + q even and 0 for p + q odd')
wrong = [coker(crestrict(CELL[(1, n + 1)], 1 + n, CELL[(1, n)], True)[0])[0] for n in range(0, 6)]
chk('ctl', wrong != ['Z', '0'] * 3, 'aty.A5: counting the real simple summands in place of the complex ones gives %s (CPLX)' % ' '.join(wrong))
chk('bit', cl[1] == '0' and cl[3] == '0', 'aty.A5: K^(-1)(point) = 0: in the complex spectral sequence E2 vanishes in every odd row, so d2, d4, ... are zero (the paper, section 4)')

head('A6. products: concatenating labels is the graded tensor product')
def gtensor(M, N):
    mM, mN = M[0].shape[0], N[0].shape[0]
    IM, IN = np.eye(mM, dtype=np.int64), np.eye(mN, dtype=np.int64)
    return [np.kron(M[0], N[0])] + [np.kron(R, IN) for R in M[1:]] + [np.kron(M[0], R) for R in N[1:]]
def gclass(mods, n):
    """class of a Cl(1,n)-module in the graded group of Cl(0,n) inside Cl(0,n+1)"""
    small, big = CELL[(1, n)], CELL[(1, n + 1)]
    m = mods[0].shape[0]; I = np.eye(m, dtype=np.int64)
    ok = all(np.array_equal(mods[i] @ mods[j] + mods[j] @ mods[i], (2 * small['eps'][i] if i == j else 0) * I) for i in range(n + 1) for j in range(n + 1))
    if len(small['irreps']) == 1: v = [m // small['m']]
    else:
        W = mprod(mods, m); v = [(m - rank_int((W - I).tolist())) // small['m'], (m - rank_int((W + I).tolist())) // small['m']]
    M, _ = restrict(big, 1 + n, small)
    _, cd = coker(M)
    return ok, coker_class(cd, v), v
eta = CELL[(1, 1)]['irreps'][0]; al, al2 = CELL[(1, 4)]['irreps']; beta = CELL[(1, 8)]['irreps'][0]
ok1, c_eta, _ = gclass(eta, 1); ok2, c_eta2, v2 = gclass(gtensor(eta, eta), 2)
chk('bit', ok1 and ok2 and c_eta == (1,) and c_eta2 == (1,), 'aty.A6: eta (dimension 2) is the generator of Z2 at n = 1 and eta^2 (dimension 4, %s irreducible) is not 0 in the Z2 at n = 2' % v2[0])
oka, c_al, _ = gclass(al, 4); okb, c_be, _ = gclass(beta, 8)
ok3, c_aa, vaa = gclass(gtensor(al, al), 8); ok4, c_ab, vab = gclass(gtensor(al, al2), 8); ok5, c_bb, _ = gclass(gtensor(al2, al2), 8)
chk('bit', oka and okb and ok3 and ok4 and ok5 and abs(c_al[0]) == 1 and abs(c_be[0]) == 1 and c_aa[0] == 4 * c_be[0],
    'aty.A6: alpha, the irreducible of Cl(1,4) on which the volume element is +1, generates the Z at n = 4 (class %d); alpha^2 (dimension 64, multiplicities %s) has class %d = 4 beta, beta the 16-dimensional irreducible of Cl(1,8) with volume element +1 (class %d)' % (c_al[0], vaa, c_aa[0], c_be[0]))
chk('bit', c_ab[0] == -c_aa[0] and c_bb[0] == c_aa[0], 'aty.A6: bilinear: (-alpha) alpha = -alpha^2 (class %d), (-alpha)^2 = alpha^2 (class %d)' % (c_ab[0], c_bb[0]))
ok6, c_eb, veb = gclass(gtensor(eta, beta), 9); ok7, c_be2, _ = gclass(gtensor(beta, eta), 9)
chk('bit', ok6 and ok7 and c_eb == (1,) and c_be2 == (1,), 'aty.A6: eta.beta and beta.eta (dimension 32) are not 0 in the Z2 at n = 9: multiplication by beta carries the generator at n = 1 to that at n = 9')
s11, s14 = STD[(1, 1)]['irreps'][0], STD[(1, 4)]['irreps'][0]
def gtensor_f(M, N):
    IM, IN = np.eye(M[0].shape[0]), np.eye(N[0].shape[0])
    return [np.kron(M[0], N[0])] + [np.kron(R, IN) for R in M[1:]] + [np.kron(M[0], R) for R in N[1:]]
AA = gtensor_f(s14, s14); om9 = np.eye(64)
for R in AA: om9 = om9 @ R
EE = gtensor_f(s11, s11)
cls_std = int(round(np.trace(om9).real / 16)); mult_std = [(64 + 16 * cls_std) // 32, (64 - 16 * cls_std) // 32]; e2std = (EE[0].shape[0] // STD[(1, 2)]['m']) % 2
chk('std', abs(cls_std) == 4 and e2std == 1, 'aty.A6: numpy: alpha^2 has trace of the volume element 16 x %d (four equal summands), eta^2 one irreducible of Cl(1,2)' % cls_std)
chk('bit==std', mult_std == vaa, 'aty.A6: the multiplicities of the two irreducibles of Cl(1,8) in alpha^2 agree: %s' % (mult_std,))
print('  (A: %.1f s for the bit-rule cells)' % TA, flush=True)

# ================================================================================================ B. the twisted de Rham complex
NV = 5
ALG5 = Alg(sig(0, 0, NV))
def clean(f): return {k: v for k, v in f.items() if v != 0}
def fadd(a, b, cb=1):
    out = dict(a)
    for k, v in b.items(): out[k] = out.get(k, 0) + cb * v
    return clean(out)
def fwedge(a, b):
    out = {}
    for (A, ma), x in a.items():
        for (B, mb), y in b.items():
            s, C = ALG5.blade_mul(A, B)
            if s:
                key = (C, tuple(i + j for i, j in zip(ma, mb))); out[key] = out.get(key, 0) + s * x * y
    return clean(out)
def fd(a):
    out = {}
    for (A, ma), x in a.items():
        for i in range(NV):
            if ma[i]:
                s, C = ALG5.blade_mul(1 << i, A)
                if s:
                    mb = list(ma); mb[i] -= 1; key = (C, tuple(mb)); out[key] = out.get(key, 0) + s * x * ma[i]
    return clean(out)
def fexp(z):
    out = {(0, (0,) * NV): Fr(1)}; term = dict(out)
    for k in range(1, NV + 1):
        term = {kk: v / k for kk, v in fwedge(term, z).items()}
        if not term: break
        out = fadd(out, term)
    return out
def DH(H, w): return fadd(fd(w), fwedge(H, w), -1)
MONOS = [m for m in itertools.product(range(3), repeat=NV) if sum(m) <= 2]
def rform(rg, degrees, nb=3, nm=2):
    f = {}
    for dg in degrees:
        blades = [a for a in range(1 << NV) if bin(a).count('1') == dg]
        for A in rg.sample(blades, min(nb, len(blades))):
            for mono in rg.sample(MONOS, nm):
                c = rg.randint(-3, 3)
                if c: f[(A, mono)] = f.get((A, mono), 0) + Fr(c)
    return clean(f)
def const(A, c=1): return {(A, (0,) * NV): Fr(c)}

# the standard forms: index tuples, the sign of the sorting permutation, the component formula of d (no label)
def _merge_sign(I, J):
    if set(I) & set(J): return 0, None
    L = list(I) + list(J); inv = sum(1 for a in range(len(L)) for b in range(a + 1, len(L)) if L[a] > L[b])
    return (-1) ** inv, tuple(sorted(L))
def to_std(f): return {(tuple(i for i in range(NV) if A >> i & 1), m): v for (A, m), v in f.items()}
def swedge(a, b):
    out = {}
    for (I, ma), x in a.items():
        for (J, mb), y in b.items():
            s, K = _merge_sign(I, J)
            if s:
                key = (K, tuple(i + j for i, j in zip(ma, mb))); out[key] = out.get(key, 0) + s * x * y
    return clean(out)
def sd(a):
    out = {}
    for (I, ma), x in a.items():
        for i in range(NV):
            if ma[i] and i not in I:
                s, K = _merge_sign((i,), I); mb = list(ma); mb[i] -= 1
                key = (K, tuple(mb)); out[key] = out.get(key, 0) + s * x * ma[i]
    return clean(out)
def sDH(H, w): return fadd(sd(w), swedge(H, w), -1)

head('B1. D = d - H on polynomial forms on R^5: D^2 = -(dH), so D^2 = 0 exactly for closed odd H')
rg = random.Random(175)
WS = [rform(rg, [0, 1, 2, 3]) for _ in range(5)]
chk('bit', all(not fd(fd(w)) for w in WS), 'aty.B1: d d = 0 on five random forms of degrees 0..3 (null labels: the square of every generator is 0)')
Hopen = rform(rg, [3], nb=4, nm=2)
ok = all(fadd(DH(Hopen, DH(Hopen, w)), fwedge(fd(Hopen), w)) == {} for w in WS)
chk('bit', ok and fd(Hopen) != {}, 'aty.B1: for a random 3-form H with dH != 0, D(D w) = -(dH) w on the five forms (H H = 0 by the sign rule)')
Hcl = fadd(fd(rform(rg, [2], nb=4, nm=3)), const(0b00111, 2))
Hodd = fadd(fadd(fd(rform(rg, [0], nb=1, nm=4)), const(0b00010, -1)), fadd(Hcl, const(0b11111, 3)))
tw = {'OPENH': Hopen, 'EVENTWIST': const(0b00011)}.get(FAULT, Hcl)
chk('bit', not fd(Hcl) and all(not DH(tw, DH(tw, w)) for w in WS), 'aty.B1: H = dB + 2 e123 (closed 3-form): D^2 = 0 on the five forms')
chk('bit', not fd(Hodd) and all(not DH(Hodd, DH(Hodd, w)) for w in WS), 'aty.B1: H of degrees 1 + 3 + 5, closed: D^2 = 0 on the five forms (a twist by any closed odd form)')
B0 = const(0b00011)
chk('ctl', any(DH(B0, DH(B0, w)) for w in WS), 'aty.B1: the closed even form e12 as a twist: (d - B)^2 != 0 (EVENTWIST)')
chk('ctl', any(DH(Hopen, DH(Hopen, w)) for w in WS), 'aty.B1: the 3-form with dH != 0: D^2 != 0 (OPENH)')
okstd = all(swedge(to_std(fd(Hopen)), to_std(w)) == to_std(fwedge(fd(Hopen), w)) and sDH(to_std(Hopen), sDH(to_std(Hopen), to_std(w))) == to_std(DH(Hopen, DH(Hopen, w))) for w in WS)
chk('bit==std', okstd, 'aty.B1: index tuples with the sorting sign and the component d give the same D D w and (dH) w on the five forms')
chk('std', all(not sDH(to_std(Hcl), sDH(to_std(Hcl), to_std(w))) for w in WS), 'aty.B1: standard forms: D^2 = 0 for the closed H')

head('B2. the twist depends on the class of H: D_(H+dz) e^z = e^z D_H')
zt = rform(rg, [2], nb=4, nm=2); ez = fexp(zt); emz = fexp({k: -v for k, v in zt.items()})
H2 = fadd(Hcl, fd(zt))
use = emz if FAULT == 'GAUGE' else ez
chk('bit', all(fadd(DH(H2, fwedge(use, w)), fwedge(use, DH(Hcl, w)), -1) == {} for w in WS), 'aty.B2: z a random 2-form, e^z = 1 + z + z^2/2 (z^3 = 0 on R^5): D_(H+dz)(e^z w) = e^z D_H w on the five forms')
chk('ctl', any(fadd(DH(H2, fwedge(emz, w)), fwedge(emz, DH(Hcl, w)), -1) for w in WS), 'aty.B2: with e^-z the identity fails (GAUGE)')
zc = const(0b01100, 3); ezc = fexp(zc)
chk('bit', all(fadd(DH(Hcl, fwedge(ezc, w)), fwedge(ezc, DH(Hcl, w)), -1) == {} for w in WS), 'aty.B2: a closed 2-form z = 3 e34 commutes with D_H through e^z: H^2(X; R) acts on the twisted cohomology')
zp = rform(rg, [2], nb=3, nm=2); Hx = fd(zp); ezp = fexp(zp)
gams = [const(0b00001), fadd(const(0b00110), const(0b11000, -2)), const(0b01011)]
betas = [fwedge(ezp, g) for g in gams]
alphas = [rform(rg, [1], nb=3, nm=2) for _ in range(3)]
okc = all(not DH(Hx, b) for b in betas)
okr = all(fadd(fwedge(fd(a), b), DH(Hx, fwedge(a, b)), -1) == {} for a in alphas for b in betas)
chk('bit', okc and okr, 'aty.B2: H = dz, b = e^z g with g closed: D b = 0, and (da) b = D(a b) for three random 1-forms a and three such b')
chk('bit==std', all(sDH(to_std(H2), swedge(to_std(ez), to_std(w))) == swedge(to_std(ez), sDH(to_std(Hcl), to_std(w))) for w in WS), 'aty.B2: the same identity with the standard forms')

# ------------------------------------------------------------------------------------------------ B, finite models
class BitModel:
    """exterior algebra on k null labels (Chevalley-Eilenberg d given on the generators) times R[t]/t^(m+1), t of degree 2"""
    def __init__(self, k, m, dgen):
        self.k, self.m, self.alg = k, m, Alg(sig(0, 0, k)); self.dgen = dgen; self._d = {}
        self.basis = sorted([(A, a) for A in range(1 << k) for a in range(m + 1)], key=lambda x: (bin(x[0]).count('1') + 2 * x[1], x))
        self.idx = {b: i for i, b in enumerate(self.basis)}; self.deg = [bin(A).count('1') + 2 * a for A, a in self.basis]
    def dblade(self, A):
        if A in self._d: return self._d[A]
        out = {}
        if A:
            i = (A & -A).bit_length() - 1; B = A ^ (1 << i)
            for C, c in self.dgen.get(i, {}).items():
                s, D = self.alg.blade_mul(C, B)
                if s: out[D] = out.get(D, 0) + s * c
            for C, c in self.dblade(B).items():
                s, D = self.alg.blade_mul(1 << i, C)
                if s: out[D] = out.get(D, 0) - s * c
        self._d[A] = clean(out); return self._d[A]
    def mul(self, x, y):
        out = {}
        for (A, a), u in x.items():
            for (B, b), v in y.items():
                if a + b > self.m: continue
                s, C = self.alg.blade_mul(A, B)
                if s: out[(C, a + b)] = out.get((C, a + b), 0) + s * u * v
        return clean(out)
    def d(self, x):
        out = {}
        for (A, a), u in x.items():
            for C, c in self.dblade(A).items(): out[(C, a)] = out.get((C, a), 0) + c * u
        return clean(out)
    def vec(self, x):
        v = [0] * len(self.basis)
        for b, c in x.items(): v[self.idx[b]] = int(c)
        return v
    def matrix(self, eta, which='D'):
        cols = []
        for b in self.basis:
            x = {b: 1}; y = self.d(x) if which in ('D', 'd') else {}
            if which in ('D', 'e'): y = fadd(y, self.mul(eta, x), -1)
            cols.append(self.vec(y))
        nb = len(self.basis)
        return [[cols[j][i] for j in range(nb)] for i in range(nb)]

def twisted_dims(D, deg):
    E = [i for i in range(len(deg)) if deg[i] % 2 == 0]; O = [i for i in range(len(deg)) if deg[i] % 2 == 1]
    rEO = rank_int([[D[i][j] for j in E] for i in O]); rOE = rank_int([[D[i][j] for j in O] for i in E])
    return len(E) - rEO - rOE, len(O) - rOE - rEO
def pages(D, deg, rmax):
    """dims of E_r^p of the degree filtration, r = 1..rmax: dim Z_r^p - dim(Z_(r-1)^(p+1) + D Z_(r-1)^(p-r+1))"""
    nb = len(deg); top = max(deg); memo = {}
    def Z(r, p):
        if (r, p) in memo: return memo[(r, p)]
        cols = [j for j in range(nb) if deg[j] >= p]
        rows = [i for i in range(nb) if deg[i] < p + r]
        if not cols: B = []
        elif not rows: B = [[int(j == c) for j in range(nb)] for c in cols]
        else:
            ns = nullspace_int([[D[i][j] for j in cols] for i in rows], len(cols))
            B = [[0] * nb for _ in ns]
            for v, w in zip(B, ns):
                for c, x in zip(cols, w): v[c] = x
        memo[(r, p)] = B; return B
    out = {}
    for r in range(1, rmax + 1):
        dims = []
        for p in range(0, top + 1):
            num = len(Z(r, p))
            den = Z(r - 1, p + 1) + [matvec(D, v) for v in Z(r - 1, p - r + 1)]
            dims.append(num - rank_int(den))
        out[r] = dims
    return out

class StdModel:
    """the same models on index tuples with the sorting sign (no label); numpy float matrices"""
    def __init__(self, k, m, dgen):
        self.k, self.m = k, m; self.dgen = dgen
        self.basis = sorted([(I, a) for s in range(k + 1) for I in itertools.combinations(range(k), s) for a in range(m + 1)], key=lambda x: (len(x[0]) + 2 * x[1], x))
        self.idx = {b: i for i, b in enumerate(self.basis)}; self.deg = [len(I) + 2 * a for I, a in self.basis]
    def mul(self, x, y):
        out = {}
        for (I, a), u in x.items():
            for (J, b), v in y.items():
                if a + b > self.m: continue
                s, K = _merge_sign(I, J)
                if s: out[(K, a + b)] = out.get((K, a + b), 0) + s * u * v
        return clean(out)
    def d(self, x):
        out = {}
        for (I, a), u in x.items():
            for s in range(len(I)):
                left = {(I[:s], 0): (-1) ** s}; right = {(I[s + 1:], 0): 1}
                dg = {(J, 0): c for J, c in self.dgen.get(I[s], {}).items()}
                t = self.mul(self.mul(left, dg), right)
                for (K, _), c in t.items(): out[(K, a)] = out.get((K, a), 0) + c * u
        return clean(out)
    def matrix(self, eta):
        nb = len(self.basis); D = np.zeros((nb, nb))
        for j, b in enumerate(self.basis):
            y = fadd(self.d({b: 1}), self.mul(eta, {b: 1}), -1)
            for bb, c in y.items(): D[self.idx[bb], j] = float(c)
        return D
def std_twisted(D, deg):
    E = [i for i in range(len(deg)) if deg[i] % 2 == 0]; O = [i for i in range(len(deg)) if deg[i] % 2 == 1]
    r1 = np.linalg.matrix_rank(D[np.ix_(O, E)]) if E and O else 0; r2 = np.linalg.matrix_rank(D[np.ix_(E, O)]) if E and O else 0
    return len(E) - r1 - r2, len(O) - r2 - r1
def std_pages(D, deg, rmax):
    nb = len(deg); deg = np.array(deg); top = int(deg.max())
    def Z(r, p):
        cols = np.where(deg >= p)[0]; rows = np.where(deg < p + r)[0]
        if len(cols) == 0: return np.zeros((nb, 0))
        if len(rows) == 0: return np.eye(nb)[:, cols]
        ns = scipy.linalg.null_space(D[np.ix_(rows, cols)], rcond=1e-9)
        out = np.zeros((nb, ns.shape[1])); out[cols, :] = ns; return out
    res = {}
    for r in range(1, rmax + 1):
        dims = []
        for p in range(0, top + 1):
            den = np.hstack([Z(r - 1, p + 1), D @ Z(r - 1, p - r + 1)])
            dims.append(Z(r, p).shape[1] - (np.linalg.matrix_rank(den, tol=1e-8) if den.shape[1] else 0))
        res[r] = dims
    return res

# the models: T3, T4, SU(2), the Heisenberg nilmanifold Y, M = Y x CP^2, Y3 x CP^3 (generators x, y, z, u = labels 0, 1, 2, 3)
MODELS = [
    ('T3', 3, 0, {}, {(0b111, 0): 1}),
    ('T4', 4, 0, {}, {(0b0111, 0): 1}),
    ('SU(2)', 3, 0, {0: {0b110: -1}, 1: {0b101: 1}, 2: {0b011: -1}}, {(0b111, 0): 1}),
    ('Y', 3, 0, {2: {0b011: 1}}, {(0b111, 0): 1}),
    ('Y x CP^2', 3, 2, {2: {0b011: 1}}, {(0b001, 1): 1}),
    ('Y3 x CP^3', 4, 3, {2: {0b0011: 1}, 3: {0b0101: 1}}, {(0b0001, 1): 1}),
]
def std_dgen(dg, k): return {i: {tuple(j for j in range(k) if C >> j & 1): c for C, c in v.items()} for i, v in dg.items()}
def std_eta(eta, k): return {(tuple(j for j in range(k) if A >> j & 1), a): c for (A, a), c in eta.items()}

head('B3. twisted cohomology of the invariant-form models')
RES = {}
for name, k, m, dg, eta in MODELS:
    bm = BitModel(k, m, dg); D = bm.matrix(eta); dmat = bm.matrix(eta, 'd'); emat = bm.matrix(eta, 'e')
    dd = np.array(dmat, dtype=object); okdd = not np.any(dd.dot(dd)); okde = not bm.d(eta) and not bm.mul(eta, eta)
    tw = twisted_dims(D, bm.deg); un = twisted_dims(dmat, bm.deg)
    sm = StdModel(k, m, std_dgen(dg, k)); Ds = sm.matrix(std_eta(eta, k))
    RES[name] = (bm, D, tw, un, sm, Ds, okdd and okde)
want_tw = {'T3': (3, 3), 'T4': (6, 6), 'SU(2)': (0, 0), 'Y': (2, 2), 'Y x CP^2': (4, 4)}
want_un = {'T3': (4, 4), 'T4': (8, 8), 'SU(2)': (1, 1), 'Y': (3, 3), 'Y x CP^2': (9, 9), 'Y3 x CP^3': (16, 16)}
chk('bit', all(r[6] for r in RES.values()), 'aty.B3: on the six models d d = 0, dH = 0 and H H = 0 exactly (labels with null squares)')
chk('bit', all(RES[nm][3] == want_un[nm] for nm in want_un), 'aty.B3: untwisted (even, odd) dimensions: %s' % ', '.join('%s %s' % (nm, RES[nm][3]) for nm in want_un))
chk('bit', all(RES[nm][2] == want_tw[nm] for nm in want_tw), 'aty.B3: twisted (even, odd): %s' % ', '.join('%s %s' % (nm, RES[nm][2]) for nm in want_tw))
chk('std', all(std_twisted(RES[nm][5], RES[nm][4].deg) == RES[nm][2] for nm in RES), 'aty.B3: numpy ranks on the standard models give the same twisted dimensions on all six (Y3 x CP^3: %s)' % (RES['Y3 x CP^3'][2],))

head('B4. Massey products: {x, x, y} on Y and the zig-zags on Y x CP^2 and Y3 x CP^3')
bm = RES['Y'][0]
x, y, z = {(0b001, 0): 1}, {(0b010, 0): 1}, {(0b100, 0): 1}
xy_exact = bm.mul(x, y) == bm.d(z) and not bm.mul(x, x)
w = bm.mul(x, z)                                                    # u = 0 (x x = 0), v = z: w = u y + (-1)^(1+1) x v = x z
Z1 = [bm.vec({b: 1}) for b in bm.basis if bm.deg[bm.idx[b]] == 1 and not bm.d({b: 1})]
def vec_to_el(bmod, v): return {bmod.basis[i]: c for i, c in enumerate(v) if c}
indet = [bm.vec(bm.d({b: 1})) for b in bm.basis if bm.deg[bm.idx[b]] == 1] + [bm.vec(bm.mul(x, vec_to_el(bm, c))) for c in Z1] + [bm.vec(bm.mul(vec_to_el(bm, c), y)) for c in Z1]
chk('bit', xy_exact and not bm.d(w) and rank_int(indet + [bm.vec(w)]) > rank_int(indet), 'aty.B4: on Y, x x = 0 and x y = dz, so {x, x, y} = x z: closed, and not in d(forms) + x H^1 + H^1 y (the Appendix, (A1))')
bm = RES['Y x CP^2'][0]
eta = {(0b001, 1): 1}; y = {(0b010, 0): 1}; v1 = {(0b100, 1): 1}
z5 = bm.mul(eta, v1); d5 = {kk: -c for kk, c in z5.items()}
Z3 = [bm.vec({b: 1}) for b in bm.basis if bm.deg[bm.idx[b]] == 3]
Z3c = [v for v in nullspace_int([[bm.vec(bm.d(vec_to_el(bm, e)))[i] for e in Z3] for i in range(len(bm.basis))], len(Z3))]
Z3el = [{kk: c for kk, c in zip([bm.basis[i] for i in range(len(bm.basis)) if bm.deg[i] == 3], v) if c} for v in Z3c]
B6 = [bm.vec(bm.d({b: 1})) for b in bm.basis if bm.deg[bm.idx[b]] == 5] + [bm.vec(bm.mul(eta, c)) for c in Z3el]
okz = bm.mul(eta, y) == bm.d(v1) and not bm.d(d5) and d5 == {(0b101, 2): -1}
chk('bit', okz and rank_int(B6 + [bm.vec(d5)]) > rank_int(B6), 'aty.B4: on Y x CP^2 with H = xt: H y = d(z t), d5(y) = -H (z t) = -x z t^2, closed and not in d(forms) + H (closed 3-forms): not 0 in E4 at degree 6')
bm3 = RES['Y3 x CP^3'][0]
eta3 = {(0b0001, 1): 1}; y3 = {(0b0010, 0): 1}; w1 = {(0b0100, 1): 1}; w2 = {(0b1000, 2): 1}
ok7 = bm3.mul(eta3, y3) == bm3.d(w1) and bm3.mul(eta3, w1) == bm3.d(w2)
d7 = {kk: -c for kk, c in bm3.mul(eta3, w2).items()}
chk('bit', ok7 and not bm3.d(d7) and d7 == {(0b1001, 3): -1}, 'aty.B4: on Y3 x CP^3 (du = x z): H y = d(z t), H z t = d(u t^2), d7(y) = -H u t^2 = -x u t^3, a closed 8-form')

head('B5. the spectral sequence of the degree filtration')
PG = {}
for nm in ('T3', 'SU(2)', 'Y', 'Y x CP^2', 'Y3 x CP^3'):
    bmod, D = RES[nm][0], RES[nm][1]; top = max(bmod.deg)
    PG[nm] = pages(D, bmod.deg, top + 2)
pm = PG['Y x CP^2']; tot = {r: sum(v) for r, v in pm.items()}
bmM, DM = RES['Y x CP^2'][0], RES['Y x CP^2'][1]
print('  pages of Y x CP^2 by degree: E2 %s, E4 %s, E6 %s, E8 %s' % (pm[2], pm[4], pm[6], pm[8]), flush=True)
chk('bit', all(pg[r] == pg[r + 1] for pg in PG.values() for r in range(2, max(pg) - 1, 2)), 'aty.B5: E3 = E2, E5 = E4, ...: every even differential d2, d4, ... is zero on the five models (D has degrees +1 and +3 only)')
chk('bit', tot[2] == 18 and tot[4] == 10 and tot[6] == 8 and tot[max(pm)] == 8, 'aty.B5: Y x CP^2, H = xt: E2 = %d, E4 = %d, E6 = %d, E_infinity = %d' % (tot[2], tot[4], tot[6], tot[max(pm)]))
# the d3-cycles of E2 (the kernel of H on H*(M)): dim E2 - (dim E2 - dim E4)/2
zc3 = tot[2] - (tot[2] - tot[4]) // 2
chk('bit', zc3 == 14 and sum(RES['Y x CP^2'][2]) == tot[max(pm)], 'aty.B5: the d3-cycles have dimension %d; the sum of E_infinity is the twisted cohomology %s' % (zc3, RES['Y x CP^2'][2]))
chk('bit', pm[4][1] - pm[6][1] == 1 and pm[4][6] - pm[6][6] == 1 and sum(pm[4]) - sum(pm[6]) == 2, 'aty.B5: d5 has rank 1, from degree 1 (y) to degree 6 (x z t^2)')
p3 = PG['Y3 x CP^3']; t3 = {r: sum(v) for r, v in p3.items()}
print('  pages of Y3 x CP^3 by degree: E2 %s, E4 %s, E6 %s, E8 %s' % (p3[2], p3[4], p3[6], p3[8]), flush=True)
chk('bit', t3[6] > t3[8] and p3[6][1] > p3[8][1] and p3[6][8] > p3[8][8] and t3[8] == t3[max(p3)] == sum(RES['Y3 x CP^3'][2]),
    'aty.B5: Y3 x CP^3: E2 = %d, E4 = %d, E6 = %d, E8 = E_infinity = %d; d7 is not 0, from degree 1 to degree 8' % (t3[2], t3[4], t3[6], t3[8]))
chk('bit', all(sum(PG[nm][max(PG[nm])]) == sum(RES[nm][2]) for nm in PG) and sum(PG['T3'][4]) == sum(PG['T3'][max(PG['T3'])]),
    'aty.B5: on the five models the sum of E_infinity is the twisted cohomology; on T3, SU(2), Y the sequence stops at E4')
SP_ = {nm: std_pages(RES[nm][5], RES[nm][4].deg, max(PG[nm])) for nm in ('Y x CP^2', 'Y3 x CP^3')}
chk('bit==std', all(SP_[nm][r] == PG[nm][r] for nm in SP_ for r in PG[nm]), 'aty.B5: scipy null spaces and numpy ranks on the standard models give the same pages, degree by degree, for Y x CP^2 and Y3 x CP^3')
formal = tot[4] if FAULT == 'FORMAL' else tot[max(pm)]
chk('bit', formal == 8, 'aty.B5: the rank of twisted K-theory over the reals of Y x CP^2 is %d (Chern character, the paper, Proposition 7.4; recalled)' % formal)
chk('ctl', tot[4] != tot[max(pm)], 'aty.B5: the formal shortcut E4 = E_infinity fails on Y x CP^2 (%d != %d): the Massey product is seen (FORMAL)' % (tot[4], tot[max(pm)]))
printed = (14, 10) if FAULT == 'PRINTED' else (tot[4], tot[6])
chk('bit', printed == (10, 8), 'aty.B5: the pages E4 and E6 of Y x CP^2 have dimensions %s' % (printed,))
chk('ctl', (tot[4], tot[6]) != (14, 10) and zc3 == 14 and tot[4] == 10, 'aty.B5: the Appendix prints 18, 14, 10 for E2, E4, E6 = E_infinity; 14 is the dimension of the d3-cycles and 10 that of E4 (PRINTED)')

print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('ATY-TWISTK')
