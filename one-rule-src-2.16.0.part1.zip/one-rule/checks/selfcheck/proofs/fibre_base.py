#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""fibre_base.py: fibre and base in the matter chapter, the spacetime cell beside Furey's Cl(6), on the labels (round 11, proofs pass 9a;
docs/round11/PLAN.md; the owner's page 2, docs/round10/owner_sketch_chain_splits.jpg, "left/right, fibre/base").
     python3 fibre_base.py [--fault NOTWIST|UNGRADED|WRONGSIGN|NOJ|HH|KKSIGN]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q,r) has its p generators
of square +1 first, then q of square -1 (core_check.sig); Cl(1,3) with bit 0 = time of square +1 (INP-011, shifted_dirac.py); the type
table core_check.TYPE.  The octonions enter as data, as furey_bit_route.py takes them (reports/furey/model.py: index 1 = i, 2 = j, 3 = k,
4 = l, 5 = li, 6 = lj, 7 = lk; k is Furey's e7 and omega = L_e7); the six fibre units are the others, in the model's order 1, 2, 4, 5, 6, 7.
fb.LR  left and right on Cl(1,3) (LNS-113, the owner's (3,1) x (1,3)).  On the 16 labels: L_a and the twisted R'_b x = (-1)^|x| x e_b
       satisfy the table of the concatenated label eps = (1,-1,-1,-1 | -1,1,1,1) (Cl(1,3) (x)^ Cl(3,1) = Cl(4,4), GEN-010) and their 256
       words fill M16(R) = End(A); the plain R_b commute with the L_a, their words have the table of Cl(1,3) (the opposite algebra up to the
       reversion), L (x) R = M2(H) (x) M2(H) = M16(R); the counts sum e_a^2 say why: the opposite keeps the squares (-4), the mirror flips them
       (+4).  [std] real 8 x 8 gamma matrices, operators on M8(R).  [ctl] NOTWIST, the mirror's ungraded product M8(H).
fb.OCT the fibre: Cl(0,6) = M8(R) on the labels; the left multiplications by six octonion units anticommute, square to -1 and fill M8(R)
       = End(O); the ideal of the labels is O by an intertwiner; the product of the six is sigma L_e7; C (x) Cl(0,6) = M8(C).
fb.TY  the four cells beside it: Cl(1,3) (x)^ Cl(0,6) = Cl(1,9), Cl(3,1) (x)^ Cl(0,6) = Cl(3,7), Cl(1,3) (x)^ Cl(6,0) = Cl(7,3), Cl(3,1) (x)^
       Cl(6,0) = Cl(9,1) against the ungraded products: types from the labels (ltype_eps of chain_blocks.py, the ungraded table), from
       GEN-011's multiplication table and from Kronecker matrices (the trace form); the irreducible modules from primitive idempotents.
       [ctl] HH (H x H = H in the table).
fb.MOD the modules: S = Cl(1,3)(1 + e0)/2 (8, commutant H) and O (8): the gradings of S are L_I R_x, x a unit imaginary quaternion (an S^2);
       S (x) O with (a x 1, 1 x b) is irreducible (M16(H), commutant H), with (a x 1, eps x b) two copies of the 32 of Cl(1,9) (commutant
       M2(R)); the two share the volume element rho(I) x omega6 and the 21 bivectors; on its half Gamma = +1 the even part has commutant
       M2(R) (graded) or H (ungraded).  [std] realified Dirac matrices (gamma5 = i g0 g1 g2 g3) and the octonion matrices, commutants by
       null spaces.  [ctl] NOJ (I alone squares to -1; as a twist it gives Cl(7,3)), UNGRADED.
fb.CHI left and right on the total cell: Gamma = e0..e9 of Cl(1,9) squares to +1, splits the 32 into two halves of 16; Gamma = +I omega6
       in the canonical order, so I = -omega6 on Gamma = +1 and I = +omega6 on Gamma = -1; with I as complex structure each half is an
       irreducible complex 8 of so(1,3) + so(6), the base of one type on both halves, the fibre of conjugate types.  [ctl] WRONGSIGN.
fb.COL so(6) on O with omega6: a complex 4 (commutant C); the stabiliser of the unit 1 is the su(3) of the derivations fixing e7; 4 = 3 + 1
       is FUR-001's O = O2 + O1 (ranks 6, 2).
fb.S10 Cl(1,9), Cl(0,10), Cl(5,5): the same complexification M32(C); real half-spinors 16 for Cl(1,9) and Cl(5,5), none for Cl(0,10)
       (omega^2 = -1, complex 16 after complexification).  The branching 16 -> (2,1,4) + (1,2,4bar) is cited, not computed.
fb.DIR the Dirac operator: the bivectors of base and fibre commute in both products; the vectors anticommute (graded) or commute
       (ungraded); K = k + l: graded K^2 = Q(k) - |l|^2 (the mass shell), ungraded K^2 = Q(k) - |l|^2 + 2 k l and (k + l)(k - l) = Q(k) + |l|^2
       (plane waves only on Q(k) = -|l|^2); exact on the labels and on S (x) O, numpy on the matrices.  [ctl] KKSIGN (the shells of the
       other sign are empty).
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   NOTWIST the plain R in place of the twisted R' (item 1); UNGRADED the twist eps dropped on the modules; WRONGSIGN Gamma = -I omega6
   asserted; NOJ the grading eps = L_I without J; HH H x H = H in GEN-011's table; KKSIGN the fibre momentum with the other sign on the shell.
Not computed here (stated, not checked): the branching of the 16 under Spin(4) x Spin(6) as representation theory (Pati-Salam 1974, Slansky
1981 Table 48, cited); Furey's Cl(6) on C (x) O with her ladder operators (Furey 2016, cited); fields on a manifold (plane waves only);
which product, split or signature nature uses (an input, INP-011).
Command: python3 -I -B selfcheck/proofs/fibre_base.py from checks/ (or from this folder); standard library and numpy."""
import os, sys, time, random, importlib.util
from fractions import Fraction as Fr
from math import isqrt
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py'), (os.path.join(_checks, 'reports', 'furey'), 'model.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps
_spec = importlib.util.spec_from_file_location('furey_model', os.path.join(_checks, 'reports', 'furey', 'model.py'))
OM = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(OM)  # the octonion model, data only (as furey_bit_route.py)

# ------------------------------------------------------------------------------------------------ check lines (from chain_blocks.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish():
    print('\n  tags: %s; %.0f s' % (', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), time.time() - T0))
    print('fibre_base: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NOTWIST', 'UNGRADED', 'WRONGSIGN', 'NOJ', 'HH', 'KKSIGN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(20261016); NPR = np.random.default_rng(20261016)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
def cstr(c): return '(%d,%d)' % c
pc = lambda x: bin(x).count('1')

# ------------------------------------------------------------------------------------------------ the kernel's formula and the label types
# copied from chain_blocks.py (popv, emask, s_vec, type_from_inv, tstr, table_type, ltype_eps, clock_type, type_mul; no __main__ guard there)
def popv(x): return np.bitwise_count(x).astype(np.int64)
def emask(eps):
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    """BR.s(a, b) for arrays of labels: (-1)^(#(i in a, j in b, j < i)) * prod_(i in a & b) eps_i"""
    eps = tuple(eps)
    if eps not in _EM: _EM[eps] = emask(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)): par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    return (1 - 2 * (par & 1)) * _EM[eps][A & B]
def table(eps):
    a = np.arange(1 << len(eps), dtype=np.int64); return s_vec(eps, a[:, None], a[None, :]).astype(np.int8)
DD = {'R': 1, 'C': 2, 'H': 4}
def type_from_inv(dim, c, cplx, fs):
    """c copies of M_m(D) from the dimension, the number c of simple summands, a complex centre, and the count fs (c m, 0, -2 c m)"""
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D]); m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
def table_type(S, gens):
    """the type of the algebra with the sign table S (every e_a^2 = +-1) and generator labels gens: centre, its squares, the count"""
    central = np.ones(S.shape[0], dtype=bool)
    for g in gens: central &= (S[:, g] == S[g, :])
    Z = np.nonzero(central)[0]; sq = S[Z, Z]
    cplx = bool(np.any(sq == -1)); c = len(Z) // 2 if cplx else len(Z)
    return type_from_inv(S.shape[0], c, cplx, int(np.trace(S.astype(np.int64))))
def ltype_eps(eps):
    """the type of a non-degenerate cell from its labels: the count by the kernel formula, the central blades by the reordering counts"""
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); d = s_vec(eps, a, a); cen = np.ones(1 << n, dtype=bool)
    for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
    Z = np.flatnonzero(cen); cplx = bool(np.any(d[Z] == -1))
    return type_from_inv(1 << n, len(Z) // 2 if cplx else len(Z), cplx, int(d.sum()))
def clock_type(p, q):
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2); assert r == 0 and m * m == m2
    return (D, m, c)
def type_mul(t1, t2, hh=None):
    """the ungraded product of two types: R x D = D, C x C = C + C, C x H = M2(C), H x H = M4(R) (H x H = H under --fault HH, or hh=True)"""
    (D1, m1, c1), (D2, m2, c2) = t1, t2
    if D1 == 'R': D, f, k = D2, 1, 1
    elif D2 == 'R': D, f, k = D1, 1, 1
    elif D1 == D2 == 'C': D, f, k = 'C', 1, 2
    elif {D1, D2} == {'C', 'H'}: D, f, k = 'C', 2, 1
    else: D, f, k = ('H', 1, 1) if (FAULT == 'HH' if hh is None else hh) else ('R', 4, 1)
    return (D, m1 * m2 * f, c1 * c2 * k)
def ungraded_table(e1, e2):
    """the ungraded product of two cells on the concatenated label a = a1 + 2^n1 a2: s1(a1,b1) s2(a2,b2), no cross sign"""
    return np.kron(table(e2).astype(np.int8), table(e1).astype(np.int8))
def count(S): return int(np.trace(S.astype(np.int64)))

# ------------------------------------------------------------------------------------------------ labels as an algebra, ideals, commutants
class Lab:
    """a twisted group algebra on N bits, e_a e_b = s(a,b) e_(a xor b) with s = +-1: a cell (BR) or an ungraded product of two cells"""
    def __init__(self, s, N): self.s, self.N, self.M = s, N, 1 << N
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                k = a ^ b; v = out.get(k, 0) + self.s(a, b) * ca * cb
                if v: out[k] = v
                else: out.pop(k, None)
        return out
def lab_graded(eps): return Lab(BR(eps).s, len(eps))
def lab_ungraded(e1, e2):
    A1, A2 = BR(e1), BR(e2); n1 = len(e1); m1 = (1 << n1) - 1
    return Lab(lambda a, b: A1.s(a & m1, b & m1) * A2.s(a >> n1, b >> n1), n1 + len(e2))
def comm_labels(L, first=(), even=False, tries=60):
    """a maximal set of pairwise commuting labels of square +1, independent (none in the span of the others), starting with `first`;
    even=True keeps to labels of even popcount; the largest set over random greedy orders"""
    best = None
    for k in range(tries):
        order = list(range(1, L.M)); RNG.shuffle(order); G = list(first); span = {0}
        for g in G: span |= {x ^ g for x in span}
        for u in order:
            if u in span or L.sq(u) != 1 or (even and pc(u) % 2) or not all(L.commute(u, g) for g in G): continue
            G.append(u); span |= {x ^ u for x in span}
        if best is None or len(G) > len(best): best = G
    return best
def span_tau(L, G):
    """the span H of the commuting labels G and tau(h): e_h f = tau(h) f for f = prod (1 + e_g)/2"""
    tau = {0: 1}
    for g in G:
        for h, t in list(tau.items()): tau[h ^ g] = L.s(h, g) * t           # e_(h^g) = s(h,g) e_h e_g, and e_g f = f
    return tau
class Ideal:
    """the left ideal A f, f = prod (1 + e_g)/2 over commuting labels G of square +1, on the basis e_r f (r a coset representative of span G):
    left and right multiplications by labels are signed permutation matrices (as abs_ring.py and chiral_spinors.py build them)"""
    def __init__(self, L, G):
        self.L, self.G = L, list(G); self.tau = span_tau(L, G); H = list(self.tau)
        self.rep = {}; self.reps = []
        for a in range(L.M):
            if a not in self.rep:
                self.reps.append(a)
                for h in H: self.rep[a ^ h] = (a, h)
        self.m = len(self.reps); self.idx = {r: i for i, r in enumerate(self.reps)}
    def act(self, b):
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[b ^ r]; R[self.idx[r2], self.idx[r]] = self.L.s(b, r) * self.L.s(r2, h) * self.tau[h]
        return R
    def ract(self, c):
        """right multiplication by e_c, c commuting with every label of G"""
        assert all(self.L.commute(c, g) for g in self.G)
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[r ^ c]; R[self.idx[r2], self.idx[r]] = self.L.s(r, c) * self.L.s(r2, h) * self.tau[h]
        return R
def centraliser_div(L, G):
    """f A f for f from G: the labels commuting with all of G, modulo span G, with the squares of the representatives (R, C or H when it
    is a division algebra: dimension 1, 2 with a square -1, 4 with three squares -1 anticommuting)"""
    H = set(span_tau(L, G)); cen = [a for a in range(L.M) if all(L.commute(a, g) for g in G)]
    reps = sorted({min(a ^ h for h in H) for a in cen}); sq = [L.sq(a) for a in reps if a]
    d = len(reps); ok = all(v == -1 for v in sq) and all(not L.commute(a, b) for a in reps if a for b in reps if b and b != a)
    return d, ({1: 'R', 2: 'C', 4: 'H'}.get(d) if ok else None)

# copied from solid_cube.py (commutant_basis: the exact commutant of a module given by signed permutation matrices, by union-find)
def commutant_basis(rho, m):
    """all X (m x m) with X rho_i = rho_i X; each rho_i a signed permutation matrix.  The equations read X[pi(b),pi(c)] = s(b) s(c) X[b,c],
    so the solutions are the sign-consistent components of a union-find over the m^2 entries; the basis is one {0,+1,-1} matrix per component."""
    perms = []
    for R in rho:
        pi = [0] * m; sg = [0] * m
        for c in range(m):
            nz = np.nonzero(R[:, c])[0]; assert len(nz) == 1
            pi[c] = int(nz[0]); sg[c] = int(R[nz[0], c])
        perms.append((pi, sg))
    parent = list(range(m * m)); psign = [1] * (m * m)
    def find(x):
        path = []
        while parent[x] != x: path.append(x); x = parent[x]
        s = 1
        for node in reversed(path):
            s *= psign[node]; psign[node] = s; parent[node] = x
        return x
    def sgn_of(x):
        r = find(x); return r, (1 if x == r else psign[x])
    eqs = []
    for pi, sg in perms:
        for b in range(m):
            for c in range(m): eqs.append((pi[b] * m + pi[c], b * m + c, sg[b] * sg[c]))
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv: parent[ru] = rv; psign[ru] = s * sv * su
    bad = set(); comp = {}
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv or su != s * sv: bad.add(rv)
    for x in range(m * m):
        r, sx = sgn_of(x); comp.setdefault(r, []).append((x, sx))
    basis = []
    for r in sorted(comp):
        if r in bad: continue
        B = np.zeros((m, m), dtype=np.int64)
        for x, sx in comp[r]: B[x // m, x % m] = sx
        basis.append(B)
    return basis
def basis_type(basis):
    """the type of the algebra spanned by integer matrices with disjoint supports (a commutant basis): the structure constants read at one
    support entry of each basis matrix, the centre, its squares, and the signature of the trace form tr(L_xy) (type_from_inv)"""
    d = len(basis); m = basis[0].shape[0]; pos = [tuple(np.argwhere(B != 0)[0]) for B in basis]
    def coords(P):
        x = [int(P[p]) * int(B[p]) for B, p in zip(basis, pos)]                   # entries +-1: the coefficient is P[p] B[p]
        assert np.array_equal(sum(c * B for c, B in zip(x, basis)), P), 'not in the span'
        return x
    K = [[coords(Bi @ Bj) for Bj in basis] for Bi in basis]                       # B_i B_j = sum_t K[i][j][t] B_t
    trL = [sum(K[k][i][i] for i in range(d)) for k in range(d)]                   # tr of left multiplication by B_k
    T = [[sum(K[i][j][t] * trL[t] for t in range(d)) for j in range(d)] for i in range(d)]
    ev = np.linalg.eigvalsh(np.array(T, dtype=float)); fs = int((ev > 1e-9).sum() - (ev < -1e-9).sum())
    cen = nullspace_frac([[K[i][j][t] - K[j][i][t] for i in range(d)] for j in range(d) for t in range(d)], d)
    cplx, c = False, len(cen)
    if len(cen) >= 2:                                    # the centre is R^a + C^b: eigenvalues of the multiplication by a random central z on it
        Zb = np.array([[float(x) for x in v] for v in cen]); z = NPR.standard_normal(len(cen)) @ Zb
        Mz = np.einsum('i,ijt->jt', z, np.array(K, dtype=float))                 # z B_j = sum_t Mz[j,t] B_t
        Cm = np.linalg.lstsq(Zb.T, (Zb @ Mz).T, rcond=None)[0].T                  # z v_k = sum_l Cm[k,l] v_l on the centre basis v_k
        ev = np.linalg.eigvals(Cm); a = int((np.abs(ev.imag) < 1e-7).sum()); b = int((ev.imag > 1e-7).sum())
        if a and b: return None
        cplx, c = (True, b) if b else (False, a)
    return type_from_inv(d, c, cplx, fs)
# copied from chiral_spinors.py (nullspace_frac: an exact rational null space)
def nullspace_frac(rows, ncol):
    rows = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p_ = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if p_ is None: continue
        rows[rk], rows[p_] = rows[p_], rows[rk]; pv = rows[rk][c]; rows[rk] = [x / pv for x in rows[rk]]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncol) if c not in piv]; basis = []
    for f in free:
        v = [Fr(0)] * ncol; v[f] = Fr(1)
        for i, c in enumerate(piv): v[c] = -rows[i][f]
        basis.append(v)
    return basis
def rank_frac(M):
    """exact rank of an integer or Fraction matrix (a list of rows or a numpy array)"""
    rows = [[Fr(x) for x in r] for r in (M.tolist() if hasattr(M, 'tolist') else M)]
    return len(rows[0]) - len(nullspace_frac(rows, len(rows[0]))) if rows else 0
def words_int(G):
    """the 2^n words of integer matrices G (generator i = bit i, the lowest bit first, as the labels)"""
    n = len(G); m = G[0].shape[0]; W = [np.eye(m, dtype=np.int64)]
    for a in range(1, 1 << n):
        top = a.bit_length() - 1; W.append(W[a ^ (1 << top)] @ G[top])
    return W
def rel_ok(G, eps):
    I = np.eye(G[0].shape[0], dtype=G[0].dtype)
    return all(np.array_equal(G[i] @ G[j] + G[j] @ G[i], 2 * eps[i] * I if i == j else 0 * I) for i in range(len(G)) for j in range(i, len(G)))
def word_table(W):
    """the sign table of signed-permutation words: W_a W_b = c W_(a xor b), c read from the traces (each W is orthogonal)"""
    M = len(W); m = W[0].shape[0]; C = np.zeros((M, M), dtype=np.int64); ok = True
    for a in range(M):
        for b in range(M):
            P = W[a] @ W[b]; Q = W[a ^ b]; c = int(np.sum(P * Q)) // m
            ok &= c in (1, -1) and np.array_equal(P, c * Q); C[a, b] = c
    return C, ok
def gram_ok(W):
    """trace orthogonality tr(W_a^T W_b) = m delta_ab: the words are linearly independent (entries 0, +-1 and sums of at most m^2 of them:
    the float64 product is exact)"""
    F = np.array([w.ravel() for w in W], dtype=np.float64); m = W[0].shape[0]
    return np.array_equal(F @ F.T, m * np.eye(len(W)))
def urel_ok(G, e1, e2):
    """the relations of the ungraded product: squares eps, anticommuting inside a factor, commuting across the two factors"""
    n1 = len(e1); eps = tuple(e1) + tuple(e2); I = np.eye(G[0].shape[0], dtype=G[0].dtype)
    return all(np.array_equal(G[i] @ G[j] + (-1 if (i < n1) != (j < n1) else 1) * (G[j] @ G[i]), 2 * eps[i] * I if i == j else 0 * I)
               for i in range(len(G)) for j in range(i, len(G)))

# ------------------------------------------------------------------------------------------------ the standard route: real matrices, no label
# (mat_table and mat_type follow chain_blocks.py; the matrices below never use the bit rule)
I2 = np.eye(2); XM = np.array([[0., 1.], [1., 0.]]); ZM = np.diag([1., -1.]); JM = np.array([[0., -1.], [1., 0.]])
def realify(Zc): return np.block([[Zc.real, -Zc.imag], [Zc.imag, Zc.real]])
_s1 = np.array([[0, 1], [1, 0]], dtype=complex); _s2 = np.array([[0, -1j], [1j, 0]]); _s3 = np.array([[1, 0], [0, -1]], dtype=complex)
_g0 = np.diag([1, 1, -1, -1]).astype(complex)
_gk = [np.block([[0 * s, s], [-s, 0 * s]]) for s in (_s1, _s2, _s3)]
GAM = [realify(g) for g in [_g0] + _gk]                                   # Cl(1,3) on R^8: the Dirac matrices realified
JC = realify(1j * np.eye(4))                                              # the realified i, commuting with GAM
GAM5 = realify(1j * _g0 @ _gk[0] @ _gk[1] @ _gk[2])                       # gamma5 = i g0 g1 g2 g3
G31 = [np.kron(XM, XM), np.kron(XM, ZM), np.kron(ZM, I2), np.kron(JM, I2)]   # Cl(3,1) on R^4 (squares +, +, +, -)
UNITS = [1, 2, 4, 5, 6, 7]                                                # the six fibre units (model index), k = 3 is Furey's e7
OLM = [OM.Lmat(OM.E[u]) for u in UNITS]                                   # Cl(0,6) on O = R^8: left multiplications
LE7 = OM.Lmat(OM.E[3]); RE7 = OM.Rmat(OM.E[3])
G60 = [np.kron(L, JM) for L in OLM]                                       # Cl(6,0) on R^16: L_u x J (squares +1)
def kron_all(ms):
    M = np.ones((1, 1))
    for m_ in ms: M = np.kron(M, m_)
    return M
def fwords(G, dtype=np.float64):
    n = len(G); d = G[0].shape[0]; W = np.zeros((1 << n, d, d), dtype=dtype); W[0] = np.eye(d)
    for a in range(1, 1 << n):
        top = a.bit_length() - 1; W[a] = W[a ^ (1 << top)] @ G[top].astype(dtype)
    return W
def frel_ok(G, eps):
    I = np.eye(G[0].shape[0])
    return all(np.allclose(G[i] @ G[j] + G[j] @ G[i], 2 * eps[i] * I if i == j else 0 * I) for i in range(len(G)) for j in range(i, len(G)))
def mat_table(W):
    """the sign table read from matrices whose generators obey the relations: W_a W_b = c W_(a xor b), c from the images of a vector"""
    M = W.shape[0]; ar = np.arange(M); V = W[:, :, 0]; nrm = (V * V).sum(1); C = np.zeros((M, M))
    for a in range(M): C[a] = ((W[a] @ V.T) * V[a ^ ar].T).sum(0) / nrm[a ^ ar]
    return np.rint(C).astype(np.int64), bool(np.allclose(C, np.rint(C)))
def mat_type(G, nsamp=300):
    """the type of the algebra generated by the real matrices G, no label: its 2^n words (rank), the trace form (the diagonal tr(W_a W_a)/d,
    the off-diagonal entries checked zero on samples), the centre as a null space of random projections, the summands from the eigenvalues of
    a random central element (real ones: real or quaternionic summands; pairs: complex)"""
    n = len(G); W = fwords(G, np.float32); d = W.shape[1]; M = 1 << n
    dg = np.einsum('aij,aji->a', W, W).astype(np.float64) / d; fs = int(np.rint(dg).sum())
    offok = bool(np.all(np.abs(np.abs(dg) - 1) < 1e-4))
    for _ in range(nsamp):
        a, b = RNG.randrange(M), RNG.randrange(M)
        if a != b: offok &= abs(float(np.einsum('ij,ji->', W[a], W[b]))) < 1e-2
    r = min(d, max(4, -(-8 * M // (n * d))))                                       # enough projected columns: n d r >= 8 M equations
    R = NPR.standard_normal((d, r)).astype(np.float32); G32 = [g.astype(np.float32) for g in G]; GR = [g @ R for g in G32]
    cols = np.stack([np.concatenate([(W[a] @ GR[i] - G32[i] @ (W[a] @ R)).ravel() for i in range(n)]) for a in range(M)], 1)
    _, s, Vt = np.linalg.svd(cols.astype(np.float64), full_matrices=False); nul = Vt[s < 1e-5 * max(s.max(), 1)]
    x = nul.T @ NPR.standard_normal(len(nul)); Zc = np.tensordot(x, W.astype(np.float64), 1)
    ev = np.linalg.eigvals(Zc); cl = []
    for v in ev:
        if not any(abs(v - w) < 1e-4 for w in cl): cl.append(v)
    nre = sum(1 for v in cl if abs(v.imag) < 1e-4); ncx = sum(1 for v in cl if v.imag > 1e-4)
    if (nre and ncx) or not offok: return None
    c, cplx = (ncx, True) if ncx else (nre, False)
    if len(nul) != (2 * c if cplx else c): return None
    return type_from_inv(M, c, cplx, fs)
def null_dim(A, tol=1e-8):
    s = np.linalg.svd(A, compute_uv=False); return A.shape[1] - int((s > tol * max(s.max(), 1)).sum())
def commutant_np(GB, GF, dB, dF):
    """numpy: the commutant of {g x 1 : g in GB} and of the further operators GF on R^dB (x) R^dF, by null spaces in two steps: the
    commutant C of GB on R^dB (dB^2 unknowns), then X = sum_k C_k x Y_k with the equations of GF (dim C x dF^2 unknowns)"""
    I = np.eye(dB); A = np.vstack([np.kron(g, I) - np.kron(I, g.T) for g in GB])     # row-major vec: [g, X] = (g x 1 - 1 x g^T) vec X
    _, s, Vt = np.linalg.svd(A); k = int((s > 1e-8 * s.max()).sum()); Cs = [v.reshape(dB, dB) for v in Vt[k:]]
    basis = [np.kron(C, E) for C in Cs for E in np.eye(dF * dF).reshape(dF * dF, dF, dF)]
    rows = np.stack([np.concatenate([(B @ g - g @ B).ravel() for g in GF]) for B in basis], 1)
    _, s2, Vt2 = np.linalg.svd(rows, full_matrices=False); k2 = int((s2 > 1e-8 * s2.max()).sum())
    Xs = [np.tensordot(v, np.array(basis), 1) for v in Vt2[k2:]]                   # the commutant, as matrices
    T = np.array([[np.trace(x @ y) for y in Xs] for x in Xs]); ev = np.linalg.eigvalsh((T + T.T) / 2)
    return len(Xs), len(Cs), int((ev > 1e-6).sum() - (ev < -1e-6).sum())          # dim, dim of the base's commutant, trace-form signature

# ================================================================================================ fb.LR  left and right on Cl(1,3)
head('fb.LR  left and right on the 16 labels of Cl(1,3): L_a, the twisted R\'_b x = (-1)^|x| x e_b (LNS-113), the plain R_b')
t = time.time()
E13, E31 = sig(1, 3), sig(3, 1); A13 = BR(E13)
def Lm(a):
    M = np.zeros((16, 16), dtype=np.int64)
    for x in range(16): M[a ^ x, x] = A13.s(a, x)
    return M
def Rm(b):
    M = np.zeros((16, 16), dtype=np.int64)
    for x in range(16): M[x ^ b, x] = A13.s(x, b)
    return M
def Rtw(j):
    """the twisted right multiplication by e_j (the plain one under --fault NOTWIST)"""
    if FAULT == 'NOTWIST': return Rm(1 << j)
    M = np.zeros((16, 16), dtype=np.int64)
    for x in range(16): M[x ^ (1 << j), x] = (-1) ** pc(x) * A13.s(x, 1 << j)
    return M
GL = [Lm(1 << i) for i in range(4)]; GT = [Rtw(j) for j in range(4)]; GP = [Rm(1 << j) for j in range(4)]
ECAT = E13 + tuple(-e for e in E13)                                       # (1,-1,-1,-1 | -1,1,1,1): Cl(1,3) followed by its mirror
okR = rel_ok(GL, E13) and rel_ok(GT, ECAT[4:]) and all(np.array_equal(l @ r, -(r @ l)) for l in GL for r in GT)
WT = words_int(GL + GT); CT, okw = word_table(WT)
chk('bit', okR, 'fb.LR: the L_i (squares +, -, -, -) and the twisted R\'_j (squares -eps_j = -, +, +, +) are 16 x 16 signed permutation matrices; every L_i anticommutes with every R\'_j: the eight satisfy the relations of the concatenated label eps = (1,-1,-1,-1 | -1,1,1,1)')
chk('bit', okw and np.array_equal(CT, table(ECAT)) and gram_ok(WT) and ltype_eps(ECAT) == clock_type(4, 4) == ('R', 16, 1),
    'fb.LR: their 256 words multiply by the sign table of that label on all 65536 pairs (Cl(1,3) (x)^ Cl(3,1), GEN-010; the reordering is Cl(4,4)) and are trace-orthogonal, tr W_c^T W_d = 16 delta_cd: 256 independent operators, all of End(A) = M16(R) (the label type of the cell: M16(R))')
WP = words_int(GP); CP, okp = word_table(WP); rev = [(-1) ** (pc(b) * (pc(b) - 1) // 2) for b in range(16)]
okP = all(np.array_equal(l @ r, r @ l) for l in GL for r in GP) and okp and np.array_equal(CP, table(E13))
okP &= all(np.array_equal(WP[b], rev[b] * Rm(b)) for b in range(16)) and np.array_equal(np.array([[A13.s(c, b) for c in range(16)] for b in range(16)]), np.array([[rev[b] * rev[c] * rev[b ^ c] * A13.s(b, c) for c in range(16)] for b in range(16)]))
chk('bit', okP, 'fb.LR: the plain R_j commute with every L_i, have the squares eps_j and anticommute: the words R_j1 R_j2 .. of the generators multiply by the table of Cl(1,3); the word of b is the right multiplication by the reversed blade e_b~, and the blades themselves multiply by the transposed table s(b\',b): the opposite algebra, Cl(1,3) again by the reversion')
WLR = [Lm(a) @ WP[b] for b in range(16) for a in range(16)]               # the label a + 16 b: L_a, then the R word of b
CLR, oklr = word_table(WLR); U13 = ungraded_table(E13, E13)
chk('bit', oklr and gram_ok(WLR) and np.array_equal(CLR, U13) and table_type(U13, [1 << i for i in range(8)]) == ('R', 16, 1),
    'fb.LR: the 256 products L_a R_b are trace-orthogonal (End(A) again) and multiply by the ungraded table s(a,a\') s(b,b\') of Cl(1,3) (x) Cl(1,3), whose label type is M16(R): M2(H) (x) M2(H) = M16(R), the commutant pair of the left action')
cA, cO, cM = count(table(E13)), count(CP), count(table(E31)); cG = count(table(ECAT))
U_mir = ungraded_table(E13, E31); tmir = table_type(U_mir, [1 << i for i in range(8)])
okC = (cA, cO, cM, cG) == (-4, -4, 4, 16) and count(U13) == cA * cO == 16 and count(U_mir) == cA * cM == -16 and tmir == ('H', 8, 1)
okC &= type_mul(clock_type(1, 3), clock_type(1, 3)) == ('R', 16, 1) and type_mul(clock_type(3, 1), clock_type(1, 3)) == tmir
chk('bit', okC, 'fb.LR: why the two products have one type though no clock is 0 or 4: the count sum e_a^2 is -4 for Cl(1,3), -4 for its opposite (the same squares) and +4 for its mirror Cl(3,1); an ungraded product multiplies counts, (-4)(-4) = +16 (M16(R), H x H = M4(R)) against GEN-011\'s (3,1) x (1,3) with the mirror, (-4)(+4) = -16 (M8(H)); the graded table has +16: the graded product pairs A with its mirror, the ungraded with its opposite')
WR2 = words_int(GT); CR2, _ = word_table(WR2)
chk('bit', np.array_equal(CR2, table(ECAT[4:])) and ltype_eps(ECAT[4:]) == ('R', 4, 1), 'fb.LR: the words of the twisted R\'_j alone multiply by the table of eps = (-1,1,1,1), the mirror Cl(3,1) = M4(R) in the order (time first): the owner\'s (3,1) is the twisted right action, (1,3) the left')
GPfail = sum(1 for l in GL for r in GP if not np.array_equal(l @ r, -(r @ l))) + sum(1 for j, r in enumerate(GP) if not np.array_equal(r @ r, ECAT[4 + j] * np.eye(16, dtype=np.int64)))
chk('ctl', GPfail == 20 and not rel_ok(GL + GP, ECAT), 'fb.LR: with the plain R_j in place of the twisted R\'_j (NOTWIST) the relations of eps = (1,-1,-1,-1 | -1,1,1,1) fail at %d places: all 16 pairs L_i, R_j commute and the 4 squares are +eps_j' % GPfail)
chk('ctl', tmir != table_type(U13, [1 << i for i in range(8)]), 'fb.LR: the ungraded product with the mirror (GEN-011\'s (3,1) x (1,3)) is %s, not End(A) = M16(R): the opposite, not the mirror, is the ungraded partner' % tstr(tmir))
note('(%.1f s)' % (time.time() - t))
# [std] real 8 x 8 Dirac matrices (realified), A = the span of their 16 words in M8(R); L_X Y = X Y, R_X Y = Y X, R'_X Y = P Y P^-1 X (P the product
# of the four matrices: P Y P^-1 = (-1)^deg Y on A), as operators on A in the basis of the words; no label, no sign formula
t = time.time()
PS = GAM[0] @ GAM[1] @ GAM[2] @ GAM[3]; WG = fwords(GAM)                               # the basis of A (orthogonal, norm^2 8)
def onA(f): return np.array([[float(np.sum(WG[a2] * f(WG[a]))) / 8 for a in range(16)] for a2 in range(16)])
SL = [onA(lambda Y, g=g: g @ Y) for g in GAM]; SP = [onA(lambda Y, g=g: Y @ g) for g in GAM]
ST = SP if FAULT == 'NOTWIST' else [onA(lambda Y, g=g: PS @ Y @ np.linalg.inv(PS) @ g) for g in GAM]
WS = fwords(SL + ST); CS, okint = mat_table(WS); WSP = np.array([SL_ @ SP_ for SP_ in fwords(SP) for SL_ in fwords(SL)])
okstd = frel_ok(SL + ST, ECAT) and int(np.linalg.matrix_rank(WS.reshape(256, -1))) == 256 and all(np.allclose(l @ r, r @ l) for l in SL for r in SP)
okstd &= int(np.linalg.matrix_rank(WSP.reshape(256, -1))) == 256 and mat_type(SL + ST) == ('R', 16, 1)
CSP, okint2 = mat_table(WSP)
chk('std', okstd, 'fb.LR: numpy, no label: with the realified Dirac matrices (squares +, -, -, -), left multiplication and the right multiplication twisted by the conjugation with P = g0 g1 g2 g3 satisfy the relations of eps = (1,-1,-1,-1 | -1,1,1,1) on the 16-dimensional algebra they span, their 256 words have rank 256 and the trace form gives M16(R); the plain right multiplications commute with the left ones and with them also reach rank 256')
chk('bit==std', okint and okint2 and np.array_equal(CS, table(ECAT)) and np.array_equal(CSP, U13), 'fb.LR: the sign tables read from the matrices equal the label tables: the twisted pair gives the concatenated label of Cl(1,3) (x)^ Cl(3,1) on all 65536 entries, the plain pair the ungraded Cl(1,3) (x) Cl(1,3)')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fb.OCT  the fibre: Cl(0,6) = End(O)
head('fb.OCT  the fibre: Cl(0,6) = M8(R) on the labels and as the left multiplications by six octonion units (Furey\'s Cl(6) over R)')
t = time.time()
E06, E60 = sig(0, 6), sig(6, 0); L06 = lab_graded(E06); G06 = comm_labels(L06); I06 = Ideal(L06, G06)
RO = [I06.act(1 << i) for i in range(6)]; cbO = commutant_basis(RO, I06.m)
chk('bit', ltype_eps(E06) == clock_type(0, 6) == ('R', 8, 1) and count(table(E06)) == 8 and len(G06) == 3 and I06.m == 8 and rel_ok(RO, E06)
    and centraliser_div(L06, G06) == (1, 'R') and len(cbO) == 1,
    'fb.OCT: Cl(0,6) on its 64 labels: centre R, count +8, M8(R) (clock 2); three commuting labels of square +1 give f with scalar part 1/8, a minimal left ideal of dimension 8 with f A f = R, on which the six generators act as signed permutations with commutant R')
WO = fwords(OLM); CO, okO = mat_table(WO); PO = np.eye(8)
for L_ in OLM: PO = PO @ L_
SIG = 1 if np.allclose(PO, LE7) else (-1 if np.allclose(PO, -LE7) else 0)
chk('std', frel_ok(OLM, E06) and int(np.linalg.matrix_rank(WO.reshape(64, -1))) == 64 and mat_type(OLM) == ('R', 8, 1),
    'fb.OCT: numpy, the octonions of reports/furey/model.py: the left multiplications L_u by the six units other than k = e7 (model order i, j, l, li, lj, lk) anticommute and square to -1, and their 64 words have rank 64: they generate all of End(O) = M8(R)')
A_ = np.vstack([np.kron(OLM[i], np.eye(8)) - np.kron(np.eye(8), RO[i].T.astype(float)) for i in range(6)])   # L_u T = T rho(e_i)
_, s_, Vt_ = np.linalg.svd(A_); Tm = Vt_[-1].reshape(8, 8); nT = null_dim(A_)
chk('bit==std', okO and np.array_equal(CO, table(E06).astype(np.int64)) and nT == 1 and abs(np.linalg.det(Tm)) > 1e-6
    and np.allclose(Tm @ (RO[0] @ RO[1] @ RO[2] @ RO[3] @ RO[4] @ RO[5]) @ np.linalg.inv(Tm), PO),
    'fb.OCT: the sign table read from the six L_u equals the label table of Cl(0,6) on all 4096 entries, and the intertwiners T with L_u T = T rho(e_i) form a line of invertible maps: the bit rule\'s minimal ideal of Cl(0,6) is O, its omega6 = e0 .. e5 going to L_u1 .. L_u6')
chk('std', SIG != 0 and all(np.allclose(L_ @ LE7, -(LE7 @ L_)) for L_ in OLM), 'fb.OCT: the product L_u1 L_u2 .. L_u6 of the six (model order) is %sL_e7 (sigma = %+d): the fibre\'s pseudoscalar omega6 acts on O as %sFurey\'s omega = L_e7 (FUR-001); each L_u anticommutes with L_e7' % ('+' if SIG == 1 else '-', SIG, '' if SIG == 1 else 'minus '))
UC = ungraded_table(E06, sig(0, 1)); tC = table_type(UC, [1 << i for i in range(7)])
chk('bit', tC == ('C', 8, 1) == type_mul(clock_type(0, 6), clock_type(0, 1)), 'fb.OCT: C (x) Cl(0,6), the ungraded product with Cl(0,1) = C, has the label type %s (centre C, count 0): the type of FUR-001\'s End_C(V); not the same subalgebra of End(V), since the six L_u anticommute with omega = L_e7' % tstr(tC))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fb.TY  the four cells beside the fibre
head('fb.TY  the spacetime cell beside the fibre: Cl(1,3) or Cl(3,1) with Cl(0,6) or Cl(6,0), graded against ungraded')
t = time.time()
PAIRS = [((1, 3), (0, 6)), ((3, 1), (0, 6)), ((1, 3), (6, 0)), ((3, 1), (6, 0))]
TG, TU, MG, MU = [], [], [], []
for cb_, cf_ in PAIRS:
    eb, ef = sig(*cb_), sig(*cf_); tg = ltype_eps(eb + ef); tu = table_type(ungraded_table(eb, ef), [1 << i for i in range(10)])
    TG.append(tg); TU.append(tu)
    for L_, Ms, gr_ in ((lab_graded(eb + ef), MG, True), (lab_ungraded(eb, ef), MU, False)):
        G_ = comm_labels(L_, tries=12); I_ = Ideal(L_, G_); d_, D_ = centraliser_div(L_, G_)
        rho_ = [I_.act(1 << i) for i in range(10)]; okr_ = rel_ok(rho_, eb + ef) if gr_ else urel_ok(rho_, eb, ef)
        cb_t = basis_type(commutant_basis(rho_, I_.m))
        Ms.append((I_.m, D_, len(G_)) if okr_ and cb_t == (D_, 1, 1) else (None, None, None))
okG = TG == [clock_type(cb_[0] + cf_[0], cb_[1] + cf_[1]) for cb_, cf_ in PAIRS] == [('R', 32, 1), ('H', 16, 1), ('H', 16, 1), ('R', 32, 1)]
okU = TU == [type_mul(clock_type(*cb_), clock_type(*cf_)) for cb_, cf_ in PAIRS] == [('H', 16, 1), ('R', 32, 1), ('R', 32, 1), ('H', 16, 1)]
chk('bit', okG, 'fb.TY: graded, from the concatenated labels (centre, squares, count): Cl(1,3) (x)^ Cl(0,6) = Cl(1,9) = %s, Cl(3,1) (x)^ Cl(0,6) = Cl(3,7) = %s, Cl(1,3) (x)^ Cl(6,0) = Cl(7,3) = %s, Cl(3,1) (x)^ Cl(6,0) = Cl(9,1) = %s, the types of the sum cells by core_check.TYPE' % tuple(map(tstr, TG)))
chk('bit', okU, 'fb.TY: ungraded, from the tables s1 s2 without the cross sign: M2(H) (x) M8(R) = %s, M4(R) (x) M8(R) = %s, M2(H) (x) M4(H) = %s, M4(R) (x) M4(H) = %s, as GEN-011\'s multiplication table gives them' % tuple(map(tstr, TU)))
clk = [((cb_[0] - cb_[1]) % 8, (cf_[0] - cf_[1]) % 8) for cb_, cf_ in PAIRS]
chk('bit', all(a != b for a, b in zip(TG, TU)) and all(x % 4 and y % 4 for x, y in clk), 'fb.TY: the two products exchange their types in all four cases (R <-> H); the factor clocks are %s, none 0 or 4: GEN-011\'s condition for equal types fails in each' % clk)
WHH = [type_mul(clock_type(*cb_), clock_type(*cf_), hh=True) for cb_, cf_ in PAIRS]
chk('ctl', [w != u for w, u in zip(WHH, TU)] == [False, False, True, False], 'fb.TY: with H x H = H in the multiplication table (HH) the ungraded M2(H) (x) M4(H) would be %s, against %s on the labels: the Brauer relation H x H = M4(R) is what the labels need' % (tstr(WHH[2]), tstr(TU[2])))
okM = [m_[:2] for m_ in MG] == [(32, 'R'), (64, 'H'), (64, 'H'), (32, 'R')] and [m_[:2] for m_ in MU] == [(64, 'H'), (32, 'R'), (32, 'R'), (64, 'H')]
chk('bit', okM, 'fb.TY: the irreducible modules from primitive idempotents f = prod (1 + e_u)/2 over commuting labels of square +1 (rank of f = 1024 / 2^k, f A f a division algebra; the ten generators on A f obey the relations of the product, and the exact commutant of the module is f A f): graded %s, ungraded %s; for the owner\'s pair Cl(1,3), Cl(0,6): 32 graded (f A f = R) against 64 ungraded (f A f = H, H^16)'
    % (', '.join('%d (k = %d, %s)' % (m_[0], m_[2], m_[1]) for m_ in MG), ', '.join('%d (k = %d, %s)' % (m_[0], m_[2], m_[1]) for m_ in MU)))
note('(%.1f s)' % (time.time() - t))
t = time.time()
def graded_mod(G):
    """a graded module of a base cell from one without a grading operator: the generators G x X with the grading 1 x Z"""
    return [np.kron(g, XM) for g in G], np.kron(np.eye(G[0].shape[0]), ZM)
BASE = {(1, 3): (GAM, GAM5), (3, 1): graded_mod(G31)}; FIB = {(0, 6): OLM, (6, 0): G60}; UB = {(1, 3): GAM, (3, 1): G31}
MTG, MTU = [], []
for cb_, cf_ in PAIRS:
    (Gb, Gam_b), Gf = BASE[cb_], FIB[cf_]; dB, dF = Gb[0].shape[0], Gf[0].shape[0]
    MTG.append(mat_type([np.kron(g, np.eye(dF)) for g in Gb] + [np.kron(Gam_b, g) for g in Gf]))
    Gu = UB[cb_]; MTU.append(mat_type([np.kron(g, np.eye(dF)) for g in Gu] + [np.kron(np.eye(Gu[0].shape[0]), g) for g in Gf]))
chk('std', all(x is not None for x in MTG + MTU), 'fb.TY: numpy, no label: the eight products as real Kronecker matrices (graded (g x 1, Gamma_B x g\'), Gamma_B = gamma5 on the Dirac module or 1 x Z on a doubled one; ungraded (g x 1, 1 x g\')), types from the trace form, the centre and a random central element: graded %s, ungraded %s' % (', '.join(map(tstr, MTG)), ', '.join(map(tstr, MTU))))
chk('bit==std', MTG == TG and MTU == TU, 'fb.TY: the matrix types equal the label types for all four graded and all four ungraded products')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fb.MOD  Dirac spinor times octonion
head('fb.MOD  the modules: the Dirac spinor S = Cl(1,3)(1 + e0)/2, its gradings, and S (x) O under the two products')
t = time.time()
L13 = lab_graded(E13); IS = Ideal(L13, [1])                                # f = (1 + e0)/2, e0 of square +1 (time)
RS = [IS.act(1 << i) for i in range(4)]; cbS = commutant_basis(RS, IS.m); I8i = np.eye(8, dtype=np.int64)
RQ = {x: IS.ract(x) for x in (6, 10, 12)}                                 # right multiplication by e1e2, e1e3, e2e3 (they commute with e0)
okS = IS.m == 8 and rel_ok(RS, E13) and len(cbS) == 4 and basis_type(cbS) == ('H', 1, 1)
okS &= all(np.array_equal(R @ r, r @ R) for R in RQ.values() for r in RS) and all(np.array_equal(R @ R, -I8i) for R in RQ.values())
okS &= all(np.array_equal(RQ[x] @ RQ[y], -(RQ[y] @ RQ[x])) for x in RQ for y in RQ if x < y) and gram_ok([I8i] + list(RQ.values()))
okS &= len({IS.rep[a][0] for a in range(16) if pc(a) % 2 == 0}) == 8                 # psi -> psi f sends the 8 even blades to 8 basis lines
chk('bit', okS, 'fb.MOD: S = Cl(1,3) f, f = (1 + e0)/2, has dimension 8; the four generators act as signed permutations with exact commutant H, spanned by 1 and the right multiplications by e1e2, e1e3, e2e3 (squares -1, anticommuting): f A f = H; psi -> psi f sends the 8 even blades to the 8 basis lines, so the even psi of the coupling step is S as a module of the even part')
QB = [I8i] + [RQ[x] for x in (6, 10, 12)]; ENDS = [IS.act(a) @ Q for a in range(16) for Q in QB]     # End(S): rho(e_a) R_x
rows = []
for r in RS:
    AC = [X @ r + r @ X for X in ENDS]
    rows += [[int(AC[k][i_, j_]) for k in range(64)] for i_ in range(8) for j_ in range(8)]
NS = nullspace_frac(rows, 64); supp = sorted({k // 4 for v in NS for k in range(64) if v[k] != 0})
PI_S = IS.act(15); EB = [PI_S @ Q for Q in QB]                            # rho(I) R_x, x = 1, e1e2, e1e3, e2e3
AT = [[EB[x] @ EB[y] + EB[y] @ EB[x] for y in range(4)] for x in range(4)]
okQ = gram_ok(ENDS) and len(NS) == 4 and supp == [15] and np.array_equal(AT[0][0], -2 * I8i) and all(np.array_equal(AT[v][v], 2 * I8i) for v in (1, 2, 3))
okQ &= all(np.array_equal(AT[v][w], 0 * I8i) for v in (1, 2, 3) for w in (1, 2, 3) if v != w) and all(np.array_equal(AT[0][v], -2 * QB[v]) for v in (1, 2, 3))
chk('bit', okQ, 'fb.MOD: in End(S) = M8(R) (the 64 independent products rho(e_a) R_x) the elements anticommuting with the four generators form a space of dimension 4, all on the pseudoscalar: eps = rho(I) R_x, I = e0e1e2e3, x in H; eps^2 = (|v|^2 - x0^2) - 2 x0 R_v for x = x0 + v, so eps is a grading (eps^2 = 1) exactly for x a unit imaginary quaternion: an S^2 of gradings, each a choice of complex structure')
EPSJ = PI_S if FAULT == 'NOJ' else PI_S @ (-RQ[6])                        # eps = I J, J = gamma2 gamma1 = -e1e2 acting on the right (the Atlas's J)
BIV_S = [IS.act((1 << i) | (1 << j)) for i in range(4) for j in range(i + 1, 4)]
chk('bit', np.array_equal(EPSJ @ EPSJ, I8i) and all(np.array_equal(EPSJ @ r, -(r @ EPSJ)) for r in RS) and all(np.array_equal(EPSJ @ b, b @ EPSJ) for b in BIV_S),
    'fb.MOD: with the Atlas\'s J = gamma2 gamma1 on the right (shifted_dirac.py), eps = I psi J squares to +1, anticommutes with the four generators and commutes with the six bivectors: the grading used below')
NOJm = [np.kron(r, I8i) for r in RS] + [np.kron(PI_S, o) for o in RO]
chk('ctl', np.array_equal(PI_S @ PI_S, -I8i) and rel_ok(NOJm, E13 + E60) and not rel_ok(NOJm, sig(1, 9)), 'fb.MOD: without J, eps = I alone squares to -1: the pseudoscalar is not a grading of S (NOJ); used as the twist it gives the six fibre operators I x b the square +1: (a x 1, I x b) is a module of Cl(1,3) (x)^ Cl(6,0) = Cl(7,3), not of Cl(1,9)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
I8f = np.eye(8)
Ab = [np.vstack([np.kron(g, I8f) - np.kron(I8f, g.T) for g in GAM])][0]; _, s_, Vt_ = np.linalg.svd(Ab); CG = [v.reshape(8, 8) for v in Vt_[int((s_ > 1e-8).sum()):]]
TG_ = np.array([[np.trace(x @ y) for y in CG] for x in CG]); evg = np.linalg.eigvalsh((TG_ + TG_.T) / 2); sgG = int((evg > 1e-6).sum() - (evg < -1e-6).sum())
Aa = np.vstack([np.kron(g, I8f) + np.kron(I8f, g.T) for g in GAM]); na = null_dim(Aa); _, s2_, Vt2_ = np.linalg.svd(Aa); AN = Vt2_[int((s2_ > 1e-8).sum()):]
inPC = np.linalg.matrix_rank(np.vstack([AN] + [(PS @ C).reshape(1, 64) for C in CG])) == 4
gam5ok = np.allclose(GAM5 @ GAM5, I8f) and all(np.allclose(GAM5 @ g, -(g @ GAM5)) for g in GAM) and np.linalg.matrix_rank(np.vstack([AN, GAM5.reshape(1, 64)])) == 4
chk('std', len(CG) == 4 and sgG == -2 and na == 4 and inPC and gam5ok, 'fb.MOD: numpy, the realified Dirac matrices on R^8: the commutant has dimension 4 and trace-form signature -2 (H); the matrices anticommuting with the four form a space of dimension 4, P times the commutant (P = g0 g1 g2 g3); gamma5 = i g0 g1 g2 g3 lies in it and squares to +1')
Ah = np.vstack([np.kron(GAM[i], I8f) - np.kron(I8f, RS[i].T.astype(float)) for i in range(4)]); nh = null_dim(Ah)
_, s3_, Vt3_ = np.linalg.svd(Ah); Th = np.tensordot(NPR.standard_normal(nh), Vt3_[-nh:], 1).reshape(8, 8); EJs = Th @ EPSJ @ np.linalg.inv(Th)
chk('bit==std', nh == 4 and abs(np.linalg.det(Th)) > 1e-6 and np.allclose(EJs @ EJs, I8f) and all(np.allclose(EJs @ g, -(g @ EJs)) for g in GAM),
    'fb.MOD: the maps T with Gamma_mu T = T rho(e_mu) from the labels\' S to the Dirac R^8 form a space of dimension 4 (H), a generic one invertible; it carries eps = I psi J to a grading of the Dirac matrices (square +1, anticommuting with all four)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
E19 = sig(1, 9); EPSM = I8i if FAULT == 'UNGRADED' else EPSJ
UNG = [np.kron(r, I8i) for r in RS] + [np.kron(I8i, o) for o in RO]       # (a x 1, 1 x b): the ungraded product on S (x) O
GRD = [np.kron(r, I8i) for r in RS] + [np.kron(EPSM, o) for o in RO]      # (a x 1, eps x b): the graded product
WU = words_int(UNG); WGd = words_int(GRD)
cU = commutant_basis(UNG, 64); cG = commutant_basis(GRD, 64); tU, tGd = basis_type(cU), basis_type(cG)
chk('bit', urel_ok(UNG, E13, E06) and gram_ok(WU) and len(cU) == 4 and tU == ('H', 1, 1),
    'fb.MOD: S (x) O (dimension 64) with a x 1 and 1 x b: the relations of the ungraded product (cross pairs commuting), 1024 trace-orthogonal words (M2(H) (x) M8(R), dimension 1024) and the exact commutant H: one irreducible module, H^16 of M16(H)')
trz = all(int(np.trace(W_)) == 0 for W_ in WGd[1:])
chk('bit', rel_ok(GRD, E19) and gram_ok(WGd) and trz and len(cG) == 4 and tGd == ('R', 2, 1),
    'fb.MOD: S (x) O with a x 1 and eps x b: the ten satisfy the relations of Cl(1,9) (the 24 cross pairs anticommute), the 1024 words are trace-orthogonal and all but the identity traceless, the exact commutant is M2(R): two copies of the 32-dimensional irreducible of Cl(1,9) = M32(R)')
ncross = sum(1 for i in range(4) for j in range(4, 10) if not np.array_equal(UNG[i] @ UNG[j], -(UNG[j] @ UNG[i])))
chk('ctl', ncross == 24 and not rel_ok(UNG, E19) and tU != tGd, 'fb.MOD: with the twist eps dropped (UNGRADED) the relations of Cl(1,9) fail at the %d cross pairs (they commute) and the module is one irreducible of dimension 64 (commutant %s), not two 32' % (ncross, tstr(tU)))
note('(%.1f s)' % (time.time() - t))
t = time.time()
EPS_STD = np.eye(8) if FAULT == 'UNGRADED' else (PS if FAULT == 'NOJ' else GAM5)
GRDs = [np.kron(g, I8f) for g in GAM] + [np.kron(EPS_STD, L_) for L_ in OLM]; UNGs = [np.kron(g, I8f) for g in GAM] + [np.kron(I8f, L_) for L_ in OLM]
cg_np, cu_np = commutant_np(GAM, GRDs[4:], 8, 8), commutant_np(GAM, UNGs[4:], 8, 8)
chk('std', frel_ok(GRDs, E19) and cg_np == (4, 4, 2) and cu_np == (4, 4, -2), 'fb.MOD: numpy on R^8 (x) R^8: (g x 1, gamma5 x L_u) satisfy the relations of Cl(1,9) and their commutant has dimension 4 and trace-form signature +2 (M2(R)); (g x 1, 1 x L_u) have a commutant of dimension 4 and signature -2 (H) (null spaces, the base\'s commutant first)')
chk('bit==std', (tGd, tU) == (('R', 2, 1), ('H', 1, 1)) and cg_np[2] == 2 and cu_np[2] == -2, 'fb.MOD: the commutants agree: M2(R) for the graded action (two copies of the 32), H for the ungraded (one 64), on the labels and on the matrices')
def prodm(ms):
    P_ = np.eye(ms[0].shape[0], dtype=ms[0].dtype)
    for m_ in ms: P_ = P_ @ m_
    return P_
def half(Gm, ops, sgn=1):
    """signed permutations ops commuting with the signed permutation Gm (Gm^2 = 1, no fixed basis line) on the eigenspace Gm = sgn, in the
    basis e_r + sgn Gm e_r over one representative r of each pair {r, Gm r}: signed permutations again"""
    m = Gm.shape[0]; img = [int(np.flatnonzero(Gm[:, c])[0]) for c in range(m)]; sg = [int(Gm[img[c], c]) for c in range(m)]
    assert all(img[c] != c for c in range(m)); reps = []; seen = set()
    for c in range(m):
        if c not in seen: reps.append(c); seen |= {c, img[c]}
    ri = {r: i for i, r in enumerate(reps)}; out = []
    for X in ops:
        assert np.array_equal(X @ Gm, Gm @ X)
        H = np.zeros((len(reps), len(reps)), dtype=np.int64)
        for i, r in enumerate(reps):
            c = int(np.flatnonzero(X[:, r])[0]); s = int(X[c, r])
            if c in ri: H[ri[c], i] = s
            else: rr = img[c]; H[ri[rr], i] = s * sgn * sg[rr]
        out.append(H)
    return out
I64 = np.eye(64, dtype=np.int64); OM6 = prodm(RO); GAMg, GAMu = prodm(GRD), prodm(UNG)
okGam = np.array_equal(GAMg, GAMu) and np.array_equal(GAMg, np.kron(PI_S, OM6)) and np.array_equal(GAMg @ GAMg, I64)
okGam &= all(np.array_equal(GAMg @ X, -(X @ GAMg)) for X in GRD + UNG)
BIVg = [GRD[i] @ GRD[j] for i in range(10) for j in range(i + 1, 10) if (i < 4) == (j < 4)]; BIVu = [UNG[i] @ UNG[j] for i in range(10) for j in range(i + 1, 10) if (i < 4) == (j < 4)]
okGam &= all(np.array_equal(x, y) for x, y in zip(BIVg, BIVu)) and len(BIVg) == 21
chk('bit', okGam, 'fb.MOD: on S (x) O the two products share the volume element: the product of the ten operators is rho(I) x omega6 in both (eps^6 = 1), it squares to +1 and anticommutes with all ten; the 6 + 15 bivectors of base and fibre are the same 21 matrices in both products')
EVg = half(GAMg, [GRD[0] @ X for X in GRD[1:]]); EVu = half(GAMu, [UNG[0] @ X for X in UNG[1:]])
thg, thu = basis_type(commutant_basis(EVg, 32)), basis_type(commutant_basis(EVu, 32))
SPg = half(GAMg, BIVg); tsp = basis_type(commutant_basis(SPg, 32))
chk('bit', (thg, thu) == (('R', 2, 1), ('H', 1, 1)) and tsp == ('C', 2, 1), 'fb.MOD: what dropping the twist does to the halves: on the half Gamma = +1 (dimension 32) the even part (generated by X_0 X_k) has commutant %s in the graded module (two copies of a real 16) and %s in the ungraded (one quaternionic 32, the halves of M16(H) are H^8); the 21 bivectors alone have commutant %s on it in both' % (tstr(thg), tstr(thu), tstr(tsp)))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fb.CHI  left and right on the total cell
head('fb.CHI  left and right on the total cell Cl(1,9): the volume element, the two halves, and the two complex structures I and omega6')
t = time.time()
L19 = lab_graded(E19); TOP = (1 << 10) - 1; BI, BW = 15, TOP ^ 15                # I = e0e1e2e3 (bits 0-3), omega6 = e4..e9 (bits 4-9)
G19 = comm_labels(L19, first=(TOP,), even=True); I19 = Ideal(L19, G19); R19 = [I19.act(1 << i) for i in range(10)]
GM19 = I19.act(TOP); IM19, WM19 = I19.act(BI), I19.act(BW)
bivB = [(1 << i) | (1 << j) for i in range(4) for j in range(i + 1, 4)]; bivF = [(1 << i) | (1 << j) for i in range(4, 10) for j in range(i + 1, 10)]
biv45 = [(1 << i) | (1 << j) for i in range(10) for j in range(i + 1, 10)]
okV = L19.sq(TOP) == 1 and all(not L19.commute(TOP, 1 << i) for i in range(10)) and all(L19.commute(TOP, b) for b in biv45)
dg = np.diag(GM19); okV &= I19.m == 32 and len(G19) == 5 and np.array_equal(GM19, np.diag(dg)) and int((dg == 1).sum()) == 16 == int((dg == -1).sum())
chk('bit', okV, 'fb.CHI: in Cl(1,9) = M32(R) the volume element Gamma = e0..e9 squares to +1, anticommutes with the ten generators and commutes with the 45 bivectors; with Gamma among five commuting even labels of square +1 the minimal ideal (dimension 32) has Gamma diagonal: (1 + Gamma)/2 and (1 - Gamma)/2 have rank 16 each')
Pp = [i for i in range(32) if dg[i] == 1]; Pm = [i for i in range(32) if dg[i] == -1]
EV19 = [R19[0] @ R19[k] for k in range(1, 10)]
cp, cm_ = commutant_basis([X[np.ix_(Pp, Pp)] for X in EV19], 16), commutant_basis([X[np.ix_(Pm, Pm)] for X in EV19], 16)
c32 = commutant_basis(EV19, 32)
chk('bit', basis_type(cp) == basis_type(cm_) == ('R', 1, 1) and basis_type(c32) == ('R', 1, 2), 'fb.CHI: the even part (generated by e0 e_k) acts on each half with commutant R (an absolutely irreducible real 16: Majorana-Weyl) and on the 32 with commutant R + R: the two halves are inequivalent')
sIW = -L19.s(BI, BW) if FAULT == 'WRONGSIGN' else L19.s(BI, BW)              # Gamma = sIW I omega6 (asserted with the other sign under WRONGSIGN)
okS = sIW == 1 and L19.sq(BI) == -1 and L19.sq(BW) == -1 and L19.commute(BI, BW) and all(L19.commute(x, b) for x in (BI, BW) for b in bivB + bivF)
chk('bit', okS, 'fb.CHI: Gamma = %+d I omega6 in the canonical order (every fibre bit lies above every base bit: no reordering); I^2 = omega6^2 = -1, and I, omega6 commute with each other and with the 6 + 15 bivectors so(1,3) + so(6)' % sIW)
okH = np.array_equal((IM19 + sIW * WM19)[np.ix_(Pp, Pp)], 0 * np.eye(16, dtype=np.int64)) and np.array_equal((IM19 - sIW * WM19)[np.ix_(Pm, Pm)], 0 * np.eye(16, dtype=np.int64))
chk('bit', okH, 'fb.CHI: so on the half Gamma = +1 the complex structure of spacetime is minus that of the fibre, I = -omega6, and on the half Gamma = -1 I = +omega6: the chirality of the total cell is the relative sign of the two complex structures')
SPp = [I19.act(b)[np.ix_(Pp, Pp)] for b in bivB + bivF]; tB = basis_type(commutant_basis([I19.act(b)[np.ix_(Pp, Pp)] for b in bivB], 16))
tF = basis_type(commutant_basis([I19.act(b)[np.ix_(Pp, Pp)] for b in bivF], 16)); tBF = basis_type(commutant_basis(SPp, 16))
t32 = basis_type(commutant_basis([I19.act(b) for b in bivB + bivF], 32))
chk('bit', (tB, tF, tBF, t32) == (('C', 4, 1), ('C', 2, 1), ('C', 1, 1), ('C', 1, 2)), 'fb.CHI: with I as complex structure each half is a complex 8: so(1,3) alone has commutant %s on it (four copies of a complex 2), so(6) alone %s (two copies of a complex 4), both together %s (irreducible: 2 x 4); on the 32 the commutant is %s: the halves are inequivalent under so(1,3) + so(6) as well' % (tstr(tB), tstr(tF), tstr(tBF), tstr(t32)))
dual = {3: (12, 1), 5: (10, -1), 9: (6, 1)}                               # boost e0e_k and its rotation R_k: e2e3, e3e1 = -e1e3, e1e2 (cyclic)
sgD = {k: sv * L19.s(BI, v) for k, (v, sv) in dual.items()}               # I R_k = sgD e0e_k, so e0e_k = sgD I R_k
cpo = basis_type(commutant_basis([RO[i] @ RO[j] for i in range(6) for j in range(i + 1, 6)], 8)); sB = sgD[3]
chk('bit', all(BI ^ v == k for k, (v, sv) in dual.items()) and len(set(sgD.values())) == 1 and cpo == ('C', 1, 1), 'fb.CHI: the base relation, one sign for all three and an identity of the algebra, so the same on both halves: e0e_k = %sI R_k with R_k = e2e3, e3e1, e1e2 (a boost is %sI times its rotation: one complex type of so(1,3) w.r.t. I); the fibre\'s so(6) on O has commutant C = span{1, omega6}, so (O, omega6) is a complex 4 not isomorphic to its conjugate: w.r.t. I the halves carry the 4-bar and the 4 (omega6 = -I and +I), (2, 4bar) on Gamma = +1 and (2, 4) on Gamma = -1' % ('' if sB == 1 else '-', '' if sB == 1 else '-'))
chk('ctl', L19.s(BI, BW) != -1 and not np.array_equal((IM19 - WM19)[np.ix_(Pp, Pp)], 0 * np.eye(16, dtype=np.int64)), 'fb.CHI: the other sign, Gamma = -I omega6 (WRONGSIGN), is false on the labels: the reordering sign of I omega6 is +1, and I = +omega6 fails on the half Gamma = +1')
note('(%.1f s)' % (time.time() - t))
t = time.time()
GAs = prodm(GRDs); Is_ = np.kron(PS, I8f); Ws_ = prodm(GRDs[4:]); Ip = (np.eye(64) + GAs) / 2
w_, V_ = np.linalg.eig(Is_ + 0.5 * Ws_)                                   # the joint eigenvalues of the commuting I and omega6
pairs_ = sorted({(round(float(np.imag(z)), 3)) for z in w_})
okst = np.allclose(GAs @ GAs, np.eye(64)) and np.linalg.matrix_rank(Ip) == 32 and np.allclose(Ws_, np.kron(np.eye(8), SIG * LE7)) and np.allclose((Is_ + sIW * Ws_) @ Ip, 0) and np.allclose(GAs, sIW * Is_ @ Ws_)
okst &= np.allclose((Is_ - sIW * Ws_) @ (np.eye(64) - Ip), 0)
chk('std', okst and pairs_ == [-1.5, -0.5, 0.5, 1.5], 'fb.CHI: numpy on the graded S (x) O: Gamma (the product of the ten matrices) squares to 1 with rank-32 halves, Gamma = I omega6 with I = P x 1 and omega6 = 1 x %sL_e7 (Furey\'s omega), and I + omega6 vanishes on Gamma = +1; the joint eigenvalues of (I, omega6) are (+-i, -+i) on Gamma = +1 and (+-i, +-i) on Gamma = -1' % ('' if SIG == 1 else '-'))
chk('bit==std', SIG == 1 and sIW == 1, 'fb.CHI: on the labels and on the matrices the same sign: on Gamma = +1, I = -omega6 = -L_e7 on the fibre (sigma = +1 from fb.OCT), on Gamma = -1, I = +L_e7')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fb.COL  so(6) = su(4) on O; colour su(3)
head('fb.COL  the fibre\'s so(6) on O with omega6: a complex 4 of su(4); the stabiliser of one unit is the colour su(3), 4 = 3 + 1')
t = time.time()
BO = [(i, j) for i in range(6) for j in range(i + 1, 6)]; XO = [RO[i] @ RO[j] for i, j in BO]             # the 15 bivectors on the ideal
k0 = int(np.flatnonzero(OM6[:, 0])[0]); Widx = [i for i in range(8) if i not in (0, k0)]                 # v0 = f (basis 0), omega6 v0 = +-e_k0
NSt = nullspace_frac([[int(X[k, 0]) for X in XO] for k in range(8)], 15)                                 # X v0 = 0
den = lambda v: int(np.lcm.reduce([x.denominator for x in v]))
STB = [sum(int(x * den(v)) * XO[i] for i, x in enumerate(v)) for v in NSt]                               # integer generators of the stabiliser
okc = len(NSt) == 8 and all(np.array_equal(X @ OM6, OM6 @ X) for X in STB) and all(int(X[k, k0]) == 0 for X in STB for k in range(8))
brk = [X @ Y - Y @ X for X in STB for Y in STB]
okc &= rank_frac([X.ravel().tolist() for X in STB]) == 8 == rank_frac([X.ravel().tolist() for X in STB + brk])
STW = [X[np.ix_(Widx, Widx)] for X in STB]
CW = nullspace_frac([[int((Y_ @ X - X @ Y_)[a, b]) for Y_ in [np.eye(6, dtype=np.int64)[[r]].T @ np.eye(6, dtype=np.int64)[[s]] for r in range(6) for s in range(6)]] for X in STW for a in range(6) for b in range(6)], 36)
OW = OM6[np.ix_(Widx, Widx)]
chk('bit', basis_type(commutant_basis(XO, 8)) == ('C', 1, 1), 'fb.COL: on the ideal of Cl(0,6) (O of the labels) the 15 bivectors so(6) have commutant C = span{1, omega6}: with omega6 as complex structure O is an irreducible complex 4 of so(6) = su(4), and no element of the commutant anticommutes with omega6: the 4 is not its conjugate')
chk('bit', okc and len(CW) == 2 and np.array_equal(OW @ OW, -np.eye(6, dtype=np.int64)), 'fb.COL: the elements of so(6) killing one basis vector v0 of the ideal form a Lie algebra of dimension 8 (closed under the bracket) that also kills omega6 v0 and acts on the other six basis vectors with commutant of dimension 2 (1 and omega6, of square -1): an irreducible complex 3, trivial on the complex line of v0: su(3) in su(4), 4 = 3 + 1')
note('(%.1f s)' % (time.time() - t))
t = time.time()
XOs = [OLM[i] @ OLM[j] for i, j in BO]; e0 = np.eye(8)[:, 0]; e7 = np.eye(8)[:, 3]
Ast = np.stack([X @ e0 for X in XOs], 1); _, sa, Va = np.linalg.svd(Ast); STs = [np.tensordot(v, np.array(XOs), 1) for v in Va[int((sa > 1e-9).sum()):]]
CC = np.array([[OM.omul(OM.E[a], OM.E[b]) for b in range(8)] for a in range(8)])                          # e_a e_b = sum_c CC[a,b,c] e_c
rowsD = []
for a in range(8):
    for b in range(8):
        for kk in range(8):                                   # (D(e_a e_b))_k - (D e_a e_b)_k - (e_a D e_b)_k = 0, D[i,j] the unknowns (D e_j = sum_i D[i,j] e_i)
            r_ = np.zeros((8, 8))
            for c in range(8): r_[kk, c] += CC[a, b, c]
            for i in range(8): r_[i, a] -= CC[i, b, kk]; r_[i, b] -= CC[a, i, kk]
            rowsD.append(r_.ravel())
AD = np.array(rowsD); nG2 = null_dim(AD); AD7 = np.vstack([AD] + [np.eye(64)[8 * i + 3] for i in range(8)]); nSU3 = null_dim(AD7)
_, sd, Vd = np.linalg.svd(AD7); DER = [v.reshape(8, 8) for v in Vd[64 - nSU3:]]
same = np.linalg.matrix_rank(np.array([x.ravel() for x in STs + DER]), tol=1e-8) == 8
P1, P2 = (np.eye(8) - LE7 @ RE7) / 2, (np.eye(8) + LE7 @ RE7) / 2
blocks = int(round(np.trace(P1))) == 2 and int(round(np.trace(P2))) == 6 and np.allclose(P1 @ e0, e0) and np.allclose(P1 @ e7, e7)
blocks &= all(np.allclose(X @ P1, 0) and np.allclose(X @ P2, P2 @ X) for X in STs)
B6 = np.linalg.svd(P2)[0][:, :6]; Y6 = [B6.T @ X @ B6 for X in STs]
cY = null_dim(np.vstack([np.kron(y, np.eye(6)) - np.kron(np.eye(6), y.T) for y in Y6]))
chk('std', len(STs) == 8 and nG2 == 14 and nSU3 == 8 and same and blocks and cY == 2, 'fb.COL: numpy on the octonions: the stabiliser of the unit 1 in span{L_u L_v} has dimension 8; the derivations of O form g2 (dimension 14), those fixing e7 have dimension 8, and the two 8-dimensional spaces coincide: the colour su(3) of Furey\'s reading; it kills FUR-001\'s block O1 = span{1, e7} (P = (1 - L_e7 R_e7)/2, rank 2) and acts on O2 (rank 6) with commutant of dimension 2')
chk('bit==std', len(NSt) == len(STs) == 8 and len(CW) == cY == 2, 'fb.COL: the same numbers on the labels and on the octonions: a stabiliser of dimension 8, acting on the complement of the fixed complex line with commutant of dimension 2 (complex 3)')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fb.S10  Cl(1,9) beside Cl(0,10) and Cl(5,5)
head('fb.S10  Cl(1,9) beside the compact Cl(0,10) (CAND-136) and the split Cl(5,5) (CAND-003): one complexification, three real forms')
t = time.time()
def even_type(eps):
    n = len(eps); ev = [a for a in range(1 << n) if pc(a) % 2 == 0]; ix = {a: k for k, a in enumerate(ev)}
    return table_type(table(eps)[np.ix_(ev, ev)], [ix[1 | (1 << k)] for k in range(1, n)])
C10 = [(1, 9), (0, 10), (5, 5)]; RT, ET, CT10, VS, HALF = [], [], [], [], []
for c_ in C10:
    e_ = sig(*c_); RT.append(ltype_eps(e_)); ET.append(even_type(e_)); VS.append(BR(e_).s(TOP, TOP))
    CT10.append(table_type(ungraded_table(e_, sig(0, 1)), [1 << i for i in range(11)]))
    Lc = lab_ungraded(e_, sig(0, 1)); vol = TOP if VS[-1] == 1 else TOP | (1 << 10)                        # Gamma, or i omega when omega^2 = -1
    Gc = comm_labels(Lc, first=(vol,), tries=6); Ic = Ideal(Lc, Gc); dv = np.diag(Ic.act(vol)); Jc = Ic.act(1 << 10)
    HALF.append((Ic.m, int((dv == 1).sum()), Lc.sq(vol) == 1 and np.array_equal(Jc @ Jc, -np.eye(Ic.m, dtype=np.int64)) and all(Lc.commute(1 << 10, 1 << i) for i in range(10))))
chk('bit', RT == [('R', 32, 1), ('H', 16, 1), ('R', 32, 1)] and ET == [('R', 16, 2), ('C', 16, 1), ('R', 16, 2)] and VS == [1, -1, 1],
    'fb.S10: on the labels Cl(1,9) = %s, Cl(0,10) = %s, Cl(5,5) = %s; their even parts are %s, %s, %s and their volume elements square to %+d, %+d, %+d: real half-spinors of dimension 16 for Cl(1,9) and Cl(5,5) (Majorana-Weyl), none for Cl(0,10), whose even part has centre C = span{1, omega}' % tuple(list(map(tstr, RT)) + list(map(tstr, ET)) + VS))
chk('bit', CT10 == [('C', 32, 1)] * 3 and all(h_ == (64, 32, True) for h_ in HALF), 'fb.S10: complexified (the ungraded product with Cl(0,1) = C, a central i of square -1) all three are M32(C) on the labels; the minimal ideal is C^32 (real dimension 64), on which Gamma (for Cl(1,9), Cl(5,5)) or i omega (for Cl(0,10)) has the eigenvalue +1 on a complex 16: the Weyl spinor, the 16 of so(10, C)')
note('the branching 16 -> (2,1,4) + (1,2,4bar) under so(4) + so(6) (Pati-Salam 1974; Slansky 1981, Table 48) is cited, not computed; here: each half of Cl(1,9) is, with I, a complex 8 = 2 x 4 (fb.CHI), the real form of a (2,1,.) + (1,2,.) pair exchanged by complex conjugation')
note('(%.1f s)' % (time.time() - t))
t = time.time()
PX = np.array([[0, 1], [1, 0]], dtype=complex); PY = np.array([[0, -1j], [1j, 0]]); PZ = np.diag([1, -1]).astype(complex); P2c = np.eye(2, dtype=complex)
HM = [kron_all([PZ] * k + [P_] + [P2c] * (4 - k)) for k in range(5) for P_ in (PX, PY)]                   # ten anticommuting Hermitian 32 x 32
CL19 = [HM[0]] + [1j * h for h in HM[1:]]; CL010 = [1j * h for h in HM]
okc10 = True; rk = []
for G_, sq_ in ((CL19, 1), (CL010, -1)):
    eps_ = [1] + [-1] * 9 if sq_ == 1 else [-1] * 10
    okc10 &= all(np.allclose(G_[i] @ G_[j] + G_[j] @ G_[i], 2 * eps_[i] * np.eye(32) * (i == j)) for i in range(10) for j in range(i, 10))
    V_ = prodm(G_); okc10 &= np.allclose(V_ @ V_, sq_ * np.eye(32)); Vh = V_ if sq_ == 1 else 1j * V_
    rk.append((int(np.linalg.matrix_rank((np.eye(32) + Vh) / 2)), int(np.linalg.matrix_rank(fwords(G_, np.complex64).reshape(1024, -1)))))
chk('std', okc10 and rk == [(16, 1024), (16, 1024)], 'fb.S10: numpy, complex gamma matrices (Pauli words): Cl(1,9) and Cl(0,10) on C^32 with Gamma^2 = +1 and omega^2 = -1; (1 + Gamma)/2 and (1 + i omega)/2 have rank 16, and the 1024 words have complex rank 1024 (M32(C)) in both')
chk('bit==std', [h_[1] // 2 for h_ in HALF[:2]] == [r_[0] for r_ in rk], 'fb.S10: the complex dimension 16 of the half agrees on the labels and on the matrices for Cl(1,9) and Cl(0,10)')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fb.DIR  the Dirac operator under the two products
head('fb.DIR  D = D_base + D_fibre under the two products: the bivectors commute in both, the vectors do not; the mass shell')
t = time.time()
LU = lab_ungraded(E13, E06); KS = -1 if FAULT == 'KKSIGN' else 1           # KS: the sign of the fibre momentum asserted on the shell
evL = [a | (b << 4) for a in range(16) if pc(a) % 2 == 0 for b in range(64) if pc(b) % 2 == 0]
okE = all(L19.commute(x, y) and LU.commute(x, y) for x in bivB for y in bivF) and all(L19.s(x, y) == LU.s(x, y) for x in evL for y in evL)
okE &= all(np.array_equal(BIVg[i] @ BIVg[j], BIVg[j] @ BIVg[i]) for i in range(6) for j in range(6, 21))
chk('bit', okE, 'fb.DIR: the 6 base bivectors and the 15 fibre bivectors commute in both products (the labels of Cl(1,9) and of the ungraded table, and as the same 21 operators on S (x) O); the two tables agree on all 65536 pairs of the 256 labels even in the base and even in the fibre: internal and spacetime symmetries commute either way (the premise of FUR-567)')
vB = [1 << i for i in range(4)]; vF = [1 << i for i in range(4, 10)]
chk('bit', all(not L19.commute(x, y) for x in vB for y in vF) and all(LU.commute(x, y) for x in vB for y in vF), 'fb.DIR: the odd parts differ: the 4 base vectors and the 6 fibre vectors anticommute in the graded product (24 pairs) and commute in the ungraded one')
def madd(*terms):
    out = {}
    for c_, x in terms:
        for k_, v in x.items():
            w = out.get(k_, 0) + c_ * v
            if w: out[k_] = w
            else: out.pop(k_, None)
    return out
def vecK(k, l): return madd((1, {1 << mu: Fr(k[mu]) for mu in range(4) if k[mu]}), (1, {1 << (4 + a): Fr(l[a]) for a in range(6) if l[a]}))
def Qk(k): return Fr(k[0]) ** 2 - sum(Fr(x) ** 2 for x in k[1:])
rfr = lambda: Fr(RNG.randint(-9, 9), RNG.randint(1, 5))
okK = True; ncr = []
for _ in range(6):
    k, l = [rfr() for _ in range(4)], [rfr() for _ in range(6)]; m2 = sum(x * x for x in l); K = vecK(k, l)
    kh, lh = vecK(k, [0] * 6), vecK([0] * 4, l); cross = LU.mul(kh, lh)
    okK &= L19.mul(K, K) == madd((Qk(k) - KS * m2, {0: Fr(1)}))
    okK &= LU.mul(K, K) == madd((Qk(k) - m2, {0: Fr(1)}), (2, cross)) and LU.mul(K, madd((1, kh), (-1, lh))) == madd((Qk(k) + KS * m2, {0: Fr(1)}))
    ncr.append(len(cross))
chk('bit', okK, 'fb.DIR: with K = k + l (k = sum k_mu e_mu, l = sum l_a f_a), exactly on six random rational (k, l): graded K^2 = Q(k) - |l|^2, a scalar; ungraded K^2 = Q(k) - |l|^2 + 2 k l with the cross term k l of %s non-zero grade-2 labels, and (k + l)(k - l) = Q(k) + |l|^2' % sorted(set(ncr)))
J_ = {6: Fr(-1)}; kS, lS = (5, 3, 0, 0), (4, 0, 0, 0, 0, 0); KSH = vecK(kS, lS); okW = True
for _ in range(3):
    P_ = {RNG.randrange(1024): rfr() or Fr(1) for _ in range(6)}
    D2g = L19.mul(L19.mul(KSH, L19.mul(L19.mul(KSH, P_), J_)), J_); D2u = LU.mul(LU.mul(KSH, LU.mul(LU.mul(KSH, P_), J_)), J_)
    okW &= D2g == madd((-(Qk(kS) - KS * 16), P_)) and D2u == madd((-(Qk(kS) - 16), P_), (-2, LU.mul(LU.mul(vecK(kS, [0] * 6), vecK([0] * 4, lS)), P_))) and D2u != {}
chk('bit', okW, 'fb.DIR: on a plane wave psi = P e^(J theta), J = gamma2 gamma1 on the right (theta = k.x + l.y), D psi = (K P J) e^(J theta) and D^2 psi = (K (K P J) J) e^(J theta) = -K^2 psi, exactly on three random rational P at E = 5, p = (3,0,0), m = |l| = 4: graded D^2 psi = -(Q(k) - m^2) psi = 0 (the mass shell E^2 = |p|^2 + m^2, Kaluza-Klein, LNS-120); ungraded D^2 psi = -2 k l psi != 0 (no Klein-Gordon equation)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
IU = Ideal(LU, comm_labels(LU, tries=12)); RU = [IU.act(1 << i) for i in range(10)]
PTS = [((5, 3, 0, 0), 4), ((4, 0, 0, 0), 4), ((3, 5, 0, 0), 4), ((6, 3, 0, 0), 4), ((5, 5, 0, 0), 0)]
def Kmat(R, k, m): return sum(k[mu] * R[mu] for mu in range(4)) + m * R[4]
QS = [Qk(k) for k, m in PTS]
wantG = [16 if q == KS * m * m else 0 for q, (k, m) in zip(QS, PTS)]; wantU = [32 if q == -KS * m * m else 0 for q, (k, m) in zip(QS, PTS)]
kerG = [32 - rank_frac(Kmat(R19, k, m)) for k, m in PTS]; kerU = [64 - rank_frac(Kmat(RU, k, m)) for k, m in PTS]
chk('bit', kerG == wantG and kerU == wantU and IU.m == 64, 'fb.DIR: plane waves (the kernel of K on the minimal ideals, exact ranks) at (E, |p|, m) = (5,3,4), (4,0,4), (3,5,4), (6,3,4), (5,5,0), Q(k) = %s: graded (Cl(1,9), 32) %s, exactly on Q(k) = m^2, E^2 = |p|^2 + m^2; ungraded (64) %s, exactly on Q(k) = -m^2, E^2 = |p|^2 - m^2 (spacelike), none on the mass shell for m != 0; both on the light cone for m = 0' % ([int(q) for q in QS], kerG, kerU))
kGM = [64 - rank_frac(Kmat(GRD, k, m)) for k, m in PTS]; kUM = [64 - rank_frac(Kmat(UNG, k, m)) for k, m in PTS]
sqok = all(np.array_equal(Kmat(GRD, k, m) @ Kmat(GRD, k, m), int(q - KS * m * m) * I64) and np.array_equal(Kmat(UNG, k, m) @ (Kmat(UNG, k, m) - 2 * m * UNG[4]), int(q + KS * m * m) * I64) for q, (k, m) in zip(QS, PTS))
chk('bit', sqok and kGM == [2 * w for w in wantG] and kUM == wantU, 'fb.DIR: the same on S (x) O (Dirac spinor times octonion, 64): K_g^2 = (Q(k) - m^2) 1 and K_u (k - l) = (Q(k) + m^2) 1 at the five points; kernels %s (graded, two copies of the 16) and %s (ungraded)' % (kGM, kUM))
c14, c23 = BR(sig(1, 4)), BR(E13 + (1,)); okL = True
for k, m in PTS:
    K4 = madd((1, {1 << mu: Fr(k[mu]) for mu in range(4) if k[mu]}), (1, {16: Fr(m)} if m else {}))
    okL &= lab_graded(sig(1, 4)).mul(K4, K4) == madd((Qk(k) - m * m, {0: Fr(1)})) and lab_graded(E13 + (1,)).mul(K4, K4) == madd((Qk(k) + m * m, {0: Fr(1)}))
chk('bit', okL, 'fb.DIR: LNS-120\'s single extra generator f: (k + m f)^2 = Q(k) - m^2 in Cl(1,4) (f^2 = -1) and Q(k) + m^2 in Cl(1,3) (x)^ Cl(1,0) (f^2 = +1) at the five points: the ungraded product\'s plane waves sit on the shell Q(k) = -m^2 of LNS-120\'s extra generator of square +1')
chk('ctl', kerG[2] == 0 and kerU[0] == kerU[1] == 0 and kGM[2] == 0 and kUM[0] == 0, 'fb.DIR: the shell of the other sign is empty in each product (KKSIGN): no graded plane wave at Q(k) = -m^2 (E = 3, |p| = 5, m = 4), no ungraded one at Q(k) = +m^2 (E = 5, |p| = 3 and E = 4 at rest, m = 4)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
kGs = [64 - int(np.linalg.matrix_rank(Kmat(GRDs, k, m))) for k, m in PTS]; kUs = [64 - int(np.linalg.matrix_rank(Kmat(UNGs, k, m))) for k, m in PTS]
sqs = all(np.allclose(Kmat(GRDs, k, m) @ Kmat(GRDs, k, m), float(q - m * m) * np.eye(64)) for q, (k, m) in zip(QS, PTS))
chk('std', sqs and kGs == [32, 32, 0, 0, 32] and kUs == [0, 0, 32, 0, 32], 'fb.DIR: numpy, the realified Dirac matrices with gamma5 x L_u (graded) and 1 x L_u (ungraded) on R^64: K^2 = Q(k) - m^2 in the graded case; kernels %s and %s at the five points' % (kGs, kUs))
chk('bit==std', kGs == kGM and kUs == kUM, 'fb.DIR: the kernels on S (x) O agree on the labels and on the matrices at all five points')
note('not computed: fields on a manifold or with x-dependent amplitudes (plane waves only); which product nature uses (an input, INP-011)')
note('(%.1f s)' % (time.time() - t))
finish()
