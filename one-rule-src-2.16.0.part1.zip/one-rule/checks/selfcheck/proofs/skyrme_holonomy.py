#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""skyrme_holonomy.py: a Skyrme field from the holonomy of the BPST field of the labels along lines and along circles, its degree, and the hyperbolic
reading of Atiyah and Sutcliffe, Skyrmions, instantons, mass and curvature.
    python3 skyrme_holonomy.py [--fault ANTI|PROFILE|NOSIGN|NONORTH|BETA|INTEGRAL|DOUBLE|KAPPA|CONF]

Labels: Cl(0,3) by the bit rule of researchers_checks/bitrule_A.py (three generators of square -1); B_0 = e0e1 (mask 3), B_1 = e0e2 (mask 5),
B_2 = e1e2 (mask 6): B_a^2 = -1, [B_a, B_b] = 2 eps_abc B_c, so so(3) = su(2), and 1, B_a span the quaternions. The BPST field of ym_solutions.py
(regular gauge, slot 3 = x4, eps_1234 = +1): A^a_mu = 2 eta^a_mu nu x^nu/(x^2 + rho^2), taken as the bivector-valued form calA = (1/2) A^a B_a, so
F = d calA + calA ^ calA (the convention of ym_solutions.py); parallel transport U = P exp(-int calA).
1. [bit] exact fractions on the labels. The radial gauge x^mu calA_mu = 0, so the holonomy along every line through the centre is 1. Along x + t e4
   the value calA_4 = -(x.B)/(r^2 + t^2 + rho^2) lies on the one bivector x.B, the path ordering is trivial and U = exp(theta xhat.B) with
   theta = pi r/sqrt(r^2 + rho^2) (the closed integral of dt/(c^2 + t^2) over the line is pi/c, recalled); -U = exp(-f xhat.B) with
   f = pi (1 - (1 + rho^2/r^2)^(-1/2)), the paper's (3.4). On the plane of xhat and e4 the connection is abelian, with curvature
   -2 rho^2/(r^2 + rho^2)^2 du^dw (xhat.B) (exact derivatives by dual numbers). The circles of that plane through s xhat and (a^2/s) xhat
   (orthogonal to |x| = a) give U = exp(-Theta xhat.B): the integrand reduces exactly to 1/(1 + tau^2) - (a^2 + rho^2)/(p + q tau^2), so
   Theta = pi (1 - (a^2 + rho^2)/sqrt(pq)), and (1 - Theta/pi)^2 = sinh^2 y/(beta^2 + sinh^2 y) with s = a tanh(y/2), beta = 2 a rho/(a^2 + rho^2),
   the paper's (3.9). The toroidal coordinates (3.5) pull the flat metric back to (ds^2(H^3) + kappa^-2 dchi^2)/(cosh kappa rho + cos chi)^2 at
   rational points (rational parametrisations); their chi-circles are these circles with a = 1/kappa; the slice chi = 0, scaled by 2, is the
   k = -1 chart 1/(1 + k r^2/4) of b3c4_curved_points.py. The degree: the orientation sign of the quaternions of the labels and
   deg = sign * (g(inf) - g(0))/pi for U = exp(g xhat.B); the Chern-Simons value 3c^2 - 2c^3 of the field c A. The dipole tails (1 + m r) e^(-m r)/r^2
   and 1/sinh^2(kappa rho) solve the linearised equations of (2.3) and (2.7) exactly; their rates are m and 2 kappa.
2. [std] numpy and scipy, never the labels: SU(2) matrices T_a = -(i/2) sigma_a; path-ordered products of matrix exponentials along lines and
   circles of the closed-form fields (regular gauge, and the paper's 't Hooft gauge (3.2)-(3.3) with its sigma_mu nu); the baryon number
   -(1/24 pi^2) int eps_ijk Tr(R_i R_j R_k) d^3x by quadrature; the instanton number of c A by quadrature of finite differences; the toroidal pullback
   by finite differences; the paper's numbers from the hedgehog energies (2.3) and (2.7) by solve_bvp and quad.
3. [ctl] each --fault NAME puts the wrong version into the main line, which then FAILs: ANTI the anti-instanton; PROFILE the exponent -1 in (3.4);
   NOSIGN the line holonomy of the regular gauge without the central -1; NONORTH circles not orthogonal to |x| = a; BETA beta = a rho/(a^2 + rho^2);
   INTEGRAL pi/(2 sqrt(pq)) for the closed integral; DOUBLE the field 2A; KAPPA kappa = m; CONF the conformal factor to the power 1.
Scope: the rational points and data printed in the log; the closed integrals and the baryon-number formula are recalled; the numerics are floats
with the tolerances printed. No engine object is built, so the eight engine faults of the gravity folder do not apply."""
import os, sys, math, itertools, random
from fractions import Fraction as Fr
from math import isqrt
import numpy as np
from scipy import integrate, optimize, linalg

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here)
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
if not os.path.isfile(os.path.join(_researchers, 'bitrule_A.py')):
    raise SystemExit('bitrule_A.py not found in ' + _researchers + ': this file belongs in selfcheck/proofs/ of the package')
if _researchers not in sys.path: sys.path.insert(0, _researchers)
from bitrule_A import BR, comm

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[0 if cond else 1] += 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('ANTI', 'PROFILE', 'NOSIGN', 'NONORTH', 'BETA', 'INTEGRAL', 'DOUBLE', 'KAPPA', 'CONF')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
PI = math.pi

# ------------------------------------------------------------------------------------------------ exact helpers
def qsqrt(q):
    """the square root of a non-negative rational when it is rational, else None"""
    q = Fr(q); n, d = q.numerator, q.denominator; rn, rd = isqrt(n), isqrt(d)
    return Fr(rn, rd) if rn * rn == n and rd * rd == d else None
def eps3(i, j, k):
    if len({i, j, k}) < 3: return 0
    return 1 if (i, j, k) in ((0, 1, 2), (1, 2, 0), (2, 0, 1)) else -1
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def det4(M):
    s = Fr(0)
    for p in itertools.permutations(range(4)):
        sg = 1
        for i in range(4):
            for j in range(i + 1, 4):
                if p[i] > p[j]: sg = -sg
        s += sg * M[0][p[0]] * M[1][p[1]] * M[2][p[2]] * M[3][p[3]]
    return s
class D:
    """forward-mode dual numbers over Fractions: value and gradient (exact first derivatives of rational functions)"""
    __slots__ = ('v', 'g')
    def __init__(self, v, g): self.v = Fr(v); self.g = tuple(Fr(x) for x in g)
    @staticmethod
    def var(v, i, n): return D(v, tuple(1 if j == i else 0 for j in range(n)))
    def _w(self, o): return o if isinstance(o, D) else D(o, (0,) * len(self.g))
    def __add__(self, o): o = self._w(o); return D(self.v + o.v, tuple(a + b for a, b in zip(self.g, o.g)))
    __radd__ = __add__
    def __neg__(self): return D(-self.v, tuple(-a for a in self.g))
    def __sub__(self, o): return self + (-self._w(o))
    def __rsub__(self, o): return self._w(o) - self
    def __mul__(self, o): o = self._w(o); return D(self.v * o.v, tuple(self.v * b + o.v * a for a, b in zip(self.g, o.g)))
    __rmul__ = __mul__
    def __truediv__(self, o): o = self._w(o); return D(self.v / o.v, tuple((a * o.v - self.v * b) / (o.v * o.v) for a, b in zip(self.g, o.g)))
    def __rtruediv__(self, o): return self._w(o) / self

# ------------------------------------------------------------------------------------------------ the labels
A3 = BR((-1, -1, -1)); BIV = (3, 5, 6)
def clean(x): return {k: Fr(v) for k, v in x.items() if v != 0}
def bv(n, c=1): return clean({BIV[a]: Fr(c) * Fr(n[a]) for a in range(3)})
def mv_eq(x, y): return not clean(A3.add(x, y, -1))
def coords(x): return [Fr(x.get(0, 0)), Fr(x.get(3, 0)), Fr(x.get(5, 0)), Fr(x.get(6, 0))]
E3 = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
UNITS = [(Fr(1, 3), Fr(2, 3), Fr(2, 3)), (Fr(2, 7), Fr(3, 7), Fr(6, 7)), (Fr(0), Fr(3, 5), Fr(4, 5)), (Fr(-2, 3), Fr(1, 3), Fr(2, 3))]

def eta_sym(bar=False):
    """eta[a][mu][nu] of ym_solutions.py: eta^a_ij = eps_aij, eta^a_i4 = delta_ai (eta-bar: -delta_ai), antisymmetric; slot 3 = x4"""
    e = [[[Fr(0)] * 4 for _ in range(4)] for _ in range(3)]
    for a in range(3):
        for i in range(3):
            for j in range(3): e[a][i][j] = Fr(eps3(a, i, j))
            s = -1 if bar else 1; e[a][i][3] = Fr(s * (a == i)); e[a][3][i] = Fr(-s * (a == i))
    return e
ETA, ETAB = eta_sym(), eta_sym(True)
def calA(x, rho2, v, bar=False, c=1):
    """coefficients k^a of calA(v) = sum_a k^a B_a at the point x: k^a = c sum_mu nu v^mu eta^a_mu nu x^nu/(x^2 + rho^2) (calA = (1/2) A^a B_a)"""
    e = ETAB if bar else ETA; Q = x[0] * x[0] + x[1] * x[1] + x[2] * x[2] + x[3] * x[3] + rho2
    return [c * sum((e[a][mu][nu] * v[mu] * x[nu] for mu in range(4) for nu in range(4) if e[a][mu][nu] != 0), Fr(0)) / Q for a in range(3)]
def mvA(k): return clean({BIV[a]: k[a] for a in range(3)})

def main():
    rng = random.Random(174)
    def rq(lo=-7, hi=7, dmax=5): return Fr(rng.randint(lo, hi), rng.randint(1, dmax))

    # ------------------------------------------------------------------------------------------ 0. the labels
    head('0. the labels: so(3) = su(2) on the bivectors of Cl(0,3), the quaternions, the orientation sign')
    sq_ok = all(mv_eq(A3.mul(bv(E3[a]), bv(E3[a])), {0: -1}) for a in range(3))
    br_ok = all(mv_eq(comm(A3, bv(E3[a]), bv(E3[b])), bv([2 * eps3(a, b, c) for c in range(3)])) for a in range(3) for b in range(3))
    Q4 = [{0: Fr(1)}] + [bv(E3[a]) for a in range(3)]
    closed = all(set(clean(A3.mul(x, y))) <= {0, 3, 5, 6} for x in Q4 for y in Q4)
    unit_ok = all(mv_eq(A3.mul(bv(n), bv(n)), {0: -1}) for n in UNITS)
    chk('bit', sq_ok and br_ok and closed and unit_ok, 'B_0 = e0e1, B_1 = e0e2, B_2 = e1e2 of Cl(0,3): B_a^2 = -1, [B_a, B_b] = 2 eps_abc B_c (9 pairs), 1 and B_a closed under the product (the quaternions, 16 products), (n.B)^2 = -1 for the rational unit vectors %s' % [tuple(str(c) for c in n) for n in UNITS])
    s1 = np.array([[0, 1], [1, 0]], complex); s2 = np.array([[0, -1j], [1j, 0]]); s3 = np.array([[1, 0], [0, -1]], complex); SIG = [s1, s2, s3]; I2 = np.eye(2)
    Bm = [-1j * s for s in SIG]
    def tomat(x): return float(x.get(0, 0)) * I2 + sum(float(x.get(BIV[a], 0)) * Bm[a] for a in range(3))
    iso = max(np.max(np.abs(tomat(clean(A3.mul(x, y))) - tomat(x) @ tomat(y))) for x in Q4 for y in Q4)
    chk('bit==std', iso < 1e-15, 'the map 1 -> I, B_a -> -i sigma_a carries the 16 products of the quaternion basis of the labels to the matrix products (max deviation %.1e): the labels\' calA = (1/2) A^a B_a is the matrix connection A^a T_a, T_a = -(i/2) sigma_a' % iso)
    nh = UNITS[0]; e1 = (Fr(2, 3), Fr(1, 3), Fr(-2, 3)); e2 = cross(nh, e1)
    frame_ok = sum(a * b for a, b in zip(nh, e1)) == 0 and sum(a * a for a in e2) == 1 and det4([[1, 0, 0, 0]] + [[0] + list(v) for v in (nh, e1, e2)]) == 1
    M = [list(col) for col in zip(coords(bv(nh)), coords({0: Fr(-1)}), coords(bv(e1)), coords(bv(e2)))]
    d0 = det4(M); SIG0 = 1 if d0 > 0 else -1
    chk('bit', frame_ok and d0 != 0, 'orientation sign of the quaternions (basis 1, B_0, B_1, B_2): for U = exp(g xhat.B) at a point with g = pi/2 the local degree is sign(g\') * det[n.B, -1, e1.B, e2.B] for a positive frame (n, e1, e2) = (%s, %s, %s): det = %s, sign %+d; so deg U = %+d (g(inf) - g(0))/pi for a monotone g' % (tuple(map(str, nh)), tuple(map(str, e1)), tuple(map(str, e2)), d0, SIG0, SIG0))

    # ------------------------------------------------------------------------------------------ 1. BPST on the labels
    head('1. the BPST field of the labels (CAND-124): radial gauge, lines parallel to e4, the plane of xhat and e4')
    pts = []
    while len(pts) < 24:
        p = [rq() for _ in range(4)]
        if any(p): pts.append((p, [Fr(1), Fr(4, 9), Fr(9)][len(pts) % 3]))
    rad = all(all(k == 0 for k in calA(p, r2, p, bar)) for (p, r2) in pts for bar in (False, True))
    chk('bit', rad, 'x^mu calA_mu(x) = 0 at %d rational points, eta and eta-bar, rho^2 in {1, 4/9, 9} (the regular gauge is radial): along every line through the centre the integrand vanishes and the holonomy is 1' % len(pts))
    e4 = [Fr(0), Fr(0), Fr(0), Fr(1)]
    line_ok = True; line_ok_b = True; comm_ok = True
    for (p, r2) in pts[:16]:
        xs = p[:3]; ts = [Fr(0), Fr(1, 2), Fr(-3), p[3]]
        vals = []
        for t in ts:
            x = xs + [t]; Q = sum(c * c for c in x) + r2
            k = calA(x, r2, e4); kb = calA(x, r2, e4, True)
            line_ok &= k == [-xs[a] / Q for a in range(3)]; line_ok_b &= kb == [xs[a] / Q for a in range(3)]; vals.append(mvA(k))
        comm_ok &= all(not clean(comm(A3, vals[i], vals[j])) for i in range(4) for j in range(i + 1, 4))
    chk('bit', line_ok and line_ok_b and comm_ok, 'along x + t e4 (16 points x, 4 values of t each): calA_4 = -(x.B)/(r^2 + t^2 + rho^2) exactly (eta-bar: +(x.B)/...), so every value lies on the one bivector xhat.B and the values commute (all 6 commutators per line are 0): the path ordering is trivial')
    PYTH = [((1, 2, 2), 16), ((2, 3, 6), 576), ((0, 3, 4), 144)]
    prof = []; prof_ok = True
    for (xv, r2) in PYTH:
        r = qsqrt(sum(c * c for c in xv)); theta_pi = r / qsqrt(r * r + r2)               # theta/pi = r/sqrt(r^2 + rho^2): the closed integral pi/c of dt/(c^2 + t^2)
        f_pi = 1 - theta_pi                                                               # -U = exp((theta - pi) xhat.B) = exp(-f xhat.B)
        expo = -1 if FAULT == 'PROFILE' else Fr(-1, 2)
        base = 1 + Fr(r2) / (r * r)
        paper = 1 - (1 / base if expo == -1 else 1 / qsqrt(base))                        # (3.4): f/pi = 1 - (1 + rho^2/r^2)^(-1/2)
        prof_ok &= f_pi == paper; prof.append((str(r), r2, str(theta_pi), str(f_pi)))
    chk('bit', prof_ok, 'Pythagorean data (r, rho^2, theta/pi, f/pi) = %s: theta/pi = r/sqrt(r^2 + rho^2) and f/pi = 1 - theta/pi equal the paper\'s (3.4) f/pi = 1 - (1 + rho^2/r^2)^(-1/2) exactly%s' % (prof, ' [fault PROFILE: exponent -1]' if FAULT == 'PROFILE' else ''))
    # the plane of xhat and e4: abelian, flux density
    pl_ok = True; curv_ok = True; nplane = 0
    for n in UNITS:
        for (u0, w0, r2) in ((Fr(1, 2), Fr(3, 4), Fr(1)), (Fr(-2), Fr(1, 3), Fr(4, 9)), (Fr(3), Fr(-5, 2), Fr(9))):
            u = D.var(u0, 0, 2); w = D.var(w0, 1, 2)
            x = [u * n[0], u * n[1], u * n[2], w]
            kn = calA(x, r2, [n[0], n[1], n[2], Fr(0)]); k4 = calA(x, r2, e4)
            Q = u0 * u0 + w0 * w0 + r2
            pl_ok &= all(kn[a].v == w0 * n[a] / Q and k4[a].v == -u0 * n[a] / Q for a in range(3))
            Fuw = [k4[a].g[0] - kn[a].g[1] for a in range(3)]                             # d_u calA_w - d_w calA_u (+ [calA_u, calA_w] = 0 below)
            cm = clean(comm(A3, mvA([k.v for k in kn]), mvA([k.v for k in k4])))
            Fc = [-4 * n[a] * r2 / Q ** 2 for a in range(3)]                                # CAND-124's F^a(xhat, e4) = -4 eta^a(xhat, e4) rho^2/(x^2 + rho^2)^2
            curv_ok &= not cm and all(Fuw[a] == -2 * r2 / Q ** 2 * n[a] and Fuw[a] == Fc[a] / 2 for a in range(3)); nplane += 1
    chk('bit', pl_ok and curv_ok, 'on the plane of xhat and e4 (%d points, 4 unit vectors): calA = (w du - u dw)/(u^2 + w^2 + rho^2) (xhat.B), [calA_u, calA_w] = 0, and the curvature (exact derivatives) is -2 rho^2/(u^2 + w^2 + rho^2)^2 du^dw (xhat.B) = (1/2) F^a(xhat, e4) B_a of CAND-124\'s closed form' % nplane)

    # ------------------------------------------------------------------------------------------ 1d. circles
    head('1d. circles of the plane through s xhat and (a^2/s) xhat (orthogonal to |x| = a), oriented along +e4 at s xhat: the hyperbolic profile')
    def circle_data(a2, r2, s, shift=Fr(0)):
        c = (s + a2 / s) / 2 + shift; R = (a2 / s - s) / 2
        A_ = c * c + R * R + r2; B_ = 2 * c * R; return c, R, A_ + B_, A_ - B_
    def g_cw(n, a2, r2, s, tau, shift=Fr(0)):
        """the coefficient of xhat.B in calA(xdot) on the circle (centre c xhat, radius R, clockwise), at the rational point tau = tan(psi/2)"""
        c, R, p, q = circle_data(a2, r2, s, shift); d = 1 + tau * tau
        u = c + R * (1 - tau * tau) / d; w = -2 * R * tau / d; du = -4 * R * tau / d ** 2; dw = -2 * R * (1 - tau * tau) / d ** 2
        x = [u * n[0], u * n[1], u * n[2], w]; v = [du * n[0], du * n[1], du * n[2], dw]
        k = calA(x, r2, v); g = (w * du - u * dw) / (u * u + w * w + r2)
        return k, g, (u, w)
    TAUS = [Fr(0), Fr(1), Fr(-1), Fr(1, 2), Fr(-1, 3), Fr(2), Fr(-5), Fr(3, 7), Fr(7, 2), Fr(-9, 4), Fr(11), Fr(-1, 8)]
    DATA = [(Fr(1), Fr(1), Fr(1, 3)), (Fr(4), Fr(4), Fr(1)), (Fr(5), Fr(16), Fr(5, 3)), (Fr(9), Fr(4), Fr(1, 2)), (Fr(25, 4), Fr(9, 4), Fr(3, 2))]
    orth = all(circle_data(a2, r2, s)[0] ** 2 - circle_data(a2, r2, s)[1] ** 2 == a2 for (a2, r2, s) in DATA)
    fix_ok = True; pf_ok = True; comm_c = True
    shift = Fr(1, 7) if FAULT == 'NONORTH' else Fr(0)
    for (a2, r2, s) in DATA:
        for n in UNITS[:2]:
            vals = []
            for tau in TAUS:
                k, g, _ = g_cw(n, a2, r2, s, tau, shift); c, R, p, q = circle_data(a2, r2, s, shift)
                fix_ok &= k == [g * n[a] for a in range(3)]; vals.append(mvA(k))
                pf_ok &= g == 1 / (1 + tau * tau) - (a2 + r2) / (p + q * tau * tau)
            comm_c &= all(not clean(comm(A3, vals[i], vals[j])) for i in range(0, 12, 3) for j in range(1, 12, 4))
    chk('bit', orth, 'the circles are orthogonal to |x| = a: c^2 - R^2 = a^2 for centre c = (s + a^2/s)/2 and radius R = (a^2/s - s)/2, data (a^2, rho^2, s) = %s' % [tuple(map(str, d_)) for d_ in DATA])
    chk('bit', fix_ok and comm_c, 'on each circle (5 data, 2 directions, 12 rational points) calA(xdot) = g(tau) xhat.B exactly with g = (w du - u dw)/(u^2 + w^2 + rho^2): one bivector, commuting values, trivial path ordering')
    chk('bit', pf_ok, 'g(tau) = 1/(1 + tau^2) - (a^2 + rho^2)/(p + q tau^2) with p = A + B, q = A - B, A = c^2 + R^2 + rho^2, B = 2 c R, at the 12 points of each circle (more points than the degree of the identity, so it holds for all tau)%s' % (' [fault NONORTH: centre shifted by 1/7]' if FAULT == 'NONORTH' else ''))
    exact_th = []
    for (a2, r2, s) in DATA[:3]:
        c, R, p, q = circle_data(a2, r2, s); rt = qsqrt(p * q)
        exact_th.append((tuple(map(str, (a2, r2, s))), str(1 - (a2 + r2) / rt) if rt is not None else None))
    chk('bit', [t[1] for t in exact_th] == ['2/5', '1/5', '2/65'], 'with the closed integrals of 1/(1 + tau^2) and 1/(p + q tau^2) over the line (pi and pi/sqrt(pq), recalled): Theta/pi = 1 - (a^2 + rho^2)/sqrt(pq), rational where pq is a square: %s' % exact_th)
    # comparison with the paper's (3.9)
    cmp_ok = True; ndat = 0; rng2 = random.Random(1740)
    while ndat < 40:
        a2 = Fr(rng2.randint(1, 30), rng2.randint(1, 6)); r2 = Fr(rng2.randint(1, 30), rng2.randint(1, 6)); s = Fr(rng2.randint(1, 40), rng2.randint(1, 9))
        if s * s >= a2: continue
        c, R, p, q = circle_data(a2, r2, s)
        lhs = (a2 + r2) ** 2 / (p * q)                                                    # (1 - Theta/pi)^2 = cos^2 alpha
        sh2 = 4 * a2 * s * s / (a2 - s * s) ** 2                                          # sinh^2 y with s = a tanh(y/2)
        beta2 = (a2 * r2 if FAULT == 'BETA' else 4 * a2 * r2) / (a2 + r2) ** 2             # beta = 2 a rho/(a^2 + rho^2)
        cmp_ok &= lhs == sh2 / (beta2 + sh2) and lhs == s * s * (a2 + r2) ** 2 / ((a2 * a2 + s * s * r2) * (s * s + r2)); ndat += 1
    chk('bit', cmp_ok, '(1 - Theta/pi)^2 = (a^2 + rho^2)^2/(pq) = s^2 (a^2 + rho^2)^2/((a^4 + s^2 rho^2)(s^2 + rho^2)) = sinh^2 y/(beta^2 + sinh^2 y), s = a tanh(y/2), beta = 2 a rho/(a^2 + rho^2), at %d random rational data: Theta = pi (1 - sinh y/sqrt(beta^2 + sinh^2 y)), the paper\'s (3.9)%s' % (ndat, ' [fault BETA]' if FAULT == 'BETA' else ''))
    ends = True
    for (a, r2) in ((Fr(2), Fr(1)), (Fr(3, 2), Fr(5)), (Fr(1), Fr(1, 4))):
        s = a; num = s * s * (a * a + r2) ** 2; den = (a ** 4 + s * s * r2) * (s * s + r2); ends &= num == den
    lim = all((s * s * (a2 + r2) ** 2 / ((a2 * a2 + s * s * r2) * (s * s + r2)) - s * s / (s * s + r2)) * ((a2 * a2 + s * s * r2) * (s * s + r2)) == s * s * r2 * (2 * a2 + r2 - s * s) for (a2, r2, s) in DATA)
    chk('bit', ends and lim, 'ends: cos^2 alpha has the factor s^2 (Theta -> pi at the centre) and equals 1 at s = a (Theta = 0 on the sphere at infinity of H^3, 3 data); cos^2 alpha - s^2/(s^2 + rho^2) = s^2 rho^2 (2 a^2 + rho^2 - s^2)/((a^4 + s^2 rho^2)(s^2 + rho^2)), of order a^-2: a -> infinity gives the line profile (3.4)')

    bnd_ok = True
    for (a2, r2, s) in DATA:
        for (av, lv) in ((Fr(1), Fr(1)), (Fr(2), Fr(1, 3)), (Fr(3, 2), Fr(5)), (Fr(7), Fr(7))):
            b = 2 * av * lv / (av * av + lv * lv); bnd_ok &= b <= 1 and (b == 1) == (av == lv) and av * av + lv * lv - 2 * av * lv == (av - lv) ** 2
    t_ok = all(((2 * t / (1 - t * t)) ** 2) / (1 + (2 * t / (1 - t * t)) ** 2) == (2 * t / (1 + t * t)) ** 2 for t in (Fr(1, 3), Fr(1, 2), Fr(2, 7)))
    chk('bit', bnd_ok and t_ok, 'the instanton family has beta = 2 a lambda/(a^2 + lambda^2) <= 1 ((a - lambda)^2 >= 0), with beta = 1 exactly for lambda = a, the instanton invariant under the circle action; then sinh^2 y/(1 + sinh^2 y) = tanh^2 y (exact at t = tanh(y/2) = 1/3, 1/2, 2/7): Theta = pi (1 - tanh y)')

    # ------------------------------------------------------------------------------------------ 1e. toroidal coordinates
    head('1e. the toroidal coordinates (3.5): R^4 minus the sphere |x| = 1/kappa, x4 = 0, is conformal to H^3 x S^1')
    def tor(t, p_, q_, tau, kap):
        """x = (1/kappa) (sinh y n, sin chi)/(cosh y + cos chi) with t = tanh(y/2), n = inverse stereographic image of (p, q), tau = tan(chi/2)"""
        sh = 2 * t / (1 - t * t); ch = (1 + t * t) / (1 - t * t); dn = 1 + p_ * p_ + q_ * q_
        n = [2 * p_ / dn, 2 * q_ / dn, (1 - p_ * p_ - q_ * q_) / dn]; sx = 2 * tau / (1 + tau * tau); cx = (1 - tau * tau) / (1 + tau * tau)
        den = kap * (ch + cx); return [sh * n[0] / den, sh * n[1] / den, sh * n[2] / den, sx / den], sh, ch, cx
    TP = [(Fr(1, 2), Fr(1, 3), Fr(-2), Fr(1, 4)), (Fr(-1, 3), Fr(2), Fr(1, 5), Fr(-3)), (Fr(2, 5), Fr(0), Fr(1), Fr(7, 3)), (Fr(3, 4), Fr(-1, 2), Fr(-1, 2), Fr(0)),
          (Fr(1, 7), Fr(3), Fr(2, 3), Fr(1, 2)), (Fr(-4, 5), Fr(1, 4), Fr(-3, 2), Fr(5))]
    conf_ok = True; npt = 0; power = 1 if FAULT == 'CONF' else 2
    for kap in (Fr(1), Fr(2, 3), Fr(3)):
        for (t0, p0, q0, tau0) in TP:
            vs = [D.var(t0, 0, 4), D.var(p0, 1, 4), D.var(q0, 2, 4), D.var(tau0, 3, 4)]
            X, sh, ch, cx = tor(*vs, kap)
            G = [[sum(X[k].g[i] * X[k].g[j] for k in range(4)) for j in range(4)] for i in range(4)]
            Om2 = 1 / (kap * kap * (ch.v + cx.v) ** power); dn = 1 + p0 * p0 + q0 * q0
            pred = [4 / (1 - t0 * t0) ** 2, 4 * sh.v ** 2 / dn ** 2, 4 * sh.v ** 2 / dn ** 2, 4 / (1 + tau0 * tau0) ** 2]
            conf_ok &= all(G[i][j] == (Om2 * pred[i] if i == j else 0) for i in range(4) for j in range(4)); npt += 1
    chk('bit', conf_ok, 'exact Jacobian (dual numbers) of (3.5) in the rational coordinates (t, p, q, tau) at %d points, kappa in {1, 2/3, 3}: dx.dx = (d rho^2 + sinh^2(kappa rho)/kappa^2 dOmega^2 + kappa^-2 dchi^2)/(cosh kappa rho + cos chi)^2, the paper\'s (3.6): H^3 of curvature -kappa^2 times a circle of radius 1/kappa%s' % (npt, ' [fault CONF: power 1]' if FAULT == 'CONF' else ''))
    circ_ok = True
    for kap in (Fr(1), Fr(2, 3)):
        for (t0, p0, q0, _) in TP[:4]:
            if t0 <= 0: continue
            a2 = 1 / (kap * kap); s = t0 / kap; c = (s + a2 / s) / 2; R = (a2 / s - s) / 2
            for tau in (Fr(0), Fr(1, 3), Fr(-2), Fr(5)):
                X, sh, ch, cx = tor(t0, p0, q0, tau, kap); dn = 1 + p0 * p0 + q0 * q0; n = [2 * p0 / dn, 2 * q0 / dn, (1 - p0 * p0 - q0 * q0) / dn]
                along = sum(X[i] * n[i] for i in range(3)); perp = [X[i] - along * n[i] for i in range(3)]
                circ_ok &= all(v == 0 for v in perp) and (along - c) ** 2 + X[3] ** 2 == R * R
            X0 = tor(t0, p0, q0, Fr(0), kap)[0]; circ_ok &= sum(v * v for v in X0[:3]) == s * s and X0[3] == 0
    chk('bit', circ_ok, 'the chi-circle of (3.5) at fixed (rho, n) lies in the plane of n and e4 and is the circle through s n and (a^2/s) n with a = 1/kappa, s = tanh(kappa rho/2)/kappa: the circles of 1d')
    sl_ok = True
    for t0 in (Fr(1, 3), Fr(1, 2), Fr(-2, 5), Fr(4, 5)):
        r = t0; hyp = 4 / (1 - r * r) ** 2                                                  # (cosh y + 1)^2 = 4/(1 - t^2)^2 on the slice chi = 0 (kappa = 1): H^3 = 4 |dx|^2/(1 - |x|^2)^2
        ch = (1 + t0 * t0) / (1 - t0 * t0); sl_ok &= (ch + 1) ** 2 == hyp
        rp = 2 * r; fk = 1 / (1 + Fr(-1) * rp * rp / 4)                                    # x' = 2 x: the k = -1 chart of b3c4_curved_points.py, spatial factor 1/(1 + k r^2/4)
        sl_ok &= hyp / 4 == fk * fk                                                         # |dx|^2 = |dx'|^2/4
    chk('bit', sl_ok, 'the slice chi = 0 (kappa = 1) carries 4 |dx|^2/(1 - |x|^2)^2, the Poincare ball of radius 1; with x\' = 2 x it is |dx\'|^2/(1 + k |x\'|^2/4)^2 with k = -1, the hyperbolic chart of b3c4_curved_points.py (4 points)')

    # ------------------------------------------------------------------------------------------ 2. degree and charge
    head('2. the degree of the holonomy field and the charge of the field')
    c_main = 2 if FAULT == 'DOUBLE' else 1; bar_main = FAULT == 'ANTI'
    def deg_line(bar=False, c=1):
        """U = exp(g xhat.B) with g = c theta (eta) or -c theta (eta-bar), theta: 0 -> pi; deg = SIG0 (g(inf) - g(0))/pi"""
        return SIG0 * (-c if bar else c)
    def charge(bar=False, c=1):
        """instanton number of c A: (3c^2 - 2c^3) N, N = +1 (eta, CAND-124) or -1 (eta-bar); from the Chern-Simons form at infinity of c g^-1 dg"""
        phi_end = Fr(c); cs = -phi_end ** 2 + Fr(2, 3) * phi_end ** 3; cs1 = Fr(-1) + Fr(2, 3)
        return (cs / cs1) * (-1 if bar else 1)
    deg_c = SIG0 * (0 - (-1))                                                               # circle: g = -Theta from -pi to 0
    Bsign = 1                                                                               # the baryon number is deg in the orientation (1, B_0, B_1, B_2); 4b compares it with the standard formula
    Bm_ = deg_line(bar_main, c_main) * Bsign; Nm_ = charge(bar_main, c_main)
    chk('bit', Bm_ == Nm_ == 1, 'line holonomy of CAND-124\'s instanton: baryon number deg = SIG0 (g(inf) - g(0))/pi = %s in the orientation (1, B_0, B_1, B_2) of the labels\' quaternions (g = theta: 0 -> pi), instanton number %s: B = N = 1%s' % (Bm_, Nm_, ' [fault %s]' % FAULT if FAULT in ('ANTI', 'DOUBLE') else ''))
    chk('bit', deg_c * Bsign == 1 and deg_line(True) * Bsign == -1 and charge(True) == -1, 'the circle holonomy (g = -Theta: -pi -> 0) has baryon number %d; the anti-instanton gives %d with instanton number %s' % (deg_c * Bsign, deg_line(True) * Bsign, charge(True)))
    chk('bit', charge(c=2) == -4 and deg_line(c=2) * Bsign == 2 and charge(c=0) == 0, 'the field c A: Chern-Simons value 3c^2 - 2c^3 = %s at c = 2 (1 at c = 1, 0 at c = 0) and holonomy baryon number c = %d: equal only at c = 0, 1; 2A is no instanton (ym_solutions.py: D*F != 0)' % (charge(c=2), deg_line(c=2) * Bsign))

    # ------------------------------------------------------------------------------------------ 3. tails
    head('3. the tails: the dipole solutions of the linearised equations of (2.3) and (2.7), exact')
    def lderiv(L): return {k - 1: v * k for k, v in L.items() if k != 0}
    def ladd(*ts):
        out = {}
        for c, L in ts:
            for k, v in L.items(): out[k] = out.get(k, 0) + c * v
        return {k: v for k, v in out.items() if v != 0}
    def lmul(L, M):
        out = {}
        for i, a in L.items():
            for j, b in M.items(): out[i + j] = out.get(i + j, 0) + a * b
        return {k: v for k, v in out.items() if v != 0}
    def eu_resid(m, L):
        """f = e^(-m r) L(r) (L a Laurent polynomial): (r^2 f')' - (2 + m^2 r^2) f as e^(-m r) times a Laurent polynomial"""
        d1 = ladd((1, lderiv(L)), (-m, L)); r2d1 = lmul({2: Fr(1)}, d1); d2 = ladd((1, lderiv(r2d1)), (-m, r2d1))
        return ladd((1, d2), (-1, lmul({0: Fr(2), 2: m * m}, L)))
    eu_ok = all(not eu_resid(Fr(m), {-2: Fr(1), -1: Fr(m)}) for m in (0, 1, Fr(3, 2), 2, 3, Fr(526, 1000)))
    def hy_der(P):
        """d/dy on sums of S^i C^j (j in {0, 1}), S = sinh y, C = cosh y, C^2 = 1 + S^2"""
        out = {}
        def put(i, j, v):
            if j == 2: put(i, 0, v); put(i + 2, 0, v); return
            out[(i, j)] = out.get((i, j), 0) + v
        for (i, j), v in P.items():
            if i: put(i - 1, j + 1, v * i)
            if j: put(i + 1, j - 1, v * j)
        return {k: v for k, v in out.items() if v != 0}
    Fh = {(-2, 0): Fr(1)}; S2F = {(i + 2, j): v for (i, j), v in hy_der(Fh).items()}
    hy_ok = hy_der(S2F) == {(-2, 0): Fr(2)}                                                 # (S^2 F_y)_y = 2 F
    Fbad = {(-1, 0): Fr(1)}; S2b = {(i + 2, j): v for (i, j), v in hy_der(Fbad).items()}; hy_bad = hy_der(S2b) != {(-1, 0): Fr(2)}
    chk('bit', eu_ok and hy_ok and hy_bad, 'exact: f = (1 + m r) e^(-m r)/r^2 solves (r^2 f\')\' = (2 + m^2 r^2) f (the linearised (2.3), m in {0, 1, 3/2, 2, 3, 0.526}); F = 1/sinh^2(kappa rho) solves (S^2 F\')\' = 2 kappa^2 F (the linearised (2.7), S = sinh(kappa rho)); 1/sinh is no solution')
    m_t = Fr(2); kap_t = m_t if FAULT == 'KAPPA' else m_t / 2
    Lr = {-2: Fr(1), -1: m_t}; Lp = lderiv(Lr)                                              # f'/f = -m + L'/L with L'/L = (-2 - m r)/(r (1 + m r)) -> 0
    lp_ok = Lp == {-3: Fr(-2), -2: -m_t}
    rate_eu = m_t; rate_hy = 2 * kap_t                                                      # F'/F = -2 kappa C/S, C/S -> 1
    chk('bit', lp_ok and rate_eu == rate_hy, 'the rates: f\'/f = -m + L\'/L with L\'/L = %s/(r (1 + m r)) -> 0, and F\'/F = -2 kappa coth(kappa rho) -> -2 kappa: at m = %s the rates agree for kappa = %s = m/2 (the paper\'s kappa = m/2 from (2.4) and (2.8))%s' % ('(-2 - m r)', m_t, kap_t, ' [fault KAPPA: kappa = m]' if FAULT == 'KAPPA' else ''))
    # y = (1 + e)^(-1/2): 1 - e/2 <= y <= 1 - e/2 + 3 e^2/8 (0 < e <= 1), compared through squares: (1 + e)(1 - e/2)^2 <= 1 <= (1 + e)(1 - e/2 + 3 e^2/8)^2
    eps_ = [Fr(1, k) for k in (1, 2, 3, 7, 10, 100, 1000, 10 ** 6)]
    tl_ok = all((1 + e) * (1 - e / 2) ** 2 <= 1 <= (1 + e) * (1 - e / 2 + 3 * e * e / 8) ** 2 for e in eps_)
    chk('bit', tl_ok, 'exact for e in {1, 1/2, 1/3, 1/7, 1/10, 1/100, 1/1000, 10^-6}: e/2 - 3 e^2/8 <= 1 - (1 + e)^(-1/2) <= e/2; with e = rho^2/r^2 (lines) and beta^2/sinh^2(kappa rho) (circles) the profiles tend to (pi rho^2/2)/r^2 and (pi beta^2/2)/sinh^2(kappa rho), the massless dipoles of R^3 and of H^3')

    # ------------------------------------------------------------------------------------------ 4. std: holonomies by path-ordered products
    head('4. [std] numpy: path-ordered holonomies of the closed-form fields, never the labels')
    T = [-0.5j * s for s in SIG]
    def eta_np(bar=False):
        e = np.zeros((3, 4, 4))
        for a in range(3):
            for i in range(3):
                for j in range(3): e[a, i, j] = eps3(a, i, j)
                s = -1 if bar else 1; e[a, i, 3] = s * (a == i); e[a, 3, i] = -s * (a == i)
        return e
    EN, ENB = eta_np(), eta_np(True)
    def A_reg(x, rho2, bar=False, c=1.0):
        e = ENB if bar else EN; Aa = 2 * c * np.einsum('amn,n->am', e, x) / (x @ x + rho2)     # A^a_mu
        return [sum(Aa[a, mu] * T[a] for a in range(3)) for mu in range(4)]
    SMN = [[None] * 4 for _ in range(4)]                                                     # the paper's sigma_mu nu: sigma_i4 = tau_i, sigma_ij = eps_ijk tau_k
    for i in range(4):
        for j in range(4):
            if i < 3 and j < 3: SMN[i][j] = sum(eps3(i, j, k) * SIG[k] for k in range(3))
            elif i < 3 and j == 3: SMN[i][j] = SIG[i]
            elif i == 3 and j < 3: SMN[i][j] = -SIG[j]
            else: SMN[i][j] = np.zeros((2, 2), complex)
    def A_thooft(x, lam2):
        """(3.2)-(3.3): A_mu = (i/2) sigma_mu nu d_nu log zeta, zeta = 1 + lambda^2/x^2"""
        x2 = x @ x; dlog = -2 * lam2 * x / (x2 * (x2 + lam2))
        return [0.5j * sum(SMN[mu][nu] * dlog[nu] for nu in range(4)) for mu in range(4)]
    def holonomy(Af, path, dpath, s0, s1, N, sign=-1):
        """P exp(sign int A(xdot) ds) by N midpoint steps of matrix exponentials (later steps on the left)"""
        U = np.eye(2, dtype=complex); h = (s1 - s0) / N
        for k in range(N):
            s = s0 + (k + 0.5) * h; x = path(s); v = dpath(s); A = Af(x)
            M = sum(A[mu] * v[mu] for mu in range(4)); U = linalg.expm(sign * M * h) @ U
        return U
    def rotor(g, nv): return math.cos(g) * I2 + math.sin(g) * sum(nv[a] * Bm[a] for a in range(3))   # exp(g n.B) in matrices
    def line(xv): return (lambda u: np.array([xv[0], xv[1], xv[2], math.tan(u)]), lambda u: np.array([0, 0, 0, 1 / math.cos(u) ** 2]))
    Nst = 1200; worst_l = 0.0; worst_sign = 0.0; worst_b = 0.0; worst_2 = 0.0; worst_th = 0.0; worst_0 = 0.0
    rngn = np.random.default_rng(174)
    for (xv, r2) in [((1, 2, 2), 16.0), ((2, 3, 6), 576.0), ((0, 3, 4), 144.0)] + [(tuple(rngn.uniform(-2, 2, 3)), float(rngn.uniform(0.3, 3))) for _ in range(4)]:
        xv = np.array(xv, float); r = np.linalg.norm(xv); nv = xv / r; th = PI * r / math.sqrt(r * r + r2); f = PI - th
        P, dP = line(xv)
        U = holonomy(lambda x: A_reg(x, r2), P, dP, -PI / 2, PI / 2, Nst)
        Ub = holonomy(lambda x: A_reg(x, r2, True), P, dP, -PI / 2, PI / 2, Nst)
        U2 = holonomy(lambda x: A_reg(x, r2, False, 2.0), P, dP, -PI / 2, PI / 2, Nst)
        worst_l = max(worst_l, np.max(np.abs(U - rotor(th, nv)))); worst_b = max(worst_b, np.max(np.abs(Ub - rotor(-th, nv)))); worst_2 = max(worst_2, np.max(np.abs(U2 - rotor(2 * th, nv))))
        ref = rotor(-f, nv) if FAULT == 'NOSIGN' else -rotor(-f, nv)
        worst_sign = max(worst_sign, np.max(np.abs(U - ref)))
        Ut = holonomy(lambda x: A_thooft(x, r2), P, dP, -PI / 2 + 1e-9, PI / 2 - 1e-9, Nst, sign=+1)
        worst_th = max(worst_th, np.max(np.abs(Ut - linalg.expm(1j * f * sum(nv[a] * SIG[a] for a in range(3))))))
        dvec = rngn.normal(size=4); P0 = (lambda u, d=dvec: d * math.tan(u)); dP0 = (lambda u, d=dvec: d / math.cos(u) ** 2)
        worst_0 = max(worst_0, np.max(np.abs(holonomy(lambda x: A_reg(x, r2), P0, dP0, -PI / 2 + 1e-6, PI / 2 - 1e-6, 200) - I2)))
    chk('std', worst_l < 1e-9 and worst_b < 1e-9 and worst_2 < 1e-9, 'lines (7: the 3 Pythagorean ones and 4 random), %d path-ordered steps: U = exp(theta n.B) (%.1e), eta-bar exp(-theta n.B) (%.1e), 2A exp(2 theta n.B) (%.1e), theta = pi r/sqrt(r^2 + rho^2)' % (Nst, worst_l, worst_b, worst_2))
    chk('bit==std', worst_sign < 1e-9, 'the regular-gauge line holonomy is -exp(-f n.B) = -exp(i f n.sigma) with the paper\'s f of (3.4) (max deviation %.1e): the central -1 of the regular gauge, singular at the point at infinity that the lines pass%s' % (worst_sign, ' [fault NOSIGN]' if FAULT == 'NOSIGN' else ''))
    chk('std', worst_th < 1e-7, 'the paper\'s (3.1)-(3.3) taken literally (A_mu = (i/2) sigma_mu nu d_nu log zeta, U = P exp(+int A_4 dx_4)): U = exp(i f(r) xhat.tau) with f of (3.4), f(0) = pi, f(inf) = 0 (max deviation %.1e)' % worst_th)
    chk('std', worst_0 < 1e-12, 'lines through the centre in 7 random directions: holonomy = 1 (max deviation %.1e)' % worst_0)
    # circles, numerically, and the closed form of 1d
    worst_c = 0.0; worst_ct = 0.0; worst_q = 0.0; cdat = []
    for (a2, r2, s) in [(1.0, 1.0, 1 / 3), (4.0, 4.0, 1.0), (5.0, 16.0, 5 / 3), (9.0, 4.0, 0.5), (2.0, 0.7, 0.9), (0.5, 3.0, 0.2)]:
        c = (s + a2 / s) / 2; R = (a2 / s - s) / 2; A_ = c * c + R * R + r2; B_ = 2 * c * R; p, q = A_ + B_, A_ - B_
        half = 0.5 if FAULT == 'INTEGRAL' else 1.0
        Th = PI * (1 - half * (a2 + r2) / math.sqrt(p * q))                              # closed integral pi/sqrt(pq) (INTEGRAL: pi/(2 sqrt(pq)))
        nv = np.array([2 / 7, 3 / 7, 6 / 7])
        P = lambda ps: np.concatenate([(c + R * math.cos(ps)) * nv, [-R * math.sin(ps)]]); dP = lambda ps: np.concatenate([-R * math.sin(ps) * nv, [-R * math.cos(ps)]])
        U = holonomy(lambda x: A_reg(x, r2), P, dP, 0.0, 2 * PI, Nst)
        worst_c = max(worst_c, np.max(np.abs(U - rotor(-Th, nv))))
        Ut = holonomy(lambda x: A_thooft(x, r2), P, dP, 0.0, 2 * PI, Nst, sign=+1)          # the paper's (3.7): P exp(+int A_chi dchi)
        worst_ct = max(worst_ct, np.max(np.abs(Ut - rotor(-Th, nv))))
        gq = lambda tau: (1 / (1 + tau * tau) - (a2 + r2) / (p + q * tau * tau))
        val = integrate.quad(gq, -np.inf, np.inf, epsabs=1e-13, epsrel=1e-12)[0]
        worst_q = max(worst_q, abs(val - Th)); cdat.append('%.6f' % (Th / PI))
    chk('bit==std', worst_c < 1e-9 and worst_q < 1e-9, 'circles (6 data, %d steps): the path-ordered holonomy of the regular gauge = exp(-Theta n.B) with Theta/pi = 1 - (a^2 + rho^2)/sqrt(pq) = %s (max deviation %.1e); quad of the reduced integrand = Theta (%.1e)%s' % (Nst, cdat, worst_c, worst_q, ' [fault INTEGRAL]' if FAULT == 'INTEGRAL' else ''))
    chk('std', worst_ct < 1e-7, 'the paper\'s \'t Hooft field (3.2) with its (3.7), P exp(+int A dchi), gives the same holonomy along these circles (max deviation %.1e): no gauge fixing is needed, the field on the plane of n and e4 lies on n.B (the paper: A_rho and A_chi have the same direction)' % worst_ct)
    # duality of the paper's sigma and of its field
    EPS4 = np.zeros((4, 4, 4, 4))
    for pp in itertools.permutations(range(4)):
        sg = 1
        for i in range(4):
            for j in range(i + 1, 4):
                if pp[i] > pp[j]: sg = -sg
        EPS4[pp] = sg
    sd_sig = max(np.max(np.abs(SMN[m][n] - 0.5 * sum(EPS4[m, n, r, s_] * SMN[r][s_] for r in range(4) for s_ in range(4)))) for m in range(4) for n in range(4))
    def Fnum(Af, x, h=1e-4):
        dA = [[None] * 4 for _ in range(4)]
        for m in range(4):
            e_ = np.zeros(4); e_[m] = h; Ap = Af(x + e_); Am = Af(x - e_); Ap2 = Af(x + 2 * e_); Am2 = Af(x - 2 * e_)
            for n in range(4): dA[m][n] = (-Ap2[n] + 8 * Ap[n] - 8 * Am[n] + Am2[n]) / (12 * h)
        A0 = Af(x); return [[dA[m][n] - dA[n][m] + A0[m] @ A0[n] - A0[n] @ A0[m] for n in range(4)] for m in range(4)]
    xt = np.array([0.4, -0.7, 0.3, 0.5]); Ft = Fnum(lambda x: A_thooft(x, 2.0), xt)
    sdF = max(np.max(np.abs(Ft[m][n] - 0.5 * sum(EPS4[m, n, r, s_] * Ft[r][s_] for r in range(4) for s_ in range(4)))) for m in range(4) for n in range(4))
    asdF = max(np.max(np.abs(Ft[m][n] + 0.5 * sum(EPS4[m, n, r, s_] * Ft[r][s_] for r in range(4) for s_ in range(4)))) for m in range(4) for n in range(4))
    Fr_ = Fnum(lambda x: A_reg(x, 2.0), xt)
    sdR = max(np.max(np.abs(Fr_[m][n] - 0.5 * sum(EPS4[m, n, r, s_] * Fr_[r][s_] for r in range(4) for s_ in range(4)))) for m in range(4) for n in range(4))
    chk('std', sd_sig < 1e-15 and asdF < 1e-7 and sdF > 0.1 and sdR < 1e-7, 'orientation eps_1234 = +1: the paper\'s sigma_mu nu (sigma_i4 = tau_i, sigma_ij = eps_ijk tau_k) is self-dual (%.0e) and its field (3.2) with F = dA + [A, A] is anti-self-dual (%.1e; F - *F = %.2f), while CAND-124\'s field is self-dual (%.1e): the paper\'s word anti-self-dual fits the orientation with x4 first, and its P exp(+int A) is the transport of the inverse orientation of the line' % (sd_sig, asdF, sdF, sdR))

    # ------------------------------------------------------------------------------------------ 4b. std: baryon number and instanton number by quadrature
    head('4b. [std] the baryon number -(1/24 pi^2) int eps_ijk Tr(R_i R_j R_k) d^3x and the instanton number of c A by quadrature')
    def Bnum(Ufield, rmap, nr=56, nt=20, nph=20, h=1e-5):
        qg, qw = np.polynomial.legendre.leggauss(nr); qg = 0.5 * (qg + 1); qw = 0.5 * qw
        tg, tw = np.polynomial.legendre.leggauss(nt); tg = 0.5 * PI * (tg + 1); tw = 0.5 * PI * tw
        ph = np.arange(nph) * 2 * PI / nph; pw = 2 * PI / nph; total = 0.0
        for qi, wq in zip(qg, qw):
            r, drdq = rmap(qi)
            for ti, wt in zip(tg, tw):
                for pi_ in ph:
                    x = r * np.array([math.sin(ti) * math.cos(pi_), math.sin(ti) * math.sin(pi_), math.cos(ti)])
                    U0 = Ufield(x); Ui = U0.conj().T; Rs = []
                    for i in range(3):
                        e_ = np.zeros(3); e_[i] = h; Rs.append((Ufield(x + e_) - Ufield(x - e_)) / (2 * h) @ Ui)
                    dens = np.trace(Rs[0] @ (Rs[1] @ Rs[2] - Rs[2] @ Rs[1])).real * 3
                    total += dens * r * r * math.sin(ti) * drdq * wq * wt * pw
        return -total / (24 * PI * PI)
    lam2 = 2.11; inf_map = lambda q_, sc=2.0: (sc * q_ / (1 - q_), sc / (1 - q_) ** 2)
    def hedge(gfun, sgn_B=1.0):
        def U(x):
            r = np.linalg.norm(x); g = gfun(r); nv = x / r
            return math.cos(g) * I2 + math.sin(g) * sum(nv[a] * Bm[a] for a in range(3)) * sgn_B
        return U
    thf = lambda r: PI * r / math.sqrt(r * r + lam2)
    def U_paper(x):
        r = np.linalg.norm(x); nv = x / r; f = PI * (1 - r / math.sqrt(r * r + lam2))
        return math.cos(f) * I2 + 1j * math.sin(f) * sum(nv[a] * SIG[a] for a in range(3))          # exp(i f n.sigma)
    B_paper = Bnum(U_paper, inf_map)
    B_eta = Bnum(hedge(lambda r: (-thf(r) if FAULT == 'ANTI' else (2 * thf(r) if FAULT == 'DOUBLE' else thf(r)))), inf_map)
    B_bar = Bnum(hedge(lambda r: -thf(r)), inf_map); B_two = Bnum(hedge(lambda r: 2 * thf(r)), inf_map)
    kap = 1.0; a_ = 1 / kap; rho2c = 0.6
    def Theta_s(s):
        c = (s + a_ * a_ / s) / 2; R = (a_ * a_ / s - s) / 2; A_ = c * c + R * R + rho2c; B_ = 2 * c * R
        return PI * (1 - (a_ * a_ + rho2c) / math.sqrt((A_ + B_) * (A_ - B_)))
    B_circ = Bnum(hedge(lambda s: -Theta_s(max(s, 1e-12))), lambda q_: (a_ * q_, a_), nr=48)
    chk('std', abs(B_paper - 1) < 1e-4, 'the paper\'s U = exp(i f xhat.tau) with (3.4), lambda^2 = 2.11: baryon number %.6f by quadrature (56 x 20 x 20 points, central differences)' % B_paper)
    chk('bit==std', abs(B_eta - 1) < 1e-4 and abs(B_eta - Bsign * deg_line()) < 1e-4, 'CAND-124\'s field: the standard baryon number of exp(theta n.B) (matrices -i sigma_a) is %.6f = the exact degree %d of part 2 = instanton number 1: the two orientations agree and B = N in the conventions of the labels (eps_1234 = +1, F = dA + A^A, transport P exp(-int A) along +e4)%s' % (B_eta, Bsign * deg_line(), ' [fault %s]' % FAULT if FAULT in ('ANTI', 'DOUBLE') else ''))
    chk('bit==std', abs(B_bar + 1) < 1e-4 and abs(B_two - 2) < 1e-4 and abs(B_circ - 1) < 1e-4, 'anti-instanton %.6f, the field 2A %.6f, the circle field on the ball |x| < 1/kappa (kappa = 1, rho^2 = 0.6) %.6f: the exact degrees -1, 2, 1 of part 2' % (B_bar, B_two, B_circ))
    def q_density(c, r, bar=False, h=1e-4):
        x = np.array([0.3, -0.5, 0.7, 0.2]); x = r * x / np.linalg.norm(x)
        Fm = Fnum(lambda y: A_reg(y, 1.0, bar, c), x, h)
        Fa = np.array([[[(-2 * np.trace(Fm[m][n] @ T[a])).real for n in range(4)] for m in range(4)] for a in range(3)])
        Fd = 0.5 * np.einsum('mnrs,ars->amn', EPS4, Fa); return 0.5 * np.sum(Fa * Fd)
    def Nnum(c, bar=False):
        f_ = lambda u: (lambda r: 2 * PI * PI * r ** 3 * q_density(c, r, bar) / (16 * PI * PI))(math.tan(u)) / math.cos(u) ** 2
        return integrate.quad(f_, 1e-6, PI / 2 - 1e-6, limit=200, epsabs=1e-9)[0]
    N1, N2, Nb = Nnum(1.0), Nnum(2.0), Nnum(1.0, True)
    chk('std', abs(N1 - 1) < 1e-5 and abs(N2 + 4) < 1e-4 and abs(Nb + 1) < 1e-5, 'instanton number (1/16 pi^2) int (1/2) F^a F~^a d^4x by radial quadrature of finite-difference curvatures (rho^2 = 1): c = 1: %.6f, c = 2: %.6f, eta-bar: %.6f; the exact 3c^2 - 2c^3 and -1 of part 2' % (N1, N2, Nb))
    # the toroidal pullback numerically, in the paper's angles
    worst_t = 0.0
    def torx(v, k):
        rho, th, ph, chi = v; den = k * (math.cosh(k * rho) + math.cos(chi)); sh = math.sinh(k * rho)
        return np.array([sh * math.sin(th) * math.cos(ph), sh * math.sin(th) * math.sin(ph), sh * math.cos(th), math.sin(chi)]) / den
    for k in (1.0, 0.5, 2.0):
        for _ in range(5):
            v = np.array([rngn.uniform(0.1, 2.5) / k, rngn.uniform(0.2, 2.9), rngn.uniform(0, 6.2), rngn.uniform(-3, 3)]); hh = 1e-6
            J = np.array([(torx(v + hh * np.eye(4)[j], k) - torx(v - hh * np.eye(4)[j], k)) / (2 * hh) for j in range(4)]).T
            G = J.T @ J; sh = math.sinh(k * v[0]); cf = 1 / (math.cosh(k * v[0]) + math.cos(v[3])) ** 2
            pred = cf * np.diag([1.0, sh * sh / k ** 2, sh * sh * math.sin(v[1]) ** 2 / k ** 2, 1 / k ** 2])
            worst_t = max(worst_t, np.max(np.abs(G - pred)) / np.max(np.abs(pred)))
    chk('std', worst_t < 1e-8, 'the paper\'s (3.5) in its angles, Jacobian by central differences at 15 random points, kappa in {1, 1/2, 2}: dx.dx = (ds^2(H^3) + kappa^-2 dchi^2)/(cosh kappa rho + cos chi)^2 (relative %.1e)' % worst_t)

    # ------------------------------------------------------------------------------------------ 5. std: the paper's numbers
    head('5. [std] the paper\'s numbers from the hedgehog energies (2.3) and (2.7) (no row of the Atlas holds the Skyrme energy)')
    def E_eu(f, fp, r, m):
        return (r * r * fp * fp + 2 * (fp * fp + 1) * np.sin(f) ** 2 + np.sin(f) ** 4 / (r * r) + 2 * m * m * r * r * (1 - np.cos(f))) / (3 * PI)
    def E_prof(ffun, fpfun, m, rmax=np.inf):
        return integrate.quad(lambda r: E_eu(ffun(r), fpfun(r), r, m), 1e-9, rmax, limit=400, epsabs=1e-11, epsrel=1e-11)[0]
    def E_inst(l2, m=0.0): return E_prof(lambda r: PI * (1 - r / math.sqrt(r * r + l2)), lambda r: -PI * l2 / (r * r + l2) ** 1.5, m)
    opt = optimize.minimize_scalar(E_inst, bounds=(1.0, 4.0), method='bounded', options={'xatol': 1e-6})
    def solve_eu(m, L=None):
        L = L or (60.0 if m == 0 else 14.0 + 6.0 / max(m, 0.5)); r0 = 1e-3
        def fun(r, y):
            f, fp = y; s, s2 = np.sin(f), np.sin(2 * f)
            return np.vstack([fp, (-2 * r * fp - s2 * fp * fp + s2 * (1 + s * s / (r * r)) + m * m * r * r * s) / (r * r + 2 * s * s)])
        def bc(ya, yb):
            Dl = (m / (1 + m * L) - m - 2 / L) if m > 0 else -2 / L
            return np.array([ya[0] - r0 * ya[1] - PI, yb[1] - Dl * yb[0]])
        rr = np.concatenate([np.linspace(r0, 3, 300), np.linspace(3, L, 400)[1:]]); y0 = np.vstack([PI * (1 - rr / np.sqrt(rr * rr + 2)), -PI * 2 / (rr * rr + 2) ** 1.5])
        sol = integrate.solve_bvp(fun, bc, rr, y0, tol=1e-9, max_nodes=200000)
        E = integrate.quad(lambda r: E_eu(*sol.sol(r), r, m), r0, L, limit=800, epsabs=1e-12, epsrel=1e-11)[0]
        if m == 0: Afit = sol.sol(L)[0] * L * L; E += 2 * Afit * Afit / (3 * PI * L ** 3)      # the tail of r^2 f'^2 + 2 sin^2 f ~ 6 A^2/r^4 beyond L, over 3 pi
        return sol, E
    def solve_hy(k, L=None):
        L = L or 16.0 / max(k, 0.25); r0 = 1e-3
        def fun(r, y):
            F_, Fp = y; S, C = np.sinh(k * r), np.cosh(k * r); s, s2 = np.sin(F_), np.sin(2 * F_)
            return np.vstack([Fp, (-2 * S * C / k * Fp - s2 * Fp * Fp + s2 * (1 + k * k * s * s / (S * S))) / (S * S / (k * k) + 2 * s * s)])
        def bc(ya, yb): return np.array([ya[0] - r0 * ya[1] - PI, yb[1] + 2 * k * (1 / math.tanh(k * L)) * yb[0]])
        rr = np.concatenate([np.linspace(r0, 3, 300), np.linspace(3, L, 300)[1:]]); b0 = 1.4 * k; Sg = np.sinh(k * rr)
        y0 = np.vstack([PI * (1 - Sg / np.sqrt(b0 * b0 + Sg * Sg)), -PI * b0 * b0 * k * np.cosh(k * rr) / (b0 * b0 + Sg * Sg) ** 1.5])
        return integrate.solve_bvp(fun, bc, rr, y0, tol=1e-9, max_nodes=200000)
    sol0, E0 = solve_eu(0.0)
    chk('std', abs(opt.x - 2.11) < 0.01 and abs(opt.fun - 1.243) < 0.0006, 'the line profile (3.4), m = 0: the energy (2.3) is least at lambda^2 = %.4f with E = %.5f (the paper: lambda^2 = 2.11, E = 1.243)' % (opt.x, opt.fun))
    chk('std', sol0.status == 0 and abs(E0 - 1.2315) < 0.0005 and 0.005 < opt.fun / E0 - 1 < 0.015, 'the massless Skyrmion by solve_bvp: E = %.5f (recalled 1.2315); the instanton approximation lies %.2f %% above it (the paper: around 1 %%)' % (E0, 100 * (opt.fun / E0 - 1)))
    def E_sol(sol, m, k): return integrate.quad(lambda r: E_eu(*sol.sol(r), r, m), 1e-3, min(16.0 / max(k, 0.25), 40.0), limit=800, epsabs=1e-12, epsrel=1e-11)[0]
    def Ebeta(b, k, m):
        """the Euclidean energy (2.3) at mass m of the profile (3.9), F = pi (1 - S/sqrt(b^2 + S^2)), S = sinh(kappa r) (b = kappa beta in the paper's units)"""
        Ff = lambda r: PI * (1 - np.sinh(k * r) / np.sqrt(b * b + np.sinh(k * r) ** 2))
        Fp = lambda r: -PI * b * b * k * np.cosh(k * r) / (b * b + np.sinh(k * r) ** 2) ** 1.5
        return E_prof(Ff, Fp, m, 60.0 / max(k, 0.3))
    rows = []; bvp_ok = True; R = {}
    for m in (1.0, 2.0, 3.0):
        solm, Em = solve_eu(m); rstar = optimize.brentq(lambda r: solm.sol(r)[0] - PI / 2, 0.05, 5.0)
        km = optimize.brentq(lambda k: solve_hy(k).sol(rstar)[0] - PI / 2, 0.05, 4.0, xtol=1e-7); sh = solve_hy(km); sh_half = solve_hy(m / 2)
        exc_h = 100 * (E_sol(sh, m, km) / Em - 1); exc_half = 100 * (E_sol(sh_half, m, m / 2) / Em - 1)
        ob = optimize.minimize_scalar(lambda b: Ebeta(b, km, m), bounds=(0.05, 5.0), method='bounded', options={'xatol': 1e-6})
        oc = optimize.minimize_scalar(lambda b: Ebeta(b, km, m), bounds=(0.05, 1.0), method='bounded', options={'xatol': 1e-6})
        oj = optimize.minimize_scalar(lambda k: Ebeta(1.0, k, m), bounds=(0.2, 4.0), method='bounded', options={'xatol': 1e-6})
        ojb = optimize.minimize_scalar(lambda b: Ebeta(b, oj.x, m), bounds=(0.05, 1.0), method='bounded', options={'xatol': 1e-6})
        R[m] = dict(Em=Em, rstar=rstar, km=km, exc_h=exc_h, exc_half=exc_half, bfree=ob.x, exc_free=100 * (ob.fun / Em - 1), exc_con=100 * (oc.fun / Em - 1),
                    kj=oj.x, exc_j=100 * (oj.fun / Em - 1), bj=ojb.x)
        bvp_ok &= solm.status == 0 and sh.status == 0 and sh_half.status == 0
        rows.append('m = %g: r* = %.4f, E = %.5f, kappa(m) = %.4f = %.3f (m/2)' % (m, rstar, Em, km, km / (m / 2)))
    exc0 = 100 * (opt.fun / E0 - 1); ms = (1.0, 2.0, 3.0)
    chk('std', bvp_ok and all(R[m]['km'] > m / 2 for m in ms) and R[1.0]['km'] / 0.5 > R[2.0]['km'] / 1.0 > R[3.0]['km'] / 1.5 > 1, 'equal sizes (f(r*) = pi/2 = F(r*)): %s; kappa(m) lies above the tail estimate kappa = m/2, the ratio falling towards 1 (the paper: reasonably close to m/2; its Fig. 3 is not readable in the OCR)' % '; '.join(rows))
    chk('std', all(0 <= R[m]['exc_h'] < 0.1 < R[m]['exc_half'] for m in ms), 'the hyperbolic Skyrmion F(rho = r) has a Euclidean energy within 0.1 %% of the Skyrmion of mass m at kappa(m) (excess %s %%; the paper: always less than 0.1 %%), and more than 0.1 %% above it at kappa = m/2 (%s %%)' % (['%.4f' % R[m]['exc_h'] for m in ms], ['%.3f' % R[m]['exc_half'] for m in ms]))
    chk('std', all(R[m]['exc_free'] < exc0 for m in ms) and R[1.0]['exc_free'] > R[2.0]['exc_free'] < R[3.0]['exc_free'], 'the profile (3.9) at kappa(m) with beta free: least excess %.3f %% (m = 0, lines), %s %% (m = 1, 2, 3), at beta = %s; below the massless value at every m (the paper: the error is always less than with massless pions), falling to m = 2 and rising from m = 2 to m = 3' % (exc0, ['%.3f' % R[m]['exc_free'] for m in ms], ['%.3f' % R[m]['bfree'] for m in ms]))
    chk('std', R[1.0]['bfree'] < 1 < R[2.0]['bfree'] < R[3.0]['bfree'] and R[2.0]['exc_con'] > 4 * exc0 and R[3.0]['exc_con'] > 10 * exc0, 'the instanton holonomies have beta <= 1 (1d: beta = 2 a lambda/(a^2 + lambda^2)); the free minimum needs beta = %.3f and %.3f at m = 2 and 3, beyond them; with beta <= 1 at kappa(m) the least excess is %s %% at m = 1, 2, 3' % (R[2.0]['bfree'], R[3.0]['bfree'], ['%.3f' % R[m]['exc_con'] for m in ms]))
    chk('std', all(abs(R[m]['bj'] - 1) < 1e-3 for m in ms) and R[1.0]['exc_j'] < exc0 < R[2.0]['exc_j'] < R[3.0]['exc_j'], 'beta = 1 (the circle-invariant instanton, F = pi (1 - tanh kappa r)) with kappa chosen by energy: kappa = %s, excess %s %% at m = 1, 2, 3, and at that kappa the least excess over beta <= 1 is at beta = 1; below the massless %.3f %% at m = 1, above it at m = 2 and 3 (the full (kappa, beta) plane is not searched)' % (['%.3f' % R[m]['kj'] for m in ms], ['%.3f' % R[m]['exc_j'] for m in ms], exc0))

    # ------------------------------------------------------------------------------------------ 6. controls
    head('6. controls: each wrong version fails (with --fault NAME it goes into the main line above)')
    chk('ctl', deg_line(True) * Bsign != 1 and abs(B_bar - 1) > 1, 'ANTI: the anti-instanton\'s holonomy has baryon number -1 (exact %d, quadrature %.4f): the line "B = N = 1" fails for it' % (deg_line(True) * Bsign, B_bar))
    wrongp = [1 - 1 / (1 + Fr(r2) / Fr(sum(c * c for c in xv))) for (xv, r2) in PYTH]
    chk('ctl', all(w != 1 - qsqrt(sum(c * c for c in xv)) / qsqrt(sum(c * c for c in xv) + r2) for w, (xv, r2) in zip(wrongp, PYTH)), 'PROFILE: the exponent -1 in place of -1/2 gives f/pi = %s at the Pythagorean data, not the holonomy' % [str(w) for w in wrongp])
    n0 = np.array([1.0, 2.0, 2.0]) / 3; th0 = PI * 3 / 5; dev0 = np.max(np.abs(rotor(th0, n0) - rotor(-(PI - th0), n0)))
    chk('ctl', dev0 > 0.5, 'NOSIGN: without the central -1 the regular-gauge line holonomy exp(theta n.B) differs from exp(-f n.B) by %.2f in a matrix entry at r = 3, rho = 4 (the regular gauge is singular at the point at infinity)' % dev0)
    a2, r2, s = DATA[2]; bad = True
    for tau in TAUS[:6]:
        k, g, _ = g_cw(UNITS[0], a2, r2, s, tau, Fr(1, 7)); c, R, p, q = circle_data(a2, r2, s, Fr(1, 7))
        bad &= g != 1 / (1 + tau * tau) - (a2 + r2) / (p + q * tau * tau)
    chk('ctl', bad, 'NONORTH: a circle with its centre moved by 1/7 (c^2 - R^2 != a^2) does not reduce to 1/(1 + tau^2) - (a^2 + rho^2)/(p + q tau^2): no orbit of the circle action')
    a2, r2, s = DATA[3]; c, R, p, q = circle_data(a2, r2, s); sh2 = 4 * a2 * s * s / (a2 - s * s) ** 2
    chk('ctl', (a2 + r2) ** 2 / (p * q) != sh2 / (a2 * r2 / (a2 + r2) ** 2 + sh2), 'BETA: beta = a rho/(a^2 + rho^2) fails the identity with (3.9)')
    a2f, r2f, sf = 2.0, 0.7, 0.9; cf = (sf + a2f / sf) / 2; Rf = (a2f / sf - sf) / 2; Af = cf * cf + Rf * Rf + r2f; Bf = 2 * cf * Rf
    chk('ctl', abs(PI * (1 - 0.5 * (a2f + r2f) / math.sqrt((Af + Bf) * (Af - Bf))) - integrate.quad(lambda t: 1 / (1 + t * t) - (a2f + r2f) / ((Af + Bf) + (Af - Bf) * t * t), -np.inf, np.inf)[0]) > 0.1, 'INTEGRAL: pi/(2 sqrt(pq)) for the closed integral disagrees with quad')
    chk('ctl', charge(c=2) != deg_line(c=2) * Bsign and abs(N2 - B_two) > 1, 'DOUBLE: for 2A the holonomy has baryon number 2 and the field has Chern-Simons value -4 (quadrature %.4f and %.4f): B = N needs the instanton' % (B_two, N2))
    chk('ctl', 2 * m_t != m_t, 'KAPPA: kappa = m gives the hyperbolic rate 2m = %s, not m = %s' % (2 * m_t, m_t))
    kq = Fr(2, 3); t0, p0, q0, tau0 = TP[0]; vs = [D.var(t0, 0, 4), D.var(p0, 1, 4), D.var(q0, 2, 4), D.var(tau0, 3, 4)]
    X, sh, ch, cx = tor(*vs, kq); G00 = sum(X[k].g[0] ** 2 for k in range(4))
    chk('ctl', G00 != 4 / (1 - t0 * t0) ** 2 / (kq * kq * (ch.v + cx.v)), 'CONF: the conformal factor (cosh kappa rho + cos chi)^-1 does not match the exact Jacobian')
    finish('SKY-HOL')

if __name__ == '__main__': main()
