#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""tqft_rotors.py: three of Atiyah's themes on the finite groups of rotors of Cl(3,0): flat connections on a surface with a finite gauge
group, the two-dimensional topological field theory of a Frobenius algebra, and the McKay correspondence.      python3 tqft_rotors.py [--fault NAME]

The groups are built by the bit rule in the even part of Cl(3,0) (labels 0, 12, 13, 23; the rotors are the unit quaternions of ATL-005):
the binary icosahedral group 2I (120 rotors, exact over Q(sqrt5), as in e_ladder.py elad.24), the binary tetrahedral group 2T (the 24
Hurwitz units, exact over Q) and the binary dihedral groups 2D_2 = Q8 (exact over Q) and 2D_4 (order 16, exact over Q(sqrt2)).
A. Flat connections (tqf.A1 .. A3).  With a finite gauge group G the flat connections on the closed surface of genus g modulo gauge are
   Hom(pi_1(Sigma_g), G)/G, and |Hom(pi_1(Sigma_g), G)| = |G| sum_chi (|G|/chi(1))^(2g-2) over the irreducible characters (Frobenius; Mednykh).
   [bit] for 2I the pairs (a, b) are enumerated and the commutators [a,b] counted by value; |Hom(Z^2, 2I)| = 1080 = 120 x 9 (the commuting
   pairs: |G| times the number of classes); for genus 2 the convolution of the commutator distribution with itself at the identity gives
   3 309 120; genus 3 the same way: 28 861 413 120.  [std] the Frobenius sum with the degrees 1, 2, 2, 3, 3, 4, 4, 5, 6 (the
   character table of elad.24, recomputed here exactly; the degrees also from the numpy Burnside table).  [ctl] the degrees of the binary
   octahedral group in the formula (WRONG_DEGREES), the sum over classes in place of characters (CLASSES).
B. The two-dimensional field theory (tqf.B1 .. B2).  The class algebra Z(Q[G]) (class sums as basis, structure constants from the rotors) with
   the trace theta(u) = (coefficient of the identity in u)/|G| is a commutative Frobenius algebra; its handle element h = sum_i e_i e^i (the
   dual basis through theta) gives Z(Sigma_g) = theta(h^g): 1/120, 9, 27576, 240 511 776 for g = 0, 1, 2, 3, exactly |Hom(pi_1 Sigma_g, G)|/|G|
   (Dijkgraaf-Witten with the trivial cocycle; Hitchin's class-function example) and sum_chi (|G|/chi(1))^(2g-2); the central idempotents are
   the eigenvectors of theta's dual pairing, with theta(E_chi) = chi(1)^2/|G|^2.  [ctl] theta = the coefficient of the identity without the 1/|G|
   (NORM) gives 1, 1080, ... instead.
C. McKay (tqf.C1 .. C3).  The McKay matrix n_ij = <chi_V chi_i, chi_j> of the 2-dimensional rotor representation V: for 2T the adjacency of the
   affine E6 diagram with the dimensions 1, 1, 1, 2, 2, 2, 3 as marks (exact over Q(sqrt-3): the three one-dimensional characters take the cube
   roots of unity on the rotor of order 6); for Q8 = 2D_2 affine D4 (marks 1, 1, 1, 1, 2; exact over Q); for 2D_4 affine D6 (marks 1, 1, 1, 1, 2, 2, 2;
   exact over Q(sqrt2)).  [std] numpy (Burnside): the same graphs, and 2D_3, 2D_5, 2D_6 give affine D5, D7, D8.  [ctl] 2T asserted to give affine E7
   (E7_FOR_2T): the graphs are not isomorphic.
Scope: the four exact groups above, the six numeric ones; genus g <= 3 (the counts), g <= 3 (the field theory).  Standard library and numpy.
Command: python3 tqft_rotors.py   (from this folder, or python3 selfcheck/proofs/tqft_rotors.py from the root of the checks)."""
import os, sys, itertools, time
from fractions import Fraction as F
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p)
from bitcliff import Alg, sig

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('WRONG_DEGREES', 'CLASSES', 'NORM', 'E7_FOR_2T')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time()

# ------------------------------------------------------------------------------------------------ a quadratic field Q(sqrt d), exact
class QD:
    __slots__ = ('a', 'b', 'd')
    def __init__(s, a, b=0, d=5): s.a = F(a); s.b = F(b); s.d = d
    def _c(s, o): return o if isinstance(o, QD) else QD(o, 0, s.d)
    def __add__(s, o): o = s._c(o); return QD(s.a + o.a, s.b + o.b, s.d)
    __radd__ = __add__
    def __neg__(s): return QD(-s.a, -s.b, s.d)
    def __sub__(s, o): return s + (-s._c(o))
    def __mul__(s, o): o = s._c(o); return QD(s.a * o.a + s.d * s.b * o.b, s.a * o.b + s.b * o.a, s.d)
    __rmul__ = __mul__
    def __eq__(s, o): o = s._c(o); return s.a == o.a and s.b == o.b
    def __hash__(s): return hash((s.a, s.b))
    def gal(s): return QD(s.a, -s.b, s.d)
    def inv(s):
        nrm = s.a * s.a - s.d * s.b * s.b; return QD(s.a / nrm, -s.b / nrm, s.d)
    def __truediv__(s, o): return s * s._c(o).inv()
    def __float__(s): return float(s.a) + float(s.b) * (s.d ** 0.5)
    def __complex__(s): return complex(float(s.a)) + complex(float(s.b)) * (complex(s.d) ** 0.5)
    def __repr__(s): return '%s%s' % (s.a, '' if s.b == 0 else '%+s*sqrt(%d)' % (s.b, s.d))
    def is_int(s): return s.b == 0 and s.a.denominator == 1

# ------------------------------------------------------------------------------------------------ the rotors: the even part of Cl(3,0) by the bit rule
ALG = Alg(sig(3, 0)); EV = [0, 3, 5, 6]; EVP = {a: i for i, a in enumerate(EV)}       # labels 0, 12, 13, 23
S3T = {(a, b): ALG.blade_mul(a, b)[0] for a in EV for b in EV}
def rmul(x, y):
    out = [QD(0, 0, x[0].d)] * 4
    for i, a in enumerate(EV):
        for j, b in enumerate(EV): out[EVP[a ^ b]] = out[EVP[a ^ b]] + x[i] * y[j] * S3T[(a, b)]
    return tuple(out)
def rrev(x): return (x[0], -x[1], -x[2], -x[3])
def one(d): return (QD(1, 0, d), QD(0, 0, d), QD(0, 0, d), QD(0, 0, d))
def closure(gens, d):
    E = one(d); G = {E}; todo = [E]
    while todo:
        x = todo.pop()
        for g in gens:
            y = rmul(x, g)
            if y not in G: G.add(y); todo.append(y)
    return G
def group_data(gens, d):
    """the group as rotors: elements, multiplication table (indices), inverses, conjugacy classes, traces 2 x scalar part"""
    G = closure(gens, d); fkey = lambda x: tuple((float(c.a), float(c.b)) for c in x)
    L = sorted(G, key=fkey); idx = {x: i for i, x in enumerate(L)}; n = len(L)
    ok_unit = all(rmul(g, rrev(g)) == one(d) for g in L)
    mt = [[idx[rmul(L[i], L[j])] for j in range(n)] for i in range(n)]
    inv = [idx[rrev(L[i])] for i in range(n)]
    cls_of = [-1] * n; CLS = []
    for i in range(n):
        if cls_of[i] >= 0: continue
        orb = sorted({mt[mt[g][i]][inv[g]] for g in range(n)})
        for x in orb: cls_of[x] = len(CLS)
        CLS.append(orb)
    TR = [L[c[0]][0] * 2 for c in CLS]
    return {'L': L, 'n': n, 'mt': mt, 'inv': inv, 'cls_of': cls_of, 'CLS': CLS, 'SZ': [len(c) for c in CLS], 'TR': TR, 'e': idx[one(d)], 'd': d, 'ok_unit': ok_unit, 'idx': idx}
def su2_chars(gd, jmax):
    """characters of the SU(2) representations V_j (dimension j + 1) restricted to the rotor group: Chebyshev recursion in the trace"""
    h = len(gd['CLS']); TR = gd['TR']; chi = {0: [QD(1, 0, gd['d'])] * h, 1: list(TR)}
    for j in range(1, jmax): chi[j + 1] = [TR[t] * chi[j][t] - chi[j - 1][t] for t in range(h)]
    return chi
def inner(gd, c1, c2):
    """<c1, c2> = (1/|G|) sum_g c1(g) conj(c2(g)); the characters here are real or in a field whose conjugation is gal when d < 0"""
    SZ = gd['SZ']; conj = (lambda v: v.gal()) if gd['d'] < 0 else (lambda v: v)
    return sum((c1[t] * conj(c2[t]) * SZ[t] for t in range(len(SZ))), QD(0, 0, gd['d'])) * F(1, gd['n'])
def one_dim_char(gd, gens, values):
    """the one-dimensional character with the given values on the generators, extended along products; None if it is not a homomorphism"""
    L, idx, mt, n = gd['L'], gd['idx'], gd['mt'], gd['n']; d = gd['d']
    val = {gd['e']: QD(1, 0, d)}; todo = [gd['e']]; gi = [idx[g] for g in gens]
    while todo:
        x = todo.pop()
        for g, v in zip(gi, values):
            y = mt[x][g]
            if y not in val: val[y] = val[x] * v; todo.append(y)
    if any(val[mt[i][j]] != val[i] * val[j] for i in range(n) for j in range(n)): return None
    return [val[c[0]] for c in gd['CLS']]

# ------------------------------------------------------------------------------------------------ 2I over Q(sqrt5) (elad.24), its characters
half = F(1, 2); phi = QD(half, half, 5); phinv = phi - 1
gI1 = (phi * half, phinv * half, QD(half, 0, 5), QD(0, 0, 5)); gI2 = (QD(half, 0, 5), QD(half, 0, 5), QD(half, 0, 5), QD(half, 0, 5))
GI = group_data([gI1, gI2], 5)
chiI = su2_chars(GI, 5)
CHI = [chiI[j] for j in range(0, 6)] + [[v.gal() for v in chiI[j]] for j in (1, 2)] + [[GI['TR'][t] * GI['TR'][t].gal() for t in range(len(GI['CLS']))]]
orthI = all(inner(GI, CHI[i], CHI[j]) == QD(int(i == j), 0, 5) for i in range(9) for j in range(9))
DEG = sorted(int(c[GI['cls_of'][GI['e']]].a) for c in CHI)
head('A. flat connections on a closed surface with the gauge group 2I (120 rotors of Cl(3,0), exact over Q(sqrt5))')
chk('bit', GI['ok_unit'] and GI['n'] == 120 and sorted(GI['SZ']) == [1, 1, 12, 12, 12, 12, 20, 20, 30] and orthI and DEG == [1, 2, 2, 3, 3, 4, 4, 5, 6],
    'tqf.A1: the two rotors of orders 10 and 6 generate 120 unit rotors in 9 classes; the nine characters (SU(2) characters of dimension 1..6 restricted, two Galois conjugates, 2 x 2\') are orthonormal, degrees %s (elad.24 recomputed)' % DEG)
n = GI['n']; mt = GI['mt']; inv = GI['inv']; e = GI['e']
comm_count = [0] * n                                                          # c(z) = #{(a, b) : a b a^-1 b^-1 = z}
for a in range(n):
    ra = mt[a]; ia = inv[a]
    for b in range(n): comm_count[mt[mt[ra[b]][ia]][inv[b]]] += 1
hom1 = comm_count[e]
def convolve(c1, c2):
    out = [0] * n
    for x in range(n):
        if c1[x]:
            row = mt[x]
            for y in range(n):
                if c2[y]: out[row[y]] += c1[x] * c2[y]
    return out
c2 = convolve(comm_count, comm_count); c3 = convolve(c2, comm_count)
HOM = {1: hom1, 2: c2[e], 3: c3[e]}
def frobenius(g, degrees, order): return order * sum(F(order, dd) ** (2 * g - 2) for dd in degrees)
DEGS = [1, 1, 2, 2, 2, 3, 3, 4] if FAULT == 'WRONG_DEGREES' else DEG
FRO = {g: frobenius(g, DEGS, 120) for g in (1, 2, 3)}
if FAULT == 'CLASSES': FRO = {g: 120 * sum(F(120, sz) ** (2 * g - 2) for sz in GI['SZ']) for g in (1, 2, 3)}
chk('bit', hom1 == 120 * 9 == 1080 and sum(comm_count) == 120 ** 2, 'tqf.A2: |Hom(Z^2, 2I)| = the commuting pairs = %d = 120 x 9 (|G| times the number of classes); the commutator values are distributed over the 120 elements (%d pairs in all)' % (hom1, sum(comm_count)))
chk('bit==std', all(HOM[g] == FRO[g] for g in (1, 2, 3)), 'tqf.A3: |Hom(pi_1(Sigma_g), 2I)| by the convolution of the commutator distribution, g = 1, 2, 3: %s; the Frobenius sum |G| sum_chi (|G|/chi(1))^(2g-2) with the degrees %s: %s' % ([HOM[g] for g in (1, 2, 3)], DEGS, [int(FRO[g]) if FRO[g].denominator == 1 else FRO[g] for g in (1, 2, 3)]))
chk('bit', HOM[2] == 3309120, 'tqf.A3: at genus 2 the count is 3 309 120 (the map, theme 10)')
wrongA = 120 * sum(F(120, sz) ** 2 for sz in GI['SZ']); wrongB = frobenius(2, [1, 1, 2, 2, 2, 3, 3, 4], 120)
chk('ctl', wrongA != HOM[2] and wrongB != HOM[2], 'tqf.A3: the sum over the classes (%s) or the degrees of another group (%s) do not give the count (CLASSES, WRONG_DEGREES)' % (wrongA, wrongB))

# ------------------------------------------------------------------------------------------------ B. the class algebra as a Frobenius algebra
head('B. the two-dimensional field theory of the class algebra of 2I (class sums, theta(u) = coefficient of the identity / |G|)')
h = len(GI['CLS']); CLS = GI['CLS']; cls_of = GI['cls_of']
STR = [[[0] * h for _ in range(h)] for _ in range(h)]                       # C_r C_s = sum_t STR[r][s][t] C_t  (integers)
for r in range(h):
    for s in range(h):
        cnt = [0] * n
        for x in CLS[r]:
            row = mt[x]
            for y in CLS[s]: cnt[row[y]] += 1
        for t in range(h):
            vals = {cnt[z] for z in CLS[t]}; assert len(vals) == 1; STR[r][s][t] = vals.pop()
def cmul(u, v):
    out = [F(0)] * h
    for r in range(h):
        if u[r]:
            for s in range(h):
                if v[s]:
                    for t in range(h): out[t] += u[r] * v[s] * STR[r][s][t]
    return out
ecl = cls_of[e]
theta = (lambda u: u[ecl]) if FAULT == 'NORM' else (lambda u: u[ecl] / n)   # theta(C_t) = 1/|G| for the class of the identity, 0 otherwise
basis = [[F(int(i == j)) for j in range(h)] for i in range(h)]
GRAM = [[theta(cmul(basis[i], basis[j])) for j in range(h)] for i in range(h)]
def inv_frac(M):
    m = len(M); A = [[F(x) for x in row] + [F(int(i == j)) for j in range(m)] for i, row in enumerate(M)]
    for c in range(m):
        piv = next(i for i in range(c, m) if A[i][c] != 0); A[c], A[piv] = A[piv], A[c]
        pv = A[c][c]; A[c] = [x / pv for x in A[c]]
        for i in range(m):
            if i != c and A[i][c]: f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return [row[m:] for row in A]
GINV = inv_frac(GRAM)
handle = [F(0)] * h
for i in range(h):
    for j in range(h):
        if GINV[i][j]:
            p = cmul(basis[i], basis[j]); handle = [a + GINV[i][j] * b for a, b in zip(handle, p)]
unit_el = basis[ecl]
Z = {}; hp = unit_el
for g in range(0, 4): Z[g] = theta(hp); hp = cmul(hp, handle)
comm_ok = all(cmul(basis[i], basis[j]) == cmul(basis[j], basis[i]) for i in range(h) for j in range(h))
nondeg = all(any(GRAM[i][j] != 0 for j in range(h)) for i in range(h))
want_Z = {g: F(HOM[g], 120) for g in (1, 2, 3)}; want_Z[0] = F(1, 120)
chk('bit', comm_ok and nondeg and all(Z[g] == want_Z[g] for g in range(4)),
    'tqf.B1: the class algebra is commutative, theta is non-degenerate (Gram matrix invertible), and Z(Sigma_g) = theta(h^g) for g = 0..3: %s = |Hom(pi_1 Sigma_g, G)|/|G| (1/120, 9, 27576, ...)' % [str(Z[g]) for g in range(4)])
frob_Z = {g: sum(F(120, dd) ** (2 * g - 2) for dd in DEG) for g in range(4)}
chk('bit==std', all(Z[g] == frob_Z[g] for g in range(4)), 'tqf.B2: the same numbers from the characters, sum_chi (|G|/chi(1))^(2g-2): %s (Hitchin\'s class-function theory; the handle operator is multiplication by h)' % [str(frob_Z[g]) for g in range(4)])

# ------------------------------------------------------------------------------------------------ C. McKay for 2T, Q8, 2D_4 (exact) and numerically for 2D_k
head('C. McKay: the 2-dimensional rotor representation on the irreducibles of 2T, 2D_2 = Q8 and 2D_4 (exact), 2D_k numerically')
def affine_D(m):
    """adjacency and marks of the affine diagram D_m~ (m + 1 nodes): a chain of m - 3 nodes of mark 2 with two leaves of mark 1 at each end"""
    chain = m - 3; nodes = chain + 4; A = [[0] * nodes for _ in range(nodes)]
    def link(i, j): A[i][j] = A[j][i] = 1
    for i in range(chain - 1): link(i, i + 1)
    link(chain, 0); link(chain + 1, 0); link(chain + 2, chain - 1); link(chain + 3, chain - 1)
    return A, [2] * chain + [1] * 4
def affine_E6():
    A = [[0] * 7 for _ in range(7)]
    def link(i, j): A[i][j] = A[j][i] = 1
    link(0, 1); link(0, 2); link(0, 3); link(1, 4); link(2, 5); link(3, 6)
    return A, [3, 2, 2, 2, 1, 1, 1]
def affine_E7():
    A = [[0] * 8 for _ in range(8)]
    def link(i, j): A[i][j] = A[j][i] = 1
    for i in range(6): link(i, i + 1)
    link(3, 7)
    return A, [1, 2, 3, 4, 3, 2, 1, 2]
def iso_labelled(adjA, labA, adjB, labB):
    nn = len(labA)
    if sorted(labA) != sorted(labB): return None
    groups = sorted(set(labA)); Ag = [[i for i in range(nn) if labA[i] == L] for L in groups]; Bg = [[j for j in range(nn) if labB[j] == L] for L in groups]
    for choice in itertools.product(*[itertools.permutations(b) for b in Bg]):
        perm = {}
        for a, b in zip(Ag, choice): perm.update(dict(zip(a, b)))
        if all(adjA[i][j] == adjB[perm[i]][perm[j]] for i in range(nn) for j in range(nn)): return perm
    return None
def mckay_exact(gd, chars):
    """n_ij = <chi_V chi_i, chi_j>, chi_V the trace of the rotors; integers or None"""
    TR = gd['TR']; h = len(TR)
    N = [[inner(gd, [TR[t] * chars[i][t] for t in range(h)], chars[j]) for j in range(len(chars))] for i in range(len(chars))]
    if not all(v.is_int() for row in N for v in row): return None
    return [[int(v.a) for v in row] for row in N]
def mckay_report(name, gd, chars, A, marks):
    h = len(gd['CLS']); orth = all(inner(gd, chars[i], chars[j]) == QD(int(i == j), 0, gd['d']) for i in range(len(chars)) for j in range(len(chars)))
    dims = [int(c[gd['cls_of'][gd['e']]].a) for c in chars]
    N = mckay_exact(gd, chars)
    ok = gd['ok_unit'] and orth and len(chars) == h and sum(dd * dd for dd in dims) == gd['n'] and N is not None
    if ok:
        Nn = np.array(N); C = 2 * np.eye(len(N), dtype=np.int64) - Nn
        ok = np.array_equal(Nn, Nn.T) and not np.any(np.diag(Nn)) and np.all(C @ np.array(dims) == 0) and iso_labelled(N, dims, A, marks) is not None
    return ok, dims, N
# 2T: the Hurwitz units, generated by (1 + e12 + e13 + e23)/2 (order 6) and e12 (order 4); its three one-dimensional characters take 1, omega, omega^2 on the first
w3 = QD(-half, half, -3)                                                     # omega = (-1 + sqrt(-3))/2
q = lambda a, b, c, dd: (QD(a, 0, -3), QD(b, 0, -3), QD(c, 0, -3), QD(dd, 0, -3))
gT1 = q(half, half, half, half); gT2 = q(0, 1, 0, 0)
GT = group_data([gT1, gT2], -3); chiT = su2_chars(GT, 2)
ones = [one_dim_char(GT, [gT1, gT2], [v, QD(1, 0, -3)]) for v in (QD(1, 0, -3), w3, w3 * w3)]
hT = len(GT['CLS'])
charsT = [ones[0], ones[1], ones[2], chiT[1], [chiT[1][t] * ones[1][t] for t in range(hT)], [chiT[1][t] * ones[2][t] for t in range(hT)], chiT[2]]
AE6, ME6 = affine_E6(); AE7, ME7 = affine_E7()
okT, dimsT, NT = mckay_report('2T', GT, charsT, *(affine_E7() if FAULT == 'E7_FOR_2T' else affine_E6()))
chk('ctl', NT is not None and iso_labelled(NT, dimsT, AE7, ME7) is None, 'tqf.C1: the McKay graph of 2T is not the affine E7 diagram (E7_FOR_2T)')
chk('bit', all(o is not None for o in ones) and GT['n'] == 24 and len(GT['CLS']) == 7 and okT,
    'tqf.C1: 2T: 24 rotors in 7 classes; characters 1, 1\', 1\'\' (cube roots of unity on the rotor of order 6, exact over Q(sqrt-3)), 2, 2 x 1\', 2 x 1\'\', 3 (orthonormal); McKay matrix = adjacency of the affine E6 diagram with the dimensions %s as marks (2I - n annihilates them)' % dimsT)
# Q8 = 2D_2: e12, e13 (exact over Q)
q8 = lambda a, b, c, dd: (QD(a, 0, 5), QD(b, 0, 5), QD(c, 0, 5), QD(dd, 0, 5))
GQ = group_data([q8(0, 1, 0, 0), q8(0, 0, 1, 0)], 5); chiQ = su2_chars(GQ, 1)
onesQ = [one_dim_char(GQ, [q8(0, 1, 0, 0), q8(0, 0, 1, 0)], [QD(a, 0, 5), QD(b, 0, 5)]) for a in (1, -1) for b in (1, -1)]
okQ, dimsQ, NQ = mckay_report('Q8', GQ, onesQ + [chiQ[1]], *affine_D(4))
chk('bit', all(o is not None for o in onesQ) and GQ['n'] == 8 and okQ, 'tqf.C2: Q8 = 2D_2 (e12, e13): 8 rotors in 5 classes, four one-dimensional characters and the rotor character; McKay matrix = affine D4 with marks %s' % dimsQ)
# 2D_4: a = (1 + e12)/sqrt2 (order 8), b = e13; exact over Q(sqrt2); the 2-dimensional irreducibles are V_1, V_2 minus the character (a -> 1, b -> -1), V_3 - V_1 (the SU(2) branching)
r2 = QD(0, half, 2)                                                          # 1/sqrt2 = sqrt2/2
gD1 = (r2, r2, QD(0, 0, 2), QD(0, 0, 2)); gD2 = (QD(0, 0, 2), QD(0, 0, 2), QD(1, 0, 2), QD(0, 0, 2))
GD = group_data([gD1, gD2], 2); chiD = su2_chars(GD, 3); hD = len(GD['CLS'])
onesD = [one_dim_char(GD, [gD1, gD2], [QD(a, 0, 2), QD(b, 0, 2)]) for a in (1, -1) for b in (1, -1)]
twosD = [chiD[1], [chiD[2][t] - onesD[1][t] for t in range(hD)], [chiD[3][t] - chiD[1][t] for t in range(hD)]]   # V_2 = rho_2 + (a -> 1, b -> -1): b sends xy to -xy; V_3 = rho_3 + rho_1
okD, dimsD, ND = mckay_report('2D4', GD, onesD + twosD, *affine_D(6))
chk('bit', all(o is not None for o in onesD) and GD['n'] == 16 and okD, 'tqf.C3: 2D_4 ((1 + e12)/sqrt2 of order 8 and e13): 16 rotors in 7 classes; four one-dimensional characters and the three two-dimensional ones peeled from the SU(2) characters; McKay matrix = affine D6 with marks %s' % dimsD)
# the standard route: numpy Burnside on 2 x 2 complex matrices (e_ladder.py elad.26)
def qmat(qq): a, b, c, dd = qq; return np.array([[a + b * 1j, c + dd * 1j], [-c + dd * 1j, a - b * 1j]])
def mckay_float(gens):
    key = lambda m: tuple(np.round(np.concatenate([m.real.ravel(), m.imag.ravel()]), 8) + 0.0)
    els = [np.eye(2, dtype=complex)]; idx = {key(els[0]): 0}; todo = [0]
    while todo:
        i = todo.pop()
        for g in gens:
            m = els[i] @ g; k = key(m)
            if k not in idx: idx[k] = len(els); els.append(m); todo.append(idx[k])
    nn = len(els); mtf = np.array([[idx[key(els[i] @ els[j])] for j in range(nn)] for i in range(nn)]); invf = [idx[key(np.linalg.inv(m))] for m in els]
    cl = -np.ones(nn, dtype=int); classes = []
    for i in range(nn):
        if cl[i] < 0:
            orb = sorted({int(mtf[mtf[g, i], invf[g]]) for g in range(nn)})
            for x in orb: cl[x] = len(classes)
            classes.append(orb)
    hh = len(classes); sz = np.array([len(c) for c in classes], dtype=float); Cm = np.zeros((hh, hh, hh))
    for r in range(hh):
        for x in classes[r]:
            for s in range(hh):
                for y in classes[s]: Cm[r, s, cl[mtf[x, y]]] += 1
    Cm /= sz[None, None, :]
    rng = np.random.default_rng(140); Xm = sum(rng.normal() * Cm[r] for r in range(hh)); w, V = np.linalg.eig(Xm); ee = cl[0]; chars = []
    for t in range(hh):
        v = V[:, t] / V[ee, t]; dd = np.sqrt(nn / np.sum(np.abs(v) ** 2 / sz)); chars.append(dd * v / sz)
    trn = np.array([np.trace(els[classes[t][0]]) for t in range(hh)])
    G_ = np.array([[np.sum(sz * chars[i] * np.conj(chars[j])) / nn for j in range(hh)] for i in range(hh)])
    NMf = np.array([[np.sum(sz * trn * chars[i] * np.conj(chars[j])) / nn for j in range(hh)] for i in range(hh)])
    return dict(n=nn, dims=[int(round(c[ee].real)) for c in chars], NM=np.rint(NMf.real).astype(int), err=max(np.abs(NMf - np.rint(NMf.real)).max(), np.abs(G_ - np.eye(hh)).max()))
def dihedral_gens(k):
    c, s = np.cos(np.pi / k), np.sin(np.pi / k); return [qmat((c, s, 0.0, 0.0)), qmat((0.0, 0.0, 1.0, 0.0))]
mT = mckay_float([qmat((0.5, 0.5, 0.5, 0.5)), qmat((0.0, 1.0, 0.0, 0.0))])
okTf = mT['n'] == 24 and mT['err'] < 1e-8 and sorted(mT['dims']) == [1, 1, 1, 2, 2, 2, 3] and iso_labelled(mT['NM'].tolist(), mT['dims'], AE6, ME6) is not None
resD = {}
for k in range(2, 7):
    mD = mckay_float(dihedral_gens(k)); A, marks = affine_D(k + 2)
    resD[k] = mD['n'] == 4 * k and mD['err'] < 1e-8 and sorted(mD['dims']) == sorted(marks) and iso_labelled(mD['NM'].tolist(), mD['dims'], A, marks) is not None
chk('std', okTf and all(resD.values()), 'tqf.C: numpy (Burnside, 2 x 2 complex matrices, no label): 2T gives affine E6 and the binary dihedral groups 2D_k, k = 2..6 (orders %s), give affine D_(k+2) with the dimensions as marks' % [4 * k for k in range(2, 7)])
chk('bit==std', okT and okTf and okQ and resD[2] and okD and resD[4] and NT is not None and sorted(dimsT) == sorted(mT['dims']), 'tqf.C: the exact and the numeric McKay graphs of 2T, Q8 and 2D_4 agree (both isomorphic to the named affine diagram with the same marks)')
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('TQFT-ROTORS')
