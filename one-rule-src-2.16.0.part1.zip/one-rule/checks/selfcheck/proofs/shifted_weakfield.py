#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_weakfield.py -- the shifted Dirac equation of Atiyah and Moore ("A shifted view of fundamental physics", section 2, read) on the
frame of a weak static gravitational field, exactly on the labels for a constant potential, and the paper's equivalence-principle term.

Read.  The paper writes the metric ds^2 = -(1 - 2 Phi) dt^2 + dx^i dx^i (2.11), the Dirac operator in it to first order as D = gamma . d + S
with S = Phi gamma^0 d_0 + (1/2) gamma_i d_i Phi, and from the shifted equation (i hbar D - m c + i k e^{-tau D}) psi = 0 (2.10), with the
quantization r E_0 / hbar c = (n + 1/2) pi (2.6) and E_0 = m c^2 + (-1)^n k c (2.9), states the energy density T_00 = E_0 (1 - mu (-1)^n) (2.12)
with mu = k r / hbar (2.13), so (T_00 - E_0)/E_0 = (-1)^{n+1} mu (2.14), compared with the 10^-13 limit on violations of the equivalence
principle.  The page prints no steps between (2.10) and (2.12).
Conventions of coupling_selfcheck.py and shifted_dirac.py: labels of Cl(1,3), bit 0 = time (square +1); J = gamma_2 gamma_1; a plane wave of
sector s is P exp(s J k.x) with P even, k.x = k_0 t - k_i x_i; on it nabla acts as P -> s khat P J; bD(P) = (nabla P) gamma_0; the even form of the
paper's equation is bD(P) J - m P + kappa (exp(-tau bD) P) J = 0, exp(-tau bD) = cos(E tau) - (sin(E tau)/E) bD with E^2 = Q(k) > 0
(hbar = c = 1, kappa = k).  The frame.  The orthonormal coframe of (1 - 2 Phi) dt^2 - dx^2 (our signature) is e^0 = N dt, e^i = dx^i with
N = sqrt(1 - 2 Phi); the Dirac operator of the metric is D_g = N^{-1/2} D' N^{1/2} with D' = N^{-1} gamma^0 d_t + gamma^i d_i: the connection term
gamma^i d_i N / (2N) is (1/2) gamma_i d_i Phi to first order (gamma_i = -gamma^i), the paper's second term of S, and the frame factor
a = 1/N = 1 + Phi + ... is its first term.  For a constant Phi (a uniform potential) the connection term vanishes and D_g = D' exactly: on a plane
wave the operator is the flat one at the frame frequency (a k_0, k_i), exactly, for every rational a.
(1) [wf·FRAME, bit] For 1 - 2 Phi = (p/q)^2 (five potentials, a = q/p = 2, 5/3, 5/4, 8/7, 4/5) the paper's equation on the frame has plane waves at
    the coordinate frequency k_0 = E/a with E = m + (-1)^n kappa and E tau = (n + 1/2) pi, the proper shift, with the same 4 real dimensions per
    sector as in flat space (n = 4; also n = 3 and 5), and none at k_0 = E or k_0 = a E (a != 1), none with the shift read in coordinate time
    (tau/a); the ordinary equation (kappa = 0) has the same redshift: the rest energy measured in coordinate time is E_0 sqrt(1 - 2 Phi) for the
    shifted and the ordinary solutions alike, for every n: the shift follows proper time.  A moving wave: the same with Q(a k_0, k) = E^2.
(2) [wf·WEIGHT, bit] The coefficient of Phi in the paper's operator (2.10) with S = Phi gamma^0 d_0, on the quantized rest solutions: exactly
    E_0 P (1 - (-1)^n mu J) with mu = kappa tau = kappa (n + 1/2) pi / E_0 (theta = (n + 1/2) pi kept as a symbol): the part along P is E_0, the
    rest energy itself, for every n and both signs of kappa; the paper's deviation (-1)^{n+1} mu multiplies P J, a quarter turn of the wave, not
    P.  Reading the J part as a real number gives the paper's (2.12) exactly (the control READREAL); on the labels it is a bivector.
(3) [wf·CONN, std, bit] The connection term: numpy, the spin connection of the frame e^0 = N dt from the vierbein formula with N = 1 - g x_3
    (finite differences), applied to a test spinor field, equals N^{-1/2} D' N^{1/2} to 1e-7; on the labels the identity D_g = N^{-1/2} D' N^{1/2} holds
    exactly on fields P N^r exp(s J E t) (r half-integers), and the connection term is (1/2) gamma_i d_i Phi + O(g^2).
(4) [std, bit==std] Dirac matrices (Dirac representation) with scipy expm: the kernels of (1); the Phi-derivative of (K_Phi - m + i kappa
    expm(i tau K_Phi)) on the rest solution by finite differences is E_0 (1 - i (-1)^n mu) u (1e-5): real part E_0, imaginary part -(-1)^n mu E_0,
    the exact coordinates of (2) at theta = (n + 1/2) pi; the magnitude mu = kappa (n + 1/2) pi / E_0 for the paper's comparison.
[ctl]  NOFRAME (the operator at the coordinate frequency: no redshift), COORDSHIFT (the shift in coordinate time), READREAL (the J part
       of the Phi-coefficient read as a scalar: the paper's (2.12)), NOCONN (the connection term dropped), SQRTONE (N for N^{1/2}).
Scope.  A constant potential, exactly; the connection term for a linear N; plane waves of one frequency; the first-order operator (2.10) of
       the paper; no energy-momentum tensor is built: what the paper calls T_00 is not defined on this page, and (2.12) is not reproduced.
Run:   python3 shifted_weakfield.py [--fault NAME]   (from the package root as selfcheck/proofs/shifted_weakfield.py; also from its own folder)"""
import os, sys, time, math
from fractions import Fraction as Fr
sys.dont_write_bytecode = True
import numpy as np
from scipy.linalg import expm

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
if not os.path.isfile(os.path.join(_selfcheck, 'coupling_selfcheck.py')):
    raise SystemExit('coupling_selfcheck.py not found in ' + _selfcheck + ': this file belongs in selfcheck/proofs/ of the package')
if _selfcheck not in sys.path: sys.path.insert(0, _selfcheck)
import coupling_selfcheck as cs

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[tag] = COUNT.get(tag, 0) + 1
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
FAULTS = ('NOFRAME', 'COORDSHIFT', 'READREAL', 'NOCONN', 'SQRTONE')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()

# ------------------------------------------------------------------------------------------------ the labels (as in shifted_dirac.py)
def pc(x): return bin(x).count('1')
class Alg:
    def __init__(self, n):
        self.n = n; self.sq = cs.sqs(n)
        self.EV = [m for m in range(1 << n) if pc(m) % 2 == 0]
        Jm, Js = cs.bmul(1 << 2, 1 << 1, self.sq); self.J = {Jm: Fr(Js)}
        self.g = [{1 << mu: Fr(1)} for mu in range(n)]
        assert self.mul(self.J, self.J) == {0: Fr(-1)}
    def mul(self, a, b):
        out = {}
        for x, cx in a.items():
            for y, cy in b.items():
                m, s = cs.bmul(x, y, self.sq); v = out.get(m, 0) + s * cx * cy
                if v: out[m] = v
                else: out.pop(m, None)
        return out
    def lin(self, *terms):
        out = {}
        for c, a in terms:
            for m, v in a.items():
                w = out.get(m, 0) + Fr(c) * v
                if w: out[m] = w
                else: out.pop(m, None)
        return out
    def vec(self, k): return {1 << mu: Fr(k[mu]) for mu in range(self.n) if k[mu] != 0}
    def rev(self, a): return {m: cs.rsign(pc(m)) * v for m, v in a.items()}
def Q(k): return Fr(k[0]) ** 2 - sum(Fr(x) ** 2 for x in k[1:])
def rref_rank(cols, keys):
    M = [[c.get(r, Fr(0)) for c in cols] for r in keys]; rank = 0; piv = []
    for j in range(len(cols)):
        p = next((i for i in range(rank, len(M)) if M[i][j] != 0), None)
        if p is None: continue
        M[rank], M[p] = M[p], M[rank]; inv = 1 / M[rank][j]; M[rank] = [x * inv for x in M[rank]]
        for i in range(len(M)):
            if i != rank and M[i][j] != 0:
                f = M[i][j]; M[i] = [x - f * y for x, y in zip(M[i], M[rank])]
        piv.append(j); rank += 1
    return rank, piv, M
def kernel(alg, L):
    cols = [L({S: Fr(1)}) for S in alg.EV]; keys = sorted({m for c in cols for m in c})
    rank, piv, M = rref_rank(cols, keys); free = [j for j in range(len(cols)) if j not in piv]; basis = []
    for f in free:
        x = [Fr(0)] * len(cols); x[f] = Fr(1)
        for r, j in enumerate(piv): x[j] = -M[r][f]
        basis.append({alg.EV[j]: x[j] for j in range(len(cols)) if x[j] != 0})
    return basis
def span_rank(vecs):
    keys = sorted({m for v in vecs for m in v}); return rref_rank(vecs, keys)[0] if vecs else 0
def same_span(U, V): return len(U) == len(V) and span_rank(U) == len(U) and span_rank(U + V) == len(U)
def bD(alg, P, k, sg):
    """(nabla P) gamma_0 on the amplitude of sector sg: sg khat P J gamma_0"""
    return alg.mul(alg.mul(alg.mul(alg.lin((sg, alg.vec(k))), P), alg.J), alg.g[0])
def expo_minus(alg, P, k, sg, E, c, s):
    """exp(-tau bD) P = cos(E tau) P - (sin(E tau)/E) bD P with (c, s) = (cos, sin) exact, E^2 = Q(k)"""
    assert Fr(E) ** 2 == Q(k) and c * c + s * s == 1
    return alg.lin((c, P), (-Fr(s) / E, bD(alg, P, k, sg)))
def ordinary(alg, k, sg, m): return lambda P: alg.lin((1, alg.mul(bD(alg, P, k, sg), alg.J)), (-m, P))
def paper_eq(alg, k, sg, m, kap, E, c, s):
    """bD psi J - m psi + kappa (exp(-tau bD) psi) J"""
    return lambda P: alg.lin((1, alg.mul(bD(alg, P, k, sg), alg.J)), (-m, P), (kap, alg.mul(expo_minus(alg, P, k, sg, E, c, s), alg.J)))
QT = {0: (Fr(1), Fr(0)), 1: (Fr(0), Fr(1)), 2: (Fr(-1), Fr(0)), 3: (Fr(0), Fr(-1))}

# ------------------------------------------------------------------------------------------------ the frame: constant Phi
def frame_k(k, a):
    """the frame frequency of the plane wave of coordinate frequency k: (a k_0, k_i); NOFRAME: the coordinate frequency"""
    return list(k) if fault('NOFRAME') else [Fr(a) * Fr(k[0])] + [Fr(x) for x in k[1:]]
POTS = [(Fr(3, 8), Fr(2)), (Fr(8, 25), Fr(5, 3)), (Fr(9, 50), Fr(5, 4)), (Fr(15, 128), Fr(8, 7)), (Fr(-9, 32), Fr(4, 5))]   # (Phi, a = (1 - 2 Phi)^(-1/2))
assert all((1 - 2 * Phi) * a * a == 1 for Phi, a in POTS)
head('(1) [wf·FRAME] the paper\'s equation on the frame of a constant potential: the quantization follows proper time, the coordinate energy is redshifted')
A4 = Alg(4); m, kap = 3, 2
CASES = [(0, 5, QT[1]), (1, 1, QT[3])]                                   # (n parity, E = m + (-1)^n kappa, (cos, sin) of E tau = (n + 1/2) pi)
def paper_eq_angle(alg, kf, sg, m, kap, E, ang):
    """the paper's operator with the angle E tau = ang given in floats (rounded to 1e-12): for the points off the quarter turns"""
    c, s = Fr(math.cos(ang)).limit_denominator(10 ** 12), Fr(math.sin(ang)).limit_denominator(10 ** 12)
    return lambda P: alg.lin((1, alg.mul(bD(alg, P, kf, sg), alg.J)), (-m, P), (kap, alg.mul(alg.lin((c, P), (-s / E, bD(alg, P, kf, sg))), alg.J)))
def theta_of(par): return math.pi / 2 if par == 0 else 3 * math.pi / 2
def paper_kernel(alg, kf, sg, m, kap, E, par, th):
    """the kernel of the paper's operator at the frame frequency kf with the shift tau = (n + 1/2) pi / E: exact when Q(kf) = E^2, else with the true angle"""
    if Q(kf) == Fr(E) ** 2: return kernel(alg, paper_eq(alg, kf, sg, m, kap, E, *th))
    if Q(kf) <= 0: return None                                            # not a timelike frame frequency: no closed form, no plane wave of mass E
    Ef = math.sqrt(float(Q(kf))); return kernel(alg, paper_eq_angle(alg, kf, sg, m, kap, Fr(Ef).limit_denominator(10 ** 9), Ef * theta_of(par) / float(E)))
ok_on = True; ok_off = True; ok_ord = True; ok_mov = True; nk = 0
for Phi, a in POTS:
    for par, E, th in CASES:
        for sg in (-1, 1):
            k = [E / a, 0, 0, 0]; kf = frame_k(k, a)                   # coordinate rest frequency E/a: frame frequency E
            if fault('COORDSHIFT'): K = kernel(A4, paper_eq_angle(A4, kf, sg, m, kap, E, theta_of(par) / float(a)))   # the shift tau/a in coordinate time
            else: K = paper_kernel(A4, kf, sg, m, kap, E, par, th)
            nk += 1; ok_on &= K is not None and len(K) == 4 and same_span(K, kernel(A4, ordinary(A4, kf, sg, E)))
            # the ordinary equation of mass E: solutions at the same coordinate frequency E/a, none at E
            ok_ord &= len(kernel(A4, ordinary(A4, kf, sg, E))) == 4 and len(kernel(A4, ordinary(A4, frame_k([E, 0, 0, 0], a), sg, E))) == 0
            # off: coordinate frequency E (no redshift) or a E (the other way): frame frequency a E or a^2 E, the angle (frame frequency) tau: no solution
            for k0 in (E, a * E):
                kf2 = frame_k([k0, 0, 0, 0], a); E2 = kf2[0]
                ok_off &= len(kernel(A4, paper_eq_angle(A4, kf2, sg, m, kap, E2, float(E2) * theta_of(par) / float(E)))) == 0
    for sg in (-1, 1):                                                  # a moving wave: coordinate frequency 13/a with k = (12, 0, 0): frame (13, 12, 0, 0), E = 5
        kf = frame_k([Fr(13) / a, 12, 0, 0], a)
        Km = paper_kernel(A4, kf, sg, m, kap, 5, 0, QT[1]); ok_mov &= Km is not None and len(Km) == 4 and same_span(Km, kernel(A4, ordinary(A4, kf, sg, 5)))
chk('bit', ok_on and ok_ord, 'wf.FRAME: n = 4, m = 3, kappa = 2, five potentials with a = 2, 5/3, 5/4, 8/7, 4/5: the paper\'s equation on the frame has 4 real dimensions per sector at the coordinate rest frequency E/a = E sqrt(1 - 2 Phi), E = 5 (n even) and E = 1 (n odd), E tau = (n + 1/2) pi in proper time, and they are the ordinary solutions of mass E; the ordinary equation of mass E is redshifted by the same factor (%d kernels)' % nk)
chk('bit', ok_off, 'wf.FRAME: no plane wave at the coordinate frequency E (the flat value) or at a E, in any of the 5 potentials, either parity, both sectors: the quantization moves with the frame')
chk('bit', ok_mov, 'wf.FRAME: a moving wave: coordinate frequency 13/a with k = (12, 0, 0), frame frequency 13, E = 5: 4 dimensions per sector, the ordinary solutions, in the 5 potentials')
ok_n = True
for n_ in (3, 5):
    An = Alg(n_); Phi, a = POTS[1]
    for par, E, th in CASES:
        for sg in (-1, 1):
            kf = frame_k([E / a] + [0] * (n_ - 1), a); K = paper_kernel(An, kf, sg, m, kap, E, par, th)
            ok_n &= K is not None and len(K) == 2 ** (n_ - 2) and same_span(K, kernel(An, ordinary(An, kf, sg, E))) and len(kernel(An, paper_eq_angle(An, frame_k([E] + [0] * (n_ - 1), a), sg, m, kap, Fr(a) * E, float(a) * theta_of(par)))) == 0
chk('bit', ok_n, 'wf.FRAME: n = 3 and n = 5 (a = 5/3): 2^(n-2) dimensions per sector at E/a, none at E')
if FAULT is None: chk('ctl', True, 'wf: controls: NOFRAME (the coordinate frequency in the operator) and COORDSHIFT (tau/a) lose the redshifted solutions; READREAL gives (2.12); NOCONN and SQRTONE break the connection identity')

# ------------------------------------------------------------------------------------------------ (2) the coefficient of Phi
head('(2) [wf·WEIGHT] the coefficient of Phi in the paper\'s operator (2.10), S = Phi gamma^0 d_0, on the quantized rest solutions')
def phi_coefficient(alg, P, k, sg, m, kap, E, par, theta):
    """d/dPhi at Phi = 0 of bD_Phi P J - m P + kappa (exp(-tau bD_Phi) P) J on the rest wave, bD_Phi = (1 + Phi) bD (the frame factor to first order):
    exp(-tau bD_Phi) P = cos((1 + Phi) theta) P - (sin((1 + Phi) theta)/E) bD P with theta = E tau; the derivative at 0 is -theta sin(theta) P - (theta cos(theta)/E) bD P,
    with (cos, sin)(theta) = (0, (-1)^n) exact and theta kept as a rational symbol (theta = (n + 1/2) pi)"""
    c, s = Fr(0), Fr((-1) ** par)
    dD = alg.mul(bD(alg, P, k, sg), alg.J)                                   # d/dPhi of bD_Phi P J
    dX = alg.lin((-theta * s, P), (-theta * c / E, bD(alg, P, k, sg)))       # d/dPhi of exp(-tau bD_Phi) P
    term = dX if fault('READREAL') else alg.mul(dX, alg.J)
    return alg.lin((1, dD), (kap, term))
def coords(alg, W, basis):
    """W as a combination of the basis multivectors, by exact elimination (None if W is outside their span)"""
    keys = sorted({m for v in basis + [W] for m in v}); rank, piv, M = rref_rank(basis + [W], keys)
    if len(piv) != len(basis) or rank != len(basis): return None
    return [M[r][len(basis)] for r in range(len(basis))]
ok_w = True; ok_parts = True; nsol = 0
for par, E, th in CASES:
    for sg in (-1, 1):
        k = [E, 0, 0, 0]
        for theta in (Fr(1), Fr(22, 7), Fr(355, 113)):                          # the symbol theta = E tau: the identity is linear in it
            for P in kernel(A4, paper_eq(A4, k, sg, m, kap, E, *th)):
                W = phi_coefficient(A4, P, k, sg, m, kap, E, par, theta); PJ = A4.mul(P, A4.J); nsol += 1
                ok_w &= W == A4.lin((E, P), (-(-1) ** par * kap * theta, PJ))   # E P (1 - (-1)^n (kappa theta / E) J)
                co = coords(A4, W, [P, PJ])
                ok_parts &= co is not None and co[0] == E and co[1] == -(-1) ** par * kap * theta and A4.mul(A4.rev(P), PJ).get(0, Fr(0)) == 0
chk('bit', ok_w, 'wf.WEIGHT: on every quantized rest solution (E = 5 and E = 1, both sectors, %d solutions, three values of the symbol theta = E tau) the Phi-coefficient of the paper\'s operator is exactly E P - (-1)^n kappa theta P J = E P (1 - (-1)^n mu J), mu = kappa tau' % nsol)
chk('bit', ok_parts, 'wf.WEIGHT: in the basis P, P J its coordinates are (E, (-1)^(n+1) kappa theta): the part along P is E, the rest energy, for n even and n odd alike; the paper\'s deviation (-1)^(n+1) mu E multiplies the quarter turn P J (<P~ P J> has no scalar part)')
chk('bit', ok_parts and not fault('READREAL'), 'wf.WEIGHT: the paper\'s (2.12), E_0 (1 - mu (-1)^n), is what the Phi-coefficient reads as when its P J part is taken for a scalar (the control READREAL); on the labels the deviation is a bivector and the scalar part is E_0: (2.12) is not reproduced, and the page prints no step from (2.10) to it')

# ------------------------------------------------------------------------------------------------ (3) the connection term
head('(3) [wf·CONN] the connection term of the frame: D_g = N^(-1/2) D\' N^(1/2), on the labels and by the vierbein formula')
# on the labels: fields P N^r exp(s J E t) with N = 1 - g x_3, as dicts {r: multivector}; d_t -> right factor s J E; d_3 -> r g' N^(r-1), g' = -g
def Dprime(alg, field, sg, E, g):
    """D' = N^-1 gamma^0 d_t + gamma^i d_i on {r: P}: gamma_0 P (s J E) N^(r-1) + gamma_3 P r (-g) N^(r-1)"""
    out = {}
    for r, P in field.items():
        t1 = alg.mul(alg.g[0], alg.mul(P, alg.lin((sg * E, alg.J)))); t3 = alg.lin((r * (-g), alg.mul(alg.g[3], P)))
        out[r - 1] = alg.lin((1, out.get(r - 1, {})), (1, t1), (1, t3))
    return {r: P for r, P in out.items() if P}
def Dg(alg, field, sg, E, g):
    """D_g = D' + gamma^3 (d_3 N)/(2N) = D' + gamma_3 (-g)/(2N)"""
    out = Dprime(alg, field, sg, E, g)
    if fault('NOCONN'): return out
    for r, P in field.items():
        out[r - 1] = alg.lin((1, out.get(r - 1, {})), (Fr(-g, 2), alg.mul(alg.g[3], P)))
    return {r: P for r, P in out.items() if P}
def shiftN(field, h): return {r + h: P for r, P in field.items()}
ok_conn = True; g = Fr(1, 10); half = Fr(1) if fault('SQRTONE') else Fr(1, 2)
import random
rg = random.Random(7)
for trial in range(12):
    P = {A4.EV[i]: Fr(rg.randint(-3, 3)) for i in rg.sample(range(len(A4.EV)), 4)}
    r = Fr(rg.randint(-3, 3), 2); sg = rg.choice((-1, 1)); E = Fr(rg.randint(1, 5))
    field = {r: P}
    lhs = Dg(A4, field, sg, E, g); rhs = shiftN(Dprime(A4, shiftN(field, half), sg, E, g), -half)
    ok_conn &= lhs == rhs
chk('bit', ok_conn, 'wf.CONN: on the labels, D_g = N^(-1/2) D\' N^(1/2) exactly on 12 random fields P N^r exp(s J E t) (N = 1 - g x_3, r half-integers): the connection term gamma^3 d_3 N/(2N) is the conjugation by N^(1/2) and does not change the frame frequency; for a constant N it vanishes')
# first order: the connection coefficient -g/(2N) against (1/2) d_3 Phi = N g/2 in magnitude, with Phi = (1 - N^2)/2 = g x_3 - g^2 x_3^2/2: the difference is g Phi/N = O(g^2)
x3 = Fr(1, 3); N = 1 - g * x3; Phi3 = (1 - N * N) / 2
chk('bit', (g / (2 * N) - N * g / 2) == g * Phi3 / N and Phi3 == g * x3 - g * g * x3 * x3 / 2,
    'wf.CONN: the connection coefficient g/(2N) equals (1/2) d_3 Phi = N g/2 up to g Phi/N = O(g^2) (exactly, at x_3 = 1/3): the second term of the paper\'s S, (1/2) gamma d Phi, is the connection of the frame to first order (its sign is a matter of the conventions for gamma_i and Phi)')
# the standard route: the vierbein formula, numpy
S1 = np.array([[0, 1], [1, 0]], complex); S2 = np.array([[0, -1j], [1j, 0]]); S3 = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
GM = [np.block([[I2, 0 * I2], [0 * I2, -I2]])] + [np.block([[0 * I2, s_], [-s_, 0 * I2]]) for s_ in (S1, S2, S3)]; I4 = np.eye(4)
ETA = np.diag([1.0, -1, -1, -1]); gN = 0.1
def Nf(x): return 1 - gN * x[3]
def metric(x): return np.diag([Nf(x) ** 2, -1.0, -1.0, -1.0])
def vierbein(x):
    """E[a, mu]: e^a = E[a, mu] dx^mu"""
    return np.diag([Nf(x), 1.0, 1.0, 1.0])
def d4(fun, x, mu, h=1e-3):
    e = np.zeros(4); e[mu] = h; return (-fun(x + 2 * e) + 8 * fun(x + e) - 8 * fun(x - e) + fun(x - 2 * e)) / (12 * h)
def christoffel(x):
    gm = metric(x); gi = np.linalg.inv(gm); dg = np.array([d4(metric, x, mu) for mu in range(4)])
    return np.array([[[0.5 * sum(gi[l, r] * (dg[m, r, n] + dg[n, r, m] - dg[r, m, n]) for r in range(4)) for n in range(4)] for m in range(4)] for l in range(4)])
def spin_connection(x):
    """omega_mu^a_b = e^a_nu (d_mu e_b^nu + Gamma^nu_{mu lambda} e_b^lambda); Gamma_mu = (1/4) omega_{mu a b} gamma^a gamma^b"""
    Ea = vierbein(x); Einv = np.linalg.inv(Ea)                               # Einv[mu, a]: the frame vectors e_a = Einv[mu, a] d_mu
    dEinv = np.array([d4(lambda y: np.linalg.inv(vierbein(y)), x, mu) for mu in range(4)])
    G = christoffel(x); om = np.zeros((4, 4, 4))
    for mu in range(4):
        for a in range(4):
            for b in range(4):
                om[mu, a, b] = sum(Ea[a, nu] * (dEinv[mu, nu, b] + sum(G[nu, mu, l] * Einv[l, b] for l in range(4))) for nu in range(4))
    Gam = []
    for mu in range(4):
        M = np.zeros((4, 4), complex)
        for a in range(4):
            for b in range(4):
                M += 0.25 * ETA[a, a] * om[mu, a, b] * GM[a] @ GM[b]
        Gam.append(M)
    return Gam
def dirac_g(psi, x):
    """D_g psi = gamma^a e_a^mu (d_mu + Gamma_mu) psi at x, by the vierbein formula"""
    Einv = np.linalg.inv(vierbein(x)); Gam = spin_connection(x)
    out = np.zeros(4, complex)
    for a in range(4):
        for mu in range(4):
            if Einv[mu, a] == 0: continue
            out += GM[a] @ (Einv[mu, a] * (d4(lambda y: psi(y), x, mu) + (0 if fault('NOCONN') else Gam[mu] @ psi(x))))
    return out
def dirac_prime(psi, x):
    Einv = np.linalg.inv(vierbein(x)); out = np.zeros(4, complex)
    for a in range(4):
        for mu in range(4):
            if Einv[mu, a] == 0: continue
            out += GM[a] @ (Einv[mu, a] * d4(lambda y: psi(y), x, mu))
    return out
def test_psi(x):
    u = np.array([1.0, 0.3 + 0.2j, -0.4, 0.7j]); return u * np.exp(-1j * 2.0 * x[0]) * np.exp(-0.5 * x[3] ** 2 + 0.3 * x[1] - 0.2 * x[2])
pw = 1.0 if fault('SQRTONE') else 0.5
ok_v = True; worst = 0.0
for x in (np.array([0.3, 0.1, -0.2, 0.5]), np.array([-1.0, 0.4, 0.3, -0.7]), np.array([0.0, 0.0, 0.0, 1.5])):
    lhs = dirac_g(test_psi, x); rhs = Nf(x) ** (-pw) * dirac_prime(lambda y: Nf(y) ** pw * test_psi(y), x)
    conn = lhs - dirac_prime(test_psi, x); want = (-gN / (2 * Nf(x))) * (GM[3] @ test_psi(x))
    dev = max(np.abs(lhs - rhs).max(), np.abs(conn - want).max()); worst = max(worst, dev); ok_v &= dev < 1e-7
chk('std', ok_v, 'wf.CONN: numpy, the vierbein formula (finite differences, 4-point stencils): the Dirac operator of (1 - 2 Phi) dt^2 - dx^2 with N = 1 - g x_3 on a test spinor field equals N^(-1/2) D\' N^(1/2), and its connection term is gamma^3 d_3 N/(2N) (3 points, max deviation %.1e)' % worst)

# ------------------------------------------------------------------------------------------------ (4) the standard route for (1) and (2)
head('(4) [std] Dirac matrices and scipy expm: the redshifted kernels and the Phi-derivative')
def Kmat(k, sg): return -sum(sg * float(k[i]) * GM[i] for i in range(4))
def cker(M, tol=1e-8):
    sv = np.linalg.svd(M, compute_uv=False); return 4 - int(np.sum(sv > tol * max(1.0, sv[0])))
def paper_std(k, sg, m, kap, tau):
    K = Kmat(k, sg); return K - m * I4 + 1j * kap * expm(1j * tau * K)
def frame_k_f(k, a): return list(k) if fault('NOFRAME') else [a * k[0]] + list(k[1:])
ok_s = True
for Phi, a in POTS:
    af = float(a)
    for par, E, th in CASES:
        tau = theta_of(par) / float(E)
        for sg in (-1, 1):
            on = 2 * cker(paper_std(frame_k_f([float(E) / af, 0, 0, 0], af), sg, m, kap, tau))     # coordinate E/a: frame frequency E
            off = 2 * cker(paper_std(frame_k_f([float(E), 0, 0, 0], af), sg, m, kap, tau))          # coordinate E: frame frequency a E
            ok_s &= on == 4 and off == 0
chk('std', ok_s, 'wf.STD: Dirac matrices with scipy expm: 4 real dimensions at the coordinate frequency E/a, none at E, in the 5 potentials, both parities and sectors')
ok_d = True; worst = 0.0; mus = []
for par, E, th in CASES:
    tau = (math.pi / 2 if par == 0 else 3 * math.pi / 2) / float(E); mu = kap * tau
    for sg in (-1, 1):
        M0 = paper_std([float(E), 0, 0, 0], sg, m, kap, tau); u_, s_, vh = np.linalg.svd(M0); U = vh[-2:].conj().T       # the kernel (4 real = 2 complex dimensions)
        h = 1e-6
        dM = (paper_std([float(E) * (1 + h), 0, 0, 0], sg, m, kap, tau) - paper_std([float(E) * (1 - h), 0, 0, 0], sg, m, kap, tau)) / (2 * h)
        for j in range(U.shape[1]):
            u = U[:, j]; w = dM @ u; coeff = np.vdot(u, w)                     # <u, dM u>: E (1 - i (-1)^n mu) if w is along u
            dev = max(abs(w - coeff * u).max(), abs(coeff - float(E) * (1 - 1j * (-1) ** par * mu)))
            worst = max(worst, dev); ok_d &= dev < 1e-5
        mus.append(mu)
chk('std', ok_d, 'wf.STD: the Phi-derivative of K_Phi - m + i kappa expm(i tau K_Phi) on the rest solutions (finite differences in Phi) is E (1 - i (-1)^n mu) u: real part E, imaginary part -(-1)^n mu E, mu = kappa tau = %.4f (n = 0, E = 5) and %.4f (n = 1, E = 1) (max deviation %.1e); for the paper\'s comparison, mu = kappa (n + 1/2) pi / E_0 is 1.6e-13 at n = 0 when kappa/E_0 = 1e-13' % (mus[0], mus[2], worst))
# the two routes side by side: the exact coordinates (E, (-1)^(n+1) kappa theta) at theta = (n + 1/2) pi against the numeric E (1 - i (-1)^n mu)
agree = True
for par, E, th in CASES:
    theta = theta_of(par); mu = kap * theta / float(E)
    for sg in (-1, 1):
        P = kernel(A4, paper_eq(A4, [E, 0, 0, 0], sg, m, kap, E, *th))[0]
        co = coords(A4, phi_coefficient(A4, P, [E, 0, 0, 0], sg, m, kap, E, par, Fr(theta).limit_denominator(10 ** 9)), [P, A4.mul(P, A4.J)])
        agree &= co is not None and float(co[0]) == float(E) and abs(float(co[1]) - (-(-1) ** par * mu * float(E))) < 1e-7
chk('bit==std', agree, 'wf.STD: the exact coordinates on (P, P J) at theta = (n + 1/2) pi and the numeric real and imaginary parts agree: E and (-1)^(n+1) mu E, both parities and sectors')
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('SHIFTED-WEAKFIELD')
