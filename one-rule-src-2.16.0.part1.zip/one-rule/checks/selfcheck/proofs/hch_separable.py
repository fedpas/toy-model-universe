#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""hch_separable.py -- separability of the cells, their Hochschild groups, and the exterior algebra with the Berezin integral as a Frobenius
algebra: its coproduct, the handle m o Delta, the closed-surface numbers.

Statements.
(1) Cl(p,q) is separable: e = 2^(-n) sum_a e_a^(-1) (x) e_a satisfies m(e) = 1 and x e = e x for every x, and e is even.  A cell with r >= 1
    has no separability idempotent over R, and has one over Lambda(R^r), in A (x)_Lambda A.  HH^1 = HH^2 = 0 for Cl(p,q); the exterior algebra
    has HH^1, HH^2 != 0; the graded groups of Cl(1,0,1) and Cl(0,1,1) are those of Cl(0,0,1).
(2) Lambda(R^r) is super-commutative and the Berezin integral eps (the coefficient of the top label e_F) is a non-degenerate Frobenius form of
    parity r mod 2.  Its copairing gamma = G^(-1) (G_ab = eps(e_a e_b)) satisfies both zigzag identities, Delta(x) = sum x b_j (x) c_j is a
    bimodule map, coassociative and counital, and m o Delta is multiplication by H = m(gamma) = sum_S (-1)^(|S|(r-|S|)) e_F: 2^r e_F for r
    odd, 0 for r even.  The element sum_a e_a e_a^v with eps(e_a e_a^v) = 1 is 2^r e_F for every r, so it is m o Delta(1) only for r odd.  For
    every cell with n <= 5 and its top-label form, m(gamma) = 2^n e_F (n odd) or 0 (n even).  eps(H^g), tr and str of (m o Delta)^(g-1).
    With the scalar-part form on Cl(p,q), m o Delta = 2^n id and Delta(1)/2^n is the separability idempotent of (1).
[bit]  The bit rule (exact Fractions): separability by direct products and by an exact consistency test of the linear system for e (cells
       n <= 3 and Lambda(R^4)); A (x)_Lambda A as the free module on e_a (x) e_c (a without null bits), with the left and the right action
       checked to satisfy the relations of the cell; the bar complex (ungraded, and graded with the sign (-1)^(|a1||f|)) ranked exactly.
[std]  Cl(p,q) as real Jordan-Wigner matrices (no bit rule), structure constants read off the matrix products, the bar differential as dense
       numpy arrays with numpy matrix_rank (tolerance 1e-8); the exterior algebra on sorted index tuples with the sign of the merging
       permutation counted by inversions, numpy for G^(-1) and H (tolerance 1e-9).
[ctl]  The dual basis in the order sum_a e_a (x) e_a^v fails the zigzag identity for r even; the plain flip fails super-commutativity for
       r >= 2; the scalar part is degenerate on Lambda(R^r); e_a in place of e_a^(-1) is no separability idempotent; the null generator moved
       across (x)_Lambda without its Koszul sign breaks the relations; the bar differential without its signs gives other groups.
       Each wrong version is also a --fault option that puts it into the main lines.
Scope. Separability: p + q <= 6 (direct), n <= 3 and Lambda(R^4) (linear system), r >= 1 with n <= 4 (relative); Hochschild groups p + q <= 3;
       Frobenius structure r = 1..4, handle element every cell with n <= 5.  Recalled, not computed: separable => HH^(>=1)(A, M) = 0 for every
       bimodule M (Hochschild; DeMeyer, Ingraham), the Kuenneth formula, commutative Frobenius algebras = 2d TQFTs (Abrams; Kock), special iff
       separable (Kock; Lauda, Pfeiffer).  No engine object is built: the faults of the gravity engine do not apply.
Run:   python3 hch_separable.py [--fault HHSIGN|SEPWRONG|RELWRONG|DUALORD|NOKOSZUL|SCALARCOUNIT]
       (from the package root as selfcheck/proofs/hch_separable.py; also from its own folder, and under -I -B)"""
import os, sys, itertools, time
from fractions import Fraction
sys.dont_write_bytecode = True
import numpy as np

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'HCH-SEP'
FAULT_NAMES = ['HHSIGN', 'SEPWRONG', 'RELWRONG', 'DUALORD', 'NOKOSZUL', 'SCALARCOUNIT']
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)

# ------------------------------------------------------------------ [bit] the bit rule
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
def cells(nmin, nmax):
    return [(p, n - r - p, r) for n in range(nmin, nmax + 1) for r in range(n + 1) for p in range(n - r + 1)]

def rank_q(vectors):
    piv = {}; rk = 0
    for v in vectors:
        v = {k: Fraction(x) for k, x in v.items() if x}
        while v:
            k = min(v)
            if k in piv:
                f = v[k]
                for kk, x in piv[k].items():
                    y = v.get(kk, 0) - f * x
                    if y: v[kk] = y
                    else: v.pop(kk, None)
            else:
                f = v[k]; piv[k] = {kk: x / f for kk, x in v.items()}; rk += 1
                break
    return rk
def consistent(rows, nvar):
    """rows: list of (dict var -> coef, rhs); True iff the system has a solution (exact ranks with and without the right-hand side)"""
    A = [dict(r) for r, b in rows]; Ab = []
    for r, b in rows:
        rr = dict(r)
        if b: rr[nvar] = b
        Ab.append(rr)
    return rank_q(A) == rank_q(Ab)

def addto(D, k, v):
    y = D.get(k, 0) + v
    if y: D[k] = y
    else: D.pop(k, None)

# ------------------------------------------------------------------ part 1a: the separability idempotent of Cl(p,q)
def sep_idempotent_ok(eps):
    n = len(eps); d = 1 << n
    e = {}
    for a in range(d):
        inv = Fraction(1, sgn(a, a, eps)) if not fault('SEPWRONG') else Fraction(1)        # e_a^(-1) = e_a / e_a^2
        addto(e, (a, a), inv / d)                                                           # the term e_a^(-1) (x) e_a, both factors on label a
    m = {}
    for (i, j), c in e.items(): addto(m, i ^ j, c * sgn(i, j, eps))
    ok_m = (m == {0: 1})
    ok_c = True
    for g in range(n):
        x = 1 << g; L = {}; R = {}
        for (i, j), c in e.items():
            s1 = sgn(x, i, eps); s2 = sgn(j, x, eps)
            if s1: addto(L, (x ^ i, j), c * s1)
            if s2: addto(R, (i, j ^ x), c * s2)
        ok_c &= (L == R)
    even = all((pc(i) + pc(j)) % 2 == 0 for (i, j) in e)
    return ok_m, ok_c, even

def sep_system(eps):
    """is there e in A (x) A with m(e) = 1 and x e = e x for every generator x?  exact consistency test"""
    n = len(eps); d = 1 << n; var = lambda i, j: i * d + j; rows = []
    for k in range(d):
        r = {}
        for i in range(d):
            j = i ^ k; s = sgn(i, j, eps)
            if s: r[var(i, j)] = s
        rows.append((r, 1 if k == 0 else 0))
    for g in range(n):
        x = 1 << g; eqs = {}
        for i in range(d):
            for j in range(d):
                s1 = sgn(x, i, eps)
                if s1: eqs.setdefault((x ^ i, j), {})[var(i, j)] = eqs.setdefault((x ^ i, j), {}).get(var(i, j), 0) + s1
                s2 = sgn(j, x, eps)
                if s2: eqs.setdefault((i, j ^ x), {})[var(i, j)] = eqs.setdefault((i, j ^ x), {}).get(var(i, j), 0) - s2
        rows += [({k: v for k, v in r.items() if v}, 0) for r in eqs.values()]
    return consistent(rows, d * d)

def relative_model(p, q, r):
    """A (x)_Lambda A for A = Cl(p,q,r): the free module on (a, c), a a fibre label (no null bit), c any label.
    Returns the left and right actions of the generators and the multiplication map, as functions on basis pairs."""
    eps = sig(p, q, r); n = len(eps); d = 1 << n; N = sum(1 << i for i in range(n) if eps[i] == 0)
    fib = [a for a in range(d) if not a & N]
    def left(g, a, c):
        x = 1 << g
        if not x & N:
            s = sgn(x, a, eps); return [((x ^ a, c), s)] if s else []
        k = 1 if fault('RELWRONG') else sgn(x, a, eps) * sgn(a, x, eps)                    # z e_a = (z e_a / e_a z) e_a z, then z crosses (x)_Lambda
        s = sgn(x, c, eps)
        return [((a, x ^ c), k * s)] if s else []
    def right(g, a, c):
        x = 1 << g; s = sgn(c, x, eps); return [((a, c ^ x), s)] if s else []
    def mult(a, c):
        s = sgn(a, c, eps); return (a ^ c, s)
    return eps, n, d, N, fib, left, right, mult

def relative_checks(p, q, r):
    eps, n, d, N, fib, left, right, mult = relative_model(p, q, r)
    basis = [(a, c) for a in fib for c in range(d)]
    def act(op, g, vec):
        out = {}
        for (a, c), v in vec.items():
            for key, s in op(g, a, c): addto(out, key, v * s)
        return out
    rel_ok = True
    for (a, c) in basis:                                      # the actions satisfy the relations of the cell and commute with each other
        v = {(a, c): 1}
        for g in range(n):
            for h in range(n):
                for op in (left, right):
                    gh = act(op, h, act(op, g, v)); hg = act(op, g, act(op, h, v))
                    if g == h:
                        want = {k: x * eps[g] for k, x in v.items()} if eps[g] else {}
                        rel_ok &= (gh == want)
                    else:
                        tot = dict(gh)
                        for k, x in hg.items(): addto(tot, k, x)
                        rel_ok &= (tot == {})
                rel_ok &= act(left, g, act(right, h, v)) == act(right, h, act(left, g, v))
    idx = {b: i for i, b in enumerate(basis)}; rows = []
    for k in range(d):                                        # m(e) = 1
        rr = {}
        for (a, c) in basis:
            lab, s = mult(a, c)
            if s and lab == k: rr[idx[(a, c)]] = rr.get(idx[(a, c)], 0) + s
        rows.append(({kk: v for kk, v in rr.items() if v}, 1 if k == 0 else 0))
    for g in range(n):                                        # x e = e x
        eqs = {}
        for b in basis:
            for key, s in left(g, *b): eqs.setdefault(key, {})[idx[b]] = eqs.setdefault(key, {}).get(idx[b], 0) + s
            for key, s in right(g, *b): eqs.setdefault(key, {})[idx[b]] = eqs.setdefault(key, {}).get(idx[b], 0) - s
        rows += [({kk: v for kk, v in rr.items() if v}, 0) for rr in eqs.values()]
    solvable = consistent(rows, len(basis))
    # the explicit element 2^-(p+q) sum_a e_a^-1 (x) e_a over the fibre labels
    e = {}
    for a in fib: addto(e, (a, a), Fraction(1, sgn(a, a, eps)) / len(fib))
    m = {}
    for (a, c), v in e.items():
        lab, s = mult(a, c)
        if s: addto(m, lab, v * s)
    expl = (m == {0: 1}) and all(act(left, g, e) == act(right, g, e) for g in range(n))
    return rel_ok, solvable, expl, len(basis)

head('hch·6 CAND-068: Cl(p,q) is separable; the cells with a null generator are separable over Lambda(R^r) only')
res6 = {}
for (p, q, r) in cells(1, 6):
    if r: continue
    res6[(p, q)] = sep_idempotent_ok(sig(p, q))
chk('bit', all(all(v) for v in res6.values()),
    'for all %d signatures Cl(p,q) with 1 <= p + q <= 6 the element 2^(-n) sum_a e_a^(-1) (x) e_a has m(e) = 1 and commutes with every generator (x e = e x in A (x) A), and every term is even: a separability idempotent of the superalgebra (exact)' % len(res6))
sysres = {}
for (p, q, r) in cells(1, 3) + [(0, 0, 4)]:
    sysres[(p, q, r)] = sep_system(sig(p, q, r))
chk('bit', all(v == (k[2] == 0) for k, v in sysres.items()),
    'the linear system m(e) = 1, x e = e x for e in A (x) A (4^n unknowns, exact consistency test) is solvable exactly for the %d cells with r = 0 among the %d cells with n <= 3 and Lambda(R^4): no cell with a null generator is separable over R (unsolvable for %s)'
    % (sum(1 for k in sysres if k[2] == 0), len(sysres), sorted(k for k, v in sysres.items() if not v)))
relres = {}
for (p, q, r) in cells(1, 4):
    if r: relres[(p, q, r)] = relative_checks(p, q, r)
chk('bit', all(all(v[:3]) for v in relres.values()),
    'over Lambda(R^r): in A (x)_Lambda A (the free module on e_a (x) e_c, a a label without null bit; its left and right actions satisfy the relations of the cell and commute) the system m(e) = 1, x e = e x is solvable, and 2^-(p+q) sum_a e_a^-1 (x) e_a over the fibre labels is a solution, for all %d cells with r >= 1 and n <= 4 (up to %d unknowns): separable relative to Lambda(R^r)'
    % (len(relres), max(v[3] for v in relres.values())))
if not FAULT:
    FAULT = 'SEPWRONG'; w1 = sep_idempotent_ok(sig(0, 1)); FAULT = 'RELWRONG'; w2 = relative_checks(1, 0, 1); FAULT = None
    chk('ctl', not all(w1) and not w2[0],
        'wrong versions: e_a in place of e_a^(-1) is no separability idempotent of Cl(0,1) (m(e) = 1: %s, central: %s); the null generator moved across (x)_Lambda without its Koszul sign gives actions that violate the relations of Cl(1,0,1)' % (w1[0], w1[1]))
tline('part 1a')

# ------------------------------------------------------------------ part 1b: Hochschild groups, [bit] exact and [std] numpy
class Alg:
    def __init__(self, d, mul, par):
        self.d = d; self.mul = mul; self.par = par                    # mul[i][j] = dict k -> coef
        self.fact = [[] for _ in range(d)]
        for i in range(d):
            for j in range(d):
                for k, c in mul[i][j].items(): self.fact[k].append((i, j, c))
def bit_alg(eps):
    d = 1 << len(eps)
    mul = [[({i ^ j: sgn(i, j, eps)} if sgn(i, j, eps) else {}) for j in range(d)] for i in range(d)]
    return Alg(d, mul, [pc(a) % 2 for a in range(d)])
def hh_bit(A, kmax, graded):
    """dims of HH^0..HH^kmax (both parities summed), exact; graded: Koszul sign (-1)^(|a1||f|) and blocks by parity"""
    d = A.d; res = []
    def col(inp, out):
        k = len(inp); c = {}
        pf = (A.par[out] + sum(A.par[x] for x in inp)) % 2
        for a1 in range(d):
            sg = (-1) ** (A.par[a1] * pf) if graded else 1
            for o, v in A.mul[a1][out].items(): addto(c, ((a1,) + inp, o), sg * v)
        for i in range(1, k + 1):
            sg = 1 if fault('HHSIGN') else (-1) ** i
            for (x, y, v) in A.fact[inp[i - 1]]: addto(c, (inp[:i - 1] + (x, y) + inp[i:], out), sg * v)
        for a in range(d):
            for o, v in A.mul[out][a].items(): addto(c, (inp + (a,), o), (-1) ** (k + 1) * v)
        return c
    prev = {0: 0, 1: 0}
    for k in range(kmax + 1):
        cols = {0: [], 1: []}
        for inp in itertools.product(range(d), repeat=k):
            for out in range(d):
                par = (A.par[out] + sum(A.par[x] for x in inp)) % 2 if graded else 0
                cols[par].append(col(inp, out))
        rk = {p_: rank_q(cols[p_]) for p_ in (0, 1)}
        res.append(sum(len(cols[p_]) - rk[p_] - prev[p_] for p_ in (0, 1))); prev = rk
    return res

def jw_matrices(p, q):
    """[std] real Jordan-Wigner matrices for p generators of square +1 and q of square -1 (no bit rule)"""
    n = p + q; X = np.array([[0, 1], [1, 0]]); Zm = np.array([[1, 0], [0, -1]]); J = np.array([[0, -1], [1, 0]]); I = np.eye(2, dtype=int)
    gens = []
    for k in range(n):
        M = np.array([[1]])
        for j in range(n): M = np.kron(M, Zm if j < k else ((X if k < p else J) if j == k else I))
        gens.append(M)
    return gens
def std_alg(p, q):
    gens = jw_matrices(p, q); n = p + q; d = 1 << n
    B = []
    for a in range(d):
        M = np.eye(1 << n, dtype=int)
        for i in range(n):
            if a >> i & 1: M = M @ gens[i]
        B.append(M)
    F = np.array([b.flatten() for b in B], dtype=float).T                           # columns: the basis matrices
    indep = np.linalg.matrix_rank(F) == d
    M3 = np.zeros((d, d, d))
    for i in range(d):
        for j in range(d):
            c, *_ = np.linalg.lstsq(F, (B[i] @ B[j]).flatten().astype(float), rcond=None)
            M3[i, j] = np.round(c)
            assert np.allclose(F @ M3[i, j], (B[i] @ B[j]).flatten())
    return M3, indep, gens
def hh_std(M3, kmax=2):
    """dense numpy bar complex, ungraded: dims HH^0..HH^kmax (numerical rank, tol 1e-8)"""
    d = M3.shape[0]; ranks = {-1: 0}; res = []
    for k in range(kmax + 1):
        cols = []
        for inp in itertools.product(range(d), repeat=k):
            for o in range(d):
                c = np.zeros((d,) * (k + 1) + (d,))
                if k == 0:
                    c[:, :] += M3[:, o, :]; c[:, :] -= M3[o, :, :]
                elif k == 1:
                    i1, = inp
                    c[:, i1, :] += M3[:, o, :]; c[:, :, o] -= M3[:, :, i1]; c[i1, :, :] += M3[o, :, :]
                elif k == 2:
                    i1, i2 = inp
                    c[:, i1, i2, :] += M3[:, o, :]; c[:, :, i2, o] -= M3[:, :, i1]; c[i1, :, :, o] += M3[:, :, i2]; c[i1, i2, :, :] -= M3[o, :, :]
                cols.append(c.flatten())
        D = np.array(cols).T
        ranks[k] = int(np.linalg.matrix_rank(D, tol=1e-8))
        res.append(d ** (k + 1) - ranks[k] - ranks[k - 1])
    return res

head('hch·7 CAND-068: Hochschild groups of Cl(p,q) (ungraded and graded) and of the exterior algebra, exact and numpy')
FIB = [(1, 0), (0, 1), (2, 0), (1, 1), (0, 2), (3, 0), (2, 1), (1, 2), (0, 3)]
hb = {}; hs = {}; hg = {}; indep_all = True
for (p, q) in FIB:
    A = bit_alg(sig(p, q))
    hb[(p, q)] = hh_bit(A, 2, graded=False); hg[(p, q)] = hh_bit(A, 2, graded=True)
    M3, indep, _ = std_alg(p, q); indep_all &= indep
    hs[(p, q)] = hh_std(M3, 2)
ctr = {k: (1 if (k[0] + k[1]) % 2 == 0 else 2) for k in FIB}
chk('bit', all(hb[k] == [ctr[k], 0, 0] for k in FIB) and all(hg[k] == [1, 0, 0] for k in FIB),
    'exact bar complex of the bit rule for the nine cells 1 <= p + q <= 3: ungraded HH^0, HH^1, HH^2 = (dim of the centre, 0, 0): %s; graded (super) HH^0, HH^1, HH^2 = (1, 0, 0) for all nine (as bd·hh·2)'
    % {('%d,%d' % k): hb[k] for k in FIB})
chk('std', indep_all and all(hs[k] == [ctr[k], 0, 0] for k in FIB),
    'real Jordan-Wigner matrices (2^n x 2^n, the 2^n ordered products independent) with structure constants read off the matrix products, dense numpy bar complex: ungraded HH^0, HH^1, HH^2 = %s' % {('%d,%d' % k): hs[k] for k in FIB})
chk('bit==std', all(hb[k] == hs[k] for k in FIB), 'the ungraded groups of the two routes agree on all nine cells')
hl = {r: (hh_bit(bit_alg(sig(0, 0, r)), 2, False), hh_bit(bit_alg(sig(0, 0, r)), 2, True)) for r in (1, 2)}
chk('ctl', all(hl[r][0][1] > 0 and hl[r][0][2] > 0 and hl[r][1][1] > 0 and hl[r][1][2] > 0 for r in (1, 2)),
    'the exterior algebra is not rigid: Lambda(R^1) has ungraded HH^0..2 = %s and graded %s; Lambda(R^2) ungraded %s and graded %s' % (hl[1][0], hl[1][1], hl[2][0], hl[2][1]))
deg = {c: hh_bit(bit_alg(sig(*c)), 2, True) for c in [(1, 0, 1), (0, 1, 1), (0, 0, 1)]}
chk('bit', deg[(1, 0, 1)] == deg[(0, 0, 1)] == deg[(0, 1, 1)],
    'absolute graded groups of the degenerate cells are those of the exterior algebra: HH^0..2 of Cl(1,0,1) = %s, of Cl(0,1,1) = %s, of Cl(0,0,1) = %s (the fibre has super-centre R; the relative groups over Lambda(R^1) vanish: bd·hh·3)'
    % (deg[(1, 0, 1)], deg[(0, 1, 1)], deg[(0, 0, 1)]))
head('hch·6 CAND-068 [std]: the separability idempotent in the real matrix model (Kronecker products, no bit rule)')
okS = True; nS = 0
for (p, q, r) in cells(1, 4):
    if r: continue
    gens = jw_matrices(p, q); n = p + q; d = 1 << n; D = 1 << n
    Bm = []
    for a in range(d):
        M = np.eye(D)
        for i in range(n):
            if a >> i & 1: M = M @ gens[i]
        Bm.append(M)
    E = sum(np.kron(np.linalg.inv(M), M) for M in Bm) / d                       # u (x) v -> kron(u, v), injective on A (x) A
    mE = sum(np.linalg.inv(M) @ M for M in Bm) / d
    okS &= np.allclose(mE, np.eye(D), atol=1e-9) and all(np.allclose(np.kron(G, np.eye(D)) @ E, E @ np.kron(np.eye(D), G), atol=1e-9) for G in gens)
    nS += 1
chk('std', okS, 'real Jordan-Wigner matrices, all %d signatures 1 <= p + q <= 4: E = 2^-n sum_a kron(B_a^-1, B_a) has m(E) = 1 and kron(G, 1) E = E kron(1, G) for every generator G (numpy, tolerance 1e-9)' % nS)
chk('bit==std', okS and all(all(res6[(p, q)]) for (p, q, r) in cells(1, 4) if not r), 'the separability idempotent holds on both routes for every Cl(p,q) with 1 <= p + q <= 4')
tline('part 1b')

# ------------------------------------------------------------------ part 2: Lambda(R^r) with the Berezin integral
def frob_bit(eps, use_scalar=False, dual_order=False):
    """Frobenius data of the cell eps with the top-label form (or the scalar part): Gram, copairing, zigzags, Delta, H"""
    n = len(eps); d = 1 << n; F = d - 1
    lam = (lambda c: 1 if c == 0 else 0) if use_scalar else (lambda c: 1 if c == F else 0)
    def prod(a, b): s = sgn(a, b, eps); return (a ^ b, s)
    G = [[Fraction(prod(a, b)[1] * lam(a ^ b)) for b in range(d)] for a in range(d)]
    nondeg = rank_q([{j: G[i][j] for j in range(d) if G[i][j]} for i in range(d)]) == d
    if not nondeg: return dict(nondeg=False)
    # exact inverse (Gauss-Jordan)
    M = [row[:] + [Fraction(int(i == j)) for j in range(d)] for i, row in enumerate(G)]
    for c in range(d):
        pr = next(i for i in range(c, d) if M[i][c]); M[c], M[pr] = M[pr], M[c]; f = M[c][c]; M[c] = [x / f for x in M[c]]
        for i in range(d):
            if i != c and M[i][c]:
                g = M[i][c]; M[i] = [x - g * y for x, y in zip(M[i], M[c])]
    Gi = [row[d:] for row in M]
    gamma = {(j, k): Gi[j][k] for j in range(d) for k in range(d) if Gi[j][k]}                  # copairing sum_jk Gi_jk e_j (x) e_k
    if dual_order: gamma = {(k, j): v for (j, k), v in gamma.items()}                        # the order sum_a e_a (x) e_a^v
    def ev(a, b): lab, s = prod(a, b); return s * lam(lab)
    z1 = all({k: v for k, v in ((k, sum(gamma.get((j, k), 0) * ev(x, j) for j in range(d))) for k in range(d)) if v} == {x: 1} for x in range(d))
    z2 = all({j: v for j, v in ((j, sum(gamma.get((j, k), 0) * ev(k, x) for k in range(d))) for j in range(d)) if v} == {x: 1} for x in range(d))
    def Delta(x):                                                                              # (m (x) id)(x (x) gamma)
        out = {}
        for (j, k), v in gamma.items():
            lab, s = prod(x, j)
            if s: addto(out, (lab, k), v * s)
        return out
    def Delta2(x):                                                                             # (id (x) m)(gamma (x) x)
        out = {}
        for (j, k), v in gamma.items():
            lab, s = prod(k, x)
            if s: addto(out, (j, lab), v * s)
        return out
    frob = all(Delta(x) == Delta2(x) for x in range(d))
    def lmul(x, T):
        out = {}
        for (i, j), v in T.items():
            lab, s = prod(x, i)
            if s: addto(out, (lab, j), v * s)
        return out
    def rmul(T, y):
        out = {}
        for (i, j), v in T.items():
            lab, s = prod(j, y)
            if s: addto(out, (i, lab), v * s)
        return out
    bimod = True
    for x in range(d):
        for y in range(d):
            lab, s = prod(x, y)
            Dxy = {k: v * s for k, v in Delta(lab).items()} if s else {}
            bimod &= (Dxy == lmul(x, Delta(y)) == rmul(Delta(x), y))
    def counit_l(T):
        out = {}
        for (i, j), v in T.items():
            if lam(i): addto(out, j, v)
        return out
    def counit_r(T):
        out = {}
        for (i, j), v in T.items():
            if lam(j): addto(out, i, v)
        return out
    counit = all(counit_l(Delta(x)) == {x: 1} == counit_r(Delta(x)) for x in range(d))
    coass = True
    for x in range(d):
        L = {}; R = {}
        for (i, j), v in Delta(x).items():
            for (a, b), w in Delta(i).items(): addto(L, (a, b, j), v * w)
            for (a, b), w in Delta(j).items(): addto(R, (i, a, b), v * w)
        coass &= (L == R)
    H = {}
    for (j, k), v in gamma.items():
        lab, s = prod(j, k)
        if s: addto(H, lab, v * s)
    mD = True
    for x in range(d):
        md = {}
        for (i, j), v in Delta(x).items():
            lab, s = prod(i, j)
            if s: addto(md, lab, v * s)
        xh = {}
        for lab, v in H.items():
            l2, s = prod(x, lab)
            if s: addto(xh, l2, v * s)
        mD &= (md == xh)
    return dict(nondeg=True, G=G, Gi=Gi, gamma=gamma, z1=z1, z2=z2, frob=frob, bimod=bimod, counit=counit, coass=coass, H=H, mD=mD, prod=prod, lam=lam, d=d, F=F)

def tqft_numbers(fd, eps):
    d, F, prod, lam, H = fd['d'], fd['F'], fd['prod'], fd['lam'], fd['H']
    def mul(X, Y):
        out = {}
        for a, v in X.items():
            for b, w in Y.items():
                lab, s = prod(a, b)
                if s: addto(out, lab, v * w * s)
        return out
    pw = {0: 1}; Z = []
    for g in range(5):
        Z.append(sum(v * lam(a) for a, v in pw.items())); pw = mul(pw, H)
    LH = [[Fraction(0)] * d for _ in range(d)]
    for b in range(d):
        for a, v in mul(H, {b: 1}).items(): LH[a][b] += v
    tr = []; st = []; P = [[Fraction(int(i == j)) for j in range(d)] for i in range(d)]
    for g in range(1, 5):
        tr.append(sum(P[i][i] for i in range(d))); st.append(sum((-1) ** pc(i) * P[i][i] for i in range(d)))
        P = [[sum(P[i][k] * LH[k][j] for k in range(d)) for j in range(d)] for i in range(d)]
    return [int(z) for z in Z], [int(t) for t in tr], [int(s) for s in st]

head('hch·8 CAND-007: Lambda(R^r), r = 1..4, with the Berezin integral: a Frobenius algebra; its parity; the handle m o Delta')
FR = {}
for r in range(1, 5):
    eps = sig(0, 0, r); d = 1 << r; F = d - 1
    fd = frob_bit(eps, use_scalar=fault('SCALARCOUNIT'), dual_order=fault('DUALORD'))
    if fault('NOKOSZUL'): scomm = all(sgn(a, b, eps) == sgn(b, a, eps) for a in range(d) for b in range(d))
    else: scomm = all(sgn(a, b, eps) == (-1) ** (pc(a) * pc(b)) * sgn(b, a, eps) for a in range(d) for b in range(d))
    ucomm = all(sgn(a, b, eps) == sgn(b, a, eps) for a in range(d) for b in range(d))
    FR[r] = fd
    if not fd['nondeg']:
        chk('bit', False, 'Lambda(R^%d): the chosen counit is degenerate' % r); continue
    parity = r % 2
    want_H = {F: d} if r % 2 else {}
    chk('bit', scomm and ucomm == (r <= 1) and fd['z1'] and fd['z2'] and fd['frob'] and fd['bimod'] and fd['counit'] and fd['coass'] and fd['mD'] and fd['H'] == want_H,
        'Lambda(R^%d): super-commutative (exact, all %d label pairs; commutative in the plain sense: %s); the Berezin integral is non-degenerate and has parity %d (%s); the copairing G^(-1) satisfies both zigzag identities; Delta is a bimodule map, coassociative, counital; m o Delta = multiplication by H = %s'
        % (r, d * d, ucomm, parity, 'even: a morphism of sVec' if parity == 0 else 'odd: not a morphism of sVec', ('%d e_top' % d) if fd['H'] else '0'))
gen = {}
for (p, q, r) in cells(1, 5):
    eps = sig(p, q, r); n = len(eps); d = 1 << n; F = d - 1
    fd = frob_bit(eps, dual_order=fault('DUALORD'))
    v22 = {}
    for a in range(d):                                                   # the bd·cat·22 element sum_a e_a e_a^v, lambda(e_a e_a^v) = 1
        b = a ^ F; s_ab = sgn(a, b, eps); addto(v22, F, Fraction(s_ab, s_ab))
    gen[(p, q, r)] = (fd['H'] == ({F: d} if n % 2 else {}), fd['z1'] and fd['z2'], v22 == {F: d}, (fd['H'] == v22) == (n % 2 == 1))
chk('bit', all(all(v) for v in gen.values()),
    'for all %d cells with 1 <= n <= 5 and the top-label form: the zigzag copairing gives m(gamma) = sum_a (-1)^(|a|(n-|a|)) e_F = 2^n e_F for n odd and 0 for n even; the element sum_a e_a e_a^v with lambda(e_a e_a^v) = 1 (bd·cat·22) is 2^n e_F for every n; the two agree exactly for n odd'
    % len(gen))
if not FAULT:
    bad = [r for r in (2, 4) if (lambda fd: fd['z1'] and fd['z2'])(frob_bit(sig(0, 0, r), dual_order=True))]
    good_odd = [r for r in (1, 3) if (lambda fd: fd['z1'] and fd['z2'])(frob_bit(sig(0, 0, r), dual_order=True))]
    chk('ctl', bad == [] and good_odd == [1, 3],
        'the copairing in the order sum_a e_a (x) e_a^v fails the zigzag identity for r = 2, 4 and satisfies it for r = 1, 3 (where the form is symmetric): the order of the dual basis matters exactly for r even')
    sc = frob_bit(sig(0, 0, 2), use_scalar=True)
    chk('ctl', not sc['nondeg'] and not all(sgn(a, b, [0, 0]) == sgn(b, a, [0, 0]) for a in range(4) for b in range(4)),
        'the scalar part is degenerate on Lambda(R^2) (not a Frobenius form), and the plain flip fails commutativity there (e_1 e_2 = -e_2 e_1): the super sign is needed')
tline('part 2a')

head('hch·9 CAND-007: closed-surface numbers eps(H^g), and the traces of (m o Delta)^(g-1); the scalar-part form on Cl(p,q)')
TQ = {}
for r in range(1, 5):
    if not FR[r].get('nondeg'): continue
    Z, tr, st = tqft_numbers(FR[r], sig(0, 0, r)); TQ[r] = (Z, tr, st)
    d = 1 << r
    want = ([0, 0, 0, 0, 0], [d, 0, 0, 0], [0, 0, 0, 0]) if r % 2 == 0 else ([0, d, 0, 0, 0], [d, 0, 0, 0], [0, 0, 0, 0])
    chk('bit', (Z, tr, st) == want and ((r % 2 == 0 and Z[1:] == st) or (r % 2 == 1 and Z[1:] == tr)),
        'Lambda(R^%d): eps(H^g) for g = 0..4 = %s; tr (m o Delta)^(g-1) for g = 1..4 = %s, str = %s: the numbers eps(H^g) are the %s traces (r %s)'
        % (r, Z, tr, st, 'super' if r % 2 == 0 else 'ungraded', 'even: every closed surface, the torus included, gets 0 = the super-dimension' if r % 2 == 0 else 'odd: the torus gets 2^r = dim, the ungraded trace; g = 0 and g >= 2 get 0'))
sp = {}
for (p, q, r) in cells(1, 4):
    if r: continue
    eps = sig(p, q); n = p + q; d = 1 << n
    fd = frob_bit(eps, use_scalar=True)
    sepe = {(a, a): Fraction(1, sgn(a, a, eps)) / d for a in range(d)}
    D1 = {k: v / d for k, v in fd['gamma'].items()}
    sp[(p, q)] = (fd['H'] == {0: d} and fd['mD'] and fd['z1'] and fd['z2'] and D1 == sepe)
chk('bit', all(sp.values()),
    'Cl(p,q) with the scalar-part form <xy>_0 (all %d signatures 1 <= p + q <= 4): the copairing is sum_a e_a (x) e_a^(-1), m o Delta = 2^n id, and Delta(1)/2^n is the separability idempotent of hch·6: special after rescaling, and so separable' % len(sp))
tline('part 2b')

# ------------------------------------------------------------------ [std] the exterior algebra on sorted tuples, numpy
head('hch·10 CAND-007: the same from the exterior algebra on sorted index tuples (no bit rule), numpy')
def ext_mul(A, B):
    if set(A) & set(B): return None, 0
    w = list(A) + list(B); inv = sum(1 for i in range(len(w)) for j in range(i + 1, len(w)) if w[i] > w[j])
    return tuple(sorted(w)), (-1) ** inv
std_ok = True; cmpb = True; Hs = {}
for r in range(1, 5):
    basis = [c for k in range(r + 1) for c in itertools.combinations(range(1, r + 1), k)]; d = len(basis); top = tuple(range(1, r + 1))
    pos = {b: i for i, b in enumerate(basis)}
    G = np.zeros((d, d))
    for i, A in enumerate(basis):
        for j, B in enumerate(basis):
            lab, s = ext_mul(A, B)
            if lab == top: G[i, j] = s
    Gi = np.linalg.inv(G)
    H = np.zeros(d)
    for i, A in enumerate(basis):
        for j, B in enumerate(basis):
            if abs(Gi[i, j]) > 1e-12:
                lab, s = ext_mul(A, B)
                if lab is not None: H[pos[lab]] += Gi[i, j] * s
    Hs[r] = H
    want = np.zeros(d); want[pos[top]] = 2 ** r if r % 2 else 0
    zig = np.allclose(G @ Gi, np.eye(d), atol=1e-9) and np.allclose(Gi @ G, np.eye(d), atol=1e-9)
    std_ok &= zig and np.allclose(H, want, atol=1e-9)
    mask = lambda T: sum(1 << (t - 1) for T_ in [T] for t in T_)
    if FR[r].get('nondeg'):
        Hb = np.zeros(d)
        for lab, v in FR[r]['H'].items():
            T = tuple(i + 1 for i in range(r) if lab >> i & 1); Hb[pos[T]] = float(v)
        Gb = np.array([[float(FR[r]['G'][mask(A)][mask(B)]) for B in basis] for A in basis])
        cmpb &= np.allclose(Gb, G, atol=1e-12) and np.allclose(Hb, H, atol=1e-9)
    else: cmpb = False
chk('std', std_ok, 'exterior algebra on sorted tuples (sign by inversion count), Berezin integral = coefficient of (1..r), numpy G^(-1): G G^(-1) = G^(-1) G = 1 and H = m(G^(-1)) = %s for r = 1..4 (tolerance 1e-9)'
    % ['%g e_top' % Hs[r][-1] for r in range(1, 5)])
chk('bit==std', cmpb, 'the Gram matrices and the handle elements of the two routes agree for r = 1..4 (labels matched to tuples by their bits; tolerance 1e-9)')
tline('part 2c')
finish(STEP)
