#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""hch_morita.py -- the invariants that read (clock, r) off a cell, the monoid of the cells under the graded tensor product, and the universal
groups of gradings of the cells (the label grading with its torsion, the Pauli gradings, four gradings that are not label-homogeneous).

Statements.
(1) For every cell Cl(p,q,r) with n = p + q + r <= 5: J = the span of the labels with a null bit is a two-sided ideal of dimension 2^(p+q)(2^r - 1),
    nilpotent of index r + 1, the kernel of the trace form, and A/J = Cl(p,q); the super-centre (z x = (-1)^(|z||x|) x z) has dimension 2^r and is
    Lambda(R^r).  The type of B = A/J and of its even part B_0 (centre dimension, the square of the central label, the sign of the trace-form
    excess: R, C, H, R+R, H+H) is the entry of p - q mod 8 in the table c -> (type B, type B_0): 0 (R, R+R), 1 (R+R, R), 2 (R, C), 3 (C, H),
    4 (H, H+H), 5 (H+H, H), 6 (H, C), 7 (C, R), with (R, R) for B = R.  So (clock, r) is read off (super-centre, A/J), and the invariants
    separate the (clock, r) classes.  Concatenation is the graded tensor product and adds (clock, r).
(2) The universal group of the label grading (one component per label) is Z2^(p+q) x Z^r, torsion included (Smith normal form).  The Pauli
    grading of M2(R) is the label grading of Cl(2,0) and of Cl(1,1); the Pauli grading of M2(C) is the label grading of Cl(3,0) coarsened along
    Z2^3 -> Z2^3/<111>.  The gradings E_ij (x) u of M2(R), M4(R), M2(C), M2(H) (u a unit of the division algebra) have universal groups Z, Z^3,
    Z x Z2, Z x Z2^2: free rank N - 1 > r = 0.  The cells with r = 0 and p - q = 1 mod 4 are not simple (centre R + R).
[bit]  The bit rule, exact: ideals and layers by label sets, the super-centre and the centre by the decoupled label equations, the trace form
       in the label basis, the invariants of B and B_0, the Koszul factorisation of the concatenated signature on all pairs n + n' <= 5, the
       relation matrix of the label grading and its Smith normal form over Z.
[std]  Cl(p,q) as real Jordan-Wigner matrices (no bit rule): the centre by a numpy null space, the square of the central element, the trace
       form tr(B_a B_b) by numpy eigenvalues, for B and B_0 (tolerance 1e-8); the expected group Z2^(p+q) x Z^r built as an explicit degree map
       and tested to be a grading whose support generates it; the Pauli matrices and the matrix units as integer and Gaussian-integer matrices.
[ctl]  The type of A/J alone does not separate the clocks (5 values on 8 classes); dim A/J is not constant on a class; the graded product
       without its Koszul sign is not the concatenated cell; the plain commutant in place of the super-centre; the clock table with 3 and 5
       swapped; the relation matrix without the square relations (a free group); a partition of M2(R) that is not a grading.
       Each wrong version is also a --fault option that puts it into the main lines.
Scope. n <= 5 (56 cells, n = 0 included), pairs n + n' <= 5, the four matrix algebras named.  Recalled, not computed: that the super-centre
       and A/J are graded-Morita invariants (Nastasescu, Van Oystaeyen; Bass), Wall's theorem on the graded Brauer group of R ("Graded Brauer
       groups"), that A (x)^ End(V) is graded-Morita equivalent to A, the signature of the trace form of M_N(D), and the classification of
       the gradings of matrix algebras (Bahturin, Zaicev; Elduque, Kochetov).  No engine object is built: the faults of the gravity engine do
       not apply.
Run:   python3 hch_morita.py [--fault NOKOSZUL|UNGRADEDCENTRE|TABLE35|NOSQUARE|BADGRADING]
       (from the package root as selfcheck/proofs/hch_morita.py; also from its own folder, and under -I -B)"""
import os, sys, itertools, time
from fractions import Fraction
from math import gcd
sys.dont_write_bytecode = True
import numpy as np

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'HCH-MOR'
FAULT_NAMES = ['NOKOSZUL', 'UNGRADEDCENTRE', 'TABLE35', 'NOSQUARE', 'BADGRADING']
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
CELLS = [(p, n - r - p, r) for n in range(0, 6) for r in range(n + 1) for p in range(n - r + 1)]

TABLE = {0: ('R', 'R+R'), 1: ('R+R', 'R'), 2: ('R', 'C'), 3: ('C', 'H'), 4: ('H', 'H+H'), 5: ('H+H', 'H'), 6: ('H', 'C'), 7: ('C', 'R')}
if fault('TABLE35'): TABLE[3], TABLE[5] = TABLE[5], TABLE[3]
def clock_of_pair(pair):
    if pair == ('R', 'R'): return 0                                                    # B = R, no odd part
    hits = [c for c, v in TABLE.items() if v == pair]
    return hits[0] if len(hits) == 1 else None

# ------------------------------------------------------------------ [bit] invariants of a cell given by any sign vector eps
def type_of(labels, eps):
    """type of the semisimple algebra spanned by the given labels (closed under the product, no null bit): centre, central square, excess"""
    lab = set(labels)
    centre = [c for c in labels if all(sgn(g, c, eps) == sgn(c, g, eps) for g in labels)]
    excess = sum(sgn(a, a, eps) for a in labels)                                         # trace form diagonal in the label basis
    if len(centre) == 1:
        return ('R' if excess > 0 else 'H'), len(centre), None, excess
    z = [c for c in centre if c != 0][0] if len(centre) == 2 else None
    if len(centre) != 2: return None, len(centre), None, excess
    zz = sgn(z, z, eps)
    if zz == -1: return 'C', 2, -1, excess
    return ('R+R' if excess > 0 else 'H+H'), 2, 1, excess
def invariants(eps):
    n = len(eps); d = 1 << n; N = sum(1 << i for i in range(n) if eps[i] == 0); r = pc(N); pq = n - r
    J = [a for a in range(d) if a & N]
    ideal = all(((x ^ j) & N) for x in range(d) for j in J if sgn(x, j, eps)) and all(((j ^ x) & N) for x in range(d) for j in J if sgn(j, x, eps))
    S = set(J); idx = 1
    while S:
        S = {a ^ b for a in S for b in J if sgn(a, b, eps)}; idx += 1
    trace_ker = [a for a in range(d) if sgn(a, a, eps) == 0]                            # T(e_a, e_b) = 2^n s(a,a) delta_ab
    if fault('UNGRADEDCENTRE'):
        sc = [c for c in range(d) if all(sgn(1 << g, c, eps) == sgn(c, 1 << g, eps) for g in range(n))]
    else:
        sc = [c for c in range(d) if all(sgn(1 << g, c, eps) == (-1) ** pc(c) * sgn(c, 1 << g, eps) for g in range(n))]
    nulls = [i for i in range(n) if eps[i] == 0]
    def compress(a, keep): return sum(1 << k for k, i in enumerate(keep) if a >> i & 1)
    lam_ok = sorted(sc) == sorted(a for a in range(d) if not a & ~N) and all(
        sgn(a, b, eps) == sgn(compress(a, nulls), compress(b, nulls), [0] * r) for a in sc for b in sc)
    fib = [a for a in range(d) if not a & N]; nonnull = [i for i in range(n) if eps[i] != 0]
    quot_ok = all(sgn(a, b, eps) == sgn(compress(a, nonnull), compress(b, nonnull), [eps[i] for i in nonnull]) for a in fib for b in fib)
    tB = type_of(fib, eps); tB0 = type_of([a for a in fib if pc(a) % 2 == 0], eps)
    return dict(n=n, r=r, dimJ=len(J), ideal=ideal, index=idx, trace_ker=(sorted(trace_ker) == sorted(J)), dimZgr=len(sc), lam=lam_ok,
                quot=quot_ok, tB=tB, tB0=tB0, pair=(tB[0], tB0[0]), dimB=len(fib))

head('hch·11 CAND-067: the radical, the super-centre and A/J of every cell with n <= 5 (exact)')
INV = {}
for (p, q, r) in CELLS: INV[(p, q, r)] = invariants(sig(p, q, r))
okJ = all(v['dimJ'] == 2 ** (p + q) * (2 ** r - 1) and v['ideal'] and v['index'] == r + 1 and v['trace_ker'] and v['quot'] for (p, q, r), v in INV.items())
chk('bit', okJ, 'for all %d cells with n <= 5: J (the labels with a null bit) is a two-sided ideal of dimension 2^(p+q)(2^r - 1), J^k = 0 exactly from k = r + 1 on, J is the kernel of the trace form, and the quotient on the labels without null bit has the structure constants of Cl(p,q)' % len(INV))
okZ = all(v['dimZgr'] == 2 ** r and v['lam'] for (p, q, r), v in INV.items())
chk('bit', okZ, 'the super-centre {z : z x = (-1)^(|z||x|) x z} of every cell is spanned by the %s labels inside the null set, dimension 2^r, with the structure constants of Cl(0,0,r) = Lambda(R^r): r = log2 of its dimension' % 'decoupled')
tline('part 1')

head('hch·12 CAND-067: the type of A/J and of its even part reads the clock; [std] from real matrices')
okT = all(clock_of_pair(v['pair']) == (p - q) % 8 for (p, q, r), v in INV.items())
chk('bit', okT, 'for all 56 cells the pair (type of A/J, type of its even part) is the table entry of the clock p - q mod 8: %s'
    % sorted({(p - q) % 8: v['pair'] for (p, q, r), v in INV.items() if p + q > 0}.items()))
def jw(p, q):
    n = p + q; X = np.array([[0, 1], [1, 0]]); Zm = np.array([[1, 0], [0, -1]]); Jm = np.array([[0, -1], [1, 0]]); I = np.eye(2, dtype=int)
    gens = []
    for k in range(n):
        M = np.array([[1]])
        for j in range(n): M = np.kron(M, Zm if j < k else ((X if k < p else Jm) if j == k else I))
        gens.append(M)
    B = []
    for a in range(1 << n):
        M = np.eye(1 << n, dtype=int)
        for i in range(n):
            if a >> i & 1: M = M @ gens[i]
        B.append(M)
    return B
def std_type(mats):
    """type of the algebra spanned by the matrices: centre (numpy null space of the commutators), square of a central element, trace form"""
    m = len(mats); V = np.array([M.flatten() for M in mats], dtype=float).T
    rows = []
    for G in mats:
        C = np.array([(G @ M - M @ G).flatten() for M in mats], dtype=float).T             # coefficients x -> [G, sum x_i M_i]
        rows.append(C)
    K = np.vstack(rows); u, s, vt = np.linalg.svd(K, full_matrices=False); rk = int((s > 1e-8).sum()); null = vt[rk:]
    dimZ = null.shape[0]
    T = np.array([[np.trace(A @ B) for B in mats] for A in mats], dtype=float); ev = np.linalg.eigvalsh(T)
    excess = int((ev > 1e-8).sum()) - int((ev < -1e-8).sum())
    zz = None
    if dimZ == 2:
        z = None
        for vec in null:
            Zc = sum(c * M for c, M in zip(vec, mats))
            if np.linalg.norm(Zc - np.trace(Zc) / Zc.shape[0] * np.eye(Zc.shape[0])) > 1e-6: z = Zc - np.trace(Zc) / Zc.shape[0] * np.eye(Zc.shape[0]); break
        z2 = z @ z; zz = 1 if np.trace(z2) > 0 else -1
    if dimZ == 1: t = 'R' if excess > 0 else 'H'
    elif dimZ == 2 and zz == -1: t = 'C'
    elif dimZ == 2: t = 'R+R' if excess > 0 else 'H+H'
    else: t = None
    return t, dimZ, zz, excess
STD = {}; agree = True
for (p, q, r) in CELLS:
    if r or p + q == 0: continue
    B = jw(p, q); n = p + q
    tB = std_type(B); tB0 = std_type([B[a] for a in range(1 << n) if pc(a) % 2 == 0])
    STD[(p, q)] = (tB[0], tB0[0])
    vb = INV[(p, q, 0)]
    agree &= (tB[1] == vb['tB'][1] and np.sign(tB[3]) == np.sign(vb['tB'][3]) and tB0[1] == vb['tB0'][1] and np.sign(tB0[3]) == np.sign(vb['tB0'][3]))
chk('std', all(clock_of_pair(v) == (p - q) % 8 for (p, q), v in STD.items()),
    'real Jordan-Wigner matrices for the 20 cells 1 <= p + q <= 5: the numpy centre, central square and trace-form signature give the same table: %s' % sorted(STD.items()))
chk('bit==std', agree, 'centre dimensions and the signs of the trace-form excess of A/J and of its even part agree between the label computation and the matrices (20 cells)')
tline('part 2')

head('hch·13 CAND-067: the invariants separate the (clock, r) classes; the controls')
pairs_same = 0; pairs_diff = 0; ok_sep = True; even_part_diff = []
cl = list(INV)
for i in range(len(cl)):
    for j in range(i + 1, len(cl)):
        a, b = cl[i], cl[j]; va, vb = INV[a], INV[b]
        same = ((a[0] - a[1]) % 8, a[2]) == ((b[0] - b[1]) % 8, b[2])
        inv_a = (va['dimZgr'], clock_of_pair(va['pair'])); inv_b = (vb['dimZgr'], clock_of_pair(vb['pair']))
        if same:
            pairs_same += 1; ok_sep &= (inv_a == inv_b) and (va['tB'][0] == vb['tB'][0])
            if va['pair'] != vb['pair']: even_part_diff.append((a, b))
        else:
            pairs_diff += 1; ok_sep &= (inv_a != inv_b)
chk('bit', ok_sep, 'on all %d pairs of cells with the same (clock, r) the super-centres are isomorphic (Lambda(R^r)) and A/J has the same type and the same clock; on all %d pairs with different (clock, r) the invariants differ; the type of the even part differs only on the %d pairs that contain a cell Cl(0,0,r) (even part R against R+R: R has no odd part)'
    % (pairs_same, pairs_diff, len(even_part_diff)))
ntypes = len({TABLE[c][0] for c in TABLE}); dims = {(p, q, r): INV[(p, q, r)]['dimB'] for (p, q, r) in [(0, 0, 0), (1, 1, 0)]}
chk('ctl', ntypes == 5 and dims[(0, 0, 0)] != dims[(1, 1, 0)],
    'the type of A/J alone takes %d values on the 8 clocks (R at 0 and 2, C at 3 and 7, H at 4 and 6): the even part is needed; dim A/J is %d for Cl(0,0) and %d for Cl(1,1), same clock: A/J is not an isomorphism invariant of the class, its Morita data are' % (ntypes, dims[(0, 0, 0)], dims[(1, 1, 0)]))
tline('part 3')

head('hch·14 CAND-067: concatenation is the graded tensor product and adds (clock, r) (all pairs with n + n\' <= 5)')
okK = True; okA = True; npairs = 0
for c1 in CELLS:
    for c2 in CELLS:
        n1, n2 = sum(c1), sum(c2)
        if n1 == 0 or n2 == 0 or n1 + n2 > 5: continue
        e1, e2 = sig(*c1), sig(*c2); e = e1 + e2; npairs += 1
        for a in range(1 << (n1 + n2)):
            a1, a2 = a & ((1 << n1) - 1), a >> n1
            for b in range(1 << (n1 + n2)):
                b1, b2 = b & ((1 << n1) - 1), b >> n1
                ks = 1 if fault('NOKOSZUL') else (-1) ** (pc(a2) * pc(b1))
                okK &= sgn(a, b, e) == sgn(a1, b1, e1) * sgn(a2, b2, e2) * ks
        v = invariants(e)
        okA &= (v['dimZgr'] == 2 ** (c1[2] + c2[2]) and clock_of_pair(v['pair']) == ((c1[0] - c1[1]) + (c2[0] - c2[1])) % 8)
chk('bit', okK, 'for all %d ordered pairs of cells with n, n\' >= 1 and n + n\' <= 5 the bit rule on the concatenated sign vector equals the graded tensor product s(a1,b1) s\'(a2,b2) (-1)^(|a2||b1|) on every pair of labels' % npairs)
chk('bit', okA, 'and the invariants of the concatenated cell (computed on the concatenated sign vector, null bits in the middle) give r + r\' and the clock c + c\' mod 8: (clock, r) is additive; r >= 0 adds, so no cell with r >= 1 has an inverse (the radical stays: bd·cat·11)')
tline('part 4')

# ------------------------------------------------------------------ part 2: universal grading groups, Smith normal form over Z
def snf_invariants(rows, ncols):
    """abelian group Z^ncols / (row span): returns (torsion invariant factors > 1, free rank)"""
    M = [r[:] for r in rows if any(r)]
    # Hermite-style elimination by gcd row operations, column by column
    R = []; col = 0; work = M
    for col in range(ncols):
        pivots = [r for r in work if r[col]]
        rest = [r for r in work if not r[col]]
        while len(pivots) > 1:
            pivots.sort(key=lambda r: abs(r[col])); p0 = pivots[0]; new = [p0]
            for r in pivots[1:]:
                f = r[col] // p0[col]; rr = [x - f * y for x, y in zip(r, p0)]
                (new if rr[col] else rest).append(rr) if any(rr) else None
            pivots = new
        if pivots: R.append(pivots[0])
        work = rest
    # Smith normal form of the small square-ish matrix R
    A = [r[:] for r in R]; m = len(A); diag = []
    t = 0
    while True:
        entries = [(abs(A[i][j]), i, j) for i in range(t, m) for j in range(t, ncols) if A[i][j]]
        if not entries: break
        _, i0, j0 = min(entries)
        A[t], A[i0] = A[i0], A[t]
        for row in A: row[t], row[j0] = row[j0], row[t]
        done = False
        while not done:
            done = True
            for i in range(t + 1, m):
                if A[i][t]:
                    f = A[i][t] // A[t][t]; A[i] = [x - f * y for x, y in zip(A[i], A[t])]
                    if A[i][t]: done = False; A[t], A[i] = A[i], A[t]
            for j in range(t + 1, ncols):
                if A[t][j]:
                    f = A[t][j] // A[t][t]
                    for row in A: row[j] -= f * row[t]
                    if A[t][j]:
                        done = False
                        for row in A: row[t], row[j] = row[j], row[t]
            if done:
                bad = [(i, j) for i in range(t + 1, m) for j in range(t + 1, ncols) if A[i][j] % A[t][t]]
                if bad:
                    i, j = bad[0]; A[t] = [x + y for x, y in zip(A[t], A[i])]; done = False
        diag.append(abs(A[t][t])); t += 1
    tors = [d for d in diag if d > 1]
    return sorted(tors), ncols - len(diag)

def label_grading_relations(eps):
    d = 1 << len(eps); rows = []
    for a in range(d):
        for b in range(d):
            if fault('NOSQUARE') and a == b: continue
            if sgn(a, b, eps):
                r = [0] * d; r[a] += 1; r[b] += 1; r[a ^ b] -= 1; rows.append(r)
    return rows, d

head('hch·15 CAND-077: the universal group of the label grading, torsion included (Smith normal form over Z)')
UG = {}
for (p, q, r) in CELLS:
    if p + q + r == 0: continue
    rows, d = label_grading_relations(sig(p, q, r))
    UG[(p, q, r)] = snf_invariants(rows, d)
chk('bit', all(v == ([2] * (p + q), r) for (p, q, r), v in UG.items()),
    'for all %d cells with 1 <= n <= 5 the relations g_a + g_b = g_(a xor b) (every non-zero product of labels) present Z2^(p+q) x Z^r: invariant factors 2 (p + q times) and free rank r (cat·G1 has the free rank for n <= 4)' % len(UG))
okG = True
for (p, q, r) in CELLS:
    if p + q + r == 0: continue
    eps = sig(p, q, r); n = len(eps); d = 1 << n
    nn = [i for i in range(n) if eps[i]]; nl = [i for i in range(n) if not eps[i]]
    deg = lambda a: (tuple((a >> i) & 1 for i in nn), tuple((a >> i) & 1 for i in nl))
    add = lambda x, y: (tuple((u + v) % 2 for u, v in zip(x[0], y[0])), tuple(u + v for u, v in zip(x[1], y[1])))
    okG &= all(deg(a ^ b) == add(deg(a), deg(b)) for a in range(d) for b in range(d) if sgn(a, b, eps))
    okG &= all(deg(1 << i) in [deg(a) for a in range(d)] for i in range(n))                # the generators' degrees, a basis of the group, are in the support
chk('std', okG, 'the explicit degree map a -> (a on the non-null bits mod 2, a on the null bits in Z^r) is a grading by Z2^(p+q) x Z^r on every cell n <= 5 and its support contains a basis: the universal group maps onto it, and the Smith form has the same order of torsion and the same rank')
if not FAULT:
    def nosq(eps):
        d = 1 << len(eps); rr = []
        for a in range(d):
            for b in range(d):
                if a != b and sgn(a, b, eps):
                    r_ = [0] * d; r_[a] += 1; r_[b] += 1; r_[a ^ b] -= 1; rr.append(r_)
        return snf_invariants(rr, d)
    g10, g20 = nosq([1]), nosq([1, 1])
    chk('ctl', g10 == ([], 1) and UG[(1, 0, 0)] == ([2], 0) and g20 == ([2, 2], 0),
        'without the relations from the squares e_a e_a = +-1 the label grading of Cl(1,0) would have the free group Z (the square gives the torsion Z2); for Cl(2,0) the anticommuting products alone already force 2 g = 0 (Z2^2 either way)')
tline('part 5')

head('hch·16 CAND-077: the Pauli gradings are label gradings (exact integer and Gaussian-integer matrices)')
X = np.array([[0, 1], [1, 0]]); Zm = np.array([[1, 0], [0, -1]]); I2 = np.eye(2, dtype=int)
def check_map(imgs, eps):
    n = len(eps); d = 1 << n; E = {}
    for a in range(d):
        M = np.eye(2, dtype=imgs[0].dtype)
        for i in range(n):
            if a >> i & 1: M = M @ imgs[i]
        E[a] = M
    hom = all(np.array_equal(E[a] @ E[b], sgn(a, b, eps) * E[a ^ b]) for a in range(d) for b in range(d))
    V = np.array([np.concatenate([E[a].real.flatten(), np.imag(E[a]).flatten()]) for a in range(d)], dtype=float)
    return hom, int(np.linalg.matrix_rank(V)) == d, E
h20, i20, E20 = check_map([X, Zm], [1, 1]); h11, i11, E11 = check_map([X, X @ Zm], [1, -1])
def canon(M):
    f = M.flatten(); nz = f[np.nonzero(f)][0]; return tuple((f * (1 if nz > 0 else -1)).tolist())
pauli_lines = {canon(M) for M in (I2, X, Zm, X @ Zm)}
same_lines = len(pauli_lines) == 4 and {canon(M) for M in E20.values()} == pauli_lines == {canon(M) for M in E11.values()}
chk('std', h20 and i20 and h11 and i11 and same_lines,
    'e1 -> X, e2 -> Z is an isomorphism Cl(2,0) -> M2(R) and e1 -> X, e2 -> XZ is one Cl(1,1) -> M2(R) (bit-rule products, four independent images); both label gradings have the four Pauli lines R I, R X, R Z, R XZ')
sx = np.array([[0, 1], [1, 0]], dtype=complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], dtype=complex)
h30, i30, E30 = check_map([sx, sy, sz], [1, 1, 1])
coarse = True
for a in range(8):
    b = a ^ 7; A_, B_ = E30[a], E30[b]
    coarse &= np.allclose(B_, 1j * A_) or np.allclose(B_, -1j * A_)                       # e_(a xor 111) = +-i e_a: the same complex line
cl_lines = {frozenset([a, a ^ 7]) for a in range(8)}
chk('std', h30 and i30 and coarse and len(cl_lines) == 4,
    'e_k -> sigma_k is an isomorphism Cl(3,0) -> M2(C) as real algebras (eight R-independent images); the labels a and a xor 111 span the same complex line C sigma: the four complex Pauli lines are the label grading coarsened along Z2^3 -> Z2^3/<111>')
tline('part 6')

head('hch·17 CAND-077: four gradings that are not label-homogeneous: E_ij (x) u on M2(R), M4(R), M2(C), M2(H)')
QT = {('1', '1'): (1, '1'), ('1', 'i'): (1, 'i'), ('1', 'j'): (1, 'j'), ('1', 'k'): (1, 'k'), ('i', '1'): (1, 'i'), ('j', '1'): (1, 'j'), ('k', '1'): (1, 'k'),
      ('i', 'i'): (-1, '1'), ('j', 'j'): (-1, '1'), ('k', 'k'): (-1, '1'), ('i', 'j'): (1, 'k'), ('j', 'i'): (-1, 'k'), ('j', 'k'): (1, 'i'),
      ('k', 'j'): (-1, 'i'), ('k', 'i'): (1, 'j'), ('i', 'k'): (-1, 'j')}
def matrix_grading(N, units, bad=False):
    """components: (i, j, u) for i != j, ('d', u) for the diagonal (x) u.  A grading: every product of two components lies in one component,
    and an explicit degree map into Z^N x Z2^m (e_i - e_j, the class of u) is additive on the non-zero products and separates the components.
    Returns (grading ok, universal group via SNF)."""
    UC = {'1': (0, 0), 'i': (1, 0), 'j': (0, 1), 'k': (1, 1)}
    def comp(i, j, u):
        if bad and N == 2 and units == ['1'] and (i, j) in [(0, 0), (0, 1)]: return ('bad', 'A')
        return (i, j, u) if i != j else ('d', u)
    comps = sorted({comp(i, j, u) for i in range(N) for j in range(N) for u in units}, key=str); ci = {c: k for k, c in enumerate(comps)}
    members = {c: [(i, j, u) for i in range(N) for j in range(N) for u in units if comp(i, j, u) == c] for c in comps}
    def deg(i, j, u): v = [0] * N; v[i] += 1; v[j] -= 1; return tuple(v) + UC[u]
    ok = True; rows = []
    for c1 in comps:
        for c2 in comps:
            targets = set()
            for (i, j, u) in members[c1]:
                for (k, l, v) in members[c2]:
                    if j == k:
                        s_, w = QT[(u, v)]
                        targets.add(comp(i, l, w))
                        dsum = tuple(a + b for a, b in zip(deg(i, j, u)[:N], deg(k, l, v)[:N])) + tuple((a + b) % 2 for a, b in zip(UC[u], UC[v]))
                        ok &= (deg(i, l, w) == dsum)
            if len(targets) > 1: ok = False
            if len(targets) == 1:
                t = targets.pop(); r = [0] * len(comps); r[ci[c1]] += 1; r[ci[c2]] += 1; r[ci[t]] -= 1; rows.append(r)
    degs = {c: {deg(*m_) for m_ in members[c]} for c in comps}
    ok &= all(len(v) == 1 for v in degs.values()) and len({next(iter(v)) for v in degs.values()}) == len(comps)
    return ok, snf_invariants(rows, len(comps))
CASES = [('M2(R)', 2, ['1'], ([], 1)), ('M4(R)', 4, ['1'], ([], 3)), ('M2(C)', 2, ['1', 'i'], ([2], 1)), ('M2(H)', 2, ['1', 'i', 'j', 'k'], ([2, 2], 1))]
res17 = {}
for name, N, units, want in CASES:
    ok, ug = matrix_grading(N, units, bad=fault('BADGRADING'))
    res17[name] = (ok, ug, want)
chk('std', all(ok and ug == want for ok, ug, want in res17.values()),
    'matrix units with the quaternion table (no bit rule; the cells Cl(2,0), Cl(3,1), Cl(3,0), Cl(1,3) have these types by hch·12): the components E_ij (x) u (i != j) and diag (x) u (u a unit of R, C = <1, i> or H = <1, i, j, k>) are a grading (every product of two components lies in one component) with universal groups %s: free rank N - 1 > r = 0, and torsion from the units (Z, Z^3, Z x Z2, Z x Z2^2)'
    % {k: ('Z2^%d' % len(v[1][0]) if v[1][0] else '') + (' x ' if v[1][0] else '') + 'Z^%d' % v[1][1] for k, v in res17.items()})
if not FAULT:
    okb, _ = matrix_grading(2, ['1'], bad=True)
    chk('ctl', not okb, 'the partition {E11, E12}, {E21}, {E22} of M2(R) is not a grading: E21 times the first part lands in two parts, and no degree map separates the parts (the grading test can fail)')
simple = {(p, q): INV[(p, q, 0)]['tB'][1] == 1 or INV[(p, q, 0)]['tB'][2] == -1 for (p, q, r) in CELLS if r == 0 and p + q > 0}
nonsimple = sorted(k for k, v in simple.items() if not v)
chk('bit', all((not v) == ((p - q) % 4 == 1) for (p, q), v in simple.items()),
    'among the 20 cells with r = 0 and 1 <= p + q <= 5 exactly those with p - q = 1 mod 4 are not simple (centre R + R, the central label squares to +1): %s; they are M_N(D) + M_N(D), so "the gradings of M_N(D)" do not cover them' % nonsimple)
tline('part 7')
finish(STEP)
