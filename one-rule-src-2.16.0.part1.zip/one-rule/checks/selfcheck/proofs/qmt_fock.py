#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""qmt_fock.py: states on graded products of cells, and the collective ladder of the Fock cell.      python3 qmt_fock.py [--fault NAME]

S. States on A (x)^ B (qmt·S1 .. S6).  The graded tensor product of Cl(p,q,r) and Cl(p',q',r') is the cell of the concatenated labels
   (the Koszul sign is the bit rule).  The dagger e_i^dagger = eps_i e_i (null generators fixed); a state is a hermitian, positive,
   normalised functional; positivity is read on the exact Gram matrix G_XY = w(e_X^dagger e_Y) (an exact pivoted LDL test over Q).
   States w_y(x) = <y^dagger y x>_0 / <y^dagger y>_0 from seeded integer y (even y: even states).  Every pair of cells r = 0 with
   1 <= n1 <= n2, n1 + n2 <= 5 (45 pairs) and four pairs at n = 6: the product of an even state with any state is a state; when both
   have odd parts the product is not hermitian (exact witness z) and, for the states with w(e_a) = 1 on an odd hermitian blade of
   square 1, not positive (exact witness x with w(x^dagger x) < 0).  Reduced states of even pure states (primitive even projectors)
   of Cl(1,1) (x)^ Cl(1,1): even states; pure for a product projector, mixed (larger Gram rank) for an entangled one.  Null
   generators (pairs with r + r' >= 1, n <= 5): z^dagger z = 0 for every blade with a null generator, the e_Y^dagger z span the
   radical J, every sampled state vanishes on J, and a functional that does not is not positive (exact witness).
   Recalled, not computed: the superselection rule itself (Wick, Wightman and Wigner).
L. The collective ladder (qmt·L1 .. L5).  On the Fock cell Cl(m,m), m = 1..6 (solid_cube.Fock): hard-core bosons s_k^+ = (prod_{j<k}
   (1 - 2 n_j)) c_k^dagger, J+ = sum s_k^+, J- = sum s_k^-, Jz = sum (n_k - 1/2): [J+, J-] = 2 Jz and [Jz, J+-] = +-J+- exactly; on
   v_n = (J+)^n f (f the vacuum idempotent), n = 0..m: [J-, J+] v_n = (2S - 2n) v_n with S = m/2, J- J+ v_n = (n + 1)(2S - n) v_n,
   v_(m+1) = 0; so [J-, J+]/2S = 1 - n/S on the n-th lowest state.  The scalar part is a trace: <e_A e_B>_0 = <e_B e_A>_0 for every
   pair of blades of every cell p + q <= 6, so <[x, y]>_0 = 0 and [x, y] = 1 has no solution in a cell.  [std] numpy Jordan-Wigner
   matrices (solid_cube.jw_ops, solid_cube.phi).  Recalled: the limit S -> infinity (Holstein and Primakoff; Inonu and Wigner) and
   that [a, a^dagger] = 1 has no bounded solution (Wielandt).
Scope: as stated.  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen; the controls are:
Options: --fault NAME (ODDOK, JSEEN, PUREPROD in S; JWSTR, CCR in L) runs only the item that carries the wrong version and must exit 1.
Command: python3 qmt_fock.py   (from this folder, or python3 selfcheck/proofs/qmt_fock.py from the package root; numpy and scipy)."""
import os, sys, itertools, random
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here)
_root = os.path.dirname(_selfcheck)
for _p in (os.path.join(_selfcheck, 'bridges'), _selfcheck, os.path.join(_root, 'researchers_checks'), os.path.join(_selfcheck, 'steps15_17'), _here):
    if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the package')
    sys.path.insert(0, _p)
from bitcliff import Alg, sig
_argv = sys.argv; sys.argv = [_argv[0]]
import solid_cube as SC
sys.argv = _argv

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('ODDOK', 'JSEEN', 'PUREPROD', 'JWSTR', 'CCR')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
FAULT_ITEM = {'ODDOK': 'states', 'JSEEN': 'states', 'PUREPROD': 'states', 'JWSTR': 'ladder', 'CCR': 'ladder'}
def pc(x): return bin(x).count('1')

# ================================================================================================ S. states on graded products
def sigma(A, m):
    """e_A^dagger = sigma e_A: reversal times the generator daggers (eps_i for non-null generators, +1 for null ones)"""
    k = pc(m); s = -1 if (k * (k - 1) // 2) % 2 else 1
    for i in range(A.n):
        if m >> i & 1 and A.eps[i] == -1: s = -s
    return s
def dag(A, x): return {m: c * sigma(A, m) for m, c in x.items()}
def state_from(A, y):
    rho = A.mul(dag(A, y), y); r0 = rho.get(0, Fr(0)); assert r0 > 0
    return [Fr(rho.get(m, 0)) * A.sq(m) / r0 for m in range(A.N)]
def gram(A, w):
    N = A.N; G = [[Fr(0)] * N for _ in range(N)]
    for X in range(N):
        sx = sigma(A, X)
        for Y in range(N):
            s, Z = A.blade_mul(X, Y)
            if s: G[X][Y] = sx * s * w[Z]
    return G
def psd_exact(G):
    """exact test of positive semidefiniteness of a symmetric rational matrix (pivoted LDL^T over Q)"""
    n = len(G); M = [row[:] for row in G]; act = list(range(n))
    while act:
        i = max(act, key=lambda t: M[t][t]); d = M[i][i]
        if d < 0: return False
        if d == 0: return all(M[a][b] == 0 for a in act for b in act)
        act.remove(i)
        for a in act:
            if M[a][i]:
                f = M[a][i] / d; Mi = M[i]; Ma = M[a]
                for b in act: Ma[b] -= f * Mi[b]
    return True
def sym(G): return [[(G[i][j] + G[j][i]) / 2 for j in range(len(G))] for i in range(len(G))]
def neg_witness(G):
    """an exact rational x with x^T G x < 0 (from the numpy eigenvector of the least eigenvalue), or None"""
    Gs = np.array([[float(v) for v in r] for r in G]); w, V = np.linalg.eigh(Gs)
    if w[0] > -1e-12: return None
    for den in (10, 100, 1000, 10000):
        x = [Fr(v).limit_denominator(den) for v in V[:, 0]]
        val = sum(x[i] * G[i][j] * x[j] for i in range(len(x)) for j in range(len(x)) if x[i] and x[j])
        if val < 0: return x, val
    return None
def product_w(w1, w2, n1, N2):
    out = [Fr(0)] * (len(w1) * N2)
    for A_, a in enumerate(w1):
        if a:
            for B_, b in enumerate(w2):
                if b: out[A_ | (B_ << n1)] = a * b
    return out
def is_even(w): return all(v == 0 for m, v in enumerate(w) if pc(m) % 2)
def hermitian(A, w): return all(v == 0 or sigma(A, m) == 1 for m, v in enumerate(w))
def rand_y(A, rg, even):
    y = {}
    for m in range(A.N):
        if (not even or pc(m) % 2 == 0) and rg.random() < 0.6: y[m] = Fr(rg.randint(-3, 3))
    y[0] = y.get(0, Fr(0)) + 5
    a = odd_herm_blade(A)
    if not even and a is not None: y[a] = y.get(a, Fr(0)) + 4
    return {m: c for m, c in y.items() if c}
def odd_herm_blade(A):
    """an odd blade with e^dagger = e (for a non-null blade the dagger sign is its square, so: an odd blade of square +1)"""
    return next((m for m in range(A.N) if pc(m) % 2 and sigma(A, m) == 1 and A.sq(m) == 1), None)

def item_states():
    head('S. States on graded products: product states, the odd-odd failure, reduced states, the radical')
    rg = random.Random(43)
    cells = [(p, n - p) for n in range(1, 5) for p in range(n, -1, -1)]
    pairs = [(c1, c2) for i, c1 in enumerate(cells) for c2 in cells[i:] if sum(c1) + sum(c2) <= 5]
    pairs += [((3, 0), (3, 0)), ((1, 2), (2, 1)), ((0, 3), (3, 0)), ((2, 1), (1, 2))]
    n_even = 0; ok_even = True; n_oo = 0; nonherm = 0; nonpos_rand = 0; n_max = 0; nonpos_max = 0; no_odd_cells = set(); oddok_claim = True; mixed_even = set()
    for (c1, c2) in pairs:
        A1, A2 = Alg(sig(*c1)), Alg(sig(*c2)); n1 = A1.n
        A12 = Alg(sig(*c1) + sig(*c2))
        wE1 = state_from(A1, rand_y(A1, rg, True)); wE2 = state_from(A2, rand_y(A2, rg, True))
        wM1 = state_from(A1, rand_y(A1, rg, False)); wM2 = state_from(A2, rand_y(A2, rg, False))
        for (wa, wb) in ((wE1, wE2), (wE1, wM2), (wM1, wE2)):
            w = product_w(wa, wb, n1, A2.N)
            G = gram(A12, w)
            ok_even &= hermitian(A12, w) and G == [list(r) for r in zip(*G)] and psd_exact(G); n_even += 1
        for c_, A_, wm in ((c1, A1, wM1), (c2, A2, wM2)):
            if odd_herm_blade(A_) is None: no_odd_cells.add(c_)
            elif is_even(wm): mixed_even.add(c_)
        if not is_even(wM1) and not is_even(wM2):
            w = product_w(wM1, wM2, n1, A2.N); n_oo += 1
            if not hermitian(A12, w): nonherm += 1
            if not psd_exact(sym(gram(A12, w))): nonpos_rand += 1
        a1, a2 = odd_herm_blade(A1), odd_herm_blade(A2)
        if a1 is not None and a2 is not None:
            wx1 = state_from(A1, {0: Fr(1), a1: Fr(1)}); wx2 = state_from(A2, {0: Fr(1), a2: Fr(1)})
            w = product_w(wx1, wx2, n1, A2.N); G = sym(gram(A12, w)); n_max += 1
            wit = neg_witness(G)
            if wit is not None and not psd_exact(G): nonpos_max += 1
            if FAULT == 'ODDOK': oddok_claim &= psd_exact(G) and hermitian(A12, w)
    chk('bit', ok_even, 'qmt·S1: the product of an even state with an even or a mixed-parity state is hermitian with a symmetric, positive semidefinite exact Gram matrix: %d products on %d pairs of cells (45 pairs with n1 + n2 <= 5, four at n = 6; seeded integer y, coefficients -3..3)' % (n_even, len(pairs)))
    chk('bit', n_oo > 0 and nonherm == n_oo, 'qmt·S2: when both factors have odd parts the product functional is not hermitian: %d of %d seeded pairs (an exact z = e_A e_B, A and B odd, with w(z^dagger) = -w(z) != 0); the dagger sign of a blade is its square, so a state can be odd only on odd blades of square +1, and the cells %s have none: all their states are even; a seeded mixed state came out even on %s' % (nonherm, n_oo, ', '.join('Cl(%d,%d)' % c for c in sorted(no_odd_cells)) or 'none', ', '.join('Cl(%d,%d)' % c for c in sorted(mixed_even)) or 'no cell'))
    chk('bit', n_max > 0 and nonpos_max == n_max, 'qmt·S3: with w(e_a) = 1 on an odd blade of square +1 in each factor, the symmetric part of the product is not positive on %d of %d pairs: an exact rational x with w(x^dagger x) < 0 each time; with the seeded mixed states %d of %d odd-odd products already fail positivity' % (nonpos_max, n_max, nonpos_rand, n_oo))
    if FAULT == 'ODDOK': chk('bit', oddok_claim, 'qmt·S3: the products of the two maximal odd states are states (the wrong claim)')
    chk('ctl', nonpos_max > 0, 'qmt·S3: an odd-odd product called a state fails on the exact witnesses above (the --fault ODDOK run asserts it)')
    # reduced states of even pure states of Cl(1,1) (x)^ Cl(1,1)
    A = Alg(sig(1, 1) + sig(1, 1)); A1 = Alg(sig(1, 1))
    def proj(*blades):
        P = {0: Fr(1)}
        for b in blades: P = A.mul(P, {0: Fr(1, 2), b: Fr(1, 2)})
        return P
    e = lambda *ix: sum(1 << i for i in ix)
    Pprod = proj(e(0, 1), e(2, 3)); Pent = proj(e(0, 3), e(1, 2))
    okp = True; ranks = {}
    for name, P in (('product', Pprod), ('entangled', Pent)):
        okp &= A.mul(P, P) == P and dag(A, P) == P and all(pc(m) % 2 == 0 for m in P)
        w = state_from(A, P); G = gram(A, w)
        okp &= psd_exact(G) and is_even(w) and hermitian(A, w)
        rk_full = np.linalg.matrix_rank(np.array([[float(v) for v in r] for r in G]))
        red = [w[m] for m in range(A1.N)]                                     # restriction to the first factor (labels 0, 1)
        Gr = gram(A1, red)
        okp &= psd_exact(Gr) and is_even(red)
        ranks[name] = (rk_full, SC.rank_frac([[v for v in r] for r in Gr]))
    pure_claim = ranks['entangled'][1] == 2 if FAULT == 'PUREPROD' else True
    chk('bit', okp and ranks['product'] == (4, 2) and ranks['entangled'] == (4, 4) and pure_claim, 'qmt·S4: Cl(1,1) (x)^ Cl(1,1) = Cl(2,2) = M4(R): the even primitive projectors (1 + e0e1)(1 + e2e3)/4 (a product) and (1 + e0e3)(1 + e1e2)/4 (entangled) give pure even states (Gram rank 4 = the module); their restrictions to the first factor are even states, pure for the product (Gram rank %d) and mixed for the entangled one (Gram rank %d = dim M2(R): the trace state), exact' % (ranks['product'][1], ranks['entangled'][1]))
    chk('ctl', ranks['entangled'][1] != 2, 'qmt·S4: the reduction of the entangled projector called pure (Gram rank 2) fails: its rank is %d (the --fault PUREPROD run asserts it)' % ranks['entangled'][1])
    # null generators
    cellsr = [(p, q, r) for n in range(1, 4) for r in range(0, n + 1) for p in range(n - r, -1, -1) for q in [n - r - p]]
    npairs = 0; okz = True; okspan = True; okvan = True; jseen_claim = True; wit_ok = True
    for c1 in cellsr:
        for c2 in cellsr:
            if c1[2] + c2[2] == 0 or sum(c1) + sum(c2) > 5 or c1 > c2: continue
            A = Alg(sig(*c1) + sig(*c2)); npairs += 1
            nullgen = [i for i in range(A.n) if A.eps[i] == 0]
            J = [m for m in range(A.N) if any(m >> i & 1 for i in nullgen)]
            okz &= all(all(v == 0 for v in A.mul(dag(A, {m: Fr(1)}), {m: Fr(1)}).values()) for m in J)
            hit = set()
            for Y in range(A.N):
                for z in J:
                    s, Z = A.blade_mul(Y, z)
                    if s: hit.add(Z)
            okspan &= hit == set(J)
            for _ in range(2):
                w = state_from(A, rand_y(A, rg, False))
                okvan &= psd_exact(sym(gram(A, w))) and all(w[m] == 0 for m in J)
            z = J[0]; wbad = state_from(A, {0: Fr(1)}); wbad = list(wbad); wbad[z] = Fr(1, 3) if sigma(A, z) == 1 else Fr(0)
            if sigma(A, z) != 1:
                z = next((m for m in J if sigma(A, m) == 1), None); wbad[z] = Fr(1, 3)
            Gb = sym(gram(A, wbad)); x = [Fr(0)] * A.N; x[0] = Fr(1, 3); x[z] = Fr(-1)
            val = sum(x[i] * Gb[i][j] * x[j] for i in range(A.N) for j in range(A.N) if x[i] and x[j])
            wit_ok &= val < 0 and not psd_exact(Gb)
            if FAULT == 'JSEEN': jseen_claim &= psd_exact(Gb)
    chk('bit', okz and okspan, 'qmt·S5: on %d graded products with null generators (r + r\' >= 1, n <= 5): z^dagger z = 0 for every blade z with a null generator, and the products e_Y z span exactly the radical J (exact ranks)' % npairs)
    chk('bit', okvan and jseen_claim, 'qmt·S5: every sampled state (two seeded per product, positive exact Gram) vanishes on J: the radical is invisible to the states (exact)')
    chk('ctl', wit_ok, 'qmt·S6: a hermitian functional with w(z) = 1/3 on a null blade z is not positive: x = 1/3 - z gives w(x^dagger x) = -1/9 < 0 on every one of the %d products (the --fault JSEEN run calls it a state)' % npairs)

# ================================================================================================ L. the collective ladder
def item_ladder():
    head('L. The collective su(2) of the Fock cell Cl(m,m) and the lowest states')
    okrel = True; okv = True; table = []; okstd = True
    for m in range(1, 7):
        F = SC.Fock(m); S = Fr(m, 2)
        par = [F.add(F.one, F.num[j], -2) for j in range(m)]
        sp, sm_ = [], []
        for k in range(m):
            st = F.one
            if FAULT != 'JWSTR':
                for j in range(k): st = F.mul(st, par[j])
            sp.append(F.mul(st, F.cd[k])); sm_.append(F.mul(F.c[k], st))
        Jp = F.total([(1, x) for x in sp]); Jm = F.total([(1, x) for x in sm_])
        Jz = F.total([(1, F.num[k]) for k in range(m)] + [(Fr(-1, 2), F.one) for _ in range(m)])
        clean = lambda x: {k_: v for k_, v in x.items() if v}
        okrel &= clean(F.comm(Jp, Jm)) == clean(F.scal(Jz, 2)) and clean(F.comm(Jz, Jp)) == clean(Jp) and clean(F.comm(Jz, Jm)) == clean(F.scal(Jm, -1))
        f = F.one
        for k in range(m): f = F.mul(f, F.c[k], F.cd[k])
        v = f; row = []
        for nn in range(m + 2):
            if nn == m + 1:
                okv &= clean(v) == {}; break
            Cm = F.comm(Jm, Jp)
            lhs = clean(F.mul(Cm, v)); rhs = clean(F.scal(v, 2 * S - 2 * nn))
            l2 = clean(F.mul(Jm, Jp, v)); r2 = clean(F.scal(v, (nn + 1) * (2 * S - nn)))
            okv &= clean(v) != {} and lhs == rhs and l2 == r2
            row.append(1 - Fr(nn) / S)
            v = F.mul(Jp, v)
        table.append('m=%d: %s' % (m, ', '.join(str(x) for x in row[:3])))
        if m <= 4:
            cs = SC.jw_ops(m); G = []
            for k in range(m): G.append(cs[k].T + cs[k])
            for k in range(m): G.append(cs[k].T - cs[k])
            I2 = np.eye(2); smat = np.array([[0., 1.], [0., 0.]])
            def site(op, k):
                o = np.array([[1.]])
                for j in range(m): o = np.kron(o, op if j == k else I2)
                return o
            Jp_np = sum(site(smat.T, k) for k in range(m))
            okstd &= np.allclose(SC.phi(F, Jp, G), Jp_np, atol=1e-12)
            Jm_np = Jp_np.T; Jz_np = (Jp_np @ Jm_np - Jm_np @ Jp_np) / 2
            vac = np.zeros(2 ** m); vac[0] = 1.0; vv = vac; evs = []
            for nn in range(m + 1):
                w_ = (Jm_np @ Jp_np - Jp_np @ Jm_np) @ vv
                evs.append(float(w_ @ vv / (vv @ vv)))
                vv = Jp_np @ vv
            okstd &= np.allclose(evs, [float(2 * S - 2 * nn) for nn in range(m + 1)], atol=1e-9) and np.allclose(Jz_np, Jz_np.T)
    chk('bit', okrel, 'qmt·L1: on Cl(m,m), m = 1..6: the hard-core bosons s_k^+ = (prod_{j<k} (1 - 2 n_j)) c_k^dagger give J+ = sum s_k^+, J- = sum s_k^-, Jz = sum (n_k - 1/2) with [J+, J-] = 2 Jz, [Jz, J+] = J+, [Jz, J-] = -J- (exact)')
    chk('bit', okv, 'qmt·L2: on v_n = (J+)^n f (f = prod c_k c_k^dagger, the vacuum idempotent), n = 0..m: [J-, J+] v_n = (2S - 2n) v_n and J- J+ v_n = (n + 1)(2S - n) v_n with S = m/2, v_n != 0, and v_(m+1) = 0 (exact, m = 1..6)')
    chk('bit', True, 'qmt·L3: so [J-, J+]/2S = 1 - n/S on the n-th lowest state, for n = 0, 1, 2: ' + '; '.join(table) + ' (exact); the deviation n/S falls as 2n/m, its limit is recalled (Holstein and Primakoff; Inonu and Wigner)')
    chk('std', okstd, 'qmt·L4: numpy Jordan-Wigner matrices (m = 1..4): the bit-rule J+ is the sum of the site raising matrices (the strings cancel), and [J-, J+] has the eigenvalues 2S - 2n on (J+)^n |vac> (tolerance 1e-9)')
    # the scalar part is a trace
    oktr = True; ncell = 0; npair = 0
    for n in range(1, 7):
        for p in range(n, -1, -1):
            A = Alg(sig(p, n - p)); ncell += 1
            for a in range(A.N):
                for b in range(A.N):
                    s1, m1 = A.blade_mul(a, b); s2, m2 = A.blade_mul(b, a)
                    oktr &= (s1 if m1 == 0 else 0) == (s2 if m2 == 0 else 0); npair += 1
    chk('bit', oktr, 'qmt·L5: <e_A e_B>_0 = <e_B e_A>_0 for every pair of blades of the %d cells p + q <= 6 (%d pairs; non-zero only for A = B), so <[x, y]>_0 = 0 for all x, y while <1>_0 = 1: [a, a^dagger] = 1 has no solution in a cell (exact; cat·B1 and check_T20 hold the super-trace side)' % (ncell, npair))
    from scipy.optimize import minimize
    Nn = 3; rg = np.random.default_rng(60)
    def resid(v):
        a = v.reshape(Nn, Nn); return float(np.sum((a @ a.T - a.T @ a - np.eye(Nn)) ** 2))
    best = min(minimize(resid, rg.normal(size=Nn * Nn), method='BFGS').fun for _ in range(5))
    claim = best < 1e-6 if FAULT == 'CCR' else best >= Nn - 1e-6
    chk('ctl', claim, 'qmt·L5: least squares for a real 3 x 3 matrix with [a, a^T] = 1 (5 seeded starts) stays at squared distance %.6f >= N = 3: the trace of the residual is -3 whatever a is (the --fault CCR run claims a solution)' % best)

ITEMS = [('states', item_states), ('ladder', item_ladder)]
if __name__ == '__main__':
    sel = [FAULT_ITEM[FAULT]] if FAULT else None
    for name, it in ITEMS:
        if sel is None or name in sel: it()
    finish('QMT-FOCK')
