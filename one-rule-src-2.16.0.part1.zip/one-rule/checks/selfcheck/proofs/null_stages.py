#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""null_stages.py: the null cells' modules, classes and stages, the exact third stage, the standard routes at the bit route's scopes, and the
limit of the chain of blocks as an ordered group on the finite side (round 12, proofs pass 10c; docs/round12/PLAN.md,
docs/round12/pass10c/BEFORE.md).      python3 null_stages.py [--fault NULLACTS|PRQUOT|NOSWAP|ANTIPAIR|MULT3|NOUNIT]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q,r) has its p generators
of square +1 first, then q of square -1, then r null (core_check.sig); the type table is core_check.TYPE (by c = p - q mod 8).  The three
clock-0 blocks of row 8 are (8,0,0), (0,8,0), (4,4,0) (GEN-009), placed after the generators they multiply; the inclusions e_i -> e_i Omega.
ns.NUL the 120 cells (p,q,r) with r >= 1, n <= 8: J (the labels with a null bit) a two-sided ideal, its powers, J^r != 0 = J^(r+1); the
       labels without a null bit (those below 2^(p+q)) a subalgebra with the table of Cl(p,q), the quotient (LNC-055).  The bit rule's left
       ideal A f (f = prod (1 + u)/2 over a maximal commuting set of labels of square +1, abs_ring.py's construction, copied): its dimension,
       the action of the null generators, its Loewy layers, its exact commutant (two-term and one-term equations of partial signed
       permutations), its top and socle; the simple modules (the top, null generators acting by 0) irreducible with commutant D; the centre
       of the cell from its central blades.  [std] numpy: the trace form of the Kronecker words (X + J at a null site), its radical.
       [ctl] NULLACTS (the kernel of a null generator on A f is a proper submodule), PRQUOT (the quotient taken as Cl(p+r,q)).
ns.ABS A(p,q,r) = coker(N(Cl(p+1,q+1,r)) -> N(Cl(p+1,q,r))) for the 120 cells, the grading the first generator, from the simple modules (the
       tops of the cells' own left ideals) and from the projective covers (A f restricted, decomposed by its top); against KO^(p-q)(point).
       [ctl] NOSWAP, PRQUOT.
ns.STG the chains from the null cells: stages n and n + 8 for the 120 cells and each block (360 chains), n + 16 for the 56 cells with n <= 6
       (168 chains, through the parity reduction and the graded diagonal; to 20 generators also by enumerating the labels): the quotient's
       type, the radical, minimal idempotents of the quotient (period_map.py's construction, copied) as idempotents of the stage, tr L_P (the
       projective cover), the order unit, the multiplicity matrices, the quotient's volume element kept, the centre.  [ctl] PRQUOT.
ns.P3  the exact P^2 = P at the third stage of the 54 chains of GEN-019 (63 idempotents) and of the 168 null chains: P = prod (1 + v)/2 over
       signed blades, P^2 from the subset expansion on all 4^|V| pairs of terms with the kernel split into segments (the graded tensor product
       of cb.GT, against BR.s on samples), the group law v_T v_t = v_(T xor t), phi(P_1) Q_2 = Q_2 phi(P_1).  [ctl] ANTIPAIR (one anticommuting
       pair: not idempotent).
ns.STD the standard routes at the bit route's scopes, no label: the signs of the explicit map on every pair (S,T) for the 84 cells n <= 6 and
       the three blocks (monomial Kronecker matrices); the ABS classes for the 45 cells p + q <= 8 at n and n + 8 (scipy.sparse Kronecker
       matrices, a commutant element by the Reynolds average generator by generator, eigenspaces; the mixed-product rule at n + 8); the stages
       0 and 1 of the 45 chains from the 15 start cells n <= 4 (monomial words, the centre through the exact commutant).  [bit==std] each.
ns.LIM the limit as an ordered group on the finite side: G = lim (Z^s, 16 I) as classes of pairs (k, v) in Fractions and integers, the cone,
       the unit, k, v -> v / 16^k onto Z[1/16]^s = Z[1/2]^s; the M256 chain; the CAR chain; s = 2 with the swap at every step; the complexified
       stages.  [std] numpy integers on the Bratteli diagram's incidence matrices.  [ctl] MULT3 (Z[1/3]), the unit forgotten.
Not computed here (stated, not checked): the C*-completion of either chain; Elliott's classification of AF algebras by the ordered K_0 with
unit and Glimm's of UHF algebras by the supernatural number, both stated for complex C*-algebras while these stages are real, cited and set
beside the finite computation; that K_0(A) = K_0(A/J) for a nilpotent J (idempotent lifting) and Nakayama's lemma are recalled.
--fault options (each a wrong version in the main lines, which must then FAIL; exit 1): NULLACTS the left ideal A f, on which the null
   generators act, taken as the irreducible; PRQUOT the quotient taken as Cl(p+r,q); NOSWAP the two irreducibles of a two-summand graded cell
   kept by the dropped generator; ANTIPAIR one anticommuting pair in the set of the third-stage idempotent; MULT3 the multiplicity 3 asserted
   in the stages and in the limit; NOUNIT the unit forgotten in the comparison of ordered groups with unit.
Command: python3 -I -B selfcheck/proofs/null_stages.py from checks/ (or from this folder); standard library, numpy and scipy (scipy.sparse
for the standard route of the classes)."""
import os, sys, time, random, itertools
from fractions import Fraction as Fr
from math import comb, gcd, isqrt
import numpy as np
import scipy.sparse as sps

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps

# ------------------------------------------------------------------------------------------------ check lines (as period_map.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish(name):
    tags = ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT))
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), tags, len(FAILS)))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    print('null_stages: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NULLACTS', 'PRQUOT', 'NOSWAP', 'ANTIPAIR', 'MULT3', 'NOUNIT')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(20261017); NPR = np.random.default_rng(20261017)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
def cells(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]
def cstr(c): return '(%s)' % ','.join(str(x) for x in c)
def clock(c): return (c[0] - c[1]) % 8
pc = lambda x: bin(x).count('1')
BLOCKS = [(8, 0, 0), (0, 8, 0), (4, 4, 0)]                                 # the three clock-0 cells of row 8 (GEN-009)
NULLC = [c for n in range(1, 9) for c in cells(n) if c[2] >= 1]           # the 120 cells with null generators, n <= 8
KO = {0: 'Z', 1: '0', 2: '0', 3: '0', 4: 'Z', 5: '0', 6: 'Z2', 7: 'Z2'}     # KO^(p-q)(point) by the clock: ATY-001's recalled table
DD = {'R': 1, 'C': 2, 'H': 4}

# ------------------------------------------------------------------------------------------------ the kernel's formula, vectorised (period_map.py / chain_blocks.py)
def popv(x): return np.bitwise_count(x).astype(np.int64)
def emask(eps):
    """E[m] = product of eps_i over the bits of m, for every mask m < 2^N"""
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    """BR.s(a, b) for arrays of labels: (-1)^(#(i in a, j in b, j < i)) * prod_(i in a & b) eps_i (period_map.py; beyond 16 generators the
    product of the eps is read from the masks of 8-bit segments instead of one table of 2^N entries)"""
    eps = tuple(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)):
        par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    if len(eps) <= 16:
        if eps not in _EM: _EM[eps] = emask(eps)
        return (1 - 2 * (par & 1)) * _EM[eps][A & B]
    E = 1 - 2 * (par & 1); AB = A & B
    for o in range(0, len(eps), 8):
        seg = eps[o:o + 8]
        if seg not in _EM: _EM[seg] = emask(seg)
        E = E * _EM[seg][(AB >> o) & ((1 << len(seg)) - 1)]
    return E

# ------------------------------------------------------------------------------------------------ types from invariants (period_map.py / chain_blocks.py)
def type_from_inv(dim, c, cplx, fs):
    """c copies of M_m(D) from the dimension, the number c of simple summands, whether the centre is complex, and the Frobenius-Schur count"""
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D])
    m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
_LT = {}
def ltype_eps(eps):
    """the type of a non-degenerate cell from its labels: the count sum of s(a,a), the central blades by the reordering counts (period_map.py)"""
    eps = tuple(eps)
    if len(eps) == 0: return ('R', 1, 1)
    if eps not in _LT:
        n = len(eps); a = np.arange(1 << n, dtype=np.int64); d = s_vec(eps, a, a); cen = np.ones(1 << n, dtype=bool)
        for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
        Z = np.flatnonzero(cen); cplx = bool(np.any(d[Z] == -1))
        _LT[eps] = type_from_inv(1 << n, len(Z) // 2 if cplx else len(Z), cplx, int(d.sum()))
    return _LT[eps]
def ltype_split(eps, nlow):
    """the type of a non-degenerate cell without enumerating its labels (pass 8c's parity reduction and graded diagonal; period_map.py)"""
    e1, e2 = tuple(eps[:nlow]), tuple(eps[nlow:]); n1, n2 = len(e1), len(e2)
    a1 = np.arange(1 << n1, dtype=np.int64); a2 = np.arange(1 << n2, dtype=np.int64); d1 = s_vec(e1, a1, a1); d2 = s_vec(e2, a2, a2)
    p1 = popv(a1) & 1; p2 = popv(a2) & 1
    E1, O1, E2, O2 = int(d1[p1 == 0].sum()), int(d1[p1 == 1].sum()), int(d2[p2 == 0].sum()), int(d2[p2 == 1].sum())
    def cen(a, n_, add_above, add_below):
        ok = np.ones(len(a), dtype=bool)
        for i in range(n_): ok &= ((popv(a >> (i + 1)) + add_above - popv(a & ((1 << i) - 1)) - add_below) & 1) == 0
        return ok
    central = []
    for par1 in (0, 1):
        for par2 in (0, 1):
            L = np.flatnonzero(cen(a1, n1, par2, 0) & (p1 == par1)); H = np.flatnonzero(cen(a2, n2, 0, par1) & (p2 == par2))
            central += [int(x) | (int(y) << n1) for x in L for y in H]
    K = BR(eps); cplx = any(K.s(c_, c_) == -1 for c_ in central)
    return type_from_inv(1 << (n1 + n2), len(central) // 2 if cplx else len(central), cplx, E1 * E2 + E1 * O2 + O1 * E2 - O1 * O2)
def stage_type(eps):
    return ltype_eps(eps) if len(eps) <= 20 else ltype_split(eps, len(eps) - 8)
def clock_type(p, q):
    """the type of Cl(p,q) from the Atlas's type table core_check.TYPE and the dimension 2^(p+q) (period_map.py)"""
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2)
    assert r == 0 and m * m == m2
    return (D, m, c)

# ------------------------------------------------------------------------------------------------ monomial matrices (period_map.py): M[rows[c], c] = vals[c]; vals 0 allowed
XM = np.array([[0, 1], [1, 0]], dtype=np.int64); JM = np.array([[0, -1], [1, 0]], dtype=np.int64); ZM = np.diag([1, -1]).astype(np.int64)
I2 = np.eye(2, dtype=np.int64)
def kron_all(ms):
    M = np.ones((1, 1), dtype=np.int64)
    for m in ms: M = np.kron(M, m)
    return M
def site_gens(eps):
    """one generator per site: Z on the sites before it, X (square +1), J (square -1) or X + J (square 0) on its own; no label (chain_blocks.py)"""
    n = len(eps)
    return [kron_all([ZM] * k + [{1: XM, -1: JM, 0: XM + JM}[e]] + [I2] * (n - k - 1)) for k, e in enumerate(eps)]
def block_mats(c8):
    """the blocks as real 16 x 16 Kronecker matrices, no label (chain_blocks.py): Cl(4,4) from X and J on four sites; Cl(8,0) and Cl(0,8) by
    the four-shift (f_j w with w = f_1 f_2 f_3 f_4, resp. e_i w' with w' = e_1 e_2 e_3 e_4)"""
    E = [kron_all([ZM] * k + [XM] + [I2] * (3 - k)) for k in range(4)]; F = [kron_all([ZM] * k + [JM] + [I2] * (3 - k)) for k in range(4)]
    if c8 == (4, 4, 0): return E + F
    if c8 == (8, 0, 0): w = F[0] @ F[1] @ F[2] @ F[3]; return E + [f @ w for f in F]
    if c8 == (0, 8, 0): w = E[0] @ E[1] @ E[2] @ E[3]; return [e @ w for e in E] + F
    raise ValueError(c8)
def to_mono(M):
    nz = M != 0; assert bool(np.all(nz.sum(0) <= 1))
    r = np.argmax(nz, axis=0).astype(np.int64); return r, M[r, np.arange(M.shape[1])].astype(np.int64)
def m_mul(A, B): return A[0][B[0]], A[1][B[0]] * B[1]
def m_kron(A, B): m = len(B[0]); return (A[0][:, None] * m + B[0][None, :]).ravel(), (A[1][:, None] * B[1][None, :]).ravel()
def m_eye(d): return np.arange(d, dtype=np.int64), np.ones(d, dtype=np.int64)
def m_eq(A, B): return np.array_equal(A[1], B[1]) and bool(np.all((A[0] == B[0]) | (A[1] == 0)))
def m_neg(A): return A[0], -A[1]
def m_prod(mods, m):
    out = m_eye(m)
    for R in mods: out = m_mul(out, R)
    return out
def m_trace(A): return int(A[1][A[0] == np.arange(len(A[0]))].sum())
def m_dense(A):
    m = len(A[0]); M = np.zeros((m, m), dtype=np.int64); M[A[0], np.arange(m)] = A[1]; return M
def rel_ok(mods, eps, m):
    """the relations R_i R_j + R_j R_i = 2 eps_i delta_ij on monomial matrices with zero columns allowed (a null generator: R_i^2 = 0)"""
    I = m_eye(m)
    for i in range(len(mods)):
        if not m_eq(m_mul(mods[i], mods[i]), (I[0], I[1] * eps[i])): return False
        for j in range(i + 1, len(mods)):
            P, Q = m_mul(mods[i], mods[j]), m_mul(mods[j], mods[i])
            if not m_eq(P, (Q[0], -Q[1])): return False
    return True
def mmul(A, x, y): return (x[0] * y[0] * A.s(x[1], y[1]), x[1] ^ y[1])     # signed blades (sign, label) with the kernel (chain_blocks.py)

# ------------------------------------------------------------------------------------------------ exact integer linear algebra (period_map.py / abs_ring.py)
def group_name(free, tors):
    parts = ['Z'] * free + ['Z%d' % d for d in tors]
    return '+'.join(parts) if parts else '0'
def smith(A):
    """integer Smith normal form: (invariant factors, U) with U A V diagonal; A by its rows (abs_ring.py)"""
    A = [[int(x) for x in r] for r in A]; r = len(A); c = len(A[0]) if r else 0
    U = [[int(i == j) for j in range(r)] for i in range(r)]
    diag = []; t_ = 0
    def swap_rows(i, j): A[i], A[j] = A[j], A[i]; U[i], U[j] = U[j], U[i]
    def swap_cols(i, j):
        for row in A: row[i], row[j] = row[j], row[i]
    while t_ < min(r, c):
        nz = [(abs(A[i][j]), i, j) for i in range(t_, r) for j in range(t_, c) if A[i][j]]
        if not nz: break
        _, i, j = min(nz); swap_rows(t_, i); swap_cols(t_, j)
        while True:
            changed = False
            for i in range(t_ + 1, r):
                if A[i][t_]:
                    qq = A[i][t_] // A[t_][t_]
                    A[i] = [a - qq * b for a, b in zip(A[i], A[t_])]; U[i] = [a - qq * b for a, b in zip(U[i], U[t_])]
                    if A[i][t_]: swap_rows(t_, i); changed = True
            for j in range(t_ + 1, c):
                if A[t_][j]:
                    qq = A[t_][j] // A[t_][t_]
                    for row in A: row[j] -= qq * row[t_]
                    if A[t_][j]: swap_cols(t_, j); changed = True
            if changed: continue
            bad = [(i, j) for i in range(t_ + 1, r) for j in range(t_ + 1, c) if A[i][j] % A[t_][t_]]
            if not bad: break
            i = bad[0][0]; A[t_] = [a + b for a, b in zip(A[t_], A[i])]; U[t_] = [a + b for a, b in zip(U[t_], U[i])]
        if A[t_][t_] < 0: A[t_] = [-a for a in A[t_]]; U[t_] = [-a for a in U[t_]]
        diag.append(A[t_][t_]); t_ += 1
    return diag, U
def coker(M):
    diag, U = smith(M)
    return group_name(len(M) - len(diag), [d for d in diag if d > 1])
def coker_divisors(M):
    """the cokernel by determinantal divisors (abs_ring.py's standard route)"""
    def det(Mx):
        Mx = [[Fr(x) for x in r] for r in Mx]; n = len(Mx); dt = Fr(1)
        for c_ in range(n):
            piv = next((i for i in range(c_, n) if Mx[i][c_] != 0), None)
            if piv is None: return 0
            if piv != c_: Mx[c_], Mx[piv] = Mx[piv], Mx[c_]; dt = -dt
            dt *= Mx[c_][c_]
            for i in range(c_ + 1, n):
                f = Mx[i][c_] / Mx[c_][c_]; Mx[i] = [a - f * b for a, b in zip(Mx[i], Mx[c_])]
        return int(dt)
    r = len(M); c = len(M[0]) if r else 0; ds = [1]
    for k in range(1, min(r, c) + 1):
        g = 0
        for rows in itertools.combinations(range(r), k):
            for cols in itertools.combinations(range(c), k): g = gcd(g, abs(det([[M[i][j] for j in cols] for i in rows])))
        if g == 0: break
        ds.append(g)
    inv = [ds[k] // ds[k - 1] for k in range(1, len(ds))]
    return group_name(r - len(inv), [e for e in inv if e > 1])

# ------------------------------------------------------------------------------------------------ minimal left ideals on the labels (period_map.py's vectorised abs_ring.py construction)
def comm_set_v(eps):
    """abs_ring.py's comm_set in its first order (increasing labels), vectorised: commuting independent labels of square +1, greedily; a label
    with a null bit has square 0 and never enters (period_map.py)"""
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); pa = popv(a)
    cand = s_vec(eps, a, a) == 1; cand[0] = False; inspan = np.zeros(1 << n, dtype=bool); inspan[0] = True
    span = np.zeros(1, dtype=np.int64); gens = []
    while True:
        idx = np.flatnonzero(cand & ~inspan)
        if not len(idx): return gens
        u = int(idx[0]); new = span ^ u
        if not np.all(s_vec(eps, new, new) == 1): cand[u] = False; continue
        gens.append(u); cand &= ((pa * pc(u) - popv(a & u)) & 1) == 0; inspan[new] = True; span = np.concatenate([span, new])
def reducer(gens):
    """the span of gens in reduced echelon form over F2: a -> the coset minimum (period_map.py)"""
    basis = []
    for g in gens:
        v = g
        for pb, bv in basis:
            if v >> pb & 1: v ^= bv
        pb = v.bit_length() - 1; basis = [(q_, w ^ v if w >> pb & 1 else w) for q_, w in basis] + [(pb, v)]
    def red(A):
        R = np.array(A, dtype=np.int64, copy=True)
        for pb, bv in basis: R = np.where(((R >> pb) & 1) == 1, R ^ bv, R)
        return R
    return red
def commutant_v(rho, m):
    """solid_cube.py's commutant_basis on signed permutations, vectorised (period_map.py): the components of X[pi(b), pi(c)] = s(b) s(c) X[b,c]
    carried by sign propagation; a component on which two signs disagree is zero.  Returns one signed permutation per surviving component
    (None if a component is not one)"""
    M = m * m; x = np.arange(M, dtype=np.int64); bb, cc = x // m, x % m
    root = x.copy(); psi = np.ones(M, dtype=np.int64)
    while True:
        changed = False
        for pi, sg in rho:
            y = pi[bb] * m + pi[cc]; tt = sg[bb] * sg[cc]
            r0, p0 = root.copy(), psi.copy(); mv = r0 < r0[y]
            if mv.any(): root[y[mv]] = r0[mv]; psi[y[mv]] = tt[mv] * p0[mv]; changed = True
            r1, p1 = root.copy(), psi.copy(); mv = r1[y] < r1
            if mv.any(): root[mv] = r1[y[mv]]; psi[mv] = tt[mv] * p1[y[mv]]; changed = True
        if not changed: break
    bad = np.zeros(M, dtype=bool)
    for pi, sg in rho:
        y = pi[bb] * m + pi[cc]; tt = sg[bb] * sg[cc]; bad[root[(root[y] != root) | (psi[y] != tt * psi)]] = True
    out = []
    for r in np.unique(root):
        if bad[r]: continue
        sel = np.flatnonzero(root == r); rows_, cols_ = sel // m, sel % m
        if len(sel) != m or len(np.unique(cols_)) != m or len(np.unique(rows_)) != m: out.append(None); continue
        o = np.argsort(cols_); out.append((rows_[o], psi[sel][o]))
    return out
def commutant_dim_pm(rho, m):
    """the dimension of {X : X R = R X for every R} for monomial matrices with zero columns allowed (commutant_v extended): in the entry (a,c)
    of R X = X R each side has at most one term, sg(b0) X[b0,c] with pi(b0) = a and sg(b0) != 0, and sg(c) X[a,pi(c)] with sg(c) != 0; two
    terms tie two unknowns with a sign, one term forces its unknown to 0.  Components carried by sign propagation; a component with a forced
    zero or two disagreeing signs is zero; the dimension is the number of the others."""
    M = m * m; x = np.arange(M, dtype=np.int64); a_, c_ = x // m, x % m
    EU, EV, ET = [], [], []; zero = np.zeros(M, dtype=bool)
    for pi, sg in rho:
        inv = np.full(m, -1, dtype=np.int64); nzc = np.flatnonzero(sg != 0); inv[pi[nzc]] = nzc
        b0 = inv[a_]; lhs = b0 >= 0; rhs = sg[c_] != 0; both = lhs & rhs
        EU.append(b0[both] * m + c_[both]); EV.append(a_[both] * m + pi[c_[both]]); ET.append(sg[b0[both]] * sg[c_[both]])
        ol = lhs & ~rhs; zero[b0[ol] * m + c_[ol]] = True
        orr = rhs & ~lhs; zero[a_[orr] * m + pi[c_[orr]]] = True
    U = np.concatenate(EU); V = np.concatenate(EV); Tt = np.concatenate(ET)       # X[U] = Tt X[V]
    root = x.copy(); psi = np.ones(M, dtype=np.int64)
    while True:
        changed = False
        r0, p0 = root.copy(), psi.copy(); mv = r0[U] < r0[V]
        if mv.any(): root[V[mv]] = r0[U[mv]]; psi[V[mv]] = Tt[mv] * p0[U[mv]]; changed = True
        r1, p1 = root.copy(), psi.copy(); mv = r1[V] < r1[U]
        if mv.any(): root[U[mv]] = r1[V[mv]]; psi[U[mv]] = Tt[mv] * p1[V[mv]]; changed = True
        if not changed: break
    bad = np.zeros(M, dtype=bool); bad[root[zero]] = True
    bad[root[U[(root[U] != root[V]) | (psi[U] != Tt * psi[V])]]] = True
    roots = np.unique(root)
    return int(np.sum(~bad[roots]))
def classify_v(basis, m):
    """solid_cube.py's classify on signed-permutation bases (period_map.py): 'R' (d = 1), 'C' (d = 2), 'H' (d = 4); None otherwise"""
    d = len(basis)
    if any(B is None for B in basis): return None
    def coords(P):
        for k, B in enumerate(basis):
            if np.array_equal(P[0], B[0]):
                if np.array_equal(P[1], B[1]): return [int(i == k) for i in range(d)]
                if np.array_equal(P[1], -B[1]): return [-int(i == k) for i in range(d)]
        raise AssertionError('not in the span')
    if d == 1: return 'R'
    kap = [[coords(m_mul(Bc, Bd)) for Bd in basis] for Bc in basis]; e = coords(m_eye(m))
    def mul(x_, y_):
        out = [0] * d
        for c_ in range(d):
            if x_[c_]:
                for dd in range(d):
                    if y_[dd]:
                        for t_ in range(d): out[t_] += x_[c_] * y_[dd] * kap[c_][dd][t_]
        return out
    neg = [-v for v in e]
    if d == 2: return 'C' if any(mul(x_, x_) == neg for x_ in itertools.product(range(-2, 3), repeat=2)) else None
    if d == 4:
        roots = [x_ for x_ in itertools.product(range(-2, 3), repeat=4) if mul(x_, x_) == neg]
        return 'H' if any(all(a_ == -b_ for a_, b_ in zip(mul(x_, y_), mul(y_, x_))) for x_ in roots for y_ in roots) else None
    return None
def left_ideal(eps, gens=None):
    """the bit rule's left ideal A f for any cell (null generators allowed), abs_ring.py's construction vectorised as period_map.py's
    build_ideal: f = prod (1 + e_a)/2 over the commuting labels gens, the basis e_r f with r the coset minima of their span among ALL labels,
    e_i e_r f = s(i,r) s(r2,mm) tau(mm) e_r2 f; a null generator gives a zero column where r already has its bit"""
    eps = tuple(eps); n = len(eps); N = 1 << n
    gens = comm_set_v(eps) if gens is None else list(gens); red = reducer(gens)
    a = np.arange(N, dtype=np.int64); reps = np.flatnonzero(red(a) == a).astype(np.int64); m = len(reps)
    tl = np.zeros(1, dtype=np.int64); ts = np.ones(1, dtype=np.int64)
    for g in gens: tl, ts = np.concatenate([tl, tl ^ g]), np.concatenate([ts, ts * s_vec(eps, tl, g)])
    tau = np.zeros(N, dtype=np.int64); tau[tl] = ts
    rho = []
    for i in range(n):
        c_ = reps ^ (1 << i); r2 = red(c_); mm = c_ ^ r2
        rho.append((np.searchsorted(reps, r2).astype(np.int64), (s_vec(eps, 1 << i, reps) * s_vec(eps, r2, mm) * tau[mm]).astype(np.int64)))
    nullmask = sum(1 << i for i, e in enumerate(eps) if e == 0)
    return {'eps': eps, 'n': n, 'm': m, 'reps': reps, 'rho': rho, 'gens': gens, 'null': nullmask}
_CELL = {}
def cell(eps):
    """a semisimple cell (no null generator) from its minimal left ideal: the exact commutant, its type, the summands, the two irreducibles of
    a two-summand cell by the volume element (period_map.py's build_ideal)"""
    eps = tuple(eps)
    if eps in _CELL: return _CELL[eps]
    n = len(eps)
    if n == 0:
        _CELL[eps] = {'eps': eps, 'n': 0, 'm': 1, 'irreps': [[]], 'gens': [], 'type': 'R', 'd': 1, 'summ': Fr(1), 'ok_rel': True}; return _CELL[eps]
    L = left_ideal(eps); m = L['m']; rho = L['rho']
    basis = commutant_v(rho, m); typ = classify_v(basis, m); d = len(basis); summ = Fr((1 << n) * d, m * m)
    W = m_prod(rho, m); irreps = [rho]; sgn = None
    if summ == 2:
        sgn = 1 if m_eq(W, m_eye(m)) else (-1 if m_eq(W, (np.arange(m), -np.ones(m, dtype=np.int64))) else 0)
        neg = [m_neg(R) for R in rho]; irreps = [rho, neg] if sgn == 1 else [neg, rho]
    _CELL[eps] = {'eps': eps, 'n': n, 'm': m, 'irreps': irreps, 'gens': L['gens'], 'type': typ, 'd': d, 'summ': summ, 'om_sign': sgn,
                  'ok_rel': rel_ok(rho, eps, m)}
    return _CELL[eps]
def module_class(mods, c_, noswap=False, m=None):
    """abs_ring.py's module_class on monomial matrices (period_map.py): the multiplicities of the irreducibles of the semisimple cell c_ in a
    module, from its dimension and, on a two-summand cell, the trace of the volume element W (W^2 = 1, dim ker(W - 1) = (m + tr W)/2)"""
    m = len(mods[0][0]) if mods else m; ok = rel_ok(mods, c_['eps'], m)
    if len(c_['irreps']) == 1: return ok and m % c_['m'] == 0, [m // c_['m']]
    W = m_prod(mods, m); ok &= m_eq(m_mul(W, W), m_eye(m)); t_ = m_trace(W); dp, dm = (m + t_) // 2, (m - t_) // 2
    ok &= (m + t_) % 2 == 0 and dp % c_['m'] == 0 and dm % c_['m'] == 0
    return (ok, [m // c_['m'], 0]) if noswap else (ok, [dp // c_['m'], dm // c_['m']])
def restrict(big, drop, small, noswap=False):
    """integer matrix (abs_ring.py, period_map.py): rows the irreducibles of `small`, columns those of `big`, restricted by dropping `drop`"""
    assert tuple(e for i, e in enumerate(big['eps']) if i != drop) == small['eps']
    cols_ = []
    for T in big['irreps']:
        ok, v = module_class([T[i] for i in range(len(T)) if i != drop], small, noswap, m=len(T[0][0]) if T else 1); assert ok
        cols_.append(v)
    return [[cols_[j][i] for j in range(len(cols_))] for i in range(len(small['irreps']))]

# ================================================================================================ ns.NUL  the null cells: radical, quotient, the left ideal, the simple modules
head('ns.NUL  the 120 cells with null generators (n <= 8): the radical J, the quotient, the bit rule\'s left ideal A f (a projective cover), the simple modules, the centre')
t = time.time()
def quot_sig(p, q, r):
    """the quotient's cell Cl(p,q) (LNC-055); under --fault PRQUOT the wrong Cl(p+r,q) (the null generators taken as squares +1)"""
    return sig(p + r, q) if FAULT == 'PRQUOT' else sig(p, q)
_TB = {}
def table(eps):
    eps = tuple(eps)
    if eps not in _TB:
        a = np.arange(1 << len(eps), dtype=np.int64); _TB[eps] = s_vec(eps, a[:, None], a[None, :]).astype(np.int8)
    return _TB[eps]
def prod_blades(S, A_, B_):
    """the blades spanning the product of the spans of the blade sets A_ and B_ (chain_blocks.py)"""
    out = np.zeros(S.shape[0], dtype=bool); ia, ib = np.flatnonzero(A_), np.flatnonzero(B_)
    if len(ia) and len(ib):
        nz = S[np.ix_(ia, ib)] != 0; out[(ia[:, None] ^ ib[None, :])[nz]] = True
    return out
def sub_mod(R, idx):
    """the monomial matrix R restricted to the basis vectors idx (R must map idx into idx where it is non-zero)"""
    pos = np.searchsorted(idx, R[0][idx]); v = R[1][idx]
    inside = (pos < len(idx)) & (idx[np.minimum(pos, len(idx) - 1)] == R[0][idx])
    return (np.where(inside, pos, 0), np.where(inside, v, 0)), bool(np.all(inside | (v == 0)))
def irreps_of(c_):
    """the simple modules of the null cell c_ = (p,q,r): those of the quotient with the null generators acting by 0; under --fault NULLACTS
    the left ideal A f (and its twist), on which the null generators act, is taken in their place"""
    p, q, r = c_
    if FAULT == 'NULLACTS':
        L = left_ideal(sig(*c_)); out = [L['rho']]
        if cell(sig(p, q))['summ'] == 2: out.append([m_neg(R) for R in L['rho']])
        return out
    Qc = cell(quot_sig(p, q, r)); z = (np.zeros(Qc['m'], dtype=np.int64), np.zeros(Qc['m'], dtype=np.int64))
    return [list(T) + [z] * (r if FAULT != 'PRQUOT' else 0) for T in Qc['irreps']]
okJ = okPow = okQ = okDim = okAct = okLay = okCom = okTop = okSoc = okIrr = okCen = okZ2 = True
nsum = {'s2': 0, 'C': 0, 'soc_other': 0, 'cen': 0}; maxm = 0; nker = 0; prq = {'type': 0, 'cls': 0}
for c in NULLC:
    p, q, r = c; n = p + q + r; nq = p + q; eps = sig(*c); N = 1 << n; S = table(eps)
    a = np.arange(N, dtype=np.int64); nb = ((1 << r) - 1) << nq; hn = (a & nb) != 0
    for i in range(n):                                                     # J closed under e_i x and x e_i
        for x_ in (S[1 << i, hn], S[hn, 1 << i]): okJ &= bool(np.all((x_ == 0) | (((a[hn] ^ (1 << i)) & nb) != 0)))
    okJ &= int(hn.sum()) == N - (1 << nq)
    Jk = hn.copy(); k = 1
    while Jk.any():                                                        # J^k = the labels with at least k null bits
        okPow &= np.array_equal(Jk, popv(a & nb) >= k); Jk = prod_blades(S, Jk, hn); k += 1
    okPow &= k == r + 1                                                    # J^r != 0 = J^(r+1): the loop stops after J^r
    QS = quot_sig(p, q, r)
    okQ &= S[:1 << nq, :1 << nq].shape == table(QS).shape and np.array_equal(S[:1 << nq, :1 << nq], table(QS))
    D, mq, s = clock_type(p, q); d = DD[D]; nsum['s2'] += s == 2; nsum['C'] += D == 'C'
    L = left_ideal(eps); m = L['m']; rho = L['rho']; reps = L['reps']; maxm = max(maxm, m); w = len(L['gens'])
    okDim &= all(u < (1 << nq) for u in L['gens']) and m == (1 << r) * mq * d and Fr(N, 1 << w) == m and rel_ok(rho, eps, m)
    okAct &= all(bool(np.any(rho[j][1] != 0)) for j in range(nq, n))
    nr = popv(reps & nb)
    for kk in range(r + 1):
        okLay &= int((nr == kk).sum()) == comb(r, kk) * mq * d
        sel = nr >= kk
        okLay &= all(bool(np.all((popv(reps[R[0][sel]] & nb) >= kk) | (R[1][sel] == 0))) for R in rho)
    okCom &= commutant_dim_pm(rho, m) == ((1 << r) * d if s == 1 else (1 << (r - 1)) * d)
    Qc = cell(sig(p, q)); top = np.flatnonzero(nr == 0); soc = np.flatnonzero(nr == r)
    Tm = []; Sm = []
    for i in range(nq):
        R1, o1 = sub_mod(rho[i], top); R2, o2 = sub_mod(rho[i], soc); okTop &= o1; okSoc &= o2; Tm.append(R1); Sm.append(R2)
    okSoc &= all(bool(np.all(rho[j][1][soc] == 0)) for j in range(nq, n))
    bt = commutant_v(Tm, len(top)); bs = commutant_v(Sm, len(soc))
    okTop &= len(top) == mq * d and len(bt) == d and classify_v(bt, len(top)) == D
    okSoc &= len(soc) == mq * d and len(bs) == d and classify_v(bs, len(soc)) == D
    ct, cs = module_class(Tm, Qc, m=len(top))[1], module_class(Sm, Qc, m=len(soc))[1]; okTop &= sum(ct) == 1; okSoc &= sum(cs) == 1
    okSoc &= (ct == cs) == (s == 1 or r % 2 == 0); nsum['soc_other'] += ct != cs
    IR = irreps_of(c)
    okIrr &= len(IR) == s and all(len(T) == n and rel_ok(T, eps, len(T[0][0])) and all(not np.any(T[j][1]) for j in range(nq, n)) for T in IR)
    okIrr &= all(len(commutant_v(T[:nq], len(T[0][0]))) == d for T in IR) and (s == 1 or module_class(IR[0][:nq], Qc)[1] != module_class(IR[1][:nq], Qc)[1])
    for j in range(nq, n):                                                 # NULLACTS (plain): ker e_j on A f is a proper submodule
        ker = np.flatnonzero((reps >> j) & 1); okk = 0 < len(ker) < m and np.array_equal(np.flatnonzero(rho[j][1] == 0), ker)
        okk &= all(sub_mod(R, ker)[1] for R in rho); nker += okk
    cen = np.ones(N, dtype=bool)                                           # the central blades: s(e_i, a) = s(a, e_i) for every generator
    for i in range(n): cen &= S[1 << i, :] == S[:, 1 << i]
    okCen &= np.array_equal(np.flatnonzero(cen & ~hn), [0]); nsum['cen'] += 1
    if nq % 2:                                                             # the quotient's omega: central in Q, anticommuting with the nulls
        om = (1 << nq) - 1
        okZ2 &= all(S[1 << i, om] == S[om, 1 << i] for i in range(nq)) and all(S[1 << j, om] == -S[om, 1 << j] != 0 for j in range(nq, n))
        okZ2 &= int(S[om, om]) == (1 if s == 2 else -1)
    prq['type'] += ltype_eps(sig(p + r, q)) != ltype_eps(sig(p, q)); prq['cls'] += KO[(p + r - q) % 8] != KO[(p - q) % 8]
chk('bit', okJ and okPow and okQ, 'ns.NUL: for the 120 cells (p,q,r), r >= 1, n <= 8: the labels with a null bit span a two-sided ideal J of dimension 2^n - 2^(p+q); J^k is spanned by the labels with at least k null bits, J^r != 0 = J^(r+1); the labels below 2^(p+q) (no null bit) form a subalgebra with the sign table of Cl(p,q) entry by entry, a complement of J: Cl(p,q,r) = Cl(p,q) + J, the quotient of LNC-055 split by a subalgebra')
chk('bit', okDim and okAct and okLay and okCom, 'ns.NUL: the bit rule\'s left ideal A f (f = prod (1 + u)/2 over a maximal commuting set of labels of square +1, all without a null bit: the quotient\'s) has dimension tr L_f = 2^n 2^-w = 2^r m dim D, 2^r times the quotient\'s minimal left ideal (up to %d); the null generators act on it non-trivially; its Loewy layers J^k f / J^(k+1) f have dimension C(r,k) m dim D; its exact commutant has dimension 2^r d (s = 1) or 2^(r-1) d (s = 2, %d cells): not minimal, reducible, for every r >= 1' % (maxm, nsum['s2']))
chk('bit', okTop and okSoc, 'ns.NUL: the top A f / J f (the basis vectors without a null bit) is the quotient\'s minimal left ideal, irreducible (commutant D, exact): A f is its projective cover; the socle J^r f = A N f (N the product of the null generators) is a minimal left ideal of dimension m dim D, killed by every null generator, the top twisted by the grade automorphism alpha^r: the other simple module exactly when s = 2 and r is odd (%d cells), the same otherwise' % nsum['soc_other'])
chk('bit', okIrr, 'ns.NUL: the irreducible modules: for each of the 120 cells the s simple modules of the quotient Cl(p,q), the null generators acting by 0, satisfy the relations of Cl(p,q,r), are irreducible (commutant D) and distinct (the volume element of the quotient when s = 2); J kills every simple module (J^(r+1) = 0 and Nakayama, recalled), so these are all')
chk('bit', okCen and okZ2, 'ns.NUL: the centre of every null cell (its central blades) has the scalars as its only part without a null bit: each null cell is one block; for the %d cells with s = 2 (quotient at the clocks 1, 5) and the %d at the clocks 3, 7 the quotient\'s volume element is central in Cl(p,q) and anticommutes with every null generator: (1 +- omega)/2 are idempotents of the cell, central modulo J and not central, and the centre C of the quotient does not lift' % (nsum['s2'], nsum['C']))
chk('ctl', nker == sum(c[2] for c in NULLC), 'ns.NUL: NULLACTS: on A f the kernel of each null generator is a proper non-zero submodule (the basis vectors with its bit; %d of %d null generators over the 120 cells): a module on which a null generator acts non-trivially is reducible' % (nker, sum(c[2] for c in NULLC)))
chk('ctl', prq['type'] == 120 and prq['cls'] > 0, 'ns.NUL: PRQUOT: the quotient taken as Cl(p+r,q) has another type for all 120 cells (dimension 2^n against the 2^(p+q) labels without a null bit), no radical, and another class (KO^(p+r-q)) for %d of them' % prq['cls'])
note('(%.1f s)' % (time.time() - t))
t = time.time()
def mono_words(G, d):
    """the 2^N words of the monomial matrices G (canonical increasing order) as two arrays (rows, values), by doubling"""
    Wr = np.arange(d, dtype=np.int64)[None, :].copy(); Wv = np.ones((1, d), dtype=np.int64)
    for g in G:
        Wr = np.concatenate([Wr, Wr[:, g[0]]]); Wv = np.concatenate([Wv, Wv[:, g[0]] * g[1][None, :]])
    return Wr, Wv
def gram_mono(Wr, Wv):
    """tr(W_a W_b) for every pair of monomial words (numpy integers, in chunks)"""
    M, d = Wr.shape; Gm = np.zeros((M, M), dtype=np.int64); cc = np.arange(d)
    for a0 in range(0, M, max(1, (1 << 20) // (M * d) or 1)):
        a1 = min(M, a0 + max(1, (1 << 20) // (M * d) or 1)); A = Wr[a0:a1]                       # (k, d)
        RA = np.take_along_axis(A[:, None, :], np.broadcast_to(Wr[None, :, :], (a1 - a0, M, d)), 2)  # rows of W_a W_b at column c
        VA = np.take_along_axis(Wv[a0:a1][:, None, :], np.broadcast_to(Wr[None, :, :], (a1 - a0, M, d)), 2) * Wv[None, :, :]
        Gm[a0:a1] = np.where(RA == cc[None, None, :], VA, 0).sum(2)
    return Gm
okG = okGb = True; nG = 0
for c in NULLC:
    p, q, r = c; n = p + q + r; nq = p + q; d = 1 << n
    G = [to_mono(g) for g in site_gens(sig(*c))]; Wr, Wv = mono_words(G, d); Gm = gram_mono(Wr, Wv)
    rkG = int(np.linalg.matrix_rank(Gm.astype(float))); w_null = (np.arange(d) >> nq) != 0         # the words with a null generator
    okG &= bool(np.all(Gm[w_null] == 0)) and int(np.linalg.matrix_rank(Gm[np.ix_(~w_null, ~w_null)].astype(float))) == 1 << nq
    nul = [G[j] for j in range(nq, n)]; prod_ = m_prod(nul, d)
    okG &= rel_ok(G, sig(*c), d) and bool(np.any(prod_[1])) and all(not np.any(m_mul(g, prod_)[1]) for g in nul)
    okGb &= d - rkG == d - (1 << nq); nG += 1
chk('std', okG, 'ns.NUL: numpy, no label, for the 120 cells: the Kronecker site matrices (X + J at a null site, monomial) satisfy the relations of Cl(p,q,r); the product of the r null matrices is non-zero and is killed by each null matrix; the trace form tr(W_a W_b) of the 2^n words vanishes on every word with a null generator and has rank 2^(p+q) on the others: its radical (Dickson\'s criterion) is spanned by the words with a null generator')
chk('bit==std', okGb, 'ns.NUL: the radical of the trace form of the matrices has the dimension 2^n - 2^(p+q) of the labels\' J for the %d cells (up to 256 x 256 Gram matrices)' % nG)
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ ns.ABS  the classes A(p,q,r) of the 120 null cells
head('ns.ABS  A(p,q,r) = coker(N(Cl(p+1,q+1,r)) -> N(Cl(p+1,q,r))) from the cells\' own left ideals: simple modules and projective covers')
t = time.time()
NS = FAULT == 'NOSWAP'
def ordered(mods_list, vol):
    """two modules of a two-summand graded cell, the one on which the quotient's volume element is +1 first (as period_map.py's build_ideal)"""
    if len(mods_list) == 1: return mods_list
    return mods_list if vol(mods_list[0]) == 1 else mods_list[::-1]
def null_classes(p, q, r, noswap=False):
    """the restriction matrices of the graded null cell from its own left ideal: by the simple modules (the tops) and by the projective
    covers (A f restricted, decomposed by its top); with the matrix of the quotients"""
    eb, es = (1,) + sig(p, q + 1, r), (1,) + sig(p, q, r); drop = 1 + p + q; nnb = p + q + 2; nns = p + q + 1
    Qb, Qs = cell((1,) + sig(p, q + 1)), cell((1,) + sig(p, q)); Rq = restrict(Qb, drop, Qs, noswap)
    if FAULT == 'PRQUOT':                                                  # the wrong quotient Cl(p+r,q) in place of the cell's own modules
        Rw = restrict(cell((1,) + sig(p + r, q + 1)), 1 + p + r + q, cell((1,) + sig(p + r, q)), noswap); return Rw, Rw, Rq, True
    Lb = left_ideal(eb); mb = Lb['m']; nb = ((1 << r) - 1) << nnb; topb = np.flatnonzero((Lb['reps'] & nb) == 0)
    ok = rel_ok(Lb['rho'], eb, mb) and mb == (1 << r) * len(topb)
    P = [Lb['rho']] + ([[m_neg(R) for R in Lb['rho']]] if Qb['summ'] == 2 else [])
    def topmods(Pm): return [sub_mod(Pm[i], topb)[0] for i in range(nnb)]
    vol = lambda Pm: 1 if m_eq(m_prod(topmods(Pm), len(topb)), m_eye(len(topb))) else -1
    P = ordered(P, vol); Rt_cols, Rp_cols = [], []
    for Pm in P:
        T = topmods(Pm)
        if FAULT == 'NULLACTS': simp = [Pm[i] for i in range(len(Pm)) if i != drop][:nns]; mm_ = mb   # A f taken as the irreducible
        else: simp = T[:nns]; mm_ = len(topb)
        ok1, v1 = module_class(simp, Qs, noswap, m=mm_); Rt_cols.append(v1)
        Res = [Pm[i] for i in range(len(Pm)) if i != drop]; ok &= rel_ok(Res, es, mb)          # the projective cover restricted
        nr = popv(Lb['reps'] & nb); ok &= all(int((nr == k).sum()) == comb(r, k) * len(topb) for k in range(r + 1))
        ok2, v2 = module_class([sub_mod(Res[i], topb)[0] for i in range(nns)], Qs, noswap, m=len(topb)); Rp_cols.append(v2)
        ok &= ok2 and (ok1 or FAULT == 'NULLACTS')
    tr_ = lambda cl: [[cl[j][i] for j in range(len(cl))] for i in range(len(cl[0]))]
    return tr_(Rt_cols), tr_(Rp_cols), Rq, ok
okA = okAk = True; LSTN = {}; nmax = 0; nsw = {}
for c in NULLC:
    p, q, r = c; Rt, Rp, Rq, ok = null_classes(p, q, r, NS)
    okA &= ok and Rt == Rq and Rp == Rq; LSTN[c] = coker(Rt); okAk &= LSTN[c] == KO[(p - q) % 8] and coker(Rp) == LSTN[c]
    nmax = max(nmax, 1 + p + q + 1 + r)
    nsw[c] = coker(null_classes(p, q, r, True)[0])
bycl = ' '.join(LSTN[next(c for c in NULLC if clock(c) == k)] for k in range(8))
chk('bit', okA, 'ns.ABS: for the 120 graded null cells (1,) + (p,q,r) and (1,) + (p,q+1,r), up to %d generators: the left ideal A f of the big cell satisfies its relations, has dimension 2^r times its top; the restriction matrix from the simple modules (the tops, the null generators acting by 0) and the one from the projective covers (A f restricted to the small cell, a module with the Loewy layers C(r,k) times its top, decomposed by its top) both equal the matrix of the quotients Cl(p+1,q+1) -> Cl(p+1,q), entry by entry' % nmax)
chk('bit', okAk, 'ns.ABS: A(p,q,r) = A(p,q) = KO^(p-q)(point) for all 120 null cells: by the clock c = 0..7 %s, the list of ATY-001 and of GEN-018; the classes see the quotient and forget r (the graded Morita class of LNC-055 keeps it)' % bycl)
okN = all((nsw[c] == 'Z+Z2') == (clock(c) % 4 == 0) for c in NULLC) and all(nsw[c] == KO[clock(c)] for c in NULLC if clock(c) % 4)
chk('ctl', okN, 'ns.ABS: NOSWAP (the two irreducibles of a two-summand graded cell kept by the dropped generator) gives Z+Z2 exactly at the clocks 0 and 4, %d of the 120 null cells, the others unchanged' % sum(1 for c in NULLC if nsw[c] == 'Z+Z2'))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ the chains: stages, idempotents as products over signed blades
class SegK:
    """the kernel on concatenated labels as the graded tensor product of its segments (cb.GT): s(a,b) = prod_k s_k(a_k, b_k) times
    (-1)^(sum_(k<l) |a_l| |b_k|), each s_k the full table of a segment of at most 8 bits (checked against BR.s on samples)"""
    def __init__(self, eps, cuts):
        self.eps = tuple(eps); self.cuts = [c_ for c_ in cuts]; self.off = [sum(cuts[:k]) for k in range(len(cuts))]
        assert sum(cuts) == len(eps) and all(c_ <= 8 for c_ in cuts)
        self.T = [table(self.eps[o:o + c_]).astype(np.int64) for o, c_ in zip(self.off, self.cuts)]
    def s(self, A, B):
        A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
        sg = np.ones(np.broadcast(A, B).shape, dtype=np.int64); par = np.zeros_like(sg); below = np.zeros_like(sg)
        for T_, o, c_ in zip(self.T, self.off, self.cuts):
            ak, bk = (A >> o) & ((1 << c_) - 1), (B >> o) & ((1 << c_) - 1)
            sg = sg * T_[ak, bk]; par = par + popv(ak) * below; below = below + popv(bk)
        return sg * (1 - 2 * (par & 1))
def expand(K, V):
    """the 2^|V| ordered products v_T of the signed blades V (T a bit mask over V): labels L_T and signs sigma_T, by doubling"""
    L = np.zeros(1, dtype=np.int64); S = np.ones(1, dtype=np.int64)
    for sv, lv in V: L, S = np.concatenate([L, L ^ lv]), np.concatenate([S, S * sv * K.s(L, lv)])
    return L, S
def group_law(K, V, L, S):
    """v_T v_t = v_(T xor t) for every T and t: each v of square +1, the v pairwise commuting (by associativity: P^2 = P)"""
    T = np.arange(len(L), dtype=np.int64)
    return all(np.array_equal(S * sv * K.s(L, lv), S[T ^ (1 << t)]) for t, (sv, lv) in enumerate(V))
def square_full(K, L, S):
    """P^2 from the subset expansion on all 4^w pairs of terms: c_U = sum_T sigma_T sigma_(T xor U) s(L_T, L_(T xor U)); P^2 = P is
    c_U = 2^w sigma_U for every U (in chunks; exact integers)"""
    M = len(L); w = M.bit_length() - 1; c = np.zeros(M, dtype=np.int64); step = max(1, (1 << 21) // M); T = np.arange(M, dtype=np.int64)
    for a0 in range(0, M, step):
        Ta = T[a0:a0 + step]; U = Ta[:, None] ^ T[None, :]
        val = S[Ta][:, None] * S[None, :] * K.s(L[Ta][:, None], L[None, :])
        c += np.bincount(U[val > 0], minlength=M) - np.bincount(U[val < 0], minlength=M)
    return np.array_equal(c, (1 << w) * S), c
def phi_blade(K, Nk, sb):
    """e_i -> e_i Omega_(k+1) (i < N_k) on a signed blade, by the kernel (period_map.py's phi_mv on one blade)"""
    Om = 255 << Nk; s_, lab = sb; out = (s_, 0)
    for i in range(lab.bit_length()):
        if lab >> i & 1: out = mmul(K, out, (K.s(1 << i, Om), (1 << i) ^ Om))
    return out
QB = {b: comm_set_v(sig(*b)) for b in BLOCKS}                              # four commuting labels of square +1 in each block
MULT = 3 if FAULT == 'MULT3' else 16
def run_chain(c0, b, K_, dense=False):
    """the chain C_0 in ... in C_K from the start cell c0 = (p,q,r) with the block b repeated: the quotient's type, the radical, a minimal
    idempotent of each summand of the quotient as a product over signed blades (V_(k+1) = phi(V_k) + the block's four), P^2 = P by the group
    law (and on all pairs while |V| <= 11), tr L_P, the units, the multiplicity matrices, the volume element kept"""
    p, q, r = c0; n = p + q + r; nq = p + q; eb = sig(*b); nm = ((1 << r) - 1) << nq; out = {'ok': True, 'err': []}
    EPS = [sig(*c0) + eb * k for k in range(K_ + 1)]; NK = [n + 8 * k for k in range(K_ + 1)]
    QE = [quot_sig(p, q, r) + eb * k for k in range(K_ + 1)]; TY = [stage_type(e) for e in QE]; out['TY'] = TY
    want = clock_type(p, q); s_ = want[2]
    out['okTy'] = all(TY[k] == (want[0], want[1] * 16 ** k, want[2]) for k in range(K_ + 1))
    rad = []
    for k in range(K_ + 1):
        e_ = EPS[k]; e1, e2 = e_[:max(0, NK[k] - 8)], e_[max(0, NK[k] - 8):]
        a1, a2 = np.arange(1 << len(e1), dtype=np.int64), np.arange(1 << len(e2), dtype=np.int64)
        split = (1 << NK[k]) - int((s_vec(e1, a1, a1) != 0).sum()) * int((s_vec(e2, a2, a2) != 0).sum())    # the graded diagonal
        enum = int((s_vec(e_, np.arange(1 << NK[k], dtype=np.int64), np.arange(1 << NK[k], dtype=np.int64)) == 0).sum()) if NK[k] <= 20 else split
        rad.append((enum, split))
    out['rad'] = rad; out['okRad'] = all(e_ == s2 == (1 << NK[k]) - (1 << len(QE[k])) for k, (e_, s2) in enumerate(rad))   # 2^N - dim(quotient)
    KB = [BR(e) for e in EPS]; KS = [SegK(e, ([n] if n else []) + [8] * k) for k, e in enumerate(EPS)]
    U0 = comm_set_v(EPS[0]); V = {'+': [(1, u) for u in U0]}
    om = [((1 << NK[k]) - 1) & ~nm for k in range(K_ + 1)]                   # the quotient's volume element at each stage
    if s_ == 2:                                                             # the other summand by e_i -> -e_i; each named by omega's coefficient
        Va, Vb = V['+'], [((-1) ** pc(u), u) for u in U0]; L0, S0 = expand(KS[0], Va); h0 = np.flatnonzero(L0 == om[0])
        V = {'+': Va, '-': Vb} if len(h0) and S0[h0[0]] == 1 else {'+': Vb, '-': Va}
    Vs = [dict(V)]
    for k in range(K_): Vs.append({g: [phi_blade(KB[k + 1], NK[k], v) for v in Vk] + [(1, u << NK[k]) for u in QB[b]] for g, Vk in Vs[k].items()})
    out['V'] = Vs; out['K'] = KS; out['NK'] = NK; out['om'] = om
    okP = okR = okU = okM = okKeep = okSum = okDen = okFull = True; units = []; Ms = []; coef = []
    for k in range(K_ + 1):
        D, mk, sk = TY[k] if TY[k] else ('R', 0, 0); ck = {}
        for g, Vk in Vs[k].items():
            L, S = expand(KS[k], Vk); w = len(Vk)
            okP &= len(np.unique(L)) == 1 << w and group_law(KS[k], Vk, L, S) and all(not (lv & nm) for _, lv in Vk)
            if w <= 11: okFull &= square_full(KS[k], L, S)[0]
            if dense and k <= 1:                                            # the dense product with BR.mul (the stages n and n + 8, n <= 4)
                Pd = {int(l_): Fr(int(s2), 1 << w) for l_, s2 in zip(L, S)}; okDen &= KB[k].mul(Pd, Pd) == Pd
            okR &= Fr(1 << NK[k], 1 << w) == (1 << r) * mk * DD[D]          # tr L_P: the projective cover A_k P
            hit = np.flatnonzero(L == om[k]); cw = int(S[hit[0]]) if len(hit) else 0
            ck[g] = (Fr(1, 1 << w), Fr(cw, 1 << w))                          # the coefficients of 1 and of omega in P
        coef.append(ck)
        if s_ == 2: okSum &= ck['+'][1] == ck['+'][0] and ck['-'][1] == -ck['-'][0]   # P z_+ = P, P' z_- = P' (z_+- = (1 +- omega)/2)
        zc = {'+': Fr(1, 2) if s_ == 2 else Fr(1)} | ({'-': Fr(1, 2)} if s_ == 2 else {})
        units.append({g: zc[g] / ck[g][0] for g in ck}); okU &= all(u_ == mk for u_ in units[-1].values())
    for k in range(K_):
        Mk = {}
        for j in Vs[k]:
            L, S = expand(KS[k + 1], [phi_blade(KB[k + 1], NK[k], v) for v in Vs[k][j]])   # phi(P_(k,j)) as its expansion
            hit = np.flatnonzero(L == om[k + 1]); c0_, cw = Fr(1, len(L)), (Fr(int(S[hit[0]]), len(L)) if len(hit) else Fr(0))
            for i in Vs[k + 1]:
                zw = {'+': Fr(1, 2), '-': Fr(-1, 2)}[i] if s_ == 2 else Fr(0); z0 = Fr(1, 2) if s_ == 2 else Fr(1)
                Mk[(i, j)] = (c0_ * z0 + cw * zw) / coef[k + 1][i][0]        # tr L(phi(P) z) / tr L(P'): (xz)_0 = x_0 z_0 + x_w z_w s(w,w), s(w,w) = +1 when s = 2
        Ms.append(Mk); okM &= all(v == (MULT if i_ == j_ else 0) for (i_, j_), v in Mk.items())
        okU &= all(units[k + 1][i] == sum(Mk[(i, j)] * units[k][j] for j in Vs[k]) for i in Vs[k + 1])
        if s_ == 2: okKeep &= phi_blade(KB[k + 1], NK[k], (1, om[k])) == (1, om[k + 1])
    out.update(okP=okP and okFull, okDen=okDen, okR=okR, okU=okU and okSum, okM=okM, okKeep=okKeep, units=units, Ms=Ms, s=s_, m0=want[1])
    return out

# ================================================================================================ ns.STG  the chains from the null cells
head('ns.STG  the chains from the null cells: the quotient, the radical x 256, the idempotents and projective covers, K_0 and the unit, 16 I, kept')
t = time.time()
STG = {}; REF = {}
for c in NULLC:
    for b in BLOCKS: STG[(c, b)] = run_chain(c, b, 2 if sum(c) <= 6 else 1, dense=sum(c) <= 4)
for pq in sorted({(c[0], c[1]) for c in NULLC}):
    for b in BLOCKS: REF[(pq, b)] = run_chain((pq[0], pq[1], 0), b, 1)
ch = list(STG.values()); n2 = sum(1 for (c, b) in STG if sum(c) <= 6); n20 = sum(1 for (c, b) in STG if sum(c) <= 4)
okT = all(x['okTy'] for x in ch); okRd = all(x['okRad'] for x in ch)
chk('bit', okT and okRd, 'ns.STG: the %d chains from the 120 null cells and the three blocks at the stages n and n + 8, and the %d from the 56 cells with n <= 6 at n + 16 (up to 22 generators): the quotient (the labels without a null bit) has the type of Cl(p,q) with the matrix size x 16^k, D and s kept; the radical has dimension 2^N - 2^(p+q+8k) = 256^k (2^n - 2^(p+q)), by enumerating the labels to 20 generators and by the graded diagonal (equal there, alone at 21 and 22)' % (len(ch), n2))
okP_ = all(x['okP'] for x in ch); okD_ = all(x['okDen'] for x in ch); okR_ = all(x['okR'] for x in ch)
chk('bit', okP_ and okD_ and okR_, 'ns.STG: a minimal idempotent of each summand of the quotient, P = prod (1 + v)/2 over the signed blades V_(k+1) = phi(V_k) + the block\'s four (phi by the kernel, no label with a null bit), is an idempotent of the stage: the 2^|V| products v_T are distinct, the group law v_T v_t = v_(T xor t) holds and P^2 = P on all pairs of terms (|V| <= 11; also by the dense product of BR.mul at n and n + 8 for the %d chains with n <= 4); tr L_P = 2^(N - |V|) = 2^r m_k dim D, the dimension of the projective cover A_k P, 2^r times the quotient\'s minimal left ideal' % n20)
okU_ = all(x['okU'] for x in ch); okL059 = all(len(comm_set_v(sig(*c))) == (x['s'] * x['m0']).bit_length() - 1 for (c, b), x in STG.items())
chk('bit', okU_ and okL059, 'ns.STG: K_0 of every stage is Z^s with the cone N^s (the classes of the projective covers A_k P, those of the quotient: idempotent lifting, recalled; here the quotient\'s idempotents lie in the stage), s = 2 for the 30 null cells at the clocks 1, 5; each P lies in one summand (its coefficient of omega is +-P_0), the unit tr L_z / tr L_P = (m_k, ..., m_k), m_k = 16^k m_0, carried by the multiplicity matrix; at stage 0 the commuting set has 2^w = s m_0 (LNC-059)')
okM_ = all(x['okM'] for x in ch); okK_ = all(x['okKeep'] for x in ch)
okRef = all(STG[(c, b)]['units'][:2] == REF[((c[0], c[1]), b)]['units'] and STG[(c, b)]['Ms'][:1] == REF[((c[0], c[1]), b)]['Ms'] and REF[((c[0], c[1]), b)]['okM'] for (c, b) in STG)
ninc = sum(len(x['Ms']) for x in ch); nkeep = sum(len(x['Ms']) for x in ch if x['s'] == 2)
chk('bit', okM_ and okK_ and okRef, 'ns.STG: the multiplicity matrix of every inclusion (%d) is %d I, and for the %d inclusions of a two-summand quotient its volume element goes to +omega of the next stage (kept); units and multiplicity matrices equal those of the chain of the start cell (p,q,0) (%d chains computed alongside): the null generators change none of the stage data, only the radical' % (ninc, MULT, nkeep, len(REF)))
dty = dts = 0
for c in NULLC:
    p, q, r = c
    for b in BLOCKS:
        for k in range(2):
            w_, r_ = stage_type(sig(p + r, q) + sig(*b) * k), stage_type(sig(p, q) + sig(*b) * k); dty += w_ != r_; dts += w_[2] != r_[2]
chk('ctl', dty == 720 and dts > 0, 'ns.STG: PRQUOT, the quotient taken as Cl(p+r,q): its type differs from the quotient\'s at both stages of all 360 chains (720 stages; s differs at %d), and it would leave no radical' % dts)
note('the stages from (0,0,1), (1,0,1), (0,1,1), (0,0,8), block (8,0,0): ' + '; '.join('%s: %s, units %s, radical %s' % (cstr(c), tstr(STG[(c, (8, 0, 0))]['TY'][0]), '/'.join(','.join(str(int(v)) for v in u_.values()) for u_ in STG[(c, (8, 0, 0))]['units']), '/'.join(str(e_) for e_, _ in STG[(c, (8, 0, 0))]['rad'])) for c in [(0, 0, 1), (1, 0, 1), (0, 1, 1), (0, 0, 8)]))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ ns.P3  the exact P^2 = P at the third stage
head('ns.P3  the exact P^2 = P at the third stage of the 54 chains of GEN-019: the subset expansion with the exact signs, not the dense product')
t = time.time()
START = [(p, n - p, 0) for n in range(5) for p in range(n + 1)] + [(8, 0, 0), (0, 8, 0), (4, 4, 0)]
CH = {(c0, b): run_chain(c0, b, 2, dense=sum(c0) <= 4) for c0 in START for b in BLOCKS}
def antipair(b, k_off):
    """a label of the block, square +1, anticommuting with the first of its four commuting labels and commuting with the second and third,
    outside their span: the last of the four replaced by it (ANTIPAIR)"""
    Tb = table(sig(*b)); q1, q2, q3 = QB[b][:3]; span3 = {0, q1, q2, q3, q1 ^ q2, q1 ^ q3, q2 ^ q3, q1 ^ q2 ^ q3}
    x = next(u for u in range(1, 256) if Tb[u, u] == 1 and Tb[u, q1] == -Tb[q1, u] and Tb[u, q2] == Tb[q2, u] and Tb[u, q3] == Tb[q3, u] and u not in span3)
    return (1, x << k_off)
okSeg = okDist = okSq = okGL = okFQ = okTr = True; nidem = 0; npairs = 0; nsmp = 0; wmax = 0; ctl_np = ctl_gl = 0; nctl = 0
for (c0, b), X in CH.items():
    K2 = X['K'][2]; KB2 = BR(K2.eps); N2 = X['NK'][2]
    for _ in range(50):
        x_, y_ = RNG.randrange(1 << N2), RNG.randrange(1 << N2); okSeg &= int(K2.s(x_, y_)) == KB2.s(x_, y_); nsmp += 1
    D, m2, _ = X['TY'][2]
    for g, V2 in X['V'][2].items():
        Vu = V2[:-1] + [antipair(b, X['NK'][1])] if FAULT == 'ANTIPAIR' else V2
        L, S = expand(K2, Vu); w = len(Vu); wmax = max(wmax, w); nidem += 1; npairs += 4 ** w
        okDist &= len(np.unique(L)) == 1 << w
        okSq &= square_full(K2, L, S)[0]; okGL &= group_law(K2, Vu, L, S)
        okTr &= Fr(1 << N2, 1 << w) == m2 * DD[D]
        Lf, Sf = expand(K2, Vu[:-4]); Lq, Sq = expand(K2, Vu[-4:])           # phi(P_1) and Q_2 on their terms, both orders
        okFQ &= bool(np.all(K2.s(Lf[:, None], Lq[None, :]) == K2.s(Lq[None, :], Lf[:, None])))
        Va = V2[:-1] + [antipair(b, X['NK'][1])]; La, Sa = expand(K2, Va)          # ANTIPAIR as a control: one anticommuting pair
        ctl_np += not square_full(K2, La, Sa)[0]; ctl_gl += not group_law(K2, Va, La, Sa); nctl += 1
chk('bit', okSeg, 'ns.P3: the kernel split into the segments of the start cell and the two blocks (the graded tensor product of cb.GT: s(a,b) = s_0 s_1 s_2 (-1)^(|a_1||b_0| + |a_2||b_0| + |a_2||b_1|), each s_k a table of at most 8 bits) equals BR.s on %d sampled entries of the third stages (up to 24 generators)' % nsmp)
chk('bit', okDist and okSq and okGL and okFQ and okTr, 'ns.P3: for the %d minimal idempotents of the third stages of the 54 chains (the 15 cells (p,q,0) with n <= 4 and (8,0), (0,8), (4,4), each with one block repeated; two summands in 9 chains), P = prod (1 + v)/2 over |V| = w_0 + 8 signed blades (up to %d, 2^|V| distinct terms, up to 4096): P^2 from the subset expansion on all 4^|V| pairs of terms (%d products, 16.7 million per idempotent at |V| = 12) has the coefficient 2^|V| sigma_U 2^(-2|V|) at every label: P^2 = P exactly; the group law v_T v_t = v_(T xor t) holds; phi(P_1) Q_2 = Q_2 phi(P_1) on the terms; tr L_P = 2^(N - |V|) = m dim D (4096 at 24 generators)' % (nidem, wmax, npairs))
okCH = all(X['okTy'] and X['okP'] and X['okDen'] and X['okR'] and X['okU'] and X['okM'] and X['okKeep'] for X in CH.values())
chk('bit', okCH, 'ns.P3: with these idempotents the stage data of the 54 chains, recomputed at n, n + 8 and n + 16: the type (D and s kept, size x 16), tr L_P = m dim D, the units 16^k m_0 (1, ..., 1), the multiplicity matrices %d I at both steps (108 inclusions), the volume element of the 9 two-summand chains kept: GEN-019\'s numbers, now with P^2 = P exact at every stage (also by BR.mul at n and n + 8 for the 45 chains with n <= 4)' % MULT)
chk('ctl', ctl_np == nctl and ctl_gl == nctl, 'ns.P3: ANTIPAIR: with the last label of Q_2 replaced by a label of the block of square +1 that anticommutes with the first and commutes with the second and third, the product is not idempotent (P\'^2 != P\' on the full expansion) and the group law fails, in all %d cases' % nctl)
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ ns.STD  the standard routes at the scopes of the bit route
head('ns.STD  the standard routes widened, no label: the signs of the map on every pair (n <= 6), the classes for p + q <= 8 (scipy.sparse), the stages 0 and 1 (n <= 4)')
t = time.time()
def mono_words_t(G, d):
    """the 2^N words of the monomial matrices G (canonical increasing order): Wr[a, c] the row of column c of word a, Wv its value (int32 /
    int16), by doubling: word a + 2^k = word a times G_k (a column gather of the words before)"""
    N = len(G); Wr = np.empty((1 << N, d), dtype=np.int32); Wv = np.empty((1 << N, d), dtype=np.int16)
    Wr[0] = np.arange(d); Wv[0] = 1
    for k, g in enumerate(G):
        h = 1 << k
        np.take(Wr[:h], g[0], axis=1, out=Wr[h:2 * h]); np.take(Wv[:h], g[0], axis=1, out=Wv[h:2 * h]); Wv[h:2 * h] *= g[1][None, :].astype(np.int16)
    return Wr, Wv
CELLS6 = [c for n in range(7) for c in cells(n)]                            # the 84 cells with n <= 6
TT = np.arange(256, dtype=np.int64); okMs = okMb = True; npair = 0; ncase = 0; dmx = 0
for c in CELLS6:
    n = sum(c); ec = sig(*c); d0 = 1 << n
    gam = [to_mono(g) for g in site_gens(ec)]; Gr, Gv = mono_words_t(gam, d0)
    for b in BLOCKS:
        eb = sig(*b); eps = ec + eb; Om = 255 << n
        Gb = [to_mono(g) for g in block_mats(b)]; Ob = m_prod(Gb, 16); Br_, Bv_ = mono_words_t(Gb, 16)
        G = [m_kron(g, Ob) for g in gam] + [m_kron(m_eye(d0), g) for g in Gb]; d = 16 * d0; dmx = max(dmx, d)
        okMs &= rel_ok(G, eps, d)                                           # the representation of Cl(n+8), exact integers
        Wr, Wv = mono_words_t(G, d)                                         # the canonical blade e_L -> the ordered product of its generators
        R = (Gr[:, None, :, None] * 16 + Br_[None, :, None, :]).reshape(d0, 256, d)          # gamma_S (x) g_T, column c = 16 i + j
        Vv = (Gv[:, None, :, None] * Bv_[None, :, None, :]).reshape(d0, 256, d)
        gi = np.array([1 << i for i in range(n)], dtype=np.int64); el, es = gi ^ Om, s_vec(eps, gi, Om)   # the bit route: e'_S f_T
        wl = np.zeros(d0, dtype=np.int64); ws = np.ones(d0, dtype=np.int64)
        for i in range(n):
            lo = np.arange(1 << i); wl[lo | (1 << i)] = wl[lo] ^ el[i]; ws[lo | (1 << i)] = ws[lo] * es[i] * s_vec(eps, wl[lo], el[i])
        L = wl[:, None] ^ (TT[None, :] << n); SG = (ws[:, None] * s_vec(eps, wl[:, None], (TT << n)[None, :])).astype(np.int16)
        okMb &= bool(np.array_equal(Wv[L] * SG[:, :, None], Vv) and np.all((Wr[L] == R) | (Vv == 0)))
        npair += d0 * 256; ncase += 1
chk('std', okMs, 'ns.STD: monomial Kronecker matrices, no label (X, J, X + J with Z strings; the blocks as 16 x 16 matrices): for the %d cases (the 84 cells with n <= 6, null generators included, and the three blocks) gamma_i (x) Omega and 1 (x) g_j satisfy all the relations of Cl(n+8) (matrices up to %d x %d, exact integers); the image of e\'_S f_T is gamma_S (x) g_T' % (ncase, dmx, dmx))
chk('bit==std', okMb, 'ns.STD: on every pair (S,T) of the %d cases (%d pairs; GEN-017 sampled 3120): the matrix gamma_S (x) g_T equals sigma(S,T) times the ordered product of the generators of L(S,T), sigma and L from the kernel (e\'_S f_T = sigma e_L): the signs of the explicit map on every pair for n <= 6' % (ncase, npair))
note('(%.1f s)' % (time.time() - t))
t = time.time()
_Xs = sps.csr_matrix(np.array([[0., 1.], [1., 0.]])); _Es = sps.csr_matrix(np.array([[0., 1.], [-1., 0.]]))
_Zs = sps.csr_matrix(np.diag([1., -1.])); _I2s = sps.identity(2, format='csr')
def sparse_gammas(eps):
    """abs_ring.py's Kronecker words (X for a square +1, E for -1, Z strings), one site per generator, as scipy.sparse matrices"""
    G = []
    for k in range(len(eps)):
        M = sps.identity(1, format='csr')
        for B in [_Zs] * k + [_Xs if eps[k] > 0 else _Es] + [_I2s] * (len(eps) - k - 1): M = sps.kron(M, B, format='csr')
        G.append(M)
    return G
def groups_of(w, tol=1e-7):
    out = []; start = 0; scale = max(1.0, float(np.abs(w).max()))
    for i in range(1, len(w) + 1):
        if i == len(w) or w[i] - w[i - 1] > tol * scale: out.append((start, i)); start = i
    return out
def std_cell_sparse(eps, seed):
    """the irreducible graded modules without labels (abs_ring.py's abs.S widened): a random symmetric X averaged over the group of words,
    the average taken as the composite of the N averages over <g_i> (conjugation by +-g_S is conjugation by g_S, so the composite is the
    average over the 2^N words), on scipy.sparse generators; its eigenspaces are the irreducible summands"""
    n = len(eps); d = 1 << n; G = sparse_gammas(eps); Y = np.random.default_rng(seed).standard_normal((d, d)); Y = Y + Y.T
    for g in G: Y = (Y + (g @ (g @ Y).T).T) / 2
    w, V = np.linalg.eigh(Y); gr = groups_of(w); om = G[0]
    for g in G[1:]: om = om @ g
    two = n % 2 == 1 and all(abs(om @ g - g @ om).max() < 1e-9 for g in G) and abs(om @ om - sps.identity(d)).max() < 1e-9
    irreps = []
    for sgn in ((1, -1) if two else (1,)):
        for a_, b_ in gr:
            Q = V[:, a_:b_]
            if not two or np.trace(Q.T @ (om @ Q)) * sgn > 0.5: break
        irreps.append([Q.T @ (g @ Q) for g in G])
    return {'m': gr[0][1] - gr[0][0], 'sizes': sorted({b_ - a_ for a_, b_ in gr}), 'two': two, 'irreps': irreps}
def std_class(mods, m_irr, two):
    m = mods[0].shape[0]
    if not two: return [int(round(m / m_irr))]
    om = np.eye(m)
    for R in mods: om = om @ R
    tr = np.trace(om); return [int(round((m + tr) / (2 * m_irr))), int(round((m - tr) / (2 * m_irr)))]
def kron_class(pairs, m_irr, two):
    """the class of a module whose generators are A_k (x) B_k: the dimension, and on a two-summand cell the trace of the volume element by the
    mixed-product rule, tr(prod (A_k (x) B_k)) = tr(prod A_k) tr(prod B_k)"""
    m = pairs[0][0].shape[0] * pairs[0][1].shape[0]
    if not two: return [int(round(m / m_irr))]
    PA = np.eye(pairs[0][0].shape[0]); PB = np.eye(pairs[0][1].shape[0])
    for A_, B_ in pairs: PA = PA @ A_; PB = PB @ B_
    tr = np.trace(PA) * np.trace(PB); return [int(round((m + tr) / (2 * m_irr))), int(round((m - tr) / (2 * m_irr)))]
def cols_to_rows(cl, two): return [[c_[i] for c_ in cl] for i in range(2 if two else 1)]
BETA_STD = {}
for b in BLOCKS:
    Gb = [g.astype(float) for g in block_mats(b)]; Ob = Gb[0]
    for g in Gb[1:]: Ob = Ob @ g
    BETA_STD[b] = [Ob] + Gb                                                 # the block's 16 x 16 Kronecker module graded by its Omega
PQ = [(p, n - p) for n in range(9) for p in range(n + 1)]                   # the 45 cells (p,q,0), n <= 8
okSd = okSc = okSR = okKD = True; nst = nst8 = nkd = 0; dmx = 0
for p, q in PQ:
    SB, SA = std_cell_sparse((1,) + sig(p, q), 101 + 7 * p + q), std_cell_sparse((1,) + sig(p, q + 1), 203 + 7 * p + q)
    bB, bA = cell((1,) + sig(p, q)), cell((1,) + sig(p, q + 1)); dmx = max(dmx, 1 << (p + q + 2)); drop = 1 + p + q
    okSd &= len(SB['sizes']) == 1 and len(SA['sizes']) == 1 and SB['m'] == bB['m'] and SA['m'] == bA['m'] and SB['two'] == (len(bB['irreps']) == 2) and SA['two'] == (len(bA['irreps']) == 2)
    Rs = cols_to_rows([std_class([T[i] for i in range(len(T)) if i != drop], SB['m'], SB['two']) for T in SA['irreps']], SB['two'])
    okSR &= Rs == restrict(bA, drop, bB, NS); okSc &= coker_divisors(Rs) == KO[(p - q) % 8]; nst += 1
    for b in BLOCKS:
        PR = [[pr for i, pr in enumerate([(T[0], BETA_STD[b][0])] + [(R, np.eye(16)) for R in T[1:]] + [(T[0], g) for g in BETA_STD[b][1:]]) if i != drop] for T in SA['irreps']]
        Rs8 = cols_to_rows([kron_class(pr, 16 * SB['m'], SB['two']) for pr in PR], SB['two'])
        okSR &= Rs8 == restrict(cell((1,) + sig(p, q + 1) + sig(*b)), drop, cell((1,) + sig(p, q) + sig(*b)), NS); okSc &= coker_divisors(Rs8) == KO[(p - q) % 8]; nst8 += 1
        if p + q <= 5:                                                       # the mixed-product rule against the dense graded tensor product
            dense = [cols_to_rows([std_class([np.kron(A_, B_) for A_, B_ in pr], 16 * SB['m'], SB['two']) for pr in PR], SB['two'])]
            okKD &= dense[0] == Rs8; nkd += 1
chk('std', okSd and okSc and okKD, 'ns.STD: scipy.sparse, no label: for the 45 cells (p,q,0), p + q <= 8, the graded cells as sparse Kronecker matrices (up to 10 generators, %d x %d), a random symmetric matrix averaged over the group of words as the composite of the averages over each generator, its eigenspaces: one dimension each, the bit route\'s irreducible dimensions and counts; at n + 8 the graded tensor product with the block\'s 16 x 16 module graded by its Omega, the traces by the mixed-product rule (equal to the dense product in the %d cases with p + q <= 5); the cokernels by determinantal divisors are KO^(p-q), 45 at n and %d at n + 8' % (dmx, dmx, nkd, nst8))
chk('bit==std', okSR, 'ns.STD: the restriction matrices of the standard route equal those from the minimal left ideals entry by entry, %d cases at n and %d at n + 8 (the bit route\'s cells up to 18 generators; GEN-018\'s standard route covered p + q <= 5)' % (nst, nst8))
note('(%.1f s)' % (time.time() - t))
t = time.time()
def clusters(ev, tol=1e-6):
    out = []
    for v in sorted(ev):
        if not out or v - out[-1][-1] > tol: out.append([v])
        else: out[-1].append(v)
    return [float(np.mean(c_)) for c_ in out]
def dense_comb(Wr, Wv, coef, d):
    """sum_a coef_a W_a as a dense d x d matrix from monomial words"""
    idx = (Wr.astype(np.int64) * d + np.arange(d)[None, :]).ravel()
    return np.bincount(idx, weights=(Wv * coef[:, None]).ravel(), minlength=d * d).reshape(d, d)
rk = lambda A: int(np.linalg.matrix_rank(A, tol=1e-6))
def std_stage_mono(G, d):
    """no label: the words of the algebra generated by the monomial matrices G; its centre as the centre of the commutant of G (the module is
    faithful and semisimple: the double commutant, recalled), the commutant exact (commutant_v on the matrices' two-term equations); the
    minimal central idempotents as spectral projectors of a random symmetric central element; a minimal projection of each summand as the top
    spectral projector of a random symmetric element of the algebra cut down by the central one (period_map.py's std_stage, its centre
    taken through the commutant instead of an SVD of 2^N columns)"""
    Wr, Wv = mono_words_t(G, d); M = len(Wr); C = commutant_v(G, d)
    cen = [B for B in C if B is not None and all(B2 is not None and m_eq(m_mul(B, B2), m_mul(B2, B)) for B2 in C)]
    Zc = sum(NPR.standard_normal() * m_dense(B).astype(float) for B in cen); Zc = (Zc + Zc.T) / 2; lam = clusters(np.linalg.eigvalsh(Zc))
    Zs = []
    for i, l in enumerate(lam):
        Pz = np.eye(d)
        for j, l2 in enumerate(lam):
            if j != i: Pz = Pz @ (Zc - l2 * np.eye(d)) / (l - l2)
        Zs.append(Pz)
    X = dense_comb(Wr, Wv, NPR.standard_normal(M), d); X = X + X.T; Ps = []
    for Pz in Zs:
        w_, V_ = np.linalg.eigh((Pz + Pz.T) / 2); B = V_[:, w_ > 0.5]; w2, V2 = np.linalg.eigh(B.T @ X @ B)
        Vt_ = B @ V2[:, w2 > w2.max() - 1e-6 * max(1.0, np.abs(w2).max())]; Ps.append(Vt_ @ Vt_.T)
    return Wr, Wv, len(cen), len(C), Zs, Ps
okSs = okSb = True; nstd = 0; STDM = {}
for c0 in START[:15]:
    n = sum(c0); d0 = 1 << n; G0 = [to_mono(g) for g in site_gens(sig(*c0))]
    W0r, W0v, nz0, nc0, Z0, P0s = std_stage_mono(G0, d0); om0 = m_dense(m_prod(G0, d0)).astype(float)
    A0 = np.stack([dense_comb(W0r, W0v, np.eye(len(W0r))[a], d0).ravel() for a in range(len(W0r))], 1)
    for b in BLOCKS:
        Gb = [to_mono(g) for g in block_mats(b)]; Ob = m_prod(Gb, 16); d1 = 16 * d0; OmI = m_kron(m_eye(d0), Ob)
        G1 = [m_kron(g, Ob) for g in G0] + [m_kron(m_eye(d0), g) for g in Gb]
        W1r, W1v, nz1, nc1, Z1, P1s = std_stage_mono(G1, d1); om1m = m_prod(G1, d1); om1 = m_dense(om1m).astype(float)
        labs = lambda Zs, om: ['+'] if len(Zs) == 1 else ['+' if np.allclose(om @ Z_, Z_, atol=1e-6) else ('-' if np.allclose(om @ Z_, -Z_, atol=1e-6) else '?') for Z_ in Zs]
        L0, L1 = labs(Z0, om0), labs(Z1, om1)
        phiG = [m_mul(G1[i], OmI) for i in range(n)]; Pr, Pv = mono_words_t(phiG, d1)    # the words of the images of e_i Omega
        Mstd = {}
        for j_, P_ in zip(L0, P0s):
            al = np.linalg.lstsq(A0, P_.ravel(), rcond=None)[0]; okSs &= np.allclose(A0 @ al, P_.ravel(), atol=1e-8)
            FP = dense_comb(Pr, Pv, al, d1)
            for i_, Z_, P1 in zip(L1, Z1, P1s): Mstd[(i_, j_)] = Fr(rk(FP @ Z_), rk(P1))
        u0 = {l_: Fr(rk(Z_), rk(P_)) for l_, Z_, P_ in zip(L0, Z0, P0s)}; u1 = {l_: Fr(rk(Z_), rk(P_)) for l_, Z_, P_ in zip(L1, Z1, P1s)}
        X = CH[(c0, b)]; okSs &= '?' not in L0 + L1; STDM[(c0, b)] = (L0, L1, Mstd, u0)
        okSb &= len(Z0) == X['TY'][0][2] and len(Z1) == X['TY'][1][2] and u0 == X['units'][0] and u1 == X['units'][1] and Mstd == X['Ms'][0]
        if len(Z0) == 2: okSb &= m_eq(m_prod(phiG, d1), om1m)                 # the volume element goes to +omega: kept
        nstd += 1
chk('std', okSs, 'ns.STD: no label, for the stages 0 and 1 of the %d chains from the 15 start cells with n <= 4 (Kronecker site matrices, the blocks as 16 x 16 matrices, C_1 as gamma (x) Omega, 1 (x) g; up to 256 x 256, 4096 words as monomials): the commutant of the generators exact (two-term equations of the monomial matrices), its centre, the minimal central idempotents and a minimal projection of each summand by numpy; each minimal projection of C_0 written in the words of C_0 and carried by the matrices of e_i Omega (GEN-019\'s standard route: the 18 chains from n <= 2)' % nstd)
chk('bit==std', okSb, 'ns.STD: for the same %d inclusions the matrix route gives the labels\' numbers: s at both stages, the order units (ratios of numpy ranks), the multiplicity matrices (16 on the diagonal), the volume element of a two-summand stage carried to +omega' % nstd)
note('what stays off the standard route: the third stages, the stages of the row-8 start cells (2^16 x 2^16 and beyond), the null cells\' stages beyond the trace form')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ ns.LIM  the limit as an ordered group, on the finite side
head('ns.LIM  the inductive limit of the ordered groups (Z^s, 16 I) with its cone and unit: Z[1/2]^s, computed on the finite side and set beside Elliott and Glimm')
t = time.time()
class DimGroup:
    """G = lim (Z^s, A) for a stationary connecting matrix A (non-negative integers, invertible over Q): the classes of pairs (k, v), v in Z^s at
    stage k, with (k, v) ~ (k + 1, A v); exact integers.  The cone: v >= 0 at some stage; the unit: a class (0, u)"""
    def __init__(self, A): self.A = [[int(a) for a in r] for r in A]; self.s = len(A)
    def step(self, v): return tuple(sum(a * x for a, x in zip(r, v)) for r in self.A)
    def at(self, x, K):
        k, v = x
        for _ in range(K - k): v = self.step(v)
        return v
    def eq(self, x, y): K = max(x[0], y[0]); return self.at(x, K) == self.at(y, K)
    def add(self, x, y): K = max(x[0], y[0]); return (K, tuple(a + b for a, b in zip(self.at(x, K), self.at(y, K))))
    def pos(self, x): return any(all(a >= 0 for a in self.at(x, x[0] + j)) for j in range(4))
def rnd_el(s, kmax=5, vmax=60): return (RNG.randrange(kmax + 1), tuple(RNG.randint(-vmax, vmax) for _ in range(s)))
SIG2 = [[0, 1], [1, 0]]
def iota(c_, x, swap=False):
    """(k, v) -> v / c^k in Q^s (Fractions); for the chain with the swap at every step sigma^k v / c^k"""
    k, v = x; v = tuple(v[::-1]) if swap and k % 2 else tuple(v)
    return tuple(Fr(a, c_ ** k) for a in v)
def in_Z_over(x, base, kmax=64):
    """is the rational x in Z[1/base]: x = a / base^k with a an integer, for some k <= kmax"""
    return any((x * base ** k).denominator == 1 for k in range(kmax + 1))
def iso_unit(u1, u2):
    """(Z[1/2]^s, u1) and (Z[1/2]^s, u2) isomorphic as ordered groups with unit: an order automorphism (coordinates permuted, each multiplied
    by a positive unit 2^j of the ring Z[1/2]) carries u1 to u2; under --fault NOUNIT the unit is forgotten"""
    if FAULT == 'NOUNIT': return len(u1) == len(u2)
    def unit2(x): x = Fr(x); return x > 0 and x.numerator & (x.numerator - 1) == 0 and x.denominator & (x.denominator - 1) == 0
    return len(u1) == len(u2) and any(all(unit2(Fr(b) / a) for a, b in zip(u1, perm)) for perm in itertools.permutations(u2))
LIM = {}
for key, X in list(CH.items()) + list(STG.items()):
    LIM.setdefault((X['s'], X['m0']), []).append((key, X))
okWD = okAdd = okInj = okOrd = okUn = okImg = okHalf = True; nsamp = 0
for (s_, m0), lst in LIM.items():
    G = DimGroup([[MULT if i == j else 0 for j in range(s_)] for i in range(s_)]); u = (0, (m0,) * s_)
    for _ in range(150):
        x, y = rnd_el(s_), rnd_el(s_); j = RNG.randrange(1, 4); nsamp += 1
        okWD &= iota(MULT, x) == iota(MULT, (x[0] + j, G.at(x, x[0] + j)))
        okAdd &= iota(MULT, G.add(x, y)) == tuple(a + b for a, b in zip(iota(MULT, x), iota(MULT, y)))
        x2 = (x[0] + j, G.at(x, x[0] + j)); okInj &= G.eq(x, x2) and (G.eq(x, y) == (iota(MULT, x) == iota(MULT, y)))
        okOrd &= G.pos(x) == all(a >= 0 for a in iota(MULT, x)) and G.pos(x) == G.pos(x2)
        tgt = tuple(Fr(RNG.randint(-99, 99), MULT ** RNG.randrange(6)) for _ in range(s_))
        kk = next(k for k in range(64) if all((a * MULT ** k).denominator == 1 for a in tgt))
        okImg &= iota(MULT, (kk, tuple(int(a * MULT ** kk) for a in tgt))) == tgt
    okUn &= iota(MULT, u) == (Fr(m0),) * s_ and all(G.eq((k, tuple(int(v) for v in X['units'][k].values())), u) for _, X in lst for k in range(len(X['units'])))
    okUn &= in_Z_over(Fr(1, m0), 2)                                         # x -> x / m0 an order automorphism of Z[1/2]^s: the unit to (1, ..., 1)
okHalf &= all(in_Z_over(Fr(1, 2 ** j), MULT) for j in range(1, 65)) and all(in_Z_over(Fr(1, MULT ** k), 2) for k in range(1, 17))
chk('bit', okWD and okAdd and okInj and okOrd and okUn, 'ns.LIM: for the chains of GEN-019 and of the null cells (%d chains, %d kinds (s, m_0)), G = lim (Z^s, %d I) as classes of pairs (k, v) with (k, v) ~ (k + 1, %d v), exact integers: the group law and the cone (v >= 0 at some stage) are well defined; iota(k, v) = v / %d^k is well defined, additive, injective (x ~ y exactly when iota(x) = iota(y)) and positive exactly on the cone (%d sampled pairs); the unit [(0, m_0 (1, ..., 1))] is the class of every stage unit 16^k m_0 (1, ..., 1) computed in ns.STG and ns.P3, and goes to (1, ..., 1) under x -> x / m_0, an order automorphism (m_0 a power of 2)' % (sum(len(v) for v in LIM.values()), len(LIM), MULT, MULT, MULT, nsamp))
chk('bit', okImg and okHalf, 'ns.LIM: the image of iota is Z[1/%d]^s (every a / %d^j reached), and Z[1/%d] = Z[1/2] as subgroups of Q: every 2^-j (j <= 64) is a / %d^k for an integer a (1/2 = 8/16), and 1/%d^k is in Z[1/2]: G is isomorphic to Z[1/2]^s with its non-negative cone, as an ordered group with unit (1, ..., 1)' % (MULT, MULT, MULT, MULT, MULT))
# the M256 chain (every second step) and the CAR chain (x 2), and the chain with the swap at every step
G16, G256, G2 = DimGroup([[16]]), DimGroup([[256]]), DimGroup([[2]]); okTh = True
for _ in range(300):
    x, y = rnd_el(1), rnd_el(1); th = lambda z: (2 * z[0], z[1]); ca = lambda z: (4 * z[0], z[1])
    okTh &= iota(256, x) == iota(16, th(x)) and G256.eq(x, y) == G16.eq(th(x), th(y)) and G16.eq(th(G256.add(x, y)), G16.add(th(x), th(y)))
    okTh &= G256.pos(x) == G16.pos(th(x)) and iota(16, x) == iota(2, ca(x)) and G16.eq(x, y) == G2.eq(ca(x), ca(y)) and G16.pos(x) == G2.pos(ca(x))
    z = rnd_el(1); z2 = z if z[0] % 2 == 0 else (z[0] + 1, (16 * z[1][0],)); okTh &= G16.eq(z, z2) and G16.eq(th((z2[0] // 2, z2[1])), z)   # onto
okTh &= all(in_Z_over(Fr(1, 2 ** j), 256) for j in range(1, 65)) and G2.eq((5, (32,)), (0, (1,)))
GS, GI = DimGroup([[0, 16], [16, 0]]), DimGroup([[16, 0], [0, 16]]); okSw = True
psi = lambda x: (x[0], tuple(x[1][::-1]) if x[0] % 2 else tuple(x[1]))      # psi_k = sigma^k
for _ in range(300):
    x, y = rnd_el(2), rnd_el(2); j = RNG.randrange(1, 4)
    okSw &= GI.eq(psi(x), psi((x[0] + j, GS.at(x, x[0] + j)))) and GS.eq(x, y) == GI.eq(psi(x), psi(y)) and GI.eq(psi(GS.add(x, y)), GI.add(psi(x), psi(y)))
    okSw &= GS.pos(x) == GI.pos(psi(x)) and iota(16, x, swap=True) == iota(16, psi(x))
okSw &= psi((0, (1, 1))) == (0, (1, 1)) and all(GS.eq((k, (16 ** k, 16 ** k)), (0, (1, 1))) for k in range(6))
chk('bit', okTh and okSw, 'ns.LIM: the M256 chain (256 I) has the image Z[1/256]^s = Z[1/2]^s and (k, v) -> (2k, v) is an isomorphism of its limit onto the M16 limit with cone and unit (the chain read every second step, GEN-014); the CAR chain (2 I, unit 1) is the M16 chain from (0,0) read through (k, v) -> (4k, v): one ordered group with unit, Z[1/2] with 1 (Glimm\'s 2^inf = 16^inf, cited, on the finite side); for s = 2 the chain with the swap at every step (16 sigma) has a limit isomorphic to lim (Z^2, 16 I) as an ordered group with unit by psi_k = sigma^k (compatible with the steps, additive, bijective, positive, (1,1) fixed): the summands kept or swapped give the same ordered group with unit')
# the standard route: numpy integers on the Bratteli diagram's incidence matrices (the matrix route's own multiplicities, ns.STD)
okLs = okLbs = True; nls = 0
for (c0, b), (L0, L1, Mstd, u0) in STDM.items():
    L0s, L1s = sorted(L0), sorted(L1)                                       # the summands in one order, '+' (omega = +1) first
    E = np.array([[int(Mstd[(i_, j_)]) for j_ in L0s] for i_ in L1s], dtype=np.int64); s_ = len(L0); m0 = int(u0[L0s[0]])
    okLs &= E.shape == (s_, s_) and np.array_equal(E, 16 * np.eye(s_, dtype=np.int64))
    Gx = DimGroup(E.tolist())
    def at_np(x, K): return np.linalg.matrix_power(E, K - x[0]) @ np.array(x[1], dtype=np.int64)
    for _ in range(40):
        x, y = rnd_el(s_), rnd_el(s_); K = 8
        eq_np = np.array_equal(at_np(x, K), at_np(y, K)); pos_np = bool(np.all(at_np(x, K) >= 0))
        sm = at_np(x, K) + at_np(y, K); okLbs &= eq_np == Gx.eq(x, y) and pos_np == Gx.pos(x) and tuple(int(a) for a in sm) == Gx.at(Gx.add(x, y), K)
        okLbs &= all(Fr(int(a), 16 ** K) == b_ for a, b_ in zip(at_np(x, K), iota(16, x)))
    okLbs &= np.array_equal(at_np((0, (m0,) * s_), 4), np.array([m0 * 16 ** 4] * s_)); nls += 1
chk('std', okLs, 'ns.LIM: numpy integers, no label: the Bratteli diagram of each of the %d chains from the start cells n <= 4 with the incidence matrix of the matrix route (ns.STD: 16 on the diagonal, numpy ranks), its powers by integer matrix multiplication, the classes compared at a common stage, the cone by signs at that stage' % nls)
chk('bit==std', okLbs, 'ns.LIM: on 40 sampled pairs per chain the numpy route and the exact route agree on equality, sums, positivity and the values in Q^s (v 16^(K-k) / 16^K), and on the image of the unit, for the %d chains' % nls)
# with the unit: the order automorphisms of Z[1/2], and what the unit reads
okAut = True; units2 = []
for _ in range(200):                                                         # an automorphism phi of Z[1/2] is x -> phi(1) x: 2^k phi(a/2^k) = a phi(1)
    a_, k_ = RNG.randint(-99, 99), RNG.randrange(8); c_ = Fr(RNG.randint(1, 99), 2 ** RNG.randrange(6)); okAut &= (2 ** k_) * (c_ * Fr(a_, 2 ** k_)) == a_ * c_
for a_ in range(1, 100):
    for k_ in range(7):
        c_ = Fr(a_, 2 ** k_)
        if in_Z_over(1 / c_, 2, 12): units2.append(c_)                          # x -> c x onto Z[1/2] exactly when 1/c is in Z[1/2]
okAut &= sorted(set(units2)) == sorted({Fr(2 ** i, 2 ** k_) for i in range(7) for k_ in range(7) if 2 ** i <= 99})
okU1 = all(iso_unit((m0,) * s_, (1,) * s_) for (s_, m0) in LIM) and not iso_unit((1,), (3,)) and iso_unit((1,), (16,)) and not iso_unit((1,), (1, 1))
cls = {}
for (s_, m0), lst in LIM.items():
    for (c0, b), X in lst: cls.setdefault(s_, set()).add((X['TY'][0][0], c0[2] > 0, b))
chk('bit', okAut and okU1, 'ns.LIM: with the unit: an order automorphism of Z[1/2] is x -> c x with c = phi(1) a positive unit of the ring Z[1/2], c = 2^j (the c = a/2^k with a < 100, k <= 6 that map Z[1/2] onto itself are exactly the powers of 2); so (Z[1/2], 1) and (Z[1/2], 3) are one ordered group and not isomorphic with unit; every unit of the Atlas\'s chains is m_0 (1, ..., 1) with m_0 a power of 2 (%s), isomorphic to (1, ..., 1): the chains are told apart by s alone, Z[1/2] (s = 1: D in %s, null and non-null start cells, the three blocks) or Z[1/2]^2 (s = 2)' % (sorted({m0 for (_, m0) in LIM}), sorted({d_ for d_, _, _ in cls.get(1, set())})))
okM3 = not in_Z_over(Fr(1, 2), 3, 64) and all((3 ** k) % 2 == 1 for k in range(65)); nv = 0
for _ in range(200):                                                         # no non-zero element of Z[1/3] is divisible by every 2^j
    k_, a_ = RNG.randrange(6), RNG.choice([x for x in range(-99, 100) if x]); v2 = (a_ & -a_).bit_length() - 1
    okM3 &= all(((3 ** i * a_) & -(3 ** i * a_)).bit_length() - 1 == v2 for i in range(6))
    okM3 &= not in_Z_over(Fr(a_, 3 ** k_ * 2 ** (v2 + 1)), 3, 64); nv += 1
okM3 &= all(in_Z_over(Fr(1, 2 ** j), 2) for j in range(65))
chk('ctl', okM3, 'ns.LIM: MULT3, a chain with multiplicity 3: its limit is Z[1/3]^s, which does not contain 1/2 (3^k is odd for every k <= 64), and is not isomorphic to Z[1/2]^s even as a group: the 2-adic valuation of the numerator of x = a/3^k is the same at every stage, so x/2^(v+1) is not in Z[1/3] (%d sampled elements), while 1 is divisible in Z[1/2] by every 2^j' % nv)
okFU = all(in_Z_over(Fr(1, b1), b2) and in_Z_over(Fr(1, b2), b1) for b1 in (2, 4, 16, 256) for b2 in (2, 4, 16, 256))
chk('ctl', okFU, 'ns.LIM: the unit forgotten: Z[1/2] = Z[1/4] = Z[1/16] = Z[1/256] as subgroups of Q (each contains the generator 1/b of the others) with one cone, so the chains of multiplicity 2, 4, 16 and 256 are one ordered group; without the unit (stable isomorphism, Elliott, cited) (Z[1/2], 1) and (Z[1/2], 3) are one too: the unit is what tells M_(2^inf) from M_3 (x) M_(2^inf), and the Atlas\'s chains never reach a unit with an odd factor')
okC = True; nc = 0
for p, q in PQ:                                                              # the stages are real: dim Z of the quotient and the complexification
    e = sig(p, q); a = np.arange(1 << (p + q), dtype=np.int64); cen = np.ones(1 << (p + q), dtype=bool)
    for i in range(p + q): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
    dz = int(cen.sum()); D, m, s_ = clock_type(p, q); okC &= dz == (2 if (p + q) % 2 else 1) and dz == (2 if D == 'C' else s_)
    if D == 'C':
        for b in BLOCKS:
            om_ = (1 << (p + q)) - 1; K1 = BR(e + sig(*b)); okC &= phi_blade(K1, p + q, (1, om_)) == (1, ((1 << (p + q + 8)) - 1)) and K1.s(om_, om_) == -1
    nc += 1
chk('bit', okC, 'ns.LIM: the stages are real algebras: the centre of Cl(p,q) (its central blades, %d cells p + q <= 8) has dimension 2 exactly when p + q is odd, so the complexification C (x) Cl(p,q) has dim Z simple summands: also 2 at the clocks 3 and 7 (D = C, s = 1 over R), where the central omega (omega^2 = -1) goes to +omega of the next stage (each block): the two complex summands are kept, and the complexified chains have the ordered group Z[1/2]^(dim Z), not the real Z[1/2]^s; Elliott\'s classification of AF algebras by (K_0, K_0+, [1]) and Glimm\'s of UHF algebras by the supernatural number are stated for complex C*-algebras and are set beside this, cited, not taken for it' % nc)
note('not computed: the C*-completion of either chain; that the completed limits are classified by these ordered groups with unit is Elliott\'s theorem (complex AF algebras) and Glimm\'s (UHF, the supernatural number 2^inf), cited; a classification of real AF algebras; the topological side of the classes; which split nature uses (INP-011)')
note('(%.1f s, total %.1f s)' % (time.time() - t, time.time() - T0))
finish('NULL-STAGES')
