#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""period_map.py: the periodicity map on every cell with n <= 8, the ABS classes at n + 8 from minimal left ideals, and the dimension
group of the chain of blocks on its finite stages (round 11, proofs pass 9b; docs/round11/PLAN.md, docs/round11/pass9b/BEFORE.md).
     python3 period_map.py [--fault OMEGAFIRST|NOOMEGA|NOSWAP|UNGRADED|PLAINTENSOR|CLOCK2|MULT8]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q,r) has its p generators
of square +1 first, then q of square -1, then r null (core_check.sig); the type table is core_check.TYPE (by c = p - q mod 8).  The three
clock-0 blocks of row 8 are (8,0,0), (0,8,0), (4,4,0) (GEN-009); a block is placed after the generators it multiplies (the next eight bits).
pm.MAP  e_i' = e_i Omega (Omega the top blade of the block) for every cell (p,q,r) with 5 <= n <= 8 (130 cells) and each block (390 cases):
       the relations of Cl(p,q,r) (n^2 products), commutation with the block (8n products), and the 2^n x 256 products e'_S f_T are non-zero
       and cover each of the 2^(n+8) labels once (the vectorised kernel formula, equal to BR.s on samples); the sign of e'_S and of
       e'_S f_T against the canonical blade as a formula, checked on every pair.  [std] monomial Kronecker matrices (X, J, X + J with Z
       strings, the blocks as 16 x 16 real matrices; no label): gamma_i x Omega and 1 x g_j satisfy the relations of Cl(n+8), e_i Omega is
       gamma_i x 1, the words are independent; [bit==std] the sign of e'_S f_T against the matrices on samples.  [ctl] OMEGAFIRST (f_j omega_n)
       and NOOMEGA (e_i' = e_i).
pm.ABS the ABS classes from minimal left ideals (abs_ring.py's method: idempotents prod (1 + e_a)/2 over a maximal set of commuting labels of
       square +1, the module on the cosets of their span as signed permutations, irreducibility from the exact commutant, the two
       irreducibles of a two-summand cell told apart by the central volume element, multiplicities from the trace of the volume element,
       integer Smith normal form).  For the 45 cells (p,q,0), n <= 8: A(p,q) = coker(N(Cl(p+1,q+1)) -> N(Cl(p+1,q))), the grading the first
       generator, the last generator dropped; at n + 8 the same with each block concatenated (cells up to 18 generators, 2^18 labels, modules
       up to dimension 512, never 2^18 x 2^18 matrices); the class of V at n goes to the class of V (x)^ beta (beta the block's 16-dimensional
       module graded by Omega, abs_ring.py's gtensor) and of the module of the explicit map (V x Omega, 1 x f_j); the square with the
       restrictions commutes, the induced map on the cokernels is an isomorphism.  abs_ring.py's build_cell (copied) and solid_cube.py's
       commutant are the reference on the 54 base cells; the vectorised construction equals them there.  Against cb.ST (the types and the
       swap, copied) and abs.R1 (A_k along (1,k), logged).  [std] numpy eigenspaces of a random symmetric commutant element (abs.S) for
       p + q <= 5, the block as 16 x 16 Kronecker matrices beyond.  [ctl] NOSWAP, UNGRADED (as abs_ring.py), PLAINTENSOR (no Koszul twist).
pm.DG  the dimension group on the finite stages.  Chains C_0 in C_1 in C_2, C_(k+1) = C_k (x) M16(R) by e_i -> e_i Omega, one block repeated,
       from the 15 cells (p,q,0) with n <= 4 and the three row-8 cells (54 chains, stages n, n + 8, n + 16): s (minimal central idempotents),
       the type, a minimal idempotent of each summand (the image of the stage before times a primitive idempotent of the new block), the
       dimension of its left ideal tr L_P = 2^N x scalar part, the order unit, the multiplicity matrices of the inclusions and the sign of
       the image of the central volume element (kept or swapped); the composite of two steps against the one-step map of the M256(R)
       chain.  At n + 16 <= 20 the centre and the count by enumerating the labels; at 24 by the parity reduction and the graded diagonal
       of pass 8c (equal to the enumeration at 16..20, to BR on samples).  [std] numpy for the stages 0 and 1 of the start cells n <= 2.
       [ctl] CLOCK2 (the block (5,3,0)); MULT8 (x 8 asserted) as a fault.
pm.CAR the CAR chain Cl(j,j) in Cl(j+1,j+1) (GEN-015): s = 1, the vacuum a minimal idempotent, multiplicity 2, its decomposition into two
       orthogonal minimal idempotents; [std] Jordan-Wigner matrices and numpy ranks.
Not computed here (stated, not checked): the limit of either chain and its completion; Elliott's classification of AF algebras by the dimension
group and Glimm's of UHF algebras by the supernatural number (2^inf), stated for complex C*-algebras, cited; which split nature uses.
--fault options (each a wrong version in the main lines, which must then FAIL; exit 1): OMEGAFIRST f_j omega_n for every cell; NOOMEGA
   e_i' = e_i; NOSWAP the two irreducibles of a two-summand cell kept by the dropped generator; UNGRADED the grading dropped; PLAINTENSOR the
   block's module tensored without the Koszul twist; CLOCK2 the chains with the block (5,3,0); MULT8 the multiplicity 8 asserted.
Command: python3 -I -B selfcheck/proofs/period_map.py from checks/ (or from this folder); standard library and numpy."""
import os, sys, io, time, random, itertools, contextlib
from fractions import Fraction as Fr
from math import comb, gcd, isqrt
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
_steps = os.path.join(_selfcheck, 'steps15_17')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py'), (_steps, 'bitcliff.py'), (_here, 'solid_cube.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck, _steps, _here):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR, anticomm
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps
from bitcliff import Alg                                                   # abs_ring.py's engine for its build_cell (copied below)
_argv = sys.argv; sys.argv = [_argv[0]]
try:
    with contextlib.redirect_stdout(io.StringIO()):
        from solid_cube import commutant_basis, classify                  # the exact commutant abs_ring.py uses (the reference)
finally:
    sys.argv = _argv

# ------------------------------------------------------------------------------------------------ check lines (as chain_blocks.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish(name):
    tags = ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT))
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), tags, len(FAILS)))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    print('period_map: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('OMEGAFIRST', 'NOOMEGA', 'NOSWAP', 'UNGRADED', 'PLAINTENSOR', 'CLOCK2', 'MULT8')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(20261016); NPR = np.random.default_rng(20261016)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
def cells(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]
def cstr(c): return '(%s)' % ','.join(str(x) for x in c)
def clock(c): return (c[0] - c[1]) % 8
pc = lambda x: bin(x).count('1')
BLOCKS = [(8, 0, 0), (0, 8, 0), (4, 4, 0)]                                 # the three clock-0 cells of row 8 (GEN-009)

# ------------------------------------------------------------------------------------------------ the kernel's formula, vectorised (chain_blocks.py)
def popv(x): return np.bitwise_count(x).astype(np.int64)
def emask(eps):
    """E[m] = product of eps_i over the bits of m, for every mask m < 2^N"""
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    """BR.s(a, b) for arrays of labels: (-1)^(#(i in a, j in b, j < i)) * prod_(i in a & b) eps_i"""
    eps = tuple(eps)
    if eps not in _EM: _EM[eps] = emask(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)):
        par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    return (1 - 2 * (par & 1)) * _EM[eps][A & B]

# ------------------------------------------------------------------------------------------------ types from invariants (chain_blocks.py)
DD = {'R': 1, 'C': 2, 'H': 4}
def type_from_inv(dim, c, cplx, fs):
    """c copies of M_m(D) from: the dimension, the number c of simple summands, whether the centre is complex, and the Frobenius-Schur count
    fs (the signature of the trace form: c m for D = R, 0 for C, -2 c m for H); None when the data are inconsistent"""
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D])
    m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
_LT = {}
def ltype_eps(eps):
    """the type of a non-degenerate cell (every eps_i = +-1, in any order) from its labels: the count sum of s(a,a) by the vectorised kernel
    formula; the central blades by the reordering counts of a against each generator; their squares (chain_blocks.py)"""
    eps = tuple(eps)
    if eps not in _LT:
        n = len(eps); a = np.arange(1 << n, dtype=np.int64); d = s_vec(eps, a, a); cen = np.ones(1 << n, dtype=bool)
        for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
        Z = np.flatnonzero(cen); cplx = bool(np.any(d[Z] == -1))
        _LT[eps] = type_from_inv(1 << n, len(Z) // 2 if cplx else len(Z), cplx, int(d.sum()))
    return _LT[eps]
def clock_type(p, q):
    """the type of Cl(p,q) from the Atlas's type table core_check.TYPE and the dimension 2^(p+q) (chain_blocks.py)"""
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2)
    assert r == 0 and m * m == m2
    return (D, m, c)

# ================================================================================================ pm.MAP  the explicit map on every cell 5 <= n <= 8
head('pm.MAP  e_i -> e_i Omega on every cell with 5 <= n <= 8 (GEN-013 completed): relations, commutation, the bijection on the labels, the sign')
t = time.time()
CELLS58 = [c for n in range(5, 9) for c in cells(n)]                      # 21 + 28 + 36 + 45 = 130 cells
TT = np.arange(256, dtype=np.int64)
TSUM = sum(((TT >> k) & 1) * k for k in range(8))                         # the sum of the block-local bit positions of T
okO = okRel = okCom = okNZ = okBij = okE = okF = okSmp = okAlt = True; nrel = ncom = nlab = ncase = nsmp = 0
alt = {'works': 0, 'odd n': 0, 'null': 0, 'mirror': 0}; plain_comm = 0
for c in CELLS58:
    n = sum(c); ec = sig(*c)
    for b in BLOCKS:
        eb = sig(*b); eps = ec + eb; N = n + 8; Om = 255 << n
        gi = np.array([1 << i for i in range(n)], dtype=np.int64); fl = np.array([1 << (n + j) for j in range(8)], dtype=np.int64)
        okO &= int(s_vec(eps, Om, Om)) == 1 and np.array_equal(s_vec(eps, Om, fl), -s_vec(eps, fl, Om)) and np.array_equal(s_vec(eps, Om, gi), s_vec(eps, gi, Om))
        # the brief's other form g_j = f_j omega_n (pass 8c: works only for even n without null generators)
        om = (1 << n) - 1; w2 = int(s_vec(eps, om, om)); gl = fl ^ om
        comm_ok = np.array_equal(s_vec(eps, gl[:, None], gi[None, :]), s_vec(eps, gi[None, :], gl[:, None]))
        G1 = s_vec(eps, gl[:, None], gl[None, :]); offd = ~np.eye(8, dtype=bool)
        rel_ok = bool(np.all((G1 == -G1.T)[offd])) and np.array_equal(np.diag(G1), w2 * np.array(eb))
        cat = 'works' if (comm_ok and rel_ok and w2 != 0) else ('null' if w2 == 0 else ('odd n' if n % 2 else 'other'))
        alt[cat] = alt.get(cat, 0) + 1; alt['mirror'] += cat == 'works' and w2 == -1
        alt_ok = cat == ('null' if c[2] else ('odd n' if n % 2 else 'works'))
        okAlt &= alt_ok
        plain_comm += int(np.array_equal(s_vec(eps, gi[:, None], fl[None, :]), s_vec(eps, fl[None, :], gi[:, None])))
        ncase += 1
        if FAULT == 'OMEGAFIRST':                                          # the other form taken for every cell
            okRel &= comm_ok and rel_ok and w2 != 0; continue
        if FAULT == 'NOOMEGA': el, es = gi.copy(), np.ones(n, dtype=np.int64)
        else: el, es = gi ^ Om, s_vec(eps, gi, Om)                         # e_i' = e_i Omega as a signed blade
        S1 = es[:, None] * es[None, :] * s_vec(eps, el[:, None], el[None, :])
        okRel &= bool(np.all((S1 == -S1.T)[~np.eye(n, dtype=bool)])) and np.array_equal(np.diag(S1), np.array(ec)); nrel += n * n
        C1 = es[:, None] * s_vec(eps, el[:, None], fl[None, :]); C2 = es[:, None] * s_vec(eps, fl[None, :], el[:, None])
        okCom &= np.array_equal(C1, C2) and bool(np.all(C1 != 0)); ncom += 8 * n
        wl = np.zeros(1 << n, dtype=np.int64); ws = np.ones(1 << n, dtype=np.int64)    # e'_S, the product in increasing order
        for i in range(n):
            lo = np.arange(1 << i); wl[lo | (1 << i)] = wl[lo] ^ el[i]; ws[lo | (1 << i)] = ws[lo] * es[i] * s_vec(eps, wl[lo], el[i])
        L = wl[:, None] ^ (TT[None, :] << n); SG = ws[:, None] * s_vec(eps, wl[:, None], (TT << n)[None, :])
        okNZ &= bool(np.all(SG != 0)); okBij &= bool(np.all(np.bincount(L.ravel(), minlength=1 << N) == 1)); nlab += 1 << N
        S_ = np.arange(1 << n, dtype=np.int64); odd = popv(S_) & 1
        okE &= np.array_equal(wl, S_ ^ (odd * Om)) and bool(np.all(ws == 1))
        sodd = (1 - 2 * ((popv(TT) + TSUM) & 1)) * emask(eb)[TT]              # (-1)^(|T| + sum t) eta_T
        okF &= np.array_equal(L, S_[:, None] | ((TT[None, :] ^ (odd[:, None] * 255)) << n)) and np.array_equal(SG, np.where(odd[:, None] == 1, sodd[None, :], 1))
        K = BR(eps)
        for _ in range(6):
            x, y = RNG.randrange(1 << N), RNG.randrange(1 << N); okSmp &= int(s_vec(eps, x, y)) == K.s(x, y); nsmp += 1
chk('bit', okO and okRel and okCom and okSmp, 'pm.MAP: for the %d cases (the 130 cells (p,q,r) with 5 <= n <= 8, null generators included, each with the blocks (8,0,0), (0,8,0), (4,4,0) as the next eight bits): Omega squares to +1, anticommutes with the block and commutes with the first n generators; e_i\' = e_i Omega satisfy the relations of Cl(p,q,r) (%d products e\'_i e\'_j) and commute with the eight generators of the block (%d products); the vectorised kernel formula equals BR.s on %d sampled entries' % (ncase, nrel, ncom, nsmp))
chk('bit', okNZ and okBij, 'pm.MAP: in every case the 2^n x 256 products e\'_S f_T are non-zero blades up to sign and each of the 2^(n+8) labels occurs exactly once (%d labels; 65536 per case at n = 8): x (x) y -> phi(x) y is a bijection on the labels, Cl(p,q,r) (x) M16(R) = Cl(n+8) for every cell with n <= 8' % nlab)
chk('bit', okE and okF, 'pm.MAP: the sign, on every S and T of the 390 cases: e\'_S = +e_(S xor [|S| odd] Omega) (sign +1: Omega commutes with the e_i, squares to +1 and its bits lie above S); e\'_S f_T = sigma e_(S + 2^n (T xor [|S| odd] 255)) with sigma = 1 for |S| even and sigma = (-1)^(|T| + sum_(t in T) t) eta_T for |S| odd (t the block-local index 0..7, eta_T the product of the squares of the block generators in T)')
chk('ctl', okAlt and alt['works'] + alt['odd n'] + alt['null'] == 390, 'pm.MAP: the other form, f_j omega_n (OMEGAFIRST), commutes with the first block and satisfies the block\'s relations in %d of the 390 cases, exactly n even without null generators (%d of them with omega_n^2 = -1, the mirrored block); it anticommutes for odd n (%d) and omega_n is nilpotent with a null generator (%d), as pass 8c found for n <= 4' % (alt['works'], alt['mirror'], alt['odd n'], alt['null']))
chk('ctl', plain_comm == 0, 'pm.MAP: without Omega (NOOMEGA, e_i\' = e_i) the first n generators commute with the block in %d of the 390 cases: each e_i anticommutes with each f_j' % plain_comm)
note('(%.1f s)' % (time.time() - t))

# ------------------------------------------------------------------------------------------------ the standard route: monomial Kronecker matrices, no label
XM = np.array([[0, 1], [1, 0]], dtype=np.int64); JM = np.array([[0, -1], [1, 0]], dtype=np.int64); ZM = np.diag([1, -1]).astype(np.int64)
I2 = np.eye(2, dtype=np.int64)
def kron_all(ms):
    M = np.ones((1, 1), dtype=np.int64)
    for m in ms: M = np.kron(M, m)
    return M
def site_gens(eps):
    """one generator per site: Z on the sites before it, X (square +1), J (square -1) or X + J (square 0) on its own; no label (chain_blocks.py)"""
    n = len(eps)
    return [kron_all([ZM] * k + [{1: XM, -1: JM, 0: XM + JM}[e]] + [I2] * (n - k - 1)) for k, e in enumerate(eps)]
def block_mats(c8):
    """the blocks as real 16 x 16 Kronecker matrices, no label (chain_blocks.py): Cl(4,4) from X and J on four sites; Cl(8,0) and Cl(0,8) by the
    four-shift (f_j w with w = f_1 f_2 f_3 f_4, resp. e_i w' with w' = e_1 e_2 e_3 e_4); the clock-2 cell Cl(5,3) by Cl(p,q) = Cl(q+1,p-1)"""
    E = [kron_all([ZM] * k + [XM] + [I2] * (3 - k)) for k in range(4)]; F = [kron_all([ZM] * k + [JM] + [I2] * (3 - k)) for k in range(4)]
    if c8 == (4, 4, 0): return E + F
    if c8 == (8, 0, 0): w = F[0] @ F[1] @ F[2] @ F[3]; return E + [f @ w for f in F]
    if c8 == (0, 8, 0): w = E[0] @ E[1] @ E[2] @ E[3]; return [e @ w for e in E] + F
    return [E[0]] + [E[0] @ f for f in F] + [E[0] @ e for e in E[1:]]           # (5,3,0)
def to_mono(M):
    """a matrix with at most one non-zero entry per column as (rows, values): X, J, X + J, Z and their Kronecker products are of this kind"""
    nz = M != 0; assert bool(np.all(nz.sum(0) <= 1))
    r = np.argmax(nz, axis=0).astype(np.int64); return r, M[r, np.arange(M.shape[1])].astype(np.int64)
def m_mul(A, B): return A[0][B[0]], A[1][B[0]] * B[1]
def m_kron(A, B): m = len(B[0]); return (A[0][:, None] * m + B[0][None, :]).ravel(), (A[1][:, None] * B[1][None, :]).ravel()
def m_eye(d): return np.arange(d, dtype=np.int64), np.ones(d, dtype=np.int64)
def m_eq(A, B): return np.array_equal(A[1], B[1]) and bool(np.all((A[0] == B[0]) | (A[1] == 0)))
def m_anti(A, B, target):
    """A B + B A == target x identity for two monomial matrices (exact integers)"""
    r1, v1 = m_mul(A, B); r2, v2 = m_mul(B, A); c_ = np.arange(len(r1))
    at_c = np.where(r1 == c_, v1, 0) + np.where(r2 == c_, v2, 0)
    off = np.where(r1 == r2, (r1 == c_) | (v1 + v2 == 0), (np.where(r1 != c_, v1, 0) == 0) & (np.where(r2 != c_, v2, 0) == 0))
    return bool(np.all(at_c == target) and np.all(off))
def mmul(A, x, y): return (x[0] * y[0] * A.s(x[1], y[1]), x[1] ^ y[1])     # signed blades (sign, label) with the kernel (chain_blocks.py)
t = time.time()
RANKB = {}
for b in BLOCKS:
    Gb = block_mats(b); W = [np.eye(16, dtype=np.int64)]
    for a in range(1, 256):
        top = a.bit_length() - 1; W.append(W[a ^ (1 << top)] @ Gb[top])
    Ob = Gb[0]
    for g in Gb[1:]: Ob = Ob @ g
    RANKB[b] = (int(np.linalg.matrix_rank(np.array(W).reshape(256, -1).astype(float))), int(np.linalg.matrix_rank(np.array([Ob @ w for w in W]).reshape(256, -1).astype(float))))
okRelM = okPhi = okInd = okBS = True; nbs = 0; dmax = 0
for c in CELLS58:
    n = sum(c); ec = sig(*c); gam = [to_mono(g) for g in site_gens(ec)]; d0 = 1 << n; I0 = m_eye(d0); I16 = m_eye(16)
    rows = []; ok0 = True                                                  # gamma_S |0..0>: one non-zero entry, a different row for each S
    for S in range(d0):
        r_, v_ = 0, 1
        for i in reversed(range(n)):
            if S >> i & 1: r_, v_ = int(gam[i][0][r_]), v_ * int(gam[i][1][r_])
        ok0 &= v_ != 0; rows.append(r_)
    okInd &= ok0 and len(set(rows)) == d0
    for b in BLOCKS:
        eb = sig(*b); eps = ec + eb; Gb = [to_mono(g) for g in block_mats(b)]; Ob = Gb[0]
        for g in Gb[1:]: Ob = m_mul(Ob, g)
        G = [m_kron(g, Ob) for g in gam] + [m_kron(I0, g) for g in Gb]; OmI = m_kron(I0, Ob); dmax = max(dmax, d0 * 16)
        okRelM &= m_eq(m_mul(Ob, Ob), I16) and all(m_anti(G[i], G[j], 2 * eps[i] if i == j else 0) for i in range(n + 8) for j in range(i, n + 8))
        PH = [m_mul(G[i], OmI) for i in range(n)]                          # the image of e_i Omega
        okPhi &= all(m_eq(PH[i], m_kron(gam[i], I16)) for i in range(n))
        K = BR(eps); Om = 255 << n
        for _ in range(8):                                                 # bit==std on samples: e'_S f_T against its label's canonical word
            S, T = RNG.randrange(d0), RNG.randrange(256); x = (1, 0); M1 = m_eye(d0 * 16)
            for i in range(n):
                if S >> i & 1: x = mmul(K, x, (K.s(1 << i, Om), (1 << i) ^ Om)); M1 = m_mul(M1, PH[i])
            for j in range(8):
                if T >> j & 1: x = mmul(K, x, (1, 1 << (n + j))); M1 = m_mul(M1, G[n + j])
            M2 = m_eye(d0 * 16)
            for k in range(n + 8):
                if x[1] >> k & 1: M2 = m_mul(M2, G[k])
            okBS &= x[0] != 0 and m_eq(M1, (M2[0], M2[1] * x[0])); nbs += 1
chk('std', all(RANKB[b] == (256, 256) for b in BLOCKS) and okRelM and okPhi, 'pm.MAP: monomial Kronecker matrices, no label (X, J, X + J with Z strings; the blocks as 16 x 16 real matrices, their 256 words of rank 256): for the 390 cases gamma_i x Omega and 1 x g_j (matrices up to %d x %d, exact integers) satisfy all (n+8)^2 relations of Cl(n+8), Omega^2 = 1, and the image of e_i Omega is gamma_i x 1' % (dmax, dmax))
chk('std', okInd, 'pm.MAP: the 2^n words of gamma send |0..0> to multiples of distinct basis vectors for each of the 130 cells, and the 256 words of each block have rank 256 (also times Omega): the 2^(n+8) words of the representation are independent on |0..0> (x) R^16, so it is faithful and Cl(n+8) = Cl(n) (x) M16(R) as matrices')
chk('bit==std', okBS, 'pm.MAP: on %d sampled pairs (S,T), 8 per case: the matrix of e\'_S f_T (the images of e_i Omega times the block\'s matrices) equals sigma times the matrix of the canonical blade of its label, sigma and the label computed with BR' % nbs)
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ pm.ABS  the ABS classes from minimal left ideals
# ------------------------------------------------------------------------------------------------ exact integer linear algebra (abs_ring.py)
def group_name(free, tors):
    parts = ['Z'] * free + ['Z%d' % d for d in tors]
    return '+'.join(parts) if parts else '0'
def smith(A):
    """integer Smith normal form: (invariant factors, U) with U A V diagonal; A by its rows (abs_ring.py)"""
    A = [[int(x) for x in r] for r in A]; r = len(A); c = len(A[0]) if r else 0
    U = [[int(i == j) for j in range(r)] for i in range(r)]
    diag = []; t_ = 0
    def swap_rows(i, j): A[i], A[j] = A[j], A[i]; U[i], U[j] = U[j], U[i]
    def swap_cols(i, j):
        for row in A: row[i], row[j] = row[j], row[i]
    while t_ < min(r, c):
        nz = [(abs(A[i][j]), i, j) for i in range(t_, r) for j in range(t_, c) if A[i][j]]
        if not nz: break
        _, i, j = min(nz); swap_rows(t_, i); swap_cols(t_, j)
        while True:
            changed = False
            for i in range(t_ + 1, r):
                if A[i][t_]:
                    qq = A[i][t_] // A[t_][t_]
                    A[i] = [a - qq * b for a, b in zip(A[i], A[t_])]; U[i] = [a - qq * b for a, b in zip(U[i], U[t_])]
                    if A[i][t_]: swap_rows(t_, i); changed = True
            for j in range(t_ + 1, c):
                if A[t_][j]:
                    qq = A[t_][j] // A[t_][t_]
                    for row in A: row[j] -= qq * row[t_]
                    if A[t_][j]: swap_cols(t_, j); changed = True
            if changed: continue
            bad = [(i, j) for i in range(t_ + 1, r) for j in range(t_ + 1, c) if A[i][j] % A[t_][t_]]
            if not bad: break
            i = bad[0][0]; A[t_] = [a + b for a, b in zip(A[t_], A[i])]; U[t_] = [a + b for a, b in zip(U[t_], U[i])]
        if A[t_][t_] < 0: A[t_] = [-a for a in A[t_]]; U[t_] = [-a for a in U[t_]]
        diag.append(A[t_][t_]); t_ += 1
    return diag, U
def coker(M):
    diag, U = smith(M)
    return group_name(len(M) - len(diag), [d for d in diag if d > 1]), (diag, U)
def coker_class(cdata, v):
    diag, U = cdata; w = [sum(a * b for a, b in zip(row, v)) for row in U]
    return tuple([w[i] % diag[i] for i in range(len(diag)) if diag[i] > 1] + w[len(diag):])
def coker_divisors(M):
    """the cokernel by determinantal divisors (abs_ring.py's standard route)"""
    def det(Mx):
        Mx = [[Fr(x) for x in r] for r in Mx]; n = len(Mx); dt = Fr(1)
        for c_ in range(n):
            piv = next((i for i in range(c_, n) if Mx[i][c_] != 0), None)
            if piv is None: return 0
            if piv != c_: Mx[c_], Mx[piv] = Mx[piv], Mx[c_]; dt = -dt
            dt *= Mx[c_][c_]
            for i in range(c_ + 1, n):
                f = Mx[i][c_] / Mx[c_][c_]; Mx[i] = [a - f * b for a, b in zip(Mx[i], Mx[c_])]
        return int(dt)
    r = len(M); c = len(M[0]) if r else 0; ds = [1]
    for k in range(1, min(r, c) + 1):
        g = 0
        for rows in itertools.combinations(range(r), k):
            for cols in itertools.combinations(range(c), k): g = gcd(g, abs(det([[M[i][j] for j in cols] for i in rows])))
        if g == 0: break
        ds.append(g)
    inv = [ds[k] // ds[k - 1] for k in range(1, len(ds))]
    return group_name(r - len(inv), [e for e in inv if e > 1])

# ------------------------------------------------------------------------------------------------ abs_ring.py's build_cell (copied; any eps): the reference
def fmm(A, B):
    """exact integer product of two integer matrices through BLAS floats (entries stay far below 2^53) (abs_ring.py)"""
    C = A.astype(np.float64) @ B.astype(np.float64); Ci = np.rint(C).astype(np.int64)
    assert np.array_equal(Ci.astype(np.float64), C); return Ci
def comm_set_ref(alg, norders):
    """abs_ring.py's comm_set: maximal sets of commuting labels of square +1 met in several orders, the largest kept"""
    best = []; rg = random.Random(7 + 31 * alg.n + sum(1 for e in alg.eps if e > 0))
    orders = [list(range(1, alg.N)), list(range(alg.N - 1, 0, -1))]
    for _ in range(norders):
        o = list(range(1, alg.N)); rg.shuffle(o); orders.append(o)
    for order in orders:
        gens = []; span = {0}
        for a in order:
            if a in span or alg.sq(a) != 1: continue
            if all(alg.comm_sign(a, g) == 1 for g in gens):
                new = {s_ ^ a for s_ in span}
                if all(alg.sq(x) == 1 for x in new): gens.append(a); span |= new
        if len(gens) > len(best): best = gens
    return best
def build_cell_ref(eps):
    """abs_ring.py's build_cell for the cell with these eps: f = prod (1 + e_a)/2, the ideal Cl f on the cosets of the span, the exact
    commutant (solid_cube.py), the two irreducibles of a two-summand cell by the sign of the volume element"""
    alg = Alg(eps); n = alg.n; N = alg.N
    gens = comm_set_ref(alg, 12 if n <= 8 else (4 if n <= 12 else 2)); k = len(gens); span = {0}
    for a in gens: span |= {s_ ^ a for s_ in span}
    tau = {}
    for J in range(1 << k):
        prod = {0: 1}
        for j in range(k):
            if J >> j & 1: prod = alg.mul(prod, {gens[j]: 1})
        (mm, cf), = prod.items(); tau[mm] = cf
    coset = {}; reps = []
    for a in range(N):
        if a not in coset:
            reps.append(a)
            for mm in span: coset[a ^ mm] = (a, mm)
    m = len(reps); idx = {r: i for i, r in enumerate(reps)}; rho = []
    for i in range(n):
        R = np.zeros((m, m), dtype=np.int64)
        for r in reps:
            s, c_ = alg.blade_mul(1 << i, r); r2, mm = coset[c_]; s2, _ = alg.blade_mul(r2, mm)
            R[idx[r2], idx[r]] = s * s2 * tau[mm]
        rho.append(R)
    basis = commutant_basis(rho, m); typ, els = classify(basis, m); d = len(basis)
    om = np.eye(m, dtype=np.int64)
    for R in rho: om = fmm(om, R)
    sgn = 1 if np.array_equal(om, np.eye(m, dtype=np.int64)) else (-1 if np.array_equal(om, -np.eye(m, dtype=np.int64)) else 0)
    return {'gens': gens, 'm': m, 'rho': rho, 'basis': basis, 'type': typ, 'd': d, 'summ': Fr(N * d, m * m), 'om_sign': sgn}

# ------------------------------------------------------------------------------------------------ the same construction vectorised, on signed permutations (M[perm[c], c] = sign[c])
def sp_trace(A): return int(A[1][A[0] == np.arange(len(A[0]))].sum())
def sp_prod(mods, m):
    out = m_eye(m)
    for R in mods: out = m_mul(out, R)
    return out
def sp_dense(A):
    m = len(A[0]); M = np.zeros((m, m), dtype=np.int64); M[A[0], np.arange(m)] = A[1]; return M
def sp_anticomm_ok(mods, eps, m):
    """the Clifford relations R_i R_j + R_j R_i = 2 eps_i delta_ij on signed permutations (exact)"""
    I = m_eye(m)
    for i in range(len(mods)):
        if not m_eq(m_mul(mods[i], mods[i]), (I[0], I[1] * eps[i])): return False
        for j in range(i + 1, len(mods)):
            P, Q = m_mul(mods[i], mods[j]), m_mul(mods[j], mods[i])
            if not (np.array_equal(P[0], Q[0]) and np.array_equal(P[1], -Q[1])): return False
    return True
def comm_set_v(eps):
    """abs_ring.py's comm_set in its first order (increasing labels), vectorised: commuting independent labels of square +1, greedily"""
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); pa = popv(a)
    cand = s_vec(eps, a, a) == 1; cand[0] = False; inspan = np.zeros(1 << n, dtype=bool); inspan[0] = True
    span = np.zeros(1, dtype=np.int64); gens = []
    while True:
        idx = np.flatnonzero(cand & ~inspan)
        if not len(idx): return gens
        u = int(idx[0]); new = span ^ u
        if not np.all(s_vec(eps, new, new) == 1): cand[u] = False; continue
        gens.append(u); cand &= ((pa * pc(u) - popv(a & u)) & 1) == 0; inspan[new] = True; span = np.concatenate([span, new])
def reducer(gens):
    """the span of gens in reduced echelon form over F2 (each pivot the highest bit of its vector, in no other): a -> the coset minimum"""
    basis = []
    for g in gens:
        v = g
        for pb, bv in basis:
            if v >> pb & 1: v ^= bv
        pb = v.bit_length() - 1; basis = [(q_, w ^ v if w >> pb & 1 else w) for q_, w in basis] + [(pb, v)]
    def red(A):
        R = np.array(A, dtype=np.int64, copy=True)
        for pb, bv in basis: R = np.where(((R >> pb) & 1) == 1, R ^ bv, R)
        return R
    return red
def commutant_v(rho, m):
    """solid_cube.py's commutant_basis, vectorised: the equations X[pi(b), pi(c)] = s(b) s(c) X[b,c] of each signed permutation, solved by
    carrying the smallest index of each component and the sign relative to it along the equations until nothing changes; a component on
    which two signs disagree is zero.  Returns the basis, one {0, +1, -1} matrix per surviving component, each a signed permutation (as
    (rows, signs) by column; None if a component is not one, which the ideal modules never give)"""
    M = m * m; x = np.arange(M, dtype=np.int64); bb, cc = x // m, x % m
    root = x.copy(); psi = np.ones(M, dtype=np.int64)
    while True:
        changed = False
        for pi, sg in rho:
            y = pi[bb] * m + pi[cc]; tt = sg[bb] * sg[cc]                      # X[y] = t X[x]
            r0, p0 = root.copy(), psi.copy(); mv = r0 < r0[y]
            if mv.any(): root[y[mv]] = r0[mv]; psi[y[mv]] = tt[mv] * p0[mv]; changed = True
            r1, p1 = root.copy(), psi.copy(); mv = r1[y] < r1
            if mv.any(): root[mv] = r1[y[mv]]; psi[mv] = tt[mv] * p1[y[mv]]; changed = True
        if not changed: break
    bad = np.zeros(M, dtype=bool)
    for pi, sg in rho:
        y = pi[bb] * m + pi[cc]; tt = sg[bb] * sg[cc]; bad[root[(root[y] != root) | (psi[y] != tt * psi)]] = True
    out = []
    for r in np.unique(root):
        if bad[r]: continue
        sel = np.flatnonzero(root == r); rows_, cols_ = sel // m, sel % m
        if len(sel) != m or len(np.unique(cols_)) != m or len(np.unique(rows_)) != m: out.append(None); continue
        o = np.argsort(cols_); out.append((rows_[o], psi[sel][o]))
    return out
def classify_v(basis, m):
    """solid_cube.py's classify (copied) on signed-permutation bases: 'R' (d = 1), 'C' (d = 2, a J with J^2 = -1), 'H' (d = 4, i and j with
    i^2 = j^2 = -1, ij = -ji); None if the commutant is not seen to be a division algebra.  The supports of the basis matrices are disjoint,
    so a signed permutation in their span is +- one of them: its coordinates are found by matching"""
    d = len(basis)
    if any(B is None for B in basis): return None, []
    def coords(P):
        for k, B in enumerate(basis):
            if np.array_equal(P[0], B[0]):
                if np.array_equal(P[1], B[1]): return [int(i == k) for i in range(d)]
                if np.array_equal(P[1], -B[1]): return [-int(i == k) for i in range(d)]
        raise AssertionError('not in the span')
    if d == 1: return 'R', []
    kap = [[coords(m_mul(Bc, Bd)) for Bd in basis] for Bc in basis]; e = coords(m_eye(m))
    def mul(x_, y_):
        out = [0] * d
        for c_ in range(d):
            if x_[c_]:
                for dd in range(d):
                    if y_[dd]:
                        for t_ in range(d): out[t_] += x_[c_] * y_[dd] * kap[c_][dd][t_]
        return out
    neg = [-v for v in e]
    if d == 2:
        for x_ in itertools.product(range(-2, 3), repeat=2):
            if mul(x_, x_) == neg: return 'C', [x_]
        return None, []
    if d == 4:
        roots = [x_ for x_ in itertools.product(range(-2, 3), repeat=4) if mul(x_, x_) == neg]
        for x_ in roots:
            for y_ in roots:
                if all(a_ == -b_ for a_, b_ in zip(mul(x_, y_), mul(y_, x_))): return 'H', [x_, y_]
        return None, []
    return None, []
def build_ideal(eps, gens=None):
    """abs_ring.py's build_cell on the labels, vectorised: f = prod (1 + e_a)/2 over the commuting labels gens (comm_set_v when not given),
    the left ideal Cl f with the basis e_r f, r the coset minima of their span; e_i e_r f = s s2 tau e_r2 f as in build_cell; the exact
    commutant (commutant_v), its type (classify_v); summands = 2^n d / m^2; the two irreducibles of a two-summand cell by the volume element"""
    eps = tuple(eps); n = len(eps); N = 1 << n
    if n == 0: return {'eps': eps, 'n': 0, 'm': 1, 'irreps': [[]], 'gens': [], 'type': 'R', 'd': 1, 'summ': Fr(1), 'ok_rel': True}
    gens = comm_set_v(eps) if gens is None else list(gens); red = reducer(gens)
    a = np.arange(N, dtype=np.int64); reps = np.flatnonzero(red(a) == a).astype(np.int64); m = len(reps)
    tl = np.zeros(1, dtype=np.int64); ts = np.ones(1, dtype=np.int64)
    for g in gens: tl, ts = np.concatenate([tl, tl ^ g]), np.concatenate([ts, ts * s_vec(eps, tl, g)])
    tau = np.zeros(N, dtype=np.int64); tau[tl] = ts
    rho = []
    for i in range(n):
        c_ = reps ^ (1 << i); r2 = red(c_); mm = c_ ^ r2
        rho.append((np.searchsorted(reps, r2).astype(np.int64), (s_vec(eps, 1 << i, reps) * s_vec(eps, r2, mm) * tau[mm]).astype(np.int64)))
    basis = commutant_v(rho, m); typ, _ = classify_v(basis, m); d = len(basis); summ = Fr(N * d, m * m)
    W = sp_prod(rho, m); irreps = [rho]; sgn = None
    if summ == 2:
        sgn = 1 if m_eq(W, m_eye(m)) else (-1 if m_eq(W, (np.arange(m), -np.ones(m, dtype=np.int64))) else 0)
        neg = [(p_, -s_) for p_, s_ in rho]; irreps = [rho, neg] if sgn == 1 else [neg, rho]
    return {'eps': eps, 'n': n, 'm': m, 'irreps': irreps, 'gens': gens, 'type': typ, 'd': d, 'summ': summ, 'om_sign': sgn,
            'basis': [sp_dense(B) for B in basis if B is not None] if m <= 64 else None, 'ok_rel': sp_anticomm_ok(rho, eps, m)}
def module_class(mods, cell, noswap=False, m=None):
    """abs_ring.py's module_class on signed permutations: the multiplicities of the irreducibles of `cell` in a module, from its dimension
    and, on a two-summand cell, the trace of the volume element W (W^2 = 1 exactly, so dim ker(W - 1) = (m + tr W)/2)"""
    m = len(mods[0][0]) if mods else m; ok = sp_anticomm_ok(mods, cell['eps'], m)
    if len(cell['irreps']) == 1: return ok and m % cell['m'] == 0, [m // cell['m']]
    W = sp_prod(mods, m); ok &= m_eq(m_mul(W, W), m_eye(m)); t_ = sp_trace(W); dp, dm = (m + t_) // 2, (m - t_) // 2
    ok &= (m + t_) % 2 == 0 and dp % cell['m'] == 0 and dm % cell['m'] == 0
    return (ok, [m // cell['m'], 0]) if noswap else (ok, [dp // cell['m'], dm // cell['m']])
def restrict(big, drop, small, noswap=False):
    """integer matrix (abs_ring.py): rows the irreducibles of `small`, columns those of `big`, restricted by dropping generator `drop`"""
    assert tuple(e for i, e in enumerate(big['eps']) if i != drop) == small['eps']
    cols = []
    for T in big['irreps']:
        ok, v = module_class([T[i] for i in range(len(T)) if i != drop], small, noswap, m=len(T[0][0]) if T else 1); assert ok
        cols.append(v)
    return [[cols[j][i] for j in range(len(cols))] for i in range(len(small['irreps']))]
def gtensor(M, N_):
    """abs_ring.py's gtensor on signed permutations: the graded tensor product of two graded modules (generator 0 = the grading in both);
    under --fault PLAINTENSOR the second module's generators without the Koszul twist"""
    IM, IN = m_eye(len(M[0][0])), m_eye(len(N_[0][0]))
    tw = IM if FAULT == 'PLAINTENSOR' else M[0]
    return [m_kron(M[0], N_[0])] + [m_kron(R, IN) for R in M[1:]] + [m_kron(tw, R) for R in N_[1:]]
def explicit_module(V, S):
    """the module item 1's map gives V (x) R^16: e_i -> V(e_i) x Omega_S for the generators of the graded cell (the grading among them),
    f_j -> 1 x S(f_j); Omega_S the product of the block's generators on its module S"""
    OmS = sp_prod(S, len(S[0][0])); IV = m_eye(len(V[0][0]))
    return [m_kron(R, OmS) for R in V] + [m_kron(IV, R) for R in S]
def induced_iso(R, R8, Phi):
    """does Phi (columns: the classes in N(small8) of the images of the irreducibles of small) induce an isomorphism coker R -> coker R8?
    The groups here are cyclic: same name, and the image of every irreducible's class is lambda times it, lambda a unit"""
    nm, cd = coker(R); nm8, cd8 = coker(R8)
    if nm != nm8: return False
    if nm == '0': return True
    if nm not in ('Z', 'Z2'): return False
    k = 0 if nm == 'Z' else 2
    cls = [coker_class(cd, [int(i == j) for j in range(len(R))])[0] for i in range(len(R))]
    cls8 = [coker_class(cd8, [Phi[r][i] for r in range(len(R8))])[0] for i in range(len(R))]
    g = next((i for i, c_ in enumerate(cls) if (abs(c_) == 1 if k == 0 else c_ % 2 == 1)), None)
    if g is None: return False
    lam = cls8[g] * cls[g] if k == 0 else 1
    return (abs(lam) == 1 if k == 0 else cls8[g] % 2 == 1) and all((c8 - lam * c_) % (k or 1) == 0 if k else c8 == lam * c_ for c_, c8 in zip(cls, cls8))
def coker_dd(M):
    """the cokernel of an integer matrix by its determinantal divisors (chain_blocks.py's coker, one or two rows)"""
    d1 = 0
    for row in M:
        for v in row: d1 = gcd(d1, v)
    if len(M) == 1: return '0' if d1 == 1 else 'Z%d' % d1
    d2 = 0
    for i in range(len(M[0])):
        for j in range(i + 1, len(M[0])): d2 = gcd(d2, abs(M[0][i] * M[1][j] - M[0][j] * M[1][i]))
    if d2 == 0: return 'Z' if d1 == 1 else 'Z+Z%d' % d1
    parts = ['Z%d' % x for x in (d1, d2 // d1) if x > 1]; return '+'.join(parts) if parts else '0'
def abs_group_types(p, q):
    """chain_blocks.py's abs_group (cb.ST, pass 8c): the class from the label types and the swap of the two summands by the dropped generator"""
    B = ltype_eps(sig(p + 1, q)); A_ = ltype_eps(sig(p + 1, q + 1)); wB = B[1] * DD[B[0]]; wA = A_[1] * DD[A_[0]]
    if B[2] == 2:
        K = BR(sig(p + 1, q + 1)); g = 1 << (p + q + 1); w = (1 << (p + q + 1)) - 1
        swap = K.s(g, g) == -1 and K.s(g, w) == -K.s(w, g) and K.s(w, w) == 1 and A_[2] == 1
        if not swap or wA % (2 * wB): return None
        M = [[wA // (2 * wB)] * A_[2], [wA // (2 * wB)] * A_[2]]
    else:
        if wA % wB: return None
        M = [[wA // wB] * A_[2]]
    return coker_dd(M)

head('pm.ABS  the ABS classes at n and n + 8 from minimal left ideals: A(p,q) = coker(N(Cl(p+1,q+1)) -> N(Cl(p+1,q))), and V -> V (x)^ beta')
t = time.time()
PQ = [(p, n - p) for n in range(9) for p in range(n + 1)]                     # the 45 cells (p,q,0), n <= 8
KO = {0: 'Z', 1: '0', 2: '0', 3: '0', 4: 'Z', 5: '0', 6: 'Z2', 7: 'Z2'}         # KO^(p-q)(point) by the clock: ATY-001's recalled table
CELL = {}
def cell(eps):
    eps = tuple(eps)
    if eps not in CELL: CELL[eps] = build_ideal(eps)
    return CELL[eps]
okRef = True; nref = 0; seen = set()                                          # the reference on the 54 base cells
for p, q in PQ:
    for eps in ((1,) + sig(p, q), (1,) + sig(p, q + 1)):
        if eps in seen: continue
        seen.add(eps); ref = build_cell_ref(eps); vec = build_ideal(eps, gens=ref['gens']); own = cell(eps)
        rv = vec['irreps'][0] if vec['om_sign'] in (None, 1) else vec['irreps'][1]
        okRef &= ref['m'] == vec['m'] == own['m'] and all(np.array_equal(R, sp_dense(v)) for R, v in zip(ref['rho'], rv))
        okRef &= ref['d'] == vec['d'] == own['d'] and ref['type'] == vec['type'] == own['type'] and ref['summ'] == vec['summ'] == own['summ']
        okRef &= (ref['summ'] != 2 or ref['om_sign'] == vec['om_sign']) and len(ref['gens']) == len(own['gens'])
        okRef &= len(vec['basis']) == len(ref['basis']) and all(any(np.array_equal(a_, b_) or np.array_equal(a_, -b_) for b_ in vec['basis']) for a_ in ref['basis'])
        nref += 1
chk('bit', okRef, 'pm.ABS: on the %d base cells (the graded cells (1,) + (p,q) and (1,) + (p,q+1), p + q <= 8, up to 10 generators) abs_ring.py\'s build_cell (copied: bitcliff.py\'s engine, solid_cube.py\'s exact commutant and classify) and the vectorised construction on signed permutations with the same commuting set give the same matrices, the same commutant (dimension, basis up to sign, type), summands and volume sign; the vectorised greedy (abs_ring.py\'s first order) finds commuting sets of the same size' % nref)
GR = FAULT != 'UNGRADED'; NS = FAULT == 'NOSWAP'
def A_data(p, q, blk=None, graded=True, noswap=False):
    """A(p,q) with the block blk concatenated (None: none): coker(N(big) -> N(small)), the last generator of the (p,q)-part dropped"""
    ext = sig(*blk) if blk else ()
    if graded: es, eb, drop = (1,) + sig(p, q) + ext, (1,) + sig(p, q + 1) + ext, 1 + p + q
    else: es, eb, drop = sig(p, q) + ext, sig(p, q + 1) + ext, p + q
    small, big = cell(es), cell(eb); R = restrict(big, drop, small, noswap)
    return coker(R)[0], R, small, big
def cols(res): return [[v[r] for _, v in res] for r in range(len(res[0][1]))], all(o for o, _ in res)
SBLK = {b: cell(sig(*b))['irreps'][0] for b in BLOCKS}                        # the block's 16-dimensional minimal left ideal
BETA = {b: [sp_prod(SBLK[b], 16)] + SBLK[b] for b in BLOCKS}                  # ... graded by Omega: a module of Cl(P+1,Q)
okBeta = all(cell(sig(*b))['m'] == 16 and cell(sig(*b))['d'] == 1 and module_class(BETA[b], cell((1,) + sig(*b))) == (True, [1, 0]) for b in BLOCKS)
LST = {}; LST8 = {}; okL = okL8 = okDim = okR8 = okCar = okId = okExp = okSq = okIso = True; nmax = 0
for p, q in PQ:
    nm, R, Bc, Ac = A_data(p, q, None, GR, NS); LST[(p, q)] = nm; okL &= nm == KO[(p - q) % 8]
    _, Rg, Bg, Ag = A_data(p, q, None, True, NS)
    for b in BLOCKS:
        nm8, R8, B8, A8 = A_data(p, q, b, GR, NS); LST8[(p, q, b)] = nm8; nmax = max(nmax, A8['m'])
        okL8 &= nm8 == nm == KO[(p - q) % 8] and R8 == R
        okDim &= B8['m'] == 16 * Bc['m'] and A8['m'] == 16 * Ac['m'] and len(B8['irreps']) == len(Bc['irreps']) and len(A8['irreps']) == len(Ac['irreps'])
        _, Rg8, Bg8, Ag8 = A_data(p, q, b, True, NS)
        Phi, o1 = cols([module_class(gtensor(V, BETA[b]), Bg8, NS) for V in Bg['irreps']])
        PhiE, o2 = cols([module_class(explicit_module(V, SBLK[b]), Bg8, NS) for V in Bg['irreps']])
        Psi, o3 = cols([module_class(gtensor(W, BETA[b]), Ag8, NS) for W in Ag['irreps']])
        okCar &= o1 and o2 and o3; okExp &= PhiE == Phi
        okId &= Phi == [[int(i == j) for j in range(len(Phi[0]))] for i in range(len(Phi))]
        okSq &= (np.array(Rg8) @ np.array(Psi)).tolist() == (np.array(Phi) @ np.array(Rg)).tolist()
        okIso &= induced_iso(Rg, Rg8, Phi)
built = list(CELL.values())
okIrr = all(c_['ok_rel'] and c_['type'] in ('R', 'C', 'H') and c_['d'] == DD[c_['type']] and c_['summ'] in (1, 2) and c_['summ'] * c_['m'] ** 2 == (1 << c_['n']) * c_['d'] for c_ in built)
bylist = ' '.join('%s' % LST[next(pq for pq in PQ if (pq[0] - pq[1]) % 8 == c_)] for c_ in range(8))
chk('bit', okIrr, 'pm.ABS: every cell built from its minimal left ideal (%d cells, up to %d generators, %d labels at most; modules of dimension up to %d on signed permutations, never as 2^n x 2^n matrices): the Clifford relations hold, the exact commutant is R, C or H, and (summands) x m^2 = 2^n x dim(commutant), one or two summands' % (len(built), max(c_['n'] for c_ in built), 1 << max(c_['n'] for c_ in built), max(c_['m'] for c_ in built)))
chk('bit', okL, 'pm.ABS: A(p,q) = coker(N(Cl(p+1,q+1)) -> N(Cl(p+1,q))) from the ideals for the 45 cells (p,q,0), p + q <= 8: by the clock c = 0..7 %s, the list KO^(p-q)(point) of ATY-001 (recalled table), the nine cells of n = 8 included' % bylist)
chk('bit', okL8 and okDim, 'pm.ABS: at n + 8, the graded cell followed by each block (8,0,0), (0,8,0), (4,4,0) (135 cases; the cells as the labels concatenate, GEN-010\'s relabelling of Cl(p+P+1,q+Q)): the same group in every case, the irreducible graded modules 16 times as large in the same number, and the restriction matrix equal to that at n entry by entry')
chk('bit', okBeta, 'pm.ABS: for each block the 16-dimensional minimal left ideal (commutant R) graded by Omega, beta = (Omega, f_1..f_8), is the irreducible of the graded block Cl(P+1,Q) on which the volume element is +1 (class (1,0) from the ideals of the 9-generator cell)')
chk('bit', okCar and okId and okExp, 'pm.ABS: the carry, 135 cases: V (x)^ beta (abs_ring.py\'s gtensor) of each irreducible graded module V at n satisfies the relations of the cell at n + 8 and is the irreducible of the same volume sign (the map on N is the identity: the two summands kept); the module of the explicit map of pm.MAP, e_i -> V(e_i) x Omega and f_j -> 1 x f_j, has the same class')
chk('bit', okSq and okIso, 'pm.ABS: the square commutes, R(n+8) Psi = Phi R(n) (Psi the carry of the irreducibles of Cl(p+1,q+1)), so V -> V (x)^ beta induces A(p,q) -> A(p+P,q+Q); it is an isomorphism, the class of each irreducible to the same multiple of a generator, in all 135 cases: ABS\'s beta on the finite side, computed from the ideals for every cell with p + q <= 8')
okST = all(abs_group_types(p, q) == LST[(p, q)] for p, q in PQ) and all(abs_group_types(p + b[0], q + b[1]) == LST8[(p, q, b)] for p, q in PQ for b in BLOCKS)
chk('bit', okST, 'pm.ABS: the 45 + 135 classes from the ideals equal pass 8c\'s classes from the label types and the swap (cb.ST, chain_blocks.py\'s abs_group copied)')
ABS_RING_R1 = 'Z Z2 Z2 0 Z 0 0 0 Z Z2 Z2 0 Z 0 0 0 Z'.split()             # abs_ring.py abs.R1 (logs/abs_ring.log): A_k, k = 0..16
ABS_RING_DIM = [1, 2, 4, 8, 8, 16, 16, 16, 16, 32, 64, 128, 128, 256, 256, 256, 256, 512]; ABS_RING_NIRR = [2, 1, 1, 1, 2, 1, 1, 1] * 2 + [2, 1]
alongk = [LST[(0, k)] for k in range(9)] + [LST8[(0, k - 8, (0, 8, 0))] for k in range(9, 17)]
cells1k = [cell((1,) + sig(0, k)) for k in range(9)] + [cell((1,) + sig(0, k - 8) + sig(0, 8)) for k in range(9, 18)]
chk('bit', alongk == ABS_RING_R1 and [c_['m'] for c_ in cells1k] == ABS_RING_DIM and [len(c_['irreps']) for c_ in cells1k] == ABS_RING_NIRR, 'pm.ABS: along (1,k), the cells of ATY-026 (the block (0,8,0) beyond k = 8 gives exactly the eps of Cl(1,k)): A_k = %s for k = 0..16, irreducible dimensions %s for k = 0..17, the list of abs.R1 (logs/abs_ring.log)' % (' '.join(alongk), [c_['m'] for c_ in cells1k]))
nsw = [A_data(p, q, None, True, True)[0] for p, q in PQ]; ung = [A_data(p, q, None, False, False)[0] for p, q in PQ]
okNS = all((x_ == 'Z+Z2') == ((p - q) % 4 == 0) for x_, (p, q) in zip(nsw, PQ)) and all(x_ == KO[(pq[0] - pq[1]) % 8] for x_, pq in zip(nsw, PQ) if (pq[0] - pq[1]) % 4)
UNG = {0: 'Z2', 1: 'Z', 2: '0', 3: '0', 4: '0', 5: 'Z', 6: '0', 7: 'Z2'}
okUG = all(x_ == UNG[(p - q) % 8] for x_, (p, q) in zip(ung, PQ))
chk('ctl', okNS, 'pm.ABS: with the two irreducibles of a two-summand graded cell kept, not swapped, by the dropped generator (NOSWAP) the class is Z+Z2 exactly at the clocks 0 and 4 (%d of the 45 cells), the others unchanged' % sum(1 for x_ in nsw if x_ == 'Z+Z2'))
chk('ctl', okUG, 'pm.ABS: without the grading (UNGRADED: coker(N(Cl(p,q+1)) -> N(Cl(p,q)))) the list moves by one: %s by the clock c = 0..7, ATY-001\'s ungraded list' % ' '.join(UNG[c_] for c_ in range(8)))
okPT = True; npt = 0
for p, q in PQ:
    for b in BLOCKS:
        Bg8 = cell((1,) + sig(p, q) + sig(*b)); V = cell((1,) + sig(p, q))['irreps'][0]; IM = m_eye(len(V[0][0])); IN = m_eye(16)
        plain = [m_kron(V[0], BETA[b][0])] + [m_kron(R, IN) for R in V[1:]] + [m_kron(IM, R) for R in BETA[b][1:]]
        bad_ = not sp_anticomm_ok(plain, Bg8['eps'], len(plain[0][0])); okPT &= bad_ == (p + q > 0); npt += bad_
chk('ctl', okPT, 'pm.ABS: the plain tensor product (PLAINTENSOR: 1 x f_j in place of the twist eps_V x f_j) is not a module of the cell at n + 8 in %d of the 135 cases, exactly those with p + q >= 1, where a generator of V then commutes with those of the block (for p = q = 0 the graded cell has only its grading and both products are modules)' % npt)
note('(%.1f s)' % (time.time() - t))
# ------------------------------------------------------------------------------------------------ the standard route (abs_ring.py's abs.S, any (p,q)): numpy, no label
t = time.time()
_Xs = np.array([[0, 1], [1, 0]]); _Zs = np.diag([1, -1]); _Es = np.array([[0, 1], [-1, 0]]); _I2s = np.eye(2, dtype=np.int64)
def kron_gammas(eps):
    G = []
    for k in range(len(eps)):
        A = _Xs if eps[k] > 0 else _Es; M = np.array([[1]], dtype=np.int64)
        for B in [_Zs] * k + [A] + [_I2s] * (len(eps) - k - 1): M = np.kron(M, B)
        G.append(M)
    return G
def _split(G, prods, dim, seed):
    """the irreducible summands of a module as eigenspaces of a random symmetric commutant element (abs_ring.py)"""
    rng = np.random.default_rng(seed); X = rng.standard_normal((dim, dim)); X = X + X.T
    Y = sum(P @ X @ P.T for P in prods) / len(prods); w, V = np.linalg.eigh(Y)
    groups = []; start = 0; scale = max(1.0, np.abs(w).max())
    for i in range(1, dim + 1):
        if i == dim or w[i] - w[i - 1] > 1e-7 * scale: groups.append(V[:, start:i]); start = i
    return groups
def _blade_products(G, dim):
    prods = [np.eye(dim)]
    for a in range(1, 1 << len(G)):
        i = (a & -a).bit_length() - 1; prods.append(G[i] @ prods[a ^ (1 << i)])
    return prods
def std_cell(eps, seed=0):
    """abs_ring.py's std_base for any eps (<= 7 generators): the irreducibles from the regular representation of the Kronecker words"""
    n = len(eps); dim = 2 ** n; Gf = [g.astype(float) for g in kron_gammas(eps)]
    prods = _blade_products(Gf, dim); groups = _split(Gf, prods, dim, 1000 + 37 * n + seed); om = prods[-1]
    two = n % 2 == 1 and all(np.allclose(om @ g, g @ om) for g in Gf) and np.allclose(om @ om, np.eye(dim)); irreps = []
    if two:
        for sgn in (1, -1):
            Q = next(g for g in groups if np.trace(g.T @ om @ g) * sgn > 0.5); irreps.append([Q.T @ Gk @ Q for Gk in Gf])
    else:
        Q = groups[0]; irreps.append([Q.T @ Gk @ Q for Gk in Gf])
    return {'m': groups[0].shape[1], 'irreps': irreps, 'two': two, 'sizes': sorted(set(g.shape[1] for g in groups))}
def gtensor_f(M, N_):
    IM, IN = np.eye(M[0].shape[0]), np.eye(N_[0].shape[0])
    return [np.kron(M[0], N_[0])] + [np.kron(R, IN) for R in M[1:]] + [np.kron(M[0], R) for R in N_[1:]]
def std_class(mods, m_irr, two):
    m = mods[0].shape[0]
    if not two: return [int(round(m / m_irr))]
    om = np.eye(m)
    for R in mods: om = om @ R
    tr = np.trace(om); return [int(round((m + tr) / (2 * m_irr))), int(round((m - tr) / (2 * m_irr)))]
def std_rmat(big_irreps, drop, m_small, two_small):
    cl = [std_class([T[i] for i in range(len(T)) if i != drop], m_small, two_small) for T in big_irreps]
    return [[c_[i] for c_ in cl] for i in range(2 if two_small else 1)]
BETA_STD = {}
for b in BLOCKS:
    Gb = [g.astype(float) for g in block_mats(b)]; Ob = Gb[0]
    for g in Gb[1:]: Ob = Ob @ g
    BETA_STD[b] = [Ob] + Gb                                                   # the block's 16 x 16 Kronecker module graded by its Omega
okSd = okSR = okSc = True; nst = 0; nst8 = 0
for p, q in PQ:
    if p + q > 5: continue
    SB, SA = std_cell((1,) + sig(p, q)), std_cell((1,) + sig(p, q + 1)); bB, bA = cell((1,) + sig(p, q)), cell((1,) + sig(p, q + 1))
    okSd &= len(SB['sizes']) == 1 and len(SA['sizes']) == 1 and SB['m'] == bB['m'] and SA['m'] == bA['m'] and SB['two'] == (len(bB['irreps']) == 2) and SA['two'] == (len(bA['irreps']) == 2)
    Rs = std_rmat(SA['irreps'], 1 + p + q, SB['m'], SB['two']); okSR &= Rs == A_data(p, q)[1]; okSc &= coker_divisors(Rs) == KO[(p - q) % 8]; nst += 1
    for b in BLOCKS:
        Rs8 = std_rmat([gtensor_f(T, BETA_STD[b]) for T in SA['irreps']], 1 + p + q, 16 * SB['m'], SB['two'])
        okSR &= Rs8 == A_data(p, q, b)[1]; okSc &= coker_divisors(Rs8) == KO[(p - q) % 8]; nst8 += 1
chk('std', okSd and okSc, 'pm.ABS: numpy, no label (abs_ring.py\'s abs.S for any (p,q)): for the %d cells with p + q <= 5 the irreducible graded modules as eigenspaces of a random symmetric commutant element of the regular representation of Kronecker words (one eigenspace dimension each, the bit route\'s dimensions and counts); at n + 8 the graded tensor product with the block\'s 16 x 16 Kronecker module graded by its Omega (%d cases); the cokernels by determinantal divisors are the list KO^(p-q)' % (nst, nst8))
chk('bit==std', okSR, 'pm.ABS: the restriction matrices of the standard route (classes from dimensions and the trace of the volume element) equal those from the ideals entry by entry, %d cases at n and %d at n + 8' % (nst, nst8))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ pm.DG  the dimension group on the finite stages
head('pm.DG  the dimension group of the chain of blocks on its finite stages: s, minimal idempotents, the order unit, the multiplicity matrices')
t = time.time()
def ltype_split(eps, nlow):
    """the type of a non-degenerate cell without enumerating its labels (pass 8c's route at n = 24): a label is c1 + 2^nlow c2; e_c commutes
    with a generator of the first part as c1 does with |c2| mod 2 added above it, with one of the second part as c2 does with |c1| mod 2
    added below it (the parity reduction); e_c^2 = (-1)^(|c1||c2|) d1(c1) d2(c2) (the graded diagonal), summed by parities"""
    e1, e2 = tuple(eps[:nlow]), tuple(eps[nlow:]); n1, n2 = len(e1), len(e2)
    a1 = np.arange(1 << n1, dtype=np.int64); a2 = np.arange(1 << n2, dtype=np.int64); d1 = s_vec(e1, a1, a1); d2 = s_vec(e2, a2, a2)
    p1 = popv(a1) & 1; p2 = popv(a2) & 1
    E1, O1, E2, O2 = int(d1[p1 == 0].sum()), int(d1[p1 == 1].sum()), int(d2[p2 == 0].sum()), int(d2[p2 == 1].sum())
    def cen(a, n_, add_above, add_below):
        ok = np.ones(len(a), dtype=bool)
        for i in range(n_): ok &= ((popv(a >> (i + 1)) + add_above - popv(a & ((1 << i) - 1)) - add_below) & 1) == 0
        return ok
    central = []
    for par1 in (0, 1):
        for par2 in (0, 1):
            L = np.flatnonzero(cen(a1, n1, par2, 0) & (p1 == par1)); H = np.flatnonzero(cen(a2, n2, 0, par1) & (p2 == par2))
            central += [int(x) | (int(y) << n1) for x in L for y in H]
    K = BR(eps); cplx = any(K.s(c_, c_) == -1 for c_ in central)
    return type_from_inv(1 << (n1 + n2), len(central) // 2 if cplx else len(central), cplx, E1 * E2 + E1 * O2 + O1 * E2 - O1 * O2)
def stage_type(eps):
    return ltype_eps(eps) if len(eps) <= 20 else ltype_split(eps, len(eps) - 8)
def prim(K, U):
    P = {0: Fr(1)}
    for u in U: P = K.mul(P, {0: Fr(1, 2), u: Fr(1, 2)})
    return P
def phi_imgs(K, Nk):                                                        # e_i -> e_i Omega_(k+1) as signed blades, i < N_k
    Om = 255 << Nk; return [(K.s(1 << i, Om), (1 << i) ^ Om) for i in range(Nk)]
def phi_mv(K, imgs, x):
    out = {}
    for lab, cf in x.items():
        sb = (1, 0)
        for i in range(lab.bit_length()):
            if lab >> i & 1: sb = mmul(K, sb, imgs[i])
        if sb[0]: out[sb[1]] = out.get(sb[1], 0) + sb[0] * cf
    return {k_: v for k_, v in out.items() if v != 0}
def alpha(x): return {lab: (-cf if pc(lab) & 1 else cf) for lab, cf in x.items()}   # e_i -> -e_i: swaps the summands of an odd cell
START = [(p, n - p) for n in range(5) for p in range(n + 1)] + [(8, 0), (0, 8), (4, 4)]
CH_BLOCKS = [(5, 3, 0)] if FAULT == 'CLOCK2' else BLOCKS
MULT = 8 if FAULT == 'MULT8' else 16
QB = {b: comm_set_v(sig(*b)) for b in BLOCKS + [(5, 3, 0)]}                 # four commuting labels of square +1 in each block
okTy = okHom = okMin = okUnit = okMul = okKeep = okComp = okUc = okLNC = okQ = True; okSplit = True; nch = 0; nkeep = 0; DATA = {}; ERRS = []
for c0 in START:
    n = sum(c0); eps0 = sig(*c0)
    for b in CH_BLOCKS:
        try:
            eb = sig(*b); EPS = [eps0 + eb * k for k in range(3)]; NK = [n + 8 * k for k in range(3)]; KS = [BR(e) for e in EPS]
            TY = [stage_type(e) for e in EPS]; s_ = [ty[2] for ty in TY] if None not in TY else [0, 0, 0]
            okTy &= None not in TY and all(TY[k] == (TY[0][0], TY[0][1] * 16 ** k, TY[0][2]) for k in range(3))
            Z = []                                                              # the minimal central idempotents, by the sign of the top blade
            for k in range(3):
                top = (1 << NK[k]) - 1
                Z.append({'+': {0: Fr(1)}} if s_[k] != 2 else {'+': {0: Fr(1, 2), top: Fr(1, 2)}, '-': {0: Fr(1, 2), top: Fr(-1, 2)}})
            P = [None, None, None]; P0 = prim(KS[0], comm_set_v(eps0) if n else [])
            def by_summand(k, Pk):
                if len(Z[k]) == 1: return {'+': Pk}
                out = {}
                for x in (Pk, alpha(Pk)):
                    sgn_ = next((g_ for g_, z in Z[k].items() if KS[k].mul(x, z) == x), None); out[sgn_] = x
                return out
            P[0] = by_summand(0, P0); IM = [phi_imgs(KS[k + 1], NK[k]) for k in range(2)]
            for k in range(2):
                okHom &= all(mmul(KS[k + 1], IM[k][i], IM[k][i]) == (EPS[k][i], 0) for i in range(NK[k])) and all(mmul(KS[k + 1], IM[k][i], IM[k][j])[0] == -mmul(KS[k + 1], IM[k][j], IM[k][i])[0] for i in range(NK[k]) for j in range(i + 1, NK[k]))
                Qk = {lab << NK[k]: cf for lab, cf in prim(BR(eb), QB[b]).items()}; FP = phi_mv(KS[k + 1], IM[k], P[k]['+'])
                okQ &= KS[k + 1].mul(Qk, Qk) == Qk and KS[k + 1].mul(FP, Qk) == KS[k + 1].mul(Qk, FP)     # Q idempotent, commuting with the image
                P[k + 1] = by_summand(k + 1, KS[k + 1].mul(FP, Qk))
            rank = lambda k, x: (1 << NK[k]) * x.get(0, 0)
            for k in range(3):
                D_, m_, _ = TY[k] if TY[k] else ('R', 0, 0)
                okMin &= None not in P[k] and len(P[k]) == s_[k] and all((k == 2 or KS[k].mul(x, x) == x) and rank(k, x) == m_ * DD[D_] for x in P[k].values())
            units = [{g_: rank(k, Z[k][g_]) / rank(k, P[k][g_]) for g_ in P[k]} for k in range(3)]
            okUnit &= all(units[k][g_] == TY[k][1] and rank(k, P[k][g_]) / units[k][g_] == DD[TY[k][0]] for k in range(3) for g_ in units[k])
            Ms = []
            for k in range(2):
                M_ = {(i_, j_): rank(k + 1, KS[k + 1].mul(phi_mv(KS[k + 1], IM[k], P[k][j_]), Z[k + 1][i_])) / rank(k + 1, P[k + 1][i_]) for i_ in P[k + 1] for j_ in P[k]}
                Ms.append(M_); okMul &= all(v == (MULT if i_ == j_ else 0) for (i_, j_), v in M_.items())
                okUc &= all(units[k + 1][i_] == sum(M_[(i_, j_)] * units[k][j_] for j_ in P[k]) for i_ in P[k + 1])
                if s_[k] == 2:
                    sb = (1, 0)
                    for i in range(NK[k]): sb = mmul(KS[k + 1], sb, IM[k][i])
                    okKeep &= sb == (1, (1 << NK[k + 1]) - 1); nkeep += 1
            # the composite of the two steps is the one step of the chain of M256(R) blocks: e_i -> e_i Omega_16, Omega_16 = Omega_1 Omega_2
            O16 = ((1 << 16) - 1) << n; I16_ = [(KS[2].s(1 << i, O16), (1 << i) ^ O16) for i in range(n)]
            okComp &= all(phi_mv(KS[2], IM[1], phi_mv(KS[1], IM[0], {1 << i: 1})) == {I16_[i][1]: I16_[i][0]} for i in range(n))
            Md = {(i_, j_): rank(2, KS[2].mul(phi_mv(KS[2], I16_, P[0][j_]), Z[2][i_])) / rank(2, P[2][i_]) for i_ in P[2] for j_ in P[0]}
            okComp &= all(Md[(i_, j_)] == sum(Ms[1][(i_, l_)] * Ms[0][(l_, j_)] for l_ in P[1]) == (MULT * MULT if i_ == j_ else 0) for (i_, j_) in Md)
            if 16 <= NK[2] <= 20: okSplit &= ltype_split(EPS[2], NK[2] - 8) == TY[2] and ltype_split(EPS[1], NK[1] - 8) == TY[1]
            if NK[2] == 24:
                K = KS[2]
                for _ in range(300):
                    x = RNG.randrange(1 << 24); i = RNG.randrange(24); lo, hi = x & 0xFFFF, x >> 16
                    red_ = (pc(lo >> (i + 1)) + pc(hi) - pc(lo & ((1 << i) - 1))) % 2 == 0 if i < 16 else (pc(hi >> (i - 15)) - pc(lo) - pc(hi & ((1 << (i - 16)) - 1))) % 2 == 0
                    okSplit &= (K.s(x, 1 << i) == K.s(1 << i, x)) == red_ and K.s(x, x) == (-1) ** (pc(lo) * pc(hi)) * K.s(lo, lo) * K.s(hi << 16, hi << 16)
            if n <= 8:                                                          # LNC-059: the 2^w idempotents of the maximal commuting set at stage 0
                U = comm_set_v(eps0) if n else []; idem = []
                for sg_ in itertools.product((1, -1), repeat=len(U)):
                    x = {0: Fr(1)}
                    for u, e_ in zip(U, sg_): x = KS[0].mul(x, {0: Fr(1, 2), u: Fr(e_, 2)})
                    idem.append(x)
                tot = {}
                for x in idem:
                    for lab, cf in x.items(): tot[lab] = tot.get(lab, 0) + cf
                okLNC &= {k_: v for k_, v in tot.items() if v} == {0: 1} and len(idem) == s_[0] * TY[0][1] and all(sum(1 for x in idem if KS[0].mul(x, Z[0][g_]) == x) == units[0][g_] for g_ in Z[0])
            DATA[(c0, b)] = (TY, units, Ms); nch += 1
        except Exception as ex_:                                            # a wrong version (a fault) that breaks the algebra: a failure, not a crash
            okTy = False; DATA[(c0, b)] = None; ERRS.append('%s %s: %s' % (cstr(c0), cstr(b), type(ex_).__name__))
chk('bit', okTy and okSplit, 'pm.DG: the %d chains (the 15 cells (p,q,0) with n <= 4 and the row-8 cells (8,0), (0,8), (4,4), each with one block repeated), stages n, n + 8, n + 16: the type from the labels keeps D and s and multiplies the matrix size by 16 at each step; s = 2 exactly for the clocks 1 and 5; at n + 16 <= 20 by enumerating the labels, at n + 16 = 24 by the parity reduction and the graded diagonal (equal to the enumeration for every stage of 16 to 20 generators, and to BR on 2700 sampled entries at 24)' % nch)
chk('bit', okHom and okMin and okQ, 'pm.DG: the inclusions e_i -> e_i Omega satisfy the relations of the stage before (an algebra map); a minimal idempotent of each summand at each stage, the image of one of the stage before times Q = prod (1 + u)/2 over four commuting labels of square +1 of the new block (the other summand by e_i -> -e_i), has tr L_P = 2^N x scalar part = m dim D, the dimension of its minimal left ideal (16 times that of the stage before); P^2 = P exactly at the stages n and n + 8, and at n + 16 as the product of two commuting idempotents (Q^2 = Q and phi(P) Q = Q phi(P) computed, phi(P)^2 = phi(P^2))')
chk('bit', okUnit and okUc and okLNC, 'pm.DG: K_0 = Z^s with the cone N^s and the order unit tr L_z / tr L_P = (m, ..., m), 16^k m_0 at stage k (the multiplicity of the irreducible in the regular module; tr L_P / m = dim D, the rank of P on the irreducible), carried to the next unit by the multiplicity matrix; at stage 0 the 2^w idempotents of the maximal commuting set (LNC-059) sum to 1 and m of them lie in each summand (2^w = s m)')
chk('bit', okMul and okKeep, 'pm.DG: the multiplicity matrix of every inclusion (108) is %d I: a minimal idempotent goes to %d minimal idempotents of the same summand; for the %d inclusions of a two-summand stage the image of the central volume element is +omega of the next stage (sign +1): the summands are kept, the permutation P_k = I' % (MULT, MULT, nkeep))
chk('bit', okComp, 'pm.DG: for the 54 chains the composite of the two steps is the one step e_i -> e_i Omega_16 of the chain of M256(R) blocks (Omega_16 = Omega_1 Omega_2, on every generator), and its multiplicity matrix, computed directly, is the product of the two: %d I (the chain of M256(R) blocks is the chain of M16(R) blocks read every second step, K_0 included)' % (MULT * MULT))
if ERRS: note('chains that broke under this version: %d (%s)' % (len(ERRS), '; '.join(ERRS[:3])))
if not ERRS: note('the stages (Z^s, unit_k, x16 P_k), block (8,0,0): ' + '; '.join('%s %s: s %d, units %s' % (cstr(c0), tstr(DATA[(c0, CH_BLOCKS[0])][0][0]), DATA[(c0, CH_BLOCKS[0])][0][0][2] if DATA[(c0, CH_BLOCKS[0])][0][0] else 0, '/'.join(','.join(str(int(v)) for v in u_.values()) for u_ in DATA[(c0, CH_BLOCKS[0])][1])) for c0 in [(0, 0), (1, 0), (0, 1), (0, 2), (0, 3), (8, 0)]))
okK2 = True; nmir = nsch = ntch = 0
for c0 in START[:15]:
    n = sum(c0); eps = sig(*c0) + sig(5, 3); K = BR(eps); Om = 255 << n
    okK2 &= K.s(Om, Om) == -1 and all(mmul(K, (K.s(1 << i, Om), (1 << i) ^ Om), (K.s(1 << i, Om), (1 << i) ^ Om)) == (-sig(*c0)[i], 0) for i in range(n)); nmir += n > 0
    t0, t1 = ltype_eps(sig(*c0)) if n else ('R', 1, 1), ltype_eps(eps)
    nsch += t0[2] != t1[2]; ntch += t1 != (t0[0], 16 * t0[1], t0[2])
odd_ = sum(1 for c0 in START[:15] if clock(c0) % 2); n04 = sum(1 for c0 in START[:15] if clock(c0) % 4 == 0)
chk('ctl', okK2 and nsch == odd_ and ntch == 15 - n04, 'pm.DG: the chain with the clock-2 block (5,3,0) (CLOCK2): its top blade squares to -1, (e_i Omega)^2 = -e_i^2 for every generator of the %d start cells with n >= 1 (no algebra map: the mirror); s changes at the first step for the %d start cells of odd clock and the type for %d of the 15 (all but the clocks 0 and 4)' % (nmir, nsch, ntch))
note('(%.1f s)' % (time.time() - t))
# ------------------------------------------------------------------------------------------------ the standard route: numpy matrices for the stages 0 and 1 (start cells n <= 2)
t = time.time()
def words_f(G, d):
    W = [np.eye(d)]
    for a in range(1, 1 << len(G)):
        top = a.bit_length() - 1; W.append(W[a ^ (1 << top)] @ G[top])
    return np.array(W)
def clusters(ev, tol=1e-6):
    out = []
    for v in sorted(ev):
        if not out or v - out[-1][-1] > tol: out.append([v])
        else: out[-1].append(v)
    return [float(np.mean(c_)) for c_ in out]
def std_stage(G, d):
    """numpy, no label: the words of the algebra generated by the d x d matrices G, the centre as the null space of the commutators with the
    generators (on random vectors), the minimal central idempotents as the spectral projectors (Lagrange) of a random symmetric central
    element, a minimal projection of each summand as the top spectral projector of a random symmetric element cut down by the central one"""
    W = words_f(G, d); M = len(W)
    if G:
        R = NPR.standard_normal((d, 3))
        cols_ = np.stack([np.concatenate([((W[a] @ g - g @ W[a]) @ R).ravel() for g in G]) for a in range(M)], 1)
        _, sv, Vt = np.linalg.svd(cols_, full_matrices=False); nul = Vt[sv < 1e-8 * max(sv.max(), 1.0)]
    else: nul = np.ones((1, 1))
    Zc = np.tensordot(nul.T @ NPR.standard_normal(len(nul)), W, 1); Zc = (Zc + Zc.T) / 2; lam = clusters(np.linalg.eigvalsh(Zc))
    Zs = []
    for i, l in enumerate(lam):
        Pz = np.eye(d)
        for j, l2 in enumerate(lam):
            if j != i: Pz = Pz @ (Zc - l2 * np.eye(d)) / (l - l2)
        Zs.append(Pz)
    X = np.tensordot(NPR.standard_normal(M), W, 1); X = X + X.T; Ps = []
    for Pz in Zs:
        w_, V_ = np.linalg.eigh((Pz + Pz.T) / 2); B = V_[:, w_ > 0.5]; w2, V2 = np.linalg.eigh(B.T @ X @ B)
        Vt_ = B @ V2[:, w2 > w2.max() - 1e-6 * max(1.0, np.abs(w2).max())]; Ps.append(Vt_ @ Vt_.T)
    return W, len(nul), Zs, Ps
rk = lambda A: int(np.linalg.matrix_rank(A, tol=1e-6))
okSs = okSb = True; nstd = 0
for c0 in START[:6]:
    n = sum(c0); d0 = 1 << n; G0 = [g.astype(float) for g in site_gens(sig(*c0))] if n else []
    W0, nz0, Z0, P0s = std_stage(G0, d0); om0 = words_f(G0, d0)[-1]
    for b in CH_BLOCKS:
        Gb = [g.astype(float) for g in block_mats(b)]; Ob = Gb[0]
        for g in Gb[1:]: Ob = Ob @ g
        G1 = [np.kron(g, Ob) for g in G0] + [np.kron(np.eye(d0), g) for g in Gb]; d1 = 16 * d0
        W1, nz1, Z1, P1s = std_stage(G1, d1); om1 = W1[-1]
        def labs(Zs, om):
            if len(Zs) == 1: return ['+']
            return ['+' if np.allclose(om @ Z_, Z_, atol=1e-6) else ('-' if np.allclose(om @ Z_, -Z_, atol=1e-6) else '?') for Z_ in Zs]
        L0, L1 = labs(Z0, om0), labs(Z1, om1)
        phiG = [np.kron(g, Ob) @ np.kron(np.eye(d0), Ob) for g in G0]           # the image of e_i Omega
        Wphi = words_f(phiG, d1); A0 = W0.reshape(len(W0), -1).T
        Mstd = {}
        for j_, P_ in zip(L0, P0s):
            al = np.linalg.lstsq(A0, P_.ravel(), rcond=None)[0]; okSs &= np.allclose(A0 @ al, P_.ravel(), atol=1e-8)
            FP = np.tensordot(al, Wphi, 1)
            for i_, Z_, P1 in zip(L1, Z1, P1s): Mstd[(i_, j_)] = Fr(rk(FP @ Z_), rk(P1))
        u0 = {l_: Fr(rk(Z_), rk(P_)) for l_, Z_, P_ in zip(L0, Z0, P0s)}; u1 = {l_: Fr(rk(Z_), rk(P_)) for l_, Z_, P_ in zip(L1, Z1, P1s)}
        if DATA[(c0, b)] is None: okSb = False; nstd += 1; continue
        TYb, unb, Msb = DATA[(c0, b)]
        okSb &= len(Z0) == TYb[0][2] and len(Z1) == TYb[1][2] and u0 == unb[0] and u1 == unb[1] and Mstd == Msb[0]
        if len(Z0) == 2:
            pw = np.eye(d1)
            for g in phiG: pw = pw @ g
            okSb &= np.allclose(pw, om1, atol=1e-8)                          # the volume element goes to +omega: kept
        nstd += 1
chk('std', okSs, 'pm.DG: numpy, no label, for the stages 0 and 1 of the %d chains from the 6 start cells with n <= 2 (Kronecker site matrices, the blocks as 16 x 16 matrices, C_1 as gamma x Omega, 1 x g): the centre as a null space, the minimal central idempotents as spectral projectors of a random symmetric central element, a minimal projection of each summand from a random symmetric element; each minimal projection of C_0 written in the words of C_0 and carried by the matrices of e_i Omega' % nstd)
chk('bit==std', okSb, 'pm.DG: for the same %d inclusions the matrix route gives the labels\' numbers: s at both stages, the order units (ratios of numpy ranks), the multiplicity matrix (rank of the image of a minimal projection in each summand over the rank of a minimal projection there: 16 on the diagonal), and the volume element of a two-summand stage carried to +omega' % nstd)
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ pm.CAR  the CAR chain
head('pm.CAR  the CAR chain Cl(j,j) in Cl(j+1,j+1) (GEN-015): s = 1, the vacuum a minimal idempotent, multiplicity 2, the Bratteli diagram')
t = time.time()
def car_eps(j): return (1, -1) * j                                          # e_i = bit 2i (square +1), f_i = bit 2i+1 (square -1), as cb.CAR
JC = 5; okCs = okCv = okCm = okCd = True; ucar = []
for j in range(JC + 1):
    A1 = BR(car_eps(j + 1)); h = Fr(1, 2)
    a = [{1 << (2 * i): h, 1 << (2 * i + 1): h} for i in range(j + 1)]; ad = [{1 << (2 * i): h, 1 << (2 * i + 1): -h} for i in range(j + 1)]
    Pj = {0: Fr(1)}
    for i in range(j): Pj = A1.mul(Pj, A1.mul(a[i], ad[i]))                 # the vacuum of j modes (labels in the first 2j bits: the prefix)
    Pj1 = A1.mul(Pj, A1.mul(a[j], ad[j]))
    okCs &= (ltype_eps(car_eps(j)) if j else ('R', 1, 1)) == ('R', 1 << j, 1) and ltype_eps(car_eps(j + 1)) == ('R', 1 << (j + 1), 1)
    okCv &= A1.mul(Pj, Pj) == Pj and (4 ** j) * Pj.get(0, 0) == 1 << j; ucar.append(Fr(4 ** j) / ((4 ** j) * Pj.get(0, 0)))
    okCm &= (4 ** (j + 1)) * Pj.get(0, 0) == 2 * ((4 ** (j + 1)) * Pj1.get(0, 0)) and (4 ** (j + 1)) * Pj1.get(0, 0) == 1 << (j + 1)
    E2 = A1.mul(Pj, A1.mul(ad[j], a[j]))
    okCd &= A1.mul(E2, E2) == E2 and A1.mul(Pj1, E2) == {} and A1.mul(E2, Pj1) == {} and A1.add(Pj1, E2) == Pj and E2 == A1.mul(ad[j], A1.mul(Pj1, a[j])) and (4 ** (j + 1)) * E2.get(0, 0) == 1 << (j + 1)
chk('bit', okCs and okCv, 'pm.CAR: Cl(j,j), j = 0..%d, with the pairs interleaved: s = 1 (centre R, M_(2^j)(R) from the labels); the vacuum Pi_j = prod a_i a_i* is idempotent with tr L = 4^j 2^-j = 2^j, a minimal idempotent; the order unit 4^j / 2^j = 2^j: %s' % (JC, ', '.join(str(u_) for u_ in ucar)))
chk('bit', okCm and okCd, 'pm.CAR: in Cl(j+1,j+1) (the prefix) Pi_j has tr L = 2^(j+2), twice that of the minimal idempotent Pi_(j+1): multiplicity 2, and explicitly Pi_j = Pi_(j+1) + a*_(j+1) Pi_(j+1) a_(j+1), two orthogonal minimal idempotents (j = 0..%d): the Bratteli diagram 1 -> 2 -> 4 -> ... of the CAR algebra (standard, recalled) on its finite stages' % JC)
def _kron_f(ms):
    M = np.ones((1, 1))
    for m in ms: M = np.kron(M, m)
    return M
def jw(n):
    """Jordan-Wigner matrices (cb.CAR): c_k = sigma^- on site k with Z on the sites before it"""
    sm = np.array([[0., 1.], [0., 0.]]); out = []
    for k in range(n):
        fs = [np.eye(2)] * n
        for j in range(k): fs[n - 1 - j] = np.diag([1., -1.])
        fs[n - 1 - k] = sm; out.append(_kron_f(fs))
    return out
okJ = True
for j in range(JC):
    cj = jw(j + 1); Pv = np.eye(2 ** (j + 1))
    for i in range(j): Pv = Pv @ (cj[i] @ cj[i].T)
    Pv1 = Pv @ (cj[j] @ cj[j].T); E2 = Pv @ (cj[j].T @ cj[j])
    okJ &= rk(Pv) == 2 * rk(Pv1) == 2 and rk(E2) == 1 and np.allclose(Pv1 + E2, Pv) and np.allclose(Pv1 @ E2, 0) and Fr(2 ** (j + 1), rk(Pv1)) == 2 * ucar[j]
chk('bit==std', okJ, 'pm.CAR: Jordan-Wigner matrices (numpy, no label), j + 1 = 1..%d modes: the vacuum of the first j modes has rank 2, the vacuum of j + 1 rank 1, the decomposition into two rank-1 projections; the multiplicity 2 and the order unit 2^(j+1) equal the labels\'' % JC)
note('not computed: the limit of either chain, its completion and its ordered group; Elliott\'s classification of AF algebras by the dimension group and Glimm\'s of UHF algebras by the supernatural number (2^inf), stated for complex C*-algebras, are cited, not entered')
note('(%.1f s, total %.1f s)' % (time.time() - t, time.time() - T0))
finish('PERIOD-MAP')
