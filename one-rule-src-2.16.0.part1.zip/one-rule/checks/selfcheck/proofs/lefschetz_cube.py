#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""lefschetz_cube.py: the Lefschetz fixed-point formula (Atiyah-Bott) in its finite form, on the cube complex of the labels.
python3 lefschetz_cube.py [--fault NAME]

The complex (LNC-140): the cells are the arrows S -> T of the cube category (S a subset of T a subset of the n bits), the cell of dimension
|T \\ S| being the face of the cube [0,1]^n with the coordinates in S fixed at 1 and those outside T at 0, oriented by the blade e_(T\\S);
the boundary d(S -> T) = sum over i in T \\ S of s(i, T \\ S \\ i) [(S + i -> T) - (S -> T - i)], s the bit rule's reordering sign; d^2 = 0 and
the homology is that of a point.  The symmetries of the cube are the 2^n n! signed permutations g = (pi, F): x -> pi(x) with the coordinates
in F reversed.  On a cell g acts by relabelling, with the sign of the blade e_(T\\S) -> e_(pi(T\\S)) under the bit rule (the sorting sign of
the permuted generators) times (-1)^|F meet (T\\S)| (a reversed free coordinate reverses the orientation).
L1. every g is a chain map (d g = g d, exact), n <= 5: the bit-rule sign is the right orientation sign.
L2. the Lefschetz number L(g) = sum_d (-1)^d tr(g on C_d) = the signed count of the cells g carries to themselves, = 1 for all 2^n n!
    symmetries, n <= 5 (the trace of g on the homology of a point); the number of fixed cells itself varies (printed by class).
L3. the heat-kernel form: with the Laplacian H = d d* + d* d, the supertrace str(g H^j) = sum_d (-1)^d tr(g H^j on C_d) vanishes for
    j = 1 .. 2n (exact integers), so str(g e^(-beta H)) = L(g) = 1 for every beta: the non-zero eigenvalues pair off between even and odd
    degrees, g-equivariantly (the finite case of index D = Tr e^(-t D*D) - Tr e^(-t D D*) with the symmetry inserted: Atiyah-Bott).
[bit]  the cells, the boundary, the signs and the Laplacian from the bit rule (steps15_17/bitcliff.py); exact integer traces.
[std]  the homology by integer ranks of the boundary (Z in degree 0, 0 above), on which every g acts as the identity: L(g) = 1 by the
       homological definition; numpy: str(g expm(-beta H)) at beta = 1/3, 1, 2 for 40 random symmetries, n = 4, equal to 1 within 1e-9.
[ctl]  NOSIGN (the orientation sign of a reversed coordinate dropped: not a chain map, and the signed counts are not all 1), BETA (the
       supertrace of g H asserted non-zero).
Scope: n = 1..5 (bit, exact), n = 4 (numpy).  Standard library, numpy, scipy.
Command: python3 lefschetz_cube.py   (from this folder, or python3 selfcheck/proofs/lefschetz_cube.py from the root of the checks)."""
import os, sys, itertools, time, random
import numpy as np
import scipy.linalg

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p)
from bitcliff import Alg, sig, pc

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('NOSIGN', 'BETA')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time()

class Cube:
    def __init__(self, n):
        self.n = n; self.alg = Alg(sig(0, 0, n)); full = (1 << n) - 1
        self.cells = [(S, T) for T in range(1 << n) for S in range(1 << n) if S & T == S]
        self.idx = {c: i for i, c in enumerate(self.cells)}
        self.dim = [pc(T ^ S) for S, T in self.cells]
        self.bydim = {d: [i for i, c in enumerate(self.cells) if self.dim[i] == d] for d in range(n + 1)}
        self.full = full
    def boundary(self):
        """d as a dict of columns: cell -> {cell: coefficient}"""
        D = {}
        for (S, T) in self.cells:
            A = T ^ S; col = {}
            for i in range(self.n):
                if A >> i & 1:
                    s = self.alg.blade_mul(1 << i, A ^ (1 << i))[0]                        # e_A = s e_i e_(A - i): the sign of removing i
                    col[(S | 1 << i, T)] = col.get((S | 1 << i, T), 0) + s
                    col[(S, T ^ (1 << i))] = col.get((S, T ^ (1 << i)), 0) - s
            D[(S, T)] = col
        return D
    def act(self, pi, Fm, cell, nosign=False):
        """the image of a cell under the signed permutation (pi, F) and the orientation sign"""
        S, T = cell; A = T ^ S; n = self.n; full = self.full
        ones = (S & ~Fm) | (~T & full & Fm); zeros = (~T & full & ~Fm) | (S & Fm)
        pmap = lambda M: sum(1 << pi[i] for i in range(n) if M >> i & 1)
        S2 = pmap(ones) & full; Z2 = pmap(zeros) & full; T2 = full & ~Z2
        # the sign: e_(pi(a_1)) ... e_(pi(a_k)) = sign . e_(pi(A)) by the bit rule, for a_1 < ... < a_k the bits of A
        prod = {0: 1}
        for i in range(n):
            if A >> i & 1: prod = self.alg.mul(prod, {1 << pi[i]: 1})
        (lab, sgn), = prod.items(); assert lab == pmap(A)
        if not nosign and pc(A & Fm) % 2: sgn = -sgn
        return (S2, T2), sgn

def dense_boundary(cube, D):
    m = len(cube.cells); M = np.zeros((m, m), dtype=np.int64)
    for c, col in D.items():
        j = cube.idx[c]
        for c2, v in col.items(): M[cube.idx[c2], j] += v
    return M
def sym_action(cube, pi, Fm, nosign=False):
    """the symmetry on the cells: image indices, signs, and the fixed cells (dimension, sign)"""
    img = np.zeros(len(cube.cells), dtype=np.int64); sgn = np.zeros(len(cube.cells), dtype=np.int64); fixed = []
    for i, c in enumerate(cube.cells):
        c2, s = cube.act(pi, Fm, c, nosign); img[i] = cube.idx[c2]; sgn[i] = s
        if c2 == c: fixed.append((cube.dim[i], s))
    return img, sgn, fixed
def is_chain_map(cube, D, img, sgn):
    """d g = g d on every cell, through the boundary dict"""
    for i, c in enumerate(cube.cells):
        lhs = {}
        for c2, v in D[c].items():
            k = cube.idx[c2]; lhs[int(img[k])] = lhs.get(int(img[k]), 0) + v * int(sgn[k])
        rhs = {}
        for c2, v in D[cube.cells[int(img[i])]].items(): rhs[cube.idx[c2]] = rhs.get(cube.idx[c2], 0) + v * int(sgn[i])
        if {k: v for k, v in lhs.items() if v} != {k: v for k, v in rhs.items() if v}: return False
    return True
def signed_count(fixed): return sum((-1) ** d * s for d, s in fixed)
def supertrace_table(cube, img, sgn, powers):
    """str(g H^j) for the stored powers H^j as exact integers: str(g M) = sum_c sign_c (-1)^dim(c) M[g c, c]"""
    ar = np.arange(len(cube.cells)); par = np.array([(-1) ** d for d in cube.dim], dtype=np.int64)
    return {j: int(np.sum(sgn * par * M[img, ar])) for j, M in powers.items()}
def sym_matrix(cube, pi, Fm, nosign=False):
    img, sgn, fixed = sym_action(cube, pi, Fm, nosign); m = len(cube.cells); G = np.zeros((m, m), dtype=np.int64)
    G[img, np.arange(m)] = sgn; return G, fixed

head('L1-L3. the cube complex, its symmetries, the Lefschetz numbers and the supertraces, n = 1..5')
allok = {'chain': True, 'lef': True, 'str': True, 'd2': True}; summary = {}
rng = random.Random(5)
for n in range(1, 6):
    cube = Cube(n); D = cube.boundary(); Dm = dense_boundary(cube, D); m = len(cube.cells)
    d2 = not np.any(Dm @ Dm); allok['d2'] &= d2
    H = Dm @ Dm.T + Dm.T @ Dm
    powers = {}; P = np.eye(m, dtype=np.int64)
    for j in range(1, 2 * n + 1): P = P @ H; powers[j] = P
    syms = [(pi, Fm) for pi in itertools.permutations(range(n)) for Fm in range(1 << n)]
    chain = True; lefs = []; strs_zero = True; fixed_counts = {}
    for pi, Fm in syms:
        img, sgn, fixed = sym_action(cube, pi, Fm, nosign=(FAULT == 'NOSIGN'))
        chain &= is_chain_map(cube, D, img, sgn)
        L = signed_count(fixed); lefs.append(L)
        fixed_counts[len(fixed)] = fixed_counts.get(len(fixed), 0) + 1
        st = supertrace_table(cube, img, sgn, powers)
        strs_zero &= all(v == 0 for v in st.values())
    allok['chain'] &= chain; allok['lef'] &= all(L == 1 for L in lefs); allok['str'] &= strs_zero
    summary[n] = (m, len(syms), sorted(set(lefs)), dict(sorted(fixed_counts.items())), chain, strs_zero)
    print('  n = %d: %d cells, %d symmetries, chain maps: %s, Lefschetz numbers %s, fixed-cell counts {count: symmetries} = %s, str(g H^j) = 0 for j = 1..%d: %s' % (n, m, len(syms), chain, sorted(set(lefs)), dict(sorted(fixed_counts.items())), 2 * n, strs_zero), flush=True)
chk('bit', allok['d2'], 'lef.L1: d^2 = 0 on the cube complex of the labels, n = 1..5 (LNC-140)')
chk('bit', allok['chain'], 'lef.L1: all 2^n n! signed permutations act as chain maps (d g = g d, exact), n = 1..5, with the bit-rule sorting sign times (-1)^(reversed free coordinates) as the orientation sign')
chk('bit', allok['lef'], 'lef.L2: the Lefschetz number, the signed count of the cells carried to themselves, is 1 for every symmetry (%d of them at n = 5), while the number of fixed cells varies: at n = 3 %s' % (summary[5][1], summary[3][3]))
chk('bit', allok['str'], 'lef.L3: str(g H^j) = sum_d (-1)^d tr(g H^j | C_d) = 0 for j = 1..2n and every symmetry: str(g e^(-beta H)) = L(g) = 1 for every beta (the fixed-point formula with the heat kernel)')
# std: the homology, and numpy expm
cube4 = Cube(4); D4 = dense_boundary(cube4, cube4.boundary()); m4 = len(cube4.cells)
ranks = {}; betti = {}
for d in range(0, 5):
    rows_d = cube4.bydim[d]; rows_dm = cube4.bydim[d - 1] if d else []
    Bd = D4[np.ix_(rows_dm, rows_d)] if d else np.zeros((0, len(rows_d)), dtype=np.int64)
    ranks[d] = np.linalg.matrix_rank(Bd.astype(float)) if Bd.size else 0
for d in range(0, 5): betti[d] = int(len(cube4.bydim[d]) - ranks[d] - (ranks[d + 1] if d < 4 else 0))
chk('std', [betti[d] for d in range(5)] == [1, 0, 0, 0, 0], 'lef.L2: the Betti numbers of the cube complex at n = 4 by numpy ranks of the boundary: %s (a point), so every chain map that fixes the vertex class has Lefschetz number 1 (homological definition)' % [betti[d] for d in range(5)])
H4 = (D4 @ D4.T + D4.T @ D4).astype(float); signs = np.array([(-1) ** d for d in cube4.dim], dtype=float)
syms4 = [(pi, Fm) for pi in itertools.permutations(range(4)) for Fm in range(16)]; sample = rng.sample(syms4, 40)
numok = True; vals = []
for beta in (1 / 3, 1.0, 2.0):
    E = scipy.linalg.expm(-beta * H4)
    for pi, Fm in sample:
        G, _ = sym_matrix(cube4, pi, Fm); v = float(np.sum(signs * np.diag(G.astype(float) @ E))); vals.append(v); numok &= abs(v - 1) < 1e-9
chk('std', numok, 'lef.L3: numpy, str(g expm(-beta H)) at beta = 1/3, 1, 2 for 40 random symmetries at n = 4: all equal to 1 (max deviation %.1e)' % max(abs(v - 1) for v in vals))
c3 = Cube(3); D3d = c3.boundary(); D3 = dense_boundary(c3, D3d); H3 = D3 @ D3.T + D3.T @ D3
bad_chain = 0; bad_L = 0
for pi in itertools.permutations(range(3)):
    for Fm in range(8):
        img, sgn, fixed = sym_action(c3, pi, Fm, nosign=True)
        bad_chain += not is_chain_map(c3, D3d, img, sgn); bad_L += signed_count(fixed) != 1
chk('ctl', bad_chain > 0 and bad_L > 0, 'lef: with the orientation sign of a reversed coordinate dropped (NOSIGN), at n = 3 %d of 48 maps are not chain maps and %d signed counts differ from 1' % (bad_chain, bad_L))
img, sgn, _ = sym_action(c3, (1, 0, 2), 0); st1 = supertrace_table(c3, img, sgn, {1: H3})[1]
chk('ctl', st1 == (1 if FAULT == 'BETA' else 0) or (FAULT != 'BETA' and st1 == 0), 'lef.L3: str(g H) for the transposition of two axes at n = 3 is %d (BETA asserts it is not 0)' % st1)
if FAULT == 'BETA': chk('ctl', st1 != 0, 'lef.L3: str(g H) != 0 asserted (BETA)')
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('LEFSCHETZ-CUBE')
