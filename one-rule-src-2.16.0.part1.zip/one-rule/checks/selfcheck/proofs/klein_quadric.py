#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""klein_quadric.py: the Klein correspondence over F2 in the labels of Cl(3,3) = M_8(R): the lines of PG(3,2) are the blades of square +1,
two lines meet exactly when their blades commute, and the points and planes of PG(3,2) are the two families of totally singular planes
of the label quadric.      python3 klein_quadric.py [--fault NAME]

The label quadric of a cell (polar_spaces.py, P): Q(a) = [e_a^2 = -1] on the 2^n labels, with polar form beta(a,b) = [e_a e_b = -e_b e_a]
(a + b singular with a and b exactly when they commute).  For Cl(3,3) the form is hyperbolic (the cell is M_8(R), Witt index 3).
K1. Cl(m,m), m = 1..5: the non-zero singular labels number (2^m - 1)(2^(m-1) + 1) = 2, 9, 35, 135, 527 (the hyperbolic quadric Q+(2m-1, 2);
    the 9 of Cl(2,2) (LNC-059's Peres-Mermin square) and the 135 of Cl(8,0) (polar.F1) are the same series).
K2. Cl(3,3): 35 singular points, 105 totally singular lines, 30 totally singular planes in two families of 15 (two planes of the same family
    meet in a point, of different families in a line or not at all); the control Cl(6,0) (elliptic, M_4(H)) has 27 points and no plane.
K3. the Klein map: the lines of PG(3,2) (35 two-dimensional subspaces of F2^4) have Pluecker coordinates p_ij = u_i v_j - u_j v_i in F2^6 on
    the quadric p01 p23 + p02 p13 + p03 p12 = 0; an explicit isometry of that quadric onto the label quadric (hyperbolic bases on both sides)
    sends the 35 lines to the 35 singular blades; two lines meet (share a point) exactly when their blades commute, the 7 lines through a
    point go to one family of planes and the 7 lines in a plane to the other.
[bit]  squares and commutation signs from the bit rule (steps15_17/bitcliff.py); subspaces by enumeration over F2.
[std]  Pluecker coordinates and the incidence of lines from vectors over F2 (no label): the counts 35, 15 + 15 and the meeting rule by
       intersecting subspaces; the counts (2^m - 1)(2^(m-1) + 1) by the formula (recalled).
[ctl]  ELLIPTIC (Cl(6,0) asserted to carry 35 points and 30 planes), COMMUTE (meeting lines asserted to anticommute).
Scope: Cl(m,m), m <= 5 (K1); Cl(3,3), Cl(6,0) (K2); PG(3,2) (K3).  Standard library only.
Command: python3 klein_quadric.py   (from this folder, or python3 selfcheck/proofs/klein_quadric.py from the root of the checks)."""
import os, sys, itertools, time

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p)
from bitcliff import Alg, sig, pc

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('ELLIPTIC', 'COMMUTE')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time()

def label_quadric(p, q):
    alg = Alg(sig(p, q)); N = alg.N
    Q = [0 if alg.sq(a) == 1 else 1 for a in range(N)]
    B = lambda a, b: 0 if alg.comm_sign(a, b) == 1 else 1
    return alg, Q, B
def span(vs):
    S = {0}
    for v in vs: S |= {s ^ v for s in S}
    return S
def subspaces(N, k, pred):
    """all k-dimensional subspaces of F2^n (N = 2^n) whose non-zero vectors all satisfy pred, as frozensets"""
    out = set(); vecs = [a for a in range(1, N) if pred(a)]
    def rec(basis, start):
        if len(basis) == k: out.add(frozenset(span(basis))); return
        S = span(basis)
        for i in range(start, len(vecs)):
            v = vecs[i]
            if v in S: continue
            S2 = span(basis + [v])
            if all(x == 0 or pred(x) for x in S2): rec(basis + [v], i + 1)
    rec([], 0)
    return out

head('K1. singular points of the label quadric of Cl(m,m), m = 1..5')
counts = []
for m in range(1, 6):
    alg, Q, B = label_quadric(m, m); counts.append(sum(1 for a in range(1, alg.N) if Q[a] == 0))
chk('bit', counts == [(2 ** m - 1) * (2 ** (m - 1) + 1) for m in range(1, 6)], 'kle.K1: Cl(m,m), m = 1..5: %s non-zero labels of square +1 = (2^m - 1)(2^(m-1) + 1), the points of the hyperbolic quadric Q+(2m-1, 2) (recalled formula); 9 at Cl(2,2), 35 at Cl(3,3), 135 as for Cl(8,0)' % counts)

head('K2. Cl(3,3): the points, lines and planes of the quadric, and the elliptic control Cl(6,0)')
def quadric_data(p, q):
    alg, Q, B = label_quadric(p, q); N = alg.N
    pts = [a for a in range(1, N) if Q[a] == 0]
    sing = lambda a: Q[a] == 0
    lines = subspaces(N, 2, sing); planes = subspaces(N, 3, sing)
    return alg, Q, B, pts, lines, planes
alg33, Q33, B33, pts, lines, planes = quadric_data(3, 3)
planes = sorted(planes, key=lambda P: sorted(P))
def meet_dim(P1, P2): return pc(len(P1 & P2)) - 1 if len(P1 & P2) > 0 else 0
# the two families: same family iff dim of the intersection has the parity of the plane dimension (planes: meet in a point (dim 1) or coincide (3): odd)
fam = [None] * len(planes); fam[0] = 0; changed = True
while changed:
    changed = False
    for i, P1 in enumerate(planes):
        if fam[i] is None: continue
        for j, P2 in enumerate(planes):
            if fam[j] is None:
                d = (len(P1 & P2)).bit_length() - 1
                fam[j] = fam[i] if d % 2 == 1 else 1 - fam[i]; changed = True
consistent = all(((len(P1 & P2)).bit_length() - 1) % 2 == (1 if fam[i] == fam[j] else 0) for i, P1 in enumerate(planes) for j, P2 in enumerate(planes))
alg60, Q60, B60, pts60, lines60, planes60 = quadric_data(6, 0)
want_pts, want_planes = (35, 30)
if FAULT == 'ELLIPTIC': ok_e = len(pts60) == 35 and len(planes60) == 30
else: ok_e = len(pts60) == 27 and len(planes60) == 0
chk('bit', len(pts) == 35 and len(lines) == 105 and len(planes) == 30 and consistent and fam.count(0) == fam.count(1) == 15,
    'kle.K2: Cl(3,3): %d singular points, %d totally singular lines, %d totally singular planes in two families of %d and %d (same family: the planes meet in a point or coincide; different families: in a line or not at all)' % (len(pts), len(lines), len(planes), fam.count(0), fam.count(1)))
chk('ctl' if FAULT != 'ELLIPTIC' else 'bit', ok_e, 'kle.K2: Cl(6,0) (M_4(H), the elliptic quadric): %d singular points, %d totally singular lines, %d planes%s' % (len(pts60), len(lines60), len(planes60), ' (ELLIPTIC asserts 35 and 30)' if FAULT == 'ELLIPTIC' else ''))

head('K3. the Klein map: lines of PG(3,2) -> singular blades of Cl(3,3)')
# PG(3,2): points = non-zero vectors of F2^4 (bits 0..3), lines = 2-dimensional subspaces, planes = 3-dimensional subspaces
P4 = list(range(1, 16))
L4 = sorted({frozenset(span([u, v]) - {0}) for u in P4 for v in P4 if u != v})
PL4 = sorted({frozenset(span([u, v, w]) - {0}) for u, v, w in itertools.combinations(P4, 3) if len(span([u, v, w])) == 8})
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
def pluecker(line):
    u, v = sorted(line)[:2]
    bit = lambda x, i: x >> i & 1
    return sum(((bit(u, i) * bit(v, j) + bit(u, j) * bit(v, i)) % 2) << k for k, (i, j) in enumerate(PAIRS))
def qpl(x):                                                                 # p01 p23 + p02 p13 + p03 p12 over F2
    b = lambda k: x >> k & 1
    return (b(0) * b(5) + b(1) * b(4) + b(2) * b(3)) % 2
PLK = {ln: pluecker(ln) for ln in L4}
okpl = all(qpl(PLK[ln]) == 0 for ln in L4) and len(set(PLK.values())) == 35 and len(L4) == 35 and len(PL4) == 15
chk('std', okpl, 'kle.K3: PG(3,2) has 15 points, %d lines and %d planes; the Pluecker coordinates of the lines are 35 distinct vectors of F2^6, all on the quadric p01 p23 + p02 p13 + p03 p12 = 0' % (len(L4), len(PL4)))
# hyperbolic bases: Pluecker side (e01, e23), (e02, e13), (e03, e12) with q(e_ij) = 0, b(e01, e23) = 1; label side by search
def bpl(x, y): return (qpl(x ^ y) + qpl(x) + qpl(y)) % 2
HP = [(1 << 0, 1 << 5), (1 << 1, 1 << 4), (1 << 2, 1 << 3)]
assert all(qpl(x) == 0 and qpl(y) == 0 and bpl(x, y) == 1 for x, y in HP) and all(bpl(a, b) == 0 for (x1, y1), (x2, y2) in itertools.combinations(HP, 2) for a in (x1, y1) for b in (x2, y2))
def hyperbolic_basis(N, Q, B):
    pairs = []; used = []
    for _ in range(3):
        found = None
        for x in range(1, N):
            if Q[x] or any(B(x, u) for u in used): continue
            for y in range(1, N):
                if Q[y] or B(x, y) != 1 or any(B(y, u) for u in used): continue
                found = (x, y); break
            if found: break
        pairs.append(found); used += list(found)
    return pairs
HL = hyperbolic_basis(alg33.N, Q33, B33)
def iso(x):                                                                 # the linear map sending the Pluecker hyperbolic basis to the label one
    out = 0
    for (a, b), (c, d) in zip(HP, HL):
        if x & a: out ^= c
        if x & b: out ^= d
    return out
img = {ln: iso(PLK[ln]) for ln in L4}
ok_iso = all(Q33[iso(x)] == qpl(x) for x in range(64)) and all(B33(iso(x), iso(y)) == bpl(x, y) for x in range(64) for y in range(64))
ok_pts = sorted(img.values()) == sorted(pts)
chk('bit==std', ok_iso and ok_pts, 'kle.K3: the map of hyperbolic bases is an isometry of the Pluecker quadric onto the label quadric (all 64 vectors, all 4096 pairs); it sends the 35 lines of PG(3,2) onto the 35 blades of square +1 of Cl(3,3)')
meet = lambda l1, l2: len(l1 & l2) > 0
want_sign = -1 if FAULT == 'COMMUTE' else 1
ok_meet = all((alg33.comm_sign(img[l1], img[l2]) == want_sign) == meet(l1, l2) for l1, l2 in itertools.combinations(L4, 2))
n_meet = sum(1 for l1, l2 in itertools.combinations(L4, 2) if meet(l1, l2))
chk('bit==std', ok_meet, 'kle.K3: two distinct lines of PG(3,2) meet exactly when their blades %s (%d meeting pairs of 595; the rest %s)' % ('anticommute' if FAULT == 'COMMUTE' else 'commute', n_meet, 'commute' if FAULT == 'COMMUTE' else 'anticommute'))
star = {pt: frozenset(span([img[ln] for ln in L4 if pt in ln])) for pt in P4}
ruled = {pl: frozenset(span([img[ln] for ln in L4 if ln <= pl])) for pl in PL4}
fam_of = {P: fam[i] for i, P in enumerate(planes)}
ok_fam = all(s in fam_of for s in star.values()) and all(r in fam_of for r in ruled.values()) and len({fam_of[s] for s in star.values()}) == 1 and len({fam_of[r] for r in ruled.values()}) == 1 and {fam_of[s] for s in star.values()} != {fam_of[r] for r in ruled.values()}
chk('bit==std', ok_fam and len(set(star.values())) == 15 and len(set(ruled.values())) == 15, 'kle.K3: the 7 lines through a point span a totally singular plane (15 planes, one family) and the 7 lines in a plane the other (15 planes, the other family): the points and planes of PG(3,2) are the two families')
chk('ctl', not all((alg33.comm_sign(img[l1], img[l2]) == -1) == meet(l1, l2) for l1, l2 in itertools.combinations(L4, 2)), 'kle.K3: with anticommutation in place of commutation the meeting rule fails (COMMUTE)')
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('KLEIN-QUADRIC')
