#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""kep_pauli.py: Pauli's algebraic hydrogen spectrum from the hidden so(4), classical and quantum, with the shells built on the labels.
      python3 kep_pauli.py [--fault UNEQUAL|SIGN|CLASSIC|ESIGN|KAPPA]

Conventions: H = |p|^2/(2 mu) - k/r, L = x x p, A = p x L - mu k x/r (Laplace-Runge-Lenz); M = A/sqrt(-2 mu E) for E < 0, N = A/sqrt(2 mu E)
for E > 0. Quantum: hbar = mu = k = 1, p = -i grad, A = (p x L - L x p)/2 - x/r = p x L - i p - x/r, a real operator:
A_j = -(curl (x x grad))_j - d_j - x_j/r; L_j = -i (x x grad)_j, L^2 = -sum (x x grad)_j^2; H = -(1/2) Laplacian - 1/r.

kpg·1 (classical, exact).  Phase-space functions with exact first derivatives (forward derivatives in Fractions; r = |x| is rational at the
   points: x from Pythagorean quadruples) at 12 rational points (8 with E < 0, 4 with E > 0; (mu, k) = (1, 1), (3/2, 2/3), (2/3, 2)):
   [std] {L_i, L_j} = eps L_k, {L_i, A_j} = eps A_k, {A_i, A_j} = -2 mu H eps L_k, {H, L} = {H, A} = 0, L.A = 0, |A|^2 = mu^2 k^2 + 2 mu H |L|^2;
   for E < 0: L^2 + M^2 = -mu k^2/(2E), L.M = 0, and A+-^2 = (L +- M)^2/4 = -mu k^2/(8E): the two Casimirs are equal.
   [bit] the bivectors L = -e_j e_k/2, M = -e_k e_4/2 of the bit rule with squares (+1,+1,+1,eps) (bitcliff.Alg): [L,L] = L, [L,M] = M,
   [M,M] = eps L. [bit==std] the Poisson brackets of (L, M) at the E < 0 points and of (L, N) at the E > 0 points are the bit-rule brackets for
   eps = +1 (so(4)) and eps = -1 (so(3,1)), entry by entry (with A = sqrt(-+2 mu E) M or N the comparison needs no square root).
kpg·2 (quantum, exact operator identities).  Functions sum c x^a y^b z^c r^k (k in Z) times exp(-s r), reduced by r^2 = x^2 + y^2 + z^2
   (a normal form: multiply by an even power of r to clear negative exponents, then r^(2m+e) -> (x^2+y^2+z^2)^m r^e, e in {0, 1}).
   [std] [H, A_j] = 0, [H, L_j] = 0, L.A = A.L = 0, [L_i, A_j] = i eps A_k, [A_i, A_j] = -2i H eps L_k, A^2 = 1 + 2H(L^2 + 1) (that is
   A^2 = mu^2 k^2 + 2 mu H (L^2 + hbar^2)). Each identity is a differential operator P of order <= 4 with coefficients in Q[x, y, z, r, 1/r]; P = 0
   iff P(x^b) = 0 for the 35 monomials with |b| <= 4 (P(x^b) = sum over a <= b of c_a b!/(b-a)! x^(b-a): by induction on b every coefficient
   c_a with |a| <= 4 vanishes). So these lines check the operator identities themselves, for all functions, not on a sample.
kpg·3 (the shells on the labels).  [bit] the bivectors of Cl(4,0) act on the four label vectors by v -> [B, v] (exact 4 x 4 matrices), and on
   polynomials in the four coordinates by D_B f = -sum (B u)_b d_b f (a Lie algebra homomorphism, checked on monomials); the harmonic
   homogeneous polynomials of degree d = n - 1 (Fock's shells: kernel of the Laplacian, exact) for n = 1..6 have dimension n^2;
   -sum A_i^2 = -sum B_i^2 = j(j+1) on them (j = d/2), L.M = 0, -(L^2 + M^2) = n^2 - 1, and -L^2 has the eigenvalues l(l+1) with multiplicity
   2l + 1, l = 0..n-1. With the identity of kpg·2 in the form M^2 + L^2 + 1 = -1/(2E) (M = A/sqrt(-2E) on an eigenspace of H with E < 0):
   E_n = -1/(2 n^2) = -1/2, -1/8, -1/18, -1/32, -1/50, -1/72 (mu k^2 = 1; exact). That every finite-dimensional irreducible representation of
   su(2) + su(2) is a V_j x V_j' (Cartan-Weyl) and the Hilbert-space facts (self-adjointness, the eigenspaces are finite-dimensional) are recalled.
kpg·4 (independent routes).  [std] textbook su(2) in a rational basis (J+ e_m = e_(m+1), J- e_m = (j+m)(j-m+1) e_(m-1), Jz e_m = m e_m) on
   V_j x V_j, 2j = 0..5: the same Casimirs, dimensions and l-content; the Schroedinger equation in three dimensions, exact: for n = 1..5 and
   l = 0..n-1, every harmonic polynomial h of degree l (a basis of the 2l+1 of them) times Q(r) exp(-r/n), Q of degree n - l - 1, solves
   H psi = -1/(2n^2) psi for one Q (a one-dimensional solution space), and the n^2 states are independent (exact rank).
   [bit==std] the same E_n, dimensions and l-content for n = 1..5.
kpg·5 (controls; each --fault puts the wrong version into the main line, which must then FAIL):
   UNEQUAL  the module of the six bivectors ((1,0) + (0,1)) in place of the shell n = 2: A^2 != B^2, L.M != 0, -1/(2E) = 5, no Balmer level;
   SIGN     A^2 = 1 + 2H(L^2 - 1) as the operator identity; CLASSIC A^2 = 1 + 2H L^2; ESIGN |A|^2 = mu^2 k^2 - 2 mu H |L|^2 at the points;
   KAPPA    the Schroedinger route with exp(-r/(n+1)) at E = -1/(2n^2): no solution.
Scope: as stated per line; exact Fractions throughout (no floats). Pauli, Ueber das Wasserstoffspektrum vom Standpunkt der neuen
Quantenmechanik; V. Fock, Zur Theorie des Wasserstoffatoms: recalled for the form of the identities; every identity used is computed here.
The script builds no object of the gravity engine (Forms, Lie, Grav): the engine faults M1-M8 do not reach it; its controls are its own.
Command: python3 kep_pauli.py (from this folder, or python3 selfcheck/proofs/kep_pauli.py from the package root). Standard library only."""
import os, sys, itertools, random
from fractions import Fraction as Fr
from math import factorial

_here = os.path.dirname(os.path.abspath(__file__))
_bc = os.path.join(os.path.dirname(_here), 'steps15_17')
if not os.path.isfile(os.path.join(_bc, 'bitcliff.py')): raise SystemExit('bitcliff.py not found in ' + _bc + ': this file belongs in selfcheck/proofs/ of the package')
if _bc not in sys.path: sys.path.insert(0, _bc)
from bitcliff import Alg

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[0 if cond else 1] += 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('UNEQUAL', 'SIGN', 'CLASSIC', 'ESIGN', 'KAPPA')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
EPS = {(0, 1, 2): 1, (1, 2, 0): 1, (2, 0, 1): 1, (0, 2, 1): -1, (2, 1, 0): -1, (1, 0, 2): -1}
def eps(i, j, k): return EPS.get((i, j, k), 0)

# ------------------------------------------------------------------------------------------------ exact linear algebra over Q
def rref_null(rows, ncols):
    """basis of the null space of the matrix (list of rows), and the free columns (a vector of the null space is fixed by its free entries)"""
    M = [list(r) for r in rows]; piv = []; rk = 0
    for c in range(ncols):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / Fr(M[rk][c]); M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncols) if c not in piv]; basis = []
    for fc in free:
        v = [Fr(0)] * ncols; v[fc] = Fr(1)
        for i, pc_ in enumerate(piv): v[pc_] = -M[i][fc]
        basis.append(v)
    return basis, free
def rank(rows, ncols):
    return ncols - len(rref_null(rows, ncols)[0]) if rows else 0

# ================================================================================================ kpg·1: classical, exact at rational points
class GD:
    """value and exact gradient in the six phase-space variables (x1, x2, x3, p1, p2, p3)"""
    __slots__ = ('v', 'g')
    def __init__(self, v, g=None): self.v = Fr(v); self.g = g if g is not None else [Fr(0)] * 6
    def __add__(s, o): o = o if isinstance(o, GD) else GD(o); return GD(s.v + o.v, [a + b for a, b in zip(s.g, o.g)])
    __radd__ = __add__
    def __neg__(s): return GD(-s.v, [-a for a in s.g])
    def __sub__(s, o): return s + (-(o if isinstance(o, GD) else GD(o)))
    def __rsub__(s, o): return GD(o) - s
    def __mul__(s, o):
        if not isinstance(o, GD): o = Fr(o); return GD(s.v * o, [a * o for a in s.g])
        return GD(s.v * o.v, [a * o.v + s.v * b for a, b in zip(s.g, o.g)])
    __rmul__ = __mul__
    def inv(s): return GD(1 / s.v, [-a / s.v ** 2 for a in s.g])
def pb(f, g): return sum(f.g[i] * g.g[3 + i] - f.g[3 + i] * g.g[i] for i in range(3))
def cross(a, b): return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def kepler_at(xv, pv, mu, k):
    X = [GD(xv[i], [Fr(int(j == i)) for j in range(6)]) for i in range(3)]; P = [GD(pv[i], [Fr(int(j == 3 + i)) for j in range(6)]) for i in range(3)]
    r0 = Fr(sum(c * c for c in xv)); rv = next(Fr(t) for t in range(1, 200) if t * t == r0)
    r = GD(rv, [Fr(xv[0]) / rv, Fr(xv[1]) / rv, Fr(xv[2]) / rv, Fr(0), Fr(0), Fr(0)]); ir = r.inv()
    H = dot(P, P) * Fr(1, 2) * (1 / Fr(mu)) - ir * Fr(k)
    L = cross(X, P); A = [a - x * ir * (Fr(mu) * Fr(k)) for a, x in zip(cross(P, L), X)]
    return H, L, A
QUADS = [(1, 2, 2), (2, 3, 6), (1, 4, 8), (4, 4, 7), (2, 6, 9), (6, 6, 7), (3, 4, 12), (2, 10, 11), (1, 12, 12), (8, 9, 12), (2, 5, 14), (8, 11, 16)]
MUK = [(Fr(1), Fr(1)), (Fr(3, 2), Fr(2, 3)), (Fr(2, 3), Fr(2))]
def phase_points():
    rng = random.Random(4101); out = []; neg = pos = 0; i = 0
    while neg < 8 or pos < 4:
        xv = QUADS[i % len(QUADS)]; mu, k = MUK[i % 3]; i += 1
        pv = [Fr(rng.randint(-3, 3), rng.randint(3, 12)) for _ in range(3)]
        r = next(t for t in range(1, 200) if t * t == sum(c * c for c in xv)); E = sum(c * c for c in pv) / (2 * mu) - k / r
        if pv == [0, 0, 0] or E == 0 or not any(cross(xv, pv)): continue
        if E < 0 and neg < 8: out.append((xv, pv, mu, k)); neg += 1
        elif E > 0 and pos < 4: out.append((xv, pv, mu, k)); pos += 1
    return out
def bit_structure(e4):
    """structure constants of (L1, L2, L3, M1, M2, M3), L = -e_j e_k / 2, M = -e_k e_4 / 2, squares (1, 1, 1, e4): C[X][Y] = {Z: c}"""
    Al = Alg((1, 1, 1, e4)); one = lambda m, c=1: {m: Fr(c)}
    Lp = [one(0b0110), one(0b0101, -1), one(0b0011)]; Mp = [one(0b1001), one(0b1010), one(0b1100)]
    B = [Al.scal(x, Fr(-1, 2)) for x in Lp + Mp]
    def coords(x):
        out = []
        for b in B:
            m = next(iter(b)); out.append(Fr(x.get(m, 0)) / b[m])
        rebuilt = {}
        for c, b in zip(out, B):
            for m, v in b.items(): rebuilt[m] = rebuilt.get(m, 0) + c * v
        assert {m: v for m, v in rebuilt.items() if v} == {m: v for m, v in x.items() if v}, 'bracket leaves the span'
        return out
    C = [[coords(Al.add(Al.mul(X, Y), Al.mul(Y, X), -1)) for Y in B] for X in B]
    return C

def part1():
    head('kpg·1: the classical algebra, exact Poisson brackets at 12 rational phase-space points [std]; the bit-rule bivectors [bit]')
    pts = phase_points(); okPB = okCons = okLA = okA2 = okCas = okEq = True; okBS = {1: True, -1: True}; nneg = npos = 0
    Cb = {1: bit_structure(1), -1: bit_structure(-1)}
    okBit = all(Cb[1][j][k][3 + l] == 0 and Cb[1][j][k][l] == eps(j, k, l) for j in range(3) for k in range(3) for l in range(3)) and \
        all(Cb[e][3 + j][3 + k][l] == e * eps(j, k, l) and Cb[e][j][3 + k][3 + l] == eps(j, k, l) for e in (1, -1) for j in range(3) for k in range(3) for l in range(3))
    sgnH = -1 if FAULT == 'ESIGN' else 1
    for xv, pv, mu, k in pts:
        H, L, A = kepler_at(xv, pv, mu, k); E = H.v
        for j in range(3):
            for kk in range(3):
                okPB &= pb(L[j], L[kk]) == sum(eps(j, kk, l) * L[l].v for l in range(3))
                okPB &= pb(L[j], A[kk]) == sum(eps(j, kk, l) * A[l].v for l in range(3))
                okPB &= pb(A[j], A[kk]) == -2 * mu * E * sum(eps(j, kk, l) * L[l].v for l in range(3))
            okCons &= pb(H, L[j]) == 0 and pb(H, A[j]) == 0
        Lv = [x.v for x in L]; Av = [x.v for x in A]; L2 = dot(Lv, Lv); A2 = dot(Av, Av); LA = dot(Lv, Av)
        okLA &= LA == 0; okA2 &= A2 == mu * mu * k * k + sgnH * 2 * mu * E * L2
        if E < 0:
            nneg += 1; M2 = A2 / (-2 * mu * E)
            okCas &= L2 + M2 == -mu * k * k / (2 * E)
            okEq &= (L2 + M2) / 4 == -mu * k * k / (8 * E)                         # A+-^2 = (L^2 + M^2 +- 2 L.M)/4 with L.M = L.A/sqrt(-2 mu E) = 0
        else: npos += 1
        # [bit==std]: {X, Y} = sum_Z c_bit Z with A = s M (E < 0, s = sqrt(-2 mu E)) or A = s N (E > 0, s = sqrt(2 mu E)): no square root needed
        e_ = 1 if E < 0 else -1; s2 = -2 * mu * E if E < 0 else 2 * mu * E; C = Cb[e_]
        for j in range(3):
            for kk in range(3):
                okBS[e_] &= pb(L[j], L[kk]) == sum(C[j][kk][l] * Lv[l] for l in range(3)) and all(C[j][kk][3 + l] == 0 for l in range(3))
                okBS[e_] &= pb(L[j], A[kk]) == sum(C[j][3 + kk][3 + l] * Av[l] for l in range(3)) and all(C[j][3 + kk][l] == 0 for l in range(3))
                okBS[e_] &= pb(A[j], A[kk]) == s2 * sum(C[3 + j][3 + kk][l] * Lv[l] for l in range(3)) and all(C[3 + j][3 + kk][3 + l] == 0 for l in range(3))
    muks = sorted(set((str(m), str(k)) for _, _, m, k in pts))
    chk('std', okPB and nneg == 8 and npos == 4, '{L_i,L_j} = eps L_k, {L_i,A_j} = eps A_k, {A_i,A_j} = -2 mu H eps L_k exactly at the 12 points (8 with E < 0, 4 with E > 0; (mu, k) in %s)' % ', '.join('(%s, %s)' % t for t in muks))
    chk('std', okCons, '{H, L_j} = {H, A_j} = 0 at the 12 points: L and A are conserved')
    chk('std', okLA and okA2, 'L.A = 0 and |A|^2 = mu^2 k^2 + 2 mu H |L|^2 at the 12 points' + (' [fault ESIGN: -2 mu H]' if FAULT == 'ESIGN' else ''))
    chk('std', okCas and okEq, 'E < 0 (8 points): L^2 + M^2 = -mu k^2/(2E) and L.M = 0, so the two Casimirs are equal: (L + M)^2/4 = (L - M)^2/4 = -mu k^2/(8E)')
    chk('bit', okBit, 'bit rule (bitcliff.Alg): L = -e_j e_k/2, M = -e_k e_4/2 with squares (+1,+1,+1,eps): [L_j,L_k] = L_l, [L_j,M_k] = M_l, [M_j,M_k] = eps L_l for eps = +1, -1 (all 36 brackets each)')
    chk('bit==std', okBS[1] and okBS[-1], 'the Poisson brackets of (L, M) at the 8 bound points are the bit-rule brackets of eps = +1 (so(4)), those of (L, N) at the 4 scattering points the brackets of eps = -1 (so(3,1)), entry by entry')
    # control: the wrong sign of the energy term
    H, L, A = kepler_at(*pts[0]); xv, pv, mu, k = pts[0]
    wrong = dot([x.v for x in A], [x.v for x in A]) == mu * mu * k * k - 2 * mu * H.v * dot([x.v for x in L], [x.v for x in L])
    chk('ctl', not wrong, '|A|^2 = mu^2 k^2 - 2 mu H |L|^2 (the wrong sign) fails at the first point (E = %s)' % H.v)

# ================================================================================================ kpg·2: the quantum operators, exact
class Fn:
    """sum c x^a y^b z^c r^k (keys (a, b, c, k), k in Z) times exp(-s r)"""
    __slots__ = ('t', 's')
    def __init__(self, t=None, s=0): self.t = {k: v for k, v in (t or {}).items() if v}; self.s = Fr(s)
def fadd(*terms):
    out = {}; s = None
    for c, f in terms:
        if s is None: s = f.s
        assert f.s == s
        for k, v in f.t.items(): out[k] = out.get(k, 0) + c * v
    return Fn(out, s if s is not None else 0)
def fdiff(f, i):
    out = {}
    for e, v in f.t.items():
        if e[i]:
            k = list(e); k[i] -= 1; k = tuple(k); out[k] = out.get(k, 0) + v * e[i]
        if e[3]:
            k = list(e); k[i] += 1; k[3] -= 2; k = tuple(k); out[k] = out.get(k, 0) + v * e[3]
        if f.s:
            k = list(e); k[i] += 1; k[3] -= 1; k = tuple(k); out[k] = out.get(k, 0) - v * f.s
    return Fn(out, f.s)
def fmulx(f, i): return Fn({tuple(e[j] + (1 if j == i else 0) for j in range(3)) + (e[3],): v for e, v in f.t.items()}, f.s)
def fmulr(f, m): return Fn({e[:3] + (e[3] + m,): v for e, v in f.t.items()}, f.s)
_R2P = {0: {(0, 0, 0): 1}}
def r2pow(m):
    if m not in _R2P:
        prev = r2pow(m - 1); out = {}
        for e, v in prev.items():
            for i in range(3):
                k = tuple(e[j] + (2 if j == i else 0) for j in range(3)); out[k] = out.get(k, 0) + v
        _R2P[m] = out
    return _R2P[m]
def normal_form(f, shift=None):
    """the coefficients of r^shift f after r^(2m+e) -> (x^2+y^2+z^2)^m r^e (e in {0, 1}); shift even, large enough to clear negative powers"""
    if shift is None:
        mk = min((e[3] for e in f.t), default=0); shift = max(0, -mk); shift += shift % 2
    out = {}
    for e, v in f.t.items():
        k = e[3] + shift; assert k >= 0; m, ee = divmod(k, 2)
        for q, w in r2pow(m).items():
            key = (e[0] + q[0], e[1] + q[1], e[2] + q[2], ee); out[key] = out.get(key, 0) + v * w
    return {k: v for k, v in out.items() if v}
def is_zero(f): return not normal_form(f)
def Lr(f, j):                                                      # (x x grad)_j f;  L_j = -i Lr_j
    a, b = [(1, 2), (2, 0), (0, 1)][j]
    return fadd((1, fmulx(fdiff(f, b), a)), (-1, fmulx(fdiff(f, a), b)))
def Aop(f, j):                                                     # A_j = -(curl Lr)_j - d_j - x_j / r
    terms = []
    for k in range(3):
        for l in range(3):
            e = eps(j, k, l)
            if e: terms.append((-e, fdiff(Lr(f, l), k)))
    terms += [(-1, fdiff(f, j)), (-1, fmulr(fmulx(f, j), -1))]
    return fadd(*terms)
def Hop(f): return fadd(*([(Fr(-1, 2), fdiff(fdiff(f, i), i)) for i in range(3)] + [(-1, fmulr(f, -1))]))
def L2op(f): return fadd(*[(-1, Lr(Lr(f, j), j)) for j in range(3)])
def monomials(dmax): return [e for d in range(dmax + 1) for e in itertools.product(range(d + 1), repeat=3) if sum(e) == d]

def part2():
    head('kpg·2: the quantum operators as exact differential-operator identities (order <= 4: decided on the 35 monomials of degree <= 4) [std]')
    mons = monomials(4); assert len(mons) == 35
    res = {'HA': True, 'HL': True, 'LA': True, 'AL': True, 'LrA': True, 'AA': True, 'A2': True}; ctlS = ctlC = True; seen = {}
    cpl = -1 if FAULT == 'SIGN' else (0 if FAULT == 'CLASSIC' else 1)
    for e in mons:
        f = Fn({e + (0,): Fr(1)}); Af = [Aop(f, j) for j in range(3)]; Hf = Hop(f); Lf = [Lr(f, j) for j in range(3)]
        res['HA'] &= all(is_zero(fadd((1, Hop(Af[j])), (-1, Aop(Hf, j)))) for j in range(3))
        res['HL'] &= all(is_zero(fadd((1, Hop(Lf[j])), (-1, Lr(Hf, j)))) for j in range(3))
        res['LA'] &= is_zero(fadd(*[(1, Lr(Af[j], j)) for j in range(3)]))
        res['AL'] &= is_zero(fadd(*[(1, Aop(Lf[j], j)) for j in range(3)]))
        for i in range(3):
            for j in range(3):
                if i == j: continue
                k = 3 - i - j
                res['LrA'] &= is_zero(fadd((1, Lr(Af[j], i)), (-1, Aop(Lf[i], j)), (eps(i, j, k), Af[k])))
                res['AA'] &= is_zero(fadd((1, Aop(Af[j], i)), (-1, Aop(Af[i], j)), (2 * eps(i, j, k), Hop(Lf[k]))))
        A2 = fadd(*[(1, Aop(Af[j], j)) for j in range(3)]); L2f = L2op(f)
        res['A2'] &= is_zero(fadd((1, A2), (-1, f), (-2, Hop(fadd((1, L2f), (cpl, f))))))
        ctlS &= not is_zero(fadd((1, A2), (-1, f), (-2, Hop(fadd((1, L2f), (-1, f)))))) if e == (0, 0, 0) else ctlS
        ctlC &= not is_zero(fadd((1, A2), (-1, f), (-2, Hop(L2f)))) if e == (0, 0, 0) else ctlC
    chk('std', res['HA'] and res['HL'], '[H, A_j] = 0 and [H, L_j] = 0 as operators (35 monomials, order <= 4): A and L commute with the Coulomb Hamiltonian')
    chk('std', res['LA'] and res['AL'], 'L.A = 0 and A.L = 0 as operators (the quantum form of L.A = 0)')
    chk('std', res['LrA'], '[L_i, A_j] = i eps_ijk A_k as operators: A is a vector operator')
    chk('std', res['AA'], '[A_i, A_j] = -2i H eps_ijk L_k as operators: on an eigenspace of H with E < 0, M = A/sqrt(-2E) gives [M_i, M_j] = i eps L_k (so(4))')
    chk('std', res['A2'], 'A^2 = 1 + 2H(L^2 + %s) as operators, that is A^2 = mu^2 k^2 + 2 mu H (L^2 + hbar^2) at hbar = mu = k = 1; on an eigenspace with E < 0: M^2 + L^2 + 1 = -1/(2E)' % cpl)
    chk('ctl', ctlS and ctlC, 'the wrong sign A^2 = 1 + 2H(L^2 - 1) and the classical form A^2 = 1 + 2H L^2 fail already on the constant function 1')

# ================================================================================================ kpg·3: the shells on the labels [bit]
def padd(*terms):
    out = {}
    for c, p in terms:
        for k, v in p.items(): out[k] = out.get(k, 0) + c * v
    return {k: v for k, v in out.items() if v}
def pdiff(p, i):
    out = {}
    for e, v in p.items():
        if e[i]:
            k = list(e); k[i] -= 1; k = tuple(k); out[k] = out.get(k, 0) + v * e[i]
    return out
def pmulu(p, i): return {tuple(e[j] + (1 if j == i else 0) for j in range(len(e))): v for e, v in p.items()}
def homog(nv, d): return [e for e in itertools.product(range(d + 1), repeat=nv) if sum(e) == d]
def harmonic_basis(nv, d):
    """basis of the harmonic homogeneous polynomials of degree d in nv variables (exact kernel of the Laplacian) and its free monomials"""
    B = homog(nv, d)
    if d < 2: return [{e: Fr(1)} for e in B], B, B
    T = homog(nv, d - 2); idx = {e: i for i, e in enumerate(T)}; cols = []
    for e in B:
        lap = padd(*[(1, pdiff(pdiff({e: Fr(1)}, i), i)) for i in range(nv)]); col = [Fr(0)] * len(T)
        for k, v in lap.items(): col[idx[k]] += v
        cols.append(col)
    rows = [[cols[j][i] for j in range(len(B))] for i in range(len(T))]
    basis, free = rref_null(rows, len(B))
    return [{B[j]: v for j, v in enumerate(vec) if v} for vec in basis], [B[j] for j in free], B
def label_ops():
    """D_B on polynomials in four variables for the bivectors L_i, M_i of Cl(4,0) (the bit rule, bitcliff.Alg), B acting on vectors by v -> [B, v]"""
    Al = Alg((1, 1, 1, 1)); one = lambda m, c=1: {m: Fr(c)}
    Lp = [one(0b0110), one(0b0101, -1), one(0b0011)]; Mp = [one(0b1001), one(0b1010), one(0b1100)]
    biv = [Al.scal(x, Fr(-1, 2)) for x in Lp + Mp]
    def vecmat(Bv):
        Mx = [[Fr(0)] * 4 for _ in range(4)]
        for a in range(4):
            img = Al.add(Al.mul(Bv, {1 << a: Fr(1)}), Al.mul({1 << a: Fr(1)}, Bv), -1)
            assert all(bin(m).count('1') == 1 for m in img)
            for m, v in img.items(): Mx[m.bit_length() - 1][a] += v
        return Mx
    mats = [vecmat(b) for b in biv]
    def D(Mx):
        def op(p): return padd(*[(-Mx[b][a], pmulu(pdiff(p, b), a)) for a in range(4) for b in range(4) if Mx[b][a]])
        return op
    return Al, biv, mats, [D(Mx) for Mx in mats]
def mat_in_basis(op, basis, free):
    """the matrix of op on the span of basis (free-entry coordinates: a vector of the span is fixed by its coefficients on the free monomials)"""
    cols = []
    for b in basis:
        img = op(b); cols.append([Fr(img.get(fm, 0)) for fm in free])
        rebuilt = padd(*[(c, bb) for c, bb in zip(cols[-1], basis)])
        assert rebuilt == {k: v for k, v in img.items() if v}, 'the operator leaves the span'
    return [[cols[j][i] for j in range(len(basis))] for i in range(len(free))]
def mmul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def madd(A, B, c=1): return [[a + c * b for a, b in zip(r, s)] for r, s in zip(A, B)]
def mscal(A, c): return [[c * a for a in r] for r in A]
def eye(n): return [[Fr(int(i == j)) for j in range(n)] for i in range(n)]
def is_scalar(A, c): return all(A[i][j] == (c if i == j else 0) for i in range(len(A)) for j in range(len(A)))
def l_content(C2):
    """{l: multiplicity} of the eigenvalues l(l+1) of the matrix C2 (exact null spaces), and whether they exhaust the dimension"""
    n = len(C2); out = {}
    for l in range(0, 13):
        m = n - rank(madd(C2, eye(n), -Fr(l * (l + 1))), n)
        if m: out[l] = m
    return out, sum(out.values()) == n
def casimirs_on(ops, basis, free):
    Ls = [mat_in_basis(op, basis, free) for op in ops[:3]]; Ms = [mat_in_basis(op, basis, free) for op in ops[3:]]
    As = [mscal(madd(l, m), Fr(1, 2)) for l, m in zip(Ls, Ms)]; Bs = [mscal(madd(l, m, -1), Fr(1, 2)) for l, m in zip(Ls, Ms)]
    neg = lambda Xs: mscal(madd(madd(mmul(Xs[0], Xs[0]), mmul(Xs[1], Xs[1])), mmul(Xs[2], Xs[2])), -1)
    A2, B2, L2, M2 = neg(As), neg(Bs), neg(Ls), neg(Ms)
    LM = madd(madd(mmul(Ls[0], Ms[0]), mmul(Ls[1], Ms[1])), mmul(Ls[2], Ms[2]))
    return A2, B2, L2, M2, LM
def adjoint_module(Al, biv):
    """the six bivectors under ad: the matrices of L_i, M_i on the bivector span (the module (1,0) + (0,1))"""
    def co(x): return [Fr(x.get(next(iter(b)), 0)) / b[next(iter(b))] for b in biv]
    return [[[co(Al.add(Al.mul(X, Y), Al.mul(Y, X), -1))[i] for Y in biv] for i in range(6)] for X in biv]

def part3():
    head('kpg·3: Fock\'s shells on the labels: harmonic polynomials on the four label vectors of Cl(4,0), the bit-rule so(4) acting [bit]')
    Al, biv, mats, ops = label_ops()
    # homomorphism: [D_X, D_Y] = D_[X,Y] on the monomials of degree <= 2 (first-order operators: decided there)
    def co(x): return [Fr(x.get(next(iter(b)), 0)) / b[next(iter(b))] for b in biv]
    hom = True
    for X in range(6):
        for Y in range(6):
            cxy = co(Al.add(Al.mul(biv[X], biv[Y]), Al.mul(biv[Y], biv[X]), -1))
            for e in [e for d in range(3) for e in homog(4, d)]:
                p = {e: Fr(1)}; lhs = padd((1, ops[X](ops[Y](p))), (-1, ops[Y](ops[X](p))))
                rhs = padd(*[(c, ops[Z](p)) for Z, c in enumerate(cxy) if c])
                hom &= lhs == rhs
    chk('bit', hom, 'D_B f = -sum (B u)_b d_b f, with B acting on the four label vectors by v -> [B, v], is a Lie algebra homomorphism on the six bivectors (all 36 brackets, monomials of degree <= 2)')
    table = {}; okDim = okCas = okLM = okL = True; energies = []
    for n in range(1, 7):
        d = n - 1; basis, free, B = harmonic_basis(4, d); N = len(basis)
        A2, B2, L2, M2, LM = casimirs_on(ops, basis, free); j = Fr(d, 2)
        if FAULT == 'UNEQUAL' and n == 2:
            ad = adjoint_module(Al, biv); Ls, Ms = ad[:3], ad[3:]; N = 6
            As = [mscal(madd(l, m), Fr(1, 2)) for l, m in zip(Ls, Ms)]; Bs = [mscal(madd(l, m, -1), Fr(1, 2)) for l, m in zip(Ls, Ms)]
            neg = lambda Xs: mscal(madd(madd(mmul(Xs[0], Xs[0]), mmul(Xs[1], Xs[1])), mmul(Xs[2], Xs[2])), -1)
            A2, B2, L2, M2 = neg(As), neg(Bs), neg(Ls), neg(Ms); LM = madd(madd(mmul(Ls[0], Ms[0]), mmul(Ls[1], Ms[1])), mmul(Ls[2], Ms[2]))
        okDim &= N == n * n
        okCas &= is_scalar(A2, j * (j + 1)) and is_scalar(B2, j * (j + 1))
        okLM &= is_scalar(LM, 0)
        S = madd(L2, M2); c = S[0][0]; okCas &= is_scalar(S, c) and c == n * n - 1
        lc, full = l_content(L2); okL &= full and lc == {l: 2 * l + 1 for l in range(n)}
        E = -1 / (2 * (c + 1)); energies.append(E); table[n] = (N, j * (j + 1), lc, E)
    chk('bit', okDim, 'the harmonic homogeneous polynomials of degree n - 1 on the four labels have dimension n^2 = %s (n = 1..6, exact kernel of the Laplacian)' % ', '.join(str(table[n][0]) for n in table))
    chk('bit', okCas, 'on the shell n: -sum A_i^2 = -sum B_i^2 = j(j+1) = %s with j = (n - 1)/2 (equal Casimirs), and -(L^2 + M^2) = n^2 - 1 (n = 1..6)' % ', '.join(str(table[n][1]) for n in table))
    chk('bit', okLM, 'L.M = sum L_i M_i = 0 on every shell n = 1..6 (equal Casimirs: L.M = A^2 - B^2)')
    chk('bit', okL, '-L^2 on the shell n has the eigenvalues l(l+1), l = 0..n-1, with multiplicity 2l + 1 (exact null spaces; n = 1..6): the angular momenta of the shell')
    want = [Fr(-1, 2 * n * n) for n in range(1, 7)]
    chk('bit', energies == want, 'with M^2 + L^2 + 1 = -1/(2E) (kpg·2): E_n = -1/(2(n^2 - 1 + 1)) = %s for n = 1..6 (mu k^2 = 1): the Balmer levels -mu k^2/(2 n^2)' % ', '.join(str(e) for e in energies))
    return table

# ================================================================================================ kpg·4: independent routes [std], [bit==std]
def spin_rational(j2):
    """J+, J-, Jz on V_j (j = j2/2) in the basis e_m, m = j, j-1, .., -j: J+ e_m = e_(m+1), J- e_m = (j+m)(j-m+1) e_(m-1)"""
    d = j2 + 1; j = Fr(j2, 2); ms = [j - t for t in range(d)]
    Jp = [[Fr(0)] * d for _ in range(d)]; Jm = [[Fr(0)] * d for _ in range(d)]; Jz = [[Fr(0)] * d for _ in range(d)]
    for t, m in enumerate(ms):
        Jz[t][t] = m
        if t > 0: Jp[t - 1][t] = Fr(1)
        if t < d - 1: Jm[t + 1][t] = (j + m) * (j - m + 1)
    return Jp, Jm, Jz
def kron(A, B): return [[a * b for a in ra for b in rb] for ra in A for rb in B]
def casimir_pm(Jp, Jm, Jz): return madd(mmul(Jz, Jz), mscal(madd(mmul(Jp, Jm), mmul(Jm, Jp)), Fr(1, 2)))
def schroedinger(n, l, kap, E):
    """the dimension of the solutions Q (degree <= n - l - 1) of (H - E)(h Q(r) exp(-kap r)) = 0 for every harmonic h of degree l; the states"""
    hb, hf, _ = harmonic_basis(3, l); dq = n - l - 1; dims = []; states = []
    for h in hb:
        cols = []
        for t in range(dq + 1):
            psi = Fn({e + (t,): v for e, v in h.items()}, kap); g = fadd((1, Hop(psi)), (-E, psi)); cols.append(normal_form(g, shift=4))
        keys = sorted(set(k for c in cols for k in c)); rows = [[c.get(k, 0) for c in cols] for k in keys]
        basis, _ = rref_null(rows, dq + 1) if rows else ([[Fr(int(i == t)) for i in range(dq + 1)] for t in range(dq + 1)], None)
        dims.append(len(basis))
        if len(basis) == 1:
            q = basis[0]; states.append(Fn({e + (t,): v * q[t] for t in range(dq + 1) for e, v in h.items()}, kap))
    return dims, states, len(hb)
def part4(table):
    head('kpg·4: textbook su(2) in a rational basis on V_j x V_j [std]; the Schroedinger equation in three dimensions [std]; [bit==std]')
    okStd = True; tstd = {}
    for j2 in range(0, 6):
        n = j2 + 1; j = Fr(j2, 2); Jp, Jm, Jz = spin_rational(j2); I = eye(j2 + 1)
        okStd &= is_scalar(casimir_pm(Jp, Jm, Jz), j * (j + 1)) and madd(mmul(Jp, Jm), mmul(Jm, Jp), -1) == mscal(Jz, 2)
        Ap, Am, Az = kron(Jp, I), kron(Jm, I), kron(Jz, I); Bp, Bm, Bz = kron(I, Jp), kron(I, Jm), kron(I, Jz)
        Lp, Lm, Lz = madd(Ap, Bp), madd(Am, Bm), madd(Az, Bz); Mp, Mm, Mz = madd(Ap, Bp, -1), madd(Am, Bm, -1), madd(Az, Bz, -1)
        L2 = casimir_pm(Lp, Lm, Lz); M2 = casimir_pm(Mp, Mm, Mz)
        LM = madd(mmul(Lz, Mz), mscal(madd(mmul(Lp, Mm), mmul(Lm, Mp)), Fr(1, 2)))
        S = madd(L2, M2); okStd &= is_scalar(S, n * n - 1) and is_scalar(LM, 0)
        lc, full = l_content(L2); okStd &= full
        tstd[n] = (len(L2), j * (j + 1), lc, Fr(-1, 2) / (S[0][0] + 1))
    chk('std', okStd, 'V_j x V_j, 2j = 0..5, textbook spin matrices (rational basis): Casimir j(j+1) on each factor, L^2 + M^2 = n^2 - 1, L.M = 0, [J+, J-] = 2 Jz')
    same = all(tstd[n][0] == table[n][0] and tstd[n][1] == table[n][1] and tstd[n][2] == table[n][2] and tstd[n][3] == table[n][3] for n in range(1, 7))
    chk('bit==std', same, 'the label shells (kpg·3) and V_j x V_j agree for n = 1..6: dimension, Casimir, l-content {l: 2l+1}, and the energy -1/(2n^2)')
    okS = True; okCount = True; okInd = True; info = []
    for n in range(1, 6):
        kap = Fr(1, n + 1) if FAULT == 'KAPPA' else Fr(1, n); E = Fr(-1, 2 * n * n); tot = 0; allst = []
        for l in range(n):
            dims, states, nh = schroedinger(n, l, kap, E); okS &= all(d_ == 1 for d_ in dims) and nh == 2 * l + 1; tot += len(states); allst += states
        okCount &= tot == n * n
        if allst:
            nfs = [normal_form(s, shift=0) for s in allst]; keys = sorted(set(k for c in nfs for k in c))
            okInd &= rank([[c.get(k, 0) for c in nfs] for k in keys], len(nfs)) == len(nfs)
        info.append('%d: %d' % (n, tot))
    chk('std', okS and okCount and okInd, 'Schroedinger, exact: for n = 1..5, l = 0..n-1, every harmonic h of degree l (2l+1 of them) times Q(r) exp(-r/n), deg Q = n - l - 1, solves H psi = -1/(2n^2) psi for one Q; the states are independent, counts n: n^2 = %s' % ', '.join(info))
    chk('bit==std', okS and okCount and all(table[n][3] == Fr(-1, 2 * n * n) and table[n][0] == n * n for n in range(1, 6)), 'the Balmer levels and degeneracies of the label shells with Pauli\'s identity equal those of the Schroedinger equation for n = 1..5')
    return

def part5():
    head('kpg·5: controls [ctl]')
    Al, biv, mats, ops = label_ops(); ad = adjoint_module(Al, biv); Ls, Ms = ad[:3], ad[3:]
    As = [mscal(madd(l, m), Fr(1, 2)) for l, m in zip(Ls, Ms)]; Bs = [mscal(madd(l, m, -1), Fr(1, 2)) for l, m in zip(Ls, Ms)]
    neg = lambda Xs: mscal(madd(madd(mmul(Xs[0], Xs[0]), mmul(Xs[1], Xs[1])), mmul(Xs[2], Xs[2])), -1)
    A2, B2, L2, M2 = neg(As), neg(Bs), neg(Ls), neg(Ms); LM = madd(madd(mmul(Ls[0], Ms[0]), mmul(Ls[1], Ms[1])), mmul(Ls[2], Ms[2]))
    S = madd(L2, M2); c = S[0][0] if is_scalar(S, S[0][0]) else None
    unequal = A2 != B2 and not is_scalar(LM, 0) and c == 4 and Fr(-1, 2) / (c + 1) not in [Fr(-1, 2 * m * m) for m in range(1, 50)]
    chk('ctl', unequal, 'unequal Casimirs: on the six bivectors ((1,0) + (0,1)) A^2 != B^2 and L.M != 0; -(L^2 + M^2) = %s gives -1/(2E) = 5, E = -1/10, not a Balmer level' % c)
    wrongE = [Fr(-1, 2 * (n * n - 2)) for n in range(1, 4)]
    chk('ctl', wrongE[0] > 0, 'the wrong sign of hbar^2 in the identity would give E = -1/(2(n^2 - 2)) = %s for n = 1, 2, 3: positive at n = 1 (no bound state)' % ', '.join(map(str, wrongE)))
    dims, states, nh = schroedinger(2, 0, Fr(1, 3), Fr(-1, 8))
    chk('ctl', dims == [0], 'the Schroedinger route with exp(-r/3) at E = -1/8 (n = 2, l = 0): no solution (dimension %s)' % dims)

def main():
    head('KPG-PAULI: Pauli\'s hydrogen spectrum from the hidden so(4)' + (' [fault %s]' % FAULT if FAULT else ''))
    part1(); part2(); table = part3(); part4(table); part5()

if __name__ == '__main__':
    main(); finish('KPG-PAULI' + ('-' + FAULT if FAULT else ''))
