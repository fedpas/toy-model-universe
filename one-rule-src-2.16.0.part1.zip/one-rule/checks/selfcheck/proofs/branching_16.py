#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""branching_16.py: the branching of the 16 on the labels in three cells, the Majorana condition as a real structure on the 32 of Cl(1,9),
and fields that depend on x on the coupling step's equation with the fibre momentum as a mass (round 12, proofs pass 10b; docs/round12/PLAN.md).
     python3 branching_16.py [--fault WRONGJ|UNGRADED|ODDLAB|NOCONJ|OTHERHALF|SHELLSIGN]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q,r) has its p generators of
square +1 first, then q of square -1 (core_check.sig); Cl(1,3) with bit 0 = time of square +1 (INP-011); Cl(1,9) = Cl(1,3) (x)^ Cl(0,6) on
concatenated labels as fibre_base.py builds it (bits 0-3 the base e0..e3, bits 4-9 the fibre f1..f6); J = gamma2 gamma1 acting on the right.
Conventions of the weights: five Cartan slots, every pair in the canonical order (lower bit first): in Cl(1,9) the rotation e1e2 and the boost
e0e3 (the so(4) slots), then f1f2, f3f4, f5f6; in Cl(0,10) e1e2, e3e4 (bits 0-3) and the three fibre pairs; in Cl(5,5) the Fock modes 0, 1 and
2, 3, 4 (GEN-015's Witt basis, interleaved pairs).  A slot of square -1 is read as sigma = +-1 through one complex structure J commuting with
all five (the involution X J^-1), a slot of square +1 directly.  "(2,1)": equal signs on the two so(4) slots, "(1,2)": opposite signs; "4": the
three so(6) signs with product -1 (so(6) on (O, omega6) of FUR-011, read with omega6), "4b": product +1.  The multiset Pati-Salam's
16 -> (2,1,4) + (1,2,4b) states (Pati-Salam 1974; Slansky 1981, Table 48; recalled) is then the 16 sign vectors with product -1, its conjugate
the 16 with product +1.
br.W19  Cl(1,9): the five Cartan blades commute; e1e2 I^-1 = e0e3; the product of the five involutions is Gamma; on the halves of the 32 the
        multisets with J = I, -I, omega6, -omega6 and with a mixed reading.  [std] complex Pauli words on C^32.  [ctl] omega6 where I is used,
        -I; the ungraded product (module 64: twice the multiset).
br.W010 Cl(0,10): type and module, the quaternionic commutant, the two complex 16s (omega J^-1 = -+1).  [std] Pauli words, omega = -+i.
br.W55  Cl(5,5): the Fock states a*_S Pi of GEN-015, n_a - 1/2 = e_a f_a / 2, the even and the odd labels read off the bits.  [std] the 10 x 10
        Cartan of so(4) + so(6) of jordan_sm.py through the spin map of Jordan-Wigner gammas.
br.ONE  one multiset in the three cells; the 32 of Cl(1,9) with each complex structure commuting with so(1,3) + so(6) against the 16.
br.MAJ  the real structure c on R^32 (x) C (the complex scalar a separate commuting unit: pairs of exact integer vectors): the I-eigenspaces,
        their exchange, the weights, the real components as complex ones, gamma5 on V^(1,0); the slots c keeps and negates in the three cells.
        [std] B with B gamma B^-1 = +-gamma* for the Pauli words, c_B on the joint eigenvectors.  [ctl] NOCONJ, OTHERHALF.
br.SUM  sums of plane waves on a left ideal of dimension 64 where right multiplication by J acts: frequency by frequency; the current
        psi gamma0 psi~ of a sum (multivectors) against the sum of the currents.  [std] realified Dirac x octonion matrices on R^64.
br.POL  P(x) e^(J k.x) with P of degree <= 2, exact rational coefficients: the solution spaces on and off the shell; the first derivatives of
        plane waves along the shell span the solutions of degree <= 1.  [std] the same system.
br.KK   two fibre momenta m1 != m2 in one field: two shells.  [std] the same kernels.  [ctl] the ungraded product; the shell of the other sign.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   WRONGJ omega6 read where I is used; UNGRADED the ungraded product Cl(1,3) (x) Cl(0,6) (items 1 and 3); ODDLAB the odd labels of Cl(5,5) taken
   as the 16; NOCONJ the real structure without conjugation of the complex scalar; OTHERHALF the other Weyl half in item 2; SHELLSIGN the shell
   E^2 = |p|^2 - m^2 asserted in item 3.
Not computed here (stated, not checked): representation theory beyond weights; which of 4 and 4b is "the" 4 beyond the orientation above; that
the so(4,C) of Cl(1,9) (Lorentz) and that of Pati-Salam (weak isospin) are one thing; the Majorana condition on quantum fields; fields on a
manifold, wave packets as integrals, the spectrum of fibre momenta; which product, split or signature nature uses (an input, INP-011).
Command: python3 -I -B selfcheck/proofs/branching_16.py from checks/ (or from this folder); standard library and numpy."""
import os, sys, time, random, importlib.util
from fractions import Fraction as Fr
from math import isqrt, gcd
from collections import Counter
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py'), (os.path.join(_checks, 'reports', 'furey'), 'model.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps
_spec = importlib.util.spec_from_file_location('furey_model', os.path.join(_checks, 'reports', 'furey', 'model.py'))
OM = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(OM)  # the octonion model, data only (as fibre_base.py)

# ------------------------------------------------------------------------------------------------ check lines (from fibre_base.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish():
    print('\n  tags: %s; %.0f s' % (', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), time.time() - T0))
    print('branching_16: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('WRONGJ', 'UNGRADED', 'ODDLAB', 'NOCONJ', 'OTHERHALF', 'SHELLSIGN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(20261017); NPR = np.random.default_rng(20261017)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
pc = lambda x: bin(x).count('1')

# ------------------------------------------------------------------------------------------------ the kernel's formula and the label types
# copied from fibre_base.py (popv, emask, s_vec, table, type_from_inv, tstr, table_type, ltype_eps, clock_type, ungraded_table; no __main__ guard)
def popv(x): return np.bitwise_count(x).astype(np.int64)
def emask(eps):
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    eps = tuple(eps)
    if eps not in _EM: _EM[eps] = emask(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)): par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    return (1 - 2 * (par & 1)) * _EM[eps][A & B]
def table(eps):
    a = np.arange(1 << len(eps), dtype=np.int64); return s_vec(eps, a[:, None], a[None, :]).astype(np.int8)
DD = {'R': 1, 'C': 2, 'H': 4}
def type_from_inv(dim, c, cplx, fs):
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D]); m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
def table_type(S, gens):
    central = np.ones(S.shape[0], dtype=bool)
    for g in gens: central &= (S[:, g] == S[g, :])
    Z = np.nonzero(central)[0]; sq = S[Z, Z]
    cplx = bool(np.any(sq == -1)); c = len(Z) // 2 if cplx else len(Z)
    return type_from_inv(S.shape[0], c, cplx, int(np.trace(S.astype(np.int64))))
def ltype_eps(eps):
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); d = s_vec(eps, a, a); cen = np.ones(1 << n, dtype=bool)
    for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
    Z = np.flatnonzero(cen); cplx = bool(np.any(d[Z] == -1))
    return type_from_inv(1 << n, len(Z) // 2 if cplx else len(Z), cplx, int(d.sum()))
def clock_type(p, q):
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2); assert r == 0 and m * m == m2
    return (D, m, c)
def ungraded_table(e1, e2): return np.kron(table(e2).astype(np.int8), table(e1).astype(np.int8))

# ------------------------------------------------------------------------------------------------ labels as an algebra, ideals, commutants
# copied from fibre_base.py (Lab, lab_graded, lab_ungraded, span_tau, Ideal, centraliser_div; two additions: comm_labels takes `must`, labels
# every chosen label also commutes with, so that right multiplication by them keeps the ideal; centraliser_div also returns its representatives)
class Lab:
    def __init__(self, s, N): self.s, self.N, self.M = s, N, 1 << N
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                k = a ^ b; v = out.get(k, 0) + self.s(a, b) * ca * cb
                if v: out[k] = v
                else: out.pop(k, None)
        return out
def lab_graded(eps): return Lab(BR(eps).s, len(eps))
def lab_ungraded(e1, e2):
    A1, A2 = BR(e1), BR(e2); n1 = len(e1); m1 = (1 << n1) - 1
    return Lab(lambda a, b: A1.s(a & m1, b & m1) * A2.s(a >> n1, b >> n1), n1 + len(e2))
def comm_labels(L, first=(), even=False, tries=60, must=()):
    best = None
    for k in range(tries):
        order = list(range(1, L.M)); RNG.shuffle(order); G = list(first); span = {0}
        for g in G: span |= {x ^ g for x in span}
        for u in order:
            if u in span or L.sq(u) != 1 or (even and pc(u) % 2) or not all(L.commute(u, g) for g in G): continue
            if not all(L.commute(u, w) for w in must): continue
            G.append(u); span |= {x ^ u for x in span}
        if best is None or len(G) > len(best): best = G
    return best
def span_tau(L, G):
    tau = {0: 1}
    for g in G:
        for h, t in list(tau.items()): tau[h ^ g] = L.s(h, g) * t
    return tau
class Ideal:
    """the left ideal A f, f = prod (1 + e_g)/2 over commuting labels G of square +1, on the basis e_r f: left and right multiplications by
    labels are signed permutation matrices"""
    def __init__(self, L, G):
        self.L, self.G = L, list(G); self.tau = span_tau(L, G); H = list(self.tau)
        self.rep = {}; self.reps = []
        for a in range(L.M):
            if a not in self.rep:
                self.reps.append(a)
                for h in H: self.rep[a ^ h] = (a, h)
        self.m = len(self.reps); self.idx = {r: i for i, r in enumerate(self.reps)}
    def act(self, b):
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[b ^ r]; R[self.idx[r2], self.idx[r]] = self.L.s(b, r) * self.L.s(r2, h) * self.tau[h]
        return R
    def ract(self, c):
        assert all(self.L.commute(c, g) for g in self.G)
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[r ^ c]; R[self.idx[r2], self.idx[r]] = self.L.s(r, c) * self.L.s(r2, h) * self.tau[h]
        return R
def centraliser_div(L, G):
    H = set(span_tau(L, G)); cen = [a for a in range(L.M) if all(L.commute(a, g) for g in G)]
    reps = sorted({min(a ^ h for h in H) for a in cen}); sq = [L.sq(a) for a in reps if a]
    d = len(reps); ok = all(v == -1 for v in sq) and all(not L.commute(a, b) for a in reps if a for b in reps if b and b != a)
    return d, ({1: 'R', 2: 'C', 4: 'H'}.get(d) if ok else None), [a for a in reps if a]

# copied from fibre_base.py (commutant_basis from solid_cube.py, basis_type, nullspace_frac from chiral_spinors.py, rank_frac, rel_ok, urel_ok)
def commutant_basis(rho, m):
    """all X (m x m) with X rho_i = rho_i X for signed permutation matrices rho_i: the sign-consistent components of a union-find over the
    m^2 entries; one {0,+1,-1} matrix per component"""
    perms = []
    for R in rho:
        pi = [0] * m; sg = [0] * m
        for c in range(m):
            nz = np.nonzero(R[:, c])[0]; assert len(nz) == 1
            pi[c] = int(nz[0]); sg[c] = int(R[nz[0], c])
        perms.append((pi, sg))
    parent = list(range(m * m)); psign = [1] * (m * m)
    def find(x):
        path = []
        while parent[x] != x: path.append(x); x = parent[x]
        s = 1
        for node in reversed(path):
            s *= psign[node]; psign[node] = s; parent[node] = x
        return x
    def sgn_of(x):
        r = find(x); return r, (1 if x == r else psign[x])
    eqs = []
    for pi, sg in perms:
        for b in range(m):
            for c in range(m): eqs.append((pi[b] * m + pi[c], b * m + c, sg[b] * sg[c]))
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv: parent[ru] = rv; psign[ru] = s * sv * su
    bad = set(); comp = {}
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv or su != s * sv: bad.add(rv)
    for x in range(m * m):
        r, sx = sgn_of(x); comp.setdefault(r, []).append((x, sx))
    basis = []
    for r in sorted(comp):
        if r in bad: continue
        B = np.zeros((m, m), dtype=np.int64)
        for x, sx in comp[r]: B[x // m, x % m] = sx
        basis.append(B)
    return basis
def basis_type(basis):
    d = len(basis); pos = [tuple(np.argwhere(B != 0)[0]) for B in basis]
    def coords(P):
        x = [int(P[p]) * int(B[p]) for B, p in zip(basis, pos)]
        assert np.array_equal(sum(c * B for c, B in zip(x, basis)), P), 'not in the span'
        return x
    K = [[coords(Bi @ Bj) for Bj in basis] for Bi in basis]
    trL = [sum(K[k][i][i] for i in range(d)) for k in range(d)]
    T = [[sum(K[i][j][t] * trL[t] for t in range(d)) for j in range(d)] for i in range(d)]
    ev = np.linalg.eigvalsh(np.array(T, dtype=float)); fs = int((ev > 1e-9).sum() - (ev < -1e-9).sum())
    cen = nullspace_frac([[K[i][j][t] - K[j][i][t] for i in range(d)] for j in range(d) for t in range(d)], d)
    cplx, c = False, len(cen)
    if len(cen) >= 2:
        Zb = np.array([[float(x) for x in v] for v in cen]); z = NPR.standard_normal(len(cen)) @ Zb
        Mz = np.einsum('i,ijt->jt', z, np.array(K, dtype=float))
        Cm = np.linalg.lstsq(Zb.T, (Zb @ Mz).T, rcond=None)[0].T
        ev = np.linalg.eigvals(Cm); a = int((np.abs(ev.imag) < 1e-7).sum()); b = int((ev.imag > 1e-7).sum())
        if a and b: return None
        cplx, c = (True, b) if b else (False, a)
    return type_from_inv(d, c, cplx, fs)
def nullspace_frac(rows, ncol):
    rows = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p_ = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if p_ is None: continue
        rows[rk], rows[p_] = rows[p_], rows[rk]; pv = rows[rk][c]; rows[rk] = [x / pv for x in rows[rk]]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncol) if c not in piv]; basis = []
    for f in free:
        v = [Fr(0)] * ncol; v[f] = Fr(1)
        for i, c in enumerate(piv): v[c] = -rows[i][f]
        basis.append(v)
    return basis
def rank_frac(M):
    rows = [[Fr(x) for x in r] for r in (M.tolist() if hasattr(M, 'tolist') else M)]
    return len(rows[0]) - len(nullspace_frac(rows, len(rows[0]))) if rows else 0
def rel_ok(G, eps):
    I = np.eye(G[0].shape[0], dtype=G[0].dtype)
    return all(np.array_equal(G[i] @ G[j] + G[j] @ G[i], 2 * eps[i] * I if i == j else 0 * I) for i in range(len(G)) for j in range(i, len(G)))
def urel_ok(G, e1, e2):
    n1 = len(e1); eps = tuple(e1) + tuple(e2); I = np.eye(G[0].shape[0], dtype=G[0].dtype)
    return all(np.array_equal(G[i] @ G[j] + (-1 if (i < n1) != (j < n1) else 1) * (G[j] @ G[i]), 2 * eps[i] * I if i == j else 0 * I)
               for i in range(len(G)) for j in range(i, len(G)))
def madd(*terms):
    out = {}
    for c_, x in terms:
        for k_, v in x.items():
            w = out.get(k_, 0) + c_ * v
            if w: out[k_] = w
            else: out.pop(k_, None)
    return out

# ------------------------------------------------------------------------------------------------ new here: an exact sparse rank over Q
def rank_sparse(rows):
    """the exact rank of an integer matrix given as sparse rows {column: int}: a row echelon form kept in integers (each pivot row primitive,
    its pivot its smallest column); a new row is reduced by the pivot rows of its smallest columns until it is zero or has a new pivot"""
    piv = {}
    for r in rows:
        r = {c: v for c, v in r.items() if v}
        while r:
            c = min(r); p = piv.get(c)
            if p is None:
                g = 0
                for v in r.values(): g = gcd(g, v)
                if r[c] < 0: g = -g
                piv[c] = {k: v // g for k, v in r.items()}; break
            a, b = r[c], p[c]; g = gcd(a, b); a //= g; b //= g
            new = {k: b * v for k, v in r.items()}
            for k, v in p.items():
                w = new.get(k, 0) - a * v
                if w: new[k] = w
                else: new.pop(k, None)
            g = 0
            for v in new.values(): g = gcd(g, v)
            r = {k: v // g for k, v in new.items()} if g > 1 else new
    return len(piv)
def sparse_rows(M):
    """the rows of an integer matrix as {column: int}"""
    return [{int(c): int(M[i, c]) for c in np.flatnonzero(M[i])} for i in range(M.shape[0])]

# ------------------------------------------------------------------------------------------------ the standard route: matrices, no label
# (the realified Dirac matrices, gamma5, the octonion left multiplications and the complex Pauli words of fibre_base.py; never the bit rule)
def realify(Zc): return np.block([[Zc.real, -Zc.imag], [Zc.imag, Zc.real]])
_s1 = np.array([[0, 1], [1, 0]], dtype=complex); _s2 = np.array([[0, -1j], [1j, 0]]); _s3 = np.array([[1, 0], [0, -1]], dtype=complex)
_g0 = np.diag([1, 1, -1, -1]).astype(complex)
_gk = [np.block([[0 * s, s], [-s, 0 * s]]) for s in (_s1, _s2, _s3)]
GAM = [realify(g) for g in [_g0] + _gk]                                   # Cl(1,3) on R^8: the Dirac matrices realified
JC = realify(1j * np.eye(4))                                              # the realified i, commuting with GAM
GAM5 = realify(1j * _g0 @ _gk[0] @ _gk[1] @ _gk[2])                       # gamma5 = i g0 g1 g2 g3
UNITS = [1, 2, 4, 5, 6, 7]                                                # the six fibre units (model index), k = 3 is Furey's e7
OLM = [OM.Lmat(OM.E[u]) for u in UNITS]                                   # Cl(0,6) on O = R^8: left multiplications
def kron_all(ms):
    M = np.ones((1, 1))
    for m_ in ms: M = np.kron(M, m_)
    return M
def prodm(ms):
    P_ = np.eye(ms[0].shape[0], dtype=ms[0].dtype)
    for m_ in ms: P_ = P_ @ m_
    return P_
PX = np.array([[0, 1], [1, 0]], dtype=complex); PY = np.array([[0, -1j], [1j, 0]]); PZ = np.diag([1, -1]).astype(complex); P2c = np.eye(2, dtype=complex)
HM = [kron_all([PZ] * k + [P_] + [P2c] * (4 - k)) for k in range(5) for P_ in (PX, PY)]   # ten anticommuting Hermitian 32 x 32
CL19 = [HM[0]] + [1j * h for h in HM[1:]]; CL010 = [1j * h for h in HM]                # Cl(1,9) and Cl(0,10) on C^32

# ------------------------------------------------------------------------------------------------ sign vectors, the reference multisets, weights
SIGNS = [tuple(1 - 2 * ((t >> k) & 1) for k in range(5)) for t in range(32)]
def prod5(s): return s[0] * s[1] * s[2] * s[3] * s[4]
PS16 = Counter({s: 1 for s in SIGNS if prod5(s) == -1})                   # (2,1,4) + (1,2,4b): the multiset Pati-Salam's 16 states
CJ16 = Counter({s: 1 for s in SIGNS if prod5(s) == 1})                    # its conjugate
def piece(eq, cp): return Counter({s: 1 for s in SIGNS if (s[0] == s[1]) == eq and s[2] * s[3] * s[4] == cp})
NAMES = [('(2,1,4)', piece(True, -1)), ('(1,2,4b)', piece(False, 1)), ('(2,1,4b)', piece(True, 1)), ('(1,2,4)', piece(False, -1))]
P214, P124b, P214b, P124 = (P for _, P in NAMES)
def name_ms(ms):
    """a multiset of sign vectors as a sum of the four pieces with multiplicities ('0' if empty, 'other' if it is not such a sum)"""
    rest = Counter({k: v for k, v in ms.items() if v}); parts = []
    for nm, P in NAMES:
        k = min(rest[s] for s in P)
        if k > 0:
            for s in P: rest[s] -= k
            parts.append(nm if k == 1 else '%d x %s' % (k, nm))
    rest = +rest
    return (' + '.join(parts) if parts else '0') if not rest else 'other (%d weights)' % sum(rest.values())
def weights(half2, invs, cplx=True):
    """the joint multiplicities of five commuting involutions on a half: tr[(1 + s Gamma)/2 prod (1 + sigma_k u_k)/2] for every sigma (half2 =
    1 + s Gamma, integer); the real dimension, halved (the complex multiplicity) when a complex structure keeps every joint eigenspace"""
    out = Counter(); m = half2.shape[0]; Id = np.eye(m, dtype=np.int64)
    for s in SIGNS:
        M = half2.copy()
        for sk, u in zip(s, invs): M = M @ (Id + sk * u)
        d, r = divmod(int(np.trace(M)), 64); assert r == 0
        if d:
            if cplx: assert d % 2 == 0; d //= 2
            out[s] = d
    return out
def conj_map(s, rot):
    """what complex conjugation does to a weight: the rotation slots (rot[k] True) change sign, the boost slots keep it"""
    return tuple(-x if r else x for x, r in zip(s, rot))
def cms(ms, rot):
    """the multiset read with -J in place of J: every rotation slot changes sign"""
    return Counter({conj_map(k, rot): v for k, v in ms.items()})
def joint(ops):
    """numpy: joint eigenvectors of commuting Hermitian matrices with a simple joint spectrum (the eigenvectors of a random real combination)
    and the eigenvalue of each operator on each, rounded, with the largest rounding error"""
    M = sum(NPR.standard_normal() * o for o in ops); _, V = np.linalg.eigh(M)
    vals = np.array([[np.real(np.vdot(V[:, j], o @ V[:, j])) for o in ops] for j in range(V.shape[1])])
    return V, np.rint(vals).astype(int), float(np.abs(vals - np.rint(vals)).max())

# ================================================================================================ br.W19  Cl(1,9): the Cartan elements and weights
head('br.W19  Cl(1,9) = Cl(1,3) (x)^ Cl(0,6): the Cartan elements e1e2, e0e3, f1f2, f3f4, f5f6 and their weights on the halves of the 32')
t = time.time()
E13, E06, E19 = sig(1, 3), sig(0, 6), sig(1, 9)
L19 = lab_graded(E19); LU = lab_ungraded(E13, E06)
TOP = (1 << 10) - 1; BI, BW = 15, TOP ^ 15                                 # I = e0e1e2e3 (bits 0-3), omega6 = f1..f6 (bits 4-9)
ROT, BOO, FF = 6, 9, (48, 192, 768)                                        # e1e2, e0e3, f1f2, f3f4, f5f6
CART = (ROT, BOO) + FF; ROT19 = (True, False, True, True, True)            # the slots of square -1, read through J
okC = [L19.sq(x) for x in CART] == [-1, 1, -1, -1, -1] and all(L19.commute(x, y) for x in CART for y in CART)
okC &= all(L19.commute(x, y) for x in (BI, BW) for y in CART) and L19.commute(BI, BW) and L19.sq(BI) == L19.sq(BW) == -1
P5 = {0: 1}
for x in CART: P5 = L19.mul(P5, {x: 1})
okC &= L19.mul({ROT: 1}, {BI: -1}) == {BOO: 1} and P5 == {TOP: 1} == L19.mul({BI: 1}, {BW: 1})
chk('bit', okC, 'br.W19: the five Cartan blades (squares -1, +1, -1, -1, -1) commute pairwise and with I and omega6; e1e2 I^-1 = e0e3 exactly (with I, so(1,3) is one sl(2,C): the rotation read with I and the boost agree on every vector); their product is e0..e9 = Gamma = I omega6, so for every J commuting with them the product of the five involutions (X J^-1 for the rotations, e0e3 itself) is Gamma: the product of the five signs is the chirality')
def module19(L):
    """the minimal left ideal from Gamma and further commuting even labels of square +1 (fibre_base.py's construction), with the matrices"""
    G = comm_labels(L, first=(TOP,), even=True, tries=12); I_ = Ideal(L, G)
    return I_, {x: I_.act(x) for x in set(CART) | {BI, BW, TOP}}
def wms(R, J, s, rot=ROT19):
    """the weights of the half Gamma = s with the five slots read through J"""
    Jinv = -J; m = R[TOP].shape[0]
    return weights(np.eye(m, dtype=np.int64) + s * R[TOP], [R[x] @ Jinv if r else R[x] for x, r in zip(CART, rot)])
GRADED = FAULT != 'UNGRADED'
IA, RA = module19(L19 if GRADED else LU)                                   # the main lines' module: the 32 (the ungraded 64 under UNGRADED)
IUc, RUc = module19(LU if GRADED else L19)                                 # the control's module: the other product
okP = all(np.array_equal(prodm([RA[x] @ (-J) if r else RA[x] for x, r in zip(CART, ROT19)]), RA[TOP]) for J in (RA[BI], -RA[BI], RA[BW], -RA[BW]))
Jm = RA[BW] if FAULT == 'WRONGJ' else RA[BI]                               # the main lines read with I (omega6 under WRONGJ)
W = {(sj, s): wms(RA, sj * Jm, s) for sj in (1, -1) for s in (1, -1)}
chk('bit', IA.m == 32 and okP and W[(1, 1)] == P214b and W[(1, -1)] == P214 and W[(-1, 1)] == P124 and W[(-1, -1)] == P124b,
    'br.W19: on the minimal ideal (dimension %d) the product of the five involutions is Gamma for J = +-I, +-omega6; with J = I each half is a complex 8 with eight weights, each once: Gamma = +1 carries %s, Gamma = -1 carries %s; with J = -I %s and %s' % (IA.m, name_ms(W[(1, 1)]), name_ms(W[(1, -1)]), name_ms(W[(-1, 1)]), name_ms(W[(-1, -1)])))
CPX = {s: W[(1, s)] + W[(-1, s)] for s in (1, -1)}
chk('bit', CPX[-1] == PS16 and CPX[1] == CJ16, 'br.W19: the complexification of a half is the sum of its I- and -I-readings (the eigenspaces I = +i and -i of I (x) 1): Gamma = -1 gives %s, the multiset Pati-Salam\'s 16 -> (2,1,4) + (1,2,4b) states (the 16 sign vectors with product -1); Gamma = +1 gives %s, its conjugate' % (name_ms(CPX[-1]), name_ms(CPX[1])))
WW = {s: wms(RA, RA[BW], s) for s in (1, -1)}
MIX = {s: weights(np.eye(IA.m, dtype=np.int64) + s * RA[TOP], [RA[ROT] @ (-RA[BI]), RA[BOO]] + [RA[f] @ (-RA[BW]) for f in FF]) for s in (1, -1)}
okJ = all(W[(-1, s)] == cms(W[(1, s)], ROT19) for s in (1, -1)) and WW[1] == W[(-1, 1)] and WW[-1] == W[(1, -1)]
chk('bit', okJ and MIX[-1] == W[(1, -1)] and MIX[1] not in (W[(1, 1)], W[(-1, 1)]), 'br.W19: one J reads all five slots: J and -J give conjugate multisets (the rotation signs flipped); omega6 = -I on Gamma = +1 and +I on Gamma = -1, so J = omega6 gives %s and %s, the I-multisets up to the overall conjugation; a mixed reading (I for the base, omega6 for the fibre) gives %s on Gamma = +1, neither the I-multiset nor its conjugate' % (name_ms(WW[1]), name_ms(WW[-1]), name_ms(MIX[1])))
WI = {s: wms(RA, RA[BI], s) for s in (1, -1)}; WmI = {s: wms(RA, -RA[BI], s) for s in (1, -1)}
chk('ctl', WW[1] == cms(WI[1], ROT19) != WI[1] and all(WmI[s] == cms(WI[s], ROT19) != WI[s] for s in (1, -1)),
    'br.W19: a wrong complex structure: omega6 where I is used gives %s on Gamma = +1, the conjugate of %s (fibre_base\'s WRONGSIGN, I = +omega6 on Gamma = +1, read as weights); -I on both halves conjugates both (WRONGJ)' % (name_ms(WW[1]), name_ms(WI[1])))
tUc = table_type(ungraded_table(E13, E06), [1 << i for i in range(10)])
WUc = {s: wms(RUc, RUc[BI], s) for s in (1, -1)}
twice = all(WUc[s] == Counter({k: 2 * v for k, v in WI[s].items()}) for s in (1, -1))
okU = IUc.m == 64 and tUc == ('H', 16, 1) and urel_ok([IUc.act(1 << i) for i in range(10)], E13, E06) and all(LU.commute(x, y) for x in CART for y in CART)
chk('ctl', okU and twice, 'br.W19: the ungraded product Cl(1,3) (x) Cl(0,6) = %s: the five blades still commute, its irreducible module is the %d (H^16), and with I its halves carry %s and %s: twice the multiset of the 32 (UNGRADED)' % (tstr(tUc), IUc.m, name_ms(WUc[1]), name_ms(WUc[-1])))
note('(%.1f s)' % (time.time() - t))
t = time.time()
GS = prodm(CL19); IS = (CL19[0] @ CL19[1] @ CL19[2] @ CL19[3]) / 1j
OPS19 = [GS, IS, (CL19[1] @ CL19[2]) / 1j, CL19[0] @ CL19[3]] + [(CL19[4 + 2 * a] @ CL19[5 + 2 * a]) / 1j for a in range(3)]
herm = all(np.allclose(o, o.conj().T) for o in OPS19) and all(np.allclose(o @ p, p @ o) for o in OPS19 for p in OPS19)
_, V19, err19 = joint(OPS19); QS = {(g, i_): Counter() for g in (1, -1) for i_ in (1, -1)}
for row in V19: QS[(row[0], row[1])][tuple(int(x) for x in row[2:])] += 1
chk('std', herm and err19 < 1e-8 and QS[(1, 1)] == P214b and QS[(-1, 1)] == P214 and QS[(1, -1)] == P124 and QS[(-1, -1)] == P124b,
    'br.W19: numpy, complex Pauli words for Cl(1,9) on C^32 (no label): Gamma, I/i, e1e2/i, e0e3, f1f2/i, f3f4/i, f5f6/i commute and are Hermitian; their joint eigenvectors give on (Gamma, I) = (+1, +i) %s, (-1, +i) %s, (+1, -i) %s, (-1, -i) %s' % tuple(name_ms(QS[k]) for k in ((1, 1), (-1, 1), (1, -1), (-1, -1))))
chk('bit==std', all(QS[(s, sj)] == W[(sj, s)] for s in (1, -1) for sj in (1, -1)), 'br.W19: the quarters (Gamma, I = +-i) of C^32 carry the label multisets of the halves read with I and -I: the same weights on the labels and on the matrices, Gamma = -1 complexified the Pati-Salam multiset, Gamma = +1 its conjugate')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ br.W010  the compact cell Cl(0,10)
head('br.W010 the compact Cl(0,10) = Cl(0,4) (x)^ Cl(0,6) (CAND-136): type, module, and its two complex 16s by the quaternionic commutant')
t = time.time()
E010 = sig(0, 10); L010 = lab_graded(E010); t010 = ltype_eps(E010)
CART10 = (3, 12) + FF; ROT10 = (True,) * 5                                 # e1e2, e3e4 (bits 0-3), f1f2, f3f4, f5f6: all of square -1
G010 = comm_labels(L010, tries=12); I010 = Ideal(L010, G010); d10, D10, reps10 = centraliser_div(L010, G010)
R010 = [I010.act(1 << i) for i in range(10)]; cb10 = commutant_basis(R010, I010.m); tcb10 = basis_type(cb10)
chk('bit', t010 == ('H', 16, 1) and len(G010) == 4 and I010.m == 64 and rel_ok(R010, E010) and (d10, D10) == (4, 'H') and len(cb10) == 4 and tcb10 == ('H', 1, 1),
    'br.W010: on the labels Cl(0,10) = %s (dimension 1024 = 4 x 16^2; the brief\'s M32(H) would have 4096); four commuting labels of square +1 give the irreducible module, of dimension %d = H^16, on which the ten generators obey the relations, with exact commutant %s (f A f = %s)' % (tstr(t010), I010.m, tstr(tcb10), D10))
I64 = np.eye(64, dtype=np.int64); JQ = [I010.ract(c) for c in reps10]; OM10 = I010.act(TOP)
okQ = len(JQ) == 3 and all(np.array_equal(J @ J, -I64) and all(np.array_equal(J @ r, r @ J) for r in R010) for J in JQ)
okQ &= all(np.array_equal(JQ[a] @ JQ[b], -(JQ[b] @ JQ[a])) for a in range(3) for b in range(a + 1, 3))
okQ &= L010.sq(TOP) == -1 and all(np.array_equal(OM10 @ J, J @ OM10) for J in JQ)
P5 = {0: 1}
for x in CART10: P5 = L010.mul(P5, {x: 1})
def wms10(J, s):
    Jinv = -J; return weights(I64 + s * (OM10 @ Jinv), [I010.act(x) @ Jinv for x in CART10])
W10 = [{s: wms10(J, s) for s in (1, -1)} for J in JQ]
okP10 = all(np.array_equal(prodm([I010.act(x) @ (-J) for x in CART10]), OM10 @ (-J)) for J in JQ)
chk('bit', okQ and P5 == {TOP: 1} and okP10 and all(w[-1] == PS16 and w[1] == CJ16 for w in W10),
    'br.W010: the commutant has three anticommuting units, the right multiplications by the labels %s, each a complex structure J commuting with the ten generators; omega = e0..e9 (square -1) commutes with J, omega J^-1 = +-1 splits R^64 into two complex 16s, and the product of the five involutions X J^-1 is omega J^-1; for each of the three J the half omega = -J carries %s, the half omega = +J %s' % (reps10, name_ms(W10[0][-1]), name_ms(W10[0][1])))
note('(%.1f s)' % (time.time() - t))
t = time.time()
OPS10 = [prodm(CL010) / 1j] + [(CL010[2 * k] @ CL010[2 * k + 1]) / 1j for k in range(5)]
herm10 = all(np.allclose(o, o.conj().T) for o in OPS10) and all(np.allclose(o @ p, p @ o) for o in OPS10 for p in OPS10)
_, V10, err10 = joint(OPS10); Q10 = {1: Counter(), -1: Counter()}
for row in V10: Q10[int(row[0])][tuple(int(x) for x in row[1:])] += 1
chk('std', herm10 and err10 < 1e-8 and Q10[-1] == PS16 and Q10[1] == CJ16, 'br.W010: numpy, Pauli words for Cl(0,10) on C^32: omega/i and the five Cartan elements over i commute and are Hermitian; their joint eigenvectors give on omega = -i %s and on omega = +i %s' % (name_ms(Q10[-1]), name_ms(Q10[1])))
chk('bit==std', all(Q10[s] == W10[0][s] for s in (1, -1)), 'br.W010: the complex 16s agree on the labels (omega = -+J) and on the matrices (omega = -+i)')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ br.W55  the split cell Cl(5,5) on the Fock labels
head('br.W55  the split Cl(5,5) on the Fock labels (GEN-015, CAND-003): the weights n_a - 1/2 = e_a f_a / 2 on the 32 five-bit labels')
t = time.time()
E55 = (1, -1) * 5; L55 = lab_graded(E55); hf = Fr(1, 2)                  # e_a = bit 2a (square +1), f_a = bit 2a+1 (square -1), as GEN-015
A_ = [{1 << (2 * i): hf, 1 << (2 * i + 1): hf} for i in range(5)]; AD = [{1 << (2 * i): hf, 1 << (2 * i + 1): -hf} for i in range(5)]
def anti(L, x, y): return madd((1, L.mul(x, y)), (1, L.mul(y, x)))
okCAR = all(anti(L55, A_[i], AD[j]) == ({0: 1} if i == j else {}) and anti(L55, A_[i], A_[j]) == {} == anti(L55, AD[i], AD[j]) for i in range(5) for j in range(5))
PI = {0: Fr(1)}
for i in range(5): PI = L55.mul(PI, L55.mul(A_[i], AD[i]))
PHI = {}
for S in range(32):
    v = dict(PI)
    for i in reversed(range(5)):
        if S >> i & 1: v = L55.mul(AD[i], v)
    PHI[S] = v
NA = [(1 << (2 * a)) | (1 << (2 * a + 1)) for a in range(5)]               # the labels e_a f_a
okN = all(L55.mul({NA[a]: 1}, PHI[S]) == madd((2 * (S >> a & 1) - 1, PHI[S])) for S in range(32) for a in range(5))
P5 = {0: 1}
for x in NA: P5 = L55.mul(P5, {x: 1})
okG55 = P5 == {TOP: 1} and all(L55.mul({TOP: 1}, PHI[S]) == madd(((-1) ** (5 - pc(S)), PHI[S])) for S in range(32))
chk('bit', okCAR and okN and okG55, 'br.W55: in Cl(5,5) with the pairs interleaved (GEN-015) a_a = (e_a + f_a)/2, a_a* = (e_a - f_a)/2 satisfy the CAR; on the 32 Fock states a*_S Pi, exactly, e_a f_a a*_S Pi = (2 n_a - 1) a*_S Pi: n_a - 1/2 = e_a f_a / 2, a boost read directly, its sign the bit a of S; Gamma = e0 f0 .. e4 f4 is the product of the five e_a f_a and acts as (-1)^(5 - |S|)')
SIG55 = {S: tuple(2 * (S >> a & 1) - 1 for a in range(5)) for S in range(32)}
EV55 = [S for S in range(32) if pc(S) % 2 == (1 if FAULT == 'ODDLAB' else 0)]   # the even labels (the odd ones under ODDLAB)
W55 = Counter(SIG55[S] for S in EV55); wk = lambda S: pc(S & 3); col = lambda S: pc(S >> 2)
SA = [S for S in EV55 if wk(S) != 1 and col(S) % 2 == 0]; SB = [S for S in EV55 if wk(S) == 1 and col(S) % 2 == 1]
okB = len(SA) == len(SB) == 8 and len(EV55) == 16 and Counter(SIG55[S] for S in SA) == P214 and Counter(SIG55[S] for S in SB) == P124b
chk('bit', W55 == PS16 and okB, 'br.W55: the even labels read off the bits: weak bits 0, 1 both set or both clear with an even number of colour bits 2, 3, 4: %d labels, weights %s; one weak bit with an odd number: %d labels, %s; no other even label: %s, the Pati-Salam multiset, on Gamma = -1' % (len(SA), name_ms(Counter(SIG55[S] for S in SA)), len(SB), name_ms(Counter(SIG55[S] for S in SB)), name_ms(W55)))
T3 = lambda S: Fr((S & 1) - ((S >> 1) & 1), 2); Yh = lambda S: Fr(wk(S), 2) - Fr(col(S), 3)       # sm16_labels.py's T3 and Y
DBL = [S for S in EV55 if T3(S) != 0]; QL = [S for S in DBL if Yh(S) == Fr(1, 6)]; LL = [S for S in DBL if Yh(S) == Fr(-1, 2)]
chk('bit', sorted(DBL) == sorted(SB) and len(QL) == 6 and len(LL) == 2 and Counter(SIG55[S] for S in DBL) == P124b and Counter(SIG55[S] for S in SA) == P214,
    'br.W55: sm16_labels.py\'s physical naming: T3 = (n0 - n1)/2 is non-zero exactly on the %d even labels with one weak bit, with Y = a/2 - b/3 = 1/6 on %d (Q_L) and -1/2 on %d (L): Pati-Salam\'s (2_L,1,4), the 4 of Q_L and L, is the bits\' (1,2,4b), and its (1,2_R,4b) the bits\' (2,1,4); exchanging both su(2) names and 4 <-> 4b together keeps the sixteen weights' % (len(DBL), len(QL), len(LL)))
W55o = Counter(SIG55[S] for S in range(32) if pc(S) % 2)
chk('ctl', W55o == CJ16 != W55, 'br.W55: the odd labels carry %s, the conjugate (the 16b, CAND-019\'s negated weights): taken as the 16 they fail (ODDLAB)' % name_ms(W55o))
note('(%.1f s)' % (time.time() - t))
t = time.time()
def jw5():
    sm = np.array([[0., 1.], [0., 0.]]); Z = np.diag([1., -1.]); I2 = np.eye(2); out = []
    for k in range(5):
        fs = [I2] * 5
        for j in range(k): fs[4 - j] = Z
        fs[4 - k] = sm; out.append(kron_all(fs))
    return out
AJ = jw5(); GJ = []
for k in range(5): GJ += [(AJ[k] + AJ[k].T).astype(complex), 1j * (AJ[k] - AJ[k].T)]            # jordan_sm.py's gammas (compact)
def Eab(a, b): M = np.zeros((10, 10)); M[a, b] = 1; M[b, a] = -1; return M
J10 = sum(Eab(2 * k + 1, 2 * k) for k in range(5)); EK = [Eab(2 * k, 2 * k + 1) for k in range(5)]   # jordan_sm.py's J and the Cartan
def spin(X): return sum(0.5 * X[a, b] * GJ[a] @ GJ[b] for a in range(10) for b in range(a + 1, 10) if X[a, b])
blk = all(np.allclose(E[:4, 4:], 0) for E in EK) and all(np.allclose(E @ F, F @ E) for E in EK for F in EK) and all(np.allclose(E @ J10, J10 @ E) for E in EK)
okCl = all(np.allclose(GJ[a] @ GJ[b] + GJ[b] @ GJ[a], 2 * (a == b) * np.eye(32)) for a in range(10) for b in range(10))
GEN21 = [Eab(a, b) for a in range(10) for b in range(a + 1, 10) if (a < 4) == (b < 4)]           # so(4) + so(6), 6 + 15
hom = all(np.allclose(spin(X @ Y - Y @ X), spin(X) @ spin(Y) - spin(Y) @ spin(X)) for X in GEN21[:7] for Y in GEN21[5:12])
vw = sorted(tuple(int(round(np.real(np.vdot(v, E @ v) / 1j))) for E in EK) for v in np.linalg.eig(sum(NPR.standard_normal() * E for E in EK))[1].T)
NK = [AJ[k].T @ AJ[k] for k in range(5)]
okSp = all(np.allclose(spin(EK[k]), 1j * (NK[k] - 0.5 * np.eye(32))) for k in range(5))
WJ = Counter(tuple(int(round(np.real(spin(EK[k])[x, x] / 1j) * 2)) for k in range(5)) for x in range(32) if pc(x) % 2 == 0)
v10 = Counter(vw); okv = v10 == Counter([tuple(s * (t == k) for t in range(5)) for k in range(5) for s in (1, -1)])
chk('std', blk and okCl and hom and okSp and okv and WJ == PS16, 'br.W55: numpy, jordan_sm.py\'s route (no label): the 10 x 10 Cartan generators E(2k, 2k+1) are block diagonal on R^4 + R^6, commute with each other and with J, and have the vector weights +-e_k, (2,2,1) + (1,1,6); with the Jordan-Wigner gammas the spin map X -> (1/2) sum X_ab g_a g_b is a homomorphism on sampled pairs of so(4) + so(6), spin(E_k) = i (n_k - 1/2), and the even popcounts carry %s' % name_ms(WJ))
chk('bit==std', WJ == Counter(SIG55[S] for S in range(32) if pc(S) % 2 == 0) and len(EV55) == 16 and W55 == WJ, 'br.W55: the weights of the 16 agree on the labels (Witt basis of Cl(5,5)) and on the Jordan-Wigner Fock space')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ br.ONE  one multiset; the 32 with one complex structure
head('br.ONE  one multiset in the three cells; the 32 of Cl(1,9) with one complex structure against the 16 of so(10)')
t = time.time()
chk('bit', CPX[-1] == W10[0][-1] == W55 == PS16 and CPX[1] == W10[0][1] == W55o == CJ16, 'br.ONE: with the Cartan slots identified (so(4) slots, then the three so(6) slots, canonical orientation, one complex structure), the complexified half Gamma = -1 of Cl(1,9), the complex 16 with omega = -J of Cl(0,10) and the even five-bit labels of Cl(5,5) carry the same 16 weights, %s; in each cell the product of the five signs is the chirality (Gamma, omega J^-1, Gamma) and the 16 is its -1 eigenspace; the conjugate on the other half' % name_ms(PS16))
bivB = [(1 << i) | (1 << j) for i in range(4) for j in range(i + 1, 4)]; bivF = [(1 << i) | (1 << j) for i in range(4, 10) for j in range(i + 1, 10)]
cb32 = commutant_basis([IA.act(b) for b in bivB + bivF], IA.m); t32 = basis_type(cb32)
I32 = np.eye(IA.m, dtype=np.int64); FOUR = [I32, RA[TOP], RA[BI], RA[BW]]
ok4 = len(cb32) == 4 and rank_frac(np.array([F_.ravel() for F_ in FOUR])) == 4 and all(np.array_equal(F_ @ IA.act(b), IA.act(b) @ F_) for F_ in FOUR for b in bivB + bivF)
JJ = [('I', RA[BI]), ('-I', -RA[BI]), ('omega6', RA[BW]), ('-omega6', -RA[BW])]
ok4 &= all(np.array_equal(J @ J, -I32) for _, J in JJ)
W32 = {nm: wms(RA, J, 1) + wms(RA, J, -1) for nm, J in JJ}
chk('bit', t32 == ('C', 1, 2) and ok4 and all(sum(w.values()) == 16 and w != PS16 and w != CJ16 for w in W32.values()),
    'br.ONE: the 32 of Cl(1,9) as 16 complex fields: the commutant of so(1,3) + so(6) on it is %s = span{1, Gamma, I, omega6} (exact), whose square roots of -1 are the four +-I, +-omega6 (as in any C + C); with each the 32 is a complex 16 (16 weights), %s (I), %s (-I), %s (omega6), %s (-omega6): none is the multiset of the 16 of so(10), which is one half complexified' % (tstr(t32), name_ms(W32['I']), name_ms(W32['-I']), name_ms(W32['omega6']), name_ms(W32['-omega6'])))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ br.MAJ  the Majorana condition as a real structure
head('br.MAJ  the Majorana condition as a real structure: complex conjugation c on R^32 (x) C, the I-eigenspaces and the weights')
t = time.time()
# R^m (x) C as pairs (re, im) of exact integer vectors: a real operator M acts as rl(M), the scalar i as JX(m), c as CX(m) (the identity on the
# pairs under NOCONJ: no conjugation of the scalar)
def rl(M): Z = np.zeros_like(M); return np.block([[M, Z], [Z, M]])
def JX(m): Z = np.zeros((m, m), dtype=np.int64); E = np.eye(m, dtype=np.int64); return np.block([[Z, -E], [E, Z]])
def CX(m): E = np.eye(m, dtype=np.int64); Z = 0 * E; return np.block([[E, Z], [Z, E if FAULT == 'NOCONJ' else -E]])
def wcx(half2, P2, H, rot):
    """the weights, with the external i, on (half2/2) (P2/2) of R^m (x) C, realified: H the five Cartan matrices, a rotation slot read as
    H/i = -i H, a boost slot directly; complex multiplicities"""
    m = half2.shape[0]; I2m = np.eye(2 * m, dtype=np.int64); JJx = JX(m)
    hs = [(-JJx @ rl(h)) if r else rl(h) for h, r in zip(H, rot)]; base = rl(half2) @ P2; out = Counter()
    for sg in SIGNS:
        M = base.copy()
        for sk, h in zip(sg, hs): M = M @ (I2m + sk * h)
        d, r = divmod(int(np.trace(M)), 128); assert r == 0 and d % 2 == 0
        if d: out[sg] = d // 2
    return out
mA = IA.m; I2A = np.eye(2 * mA, dtype=np.int64); JA, CA = JX(mA), CX(mA)
SMAJ = 1 if FAULT == 'OTHERHALF' else -1                                  # the main lines' half: Gamma = -1 (+1 under OTHERHALF)
HALF = {s: np.eye(mA, dtype=np.int64) + s * RA[TOP] for s in (1, -1)}
P10, P01 = I2A - JA @ rl(RA[BI]), I2A + JA @ rl(RA[BI])                   # twice the projectors onto V(1,0) = {v - iIv}, V(0,1) = {v + iIv}
HA = [RA[x] for x in CART]
dims = [int(np.trace(rl(HALF[s]) @ P)) // 8 for s in (1, -1) for P in (P10, P01)]
okX = np.array_equal(CA @ CA, I2A) and np.array_equal(CA @ P10 @ CA, P01) and all(np.array_equal(CA @ rl(HALF[s]), rl(HALF[s]) @ CA) for s in (1, -1))
chk('bit', mA == 32 and dims == [8, 8, 8, 8] and int(np.trace(P10)) // 4 == 16 and okX,
    'br.MAJ: on R^32 (x) C (pairs of exact integer vectors) the eigenspaces of I (x) 1 on each half, V(1,0) = {v - iIv} (I = +i) and V(0,1) = {v + iIv}, have complex dimensions %s; on the whole 32 V(1,0) is a complex 16; c (v + iw) = v - iw squares to 1, keeps each half (Gamma real) and exchanges V(1,0) and V(0,1): c P(1,0) c = P(0,1)' % dims)
W10c, W01c = wcx(HALF[SMAJ], P10, HA, ROT19), wcx(HALF[SMAJ], P01, HA, ROT19)
okH = all(np.array_equal(CA @ ((-JA @ rl(h)) if r else rl(h)) @ CA, (rl(h) @ JA) if r else rl(h)) for h, r in zip(HA, ROT19))
okH &= Counter({conj_map(k, ROT19): v for k, v in W10c.items()}) == W01c
chk('bit', okH and W10c == P214 and W01c == P124b, 'br.MAJ: c commutes with the five Cartan blades (real operators): it keeps the eigenvalue of the boost and changes the sign of the four rotations\' eigenvalues +-i, so on so(4,C) + so(6) it is minus the weight with the two sl(2) factors exchanged; on the half Gamma = -1 V(1,0) carries %s and V(0,1) %s, and c maps the one onto the other weight by weight: the Majorana-Weyl condition pairs the left-handed 4 with the right-handed 4b in one real field' % (name_ms(W10c), name_ms(W01c)))
WO = {s: (wcx(HALF[s], P10, HA, ROT19), wcx(HALF[s], P01, HA, ROT19)) for s in (1, -1)}
selfc = all(sum(WO[s][0].values()) + sum(WO[s][1].values()) == 16 and prod5(next(iter(WO[s][0]))) == prod5(conj_map(next(iter(WO[s][0])), ROT19)) == s for s in (1, -1))
chk('bit', selfc and WO[1][0] == P214b and WO[1][1] == P124, 'br.MAJ: c keeps the product of the five signs (one boost, four rotations): each half\'s complexification is its own conjugate, the real form of a 16 (Majorana-Weyl); on Gamma = +1 it pairs %s with %s (the left-handed 4b with the right-handed 4)' % (name_ms(WO[1][0]), name_ms(WO[1][1])))
REALH = {s: np.vstack([HALF[s], np.zeros((mA, mA), dtype=np.int64)]) for s in (1, -1)}   # the real vectors (v, 0) of each half, as columns
rk_both = [rank_frac(P10 @ REALH[s]) for s in (1, -1)]; rk_map = rk_both[0] if rk_both[0] == rk_both[1] else -1
ok_sum = np.array_equal(P10 + P01, 2 * I2A) and all(np.array_equal(CA @ P10 @ REALH[s], P01 @ REALH[s]) for s in (1, -1))
gam5 = np.array_equal((JA @ rl(RA[BI])) @ P10, -P10)
chk('bit', rk_map == 16 and ok_sum and gam5, 'br.MAJ: on each half v -> (v - iIv)/2 maps the 16 real components onto V(1,0) with rank %d (real), a bijection onto its 8 complex dimensions, and v = (v - iIv)/2 + c((v - iIv)/2): the 16 real components are 8 complex numbers, the left-handed and the right-handed parts the same real components read with I or with -I; on V(1,0) gamma5 = i gamma0 gamma1 gamma2 gamma3 = iI acts as -1 (left-handed when P_L = (1 - gamma5)/2, a convention, recalled)' % rk_map)
sq3 = ([L19.sq(x) for x in CART], [L010.sq(x) for x in CART10], [L55.sq(x) for x in NA])
nrot = [sum(1 for v in q if v == -1) for q in sq3]
J0 = JQ[0]; H10 = [I010.act(x) for x in CART10]; h10 = I64 + (-1) * (OM10 @ (-J0)); P10q, P01q = np.eye(128, dtype=np.int64) - JX(64) @ rl(J0), np.eye(128, dtype=np.int64) + JX(64) @ rl(J0)
W10q, W01q = wcx(h10, P10q, H10, ROT10), wcx(h10, P01q, H10, ROT10)
chk('bit', nrot == [4, 5, 0] and W10q == PS16 and W01q == CJ16 and Counter({tuple(-x for x in k): v for k, v in W10q.items()}) == W01q,
    'br.MAJ: what c does in the three cells follows the squares of the Cartan blades (rotations %s of 5): Cl(1,9) keeps the product of the signs (real halves), Cl(5,5) keeps every weight (five boosts: real halves), Cl(0,10) negates all five: with J from its commutant, V(1,0) of the half omega = -J carries %s and c maps it onto %s in V(0,1): 16 <-> 16b, no real half (FUR-012)' % (nrot, name_ms(W10q), name_ms(W01q)))
chk('ctl', not np.array_equal(P10, P01) and np.array_equal(np.eye(2 * mA, dtype=np.int64) @ P10, P10) and wcx(HALF[-1], P10, HA, ROT19) != wcx(HALF[1], P10, HA, ROT19),
    'br.MAJ: controls: c taken linear (the identity on the complex scalar) keeps V(1,0) (no exchange, no pairing: NOCONJ); the other Weyl half pairs the left-handed 4b with the right-handed 4, not the 4 with the 4b (OTHERHALF)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
def cwords(G):
    n = len(G); W = [np.eye(G[0].shape[0], dtype=complex)]
    for a in range(1, 1 << n):
        top = a.bit_length() - 1; W.append(W[a ^ (1 << top)] @ G[top])
    return W
WC = cwords(CL19); WCi = [np.linalg.inv(w) for w in WC]; X0 = NPR.standard_normal((32, 32)) + 1j * NPR.standard_normal((32, 32))
BB = {}
for sgn in (1, -1):
    B = sum((sgn ** pc(a)) * np.conj(WC[a]) @ X0 @ WCi[a] for a in range(1024)); B = B / np.abs(B).max()
    lam = (B @ np.conj(B))[0, 0]; B = B / np.sqrt(abs(lam))
    BB[sgn] = (B, np.allclose(B @ np.conj(B), np.sign(lam.real) * np.eye(32)), float(np.sign(lam.real)),
               all(np.allclose(B @ g @ np.linalg.inv(B), sgn * np.conj(g)) for g in CL19))
Vv, Vals, _ = joint(OPS19); Bp = BB[1][0]; Bpi = np.linalg.inv(Bp); okcb = True; mp = {}
for j in range(32):
    w = Bpi @ np.conj(Vv[:, j]); w = w / np.linalg.norm(w)
    ev = [np.real(np.vdot(w, o @ w)) for o in OPS19]; okcb &= all(np.allclose(o @ w, e * w, atol=1e-8) for o, e in zip(OPS19, ev))
    mp[tuple(int(x) for x in Vals[j])] = tuple(int(round(e)) for e in ev)
okmap = all(v[0] == k[0] and v[1] == -k[1] and v[2:] == conj_map(k[2:], ROT19) for k, v in mp.items())
chk('std', all(BB[s][1] and BB[s][3] and BB[s][2] == 1 for s in (1, -1)) and okcb and okmap,
    'br.MAJ: numpy, Pauli words for Cl(1,9) (no label): B+ with B gamma B^-1 = gamma* and B- with -gamma* (group averages over the 1024 words) both exist with B B* = +1; c_B psi = B+^-1 psi* commutes with the ten gammas, keeps Gamma, sends I = +i to -i and every joint eigenvector of weight sigma to one of weight (-sigma_R, sigma_B, -sigma_f)')
chk('bit==std', okH and okmap and okX, 'br.MAJ: the real structure acts on the weights in the same way on the labels (c on the pairs) and on the matrices (c_B): the boost kept, the four rotations negated, the halves kept, V(1,0) and V(0,1) exchanged')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ br.SUM  sums of plane waves; the current
head('br.SUM  fields that depend on x: sums of plane waves on the coupling step\'s equation with the fibre momentum as a mass, nabla phi J = m f phi')
t = time.time()
# psi(x, y) = phi(x) e^(J m y) and D = nabla_x + sum_a f_a d/dy_a (FUR-013) give D psi J = (nabla phi J - m f phi) e^(J m y): the coupling step's
# nabla psi J = m psi gamma0 with the mass carried by the fibre momentum.  Right multiplication by J needs a left ideal that it keeps.
LB = L19 if GRADED else LU; LC = LU if GRADED else L19                     # the main lines' product and the control's
def moduleJ(L):
    """a left ideal A f, f from commuting labels of square +1 that commute with e1e2 (so right multiplication by J = e2e1 keeps it)"""
    G = comm_labels(L, first=(TOP,), tries=12, must=(ROT,)); I_ = Ideal(L, G)
    return I_, [I_.act(1 << mu) for mu in range(4)], I_.act(1 << 4), -I_.ract(ROT)
IBm, EB, FB, JB = moduleJ(LB); ICm, EC, FC, JCm = moduleJ(LC)
nB = IBm.m; IdB = np.eye(nB, dtype=np.int64); GENB = [IBm.act(1 << i) for i in range(10)]
cbB = commutant_basis(GENB, nB); tcbB = basis_type(cbB)
okMod = nB == 64 and rel_ok(GENB, E19) and np.array_equal(JB @ JB, -IdB) and all(np.array_equal(JB @ g, g @ JB) for g in GENB) and tcbB == ('R', 2, 1)
cbA = commutant_basis([IA.act(1 << i) for i in range(10)], IA.m)
okMin = len(cbA) == 1 and not any(len(comm_labels(L19, first=(TOP,), tries=4, must=(ROT,))) == 5 for _ in range(3))
chk('bit', okMod and okMin, 'br.SUM: no minimal ideal of Cl(1,9) = M32(R) is kept by right multiplication by J: such a map would commute with the ten generators, and their exact commutant on the minimal ideal is R (dimension %d), with no square root of -1 (the greedy search also finds at most four commuting labels of square +1 commuting with e1e2); the left ideal' % len(cbA) + ' from four such labels has dimension %d, the ten generators obey the relations of Cl(1,9) on it, J^2 = -1 commutes with them, and its exact commutant is %s: two copies of the 32, the size of fibre_base\'s S (x) O' % (nB, tstr(tcbB)))
def Kof(E, F, b, m): return sum(int(b[mu]) * E[mu] for mu in range(4)) + int(m) * F
def Qf(b): return b[0] ** 2 - b[1] ** 2 - b[2] ** 2 - b[3] ** 2
KSG = -1 if FAULT == 'SHELLSIGN' else 1                                    # the shell asserted: Q(b) = KSG m^2 (the other sign under SHELLSIGN)
SH4 = {1: [(5, 3, 0, 0), (5, 0, 3, 0), (4, 0, 0, 0), (-5, -3, 0, 0)], -1: [(3, 5, 0, 0), (3, 0, 5, 0), (0, 4, 0, 0), (-3, -5, 0, 0)]}
M1, M2 = 4, 8; BS = SH4[KSG]; BOFF = (6, 3, 0, 0); assert all(Qf(b) == KSG * M1 * M1 for b in BS)
okOp = all(np.array_equal(JB @ (sum(b[mu] * EB[mu] for mu in range(4)) @ JB) - M1 * FB, -Kof(EB, FB, b, M1)) for b in BS + [BOFF])
kerS = [nB - rank_frac(Kof(EB, FB, b, M1)) for b in BS]; kerO = nB - rank_frac(Kof(EB, FB, BOFF, M1))
chk('bit', okOp and kerS == [32] * 4 and kerO == 0, 'br.SUM: on Z e^(J b.x) the derivative d_mu acts as b_mu J, so nabla phi J - m f phi = -(b + m f) Z e^(J b.x) = -K_b Z e^(J b.x) (exact on the module), and a finite sum of distinct frequencies solves the equation exactly when every coefficient lies in ker K_b (distinct exponentials compared coefficient by coefficient, as shifted_tensor.py): at m = 4 the kernels at %s (Q = 16) are %s, at (6,3,0,0) (Q = 27) %d; the four-wave sum has a solution space of dimension %d, and with (6,3,0,0) added still %d' % (BS, kerS, kerO, sum(kerS), sum(kerS) + kerO))
G0 = {1: 1}; JMV = {ROT: -1}                                               # gamma0 = e0, J = gamma2 gamma1 = -e1e2 on the right
def Kmv(b, m): return madd(*[(Fr(b[mu]), {1 << mu: 1}) for mu in range(4) if b[mu]], (Fr(m), {16: 1}))
def rev(x): return {k: (v if (pc(k) * (pc(k) - 1) // 2) % 2 == 0 else -v) for k, v in x.items()}
def canon(nu):
    for x in nu:
        if x: return (nu, 1) if x > 0 else (tuple(-y for y in nu), -1)
    return (nu, 0)
def current(Rf, L):
    """psi gamma0 psi~ for an R-field psi = sum_b Z_b e^(J b.x): Z_a e^(J a.x) gamma0 e^(-J b.x) Z_b~ = cos((a - b).x) Z_a g0 Z_b~ + sin((a - b).x)
    Z_a g0 J Z_b~ (gamma0 commutes with J); returned as {nu: (C, S)}, nu the representative of +-(a - b) with its first non-zero entry positive"""
    out = {}
    for a, Za in Rf.items():
        for b, Zb in Rf.items():
            key, sg = canon(tuple(x - y for x, y in zip(a, b)))
            C = L.mul(L.mul(Za, G0), rev(Zb)); S = L.mul(L.mul(L.mul(Za, G0), JMV), rev(Zb)) if sg else {}
            c0, s0 = out.get(key, ({}, {})); out[key] = (madd((1, c0), (1, C)), madd((1, s0), (sg, S)))
    return {k: v for k, v in out.items() if v[0] or v[1]}
rfr = lambda: Fr(RNG.randint(-9, 9) or 1, RNG.randint(1, 5))
EVL = [a for a in range(1024) if pc(a) % 2 == 0]
RF = {}
for b in BS:
    X = {RNG.choice(EVL): rfr() for _ in range(3)}; RF[b] = LB.mul(Kmv(b, M1), X)       # P = K X: in ker K when K^2 = 0
okSol = all(RF[b] and LB.mul(Kmv(b, M1), RF[b]) == {} for b in BS)
CUR = current(RF, LB); ONE_ = [current({b: RF[b]}, LB) for b in BS]; z4 = (0, 0, 0, 0)
sum0 = madd(*[(1, c[z4][0]) for c in ONE_]); keys = {canon(tuple(x - y for x, y in zip(a, b)))[0] for i, a in enumerate(BS) for b in BS[i + 1:]}
qd = sorted((Qf(canon(tuple(x - y for x, y in zip(a, b)))[0]), (a[0] > 0) == (b[0] > 0)) for i, a in enumerate(BS) for b in BS[i + 1:])
okCur = okSol and all(set(c) == {z4} for c in ONE_) and CUR[z4][0] == sum0 and set(CUR) == keys | {z4} and all(CUR[k][0] or CUR[k][1] for k in keys)
okQd = all((q < 0) == same for q, same in qd)
chk('bit', okCur and okQd, 'br.SUM: on multivectors of Cl(1,9), P_b = K_b X_b (three random even blades) solves at the four frequencies; the current psi gamma0 psi~ of their sum is a trigonometric polynomial whose frequency-0 part is the sum of the four currents, with cross terms at the %d frequencies +-(b_j - b_l), none zero; Q(b_j - b_l) = %s: negative (spacelike) for two frequencies with k0 of one sign, positive for opposite signs' % (len(keys), [q for q, _ in qd]))
note('(%.1f s)' % (time.time() - t))
t = time.time()
# [std] item 3 on the realified Dirac matrices with gamma5 x L_u on R^64 (fibre_base.py's S (x) O, graded; 1 x L_u ungraded), J the realified i
I8f = np.eye(8)
GRDs = [np.kron(g, I8f) for g in GAM] + [np.kron(GAM5, L_) for L_ in OLM]; UNGs = [np.kron(g, I8f) for g in GAM] + [np.kron(I8f, L_) for L_ in OLM]
JS = np.kron(JC, I8f); GSm = GRDs if GRADED else UNGs; GSc = UNGs if GRADED else GRDs
def Ks(G, b, m): return sum(b[mu] * G[mu] for mu in range(4)) + m * G[4]
def nulls(A, tol=1e-9):
    _, s, Vt = np.linalg.svd(A); k = int((s > tol * max(s.max(), 1)).sum()); return Vt[k:].T
okJS = np.allclose(JS @ JS, -np.eye(64)) and all(np.allclose(JS @ g, g @ JS) for g in GSm)
NS = {b: nulls(Ks(GSm, b, M1)) for b in BS + [BOFF]}; kS_std = [NS[b].shape[1] for b in BS]; kO_std = NS[BOFF].shape[1]
coef = {b: NS[b] @ NPR.standard_normal(NS[b].shape[1]) if NS[b].shape[1] else np.zeros(64) for b in BS}
def phi(x, cf): return sum(np.cos(np.dot(b, x)) * Z + np.sin(np.dot(b, x)) * (JS @ Z) for b, Z in cf.items())
def Dphi(x, cf, m, G, h=1e-5):
    d = [(phi(x + h * e, cf) - phi(x - h * e, cf)) / (2 * h) for e in np.eye(4)]
    return JS @ sum(G[mu] @ d[mu] for mu in range(4)) - m * (G[4] @ phi(x, cf))
PTS = NPR.uniform(-1, 1, (6, 4)); scale = max(max(np.abs(phi(x, coef)).max() for x in PTS), 1e-300)
res_on = max(np.abs(Dphi(x, coef, M1, GSm)).max() for x in PTS) / scale
cf_off = dict(coef); cf_off[BOFF] = NPR.standard_normal(64); res_off = max(np.abs(Dphi(x, cf_off, M1, GSm)).max() for x in PTS) / scale
CLS = [BS[0], BS[1], BS[2], BOFF]                                         # one frequency of each +- class; (-5,-3,0,0) = -(5,3,0,0)
EVm = np.array([[f(np.dot(b, x)) for b in CLS for f in (np.cos, np.sin)] for x in NPR.uniform(-2, 2, (20, 4))]); rkE = int(np.linalg.matrix_rank(EVm))
chk('std', okJS and kS_std == [32] * 4 and kO_std == 0 and res_on < 1e-6 and res_off > 1e-2 and rkE == 8,
    'br.SUM: numpy, the realified Dirac matrices with gamma5 x L_u on R^64 and J the realified i (no label): kernels %s at the four frequencies and %d at (6,3,0,0); the four-wave sum with random coefficients in the kernels, evaluated at six random points with derivatives by central differences, solves the equation to %.0e (relative), and with a random (6,3,0,0) term added it fails by %.2f; the cos and sin of the four +- classes are independent functions (rank %d of 8 at 20 points), and J separates b from -b' % (kS_std, kO_std, res_on, res_off, rkE))
chk('bit==std', kS_std == kerS and kO_std == kerO, 'br.SUM: the kernels of the sum agree on the labels (the left ideal of dimension 64) and on the matrices (S (x) O): %d and %d' % (sum(kerS), sum(kS_std)))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ br.POL  amplitudes that depend on x
head('br.POL  amplitudes that depend on x: phi = P(x) e^(J k.x), P of degree <= 2 with exact rational coefficients, on and off the shell')
t = time.time()
def mons(d): return sorted([(a, b, c, e) for a in range(d + 1) for b in range(d + 1 - a) for c in range(d + 1 - a - b) for e in range(d + 1 - a - b - c)], key=lambda m_: (-sum(m_), m_))
def poly_rows(E, F, J, b, m, d):
    """(nabla P) J = K P for P = sum x^alpha P_alpha (degree <= d): for every monomial beta, sum_mu (beta_mu + 1) J E_mu P_(beta + e_mu) - K P_beta = 0
    (J commutes with E_mu); sparse integer rows, the unknowns of the highest degree first"""
    n = E[0].shape[0]; MS = mons(d); ix = {a: i for i, a in enumerate(MS)}; K = Kof(E, F, b, m); JE = [J @ E[mu] for mu in range(4)]; rows = []
    for beta in MS:
        blocks = [(ix[beta], -K)] + [(ix[up], (beta[mu] + 1) * JE[mu]) for mu in range(4) for up in [tuple(beta[s] + (s == mu) for s in range(4))] if up in ix]
        for r in range(n):
            row = {}
            for bi, Mb in blocks:
                for c in np.flatnonzero(Mb[r]): row[bi * n + int(c)] = row.get(bi * n + int(c), 0) + int(Mb[r, c])
            rows.append({k: v for k, v in row.items() if v})
    return rows, len(MS) * n
def pdims(E, F, J, b, m): return [nc - rank_sparse(rw) for rw, nc in (poly_rows(E, F, J, b, m, d) for d in range(3))]
PON, POFF = pdims(EB, FB, JB, BS[0], M1), pdims(EB, FB, JB, BOFF, M1)
def deriv_solutions(E, F, J, b, m, tangents):
    """the plane waves of ker K_b and the first derivatives along the shell: for a tangent t (Minkowski-orthogonal to b), d/du of
    K(u) X e^(J k(u).x) is (t-hat X + (t.x) J K X) e^(J k.x), unknowns ordered as poly_rows (degree 1 first); integer vectors"""
    n = E[0].shape[0]; MS = mons(1); ix = {a: i for i, a in enumerate(MS)}; K = Kof(E, F, b, m); JK = J @ K; vecs = []
    for v in nullspace_frac(K.tolist(), n):
        den = 1
        for x in v: den = den * x.denominator // gcd(den, x.denominator)
        w = [0] * (len(MS) * n); c0 = ix[(0, 0, 0, 0)]
        for i, x in enumerate(v): w[c0 * n + i] = int(x * den)
        vecs.append(w)
    for tv in tangents:
        T = sum(tv[mu] * E[mu] for mu in range(4))
        for i in range(n):
            w = [0] * (len(MS) * n); c0 = ix[(0, 0, 0, 0)]
            for r in range(n): w[c0 * n + r] = int(T[r, i])
            for mu in range(4):
                if tv[mu]:
                    cm = ix[tuple(int(s == mu) for s in range(4))]
                    for r in range(n): w[cm * n + r] = int(tv[mu] * JK[r, i])
            vecs.append(w)
    return vecs
TAN = [(3, 5, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1)]; assert all(t_[0] * BS[0][0] - sum(t_[k] * BS[0][k] for k in (1, 2, 3)) == 0 for t_ in TAN) or KSG == -1
DV = deriv_solutions(EB, FB, JB, BS[0], M1, TAN); RW1, _ = poly_rows(EB, FB, JB, BS[0], M1, 1)
solves = all(sum(c * w[k] for k, c in row.items()) == 0 for row in RW1 for w in DV)
rkD = rank_sparse([{k: x for k, x in enumerate(w) if x} for w in DV])
chk('bit', PON == [32, 128, 320] and POFF == [0, 0, 0], 'br.POL: the equation on P(x) e^(J k.x) is (nabla P) J = K P, order by order in x (exact sparse ranks over Q, 64, 320 and 960 unknowns): at the shell point %s (m = 4) the solution spaces of degree <= 0, 1, 2 have dimensions %s, increments %s = 32 x (1, 3, 6), the number of monomials of degree 0, 1, 2 in three variables: the constants and more; at (6,3,0,0) (off the shell, K invertible) %s' % (BS[0], PON, [PON[0], PON[1] - PON[0], PON[2] - PON[1]], POFF))
chk('bit', solves and rkD == PON[1] == 128, 'br.POL: the first derivatives along the shell are such solutions: for the three tangents (3,5,0,0), (0,0,1,0), (0,0,0,1) at (5,3,0,0), d/du of K(u) X e^(J k(u).x) = (t X + (t.x) J K X) e^(J k.x) solves the degree-1 system exactly for every X, and with the plane waves of ker K they span a space of dimension %d: the whole solution space of degree <= 1' % rkD)
note('(%.1f s)' % (time.time() - t))
t = time.time()
def poly_mat(G, J, b, m, d):
    n = G[0].shape[0]; MS = mons(d); ix = {a: i for i, a in enumerate(MS)}; K = Ks(G, b, m); A = np.zeros((len(MS) * n, len(MS) * n))
    for beta in MS:
        i = ix[beta]; A[i * n:(i + 1) * n, i * n:(i + 1) * n] -= K
        for mu in range(4):
            up = tuple(beta[s] + (s == mu) for s in range(4))
            if up in ix: j = ix[up]; A[i * n:(i + 1) * n, j * n:(j + 1) * n] += (beta[mu] + 1) * (J @ G[mu])
    return A
def pnull(G, J, b, m):
    out = []
    for d in range(3):
        A = poly_mat(G, J, b, m, d); s = np.linalg.svd(A, compute_uv=False); out.append(A.shape[1] - int((s > 1e-8 * s.max()).sum()))
    return out
PON_s, POFF_s = pnull(GSm, JS, BS[0], M1), pnull(GSm, JS, BOFF, M1)
chk('std', PON_s == [32, 128, 320] and POFF_s == [0, 0, 0], 'br.POL: numpy, the same system on S (x) O (SVD of the 64 x 64 blocks, up to 960 x 960): on the shell %s, off it %s' % (PON_s, POFF_s))
chk('bit==std', PON_s == PON and POFF_s == POFF, 'br.POL: the polynomial solution spaces agree on the labels (exact) and on the matrices (SVD), on and off the shell')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ br.KK  two fibre momenta in one field
head('br.KK   two fibre momenta m1 != m2 in one field: psi = sum Z e^(J (b.x + m y)), the equation keyed by (b, m)')
t = time.time()
SH8 = {1: (10, 6, 0, 0), -1: (6, 10, 0, 0)}[KSG]; assert Qf(SH8) == KSG * M2 * M2
TWO = [(BS[0], M1), (SH8, M2)]; SAME = [(BS[0], M1), (BS[0], M2)]
kT = [nB - rank_frac(Kof(EB, FB, b, m)) for b, m in TWO]; kS = [nB - rank_frac(Kof(EB, FB, b, m)) for b, m in SAME]
chk('bit', kT == [32, 32] and kS == [32, 0], 'br.KK: distinct (b, m) are distinct exponentials in (x, y), so the equation separates and each term needs its own shell Q(b) = m^2: m1 = 4 at %s and m2 = 8 at %s give kernels %s, a solution space of %d; one spacetime momentum %s for both masses gives %s: the m2 term must vanish (two masses from two fibre momenta, the first two rungs of a Kaluza-Klein tower, recalled; the masses are inputs, the Atlas says nothing about their spectrum)' % (BS[0], SH8, kT, sum(kT), BS[0], kS))
kU = [ICm.m - rank_frac(Kof(EC, FC, b, M1)) for b in SH4[1]]; kUm = ICm.m - rank_frac(Kof(EC, FC, (3, 5, 0, 0), M1))
PU = pdims(EC, FC, JCm, SH4[1][0], M1); PUm = pdims(EC, FC, JCm, (3, 5, 0, 0), M1); IdC = np.eye(ICm.m, dtype=np.int64)
okKU = all(np.array_equal(Kof(EC, FC, b, M1) @ (Kof(EC, FC, b, 0) - M1 * FC), (Qf(b) + M1 * M1) * IdC) for b in SH4[1] + SH4[-1] + [BOFF])
chk('ctl', okKU and kU == [0] * 4 and kUm == 32 and PU == [0, 0, 0], 'br.KK: the ungraded product (its left ideal of dimension %d with right J): K_u (k - m f) = Q(k) + m^2 exactly at nine frequencies, and at the four of the mass shell the kernels are %s, so no superposition and no polynomial amplitude there (%s); plane waves only at Q(k) = -m^2 (kernel %d at (3,5,0,0)), where the polynomial solution spaces of degree <= 0, 1, 2 have dimensions %s (UNGRADED)' % (ICm.m, kU, PU, kUm, PUm))
kW = [nB - rank_frac(Kof(EB, FB, b, M1)) for b in SH4[-1]]; PW = pdims(EB, FB, JB, SH4[-1][0], M1)
chk('ctl', (kW == [0] * 4 and PW == [0, 0, 0]) if GRADED else True, 'br.KK: the shell of the other sign, E^2 = |p|^2 - m^2 (Q = -16 at %s), is empty in the graded product: kernels %s, polynomial solution spaces %s (SHELLSIGN)' % (SH4[-1], kW, PW))
note('(%.1f s)' % (time.time() - t))
t = time.time()
kT_s = [nulls(Ks(GSm, b, m)).shape[1] for b, m in TWO]; kS_s = [nulls(Ks(GSm, b, m)).shape[1] for b, m in SAME]
kU_s = [nulls(Ks(GSc, b, M1)).shape[1] for b in SH4[1]]
chk('std', kT_s == [32, 32] and kS_s == [32, 0] and (kU_s == [0] * 4 if GRADED else True), 'br.KK: numpy on S (x) O: two masses at their shells %s, one momentum for both %s; the ungraded matrices (1 x L_u) at the mass shell %s' % (kT_s, kS_s, kU_s))
chk('bit==std', kT_s == kT and kS_s == kS, 'br.KK: the kernels of the two-mass fields agree on the labels and on the matrices')
note('not computed: fields on a manifold, wave packets as integrals over the shell, the Majorana condition on quantum fields, the spectrum of fibre momenta; which product, split or signature nature uses (an input, INP-011)')
note('(%.1f s)' % (time.time() - t))
finish()
