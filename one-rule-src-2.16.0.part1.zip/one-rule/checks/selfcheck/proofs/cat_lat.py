#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cat_lat.py -- six small statements of categories, posets and lattices on the bit labels: the face poset of the n-cube and its polar,
the Euler characteristic of a finite poset, the weight lattice of A2 as the Eisenstein lattice, Peirce decompositions as Morita contexts,
the representation numbers of the Eisenstein norm, and the Dedekind numbers.

Statements.
(1) The faces of the n-cube are the intervals [S, T] = {U : S <= U <= T} of 2^[n] (the coordinates in S fixed at 1, those outside T fixed at 0),
    ordered by inclusion; equivalently the pairs (A, Z) of disjoint bit masks (fixed to 1, fixed to 0), A = S, Z = [n] minus T. The k-faces
    number 2^(n-k) C(n,k); the map (A, Z) -> {+e_i : i in A} + {-e_i : i in Z} reverses inclusion onto the faces of the cross-polytope, which
    has 2^(k+1) C(n,k+1) faces of dimension k; the Moebius function of the face poset is (-1)^(dim G - dim F) on every interval, that of 2^[n] is
    (-1)^|T minus S|.
(2) For a finite poset Leinster's Euler characteristic, the sum of the entries of the inverse of the zeta matrix (the Moebius sum, also the
    sum of the weighting), equals the Euler characteristic of the order complex, sum_k (-1)^k c_k, c_k the number of chains of k+1 elements. On
    the Boolean lattice B_n both are 1; on its proper part (B_n minus the bottom and the top) both are 1 + (-1)^n, the sphere S^(n-2).
(3) The weight lattice of A2, with the Killing-normalised form (roots of squared length 2) scaled by 3/2, is the Eisenstein lattice Z[w]
    with the norm x^2 - xy + y^2: the six roots are its vectors of norm 3, the six weights +-w_k its vectors of norm 1; the root lattice is the
    ideal (1 - w), of index 3. The 126 roots of E7 projected on the plane of its last two simple roots have norms 0, 1, 3 for 30, 90, 6 roots.
(4) For orthogonal idempotents e_i summing to 1, A = sum e_i A e_j, and e_iAe_j * e_jAe_k lies in e_iAe_k; for an idempotent e with AeA = A the
    algebra A is Morita equivalent to eAe. In Cl(n,n) (n = 2, 3) the 2^n Peirce idempotents give 2^n x 2^n lines and matrix units, so A = M_(2^n)(R);
    every non-empty sum e of k of them has dim eAe = k^2 (all sums, from the table) and AeA = A (n = 2: all 15 sums by exact rank; n = 3: all 8
    single idempotents and a seeded sample of 10 sums by exact rank, the other sums follow from P_S = P_S e P_S); the six real and five complex
    Peirce blocks of the model of Cl(0,8) = M_16(R) have the dimensions 62 + 194 and 16 + 48 over C.
(5) The number r(N) of (x, y) in Z^2 with x^2 - xy + y^2 = N is 6 sum_{d | N} chi(d), chi the character mod 3 (0, 1, -1 for d = 0, 1, 2 mod 3),
    for every N from 1 to 10^4; r(N) = 0 for N = 2 mod 3; the theta series begins 1 + 6q + 6q^3 + 6q^4 + 12q^7.
(6) The number of up-sets of B_k (the empty and the full up-set included; equivalently the antichains, the monotone Boolean functions of k
    variables) is 2, 3, 6, 20, 168, 7581, 7828354 for k = 0..6.
[bit]  Bit masks: faces as pairs (A, Z) with geometric faces recomputed as argmax sets of integer functionals (n <= 5; the cross-polytope n <= 4);
       the signed cube category (3^n arrows, every square anticommutes), the 4^n composable pairs against the (face, vertex) incidences; the
       defining recursion of the Moebius function on every interval (n <= 6, with and without the empty face); B_n by the subset test, the
       weighting by back-substitution, chains by dynamic programming; A2 from its Cartan matrix and E7 from its Cartan matrix by reflections; the
       bit-rule algebra Cl(n,n) with the Peirce idempotents from the null pairs (e_i + f_i)/2, matrix units built and multiplied exactly; r(N) by
       enumeration; antichains of B_k by backtracking over the labels (k = 6: 7828354 antichains).
[std]  Intervals of the Boolean lattice enumerated as pairs of masks; numpy inversion of the zeta matrix; brute-force chains (n <= 4); the textbook
       polar of the cube [-1,1]^n; integer arithmetic on Z[w] (pairs (a, b), w^2 = -1 - w); numpy matrices and ranks for M_n(R) and for the model of
       Cl(0,8); the divisor sum; the recursion M(k+1) = number of pairs f <= g of monotone functions of k variables (numpy).
[ctl]  The cross-polytope's f-vector in place of the cube's; a Moebius function with the wrong sign; the polar map taken as order preserving;
       posets with two maximal elements (not contractible); the transposed zeta matrix (the weighting changes); the scale 1/2 on the weight
       lattice; the sublattice of index 2; an idempotent that is not full; idempotents that are not orthogonal; a character with the wrong period;
       the count without the factor 6; the count without the empty and the full up-set; strict pairs f < g. Each wrong version is also a --fault
       option that puts it into the main lines (the run must then end with FAILS).
Scope. n <= 6 (faces; geometric faces n <= 5), n <= 6 (posets), N <= 10^4, k <= 6, Cl(n,n) for n = 2, 3. Theorems for every n or N (Ziegler,
       Stanley, Leinster, the ideal-class theorem, Morita) are recalled, not claimed. No engine object is built: the script is silent under
       faults of the gravity engine.
Run:   python3 cat_lat.py [--fault CROSSF|MUSIGN|DUALORD|TWOMAX|ZTRANS|SCALE12|IDX2|NONFULL|NONORTH|CHI4|NOSIX|DEDM2|DEDSTRICT]
       (from the package root as selfcheck/proofs/cat_lat.py; also from its own folder, and under -I -B)"""
import os, sys, itertools, importlib.util, time, math, random
from fractions import Fraction as F
from math import comb
from collections import Counter
sys.dont_write_bytecode = True
import numpy as np

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'CATLAT'
HERE = os.path.dirname(os.path.abspath(__file__))
SELF = os.path.dirname(HERE)                                        # selfcheck/
ROOT = os.path.dirname(SELF)                                        # the package root
FAULT_NAMES = ['CROSSF', 'MUSIGN', 'DUALORD', 'TWOMAX', 'ZTRANS', 'SCALE12', 'IDX2', 'NONFULL', 'NONORTH', 'CHI4', 'NOSIX', 'DEDM2', 'DEDSTRICT']
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
def pc(x): return bin(x).count('1')
def bits(m):
    while m:
        low = m & -m
        yield low.bit_length() - 1
        m ^= low
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)

# =============================================================================================================== 1. the face poset of the n-cube
def cube_faces(n):
    """[bit] the faces of the n-cube as pairs (A, Z) of disjoint masks: A fixed to 1, Z fixed to 0, the rest free"""
    full = (1 << n) - 1; out = []
    for A in range(1 << n):
        rest = full & ~A; z = rest
        while True:
            out.append((A, z))
            if z == 0: break
            z = (z - 1) & rest
    return out
def vertices_of(n, A, Z):
    m = 0
    for U in range(1 << n):
        if (U & A) == A and (U & Z) == 0: m |= 1 << U
    return m
def interval_vertices(n):
    """[std] every interval [S, T] of the Boolean lattice 2^[n] (S subset of T), with its vertex set U, S <= U <= T, as a mask over the 2^n labels"""
    out = {}
    for S in range(1 << n):
        for T in range(1 << n):
            if (S & T) == S:
                m = 0; d = T & ~S; w = d
                while True:
                    m |= 1 << (S | w)
                    if w == 0: break
                    w = (w - 1) & d
                out[(S, T)] = m
    return out
def mobius_rec(up):
    """the defining recursion mu(x,x) = 1, mu(x,y) = -sum_{x <= z < y} mu(x,z); up[i] = mask of j with i <= j; the index order is a linear extension"""
    N = len(up); down = [0] * N
    for i in range(N):
        for j in bits(up[i]): down[j] |= 1 << i
    mu = {}
    for x in range(N):
        mux = {x: 1}
        for y in bits(up[x] & ~(1 << x)):
            s = 0
            for z in bits(up[x] & down[y] & ~(1 << y)): s += mux[z]
            mux[y] = -s
        for y, v in mux.items(): mu[(x, y)] = v
    return mu, down
def argmax_faces(n):
    """[bit] the faces of [0,1]^n as the argmax sets of the 5^n integer functionals c in {-2..2}^n on the 2^n vertices (masks over the labels)"""
    V = np.array([[(U >> i) & 1 for i in range(n)] for U in range(1 << n)], dtype=np.int64)
    C = np.array(list(itertools.product(range(-2, 3), repeat=n)), dtype=np.int64)
    val = C @ V.T
    faces = set()
    for row in val:
        mx = row.max(); m = 0
        for U in np.nonzero(row == mx)[0]: m |= 1 << int(U)
        faces.add(m)
    return faces
def argmax_orthoplex(n):
    """[bit] the faces of the n-cross-polytope as argmax sets on its 2n vertices +-e_i (mask: bit i = +e_i, bit n+i = -e_i)"""
    C = np.array(list(itertools.product(range(-2, 3), repeat=n)), dtype=np.int64)
    faces = set()
    for c in C:
        val = list(c) + list(-c); mx = max(val)
        faces.add(sum(1 << j for j in range(2 * n) if val[j] == mx))
    return faces

head('1. CAND-104: the face poset of the n-cube, its polar, the f-vectors, the Moebius function (n <= 6)')
for n in range(1, 7):
    faces = cube_faces(n); dims = [n - pc(A) - pc(Z) for A, Z in faces]
    fvec = Counter(dims)
    cube_f = [2 ** (n - k) * comb(n, k) for k in range(n + 1)]
    cross_f = [2 ** (k + 1) * comb(n, k + 1) for k in range(n)]
    want = cross_f if fault('CROSSF') else cube_f
    chk('bit', len(faces) == 3 ** n and [fvec[k] for k in range(len(want))] == want and sum((-1) ** k * cube_f[k] for k in range(n + 1)) == 1,
        'n = %d: %d faces as pairs (A, Z) of disjoint masks (3^n); f-vector %s = 2^(n-k) C(n,k); sum (-1)^k f_k = 1' % (n, len(faces), [fvec[k] for k in range(n + 1)]))
    if n >= 3:
        chk('ctl', [cube_f[k] for k in range(n)] != cross_f, 'n = %d: the cross-polytope f-vector %s differs from the cube\'s %s (the formula is not symmetric)' % (n, cross_f, cube_f[:n]))
    # cat.K1a again: the arrows a -> b (a subset of b) and the signed squares
    arrows = sum(1 for a in range(1 << n) for b in range(1 << n) if (a & b) == a)
    sg = lambda a, i: -1 if pc(a & ((1 << i) - 1)) & 1 else 1
    sq_ok = all(sg(a, i) * sg(a | 1 << i, j) * sg(a, j) * sg(a | 1 << j, i) == -1 for a in range(1 << n) for i in range(n) for j in range(i + 1, n) if not (a >> i) & 1 and not (a >> j) & 1)
    chk('bit', arrows == 3 ** n and arrows == len(faces) and sq_ok,
        'n = %d: the cube category has %d arrows a -> b (a subset of b) = the number of faces; with the sign (-1)^(set bits below i) on a -> a + {i} every square anticommutes' % (n, arrows))
    # bd.mjg.19 again: composable pairs S <= T <= U against the (face, vertex) incidences
    vmk = [vertices_of(n, A, Z) for A, Z in faces]
    inc = {(m, U) for m in vmk for U in range(1 << n) if (m >> U) & 1}
    comp = [(S, T, U) for U in range(1 << n) for T in range(1 << n) if (T & U) == T for S in range(1 << n) if (S & T) == S]
    if n <= 5:
        img = {(vertices_of(n, S, (((1 << n) - 1) & ~U)), T) for (S, T, U) in comp}
        chk('bit', len(comp) == 4 ** n and len(img) == 4 ** n and img == inc,
            'n = %d: %d composable pairs S <= T <= U = 4^n; (S, T, U) -> (face [S, U], vertex T) is a bijection onto the %d incidences (face, vertex)' % (n, len(comp), len(inc)))
    else:
        chk('bit', len(comp) == 4 ** n, 'n = %d: %d composable pairs S <= T <= U = 4^n' % (n, len(comp)))
tline('part 1a')

for n in range(1, 7):
    # the order: [bit] (A, Z) <= (A', Z') iff A' subset A and Z' subset Z; [std] inclusion of the vertex sets of the intervals [S, T]
    faces = cube_faces(n); full = (1 << n) - 1
    ivs = interval_vertices(n)
    vm = [ivs[(A, full & ~Z)] for A, Z in faces]
    vm_bit = [vertices_of(n, A, Z) for A, Z in faces]
    chk('bit==std', len(ivs) == 3 ** n and vm == vm_bit and len(set(vm)) == len(vm),
        'n = %d: the %d intervals [S, T] of 2^[n] and the faces (A, Z) correspond by A = S, Z = [n] minus T: the same vertex sets, all distinct' % (n, len(ivs)))
    N = len(faces); ok_ord = True
    for i in range(N):
        Ai, Zi = faces[i]
        for j in range(N):
            Aj, Zj = faces[j]
            if ((Aj & ~Ai) == 0 and (Zj & ~Zi) == 0) != ((vm[i] & ~vm[j]) == 0): ok_ord = False
    chk('bit==std', ok_ord, 'n = %d: (A, Z) <= (A\', Z\') in the bit order (A\' subset A, Z\' subset Z) exactly when the vertex set of the first interval lies in that of the second, all %d pairs' % (n, N * N))
tline('part 1b')

for n in range(1, 6):
    gf = argmax_faces(n); faces = cube_faces(n)
    chk('bit', gf == {vertices_of(n, A, Z) for A, Z in faces} and len(gf) == 3 ** n,
        'n = %d: the argmax sets of the %d integer functionals on the %d vertices are exactly the %d vertex sets of the faces (A, Z)' % (n, 5 ** n, 1 << n, len(gf)))
for n in range(1, 5):
    og = argmax_orthoplex(n); faces = cube_faces(n); full = (1 << n) - 1
    phi = lambda A, Z: A | (Z << n)
    nonempty = {phi(A, Z) for A, Z in faces if A | Z}
    og_f = Counter((bin(m).count('1') - 1) if m != (1 << (2 * n)) - 1 else n for m in og)
    chk('bit', og == nonempty | {(1 << (2 * n)) - 1} and [og_f[k] for k in range(n)] == [2 ** (k + 1) * comb(n, k + 1) for k in range(n)],
        'n = %d: the argmax sets on the 2n vertices +-e_i of the cross-polytope are the %d signed sets without an antipodal pair, plus the whole polytope; f-vector %s = 2^(k+1) C(n,k+1)' % (n, len(og), [og_f[k] for k in range(n)]))

for n in range(1, 7):
    faces = cube_faces(n); full = (1 << n) - 1
    # the polar map: [bit] by the masks; [std] the textbook polar of [-1,1]^n on the vertex coordinates
    phi_bit = [A | (Z << n) for A, Z in faces]
    ivs = interval_vertices(n); vm = [ivs[(A, full & ~Z)] for A, Z in faces]
    H = [sum(1 << U for U in range(1 << n) if (U >> i) & 1) for i in range(n)]               # the labels U that have bit i
    phi_std = []
    for m in vm:
        plus = sum(1 << i for i in range(n) if (m & ~H[i]) == 0)                              # +e_i: x_i = +1 on every vertex of the face
        minus = sum(1 << i for i in range(n) if (m & H[i]) == 0)                              # -e_i: x_i = -1 on every vertex of the face
        phi_std.append(plus | (minus << n))
    chk('bit==std', phi_bit == phi_std and len(set(phi_bit)) == 3 ** n and all(p & (p >> n) == 0 for p in phi_bit),
        'n = %d: the polar of the face (A, Z) of [-1,1]^n, {y in {+-e_i} : <x,y> = 1 for all x in the face} (integers), is {+e_i : i in A} + {-e_i : i in Z}: a bijection onto the %d signed sets without an antipodal pair' % (n, 3 ** n))
    N = len(faces); rev = pres = True
    for i in range(N):
        Ai, Zi = faces[i]
        for j in range(N):
            Aj, Zj = faces[j]
            le = (Aj & ~Ai) == 0 and (Zj & ~Zi) == 0                                          # face i <= face j
            sub = (phi_bit[j] & ~phi_bit[i]) == 0                                              # phi(j) subset of phi(i)
            if le and not sub: rev = False
            if le and not (phi_bit[i] & ~phi_bit[j]) == 0: pres = False
    dim_ok = all(bin(phi_bit[i]).count('1') - 1 == n - 1 - (n - pc(A) - pc(Z)) for i, (A, Z) in enumerate(faces))
    chk('bit', (pres if fault('DUALORD') else rev) and dim_ok,
        'n = %d: the polar map reverses inclusion on all %d pairs and sends a face of dimension d to one of dimension n - 1 - d (the whole cube goes to the empty face; with the empty face of the cube going to the whole cross-polytope the complete lattices are anti-isomorphic)' % (n, N * N))
    chk('ctl', not pres, 'n = %d: the polar map does not preserve inclusion (it is order reversing, not order preserving)' % n)
tline('part 1c')

for n in range(1, 7):
    faces = cube_faces(n); full = (1 << n) - 1
    els = sorted(faces, key=lambda f: n - pc(f[0]) - pc(f[1]))                              # by dimension: a linear extension
    dims = [n - pc(A) - pc(Z) for A, Z in els]
    for with_empty in (False, True):
        E = ([None] if with_empty else []) + els; D = ([-1] if with_empty else []) + dims; N = len(E)
        def leq(x, y):
            if x is None: return True
            if y is None: return False
            return (y[0] & ~x[0]) == 0 and (y[1] & ~x[1]) == 0
        up = [sum(1 << j for j in range(N) if leq(E[i], E[j])) for i in range(N)]
        mu, down = mobius_rec(up)
        sgn = (lambda dx, dy: (-1) ** (dy - dx + 1)) if fault('MUSIGN') else (lambda dx, dy: (-1) ** (dy - dx))
        ok = all(mu[(x, y)] == sgn(D[x], D[y]) for (x, y) in mu) and len(mu) == sum(pc(u) for u in up)
        chk('bit', ok, 'n = %d%s: the defining recursion gives mu(F, G) = (-1)^(dim G - dim F) on all %d intervals F <= G' % (n, ' with the empty face (dim -1)' if with_empty else '', len(mu)))
        if with_empty or n <= 5:
            Zm = np.zeros((N, N))
            for i in range(N):
                for j in bits(up[i]): Zm[i, j] = 1.0
            Mi = np.linalg.inv(Zm)
            Ex = np.zeros((N, N))
            for (x, y) in mu: Ex[x, y] = (-1) ** (D[y] - D[x])
            chk('std', np.abs(Mi - Ex).max() < 1e-9, 'n = %d%s: numpy inverse of the %d x %d zeta matrix = (-1)^(dim G - dim F) on F <= G and 0 elsewhere (max deviation %.1e)' % (n, ' with the empty face' if with_empty else '', N, N, np.abs(Mi - Ex).max()))
        if with_empty and n <= 4:
            wrong = {(x, y): -v for (x, y), v in mu.items()}
            bad = any(sum(wrong[(x, z)] for z in range(N) if (x, z) in wrong and (up[z] >> y) & 1) != (1 if x == y else 0) for (x, y) in wrong)
            chk('ctl', bad, 'n = %d: with the opposite sign the sum of mu over [F, G] is not delta(F, G) (the identity sum_{F <= H <= G} mu(F, H) = delta fixes the sign)' % n)
# the Boolean lattice 2^[n] itself
for n in range(1, 7):
    N = 1 << n; up = [sum(1 << y for y in range(N) if (x & y) == x) for x in range(N)]
    order = sorted(range(N), key=pc); pos = {x: i for i, x in enumerate(order)}
    up2 = [sum(1 << pos[y] for y in range(N) if (x & y) == x) for x in order]
    mu, _ = mobius_rec(up2)
    chk('bit', all(v == (-1) ** pc(order[y] ^ order[x]) for (x, y), v in mu.items()), 'n = %d: the Moebius function of 2^[n] is (-1)^|T minus S| on all %d intervals S <= T' % (n, len(mu)))
tline('part 1')

# =============================================================================================================== 2. Leinster's Euler characteristic
def up_masks(elems, leq):
    return [sum(1 << j for j, y in enumerate(elems) if leq(x, y)) for x in elems]
def weighting(up, transpose=False):
    """k with Z k = 1 (sum_{y >= x} k_y = 1), by back-substitution from the maximal elements; transpose=True solves Z^T k = 1 instead"""
    N = len(up)
    if not transpose:
        k = [F(0)] * N
        for x in sorted(range(N), key=lambda i: pc(up[i])): k[x] = 1 - sum(k[y] for y in bits(up[x] & ~(1 << x)))
        return k
    down = [0] * N
    for i in range(N):
        for j in bits(up[i]): down[j] |= 1 << i
    l = [F(0)] * N
    for y in sorted(range(N), key=lambda i: pc(down[i])): l[y] = 1 - sum(l[x] for x in bits(down[y] & ~(1 << y)))
    return l
def chain_counts(up):
    """c_k = number of chains x_0 < ... < x_k (k+1 elements), by dynamic programming over the strict order"""
    N = len(up); down = [0] * N
    for i in range(N):
        for j in bits(up[i] & ~(1 << i)): down[j] |= 1 << i
    e = [1] * N; cs = []
    while sum(e):
        cs.append(sum(e)); e = [sum(e[x] for x in bits(down[y])) for y in range(N)]
    return cs
def chi_order(cs): return sum((-1) ** k * c for k, c in enumerate(cs))
def leinster(up):
    """[bit] the Moebius sum from the defining recursion, the sum of the weighting, and the sum of the coweighting"""
    order = sorted(range(len(up)), key=lambda i: pc(up[i]), reverse=True)
    pos = {x: i for i, x in enumerate(order)}
    up2 = [sum(1 << pos[y] for y in bits(up[x])) for x in order]
    mu, _ = mobius_rec(up2)
    return sum(mu.values()), sum(weighting(up)), sum(weighting(up, True))
def std_chi(up):
    """[std] numpy: the entry sum of the inverse of the zeta matrix"""
    N = len(up)
    if N == 0: return 0
    Zm = np.zeros((N, N))
    for i in range(N):
        for j in bits(up[i]): Zm[i, j] = 1.0
    return int(round(float(np.linalg.inv(Zm).sum())))
def std_chains_bruteforce(up):
    """[std] every subset of the elements tested for being a chain (n <= 4: at most 2^16 subsets)"""
    N = len(up); tot = 0
    comp = [[(up[a] >> b) & 1 or (up[b] >> a) & 1 for b in range(N)] for a in range(N)]
    for r in range(1, N + 1):
        for S in itertools.combinations(range(N), r):
            if all(comp[a][b] for a, b in itertools.combinations(S, 2)): tot += (-1) ** (r - 1)
    return tot

head('2. CAND-096: Leinster\'s Euler characteristic equals the Moebius sum and the Euler characteristic of the order complex')
for n in range(1, 7):
    N = 1 << n; elems = list(range(N)); up = up_masks(elems, lambda x, y: (x & y) == x)
    mob, wsum, lsum = leinster(up)
    cs = chain_counts(up); co = chi_order(cs)
    ways = [0] * N; ways[0] = 1
    for x in range(1, N): ways[x] = sum(ways[x ^ (1 << i)] for i in range(n) if (x >> i) & 1)
    k = weighting(up)
    chk('bit', mob == wsum == lsum == co == 1 and ways[N - 1] == math.factorial(n) and k == [F(int(x == N - 1)) for x in range(N)],
        'B_%d: Moebius sum %d = sum of the weighting %s = sum of the coweighting %s = alternating chain count %d (chains by size %s); the weighting is the indicator of the top; %d maximal chains = n!' % (n, mob, wsum, lsum, co, cs, ways[N - 1]))
    # the proper part
    prop = list(range(1, N - 1)); upp = up_masks(prop, lambda x, y: (x & y) == x)
    if prop:
        mobp, wp, lp = leinster(upp); csp = chain_counts(upp); cop = chi_order(csp)
    else:
        mobp = wp = lp = cop = 0; csp = []
    want = 1 + (-1) ** n
    mu0 = (-1) ** n
    chk('bit', mobp == wp == lp == cop == want and cop - 1 == mu0,
        'B_%d proper part (%d elements): Moebius sum %d = weighting sum %s = chain count %d = 1 + (-1)^n = %d (the sphere S^%d); reduced characteristic %d = mu(bottom, top) = (-1)^n' % (n, len(prop), mobp, wp, cop, want, n - 2, cop - 1))
    if n <= 6:
        chk('std', std_chi(up) == 1 and std_chi(upp) == want, 'B_%d: numpy inverse of the zeta matrix has entry sum 1; of the proper part %d' % (n, want))
    if n <= 4:
        bf = std_chains_bruteforce(up); bfp = std_chains_bruteforce(upp) if prop else 0
        chk('std', bf == 1 and bfp == want, 'B_%d: all subsets of the %d elements tested as chains: alternating count %d; of the proper part %d (brute force)' % (n, N, bf, bfp))
tline('part 2a')
small = {}
def poset_from_cover(names, rel):
    idx = {a: i for i, a in enumerate(names)}; N = len(names)
    le = [[i == j for j in range(N)] for i in range(N)]
    for a, b in rel: le[idx[a]][idx[b]] = True
    for k in range(N):
        for i in range(N):
            for j in range(N):
                if le[i][k] and le[k][j]: le[i][j] = True
    order = sorted(range(N), key=lambda i: sum(le[j][i] for j in range(N)))
    return [sum(1 << p for p, j in enumerate(order) if le[i][j]) for i in order]
small['antichain of 2'] = (poset_from_cover(['a', 'b'], []), 2)
small['crown (two minimal, two maximal)'] = (poset_from_cover(['a1', 'a2', 'b1', 'b2'], [('a1', 'b1'), ('a1', 'b2'), ('a2', 'b1'), ('a2', 'b2')]), 0)
small['N'] = (poset_from_cover(['a', 'b', 'c', 'd'], [('a', 'c'), ('b', 'c'), ('b', 'd')]), 1)
small['V'] = (poset_from_cover(['a', 'b', 'c'], [('a', 'b'), ('a', 'c')]), 1)
small['chain of 4'] = (poset_from_cover(['a', 'b', 'c', 'd'], [('a', 'b'), ('b', 'c'), ('c', 'd')]), 1)
small['pentagon N5'] = (poset_from_cover(['o', 'a', 'b', 'c', 'i'], [('o', 'a'), ('a', 'b'), ('b', 'i'), ('o', 'c'), ('c', 'i')]), 1)
small['three-point antichain with a top'] = (poset_from_cover(['a', 'b', 'c', 't'], [('a', 't'), ('b', 't'), ('c', 't')]), 1)
for name, (up, val) in small.items():
    mob, wsum, lsum = leinster(up); co = chi_order(chain_counts(up))
    chk('bit', mob == wsum == lsum == co == val and std_chi(up) == val and std_chains_bruteforce(up) == val,
        '%s: Moebius sum = weighting sum = coweighting sum = order complex characteristic = %d (numpy and brute-force chains agree)' % (name, co))
crown = small['crown (two minimal, two maximal)'][0]; anti = small['antichain of 2'][0]
chi_crown = leinster(crown)[0]; chi_anti = leinster(anti)[0]
chk('bit' if fault('TWOMAX') else 'ctl', (chi_crown == 1 and chi_anti == 1) if fault('TWOMAX') else (chi_crown != 1 and chi_anti != 1),
    'posets with two maximal elements (the crown: a circle, characteristic %d; the antichain of 2: %d) do not have characteristic 1: the value 1 belongs to posets with a top or a bottom, the identity Moebius sum = order complex holds on all of them' % (chi_crown, chi_anti))
for n in range(1, 5):
    N = 1 << n; up = up_masks(list(range(N)), lambda x, y: (x & y) == x)
    k_ok = weighting(up); k_t = weighting(up, True)
    def Zk(vec): return [sum(vec[y] for y in bits(up[x])) for x in range(N)]
    main = k_t if fault('ZTRANS') else k_ok
    chk('bit' if fault('ZTRANS') else 'ctl', (Zk(main) == [1] * N) if fault('ZTRANS') else (Zk(k_t) != [1] * N and Zk(k_ok) == [1] * N and sum(k_t) == sum(k_ok)),
        'B_%d: the transposed zeta matrix gives the weight of the bottom, not of the top: it does not solve Z k = 1 (the sums agree, the vectors do not)' % n)
tline('part 2')

# =============================================================================================================== 3. the weight lattice of A2 and the Eisenstein lattice
def inv2(M):
    a, b, c, d = M[0][0], M[0][1], M[1][0], M[1][1]; det = a * d - b * c
    return [[F(d) / det, F(-b) / det], [F(-c) / det, F(a) / det]], det
def zmul(u, v):                                         # [std] Z[w], w^2 = -1 - w: (a + b w)(c + d w)
    return (u[0] * v[0] - u[1] * v[1], u[0] * v[1] + u[1] * v[0] - u[1] * v[1])
def zconj(u): return (u[0] - u[1], -u[1])
def znorm(u): return u[0] * u[0] - u[0] * u[1] + u[1] * u[1]
def lat_index(g1, g2):
    return abs(g1[0] * g2[1] - g1[1] * g2[0])

head('3. CAND-107: the weight lattice of A2 is the Eisenstein lattice; the root lattice is the ideal (1 - w) of index 3')
C = [[2, -1], [-1, 2]]
Gw, detC = inv2(C)                                                               # Gram matrix of the fundamental weights = C^-1
scale = F(1, 2) if fault('SCALE12') else 1 / Gw[0][0]                           # the scale making the shortest weight of norm 1 (3/2)
Qform = lambda x, y: scale * (Gw[0][0] * x * x + 2 * Gw[0][1] * x * y + Gw[1][1] * y * y)
roots = [(2, -1), (-1, 2), (1, 1)]; roots += [(-a, -b) for a, b in roots]       # alpha_i = sum_j C_ij omega_j in weight coordinates
wts = [(1, 0), (-1, 1), (0, -1)]; wts += [(-a, -b) for a, b in wts]               # the weights of the 3 and their negatives
chk('bit', Gw == [[F(2, 3), F(1, 3)], [F(1, 3), F(2, 3)]] and detC == 3 and (scale == F(3, 2) or fault('SCALE12')),
    'A2: the Gram matrix of the fundamental weights is C^-1 = [[2/3, 1/3], [1/3, 2/3]] (squared length 2/3), det C = 3; the scale that gives the shortest weight norm 1 is %s (roots 2 * %s = %s)' % (scale, scale, 2 * scale))
chk('bit', all(Qform(*r) == 3 for r in roots) and all(Qform(*w) == 1 for w in wts) and all(Qform(*w).denominator == 1 for w in wts + roots),
    'A2 scaled: the six roots have norm 3 and the six weights +-w_k (w_1 = omega_1, w_2 = omega_2 - omega_1, w_3 = -omega_2) have norm 1; every weight norm is an integer (norm of x omega_1 + y omega_2 = x^2 + xy + y^2)')
w_half = F(1, 2) * Gw[0][0]
chk('ctl', w_half.denominator != 1 and F(1, 2) * 2 == 1,
    'scale 1/2: the roots then have norm 1 and the weights norm %s (not integral): the scale 3/2 is forced by the integrality of the weight lattice' % w_half)
box = [(x, y) for x in range(-8, 9) for y in range(-8, 9)]
n1 = {v for v in box if v[0] ** 2 + v[0] * v[1] + v[1] ** 2 == 1}
n3 = {v for v in box if v[0] ** 2 + v[0] * v[1] + v[1] ** 2 == 3}
chk('bit', n1 == set(wts) and n3 == set(roots) and not any(v[0] ** 2 + v[0] * v[1] + v[1] ** 2 == 2 for v in box),
    'in the box |x|, |y| <= 8 of weight coordinates: the vectors of norm 1 are exactly the six weights, those of norm 3 exactly the six roots, none has norm 2')
phi = lambda v: (v[0], -v[1])                                                     # omega_1 -> 1, omega_2 -> -w
chk('bit==std', all(znorm(phi(v)) == v[0] ** 2 + v[0] * v[1] + v[1] ** 2 for v in box) and all(zmul(phi(v), zconj(phi(v))) == (znorm(phi(v)), 0) for v in box),
    'the map omega_1 -> 1, omega_2 -> -w (pairs (a, b) = a + b w) is an isometry onto (Z[w], norm a^2 - ab + b^2) on the box (%d vectors), and z * conj(z) = norm in Z[w] by integer arithmetic' % len(box))
units = {(a, b) for a in range(-3, 4) for b in range(-3, 4) if znorm((a, b)) == 1}
chk('std', units == {(1, 0), (-1, 0), (0, 1), (0, -1), (-1, -1), (1, 1)} and all(zmul(u, zconj(u)) == (1, 0) for u in units) and zmul((0, 1), zmul((0, 1), (0, 1))) == (1, 0),
    'Z[w]: the six elements of norm 1 are +-1, +-w, +-w^2 = -+(1 + w) (the units), w^3 = 1; none of norm 2')
ideal_gen = [zmul((1, -1), (1, 0)), zmul((1, -1), (0, 1))]                         # (1 - w) * 1 and (1 - w) * w
rootlat = [phi(roots[0]), phi(roots[1])]
idx_ideal = lat_index(*ideal_gen); idx_root = lat_index(*rootlat)
def in_lat(v, g1, g2):                                                             # integer coordinates of v in the lattice spanned by g1, g2
    d = g1[0] * g2[1] - g1[1] * g2[0]; a = F(v[0] * g2[1] - v[1] * g2[0], d); b = F(g1[0] * v[1] - g1[1] * v[0], d)
    return a.denominator == 1 and b.denominator == 1
same = all(in_lat(v, *ideal_gen) for v in rootlat) and all(in_lat(v, *rootlat) for v in ideal_gen)
mult_closed = all(in_lat(zmul(z, g), *ideal_gen) for g in ideal_gen for z in [(1, 0), (0, 1), (1, 1)])
res3 = Counter((a + b) % 3 for a in range(-9, 10) for b in range(-9, 10) if in_lat((a, b), *ideal_gen))
want_idx = 2 if fault('IDX2') else 3
chk('bit', idx_root == want_idx and idx_ideal == want_idx and same and mult_closed and set(res3) == {0},
    'the root lattice (alpha_1, alpha_2 mapped by omega_1 -> 1, omega_2 -> -w) has index det C = %d in Z[w]; it equals the ideal (1 - w) = {a + b w : a + b = 0 mod 3} (index %d, closed under multiplication by w); the norm of 1 - w is 3' % (idx_root, idx_ideal))
wrong_sub = [(2, 0), (0, 1)]                                                       # <2 omega_1, omega_2> in the weight coordinates
chk('ctl', lat_index(*wrong_sub) == 2 and not all(in_lat(phi(r), phi(wrong_sub[0]), phi(wrong_sub[1])) for r in roots),
    'the sublattice <2 omega_1, omega_2> has index 2 and does not contain the roots: it is not the root lattice (index 3)')
# E7 from its Cartan matrix: the shadows of the 126 roots on the plane of the last two simple roots
edges7 = [(0, 2), (2, 3), (3, 1), (3, 4), (4, 5), (5, 6)]                         # Bourbaki: 1-3, 3-4, 4-2, 4-5, 5-6, 6-7
C7 = [[2 if i == j else (-1 if (i, j) in edges7 or (j, i) in edges7 else 0) for j in range(7)] for i in range(7)]
simple = [tuple(1 if j == i else 0 for j in range(7)) for i in range(7)]
R7 = set(simple); front = list(simple)
while front:
    nxt = []
    for v in front:
        for i in range(7):
            w = list(v); w[i] -= sum(v[j] * C7[j][i] for j in range(7)); w = tuple(w)
            if w not in R7: R7.add(w); nxt.append(w)
    front = nxt
sh = Counter(); onplane = set()
for v in R7:
    t1 = sum(v[j] * C7[j][5] for j in range(7)); t2 = sum(v[j] * C7[j][6] for j in range(7))
    N_ = t1 * t1 + t1 * t2 + t2 * t2; sh[N_] += 1
    if N_ == 3: onplane.add(v)
inplane = {v for v in R7 if all(v[j] == 0 for j in range(5))}
chk('bit', len(R7) == 126 and sh == Counter({0: 30, 1: 90, 3: 6}) and onplane == inplane and len(inplane) == 6,
    'E7 (Cartan matrix, Bourbaki labels, 126 roots by reflections): the shadows on the plane of alpha_6, alpha_7 have Eisenstein norm (3/2)|p|^2 = t_1^2 + t_1 t_2 + t_2^2 equal to %s; those of norm 3 are exactly the 6 roots of the A2 on that plane (baez T1b again)' % dict(sorted(sh.items())))
tline('part 3')

# =============================================================================================================== 4. Peirce decompositions and Morita contexts
def span_basis(vecs, stop_at=None):
    """exact reduced echelon basis (rows as dicts) of the span of the vectors; stops early once stop_at independent rows are found"""
    piv = {}
    for v in vecs:
        v = {k: F(c) for k, c in v.items() if c}
        for k in list(piv):
            if k in v:
                c = v[k]
                for kk, vv in piv[k].items():
                    nv = v.get(kk, 0) - c * vv
                    if nv: v[kk] = nv
                    else: v.pop(kk, None)
        if v:
            p = min(v); c = v[p]; v = {k: x / c for k, x in v.items()}
            for k in piv:
                if p in piv[k]:
                    cc = piv[k][p]
                    for kk, vv in v.items():
                        nv = piv[k].get(kk, 0) - cc * vv
                        if nv: piv[k][kk] = nv
                        else: piv[k].pop(kk, None)
            piv[p] = v
            if stop_at is not None and len(piv) >= stop_at: break
    return list(piv.values())

class BitAlg:
    """the bit rule: e_a e_b = s(a, b) e_(a xor b), s(a, b) = (-1)^#{(i in a, j in b, j < i)} prod_{i in a and b} eps_i"""
    def __init__(self, eps):
        self.eps = list(eps); self.m = len(eps); M = 1 << self.m
        self.s = [[self._sgn(a, b) for b in range(M)] for a in range(M)]
    def _sgn(self, a, b):
        c = 0; x = a; i = 0
        while x:
            if x & 1: c += pc(b & ((1 << i) - 1))
            x >>= 1; i += 1
        v = -1 if c & 1 else 1; x = a & b; i = 0
        while x:
            if x & 1: v *= self.eps[i]
            x >>= 1; i += 1
        return v
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            sa = self.s[a]
            for b, cb in y.items():
                v = sa[b]
                if v: out[a ^ b] = out.get(a ^ b, 0) + v * ca * cb
        return {k: v for k, v in out.items() if v}
def vadd(x, y, c=1):
    out = dict(x)
    for k, v in y.items(): out[k] = out.get(k, 0) + c * v
    return {k: v for k, v in out.items() if v}
def vscale(x, c): return {k: c * v for k, v in x.items() if c * v}

def peirce_clnn(n):
    A = BitAlg([1] * n + [-1] * n); M = 1 << (2 * n); one = {0: F(1)}
    Ni = []
    for i in range(n):
        nu = {1 << i: F(1, 2), 1 << (n + i): F(1, 2)}; nub = {1 << i: F(1, 2), 1 << (n + i): F(-1, 2)}
        chk('bit', not A.mul(nu, nu) and not A.mul(nub, nub) and vadd(A.mul(nu, nub), A.mul(nub, nu)) == one,
            'Cl(%d,%d), pair %d: nu = (e + f)/2 and nubar = (e - f)/2 are null and {nu, nubar} = 1' % (n, n, i))
        Ni.append(A.mul(nu, nub))
    P = {}
    for S in range(1 << n):
        x = one
        for i in range(n): x = A.mul(x, Ni[i] if (S >> i) & 1 else vadd(one, Ni[i], -1))
        P[S] = x
    return A, P, M
def prod3(A, a, x, b): return A.mul(A.mul(a, x), b)

head('4. CAND-098: Peirce decompositions in Cl(n,n) and in the model of Cl(0,8); the Morita context of an idempotent')
CL = {}
for n in (2, 3):
    A, P, M = CL[n] = peirce_clnn(n); NS = 1 << n; one = {0: F(1)}; blades = [{b: F(1)} for b in range(M)]
    orth = all(A.mul(P[S], P[T]) == (P[S] if S == T else {}) for S in range(NS) for T in range(NS))
    tot = {}
    for S in range(NS): tot = vadd(tot, P[S])
    chk('bit', orth and tot == one, 'Cl(%d,%d) (dimension %d): the %d Peirce idempotents P_S (products of N_i = nu_i nubar_i and 1 - N_i) are orthogonal idempotents and sum to 1 (bd.mja.9 again)' % (n, n, M, NS))
    # the Peirce spaces and the table of dimensions
    dimtab = {}
    for T in range(NS):
        for S in range(NS):
            dimtab[(T, S)] = len(span_basis(prod3(A, P[T], b, P[S]) for b in blades))
    chk('bit', all(v == 1 for v in dimtab.values()) and sum(dimtab.values()) == M,
        'Cl(%d,%d): dim P_T A P_S = 1 for all %d pairs (T, S); their sum %d = dim A = 4^n, so A = sum P_T A P_S is a direct sum of lines' % (n, n, NS * NS, sum(dimtab.values())))
    # matrix units: u_{T,S0} and v_{S0,T}, normalised so that v u = P_S0
    S0 = 0; u = {}; v = {}
    for T in range(NS):
        u[T] = next(w for b in blades for w in [prod3(A, P[T], b, P[S0])] if w)
        v[T] = next(w for b in blades for w in [prod3(A, P[S0], b, P[T])] if w)
    cst_ok = True
    for T in range(NS):
        w = A.mul(v[T], u[T]); key = next(iter(P[S0])); c = F(w.get(key, 0)) / P[S0][key]
        cst_ok &= c != 0 and w == vscale(P[S0], c); v[T] = vscale(v[T], 1 / c)
    chk('bit', cst_ok, 'Cl(%d,%d): the composition P_S0 A P_T times P_T A P_S0 lands in the line P_S0 A P_S0 = R P_S0 with a non-zero constant for every T (the pairings of the Morita context are onto)' % (n, n))
    Eu = {(T, S): A.mul(u[T], v[S]) for T in range(NS) for S in range(NS)}
    mu_ok = all(A.mul(Eu[(T, S)], Eu[(S2, U)]) == (Eu[(T, U)] if S == S2 else {}) for T in range(NS) for S in range(NS) for S2 in range(NS) for U in range(NS))
    pcs_ok = all(Eu[(T, S)] and prod3(A, P[T], Eu[(T, S)], P[S]) == Eu[(T, S)] for T in range(NS) for S in range(NS))
    tr = {}
    for T in range(NS): tr = vadd(tr, Eu[(T, T)])
    allsub = [Tt for r in range(1, NS + 1) for Tt in itertools.combinations(range(NS), r)]
    chk('bit', all(sum(dimtab[(a, b)] for a in Tt for b in Tt) == len(Tt) ** 2 for Tt in allsub),
        'Cl(%d,%d): for all %d non-empty sums e of k Peirce idempotents the lines add up to dim eAe = k^2 (the corner eAe is the sum of the k^2 lines P_S A P_S\')' % (n, n, len(allsub)))
    chk('bit', mu_ok and pcs_ok and tr == one,
        'Cl(%d,%d): matrix units E_TS = u_T v_S in P_T A P_S with E_TS E_S\'U = delta_SS\' E_TU (%d products, exact) and sum E_TT = 1: the bimodules P_T A P_S compose as e_iAe_j * e_jAe_k in e_iAe_k, and A = M_%d(R), the type the clock gives' % (n, n, NS ** 4, NS))
    # sums of Peirce idempotents: eAe and AeA
    subs = allsub
    ok_dim = ok_full = True; nrank = 0
    rng = random.Random(4 * n)
    pick = subs if n == 2 else rng.sample(subs, 10)
    for Tset in pick:
        e = {}
        for S in Tset: e = vadd(e, P[S])
        k = len(Tset)
        eAe = len(span_basis(prod3(A, e, b, e) for b in blades))
        Ae = span_basis(A.mul(b, e) for b in blades); eA = span_basis(A.mul(e, b) for b in blades)
        AeA = span_basis((A.mul(w, b) for w in Ae for b in blades), stop_at=M)
        ok_dim &= eAe == k * k and len(Ae) == k * NS and len(eA) == k * NS
        ok_full &= len(AeA) == M; nrank += 1
    chk('bit', ok_dim and ok_full,
        'Cl(%d,%d): for %d sums e of k Peirce idempotents (%s): dim eAe = k^2 (eAe = M_k(R)), dim Ae = dim eA = k 2^n, and AeA = A by exact rank %d: the pairing Ae (x)_(eAe) eA -> A is onto between spaces of the same dimension, so A is Morita equivalent to eAe' % (n, n, nrank, 'all' if n == 2 else 'a seeded sample', M))
    full_all = all(len(span_basis((A.mul(w, b) for w in span_basis(A.mul(b2, P[S]) for b2 in blades) for b in blades), stop_at=M)) == M for S in range(NS))
    chk('bit', full_all, 'Cl(%d,%d): every single Peirce idempotent is full (AeA = A); since P_S = P_S e P_S for e a sum containing P_S, every non-empty sum is full: all %d of them' % (n, n, len(subs)))
    if n == 3: tline('Cl(3,3)')
# controls: a non-full idempotent; idempotents that are not orthogonal
A1 = BitAlg([1]); e1 = {0: F(1, 2), 1: F(1, 2)}; bl1 = [{0: F(1)}, {1: F(1)}]
idem1 = A1.mul(e1, e1) == e1
AeA1 = len(span_basis(A1.mul(A1.mul(b, e1), b2) for b in bl1 for b2 in bl1))
A, P, M = CL[2]; blades = [{b: F(1)} for b in range(M)]
e0 = {}
dimAeA_zero = len(span_basis(A.mul(A.mul(b, e0), b2) for b in blades for b2 in blades))
chk('bit' if fault('NONFULL') else 'ctl', (dimAeA_zero == M) if fault('NONFULL') else (dimAeA_zero == 0 and idem1 and AeA1 == 1),
    'a non-full idempotent: e = 0 in Cl(2,2) has AeA = 0 (rank 0 < 16); in Cl(1,0) = R + R the idempotent (1 + e)/2 has AeA of dimension %d < 2, and eAe = R is not Morita equivalent to A (A has two simple modules)' % AeA1)
nonorth = [P[0], vadd(P[0], P[1])]                                                  # both idempotents, P_0 (P_0 + P_1) = P_0 != 0
def family_stats(fam):
    orth = all(A.mul(fam[i], fam[j]) == {} for i in range(2) for j in range(2) if i != j)
    return orth, sum(len(span_basis(prod3(A, fam[i], b, fam[j]) for b in blades)) for i in range(2) for j in range(2))
orth_bad, sdim_bad = family_stats(nonorth); orth_ok, sdim_ok = family_stats([P[0], P[1]])
chk('bit' if fault('NONORTH') else 'ctl', (orth_bad and sdim_bad == M) if fault('NONORTH') else (not orth_bad and A.mul(nonorth[0], nonorth[1]) == nonorth[0] and sdim_bad != M and sdim_bad == 9),
    'idempotents that are not orthogonal (P_0 and P_0 + P_1): the product is P_0, not 0, they do not sum to 1, and the four spaces e_iAe_j have total dimension %d, not 16: the Peirce decomposition needs orthogonal idempotents summing to 1 (for P_0, P_1 the four spaces have total dimension %d and do not fill A either)' % (sdim_bad, sdim_ok))
# the model of Cl(0,8) = M_16(R): the six real blocks
def load(name, *rel):
    spec = importlib.util.spec_from_file_location(name, os.path.join(ROOT, *rel))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
fm = load('furey_model', 'reports', 'furey', 'model.py')
E8, I8, I16, Lmat, Rmat, diag2 = fm.E, fm.I8, fm.I16, fm.Lmat, fm.Rmat, fm.diag2
k7 = E8[3]; Lk, Rk = Lmat(k7), Rmat(k7); LR = Lk @ Rk
def proj(P8, second):
    Pm = np.zeros((16, 16)); Pm[:8, :8] = P8
    for m in second: Pm[8 + m, 8 + m] = 1
    return Pm
blocks = [proj((I8 - LR) / 2, ()), proj((I8 + LR) / 2, ()), proj(0 * I8, (4, 5, 6, 7)), proj(0 * I8, (1, 2)), proj(0 * I8, (3,)), proj(0 * I8, (0,))]
Bi = [np.rint(2 * Pm).astype(np.int64) for Pm in blocks]                                  # 2 P with integer entries
chk('bit', all(np.abs(2 * Pm - Bm).max() < 1e-12 for Pm, Bm in zip(blocks, Bi)) and all(np.array_equal(Bi[a] @ Bi[b], (2 * Bi[a]) * int(a == b)) for a in range(6) for b in range(6)) and np.array_equal(sum(Bi), 2 * np.eye(16, dtype=np.int64)),
    'Furey model (16 x 16, octonion multiplication matrices): the six block projectors, written as 2P with integer entries, are orthogonal idempotents ((2P_a)(2P_b) = 2 delta_ab (2P_a)) and sum to 1 (exact integers)')
rk = [int(np.trace(Bm)) // 2 for Bm in Bi]
chk('bit', rk == [2, 6, 4, 2, 1, 1] and sum(r * r for r in rk) == 62 and sum(rk) ** 2 - sum(r * r for r in rk) == 194 and sum(rk) ** 2 == 256,
    'the ranks (traces of the idempotents, exact) are %s; sum r_i r_j = 256 = dim M_16(R), of which %d on the diagonal and %d off it' % (rk, sum(r * r for r in rk), 256 - sum(r * r for r in rk)))
tab = [[int(np.linalg.matrix_rank(np.kron(blocks[b].T, blocks[a]), tol=1e-9)) for b in range(6)] for a in range(6)]
chk('std', all(tab[a][b] == rk[a] * rk[b] for a in range(6) for b in range(6)),
    'numpy: dim P_a A P_b = rank of the 256 x 256 Kronecker matrix P_b^T (x) P_a (tolerance 1e-9) = r_a r_b for all 36 pairs: table %s' % tab)
# A e A = A for each block: the products E_ab e E_cd = e_bc E_ad reach every matrix unit
fullok = True
for Bm in Bi:
    reach = {(a, d) for a in range(16) for d in range(16) for bb in range(16) for c in range(16) if Bm[bb, c] != 0}
    fullok &= len(reach) == 256
chk('bit', fullok, 'for each of the six blocks e, the products E_ab e E_cd = e_bc E_ad (e_bc an entry of e) reach all 256 matrix units: AeA = A, and eAe = M_r(R) of dimension r^2 = %s' % [r * r for r in rk])
om = diag2(Lk)
ncomp = np.vstack([np.kron(np.eye(16), om) - np.kron(om.T, np.eye(16))]); u_, s_, vt_ = np.linalg.svd(ncomp)
rr_ = int(np.sum(s_ > 1e-9)); cb = [vt_[rr_ + c].reshape(16, 16, order='F') for c in range(256 - rr_)]
Q = [blocks[0], blocks[1], blocks[2], blocks[3], blocks[4] + blocks[5]]; cr = [int(round(np.trace(q))) // 2 for q in Q]
ctab = [[int(np.linalg.matrix_rank(np.array([(Q[a] @ X @ Q[b]).reshape(-1) for X in cb]), tol=1e-9)) for b in range(5)] for a in range(5)]
chk('std', len(cb) == 128 and cr == [1, 3, 2, 1, 1] and all(ctab[a][b] == 2 * cr[a] * cr[b] for a in range(5) for b in range(5)) and sum(c * c for c in cr) == 16 and 64 - 16 == 48
    and all(np.abs(om @ q - q @ om).max() < 1e-12 for q in Q),
    'numpy: the complex structure omega (omega^2 = -1) commutes with the five blocks; the commutant has real dimension 128 (M_8(C)); dim_R Q_a A_C Q_b = 2 c_a c_b for the blocks c = %s (numerical ranks, tolerance 1e-9): 16 on the diagonal, 48 off it' % cr)
# [std] M_N(R) with diagonal idempotents
okm = True
for Nn in (2, 3, 4, 5):
    for k in range(1, Nn):
        e = np.diag([1.0] * k + [0.0] * (Nn - k))
        eAe = np.linalg.matrix_rank(np.kron(e.T, e)); AeA = np.linalg.matrix_rank(np.array([(np.outer(np.eye(Nn)[a], np.eye(Nn)[b]) @ e @ np.outer(np.eye(Nn)[c], np.eye(Nn)[d])).reshape(-1) for a in range(Nn) for b in range(Nn) for c in range(Nn) for d in range(Nn)]))
        Ae = np.linalg.matrix_rank(np.kron(e.T, np.eye(Nn))); eA = np.linalg.matrix_rank(np.kron(np.eye(Nn), e))
        okm &= eAe == k * k and AeA == Nn * Nn and Ae == k * Nn and eA == k * Nn and Ae * eA == AeA * eAe
chk('std', okm, 'numpy, M_N(R) for N = 2..5 with the diagonal idempotents of k ones (k < N): dim eAe = k^2, AeA = A (rank N^2), dim Ae = dim eA = kN, and dim Ae * dim eA = dim AeA * dim eAe, the dimension count of Ae (x)_(eAe) eA = AeA')
tline('part 4')

# =============================================================================================================== 5. representation numbers of the Eisenstein norm
head('5. CAND-105: r(N) = 6 sum_{d | N} chi(d), N <= 10^4')
NM = 10 ** 4; BOX = 116
cnt = [0] * (NM + 1)
for x in range(-BOX, BOX + 1):
    for y in range(-BOX, BOX + 1):
        v = x * x - x * y + y * y
        if v <= NM: cnt[v] += 1
edge_min = min(x * x - x * y + y * y for x in range(-BOX, BOX + 1) for y in range(-BOX, BOX + 1) if max(abs(x), abs(y)) == BOX)
chi3 = lambda d: 0 if d % 3 == 0 else (1 if d % 3 == 1 else -1)
chi4 = lambda d: 0 if d % 2 == 0 else (1 if d % 4 == 1 else -1)
chi = chi4 if fault('CHI4') else chi3
fac = 1 if fault('NOSIX') else 6
dsum = [0] * (NM + 1)
for d in range(1, NM + 1):
    c = chi(d)
    if c:
        for m in range(d, NM + 1, d): dsum[m] += c
bad = [N for N in range(1, NM + 1) if cnt[N] != fac * dsum[N]]
chk('bit', cnt[0] == 1 and not bad and edge_min > NM,
    'the number of (x, y) in the box |x|, |y| <= %d (every point of norm <= 10^4 lies inside: the boundary has norm >= %d) with x^2 - xy + y^2 = N equals %d * sum_{d | N} chi(d) for all N = 1..10^4 (%d differences)' % (BOX, edge_min, fac, len(bad)))
z2 = [N for N in range(2, NM + 1, 3)]
chk('bit', all(cnt[N] == 0 for N in z2) and cnt[:13] == [1, 6, 0, 6, 6, 0, 0, 12, 0, 6, 0, 0, 6] and all(cnt[N] % 6 == 0 for N in range(1, NM + 1)),
    'r(N) = 0 for all %d values N = 2 mod 3 up to 10^4; the theta series begins %s (1 + 6q + 6q^3 + 6q^4 + 12q^7 + 6q^9 + 6q^12); every r(N) is a multiple of 6 (the six units)' % (len(z2), cnt[:13]))
th = [1] + [6 * sum(chi3(d) for d in range(1, N + 1) if N % d == 0) for N in range(1, 31)]
chk('bit==std', th == cnt[:31], 'baez T1a again: the counts for N = 0..30 equal the divisor-sum formula (the first eight: 1, 6, 0, 6, 6, 0, 0, 12)')
chk('ctl', [N for N in range(1, 40) if cnt[N] != 6 * sum(chi4(d) for d in range(1, N + 1) if N % d == 0)] != [] and [N for N in range(1, 40) if cnt[N] != sum(chi3(d) for d in range(1, N + 1) if N % d == 0)] != [],
    'a character with the wrong period (chi_-4: 0, 1, 0, -1) or the divisor sum without the factor 6 disagrees with the count already below N = 40')
tline('part 5')

# =============================================================================================================== 6. Dedekind numbers
def upsets_bruteforce(k):
    N = 1 << k; near = [sum(1 << b for b in range(N) if (a & b) == a) for a in range(N)]; out = []
    for X in range(1 << N):
        if all(not (near[a] & ~X) for a in bits(X)): out.append(X)
    return out
def count_antichains(k):
    """[bit] antichains of B_k (the empty antichain and {bottom} included) by backtracking over the labels in increasing order"""
    N = 1 << k; comp = [sum(1 << b for b in range(N) if (a & b) == a or (a & b) == b) for a in range(N)]
    def rec(allowed):
        tot = 1
        while allowed:
            low = allowed & -allowed; a = low.bit_length() - 1; allowed ^= low
            tot += rec(allowed & ~comp[a])
        return tot
    return rec((1 << N) - 1)
DED = [2, 3, 6, 20, 168, 7581, 7828354]

head('6. CAND-106: the Dedekind numbers, k <= 6')
ups = [len(upsets_bruteforce(k)) for k in range(0, 5)]
U4 = upsets_bruteforce(4); M5 = sum(1 for U in U4 for V in U4 if (U & ~V) == 0)
chk('bit', ups == DED[:5] and M5 == DED[5], 'up-sets of B_k by testing every subset of the labels for up-closure: %s for k = 0..4 (bd.mjc.31 again); pairs U subset V of up-sets of B_4: %d for k = 5' % (ups, M5))
anti = [count_antichains(k) for k in range(0, 6 if FAULT else 7)]
conv = (lambda m: m - 2) if fault('DEDM2') else (lambda m: m)
chk('bit', [conv(m) for m in anti] == DED[:len(anti)] and anti[:5] == ups,
    'antichains of B_k (the empty antichain and {bottom} included) by backtracking over the 2^k labels with comparability masks: %s for k = 0..%d (k = 6: %s antichains%s); equal to the up-set counts for k <= 4' % (anti, len(anti) - 1, DED[6], '' if not FAULT else ', skipped in a fault run'))
# [std] M(k+1) = number of pairs f <= g of monotone functions of k variables
mons = [[0, 1]]                                                                    # k = 0: the two constants, as 1-bit integers
for k in range(0, 5):
    prev = mons[-1]; w = 1 << k
    mons.append([f | (g << w) for f in prev for g in prev if (f & ~g) == 0])
cnts = [len(m) for m in mons]
chk('std', cnts == DED[:6], 'monotone Boolean functions of k variables as 2^k-bit integers, built by the recursion h = f + 2^(2^k) g with f <= g (f & ~g = 0) over the functions of k variables: %s for k = 0..5' % cnts)
arr = np.array(mons[5], dtype=np.int64)
strict = 0; total = 0
for i in range(0, len(arr), 400):
    blk = arr[i:i + 400]
    le = (blk[:, None] & ~arr[None, :]) == 0
    total += int(le.sum()); strict += int((le & (blk[:, None] != arr[None, :])).sum())
want6 = strict if fault('DEDSTRICT') else total
chk('std', want6 == DED[6], 'k = 6: the number of pairs f <= g among the %d monotone functions of 5 variables (numpy, %d pairs tested) is %d' % (len(arr), len(arr) ** 2, want6))
chk('ctl', strict != DED[6] and [m - 2 for m in DED] != DED and total - strict == len(arr),
    'strict pairs f < g number %d, not M(6): the pairs with f = g are the %d functions; the count without the empty and the full up-set is M(k) - 2 = %s, another list. (Down-sets counted as up-sets give the same numbers: a symmetry, not a control.)' % (strict, len(arr), [m - 2 for m in DED]))
if not FAULT:
    chk('bit==std', anti[6] == total == DED[6], 'k = 6: the backtracking count of antichains %d equals the pair count %d equals M(6) = 7828354' % (anti[6], total))
tline('part 6')
finish(STEP)
