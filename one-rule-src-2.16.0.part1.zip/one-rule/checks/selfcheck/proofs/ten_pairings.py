#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""ten_pairings.py: the pairings of the half-spinors in the split and compact cells of ten generators, Furey and Hughes's three copies
of H (x) O on the roadmap's labels, and the complexification of the cells and of the chains with D = H (round 15, proofs pass 12a;
docs/round15/PLAN.md section 3, docs/round15/pass12a/BEFORE.md).
     python3 ten_pairings.py [--fault SCALAR|FORM|PSIDIM|NOCENTRAL|NOCRULE|QREAL]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators of
square +1 first (core_check.sig); the type table core_check.TYPE by the clock p - q mod 8.  Cl(1,9) as fibre_base.py builds it (Gamma =
e0..e9); the compact Cl(0,10) on the same bits (omega = e0..e9, omega^2 = -1); the split Cl(5,5) with GEN-015's interleaved pairs (bit 2a
= e_a, square +1; bit 2a+1 = f_a, square -1) and its Fock states a*_S Pi (FUR-022).  The roadmap's cell is furey_roadmap.py's Cl(1,10)
(FUR-028): bit 0 = e0 (square +1), bits 1..10 the ten Gamma's of Roadmap I (arXiv:2312.12377, eq. 25), the central i the label 2047; her
five pairs in the bit order (8,7), (10,9), (5,4), (3,1), (6,2) (bits 0, 1 weak, 2, 3, 4 colour), her vacuum and the 32 states s_S (FUR-029).
A complex scalar is a blade of a larger cell (the label 2047; the extra generator of the ungraded product Cl(p,q) (x) Cl(0,1)) or pairs of
exact integer vectors, never a Python complex number on a [bit] line.  Furey and Hughes (arXiv:2409.17948) enter as docs/round13/SOURCES.md
(g) records them: eqs. 21-22 (the triality actions), 26 (su(2)_L), 27 (u(1)_Y), 30-31 (her basis), 32 (its leptonic beginning), 34-35 (the
irreps of V), 36 (V = Psi+ Psi-^dag); the Roadmap's eqs. 22, 25 and Furey 2018's eq. 16 give the dictionary of her L's and R's.
tp.PAIR (a) the products psi chi~ of the half-spinors by grade (chiral_spinors.py's method, ATY-029, as spinor_pairings.py ran it for
        Cl(1,9)) in Cl(5,5) (S+- = ((1 +- Gamma)/2) S) and Cl(0,10) (S_s = {omega psi = s psi u}, u a unit of the quaternionic commutant, of
        either reversion sign), Cl(1,9) recomputed beside them; the invariant bilinear forms (ATY-028's method) on the Fock labels of
        Cl(5,5) and on the 64 of Cl(0,10), their symmetry and their behaviour under J.  [std] complex Pauli words, C+- with C g C^-1 = +-g^T,
        the bilinears by grade on the Weyl blocks, the invariant bilinear and Hermitian forms by null spaces.  [ctl] SCALAR, FORM.
tp.FH   (b) on the labels of Cl(1,10): her left and right multiplications L_e7, R_e7, L_eps, R_eps as label multivectors; the actions of
        eqs. 26-27 for the three copies, their eigenvalues on the 32 states against CAND-019's bits; the two generations of Psi+; the real
        dimensions of the pieces of V.  [std] numpy on C (x) H (x) O = C^32: the same operators, her basis of eqs. 30-31 against the states,
        the product of H (x) O and the relation of eqs. 21-22, the derivations of O fixing e7.  [ctl] PSIDIM.
tp.CPX  (c) Cl(p,q) (x) C for the 45 cells with n <= 8 on the labels with the central i (centre, squares, count, a minimal left ideal and
        its commutant), against the clock table with the rules for R, C, H; the 15 chains of GEN-019 with D = H complexified (types,
        minimal idempotents, multiplicities) and mapped by e_j -> i e'_j onto the complexified chains of a clock-0 or clock-1 cell.  [std]
        complex Pauli matrices for the 45 cells.  [ctl] NOCENTRAL, NOCRULE.
tp.INT  the real H chain itself: B_k = phi(C_k) Q with Q = H in the next block is a finite product of real matrix algebras, C_k in B_k in
        C_(k+1), computed for k = 0, 1 (up to 20 generators).  [std] the real span of B_0's words as matrices.  [ctl] QREAL.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   SCALAR a scalar pairing asserted on one half where there is none; FORM the wrong real form (Cl(5,5)'s eps) for the compact cell; PSIDIM
   one generation of Psi+ taken for the two; NOCENTRAL the complexification without the central i (the extra unit anticommuting with the
   generators); NOCRULE the type table without the C rule (M_m(C) (x)_R C taken as M_m(C)); QREAL Q of real type (M2(R)) in the interleaving.
Not computed here (stated, not checked): the C*-completions and the classifications of the completed limits (cited from SOURCES.md); the
full lists of Furey-Hughes's eqs. 32-33, their factorization 36-39 and their third generation beyond the dimensions recorded, dynamics and
symmetry breaking; the statistics a mass term needs, a Lagrangian; anything about nature's generations, real form, product or signature
(inputs, INP-011).
Command: python3 -I -B selfcheck/proofs/ten_pairings.py from checks/ (or from this folder); standard library and numpy."""
import os, sys, time, random
from fractions import Fraction as Fr
from math import isqrt, gcd, comb
from collections import Counter
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps

# ------------------------------------------------------------------------------------------------ check lines (from spinor_pairings.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish():
    print('\n  tags: %s; %.0f s' % (', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), time.time() - T0))
    print('ten_pairings: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('SCALAR', 'FORM', 'PSIDIM', 'NOCENTRAL', 'NOCRULE', 'QREAL')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(202610172); NPR = np.random.default_rng(202610172)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
pc = lambda x: bin(x).count('1')
def rsign(a): return -1 if (pc(a) * (pc(a) - 1) // 2) % 2 else 1             # the reversion's sign on the label a

# ------------------------------------------------------------------------------------------------ the kernel's formula, vectorised; types
# copied from spinor_pairings.py (popv, emask, s_vec, table; from branching_16.py there) and from branching_16.py (type_from_inv, tstr,
# table_type, ltype_eps, clock_type; branching_16.py took them from fibre_base.py and chain_blocks.py)
def popv(x): return np.bitwise_count(np.asarray(x, dtype=np.int64)).astype(np.int64)
def emask(eps):
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    eps = tuple(eps)
    if eps not in _EM: _EM[eps] = emask(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)): par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    return (1 - 2 * (par & 1)) * _EM[eps][A & B]
def table(eps):
    a = np.arange(1 << len(eps), dtype=np.int64); return s_vec(eps, a[:, None], a[None, :]).astype(np.int8)
DD = {'R': 1, 'C': 2, 'H': 4}
def type_from_inv(dim, c, cplx, fs):
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D]); m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
def table_type(S, gens):
    central = np.ones(S.shape[0], dtype=bool)
    for g in gens: central &= (S[:, g] == S[g, :])
    Z = np.nonzero(central)[0]; sq = S[Z, Z]
    cplx = bool(np.any(sq == -1)); c = len(Z) // 2 if cplx else len(Z)
    return type_from_inv(S.shape[0], c, cplx, int(np.trace(S.astype(np.int64))))
def ltype_eps(eps):
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); d = s_vec(eps, a, a); cen = np.ones(1 << n, dtype=bool)
    for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
    Z = np.flatnonzero(cen); cplx = bool(np.any(d[Z] == -1))
    return type_from_inv(1 << n, len(Z) // 2 if cplx else len(Z), cplx, int(d.sum()))
def clock_type(p, q):
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2); assert r == 0 and m * m == m2
    return (D, m, c)

# ------------------------------------------------------------------------------------------------ labels as an algebra, ideals, commutants
# copied from spinor_pairings.py (Lab, lab_graded, comm_labels with `must` and `keep`, span_tau, Ideal, centraliser_div; from branching_16.py
# and fibre_base.py there)
class Lab:
    def __init__(self, s, N): self.s, self.N, self.M = s, N, 1 << N
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                k = a ^ b; v = out.get(k, 0) + self.s(a, b) * ca * cb
                if v: out[k] = v
                else: out.pop(k, None)
        return out
def lab_graded(eps): return Lab(BR(eps).s, len(eps))
def lab_table(T): TL = T.tolist(); return Lab(lambda a, b: TL[a][b], int(T.shape[0]).bit_length() - 1)   # new here: a Lab read from a table
def comm_labels(L, first=(), even=False, tries=60, must=(), keep=None):
    best = None
    for k in range(tries):
        order = list(range(1, L.M)); RNG.shuffle(order); G = list(first); span = {0}
        for g in G: span |= {x ^ g for x in span}
        for u in order:
            if u in span or L.sq(u) != 1 or (even and pc(u) % 2) or not all(L.commute(u, g) for g in G): continue
            if not all(L.commute(u, w) for w in must) or (keep is not None and not keep(u)): continue
            G.append(u); span |= {x ^ u for x in span}
        if best is None or len(G) > len(best): best = G
    return best
def span_tau(L, G):
    tau = {0: 1}
    for g in G:
        for h, t in list(tau.items()): tau[h ^ g] = L.s(h, g) * t
    return tau
class Ideal:
    """the left ideal A f, f = prod (1 + e_g)/2 over commuting labels G of square +1, on the basis e_r f: left and right multiplications by
    labels are signed permutation matrices"""
    def __init__(self, L, G):
        self.L, self.G = L, list(G); self.tau = span_tau(L, G); H = list(self.tau)
        self.rep = {}; self.reps = []
        for a in range(L.M):
            if a not in self.rep:
                self.reps.append(a)
                for h in H: self.rep[a ^ h] = (a, h)
        self.m = len(self.reps); self.idx = {r: i for i, r in enumerate(self.reps)}
    def act(self, b):
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[b ^ r]; R[self.idx[r2], self.idx[r]] = self.L.s(b, r) * self.L.s(r2, h) * self.tau[h]
        return R
    def ract(self, c):
        assert all(self.L.commute(c, g) for g in self.G)
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[r ^ c]; R[self.idx[r2], self.idx[r]] = self.L.s(r, c) * self.L.s(r2, h) * self.tau[h]
        return R
def centraliser_div(L, G):
    H = set(span_tau(L, G)); cen = [a for a in range(L.M) if all(L.commute(a, g) for g in G)]
    reps = sorted({min(a ^ h for h in H) for a in cen}); sq = [L.sq(a) for a in reps if a]
    d = len(reps); ok = all(v == -1 for v in sq) and all(not L.commute(a, b) for a in reps if a for b in reps if b and b != a)
    return d, ({1: 'R', 2: 'C', 4: 'H'}.get(d) if ok else None), [a for a in reps if a]
def rev(x): return {k: v * rsign(k) for k, v in x.items()}

# copied from branching_16.py (commutant_basis, from solid_cube.py there); one addition here: `eps`, a sign per generator, so that the same
# union-find gives the solutions of X rho_i = eps_i rho_i X (the invariant bilinear forms, rho(B)^T = sq(B) rho(B) for a signed permutation)
def commutant_basis(rho, m, eps=None):
    perms = []
    for R in rho:
        pi = [0] * m; sg = [0] * m
        for c in range(m):
            nz = np.nonzero(R[:, c])[0]; assert len(nz) == 1
            pi[c] = int(nz[0]); sg[c] = int(R[nz[0], c])
        perms.append((pi, sg))
    eps = [1] * len(rho) if eps is None else list(eps)
    parent = list(range(m * m)); psign = [1] * (m * m)
    def find(x):
        path = []
        while parent[x] != x: path.append(x); x = parent[x]
        s = 1
        for node in reversed(path):
            s *= psign[node]; psign[node] = s; parent[node] = x
        return x
    def sgn_of(x):
        r = find(x); return r, (1 if x == r else psign[x])
    eqs = []
    for (pi, sg), e in zip(perms, eps):
        for b in range(m):
            for c in range(m): eqs.append((pi[b] * m + pi[c], b * m + c, e * sg[b] * sg[c]))
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv: parent[ru] = rv; psign[ru] = s * sv * su
    bad = set(); comp = {}
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv or su != s * sv: bad.add(rv)
    for x in range(m * m):
        r, sx = sgn_of(x); comp.setdefault(r, []).append((x, sx))
    basis = []
    for r in sorted(comp):
        if r in bad: continue
        B = np.zeros((m, m), dtype=np.int64)
        for x, sx in comp[r]: B[x // m, x % m] = sx
        basis.append(B)
    return basis
# copied from spinor_pairings.py (nullspace_frac from chiral_spinors.py, rank_frac, madd, rank_sparse; rank_modp, new there)
def nullspace_frac(rows, ncol):
    rows = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p_ = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if p_ is None: continue
        rows[rk], rows[p_] = rows[p_], rows[rk]; pv = rows[rk][c]; rows[rk] = [x / pv for x in rows[rk]]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncol) if c not in piv]; basis = []
    for f in free:
        v = [Fr(0)] * ncol; v[f] = Fr(1)
        for i, c in enumerate(piv): v[c] = -rows[i][f]
        basis.append(v)
    return basis
def rank_frac(M):
    rows = [[Fr(x) for x in r] for r in (M.tolist() if hasattr(M, 'tolist') else M)]
    return len(rows[0]) - len(nullspace_frac(rows, len(rows[0]))) if rows else 0
def madd(*terms):
    out = {}
    for c_, x in terms:
        for k_, v in x.items():
            w = out.get(k_, 0) + c_ * v
            if w: out[k_] = w
            else: out.pop(k_, None)
    return out
def rank_sparse(rows):
    """the exact rank of an integer matrix given as sparse rows {column: int}: a row echelon form kept in integers"""
    piv = {}
    for r in rows:
        r = {c: v for c, v in r.items() if v}
        while r:
            c = min(r); p = piv.get(c)
            if p is None:
                g = 0
                for v in r.values(): g = gcd(g, v)
                if r[c] < 0: g = -g
                piv[c] = {k: v // g for k, v in r.items()}; break
            a, b = r[c], p[c]; g = gcd(a, b); a //= g; b //= g
            new = {k: b * v for k, v in r.items()}
            for k, v in p.items():
                w = new.get(k, 0) - a * v
                if w: new[k] = w
                else: new.pop(k, None)
            g = 0
            for v in new.values(): g = gcd(g, v)
            r = {k: v // g for k, v in new.items()} if g > 1 else new
    return len(piv)
PRIME = 2147483647
def rank_modp(M, p=PRIME):
    """the rank of an integer matrix modulo the prime p; it is at most the rank over Q, so a rank modulo p equal to an upper bound proved
    exactly (the dimension of a space the rows are shown to lie in, or their number) is the rank over Q"""
    A = np.array([[int(x) % p for x in row] for row in (M.tolist() if hasattr(M, 'tolist') else M)], dtype=np.int64)
    if A.size == 0: return 0
    r = 0
    for c in range(A.shape[1]):
        if r == A.shape[0]: break
        nz = np.flatnonzero(A[r:, c])
        if not len(nz): continue
        pv = r + int(nz[0])
        if pv != r: A[[r, pv]] = A[[pv, r]]
        A[r] = (A[r] * pow(int(A[r, c]), p - 2, p)) % p
        col = A[:, c].copy(); col[r] = 0; nzr = np.flatnonzero(col)
        if len(nzr): A[nzr] = (A[nzr] - (np.outer(col[nzr], A[r]) % p)) % p
        r += 1
    return r

# ------------------------------------------------------------------------------------------------ dense multivectors (from spinor_pairings.py)
def arr(d): k = np.array(sorted(d), dtype=np.int64); return k, np.array([int(d[x]) for x in k.tolist()], dtype=np.int64)
def mul_arr(T, x, y):
    """the product of two integer multivectors (label array, coefficient array) as a dense vector, with the sign table T (sp.PAIR's mul_arr
    with the table an argument)"""
    (la, ca), (lb, cb) = x, y; out = np.zeros(T.shape[0], dtype=np.int64)
    np.add.at(out, (la[:, None] ^ lb[None, :]).ravel(), (T[la[:, None], lb[None, :]].astype(np.int64) * ca[:, None] * cb[None, :]).ravel())
    return out

# ------------------------------------------------------------------------------------------------ the standard route: matrices, no label
# copied from spinor_pairings.py (kron_all, prodm, the Pauli words HM, cwords; from branching_16.py and fibre_base.py there)
def kron_all(ms):
    M = np.ones((1, 1))
    for m_ in ms: M = np.kron(M, m_)
    return M
def prodm(ms):
    P_ = np.eye(ms[0].shape[0], dtype=ms[0].dtype)
    for m_ in ms: P_ = P_ @ m_
    return P_
PX = np.array([[0, 1], [1, 0]], dtype=complex); PY = np.array([[0, -1j], [1j, 0]]); PZ = np.diag([1, -1]).astype(complex); P2c = np.eye(2, dtype=complex)
def herm_words(h):                                                         # 2h anticommuting Hermitian matrices of size 2^h (HM for h = 5)
    return [kron_all([PZ] * k + [P_] + [P2c] * (h - 1 - k)) for k in range(h) for P_ in (PX, PY)]
HM = herm_words(5)
def cwords(G):
    n = len(G); W = [np.eye(G[0].shape[0], dtype=complex)]
    for a in range(1, 1 << n):
        top = a.bit_length() - 1; W.append(W[a ^ (1 << top)] @ G[top])
    return W

# ------------------------------------------------------------------------------------------------ multivectors on the labels (exact)
# copied from furey_roadmap.py (Cell, add, scal, lin, eq, blade; from furey_cl6.py there)
class Cell:
    """the labels of a cell: e_a e_b = s(a,b) e_(a xor b), s read as the table of s_vec; multivectors are dicts label -> Fraction"""
    def __init__(self, eps):
        self.eps = tuple(eps); self.n = len(eps); self.M = 1 << self.n; self.T = table(self.eps); self.S = self.T.tolist()
    def mul(self, x, y):
        S = self.S; out = {}
        for a, ca in x.items():
            Sa = S[a]
            for b, cb in y.items():
                k = a ^ b; v = out.get(k, 0) + Sa[b] * ca * cb
                if v: out[k] = v
                else: out.pop(k, None)
        return out
    def prod(self, *xs):
        out = {0: Fr(1)}
        for x in xs: out = self.mul(out, x)
        return out
    def comm(self, x, y): return add(self.mul(x, y), self.mul(y, x), -1)
    def sq(self, a): return self.S[a][a]
    def commute(self, a, b): return self.S[a][b] == self.S[b][a]
def add(x, y, c=1):
    out = dict(x)
    for k, v in y.items():
        w = out.get(k, 0) + c * v
        if w: out[k] = w
        else: out.pop(k, None)
    return out
def scal(x, c): return {k: c * v for k, v in x.items() if c * v != 0}
def lin(*terms):
    out = {}
    for c, x in terms: out = add(out, x, c)
    return out
def eq(x, y): return add(x, y, -1) == {}
def blade(a, c=1): return {a: Fr(c)}
ONE = blade(0)

# ================================================================================================ tp.PAIR (a): the pairings in ten generators
head('tp.PAIR (a): the products psi chi~ and the invariant forms of the half-spinors in Cl(5,5) and Cl(0,10), against Cl(1,9) (FUR-035)')
t = time.time()
E19, E010, E55 = sig(1, 9), sig(0, 10), (1, -1) * 5
TOP = (1 << 10) - 1                                                        # Gamma in Cl(1,9) and Cl(5,5); omega in Cl(0,10)
T19, T010, T55 = table(E19), table(E010), table(E55)
L19, L010, L55 = lab_table(T19), lab_table(T010), lab_table(T55)
aa = np.arange(1 << 10, dtype=np.int64); gr = popv(aa); ODD = (gr % 2) == 1
BIV = [(1 << i) | (1 << j) for i in range(10) for j in range(i + 1, 10)]
def granks(P): return {k: rank_modp(P[:, gr == k]) for k in range(11) if np.any(P[:, gr == k])}
def gamma_products(T, L):
    """FUR-035's construction (spinor_pairings.py, sp.PAIR): f from five commuting labels of square +1 and reversion sign +1 (f~ = f), the
    halves (1 +- Gamma) e_r f, and the products psi chi~ of the bases of S_s and S_t as dense vectors (times 64^2)"""
    G = comm_labels(L, tries=40, keep=lambda u: rsign(u) == 1); I_ = Ideal(L, G); F = {0: 1}
    for g in G: F = L.mul(F, {0: 1, g: 1})
    okf = len(G) == 5 and I_.m == 32 and rev(F) == F and L.mul(F, F) == {k: 32 * v for k, v in F.items()}
    partner = {r: I_.rep[TOP ^ r][0] for r in I_.reps}; R16 = [r for r in I_.reps if r < partner[r]]
    HV = {s: [L.mul({0: 1, TOP: s}, L.mul({r: 1}, F)) for r in R16] for s in (1, -1)}
    PR = {(s, t_): np.array([mul_arr(T, arr(x), arr(rev(y))) for x in HV[s] for y in HV[t_]]) for s in (1, -1) for t_ in (1, -1)}
    sT = T[TOP, :].astype(np.int64); sR = T[:, TOP].astype(np.int64); inside = True
    for (s, t_), P in PR.items():
        GM = np.zeros_like(P); GM[:, TOP ^ aa] = sT[None, :] * P; MG = np.zeros_like(P); MG[:, aa ^ TOP] = sR[None, :] * P
        inside &= np.array_equal(GM, s * P) and np.array_equal(MG, -t_ * P)                  # Gamma M = s M, M Gamma = -t M
    return okf and inside, PR
WSAME = {1: 10, 3: 120, 5: 126, 7: 120, 9: 10}; WOPP = {0: 1, 2: 45, 4: 210, 6: 210, 8: 45, 10: 1}
ok55p, PR55 = gamma_products(T55, L55); ok19p, PR19 = gamma_products(T19, L19)
GR55 = {k: granks(P) for k, P in PR55.items()}; GR19 = {k: granks(P) for k, P in PR19.items()}
def gpattern(PR, GR):
    same = all(GR[(s, s)] == WSAME and rank_modp(PR[(s, s)][:, np.isin(gr, (1, 3, 5))]) == 256 for s in (1, -1))
    opp = all(GR[(s, -s)] == WOPP and rank_modp(PR[(s, -s)][:, np.isin(gr, (0, 2, 4))]) == 256 for s in (1, -1))
    return same, opp, [int(np.any(PR[(s, s)][:, 0])) for s in (1, -1)], [int(np.any(PR[(s, -s)][:, 0])) for s in (1, -1)]
PAT55, PAT19 = gpattern(PR55, GR55), gpattern(PR19, GR19)
SCAL_WANT = [1, 1] if FAULT == 'SCALAR' else [0, 0]                       # the scalar on S+ x S+ and S- x S- (asserted under SCALAR)
chk('bit', ok55p and ok19p and PAT55[:2] == PAT19[:2] == (True, True) and PAT55[2] == SCAL_WANT and PAT19[2] == [0, 0] and PAT55[3] == PAT19[3] == [1, 1] and GR55 == GR19,
    'tp.PAIR: Cl(5,5) by FUR-035\'s construction (f from five commuting labels of square +1 and reversion sign +1, f~ = f; S+- = ((1 +- Gamma)/2) S, 16 each; Gamma^2 = +1 and Gamma~ = -Gamma, so every product psi chi~ lies in ((1 + s Gamma)/2) Cl ((1 - t Gamma)/2), exact): for s = t the products are odd with grade ranks %s, the projection onto {1, 3, 5} of rank 256, and their scalar part is %s; for s != t even with %s, the projection onto {0, 2, 4} of rank 256, the scalar non-zero; Cl(1,9), recomputed by the same code, gives the same ranks (FUR-035): the split cell repeats the Lorentz cell%s (ranks modulo 2^31 - 1, each equal to an exact upper bound: the number of products, 126 for the Gamma-eigenspace of grade 5)' % (GR55[(1, 1)], 'non-zero' if any(PAT55[2]) else 'zero on S+ x S+ and on S- x S-', GR55[(1, -1)], ' (a scalar on one half asserted: SCALAR)' if FAULT == 'SCALAR' else ''))
# Cl(5,5) on the Fock labels: the states a*_S Pi of GEN-015 (spinor_pairings.py's PHI); every label is a signed permutation of them
hf = Fr(1, 2); A_ = [{1 << (2 * i): hf, 1 << (2 * i + 1): hf} for i in range(5)]; AD = [{1 << (2 * i): hf, 1 << (2 * i + 1): -hf} for i in range(5)]
PI = {0: Fr(1)}
for i in range(5): PI = L55.mul(PI, L55.mul(A_[i], AD[i]))
PHI = {}
for S in range(32):
    v = dict(PI)
    for i in reversed(range(5)):
        if S >> i & 1: v = L55.mul(AD[i], v)
    PHI[S] = v
def fock_of(lab): return sum(1 << a for a in range(5) if ((lab >> (2 * a)) & 3) in (1, 2))   # the pairs with exactly one bit: S
def act55(b):
    R = np.zeros((32, 32), dtype=np.int64)
    for S in range(32):
        v = L55.mul({b: 1}, PHI[S]); k0 = next(iter(v)); T_ = fock_of(k0); c = v[k0] / PHI[T_][k0]
        assert c in (1, -1) and v == {k: c * w for k, w in PHI[T_].items()}
        R[T_, S] = int(c)
    return R
GAM55 = act55(TOP); okG55 = np.array_equal(GAM55, np.diag([(-1) ** (5 - pc(S)) for S in range(32)]))
okG55 &= all(np.abs(act55(1 << (2 * a + f_))[S ^ (1 << a), S]) == 1 for a in range(5) for f_ in (0, 1) for S in range(32))   # e_a, f_a flip bit a
IDX55 = {s: [S for S in range(32) if GAM55[S, S] == s] for s in (1, -1)}
def srank(Ms): return rank_sparse([{int(c): int(M.ravel()[c]) for c in np.flatnonzero(M.ravel())} for M in Ms])   # exact rank of matrices
def block_dims(forms, IDX):
    """the dimensions of the restrictions of a space of forms (a basis of matrices C, B(psi, chi) = chi^T C psi) to S_s x S_t: exact ranks"""
    return {(s, t_): srank([C[np.ix_(IDX[t_], IDX[s])] for C in forms]) for s in (1, -1) for t_ in (1, -1)}
RHO55 = [act55(B) for B in BIV]; FORMS55 = commutant_basis(RHO55, 32, [-L55.sq(B) for B in BIV])
BD55 = block_dims(FORMS55, IDX55); SYM55 = (srank([C + C.T for C in FORMS55]), srank([C - C.T for C in FORMS55]))
W5E, W5F = sum(1 << (2 * a) for a in range(5)), sum(1 << (2 * a + 1) for a in range(5))   # e0e1e2e3e4 and f0f1f2f3f4
CE, CF = act55(W5E), act55(W5F)
def invariant(C, RHO, L): return all(np.array_equal(C @ R + R.T @ C, 0 * C) for R in RHO)
okW55 = invariant(CE, RHO55, L55) and invariant(CF, RHO55, L55) and np.array_equal(CE, CE.T) and np.array_equal(CF, -CF.T) and L55.sq(W5E) == 1 and L55.sq(W5F) == -1
okW55 &= not CE[np.ix_(IDX55[1], IDX55[1])].any() and not CE[np.ix_(IDX55[-1], IDX55[-1])].any() and rank_frac(CE[np.ix_(IDX55[-1], IDX55[1])]) == 16
IA19 = Ideal(L19, comm_labels(L19, first=(TOP,), even=True, tries=12)); G19d = np.diag(IA19.act(TOP)); IDX19 = {s: [i for i in range(32) if G19d[i] == s] for s in (1, -1)}
FORMS19 = commutant_basis([IA19.act(B) for B in BIV], 32, [-L19.sq(B) for B in BIV]); BD19 = block_dims(FORMS19, IDX19)
SYM19 = (srank([C + C.T for C in FORMS19]), srank([C - C.T for C in FORMS19]))
WBD = {(1, 1): 0, (1, -1): 1, (-1, 1): 1, (-1, -1): 0}
chk('bit', okG55 and len(FORMS55) == 2 and BD55 == WBD and SYM55 == (1, 1) and okW55 and len(FORMS19) == 2 and BD19 == WBD and SYM19 == (1, 1),
    'tp.PAIR: Cl(5,5) on its 32 Fock states a*_S Pi (GEN-015): every label acts as a signed permutation (e_a and f_a flip the bit a), Gamma = e0f0..e4f4 as (-1)^(5 - |S|); the bilinear forms invariant under the 45 bivectors (C rho(B) + rho(B)^T C = 0, rho(B)^T = sq(B) rho(B): C commutes with the 20 rotations and anticommutes with the 25 boosts; a sign-consistent union-find, exact) form a space of dimension %d on the 32, with %s on S_s x S_t (s, t = +-1): S- is the dual of S+ and neither half carries an invariant scalar; %d symmetric and %d antisymmetric: rho(e0e1e2e3e4) (square +1, symmetric) and rho(f0f1f2f3f4) (square -1, antisymmetric), both odd, zero on each half and of rank 16 between them; fibre_base\'s ideal of Cl(1,9) gives the same (%d forms, %s, %s symmetric/antisymmetric)' % (len(FORMS55), {'%+d%+d' % k: v for k, v in BD55.items()}, SYM55[0], SYM55[1], len(FORMS19), {'%+d%+d' % k: v for k, v in BD19.items()}, SYM19))
# Cl(0,10): an ideal with f~ = f (four commuting labels of square +1 and reversion sign +1: grades 4 and 8), the quaternionic commutant
G10 = comm_labels(L010, tries=40, keep=lambda u: rsign(u) == 1); I10 = Ideal(L010, G10); F10 = {0: 1}
for g in G10: F10 = L010.mul(F10, {0: 1, g: 1})                           # 16 f
d10, D10, U10 = centraliser_div(L010, G10)
if FAULT == 'FORM':                                                        # the wrong real form: Cl(5,5)'s eps where the compact cell is meant
    LF = L55; GF = comm_labels(LF, tries=40, keep=lambda u: rsign(u) == 1); dF, DF, UF = centraliser_div(LF, GF); mF = Ideal(LF, GF).m
else: LF, GF, dF, DF, UF, mF = L010, G10, d10, D10, U10, I10.m
okCls = LF.sq(TOP) == -1 and DF == 'H' and len(GF) == 4 and mF == 64 and sorted(rsign(u) for u in UF) == [-1, 1, 1] and all(pc(g) % 4 == 0 for g in GF)
okCls &= rev(F10) == F10 and L010.mul(F10, F10) == {k: 16 * v for k, v in F10.items()}
UP = next(u for u in U10 if rsign(u) == 1); UM = next(u for u in U10 if rsign(u) == -1); UK = next(u for u in U10 if rsign(u) == 1 and u != UP)
chk('bit', okCls, 'tp.PAIR: Cl(0,10)%s: omega = e0..e9 has square %d, so no real half exists; f from four commuting labels of square +1 and reversion sign +1 (grades %s: the only grades with both in Cl(0,10) are 0 mod 4), f~ = f, gives the module of dimension %d with commutant %s (dimension %d): its three units u (labels commuting with f, square -1, pairwise anticommuting; grades %s) have reversion signs %s: the reversion induces on H an anti-involution that fixes two units and negates their product; a half exists only with a complex structure J of the commutant, here J = right multiplication by a unit u: S_s = {omega psi = s psi u}' % (' (FORM: Cl(5,5)\'s eps taken)' if FAULT == 'FORM' else '', LF.sq(TOP), sorted(pc(g) for g in GF), mF, DF, dF, [pc(u) for u in UF], [rsign(u) for u in UF]))
Lw = I10.act(TOP); I64 = np.eye(64, dtype=np.int64); MV10 = {}
def ideal_mv(v):
    """the multivector sum_r v_r e_r (16 f) of a coordinate vector on the basis e_r f of the ideal"""
    key = tuple(v.tolist())
    if key not in MV10:
        out = {}
        for i, r in enumerate(I10.reps):
            if v[i]: out = madd((1, out), (int(v[i]), L010.mul({r: 1}, F10)))
        MV10[key] = out
    return MV10[key]
def halves(u):
    """J = right multiplication by the unit u: X = L_omega R_u is a symmetric signed-permutation involution; 2 P_s = 1 - s X; a basis of S_s"""
    Ru = I10.ract(u); X = Lw @ Ru
    okX = np.array_equal(X @ X, I64) and np.array_equal(X, X.T) and np.array_equal(Lw @ Ru, Ru @ Lw)
    P2 = {s: I64 - s * X for s in (1, -1)}; B = {}
    for s in (1, -1):
        cols, seen = [], set()
        for j in range(64):
            v = P2[s][:, j]; key = tuple(np.flatnonzero(v).tolist())
            if key and key not in seen: seen.add(key); cols.append(v)
        B[s] = cols
    okX &= all(rank_frac(np.array(B[s])) == 32 for s in (1, -1))
    return okX, Ru, P2, B
def cproducts(B, s, t_):
    xs = [arr(ideal_mv(v)) for v in B[s]]; ys = [arr(rev(ideal_mv(v))) for v in B[t_]]
    return np.array([mul_arr(T010, x, y) for x in xs for y in ys])
def rk_bound(M, bound):                                                    # a rank modulo p on half the rows first; the bound is exact
    r = rank_modp(M[: M.shape[0] // 2]); return r if r == bound else rank_modp(M)
def canal(P):
    par = 'odd' if not P[:, ~ODD].any() else ('even' if not P[:, ODD].any() else 'mixed')
    cols = ODD if par == 'odd' else ~ODD
    return par, rk_bound(P[:, cols], 512), {k: rk_bound(P[:, gr == k], comb(10, k)) for k in range(11) if P[:, gr == k].any()}, bool(P[:, 0].any())
CJ = {}
for nmJ, u, k_ in (('J+', UP, UK), ('J-', UM, UP)):
    okX, Ru, P2, B = halves(u); Rk = I10.ract(k_)
    okK = np.array_equal(Rk @ P2[1], P2[-1] @ Rk) and len(B[1]) == len(B[-1]) == 32                    # R_k maps S+ onto S-
    okK &= all(np.array_equal(Ru @ v, s * Lw @ v) for s in (1, -1) for v in B[s])                       # psi u = s omega psi on S_s
    Ppp = cproducts(B, 1, 1); A_pp, A_pm = canal(Ppp), canal(cproducts(B, 1, -1))
    okK &= np.array_equal(cproducts({1: [Ru @ v for v in B[1]]}, 1, 1), -rsign(u) * Ppp)                # psi u (chi u)~ = -rsign(u) psi chi~
    Pmm, Pmp = cproducts(B, -1, -1), cproducts(B, -1, 1)
    side = (('odd' if not Pmm[:, ~ODD].any() else 'even'), bool(Pmm[:, 0].any()), ('odd' if not Pmp[:, ~ODD].any() else 'even'), bool(Pmp[:, 0].any()))
    CJ[nmJ] = (okX and okK, Ru, P2, A_pp, A_pm, side)
WODD10 = {1: 10, 3: 120, 5: 252, 7: 120, 9: 10}
okJp = CJ['J+'][0] and CJ['J+'][3] == ('odd', 512, WODD10, False) and CJ['J+'][4] == ('even', 512, WOPP, True) and CJ['J+'][5] == ('odd', False, 'even', True)
okJm = CJ['J-'][0] and CJ['J-'][3] == ('even', 512, WOPP, True) and CJ['J-'][4] == ('odd', 512, WODD10, False) and CJ['J-'][5] == ('even', True, 'odd', False)
chk('bit', okJp and okJm, 'tp.PAIR: Cl(0,10), the products psi chi~ of the halves (32 x 32 products of basis vectors, exact; psi u = s omega psi on S_s, so they form a complex subspace for s omega, and psi u (chi u)~ = -rsign(u) psi chi~: J-bilinear for a unit of reversion sign +1, J-sesquilinear for the unit of sign -1): with J from a unit of sign +1 (grade %d), on one half they are %s, of rank %d (all of that part), grade ranks %s, scalar %s; across the halves %s, rank %d, %s, scalar %s; with J from the unit of sign -1 (grade %d) the roles swap: on one half %s, rank %d, %s, scalar %s (an invariant scalar on each half), across %s, rank %d, scalar %s; S- x S- and S- x S+ give the same parity and scalar (R_k, k a unit anticommuting with u, maps S+ onto S-, and psi k (chi k)~ = +-psi chi~); against Cl(1,9) (odd 10, 120, 126 on a half): the parity pattern of J of sign +1, but every odd element, grade 5 of rank 252 (Lambda^5 a complex space of dimension 126 under omega) (ranks modulo 2^31 - 1, each equal to the exact bound: 512 = the dimension of the parity part the products are shown to lie in, C(10, k) for grade k)' % (
    pc(UP), CJ['J+'][3][0], CJ['J+'][3][1], CJ['J+'][3][2], 'non-zero' if CJ['J+'][3][3] else 'zero', CJ['J+'][4][0], CJ['J+'][4][1], CJ['J+'][4][2], 'non-zero' if CJ['J+'][4][3] else 'zero',
    pc(UM), CJ['J-'][3][0], CJ['J-'][3][1], CJ['J-'][3][2], 'non-zero' if CJ['J-'][3][3] else 'zero', CJ['J-'][4][0], CJ['J-'][4][1], 'non-zero' if CJ['J-'][4][3] else 'zero'))
RHO10 = [I10.act(B) for B in BIV]; FORMS10 = commutant_basis(RHO10, 64, [-L010.sq(B) for B in BIV])
SYM10 = (srank([C + C.T for C in FORMS10]), srank([C - C.T for C in FORMS10]))
def jsplit(Ru, P2):
    """the invariant forms restricted to S_s x S_t: all, J-sesquilinear (B(J., J.) = B), J-bilinear (B(J., J.) = -B); symmetric/antisymmetric on S_s"""
    out = {(s, t_): (srank([P2[t_].T @ C @ P2[s] for C in FORMS10]), srank([P2[t_].T @ (C + Ru.T @ C @ Ru) @ P2[s] for C in FORMS10]),
                     srank([P2[t_].T @ (C - Ru.T @ C @ Ru) @ P2[s] for C in FORMS10])) for s in (1, -1) for t_ in (1, -1)}
    sym = {s: (srank([P2[s].T @ (C + C.T) @ P2[s] for C in FORMS10]), srank([P2[s].T @ (C - C.T) @ P2[s] for C in FORMS10]),
               srank([P2[s].T @ (C + C.T) @ P2[s] for C in FORMS10] + [P2[s]])) for s in (1, -1)}
    return out, sym
JS = {nm: jsplit(CJ[nm][1], CJ[nm][2]) for nm in CJ}
WJS = {(1, 1): (2, 2, 0), (-1, -1): (2, 2, 0), (1, -1): (2, 0, 2), (-1, 1): (2, 0, 2)}
if FAULT == 'SCALAR': WJS = {**WJS, (1, 1): (2, 2, 2), (-1, -1): (2, 2, 2)}   # a J-bilinear invariant asserted on one half
RQ8 = [W_ @ R_ for W_ in (I64, Lw) for R_ in [I64] + [I10.ract(u) for u in U10]]                # rho(w) R_q, w in {1, omega}, q in {1, units}
okF10 = len(FORMS10) == 8 and SYM10 == (4, 4) and all(invariant(C, RHO10, L010) for C in RQ8) and srank(RQ8) == 8 and srank(RQ8 + FORMS10) == 8
okF10 &= all(JS[nm][0] == WJS and JS[nm][1] == {1: (1, 1, 1), -1: (1, 1, 1)} for nm in JS)
chk('bit', okF10, 'tp.PAIR: Cl(0,10), the invariant bilinear forms on the 64 (all 45 bivectors square to -1: the commutant of their action, a sign-consistent union-find, exact): dimension %d, %d symmetric and %d antisymmetric (rho(w) R_q, w in {1, omega}, q in {1, u, u\', u u\'}); restricted to S_s x S_t, (all, J-sesquilinear, J-bilinear) = %s for J of sign +1 and %s for J of sign -1: on each half two forms, both J-sesquilinear, one symmetric and one antisymmetric, the symmetric one the restriction of the identity (positive definite: the compact group\'s inner product), and no J-bilinear form%s; between the halves two, both J-bilinear: as complex forms, no invariant on the complex 16 itself and one pairing it with the other half, as in Cl(1,9) and Cl(5,5); what the compact cell has and they lack is the definite form on each half' % (
    len(FORMS10), SYM10[0], SYM10[1], {'%+d%+d' % k: v for k, v in JS['J+'][0].items()}, {'%+d%+d' % k: v for k, v in JS['J-'][0].items()}, ' (one asserted: SCALAR)' if FAULT == 'SCALAR' else ''))
chk('ctl', PAT55[2] == PAT19[2] == [0, 0] and all(JS[nm][0][(s, s)][2] == 0 for nm in JS for s in (1, -1)),
    'tp.PAIR: the scalar parts of the products psi chi~ on S+ x S+ and S- x S- of Cl(5,5) (and of Cl(1,9)) are zero, and on each half of Cl(0,10) the J-bilinear invariant forms are the space 0 for either J: a scalar pairing asserted on one half fails (SCALAR)')
G55f = comm_labels(L55, tries=40, keep=lambda u: rsign(u) == 1); d55, D55, _ = centraliser_div(L55, G55f)
chk('ctl', L55.sq(TOP) == 1 and L19.sq(TOP) == 1 and len(G55f) == 5 and Ideal(L55, G55f).m == 32 and D55 == 'R' and L010.sq(TOP) == -1,
    'tp.PAIR: the split form: in Cl(5,5) (as in Cl(1,9)) Gamma^2 = +1, five commuting labels of square +1 and reversion sign +1 give the 32 with commutant %s: real halves (1 +- Gamma)/2 exist and no J is needed; taken for the compact cell (Cl(0,10), omega^2 = -1, commutant H) it fails (FORM)' % D55)
note('(%.1f s)' % (time.time() - t))
t = time.time()
CL010 = [1j * h for h in HM]; CL55 = [HM[k] if k % 2 == 0 else 1j * HM[k] for k in range(10)]   # Cl(0,10) and Cl(5,5) on C^32 (no label)
SYMK = [k for k in range(10) if np.allclose(HM[k].T, HM[k])]; CPm = prodm([HM[k] for k in SYMK]); CMm = prodm([HM[k] for k in range(10) if k not in SYMK])
def cc_sign(C, G):                                                         # the eps with C g C^-1 = eps g^T for every generator, or None
    Ci = np.linalg.inv(C); e = {e_ for e_ in (1, -1) if all(np.allclose(C @ g @ Ci, e_ * g.T) for g in G)}
    return e.pop() if len(e) == 1 else None
def std_pairings(G, top_herm):
    """the Weyl blocks of the volume element (Hermitian after division by i for Cl(0,10)), the ranks of chi^T C- gamma_A psi by grade on the
    blocks, and the dimensions of the invariant complex bilinear (C X_s + X_t^T C = 0) and Hermitian (X_t^dag H + H X_s = 0) forms"""
    W = cwords(G); ev, V = np.linalg.eigh(top_herm); VB = {1: V[:, ev > 0], -1: V[:, ev < 0]}
    gk = {}
    for s in (1, -1):
        for t_ in (1, -1):
            out = {}
            for k in range(11):
                M = np.array([(VB[t_].T @ CMm @ W[a] @ VB[s]).ravel() for a in range(1024) if pc(a) == k]); sv = np.linalg.svd(M, compute_uv=False)
                r = int((sv > 1e-8 * max(sv.max(), 1.0)).sum())
                if r: out[k] = r
            gk[(s, t_)] = out
    I16 = np.eye(16); bil, her = {}, {}
    for s in (1, -1):
        for t_ in (1, -1):
            rb, rh = [], []
            for a, b in [(a, b) for a in range(10) for b in range(a + 1, 10)]:
                Sg = G[a] @ G[b]; Xs = VB[s].conj().T @ Sg @ VB[s]; Xt = VB[t_].conj().T @ Sg @ VB[t_]
                rb.append(np.kron(I16, Xs.T) + np.kron(Xt.T, I16)); rh.append(np.kron(I16, Xs.T) + np.kron(Xt.conj().T, I16))
            for D_, rows in ((bil, rb), (her, rh)):
                sv = np.linalg.svd(np.vstack(rows), compute_uv=False); D_[(s, t_)] = int((sv < 1e-9 * sv.max()).sum())
    return gk, bil, her
okPw = all(np.allclose(g @ h + h @ g, 2 * e * (i == j) * np.eye(32)) for G, E in ((CL010, E010), (CL55, E55)) for i, (g, e) in enumerate(zip(G, E)) for j, h in enumerate(G) if j >= i)
CCs = {nm: (cc_sign(CPm, G), cc_sign(CMm, G)) for nm, G in (('Cl(0,10)', CL010), ('Cl(5,5)', CL55))}
W010m, G55m = prodm(CL010), prodm(CL55)
STD10 = std_pairings(CL010, (W010m / 1j + (W010m / 1j).conj().T) / 2); STD55 = std_pairings(CL55, (G55m + G55m.conj().T) / 2)
WB, WH10 = {(1, 1): 0, (1, -1): 1, (-1, 1): 1, (-1, -1): 0}, {(1, 1): 1, (1, -1): 0, (-1, 1): 0, (-1, -1): 1}
okStd = okPw and CCs['Cl(0,10)'] == CCs['Cl(5,5)'] and all(None not in v and v[0] != v[1] for v in CCs.values()) and np.allclose(W010m @ W010m, -np.eye(32)) and np.allclose(G55m @ G55m, np.eye(32))
okStd &= all(S[0][(s, s)] == WSAME and S[0][(s, -s)] == WOPP for S in (STD10, STD55) for s in (1, -1)) and STD10[1] == STD55[1] == WB and STD10[2] == WH10 and STD55[2] == WB
chk('std', okStd, 'tp.PAIR: numpy, complex Pauli words (no label): Cl(0,10) (i times the ten Hermitian words) and Cl(5,5) (the words for e_a, i times them for f_a) on C^32 obey their relations; C+ and C- (products of the symmetric, resp. antisymmetric, Hermitian words) give C+ g C+^-1 = %sg^T and C- g C-^-1 = %sg^T in both cells; on the Weyl blocks (omega/i = +-1 in Cl(0,10), Gamma = +-1 in Cl(5,5)) the bilinears chi^T C- gamma_A psi have, by the grade k of A, the complex ranks %s on one block and %s across, in both cells (one complexification); the invariant complex bilinear forms on the blocks have dimensions %s in both cells, the invariant Hermitian forms %s in Cl(0,10) (the identity on each block: the compact group) and %s in Cl(5,5)' % (
    '+' if CCs['Cl(0,10)'][0] == 1 else '-', '+' if CCs['Cl(0,10)'][1] == 1 else '-', STD10[0][(1, 1)], STD10[0][(1, -1)], {'%+d%+d' % k: v for k, v in STD10[1].items()}, {'%+d%+d' % k: v for k, v in STD10[2].items()}, {'%+d%+d' % k: v for k, v in STD55[2].items()}))
okBS = GR55[(1, 1)] == STD55[0][(1, 1)] and GR55[(1, -1)] == STD55[0][(1, -1)] and BD55 == STD55[1] == STD55[2]
okBS &= all(CJ['J+'][3][2][k] == STD10[0][(1, 1)][k] * (2 if k == 5 else 1) for k in STD10[0][(1, 1)]) and CJ['J+'][4][2] == STD10[0][(1, -1)]
okBS &= all(JS[nm][0][key][2] == 2 * STD10[1][key] and JS[nm][0][key][1] == 2 * STD10[2][key] for nm in JS for key in STD10[1])
chk('bit==std', okBS, 'tp.PAIR: Cl(5,5): the real grade ranks of the products and the real dimensions of the invariant forms on the Fock labels equal the complex ranks and dimensions of the Pauli words (real halves: the bilinear and the Hermitian dimensions coincide); Cl(0,10) with J of sign +1: the real rank of grade k equals the complex rank of grade k for k != 5 and is twice it for k = 5, and the J-bilinear (J-sesquilinear) real dimensions are twice the complex bilinear (Hermitian) ones, block by block')
note('the statistics a mass term needs (which symmetry of the form) and a Lagrangian stay outside the finite computation (%.1f s)' % (time.time() - t))

# ================================================================================================ tp.FH (b): Furey and Hughes's three copies
head('tp.FH (b): Furey and Hughes\'s three copies of H (x) O (arXiv:2409.17948, as SOURCES.md (g) records it) on the roadmap\'s labels of Cl(1,10)')
t = time.time()
# the roadmap's cell, copied from furey_roadmap.py (fr.ALG, fr.WITT, fr.FOCK: Cl(1,10), the central i = 2047, her dagger, the five pairs, her
# vacuum prod (1 + i e_j e_k)/2 and the 32 states s_S = the alpha_b of the bits of S applied to it)
E110 = sig(1, 10); C110 = Cell(E110); TOPC, GAM = 2047, 2046; I_ = blade(TOPC)
DS = np.array([(-1) ** ((pc(a) * (pc(a) + 1) // 2 + (a & 1)) % 2) for a in range(2048)], dtype=np.int64)   # her dagger on the labels
def dag(x): return {a: int(DS[a]) * c for a, c in x.items()}
ROADMAP = [(8, 7), (10, 9), (5, 4), (3, 1), (6, 2)]                        # bits 0, 1 (weak), 2, 3, 4 (colour): R1's pairs (j, k)
def gen(p): return blade(1 << p)
def bl(*ps): return C110.prod(*[gen(p) for p in ps])                       # the ordered product e_p1 e_p2 ..
AL = [lin((-hf, gen(j)), (hf, C110.mul(I_, gen(k)))) for j, k in ROADMAP]; ADL = [dag(x) for x in AL]
VAC = C110.prod(*[scal(add(ONE, C110.mul(I_, bl(j, k))), hf) for j, k in ROADMAP])
def state(S):
    v = VAC
    for b in reversed(range(5)):
        if (S >> b) & 1: v = C110.mul(AL[b], v)
    return v
ST = [state(S) for S in range(32)]
NB = [C110.mul(AL[b], ADL[b]) for b in range(5)]
okST = all(eq(C110.mul(NB[b], ST[S]), ST[S] if (S >> b) & 1 else {}) for b in range(5) for S in range(32)) and all(ST)
# the dictionary (new here): Roadmap I eq. 25 (Gamma_j = i L_ej L_e7 R_eps1, Gamma_(6+m) = L_e7 L_epsm R_eps1, Gamma_10 = R_eps2), eq. 22 (2 R_e7 =
# -L_e7 + L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5) and Furey 2018 eq. 16 (L_e7 = L_e1 .. L_e6): L_ej L_ek = Gamma_j Gamma_k, L_epsm L_epsn = L_(epsm epsn),
# Gamma_7 Gamma_8 Gamma_9 = -L_e7 R_eps1, so R_eps1 = Gamma_1 .. Gamma_9, R_eps3 = R_eps2 R_eps1 = -Gamma_11 (A5)
LL7 = bl(1, 2, 3, 4, 5, 6); RR7 = scal(lin((-1, LL7), (1, bl(1, 3)), (1, bl(2, 6)), (1, bl(4, 5))), hf)
LEPS = {1: bl(8, 9), 2: bl(9, 7), 3: bl(7, 8)}; REPS = {1: bl(*range(1, 10)), 2: bl(10), 3: scal(bl(*range(1, 11)), -1)}
M_ONE = scal(ONE, -1)
okD = eq(C110.mul(LL7, LL7), M_ONE) and eq(C110.mul(RR7, RR7), M_ONE) and eq(C110.mul(LL7, RR7), C110.mul(RR7, LL7)) and eq(REPS[3], scal(blade(GAM), -1))
okD &= all(eq(C110.mul(LEPS[m], LEPS[m]), M_ONE) and eq(C110.mul(REPS[m], REPS[m]), M_ONE) for m in (1, 2, 3))
okD &= eq(C110.mul(LEPS[1], LEPS[2]), LEPS[3]) and eq(C110.mul(LEPS[2], LEPS[3]), LEPS[1]) and eq(C110.mul(REPS[2], REPS[1]), REPS[3]) and eq(C110.mul(REPS[3], REPS[2]), REPS[1])
okD &= all(eq(C110.mul(x, y), C110.mul(y, x)) for x in LEPS.values() for y in REPS.values())
okD &= all(eq(C110.mul(x, y), C110.mul(y, x)) for x in list(LEPS.values()) + list(REPS.values()) for y in (LL7, RR7))
def eigval(X, v):
    """the rational eigenvalue y of the multivector X on the state v (X v = y v exactly), or None"""
    w = C110.mul(X, v); k0 = next(iter(v)); y = Fr(w.get(k0, 0)) / Fr(v[k0])
    return y if eq(w, scal(v, y)) else None
def iop(x): return C110.mul(I_, x)
SIGB = [[2 * ((S >> b) & 1) - 1 for b in range(5)] for S in range(32)]
cS = [s[2] * s[3] * s[4] for s in SIGB]; tS = [s[2] + s[3] + s[4] for s in SIGB]; PS_ = [s[0] * s[1] * s[2] * s[3] * s[4] for s in SIGB]
EIG = [(eigval(iop(LL7), ST[S]), eigval(iop(RR7), ST[S]), eigval(iop(LEPS[3]), ST[S]), eigval(iop(REPS[3]), ST[S])) for S in range(32)]
okE = all(EIG[S] == (cS[S], Fr(tS[S] - cS[S], 2), SIGB[S][0], PS_[S]) for S in range(32)) and all(PS_[S] == -(-1) ** pc(S) for S in range(32))
chk('bit', okST and okD and okE, 'tp.FH: the roadmap\'s cell Cl(1,10) (furey_roadmap.py\'s construction: her vacuum, the 32 states s_S, n_b reading bit b of S); the dictionary of her multiplications on C (x) H (x) O as labels, from Roadmap I eqs. 22, 25 and Furey 2018 eq. 16: L_e7 = e1..e6 (the label 126), R_e7 = (-e1..e6 + e1e3 + e2e6 + e4e5)/2, L_eps1 = e8e9, L_eps2 = e9e7, L_eps3 = e7e8, R_eps1 = e1..e9, R_eps2 = e10, R_eps3 = -e1..e10 = -Gamma11 (A5): L_e7, R_e7 and the six quaternion operators square to -1, L_e7 and R_e7 commute, L_eps1 L_eps2 = L_eps3 and R_eps2 R_eps1 = R_eps3 (R_x R_y = R_yx), the left and right quaternions commute with each other and with L_e7, R_e7 (exact); on the 32 states, with c = s2 s3 s4 and t = s2 + s3 + s4 = 2b - 3 (s_b = 2 n_b - 1): i L_e7 = c, i R_e7 = (t - c)/2, i L_eps3 = s0, i R_eps3 = s0 s1 s2 s3 s4 = -(-1)^|S| (the roadmap\'s chirality, FUR-030): the hypercharges of eq. 27 and the Cartan element R_eps3 of eq. 26 are diagonal on the states')
# eq. 27 (u(1)_Y per unit y) for the three copies, Y = -i delta (a convention: the multisets do not depend on its sign); eq. 26: su(2)_L as R_H
DP = lin((Fr(1, 6), LL7), (Fr(-1, 2), LEPS[3]), (Fr(1, 3), RR7)); DM = lin((Fr(-1, 3), LL7), (Fr(-1, 6), RR7)); DV = lin((Fr(1, 6), LL7), (Fr(-1, 2), LEPS[3]), (Fr(-1, 6), RR7))
YP, YM, YV = [[eigval(scal(iop(D_), -1), ST[S]) for S in range(32)] for D_ in (DP, DM, DV)]
bS = [pc(S >> 2) for S in range(32)]; s0 = [S & 1 for S in range(32)]; s1 = [(S >> 1) & 1 for S in range(32)]
YB = [Fr(s0[S] + s1[S], 2) - Fr(bS[S], 3) for S in range(32)]              # CAND-019's bits: Y = a/2 - b/3
okY = all(YP[S] == s0[S] - Fr(bS[S], 3) and YM[S] == Fr(3 * cS[S] + tS[S], 12) and YV[S] == Fr(SIGB[S][0], 2) + Fr(tS[S] - 3 * cS[S], 12) for S in range(32))
T0L = [S for S in range(32) if s0[S] == s1[S]]; DBL = [S for S in range(32) if s0[S] != s1[S]]
GP = [eigval(C110.mul(scal(LEPS[3], -1), REPS[3]), ST[S]) for S in range(32)]   # G+ = -L_eps3 R_eps3, a real involution
GEN1 = [S for S in range(32) if GP[S] == 1]
PSI_P = GEN1 if FAULT == 'PSIDIM' else list(range(32))                     # the labels taken as Psi+ (one generation under PSIDIM)
okP = Counter(YP[S] for S in PSI_P) == Counter({k: 2 * v for k, v in Counter(YB[S] for S in T0L).items()}) and all(YP[S] == YB[S] for S in T0L) and all(YP[S] != YB[S] for S in DBL)
okP &= all(GP[S] == SIGB[S][1] * cS[S] for S in range(32)) and len(GEN1) == 16 and Counter(YP[S] for S in GEN1) == Counter(YB[S] for S in T0L) and sorted(31 - S for S in GEN1) == GEN1
DPc = [eigval(scal(iop(DP), -1), ST[S]) for S in range(32)]
okR = all(eq(C110.mul(REPS[m], DP), C110.mul(DP, REPS[m])) for m in (1, 2, 3))
R2S = [C110.mul(REPS[2], ST[S]) for S in range(32)]
okR &= all(eq(R2S[S], ST[S ^ 2]) or eq(R2S[S], scal(ST[S ^ 2], -1)) for S in range(32)) and all(GP[S] == -GP[S ^ 2] for S in range(32))
chk('bit', okY and okP and okR, 'tp.FH: Psi+ (eq. 27\'s delta+ = L_((y/6)e7 - (y/2)eps3) + R_((y/3)e7); su(2)_L inactive, eq. 26): on the 32 states Y+ = -i delta+/y = s0 - b/3 exactly, which is CAND-019\'s Y = a/2 - b/3 on the 16 labels with equal weak bits (T3 = 0) and on no other; the multiset of Y+ on %s labels is %s that of the bits\' Y on those 16: two generations, real dimension 32 = 2 x 16, Y+ not depending on the weak bit 1; the real involution G+ = -L_eps3 R_eps3 (s1 c on the states) has two eigenspaces of 16 states, each closed under S -> 31 - S (so of real dimension 16 in the real copy) and each carrying the multiset once; R_eps1, R_eps2, R_eps3 commute with delta+ and R_eps2 = e10 maps each state to +- the state with bit 1 flipped, across the two eigenspaces of G+' % (len(PSI_P), 'twice' if len(PSI_P) == 32 else 'asserted twice'))
okM = Counter(YM) == Counter({k: 2 * v for k, v in Counter(YB[S] for S in DBL).items()}) and all(YM[S] == YB[S] for S in DBL if bS[S] in (1, 2)) and all(YM[S] == -YB[S] for S in DBL if bS[S] in (0, 3))
T3F = [eigval(scal(iop(REPS[3]), hf), ST[S]) for S in range(32)]
okM &= all(T3F[S] == -T3F[S ^ 2] and abs(T3F[S]) == hf and YM[S] == YM[S ^ 2] and YV[S] == YV[S ^ 2] for S in range(32))
okC = all((EIG[S][0] == EIG[S][1]) == (bS[S] in (0, 3)) and (EIG[S][0] == -EIG[S][1]) == (bS[S] in (1, 2)) for S in range(32))
VCL = {k: [S for S in range(32) if abs(YV[S]) == k] for k in (Fr(1, 2), Fr(1, 6), Fr(5, 6))}
okV = {k: len(v) for k, v in VCL.items()} == {Fr(1, 2): 8, Fr(1, 6): 12, Fr(5, 6): 12} and all(sorted(31 - S for S in v) == v for v in VCL.values())
okV &= all(YV[31 - S] == -YV[S] and YM[31 - S] == -YM[S] and YP[31 - S] == -YP[S] for S in range(32))
chk('bit', okM and okC and okV, 'tp.FH: Psi- (delta- = L_(-(y/3)e7) + R_(-(y/6)e7)): Y- = (3c + t)/12 = -1/2, 1/6, -1/6, 1/2 for b = 0, 1, 2, 3, the weak bits free; su(2)_L (eq. 26: right multiplications R_eps) pairs every state with the one of bit 1 flipped, T3 = (i/2) R_eps3 = +-1/2 opposite on the pair and Y- equal: 16 doublets; the multiset of Y- on the 32 is twice that of the bits\' Y on the 16 doublet labels (one weak bit), but per label Y- equals the bits\' Y for b = 1, 2 and is its negative for b = 0, 3: the copy is not the bits\' naming, only the multisets agree; V (delta^V = L_((y/6)e7 - (y/2)eps3) + R_(-(y/6)e7)): Y^V = s0/2 + (t - 3c)/12, all states in doublets; the classes |Y^V| = 1/2, 1/6, 5/6 have %d, %d, %d states, each closed under S -> 31 - S (Y(31 - S) = -Y(S) on all three copies; complex conjugation of the coefficients maps the state S to 31 - S, the standard route below), so the real copy splits into real dimensions 8 (h + H: 4 + 4), 12 (V_q), 12 (V_r), the record\'s 4, 4, 12, 12; colour: i L_e7 = i R_e7 (singlets) exactly for b = 0, 3, opposite for b = 1, 2' % tuple(len(VCL[k]) for k in (Fr(1, 2), Fr(1, 6), Fr(5, 6))))
GEN1F = [S for S in range(32) if GP[S] == 1]
chk('ctl', len(GEN1F) == 16 and Counter(YP[S] for S in GEN1F) != Counter({k: 2 * v for k, v in Counter(YB[S] for S in T0L).items()}),
    'tp.FH: one generation, the eigenspace G+ = +1 (16 states, real dimension 16), carries the multiset of the T3 = 0 labels once, not twice: taken for Psi+ (real dimension 32) it fails (PSIDIM)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
# the octonions and quaternions as data, copied from furey_roadmap.py (TRIP, FO, omul_f, LO, RO, qmul_f, LH, RH: the Roadmap's table in Furey's
# labelling, from furey_papers_check.py through furey_cl6.py) and its standard-route tools (Le, Re, Le_, Re_, the ten Gamma's GM10, fwords, rho)
TRIP = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
FO = np.zeros((8, 8, 8), dtype=np.int64)
for (i_, j_, k_) in TRIP:
    for (a_, b_, c_) in [(i_, j_, k_), (j_, k_, i_), (k_, i_, j_)]:
        FO[a_, b_, c_] = 1; FO[b_, a_, c_] = -1
def omul_f(i_, j_):
    if i_ == 0: return 1, j_
    if j_ == 0: return 1, i_
    if i_ == j_: return -1, 0
    for k_ in range(1, 8):
        if FO[i_, j_, k_] != 0: return int(FO[i_, j_, k_]), k_
LO = np.zeros((8, 8, 8), dtype=np.int64); RO = np.zeros((8, 8, 8), dtype=np.int64)
for a_ in range(8):
    for j_ in range(8):
        s_, k_ = omul_f(a_, j_); LO[a_][k_, j_] = s_
        s_, k_ = omul_f(j_, a_); RO[a_][k_, j_] = s_
def qmul_f(i_, j_):
    if i_ == 0: return 1, j_
    if j_ == 0: return 1, i_
    if i_ == j_: return -1, 0
    k_ = 6 - i_ - j_; return int(round(np.linalg.det(np.eye(3)[[i_ - 1, j_ - 1, k_ - 1]]))), k_
LH = np.zeros((4, 4, 4), dtype=np.int64); RH = np.zeros((4, 4, 4), dtype=np.int64)
for a_ in range(4):
    for j_ in range(4):
        s_, k_ = qmul_f(a_, j_); LH[a_][k_, j_] = s_
        s_, k_ = qmul_f(j_, a_); RH[a_][k_, j_] = s_
I4n, I8n = np.eye(4), np.eye(8)
def Le(a): return np.kron(I4n, LO[a]).astype(complex)
def Re(a): return np.kron(I4n, RO[a]).astype(complex)
def Le_(m): return np.kron(LH[m], I8n).astype(complex)
def Re_(m): return np.kron(RH[m], I8n).astype(complex)
ID32 = np.eye(32, dtype=complex)
GM10 = [1j * Le(j) @ Le(7) @ Re_(1) for j in range(1, 7)] + [Le(7) @ Le_(m) @ Re_(1) for m in range(1, 4)] + [Re_(2)]   # Roadmap eq. 25
def fwords(G):
    n = len(G); d = G[0].shape[0]; W = np.zeros((1 << n, d, d), dtype=np.complex128); W[0] = np.eye(d)
    for a in range(1, 1 << n):
        top = a.bit_length() - 1; W[a] = W[a ^ (1 << top)] @ G[top]
    return W
W110 = fwords([1j * Re_(3)] + GM10)                                       # e0 -> i R_eps3 = -i Gamma11, e_p -> Gamma_p (FUR-028)
def rho(x):
    out = np.zeros((32, 32), dtype=np.complex128)
    for a, c in x.items(): out += float(c) * W110[a]
    return out
okA = np.array_equal(prodm([LO[a] for a in range(1, 7)]), LO[7]) and np.array_equal(2 * RO[7], -LO[7] + LO[1] @ LO[3] + LO[2] @ LO[6] + LO[4] @ LO[5])
okA &= all(np.allclose(GM10[p] @ GM10[q] + GM10[q] @ GM10[p], -2 * (p == q) * ID32) for p in range(10) for q in range(10))
YPm, YMm, YVm = [-1j * M for M in (Le(7) / 6 - Le_(3) / 2 + Re(7) / 3, -Le(7) / 3 - Re(7) / 6, Le(7) / 6 - Le_(3) / 2 - Re(7) / 6)]
def fms(c): return '{' + ', '.join('%s: %d' % (k, v) for k, v in sorted(c.items())) + '}'   # a multiset of fractions, printed
def spec(M): ev = np.linalg.eigvalsh((M + M.conj().T) / 2); return Counter(Fr(int(round(6 * x)), 6) for x in ev), float(np.abs(6 * ev - np.rint(6 * ev)).max())
SPP, SPM, SPV = spec(YPm), spec(YMm), spec(YVm)
okSp = SPP[0] == Counter(YP) and SPM[0] == Counter(YM) and SPV[0] == Counter(YV) and max(SPP[1], SPM[1], SPV[1]) < 1e-9
# her basis of eqs. 30-31: eps_ab (x) x, x in {l, l*, alpha_i, alpha_i^dag}, as vectors of C (x) H (x) O = C^4 (x) C^8 (her labelling)
def qv(c): v = np.zeros(4, dtype=complex); [v.__setitem__(k, w) for k, w in c.items()]; return v
def ov(c): v = np.zeros(8, dtype=complex); [v.__setitem__(k, w) for k, w in c.items()]; return v
EPSB = {'uu': qv({0: .5, 3: .5j}), 'ud': qv({1: .5j, 2: -.5}), 'du': qv({1: .5j, 2: .5}), 'dd': qv({0: .5, 3: -.5j})}
OCTB = {'l': ov({0: .5, 7: .5j}), 'l*': ov({0: .5, 7: -.5j}), 'a1': ov({5: -.5, 4: .5j}), 'a2': ov({3: -.5, 1: .5j}), 'a3': ov({6: -.5, 2: .5j}),
        'a1d': ov({5: .5, 4: .5j}), 'a2d': ov({3: .5, 1: .5j}), 'a3d': ov({6: .5, 2: .5j})}
ALB = [0.5 * (-GM10[j - 1] + 1j * GM10[k - 1]) for j, k in ROADMAP]       # R1's a_c in the bit order of the labels
OmN = prodm(ALB); VN = OmN.conj().T @ OmN; x0 = VN[:, int(np.argmax(np.abs(VN).sum(0)))]; VEC0 = VN @ x0
STN = []
for S in range(32):
    v = VEC0.copy()
    for b in reversed(range(5)):
        if (S >> b) & 1: v = ALB[b] @ v
    STN.append(v)
NBM = [(ID32 - 1j * GM10[j - 1] @ GM10[k - 1]) / 2 for j, k in ROADMAP]   # n_b on the matrices
def bits_of(v):
    out = 0
    for b, N in enumerate(NBM):
        lam = np.vdot(v, N @ v) / np.vdot(v, v)
        if not (np.allclose(N @ v, lam * v, atol=1e-9) and abs(lam - round(lam.real)) < 1e-9): return None
        out |= int(round(lam.real)) << b
    return out
def prop(u, w): return abs(abs(np.vdot(u, w)) - np.linalg.norm(u) * np.linalg.norm(w)) < 1e-9 * np.linalg.norm(u) * np.linalg.norm(w)
FHB = {(e, o): np.kron(EPSB[e], OCTB[o]) for e in EPSB for o in OCTB}
SOF = {k: bits_of(v) for k, v in FHB.items()}
okB = sorted(s for s in SOF.values() if s is not None) == list(range(32)) and all(prop(FHB[k], STN[SOF[k]]) for k in FHB)
okB &= (SOF[('uu', 'l')], SOF[('ud', 'l')], SOF[('dd', 'l*')], SOF[('du', 'l*')]) == (31, 29, 0, 2)
okB &= all(prop(np.conj(STN[S]), STN[31 - S]) for S in range(32))
G1 = sorted(SOF[k] for k in FHB if k[0] in ('uu', 'dd')); GPm = -Le_(3) @ Re_(3)
okB &= G1 == sorted(GEN1) and all(np.allclose(GPm @ FHB[k], (1 if k[0] in ('uu', 'dd') else -1) * FHB[k]) for k in FHB)
chk('std', okA and okSp and okB, 'tp.FH: numpy on C (x) H (x) O = C^4 (x) C^8 (no label; her tables as furey_roadmap.py rebuilt them): L_e7 = L_e1..L_e6 and 2 R_e7 = -L_e7 + L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5 (exact integers), the ten Gamma\'s of eq. 25 anticommute with square -1; the spectra of -i delta/y for the three copies of eq. 27 are %s, %s, %s; her 32 basis vectors eps_ab (x) x of eqs. 30-31 are joint eigenvectors of the five number operators (1 - i Gamma_j Gamma_k)/2 and proportional to the roadmap\'s 32 states (R1\'s a_c applied to her vacuum), one each: l eps_uu and l eps_ud, the two right-handed neutrinos of eq. 32, are the states 31 and 29, their conjugates l* eps_dd and l* eps_du the states 0 and 2; complex conjugation of the coefficients maps the state S to the state 31 - S; -L_eps3 R_eps3 is +1 on eps_uu, eps_dd and -1 on eps_ud, eps_du' % tuple(fms(sp[0]) for sp in (SPP, SPM, SPV)))
okBS = all(np.allclose(rho(LL7), Le(7)) for _ in [0]) and np.allclose(rho(RR7), Re(7)) and all(np.allclose(rho(LEPS[m]), Le_(m)) and np.allclose(rho(REPS[m]), Re_(m)) for m in (1, 2, 3))
okBS &= all(np.allclose(rho(ST[S]) @ x0, STN[S]) for S in range(32)) and all(abs(np.vdot(STN[S], YPm @ STN[S]) / np.vdot(STN[S], STN[S]) - float(YP[S])) < 1e-9 for S in range(32))
okBS &= all(np.allclose((1j * Le(7)) @ FHB[k], float(EIG[SOF[k]][0]) * FHB[k]) and np.allclose((1j * Re(7)) @ FHB[k], float(EIG[SOF[k]][1]) * FHB[k]) and np.allclose((1j * Le_(3)) @ FHB[k], float(EIG[SOF[k]][2]) * FHB[k]) and np.allclose((1j * Re_(3)) @ FHB[k], float(EIG[SOF[k]][3]) * FHB[k]) for k in FHB)
chk('bit==std', okBS, 'tp.FH: the images of the label operators L_e7, R_e7, L_eps_m, R_eps_m under e0 -> i R_eps3, e_p -> Gamma_p are her matrices; the images of the 32 label states applied to the vacuum\'s vector are the numpy states, with the same eigenvalues of Y+; on her basis vectors the eigenvalues of i L_e7, i R_e7, i L_eps3, i R_eps3 are those of the label state they are proportional to')
# the product of H (x) O (integer structure constants) and the relation of eqs. 21-22, delta^V(x y) = (delta+ x) y + x (delta- y)
Lx = [np.kron(LH[q], LO[o]) for q in range(4) for o in range(8)]          # left multiplication by the basis element e_q (x) e_o
MT = np.array([[Lx[i][:, j] for j in range(32)] for i in range(32)]).transpose(2, 0, 1)   # MT[k, i, j]: the k-th coordinate of e_i e_j
def lift(Mq, Mo): return np.kron(Mq, Mo)
D6 = {'+': lift(np.eye(4, dtype=np.int64), LO[7] + 2 * RO[7]) - 3 * lift(LH[3], np.eye(8, dtype=np.int64)),       # 6 delta+/y (eq. 27)
      '-': lift(np.eye(4, dtype=np.int64), -2 * LO[7] - RO[7]),                                                      # 6 delta-/y
      'V': lift(np.eye(4, dtype=np.int64), LO[7] - RO[7]) - 3 * lift(LH[3], np.eye(8, dtype=np.int64))}              # 6 delta^V/y
def equiv(DV_, DP_, DM_, conj=False):
    """the number of basis pairs (i, j) where delta^V(x y') != (delta+ x) y' + x (delta- y)' with y' = y or its conjugate (exact integers)"""
    K = np.kron(np.diag([1, -1, -1, -1]), np.diag([1] + [-1] * 7)).astype(np.int64) if conj else np.eye(32, dtype=np.int64)
    lhs = np.einsum('kl,lij->kij', DV_, np.einsum('lim,mj->lij', MT, K))
    rhs = np.einsum('kmj,mi->kij', np.einsum('kim,mj->kij', MT, K), DP_) + np.einsum('kim,mj->kij', MT, K @ DM_)
    return int(np.any(lhs != rhs, axis=0).sum())
NEQ_Y = equiv(D6['V'], D6['+'], D6['-']); NEQ_YD = equiv(D6['V'], D6['+'], D6['-'], conj=True)
NEQ_L = [equiv(-lift(RH[m], np.eye(8, dtype=np.int64)), 0 * D6['+'], -lift(RH[m], np.eye(8, dtype=np.int64))) for m in (1, 2, 3)]   # eq. 26
NEQ_T = sum(equiv(lift(np.eye(4, dtype=np.int64), LO[a] + RO[b]), lift(np.eye(4, dtype=np.int64), LO[a] + RO[a] - RO[b]), lift(np.eye(4, dtype=np.int64), LO[b] - LO[a] + RO[b])) for a in range(1, 8) for b in range(1, 8))
NEQ_TH = sum(equiv(lift(LH[a] + RH[b], np.eye(8, dtype=np.int64)), lift(LH[a] + RH[a] - RH[b], np.eye(8, dtype=np.int64)), lift(LH[b] - LH[a] + RH[b], np.eye(8, dtype=np.int64))) for a in range(1, 4) for b in range(1, 4))
# su(3)_C: the derivations of O (D(xy) = D(x) y + x D(y)) by an exact null space, those fixing e7, and their action
drows = []
for a_ in range(8):
    for b_ in range(8):
        for k_ in range(8):                                                # component k of D(e_a e_b) - D(e_a) e_b - e_a D(e_b), unknowns D[r, c] at 8 r + c
            row = [0] * 64; s_, m_ = omul_f(a_, b_); row[8 * k_ + m_] += s_
            for r_ in range(8): row[8 * r_ + a_] -= int(RO[b_][k_, r_]); row[8 * r_ + b_] -= int(LO[a_][k_, r_])
            drows.append(row)
DER = nullspace_frac(drows, 64); DER7 = nullspace_frac(drows + [[int(c == 8 * r_ + 7) for c in range(64)] for r_ in range(8)], 64)
DM7 = [np.array([[int(v[8 * r_ + c_]) for c_ in range(8)] for r_ in range(8)], dtype=np.int64) for v in DER7]
okDer = len(DER) == 14 and len(DER7) == 8 and all(np.array_equal(D_ @ LO[7], LO[7] @ D_) and np.array_equal(D_ @ RO[7], RO[7] @ D_) and not D_[:, 0].any() and not D_[:, 7].any() for D_ in DM7)
V6 = list(range(1, 7)); crow = []
for D_ in DM7:
    Dr = D_[np.ix_(V6, V6)]
    for i_ in range(6):
        for j_ in range(6):                                                # (X Dr - Dr X)[i, j] = 0, unknowns X[r, c] at 6 r + c
            row = [0] * 36
            for k_ in range(6): row[6 * i_ + k_] += int(Dr[k_, j_]); row[6 * k_ + j_] -= int(Dr[i_, k_])
            crow.append(row)
COMM6 = nullspace_frac(crow, 36)
chk('std', NEQ_Y == 0 and NEQ_L == [0, 0, 0] and NEQ_T == 0 and NEQ_TH == 0 and NEQ_YD > 0 and okDer and len(COMM6) == 2,
    'tp.FH: numpy, the product of H (x) O (integer structure constants, no label): the relation of eqs. 21-22, delta^V(x y) = (delta+ x) y + x (delta- y) with delta^V = L_a + R_b, delta+ = L_a + R_(a-b), delta- = L_(b-a) + R_b, holds on all 32 x 32 pairs of basis elements for the 49 pairs of imaginary octonion units and the 9 of quaternion units (an identity of the associator; %d failures), for eq. 27\'s u(1)_Y (%d failures) and for eq. 26\'s su(2)_L with delta+ = 0 (%s): the plain product Psi+ Psi- is equivariant; with the conjugation of eq. 36, x y^dag with delta- acting on y as recorded, it fails on %d of the 1024 pairs (whether the paper\'s delta- acts on Psi- or on Psi-^dag is not in the record: nothing is decided about the paper); the products span the 32 (1 y = y); the derivations of O form a space of dimension %d (exact null space), those fixing e7 one of dimension %d: they commute with L_e7 and R_e7, kill 1 and e7, and on the six units e1..e6 have the commutant of dimension %d (C): the colour multiplets are the two singlets and the two joint eigenspaces of dimension 3 of L_e7, R_e7' % (NEQ_T + NEQ_TH, NEQ_Y, NEQ_L, NEQ_YD, len(DER), len(DER7), len(COMM6)))
note('read, not computed: the full lists of eqs. 32-33, the set of eq. 39 (32 real dimensions recorded), the factorization 36-39, dynamics and symmetry breaking (left by the authors to future work); nothing about nature\'s generations (%.1f s)' % (time.time() - t))

# ================================================================================================ tp.CPX (c): the complexification
head('tp.CPX (c): Cl(p,q) (x) C for the 45 cells with n <= 8 on the labels with the central i; the 15 chains of GEN-019 with D = H complexified')
t = time.time()
T2 = np.array([[1, 1], [1, -1]], dtype=np.int8)                           # Cl(0,1): the extra generator i, of square -1
def cplx_table(eps):
    """Cl(p,q) (x) C as the ungraded product Cl(p,q) (x) Cl(0,1) (branching_16.py's ungraded_table): the label a + 2^n e, the bit n (i) commuting
    with every label; under NOCENTRAL the graded product Cl(p,q+1), whose extra generator anticommutes with the generators"""
    return table(tuple(eps) + (-1,)) if FAULT == 'NOCENTRAL' else np.kron(T2, table(eps))
RULE = {'R': lambda m, c: ('C', m, c), 'C': lambda m, c: ('C', m, c if FAULT == 'NOCRULE' else 2 * c), 'H': lambda m, c: ('C', 2 * m, c)}
CELLS45 = [(p, n - p) for n in range(9) for p in range(n + 1)]
RES45 = {}; okT = okI = okZ = True; byD = Counter()
for p, q in CELLS45:
    eps = sig(p, q); n = p + q; Tc = cplx_table(eps); Lc = lab_table(Tc)
    tr, tcl = ltype_eps(eps), clock_type(p, q); tc = table_type(Tc, [1 << k for k in range(n + 1)])
    G = comm_labels(Lc, tries=8); I_ = Ideal(Lc, G); d, D, _ = centraliser_div(Lc, G)
    RES45[(p, q)] = (tr, tc); byD[tr[0] + ('2' if tr[2] == 2 else '')] += 1
    okT &= tr == tcl and tc == RULE[tr[0]](tr[1], tr[2]) and tc == ('C', 1 << (n // 2), 1 + n % 2)
    okI &= D == 'C' and tc is not None and I_.m == 2 * tc[1] and (tr[0] != 'H' or any((g >> n) & 1 for g in G))   # for D = H, i times labels in G
    if n % 2:                                                              # the central idempotents (1 +- w')/2, w' = omega or i omega of square +1
        om, iom = (1 << n) - 1, (1 << (n + 1)) - 1; w = om if Lc.sq(om) == 1 else iom
        e_ = {0: Fr(1, 2), w: Fr(1, 2)}; okZ &= Lc.sq(w) == 1 and all(Lc.commute(w, 1 << k) for k in range(n + 1)) and Lc.mul(e_, e_) == e_
        okZ &= (w == iom) == ((p - q) % 8 in (3, 7))
NH = sorted(c for c, (tr, tc) in RES45.items() if tr[0] == 'H'); NC = sorted(c for c, (tr, tc) in RES45.items() if tr[0] == 'C')
chk('bit', okT and okI and okZ and len(RES45) == 45, 'tp.CPX: for the 45 cells (p,q,0) with n <= 8, Cl(p,q) (x) C on the labels as the ungraded product with Cl(0,1) (the extra bit i, of square -1, commuting with every label%s): the centre is span{1, i} for even n and span{1, i, omega, i omega} for odd n, the count 0, the type M_(2^(n/2))(C) or M_(2^((n-1)/2))(C) + M_(2^((n-1)/2))(C), the type of n alone; for odd n the central idempotents (1 +- omega)/2 at the clocks 1, 5 and (1 +- i omega)/2 at the clocks 3, 7; a minimal left ideal (commuting labels of square +1, among them i times labels of square -1) has real dimension 2 m and commutant C in every cell; against the real type by the clock (%s cells) with the rules M_m(R) (x) C = M_m(C), M_m(C) (x)_R C = M_m(C) + M_m(C) (the C rule%s: the %d cells %s), M_m(H) (x) C = M_2m(C) (the H rule: the %d cells %s): all 45 agree, so the complexification of a clock-4 or clock-6 cell is that of the clock-0 or clock-2 cell of the same n' % (
    '; NOCENTRAL: the graded product taken' if FAULT == 'NOCENTRAL' else '', dict(sorted(byD.items())), ' omitted: NOCRULE' if FAULT == 'NOCRULE' else '', len(NC), ', '.join('(%d,%d)' % c for c in NC), len(NH), ', '.join('(%d,%d)' % c for c in NH)))
TRUEC = {(p, q): table_type(np.kron(T2, table(sig(p, q))), [1 << k for k in range(p + q + 1)]) for p, q in CELLS45}   # the ungraded product
ctl_cen = sum(1 for p, q in CELLS45 if ltype_eps(sig(p, q) + (-1,)) != TRUEC[(p, q)])
ctl_rule = sum(1 for p, q in CELLS45 if ltype_eps(sig(p, q))[0] == 'C' and ('C', ltype_eps(sig(p, q))[1], ltype_eps(sig(p, q))[2]) != TRUEC[(p, q)])
chk('ctl', ctl_cen > 0 and ctl_rule == 10, 'tp.CPX: the extra unit taken anticommuting with the generators (the graded product, Cl(p,q+1)) gives another type at %d of the 45 cells (NOCENTRAL); the table without the C rule (M_m(C) (x)_R C taken as M_m(C)) is wrong at %d cells, those of the clocks 3 and 7 (NOCRULE)' % (ctl_cen, ctl_rule))
note('(%.1f s)' % (time.time() - t))
t = time.time()
def std_ctype(p, q):
    """the complex type of the C-span of the words of complex Pauli matrices g_k^2 = +-1 (no label): its dimension, the dimension of its centre
    (null space of the commutators with the generators), the sizes of the summands (ranks of the central idempotents)"""
    n = p + q
    if n == 0: return ('C', 1, 1), True
    h = (n + 1) // 2; Hw = herm_words(h); G = [Hw[k] if k < p else 1j * Hw[k] for k in range(n)]; W = np.array(cwords(G)); d = W.shape[1]
    sv = np.linalg.svd(W.reshape(len(W), -1), compute_uv=False); span = int((sv > 1e-9 * sv.max()).sum())
    A = np.vstack([np.array([(Wa @ g - g @ Wa).ravel() for Wa in W]).T for g in G]); sv = np.linalg.svd(A, compute_uv=False)
    zc = len(W) - int((sv > 1e-9 * sv.max()).sum())
    if zc == 1: return ('C', d if span == d * d else 0, 1), span == 1 << n
    om = prodm(G); w = om if np.allclose(om @ om, np.eye(d)) else 1j * om; Pp = (np.eye(d) + w) / 2
    sv = np.linalg.svd(np.array([(Wa @ Pp).ravel() for Wa in W]), compute_uv=False); dimp = int((sv > 1e-9 * sv.max()).sum())
    return ('C', isqrt(dimp), 2), span == 1 << n and isqrt(dimp) ** 2 == dimp and np.allclose(w @ w, np.eye(d))
STDC = {c: std_ctype(*c) for c in CELLS45}
chk('std', all(v[1] for v in STDC.values()) and all(STDC[c][0] == ('C', 1 << (sum(c) // 2), 1 + sum(c) % 2) for c in CELLS45),
    'tp.CPX: numpy (no label): for each of the 45 cells, n anticommuting complex Pauli matrices with g_k^2 = +1 (k < p) and -1: the 2^n words are C-independent (so their C-span is the complexification of their R-span), the centre of the C-span has dimension 1 for even n and 2 for odd n, and the summands have the sizes 2^(n/2), resp. two of 2^((n-1)/2) (ranks of (1 +- w)/2, w = omega or i omega of square 1)')
chk('bit==std', all(STDC[c][0] == RES45[c][1] for c in CELLS45), 'tp.CPX: the complex types agree on the labels with the central i and on the Pauli matrices for the 45 cells')
note('(%.1f s)' % (time.time() - t))
t = time.time()
# the chains of GEN-019 with D = H: start cells of the clocks 4, 6 (s = 1) and 5 (s = 2) with n <= 4, the three blocks, stages 0 and 1
STARTH = [(0, 2, 0), (1, 3, 0), (0, 4, 0), (4, 0, 0), (0, 3, 0)]; BLOCKS = [(8, 0, 0), (0, 8, 0), (4, 4, 0)]
TARGET = {(0, 2, 0): (1, 1, 0), (1, 3, 0): (2, 2, 0), (0, 4, 0): (2, 2, 0), (4, 0, 0): (2, 2, 0), (0, 3, 0): (2, 1, 0)}   # same n, D = R, same s
def ctype_vec(eps):
    """the type of Cl(eps) (x) C from the labels with the central i without the full table (the ungraded product's centre is the real centre
    times {1, i}, its squares the real ones and their negatives, its count 0); under NOCENTRAL the graded product Cl(eps + (-1,))"""
    if FAULT == 'NOCENTRAL': return ltype_eps(tuple(eps) + (-1,))
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); cen = np.ones(1 << n, dtype=bool)
    for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
    return type_from_inv(1 << (n + 1), int(cen.sum()), True, 0)
def phi_lab(S, n0, NK):                                                    # e_S -> +e_(S xor [|S| odd] Omega) (cc.LIM), Omega the next block of 8
    return S ^ ((255 << NK) if pc(S) % 2 else 0)
def span_set(labs):
    span = {0}
    for g in labs: span |= {x ^ g for x in span}
    return span
def indep(labs): return len(span_set(labs)) == 1 << len(labs)
def comm_set_ok(eps, labs, cplx=False):
    """the labels commute pairwise, square to +1 and are independent, in Cl(eps) or (cplx) in Cl(eps) (x) Cl(0,1), the bit len(eps) being i"""
    N = len(eps); L_ = np.array(labs, dtype=np.int64); lo = L_ & ((1 << N) - 1); hi = (L_ >> N) & 1 if cplx else 0 * L_
    P = s_vec(eps, lo[:, None], lo[None, :]) * (1 - 2 * (hi[:, None] & hi[None, :]))
    return bool(np.all(np.diag(P) == 1)) and bool(np.all(P == P.T)) and indep(labs)
def psi_pairs(e, eT, F):
    """psi: e_j -> i e'_j (j in F), e'_j otherwise, on all pairs of labels: psi(e_A) psi(e_B) = psi(e_A e_B) with powers of i (as sp.CPX)"""
    N = len(e); a = np.arange(1 << N, dtype=np.int64); fm = sum(1 << j for j in F); f = popv(a & fm)
    S, ST_ = table(e).astype(np.int64), table(eT).astype(np.int64)
    lhs = (f[:, None] + f[None, :] + 2 * (ST_ < 0)) % 4; rhs = (f[a[:, None] ^ a[None, :]] + 2 * (S < 0)) % 4
    return int((lhs != rhs).sum()), (1 << N) ** 2
CHR = {}; okCh = okPsi = True; npairs = 0
for c0 in STARTH:
    n = sum(c0); e0 = sig(*c0); eT = sig(*TARGET[c0]); F = [j for j in range(n) if e0[j] != eT[j]]
    L0 = lab_graded(e0); G0 = comm_labels(L0, tries=6); dH, DH, U0 = centraliser_div(L0, G0)
    for b in BLOCKS:
        eb = sig(*b); E = [e0 + eb * k for k in range(3)]; ET = [eT + eb * k for k in range(2)]
        rt = [ltype_eps(E[k]) for k in range(2)]; ct = [ctype_vec(E[k]) for k in range(2)]; rtT = [ltype_eps(ET[k]) for k in range(2)]; ctT = [ctype_vec(ET[k]) for k in range(2)]
        m0, s_ = rt[0][1], rt[0][2]
        QBb = comm_labels(lab_graded(eb), tries=6)                         # four commuting labels of square +1 of the block (GEN-019's QB)
        G1 = [phi_lab(g, n, n) for g in G0] + [x << n for x in QBb]; u0 = U0[0]; u1 = phi_lab(u0, n, n)
        PC = [G0 + [u0 | (1 << n)], G1 + [u1 | (1 << (n + 8))]]            # the factors of the complexified minimal idempotents (i the top bit)
        okPC = all(comm_set_ok(E[k], PC[k], cplx=True) for k in range(2)) and all(comm_set_ok(E[k], [G0, G1][k]) for k in range(2))
        tau = [Fr(1, 1 << len(PC[k])) for k in range(2)]                    # the scalar part of prod (1 + e_v)/2 over independent labels
        idl = [1 << (len(E[k]) + 1 - len(PC[k])) for k in range(2)]        # the real dimension of the left ideal of the idempotent
        om0, om1 = (1 << n) - 1, (1 << (n + 8)) - 1
        okKeep = s_ == 1 or (phi_lab(om0, n, n) == om1 and om0 in span_set(G0) and om1 in span_set(G1))   # s = 2: omega kept, P in one summand
        CHR[(c0, b)] = dict(n=n, F=F, rt=rt, ct=ct, rtT=rtT, ctT=ctT, m0=m0, s=s_, G0=G0, G1=G1, U0=U0, QB=QBb, tau=tau, idl=idl, okPC=okPC, E=E, ET=ET)
        okCh &= rt == [('H', m0, s_), ('H', 16 * m0, s_)] and rtT == [('R', 2 * m0, s_), ('R', 32 * m0, s_)] and ct == ctT == [('C', 2 * m0, s_), ('C', 32 * m0, s_)]
        okCh &= okPC and [s_ * x for x in tau] == [Fr(1, 2 * m0), Fr(1, 32 * m0)] and idl == [4 * m0, 64 * m0] and okKeep and len(G1) == len(G0) + 4
        okPsi &= all(ET[k][j] * (-1 if j in F else 1) == E[k][j] for k in range(2) for j in range(len(E[k])))
        okPsi &= all(int(s_vec(E[1], 1 << j, 255 << n)) == int(s_vec(ET[1], 1 << j, 255 << n)) for j in range(n))   # psi phi = phi' psi on generators
        for k in ((0, 1) if n <= 3 else (0,)):
            bad, tot = psi_pairs(E[k], ET[k], F); okPsi &= bad == 0; npairs += tot
chk('bit', okCh, 'tp.CPX: the 15 chains of GEN-019 with D = H (start cells (0,2), (1,3), (0,4), (4,0), s = 1, and (0,3), s = 2; blocks (8,0,0), (0,8,0), (4,4,0); stages 0 and 1): the real types M_(m0)(H)^s and M_(16 m0)(H)^s%s, the complexified ones (with the central i) M_(2 m0)(C)^s and M_(32 m0)(C)^s, the same as those of the R chains of the same n (M_(2 m0)(R)^s, M_(32 m0)(R)^s, complexified alike); a minimal idempotent of each complexified stage, P (1 + i u)/2 with P from a maximal commuting set (at stage 1 the image of the one before and four commuting labels of the block) and u a unit of the real commutant ((i u)^2 = +1): its factors commute, square to +1 and are independent (exact), its left ideal has real dimension 4 m0 16^k (a column of M_(2 m0 16^k)(C)) and its trace per summand is 1/(2 m0 16^k); the inclusion e_j -> e_j Omega, i -> i (on the labels e_S -> +e_(S xor [|S| odd] Omega), cc.LIM), sends only the label 0 to 0 (the trace is kept) and, for s = 2, omega to +omega, so its multiplicity is 16: K_0 of the complexified chain is Z[1/2]^s with the unit 2 m0 (1, .., 1), isomorphic with its unit to GEN-026\'s group of the real H chain (x -> 2x is an order automorphism of Z[1/2])' % (' (NOCENTRAL: the graded product taken)' if FAULT == 'NOCENTRAL' else ''))
chk('bit', okPsi, 'tp.CPX: psi: e_j -> i e\'_j on the generators whose square differs ((0,2) -> (1,1), (1,3) -> (2,2), (0,4) -> (2,2), (4,0) -> (2,2), (0,3) -> (2,1)), the block generators fixed, keeps the relations at both stages (every generator), is multiplicative on all %d pairs of labels checked (stage 0 of the 15 chains, stage 1 of the 6 with n <= 3; powers of i a separate unit) and satisfies psi phi = phi\' psi on the generators: the complexified H chain is, at the stages 0 and 1 and with the inclusion between them (and at every stage by the same map, the blocks\' generators unchanged), the complexified R chain of the same n and block, a chain of matricial C-algebras; so Goodearl\'s theorem in the form read (unital ultramatricial algebras over a field: SOURCES.md (a), secondary) applies to the complexified chain; what it says about the real H chain is a reading (one complex AF algebra can have several real forms: SOURCES.md (c), secondary)' % npairs)
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ tp.INT: the real H chain interleaved
head('tp.INT: the real H chain itself: B_k = phi(C_k) Q, Q = H in the next block, between C_k and C_(k+1); its type on the labels')
t = time.time()
def quat_pair(eb, off, sq=-1):
    """two labels of the block (8 generators, eps eb) of square sq that anticommute: Q = span{1, q1, q2, q1 q2} (H for sq = -1, M2(R) for +1)"""
    T_ = table(eb); x = next(u for u in range(1, 256) if T_[u, u] == sq); y = next(u for u in range(1, 256) if T_[u, u] == sq and T_[u, x] == -T_[x, u])
    return x << off, y << off
def btype(eps, labs, gens):
    """the type of the subalgebra spanned by the labels labs (closed under the product) with generators gens: its centre among its labels,
    the squares there and its count (the vectorised kernel formula)"""
    L_ = np.array(labs, dtype=np.int64); cen = np.ones(len(L_), dtype=bool)
    for g in gens: cen &= s_vec(eps, L_, g) == s_vec(eps, g, L_)
    sq = s_vec(eps, L_, L_); Z = np.flatnonzero(cen); cplx = bool(np.any(sq[Z] == -1))
    return type_from_inv(len(L_), len(Z) // 2 if cplx else len(Z), cplx, int(sq.sum()))
QSQ = 1 if FAULT == 'QREAL' else -1                                        # the square of q1, q2 (+1: Q = M2(R) under QREAL)
INT = {}; okInt = True
for (c0, b), X in CHR.items():
    n, m0, s_, E = X['n'], X['m0'], X['s'], X['E']; eb = sig(*b)
    q1, q2 = quat_pair(eb, n, QSQ); p1, p2 = quat_pair(eb, n + 8, QSQ)
    B0 = sorted({phi_lab(A, n, n) ^ q for A in range(1 << n) for q in (0, q1, q2, q1 ^ q2)})
    B1 = sorted({phi_lab(S, n, n + 8) ^ q for S in range(1 << (n + 8)) for q in (0, p1, p2, p1 ^ p2)})
    gB0 = [phi_lab(1 << j, n, n) for j in range(n)] + [q1, q2]; gB1 = [phi_lab(1 << j, n, n + 8) for j in range(n + 8)] + [p1, p2]
    tB = [btype(E[1], B0, gB0), btype(E[2], B1, gB1)]
    u1, u2 = next((x, y) for x in X['U0'] for y in X['U0'] if x < y and lab_graded(sig(*c0)).s(x, y) == -lab_graded(sig(*c0)).s(y, x))
    PB0 = [phi_lab(g, n, n) for g in X['G0']] + [phi_lab(u1, n, n) ^ q1, phi_lab(u2, n, n) ^ q2]
    PB1 = [phi_lab(g, n, n + 8) for g in X['G1']] + [phi_lab(phi_lab(u1, n, n), n, n + 8) ^ p1, phi_lab(phi_lab(u2, n, n), n, n + 8) ^ p2]
    okI_ = comm_set_ok(E[1], PB0) and comm_set_ok(E[2], PB1)
    okI_ &= all(int(s_vec(E[1], g, q)) == int(s_vec(E[1], q, g)) for g in gB0[:n] for q in (q1, q2)) and all(int(s_vec(E[2], g, q)) == int(s_vec(E[2], q, g)) for g in gB1[:n + 8] for q in (p1, p2))
    okI_ &= span_set(gB0) == set(B0) and span_set(gB1) == set(B1)          # the labels of B_k are the XOR-span of its generators: closed
    tauB = [Fr(1, 1 << len(PB0)), Fr(1, 1 << len(PB1))]
    sub = set(B0) >= {phi_lab(A, n, n) for A in range(1 << n)} and set(B1) >= {phi_lab(S, n, n + 8) for S in B0}   # C_0 -> B_0, B_0 -> B_1
    INT[(c0, b)] = (tB, tauB, okI_)
    okInt &= tB == [('R', 4 * m0, s_), ('R', 64 * m0, s_)] and okI_ and [s_ * x for x in tauB] == [Fr(1, 4 * m0), Fr(1, 64 * m0)] and sub and len(B0) == 4 << n and len(B1) == 4 << (n + 8)
chk('bit', okInt, 'tp.INT: for the 15 chains with D = H: in the next block two labels q1, q2 of square %d that anticommute span with 1 and q1 q2 an algebra Q%s, which commutes with phi(C_k) (phi(C_k) commutes with every label of the block; checked on the generators); B_k = phi(C_k) Q, spanned by the 4 dim C_k labels phi(e_A) q, lies between C_k and C_(k+1) (phi(C_k) in B_k in C_(k+1), and phi(B_0) in B_1); on its labels (centre, squares, count) B_0 is %s and B_1 is %s (for the chain (0,2), (8,0,0)), in general M_(4 m0)(R)^s and M_(64 m0)(R)^s: C_k (x) H = M_(m0 16^k)(H (x) H) = M_(4 m0 16^k)(R)^s; P (1 + phi(u1) q1)/2 (1 + phi(u2) q2)/2 (u1, u2 anticommuting units of the commutant) has commuting, independent factors of square +1 and trace per summand 1/(4 m0 16^k), a minimal idempotent, so B_0 -> B_1 has multiplicity 16; computed for B_0 in C_1 and B_1 in C_2 (up to 20 generators)' % (QSQ, ' (QREAL: M2(R))' if FAULT == 'QREAL' else ' = H', tstr(INT[((0, 2, 0), (8, 0, 0))][0][0]), tstr(INT[((0, 2, 0), (8, 0, 0))][0][1])))
RQ = {}
for (c0, b), X in CHR.items():
    n = X['n']; r1, r2 = quat_pair(sig(*b), n, 1)                           # Q of real type: two anticommuting block labels of square +1
    B0r = sorted({phi_lab(A, n, n) ^ q for A in range(1 << n) for q in (0, r1, r2, r1 ^ r2)})
    RQ[(c0, b)] = btype(X['E'][1], B0r, [phi_lab(1 << j, n, n) for j in range(n)] + [r1, r2])
chk('ctl', all(RQ[k] == ('H', 2 * CHR[k]['m0'], CHR[k]['s']) for k in CHR),
    'tp.INT: with Q of real type (two anticommuting block labels of square +1: M2(R)) B_0 = C_0 (x) M2(R) is %s for the chain (0,2), (8,0,0), in general M_(2 m0)(H)^s: still over H, not over a field; taken for the interleaving it fails (QREAL)' % tstr(RQ[((0, 2, 0), (8, 0, 0))]))
note('(%.1f s)' % (time.time() - t))
t = time.time()
def std_btype(c0, b):
    """B_0 as matrices (no label): complex Pauli matrices for the n + 8 generators of stage 1, e_j Omega and the block products q1, q2 as
    matrix products, the real span of the 4 dim C_0 words: its real centre (null space of the commutators), the squares there, the count
    (the signature of the trace form: the words square to +-1)"""
    X = CHR[(c0, b)]; n = X['n']; E1 = X['E'][1]; N1 = n + 8; Hw = herm_words((N1 + 1) // 2); G = [Hw[k] if E1[k] == 1 else 1j * Hw[k] for k in range(N1)]
    d = G[0].shape[0]; I_d = np.eye(d)
    def mat(lab):
        M = I_d.astype(complex)
        for k in range(N1):
            if (lab >> k) & 1: M = M @ G[k]
        return M
    q1, q2 = quat_pair(sig(*b), n, QSQ)
    Om = mat(255 << n); PH = [G[j] @ Om for j in range(n)]
    Wd = []
    for A in range(1 << n):
        WA = I_d.astype(complex)
        for j in range(n):
            if (A >> j) & 1: WA = WA @ PH[j]
        for q in (0, q1, q2, q1 ^ q2): Wd.append(WA @ mat(q))
    gens = PH + [mat(q1), mat(q2)]
    A_ = np.vstack([np.vstack([np.array([(Wa @ g - g @ Wa).ravel().real for Wa in Wd]).T, np.array([(Wa @ g - g @ Wa).ravel().imag for Wa in Wd]).T]) for g in gens])
    _, sv, Vh = np.linalg.svd(A_, full_matrices=False); nz = len(Wd) - int((sv > 1e-9 * sv.max()).sum())
    Zs = [sum(c * Wa for c, Wa in zip(v, Wd)) for v in Vh[len(Wd) - nz:]]
    cplx = any(np.allclose(Z_ @ Z_, -np.vdot(Z_.ravel(), Z_.ravel()).real / d * I_d, atol=1e-8) for Z_ in Zs if not np.allclose(Z_, Z_[0, 0] * I_d))
    fs = int(round(sum(np.trace(Wa @ Wa).real / d for Wa in Wd)))
    return type_from_inv(len(Wd), nz // 2 if cplx else nz, cplx, fs)
STDB = {(c0, (8, 0, 0)): std_btype(c0, (8, 0, 0)) for c0 in STARTH}
chk('std', all(STDB[k] == ('R', 4 * CHR[k]['m0'], CHR[k]['s']) for k in STDB),
    'tp.INT: numpy (no label): for the five start cells with the block (8,0,0), the real span of B_0\'s words as complex Pauli matrices of stage 1 (e_j Omega and the block products q1, q2 as matrix products) has a real centre of dimension s (no central element of square -1) and the trace-form signature +4 m0 s: %s' % ', '.join('(%d,%d) %s' % (k[0][0], k[0][1], tstr(v)) for k, v in STDB.items()))
chk('bit==std', all(STDB[k] == INT[k][0][0] for k in STDB), 'tp.INT: the types of B_0 agree on the labels and on the matrices')
note('so the union of the real H chain is the union of the chain B_0 in B_1 in .. of finite products of matrix algebras over the field R (multiplicity 16, K_0 = Z[1/2]^s with the unit 4 m0): a unital ultramatricial R-algebra, to which the theorem as read (Elliott in Goodearl\'s form, SOURCES.md (a), secondary) applies as stated; its conclusion, that this limit is the limit of the R chain with the same s and unit, is the theorem\'s, cited, not computed; the C*-completions are not built (%.1f s)' % (time.time() - t))
finish()
