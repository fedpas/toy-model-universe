#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""chain_labels.py: the computable cores of four readings at the top of the rule, cells and shapes pages: blades as cube corners and
labels, the unit 1 as the baseline of every cell, the signed faces of a fused pair against a lone null generator, and the grade parity of
fields and sources.
     python3 chain_labels.py [--fault OR|TOPBIT|UNITSIGN|NOFACTOR4|NOPAIR|MIXEDPSI|A2]

chn.1 (PAG-002b).  In every cell with n <= 4 (all 3^n patterns of squares +1, -1, 0) and in Cl(n,0) for n <= 8: the 2^n ordered products
   e_i1 ... e_ik (i1 < ... < ik) of distinct generators are +-1 times the 2^n blades, each label once; the grade is the popcount and there are
   C(n,k) blades of grade k, as many as corners of the n-cube of weight k and faces of the (n-1)-simplex with k vertices (enumerated
   separately); e_i e_a = +- e_(a xor 2^i), so a generator moves a label along an edge of the cube (n 2^(n-1) edges, each met from both ends);
   e_a e_b = s(a,b) e_(a xor b) and every sub-label b of a splits e_a = +- e_b e_(a xor b).
   [bit] bitrule_A.py BR, exact integers.  [std] complex Kronecker gamma matrices of Cl(n,0), n <= 6 (numpy): the matrix of a blade times the
   matrix of another is s(a,b) times the matrix of the xor label, with the same sign s as the bit rule.
chn.2 (ATL-001b).  In every cell (p,q,r) with p + q + r <= 6, in every order of its generators (1093 sign patterns, 84 cells): the label 0 multiplies every label with sign +1 from both sides,
   so R.1 = Cl(0,0) sits in each cell as its unit and in its centre; for every n the sign of the empty label is an empty product (one line).
   [std] the left-regular matrices (numpy, n <= 5, three cells per n): L_0 is the identity and commutes with every L_a.
chn.3 (ATL-002b).  (a) In Cl(1,1) the null pair n = (e1 + e2)/2, n~ = (e1 - e2)/2 has n^2 = n~^2 = 0, n n~ + n~ n = 1, and e = n + n~,
   f = n - n~ square to +1 and -1 and anticommute: span{1, e} is a copy of Cl(1,0) (idempotents (1 +- e)/2), span{1, f} of Cl(0,1).
   (b) For the unital algebras with basis {1, x}, x^2 = a + b x, every change of generator x' = alpha x + beta (alpha != 0) multiplies
   D = b^2 + 4a by alpha^2 (the bit-rule products in Cl(1,0), Cl(0,1), Cl(0,0,1) on a grid of rational alpha, beta, against the closed
   form a' = alpha^2 a - alpha beta b - beta^2, b' = alpha b + 2 beta); D = 4, -4, 0 for the three cells; every copy of Cl(0,0,1) has D = 0,
   D is continuous in (a, b), so no limit of copies of Cl(0,0,1) is Cl(1,0): Cl(1,0) is not a contraction of the null seed.  The other way
   round it is: x_t = t e has x_t^2 = t^2 -> 0.  As a deformation of the square (x^2 = s^2 > 0) the null seed does reach Cl(1,0): x/s squares
   to +1.  (c) Non-isomorphism: on the grid u, v in {k/4 : |k| <= 8} the idempotents of Cl(1,0) are 0, 1, (1 +- e)/2 and it has no nonzero
   nilpotent; Cl(0,0,1) has only the idempotents 0, 1 and the nilpotents v eps.
   [bit] BR((1,-1)), BR((1,)), BR((-1,)), BR((0,)), Fractions.  [std] 2x2 real matrices (n = E12, n~ = E21; dual numbers as [[u, v], [0, u]]).
chn.4 (PAG-019).  In Cl(1,3) (e_t^2 = +1, space -1) with exact polynomial fields: for three random integer quadratic vector potentials A
   (grade 1, an odd field by definition), the vector derivative of A has grades 0 and 2 only (even), F = grad ^ A is grade 2, and grad F has
   grade 1 only (its grade-3 part grad ^ F vanishes identically): J = grad F is odd; for 20 random integer even psi the current psi e_t psi~
   has grade 1 only (odd); the tetrad e (vector-valued) is grade 1 by definition (odd).
   [bit] BR((1,-1,-1,-1)) on polynomial coefficients, exact.  [std] F^(mu nu) = d^mu A^nu - d^nu A^mu and J^nu = d_mu F^(mu nu) by index
   formulas (no bit rule), and the current by the 4x4 complex Dirac matrices with the trace projection onto the 16 blades (numerical, 1e-9).
Controls ([ctl]; each --fault puts the wrong version in the main lines, which must then FAIL):
   OR the product label a or b in place of a xor b (the edge and xor lines fail); TOPBIT the grade read as the highest bit (the C(n,k) counts
   fail); UNITSIGN the empty label given the sign -1 against odd labels (not a unit); NOFACTOR4 D = b^2 + a in place of b^2 + 4a (not
   invariant); NOPAIR the two null generators of the Grassmann cell Cl(0,0,2) in place of the pair (n n~ + n~ n = 0: e^2 = 0, no face of
   square +1); MIXEDPSI an odd part added to psi (the current gains grades 0 or 4); A2 a grade-2 piece added to A (grad A gains odd grades).
Scope: as stated per item.  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen by this script;
its controls are the faults above.
Command: python3 chain_labels.py   (from this folder, or python3 selfcheck/proofs/chain_labels.py from the package root; standard library,
numpy)."""
import os, sys, itertools, random
from fractions import Fraction as Fr
from math import comb
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_researchers = os.path.join(os.path.dirname(os.path.dirname(_here)), 'researchers_checks')
if not os.path.isfile(os.path.join(_researchers, 'bitrule_A.py')): raise SystemExit('bitrule_A.py not found in ' + _researchers + ': this file belongs in selfcheck/proofs/ of the package')
if _researchers not in sys.path: sys.path.insert(0, _researchers)
from bitrule_A import BR

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('OR', 'TOPBIT', 'UNITSIGN', 'NOFACTOR4', 'NOPAIR', 'MIXEDPSI', 'A2')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')

def bmul(A, a, b):
    """one blade product: (sign, label); the OR fault puts the label a | b"""
    s = A.s(a, b)
    return s, ((a | b) if FAULT == 'OR' else (a ^ b))
def grade_of(a): return a.bit_length() if FAULT == 'TOPBIT' else pc(a)
def cells(n): return itertools.product((1, -1, 0), repeat=n)

# ================================================================================================ chn.1  blades, corners, labels
head('chn.1  blades as cube corners and labels (PAG-002b)')
ok_prod = ok_cnt = ok_edge = ok_xor = ok_sub = True; ncell = 0
for n in range(0, 9):
    pats = list(cells(n)) if n <= 4 else [(1,) * n]
    for eps in pats:
        A = BR(eps); ncell += 1
        seen = {}
        for k in range(n + 1):
            for S in itertools.combinations(range(n), k):
                sgn, lab = 1, 0
                for i in S:
                    s_, lab = bmul(A, lab, 1 << i); sgn *= s_
                seen.setdefault(lab, []).append(sgn)
        ok_prod &= sorted(seen) == list(range(1 << n)) and all(len(v) == 1 and v[0] in (1, -1) for v in seen.values())
        if eps == (1,) * n:
            byg = [sum(1 for a in range(1 << n) if grade_of(a) == k) for k in range(n + 1)]
            corners = [sum(1 for v in itertools.product((0, 1), repeat=n) if sum(v) == k) for k in range(n + 1)]
            faces = [len(list(itertools.combinations(range(n), k))) for k in range(n + 1)]
            ok_cnt &= byg == corners == faces == [comb(n, k) for k in range(n + 1)]
        edges = set(); hits = 0
        for a in range(1 << n):
            for i in range(n):
                s_, lab = bmul(A, 1 << i, a)
                null_hit = eps[i] == 0 and (a >> i & 1)
                ok_edge &= pc(lab ^ a) == 1 and ((s_ == 0) if null_hit else (s_ in (1, -1)))
                edges.add(frozenset((a, lab))); hits += 1
        ok_edge &= len(edges) == n * (1 << (n - 1) if n else 0) and hits == 2 * len(edges)
        if n <= 6:
            for a in range(1 << n):
                for b in range(1 << n):
                    s_, lab = bmul(A, a, b)
                    zero = any(eps[i] == 0 for i in range(n) if (a & b) >> i & 1)
                    ok_xor &= (s_ == 0) if zero else (s_ in (1, -1) and lab == a ^ b)
                    if b & a == b:
                        s2, lab2 = bmul(A, b, a ^ b); ok_sub &= s2 in (1, -1) and lab2 == a
chk('bit', ok_prod, 'chn.1a: in %d cells (every pattern of squares +1, -1, 0 for n <= 4, Cl(n,0) for n = 5..8) the 2^n ordered products of distinct generators are +-1 times the 2^n blades, each label once' % ncell)
chk('bit', ok_cnt, 'chn.1b: n = 0..8: C(n,k) blades of grade k (grade = popcount) = corners of the n-cube of weight k = faces of the (n-1)-simplex with k vertices (three separate enumerations)')
chk('bit', ok_edge, 'chn.1c: e_i e_a = +- e_(a xor 2^i) (0 exactly when e_i is null and i is in a): a generator moves a label along an edge of the cube; n 2^(n-1) edges, each met from both ends (every cell above)')
okc_or = any(pc(((1 << i) | a) ^ a) != 1 for a in range(8) for i in range(3))
chk('ctl', okc_or, 'chn.1g: a wrong product label, a or b in place of a xor b, does not move a label along an edge (e_i e_a would keep the label when i is in a): it fails (n = 3)')
chk('bit', ok_xor and ok_sub, 'chn.1d: e_a e_b = s(a,b) e_(a xor b), s = +-1 unless a and b share a null generator (then 0); for every sub-label b of a, e_b e_(a xor b) = +- e_a (n <= 6, every cell above)')

def gammas(n):
    X = np.array([[0, 1], [1, 0]], dtype=complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1, -1]).astype(complex); I2 = np.eye(2, dtype=complex)
    m = (n + 1) // 2; G = []
    for k in range(n):
        j, w = divmod(k, 2); fs = [Z] * j + [X if w == 0 else Y] + [I2] * (m - j - 1)
        M = fs[0]
        for f in fs[1:]: M = np.kron(M, f)
        G.append(M)
    return G
ok_mat = True
for n in range(1, 7):
    G = gammas(n); A = BR((1,) * n); dim = G[0].shape[0]
    Gb = []
    for a in range(1 << n):
        M = np.eye(dim, dtype=complex)
        for i in range(n):
            if a >> i & 1: M = M @ G[i]
        Gb.append(M)
    for a in range(1 << n):
        for b in range(1 << n):
            s_, lab = bmul(A, a, b)
            ok_mat &= np.allclose(Gb[a] @ Gb[b], s_ * Gb[lab], atol=1e-12)
chk('std', ok_mat, 'chn.1e: Kronecker gamma matrices of Cl(n,0), n = 1..6: the matrix of e_a times the matrix of e_b is s(a,b) times the matrix of e_(a xor b), for all 4^n pairs')
chk('bit==std', ok_mat and ok_xor, 'chn.1f: the sign and the label of every blade product agree between the bit rule and the matrices (Cl(n,0), n <= 6)')

# ================================================================================================ chn.2  the unit of every cell
head('chn.2  R.1 = Cl(0,0) as the unit of every cell (ATL-001b)')
def s_unit(A, a, b):
    s_ = A.s(a, b)
    if FAULT == 'UNITSIGN' and (a == 0 or b == 0) and pc(a | b) % 2 == 1: s_ = -s_
    return s_
ok_unit = True; nc = 0
for n in range(0, 7):
    for eps in cells(n):
        A = BR(eps); nc += 1
        ok_unit &= all(s_unit(A, 0, a) == 1 and s_unit(A, a, 0) == 1 for a in range(1 << n))
chk('bit', ok_unit and nc == 1093, 'chn.2a: in all %d sign patterns of squares +1, -1, 0 on at most six generators (every cell (p,q,r) with p + q + r <= 6, in every order of its generators), e_0 e_a = e_a e_0 = e_a for every label a: R.1 = Cl(0,0) is the unit of each cell and lies in its centre' % nc)
def left_regular(A):
    N = 1 << A.n; L = []
    for a in range(N):
        M = np.zeros((N, N))
        for b in range(N):
            s_ = s_unit(A, a, b)
            if s_: M[a ^ b, b] = s_
        L.append(M)
    return L
ok_lr = True
for n in range(1, 6):
    for eps in ((1,) * n, (1,) + (-1,) * (n - 1), (0,) + (1,) * (n - 1)):
        L = left_regular(BR(eps)); I = np.eye(1 << n)
        ok_lr &= np.array_equal(L[0], I) and all(np.array_equal(L[0] @ M, M @ L[0]) for M in L)
chk('std', ok_lr, 'chn.2b: left-regular matrices (n = 1..5; Euclidean, Lorentzian and one degenerate cell per n): L_0 is the identity matrix and commutes with every L_a')
badA = BR((1, 1)); bad = any(((-1 if pc(a) % 2 else 1) * badA.s(0, a)) != 1 for a in range(4))
chk('ctl', bad, 'chn.2d: a wrong sign rule that gives the empty label the sign -1 against odd labels is not a unit: it fails')
chk('bit==std', ok_unit and ok_lr, 'chn.2c: the unit seen by the sign rule and by the matrices is the same element, label 0; for every n the sign of the empty label is an empty product, +1 (one line)')

# ================================================================================================ chn.3  signed faces of a fused pair
head('chn.3  a signed face of a fused pair, not a contraction of a lone null generator (ATL-002b)')
def mv_mul(A, x, y): return A.mul(x, y)
def mv_add(*xs):
    out = {}
    for x in xs:
        for k, v in x.items(): out[k] = out.get(k, 0) + v
    return {k: v for k, v in out.items() if v != 0}
def sc(x, c): return {k: c * v for k, v in x.items() if c * v != 0}
h = Fr(1, 2)
if FAULT == 'NOPAIR':
    P = BR((0, 0)); nn = {1: Fr(1)}; nt = {2: Fr(1)}
else:
    P = BR((1, -1)); nn = {1: h, 2: h}; nt = {1: h, 2: -h}
one = {0: Fr(1)}
n2, nt2 = mv_mul(P, nn, nn), mv_mul(P, nt, nt)
anti = mv_add(mv_mul(P, nn, nt), mv_mul(P, nt, nn))
e_ = mv_add(nn, nt); f_ = mv_add(nn, sc(nt, -1))
e2, f2 = mv_mul(P, e_, e_), mv_mul(P, f_, f_); ef = mv_add(mv_mul(P, e_, f_), mv_mul(P, f_, e_))
idem = [sc(mv_add(one, sc(e_, s_)), h) for s_ in (1, -1)]
ok_face = n2 == {} and nt2 == {} and anti == one and e2 == one and f2 == sc(one, -1) and ef == {} and all(mv_mul(P, p_, p_) == p_ for p_ in idem)
chk('bit', ok_face, 'chn.3a: Cl(1,1): n = (e1 + e2)/2, n~ = (e1 - e2)/2 have n^2 = n~^2 = 0 and n n~ + n~ n = 1; e = n + n~ squares to +1, f = n - n~ to -1, ef + fe = 0; (1 +- e)/2 are idempotents: span{1, e} is a copy of Cl(1,0), span{1, f} of Cl(0,1)')
Nm = np.array([[0., 1.], [0., 0.]]); Nt = np.array([[0., 0.], [1., 0.]])
if FAULT == 'NOPAIR': Nt = Nm.copy()
Em, Fm = Nm + Nt, Nm - Nt
ok_face_std = np.allclose(Nm @ Nm, 0) and np.allclose(Nt @ Nt, 0) and np.allclose(Nm @ Nt + Nt @ Nm, np.eye(2)) and np.allclose(Em @ Em, np.eye(2)) and np.allclose(Fm @ Fm, -np.eye(2))
chk('std', ok_face_std, 'chn.3b: 2x2 real matrices n = E12, n~ = E21: the same relations; n + n~ = [[0,1],[1,0]] (eigenvalues +1, -1), n - n~ = [[0,1],[-1,0]] (square -1)')
def disc(a, b): return b * b + a if FAULT == 'NOFACTOR4' else b * b + 4 * a
grid = [Fr(k, d) for k in range(-3, 4) for d in (1, 2, 3)]
grid = sorted(set(grid))
ok_d = ok_d_std = True; Dvals = {}
for name, eps in (('Cl(1,0)', (1,)), ('Cl(0,1)', (-1,)), ('Cl(0,0,1)', (0,))):
    C1 = BR(eps); x = {1: Fr(1)}; x2 = mv_mul(C1, x, x); a0, b0 = x2.get(0, Fr(0)), x2.get(1, Fr(0)); Dvals[name] = disc(a0, b0)
    for al in grid:
        if al == 0: continue
        for be in grid:
            xp = mv_add(sc(x, al), sc(one, be)); xp2 = mv_mul(C1, xp, xp)
            c0, c1 = xp2.get(0, Fr(0)), xp2.get(1, Fr(0)); bp = c1 / al; ap = c0 - bp * be
            ok_d &= disc(ap, bp) == al * al * disc(a0, b0)
            ok_d_std &= (ap, bp) == (al * al * a0 - al * be * b0 - be * be, al * b0 + 2 * be)
chk('bit', ok_d and Dvals == {'Cl(1,0)': 4, 'Cl(0,1)': -4, 'Cl(0,0,1)': 0}, 'chn.3c: x^2 = a + b x; for %d changes of generator x\' = alpha x + beta (rational grid) the bit-rule product gives D\' = alpha^2 D, D = b^2 + 4a; D = 4, -4, 0 for Cl(1,0), Cl(0,1), Cl(0,0,1)' % (len(grid) * (len(grid) - 1)))
chk('std', ok_d_std, 'chn.3d: the structure constants of x\' read from the bit-rule products equal the closed form a\' = alpha^2 a - alpha beta b - beta^2, b\' = alpha b + 2 beta (all three cells, every grid point)')
ts = [Fr(1, 2 ** k) for k in range(11)]
C10 = BR((1,)); C001 = BR((0,))
contr = all(mv_mul(C10, {1: t}, {1: t}) == {0: t * t} for t in ts)
deform = all(mv_mul(BR((s_ * s_,)), {1: 1 / s_}, {1: 1 / s_}) == {0: Fr(1)} and disc(s_ * s_, 0) > 0 for s_ in ts)   # x^2 = s^2: x/s squares to +1
orbit0 = all(disc(-be * be, 2 * be) == 0 for be in grid)
chk('bit', contr and orbit0 and ok_d, 'chn.3e: every copy of Cl(0,0,1) has D = 0 (orbit: a\' = -beta^2, b\' = 2 beta), D is continuous, so no limit of copies of Cl(0,0,1) is Cl(1,0) (D = 4 alpha^2 > 0): Cl(1,0) is not a contraction of the null seed; the converse contraction exists, x_t = t e, x_t^2 = t^2 -> 0 (t = 2^-k, k <= 10)')
chk('bit', deform, 'chn.3f: as a deformation of the square, x^2 = t = s^2 > 0 (s = 2^-k, k <= 10, the cell with square t), the null seed does reach Cl(1,0): D = 4t > 0 and x/s squares to +1 (so the reading holds for contraction, not for deformation)')
gq = [Fr(k, 4) for k in range(-8, 9)]
def idem_nil(eps):
    C1 = BR(eps); I_, N_ = [], []
    for u in gq:
        for v in gq:
            z = {k: c for k, c in ((0, u), (1, v)) if c != 0}; z2 = mv_mul(C1, z, z)
            if z2 == z: I_.append((u, v))
            if z2 == {} and z != {}: N_.append((u, v))
    return I_, N_
I10, N10 = idem_nil((1,)); I001, N001 = idem_nil((0,))
ok_iso = sorted(I10) == sorted([(Fr(0), Fr(0)), (Fr(1), Fr(0)), (h, h), (h, -h)]) and N10 == [] and sorted(I001) == [(Fr(0), Fr(0)), (Fr(1), Fr(0))] and len(N001) == 16 and all(u == 0 for u, v in N001)
chk('bit', ok_iso, 'chn.3g: on the grid u, v in {k/4 : |k| <= 8}: Cl(1,0) has the idempotents 0, 1, (1 +- e)/2 and no nonzero nilpotent; Cl(0,0,1) has only 0, 1 and the 16 nilpotents v eps: not isomorphic')
Dual = lambda u, v: np.array([[u, v], [0., u]])
ok_iso_std = bool(np.linalg.matrix_rank(Dual(0, 1)) == 1 and np.allclose(Dual(0, 1) @ Dual(0, 1), 0) and np.allclose(sorted(np.linalg.eigvals(np.array([[0., 1.], [1., 0.]])).real), [-1, 1]))
chk('std', ok_iso_std, 'chn.3h: matrices: the dual numbers [[u, v], [0, u]] contain the nonzero nilpotent [[0,1],[0,0]]; the generator of Cl(1,0), [[0,1],[1,0]], is diagonalisable with eigenvalues +1, -1 (R + R)')
wrong_inv = any((2 * be) ** 2 + (al * al - be * be) != al * al * 1 for al in grid if al for be in grid)
Gr = BR((0, 0)); gx, gy = {1: Fr(1)}, {2: Fr(1)}
grass = mv_add(mv_mul(Gr, gx, gy), mv_mul(Gr, gy, gx)) == {} and mv_mul(Gr, mv_add(gx, gy), mv_add(gx, gy)) == {}
chk('ctl', wrong_inv and grass, 'chn.3i: wrong versions fail: b^2 + a is not invariant under x\' = alpha x + beta (Cl(1,0)); two null generators without a pairing (Cl(0,0,2)) anticommute to 0 and their sum squares to 0, so no face of square +1')

# ================================================================================================ chn.4  grade parity of fields and sources
head('chn.4  even fields and odd sources: F and J, psi and its current; A and e odd (PAG-019)')
STA = BR((1, -1, -1, -1)); ETA = (1, -1, -1, -1)
def padd(p, q, c=1):
    out = dict(p)
    for k, v in q.items(): out[k] = out.get(k, 0) + c * v
    return {k: v for k, v in out.items() if v != 0}
def pder(p, mu):
    out = {}
    for k, v in p.items():
        if k[mu]:
            kk = list(k); kk[mu] -= 1; out[tuple(kk)] = out.get(tuple(kk), 0) + v * k[mu]
    return {k: v for k, v in out.items() if v != 0}
def rand_poly(rng):
    mons = [m for m in itertools.product(range(3), repeat=4) if sum(m) <= 2]
    return {m: rng.randint(-4, 4) for m in mons if rng.random() < 0.6}
def nabla(Fd):
    """grad F = sum_mu e^mu d_mu F with e^mu = eta_mu e_mu; F a dict label -> polynomial"""
    out = {}
    for mu in range(4):
        for a, p in Fd.items():
            dp = pder(p, mu)
            if not dp: continue
            s_ = STA.s(1 << mu, a) * ETA[mu]; lab = (1 << mu) ^ a
            out[lab] = padd(out.get(lab, {}), dp, s_)
    return {k: v for k, v in out.items() if v}
rng = random.Random(20261013)
ok_dA = ok_F = ok_J = ok_std = True
for trial in range(3):
    Acomp = [rand_poly(rng) for _ in range(4)]
    Ad = {1 << mu: Acomp[mu] for mu in range(4) if Acomp[mu]}
    if FAULT == 'A2': Ad[0b0011] = rand_poly(rng) or {(1, 0, 0, 0): 1}
    dA = nabla(Ad)
    ok_dA &= all(pc(a) in (0, 2) for a in dA)
    Fd = {a: p for a, p in dA.items() if pc(a) == 2}
    J = nabla(Fd)
    ok_F &= all(pc(a) == 2 for a in Fd) and len(Fd) > 0
    ok_J &= all(pc(a) == 1 for a in J) and len(J) > 0
    # [std] index formulas: F^{mu nu} = d^mu A^nu - d^nu A^mu, J^nu = d_mu F^{mu nu}
    Fup = {}
    for mu in range(4):
        for nu in range(4):
            Fup[(mu, nu)] = padd({k: ETA[mu] * v for k, v in pder(Acomp[nu], mu).items()}, {k: ETA[nu] * v for k, v in pder(Acomp[mu], nu).items()}, -1)
    for mu in range(4):
        for nu in range(mu + 1, 4):
            lab = (1 << mu) | (1 << nu)
            ok_std &= Fd.get(lab, {}) == Fup[(mu, nu)]
    for nu in range(4):
        Jn = {}
        for mu in range(4): Jn = padd(Jn, pder(Fup[(mu, nu)], mu))
        ok_std &= J.get(1 << nu, {}) == Jn
chk('bit', ok_dA, 'chn.4a: three random integer quadratic potentials A (grade 1): grad A has grades 0 and 2 only (the derivative of an odd field is even)')
chk('bit', ok_F and ok_J, 'chn.4b: F = grad ^ A is grade 2 (even) and J = grad F has grade 1 only: its grade-3 part grad ^ F vanishes identically (exact polynomials)')
chk('std', ok_std, 'chn.4c: index route: F^(mu nu) = d^mu A^nu - d^nu A^mu equals the coefficient of e_mu e_nu, and J^nu = d_mu F^(mu nu) the coefficient of e_nu (Maxwell d_mu F^(mu nu) = J^nu)')
def rev_sign(a): k = pc(a); return -1 if (k * (k - 1) // 2) % 2 else 1
EVEN = [a for a in range(16) if pc(a) % 2 == 0]; ODD = [a for a in range(16) if pc(a) % 2 == 1]
g0 = np.diag([1, 1, -1, -1]).astype(complex)
sx = np.array([[0, 1], [1, 0]], dtype=complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.diag([1, -1]).astype(complex); Z2 = np.zeros((2, 2), dtype=complex)
gk = [np.block([[Z2, s], [-s, Z2]]) for s in (sx, sy, sz)]
GD = [g0] + gk
Gm = []
for a in range(16):
    M = np.eye(4, dtype=complex)
    for i in range(4):
        if a >> i & 1: M = M @ GD[i]
    Gm.append(M)
Ginv = [np.linalg.inv(M) for M in Gm]
ok_cur = ok_cur_std = True
for trial in range(20):
    psi = {a: Fr(rng.randint(-5, 5)) for a in EVEN}
    if FAULT == 'MIXEDPSI': psi.update({a: Fr(rng.randint(1, 5)) for a in ODD[:2]})
    psi = {k: v for k, v in psi.items() if v != 0}
    psit = {a: v * rev_sign(a) for a, v in psi.items()}
    j = STA.mul(STA.mul(psi, {1: Fr(1)}), psit)
    ok_cur &= all(pc(a) == 1 for a in j) and len(j) > 0
    P_ = sum(float(v) * Gm[a] for a, v in psi.items()); Pt = sum(float(v) * Gm[a] for a, v in psit.items())
    X = P_ @ g0 @ Pt
    coef = {a: np.trace(Ginv[a] @ X) / 4 for a in range(16)}
    ok_cur_std &= all(abs(coef[a] - float(j.get(a, 0))) < 1e-9 for a in range(16))
chk('bit', ok_cur, 'chn.4d: 20 random integer even psi: the current psi e_t psi~ has grade 1 only (odd); psi itself is even')
chk('std', ok_cur_std, 'chn.4e: 4x4 complex Dirac matrices (gamma_0 = diag(1,1,-1,-1), gamma_k off-diagonal Pauli): the trace projection of Psi gamma_0 Psi~ onto the 16 blades equals the bit-rule current (numerical, 1e-9)')
psim = {0: Fr(1), 1: Fr(1)}; jm = STA.mul(STA.mul(psim, {1: Fr(1)}), {a: v * rev_sign(a) for a, v in psim.items()})
Am = nabla({1: {(0, 1, 0, 0): 1}, 0b0011: {(1, 0, 0, 0): 1}})
chk('ctl', any(pc(a) in (0, 4) for a in jm) and any(pc(a) % 2 == 1 for a in Am), 'chn.4g: wrong versions fail: psi = 1 + e_t (an odd part) gives a current with a grade-0 part; a potential with a grade-2 piece has a derivative with odd grades')
chk('bit==std', ok_std and ok_cur_std, 'chn.4f: both routes give the same F, J and current; A and the tetrad e are vector-valued (grade 1) by definition: odd fields, so the reading "even fields, odd sources" holds of F, J, psi, its current, and not of A or e')

finish('CHAIN-LABELS')
