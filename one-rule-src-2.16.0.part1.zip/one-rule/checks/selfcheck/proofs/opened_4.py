#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""opened_4.py: four statements on the labels, each computed by the bit rule and by a route that never touches it.
    python3 opened_4.py [--fault GRADEINV|FLIP|TWOBITS|NOFLOOR]

OPEN-CUR (opn.CUR).  For an even psi of Cl(1,n-1) with independent components, the current X = psi gamma_0 psi~ is odd and equal to
   its own reverse, so its grades are the k <= n with k = 1 mod 4: a vector for n <= 4, a grade-5 part from n = 5, a grade-9 part from
   n = 9, and every blade of these grades occurs (C(n,5) of grade 5).
   [bit]  BR(eps) of researchers_checks/bitrule_A.py: the coefficient of the blade S^1^T in e_S gamma_0 (e_T)~ for every pair of even
          masks, summed into quadratic forms in the components; n = 1..10 for Cl(1,n-1), every signature p + q = n <= 8; the reverse of
          every blade as the product of its generators in the opposite order; the page script's own product
          (coupling_selfcheck.current_structure, n <= 8) and the stored coupling.json give the same forms and counts.
   [std]  Jordan-Wigner gamma matrices (Pauli strings on floor(n/2) + 1 qubits, so the 2^n products are independent), gamma_k^2 = -1 by a
          factor i; psi with random integer components (three seeds), psi~ as the same products taken in the opposite order (matrix
          products, no sign formula), X as a matrix and its blade coefficients by traces (integer entries: exact); n = 1..9.
   [ctl]  the grade involution in place of the reverse gives grade 3 (n >= 3); psi not even gives grades 0 and 4; a bivector in place of
          gamma_0 gives grades 2 and 6 (the grade of the middle factor is kept mod 4).
OPEN-FANO (opn.FANO).  The seven Fano-line blades e_a e_b e_c e_8 of Cl(0,8) (the lines of the model's octonion table) generate a group of
   32 elements, the 16 code blades with both signs; the relations among them are the seven sets of four lines that miss a point, with
   product -1 for the points 0, 2, 4, 6 and +1 for 1, 3, 5 (a line); the sign is a character of the relations; one blade's sign flipped
   moves the +1 points to another line, and for the line 1, 3, 5 leaves a group of 16 without -1; Cl(8,0) gives the same 32.
   [bit]  BR((-1,)*8): closure of the seven signed blades, the 128 subsets of lines, the products over the relations; BR((1,)*8).
   [std]  the 16 x 16 matrices of reports/furey/model.py (integer entries), their closure and products; the sign of a word of
          anticommuting generators by the parity of its inversions, plain Python.
   [ctl]  signs forgotten (the XOR closure has 16 elements); one sign flipped, each of the seven (the pattern changes); a non-line triple
          (it does not commute with the line blades).
OPEN-CONJ (opn.CONJ).  On the 32 five-bit labels (bits 2, 3, 4 colour, E_ij = a_i^+ a_j), the map from the triplet's labels (one colour bit)
   to the anti-triplet's (two colour bits) is the flip of the three colour bits, C = c_2 c_3 c_4 with c_k = a_k + a_k^+: C e_x = +-e_(x^28),
   C a_k C^-1 = a_k^+, C E_ij C^-1 = delta_ij - E_ji, C rho(X) C^-1 = rho(-X^T), b -> 3 - b; across it d_abc T_a T_b T_c changes sign
   (10/9 <-> -10/9), the quadratic Casimir (4/3) and the antisymmetric f_abc T_a T_b T_c (2i; -2 for the form kappa([X,Y],Z)) do not.
   [bit]  a_k^+ = left multiplication by e_k in BR((0,)*5) (every generator null: the exterior algebra on the five bits), a_k its
          transpose; kappa = 2 tr, D, F on the one-colour-bit labels; the Casimir operators on all 32 labels, exact integers over a
          common denominator; C as a signed permutation; every identity as an exact 32 x 32 matrix equality.
   [std]  3 x 3 integer matrices: Lambda^2 X = S (-X^T) S^-1 with S the epsilon map; numpy Gell-Mann matrices T = lambda/2 (floats).
   [ctl]  the antisymmetric cubic and the quadratic Casimir: one value on both, fixed by C; a flip of one or two colour bits does not map
          the one-colour-bit labels into one colour count; the flip of the weak bits commutes with su(3).
OPEN-WEYL (opn.WEYL).  The algebraic curvature tensors have dimension n^2(n^2-1)/12; the Ricci contraction on them has rank n(n+1)/2 for
   n >= 3 and 1 at n = 2; its kernel, the Weyl part, has dimension n(n+1)(n+2)(n-3)/12 for n >= 3 and 0 at n = 2 (the formula gives -2).
   [bit]  gravity_selfcheck.curvature_space(n) (exact, the first Bianchi identity as rows), n = 2..6; gravity.json for n = 2..7.
   [std]  the Young tableau count: semistandard tableaux of shape (2,2) with entries 1..n (that the curvature tensors are the GL(n)
          representation of this shape is recalled: Weyl's construction); numpy: the null space of the pair-symmetry and cyclic constraints
          on Lambda^2 (x) Lambda^2, the rank of the Ricci contraction, and the eigenvalues of the so(n) Casimir on that space (0 once, 2n on
          the trace-free Ricci part, 4n - 4 on the Weyl part; the names of these values are recalled), n = 2..8.
   [ctl]  the closed forms read below n = 3; the cyclic identity dropped; the column-strict condition of the tableaux dropped.
Faults: --fault NAME puts a wrong version into the main lines (GRADEINV the grade involution, FLIP the first line blade negated, TWOBITS
   the flip of bits 2 and 3 only, NOFLOOR the closed forms without their floor); each such run must exit 1.
Scope: the n, signatures and labels named above, exact except the numpy lines of OPEN-CONJ and OPEN-WEYL (floats, tolerance 1e-8).
   Nothing about nature. The script builds no Forms, Lie or Grav object of the gravity engine (it calls curvature_space), so the eight
   engine faults are silent here by construction; its controls are the [ctl] lines and the faults above. It writes nothing.
Command: python3 opened_4.py   (from this folder, or python3 selfcheck/proofs/opened_4.py from the package root; also under -I -B)."""
import os, sys, json, itertools, random, importlib.util
from fractions import Fraction as Fr
from math import comb, lcm, prod as prod_int
sys.dont_write_bytecode = True
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
SELF = os.path.dirname(HERE)                                            # selfcheck/
ROOT = os.path.dirname(SELF)                                            # the package root (checks/)
def load(name, *rel):
    p = os.path.join(ROOT, *rel)
    if not os.path.isfile(p): raise SystemExit(os.path.join(*rel) + ' not found: this file belongs in selfcheck/proofs/ of the package')
    spec = importlib.util.spec_from_file_location(name, p); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
bitrule = load('bitrule_A', 'researchers_checks', 'bitrule_A.py')
cpl = load('coupling_selfcheck', 'selfcheck', 'coupling_selfcheck.py')
gs = load('gravity_selfcheck', 'selfcheck', 'gravity_selfcheck.py')
OM = load('furey_model', 'reports', 'furey', 'model.py')
BR, comm = bitrule.BR, bitrule.comm
def stored(name):
    with open(os.path.join(SELF, name), encoding='utf8') as f: return json.load(f)

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; MARK = [0]
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def part_end(step):
    new = FAILS[MARK[0]:]; MARK[0] = len(FAILS)
    print('FAILS (%s): %s' % (step, new if new else 'none'), flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('GRADEINV', 'FLIP', 'TWOBITS', 'NOFLOOR')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
if FAULT: print('FAULT %s: a wrong version is in the main lines; this run must end with failures' % FAULT)

def pc(x): return bin(x).count('1')
def rsign(k): return -1 if (k * (k - 1) // 2) % 2 else 1                 # the reverse on a blade of grade k
def mask(t): return sum(1 << i for i in t)
def bits(m): return [i for i in range(m.bit_length()) if m >> i & 1]
def lor(n, p=1): return (1,) * p + (-1,) * (n - p)                       # Cl(p, n-p), the first p generators of square +1

# ================================================================================================ OPEN-CUR
head('OPEN-CUR (opn.CUR). The grades of the current X = psi gamma_0 psi~ for an even psi of Cl(1,n-1)')
INV = {'rev': lambda k: rsign(k), 'grade': lambda k: -1 if k % 2 else 1, 'conj': lambda k: rsign(k) * (-1 if k % 2 else 1)}
def current_forms(n, eps, mid=1, inv='rev', even=True):
    """blade B -> {(S, T) with S <= T: coefficient of psi_S psi_T in X_B}, X = psi mid inv(psi), psi = sum psi_S e_S, by the kernel's sign"""
    A = BR(eps); L = [m for m in range(1 << n) if pc(m) % 2 == 0] if even else list(range(1 << n))
    ts = {T: INV[inv](pc(T)) for T in L}; acc = {}
    for S in L:
        s1 = A.s(S, mid)
        if not s1: continue
        m1 = S ^ mid
        for T in L:
            s2 = A.s(m1, T)
            if not s2: continue
            d = acc.setdefault(m1 ^ T, {}); key = (S, T) if S <= T else (T, S); d[key] = d.get(key, 0) + s1 * s2 * ts[T]
    return {B: {k: v for k, v in d.items() if v} for B, d in acc.items() if any(d.values())}
def grades(forms): return sorted({pc(B) for B in forms})
def blades_per_grade(forms):
    out = {}
    for B in forms: out[pc(B)] = out.get(pc(B), 0) + 1
    return out
def want_cur(n): return [k for k in range(1, n + 1) if k % 4 == 1]
MAIN_INV = 'grade' if FAULT == 'GRADEINV' else 'rev'
NB = 10
FORMS = {}
for n in range(1, NB + 1):
    FORMS[n] = current_forms(n, lor(n), inv=MAIN_INV)
    g = grades(FORMS[n]); bp = blades_per_grade(FORMS[n])
    chk('bit', g == want_cur(n), 'opn.CUR n=%d, Cl(1,%d): the grades of psi gamma_0 psi~ are %s (the k <= n with k = 1 mod 4: %s)' % (n, n - 1, g, want_cur(n)))
    chk('bit', all(bp.get(k, 0) == comb(n, k) for k in want_cur(n)), 'opn.CUR n=%d: every blade of these grades occurs: %s blades (C(n,k): %s)' % (n, [bp.get(k, 0) for k in want_cur(n)], [comb(n, k) for k in want_cur(n)]))
chk('bit', all(all(pc(B) % 2 == 1 and rsign(pc(B)) == 1 for B in FORMS[n]) for n in FORMS), 'opn.CUR: every blade that occurs, n = 1..%d, is odd and fixed by the reverse (sign +1 for grade = 1 mod 4)' % NB)
ok = True
for n in range(1, 9):
    A = BR(lor(n))
    for B in range(1 << n):
        w = A.one()
        for i in reversed(bits(B)): w = A.mul(w, A.gen(i))
        ok = ok and w == {B: rsign(pc(B))}
chk('bit', ok, 'opn.CUR: the reverse of every blade of Cl(1,n-1), n = 1..8, taken as the product of its generators in the opposite order by the kernel, is (-1)^(k(k-1)/2) e_B')
ok = all(current_forms(n, lor(n), inv='conj') == FORMS[n] for n in range(1, 9))
chk('bit', ok, 'opn.CUR: Clifford conjugation in place of the reverse gives the same forms for even psi, n = 1..8 (they agree on the even half)')
ok = True; seen = []
for n in range(1, 9):
    for p in range(0, n + 1):
        g = grades(current_forms(n, lor(n, p), inv=MAIN_INV)); ok = ok and g == want_cur(n); seen.append((n, p))
chk('bit', ok, 'opn.CUR: the same grades in every signature Cl(p,n-p), p = 0..n, n = 1..8 (%d cells; gamma_0 the generator of bit 0)' % len(seen))
cs = stored('coupling.json')['ladder']
ok_page = all(cpl.current_structure(n, 1) == FORMS[n] for n in range(1, 9))
chk('bit', ok_page, "opn.CUR: the page script's own product, coupling_selfcheck.current_structure(n, 1), gives the same quadratic forms, n = 1..8")
ok_st = all(cs[str(n)]['current_grades'] == grades(FORMS[n]) and cs[str(n)]['current_blades'] == {str(k): v for k, v in blades_per_grade(FORMS[n]).items()}
            and cs[str(n)]['current_monomials'] == {str(k): sum(len(v) for B, v in FORMS[n].items() if pc(B) == k) for k in grades(FORMS[n])} for n in range(1, 9))
chk('bit', ok_st, 'opn.CUR: the stored coupling.json (grades, blades and monomials per grade, n = 1..8) equals these counts: %s' % ['%d:%s' % (n, cs[str(n)]['current_blades']) for n in (5, 6, 7, 8)])
# [std] Jordan-Wigner gamma matrices
PX = np.array([[0, 1], [1, 0]], dtype=complex); PY = np.array([[0, -1j], [1j, 0]]); PZ = np.diag([1, -1]).astype(complex); P1 = np.eye(2, dtype=complex)
def kron_all(ms):
    M = ms[0]
    for q in ms[1:]: M = np.kron(M, q)
    return M
def gammas(n, p=1):
    m = n // 2 + 1; G = []
    for j in range(m):
        for P in (PX, PY): G.append(kron_all([PZ] * j + [P] + [P1] * (m - j - 1)))
    return [G[k] if k < p else 1j * G[k] for k in range(n)], 2 ** m
def prod(ms, d):
    M = np.eye(d, dtype=complex)
    for q in ms: M = M @ q
    return M
STD = {}
ok_alg = True; ok_int = True; ok_rev = True; ok_sym = True; ok_eq = True; ok_bladerev = True; gr_std = {}
for n in range(1, 10):
    g, d = gammas(n); sq = lor(n); I = np.eye(d, dtype=complex)
    ok_alg = ok_alg and all(np.array_equal(g[i] @ g[i], sq[i] * I) for i in range(n)) and all(np.array_equal(g[i] @ g[j], -g[j] @ g[i]) for i in range(n) for j in range(i))
    gB = {B: prod([g[i] for i in bits(B)], d) for B in range(1 << n)}
    gR = {B: prod([g[i] for i in reversed(bits(B))], d) for B in range(1 << n)}
    gI = {B: prod([sq[i] * g[i] for i in reversed(bits(B))], d) for B in range(1 << n)}       # the inverse: gamma_i^-1 = eps_i gamma_i
    ok_bladerev = ok_bladerev and all(np.array_equal(gR[B], rsign(pc(B)) * gB[B]) for B in gB)
    ev = [m for m in range(1 << n) if pc(m) % 2 == 0]; found = set()
    for seed in (1, 2, 3):
        rng = random.Random(1000 * n + seed); c = {S: rng.randint(-50, 50) for S in ev}
        psi = sum(c[S] * gB[S] for S in ev); psit = sum(c[S] * gR[S] for S in ev)
        X = psi @ gB[1] @ (psit if MAIN_INV == 'rev' else psi)
        x = {}
        for B in range(1 << n):
            t = np.trace(gI[B] @ X) / d; xr = int(round(t.real)); ok_int = ok_int and t.imag == 0 and t.real == xr; x[B] = xr
        ok_sym = ok_sym and np.array_equal(sum(x[B] * gR[B] for B in x), X)
        ok_rev = ok_rev and np.array_equal(sum(x[B] * gB[B] for B in x), X)
        found |= {pc(B) for B in x if x[B]}
        bitval = {B: sum(v * c[S] * c[T] for (S, T), v in FORMS[n].get(B, {}).items()) for B in range(1 << n)}
        ok_eq = ok_eq and bitval == x
    gr_std[n] = sorted(found)
chk('std', ok_alg, 'opn.CUR: Jordan-Wigner matrices on floor(n/2)+1 qubits: gamma_0^2 = +1, gamma_k^2 = -1, anticommuting, n = 1..9')
chk('std', ok_bladerev, 'opn.CUR: the reverse of each blade matrix (its generators multiplied in the opposite order) is + itself for grades 0, 1 mod 4 and - itself for 2, 3 mod 4: the odd grades it fixes are 1, 5, 9, n = 1..9')
chk('std', ok_int and ok_rev, 'opn.CUR: X = psi gamma_0 psi~ (psi~ the products in the opposite order) has integer blade coefficients by traces, and they rebuild X, n = 1..9, three random integer psi each')
chk('std', ok_sym, 'opn.CUR: the matrix X equals its own reverse (the blades of X multiplied in the opposite order), n = 1..9')
chk('std', all(gr_std[n] == want_cur(n) for n in gr_std), 'opn.CUR: the grades with a non-zero coefficient: n = 4: %s, n = 5: %s, n = 8: %s, n = 9: %s (every n = 1..9 as above)' % (gr_std[4], gr_std[5], gr_std[8], gr_std[9]))
chk('bit==std', ok_eq, 'opn.CUR: every blade coefficient of X at the three sample points equals the quadratic forms of the labels, exactly, n = 1..9')
# controls
gi = {n: grades(current_forms(n, lor(n), inv='grade' if MAIN_INV == 'rev' else 'rev')) for n in range(1, 9)}
chk('ctl', all(3 in gi[n] and gi[n] != want_cur(n) for n in range(3, 9)) and all(gi[n] == [1] for n in (1, 2)),
    'opn.CUR: a wrong involution, the grade involution in place of the reverse (psi gamma_0 psi for even psi), gives other grades: n = 3: %s, n = 4: %s, n = 5: %s, n = 8: %s' % (gi[3], gi[4], gi[5], gi[8]))
ga = {n: grades(current_forms(n, lor(n), inv='rev', even=False)) for n in range(3, 7)}
chk('ctl', all(0 in ga[n] and (n < 4 or 4 in ga[n]) and ga[n] == [k for k in range(n + 1) if k % 4 in (0, 1)] for n in ga),
    'opn.CUR: psi not even (all 2^n components) gives the grades = 0, 1 mod 4: n = 4: %s, n = 6: %s: the even half is needed' % (ga[4], ga[6]))
gb = {n: grades(current_forms(n, lor(n), mid=3, inv='rev')) for n in range(2, 9)}
chk('ctl', all(gb[n] == [k for k in range(n + 1) if k % 4 == 2] for n in gb),
    'opn.CUR: a bivector e_0 e_1 in place of gamma_0 gives the grades = 2 mod 4: n = 5: %s, n = 8: %s: the sandwich keeps the grade of its middle factor mod 4' % (gb[5], gb[8]))
part_end('OPEN-CUR')

# ================================================================================================ OPEN-FANO
head('OPEN-FANO (opn.FANO). The group generated by the seven Fano-line blades of the 8-bit code')
E8, omul, Lmat, blk, I8, I16, Z8 = OM.E, OM.omul, OM.Lmat, OM.blk, OM.I8, OM.I16, OM.Z
units = [E8[m] for m in range(1, 8)]
lines = []
for a in range(7):
    for b in range(a + 1, 7):
        pr = omul(units[a], units[b]); c = int(np.argmax(abs(pr))) - 1
        if c > b: lines.append((a, b, c))
LM = [mask(l + (7,)) for l in lines]
chk('std', lines == [(0, 1, 2), (0, 3, 4), (0, 5, 6), (1, 3, 5), (1, 4, 6), (2, 3, 6), (2, 4, 5)] and all(sum(1 for l in lines if set(q) <= set(l)) == 1 for q in itertools.combinations(range(7), 2)),
    'opn.FANO: the seven lines of the octonion table of the model, points 0..6 = the units e1..e7: %s; every two points lie on one line' % (lines,))
chk('std', LM == stored('dictionary.json')['code']['fano_line_tetrahedra'], 'opn.FANO: their masks with bit 7 (the eighth generator), %s, are the stored line tetrahedra of dictionary.json' % LM)
A8 = BR((-1,) * 8)
def smul(A, x, y): return (x[0] ^ y[0], x[1] * y[1] * A.s(x[0], y[0]))
def closure(A, gens):
    G = {(0, 1)}; fr = [(0, 1)]
    while fr:
        nx = []
        for x in fr:
            for gg in gens:
                y = smul(A, x, gg)
                if y not in G: G.add(y); nx.append(y)
        fr = nx
    return G
def line_signs(A, signs):
    """the product over the four lines that miss each point, and the relations: subsets of lines whose masks XOR to 0"""
    gens = [(m, s) for m, s in zip(LM, signs)]; rel = {}
    for U in range(128):
        x = (0, 1)
        for j in range(7):
            if U >> j & 1: x = smul(A, x, gens[j])
        if x[0] == 0: rel[U] = x[1]
    miss = [rel.get(mask([j for j in range(7) if p not in lines[j]])) for p in range(7)]
    return gens, rel, miss
SIGNS = [-1] + [1] * 6 if FAULT == 'FLIP' else [1] * 7
gens, REL, MISS = line_signs(A8, SIGNS)
G = closure(A8, gens); SL = sorted({m for m, s in G})
chk('bit', all(A8.s(m, m) == 1 for m in LM) and all(comm(A8, {m: 1}, {k: 1}) == {} for m in LM for k in LM), 'opn.FANO: the seven line blades e_a e_b e_c e_8 square to +1 and commute (BR((-1,)*8))')
chk('bit', len(G) == 32 and len(SL) == 16 and all((m, s) in G for m in SL for s in (1, -1)) and (0, -1) in G,
    'opn.FANO: they generate %d elements: the %d code blades, each with both signs; -1 is in the group' % (len(G), len(SL)))
chk('bit', sorted(pc(m) for m in SL) == [0] + [4] * 14 + [8], 'opn.FANO: the code: 1, 14 blades of grade 4 and the volume element')
relsets = {U for U in REL if U}
chk('bit', len(REL) == 8 and relsets == {mask([j for j in range(7) if p not in lines[j]]) for p in range(7)},
    'opn.FANO: of the 128 subsets of lines, %d have masks with XOR 0: the empty set and, for each point, the four lines that miss it' % len(REL))
chk('bit', MISS == [-1, 1, -1, 1, -1, 1, -1], 'opn.FANO: the product of the four line blades that miss the point p, p = 0..6: %s: -1 for 0, 2, 4, 6 (the units e1, e3, e5, e7), +1 for 1, 3, 5' % MISS)
plus = tuple(p for p in range(7) if MISS[p] == 1)
chk('bit', plus in lines and all(REL[U ^ V] == REL[U] * REL[V] for U in REL for V in REL),
    'opn.FANO: the +1 points %s form a line, and the sign is a character of the relations (the sign of U xor V is the product of the signs)' % (plus,))
A8p = BR((1,) * 8); _, _, MISSp = line_signs(A8p, SIGNS); Gp = closure(A8p, gens)
chk('bit', len(Gp) == 32 and MISSp == MISS, 'opn.FANO: in Cl(8,0) the same blades generate %d elements with the same signs %s' % (len(Gp), MISSp))
# [std] the 16 x 16 matrices of the model
gm = [np.rint(blk(Z8, Lmat(u), Lmat(u), Z8)).astype(np.int64) for u in units] + [np.rint(blk(Z8, I8, -I8, Z8)).astype(np.int64)]
Id = np.eye(16, dtype=np.int64)
chk('std', all(np.array_equal(blk(Z8, Lmat(u), Lmat(u), Z8), gm[i]) for i, u in enumerate(units)) and all(np.array_equal(gm[i] @ gm[i], -Id) for i in range(8)) and all(np.array_equal(gm[i] @ gm[j], -gm[j] @ gm[i]) for i in range(8) for j in range(i)),
    "opn.FANO: the model's eight 16 x 16 matrices have integer entries, square to -1 and anticommute: Cl(0,8)")
def mbl(m):
    M = Id.copy()
    for i in bits(m): M = M @ gm[i]
    return M
LMm = [s * mbl(m) for m, s in zip(LM, SIGNS)]
key = lambda M: M.tobytes()
GM = {key(Id): Id}; fr = [Id]
while fr:
    nx = []
    for M in fr:
        for L in LMm:
            Y = M @ L
            if key(Y) not in GM: GM[key(Y)] = Y; nx.append(Y)
    fr = nx
chk('std', len(GM) == 32 and key(-Id) in GM, 'opn.FANO: the line-blade matrices generate %d matrices, -I among them' % len(GM))
MISSm = []
for p in range(7):
    M = Id.copy()
    for j in range(7):
        if p not in lines[j]: M = M @ LMm[j]
    MISSm.append(1 if np.array_equal(M, Id) else -1 if np.array_equal(M, -Id) else 0)
chk('std', MISSm == [-1, 1, -1, 1, -1, 1, -1], 'opn.FANO: the products of the four line matrices that miss each point: %s' % MISSm)
def word_sign(word, eps):
    """the sign of a word of anticommuting generators: the parity of the swaps of distinct letters that sort it, times eps_i per pair i i"""
    w = list(word); sw = 0
    for i in range(len(w)):
        for j in range(len(w) - 1 - i):
            if w[j] > w[j + 1]: w[j], w[j + 1] = w[j + 1], w[j]; sw += 1
    s = -1 if sw % 2 else 1
    for i in set(w): s *= eps[i] ** (w.count(i) // 2)
    return s
MISSw = [word_sign([i for j in range(7) if p not in lines[j] for i in sorted(lines[j] + (7,))], (-1,) * 8) * prod_int(SIGNS[j] for j in range(7) if p not in lines[j]) for p in range(7)]
chk('std', MISSw == [-1, 1, -1, 1, -1, 1, -1], 'opn.FANO: the same signs from the parity of the sorted words of indices (plain Python): %s' % MISSw)
phi = {(m, s): s * mbl(m) for m, s in G}
chk('bit==std', len({key(M) for M in phi.values()}) == 32 and {key(M) for M in phi.values()} == set(GM) and all(np.array_equal(phi[smul(A8, x, y)], phi[x] @ phi[y]) for x in G for y in G),
    'opn.FANO: e_m with sign s -> s times the matrix of e_m maps the 32 elements one to one onto the 32 matrices and respects all 1024 products')
chk('bit==std', MISS == MISSm == MISSw, 'opn.FANO: the seven signs agree on the three routes')
# controls
xor_cl = {0}
for m in LM: xor_cl |= {x ^ m for x in xor_cl}
chk('ctl', len(xor_cl) == 16, 'opn.FANO: signs forgotten, the XOR closure of the seven masks has %d elements, not 32' % len(xor_cl))
flips = []
for j in range(7):
    sg = [1] * 7; sg[j] = -1; gj, _, mj = line_signs(A8, sg); Gj = closure(A8, gj); pj = tuple(p for p in range(7) if mj[p] == 1); flips.append((lines[j], len(Gj), pj))
ok_fl = all(f[2] != plus for f in flips) and all((f[1] == 16 and len(f[2]) == 7) if f[0] == plus else (f[1] == 32 and f[2] in lines) for f in flips)
chk('ctl', ok_fl, 'opn.FANO: one line blade negated, each of the seven: the +1 points move (%s); for the line %s all seven products are +1 and the group has %d elements, no -1'
    % ('; '.join('%s: %s' % (''.join(map(str, f[0])), ''.join(map(str, f[2]))) for f in flips if f[0] != plus), ''.join(map(str, plus)), next(f[1] for f in flips if f[0] == plus)))
nl = mask((0, 1, 3, 7))
chk('ctl', any(comm(A8, {nl: 1}, {m: 1}) != {} for m in LM), 'opn.FANO: a non-line triple (0, 1, 3) with e_8 does not commute with every line blade')
part_end('OPEN-FANO')

# ================================================================================================ OPEN-CONJ
head('OPEN-CONJ (opn.CONJ). 3 -> 3-bar as a flip of bits of the 32 five-bit labels, and the sign of the cubic Casimir across it')
A5 = BR((0,) * 5)
def creation(k):
    M = np.zeros((32, 32), dtype=np.int64)
    for x in range(32):
        for m, v in A5.mul({1 << k: 1}, {x: 1}).items(): M[m, x] = v
    return M
AD = [creation(k) for k in range(5)]; AN = [M.T.copy() for M in AD]; I32 = np.eye(32, dtype=np.int64)
chk('bit', all(np.array_equal(AN[k] @ AD[j] + AD[j] @ AN[k], I32 * (k == j)) and np.array_equal(AN[k] @ AN[j] + AN[j] @ AN[k], 0 * I32) for k in range(5) for j in range(5)),
    'opn.CONJ: a_k^+ = left multiplication by e_k in BR((0,)*5), a_k its transpose: the canonical anticommutation relations hold on the 32 labels')
def a_jw(i):                                                         # the Jordan-Wigner a_i of catw_lines.py, copied
    M = np.zeros((32, 32), dtype=np.int64)
    for x in range(32):
        if (x >> i) & 1: M[x ^ (1 << i), x] = (-1) ** pc(x & ((1 << i) - 1))
    return M
chk('bit', all(np.array_equal(AN[k], a_jw(k)) for k in range(5)), "opn.CONJ: the kernel's a_k equal the Jordan-Wigner a_k of catw_lines.py (catl.C1-C4 use those)")
COL = (2, 3, 4); OFF = [(i, j) for i in range(3) for j in range(3) if i != j]
Eop = lambda i, j: AD[COL[i]] @ AN[COL[j]]
X32 = [Eop(i, j) for (i, j) in OFF] + [Eop(0, 0) - Eop(1, 1), Eop(1, 1) - Eop(2, 2)]
bcol = lambda x: pc(x >> 2); wk = lambda x: pc(x & 3)
V3 = [x for x in range(32) if bcol(x) == 1 and wk(x) == 0]; V3b = [x for x in range(32) if bcol(x) == 2 and wk(x) == 0]
def inv_fr(Mx):
    n = len(Mx); M = [[Fr(int(Mx[i][j])) for j in range(n)] + [Fr(int(i == j)) for j in range(n)] for i in range(n)]
    for c in range(n):
        p = next(r for r in range(c, n) if M[r][c] != 0); M[c], M[p] = M[p], M[c]; iv = 1 / M[c][c]; M[c] = [x * iv for x in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0: f = M[r][c]; M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [row[n:] for row in M]
R3 = [X[np.ix_(V3, V3)] for X in X32]
tr = lambda M: int(np.trace(M))
kap = [[2 * tr(R3[a] @ R3[b]) for b in range(8)] for a in range(8)]; ki = inv_fr(kap)
Dt = {(a, b, c): 2 * tr(R3[a] @ (R3[b] @ R3[c] + R3[c] @ R3[b])) for a, b, c in itertools.product(range(8), repeat=3)}
Ft = {(a, b, c): 2 * tr((R3[a] @ R3[b] - R3[b] @ R3[a]) @ R3[c]) for a, b, c in itertools.product(range(8), repeat=3)}
def raise3(t):
    out = {k: Fr(v) for k, v in t.items()}
    for slot in range(3):
        new = {}
        for k in itertools.product(range(8), repeat=3):
            new[k] = sum((ki[k[slot]][m] * out[k[:slot] + (m,) + k[slot + 1:]] for m in range(8) if ki[k[slot]][m]), Fr(0))
        out = new
    return out
def cubic(t, ops):
    L = lcm(*[v.denominator for v in t.values()]); acc = np.zeros((32, 32), dtype=np.int64)
    for (a, b, c), v in t.items():
        if v: acc = acc + int(v * L) * (ops[a] @ ops[b] @ ops[c])
    return acc, L
def quad(ops):
    L = lcm(*[v.denominator for r in ki for v in r]); acc = np.zeros((32, 32), dtype=np.int64)
    for a in range(8):
        for b in range(8):
            if ki[a][b]: acc = acc + int(ki[a][b] * L) * (ops[a] @ ops[b])
    return acc, L
def sector_values(M, L):
    if not np.array_equal(M, np.diag(np.diag(M))): return None
    v = {}
    for x in range(32): v.setdefault(bcol(x), set()).add(Fr(int(M[x, x]), L))
    return {b: (s.pop() if len(s) == 1 else None) for b, s in sorted(v.items())}
CD, LD_ = cubic(raise3(Dt), X32); CF, LF = cubic(raise3(Ft), X32); C2, L2 = quad(X32)
vD, vF, v2 = sector_values(CD, LD_), sector_values(CF, LF), sector_values(C2, L2)
fmt = lambda v: '{%s}' % ', '.join('b=%d: %s' % (b, x) for b, x in v.items()) if v else 'not diagonal'
chk('bit', vD == {0: 0, 1: Fr(10, 9), 2: Fr(-10, 9), 3: 0}, 'opn.CONJ: the symmetrised cubic Casimir C_D (kappa = 2 tr, D = 2 tr(X{Y,Z}) on the one-colour-bit labels) per colour count: %s' % fmt(vD))
chk('bit', vF == {0: 0, 1: -2, 2: -2, 3: 0} and v2 == {0: 0, 1: Fr(4, 3), 2: Fr(4, 3), 3: 0}, 'opn.CONJ: the antisymmetric C_F (F = kappa([X,Y],Z)): %s; the quadratic C_2: %s' % (fmt(vF), fmt(v2)))
def cflip(ks):
    M = I32.copy()
    for k in ks: M = M @ (AN[k] + AD[k])
    return M
MAINK = (2, 3) if FAULT == 'TWOBITS' else COL
C = cflip(MAINK)
perm_ok = all(sum(1 for y in range(32) if C[y, x]) == 1 and abs(int(C[x ^ 28, x])) == 1 for x in range(32))
chk('bit', perm_ok and np.array_equal(C.T @ C, I32), 'opn.CONJ: C = c_2 c_3 c_4 (c_k = a_k + a_k^+, square +1) is a signed permutation of the labels with C e_x = +-e_(x xor 11100): the flip of the three colour bits')
chk('bit', [x ^ 28 for x in V3] == [24, 20, 12] and sorted(x ^ 28 for x in V3) == V3b and all(bcol(x ^ 28) == 3 - bcol(x) for x in range(32)) and all(np.array_equal(C @ AN[k] @ C.T, AD[k]) for k in COL),
    'opn.CONJ: it sends the triplet labels 00100, 01000, 10000 (for every weak value) to 11000, 10100, 01100, the colour count b to 3 - b, and a_k to a_k^+ for k = 2, 3, 4')
NC = sum(Eop(i, i) for i in range(3))
ok_E = all(np.array_equal(C @ Eop(i, j) @ C.T, I32 * (i == j) - Eop(j, i)) for i in range(3) for j in range(3))
chk('bit', ok_E and np.array_equal(C @ NC @ C.T, 3 * I32 - NC), 'opn.CONJ: C E_ij C^-1 = delta_ij - E_ji for all nine i, j, so C rho(X) C^-1 = rho(-X^T) on sl3, and C N C^-1 = 3 - N for the colour number N')
chk('bit', np.array_equal(C @ CD @ C.T, -CD) and np.array_equal(C @ CF @ C.T, CF) and np.array_equal(C @ C2 @ C.T, C2),
    'opn.CONJ: across C the symmetrised cubic Casimir changes sign, C C_D C^-1 = -C_D (10/9 on b = 1 <-> -10/9 on b = 2), while C_F and C_2 are fixed (exact 32 x 32)')
Cw = cflip((0, 1)); Ca = cflip((0, 1, 2, 3, 4))
chk('bit', all(np.array_equal(Cw @ X @ Cw.T, X) for X in X32) and all(np.array_equal(Ca @ Eop(i, j) @ Ca.T, I32 * (i == j) - Eop(j, i)) for i in range(3) for j in range(3)),
    'opn.CONJ: the weak bits play no part: the flip of bits 0, 1 commutes with every su(3) operator, and the flip of all five bits acts on su(3) as the colour flip')
# [std] 3 x 3 matrices and Gell-Mann matrices
def unit3(i, j): m = np.zeros((3, 3), dtype=np.int64); m[i, j] = 1; return m
X3 = [unit3(i, j) for (i, j) in OFF] + [unit3(0, 0) - unit3(1, 1), unit3(1, 1) - unit3(2, 2)]
W2 = [(0, 1), (0, 2), (1, 2)]
def lam2(X):
    M = np.zeros((3, 3), dtype=np.int64)
    for col, (i, j) in enumerate(W2):
        for k in range(3):
            for (a, b), cf in (((k, j), X[k, i]), ((i, k), X[k, j])):
                if cf and a != b: s = 1 if a < b else -1; M[W2.index((min(a, b), max(a, b))), col] += s * cf
    return M
eps3 = lambda i, j, k: int(np.sign((j - i) * (k - i) * (k - j)))
S = np.array([[eps3(i, j, k) for (i, j) in W2] for k in range(3)], dtype=np.int64)
chk('std', all(np.array_equal(S @ lam2(X) @ S.T, -X.T) for X in X3) and np.array_equal(S @ S.T, np.eye(3, dtype=np.int64)),
    'opn.CONJ: 3 x 3 integer matrices: the representation on Lambda^2 C^3 is S (-X^T) S^-1 with S the epsilon map, for all eight basis elements: the anti-triplet')
lam = np.zeros((8, 3, 3), dtype=complex)
lam[0][0, 1] = lam[0][1, 0] = 1; lam[1][0, 1] = -1j; lam[1][1, 0] = 1j; lam[2][0, 0] = 1; lam[2][1, 1] = -1
lam[3][0, 2] = lam[3][2, 0] = 1; lam[4][0, 2] = -1j; lam[4][2, 0] = 1j; lam[5][1, 2] = lam[5][2, 1] = 1; lam[6][1, 2] = -1j; lam[6][2, 1] = 1j
lam[7] = np.diag([1, 1, -2]) / np.sqrt(3)
def dfs(Ts):
    d = np.array([[[2 * np.trace(Ts[a] @ (Ts[b] @ Ts[c] + Ts[c] @ Ts[b])).real for c in range(8)] for b in range(8)] for a in range(8)])
    f = np.array([[[(-2j * np.trace((Ts[a] @ Ts[b] - Ts[b] @ Ts[a]) @ Ts[c])).real for c in range(8)] for b in range(8)] for a in range(8)])
    return d, f
T8 = lam / 2; Tb = np.array([-X.T for X in T8]); dG, fG = dfs(T8); dB, fB = dfs(Tb)
cas = lambda t, Ts: np.einsum('abc,aij,bjk,ckl->il', t, Ts, Ts, Ts)
vd3, vdb, vf3, vfb = cas(dG, T8), cas(dG, Tb), cas(fG, T8), cas(fG, Tb)
I3 = np.eye(3)
chk('std', np.allclose(vd3, 10 / 9 * I3, atol=1e-12) and np.allclose(vdb, -10 / 9 * I3, atol=1e-12) and np.allclose(vf3, 2j * I3, atol=1e-12) and np.allclose(vfb, 2j * I3, atol=1e-12),
    'opn.CONJ: numpy Gell-Mann matrices, T = lambda/2: d_abc T_a T_b T_c = %.6f on T and %.6f on -T^T; f_abc T_a T_b T_c = %.6fi on both (floats)' % (vd3[0, 0].real, vdb[0, 0].real, vf3[0, 0].imag))
chk('std', np.allclose(dB, -dG, atol=1e-12) and np.allclose(fB, fG, atol=1e-12) and abs(dG[0, 0, 7] - 1 / np.sqrt(3)) < 1e-12 and abs(dG[0, 3, 5] - 0.5) < 1e-12,
    'opn.CONJ: under T -> -T^T the d tensor changes sign and the f tensor does not (d_118 = 1/sqrt 3, d_146 = 1/2)')
blk2 = all(np.array_equal(X[np.ix_(V3b, V3b)], lam2(Y)) for X, Y in zip(X32, X3)); blk1 = all(np.array_equal(X[np.ix_(V3, V3)], Y) for X, Y in zip(X32, X3))
chk('bit==std', blk1 and blk2, 'opn.CONJ: on the labels the one-colour-bit block is X and the two-colour-bit block is Lambda^2 X (basis 01100, 10100, 11000 = e1^e2, e1^e3, e2^e3), exactly')
chk('bit==std', vD[1] == Fr(10, 9) and abs(float(vD[1]) - vd3[0, 0].real) < 1e-12 and abs(float(vD[2]) - vdb[0, 0].real) < 1e-12 and abs(float(vF[1]) - (1j * vf3[0, 0]).real) < 1e-12 and v2[1] == Fr(4, 3),
    'opn.CONJ: the labels and the matrices give the same values: 10/9 and -10/9, the antisymmetric one -2 = i (2i), the quadratic one 4/3')
# controls
chk('ctl', vF[1] == vF[2] and np.array_equal(C @ CF @ C.T, CF), 'opn.CONJ: the antisymmetric cubic gives one value on both, %s and %s, and C leaves it as it is: it cannot tell 3 from 3-bar' % (vF[1], vF[2]))
chk('ctl', v2[1] == v2[2], 'opn.CONJ: the quadratic Casimir gives %s on both' % v2[1])
part = []
for K in [(2,), (3,), (4,), (2, 3), (2, 4), (3, 4)]:
    CK = cflip(K); img = {bcol(int(np.nonzero(CK[:, x])[0][0])) for x in V3}
    part.append((K, sorted(img), np.array_equal(CK @ NC @ CK.T, NC) or np.array_equal(CK @ NC @ CK.T, 3 * I32 - NC)))
chk('ctl', all(len(p[1]) > 1 and not p[2] for p in part), 'opn.CONJ: a flip of one or two colour bits does not exchange the sectors: the triplet labels go to colour counts %s' % ['%s: %s' % (''.join(map(str, p[0])), p[1]) for p in part])
chk('ctl', np.array_equal(Cw @ CD @ Cw.T, CD), 'opn.CONJ: the flip of the weak bits leaves C_D as it is (10/9 stays 10/9): it is not a conjugation of su(3)')
part_end('OPEN-CONJ')

# ================================================================================================ OPEN-WEYL
head('OPEN-WEYL (opn.WEYL). The Riemann, Ricci and Weyl counts with their floor at n = 2')
riem = lambda n: n * n * (n * n - 1) // 12
ric_f = lambda n: n * (n + 1) // 2 if (n >= 3 or FAULT == 'NOFLOOR') else 1
wey_f = lambda n: n * (n + 1) * (n + 2) * (n - 3) // 12 if (n >= 3 or FAULT == 'NOFLOOR') else 0
ENG = {}
for n in range(2, 7):
    c = gs.curvature_space(n); ENG[n] = (c['dimension'], c['ricci_rank'], c['weyl_dimension'])
    chk('bit', ENG[n] == (riem(n), ric_f(n), wey_f(n)) and c['pair_symmetric'] and gs.counts(n)['riemann_independent'] == riem(n),
        'opn.WEYL n=%d: the engine curvature_space: dimension %d, Ricci rank %d, Weyl %d (closed forms %d, %d, %d)' % ((n,) + ENG[n] + (riem(n), ric_f(n), wey_f(n))))
gj = stored('gravity.json')['curvature_space']
chk('bit', all((gj[str(n)]['dimension'], gj[str(n)]['ricci_rank'], gj[str(n)]['weyl_dimension']) == (riem(n), ric_f(n), wey_f(n)) for n in range(2, 8)),
    'opn.WEYL: the stored gravity.json, n = 2..7: Ricci %s, Weyl %s' % ([gj[str(n)]['ricci_rank'] for n in range(2, 8)], [gj[str(n)]['weyl_dimension'] for n in range(2, 8)]))
def ssyt22(n, strict=True):
    return sum(1 for a, b, c, d in itertools.product(range(n), repeat=4) if a <= b and c <= d and ((a < c and b < d) if strict else (a <= c and b <= d)))
tab = {n: ssyt22(n) for n in range(2, 9)}
chk('std', all(tab[n] == riem(n) for n in tab), 'opn.WEYL: the semistandard tableaux of shape (2,2) with entries 1..n: %s for n = 2..8 = n^2(n^2-1)/12 (the GL(n) representation of this shape: recalled)' % [tab[n] for n in tab])
def riemann_space(n, cyclic=True):
    P = list(itertools.combinations(range(n), 2)); ix = {p: i for i, p in enumerate(P)}; NP = len(P)
    def co(i, j, k, l):
        if i == j or k == l: return None
        s = 1
        if i > j: i, j, s = j, i, -s
        if k > l: k, l, s = l, k, -s
        return s, ix[(i, j)] * NP + ix[(k, l)]
    rows = []
    for p in range(NP):
        for q in range(p + 1, NP): r = np.zeros(NP * NP); r[p * NP + q] = 1; r[q * NP + p] = -1; rows.append(r)
    if cyclic:
        for a, b, c, d in itertools.product(range(n), repeat=4):
            r = np.zeros(NP * NP)
            for t in (co(a, b, c, d), co(a, c, d, b), co(a, d, b, c)):
                if t: r[t[1]] += t[0]
            if r.any(): rows.append(r)
    M = np.array(rows) if rows else np.zeros((1, NP * NP))
    M = np.vstack([M, np.zeros((max(0, M.shape[1] - M.shape[0]), M.shape[1]))])
    u, s, vt = np.linalg.svd(M, full_matrices=False); rk = int((s > 1e-9).sum()); Q = vt[rk:].T                  # orthonormal basis of the null space
    ric = np.zeros((Q.shape[1], n * n))
    for k in range(Q.shape[1]):
        for b, d_ in itertools.product(range(n), repeat=2):
            ric[k, b * n + d_] = sum(t[0] * Q[t[1], k] for a in range(n) for t in [co(a, b, a, d_)] if t)
    rr = int((np.linalg.svd(ric, compute_uv=False) > 1e-9).sum()) if Q.shape[1] else 0
    # the so(n) Casimir on Lambda^2 (x) Lambda^2: K(M) = A M + M A^T for the action A of L_ij on Lambda^2
    Om = np.zeros((Q.shape[1], Q.shape[1])); Qm = Q.T.reshape(-1, NP, NP)
    for i, j in itertools.combinations(range(n), 2):
        Lv = np.zeros((n, n)); Lv[i, j] = 1; Lv[j, i] = -1
        A2 = np.zeros((NP, NP))
        for col, (a, b) in enumerate(P):
            for k in range(n):
                for (x, y), cf in (((k, b), Lv[k, a]), ((a, k), Lv[k, b])):
                    if cf and x != y: s_ = 1 if x < y else -1; A2[ix[(min(x, y), max(x, y))], col] += s_ * cf
        K1 = A2 @ Qm + Qm @ A2.T; K2 = A2 @ K1 + K1 @ A2.T
        Om -= K2.reshape(Q.shape[1], -1) @ Q
    ev = np.linalg.eigvalsh((Om + Om.T) / 2) if Q.shape[1] else np.array([])
    vals = {}
    for x in ev: vals[int(round(x))] = vals.get(int(round(x)), 0) + 1
    near = all(abs(x - round(x)) < 1e-8 for x in ev)
    # the eigenspace of 4n - 4 against the kernel of the Ricci contraction
    sameW = True
    if cyclic and Q.shape[1]:
        w, V = np.linalg.eigh((Om + Om.T) / 2); Wv = V[:, np.abs(w - (4 * n - 4)) < 1e-6]
        sameW = (Wv.shape[1] == Q.shape[1] - rr) and (Wv.shape[1] == 0 or np.abs(ric.T @ Wv).max() < 1e-9) if n >= 3 else Wv.shape[1] == 0
        # the other two eigenspaces: the Ricci contraction of the 0-space is a multiple of the metric (the scalar), and it maps the 2n-space
        # one to one onto trace-free symmetric matrices (the trace-free Ricci part)
        RV = ric.T @ V; idv = np.eye(n).reshape(-1); z = np.abs(w) < 1e-6; t = np.abs(w - 2 * n) < 1e-6 if n >= 3 else np.zeros(len(w), dtype=bool)
        okS = z.sum() == 1 and np.linalg.norm(RV[:, z]) > 1e-6 and np.linalg.matrix_rank(np.column_stack([RV[:, z], idv]), tol=1e-8) == 1
        okT = t.sum() == 0 or (np.linalg.matrix_rank(RV[:, t], tol=1e-8) == t.sum() and np.abs(idv @ RV[:, t]).max() < 1e-9 and all(np.allclose(RV[:, k].reshape(n, n), RV[:, k].reshape(n, n).T, atol=1e-9) for k in np.nonzero(t)[0]))
        sameW = sameW and okS and okT
    return Q.shape[1], rr, vals, near, sameW
STDW = {}
for n in range(2, 9):
    dim_, rr, vals, near, sameW = riemann_space(n); STDW[n] = (dim_, rr, dim_ - rr)
    want_vals = {0: 1} if n == 2 else {k: v for k, v in ((0, 1), (2 * n, n * (n + 1) // 2 - 1), (4 * n - 4, wey_f(n))) if v}
    chk('std', STDW[n] == (riem(n), ric_f(n), wey_f(n)), 'opn.WEYL n=%d: numpy, the Riemann symmetries on Lambda^2 (x) Lambda^2: dimension %d, Ricci rank %d, Weyl %d' % ((n,) + STDW[n]))
    chk('std', near and vals == want_vals and sameW, 'opn.WEYL n=%d: the so(n) Casimir on that space: eigenvalue (multiplicity) %s; Ricci takes the 0-space to the metric (the scalar) and the 2n-space one to one onto trace-free symmetric matrices, and the 4n - 4 space is its kernel (floats)'
        % (n, ', '.join('%d (%d)' % kv for kv in sorted(vals.items()))))
chk('bit==std', all(ENG[n] == STDW[n] for n in ENG) and all(tab[n] == STDW[n][0] for n in tab), 'opn.WEYL: the engine, the tableaux and numpy give the same (dimension, Ricci, Weyl) at every n = 2..6, and the same dimension for n = 2..8')
print('  n   Riemann  Ricci  Weyl   (n(n+1)/2, n(n+1)(n+2)(n-3)/12 as read without the floor)')
for n in range(2, 9): print('  %d   %5d   %4d   %4d   (%d, %d)' % (n, STDW[n][0], STDW[n][1], STDW[n][2], n * (n + 1) // 2, n * (n + 1) * (n + 2) * (n - 3) // 12))
chk('ctl', 2 * 3 // 2 != ENG[2][1] and 2 * 3 * 4 * (2 - 3) // 12 == -2 != ENG[2][2], 'opn.WEYL: the closed forms read below n = 3 fail: n(n+1)/2 = 3 is not the Ricci rank %d at n = 2, and the Weyl formula gives -2, not %d' % (ENG[2][1], ENG[2][2]))
d21, _, v21, _, _ = riemann_space(4, cyclic=False)
chk('ctl', d21 == 21 and v21.get(0) == 2, 'opn.WEYL: the cyclic identity dropped at n = 4: dimension %d, not 20, and the eigenvalue 0 twice (the 4-form joins the scalar): %s' % (d21, ', '.join('%d (%d)' % kv for kv in sorted(v21.items()))))
weak = {n: ssyt22(n, strict=False) for n in range(2, 6)}
chk('ctl', all(weak[n] != riem(n) for n in weak), 'opn.WEYL: the tableaux with the column-strict condition dropped count %s for n = 2..5, not %s' % ([weak[n] for n in weak], [riem(n) for n in weak]))
part_end('OPEN-WEYL')

finish('OPENED-4')
