#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""e_ladder.py -- the E-series ladder to its top: the bracket of e8 from the bit-rule sign, e6 > f4 > su(3) + su(3), E8 > E6 x A2 and the
commutant of the Standard-Model algebra in Furey's 16-dimensional model, the regular su(3) + su(2) of F4, E6 and so(10), the three 32-dimensional
spaces V_k of e7, Spin(9) on the Peirce 1/2 space of h3(O), and McKay for the binary icosahedral group.

Statements (check ids elad·1 .. elad·26).
 A. With eps(x,y) = s(lab x, lab y), s the bit-rule sign of Cl(8,0) and lab the map of E8 = k-perp in I_(1,8) to its space part mod 2 (the map of
    bd·mat·18), h + sum Q e_a with [e_a, e_b] = eps(a,b) e_(a+b), [e_a, e_-a] = -a satisfies the Jacobi identity on all 248^3 ordered basis
    triples (exact integers); its Killing form is 60 C on h and -60 on (e_a, e_-a).                                            (elad·1 .. elad·4)
 B. The folding sigma of the E6 diagram lifts to an involutive automorphism of e6 with fixed algebra f4 (52 = 4 + 24 + 24); 27 = 1 + 26 under f4;
    f4 contains su(3)_short + su(3)_long with 27 = (1,1) + (8,1) + (3,3b) + (3b,3), 52 = (8,1) + (1,8) + (6,3) + (6b,3b) for one choice of simple
    roots; exchanging the two simple roots of the long factor gives (3,3) + (3b,3b) and (6,3b) + (6b,3).                     (elad·5 .. elad·8)
 C. E8 > E6 x A2: 248 = 78 + 8 + 3 x 27 + 3 x 27b on the roots; the 1120 A2 of E8 form one orbit. In Furey's model the commutant of g_SM in M16(R)
    is M4(R) + C + C + C (22), its derived Lie algebra sl(4,R) on the 4 real dimensions of the hypercharge-0 singlets: it holds an sl(3,R) (V = 3 + 13
    trivial) and no su(3); with omega kept it is M2(C) + C + C + C (14), derived sl(2,C).                                     (elad·9 .. elad·12)
 D. Closed A2 + A1 subsystems (A1 orthogonal to A2): E6 720 in one orbit, D5 80 in one orbit, F4 96 in two orbits; branchings of the 27, 16, 10; the
    Albert-algebra copy is the F4 class long A2 + short A1, the E7-paper copy the E6 class; in E6 the su(2) of the first is the diagonal of two
    orthogonal roots (a triplet in the 27), that of the second a root; the first lies in an so(9) = f4 meets so(10)', the second fixes no vector
    of the 10 of its so(10).                                                                                                   (elad·13 .. elad·17)
 E. In e7 the generation sl3 and sl6 commute; 90 = (3,15) + (3b,15b); each V_k (30 + 2 roots) is sl6-stable (1 + 15 + 15 + 1) but is not a weight
    space of a Cartan element of sl3; the sl3-span of V_1 + V_2 + V_3 is 98-dimensional.                                       (elad·18 .. elad·20)
 F. Der h3(O) has dimension 52 exactly; the stabiliser of h2(O) is so(9) (36, faithful on the traceless 9); on the Peirce 1/2 space (16) it has a
    one-dimensional space of intertwiners with the spinor module of Cl(9,0) built by the bit rule, and the intertwiner is invertible. (elad·21 .. elad·23)
 G. 120 unit rotors of the even part of Cl(3,0) over Q(sqrt5), 9 classes, the full character table (exact), and the McKay graph of the
    2-dimensional representation: the affine E8 diagram with the dimensions as marks (those of check_T10.py).                  (elad·24 .. elad·26)
[bit]  exact integers, Fractions and Q(sqrt5): roots from bit labels, the bracket from the bit-rule sign, actions of root vectors, exact nullspaces
       (rank over F_p of the normal matrix as the upper bound, rational solutions checked in integers as the lower bound).
[std]  the textbook sign of Kac (recalled) and the coboundary eta to the bit-rule sign; numpy floats for ad[x,y] = [ad x, ad y]; Freudenthal
       multiplicities and Weyl dimensions; Gell-Mann matrices for g_SM; Casimirs of so(9); Burnside's class-multiplication method.
[ctl]  [e_a, e_-a] = +a, eps = 1, a random sign table (Jacobi fails); sigma = identity (78), sigma with E_2 -> -E_2 (36); a long A2 not orthogonal
       to the short one; u(1)_Y alone and so(16) (commutants 44 and 1), three copies of the colour triplet (a generation index is found); a regular
       su(3) of E6 against the short su(3) of F4; a generation sl2 and an sl6 Cartan element; the vector 9 (no intertwiner) and the frame so(8);
       the binary octahedral group (affine E7) and the cyclic group of order 8 (affine A7). Each wrong version of the main lines is a --fault option
       (the run must then end with FAILS).
Scope. Lie algebras over Q on the roots (split forms); compact forms enter only through the signatures in C and the Casimirs in F. The papers' own
       choices of embedding and their tables are not in the package (recalled). Nothing here is a statement about nature. The script builds no
       Forms, Lie or Grav object (standard library, numpy, scipy).
Run:   python3 selfcheck/proofs/e_ladder.py [--fault CARTAN_SIGN|EPS_ONE|EPS_RANDOM|SIGMA_ID|SIGMA_SIGN|A2_SHIFT|FUREY_NO_Y|V_A5|INTERTW_VEC|MCKAY_OCT]
       (from checks/; also from its own folder, and under -I -B)"""
import sys, itertools
from fractions import Fraction as F
from collections import Counter
import numpy as np
import scipy.linalg
sys.dont_write_bytecode = True

FAILS = []
NOK = [0]
def chk(tag, cid, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s %s' % ('ok  ' if cond else 'FAIL', tag, cid, msg), flush=True)
    if cond: NOK[0] += 1
    else: FAILS.append('[%s] %s' % (tag, cid))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % (NOK[0], len(FAILS)), flush=True)
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'ELAD'
FAULT_NAMES = ('CARTAN_SIGN', 'EPS_ONE', 'EPS_RANDOM', 'SIGMA_ID', 'SIGMA_SIGN', 'A2_SHIFT', 'FUREY_NO_Y', 'V_A5', 'INTERTW_VEC', 'MCKAY_OCT')
FAULT = None
if '--fault' in sys.argv:
    _i = sys.argv.index('--fault')
    FAULT = sys.argv[_i + 1] if _i + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)

# ===================================================================================== exact linear algebra
def pc(x): return bin(x).count('1')
def inv_frac(M):
    n = len(M); A = [[F(v) for v in row] + [F(int(i == j)) for j in range(n)] for i, row in enumerate(M)]
    for c in range(n):
        piv = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[piv] = A[piv], A[c]
        p = A[c][c]; A[c] = [v / p for v in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [u - f * w for u, w in zip(A[i], A[c])]
    return [row[n:] for row in A]
def det_frac(M):
    A = [[F(v) for v in row] for row in M]; n = len(A); d = F(1)
    for c in range(n):
        piv = next((i for i in range(c, n) if A[i][c] != 0), None)
        if piv is None: return F(0)
        if piv != c: A[c], A[piv] = A[piv], A[c]; d = -d
        d *= A[c][c]
        for i in range(c + 1, n):
            if A[i][c] != 0:
                f = A[i][c] / A[c][c]; A[i] = [u - f * w for u, w in zip(A[i], A[c])]
    return d
def nullspace_sparse(rows, nvar):
    """basis of {x : r.x = 0 for every row}; rows as dicts var -> coefficient; exact (Fractions)"""
    piv = {}
    for r in rows:
        r = {k: F(v) for k, v in r.items() if v}
        for c in list(r):
            if c in piv and c in r:
                f = r[c]
                for kk, x in piv[c].items():
                    y = r.get(kk, 0) - f * x
                    if y: r[kk] = y
                    else: r.pop(kk, None)
        if not r: continue
        c = min(r); f = r[c]; r = {kk: x / f for kk, x in r.items()}
        for pr in piv.values():
            if c in pr:
                g = pr[c]
                for kk, x in r.items():
                    y = pr.get(kk, 0) - g * x
                    if y: pr[kk] = y
                    else: pr.pop(kk, None)
        piv[c] = r
    basis = []
    for f_ in (j for j in range(nvar) if j not in piv):
        v = {f_: F(1)}
        for c, pr in piv.items():
            if f_ in pr: v[c] = -pr[f_]
        basis.append(v)
    return basis
def rank_mod_p(A, p=2147483647):
    """rank of an integer matrix over F_p (a lower bound for its rank over Q)"""
    A = np.array(A, dtype=np.int64) % p
    m, n = A.shape; r = 0
    for c in range(n):
        if r == m: break
        nz = np.nonzero(A[r:, c])[0]
        if len(nz) == 0: continue
        pv = r + int(nz[0])
        if pv != r: A[[r, pv]] = A[[pv, r]]
        A[r] = (A[r] * pow(int(A[r, c]), p - 2, p)) % p
        below = r + 1 + np.nonzero(A[r + 1:, c])[0]
        if len(below): A[below] = (A[below] - (A[below, c][:, None] * A[r][None, :]) % p) % p
        r += 1
    return r
def null_exact(Mint, dens=(1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128)):
    """exact nullspace of an integer matrix M: an upper bound n - rank_p(M^T M) (rank over F_p <= rank over Q = rank M),
    and a rational basis found in floats, rounded, and checked exactly (M B = 0 in integers, B = D x identity on pivot rows)"""
    Mf = np.asarray(Mint, dtype=np.float64); G = Mf.T @ Mf; n = G.shape[0]
    ub = n - rank_mod_p(np.rint(G).astype(np.int64))
    if ub == 0: return np.zeros((n, 0), dtype=np.int64), 1, 0, True
    w, V = np.linalg.eigh(G); N = V[:, :ub]
    P = scipy.linalg.qr(N.T, pivoting=True)[2]; pv = sorted(int(x) for x in P[:ub])
    B = N @ np.linalg.inv(N[pv, :])
    for D in dens:
        BD = B * D
        if np.abs(BD - np.rint(BD)).max() < 1e-7:
            Bi = np.rint(BD).astype(np.int64)
            ok = (not np.any(np.asarray(Mint, dtype=np.int64) @ Bi)) and np.array_equal(Bi[pv], D * np.eye(ub, dtype=np.int64))
            return Bi, D, ub, ok
    return None, None, ub, False

# ===================================================================================== characters (Freudenthal) and peeling
class RS:
    """a semisimple root datum from its Cartan matrix A[i][j] = <alpha_i, alpha_j^vee> and d[i] = (alpha_i, alpha_i)/2"""
    def __init__(self, A, d):
        r = len(A); self.r = r; self.A = [[int(x) for x in row] for row in A]
        self.B = [[F(A[i][j]) * F(d[j]) for j in range(r)] for i in range(r)]
        self.ATi = inv_frac([[A[j][i] for j in range(r)] for i in range(r)])
        simple = [tuple(int(i == j) for j in range(r)) for i in range(r)]
        pos = set(simple); layer = list(simple)
        while layer:
            nxt = []
            for b in layer:
                for j in range(r):
                    p = 0
                    while tuple(b[i] - (p + 1) * (i == j) for i in range(r)) in pos: p += 1
                    if p - sum(b[i] * self.A[i][j] for i in range(r)) > 0:
                        nb = tuple(b[i] + (i == j) for i in range(r))
                        if nb not in pos: pos.add(nb); nxt.append(nb)
            layer = nxt
        self.pos = sorted(pos)
        self.poslab = [tuple(sum(b[i] * self.A[i][k] for i in range(r)) for k in range(r)) for b in self.pos]
        self.posht = [sum(b) for b in self.pos]
        self.cache = {}
    def co(self, l): return [sum(self.ATi[i][j] * l[j] for j in range(self.r)) for i in range(self.r)]
    def ip(self, l1, l2):
        c1, c2 = self.co(l1), self.co(l2)
        return sum(c1[i] * self.B[i][j] * c2[j] for i in range(self.r) for j in range(self.r))
    def height(self, l): return sum(self.co(l))
    def dimW(self, hw):
        rho = (1,) * self.r; lr = tuple(a + 1 for a in hw); out = F(1)
        for al in self.poslab: out *= self.ip(lr, al) / self.ip(rho, al)
        return out
    def char(self, hw):
        hw = tuple(int(x) for x in hw)
        if hw in self.cache: return self.cache[hw]
        r = self.r; rho = (1,) * r
        add = lambda x, y, s=1: tuple(a + s * b for a, b in zip(x, y))
        lr = add(hw, rho); nl = self.ip(lr, lr); h0 = self.height(hw)
        mult = {hw: F(1)}; layer = [hw]; simple_lab = [tuple(self.A[i]) for i in range(r)]
        while layer:
            cand = sorted({add(mu, s, -1) for mu in layer for s in simple_lab})
            nxt = []
            for mu in cand:
                if mu in mult: continue
                mr = add(mu, rho); den = nl - self.ip(mr, mr)
                if den <= 0: continue
                kmax = int(h0 - self.height(mu)) + 1; tot = F(0)
                for al, ht in zip(self.poslab, self.posht):
                    for k in range(1, kmax // ht + 2):
                        nu = add(mu, al, k)
                        if nu in mult: tot += mult[nu] * self.ip(nu, al)
                m = 2 * tot / den
                if m: mult[mu] = m; nxt.append(mu)
            layer = nxt
        out = Counter({k: int(v) for k, v in mult.items()})
        assert all(v.denominator == 1 for v in mult.values())
        self.cache[hw] = out
        return out
def peel(rs, weights):
    """split a multiset of weights (Dynkin labels) into irreducible characters, highest first; None if it is not a character"""
    pool = Counter(weights); out = Counter()
    while pool:
        hw = max(pool, key=lambda l: (rs.height(l), l))
        if any(x < 0 for x in hw): return None
        for w, m in rs.char(hw).items():
            pool[w] -= m
            if pool[w] < 0: return None
            if pool[w] == 0: del pool[w]
        out[hw] += 1
    return out
A2A1 = RS([[2, -1, 0], [-1, 2, 0], [0, 0, 2]], [1, 1, 1])
A2A2 = RS([[2, -1, 0, 0], [-1, 2, 0, 0], [0, 0, 2, -1], [0, 0, -1, 2]], [1, 1, 1, 1])
NM3 = {(0, 0): '1', (1, 0): '3', (0, 1): '3b', (1, 1): '8', (2, 0): '6', (0, 2): '6b'}
NM2 = {0: '1', 1: '2', 2: '3'}
def name_a2a1(hw): return '(%s,%s)' % (NM3.get(hw[:2], str(hw[:2])), NM2.get(hw[2], str(hw[2])))
def name_a2a2(hw): return '(%s,%s)' % (NM3.get(hw[:2], str(hw[:2])), NM3.get(hw[2:], str(hw[2:])))
def content(dec, namer): return dict(sorted(Counter({namer(h): m for h, m in dec.items()}).items())) if dec is not None else None

# ===================================================================================== A. the E8 bracket from the bit-rule sign
head('A. [bit] E8 from bit labels; its bracket from the bit-rule sign of Cl(8,0) carried to E8/2E8 (CAND-050)')
R8 = []
for m in range(256):
    if pc(m) == 2:
        i, j = [t for t in range(8) if (m >> t) & 1]
        for si in (2, -2):
            for sj in (2, -2):
                v = [0] * 8; v[i] = si; v[j] = sj; R8.append(tuple(v))
for x in range(256):
    if pc(x) % 2 == 0: R8.append(tuple(1 - 2 * ((x >> t) & 1) for t in range(8)))
S8 = [(1, -1, -1, -1, -1, -1, -1, 1), (2, 2, 0, 0, 0, 0, 0, 0), (-2, 2, 0, 0, 0, 0, 0, 0), (0, -2, 2, 0, 0, 0, 0, 0), (0, 0, -2, 2, 0, 0, 0, 0),
      (0, 0, 0, -2, 2, 0, 0, 0), (0, 0, 0, 0, -2, 2, 0, 0), (0, 0, 0, 0, 0, -2, 2, 0)]            # Bourbaki simple roots alpha_1..alpha_8, doubled
RI = {r: k for k, r in enumerate(R8)}
RA = np.array(R8, dtype=np.int64); SA = np.array(S8, dtype=np.int64)
DOT = RA @ RA.T; G8 = DOT // 4                                         # inner products (dot / 4)
SINV = inv_frac(S8)
COEFF = [[sum(F(r[t]) * SINV[t][i] for t in range(8)) for i in range(8)] for r in R8]
COEF = np.array([[int(c) for c in row] for row in COEFF], dtype=np.int64)
CART8 = (SA @ SA.T) // 4
SIMP = [RI[s] for s in S8]
NEG = np.array([RI[tuple(-x for x in r)] for r in R8])
ADD = -np.ones((240, 240), dtype=np.int64)
for k, l in zip(*np.nonzero(G8 == -1)): ADD[k, l] = RI[tuple(RA[k] + RA[l])]
okr = (len(set(R8)) == 240 and np.all(DOT % 4 == 0) and np.all(np.diag(G8) == 2) and all(c.denominator == 1 for row in COEFF for c in row)
       and np.array_equal(COEF @ SA, RA) and int(((COEF >= 0).all(1)).sum()) == 120 and abs(det_frac(CART8.tolist())) == 1)
chk('bit', 'elad·1', okr and len(set(map(tuple, CART8.tolist()))) == 8,
    '240 roots of E8 from bit labels (112 from pairs of 8 bits, 128 from even labels), integer coefficients on the Bourbaki simple roots, 120 positive, det of the Cartan matrix 1')
# the label of a root: E8 = k-perp in I_{1,8} (simple roots alpha_0 = (1;-1,-1,-1,0..), alpha_i = e_i - e_(i+1)), space part mod 2 (bd·mat·18)
MU = [1, 0, 2, 3, 4, 5, 6, 7]                                         # Bourbaki alpha_k -> E_n simple root index (branch node alpha_4 -> alpha_3)
EnB = [[1, -1, -1, -1, 0, 0, 0, 0, 0]] + [[int(t == i) - int(t == i + 1) for t in range(9)] for i in range(1, 8)]
GI = [1] + [-1] * 8
dotI = lambda x, y: sum(GI[t] * x[t] * y[t] for t in range(9))
iso = all(-dotI(EnB[MU[i]], EnB[MU[j]]) == CART8[i][j] for i in range(8) for j in range(8))
XI = COEF @ np.array([EnB[MU[i]] for i in range(8)], dtype=np.int64)
LAB = [int(sum(int(XI[k, t] % 2) << (t - 1) for t in range(1, 9))) for k in range(240)]
evenlab = all(int(XI[k, 0] % 2) == pc(LAB[k]) % 2 for k in range(240))
def sgn(a, b, n):
    s = 0
    for i in range(n):
        if (a >> i) & 1: s += pc(b & ((1 << i) - 1))
    return -1 if s & 1 else 1
S256 = np.array([[sgn(a, b, 8) for b in range(256)] for a in range(256)], dtype=np.int8)
X_ = np.arange(256); XOR = X_[:, None] ^ X_[None, :]
bim = np.array_equal(S256[XOR], S256[:, None, :] * S256[None, :, :]) and np.array_equal(S256[:, XOR], S256[:, :, None] * S256[:, None, :])
def f2rank(vs):
    vs = list(vs); r = 0
    for bit in range(8):
        pv = next((i for i in range(r, len(vs)) if (vs[i] >> bit) & 1), None)
        if pv is None: continue
        vs[r], vs[pv] = vs[pv], vs[r]
        for i in range(len(vs)):
            if i != r and (vs[i] >> bit) & 1: vs[i] ^= vs[r]
        r += 1
    return r
EPS = S256[np.ix_(LAB, LAB)].astype(np.int64)
SGN_G = np.where(G8 % 2 == 0, 1, -1)
linlab = all(LAB[ADD[k, l]] == LAB[k] ^ LAB[l] for k, l in zip(*np.nonzero(ADD >= 0)))
chk('bit', 'elad·1', iso and evenlab and bim and linlab and f2rank([LAB[s] for s in SIMP]) == 8 and np.all(np.diag(EPS) == -1) and np.array_equal(EPS * EPS.T, SGN_G),
    'the label map (Bourbaki alpha_1..alpha_8 -> the E_n simple roots of I_(1,8), space part mod 2) is additive and onto F_2^8 (images of the simple roots independent); '
    'the Cl(8,0) sign s(a,b) = (-1)^#(i in a, j in b, j < i) is bimultiplicative on all 256^3 triples (both arguments); eps(x,y) = s(lab x, lab y) gives eps(a,a) = -1 on all 240 roots '
    'and eps(a,b) eps(b,a) = (-1)^(a.b) on all 57600 root pairs: a Frenkel-Kac sign')
def bracket_entries(EP, csign=-1):
    """structure constants of h + sum e_a: basis 0..7 = h_i (simple coroots), 8 + k = e_(root k); entries [b_x, b_y] = sum c b_z"""
    X, Y, Z, C = [], [], [], []
    for i in range(8):
        cv = G8[:, SIMP[i]]
        for k in np.nonzero(cv)[0]:
            X += [i, 8 + k]; Y += [8 + k, i]; Z += [8 + k, 8 + k]; C += [int(cv[k]), -int(cv[k])]
    ks, ls = np.nonzero(ADD >= 0)
    X += list(8 + ks); Y += list(8 + ls); Z += list(8 + ADD[ks, ls]); C += [int(EP[k, l]) for k, l in zip(ks, ls)]
    for k in range(240):
        for i in range(8):
            if COEF[k, i]: X.append(8 + k); Y.append(8 + int(NEG[k])); Z.append(i); C.append(csign * int(COEF[k, i]))
    return tuple(np.array(a, dtype=np.int64) for a in (X, Y, Z, C))
def jacobi(ent, n=248):
    """J(a,b,c) = [[a,b],c] + [[b,c],a] + [[c,a],b] on all ordered basis triples, exact integers (sparse contraction)"""
    X, Y, Z, C = ent
    o = np.argsort(X, kind='stable'); Xs, Ys, Zs, Cs = X[o], Y[o], Z[o], C[o]
    start = np.searchsorted(Xs, np.arange(n)); cnt = np.searchsorted(Xs, np.arange(n), side='right') - start
    rep = cnt[Z]; tot = int(rep.sum())
    i1 = np.repeat(np.arange(len(X)), rep); off = np.repeat(np.cumsum(rep) - rep, rep)
    i2 = start[Z[i1]] + (np.arange(tot) - off)
    x, y, z, u, v = X[i1], Y[i1], Ys[i2], Zs[i2], C[i1] * Cs[i2]
    keys = np.concatenate([((x * n + y) * n + z) * n + u, ((z * n + x) * n + y) * n + u, ((y * n + z) * n + x) * n + u])
    uk, inv = np.unique(keys, return_inverse=True)
    sums = np.bincount(inv.ravel(), weights=np.concatenate([v, v, v]).astype(np.float64))
    bad = np.unique(uk[np.abs(sums) > 0.5] // n)
    return len(bad), len(np.unique(uk // n))
def antisym(ent):
    d = {(int(x), int(y), int(z)): int(c) for x, y, z, c in zip(*ent)}
    return all(d.get((y, x, z)) == -c for (x, y, z), c in d.items())
rngA = np.random.default_rng(50)
RND = np.triu(rngA.choice([-1, 1], size=(240, 240)), 1); RND = RND - RND.T; np.fill_diagonal(RND, -1)
EPS_MAIN = np.ones((240, 240), dtype=np.int64) if FAULT == 'EPS_ONE' else (RND if FAULT == 'EPS_RANDOM' else EPS)
ENT = bracket_entries(EPS_MAIN, +1 if FAULT == 'CARTAN_SIGN' else -1)
nbad, ntouch = jacobi(ENT)
chk('bit', 'elad·2', nbad == 0 and antisym(ENT) and 8 + 240 == 248,
    'e8 = h + sum Q e_a with [h_i, e_a] = <a, alpha_i> e_a, [e_a, e_b] = eps(a,b) e_(a+b) (a+b a root), [e_a, e_-a] = -a (the coroot in h): antisymmetric; '
    'Jacobi identity on all 248^3 = %d ordered basis triples, exact integers: %d triples carry a non-zero term, %d fail' % (248 ** 3, ntouch, nbad))
AD = np.zeros((248, 248, 248), dtype=np.float32)
np.add.at(AD, (ENT[0], ENT[2], ENT[1]), ENT[3].astype(np.float32))           # AD[x][z, y] = coefficient of b_z in [b_x, b_y]
KIL = np.rint(AD.reshape(248, -1).astype(np.float64) @ AD.transpose(0, 2, 1).reshape(248, -1).astype(np.float64).T).astype(np.int64)
KP = np.zeros((248, 248), dtype=np.int64); KP[:8, :8] = 60 * CART8
for k in range(240): KP[8 + k, 8 + NEG[k]] = -60
chk('bit', 'elad·2', np.array_equal(KIL, KP),
    'Killing form tr(ad x ad y) exact: 60 x (Cartan matrix) on h, -60 on each pair (e_a, e_-a), 0 elsewhere; so it is non-degenerate (rank 248: det(60 C) = 60^8, one entry per root row)')
rngB = np.random.default_rng(8); res = 0.0
for _ in range(5):
    xv, yv = rngB.normal(size=248), rngB.normal(size=248)
    adx, ady = np.tensordot(xv, AD, 1).astype(np.float64), np.tensordot(yv, AD, 1).astype(np.float64)
    adz = np.tensordot(adx @ yv, AD, 1).astype(np.float64)
    res = max(res, np.abs(adz - (adx @ ady - ady @ adx)).max() / max(1.0, np.abs(adx @ ady).max()))
chk('std', 'elad·3', res < 1e-6, 'numpy floats: ad([x,y]) = [ad x, ad y] for 5 random pairs of elements of the 248-dimensional algebra (relative residual %.1e, float32 storage)' % res)
# the textbook sign (Kac, Infinite-dimensional Lie algebras; recalled): eps_K(alpha_i, alpha_j) = -1 for i = j and for i < j adjacent, bimultiplicative
MK = np.zeros((8, 8), dtype=np.int64)
for i in range(8):
    MK[i, i] = 1
    for j in range(i + 1, 8):
        if CART8[i][j] == -1: MK[i, j] = 1
C2 = COEF % 2
EPSK = 1 - 2 * ((C2 @ MK @ C2.T) % 2)
ENTK = bracket_entries(EPSK, -1)
nbadK, _ = jacobi(ENTK)
MB = np.array([[0 if S256[LAB[SIMP[i]], LAB[SIMP[j]]] == 1 else 1 for j in range(8)] for i in range(8)], dtype=np.int64)
bimc = np.array_equal(EPS, 1 - 2 * ((C2 @ MB @ C2.T) % 2))
Dm = (MB + MK) % 2; U = np.triu(Dm, 1)
ETA = np.array([1 - 2 * (int(C2[k] @ U @ C2[k]) % 2) for k in range(240)])
cob = all(EPS[k, l] == EPSK[k, l] * ETA[k] * ETA[l] * ETA[ADD[k, l]] for k, l in zip(*np.nonzero(ADD >= 0))) and np.array_equal(ETA, ETA[NEG])
sfac = np.concatenate([np.ones(8, dtype=np.int64), ETA])
DB = {(int(x), int(y), int(z)): int(c) for x, y, z, c in zip(*bracket_entries(EPS, -1))}
DK = {(int(x), int(y), int(z)): int(c * sfac[x] * sfac[y] * sfac[z]) for x, y, z, c in zip(*ENTK)}
chk('std', 'elad·3', nbadK == 0 and bimc and np.array_equal(Dm, Dm.T) and not np.any(np.diag(Dm)) and cob and DB == DK,
    'the textbook sign eps_K (recalled): Jacobi failures %d; the bit-rule sign is (-1)^(c(a) M c(b)) for a matrix M on the simple-root coefficients mod 2, M + M_K is symmetric with zero diagonal, '
    'so eps_bit = eps_K x eta(a) eta(b) eta(a+b) with eta(a) = (-1)^(c U c) (U the upper part): the map e_a -> eta(a) e_a carries the textbook bracket table onto the bit-rule one, entry by entry' % nbadK)
nbP, _ = jacobi(bracket_entries(EPS, +1)); nb1, _ = jacobi(bracket_entries(np.ones((240, 240), dtype=np.int64), -1)); nbR, _ = jacobi(bracket_entries(RND, -1))
chk('ctl', 'elad·4', nbP > 0 and nb1 > 0 and nbR > 0 and not antisym(bracket_entries(np.ones((240, 240), dtype=np.int64), -1)),
    'wrong versions fail the Jacobi identity: [e_a, e_-a] = +a: %d triples; eps = 1 (not antisymmetric): %d; a random antisymmetric sign table (seed 50): %d' % (nbP, nb1, nbR))
BRD = {}
for x, y, z, c in zip(*ENT): BRD.setdefault((int(x), int(y)), []).append((int(z), int(c)))
def brk(u, v):
    out = {}
    for x, a in u.items():
        for y, b in v.items():
            for z, c in BRD.get((x, y), ()): out[z] = out.get(z, 0) + a * b * c
    return {k: w for k, w in out.items() if w}
def adsub(vec, rows, cols):
    M = sum(float(c) * AD[x].astype(np.float64) for x, c in vec.items())
    return np.rint(M[np.ix_(rows, cols)]).astype(np.int64)

# ===================================================================================== B. e6 > f4 > su(3) + su(3)
head('B. [bit] e6 > f4 (the folding sigma of the E6 diagram, lifted to the bracket of A) > su(3) + su(3) (CAND-082)')
E6I = [k for k in range(240) if COEF[k, 6] == 0 and COEF[k, 7] == 0]; E6S = set(E6I)
def sigma_of(pi):
    return {k: RI[tuple(int(x) for x in np.array([int(COEF[k, pi[j]]) for j in range(6)] + [0, 0]) @ SA)] for k in E6I}
def lift(sig, pi, base2=1):
    """sigma~(E_i) = E_pi(i), sigma~(F_i) = F_pi(i) (E_i = e_(alpha_i), F_i = -e_(-alpha_i)) extended by brackets: sigma~(e_k) = ets[k] e_sig(k)"""
    base = [1] * 6; base[1] = base2; ets = {}
    for k in sorted([k for k in E6I if COEF[k].sum() > 0], key=lambda k: COEF[k].sum()):
        c = COEF[k]
        if c.sum() == 1:
            i = int(np.argmax(c)); ets[k] = base[i]; ets[int(NEG[k])] = base[i]; continue
        for i in range(6):
            kp = RI.get(tuple(RA[k] - SA[i])) if c[i] > 0 else None
            if kp is not None and kp in E6S: break
        ai, aj = SIMP[i], SIMP[pi[i]]; nk, nkp = int(NEG[k]), int(NEG[kp])
        ets[k] = base[i] * ets[kp] * int(EPS_MAIN[aj, sig[kp]]) * int(EPS_MAIN[ai, kp])
        ets[nk] = base[i] * ets[nkp] * int(EPS_MAIN[NEG[aj], sig[nkp]]) * int(EPS_MAIN[NEG[ai], nkp])
    return ets
E6B = set(range(6)) | {8 + k for k in E6I}
D6 = {(int(x), int(y), int(z)): int(c) for x, y, z, c in zip(*ENT) if int(x) in E6B and int(y) in E6B}
def is_auto(pi, sig, ets):
    img = lambda x: (pi[x], 1) if x < 8 else (8 + sig[x - 8], ets[x - 8])
    T = {}
    for (x, y, z), c in D6.items():
        (x2, sx), (y2, sy), (z2, sz) = img(x), img(y), img(z); T[(x2, y2, z2)] = c * sx * sy * sz
    return T == D6 and all(ets[k] * ets[sig[k]] == 1 for k in E6I) and all(pi[pi[i]] == i for i in range(6))
def fixed_basis(pi, sig, ets):
    FB = [({i: 1} if pi[i] == i else {i: 1, pi[i]: 1}) for i in range(6) if i <= pi[i]]
    FB += [{8 + k: 1} for k in E6I if sig[k] == k and ets[k] == 1]
    FB += [{8 + k: 1, 8 + sig[k]: ets[k]} for k in E6I if k < sig[k]]
    return FB
PI6 = list(range(6)) if FAULT == 'SIGMA_ID' else [5, 1, 4, 3, 2, 0]           # alpha_1 <-> alpha_6, alpha_3 <-> alpha_5
SIG = sigma_of(PI6); ETS = lift(SIG, PI6, -1 if FAULT == 'SIGMA_SIGN' else 1)
FIX = [k for k in E6I if SIG[k] == k]; PAIRS = [k for k in E6I if k < SIG[k]]
okS = sorted(SIG.values()) == sorted(E6I) and all(SIG[SIG[k]] == k for k in E6I) and all(G8[SIG[k], SIG[l]] == G8[k, l] for k in E6I for l in E6I)
chk('bit', 'elad·5', okS and len(FIX) == 24 and len(PAIRS) == 24 and all(G8[k, SIG[k]] == 0 for k in PAIRS),
    'sigma (alpha_1 <-> alpha_6, alpha_3 <-> alpha_5) permutes the 72 roots of E6, keeps inner products, sigma^2 = 1: %d fixed roots, %d orbits of two orthogonal roots' % (len(FIX), len(PAIRS)))
FB = fixed_basis(PI6, SIG, ETS)
PIDX = {min(v): t for t, v in enumerate(FB)}
def fcoords(v):
    c = {PIDX[p]: w for p, w in v.items() if p in PIDX}; rec = {}
    for t, a in c.items():
        for x, b in FB[t].items(): rec[x] = rec.get(x, 0) + a * b
    return c, {k: w for k, w in rec.items() if w} == v
nF = len(FB); ADF = np.zeros((nF, nF, nF), dtype=np.int64); closedF = True
for a in range(nF):
    for b in range(nF):
        c, okc = fcoords(brk(FB[a], FB[b])); closedF &= okc
        for t, w in c.items(): ADF[a][t, b] = w
KF = np.einsum('aij,bji->ab', ADF, ADF)
chk('bit', 'elad·5', is_auto(PI6, SIG, ETS) and nF == 52 and closedF and rank_mod_p(KF) == 52,
    'sigma lifted (E_i -> E_sigma(i), F_i -> F_sigma(i), extended through brackets) is an automorphism of e6 on all 78^2 basis pairs and an involution; its fixed algebra has dimension %d = 4 (Cartan) + %d (fixed roots, all with sign +1) + %d (orbits), closes under the bracket, Killing form of rank %d (semisimple)'
    % (nF, sum(1 for k in FIX if ETS[k] == 1), len(PAIRS), rank_mod_p(KF)))
VR = {k: tuple(int(x) for x in RA[k] + RA[SIG[k]]) for k in E6I}                 # twice the projection to the sigma-fixed space (doubled coordinates)
F4V = sorted(set(VR.values())); ipv = lambda a, b: F(int(np.dot(a, b)), 16)
F4S = [VR[SIMP[1]], VR[SIMP[3]], VR[SIMP[2]], VR[SIMP[0]]]                       # L1 = alpha_2, L2 = alpha_4, S1 = (alpha_3+alpha_5)/2, S2 = (alpha_1+alpha_6)/2
AF4 = [[2 * ipv(F4S[i], F4S[j]) / ipv(F4S[j], F4S[j]) for j in range(4)] for i in range(4)]
AF4E = [[2, -1, 0, 0], [-1, 2, -2, 0], [0, -1, 2, -1], [0, 0, -1, 2]]
chk('bit', 'elad·5', len(F4V) == 48 and Counter(ipv(v, v) for v in F4V) == Counter({2: 24, 1: 24}) and AF4 == AF4E,
    'the restricted roots: 48 = 24 of squared length 2 + 24 of squared length 1; the simple ones (alpha_2, alpha_4, (alpha_3+alpha_5)/2, (alpha_1+alpha_6)/2) have the Cartan matrix of F4 %s: the fixed algebra is f4' % AF4E)
RSF4 = RS(AF4E, [1, 1, F(1, 2), F(1, 2)])
G27 = [k for k in range(240) if COEF[k, 6] == 1 and COEF[k, 7] == 0]; I27 = [8 + k for k in G27]
labf = lambda x, v: F(4 * int(np.dot(x, v)), int(np.dot(v, v)))
W27F = Counter(tuple(int(labf(RA[g], v)) for v in F4S) for g in G27)
dec27 = peel(RSF4, W27F)
ADJF = Counter([tuple(int(F(2 * int(np.dot(u, v)), int(np.dot(v, v)))) for v in F4S) for u in F4V] + [(0, 0, 0, 0)] * 4)
decAdj = peel(RSF4, ADJF)
chk('std', 'elad·6', dec27 == Counter({(0, 0, 0, 0): 1, (0, 0, 0, 1): 1}) and RSF4.dimW((0, 0, 0, 1)) == 26 and sum(RSF4.char((0, 0, 0, 1)).values()) == 26
    and RSF4.char((0, 0, 0, 1))[(0, 0, 0, 0)] == 2 and decAdj == Counter({(1, 0, 0, 0): 1}) and RSF4.dimW((1, 0, 0, 0)) == 52,
    'characters (Freudenthal multiplicities, Weyl dimension formula): the 27 weights restricted to the f4 Cartan are the characters of the trivial representation and of highest weight omega_4 (dimension 26, zero weight twice): 27 = 1 + 26; the 52 restricted roots + 4 zeros are the character of omega_1 (dimension 52, the adjoint)')
RHO27 = {t: adsub(v, I27, I27) for t, v in enumerate(FB)}
inv_rows = [r for M in RHO27.values() for r in ({j: int(M[i, j]) for j in range(27) if M[i, j]} for i in range(27)) if r]
EF4 = [{8 + SIMP[1]: 1}, {8 + SIMP[3]: 1}, {8 + SIMP[2]: 1, 8 + SIMP[4]: ETS[SIMP[2]]}, {8 + SIMP[0]: 1, 8 + SIMP[5]: ETS[SIMP[0]]}]
def hw_count(ops, idx):
    rows = [r for v in ops for M in [adsub(v, idx, idx)] for r in ({j: int(M[i, j]) for j in range(len(idx)) if M[i, j]} for i in range(len(idx))) if r]
    return len(nullspace_sparse(rows, len(idx)))
ninv, nhwF = len(nullspace_sparse(inv_rows, 27)), hw_count(EF4, I27)
chk('bit==std', 'elad·6', ninv == 1 and nhwF == 2 and sum(dec27.values()) == 2,
    'on the 27 (grade-1 root vectors of e7, acted on by brackets): the vectors killed by all of f4 span %d dimension; the vectors killed by the four raising operators of f4 span %d: two irreducible summands, the singlet and the 26 (as many as the character route finds)' % (ninv, nhwF))
th6 = max(E6I, key=lambda k: COEF[k].sum()); mth6 = int(NEG[th6])
def a2a2_data(long2, swap=False):
    vs = [VR[SIMP[2]], VR[SIMP[0]]] + ([VR[long2], VR[SIMP[1]]] if swap else [VR[SIMP[1]], VR[long2]])   # short (S1, S2) first, then the long pair
    A = [[2 * ipv(vs[i], vs[j]) / ipv(vs[j], vs[j]) for j in range(4)] for i in range(4)]
    W = Counter(tuple(int(labf(RA[g], v)) for v in vs) for g in G27)
    Wadj = Counter([tuple(int(F(2 * int(np.dot(u, v)), int(np.dot(v, v)))) for v in vs) for u in F4V] + [(0, 0, 0, 0)] * 4)
    return A, peel(A2A2, W), peel(A2A2, Wadj)
L2ND = SIMP[3] if FAULT == 'A2_SHIFT' else mth6
A22, dec22, dec22a = a2a2_data(L2ND)
_, dec22s, dec22as = a2a2_data(L2ND, swap=True)
want27 = {'(1,1)': 1, '(3,3b)': 1, '(3b,3)': 1, '(8,1)': 1}; want52 = {'(1,8)': 1, '(6,3)': 1, '(6b,3b)': 1, '(8,1)': 1}
want27s = {'(1,1)': 1, '(3,3)': 1, '(3b,3b)': 1, '(8,1)': 1}; want52s = {'(1,8)': 1, '(6,3b)': 1, '(6b,3)': 1, '(8,1)': 1}
chk('bit', 'elad·7', SIG[th6] == th6 and A22 == [[2, -1, 0, 0], [-1, 2, 0, 0], [0, 0, 2, -1], [0, 0, -1, 2]] and content(dec22, name_a2a2) == want27 and content(dec22a, name_a2a2) == want52
    and content(dec22s, name_a2a2) == want27s and content(dec22as, name_a2a2) == want52s,
    'su(3) + su(3) in f4: the short A2 on ((alpha_3+alpha_5)/2, (alpha_1+alpha_6)/2) and the long A2 on (alpha_2, -theta) (theta the highest root of E6, sigma-fixed), orthogonal (block Cartan matrix); '
    'first factor the short su(3): the 27 splits as %s and the adjoint 52 as %s (8 + 8 + 18 + 18); with the two simple roots of the long A2 exchanged (3 <-> 3b in the second factor) the 27 is %s and the 52 is %s: '
    'so 26 = (8,1) + (3,3) + (3b,3b) holds in the second labelling, and then the 52 carries (6,3b) + (6b,3); the 8 of the 26 is the short su(3)'
    % (content(dec22, name_a2a2), content(dec22a, name_a2a2), content(dec22s, name_a2a2), content(dec22as, name_a2a2)))
E22 = [{8 + SIMP[2]: 1, 8 + SIMP[4]: ETS[SIMP[2]]}, {8 + SIMP[0]: 1, 8 + SIMP[5]: ETS[SIMP[0]]}, {8 + SIMP[1]: 1}, {8 + L2ND: 1}]
nhw22 = hw_count(E22, I27)
chk('bit==std', 'elad·7', dec22 is not None and nhw22 == sum(dec22.values()) == 4 and A2A2.dimW((1, 1, 0, 0)) == 8 and A2A2.dimW((2, 0, 1, 0)) == 18,
    'highest-weight vectors of su(3) + su(3) on the 27 (kernel of the four raising operators, exact): %d, the number of pieces of the character route; Weyl dimensions (8,1) = 8, (6,3) = 18' % nhw22)
SIGI = sigma_of(list(range(6))); FBI = fixed_basis(list(range(6)), SIGI, {k: 1 for k in E6I})
SIGP = sigma_of([5, 1, 4, 3, 2, 0]); ETSS = lift(SIGP, [5, 1, 4, 3, 2, 0], -1); FBS = fixed_basis([5, 1, 4, 3, 2, 0], SIGP, ETSS)
A22c, dec22c, _ = a2a2_data(SIMP[3])
chk('ctl', 'elad·8', len(FBI) == 78 and is_auto([5, 1, 4, 3, 2, 0], SIGP, ETSS) and len(FBS) != 52 and A22c != A22 and content(dec22c, name_a2a2) != want27,
    'wrong versions: sigma = identity fixes all 78 dimensions; sigma lifted with E_2 -> -E_2, F_2 -> -F_2 is still an involutive automorphism but fixes %d dimensions (not 52); '
    'the long A2 (alpha_2, alpha_4) is not orthogonal to the short one (Cartan block %s) and the 27 does not split as above (%s)' % (len(FBS), [[int(x) for x in r[2:]] for r in A22c[:2]], content(dec22c, name_a2a2)))

# ===================================================================================== C. E8 > E6 x A2; the generation sl3 and Furey's model
head('C. [bit] E8 > E6 x A2 on the roots (RSN-004); the commutant of the Standard-Model algebra in Furey\'s 16-dimensional model (GOS-003)')
A2p = [k for k in range(240) if all(G8[k, SIMP[i]] == 0 for i in range(6))]
b1 = A2p[0]; b2 = next(l for l in A2p if G8[b1, l] == -1)
OTH = [k for k in range(240) if k not in E6S and k not in set(A2p)]
wcls = {}
for k in OTH: wcls.setdefault((int(G8[k, b1]), int(G8[k, b2])), []).append(k)
W3 = [(1, 0), (-1, 1), (0, -1)]; W3B = [(-a, -b) for a, b in W3]
lab6 = lambda k: tuple(int(G8[k, SIMP[i]]) for i in range(6))
L27 = {lab6(g) for g in G27}; L27b = {tuple(-x for x in l) for l in L27}
kind = {w: ('27' if {lab6(k) for k in wcls.get(w, [])} == L27 else ('27b' if {lab6(k) for k in wcls.get(w, [])} == L27b else '?')) for w in W3 + W3B}
okA2 = all(ADD[k, l] in A2p for k in A2p for l in A2p if G8[k, l] == -1) and Counter(int(G8[b1, l]) for l in A2p) == Counter({2: 1, -2: 1, 1: 2, -1: 2})
chk('bit', 'elad·9', len(A2p) == 6 and okA2 and len(OTH) == 162 and sorted(wcls) == sorted(W3 + W3B) and all(len(v) == 27 for v in wcls.values())
    and len({kind[w] for w in W3}) == 1 and len({kind[w] for w in W3B}) == 1 and {kind[W3[0]], kind[W3B[0]]} == {'27', '27b'},
    'the roots of E8 orthogonal to alpha_1..alpha_6: 6, an A2; 240 = 72 + 6 + 162, the 162 in 6 classes of 27 by their A2 weight; the 3 classes at the weights of the 3 carry the E6 weights of one 27 (%s), '
    'the 3 at the 3b those of the other: 248 = (78,1) + (1,8) + (27,3) + (27b,3b) = 78 + 8 + 81 + 81' % kind[W3[0]])
A2all = set()
for k, l in zip(*np.nonzero(G8 == -1)):
    if k < l: s_ = int(ADD[k, l]); A2all.add(frozenset((int(k), int(l), s_, int(NEG[k]), int(NEG[l]), int(NEG[s_]))))
REFL8 = [np.array([RI[tuple(RA[k] - G8[k, SIMP[i]] * SA[i])] for k in range(240)]) for i in range(8)]
def orbit_sets(start, perms):
    seen = {start}; todo = [start]
    while todo:
        a = todo.pop()
        for P in perms:
            b = frozenset(int(P[x]) for x in a)
            if b not in seen: seen.add(b); todo.append(b)
    return seen
orbA2 = orbit_sets(next(iter(A2all)), REFL8)
chk('bit', 'elad·9', len(A2all) == 1120 and orbA2 == A2all and all(int(((G8[:, sorted(a)] == 0).all(1)).sum()) == 72 for a in A2all),
    'the A2 subsystems of E8: %d, one orbit of the eight simple reflections, each with exactly 72 orthogonal roots (an E6)' % len(A2all))
# ---- Furey's model (octonions by Cayley-Dickson with exact integers; blocks and gauge algebra as in reports/furey/model.py and run_all.py)
def qmul(p, q):
    a1, b1_, c1, d1 = p; a2, b2_, c2, d2 = q
    return [a1*a2 - b1_*b2_ - c1*c2 - d1*d2, a1*b2_ + b1_*a2 + c1*d2 - d1*c2, a1*c2 - b1_*d2 + c1*a2 + d1*b2_, a1*d2 + b1_*c2 - c1*b2_ + d1*a2]
def qconj(p): return [p[0], -p[1], -p[2], -p[3]]
def omul8(x, y):
    a, b, c, d = x[:4], x[4:], y[:4], y[4:]
    return [u - v for u, v in zip(qmul(a, c), qmul(qconj(d), b))] + [u + v for u, v in zip(qmul(d, a), qmul(b, qconj(c)))]
def unit(a, n=8): v = [0] * n; v[a] = 1; return v
OSIGN = {}
for a in range(8):
    for b in range(8):
        nz_ = [(c, w) for c, w in enumerate(omul8(unit(a), unit(b))) if w]
        assert len(nz_) == 1 and nz_[0][0] == a ^ b; OSIGN[(a, b)] = nz_[0][1]
def mmul(A, B):
    out = {}; Bc = {}
    for (k, j), v in B.items(): Bc.setdefault(k, []).append((j, v))
    for (i, k), u in A.items():
        for j, v in Bc.get(k, ()): out[(i, j)] = out.get((i, j), 0) + u * v
    return {k: v for k, v in out.items() if v}
def madd(A, B, s=1):
    out = dict(A)
    for k, v in B.items(): out[k] = out.get(k, 0) + s * v
    return {k: v for k, v in out.items() if v}
def mscale(A, s): return {k: v * s for k, v in A.items() if v * s}
def comm(A, B): return madd(mmul(A, B), mmul(B, A), -1)
def ident(idx): return {(i, i): F(1) for i in idx}
def trace(A): return sum(v for (i, j), v in A.items() if i == j)
def Lmat8(a): return {(a ^ m, m): F(OSIGN[(a, m)]) for m in range(8)}
def Rmat8(a): return {(m ^ a, m): F(OSIGN[(m, a)]) for m in range(8)}
def embed(A8, copy): return {(i + 8 * copy, j + 8 * copy): v for (i, j), v in A8.items()}
def _rank_rows(rows):
    piv = {}; rk = 0
    for r in rows:
        r = {k: F(v) for k, v in r.items() if v}
        while r:
            c = min(r)
            if c in piv:
                f = r[c]
                for kk, x in piv[c].items():
                    y = r.get(kk, 0) - f * x
                    if y: r[kk] = y
                    else: r.pop(kk, None)
            else:
                f = r[c]; piv[c] = {kk: x / f for kk, x in r.items()}; rk += 1; break
    return rk
def commutant(gens, idx=range(16)):
    idx = list(idx); pos = {(i, j): n for n, (i, j) in enumerate(itertools.product(idx, idx))}; rows = []
    for g in gens:
        gr, gc = {}, {}
        for (i, j), v in g.items(): gr.setdefault(i, []).append((j, v)); gc.setdefault(j, []).append((i, v))
        for a in idx:
            for b in idx:
                r = {}
                for k, v in gc.get(b, ()):
                    if (a, k) in pos: r[pos[(a, k)]] = r.get(pos[(a, k)], 0) + v
                for k, v in gr.get(a, ()):
                    if (k, b) in pos: r[pos[(k, b)]] = r.get(pos[(k, b)], 0) - v
                r = {kk: vv for kk, vv in r.items() if vv}
                if r: rows.append(r)
    inv = {n: ij for ij, n in pos.items()}
    return [{inv[n]: v for n, v in vec.items()} for vec in nullspace_sparse(rows, len(pos))]
def derivations_killing(kill):
    var = lambda i, j: 8 * i + j; rows = []
    for a in range(8):
        for b in range(8):
            s_, c = OSIGN[(a, b)], a ^ b
            for i in range(8):
                r = {}
                r[var(i, c)] = r.get(var(i, c), 0) + s_
                kk = i ^ b; r[var(kk, a)] = r.get(var(kk, a), 0) - OSIGN[(kk, b)]
                kk = a ^ i; r[var(kk, b)] = r.get(var(kk, b), 0) - OSIGN[(a, kk)]
                r = {x: y for x, y in r.items() if y}
                if r: rows.append(r)
    if kill is not None: rows += [{var(i, kill): 1} for i in range(8)]
    return [{(v // 8, v % 8): x for v, x in vec.items()} for vec in nullspace_sparse(rows, 64)]
Lk, Rk = Lmat8(3), Rmat8(3)
OMEGA = madd(embed(Lk, 0), embed(Lk, 1)); LR = mmul(Lk, Rk)
PO2 = embed(mscale(madd(ident(range(8)), LR, 1), F(1, 2)), 0)
PH = ident([12, 13, 14, 15]); PC = ident([9, 10])
def su2_on_H():
    J = {(i - 12, j - 12): v for (i, j), v in OMEGA.items() if 12 <= i < 16 and 12 <= j < 16}
    pairs = [(i, j) for i in range(4) for j in range(i + 1, 4)]
    def X_of(vec):
        X = {}
        for n, (i, j) in enumerate(pairs):
            if vec.get(n): X[(i, j)] = vec[n]; X[(j, i)] = -vec[n]
        return X
    rows = []
    for a in range(4):
        for b in range(4):
            r = {n: comm(X_of({n: 1}), J).get((a, b)) for n in range(len(pairs))}
            r = {k: v for k, v in r.items() if v}
            if r: rows.append(r)
    rows.append({n: trace(mmul(J, X_of({n: 1}))) for n in range(len(pairs)) if trace(mmul(J, X_of({n: 1})))})
    return [{(i + 12, j + 12): v for (i, j), v in X_of(vec).items()} for vec in nullspace_sparse(rows, len(pairs))]
SU3F = [embed(D, 0) for D in derivations_killing(3)]; SU2F = su2_on_H()
YF = madd(madd(mscale(PO2, F(1, 3)), mscale(PH, F(1, 2))), PC); U1F = [mmul(OMEGA, YF)]
GSM = SU3F + SU2F + ([] if FAULT == 'FUREY_NO_Y' else U1F)
CM = commutant(GSM); CMw = commutant(GSM + [OMEGA])
BLK = {'C_O + C_last (Y = 0)': [0, 3, 8, 11], 'C3_O (Y = 1/3)': [1, 2, 4, 5, 6, 7], 'C2_H (Y = 1/2)': [12, 13, 14, 15], 'C_C (Y = 1)': [9, 10]}
blockdiag = all(any(i in b and j in b for b in BLK.values()) for X in CM for (i, j) in X)
bdims = {n: _rank_rows([{(i, j): v for (i, j), v in X.items() if i in b and j in b} for X in CM]) for n, b in BLK.items()}
BRK = [comm(A, B) for a_, A in enumerate(CM) for B in CM[a_ + 1:]]
B4 = set(BLK['C_O + C_last (Y = 0)'])
derived_ok = all(i in B4 and j in B4 for X in BRK for (i, j) in X) and all(trace(X) == 0 for X in BRK)
ndr = _rank_rows(BRK)
def centre_dim(basis):
    rows = {}
    for l, Bl in enumerate(basis):
        for k, Bk in enumerate(basis):
            for key, v in comm(Bk, Bl).items(): rows.setdefault((l, key), {})[k] = v
    return len(nullspace_sparse(list(rows.values()), len(basis)))
def indep(mats):
    out = []
    for M in mats:
        if _rank_rows(out + [M]) > len(out): out.append(M)
    return out
def sig_trace(mats):
    G_ = np.array([[float(trace(mmul(A, B))) for B in mats] for A in mats]); ev = np.linalg.eigvalsh(G_)
    return int((ev > 1e-9).sum()), int((ev < -1e-9).sum())
DB15 = indep(BRK); sg15 = sig_trace(DB15)
BRKw = [comm(A, B) for a_, A in enumerate(CMw) for B in CMw[a_ + 1:]]; DBw = indep(BRKw); sgw = sig_trace(DBw)
chk('bit', 'elad·10', len(GSM) == 12 and len(CM) == 22 and blockdiag and bdims == {'C_O + C_last (Y = 0)': 16, 'C3_O (Y = 1/3)': 2, 'C2_H (Y = 1/2)': 2, 'C_C (Y = 1)': 2}
    and derived_ok and ndr == 15 and centre_dim(CM) == 7 and sg15 == (9, 6),
    'the 12-dimensional g_SM of the model (8 derivations of O killing k, 3 on the H block, omega Y) has a commutant in M16(R) of dimension %d (exact), block-diagonal with %s real dimensions on the blocks: M4(R) + C + C + C; '
    'as a Lie algebra its derived algebra has dimension %d, lies on the 4 real coordinates of the two hypercharge-0 singlet blocks and is traceless there: sl(4,R) (trace form of signature %s), centre of dimension 7'
    % (len(CM), bdims, ndr, sg15))
chk('bit', 'elad·10', len(CMw) == 14 and len(DBw) == 6 and sgw == (3, 3),
    'with the complex structure omega kept (complex-linear maps) the commutant has dimension %d and its derived algebra dimension %d, trace form of signature %s: sl(2,C) on C_O + C_last, no sl(3)' % (len(CMw), len(DBw), sgw))
I3 = [0, 3, 8]
SL3 = [{(a, b): F(1)} for a in I3 for b in I3 if a != b] + [{(0, 0): F(1), (3, 3): F(-1)}, {(3, 3): F(1), (8, 8): F(-1)}]
inv_sl3 = len(nullspace_sparse([r for X in SL3 for r in ({j: v for (i2, j), v in X.items() if i2 == i} for i in range(16)) if r], 16))
chk('bit', 'elad·11', all(not comm(X, g) for X in SL3 for g in GSM) and _rank_rows(SL3 + [comm(A, B) for A in SL3 for B in SL3]) == 8 and sig_trace(SL3) == (5, 3) and inv_sl3 == 13,
    'an sl(3,R) in the commutant: the traceless real 3 x 3 matrices on the coordinates 1, k (first copy) and 1\' (second copy): commutes with all of g_SM, closes, trace form of signature (5, 3) (split real form, not su(3)), '
    'and V = 3 + %d trivial under it: it moves three real singlet directions, not a generation index' % inv_sl3)
chk('bit', 'elad·11', ndr == 15 and len(B4) == 4 < 6 and all(bdims[n] == 2 for n in bdims if n != 'C_O + C_last (Y = 0)'),
    'answer to the generation question: every perfect subalgebra of the commutant lies in its derived algebra sl(4,R), which acts on 4 real dimensions only; su(3) has no non-trivial real representation of dimension below 6 (recalled), '
    'so no su(3) commutes with g_SM; the charged and coloured blocks carry only scalars (commutant C, multiplicity one each), so V is not 3 x W for any sl3 commuting with g_SM: the generation A2 of E8 > E6 x A2 (acting on 27 x 3) is not in End(V)')
LAM = [np.array(m, dtype=complex) for m in (
    [[0, 1, 0], [1, 0, 0], [0, 0, 0]], [[0, -1j, 0], [1j, 0, 0], [0, 0, 0]], [[1, 0, 0], [0, -1, 0], [0, 0, 0]], [[0, 0, 1], [0, 0, 0], [1, 0, 0]],
    [[0, 0, -1j], [0, 0, 0], [1j, 0, 0]], [[0, 0, 0], [0, 0, 1], [0, 1, 0]], [[0, 0, 0], [0, 0, -1j], [0, 1j, 0]], np.diag([1, 1, -2]) / np.sqrt(3))]
PAU = [np.array(m, dtype=complex) for m in ([[0, 1], [1, 0]], [[0, -1j], [1j, 0]], [[1, 0], [0, -1]])]
def emb8(A, at):
    M = np.zeros((8, 8), dtype=complex); n = A.shape[0]; M[at:at + n, at:at + n] = A; return M
realify = lambda A: np.block([[A.real, -A.imag], [A.imag, A.real]])
GS = [realify(emb8(0.5j * l, 0)) for l in LAM] + [realify(emb8(0.5j * p, 3)) for p in PAU] + [realify(1j * np.diag([1/3, 1/3, 1/3, 1/2, 1/2, 1, 0, 0]))]
def comm_null(gens, n):
    Mb = np.vstack([np.kron(g, np.eye(n)) - np.kron(np.eye(n), g.T) for g in gens]); u, s, vt = np.linalg.svd(Mb)
    k = int((s < 1e-9).sum()) + (Mb.shape[1] - len(s)); return [vt[-t - 1].reshape(n, n) for t in range(k)]
CS = comm_null(GS, 16)
brs = np.array([(A @ B - B @ A).ravel() for a_, A in enumerate(CS) for B in CS[a_ + 1:]]); dstd = int((np.linalg.svd(brs, compute_uv=False) > 1e-8).sum())
chk('std', 'elad·12', len(CS) == 22 and dstd == 15,
    'numpy: g_SM written with Gell-Mann and Pauli matrices on C^8 = 3_(1/3) + 2_(1/2) + 1_1 + 1_0 + 1_0, made real (16 x 16): commutant of dimension %d by SVD, derived algebra of dimension %d (the same numbers as the model)' % (len(CS), dstd))
SO16 = [{(i, i + 1): F(1), (i + 1, i): F(-1)} for i in range(15)]
GC3 = [{(i, j): v for (i, j), v in g.items() if i in BLK['C3_O (Y = 1/3)'] and j in BLK['C3_O (Y = 1/3)']} for g in SU3F + U1F]
pos6 = {c: t for t, c in enumerate(BLK['C3_O (Y = 1/3)'])}
GC3x3 = [{(3 * pos6[i] + r, 3 * pos6[j] + r): v for (i, j), v in g.items() for r in range(3)} for g in GC3 if g]
C3x3 = commutant(GC3x3, range(18)); d3x3 = len(indep([comm(A, B) for a_, A in enumerate(C3x3) for B in C3x3[a_ + 1:]]))
chk('ctl', 'elad·12', len(commutant(U1F)) == 44 and len(commutant(SO16)) == 1 and len(C3x3) == 18 and d3x3 == 16,
    'controls: the commutant of u(1)_Y alone has dimension %d (larger), of so(16) dimension 1; positive control: three copies of the colour triplet block (C3_O x R^3, 18 real dimensions) have a commutant of dimension %d '
    '(M3(C)) with derived algebra of dimension %d (sl(3,C), containing su(3)): a generation index is found when the model has one' % (len(commutant(U1F)), len(C3x3), d3x3))

# ===================================================================================== D. regular su(3) + su(2) in F4, E6, so(10); the two copies; Spin(9) < Spin(10)
head('D. [bit] regular su(3) + su(2) (+ u(1)) of F4, E6 and so(10) from the roots; the Albert-algebra copy and the E7-paper copy; Spin(9) in Spin(10) (LNB-035/038/045/117/021g/035b)')
SIGT = sigma_of([5, 1, 4, 3, 2, 0])                                             # the table uses the folding itself (independent of the faults of B)
VRT = {k: tuple(int(x) for x in RA[k] + RA[SIGT[k]]) for k in E6I}; F4VT = sorted(set(VRT.values())); F4ST = [VRT[SIMP[1]], VRT[SIMP[3]], VRT[SIMP[2]], VRT[SIMP[0]]]
def rvec(v, a):
    num = 2 * int(np.dot(v, a)); aa = int(np.dot(a, a)); assert num % aa == 0
    return tuple(int(x) for x in np.array(v) - (num // aa) * np.array(a))
def subsystems(vecs, simple_vecs):
    V = np.array(vecs, dtype=np.int64); idx = {tuple(int(x) for x in v): i for i, v in enumerate(V)}; n = len(vecs); Gd = V @ V.T
    neg = [idx[tuple(int(x) for x in -V[i])] for i in range(n)]
    perms = [np.array([idx[rvec(v, s)] for v in V]) for s in simple_vecs]
    A2s = set()
    for i in range(n):
        for j in range(n):
            if Gd[i, i] == Gd[j, j] and 2 * Gd[i, j] == -Gd[i, i]:
                s_ = idx.get(tuple(int(x) for x in V[i] + V[j]))
                if s_ is not None: A2s.add(frozenset((i, j, s_, neg[i], neg[j], neg[s_])))
    subs = set(); nonclosed = 0; nonorth_closed = 0
    for a2 in A2s:
        L = sorted(a2)
        for c in range(n):
            if c in a2: continue
            closed = all(idx.get(tuple(int(x) for x in V[t] + V[c])) is None and idx.get(tuple(int(x) for x in V[t] - V[c])) is None for t in L)
            if all(Gd[c, t] == 0 for t in L):
                if closed: subs.add((a2, frozenset((c, neg[c]))))
                else: nonclosed += 1
            elif closed: nonorth_closed += 1
    keys = set(subs); orbits = []
    while keys:
        st = next(iter(keys)); seen = {st}; todo = [st]
        while todo:
            a2, a1 = todo.pop()
            for P in perms:
                b = (frozenset(int(P[x]) for x in a2), frozenset(int(P[x]) for x in a1))
                if b not in seen: seen.add(b); todo.append(b)
        orbits.append(seen); keys -= seen
    return dict(V=V, idx=idx, Gd=Gd, neg=neg, A2s=A2s, subs=subs, orbits=sorted(orbits, key=len), nonclosed=nonclosed, nonorth_closed=nonorth_closed, rank=int(np.linalg.matrix_rank(V.astype(float))))
def simple_of(sd, rep):
    a2, a1 = rep; Gd = sd['Gd']; L = sorted(a2)
    i, j = next((p, q) for p in L for q in L if p < q and 2 * Gd[p, q] == -Gd[p, p]); return i, j, min(a1)
def branch(sd, rep, xs, labfun, ij=None):
    i, j, c = simple_of(sd, rep) if ij is None else ij; V = sd['V']
    return peel(A2A1, Counter(tuple(int(labfun(x, V[t])) for t in (i, j, c)) for x in xs))
def descr(sd, rep):
    a2, a1 = rep; Gd = sd['Gd']; L = sorted(a2 | a1)
    cen = [t for t in range(len(sd['V'])) if all(Gd[t, u] == 0 for u in L)]
    return dict(a2=int(Gd[min(a2), min(a2)]), a1=int(Gd[min(a1), min(a1)]), cen_roots=len(cen), cen_cartan=sd['rank'] - 3)
labe = lambda x, v: F(2 * int(np.dot(x, v)), int(np.dot(v, v)))
D5I = [k for k in range(240) if COEF[k, 5] == 0 and COEF[k, 6] == 0 and COEF[k, 7] == 0]
SYS = {'E6': subsystems([R8[k] for k in E6I], S8[:6]), 'D5': subsystems([R8[k] for k in D5I], S8[:5]), 'F4': subsystems(F4VT, F4ST)}
X27 = [RA[g] for g in G27]; X16 = [RA[g] for g in G27 if COEF[g, 5] == 1]; X10 = [RA[g] for g in G27 if COEF[g, 5] == 2]
TAB = {}
for nm, sd in SYS.items():
    for orb in sd['orbits']:
        rep = min(orb, key=lambda r: (sorted(r[0]), sorted(r[1])))
        row = dict(descr(sd, rep), size=len(orb))
        if nm == 'E6': row['27'] = content(branch(sd, rep, X27, labe), name_a2a1)
        if nm == 'D5': row['16'] = content(branch(sd, rep, X16, labe), name_a2a1); row['10'] = content(branch(sd, rep, X10, labe), name_a2a1)
        if nm == 'F4': row['27'] = content(branch(sd, rep, X27, labf), name_a2a1)
        TAB.setdefault(nm, []).append((row, rep))
for nm in TAB:
    for row, _ in TAB[nm]: print('      table %s: %s' % (nm, row))
cnt = {nm: (len(sd['A2s']), len(sd['subs']), [len(o) for o in sd['orbits']]) for nm, sd in SYS.items()}
F4rows = {(r['a2'], r['a1']): (r, rep) for r, rep in TAB['F4']}
chk('bit', 'elad·13', cnt == {'E6': (120, 720, [720]), 'D5': (40, 80, [80]), 'F4': (32, 96, [48, 48])} and set(F4rows) == {(32, 16), (16, 32)}
    and [r['cen_roots'] for r, _ in TAB['E6']] == [6] and [r['cen_roots'] for r, _ in TAB['D5']] == [2] and all(r['cen_roots'] == 0 for r, _ in TAB['F4']),
    'closed A2 + A1 subsystems (A1 orthogonal to A2), counted and sorted into orbits of the simple reflections: E6 %s, D5 %s, F4 %s (A2 count, subsystem count, orbit sizes); '
    'F4 has two classes, long A2 + short A1 and short A2 + long A1; centralisers (roots orthogonal, Cartan of rank r - 3): E6 6 roots and 3 (su(3) + u(1), dimension 9), D5 2 roots and 2 (su(2) + u(1)), F4 none and 1 (u(1))' % (cnt['E6'], cnt['D5'], cnt['F4']))
e6pos = {k: t for t, k in enumerate(E6I)}; d5pos = {k: t for t, k in enumerate(D5I)}
def keyof(pos, a, b, c):
    s_ = int(ADD[a, b]); return (frozenset(pos[x] for x in (a, b, s_, int(NEG[a]), int(NEG[b]), int(NEG[s_]))), frozenset((pos[c], pos[int(NEG[c])])))
E7rep6 = keyof(e6pos, SIMP[0], SIMP[2], SIMP[1]); E7rep5 = keyof(d5pos, SIMP[0], SIMP[2], SIMP[1])
c27_E7 = content(branch(SYS['E6'], E7rep6, X27, labe, (e6pos[SIMP[0]], e6pos[SIMP[2]], e6pos[SIMP[1]])), name_a2a1)
c16_E7 = content(branch(SYS['D5'], E7rep5, X16, labe, (d5pos[SIMP[0]], d5pos[SIMP[2]], d5pos[SIMP[1]])), name_a2a1)
c10_E7 = content(branch(SYS['D5'], E7rep5, X10, labe, (d5pos[SIMP[0]], d5pos[SIMP[2]], d5pos[SIMP[1]])), name_a2a1)
CAS3 = {'1': F(0), '3': F(4, 9), '3b': F(4, 9), '8': F(1)}; CAS2 = {'1': F(0), '2': F(3, 8), '3': F(1)}; DIM3 = {'1': 1, '3': 3, '3b': 3, '8': 8}; DIM2 = {'1': 1, '2': 2, '3': 3}
def s2table(cont):
    out = Counter()
    for nmx, m in cont.items():
        a, b = nmx[1:-1].split(','); out[(CAS3[a], CAS2[b])] += m * DIM3[a] * DIM2[b]
    return out
WANT_S2 = Counter({(F(0), F(0)): 2, (F(0), F(3, 8)): 4, (F(0), F(1)): 3, (F(4, 9), F(3, 8)): 12, (F(4, 9), F(0)): 6})    # baez_check.py S2, the Albert-algebra copy on h3(O)
s2long, s2short = s2table(F4rows[(32, 16)][0]['27']), s2table(F4rows[(16, 32)][0]['27'])
chk('bit', 'elad·14', E7rep6 in SYS['E6']['subs'] and c27_E7 == {'(1,1)': 3, '(1,2)': 3, '(3,1)': 1, '(3,2)': 1, '(3b,1)': 3} and c16_E7 == {'(1,1)': 2, '(1,2)': 1, '(3,2)': 1, '(3b,1)': 2}
    and c10_E7 == {'(1,2)': 2, '(3,1)': 1, '(3b,1)': 1} and s2long == WANT_S2 and s2short != WANT_S2,
    'the E7-paper copy (A2 on alpha_1, alpha_3, A1 on alpha_2, inside the Levi so(10) = D5) is the one E6 class: 27 = %s, 16 = %s, 10 = %s; '
    'the Albert-algebra copy (baez_check.py S2: Casimir classes of the 12-dimensional stabiliser on h3(O)) has the 27 of the F4 class long A2 + short A1: %s; the class short A2 + long A1 gives %s (it has an 8)'
    % (c27_E7, c16_E7, c10_E7, F4rows[(32, 16)][0]['27'], F4rows[(16, 32)][0]['27']))
repF = F4rows[(32, 16)][1]; sdF = SYS['F4']; iF, jF, cF = simple_of(sdF, repF)
cvec = tuple(int(x) for x in sdF['V'][cF]); BETA = sorted(k for k in E6I if VRT[k] == cvec)
RS1 = RS([[2]], [1])
su2_F4 = peel(RS1, Counter((int(F(int(np.dot(x, np.array(cvec))), 4)),) for x in X27)); su2_E6 = peel(RS1, Counter((int(G8[g, SIMP[1]]),) for g in G27))
chk('bit', 'elad·14', len(BETA) == 2 and SIGT[BETA[0]] == BETA[1] and G8[BETA[0], BETA[1]] == 0 and su2_F4 == Counter({(2,): 1, (1,): 8, (0,): 8}) and su2_E6 == Counter({(1,): 6, (0,): 15}),
    'in E6 the su(2) of the Albert-algebra copy is the diagonal of two orthogonal roots beta, sigma(beta) (a short root of F4), the 27 under it = 1 triplet + 8 doublets + 8 singlets; '
    'a root su(2) of E6 (the E7-paper copy) gives 6 doublets + 15 singlets: the two copies are not conjugate in E6 (no triplet in any regular A1)')
LONGF = [v for v in F4VT if int(np.dot(v, v)) == 32]
orb8 = {cvec}; todo = [cvec]
while todo:
    v = todo.pop()
    for a in LONGF:
        w = rvec(v, a)
        if w not in orb8: orb8.add(w); todo.append(w)
D5P = sorted([k for k in E6I if SIGT[k] == k] + [k for k in E6I if SIGT[k] != k and VRT[k] in orb8]); D5PS = set(D5P)
closedP = all(int(ADD[k, l]) in D5PS for k in D5P for l in D5P if ADD[k, l] >= 0)
orbD5 = orbit_sets(frozenset(D5P), REFL8[:6])
zrow = [{i: int(np.dot(SA[i], RA[k])) for i in range(6) if np.dot(SA[i], RA[k])} for k in D5P]
zs = nullspace_sparse(zrow, 6); zvec = sum(np.array([float(zs[0].get(i, 0)) for i in range(6)])[i] * SA[i].astype(float) for i in range(6)) if len(zs) == 1 else None
lev = Counter(round(float(np.dot(RA[g], zvec)), 9) for g in G27) if zvec is not None else Counter()
lv10 = [v for v, m in lev.items() if m == 10]
X10P = [RA[g] for g in G27 if lv10 and abs(float(np.dot(RA[g], zvec)) - lv10[0]) < 1e-9]
chk('bit', 'elad·15', len(orb8) == 8 and len(D5P) == 40 and closedP and int(np.linalg.matrix_rank(RA[D5P].astype(float))) == 5 and len(orbD5) == 27 and frozenset(D5I) in orbD5
    and sorted(lev.values()) == [1, 10, 16] and set(BETA) <= D5PS and all(RI[tuple(int(x) // 2 for x in sdF['V'][t])] in D5PS for t in repF[0]),
    'Spin(9) in Spin(10): the W(D4)-orbit of the short root of the Albert-algebra copy (8 short roots of F4, a B4 = so(9) with the 24 long ones); their 16 E6 preimages with the 24 sigma-fixed roots form a closed rank-5 system of 40 roots, '
    'one of the 27 D5 of E6 (one orbit, containing the Levi D5 of the E7 paper): so(10)\'; the 27 splits under it as %s; the Albert-algebra copy lies in it (its A2 and beta, sigma(beta) are among the 40), and in the so(9) = f4 meets so(10)\'' % sorted(lev.values()))
long2 = [sdF['V'][iF], sdF['V'][jF]]
urow = [{t: int(np.dot(F4ST[t], np.array(w))) for t in range(4) if np.dot(F4ST[t], np.array(w))} for w in long2 + [np.array(cvec)]]
us = nullspace_sparse(urow, 4); uvec = sum(float(us[0].get(t, 0)) * np.array(F4ST[t], dtype=float) for t in range(4)) if len(us) == 1 else None
def charged(xs, simple3, chargev, labfun):
    out = Counter()
    for q in sorted({round(float(np.dot(x, chargev)), 9) for x in xs}):
        sub = [x for x in xs if abs(float(np.dot(x, chargev)) - q) < 1e-9]
        d = peel(A2A1, Counter(tuple(int(labfun(x, v)) for v in simple3) for x in sub))
        if d is None: return None
        for h, m in d.items(): out[(name_a2a1(h), q)] += m
    return out
cF10 = charged(X10P, long2 + [np.array(cvec)], uvec, labf) if uvec is not None else None
ywrow = [{i: int(np.dot(SA[i], SA[t])) for i in range(4)} for t in (0, 1, 2)]
ys = nullspace_sparse(ywrow, 4); yvec = sum(float(ys[0].get(i, 0)) * SA[i].astype(float) for i in range(4)) if len(ys) == 1 else None
cE10 = charged(X10, [SA[0], SA[2], SA[1]], yvec, labe) if yvec is not None else None
inv_F = sum(m for (nmx, q), m in (cF10 or {}).items() if nmx == '(1,1)' and q == 0); inv_E = sum(m for (nmx, q), m in (cE10 or {}).items() if nmx == '(1,1)')
chk('bit', 'elad·16', cF10 is not None and cE10 is not None and inv_F == 1 and inv_E == 0 and sorted(n_ for (n_, q) in cF10) == ['(1,1)', '(1,3)', '(3,1)', '(3b,1)'],
    'on the vector 10 of its so(10): the Albert-algebra copy (with its u(1), the Cartan direction of f4 orthogonal to its A2 and A1) gives %s: one invariant vector, so it lies in the so(9) fixing it; '
    'the E7-paper copy (u(1) = the direction of the A4 Cartan orthogonal to alpha_1, alpha_2, alpha_3) gives %s: no invariant vector, so it lies in no so(9) of its so(10) (an so(9) of so(10) fixes a vector of the 10, recalled): '
    'Spin(9) in Spin(10) does not carry one copy to the other' % (dict(sorted((('%s q=%s' % (n_, F(q).limit_denominator(100))), m) for (n_, q), m in cF10.items())) if cF10 else None, dict(sorted((('%s q=%s' % (n_, F(q).limit_denominator(100))), m) for (n_, q), m in cE10.items())) if cE10 else None))
orthP = [k for k in D5P if G8[k, BETA[0]] == 0 and G8[k, BETA[1]] == 0]
A2F_e6 = {RI[tuple(int(x) // 2 for x in sdF['V'][t])] for t in repF[0]}
orthE = [k for k in D5I if all(G8[k, t] == 0 for t in (SIMP[0], SIMP[2]))]; dE = [k for k in orthE if k not in (SIMP[1], int(NEG[SIMP[1]]))]
chk('bit', 'elad·17', len(orthP) == 12 and A2F_e6 <= set(orthP) and len(orthE) == 4 and len(dE) == 2 and G8[dE[0], SIMP[1]] == 0 and abs(float(np.dot(yvec, RA[dE[0]]))) > 1e-9 and abs(float(np.dot(yvec, SA[1]))) < 1e-9,
    'the relation inside so(10) = so(6) + so(4) + ...: in so(10)\' the roots orthogonal to beta, sigma(beta) are 12 (an so(6)) and contain the A2 of the Albert-algebra copy, whose su(2) is the diagonal of so(4) = su(2)(beta) + su(2)(sigma beta); '
    'in the Levi so(10) the roots orthogonal to the E7-paper A2 are 4 = {+-alpha_2, +-delta} (an so(4)), its su(2) is the factor su(2)(alpha_2), and its u(1) has a component along delta: the same su(3) class, '
    'the su(2) a factor in one copy and the diagonal in the other')
A2RS = RS([[2, -1], [-1, 2]], [1, 1])
regA2 = content(peel(A2RS, Counter((int(G8[g, SIMP[0]]), int(G8[g, SIMP[2]])) for g in G27)), lambda h: NM3[h])
shA2 = content(peel(A2RS, Counter((int(labf(RA[g], VRT[SIMP[2]])), int(labf(RA[g], VRT[SIMP[0]]))) for g in G27)), lambda h: NM3[h])
chk('ctl', 'elad·17', regA2 == {'1': 9, '3': 3, '3b': 3} and '8' in shA2 and all(sd['nonorth_closed'] == 0 for sd in SYS.values()),
    'controls: a regular su(3) of E6 splits the 27 as %s, the short su(3) of F4 (diagonal in E6, not regular there) as %s; no A2 together with a non-orthogonal root is closed (all three systems)' % (regA2, shA2))

# ===================================================================================== E. V1, V2, V3 and the generation sl3 of e7
head('E. [bit] the three 32-dimensional spaces V_k of e7 and the generation sl3 (LNB-039, LNB-033, LNB-033b; CAND-021)')
E7I = [k for k in range(240) if COEF[k, 7] == 0]
AG = [k for k in E7I if all(G8[k, SIMP[i]] == 0 for i in range(4))]                    # the generation A2 (E7 paper, Prop. 1; baez_check.py E3a)
PHI0 = [k for k in E7I if G8[k, SIMP[5]] == 0 and G8[k, SIMP[6]] == 0]                 # sl6 (E3b)
NIN = [k for k in E7I if k not in set(AG) | set(PHI0)]
SRC2 = PHI0 if FAULT == 'V_A5' else AG
g1_ = SRC2[0]; g2_ = next(l for l in SRC2 if G8[g1_, l] == -1)
wt = lambda k: (int(G8[k, g1_]), int(G8[k, g2_]))
Q45 = [k for k in NIN if wt(k) in W3]; Q45b = [k for k in NIN if wt(k) in W3B]
PHIK = {w: [k for k in NIN if wt(k) in (w, (-w[0], -w[1]))] for w in W3}
BK = {w: [k for k in AG if PHIK[w] and all(G8[k, s] == 0 for s in PHIK[w])] for w in W3}
VK = {w: PHIK[w] + BK[w] for w in W3}
okV = (len(AG), len(PHI0), len(NIN), len(Q45), len(Q45b)) == (6, 30, 90, 45, 45) and all(len(PHIK[w]) == 30 and len(BK[w]) == 2 and len(VK[w]) == 32 for w in W3)
okV &= all(set(PHIK[w]) == {k for k in NIN if BK[w] and G8[k, BK[w][0]] == 0} for w in W3)
chk('bit', 'elad·18', okV,
    'e7 = the roots of E8 with no alpha_8: the generation A2 (6 roots orthogonal to alpha_1..alpha_4), sl6 (30 roots orthogonal to alpha_6, alpha_7) and 90 others; by their A2 weight the 90 are 45 at the weights w_k of the 3 and 45 at -w_k; '
    'V_k = (the 30 roots at +-w_k) + (+-beta_k, the A2 roots orthogonal to w_k): 32 each, and the 30 are exactly the roots of the 90 orthogonal to beta_k')
cor = lambda k: {i: int(COEF[k, i]) for i in range(8) if COEF[k, i]}
SL3B = [{8 + k: 1} for k in AG] + [cor(g1_), cor(g2_)]
SL6B = [{8 + k: 1} for k in PHI0] + [cor(k) for k in PHI0]
def stable(vecs, idx):
    S = set(idx); out = True
    for v in vecs:
        M = sum(float(c) * AD[x][:, idx].astype(np.float64) for x, c in v.items())
        out &= not np.any(np.abs(M[[r for r in range(248) if r not in S]]) > 0.5)
    return out
gvec = np.array([1, 3, 7, 15, 31, 63, 127, 255])
POSR = [k for k in AG + PHI0 if int(RA[k] @ gvec) > 0]; POS6 = [k for k in PHI0 if int(RA[k] @ gvec) > 0]
I45, I45b = [8 + k for k in Q45], [8 + k for k in Q45b]
comm36 = all(not brk(x, y) for x in SL3B for y in SL6B)
irr = (hw_count([{8 + k: 1} for k in POSR], I45), hw_count([{8 + k: 1} for k in POSR], I45b)) if okV else (0, 0)
chk('bit', 'elad·18', okV and all(int(RA[k] @ gvec) != 0 for k in AG + PHI0) and comm36 and stable(SL3B + SL6B, I45) and stable(SL3B + SL6B, I45b) and irr == (1, 1),
    'on the bracket of A: sl3 and sl6 commute (all 8 x 60 basis brackets zero); the 45 root vectors at +w_k and the 45 at -w_k are each stable under sl3 + sl6, and each has a single highest-weight vector '
    '(kernel of the 18 positive root vectors, exact): irreducible, (3,15) and (3b,15b): the 90 is 3 x 15 + 3b x 15b, with sl3 acting on the index k')
hw6 = [hw_count([{8 + k: 1} for k in POS6], [8 + r for r in VK[w]]) for w in W3] if okV else []
hrows = [{0: int(G8[r, g1_] - G8[VK[w][0], g1_]), 1: int(G8[r, g2_] - G8[VK[w][0], g2_])} for w in W3 for r in VK[w][1:]]
nH = len(nullspace_sparse([{k: v for k, v in r.items() if v} for r in hrows if any(r.values())], 2))
chk('bit', 'elad·19', okV and all(stable(SL6B, [8 + r for r in VK[w]]) for w in W3) and hw6 == [4, 4, 4] and nH == 0,
    'each V_k is stable under sl6 with 4 highest-weight vectors (1 + 15 + 15 + 1 = Lambda^even C^6, as baez_check.py E3e); but no non-zero Cartan element of the generation sl3 has each V_k inside one eigenspace '
    '(the solution space of the conditions is %d-dimensional): V_k holds roots r and -r, so the V_k are not weight spaces of a Cartan element of sl3' % nH)
I96 = [8 + r for w in W3 for r in VK[w]]
span96 = [np.eye(248, dtype=np.int64)[i] for i in I96]
for x in SL3B:
    for i in I96:
        bv = brk(x, {i: 1}); v = np.zeros(248, dtype=np.int64)
        for z, c in bv.items(): v[z] = c
        span96.append(v)
S96 = np.array(span96); r96 = rank_mod_p(S96)
inside = not np.any(S96[:, [c for c in range(248) if c not in set(I96) and c >= 8]]) and rank_mod_p(S96[:, :8]) == 2
maps = 0
for b in AG:
    for WS in (W3, W3B):
        for w in WS:
            w2 = (w[0] + wt(b)[0], w[1] + wt(b)[1])
            if w2 in WS:
                src = [k for k in NIN if wt(k) == w]; dst = {k for k in NIN if wt(k) == w2}
                maps += int(all(ADD[k, b] >= 0 for k in src) and {int(ADD[k, b]) for k in src} == dst and len(src) == 15)
chk('bit', 'elad·19', okV and r96 == 98 and inside and maps == 12,
    'the sl3-span of V_1 + V_2 + V_3 (96 root vectors and their brackets with sl3) has dimension %d: the two Cartan directions of sl3 enter, so the 96 is not sl3-stable and is not 3 x 32; '
    'on the 90 each root vector e_beta of sl3 maps the 15 roots at one weight bijectively onto the 15 at the next (%d such maps, 6 on the 3 and 6 on the 3b): the index k is moved on the 90 only, the two completing vectors +-beta_k of each V_k are root vectors of sl3 itself' % (r96, maps))
c2gen = Counter(int(G8[r, g1_]) for r in NIN)
rngE = np.random.default_rng(39); t6 = rngE.integers(1, 50, size=5)
p6 = [k for k in PHI0 if int(RA[k] @ gvec) > 0][:5]
ev6 = Counter(int(sum(int(t) * int(G8[r, p]) for t, p in zip(t6, p6))) for r in NIN + AG)
chk('ctl', 'elad·20', c2gen == Counter({0: 30, 1: 30, -1: 30}) and len(ev6) != 3 and sorted(ev6.values()) != [32, 32, 32],
    'controls: a generation sl2 (one root of the A2) splits the 90 as 30 at eigenvalue 0 and 60 at +-1 (30 singlets + 30 doublets: 2 + 1, not three equal pieces); '
    'a generic Cartan element of sl6 has %d distinct eigenvalues on the 96 (the A2 at 0), not three spaces of 32' % len(ev6))

# ===================================================================================== F. Spin(9) on the Peirce 1/2 space of h2(O) in h3(O)
head('F. [bit] h3(O) on Cayley-Dickson octonions: derivations f4, the stabiliser of A = h2(O) is so(9), and its action on the Peirce 1/2 space is the spinor module of Cl(9,0) (CAND-023)')
OT8 = np.zeros((8, 8, 8), dtype=np.int64)
for (a, b), s_ in OSIGN.items(): OT8[a, b, a ^ b] = s_
def oconj(x): y = -np.array(x, dtype=np.int64); y[0] = -y[0]; return y
def hmat(v):
    M = np.zeros((3, 3, 8), dtype=np.int64)
    for i in range(3): M[i, i, 0] = v[i]
    x12, x23, x31 = np.array(v[3:11]), np.array(v[11:19]), np.array(v[19:27])
    M[0, 1], M[1, 0] = x12, oconj(x12); M[1, 2], M[2, 1] = x23, oconj(x23); M[2, 0], M[0, 2] = x31, oconj(x31)
    return M
def hmul(X, Y):
    Z = np.zeros((3, 3, 8), dtype=np.int64)
    for i in range(3):
        for j in range(3):
            for k in range(3): Z[i, j] += np.einsum('a,b,abc->c', X[i, k], Y[k, j], OT8)
    return Z
def hcoords(M): return np.array([M[0, 0, 0], M[1, 1, 0], M[2, 2, 0], *M[0, 1], *M[1, 2], *M[2, 0]], dtype=np.int64)
E27 = np.eye(27, dtype=np.int64); JT2 = np.zeros((27, 27, 27), dtype=np.int64); herm_ok = True
for i in range(27):
    for j in range(i, 27):
        X, Y = hmat(E27[i]), hmat(E27[j]); Z = hmul(X, Y) + hmul(Y, X)
        herm_ok &= all(np.array_equal(Z[b, a], oconj(Z[a, b])) for a in range(3) for b in range(3)) and not np.any(Z[[0, 1, 2], [0, 1, 2], 1:])
        JT2[i, j] = JT2[j, i] = hcoords(Z)                                           # 2 (e_i o e_j)
P2 = lambda u, v: np.einsum('i,j,ijk->k', u, v, JT2)
rngF = np.random.default_rng(23); jord = True
for _ in range(10):
    x, y = rngF.integers(-3, 4, 27), rngF.integers(-3, 4, 27)
    jord &= np.array_equal(P2(P2(P2(x, x), y), x), P2(P2(x, x), P2(y, x)))
ONE = np.array([1, 1, 1] + [0] * 24)
chk('bit', 'elad·21', herm_ok and jord and all(np.array_equal(P2(ONE, E27[i]), 2 * E27[i]) for i in range(27)),
    'h3(O) on the 27 coordinates (3 diagonal, x12, x23, x31) with the Cayley-Dickson octonions (product table XOR with a sign, exact integers): X o Y = (XY + YX)/2 is hermitian, has the unit 1, '
    'and satisfies the Jordan identity (x^2 y) x = x^2 (y x) exactly for 10 random integer pairs (seed 23)')
pairsJ = [(i, j) for i in range(27) for j in range(i, 27)]; ar27 = np.arange(27)
Mder = np.zeros((len(pairsJ) * 27, 729), dtype=np.int64)
for t, (i, j) in enumerate(pairsJ):
    for l in range(27):
        row = Mder[t * 27 + l]
        row[l * 27:(l + 1) * 27] += JT2[i, j, :]
        row[ar27 * 27 + i] -= JT2[:, j, l]
        row[ar27 * 27 + j] -= JT2[i, :, l]
BD, DD, ubD, okD = null_exact(Mder)
ASET = [0, 1] + list(range(3, 11)); NOTA = [p for p in range(27) if p not in ASET]
cs = nullspace_sparse([r for r in ({t: int(BD[p * 27 + q, t]) for t in range(BD.shape[1]) if BD[p * 27 + q, t]} for p in NOTA for q in ASET) if r], BD.shape[1]) if okD else []
def intvec(v, n):
    den = 1
    for x in v.values(): den = den * x.denominator // int(np.gcd(den, x.denominator))
    out = np.zeros(n, dtype=np.int64)
    for t, x in v.items(): out[t] = int(x * den)
    return out
STAB = [(BD @ intvec(v, BD.shape[1])).reshape(27, 27) for v in cs]
FV = [E27[0] - E27[1]] + [E27[3 + k] for k in range(8)]
def rho9(S):
    out = np.zeros((9, 9), dtype=np.int64); ok = True
    for b, fb in enumerate(FV):
        v = S @ fb; ok &= v[2] == 0 and not np.any(v[11:]) and v[0] == -v[1]; out[0, b] = v[0]; out[1:, b] = v[3:11]
    return out, ok
R9 = [rho9(S) for S in STAB]; R16 = [S[11:, 11:] for S in STAB]
blocks_ok = all(not np.any(S[11:, :11]) and not np.any(S[:11, 11:]) and not np.any(S[:, 0] + S[:, 1]) and not np.any(S[:, 2]) for S in STAB)
r9rank = rank_mod_p(np.array([m.ravel() for m, _ in R9])) if R9 else 0
chk('bit', 'elad·21', okD and ubD == 52 and len(STAB) == 36 and blocks_ok and all(ok and np.array_equal(m, -m.T) for m, ok in R9) and r9rank == 36,
    'derivations of h3(O): the 10206 x 729 integer system D(x o y) = Dx o y + x o Dy has nullity exactly %d (52 rational solutions checked in integers, denominator %s; rank mod p of the normal matrix 677): f4; '
    'those preserving A = h2(O) (diagonal 1, 2 and x12): %d; they kill 1_A and e3, preserve the Peirce 1/2 space x23 + x31 (16), and act on the 9-dimensional traceless part of A by antisymmetric matrices '
    'in the orthonormal basis (e1 - e2, x12), faithfully (rank %d = dim so(9)): the stabiliser is so(9)' % (ubD, DD, len(STAB), r9rank))
def mvmul(x, y, n=9):
    out = {}
    for a, ca in x.items():
        for b, cb in y.items(): k = a ^ b; out[k] = out.get(k, 0) + sgn(a, b, n) * ca * cb
    return {k: v for k, v in out.items() if v}
FG = [15, 240, 51, 85, 511]                                                       # e0123, e4567, e0145, e0246, the volume element e0..8
okf = all(sgn(f, f, 9) == 1 for f in FG) and all(sgn(f, g, 9) == sgn(g, f, 9) for f in FG for g in FG)
PP = {0: 1}
for f in FG: PP = mvmul(PP, {0: 1, f: 1})
Hs = {0}
for f in FG: Hs |= {h ^ f for h in Hs}
REPS = sorted({min(B ^ h for h in Hs) for B in range(512)}); VB = {R: mvmul({R: 1}, PP) for R in REPS}
GAM = []
for i in range(9):
    Gm = np.zeros((16, 16), dtype=np.int64)
    for col, R in enumerate(REPS):
        w = mvmul({1 << i: 1}, VB[R])
        for row, R2 in enumerate(REPS):
            if w == VB[R2]: Gm[row, col] = 1; break
            if w == {k: -v for k, v in VB[R2].items()}: Gm[row, col] = -1; break
    GAM.append(Gm)
I16 = np.eye(16, dtype=np.int64)
cliff = all(np.array_equal(GAM[i] @ GAM[j] + GAM[j] @ GAM[i], 2 * int(i == j) * I16) for i in range(9) for j in range(9))
chk('bit', 'elad·22', okf and len(PP) == 32 and mvmul(PP, PP) == {k: 32 * v for k, v in PP.items()} and len(REPS) == 16 and cliff,
    'Cl(9,0) by the bit rule: e0123, e4567, e0145, e0246 and the central e0..8 square to +1 and commute; (1 + f)/2 over the five gives an idempotent with 32 terms; its left ideal has %d basis vectors e_R P (coset representatives), '
    'on which the nine generators act by signed permutation matrices with gamma_i gamma_j + gamma_j gamma_i = 2 delta_ij: the 16-dimensional spinor module' % len(REPS))
SIG4 = [sum(int(m[a, b]) * GAM[a] @ GAM[b] for a in range(9) for b in range(9)) for m, _ in R9]       # 4 sigma(M), sigma(M) = (1/4) sum M_ab gamma_a gamma_b
cov = all(np.array_equal(S4 @ GAM[k] - GAM[k] @ S4, 4 * sum(int(m[i, k]) * GAM[i] for i in range(9))) for S4, (m, _) in zip(SIG4, R9) for k in range(9))
def hom_space(As, Bs):
    """{T : A T = T B for all pairs}, T of shape (dim A) x (dim B); integer matrices"""
    na, nb = As[0].shape[0], Bs[0].shape[0]
    return null_exact(np.vstack([np.kron(A, np.eye(nb, dtype=np.int64)) - np.kron(np.eye(na, dtype=np.int64), B.T) for A, B in zip(As, Bs)]))
TGT = [4 * m for m, _ in R9] if FAULT == 'INTERTW_VEC' else SIG4
BT, DT, ubT, okT = hom_space([4 * r for r in R16], TGT)
Tm = BT[:, 0].reshape(16, -1) if (BT is not None and BT.shape[1] == 1) else None
chk('bit', 'elad·22', cov and ubT == 1 and okT and Tm is not None and Tm.shape == (16, 16) and rank_mod_p(Tm) == 16,
    'with sigma(M) = (1/4) sum M_ab gamma_a gamma_b ([sigma(M), gamma(v)] = gamma(Mv), exact), the intertwiners T with rho_16(X) T = T sigma(rho_9(X)) for the 36 stabiliser elements form a space of dimension %d '
    '(exact: 9216 integer equations, a rational solution checked in integers, rank mod p of the normal matrix 255); T has rank %s: the Peirce 1/2 space is the real spinor module of Spin(9)'
    % (ubT, rank_mod_p(Tm) if Tm is not None else None))
g9 = np.array([[float(np.trace(a @ b)) for b, _ in R9] for a, _ in R9]); gi = np.linalg.inv(g9)
cas = lambda reps, sc: sum(gi[a, b] * (reps[a] / sc) @ (reps[b] / sc) for a in range(36) for b in range(36))
C16, CSp, C9 = cas([r.astype(float) for r in R16], 1.0), cas([s.astype(float) for s in SIG4], 4.0), cas([m.astype(float) for m, _ in R9], 1.0)
c16, cSp, c9 = C16[0, 0], CSp[0, 0], C9[0, 0]
chk('std', 'elad·23', np.allclose(C16, c16 * np.eye(16)) and np.allclose(CSp, cSp * np.eye(16)) and np.allclose(C9, c9 * np.eye(9)) and abs(c16 - cSp) < 1e-9 and abs(c9 - c16) > 1e-3,
    'numpy: the Casimir of so(9) (inverse of the trace form on the 9) is scalar on the Peirce 1/2 space (%.6f), on the Clifford spinor module (%.6f) and on the vector (%.6f): equal on the two 16s, different on the 9' % (c16, cSp, c9))
_, _, ub9, _ = hom_space([r for r in R16], [m for m, _ in R9])
fr = [{s: int(STAB[s][p, c]) for s in range(36) if STAB[s][p, c]} for c in (0, 1) for p in range(27)]
cs8 = nullspace_sparse([r for r in fr if r], 36)
SO8 = [sum(int(intvec(v, 36)[s]) * STAB[s] for s in range(36)) for v in cs8]
X23 = list(range(11, 19)); RESTX = [p for p in range(27) if p not in X23]
x23ok = all(not np.any(S[np.ix_(RESTX, X23)]) for S in SO8)
SIG8 = [sum(int(rho9(S)[0][a, b]) * GAM[a] @ GAM[b] for a in range(9) for b in range(9)) for S in SO8]
_, _, ub8, ok8 = hom_space(SIG8, [4 * S[11:19, 11:19] for S in SO8])
chk('ctl', 'elad·23', ub9 == 0 and len(SO8) == 28 and x23ok and ub8 == 1 and ok8,
    'controls: no intertwiner between the vector 9 and the 16 (dimension %d); restricted to the frame so(8) (stabiliser of e1, e2, e3: %d dimensions) the block x23 has a one-dimensional space of intertwiners into the spinor module (%d)' % (ub9, len(SO8), ub8))

# ===================================================================================== G. McKay for the binary icosahedral group
head('G. [bit] the binary icosahedral group as 120 unit rotors of the even part of Cl(3,0) over Q(sqrt5); characters and the McKay graph (CAND-140)')
class Q5:
    __slots__ = ('a', 'b')
    def __init__(self, a, b=0): self.a = F(a); self.b = F(b)
    def __add__(s, o): o = o if isinstance(o, Q5) else Q5(o); return Q5(s.a + o.a, s.b + o.b)
    __radd__ = __add__
    def __neg__(s): return Q5(-s.a, -s.b)
    def __sub__(s, o): return s + (-(o if isinstance(o, Q5) else Q5(o)))
    def __mul__(s, o): o = o if isinstance(o, Q5) else Q5(o); return Q5(s.a * o.a + 5 * s.b * o.b, s.a * o.b + s.b * o.a)
    __rmul__ = __mul__
    def __eq__(s, o): o = o if isinstance(o, Q5) else Q5(o); return s.a == o.a and s.b == o.b
    def __hash__(s): return hash((s.a, s.b))
    def gal(s): return Q5(s.a, -s.b)
    def __float__(s): return float(s.a) + float(s.b) * 5 ** 0.5
EV = [0, 3, 5, 6]; EVP = {a: t for t, a in enumerate(EV)}; S3T = {(a, b): sgn(a, b, 3) for a in EV for b in EV}
def rmul(x, y):
    out = [Q5(0)] * 4
    for i, a in enumerate(EV):
        for j, b in enumerate(EV): out[EVP[a ^ b]] = out[EVP[a ^ b]] + x[i] * y[j] * S3T[(a, b)]
    return tuple(out)
def rrev(x): return (x[0], -x[1], -x[2], -x[3])
half = F(1, 2); phi = Q5(half, half); phinv = phi - 1
ONE4 = (Q5(1), Q5(0), Q5(0), Q5(0))
gI1 = (phi * half, phinv * half, Q5(half), Q5(0)); gI2 = (Q5(half), Q5(half), Q5(half), Q5(half))   # phi/2 + (1/(2 phi)) e12 + (1/2) e13 ; (1 + e12 + e13 + e23)/2
def order(g):
    x, n = g, 1
    while x != ONE4: x = rmul(x, g); n += 1
    return n
GRP = {ONE4}; todo = [ONE4]
while todo:
    x = todo.pop()
    for g in (gI1, gI2):
        y = rmul(x, g)
        if y not in GRP: GRP.add(y); todo.append(y)
fkey = lambda x: tuple(round(float(c), 12) for c in x)
GL = sorted(GRP, key=fkey); cls_of = {}; CLS = []
for x in GL:
    if x in cls_of: continue
    orb = {x}; todo = [x]
    while todo:
        y = todo.pop()
        for g in (gI1, gI2):
            z = rmul(rmul(g, y), rrev(g))
            if z not in orb: orb.add(z); todo.append(z)
    for y in orb: cls_of[y] = len(CLS)
    CLS.append(sorted(orb, key=fkey))
hC = len(CLS); SZ = [len(c) for c in CLS]; TR = [2 * c[0][0] for c in CLS]; cid = cls_of[ONE4]
chi = {1: [Q5(1)] * hC, 2: TR}
for n_ in range(2, 6): chi[n_ + 1] = [TR[t] * chi[n_][t] - chi[n_ - 1][t] for t in range(hC)]
CH = [chi[n_] for n_ in range(1, 7)] + [[v.gal() for v in chi[n_]] for n_ in (2, 3)] + [[TR[t] * TR[t].gal() for t in range(hC)]]
def inner(c1, c2): return sum((SZ[t] * c1[t] * c2[t] for t in range(hC)), Q5(0)) * F(1, sum(SZ))
orth = all(inner(CH[i], CH[j]) == Q5(int(i == j)) for i in range(len(CH)) for j in range(len(CH)))
DIMS = [int(CH[i][cid].a) for i in range(len(CH))]
chk('bit', 'elad·24', all(rmul(g, rrev(g)) == ONE4 for g in (gI1, gI2)) and (order(gI1), order(gI2)) == (10, 6) and len(GRP) == 120 and sorted(SZ) == [1, 1, 12, 12, 12, 12, 20, 20, 30]
    and len({TR[t] for t in range(hC)}) == 9 and orth and sorted(DIMS) == [1, 2, 2, 3, 3, 4, 4, 5, 6],
    'even part of Cl(3,0) by the bit rule (labels 0, 12, 13, 23) over Q(sqrt5): two unit rotors of orders 10 and 6 generate %d elements in %d conjugacy classes of sizes %s (one per value of the trace 2 x scalar part); '
    'the characters of the SU(2) representations of dimension 1..6 restricted (Chebyshev recursion in the trace) the Galois conjugates of those of dimension 2 and 3, and the product of the two 2-dimensional ones (4\') are orthonormal (exact over Q(sqrt5)); the 4-dimensional SU(2) character is Galois-invariant (rational): the full character table, dimensions %s'
    % (len(GRP), hC, sorted(SZ), DIMS))
NMK = [[inner([TR[t] * CH[i][t] for t in range(hC)], CH[j]) for j in range(9)] for i in range(9)]
NM = np.array([[int(v.a) for v in row] for row in NMK]) if all(v.b == 0 and v.a.denominator == 1 for row in NMK for v in row) else None
th8 = int(np.argmax(COEF.sum(1))); EXT8 = [int(NEG[th8])] + SIMP; AFF8 = G8[np.ix_(EXT8, EXT8)]; MARK8 = [1] + [int(x) for x in COEF[th8]]
def iso_labelled(adjA, labA, adjB, labB):
    n = len(labA)
    if sorted(labA) != sorted(labB): return None
    groups = sorted(set(labA)); Ag = [[i for i in range(n) if labA[i] == L] for L in groups]; Bg = [[j for j in range(n) if labB[j] == L] for L in groups]
    for choice in itertools.product(*[itertools.permutations(b) for b in Bg]):
        perm = {}
        for a, b in zip(Ag, choice): perm.update(dict(zip(a, b)))
        if all(adjA[i][j] == adjB[perm[i]][perm[j]] for i in range(n) for j in range(n)): return perm
    return None
ADJ8 = (2 * np.eye(9, dtype=np.int64) - AFF8).tolist()
MT10 = [3, 2, 4, 6, 5, 4, 3, 2, 1]                                                # check_T10.py: E9 null root marks, chain alpha_1..alpha_8 with alpha_0 on alpha_3
ADJT10 = [[int(abs(i - j) == 1 and min(i, j) >= 1 or {i, j} == {0, 3}) for j in range(9)] for i in range(9)]
chk('bit', 'elad·25', NM is not None and np.array_equal(NM, NM.T) and not np.any(np.diag(NM)) and np.all(AFF8 @ np.array(MARK8) == 0) and MARK8 == [1, 2, 3, 4, 6, 5, 4, 3, 2]
    and iso_labelled(NM.tolist(), DIMS, ADJ8, MARK8) is not None and iso_labelled(NM.tolist(), DIMS, ADJT10, MT10) is not None,
    'McKay matrix n_ij = <chi_2 chi_i, chi_j> (exact integers): symmetric, 0/1, zero diagonal, and 2 - n is the Cartan matrix of the affine E8 diagram (extended by minus the highest root, null vector %s) '
    'under a bijection that sends each irreducible representation to the node whose mark is its dimension; the same graph carries the marks %s of check_T10.py' % (MARK8, MT10))
def qmat(q): a, b, c, d = q; return np.array([[a + b * 1j, c + d * 1j], [-c + d * 1j, a - b * 1j]])
def mckay_float(gens):
    key = lambda m: tuple(np.round(np.concatenate([m.real.ravel(), m.imag.ravel()]), 8) + 0.0)
    els = [np.eye(2, dtype=complex)]; idx = {key(els[0]): 0}; todo = [0]
    while todo:
        i = todo.pop()
        for g in gens:
            m = els[i] @ g; k = key(m)
            if k not in idx: idx[k] = len(els); els.append(m); todo.append(idx[k])
    n = len(els); mt = np.array([[idx[key(els[i] @ els[j])] for j in range(n)] for i in range(n)]); inv = [idx[key(np.linalg.inv(m))] for m in els]
    cl = -np.ones(n, dtype=int); classes = []
    for i in range(n):
        if cl[i] < 0:
            orb = sorted({int(mt[mt[g, i], inv[g]]) for g in range(n)})
            for x in orb: cl[x] = len(classes)
            classes.append(orb)
    h = len(classes); sz = np.array([len(c) for c in classes], dtype=float); Cm = np.zeros((h, h, h))
    for r in range(h):
        for x in classes[r]:
            for s in range(h):
                for y in classes[s]: Cm[r, s, cl[mt[x, y]]] += 1
    Cm /= sz[None, None, :]
    rng = np.random.default_rng(140); Xm = sum(rng.normal() * Cm[r] for r in range(h)); w, V = np.linalg.eig(Xm); e = cl[0]; chars = []
    for t in range(h):
        v = V[:, t] / V[e, t]; d = np.sqrt(n / np.sum(np.abs(v) ** 2 / sz)); chars.append(d * v / sz)
    trn = np.array([np.trace(els[classes[t][0]]) for t in range(h)])
    G_ = np.array([[np.sum(sz * chars[i] * np.conj(chars[j])) / n for j in range(h)] for i in range(h)])
    NMf = np.array([[np.sum(sz * trn * chars[i] * np.conj(chars[j])) / n for j in range(h)] for i in range(h)])
    return dict(n=n, sz=sorted(int(x) for x in sz), dims=[int(round(c[e].real)) for c in chars], NM=np.rint(NMf.real).astype(int), err=max(np.abs(NMf - np.rint(NMf.real)).max(), np.abs(G_ - np.eye(h)).max()), chars=chars, tr=trn, classes=classes)
s5 = 5 ** 0.5; phf = (1 + s5) / 2
GENI = [qmat((phf / 2, 1 / (2 * phf), 0.5, 0.0)), qmat((0.5, 0.5, 0.5, 0.5))]
GENO = [qmat((2 ** -0.5, 2 ** -0.5, 0.0, 0.0)), qmat((0.5, 0.5, 0.5, 0.5))]
GENZ = [np.diag([np.exp(1j * np.pi / 4), np.exp(-1j * np.pi / 4)])]
mI = mckay_float(GENO if FAULT == 'MCKAY_OCT' else GENI)
chk('std', 'elad·26', mI['n'] == 120 and mI['err'] < 1e-8 and sorted(mI['dims']) == [1, 2, 2, 3, 3, 4, 4, 5, 6] and iso_labelled(mI['NM'].tolist(), mI['dims'], ADJ8, MARK8) is not None,
    'numpy: unit quaternions (phi + i/phi + j)/2 and (1 + i + j + k)/2 as 2 x 2 complex matrices, closure %d elements, Burnside class-multiplication eigenvectors give the character table (orthonormal to %.0e) '
    'with dimensions %s and the same McKay graph: affine E8 with the marks as dimensions' % (mI['n'], mI['err'], sorted(mI['dims'])))
match = True
for t in range(hC):
    tf = float(TR[t]); s_ = [u for u in range(len(mI['classes'])) if abs(mI['tr'][u].real - tf) < 1e-8]
    match &= len(s_) == 1 and len(mI['classes'][s_[0]]) == SZ[t] if mI['n'] == 120 else False
rowsE = sorted(tuple(np.round(float(CH[i][t]), 6) for t in sorted(range(hC), key=lambda t: float(TR[t]))) for i in range(9))
rowsF = sorted(tuple(np.round(float(c[u].real), 6) for u in sorted(range(len(mI['tr'])), key=lambda u: mI['tr'][u].real)) for c in mI['chars'])
chk('bit==std', 'elad·26', match and rowsE == rowsF, 'the exact character table (Q(sqrt5), classes matched by the trace) and the numpy table agree entry by entry (to 1e-6)')
mO, mZ = mckay_float(GENO), mckay_float(GENZ)
th7 = max(E7I, key=lambda k: COEF[k].sum()); EXT7 = [int(NEG[th7])] + SIMP[:7]; AFF7 = G8[np.ix_(EXT7, EXT7)]; MARK7 = [1] + [int(x) for x in COEF[th7][:7]]
ADJ7 = (2 * np.eye(8, dtype=np.int64) - AFF7).tolist()
cyc = mZ['NM']; degs = cyc.sum(1)
chk('ctl', 'elad·26', mO['n'] == 48 and sorted(mO['dims']) == [1, 1, 2, 2, 2, 3, 3, 4] and np.all(AFF7 @ np.array(MARK7) == 0) and iso_labelled(mO['NM'].tolist(), mO['dims'], ADJ7, MARK7) is not None
    and mZ['n'] == 8 and all(d == 1 for d in mZ['dims']) and np.all(degs == 2) and np.array_equal(cyc, cyc.T),
    'controls: the binary octahedral group (48) gives dimensions %s and the affine E7 diagram (marks %s); the cyclic group of order 8 gives 8 one-dimensional characters on a cycle (affine A7, every node of degree 2)' % (sorted(mO['dims']), MARK7))

finish(STEP)
