#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""abs_ring.py: Atiyah, Bott and Shapiro, "Clifford modules" (Topology 3, 1964), read with the labels: the groups A_k of graded Clifford
modules modulo those restricted from one generator more, and their ring under the graded tensor product, computed on the bit rule up to
degree 16.      python3 abs_ring.py [--fault NAME]

What is read (the paper's definitions, as reproduced in D. Chua, "Clifford Algebras and Bott Periodicity", section 1, and in
arXiv:2310.05061, section 3): C_k is the Clifford algebra of R^k with generators of square -1 (the Atlas's Cl(0,k)); M(C_k) is the
Grothendieck group of graded C_k-modules; the inclusion C_k -> C_(k+1) restricts modules, i*: M(C_(k+1)) -> M(C_k); A_k = M(C_k)/i* M(C_(k+1)).
C_(k+8) = C_k (x) R(16), and A_* = (+) A_k is a graded ring under the graded tensor product.  Table 2 of the paper: A_k = Z2, Z2, 0, Z, 0, 0, 0, Z
for k = 1..8, with one irreducible graded module except at k = 4n, where the two are exchanged by the grading.  The theorem that is not
finite (read, not computed): A_* -> KO^(-*)(point) is an isomorphism of graded rings (ABS; arXiv:2310.05061, 3.1.1), whose proof uses
Kuiper's theorem and the loop spaces of Fredholm operators (Chua, sections 2-4).

What is computed here, exactly, on the bit rule.  A graded C_k-module is a Cl(1,k)-module (the grading operator is one more label of
square +1 anticommuting with the generators), so A_k = coker(N(Cl(1,k+1)) -> N(Cl(1,k))) with N the free group on the irreducibles.
R1. the groups A_k for k = 0..16 (the cells Cl(1,k), k <= 17): Z Z2 Z2 0 Z 0 0 0 Z Z2 Z2 0 Z 0 0 0 Z, the paper's Table 2 twice over, and the
    dimensions 2, 4, 8, 8, 16, 16, 16, 16 of the irreducible graded modules for k = 1..8 (the paper's 2 dim M_0), 32 ... 512 for k = 9..17;
    the other sign (C'_k, generators of square +1): A'_k, k = 0..9, the same list.
R2. the generators: eta (A_1), alpha (A_4, the irreducible of Cl(1,4) on which the volume element is +1), beta (A_8, the 16-dimensional
    irreducible of Cl(1,8) with volume element +1), and every product of them by concatenation of labels (the graded tensor product):
    eta^2 generates A_2; eta^3 = 0 (A_3 = 0) and eta^4 = 0 in the Z of A_4 (the 16-dimensional module restricts from Cl(1,5));
    eta.alpha = 0 (A_5 = 0); alpha^2 = 4 beta; eta.beta and eta^2.beta generate A_9 and A_10; alpha.beta generates A_12; beta^2 generates
    A_16; alpha^2.beta = 4 beta^2.  So in degrees <= 16 the ring is Z[eta, alpha, beta]/(2 eta, eta^3, eta.alpha, alpha^2 - 4 beta), the ring
    KO^(-*)(point) as recalled, and multiplication by beta is an isomorphism A_k -> A_(k+8) for k = 0..8 (the paper's periodicity on
    the finite side).
R3. the complex groups and ring (bit rule: the centre counts the simple summands, the volume element tells the two apart): A^c_k = Z for k
    even and 0 for k odd, k = 0..12; mu (the irreducible complex graded module of C_2, complex dimension 2) has mu^2, mu^3, ... generating
    A^c_4, A^c_6, ..., A^c_12: the ring Z[mu], period 2.
[bit]  minimal left ideals of the bit rule (steps15_17/bitcliff.py): f = prod (1 + e_a)/2 over a maximal set of commuting labels of
       square +1, the module as signed permutation matrices, irreducibility from the exact commutant (solid_cube.py), the two irreducibles
       of a two-summand cell told apart by the central volume element, multiplicities from exact ranks, integer Smith normal form.
[std]  numpy, no label: the cells Cl(1,k) for k <= 8 as Kronecker words of 2 x 2 real matrices, their irreducibles as eigenspaces of a random
       symmetric commutant element, the modules of Cl(1,k+8) as the graded tensor product with the 16-dimensional module of Cl(1,8), the
       classes from dimensions and the trace of the volume element; the same products, the same cokernels (determinantal divisors to k = 9).
[ctl]  UNGRADED (the grading dropped: the list moves by one), NOSWAP (the two irreducibles assumed kept by the dropped generator),
       ALPHA2 (alpha^2 = 2 beta asserted), ETA4 (eta^4 != 0 asserted), PERIOD (beta^2 = 0 asserted), CPLX (the real summand count used
       for the complex one), each wrong version exits 1.
Scope: the cells Cl(1,k), k <= 17, and Cl(k,0), k <= 10 (bit); Cl(1,k), k <= 17 (std, with the base cells k <= 8 built from scratch).
Command: python3 abs_ring.py   (from this folder, or python3 selfcheck/proofs/abs_ring.py from the root of the checks; standard library
and numpy)."""
import os, sys, io, random, itertools, contextlib, time
from fractions import Fraction as Fr
from math import gcd
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                         # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                         # selfcheck/
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p); sys.path.insert(0, _here)
from bitcliff import Alg, sig
_argv = sys.argv; sys.argv = [_argv[0]]
try:
    with contextlib.redirect_stdout(io.StringIO()):
        from solid_cube import commutant_basis, classify               # exact commutant of a signed-permutation module, its type
finally:
    sys.argv = _argv

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('UNGRADED', 'NOSWAP', 'ALPHA2', 'ETA4', 'PERIOD', 'CPLX')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
KOM = ['Z', 'Z2', 'Z2', '0', 'Z', '0', '0', '0']        # the paper's Table 2 (A_k, k = 1..8, read: Z2 Z2 0 Z 0 0 0 Z), placed at k mod 8; used only to compare
KMAX = 16
T0 = time.time()

# ------------------------------------------------------------------------------------------------ exact integer linear algebra (as in aty_twisted_k.py)
def _norm(r):
    g = 0
    for x in r: g = gcd(g, x)
    return [x // g for x in r] if g > 1 else r
def echelon(rows):
    piv = []
    for r in rows:
        r = [int(x) for x in r]
        for c, pr in piv:
            if r[c]:
                a, b = pr[c], r[c]; r = _norm([a * x - b * y for x, y in zip(r, pr)])
        nz = next((i for i, x in enumerate(r) if x), None)
        if nz is not None: piv.append((nz, r))
    return piv
def rank_int(rows): return len(echelon(rows)) if rows else 0
def smith(A):
    """integer Smith normal form: (invariant factors, U) with U A V diagonal; A by its rows"""
    A = [[int(x) for x in r] for r in A]; r = len(A); c = len(A[0]) if r else 0
    U = [[int(i == j) for j in range(r)] for i in range(r)]
    diag = []; t = 0
    def swap_rows(i, j): A[i], A[j] = A[j], A[i]; U[i], U[j] = U[j], U[i]
    def swap_cols(i, j):
        for row in A: row[i], row[j] = row[j], row[i]
    while t < min(r, c):
        nz = [(abs(A[i][j]), i, j) for i in range(t, r) for j in range(t, c) if A[i][j]]
        if not nz: break
        _, i, j = min(nz); swap_rows(t, i); swap_cols(t, j)
        while True:
            changed = False
            for i in range(t + 1, r):
                if A[i][t]:
                    qq = A[i][t] // A[t][t]
                    A[i] = [a - qq * b for a, b in zip(A[i], A[t])]; U[i] = [a - qq * b for a, b in zip(U[i], U[t])]
                    if A[i][t]: swap_rows(t, i); changed = True
            for j in range(t + 1, c):
                if A[t][j]:
                    qq = A[t][j] // A[t][t]
                    for row in A: row[j] -= qq * row[t]
                    if A[t][j]: swap_cols(t, j); changed = True
            if changed: continue
            bad = [(i, j) for i in range(t + 1, r) for j in range(t + 1, c) if A[i][j] % A[t][t]]
            if not bad: break
            i = bad[0][0]; A[t] = [a + b for a, b in zip(A[t], A[i])]; U[t] = [a + b for a, b in zip(U[t], U[i])]
        if A[t][t] < 0: A[t] = [-a for a in A[t]]; U[t] = [-a for a in U[t]]
        diag.append(A[t][t]); t += 1
    return diag, U
def group_name(free, tors):
    parts = ['Z'] * free + ['Z%d' % d for d in tors]
    return '+'.join(parts) if parts else '0'
def coker(M):
    diag, U = smith(M)
    free = len(M) - len(diag)
    return group_name(free, [d for d in diag if d > 1]), (diag, U)
def coker_class(cdata, v):
    diag, U = cdata; w = [sum(a * b for a, b in zip(row, v)) for row in U]
    return tuple([w[i] % diag[i] for i in range(len(diag)) if diag[i] > 1] + w[len(diag):])
def _det(M):
    M = [[Fr(x) for x in r] for r in M]; n = len(M); det = Fr(1)
    for c in range(n):
        piv = next((i for i in range(c, n) if M[i][c] != 0), None)
        if piv is None: return 0
        if piv != c: M[c], M[piv] = M[piv], M[c]; det = -det
        det *= M[c][c]
        for i in range(c + 1, n):
            f = M[i][c] / M[c][c]; M[i] = [a - f * b for a, b in zip(M[i], M[c])]
    return int(det)
def coker_divisors(M):
    r = len(M); c = len(M[0]) if r else 0; ds = [1]
    for k in range(1, min(r, c) + 1):
        g = 0
        for rows in itertools.combinations(range(r), k):
            for cols in itertools.combinations(range(c), k):
                g = gcd(g, abs(_det([[M[i][j] for j in cols] for i in rows])))
        if g == 0: break
        ds.append(g)
    inv = [ds[k] // ds[k - 1] for k in range(1, len(ds))]
    return group_name(r - len(inv), [e for e in inv if e > 1])

# ================================================================================================ the bit-rule modules
def comm_set(alg, norders):
    best = []; rg = random.Random(7 + 31 * alg.n + sum(1 for e in alg.eps if e > 0))
    orders = [list(range(1, alg.N)), list(range(alg.N - 1, 0, -1))]
    for _ in range(norders):
        o = list(range(1, alg.N)); rg.shuffle(o); orders.append(o)
    for order in orders:
        gens = []; span = {0}
        for a in order:
            if a in span or alg.sq(a) != 1: continue
            if all(alg.comm_sign(a, g) == 1 for g in gens):
                new = {s ^ a for s in span}
                if all(alg.sq(x) == 1 for x in new): gens.append(a); span |= new
        if len(gens) > len(best): best = gens
    return best
def fmm(A, B):
    """exact integer product of two signed-permutation-like integer matrices through BLAS floats (entries stay far below 2^53)"""
    C = A.astype(np.float64) @ B.astype(np.float64); Ci = np.rint(C).astype(np.int64)
    assert np.array_equal(Ci.astype(np.float64), C); return Ci
def mprod(mats, m):
    out = np.eye(m, dtype=np.int64)
    for R in mats: out = fmm(out, R)
    return out
def anticomm_ok(mods, eps, m):
    """the Clifford relations R_i R_j + R_j R_i = 2 eps_i delta_ij on the module (exact, through fmm)"""
    n = len(mods); I = np.eye(m, dtype=np.int64)
    for i in range(n):
        for j in range(i, n):
            P = fmm(mods[i], mods[j]); Q = P if i == j else fmm(mods[j], mods[i])
            if not np.array_equal(P + Q, (2 * eps[i] if i == j else 0) * I): return False
    return True
def build_cell(p, q):
    """the minimal module(s) of Cl(p,q) from the bit rule: f = prod (1 + e_a)/2, the ideal Cl f on the cosets of the span"""
    alg = Alg(sig(p, q)); n = alg.n; N = alg.N
    if n == 0: rho, m = [], 1
    else:
        gens = comm_set(alg, 12 if n <= 8 else (4 if n <= 12 else 2))
        k = len(gens); span = {0}
        for a in gens: span |= {s ^ a for s in span}
        tau = {}
        for J in range(1 << k):
            prod = {0: 1}
            for j in range(k):
                if J >> j & 1: prod = alg.mul(prod, {gens[j]: 1})
            (mm, cf), = prod.items(); tau[mm] = cf
        coset = {}; reps = []
        for a in range(N):
            if a not in coset:
                reps.append(a)
                for mm in span: coset[a ^ mm] = (a, mm)
        m = len(reps); idx = {r: i for i, r in enumerate(reps)}
        rho = []
        for i in range(n):
            R = np.zeros((m, m), dtype=np.int64)
            for r in reps:
                s, c = alg.blade_mul(1 << i, r); r2, mm = coset[c]; s2, _ = alg.blade_mul(r2, mm)
                R[idx[r2], idx[r]] = s * s2 * tau[mm]
            rho.append(R)
    I = np.eye(m, dtype=np.int64)
    ok_rel = anticomm_ok(rho, alg.eps, m)
    basis = commutant_basis(rho, m) if n else [I]
    typ, els = classify(basis, m)
    J = els[0] if typ in ('C', 'H') else None                                 # a complex structure in the commutant (J^2 = -1), when there is one
    d = len(basis); summ = Fr(N * d, m * m)
    om = mprod(rho, m)
    irreps = [rho]
    if summ == 2:
        s = 1 if np.array_equal(om, I) else (-1 if np.array_equal(om, -I) else 0)
        neg = [-R for R in rho]
        irreps = [rho, neg] if s == 1 else [neg, rho]
    else: s = None
    return {'p': p, 'q': q, 'n': n, 'eps': alg.eps, 'alg': alg, 'm': m, 'irreps': irreps, 'type': typ, 'd': d, 'summ': summ, 'ok_rel': ok_rel, 'om_sign': s,
            'ncent': len(alg.center_blades()), 'J': J}

def module_class(mods, cell, noswap=False, m=None):
    """multiplicities of the irreducibles of `cell` in a module given by its generator matrices: the dimension, and on a two-summand cell the trace of
    the volume element W (W^2 = 1 exactly, so dim ker(W - 1) = (m + tr W)/2: exact integers)"""
    m = mods[0].shape[0] if mods else m; I = np.eye(m, dtype=np.int64)
    ok = anticomm_ok(mods, cell['eps'], m)
    if len(cell['irreps']) == 1: return ok, [m // cell['m']]
    W = mprod(mods, m)
    assert np.array_equal(fmm(W, W), I)
    t = int(np.trace(W)); assert (m + t) % 2 == 0
    dp = (m + t) // 2; dm = (m - t) // 2
    assert dp % cell['m'] == 0 and dm % cell['m'] == 0
    if noswap: return ok, [m // cell['m'], 0]
    return ok, [dp // cell['m'], dm // cell['m']]
def restrict(big, drop, small, noswap=False):
    """integer matrix: rows the irreducibles of `small`, columns those of `big`, restricted by dropping generator `drop`"""
    assert tuple(e for i, e in enumerate(big['eps']) if i != drop) == small['eps']
    cols = []
    for T in big['irreps']:
        R = [T[i] for i in range(len(T)) if i != drop]
        ok, v = module_class(R, small, noswap, m=T[0].shape[0]); assert ok
        cols.append(v)
    return [[cols[j][i] for j in range(len(cols))] for i in range(len(small['irreps']))]
def gtensor(M, N):
    """the graded tensor product of two graded modules (generator 0 = the grading in both): concatenation of the labels"""
    mM, mN = M[0].shape[0], N[0].shape[0]
    IM, IN = np.eye(mM, dtype=np.int64), np.eye(mN, dtype=np.int64)
    return [np.kron(M[0], N[0])] + [np.kron(R, IN) for R in M[1:]] + [np.kron(M[0], R) for R in N[1:]]

CELL = {}
for k in range(0, KMAX + 2): CELL[(1, k)] = build_cell(1, k)
for k in range(0, 11): CELL[(k, 0)] = build_cell(k, 0)
TA = time.time() - T0
GRP = {}          # k -> (name, cokernel data, restriction matrix) of A_k = coker(N(Cl(1,k+1)) -> N(Cl(1,k)))
def A_group(k, noswap=False):
    if (k, noswap) not in GRP:
        M = restrict(CELL[(1, k + 1)], 1 + k, CELL[(1, k)], noswap)
        nm, cd = coker(M); GRP[(k, noswap)] = (nm, cd, M)
    return GRP[(k, noswap)]
def A_class(mods, k):
    """class in A_k of a Cl(1,k)-module given by its matrices"""
    ok, v = module_class(mods, CELL[(1, k)]); nm, cd, _ = A_group(k)
    return ok, coker_class(cd, v), v
def Ap_group(k):
    """A'_k: graded modules of Cl(k,0) (= modules of Cl(k+1,0)) modulo those from Cl(k+2,0)"""
    M = restrict(CELL[(k + 2, 0)], k + 1, CELL[(k + 1, 0)])
    return coker(M)[0]

# ================================================================================================ R1. the groups
head('R1. the groups A_k = coker(N(Cl(1,k+1)) -> N(Cl(1,k))), k = 0..%d (the paper: M(C_k)/i* M(C_(k+1)), graded C_k-modules = Cl(1,k)-modules)' % KMAX)
okrel = all(c['ok_rel'] for c in CELL.values()); okdiv = all(c['type'] in ('R', 'C', 'H') and c['d'] in (1, 2, 4) for c in CELL.values())
okdim = all(c['summ'] * c['m'] * c['m'] == (1 << c['n']) * c['d'] for c in CELL.values())
chk('bit', okrel and okdiv and okdim, 'abs.R1: %d cells (Cl(1,k), k <= %d; Cl(k,0), k <= 10): the ideal matrices obey the Clifford relations, the exact commutant is R, C or H, and (summands) x m^2 = 2^n x dim(commutant)' % (len(CELL), KMAX + 1))
dims = [CELL[(1, k)]['m'] for k in range(0, KMAX + 2)]; nirr = [len(CELL[(1, k)]['irreps']) for k in range(0, KMAX + 2)]
chk('bit', dims[1:9] == [2, 4, 8, 8, 16, 16, 16, 16] and nirr[1:9] == [1, 1, 1, 2, 1, 1, 1, 2],
    'abs.R1: irreducible graded C_k-modules, k = 1..8: dimensions %s (the paper: twice dim M_0 = 2, 4, 8, 8, 16, 16, 16, 16), one irreducible except two at k = 4 and 8 (Table 2, read)' % dims[1:9])
chk('bit', all(dims[k] == 16 * dims[k - 8] and nirr[k] == nirr[k - 8] for k in range(9, KMAX + 2)),
    'abs.R1: k = 0..%d: dimensions %s and irreducible counts %s; from k = 9 on they are 16 times those of k - 8 (C_(k+8) = C_k (x) R(16), read)' % (KMAX + 1, dims, nirr))
if FAULT == 'UNGRADED':
    AL = []
    for k in range(0, KMAX + 1):
        M = restrict(CELL[(0, k + 1)] if (0, k + 1) in CELL else build_cell(0, k + 1), k, CELL[(0, k)] if (0, k) in CELL else build_cell(0, k)); AL.append(coker(M)[0])
else:
    AL = [A_group(k, noswap=(FAULT == 'NOSWAP'))[0] for k in range(0, KMAX + 1)]
want = [KOM[k % 8] for k in range(0, KMAX + 1)]
chk('bit', AL == want, 'abs.R1: A_k, k = 0..%d: %s; the paper\'s Table 2 (k = 1..8: Z2 Z2 0 Z 0 0 0 Z) repeated with period 8, and A_0 = Z' % (KMAX, ' '.join(AL)))
APL = [Ap_group(k) for k in range(0, 9)]
chk('bit', APL == want[:9], 'abs.R1: the other sign, A\'_k = coker(N(Cl(k+2,0)) -> N(Cl(k+1,0))), k = 0..8: %s, the same list (the paper: the sequences of C_k and C\'_k)' % ' '.join(APL))
ul = []
for k in range(0, 9):
    M = restrict(CELL[(0, k + 1)] if (0, k + 1) in CELL else build_cell(0, k + 1), k, CELL[(0, k)] if (0, k) in CELL else build_cell(0, k)); ul.append(coker(M)[0])
chk('ctl', ul != want[:9] and ul[0] == 'Z2', 'abs.R1: without the grading (ungraded C_k-modules modulo C_(k+1)) the list is %s: it moves by one, Z2 at k = 0 (UNGRADED)' % ' '.join(ul))
nl = [A_group(k, noswap=True)[0] for k in range(0, 9)]
chk('ctl', nl != want[:9], 'abs.R1: with the two irreducibles of C_4 and C_8 kept, not swapped, by the dropped generator the list reads %s (NOSWAP)' % ' '.join(nl))

# ================================================================================================ R2. the ring
head('R2. the ring: products by concatenation of labels (the graded tensor product), generators eta, alpha, beta')
eta = CELL[(1, 1)]['irreps'][0]
al, al2 = CELL[(1, 4)]['irreps']; be, be2 = CELL[(1, 8)]['irreps']
def gen_ok(mods, k, want_cls):
    ok, cls, v = A_class(mods, k); return ok and cls == want_cls, cls, v
def unit(mods, k):
    """a generator of a cyclic A_k: class (1,) or (-1,) in Z, (1,) in Z2"""
    ok, cls, v = A_class(mods, k); nm = A_group(k)[0]
    return ok and (cls == (1,) if nm == 'Z2' else abs(cls[0]) == 1), cls, v
o1, c_eta, _ = unit(eta, 1); o2, c_eta2, _ = unit(gtensor(eta, eta), 2)
chk('bit', o1 and o2, 'abs.R2: eta (the irreducible of Cl(1,1), dimension 2) generates A_1 = Z2 and eta^2 (dimension 4) generates A_2 = Z2 (classes %s, %s)' % (c_eta, c_eta2))
eta3 = gtensor(gtensor(eta, eta), eta); ok3, v3 = module_class(eta3, CELL[(1, 3)])
chk('bit', ok3 and A_group(3)[0] == '0', 'abs.R2: eta^3 (dimension 8, %d copies of the irreducible of Cl(1,3)) lies in A_3 = 0: the relation eta^3 = 0' % v3[0])
eta4 = gtensor(eta3, eta); ok4, c_eta4, v4 = A_class(eta4, 4)
chk('bit', ok4 and c_eta4 == ((1,) if FAULT == 'ETA4' else (0,)), 'abs.R2: eta^4 (dimension 16, multiplicities %s of the two irreducibles of Cl(1,4)) has class %d in A_4 = Z: it restricts from Cl(1,5), so eta^4 = 0 there too' % (v4, c_eta4[0]))
oa, c_al, _ = unit(al, 4); ob, c_be, _ = unit(be, 8)
chk('bit', oa and ob and abs(c_al[0]) == 1 and abs(c_be[0]) == 1, 'abs.R2: alpha, the irreducible of Cl(1,4) with volume element +1 (dimension 8), generates A_4 = Z with class %d; beta, the irreducible of Cl(1,8) with volume element +1 (dimension 16), generates A_8 = Z with class %d' % (c_al[0], c_be[0]))
ea = gtensor(eta, al); oea, vea = module_class(ea, CELL[(1, 5)])
chk('bit', oea and A_group(5)[0] == '0', 'abs.R2: eta.alpha (dimension 16, %d copies of the irreducible of Cl(1,5)) lies in A_5 = 0: the relation eta.alpha = 0' % vea[0])
aa = gtensor(al, al); oaa, c_aa, vaa = A_class(aa, 8)
chk('bit', oaa and c_aa[0] == (2 if FAULT == 'ALPHA2' else 4) * c_be[0], 'abs.R2: alpha^2 (dimension 64, multiplicities %s of the two irreducibles of Cl(1,8)) has class %d = 4 beta: the relation alpha^2 = 4 beta' % (vaa, c_aa[0]))
oeb, c_eb, _ = unit(gtensor(eta, be), 9); oeeb, c_eeb, _ = unit(gtensor(gtensor(eta, eta), be), 10)
chk('bit', oeb and oeeb, 'abs.R2: eta.beta (dimension 32) generates A_9 = Z2 and eta^2.beta (dimension 64) generates A_10 = Z2')
oab, c_ab, vab = unit(gtensor(al, be), 12)
chk('bit', oab and abs(c_ab[0]) == 1, 'abs.R2: alpha.beta (dimension 128, multiplicities %s of the two irreducibles of Cl(1,12)) has class %d: it generates A_12 = Z' % (vab, c_ab[0]))
bb = gtensor(be, be); obb, c_bb, vbb = A_class(bb, 16)
chk('bit', obb and abs(c_bb[0]) == (0 if FAULT == 'PERIOD' else 1), 'abs.R2: beta^2 (dimension 256, multiplicities %s of the two irreducibles of Cl(1,16)) has class %d: it generates A_16 = Z' % (vbb, c_bb[0]))
aab = gtensor(aa, be); oaab, c_aab, _ = A_class(aab, 16)
chk('bit', oaab and c_aab[0] == 4 * c_bb[0], 'abs.R2: alpha^2.beta (dimension 1024) has class %d = 4 x (class of beta^2): the relation alpha^2 = 4 beta is carried along by beta' % c_aab[0])
ob2, c_b2, _ = unit(be2, 8); ob2b, c_b2b, _ = A_class(gtensor(be2, be), 16)
chk('bit', ob2 and c_b2[0] == -c_be[0] and c_b2b[0] == -c_bb[0], 'abs.R2: the other irreducible of Cl(1,8) (volume element -1) is -beta (class %d) and (-beta).beta = -beta^2 (class %d): the product is bilinear' % (c_b2[0], c_b2b[0]))
pers = []
for k, g in ((0, None), (1, eta), (2, gtensor(eta, eta)), (4, al), (8, be)):
    mods = be if g is None else gtensor(g, be)
    okp, clsp, _ = unit(mods, k + 8); pers.append((k, okp))
chk('bit', all(o for _, o in pers), 'abs.R2: multiplication by beta sends the generator of A_k to a generator of A_(k+8) for k = 0, 1, 2, 4, 8 (and the zero groups to zero): an isomorphism A_k -> A_(k+8), k = 0..8 (the paper\'s periodicity, finite side)')
mono = {0: '1', 1: 'eta', 2: 'eta^2', 4: 'alpha', 8: 'beta', 9: 'eta.beta', 10: 'eta^2.beta', 12: 'alpha.beta', 16: 'beta^2'}
chk('bit', all(AL[k] == ('Z' if k % 4 == 0 else 'Z2') for k in mono) and all(AL[k] == '0' for k in range(KMAX + 1) if k not in mono),
    'abs.R2: in degrees 0..%d the groups are generated by the monomials %s and are 0 elsewhere: the ring Z[eta, alpha, beta]/(2 eta, eta^3, eta.alpha, alpha^2 - 4 beta), KO^(-*)(point) as recalled' % (KMAX, ', '.join(mono[k] for k in sorted(mono))))

# ================================================================================================ R3. the complex groups and ring
head('R3. the complex groups: the centre counts the simple summands of C (x) Cl(1,k), the volume element tells them apart; the complex ring by the complex tensor product')
def ccounts(cell, fault=False):
    nC = int(cell['summ']) if fault else cell['ncent']
    mC = cell['m'] // (1 if cell['type'] == 'R' else 2)
    return nC, mC
def crestrict(big, drop, small, fault=False):
    """the complex restriction matrix: every complex irreducible of `big` restricts to the complex irreducibles of `small` alike (the dropped generator
    swaps the two summands of `small`, exact: it anticommutes with the volume element), with multiplicity from the complex dimensions"""
    nB, mB = ccounts(big, fault); nS, mS = ccounts(small, fault)
    if nS == 2:
        vol = (1 << big['n']) - 1 - (1 << drop); swap = big['alg'].comm_sign(1 << drop, vol) == -1; col = [mB // (2 * mS)] * 2
    else: swap = True; col = [mB // mS]
    return [[col[i]] * nB for i in range(nS)], swap
cl = []; cbad = []; cswap = True
for k in range(0, 13):
    M, sw = crestrict(CELL[(1, k + 1)], k + 1, CELL[(1, k)], FAULT == 'CPLX'); cswap = cswap and sw; nm = coker(M)[0]; cl.append(nm)
    if nm != ('Z' if k % 2 == 0 else '0'): cbad.append((k, nm))
chk('bit', not cbad and cswap, 'abs.R3: A^c_k, k = 0..12: %s: Z for k even, 0 for k odd (period 2; the paper\'s complex case, read); at k even the dropped generator anticommutes with the volume element' % ' '.join(cl))
wrong = [coker(crestrict(CELL[(1, k + 1)], k + 1, CELL[(1, k)], True)[0])[0] for k in range(0, 6)]
chk('ctl', wrong != ['Z', '0'] * 3, 'abs.R3: counting the real simple summands in place of the complex ones gives %s (CPLX)' % ' '.join(wrong))
# the complex ring: mu = the irreducible of Cl(1,2) with its complex structure J from the commutant (type C); mu^j = the complex tensor power, the part of the
# real tensor power on which the j complex structures agree; its class in A^c_(2j) = Z^2/(1,1) = Z is (multiplicity of S_+) - (multiplicity of S_-), the two
# complex irreducibles of Cl(1,2j) being the eigenspaces of the complex volume element (omega itself when omega^2 = +1, i.omega = -J.omega... when omega^2 = -1)
mu = CELL[(1, 2)]['irreps'][0]; Jmu = CELL[(1, 2)]['J']
chk('bit', Jmu is not None and np.array_equal(Jmu @ Jmu, -np.eye(4, dtype=np.int64)) and all(np.array_equal(Jmu @ R, R @ Jmu) for R in mu),
    'abs.R3: mu, the irreducible of Cl(1,2) (real dimension 4), has a complex structure J in its commutant (J^2 = -1, commuting with the generators): a complex graded C_2-module of complex dimension 2')
def kron_all(mats):
    out = np.array([[1]], dtype=np.int64)
    for M in mats: out = np.kron(out, M)
    return out
def mu_power_class(j):
    """class of mu^j in A^c_(2j): on the real tensor power (dimension 4^j) the complex part E is where J_1 = J_2 = ... = J_j, the joint +1 eigenspace of the
    commuting involutions P_i = -J_i J_(i+1); a = dim_C (E, omega_c = +1) and b = dim_C (E, omega_c = -1) from the traces of the projectors (exact: entries in Z/2^j)"""
    mods = mu
    for _ in range(j - 1): mods = gtensor(mods, mu)
    m = 4 ** j; I = np.eye(m)
    Js = [kron_all([np.eye(4, dtype=np.int64)] * i + [Jmu] + [np.eye(4, dtype=np.int64)] * (j - 1 - i)) for i in range(j)]
    Ps = [-fmm(Js[i], Js[i + 1]) for i in range(j - 1)]
    om = mprod(mods, m); om2 = fmm(om, om)
    if np.array_equal(om2, np.eye(m, dtype=np.int64)): Q = om
    else:
        assert np.array_equal(om2, -np.eye(m, dtype=np.int64)); Q = -fmm(om, Js[0])     # omega_c = i omega = +1 where omega = -i, i.e. omega = -J: Q = -omega J = +1
    for Mx in Ps + [Q]: assert np.array_equal(fmm(Mx, Mx), np.eye(m, dtype=np.int64))
    Pr = np.eye(m)
    for P in Ps: Pr = Pr @ ((I + P) / 2)
    e2 = Pr.trace(); a2 = (Pr @ ((I + Q) / 2)).trace(); b2 = e2 - a2
    e2, a2, b2 = [int(round(x)) for x in (e2, a2, b2)]
    assert abs(Pr.trace() - e2) < 1e-9 and a2 % 2 == 0 and b2 % 2 == 0 and a2 + b2 == e2
    nC, mC = ccounts(CELL[(1, 2 * j)]); assert nC == 2 and (a2 // 2) % mC == 0 and (b2 // 2) % mC == 0
    return (a2 // 2) // mC - (b2 // 2) // mC, e2 // 2
JMAX = 5
mcls = [mu_power_class(j) for j in range(1, JMAX + 1)]
chk('bit', [abs(c) for c, _ in mcls] == [1] * JMAX and [d for _, d in mcls] == [2 ** j for j in range(1, JMAX + 1)],
    'abs.R3: mu^j, j = 1..%d, has complex dimension %s and class %s in A^c_(2j) = Z: each power generates, so in degrees <= %d the complex ring is Z[mu] (K^(-*)(point) as recalled; period 2)' % (JMAX, [d for _, d in mcls], [c for c, _ in mcls], 2 * JMAX))
print('  (bit-rule cells: %.1f s)' % TA, flush=True)
# ================================================================================================ the standard route: numpy, no label
head('S. the standard route: Kronecker words for Cl(1,k), k <= 8, the graded tensor product with the 16-dimensional module of Cl(1,8) beyond; classes from dimensions and the trace of the volume element')
_X = np.array([[0, 1], [1, 0]]); _Z = np.diag([1, -1]); _E = np.array([[0, 1], [-1, 0]]); _I2 = np.eye(2, dtype=np.int64)
def kron_gammas(eps):
    G = []
    for k in range(len(eps)):
        A = _X if eps[k] > 0 else _E
        M = np.array([[1]], dtype=np.int64)
        for B in [_Z] * k + [A] + [_I2] * (len(eps) - k - 1): M = np.kron(M, B)
        G.append(M)
    return G
def hom_dim_small(S, T):
    mS = S[0].shape[0]; mT = T[0].shape[0]
    rows = [np.kron(Si.T, np.eye(mT)) - np.kron(np.eye(mS), Ti) for Si, Ti in zip(S, T)]
    A = np.vstack(rows).astype(float)
    return mS * mT - np.linalg.matrix_rank(A, tol=1e-8 * max(1.0, np.abs(A).max()))
def _split(G, prods, dim, seed):
    """the irreducible summands of a module (generator matrices G, the blade products `prods`) as eigenspaces of a random symmetric commutant element"""
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((dim, dim)); X = X + X.T
    Y = sum(P @ X @ P.T for P in prods) / len(prods)
    w, V = np.linalg.eigh(Y)
    groups = []; start = 0; scale = max(1.0, np.abs(w).max())
    for i in range(1, dim + 1):
        if i == dim or w[i] - w[i - 1] > 1e-7 * scale: groups.append(V[:, start:i]); start = i
    return groups
def _blade_products(G, dim):
    prods = [np.eye(dim)]
    for a in range(1, 1 << len(G)):
        i = (a & -a).bit_length() - 1; prods.append(G[i] @ prods[a ^ (1 << i)])
    return prods
def std_base(k, seed=0):
    """the irreducible module(s) of Cl(1,k), k <= 7, as eigenspaces of a random symmetric commutant element of the regular representation (floats, no label)"""
    eps = [1] + [-1] * k; n = k + 1; dim = 2 ** n
    Gf = [g.astype(float) for g in kron_gammas(eps)]
    prods = _blade_products(Gf, dim); groups = _split(Gf, prods, dim, 1000 + 37 * k + seed)
    om = prods[-1]
    two = n % 2 == 1 and all(np.allclose(om @ g, g @ om) for g in Gf) and np.allclose(om @ om, np.eye(dim))
    irreps = []
    if two:
        for sgn in (1, -1):
            Q = next(g for g in groups if np.trace(g.T @ om @ g) * sgn > 0.5); irreps.append([Q.T @ Gk @ Q for Gk in Gf])
    else:
        Q = groups[0]; irreps.append([Q.T @ Gk @ Q for Gk in Gf])
    m = groups[0].shape[1]; d = hom_dim_small(irreps[0], irreps[0]) if m <= 16 else None
    return {'k': k, 'm': m, 'irreps': irreps, 'two': two, 'd': d, 'sizes': sorted(set(g.shape[1] for g in groups))}
def gtensor_f(M, N):
    IM, IN = np.eye(M[0].shape[0]), np.eye(N[0].shape[0])
    return [np.kron(M[0], N[0])] + [np.kron(R, IN) for R in M[1:]] + [np.kron(M[0], R) for R in N[1:]]
SB = {k: std_base(k) for k in range(0, 8)}
# k = 8: the 64-dimensional module alpha (x) alpha of Cl(1,8) splits into irreducibles of dimension 16; the one with volume element +1 is the base module
_AA = gtensor_f(SB[4]['irreps'][0], SB[4]['irreps'][0]); _pr = _blade_products(_AA, 64); _gr = _split(_AA, _pr, 64, 4242); _om = _pr[-1]
Qg = next(g for g in _gr if np.trace(g.T @ _om @ g) > 0.5); _plus = [Qg.T @ Gk @ Qg for Gk in _AA]
_irr8 = [_plus, [-Gk for Gk in _plus]]                                   # the other irreducible: the generators negated (nine of them, so the volume element changes sign)
SB[8] = {'k': 8, 'm': _gr[0].shape[1], 'irreps': _irr8, 'two': True, 'd': hom_dim_small(_irr8[0], _irr8[0]), 'sizes': sorted(set(g.shape[1] for g in _gr))}
oks = all(len(s['sizes']) == 1 for s in SB.values()) and all(s['d'] in (1, 2, 4) for s in SB.values() if s['d'] is not None)
chk('std', oks and [SB[k]['m'] for k in range(9)] == dims[:9] and [2 if SB[k]['two'] else 1 for k in range(9)] == nirr[:9],
    'abs.S: Cl(1,k), k = 0..7 from the regular representation and k = 8 from alpha (x) alpha: one eigenspace dimension each, commutants of dimension 1, 2 or 4 where computed; dimensions %s and counts %s agree with the bit rule' % ([SB[k]['m'] for k in range(9)], [2 if SB[k]['two'] else 1 for k in range(9)]))
def std_irreps(k):
    """the irreducible modules of Cl(1,k) on the standard route: the base for k <= 8, the graded tensor product with the 16-dimensional module of Cl(1,8) beyond"""
    if k <= 8: return SB[k]['irreps'], SB[k]['m'], SB[k]['two']
    base, m, two = std_irreps(k - 8); B16 = SB[8]['irreps'][0]
    out = [gtensor_f(T, B16) for T in base]
    return out, m * 16, two
def std_class(mods, k):
    irr, m_irr, two = std_irreps(k); m = mods[0].shape[0]
    if not two: return [int(round(m / m_irr))]
    om = np.eye(m)
    for R in mods: om = om @ R
    tr = np.trace(om); return [int(round((m + tr) / (2 * m_irr))), int(round((m - tr) / (2 * m_irr)))]
def std_restrict(k):
    big, _, _ = std_irreps(k + 1); irr, _, two = std_irreps(k)
    cols = [std_class([T[i] for i in range(len(T)) if i != k + 1], k) for T in big]
    return [[c[i] for c in cols] for i in range(2 if two else 1)]
SR = {k: std_restrict(k) for k in range(0, 10)}
okr = all(SR[k] == A_group(k)[2] for k in range(0, 10))
chk('bit==std', okr, 'abs.S: the restriction matrices N(Cl(1,k+1)) -> N(Cl(1,k)), k = 0..9, agree with the bit rule entry by entry')
chk('std', [coker_divisors(SR[k]) for k in range(0, 10)] == want[:10], 'abs.S: cokernels by determinantal divisors, k = 0..9: %s' % ' '.join(coker_divisors(SR[k]) for k in range(10)))
def std_A(mods, k):
    nm, cd = coker(SR[k] if k in SR else std_restrict(k)); return coker_class(cd, std_class(mods, k))
s_eta = SB[1]['irreps'][0]; s_al = SB[4]['irreps'][0]; s_be = SB[8]['irreps'][0]
s_tab = {'eta^2': (gtensor_f(s_eta, s_eta), 2), 'eta^4': (gtensor_f(gtensor_f(s_eta, s_eta), gtensor_f(s_eta, s_eta)), 4), 'alpha^2': (gtensor_f(s_al, s_al), 8),
         'eta.beta': (gtensor_f(s_eta, s_be), 9), 'eta^2.beta': (gtensor_f(gtensor_f(s_eta, s_eta), s_be), 10), 'alpha.beta': (gtensor_f(s_al, s_be), 12), 'beta^2': (gtensor_f(s_be, s_be), 16)}
s_cls = {name: std_A(mods, k) for name, (mods, k) in s_tab.items()}
b_cls = {'eta^2': c_eta2, 'eta^4': c_eta4, 'alpha^2': c_aa, 'eta.beta': c_eb, 'eta^2.beta': c_eeb, 'alpha.beta': c_ab, 'beta^2': c_bb}
same = all(abs(s_cls[nm][0]) == abs(b_cls[nm][0]) for nm in s_tab)
chk('std', s_cls['eta^2'] == (1,) and s_cls['eta^4'] == (0,) and abs(s_cls['alpha^2'][0]) == 4 and s_cls['eta.beta'] == (1,) and s_cls['eta^2.beta'] == (1,) and abs(s_cls['alpha.beta'][0]) == 1 and abs(s_cls['beta^2'][0]) == 1,
    'abs.S: on the standard route eta^2, eta.beta, eta^2.beta generate their Z2, eta^4 = 0, |alpha^2| = 4 |beta|, alpha.beta and beta^2 generate their Z: %s' % {k: v[0] for k, v in s_cls.items()})
chk('bit==std', same, 'abs.S: the seven product classes agree with the bit rule up to the sign of a generator')
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('ABS-RING')
