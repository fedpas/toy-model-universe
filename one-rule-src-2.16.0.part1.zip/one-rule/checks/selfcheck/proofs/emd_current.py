#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""emd_current.py: the grade-5 part of the current X = psi gamma_0 psi~ on one copy of the Dirac field, n = 6, 7, 8.
      python3 emd_current.py [--fault GRADE|OUTSIDE|NOTDIRAC]

Conventions of coupling_selfcheck.py, imported and used as they stand: Cl(1,n-1) by bit masks, bit 0 = time (square +1), the other bits square -1;
the product is its bmul (here through a table of its signs); J = gamma_2 gamma_1; D(psi; A, e, m) = nabla(psi) J - e A psi - m psi gamma_0.
Two meanings of "one copy", both computed for n = 6, 7, 8:
 (A) a minimal left ideal Cl+ e_s of Cl+(1,n-1): e_s = prod_i (1 + s_i P_i)/2 with the commuting label involutions P_i found by the routine of
     dirac_limits.py dlim·MOD (the same code: [3, 60], [3, 60], [3, 60, 204]) and all 4, 4, 8 sign choices s;
 (B) a Dirac copy Cl+ f: f = prod (1 + s_i Q_i)/2 with Q_i labels of grade 4 (so Q~ = Q) that commute with gamma_0 and J and with each other:
     n = 6 Q = gamma_1234; n = 7 Q = gamma_1234, gamma_3456 (the latter central among the right multiplications that keep D); n = 8 Q = gamma_1234,
     gamma_1256: 2, 4, 4 copies, the numbers of dlim·EXTRA; f is primitive among those right multiplications (f C f has dimension 2).
For each copy, exactly (Fractions): membership; three random integer psi in the copy (seeded), the grades of X and the number of non-zero grade-5
blades; by polarisation B(u, v) = u gamma_0 v~ + v gamma_0 u~ on a basis of the copy, the dimension of the span of the grade-5 parts, of the grade-1
parts and of both (equal joint and grade-1 dimension: the grade-5 part is a linear function of the grade-1 part on that copy); the inertia of the
quadratic form of each grade-5 coefficient (a definite one makes X5 != 0 for every psi != 0 in the copy); the label spinors b e (b an even label)
with X5 = 0.  n = 6: each minimal left ideal lies in one simple factor (psi I6 = s psi) and there X5 = -s X1 I6 (a derivation: (1 + s I6) gamma_0 =
gamma_0 (1 - s I6), I6 central in Cl+; checked on the samples and on every polarised pair); on a Dirac copy X5 = (X1(psi-) - X1(psi+)) I6 with
psi+- = psi (1 +- I6)/2.  The current of the full even psi is the sum over the Dirac copies (f_s gamma_0 f_t~ = gamma_0 f_s f_t = 0 for s != t) and
over the minimal left ideals (checked on three random psi).  D(psi f) = D(psi) f: f commutes with gamma_0 and J; the D of coupling_selfcheck is run
at n = 6 on one random field.
[std] numpy: Jordan-Wigner matrices of coupling_matrix_check.py (n = 6, 7, 8): the matrix of X equals the product of the matrices of psi, gamma_0,
psi~ for one sample per copy, and the matrix ranks of the copies equal the exact dimensions.
Controls ([ctl]; each --fault puts the wrong version into the main line, which must then FAIL):
   GRADE     the grade-3 part in place of the grade-5 part (zero on every copy: a wrong grade sees nothing);  OUTSIDE  psi not projected into the copy
   (membership and the n = 6 identity fail);  NOTDIRAC  f = (1 + gamma_0 gamma_1)/2, which does not commute with gamma_0 (D(psi f) != D(psi) f).
Scope: n = 6, 7, 8; every minimal left ideal of the decomposition and every Dirac copy; three random psi per copy (integers -5..5, seeds fixed); exact
Fractions on [bit], floats with the tolerances printed on [std].  The script builds no object of the gravity engine (Forms, Lie, Grav): the engine
faults M1-M8 do not reach it; its controls are its own.
Command: python3 emd_current.py   (from this folder, or python3 selfcheck/proofs/emd_current.py from the package root; numpy)."""
import os, sys, itertools, random
from fractions import Fraction as Fr
from math import comb
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here)
for _p, _f in ((_selfcheck, 'coupling_selfcheck.py'), (_selfcheck, 'coupling_matrix_check.py'), (os.path.join(_selfcheck, 'steps15_17'), 'bitcliff.py')):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
import coupling_selfcheck as cs
import coupling_matrix_check as cm
import bitcliff as bc

FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[0 if cond else 1] += 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('GRADE', 'OUTSIDE', 'NOTDIRAC')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')

# ------------------------------------------------------------------------------------------------ the routine of dlim·MOD (dirac_limits.py), unchanged
def gf2_rank(ms):
    piv = {}
    for m in ms:
        x = m
        while x:
            h = x.bit_length() - 1
            if h in piv: x ^= piv[h]
            else: piv[h] = x; break
    return len(piv)
def span_masks(Ps):
    H = {0}
    for P in Ps: H |= {h ^ P for h in H}
    return H
def dtype(alg, masks, Ps):
    com = [b for b in masks if all(alg.comm_sign(b, P) == 1 for P in Ps)]; H = span_masks(Ps)
    reps = sorted({min(b ^ h for h in H) for b in com}); nt = [b for b in reps if b != 0]
    if len(reps) == 1: return 'R'
    if len(reps) == 2: return 'C' if alg.sq(nt[0]) == -1 else None
    if len(reps) == 4 and all(alg.sq(b) == -1 for b in nt) and alg.comm_sign(nt[0], nt[1]) == -1: return 'H'
    return None
def find_primitive(alg, masks):
    invs = [a for a in masks if a and alg.sq(a) == 1]
    def rec(Ps):
        t = dtype(alg, masks, Ps)
        if t: return Ps, t
        for P in invs:
            if Ps and P <= Ps[-1]: continue
            if all(alg.comm_sign(P, Q) == 1 for Q in Ps) and gf2_rank(Ps + [P]) == len(Ps) + 1:
                r = rec(Ps + [P])
                if r: return r
        return None
    return rec([])

# ------------------------------------------------------------------------------------------------ exact algebra by the sign table of cs.bmul
class Alg8:
    def __init__(self, n):
        self.n = n; self.sq = cs.sqs(n); N = 1 << n
        self.T = [[cs.bmul(a, b, self.sq)[1] for b in range(N)] for a in range(N)]
        self.ev = [m for m in range(N) if pc(m) % 2 == 0]
    def mul(self, x, y):
        r = {}
        for a, ca in x.items():
            Ta = self.T[a]
            for b, cb in y.items():
                k = a ^ b; r[k] = r.get(k, 0) + Ta[b] * ca * cb
        return {k: v for k, v in r.items() if v}
    def comm(self, a, b): return self.T[a][b] == self.T[b][a]
def add(*ts):
    r = {}
    for t in ts:
        for k, v in t.items(): r[k] = r.get(k, 0) + v
    return {k: v for k, v in r.items() if v}
def sc(a, c): return {k: v * c for k, v in a.items() if v * c}
def rev(a): return {m: cs.rsign(pc(m)) * v for m, v in a.items()}
def grade(a, k): return {m: v for m, v in a.items() if pc(m) == k}
def grades(a): return sorted({pc(m) for m in a})
class Ech:
    """an echelon basis over Q of dict vectors (exact)"""
    def __init__(self): self.rows = {}
    def add(self, v):
        v = {k: Fr(c) for k, c in v.items() if c}
        while v:
            p = min(v)
            if p not in self.rows:
                c = v[p]; self.rows[p] = {k: x / c for k, x in v.items()}; return True
            r = self.rows[p]; c = v[p]
            for k, x in r.items():
                nv = v.get(k, 0) - c * x
                if nv: v[k] = nv
                else: v.pop(k, None)
        return False
    def __len__(self): return len(self.rows)
def rank_of(vs):
    E = Ech()
    for v in vs: E.add(v)
    return len(E)
def basis_of(vs):
    E = Ech(); out = []
    for v in vs:
        if E.add(v): out.append(v)
    return out
def inertia(S):
    """(positive, negative, zero) of a symmetric rational matrix by congruence (the routine of dirac_limits.py)"""
    S = [[Fr(x) for x in r] for r in S]; n = len(S); out = [0, 0, 0]; idx = list(range(n))
    while idx:
        i = next((j for j in idx if S[j][j] != 0), None)
        if i is None:
            pair = next(((a, b) for a in idx for b in idx if a != b and S[a][b] != 0), None)
            if pair is None: out[2] += len(idx); break
            a, b = pair
            for k in range(n): S[a][k] += S[b][k]
            for k in range(n): S[k][a] += S[k][b]
            continue
        out[0 if S[i][i] > 0 else 1] += 1; idx.remove(i)
        for j in idx:
            f = S[j][i] / S[i][i]
            for k in range(n): S[j][k] -= f * S[i][k]
            for k in range(n): S[k][j] -= f * S[k][i]
    return tuple(out)
def idem(A, Ps, signs):
    e = {0: Fr(1)}
    for P, s in zip(Ps, signs): e = A.mul(e, {0: Fr(1, 2), P: Fr(s, 2)})
    return e
def lift(a, nv): return {m: {(0,) * nv: Fr(c)} for m, c in a.items() if c}
def Dfield(psi, A, e, m, n):
    """the line of coupling_selfcheck.identities() as dirac_limits.py writes it: D = nabla(psi) J - e A psi - m psi gamma_0"""
    sq = cs.sqs(n); Jm, Js = cs.bmul(1 << 2, 1 << 1, sq); Jf = {Jm: {(0,) * n: Fr(Js)}}; g0 = cs.const(1, 1, n)
    return cs.fadd(cs.fadd(cs.fmul(cs.nabla(psi, sq), Jf, sq), cs.fmul(A, psi, sq), -e), cs.fmul(psi, g0, sq), -m)

EXPECT_PS = {6: [3, 60], 7: [3, 60], 8: [3, 60, 204]}
DIRAC_Q = {6: [30], 7: [30, 120], 8: [30, 102]}
EXPECT_COPIES = {6: 2, 7: 4, 8: 4}
G0 = {1: Fr(1)}
SUMMARY = {}

def study(A, n, name, idems, rng_base, factor_sign=None, I6=None):
    """the grade-5 part of the current on each copy Cl+ x for x in idems; returns a summary per copy"""
    out = []
    for ci, x in enumerate(idems):
        B = basis_of([A.mul({b: Fr(1)}, x) for b in A.ev])
        memb = all(A.mul(u, x) == u for u in B)
        samples = []
        for sd in range(3):
            rg = random.Random(rng_base + 100 * ci + sd); y = {b: Fr(rg.randint(-5, 5)) for b in A.ev}
            psi = y if FAULT == 'OUTSIDE' else A.mul(y, x)
            X = A.mul(A.mul(psi, G0), rev(psi))
            g = 3 if FAULT == 'GRADE' else 5
            samples.append((A.mul(psi, x) == psi, grades(X), len(grade(X, g)), len(grade(X, 3)), psi, X))
        pol = {}
        for i in range(len(B)):
            for j in range(i, len(B)):
                u, v = B[i], B[j]
                pol[(i, j)] = A.mul(A.mul(u, G0), rev(u)) if i == j else add(A.mul(A.mul(u, G0), rev(v)), A.mul(A.mul(v, G0), rev(u)))
        r5 = rank_of([grade(p, 5) for p in pol.values()]); r1 = rank_of([grade(p, 1) for p in pol.values()]); rj = rank_of(list(pol.values()))
        blades5 = sorted({m for p in pol.values() for m in p if pc(m) == 5})
        definite = []
        for bl in blades5:
            S = [[(pol[(min(i, j), max(i, j))].get(bl, 0) * (1 if i == j else Fr(1, 2))) for j in range(len(B))] for i in range(len(B))]
            ine = inertia(S)
            if ine[2] == 0 and (ine[0] == 0 or ine[1] == 0): definite.append(bl)
        dens = [[(pol[(min(i, j), max(i, j))].get(1, 0) * (1 if i == j else Fr(1, 2))) for j in range(len(B))] for i in range(len(B))]
        labz = sum(1 for b in A.ev if A.mul({b: Fr(1)}, x) and not grade(A.mul(A.mul(A.mul({b: Fr(1)}, x), G0), rev(A.mul({b: Fr(1)}, x))), 5))
        pairs = []
        for i, j in itertools.combinations(range(len(B)), 2):
            for t in (1, -1, 2, -2, Fr(1, 2), Fr(-1, 2)):
                q = add(B[i], sc(B[j], t))
                if q and not grade(A.mul(A.mul(q, G0), rev(q)), 5): pairs.append((i, j, t, q))
        rec = dict(pairs=pairs, ntried=6 * len(B) * (len(B) - 1) // 2, dim=len(B), memb=memb, samples=samples, r5=r5, r1=r1, rj=rj, nbl5=len(blades5), definite=definite, dens=inertia(dens), labz=labz, B=B, pol=pol)
        if I6 is not None:
            sgn = [s for s in (1, -1) if all(A.mul(u, I6) == sc(u, s) for u in B)]
            rec['factor'] = sgn[0] if sgn else 0
            if sgn:
                s = sgn[0]
                rec['id6'] = all(grade(p, 5) == sc(A.mul(grade(p, 1), I6), -s) for p in pol.values()) and all(grade(X, 5) == sc(A.mul(grade(X, 1), I6), -s) for *_, X in samples)
        out.append(rec)
    return out

for n in (6, 7, 8):
    head('n = %d: Cl+(1,%d), the grade-5 part of psi gamma_0 psi~ on one copy [bit]' % (n, n - 1))
    A = Alg8(n); alg = bc.Alg(cs.sqs(n))
    Ps, D_ = find_primitive(alg, A.ev)
    chk('bit', Ps == EXPECT_PS[n], 'n=%d: the routine of dlim·MOD gives the label involutions %s (e Cl+ e = %s), as in its log' % (n, Ps, D_))
    sig = list(itertools.product((1, -1), repeat=len(Ps)))
    E_ = [idem(A, Ps, s) for s in sig]
    chk('bit', add(*E_) == {0: Fr(1)} and all(A.mul(E_[i], E_[j]) == ({} if i != j else E_[i]) for i in range(len(E_)) for j in range(len(E_))),
        'n=%d: the %d idempotents e_s are orthogonal and sum to 1 (minimal left ideals Cl+ e_s)' % (n, len(E_)))
    Jm, Js = cs.bmul(1 << 2, 1 << 1, A.sq); J = {Jm: Fr(Js)}
    Q = DIRAC_Q[n]
    okQ = all(A.comm(q, 1) and A.comm(q, Jm) and A.T[q][q] == 1 and cs.rsign(pc(q)) == 1 for q in Q) and all(A.comm(a, b) for a in Q for b in Q) and gf2_rank(Q) == len(Q)
    fsig = list(itertools.product((1, -1), repeat=len(Q)))
    Fq = [idem(A, Q, s) for s in fsig]
    if FAULT == 'NOTDIRAC': Fq = [{0: Fr(1, 2), 3: Fr(s[0], 2)} for s in fsig[:2]] if n == 6 else Fq
    C = [a for a in A.ev if A.comm(a, 1) and A.comm(a, Jm)]
    prim = [rank_of([A.mul(A.mul(f, {c: Fr(1)}), f) for c in C]) for f in Fq]
    okF = add(*Fq) == {0: Fr(1)} and all(A.mul(Fq[i], Fq[j]) == ({} if i != j else Fq[i]) for i in range(len(Fq)) for j in range(len(Fq)))
    comm_ok = all(A.mul(f, G0) == A.mul(G0, f) and A.mul(f, J) == A.mul(J, f) and rev(f) == f for f in Fq)
    chk('bit', okQ and okF and comm_ok and len(Fq) == EXPECT_COPIES[n] and set(prim) == {2} and len(C) == 2 ** (n - 3),
        'n=%d: Q = %s (grade 4, Q^2 = 1, Q~ = Q, commuting with gamma_0, J and each other) give %d orthogonal idempotents f summing to 1 that commute with gamma_0 and J, primitive among the %d right multiplications that keep D (f C f of dimension %s): %d Dirac copies, the number of dlim·EXTRA'
        % (n, Q, len(Fq), len(C), sorted(set(prim)), len(Fq)))
    if n == 6:
        r2 = random.Random(6060); psiF = {S_: cs.rpoly(r2, 6, 1, .5) for S_ in A.ev}; Af = {1 << k: cs.rpoly(r2, 6, 1, .5) for k in range(6)}
        okD = all(Dfield(cs.fmul(psiF, lift(f, 6), A.sq), Af, Fr(3), Fr(5), 6) == cs.fmul(Dfield(psiF, Af, Fr(3), Fr(5), 6), lift(f, 6), A.sq) for f in Fq)
        chk('bit', okD, 'n=6: D(psi f) = D(psi) f for both Dirac idempotents on one random field (psi of degree 1, A of degree 1, e = 3, m = 5; the D of coupling_selfcheck): each copy obeys the same equation')
        bad = {0: Fr(1, 2), 3: Fr(1, 2)}
        chk('ctl', Dfield(cs.fmul(psiF, lift(bad, 6), A.sq), Af, Fr(3), Fr(5), 6) != cs.fmul(Dfield(psiF, Af, Fr(3), Fr(5), 6), lift(bad, 6), A.sq),
            'n=6: f = (1 + gamma_0 gamma_1)/2 (it does not commute with gamma_0): D(psi f) != D(psi) f')
    I6 = {63: Fr(1)} if n == 6 else None
    if n == 6:
        chk('bit', A.T[63][63] == 1 and all(A.comm(63, b) for b in A.ev) and not A.comm(63, 1), 'n=6: I6 = gamma_012345 squares to +1, commutes with the even labels (central in Cl+) and anticommutes with gamma_0: Cl+ = Cl+ (1 + I6)/2 + Cl+ (1 - I6)/2')
    RA = study(A, n, 'ideal', E_, 1000 * n, I6=I6)
    RB = study(A, n, 'dirac', Fq, 1000 * n + 500, I6=I6)
    for tag, R_, what in (('A', RA, 'minimal left ideal'), ('B', RB, 'Dirac copy')):
        g5 = [[s[2] for s in r['samples']] for r in R_]
        chk('bit', all(r['memb'] and all(s[0] for s in r['samples']) for r in R_) and all(set(s[1]) <= {1, 5} and s[3] == 0 for r in R_ for s in r['samples']),
            'n=%d (%s): %d copies of dimension %s; every sample lies in its copy; the grades of X are within {1, 5} and its grade-3 part is 0' % (n, what, len(R_), sorted({r['dim'] for r in R_})))
        chk('bit', all(all(c > 0 for c in row) for row in g5), 'n=%d (%s): the grade-5 part is non-zero on every sample: non-zero blades %s of C(%d,5) = %d' % (n, what, g5, n, comb(n, 5)))
        chk('bit', all(r['dens'] == (r['dim'], 0, 0) for r in R_), 'n=%d (%s): the gamma_0 coefficient of X (the density <psi gamma_0 psi~ gamma_0>_0) is a positive definite form on every copy (inertia %s)' % (n, what, sorted({r['dens'] for r in R_})))
        chk('bit', all(r['r5'] > 0 and r['rj'] >= max(r['r1'], r['r5']) and r['rj'] <= r['r1'] + r['r5'] for r in R_), 'n=%d (%s): by polarisation on a basis of each copy, the grade-5 parts span %s, the grade-1 parts %s, both together %s dimensions; X5 is a linear function of X1 on the copy: %s; definite grade-5 coefficient forms per copy: %s of %s blades; label spinors b x with X5 = 0: %s'
            % (n, what, sorted({r['r5'] for r in R_}), sorted({r['r1'] for r in R_}), sorted({r['rj'] for r in R_}), sorted({r['rj'] == r['r1'] for r in R_}), sorted({len(r['definite']) for r in R_}), sorted({r['nbl5'] for r in R_}), sorted({r['labz'] for r in R_})))
        SUMMARY[(n, tag)] = R_
    nz_pairs = {(tag, len(r['pairs'])) for tag, R_ in (('A', RA), ('B', RB)) for r in R_}
    if n == 6:
        w = RB[0]['pairs'][0] if RB[0]['pairs'] else None
        chk('bit', all(len(r['pairs']) == 0 for r in RA) and all(len(r['pairs']) > 0 for r in RB) and w is not None and grade(A.mul(A.mul(w[3], G0), rev(w[3])), 1) != {},
            'n=6: X5 vanishes on special psi of a Dirac copy: %s of the %d two-label combinations u + t v (t = +-1, +-2, +-1/2) of a basis of each copy have X5 = 0 (for instance basis spinors %d and %d with t = %s, X1 != 0); on the minimal left ideals none' % ([len(r['pairs']) for r in RB], RB[0]['ntried'], w[0], w[1], w[2]))
    else:
        chk('bit', all(len(r['pairs']) == 0 for r in RA + RB), 'n=%d: no two-label combination u + t v (t = +-1, +-2, +-1/2) of a basis of any copy has X5 = 0 (%d and %d combinations per copy); no grade-5 coefficient form is definite: whether X5 vanishes at some psi != 0 of a copy is not decided here' % (n, RA[0]['ntried'], RB[0]['ntried']))
    if n == 6:
        chk('bit', all(r['factor'] in (1, -1) and r['id6'] for r in RA), 'n=6: each minimal left ideal lies in one simple factor (psi I6 = s psi, s = %s) and on it X5 = -s X1 I6 on every sample and every polarised pair: the grade-5 part is the dual of the vector current and vanishes for no psi != 0' % [r['factor'] for r in RA])
        okB = True
        for r in RB:
            for *_, psi, X in r['samples']:
                pp = A.mul(psi, {0: Fr(1, 2), 63: Fr(1, 2)}); pm = A.mul(psi, {0: Fr(1, 2), 63: Fr(-1, 2)})
                X1p = grade(A.mul(A.mul(pp, G0), rev(pp)), 1); X1m = grade(A.mul(A.mul(pm, G0), rev(pm)), 1)
                okB &= grade(X, 5) == A.mul(add(X1m, sc(X1p, -1)), I6) and A.mul(A.mul(pp, G0), rev(pm)) == {}
            okB &= r['factor'] == 0
        chk('bit', okB, 'n=6: a Dirac copy has one part in each simple factor, no cross term between them, and X5 = (X1(psi-) - X1(psi+)) I6, psi+- = psi (1 +- I6)/2: zero exactly where the vector currents of the two parts coincide')
        y = {b: Fr(random.Random(66).randint(-5, 5)) for b in A.ev}; e0 = E_[0]; s0 = RA[0]['factor']
        Xo = A.mul(A.mul(y, G0), rev(y))
        chk('ctl', A.mul(y, e0) != y and grade(Xo, 5) != sc(A.mul(grade(Xo, 1), I6), -s0), 'n=6: a psi outside the copy (not projected) is not in Cl+ e and breaks X5 = -s X1 I6')
    sums = True; sumsA = True
    for sd in range(3):
        rg = random.Random(77000 + 10 * n + sd); psi = {b: Fr(rg.randint(-5, 5)) for b in A.ev}
        X = A.mul(A.mul(psi, G0), rev(psi))
        parts = [A.mul(psi, f) for f in Fq]; sums &= X == add(*[A.mul(A.mul(p, G0), rev(p)) for p in parts])
        partsA = [A.mul(psi, e) for e in E_]; sumsA &= X == add(*[A.mul(A.mul(p, G0), rev(p)) for p in partsA])
    chk('bit', sums, 'n=%d: for three random even psi the current is the sum of the currents of its %d Dirac copies (no cross term: f_s gamma_0 f_t~ = gamma_0 f_s f_t = 0), so its grade-5 part is the sum over the copies' % (n, len(Fq)))
    chk('bit', sumsA, 'n=%d: the same holds over the %d minimal left ideals Cl+ e_s' % (n, len(E_)))
    yg = {bb: Fr(random.Random(88000 + n).randint(-5, 5)) for bb in A.ev}
    chk('ctl', all(s_[3] == 0 for r in RA + RB for s_ in r['samples']) and len(grade(A.mul(A.mul(yg, G0), yg), 3)) > 0, 'n=%d: a wrong grade sees nothing: the grade-3 part of the current is 0 on every copy (the same extraction finds %d grade-3 blades in psi gamma_0 psi, no reverse, for a random even psi)' % (n, len(grade(A.mul(A.mul(yg, G0), yg), 3))))
    # std: Jordan-Wigner matrices
    g = cm.gammas(n)
    def mat(x): return sum(complex(c) * cm.blade_matrix(g, mm) for mm, c in x.items())
    okM = True; rk = []
    for r in RA[:1] + RB[:1]:
        psi, X = r['samples'][0][4], r['samples'][0][5]
        okM &= np.allclose(mat(X), mat(psi) @ mat(G0) @ mat(rev(psi)), atol=1e-6)
        Ms = [mat(u) for u in r['B']]; rk.append(int(np.linalg.matrix_rank(np.array([np.concatenate([M.real.ravel(), M.imag.ravel()]) for M in Ms]), tol=1e-9)))
    chk('std', okM and rk == [RA[0]['dim'], RB[0]['dim']], 'n=%d: Jordan-Wigner matrices (coupling_matrix_check.gammas): mat(X) = mat(psi) mat(gamma_0) mat(psi~) on one sample of each kind (tolerance 1e-6), matrix ranks of the copies %s' % (n, rk))
    chk('bit==std', okM and rk == [RA[0]['dim'], RB[0]['dim']], 'n=%d: the exact dimensions %s agree with the matrices' % (n, [RA[0]['dim'], RB[0]['dim']]))

head('Answer [bit]')
ans = []
for n in (6, 7, 8):
    for tag in ('A', 'B'):
        R_ = SUMMARY[(n, tag)]; ans.append('n=%d %s: X5 != 0 on every sample, span %s of %d, X5 linear in X1 %s, definite forms %s' % (n, 'ideal' if tag == 'A' else 'Dirac copy', sorted({r['r5'] for r in R_}), comb(n, 5), sorted({r['rj'] == r['r1'] for r in R_}), sorted({len(r['definite']) for r in R_})))
chk('bit', all(all(s[2] > 0 for r in SUMMARY[k] for s in r['samples']) for k in SUMMARY), 'the grade-5 part of the current does not vanish on one copy for n = 6, 7, 8 (either meaning of copy): ' + '; '.join(ans))
finish('EMD-CURRENT')
