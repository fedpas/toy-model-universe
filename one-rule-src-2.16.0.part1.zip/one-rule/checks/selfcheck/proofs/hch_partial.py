#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""hch_partial.py -- the cells as twisted contracted algebras of the label monoid with zero, the low-degree cohomology of that monoid with
coefficients in F2 (the cochains defined where the product is not zero), the classes of the bit-rule signs; and the null labels as variables
of zero expectation.

Statements.
(1) On the labels of n bits with r null bits put a.b = a xor b when a and b share no null bit, and a.b = 0 otherwise: a monoid with zero M(n, r),
    unit the empty label.  For every choice of squares +-1 on the other bits, the bit-rule sign s(a,b) is non-zero exactly where a.b != 0, so
    Cl(p,q,r) is the twisted contracted monoid algebra of M with the twist s.
(2) Let D_k be the k-tuples with a non-zero product, C^k = F2^(D_k) (a 2-cochain "into {+-1} u {0}": the value 0 exactly on the zero products,
    +-1 written additively elsewhere) and d the bar differential (every face of a tuple in D_(k+1) lies in D_k).  d o d = 0; the dimensions of
    Z^k, B^k, H^k for k = 1, 2, 3 and every (n, r) with n <= 3; for r = 0 they are those of the group Z2^n, C(n+k-1, k).  Every bit-rule sign is a
    2-cocycle, and the 2^(p+q) choices of squares give 2^(p+q) distinct classes in H^2.
(3) For every cell with n <= 5 every label with a null bit has scalar part 0 and pairs to 0 with every label under <xy>_0: the scalar-part
    pairing has rank 2^(p+q).  The Koszul boundary on the labels squares to 0 and is exact, its rank from degree k being C(n-1, k-1) (n <= 6).
[bit]  Labels as bit masks, F2 linear algebra on bitsets (exact): the incidence matrices of d, their ranks and their products; the bit-rule
       signs read as F2 cochains; reduction modulo an echelon basis of B^2; the scalar part from the bit-rule products.
[std]  n <= 2: every function sigma: D_2 -> F2 (at most 2^16) turned into an algebra (e_a e_b = (-1)^sigma(a,b) e_(a.b), 0 on zero products)
       and tested for associativity on all basis triples; n <= 3: every tau on the labels (at most 2^8) and the set of distinct d tau; the
       Fock space of Lambda(R^m) with creation matrices (numpy, m <= 5) and the vacuum expectation.
[ctl]  The group Z2^n in place of the monoid with zero; one value of a sign flipped; the bar differential without its last face; the top-label
       coefficient in place of the scalar part; the Koszul boundary without its signs.  Each wrong version is also a --fault option that puts it into the main lines.
Scope. Monoid and supports n <= 4; cohomology n <= 3, k <= 3 (r <= n); brute force n <= 2 (cocycles) and n <= 3 (coboundaries); scalar part n <= 5.
       Recalled, not computed: the F2 cohomology ring of Z2^n (a polynomial ring), partial cohomology as a theory (Dokuchaev, Khrypchenko),
       semigroup algebras (Okninski); the BRST construction and the quartet mechanism (Becchi, Rouet, Stora; Tyutin; Kugo, Ojima).  The Koszul
       complex is also checked by check_T6.py (d^2 = 0 and the homotopy for n <= 7, the total rank for n <= 6); here the layers.  No engine object is built: the faults of the
       gravity engine do not apply.
Run:   python3 hch_partial.py [--fault NOZERO|BADSIGN|DELTA|SCALAR|UNSIGNED]
       (from the package root as selfcheck/proofs/hch_partial.py; also from its own folder, and under -I -B)"""
import os, sys, itertools, time
from math import comb
sys.dont_write_bytecode = True
import numpy as np

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'HCH-PAR'
FAULT_NAMES = ['NOZERO', 'BADSIGN', 'DELTA', 'SCALAR', 'UNSIGNED']
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r

ZERO = -1
def mono(n, r):
    """the label monoid with zero: null bits are the last r bits"""
    N = ((1 << r) - 1) << (n - r)
    def m(a, b):
        if a == ZERO or b == ZERO: return ZERO
        if not fault('NOZERO') and a & b & N: return ZERO
        return a ^ b
    return m, N

def f2_rank(rows):
    """rank over F2 of a list of int bitsets"""
    piv = {}
    for v in rows:
        while v:
            h = v.bit_length() - 1
            if h in piv: v ^= piv[h]
            else: piv[h] = v; break
    return len(piv)
def f2_echelon(rows):
    """fully reduced echelon basis {leading bit: row}"""
    piv = {}
    for v in rows:
        for h in sorted(piv, reverse=True):
            if v >> h & 1: v ^= piv[h]
        if v:
            h = v.bit_length() - 1
            for k in list(piv):
                if piv[k] >> h & 1: piv[k] ^= v
            piv[h] = v
    return piv
def f2_reduce(v, piv):
    for h in sorted(piv, reverse=True):
        if v >> h & 1: v ^= piv[h]
    return v

class Partial:
    def __init__(self, n, r):
        self.n, self.r = n, r; self.m, self.N = mono(n, r); d = 1 << n; self.d = d
        self.D = {0: [()]}
        for k in range(1, 5):
            self.D[k] = [t + (a,) for t in self.D[k - 1] for a in range(d) if self.prod(t + (a,)) != ZERO]
        self.idx = {k: {t: i for i, t in enumerate(self.D[k])} for k in self.D}
    def prod(self, t):
        x = 0
        for a in t: x = self.m(x, a)
        return x
    def faces(self, t):
        """the faces of a (k+1)-tuple as k-tuples (with multiplicity), the bar differential over F2"""
        k1 = len(t); out = [t[1:]]
        for i in range(k1 - 1): out.append(t[:i] + (self.m(t[i], t[i + 1]),) + t[i + 2:])
        if not fault('DELTA'): out.append(t[:-1])
        return out
    def row(self, t):
        """row of d^k at the (k+1)-tuple t: bitset over D_k"""
        v = 0; k = len(t) - 1
        for f in self.faces(t):
            if ZERO in f: continue
            v ^= 1 << self.idx[k][f]
        return v
    def ranks(self, kmax):
        return {k: f2_rank([self.row(t) for t in self.D[k + 1]]) for k in range(kmax + 1)}
    def dd_zero(self, kmax):
        ok = True
        for k in range(kmax):                                               # rows of d^(k+1) d^k at every (k+2)-tuple
            rows_k = {t: self.row(t) for t in self.D[k + 1]}
            for t in self.D[k + 2]:
                acc = 0
                for f in self.faces(t):
                    if ZERO in f: continue
                    if f in rows_k: acc ^= rows_k[f]
                ok &= (acc == 0)
        return ok
    def cochain_from_sign(self, eps, flip=False):
        v = 0
        for i, (a, b) in enumerate(self.D[2]):
            s = sgn(a, b, eps)
            if s == -1: v |= 1 << i
        if flip: v ^= 1 << (len(self.D[2]) // 2)
        return v
    def is_cocycle(self, v):
        for t in self.D[3]:
            acc = 0
            for f in self.faces(t):
                if ZERO in f: continue
                acc ^= (v >> self.idx[2][f]) & 1
            if acc: return False
        return True
    def coboundaries(self):
        return [self.row_transpose_1(a) for a in range(self.d)]
    def row_transpose_1(self, a):
        """d of the 1-cochain delta_a, as a bitset over D_2"""
        v = 0
        for i, t in enumerate(self.D[2]):
            if sum(1 for f in self.faces(t) if ZERO not in f and f == (a,)) % 2: v |= 1 << i
        return v

head('hch·18 CAND-079: the label monoid with zero, and the cells as its twisted contracted algebras (n <= 4)')
ok_m = True; ok_s = True; cnt_eps = 0
for n in range(1, 5):
    for r in range(0, n + 1):
        m, N = mono(n, r); d = 1 << n; L = list(range(d)) + [ZERO]
        ok_m &= all(m(m(a, b), c) == m(a, m(b, c)) for a in L for b in L for c in L) and all(m(0, a) == a == m(a, 0) for a in L)
        for signs in itertools.product((1, -1), repeat=n - r):
            eps = list(signs) + [0] * r; cnt_eps += 1
            ok_s &= all((sgn(a, b, eps) != 0) == (m(a, b) != ZERO) for a in range(d) for b in range(d))
chk('bit', ok_m and ok_s,
    'for every n <= 4 and r <= n the product a.b (xor, or 0 when a null bit is shared) is associative with unit the empty label and absorbing 0, and for all %d sign vectors (+-1 on the other bits) the bit-rule sign is non-zero exactly on the pairs with a.b != 0: Cl(p,q,r) is the contracted algebra of M(n, r) twisted by s' % cnt_eps)
tline('part 1')

head('hch·19 CAND-079: the cochains on the non-zero products, d o d = 0, and the dimensions of Z^k, B^k, H^k (exact over F2)')
TAB = {}; ok_dd = True; ok_grp = True
for n in range(1, 4):
    for r in range(0, n + 1):
        P = Partial(n, r)
        ok_dd &= P.dd_zero(3)
        rk = P.ranks(3); rk[-1] = 0
        dimC = {k: len(P.D[k]) for k in range(1, 4)}
        Z = {k: dimC[k] - rk[k] for k in range(1, 4)}; B = {k: rk[k - 1] for k in range(1, 4)}; H = {k: Z[k] - B[k] for k in range(1, 4)}
        TAB[(n, r)] = (dimC, Z, B, H)
        if r == 0: ok_grp &= all(H[k] == comb(n + k - 1, k) for k in (1, 2, 3))
chk('bit', ok_dd, 'd o d = 0 on every basis cochain of degree 0, 1, 2 (every (n, r) with n <= 3): the cochains on the non-zero products form a complex')
chk('bit', ok_grp, 'r = 0 (the group Z2^n): dim H^1, H^2, H^3 = %s for n = 1, 2, 3 = C(n+k-1, k), the F2 cohomology of Z2^n (T6 (c) for H^2)'
    % [[TAB[(n, 0)][3][k] for k in (1, 2, 3)] for n in (1, 2, 3)])
lines = '; '.join('(n,r)=(%d,%d): C %s Z %s B %s H %s' % (n, r, [v[0][k] for k in (1, 2, 3)], [v[1][k] for k in (1, 2, 3)], [v[2][k] for k in (1, 2, 3)], [v[3][k] for k in (1, 2, 3)]) for (n, r), v in sorted(TAB.items()))
chk('bit', all(v[0][k] == 2 ** (k * (n - r)) * (k + 1) ** r and v[1][k] == v[2][k] + v[3][k] for (n, r), v in TAB.items() for k in (1, 2, 3)),
    '|D_k| = 2^(k(n-r)) (k+1)^r (a null bit sits in at most one place of a tuple); dimensions of C^k, Z^k, B^k, H^k for k = 1, 2, 3: ' + lines)
tline('part 2')

head('hch·20 CAND-079: every bit-rule sign is a 2-cocycle; the choices of squares give distinct classes in H^2')
ok_c = True; classes = {}
for n in range(1, 4):
    for r in range(0, n + 1):
        P = Partial(n, r); piv = f2_echelon(P.coboundaries()); reps = set(); allc = True
        for signs in itertools.product((1, -1), repeat=n - r):
            eps = list(signs) + [0] * r
            v = P.cochain_from_sign(eps, flip=fault('BADSIGN'))
            allc &= P.is_cocycle(v); reps.add(f2_reduce(v, piv))
        classes[(n, r)] = (len(reps), 2 ** (n - r)); ok_c &= allc and len(reps) == 2 ** (n - r)
chk('bit', ok_c, 'for every (n, r) with n <= 3 the 2^(n-r) bit-rule signs (squares +-1 on the non-null bits) are 2-cocycles on the non-zero products, with pairwise different classes modulo B^2: (classes, choices) = %s'
    % {('%d,%d' % k): v for k, v in sorted(classes.items())})
if not FAULT:
    P = Partial(2, 0); v = P.cochain_from_sign([1, 1]); bad = v ^ (1 << 5)
    P1 = Partial(2, 1); v1 = P1.cochain_from_sign([1, 0])
    chk('ctl', not P.is_cocycle(bad) and P1.is_cocycle(v1),
        'one value of the Cl(2,0) sign flipped (the pair %s) is not a cocycle; the sign of Cl(1,0,1) is one: the test can fail' % (P.D[2][5],))
tline('part 3')

head('hch·21 CAND-079: [std] the same numbers by brute force: algebras tested for associativity (n <= 2), coboundaries listed (n <= 3)')
ok_bf = True; out = []
for n in (1, 2):
    for r in range(0, n + 1):
        P = Partial(n, r); D2 = P.D[2]; m = P.m; d = 1 << n; pos = {t: i for i, t in enumerate(D2)}
        cnt = 0
        trip = [(a, b, c) for a in range(d) for b in range(d) for c in range(d)]
        for sv in range(1 << len(D2)):
            def mul(x, y):
                p_ = m(x, y)
                if p_ == ZERO: return ZERO, 0
                return p_, (-1) ** ((sv >> pos[(x, y)]) & 1)
            good = True
            for (a, b, c) in trip:
                ab = mul(a, b)
                if ab[0] == ZERO: L = (ZERO, 0)
                else:
                    t_ = mul(ab[0], c); L = (t_[0], ab[1] * t_[1]) if t_[0] != ZERO else (ZERO, 0)
                bc = mul(b, c)
                if bc[0] == ZERO: R = (ZERO, 0)
                else:
                    t_ = mul(a, bc[0]); R = (t_[0], bc[1] * t_[1]) if t_[0] != ZERO else (ZERO, 0)
                if L != R: good = False; break
            cnt += good
        want = 2 ** TAB[(n, r)][1][2]; ok_bf &= (cnt == want); out.append('(%d,%d): %d of 2^%d = %d' % (n, r, cnt, len(D2), want))
for n in (1, 2, 3):
    for r in range(0, n + 1):
        P = Partial(n, r); d = 1 << n; seen = set()
        for tau in range(1 << d):
            v = 0
            for i, (a, b) in enumerate(P.D[2]):
                ab = P.m(a, b)
                if ((tau >> a & 1) + (tau >> b & 1) + (tau >> ab & 1)) & 1: v |= 1 << i
            seen.add(v)
        ok_bf &= (len(seen) == 2 ** TAB[(n, r)][2][2])
chk('std', ok_bf, 'associative twisted algebras among all sigma on D_2 = 2^(dim Z^2): %s; the distinct d tau over all 2^(2^n) functions tau on the labels number 2^(dim B^2) for every (n, r) with n <= 3' % '; '.join(out))
chk('bit==std', ok_bf, 'the F2 ranks of the complex and the brute-force counts agree (Z^2 for n <= 2, B^2 for n <= 3)')
tline('part 4')

head('hch·22 CAND-142: the null labels have zero expectation: <e_a>_0 = 0 and <e_a x>_0 = 0 for every label a with a null bit (n <= 5)')
ok_e = True; ranks = {}
for n in range(1, 6):
    for r in range(0, n + 1):
        for p in range(n - r + 1):
            q = n - r - p; eps = sig(p, q, r); d = 1 << n; F = d - 1; N = sum(1 << i for i in range(n) if eps[i] == 0)
            expv = (lambda a: 1 if a == F else 0) if fault('SCALAR') else (lambda a: 1 if a == 0 else 0)
            for a in range(d):
                if a & N:
                    ok_e &= expv(a) == 0
                    ok_e &= all(sgn(a, b, eps) * expv(a ^ b) == 0 for b in range(d))
            ranks[(p, q, r)] = sum(1 for a in range(d) if sgn(a, a, eps) != 0)
ok_e &= all(v == 2 ** (p + q) for (p, q, r), v in ranks.items())
chk('bit', ok_e, 'for all %d cells with 1 <= n <= 5 every label with a null bit has scalar part 0 and <e_a e_b>_0 = 0 for every b; the scalar-part pairing has rank 2^(p+q): the null generators are invisible to the scalar part (every state vanishes on J: cat·C3)' % len(ranks))
ok_f = True
for m_ in range(1, 6):
    D = 1 << m_
    def creator(i):
        C = np.zeros((D, D))
        for S in range(D):
            if not S >> i & 1: C[S | 1 << i, S] = (-1) ** pc(S & ((1 << i) - 1))
        return C
    cs = [creator(i) for i in range(m_)]
    vac = np.zeros(D); vac[0] = 1
    for S in range(1, D):
        X = np.eye(D)
        for i in range(m_):
            if S >> i & 1: X = X @ cs[i]
        state = X @ vac
        ok_f &= abs(vac @ X @ vac) < 1e-12 and abs(state[S]) == 1.0
    ok_f &= all(np.allclose(c @ c, 0) for c in cs) and all(np.allclose(cs[i] @ cs[j] + cs[j] @ cs[i], 0) for i in range(m_) for j in range(m_))
chk('std', ok_f and not fault('SCALAR'), 'Fock space of Lambda(R^m), m <= 5: the creation matrices square to 0 and anticommute, c_S^+|0> = +-e_S, and the vacuum expectation <0|c_S^+|0> = 0 for every non-empty S (numpy, tolerance 1e-12): the scalar part is the vacuum expectation')
chk('bit==std', ok_e and ok_f, 'both routes: every product containing a null generator has expectation 0')
tline('part 5')

head('hch·23 CAND-142: the Koszul boundary on the labels: d^2 = 0, exact, layer by layer (rank C(n-1, k-1) from degree k), n <= 6')
from fractions import Fraction
def rank_q(rows):
    piv = {}; rk = 0
    for v in rows:
        v = {k: Fraction(x) for k, x in v.items() if x}
        while v:
            k = min(v)
            if k in piv:
                f = v[k]
                for kk, x in piv[k].items():
                    y = v.get(kk, 0) - f * x
                    if y: v[kk] = y
                    else: v.pop(kk, None)
            else:
                f = v[k]; piv[k] = {kk: x / f for kk, x in v.items()}; rk += 1; break
    return rk
ok_kb = True; lay = {}
for n in range(1, 7):
    eps = [0] * n; d = 1 << n
    def dK(a):                                                               # d e_a = sum_(i in a) s(a - i, i) e_(a - i), s the bit-rule sign
        out = {}
        for i in range(n):
            if a >> i & 1:
                s = 1 if fault('UNSIGNED') else sgn(a ^ (1 << i), 1 << i, [1] * n)
                out[a ^ (1 << i)] = out.get(a ^ (1 << i), 0) + s
        return out
    dd = all(not any(v for v in (lambda D: {k: sum(c * dK(b).get(k, 0) for b, c in D.items()) for k in range(d)})(dK(a)).values()) for a in range(d))
    rk = [rank_q([dK(a) for a in range(d) if pc(a) == k]) for k in range(n + 1)]
    lay[n] = rk[1:]
    ok_kb &= dd and rk[1:] == [comb(n - 1, k - 1) for k in range(1, n + 1)] and sum(rk) == 2 ** (n - 1)
chk('bit', ok_kb, 'd e_a = sum_(i in a) s(a - i, i) e_(a - i) with the bit-rule sign of e_(a-i) e_i: d o d = 0 on every label, the rank from degree k is C(n-1, k-1) (%s for n = 6) and the total rank is 2^(n-1) = half of 2^n: kernel = image: zero cohomology in every degree (exact over Q, n <= 6)' % lay[6])
ok_ks = True
for n in range(1, 7):
    basis = [c for k in range(n + 1) for c in itertools.combinations(range(n), k)]; pos = {b: i for i, b in enumerate(basis)}
    Dm = np.zeros((len(basis), len(basis)))
    for T in basis:
        for k in range(len(T)): Dm[pos[T[:k] + T[k + 1:]], pos[T]] += (-1) ** k
    ok_ks &= np.allclose(Dm @ Dm, 0) and int(np.linalg.matrix_rank(Dm, tol=1e-8)) == 2 ** (n - 1)
    ok_ks &= all(int(np.linalg.matrix_rank(Dm[:, [pos[T] for T in basis if len(T) == k]], tol=1e-8)) == comb(n - 1, k - 1) for k in range(1, n + 1))
chk('std', ok_ks, 'the textbook contraction on sorted index tuples, sum_k (-1)^k (T without its k-th entry), as numpy matrices: d^2 = 0, total rank 2^(n-1), rank C(n-1, k-1) from degree k, n <= 6 (tolerance 1e-8)')
chk('bit==std', ok_kb and ok_ks, 'both conventions (the bit-rule sign removes a generator on the right, the textbook one on the left) give the same layers')
if not FAULT:
    FAULT = 'UNSIGNED'
    bad = any(any(v for v in {k: sum(c * (lambda a: {a ^ (1 << i): 1 for i in range(3) if a >> i & 1})(b).get(k, 0) for b, c in (lambda a: {a ^ (1 << i): 1 for i in range(3) if a >> i & 1})(a).items()) for k in range(8)}.values()) for a in range(8))
    FAULT = None
    chk('ctl', bad, 'the boundary without signs (all +1) does not square to 0 on Lambda(R^3): the sign is what makes the complex')
tline('part 6')
finish(STEP)
