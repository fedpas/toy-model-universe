#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""theta_walsh.py: the finite theta law of the clock. The Gauss sum G = sum_a i^w(a) over the labels of a cell (LAB-017: G = (1+i)^p (1-i)^q,
the clock its phase) is its own Walsh transform: sum_a i^w(a) (-1)^(a.b) = G i^(-w(b)) for every label b, because w is a Z4-valued quadratic
refinement of the dot product, w(a + b) = w(a) + w(b) + 2 a.b mod 4 (core.B1).  This is the finite form of theta(-1/z) = (-iz)^(1/2) theta(z)
(Poisson summation on a lattice: the Fourier transform of a Gaussian is a Gaussian), with the dual label b and the phase i^(-w(b)) in place
of the dual lattice and the quadratic exponent (the reading is ours).      python3 theta_walsh.py [--fault NAME]

T1. every cell Cl(p,q), p + q = n <= 10 (66 cells): w from the bit rule (w(a) = (|a| mod 2) + 2 [e_a^2 = -1], in Z4), the refinement identity on all
    4^n pairs (n <= 7) and the theta law on all 2^n labels b (n <= 10), as Gaussian integers; the transform of i^w at b is G times the
    conjugate-free phase i^(-w(b)), so |transform| = 2^(n/2) at every b (a bent function in the Z4 sense).
T2. the standard route: w(a) = |a meet P| - |a meet Q| mod 4 (the charge of the generators, core.B2), the Walsh-Hadamard transform by the fast
    butterfly in numpy (complex floats), G = (1+i)^p (1-i)^q by direct multiplication: agreement with T1 at every b to 1e-9, n <= 10.
[ctl]  NOPARITY (w without the parity term, 2 [e_a^2 = -1]: not a refinement of the dot product; the law fails), DOT (the symplectic
       commutation form in place of the dot product).
Scope: n <= 10, all signatures with r = 0.  Standard library and numpy.
Command: python3 theta_walsh.py   (from this folder, or python3 selfcheck/proofs/theta_walsh.py from the root of the checks)."""
import os, sys, time
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p)
from bitcliff import Alg, sig, pc

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('NOPARITY', 'DOT')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time(); NMAX = 10
I4 = [1, 1j, -1, -1j]                                                        # i^k as Gaussian integers (complex with integer parts)

def w_bit(alg):
    """w(a) = |a| + 2 [e_a^2 = -1] mod 4 from the bit rule"""
    return [((0 if FAULT == 'NOPARITY' else pc(a) & 1) + (2 if alg.sq(a) == -1 else 0)) % 4 for a in range(alg.N)]
def pairing(a, b, alg):
    if FAULT == 'DOT': return (pc(a) * pc(b) + pc(a & b)) % 2                 # the commutation form (polar.P1), a control
    return pc(a & b) % 2
head('T1. the bit rule: w, the refinement identity and the theta law, all cells with p + q <= %d' % NMAX)
ok_ref = True; ok_law = True; ok_bent = True; ncells = 0; npairs = 0; nb = 0; GS = {}
for n in range(0, NMAX + 1):
    for p in range(0, n + 1):
        q = n - p; alg = Alg(sig(p, q)); N = alg.N; w = w_bit(alg); ncells += 1
        if n <= 7:
            for a in range(N):
                for b in range(N):
                    if (w[a ^ b] - w[a] - w[b] - 2 * pairing(a, b, alg)) % 4: ok_ref = False
            npairs += N * N
        phase = np.array([I4[x] for x in w])
        G = complex(np.sum(phase)); GS[(p, q)] = G
        Gi = complex(round(G.real), round(G.imag)); assert abs(G - Gi) < 1e-9; G = Gi
        # the transform at every b: sum_a i^w(a) (-1)^(a.b)
        A = np.arange(N)
        for b in range(N):
            s = np.array([(-1) ** pairing(a, b, alg) for a in range(N)]) if FAULT == 'DOT' else (-1.0) ** np.array([pc(x) for x in (A & b)])
            T = complex(np.sum(phase * s)); Ti = complex(round(T.real), round(T.imag)); assert abs(T - Ti) < 1e-9
            if Ti != G * I4[(-w[b]) % 4]: ok_law = False
            if abs(abs(Ti) ** 2 - N) > 1e-9: ok_bent = False
            nb += 1
chk('bit', ok_ref, 'tht.T1: w(a + b) = w(a) + w(b) + 2 a.b mod 4 on all %d label pairs of the %d cells with p + q <= 7 (w = parity + 2 [square = -1])' % (npairs, sum(n + 1 for n in range(8))))
chk('bit', ok_law, 'tht.T1: the theta law: sum_a i^w(a) (-1)^(a.b) = G i^(-w(b)) for every label b of every cell with p + q <= %d (%d cells, %d values of b), as Gaussian integers' % (NMAX, ncells, nb))
chk('bit', ok_bent, 'tht.T1: |transform(b)|^2 = 2^n at every b: the phase i^w is flat under the Walsh transform (a Z4 bent function), as |G|^2 = 2^n')
head('T2. the standard route: the charge w(a) = |a meet P| - |a meet Q| mod 4, the fast Walsh-Hadamard transform in numpy, G = (1+i)^p (1-i)^q')
def fwht(x):
    y = x.copy(); h = 1; N = len(y)
    while h < N:
        y = y.reshape(-1, 2, h); a = y[:, 0, :].copy(); b = y[:, 1, :].copy(); y[:, 0, :] = a + b; y[:, 1, :] = a - b; y = y.reshape(N); h *= 2
    return y
ok_std = True; ok_same = True; ok_G = True
for n in range(0, NMAX + 1):
    for p in range(0, n + 1):
        q = n - p; N = 1 << n; A = np.arange(N); P = (1 << p) - 1; Qm = ((1 << n) - 1) ^ P
        cp = np.array([pc(x) for x in (A & P)]); cq = np.array([pc(x) for x in (A & Qm)])
        w_std = (cp - cq) % 4
        f = (1j) ** w_std; T = fwht(f); G = f.sum(); Gf = (1 + 1j) ** p * (1 - 1j) ** q
        ok_G &= abs(G - Gf) < 1e-9
        ok_std &= np.max(np.abs(T - G * (1j) ** ((-w_std) % 4))) < 1e-9
        alg = Alg(sig(p, q)); ok_same &= np.array_equal(w_std, np.array(w_bit(alg)) if FAULT != 'NOPARITY' else -np.ones(N))
chk('std', ok_std and ok_G, 'tht.T2: numpy, no label: the fast Walsh-Hadamard transform of i^w with the charge w = |a meet P| - |a meet Q| mod 4 equals G i^(-w(b)) at every b, G = (1+i)^p (1-i)^q, all cells p + q <= %d' % NMAX)
chk('bit==std', ok_same, 'tht.T2: the charge w agrees with the bit-rule w = parity + 2 [square = -1] label by label on every cell (core.B2)')
# controls computed in place
alg = Alg(sig(2, 1)); N = alg.N
w_np = [(2 if alg.sq(a) == -1 else 0) for a in range(N)]; phase = np.array([I4[x] for x in w_np]); G = complex(np.sum(phase))
bad_np = any(complex(np.sum(phase * (-1.0) ** np.array([pc(a & b) for a in range(N)]))) != G * I4[(-w_np[b]) % 4] for b in range(N))
w_ok = w_bit(alg) if FAULT != 'NOPARITY' else [((pc(a) & 1) + (2 if alg.sq(a) == -1 else 0)) % 4 for a in range(N)]; phase2 = np.array([I4[x] for x in w_ok]); G2 = complex(np.sum(phase2))
bad_dot = any(complex(np.sum(phase2 * (-1.0) ** np.array([(pc(a) * pc(b) + pc(a & b)) % 2 for a in range(N)]))) != G2 * I4[(-w_ok[b]) % 4] for b in range(N))
chk('ctl', bad_np and bad_dot, 'tht: on Cl(2,1) the law fails without the parity term in w (NOPARITY) and with the commutation form in place of the dot product (DOT)')
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('THETA-WALSH')
