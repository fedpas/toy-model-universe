#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""even_conj.py: on the even part of a Clifford algebra, Clifford conjugation is reversion.

Statement. Clifford conjugation is x-bar = alpha(x-tilde), alpha the grade involution (e_i -> -e_i, extended as an algebra map: +1 on even
grades, -1 on odd grades) and x-tilde the reversion. On a blade of grade k the three involutions act by the signs (-1)^k, (-1)^(k(k-1)/2) and
(-1)^(k(k+1)/2), and k(k+1)/2 - k(k-1)/2 = k, so Clifford conjugation and reversion differ by the sign (-1)^k: they agree on every even grade and are
opposite on every odd grade. Hence x-bar = x-tilde for every even x, M M-bar = M M-tilde for every even M (rotors and motors are even), and
psi gamma_0 psi-tilde and psi psi-tilde are the same with either for even psi; on odd x, x-bar = -x-tilde. The argument is the line above: it holds
for every n and for every signature, null generators included. The script computes it in the algebras listed below.

  [bit]      the bit product e_a e_b = s(a,b) e_(a xor b) (reordering sign times the squares of the shared generators) of Cl(p,q,r) with p
             generators squaring to +1, q to -1, r to 0. Reversion is the product of the generators of a blade in the reverse order, alpha
             the product of the negated generators in the given order, Clifford conjugation both ways (alpha after reversion, and the
             product of the negated generators in the reverse order); each sign is read off the bit product. Checked: alpha is an algebra
             map and reversion and conjugation are anti-maps on every pair of blades; on every even blade alpha = +1 and conjugation =
             reversion; on 20 random even elements per algebra (every even blade present, coefficients non-zero integers in -50..50)
             conjugation = reversion and M M-bar = M M-tilde through the product; psi gamma_0 psi-tilde = psi gamma_0 psi-bar and
             psi psi-tilde = psi psi-bar; an explicit rotor 3 + 4 e0e1 of Cl(2,0) and a motor 2 + e0 e3 (e3 null) of Cl(3,0,1).
  [std]      the three signs from the grade alone, no algebra: (-1)^k, (-1)^(k(k-1)/2), (-1)^(k(k+1)/2) for k = 0..64, the identity
             k(k+1)/2 - k(k-1)/2 = k for k = 0..200, and so conjugation sign = alpha sign x reversion sign, equal to the reversion
             sign on even k and opposite on odd k.
  [bit==std] the sign read off the bit product equals the grade formula on every blade of every algebra, for the three involutions.
  [ctl]      on odd elements conjugation = -reversion (blades and 20 random odd elements per algebra), so x-bar != x-tilde for every non-zero
             odd x and M M-bar = -M M-tilde != M M-tilde whenever M M-tilde != 0; the reversion without its sign and conjugation taken
             as alpha alone are not the conjugation on the even blades of grade 2 (mod 4).
  --fault NAME  the wrong version of one control, each exits with code 1:
             rev-nosign (reversion without the reversed order), conj-as-alpha (conjugation taken as alpha), all-grades (the equality
             asserted on every blade), std-sign (the grade formula of conjugation with the exponent of reversion), odd-equal (the equality
             asserted on odd elements).

Scope: every Cl(p,q) with p + q <= 6 (28 algebras) and every Cl(p,q,r) with r >= 1 and p + q + r <= 4 (20 algebras); exact integers; seeded.
The script builds no object of the gravity engine (Forms, Lie, Grav): the engine faults do not reach it; its controls are its own.

  python3 even_conj.py      one line per check, each starting with its id evenconj·1 ... evenconj·9; last line FAILS (EVENCONJ): none; exit code 1 on a failure
"""
import random, sys

FAULTS = ('rev-nosign', 'conj-as-alpha', 'all-grades', 'std-sign', 'odd-equal')
FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv and sys.argv.index('--fault') + 1 < len(sys.argv) else None
if '--fault' in sys.argv and FAULT not in FAULTS: sys.exit('--fault NAME: one of ' + ', '.join(FAULTS))

# ---------------------------------------------------------------- the three helpers of selfcheck/gravity/b1lib.py
FAILS = []
def chk(tag, cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + '[' + tag + '] ' + msg)
    if not cond: FAILS.append(msg)
    return bool(cond)
def head(s):
    print('\n' + s)
def finish(STEP):
    print('\nFAILS (%s): %s' % (STEP, '; '.join(FAILS) if FAILS else 'none'))
    sys.exit(1 if FAILS else 0)

# ---------------------------------------------------------------- [bit] the bit product and the three involutions read off it
def pc(a): return bin(a).count('1')
def bit_mul(a, b, eps):
    """e_a e_b = s e_(a xor b): the reordering sign times the product of the squares of the shared generators"""
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return a ^ b, s
class Alg:
    def __init__(self, p, q, r=0):
        self.p, self.q, self.r, self.n = p, q, r, p + q + r
        self.eps = [1] * p + [-1] * q + [0] * r
        N = 1 << self.n
        self.T = [[bit_mul(a, b, self.eps) for b in range(N)] for a in range(N)]
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                m, s = self.T[a][b]
                if s: out[m] = out.get(m, 0) + s * ca * cb
        return {k: v for k, v in out.items() if v}
def gens(a): return [i for i in range(a.bit_length()) if a >> i & 1]
def chain_sign(A, a, order, coef):
    """the generators of the blade a multiplied through the bit product in the given order, each times coef: the sign of the result (its mask is a)"""
    mask, s = 0, 1
    for i in order:
        mask, t = A.T[mask][1 << i]; s *= t * coef
    assert mask == a
    return s
def rev_sign(A, a):
    return chain_sign(A, a, gens(a) if FAULT == 'rev-nosign' else gens(a)[::-1], 1)      # fault rev-nosign: the product is not reversed
def alpha_sign(A, a): return chain_sign(A, a, gens(a), -1)
def conj_sign(A, a): return alpha_sign(A, a) if FAULT == 'conj-as-alpha' else alpha_sign(A, a) * rev_sign(A, a)    # x-bar = alpha(x-tilde)
def conj_sign2(A, a): return chain_sign(A, a, gens(a)[::-1], -1)                         # the anti-map e_i -> -e_i: the images in the reverse order
def app(sg, x): return {a: sg[a] * c for a, c in x.items()}
def rand_el(rng, n, parity):
    return {a: rng.choice((-1, 1)) * rng.randint(1, 50) for a in range(1 << n) if pc(a) % 2 == parity}

# ---------------------------------------------------------------- [std] the signs from the grade alone
def std_sign(kind, k):
    if kind == 'alpha': return (-1) ** k
    if kind == 'rev': return (-1) ** (k * (k - 1) // 2)
    return (-1) ** (k * (k - 1) // 2) if FAULT == 'std-sign' else (-1) ** (k * (k + 1) // 2)

def work(A, seed, S):
    """every check that needs the algebra A; the counters go to S"""
    n, N = A.n, 1 << A.n
    R = {a: rev_sign(A, a) for a in range(N)}; Al = {a: alpha_sign(A, a) for a in range(N)}; Cj = {a: conj_sign(A, a) for a in range(N)}
    C2 = {a: conj_sign2(A, a) for a in range(N)}
    S['algs'] += 1; S['blades'] += N
    S['grade_bad'] += sum(1 for a in range(N) if (R[a], Al[a], Cj[a]) != (std_sign('rev', pc(a)), std_sign('alpha', pc(a)), std_sign('conj', pc(a))))
    S['two_ways_bad'] += sum(1 for a in range(N) if Cj[a] != C2[a])
    for a in range(N):
        for b in range(N):
            m, s = A.T[a][b]; _, s2 = A.T[b][a]; S['pairs'] += 1
            S['morph_bad'] += (s * Al[m] != Al[a] * Al[b] * s) + (s * R[m] != R[a] * R[b] * s2) + (s * Cj[m] != Cj[a] * Cj[b] * s2)
    blades = range(N) if FAULT == 'all-grades' else [a for a in range(N) if pc(a) % 2 == 0]       # fault all-grades: the equality asserted on every blade
    S['even_blades'] += len(blades); S['even_bad'] += sum(1 for a in blades if Cj[a] != R[a] or (pc(a) % 2 == 0 and Al[a] != 1))
    S['wrong_rev_k2'] += sum(1 for a in range(N) if pc(a) == 2 and Cj[a] != 1)              # the reversion without its sign (+1) is not the conjugation on a grade 2 blade
    S['wrong_alpha_k2'] += sum(1 for a in range(N) if pc(a) == 2 and Cj[a] != Al[a])         # alpha alone is not the conjugation on a grade 2 blade
    if n == 0: return
    S['odd_blades'] += sum(1 for a in range(N) if pc(a) % 2 == 1)
    S['odd_blades_bad'] += sum(1 for a in range(N) if pc(a) % 2 == 1 and (Cj[a] != R[a] if FAULT == 'odd-equal' else Cj[a] != -R[a]))
    rng = random.Random(seed)
    g0 = {1: 1}
    for _ in range(20):
        x = rand_el(rng, n, 0); xt, xb = app(R, x), app(Cj, x)
        S['even_el'] += 1; S['even_el_bad'] += (xb != xt)
        M1, M2 = A.mul(x, xt), A.mul(x, xb); S['mm'] += 1; S['mm_bad'] += (M1 != M2)
        X1, X2 = A.mul(A.mul(x, g0), xt), A.mul(A.mul(x, g0), xb); S['psi'] += 1; S['psi_bad'] += (X1 != X2)
        y = rand_el(rng, n, 1); yt, yb = app(R, y), app(Cj, y)
        S['odd_el'] += 1; S['odd_el_bad'] += (yb != (yt if FAULT == 'odd-equal' else app({a: -1 for a in y}, yt))) + (yb == yt)
        Q1, Q2 = A.mul(y, yt), A.mul(y, yb)
        if Q1:
            S['odd_mm'] += 1; S['odd_mm_bad'] += (Q2 != app({a: -1 for a in Q1}, Q1)) + (Q2 == Q1)

def algebras():
    nondeg = [(p, n - p, 0) for n in range(7) for p in range(n + 1)]
    deg = [(p, n - r - p, r) for n in range(1, 5) for r in range(1, n + 1) for p in range(n - r + 1)]
    return nondeg, deg

def fresh():
    return dict(algs=0, blades=0, grade_bad=0, two_ways_bad=0, pairs=0, morph_bad=0, even_blades=0, even_bad=0, wrong_rev_k2=0, wrong_alpha_k2=0,
                odd_blades=0, odd_blades_bad=0, even_el=0, even_el_bad=0, mm=0, mm_bad=0, psi=0, psi_bad=0, odd_el=0, odd_el_bad=0, odd_mm=0, odd_mm_bad=0)

def main():
    head('[std] the three involutions by their signs on the grade alone (no algebra)')
    K = range(65)
    table = lambda kind, m: ' '.join('+' if std_sign(kind, k) == 1 else '-' for k in range(m))
    chk('std', all(std_sign('conj', k) == std_sign('alpha', k) * std_sign('rev', k) for k in K),
        f'evenconj·1  sign of Clifford conjugation (-1)^(k(k+1)/2) = (-1)^k (-1)^(k(k-1)/2) = alpha sign x reversion sign for k = 0..64; k = 0..7: alpha {table("alpha", 8)} | reversion {table("rev", 8)} | conjugation {table("conj", 8)}')
    chk('std', all(std_sign('conj', k) == (std_sign('rev', k) if k % 2 == 0 else -std_sign('rev', k)) for k in K),
        'evenconj·1  conjugation sign = reversion sign on every even grade and = minus the reversion sign on every odd grade, k = 0..64')
    chk('std', all(k * (k + 1) // 2 - k * (k - 1) // 2 == k for k in range(201)),
        'evenconj·1  the exponents differ by k exactly (k(k+1)/2 - k(k-1)/2 = k, k = 0..200; for every k by cancelling): the signs differ by (-1)^k, +1 on even grades for every n and every signature')
    nondeg, deg = algebras()
    groups = []
    for label, sigs in (('Cl(p,q), p + q <= 6', nondeg), ('Cl(p,q,r), r >= 1, p + q + r <= 4', deg)):
        S = fresh()
        for (p, q, r) in sigs: work(Alg(p, q, r), 7000 + 100 * p + 10 * q + r, S)
        groups.append((label, len(sigs), S))
        head(f'[bit] {label}: {len(sigs)} algebras, {S["blades"]} blades')
        chk('bit', S['morph_bad'] == 0 and S['two_ways_bad'] == 0,
            f'evenconj·2  alpha is an algebra map and reversion and conjugation are anti-maps on all {S["pairs"]} blade pairs; conjugation read as alpha after reversion equals the anti-map e_i -> -e_i on every blade')
        chk('bit', S['even_bad'] == 0,
            f'evenconj·3  alpha = +1 and conjugation = reversion on each of the {S["even_blades"]} even blades (the grade involution is the identity on even elements)')
        chk('bit', S['even_el_bad'] == 0 and S['even_el'] > 0,
            f'evenconj·4  conjugation = reversion on {S["even_el"]} random even elements (20 per algebra with n >= 1, every even blade present, coefficients non-zero integers in -50..50)')
        chk('bit', S['mm_bad'] == 0 and S['mm'] > 0, f'evenconj·5  M M-bar = M M-tilde through the bit product on the same {S["mm"]} even elements')
        chk('bit', S['psi_bad'] == 0 and S['psi'] > 0, f'evenconj·6  psi gamma_0 psi-tilde = psi gamma_0 psi-bar (gamma_0 the generator of mask 1) on the same {S["psi"]} even elements; psi psi-tilde = psi psi-bar is the case without gamma_0 of M M-bar above')
    A2 = Alg(2, 0); R2 = {a: rev_sign(A2, a) for a in range(4)}; C2 = {a: conj_sign(A2, a) for a in range(4)}
    rot = {0: 3, 3: 4}; A4 = Alg(3, 0, 1); R4 = {a: rev_sign(A4, a) for a in range(16)}; C4 = {a: conj_sign(A4, a) for a in range(16)}
    mot = {0: 2, 0b1001: 1}
    chk('bit', A2.mul(rot, app(R2, rot)) == A2.mul(rot, app(C2, rot)) == {0: 25} and A4.mul(mot, app(R4, mot)) == A4.mul(mot, app(C4, mot)) == {0: 4},
        'evenconj·6  an explicit rotor R = 3 + 4 e0e1 of Cl(2,0): R R-tilde = R R-bar = 25; an explicit motor M = 2 + e0e3 (e3 null) of Cl(3,0,1): M M-tilde = M M-bar = 4')
    head('[bit==std] the sign read off the bit product against the grade formula')
    gb = sum(S['grade_bad'] for _, _, S in groups); nb = sum(S['blades'] for _, _, S in groups); na = sum(S['algs'] for _, _, S in groups)
    chk('bit==std', gb == 0, f'evenconj·7  reversion, alpha and conjugation: the bit-product sign equals (-1)^(k(k-1)/2), (-1)^k, (-1)^(k(k+1)/2) on every blade ({nb} blades of {na} algebras, k the grade)')
    head('[ctl] odd elements and wrong versions')
    for label, _, S in groups:
        chk('ctl', S['odd_blades_bad'] == 0 and S['odd_blades'] > 0 and S['odd_el_bad'] == 0 and S['odd_el'] > 0,
            f'evenconj·8  {label}: on the {S["odd_blades"]} odd blades and {S["odd_el"]} random odd elements conjugation = -reversion, so conjugation != reversion for every non-zero odd element')
        chk('ctl', S['odd_mm_bad'] == 0 and S['odd_mm'] > 0,
            f'evenconj·8  {label}: M M-bar = -M M-tilde != M M-tilde on the {S["odd_mm"]} random odd M with M M-tilde != 0 (the choice of involution matters for odd versors, not for even ones)')
    wr = sum(S['wrong_rev_k2'] for _, _, S in groups); wa = sum(S['wrong_alpha_k2'] for _, _, S in groups)
    chk('ctl', wr > 0 and wa > 0,
        f'evenconj·9  the reversion without its sign (the identity on blades) differs from conjugation on {wr} blades of grade 2, and alpha alone on {wa}: neither is the conjugation on the even blades of grade 2 (mod 4)')
    finish('EVENCONJ')

if __name__ == '__main__':
    main()
