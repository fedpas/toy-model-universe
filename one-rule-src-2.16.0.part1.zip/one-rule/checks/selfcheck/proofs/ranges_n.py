#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""ranges_n.py: four closed forms of the bit rule, each with a derivation that holds for every n, checked over the range the engine reaches.

     python3 ranges_n.py [--fault EVEN|NONDIAG|RADW2|NORAD|SIGNN|SIGNP|CENTRE|NONCHAR|LEVEN]

Z (range.Z1..Z6).  The Z4 form w = pi + 2Q of a diagonal cell, e_j^2 = eps_j.
   Derivation, every n.  (1) e_a^2 = (-1)^C(|a|,2) prod_{j in a} eps_j, so Q(a) = C(|a|,2) + |a & N| mod 2 (N the -1 bits); with
   (m mod 2) + 2 C(m,2) = m mod 4 (the step m -> m+1 adds 1 mod 4) w(a) = |a| + 2|a & N| = sum_{j in a} k_j mod 4, k_j = 1 for +1 and 3 for -1.
   (2) For disjoint a, b: pi(a+b) = pi(a) + pi(b) - 2 pi(a) pi(b) in the integers, so w(a+b) - w(a) - w(b) = 2 (b'(a,b) - |a||b|) mod 4 for
   any quadratic form Q' with polar form b'; it is 0 on all disjoint pairs iff b'(e_i,e_j) = 1 for i != j (singletons, bilinearity).
   (3) i^{sum_{j in a} k_j} = prod_{j in a} i^{k_j}, so sum_a i^{w(a)} = prod_j (1 + i^{k_j}); a null generator has charge 0 and gives the factor 2.
   (4) For a Z4 refinement w of a non-degenerate form b on V: G(w) conj G(w) = sum_z i^{w(z)} sum_y (-1)^{b(y,z)} = |V|; G is a Gaussian integer
   of norm 2^d, hence (1+i)^d i^t = 2^{d/2} zeta^beta (zeta = e^{2 pi i/8}): the Brown invariant beta in Z/8 is the exponent of the Gauss sum.
   G(w1 + w2) = G(w1) G(w2), so beta adds on orthogonal sums; for k_j = 1, 3 it is p - q.  (5) (a+b)_j = a_j + b_j - 2 a_j b_j gives
   w_k(a+b) - w_k(a) - w_k(b) = 2 sum_{j in a&b} k_j mod 4, equal to 2|a&b| for all a, b iff every k_j is odd (take a = b = {j}).
D (range.D1..D5).  The degenerate case.  Derivation, every dimension.  Let w(x+y) = w(x) + w(y) + 2B(x,y) on V, R = rad B.  (1) w(0) = 0 and for
   x in R, 0 = w(x+x) = 2 w(x) + 2 B(x,x) = 2 w(x), so w(x) in {0,2}; on R, w(x+y) = w(x) + w(y): w|R is a homomorphism R -> {0,2}.  (2) If
   w(r0) = 2, x -> x + r0 is an involution with w(x+r0) = w(x) + 2 + 2B(x,r0) = w(x) + 2, so i^w changes sign and G = 0.  (3) If w|R = 0,
   w(x+r) = w(x): w descends to V/R with the induced non-degenerate form, G(w) = |R| G(w-bar) != 0, and the Brown invariant is that of w-bar.
   Cells: B is the dot product on the non-null bits (R = span of the null bits) and w_c(a) = sum over non-null bits of a of k_j + 2 (c . a_null)
   for c in F_2^r, the 2^r homomorphisms of R; c = 0 is the clock of the cell (null bits of weight 0).  A refinement is determined by
   its single-bit increments: if w(x+e_j) - w(x) - w(e_j) = 2 B(x,e_j) for all x, j then w(x+y) - w(x) - w(y) = 2 B(x,y) for all x, y (induction on |y|).
W (range.W1..W4).  omega^2 and the centre.  Derivation, every n.  (1) Reversing n anticommuting generators takes n(n-1)/2 swaps:
   omega-tilde = (-1)^{n(n-1)/2} omega (in the bit rule the reordering exponent of top*top is sum_{i<n} popcount(top & (2^i - 1)) = n(n-1)/2).
   (2) omega omega-tilde = e_1..e_n e_n..e_1 = prod_j eps_j (collapse the middle pair, induction) = (-1)^q for r = 0, 0 for r >= 1.  (3) So
   omega^2 = (-1)^{n(n-1)/2} omega omega-tilde = (-1)^{n(n-1)/2 + q} (r = 0) and 0 (r >= 1).  (4) Centre: for a blade e_a, e_j e_a = (-1)^{|a|} e_a e_j
   if j is not in a, (-1)^{|a|-1} e_a e_j if j is in a and not null, and both products are 0 if j is in a and null; products of different blades land
   on different blades, so z is central iff each blade of z is.  A blade with a non-null generator is central iff |a| is odd and nothing lies outside
   a: omega, n odd.  A blade nu_S of null generators is central iff |S| is even (or S is everything: omega).  So the centre is span{nu_S : |S| even}
   + R omega [n odd]: R, R + R omega for r = 0; dimension 2^(r-1) + [n odd] for r >= 1 (the same R, R + R omega for r = 1, larger for r >= 2).  The super-centre (e_a e_j = (-1)^{|a|} e_j e_a for all j) is
   span{nu_S}, all S: Lambda(R^r), dimension 2^r.
L (range.L1..L6).  The characteristic vector mod 2.  Derivation, every odd unimodular lattice L of rank n.  (1) x -> x.x mod 2 is additive on L/2L
   ((x+y)^2 = x^2 + y^2 + 2 x.y) and onto F_2 (L odd): L_even = {x.x even} has index 2, contains 2L, dim L_even/2L = n - 1; x.x/2 mod 2 is well defined
   on L_even/2L ((x+2y)^2 = x^2 mod 4).  (2) L unimodular: x.x mod 2 = k.x mod 2 for some k (characteristic), k != 0 since L is odd; k-perp is a kernel,
   hence saturated, of rank n - 1, and x.x = k.x = 0 mod 2 on it: k-perp lies in L_even.  (3) k-perp -> L_even/2L has kernel k-perp & 2L = 2 k-perp
   (L is torsion free): an injection k-perp/2k-perp -> L_even/2L between F_2-spaces of dimension n - 1, an isometry of x.x/2 mod 2, for every k.
   (4) L = I_{p,q}: x mod 2 is the label a = {i : x_i odd}; x.x = sum eps_i x_i^2 = |a & P| - |a & N| = w(a) mod 4 (odd squares are 1 mod 4, even
   squares 0), so L_even/2L is the set of even labels and x.x/2 mod 2 = w(a)/2 = Q(a) there (pi = 0).  Dropping a pivot generator b (f_i = e_i e_b)
   maps the even labels onto the labels of Cl(p,q-1) (b negative) or Cl(q,p-1) (b positive) with Q preserved.  The characteristic vectors of I_{p,q}
   are the vectors with every coordinate odd.

[bit]  The bit rule of core_check (sgn, Q, w4, sig, brown_target), BR of bitrule_A (products of multivectors), f2lib (q_clifford, form_invariants);
       Gaussian integers as pairs of ints; Fraction elimination for the exact null spaces.
[std]  No bit rule: the lattice reading x.x mod 4, the charges sum eps_j, cmath sums in floats, numpy regular representations built from the
       relation-by-relation product (left and right multiplication matrices, SVD null spaces), Jordan-Wigner matrices, own integer routines
       (extended Euclid kernel basis, Smith normal form, exact solve) for the lattices.
Controls ([ctl], each has a --fault that puts the wrong version into a main line, which must then FAIL):
   EVEN one weight k_j even in place of odd; NONDIAG a cross term 2 a_1 a_2 added to w; RADW2 a radical vector with w = 2 in the clock sum;
   NORAD only cells without a radical (the criterion has nothing to detect); SIGNN the exponent n(n+1)/2 in place of n(n-1)/2; SIGNP (-1)^p;
   CENTRE the centre R + R omega read for r >= 1; NONCHAR a vector with an even coordinate in place of a characteristic one; LEVEN L_even in place of k-perp.
Scope: Z at every n by the derivation; checked on every label of every (p,q,r) with n <= 10 (exact), on the Gauss sum of every (p,q,r) with n <= 16
       (exact), on all 2^(n(n+1)/2) quadratic forms for n <= 5, on all weight vectors in (Z/4)^n for n <= 6 and all multisets of weights for n <= 8.
       D at every dimension by the derivation; checked on every (p,q,r) with r <= 3, n <= 9 and every character of the radical, on every Z4
       refinement of every symmetric form on F_2^m for m <= 4, and on seeded samples for m = 5..9.  W at every n by the derivation; checked for omega^2
       on every (p,q,r) with n <= 10, the centre and super-centre by exact null spaces for n <= 7 and numerically for n <= 7.  L at every odd
       unimodular lattice by the derivation; checked for I_{p,q} with 2 <= p + q <= 12 and k = (1,...,1), for every characteristic vector with
       sum k_i^2 <= n + 8 for p + q <= 8 (all sign patterns for p + q <= 6, positive representatives above), for 40 seeded random odd vectors per
       signature with p + q <= 8, and for the lattices A_n (n = 1..11) and E_n (n = 3..11).
       Recalled, not checked here: the classification of quadratic forms over F_2 (dimension, radical, delta, Gauss sum), unique factorisation in
       Z[i] (a Gaussian integer of norm 2^d is (1+i)^d times a unit), and the existence of a characteristic vector in a unimodular lattice.
       The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen by this script; its controls are the faults above.
Command: python3 ranges_n.py   (from this folder, or python3 selfcheck/proofs/ranges_n.py from the package root; standard library, numpy)."""
import os, sys, itertools, random, math, cmath
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
for _p, _f in ((_researchers, 'bitrule_A.py'), (_researchers, 'f2lib.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
from bitrule_A import BR
import f2lib
import core_check as CC

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('EVEN', 'NONDIAG', 'RADW2', 'NORAD', 'SIGNN', 'SIGNP', 'CENTRE', 'NONCHAR', 'LEVEN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))

pc = lambda x: bin(x).count('1')
def parity(x): return bin(x).count('1') & 1
POPLEN = 1 << 16
POP = np.zeros(POPLEN, dtype=np.int64)
for _b in range(16): POP += (np.arange(POPLEN, dtype=np.int64) >> _b) & 1

def sigs(n, rmax=None):
    for r in range(0, (n if rmax is None else min(rmax, n)) + 1):
        for p in range(n - r + 1): yield (p, n - r - p, r)

# ------------------------------------------------------------------------------------------------ Gaussian integers (pairs of ints)
IP = ((1, 0), (0, 1), (-1, 0), (0, -1))
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def gsum_counts(c): return (int(c[0]) - int(c[2]), int(c[1]) - int(c[3]))
def gsum_list(ws):
    c = [0, 0, 0, 0]
    for w in ws: c[w & 3] += 1
    return gsum_counts(c)
def gprod_charges(ks):
    z = (1, 0)
    for k in ks: z = gmul(z, (1 + IP[k & 3][0], IP[k & 3][1]))
    return z
def gnorm(z): return z[0] * z[0] + z[1] * z[1]
PH = {(1, 0): 0, (1, 1): 1, (0, 1): 2, (-1, 1): 3, (-1, 0): 4, (-1, -1): 5, (0, -1): 6, (1, -1): 7}
def phase8(z):
    """the argument of the Gaussian integer z in Z/8 (z = |z| zeta^beta), exact; None for z = 0 or an argument that is no multiple of pi/4"""
    if z == (0, 0): return None
    while z[0] % 2 == 0 and z[1] % 2 == 0: z = (z[0] // 2, z[1] // 2)
    return PH.get(z)

# ------------------------------------------------------------------------------------------------ tables of w = pi + 2Q
WT = {}
def wtab(p, q):                                                             # the engine's w4 over all labels of Cl(p,q)
    if (p, q) not in WT:
        e = CC.sig(p, q)
        WT[(p, q)] = [CC.w4(a, e) for a in range(1 << (p + q))]
    return WT[(p, q)]
def wtab_np(p, q):                                                          # the same sign rule on arrays of labels (n <= 16)
    n = p + q; A = np.arange(1 << n, dtype=np.int64); ex = np.zeros_like(A)
    for i in range(n): ex += ((A >> i) & 1) * POP[A & ((1 << i) - 1)]
    ex += POP[A & (((1 << q) - 1) << p)]
    return (POP[A] % 2 + 2 * (ex & 1)) % 4

# ================================================================================================ Z
head('Z. w = pi + 2Q of the diagonal cells: weights, disjoint addresses, Gauss sums, Brown invariant, odd weights (range.Z1..Z6)')
ok_cf = ok_q = ok_mod = ok_clk = ok_std = True; nlab = ncell = 0
for m_ in range(65):
    if ((m_ % 2) + 2 * (m_ * (m_ - 1) // 2)) % 4 != m_ % 4: ok_mod = False
for n in range(1, 11):
    for p in range(n + 1):
        q = n - p; e = CC.sig(p, q); tab = wtab(p, q); ks = [1] * p + [3] * q; negmask = ((1 << q) - 1) << p
        kw = [0] * (1 << n)
        for a in range(1, 1 << n):
            low = a & -a; kw[a] = (kw[a ^ low] + ks[low.bit_length() - 1]) % 4
        if kw != tab: ok_cf = False
        for a in range(1 << n):
            if CC.Q(a, e) != (pc(a) * (pc(a) - 1) // 2 + pc(a & negmask)) % 2: ok_q = False
            if n <= 8 and sum(e[j] for j in range(n) if a >> j & 1) % 4 != tab[a]: ok_std = False
        nlab += 1 << n; ncell += 1
    for (p, q, r) in sigs(n, 10):
        if r == 0: continue
        nd = p + q; tab = wtab(p, q); P = (1 << p) - 1; Nm = ((1 << q) - 1) << p
        for a in range(1 << n):
            if (pc(a & P) - pc(a & Nm)) % 4 != tab[a & ((1 << nd) - 1)]: ok_clk = False
chk('bit', ok_mod, 'range.Z1: (m mod 2) + 2 C(m,2) = m mod 4 for m = 0..64 (the induction step m -> m+1 adds 1 mod 4)')
chk('bit', ok_q, 'range.Z1: Q(a) = [e_a^2 = -1] of core_check equals C(|a|,2) + |a & N| mod 2 on every label of every Cl(p,q), n <= 10 (%d cells, %d labels)' % (ncell, nlab))
chk('bit', ok_cf, 'range.Z1: w4 = pi + 2Q of core_check equals sum_{j in a} k_j mod 4 (k_j = 1 for +1, 3 for -1) on every label of every Cl(p,q), n <= 10')
chk('bit', ok_clk, 'range.Z1: with null generators (r >= 1, n <= 10, all cells) the clock exponent |a & P| - |a & N| equals w4 of the quotient label (null bits dropped), i.e. the null charge is 0')
chk('std', ok_std, 'range.Z1: the lattice reading w(a) = x.x mod 4 for the 0/1 vector x of the label in the lattice with Gram diag(eps) equals w4 on every label, n <= 8 (no bit rule)')

# Z2: (i) disjoint addresses
ok_cells = True; npairs = 0
def disjoint_pairs(n): return [(a, b) for a in range(1 << n) for b in range(1 << n) if not a & b]
for n in range(1, 9):
    pr = disjoint_pairs(n)
    if n <= 6:
        for sv in itertools.product((1, -1), repeat=n):
            tab = [CC.w4(a, list(sv)) for a in range(1 << n)]
            if any((tab[a | b] - tab[a] - tab[b]) % 4 for a, b in pr): ok_cells = False
            npairs += len(pr)
    else:
        for p in range(n + 1):
            tab = wtab(p, n - p)
            if any((tab[a | b] - tab[a] - tab[b]) % 4 for a, b in pr): ok_cells = False
            npairs += len(pr)
chk('bit', ok_cells, 'range.Z2: w4 adds on disjoint addresses, w(a+b) = w(a) + w(b) for a & b = 0: all 2^n sign vectors for n <= 6, all (p,q) for n = 7, 8 (%d checked pairs)' % npairs)

def all_forms_additive(n):                                                  # every quadratic form Q' on F_2^n: which pi + 2Q' add on disjoint addresses
    N = 1 << n; A = np.arange(N, dtype=np.int64)
    pr = disjoint_pairs(n); PA = np.array([a for a, b in pr]); PB = np.array([b for a, b in pr])
    vm = [1 << i for i in range(n)] + [(1 << i) | (1 << j) for i in range(n) for j in range(i + 1, n)]
    IND = np.array([[1 if (a & m_) == m_ else 0 for a in range(N)] for m_ in vm], dtype=np.int64)
    nv = len(vm); F = 1 << nv
    bits = (np.arange(F, dtype=np.int64)[:, None] >> np.arange(nv, dtype=np.int64)[None, :]) & 1
    Qt = (bits @ IND) & 1
    W = ((POP[A] & 1)[None, :] + 2 * Qt) % 4
    W = W.astype(np.int8)
    D = (W[:, PA ^ PB] - W[:, PA] - W[:, PB]) % 4
    good = np.nonzero((D == 0).all(axis=1))[0]
    want = np.nonzero((np.arange(F) >> n) == ((1 << (nv - n)) - 1))[0]       # all pair bits of the polar form equal to 1
    cells_in = True
    for sv in itertools.product((1, -1), repeat=n):                         # the cell with signs sv is the form with c_i = [sv_i = -1] and all pair bits 1
        fid = sum(1 << i for i in range(n) if sv[i] == -1) | (((1 << (nv - n)) - 1) << n)
        if [int(x) for x in Qt[fid]] != [CC.Q(a, list(sv)) for a in range(N)]: cells_in = False
    return (list(good) == list(want)), len(good), F, cells_in
res_forms = [all_forms_additive(n) for n in range(1, 6)]
chk('bit', all(r[0] and r[1] == 1 << n_ and r[3] for r, n_ in zip(res_forms, range(1, 6))),
    'range.Z2: among ALL quadratic forms Q\' on F_2^n (%s forms for n = 1..5) the ones for which pi + 2Q\' adds on disjoint addresses are exactly the %s forms with polar form b\'(e_i,e_j) = 1 for i != j: the cells with squares +-1 (their Q is the form with c_i = [eps_i = -1])'
    % (', '.join(str(r[2]) for r in res_forms), ', '.join(str(r[1]) for r in res_forms)))

# Z3: (ii) the factorisation, exact Gaussian integers
ok_fac = ok_ph = ok_f2 = ok_np = ok_bt = True; nsig = 0; ok_cmath = True
for n in range(1, 11):
    for (p, q, r) in sigs(n):
        nd = p + q; tab = wtab(p, q)
        if FAULT == 'NONDIAG' and nd >= 2: tab = [(w + 2 * ((a & 1) & (a >> 1 & 1))) % 4 for a, w in enumerate(tab)]
        ks = [1] * p + [3] * q + [0] * r
        G = gsum_list([tab[a & ((1 << nd) - 1)] for a in range(1 << n)])
        if G != gprod_charges(ks): ok_fac = False
        if G != gmul((1 << r, 0), CC.brown_target(p, q)) or phase8(G) != (p - q) % 8 or gnorm(G) != 4 ** r * 2 ** nd: ok_ph = False
        nsig += 1
chk('bit', ok_fac, 'range.Z3: sum_a i^w(a) over all 2^n labels, as a pair of ints, equals prod_j (1 + i^k_j) exactly for every (p,q,r) with n <= 10 (%d signatures; null charge 0: factor 2)' % nsig)
chk('bit', ok_ph, 'range.Z3: that sum equals 2^r (1+i)^p (1-i)^q, has norm 4^r 2^(p+q) and argument (p - q) mod 8 in Z/8 for all of them')
nbig = 0
for n in range(11, 17):
    for (p, q, r) in sigs(n):
        nd = p + q; wq = wtab_np(p, q); A_ = np.arange(1 << n, dtype=np.int64)
        G = gsum_counts(np.bincount(wq[A_ & ((1 << nd) - 1)], minlength=4))
        if G != gprod_charges([1] * p + [3] * q + [0] * r) or phase8(G) != (p - q) % 8 or G != gmul((1 << r, 0), CC.brown_target(p, q)): ok_bt = False
        nbig += 1
for n in range(1, 11):
    for p in range(n + 1):
        if [int(x) for x in wtab_np(p, n - p)] != wtab(p, n - p): ok_np = False
chk('bit', ok_np and ok_bt, 'range.Z3: n = 11..16: the vectorised sign rule (equal to core_check w4 on every label of every Cl(p,q), n <= 10) gives, over all 2^n labels, the sum prod_j (1 + i^k_j) with argument (p - q) mod 8 for all %d signatures (p,q,r)' % nbig)
for n in range(1, 9):
    for (p, q, r) in sigs(n):
        ks = [1] * p + [3] * q + [0] * r
        S = sum(cmath.exp(1j * math.pi / 2 * (sum(ks[j] for j in range(n) if a >> j & 1)))
                for a in range(1 << n))
        Pf = 1
        for k in ks: Pf *= (1 + cmath.exp(1j * math.pi / 2 * k))
        if abs(S - Pf) > 1e-9 * 4 ** n: ok_cmath = False
        if p + q and (round(cmath.phase(S) / (math.pi / 4)) % 8 != (p - q) % 8): ok_cmath = False
chk('std', ok_cmath, 'range.Z3: cmath sums in floats of exp(i pi/2 sum k_j) over all labels equal the product of (1 + i^k_j) and have argument (p - q) pi/4, every (p,q,r), n <= 8')
chk('bit==std', ok_fac and ok_cmath, 'range.Z3: the exact Gaussian-integer sums and the float sums agree on every (p,q,r) with n <= 8')

# Z4: (iii) the Brown invariant: additive on orthogonal sums, read off the Gauss sum
ok_os = True; nos = 0
for n1 in range(1, 8):
    for n2 in range(1, 9 - n1):
        for p1 in range(n1 + 1):
            for p2 in range(n2 + 1):
                T1 = wtab(p1, n1 - p1); T2 = wtab(p2, n2 - p2); T3 = wtab(p1 + p2, n1 + n2 - p1 - p2)
                Gd = gsum_list([(T1[a1] + T2[a2]) % 4 for a1 in range(1 << n1) for a2 in range(1 << n2)])
                G1 = gsum_list(T1); G2 = gsum_list(T2)
                b1, b2, b3 = phase8(G1), phase8(G2), phase8(Gd)
                if Gd != gmul(G1, G2) or Gd != gsum_list(T3) or b3 != (b1 + b2) % 8 or b3 != (p1 + p2 - (n1 + n2 - p1 - p2)) % 8: ok_os = False
                nos += 1
chk('bit', ok_os, 'range.Z4: direct sum over V1 x V2 of i^(w1 + w2) = G(w1) G(w2) = G of the cell Cl(p1+p2, q1+q2), and the Brown invariants add (argument of the Gauss sum), n1 + n2 <= 8: %d orthogonal sums of cells' % nos)

def build_form(m, ks, off):                                                 # Z4 refinement of a symmetric form on F_2^m: diagonal lifts ks (Z4), off-diagonal bits
    N = 1 << m; offmask = [0] * m
    for (i, j), v in off.items():
        if v: offmask[i] |= 1 << j
    W = [0] * N
    for x in range(1, N):
        i = (x & -x).bit_length() - 1; xp = x ^ (1 << i)
        W[x] = (W[xp] + ks[i] + 2 * parity(xp & offmask[i])) % 4
    Bcol = [(ks[j] & 1) << j for j in range(m)]
    for (i, j), v in off.items():
        if v: Bcol[i] |= 1 << j; Bcol[j] |= 1 << i
    return W, Bcol
def bcolvec(Bcol, y):
    z = 0
    for j in range(len(Bcol)):
        if y >> j & 1: z ^= Bcol[j]
    return z
def refines_all_pairs(m, W, Bcol):
    return all((W[x ^ y] - W[x] - W[y]) % 4 == 2 * parity(x & bcolvec(Bcol, y)) for x in range(1 << m) for y in range(1 << m))
def refines_increments(m, W, Bcol):
    return all((W[x ^ (1 << j)] - W[x] - W[1 << j]) % 4 == 2 * parity(x & Bcol[j]) for x in range(1 << m) for j in range(m))
def all_forms(m):
    pairs = [(i, j) for i in range(m) for j in range(i + 1, m)]
    for ks in itertools.product(range(4), repeat=m):
        for ob in itertools.product((0, 1), repeat=len(pairs)):
            yield list(ks), dict(zip(pairs, ob))

ND = {}
ok_form_ref = True; nform = 0
for m in (1, 2, 3):
    ND[m] = []
    for ks, off in all_forms(m):
        W, Bcol = build_form(m, ks, off)
        if not refines_all_pairs(m, W, Bcol): ok_form_ref = False
        nform += 1
        if not [x for x in range(1, 1 << m) if all(parity(x & Bcol[j]) == 0 for j in range(m))]: ND[m].append((W, ks, off))
ok_nd = True; nnd = 0
for m in ND:
    for (W, ks, off) in ND[m]:
        G = gsum_list(W)
        if gnorm(G) != 1 << m or phase8(G) is None: ok_nd = False
        nnd += 1
ok_osg = True; nosg = 0
for m1 in (1, 2, 3):
    for m2 in (1, 2, 3):
        if m1 + m2 > 5: continue
        for (W1, ks1, off1) in ND[m1]:
            for (W2, ks2, off2) in ND[m2]:
                off = dict(off1); off.update({(i + m1, j + m1): v for (i, j), v in off2.items()})
                Wd, Bd = build_form(m1 + m2, ks1 + ks2, off)
                G1 = gsum_list(W1); G2 = gsum_list(W2); Gd = gsum_list(Wd)
                if any(Wd[a1 | (a2 << m1)] != (W1[a1] + W2[a2]) % 4 for a1 in range(1 << m1) for a2 in range(1 << m2)): ok_osg = False
                if Gd != gmul(G1, G2) or phase8(Gd) != (phase8(G1) + phase8(G2)) % 8 or gnorm(Gd) != 1 << (m1 + m2): ok_osg = False
                nosg += 1
chk('bit', ok_form_ref and ok_nd, 'range.Z4: every (diagonal lifts in Z4, off-diagonal bits) on F_2^m, m <= 3 (%d forms) is a Z4 refinement of its symmetric form; the %d with non-degenerate form have |G|^2 = 2^m and an argument in Z/8: the Brown invariant is read off G' % (nform, nnd))
chk('bit', ok_osg, 'range.Z4: orthogonal sums of non-diagonal non-degenerate refinements (m1 + m2 <= 5, %d pairs, block-diagonal form built directly): G = G1 G2 and the Brown invariants add' % nosg)

# Z5: (iv) odd weights
def refines_dot(ks, n):
    N = 1 << n; A = np.arange(N, dtype=np.int64); W = np.zeros(N, dtype=np.int64)
    for j in range(n): W += ((A >> j) & 1) * ks[j]
    W %= 4; X = A[:, None]; Y = A[None, :]
    return not ((W[X ^ Y] - W[X] - W[Y] - 2 * (POP[X & Y] & 1)) % 4).any()
def all_odd(ks): return all(k % 2 == 1 for k in ks)
def pred_odd(ks):
    if FAULT == 'EVEN': return all(k % 4 != 0 for k in ks)                     # the wrong criterion: any non-zero weight refines
    return all_odd(ks)
ok_iff = True; nvec = 0
for n in range(1, 9):
    fam = itertools.product(range(4), repeat=n) if n <= 6 else (c for c in itertools.combinations_with_replacement(range(4), n))
    for ks in fam:
        if refines_dot(list(ks), n) != pred_odd(ks): ok_iff = False
        nvec += 1
chk('bit', ok_iff, 'range.Z5: sum_{j in a} k_j mod 4 refines the dot product (w(a+b) - w(a) - w(b) = 2|a&b| mod 4 on all pairs) iff every k_j is odd: all 4^n weight vectors for n <= 6, all multisets of weights (up to permuting the generators) for n = 7, 8 (%d vectors)' % nvec)
ok_pq = True
for n in range(1, 9):
    for ks in itertools.product((1, 3), repeat=min(n, 6)):
        ks = list(ks) + [1] * (n - len(ks))
        G = gprod_charges(ks); b = phase8(G)
        if b != (sum(1 for k in ks if k == 1) - sum(1 for k in ks if k == 3)) % 8 or not refines_dot(ks, n): ok_pq = False
chk('bit', ok_pq, 'range.Z5: for odd weights the Brown invariant is #(k_j = 1) - #(k_j = 3) = p - q mod 8 and the refinement holds (k in {1,3}^n, n <= 6 padded with 1 up to n = 8)')

# Z6: controls
ks_bad = [1, 3, 2, 1]
chk('ctl', not refines_dot(ks_bad, 4) and not refines_dot([2, 1, 1], 3) and not refines_dot([0, 1], 2),
    'range.Z6: one even weight breaks the refinement (weights (1,3,2,1), (2,1,1), (0,1) do not refine the dot product)')
chk('ctl', gprod_charges([1, 3, 2, 1]) == (0, 0) and phase8((0, 0)) is None,
    'range.Z6: a weight 2 gives the factor 1 + i^2 = 0, a Gauss sum 0 with no Brown invariant')
def cross(tab): return [(w + 2 * ((a & 1) & (a >> 1 & 1))) % 4 for a, w in enumerate(tab)]
cnt_all = sum(n + 1 for n in range(2, 9))
cnt_break = sum(1 for n in range(2, 9) for p in range(n + 1) if gsum_list(cross(wtab(p, n - p))) != gprod_charges([1] * p + [3] * (n - p)))
cnt_add = sum(1 for n in range(2, 9) for p in range(n + 1) if (lambda t: (t[3] - t[1] - t[2]) % 4 != 0)(cross(wtab(p, n - p))))
chk('ctl', cnt_break == cnt_all, 'range.Z6: adding the cross term 2 a_1 a_2 to w breaks the factorisation sum_a i^w(a) = prod_j (1 + i^k_j) for %d of the %d cells with 2 <= n <= 8' % (cnt_break, cnt_all))
chk('ctl', cnt_add == cnt_all, 'range.Z6: with the cross term 2 a_1 a_2, w(a+b) = w(a) + w(b) fails at the disjoint pair a = {1}, b = {2} for %d of the %d cells with 2 <= n <= 8' % (cnt_add, cnt_all))

# ================================================================================================ D
head('D. the degenerate case: values 0, 2 on the radical, the Gauss sum vanishes iff w is non-zero there, Brown invariant of the quotient (range.D1..D5)')
def clock_w(p, q, r, c):                                                     # the family w_c of the cell: clock exponent of core_check plus 2 (c . a_null)
    nd = p + q; P = (1 << p) - 1; Nm = ((1 << q) - 1) << p
    return [((pc(a & P) - pc(a & Nm)) + 2 * parity((a >> nd) & c)) % 4 for a in range(1 << (p + q + r))]
def cells_deg(nmax, rmax):
    for n in range(1, nmax + 1):
        for (p, q, r) in sigs(n, rmax): yield (p, q, r)
ok_ref = ok_rad = ok_val = ok_hom = ok_ctie = ok_van = ok_q0 = ok_mot = ok_phq = ok_nonz = True
ncell = npair = nvan = nzero = 0
for (p, q, r) in cells_deg(9, 3):
    n = p + q + r; nd = p + q; nullmask = ((1 << r) - 1) << nd
    if FAULT == 'NORAD' and r > 0: continue
    ncell += 1
    for c in range(1 << r):
        ws = clock_w(p, q, r, c ^ 1 if (FAULT == 'RADW2' and r > 0) else c); npair += 1
        Bcol = [(ws[1 << j] & 1) << j for j in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                d = (ws[(1 << i) | (1 << j)] - ws[1 << i] - ws[1 << j]) % 4
                if d % 2: ok_ref = False
                if d // 2: Bcol[i] |= 1 << j; Bcol[j] |= 1 << i
        if n <= 6:
            if not refines_all_pairs(n, ws, Bcol): ok_ref = False
        elif not refines_increments(n, ws, Bcol): ok_ref = False
        rad = [x for x in range(1 << n) if all(parity(x & Bcol[j]) == 0 for j in range(n))]
        if rad != [x for x in range(1 << n) if not x & ((1 << nd) - 1)]: ok_rad = False
        if any(ws[x] not in (0, 2) for x in rad): ok_val = False
        if any(ws[x ^ y] != (ws[x] + ws[y]) % 4 for x in rad for y in rad): ok_hom = False
        G = gsum_list(ws); nonzero_rad = any(ws[x] == 2 for x in rad)
        if (G == (0, 0)) != nonzero_rad or nonzero_rad != (c != 0): ok_van = False
        if G == (0, 0): nzero += 1
        if not nonzero_rad:
            Gq = gsum_list([ws[x] for x in range(1 << n) if not x & nullmask])
            if c == 0 and ws != [CC.w4(a & ((1 << nd) - 1), CC.sig(p, q)) for a in range(1 << n)]: ok_ctie = False
            if Gq != CC.brown_target(p, q) or G != (Gq[0] << r, Gq[1] << r): ok_q0 = False
            if G != gmul((1 << r, 0), CC.brown_target(p, q)) or phase8(G) != (p - q) % 8 or phase8(Gq) != (p - q) % 8 or gnorm(Gq) != 1 << nd: ok_phq = False
            if nd + 2 * r <= 12:
                Gm = gsum_counts(np.bincount(wtab_np(p + r, q + r), minlength=4))
                if Gm != G: ok_mot = False
            else: pass
        else:
            if G != (0, 0): ok_nonz = False
chk('bit', ok_ref and ok_rad, 'range.D1: for every (p,q,r) with r <= 3, n <= 9 (%d cells, %d pairs cell x character c) w_c is a Z4 refinement of the dot product on the non-null bits (all pairs for n <= 6, single-bit increments above) and its radical is exactly the span of the null bits' % (ncell, npair))
chk('bit', ok_val and ok_hom, 'range.D1: w_c takes only the values 0 and 2 on the radical and is a homomorphism there (w(x+y) = w(x) + w(y)), for all of them')
chk('bit', ok_van and ok_nonz and 0 < nzero < npair, 'range.D2: the Gauss sum (exact Gaussian integer over all 2^n labels) is 0 exactly when w_c is non-zero on the radical, i.e. c != 0 (%d of the %d pairs vanish, those with c != 0; both outcomes occur)' % (nzero, npair))
chk('bit', ok_q0 and ok_ctie, 'range.D2: for c = 0 (null bits of weight 0: the clock exponent, equal to core_check w4 of the quotient label) w is constant on cosets of the radical and G = 2^r times the Gauss sum of the quotient Cl(p,q) = (1+i)^p (1-i)^q')
chk('bit', ok_phq and ok_mot, 'range.D2: for c = 0 the Brown invariant (argument of G) is p - q mod 8, that of the quotient cell, and G equals the Gauss sum of the mother cell Cl(p+r,q+r) counted over all its 2^(n+r) labels (p + q + 2r <= 12)')

def analyse_form(m, W, Bcol):
    N = 1 << m
    rad = [x for x in range(N) if all(parity(x & Bcol[j]) == 0 for j in range(m))]
    vals_ok = all(W[x] in (0, 2) for x in rad)
    hom_ok = all(W[x ^ y] == (W[x] + W[y]) % 4 for x in rad for y in rad)
    G = gsum_list(W); nz = any(W[x] == 2 for x in rad)
    van_ok = (G == (0, 0)) == nz; quot_ok = True
    if not nz:
        rep = [min(x ^ r_ for r_ in rad) for x in range(N)]
        Sb = gsum_list([W[x] for x in range(N) if rep[x] == x]); dimr = len(rad).bit_length() - 1
        quot_ok = (all(W[x] == W[rep[x]] for x in range(N)) and G == (len(rad) * Sb[0], len(rad) * Sb[1])
                   and gnorm(Sb) == 1 << (m - dimr) and phase8(G) == phase8(Sb) and phase8(G) is not None)
    return len(rad), vals_ok, hom_ok, van_ok, quot_ok, nz
cnt = {'forms': 0, 'zero': 0, 'deg_ok': 0, 'nondeg': 0}; ok_all4 = True
for m in (1, 2, 3, 4):
    for ks, off in all_forms(m):
        W, Bcol = build_form(m, ks, off)
        nr, v, h, vz, qo, nz = analyse_form(m, W, Bcol)
        if not (v and h and vz and qo): ok_all4 = False
        cnt['forms'] += 1; cnt['zero'] += int(nz); cnt['nondeg'] += int(nr == 1); cnt['deg_ok'] += int(nr > 1 and not nz)
chk('bit', ok_all4, 'range.D3: EVERY Z4 refinement of EVERY symmetric bilinear form on F_2^m, m = 1..4 (%d forms): values 0, 2 on the radical, homomorphism, G = 0 iff non-zero there (%d forms), else G = |R| G(w-bar), |G(w-bar)|^2 = |V/R|, equal arguments (%d with a proper radical, %d non-degenerate)' % (cnt['forms'], cnt['zero'], cnt['deg_ok'], cnt['nondeg']))
rng = random.Random(91); ok_rnd = True; nrnd = nrz = nrd = 0
for m in range(5, 10):
    for t in range(200):
        s = m if t % 2 == 0 else m - rng.randint(1, 3)
        ks = [rng.randrange(4) for _ in range(s)] + [2 * rng.randrange(2) for _ in range(m - s)]
        pairs = [(i, j) for i in range(m) for j in range(i + 1, m)]
        off = {(i, j): (rng.randrange(2) if j < s else 0) for (i, j) in pairs}
        W, Bcol = build_form(m, ks, off)
        if not refines_increments(m, W, Bcol): ok_rnd = False
        nr, v, h, vz, qo, nz = analyse_form(m, W, Bcol)
        if not (v and h and vz and qo): ok_rnd = False
        nrnd += 1; nrz += int(nz); nrd += int(nr > 1 and not nz)
chk('bit', ok_rnd, 'range.D3: seeded random Z4 refinements of symmetric forms on F_2^m, m = 5..9, 200 each (%d forms, half with a forced radical): the same four statements; %d have w non-zero on the radical (G = 0), %d a proper radical with w = 0 there' % (nrnd, nrz, nrd))

ok_dstd = True; nstd = 0
for (p, q, r) in cells_deg(7, 3):
    n = p + q + r
    for c in range(1 << r):
        ks = [1] * p + [3] * q + [2 * (c >> j & 1) for j in range(r)]
        S = sum(cmath.exp(1j * math.pi / 2 * sum(ks[j] for j in range(n) if a >> j & 1)) for a in range(1 << n))
        want = 0 if c else (2 ** r) * (1 + 1j) ** p * (1 - 1j) ** q
        if abs(S - want) > 1e-9 * 2 ** n: ok_dstd = False
        if c == 0 and p + q and round(cmath.phase(S) / (math.pi / 4)) % 8 != (p - q) % 8: ok_dstd = False
        nstd += 1
chk('std', ok_dstd, 'range.D4: cmath sums over all labels with the textbook charges (1, 3, 0 or 2 on the null bits): 0 for c != 0, 2^r (1+i)^p (1-i)^q with argument (p - q) pi/4 for c = 0; r <= 3, n <= 7 (%d pairs)' % nstd)
chk('bit==std', ok_dstd and ok_van, 'range.D4: the exact vanishing pattern (D2) and the float sums (D4) agree on every cell with n <= 7')

ok_c1 = ok_c2 = ok_c3 = True; n_c1 = 0
for (p, q, r) in cells_deg(9, 3):
    if r == 0: continue
    n_c1 += 2 ** r - 1
nz_all = sum(2 ** r - 1 for (p, q, r) in cells_deg(9, 3))
vanish_r0 = 0
for (p, q, r) in cells_deg(9, 3):
    if r: continue
    if gsum_list(wtab(p, q)) == (0, 0): vanish_r0 += 1
chk('ctl', nzero == nz_all == n_c1 and nz_all > 0, 'range.D5: a radical vector with w = 2 (c != 0) puts the Gauss sum at 0: %d of %d pairs, every cell with r >= 1; with it the clock of the cell would be undefined' % (nzero, n_c1))
chk('ctl', vanish_r0 == 0 and nzero > 0, 'range.D5: r = 0 has no radical (R = {0}): the criterion is vacuous, no sum vanishes among the %d cells with r = 0; the criterion is exercised only by the cells with r >= 1' % sum(1 for (p, q, r) in cells_deg(9, 3) if r == 0))
nb = 0; ok_pi = True; n_other = 0
for (p, q, r) in cells_deg(6, 3):
    if r == 0: continue
    n = p + q + r; wf = [CC.w4(a, CC.sig(p, q, r)) for a in range(1 << n)]
    Bfam = [(1 << j) if j < p + q else 0 for j in range(n)]                  # the dot product on the non-null bits: the null span is its radical
    if refines_all_pairs(n, wf, Bfam) or wf[1 << (p + q)] != 1: ok_pi = False
    nb += 1
chk('ctl', ok_pi and nb > 0, 'range.D5: pi + 2Q on all of V (charge 1 on a null generator, w4 of core_check) has the value 1 on a vector of the radical of the dot product on the non-null bits and is not a refinement of it, for each of the %d cells with 1 <= r <= 3, n <= 6: the weight on a null bit is 0 or 2, never 1' % nb)

# ================================================================================================ W
head('W. omega^2 = (-1)^(n(n-1)/2 + q) and the centre, the super-centre (range.W1..W4)')
def omega_sq_formula(n, p, q, r):
    if r: return 0
    if FAULT == 'SIGNN': return (-1) ** (n * (n + 1) // 2 + q)
    if FAULT == 'SIGNP': return (-1) ** p
    return (-1) ** (n * (n - 1) // 2 + q)
ok_up = ok_dn = ok_pe = ok_sq = ok_sgn = ok_pop = True; ncl = 0
for n in range(1, 11):
    top = (1 << n) - 1
    if sum(pc(top & ((1 << i) - 1)) for i in range(n)) != n * (n - 1) // 2: ok_pop = False
    for (p, q, r) in sigs(n):
        eps = CC.sig(p, q, r); A = BR(eps); up = A.one(); dn = A.one()
        for j in range(n): up = A.mul(up, A.gen(j))
        for j in range(n - 1, -1, -1): dn = A.mul(dn, A.gen(j))
        pe = 0 if r else (-1) ** q
        if up != {top: 1}: ok_up = False
        if dn != {top: (-1) ** (n * (n - 1) // 2)}: ok_dn = False
        pw = A.mul(up, dn)
        if pw != ({0: pe} if pe else {}): ok_pe = False
        s2 = omega_sq_formula(n, p, q, r); sq = A.mul(up, up)
        if sq != ({0: s2} if s2 else {}): ok_sq = False
        if CC.sgn(top, top, eps) != s2: ok_sgn = False
        ncl += 1
chk('bit', ok_pop, 'range.W1: the reordering exponent of top*top, sum_{i<n} popcount(top & (2^i - 1)), is n(n-1)/2 for n = 1..10')
chk('bit', ok_up and ok_dn, 'range.W1: BR: e_1 ... e_n = the top blade with coefficient +1 and the reversed product e_n ... e_1 = (-1)^(n(n-1)/2) times it, every (p,q,r), n <= 10 (%d cells)' % ncl)
chk('bit', ok_pe, 'range.W1: BR: omega * omega-tilde = prod_j eps_j = (-1)^q for r = 0 and 0 for r >= 1, every (p,q,r), n <= 10')
chk('bit', ok_sq and ok_sgn, 'range.W1: BR: omega^2 = (-1)^(n(n-1)/2 + q) for r = 0 and 0 for r >= 1 (exhaustive, all %d cells with n <= 10), equal to the coefficient core_check.sgn(top, top)' % ncl)

def sparse_rank(eqs):
    piv = {}
    for r_ in eqs:
        r_ = dict(r_)
        while True:
            hit = [c for c in r_ if c in piv]
            if not hit: break
            c = hit[0]; f = r_[c]
            for c2, v in piv[c].items():
                nv = r_.get(c2, 0) - f * v
                if nv: r_[c2] = nv
                else: r_.pop(c2, None)
        if r_:
            c0 = min(r_); inv = 1 / r_[c0]; piv[c0] = {c: v * inv for c, v in r_.items()}
    return len(piv)
def predicted(p, q, r, which):
    n = p + q + r; nullmask = ((1 << r) - 1) << (p + q); top = (1 << n) - 1
    if which == 'super': return {a for a in range(1 << n) if not a & ~nullmask}
    if which == 'literal': return {0} | ({top} if n % 2 else set())
    return {a for a in range(1 << n) if not a & ~nullmask and pc(a) % 2 == 0} | ({top} if n % 2 else set())
def exact_null(p, q, r, mode):
    n = p + q + r; A = BR(CC.sig(p, q, r)); eqs = {}
    for j in range(n):
        gj = A.gen(j)
        for a in range(1 << n):
            ea = {a: 1}
            d = A.add(A.mul(ea, gj), A.mul(gj, ea), -1 if mode == 'c' else -(-1) ** pc(a))
            for b, cf in d.items(): eqs.setdefault((j, b), {})[a] = Fr(cf)
    rank = sparse_rank(eqs.values())
    return (1 << n) - rank, eqs
ok_ce = ok_su = True; ncen = 0; dim_tab = {}
for n in range(1, 8):
    for (p, q, r) in sigs(n):
        for mode, which in (('c', 'literal' if FAULT == 'CENTRE' else 'centre'), ('s', 'super')):
            dim, eqs = exact_null(p, q, r, mode); pred = predicted(p, q, r, which)
            if mode == 'c': dim_tab[(p, q, r)] = dim
            if dim != len(pred) or not all(eq.get(a, 0) == 0 for eq in eqs.values() for a in pred):
                if mode == 'c': ok_ce = False
                else: ok_su = False
        ncen += 1
chk('bit', ok_ce, 'range.W2: exact null space (Fraction elimination of the equations [z, e_j] = 0 written on the 2^n blades from the BR products, nothing assumed about their shape) of every (p,q,r), n <= 7 (%d cells): dimension 2^max(r-1,0) + [n odd], spanned by the null blades of even grade and, for n odd, the top blade omega: R, R + R omega for r = 0 and r = 1' % ncen)
chk('bit', ok_su, 'range.W2: the same for the super-centre (z e_j = (-1)^|z| e_j z): dimension 2^r, spanned by all null blades: Lambda(R^r) (R for r = 0)')
small = [k for k in dim_tab if k[2] <= 1]; big = [(k, v) for k, v in dim_tab.items() if k[2] >= 2]
chk('ctl', all(dim_tab[k] == 1 + sum(k) % 2 for k in small) and all(v > 1 + sum(k) % 2 for k, v in big) and dim_tab[(0, 0, 2)] == 2 and dim_tab[(1, 0, 2)] == 3,
    'range.W2: the centre R (n even) / R + R omega (n odd) is what the null space gives for r = 0 and r = 1 (%d cells, n <= 7) and is too small for r >= 2: all %d cells with r >= 2, n <= 7 have a larger centre (Cl(0,0,2): dimension 2, spanned by 1 and nu_1 nu_2; Cl(1,0,2): dimension 3, not 2)' % (len(small), len(big)))

# W3 [std]
def reg_rep(p, q, r):                                                       # left and right multiplication by each generator on the 2^n basis words, from the relations alone
    n = p + q + r; N = 1 << n; eps = CC.sig(p, q, r)
    Lm = [np.zeros((N, N)) for _ in range(n)]; Rm = [np.zeros((N, N)) for _ in range(n)]
    for j in range(n):
        for a in range(N):
            hi = pc(a >> (j + 1)); lo = pc(a & ((1 << j) - 1))
            if a >> j & 1: b = a ^ (1 << j); vr = (-1) ** hi * eps[j]; vl = (-1) ** lo * eps[j]
            else: b = a | (1 << j); vr = (-1) ** hi; vl = (-1) ** lo
            if vr: Rm[j][b, a] = vr
            if vl: Lm[j][b, a] = vl
    return Lm, Rm
ok_sc = ok_ss = ok_om = True; nreg = 0
for n in range(1, 8):
    for (p, q, r) in sigs(n):
        N = 1 << n; Lm, Rm = reg_rep(p, q, r)
        Pi = np.diag([(-1.0) ** pc(a) for a in range(N)])
        for mode, which in (('c', 'centre'), ('s', 'super')):
            M = np.vstack([Lm[j] - (Rm[j] if mode == 'c' else Rm[j] @ Pi) for j in range(n)])
            U_, s_, Vt = np.linalg.svd(M, full_matrices=False)
            rank = int((s_ > 1e-9).sum()); null = Vt[rank:]
            D = np.diag([1.0 if a in predicted(p, q, r, which) else 0.0 for a in range(N)])
            if not np.allclose(null.T @ null, D, atol=1e-9):
                if mode == 'c': ok_sc = False
                else: ok_ss = False
        nreg += 1
for n in range(1, 9):
    for (p, q, r) in sigs(n):
        Lm, Rm = reg_rep(p, q, r); Lw = np.eye(1 << n)
        for j in range(n): Lw = Lw @ Lm[j]
        c = 0 if r else (-1) ** (n * (n - 1) // 2 + q)
        if not np.allclose(Lw @ Lw, c * np.eye(1 << n)): ok_om = False
chk('std', ok_sc and ok_ss, 'range.W3: numpy regular representation (left and right multiplication by each generator, built from the relations, no sign formula): the null space of the stacked L_j - R_j (SVD) is the span of the predicted blades for the centre, of L_j - R_j P for the super-centre, every (p,q,r), n <= 7 (%d cells)' % nreg)
chk('std', ok_om, 'range.W3: (L_1 ... L_n)^2 = (-1)^(n(n-1)/2 + q) I for r = 0 and the zero matrix for r >= 1 in the regular representation, every (p,q,r), n <= 8')
def gammas(n):
    m = (n + 1) // 2; X = np.array([[0, 1], [1, 0]], dtype=complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1.0 + 0j, -1]); I2 = np.eye(2, dtype=complex); gs = []
    for k in range(m):
        for Pm in (X, Y):
            if len(gs) == n: break
            mats = [Z] * k + [Pm] + [I2] * (m - k - 1); g = mats[0]
            for t in mats[1:]: g = np.kron(g, t)
            gs.append(g)
    return gs
ok_pa = True
for n in range(1, 11):
    gs = gammas(n)
    for p in range(n + 1):
        q = n - p; om = np.eye(gs[0].shape[0], dtype=complex)
        for j in range(n): om = om @ (gs[j] if j < p else 1j * gs[j])
        if not np.allclose(om @ om, (-1) ** (n * (n - 1) // 2 + q) * np.eye(om.shape[0])): ok_pa = False
chk('std', ok_pa, 'range.W3: Jordan-Wigner matrices (e_j = gamma_j for +1, i gamma_j for -1; Pauli strings, no bit rule): omega^2 = (-1)^(n(n-1)/2 + q) I for every Cl(p,q), n <= 10')
chk('bit==std', ok_sq and ok_om and ok_pa, 'range.W3: BR, the regular representation and the Pauli matrices give the same omega^2 on the cells they share')
wrongN = [(n, p, n - p) for n in range(1, 11) for p in range(n + 1) if (-1) ** (n * (n + 1) // 2 + (n - p)) != (-1) ** (n * (n - 1) // 2 + (n - p))]
A1 = BR([1])
chk('ctl', {n for n, p, q in wrongN} == {1, 3, 5, 7, 9} and len(wrongN) == 30 and A1.mul(A1.gen(0), A1.gen(0)) == {0: 1} and (-1) ** (1 * 2 // 2) == -1,
    'range.W4: the exponent n(n+1)/2 + q in place of n(n-1)/2 + q differs from the closed form exactly at the %d cells with odd n <= 9 (n = 1..10) and fails there; e.g. Cl(1,0): omega = e_1 and BR gives omega^2 = +1, the wrong exponent -1' % len(wrongN))
wrongP = [(n, p) for n in range(1, 11) for p in range(n + 1) if (-1) ** p != (-1) ** (n * (n - 1) // 2 + n - p)]
chk('ctl', (1, 1) in [(p, n - p) for n, p in wrongP if n == 2] and len(wrongP) > 0,
    'range.W4: (-1)^p in place of the closed form fails at Cl(1,1) (omega^2 = +1, p odd) and at %d cells with r = 0, n <= 10' % len(wrongP))

# ================================================================================================ L
head('L. characteristic vectors: k-perp/2k-perp = (L_even/2L, x.x/2 mod 2) = the label form of the even part (range.L1..L6)')
def ext_kernel_basis(c):
    n = len(c); c = list(c); cols = [[int(i == j) for j in range(n)] for i in range(n)]
    while True:
        nz = [i for i in range(n) if c[i] != 0]
        if len(nz) <= 1: break
        i0 = min(nz, key=lambda i: abs(c[i]))
        for i in nz:
            if i != i0:
                t = c[i] // c[i0]
                if t: c[i] -= t * c[i0]; cols[i] = [u - t * v for u, v in zip(cols[i], cols[i0])]
    piv = nz[0]
    return [cols[i] for i in range(n) if i != piv], abs(c[piv])
def snf_factors(M):
    A = [list(map(int, r_)) for r_ in M]; m = len(A); n = len(A[0]) if m else 0; out = []
    for t in range(min(m, n)):
        while True:
            cand = [(abs(A[i][j]), i, j) for i in range(t, m) for j in range(t, n) if A[i][j] != 0]
            if not cand: return out
            _, i, j = min(cand)
            A[t], A[i] = A[i], A[t]
            for row_ in A: row_[t], row_[j] = row_[j], row_[t]
            piv = A[t][t]; clean = True
            for i in range(t + 1, m):
                f = A[i][t] // piv
                if f: A[i] = [x - f * y for x, y in zip(A[i], A[t])]
                if A[i][t]: clean = False
            for j in range(t + 1, n):
                f = A[t][j] // piv
                if f:
                    for i in range(t, m): A[i][j] -= f * A[i][t]
                if A[t][j]: clean = False
            if clean:
                bad = next(((i, j) for i in range(t + 1, m) for j in range(t + 1, n) if A[i][j] % piv), None)
                if bad is None: break
                A[t] = [x + y for x, y in zip(A[t], A[bad[0]])]
        out.append(abs(A[t][t]))
    return out
def express(roots, x):
    m = len(roots); dim = len(x); M = [[Fr(roots[j][i]) for j in range(m)] + [Fr(x[i])] for i in range(dim)]; row_ = 0; pivs = []
    for col in range(m):
        pr = next((i for i in range(row_, dim) if M[i][col] != 0), None)
        if pr is None: continue
        M[row_], M[pr] = M[pr], M[row_]; inv = 1 / M[row_][col]; M[row_] = [v * inv for v in M[row_]]
        for i in range(dim):
            if i != row_ and M[i][col] != 0:
                f = M[i][col]; M[i] = [a - f * b for a, b in zip(M[i], M[row_])]
        pivs.append(col); row_ += 1
    if any(M[i][m] != 0 for i in range(row_, dim)): return None
    y = [Fr(0)] * m
    for r_, col in enumerate(pivs): y[col] = M[r_][m]
    return y
COMB = {}
def comb_matrix(m):
    if m not in COMB:
        idx = np.arange(1 << m, dtype=np.int64); COMB[m] = (idx[:, None] >> np.arange(m, dtype=np.int64)[None, :]) & 1
    return COMB[m]
def reduce_classes(basis, eps):                                             # the 2^m classes of a lattice with Z-basis `basis` modulo twice itself: (label of odd coordinates, x.x)
    n = len(eps); Bm = np.array(basis, dtype=np.int64).reshape(len(basis), n); X = comb_matrix(len(basis)) @ Bm
    xx = (X * X * np.array(eps, dtype=np.int64)[None, :]).sum(axis=1)
    lab = ((X & 1) << np.arange(n, dtype=np.int64)[None, :]).sum(axis=1)
    return lab, xx
QT = {}
def qtab(p, q):
    if (p, q) not in QT: QT[(p, q)] = np.array(f2lib.q_clifford(p, q), dtype=np.int64)
    return QT[(p, q)]
def kperp_check(p, q, kvec, use_leven=False):
    n = p + q; eps = [1] * p + [-1] * q; coef = [e * k for e, k in zip(eps, kvec)]
    if use_leven:
        basis = [[-1 if t == 0 else (1 if t == i else 0) for t in range(n)] for i in range(1, n)] + [[2] + [0] * (n - 1)]
    else: basis, g = ext_kernel_basis(coef)
    lab, xx = reduce_classes(basis, eps)
    res = {'even': bool((xx % 2 == 0).all()), 'basis': basis}
    ev = bool((POP[lab] % 2 == 0).all()); uniq = int(np.unique(lab).size)
    res['bij'] = ev and uniq == 1 << (n - 1) and len(lab) == uniq
    res['q'] = bool(res['even'] and (qtab(p, q)[lab] == ((xx // 2) % 2)).all())
    res['xx'] = xx; res['lab'] = lab
    return res
ok_snf = ok_unim = ok_sat = ok_lev = True; nsg = 0
for n in range(2, 13):
    for p in range(n + 1):
        q = n - p; eps = [1] * p + [-1] * q
        if snf_factors([[eps[i] if i == j else 0 for j in range(n)] for i in range(n)]) != [1] * n: ok_unim = False
        kv = [1] * n
        if FAULT == 'NONCHAR': kv[-1] = 2
        basis, g = ext_kernel_basis([e * k for e, k in zip(eps, kv)])
        if snf_factors(basis) != [1] * (n - 1) or len(basis) != n - 1: ok_sat = False
        lev = [[-1 if t == 0 else (1 if t == i else 0) for t in range(n)] for i in range(1, n)] + [[2] + [0] * (n - 1)]
        if snf_factors(lev) != [1] * (n - 1) + [2]: ok_lev = False
        nsg += 1
chk('std', ok_unim, 'range.L1: Smith normal form of the Gram matrix diag(eps) of I_{p,q} is (1,...,1): unimodular, every p + q = 2..12 (%d lattices)' % nsg)
chk('std', ok_sat and (FAULT != 'NONCHAR' or ok_sat), 'range.L1: k = (1,...,1): a Z-basis of k-perp from the extended Euclid algorithm has Smith normal form (1,...,1) with n - 1 factors: k-perp is saturated of rank n - 1, every p + q = 2..12')
chk('std', ok_lev, 'range.L1: a basis of L_even = {x : x.x even} has Smith normal form (1,...,1,2): index 2 in L, rank n, every p + q = 2..12')
ok_gram = True; ngr = 0
for n in range(2, 13):
    for p in range(n + 1):
        q = n - p; eps = [1] * p + [-1] * q
        basis, g = ext_kernel_basis(eps)
        Gk = [[sum(u[t] * eps[t] * v[t] for t in range(n)) for v in basis] for u in basis]
        want = [1] * (n - 2) + ([abs(p - q)] if p != q else [])
        if snf_factors(Gk) != want: ok_gram = False
        ngr += 1
chk('std', ok_gram, 'range.L1: Smith normal form of the Gram matrix of k-perp (k = (1,...,1)) is (1,...,1,|k.k|) with |k.k| = |p - q| when p != q (cyclic discriminant group of order |k.k|) and (1,...,1) of length n - 2 when k.k = 0 (k lies in k-perp, rank n - 2), every p + q = 2..12 (%d lattices)' % ngr)

ok_main = {'even': True, 'bij': True, 'q': True}; ok_inv = True; ok_zero = True; nmain = 0; tab_arf = []
for n in range(2, 13):
    for p in range(n + 1):
        q = n - p; kv = [1] * n
        if FAULT == 'NONCHAR': kv[-1] = 2
        res = kperp_check(p, q, kv, use_leven=(FAULT == 'LEVEN'))
        for key in ok_main: ok_main[key] = ok_main[key] and res[key]
        if res['even'] and res['bij']:
            lab, xx = res['lab'], res['xx']; qv = (xx // 2) % 2
            ql = [0] * (1 << (n - 1))
            for idx in range(1 << (n - 1)): ql[idx] = int(qv[idx])
            # the Clifford side: even labels re-indexed by dropping the pivot bit, as the label form of Cl(p,q-1) (q >= 1) or Cl(0,p-1) (q = 0)
            if q >= 1: pp, qq = p, q - 1
            else: pp, qq = 0, p - 1
            qc = f2lib.q_clifford(pp, qq)
            if f2lib.form_invariants(ql, n - 1) != f2lib.form_invariants(qc, n - 1): ok_inv = False
            if int((qv == 0).sum()) != qc.count(0): ok_zero = False
        nmain += 1
chk('std', ok_main['even'], 'range.L2: k = (1,...,1), p + q = 2..12 (%d lattices): x.x is even on all 2^(n-1) classes of k-perp/2k-perp: k-perp lies in L_even' % nmain)
chk('bit==std', ok_main['bij'] and ok_main['q'], 'range.L2: x mod 2 -> label of the odd coordinates is a bijection of k-perp/2k-perp onto the 2^(n-1) even labels and x.x/2 mod 2 equals Q = [e_a^2 = -1] of Cl(p,q) (f2lib.q_clifford) on the label, every p + q = 2..12')
chk('bit==std', ok_inv and ok_zero, 'range.L2: the complete invariants (dimension, radical, delta, Gauss sum: f2lib.form_invariants) and the number of singular vectors of the lattice form agree with those of the label form of Cl(p,q-1) (Cl(0,p-1) for q = 0), the even part, every p + q = 2..12')
ok_qeq = all(list(qtab(p, n - p)) == [CC.Q(a, CC.sig(p, n - p)) for a in range(1 << n)] for n in range(1, 9) for p in range(n + 1))
chk('bit', ok_qeq, 'range.L2: f2lib.q_clifford equals core_check Q on every label of every Cl(p,q), n <= 8 (the two label tables used here are one)')

ok_br = True; nbr = 0
for n in range(2, 8):
    for p in range(n + 1):
        q = n - p; eps = CC.sig(p, q); A = BR(eps); t = n - 1; gt = A.gen(t)
        if q >= 1: A2 = BR(CC.sig(p, q - 1)); sq_cell = (p, q - 1)
        else: A2 = BR([-1] * (p - 1)); sq_cell = (0, p - 1)
        for b in range(1 << (n - 1)):
            fb = A.one()
            for i in range(n - 1):
                if b >> i & 1: fb = A.mul(fb, A.mul(A.gen(i), gt))
            lab_ = b | (((pc(b) & 1)) << t)
            if len(fb) != 1 or lab_ not in fb: ok_br = False; continue
            s2 = A.mul(fb, fb); want = A2.s(b, b)
            if s2 != {0: want}: ok_br = False
            if (want == -1) != bool(f2lib.q_clifford(*sq_cell)[b]): ok_br = False
        nbr += 1
chk('bit', ok_br, 'range.L3: BR products f_i = e_i e_b (b the last generator): f_b is +-e_label with label = b + pi(b) at the pivot bit, and f_b^2 equals the square of the blade b in Cl(p,q-1) (Cl(0,p-1) for q = 0): the even part carries the label form of the smaller cell, every Cl(p,q) with 2 <= n <= 7 (%d cells)' % nbr)

# L4: every characteristic vector of small norm, and random ones
def small_char_vectors(n, signs=True):
    for pos in [None] + list(range(n)):
        base = [1] * n
        if pos is not None: base[pos] = 3
        if signs:
            for sv in itertools.product((1, -1), repeat=n): yield [a * b for a, b in zip(base, sv)]
        else: yield base
ok4 = {'even': True, 'bij': True, 'q': True}; nk = 0
for n in range(2, 9):
    for p in range(n + 1):
        q = n - p
        for kv in small_char_vectors(n, signs=(n <= 6)):
            res = kperp_check(p, q, kv)
            for key in ok4: ok4[key] = ok4[key] and res[key]
            nk += 1
rng2 = random.Random(101); nrk = 0
for n in range(2, 9):
    for p in range(n + 1):
        for t in range(40):
            kv = [rng2.choice((1, -1)) * rng2.choice((1, 3, 5, 7, 9)) for _ in range(n)]
            res = kperp_check(p, n - p, kv)
            for key in ok4: ok4[key] = ok4[key] and res[key]
            nrk += 1
chk('std', ok4['even'], 'range.L4: for EVERY characteristic vector k with sum k_i^2 <= n + 8 (all coordinates +-1 but at most one +-3) of I_{p,q}, p + q = 2..8 (%d vectors: all sign patterns for p + q <= 6, positive representatives above; coordinate sign changes are isometries that leave x mod 2 and x.x unchanged) and for %d seeded random vectors with odd coordinates up to 9: k-perp lies in L_even (x.x even on all classes)' % (nk, nrk))
chk('bit==std', ok4['bij'] and ok4['q'], 'range.L4: for all of them the label map is a bijection of k-perp/2k-perp onto the even labels carrying x.x/2 mod 2 to Q of Cl(p,q): the form does not depend on k')

# L5: A_n and E_n (the lattices behind the Gosset rows)
ok_an = ok_en = ok_sp = ok_pv = ok_snf = True; nan = nen = 0
for n in range(1, 12):
    p, q = n + 1, 0; kv = [1] * (n + 1)
    roots = [[1 if t == i else (-1 if t == i + 1 else 0) for t in range(n + 1)] for i in range(n)]
    res = kperp_check(p, q, kv)
    basis = res['basis']
    if any(express(roots, x) is None or any(v.denominator != 1 for v in express(roots, x)) for x in basis): ok_sp = False
    if not (res['even'] and res['bij'] and res['q']): ok_an = False
    GA = [[sum(u[t] * v[t] for t in range(n + 1)) for v in roots] for u in roots]
    if snf_factors(GA) != [1] * (n - 1) + [n + 1]: ok_snf = False
    # drop the last bit: the labels of Cl(0,n) = Cl^0(n+1,0)
    lab = res['lab']; qv = (res['xx'] // 2) % 2
    if n >= 1 and not all(qv[i] == qtab(0, n)[int(lab[i]) & ((1 << n) - 1)] for i in range(len(lab))): ok_pv = False
    nan += 1
for n in range(3, 12):
    p, q = 1, n; kv = [3] + [-1] * n
    roots = [[1, -1, -1, -1] + [0] * (n - 3)] + [[0] * i + [1, -1] + [0] * (n - i - 1) for i in range(1, n + 1) if i < n for _ in [0]]
    roots = [[1, -1, -1, -1] + [0] * (n - 3)] + [[0] + [1 if t == i else (-1 if t == i + 1 else 0) for t in range(1, n + 1)] for i in range(1, n)]
    roots = [r_ if len(r_) == n + 1 else r_ + [0] * (n + 1 - len(r_)) for r_ in roots]
    res = kperp_check(p, q, kv); basis = res['basis']
    if any(express(roots, x) is None or any(v.denominator != 1 for v in express(roots, x)) for x in basis): ok_sp = False
    if any(sum(([1] + [-1] * n)[t] * kv[t] * r_[t] for t in range(n + 1)) != 0 for r_ in roots): ok_sp = False
    if not (res['even'] and res['bij'] and res['q']): ok_en = False
    eE = [1] + [-1] * n
    GE = [[sum(u[t] * eE[t] * v[t] for t in range(n + 1)) for v in roots] for u in roots]
    if snf_factors(GE) != ([1] * (n - 1) + [abs(9 - n)] if n != 9 else [1] * 8): ok_snf = False
    lab = res['lab']; qv = (res['xx'] // 2) % 2
    if not all(qv[i] == qtab(n, 0)[int(lab[i]) >> 1] for i in range(len(lab))): ok_pv = False       # drop the time bit: the labels of Cl(n,0) = Cl^0(1,n)
    nen += 1
chk('std', ok_sp, 'range.L5: the simple roots of A_n (e_i - e_{i+1}, n = 1..11, in Z^{n+1}) and of E_n (e_0 - e_1 - e_2 - e_3 and e_i - e_{i+1}, n = 3..11, in I_{1,n}) are orthogonal to k = (1,...,1) resp. (3;-1,...,-1) and generate all of k-perp (every Z-basis vector of k-perp is an integer combination of the roots, exact solve)')
chk('std', ok_snf, 'range.L5: Smith normal form of the Gram matrix of the simple roots: (1,...,1,n+1) for A_n (n = 1..11) and (1,...,1,|9 - n|) for E_n (n = 3..11; rank 8 for n = 9), the discriminant |k.k| of k = (1,...,1) resp. (3;-1,...,-1)')
chk('bit==std', ok_an and ok_en, 'range.L5: A_n/2A_n (n = 1..11) is the set of even labels of Cl(n+1,0) with x.x/2 mod 2 = Q, and E_n/2E_n (n = 3..11, including n = 9 where k is isotropic and n = 10, 11 where it is not positive) the even labels of Cl(1,n) with x.x/2 mod 2 = Q')
chk('bit==std', ok_pv, 'range.L5: dropping the last bit (A_n) carries these labels onto Cl(0,n) = Cl^0(n+1,0) and dropping the time bit (E_n) onto Cl(n,0) = Cl^0(1,n), with the form preserved: the label form of Cl(0,n) and of Cl(n,0)')

# L6: controls
nonchar_ok = True; nnc = 0
for n in range(2, 6):
    for p in range(n + 1):
        q = n - p; eps = [1] * p + [-1] * q
        for kv in itertools.product(range(-2, 4), repeat=n):
            if not any(kv) or all(k % 2 for k in kv): continue
            from math import gcd
            g = 0
            for k in kv: g = gcd(g, abs(k))
            if g != 1: continue
            res = kperp_check(p, q, list(kv))
            if res['even']: nonchar_ok = False
            nnc += 1
chk('ctl', nonchar_ok and nnc > 0, 'range.L6: a primitive k with an even coordinate is not characteristic: for all %d such k with coordinates in -2..3, p + q = 2..5, k-perp contains a vector of odd norm (x.x/2 is not integral, the form is not defined)' % nnc)
ok_le = True; nle = 0
for n in range(2, 10):
    for p in range(n + 1):
        q = n - p; eps = [1] * p + [-1] * q
        lev = [[-1 if t == 0 else (1 if t == i else 0) for t in range(n)] for i in range(1, n)] + [[2] + [0] * (n - 1)]
        lab, xx = reduce_classes(lev, eps)
        two_to_one = len(lab) == 1 << n and int(np.unique(lab).size) == 1 << (n - 1) and bool((xx % 2 == 0).all())
        if not two_to_one: ok_le = False
        nle += 1
chk('ctl', ok_le and nle > 0, 'range.L6: L_even in place of k-perp: rank n, L_even/2 L_even has 2^n classes and maps 2-to-1 onto the 2^(n-1) even labels (the class of 2 e_1 is a radical vector of the form at label 0): not a bijection, a form of dimension n, for every p + q = 2..9 (%d lattices)' % nle)

finish('RANGE' + ('-' + FAULT if FAULT else ''))
