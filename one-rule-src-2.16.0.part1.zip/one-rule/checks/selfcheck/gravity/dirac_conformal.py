#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""DIRAC-CONF.  The massless Dirac-Hestenes equation is invariant under the special conformal fields xi_b = 2 (b.x) x - x^2 b of so(2,4),
with the spinor weight 3/2.      python3 dirac_conformal.py [--fault WEIGHT|ROT|SHEAR|MASSIVE|KELVIN]

 Minkowski R^{1,3}, signature (+,-,-,-), the coordinates x^mu of gm_conformal.py; blades of Cl(1,3) by the bit rule (bit 0 = time); the
 vector derivative nabla = gamma^mu d_mu (gamma^mu = eta^{mu mu} gamma_mu); psi even. For a field xi: Omega = nabla ^ xi (the bivector of the
 2-form d xi_flat), sigma = (d_mu xi^mu)/4, and delta_{a,w} psi = xi^mu d_mu psi + a Omega psi + w sigma psi.
 [bit]  xi_b and the conformal Killing equation L_xi eta = 4 (b.x) eta as in gm_conformal.py (engine d), L_xi *X = * L_xi X on a random 2-form
        (bit-rule star, the Lie derivative of g2_forms_calc), Omega and sigma from the engine's d; exact polynomial solutions of nabla psi = 0
        (psi even, degree <= 3, an exact linear solve, three random ones); the pair (a, w) with nabla delta_{a,w} psi = 0 solved for exactly,
        for b = (1/2, -1, 1/2, 3/2), (1, 0, 0, 0), (1, 1, 0, 0); the operator identity nabla delta_{1/4,3/2} = delta_{1/4,5/2} nabla on random
        polynomial even fields (degree 3), and the unique weights (3/2, 5/2) of that identity solved for.
 [std]  Omega and sigma by plain polynomial derivatives; the Kelvin inversion K_p psi = x psi(x/x^2)/(x^2)^p of the solutions: nabla of
        N/(x^2)^k vanishes iff x^2 nabla N - 2 k x N = 0 (exact), for p = 1, 2, 3; numpy: the same inversion with 4 x 4 Dirac matrices and
        central differences at three points; the weight of the inversion, w = p - 1/2 (x/(x^2)^p = (x/|x|) |x|^(1-2p), the conformal factor of
        the inversion being 1/|x^2|), compared with the solved one.
 Controls ([ctl]; each --fault puts the wrong version into the main line, which must then FAIL): WEIGHT w = 5/2 (and w = 1/2 as a control);
 ROT a = -1/4; SHEAR the shear xi = x^1 d_0 (not conformal: no pair (a, w) works); MASSIVE the operator nabla psi J - m psi gamma_0 (no pair of
 weights intertwines it, and the image of the rest-frame plane wave psi_0 exp(-J m t) is not a solution); KELVIN p = 1.
 Engine: the conformal Killing line, Omega and sigma read the engine's d; the star line reads d and the frame. The Yang-Mills equation is
 not here.  Scope: one b of gm_conformal.py and two more; polynomial solutions of degree <= 3 (three), random fields of degree 3 (three);
 exact Fractions except the numpy line (tolerance printed)."""
import os, sys, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import g2_forms_calc as FC
import numpy as np

_chk = chk; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[0 if cond else 1] += 1
    return _chk(tag, cond, msg)
ARGS = sys.argv[1:]
FAULTS = ('WEIGHT', 'ROT', 'SHEAR', 'MASSIVE', 'KELVIN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))

N = 4; SQ = LORENTZ(4); B0 = [F(1, 2), F(-1), F(1, 2), F(3, 2)]
BS = [B0, [F(1), F(0), F(0), F(0)], [F(1), F(1), F(0), F(0)]]
MONS3 = [ex for ex in itertools.product(range(4), repeat=N) if sum(ex) <= 3]
EVEN = [m for m in range(16) if popc(m) % 2 == 0]; ODD = [m for m in range(16) if popc(m) % 2 == 1]
# ------------------------------------------------------------------------------------------------ copied from gm_conformal.py
def flat(nv=N): return [{1 << a: const(nv, 1)} for a in range(N)], [[const(nv, int(m == a)) for a in range(N)] for m in range(N)]
def xi_special(b):
    X = [var(N, i) for i in range(N)]; bx = lin(*[(F(SQ[m]) * b[m], X[m]) for m in range(N)]); x2 = lin(*[(F(SQ[m]), sp_mul(X[m], X[m], 9, N)) for m in range(N)])
    return [lin((F(2), sp_mul(bx, X[m], 9, N)), (-b[m], x2)) for m in range(N)], bx
def killing_matrix(Gv, xi):
    """(L_xi eta)_{mu nu} = eta_{mu l} d_nu xi^l + eta_{l nu} d_mu xi^l, with d_nu xi^l read from L_xi dx^l = d xi^l (engine d)"""
    dxi = [Gv.Fm.d({0: xi[l]}) for l in range(N)]
    D = [[dxi[l].get(1 << nu, {}) for nu in range(N)] for l in range(N)]
    return [[lin((F(SQ[mu]), D[mu][nu]), (F(SQ[nu]), D[nu][mu])) for nu in range(N)] for mu in range(N)]
# ------------------------------------------------------------------------------------------------ polynomial multivector fields (the bit rule)
def pmul(a, b):
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            k = tuple(x + y for x, y in zip(k1, k2)); x = r.get(k, 0) + v1 * v2
            if x == 0: r.pop(k, None)
            else: r[k] = x
    return r
def fadd(A, B, c=1):
    r = dict(A)
    for m, p in B.items():
        x = padd(r.get(m, {}), p, c)
        if x: r[m] = x
        else: r.pop(m, None)
    return r
def fmul(A, B):
    r = {}
    for a, pa in A.items():
        for b, pb in B.items():
            m, s = bmul(a, b, SQ); x = padd(r.get(m, {}), pmul(pa, pb), s)
            if x: r[m] = x
            else: r.pop(m, None)
    return r
def fpoly(A, e): return {m: q for m, p in A.items() for q in [pmul(p, e)] if q}
def fder(A, i): return {m: q for m, p in A.items() for q in [pder(p, i)] if q}
def fscale(A, c): return {m: q for m, p in A.items() for q in [pscale(p, c)] if q}
def cst(a): return {m: const(N, c) for m, c in a.items() if c}
ONE = const(N, 1); JF = cst({6: -1}); G0F = cst({1: 1})
def nabla(A):
    out = {}
    for mu in range(N): out = fadd(out, fmul({1 << mu: const(N, SQ[mu])}, fder(A, mu)))
    return out
def delta(P, xi, Om, sig, a, w, kap0=0):
    """xi^mu d_mu P + a Omega P + w sigma P; kap0 != 0: P stands for P exp(J kap0 t), the time derivative carries kap0 P J"""
    out = {}
    for mu in range(N):
        dP = fder(P, mu)
        if mu == 0 and kap0: dP = fadd(dP, fmul(P, JF), kap0)
        out = fadd(out, fpoly(dP, xi[mu]))
    return fadd(fadd(out, fmul(Om, P), a), fpoly(P, sig), w)
def nabla_ph(P, kap0):
    out = nabla(P)
    if kap0: out = fadd(out, fmul({1: const(N, SQ[0])}, fmul(P, JF)), kap0)
    return out
def Dm(P, m, kap0=0): return fadd(fmul(nabla_ph(P, kap0), JF), fmul(P, G0F), -m)
def rref(rows, ncols):
    M = [[F(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncols):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / M[rk][c]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
        if rk == len(M): break
    return M[:rk], piv
def solve(cols, target):
    """x with sum_j x_j cols[j] = target (fields); None if there is none; also the rank of the columns"""
    keys = sorted({(m, k) for f in cols + [target] for m, p in f.items() for k in p})
    rows = [[f.get(m, {}).get(k, F(0)) for f in cols] + [target.get(m, {}).get(k, F(0))] for m, k in keys]
    R, piv = rref(rows, len(cols) + 1)
    if len(cols) in piv: return None, len(piv)
    x = [F(0)] * len(cols)
    for i, p in enumerate(piv): x[p] = R[i][-1]
    return x, len(piv)
# ------------------------------------------------------------------------------------------------ Omega and sigma, two routes
def omega_sigma_engine(Gv, xi):
    dflat = Gv.Fm.d({1 << nu: pscale(xi[nu], SQ[nu]) for nu in range(N)})               # the 2-form d(xi_nu dx^nu), engine d
    Om = {m: q for m, p in dflat.items() for a, b in [[i for i in range(N) if m >> i & 1]] for q in [pscale(p, SQ[a] * SQ[b])] if q}
    sig = {}
    for l in range(N): sig = padd(sig, Gv.Fm.d({0: xi[l]}).get(1 << l, {}))
    return Om, pscale(sig, F(1, 4))
def omega_sigma_plain(xi):
    Om = {}
    for a, b in itertools.combinations(range(N), 2):
        p = padd(pscale(pder(xi[b], a), SQ[b]), pscale(pder(xi[a], b), SQ[a]), -1)       # d_a xi_b - d_b xi_a, xi_b = eta_bb xi^b
        p = pscale(p, SQ[a] * SQ[b])                                                       # gamma^a gamma^b = eta^aa eta^bb gamma_a gamma_b
        if p: Om[(1 << a) | (1 << b)] = p
    sig = {}
    for l in range(N): sig = padd(sig, pder(xi[l], l))
    return Om, pscale(sig, F(1, 4))
# ------------------------------------------------------------------------------------------------ exact polynomial solutions of nabla psi = 0
def monogenic_solutions(count, seed):
    unknowns = [(S, ex) for S in EVEN for ex in MONS3]; keys = {}; cols = []
    for S, ex in unknowns:
        col = {}
        for m, p in nabla({S: {ex: F(1)}}).items():
            for k, v in p.items(): col[keys.setdefault((m, k), len(keys))] = v
        cols.append(col)
    rows = [[F(0)] * len(unknowns) for _ in range(len(keys))]
    for j, col in enumerate(cols):
        for i, v in col.items(): rows[i][j] = v
    R, piv = rref(rows, len(unknowns)); free = [c for c in range(len(unknowns)) if c not in piv]; sols = []
    rng = random.Random(seed)
    for _ in range(count):
        val = [F(0)] * len(unknowns)
        for c in free: val[c] = F(rng.randint(-4, 4))
        for i, c in enumerate(piv): val[c] = -sum(R[i][j] * val[j] for j in free)
        psi = {}
        for (S, ex), v in zip(unknowns, val):
            if v: psi.setdefault(S, {})[ex] = v
        sols.append(psi)
    return sols, len(piv), len(unknowns)
def rand_field(rng, deg, grades):
    mons = [ex for ex in itertools.product(range(deg + 1), repeat=N) if sum(ex) <= deg]
    return {m: p for m in range(16) if popc(m) in grades for p in [{ex: F(rng.randint(-3, 3)) for ex in mons if rng.random() < .3}] if p}

def main():
    Gv = Grav(N); Fm = Gv.Fm; ef, Ef = flat()
    head('dconf·1 (1) the fields xi_b, the conformal Killing equation (engine d) and L_xi * = * L_xi [bit]; Omega and sigma by the engine and by plain derivatives [bit==std]')
    XI = []
    for b in BS:
        xi, bx = xi_special(b); Km = killing_matrix(Gv, xi)
        chk('bit', all(Km[m][n] == (scale(bx, 4 * SQ[m]) if m == n else {}) for m in range(N) for n in range(N)),
            'b = (%s): L_xi eta_{mu nu} = 4 (b.x) eta_{mu nu} exactly (d xi^l from the engine\'s d)' % ', '.join(map(str, b)))
        Om, sig = omega_sigma_engine(Gv, xi); Om2, sig2 = omega_sigma_plain(xi)
        chk('bit==std', Om == Om2 and sig == sig2 and sig == scale(bx, 2) and bool(Om),
            'b = (%s): Omega = nabla ^ xi from the engine\'s 2-form d xi_flat equals the plain derivative d_a xi_b - d_b xi_a; sigma = d.xi/4 = 2 (b.x) both ways' % ', '.join(map(str, b)))
        XI.append((b, xi, bx, Om, sig))
    X = gs.sform(random.Random(1), N, 2, 2); xi0 = XI[0][1]
    chk('bit', FC.form_eq(FC.lie(Gv, xi0, H.hodge_form(X, ef, Ef, Fm, SQ, N, 'bit')), H.hodge_form(FC.lie(Gv, xi0, X), ef, Ef, Fm, SQ, N, 'bit')),
        'b = (1/2, -1, 1/2, 3/2): L_xi *X = * L_xi X for a random 2-form of degree 2 (the line of gm_conformal.py)')
    head('dconf·2 (2) exact solutions of nabla psi = 0 and the pair (a, w) that keeps them [bit]')
    sols, rk, nu = monogenic_solutions(3, 1313)
    chk('bit', all(nabla(s) == {} and bool(s) for s in sols), 'nabla psi = 0 on even psi of degree <= 3: the map has rank %d on %d unknowns; three random exact solutions (non-zero)' % (rk, nu))
    found = []
    for b, xi, bx, Om, sig in XI:
        for s in sols:
            U = nabla(delta(s, xi, Om, sig, 0, 0)); V = nabla(fmul(Om, s)); W = nabla(fpoly(s, sig))
            x, r = solve([V, W], fscale(U, -1)); found.append((tuple(x) if x else None, r))
    chk('bit', all(f == ((F(1, 4), F(3, 2)), 2) for f in found),
        'for each of the three b and each solution, nabla(xi.d psi + a Omega psi + w sigma psi) = 0 has the unique solution (a, w) = %s (rank 2): the rotation coefficient 1/4 and the weight 3/2'
        % ', '.join(sorted({'(%s, %s)' % f[0] for f in found if f[0]} | {'none' for f in found if not f[0]})))
    a_m, w_m = (F(-1, 4) if FAULT == 'ROT' else F(1, 4)), (F(5, 2) if FAULT == 'WEIGHT' else F(3, 2))
    shear = [var(N, 1), {}, {}, {}]; Oms, sgs = omega_sigma_plain(shear)
    ok = True
    for b, xi, bx, Om, sig in XI:
        if FAULT == 'SHEAR': xi, Om, sig = shear, Oms, sgs
        ok &= all(nabla(delta(s, xi, Om, sig, a_m, w_m)) == {} for s in sols)
    chk('bit', ok, 'psi -> xi.d psi + (1/4) Omega psi + (3/2) sigma psi maps the three solutions to solutions, for the three b')
    b, xi, bx, Om, sig = XI[0]
    for w_bad in (F(1, 2), F(5, 2)):
        chk('ctl', all(nabla(delta(s, xi, Om, sig, F(1, 4), w_bad)) != {} for s in sols), 'weight %s in place of 3/2: nabla(delta psi) != 0 for each solution' % w_bad)
    chk('ctl', all(nabla(delta(s, xi, Om, sig, F(-1, 4), F(3, 2))) != {} for s in sols), 'rotation coefficient -1/4: nabla(delta psi) != 0')
    xs = [solve([nabla(fmul(Oms, s)), nabla(fpoly(s, sgs))], fscale(nabla(delta(s, shear, Oms, sgs, 0, 0)), -1))[0] for s in sols]
    chk('ctl', all(x is None for x in xs), 'the shear xi = x^1 d_0 (not conformal): no pair (a, w) keeps the solutions')
    head('dconf·3 (3) the operator identity nabla delta_{3/2} = delta_{5/2} nabla on random fields; the massive operator [bit]')
    rf = random.Random(2626); okI = True; wsol = []
    mI = F(5) if FAULT == 'MASSIVE' else F(0)
    for k in range(3):
        psi = rand_field(rf, 3, (0, 2, 4)); b, xi, bx, Om, sig = XI[k]
        L = Dm(delta(psi, xi, Om, sig, F(1, 4), F(3, 2)), mI); R_ = delta(Dm(psi, mI), xi, Om, sig, F(1, 4), F(5, 2))
        okI &= L == R_
        A_ = fmul(nabla(delta(psi, xi, Om, sig, F(1, 4), 0)), JF); Bw = fmul(nabla(fpoly(psi, sig)), JF); C_ = delta(fmul(nabla(psi), JF), xi, Om, sig, F(1, 4), 0); Cw = fmul(fpoly(fmul(nabla(psi), JF), sig), {0: ONE})
        x, r = solve([Bw, fscale(Cw, -1)], fscale(fadd(A_, C_, -1), -1)); wsol.append(tuple(x) if x else None)
    chk('bit', okI, 'nabla(delta_{1/4,3/2} psi) J = delta_{1/4,5/2}(nabla psi J) on three random even fields of degree 3 (one per b): the massless operator intertwines, so every solution goes to a solution')
    chk('bit', all(w == (F(3, 2), F(5, 2)) for w in wsol), 'the weights (w, w\') with nabla delta_w = delta_{w\'} nabla, solved for: %s on each of the three fields, unique' % ', '.join(sorted({'(%s, %s)' % w if w else 'none' for w in wsol})))
    mm = F(5); wm = []
    for k in range(3):
        psi = rand_field(random.Random(3000 + k), 3, (0, 2, 4)); b, xi, bx, Om, sig = XI[k]
        A_ = fadd(Dm(delta(psi, xi, Om, sig, F(1, 4), 0), mm), delta(Dm(psi, mm), xi, Om, sig, F(1, 4), 0), -1)
        x, r = solve([Dm(fpoly(psi, sig), mm), fscale(fpoly(Dm(psi, mm), sig), -1)], fscale(A_, -1)); wm.append(x)
    chk('ctl', all(x is None for x in wm), 'the massive operator nabla psi J - m psi gamma_0 (m = 5): no pair of weights (w, w\') gives D_m delta_w = delta_{w\'} D_m, three random fields')
    m3 = F(3); kap = -m3; okpw = True; okfm = True
    for psi0 in ({0: F(1)}, {6: F(2), 12: F(-1)}, {0: F(1), 10: F(3)}):
        P = cst(psi0); okpw &= Dm(P, m3, kap) == {}
        img = delta(P, xi, Om, sig, F(1, 4), F(3, 2), kap)
        res = Dm(img, m3, kap); okfm &= res != {} and res == fscale(fmul(fpoly(P, sig), G0F), m3)
    chk('ctl', okpw and okfm, 'the rest-frame plane waves psi_0 exp(-J m t) (m = 3, psi_0 even Pauli) solve D_m psi = 0, and their images under delta_{1/4,3/2} do not: D_m(delta psi) = m sigma psi gamma_0 != 0 exactly')
    head('dconf·4 (4) the Kelvin inversion x psi(x/x^2)/(x^2)^p of the solutions, exact [std]; with 4 x 4 Dirac matrices, numerical [std]')
    x2 = {(2, 0, 0, 0): F(1), (0, 2, 0, 0): F(-1), (0, 0, 2, 0): F(-1), (0, 0, 0, 2): F(-1)}
    xvec = {1 << mu: var(N, mu) for mu in range(N)}
    def kelvin_ok(psi, p):
        Dg = max(sum(k) for q in psi.values() for k in q); Mn = {}
        for d in range(Dg + 1):
            part = {m: q for m, pp in psi.items() for q in [{k: v for k, v in pp.items() if sum(k) == d}] if q}
            pw = {(0,) * N: F(1)}
            for _ in range(Dg - d): pw = pmul(pw, x2)
            Mn = fadd(Mn, fpoly(part, pw))
        Nn = fmul(xvec, Mn); k = Dg + p
        return fadd(fpoly(nabla(Nn), x2), fmul(xvec, Nn), -2 * k) == {}
    pk = 1 if FAULT == 'KELVIN' else 2
    res = {p: [kelvin_ok(s, p) for s in sols] for p in (1, 2, 3)}
    chk('std', all(kelvin_ok(s, pk) for s in sols), 'K_2 psi = x psi(x/x^2)/(x^2)^2 solves nabla K_2 psi = 0 for the three solutions (x^2 nabla N - 2 k x N = 0 exactly)')
    chk('ctl', not any(res[1]) and not any(res[3]), 'the powers p = 1 and p = 3 in place of 2: not solutions (%s, %s)' % (res[1], res[3]))
    nonsol = rand_field(random.Random(77), 3, (0, 2, 4))
    chk('ctl', not kelvin_ok(nonsol, 2), 'a random even field that is not a solution: K_2 of it is not a solution')
    w_std = [p for p in (1, 2, 3) if all(res[p])]
    chk('bit==std', w_std == [2] and (F(w_std[0]) - F(1, 2)) == F(3, 2), 'the only power that works is p = %s: weight p - 1/2 = 3/2, the weight solved for in (2)' % w_std)
    I2 = np.eye(2); Z2 = np.zeros((2, 2)); PM = [np.array([[0, 1], [1, 0]], complex), np.array([[0, -1j], [1j, 0]]), np.array([[1, 0], [0, -1]], complex)]
    gD = [np.block([[I2, Z2], [Z2, -I2]]).astype(complex)] + [np.block([[Z2, s], [-s, Z2]]) for s in PM]; GL = [gD[0]] + [-gD[k] for k in (1, 2, 3)]
    def matb(m):
        M = np.eye(4, dtype=complex)
        for i in range(N):
            if m >> i & 1: M = M @ GL[i]
        return M
    def evalf(psi, x):
        return sum(float(v) * np.prod([x[i] ** k[i] for i in range(N)]) * matb(m) for m, q in psi.items() for k, v in q.items())
    def kel(psi, x, p):
        xx = x[0] ** 2 - x[1] ** 2 - x[2] ** 2 - x[3] ** 2
        return sum(x[mu] * GL[mu] for mu in range(N)) @ evalf(psi, x / xx) / xx ** p
    def dirac_num(f, x, h=1e-5):
        out = np.zeros((4, 4), complex)
        for mu in range(N):
            dx = np.zeros(4); dx[mu] = h; out += SQ[mu] * GL[mu] @ (f(x + dx) - f(x - dx)) / (2 * h)
        return float(np.abs(out).max())
    pts = [np.array([1.3, 0.4, -0.2, 0.3]), np.array([-0.9, 1.6, 0.5, -0.4]), np.array([0.7, -0.3, 1.8, 0.6])]
    r0 = max(dirac_num(lambda y: evalf(s, y), x) for s in sols for x in pts)
    rk = {p: max(dirac_num(lambda y: kel(s, y, p), x) / max(1.0, float(np.abs(kel(s, x, p)).max())) for s in sols for x in pts) for p in (1, 2, 3)}
    chk('std', r0 < 1e-6 and rk[2] < 1e-5 and rk[1] > 1e-3 and rk[3] > 1e-3,
        'Dirac matrices, central differences at three points off the light cone: residual of the solutions %.1e, of K_2 %.1e; K_1 %.1e and K_3 %.1e (not solutions)' % (r0, rk[2], rk[1], rk[3]))
    print('\n  reading: the massless Dirac-Hestenes equation is invariant under the special conformal generator with the spinor weight 3/2; a mass term breaks it.')

if __name__ == '__main__':
    main(); print('\nchecks: %d ok, %d FAIL' % tuple(COUNT)); finish('DIRAC-CONF')
