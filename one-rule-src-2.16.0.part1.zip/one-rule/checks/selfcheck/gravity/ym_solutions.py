#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""YM-SOL.  Two classical Yang-Mills solutions on the bit rule: the BPST instanton and the Wu-Yang monopole.   python3 ym_solutions.py

 BPST      Euclidean R^4 (signature (+,+,+,+), x^4 = slot 3, eps_1234 = +1), 't Hooft symbols eta; regular gauge A^a_mu = 2 eta^a_mu nu x^nu / (x^2 + rho^2) on the so(3)
           of Lie([-1]*3) (generators B_01, B_02, B_12, [B_A, B_B] = 2 eps_ABC B_C) and on one su(2) ideal of so(4) = Lie([-1]*4).
           Claim: F = *F, F = -4 eta rho^2/(x^2 + rho^2)^2, D*F = 0, density Sum_a F^a ^ F^a = 96 rho^4/(x^2 + rho^2)^4 vol, instanton number 1 (exact rational).
 Wu-Yang   signature (+,-,-,-), static A^a_i = eps_aij x_j / r^2 (slots 1..3 = x, y, z): D*F = 0 away from the origin, F^a_ij = sigma eps_ijk x_a x_k / r^4, Sum_a B^a_i B^a_i = 1/r^4.
 [bit]     the engine's curvature and D_bivector, g2_hodge's bit-rule star, on exact Taylor jets (degree 2) at rational points: F exact to degree 1, D*F at the point.
 [std]     numpy: eta symbols, five-point differences of the closed forms, scipy quadrature of the radial integral and of the volume of S^3.
 [ctl]     the singular gauge (a gauge transformation by a unit quaternion field: F transforms covariantly), rho^2 -> -rho^2 (local equations hold, the integral diverges),
           the anti-instanton (anti-self-dual, number -1), A -> 2A for BPST (not a solution); for Wu-Yang lambda = 2 is a pure gauge (F = 0) and lambda = 1/2, 3 are the controls.
 Exports (no engine object at import): eta_thooft, inv_quad_jet, bpst_A, wuyang_A, so4_ideal."""
import os, sys, time, itertools, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import numpy as np
from scipy import integrate

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
n = 4; NV = 4; FULL = 15; EUC = [1, 1, 1, 1]; LOR = [1, -1, -1, -1]; DEG = 2

def eps3(i, j, k): return H.perm_sign([i, j, k]) if len({i, j, k}) == 3 else 0
def eta_thooft(bar=False):
    """eta[a][mu][nu], a = 0..2, mu, nu = 0..3 (slot 3 = x^4): eta^a_ij = eps_aij, eta^a_i4 = delta_ai (eta-bar: -delta_ai), antisymmetric"""
    e = [[[F(0)] * 4 for _ in range(4)] for _ in range(3)]
    for a in range(3):
        for i in range(3):
            for j in range(3): e[a][i][j] = F(eps3(a, i, j))
            s = -1 if bar else 1; e[a][i][3] = F(s * (a == i)); e[a][3][i] = F(-s * (a == i))
    return e
def jmul(a, b): return sp_mul(a, b, DEG, n)
def inv_quad_jet(p, c, sgn=1, slots=(0, 1, 2, 3)):
    """1/(x^2 + sgn c) around p (x^2 summed over the given slots) as a jet of degree 2: (1/Q0)(1 - u + u^2), Q0 = p^2 + sgn c, u = (2 p.delta + delta^2)/Q0"""
    Q0 = sum(p[i] * p[i] for i in slots) + sgn * c; X = {i: var(NV, i) for i in slots}
    u = lin(*[(2 * p[i] / Q0, X[i]) for i in slots], *[(1 / Q0, jmul(X[i], X[i])) for i in slots])
    return lin((1 / Q0, const(NV, 1)), (-1 / Q0, u), (1 / Q0, jmul(u, u))), Q0
def xs_jet(p): return [lin((F(1), const(NV, p[i])), (F(1), var(NV, i))) for i in range(4)]
def bpst_A(p, rho2, bar=False, sgn=1, scale_=1):
    """A^a = 2 eta^a_mu nu x^nu / (x^2 + sgn rho^2) dx^mu (jets of degree 2 at p, 4 coordinates), a list of 3 one-forms"""
    eta = eta_thooft(bar); inv, Q0 = inv_quad_jet(p, rho2, sgn); X = xs_jet(p); A = []
    for a in range(3):
        form = {}
        for mu in range(4):
            num = lin(*[(2 * scale_ * eta[a][mu][nu], X[nu]) for nu in range(4) if eta[a][mu][nu]])
            if num: form[1 << mu] = jmul(num, inv)
        A.append(form)
    return A, Q0
def wuyang_A(p, scale_=1):
    """A^a = eps_aij x_j / r^2 dx^i, x = (slots 1, 2, 3), static (jets of degree 2 at the space-time point p)"""
    inv, Q0 = inv_quad_jet(p, F(0), slots=(1, 2, 3))
    X = xs_jet(p); A = []
    for a in range(3):
        form = {}
        for i in range(3):
            num = lin(*[(F(scale_ * eps3(a, i, j)), X[j + 1]) for j in range(3) if eps3(a, i, j)])
            if num: form[1 << (i + 1)] = jmul(num, inv)
        A.append(form)
    return A, Q0
def deg_le(X, d): return {m: q for m, q in ((m, {k: v for k, v in p.items() if sum(k) <= d}) for m, p in X.items()) if q}
def at0f(X): return {m: at0(p, NV) for m, p in X.items() if at0(p, NV) != 0}
def so4_ideal(L4):
    """three combinations S_a = c (B_0i + s_a B_jk) of so(4) with [S_a, S_b] = 2 eps_abc S_c (found by search over the signs and c in {1/2, 1, 2})"""
    idx = L4.idx; B = lambda i, j: idx[(1 << i) | (1 << j)]
    def br(X, Y):
        r = [F(0)] * L4.G
        for (P, Q), (C, f) in L4.f.items(): r[C] += X[P] * Y[Q] * f
        return r
    for sg in itertools.product((1, -1), repeat=3):
        for c in (F(1, 2), F(1), F(2)):
            S = []
            for (i, (j, k)), s in zip(((1, (2, 3)), (2, (1, 3)), (3, (1, 2))), sg):
                v = [F(0)] * L4.G; v[B(0, i)] += c; v[B(j, k)] += c * s; S.append(v)
            if all(br(S[a], S[b]) == [sum(2 * eps3(a, b, cc) * S[cc][q] for cc in range(3)) for q in range(L4.G)] for a in range(3) for b in range(3)):
                return S, sg, c
    return None, None, None
def embed(Ao, S, G4):
    out = [{} for _ in range(G4)]; Fm = Forms(4)
    for a in range(3):
        for q in range(G4):
            if S[a][q]: out[q] = Fm.add(out[q], Ao[a], S[a][q])
    return out

def main():
    L3 = Lie([-1] * 3); G3 = Grav(4, L3); Fm = G3.Fm
    head('0. the algebra and the symbols')
    half_eps = all(F(f, 2) == eps3(P, Q, C) for (P, Q), (C, f) in L3.f.items()) and len(L3.f) == 6
    chk('bit', half_eps, 'so(3) of Lie([-1]*3) in the engine order (B_01, B_02, B_12): (1/2) f_AB^C = eps_ABC on all 6 non-zero entries, so the engine\'s F = dA - dA + (1/2) f A A is the textbook dA - dA + eps A A')
    eta = eta_thooft(); etab = eta_thooft(True); epsl = lambda idx: H.perm_sign(idx) if len(set(idx)) == 4 else 0
    sd = all(eta[a][m][v] == sum(F(epsl([m, v, r, s]), 2) * eta[a][r][s] for r in range(4) for s in range(4)) for a in range(3) for m in range(4) for v in range(4))
    asd = all(etab[a][m][v] == -sum(F(epsl([m, v, r, s]), 2) * etab[a][r][s] for r in range(4) for s in range(4)) for a in range(3) for m in range(4) for v in range(4))
    tw = sum(eta[a][m][v] ** 2 for a in range(3) for m in range(4) for v in range(4))
    E_np = np.array([[[float(eta[a][m][v]) for v in range(4)] for m in range(4)] for a in range(3)])
    chk('std', sd and asd and tw == 12 and abs(np.einsum('amn,amn->', E_np, E_np) - 12) < 1e-12, 'eta^a_mn = (1/2) eps_mnrs eta^a_rs (self-dual), eta-bar anti-self-dual, Sum eta^a_mn eta^a_mn = %s (exact and numpy)' % tw)
    L4 = Lie([-1] * 4); G4 = Grav(4, L4); S4, sg4, c4 = so4_ideal(L4)
    chk('bit', S4 is not None, 'so(4): S_a = c (B_0i + s_a B_jk) with signs %s and c = %s satisfy [S_a, S_b] = 2 eps_abc S_c (one su(2) ideal of so(4), engine f)' % (sg4, c4))
    tick('part 0')

    # ------------------------------------------------------------------ 1. BPST
    head('1. BPST instanton, regular gauge, exact jets at rational points: F = *F, F = -4 eta rho^2/(x^2+rho^2)^2, D*F = 0, the density')
    rng = random.Random(4242); pts = []
    while len(pts) < 24:
        p = [F(rng.randint(-7, 7), rng.randint(1, 5)) for _ in range(4)]
        if any(p): pts.append((p, [F(1), F(4, 9), F(9)][len(pts) % 3]))
    ok_sd = True; ok_cf = True; ok_D = True; ok_den = True; ok_sd4 = True; ok_D4 = True; dens = set(); FLD = []
    for (p, rho2) in pts:
        A, Q0 = bpst_A(p, rho2)
        with trunc(4, xdeg=DEG):
            Fc = G3.curvature(A); SF = [H.star_comps(x, EUC) for x in Fc]; DSF = G3.D_bivector(A, SF)
            den = G3.wedge_sum([(1, Fc[a], Fc[a]) for a in range(3)])
        ok_sd &= all(not deg_le(Fm.add(Fc[a], SF[a], -1), 1) for a in range(3)) and any(deg_le(x, 1) for x in Fc)
        ok_cf &= all(at0(Fc[a].get((1 << m) | (1 << v), {}), NV) == -4 * eta[a][m][v] * rho2 / Q0 ** 2 for a in range(3) for m in range(4) for v in range(m + 1, 4))
        ok_D &= all(not at0f(x) for x in DSF)
        c0 = at0(den.get(FULL, {}), NV); dens.add(c0 * Q0 ** 4 / rho2 ** 2)
        if S4 is None: ok_sd4 = ok_D4 = False
        else:
            A4 = embed(A, S4, 6)
            with trunc(4, xdeg=DEG):
                F4 = G4.curvature(A4); SF4 = [H.star_comps(x, EUC) for x in F4]; D4 = G4.D_bivector(A4, SF4)
            ok_sd4 &= all(not deg_le(Fm.add(F4[q], SF4[q], -1), 1) for q in range(6)) and all(not deg_le(Fm.add(F4[q], embed([x for x in Fc], S4, 6)[q], -1), 1) for q in range(6))
            ok_D4 &= all(not at0f(x) for x in D4)
        FLD.append((p, rho2, A, Fc))
    chk('bit', ok_sd, 'F = *F on every coefficient of degree <= 1 of the jets (bit-rule star, Euclidean), %d rational points, rho^2 in {1, 4/9, 9}' % len(pts))
    chk('bit', ok_cf, 'F^a_mn at the point = -4 eta^a_mn rho^2/(x^2 + rho^2)^2 exactly, all 18 components, %d points' % len(pts))
    chk('bit', ok_D, 'D*F = 0 at the point (D_bivector of the engine), %d points: the BPST field solves the Yang-Mills equation' % len(pts))
    chk('bit', ok_sd4 and ok_D4, 'so(4): the same field on the ideal S_a (an so(4) connection in one su(2) factor): its curvature is Sum F^a S_a, self-dual on the degree <= 1 jets, D*F = 0 at the %d points' % len(pts))
    chk('bit', dens == {F(96)}, 'density: Sum_a F^a ^ F^a = c dx^1234 with c (x^2 + rho^2)^4 / rho^4 = %s at every point (= (1/2) Sum F^a_mn F~^a_mn)' % sorted(dens))
    # exact instanton number: the radial integral by its antiderivative, in fractions
    nums = set()
    for rho2 in (F(1), F(4, 9), F(9)):
        a_ = rho2; prim = lambda u: (-F(1, 2) / (u + a_) ** 2 + a_ / (3 * (u + a_) ** 3)) if u is not None else F(0)     # antiderivative of (u+a)^-3 - a (u+a)^-4, -> 0 at infinity
        I = F(1, 2) * (F(0) - prim(F(0)))                                      # Int_0^inf r^3 (r^2 + a)^-4 dr = (1/2) Int_0^inf u (u + a)^-4 du
        nums.add((I == 1 / (12 * a_ ** 2), F(96) * a_ ** 2 * I * 2 / 16))
    chk('bit', nums == {(True, F(1))}, 'instanton number (1/(16 pi^2)) Int Sum F^a ^ F^a = 96 rho^4 * 2 pi^2 * Int_0^inf r^3 (r^2 + rho^2)^-4 dr / (16 pi^2) with the radial integral = 1/(12 rho^4) exactly: %s (pi^2 cancels; three rho)' % sorted(nums))
    tick('part 1')

    # ------------------------------------------------------------------ 1 [std]
    head('1 [std]. numpy: closed forms and five-point differences, scipy quadrature')
    def A_num(x, rho2, bar=False, sgn=1):
        e_ = np.array([[[float(v) for v in r] for r in M] for M in eta_thooft(bar)]); return 2 * np.einsum('amn,n->am', e_, x) / (x @ x + sgn * rho2)
    def F_num(x, rho2, h=1e-3, Af=A_num):
        dA = np.zeros((3, 4, 4))
        for m in range(4):
            u = np.zeros(4); u[m] = h; dA[:, m, :] = (-Af(x + 2 * u, rho2) + 8 * Af(x + u, rho2) - 8 * Af(x - u, rho2) + Af(x - 2 * u, rho2)) / (12 * h)
        Fv = dA - np.transpose(dA, (0, 2, 1)); Av = Af(x, rho2)
        for a in range(3):
            for b in range(3):
                for c in range(3):
                    if eps3(a, b, c): Fv[a] += eps3(a, b, c) * np.outer(Av[b], Av[c])
        return Fv
    EPS = np.zeros((4, 4, 4, 4))
    for pp in itertools.permutations(range(4)): EPS[pp] = H.perm_sign(pp)
    worst_cf = 0.0; worst_sd = 0.0; worst_D = 0.0; worst_bs = 0.0
    for (p, rho2, A, Fc) in FLD[:8]:
        x = np.array([float(v) for v in p]); r2 = float(rho2); Fv = F_num(x, r2)
        cf = -4 * E_np * r2 / (x @ x + r2) ** 2; worst_cf = max(worst_cf, np.max(np.abs(Fv - cf)))
        worst_sd = max(worst_sd, np.max(np.abs(Fv - 0.5 * np.einsum('mnrs,ars->amn', EPS, Fv))))
        bit = np.array([[[float(at0(Fc[a].get((1 << min(m, v)) | (1 << max(m, v)), {}), NV)) * (1 if m < v else -1) if m != v else 0.0 for v in range(4)] for m in range(4)] for a in range(3)])
        worst_bs = max(worst_bs, np.max(np.abs(bit - cf)))
        h = 1e-3; DF = np.zeros((3, 4)); Av = A_num(x, r2)
        for m in range(4):
            u = np.zeros(4); u[m] = h; DF += ((-F_num(x + 2 * u, r2) + 8 * F_num(x + u, r2) - 8 * F_num(x - u, r2) + F_num(x - 2 * u, r2)) / (12 * h))[:, m, :]
        Fv0 = F_num(x, r2)
        for a in range(3):
            for b in range(3):
                for c in range(3):
                    if eps3(a, b, c): DF[a] += eps3(a, b, c) * np.einsum('m,mn->n', Av[b], Fv0[c])
        worst_D = max(worst_D, np.max(np.abs(DF)))
    chk('std', worst_cf < 1e-7 and worst_sd < 1e-7 and worst_D < 1e-5, 'numpy, 8 points: F from five-point differences of the closed-form A plus eps A A = the closed form (%.1e), F = *F (%.1e), D_mu F_mu nu = 0 by differences (%.1e)' % (worst_cf, worst_sd, worst_D))
    chk('bit==std', worst_bs < 1e-12, 'the engine\'s F at the points = the numpy closed form (max deviation %.1e)' % worst_bs)
    rad = [integrate.quad(lambda r, a=a: r ** 3 / (r * r + a) ** 4, 0, np.inf, epsabs=1e-14, epsrel=1e-13)[0] for a in (1.0, 4 / 9, 9.0)]
    vol3 = integrate.quad(lambda t: math.sin(t) ** 2, 0, math.pi)[0] * integrate.quad(math.sin, 0, math.pi)[0] * 2 * math.pi
    numq = [96 * a * a * I_ * vol3 / (16 * math.pi ** 2) for a, I_ in zip((1.0, 4 / 9, 9.0), rad)]
    chk('std', abs(vol3 - 2 * math.pi ** 2) < 1e-12 and all(abs(v - 1) < 1e-9 for v in numq), 'scipy: vol(S^3) = %.12f = 2 pi^2, and the instanton number by quadrature = %s' % (vol3, ['%.12f' % v for v in numq]))
    tick('part 1 std')

    # ------------------------------------------------------------------ 2. Wu-Yang
    head('2. Wu-Yang monopole, static, signature (+,-,-,-): D*F = 0 away from the origin, F = sigma eps x_a x_k / r^4, Sum B^a B^a = 1/r^4')
    rng = random.Random(77); wpts = []
    while len(wpts) < 20:
        p = [F(rng.randint(-5, 5), 3)] + [F(rng.randint(-7, 7), rng.randint(1, 4)) for _ in range(3)]
        if any(p[1:]): wpts.append(p)
    ok_wD = True; sig = set(); ok_B = True; WY = []
    for p in wpts:
        A, R2 = wuyang_A(p)
        with trunc(4, xdeg=DEG):
            Fc = G3.curvature(A); SF = [H.star_comps(x, LOR) for x in Fc]; DSF = G3.D_bivector(A, SF)
        ok_wD &= all(not at0f(x) for x in DSF) and any(at0f(x) for x in SF)
        xs = p[1:]
        for a in range(3):
            for i in range(3):
                for j in range(i + 1, 3):
                    val = at0(Fc[a].get((1 << (i + 1)) | (1 << (j + 1)), {}), NV); k = 3 - i - j
                    ref = eps3(i, j, k) * xs[a] * xs[k] / R2 ** 2
                    if ref != 0: sig.add(val / ref)
                    elif val != 0: sig.add(None)
            ok_wD &= all(at0(Fc[a].get(1 | (1 << i), {}), NV) == 0 for i in range(1, 4))
        Bv = [[sum(F(eps3(i, j, k), 2) * at0(Fc[a].get((1 << (min(j, k) + 1)) | (1 << (max(j, k) + 1)), {}), NV) * (1 if j < k else -1) for j in range(3) for k in range(3) if j != k) for i in range(3)] for a in range(3)]
        ok_B &= sum(Bv[a][i] ** 2 for a in range(3) for i in range(3)) == 1 / R2 ** 2
        WY.append((p, A, Fc, R2))
    chk('bit', ok_wD, 'D*F = 0 at %d rational points (x != 0), Minkowski bit-rule star; F^a_0i = 0 (static, purely magnetic); *F != 0' % len(wpts))
    chk('bit', len(sig) == 1 and None not in sig, 'F^a_ij = sigma eps_ijk x_a x_k / r^4 at every point and component with ONE sigma = %s: the hedgehog B^a_i = -sigma x_a x_i / r^4 in colour and space' % sorted(sig, key=str))
    chk('bit', ok_B, 'Sum_a B^a_i B^a_i = 1/r^4 exactly at every point (B^a_i = (1/2) eps_ijk F^a_jk): the field strength of an abelian monopole of unit charge (= 1/g, g = 1 in this normalisation)')
    def Awy(x): r2 = x[1:] @ x[1:]; return np.array([[0.0] + [sum(eps3(a, i, j) * x[j + 1] for j in range(3)) / r2 for i in range(3)] for a in range(3)])
    worst = 0.0; worstB = 0.0
    for (p, A, Fc, R2) in WY[:6]:
        x = np.array([float(v) for v in p]); Fv = F_num(x, 0.0, Af=lambda y, _r: Awy(y))
        Bn = np.array([[0.5 * sum(eps3(i, j, k) * Fv[a, j + 1, k + 1] for j in range(3) for k in range(3)) for i in range(3)] for a in range(3)])
        worstB = max(worstB, abs(np.sum(Bn ** 2) - 1 / float(R2) ** 2))
        h = 1e-3; DF = np.zeros((3, 4)); Av = Awy(x)
        for m in range(1, 4):
            u = np.zeros(4); u[m] = h; FF = lambda y: F_num(y, 0.0, Af=lambda z, _r: Awy(z))
            DF -= ((-FF(x + 2 * u) + 8 * FF(x + u) - 8 * FF(x - u) + FF(x - 2 * u)) / (12 * h))[:, m, :]
        for a in range(3):
            for b in range(3):
                for c in range(3):
                    if eps3(a, b, c): DF[a] -= eps3(a, b, c) * np.einsum('m,mn->n', Av[b, 1:], Fv[c][1:, :])
        worst = max(worst, np.max(np.abs(DF)))
    chk('std', worst < 1e-5 and worstB < 1e-8, 'numpy, 6 points: D^i F_i nu = 0 by differences of the closed-form A (%.1e) and Sum B^a B^a = 1/r^4 (%.1e)' % (worst, worstB))
    tick('part 2')

    # ------------------------------------------------------------------ 3. controls
    head('3. controls: singular gauge (covariance), rho^2 -> -rho^2, anti-instanton, A -> 2A')
    # gauge transformation by U = N/|x|, N = x4 + x1 B01 + x2 B02 + x3 B12 (unit quaternion field of Cl(0,3)): A' = U A U~ + 2 U dU~, F' = U F U~
    sq3 = [-1, -1, -1]; gens = L3.gens
    def mv_mul(Xm, Ym):
        out = {}
        for a_, pa in Xm.items():
            for b_, pb in Ym.items():
                mk, s_ = bmul(a_, b_, sq3); out[mk] = padd(out.get(mk, {}), jmul(pa, pb), s_)
        return {k: v for k, v in out.items() if v}
    ok_cov = True; ok_diff = True; ok_sdg = True; ok_Dg = True
    for (p, rho2, A, Fc) in FLD[:8]:
        X = xs_jet(p); N = {0: X[3], gens[0]: X[0], gens[1]: X[1], gens[2]: X[2]}; Nr = {0: X[3], gens[0]: scale(X[0], -1), gens[1]: scale(X[1], -1), gens[2]: scale(X[2], -1)}
        ix2, x2 = inv_quad_jet(p, F(0))
        Ap = [{} for _ in range(3)]
        for mu in range(4):
            Om = {gens[a]: A[a].get(1 << mu, {}) for a in range(3) if A[a].get(1 << mu)}
            dNr = {k: {kk: v for kk, v in sp_der(q, mu).items()} for k, q in Nr.items()}; dNr = {k: v for k, v in dNr.items() if v}
            T1 = mv_mul(mv_mul(N, Om), Nr); T2 = mv_mul(N, dNr); tot = {}
            for k in set(T1) | set(T2): tot[k] = padd(T1.get(k, {}), T2.get(k, {}), 2)
            ok_diff &= (tot.get(0, {}) == scale(X[mu], 2))                    # scalar part 2 x_mu: cancelled by -2 x.dx/x^2, so A' is bivector-valued
            for a in range(3):
                q = jmul(tot.get(gens[a], {}), ix2)
                if q: Ap[a][1 << mu] = q
        with trunc(4, xdeg=DEG):
            Fp = G3.curvature(Ap); SFp = [H.star_comps(x, EUC) for x in Fp]; DFp = G3.D_bivector(Ap, SFp)
        x0 = [at0(x, NV) for x in X]; xx = sum(v * v for v in x0)
        for mk in range(16):
            if popc(mk) != 2: continue
            Fm0 = {gens[a]: const(NV, at0(Fc[a].get(mk, {}), NV)) for a in range(3) if at0(Fc[a].get(mk, {}), NV)}
            N0 = {k: const(NV, at0(v, NV)) for k, v in N.items() if at0(v, NV)}; Nr0 = {k: const(NV, at0(v, NV)) for k, v in Nr.items() if at0(v, NV)}
            rot = mv_mul(mv_mul(N0, Fm0), Nr0)
            ok_cov &= all(at0(Fp[a].get(mk, {}), NV) == at0(rot.get(gens[a], {}), NV) / xx for a in range(3)) and not at0(rot.get(0, {}), NV)
        ok_diff &= any(deg_le(Fm.add(Ap[a], A[a], -1), 0) for a in range(3))
        ok_sdg &= all(not deg_le(Fm.add(Fp[a], SFp[a], -1), 1) for a in range(3)); ok_Dg &= all(not at0f(x) for x in DFp)
    chk('ctl', ok_cov and ok_diff, 'singular-gauge control: A\' = U A U~ + 2 U dU~ with U = (x4 + x1 B01 + x2 B02 + x3 B12)/|x| (rational: N A N~/x^2; the scalar part 2 x_mu of N A N~ + 2 N dN~ is cancelled exactly) differs from A, and the engine\'s F of A\' equals U F U~ at 8 points (curvature covariance under a finite gauge transformation)')
    chk('bit', ok_sdg and ok_Dg, 'A\' is again self-dual (degree <= 1 jets) with D*F = 0 at the 8 points')
    # rho^2 -> -rho^2
    ok_loc = True
    for (p, rho2, _, _) in FLD[:8]:
        if sum(v * v for v in p) == rho2: continue
        A, Q0 = bpst_A(p, rho2, sgn=-1)
        with trunc(4, xdeg=DEG):
            Fc = G3.curvature(A); SF = [H.star_comps(x, EUC) for x in Fc]; DSF = G3.D_bivector(A, SF)
        ok_loc &= all(not deg_le(Fm.add(Fc[a], SF[a], -1), 1) for a in range(3)) and all(not at0f(x) for x in DSF)
    parts = [integrate.quad(lambda r: r ** 3 / (r * r - 1.0) ** 4, 0, 1 - d, limit=200)[0] for d in (1e-1, 1e-2)]
    chk('ctl', ok_loc and parts[1] / parts[0] > 500, 'control rho^2 -> -rho^2: the local equations still hold at the points off |x| = rho (F = *F, D*F = 0), but Int_0^(rho(1-d)) r^3 (r^2 - rho^2)^-4 dr grows like d^-3 (d = 0.1, 0.01: ratio %.0f): no finite action, no instanton number' % (parts[1] / parts[0]))
    # anti-instanton and 2A
    ok_anti = True; ok_2A = True; dens_a = set()
    for (p, rho2, _, _) in FLD[:8]:
        A, Q0 = bpst_A(p, rho2, bar=True); A2, _ = bpst_A(p, rho2, scale_=2)
        with trunc(4, xdeg=DEG):
            Fa = G3.curvature(A); SFa = [H.star_comps(x, EUC) for x in Fa]; dena = G3.wedge_sum([(1, Fa[a], Fa[a]) for a in range(3)])
            F2 = G3.curvature(A2); SF2 = [H.star_comps(x, EUC) for x in F2]; D2 = G3.D_bivector(A2, SF2)
        ok_anti &= all(not deg_le(Fm.add(Fa[a], SFa[a]), 1) for a in range(3)) and any(deg_le(Fm.add(Fa[a], SFa[a], -1), 1) for a in range(3))
        dens_a.add(at0(dena.get(FULL, {}), NV) * Q0 ** 4 / rho2 ** 2)
        ok_2A &= any(deg_le(Fm.add(F2[a], SF2[a], -1), 1) for a in range(3)) and any(deg_le(Fm.add(F2[a], SF2[a]), 1) for a in range(3)) and any(at0f(x) for x in D2)
    chk('ctl', ok_anti and dens_a == {F(-96)}, 'control anti-instanton (eta-bar): F = -*F (the self-duality check fails), density c (x^2+rho^2)^4/rho^4 = %s: instanton number -1' % sorted(dens_a))
    chk('ctl', ok_2A, 'control A -> 2A (BPST): neither self-dual nor anti-self-dual and D*F != 0 at the points: not a solution')
    ok_vac = True; ok_w2 = True
    for p in wpts[:6]:
        A2, _ = wuyang_A(p, 2)
        with trunc(4, xdeg=DEG): F2 = G3.curvature(A2)
        ok_vac &= all(not deg_le(x, 1) for x in F2)
        for lam_ in (F(1, 2), F(3)):
            Al, _ = wuyang_A(p, lam_)
            with trunc(4, xdeg=DEG):
                Fl = G3.curvature(Al); Dl = G3.D_bivector(Al, [H.star_comps(x, LOR) for x in Fl])
            ok_w2 &= any(at0f(x) for x in Dl)
    chk('bit', ok_vac, 'the same ansatz with 2A (lambda eps_aij x_j/r^2, lambda = 2) has F = 0 on the degree <= 1 jets at 6 points: a pure gauge (the vacuum in the hedgehog gauge), so A -> 2A is no control here')
    chk('ctl', ok_w2, 'control lambda eps_aij x_j/r^2 with lambda = 1/2 and 3 (Wu-Yang): D*F != 0 at 6 points (lambda = 1 is the Wu-Yang field, lambda = 2 a pure gauge, lambda = 0 the vacuum)')
    tick('part 3')
    finish('YM-SOL')

if __name__ == '__main__': main()
