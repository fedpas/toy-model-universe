#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-STRESS.  The Maxwell stress T(a) = -1/2 F a F: its divergence is J.F = -F.J when grad F = J, and conservation of the total gives the Lorentz force density F.J.   python3 gm_maxwell_stress.py

 Derivation: D = sum_mu d_mu T(g^mu) = -(1/2)(F' grad' F + F grad F) with F' grad' = sum_mu (d_mu F) g^mu = -(grad F)~. If grad F = J (a vector, grad^F = 0): D = (1/2)(J F - F J) = J.F = -F.J,
 with F.J = <F J>_1 = (1/2)(F J - J F). For any bivector field, grad F = J + K (K = grad^F, a trivector): D = J.F - (1/2)(K F + F K). Conservation of the total, D + D_sources = 0,
 gives the force density on the sources, F.J (f^nu = F^{nu lambda} J_lambda = (E.J, rho E + J x B)).
 [bit]  Cl(1,3), time squares +1, the bit rule of the page script maxwell_selfcheck.py (bprod) on exact polynomial fields: random potentials A (every monomial of degree <= 3, integers uniform
        in -50..50: the strong sampler of a2b_strong_sampling.py; three fields), F = <grad A>_2, grad = sum_mu g^mu d_mu: grad^F = 0, J = grad F, and D = J.F exactly; the same with the
        page's own gradient sum_a e_a d_a; the general formula with K on random bivector fields.
 [std]  index calculus, own polynomial code: F_{mu nu} = d_mu A_nu - d_nu A_mu, J^nu = d_mu F^{mu nu}, T^{mu nu} = -(F^{mu a} F^nu_a - (1/4) eta^{mu nu} F_{ab} F^{ab}) (the textbook
        form F^{mu a} F^nu_a - (1/4) eta F^2 belongs to the signature (-,+,+,+); in (+,-,-,-) its negative has T^{00} = (E^2 + B^2)/2), d_mu T^{mu nu} = -F^{nu lambda} J_lambda exactly; numpy central differences of T at points as a second look; f = (E.J, rho E + J x B).
 [bit==std] F^{mu nu} = the blade coefficients of F; g^mu.T(g^nu) = T^{mu nu}; D^nu = d_mu T^{mu nu}; (F.J)^nu = f^nu.
 Bound: the residual D - J.F has degree 2 in the sampled coefficients; a false identity passes the three fields with probability at most (2/101)^3 = 7.8e-6.
 Controls: T = +1/2 F a F; T = F a F; a bivector field with grad^F != 0 and J = <grad F>_1; the trace term -1/2 in the textbook tensor.
 Scope: polynomial fields of degree 3 in A (2 in F), three seeds, all coefficients of the identities (exact)."""
import os, sys, random, itertools, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import maxwell_selfcheck as MX                                      # the page script: bit rule bprod (p = 1: generator 0 squares +1, 1..3 square -1), polynomials, gradient
from a2b_strong_sampling import s_poly
import numpy as np

N = 4; ETA = [1, -1, -1, -1]; R50 = 50; DEG = 3; SEEDS = (39, 1039, 2039)
# ------------------------------------------------------------------------------------------------ [bit] multivectors with polynomial coefficients, the page's bit rule
def gp(A, B):
    r = {}
    for a, pa in A.items():
        for b, pb in B.items():
            m, s = MX.bprod(a, b, 1); r[m] = padd(r.get(m, {}), pm(pa, pb), s)
            if not r[m]: del r[m]
    return r
def mvadd(A, B, c=1):
    r = dict(A)
    for m, p in B.items():
        x = padd(r.get(m, {}), p, c)
        if x: r[m] = x
        else: r.pop(m, None)
    return r
def mvscale(A, c): return {m: scale(p, c) for m, p in A.items()} if c != 0 else {}
def part(A, k): return {m: p for m, p in A.items() if popc(m) == k}
def grad(X, recip=True):
    """sum_mu g^mu d_mu X (recip = True: g^mu = eta^{mu mu} g_mu) or the page's sum_a e_a d_a X (MX.nabla)"""
    if not recip: return MX.nabla(X, N, 1)
    r = {}
    for m, p in X.items():
        for mu in range(N):
            dp = pder(p, mu)
            if not dp: continue
            mm, s = MX.bprod(1 << mu, m, 1); r = mvadd(r, {mm: dp}, s * ETA[mu])
    return r
def stress(Fb, a_mask, coef=F(-1, 2)): return mvscale(gp(gp(Fb, {a_mask: const(N, 1)}), Fb), coef)
def divergence(Fb, recip=True, coef=F(-1, 2)):
    """D = sum_mu d_mu T(g^mu) (recip) or sum_a d_a T(e_a) (the page's pairing)"""
    D = {}
    for mu in range(N):
        T = mvscale(stress(Fb, 1 << mu, coef), ETA[mu] if recip else 1)
        D = mvadd(D, {m: pder(p, mu) for m, p in T.items() if pder(p, mu)})
    return D
def dot_JF(J, Fb): return mvscale(mvadd(gp(J, Fb), gp(Fb, J), -1), F(1, 2))         # J.F = (1/2)(J F - F J) = -F.J

# ------------------------------------------------------------------------------------------------ [std] index calculus (own code: b1lib's sp_* helpers, no bit rule)
def sp(a, b): return sp_mul(a, b, 99, N)
def std_fields(Aup, trace=F(-1, 4), sgn=-1):
    """T^{mu nu} = sgn (F^{mu a} F^nu_a + trace eta^{mu nu} F_{ab} F^{ab}); the form with sgn = +1 is the one of the signature (-,+,+,+); in (+,-,-,-) the tensor with T^{00} = (E^2 + B^2)/2 has sgn = -1"""
    Adn = [scale(Aup[m], ETA[m]) for m in range(N)]
    Fdn = {(m, n): sp_add(sp_der(Adn[n], m), sp_der(Adn[m], n), -1) for m in range(N) for n in range(N)}
    Fup = {(m, n): scale(Fdn[(m, n)], ETA[m] * ETA[n]) for m in range(N) for n in range(N)}
    Jup = [lin(*[(F(1), sp_der(Fup[(m, n)], m)) for m in range(N)]) for n in range(N)]
    F2 = lin(*[(F(1), sp(Fdn[(a, b)], Fup[(a, b)])) for a in range(N) for b in range(N)])
    T = {}
    for m in range(N):
        for n in range(N):
            t = lin(*[(F(ETA[a]), sp(Fup[(m, a)], Fup[(n, a)])) for a in range(N)])
            if m == n: t = sp_add(t, F2, trace * ETA[m])
            T[(m, n)] = scale(t, sgn)
    div = [lin(*[(F(1), sp_der(T[(m, n)], m)) for m in range(N)]) for n in range(N)]
    f = [lin(*[(F(ETA[l]), sp(Fup[(n, l)], Jup[l])) for l in range(N)]) for n in range(N)]
    return Fup, Jup, T, div, f
def evalp(p, x): return sum(float(v) * math.prod(x[i] ** k for i, k in enumerate(ex)) for ex, v in p.items())

def main():
    bound = (F(2, 2 * R50 + 1)) ** len(SEEDS)
    head('(1) random exact fields: A of degree %d (strong sampler, integers -%d..%d), F = <grad A>_2, J = grad F; D = sum_mu d_mu T(g^mu) against J.F [bit]; textbook tensor [std]' % (DEG, R50, R50))
    allb = True
    for sd in SEEDS:
        rng = random.Random(sd); Aup = [s_poly(rng, N, DEG, R50) for _ in range(N)]
        A = {1 << m: Aup[m] for m in range(N) if Aup[m]}
        gA = grad(A); Fb = part(gA, 2); gF = grad(Fb); K = part(gF, 3); J = part(gF, 1)
        D = divergence(Fb); JF = dot_JF(J, Fb)
        ok_id = not K and set(popc(m) for m in gF) <= {1} and set(popc(m) for m in D) <= {1} and mvadd(D, JF, -1) == {}
        chk('bit', ok_id, 'seed %d: grad^F = 0 exactly, J = grad F is a vector, and sum_mu d_mu T(g^mu) = J.F = -F.J as polynomials (every coefficient; %d monomials in D)' % (sd, sum(len(p) for p in D.values())))
        Fp = part(grad(A, recip=False), 2); Dp = divergence(Fp, recip=False); Jp = grad(Fp, recip=False); JFp = dot_JF(part(Jp, 1), Fp)
        chk('bit', not part(Jp, 3) and mvadd(Dp, JFp, -1) == {}, 'seed %d: the same with the page\'s gradient sum_a e_a d_a and D = sum_a d_a T(e_a) (maxwell_selfcheck.nabla)' % sd)
        # [std]
        Fup, Jup, T, div, f = std_fields(Aup)
        ok_std = all(sp_add(div[n], f[n]) == {} for n in range(N))
        chk('std', ok_std, 'seed %d: d_mu T^{mu nu} = -F^{nu lambda} J_lambda for nu = 0..3 (exact polynomials, index calculus)' % sd)
        # [bit==std]
        okF = all(Fb.get((1 << m) | (1 << n), {}) == Fup[(m, n)] for m in range(N) for n in range(m + 1, N))
        okT = True
        for n in range(N):
            Tn = mvscale(stress(Fb, 1 << n), ETA[n])                          # T(g^n)
            okT &= all(Tn.get(1 << m, {}) == T[(m, n)] for m in range(N))
        okD = all(D.get(1 << n, {}) == div[n] for n in range(N)) and all(mvscale(dot_JF(Fb, J), 1).get(1 << n, {}) == f[n] for n in range(N))
        chk('bit==std', okF and okT and okD, 'seed %d: F^{mu nu} = blade coefficients of F; g^mu.T(g^nu) = T^{mu nu} (16 components, T^{00} = (E^2 + B^2)/2); D^nu = d_mu T^{mu nu}; (F.J)^nu = F^{nu lambda} J_lambda' % sd)
        # the 3-vector reading of the force density
        Ev = [scale(Fup[(i, 0)], 1) for i in (1, 2, 3)]; Bv = [scale(Fup[(2, 3)], -1), scale(Fup[(3, 1)], -1), scale(Fup[(1, 2)], -1)]
        rho = Jup[0]; Jv = [Jup[i] for i in (1, 2, 3)]
        f0 = lin(*[(F(1), sp(Ev[i], Jv[i])) for i in range(3)])
        cross = [sp_add(sp(Jv[1], Bv[2]), sp(Jv[2], Bv[1]), -1), sp_add(sp(Jv[2], Bv[0]), sp(Jv[0], Bv[2]), -1), sp_add(sp(Jv[0], Bv[1]), sp(Jv[1], Bv[0]), -1)]
        fi = [sp_add(sp(rho, Ev[i]), cross[i]) for i in range(3)]
        E2B2 = lin(*([(F(1, 2), sp(Ev[i], Ev[i])) for i in range(3)] + [(F(1, 2), sp(Bv[i], Bv[i])) for i in range(3)]))
        _, _, Tplus, divplus, _ = std_fields(Aup, sgn=1)
        chk('std', T[(0, 0)] == E2B2 and all(sp_add(divplus[n], f[n], -1) == {} for n in range(N)), 'seed %d: T^{00} = (E^2 + B^2)/2 for the sign -1; the (-,+,+,+) form F^{mu a} F^nu_a - (1/4) eta F^2 read in (+,-,-,-) has divergence +f^nu' % sd)
        chk('std', f0 == f[0] and all(fi[i] == f[i + 1] for i in range(3)), 'seed %d: f = F^{nu lambda} J_lambda = (E.J, rho E + J x B) with E^i = F^{i0}, B^k = -(1/2) eps_kij F^{ij}, rho = J^0' % sd)
        # numpy finite differences of T (second look)
        x0 = [0.3, -0.2, 0.5, 0.1]; h = 1e-3; okfd = True
        for n in range(N):
            num = 0.0
            for m in range(N):
                xp = list(x0); xm = list(x0); xp[m] += h; xm[m] -= h
                xp2 = list(x0); xm2 = list(x0); xp2[m] += 2 * h; xm2[m] -= 2 * h
                num += (-evalp(T[(m, n)], xp2) + 8 * evalp(T[(m, n)], xp) - 8 * evalp(T[(m, n)], xm) + evalp(T[(m, n)], xm2)) / (12 * h)
            ex = -evalp(f[n], x0); okfd &= abs(num - ex) <= 1e-6 * max(1.0, abs(ex))
        chk('std', okfd, 'seed %d: five-point differences of T^{mu nu} at x = (0.3, -0.2, 0.5, 0.1) give d_mu T^{mu nu} = -f^nu to 1e-6 (relative)' % sd)
        allb &= ok_id
        # controls
        chk('ctl', mvadd(divergence(Fb, coef=F(1, 2)), JF, -1) != {}, 'seed %d: T = +1/2 F a F (wrong sign): the divergence is not J.F (it is -J.F)' % sd)
        chk('ctl', mvadd(divergence(Fb, coef=F(1)), JF, -1) != {}, 'seed %d: T = F a F (the factor -1/2 dropped): the divergence is not J.F (it is -2 J.F)' % sd)
        _, _, _, div_bad, f_bad = std_fields(Aup, trace=F(-1, 2))
        chk('ctl', any(sp_add(div_bad[n], f_bad[n]) != {} for n in range(N)), 'seed %d: the textbook tensor with -1/2 eta F^2 in place of -1/4: d_mu T^{mu nu} != -f^nu' % sd)
    print('    failure bound for a false identity on the three fields: (2/101)^3 = %.1e' % float(bound))
    head('(2) a bivector field that is not closed: grad F = J + K with K = grad^F != 0 [bit]')
    for sd in SEEDS:
        rng = random.Random(sd + 7)
        Fr = {(1 << a) | (1 << b): s_poly(rng, N, 2, R50) for a in range(N) for b in range(a + 1, N)}
        gF = grad(Fr); J = part(gF, 1); K = part(gF, 3); D = divergence(Fr); JF = dot_JF(J, Fr)
        gen = mvadd(JF, mvscale(mvadd(gp(K, Fr), gp(Fr, K)), F(1, 2)), -1)
        chk('bit', bool(K) and mvadd(D, gen, -1) == {}, 'seed %d: D = J.F - (1/2)(K F + F K) for a random bivector field of degree 2 (the derivation before grad^F = 0 is used)' % (sd + 7))
        chk('ctl', mvadd(D, JF, -1) != {}, 'seed %d: with grad^F != 0 and J = <grad F>_1 the divergence is not J.F' % (sd + 7))
    head('(3) reading')
    print('    sum_mu d_mu T(g^mu) = J.F = -F.J: the field loses energy-momentum at the rate F.J, and conservation of the total gives the force density F.J = (E.J, rho E + J x B) on the sources.'
          '\n    The candidate prints the divergence as F.J; with T(a) = -1/2 F a F, grad F = J and F.J = <FJ>_1 the computed divergence is J.F = -F.J (sign of the convention).')

if __name__ == '__main__':
    main(); finish('GM-STRESS')
