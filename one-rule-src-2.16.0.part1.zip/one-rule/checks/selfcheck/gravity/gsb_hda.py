#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSB-HDA.  The signature sign in the bracket of two Hamiltonian constraints, d = 2, exact on polynomial data.   python3 gsb_hda.py [--fault EPS|POT]

Phase space: a spatial metric q_ij(x) and its momentum pi^ij(x) on R^2 (variables Q = (q_11, q_12, q_22), P = (pi^11, 2 pi^12, pi^22),
{Q_A(x), P^B(y)} = delta_A^B delta(x - y)).  Constraints, with s the square of the time generator of the frame algebra Cl(s, +, +) (bit rule):
    H = -s (1/sqrt q)(pi^ij pi_ij - pi^2) - sqrt q R(q),        H_k = -2 q_kj D_i pi^ij        (d = 2: pi^2 has the coefficient 1/(d-1) = 1).
For s = -1 (Lorentzian) and s = +1 (Euclidean) H is the ADM Hamiltonian constraint of s N^2 dt^2 + q (dx + N dt)^2 (Legendre transform, recalled);
s = 0 is its zero-signature member (the kinetic term drops).
Statement checked: {H[N], H[M]} = eps H_k[q^kj (N d_j M - M d_j N)] with eps = -s: eps = +1, -1, 0 for s = -1, +1, 0 in these conventions.
How: the functional derivatives are Euler operators computed exactly on series jets at the origin (q(0) = 1, sqrt and inverse as exact series,
variations through a bookkeeping slot: the coefficient of lam in H(Q + lam h e_A) for the basis h in {1, x, y, x^2, xy, y^2} gives the jet
coefficients of the first variation, then E = c - d c' + d d c''); the bracket density B(N) = sum_A [E_QA(N H) E_PA(M H) - E_PA(N H) E_QA(M H)]
and the right-hand side differ by a divergence, which the Euler operator in N removes: E_N(B)(0) = eps E_N(RHS)(0), on four random polynomial
configurations per s (M random, N over the basis), eps fitted on the first and verified on the other three.
[bit]  the products are the engine's polynomial product (gravity_selfcheck.pmul through b1lib.trunc: x-degree and lam-degree cut); s from the bit
       rule: the square of gamma_0 in Cl(s, +, +) (bmul).
[std]  the textbook closed form of the functional derivative of the potential in d = 2, d(int N sqrt q R)/dq_ij = sqrt q (D^i D^j N - q^ij D^2 N)
       (b1lib's sp_ polynomial code), compared with the Euler route at the origin (the factor 2 for q_12).
Scope: d = 2 only (d = 3 not run); four configurations per s, one point each, exact.  The algebra in every dimension is recalled: S. Hojman, K. Kuchar, C. Teitelboim,
Geometrodynamics regained; C. Teitelboim, How commutators of constraints reflect the spacetime structure; M. Henneaux, Geometry of zero signature
space-times.  Controls (--fault puts each into its main check, exit 1): EPS eps = +s (the wrong sign); POT the potential sqrt q R^2 in place of
sqrt q R (the bracket does not close: no eps fits two configurations).  No Grav, Lie or Forms object is built: the engine faults are silent here."""
import os, sys, time, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'EPS', 'POT'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
D = 2; NV = 3; K = 5                               # x-degree kept in the series; slot 2 is the bookkeeping parameter lam
ONE = const(NV, 1); X = [var(NV, 0), var(NV, 1)]; LAM = var(NV, 2)
def mul(a, b): return gs.pmul(a, b)
def mono(a, b): return {(a, b, 0): F(1)}
def series(u, coefs):
    """sum_k coefs[k] u^k for u without constant term (x and lam jointly), truncated by the active trunc"""
    out = {}; pw = ONE
    for c in coefs:
        if c: out = padd(out, pw, c)
        pw = mul(pw, u)
        if not pw: break
    return out
def binom_coefs(alpha, m):
    out = [F(1)]; c = F(1)
    for k in range(1, m):
        c = c * (alpha - k + 1) / k; out.append(c)
    return out
SQRT = binom_coefs(F(1, 2), K + 3); ISQRT = binom_coefs(F(-1, 2), K + 3); INV = [F((-1) ** k) for k in range(K + 3)]
def der(p, i): return pder(p, i)

def hamiltonian(Q, P, s, pot='R'):
    """H = -s kin - sqrt(q) R (or sqrt(q) R^2 for the control) as a series; Q, P lists of 3 series"""
    q = [[Q[0], Q[1]], [Q[1], Q[2]]]; pi = [[P[0], scale(P[1], F(1, 2))], [scale(P[1], F(1, 2)), P[2]]]
    det = padd(mul(Q[0], Q[2]), mul(Q[1], Q[1]), -1); u = padd(det, ONE, -1)
    isq = series(u, ISQRT); sq = series(u, SQRT); idet = series(u, INV)
    qi = [[mul(Q[2], idet), scale(mul(Q[1], idet), -1)], [scale(mul(Q[1], idet), -1), mul(Q[0], idet)]]
    pil = [[lin(*[(F(1), mul(mul(q[i][k], pi[k][l]), q[l][j])) for k in range(D) for l in range(D)]) for j in range(D)] for i in range(D)]
    pipi = lin(*[(F(1), mul(pi[i][j], pil[i][j])) for i in range(D) for j in range(D)]); tr = lin(*[(F(1), mul(q[i][j], pi[i][j])) for i in range(D) for j in range(D)])
    kin = mul(isq, padd(pipi, mul(tr, tr), -1))
    Gam = [[[lin(*[(F(1, 2), mul(qi[k][l], lin((F(1), der(q[l][j], i)), (F(1), der(q[l][i], j)), (F(-1), der(q[i][j], l))))) for l in range(D)]) for j in range(D)] for i in range(D)] for k in range(D)]
    def Rk(k, l, i, j):
        t = padd(der(Gam[k][j][l], i), der(Gam[k][i][l], j), -1)
        for m in range(D): t = padd(t, mul(Gam[k][i][m], Gam[m][j][l])); t = padd(t, mul(Gam[k][j][m], Gam[m][i][l]), -1)
        return t
    Ric = [[lin(*[(F(1), Rk(k, l, k, j)) for k in range(D)]) for j in range(D)] for l in range(D)]
    Rs = lin(*[(F(1), mul(qi[l][j], Ric[l][j])) for l in range(D) for j in range(D)])
    potential = mul(sq, Rs if pot == 'R' else mul(Rs, Rs))
    return lin((F(-s), kin), (F(-1), potential)), dict(q=q, qi=qi, pi=pi, sq=sq)
def lam1(p):
    """the coefficient of lam^1, as a polynomial in x (lam slot set to 0)"""
    return {(k[0], k[1], 0): v for k, v in p.items() if k[2] == 1}
def xcut(p, deg): return {k: v for k, v in p.items() if k[0] + k[1] <= deg and k[2] == 0}
BASIS = [(0, 0), (1, 0), (0, 1), (2, 0), (1, 1), (0, 2)]
def jet_coefs(var_of):
    """var_of(h) -> first variation density for h; returns (c0, [c^0, c^1], {(0,0): c00, (0,1): c01, (1,1): c11})"""
    v = {b: var_of(mono(*b)) for b in BASIS}; c0 = v[(0, 0)]
    c1 = [padd(v[(1, 0)], mul(X[0], c0), -1), padd(v[(0, 1)], mul(X[1], c0), -1)]
    c00 = scale(lin((F(1), v[(2, 0)]), (F(-1), mul(mul(X[0], X[0]), c0)), (F(-2), mul(X[0], c1[0]))), F(1, 2))
    c11 = scale(lin((F(1), v[(0, 2)]), (F(-1), mul(mul(X[1], X[1]), c0)), (F(-2), mul(X[1], c1[1]))), F(1, 2))
    c01 = lin((F(1), v[(1, 1)]), (F(-1), mul(mul(X[0], X[1]), c0)), (F(-1), mul(X[1], c1[0])), (F(-1), mul(X[0], c1[1])))
    return c0, c1, {(0, 0): c00, (0, 1): c01, (1, 1): c11}
def euler(c0, c1, c2, Nf=None):
    """E = N c0 - d_nu (N c^nu) + sum_{nu <= rho} d_nu d_rho (N c^{nu rho})  (N = 1 when Nf is None)"""
    m = (lambda p: mul(Nf, p)) if Nf is not None else (lambda p: p)
    out = m(c0)
    for nu in range(D): out = padd(out, der(m(c1[nu]), nu), -1)
    for (nu, rho), c in c2.items(): out = padd(out, der(der(m(c), nu), rho))
    return out
def rand_poly(rng, deg, lo=-2, hi=2, const_term=True):
    p = {}
    for a in range(deg + 1):
        for b in range(deg + 1 - a):
            if (a, b) == (0, 0) and not const_term: continue
            c = rng.randint(lo, hi)
            if c: p[(a, b, 0)] = F(c)
    return p
def momentum_H(Q, P):
    """H_k = -2 (q_kj d_i pi^ij + Gam_{k,il} pi^il), Gam_{k,il} = (1/2)(d_i q_kl + d_l q_ki - d_k q_il)"""
    q = [[Q[0], Q[1]], [Q[1], Q[2]]]; pi = [[P[0], scale(P[1], F(1, 2))], [scale(P[1], F(1, 2)), P[2]]]; out = []
    for k in range(D):
        t = {}
        for j in range(D):
            for i in range(D): t = padd(t, mul(q[k][j], der(pi[i][j], i)))
        for i in range(D):
            for l in range(D):
                G = lin((F(1, 2), der(q[k][l], i)), (F(1, 2), der(q[k][i], l)), (F(-1, 2), der(q[i][l], k)))
                t = padd(t, mul(G, pi[i][l]))
        out.append(scale(t, -2))
    return out
def config(rng):
    Q = [padd(rand_poly(rng, 6, -2, 2, False), ONE) if A != 1 else rand_poly(rng, 6, -2, 2, False) for A in range(3)]
    P = [rand_poly(rng, 4) for _ in range(3)]; M = rand_poly(rng, 3)
    return Q, P, M
def EN_at0(Bfun):
    """E_N(B)(0) for B linear in the 2-jet of N: extraction over the basis N in BASIS (B evaluated as a series)"""
    c0, c1, c2 = jet_coefs(Bfun)
    return at0(euler(c0, c1, c2), NV)
def bracket_sides(Q, P, M, s, pot='R'):
    with trunc(D, xdeg=K, lam=1):
        H0, parts = hamiltonian(Q, P, s, pot)
        cq = []
        for A in range(3):
            def var_q(h, A=A):
                Q2 = list(Q); Q2[A] = padd(Q[A], mul(LAM, h)); return xcut(lam1(hamiltonian(Q2, P, s, pot)[0]), 4)
            cq.append(jet_coefs(var_q))
        dP = []
        for A in range(3):
            P2 = list(P); P2[A] = padd(P[A], LAM); dP.append(xcut(lam1(hamiltonian(Q, P2, s, pot)[0]), 4))   # E_PA(H) = dH/dP^A (algebraic)
        Hk = momentum_H(Q, P); qi = parts['qi']
    def E4(cA, Nf):
        with trunc(D, xdeg=4, lam=0): return xcut(euler(*cA, Nf=Nf), 2)                  # N c is kept to x-degree 4 before the two derivatives
    with trunc(D, xdeg=2, lam=0):
        EqM = [E4(cq[A], M) for A in range(3)]; EpM = [mul(M, dP[A]) for A in range(3)]
        def B_of(Nf):
            EqN = [E4(cq[A], Nf) for A in range(3)]
            return lin(*[(F(1), mul(EqN[A], EpM[A])) for A in range(3)] + [(F(-1), mul(mul(Nf, dP[A]), EqM[A])) for A in range(3)])
        def R_of(Nf):
            out = {}
            for j in range(D):
                w = padd(mul(Nf, der(M, j)), mul(M, der(Nf, j)), -1)
                for k in range(D): out = padd(out, mul(w, mul(qi[j][k], Hk[k])))
            return out
        return EN_at0(B_of), EN_at0(R_of), cq
def std_potential_check(Q, P, Nf):
    """[std] T^ij = sqrt q (D^i D^j N - q^ij D^2 N) at the origin (q(0) = 1, sqrt q(0) = 1), plain sp_ arithmetic; returns [T^11, 2 T^12, T^22]"""
    n = D; q = [[Q[0], Q[1]], [Q[1], Q[2]]]
    Gam0 = {(m, i, j): F(1, 2) * (at0(sp_der(q[m][j], i), NV) + at0(sp_der(q[m][i], j), NV) - at0(sp_der(q[i][j], m), NV)) for m in range(n) for i in range(n) for j in range(n)}
    dN = [at0(sp_der(Nf, i), NV) for i in range(n)]
    hess = [[at0(sp_der(sp_der(Nf, i), j), NV) - sum(Gam0[(m, i, j)] * dN[m] for m in range(n)) for j in range(n)] for i in range(n)]
    lap = hess[0][0] + hess[1][1]
    T = [[hess[i][j] - (lap if i == j else 0) for j in range(n)] for i in range(n)]
    return [T[0][0], 2 * T[0][1], T[1][1]]

def main():
    head('GSB-HDA: {H[N], H[M]} = eps H_k[q^kj (N d_j M - M d_j N)] in d = 2, s = square of the time generator' + (' [fault %s]' % FAULT if FAULT else ''))
    pot = 'R2' if FAULT == 'POT' else 'R'
    for sname, sq_t in (('Lorentzian', -1), ('Euclidean', 1), ('zero signature', 0)):
        _, s_bit = bmul(1, 1, [sq_t, 1, 1]); s = s_bit if sq_t != 0 else 0
        rng = random.Random(1210 + 7 * (sq_t + 1)); vals = []
        for k in range(4):
            Q, P, M = config(rng); b, r, cq = bracket_sides(Q, P, M, s, pot); vals.append((b, r))
            if k == 0 and sq_t == -1:
                Nf = rand_poly(random.Random(5), 3)
                with trunc(D, xdeg=K, lam=1):
                    cqp = []
                    for A in range(3):
                        def var_q(h, A=A):
                            Q2 = list(Q); Q2[A] = padd(Q[A], mul(LAM, h)); H2, _ = hamiltonian(Q2, P, 0, 'R'); return xcut(lam1(H2), 4)
                        cqp.append(jet_coefs(var_q))
                with trunc(D, xdeg=4, lam=0): Ebit = [-at0(euler(*cqp[A], Nf=Nf), NV) for A in range(3)]      # H(s = 0) = - sqrt q R: E(int N sqrt q R) = -E(N H)
                Estd = std_potential_check(Q, P, Nf)
                chk('bit==std', Ebit == Estd and any(x != 0 for x in Estd), 'the Euler route gives d(int N sqrt q R)/dQ_A at the origin = [std] sqrt q (D^i D^j N - q^ij D^2 N) (components 11, 2 x 12, 22: %s)' % [str(x) for x in Estd])
        b1, r1 = vals[0]
        eps_want = F(s) if FAULT == 'EPS' else F(-s)
        if s != 0:
            eps1 = b1 / r1 if r1 else None
            chk('bit', r1 != 0 and b1 != 0 and eps1 == eps_want and all(b == eps_want * r and r != 0 for b, r in vals[1:]), 's = %d (%s, gamma_0^2 = %d by the bit rule): E_N of the bracket density at the origin = eps E_N of the right-hand side with eps = %s on configuration 1, verified on configurations 2 to 4 (both sides non-zero)' % (s, sname, s, eps1))
        else:
            chk('bit', all(b == 0 for b, r in vals) and all(r != 0 for b, r in vals) and (eps_want == 0), 's = 0 (%s): the bracket of two Hamiltonian constraints vanishes (E_N of the bracket density is 0 on all four configurations while the right-hand side is not): eps = 0' % sname)
        if s != 0 and FAULT is None:
            chk('ctl', b1 != F(s) * r1, 's = %d: the opposite sign eps = %d fails' % (s, s))
        tick(sname)
    if FAULT is None:
        rng = random.Random(1299); vals = []
        for k in range(2):
            Q, P, M = config(rng); b, r, _ = bracket_sides(Q, P, M, -1, 'R2'); vals.append((b, r))
        (b1, r1), (b2, r2) = vals
        chk('ctl', r1 == 0 or r2 == 0 or b1 * r2 != b2 * r1, 's = -1 with the potential sqrt q R^2 in place of sqrt q R: no single eps fits the two configurations (the algebra does not close on H_k)')
        tick('control')
    finish('GSB-HDA')

if __name__ == '__main__': main()
