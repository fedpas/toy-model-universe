#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-LAMAN.  Laman's count against the generic rank of the planar rigidity matrix, on every graph with at most 7 vertices.   python3 gm_laman.py [--fault COUNTONLY|COUNT|NONGENERIC|MC]

 Laman's theorem (recalled): a graph is generically minimally rigid in the plane iff |E| = 2V - 3 and every subgraph on k >= 2 vertices has at most 2k - 3 edges; generically rigid iff it has
 such a spanning subgraph. Rank form (recalled, the (2,3)-sparsity matroid): the generic rank equals the size of a largest edge set in which every k-vertex subset (k >= 2) spans at most
 2k - 3 edges; greedily built. Maxwell-Calladine: with the trivial motions of rank C(d+1,2) = 3 in the kernel, mechanisms - self-stresses = 2V - E - 3.
 Graphs: up to isomorphism, V = 1..7: each class of V - 1 vertices with a new vertex joined in all 2^(V-1) ways, one graph kept per canonical form (the least edge mask over all V!
 relabellings, numpy); edge (i, j), i < j, is bit j(j-1)/2 + i, so the edges of the first V - 1 vertices come first.
 [bit]  per class: gm_cube_framework.rigidity at three random integer positions (coordinates -1000..1000, fixed seed), the exact rank over Q (integer elimination with the rows divided by
        their gcd), the largest of the three; gm_cube_framework.rank_mod_p (exact over F_p, p = 1000003) at the same positions; the greedy (2,3)-sparse edge set (bit masks over the vertex
        subsets); the trivial motions: two translations and the rotation from the engine's h table of Cl(0,2) (= the bit-rule commutator), in the kernel, rank 3.
 [std]  numpy matrix_rank (floats, SVD) at the same positions.
 [bit==std] exact rank = numpy rank on every class and position.
 Controls (--fault puts each into the main check): COUNTONLY rigidity decided by |E| = 2V - 3 alone; COUNT the bound 2k - 2 in place of 2k - 3; NONGENERIC all joints on one line;
 MC d = 2 trivial motions in place of C(d+1,2) = 3 in the index. The double banana (the count is not sufficient in three dimensions) is outside the plane and not run."""
import os, sys, random, itertools, time
from math import comb, gcd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import gm_cube_framework as CF
import numpy as np

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'COUNTONLY', 'COUNT', 'NONGENERIC', 'MC'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
VMAX = 7
GRAPHS_RECALLED = {1: 1, 2: 2, 3: 4, 4: 11, 5: 34, 6: 156, 7: 1044}
LAMAN_RECALLED = {2: 1, 3: 1, 4: 1, 5: 3, 6: 13, 7: 70}            # recalled 1, 1, 3, 13, 70 from V = 3 (V = 4: K4 minus an edge is the only graph with 5 edges)
def eidx(i, j): i, j = min(i, j), max(i, j); return j * (j - 1) // 2 + i
def edges_of(V): return sorted(((i, j) for j in range(V) for i in range(j)), key=lambda e: eidx(*e))
def canonical(masks, V):
    """least edge mask over all relabellings (numpy, chunks of permutations)"""
    E = edges_of(V); nE = len(E); masks = np.array(masks, dtype=np.int64)
    if V <= 1 or nE == 0: return masks
    I = np.array([e[0] for e in E]); J = np.array([e[1] for e in E]); best = None
    perms = np.array(list(itertools.permutations(range(V))), dtype=np.int64)
    for c0 in range(0, len(perms), 252):
        P = perms[c0:c0 + 252]; a, b = P[:, I], P[:, J]; lo, hi = np.minimum(a, b), np.maximum(a, b); pe = hi * (hi - 1) // 2 + lo
        out = np.zeros((len(P), len(masks)), dtype=np.int64)
        for e in range(nE): out |= ((masks[None, :] >> e) & 1) << pe[:, e][:, None]
        m = out.min(axis=0); best = m if best is None else np.minimum(best, m)
    return best
def classes_up_to(Vmax):
    cl = {1: [0]}
    for V in range(2, Vmax + 1):
        base = comb(V - 1, 2); cand = [m | (N << base) for m in cl[V - 1] for N in range(1 << (V - 1))]
        cl[V] = sorted(set(int(x) for x in canonical(cand, V)))
    return cl
def rank_q(M):
    """exact rank over Q of an integer matrix: integer elimination, each new row divided by the gcd of its entries"""
    A = [[int(x) for x in row] for row in M]; rows = len(A); cols = len(A[0]) if rows else 0; r = 0
    for c in range(cols):
        piv = next((i for i in range(r, rows) if A[i][c] != 0), None)
        if piv is None: continue
        A[r], A[piv] = A[piv], A[r]; pr = A[r]
        for i in range(r + 1, rows):
            if A[i][c] != 0:
                a, b = pr[c], A[i][c]; row = [a * x - b * y for x, y in zip(A[i], pr)]; g = 0
                for x in row: g = gcd(g, x)
                A[i] = [x // g for x in row] if g > 1 else row
        r += 1
        if r == rows: break
    return r
def subset_tables(V):
    E = edges_of(V); inside = [0] * (1 << V)
    for S in range(1 << V):
        inside[S] = sum(1 << k for k, (i, j) in enumerate(E) if (S >> i) & 1 and (S >> j) & 1)
    both = [[S for S in range(1 << V) if (S >> i) & 1 and (S >> j) & 1] for (i, j) in E]
    return E, inside, both
def sparse(mask, V, inside, bound):
    return all(bin(mask & inside[S]).count('1') <= bound(bin(S).count('1')) for S in range(1 << V) if bin(S).count('1') >= 2)
def greedy(mask, V, E, inside, both, bound):
    I = 0
    for k in range(len(E)):
        if not (mask >> k) & 1: continue
        J = I | (1 << k)
        if all(bin(J & inside[S]).count('1') <= bound(bin(S).count('1')) for S in both[k]): I = J
    return I

def main():
    head('GM-LAMAN: Laman\'s count and the generic rank, every graph on V <= %d vertices' % VMAX + (' [fault %s]' % FAULT if FAULT else ''))
    W, Wb = CF.rotation_generators(2)
    chk('bit', W == Wb and len(W) == 1 and W[0] != [[0, 0], [0, 0]], 'the rotation generator of the plane from the engine\'s h table of Cl(0,2) = the bit-rule commutator (1/2)[B_01, gamma_b]: %s' % [[str(x) for x in r] for r in W[0]])
    cl = classes_up_to(VMAX); counts = {V: len(cl[V]) for V in cl}
    chk('std', counts == GRAPHS_RECALLED, 'graphs up to isomorphism by canonical forms: %s for V = 1..%d (the recalled numbers of graphs)' % ([counts[V] for V in sorted(counts)], VMAX))
    tick('enumeration')
    bound = (lambda k: 2 * k - 2) if FAULT == 'COUNT' else (lambda k: 2 * k - 3)
    rng = random.Random(35); stats = {}; ok_a = ok_b = ok_c = ok_mc = ok_kern = ok_p = ok_np = True; n_all = 0; bad_c2 = []; flex_count = []; examples = {}
    for V in range(2, VMAX + 1):
        E, inside, both = subset_tables(V); nlam = nrig = 0
        for m in cl[V]:
            bars = [(i, j) for k, (i, j) in enumerate(E) if (m >> k) & 1]; nE = len(bars); n_all += 1
            best = -1; bestP = None
            for t in range(3):
                P = [[rng.randint(-1000, 1000), rng.randint(-1000, 1000)] for _ in range(V)]
                if FAULT == 'NONGENERIC': P = [[u, 0] for u in range(V)]
                Mx = CF.rigidity(P, bars, 2) if bars else np.zeros((0, 2 * V), dtype=np.int64)
                rq = rank_q(Mx) if bars else 0; rp = CF.rank_mod_p(Mx) if bars else 0; rn = int(np.linalg.matrix_rank(Mx.astype(float))) if bars else 0
                ok_p &= (rp == rq); ok_np &= (rn == rq)
                if rq > best: best, bestP, bestM = rq, P, Mx
            g = greedy(m, V, E, inside, both, bound); gsz = bin(g).count('1'); sp = sparse(m, V, inside, bound)
            ok_a &= (best == gsz)
            minimal = (best == nE == 2 * V - 3); laman = (nE == 2 * V - 3 and sp)
            ok_b &= (minimal == ((nE == 2 * V - 3) if FAULT == 'COUNTONLY' else laman))
            rigid = (best == 2 * V - 3); ok_c &= (rigid == (gsz == 2 * V - 3 and sparse(g, V, inside, bound) and bin(g).count('1') == 2 * V - 3))
            nlam += int(laman); nrig += int(rigid)
            if V == 6 and nE == 9 and not sp: flex_count.append(best < 9)
            Tm = CF.trivial_motions(bestP, 2, W)
            kern = all(sum(int(bestM[r, c]) * t[c] for c in range(2 * V)) == 0 for t in Tm for r in range(nE)) if nE else True
            rT = rank_exact(Tm); ok_kern &= kern and rT == 3
            ntriv = 2 if FAULT == 'MC' else 3
            mech = (2 * V - best) - ntriv; ss = nE - best; ok_mc &= (mech - ss == 2 * V - nE - comb(3, 2)) and mech >= 0
            if V == 4 and nE == 6: examples['K4'] = (best, gsz, sparse(m, V, inside, lambda k: 2 * k - 2))
            if V == 3 and nE == 3: examples['triangle'] = bars
        stats[V] = (len(cl[V]), nlam, nrig)
    tick('ranks')
    chk('bit', ok_a, 'every one of the %d graphs with 2 to 7 vertices: the generic rank (exact over Q, the largest at three random integer positions) = the size of the greedy (2,3)-sparse edge set' % n_all)
    chk('bit', ok_b, 'every graph: minimally rigid (rank = |E| = 2V - 3) iff |E| = 2V - 3 and every subgraph on k >= 2 vertices has at most 2k - 3 edges (Laman)')
    chk('bit', ok_c, 'every graph: rigid (rank 2V - 3) iff it contains a spanning Laman subgraph (the greedy set has 2V - 3 edges and is (2,3)-sparse)')
    chk('bit', ok_kern, 'every graph, at its generic position: the two translations and the engine\'s rotation lie in the kernel and have rank 3 = C(d+1,2)')
    chk('bit', ok_mc, 'every graph: mechanisms - self-stresses = (2V - rank - 3) - (E - rank) = 2V - E - C(d+1,2), both sides from the exact rank (Maxwell-Calladine)')
    chk('bit', ok_p, 'gm_cube_framework.rank_mod_p (p = 1000003) = the rank over Q at every position (%d matrices)' % (3 * n_all))
    chk('bit==std', ok_np, 'numpy matrix_rank (floats) = the exact rank at every position (%d matrices)' % (3 * n_all))
    lam_found = {V: stats[V][1] for V in stats}
    print('    per V (graphs, Laman graphs, rigid graphs): %s' % ', '.join('V=%d: %s' % (V, stats[V]) for V in sorted(stats)))
    chk('bit', lam_found == LAMAN_RECALLED, 'Laman (minimally rigid) graphs up to isomorphism: %s for V = 2..%d (the recalled numbers 1, 1, 3, 13, 70 for V = 3..7)' % ([lam_found[V] for V in sorted(lam_found)], VMAX))
    head('the two examples again (unit square) and the controls')
    Psq = [[0, 0], [1, 0], [1, 1], [0, 1]]; sqb = [(0, 1), (1, 2), (2, 3), (0, 3)]; rs = rank_q(CF.rigidity(Psq, sqb, 2)); rb = rank_q(CF.rigidity(Psq, sqb + [(0, 2)], 2))
    chk('bit', rs == 4 and 2 * 4 - rs - 3 == 1 and rb == 5 == 2 * 4 - 3, 'the square: rank 4, one mechanism; the square with one diagonal: rank 5 = 2V - 3, rigid (exact)')
    chk('ctl', len(flex_count) > 0 and all(flex_count), 'V = 6: the %d classes with |E| = 9 = 2V - 3 that fail the subgraph condition are all flexible (rank < 9): the count alone is not enough' % len(flex_count))
    Pk = [[rng.randint(-1000, 1000), rng.randint(-1000, 1000)] for _ in range(6)]; kb = [(i, j) for i in range(4) for j in range(i + 1, 4)] + [(3, 4), (4, 5), (0, 5)]
    rk = rank_q(CF.rigidity(Pk, kb, 2))
    chk('ctl', len(kb) == 9 and rk == 8, 'the example K4 plus a path 3-4-5-0: 9 edges, K4 has 6 > 2*4 - 3 edges, rank %d < 9: flexible' % rk)
    k4 = examples.get('K4')
    chk('ctl', k4 is not None and k4[2] and k4[0] == 5, 'the bound 2k - 2 in place of 2k - 3: K4 (6 edges) passes it, but its generic rank is %s < 6' % (k4[0] if k4 else None))
    tri = examples.get('triangle'); rc = rank_q(CF.rigidity([[0, 0], [1, 0], [2, 0]], tri, 2))
    chk('ctl', rc == 2, 'joints on one line (a special position): the triangle has rank %d < 3; generic positions are needed' % rc)
    Pt = [[rng.randint(-1000, 1000), rng.randint(-1000, 1000)] for _ in range(3)]; Mt = CF.rigidity(Pt, tri, 2)
    shear = CF.trivial_motions(Pt, 2, [[[F(0), F(1)], [F(1), F(0)]]])[2]; rot = CF.trivial_motions(Pt, 2, W)[2]
    inK = lambda t: all(sum(int(Mt[r, c]) * t[c] for c in range(6)) == 0 for r in range(3))
    chk('ctl', inK(rot) and not inK(shear), 'the symmetric generator [[0, 1], [1, 0]] in place of the rotation (a shear, not a rigid motion) is not in the kernel of the triangle; the engine\'s rotation is')
    tick('controls')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GM-LAMAN' + ('-' + FAULT if FAULT else ''))
