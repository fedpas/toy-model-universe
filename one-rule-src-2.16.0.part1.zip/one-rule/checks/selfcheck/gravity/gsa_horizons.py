#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSA-HORIZONS.  Killing horizons on given frames (hypersurface orthogonality, xi^2 = 0, the Kerr ergosurface against the horizon) and the Euclidean
 period 2 pi/kappa of the Schwarzschild and Reissner-Nordstrom sections.   python3 gsa_horizons.py [--fault nonkilling|ergo_radius|half_period|inner_kappa|linear_R]

 Part A (Killing horizons).  Frames: the radial Kerr-Schild class (b1lib.ks_frame_jet): Schwarzschild M = 1, Reissner-Nordstrom f = M/rho - s/rho^2 with
   (M, s) = (2, 3/2) (horizons 3 and 1), Schwarzschild-de Sitter with horizons 1 and 2 (M = 3/7, H2 = 1/7); Kerr M = 5, a = 3 (g2_kerr.kerr_ks_frame_jet,
   horizons r = 9 and 1, Omega_H = 1/30).  Exact 2-jets at rational points on, between, inside and outside the horizons.
   [bit]  xi_flat = sum_a sq_a xi^a e^a (xi^a = i_xi e^a, the bit-rule interior), d xi_flat and xi_flat ^ d xi_flat with the engine's d and wedge (the bit rule
          with null generators), all four components of the 3-form, value and first derivatives at the point; xi^2 as the scalar part of the bit-rule square;
          Killing: L_xi e^a = lam^a_b e^b with lam antisymmetric (f3_killing.lie_frame).
   [std]  xi_mu = g_mu nu xi^nu from the metric components, the 3-form sum over permutations sign(s) xi_s0 d_s1 xi_s2 (plain derivatives); g(xi, xi).
   Kerr: d_t is not hypersurface orthogonal; chi = d_t + Omega_H (x d_y - y d_x) is null and chi ^ d chi = 0 at the horizon points; the ergosurface g_tt = 0,
   r_E = M + sqrt(M^2 - a^2 cos^2 th) (recalled), at rational points of polar angle cos th = 0, 12/17 and 1: r_E = 10, 162/17, 9 against r_+ = 9.
 Part B (Euclidean period).  T(r) = 1 - 2M/r + 2s/r^2 = (r - r+)(r - r-)/r^2: Schwarzschild M = 1, RN (2, 3/2) and (3/2, 1).
   [bit]  kappa from nabla_xi xi = kappa xi at a horizon point of the Lorentzian Kerr-Schild frame (A3 omega, Grav.D_vector), [std] the Christoffel route.
   [std]  the polar chart of the Euclidean (rho, tau) section: rho = int dr/sqrt(T), G = sqrt(T) as an exact series: G^2 = kappa^2 rho^2 Z(kappa rho^2/2), Z(0) = 1;
          a 2-metric d rho^2 + G^2 d tau^2 is smooth at rho = 0 iff G is odd and G'(0) P = 2 pi (recalled), so the period is P = 2 pi/kappa, the cone angle
          kappa P = 2 pi beta (beta of aty_cone_defects).
   [bit]  the Euclidean coframe (frame algebra Cl(4,0)) in the chart (tau, r, t, phi), theta = 2 arctan t: e^0 = sqrt(T) d tau, e^1 = dr/sqrt(T), e^2 = r theta' dt,
          e^3 = r sin theta d phi, exact 2-jets at points where T is a rational square; the engine's Euler 4-form eps_abcd R^ab ^ R^cd; its radial density
          rho_E(r) = E4/(sin theta theta'(t)) fitted exactly by c4/r^4 + c5/r^5 + c6/r^6 (three points) and verified at two more; I = int_{r+}^inf rho_E dr
          exactly; (1/32 pi^2) int E4 = P I/(8 pi).  Found: I = 8 kappa, so the integral is kappa P/pi = 2 beta: chi(R^2 x S^2) = 2 only at P = 2 pi/kappa, and
          2 - 2 beta = (1 - beta) chi(S^2) is the edge-cone defect of Atiyah and LeBrun (recalled) along the bolt.
   [std]  the Christoffel route on the same jets: (R_abcd R^abcd - 4 R_ab R^ab + R^2) sqrt(g) = E4 at every point; the recalled closed form
          48 M^2/r^6 - 96 M Q^2/r^7 + 40 Q^4/r^8 (Q^2 = 2s) for the bracket.
 Controls (each also a --fault NAME that puts the wrong version into a main check and exits 1): nonkilling ((1 + x/7) d_t: hypersurface orthogonal, null on the
   horizon, not Killing), ergo_radius (the point at r = 2M at polar angle 12/17 in place of r_E), half_period (P = pi/kappa), inner_kappa (the period of the
   inner horizon's |kappa| at the outer bolt), linear_R (R = d omega without its quadratic term in the Euler 4-form); also d_t + (1/3) rot_z (Killing, not
   hypersurface orthogonal) and chi with 9/10 Omega_H.
 Scope  values at rational points, n = 4; the radiation and T = kappa/2 pi are recalled (Hawking; Gibbons and Hawking), not computed."""
import os, sys, time, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_kerr as K
import f3_killing as F3
from g2_forms_calc import frame_comps

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'nonkilling', 'ergo_radius', 'half_period', 'inner_kappa', 'linear_R'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
NV = 4; SQ = LORENTZ(4); SQE = [1, 1, 1, 1]
MASKS3 = [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)]
PERM3 = [((0, 1, 2), 1), ((1, 2, 0), 1), ((2, 0, 1), 1), ((1, 0, 2), -1), ((0, 2, 1), -1), ((2, 1, 0), -1)]
def tdeg(p, d): return {k: v for k, v in p.items() if sum(k) <= d}

# ------------------------------------------------------------------------------------------------ Part A helpers
def flat_bit(Gv, e, xi):
    """[bit] xi_flat = sum_a sq_a xi^a e^a (2-jets), xi^a = i_xi e^a by the bit-rule interior"""
    Fm = Gv.Fm; xa = frame_comps(Gv, xi, e); X = {}
    with trunc(4, xdeg=2):
        for a in range(4):
            if xa[a]: X = Fm.add(X, Fm.wedge({0: xa[a]}, e[a]), SQ[a])
    return X, xa
def frob_bit(Gv, e, xi, deg=1):
    """[bit] the 3-form xi_flat ^ d xi_flat (engine d and wedge), components {(mu, nu, rho): poly of degree <= deg}"""
    Fm = Gv.Fm; X, xa = flat_bit(Gv, e, xi)
    with trunc(4, xdeg=2): dX = Fm.d(X)
    with trunc(4, xdeg=deg): W = Fm.wedge(X, dX)
    return {t: tdeg(W.get(sum(1 << i for i in t), {}), deg) for t in MASKS3}, xa
def frob_std(e, xi, deg=1):
    """[std] (xi ^ d xi)_{mu nu rho} = sum over permutations sign(s) xi_s0 d_s1 xi_s2, xi_mu = g_mu nu xi^nu (plain polynomials, no engine)"""
    g = std_metric(e, 4, SQ, NV, 2); xl = [lin(*[(F(1), sp_mul(g[(m, n)], xi[n], 2, 4)) for n in range(4) if xi[n]]) for m in range(4)]
    out = {}
    for t in MASKS3:
        tot = {}
        for perm, sg in PERM3:
            s0, s1, s2 = (t[i] for i in perm); tot = sp_add(tot, sp_mul(xl[s0], sp_der(xl[s2], s1), deg, 4), sg)
        out[t] = tdeg(tot, deg)
    return out, g
def norm_std(g, xi): return sum(at0(g[(m, n)], NV) * at0(xi[m], NV) * at0(xi[n], NV) for m in range(4) for n in range(4))
def zero3(W): return all(not q for q in W.values())
def val3(W): return {t: at0(q, NV) for t, q in W.items()}
def coord(p, i): return var(NV, 0) if i == 0 else lin((F(1), const(NV, p[i - 1])), (F(1), var(NV, i)))
def d_t(): return [const(NV, 1), {}, {}, {}]
def rot_z(p): return [{}, scale(coord(p, 2), -1), coord(p, 1), {}]
def vsum(*terms):
    out = [{} for _ in range(4)]
    for c, v in terms: out = [padd(out[m], v[m], c) for m in range(4)]
    return out
def static_frame(p, rho0, M, s=F(0), H2=F(0)):
    jets = (M / rho0 - s / rho0 ** 2 + H2 * rho0 ** 2 / 2, -M / rho0 ** 2 + 2 * s / rho0 ** 3 + H2 * rho0, 2 * M / rho0 ** 3 - 6 * s / rho0 ** 4 + H2)
    e, E, _ = ks_frame_jet(tuple(p), rho0, *jets, nv=NV); return e, E, 1 - 2 * jets[0]
def engine_mixed(Gv, S, e, c):
    """[bit] (G - 3c delta)^mu_nu in the coordinates from the engine's E_a(c) (as gsa_birkhoff)"""
    e0, E0, det = E0_of(e, 4, NV); om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, c)
    Mf = mixed_from_components(comp, e0, det, 4, s=-1)
    return [[sum(E0[m][b] * Mf[b][a] * e0[a][n] for b in range(4) for a in range(4)) for n in range(4)] for m in range(4)]
def std_mixed(e):
    g = std_metric(e, 4, SQ, NV, 2); R1, g0, g0i = std_riemann(g, 4, NV, 1); return std_einstein_mixed(R1, g0, g0i, 4)[0]
def killing_bit(Gv, e, E, xi):
    Le, lam = F3.lie_frame(Gv, e, E, xi); return F3.all_zero(F3.lam_sym(lam))

# ------------------------------------------------------------------------------------------------ Part B helpers: series
NS = 6
def s_mul(a, b): return [sum(a[i] * b[k - i] for i in range(k + 1)) for k in range(NS)]
def s_pow_half(a, sgn=1):
    """(1 + a)^(sgn/2) for a series a with a[0] = 0 (binomial series)"""
    out = [F(0)] * NS; term = [F(1)] + [F(0)] * (NS - 1); c = F(1); al = F(sgn, 2)
    for j in range(NS):
        out = [x + c * y for x, y in zip(out, term)]; term = s_mul(term, a); c = c * (al - j) / (j + 1)
    return out
def s_compose(f, X):
    """f(X(u)) for X with X[0] = 0 (Horner)"""
    out = [F(0)] * NS
    for c in reversed(f): out = s_mul(out, X); out[0] += c
    return out
def polar_series(rp, rm):
    """[std] T = (r - rp)(r - rm)/r^2, x = r - rp: returns (t1, Z2) with T = t1 x + ..., G^2/(kappa^2 rho^2) = Z2(u), u = kappa rho^2/2, kappa = t1/2"""
    rp, rm = F(rp), F(rm); inv = [(-1) ** k / rp ** (k + 2) * (k + 1) for k in range(NS + 1)]    # 1/(rp + x)^2 = sum (k+1)(-x)^k/rp^(k+2)
    num = [F(0), rp - rm, F(1)] + [F(0)] * (NS - 2)                                             # x (x + rp - rm)
    Tx = [sum(num[i] * inv[k - i] for i in range(k + 1)) for k in range(NS + 1)]
    t1 = Tx[1]; tau = [F(0)] + [Tx[k + 1] / t1 for k in range(1, NS)]                           # T/(t1 x) = 1 + tau
    V = s_pow_half(tau, -1); Sx = [V[k] / (2 * k + 1) for k in range(NS)]                        # rho = 2 (t1)^(-1/2) sqrt(x) S(x)
    S2m1 = s_mul(Sx, Sx); S2m1[0] -= 1                                                          # u = x S(x)^2 = x + x (S^2 - 1)
    R = [F(0)] + S2m1[:NS - 1]
    Xs = [F(0), F(1)] + [F(0)] * (NS - 2)
    for _ in range(NS + 1):
        RX = s_compose(R, Xs); Xs = [(F(1) if k == 1 else F(0)) - RX[k] for k in range(NS)]
    Tn = [F(1)] + tau[1:]; Xu = Xs[1:] + [F(0)]                                                  # X(u)/u
    Z2 = s_mul(s_compose(Tn, Xs), Xu)
    chk_u = s_compose([F(0)] + [x for x in s_mul(Sx, Sx)][:NS - 1], Xs)                         # u(X(u)) must be u
    return t1, Z2, chk_u

# ------------------------------------------------------------------------------------------------ Part B helpers: Euclidean frame and the Euler density
def C_(c): return const(NV, F(c))
def Xv(i, x0): return lin((F(1), const(NV, F(x0))), (F(1), var(NV, i)))
def mul(*ps):
    r = ps[0]
    for q in ps[1:]: r = sp_mul(r, q, 2, NV)
    return r
def inv_j(a):
    a0 = at0(a, NV); u = scale(sp_add(a, const(NV, a0), -1), 1 / a0)
    return scale(lin((F(1), C_(1)), (F(-1), u), (F(1), mul(u, u))), 1 / a0)
def sqrt_j(a, q):
    u = scale(sp_add(a, const(NV, q * q), -1), 1 / (q * q)); return scale(lin((F(1), C_(1)), (F(1, 2), u), (F(-1, 8), mul(u, u))), q)
def euclid_frame(M, s, r0, q, t0):
    """Euclidean coframe in (tau, r, t, phi), theta = 2 arctan t, at (0, r0, t0, 0); T(r0) = q^2"""
    R_ = Xv(1, r0); ir = inv_j(R_); Tj = lin((F(1), C_(1)), (-2 * F(M), ir), (2 * F(s), mul(ir, ir))); assert at0(Tj, NV) == q * q
    sT = sqrt_j(Tj, q); Tt = Xv(2, t0); it = inv_j(lin((F(1), C_(1)), (F(1), mul(Tt, Tt))))
    sth = scale(mul(Tt, it), 2); dth = scale(it, 2)
    return [{1: sT}, {2: inv_j(sT)}, {4: mul(R_, dth)}, {8: mul(R_, sth)}], at0(sth, NV) * at0(dth, NV)
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
def euler_bit(GvE, SE, e, linear=False):
    """[bit] the coefficient of d tau ^ dr ^ dt ^ d phi of eps_abcd R^ab ^ R^cd at the point (engine curvature, wedge; linear: R = d omega)"""
    om, R = engine_om_R(GvE, e, SE, 4)
    if linear:
        with trunc(4, xdeg=1): R = [GvE.Fm.d(om[A]) for A in range(GvE.G)]
    Fm = GvE.Fm; ix = lambda a, b: GvE.L.idx[(1 << a) | (1 << b)]; E4 = {}
    with trunc(4, xdeg=0):
        for (a, b) in PAIRS:
            c, d = [x for x in range(4) if x not in (a, b)]; E4 = Fm.add(E4, Fm.wedge(R[ix(a, b)], R[ix(c, d)]), 4 * GvE.eps([a, b, c, d]))
    return at0(E4.get(15, {}), NV)
def gb_std(e):
    """[std] (R_abcd R^abcd - 4 R_ab R^ab + R^2) sqrt(g) at the point, Christoffel route (b1lib.std_riemann, Euclidean metric)"""
    g = std_metric(e, 4, SQE, NV, 2); Rr, g0, g0i = std_riemann(g, 4, NV, 1); n = 4; rg = range(n)
    Rl = {(a, b, c, d): sum(g0[a][x] * Rr[(x, b, c, d)] for x in rg) for a in rg for b in rg for c in rg for d in rg}
    Ru = {}
    for a in rg:
        for b in rg:
            for c in rg:
                for d in rg: Ru[(a, b, c, d)] = sum(g0i[b][y] * g0i[c][z] * g0i[d][w] * Rr[(a, y, z, w)] for y in rg for z in rg for w in rg)
    Kr = sum(Rl[k] * Ru[k] for k in Rl)
    ric = [[sum(Rr[(r, s_, r, v)] for r in rg) for v in rg] for s_ in rg]; Rs = sum(g0i[s_][v] * ric[s_][v] for s_ in rg for v in rg)
    ric2 = sum(g0i[a][c] * g0i[b][d] * ric[a][b] * ric[c][d] for a in rg for b in rg for c in rg for d in rg)
    e0 = [[at0(e[a].get(1 << m, {}), NV) for m in rg] for a in rg]; det, _ = det_inv(e0)
    return (Kr - 4 * ric2 + Rs * Rs) * abs(det)
def bolt_points(rp, rm, ts):
    c0, d = (F(rp) + F(rm)) / 2, (F(rp) - F(rm)) / 2
    return [(c0 + (t + d * d / t) / 2, ((t - d * d / t) / 2) / (c0 + (t + d * d / t) / 2)) for t in ts]

def main():
    head('GSA-HORIZONS: Killing horizons on given frames; the Euclidean period of Schwarzschild and Reissner-Nordstrom' + (' [fault %s]' % FAULT if FAULT else ''))
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
    CT = {}
    def ctl(name, wrong): x = CT.setdefault(name, [0, 0]); x[1] += 1; x[0] += int(bool(wrong))
    # ================================================================================== A1 static frames
    head('A1. static frames: d_t Killing, xi_flat ^ d xi_flat = 0 (value and first derivatives), xi^2 = 0 exactly on the horizons')
    u1 = (F(1, 3), F(2, 3), F(2, 3)); u2 = (F(2, 7), F(3, 7), F(6, 7))
    MEM = [('Schwarzschild M = 1', F(1), F(0), F(0), [F(2)], [F(3), F(5, 2), F(3, 2)]),
           ('RN (M, s) = (2, 3/2)', F(2), F(3, 2), F(0), [F(3), F(1)], [F(2), F(5), F(1, 2)]),
           ('SdS horizons 1, 2 (M, H2) = (3/7, 1/7)', F(3, 7), F(0), F(1, 7), [F(1), F(2)], [F(3, 2), F(3), F(1, 2)])]
    nA = 0; ok_k = ok_f = ok_fs = ok_h = ok_off = True; ok_ctx = True; nh = noff = 0
    for name, M, s, H2, hors, offs in MEM:
        for i, rho0 in enumerate(hors + offs):
            u = u1 if i % 2 == 0 else u2; p = [rho0 * x for x in u]; e, E, gtt = static_frame(p, rho0, M, s, H2)
            if i == len(hors):                                                     # context: which frame the member is (field equation, not the criterion)
                Mb = engine_mixed(Gv, S, e, H2); Gs = std_mixed(e); Mz = [[Gs[r][c_] - (3 * H2 if r == c_ else 0) for c_ in range(4)] for r in range(4)]
                ok_ctx &= (Mb == Mz) and ((s == 0) == all(x == 0 for row in Mb for x in row))
            xi = d_t()
            if FAULT == 'nonkilling': xi = [lin((F(1), const(NV, 1)), (F(1, 7), var(NV, 1))), {}, {}, {}]
            ok_k &= killing_bit(Gv, e, E, xi)
            Wb, xa = frob_bit(Gv, e, xi); Ws, g = frob_std(e, xi); n2 = K.frame_norm_bit([at0(q, NV) for q in xa], SQ)
            ok_f &= zero3(Wb); ok_fs &= (Wb == Ws) and n2 == norm_std(g, xi) == gtt; nA += 1
            if rho0 in hors: ok_h &= (n2 == 0); nh += 1
            else: ok_off &= (n2 != 0); noff += 1
            # controls on the same frame
            xn = [lin((F(1), const(NV, 1)), (F(1, 7), var(NV, 1))), {}, {}, {}]
            Wn, xan = frob_bit(Gv, e, xn); ctl('(1 + x/7) d_t: hypersurface orthogonal (xi ^ d xi = 0) and null where d_t is, but not Killing (lam not antisymmetric)', zero3(Wn) and not killing_bit(Gv, e, E, xn))
            xr = vsum((1, d_t()), (F(1, 3), rot_z(p))); Wr, _ = frob_bit(Gv, e, xr)
            ctl('d_t + (1/3) rot_z: Killing, but xi ^ d xi != 0 (not hypersurface orthogonal)', killing_bit(Gv, e, E, xr) and not zero3(Wr))
    chk('bit', ok_k, 'd_t is Killing (L_xi e^a = lam^a_b e^b, lam antisymmetric, value and first derivatives) at all %d points of the three static frames' % nA)
    chk('bit', ok_f, 'xi_flat ^ d xi_flat = 0 for xi = d_t: all four components of the 3-form, value and first derivatives, at the %d points (horizons, between, inside, outside): d_t is hypersurface orthogonal' % nA)
    chk('bit==std', ok_fs, 'the engine\'s 3-form (bit-rule d and wedge) = the permutation sum of xi_mu d_nu xi_rho from the metric components, and xi^2 (bit-rule square) = g_tt = 1 - 2f at every point')
    chk('bit==std', ok_ctx, 'context (the field equation, not the criterion): the engine\'s E_a(c) with c = H2 equals the Christoffel-route G - 3c delta at one off-horizon point per member; it vanishes for Schwarzschild and SdS (vacuum with c = Lambda/3) and not for RN (a Maxwell source, C3)')
    chk('bit', ok_h and ok_off and nh == 5 and noff == 9, 'xi^2 = 0 exactly at the %d horizon points (rho = 2; 3 and 1; 1 and 2) and xi^2 != 0 at the %d points off the horizons: the set xi^2 = 0 is the horizon set of each frame' % (nh, noff))
    tick('A1')
    # ================================================================================== A2 Kerr
    head('A2. Kerr (M, a) = (5, 3): d_t not hypersurface orthogonal; chi = d_t + Omega_H rot_z null with chi ^ d chi = 0 on the horizon; the ergosurface g_tt = 0 off the horizon except on the axis')
    M, a = F(5), F(3); OmH = a / (9 * 9 + a * a)
    HOR = [(F(105, 17), F(45, 17), F(108, 17))] + [P['p'] for P in K.rational_kerr_points(a, [F(9)], [((F(3, 5), F(4, 5)), (F(0), F(1))), ((F(0), F(1)), (F(4, 5), F(3, 5)))])]
    AXIS = [(F(0), F(0), F(9)), (F(0), F(0), F(-9))]
    ERG = [(F(34725, 4913), F(1710, 4913), F(1944, 289)), (F(10), F(3), F(0)), (F(-3), F(10), F(0)), (F(34725, 4913) * F(3, 5) - F(1710, 4913) * F(4, 5), F(34725, 4913) * F(4, 5) + F(1710, 4913) * F(3, 5), F(1944, 289))]
    if FAULT == 'ergo_radius':                                                      # the point of Kerr-Schild radius 2M = 10 at cos th = 12/17: x^2 + y^2 = 109 * 145/289
        uv = next((u, math.isqrt(15805 - u * u)) for u in range(math.isqrt(15805), 0, -1) if math.isqrt(15805 - u * u) ** 2 == 15805 - u * u)
        ERG[0] = (F(uv[0], 17), F(uv[1], 17), F(120, 17))
    OFF = [P['p'] for P in K.rational_kerr_points(a, [F(20), F(7)], [((F(3, 5), F(4, 5)), (F(3, 5), F(4, 5)))])]
    def kerr_at(p):
        x, y, z = p; R2 = x * x + y * y + z * z - a * a; disc = R2 * R2 + 4 * a * a * z * z; r2 = (R2 + K.rat_sqrt(disc)) / 2; r = K.rat_sqrt(r2)
        e, E, _, dat = K.kerr_ks_frame_jet(p, M, a, r); return e, E, r
    ok_hn = ok_hx = ok_ax = ok_er = ok_t = ok_ts = ok_ch = True; rs_h, rs_e = set(), set(); vals = []
    for p in HOR + AXIS + ERG + OFF:
        e, E, r = kerr_at(p); xi = d_t(); chi = vsum((1, d_t()), (OmH, rot_z(p)))
        Wx, xa = frob_bit(Gv, e, xi, deg=0); Wxs, g = frob_std(e, xi, deg=0); Wc, ca = frob_bit(Gv, e, chi, deg=0); Wcs, _ = frob_std(e, chi, deg=0)
        nx = K.frame_norm_bit([at0(q, NV) for q in xa], SQ); nc = K.frame_norm_bit([at0(q, NV) for q in ca], SQ)
        ok_ts &= (Wx == Wxs and Wc == Wcs and nx == norm_std(g, xi) and nc == norm_std(g, chi)); cz = z_over = p[2] / r
        if p in HOR: rs_h.add(r); ok_hn &= (nc == 0 and nx < 0 and zero3(Wc)); ok_t &= not zero3(Wx)
        elif p in AXIS: rs_h.add(r); ok_ax &= (nc == 0 and nx == 0)
        elif p in ERG: rs_e.add((r, cz)); ok_er &= (nx == 0 and nc != 0 and r != 9 and not zero3(Wc)); ok_t &= not zero3(Wx)
        else: ok_ch &= (nx != 0 and nc != 0 and not zero3(Wc) and not zero3(Wx))
        vals.append((r, cz, nx, nc))
        chi9 = vsum((1, d_t()), (OmH * F(9, 10), rot_z(p)))
        if p in HOR: ctl('chi with 9/10 Omega_H on the horizon: not null', K.frame_norm_bit([at0(q, NV) for q in frame_comps(Gv, chi9, e)], SQ) != 0)
    chk('bit', ok_hn and ok_t, 'on the horizon r = 9 (3 points off the axis, cos th = 12/17, 3/5, 0): chi^2 = 0 and chi_flat ^ d chi_flat = 0 (chi normal to the horizon), while d_t^2 < 0 (spacelike) and d_t ^ d d_t != 0 (d_t is not hypersurface orthogonal)')
    chk('bit', ok_ax, 'at the poles (0, 0, +-9): d_t^2 = chi^2 = 0: the ergosurface touches the horizon on the axis')
    chk('bit', ok_er, 'at 4 rational points of the ergosurface (r_E = 162/17 at cos th = 12/17, two azimuths; r_E = 10 on the equator, two azimuths): d_t^2 = g_tt = 0 exactly while chi^2 != 0 and chi ^ d chi != 0: the ergosurface is not the horizon r_+ = 9 off the axis')
    chk('bit', ok_ch, 'at 2 points off both surfaces (r = 20, 7): d_t^2, chi^2, d_t ^ d d_t and chi ^ d chi are all non-zero')
    chk('bit==std', ok_ts, 'engine (bit-rule interior, d, wedge, squares) = metric components (plain polynomials) for both 3-forms and both norms at all %d Kerr points' % len(vals))
    rE = lambda c2: M + K.rat_sqrt(M * M - a * a * c2)
    chk('std', all(r == rE(cz * cz) for (r, cz) in rs_e) and rs_h == {F(9)} and rE(F(1)) == 9, '[recalled closed form] r_E = M + sqrt(M^2 - a^2 cos^2 th): 162/17 at cos th = 12/17, 10 at 0, 9 = r_+ at 1; the points used have exactly these Kerr-Schild radii')
    tick('A2')
    # ================================================================================== B1 kappa
    head('B. the Euclidean section: kappa from the Lorentzian frame, the polar series, the engine\'s Euler integral')
    RNM = [('Schwarzschild M = 1', F(1), F(0), F(2), F(0)), ('RN (M, s) = (2, 3/2)', F(2), F(3, 2), F(3), F(1)), ('RN (M, s) = (3/2, 1)', F(3, 2), F(1), F(2), F(1))]
    KAP = {}
    ok_k1 = True
    for name, M, s, rp, rm in RNM:
        for rr in ([rp, rm] if rm else [rp]):
            p = [rr * x for x in u1]; e, E, gtt = static_frame(p, rr, M, s)
            om = omega_closed_form(Gv, e, S, NV, 0)[0]; ca, nab = K.engine_nabla_vv(Gv, om, e, d_t())
            k = next((nab[i] / ca[i] for i in range(4) if ca[i] != 0), None); prop_ok = k is not None and all(nab[i] == k * ca[i] for i in range(4))
            g = std_metric(e, 4, SQ, NV, 2); ns = K.std_nabla_vv(g, d_t()); ks = ns[0]
            Tp = 2 * M / rr ** 2 - 4 * s / rr ** 3
            ok_k1 &= prop_ok and k == ks and k == Tp / 2 and gtt == 0; KAP[(name, rr)] = k
    chk('bit==std', ok_k1, 'nabla_xi xi = kappa xi for xi = d_t at horizon points (engine: A3 omega, D_vector; Christoffel route): kappa = %s; = T\'(r_h)/2 (closed form)' % ', '.join('%s at r = %s (%s)' % (v, k[1], k[0]) for k, v in KAP.items()))
    # ================================================================================== B2 polar series
    ok_s = True; zs = []
    for name, M, s, rp, rm in RNM:
        t1, Z2, cu = polar_series(rp, rm); kap = t1 / 2
        ok_s &= (Z2[0] == 1 and kap == KAP[(name, rp)] and cu[:NS - 1] == [F(0), F(1)] + [F(0)] * (NS - 3)); zs.append((name, kap, Z2[1], Z2[2]))
    chk('std', ok_s, 'polar chart of the (rho, tau) section, exact series to u^%d (u = kappa rho^2/2): G^2 = kappa^2 rho^2 (1 + z1 u + z2 u^2 + ...), so G is odd with G\'(0) = kappa = the engine\'s kappa; (kappa, z1, z2) = %s' % (NS - 1, '; '.join('%s: (%s, %s, %s)' % z for z in zs)))
    # numerical cross-check of the series (floats): rho(r) by quadrature against the series at three radii
    from scipy.integrate import quad
    worst = 0.0
    for name, M, s, rp, rm in RNM:
        t1, Z2, _ = polar_series(rp, rm); kap = float(t1 / 2); Tf = lambda r: (r - float(rp)) * (r - float(rm)) / r ** 2
        for dx in (1e-3, 1e-2, 2e-2):
            r = float(rp) + dx; rho = quad(lambda x: 1 / math.sqrt(Tf(x)), float(rp), r, limit=200)[0]; u = kap * rho * rho / 2
            ser = kap * kap * rho * rho * sum(float(Z2[k]) * u ** k for k in range(NS)); worst = max(worst, abs(ser - Tf(r)) / Tf(r))
    chk('std', worst < 1e-9, 'floats: rho(r) = int dr/sqrt(T) by quadrature at r_+ + 0.001, 0.01, 0.02 for the three members (the series to u^5): T(r) = the series in rho to relative %.1e (< 1e-9)' % worst)
    tick('B1-B2')
    # ================================================================================== B3 Euler integral
    LieE = Lie(SQE); GvE = Grav(4, LieE); SE = koszul_S(4, SQE, LieE)
    ok_fit = ok_gb = ok_I = ok_cf = True; rows = []
    TS = [F(2), F(3), F(5, 2), F(4), F(7, 2)]; TH = [F(1, 2), F(2, 3), F(1, 3), F(3, 4), F(2, 5)]
    for name, M, s, rp, rm in RNM:
        pts = bolt_points(rp, rm, TS); dens = []
        for (r0, q), t0 in zip(pts, TH):
            e, w = euclid_frame(M, s, r0, q, t0); E4 = euler_bit(GvE, SE, e, linear=(FAULT == 'linear_R')); gb = gb_std(e)
            ok_gb &= (E4 == gb) or FAULT == 'linear_R'; dens.append((r0, E4 / w))
        A = [[r0 ** -k for k in (4, 5, 6)] for r0, _ in dens[:3]]; b = [d for _, d in dens[:3]]
        c, rk, _, cons = solve_exact(A, b)
        ok_fit &= c is not None and all(sum(ck * r0 ** -k for ck, k in zip(c, (4, 5, 6))) == d for r0, d in dens[3:])
        I = sum(ck * rp ** (1 - k) / (k - 1) for ck, k in zip(c, (4, 5, 6))) if c else None
        kap = KAP[(name, rp)]; ok_I &= (I == 8 * kap); Q2 = 2 * s
        ok_cf &= c == [48 * M * M, -96 * M * Q2, 40 * Q2 * Q2]
        rows.append((name, c, I, kap))
    chk('bit==std', ok_gb, 'the engine\'s Euler 4-form coefficient E4 = (R_abcd R^abcd - 4 R_ab R^ab + R^2) sqrt(g) of the Christoffel route, exactly, at all 15 points (Euclidean frames, Cl(4,0))')
    chk('bit', ok_fit, 'the radial density E4/(sin th theta\') = c4/r^4 + c5/r^5 + c6/r^6 fitted at 3 points per member is verified exactly at 2 more (rational points with T = q^2, t = 2, 3, 5/2, 4, 7/2 of the parametrisation)')
    chk('std', ok_cf, '[recalled closed form] (c4, c5, c6) = (48 M^2, -96 M Q^2, 40 Q^4) with Q^2 = 2s: %s' % '; '.join('%s: %s' % (r[0], [str(x) for x in r[1]]) for r in rows))
    chk('bit', ok_I, 'I = int_{r+}^inf rho_E dr = 8 kappa exactly (%s), so (1/32 pi^2) int E4 over tau in [0, P) is P I/(8 pi) = kappa P/pi = 2 beta, beta = kappa P/(2 pi)' % '; '.join('%s: I = %s, kappa = %s' % (r[0], r[2], r[3]) for r in rows))
    def chi_int(I, P_over_pi): return I * P_over_pi / 8                                   # P I/(8 pi) with P = (P/pi) pi
    reg = all(chi_int(r[2], 2 / r[3]) == 2 for r in rows)
    Pf = (lambda kap: 1 / kap) if FAULT == 'half_period' else ((lambda kap: F(2)) if FAULT == 'inner_kappa' else (lambda kap: 2 / kap))
    main_ok = all(chi_int(r[2], Pf(r[3])) == 2 for r in rows)
    chk('bit', reg and main_ok, 'at the period P = 2 pi/kappa the Euler integral is 2 = chi(R^2 x S^2) for the three members (beta = 1, no cone along the bolt); the polar chart is smooth there (B2)')
    for r in rows:
        ctl('the period pi/kappa (beta = 1/2): the Euler integral is 1, the defect (1 - beta) chi(S^2) = 1', chi_int(r[2], 1 / r[3]) == 1)
    I2, k2 = rows[1][2], rows[1][3]; kin = abs(KAP[('RN (M, s) = (2, 3/2)', F(1))])
    ctl('the period 2 pi/|kappa_-| of the inner horizon (|kappa_-| = 1) at the outer bolt of RN (2, 3/2): integral 2 kappa_+/|kappa_-| = 2/9, not 2', chi_int(I2, 2 / kin) != 2)
    e, w = euclid_frame(F(1), F(0), *bolt_points(F(2), F(0), [F(3)])[0], F(1, 2)); ctl('R = d omega (no quadratic term) in the Euler 4-form changes E4 (Schwarzschild point)', euler_bit(GvE, SE, e, linear=True) != euler_bit(GvE, SE, e))
    tick('B3')
    head('controls (a wrong version must fail on every sample where it can be seen)')
    for name, (dif, seen) in CT.items(): chk('ctl', dif == seen and seen > 0, '%s: fails on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GSA-HORIZONS' + ('-' + FAULT if FAULT else ''))

if __name__ == '__main__': main()
