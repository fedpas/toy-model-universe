#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-LT.  Frame dragging: a spin carried along a circular equatorial geodesic of Kerr turns by 2 pi (1 - sqrt(1 - 3M/r + 2a sqrt(M/r^3))) per orbit.
    python3 gm_lense_thirring.py [--fault OMEGA|RATE|SCHIFF|SIGN]

 Derivation: along a geodesic Fermi-Walker transport is parallel transport. The orbit u = u^t (d_t + Omega d_phi) is an orbit of the helical Killing field d_t + Omega d_phi, and the
 Kerr-Schild frame of g2_kerr is invariant under t and covariant under rotations about z, so a vector dragged by the isometry has frame components R_z(Omega t) V(0). Relative to that
 co-rotating frame the carried spin turns in the plane orthogonal to u and e_z: S(tau) = R_z(Omega u^t tau) exp(-w tau J) S(0), J = *(u ^ e_z). Per orbit (tau = 2 pi/(Omega u^t)) the turn
 against the fixed directions is 2 pi - 2 pi w/(Omega u^t). Recalled: Omega = sqrt(M)/(r^(3/2) + a sqrt(M)) (prograde for a > 0), u^t = (1 + a W)/sqrt(1 - 3M/r + 2aW), W = sqrt(M/r^3);
 the closed form of Rindler and Perlick for the turn, and Schiff's Omega_LT = (1/r^3)[3 (J.n) n - J], J = aM, which gives -2 pi (a/r) sqrt(M/r) per orbit on the equator.
 Found here: w = W for every a run, so the turn is 2 pi (1 - sqrt(1 - 3M/r + 2aW)); its term linear in a is -2 pi (a/r) sqrt(M/r)/sqrt(1 - 3M/r): Schiff's term times
 1/sqrt(1 - 3M/r) = u^t(a = 0): the a-dependence of Omega and u^t enters through the proper orbital period.
 Orbit of the exact route: M = 25, r = 196 (M/r = 25/196, W = 5/2744); u^t is rational when 121 + 5a/7 = s^2 (s rational): a = 63/4, 469/45, -91/9 give s = 23/2, 34/3, 32/3 and
 1 - s/14 = 5/28, 4/21, 5/21 turns of 2 pi; a = 0 gives 3/14 (gm_gyroscope's 3 pi/7).
 [bit]  (1) a = 0 on g2_kerr's frame: gm_gyroscope's transport (A3 closed-form omega, the engine's h table, Picard series to order tau^2), 3/14 = gm_gyroscope's number.
        (2) the exact a: d_t + Omega d_phi carried as a geodesic tangent to order tau^2 (exact for any rational Omega); u^t from the frame (exact) against the recalled form; the
            four carried frame vectors, the proper rate w read at order tau and every entry matched to order tau^2; the turn per orbit.
        (3) first order in a: the Kerr-Schild frame with r = rho, f = M/rho, l = dt + x.dx/rho + a (y dx - x dy)/rho^2 (a as the bookkeeping slot of b1lib.trunc, kept to a^1);
            the engine's Einstein form vanishes on it mod a^2 (16 components); the transport over dual numbers c0 + c1 a; the a-linear coefficient of the turn; the reversed spin.
 [std]  scipy: the equatorial geodesic and parallel transport with the Christoffel symbols of Kerr in Boyer-Lindquist coordinates (metric recalled, r-derivatives in closed form), one orbit,
        M/r = 25/196, a/M in {0, 1/5, -1/5, 63/100, +-1/500}: the angle against the co-rotating radial direction; r stays on the circle.
 [bit==std] the scipy turn at a/M = 63/100 = 5/28 of 2 pi; the scipy derivative in a = the engine's a-linear coefficient.
 Controls (--fault puts each wrong version into the main check): OMEGA the Kepler W in place of Omega (not a geodesic of Kerr); RATE the orbital Omega in place of w; SCHIFF Schiff's
 coefficient in place of the engine's; SIGN the frame with the spin reversed under the prograde Omega. [std] Fermi-Walker transport along a non-geodesic circle (11/10 Omega)."""
import os, sys, math, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
from scipy.integrate import solve_ivp
import g2_kerr as K
import g2_hodge as H
import gm_gyroscope as GY

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'OMEGA', 'RATE', 'SCHIFF', 'SIGN'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N = 4; SQ = LORENTZ(4); KO = GY.K
M0, R0 = F(25), F(196); W = F(5, 2744)                            # W = sqrt(M/r^3)
AV = [(F(63, 4), F(23, 2)), (F(469, 45), F(34, 3)), (F(-91, 9), F(32, 3))]
COEF = -F(5, 11) / R0; COEF_SCHIFF = -F(5, 14) / R0               # the a-linear coefficient of turn/(2 pi): engine (predicted) and Schiff
def omega_kerr(a): return F(5) / (2744 + 5 * a)                   # sqrt(M)/(r^(3/2) + a sqrt(M)) at M = 25, r = 196
def ut_recalled(a, s): return (1 + a * W) * 14 / s

# ------------------------------------------------------------------------------------------------ dual numbers c0 + c1 a (a^2 = 0)
class Du:
    __slots__ = ('x', 'y')
    def __init__(s, x=0, y=0): s.x = F(x); s.y = F(y)
    def __add__(s, o): o = du(o); return Du(s.x + o.x, s.y + o.y)
    __radd__ = __add__
    def __sub__(s, o): o = du(o); return Du(s.x - o.x, s.y - o.y)
    def __rsub__(s, o): o = du(o); return Du(o.x - s.x, o.y - s.y)
    def __mul__(s, o): o = du(o); return Du(s.x * o.x, s.x * o.y + s.y * o.x)
    __rmul__ = __mul__
    def __truediv__(s, o): o = du(o); return Du(s.x / o.x, (s.y * o.x - s.x * o.y) / (o.x * o.x))
    def __rtruediv__(s, o): return du(o) / s
    def __neg__(s): return Du(-s.x, -s.y)
    def __eq__(s, o): o = du(o); return s.x == o.x and s.y == o.y
    def __ne__(s, o): return not s.__eq__(o)
    def __gt__(s, o): return s.x > du(o).x
    __hash__ = None
    def __repr__(s): return '%s + (%s) a' % (s.x, s.y)
def du(o): return o if isinstance(o, Du) else Du(o, 0)
def dsqrt_inv(v):
    """(x + y a)^(-1/2) for a rational square x"""
    r = K.rat_sqrt(v.x); assert r is not None; return Du(1 / r, -v.y / (2 * r ** 3))
def s_const(c): return [du(c)] + [Du() for _ in range(KO)]
def s_mul(a, b): return [sum((a[i] * b[k - i] for i in range(k + 1)), Du()) for k in range(KO + 1)]
def s_add(a, b, c=1): return [x + c * y for x, y in zip(a, b)]
def s_int(a): return [Du()] + [a[k - 1] / k for k in range(1, KO + 1)]
def s_sum(items):
    out = s_const(0)
    for x in items: out = s_add(out, x)
    return out
def compose(p, d):
    out = s_const(0)
    for ex, v in p.items():
        t = s_const(v)
        for i, k in enumerate(ex):
            for _ in range(k): t = s_mul(t, d[i])
        out = s_add(out, t)
    return out
def to_dual(p):
    """a polynomial in (delta, a) (slot 4 = a, degree <= 1) -> {delta exponents: Du}"""
    out = {}
    for ex, v in p.items():
        assert ex[4] <= 1
        d = out.setdefault(ex[:4], Du())
        if ex[4] == 0: d.x += v
        else: d.y += v
    return out
def transport_dual(Gv, om, E, u0, vecs, iters=KO + 2):
    """[bit] gm_gyroscope.transport over dual numbers: om, E with Du coefficients"""
    d = [s_const(0) for _ in range(N)]; U = [s_const(c) for c in u0]; V = [[s_const(c) for c in v] for v in vecs]; h = list(Gv.L.h.items())
    for _ in range(iters):
        Ed = [[compose(E[mu][a], d) for a in range(N)] for mu in range(N)]
        xdot = [s_sum(s_mul(Ed[mu][a], U[a]) for a in range(N)) for mu in range(N)]
        omu = [s_sum(s_mul(compose(om[A].get(1 << mu, {}), d), xdot[mu]) for mu in range(N)) for A in range(Gv.G)]
        def rhs(X):
            out = [s_const(0) for _ in range(N)]
            for (A, b), (c, hv) in h: out[c] = s_add(out[c], s_mul(omu[A], X[b]), -hv)
            return out
        nU = [s_add(s_const(u0[c]), s_int(r)) for c, r in enumerate(rhs(U))]
        nV = [[s_add(s_const(v[c]), s_int(r)) for c, r in enumerate(rhs(X))] for v, X in zip(vecs, V)]
        d = [s_int(x) for x in xdot]; U, V = nU, nV
    return d, U, V
NV5 = 5
def jm(a, b):
    """product of 2-jets in delta with the spin slot kept to degree 1"""
    return {k: v for k, v in sp_mul(a, b, 2, N).items() if k[4] <= 1}
def kerr_frame_a1(p, M, rho0, sgn=1):
    """[bit] the Kerr-Schild frame of g2_kerr to first order in a around p (z = 0 allowed): r = rho + O(a^2), f = M/rho + O(a^2),
    l_mu dx^mu = dt + (x dx + y dy + z dz)/rho + sgn a (y dx - x dy)/rho^2 (null to first order); e^a = dx^a - f l^a l_mu dx^mu, E = delta + f l^mu l_a"""
    X = [None] + [var(NV5, i) for i in (1, 2, 3)]; A_ = var(NV5, 4)
    ir = H.rho_pow_jet(p, rho0, -1, 2, NV5); ir2 = H.rho_pow_jet(p, rho0, -2, 2, NV5); f = scale(ir, M)
    xs = [None] + [lin((F(1), const(NV5, p[i - 1])), (F(1), X[i])) for i in (1, 2, 3)]
    ld = [const(NV5, 1)] + [jm(xs[i], ir) for i in (1, 2, 3)]
    ld[1] = padd(ld[1], jm(A_, jm(xs[2], ir2)), sgn); ld[2] = padd(ld[2], jm(A_, jm(xs[1], ir2)), -sgn)
    lu = [ld[0]] + [scale(q, -1) for q in ld[1:]]
    e = []; E = [[None] * N for _ in range(N)]
    for a in range(N):
        form = {}
        for mu in range(N):
            pol = lin((F(1 if a == mu else 0), const(NV5, 1)), (F(-1), jm(jm(f, lu[a]), ld[mu])))
            if pol: form[1 << mu] = pol
            E[mu][a] = lin((F(1 if a == mu else 0), const(NV5, 1)), (F(1), jm(jm(f, lu[mu]), ld[a])))
        e.append(form)
    return e, E

def orient_J(u0):
    z = [F(0), F(0), F(0), F(1)]; J = GY.dual_generator(u0, z)
    xr = [F(0), F(1), F(0), F(0)]; yr = [F(0), F(0), F(1), F(0)]
    pr = lambda v: [a - GY.eta(v, u0) * b for a, b in zip(v, u0)]
    sgn = 1 if -GY.eta(GY.mv(J, pr(xr)), pr(yr)) > 0 else -1
    return [[sgn * x for x in r] for r in J], z
KZ = [[F(0)] * N for _ in range(N)]; KZ[2][1] = F(1); KZ[1][2] = F(-1)
def fit_rate(V, J, rot):
    """the proper rate w from the order-tau coefficient of the carried basis vectors: V1 = rot Kz - w J (entry with J != 0)"""
    for a in range(N):
        for c in range(N):
            if J[c][a] != 0: return (rot * KZ[c][a] - V[a][c][1]) / J[c][a]
def frame_vec(e, v, nv=N):
    return [sum(at0(e[A].get(1 << mu, {}), nv) * v[mu] for mu in range(N)) for A in range(N)]

# ------------------------------------------------------------------------------------------------ [bit] one exact orbit of the Kerr frame
def exact_orbit(a, Om, a_l=None):
    """the g2_kerr frame at p = (r, a, 0) (theta = pi/2, phi = 0); returns the engine data of the carried chi = d_t + Om d_phi and of the carried frame vectors"""
    p = (R0, a, F(0)); e, E, _, dat = K.kerr_ks_frame_jet(p, M0, a, R0, a_l=a_l)
    Lie_ = Lie(SQ); Gv = Grav(N, Lie_); S_ = koszul_S(N, SQ, Lie_)
    om = omega_closed_form(Gv, e, S_, N, 1)[0]
    chi = [F(1), -Om * a, Om * R0, F(0)]; c0 = frame_vec(e, chi)
    d, U, _ = GY.transport(Gv, om, E, c0, [])
    Rz = GY.mat_series(KZ, Om); upred = GY.mser_apply(Rz, c0)
    orbit = [[F(0), F(1), F(0)], [F(0), -a * Om, -R0 * Om * Om / 2], [F(0), R0 * Om, -a * Om * Om / 2], [F(0)] * 3]
    geo = all(U[c] == upred[c] for c in range(N)) and all(d[mu] == orbit[mu] for mu in range(N))
    return dict(Gv=Gv, om=om, e=e, E=E, c0=c0, geo=geo, nrm=GY.eta(c0, c0))
def spin_run(o, Om, ut, rate_used):
    u0 = [ut * x for x in o['c0']]; J, z = orient_J(u0)
    J3 = [[sum(J[i][k] * sum(J[k][l] * J[l][j] for l in range(N)) for k in range(N)) for j in range(N)] for i in range(N)]
    okJ = GY.eta(u0, u0) == 1 and GY.mv(J, u0) == [0] * N and GY.mv(J, z) == [0] * N and J3 == [[-x for x in r] for r in J]
    basis = [[F(int(i == a)) for i in range(N)] for a in range(N)]
    d, U, V = GY.transport(o['Gv'], o['om'], o['E'], u0, basis)
    w = fit_rate(V, J, Om * ut)
    pred = GY.mser_mul(GY.mat_series(KZ, Om * ut), GY.mat_series(J, -rate_used))
    okS = all(V[a][c] == GY.mser_apply(pred, basis[a])[c] for a in range(N) for c in range(N))
    return dict(w=w, okS=okS, okJ=okJ, turn=1 - w / (Om * ut))

# ------------------------------------------------------------------------------------------------ [std] Boyer-Lindquist, equator, scipy
def bl_run(Mr, aM, om_fac=1.0, fw=False, npts=4001):
    """M = 1, r = 1/Mr, a = aM. State (t, r, phi, u^t, u^r, u^phi, S^t, S^r, S^phi), signature (-,+,+,+), metric of Kerr on the equator (recalled):
    g_tt = -(1 - 2M/r), g_tphi = -2Ma/r, g_phiphi = r^2 + a^2 + 2Ma^2/r, g_rr = r^2/Delta, Delta = r^2 - 2Mr + a^2.
    fw=True: the circle is forced (r, Omega fixed) and the spin is Fermi-Walker transported with the acceleration of the circle."""
    M = 1.0; a = aM; r0 = 1.0 / Mr
    def g_and_dg(r):
        D = r * r - 2 * M * r + a * a
        g = np.array([[-(1 - 2 * M / r), -2 * M * a / r], [-2 * M * a / r, r * r + a * a + 2 * M * a * a / r]])
        dg = np.array([[-2 * M / r ** 2, 2 * M * a / r ** 2], [2 * M * a / r ** 2, 2 * r - 2 * M * a * a / r ** 2]])
        grr = r * r / D; dgrr = (2 * r * D - r * r * (2 * r - 2 * M)) / D ** 2
        return g, dg, grr, dgrr
    def gam(r):
        """Gamma[mu][nu][lam] on (t, r, phi) = indices (0, 1, 2)"""
        g, dg, grr, dgrr = g_and_dg(r); gi = np.linalg.inv(g); G = np.zeros((3, 3, 3)); idx = [0, 2]
        for i, A in enumerate(idx):
            for j, B in enumerate(idx):
                G[1][A][B] = -0.5 / grr * dg[i, j]
                G[A][1][B] = G[A][B][1] = 0.5 * sum(gi[i, k] * dg[k, j] for k in range(2))
        G[1][1][1] = 0.5 / grr * dgrr
        return G
    def metric3(r):
        g, _, grr, _ = g_and_dg(r); m = np.zeros((3, 3)); m[0, 0], m[0, 2], m[2, 0], m[2, 2] = g[0, 0], g[0, 1], g[1, 0], g[1, 1]; m[1, 1] = grr; return m
    Om = om_fac / (r0 ** 1.5 + a); g3 = metric3(r0)
    ut = 1.0 / math.sqrt(-(g3[0, 0] + 2 * Om * g3[0, 2] + Om * Om * g3[2, 2])); u = np.array([ut, 0.0, Om * ut])
    acc = np.einsum('mnl,n,l->m', gam(r0), u, u)                                    # the acceleration of the forced circle (u constant in these coordinates)
    def rhs(tau, y):
        G = gam(y[1]) if not fw else gam(r0); uu = y[3:6] if not fw else u; S = y[6:9]
        du_ = -np.einsum('mnl,n,l->m', G, uu, uu) if not fw else np.zeros(3)
        dS = -np.einsum('mnl,n,l->m', G, uu, S)
        if fw:
            m3 = metric3(r0); dS = dS + (S @ m3 @ acc) * uu - (S @ m3 @ uu) * acc
        dx = uu if not fw else u
        return np.concatenate([dx, du_, dS])
    y0 = np.concatenate([[0.0, r0, 0.0], u, [0.0, 1.0 / math.sqrt(g3[1, 1]), 0.0]])
    T = 2 * math.pi / (Om * ut); sol = solve_ivp(rhs, (0, T), y0, rtol=1e-12, atol=1e-14, dense_output=True)
    ts = np.linspace(0, T, npts); ang = []; rdev = 0.0
    for tau in ts:
        y = sol.sol(tau); rr = y[1] if not fw else r0; m3 = metric3(rr); uu = y[3:6] if not fw else u; S = y[6:9]; rdev = max(rdev, abs(rr - r0) / r0)
        ul = m3 @ uu; beta = -ul[2] / ul[0]; nvec = np.array([beta, 0.0, 1.0]); nvec = nvec / math.sqrt(nvec @ m3 @ nvec)
        a_r = math.sqrt(m3[1, 1]) * S[1]; a_p = S @ m3 @ nvec
        ang.append(math.atan2(a_p, a_r))
    ang = np.unwrap(np.array(ang)); return (2 * math.pi + ang[-1]) / (2 * math.pi), rdev
def closed_turn(Mr, aM):
    return 1 - math.sqrt(1 - 3 * Mr + 2 * aM * Mr ** 1.5)

def main():
    head('GM-LT: the spin on a circular equatorial geodesic of the Kerr frame (g2_kerr), M = 25, r = 196' + (' [fault %s]' % FAULT if FAULT else ''))
    # ================================================================================== (1) a = 0
    head('(1) a = 0 on the Kerr frame of g2_kerr: the Schwarzschild number of gm_gyroscope [bit]')
    o0 = exact_orbit(F(0), omega_kerr(0)); ut0 = K.rat_sqrt(1 / o0['nrm'])
    chk('bit', o0['geo'] and ut0 == GY.UT, 'a = 0: d_t + Omega d_phi with Omega = %s is carried as a geodesic tangent to order tau^2 (velocity and orbit); u^t = %s = gm_gyroscope\'s u^t' % (omega_kerr(0), ut0))
    s0 = spin_run(o0, omega_kerr(0), ut0, W)
    chk('bit', s0['okJ'] and s0['okS'] and s0['w'] == W and s0['turn'] == F(3, 14) == 1 - 1 / GY.UT,
        'a = 0: the carried frame vectors are R_z(Omega u^t tau) exp(-w tau J) S(0) to order tau^2 with w = %s; turn per orbit %s x 2 pi = 3 pi/7 = gm_gyroscope\'s number' % (s0['w'], s0['turn']))
    tick('part 1')
    # ================================================================================== (2) exact a
    head('(2) the exact orbits a = 63/4, 469/45, -91/9 (u^t rational): geodesic, proper rate, turn per orbit [bit]')
    rows = []
    for a, s in AV:
        Om = omega_kerr(a) if FAULT != 'OMEGA' else W
        o = exact_orbit(a, Om, a_l=(-a if FAULT == 'SIGN' else None))
        chk('bit', o['geo'], 'a = %s: d_t + Omega d_phi with Omega = sqrt(M)/(r^(3/2) + a sqrt(M)) = %s is carried as a geodesic tangent to order tau^2 (the Kerr Omega of the recalled form is a geodesic of the engine\'s frame)' % (a, Om))
        ut = K.rat_sqrt(1 / o['nrm']) if o['nrm'] > 0 else None
        chk('bit', ut is not None and ut == ut_recalled(a, s), 'a = %s: |d_t + Omega d_phi|^2 = %s from the frame, u^t = %s = (1 + aW)/sqrt(1 - 3M/r + 2aW) (recalled form)' % (a, o['nrm'], ut))
        if ut is None: continue
        rate = W if FAULT != 'RATE' else Om
        sr = spin_run(o, Om, ut, rate)
        chk('bit', sr['okJ'] and sr['okS'] and sr['w'] == W, 'a = %s: the four carried frame vectors are R_z(Omega u^t tau) exp(-w tau J) S(0) to order tau^2 with the proper rate w = %s = sqrt(M/r^3) (independent of a)' % (a, sr['w']))
        chk('bit', sr['turn'] == 1 - s / 14, 'a = %s: turn per orbit 1 - w/(Omega u^t) = %s of 2 pi = 1 - sqrt(1 - 3M/r + 2a sqrt(M/r^3)) (Rindler-Perlick form, recalled)' % (a, sr['turn']))
        rows.append((a, Om, ut, sr['turn']))
    a1 = AV[0][0]
    oc = exact_orbit(a1, W)
    chk('ctl', not oc['geo'], 'a = %s: the Kepler W = sqrt(M/r^3) in place of Omega (its a-dependent term left out): d_t + W d_phi is not carried as a geodesic tangent (order tau)' % a1)
    o1 = exact_orbit(a1, omega_kerr(a1)); ut1 = K.rat_sqrt(1 / o1['nrm']); sc = spin_run(o1, omega_kerr(a1), ut1, omega_kerr(a1))
    chk('ctl', not sc['okS'], 'a = %s: the orbital rate Omega = %s in place of w = sqrt(M/r^3) does not match the carried frame vectors' % (a1, omega_kerr(a1)))
    orv = exact_orbit(a1, omega_kerr(a1), a_l=-a1)
    chk('ctl', not orv['geo'], 'a = %s: the frame with the spin reversed (g2_kerr a_l = -a, Kerr with spin -a) under the prograde Omega: not a geodesic' % a1)
    tick('part 2')
    # ================================================================================== (3) first order in a
    head('(3) first order in a: the Kerr-Schild frame to O(a), the engine\'s Einstein form, the transport over dual numbers [bit]')
    p5 = (R0, F(0), F(0)); res = {}
    for sgn in (1, -1):
        e5, E5 = kerr_frame_a1(p5, M0, R0, sgn)
        Lie_ = Lie(SQ); Gv = Grav(N, Lie_); S_ = koszul_S(N, SQ, Lie_)
        with trunc(N, xdeg=None, lam=1):
            om5 = omega_closed_form(Gv, e5, S_, NV5, 1)[0]
            if sgn == 1:
                with trunc(N, xdeg=1): R5 = Gv.curvature(om5); Ea, _ = Gv.einstein(None, e5, R5, F(0))
                full = 15; comp0 = [Ea[a].get(full ^ (1 << mu), {}).get(tuple([0] * 5), 0) for a in range(N) for mu in range(N)]
                comp1 = [Ea[a].get(full ^ (1 << mu), {}).get((0, 0, 0, 0, 1), 0) for a in range(N) for mu in range(N)]
                Rnz = any(R5[A].get(m, {}).get((0, 0, 0, 0, 1), 0) for A in range(Gv.G) for m in R5[A])
                chk('bit', all(v == 0 for v in comp0 + comp1) and Rnz, 'the frame to first order in a solves the vacuum equation: E_a(0) = 0 on all 16 components at p = (196, 0, 0), at order a^0 and a^1 (the curvature has a non-zero a^1 part)')
        omd = [{m: to_dual(q) for m, q in om5[A].items()} for A in range(Gv.G)]; Ed = [[to_dual(E5[mu][a]) for a in range(N)] for mu in range(N)]
        ed = [{m: to_dual(q) for m, q in e5[A].items()} for A in range(N)]
        Om = Du(W, -sgn * W * W)                                                       # Omega = W/(1 + sgn a W) to first order
        chi = [Du(1), Du(), R0 * Om, Du()]; c0 = [sum((ed[A].get(1 << mu, {}).get((0, 0, 0, 0), Du()) * chi[mu] for mu in range(N)), Du()) for A in range(N)]
        ut = dsqrt_inv(GY.eta(c0, c0)); u0 = [ut * x for x in c0]
        utr = Du(F(14, 11), F(14, 11) * sgn * W * (1 - F(196, 121)))
        J, z = orient_J(u0); basis = [[du(int(i == a)) for i in range(N)] for a in range(N)]
        d, U, V = transport_dual(Gv, omd, Ed, u0, basis)
        rot = Om * ut; Rz = GY.mat_series(KZ, rot)
        geo = all(U[c] == GY.mser_apply(Rz, u0)[c] for c in range(N))
        orbit = [[Du(), ut, Du()], [Du(), Du(), -R0 * rot * rot / 2], [Du(), R0 * rot, Du()], [Du()] * 3]
        geo &= all(d[mu] == orbit[mu] for mu in range(N))
        w = fit_rate(V, J, rot); pred = GY.mser_mul(Rz, GY.mat_series(J, -w))
        okS = all(V[a][c] == GY.mser_apply(pred, basis[a])[c] for a in range(N) for c in range(N))
        turn = 1 - w / rot; res[sgn] = (geo, ut == utr, okS, w, turn)
    geo, okut, okS, w, turn = res[1]
    chk('bit', geo and okut, 'first order in a: d_t + Omega d_phi with Omega = W (1 - aW) is carried as a geodesic tangent to order tau^2; u^t from the frame = %s, the recalled form to first order in a' % utr)
    chk('bit', okS and w == Du(W, 0), 'first order in a: the carried frame vectors match R_z(Omega u^t tau) exp(-w tau J) S(0) to order tau^2 with w = %s: the proper rate has no a-linear part' % w)
    target = COEF if FAULT != 'SCHIFF' else COEF_SCHIFF
    chk('bit', turn == Du(F(3, 14), target), 'the turn per orbit = (%s) of 2 pi: the a-linear coefficient is -(5/11)/r = -2 pi (a/r) sqrt(M/r)/sqrt(1 - 3M/r) per orbit' % turn)
    chk('ctl', COEF != COEF_SCHIFF and COEF / COEF_SCHIFF == F(14, 11) == GY.UT, 'Schiff\'s coefficient -(5/14)/r = %s differs from the engine\'s %s by the factor 14/11 = 1/sqrt(1 - 3M/r) = u^t(a = 0): Schiff\'s term is its weak-field limit' % (COEF_SCHIFF, COEF))
    geo_r, okut_r, okS_r, w_r, turn_r = res[-1]
    chk('bit', geo_r and okut_r and okS_r and w_r == Du(W, 0) and turn_r == Du(F(3, 14), -COEF), 'the spin reversed (l with -a, Omega = W (1 + aW)): the same proper rate and the a-linear coefficient +(5/11)/r: the dragging term is odd in a (r and f are even in a)')
    tick('part 3')
    # ================================================================================== (4) [std]
    head('(4) the float route: Boyer-Lindquist Christoffel symbols, geodesic and parallel transport over one orbit (scipy) [std]')
    Mr = 25 / 196; tol = 1e-8
    for aM in (0.0, 0.2, -0.2):
        tn, rdev = bl_run(Mr, aM); cf = closed_turn(Mr, aM)
        chk('std', abs(tn - cf) < tol and rdev < 1e-9, 'a/M = %+.1f: turn per orbit %.12f of 2 pi = 1 - sqrt(1 - 3M/r + 2a sqrt(M/r^3)) = %.12f (|diff| < 1e-8); r stays on the circle (%.1e)' % (aM, tn, cf, rdev))
        if aM != 0:
            lin1 = 3 / 14 + float(COEF * M0) * aM; sch = 3 / 14 + float(COEF_SCHIFF * M0) * aM
            print('    a/M = %+.1f: closed form %.6f, engine first order %.6f, Schiff first order %.6f' % (aM, cf, lin1, sch))
    tn63, _ = bl_run(Mr, 0.63)
    chk('bit==std', abs(tn63 - float(F(5, 28))) < tol, 'a/M = 63/100 (a = 63/4 at M = 25): the scipy turn %.12f = the engine\'s exact 5/28 = %.12f' % (tn63, 5 / 28))
    h = 1 / 500; tp, _ = bl_run(Mr, h); tm, _ = bl_run(Mr, -h); der = (tp - tm) / (2 * h)
    want = float(target * M0)
    chk('bit==std', abs(der - want) < 1e-4 * abs(want), 'd(turn/2 pi)/d(a/M) at a = 0 by central differences (a/M = +-1/500): %.8f = the engine\'s -(5/11)(M/r) = %.8f' % (der, want))
    sw = float(COEF_SCHIFF * M0); chk('ctl', abs(der - sw) > 1e-2 * abs(sw), 'the same derivative is %.1f%% away from Schiff\'s -(5/14)(M/r) = %.6f' % (100 * abs(der / sw - 1), sw))
    tf, _ = bl_run(Mr, 0.2, om_fac=1.1, fw=True)
    chk('ctl', abs(tf - closed_turn(Mr, 0.2)) > 1e-3, 'a/M = 1/5: Fermi-Walker transport along the circle with 11/10 of the geodesic Omega (not a geodesic, its acceleration enters) turns by %.6f of 2 pi, not %.6f' % (tf, closed_turn(Mr, 0.2)))
    tick('part 4')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GM-LT' + ('-' + FAULT if FAULT else ''))
