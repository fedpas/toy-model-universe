#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""YM-NAB.  A non-abelian source of gravity that is not an embedded abelian field: the meron on the Einstein static universe R x S^3.
    python3 ym_nonabelian_source.py [--fault LAM14|FLAT|NOLAM|SIGN]

 Frame (signature (+,-,-,-)): e^0 = dt, e^(i+1) = R theta^i, theta = theta^i e_i = q^-1 dq the Maurer-Cartan form of S^3 = SU(2) (unit quaternions, e_0, e_1, e_2 = i, j, k) in Cayley
 coordinates q = (1 + y)(1 - y)^-1: theta = 2 (1 - y) dy (1 + y)/(1 + |y|^2)^2, exact jets of degree 2 at rational points (0, y0). The unit 3-sphere has the metric sum (theta^i)^2.
 Field: A^C = 2 lambda theta^C on the engine's so(3) (Lie([-1]*3), (1/2) f = eps): A = lambda q^-1 dq. Maurer-Cartan gives F = (lambda^2 - lambda) (1/2) eps Theta Theta (Theta = 2 theta), so
 F = 0 at lambda = 0, 1 (lambda = 1 is pure gauge); the meron is lambda = 1/2 (Hosotani 1984, the exact Einstein-Yang-Mills solution on the Einstein static universe, recalled; the paper
 is not in the package: everything is computed here).
 [bit]  the engine's omega (A3 closed form), R, E_a(c) on the frame; the so(3) curvature of A, the frame star (g2_hodge.hodge_form) and D_bivector: D*F = 0 at the point; the covariant route
        of ym_matter_gravity.py part G (nabla^a F^C_ab + (1/2) f A^A_a F^B_ab, g2_hodge.D_two_index, which reads the h table); the stress T = -(1/2) sum_c F^c a F^c
        (ym_matter_gravity.ym_stress_at_point); E_a(0) + kappa T_a + c Y_a = 0 solved exactly for (kappa, c), Y_a = E_a(1) - E_a(0) the engine's cosmological 3-form (E_a(c) reads
        G - 3c delta: Lambda = 3c in G - Lambda delta = kappa T); the rank of the colour-by-pair matrix of F; 7 points (R, y0).
 [std]  numpy in hyperspherical coordinates (chi, th, ph): metric diag(1, -R^2, -R^2 sin^2 chi, -R^2 sin^2 chi sin^2 th), g = cos chi - i sin chi n.sigma, A_mu = (1/2) g^-1 d_mu g (closed form),
        F by five-point differences, the Yang-Mills residual (1/sqrt|g|) d_mu (sqrt|g| F^mu nu) + [A_mu, F^mu nu], the textbook stress sum_C (-F^C mu a F^C_nu a + (1/4) delta F^C.F^C),
        the Einstein tensor from Christoffel symbols by differences; kappa and Lambda by least squares from G^mu_nu - Lambda delta = kappa T^mu_nu.
 [bit==std] kappa, Lambda, rho and the Einstein tensor at the radii both routes ran.
 Controls (--fault puts each into the main check): LAM14 lambda = 1/4 (the residual is proportional to lambda (lambda - 1)(2 lambda - 1)); FLAT the flat frame (no solution with kappa != 0);
 NOLAM Lambda = 0 (no solution); SIGN the stress with the opposite overall sign (kappa < 0)."""
import os, sys, itertools, math, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import ym_matter_gravity as YG
import numpy as np

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'LAM14', 'FLAT', 'NOLAM', 'SIGN'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N = 4; SQ = LORENTZ(4)
PTS = [(F(1), (F(0), F(0), F(0))), (F(2), (F(1, 2), F(0), F(0))), (F(3, 2), (F(1, 3), F(-1, 2), F(1, 4))), (F(1, 3), (F(2), F(1), F(-1))),
       (F(5), (F(-1, 5), F(3, 7), F(0))), (F(7, 4), (F(1), F(1), F(1))), (F(2, 5), (F(0), F(-2, 3), F(1, 2)))]
LAM = F(1, 4) if FAULT == 'LAM14' else F(1, 2)
def eps3(i, j, k): return H.perm_sign([i, j, k]) if len({i, j, k}) == 3 else 0

# ------------------------------------------------------------------------------------------------ [bit] the frame of R x S^3 and the field
def s3_theta(y0):
    """theta^i_m (coefficient of dy^m, m = 0..2) as jets of degree 2 at y0: 2 [(1 - |y|^2) delta_im + 2 y_i y_m + 2 eps_imk y_k]/(1 + |y|^2)^2"""
    nv = 4; Y = [lin((F(1), const(nv, y0[i])), (F(1), var(nv, i + 1))) for i in range(3)]
    y2 = lin(*[(F(1), sp_mul(Y[i], Y[i], 2, 4)) for i in range(3)]); n0 = sum(c * c for c in y0); Q0 = 1 + n0
    u = scale(padd(y2, const(nv, n0), -1), 1 / Q0); inv2 = scale(lin((F(1), const(nv, 1)), (F(-2), u), (F(3), sp_mul(u, u, 2, 4))), 1 / Q0 ** 2)
    th = []
    for i in range(3):
        row = []
        for m in range(3):
            t = lin((F(int(i == m)), const(nv, 1)), (F(-int(i == m)), y2), (F(2), sp_mul(Y[i], Y[m], 2, 4)), *[(F(2 * eps3(i, m, k)), Y[k]) for k in range(3) if eps3(i, m, k)])
            row.append(scale(sp_mul(t, inv2, 2, 4), 2))
        th.append(row)
    return th
def s3_frame(R, th): return [{1: const(4, 1)}] + [{1 << (m + 1): scale(th[i][m], R) for m in range(3) if th[i][m]} for i in range(3)]
def flat_frame(): return [{1 << a: const(4, 1)} for a in range(4)]
def meron(th, lam): return [{1 << (m + 1): scale(th[C][m], 2 * lam) for m in range(3) if th[C][m]} for C in range(3)]
def inv_frame(e):
    with trunc(4, xdeg=2): return inverse_series(frame_matrix(e, 4), 4, 4, 2)[0]
def geometry(GL, S_, e):
    om, R_ = engine_om_R(GL, e, S_, 4); E0c = engine_E_from_R(GL, e, R_, 4, 0); E1c = engine_E_from_R(GL, e, R_, 4, 1)
    return om, E0c, {k: E1c[k] - E0c[k] for k in E0c}
def ym_on_frame(G3, GL, A, e, E):
    with trunc(4, xdeg=2):
        Fc = G3.curvature(A); Fab = [H.frame_components(x, E, 4) for x in Fc]; SF = [H.hodge_form(x, e, E, GL.Fm, SQ, 4) for x in Fc]; DSF = G3.D_bivector(A, SF)
    res = [at0(q, 4) for x in DSF for q in x.values()]
    Fls = [{(a, b): at0(Fx.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)} for Fx in Fab]
    return Fc, Fab, Fls, res
def covariant_route(GL, G3, om, A, Fab, E):
    """nabla^a F^C_ab + (1/2) f_AB^C A^A_a F^B_ab at the point (ym_matter_gravity part G): with the engine's omega, and with omega = 0"""
    E0m = [[at0(E[mu][a], 4) for a in range(4)] for mu in range(4)]
    Af = [[sum(at0(A[C].get(1 << mu, {}), 4) * E0m[mu][a] for mu in range(4)) for a in range(4)] for C in range(3)]
    Fv = lambda C, a, b: (at0(Fab[C].get((1 << min(a, b)) | (1 << max(a, b)), {}), 4) * (1 if a < b else -1)) if a != b else 0
    out = []; out0 = []
    for C in range(3):
        full = {(a, b): (Fab[C].get((1 << a) | (1 << b), {}) if a < b else scale(Fab[C].get((1 << b) | (1 << a), {}), -1)) for a in range(4) for b in range(4) if a != b}
        with trunc(4, xdeg=1): DF = H.D_two_index(GL, om, full, 4); DF0 = H.D_two_index(GL, [{} for _ in range(GL.G)], full, 4)
        gauge = [sum(SQ[a] * F(f, 2) * Af[P_][a] * Fv(Q_, a, b) for (P_, Q_), (C_, f) in G3.L.f.items() if C_ == C for a in range(4)) for b in range(4)]
        out += [x + y for x, y in zip(H.frame_divergence_at0(DF, E, SQ, 4), gauge)]; out0 += [x + y for x, y in zip(H.frame_divergence_at0(DF0, E, SQ, 4), gauge)]
    return out, out0
def solve_kc(E0c, Tc, Yc, use_c=True):
    keys = sorted(E0c); rows = [[Tc[k], Yc[k]] if use_c else [Tc[k]] for k in keys]; rhs = [-E0c[k] for k in keys]
    w, rank, nvar, cons = solve_exact(rows, rhs); return (w if cons and rank == nvar else None), rank, cons

# ------------------------------------------------------------------------------------------------ [std] numpy, hyperspherical coordinates
SIG = [np.array([[0, 1], [1, 0]], dtype=complex), np.array([[0, -1j], [1j, 0]]), np.array([[1, 0], [0, -1]], dtype=complex)]
TG = [-0.5j * s for s in SIG]                                                    # [T_a, T_b] = eps_abc T_c
def nvec(th, ph): return np.array([math.sin(th) * math.cos(ph), math.sin(th) * math.sin(ph), math.cos(th)])
def gmat(x):
    chi, th, ph = x[1], x[2], x[3]; n = nvec(th, ph); return math.cos(chi) * np.eye(2) - 1j * math.sin(chi) * sum(n[i] * SIG[i] for i in range(3))
def dgmat(x):
    chi, th, ph = x[1], x[2], x[3]; n = nvec(th, ph)
    dn_th = np.array([math.cos(th) * math.cos(ph), math.cos(th) * math.sin(ph), -math.sin(th)]); dn_ph = np.array([-math.sin(th) * math.sin(ph), math.sin(th) * math.cos(ph), 0.0])
    ns = lambda v: sum(v[i] * SIG[i] for i in range(3))
    return [np.zeros((2, 2), dtype=complex), -math.sin(chi) * np.eye(2) - 1j * math.cos(chi) * ns(n), -1j * math.sin(chi) * ns(dn_th), -1j * math.sin(chi) * ns(dn_ph)]
def A_std(x, lam=0.5):
    gi = gmat(x).conj().T; return [lam * gi @ d for d in dgmat(x)]
def F_std(x, lam=0.5, h=1e-3):
    dA = [[None] * 4 for _ in range(4)]
    for m in range(4):
        u = np.zeros(4); u[m] = h; Ap2, Ap1, Am1, Am2 = A_std(x + 2 * u, lam), A_std(x + u, lam), A_std(x - u, lam), A_std(x - 2 * u, lam)
        for n in range(4): dA[m][n] = (-Ap2[n] + 8 * Ap1[n] - 8 * Am1[n] + Am2[n]) / (12 * h)
    Av = A_std(x, lam); return [[dA[m][n] - dA[n][m] + Av[m] @ Av[n] - Av[n] @ Av[m] for n in range(4)] for m in range(4)]
def gdiag(x, R): return np.array([1.0, -R * R, -R * R * math.sin(x[1]) ** 2, -R * R * math.sin(x[1]) ** 2 * math.sin(x[2]) ** 2])
def ym_std(x, R, lam=0.5, h=1e-2):
    def J(y):                                                                    # sqrt|g| F^{mu nu}
        gd = gdiag(y, R); Fy = F_std(y, lam); sg = math.sqrt(abs(np.prod(gd)))
        return [[sg * Fy[m][n] / (gd[m] * gd[n]) for n in range(4)] for m in range(4)]
    dJ = [None] * 4
    for m in range(4):
        u = np.zeros(4); u[m] = h; a, b, c, d = J(x + 2 * u), J(x + u), J(x - u), J(x - 2 * u)
        dJ[m] = [(-a[m][n] + 8 * b[m][n] - 8 * c[m][n] + d[m][n]) / (12 * h) for n in range(4)]
    gd = gdiag(x, R); sg = math.sqrt(abs(np.prod(gd))); Fx = F_std(x, lam); Av = A_std(x, lam)
    return max(float(np.abs(sum(dJ[m][n] for m in range(4)) / sg + sum(Av[m] @ (Fx[m][n] / (gd[m] * gd[n])) - (Fx[m][n] / (gd[m] * gd[n])) @ Av[m] for m in range(4))).max()) for n in range(4))
def T_std(x, R):
    gd = gdiag(x, R); Fx = F_std(x); comp = lambda X: np.array([float(np.real(-2 * np.trace(TG[c] @ X))) for c in range(3)])
    Fc = [[comp(Fx[m][n]) for n in range(4)] for m in range(4)]; F2 = sum(Fc[a][b] @ Fc[a][b] / (gd[a] * gd[b]) for a in range(4) for b in range(4))
    return np.array([[-sum(Fc[m][a] @ Fc[n][a] / (gd[m] * gd[a]) for a in range(4)) + (F2 / 4 if m == n else 0.0) for n in range(4)] for m in range(4)])
def G_std(x, R, h1=1e-4, h2=1e-3):
    def Gam(y):
        gd = gdiag(y, R); dg = np.zeros((4, 4))
        for k in range(4):
            u = np.zeros(4); u[k] = h1; dg[k] = (-gdiag(y + 2 * u, R) + 8 * gdiag(y + u, R) - 8 * gdiag(y - u, R) + gdiag(y - 2 * u, R)) / (12 * h1)
        G = np.zeros((4, 4, 4))
        for l in range(4):
            for m in range(4):
                for n in range(4):
                    G[l, m, n] = 0.5 / gd[l] * ((dg[m, l] if l == n else 0) + (dg[n, l] if l == m else 0) - (dg[l, m] if m == n else 0))
        return G
    G0 = Gam(x); dG = np.zeros((4, 4, 4, 4))
    for k in range(4):
        u = np.zeros(4); u[k] = h2; dG[k] = (-Gam(x + 2 * u) + 8 * Gam(x + u) - 8 * Gam(x - u) + Gam(x - 2 * u)) / (12 * h2)
    Rm = np.einsum('mrns->rsmn', dG) - np.einsum('nrms->rsmn', dG) + np.einsum('rml,lns->rsmn', G0, G0) - np.einsum('rnl,lms->rsmn', G0, G0)
    ric = np.einsum('rsrn->sn', Rm); gd = gdiag(x, R); Rs = sum(ric[s, s] / gd[s] for s in range(4))
    return np.array([[ric[m, n] / gd[m] - (0.5 * Rs if m == n else 0) for n in range(4)] for m in range(4)])

def main():
    head('YM-NAB: the meron A = lambda q^-1 dq (lambda = %s) on the Einstein static universe R x S^3' % LAM + (' [fault %s]' % FAULT if FAULT else ''))
    LL = Lie(SQ); GL = Grav(4, LL); S_ = koszul_S(4, SQ, LL); L3 = Lie([-1] * 3); G3 = Grav(4, L3)
    okYM = okCov = True; om0_reads = False; okT = okK = okG = okRank = okComm = okUnique = okNoL = okSign = True; KAP = {}
    for R, y0 in PTS:
        th = s3_theta(y0); e = s3_frame(R, th); E = inv_frame(e); om, E0c, Yc = geometry(GL, S_, e)
        e0, E0m, det = E0_of(e, 4, 4); Gm = mixed_from_components(E0c, e0, det, 4, s=-1)
        okG &= all(Gm[b][a] == ((3 if a == 0 else 1) / R ** 2 if a == b else 0) for a in range(4) for b in range(4))
        A = meron(th, LAM); Fc, Fab, Fls, res = ym_on_frame(G3, GL, A, e, E); okYM &= all(v == 0 for v in res)
        cov, cov0 = covariant_route(GL, G3, om, A, Fab, E); okCov &= all(v == 0 for v in cov); om0_reads |= any(v != 0 for v in cov0)
        T = YG.ym_stress_at_point(Fls, F(1, 2) if FAULT == 'SIGN' else F(-1, 2)); rho = T[0][0]
        okT &= all(T[b][a] == 0 for a in range(4) for b in range(4) if a != b) and rho == F(3, 2) / R ** 4 and all(T[i][i] == -rho / 3 for i in (1, 2, 3))
        with trunc(4, xdeg=1): Ta = H.stress_forms(T, H.theta_forms(e, GL.Fm, 4), GL.Fm)
        Tc = einstein_components(Ta, 4, 4)
        if FAULT == 'FLAT':
            ef = flat_frame(); _, E0c, Yc = geometry(GL, S_, ef)
            with trunc(4, xdeg=1): Tc = einstein_components(H.stress_forms(T, H.theta_forms(ef, GL.Fm, 4), GL.Fm), 4, 4)
        w, rk, cons = solve_kc(E0c, Tc, Yc, use_c=(FAULT != 'NOLAM'))
        okUnique &= w is not None and len(w) == 2; KAP[R] = w
        okK &= w is not None and len(w) == 2 and w[0] == R * R and w[1] == 1 / (2 * R * R)
        Mx = [[Fls[C][pr] for pr in sorted(Fls[C])] for C in range(3)]; okRank &= rank_exact(Mx) == 3
        v12 = [Fls[C][(1, 2)] for C in range(3)]; v23 = [Fls[C][(2, 3)] for C in range(3)]
        okComm &= any(sum(eps3(a, b, c) * v12[a] * v23[b] for a in range(3) for b in range(3)) != 0 for c in range(3))
        okNoL &= solve_kc(E0c, Tc, Yc, use_c=False)[0] is None
        if FAULT is None: ws = solve_kc(E0c, {k: -v for k, v in Tc.items()}, Yc)[0]; okSign &= ws is not None and ws[0] == -R * R
    tick('the 7 points')
    pts = ', '.join('(%s; %s)' % (R, ', '.join(map(str, y))) for R, y in PTS)
    chk('bit', okG, 'the engine\'s Einstein form on R x S^3 reads G^b_a = diag(3, 1, 1, 1)/R^2 (mixed, A4 reading) at the 7 points (R; y0) = %s' % pts)
    chk('bit', okYM, 'lambda = %s: D*F = 0 at the 7 points on the curved frame (form route: D_bivector of the frame star)' % LAM)
    chk('bit', okCov, 'lambda = %s: nabla^a F^C_ab + (1/2) f A^A_a F^B_ab = 0 at the 7 points (covariant route, the engine\'s omega and D_two_index)' % LAM)
    print('    finding: with omega = 0 the covariant route gives %s at the points: %s' % ('a non-zero divergence' if om0_reads else 'zero as well', 'the route reads the connection' if om0_reads else 'it does not read the connection here'))
    chk('bit', okT, 'the stress -(1/2) sum_c F^c a F^c is diagonal with T^0_0 = rho = 3/(2R^4) and T^i_i = -rho/3 at the 7 points: homogeneous, isotropic, rho = 3p (traceless)')
    chk('bit', okUnique and okK, 'E_a(0) + kappa T_a + c Y_a = 0 on all 16 components has the unique solution kappa = R^2, c = 1/(2R^2) at the 7 points: Lambda = 3c = 3/(2R^2) and kappa rho = Lambda = 3/(2R^2)')
    chk('bit', okRank and okComm, 'not an embedded abelian field: the 3 x 6 matrix F^C_ab has rank 3 at the 7 points (the components span su(2), a gauge-invariant statement; an embedded abelian field has rank <= 1), and [F_12, F_23] != 0')
    chk('ctl', okNoL, 'Lambda = 0: E_a(0) + kappa T_a = 0 has no solution at any of the 7 points')
    if FAULT is None: chk('ctl', okSign, 'the stress with the opposite overall sign: the solve gives kappa = -R^2 < 0 at the 7 points (repulsive, against the input sign)')
    head('controls on one point (R = 2, y0 = (1/2, 0, 0)): the lambda scan, the flat frame [bit] [ctl]')
    R, y0 = PTS[1]; th = s3_theta(y0); e = s3_frame(R, th); E = inv_frame(e); rs = {}; flat1 = None
    for lam in (F(0), F(1, 4), F(1, 2), F(3, 4), F(1), F(3, 2)):
        Fc, _, _, res = ym_on_frame(G3, GL, meron(th, lam), e, E); rs[lam] = res
        if lam == 1: flat1 = all(not {k: v for k, v in p.items() if sum(k) <= 1} for x in Fc for p in x.values())
    zero = sorted(l for l, r in rs.items() if all(v == 0 for v in r)); prop = set()
    for l in (F(1, 4), F(3, 4), F(3, 2)):
        c_ = l * (l - 1) * (2 * l - 1); prop.add(tuple(v / c_ for v in rs[l]))
    chk('ctl', zero == [0, F(1, 2), 1] and len(prop) == 1 and flat1, 'A = lambda q^-1 dq solves D*F = 0 exactly for lambda in {%s} of {0, 1/4, 1/2, 3/4, 1, 3/2}; the residual is lambda (lambda - 1)(2 lambda - 1) times one fixed 3-form; at lambda = 1, F = 0 (pure gauge)' % ', '.join(map(str, zero)))
    T = YG.ym_stress_at_point(ym_on_frame(G3, GL, meron(th, F(1, 2)), e, E)[2]); ef = flat_frame(); _, Ef0, Yf = geometry(GL, S_, ef)
    with trunc(4, xdeg=1): Tf = einstein_components(H.stress_forms(T, H.theta_forms(ef, GL.Fm, 4), GL.Fm), 4, 4)
    keys = sorted(Ef0); rkf = rank_exact([[Tf[k], Yf[k]] for k in keys])
    chk('ctl', all(v == 0 for v in Ef0.values()) and rkf == 2, 'the flat frame (the R -> infinity limit of the geometry): E_a = 0, and kappa T_a + c Y_a = 0 forces kappa = c = 0 (rank 2): no static solution with this source')
    tick('controls')
    head('[std] numpy, hyperspherical coordinates: the Yang-Mills residual, the stress, the Einstein tensor, the fit of (kappa, Lambda) [bit==std]')
    xs = [np.array([0.3, 0.7, 1.1, 0.4]), np.array([-0.5, 1.3, 0.6, 2.0]), np.array([1.0, 2.2, 2.0, -1.0])]
    worst_ym = 0.0; fits = {}; worst_fit = 0.0; rhos = {}; Gs = {}
    for R in (2.0, 1.5):
        for x in xs:
            worst_ym = max(worst_ym, ym_std(x, R)); Tm = T_std(x, R); Gm = G_std(x, R)
            Mx = np.array([[Tm[m, n], float(m == n)] for m in range(4) for n in range(4)]); b = np.array([Gm[m, n] for m in range(4) for n in range(4)])
            sol, *_ = np.linalg.lstsq(Mx, b, rcond=None); worst_fit = max(worst_fit, float(np.abs(Mx @ sol - b).max())); fits.setdefault(R, []).append(sol)
            rhos.setdefault(R, []).append(Tm[0, 0]); Gs.setdefault(R, []).append((Gm[0, 0], Gm[1, 1], Gm[2, 2], Gm[3, 3]))
    bad_lam = ym_std(xs[0], 2.0, lam=0.25)
    chk('std', worst_ym < 1e-6, 'lambda = 1/2: the Yang-Mills residual by differences is below %.1e at 3 points for R = 2 and 3/2' % max(worst_ym, 1e-16))
    chk('std', worst_fit < 1e-6, 'G^mu_nu - Lambda delta = kappa T^mu_nu holds with one (kappa, Lambda) per point (least-squares residual %.1e)' % worst_fit)
    chk('ctl', bad_lam > 1e-3, 'lambda = 1/4: the Yang-Mills residual is %.2e' % bad_lam)
    okbs = True
    for R in (2.0, 1.5):
        kb, cb = KAP[F(R).limit_denominator(10)] if KAP.get(F(R).limit_denominator(10)) else (None, None)
        for sol, rho_, g_ in zip(fits[R], rhos[R], Gs[R]):
            okbs &= kb is not None and abs(sol[0] - float(kb)) < 1e-6 * float(kb) and abs(sol[1] - 3 * float(cb)) < 1e-6 and abs(rho_ - 1.5 / R ** 4) < 1e-8
            okbs &= abs(g_[0] - 3 / R ** 2) < 1e-6 and all(abs(v - 1 / R ** 2) < 1e-6 for v in g_[1:])
        print('    R = %s: kappa = %.10f, Lambda = %.10f (bit: kappa = %s, Lambda = 3c = %s), rho = %.10f' % (R, fits[R][0][0], fits[R][0][1], kb, 3 * cb if cb is not None else None, rhos[R][0]))
    chk('bit==std', okbs, 'R = 2, 3/2: kappa = R^2, Lambda = 3c = 3/(2R^2), rho = 3/(2R^4) and G = diag(3, 1, 1, 1)/R^2 from the numbers of both routes (tolerance 1e-6)')
    tick('std')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('YM-NAB' + ('-' + FAULT if FAULT else ''))
