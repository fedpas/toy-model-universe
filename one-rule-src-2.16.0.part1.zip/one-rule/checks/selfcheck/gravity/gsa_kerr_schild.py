#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSA-KS.  Kerr-Schild frames e^a = dx^a - f l^a l with an ARBITRARY profile f: the engine's mixed Einstein tensor is linear in f when l is a null geodesic,
 and the vacuum members of a finite family of profiles on Kerr's l.   python3 gsa_kerr_schild.py [--fault nongeodesic|wrong_l|no_r1]

 Frames  g = eta - 2 f l l, signature (+,-,-,-), e^a = dx^a - f l^a l_mu dx^mu, inverse E = delta + f l^mu l_a (exact because l is null).
   Kerr's l (g2_kerr: l = dt + ((r x + a y) dx + (r y - a x) dy)/(r^2 + a^2) + z dz/r, M = 5, a = 3, exact 2-jets at rational points);
   a geodesic shearing l: the cylindrical l = dt + (x dx + y dy)/rho_c (rho_c = sqrt(x^2 + y^2), straight rays, shear != 0);
   a null l that is not geodesic: l = dt + n.dx, n = ((1 - w^2), 2w, 0)/(1 + w^2), w = x/5 (a unit field that turns along itself).
   f: random polynomial 2-jets in delta = x - p (every monomial of degree <= 2, rational coefficients, fixed seed), stationary.
 [bit]  omega from the A3 closed form, R, E_a(0) (the engine), frame components carried to the coordinates: M^mu_nu = G^mu_nu.
        (1) G(f1 + f2) = G(f1) + G(f2) and G(q f) = q G(f) exactly, all 16 components, for Kerr's l and for the cylindrical l; G(0) = 0.
        (2) the vacuum members of f = P(r, cos th)/(r^2 + a^2 cos^2 th), P in span{r^j cos^2k th: j = -1..2, k = 0, 1} (8 profiles; Kerr is P = M r):
            the null space of the 64 x 8 system E_a(0) = 0 at 4 points (linear because of (1)).
 [std]  the Christoffel route on g = e^T eta e for the same frames (linearity of its mixed Einstein tensor on one sample per l).
 Wires  f1_focusing (Kerr's l geodesic, affine, shear-free and twisting at 3 points with the engine's connection); f2_first_law and f3_kn_horizons (with the
        Maxwell field A = (Q r^3/(r^4 + a^2 z^2)) l the profile (M r - s) r^2/(r^4 + a^2 z^2) has E_a = lambda T_a with one lambda: Kerr-Newman).
 Controls (each also a --fault NAME that puts the wrong version into a main check and exits 1): nongeodesic (the turning l in the linearity check),
        wrong_l (a + 1/7 in l only: Kerr's f is not vacuum), no_r1 (the family without r^1: no vacuum member).
 Scope  values at rational points, n = 4, exact 2-jets; the theorem that the stationary axisymmetric vacuum solutions of this class are Kerr (Kerr and Schild;
        Debney, Kerr and Schild) is recalled; here only the finite family above is decided."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_kerr as K

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'nongeodesic', 'wrong_l', 'no_r1'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
NV = 4; SQ = LORENTZ(4); M0, A0 = F(5), F(3)
def jm(a, b): return sp_mul(a, b, 2, 4)
def X_(p, i): return lin((F(1), const(NV, p[i - 1])), (F(1), var(NV, i)))

def ks_frame_from(l_up, l_dn, f):
    e = []
    for a in range(4):
        form = {}
        for mu in range(4):
            pol = lin((F(1 if a == mu else 0), const(NV, 1)), (F(-1), jm(jm(f, l_up[a]), l_dn[mu])))
            if pol: form[1 << mu] = pol
        e.append(form)
    return e
def kerr_l(p, a=A0, a_l=None):
    x, y, z = p; R2 = x * x + y * y + z * z - a * a; r = K.rat_sqrt((R2 + K.rat_sqrt(R2 * R2 + 4 * a * a * z * z)) / 2)
    e, E, (lu, ld), dat = K.kerr_ks_frame_jet(p, M0, a, r, a_l=a_l); return lu, ld, dat
def cyl_l(p):
    """l = dt + (x dx + y dy)/rho_c at p with x^2 + y^2 a rational square (2-jets)"""
    x0, y0 = p[0], p[1]; rc0 = K.rat_sqrt(x0 * x0 + y0 * y0); X1, X2 = var(NV, 1), var(NV, 2)
    u = lin((2 / rc0 ** 2, lin((x0, X1), (y0, X2))), (1 / rc0 ** 2, lin((F(1), jm(X1, X1)), (F(1), jm(X2, X2))))); u2 = jm(u, u)
    ir = lin((1 / rc0, const(NV, 1)), (-1 / (2 * rc0), u), (F(3, 8) / rc0, u2))
    n = [jm(X_(p, 1), ir), jm(X_(p, 2), ir), {}]
    return [const(NV, 1)] + [scale(q, -1) for q in n], [const(NV, 1)] + n
def turning_l(p):
    """l = dt + n.dx with n = (1 - w^2, 2w, 0)/(1 + w^2), w = x/5: null, not geodesic"""
    w = scale(X_(p, 1), F(1, 5)); w2 = jm(w, w); den = K.recip2(lin((F(1), const(NV, 1)), (F(1), w2)))
    n = [jm(lin((F(1), const(NV, 1)), (F(-1), w2)), den), jm(scale(w, 2), den), {}]
    return [const(NV, 1)] + [scale(q, -1) for q in n], [const(NV, 1)] + n
def null_ok(lu, ld): return not lin(*[(F(1), jm(lu[m], ld[m])) for m in range(4)])
def geodesic_flat(lu, ld):
    """l^nu d_nu l_mu at the point (flat background, plain derivatives): zero for an affinely parametrised null geodesic"""
    return [sum(at0(lu[n], NV) * at0(sp_der(ld[m], n), NV) for n in range(4)) for m in range(4)]
TF = []
def engine_G(Gv, S, e, torsion=False):
    e0, E0, det = E0_of(e, 4, NV); om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0)
    if torsion:
        with trunc(4, xdeg=0): TF.append(torsion_zero_at0(Gv, om, e, NV))
    Mf = mixed_from_components(comp, e0, det, 4, s=-1)
    return [[sum(E0[m][b] * Mf[b][a] * e0[a][n] for b in range(4) for a in range(4)) for n in range(4)] for m in range(4)], comp
def std_G(e):
    g = std_metric(e, 4, SQ, NV, 2); R1, g0, g0i = std_riemann(g, 4, NV, 1); return std_einstein_mixed(R1, g0, g0i, 4)[0]
def madd(A, B, c=1): return [[A[i][j] + c * B[i][j] for j in range(4)] for i in range(4)]
def mscale(A, c): return [[c * x for x in r] for r in A]
def rand_f(rng):
    mons = [(0, i, j, k) for i in range(3) for j in range(3) for k in range(3) if i + j + k <= 2]
    return {m: F(rng.choice([-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]), rng.randint(1, 7)) for m in mons}
def family(dat, p, drop_r1=False):
    """the 2-jets of r^j (z/r)^(2k)/(r^2 + a^2 (z/r)^2), j = -1..2, k = 0, 1 (labels (j, k))"""
    r = dat['r']; ir = K.recip2(r); z = X_(p, 3); c = jm(z, ir); c2 = jm(c, c)
    Sig = lin((F(1), jm(r, r)), (A0 * A0, c2)); iS = K.recip2(Sig)
    pw = {-1: ir, 0: const(NV, 1), 1: r, 2: jm(r, r)}; out = []
    for j in (-1, 0, 1, 2):
        for k in (0, 1):
            if drop_r1 and (j, k) == (1, 0): continue
            out.append(((j, k), jm(jm(pw[j], c2 if k else const(NV, 1)), iS)))
    return out

def main():
    head('GSA-KS: Kerr-Schild frames with an arbitrary profile f on three null congruences' + (' [fault %s]' % FAULT if FAULT else ''))
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
    from d_probe import d_sign_probe; d_sign_probe()
    rng = random.Random(127)
    KP = [P['p'] for P in K.rational_kerr_points(A0, [F(7), F(20), F(9, 2)], [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5)))])]
    CP = [(F(3), F(4), F(2)), (F(5), F(-12), F(1)), (F(8), F(6), F(-3))]
    TP = [(F(3), F(4), F(2)), (F(2), F(1), F(1)), (F(8), F(6), F(-3))]               # w = x/5 != 1: n.grad n != 0 there
    # ================================================================================== 0 the congruences
    head('0. the three null congruences: null (to the jet order), and l^nu d_nu l_mu at the point (flat background)')
    rows = []
    for nm, mk, pts in (('Kerr l', kerr_l, KP), ('cylindrical l', cyl_l, CP), ('turning l', turning_l, TP)):
        for p in pts:
            lu, ld = mk(p)[:2]; rows.append((nm, null_ok(lu, ld), geodesic_flat(lu, ld)))
    chk('std', all(r[1] for r in rows), 'l^mu l_mu = 0 on every coefficient of degree <= 2 for the three congruences at their 3 points each')
    chk('std', all(all(x == 0 for x in r[2]) for r in rows if r[0] != 'turning l') and all(any(x != 0 for x in r[2]) for r in rows if r[0] == 'turning l'),
        'l^nu d_nu l_mu = 0 at the points for Kerr\'s l and the cylindrical l (affine null geodesics); != 0 for the turning l (not geodesic)')
    tick('part 0')
    # ================================================================================== 1 linearity
    head('1. G(f1 + f2) = G(f1) + G(f2), G(q f) = q G(f), G(0) = 0: the engine\'s mixed Einstein tensor for random 2-jets f, all 16 components')
    res = {}
    for nm, mk, pts in (('Kerr l', kerr_l, KP), ('cylindrical l', cyl_l, CP), ('turning l', turning_l, TP)):
        ok_add = ok_sc = ok_0 = True; nz = False; n = 0
        for p in pts:
            lu, ld = mk(p)[:2]
            if FAULT == 'nongeodesic' and nm == 'Kerr l': lu, ld = turning_l(CP[0])
            f1, f2 = rand_f(rng), rand_f(rng); q = F(rng.choice([-3, 2, 5]), rng.choice([2, 7]))
            G1, _ = engine_G(Gv, S, ks_frame_from(lu, ld, f1), torsion=True); G2, _ = engine_G(Gv, S, ks_frame_from(lu, ld, f2))
            G12, _ = engine_G(Gv, S, ks_frame_from(lu, ld, padd(f1, f2))); Gq, _ = engine_G(Gv, S, ks_frame_from(lu, ld, pscale(f1, q)))
            G0, _ = engine_G(Gv, S, ks_frame_from(lu, ld, {}))
            ok_add &= (G12 == madd(G1, G2)); ok_sc &= (Gq == mscale(G1, q)); ok_0 &= all(x == 0 for r in G0 for x in r); nz |= any(x != 0 for r in G1 for x in r); n += 1
        res[nm] = (ok_add and ok_sc and ok_0 and nz, n)
        if nm != 'turning l':
            p = pts[0]; lu, ld = mk(p)[:2]; f1, f2 = rand_f(rng), rand_f(rng)
            S1, S2, S12 = std_G(ks_frame_from(lu, ld, f1)), std_G(ks_frame_from(lu, ld, f2)), std_G(ks_frame_from(lu, ld, padd(f1, f2)))
            B12, _ = engine_G(Gv, S, ks_frame_from(lu, ld, padd(f1, f2)))
            res[nm + ' std'] = (S12 == madd(S1, S2) and B12 == S12)
    chk('bit', len(TF) == 9 and all(TF), 'the A3 closed-form omega is torsion-free at the 9 sample frames (T^a = de^a + h omega e = 0 with the engine\'s h table): the Einstein form is that of the Levi-Civita connection')
    chk('bit', res['Kerr l'][0], 'Kerr\'s l (M = 5, a = 3 in l), 3 points (r = 7, 20, 9/2): G(f1 + f2) = G(f1) + G(f2), G(q f) = q G(f), G(0) = 0 exactly for random 2-jets f (not solutions): the field equations are linear in f')
    chk('bit', res['cylindrical l'][0], 'the cylindrical l (geodesic, shearing), 3 points: the same linearity: shear-freeness is not needed for it, the geodesic property is')
    chk('bit==std', res['Kerr l std'] and res['cylindrical l std'], 'Christoffel route: its mixed Einstein tensor is additive in f on one sample per geodesic l and equals the engine\'s')
    chk('ctl', not res['turning l'][0], 'the turning l (null, not geodesic), 3 points: the linearity fails (the engine\'s G(f1 + f2) != G(f1) + G(f2) or G(q f) != q G(f))')
    tick('part 1')
    # ================================================================================== 2 the vacuum members of the family
    head('2. f = P(r, cos th)/(r^2 + a^2 cos^2 th), P in span{r^j cos^2k th} (8 profiles): the null space of E_a(0) = 0 at 4 points')
    pts = [P['p'] for P in K.rational_kerr_points(A0, [F(7), F(4)], [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(5, 13), F(12, 13)), (F(3, 5), F(-4, 5)))])]
    cols = None; labels = None
    for p in pts:
        lu, ld, dat = kerr_l(p, a_l=(A0 + F(1, 7) if FAULT == 'wrong_l' else None))
        fam = family(dat, p, drop_r1=(FAULT == 'no_r1'))
        if labels is None: labels = [lab for lab, _ in fam]; cols = [[] for _ in fam]
        for i, (lab, fj) in enumerate(fam):
            _, comp = engine_G(Gv, S, ks_frame_from(lu, ld, fj)); cols[i] += [comp[k] for k in sorted(comp)]
    rows_ = [list(r) for r in zip(*cols)]; rank, nullb = gs.rank_and_null(rows_, len(labels))
    kerr_ix = labels.index((1, 0)) if (1, 0) in labels else None
    only_kerr = len(nullb) == 1 and kerr_ix is not None and all((v != 0) == (i == kerr_ix) for i, v in enumerate(nullb[0]))
    chk('bit', only_kerr and rank == len(labels) - 1, 'rank %d of %d over %d equations (16 components at 4 points): the null space is spanned by P = r alone, f = r/(r^2 + a^2 cos^2 th) = r^3/(r^4 + a^2 z^2): Kerr (any M) is the only vacuum member of the family' % (rank, len(labels), len(rows_)))
    # the same with the profile of mass M0 checked directly, and Kerr-Newman's charge term is not vacuum
    lu, ld, dat = kerr_l(pts[0]); fam = dict(family(dat, pts[0]))
    _, cK = engine_G(Gv, S, ks_frame_from(lu, ld, pscale(fam[(1, 0)], M0))); _, cQ = engine_G(Gv, S, ks_frame_from(lu, ld, fam[(0, 0)]))
    chk('bit', all(v == 0 for v in cK.values()) and any(v != 0 for v in cQ.values()), 'f = M r^3/(r^4 + a^2 z^2) with M = 5 (C2\'s Kerr frame) has E_a = 0; the charge profile s r^2/(r^4 + a^2 z^2) of Kerr-Newman has E_a != 0 (its source is the Maxwell stress, f2_first_law)')
    # controls of part 2
    lw, ldw, dw = kerr_l(pts[0], a_l=A0 + F(1, 7)); famw = dict(family(dw, pts[0]))
    _, cw = engine_G(Gv, S, ks_frame_from(lw, ldw, pscale(famw[(1, 0)], M0)))
    chk('ctl', any(v != 0 for v in cw.values()), 'a + 1/7 in l only (r and f of a = 3): Kerr\'s profile is not vacuum on that l')
    cols2 = [c for lab, c in zip(labels, cols) if lab != (1, 0)]; rk2, nb2 = gs.rank_and_null([list(r) for r in zip(*cols2)], len(cols2))
    chk('ctl', len(nb2) == 0, 'the family without r^1 (7 profiles): rank %d of %d, no vacuum member' % (rk2, len(cols2)))
    tick('part 2')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GSA-KS' + ('-' + FAULT if FAULT else ''))

if __name__ == '__main__': main()
