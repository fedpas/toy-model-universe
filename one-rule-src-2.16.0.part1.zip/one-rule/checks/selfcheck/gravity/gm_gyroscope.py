#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-GYRO.  Geodetic precession: a spin carried along a circular geodesic of Schwarzschild turns by 2 pi (1 - sqrt(1 - 3M/r)) per orbit.   python3 gm_gyroscope.py

 Derivation: along a geodesic Fermi-Walker transport is parallel transport. The circular orbit u = u^t (d_t + Omega d_phi), Omega^2 = M/r^3, u^t = 1/sqrt(1 - 3M/r) (recalled), is an orbit of the
 helical isometry d_t + Omega d_phi; the Kerr-Schild frame is invariant under t and covariant under rotations, so a vector dragged by the isometry has frame components R_z(Omega t) V(0).
 Relative to the dragged (co-rotating) frame the carried spin turns in the plane orthogonal to u and e_z at the proper rate Omega against the orbital sense:
 S(tau) = R_z(Omega u^t tau) exp(-Omega tau J) S(0), J = *(u ^ e_z) (a unit rotation generator, rational). Per orbit (tau = 2 pi/(Omega u^t)) the net turn against the fixed directions is
 2 pi - 2 pi/u^t = 2 pi (1 - sqrt(1 - 3M/r)).
 Orbit of the exact route: M = 25, r = 196 (M/r = 25/196): sqrt(M/r) = 5/14, sqrt(1 - 3M/r) = 11/14, Omega = 5/2744, u^t = 14/11, 3 pi/7 per orbit. (M/r = 16/75 gives 1 - 3M/r = 9/25 and
 4 pi/5, but the orbital speed sqrt(M/r) = 4/(5 sqrt 3) is irrational: that orbit runs on the float route.)
 [bit]  the Kerr-Schild frame (b1lib.ks_frame_jet, exact 2-jets at p = (r, 0, 0)), the A3 closed-form omega (1-jet), the engine's h table: du/dtau = -h omega(dx/dtau) u,
        dS/dtau = -h omega(dx/dtau) S, dx/dtau = E u as exact power series in tau (Picard iteration; exact to order 2, the order the jets support); u(tau) = R_z(Omega u^t tau) u(0) (the orbit
        is a geodesic) and S(tau) = R_z(Omega u^t tau) exp(-Omega tau J) S(0) for the four frame vectors S(0) = e_a, to order 2; the orbit x(tau) to order 2.
 [std]  scipy: parallel transport with the Schwarzschild Christoffel symbols (closed form, recalled) over one orbit at M/r = 25/196 and 16/75; the angle of S against the co-rotating radial
        direction ends at -2 pi sqrt(1 - 3M/r), so the turn per orbit is 3 pi/7 and 4 pi/5.
 [bit==std] the proper rate -Omega of the exact series = the rate of the integration.
 Controls: a circular orbit with 11/10 of the Kepler Omega (not a geodesic): the carried velocity leaves the circle at first order; the closed form with 2M/r in place of 3M/r misses the
 integrated angle; the co-rotating rate Omega u^t in place of Omega fails the exact series.
 Not here: the Lense-Thirring term on a Kerr frame."""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
from scipy.integrate import solve_ivp

N = 4; SQ = LORENTZ(4); K = 2
M0, R0 = F(25), F(196); OM = F(5, 2744); UT = F(14, 11)
# ------------------------------------------------------------------------------------------------ series in tau (lists of Fractions, truncated at order K)
def s_mul(a, b): return [sum(a[i] * b[k - i] for i in range(k + 1)) for k in range(K + 1)]
def s_add(a, b, c=1): return [x + c * y for x, y in zip(a, b)]
def s_int(a): return [F(0)] + [a[k - 1] / k for k in range(1, K + 1)]
def s_der(a): return [a[k + 1] * (k + 1) for k in range(K)] + [F(0)]
def s_const(c): return [F(c)] + [F(0)] * K
def s_sum(items):
    out = s_const(0)
    for x in items: out = s_add(out, x)
    return out
def compose(p, d):
    """the polynomial p(delta) along delta(tau) = d (series without constant term)"""
    out = s_const(0)
    for ex, v in p.items():
        t = s_const(v)
        for i, k in enumerate(ex[:N]):
            for _ in range(k): t = s_mul(t, d[i])
        out = s_add(out, t)
    return out
def transport(Gv, om, E, u0, vecs, iters=K + 2):
    """[bit] Picard iteration for x, u and the carried vectors along the geodesic from p with frame velocity u0"""
    d = [s_const(0) for _ in range(N)]; U = [s_const(c) for c in u0]; V = [[s_const(c) for c in v] for v in vecs]
    h = list(Gv.L.h.items())
    for _ in range(iters):
        Ed = [[compose(E[mu][a], d) for a in range(N)] for mu in range(N)]
        xdot = [s_sum(s_mul(Ed[mu][a], U[a]) for a in range(N)) for mu in range(N)]
        omu = [s_sum(s_mul(compose(om[A].get(1 << mu, {}), d), xdot[mu]) for mu in range(N)) for A in range(Gv.G)]
        def rhs(X):
            out = [s_const(0) for _ in range(N)]
            for (A, b), (c, hv) in h: out[c] = s_add(out[c], s_mul(omu[A], X[b]), -hv)
            return out
        nU = [s_add(s_const(u0[c]), s_int(r)) for c, r in enumerate(rhs(U))]
        nV = [[s_add(s_const(v[c]), s_int(r)) for c, r in enumerate(rhs(X))] for v, X in zip(vecs, V)]
        d = [s_int(x) for x in xdot]; U, V = nU, nV
    return d, U, V
def mat_series(Mgen, rate):
    """exp(rate tau Mgen) to order K, as a list of matrices (coefficients of tau^k)"""
    I = [[F(int(i == j)) for j in range(N)] for i in range(N)]; M2 = [[sum(Mgen[i][k] * Mgen[k][j] for k in range(N)) for j in range(N)] for i in range(N)]
    return [I, [[rate * x for x in r] for r in Mgen], [[rate * rate * x / 2 for x in r] for r in M2]]
def mser_apply(Ms, v):
    """(sum_k M_k tau^k) v for a constant vector v -> list of series per component"""
    return [[sum(Ms[k][i][j] * v[j] for j in range(N)) for k in range(K + 1)] for i in range(N)]
def mser_mul(A, B): return [[[sum(A[i][r][s] * B[k - i][s][c] for i in range(k + 1) for s in range(N)) for c in range(N)] for r in range(N)] for k in range(K + 1)]
def eps4(a, b, c, d):
    p = [a, b, c, d]
    if len(set(p)) < 4: return 0
    s = 1
    for i in range(4):
        for j in range(i + 1, 4):
            if p[i] > p[j]: s = -s
    return s
def dual_generator(u, z):
    """J^a_b = eps^a_{b c d} u^c z^d (indices raised with eta): the rotation generator in the plane orthogonal to u and z"""
    return [[sum(SQ[a] * eps4(a, b, c, dd) * u[c] * z[dd] for c in range(N) for dd in range(N)) for b in range(N)] for a in range(N)]
def eta(v, w): return sum(SQ[a] * v[a] * w[a] for a in range(N))
def mv(Mx, v): return [sum(Mx[i][j] * v[j] for j in range(N)) for i in range(N)]

def std_angle(Mr, nturn=1.0, ratio=3):
    """[std] parallel transport in Schwarzschild coordinates over nturn orbits (M = 1, r = 1/Mr); returns (final unwrapped angle of S against the co-rotating radial direction, rate per tau)"""
    M = 1.0; r = 1.0 / Mr; A = 1 - 2 * M / r; Om = math.sqrt(M / r ** 3); ut = 1 / math.sqrt(1 - 3 * M / r); uph = Om * ut
    def rhs(tau, S):                                                          # S = (S^t, S^r, S^phi), equator
        St, Sr, Sp = S
        dSt = -(M / (r * r * A)) * ut * Sr
        dSr = -(M * A / (r * r)) * ut * St + (r - 2 * M) * uph * Sp
        dSp = -(1 / r) * uph * Sr
        return [dSt, dSr, dSp]
    T = 2 * math.pi / (Om * ut) * nturn
    sol = solve_ivp(rhs, (0, T), [0.0, math.sqrt(A), 0.0], rtol=1e-12, atol=1e-14, dense_output=True)
    ts = np.linspace(0, T, 4001); ang = []
    for tau in ts:
        St, Sr, Sp = sol.sol(tau)
        a_r = Sr / math.sqrt(A)                                               # along the unit radial vector
        # unit vector in the (t, phi) plane orthogonal to u: n = (r uph / sqrt(A), 0, sqrt(A) ut / r) (components t, r, phi); g(n, n) = -1, g(n, u) = 0
        n = np.array([r * uph / math.sqrt(A), 0.0, math.sqrt(A) * ut / r])
        a_p = -(A * St * n[0] - r * r * Sp * n[2])                           # -g(S, n) with g = diag(A, -1/A, -r^2) on (t, r, phi)
        ang.append(math.atan2(a_p, a_r))
    ang = np.unwrap(np.array(ang)); return ang[-1], ang[len(ts) // 4] / ts[len(ts) // 4], Om, ut

def main():
    Lie_ = Lie(SQ); Gv = Grav(N, Lie_); S_ = koszul_S(N, SQ, Lie_)            # built per run
    p = (R0, F(0), F(0)); e, E, (lu, ld) = ks_frame_jet(p, R0, *sds_jets(M0, F(0), R0))
    om = omega_closed_form(Gv, e, S_, N, 1)[0]
    head('(1) the orbit M = 25, r = 196: Omega = 5/2744, u^t = 14/11; the exact series of x, u and the carried frame vectors [bit]')
    chk('bit', OM * OM == M0 / R0 ** 3 and UT * UT * (1 - 3 * M0 / R0) == 1, 'Omega^2 = M/r^3 and (u^t)^2 (1 - 3M/r) = 1 exactly: Omega = %s, u^t = %s, sqrt(M/r) = r Omega = %s' % (OM, UT, R0 * OM))
    ucoord = [UT, F(0), UT * R0 * OM, F(0)]
    u0 = [sum(at0(e[a].get(1 << mu, {}), N) * ucoord[mu] for mu in range(N)) for a in range(N)]
    chk('bit', eta(u0, u0) == 1 and u0[3] == 0, 'frame components of u at p: (%s), eta(u, u) = 1' % ', '.join(map(str, u0)))
    Kz = [[F(0)] * N for _ in range(N)]; Kz[2][1] = F(1); Kz[1][2] = F(-1)           # R_z generator on the frame indices 1, 2
    z = [F(0), F(0), F(0), F(1)]; J = dual_generator(u0, z)
    xr = [F(0), F(1), F(0), F(0)]; nr = [a - eta(xr, u0) * b for a, b in zip(xr, u0)]
    sgn = 1 if -eta(mv(J, nr), [a - eta([F(0), F(0), F(1), F(0)], u0) * b for a, b in zip([F(0), F(0), F(1), F(0)], u0)]) > 0 else -1
    J = [[sgn * x for x in r] for r in J]
    J3 = [[sum(J[i][k] * sum(J[k][l] * J[l][j] for l in range(N)) for k in range(N)) for j in range(N)] for i in range(N)]
    chk('bit', mv(J, u0) == [0] * N and mv(J, z) == [0] * N and J3 == [[-x for x in r] for r in J], 'J = *(u ^ e_z), oriented with the motion: J u = 0, J e_z = 0, J^3 = -J (a unit rotation generator of the plane orthogonal to u and e_z)')
    basis = [[F(int(i == a)) for i in range(N)] for a in range(N)]
    d, U, V = transport(Gv, om, E, u0, basis)
    Rz = mat_series(Kz, OM * UT); Rj = mat_series(J, -OM); Rpred = mser_mul(Rz, Rj)
    upred = mser_apply(Rz, u0)
    chk('bit', all(U[c] == upred[c] for c in range(N)), 'the carried velocity: u(tau) = R_z(Omega u^t tau) u(0) to order tau^2 (first order: the connection at p; second: its derivative along the orbit): the circle is a geodesic')
    orbit = [[F(0), UT, F(0)], [F(0), F(0), -R0 * (OM * UT) ** 2 / 2], [F(0), R0 * OM * UT, F(0)], [F(0)] * 3]
    chk('bit', all(d[mu] == orbit[mu] for mu in range(N)), 'x(tau) - p = (u^t tau, -(r/2)(Omega u^t tau)^2, r Omega u^t tau, 0) to order tau^2: the orbit')
    ok_s = all(V[a][c] == mser_apply(Rpred, basis[a])[c] for a in range(N) for c in range(N))
    chk('bit', ok_s, 'the four carried frame vectors: S(tau) = R_z(Omega u^t tau) exp(-Omega tau J) S(0) to order tau^2: relative to the co-rotating frame the spin turns at the proper rate Omega against the orbit')
    Rbad = mser_mul(Rz, mat_series(J, -OM * UT))
    chk('ctl', not all(V[a][c] == mser_apply(Rbad, basis[a])[c] for a in range(N) for c in range(N)), 'the co-rotating rate Omega u^t in place of Omega does not match the carried vectors')
    per_orbit = 1 - 1 / UT
    chk('bit', per_orbit == F(3, 14), 'per orbit (tau = 2 pi/(Omega u^t)) the spin turns by 2 pi - Omega tau = 2 pi (1 - 1/u^t) = 2 pi x %s = 3 pi/7 against the fixed directions' % per_orbit)
    # control: a circular orbit that is not a geodesic
    OM2 = OM * F(11, 10); uc2 = [F(1), F(0), R0 * OM2, F(0)]; u2 = [sum(at0(e[a].get(1 << mu, {}), N) * uc2[mu] for mu in range(N)) for a in range(N)]
    d2, U2, V2 = transport(Gv, om, E, u2, [])
    pred2 = mser_apply(mat_series(Kz, OM2), u2)
    chk('ctl', U2[0][1] != pred2[0][1] or any(U2[c][1] != pred2[c][1] for c in range(N)), 'a circle with Omega = 11/10 of the Kepler value (u = d_t + Omega d_phi): the carried velocity is not R_z(Omega t) u(0) at first order (not a geodesic)')
    head('(2) the float route: parallel transport with the Schwarzschild Christoffel symbols over one orbit (scipy) [std]')
    for Mr, s_exact, name in ((25 / 196, 11 / 14, '25/196'), (16 / 75, 3 / 5, '16/75')):
        a_end, rate, Om_, ut_ = std_angle(Mr)
        turn = 2 * math.pi + a_end
        chk('std', abs(a_end + 2 * math.pi * s_exact) < 1e-7 and abs(turn - 2 * math.pi * (1 - math.sqrt(1 - 3 * Mr))) < 1e-7, 'M/r = %s: the angle against the co-rotating radial direction ends at %.10f = -2 pi sqrt(1 - 3M/r); the turn per orbit is %.10f = 2 pi (1 - sqrt(1 - 3M/r)) = %s' % (name, a_end, turn, '3 pi/7' if name == '25/196' else '4 pi/5'))
        chk('ctl', abs(turn - 2 * math.pi * (1 - math.sqrt(1 - 2 * Mr))) > 1e-3, 'M/r = %s: the closed form with 2M/r in place of 3M/r (%.6f) misses the integrated turn %.6f' % (name, 2 * math.pi * (1 - math.sqrt(1 - 2 * Mr)), turn))
        if name == '25/196':
            chk('bit==std', abs(rate - (-Om_)) < 1e-9 * Om_, 'M/r = 25/196: the integrated proper rate %.12e = -Omega (the exact series: -Omega = -5/2744 for M = 25, r = 196; here M = 1)' % rate)

if __name__ == '__main__':
    main(); finish('GM-GYRO')
