#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""KPG-CARROLL.  Carroll boosts are null translations: the bivector algebra of the labels with one null generator is iso(m), and it is the
algebra of a null hyperplane of Minkowski space.      python3 carroll_null.py [--fault NONNULL|MIXED|TIMELIKE|NOREV]

 Squares (s, .., s, 0) and (0, s, .., s), s = +1 and -1, m = 1..4 non-null generators (a null hypersurface of an (m+2)-dimensional spacetime:
 Cl(m,0,1) and Cl(0,m,1); the time-positive convention gives Cl(0,m,1), the tangent algebra of check_T18).  K_a = e_a e_null (boosts),
 J_ab = e_a e_b (rotations).
 kpg·13 [bit] the engine's Lie table (f: bivector with bivector; h: (1/2)[B, gamma_b] = h gamma_c): dimension m(m+1)/2; [K_a, K_b] = 0 (no f entry);
        [J, K] in span K, [J, J] in span J; Jacobi (gm_cartan_bianchi.jacobi_ok); the J-J table is the engine's table of the squares (s, .., s);
        the Killing form tr(ad ad) has rank m(m-1)/2 and its radical is span K (m >= 2). [std] plain matrices: the algebra of the Carroll
        structure (q, xi), {X : X^T q + q X = 0, X xi = 0} with q = diag(s, .., s, 0), xi = e_null, has dimension m(m+1)/2 (exact null space).
        [bit==std] the engine's h-matrices H_B span exactly that algebra; B -> -(2 H_B)^T is a Lie algebra homomorphism onto the affine matrices
        [[S, v], [0, 0]] of iso(m) (S skew; exact); numpy Killing ranks of the matrices agree.
 kpg·14 [bit] the rotor R = 1 + (t/2) K_a (exact: K_a^2 = 0, so exp is a polynomial) by the engine's bit rule (gravity_selfcheck.bmul):
        R x R~ = x - t s x_a e_null for every vector x (t = 1, 2, 3, and five random rational x per case), e_null is fixed, and the
        degenerate inner product (x y + y x)/2 is kept; the h table gives exp(t H_K) = 1 + t H_K (H_K^2 = 0) with the same action.
        [std] scipy expm of the textbook Carroll boost (t, x) -> (t + b.x, x) (Levy-Leblond's form, recalled): equal to 1 + t H_K with b = -s t e_a.
 kpg·15 [bit] the engine's Lie(LORENTZ(n)), n = 3..6, and the null vector nu = gamma_0 + gamma_(n-1): the bivectors with H_B nu = 0 span
        (n-1)(n-2)/2 dimensions (exact null space); they keep nu^perp = span(gamma_1 .. gamma_(n-2), nu), whose induced metric is
        diag(-1, .., -1, 0) with kernel nu; restricted to nu^perp they span exactly the algebra of (q, xi) with q = diag(-1, .., -1, 0) and
        xi = nu, the same matrix algebra as the h-matrices of the squares (-1, .., -1, 0) (kpg·13): the stabiliser of a null vector is the
        Carroll algebra iso(n-2) of the null hyperplane, rotations and null rotations acting as Carroll boosts.
        [std] numpy: so(1, n-1) as matrices X^T eta + eta X = 0, the null space of X -> X nu (SVD), its dimension and Killing rank.
 Scope: a pointwise statement (the tangent space of a null hypersurface is a null hyperplane of the tangent Minkowski space); that a null
 hypersurface carries a Carroll structure as a field, and its physics, are recalled: C. Duval, G. W. Gibbons, P. A. Horvathy and P.-M. Zhang,
 Carroll versus Newton and Galilei: two dual non-Einsteinian concepts of time; J.-M. Levy-Leblond, Une nouvelle limite non-relativiste du
 groupe de Poincare. Wire: dirac_limits.py (dlim·WIG: e(2) for n = 4), kin_mech.py (the Carroll contraction), check_T18.
 Controls (--fault puts each into the main lines): NONNULL the last square +1 (so(m+1)): [K_1, K_2] != 0; MIXED squares (1, -1, 0): iso(1,1), the
 rotation is hyperbolic (positive Killing value), not iso(2); TIMELIKE nu = gamma_0: the stabiliser is so(n-1), the induced metric is not
 degenerate; NOREV R x R in place of R x R~: no translation.
 Engine faults: the script reads the f and the h tables of Lie (no curvature, no Einstein form, no d)."""
import os, sys, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import gm_cartan_bianchi as CB
import numpy as np
from scipy.linalg import expm

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'NONNULL', 'MIXED', 'TIMELIKE', 'NOREV'), 'unknown fault'
CNT = [0, 0]
def ck(tag, cond, msg): CNT[0 if cond else 1] += 1; return chk(tag, bool(cond), msg)

def hmat(L, A):
    """the matrix of (1/2)[B_A, .] on the vectors, from the engine's h table"""
    N = L.N; M = [[F(0)] * N for _ in range(N)]
    for (a, b), (c, v) in L.h.items():
        if a == A: M[c][b] += F(v)
    return M
def mmul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def msub(A, B): return [[a - b for a, b in zip(r, s)] for r, s in zip(A, B)]
def mT(A): return [list(r) for r in zip(*A)]
def flat(A): return [x for r in A for x in r]
def killing(L):
    G = L.G; ad = [[[F(0)] * G for _ in range(G)] for _ in range(G)]
    for (A, B), (C, c) in L.f.items(): ad[A][C][B] += F(c)
    return [[sum(ad[A][i][j] * ad[B][j][i] for i in range(G) for j in range(G)) for B in range(G)] for A in range(G)]
def qxi_algebra(q, xi):
    """dimension and equations (exact) of {X : X^T Q + Q X = 0, X xi = 0} for Q = diag(q): (X^T Q + Q X)_ij = q_j X_ji + q_i X_ij"""
    N = len(q); rows = []
    for i in range(N):
        for j in range(N):
            r = [F(0)] * (N * N); r[j * N + i] += F(q[j]); r[i * N + j] += F(q[i]); rows.append(r)
    for i in range(N):
        r = [F(0)] * (N * N)
        for k in range(N): r[i * N + k] += F(xi[k])
        rows.append(r)
    return N * N - rank_exact(rows), rows
def in_algebra(rows, X): return all(sum(r[k] * x for k, x in enumerate(flat(X))) == 0 for r in rows)
def np_killing_rank(mats):
    B = np.array([np.array(M, dtype=float).ravel() for M in mats]); G = len(mats); ad = np.zeros((G, G, G))
    for a in range(G):
        for b in range(G):
            C = np.array(mats[a], dtype=float) @ np.array(mats[b], dtype=float) - np.array(mats[b], dtype=float) @ np.array(mats[a], dtype=float)
            co, *_ = np.linalg.lstsq(B.T, C.ravel(), rcond=None); ad[a][:, b] = co
    K = np.array([[np.trace(ad[a] @ ad[b]) for b in range(G)] for a in range(G)])
    return int(np.linalg.matrix_rank(K, tol=1e-8))

def carroll_case(sq, z):
    """the Carroll table of the squares sq with the null generator at index z"""
    L = Lie(sq); m = L.N - 1; G = L.G
    K = [A for A, g in enumerate(L.gens) if g >> z & 1]; J = [A for A, g in enumerate(L.gens) if not g >> z & 1]
    kk = all((A, B) not in L.f for A in K for B in K)
    jk = all(L.f[(A, B)][0] in K for A in J for B in K if (A, B) in L.f) and all(L.f[(A, B)][0] in J for A in J for B in J if (A, B) in L.f)
    jac = CB.jacobi_ok(L)
    others = [i for i in range(L.N) if i != z]; L0 = Lie([sq[i] for i in others])
    relabel = {}
    for A in J:
        bits = [others.index(i) for i in range(L.N) if L.gens[A] >> i & 1]; relabel[A] = L0.idx[(1 << bits[0]) | (1 << bits[1])]
    quot = all(((relabel[A], relabel[B]) in L0.f) == ((A, B) in L.f) and ((A, B) not in L.f or (L0.f[(relabel[A], relabel[B])] == (relabel[L.f[(A, B)][0]], L.f[(A, B)][1]))) for A in J for B in J)
    Kf = killing(L); rk = rank_exact([list(r) for r in Kf]) if G else 0
    rad = [A for A in range(G) if all(x == 0 for x in Kf[A])]
    # [std] the algebra of (q, xi) and the engine's h-matrices
    q = [sq[i] for i in range(L.N)]; xi = [F(int(i == z)) for i in range(L.N)]
    dimq, rows = qxi_algebra(q, xi); H = [hmat(L, A) for A in range(G)]
    span_ok = all(in_algebra(rows, M) for M in H) and rank_exact([flat(M) for M in H]) == dimq == G
    # iso(m): B -> -(2 H_B)^T, in the basis (non-null generators, null generator last)
    order = others + [z]; P = lambda M: [[M[order[i]][order[j]] for j in range(L.N)] for i in range(L.N)]
    img = {A: [[-2 * x for x in r] for r in mT(P(H[A]))] for A in range(G)}
    shape = all(all(img[A][L.N - 1][j] == 0 for j in range(L.N)) and all(img[A][i][j] == -img[A][j][i] for i in range(m) for j in range(m)) for A in range(G))
    hom = True
    for A in range(G):
        for B in range(G):
            C = msub(mmul(img[A], img[B]), mmul(img[B], img[A]))
            want = [[F(0)] * L.N for _ in range(L.N)]
            if (A, B) in L.f:
                c, v = L.f[(A, B)]; want = [[F(v) * x for x in r] for r in img[c]]
            hom &= C == want
    npk = np_killing_rank([img[A] for A in range(G)])
    return dict(L=L, m=m, G=G, K=K, J=J, kk=kk, jk=jk, jac=jac, quot=quot, rk=rk, rad=sorted(rad), dimq=dimq, span_ok=span_ok, shape=shape, hom=hom, npk=npk, H=H)

def part13():
    head('kpg·13: the bivector algebra of the squares (s, .., s, 0) and (0, s, .., s), m = 1..4: iso(m) [bit] [std] [bit==std]')
    ok = {k: True for k in ('dim', 'kk', 'jk', 'jac', 'quot', 'kil', 'std', 'iso', 'np')}
    for s in (1, -1):
        for m in range(1, 5):
            for last in (True, False):
                sq = [s] * m + [0] if last else [0] + [s] * m
                if FAULT == 'NONNULL': sq = [s] * m + [1] if last else [1] + [s] * m
                if FAULT == 'MIXED' and m == 2: sq = [1, -1, 0] if last else [0, 1, -1]
                z = m if last else 0; R = carroll_case(sq, z)
                ok['dim'] &= R['G'] == m * (m + 1) // 2 and len(R['K']) == m
                ok['kk'] &= R['kk']; ok['jk'] &= R['jk']; ok['jac'] &= R['jac']; ok['quot'] &= R['quot']
                want_rk = m * (m - 1) // 2
                ok['kil'] &= R['rk'] == want_rk and (m == 1 or R['rad'] == sorted(R['K']))
                if m == 2: Kf = killing(R['L']); ok['kil'] &= all(Kf[A][A] < 0 for A in R['J'])
                ok['std'] &= R['dimq'] == m * (m + 1) // 2
                ok['iso'] &= R['span_ok'] and R['shape'] and R['hom']
                ok['np'] &= R['npk'] == want_rk
    ck('bit', ok['dim'] and ok['kk'], 'the engine\'s table has m(m+1)/2 = 1, 3, 6, 10 bivectors for m = 1..4, m boosts K_a = e_a e_null, and [K_a, K_b] = 0 (no f entry), both signs s, the null generator last and first')
    ck('bit', ok['jk'] and ok['jac'], '[J, K] lies in span K and [J, J] in span J (the boosts are an ideal); Jacobi on the whole table')
    ck('bit', ok['quot'], 'the J-J table is the engine\'s table of the squares (s, .., s): the quotient by the boosts is so(m)')
    ck('bit', ok['kil'], 'Killing form tr(ad ad): rank m(m-1)/2 = 0, 1, 3, 6, radical exactly span K for m >= 2; for m = 2 the rotation has a negative Killing value (elliptic: iso(2), not iso(1,1))')
    ck('std', ok['std'], 'plain matrices: {X : X^T q + q X = 0, X xi = 0}, q = diag(s, .., s, 0), xi = e_null, has dimension m(m+1)/2 (exact null space)')
    ck('bit==std', ok['iso'], 'the engine\'s h-matrices span exactly that algebra, and B -> -(2 H_B)^T is a Lie algebra homomorphism onto the affine matrices [[S, v], [0, 0]] of iso(m) (exact, all pairs, the 16 cases)')
    ck('bit==std', ok['np'], 'numpy Killing ranks of the affine matrices agree with the exact ranks (16 cases)')

def mv_mul(x, y, sq):
    out = {}
    for a, u in x.items():
        for b, v in y.items():
            c, s_ = bmul(a, b, sq)
            if s_: out[c] = out.get(c, 0) + s_ * u * v
    return {k: v for k, v in out.items() if v != 0}
def mv_rev(x): return {m: (v if popc(m) % 4 in (0, 1) else -v) for m, v in x.items()}
def inner(x, y, sq): return (mv_mul(x, y, sq).get(0, F(0)) + mv_mul(y, x, sq).get(0, F(0))) / 2
def part14():
    head('kpg·14: the rotor 1 + (t/2) K_a acts as a null translation [bit]; the textbook Carroll boost by scipy expm [std]')
    rng = random.Random(2801); okT = okFix = okMet = okH = okStd = True; nchk = 0
    for s in (1, -1):
        for m in (1, 2, 3, 4):
            sq = [s] * m + [0]; z = m; L = Lie(sq)
            for a in range(m):
                Ka = (1 << a) | (1 << z)
                for t in (F(1), F(2), F(3)):
                    R = {0: F(1), Ka: t / 2}; Rr = R if FAULT == 'NOREV' else mv_rev(R)
                    assert mv_mul({Ka: F(1)}, {Ka: F(1)}, sq) == {}
                    for _ in range(5):
                        xv = [F(rng.randint(-9, 9), rng.randint(1, 5)) for _ in range(m + 1)]; x = {1 << i: xv[i] for i in range(m + 1) if xv[i]}
                        img = mv_mul(mv_mul(R, x, sq), Rr, sq)
                        want = dict(x); want[1 << z] = want.get(1 << z, 0) - t * s * xv[a]; want = {k: v for k, v in want.items() if v != 0}
                        okT &= img == want; nchk += 1
                        yv = [F(rng.randint(-9, 9), rng.randint(1, 5)) for _ in range(m + 1)]; y = {1 << i: yv[i] for i in range(m + 1) if yv[i]}
                        imgy = mv_mul(mv_mul(R, y, sq), Rr, sq)
                        okMet &= inner(img, imgy, sq) == inner(x, y, sq) == sum(s * xv[i] * yv[i] for i in range(m))
                    okFix &= mv_mul(mv_mul(R, {1 << z: F(1)}, sq), Rr, sq) == {1 << z: F(1)}
                A = L.idx[Ka]; Hk = hmat(L, A); H2 = mmul(Hk, Hk)
                okH &= all(x == 0 for x in flat(H2))
                for t in (F(1), F(2)):
                    Mx = [[F(int(i == j)) + t * Hk[i][j] for j in range(m + 1)] for i in range(m + 1)]
                    want = [[F(int(i == j)) for j in range(m + 1)] for i in range(m + 1)]; want[z][a] = -t * s
                    okH &= Mx == want
                    # [std] the textbook Carroll boost: time coordinate u = x_null, (u, x) -> (u + b.x, x), b = -s t e_a, as expm of its generator
                    Gm = np.zeros((m + 1, m + 1)); Gm[z, a] = -s * float(t); Bst = expm(Gm)
                    okStd &= np.allclose(Bst, np.array(Mx, dtype=float), atol=1e-12) and np.allclose(Bst @ np.eye(m + 1)[:, z], np.eye(m + 1)[:, z])
    ck('bit', okT and nchk > 0, 'R x R~ = x - t s x_a e_null for R = 1 + (t/2) e_a e_null, t = 1, 2, 3, five random rational vectors x per (s, m, a), m = 1..4, s = +-1 (%d sandwiches): the boost is a null translation' % nchk + (' [fault NOREV]' if FAULT == 'NOREV' else ''))
    ck('bit', okFix and okMet, 'e_null is fixed, and the degenerate inner product (x y + y x)/2 = sum_a s x_a y_a (kernel e_null) is kept by every rotor')
    ck('bit', okH, 'from the h table: H_K^2 = 0, exp(t H_K) = 1 + t H_K maps e_a to e_a - t s e_null and fixes the rest (t = 1, 2)')
    ck('std', okStd, 'scipy expm of the textbook Carroll boost generator (u, x) -> (u + b.x, x) with b = -s t e_a equals 1 + t H_K (1e-12) and fixes the null direction')

def part15():
    head('kpg·15: the stabiliser of a null vector in so(1, n-1), restricted to the null hyperplane, is the Carroll algebra iso(n-2) [bit] [std] [bit==std]')
    okDim = okKeep = okMet = okSpan = okSame = okNp = True; dims = []
    for n in (3, 4, 5, 6):
        sq = LORENTZ(n); L = Lie(sq); G = L.G; m = n - 2
        nu = [F(0)] * n; nu[0] = F(1)
        if FAULT != 'TIMELIKE': nu[n - 1] = F(1)
        H = [hmat(L, A) for A in range(G)]
        cols = [[sum(H[A][i][j] * nu[j] for j in range(n)) for i in range(n)] for A in range(G)]
        rows = [[cols[A][i] for A in range(G)] for i in range(n)]
        # null-space basis of the stabiliser
        def nullsp(Mrows, nc):
            Mm = [list(r) for r in Mrows]; piv = []; r_ = 0
            for c in range(nc):
                p = next((i for i in range(r_, len(Mm)) if Mm[i][c] != 0), None)
                if p is None: continue
                Mm[r_], Mm[p] = Mm[p], Mm[r_]; inv = 1 / Mm[r_][c]; Mm[r_] = [x * inv for x in Mm[r_]]
                for i in range(len(Mm)):
                    if i != r_ and Mm[i][c] != 0:
                        f_ = Mm[i][c]; Mm[i] = [x - f_ * y for x, y in zip(Mm[i], Mm[r_])]
                piv.append(c); r_ += 1
            out = []
            for fc in [c for c in range(nc) if c not in piv]:
                v = [F(0)] * nc; v[fc] = F(1)
                for i, pc_ in enumerate(piv): v[pc_] = -Mm[i][fc]
                out.append(v)
            return out
        St = nullsp(rows, G); dims.append(len(St)); okDim &= len(St) == (n - 1) * (n - 2) // 2
        HS = [[[sum(v[A] * H[A][i][j] for A in range(G)) for j in range(n)] for i in range(n)] for v in St]
        # nu^perp basis: gamma_1 .. gamma_(n-2), nu  (as columns of P)
        basis = [[F(int(i == a)) for i in range(n)] for a in range(1, n - 1)] + [nu]
        eta = [F(x) for x in sq]; ip = lambda u, w: sum(eta[i] * u[i] * w[i] for i in range(n))
        gram = [[ip(u, w) for w in basis] for u in basis]
        okMet &= gram == [[F(-1) if (i == j and i < m) else F(0) for j in range(m + 1)] for i in range(m + 1)]
        # restriction: coordinates of X b in the basis (exact solve), and X b in nu^perp
        restr = []
        for X in HS:
            R = []
            for b in basis:
                Xb = [sum(X[i][j] * b[j] for j in range(n)) for i in range(n)]
                okKeep &= ip(Xb, nu) == 0
                w, _, _, cons_ = solve_exact([[basis[c][i] for c in range(m + 1)] for i in range(n)], Xb); okKeep &= cons_
                R.append(w if w else [F(0)] * (m + 1))
            restr.append(mT(R))
        q = [-1] * m + [0]; xi = [F(0)] * m + [F(1)]; dimq, qrows = qxi_algebra(q, xi)
        okSpan &= all(in_algebra(qrows, M) for M in restr) and rank_exact([flat(M) for M in restr]) == dimq == len(St)
        Lc = Lie([-1] * m + [0]); Hc = [hmat(Lc, A) for A in range(Lc.G)]
        okSame &= rank_exact([flat(M) for M in restr + Hc]) == rank_exact([flat(M) for M in Hc]) == len(St)
        # [std] numpy so(1, n-1) matrices and the null space of X -> X nu
        etan = np.diag([float(x) for x in sq]); gens = []
        for a, b in itertools.combinations(range(n), 2):
            Mx = np.zeros((n, n)); Mx[a, :] += etan[b, :]; Mx[b, :] -= etan[a, :]; gens.append(Mx)
        nun = np.array([float(x) for x in nu]); Mt = np.array([Gm @ nun for Gm in gens]).T
        sv = np.linalg.svd(Mt)[1]; r = int((sv > 1e-9).sum()); Vt = np.linalg.svd(Mt)[2]; stab = [sum(c * Gm for c, Gm in zip(v, gens)) for v in Vt[r:]]
        okNp &= len(stab) == (n - 1) * (n - 2) // 2 and np_killing_rank(stab) == (m * (m - 1)) // 2
    ck('bit', okDim, 'the engine\'s bivectors of Cl(1, n-1) with H_B nu = 0, nu = gamma_0 + gamma_(n-1), span (n-1)(n-2)/2 = %s dimensions for n = 3..6 (exact null space)' % ', '.join(map(str, dims)) + (' [fault TIMELIKE: nu = gamma_0]' if FAULT == 'TIMELIKE' else ''))
    ck('bit', okMet and okKeep, 'nu^perp = span(gamma_1 .. gamma_(n-2), nu) has the induced metric diag(-1, .., -1, 0) with kernel nu, and the stabiliser keeps it')
    ck('bit', okSpan, 'restricted to nu^perp the stabiliser spans exactly the algebra of (q, xi), q = diag(-1, .., -1, 0), xi = nu: rotations and Carroll boosts, dimension (n-1)(n-2)/2')
    ck('bit', okSame, 'it is the same matrix algebra as the h-matrices of the squares (-1, .., -1, 0) of kpg·13: the stabiliser of a null vector is the Carroll algebra iso(n-2) of the null hyperplane (n = 3..6)')
    ck('std', okNp, 'numpy: so(1, n-1) as matrices, the null space of X -> X nu has dimension (n-1)(n-2)/2 and Killing rank (n-2)(n-3)/2 = 0, 1, 3, 6 (n = 3..6), as iso(n-2)')

def part16():
    head('kpg·16: controls [ctl]')
    L = Lie([1, 1, 1]); K = [A for A, g in enumerate(L.gens) if g >> 2 & 1]
    ck('ctl', any((A, B) in L.f for A in K for B in K), 'the third square +1 in place of 0 (so(3)): [K_1, K_2] != 0')
    R = carroll_case([1, -1, 0], 2); Kf = killing(R['L'])
    ck('ctl', R['kk'] and all(Kf[A][A] > 0 for A in R['J']), 'squares (1, -1, 0): the boosts still commute, but the rotation has a positive Killing value (hyperbolic: iso(1,1), not iso(2))')
    n = 4; L4 = Lie(LORENTZ(4)); H = [hmat(L4, A) for A in range(L4.G)]; nu = [F(1), F(0), F(0), F(0)]
    rows = [[sum(H[A][i][j] * nu[j] for j in range(n)) for A in range(L4.G)] for i in range(n)]
    dimS = L4.G - rank_exact(rows)
    fix0 = [A for A in range(L4.G) if all(sum(H[A][i][j] * nu[j] for j in range(n)) == 0 for i in range(n))]
    spatial = sorted(A for A, g in enumerate(L4.gens) if not g & 1); Kf4 = killing(L4)
    neg_def = fix0 == spatial and all(Kf4[A][A] < 0 for A in fix0) and all(Kf4[A][B] == 0 for A in fix0 for B in fix0 if A != B)
    sq4 = LORENTZ(4); gram_t = [[F(sq4[i]) if i == j else F(0) for j in range(1, 4)] for i in range(1, 4)]
    nondeg = all(gram_t[i][i] != 0 for i in range(3))
    ck('ctl', dimS == 3 and neg_def and nondeg, 'nu = gamma_0 (timelike): the stabiliser has the same dimension 3 but is so(3) (dlim·WIG), and gamma_0^perp = span(gamma_1, gamma_2, gamma_3) has the non-degenerate metric diag(-1, -1, -1): no Carroll structure')
    sq = [1, 1, 0]; R = {0: F(1), 0b101: F(1, 2)}; x = {0b001: F(1)}
    ck('ctl', mv_mul(mv_mul(R, x, sq), R, sq) == x, 'R x R in place of R x R~: e_1 -> e_1, no translation (the boost is lost)')

def main():
    head('KPG-CARROLL: the bivector algebra with one null generator, Carroll boosts and the null hyperplane' + (' [fault %s]' % FAULT if FAULT else ''))
    part13(); part14(); part15(); part16()
    print('\nchecks: %d ok, %d FAIL' % tuple(CNT))

if __name__ == '__main__':
    main(); finish('KPG-CARROLL' + ('-' + FAULT if FAULT else ''))
