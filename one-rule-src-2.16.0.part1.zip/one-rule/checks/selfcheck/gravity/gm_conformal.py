#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-CONF.  Maxwell's equations are invariant under the special conformal fields xi_b = 2 (b.x) x - x^2 b of so(2,4).   python3 gm_conformal.py

 Derivation: L_xi = d i_xi + i_xi d commutes with d. For a conformal Killing field (L_xi eta = 2 sigma eta) the flow is conformal, and on 2-forms in four dimensions the star does not change
 under g -> Omega^2 g (weight n/2 - p = 0), so L_xi * = * L_xi on 2-forms; hence dF = 0 and d*F = 0 give d L_xi F = 0 and d* L_xi F = 0. For xi_b: L_xi eta = 4 (b.x) eta (sigma = 2 b.x).
 Minkowski R^{1,3}, signature (+,-,-,-), b = (1/2, -1, 1/2, 3/2).
 [bit]  exact polynomial vacuum solutions: A with components of degree <= 3, F = dA (engine d), d*F = 0 imposed by an exact linear solve (bit-rule star of g2_hodge), three random solutions;
        L_xi F by g2_forms_calc.lie (Cartan with the engine's d and the bit-rule interior product): d(L_xi F) = 0 and d*(L_xi F) = 0; L_xi *X = * L_xi X for random 2-forms X;
        L_xi eta = 4 (b.x) eta from L_xi dx^l = d xi^l (engine d).
 [std]  the component formula g2_forms_calc.lie_std (plain polynomial calculus) equals the engine's L_xi F; numpy: L_xi F_{mu nu} = xi^l d_l F_{mu nu} + F_{l nu} d_mu xi^l + F_{mu l} d_nu xi^l
        for a plane wave F = (k ^ p) cos(k.x) (k null, p.k = 0) and the Coulomb field, and Maxwell's equations of L_xi F by central differences at points (the Bateman-Cunningham
        statement, recalled, in its infinitesimal form).
 Controls: the shear xi = x^1 d_0 is not conformal (L_xi eta is not a multiple of eta) and d*(L_xi F) != 0 for a solution; L_xi F + sigma F (a dilatation weight wrongly added) is not closed;
 a field with d*F != 0 gives d*(L_xi F) != 0.
 Not here: the massless Dirac equation (weight 3/2) and the linearised Yang-Mills equation."""
import os, sys, random, itertools, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import g2_forms_calc as FC
import numpy as np

N = 4; SQ = LORENTZ(4); B = [F(1, 2), F(-1), F(1, 2), F(3, 2)]
MONS = [ex for ex in itertools.product(range(4), repeat=N) if sum(ex) <= 3]
def flat(nv=N): return [{1 << a: const(nv, 1)} for a in range(N)], [[const(nv, int(m == a)) for a in range(N)] for m in range(N)]
def xi_special(b):
    X = [var(N, i) for i in range(N)]; bx = lin(*[(F(SQ[m]) * b[m], X[m]) for m in range(N)]); x2 = lin(*[(F(SQ[m]), sp_mul(X[m], X[m], 9, N)) for m in range(N)])
    return [lin((F(2), sp_mul(bx, X[m], 9, N)), (-b[m], x2)) for m in range(N)], bx
def dstar(Gv, X, ef, Ef): return Gv.Fm.d(H.hodge_form(X, ef, Ef, Gv.Fm, SQ, N, 'bit'))
def zero(X): return not any(X.values())
def random_solution(Gv, rng, ef, Ef):
    """[bit] a random exact solution F = dA with d*F = 0: A of degree <= 3, the linear map A -> d*dA by the engine, random values of the free unknowns"""
    cols = []; keys = {}
    unknowns = [(mu, ex) for mu in range(N) for ex in MONS]
    for (mu, ex) in unknowns:
        r = dstar(Gv, Gv.Fm.d({1 << mu: {ex: F(1)}}), ef, Ef); col = {}
        for m, p in r.items():
            for k, v in p.items():
                kk = keys.setdefault((m, k), len(keys)); col[kk] = v
        cols.append(col)
    rows = [[F(0)] * len(unknowns) for _ in range(len(keys))]
    for j, col in enumerate(cols):
        for i, v in col.items(): rows[i][j] = v
    M = [r[:] for r in rows]; piv = []; rk = 0
    for c in range(len(unknowns)):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / M[rk][c]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0: f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    val = [F(0)] * len(unknowns)
    for c in range(len(unknowns)):
        if c not in piv: val[c] = F(rng.randint(-9, 9))
    for i, c in enumerate(piv): val[c] = -sum(M[i][j] * val[j] for j in range(len(unknowns)) if j not in piv)
    A = {}
    for (mu, ex), v in zip(unknowns, val):
        if v: A.setdefault(1 << mu, {})[ex] = v
    return A, rk, len(unknowns)
def killing_matrix(Gv, xi):
    """(L_xi eta)_{mu nu} = eta_{mu l} d_nu xi^l + eta_{l nu} d_mu xi^l, with d_nu xi^l read from L_xi dx^l = d xi^l (engine d)"""
    dxi = [Gv.Fm.d({0: xi[l]}) for l in range(N)]
    D = [[dxi[l].get(1 << nu, {}) for nu in range(N)] for l in range(N)]
    return [[lin((F(SQ[mu]), D[mu][nu]), (F(SQ[nu]), D[nu][mu])) for nu in range(N)] for mu in range(N)]
# ------------------------------------------------------------------------------------------------ [std] numpy, closed-form fields
def xi_num(x, b):
    eta = np.diag([float(s) for s in SQ]); bx = b @ eta @ x; x2 = x @ eta @ x; return 2 * bx * x - x2 * b
def dxi_num(x, b):
    """d_mu xi^l (rows l, columns mu)"""
    eta = np.diag([float(s) for s in SQ]); bl = eta @ b; xl = eta @ x
    return 2 * np.outer(x, bl) + 2 * (b @ eta @ x) * np.eye(4) - 2 * np.outer(b, xl)
def lie_num(Ffun, dFfun, x, b, shear=False):
    """L_xi F_{mn} = xi^l d_l F_mn + F_ln d_m xi^l + F_ml d_n xi^l (xi_b, or the shear xi = x^1 d_0)"""
    Fx = Ffun(x); dF = dFfun(x)
    if shear: xi = np.array([x[1], 0.0, 0.0, 0.0]); D = np.zeros((4, 4)); D[0, 1] = 1.0
    else: xi = xi_num(x, b); D = dxi_num(x, b)
    return np.einsum('l,lmn->mn', xi, dF) + np.einsum('ln,lm->mn', Fx, D) + np.einsum('ml,ln->mn', Fx, D)
def maxwell_residual(G, x, h=1e-4):
    """central differences: d_mu G^{mu nu} (eta raises) and the cyclic d_[l G_mn] at x"""
    eta = np.diag([float(s) for s in SQ]); res = 0.0
    dG = np.zeros((4, 4, 4))
    for l in range(4):
        dx = np.zeros(4); dx[l] = h; dG[l] = (G(x + dx) - G(x - dx)) / (2 * h)
    div = np.array([sum(eta[m, m] * eta[n, n] * dG[m][m, n] for m in range(4)) for n in range(4)])
    cyc = max(abs(dG[l][m, n] + dG[m][n, l] + dG[n][l, m]) for l, m, n in itertools.combinations(range(4), 3))
    return float(np.abs(div).max()), float(cyc)

def main():
    Gv = Grav(N); Fm = Gv.Fm; ef, Ef = flat(); rng = random.Random(139)
    xi, bx = xi_special(B)
    head('(1) the conformal Killing equation: L_xi eta = 4 (b.x) eta for xi_b = 2 (b.x) x - x^2 b, b = (%s) [bit]' % ', '.join(map(str, B)))
    Km = killing_matrix(Gv, xi)
    chk('bit', all(Km[m][n] == (scale(bx, 4 * SQ[m]) if m == n else {}) for m in range(N) for n in range(N)), 'L_xi eta_{mu nu} = d_mu xi_nu + d_nu xi_mu = 4 (b.x) eta_{mu nu} exactly (d xi^l from the engine\'s d)')
    shear = [var(N, 1), {}, {}, {}]; Ks = killing_matrix(Gv, shear)
    chk('ctl', Ks[0][1] != {} or Ks[1][0] != {}, 'the shear xi = x^1 d_0: L_xi eta has the off-diagonal entry %s: not a multiple of eta (not conformal)' % at0(Ks[0][1], N))
    head('(2) L_xi commutes with the star on 2-forms: random polynomial 2-forms [bit]; the component formula [std]')
    for sd in (1, 2, 3):
        X = gs.sform(random.Random(sd), N, 2, 2)
        lhs = FC.lie(Gv, xi, H.hodge_form(X, ef, Ef, Fm, SQ, N, 'bit')); rhs = H.hodge_form(FC.lie(Gv, xi, X), ef, Ef, Fm, SQ, N, 'bit')
        chk('bit', FC.form_eq(lhs, rhs), 'random 2-form %d (degree 2): L_xi *X = * L_xi X exactly' % sd)
    Xs = gs.sform(random.Random(4), N, 2, 2)
    chk('ctl', not FC.form_eq(FC.lie(Gv, shear, H.hodge_form(Xs, ef, Ef, Fm, SQ, N, 'bit')), H.hodge_form(FC.lie(Gv, shear, Xs), ef, Ef, Fm, SQ, N, 'bit')), 'the shear: L_xi *X != * L_xi X')
    head('(3) exact polynomial vacuum solutions F = dA, d*F = 0, and L_xi F [bit]; lie_std [std]')
    for k in range(3):
        A, rk, nu = random_solution(Gv, rng, ef, Ef); Fx = Fm.d(A)
        okF = zero(Fm.d(Fx)) and zero(dstar(Gv, Fx, ef, Ef)) and not zero(Fx)
        L = FC.lie(Gv, xi, Fx)
        okL = zero(Fm.d(L)) and zero(dstar(Gv, L, ef, Ef)) and not zero(L)
        chk('bit', okF and okL, 'solution %d (A of degree <= 3; the map A -> d*dA has rank %d on %d unknowns): dF = 0, d*F = 0; L_xi F != 0 has d(L_xi F) = 0 and d*(L_xi F) = 0 exactly' % (k + 1, rk, nu))
        chk('bit==std', FC.form_eq(L, FC.lie_std(xi, Fx, N)), 'solution %d: the engine\'s L_xi F (Cartan) = the component formula xi^l d_l F_mn + F_ln d_m xi^l + F_ml d_n xi^l (lie_std, no engine)' % (k + 1))
        sig = scale(bx, 2); W = Fm.add(L, Fm.wedge({0: sig}, Fx))
        chk('ctl', not zero(Fm.d(W)), 'solution %d: L_xi F + sigma F with sigma = 2 b.x (a dilatation weight wrongly added) is not closed' % (k + 1))
        chk('ctl', not zero(dstar(Gv, FC.lie(Gv, shear, Fx), ef, Ef)), 'solution %d: the shear field: d*(L_xi F) != 0' % (k + 1))
    Fbad = Fm.d(gs.sform(random.Random(9), N, 1, 3))
    chk('ctl', not zero(dstar(Gv, Fbad, ef, Ef)) and not zero(dstar(Gv, FC.lie(Gv, xi, Fbad), ef, Ef)), 'a field F = dA with d*F != 0 (random A): d*(L_xi F) != 0 (the statement is about solutions)')
    head('(4) the float route: a plane wave and the Coulomb field, L_xi F by the index formula, Maxwell by central differences [std]')
    bn = np.array([float(x) for x in B]); eta = np.diag([float(s) for s in SQ])
    kup = np.array([1.0, 0.6, 0.0, 0.8]); pup = np.array([0.0, 0.8, 0.0, -0.6]); kl = eta @ kup; pl = eta @ pup
    Fpw = lambda x: (np.outer(kl, pl) - np.outer(pl, kl)) * math.cos(kup @ eta @ x)
    dFpw = lambda x: -np.einsum('l,mn->lmn', kl, np.outer(kl, pl) - np.outer(pl, kl)) * math.sin(kup @ eta @ x)
    def Fc(x):
        r = np.linalg.norm(x[1:]); M = np.zeros((4, 4)); M[0, 1:] = x[1:] / r ** 3; M[1:, 0] = -x[1:] / r ** 3; return M
    def dFc(x, h=1e-6):
        out = np.zeros((4, 4, 4))
        for l in range(4):
            dx = np.zeros(4); dx[l] = h; out[l] = (Fc(x + dx) - Fc(x - dx)) / (2 * h)
        return out
    pts = [np.array([0.3, 0.7, -0.4, 0.5]), np.array([-0.2, 1.1, 0.6, -0.8]), np.array([0.5, -0.9, 1.3, 0.4])]
    for name, Ff, dFf in (('plane wave (k null, p.k = 0)', Fpw, dFpw), ('Coulomb field', Fc, dFc)):
        r0 = max(max(maxwell_residual(Ff, x)) for x in pts)
        rL = max(max(maxwell_residual(lambda y: lie_num(Ff, dFf, y, bn), x, 1e-3)) for x in pts)
        rS = max(max(maxwell_residual(lambda y: lie_num(Ff, dFf, y, bn, shear=True), x, 1e-3)) for x in pts)
        chk('std', r0 < 1e-6 and rL < 1e-5, '%s: Maxwell residual of F %.1e and of L_xi F %.1e at three points (central differences)' % (name, r0, rL))
        chk('ctl', rS > 1e-3, '%s: the shear field gives the residual %.1e for its L_xi F' % (name, rS))
    print('\n  reading: xi_b is a conformal Killing field (L_xi eta = 4 (b.x) eta); L_xi commutes with d and, on 2-forms, with the star, so it maps vacuum solutions to vacuum solutions.')

if __name__ == '__main__':
    main(); finish('GM-CONF')
