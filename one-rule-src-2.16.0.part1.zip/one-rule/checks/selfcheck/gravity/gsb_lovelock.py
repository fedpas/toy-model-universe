#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSB-LOVELOCK.  Divergence-free symmetric tensors from the curvature: the finite part of Lovelock's theorem.   python3 gsb_lovelock.py [--quick] [--fault TRACE|LANCZOS|N5]

Statement checked.  On random polynomial frames with the torsion-free connection, at the origin:
 (1) the Einstein form is divergence-free, D E_a = 0 (c = 0 and 1/3: G_ab + Lambda g_ab), n = 4;
 (2) among the second-order tensors linear in the curvature, (R_ab, R g_ab, g_ab), the divergence-free combinations are exactly span{G_ab, g_ab};
 (3) among the seven quadratic ones, (R R_ab, R_ac R^c_b, R_acbd R^cd, R_acde R_b^cde, g_ab R^2, g_ab R_cd R^cd, g_ab R_cdef R^cdef), the only
     divergence-free combination is the Lanczos combination H_ab = 2(R R_ab - 2 R_ac R^c_b - 2 R_acbd R^cd + R_acde R_b^cde)
     - (1/2) g_ab (R^2 - 4 R_cd R^cd + R_cdef R^cdef), and at n = 4 H_ab is the zero tensor: no new divergence-free tensor;
 (4) at n = 5 the same combination is divergence-free and not zero (why the theorem is four-dimensional);
 (5) [std] with the fourth-order tensors box R_ab, nabla_a nabla_b R, g_ab box R added, the divergence-free space grows to dimension 3 at n = 4
     (H and two combinations that contain fourth-order terms: the second-order hypothesis is needed).
[bit]  frames of degree 3 (b1lib.rand_frame, coefficients -2..2), A3's closed-form omega as a 2-jet, the engine's curvature as a 1-jet, its frame
       components R^{cd}(E_a, E_b) as 1-jets; each candidate M_ab enters as the (n-1)-form M_a^b Theta_b (Theta_b = i_{E_b} vol, g2_hodge) and its
       divergence is D(M_a^b Theta_b) = (nabla_b M_a^b) vol (the engine's D_covector; torsion zero); kernels exact over Q.
[std]  Christoffel calculus on g = e^T eta e as exact series (Riemann, Ricci, covariant derivatives), the divergences g^{mn} nabla_m M_{n l} at the
       origin; [bit==std] on every divergence (frame components); (5) on frames of degree 5 by the [std] route alone (Riemann to third order).
Scope: n = 4 (three frames), n = 5 (two frames), exact; (5) at n = 4 on four frames.  Lovelock's theorem (every symmetric divergence-free tensor
built from g and its first two derivatives at n = 4 is a G_ab + b g_ab; only Einstein-Hilbert plus a cosmological term as a second-order
Lagrangian) is recalled: D. Lovelock, The Einstein tensor and its generalizations; The four-dimensionality of space and the Einstein tensor.
Controls: G with the trace coefficient -1/4; every candidate alone; the Lanczos combination with one coefficient changed; H = 0 claimed at n = 5.
--fault TRACE | LANCZOS | N5 puts each into its main check (exit 1).  --quick: n = 4 only, without the fourth-order part (the mutation table runs with it)."""
import os, sys, time, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as GH

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'TRACE', 'LANCZOS', 'N5'), 'unknown fault'
QUICK = '--quick' in ARGS
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
LIN = ['R_ab', 'R g_ab', 'g_ab']
QUAD = ['R R_ab', 'R_ac R^c_b', 'R_acbd R^cd', 'R_acde R_b^cde', 'g R^2', 'g Ric^2', 'g Riem^2']
H_COEF = [F(2), F(-4), F(-4), F(2), F(-1, 2), F(2), F(-1, 2)]
H_WRONG = [F(2), F(-4), F(-4), F(2), F(-1, 2), F(2), F(-1)]

# ------------------------------------------------------------------------------------------------ tensor algebra on index dicts (polynomial entries)
def tens_lin(terms, keys):
    out = {}
    for k in keys:
        t = {}
        for c, T in terms:
            if c and T.get(k): t = padd(t, T[k], c)
        out[k] = t
    return out
def candidates(Rl, Ric, Rs, eta_up, n, mul):
    """the ten candidates as dicts (a, b) -> polynomial; Rl[(a,b,c,d)] lower Riemann, Ric[(a,b)], Rs scalar; eta_up[a][b] the inverse metric entries
       (numbers or polynomials through mul); mul(p, q) the truncated product"""
    I = range(n); keys = [(a, b) for a in I for b in I]
    def up(p, a, b):
        x = eta_up(a, b)
        return mul(x, p) if x else {}
    Ricup = {(c, d): lin(*[(F(1), mul(eta_up(c, e), mul(eta_up(d, f), Ric[(e, f)]))) for e in I for f in I if eta_up(c, e) and eta_up(d, f)]) for c in I for d in I}
    g = {(a, b): eta_low(a, b) for a in I for b in I}
    RR = {k: mul(Rs, Ric[k]) for k in keys}
    RicRic = {(a, b): lin(*[(F(1), mul(Ric[(a, c)], lin(*[(F(1), mul(eta_up(c, d), Ric[(d, b)])) for d in I if eta_up(c, d)]))) for c in I]) for a in I for b in I}
    RiemRic = {(a, b): lin(*[(F(1), mul(Rl[(a, c, b, d)], Ricup[(c, d)])) for c in I for d in I]) for a in I for b in I}
    Rup = {}
    for (b, c, d, e) in itertools.product(I, repeat=4):
        t = {}
        for c2 in I:
            x = eta_up(c, c2)
            if not x: continue
            for d2 in I:
                y = eta_up(d, d2)
                if not y: continue
                for e2 in I:
                    z = eta_up(e, e2)
                    if z: t = padd(t, mul(mul(x, mul(y, z)), Rl[(b, c2, d2, e2)]))
        Rup[(b, c, d, e)] = t
    RiemRiem = {(a, b): lin(*[(F(1), mul(Rl[(a, c, d, e)], Rup[(b, c, d, e)])) for c in I for d in I for e in I]) for a in I for b in I}
    R2 = mul(Rs, Rs); Ric2 = lin(*[(F(1), mul(Ric[(c, d)], Ricup[(c, d)])) for c in I for d in I])
    Riem2 = lin(*[(F(1), mul(Rl[(a, c, d, e)], lin(*[(F(1), mul(eta_up(a, f), Rup[(f, c, d, e)])) for f in I if eta_up(a, f)]))) for a in I for c in I for d in I for e in I])
    lin_c = [dict(Ric), {k: mul(g[k], Rs) if g[k] else {} for k in keys}, {k: g[k] for k in keys}]
    quad_c = [RR, RicRic, RiemRic, RiemRiem, {k: mul(g[k], R2) if g[k] else {} for k in keys}, {k: mul(g[k], Ric2) if g[k] else {} for k in keys}, {k: mul(g[k], Riem2) if g[k] else {} for k in keys}]
    return lin_c, quad_c
eta_low = None

# ------------------------------------------------------------------------------------------------ [bit] the engine route
def bit_route(n, seed):
    global eta_low
    sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); Fm = Gv.Fm; S = koszul_S(n, sq, Lie_); rng = random.Random(seed)
    e = rand_frame(rng, n, deg=3, coef=2, density=.3)
    Dp = anholonomy(Gv, e, n, 2); om = omega_closed_form(Gv, e, S, n, 2, Dpre=Dp)[0]; E = Dp[1]
    with trunc(n, xdeg=1): T = Gv.torsion(om, e); R = Gv.curvature(om)
    tfree = all(c == 0 for x in T for p in x.values() for k, c in p.items() if sum(k[:n]) <= 1)          # d e is not truncated: read x-degree <= 1 only
    I = range(n); zero = (0,) * n
    with trunc(n, xdeg=1):
        Rf = {}
        for A, (c, d) in enumerate(pairs_of(Gv.L)):
            for a in I:
                for b in I:
                    t = {}
                    for mu in I:
                        for nu in range(mu + 1, n):
                            p = R[A].get((1 << mu) | (1 << nu), {})
                            if p: t = padd(t, pm(p, padd(pm(E[mu][a], E[nu][b]), pm(E[nu][a], E[mu][b]), -1)))
                    Rf[(c, d, a, b)] = t; Rf[(d, c, a, b)] = scale(t, -1)
        for c in I:
            for a in I:
                for b in I: Rf[(c, c, a, b)] = {}
        Rl = {(c, d, a, b): scale(Rf[(c, d, a, b)], sq[c] * sq[d]) for (c, d, a, b) in itertools.product(I, repeat=4)}
        Ric = {(b, d): lin(*[(F(sq[b]), Rf[(a, b, a, d)]) for a in I]) for b in I for d in I}
        Rs = lin(*[(F(1), Rf[(a, b, a, b)]) for a in I for b in I])
        eta_low = lambda a, b: const(n, sq[a]) if a == b else {}
        lin_c, quad_c = candidates(Rl, Ric, Rs, lambda a, b: const(n, sq[a]) if a == b else {}, n, pm)
        th = GH.theta_forms(e, Fm, n)
        def to_form(M):
            out = []
            for a in I:
                f = {}
                for b in I:
                    if M[(a, b)]: f = Fm.add(f, Fm.wedge({0: scale(M[(a, b)], sq[b])}, th[b]))
                out.append(f)
            return out
        forms_lin = [to_form(M) for M in lin_c]; forms_quad = [to_form(M) for M in quad_c]
        Eforms = {c: Gv.einstein(None, e, R, c)[0] for c in (F(0), F(1, 3))}
    e0, E0, det = E0_of(e, n, n); full = (1 << n) - 1
    def div_of(forms):
        with trunc(n, xdeg=0): DT = Gv.D_covector(om, forms)
        return [at0(DT[a].get(full, {}), n) / det for a in I]
    out = dict(tfree=tfree, e=e, E0=E0, n=n, sq=sq,
               dE={c: div_of(Ef) for c, Ef in Eforms.items()}, Enz=any(at0(p, n) for Ef in Eforms.values() for x in Ef for p in x.values()),
               div_lin=[div_of(f) for f in forms_lin], div_quad=[div_of(f) for f in forms_quad],
               val_quad=[{k: at0(v, n) for k, v in M.items()} for M in quad_c], val_lin=[{k: at0(v, n) for k, v in M.items()} for M in lin_c])
    return out

# ------------------------------------------------------------------------------------------------ [std] Christoffel calculus as exact series
def std_geom(e, n, sq, K):
    g = std_metric(e, n, sq, n, K + 2); gi, g0, g0i = std_inverse_metric(g, n, n, K + 1); I = range(n)
    Gam = {}
    for l in I:
        for m in I:
            for v in range(m, n):
                t = {}
                for s in I:
                    br = sp_add(sp_add(sp_der(g[(s, v)], m), sp_der(g[(s, m)], v)), sp_der(g[(m, v)], s), -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, K + 1, n), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    Rup = {}
    for (r, s, m, v) in itertools.product(I, repeat=4):
        t = sp_add(sp_der(Gam[(r, v, s)], m), sp_der(Gam[(r, m, s)], v), -1)
        for l in I:
            t = sp_add(t, sp_mul(Gam[(r, m, l)], Gam[(l, v, s)], K, n)); t = sp_add(t, sp_mul(Gam[(r, v, l)], Gam[(l, m, s)], K, n), -1)
        Rup[(r, s, m, v)] = {k: c for k, c in t.items() if sum(k) <= K}
    Rl = {(r, s, m, v): lin(*[(F(1), sp_mul(g[(r, a)], Rup[(a, s, m, v)], K, n)) for a in I]) for (r, s, m, v) in itertools.product(I, repeat=4)}
    Ric = {(s, v): lin(*[(F(1), Rup[(r, s, r, v)]) for r in I]) for s in I for v in I}
    Rs = lin(*[(F(1), sp_mul(gi[(s, v)], Ric[(s, v)], K, n)) for s in I for v in I])
    return g, gi, g0, g0i, Gam, Rl, Ric, Rs
def cov(T, rank, Gam, n, deg):
    """(nabla T)_{c i1..ik} = d_c T - sum_j Gam^r_{c i_j} T_{..r..}, truncated at x-degree deg"""
    out = {}; I = range(n)
    for c in I:
        for idx in itertools.product(I, repeat=rank):
            t = {k: v for k, v in sp_der(T[idx], c).items() if sum(k) <= deg}
            for j in range(rank):
                for r in I:
                    G_ = Gam[(r, c, idx[j])]
                    if not G_: continue
                    j2 = list(idx); j2[j] = r; q = T[tuple(j2)]
                    if q: t = sp_add(t, sp_mul(G_, q, deg, n), -1)
            out[(c,) + idx] = t
    return out
def std_div0(M, gi, g0i, Gam, n):
    """g^{mn} nabla_m M_{n l} at the origin, l = 0..n-1"""
    NM = cov(M, 2, Gam, n, 0)
    return [sum(g0i[m][v] * at0(NM[(m, v, l)], n) for m in range(n) for v in range(n)) for l in range(n)]
def std_route(e, n, sq, K=1, fourth=False):
    global eta_low
    g, gi, g0, g0i, Gam, Rl, Ric, Rs = std_geom(e, n, sq, K + (2 if fourth else 0))
    mul = lambda p, q: sp_mul(p, q, 1, n)
    eta_low = lambda a, b: g[(a, b)]
    lin_c, quad_c = candidates(Rl, Ric, Rs, lambda a, b: gi[(a, b)], n, mul)
    res = dict(div_lin=[std_div0(M, gi, g0i, Gam, n) for M in lin_c], div_quad=[std_div0(M, gi, g0i, Gam, n) for M in quad_c])
    if fourth:
        D = 3
        NRic = cov(Ric, 2, Gam, n, D - 1); NNRic = cov(NRic, 3, Gam, n, D - 2)
        boxRic = {(a, b): lin(*[(F(1), sp_mul(gi[(c, d)], NNRic[(c, d, a, b)], 1, n)) for c in range(n) for d in range(n)]) for a in range(n) for b in range(n)}
        dR = {(c,): Rs for c in [None]}
        NR = {(c,): {k: v for k, v in sp_der(Rs, c).items() if sum(k) <= D - 1} for c in range(n)}
        NNR = cov(NR, 1, Gam, n, D - 2); hessR = {(a, b): NNR[(a, b)] for a in range(n) for b in range(n)}
        boxR = lin(*[(F(1), sp_mul(gi[(a, b)], hessR[(a, b)], 1, n)) for a in range(n) for b in range(n)])
        gbox = {(a, b): sp_mul(g[(a, b)], boxR, 1, n) for a in range(n) for b in range(n)}
        res['div_four'] = [std_div0(M, gi, g0i, Gam, n) for M in (boxRic, hessR, gbox)]
    return res

def kernel(vectors_per_frame):
    """vectors_per_frame: list over frames of [div vector of candidate i]; returns a basis of {c : sum_i c_i div_i = 0 on every frame}"""
    k = len(vectors_per_frame[0]); rows = []
    for vecs in vectors_per_frame:
        for comp in range(len(vecs[0])): rows.append([vecs[i][comp] for i in range(k)])
    w, rank, nvar, cons = solve_exact(rows, [F(0)] * len(rows))
    M = [r[:] for r in rows]; piv = []; r = 0
    for c in range(k):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
    basis = []
    for fcol in [c for c in range(k) if c not in piv]:
        v = [F(0)] * k; v[fcol] = F(1)
        for i, c in enumerate(piv): v[c] = -M[i][fcol]
        basis.append(v)
    return basis
def same_span(B, vecs): return rank_exact([list(x) for x in B + vecs]) == len(B) == rank_exact([list(x) for x in vecs]) if B else not vecs

def main():
    head('GSB-LOVELOCK: divergence-free symmetric tensors from the curvature, n = 4 and 5' + (' [fault %s]' % FAULT if FAULT else ''))
    for n, seeds in ((4, [4401, 4402, 4403]),) + (() if QUICK else ((5, [5501, 5502]),)):
        head('n = %d: %d random frames (degree 3), torsion-free A3 connection as a 2-jet' % (n, len(seeds)))
        runs = []
        for s in seeds:
            b = bit_route(n, s); runs.append(b)
            sd = std_route(b['e'], n, b['sq'])
            fr = lambda v: [sum(v[mu] * b['E0'][mu][a] for mu in range(n)) for a in range(n)]
            ok = all(fr(sd['div_lin'][i]) == b['div_lin'][i] for i in range(3)) and all(fr(sd['div_quad'][i]) == b['div_quad'][i] for i in range(7))
            chk('bit==std', ok and b['tfree'], 'n=%d frame %d: [std] Christoffel series: the divergences of the 10 candidates at the origin equal the engine\'s (frame components); omega torsion-free to first order' % (n, s))
            tick('n=%d frame %d' % (n, s))
        if n == 4:
            chk('bit', all(all(x == 0 for x in r['dE'][c]) for r in runs for c in r['dE']) and all(r['Enz'] for r in runs), 'n=4: D E_a = 0 at the origin for c = 0 and 1/3 on all three frames (E_a != 0): G_ab + Lambda g_ab is divergence-free')
            gt = [F(1), F(-1, 4) if FAULT == 'TRACE' else F(-1, 2), F(0)]
            dg = [[sum(gt[i] * r['div_lin'][i][a] for i in range(3)) for a in range(n)] for r in runs]
            chk('bit', all(all(x == 0 for x in v) for v in dg), 'n=4: G_ab = R_ab - (1/2) R g_ab built from the candidates has zero divergence on all frames (the contracted Bianchi identity)')
            dw = [[sum([F(1), F(-1, 4), F(0)][i] * r['div_lin'][i][a] for i in range(3)) for a in range(n)] for r in runs]
            chk('ctl', any(any(x != 0 for x in v) for v in dw), 'n=4: R_ab - (1/4) R g_ab (the wrong trace coefficient) has non-zero divergence')
        alone = all(any(any(x != 0 for x in r['div_lin'][i]) for r in runs) for i in range(2)) and all(any(any(x != 0 for x in r['div_quad'][i]) for r in runs) for i in range(7))
        chk('ctl', alone, 'n=%d: each candidate alone (R_ab, R g_ab and the seven quadratic ones) has non-zero divergence on some frame: the test can fail' % n)
        Kl = kernel([r['div_lin'] for r in runs]); Kq = kernel([r['div_quad'] for r in runs])
        chk('bit', len(Kl) == 2 and same_span(Kl, [[F(1), F(-1, 2), F(0)], [F(0), F(0), F(1)]]), 'n=%d: the divergence-free combinations of (R_ab, R g_ab, g_ab) on these frames: dimension %d, span{G_ab, g_ab}' % (n, len(Kl)))
        hv = H_WRONG if FAULT == 'LANCZOS' else H_COEF
        chk('bit', len(Kq) == 1 and same_span(Kq, [hv]), 'n=%d: the divergence-free combinations of the seven quadratic tensors: dimension %d, spanned by the Lanczos coefficients (2, -4, -4, 2, -1/2, 2, -1/2)' % (n, len(Kq)))
        Hval = [{k: sum(hv[i] * r['val_quad'][i][k] for i in range(7)) for k in r['val_quad'][0]} for r in runs]
        Hz = all(all(v == 0 for v in Hk.values()) for Hk in Hval)
        if n == 4:
            chk('bit', Hz, 'n=4: H_ab is the zero tensor at the origin of every frame (all 16 components): in four dimensions the quadratic sector gives no new divergence-free tensor')
            Hw = [{k: sum(H_WRONG[i] * r['val_quad'][i][k] for i in range(7)) for k in r['val_quad'][0]} for r in runs]
            chk('ctl', any(any(v != 0 for v in Hk.values()) for Hk in Hw), 'n=4: the Lanczos combination with the last coefficient -1 in place of -1/2 is not zero')
        else:
            chk('bit', (not Hz) if FAULT != 'N5' else Hz, 'n=5: H_ab is divergence-free and not zero (largest component %s): the second Lovelock tensor; the four-dimensional identity H = 0 does not hold at n = 5' % max(abs(v) for Hk in Hval for v in Hk.values()))
        tick('n=%d kernels' % n)
    if QUICK: finish('GSB-LOVELOCK')
    head('n = 4, [std] only: with the fourth-order tensors box R_ab, nabla_a nabla_b R, g_ab box R (frames of degree 5, Riemann to third order)')
    four = []
    for s in (4601, 4602, 4603, 4604):
        e = rand_frame(random.Random(s), 4, deg=5, coef=1, density=.12); sd = std_route(e, 4, LORENTZ(4), 1, fourth=True)
        four.append(sd['div_quad'] + sd['div_four'])
        tick('frame %d' % s)
    K4 = kernel(four)
    second_only = kernel([v[:7] for v in four])
    has_H = rank_exact([list(x) for x in K4] + [H_COEF + [F(0)] * 3]) == len(K4)
    fourth_in_rest = all(any(v[i] != 0 for i in range(7, 10)) for v in K4 if rank_exact([list(v), H_COEF + [F(0)] * 3]) == 2)
    chk('std', len(K4) == 3 and has_H and len(second_only) == 1, 'n=4 [std]: with the three fourth-order tensors the divergence-free combinations have dimension %d (H and %d more, each with a fourth-order part); without them dimension %d (H): the second-order hypothesis of the theorem is needed' % (len(K4), len(K4) - 1, len(second_only)))
    chk('ctl', all(any(x != 0 for x in v[7]) for v in four[:1]), 'n=4 [std]: box R_ab alone has non-zero divergence')
    tick('done')
    finish('GSB-LOVELOCK')

if __name__ == '__main__': main()
