#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-SMARR.  Smarr's formula from Euler's theorem: M(Abar, J, Q) of the Kerr-Newman family has weight 1, and the engine's kH, Omega_H, Phi_H are its partial derivatives.   python3 gm_smarr_euler.py

 Variables of the Atlas: Abar = A/(4 pi), J, Q (the Coulomb coefficient of A), kappa (the coupling, an input), q = kappa Q^2/2.  Closed form (Christodoulou-Ruffini, recalled):
 M^2 = N/D, N = (Abar + q)^2 + 4 J^2, D = 4 Abar.
 Derivation: N has weight 4 and D weight 2 under (Abar, J, Q) -> (lambda^2 Abar, lambda^2 J, lambda Q), so M has weight 1 and Euler's relation E M = M holds, E = 2 Abar d_Abar + 2 J d_J + Q d_Q.
 With d_Abar M = kH/2, d_J M = Omega_H, d_Q M = (kappa/2) Phi_H (the first law dM = (kH/2) dAbar + Omega dJ + (kappa/2) Phi dQ, constants (alpha, beta, gamma) = (1/2, 1, kappa/2)),
 Euler gives Smarr M = kH Abar + 2 Omega J + (kappa/2) Phi Q, constants (alpha', beta', gamma') = (2 alpha, 2 beta, gamma): the weights times the partial derivatives.
 In G = 1 units (A = 4 pi Abar, charge q_s = Q sqrt(kappa/2), Phi_s = Phi sqrt(kappa/2)): M = kH A/(4 pi) + 2 Omega J + Phi_s q_s and dM/dA = kH/(8 pi).
 [std]  own exact polynomial code: N(lambda^2 Abar, lambda^2 J, lambda Q) = lambda^4 N, D(...) = lambda^2 D, E(N) D - N E(D) = 2 N D; hand-coded partial derivatives of M (quotient rule on N/D)
        at each member against f2_first_law.cr_partials, and the first law dM = sum (d_X M) dX along the directions of each member (dual numbers of f2_first_law.family_closed).
 [bit]  the engine's kH (nabla_chi chi = kH chi with the closed-form connection, Grav.D_vector), Omega_H (double root on the frame), Abar (frame area), Phi_H (gauge value chi.A, ray
        integral at a = 0) by f2_first_law.horizon_numbers at every member of f2_first_law.MEMBERS (outer and inner horizons, two extremal members) and three near-extremal members.
 [bit==std] kH = 2 d_Abar M, Omega = d_J M, (kappa/2) Phi = d_Q M at each; Smarr from the engine numbers; the constants as ratios.
 Controls: weights (2, 2, 2) (the Euler identity fails; Smarr with these exponents fails at the charged members); the coefficient 1 on Omega J (fails at the rotating members);
 Smarr with the first-law constants (1/2, 1, kappa/2) (fails where kH Abar or Omega J is not zero). The extremal members (kH = 0) still obey Smarr.
 Scope: the polynomial identities for all (Abar, J, Q); the engine at the stated members, two rational points of each horizon."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import f2_first_law as F2
from f2_first_law import MEMBERS, horizon_numbers, family_closed, cr_partials, one, SQ

NV = 4                                                              # variables Abar, J, Q, lambda
AB, JJ, QQ, LM = (var(NV, i) for i in range(NV))
def sp(a, b): return sp_mul(a, b, 99, NV)
def ND(kappa):
    q = scale(sp(QQ, QQ), F(kappa, 2)); Aq = sp_add(AB, q)
    return sp_add(sp(Aq, Aq), scale(sp(JJ, JJ), 4)), scale(AB, 4)
def substitute(p, w):
    """p(lambda^w0 Abar, lambda^w1 J, lambda^w2 Q): each monomial gets lambda^(w . exponents)"""
    out = {}
    for ex, v in p.items():
        k = (ex[0], ex[1], ex[2], ex[3] + w[0] * ex[0] + w[1] * ex[1] + w[2] * ex[2]); out[k] = out.get(k, 0) + v
    return {k: v for k, v in out.items() if v}
def euler(p, w): return lin((F(w[0]), sp(AB, sp_der(p, 0))), (F(w[1]), sp(JJ, sp_der(p, 1))), (F(w[2]), sp(QQ, sp_der(p, 2))))
def lam_pow(k): return {(0, 0, 0, k): F(1)}
def ev(p, Ab, J, Q): return sum((v * Ab ** ex[0] * J ** ex[1] * Q ** ex[2] for ex, v in p.items() if ex[3] == 0), F(0))
def partials(kappa, Ab, J, Q, M):
    """[std] hand-coded: d_X M = (N_X D - N D_X)/(2 M D^2) at the point; returns (M^2, dAbar, dJ, dQ)"""
    N, D = ND(kappa); n, d = ev(N, Ab, J, Q), ev(D, Ab, J, Q)
    out = [n / d]
    for i in range(3): out.append((ev(sp_der(N, i), Ab, J, Q) * d - n * ev(sp_der(D, i), Ab, J, Q)) / (2 * M * d * d))
    return tuple(out)
NEAR = [('near-extremal Kerr', 1, F(61), F(60), F(0), [(1, 0, 0), (0, 1, 0)]), ('near-extremal RN', 2, F(25), F(0), F(24), [(1, 0, 0), (0, 0, 1)]),
        ('near-extremal Kerr-Newman', 2, F(15), F(10), F(11), [(1, 0, 0), (0, 1, 0), (0, 0, 1)])]

def main():
    T0 = time.time()
    head('(1) homogeneity and Euler\'s relation as polynomial identities in (Abar, J, Q, lambda) [std]')
    for kap in (1, 2, 4):
        N, D = ND(kap)
        hom = substitute(N, (2, 2, 1)) == sp(lam_pow(4), N) and substitute(D, (2, 2, 1)) == sp(lam_pow(2), D)
        eul = sp_add(sp_add(sp(euler(N, (2, 2, 1)), D), sp(N, euler(D, (2, 2, 1))), -1), scale(sp(N, D), 2), -1) == {}
        chk('std', hom and eul, 'kappa = %s: N = (Abar + kappa Q^2/2)^2 + 4 J^2 has weight 4, D = 4 Abar weight 2 under (lambda^2, lambda^2, lambda): M^2 = N/D has weight 2, M weight 1; E(N) D - N E(D) = 2 N D (Euler for M^2, so E M = M)' % kap)
        hom2 = substitute(N, (2, 2, 2)) == sp(lam_pow(4), N)
        eul2 = sp_add(sp_add(sp(euler(N, (2, 2, 2)), D), sp(N, euler(D, (2, 2, 2))), -1), scale(sp(N, D), 2), -1) == {}
        chk('ctl', not hom2 and not eul2, 'kappa = %s: the weights (2, 2, 2): N is not homogeneous of weight 4 and the Euler identity fails' % kap)

    head('(2) the engine\'s horizon numbers against the partial derivatives of M(Abar, J, Q); Smarr; the first law along the family [bit], [std], [bit==std]')
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # built per run: an engine fault put into Lie in memory is seen
    ratios = {'alpha': set(), 'beta': set(), 'gamma/kappa': set()}; rows = []
    for (fam, kap, M, a, Q, dirs) in list(MEMBERS) + NEAR:
        M, a, Q = F(M), F(a), F(Q); s = F(kap) * Q * Q / 4
        for br in ((1,) if fam in ('Schwarzschild', 'extremal RN') else (1, -1)):
            cf = family_closed(kap, M, a, Q, (0, 0, 0), br); rh = cf['rh'].v
            out = horizon_numbers(Gv, S, M, a, s, rh, F2.ANG, Q=Q, ray=True)
            kH, Om, Ab, Phi = one(out['kH']), one(out['Om']), one(out['area']), (one(out['phi']) if Q else F(0))
            tag = '%s kappa=%s (M, a, Q) = (%s, %s, %s) %s r = %s' % (fam, kap, M, a, Q, 'outer' if br == 1 else 'inner', rh)
            okb = out['null'] == {0} and out['disc'] == {0} and None not in (kH, Om, Ab, Phi) and out['exact'] and out['ray'] and out['std']
            J = M * a
            M2, dA, dJ, dQ = partials(kap, Ab, J, Q, M) if okb else (None,) * 4
            M2f, dAf, dJf, dQf = cr_partials(kap, Ab, J, Q, M) if okb else (None,) * 4
            chk('std', okb and M2 == M * M and (M2, dA, dJ, dQ) == (M2f, dAf, dJf, dQf), '%s: M^2 = N/D = %s; hand-coded d M/d(Abar, J, Q) = (%s, %s, %s) = f2_first_law.cr_partials' % (tag, M2, dA, dJ, dQ))
            if not okb:
                chk('bit', False, '%s: the engine numbers are not all defined (kH, Omega, Abar, Phi) = (%s, %s, %s, %s)' % (tag, kH, Om, Ab, Phi)); continue
            ok_fl = True
            for dirn in dirs:
                cd = family_closed(kap, M, a, Q, dirn, br)
                ok_fl &= cd['M'].d == dA * cd['Abar'].d + dJ * cd['J'].d + dQ * cd['Q'].d
            chk('std', okb and ok_fl, '%s: the first law dM = (d_Abar M) dAbar + (d_J M) dJ + (d_Q M) dQ along the %d directions (dM, da, dQ) of the family (dual numbers)' % (tag, len(dirs)))
            eq = okb and kH == 2 * dA and Om == dJ and F(kap) * Phi == 2 * dQ
            smarr_b = okb and M == kH * Ab + 2 * Om * J + F(kap, 2) * Phi * Q
            smarr_s = okb and M == 2 * Ab * dA + 2 * J * dJ + Q * dQ
            chk('bit==std', eq and smarr_b and smarr_s, '%s: engine (kH, Omega, Abar, Phi) = (%s, %s, %s, %s): kH = 2 d_Abar M, Omega = d_J M, (kappa/2) Phi = d_Q M; M = kH Abar + 2 Omega J + (kappa/2) Phi Q = E M' % (tag, kH, Om, Ab, Phi))
            if okb:
                if kH: ratios['alpha'].add(dA / kH)
                if Om: ratios['beta'].add(dJ / Om)
                if Phi: ratios['gamma/kappa'].add(dQ / (Phi * kap))
                rows.append(dict(fam=fam, kap=kap, M=M, a=a, Q=Q, br=br, kH=kH, Om=Om, Ab=Ab, Phi=Phi, J=J, dA=dA, dJ=dJ, dQ=dQ, tag=tag))
    print('    (engine numbers: %.1f s)' % (time.time() - T0), flush=True)
    head('(3) the constants are derived: ratios of the partial derivatives to the engine numbers, and the Euler weights [bit==std]')
    chk('bit==std', ratios == {'alpha': {F(1, 2)}, 'beta': {F(1)}, 'gamma/kappa': {F(1, 2)}},
        'over %d (member, horizon) pairs: d_Abar M / kH = %s, d_J M / Omega = %s, d_Q M / (kappa Phi) = %s: (alpha, beta, gamma) = (1/2, 1, kappa/2); Smarr (alpha\', beta\', gamma\') = (2, 2, 1) x (alpha, beta, gamma) = (1, 2, kappa/2)' % (
            len(rows), ', '.join(map(str, sorted(ratios['alpha']))), ', '.join(map(str, sorted(ratios['beta']))), ', '.join(map(str, sorted(ratios['gamma/kappa'])))))
    ext = [r for r in rows if r['kH'] == 0]
    chk('bit', len(ext) == 2 and all(r['M'] == r['kH'] * r['Ab'] + 2 * r['Om'] * r['J'] + F(r['kap'], 2) * r['Phi'] * r['Q'] for r in ext), 'the extremal members (kH = 0): %s obey Smarr, M = (kappa/2) Phi Q' % '; '.join(r['tag'] for r in ext))
    near = [r for r in rows if r['fam'].startswith('near')]
    chk('bit', len(near) == 6 and all(r['M'] == r['kH'] * r['Ab'] + 2 * r['Om'] * r['J'] + F(r['kap'], 2) * r['Phi'] * r['Q'] for r in near),
        'near-extremal members (outer and inner): Kerr a/M = 60/61, RN kappa Q^2/(2 M^2) = 576/625, Kerr-Newman (a^2 + kappa Q^2/2)/M^2 = 221/225: Smarr holds with the engine numbers (kH = %s)' % ', '.join(str(r['kH']) for r in near))
    head('(4) controls')
    ch = [r for r in rows if r['Q'] != 0]; rot = [r for r in rows if r['a'] != 0]
    chk('ctl', all(r['M'] != 2 * r['Ab'] * r['dA'] + 2 * r['J'] * r['dJ'] + 2 * r['Q'] * r['dQ'] for r in ch), 'Euler with the weights (2, 2, 2): M != 2 Abar d_Abar M + 2 J d_J M + 2 Q d_Q M at all %d charged (member, horizon) pairs' % len(ch))
    chk('ctl', all(r['M'] != r['kH'] * r['Ab'] + r['Om'] * r['J'] + F(r['kap'], 2) * r['Phi'] * r['Q'] for r in rot), 'Smarr with the coefficient 1 on Omega J fails at all %d rotating (member, horizon) pairs' % len(rot))
    nz = [r for r in rows if r['kH'] * r['Ab'] != 0 or r['Om'] * r['J'] != 0]
    chk('ctl', all(r['M'] != F(1, 2) * r['kH'] * r['Ab'] + r['Om'] * r['J'] + F(r['kap'], 2) * r['Phi'] * r['Q'] for r in nz), 'Smarr with the first-law constants (1/2, 1, kappa/2) in place of (1, 2, kappa/2) fails at all %d pairs where kH Abar or Omega J is not 0' % len(nz))
    print('\n  reading: M(Abar, J, Q) is homogeneous of weight 1 under (lambda^2, lambda^2, lambda); its partial derivatives are kH/2, Omega_H and (kappa/2) Phi_H at every member checked;'
          '\n  Euler gives M = kH Abar + 2 Omega_H J + (kappa/2) Phi_H Q, which is M = kH A/(4 pi) + 2 Omega_H J + Phi_s q_s in G = 1 units (A = 4 pi Abar, q_s = Q sqrt(kappa/2)); dM/dA = kH/(8 pi).')

if __name__ == '__main__':
    main(); finish('GM-SMARR')
