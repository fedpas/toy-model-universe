#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""KPG-MERON.  The meron on the Einstein static universe R x S^3 with a coupling g: D = d + g A^, F = dA + (g/2)[A, A].
    python3 ym_meron_coupling.py [--fault LAMQ|NOG|FONLY]

 Frame, points and field of ym_nonabelian_source.py (imported: s3_theta, s3_frame, inv_frame, geometry, meron, ym_on_frame, covariant_route,
 solve_kc, PTS, G_std): e^0 = dt, e^(i+1) = R theta^i, theta the Maurer-Cartan form of S^3 = SU(2) in Cayley coordinates, exact jets of degree 2
 at the 7 rational points (R, y0); A^C = 2 lambda theta^C on so(3).
 The coupling: the engine's so(3) table Lie([-1]*3) with every structure constant multiplied by g (a Lie object whose f entries are g f), so the
 engine's curvature is dA + (g/4) f A ^ A and its D_bivector is d + (g/2) f A ^: D = d + g A^ and F = dA + (g/2)[A, A].
 kpg·19 [bit]  for g = 2, 3/2, 1/3: A = lambda theta solves D*F = 0 exactly for lambda in {0, 1/(2g), 1/g} among {0, 1/(4g), 1/(2g), 3/(4g), 1/g,
        3/(2g)} at the 7 points (form route: the engine's curvature, the frame star of g2_hodge, D_bivector); at lambda = 1/(2g) also the
        covariant route nabla^a F^C_ab + (1/2) g f A^A_a F^B_ab = 0 (the engine's omega, g2_hodge.D_two_index); the residual at (g, lambda) is
        exactly (1/g) times the residual at (1, g lambda) for every lambda of the scan (the rescaling A -> g A); F = 0 at lambda = 1/g (pure gauge).
        With the stress formula of the coupling-1 row, T = -(1/2) sum_c F^c a F^c (the canonical normalisation, ym_matter_gravity.ym_stress_at_point):
        at lambda = 1/(2g), rho = 3/(2 g^2 R^4) = 3p, and E_a(0) + kappa T_a + c Y_a = 0 has the unique solution kappa = g^2 R^2, c = 1/(2R^2)
        (Lambda = 3c = 3/(2R^2), kappa rho = Lambda); the colour-by-pair matrix of F has rank 3 (not an embedded abelian field).
        [std] numpy in hyperspherical coordinates (the closed-form A = lambda g^-1 dg of ym_nonabelian_source with the coupling put into F and into
        the covariant divergence; five-point differences): the Yang-Mills residual below 1e-6 at lambda = 1/(2g) and above 1e-3 at lambda = 1/(4g),
        g = 2, 3/2, 1/3, R = 2, three points; G - Lambda delta = kappa T fitted by least squares. [bit==std] kappa = g^2 R^2 and Lambda = 3/(2R^2)
        from both routes at R = 2 (tolerance 1e-6).
 kpg·20 [ctl] (--fault puts each into the main lines): LAMQ lambda = 1/(4g); NOG the coupling ignored (the unscaled table with lambda = 1/(2g));
        FONLY the coupling in F only, not in D. Each gives D*F != 0.
 The solution with g = 1 is recalled as Hosotani's (the paper is not in the package); the rescaling with g is computed here.
 Engine faults: the script reads the curvature, d, D_bivector (f table), the frame's omega and Einstein form (h table, Einstein pairs)."""
import os, sys, copy, math, time
ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'LAMQ', 'NOG', 'FONLY'), 'unknown fault'
sys.argv = sys.argv[:1]                                   # the imported module reads its own --fault from the command line
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import ym_matter_gravity as YG
import ym_nonabelian_source as YN
import numpy as np
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
CNT = [0, 0]
def ck(tag, cond, msg): CNT[0 if cond else 1] += 1; return chk(tag, bool(cond), msg)
SQ = LORENTZ(4); GS = (F(2), F(3, 2), F(1, 3))

def coupled_lie(g):
    L = Lie([-1] * 3); Lg = copy.copy(L); Lg.f = {k: (c, F(v) * g) for k, (c, v) in L.f.items()}; return Lg
def ym_res(GF, GD, GL, A, e, E):
    """D*F at the point with the curvature of GF and the covariant derivative of GD (both Grav on 4 coordinates)"""
    with trunc(4, xdeg=2):
        Fc = GF.curvature(A); SF = [H.hodge_form(x, e, E, GL.Fm, SQ, 4) for x in Fc]; DSF = GD.D_bivector(A, SF)
    out = {}
    for C, x in enumerate(DSF):
        for m, q in x.items():
            v = at0(q, 4)
            if v != 0: out[(C, m)] = v
    return out, Fc                                         # the non-zero components of D*F at the point, keyed (colour, 3-form mask)

# ------------------------------------------------------------------------------------------------ [std] numpy with the coupling
def F_std_g(x, lam, gc, h=1e-3):
    dA = [[None] * 4 for _ in range(4)]
    for m in range(4):
        u = np.zeros(4); u[m] = h; Ap2, Ap1, Am1, Am2 = YN.A_std(x + 2 * u, lam), YN.A_std(x + u, lam), YN.A_std(x - u, lam), YN.A_std(x - 2 * u, lam)
        for n in range(4): dA[m][n] = (-Ap2[n] + 8 * Ap1[n] - 8 * Am1[n] + Am2[n]) / (12 * h)
    Av = YN.A_std(x, lam); return [[dA[m][n] - dA[n][m] + gc * (Av[m] @ Av[n] - Av[n] @ Av[m]) for n in range(4)] for m in range(4)]
def ym_std_g(x, R, lam, gc, h=1e-2):
    def J(y):
        gd = YN.gdiag(y, R); Fy = F_std_g(y, lam, gc); sg = math.sqrt(abs(np.prod(gd)))
        return [[sg * Fy[m][n] / (gd[m] * gd[n]) for n in range(4)] for m in range(4)]
    dJ = [None] * 4
    for m in range(4):
        u = np.zeros(4); u[m] = h; a, b, c, d = J(x + 2 * u), J(x + u), J(x - u), J(x - 2 * u)
        dJ[m] = [(-a[m][n] + 8 * b[m][n] - 8 * c[m][n] + d[m][n]) / (12 * h) for n in range(4)]
    gd = YN.gdiag(x, R); sg = math.sqrt(abs(np.prod(gd))); Fx = F_std_g(x, lam, gc); Av = YN.A_std(x, lam)
    return max(float(np.abs(sum(dJ[m][n] for m in range(4)) / sg + gc * sum(Av[m] @ (Fx[m][n] / (gd[m] * gd[n])) - (Fx[m][n] / (gd[m] * gd[n])) @ Av[m] for m in range(4))).max()) for n in range(4))
def T_std_g(x, R, lam, gc):
    gd = YN.gdiag(x, R); Fx = F_std_g(x, lam, gc); comp = lambda X: np.array([float(np.real(-2 * np.trace(YN.TG[c] @ X))) for c in range(3)])
    Fc = [[comp(Fx[m][n]) for n in range(4)] for m in range(4)]; F2 = sum(Fc[a][b] @ Fc[a][b] / (gd[a] * gd[b]) for a in range(4) for b in range(4))
    return np.array([[-sum(Fc[m][a] @ Fc[n][a] / (gd[m] * gd[a]) for a in range(4)) + (F2 / 4 if m == n else 0.0) for n in range(4)] for m in range(4)])

def main():
    head('KPG-MERON: the meron A = lambda q^-1 dq on R x S^3 with a coupling g, D = d + g A^' + (' [fault %s]' % FAULT if FAULT else ''))
    LL = Lie(SQ); GL = Grav(4, LL); S_ = koszul_S(4, SQ, LL)
    G1 = Grav(4, Lie([-1] * 3)); Gg = {g: Grav(4, coupled_lie(g)) for g in GS}
    pts = []
    for R, y0 in YN.PTS:
        th = YN.s3_theta(y0); e = YN.s3_frame(R, th); E = YN.inv_frame(e); om, E0c, Yc = YN.geometry(GL, S_, e); pts.append((R, y0, th, e, E, om, E0c, Yc))
    tick('the frame at the 7 points')
    okSol = okCov = okScan = okResc = okFlat = okT = okK = okRank = True; zsets = {}
    for g in GS:
        GF = Gg[g]; GD = Gg[g]
        if FAULT == 'NOG': GF = GD = G1
        if FAULT == 'FONLY': GD = G1
        lam_m = 1 / (4 * g) if FAULT == 'LAMQ' else 1 / (2 * g)
        scan = [F(0), 1 / (4 * g), 1 / (2 * g), 3 / (4 * g), 1 / g, 3 / (2 * g)]
        zs = None
        for R, y0, th, e, E, om, E0c, Yc in pts:
            res, Fc = ym_res(GF, GD, GL, YN.meron(th, lam_m), e, E); okSol &= not res
            with trunc(4, xdeg=2): Fab = [H.frame_components(x, E, 4) for x in Fc]
            cov, _ = YN.covariant_route(GL, GD, om, YN.meron(th, lam_m), Fab, E); okCov &= all(v == 0 for v in cov)
            z = []
            for lam in scan:
                r_g, Fl = ym_res(Gg[g], Gg[g], GL, YN.meron(th, lam), e, E); r_1, _ = ym_res(G1, G1, GL, YN.meron(th, g * lam), e, E)
                okResc &= r_g == {k: v / g for k, v in r_1.items()}
                if not r_g: z.append(lam)
                if lam == 1 / g: okFlat &= all(not {k: v for k, v in p.items() if sum(k) <= 1} for x in Fl for p in x.values())
            zs = z if zs is None else zs; okScan &= z == zs == [F(0), 1 / (2 * g), 1 / g]
            # the stress and the Einstein solve at the meron of coupling g
            with trunc(4, xdeg=2): Fc2 = Gg[g].curvature(YN.meron(th, 1 / (2 * g))); Fab2 = [H.frame_components(x, E, 4) for x in Fc2]
            Fls = [{(a, b): at0(Fx.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)} for Fx in Fab2]
            T = YG.ym_stress_at_point(Fls, F(-1, 2)); rho = T[0][0]
            okT &= all(T[b][a] == 0 for a in range(4) for b in range(4) if a != b) and rho == F(3, 2) / (g * g * R ** 4) and all(T[i][i] == -rho / 3 for i in (1, 2, 3))
            with trunc(4, xdeg=1): Ta = H.stress_forms(T, H.theta_forms(e, GL.Fm, 4), GL.Fm)
            Tc = einstein_components(Ta, 4, 4); w, rk, cons = YN.solve_kc(E0c, Tc, Yc)
            okK &= w is not None and len(w) == 2 and w[0] == g * g * R * R and w[1] == 1 / (2 * R * R)
            Mx = [[Fls[C][pr] for pr in sorted(Fls[C])] for C in range(3)]; okRank &= rank_exact(Mx) == 3
        zsets[g] = zs
    tick('the 3 couplings at the 7 points')
    gtxt = ', '.join(str(g) for g in GS)
    ck('bit', okSol, 'g = %s: A = theta/(2g) solves D*F = 0 with D = d + g A^ at the 7 points (form route)' % gtxt + (' [fault %s]' % FAULT if FAULT else ''))
    ck('bit', okCov, 'the covariant route nabla^a F^C_ab + (1/2) g f A^A_a F^B_ab = 0 at the 7 points, the same three couplings')
    ck('bit', okScan, 'among {0, 1/(4g), 1/(2g), 3/(4g), 1/g, 3/(2g)} exactly lambda in {0, 1/(2g), 1/g} solve D*F = 0, at each of the 7 points: %s' % '; '.join('g = %s: {%s}' % (g, ', '.join(map(str, zsets[g] or []))) for g in GS))
    ck('bit', okResc and okFlat, 'the residual at (g, lambda) is exactly (1/g) x the residual at (1, g lambda) for the six lambda, three g, 7 points (the rescaling A -> gA); F = 0 at lambda = 1/g (pure gauge)')
    ck('bit', okT and okK, 'with T = -(1/2) sum_c F^c a F^c: rho = 3/(2 g^2 R^4) = 3p, and E_a(0) + kappa T_a + c Y_a = 0 has the unique solution kappa = g^2 R^2, c = 1/(2R^2) (Lambda = 3/(2R^2), kappa rho = Lambda) at the 7 points, three g')
    ck('bit', okRank, 'the colour-by-pair matrix of F has rank 3 at the 7 points for the three couplings: not an embedded abelian field')
    head('[std] numpy in hyperspherical coordinates with the coupling in F and in D; [bit==std] kappa and Lambda')
    xs = [np.array([0.3, 0.7, 1.1, 0.4]), np.array([-0.5, 1.3, 0.6, 2.0]), np.array([1.0, 2.2, 2.0, -1.0])]
    R = 2.0; worst = 0.0; badq = 1.0; fit_ok = True; info = []
    for g in GS:
        gc = float(g); lam = 1 / (4 * gc) if FAULT == 'LAMQ' else 1 / (2 * gc)
        worst = max(worst, max(ym_std_g(x, R, lam, gc) for x in xs)); badq = min(badq, ym_std_g(xs[0], R, 1 / (4 * gc), gc))
        sols = []
        for x in xs:
            Tm = T_std_g(x, R, 1 / (2 * gc), gc); Gm = YN.G_std(x, R)
            Mx = np.array([[Tm[m, n], float(m == n)] for m in range(4) for n in range(4)]); b = np.array([Gm[m, n] for m in range(4) for n in range(4)])
            sol, *_ = np.linalg.lstsq(Mx, b, rcond=None); sols.append(sol)
            fit_ok &= abs(sol[0] - gc * gc * R * R) < 1e-6 * gc * gc * R * R and abs(sol[1] - 1.5 / R ** 2) < 1e-6
        info.append('g = %s: kappa = %.8f, Lambda = %.8f' % (g, sols[0][0], sols[0][1]))
    ck('std', worst < 1e-6, 'lambda = 1/(2g): the Yang-Mills residual with the coupling is below %.1e at 3 points, R = 2, g = %s' % (max(worst, 1e-16), gtxt))
    ck('ctl', badq > 1e-3, 'lambda = 1/(4g): the residual is at least %.2e (g = %s, one point)' % (badq, gtxt))
    ck('bit==std', fit_ok, 'G - Lambda delta = kappa T fitted with kappa = g^2 R^2 and Lambda = 3/(2R^2) at R = 2 (tolerance 1e-6), as the engine solve: ' + '; '.join(info))
    tick('std')
    head('controls on one point (R = 2, y0 = (1/2, 0, 0)) [ctl]')
    R, y0, th, e, E, om, E0c, Yc = pts[1]; g = F(2)
    r_q, _ = ym_res(Gg[g], Gg[g], GL, YN.meron(th, 1 / (4 * g)), e, E)
    r_n, _ = ym_res(G1, G1, GL, YN.meron(th, 1 / (2 * g)), e, E)
    r_f, _ = ym_res(Gg[g], G1, GL, YN.meron(th, 1 / (2 * g)), e, E)
    ck('ctl', bool(r_q), 'g = 2, lambda = 1/(4g) = 1/8: D*F != 0')
    ck('ctl', bool(r_n), 'the coupling ignored (the unscaled table) with lambda = 1/(2g) = 1/4: D*F != 0')
    ck('ctl', bool(r_f), 'the coupling in F only, not in D (lambda = 1/4, g = 2): D*F != 0')
    tick('controls')
    print('\nchecks: %d ok, %d FAIL' % tuple(CNT))

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('KPG-MERON' + ('-' + FAULT if FAULT else ''))
