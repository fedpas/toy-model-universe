#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-SPHERE.  The celestial sphere: the null lines of R^{1,3} are the points P(x) of the plane and one more point, and the Lorentz group acts by Mobius maps.   python3 gm_null_sphere.py

 Cell: Cl(1,3) as the null-pair algebra of projective_selfcheck.py on the base R^2 (space squares -1): generators e1, e2, e_p (square -1), e_m (square +1),
 eps = e_p + e_m, o = (e_m - e_p)/2 (null, eps.o = 1), x^2 = -(x1^2 + x2^2), P(x) = o + x - (1/2) x^2 eps, z = x1 + i x2.
 [bit]  the bit rule (the engine's bmul) on multivectors with exact polynomial coefficients:
        (1) P(x)^2 = 0 and P(x).P(y) = -(1/2)(x-y)^2 as identities in (x1, x2, y1, y2); 2 alpha v - (2 alpha^2 o + 2 alpha u - u^2 eps) = v^2 eps for v = alpha o + beta eps + u:
            a null line is [P(x)] or [eps], the plane plus one point.
        (2) six generator rotors R = a + b B (rotations (a, b) = (3/5, 4/5), boosts (5/4, 3/4)) and a product: (a, b, c, d) over Q(i) from the images of z = 0, 1, i, ad - bc = 1 by an exact
            square root, twenty more points, and the identity R P(x) R~ = |cz+d|^2 o + Re((az+b) conj(cz+d)) e1 + Im((az+b) conj(cz+d)) e2 + (1/2)|az+b|^2 eps in (x1, x2).
        (3) reflections in e1, e_p (the unit circle), a rational circle P(c) - (1/2) r^2 eps and the time vector e_m: the same with conj z (anti-Mobius); every generator rotor is a
            product of two vectors of square -1 (two inversions); the even element e_m e_p (V V~ = -1, not orthochronous) acts on null lines as the rotation by pi.
        (4) stabilisers with the engine's Lie table (h: (1/2)[B_A, gamma_b] = h gamma_c; f: [B_A, B_B] = f B_C): for n = eps, o, P(x0) the bivectors with B.n = 0 (dimension 3, iso(2))
            and with B.n parallel to n (dimension 4, iso(2) and the boost along n), both subalgebras; h and f against the bit-rule commutators.
 [std]  Hermitian 2 x 2 matrices H = t + X sx + Y sy + Z sz, H(z) = [[|z|^2, conj z], [z, 1]] = xi xi^dagger with xi = (conj z, 1), X -> A X A^dagger: det H = 0 and
        (1/2) det(H(z) + H(w)) = (1/2)|z - w|^2 (own polynomial code); textbook SL(2,C) matrices of the six generators (half angles), the Mobius map on z is conj(A) (numpy on twenty points);
        stabilisers in sl(2,C) of the point and of the null vector by numpy ranks.
 [bit==std] the dictionary (t, X, Y, Z) = (e_m, e1, e2, e_p): P(x) <-> H(z); the bit (a, b, c, d) = +- conj(A) for one sense of the parameter (printed); the dimensions.
 Controls: a reflection is not a Mobius map; a boost with a^2 - b^2 != 1 does not keep P(x).P(y) (it keeps the cone: every invertible even element psi acts on vectors as
 psi X psi~ = rho R X R~, checked for 1 + e1e2 + e_me_p); the element 1 + e1 (not of one parity) does not map P(x) to a vector; P(x) with -x^2 eps in place of -(1/2) x^2 eps is not null.
 Scope: exact identities in x (all points), the six generators and one product, four reflections, three null vectors for the stabilisers."""
import os, sys, random, itertools, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from g2_weyl import QI, qi
import numpy as np

SQ = [-1, -1, -1, 1]                       # e1, e2, e_p, e_m
E1, E2, EP, EM = 1, 2, 4, 8
NAMES = {E1: 'e1', E2: 'e2', EP: 'e_p', EM: 'e_m'}

# ------------------------------------------------------------------------------------------------ multivectors with polynomial coefficients (the bit rule)
def mv_mul(A, B, sq=SQ):
    r = {}
    for a, pa in A.items():
        for b, pb in B.items():
            m, s = bmul(a, b, sq)
            if s == 0: continue
            x = padd(r.get(m, {}), pm(pa, pb), s)
            if x: r[m] = x
            else: r.pop(m, None)
    return r
def mv_add(A, B, c=1):
    r = dict(A)
    for m, p in B.items():
        x = padd(r.get(m, {}), p, c)
        if x: r[m] = x
        else: r.pop(m, None)
    return r
def mv_scale(A, c): return {m: scale(p, c) for m, p in A.items()} if c != 0 else {}
def mv_rev(A): return {m: scale(p, gs.rsign(popc(m))) for m, p in A.items()}
def mv_const(d, nv): return {m: const(nv, c) for m, c in d.items() if c != 0}
def mv_eq(A, B): return not mv_add(A, B, -1)
def grades(A): return sorted({popc(m) for m in A})
def ev_poly(p, pt): return sum((v * math.prod(F(pt[i]) ** k for i, k in enumerate(ex)) for ex, v in p.items()), F(0))
def ev_mv(A, pt): return {m: ev_poly(p, pt) for m, p in A.items()}
def o_eps(nv): return mv_const({EM: F(1, 2), EP: F(-1, 2)}, nv), mv_const({EP: F(1), EM: F(1)}, nv)
def point(x1, x2, nv, half=F(1, 2)):
    """P(x) = o + x1 e1 + x2 e2 - half x^2 eps with x^2 = -(x1^2 + x2^2); x1, x2 polynomials"""
    o, eps = o_eps(nv); x2sq = lin((F(-1), pm(x1, x1)), (F(-1), pm(x2, x2)))
    return mv_add(mv_add(o, {E1: x1, E2: x2}), mv_mul({0: x2sq}, eps), -half)

# ------------------------------------------------------------------------------------------------ Q(i): exact square root, null space, Mobius maps
def rsqrt(q):
    q = F(q)
    if q < 0: return None
    a, b = math.isqrt(q.numerator), math.isqrt(q.denominator)
    return F(a, b) if a * a == q.numerator and b * b == q.denominator else None
def qsqrt(z):
    z = qi(z); r = rsqrt(z.re ** 2 + z.im ** 2)
    if r is None: return None
    u, v = rsqrt((r + z.re) / 2), rsqrt((r - z.re) / 2)
    if u is None or v is None: return None
    s = QI(u, v if z.im >= 0 else -v)
    return s if s * s == z else None
def nullvec(rows):
    """one non-zero vector of the null space of a 3 x 4 matrix over Q(i) (rank 3 assumed; None otherwise)"""
    M = [[qi(x) for x in r] for r in rows]; piv = []; r = 0
    for c in range(4):
        p = next((i for i in range(r, len(M)) if not M[i][c].iszero()), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = QI(1) / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and not M[i][c].iszero(): f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
    free = [c for c in range(4) if c not in piv]
    if len(free) != 1: return None
    v = [QI(0)] * 4; v[free[0]] = QI(1)
    for i, c in enumerate(piv): v[c] = -M[i][free[0]]
    return v
INF = 'inf'
def image_z(V):
    """the point of the plane (as z in Q(i)) of a null vector V given by rational coefficients, or INF for a multiple of eps"""
    co = V.get(EM, 0) - V.get(EP, 0)
    if co == 0: return INF if V.get(E1, 0) == 0 and V.get(E2, 0) == 0 else None
    return QI(V.get(E1, 0) / co, V.get(E2, 0) / co)
def fit(pairs, anti=False, normalise=True):
    """(a, b, c, d) with w = (a s + b)/(c s + d), s = z (or conj z), from three (z, w) pairs; normalised to ad - bc = 1 when the square root is in Q(i) (normalise=False: the projective map)"""
    rows = []
    for z, w in pairs:
        s = z.conj() if anti else z
        rows.append([QI(0), QI(0), s, QI(1)] if w == INF else [s, QI(1), -w * s, -w])
    v = nullvec(rows)
    if v is None: return None, None
    det = v[0] * v[3] - v[1] * v[2]
    if det.iszero(): return None, det
    if not normalise: return v, det
    k = qsqrt(det)
    if k is None: return None, det
    return [x / k for x in v], det
def mob(abcd, z, anti=False):
    a, b, c, d = abcd; s = z.conj() if anti else z; den = c * s + d
    return INF if den.iszero() else (a * s + b) / den
def poly_target(abcd, nv, anti=False, sign=1):
    """|cz+d|^2 o + Re((az+b) conj(cz+d)) e1 + Im(...) e2 + (1/2)|az+b|^2 eps as polynomials in x1, x2 (z -> conj z for anti)"""
    a, b, c, d = abcd; x1, x2 = var(nv, 0), var(nv, 1); y2 = scale(x2, -1) if anti else x2
    def cpoly(p, q):                                            # p s + q with s = x1 + i y2: (re, im)
        return lin((p.re, x1), (-p.im, y2), (q.re, const(nv, 1))), lin((p.im, x1), (p.re, y2), (q.im, const(nv, 1)))
    ar, ai = cpoly(a, b); cr, ci = cpoly(c, d)
    re = lin((F(1), pm(ar, cr)), (F(1), pm(ai, ci))); im = lin((F(1), pm(ai, cr)), (F(-1), pm(ar, ci)))
    lam = lin((F(1), pm(cr, cr)), (F(1), pm(ci, ci))); mu = lin((F(1), pm(ar, ar)), (F(1), pm(ai, ai)))
    o, eps = o_eps(nv)
    out = mv_add(mv_add(mv_mul({0: lam}, o), {E1: re, E2: im}), mv_mul({0: mu}, eps), F(1, 2))
    return mv_scale(out, sign)

# ------------------------------------------------------------------------------------------------ [std] Hermitian matrices, SL(2,C) (no engine, no bit rule)
def m2mul(A, B): return [[A[i][0] * B[0][j] + A[i][1] * B[1][j] for j in range(2)] for i in range(2)]
def m2conj(A): return [[x.conj() for x in r] for r in A]
def m2det(A): return A[0][0] * A[1][1] - A[0][1] * A[1][0]
SIG = {'x': [[QI(0), QI(1)], [QI(1), QI(0)]], 'y': [[QI(0), QI(0, -1)], [QI(0, 1), QI(0)]], 'z': [[QI(1), QI(0)], [QI(0), QI(-1)]]}
def std_A(kind, axis, c, s, sense):
    """textbook SL(2,C): boost along the axis A = ch + sense sh sigma; rotation about the axis A = cos - sense i sin sigma (half angles c, s)"""
    S = SIG[axis]; I = [[QI(1), QI(0)], [QI(0), QI(1)]]
    k = QI(sense * s) if kind == 'boost' else QI(0, -sense * s)
    return [[I[i][j] * c + S[i][j] * k for j in range(2)] for i in range(2)]
def H_num(z): return np.array([[abs(z) ** 2, np.conj(z)], [z, 1]], dtype=complex)

def main():
    rng = random.Random(30)
    # ============================================================================== (1) the null lines
    head('(1) P(x) is null, P(x).P(y) = -(1/2)(x-y)^2, and every null line is [P(x)] or [eps]: identities in the coordinates [bit]')
    nv = 4; X1, X2, Y1, Y2 = (var(nv, i) for i in range(4))
    P, Qy = point(X1, X2, nv), point(Y1, Y2, nv)
    chk('bit', not mv_mul(P, P) and grades(P) == [1], 'P(x)^2 = 0 as a polynomial identity in (x1, x2); P(x) is a vector')
    sym_ = mv_scale(mv_add(mv_mul(P, Qy), mv_mul(Qy, P)), F(1, 2))
    dx2 = lin((F(-1), pm(lin((F(1), X1), (F(-1), Y1)), lin((F(1), X1), (F(-1), Y1)))), (F(-1), pm(lin((F(1), X2), (F(-1), Y2)), lin((F(1), X2), (F(-1), Y2)))))
    chk('bit', set(sym_) <= {0} and sym_.get(0, {}) == scale(dx2, F(-1, 2)), 'P(x).P(y) = -(1/2)(x-y)^2 = (1/2)((x1-y1)^2 + (x2-y2)^2) as a polynomial identity in four variables')
    nv5 = 4; al, be, u1, u2 = (var(nv5, i) for i in range(4)); o5, eps5 = o_eps(nv5)
    v = mv_add(mv_add(mv_mul({0: al}, o5), mv_mul({0: be}, eps5)), {E1: u1, E2: u2}); v2 = mv_mul(v, v)
    u2s = lin((F(-1), pm(u1, u1)), (F(-1), pm(u2, u2)))
    lhs = mv_add(mv_scale(mv_mul({0: al}, v), 2), mv_add(mv_add(mv_mul({0: pm(al, al)}, mv_scale(o5, 2)), mv_scale(mv_mul({0: al}, {E1: u1, E2: u2}), 2)), mv_mul({0: u2s}, eps5), -1), -1)
    chk('bit', set(v2) <= {0} and v2.get(0, {}) == lin((F(2), pm(al, be)), (F(1), u2s)) and mv_eq(lhs, mv_mul({0: v2.get(0, {})}, eps5)),
        'v = alpha o + beta eps + u: v^2 = 2 alpha beta + u^2 and 2 alpha v - (2 alpha^2 o + 2 alpha u - u^2 eps) = v^2 eps: a null v with alpha != 0 is alpha P(u/alpha); alpha = 0 forces u^2 = 0, u = 0, v = beta eps')
    Pw = point(X1, X2, nv, half=F(1))
    chk('ctl', mv_mul(Pw, Pw) != {}, 'P(x) = o + x - x^2 eps (the factor 1/2 dropped) is not null')
    # [std] Hermitian matrices
    def sp(a, b): return sp_mul(a, b, 8, nv)
    Hz = lambda a1, a2: [[(lin((F(1), sp(a1, a1)), (F(1), sp(a2, a2))), {}), (a1, scale(a2, -1))], [(a1, a2), (const(nv, 1), {})]]     # entries (re, im)
    def cmul(p, q): return (lin((F(1), sp(p[0], q[0])), (F(-1), sp(p[1], q[1]))), lin((F(1), sp(p[0], q[1])), (F(1), sp(p[1], q[0]))))
    def cadd(p, q, c=1): return (sp_add(p[0], q[0], c), sp_add(p[1], q[1], c))
    def cdet(H): return cadd(cmul(H[0][0], H[1][1]), cmul(H[0][1], H[1][0]), -1)
    H1, H2 = Hz(X1, X2), Hz(Y1, Y2); Hs = [[cadd(H1[i][j], H2[i][j]) for j in range(2)] for i in range(2)]
    d1 = cdet(H1); ds = cdet(Hs); want = lin((F(1), sp(lin((F(1), X1), (F(-1), Y1)), lin((F(1), X1), (F(-1), Y1)))), (F(1), sp(lin((F(1), X2), (F(-1), Y2)), lin((F(1), X2), (F(-1), Y2)))))
    chk('std', not d1[0] and not d1[1] and not ds[1] and scale(ds[0], F(1, 2)) == scale(want, F(1, 2)),
        'H(z) = [[|z|^2, conj z], [z, 1]]: det H(z) = 0 and (1/2) det(H(z) + H(w)) = (1/2)|z - w|^2 as polynomial identities (own code)')
    tP = P.get(EM, {}); ZP = P.get(EP, {})
    dict_ok = sp_add(tP, ZP) == lin((F(1), sp(X1, X1)), (F(1), sp(X2, X2))) and sp_add(tP, ZP, -1) == const(nv, 1) and P.get(E1) == X1 and P.get(E2) == X2
    chk('bit==std', dict_ok and sym_.get(0, {}) == scale(want, F(1, 2)), 'dictionary (t, X, Y, Z) = (e_m, e1, e2, e_p): t + Z = |z|^2, t - Z = 1, X + iY = z, so P(x) <-> H(z), and P(x).P(y) = (1/2) det(H(z) + H(w))')

    # ============================================================================== (2) rotors act by Mobius maps
    head('(2) the six generator rotors and a product: z -> (az + b)/(cz + d), ad - bc = 1, as an identity in z [bit]; textbook SL(2,C) [std]')
    nv = 2; X1, X2 = var(nv, 0), var(nv, 1); P = point(X1, X2, nv)
    GEN = [('rotation', 'e1e2', E1 | E2, 'z', F(3, 5), F(4, 5)), ('rotation', 'e2e_p', E2 | EP, 'x', F(3, 5), F(4, 5)), ('rotation', 'e_pe1', None, 'y', F(3, 5), F(4, 5)),
           ('boost', 'e_me1', None, 'x', F(5, 4), F(3, 4)), ('boost', 'e_me2', None, 'y', F(5, 4), F(3, 4)), ('boost', 'e_me_p', None, 'z', F(5, 4), F(3, 4))]
    def biv(word):                                              # the bivector of a two-letter word, with its sign from the bit rule
        a, b = {'e1e2': (E1, E2), 'e2e_p': (E2, EP), 'e_pe1': (EP, E1), 'e_me1': (EM, E1), 'e_me2': (EM, E2), 'e_me_p': (EM, EP)}[word]
        m, s = bmul(a, b, SQ); return {m: const(nv, s)}
    Z3 = [QI(0), QI(1), QI(0, 1)]
    PTS = [(F(rng.randint(-6, 6), rng.randint(1, 4)), F(rng.randint(-6, 6), rng.randint(1, 4))) for _ in range(20)]
    mats = {}
    def analyse(name, R, anti=False, sign=1, quiet=False):
        S = mv_mul(mv_mul(R, P), mv_rev(R))
        imgs = [image_z(ev_mv(S, (z.re, z.im))) for z in Z3]
        abcd, det = fit(list(zip(Z3, imgs)), anti)
        if abcd is None: return None, S, False, False
        okp = all(image_z(ev_mv(S, pt)) == mob(abcd, QI(*pt), anti) for pt in PTS)
        oki = mv_eq(S, poly_target(abcd, nv, anti, sign))
        return abcd, S, okp, oki
    for kind, word, _, axis, c, s in GEN:
        B = biv(word); R = mv_add(mv_const({0: c}, nv), mv_scale(B, s))
        RR = mv_mul(R, mv_rev(R)); Bsq = mv_mul(B, B)
        abcd, S, okp, oki = analyse(word, R)
        okn = abcd is not None and (abcd[0] * abcd[3] - abcd[1] * abcd[2]) == QI(1)
        chk('bit', mv_eq(RR, mv_const({0: 1}, nv)) and set(Bsq) == {0} and okn and okp and oki,
            '%s rotor %s + %s %s (B^2 = %s, R R~ = 1): (a, b, c, d) = (%s), ad - bc = 1; twenty more points; R P(x) R~ = |cz+d|^2 P(w) as an identity in z' % (kind, c, s, word, Bsq[0].get((0, 0)), ', '.join(map(repr, abcd)) if abcd else None))
        mats[word] = abcd
        # [std] textbook matrix, both senses; the Mobius matrix of z is conj(A)
        senses = []
        for sense in (1, -1):
            A = std_A(kind, axis, c, s, sense); Mz = m2conj(A)
            if abcd and all(x == y for x, y in zip(abcd, [Mz[0][0], Mz[0][1], Mz[1][0], Mz[1][1]])) or abcd and all(x == -y for x, y in zip(abcd, [Mz[0][0], Mz[0][1], Mz[1][0], Mz[1][1]])): senses.append(sense)
        A = std_A(kind, axis, c, s, senses[0] if senses else 1); An = np.array([[x.cx() for x in r] for r in A]); okd = m2det(A) == QI(1)
        Mz = np.conj(An); okm = True
        for pt in PTS:
            z = complex(float(pt[0]), float(pt[1])); Hn = An @ H_num(z) @ An.conj().T; w = (Mz[0, 0] * z + Mz[0, 1]) / (Mz[1, 0] * z + Mz[1, 1]); lam = abs(Mz[1, 0] * z + Mz[1, 1]) ** 2
            okm &= bool(np.allclose(Hn, lam * H_num(w), atol=1e-9))
        chk('std', okd and okm, '%s along/about %s: A = %s, det A = 1 (exact); A H(z) A^dagger = |cz+d|^2 H(w) with w = Mobius(conj A) at twenty points (numpy)' % (kind, axis, [[repr(x) for x in r] for r in A]))
        chk('bit==std', len(senses) == 1, '%s %s: bit (a, b, c, d) = +- conj(A) for the sense %s of the textbook parameter (one sense only)' % (kind, word, senses))
    # a product rotor
    Rb = mv_add(mv_const({0: F(5, 4)}, nv), mv_scale(biv('e_me1'), F(3, 4))); Rr = mv_add(mv_const({0: F(3, 5)}, nv), mv_scale(biv('e1e2'), F(4, 5))); R12 = mv_mul(Rb, Rr)
    abcd, S, okp, oki = analyse('product', R12); m1, m2 = mats['e_me1'], mats['e1e2']
    prod = [m1[0] * m2[0] + m1[1] * m2[2], m1[0] * m2[1] + m1[1] * m2[3], m1[2] * m2[0] + m1[3] * m2[2], m1[2] * m2[1] + m1[3] * m2[3]]
    same = abcd is not None and (all(x == y for x, y in zip(abcd, prod)) or all(x == -y for x, y in zip(abcd, prod)))
    chk('bit', same and okp and oki, 'the product rotor (boost e_me1)(rotation e1e2) gives +- the product of the two matrices (%s); twenty points; the identity in z' % ', '.join(map(repr, abcd or [])))
    # generated by inversions: each generator rotor is a product of two vectors of square -1
    okf = True
    for kind, word, _, axis, c, s in GEN:
        a_, b_ = {'e1e2': (E1, E2), 'e2e_p': (E2, EP), 'e_pe1': (EP, E1), 'e_me1': (EM, E1), 'e_me2': (EM, E2), 'e_me_p': (EM, EP)}[word]
        R = mv_add(mv_const({0: c}, nv), mv_scale(biv(word), s)); found = False
        for v1m in (a_, b_):
            if SQ[v1m.bit_length() - 1] != -1: continue
            v1 = mv_const({v1m: 1}, nv); v1i = mv_scale(v1, F(1, SQ[v1m.bit_length() - 1])); v2 = mv_mul(v1i, R)
            sq2 = mv_mul(v2, v2)
            if grades(v2) == [1] and set(sq2) <= {0} and sq2.get(0, {}) == const(nv, -1): found = True
        okf &= found
    chk('bit', okf, 'each of the six generator rotors is v1 v2 with v1^2 = v2^2 = -1: a product of two reflections in circles or lines (two inversions)')

    # ============================================================================== (3) reflections and the other components
    head('(3) reflections and inversions act as z -> (a conj z + b)/(c conj z + d); the even element e_m e_p acts on lines as the rotation by pi [bit]')
    cpt = (F(1, 2), F(1, 3)); r2 = F(4, 9); o2, eps2 = o_eps(nv)
    Sph = mv_add(point(const(nv, cpt[0]), const(nv, cpt[1]), nv), eps2, -r2 / 2)
    REFL = [('line x1 = 0 (e1)', mv_const({E1: 1}, nv)), ('unit circle (e_p)', mv_const({EP: 1}, nv)), ('circle centre (1/2, 1/3), r^2 = 4/9', Sph), ('time vector e_m (antipodal map)', mv_const({EM: 1}, nv))]
    for name, vv in REFL:
        vsq = mv_mul(vv, vv); s0 = vsq.get(0, {}).get((0, 0), F(0)); vinv = mv_scale(vv, 1 / s0)
        S = mv_scale(mv_mul(mv_mul(vv, P), vinv), -1)
        imgs = [image_z(ev_mv(S, (z.re, z.im))) for z in Z3]
        ab_m, _ = fit(list(zip(Z3, imgs)), False); ab_a, _ = fit(list(zip(Z3, imgs)), True)
        mob_ok = ab_m is not None and all(image_z(ev_mv(S, pt)) == mob(ab_m, QI(*pt), False) for pt in PTS)
        anti_ok = ab_a is not None and all(image_z(ev_mv(S, pt)) == mob(ab_a, QI(*pt), True) for pt in PTS)
        ident = ab_a is not None and (mv_eq(mv_scale(S, F(1)), poly_target(ab_a, nv, True)) or mv_eq(S, poly_target(ab_a, nv, True, -1)))
        chk('bit', anti_ok and ident, 'reflection in the %s (v^2 = %s): w = (a conj z + b)/(c conj z + d) with (%s), twenty points, and the identity in z (up to the sign of the scale)' % (name, s0, ', '.join(map(repr, ab_a or []))))
        chk('ctl', not mob_ok, 'reflection in the %s: the Mobius map through the images of 0, 1, i misses the other points (not in the identity component: not a Mobius map)' % name)
    V = mv_const({EM | EP: 1}, nv); m_, s_ = bmul(EM, EP, SQ); V = mv_const({EM | EP: s_}, nv)
    VV = mv_mul(V, mv_rev(V)); S = mv_mul(mv_mul(V, P), mv_rev(V))
    imgs = [image_z(ev_mv(S, (z.re, z.im))) for z in Z3]; abV, _ = fit(list(zip(Z3, imgs)), False)
    okV = abV is not None and all(image_z(ev_mv(S, pt)) == mob(abV, QI(*pt)) for pt in PTS)
    Rpi = mv_const({E1 | E2: bmul(E1, E2, SQ)[1]}, nv); Spi = mv_mul(mv_mul(Rpi, P), mv_rev(Rpi))
    abpi, _ = fit(list(zip(Z3, [image_z(ev_mv(Spi, (z.re, z.im))) for z in Z3])), False)
    samepi = abV is not None and abpi is not None and all(mob(abV, QI(*pt)) == mob(abpi, QI(*pt)) for pt in PTS)
    chk('bit', VV == mv_const({0: -1}, nv) and okV and samepi, 'V = e_m e_p: V V~ = -1 (determinant +1, reverses time); on null lines it is the Mobius map (%s), z -> -z, the same as the rotation by pi in e1e2' % ', '.join(map(repr, abV or [])))
    Vinv = mv_scale(mv_rev(V), -1); t_img = ev_mv(mv_mul(mv_mul(V, P), Vinv), (F(0), F(0)))
    chk('bit', mv_eq(mv_mul(V, Vinv), mv_const({0: 1}, nv)) and t_img.get(EM, 0) < 0, 'on future null RAYS the Lorentz map X -> V X V^-1 of V = e_m e_p is not a map of the set: the future vector P(0) = o goes to time component %s < 0' % t_img.get(EM, 0))
    # controls on the normalisation and on the versor property
    nv4 = 4; X1b, X2b, Y1b, Y2b = (var(nv4, i) for i in range(4)); Pb, Qb = point(X1b, X2b, nv4), point(Y1b, Y2b, nv4)
    Bz = {EM | EP: const(nv4, bmul(EM, EP, SQ)[1])}; Rbad = mv_add(mv_const({0: F(5, 4)}, nv4), mv_scale(Bz, F(1, 2)))
    k = mv_mul(Rbad, mv_rev(Rbad)).get(0, {}).get((0,) * nv4, 0)
    SPb, SQb = mv_mul(mv_mul(Rbad, Pb), mv_rev(Rbad)), mv_mul(mv_mul(Rbad, Qb), mv_rev(Rbad))
    ip = mv_scale(mv_add(mv_mul(SPb, SQb), mv_mul(SQb, SPb)), F(1, 2)); ip0 = mv_scale(mv_add(mv_mul(Pb, Qb), mv_mul(Qb, Pb)), F(1, 2))
    chk('ctl', not mv_eq(ip, ip0), 'boost with (a, b) = (5/4, 1/2), a^2 - b^2 = %s != 1: P(x).P(y) is not kept (it is multiplied by %s)' % (k, k * k))
    chk('bit', not mv_mul(SPb, SPb) and mv_eq(ip, mv_scale(ip0, k * k)), 'the same element keeps the cone: (R P R~)^2 = 0 as an identity, and the inner products scale by (a^2 - b^2)^2 = %s (the point map is the Mobius map of the normalised rotor)' % (k * k))
    Rnv = mv_add(mv_add(mv_const({0: 1}, nv4), mv_const({E1 | E2: 1}, nv4)), mv_const({EM | EP: 1}, nv4)); Snv = mv_mul(mv_mul(Rnv, Pb), mv_rev(Rnv))
    RRn = mv_mul(Rnv, mv_rev(Rnv))
    Pn = point(X1, X2, nv); Rn2 = mv_add(mv_add(mv_const({0: 1}, nv), mv_const({E1 | E2: 1}, nv)), mv_const({EM | EP: 1}, nv)); Sn2 = mv_mul(mv_mul(Rn2, Pn), mv_rev(Rn2))
    abn, detn = fit(list(zip(Z3, [image_z(ev_mv(Sn2, (z.re, z.im))) for z in Z3])), False, normalise=False)
    okn2 = abn is not None and all(image_z(ev_mv(Sn2, pt)) == mob(abn, QI(*pt)) for pt in PTS)
    chk('bit', grades(Snv) == [1] and not mv_mul(Snv, Snv) and sorted({popc(m) for m in RRn}) == [0, 4] and okn2,
        'the even element psi = 1 + e1e2 + e_me_p (psi psi~ has grades 0 and 4: not a rotor times a scalar) still maps P(x) to null vectors (identity in x) and acts on z by a Mobius map (projective (a, b, c, d) = (%s), ad - bc = %s, twenty points): psi acts on vectors as a scaled Lorentz map' % (', '.join(map(repr, abn or [])), detn))
    Rodd = mv_add(mv_const({0: 1}, nv4), mv_const({E1: 1}, nv4)); Sodd = mv_mul(mv_mul(Rodd, Pb), mv_rev(Rodd))
    chk('ctl', grades(Sodd) != [1], 'the element 1 + e1 (scalar plus vector, not of one parity) does not map P(x) to a vector: the image has grades %s' % grades(Sodd))

    # ============================================================================== (4) stabilisers
    head('(4) stabilisers in the engine\'s Lie table of Cl(1,3): the null vector (dimension 3, iso(2)) and the null ray, a point of the sphere (dimension 4) [bit]; sl(2,C) [std]')
    L = Lie(SQ); G = L.G
    def act(A, nvec):                                          # (1/2)[B_A, n] from the h table
        out = [F(0)] * 4
        for (A_, b), (c, h) in L.h.items():
            if A_ == A: out[c] += h * nvec[b]
        return out
    def act_bit(A, nvec):                                      # (1/2)(B_A n - n B_A) by the bit rule
        Bm = {L.gens[A]: F(1)}; nm = {1 << b: F(nvec[b]) for b in range(4) if nvec[b]}
        def mul(X, Y):
            r = {}
            for a, x in X.items():
                for b, y in Y.items():
                    m, s = bmul(a, b, SQ); r[m] = r.get(m, 0) + s * x * y
            return r
        c1, c2 = mul(Bm, nm), mul(nm, Bm); out = [F(0)] * 4
        for m in set(c1) | set(c2):
            val = (c1.get(m, 0) - c2.get(m, 0)) / 2
            if val: out[m.bit_length() - 1] += val if popc(m) == 1 else 0
        return out
    h_ok = all(act(A, [F(int(i == b)) for i in range(4)]) == act_bit(A, [F(int(i == b)) for i in range(4)]) for A in range(G) for b in range(4))
    chk('bit', h_ok, 'the h table of the engine (1/2)[B_A, gamma_b] = h gamma_c equals the bit-rule commutator for all %d generators and 4 vectors' % G)
    def brk(u, w):                                             # [sum u_A B_A, sum w_B B_B] with the f table
        out = [F(0)] * G
        for (A, B), (C, f) in L.f.items(): out[C] += f * u[A] * w[B]
        return out
    def brk_bit(u, w):
        def mvb(x): return {L.gens[A]: x[A] for A in range(G) if x[A]}
        def mul(X, Y):
            r = {}
            for a, x in X.items():
                for b, y in Y.items():
                    m, s = bmul(a, b, SQ); r[m] = r.get(m, 0) + s * x * y
            return r
        X, Y = mvb(u), mvb(w); c1, c2 = mul(X, Y), mul(Y, X); out = [F(0)] * G
        for m in set(c1) | set(c2):
            val = c1.get(m, 0) - c2.get(m, 0)
            if val: out[L.idx[m]] += val
        return out
    def kernel(rows, ncol):
        """basis of the null space (exact) of a list of rows"""
        M = [r[:] for r in rows]; piv = []; r = 0
        for c in range(ncol):
            p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
            if p is None: continue
            M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
            for i in range(len(M)):
                if i != r and M[i][c] != 0: f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
            piv.append(c); r += 1
        out = []
        for fc in [c for c in range(ncol) if c not in piv]:
            vec = [F(0)] * ncol; vec[fc] = F(1)
            for i, c in enumerate(piv): vec[c] = -M[i][fc]
            out.append(vec)
        return out
    x0 = (F(2, 3), F(-1, 2)); Px0 = ev_mv(point(const(2, x0[0]), const(2, x0[1]), 2), (0, 0))
    NULLS = [('eps (the point at infinity)', [F(0), F(0), F(1), F(1)]), ('o (z = 0)', [F(0), F(0), F(-1, 2), F(1, 2)]), ('P(2/3, -1/2)', [Px0.get(1 << i, F(0)) for i in range(4)])]
    std_dims = []
    for name, nvec in NULLS:
        nsq = sum(SQ[i] * nvec[i] ** 2 for i in range(4))
        cols = [act(A, nvec) for A in range(G)]
        rows_v = [[cols[A][c] for A in range(G)] for c in range(4)]
        rows_r = [[cols[A][c] for A in range(G)] + [-nvec[c]] for c in range(4)]
        Kv = kernel(rows_v, G); Kr = kernel(rows_r, G + 1); Kr_b = [k_[:G] for k_ in Kr]
        def in_span(basis, w):
            return rank_exact(basis + [w]) == rank_exact(basis) if basis else not any(w)
        closed_v = all(in_span(Kv, brk(u, w)) for u in Kv for w in Kv); closed_r = all(in_span(Kr_b, brk(u, w)) for u in Kr_b for w in Kr_b)
        f_ok = all(brk(u, w) == brk_bit(u, w) for u in Kr_b for w in Kr_b)
        der_v = [brk(u, w) for u in Kv for w in Kv]; dv = rank_exact(der_v) if any(any(x) for x in der_v) else 0
        abel = all(not any(brk(u, w)) for u in der_v for w in der_v)
        contains = all(in_span(Kr_b, u) for u in Kv)
        extra = [k_ for k_ in Kr if k_[G] != 0]
        chk('bit', nsq == 0 and len(Kv) == 3 and closed_v and dv == 2 and abel, 'n = %s (null): {B : B.n = 0} has dimension %d, is a subalgebra, its derived algebra has dimension %d and is abelian: iso(2), the little group of the null vector' % (name, len(Kv), dv))
        chk('bit', len(Kr_b) == 4 and closed_r and contains and len(extra) >= 1 and f_ok, 'n = %s: {B : B.n parallel to n} (the stabiliser of the point of the sphere) has dimension %d, is a subalgebra containing the little group, plus one element with B.n = mu n, mu != 0; f brackets = bit-rule commutators' % (name, len(Kr_b)))
        # [std] sl(2,C) as a real 6-dimensional algebra; the point xi of the null vector H = xi xi^dagger
        if nvec[3] - nvec[2] == 0: xi = np.array([1, 0], dtype=complex)
        else:
            zz = complex(float(nvec[0] / (nvec[3] - nvec[2])), float(nvec[1] / (nvec[3] - nvec[2]))); xi = np.array([np.conj(zz), 1], dtype=complex) * math.sqrt(float(nvec[3] - nvec[2]))
        Hn = np.outer(xi, xi.conj()); basis = [s_ * np.array(m, dtype=complex) for m in ([[0, 1], [1, 0]], [[0, -1j], [1j, 0]], [[1, 0], [0, -1]]) for s_ in (1, 1j)]
        basis = [np.array(b, dtype=complex) for b in basis]
        cols_s = [(Xb @ Hn + Hn @ Xb.conj().T) for Xb in basis]
        Mv = np.array([[c_[i, j].real for c_ in cols_s] for i in range(2) for j in range(2)] + [[c_[i, j].imag for c_ in cols_s] for i in range(2) for j in range(2)])
        Mr = np.hstack([Mv, -np.array([[Hn[i, j].real for i in range(2) for j in range(2)] + [Hn[i, j].imag for i in range(2) for j in range(2)]]).T])
        dv_s = 6 - np.linalg.matrix_rank(Mv, tol=1e-9); dr_s = 7 - np.linalg.matrix_rank(Mr, tol=1e-9); std_dims.append((dv_s, dr_s))
        chk('std', dv_s == 3 and dr_s == 4, 'n = %s: in sl(2,C) (real dimension 6) X H + H X^dagger = 0 has dimension %d and X H + H X^dagger parallel to H has dimension %d (numpy ranks)' % (name, dv_s, dr_s))
        chk('bit==std', (len(Kv), len(Kr_b)) == (dv_s, dr_s), 'n = %s: the dimensions (3, 4) agree' % name)
    print('\n  reading: the stabiliser of a point of the sphere (a null line) is four-dimensional (the similarity maps z -> a z + b of the plane: rotation, two translations, the boost along the line);'
          '\n  the little group of item 10 (bd.phy.5) is the stabiliser of the null VECTOR, of dimension 3 (|a| = 1). The sentence "its point stabilisers are the little groups" holds for the vector, not for the point.')

if __name__ == '__main__':
    main(); finish('GM-SPHERE')
