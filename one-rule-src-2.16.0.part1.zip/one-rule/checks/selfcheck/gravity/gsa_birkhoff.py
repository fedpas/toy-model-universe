#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSA-BIRKHOFF.  The Einstein form on the general spherically symmetric chart A(t,r) dt^2 - B(t,r) dr^2 - r^2 dOmega^2 and its reduction to ODEs.
    python3 gsa_birkhoff.py [--fault time_mass|no_product|wrong_c|rn|closed_coef]

 Chart (an input): areal radius r, a time t orthogonal to it, A = alpha^2, B = beta^2, signature (+,-,-,-).  Coframe in the Cartesian slots (t, x, y, z):
   e^0 = alpha(t, r) dt,   e^i = dx^i + (beta(t, r) - 1) xhat^i (xhat . dx),   r = |x|,
 alpha and beta given by arbitrary exact 2-jets in (t, r) at a rational point p with rational |p| (r - r0 and xhat as exact 2-jets in delta = x - p).
 Claim.  The engine's E_a(c) = -(G - 3c delta)^h_a Theta_h gives, with Phi = ln alpha, Lam = ln beta (' = d_r, dot = d_t),
     G^t_t = (1 - e^(-2 Lam)(1 - 2 r Lam'))/r^2 = (r (1 - 1/B))'/r^2,      G^r_r = (1 - e^(-2 Lam)(1 + 2 r Phi'))/r^2,
     G^t_r = (2/r) e^(-2 Phi) Lam_dot,   G^r_t = -(2/r) e^(-2 Lam) Lam_dot,
     G^th_th = -e^(-2 Lam) (Phi'' + Phi'^2 - Phi' Lam' + (Phi' - Lam')/r) + e^(-2 Phi) (Lam_ddot + Lam_dot^2 - Phi_dot Lam_dot)
   (the textbook components, recalled, here in the signature (+,-,-,-), where the mixed components change sign).  So E_a(c) = 0 at every point gives
   beta_t = 0 (B static), (r (1 - 1/B))' = 3c r^2, i.e. 1/B = 1 - 2M/r - c r^2, and G^t_t - G^r_r = 2 (alpha beta)_r/(r alpha beta^3) = 0, i.e. A B = h(t)^2,
   h absorbed by the time chart: Schwarzschild-(anti-)de Sitter with c = Lambda/3.  Local uniqueness in general (Birkhoff's theorem) is recalled.
 [bit]  the engine (Forms, Lie, Grav; omega from the A3 closed form; E_a(c)) on the exact 2-jets; frame components carried to the coordinates.
 [std]  Christoffel route on g = e^T eta e (two Riemann routes on part of the samples) and the closed form above.
 Parts  1 closed form on random jets; 2 what each component reads; 3 the three reductions solved from the engine's own components at the points;
        4 the solutions alpha = h(t) sqrt(F), beta = 1/sqrt(F), F = 1 - 2M/r - c r^2, at points where F is a rational square (F > 0: outside the horizon);
        5 controls.
 Controls (each also a --fault NAME that puts the wrong version into part 4 or part 1 and exits 1): time_mass (B with M(1 + t/7)), no_product (alpha (1 + r/50)),
        wrong_c (E_a(c + 1/10)), rn (the Reissner-Nordstrom profile 1 - 2M/r + 2s/r^2, a source), closed_coef (2 r Lam' -> r Lam' in G^t_t).
 Scope  values at rational points, n = 4, exact 2-jets of the frame; no statement inside a horizon (the chart with real alpha, beta does not exist there)."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'time_mass', 'no_product', 'wrong_c', 'rn', 'closed_coef'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
NV = 4; SQ = LORENTZ(4)
DIRS = [(1, 2, 2, 3), (2, 3, 6, 7), (2, 6, 9, 11), (1, 4, 8, 9), (4, 4, 7, 9), (6, 6, 7, 11), (-2, 3, 6, 7)]

# ------------------------------------------------------------------------------------------------ jets
def radial_jets(p, r0):
    """delta r = |x| - r0 and xhat = x/|x| as exact 2-jets in delta = x - p (slot 0 = t unused)"""
    X = [None] + [var(NV, i) for i in (1, 2, 3)]
    d2 = lin(*[(F(1), sp_mul(X[i], X[i], 2, 4)) for i in (1, 2, 3)])
    u = lin((F(2) / r0 ** 2, lin(*[(p[i - 1], X[i]) for i in (1, 2, 3)])), (F(1) / r0 ** 2, d2)); u2 = sp_mul(u, u, 2, 4)
    inv_r = lin((1 / r0, const(NV, 1)), (-1 / (2 * r0), u), (F(3, 8) / r0, u2))
    dr = lin((r0 / 2, u), (-r0 / 8, u2))
    nh = [sp_mul(lin((F(1), const(NV, p[i])), (F(1), X[i + 1])), inv_r, 2, 4) for i in range(3)]
    return dr, nh
def jet_tr(j, dr):
    """j = (v, v_t, v_r, v_tt, v_tr, v_rr): the 2-jet v + v_t dt + v_r dr + (v_tt dt^2 + 2 v_tr dt dr + v_rr dr^2)/2 in the slots"""
    T = var(NV, 0); v, vt, vr, vtt, vtr, vrr = j
    return lin((v, const(NV, 1)), (vt, T), (vr, dr), (vtt / 2, sp_mul(T, T, 2, 4)), (vtr, sp_mul(T, dr, 2, 4)), (vrr / 2, sp_mul(dr, dr, 2, 4)))
def frame(p, r0, ja, jb):
    dr, nh = radial_jets(p, r0); al = jet_tr(ja, dr); bm1 = padd(jet_tr(jb, dr), const(NV, 1), -1)
    e = [{1: al}]
    for i in range(3):
        form = {}
        for j in range(3):
            pol = padd(const(NV, 1) if i == j else {}, sp_mul(sp_mul(bm1, nh[i], 2, 4), nh[j], 2, 4))
            if pol: form[1 << (j + 1)] = pol
        e.append(form)
    return e
def point(k, r0):
    a, b, c, d = DIRS[k % len(DIRS)]; return tuple(F(r0) * F(x, d) for x in (a, b, c))

# ------------------------------------------------------------------------------------------------ the two routes and the closed form
TF = []
def engine_M(Gv, S, e, c, torsion=False):
    """[bit] M^mu_nu = (G - 3c delta)^mu_nu in (t, x, y, z) from the engine's E_a(c) (frame components carried to the coordinates);
    torsion=True also records whether T^a = de^a + h omega e vanishes at the point (the engine's h table)"""
    e0, E0, det = E0_of(e, 4, NV); om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, c)
    if torsion:
        with trunc(4, xdeg=0): TF.append(torsion_zero_at0(Gv, om, e, NV))
    Mf = mixed_from_components(comp, e0, det, 4, s=-1)
    return [[sum(E0[m][b] * Mf[b][a] * e0[a][n] for b in range(4) for a in range(4)) for n in range(4)] for m in range(4)], comp
def std_G(e, both=False):
    """[std] mixed Einstein tensor of g = e^T eta e in (t, x, y, z), Christoffel route (both=True: the second-derivative route must agree)"""
    g = std_metric(e, 4, SQ, NV, 2); R1, g0, g0i = std_riemann(g, 4, NV, 1); Gm, _, _ = std_einstein_mixed(R1, g0, g0i, 4)
    if both:
        R2, _, _ = std_riemann(g, 4, NV, 2); assert std_einstein_mixed(R2, g0, g0i, 4)[0] == Gm
    return Gm
def closed_parts(r0, ja, jb, coef=2):
    """the textbook components (G^t_t, G^r_r, G^t_r, G^r_t, G^th_th) in (+,-,-,-) from the jets at the point"""
    r = F(r0); a, at, ar, att, atr, arr = ja; b, bt, br, btt, btr, brr = jb
    Pp, Pt = ar / a, at / a; Ppp = arr / a - Pp ** 2; Lp, Lt = br / b, bt / b; Ltt = btt / b - Lt ** 2
    Gtt = (1 - (1 - coef * r * Lp) / b ** 2) / r ** 2; Grr = (1 - (1 + 2 * r * Pp) / b ** 2) / r ** 2
    Gtr = 2 * Lt / (r * a ** 2); Grt = -2 * Lt / (r * b ** 2)
    Gth = -(Ppp + Pp ** 2 - Pp * Lp + (Pp - Lp) / r) / b ** 2 + (Ltt + Lt ** 2 - Pt * Lt) / a ** 2
    return Gtt, Grr, Gtr, Grt, Gth
def closed_cart(p, r0, ja, jb, coef=2):
    Gtt, Grr, Gtr, Grt, Gth = closed_parts(r0, ja, jb, coef); xh = [x / F(r0) for x in p]; G = [[F(0)] * 4 for _ in range(4)]
    G[0][0] = Gtt
    for i in range(3):
        G[0][1 + i] = Gtr * xh[i]; G[1 + i][0] = Grt * xh[i]
        for j in range(3): G[1 + i][1 + j] = Grr * xh[i] * xh[j] + Gth * ((1 if i == j else 0) - xh[i] * xh[j])
    return G
def sub_c(M, c): return [[M[i][j] + (3 * c if i == j else 0) for j in range(4)] for i in range(4)]
def read_parts(G, p, r0):
    """(G^t_t, G^r_r, G^t_r, G^r_t, G^th_th) read off a coordinate tensor at p"""
    xh = [x / F(r0) for x in p]; v = (xh[1], -xh[0], F(0)) if (xh[0] or xh[1]) else (F(0), xh[2], -xh[1]); vv = sum(x * x for x in v)
    Grr = sum(xh[i] * G[1 + i][1 + j] * xh[j] for i in range(3) for j in range(3))
    Gth = sum(v[i] * G[1 + i][1 + j] * v[j] for i in range(3) for j in range(3)) / vv
    return G[0][0], Grr, sum(G[0][1 + i] * xh[i] for i in range(3)), sum(G[1 + i][0] * xh[i] for i in range(3)), Gth

# ------------------------------------------------------------------------------------------------ the solutions
def sol_jets(r0, q, c, h, M=None, mdot=F(0), extra=None):
    """jets of alpha = h(t) sqrt(F), beta = 1/sqrt(F), F = 1 - 2M(t)/r - c r^2 with F(r0) = q^2 (M from q unless given), M(t) = M (1 + mdot t);
    extra = (k2, s): F gains 2 s/r^2 (the Reissner-Nordstrom profile, M from q).  h = (h0, h1, h2) the 2-jet of h(t)."""
    r = F(r0); s = F(0) if extra is None else extra
    if M is None: M = r * (1 - q * q - c * r * r) / 2 + s / r
    F0 = 1 - 2 * M / r - c * r * r + 2 * s / r ** 2; assert F0 == q * q, (F0, q)
    F1 = 2 * M / r ** 2 - 2 * c * r - 4 * s / r ** 3; F2 = -4 * M / r ** 3 - 2 * c + 12 * s / r ** 4
    Ft = -2 * M * mdot / r; Ftr = 2 * M * mdot / r ** 2                                  # d_t F and d_t d_r F (M linear in t: d_tt F = 0)
    h0, h1, h2 = h
    sq = (q, Ft / (2 * q), F1 / (2 * q), -Ft ** 2 / (4 * q ** 3), Ftr / (2 * q) - Ft * F1 / (4 * q ** 3), F2 / (2 * q) - F1 ** 2 / (4 * q ** 3))   # sqrt(F)
    isq = (1 / q, -Ft / (2 * q ** 3), -F1 / (2 * q ** 3), 3 * Ft ** 2 / (4 * q ** 5), -Ftr / (2 * q ** 3) + 3 * Ft * F1 / (4 * q ** 5), 3 * F1 ** 2 / (4 * q ** 5) - F2 / (2 * q ** 3))
    s0, st, sr, stt, s_tr, srr = sq
    ja = (h0 * s0, h1 * s0 + h0 * st, h0 * sr, h2 * s0 + 2 * h1 * st + h0 * stt, h1 * sr + h0 * s_tr, h0 * srr)   # product rule for the 2-jet of h(t) sqrt(F)
    return ja, isq, M

def main():
    head('GSA-BIRKHOFF: the general spherically symmetric chart A(t,r) dt^2 - B(t,r) dr^2 - r^2 dOmega^2 on the engine' + (' [fault %s]' % FAULT if FAULT else ''))
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
    rng = random.Random(1010)
    rq = lambda: F(rng.choice([-6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6]), rng.randint(1, 5))
    rpos = lambda: F(rng.randint(3, 12), rng.randint(2, 6))
    def rjet(): return (rpos(),) + tuple(rq() for _ in range(5))
    # ================================================================================== 1
    head('1. the engine\'s mixed Einstein tensor on random 2-jets of (alpha, beta) in (t, r) = the Christoffel route = the closed form (all 16 components)')
    from d_probe import d_sign_probe; d_sign_probe()
    ok_b = ok_s = ok_bs = True; n1 = 0; nzc = set(); ok_cc = True
    for k in range(6):
        r0 = F(rng.randint(2, 9)) + F(rng.randint(0, 3), 4); p = point(k, r0)
        for m in range(3):
            ja, jb = rjet(), rjet(); e = frame(p, r0, ja, jb)
            cf = closed_cart(p, r0, ja, jb, coef=1 if FAULT == 'closed_coef' else 2)
            Mb, _ = engine_M(Gv, S, e, F(0), torsion=True); Gs = std_G(e, both=(m == 0)); n1 += 1
            ok_b &= (Mb == cf); ok_s &= (Gs == cf); ok_bs &= (Mb == Gs); nzc |= {(i, j) for i in range(4) for j in range(4) if cf[i][j] != 0}
            if m == 1:
                c = F(-2, 7); Mc, _ = engine_M(Gv, S, e, c); ok_cc &= (sub_c(Mc, c) == Gs)
    chk('bit==std', ok_b and ok_s and ok_bs, 'engine (omega from A3, E_a, frame -> coordinates) = Christoffel route (two Riemann routes on 6 samples) = the closed form, all 16 components, %d random jets at 6 points' % n1)
    chk('bit', len(TF) == n1 and all(TF), 'the A3 closed-form omega is torsion-free at the %d sample points: T^a = de^a + h_Ab^a omega^A ^ e^b = 0 with the engine\'s h table (the Einstein form is that of the Levi-Civita connection)' % len(TF))
    chk('bit', len(nzc) == 16 and ok_cc, 'each of the 16 components is non-zero on some sample (the comparison is not 0 = 0) and E_a(c) at c = -2/7 is G - 3c delta with the same G (6 samples)')
    tick('part 1')
    # ================================================================================== 2
    head('2. what each component reads: G^r_t from (beta, beta_t), G^t_t from (beta, beta_r), G^t_t - G^r_r from (alpha beta)_r (engine, other jet entries varied)')
    ok_rt = ok_tt = ok_dif = ok_zero = True; n2 = 0
    for k in range(4):
        r0 = F(rng.randint(3, 8)); p = point(k + 1, r0); ja, jb = rjet(), rjet()
        base = read_parts(engine_M(Gv, S, frame(p, r0, ja, jb), F(0))[0], p, r0)
        ja2 = (ja[0], rq(), rq(), rq(), rq(), rq()); jb2 = (jb[0], jb[1], jb[2], rq(), rq(), rq())     # all but (alpha, beta, beta_t, beta_r) changed
        oth = read_parts(engine_M(Gv, S, frame(p, r0, ja2, jb2), F(0))[0], p, r0); n2 += 2
        ok_rt &= (base[3] == oth[3] == -2 * jb[1] / (r0 * jb[0] ** 3)) and base[2] == 2 * jb[1] / (r0 * jb[0] * ja[0] ** 2)
        ok_tt &= (base[0] == oth[0] == (1 - (1 - 2 * r0 * jb[2] / jb[0]) / jb[0] ** 2) / r0 ** 2)
        ok_dif &= (base[0] - base[1] == 2 * (ja[2] * jb[0] + ja[0] * jb[2]) / (r0 * ja[0] * jb[0] ** 3))
        jbs = (jb[0], F(0), jb[2], jb[3], jb[4], jb[5]); Ms = engine_M(Gv, S, frame(p, r0, ja, jbs), F(0))[0]; n2 += 1
        ok_zero &= all(Ms[0][1 + i] == 0 and Ms[1 + i][0] == 0 for i in range(3))
    chk('bit', ok_rt, 'G^r_t = -2 beta_t/(r beta^3) and G^t_r = 2 beta_t/(r beta alpha^2) exactly, unchanged when alpha, alpha_t, alpha_r and every second derivative are changed (4 points, %d engine runs)' % n2)
    chk('bit', ok_zero, 'beta_t = 0 with every other entry random: the four (t, x^i) and (x^i, t) components are 0 exactly: vacuum at every point forces d_t B = 0')
    chk('bit', ok_tt, 'G^t_t = (1 - (1 - 2 r beta_r/beta)/beta^2)/r^2 = (r (1 - 1/B))\'/r^2 depends on (beta, beta_r) only: a first-order ODE for B alone')
    chk('bit', ok_dif, 'G^t_t - G^r_r = 2 (alpha beta)_r/(r alpha beta^3) exactly: G^t_t = G^r_r forces (alpha beta)_r = 0, A B = h(t)^2')
    tick('part 2')
    # ================================================================================== 3
    head('3. the vacuum equations solved from the engine\'s own components at the points: unknowns beta_t, beta_r, alpha_r given (alpha, beta) and the rest')
    ok3 = True; n3 = 0
    for k, (r0, q, c) in enumerate([(F(3), F(1, 2), F(0)), (F(5), F(3, 5), F(1, 50)), (F(7, 2), F(2, 3), F(-1, 40)), (F(9, 4), F(1, 3), F(1, 30))]):
        p = point(k + 2, r0); a0 = rpos(); b0 = 1 / q; rest_a = [rq() for _ in range(4)]; rest_b = [rq() for _ in range(3)]
        def M_of(bt, br, ar):
            ja = (a0, rest_a[0], ar, rest_a[1], rest_a[2], rest_a[3]); jb = (b0, bt, br, rest_b[0], rest_b[1], rest_b[2])
            return read_parts(engine_M(Gv, S, frame(p, r0, ja, jb), c)[0], p, r0)
        P00 = M_of(F(0), F(0), F(0)); P1 = M_of(F(1), F(0), F(0)); P2 = M_of(F(0), F(1), F(0)); P3 = M_of(F(0), F(1), F(1)); n3 += 4
        bt = -P00[3] / (P1[3] - P00[3])                                   # G^r_t affine in beta_t: its zero
        br = -P00[0] / (P2[0] - P00[0])                                   # G^t_t - 3c affine in beta_r (G^t_t reads beta, beta_r only)
        sl = P3[1] - P2[1]; ar = -P2[1] / sl if sl else None                 # G^r_r - 3c affine in alpha_r (it does not read beta_r: P2[1] = P00[1])
        ok3 &= (P2[1] == P00[1])
        M = r0 * (1 - q * q - c * r0 * r0) / 2; F1 = 2 * M / r0 ** 2 - 2 * c * r0
        ok3 &= (bt == 0 and br == -F1 / (2 * q ** 3) and ar == -a0 * br / b0)
    chk('bit', ok3, 'solved from the engine at 4 points ((r, 1/beta^2, c) = (3, 1/4, 0), (5, 9/25, 1/50), (7/2, 4/9, -1/40), (9/4, 1/9, 1/30)): beta_t = 0, beta_r = the ODE value -F\'/(2 F^(3/2)) of 1/B = F = 1 - 2M/r - c r^2 through the point (M fixed by beta), alpha_r = -alpha beta_r/beta ((alpha beta)_r = 0), %d engine runs' % n3)
    tick('part 3')
    # ================================================================================== 4
    head('4. the solutions alpha = h(t) sqrt(F), beta = 1/sqrt(F), F = 1 - 2M/r - c r^2 (rational square at the point, F > 0): E_a(c) = 0 on all 16 components')
    SOLS = [(F(3), F(1, 2), F(0)), (F(8, 3), F(1, 2), F(0)), (F(25, 8), F(3, 5), F(0)), (F(5), F(3, 5), F(1, 50)), (F(4), F(1, 2), F(1, 40)), (F(7, 2), F(2, 3), F(-1, 40)), (F(6), F(4, 5), F(-1, 100))]
    ok4 = True; Ms = []; n4 = 0
    for k, (r0, q, c) in enumerate(SOLS):
        p = point(k, r0); h = (F(1) + F(k, 7), F(1, 3) - F(k, 11), F(-2, 7) + F(k, 13))
        if FAULT == 'time_mass': ja, jb, M = sol_jets(r0, q, c, h, mdot=F(1, 7))
        elif FAULT == 'rn': ja, jb, M = sol_jets(r0, q, c, h, extra=F(1, 3))
        else: ja, jb, M = sol_jets(r0, q, c, h)
        if FAULT == 'no_product': ja = (ja[0] * (1 + r0 / 50), ja[1] * (1 + r0 / 50), ja[2] * (1 + r0 / 50) + ja[0] / 50, ja[3] * (1 + r0 / 50), ja[4] * (1 + r0 / 50) + ja[1] / 50, ja[5] * (1 + r0 / 50) + 2 * ja[2] / 50)
        cc = c + F(1, 10) if FAULT == 'wrong_c' else c
        Mx, comp = engine_M(Gv, S, frame(p, r0, ja, jb), cc); n4 += 1
        ok4 &= all(v == 0 for v in comp.values()); Ms.append(M)
    chk('bit', ok4, 'E_a(c) = 0, all 16 components, at %d points: (r, F(r), c) = %s, M = %s, h(t) with h\' != 0 at every point (the time dependence of A alone is the time chart)' % (
        n4, ', '.join('(%s, %s, %s)' % (r0, q * q, c) for r0, q, c in SOLS), ', '.join(str(M) for M in Ms)))
    tick('part 4')
    # ================================================================================== 5
    head('5. controls: a wrong version must fail')
    cnt = {}
    def ctl(name, wrong):
        x = cnt.setdefault(name, [0, 0]); x[1] += 1; x[0] += int(bool(wrong))
    for k, (r0, q, c) in enumerate(SOLS[:5]):
        p = point(k, r0); h = (F(1), F(1, 3), F(-2, 7))
        ja, jb, M = sol_jets(r0, q, c, h, mdot=F(1, 7)); Mx, comp = engine_M(Gv, S, frame(p, r0, ja, jb), c); P = read_parts(Mx, p, r0)
        ctl('B with a time-dependent mass M(1 + t/7) (each slice Schwarzschild-(A)dS): G^r_t != 0', P[3] != 0 and any(v != 0 for v in comp.values()))
        ja, jb, M = sol_jets(r0, q, c, h); jx = (ja[0] * (1 + r0 / 50), ja[1] * (1 + r0 / 50), ja[2] * (1 + r0 / 50) + ja[0] / 50, ja[3] * (1 + r0 / 50), ja[4] * (1 + r0 / 50) + ja[1] / 50, ja[5] * (1 + r0 / 50) + 2 * ja[2] / 50)
        Mx, comp = engine_M(Gv, S, frame(p, r0, jx, jb), c); P = read_parts(Mx, p, r0)
        ctl('alpha beta = h(t)(1 + r/50), not h(t): G^t_t != G^r_r', P[0] != P[1])
        Mx, comp = engine_M(Gv, S, frame(p, r0, ja, jb), c + F(1, 10)); ctl('the solution with a wrong c (c + 1/10): E_a != 0', any(v != 0 for v in comp.values()))
        ja, jb, M = sol_jets(r0, q, c, h, extra=F(1, 3)); Mx, comp = engine_M(Gv, S, frame(p, r0, ja, jb), c)
        ctl('the Reissner-Nordstrom profile F + 2s/r^2 (s = 1/3, a Maxwell source): E_a != 0', any(v != 0 for v in comp.values()))
        jr, js = rjet(), rjet(); Mq, _ = engine_M(Gv, S, frame(p, r0, jr, js), F(0))
        ctl('the closed form with r Lam\' in place of 2 r Lam\' in G^t_t differs from the engine', Mq != closed_cart(p, r0, jr, js, coef=1))
    for name, (dif, seen) in cnt.items(): chk('ctl', dif == seen and seen > 0, '%s: the wrong version fails on %d of %d samples' % (name, dif, seen))
    tick('part 5')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GSA-BIRKHOFF' + ('-' + FAULT if FAULT else ''))

if __name__ == '__main__': main()
