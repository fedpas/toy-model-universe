#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""YM-ALG.  Which algebras the bit rule gives inside so(m) once one datum is chosen: u(n), su(3) and the algebra of the Standard Model.   python3 ym_algebras.py

 [bit]   Lie([-1]*2n) (the bivectors of Cl(0,2n), bracket from the bit product), J = B_01 + B_23 + ... + B_(2n-2,2n-1):
         the commutant of J is an exact nullspace of ad_J of dimension n^2 (n = 1..6), closed, with centre spanned by J, derived algebra of dimension n^2 - 1,
         and the Killing form of so(2n) negative definite on it.  so(6): su(3) = the derived algebra of the commutant of J (dimension 8, centre 0).
         so(10) on the label bits (pairs 0, 1 weak, pairs 2, 3, 4 colour; the idea of H3f of baez_check): the commutant of J_w = B_01 + B_23 and J_c = B_45 + B_67 + B_89
         inside su(5) has dimension 12 = 8 + 3 + 1, derived algebra 11, centre 3 J_w - 2 J_c; B_01, ..., B_89 is a maximal abelian subalgebra (rank 5, 40 roots).
 [std]   numpy: antisymmetric matrices commuting with the standard complex structure (rank); the octonions by Cayley-Dickson: Der(O) of dimension 14, those with D(e7) = 0 of dimension 8.
 [ctl]   J' = B_01 + 2 B_23 (J'^2 != -1 on vectors); a bivector of rank 2n - 2; the Standard Model construction with two colour pairs.
 Exports (no engine object at import): nullspace, ad_matrix, commutant, derived, centre_of."""
import os, sys, time, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

def rref(rows, ncols):
    M = [list(r) for r in rows]; piv = []; r = 0
    for c in range(ncols):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
        if r == len(M): break
    return M[:r], piv
def nullspace(rows, ncols):
    R, piv = rref(rows, ncols) if rows else ([], []); free = [c for c in range(ncols) if c not in piv]; out = []
    for fc in free:
        v = [F(0)] * ncols; v[fc] = F(1)
        for i, pc in enumerate(piv): v[pc] = -R[i][fc]
        out.append(v)
    return out
def br(L, X, Y):
    r = [F(0)] * L.G
    for (P, Q), (C, f) in L.f.items():
        if X[P] and Y[Q]: r[C] += X[P] * Y[Q] * f
    return r
def ad_matrix(L, J):
    M = [[F(0)] * L.G for _ in range(L.G)]
    for (P, B), (C, f) in L.f.items():
        if J[P]: M[C][B] += J[P] * f
    return M
def commutant(L, Js):
    rows = [r for J in Js for r in ad_matrix(L, J)]; return nullspace(rows, L.G)
def span(vecs, G):
    R, _ = rref([v for v in vecs if any(v)], G) if any(any(v) for v in vecs) else ([], []); return R
def derived(L, basis): return span([br(L, x, y) for x, y in itertools.combinations(basis, 2)], L.G)
def centre_of(L, basis):
    """elements sum c_i b_i commuting with every b_j"""
    k = len(basis); rows = []
    for bj in basis:
        cols = [br(L, bi, bj) for bi in basis]
        for C in range(L.G): rows.append([cols[i][C] for i in range(k)])
    return [[sum(c[i] * basis[i][C] for i in range(k)) for C in range(L.G)] for c in nullspace(rows, k)]
def in_span(basis, v, G): return len(span(basis + [v], G)) == len(span(basis, G))
def killing_diag(L):
    d = [F(0)] * L.G
    for (A, B), (C, f) in L.f.items():
        g = L.f.get((A, C))
        if g and g[0] == B: d[A] += F(f) * g[1]                                  # tr(ad_A ad_A) = sum_{B} f_AB^C f_AC^B
    return d
def gram_neg_def(basis, kd):
    Gm = np.array([[float(sum(x[A] * y[A] * kd[A] for A in range(len(kd)))) for y in basis] for x in basis]); return bool(len(basis) == 0 or np.max(np.linalg.eigvalsh(Gm)) < -1e-9)
def bv(L, pairs, coefs=None):
    v = [F(0)] * L.G
    for k, (i, j) in enumerate(pairs): v[L.idx[(1 << i) | (1 << j)]] += F(1 if coefs is None else coefs[k])
    return v
def intersect(U, W, G):
    rows = [[U[i][C] for i in range(len(U))] + [-W[j][C] for j in range(len(W))] for C in range(G)]
    return span([[sum(c[i] * U[i][C] for i in range(len(U))) for C in range(G)] for c in nullspace(rows, len(U) + len(W))], G)

def main():
    head('1. u(n) = the commutant of J = B_01 + B_23 + ... in so(2n) (engine Lie, exact nullspaces), n = 1..6')
    dims = []; ok_cl = True; ok_c = True; ok_d = True; ok_k = True
    for nn in range(1, 7):
        L = Lie([-1] * (2 * nn)); J = bv(L, [(2 * k, 2 * k + 1) for k in range(nn)]); U = commutant(L, [J]); dims.append(len(U))
        ok_cl &= all(in_span(U, br(L, x, y), L.G) for x, y in itertools.combinations(U, 2)) if nn <= 4 else all(in_span(U, br(L, U[0], y), L.G) and in_span(U, br(L, U[-1], y), L.G) for y in U)
        Z = centre_of(L, U); ok_c &= len(Z) == 1 and len(span(Z + [J], L.G)) == 1
        ok_d &= len(derived(L, U)) == nn * nn - 1
        if nn >= 2: ok_k &= gram_neg_def(U, killing_diag(L)) and all(x < 0 for x in killing_diag(L))
        else: ok_k &= killing_diag(L) == [0]                                          # so(2) is abelian: Killing form 0
    chk('bit', dims == [k * k for k in range(1, 7)], 'dimension of the commutant of J in so(2n): %s for n = 1..6 = n^2' % dims)
    chk('bit', ok_cl, 'the commutant is closed under the bracket (all pairs for n <= 4; for n = 5, 6 the brackets with the first and the last basis element)')
    chk('bit', ok_c and ok_d, 'its centre is one-dimensional and spanned by J (the u(1)), its derived algebra has dimension n^2 - 1 (su(n)), n = 1..6')
    chk('bit', ok_k, 'the Killing form of so(2n) (diagonal, negative on every bivector) is negative definite on the commutant: a compact algebra, n = 2..6 (at n = 1, so(2) is abelian and its Killing form is 0)')
    tick('part 1')

    head('2. su(3) in so(6), the Standard Model algebra in so(10) on the label bits, the rank of so(10)')
    L6 = Lie([-1] * 6); J6 = bv(L6, [(0, 1), (2, 3), (4, 5)]); U6 = commutant(L6, [J6]); S3 = derived(L6, U6); kd6 = killing_diag(L6)
    chk('bit', len(U6) == 9 and len(S3) == 8 and not in_span(S3, J6, L6.G) and centre_of(L6, S3) == [] and gram_neg_def(S3, kd6) and L6.G == 15,
        'so(6) (dimension 15 = dim su(4)): the commutant of J is u(3) (9), its derived algebra su(3) has dimension %d, does not contain J, has centre 0, and the Killing form is negative definite on it' % len(S3))
    L10 = Lie([-1] * 10); Jw = bv(L10, [(0, 1), (2, 3)]); Jc = bv(L10, [(4, 5), (6, 7), (8, 9)]); Jt = [x + y for x, y in zip(Jw, Jc)]
    Uwc = commutant(L10, [Jw, Jc]); U5 = commutant(L10, [Jt]); SU5 = derived(L10, U5); SM = intersect(Uwc, SU5, L10.G); DSM = derived(L10, SM); Z = centre_of(L10, SM)
    Y = [3 * x - 2 * y for x, y in zip(Jw, Jc)]
    chk('bit', (len(Uwc), len(U5), len(SU5)) == (13, 25, 24), 'so(10): the commutant of J_w = B_01 + B_23 and J_c = B_45 + B_67 + B_89 has dimension %d (u(2) + u(3)); u(5) = commutant of J_w + J_c: %d; su(5) = its derived algebra: %d' % (len(Uwc), len(U5), len(SU5)))
    chk('bit', len(SM) == 12 and len(DSM) == 11 and len(Z) == 1 and len(span(Z + [Y], L10.G)) == 1 and in_span(SM, Y, L10.G),
        'the Standard Model algebra = commutant of J_w, J_c inside su(5): dimension %d = 8 + 3 + 1, derived algebra %d (su(3) + su(2)), centre spanned by 3 J_w - 2 J_c (the direction N_w/2 - N_c/3 of H3f)' % (len(SM), len(DSM)))
    Hc = [bv(L10, [(2 * k, 2 * k + 1)]) for k in range(5)]; CH = commutant(L10, Hc)
    chk('bit', len(CH) == 5 and len(span(CH + Hc, L10.G)) == 5 and L10.G == 45, 'B_01, B_23, ..., B_89 commute and their commutant is their own span (dimension 5): a maximal abelian subalgebra, so(10) has rank 5 and 45 - 5 = 40 roots')
    tick('part 2')

    head('3. [std] numpy matrices and the octonions; controls')
    ok_np = True; dn = []
    for nn in range(1, 7):
        m = 2 * nn; J0 = np.zeros((m, m))
        for k in range(nn): J0[2 * k, 2 * k + 1] = 1; J0[2 * k + 1, 2 * k] = -1
        basis = []
        for i in range(m):
            for j in range(i + 1, m):
                E = np.zeros((m, m)); E[i, j] = 1; E[j, i] = -1; basis.append(E)
        M = np.array([(J0 @ E - E @ J0).ravel() for E in basis]).T; dn.append(int(len(basis) - np.linalg.matrix_rank(M)))
    ok_np = dn == [k * k for k in range(1, 7)]
    def cd(x, y):
        k = len(x)
        if k == 1: return x * y
        h = k // 2; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
        conj = lambda z: np.concatenate([z[:1], -z[1:]])
        return np.concatenate([cd(a, c) - cd(conj(d), b), cd(d, a) + cd(b, conj(c))])
    e = np.eye(8); T = np.array([[cd(e[i], e[j]) for j in range(8)] for i in range(8)])
    rows = []
    for i in range(8):
        for j in range(8):
            for out in range(8):
                r = np.zeros(64)
                for k in range(8):
                    r[out * 8 + k] += T[i, j, k]                                   # D(e_i e_j)_out = sum_k (e_i e_j)_k D[out, k]
                    r[k * 8 + i] -= T[k, j, out]                                   # (D(e_i) e_j)_out = sum_k D[k, i] (e_k e_j)_out
                    r[k * 8 + j] -= T[i, k, out]                                   # (e_i D(e_j))_out
                rows.append(r)
    Rm = np.array(rows); g2 = int(64 - np.linalg.matrix_rank(Rm)); su3 = int(64 - np.linalg.matrix_rank(np.vstack([Rm] + [np.eye(64)[k * 8 + 7] for k in range(8)])))
    alt = all(np.allclose(cd(cd(e[i], e[i]), e[j]), cd(e[i], cd(e[i], e[j]))) for i in range(8) for j in range(8))
    chk('std', ok_np, 'numpy: antisymmetric 2n x 2n matrices commuting with the standard complex structure: dimension %s, n = 1..6' % dn)
    chk('std', alt and (g2, su3) == (14, 8), 'numpy octonions (Cayley-Dickson, alternative): Der(O) has dimension %d (g2) and the derivations with D(e7) = 0 dimension %d (su(3)), as bd.alg.17 of alg_octonion.py asserts on its sign table' % (g2, su3))
    L4 = Lie([-1] * 4); Jp = bv(L4, [(0, 1), (2, 3)], [1, 2]); cJp = commutant(L4, [Jp])
    chk('ctl', len(cJp) == 2, 'control J\' = B_01 + 2 B_23 in so(4) (J\'^2 is not -1 on vectors): commutant of dimension %d, not 4' % len(cJp))
    dr = []
    for nn in range(2, 7):
        L = Lie([-1] * (2 * nn)); dr.append(len(commutant(L, [bv(L, [(2 * k, 2 * k + 1) for k in range(nn - 1)])])))
    chk('ctl', dr == [(k - 1) ** 2 + 1 for k in range(2, 7)] and all(d != k * k for d, k in zip(dr, range(2, 7))), 'control: a bivector of rank 2n - 2 (the last pair left out) has a commutant of dimension %s = (n-1)^2 + 1 for n = 2..6, not n^2 (smaller, u(n-1) + so(2))' % dr)
    Jc2 = bv(L10, [(4, 5), (6, 7)]); U2 = commutant(L10, [Jw, Jc2]); SM2 = intersect(U2, SU5, L10.G)
    chk('ctl', len(SM2) != 12, 'control: with two colour pairs (J_c = B_45 + B_67) the same construction gives dimension %d inside su(5), not 12' % len(SM2))
    tick('part 3')
    finish('YM-ALG')

if __name__ == '__main__': main()
