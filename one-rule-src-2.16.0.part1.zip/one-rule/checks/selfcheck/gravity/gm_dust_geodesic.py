#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-DUST.  Dust: D tau_a = [div(rho u) u_a + rho a_a] vol, so the conservation law that the field equation forces is free fall.   python3 gm_dust_geodesic.py

 Derivation: T^{ab} = rho u^a u^b, tau_a = T^b_a Theta_b = rho u_a Theta_u (Theta_u = i_u vol). With u the frame vector E_0 (u^a = delta^a_0) and a torsion-free connection,
 D tau_a = d(rho Theta_u) u_a + rho (D u)_a ^ Theta_u = [div(rho u) u_a + rho a_a] vol, a = nabla_u u (a.u = 0). The u-part is div(rho u), the part orthogonal to u is rho a, so D tau_a = 0
 iff div(rho u) = 0 and (where rho != 0) a = 0. With E_a = kappa tau_a and the Noether identity D E_a = 0 of the torsion-free engine (b2_noether.py), the field equation forces free fall.
 [bit]  n = 4, (+,-,-,-): random polynomial frames (b1lib.rand_frame, exact 2-jets), the A3 closed-form omega (1-jet), random polynomial rho (strong sampler of a2b_strong_sampling.py,
        degree 2, integers -50..50); Theta_b and vol from the engine's wedge (g2_hodge); the engine's D_covector of tau_a at the point equals [div(rho u) u_a + rho a_a] vol with
        div(rho u) vol = d(rho Theta_0) (engine d) and a^c = i_u (D u)^c (engine D_vector, the h table); u^a a_a = 0.
 [std]  the metric g = e^T eta e, Christoffel symbols at the point (own code), u^mu = E^mu_0 (inverse frame to first order): nabla_mu (rho u^mu u^nu) at the point; u_nu nabla_mu T^{mu nu}
        = nabla_mu (rho u^mu) and the orthogonal part rho (u^mu d_mu u^nu + Gamma^nu_{mu l} u^mu u^l) (the textbook geodesic equation).
 [bit==std] D tau_a / vol = the frame components of nabla_mu T^{mu nu}; a^a = the frame components of the textbook acceleration.
 Controls: the decomposition with 2 rho a or -rho a fails on frames with a != 0; the Rindler frame (e^0 = (1 + g x) dt): rho independent of t gives div(rho u) = 0 but a = g != 0 and
 D tau_a != 0 (both sides computed); the flat frame with d_0 rho = 0 has D tau_a = 0 (geodesic).
 Scope: three random frames and densities, the Rindler and flat frames; the value at the point (the origin of the jets)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
from a2b_strong_sampling import s_poly

N = 4; SQ = LORENTZ(4); FULL = (1 << N) - 1; SEEDS = (37, 1037, 2037)
def engine_side(Gv, S, e, rho):
    """[bit] (D tau_a at the point, [div(rho u) u_a + rho a_a] vol at the point, div(rho u), a^c, vol(0))"""
    Fm = Gv.Fm; om = omega_closed_form(Gv, e, S, N, 1)[0]
    with trunc(N, xdeg=1):
        th = H.theta_forms(e, Fm, N); vol = H.vol_form(e, Fm, N)
        tau = [Fm.wedge({0: rho}, th[0]) if a == 0 else {} for a in range(N)]             # u_a = eta_{a0}: only tau_0 = rho Theta_0
        Dt = Gv.D_covector(om, tau); dRT = Fm.d(tau[0])
        Du = Gv.D_vector(om, [{0: const(N, 1)} if c == 0 else {} for c in range(N)])        # u^c = delta^c_0, constant frame components
    e0, E0, det = E0_of(e, N, N); v0 = at0(vol.get(FULL, {}), N)
    div = at0(dRT.get(FULL, {}), N) / v0
    acc = [sum(at0(Du[c].get(1 << mu, {}), N) * E0[mu][0] for mu in range(N)) for c in range(N)]
    r0 = at0(rho, N); ua = [F(SQ[0]) if a == 0 else F(0) for a in range(N)]
    lhs = [at0(Dt[a].get(FULL, {}), N) for a in range(N)]
    rhs = [(div * ua[a] + r0 * SQ[a] * acc[a]) * v0 for a in range(N)]
    return lhs, rhs, div, acc, v0, r0, om
def std_side(e, rho):
    """[std] nabla_mu (rho u^mu u^nu) at the point, its u-part and the textbook acceleration, carried to frame components (no engine)"""
    g = std_metric(e, N, SQ, N, 2); g0 = [[at0(g[(a, b)], N) for b in range(N)] for a in range(N)]; det, g0i = det_inv(g0)
    dg = lambda k, a, b: at0(sp_der(g[(a, b)], k), N)
    Gam = {(l, m, v): sum(g0i[l][s] * F(1, 2) * (dg(m, s, v) + dg(v, s, m) - dg(s, m, v)) for s in range(N)) for l in range(N) for m in range(N) for v in range(N)}
    e0 = [[at0(e[a].get(1 << mu, {}), N) for mu in range(N)] for a in range(N)]; d0, E0 = det_inv(e0)
    e1 = [[sp_add(e[a].get(1 << mu, {}), const(N, e0[a][mu]), -1) for mu in range(N)] for a in range(N)]
    u = [lin((E0[mu][0], const(N, 1)), *[(-E0[mu][b] * E0[nu][0], {k: v for k, v in e1[b][nu].items() if sum(k) == 1}) for b in range(N) for nu in range(N)]) for mu in range(N)]
    u0 = [at0(u[mu], N) for mu in range(N)]; du = [[at0(sp_der(u[mu], k), N) for k in range(N)] for mu in range(N)]
    r0 = at0(rho, N); dr = [at0(sp_der(rho, k), N) for k in range(N)]
    divT = [sum(dr[m] * u0[m] * u0[v] + r0 * du[m][m] * u0[v] + r0 * u0[m] * du[v][m] for m in range(N)) + sum(Gam[(m, m, l)] * r0 * u0[l] * u0[v] + Gam[(v, m, l)] * r0 * u0[m] * u0[l] for m in range(N) for l in range(N)) for v in range(N)]
    div_ru = sum(dr[m] * u0[m] + r0 * du[m][m] for m in range(N)) + sum(Gam[(m, m, l)] * r0 * u0[l] for m in range(N) for l in range(N))
    accv = [sum(u0[m] * du[v][m] for m in range(N)) + sum(Gam[(v, m, l)] * u0[m] * u0[l] for m in range(N) for l in range(N)) for v in range(N)]
    low = lambda V: [sum(g0[v][l] * V[v] for v in range(N)) for l in range(N)]
    to_frame_dn = lambda V: [sum(low(V)[l] * E0[l][a] for l in range(N)) for a in range(N)]
    to_frame_up = lambda V: [sum(e0[a][v] * V[v] for v in range(N)) for a in range(N)]
    unorm = sum(g0[m][v] * u0[m] * u0[v] for m in range(N) for v in range(N))
    return to_frame_dn(divT), div_ru, to_frame_up(accv), unorm, divT, low(u0)
def rindler(gacc, nv=N):
    e = [{1: lin((F(1), const(nv, 1)), (F(gacc), var(nv, 1)))}] + [{1 << i: const(nv, 1)} for i in range(1, N)]; return e

def main():
    Lie_ = Lie(SQ); Gv = Grav(N, Lie_); S = koszul_S(N, SQ, Lie_)                    # built per run
    head('(1) random polynomial frames, u = E_0, random rho: the engine\'s D tau_a against [div(rho u) u_a + rho a_a] vol [bit]; Christoffel route [std]')
    for sd in SEEDS:
        rng = random.Random(sd); e = rand_frame(rng, N, deg=2, coef=3); rho = s_poly(rng, N, 2, 50)
        lhs, rhs, div, acc, v0, r0, om = engine_side(Gv, S, e, rho)
        with trunc(N, xdeg=0): tz = torsion_zero_at0(Gv, om, e, N)
        chk('bit', tz and lhs == rhs and acc[0] == 0 and any(acc), 'seed %d: T = 0; D tau_a = [div(rho u) u_a + rho a_a] vol at the point (four components), div(rho u) = %s, a = (%s) != 0, u^a a_a = 0' % (sd, div, ', '.join(map(str, acc))))
        Tfr, div_s, acc_s, unorm, divT, ulow = std_side(e, rho)
        chk('std', unorm == 1 and sum(ulow[v] * divT[v] for v in range(N)) == div_s, 'seed %d: g(u, u) = 1; u_nu nabla_mu (rho u^mu u^nu) = nabla_mu (rho u^mu) = %s (Christoffel symbols at the point)' % (sd, div_s))
        chk('bit==std', [x / v0 for x in lhs] == Tfr and div == div_s and acc == acc_s, 'seed %d: D tau_a / vol = the frame components of nabla_mu T^{mu nu} = (%s); div(rho u) and the acceleration agree with the textbook ones' % (sd, ', '.join(map(str, Tfr))))
        bad2 = [(div * (SQ[0] if a == 0 else 0) + 2 * r0 * SQ[a] * acc[a]) * v0 for a in range(N)]; badm = [(div * (SQ[0] if a == 0 else 0) - r0 * SQ[a] * acc[a]) * v0 for a in range(N)]
        chk('ctl', lhs != bad2 and lhs != badm, 'seed %d: the decomposition with 2 rho a or with -rho a in place of rho a does not match D tau_a' % sd)
    head('(2) the accelerated and the geodesic frame vector')
    gacc = F(1, 3); rng = random.Random(7)
    rho_t = {k: v for k, v in s_poly(rng, N, 2, 50).items() if k[0] == 0}                  # independent of t
    lhs, rhs, div, acc, v0, r0, om = engine_side(Gv, S, rindler(gacc), rho_t)
    Tfr, div_s, acc_s, unorm, divT, ulow = std_side(rindler(gacc), rho_t)
    chk('ctl', lhs == rhs and div == 0 and acc[1] != 0 and any(x != 0 for x in lhs), 'Rindler frame e^0 = (1 + x/3) dt, rho independent of t: div(rho u) = %s, a = (%s) != 0, so D tau_a = rho a_a vol = (%s) != 0 (the identity holds, free fall fails)' % (div, ', '.join(map(str, acc)), ', '.join(map(str, lhs))))
    chk('bit==std', acc == acc_s and [x / v0 for x in lhs] == Tfr, 'Rindler frame: the acceleration and nabla_mu T^{mu nu} agree with the Christoffel route (a^1 = %s)' % acc_s[1])
    ef = [{1 << a: const(N, 1)} for a in range(N)]
    lhs, rhs, div, acc, v0, r0, om = engine_side(Gv, S, ef, rho_t)
    chk('bit', all(x == 0 for x in lhs) and div == 0 and not any(acc), 'flat frame, rho independent of t: a = 0 and div(rho u) = 0, so D tau_a = 0 (a geodesic dust flow)')
    print('\n  reading: D tau_a = [div(rho u) u_a + rho a_a] vol; with E_a = kappa tau_a and D E_a = 0 (torsion free) the conservation law holds, so div(rho u) = 0 and u.grad u = 0 where rho != 0.')

if __name__ == '__main__':
    main(); finish('GM-DUST')
