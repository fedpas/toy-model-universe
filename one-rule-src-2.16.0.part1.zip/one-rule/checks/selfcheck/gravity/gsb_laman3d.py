#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSB-LAMAN3.  Maxwell-Calladine counting in three dimensions: the count is necessary and not sufficient.   python3 gsb_laman3d.py [--fault COUNT|PLANE|MC]

Statement.  A bar framework with V joints and E bars in R^3 whose joints span R^3 affinely has
    mechanisms - self-stresses = 3V - E - C(4, 2) = 3V - E - 6        (Maxwell-Calladine, d = 3),
with mechanisms = dim ker(rigidity matrix) - 6 and self-stresses = dim ker(transpose).  In the plane Laman's count decides generic rigidity
(gm_laman.py); in three dimensions the analogous count (E = 3V - 6 and every subgraph on k >= 3 joints has at most 3k - 6 bars) does not:
the double banana (two triangular bipyramids glued at their two apexes, V = 8, E = 18, no bar between the apexes) meets the count and is
flexible at generic joints: one mechanism (the two bananas turn about the axis through the shared joints) and one self-stress.
The octahedron (V = 6, E = 12 = 3V - 6) is rigid at generic joints.
[bit]  exact ranks over Q (gm_laman.rank_q: integer elimination) of gm_cube_framework.rigidity at three random integer positions per graph
       (coordinates -1000..1000, fixed seed) and gm_cube_framework.rank_mod_p (p = 1000003); the six trivial motions: three translations and the
       three rotations from the engine's h table of Cl(0,3) (gm_cube_framework.rotation_generators, = the bit-rule commutator), in the kernel,
       rank 6; the hinge motion of the double banana written down and checked to lie in the kernel, independent of the trivial motions;
       the count conditions by all 2^V vertex subsets.
[std]  numpy matrix_rank (SVD, floats) at the same positions.
[bit==std] exact rank = numpy rank at every position.
Graphs: tetrahedron (4, 6), triangular bipyramid (5, 9), octahedron (6, 12), double banana (8, 18), the double banana with the apex bar (8, 19).
Controls (--fault puts each into its main check, exit 1): COUNT rigidity decided by the count alone; PLANE the octahedron with every joint in
one plane (not affinely spanning, not generic); MC the index with C(d+1,2) replaced by 3 (the planar number)."""
import os, sys, time, random, itertools
from math import comb
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import gm_cube_framework as CF
from math import gcd
import numpy as np

def rank_q(M):
    """exact rank over Q of an integer matrix (the elimination of gm_laman.py, copied: that module reads its own command line at import)"""
    A = [[int(x) for x in row] for row in M]; rows = len(A); cols = len(A[0]) if rows else 0; r = 0
    for c in range(cols):
        piv = next((i for i in range(r, rows) if A[i][c] != 0), None)
        if piv is None: continue
        A[r], A[piv] = A[piv], A[r]; pr = A[r]
        for i in range(r + 1, rows):
            if A[i][c] != 0:
                a, b = pr[c], A[i][c]; row = [a * x - b * y for x, y in zip(A[i], pr)]; g = 0
                for x in row: g = gcd(g, x)
                A[i] = [x // g for x in row] if g > 1 else row
        r += 1
        if r == rows: break
    return r

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'COUNT', 'PLANE', 'MC'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
D = 3; TRIV = comb(D + 1, 2)

def bipyramid(p0, p1, eq):
    return [tuple(sorted(e)) for e in [(eq[0], eq[1]), (eq[1], eq[2]), (eq[0], eq[2])] + [(p, q) for p in (p0, p1) for q in eq]]
GRAPHS = {
    'tetrahedron': (4, [(i, j) for i in range(4) for j in range(i + 1, 4)]),
    'triangular bipyramid': (5, bipyramid(0, 1, (2, 3, 4))),
    'octahedron': (6, [(i, j) for i in range(6) for j in range(i + 1, 6) if (i, j) not in ((0, 1), (2, 3), (4, 5))]),
    'double banana': (8, bipyramid(0, 1, (2, 3, 4)) + bipyramid(0, 1, (5, 6, 7))),
    'double banana + apex bar': (8, bipyramid(0, 1, (2, 3, 4)) + bipyramid(0, 1, (5, 6, 7)) + [(0, 1)]),
}
def positions(rng, V, plane=False):
    return [[rng.randint(-1000, 1000) for _ in range(2)] + [0 if plane else rng.randint(-1000, 1000)] for _ in range(V)]
def count_ok(V, bars):
    """E = 3V - 6 and every vertex subset with k >= 3 spans at most 3k - 6 bars (all 2^V subsets)"""
    if len(bars) != 3 * V - 6: return False
    for mask in range(1 << V):
        k = bin(mask).count('1')
        if k < 3: continue
        inside = sum(1 for (u, v) in bars if mask >> u & 1 and mask >> v & 1)
        if inside > 3 * k - 6: return False
    return True
def matvec(M, v): return [sum(int(M[r, c]) * v[c] for c in range(M.shape[1])) for r in range(M.shape[0])]
def cross(a, b): return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]

def main():
    head('GSB-LAMAN3: Maxwell-Calladine in three dimensions; the double banana and the octahedron' + (' [fault %s]' % FAULT if FAULT else ''))
    W, Wb = CF.rotation_generators(D)
    chk('bit', W == Wb and len(W) == 3 and all(any(x != 0 for r in M for x in r) for M in W), 'the three rotation generators of R^3 from the engine\'s h table of Cl(0,3) equal the bit-rule commutators (1/2)[B_ab, gamma_c] (3 generators, non-zero)')
    rng = random.Random(8023); res = {}
    for name, (V, bars) in GRAPHS.items():
        E = len(bars); ranks = []; rp_ok = True; np_ok = True; triv_ok = True
        for k in range(3):
            P = positions(rng, V, plane=(FAULT == 'PLANE' and name == 'octahedron'))
            M = CF.rigidity(P, bars, D); rq = rank_q(M); ranks.append(rq)
            rp_ok &= CF.rank_mod_p(M) == rq; np_ok &= int(np.linalg.matrix_rank(M.astype(float))) == rq
            Tm = CF.trivial_motions(P, D, W)
            triv_ok &= all(all(x == 0 for x in matvec(M, [int(t) for t in tv])) for tv in Tm) and rank_q(np.array([[int(t) for t in tv] for tv in Tm], dtype=object)) == TRIV
            if name == 'double banana' and k == 0: keepP, keepM = P, M
        rk = max(ranks); mech = D * V - rk - TRIV; stress = E - rk
        res[name] = dict(V=V, E=E, rank=rk, ranks=ranks, m=mech, s=stress, count=count_ok(V, bars))
        chk('bit', triv_ok, '%s: the six trivial motions (three translations, three h-table rotations) lie in the kernel at all three positions, rank %d' % (name, TRIV))
        chk('bit==std', rp_ok and np_ok, '%s: exact rank over Q = rank mod p = numpy rank at all three positions (ranks %s)' % (name, ranks))
        tri = TRIV if FAULT != 'MC' else 3
        chk('bit', mech - stress == D * V - E - tri, '%s (V = %d, E = %d): rank %d, mechanisms %d, self-stresses %d; mechanisms - self-stresses = 3V - E - C(4,2) = %d' % (name, V, E, rk, mech, stress, D * V - E - tri))
    tick('ranks')
    db = res['double banana']
    chk('bit', db['count'] and db['E'] == 3 * db['V'] - 6, 'double banana: E = 18 = 3V - 6 and every vertex subset with k >= 3 spans at most 3k - 6 bars (all 256 subsets): the three-dimensional count holds')
    decided = db['count'] if FAULT == 'COUNT' else (db['m'] == 0)
    chk('bit', db['ranks'] == [17, 17, 17] and db['m'] == 1 and db['s'] == 1 and (decided is False), 'double banana: rank 17 at all three generic positions, so one mechanism beyond the six trivial motions and one self-stress: generically flexible although the count holds (the count is not sufficient in three dimensions)')
    P = keepP; M = keepM; a, b = P[0], P[1]; w = [b[i] - a[i] for i in range(3)]
    v = []
    for u in range(8): v += cross(w, [P[u][i] - a[i] for i in range(3)]) if u in (2, 3, 4) else [0, 0, 0]
    Tm = [[int(t) for t in tv] for tv in CF.trivial_motions(P, D, W)]
    chk('bit', all(x == 0 for x in matvec(M, v)) and rank_q(np.array(Tm + [v], dtype=object)) == TRIV + 1, 'double banana: the hinge motion (joints 2, 3, 4 turn about the axis through the shared joints 0 and 1, the rest at rest) lies in the kernel and is independent of the six trivial motions (rank 7)')
    Mt = np.array([[int(M[r, c]) for r in range(M.shape[0])] for c in range(M.shape[1])], dtype=object)
    chk('bit', M.shape[0] - rank_q(M) == 1 and rank_q(Mt) == 17, 'double banana: the self-stress space (kernel of the transpose, 18 bars) has dimension 18 - 17 = 1')
    ab = res['double banana + apex bar']; Mab = CF.rigidity(P, GRAPHS['double banana + apex bar'][1], D)
    chk('bit', ab['ranks'] == [17, 17, 17] and ab['m'] == 1 and ab['s'] == 2 and all(x == 0 for x in matvec(Mab, v)), 'the double banana with the bar between the shared joints 0 and 1: rank still 17, one mechanism, two self-stresses; the hinge motion is still in the kernel (joints 0 and 1 are at rest in it, and each banana already fixes their distance): the bar on the hinge axis does not block the hinge')
    oc = res['octahedron']
    chk('bit', oc['count'] and oc['ranks'] == [12, 12, 12] and oc['m'] == 0 and oc['s'] == 0, 'octahedron: E = 12 = 3V - 6, the count holds, rank 12 at all three positions: infinitesimally rigid, no self-stress')
    chk('bit', res['tetrahedron']['rank'] == 6 and res['triangular bipyramid']['rank'] == 9 and res['tetrahedron']['m'] == res['triangular bipyramid']['m'] == 0, 'tetrahedron (rank 6) and triangular bipyramid (rank 9): rigid, the count holds')
    head('controls')
    chk('ctl', db['count'] != (db['m'] == 0), 'the count alone calls the double banana rigid; the exact rank shows a mechanism: deciding by the count is wrong in three dimensions')
    rngp = random.Random(77); Pp = positions(rngp, 6, plane=True); rpl = rank_q(CF.rigidity(Pp, GRAPHS['octahedron'][1], D))
    chk('ctl', rpl < 12, 'the octahedron with all six joints in one plane (not affinely spanning): rank %d < 12' % rpl)
    chk('ctl', db['m'] - db['s'] != 3 * 8 - 18 - 3, 'the planar number 3 in place of C(4,2) = 6: the index 3V - E - 3 = 3 does not equal mechanisms - self-stresses = 0')
    tick('done')
    finish('GSB-LAMAN3')

if __name__ == '__main__': main()
