#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSA-FRW.  FRW beyond one local series: the acceleration condition from the engine's two Friedmann equations, the de Sitter attractor and slow roll
 (numerical), and focusing of FRW null rays with the null energy condition on dust and radiation.   python3 gsa_frw.py [--fault rho_plus_p|sign_c|lambda_neg|theta_third|phantom]

 Frames  c4_frw.frw_frame: cosmic time e^0 = dt, e^i = a(t) s(x) dx^i (s = 1 - k r^2/4, k = -1, 0, 1), conformal time e^0 = a d eta, e^i = a dx^i; a a random
         cubic (exact polynomial frames); E_a(c) = -(G - 3c delta)^h_a Theta_h (c = Lambda/3); the comoving fluid T^0_0 = rho, T^i_i = -p, E_a + kappa T_a = 0.
 Part 1 [bit]  kappa rho = M^0_0, kappa p = -M^i_i from the engine's E_a(c) (c4_frw: M^0_0 = 3H^2 + 3k/a^2 - 3c, M^i_i = 2a''/a + H^2 + k/a^2 - 3c):
         a''/a = c - kappa (rho + 3p)/6 exactly, so a'' > 0 iff rho + 3p < 6c/kappa = 2 Lambda/kappa (rho + 3p < 0 at Lambda = 0), on 18 random frames
         (k = -1, 0, 1; c = 0, 1/3, -2/5), both signs of a'' present; [std] the Christoffel route on one frame per k.
 Part 2 [std]  the de Sitter attractor, floats: H' = -kappa (rho + p)/2 + k/a^2, a' = a H, rho = sum rho_w a^(-3(1+w)) (dust, radiation, w = -1/2), kappa = 3,
         c = 1/4: H -> sqrt(c) for k = 0, -1, +1 (relative 1e-8 at sqrt(c) t = 40), the constraint H^2 + k/a^2 = rho + c kept to 1e-9; flat dust + Lambda against the
         recalled closed form H = sqrt(c) coth((3/2) sqrt(c) t).  Control: c < 0 recollapses (H reaches 0).
 Part 3 [std]  slow roll, floats: V = m^2 phi^2/2 (kappa = 1, m = 1e-2, phi0 = 16), the Friedmann-Klein-Gordon system (b3c4_scalar_frw: rho = phi'^2/2 + V,
         p = phi'^2/2 - V): a'' > 0 exactly while eps_H = kappa phi'^2/(2 H^2) < 1 (a''/a = H^2 (1 - eps_H)); eps_H/eps_V -> 1 with eps_V = 2/(kappa phi^2) early;
         the end eps_H = 1; e-folds against the slow-roll count kappa (phi0^2 - phi_end^2)/4 (recalled, Mukhanov; Weinberg).
 Part 4 [bit]  null rays on conformal FRW (k = 0): the plane congruence N = a^-2 (d_eta - d_z) and the radial one N = a^-2 (d_eta - xhat.d_x), frame components
         (1/a)(1, 0, 0, -1) and (1/a)(1, -xhat); f1_focusing.evaluate (B = nabla N with the engine's omega and D_vector, theta, d theta/d lambda with the engine's d,
         R_NN from E_a): theta = 2a'/a^3 (plane), (2/a^2)(a'/a - 1/r) (radial); sigma^2 = w^2 = 0, a = 0; d theta/d lambda = -theta^2/2 - sigma^2 + w^2 - R_NN
         exactly; R_NN = kappa (rho + p)(u.N)^2 >= 0 for dust (a = eta^2) and radiation (a = eta) at 13 rational null directions; [std] f1_focusing.std_B.
 Controls (each also a --fault NAME): rho_plus_p (rho + p in place of rho + 3p), sign_c (-c in the identity), lambda_neg (the attractor run with c < 0),
         theta_third (-theta^2/3, the timelike coefficient), phantom (a frame with rho + p < 0 in the NEC check: R_NN < 0).
 Scope   FRW frames at one point each (exact), floats where named; the singularity and focusing theorems (Raychaudhuri; Penrose; Hawking and Ellis) are recalled."""
import os, sys, time, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
from scipy.integrate import solve_ivp
import c4_frw as C4
import g2_hodge as H
from f1_focusing import evaluate, screen, std_B

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'rho_plus_p', 'sign_c', 'lambda_neg', 'theta_third', 'phantom'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
NV = 4; SQ = LORENTZ(4)
def dotN(u, v): return sum(SQ[a] * u[a] * v[a] for a in range(4))
def ricci_NN(Gm, N): return H.contract_NN(Gm, N, SQ) - dotN(N, N) * sum(Gm[a][a] for a in range(4)) / 2

def main():
    head('GSA-FRW: acceleration condition, de Sitter attractor, slow roll, focusing of FRW null rays' + (' [fault %s]' % FAULT if FAULT else ''))
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
    from d_probe import d_sign_probe; d_sign_probe()
    rng = random.Random(148)
    rq = lambda: F(rng.choice([-9, -7, -5, -3, -2, -1, 1, 2, 3, 5, 7, 9]), rng.randint(1, 5))
    # ================================================================================== 1
    head('1. a\'\'/a = c - kappa (rho + 3p)/6 from the engine\'s E_a(c) on random cosmic-time frames: a\'\' > 0 iff rho + 3p < 6c/kappa')
    ok_id = ok_sign = ok_std = True; npos = nneg = 0; n1 = 0; seen_k = set()
    for i in range(18):
        k = (-1, 0, 1)[i % 3]; c = (F(0), F(1, 3), F(-2, 5))[(i // 3) % 3]
        ac = [F(rng.randint(1, 9), rng.randint(1, 4))] + [rq() for _ in range(3)]
        e = C4.frw_frame(ac, k=k); om, R, Ea = C4.engine_frw(Gv, S, e, c, 1); M, comp, (e0, E0, det) = C4.mixed_at0(Ea, e)
        krho, kp = M[0][0], -M[1][1]; add = 2 * ac[2] / ac[0]
        cc = -c if FAULT == 'sign_c' else c; rp3 = (krho + kp) if FAULT == 'rho_plus_p' else (krho + 3 * kp)
        ok_id &= (add == cc - rp3 / 6) and M[1][1] == M[2][2] == M[3][3]
        ok_sign &= ((add > 0) == (rp3 < 6 * cc)) and ((add < 0) == (rp3 > 6 * cc)); npos += int(add > 0); nneg += int(add < 0); n1 += 1
        if k not in seen_k:
            seen_k.add(k); g = std_metric(e, 4, SQ, NV, 2); Rr, g0, g0i = std_riemann(g, 4, NV); Gm, _, _ = std_einstein_mixed(Rr, g0, g0i, 4); Gf = to_frame_mixed(Gm, e0, E0, 4)
            ok_std &= all(Gf[b][a] == M[b][a] + (3 * c if a == b else 0) for a in range(4) for b in range(4))
    chk('bit', ok_id, 'a\'\'/a = c - kappa (rho + 3p)/6 exactly on %d frames (k = -1, 0, 1; c = 0, 1/3, -2/5), kappa rho = M^0_0, kappa p = -M^i_i read off the engine\'s E_a(c) (isotropic)' % n1)
    chk('bit', ok_sign and npos > 0 and nneg > 0, 'sign rule: a\'\' > 0 iff rho + 3p < 6c/kappa = 2 Lambda/kappa on every frame (%d accelerating, %d decelerating); at Lambda = 0: a\'\' > 0 iff rho + 3p < 0' % (npos, nneg))
    chk('bit==std', ok_std, 'Christoffel route: G^b_a = M^b_a + 3c delta on one frame per k')
    # controls on fresh frames
    bad_rp = bad_c = 0
    for i in range(12):
        k = (-1, 0, 1)[i % 3]; c = (F(1, 3), F(-2, 5))[i % 2]; ac = [F(rng.randint(1, 9), rng.randint(1, 4))] + [rq() for _ in range(3)]
        e = C4.frw_frame(ac, k=k); om, R, Ea = C4.engine_frw(Gv, S, e, c, 1); M, comp, _ = C4.mixed_at0(Ea, e); krho, kp = M[0][0], -M[1][1]; add = 2 * ac[2] / ac[0]
        bad_rp += int(add != c - (krho + kp) / 6); bad_c += int(add != -c - (krho + 3 * kp) / 6)
    chk('ctl', bad_rp == 12 and bad_c == 12, 'controls: rho + p in place of rho + 3p fails the identity on %d of 12 frames; the wrong sign of c on %d of 12' % (bad_rp, bad_c))
    tick('part 1')
    # ================================================================================== 2
    head('2. [std] the de Sitter attractor (floats): dust + radiation + a w = -1/2 fluid + c, kappa = 3')
    def run(k, c, rho_w, tend):
        def rhs(t, y):
            a, Hh = y; rho = sum(r * a ** (-3 * (1 + w)) for w, r in rho_w); p = sum(w * r * a ** (-3 * (1 + w)) for w, r in rho_w)
            return [a * Hh, -1.5 * (rho + p) + k / a ** 2]
        rho0 = sum(r for _, r in rho_w); H0 = math.sqrt(rho0 + c - k)
        ev = lambda t, y: y[1]; ev.terminal = True; ev.direction = -1
        sol = solve_ivp(rhs, (0, tend), [1.0, H0], method='DOP853', rtol=1e-12, atol=1e-14, events=ev, dense_output=True)
        a, Hh = sol.y[0][-1], sol.y[1][-1]; rho = sum(r * a ** (-3 * (1 + w)) for w, r in rho_w)
        ts = np.linspace(0, sol.t[-1], 400); cons = max(abs(sol.sol(t)[1] ** 2 + k / sol.sol(t)[0] ** 2 - sum(r * sol.sol(t)[0] ** (-3 * (1 + w)) for w, r in rho_w) - c) for t in ts)
        return sol, Hh, cons
    mix = [(0.0, 2.0), (1 / 3, 0.5), (-0.5, 0.3)]; c = 0.25 if FAULT != 'lambda_neg' else -0.25
    worst = 0.0; consw = 0.0
    for k in (0, -1, 1):
        sol, Hh, cons = run(k, c, mix, 40 / math.sqrt(abs(c)))
        worst = max(worst, abs(Hh - math.sqrt(abs(c))) / math.sqrt(abs(c)) if sol.status == 0 else 1.0); consw = max(consw, cons)
    chk('std', worst < 1e-8 and consw < 1e-9, 'k = 0, -1, +1, rho = 2 a^-3 + 0.5 a^-4 + 0.3 a^-3/2 (kappa = 3), c = 1/4: H(t) -> sqrt(c) = 1/2 to relative %.1e (< 1e-8) at sqrt(c) t = 40; constraint H^2 + k/a^2 = rho + c kept to %.1e (< 1e-9)' % (worst, consw))
    sol, Hh, cons = run(0, 0.25, [(0.0, 1.0)], 40.0); cw = 0.0
    for t in np.linspace(0.5, 40.0, 200):
        a, Hn = sol.sol(t); t0 = math.atanh(math.sqrt(0.25 / (1.0 + 0.25))) / (1.5 * 0.5)       # H(0) = sqrt(rho0 + c): coth(1.5 sqrt(c) t0) = H(0)/sqrt(c)
        cw = max(cw, abs(Hn - 0.5 / math.tanh(1.5 * 0.5 * (t + t0))) / Hn)
    chk('std', cw < 1e-9, 'flat dust + Lambda: H(t) = sqrt(c) coth((3/2) sqrt(c) (t + t0)) (recalled closed form) to relative %.1e (< 1e-9) on [0.5, 40]' % cw)
    solm, Hm, _ = run(0, -0.25, mix, 400.0)
    chk('ctl', solm.status == 1 and Hm < 1e-6, 'c = -1/4 (Lambda < 0): no de Sitter limit, the expansion stops (H = 0 reached at t = %.3f) and the universe recollapses' % solm.t[-1])
    tick('part 2')
    # ================================================================================== 3
    head('3. [std] slow roll (floats): V = m^2 phi^2/2, kappa = 1, m = 1e-2, phi0 = 16')
    mm = 1e-2; kap = 1.0
    def fkg(t, y):
        a, ph, dph = y; V = 0.5 * mm * mm * ph * ph; Hh = math.sqrt(kap / 3 * (0.5 * dph * dph + V)); return [a * Hh, dph, -3 * Hh * dph - mm * mm * ph]
    ph0 = 16.0; V0 = 0.5 * mm * mm * ph0 ** 2; H0 = math.sqrt(kap * V0 / 3); y0 = [1.0, ph0, -mm * mm * ph0 / (3 * H0)]       # the slow-roll velocity at start
    endev = lambda t, y: kap * y[2] ** 2 / (2 * (kap / 3 * (0.5 * y[2] ** 2 + 0.5 * mm * mm * y[1] ** 2))) - 1; endev.terminal = True; endev.direction = 1
    sol = solve_ivp(fkg, (0, 1e5), y0, method='DOP853', rtol=1e-11, atol=1e-13, events=endev, dense_output=True)
    tend = sol.t[-1]; ts = np.linspace(0, tend, 2000); acc_ok = True; ratio_early = 0.0
    for t in ts[:-1]:
        a, ph, dph = sol.sol(t); V = 0.5 * mm * mm * ph * ph; Hh = math.sqrt(kap / 3 * (0.5 * dph * dph + V)); epsH = kap * dph * dph / (2 * Hh * Hh)
        addot = a * (-kap / 6 * (2 * dph * dph - 2 * V))                                           # Part 1's identity a''/a = c - kappa (rho + 3p)/6 at c = 0, rho + 3p = 2 phi'^2 - 2V
        acc_ok &= (addot > 0) == (epsH < 1) and abs(addot / a - Hh * Hh * (1 - epsH)) < 1e-12 * Hh * Hh
        if ph > 10: ratio_early = max(ratio_early, abs(epsH / (2 / (kap * ph * ph)) - 1))
    a_e, ph_e, dph_e = sol.y[:, -1]; N = math.log(a_e); Nsr = kap * (ph0 ** 2 - ph_e ** 2) / 4
    chk('std', acc_ok, 'along the solution (2000 times up to the end): a\'\' > 0 exactly where eps_H < 1, a\'\'/a = H^2 (1 - eps_H) to 1e-12 relative (Part 1\'s identity with rho = phi\'^2/2 + V, p = phi\'^2/2 - V)')
    chk('std', ratio_early < 2e-2, 'slow roll: |eps_H/eps_V - 1| <= %.1e (< 2e-2) while phi > 10, eps_V = 2/(kappa phi^2)' % ratio_early)
    chk('std', sol.status == 1 and 0.8 < ph_e < 1.2 and abs(N / Nsr - 1) < 2e-2, 'inflation ends (eps_H = 1) at phi = %.4f (eps_V = 1 at sqrt(2) = 1.4142); e-folds N = %.3f against the slow-roll count kappa (phi0^2 - phi_end^2)/4 = %.3f (relative %.1e < 2e-2)' % (ph_e, N, Nsr, abs(N / Nsr - 1)))
    from scipy.optimize import brentq
    tphi = lambda v: brentq(lambda t: sol.sol(t)[1] - v, 0, tend)
    segs = []
    for hi, lo in ((15.0, 5.0), (15.0, 10.0)):
        Ns = math.log(sol.sol(tphi(lo))[0] / sol.sol(tphi(hi))[0]); Nsr_ = kap * (hi * hi - lo * lo) / 4; segs.append((hi, lo, Ns, Nsr_, abs(Ns / Nsr_ - 1)))
    chk('std', all(x[4] < 1e-2 for x in segs) and segs[1][4] < segs[0][4], 'segments: phi 15 -> 5: N = %.4f against kappa (15^2 - 5^2)/4 = %.2f (relative %.1e); 15 -> 10: N = %.4f against %.2f (relative %.1e): both < 1e-2, smaller deeper in slow roll (leading order in eps_V)' % (
        segs[0][2], segs[0][3], segs[0][4], segs[1][2], segs[1][3], segs[1][4]))
    tick('part 3')
    # ================================================================================== 4
    head('4. null rays on conformal FRW frames (k = 0): expansion, shear, twist, Raychaudhuri and the null energy condition, engine (f1_focusing.evaluate)')
    def conf_data(ac):
        e = C4.frw_frame(ac, conformal=True); om, R, Ea = C4.engine_frw(Gv, S, e, F(0), 2); M, comp, (e0, E0, det) = C4.mixed_at0(Ea, e)
        with trunc(4, xdeg=2): E, _ = inverse_series(frame_matrix(e, 4), 4, NV, 2)
        a = C4.poly_t(ac);
        with trunc(4, xdeg=2): ia = E[0][0]
        return e, om, M, E, ia
    def xhat_jets(p):
        r0 = K_r(p); X = [None] + [var(NV, i) for i in (1, 2, 3)]
        d2 = lin(*[(F(1), sp_mul(X[i], X[i], 2, 4)) for i in (1, 2, 3)])
        u = lin((F(2) / r0 ** 2, lin(*[(p[i - 1], X[i]) for i in (1, 2, 3)])), (F(1) / r0 ** 2, d2)); u2 = sp_mul(u, u, 2, 4)
        ir = lin((1 / r0, const(NV, 1)), (-1 / (2 * r0), u), (F(3, 8) / r0, u2))
        return [sp_mul(lin((F(1), const(NV, p[i])), (F(1), X[i + 1])), ir, 2, 4) for i in range(3)], r0
    def K_r(p):
        s = sum(x * x for x in p); n_, d_ = math.isqrt(s.numerator), math.isqrt(s.denominator); assert F(n_, d_) ** 2 == s; return F(n_, d_)
    coef = F(-1, 3) if FAULT == 'theta_third' else F(-1, 2)
    ok_pl = ok_rad = ok_ray = ok_bs = ok_rnn = True; nrow = 0
    for j in range(4):
        ac = [F(rng.randint(2, 9), rng.randint(1, 3))] + [rq() for _ in range(3)]; e, om, M, E, ia = conf_data(ac)
        a0, a1 = ac[0], ac[1]; app = 2 * ac[2]
        Np = [ia, {}, {}, scale(ia, -1)]
        d = evaluate(Gv, om, E, Np, M); th, s2, w2, P = screen(d['B0'], d['N0'])
        ok_pl &= (th == d['theta'] == 2 * a1 / a0 ** 3 and s2 == 0 and w2 == 0 and d['acc0'] == [0] * 4 and d['diva'] == 0)
        ok_ray &= (d['dth'] == coef * th * th - s2 + w2 - d['RNN']); nrow += 1
        ok_rnn &= (d['RNN'] == (4 * a1 * a1 / a0 ** 4 - 2 * app / a0 ** 3) / a0 ** 2)
        if j < 2: ok_bs &= (d['B0'] == std_B(e, E, Np))
        p = [(F(3), F(4), F(12)), (F(2), F(-3), F(6)), (F(1), F(4), F(-8)), (F(-6), F(2), F(9))][j]; xh, r0 = xhat_jets(p)
        Nr = [ia] + [scale(sp_mul(ia, xh[i], 2, 4), -1) for i in range(3)]
        dr_ = evaluate(Gv, om, E, Nr, M); thr, s2r, w2r, _ = screen(dr_['B0'], dr_['N0'])
        ok_rad &= (thr == dr_['theta'] == 2 / a0 ** 2 * (a1 / a0 - 1 / r0) and s2r == 0 and w2r == 0 and dr_['acc0'] == [0] * 4); ok_rnn &= (dr_['RNN'] == d['RNN'])
        ok_ray &= (dr_['dth'] == coef * thr * thr - s2r + w2r - dr_['RNN']); nrow += 1
        if j < 2: ok_bs &= (dr_['B0'] == std_B(e, E, Nr))
    chk('bit', ok_pl, 'plane rays N = a^-2 (d_eta - d_z) on 4 random cubic a(eta): theta = 2a\'/a^3, sigma^2 = w^2 = 0, acceleration 0 and its divergence 0 (affine null geodesics), exactly')
    chk('bit', ok_rad, 'radial rays N = a^-2 (d_eta - xhat.d_x) at |x| = 13, 7, 9, 11: theta = (2/a^2)(a\'/a - 1/r), sigma^2 = w^2 = 0, acceleration 0, exactly')
    chk('bit', ok_ray, 'Raychaudhuri on these %d congruences: d theta/d lambda = -theta^2/2 - sigma^2 + w^2 - R_NN exactly (d theta/d lambda by the engine\'s d; the coefficients of f1_focusing\'s fit)' % nrow)
    chk('bit', ok_rnn, 'R_NN = (4a\'^2 - 2 a a\'\')/a^6 = kappa (rho + p)(u.N)^2 with u.N = 1/a, the same on the plane and the radial rays, and kappa (rho + p) = 4a\'^2/a^4 - 2a\'\'/a^3 (conformal Friedmann pair, c4_frw)')
    chk('bit==std', ok_bs, 'B = nabla N: engine (D_vector, A3 omega) = Christoffel route (f1_focusing.std_B), plane and radial rays on 2 frames')
    # null energy condition: dust a = eta^2, radiation a = eta (c4_frw: kappa rho0 = 12 and 3), phantom control
    dirs = [(F(0), F(0), F(1)), (F(1), F(0), F(0)), (F(3, 5), F(4, 5), F(0)), (F(1, 3), F(2, 3), F(2, 3)), (F(2, 7), F(-3, 7), F(6, 7)), (F(-2, 3), F(1, 3), F(2, 3)),
            (F(12, 13), F(0), F(5, 13)), (F(1, 9), F(4, 9), F(-8, 9)), (F(-6, 11), F(6, 11), F(7, 11)), (F(4, 9), F(-4, 9), F(7, 9)), (F(8, 17), F(-15, 17), F(0)),
            (F(-1), F(0), F(0)), (F(0), F(-3, 5), F(-4, 5))]
    nec = {}; eos = {}
    for nm, ac in (('dust a = eta^2 at eta = 2', [F(4), F(4), F(1), F(0)]), ('radiation a = eta at eta = 3', [F(3), F(1), F(0), F(0)]), ('phantom a = 1 + eta/10 + eta^2 at eta = 0', [F(1), F(1, 10), F(1), F(0)])):
        e, om, M, E, ia = conf_data(ac); vals = []; eos[nm] = (M[0][0], -M[1][1])
        for n_ in dirs:
            N0 = [F(1)] + list(n_); vals.append(ricci_NN(M, N0))                                   # R_NN for the null frame vector (1, n), |n| = 1
        nec[nm] = vals
    dust, rad, ph = nec['dust a = eta^2 at eta = 2'], nec['radiation a = eta at eta = 3'], nec['phantom a = 1 + eta/10 + eta^2 at eta = 0']
    if FAULT == 'phantom': dust = ph
    ed, er = eos['dust a = eta^2 at eta = 2'], eos['radiation a = eta at eta = 3']
    chk('bit', ed[1] == 0 and ed[0] > 0 and 3 * er[1] == er[0] > 0, 'the two frames are dust and radiation: kappa p = 0 with kappa rho = %s; kappa p = kappa rho/3 with kappa rho = %s (engine, E_a + kappa T_a = 0)' % (ed[0], er[0]))
    chk('bit', all(v > 0 for v in dust) and all(v == dust[0] for v in dust) and all(v > 0 for v in rad), 'NEC: R_NN = kappa T_NN > 0 at all 13 rational null directions for dust (a = eta^2, R_NN = %s for every direction: isotropic) and radiation (a = eta, R_NN = %s)' % (dust[0], rad[0]))
    chk('ctl', all(v < 0 for v in ph), 'a phantom frame (a = 1 + eta/10 + eta^2: kappa (rho + p) = 4a\'^2 - 2a a\'\' < 0 at eta = 0): R_NN = %s < 0 for every null direction, the focusing inequality fails' % ph[0])
    tick('part 4')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GSA-FRW' + ('-' + FAULT if FAULT else ''))

if __name__ == '__main__': main()
