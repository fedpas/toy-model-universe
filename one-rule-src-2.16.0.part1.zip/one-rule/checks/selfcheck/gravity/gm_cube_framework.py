#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-CUBE.  The n-cube bar framework in R^n: no self-stress and n 2^(n-1) - C(n+1,2) mechanisms, for every n.   python3 gm_cube_framework.py

 Joints {0,1}^n (V = 2^n), bars u -- u + e_k (E = n 2^(n-1)). Maxwell-Calladine: dim(mechanisms) - dim(self-stresses) = dV - E - C(d+1,2) (the trivial motions have dimension C(d+1,2)
 when the joints span R^d affinely).
 Argument for every n: the bar u -- u + e_k has direction e_k, so its row of the rigidity matrix involves only the k-th components of the two displacements; the matrix is block diagonal
 over k, and block k is the incidence matrix of the perfect matching {u, u + e_k}. The E x E minor on the columns (u, k) with u_k = 0 has one entry +-1 in each row and each column
 (a signed permutation matrix), so its determinant is +-1 and the rank is E: no self-stress, and mechanisms = n 2^n - n 2^(n-1) - C(n+1,2) = n 2^(n-1) - C(n+1,2).
 [bit]  n = 2..7: the integer rigidity matrix; the block structure and the perfect matchings; the minor (signed permutation, and its determinant modulo the prime 1000003: a rank modulo p
        never exceeds the rank over Q, and E is the largest possible); the full rank modulo p; the trivial motions from the engine's Lie table of Cl(0,n) (h: the rotation generators acting
        on vectors, compared with the bit-rule commutator) and the translations lie in the kernel and have rank C(n+1,2) (exact); a generic integer realisation of the graph (n = 3..5).
 [std]  numpy matrix_rank (SVD) of the same matrices; the counts n 2^(n-1) - C(n+1,2) = 1, 6, 22, 65, 171, 420; the Laman count in the plane (square: 4 bars < 2V - 3 = 5, one mechanism;
        square with one diagonal: 5 bars, rigid).
 Controls: one bar removed (one more mechanism, no self-stress); one joint moved onto its neighbour (a bar of length 0: rank E - 1, one self-stress, the index unchanged);
 n = 3 against the octahedron (6 joints, 12 bars: 0 mechanisms, 0 self-stresses).
 Scope: the unit n-cube for n = 2..7 (exact), generic realisations for n = 3..5, the planar Laman examples only."""
import os, sys, random, itertools
from math import comb
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np

PR = 1000003
def cube(n):
    V = 1 << n; P = [[(u >> i) & 1 for i in range(n)] for u in range(V)]
    bars = [(u, u | (1 << k), k) for k in range(n) for u in range(V) if not (u >> k) & 1]
    return P, bars
def rigidity(P, bars, n):
    V = len(P); M = np.zeros((len(bars), n * V), dtype=np.int64)
    for r, (u, v, *_) in enumerate(bars):
        for i in range(n):
            d = P[u][i] - P[v][i]; M[r, u * n + i] += d; M[r, v * n + i] -= d
    return M
def rank_mod_p(M, p=PR):
    A = (np.array(M, dtype=np.int64) % p).copy(); rows, cols = A.shape; r = 0
    for c in range(cols):
        if r == rows: break
        nz = np.nonzero(A[r:, c])[0]
        if len(nz) == 0: continue
        piv = r + nz[0]
        if piv != r: A[[r, piv]] = A[[piv, r]]
        A[r] = (A[r] * pow(int(A[r, c]), p - 2, p)) % p
        below = np.nonzero(A[r + 1:, c])[0] + r + 1
        if len(below): A[below] = (A[below] - np.outer(A[below, c], A[r])) % p
        r += 1
    return r
def det_mod_p(M, p=PR):
    A = (np.array(M, dtype=np.int64) % p).copy(); n = A.shape[0]; det = 1
    for c in range(n):
        nz = np.nonzero(A[c:, c])[0]
        if len(nz) == 0: return 0
        piv = c + nz[0]
        if piv != c: A[[c, piv]] = A[[piv, c]]; det = -det
        det = det * int(A[c, c]) % p; inv = pow(int(A[c, c]), p - 2, p)
        below = np.nonzero(A[c + 1:, c])[0] + c + 1
        if len(below): A[below] = (A[below] - np.outer(A[below, c] * inv % p, A[c])) % p
    return det % p
def rotation_generators(n):
    """the engine's h table of Cl(0,n) (all squares -1): W_A[c][b] = h with (1/2)[B_A, gamma_b] = h gamma_c; and the same from the bit-rule commutator"""
    L = Lie([-1] * n); W = []; Wb = []
    for A, g in enumerate(L.gens):
        M = [[F(0)] * n for _ in range(n)]
        for (A_, b), (c, h) in L.h.items():
            if A_ == A: M[c][b] += h
        W.append(M)
        Mb = [[F(0)] * n for _ in range(n)]
        for b in range(n):
            m1, s1 = bmul(g, 1 << b, [-1] * n); m2, s2 = bmul(1 << b, g, [-1] * n)
            if m1 == m2 and popc(m1) == 1 and s1 != s2: Mb[m1.bit_length() - 1][b] += F(s1 - s2, 2)
        Wb.append(Mb)
    return W, Wb
def trivial_motions(P, n, W):
    out = []
    for i in range(n): out.append([F(int(j == i)) for u in range(len(P)) for j in range(n)])
    for M in W: out.append([sum(M[c][b] * P[u][b] for b in range(n)) for u in range(len(P)) for c in range(n)])
    return out
def counts(M, n, V):
    rk = rank_mod_p(M); E = M.shape[0]; ker = n * V - rk
    return rk, E - rk, ker - comb(n + 1, 2)

def main():
    WANT = {n: n * 2 ** (n - 1) - comb(n + 1, 2) for n in range(2, 8)}
    head('(1) the unit n-cube, n = 2..7: block structure, the minor, the rank, the trivial motions [bit]; numpy ranks [std]')
    for n in range(2, 8):
        P, bars = cube(n); V = len(P); E = len(bars); M = rigidity(P, bars, n)
        blocks = all(len({c % n for c in np.nonzero(M[r])[0]}) == 1 and {c % n for c in np.nonzero(M[r])[0]} == {bars[r][2]} for r in range(E))
        match = all(sorted(x for (u, v, k_) in bars if k_ == k for x in (u, v)) == list(range(V)) for k in range(n))
        cols = [u * n + k for (u, v, k) in bars]; Mi = M[:, cols]
        perm = all(np.count_nonzero(Mi[r]) == 1 for r in range(E)) and all(np.count_nonzero(Mi[:, c]) == 1 for c in range(E)) and set(np.abs(Mi[Mi != 0]).tolist()) == {1}
        dm = det_mod_p(Mi); rk, ss, mech = counts(M, n, V)
        chk('bit', blocks and match and perm and dm != 0 and rk == E and ss == 0, 'n = %d: V = %d, E = %d; block diagonal over the axis, each block a perfect matching; the E x E minor on the columns (u, k), u_k = 0, is a signed permutation matrix (det = %s mod %d): rank E, no self-stress' % (n, V, E, dm if dm < PR // 2 else dm - PR, PR))
        W, Wb = rotation_generators(n); Tm = trivial_motions(P, n, W)
        hok = all(W[A] == Wb[A] for A in range(len(W)))
        inker = all(not any(sum(int(M[r, c]) * t[c] for c in np.nonzero(M[r])[0]) for r in range(E)) for t in Tm)
        rT = rank_exact(Tm)
        chk('bit', hok and inker and rT == comb(n + 1, 2) and mech == WANT[n], 'n = %d: the %d rotation generators (engine h table = bit-rule commutator) and %d translations are in the kernel, rank %d = C(n+1,2); mechanisms = %d = n 2^(n-1) - C(n+1,2)' % (n, len(W), n, rT, mech))
        rs = int(np.linalg.matrix_rank(M.astype(float)))
        chk('std', rs == E and n * V - rs - comb(n + 1, 2) == WANT[n] and (n * V - rs - comb(n + 1, 2)) - (E - rs) == n * V - E - comb(n + 1, 2), 'n = %d: numpy rank %d; mechanisms %d, self-stresses %d; Maxwell-Calladine index %d = dV - E - C(d+1,2)' % (n, rs, n * V - rs - comb(n + 1, 2), E - rs, n * V - E - comb(n + 1, 2)))
    chk('bit==std', [WANT[n] for n in range(2, 8)] == [1, 6, 22, 65, 171, 420], 'the counts 1, 6, 22, 65 (n = 2..5, as bd.sol.19) and 171, 420 (n = 6, 7)')
    head('(2) generic realisations of the n-cube graph (random integer joints), n = 3..5 [bit] [std]')
    rng = random.Random(35)
    for n in (3, 4, 5):
        P, bars = cube(n); Pg = [[3 * x + rng.randint(-2, 2) for x in row] for row in P]; M = rigidity(Pg, bars, n); rk, ss, mech = counts(M, n, len(P))
        chk('bit', rk == len(bars) and ss == 0 and mech == WANT[n], 'n = %d: random integer realisation: rank %d = E, mechanisms %d (the unit cube is not special for this count)' % (n, rk, mech))
        chk('std', int(np.linalg.matrix_rank(M.astype(float))) == rk, 'n = %d: numpy rank of the generic realisation = %d' % (n, rk))
    head('(3) Laman in the plane [std] [bit]')
    P, bars = cube(2); M = rigidity(P, bars, 2); rs = int(np.linalg.matrix_rank(M.astype(float)))
    chk('std', len(bars) == 4 < 2 * 4 - 3 and 2 * 4 - rs - 3 == 1, 'the square: 4 bars < 2V - 3 = 5, numpy rank %d, one mechanism' % rs)
    Pb = [list(p) for p in P]; barsb = bars + [(0, 3, None)]; Mb = rigidity(Pb, barsb, 2); rsb = int(np.linalg.matrix_rank(Mb.astype(float))); rkb = rank_mod_p(Mb)
    lam = all(sum(1 for (u, v, *_) in barsb if u in S_ and v in S_) <= 2 * len(S_) - 3 for k in range(2, 5) for S_ in itertools.combinations(range(4), k))
    chk('std', len(barsb) == 5 == 2 * 4 - 3 and lam and rsb == 5 == rkb, 'the square with one diagonal: 5 bars = 2V - 3, every k-subset spans <= 2k - 3 bars (Laman), rank 5 (numpy and mod p): rigid')
    head('(4) controls')
    for n in (3, 4, 5):
        P, bars = cube(n); V = len(P); E = len(bars)
        M1 = rigidity(P, bars[1:], n); rk1, ss1, mech1 = counts(M1, n, V)
        chk('ctl', ss1 == 0 and mech1 == WANT[n] + 1, 'n = %d: one bar removed: rank %d = E - 1, no self-stress, %d mechanisms (one more)' % (n, rk1, mech1))
        Pm = [list(p) for p in P]; Pm[1] = list(Pm[0]); M2 = rigidity(Pm, bars, n); rk2, ss2, mech2 = counts(M2, n, V)
        rT2 = rank_exact(trivial_motions(Pm, n, rotation_generators(n)[0]))
        chk('ctl', rk2 == E - 1 and ss2 == 1 and rT2 == comb(n + 1, 2) and mech2 - ss2 == WANT[n], 'n = %d: joint 1 moved onto joint 0 (bar of length 0): rank %d = E - 1, one self-stress, %d mechanisms; the index mechanisms - self-stresses = %d is unchanged' % (n, rk2, mech2, mech2 - ss2))
    Po = [[(1 if i == k else 0) * s for i in range(3)] for k in range(3) for s in (1, -1)]
    baro = [(u, v) for u in range(6) for v in range(u + 1, 6) if not (u // 2 == v // 2)]
    Mo = rigidity(Po, baro, 3); rko, sso, mecho = counts(Mo, 3, 6)
    chk('ctl', len(baro) == 12 and rko == 12 and sso == 0 and mecho == 0 and WANT[3] == 6, 'n = 3: the octahedron (6 joints, 12 bars) is rigid (rank 12, 0 mechanisms, 0 self-stresses) while the 3-cube has 6 mechanisms')
    print('\n  reading: for every n the cube framework splits into n perfect matchings (one per axis), so the minor of the bars against the lower-endpoint columns is a signed permutation:'
          '\n  rank E, no self-stress, n 2^(n-1) - C(n+1,2) mechanisms. The exact runs n = 2..7 and the generic realisations n = 3..5 agree with numpy.')

if __name__ == '__main__':
    main(); finish('GM-CUBE')
