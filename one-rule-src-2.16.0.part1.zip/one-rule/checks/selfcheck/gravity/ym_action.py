#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""YM-ACTION.  The Yang-Mills action of so(m) on the bit rule: first variation, conservation of the source, size and sign of the coupling.   python3 ym_action.py

 Algebra   Lie([-1]*m): the bivectors B_A of Cl(0,m), [B_A, B_B] = f_AB^C B_C from the bit product; K_AB = <B_A B_B>_0 (scalar part) = -1 on the diagonal.
 Engine    F = curvature(A) = dA + (1/4) f A ^ A,  D Y = D_bivector(A, Y) = dY + (1/2) f A ^ Y  (the component form with g = 1/2); for a coupling g of
           D = d + g A^a B_a the engine objects are used with 2 g A:  F_g = curvature(2gA)/(2g),  D_g = D_bivector(2gA, .)  (the commutator term of F is the same g).
 Action    L = c_k K_AB F^A ^ *F^B + c_s K_AB A^A ^ *J^B  (bit-rule star of g2_hodge on the flat frame e = dx, eps_0123 = +1).
 Claim A   delta L = dA^B ^ E_B + d(2 c_k K dA ^ *F),  E_B = K_BC (2 c_k (D*F)^C + c_s *J^C): an exact polynomial identity for random polynomial fields,
           m = 2, 3, 4, signature (+,-,-,-) (and (+,+,+,+) at m = 3); the brief's constants c_k = -1/2, c_s = -1 give E = D*F + *J, i.e. D^mu F_mu nu = J_nu.
           L(A + eps dA) has degree 4 in eps for m >= 3 (degree 2 only at m = 2).  The topological term K F ^ F has E = 0 and equals d(CS).
 Claim B   D(D*F) = (1/2) f F ^ *F = 0 (so the source is covariantly conserved);  A -> A + D(phi): E -> E + (1/2)[E, phi] at first order.
 Claim C   L = (1/2) K F_g ^ *F_g + L_D (positive-energy sign of the Yang-Mills term), L_D = Sum_T <(E_psi gamma_0)_T Psi~_T>_0 vol (matter_selfcheck's Psi, D and E):
           the A-equation is D*F = g *j, i.e. D^mu F_mu nu = kappa j_nu with kappa/g = -1 for matter_selfcheck's current j^a; the conjugate-field equation is E_psi = 0;
           flipping the interaction term flips the source and the potential term together.
 [bit]   the engine's Forms, Lie, Grav (d, wedge, curvature, D_bivector), g2_hodge's bit-rule star; the eps^1 coefficient by Lagrange interpolation on eps = 0..5
         (b1_first_variation.vander_weights) and by a parameter slot (slot 4 of the polynomials, b1lib.trunc).
 [std]   no engine: so(m) as antisymmetric integer matrices E_ij (numpy commutators), components F^c_mn, L_std = -(1/4) F.F - A.J, the textbook first variation as a polynomial
         identity (b1lib's sp_* helpers), the textbook star; a float Euler-Lagrange expression from complex steps and five-point differences; exact differences of the Dirac density.
 [ctl]   wrong source sign, -K in place of K, the quadratic term of F with 1/2 in place of 1/4, a non-Lie table, the wrong sign of the surface term, the interaction flipped alone.
 Exports (no engine object at import): ym_K, star0, curv_g, D_g, L_ym, E_ym, theta_ym, eps_coeffs, rp, rform1, dirac_density, current_poly, jflat, lam1."""
import os, sys, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import g2_hodge as H
import b3_matter as B3
from b1_first_variation import vander_weights
import matter_selfcheck as MS                                                  # selfcheck/ is on the path (b1lib); pure functions, no run at import
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
n = 4; NV = 5; FULL = 15; LOR = [1, -1, -1, -1]; EUC = [1, 1, 1, 1]
LAMV = {(0, 0, 0, 0, 1): F(1)}

# ------------------------------------------------------------------------------------------------ fields and helpers
def rp(rng, deg, lo=-9, hi=9):
    """strong sampler: every monomial of x-degree <= deg in x^0..x^3, integer coefficient uniform in [lo, hi] (zeros left out); slot 4 (lam) exponent 0"""
    out = {}
    for ex in itertools.product(range(deg + 1), repeat=4):
        if sum(ex) <= deg:
            c = rng.randint(lo, hi)
            if c: out[ex + (0,)] = F(c)
    return out
def rform1(rng, deg):
    return {1 << mu: p for mu in range(4) for p in [rp(rng, deg)] if p}
def lam1(p): return B3.lam_part(p, n, 1)
def lam1_form(X): return {m: q for m, q in ((m, lam1(p)) for m, p in X.items()) if q}
def is0(X): return all(not p for p in X.values())
def eqf(X, Y):
    a = {m: p for m, p in X.items() if p}; b = {m: p for m, p in Y.items() if p}
    return a == b
def lsum(Fm, terms):
    r = {}
    for c, X in terms: r = Fm.add(r, X, c)
    return r

def ym_K(Lie_):
    """K_AB = <B_A B_B>_0 from the bit product (exact)"""
    G = Lie_.G; K = [[F(0)] * G for _ in range(G)]
    for A, ga in enumerate(Lie_.gens):
        for B, gb in enumerate(Lie_.gens):
            mk, s = bmul(ga, gb, Lie_.sq)
            if mk == 0: K[A][B] = F(s)
    return K
def star0(X, sq, route='bit'):
    """Hodge star on the flat frame e = dx (frame components = coordinate components): g2_hodge.star_comps"""
    return {m: p for m, p in H.star_comps(X, sq, route).items() if p}
def curv_g(Gv, A, g=F(1, 2)):
    """F_g = dA + (g/2) f A ^ A  (= the engine's curvature at g = 1/2)"""
    if g == F(1, 2): return Gv.curvature(A)
    R = Gv.curvature([Gv.Fm.scale(a, 2 * g) for a in A]); return [Gv.Fm.scale(r, 1 / (2 * g)) for r in R]
def D_g(Gv, A, Y, g=F(1, 2)):
    return Gv.D_bivector(A if g == F(1, 2) else [Gv.Fm.scale(a, 2 * g) for a in A], Y)
def L_ym(Gv, A, J, K, sq, ck, cs, g=F(1, 2), kind='ym', Fc=None):
    Fm = Gv.Fm; G = Gv.G; Fc = Fc if Fc is not None else curv_g(Gv, A, g); out = {}
    for P in range(G):
        for Q in range(G):
            if not K[P][Q]: continue
            if kind == 'top': out = Fm.add(out, Fm.wedge(Fc[P], Fc[Q]), K[P][Q]); continue
            out = Fm.add(out, Fm.wedge(Fc[P], star0(Fc[Q], sq)), ck * K[P][Q])
            if J is not None and cs: out = Fm.add(out, Fm.wedge(A[P], star0(J[Q], sq)), cs * K[P][Q])
    return out
def E_ym(Gv, A, J, K, sq, ck, cs, g=F(1, 2), Fc=None):
    """E_B = K_BC (2 c_k (D*F)^C + c_s *J^C)  (3-forms);  returns (E, D*F, *F)"""
    Fm = Gv.Fm; G = Gv.G; Fc = Fc if Fc is not None else curv_g(Gv, A, g); SF = [star0(x, sq) for x in Fc]; DSF = D_g(Gv, A, SF, g)
    SJ = [star0(x, sq) for x in J] if J is not None else [{} for _ in range(G)]
    E = [lsum(Fm, [(K[B][C] * 2 * ck, DSF[C]) for C in range(G) if K[B][C]] + [(K[B][C] * cs, SJ[C]) for C in range(G) if K[B][C] and cs]) for B in range(G)]
    return E, DSF, SF
def theta_ym(Gv, a, SF, K, ck):
    Fm = Gv.Fm; G = Gv.G; return lsum(Fm, [(2 * ck * K[C][D], Fm.wedge(a[C], SF[D])) for C in range(G) for D in range(G) if K[C][D]])
def eps_coeffs(Fm, Lfun, A, a, nodes=6):
    """coefficients of eps^0 .. eps^(nodes-1) of L(A + eps a) from the values at eps = 0 .. nodes-1 (exact Vandermonde weights)"""
    Vi = vander_weights(nodes); vals = [Lfun([Fm.add(A[C], a[C], j) for C in range(len(A))]) for j in range(nodes)]
    return [lsum(Fm, [(Vi[k][j], vals[j]) for j in range(nodes)]) for k in range(nodes)]
def bracket_forms(Gv, X, Y, c):
    """c f_PQ^C X^P ^ Y^Q"""
    out = [{} for _ in range(Gv.G)]
    for (P, Q), (C, f) in Gv.L.f.items():
        if X[P] and Y[Q]: out[C] = Gv.Fm.add(out[C], Gv.Fm.wedge(X[P], Y[Q]), c * f)
    return out

# ------------------------------------------------------------------------------------------------ the Dirac term (matter_selfcheck's field, D and E; polynomial entries)
def wS(S, sq): return gs.rsign(popc(S)) * bmul(S, S, sq)[1]                    # <e_S e_S~>_0 = +-1
def pairing(X, Phi, sq):
    """Sum_T <X_T Phi~_T>_0 for even X, Phi: Sum_{S,T} w_S X_{S,T} Phi_{S,T}  (polynomial)"""
    out = {}
    for k, p in X.items():
        q = Phi.get(k)
        if p and q: out = padd(out, MS.pmul(p, q), wS(k[0], sq))
    return out
def acomp(A): return [[A[a].get(1 << mu, {}) for a in range(len(A))] for mu in range(4)]
def dirac_density(Y, A, Psi, Phi=None):
    """L_D = Sum_T <(E(Psi) gamma_0)_T Phi~_T>_0,  Phi = Psi by default (Hestenes' Lagrangian with D at A = 0);  E = matter_selfcheck.Eop"""
    E = MS.Eop(Y, acomp(A), Psi); return pairing(Y.r0(E), Psi if Phi is None else Phi, Y.sq), E
def current_poly(Y, Phi, Psi, a, nu):
    """matter_selfcheck's Bnu with polynomial entries: Sum_T < Phi~_T gamma^nu (B_a Psi)_T gamma_0 J >_0"""
    La = Y.lmul(a, Psi); tot = {}
    for (S, T), v in Phi.items():
        for (S2, T2), w in La.items():
            if T != T2 or not v or not w: continue
            mk, s = MS.prod([S, 1 << nu, S2, 1, Y.Jm], Y.sq)
            if mk == 0: tot = padd(tot, MS.pmul(v, w), s * (-1) * gs.rsign(popc(S)) * Y.sq[nu])
    return tot
def jflat(Y, Psi, sq):
    """the 1-forms j_flat^a = Sum_nu eta_nu nu j^(a nu) dx^nu"""
    return [{1 << nu: p for nu in range(4) for p in [scale(current_poly(Y, Psi, Psi, a, nu), sq[nu])] if p} for a in range(Y.G)]

# ------------------------------------------------------------------------------------------------ [std] matrices and components (no engine)
def std_algebra(m):
    pairs = [(i, j) for i in range(m) for j in range(i + 1, m)]
    T = []
    for (i, j) in pairs:
        M = np.zeros((m, m), dtype=np.int64); M[i, j] = 1; M[j, i] = -1; T.append(M)
    c = {}
    for a in range(len(T)):
        for b in range(len(T)):
            Cm = T[a] @ T[b] - T[b] @ T[a]
            for cc, (i, j) in enumerate(pairs):
                if Cm[i, j]: c[(a, b, cc)] = int(Cm[i, j])
            rebuilt = sum((c.get((a, b, cc), 0) * T[cc] for cc in range(len(T))), np.zeros((m, m), dtype=np.int64))
            assert (rebuilt == Cm).all()
    metric = [[-F(int(np.trace(T[a] @ T[b])), 2) for b in range(len(T))] for a in range(len(T))]
    return pairs, T, c, metric
BIG = 99
def s_mul(a, b): return sp_mul(a, b, BIG, n)
def std_F(Acs, c, gs_, G):
    """F^c_mn = d_m A^c_n - d_n A^c_m + g c_ab^c A^a_m A^b_n,  Acs[c][mu] polynomials"""
    Fs = {}
    for C in range(G):
        for mu in range(4):
            for nu in range(4):
                t = sp_add(sp_der(Acs[C][nu], mu), sp_der(Acs[C][mu], nu), -1)
                for (a, b, cc), v in c.items():
                    if cc == C and Acs[a][mu] and Acs[b][nu]: t = sp_add(t, s_mul(Acs[a][mu], Acs[b][nu]), gs_ * v)
                Fs[(C, mu, nu)] = t
    return Fs
def std_L(Acs, Jcs, c, gs_, G, sq):
    Fs = std_F(Acs, c, gs_, G); L = {}
    for C in range(G):
        for mu in range(4):
            for nu in range(4):
                if Fs[(C, mu, nu)]: L = sp_add(L, s_mul(Fs[(C, mu, nu)], Fs[(C, mu, nu)]), F(-1, 4) * sq[mu] * sq[nu])
            if Jcs is not None and Acs[C][mu] and Jcs[C][mu]: L = sp_add(L, s_mul(Acs[C][mu], Jcs[C][mu]), -sq[mu])
    return L, Fs
def std_EL(Acs, Jcs, Fs, c, gs_, G, sq):
    """EL^(c n) = (D_m F^mn)^c - J^(c n),  F^mn = eta^mm eta^nn F_mn;  also (D_m F^mn)^c alone"""
    Fu = {k: scale(p, sq[k[1]] * sq[k[2]]) for k, p in Fs.items()}; DF = {}; EL = {}
    for C in range(G):
        for nu in range(4):
            t = {}
            for mu in range(4):
                t = sp_add(t, sp_der(Fu[(C, mu, nu)], mu))
                for (a, b, cc), v in c.items():
                    if cc == C and Acs[a][mu] and Fu[(b, mu, nu)]: t = sp_add(t, s_mul(Acs[a][mu], Fu[(b, mu, nu)]), gs_ * v)
            DF[(C, nu)] = t
            EL[(C, nu)] = sp_add(t, scale(Jcs[C][nu], sq[nu]), -1) if Jcs is not None and Jcs[C][nu] else t
    return EL, DF, Fu
def peval(p, x): return sum(float(v) * float(np.prod([x[i] ** k[i] for i in range(4)])) for k, v in p.items())

# ================================================================================================ the run
def part_A(m, seeds, sq, rows, heavy):
    Lie_ = Lie([-1] * m); Gv = Grav(4, Lie_); Fm = Gv.Fm; G = Gv.G; K = ym_K(Lie_); ck, cs = F(-1, 2), F(-1)
    tag = 'm=%d %s' % (m, 'Lorentz' if sq == LOR else 'Euclid')
    inv = all(sum(f * K[C][Dd] for (A2, B2), (C, f) in Lie_.f.items() if A2 == A_ and B2 == B_) + sum(f * K[C][B_] for (A2, D2), (C, f) in Lie_.f.items() if A2 == A_ and D2 == Dd) == 0
              for A_ in range(G) for B_ in range(G) for Dd in range(G))
    res = dict(inv=inv, K=K, deg_ok=True, id_ok=True, slot_ok=True, e3=set(), nz=True, top_ok=True, bianchi=True, cs_ok=True, ctl_src=True, ctl_K=True, ctl_quad=True, ctl_th=True)
    for seed in seeds:
        rng = random.Random(1000 * m + seed + (0 if sq == LOR else 77))
        A = [rform1(rng, 2) for _ in range(G)]; a = [rform1(rng, 2) for _ in range(G)]; J = [rform1(rng, 1) for _ in range(G)]
        Lf = lambda AA: L_ym(Gv, AA, J, K, sq, ck, cs)
        co = eps_coeffs(Fm, Lf, A, a); res['deg_ok'] &= is0(co[5]); res['e3'].add(not is0(co[3]))
        E, DSF, SF = E_ym(Gv, A, J, K, sq, ck, cs); Th = theta_ym(Gv, a, SF, K, ck)
        rhs = Fm.add(lsum(Fm, [(1, Fm.wedge(a[B], E[B])) for B in range(G)]), Fm.d(Th))
        res['id_ok'] &= eqf(co[1], rhs); res['nz'] &= not is0(co[1]) and any(not is0(x) for x in E)
        first = heavy and seed == seeds[0]                                     # the second route and the heavier controls: first field of the m = 2, 3 Lorentz cases
        if first:
            with trunc(4, lam=1): Ls = Lf([Fm.add(A[C], Fm.wedge({0: LAMV}, a[C])) for C in range(G)])
            res['slot_ok'] &= eqf(lam1_form(Ls), co[1])
        # topological term, Bianchi, Chern-Simons
        Fc = Gv.curvature(A)
        if first:
            ct = eps_coeffs(Fm, lambda AA: L_ym(Gv, AA, None, K, sq, 0, 0, kind='top'), A, a)
            res['top_ok'] &= eqf(ct[1], Fm.d(lsum(Fm, [(2 * K[P][Q], Fm.wedge(a[P], Fc[Q])) for P in range(G) for Q in range(G) if K[P][Q]]))) and not is0(ct[1])
        res['bianchi'] &= all(is0(x) for x in Gv.D_bivector(A, Fc))
        CS = lsum(Fm, [(K[P][Q], Fm.wedge(A[P], Fm.d(A[Q]))) for P in range(G) for Q in range(G) if K[P][Q]])
        for (P, Q), (Dd, f) in Lie_.f.items():
            for C in range(G):
                if K[Dd][C]: CS = Fm.add(CS, Fm.wedge(Fm.wedge(A[P], A[Q]), A[C]), F(f, 6) * K[Dd][C])
        res['cs_ok'] &= eqf(Fm.d(CS), L_ym(Gv, A, None, K, sq, 0, 0, kind='top')) and not is0(CS)
        # controls
        Eb, _, _ = E_ym(Gv, A, J, K, sq, ck, -cs); res['ctl_src'] &= not eqf(co[1], Fm.add(lsum(Fm, [(1, Fm.wedge(a[B], Eb[B])) for B in range(G)]), Fm.d(Th)))
        mK = [[-x for x in r] for r in K]; EmK, _, SFm = E_ym(Gv, A, J, mK, sq, ck, cs)
        res['ctl_K'] &= not eqf(co[1], Fm.add(lsum(Fm, [(1, Fm.wedge(a[B], EmK[B])) for B in range(G)]), Fm.d(theta_ym(Gv, a, SFm, mK, ck))))
        res['ctl_th'] &= not eqf(co[1], Fm.add(lsum(Fm, [(1, Fm.wedge(a[B], E[B])) for B in range(G)]), Fm.d(Th), -1))
        if m >= 3 and first:
            def Fbad(AA):
                R = [Fm.d(x) for x in AA]
                for (P, Q), (C, f) in Lie_.f.items(): R[C] = Fm.add(R[C], Fm.wedge(AA[P], AA[Q]), F(f, 2))
                return R
            cb = eps_coeffs(Fm, lambda AA: L_ym(Gv, AA, J, K, sq, ck, cs, Fc=Fbad(AA)), A, a)
            Ebd, _, SFb = E_ym(Gv, A, J, K, sq, ck, cs, Fc=Fbad(A))
            res['ctl_quad'] &= not eqf(cb[1], Fm.add(lsum(Fm, [(1, Fm.wedge(a[B], Ebd[B])) for B in range(G)]), Fm.d(theta_ym(Gv, a, SFb, K, ck))))
        rows.append((m, sq, seed, A, a, J, E, DSF, co, Gv, K))
    return res, tag

def main():
    rows = []
    # ------------------------------------------------------------------ A
    head('A. the first variation of L = -(1/2) K F ^ *F - K A ^ *J (brief\'s constants), exact polynomial identity on random fields (A, dA of degree 2, J of degree 1, coefficients in -9..9)')
    for (m, seeds, sq, heavy) in ((2, [1, 2], LOR, True), (3, [1, 2], LOR, True), (4, [1], LOR, False), (3, [3], EUC, False)):
        r, tag = part_A(m, seeds, sq, rows, heavy)
        if sq == LOR: chk('bit', r['inv'] and all(r['K'][i][j] == (-1 if i == j else 0) for i in range(len(r['K'])) for j in range(len(r['K']))), '%s: K_AB = <B_A B_B>_0 = -delta_AB (negative definite) and invariant: f_AB^C K_CD + f_AD^C K_CB = 0 for all A, B, D (engine f)' % tag)
        chk('bit', r['deg_ok'] and (r['e3'] == ({True} if m >= 3 else {False})), '%s: L(A + eps dA) has degree <= 4 in eps (eps^5 coefficient = 0 from the nodes 0..5); eps^3 coefficient %s (the quadratic term (1/4) f dA ^ dA of F(A + eps dA))' % (tag, 'non-zero: degree 4, not 2' if m >= 3 else 'zero: F is linear in A at m = 2, degree 2'))
        chk('bit', r['id_ok'] and r['nz'], '%s, %d field(s): delta L = dA^B ^ E_B + d(2 c_k K_CD dA^C ^ *F^D), E_B = K_BC (2 c_k (D*F)^C + c_s *J^C), on every polynomial coefficient (D*F = D_bivector(A, *F)); with c_k = -1/2, c_s = -1, K = -1: E = D*F + *J' % (tag, len(seeds)))
        if heavy: chk('bit', r['slot_ok'], '%s: the same first variation read from the parameter slot (lam^1 part of L(A + lam dA), b1lib.trunc lam = 1) equals the interpolated eps^1 coefficient' % tag)
        chk('bit', r['top_ok'] and r['bianchi'] and r['cs_ok'], '%s: topological term K F ^ F: D F = 0 (Bianchi) and K F ^ F = d(K A ^ dA + (1/6) f K A ^ A ^ A)%s' % (tag, ', and its first variation is d(2 K dA ^ F) exactly (Euler-Lagrange form 0)' if heavy else ''))
        chk('ctl', r['ctl_src'], '%s: control: the source term with the wrong sign in E fails the identity' % tag)
        chk('ctl', r['ctl_K'], '%s: control: E and the surface term built with -K in place of K (the wrong sign of the kinetic and source terms: E flips) fail the identity' % tag)
        chk('ctl', r['ctl_th'], '%s: control: the surface term with the wrong sign fails' % tag)
        if m >= 3 and heavy: chk('ctl', r['ctl_quad'], '%s: control: F = dA + (1/2) f A ^ A (the quadratic term doubled, as the engine fault M1) with D_bivector kept: the identity fails' % tag)
        tick('A m=%d' % m)
    # m = 2 against b3_matter
    m2 = [r for r in rows if r[0] == 2][0]; _, sq, _, A, a, J, E, DSF, co, Gv, K = m2; Fm = Gv.Fm
    e = [{1 << mu: const(NV, 1)} for mu in range(4)]; Ein = [[const(NV, 1) if mu == b else {} for b in range(4)] for mu in range(4)]
    Fc = Gv.curvature(A)[0]; Lp = L_ym(Gv, A, None, K, sq, F(1, 2), 0); Lb = L_ym(Gv, A, None, K, sq, F(-1, 2), 0)
    Ep, _, _ = E_ym(Gv, A, None, K, sq, F(1, 2), 0)
    ok_b3 = eqf(Lp, B3.L_maxwell(Gv, e, Ein, Fc, 1, sq, NV)) and eqf(Lb, B3.L_maxwell(Gv, e, Ein, Fc, -1, sq, NV)) and eqf(Ep[0], B3.EL_maxwell(Gv, e, Ein, Fc, 1, sq, NV)) and not is0(Ep[0])
    chk('bit', ok_b3, 'm = 2: +(1/2) K F ^ *F is b3_matter\'s L_maxwell(sA = +1) (the positive-energy sign) and its E is b3_matter\'s EL_maxwell = -d*F exactly; the brief\'s -(1/2) K F ^ *F is L_maxwell(sA = -1)')

    # ------------------------------------------------------------------ A [std]
    head('A [std]. so(m) as antisymmetric matrices (numpy), textbook components, no engine')
    ok_lam = True; ok_F = True; ok_L = True; ok_E = True; ok_tid = True; sig = set(); lams = set()
    for (m, sq_, seed, A, a, J, E, DSF, co, Gv, K) in rows:
        G = Gv.G; pairs, T, c, metric = std_algebra(m)
        lam = None; okl = True
        for (P, Q), (C, f) in Gv.L.f.items():
            v = c.get((P, Q, C), 0)
            if v == 0: okl = False; continue
            lam = F(f, v) if lam is None else lam; okl &= F(f, v) == lam
        okl &= sum(1 for (P, Q, C) in c) == len(Gv.L.f) and all(metric[i][j] == (1 if i == j else 0) for i in range(G) for j in range(G))
        ok_lam &= okl
        if lam is not None: lams.add(lam)
        gs_ = (lam / 2) if lam is not None else F(0)
        Acs = [[A[C].get(1 << mu, {}) for mu in range(4)] for C in range(G)]; Jcs = [[J[C].get(1 << mu, {}) for mu in range(4)] for C in range(G)]
        acs = [[a[C].get(1 << mu, {}) for mu in range(4)] for C in range(G)]
        Ls, Fs = std_L(Acs, Jcs, c, gs_, G, sq_)
        Fb = Gv.curvature(A)
        ok_F &= all(Fb[C].get((1 << mu) | (1 << nu), {}) == Fs[(C, mu, nu)] for C in range(G) for mu in range(4) for nu in range(mu + 1, 4))
        Lbit = L_ym(Gv, A, J, K, sq_, F(-1, 2), F(-1)); ok_L &= (Lbit.get(FULL, {}) == scale(Ls, -1)) and bool(Ls)
        EL, DF, Fu = std_EL(Acs, Jcs, Fs, c, gs_, G, sq_)
        for B in range(G):
            Xl = {1 << nu: scale(EL[(B, nu)], -sq_[nu]) for nu in range(4) if EL[(B, nu)]}
            ok_E &= eqf(E[B], star0(Xl, sq_, 'std'))
            DFl = {1 << nu: scale(DF[(B, nu)], sq_[nu]) for nu in range(4) if DF[(B, nu)]}; St = star0(DFl, sq_, 'std')
            for mk in set(St) | set(DSF[B]):
                p, q = DSF[B].get(mk, {}), St.get(mk, {})
                if q:
                    k0 = next(iter(q)); s_ = p.get(k0, F(0)) / q[k0]; sig.add(s_) if p == scale(q, s_) else sig.add(None)
                elif p: sig.add(None)
        # textbook first variation as a polynomial identity: lam slot in the std polynomials (m <= 3)
        if m > 3: continue
        Al = [[sp_add(Acs[C][mu], s_mul(LAMV, acs[C][mu])) for mu in range(4)] for C in range(G)]
        Ll, _ = std_L(Al, Jcs, c, gs_, G, sq_); dL = lam1(Ll)
        div = {}
        for nu in range(4):
            for mu in range(4):
                t = {}
                for C in range(G):
                    if Fu[(C, mu, nu)] and acs[C][nu]: t = sp_add(t, s_mul(Fu[(C, mu, nu)], acs[C][nu]), -1)
                div = sp_add(div, sp_der(t, mu))
        rhs = dict(div)
        for C in range(G):
            for nu in range(4):
                if acs[C][nu] and EL[(C, nu)]: rhs = sp_add(rhs, s_mul(acs[C][nu], EL[(C, nu)]))
        ok_tid &= (dL == rhs) and bool(dL)
    chk('std', ok_lam and lams == {F(-2)}, 'the bit-rule structure constants are f = lambda c with ONE lambda = %s for m = 2, 3, 4 (c from numpy commutators of E_ij, the metric -(1/2) tr(E_a E_b) = delta): the engine\'s F is the textbook F with g = lambda/2 = -1 on the basis E_ij' % sorted(lams, key=str))
    chk('std', ok_tid, 'textbook first variation as a polynomial identity: delta L_std = d_m(-F^(c mn) a^c_n) + a^c_n ((D_m F^mn)^c - J^(c n)), L_std = -(1/4) F.F - A.J, the m = 2, 3 samples (lam slot of the plain polynomials)')
    chk('bit==std', ok_F, 'the engine\'s F = curvature(A) equals the component F^c_mn = d_m A_n - d_n A_m + g c A_m A_n (g = -1, basis E_ij) on every coefficient, all samples')
    chk('bit==std', ok_L, 'the brief\'s L = -(1/2) K F ^ *F - K A ^ *J equals -L_std vol exactly (both signatures run): the brief\'s action is the textbook action with the opposite overall sign')
    chk('bit==std', ok_E, 'the engine\'s E_B = -*(EL_std lowered) with the textbook star (g2_hodge route std), every coefficient, all samples: the same Euler-Lagrange equation')
    chk('bit==std', sig == {F(-1)}, 'D*F (engine) = sigma *(D^mu F_mu nu dx^nu) (textbook) with ONE sigma = %s in both signatures: E = D*F + *J = 0 is D^mu F_mu nu = J_nu' % sorted(sig, key=str))
    # float second look: complex step + five-point differences
    m, sq_, seed, A, a, J, E, DSF, co, Gv, K = [r for r in rows if r[0] == 3 and r[1] == LOR][0]; G = Gv.G; pairs, T, c, metric = std_algebra(3); gs_ = -1.0
    Acs = [[A[C].get(1 << mu, {}) for mu in range(4)] for C in range(G)]; Jcs = [[J[C].get(1 << mu, {}) for mu in range(4)] for C in range(G)]
    Ls, Fs = std_L(Acs, Jcs, c, F(-1), G, sq_); EL, _, _ = std_EL(Acs, Jcs, Fs, c, F(-1), G, sq_)
    dA = [[[sp_der(Acs[C][nu], mu) for nu in range(4)] for mu in range(4)] for C in range(G)]
    eta = np.array(sq_, dtype=float); cl = list(c.items())
    def ell(Av, dAv, Jv):
        Fv = dAv - np.transpose(dAv, (0, 2, 1))
        for (aa, bb, cc), v in cl: Fv[cc] = Fv[cc] + gs_ * v * np.outer(Av[aa], Av[bb])
        return -0.25 * np.einsum('cmn,m,n,cmn->', Fv, eta, eta, Fv) - np.einsum('cm,m,cm->', Av, eta, Jv)
    def vec(polys):
        out = []
        for p in polys:
            Km = np.array([k[:4] for k in p], dtype=float).reshape(len(p), 4); out.append((Km, np.array([float(v) for v in p.values()])))
        return out
    VA = vec([Acs[C][mu] for C in range(G) for mu in range(4)]); VD = vec([dA[C][mu][nu] for C in range(G) for mu in range(4) for nu in range(4)]); VJ = vec([Jcs[C][mu] for C in range(G) for mu in range(4)])
    ev_ = lambda V, x: np.array([float(np.prod(x ** Km, axis=1) @ v) if len(v) else 0.0 for Km, v in V], dtype=complex)
    def fields(x): return ev_(VA, x).reshape(G, 4), ev_(VD, x).reshape(G, 4, 4), ev_(VJ, x).reshape(G, 4)
    hh = 1e-20; worst = 0.0
    for x0 in (np.array([0.3, -0.2, 0.5, 0.1]), np.array([-0.4, 0.25, 0.1, -0.3]), np.array([0.15, 0.35, -0.45, 0.2])):
        Av, dAv, Jv = fields(x0)
        for C in range(G):
            for nu in range(4):
                Ap = Av.copy(); Ap[C, nu] += 1j * hh; dl_dA = ell(Ap, dAv, Jv).imag / hh
                div = 0.0
                for mu in range(4):
                    def g_(y):
                        Ay, dAy, Jy = fields(y); dAy[C, mu, nu] += 1j * hh; return ell(Ay, dAy, Jy).imag / hh
                    u = np.zeros(4); u[mu] = 1e-3
                    div += (-g_(x0 + 2 * u) + 8 * g_(x0 + u) - 8 * g_(x0 - u) + g_(x0 - 2 * u)) / (12e-3)
                num = dl_dA - div; ex = peval(EL[(C, nu)], x0)
                worst = max(worst, abs(num - ex) / max(1.0, abs(ex)))
    chk('std', worst < 1e-6, 'floats, m = 3: the Euler-Lagrange expression dl/dA^c_n - d_m dl/d(d_m A^c_n) of the density (complex step 1e-20 in the field values, five-point differences in x) equals the textbook (D_m F^mn)^c - J^(c n) at 3 points x 12 components: worst relative deviation %.1e' % worst)
    tick('A std')

    # ------------------------------------------------------------------ B
    head('B. conservation of the source and covariance of E (engine D_bivector)')
    ok_r = True; ok_z = True; ok_nc = True; ok_cov = True; ok_cov_bad = True
    for (m, sq_, seed, A, a, J, E, DSF, co, Gv, K) in rows:
        if sq_ != LOR: continue
        Fm = Gv.Fm; G = Gv.G; Fc = Gv.curvature(A); SF = [star0(x, sq_) for x in Fc]
        DD = Gv.D_bivector(A, DSF); R = bracket_forms(Gv, Fc, SF, F(1, 2))
        ok_r &= all(eqf(DD[C], R[C]) for C in range(G)); ok_z &= all(is0(x) for x in R)
        ok_nc &= any(not is0(x) for x in Gv.D_bivector(A, [star0(x, sq_) for x in J])) if m >= 2 else True
        if m >= 3:
            rng = random.Random(500 + m); phi = [{0: rp(rng, 2)} for _ in range(G)]
            Dphi = Gv.D_bivector(A, phi); dJ = bracket_forms(Gv, J, phi, F(1, 2))
            with trunc(4, xdeg=3, lam=1):                                       # jets: E exact on every coefficient of x-degree <= 1
                Ap = [Fm.add(A[C], Fm.wedge({0: LAMV}, Dphi[C])) for C in range(G)]; Jp = [Fm.add(J[C], Fm.wedge({0: LAMV}, dJ[C])) for C in range(G)]
                Ep, _, _ = E_ym(Gv, Ap, Jp, K, sq_, F(-1, 2), F(-1))
                def Fbad(AA):
                    Rr = [Fm.d(x) for x in AA]
                    for (P, Q), (C, f) in Gv.L.f.items(): Rr[C] = Fm.add(Rr[C], Fm.wedge(AA[P], AA[Q]), F(f, 2))
                    return Rr
                Eb, _, _ = E_ym(Gv, Ap, Jp, K, sq_, F(-1, 2), F(-1), Fc=Fbad(Ap))
            E0b, _, _ = E_ym(Gv, A, J, K, sq_, F(-1, 2), F(-1), Fc=Fbad(A))
            want = bracket_forms(Gv, E, phi, F(1, 2)); wantb = bracket_forms(Gv, E0b, phi, F(1, 2))
            ok_cov &= all(B3.form_eq_deg(lam1_form(Ep[C]), want[C], 1) for C in range(G)) and any(not is0(x) for x in want)
            ok_cov_bad &= not all(B3.form_eq_deg(lam1_form(Eb[C]), wantb[C], 1) for C in range(G))
    chk('bit', ok_r and ok_z, 'D(D*F) = (1/2) f_AB^C F^A ^ *F^B exactly and the right side is 0 (F ^ *F symmetric in colour, f antisymmetric), m = 2, 3, 4: D*J = -D(D*F) = 0 for the source of every field')
    chk('ctl', ok_nc, 'control: a random J (not the source of a field) has D*J != 0: the conservation is the field equation\'s, not an identity of J')
    chk('bit', ok_cov, 'gauge covariance: A -> A + lam D(phi), J -> J + lam (1/2)[J, phi]: the lam^1 part of E is (1/2) f E phi on every coefficient of x-degree <= 1 (jets truncated at degree 3), m = 3, 4 (phi a random degree-2 algebra-valued function)')
    chk('ctl', ok_cov_bad, 'control: with F = dA + (1/2) f A ^ A (the quadratic term doubled) the same transformation does not give (1/2)[E, phi]: covariance fails, m = 3, 4')
    # non-Lie table
    Lb = Lie([-1] * 4); key = sorted(Lb.f)[0]; (C0, f0) = Lb.f[key]; Lb.f[key] = (C0, 2 * f0); Lb.f[(key[1], key[0])] = (C0, -2 * f0)
    def fc(L_, P, Q, C): v = L_.f.get((P, Q)); return v[1] if v and v[0] == C else 0
    jac_bad = sum(1 for P, Q, R_, Dd in itertools.product(range(6), repeat=4) if sum(fc(Lb, P, Q, X) * fc(Lb, X, R_, Dd) + fc(Lb, Q, R_, X) * fc(Lb, X, P, Dd) + fc(Lb, R_, P, X) * fc(Lb, X, Q, Dd) for X in range(6)) != 0)
    Gb = Grav(4, Lb); rng = random.Random(909); A = [rform1(rng, 2) for _ in range(6)]; Fc = Gb.curvature(A); SF = [star0(x, LOR) for x in Fc]
    DD = Gb.D_bivector(A, Gb.D_bivector(A, SF)); R = bracket_forms(Gb, Fc, SF, F(1, 2))
    chk('ctl', jac_bad > 0 and not all(eqf(DD[C], R[C]) for C in range(6)) and any(not is0(x) for x in DD), 'control: so(4) with one structure constant doubled (%s, Jacobi fails on %d index quadruples): D(D*F) != (1/2) f F ^ *F and D(D*F) != 0, the conservation of the source fails' % (str(key), jac_bad))
    tick('B')

    # ------------------------------------------------------------------ C
    head('C. one action L = (1/2) K F_g ^ *F_g + L_D (positive-energy sign), D = d + g A^a B_a (matter_selfcheck): the source, kappa / g, the sign of the interaction')
    sq_ = LOR; sigma = sorted(sig, key=str)[0] if (len(sig) == 1 and None not in sig) else F(-1)          # measured in part A
    ok_aff = True; ok_cur = True; kap = set(); ok_id = set(); ok_brief = set(); ok_conj = True; ok_w = True; ok_flip = True; ok_cov_s = True; ok_cov_flip = True; ok_std = True
    for (m, g, seed, full) in ((2, F(3), 1, True), (3, F(3), 2, True), (3, F(-1, 2), 3, False), (4, F(1, 2), 4, False)):
        Lie_ = Lie([-1] * m); Gv = Grav(4, Lie_); Fm = Gv.Fm; G = Gv.G; K = ym_K(Lie_)
        rng = random.Random(7000 + seed); Y = MS.Sys(4, m, g=g, mass=F(5))
        A = [rform1(rng, 2) for _ in range(G)]; a = [rform1(rng, 2) for _ in range(G)]
        Psi = {(S, T): p for S in Y.ev for T in Y.Ts for p in [rp(rng, 1, -3, 3)] if p}
        jf = jflat(Y, Psi, sq_); SJ = [star0(x, sq_) for x in jf]
        # the Dirac part: affine in A, its variation fitted against sum dA^a ^ *j_flat^a
        d0, Epsi = dirac_density(Y, A, Psi); d1, _ = dirac_density(Y, [Fm.add(A[C], a[C]) for C in range(G)], Psi); d2, _ = dirac_density(Y, [Fm.add(A[C], a[C], 2) for C in range(G)], Psi)
        ok_aff &= (padd(padd(d2, d1, -2), d0) == {})
        dD = padd(d1, d0, -1); base = lsum(Fm, [(1, Fm.wedge(a[B], SJ[B])) for B in range(G)]).get(FULL, {})
        k0 = next(iter(base)); cD = dD.get(k0, F(0)) / base[k0]; ok_cur &= (dD == scale(base, cD)) and bool(dD)
        for ck in (F(1, 2), F(-1, 2)):
            kp = cD / (2 * ck * sigma)                                             # E_B = -2 c_k (D*F)^B + c_D *j_flat^B = 0  <=>  D^mu F_mu nu = kp j_nu
            (kap if ck > 0 else ok_brief).add((cD / g, kp / g))
        if full:                                                                   # the whole action by interpolation (degree <= 4 in eps)
            for ck in (F(1, 2), F(-1, 2)):
                def Ltot(AA):
                    dens, _ = dirac_density(Y, AA, Psi); return Fm.add(L_ym(Gv, AA, None, K, sq_, ck, 0, g), {FULL: dens} if dens else {})
                co = eps_coeffs(Fm, Ltot, A, a); Ey, DSF, SF = E_ym(Gv, A, None, K, sq_, ck, 0, g)
                E = [Fm.add(Ey[B], SJ[B], cD) for B in range(G)]
                ok_id.add((ck, eqf(co[1], Fm.add(lsum(Fm, [(1, Fm.wedge(a[B], E[B])) for B in range(G)]), Fm.d(theta_ym(Gv, a, SF, K, ck)))) and not is0(co[1]) and is0(co[5])))
        # conjugate field: algebraic in Phi with the weights w_S
        Phi = {(S, T): p for S in Y.ev for T in Y.Ts for p in [rp(rng, 1, -3, 3)] if p}
        dP, _ = dirac_density(Y, A, Psi, Phi); EG = Y.r0(Epsi); want = {}
        for k, p in Phi.items():
            if EG.get(k): want = padd(want, MS.pmul(EG[k], p), wS(k[0], Y.sq))
        ok_conj &= (dP == want) and bool(dP); ok_w &= all(wS(S, Y.sq) in (1, -1) for S in Y.ev)
        # flip of the interaction term: -g in L_D only
        Yf = MS.Sys(4, m, g=-g, mass=F(5)); Ef = MS.Eop(Yf, acomp(A), Psi); E0 = MS.Eop(MS.Sys(4, m, g=F(0), mass=F(5)), acomp(A), Psi)
        pot = MS.fadd(Epsi, E0, -1); potf = MS.fadd(Ef, E0, -1)
        f1, _ = dirac_density(Yf, [Fm.add(A[C], a[C]) for C in range(G)], Psi); f0, _ = dirac_density(Yf, A, Psi)
        ok_flip &= (potf == {k: scale(p, -1) for k, p in pot.items()}) and bool(pot) and (padd(f1, f0, -1) == scale(dD, -1))
        # covariance: the gauge transformation of F_g (dA = d lam + g f A lam) and the matter transformation of coupling s g
        lamf = [rp(rng, 1) for _ in range(G)]; Ac = acomp(A); dA = []
        for mu in range(4):
            v = [sp_der(lamf[x], mu) for x in range(G)]
            for (b, cc), d in Y.f.items():
                for x, w in d.items():
                    if Ac[mu][b] and lamf[cc]: v[x] = padd(v[x], MS.pmul(Ac[mu][b], lamf[cc]), g * w)
            dA.append(v)
        for s, YY in ((1, Y), (-1, Yf)):
            dPsi = {}
            for x in range(G): dPsi = MS.fadd(dPsi, MS.fmulp(lamf[x], YY.lmul(x, Psi)), -YY.g)
            dE = {}
            for mu in range(4):
                t = MS.fder(dPsi, mu)
                for x in range(G):
                    if Ac[mu][x]: t = MS.fadd(t, MS.fmulp(Ac[mu][x], YY.lmul(x, dPsi)), YY.g)
                    if dA[mu][x]: t = MS.fadd(t, MS.fmulp(dA[mu][x], YY.lmul(x, Psi)), YY.g)
                dE = MS.fadd(dE, YY.rJ(YY.gam_left(mu, t)))
            dE = MS.fadd(dE, YY.r0(dPsi), -YY.mass); E_ = Epsi if s == 1 else Ef; wnt = {}
            for x in range(G): wnt = MS.fadd(wnt, MS.fmulp(lamf[x], YY.lmul(x, E_)), -YY.g)
            if s == 1: ok_cov_s &= (dE == wnt)
            else: ok_cov_flip &= (dE == wnt) == (m == 2)
        # [std]: point values only: exact differences of the density in A^a_mu at a rational point against matter_selfcheck's pointwise current Bnu
        x0 = (F(1, 3), F(-1, 2), F(2, 5), F(1, 7)); ev = lambda p: sum(v * F(1) * x0[0] ** k[0] * x0[1] ** k[1] * x0[2] ** k[2] * x0[3] ** k[3] for k, v in p.items())
        P0 = {k: ev(p) for k, p in Psi.items()}; dP0 = [{k: ev(sp_der(p, mu)) for k, p in Psi.items()} for mu in range(4)]; A0 = [[ev(A[x].get(1 << mu, {})) for x in range(G)] for mu in range(4)]
        def lm0(x, X):
            out = {}
            for (S, T), v in X.items():
                t, s_ = bmul(Y.gens[x], T, Y.sqi); out[(S, t)] = out.get((S, t), 0) + s_ * v
            return out
        def dens0(Av):
            tot = {}
            for mu in range(4):
                Dm = dict(dP0[mu])
                for x in range(G):
                    if Av[mu][x]:
                        for k, v in lm0(x, P0).items(): Dm[k] = Dm.get(k, 0) + g * Av[mu][x] * v
                for (S, T), v in Dm.items():
                    t1, s1 = bmul(1 << mu, S, Y.sq); t2, s2 = bmul(t1, Y.Jm, Y.sq); t3, s3 = bmul(t2, 1, Y.sq)
                    tot[(t3, T)] = tot.get((t3, T), 0) + s1 * Y.sq[mu] * (-1) * s2 * s3 * v
            for (S, T), v in P0.items(): tot[(S, T)] = tot.get((S, T), 0) - Y.mass * v          # E gamma_0 = gamma^mu D_mu Psi J gamma_0 - m Psi
            return sum(wS(S, Y.sq) * v * P0.get((S, T), 0) for (S, T), v in tot.items())
        base0 = dens0(A0)
        for (x, mu) in ((0, 0), (G - 1, 2)):
            Ap = [list(r) for r in A0]; Ap[mu][x] += 1
            dd = dens0(Ap) - base0; ok_std &= (dd == g * MS.Bnu(Y, P0, lm0(x, P0), mu)) and dd != 0
        ok_std &= base0 == ev(d0)
    kv = sorted(kap, key=str); bv = sorted(ok_brief, key=str); iv = sorted(ok_id, key=str)
    chk('bit', ok_aff and ok_cur, 'L_D is affine in A and delta_A L_D vol = c_D sum_a dA^a ^ *j_flat^a with ONE constant c_D = g per sample, (m, g) = (2, 3), (3, 3), (3, -1/2), (4, 1/2); j_flat^a = eta_nu nu j^(a nu) dx^nu with j^(a nu) = matter_selfcheck\'s Bnu (polynomial entries): its j^a_nu enters with the index raised')
    chk('bit', iv == [(F(-1, 2), True), (F(1, 2), True)], 'one action c_k K F_g ^ *F_g + L_D, by interpolation in eps (degree <= 4): delta_A L = dA^B ^ (2 c_k K_BC (D_g *F_g)^C + g *j_flat^B) + d(2 c_k K dA ^ *F_g) exactly, (m, g) = (2, 3), (3, 3), both signs c_k = +1/2, -1/2: the A-equation is 2 c_k D*F = g *j_flat')
    chk('bit', kv == [(F(1), F(-1))], 'with D*F = sigma *(D^mu F_mu nu dx^nu), sigma = %s (part A) and the positive-energy sign c_k = +1/2: D^mu F^a_mu nu = kappa j^a_nu with kappa / g = -1 for matter_selfcheck\'s current, for g of both signs (g -> -g in D and F together), m = 2, 3, 4; kappa = +g for X^a = -j^a: (c_D/g, kappa/g) = %s' % (sigma, kv))
    chk('bit', ok_conj and ok_w, 'conjugate field: L_D(Phi, Psi) is algebraic in Phi, Sum_{S,T} w_S (E gamma_0)_{S,T} Phi_{S,T}, and w_S = <e_S e_S~>_0 = +-1 on all 8 even blades (a non-degenerate pairing): delta_Phi L = 0 iff E = 0, the matter equation with + g A^a B_a Psi (the variation in Psi itself: ym_matter_gravity.py part D)')
    chk('bit', ok_flip, 'flip: the interaction term with -g (L_D only) gives the Dirac equation with - g A^a B_a Psi and the source -g *j_flat: the potential term and the source flip together, m = 2, 3, 4')
    chk('bit', ok_cov_s, 'the matter equation of coupling g is covariant at first order under the gauge transformation of F_g (dA = d lam + g f A lam, dPsi = -g lam B Psi): dE = -g lam B E, all samples')
    chk('ctl', ok_cov_flip, 'control: with the interaction flipped alone (D = d - g A, F keeps +g) the matter equation is not covariant under the gauge transformation of F_g for m >= 3 (it is at m = 2): the commutator term of F is the g of D, not scaled separately')
    chk('ctl', bv == [(F(1), F(1))], 'control: the brief\'s overall sign of the Yang-Mills term (c_k = -1/2, L_D unchanged) gives kappa / g = +1: the sign of kappa is the relative sign of the two terms, fixed here by the positive energy of the Yang-Mills term (b3_matter part 5, ym_matter_gravity part G)')
    chk('std', ok_std, 'point values only (no polynomial): the density at a rational point equals the polynomial L_D there, and its exact difference under a unit change of A^a_mu equals g * Bnu (matter_selfcheck\'s pointwise current), two (a, mu) per sample, all samples')
    tick('C')
    finish('YM-ACTION')

if __name__ == '__main__': main()
