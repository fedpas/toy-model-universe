#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-PETROV.  Frames of Petrov types II and III, built from Q = E + iB with the Jordan forms and read back by the engine.   python3 gm_petrov_ii_iii.py

 Q (complex symmetric, trace-free 3 x 3): type II: diag(l, l, -2l) + N2 with N2 = [[1, i, 0], [i, -1, 0], [0, 0, 0]] (N2^2 = 0: a 2 x 2 Jordan block for l), l = 1 and l = 1 + i;
 type III: [[0, 1, 0], [1, 0, i], [0, i, 0]] (nilpotent of index 3). Controls: type D diag(l, l, -2l), type N the matrix N2, type I diag(1, 2, -3).
 Q -> Weyl tensor: the unique solution over the 21 cells S_AB of Ricci = 0, the first Bianchi identity and complex_Q(C) = Q (exact linear solve, rank 21).
 Weyl tensor -> frame: e^a = Lambda(x)^a_b (dx^b - (1/6) C^b_{alpha mu beta} x^alpha x^beta dx^mu) (Riemann normal 2-jet; Lambda = 1 + X + X^2/2, X = x^mu X_mu, X_mu in so(1,3):
 a local Lorentz transformation to second order with Lambda(0) = 1, so the connection is not zero at the point and the quadratic term of R is read).
 [bit]  the engine: A3 closed-form omega (1-jet), R = d omega + (1/4)[omega, omega], T = 0 at the point; the frame Riemann tensor at the point equals C; its Weyl part and
        Q = E + iB (g2_weyl.complex_Q) equal the chosen Q; the type from the exact Jordan structure over Q(i) (g2_weyl.petrov).
 [std]  the Christoffel route on g = e^T eta e (exact, g2_weyl.std_frame_riemann) equals C; numpy: Weyl and Q from floats (g2_weyl.weyl_float), the numerical type (petrov_float),
        Jordan ranks (rank (Q - l), (Q - l)^2, Q, Q^2, Q^3 by SVD) and the invariants I = tr Q^2/2, J = tr Q^3/6: I^3 = 27 J^2 != 0 for II and D, I = J = 0 for III and N
        (normalisation recalled from Stephani, Kramer, MacCallum, Hoenselaers, Herlt, Exact Solutions of Einstein's Field Equations).
 Controls: the diagonalisable Q with the eigenvalues of II is D, not II; the nilpotent of index 2 is N, of index 3 III; diag(1, 2, -3) is I.
 Scope: one point (the origin of the jets) per frame, signature (+,-,-,-)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from g2_weyl import *

SQ4 = LORENTZ(4); I_ = QI(0, 1)
def dot(u, v): return sum(x * y for x, y in zip(u, v))
def qm(rows): return [[qi(x) for x in r] for r in rows]
def N2(): return qm([[1, I_, 0], [I_, -1, 0], [0, 0, 0]])
def QD(l): return qm([[l, 0, 0], [0, l, 0], [0, 0, -2 * l]])
def QII(l): return [[QD(l)[i][j] + N2()[i][j] for j in range(3)] for i in range(3)]
def QIII(): return qm([[0, 1, 0], [1, 0, I_], [0, I_, 0]])
def ricci_of(T, sq=SQ4): return {(b, d): sum(sq[a] * T[(a, b, a, d)] for a in range(4)) for b in range(4) for d in range(4)}
def weyl_from_Q(Q):
    """the unique 21-cell vector with Ricci = 0, first Bianchi and complex_Q = Q (exact); returns (cells, rank, consistent)"""
    cols = []
    for i in range(21):
        T = tensor_of_cells(unit_cell(i)); Ric = ricci_of(T); q = complex_Q(T)
        cols.append([Ric[(b, d)] for b in range(4) for d in range(b, 4)] + [eps_row()[i]] + [q[r][c].re for r in range(3) for c in range(3)] + [q[r][c].im for r in range(3) for c in range(3)])
    rows = [[cols[i][k] for i in range(21)] for k in range(len(cols[0]))]
    rhs = [F(0)] * 11 + [Q[r][c].re for r in range(3) for c in range(3)] + [Q[r][c].im for r in range(3) for c in range(3)]
    w, rank, nvar, cons = solve_exact(rows, rhs)
    return w, rank, cons
XMU = [[[0, F(1, 2), F(1, 5), 0], [F(1, 2), 0, 0, 0], [F(1, 5), 0, 0, 0], [0, 0, 0, 0]],   # X_mu as matrices X^a_b with eta X antisymmetric: boosts in (0,1) and (0,2) ...
       [[0, 0, 0, 0], [0, 0, F(1, 3), 0], [0, F(-1, 3), 0, 0], [0, 0, 0, 0]],          # ... a rotation in (1,2)
       [[0, 0, 0, F(-1, 4)], [0, 0, 0, 0], [0, 0, 0, 0], [F(-1, 4), 0, 0, 0]],         # ... a boost in (0,3)
       [[0, 0, 0, 0], [0, 0, 0, F(2, 5)], [0, 0, 0, 0], [0, F(-2, 5), 0, 0]]]          # ... a rotation in (1,3)
def frame_from_weyl(C, nv=4, gauge=True):
    """e^a_mu = Lambda^a_b(x) (delta^b_mu - (1/6) eta^bb C_{b alpha mu beta} x^alpha x^beta), exact to x-degree 2"""
    X = [var(nv, i) for i in range(4)]
    base = [[lin((F(int(b == mu)), const(nv, 1)), *[(-F(1, 6) * SQ4[b] * C[(b, al, mu, be)], sp_mul(X[al], X[be], 2, nv)) for al in range(4) for be in range(4) if C[(b, al, mu, be)] != 0]) for mu in range(4)] for b in range(4)]
    if not gauge: Lam = [[const(nv, int(a == b)) for b in range(4)] for a in range(4)]
    else:
        A = [[lin(*[(XMU[m][a][b], X[m]) for m in range(4) if XMU[m][a][b] != 0]) for b in range(4)] for a in range(4)]
        A2 = [[lin(*[(F(1), sp_mul(A[a][c], A[c][b], 2, nv)) for c in range(4)]) for b in range(4)] for a in range(4)]
        Lam = [[lin((F(int(a == b)), const(nv, 1)), (F(1), A[a][b]), (F(1, 2), A2[a][b])) for b in range(4)] for a in range(4)]
    e = []
    for a in range(4):
        form = {}
        for mu in range(4):
            p = lin(*[(F(1), sp_mul(Lam[a][b], base[b][mu], 2, nv)) for b in range(4)])
            if p: form[1 << mu] = p
        e.append(form)
    return e
def lorentz_ok(nv=4):
    """Lambda^T eta Lambda = eta to x-degree 2 (each X_mu in so(1,3))"""
    ok = True
    for m in range(4):
        X = XMU[m]; ok &= all(sum(SQ4[a] * X[a][b] * (1 if a == c else 0) for a in range(4)) + sum(SQ4[a] * X[a][c] * (1 if a == b else 0) for a in range(4)) == 0 for b in range(4) for c in range(4))
    return ok
def jordan_numpy(Qf, lam=None):
    sv = lambda M: int((np.linalg.svd(M, compute_uv=False) > 1e-9 * max(1.0, np.linalg.norm(Qf))).sum())
    I3 = np.eye(3); out = {'rank Q': sv(Qf), 'rank Q^2': sv(Qf @ Qf), 'rank Q^3': sv(Qf @ Qf @ Qf)}
    if lam is not None: out['rank (Q-l)'] = sv(Qf - lam * I3); out['rank (Q-l)^2'] = sv((Qf - lam * I3) @ (Qf - lam * I3))
    I = np.trace(Qf @ Qf) / 2; J = np.trace(Qf @ Qf @ Qf) / 6
    return out, I, J

def main():
    Lie_ = Lie(SQ4); Gv = Grav(4, Lie_); S = koszul_S(4, SQ4, Lie_)            # built per run (engine faults in memory are seen)
    chk('bit', lorentz_ok(), 'the four generators X_mu of the gauge Lambda = 1 + X + X^2/2 are in so(1,3) (eta X antisymmetric): Lambda is Lorentz to second order, Lambda(0) = 1')
    CASES = [('II', 'type II, l = 1', QII(1), QI(1)), ('II', 'type II, l = 1 + i', QII(QI(1, 1)), QI(1, 1)), ('III', 'type III (nilpotent, index 3)', QIII(), None),
             ('D', 'control: type D, l = 1 (diagonalisable, the eigenvalues of II)', QD(1), QI(1)), ('N', 'control: type N (nilpotent, index 2)', N2(), None),
             ('I', 'control: type I, diag(1, 2, -3)', qm([[1, 0, 0], [0, 2, 0], [0, 0, -3]]), None)]
    for want, name, Q, lam in CASES:
        head('%s: Q = %s' % (name, [[repr(x) for x in r] for r in Q]))
        tag = 'ctl' if name.startswith('control') else 'bit'
        okQ = q_symmetric(Q) and qtrace(Q).iszero()
        w, rank, cons = weyl_from_Q(Q); C = tensor_of_cells(w) if cons else None
        okC = cons and rank == 21 and pair_symmetric(C) and all_traces_zero(C, SQ4) and dot(eps_row(), w) == 0 and all(complex_Q(C)[i][j] == Q[i][j] for i in range(3) for j in range(3))
        chk('bit', okQ and okC, '%s: Q symmetric and trace-free; the Weyl tensor with this Q is unique (rank 21 of the 21 cells), pair-symmetric, trace-free on all contractions, first Bianchi' % name)
        e = frame_from_weyl(C)
        Rl, om, R = engine_frame_riemann(Gv, e, S, 4)
        with trunc(4, xdeg=0): tz = torsion_zero_at0(Gv, om, e, 4)
        om0 = any(at0(p, 4) != 0 for A in om for p in A.values())
        Ce, Ric, Rs, tf = weyl_parts(Rl, SQ4); Qe = complex_Q(Ce); typ, I2, I3, info = petrov(Qe)
        sameR = all(Rl[k] == C[k] for k in C); sameQ = all(Qe[i][j] == Q[i][j] for i in range(3) for j in range(3))
        chk('bit', tz and om0 and sameR and sameQ, '%s: engine frame Riemann at the point = C (Ricci 0), omega(0) != 0, T = 0; Q read back = the chosen Q' % name)
        chk(tag, typ == want, '%s: the engine\'s Petrov type is %s (expected %s); tr Q^2 = %s, tr Q^3 = %s%s' % (name, typ, want, I2, I3,
            ('; double eigenvalue %s, simple %s, rank(Q - l) = %d' % (info['double'], info['simple'], info['rank_Q_minus_r'])) if 'double' in info else ''))
        # [std]
        Rstd = std_frame_riemann(e, 4, SQ4); Cf, Qf, Ricf, Rsf = weyl_float(Rstd, SQ4); tf_, I2f, I3f = petrov_float(Qf)
        jr, If, Jf = jordan_numpy(Qf, lam.cx() if lam is not None else None)
        spec = {'II': lambda: jr['rank (Q-l)'] == 2 and jr['rank (Q-l)^2'] == 1 and abs(If ** 3 - 27 * Jf ** 2) < 1e-9 * abs(If) ** 3 and abs(If) > 1e-9,
                'D': lambda: jr['rank (Q-l)'] == 1 and abs(If ** 3 - 27 * Jf ** 2) < 1e-9 * abs(If) ** 3,
                'III': lambda: (jr['rank Q'], jr['rank Q^2'], jr['rank Q^3']) == (2, 1, 0) and abs(If) < 1e-12 and abs(Jf) < 1e-12,
                'N': lambda: (jr['rank Q'], jr['rank Q^2']) == (1, 0) and abs(If) < 1e-12 and abs(Jf) < 1e-12,
                'I': lambda: abs(If ** 3 - 27 * Jf ** 2) > 1e-6}[want]()
        chk('std', all(Rstd[k] == C[k] for k in C) and np.allclose(Qf, np.array([[x.cx() for x in r] for r in Q])), '%s: the Christoffel route on g = e^T eta e gives the same R_abcd = C exactly; numpy Q = the chosen Q' % name)
        chk('std', tf_ == want and spec, '%s: numpy type %s; Jordan ranks %s; I = %.6g%+.6gi, J = %.6g%+.6gi, I^3 - 27 J^2 = %.2e' % (name, tf_, jr, If.real, If.imag, Jf.real, Jf.imag, abs(If ** 3 - 27 * Jf ** 2)))
        chk('bit==std', typ == tf_, '%s: exact type (engine, Q(i)) = numerical type (numpy) = %s' % (name, typ))
    head('reading')
    print('    The Weyl tensors of types II and III are built from Q (a 2 x 2 Jordan block for the double eigenvalue; a nilpotent of index 3) and the engine reads the types back from the curvature'
          '\n    of a frame; with the D, N and I frames of h1_petrov.py and the flat frame (O), all six Jordan types have a frame. The types D and II share the invariants (I^3 = 27 J^2), N and III'
          '\n    share I = J = 0; the ranks of Q - l and of Q^2 separate them.')

if __name__ == '__main__':
    main(); finish('GM-PETROV')
