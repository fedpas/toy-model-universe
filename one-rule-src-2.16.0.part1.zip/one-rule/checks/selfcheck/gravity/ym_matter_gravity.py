#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""YM-GRAV.  The Dirac action charged under so(m) (stationarity, Noether current) and the non-abelian stress as a source of gravity.   python3 ym_matter_gravity.py

 D  L_D = Sum_T <(E gamma_0)_T Psi~_T>_0 (matter_selfcheck's Psi, D = d + g A^a B_a, E = gamma^mu (D_mu Psi) J - m Psi gamma_0; helpers of ym_action.py):
    [bit] delta_Psi L_D = c1 <E gamma_0, dPsi>_w + c2 d_mu V^mu with (c1, c2) = (2, 1) by an exact fit (stationarity in Psi is E = 0);
          (D_mu j^mu)^a = c <E gamma_0, B_a Psi>_w off shell with c = -2 (so j^a is conserved when E = 0); the Noether current of B_a is matter_selfcheck's j^a.
    [std] matter_selfcheck's pointwise on-shell conservation (its point_identities), called here.
 G  the Wu-Yang hedgehog (ym_solutions.wuyang_A) on c3_rn's radial Kerr-Schild Reissner-Nordstrom frame, f = M/rho - s/rho^2, the 7 points of c3_rn:
    [bit] T = Sum_a (-1/2) F^a gamma F^a (frame components, g2_hodge) = the variational stress of -(1/2) Sum F^a ^ *F^a (b3_matter.matter_variation: tau = -T)
          = the stress of the abelian magnetic monopole of strength 1 (c3_rn's Coulomb field with Q = 1, its dual); D*F = 0 on the curved frame (frame star, D_bivector)
          and nabla^a F_ab + (1/2) f A^a F_ab = 0 (engine omega, D_two_index: the h table); E_a(c=0) = -(4 s/P^2) T_a, so E_a + kappa T_a = 0 iff s = kappa P^2/4.
    [std] c1_birkhoff's Christoffel route G^mu_nu = (4 s/P^2) T^mu_nu with the textbook T^mu_nu = Sum_a (-F^(a mu alpha) F^a_nu alpha + (1/4) delta F^a.F^a).
 [ctl] the wrong sign of the divergence term; the wrong charge term s; a non-hedgehog field; the stress with the opposite overall sign; omega = 0 in the covariant route.
 Exports (no engine object at import): bil, L_dirac, ym_stress_at_point."""
import os, sys, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import b3_matter as B3
import c3_rn
import ym_action as YA
import ym_solutions as YS
import matter_selfcheck as MS

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
SQ = LORENTZ(4); FULL = 15

def bil(Y, Phi, X, nu):
    """Sum_T < Phi~_T gamma^nu X_T gamma_0 J >_0 (matter_selfcheck's Bnu with X in place of B_a Psi; polynomial entries)"""
    tot = {}
    for (S, T), v in Phi.items():
        for (S2, T2), w in X.items():
            if T != T2 or not v or not w: continue
            mk, s = MS.prod([S, 1 << nu, S2, 1, Y.Jm], Y.sq)
            if mk == 0: tot = padd(tot, MS.pmul(v, w), s * (-1) * gs.rsign(popc(S)) * Y.sq[nu])
    return tot
def L_dirac(Y, A, Psi): return YA.dirac_density(Y, A, Psi)
def fit(target, basis):
    keys = sorted(set(target) | {k for b in basis for k in b}); rows = [[b.get(k, F(0)) for b in basis] for k in keys]
    w, rank, nvar, cons = solve_exact(rows, [target.get(k, F(0)) for k in keys]); return w if cons and rank == len(basis) else None
def ym_stress_at_point(Fls, sign=F(-1, 2)):
    """T^b_a = Sum_colours (-K_cc) sign * F^c gamma_a F^c (K = -1: weight 1), from lower frame components Fls[c][(a, b)]"""
    T = [[F(0)] * 4 for _ in range(4)]
    for Fl in Fls:
        Tc = H.maxwell_T_bit(H.bivector(Fl, SQ), SQ, sign)
        T = [[T[b][a] + Tc[b][a] for a in range(4)] for b in range(4)]
    return T

def main():
    # ================================================================================== D
    head('D. the Dirac action with D: variation in Psi, the Noether identity off shell, the Noether current (polynomial fields, m = 2, 3, g = 3)')
    Fm = Forms(4); ok_var = set(); ok_noe = set(); ok_cur = True; ok_glob = True; ok_bad = True
    for (m, seed) in ((2, 11), (3, 12)):
        rng = random.Random(seed); Y = MS.Sys(4, m, g=F(3), mass=F(5)); G = Y.G
        A = [YA.rform1(rng, 1) for _ in range(G)]
        Psi = {(S, T): p for S in Y.ev for T in Y.Ts for p in [YA.rp(rng, 1, -3, 3)] if p}; dPsi = {(S, T): p for S in Y.ev for T in Y.Ts for p in [YA.rp(rng, 1, -3, 3)] if p}
        Lp, _ = L_dirac(Y, A, MS.fadd(Psi, dPsi)); Lm, _ = L_dirac(Y, A, MS.fadd(Psi, dPsi, -1)); L0, E = L_dirac(Y, A, Psi)
        first = scale(padd(Lp, Lm, -1), F(1, 2))
        P = YA.pairing(Y.r0(E), dPsi, Y.sq)
        V = {}
        for mu in range(4):
            q = bil(Y, Psi, dPsi, mu)
            if q: V = Fm.add(V, {FULL ^ (1 << mu): scale(q, (-1) ** mu)})
        divV = Fm.d(V).get(FULL, {})
        w = fit(first, [P, divV]); ok_var.add(tuple(w) if w else None)
        wb = fit(first, [P, scale(divV, -1)]); ok_bad &= (wb is None or tuple(wb) != (F(2), F(1)))
        # Noether identity off shell
        Ac = YA.acomp(A); lhs = []; rhs = []
        for a in range(G):
            j = [YA.current_poly(Y, Psi, Psi, a, mu) for mu in range(4)]
            div = {}
            for mu in range(4): div = padd(div, sp_der(j[mu], mu))
            for (b, c), d in Y.f.items():
                if a in d:
                    for mu in range(4):
                        jc = YA.current_poly(Y, Psi, Psi, c, mu)
                        if Ac[mu][b] and jc: div = padd(div, MS.pmul(Ac[mu][b], jc), Y.g * d[a])
            lhs.append(div); rhs.append(YA.pairing(Y.r0(E), Y.lmul(a, Psi), Y.sq))
        cs_ = set()
        for a in range(G):
            wa = fit(lhs[a], [rhs[a]]); cs_.add(wa[0] if wa else None)
        ok_noe.add(tuple(sorted(cs_, key=str)))
        # the Noether current: dPsi = phi B_a Psi at A = 0; phi = 1 gives 0 (global symmetry), phi = x^nu gives the coefficient of d_nu phi
        A0 = [{} for _ in range(G)]; Lz, _ = L_dirac(Y, A0, Psi)
        for a in range(G):
            BPsi = Y.lmul(a, Psi)
            g1p, _ = L_dirac(Y, A0, MS.fadd(Psi, BPsi)); g1m, _ = L_dirac(Y, A0, MS.fadd(Psi, BPsi, -1)); ok_glob &= padd(g1p, g1m, -1) == {}
            for nu in range(4):
                xn = {tuple(1 if i == nu else 0 for i in range(5)): F(1)}; dP = MS.fmulp(xn, BPsi)
                hp, _ = L_dirac(Y, A0, MS.fadd(Psi, dP)); hm, _ = L_dirac(Y, A0, MS.fadd(Psi, dP, -1))
                ok_cur &= scale(padd(hp, hm, -1), F(1, 2)) == YA.current_poly(Y, Psi, Psi, a, nu) and bool(YA.current_poly(Y, Psi, Psi, a, nu))
    chk('bit', ok_var == {(F(2), F(1))}, 'variation in Psi itself: delta L_D = c1 <E gamma_0, dPsi>_w + c2 d_mu V^mu exactly, V^mu = Sum_T <Psi~_T gamma^mu dPsi_T gamma_0 J>_0 (engine d of the 3-form), fitted (c1, c2) = %s, m = 2, 3: stationarity in Psi is E = 0' % sorted(ok_var, key=str))
    chk('ctl', ok_bad, 'control: the divergence term with the wrong sign does not give (2, 1)')
    chk('bit', ok_noe == {(F(-2),)}, 'Noether identity off shell: (D_mu j^mu)^a = d_mu j^(a mu) + g f_bc^a A^b_mu j^(c mu) = c <E gamma_0, B_a Psi>_w with ONE c = %s for every generator, m = 2, 3: D_mu j^mu = 0 wherever E = 0' % sorted(ok_noe, key=str))
    chk('bit', ok_glob and ok_cur, 'A = 0: dPsi = B_a Psi leaves L_D unchanged at first order (global symmetry), and for dPsi = x^nu B_a Psi the first-order change is j^(a nu) exactly: the Noether current of B_a is matter_selfcheck\'s j^a, every generator, m = 2, 3')
    okp = True
    for (n_, m_) in ((4, 2), (4, 3)):
        try: r = MS.point_identities(n_, m_, 77 * n_ + m_); okp &= r['conserved_on_shell'] and r['current_is_not_zero']
        except AssertionError: okp = False
    chk('std', okp, 'matter_selfcheck.point_identities (E = 0 reached at a point by solving for d_0 Psi, then D^nu j^a_nu = 0 there, exact numbers), (n, m) = (4, 2), (4, 3)')
    tick('D')

    # ================================================================================== G
    head('G. the Wu-Yang field on the Reissner-Nordstrom Kerr-Schild frame: the stress, the Yang-Mills equation on the frame, the Einstein form')
    LL = Lie(SQ); GL = Grav(4, LL); S = koszul_S(4, SQ, LL); L3 = Lie([-1] * 3); G3 = Grav(4, L3); FmL = GL.Fm
    SAMPLES = [(F(1), F(1, 4)), (F(3, 2), F(3, 8)), (F(-1, 3), F(1, 14)), (F(2), F(1, 2))]          # (M, s); P = 1
    ok_mono = True; ok_pos = True; ok_dsf = True; ok_cov = True; ok_om0 = False; ok_lam = set(); ok_k = True; ok_std = True; ok_nh = True; ok_nhT = False; ok_sign = True; ok_var = True; ok_bad = True; ok_nab = True; n_nab = 0; ok_nab0 = False; ok_nabnz = False
    for si, (M, s) in enumerate(SAMPLES):
        for pi_, (p, rho0) in enumerate(c3_rn.POINTS):
            if si >= 2 and pi_ >= 3: continue
            pt, e, E = c3_rn.frame_at(p, rho0, M, s); p4 = [F(0)] + list(pt)
            A, R2 = YS.wuyang_A(p4)
            with trunc(4, xdeg=2):
                Fc = G3.curvature(A); Fab = [H.frame_components(x, E, 4) for x in Fc]
                SF = [H.hodge_form(x, e, E, FmL, SQ, 4) for x in Fc]; DSF = G3.D_bivector(A, SF)
            Fls = [{(a, b): at0(Fx.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)} for Fx in Fab]
            T = ym_stress_at_point(Fls)
            mx = c3_rn.maxwell_on_frame(GL, pt, rho0, e, E, F(1))
            Mab = H.star_comps(mx['Fab'], SQ); Ml0 = {(a, b): at0(Mab.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)}
            Tmag = H.maxwell_T_bit(H.bivector(Ml0, SQ), SQ)
            ok_mono &= (T == Tmag) and (T == mx['Tm']) and any(v for (a, b), v in Ml0.items() if a > 0)
            ok_pos &= T[0][0] == F(1, 2) / rho0 ** 4
            ok_dsf &= all(not {k: v for k, v in x.items() if at0(v, 4) != 0} for x in DSF) and any(at0(q, 4) for x in SF for q in x.values())
            om, compE = c3_rn.einstein_on_frame(GL, S, e)
            with trunc(4, xdeg=1): Ta = H.stress_forms(T, H.theta_forms(e, FmL, 4), FmL)
            compT = einstein_components(Ta, 4, 4)
            k0 = next((k for k in sorted(compT) if compT[k] != 0), None)
            if k0 is None: ok_lam.add(None)
            else:
                ok_lam.add(compE[k0] / compT[k0] / s)
                if not all(compE[k] == compE[k0] / compT[k0] * compT[k] for k in compT): ok_lam.add(None)
            kap = 4 * s; ok_k &= all(compE[k] + kap * compT[k] == 0 for k in compE) and any(compE.values())
            ok_bad &= any(compE[k] + (2 * s) * compT[k] != 0 for k in compE)                    # s = kappa P^2/2 for kappa = 2 s: the wrong charge term
            Tneg = ym_stress_at_point(Fls, F(1, 2)); ok_sign &= Tneg[0][0] < 0
            # covariant route: nabla^a F^C_ab + (1/2) f_AB^C A^A_a F^B_ab with the engine's omega (D_two_index reads the h table)
            E0 = [[at0(E[mu][a], 4) for a in range(4)] for mu in range(4)]
            Af = [[sum(at0(A[C].get(1 << mu, {}), 4) * E0[mu][a] for mu in range(4)) for a in range(4)] for C in range(3)]
            div_all = []; div0_all = []
            for C in range(3):
                full = {}
                for a in range(4):
                    for b in range(4):
                        if a != b: full[(a, b)] = Fab[C].get((1 << a) | (1 << b), {}) if a < b else scale(Fab[C].get((1 << b) | (1 << a), {}), -1)
                with trunc(4, xdeg=1): DF = H.D_two_index(GL, om, full, 4); DF0 = H.D_two_index(GL, [{} for _ in range(GL.G)], full, 4)
                gauge = [sum(SQ[a] * F(f, 2) * Af[P_][a] * (at0(Fab[Q_].get((1 << min(a, b)) | (1 << max(a, b)), {}), 4) * (1 if a < b else -1) if a != b else 0)
                             for (P_, Q_), (C_, f) in L3.f.items() if C_ == C for a in range(4)) for b in range(4)]
                dv = H.frame_divergence_at0(DF, E, SQ, 4); dv0 = H.frame_divergence_at0(DF0, E, SQ, 4)
                div_all.append([x + y for x, y in zip(dv, gauge)]); div0_all.append([x + y for x, y in zip(dv0, gauge)])
            ok_cov &= all(v == 0 for r in div_all for v in r); ok_om0 |= any(v != 0 for r in div0_all for v in r)
            if si == 0 and pi_ < 3:                                                 # nabla_c F^C_ab (all frame components): engine (D_two_index, h table) against Christoffel symbols
                gmet = std_metric(e, 4, SQ, 4, 2); Gam = c3_rn.christoffel_std(gmet, 4, 4)
                for C in range(3):
                    Xj = {(a, b): (Fc[C].get((1 << a) | (1 << b), {}) if a < b else scale(Fc[C].get((1 << b) | (1 << a), {}), -1)) if a != b else {} for a in range(4) for b in range(4)}
                    nab = {(m_, v, r): at0(pder(Xj[(v, r)], m_), 4) - sum(Gam[(l, m_, v)] * at0(Xj[(l, r)], 4) + Gam[(l, m_, r)] * at0(Xj[(v, l)], 4) for l in range(4)) for m_ in range(4) for v in range(4) for r in range(4)}
                    full = {}
                    for a in range(4):
                        for b in range(4):
                            if a != b: full[(a, b)] = Fab[C].get((1 << a) | (1 << b), {}) if a < b else scale(Fab[C].get((1 << b) | (1 << a), {}), -1)
                    with trunc(4, xdeg=1): DX = H.D_two_index(GL, om, full, 4); DX0 = H.D_two_index(GL, [{} for _ in range(GL.G)], full, 4)
                    for a in range(4):
                        for b in range(4):
                            if a == b: continue
                            bc = H.frame_derivative_at0(DX[(a, b)], E, 4, 4); bc0 = H.frame_derivative_at0(DX0[(a, b)], E, 4, 4)
                            for c in range(4):
                                sc = sum(E0[m_][c] * E0[v][a] * E0[r][b] * nab[(m_, v, r)] for m_ in range(4) for v in range(4) for r in range(4))
                                ok_nab &= (bc[c] == sc); n_nab += 1; ok_nab0 |= (bc0[c] != sc); ok_nabnz |= (sc != 0 and a == 0 and c != 0)
            # [std] Christoffel route
            jets = c3_rn.rn_jets(M, s, rho0); Gs = c3_rn.C1.std_G(p, rho0, jets); f0 = jets[0]; r0 = F(rho0)
            ld = [F(1)] + [F(x) / r0 for x in pt]; lu = [F(1)] + [-F(x) / r0 for x in pt]
            gi = [[SQ[m_] * (m_ == v) + 2 * f0 * lu[m_] * lu[v] for v in range(4)] for m_ in range(4)]
            Av = [[at0(A[C].get(1 << mu, {}), 4) for mu in range(4)] for C in range(3)]
            dA = [[[at0(pder(A[C].get(1 << nu, {}), mu), 4) for nu in range(4)] for mu in range(4)] for C in range(3)]
            Ts = [[F(0)] * 4 for _ in range(4)]
            for C in range(3):
                Fco = [[dA[C][m_][v] - dA[C][v][m_] + sum(YS.eps3(C, b_, c_) * (Av[b_][m_] * Av[c_][v]) for b_ in range(3) for c_ in range(3)) for v in range(4)] for m_ in range(4)]
                Fup = [[sum(gi[m_][a_] * gi[v][b_] * Fco[a_][b_] for a_ in range(4) for b_ in range(4)) for v in range(4)] for m_ in range(4)]
                F2 = sum(Fco[a_][b_] * Fup[a_][b_] for a_ in range(4) for b_ in range(4))
                Ts = [[Ts[m_][v] - sum(Fup[m_][a_] * Fco[v][a_] for a_ in range(4)) + (F2 / 4 if m_ == v else 0) for v in range(4)] for m_ in range(4)]
            ok_std &= all(Gs[m_][v] == 4 * s * Ts[m_][v] for m_ in range(4) for v in range(4)) and any(Ts[m_][v] for m_ in range(4) for v in range(4))
            if si == 0 and pi_ < 2:
                e5 = [B3.lift_form(x) for x in e]; Fc5 = [B3.lift_form({k: q for k, q in x.items()}) for x in Fc]
                tau = B3.matter_variation(GL, e5, lambda ep, Ep: lsum_forms(GL, [B3.L_maxwell(GL, ep, Ep, Fx, 1) for Fx in Fc5]))
                Tv, _ = B3.tau_mixed_at0(tau, e5); ok_var &= all(Tv[b][a] == -T[b][a] for a in range(4) for b in range(4)) and any(T[b][a] for a in range(4) for b in range(4))
            if si == 0 and pi_ < 3:
                An = [dict(A[0]), dict(A[1]), {}]
                with trunc(4, xdeg=2):
                    Fn = G3.curvature(An); SFn = [H.hodge_form(x, e, E, FmL, SQ, 4) for x in Fn]; DSFn = G3.D_bivector(An, SFn); Fabn = [H.frame_components(x, E, 4) for x in Fn]
                ok_nh &= any(at0(q, 4) != 0 for x in DSFn for q in x.values())
                Tn = ym_stress_at_point([{(a, b): at0(Fx.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)} for Fx in Fabn]); ok_nhT |= (Tn != Tmag)
    lv = sorted(ok_lam, key=str)
    chk('bit', ok_mono and ok_pos, 'T = Sum_a (-1/2) F^a gamma F^a of the Wu-Yang field = the stress of the abelian magnetic monopole of strength 1 (dual of c3_rn\'s Coulomb field, Q = 1) = that Coulomb stress, all 16 components, and T^0_0 = 1/(2 rho^4) > 0, at every (sample, point) pair')
    chk('bit', ok_var, 'variational stress: delta (-(1/2) Sum_a F^a ^ *F^a) = h^a ^ tau_a under the frame variation (b3_matter.matter_variation) with tau = -T exactly, 2 points (b3\'s lambda = -1 of the Maxwell field)')
    chk('bit', ok_dsf, 'the Yang-Mills equation on the curved frame (form route): D_bivector(A, *_e F) = 0 at the point with the star of the RN frame, every pair (*F != 0)')
    chk('bit', ok_cov, 'covariant route: nabla^a F^C_ab + (1/2) f_AB^C A^A_a F^B_ab = 0 at every pair, nabla from the engine\'s omega (A3 closed form) and D_two_index (h table)')
    print('    finding: with omega = 0 the divergence of this purely magnetic hedgehog is %s at every pair: the omega terms drop out of nabla^a F_ab here, so the divergence alone does not read the connection' % ('also 0' if not ok_om0 else 'not 0'))
    chk('bit==std', ok_nab and ok_nabnz, 'nabla_c F^C_ab, the frame-covariant derivative of each colour: engine (D_two_index with the engine\'s omega, h table) = Christoffel route (coordinates, then frame components), %d components at 3 points; some nabla_k F_0j (k spatial) is non-zero, where omega^b_0 acts' % n_nab)
    chk('ctl', ok_nab0, 'control: omega = 0 in the engine route breaks that comparison')
    chk('bit', lv == [F(-4)], 'E_a(c=0) = lambda T_a with ONE lambda = (%s) s/P^2 for all components, 4 samples (M, s) and the points of c3_rn (P = 1): E_a = -(4 s/P^2) T_a' % lv)
    chk('bit', ok_k, 'so with s = kappa P^2/4 (kappa = 4 s = 1, 3/2, 2/7, 2): E_a + kappa T_a = 0 exactly on all components: a coloured Reissner-Nordstrom frame of the Einstein-Yang-Mills system at these rational points')
    chk('std', ok_std, 'Christoffel route (c1_birkhoff.std_G, exact) = (4 s/P^2) T^mu_nu with the textbook T^mu_nu = Sum_a (-F^(a mu alpha) F^a_nu alpha + (1/4) delta F^a.F^a), F^a from plain derivatives of the jets plus eps A A, every pair')
    chk('ctl', ok_bad, 'control: the wrong charge term (kappa = 2 s, i.e. s = kappa P^2/2) leaves E_a + kappa T_a != 0 at every pair')
    chk('ctl', ok_nh and ok_nhT, 'control: the non-hedgehog field (the Wu-Yang connection with its third colour component removed): D*F != 0 on the frame at 3 points and its stress differs from the monopole\'s')
    chk('ctl', ok_sign, 'control: the stress with the opposite overall sign (+1/2 Sum F a F, the brief\'s sign of the action) has T^0_0 < 0: with it E_a + kappa T_a = 0 would need kappa < 0')
    tick('G')
    finish('YM-GRAV')

def lsum_forms(Gv, forms):
    r = {}
    for x in forms: r = Gv.Fm.add(r, x)
    return r

if __name__ == '__main__': main()
