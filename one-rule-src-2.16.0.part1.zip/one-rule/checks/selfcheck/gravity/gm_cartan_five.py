#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""KPG-CFIVE.  The finite gauge law A -> g^-1 A g + g^-1 dg, F -> g^-1 F g on the five Lie tables on five coordinates.
    python3 gm_cartan_five.py [--fault NODG|GINV|FACT] [--quick]

 The series and the truncation of gm_cartan_finite.py (imported: transform, finite_case, curv_low, exp_series, rand_lambda, deg_le), here with
 g = exp(lambda) truncated at degree 3 (the series to k = 3 and every product truncated at degree 3): A' is exact to degree 3 and F(A') to
 degree 2, so the identity is asserted on every coefficient of degree <= 2.
 Tables: gm_cartan_bianchi.tables() on 5 coordinates: so(1,4) x R^5 (Poincare), so(1,5), so(2,4) (15 generators each), so(3) and so(4) on 5
 coordinates; three random connections per table (strong sampler of a2b_strong_sampling: degree 1, integers -50..50), lambda of degree <= 2
 without constant term (same sampler).
 kpg·17 [bit]  F(g^-1 A g + g^-1 dg) = g^-1 F g on every coefficient of degree <= 2 (g^-1 F g != F there), each table, three connections; the
        infinitesimal law as the t^1 term (lambda -> t lambda): delta A = D_A lambda (engine D_bivector), delta F = (1/2) f F lambda = [F, lambda];
        the first error term sits at degree 3 (so(3) on 5 coordinates, one connection: the degree-3 coefficients differ at truncation 3 and
        agree at truncation 4; degree <= 2 is the same at both).
        [bit==std] the engine's f table = 2 x the structure constants of the matrices L_AB (numpy), each table.
        [std] so(4) as plain 4 x 4 matrices with polynomial entries in the five coordinates (b1lib's plain polynomial code): g = (I - K)(I + K)^-1,
        the Cayley transform of a skew polynomial K, jets of degree 2 at a rational point p; g^T g = I; F'(p) of A' = g^T A g + g^T dg equals
        g^T(p) F(p) g(p) on all components, three connections. [bit==std] the engine's curvature of the Cayley-transformed connection
        (its components on L_A, exact jets to degree 1) = g^T F g at p.
 kpg·18 [ctl] (--fault puts each into the main lines): NODG A -> g^-1 A g without g^-1 dg; GINV g in place of g^-1 in the conjugation; FACT
        1/k! in place of 1/(k+1)! in the series of g^-1 dg: F(A') != g^-1 F g for 3 of 3 connections (so(4) on 5 coordinates); in matrices
        without g^T dg and with g A g^T.
 --quick: one random connection per table and per control in place of three (used for the mutation table only; the shipped log is the full run).
 Engine faults: the script reads the f table (curvature, D_bivector) and d; it reads no h table and no Einstein form."""
import os, sys, random, itertools, time
from math import factorial
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from a2b_strong_sampling import s_form
import gm_cartan_bianchi as CB
import gm_cartan_finite as CF
import numpy as np

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'NODG', 'GINV', 'FACT'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
D = 3; NCO = 5; R50 = 50; SEEDS = (31,) if '--quick' in ARGS else (31, 1031, 2031)
NWORD = {1: 'one random connection', 3: 'three random connections'}[len(SEEDS)]
CNT = [0, 0]
def ck(tag, cond, msg): CNT[0 if cond else 1] += 1; return chk(tag, bool(cond), msg)

# ------------------------------------------------------------------------------------------------ [std] so(m) matrices with polynomial entries in NCO variables
MS = 4; DJ = 2
def M0(): return [[{} for _ in range(MS)] for _ in range(MS)]
def mmul(A, B): return [[lin(*[(F(1), sp_mul(A[i][k], B[k][j], DJ, NCO)) for k in range(MS) if A[i][k] and B[k][j]]) for j in range(MS)] for i in range(MS)]
def madd(A, B, c=1): return [[sp_add(A[i][j], B[i][j], c) for j in range(MS)] for i in range(MS)]
def mT(A): return [[A[j][i] for j in range(MS)] for i in range(MS)]
def mder(A, mu): return [[sp_der(A[i][j], mu) for j in range(MS)] for i in range(MS)]
def mval(A): return [[at0(A[i][j], NCO) for j in range(MS)] for i in range(MS)]
def mconst(Mn): return [[const(NCO, Mn[i][j]) for j in range(MS)] for i in range(MS)]
def ident(): return mconst([[F(int(i == j)) for j in range(MS)] for i in range(MS)])
def minv_series(Mx):
    m0 = mval(Mx); det, m0i = det_inv(m0); assert det != 0
    Ni = mconst(m0i); Nn = madd(Mx, mconst(m0), -1); T = mmul(Ni, Nn); T = [[scale(x, -1) for x in r] for r in T]
    out = Ni; term = Ni
    for _ in range(DJ): term = mmul(T, term); out = madd(out, term)
    return out
def cayley(K): return mmul(madd(ident(), K, -1), minv_series(madd(ident(), K)))
def mat_conn(om, mats, p):
    out = []
    for mu in range(NCO):
        Mx = M0()
        for A, L_ in enumerate(mats):
            q = shift_poly(om[A].get(1 << mu, {}), p, NCO)
            if q: Mx = madd(Mx, [[scale(q, L_[i][j]) for j in range(MS)] for i in range(MS)])
        out.append(Mx)
    return out
def mat_F_at(Am):
    out = {}
    for m, n in itertools.combinations(range(NCO), 2):
        a, b = mval(Am[m]), mval(Am[n]); d1, d2 = mval(mder(Am[n], m)), mval(mder(Am[m], n))
        out[(m, n)] = [[d1[i][j] - d2[i][j] + sum(a[i][k] * b[k][j] - b[i][k] * a[k][j] for k in range(MS)) for j in range(MS)] for i in range(MS)]
    return out
def mat_transform(Am, g, mode=None):
    gt = mT(g); out = []
    for mu in range(NCO):
        conj = mmul(mmul(gt, Am[mu]), g) if mode != 'GINV' else mmul(mmul(g, Am[mu]), gt)
        out.append(conj if mode == 'NODG' else madd(conj, mmul(gt, mder(g, mu))))
    return out
def conj_at(Fd, g0):
    gt = [[g0[j][i] for j in range(MS)] for i in range(MS)]
    mm_ = lambda X, Y: [[sum(X[i][k] * Y[k][j] for k in range(MS)) for j in range(MS)] for i in range(MS)]
    return {k: mm_(mm_(gt, v), g0) for k, v in Fd.items()}

def main():
    head('KPG-CFIVE: the finite gauge law on the five Lie tables on five coordinates, g truncated at degree %d' % D + (' [fault %s]' % FAULT if FAULT else ''))
    tabs = [t for t in CB.tables() if t[2] == NCO]; assert len(tabs) == 5
    names = []
    for name, sq, nc, base, s in tabs:
        L = Lie(sq); Gv = Grav(nc, L); G = L.G; names.append(name)
        mats = CB.so_mats(sq, L.gens); c, jres = CB.std_structure(mats)
        f_ok = all(abs(2 * c[A, B, C] - (L.f[(A, B)][1] if (A, B) in L.f and L.f[(A, B)][0] == C else 0)) < 1e-12 for A in range(G) for B in range(G) for C in range(G))
        ok = True; nt = True
        for sd in SEEDS:
            rng = random.Random(sd + 100 * nc + len(sq)); A = [s_form(rng, nc, 1, 1, R50) for _ in range(G)]; lam = CF.rand_lambda(rng, nc, G)
            o, t_, _, _, _ = CF.finite_case(Gv, A, lam, nc, D, FAULT); ok &= o; nt &= t_
        ck('bit==std', f_ok and jres < 1e-12, '%s: the engine\'s f table (%d generators) = 2 x the structure constants of the matrices L_AB (numpy)' % (name, G))
        ck('bit', ok and nt, '%s: F(g^-1 A g + g^-1 dg) = g^-1 F g on every coefficient of degree <= %d, g = exp(lambda) truncated at degree %d, %s (g^-1 F g != F there)' % (name, D - 1, D, NWORD))
        rng = random.Random(7 + nc + len(sq)); A = [CF.pad(s_form(rng, nc, 1, 1, R50), nc) for _ in range(G)]
        lam0 = CF.rand_lambda(rng, nc, G); lam = [CF.times_t(CF.pad(x, nc), nc) for x in lam0]
        with trunc(nc, xdeg=D, lam=1):
            Ap = CF.transform(Gv, lam, A, D, FAULT); Fc = Gv.curvature(A); Fp = CF.exp_series(Gv, lam, Fc, lambda k: F(1, factorial(k)), D)
        lp = [CF.pad(x, nc) for x in lam0]
        with trunc(nc, xdeg=D, lam=0):
            DL = Gv.D_bivector(A, lp); br = [{} for _ in range(G)]
            for (P, Q), (C, f) in L.f.items(): br[C] = Gv.Fm.add(br[C], Gv.Fm.wedge(Fc[P], lp[Q]), F(f, 2))
        inf_ok = all(CF.t_part(Ap[C], nc, 1) == {m: q for m, q in DL[C].items() if q} and CF.t_part(Fp[C], nc, 1) == {m: q for m, q in br[C].items() if q} and CF.t_part(Ap[C], nc, 0) == A[C] for C in range(G))
        ck('bit', inf_ok and any(DL), '%s: lambda -> t lambda: the t^1 terms of the finite law are delta A = D_A lambda (engine D_bivector) and delta F = (1/2) f F lambda = [F, lambda]' % name)
        tick(name)
    head('the degree of the error term (so(3) on 5 coordinates, one connection) [bit]')
    L = Lie([-1] * 3); Gv = Grav(NCO, L); rng = random.Random(99); A = [s_form(rng, NCO, 1, 1, R50) for _ in range(3)]; lam = CF.rand_lambda(rng, NCO, 3)
    ok3, _, Ap3, Fp3, _ = CF.finite_case(Gv, A, lam, NCO, D); ok4, _, Ap4, Fp4, _ = CF.finite_case(Gv, A, lam, NCO, D + 1)
    with trunc(NCO, xdeg=D): Ffull3 = Gv.curvature(Ap3)
    dD = lambda X: {m: q for m, q in ((m, {k: v for k, v in p.items() if sum(k) == D}) for m, p in X.items()) if q}
    low_same = all(CF.deg_le(Fp3[C], D - 1, NCO) == CF.deg_le(Fp4[C], D - 1, NCO) for C in range(3))
    err_at = any(dD(Ffull3[C]) != dD(Fp3[C]) for C in range(3)); fix_at = all(CF.curv_low(Gv, Ap4, D, NCO)[C] == CF.deg_le(Fp4[C], D, NCO) for C in range(3))
    ck('bit', ok3 and ok4 and low_same and err_at and fix_at, 'truncation at degree %d: F(A\') = g^-1 F g on degree <= %d, the degree-%d coefficients differ (the first error term); at truncation %d they agree on degree <= %d; degree <= %d is the same at both' % (D, D - 1, D, D + 1, D, D - 1))
    tick('error term')
    head('controls: the wrong versions of the finite law (so(4) on 5 coordinates, %s) [ctl]' % NWORD)
    name, sq, nc, base, s = [t for t in tabs if t[0].startswith('so(4)')][0]; L = Lie(sq); Gv = Grav(nc, L)
    for fl, what in (('NODG', 'A -> g^-1 A g without g^-1 dg'), ('GINV', 'g in place of g^-1 in the conjugation (e^{+ad lambda} A)'), ('FACT', '1/k! in place of 1/(k+1)! in the series of g^-1 dg')):
        bad = 0
        for sd in SEEDS:
            rng = random.Random(sd + 100 * nc + len(sq)); A = [s_form(rng, nc, 1, 1, R50) for _ in range(L.G)]; lam = CF.rand_lambda(rng, nc, L.G)
            bad += int(not CF.finite_case(Gv, A, lam, nc, D, fl)[0])
        ck('ctl', bad == len(SEEDS), '%s: %s: F(A\') != g^-1 F g for %d of %d connections' % (name, what, bad, len(SEEDS)))
    tick('controls')
    head('[std] plain so(4) matrices on 5 coordinates: g = Cayley transform of a skew polynomial K, jets of degree 2 at p; [bit==std] the engine\'s curvature of the transformed connection')
    sq4 = [-1] * 4; L4 = Lie(sq4); G4 = Grav(NCO, L4); mats = CB.so_mats(sq4, L4.gens); p = [F(1, 2), F(-2, 3), F(3, 4), F(1, 5), F(-1, 3)]
    pairs = [tuple(i for i in range(4) if g >> i & 1) for g in L4.gens]
    okS = okO = okB = okSk = True; nodg = ginv = 0
    for sd in SEEDS:
        rng = random.Random(sd + 5); om = [s_form(rng, NCO, 1, 1, R50) for _ in range(L4.G)]
        K = M0()
        for A_, Lm in enumerate(mats):
            q = const(NCO, F(1, 2) if A_ == 0 else (F(1, 3) if A_ == L4.G - 1 else 0))
            for j in range(NCO): q = sp_add(q, scale(var(NCO, j), F(rng.randint(-5, 5), rng.randint(1, 4))))
            for j, k in itertools.combinations_with_replacement(range(NCO), 2): q = sp_add(q, scale(sp_mul(var(NCO, j), var(NCO, k), 2, NCO), F(rng.randint(-5, 5), rng.randint(1, 4))))
            K = madd(K, [[scale(q, Lm[i][j]) for j in range(MS)] for i in range(MS)])
        g = cayley(K); g0 = mval(g)
        okO &= all(madd(mmul(mT(g), g), ident(), -1)[i][j] == {} for i in range(MS) for j in range(MS)) and g0 != [[F(int(i == j)) for j in range(MS)] for i in range(MS)]
        Am = mat_conn(om, mats, p); Fd = mat_F_at(Am); want = conj_at(Fd, g0)
        Ap = mat_transform(Am, g, FAULT if FAULT in ('NODG', 'GINV') else None)
        okS &= mat_F_at(Ap) == want and any(any(x != 0 for r in v for x in r) for v in want.values())
        nodg += int(mat_F_at(mat_transform(Am, g, 'NODG')) != want); ginv += int(mat_F_at(mat_transform(Am, g, 'GINV')) != want)
        lo1 = lambda q: {k: v for k, v in q.items() if sum(k) <= 1}
        okSk &= all(lo1(sp_add(Ap[mu][i][j], Ap[mu][j][i])) == {} for mu in range(NCO) for i in range(MS) for j in range(MS))
        omp = [{1 << mu: q for mu in range(NCO) for q in [lo1(Ap[mu][b][a])] if q} for (a, b) in pairs]
        with trunc(NCO, xdeg=1): Fe = G4.curvature(omp)
        okB &= all([[sum(at0(Fe[C].get((1 << m) | (1 << n), {}), NCO) * mats[C][i][j] for C in range(L4.G)) for j in range(MS)] for i in range(MS)] == want[(m, n)] for (m, n) in want)
    ck('std', okO, 'g = (I - K)(I + K)^-1 is orthogonal on the jets to degree 2 (g^T g = I) and g(p) != I, %d random skew K in five variables' % len(SEEDS))
    ck('std', okS, 'F\'(p) of A\' = g^T A g + g^T dg equals g^T(p) F(p) g(p) on all 10 components, %s (exact, plain 4 x 4 matrices, five coordinates)' % NWORD)
    ck('ctl', nodg == len(SEEDS) and ginv == len(SEEDS), 'matrices: without g^T dg (%d of %d) and with g A g^T in place of g^T A g (%d of %d) the transformed curvature is not g^T F g' % (nodg, len(SEEDS), ginv, len(SEEDS)))
    ck('bit==std', okSk and okB, 'the engine\'s curvature of the Cayley-transformed connection (A\' skew on its exact jets to degree 1, its components on L_A) = g^T F g of the matrix route at p, %s' % NWORD)
    tick('std')
    print('\nchecks: %d ok, %d FAIL' % tuple(CNT))

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('KPG-CFIVE' + ('-' + FAULT if FAULT else ''))
