#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSA-LT.  Frame dragging at a second radius: a spin carried along a circular equatorial geodesic of Kerr at M/r = 16/169 (M = 16, r = 169) turns by
 2 pi (1 - sqrt(1 - 3M/r + 2a sqrt(M/r^3))) per orbit, and its a-linear term is Schiff's -2 pi (a/r) sqrt(M/r) times 1/sqrt(1 - 3M/r) = 13/11.
    python3 gsa_lense_thirring.py [--fault OMEGA|RATE|SCHIFF|RADIUS]

 Method: gm_lense_thirring's (the transport of gm_gyroscope over exact power series in proper time to order tau^2 with the engine's A3 omega and h table; the helical
 Killing orbit d_t + Omega d_phi; dual numbers for first order in a), with the radius as a parameter.  The exact route needs sqrt(M), sqrt(r) and sqrt(1 - 3M/r)
 rational: M/r = 16/169 gives sqrt(M/r) = 4/13, sqrt(1 - 3M/r) = 11/13, W = sqrt(M/r^3) = 4/2197, Omega = sqrt(M)/(r^(3/2) + a sqrt(M)) = 4/(2197 + 4a) (recalled).
 (M/r = 16/75 and 1/9 have an irrational sqrt(M/r) or sqrt(1 - 3M/r): they run on the float route only.)
 u^t is rational when 1 - 3M/r + 2aW = s^2: a = 1157/128, -1131/128, 2301/512 give s = 45/52, 43/52, 89/104 and turns 1 - s = 7/52, 9/52, 15/104 of 2 pi;
 a = 0 gives 2/13 (4 pi/13 per orbit).
 [bit]  (1) a = 0 and the three exact a: the geodesic, u^t from the frame against (1 + aW)/sqrt(1 - 3M/r + 2aW) (recalled), the proper rate w = W, the turn per orbit;
        (2) first order in a: the frame of gm_lense_thirring.kerr_frame_a1 at p = (169, 0, 0), E_a = 0 at orders a^0 and a^1, the turn (2/13 + COEF a) of 2 pi with
            COEF = -(4/11)/r = Schiff's -(4/13)/r times 13/11; the reversed spin gives +(4/11)/r.
 [std]  scipy, Boyer-Lindquist (gm_lense_thirring.bl_run): the turn at M/r = 16/169 for a/M = 0, +-1/5 against the closed form; the a-derivative at a = 0 by central
        differences at M/r = 16/169, 16/75 and 1/9 against -(M/r) sqrt(M/r)/sqrt(1 - 3M/r): Schiff's -(M/r) sqrt(M/r) times 13/11, 5/3, sqrt(3/2).
 Controls (--fault puts each into the main check and exits 1): OMEGA the Kepler W in place of Omega; RATE the orbital Omega as the proper rate; SCHIFF Schiff's
        coefficient; RADIUS the factor 14/11 of the first radius (M/r = 25/196) at this radius.
 Not here: a polar orbit.  It is not an orbit of a Killing field of the frame (no helical symmetry: the orbital plane is dragged), so the exact series route does not
        apply, and a float route needs the full Kerr geodesic in r and theta and a frame tied to infinity; the polar case of Schiff's formula stays recalled."""
import os, sys, time, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_kerr as K
import gm_gyroscope as GY
_argv = sys.argv; sys.argv = sys.argv[:1]
import gm_lense_thirring as LT                                                   # its helpers (frame_vec, KZ, orient_J, fit_rate, spin_run, transport_dual, ...); its own flags off
sys.argv = _argv

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'OMEGA', 'RATE', 'SCHIFF', 'RADIUS'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N = 4; SQ = LORENTZ(4)
M0, R0 = F(16), F(169); SM, SR = F(4), F(13); W = SM / (SR ** 3); UT0 = F(13, 11); SQ3 = F(11, 13)    # sqrt(M), sqrt(r), W = sqrt(M/r^3), 1/sqrt(1 - 3M/r), sqrt(1 - 3M/r)
AV = [(F(1157, 128), F(45, 52)), (F(-1131, 128), F(43, 52)), (F(2301, 512), F(89, 104))]
COEF = -(SM / SR) * UT0 / R0; COEF_SCHIFF = -(SM / SR) / R0; COEF_FIRST = -(SM / SR) * F(14, 11) / R0
def omega_kerr(a): return SM / (SR ** 3 + a * SM)
def ut_recalled(a, s): return (1 + a * W) / s

def exact_orbit(a, Om, a_l=None):
    """gm_lense_thirring.exact_orbit at (M, r) = (16, 169): the frame at p = (r, a, 0), the carried chi = d_t + Om d_phi"""
    p = (R0, a, F(0)); e, E, _, dat = K.kerr_ks_frame_jet(p, M0, a, R0, a_l=a_l)
    Lie_ = Lie(SQ); Gv = Grav(N, Lie_); S_ = koszul_S(N, SQ, Lie_)
    om = omega_closed_form(Gv, e, S_, N, 1)[0]
    chi = [F(1), -Om * a, Om * R0, F(0)]; c0 = LT.frame_vec(e, chi)
    d, U, _ = GY.transport(Gv, om, E, c0, [])
    Rz = GY.mat_series(LT.KZ, Om); upred = GY.mser_apply(Rz, c0)
    orbit = [[F(0), F(1), F(0)], [F(0), -a * Om, -R0 * Om * Om / 2], [F(0), R0 * Om, -a * Om * Om / 2], [F(0)] * 3]
    geo = all(U[c] == upred[c] for c in range(N)) and all(d[mu] == orbit[mu] for mu in range(N))
    return dict(Gv=Gv, om=om, e=e, E=E, c0=c0, geo=geo, nrm=GY.eta(c0, c0))

def main():
    head('GSA-LT: the spin on a circular equatorial geodesic of the Kerr frame (g2_kerr) at M = 16, r = 169' + (' [fault %s]' % FAULT if FAULT else ''))
    # ================================================================================== (1) a = 0 and exact a
    head('(1) a = 0 and the exact orbits a = 1157/128, -1131/128, 2301/512 (u^t rational) [bit]')
    o0 = exact_orbit(F(0), omega_kerr(0)); ut0 = K.rat_sqrt(1 / o0['nrm'])
    s0 = LT.spin_run(o0, omega_kerr(0), ut0, W)
    chk('bit', o0['geo'] and ut0 == UT0 and s0['okJ'] and s0['okS'] and s0['w'] == W and s0['turn'] == F(2, 13) == 1 - 1 / UT0,
        'a = 0: d_t + Omega d_phi (Omega = %s) carried as a geodesic tangent to order tau^2, u^t = %s = 1/sqrt(1 - 3M/r), the frame vectors R_z(Omega u^t tau) exp(-w tau J) S(0) with w = %s; turn %s x 2 pi = 4 pi/13 = 2 pi (1 - sqrt(1 - 3M/r))' % (omega_kerr(0), ut0, s0['w'], s0['turn']))
    for a, s in AV:
        Om = omega_kerr(a) if FAULT != 'OMEGA' else W
        o = exact_orbit(a, Om)
        ut = K.rat_sqrt(1 / o['nrm']) if o['nrm'] > 0 else None
        ok_geo = o['geo'] and ut is not None and ut == ut_recalled(a, s)
        sr = LT.spin_run(o, Om, ut, W if FAULT != 'RATE' else Om) if ut is not None else None
        chk('bit', ok_geo and sr is not None and sr['okJ'] and sr['okS'] and sr['w'] == W and sr['turn'] == 1 - s,
            'a = %s: Omega = %s is a geodesic of the frame to order tau^2; |chi|^2 = %s, u^t = %s = (1 + aW)/sqrt(1 - 3M/r + 2aW) (recalled); w = sqrt(M/r^3) = %s; turn 1 - w/(Omega u^t) = %s of 2 pi = 1 - sqrt(1 - 3M/r + 2a sqrt(M/r^3))' % (
                a, Om, o['nrm'], ut, sr['w'] if sr else None, sr['turn'] if sr else None))
    a1 = AV[0][0]
    chk('ctl', not exact_orbit(a1, W)['geo'], 'a = %s: the Kepler W = sqrt(M/r^3) in place of Omega: d_t + W d_phi is not carried as a geodesic tangent' % a1)
    o1 = exact_orbit(a1, omega_kerr(a1)); ut1 = K.rat_sqrt(1 / o1['nrm']); sc = LT.spin_run(o1, omega_kerr(a1), ut1, omega_kerr(a1))
    chk('ctl', not sc['okS'], 'a = %s: the orbital rate Omega in place of w = sqrt(M/r^3) does not match the carried frame vectors' % a1)
    tick('part 1')
    # ================================================================================== (2) first order in a
    head('(2) first order in a: the Kerr-Schild frame to O(a) at p = (169, 0, 0), the engine\'s Einstein form, the transport over dual numbers [bit]')
    p5 = (R0, F(0), F(0)); res = {}; Du, du = LT.Du, LT.du
    for sgn in (1, -1):
        e5, E5 = LT.kerr_frame_a1(p5, M0, R0, sgn)
        Lie_ = Lie(SQ); Gv = Grav(N, Lie_); S_ = koszul_S(N, SQ, Lie_)
        with trunc(N, xdeg=None, lam=1):
            om5 = omega_closed_form(Gv, e5, S_, LT.NV5, 1)[0]
            if sgn == 1:
                with trunc(N, xdeg=1): R5 = Gv.curvature(om5); Ea, _ = Gv.einstein(None, e5, R5, F(0))
                comp = [Ea[a].get(15 ^ (1 << mu), {}).get(k, 0) for a in range(N) for mu in range(N) for k in ((0, 0, 0, 0, 0), (0, 0, 0, 0, 1))]
                Rnz = any(R5[A].get(m, {}).get((0, 0, 0, 0, 1), 0) for A in range(Gv.G) for m in R5[A])
                chk('bit', all(v == 0 for v in comp) and Rnz, 'the frame to first order in a solves E_a(0) = 0 on all 16 components at p = (169, 0, 0) at orders a^0 and a^1 (the curvature has a non-zero a^1 part)')
        omd = [{m: LT.to_dual(q) for m, q in om5[A].items()} for A in range(Gv.G)]; Ed = [[LT.to_dual(E5[mu][a]) for a in range(N)] for mu in range(N)]
        ed = [{m: LT.to_dual(q) for m, q in e5[A].items()} for A in range(N)]
        Om = Du(W, -sgn * W * W)
        chi = [Du(1), Du(), R0 * Om, Du()]; c0 = [sum((ed[A].get(1 << mu, {}).get((0, 0, 0, 0), Du()) * chi[mu] for mu in range(N)), Du()) for A in range(N)]
        ut = LT.dsqrt_inv(GY.eta(c0, c0)); u0 = [ut * x for x in c0]
        utr = Du(UT0, UT0 * sgn * W * (1 - UT0 * UT0))
        J, z = LT.orient_J(u0); basis = [[du(int(i == a)) for i in range(N)] for a in range(N)]
        d, U, V = LT.transport_dual(Gv, omd, Ed, u0, basis)
        rot = Om * ut; Rz = GY.mat_series(LT.KZ, rot)
        geo = all(U[c] == GY.mser_apply(Rz, u0)[c] for c in range(N))
        orbit = [[Du(), ut, Du()], [Du(), Du(), -R0 * rot * rot / 2], [Du(), R0 * rot, Du()], [Du()] * 3]
        geo &= all(d[mu] == orbit[mu] for mu in range(N))
        w = LT.fit_rate(V, J, rot); pred = GY.mser_mul(Rz, GY.mat_series(J, -w))
        okS = all(V[a][c] == GY.mser_apply(pred, basis[a])[c] for a in range(N) for c in range(N))
        res[sgn] = (geo, ut == utr, okS, w, 1 - w / rot)
    geo, okut, okS, w, turn = res[1]
    chk('bit', geo and okut and okS and w == Du(W, 0), 'first order in a: d_t + Omega d_phi with Omega = W (1 - aW) carried as a geodesic tangent to order tau^2; u^t = %s (the recalled form to first order); the proper rate w = %s has no a-linear part' % (utr, w))
    target = {None: COEF, 'SCHIFF': COEF_SCHIFF, 'RADIUS': COEF_FIRST}.get(FAULT, COEF)
    chk('bit', turn == Du(F(2, 13), target), 'the turn per orbit = (%s) of 2 pi: the a-linear coefficient is -(4/11)/r = -2 pi (a/r) sqrt(M/r)/sqrt(1 - 3M/r) per orbit at M/r = 16/169' % turn)
    chk('ctl', COEF / COEF_SCHIFF == UT0 == F(13, 11) and COEF_FIRST != COEF, 'Schiff\'s -(4/13)/r differs from the engine\'s -(4/11)/r by 13/11 = 1/sqrt(1 - 3M/r) at this radius (14/11 at M/r = 25/196, gm_lense_thirring): the factor follows the radius')
    geo_r, okut_r, okS_r, w_r, turn_r = res[-1]
    chk('bit', geo_r and okut_r and okS_r and w_r == Du(W, 0) and turn_r == Du(F(2, 13), -COEF), 'the spin reversed: the same proper rate and the a-linear coefficient +(4/11)/r: the dragging term is odd in a')
    tick('part 2')
    # ================================================================================== (3) [std]
    head('(3) the float route: Boyer-Lindquist Christoffel symbols, geodesic and parallel transport over one orbit (scipy) [std]')
    Mr = 16 / 169; tol = 1e-8
    for aM in (0.0, 0.2, -0.2):
        tn, rdev = LT.bl_run(Mr, aM); cf = LT.closed_turn(Mr, aM)
        chk('std', abs(tn - cf) < tol and rdev < 1e-9, 'M/r = 16/169, a/M = %+.1f: turn %.12f of 2 pi = 1 - sqrt(1 - 3M/r + 2a sqrt(M/r^3)) = %.12f (|diff| < 1e-8); r stays on the circle (%.1e)' % (aM, tn, cf, rdev))
    tA, _ = LT.bl_run(Mr, float(AV[0][0] / M0))
    chk('bit==std', abs(tA - float(1 - AV[0][1])) < tol, 'a/M = 1157/2048: the scipy turn %.12f = the engine\'s exact 7/52 = %.12f' % (tA, 7 / 52))
    h = 1 / 500
    for Mr_, lab, fac in ((16 / 169, '16/169', 13 / 11), (16 / 75, '16/75', 5 / 3), (1 / 9, '1/9', math.sqrt(1.5))):
        tp, _ = LT.bl_run(Mr_, h); tm, _ = LT.bl_run(Mr_, -h); der = (tp - tm) / (2 * h)
        sch = -Mr_ * math.sqrt(Mr_); want = sch * fac
        chk('std', abs(der - want) < 1e-4 * abs(want) and abs(der - sch) > 1e-2 * abs(sch), 'M/r = %s: d(turn/2 pi)/d(a/M) at a = 0 by central differences = %.8f = Schiff\'s -(M/r) sqrt(M/r) = %.8f times 1/sqrt(1 - 3M/r) = %.6f (1e-4 relative; %.1f%% from Schiff)' % (
            lab, der, sch, fac, 100 * abs(der / sch - 1)))
        if lab == '16/169':
            chk('bit==std', abs(der - float(COEF * M0)) < 1e-4 * abs(der), 'M/r = 16/169: the scipy derivative = the engine\'s exact -(4/11)(M/r) = %.8f' % float(COEF * M0))
    tick('part 3')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GSA-LT' + ('-' + FAULT if FAULT else ''))

if __name__ == '__main__': main()
