#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-CYM.  The Yang-Mills equation in four dimensions is invariant under the conformal Killing fields: A + eps i_xi F solves D*F = 0 to first order in eps.
    python3 gm_conformal_ym.py [--fault NONCONF|WEIGHT|MASS|GAUGE]

 Derivation: i_xi F = L_xi A - D_A(i_xi A), with L_xi = d i_xi + i_xi d on each colour. The flow of a conformal Killing field keeps D*F = 0 in four dimensions (the star on 2-forms is
 conformally invariant), so L_xi A solves the linearised equation; an infinitesimal gauge transformation D_A lambda solves it at every solution; so does their difference i_xi F, the
 gauge-covariant Lie derivative used here.
 Fields: xi_b = 2 (b.x) x - x^2 b for b = (1/2, -1, 1/2, 3/2) (gm_conformal's), (1, 0, -2, 1/3), (-3/4, 1/5, 1, -1), and the dilatation x^mu d_mu; the BPST instanton (Euclidean, so(3) of
 Lie([-1]*3) and the su(2) ideal of so(4)) and the Wu-Yang monopole (signature (+,-,-,-)) of ym_solutions.py, as exact jets of degree 3 at rational points.
 Degrees: the value at the point of D*F(A + eps a) needs a to degree 2, hence F and A to degrees 2 and 3; each product is truncated where its result is needed (b1lib.trunc; eps is the
 bookkeeping slot, kept to eps^1: the eps^0 part is D*F(A), the eps^1 part the linearised equation).
 [bit]  the engine's curvature (f table), D_bivector and d, g2_hodge's flat bit-rule star, g2_forms_calc.interior and .lie: the eps^0 and eps^1 parts vanish at every point and xi;
        L_xi A - i_xi F = D_A(i_xi A) on the jets to degree 2; A + eps L_xi A solves to first order as well; the conformal Killing equation L_xi eta = (1/2)(d.xi) eta (engine d).
 [std]  numpy with su(2) matrices T_a = -(i/2) sigma_a: i_xi F from the closed forms; the linearised operator by a five-point stencil in eps (exact for the cubic dependence on eps) of
        D^mu F_mu nu computed by nested five-point differences (h = 1e-3 inside, 1e-2 outside); the conformal Killing equation by central differences.
 [bit==std] i_xi F at the points.
 Controls (--fault puts each into the main check): NONCONF a random quadratic xi (not conformal Killing); WEIGHT the dilatation weight wrongly added (i_xi F + A, L_xi A + A);
 MASS the Proca plane wave (k^2 = 1): L_xi A solves Maxwell for the null wave at the point and fails the massive equation for the massive wave; GAUGE the identity with the wrong sign."""
import os, sys, random, itertools, math, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import g2_forms_calc as FC
import ym_solutions as YS
import numpy as np

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'NONCONF', 'WEIGHT', 'MASS', 'GAUGE'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N = 4; NV = 5; DEG = 3; Z5 = (0,) * 5; E1 = (0, 0, 0, 0, 1)
EUC = [1, 1, 1, 1]; LOR = [1, -1, -1, -1]
BS = [[F(1, 2), F(-1), F(1, 2), F(3, 2)], [F(1), F(0), F(-2), F(1, 3)], [F(-3, 4), F(1, 5), F(1), F(-1)]]
BPTS = [([F(1, 2), F(-1, 3), F(2, 3), F(1)], F(1)), ([F(-1), F(1, 4), F(0), F(-1, 2)], F(4, 9))]
WPTS = [[F(1, 3), F(1), F(-1, 2), F(2, 3)], [F(0), F(-1, 2), F(3, 4), F(1)]]

# ------------------------------------------------------------------------------------------------ jets (degree 3, eps slot 4 untouched)
def jm(a, b, d=DEG): return sp_mul(a, b, d, N)
def xs_jet(p): return [lin((F(1), const(NV, p[i])), (F(1), var(NV, i))) for i in range(4)]
def inv_quad(p, c, slots):
    """1/(sum over slots of x_i^2 + c) around p, exact to degree 3"""
    Q0 = sum(p[i] * p[i] for i in slots) + c; X = {i: var(NV, i) for i in slots}
    u = lin(*[(2 * p[i] / Q0, X[i]) for i in slots], *[(1 / Q0, jm(X[i], X[i])) for i in slots])
    out = const(NV, 1); t = const(NV, 1)
    for k in range(1, DEG + 1): t = jm(t, u); out = padd(out, t, (-1) ** k)
    return scale(out, 1 / Q0)
def bpst_A(p, rho2):
    """A^a = 2 eta^a_mu nu x^nu/(x^2 + rho^2) dx^mu (ym_solutions' regular gauge)"""
    eta = YS.eta_thooft(); inv = inv_quad(p, rho2, (0, 1, 2, 3)); X = xs_jet(p); A = []
    for a in range(3):
        form = {}
        for mu in range(4):
            num = lin(*[(2 * eta[a][mu][nu], X[nu]) for nu in range(4) if eta[a][mu][nu]])
            if num: form[1 << mu] = jm(num, inv)
        A.append(form)
    return A
def wuyang_A(p):
    """A^a = eps_aij x_j/r^2 dx^i (ym_solutions' Wu-Yang field)"""
    inv = inv_quad(p, F(0), (1, 2, 3)); X = xs_jet(p); A = []
    for a in range(3):
        form = {}
        for i in range(3):
            num = lin(*[(F(YS.eps3(a, i, j)), X[j + 1]) for j in range(3) if YS.eps3(a, i, j)])
            if num: form[1 << (i + 1)] = jm(num, inv)
        A.append(form)
    return A
def xi_K(b, p, sq):
    X = xs_jet(p); bx = lin(*[(F(sq[m]) * b[m], X[m]) for m in range(4)]); x2 = lin(*[(F(sq[m]), jm(X[m], X[m])) for m in range(4)])
    return [lin((F(2), jm(bx, X[m])), (-b[m], x2)) for m in range(4)]
def xi_D(p): return xs_jet(p)
def xi_rand(p, seed=139):
    """a random quadratic vector field (fixed seed), not conformal Killing"""
    rng = random.Random(seed); X = xs_jet(p); out = []
    for m in range(4):
        t = const(NV, F(rng.randint(-3, 3), rng.randint(1, 3)))
        for i in range(4): t = padd(t, X[i], F(rng.randint(-3, 3), rng.randint(1, 3)))
        for i, j in itertools.combinations_with_replacement(range(4), 2): t = padd(t, jm(X[i], X[j]), F(rng.randint(-3, 3), rng.randint(1, 3)))
        out.append(t)
    return out
def deg_le(X, d): return {m: q for m, q in ((m, {k: v for k, v in p.items() if sum(k[:4]) <= d}) for m, p in X.items()) if q}
def eps_shift(X): return {m: {k[:4] + (k[4] + 1,): v for k, v in p.items()} for m, p in X.items()}
def conformal_killing(Gv, xi, sq):
    """[bit] (L_xi eta)_{mu nu} = eta_mu l d_nu xi^l + eta_l nu d_mu xi^l (engine d) against (1/2)(d.xi) eta"""
    dxi = [Gv.Fm.d({0: xi[l]}) for l in range(N)]; D = [[dxi[l].get(1 << nu, {}) for nu in range(N)] for l in range(N)]
    Km = [[lin((F(sq[mu]), D[mu][nu]), (F(sq[nu]), D[nu][mu])) for nu in range(N)] for mu in range(N)]
    div = lin(*[(F(1), D[l][l]) for l in range(N)])
    return all(Km[m][n] == (scale(div, F(sq[m], 2)) if m == n else {}) for m in range(N) for n in range(N))

# ------------------------------------------------------------------------------------------------ [bit] the linearised equation at the point
def curv_F(Gv, A):
    with trunc(N, xdeg=2): return Gv.curvature(A)
def iota_F(Gv, xi, Fc):
    with trunc(N, xdeg=2): return [FC.interior(Gv, xi, x) for x in Fc]
def ym_eps(Gv, A, a, sq):
    """D*F(A + eps a) at the point: (eps^0 values, eps^1 values) over all colours and components"""
    Fm = Gv.Fm; B = [Fm.add(deg_le(A[C], 2), eps_shift(deg_le(a[C], 2))) for C in range(Gv.G)]
    with trunc(N, xdeg=1, lam=1): FB = Gv.curvature(B); SB = [H.star_comps(x, sq) for x in FB]
    with trunc(N, xdeg=0, lam=1): Y = Gv.D_bivector(B, SB)
    v0 = [p.get(Z5, 0) for C in range(Gv.G) for p in Y[C].values()]; v1 = [p.get(E1, 0) for C in range(Gv.G) for p in Y[C].values()]
    return v0, v1
def lie_A(Gv, xi, A):
    with trunc(N, xdeg=3): return [FC.lie(Gv, xi, x) for x in A]
def gauge_part(Gv, xi, A):
    with trunc(N, xdeg=3): lam = [{0: FC.interior(Gv, xi, x).get(0, {})} for x in A]
    with trunc(N, xdeg=2): return Gv.D_bivector(A, lam)
def nonzero_low(a): return any(deg_le(x, 1) for x in a)

# ------------------------------------------------------------------------------------------------ [std] numpy
EPSN = np.zeros((3, 3, 3))
for _i, _j, _k in itertools.permutations(range(3)): EPSN[_i, _j, _k] = YS.eps3(_i, _j, _k)
ETAN = np.array([[[float(v) for v in r] for r in M] for M in YS.eta_thooft()])
def A_bpst(x, rho2): return 2 * np.einsum('amn,n->am', ETAN, x) / (x @ x + rho2)
def F_bpst(x, rho2): return -4 * ETAN * rho2 / (x @ x + rho2) ** 2
def A_wy(x):
    r2 = x[1:] @ x[1:]; out = np.zeros((3, 4))
    for a in range(3):
        for i in range(3): out[a, i + 1] = sum(EPSN[a, i, j] * x[j + 1] for j in range(3)) / r2
    return out
def F_num(Af, x, h=1e-3):
    dA = np.zeros((3, 4, 4))
    for m in range(4):
        u = np.zeros(4); u[m] = h; dA[:, m, :] = (-Af(x + 2 * u) + 8 * Af(x + u) - 8 * Af(x - u) + Af(x - 2 * u)) / (12 * h)
    Av = Af(x); return dA - np.transpose(dA, (0, 2, 1)) + np.einsum('abc,bm,cn->amn', EPSN, Av, Av)
def ym_num(Af, x, sq, h=1e-2):
    """D^mu F_mu nu = sum_mu sq_mu (d_mu F_mu nu + eps A_mu F_mu nu), nested five-point differences"""
    dF = np.zeros((3, 4, 4, 4))
    for m in range(4):
        u = np.zeros(4); u[m] = h; dF[:, m] = (-F_num(Af, x + 2 * u) + 8 * F_num(Af, x + u) - 8 * F_num(Af, x - u) + F_num(Af, x - 2 * u)) / (12 * h)
    Fx = F_num(Af, x); Av = Af(x); s = np.array([float(v) for v in sq])
    return np.einsum('m,amn->an', s, np.einsum('ammn->amn', dF)) + np.einsum('m,abc,bm,cmn->an', s, EPSN, Av, Fx)
def xi_num(kind, x, sq, b=None, rnd=None):
    if kind == 'K': s = np.array([float(v) for v in sq]); bb = np.array([float(v) for v in b]); return 2 * (bb @ (s * x)) * x - (x @ (s * x)) * bb
    if kind == 'D': return x.copy()
    return rnd(x)
def lin_num(Af, Ffun, xif, x, sq, e=0.1, add_A=False):
    """the eps^1 part of D^mu F_mu nu (A + eps a), a = i_xi F (+ A for the weight control): five-point stencil in eps, exact for a cubic"""
    def a_of(y): return np.einsum('m,amn->an', xif(y), Ffun(y)) + (Af(y) if add_A else 0)
    Y = {c: ym_num(lambda y, c=c: Af(y) + c * e * a_of(y), x, sq) for c in (-2, -1, 1, 2)}
    return (8 * (Y[1] - Y[-1]) - (Y[2] - Y[-2])) / (12 * e)
def ck_num(xif, x, sq, h=1e-4):
    s = np.diag([float(v) for v in sq]); D = np.zeros((4, 4))
    for m in range(4):
        u = np.zeros(4); u[m] = h; D[:, m] = (xif(x + u) - xif(x - u)) / (2 * h)           # D[l, m] = d_m xi^l
    L = s @ D + (s @ D).T; return float(np.abs(L - 0.5 * np.trace(D) * s).max())

def run_field(name, Gv, A_of, pts, sq, xis, Ftag):
    """[bit] per point and xi: eps^0 and eps^1 parts, a != 0; returns the data for the comparisons"""
    ok0 = True; ok1 = True; nz = True; out = []
    for p in pts:
        A = A_of(p); Fc = curv_F(Gv, A)
        for xname, xif in xis:
            xi = xif(p); a = iota_F(Gv, xi, Fc)
            if FAULT == 'WEIGHT': a = [Gv.Fm.add(a[C], deg_le(A[C], 2)) for C in range(Gv.G)]
            v0, v1 = ym_eps(Gv, A, a, sq); ok0 &= all(v == 0 for v in v0); ok1 &= all(v == 0 for v in v1); nz &= nonzero_low(a)
            out.append((p, xname, a, A, Fc, xi))
    chk('bit', ok0, '%s: D*F = 0 at the %d points (the eps^0 part)' % (name, len(pts)))
    chk('bit', ok1 and nz, '%s: A + eps i_xi F solves D*F = 0 to first order in eps (the eps^1 part vanishes on every component) for xi = %s at the %d points; i_xi F != 0' % (name, ', '.join(x for x, _ in xis), len(pts)))
    return out

def main():
    head('GM-CYM: conformal invariance of the Yang-Mills equation' + (' [fault %s]' % FAULT if FAULT else ''))
    L3 = Lie([-1] * 3); G3 = Grav(4, L3); L4 = Lie([-1] * 4); G4 = Grav(4, L4); G0 = Grav(4)
    head('(1) the conformal Killing equation L_xi eta = (1/2)(d.xi) eta [bit]')
    p0 = BPTS[0][0]
    for sq, sname in ((EUC, 'Euclidean'), (LOR, '(+,-,-,-)')):
        chk('bit', all(conformal_killing(G0, xi_K(b, p0, sq), sq) for b in BS) and conformal_killing(G0, xi_D(p0), sq),
            '%s: xi_b = 2 (b.x) x - x^2 b for the three b and the dilatation x^mu d_mu are conformal Killing fields (exact polynomial identity)' % sname)
        chk('ctl', not conformal_killing(G0, xi_rand(p0), sq), '%s: the random quadratic field (seed 139) is not conformal Killing' % sname)
    tick('part 1')
    xis_E = [('K_b%d' % (i + 1), (lambda p, b=b: xi_K(b, p, EUC))) for i, b in enumerate(BS)] + [('the dilatation', xi_D)]
    xis_L = [('K_b%d' % (i + 1), (lambda p, b=b: xi_K(b, p, LOR))) for i, b in enumerate(BS)]
    if FAULT == 'NONCONF': xis_E = [('a random quadratic field', xi_rand)] + xis_E[1:]; xis_L = [('a random quadratic field', xi_rand)] + xis_L[1:]
    head('(2) BPST (so(3), Euclidean), exact jets of degree 3 at 2 rational points [bit]')
    bp = [p for p, _ in BPTS]; rho = {tuple(p): r for p, r in BPTS}
    datB = run_field('BPST so(3)', G3, lambda p: bpst_A(p, rho[tuple(p)]), bp, EUC, xis_E, 'B')
    okI = True; okL = True; badG = True
    for (p, xname, a, A, Fc, xi) in datB:
        if xname == 'the dilatation':
            lamD = any(deg_le({0: FC.interior(G3, xi, A[C]).get(0, {})}, 3) for C in range(3))
            print('    the dilatation on BPST: i_xi A = %s on the jets to degree 3 (eta antisymmetric), so i_xi F = L_xi A there' % ('0' if not lamD else 'not 0')); continue
        if xname not in ('K_b1', 'K_b2'): continue
        La = lie_A(G3, xi, A); Dl = gauge_part(G3, xi, A); sg = -1 if FAULT == 'GAUGE' else 1
        okI &= all(deg_le(G3.Fm.add(La[C], a[C], -1), 2) == deg_le(G3.Fm.scale(Dl[C], sg), 2) and deg_le(Dl[C], 1) for C in range(3))
        badG &= any(deg_le(G3.Fm.add(La[C], a[C], -1), 2) != deg_le(G3.Fm.scale(Dl[C], -1), 2) for C in range(3))
        okL &= all(v == 0 for v in ym_eps(G3, A, La, EUC)[1])
    chk('bit', okI, 'BPST: L_xi A - i_xi F = D_A(i_xi A) on the jets to degree 2 (non-zero), xi = K_b1 and K_b2, 2 points: i_xi F is the Lie derivative up to a gauge transformation')
    chk('ctl', badG, 'BPST: the same identity with the wrong sign, L_xi A - i_xi F = -D_A(i_xi A), fails')
    chk('bit', okL, 'BPST: A + eps L_xi A solves D*F = 0 to first order in eps as well (xi = K_b1 and K_b2, 2 points)')
    p, _, _, A, Fc, _ = datB[0]
    vbad = ym_eps(G3, A, iota_F(G3, xi_rand(p), Fc), EUC)[1]
    chk('ctl', any(v != 0 for v in vbad), 'BPST: xi = the random quadratic field: the eps^1 part is non-zero (%d of %d components)' % (sum(1 for v in vbad if v != 0), len(vbad)))
    aw = [G3.Fm.add(lie_A(G3, xi_D(p), A)[C], deg_le(A[C], 2)) for C in range(3)]; vw = ym_eps(G3, A, aw, EUC)[1]
    chk('ctl', any(v != 0 for v in vw), 'BPST: the dilatation with the wrong weight, L_xi A + A: the eps^1 part is non-zero')
    tick('part 2')
    head('(3) BPST on the su(2) ideal of so(4) [bit]')
    S4, sg4, c4 = YS.so4_ideal(L4); ok4 = S4 is not None; nz4 = True
    p4, r4 = BPTS[0]; A3 = bpst_A(p4, r4)
    if ok4: A4 = YS.embed(A3, S4, 6); F4 = curv_F(G4, A4)
    for xname, xif in (xis_E[:1] + xis_E[3:]) if ok4 else []:
        a4 = iota_F(G4, xif(p4), F4)
        if FAULT == 'WEIGHT': a4 = [G4.Fm.add(a4[C], deg_le(A4[C], 2)) for C in range(6)]
        v0, v1 = ym_eps(G4, A4, a4, EUC); ok4 &= all(v == 0 for v in v0 + v1); nz4 &= nonzero_low(a4)
    chk('bit', ok4 and nz4, 'so(4): the BPST field on the ideal S_a (signs %s, c = %s): D*F = 0 and A + eps i_xi F solves to first order for xi = %s and %s at the point' % (sg4, c4, xis_E[0][0], xis_E[3][0]))
    tick('part 3')
    head('(4) Wu-Yang (signature (+,-,-,-)), exact jets of degree 3 at 2 rational points [bit]')
    datW = run_field('Wu-Yang', G3, wuyang_A, WPTS, LOR, xis_L, 'W')
    pw = WPTS[0]; Aw = wuyang_A(pw); Fw = curv_F(G3, Aw); aD = iota_F(G3, xi_D(pw), Fw)
    print('    the dilatation on the monopole: i_xi F has %s components of degree <= 1 (the field is scale invariant: a check of nothing, not counted)' % ('no non-zero' if not nonzero_low(aD) else 'non-zero'))
    vbw = ym_eps(G3, Aw, iota_F(G3, xi_rand(pw), Fw), LOR)[1]
    chk('ctl', any(v != 0 for v in vbw), 'Wu-Yang: xi = the random quadratic field: the eps^1 part is non-zero')
    tick('part 4')
    head('(5) the massive term (abelian, exact jets): a null wave and a Proca wave cos(k.x) dy, xi = K_b1 [bit] [ctl]')
    def wave(k, p):
        kd = lin(*[(F(LOR[m]) * k[m], var(NV, m)) for m in range(4)]); return {1 << 2: lin((F(1), const(NV, 1)), (F(-1, 2), jm(kd, kd)))}
    def dsd(X):
        with trunc(N, xdeg=2): return G0.Fm.d(H.star_comps(G0.Fm.d(X), LOR))
    def at_pt(X, d=0): return [q for m, p_ in X.items() for k, q in p_.items() if sum(k[:4]) <= d and q != 0]
    km, pm_ = [F(5, 4), F(3, 4), F(0), F(0)], [F(3, 4), F(5, 4), F(1, 2), F(-1, 3)]           # k.k = 1, k.p = 0
    kn, pn = [F(1), F(1), F(0), F(0)], [F(1, 2), F(1, 2), F(1, 2), F(-1, 3)]                   # k.k = 0, k.p = 0
    Am, An = wave(km, pm_), wave(kn, pn)
    sgn = [s for s in (1, -1) if not at_pt(G0.Fm.add(dsd(Am), H.star_comps(Am, LOR), s), 1)]
    chk('bit', len(sgn) == 1 and not at_pt(dsd(An), 1) and at_pt(dsd(Am), 1), 'the null wave solves d*dA = 0 and the wave with k^2 = 1 solves d*dA %s *A = 0 (one sign, read from the wave) on the jets to degree 1; it does not solve Maxwell' % ('+' if sgn and sgn[0] > 0 else '-'))
    s_ = sgn[0] if sgn else 1
    def proca(X): return G0.Fm.add(dsd(X), H.star_comps(X, LOR), s_)
    with trunc(N, xdeg=3): Ln = FC.lie(G0, xi_K(BS[0], pn, LOR), An); Lm = FC.lie(G0, xi_K(BS[0], pm_, LOR), Am)
    if FAULT == 'MASS': Ln, opn = Lm, proca
    else: opn = dsd
    chk('bit', not at_pt(opn(Ln)) and at_pt(Ln, 2), 'xi = K_b1: L_xi A of the null wave solves d*dA = 0 at the point (L_xi A != 0)')
    chk('ctl', at_pt(proca(Lm)), 'xi = K_b1: L_xi A of the Proca wave does not solve the massive equation at the point (the massive term breaks the conformal invariance)')
    tick('part 5')
    head('(6) the float route: su(2) matrices, closed forms, nested differences [std]; i_xi F [bit==std]')
    worst = 0.0; worst_ck = 0.0; worst_bs = 0.0; bad = []
    for (p, rho2) in BPTS:
        x = np.array([float(v) for v in p]); r2 = float(rho2)
        for i, b in enumerate(BS):
            xf = lambda y, b=b: xi_num('K', y, EUC, b)
            res = lin_num(lambda y: A_bpst(y, r2), lambda y: F_bpst(y, r2), xf, x, EUC); worst = max(worst, float(np.abs(res).max()))
            worst_ck = max(worst_ck, ck_num(xf, x, EUC))
        xf = lambda y: xi_num('D', y, EUC); res = lin_num(lambda y: A_bpst(y, r2), lambda y: F_bpst(y, r2), xf, x, EUC); worst = max(worst, float(np.abs(res).max()))
        resw = lin_num(lambda y: A_bpst(y, r2), lambda y: F_bpst(y, r2), xf, x, EUC, add_A=True); bad.append(float(np.abs(resw).max()))
    for (p, xname, a, A, Fc, xi) in datB:
        if xname.startswith('K_b'):
            b = BS[int(xname[3]) - 1]; x = np.array([float(v) for v in p]); r2 = float(rho[tuple(p)])
            an = np.einsum('m,amn->an', xi_num('K', x, EUC, b), F_bpst(x, r2))
            ab = np.array([[float(a[C].get(1 << n, {}).get(Z5, 0)) for n in range(4)] for C in range(3)]); worst_bs = max(worst_bs, float(np.abs(an - ab).max()))
    for p in WPTS:
        x = np.array([float(v) for v in p])
        for b in BS:
            xf = lambda y, b=b: xi_num('K', y, LOR, b)
            res = lin_num(A_wy, lambda y: F_num(A_wy, y), xf, x, LOR); worst = max(worst, float(np.abs(res).max())); worst_ck = max(worst_ck, ck_num(xf, x, LOR))
    for (p, xname, a, A, Fc, xi) in datW:
        if not xname.startswith('K_b'): continue
        b = BS[int(xname[3]) - 1]; x = np.array([float(v) for v in p])
        an = np.einsum('m,amn->an', xi_num('K', x, LOR, b), F_num(A_wy, x))
        ab = np.array([[float(a[C].get(1 << n, {}).get(Z5, 0)) for n in range(4)] for C in range(3)]); worst_bs = max(worst_bs, float(np.abs(an - ab).max()))
    rng = random.Random(139); RM = np.array([[rng.uniform(-1, 1) for _ in range(10)] for _ in range(4)])
    def rq(y): return RM[:, :4] @ y + RM[:, 4:8] @ (y * y) + RM[:, 8] * y[0] * y[1] + RM[:, 9]
    xb = np.array([float(v) for v in BPTS[0][0]])
    rbad = float(np.abs(lin_num(lambda y: A_bpst(y, 1.0), lambda y: F_bpst(y, 1.0), rq, xb, EUC)).max()); ckbad = ck_num(rq, xb, EUC)
    chk('std', worst < 1e-6 and worst_ck < 1e-8, 'numpy: the eps^1 part of D^mu F_mu nu (A + eps i_xi F) is below %.1e for BPST (K_b, dilatation) and Wu-Yang (K_b) at the 4 points; the conformal Killing residual of K_b is %.1e' % (max(worst, 1e-16), max(worst_ck, 1e-16)))
    chk('bit==std', worst_bs < 1e-9, 'i_xi F at the points: the engine (exact) = numpy (BPST closed form, Wu-Yang F by differences), largest difference %.1e (tolerance 1e-9)' % worst_bs)
    chk('ctl', min(bad) > 1e-3 and rbad > 1e-3 and ckbad > 1e-3, 'numpy: the dilatation with the wrong weight gives %.2e, a random quadratic field %.2e (conformal Killing residual %.2e)' % (min(bad), rbad, ckbad))
    tick('part 6')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GM-CYM' + ('-' + FAULT if FAULT else ''))
