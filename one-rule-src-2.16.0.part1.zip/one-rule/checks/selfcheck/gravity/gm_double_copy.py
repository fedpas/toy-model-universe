#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-DCOPY.  The Kerr-Schild double copy of Schwarzschild: the same null k carries the vacuum metric and the Coulomb potential.   python3 gm_double_copy.py

 Signature (+,-,-,-). Kerr-Schild frame e^a = dx^a - f l^a l_mu dx^mu (b1lib.ks_frame_jet, exact 2-jets at rational points), l_mu dx^mu = dt + d rho (null), f = M/rho:
 g = eta - (2M/rho) l l (the same metric as eta + (2M/r) k k in the signature (-,+,+,+)). Single copy: A = (Q/rho) l = (Q/M) f l (c3_rn.coulomb_A, exact 3-jets) on flat space.
 [bit]  l is null: the bit-rule square of l^a gamma_a is 0 (jets to degree 2); the engine's Einstein form E_a(c = 0) of the frame is 0 at the point and T = 0 for the closed-form omega;
        on the flat frame: F = dA (engine d), dF = 0, d*F = 0 with the bit-rule Hodge star (g2_hodge), and grad F = 0 in Cl(1,3) by the bit rule of maxwell_selfcheck.py (x-degree <= 1);
        A = (Q/M) f l to degree 2 (the same l and the same profile).
 [std]  the Christoffel route on g = e^T eta e: Ricci = 0 (exact jets); g^{mu nu} l_mu l_nu = 0; the closed-form Coulomb field F_{0i} = Q x_i/rho^3, F_{ij} = 0 (the rest of A is the
        gauge term d(Q ln rho)); numpy central differences of E = Q x/rho^3: div E = 0 and curl E = 0 at the points.
 [bit==std] the engine's F at the point = the closed-form Coulomb field.
 Controls: A = (Q/rho^2) l (wrong power): d*F != 0; a non-null l (l_mu = (1, x/(2 rho))) in the Kerr-Schild frame: E_a != 0 and Ricci != 0; f = M/rho^2: E_a != 0.
 Scope: the points (1, 2, 2), (2, 3, 6), (1, 4, 8) (rho = 3, 7, 9), M = 1 and 3/2, Q = 2; jets of degree 2 (frame) and 3 (potential)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import c3_rn as C3
import maxwell_selfcheck as MX
import numpy as np

SQ = LORENTZ(4); ETA = SQ
POINTS = [((1, 2, 2), 3), ((2, 3, 6), 7), ((1, 4, 8), 9)]
def trunc_deg(p, d, n=4): return {k: v for k, v in p.items() if sum(k[:n]) <= d}
def flat_frame(nv=4): return [{1 << a: const(nv, 1)} for a in range(4)], [[const(nv, int(m == a)) for a in range(4)] for m in range(4)]
def scaled_l_frame(e, c):
    """e'^a_mu = delta - c^([a>0] + [mu>0]) (delta - e^a_mu): the Kerr-Schild frame with l replaced by (1, c n) (null only for c = +-1)"""
    out = []
    for a in range(4):
        form = {}
        for mu in range(4):
            d = const(4, int(a == mu)); q = sp_add(d, e[a].get(1 << mu, {}), -1)
            p = sp_add(d, scale(q, F(c) ** (int(a > 0) + int(mu > 0))), -1)
            if p: form[1 << mu] = p
        out.append(form)
    return out
def engine_vacuum(Gv, S, e):
    om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0)
    with trunc(4, xdeg=0): tz = torsion_zero_at0(Gv, om, e, 4)
    return comp, tz, any(at0(p, 4) != 0 for A in om for p in A.values())
def std_ricci(e):
    g = std_metric(e, 4, SQ, 4, 2); R, g0, g0i = std_riemann(g, 4, 4, 1); G, ric, Rs = std_einstein_mixed(R, g0, g0i, 4); return ric, g
def grad_bivector(Fl):
    """grad F = sum_mu g^mu d_mu F in Cl(1,3) (maxwell_selfcheck.bprod), F = sum_{mu<nu} F^{mu nu} g_mu g_nu from the lower components F_{mu nu} of the 2-form"""
    Fb = {m: scale(p, ETA[[i for i in range(4) if m >> i & 1][0]] * ETA[[i for i in range(4) if m >> i & 1][1]]) for m, p in Fl.items()}
    out = {}
    for m, p in Fb.items():
        for mu in range(4):
            dp = sp_der(p, mu)
            if not dp: continue
            mm, s = MX.bprod(1 << mu, m, 1); out[mm] = sp_add(out.get(mm, {}), dp, s * ETA[mu])
            if not out[mm]: del out[mm]
    return out

def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm      # built per run
    Q = F(2); ef, Ef = flat_frame()
    for M in (F(1), F(3, 2)):
        head('M = %s: the Kerr-Schild frame of Schwarzschild and the Coulomb potential A = (Q/rho) l, Q = %s' % (M, Q))
        for p, r0 in POINTS:
            pt = tuple(F(x) for x in p); rho0 = F(r0); tag = 'M = %s, p = %s (rho = %s)' % (M, p, r0)
            e, E, (lu, ld) = ks_frame_jet(pt, rho0, *sds_jets(M, F(0), rho0))
            sq_l = clifford_square(SQ, {a: lu[a] for a in range(4)}, 4)
            null_b = all(not trunc_deg(q, 2) for q in sq_l.values())
            ginv = {(m, n): lin(*[(F(SQ[a]), sp_mul(E[m][a], E[n][a], 2, 4)) for a in range(4)]) for m in range(4) for n in range(4)}
            null_s = not trunc_deg(lin(*[(F(1), sp_mul(sp_mul(ginv[(m, n)], ld[m], 2, 4), ld[n], 2, 4)) for m in range(4) for n in range(4)]), 2)
            comp, tz, om0 = engine_vacuum(Gv, S, e)
            chk('bit', null_b and tz and om0 and all(v == 0 for v in comp.values()), '%s: (l^a gamma_a)^2 = 0 (bit rule, to degree 2); T = 0, omega(0) != 0; the engine\'s Einstein form E_a(c = 0) is 0 on all 16 components: vacuum' % tag)
            ric, g = std_ricci(e)
            chk('std', null_s and all(ric[i][j] == 0 for i in range(4) for j in range(4)), '%s: g^{mu nu} l_mu l_nu = 0 and the Christoffel route on g = e^T eta e gives Ricci = 0 (exact)' % tag)
            A = C3.coulomb_A(pt, rho0, Q, 1, 3, 4)
            with trunc(4, xdeg=2):
                Fc = Fm.d(A); dF = Fm.d(Fc); sF = H.hodge_form(Fc, ef, Ef, Fm, SQ, 4, 'bit'); dsF = Fm.d(sF)
            gF = grad_bivector({m: trunc_deg(q, 2) for m, q in Fc.items()})
            okM = not any(dF.values()) and not any(trunc_deg(q, 1) for q in dsF.values()) and not any(trunc_deg(q, 1) for q in gF.values())
            chk('bit', okM and any(Fc.values()), '%s: on the flat frame F = dA has dF = 0, d*F = 0 (bit-rule star) and grad F = 0 in Cl(1,3) (maxwell_selfcheck bit rule) to x-degree 1: A solves the vacuum Maxwell equations at the point' % tag)
            f_l = [sp_add(const(4, int(mu == 0)), e[0].get(1 << mu, {}), -1) for mu in range(4)]           # f l^0 l_mu with l^0 = 1
            same = all(trunc_deg(A.get(1 << mu, {}), 2) == trunc_deg(scale(f_l[mu], Q / M), 2) for mu in range(4))
            chk('bit', same and lu[0] == const(4, 1), '%s: A_mu = (Q/M) f l_mu to degree 2: the single copy uses the same null l and the same profile f = M/rho' % tag)
            closed = {(0, i): Q * pt[i - 1] / rho0 ** 3 for i in (1, 2, 3)}; closed.update({(i, j): F(0) for i in (1, 2, 3) for j in range(i + 1, 4)})
            eng = {(m, n): at0(Fc.get((1 << m) | (1 << n), {}), 4) for m in range(4) for n in range(m + 1, 4)}
            chk('bit==std', eng == closed, '%s: engine F_{mu nu} at the point = the Coulomb field F_{0i} = Q x_i/rho^3 = (%s), F_{ij} = 0' % (tag, ', '.join(str(closed[(0, i)]) for i in (1, 2, 3))))
            # controls
            A2 = C3.coulomb_A(pt, rho0, Q, 2, 3, 4)
            with trunc(4, xdeg=2): F2_ = Fm.d(A2); dsF2 = Fm.d(H.hodge_form(F2_, ef, Ef, Fm, SQ, 4, 'bit'))
            chk('ctl', any(trunc_deg(q, 1) for q in dsF2.values()), '%s: A = (Q/rho^2) l (wrong power): d*F != 0 at the point' % tag)
            enn = scaled_l_frame(e, F(1, 2)); compn, _, _ = engine_vacuum(Gv, S, enn); ricn, _ = std_ricci(enn)
            chk('ctl', any(v != 0 for v in compn.values()) and any(ricn[i][j] != 0 for i in range(4) for j in range(4)), '%s: l_mu = (1, x/(2 rho)) (not null, l.l = 3/4): E_a != 0 (engine) and Ricci != 0 (Christoffel route)' % tag)
            ew, _, _ = ks_frame_jet(pt, rho0, M / rho0 ** 2, -2 * M / rho0 ** 3, 6 * M / rho0 ** 4)
            compw, _, _ = engine_vacuum(Gv, S, ew)
            chk('ctl', any(v != 0 for v in compw.values()), '%s: f = M/rho^2 (wrong profile): E_a != 0' % tag)
    head('closed-form Coulomb field E = Q x/rho^3, numpy central differences [std]')
    def Efield(x): x = np.asarray(x, float); return float(Q) * x / np.linalg.norm(x) ** 3
    h = 1e-4; ok = True; worst = 0.0
    for p, r0 in POINTS:
        x0 = np.array(p, float); J = np.zeros((3, 3))
        for j in range(3):
            dx = np.zeros(3); dx[j] = h; J[:, j] = (Efield(x0 + dx) - Efield(x0 - dx)) / (2 * h)
        div = np.trace(J); curl = np.array([J[2, 1] - J[1, 2], J[0, 2] - J[2, 0], J[1, 0] - J[0, 1]]); worst = max(worst, abs(div), np.abs(curl).max()); ok &= abs(div) < 1e-6 and np.abs(curl).max() < 1e-6
    chk('std', ok, 'div E = 0 and curl E = 0 at the three points (central differences, largest residual %.1e)' % worst)

if __name__ == '__main__':
    main(); finish('GM-DCOPY')
