#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""ATY-CONE.  Euler and signature integrals of 4-metrics with an edge-cone singularity of angle 2 pi beta along a surface Sigma, against the defects of
M. Atiyah and C. LeBrun, "Curvature, cones and characteristic numbers":   chi(M) - (1 - beta) chi(Sigma) = (1/32 pi^2) int eps_abcd R^ab R^cd,
tau(M) - (1/3)(1 - beta^2) [Sigma]^2 = (1/12 pi^2) int sum_{a<b} R^ab R^ab.        python3 aty_cone_defects.py   [--fault NAME]

 Densities.  [bit] the engine: exact 2-jets of a rational coframe at a rational point, omega from the closed form, R = d omega + 1/4 [omega, omega],
   the Euler 4-form eps_abcd R^ab ^ R^cd (each plane with its complementary plane) and the Pontryagin 4-form sum_{a<b} R^ab ^ R^ab (each plane with itself)
   as the engine's wedge products; the frame components of R split by the projectors (1 +- *)/2 of the bit-rule Hodge star.  Frame algebra Cl(4,0).
   [std] numpy: the metric in angular coordinates, Christoffel symbols and the Riemann tensor by 4th-order finite differences of g, the textbook Weyl
   tensor and its left dual, the paper's integrands (1/8 pi^2)(|W|^2 - |r0|^2/2 + s^2/24) and (1/12 pi^2)(|W+|^2 - |W-|^2); Gauss-Legendre in the radius.
 Parts  (1) the pseudoscalar I = gamma_0123 by the bit rule: I^2 = +1 in Cl(4,0) and Cl(0,4), -1 in Cl(1,3) and Cl(3,1); I B is the Hodge star of B
        (2) smooth Gauss-Bonnet and signature: S^4 (stereographic chart) and S^2 x S^2: chi = 2, 4 and tau = 0, exact
        (3) cones along a surface of zero self-intersection: S^4 with the cone along S^2 (dr^2 + cos^2 r g_S2 + beta^2 sin^2 r dpsi^2) and S^2 x (a football
            with two cone points): the Euler integral 2 beta and 4 beta, the signature integral 0, beta in {1/3, 1/2, 2/3, 2, 3}
        (4) CP^2 with a U(2)-invariant cone along a line: dr^2 + sin^2 r (s1^2 + s2^2) + sin^2 r cos^2 r (beta + (1 - beta) cos^2 r)^2 s3^2 (s_i unit
            left-invariant forms of S^3): the radial densities rebuilt exactly as rational functions of t = tan(r/2) by interpolation (verified at
            further points) and integrated exactly in Q + Q pi + Q log 2: Euler 1 + 2 beta, signature (2 + beta^2)/3 at beta in {1/3, 1/2, 1, 2}
        (5) the paper's self-dual family on (CP^2, CP^1) as printed in (5.4)-(5.6): V = 1/beta + 1/(e^{2 alpha} - 1), g0 = V (d alpha^2 + sinh^2 alpha g_S2)
            + V^-1 s3^2 and g~ = 4 beta^-1 ((2 - beta) cosh alpha + beta sinh alpha)^-2 g0: at 8 rational points where beta and V are rational squares,
            W+ = 0 in the chart orientation for g0 and g~, r0 = 0 and the Einstein constant (3/2) beta^2 (2 - beta) of g~; [std] the integrals and the
            volume of g~ at beta in {1/2, 1, 3/2}
 Controls (each also a --fault NAME, which puts the wrong version in place of the right one and exits 1):
   linear_R      the curvature without its quadratic term (R = d omega): the Euler integral of S^4 is not 2
   no_defect     the plain Gauss-Bonnet and signature values chi(M), tau(M) on a cone
   euler_beta2   the Euler defect with (1 - beta^2) in place of (1 - beta)
   sig_no_third  the signature defect (1 - beta^2) [Sigma]^2 without the 1/3
   swap_W        W+ and W- exchanged in the standard signature density
   low_degree    the interpolating polynomial one degree too low
   bad_nut       the CP^2 family with (beta + (2 - beta) cos^2 r): a conical point at the nut
   no_conformal  g0 in place of the Einstein representative g~ of part 5
   ocr_factor    4 beta^-2 (the factor as the OCR text reads it) in place of the printed 4 beta^-1 of (5.6)
 Engine faults: the script builds Lie, Grav and Forms (curvature, torsion, wedge, d); no Einstein form; the frame is Euclidean (no time vector)."""
import os, sys, math, time, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import numpy as np

STEP = 'ATY-CONE'
FAULTS = ('linear_R', 'no_defect', 'euler_beta2', 'sig_no_third', 'swap_W', 'low_degree', 'bad_nut', 'no_conformal', 'ocr_factor')
FAULT = None
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ exact numbers a + b pi + c log 2 and the radial integrals
def T3(q0=0, qp=0, ql=0): return (F(q0), F(qp), F(ql))
def tadd(a, b, c=1): return tuple(x + c * y for x, y in zip(a, b))
def tscale(a, c): return tuple(x * c for x in a)
def tstr(a): return ' + '.join(s for s in ('%s' % a[0] if a[0] or not any(a) else '', '%s pi' % a[1] if a[1] else '', '%s log2' % a[2] if a[2] else '') if s)
_J = {}
def J01(m, k):
    """int_0^1 t^m (1 + t^2)^-k dt, exact, as (rational, coefficient of pi, coefficient of log 2)"""
    key = (m, k)
    if key in _J: return _J[key]
    if k == 0: v = T3(F(1, m + 1))
    elif m >= 2: v = tadd(J01(m - 2, k - 1), J01(m - 2, k), -1)
    elif m == 0: v = T3(0, F(1, 4)) if k == 1 else tadd(T3(F(1, (2 * k - 2) * 2 ** (k - 1))), J01(0, k - 1), F(2 * k - 3, 2 * k - 2))
    else: v = T3(0, 0, F(1, 2)) if k == 1 else T3(F(1, 2 * (k - 1)) * (1 - F(1, 2 ** (k - 1))))
    _J[key] = v; return v
def gamma_half(n2):
    """Gamma(n2/2) = rational * sqrt(pi)^p, returns (rational, p)"""
    if n2 % 2 == 0: return F(math.factorial(n2 // 2 - 1)), 0
    n = (n2 - 1) // 2; return F(math.factorial(2 * n), 4 ** n * math.factorial(n)), 1
def J0inf(m, k):
    """int_0^oo t^m (1 + t^2)^-k dt = B((m+1)/2, k - (m+1)/2) / 2, exact"""
    x2, y2 = m + 1, 2 * k - m - 1; assert y2 > 0
    gx, px = gamma_half(x2); gy, py = gamma_half(y2); gs, _ = gamma_half(x2 + y2); val = gx * gy / gs / 2
    return T3(val) if px + py == 0 else T3(0, val)
def poly_integral(P, M, J=J01): return tuple(sum((p * J(m, M)[i] for m, p in enumerate(P) if p), F(0)) for i in range(3))

def interp(xs, ys):
    """exact interpolating polynomial (coefficients, low degree first) through the points (xs, ys)"""
    n = len(xs); c = list(ys)
    for j in range(1, n):
        for i in range(n - 1, j - 1, -1): c[i] = (c[i] - c[i - 1]) / (xs[i] - xs[i - j])
    P = [F(0)]
    for i in range(n - 1, -1, -1):
        new = [F(0)] * (len(P) + 1)
        for k, pk in enumerate(P): new[k + 1] += pk; new[k] -= pk * xs[i]
        new[0] += c[i]; P = new
    while len(P) > 1 and P[-1] == 0: P.pop()
    return P
def peval(P, x): return sum((p * x ** k for k, p in enumerate(P)), F(0))

# ------------------------------------------------------------------------------------------------ exact 2-jets of rational coframes (4 variables delta = x - x0)
NV = 4
def C(c): return const(NV, F(c))
def X(i, x0): return lin((F(1), const(NV, F(x0))), (F(1), var(NV, i)))
def mul(*ps):
    r = ps[0]
    for p in ps[1:]: r = sp_mul(r, p, 2, NV)
    return r
def one_plus(p, c=1): return lin((F(1), C(1)), (F(c), p))
def inv(a):
    a0 = at0(a, NV); assert a0 != 0
    u = scale(sp_add(a, const(NV, a0), -1), 1 / a0)
    return scale(lin((F(1), C(1)), (F(-1), u), (F(1), mul(u, u))), 1 / a0)
def sqrt_j(a, q):
    """the 2-jet of sqrt(a) when a(x0) = q^2, q rational"""
    u = scale(sp_add(a, const(NV, q * q), -1), 1 / (q * q))
    return scale(lin((F(1), C(1)), (F(1, 2), u), (F(-1, 8), mul(u, u))), q)
def trig_t(t0, i):
    """sin r, cos r and dr/dt as jets in delta_i, r = 2 arctan t"""
    T_ = X(i, t0); it = inv(one_plus(mul(T_, T_)))
    return scale(mul(T_, it), 2), mul(one_plus(mul(T_, T_), -1), it), scale(it, 2)

def frame_s4_stereo(x0):
    Xs = [X(i, x0[i]) for i in range(4)]; Om = scale(inv(lin((F(1), C(1)), *[(F(1), mul(x, x)) for x in Xs])), 2)
    return [{1 << a: Om} for a in range(4)]
def frame_s2s2(x0):
    Xs = [X(i, x0[i]) for i in range(4)]
    O1 = scale(inv(lin((F(1), C(1)), (F(1), mul(Xs[0], Xs[0])), (F(1), mul(Xs[1], Xs[1])))), 2)
    O2 = scale(inv(lin((F(1), C(1)), (F(1), mul(Xs[2], Xs[2])), (F(1), mul(Xs[3], Xs[3])))), 2)
    return [{1: O1}, {2: O1}, {4: O2}, {8: O2}]
def frame_s4_cone(t0, s0, beta):                    # coordinates (t, s, phi, psi): dr^2 + cos^2 r (dth^2 + sin^2 th dphi^2) + beta^2 sin^2 r dpsi^2
    Sr, Cr, dr = trig_t(t0, 0); St, Ct, dth = trig_t(s0, 1)
    return [{1: dr}, {2: mul(Cr, dth)}, {4: mul(Cr, St)}, {8: scale(Sr, beta)}]
def frame_football(x0, t0, beta):                   # coordinates (x, y, t, psi): 4 |dx|^2/(1 + |x|^2)^2 + dr^2 + beta^2 sin^2 r dpsi^2
    Xs = [X(0, x0[0]), X(1, x0[1])]; Om = scale(inv(lin((F(1), C(1)), (F(1), mul(Xs[0], Xs[0])), (F(1), mul(Xs[1], Xs[1])))), 2)
    Sr, Cr, dr = trig_t(t0, 2)
    return [{1: Om}, {2: Om}, {4: dr}, {8: scale(Sr, beta)}]
def frame_cp2(t0, s0, beta, nut=1):                 # coordinates (t, s, phi, psi); s3 = (dpsi + cos th dphi)/2, s1^2 + s2^2 = (dth^2 + sin^2 th dphi^2)/4
    Sr, Cr, dr = trig_t(t0, 0); St, Ct, dth = trig_t(s0, 1)
    a = scale(Sr, F(1, 2)); ph = lin((F(beta), C(1)), (F(nut) - beta, mul(Cr, Cr))); c = scale(mul(Sr, Cr, ph), F(1, 2))
    return [{1: dr}, {2: mul(a, dth)}, {4: mul(a, St)}, {4: mul(c, Ct), 8: c}]
def qsqrt(x):
    """the exact square root of a rational square"""
    x = F(x); n, d = math.isqrt(x.numerator), math.isqrt(x.denominator); assert F(n, d) ** 2 == x, x; return F(n, d)
def frame_hyp(tau0, s0, beta, q, factor='printed'):  # coordinates (tau, s, phi, psi), alpha = 2 artanh tau, V(tau0) = q^2
    """the coframe of g0 (factor None), of the printed (5.6) g~ = 4 beta^-1 [(2 - beta) cosh alpha + beta sinh alpha]^-2 g0 (factor 'printed', beta a
    rational square), or of 4 beta^-2 [...]^-2 g0 (factor 'ocr', the factor as the OCR text reads it)"""
    Tau = X(0, tau0); itm = inv(one_plus(mul(Tau, Tau), -1))
    ch = mul(one_plus(mul(Tau, Tau)), itm); sh = scale(mul(Tau, itm), 2); da = scale(itm, 2)
    om_ = one_plus(Tau, -1); V = lin((1 / F(beta), C(1)), (F(1), mul(om_, om_, inv(scale(Tau, 4)))))
    assert at0(V, NV) == q * q
    sV = sqrt_j(V, q); isV = inv(sV)
    if factor is None: Om = C(1)
    else:
        rb = qsqrt(beta) if factor == 'printed' else F(beta)               # Om^2 = 4 / (rb^2 [...]^2): rb^2 = beta (printed) or beta^2 (ocr)
        Om = scale(inv(lin((2 - F(beta), ch), (F(beta), sh))), 2 / rb)
    St, Ct, dth = trig_t(s0, 1); A = mul(Om, sV); B = scale(mul(Om, isV), F(1, 2))
    return [{1: mul(A, da)}, {2: mul(A, sh, dth)}, {4: mul(A, sh, St)}, {4: mul(B, Ct), 8: B}]

# ------------------------------------------------------------------------------------------------ [bit] the engine's densities at the point
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
def engine_objects(sq):
    L_ = Lie(sq); Gv = Grav(4, L_); return Gv, koszul_S(4, sq, L_)
GV, SK = engine_objects([1, 1, 1, 1])
STAR_BIT = [[GV.eps([a, b, c, d]) if len({a, b, c, d}) == 4 else 0 for (a, b) in PAIRS] for (c, d) in PAIRS]   # (* e^{ab})_{cd}, sign of the null product
def engine_eval(e, Gv=GV, S=SK, linear=False):
    om, R = engine_om_R(Gv, e, S, 4)
    if linear: R = [Gv.Fm.d(om[A]) for A in range(Gv.G)]
    with trunc(4, xdeg=0): tf = torsion_zero_at0(Gv, om, e, 4)
    Fm = Gv.Fm; ix = lambda a, b: Gv.L.idx[(1 << a) | (1 << b)]
    with trunc(4, xdeg=0):
        E4 = {}; P4 = {}
        for (a, b) in PAIRS:
            c, d = [x for x in range(4) if x not in (a, b)]
            E4 = Fm.add(E4, Fm.wedge(R[ix(a, b)], R[ix(c, d)]), 4 * Gv.eps([a, b, c, d]))
            P4 = Fm.add(P4, Fm.wedge(R[ix(a, b)], R[ix(a, b)]))
    e0, E0, det = E0_of(e, 4, 4); Rc = Rab_at0(Gv, R, 4); sg = Gv.L.sq
    Rf = [[[[sg[b] * sum(Rc.get((a, b, m, v), 0) * (E0[m][c] * E0[v][d] - E0[v][c] * E0[m][d]) for m in range(4) for v in range(m + 1, 4))
             for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)]
    return dict(E4=at0(E4.get(15, {}), 4), P4=at0(P4.get(15, {}), 4), det=det, Rf=Rf, tf=tf)
def mm(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def bit_invariants(Rf, star=STAR_BIT):
    """s, |r0|^2, |W+|^2, |W-|^2 of frame components Rf by the projectors P = (1 +- *)/2 (exact)"""
    Rm = [[Rf[a][b][c][d] for (c, d) in PAIRS] for (a, b) in PAIRS]
    Ric = [[sum(Rf[a][b][a][d] for a in range(4)) for d in range(4)] for b in range(4)]; s = sum(Ric[i][i] for i in range(4))
    r0 = sum((Ric[i][j] - (s / 4 if i == j else 0)) ** 2 for i in range(4) for j in range(4))
    out = [s, r0]
    for sgn in (1, -1):
        P = [[(F(1 if i == j else 0) + sgn * star[i][j]) / 2 for j in range(6)] for i in range(6)]
        W = mm(mm(P, Rm), P); W = [[W[i][j] - s / 12 * P[i][j] for j in range(6)] for i in range(6)]
        out.append(sum(x * x for row in W for x in row))
    return tuple(out)
def bit_pointwise(ev):
    s, r0, wp, wm = bit_invariants(ev['Rf']); d = ev['det']
    return dict(s=s, r0=r0, wp=wp, wm=wm, euler_ok=(ev['E4'] == 4 * (wp + wm - r0 / 2 + s * s / 24) * d), sig_ok=(ev['P4'] == (wp - wm) * d))

# ------------------------------------------------------------------------------------------------ [std] numpy, never the engine
LC4 = np.zeros((4, 4, 4, 4))
for p in itertools.permutations(range(4)):
    LC4[p] = np.linalg.det(np.eye(4)[list(p)])
C1 = {-2: 1 / 12, -1: -8 / 12, 1: 8 / 12, 2: -1 / 12}; C2 = {-2: -1 / 12, -1: 16 / 12, 0: -30 / 12, 1: 16 / 12, 2: -1 / 12}
def std_riemann_fd(gfun, x, h, active):
    """R_ijkl (all indices down, MTW sign) of the metric gfun at x: 4th-order central differences, steps h[i], only the coordinates in `active` vary"""
    x = np.array(x, float); g = gfun(x); dg = np.zeros((4, 4, 4)); ddg = np.zeros((4, 4, 4, 4))
    def G(*sh):
        y = x.copy()
        for (i, k) in sh: y[i] += k * h[i]
        return gfun(y)
    for i in active:
        dg[i] = sum(c * G((i, k)) for k, c in C1.items()) / h[i]
        ddg[i, i] = sum(c * G((i, k)) for k, c in C2.items()) / h[i] ** 2
    for i, j in itertools.combinations(active, 2):
        ddg[i, j] = ddg[j, i] = sum(ci * cj * G((i, ki), (j, kj)) for ki, ci in C1.items() for kj, cj in C1.items()) / (h[i] * h[j])
    gi = np.linalg.inv(g)
    Gam = 0.5 * (np.einsum('mn,inj->mij', gi, dg) + np.einsum('mn,jni->mij', gi, dg) - np.einsum('mn,nij->mij', gi, dg))   # Gam[m,i,j]; dg[k,a,b] = d_k g_ab
    R = 0.5 * (np.einsum('jkil->ijkl', ddg) + np.einsum('iljk->ijkl', ddg) - np.einsum('jlik->ijkl', ddg) - np.einsum('ikjl->ijkl', ddg))
    R += np.einsum('mn,mjk,nil->ijkl', g, Gam, Gam) - np.einsum('mn,mjl,nik->ijkl', g, Gam, Gam)
    return R, g
def std_point(gfun, x, h, active, swap=False):
    """the paper's integrands at x, per coordinate volume: (1/8pi^2)(|W|^2 - |r0|^2/2 + s^2/24) sqrt g, (1/12pi^2)(|W+|^2 - |W-|^2) sqrt g, and the invariants"""
    R, g = std_riemann_fd(gfun, x, h, active); L = np.linalg.cholesky(g); E = np.linalg.inv(L.T); vol = float(np.prod(np.diag(L)))
    Rf = np.einsum('ijkl,ia,jb,kc,ld->abcd', R, E, E, E, E); I4 = np.eye(4)
    Ric = np.einsum('abad->bd', Rf); s = np.trace(Ric); r0 = Ric - s / 4 * I4
    W = Rf - 0.5 * (np.einsum('ac,bd->abcd', I4, Ric) - np.einsum('ad,bc->abcd', I4, Ric) + np.einsum('bd,ac->abcd', I4, Ric) - np.einsum('bc,ad->abcd', I4, Ric)) \
        + s / 6 * (np.einsum('ac,bd->abcd', I4, I4) - np.einsum('ad,bc->abcd', I4, I4))
    sW = 0.5 * np.einsum('abef,efcd->abcd', LC4, W); Wp = (W + sW) / 2; Wm = (W - sW) / 2
    wp, wm, w2, r2 = [0.25 * float((T_ ** 2).sum()) for T_ in (Wp, Wm, W)] + [float((r0 ** 2).sum())]
    if swap: wp, wm = wm, wp
    eu = (w2 - r2 / 2 + s * s / 24) / (8 * math.pi ** 2) * vol; sg = (wp - wm) / (12 * math.pi ** 2) * vol
    return dict(eu=eu, sg=sg, vol=vol, s=float(s), r0=r2, wp=wp, wm=wm)
def gl(n, a, b):
    x, w = np.polynomial.legendre.leggauss(n); return (b - a) / 2 * x + (a + b) / 2, (b - a) / 2 * w
def g_from_coframe(cf):
    M = np.array(cf, float); return M.T @ M
def g_s4_stereo(x): Om = 2 / (1 + x @ x); return Om * Om * np.eye(4)
def g_s2s2(x): return np.diag([4 / (1 + x[0] ** 2 + x[1] ** 2) ** 2] * 2 + [4 / (1 + x[2] ** 2 + x[3] ** 2) ** 2] * 2)
def g_s4_cone(beta): return lambda x: np.diag([1, math.cos(x[0]) ** 2, (math.cos(x[0]) * math.sin(x[1])) ** 2, (beta * math.sin(x[0])) ** 2])
def g_football(beta): return lambda x: np.diag([1, math.sin(x[0]) ** 2, 1, (beta * math.sin(x[2])) ** 2])
def g_cp2(beta, nut=1.0):
    def g(x):
        r, th = x[0], x[1]; a = math.sin(r) / 2; c = math.sin(r) * math.cos(r) * (beta + (nut - beta) * math.cos(r) ** 2) / 2
        return g_from_coframe([[1, 0, 0, 0], [0, a, 0, 0], [0, 0, a * math.sin(th), 0], [0, 0, c * math.cos(th), c]])
    return g
def g_hyp(beta, factor='printed'):
    def g(x):
        al, th = x[0], x[1]; V = 1 / beta + 1 / math.expm1(2 * al); sV = math.sqrt(V); br = (2 - beta) * math.cosh(al) + beta * math.sinh(al)
        Om = 1.0 if factor is None else 2 / ((math.sqrt(beta) if factor == 'printed' else beta) * br)
        A = Om * sV; B = Om / sV / 2; sh = math.sinh(al)
        return g_from_coframe([[A, 0, 0, 0], [0, A * sh, 0, 0], [0, 0, A * sh * math.sin(th), 0], [0, 0, B * math.cos(th), B]])
    return g
def hstep(x, i, lo=None, hi=None):
    """relative step: 1e-3 times the distance to the ends of the radial range (the metric scales like a power of that distance there)"""
    d = 1.0
    if lo is not None: d = min(d, x[i] - lo)
    if hi is not None: d = min(d, hi - x[i])
    return 1e-3 * d
def close(a, b, tol=1e-7): return abs(a - b) <= tol * max(1.0, abs(a), abs(b))

# ------------------------------------------------------------------------------------------------ (1) the pseudoscalar and the two pairings
def part1():
    head('(1) the pseudoscalar I = gamma_0123 by the bit rule, and the Hodge star of the six planes (the antipodal map of the octahedron)')
    sq_of = {'Cl(4,0)': [1, 1, 1, 1], 'Cl(0,4)': [-1, -1, -1, -1], 'Cl(1,3)': [1, -1, -1, -1], 'Cl(3,1)': [-1, 1, 1, 1]}
    I2 = {k: bmul(15, 15, sq)[1] for k, sq in sq_of.items()}
    chk('bit', I2 == {'Cl(4,0)': 1, 'Cl(0,4)': 1, 'Cl(1,3)': -1, 'Cl(3,1)': -1}, 'I^2 by the bit rule: %s (a real split of the planes needs a Euclidean cell)' % I2)
    rel = set(); anti = True
    for k in ('Cl(4,0)', 'Cl(0,4)'):
        for i, (a, b) in enumerate(PAIRS):
            m, sgn = bmul(15, (1 << a) | (1 << b), sq_of[k]); anti &= (m == 15 ^ ((1 << a) | (1 << b)))
            j = PAIRS.index(tuple(x for x in range(4) if (m >> x) & 1)); rel.add((k, sgn * STAR_BIT[j][i]))
    S = np.array([[float(x) for x in r] for r in STAR_BIT]); ev = np.sort(np.linalg.eigvals(S).real)
    Sstd = np.array([[LC4[a, b, c, d] for (a, b) in PAIRS] for (c, d) in PAIRS])
    chk('bit', anti, 'I e_ab = +- e_cd with cd the complementary plane, for all six planes in both Euclidean cells (each vertex goes to its antipode)')
    cells = sorted(set(k for k, _ in rel))
    chk('bit==std', np.array_equal(S, Sstd) and len(rel) == 2 and cells == ['Cl(0,4)', 'Cl(4,0)'],
        'the bit-rule eps is the textbook Levi-Civita symbol, and I e_ab = sigma *e_ab with one sign sigma for all six planes in each cell (%s); the star has eigenvalues %s (3 + 3)'
        % (', '.join('%s: sigma = %+d' % kv for kv in sorted(rel)), ev.round(6).tolist()))

# ------------------------------------------------------------------------------------------------ (2) smooth Gauss-Bonnet and signature
def part2():
    head('(2) smooth: S^4 (stereographic chart, e^a = 2 dx^a / (1 + |x|^2)) and S^2 x S^2 (two stereographic charts): chi = 2, 4 and tau = 0')
    pts = [(F(1, 2), F(-1, 3), F(2), F(1, 5)), (F(0), F(1), F(-2, 3), F(3, 4)), (F(3), F(1, 7), F(0), F(-1, 2)), (F(-1, 4), F(2, 3), F(5, 3), F(-2))]
    ok = {'s4': True, 's2s2': True}; ident = True; tors = True; lin_bad = True; lin_same = True; wsplit = True; bs = []
    for x0 in pts:
        for name, fr, k in (('s4', frame_s4_stereo, 24), ('s2s2', frame_s2s2, 8)):
            ev = engine_eval(fr(x0), linear=(FAULT == 'linear_R')); bp = bit_pointwise(ev); tors &= ev['tf']; ident &= bp['euler_ok'] and bp['sig_ok']
            ok[name] &= (ev['E4'] == k * ev['det'] and ev['P4'] == 0)
            if name == 's4': wsplit &= (bp['wp'] == 0 and bp['wm'] == 0 and bp['r0'] == 0 and bp['s'] == 12)
            else: wsplit &= (bp['wp'] == bp['wm'] and bp['r0'] == 0 and bp['s'] == 4)
            if FAULT != 'linear_R':
                evl = engine_eval(fr(x0), linear=True)
                if name == 's4': lin_bad &= (evl['E4'] != k * evl['det'])
                else: lin_same &= (evl['E4'] == ev['E4'])
            bs.append((name, x0, bp))
    chk('bit', tors, 'omega from the closed form is torsion-free at all %d points (the engine\'s torsion T = de + h omega e vanishes)' % (2 * len(pts)))
    chk('bit', ok['s4'], 'S^4: eps R^R = 24 e^0123 and sum R^ab R^ab = 0 at %d rational points, exact' % len(pts))
    chk('bit', ok['s2s2'], 'S^2 x S^2: eps R^R = 8 e^0123 and sum R^ab R^ab = 0 at %d rational points, exact' % len(pts))
    chk('bit', ident, 'at every point eps R^R = 4 (|W|^2 - |r0|^2/2 + s^2/24) dmu and sum R^ab R^ab = (|W+|^2 - |W-|^2) dmu exactly (W+- from the projectors (1 +- *)/2)')
    chk('bit', wsplit, 'S^4: s = 12, r0 = 0, W = 0;  S^2 x S^2: s = 4, r0 = 0, |W+|^2 = |W-|^2 (= %s): the two densities vanish for different reasons' % bs[-1][2]['wp'])
    # exact integrals: S^4 radial, vol = 2 pi^2 int_0^oo rho^3 16/(1 + rho^2)^4 drho ; S^2 x S^2: (int 4/(1+rho^2)^2 2 pi rho drho)^2
    vol_s4 = tscale(J0inf(3, 4), 32)                                   # in units of pi^2: 2 pi^2 * 16 * J
    chi_s4 = F(24) * vol_s4[0] / 32; vol_s2 = tscale(J0inf(1, 2), 8)    # area of S^2 in units of pi: 2 pi * 4 * J
    chi_s2s2 = F(8) * vol_s2[0] ** 2 / 32
    chk('bit', (FAULT != 'linear_R' or not ok['s4']) and chi_s4 == 2 and vol_s4[1] == 0 and chi_s2s2 == 4,
        'exact integrals: vol(S^4) = %s pi^2, chi = 24 vol / 32 pi^2 = %s;  vol(S^2 x S^2) = (%s pi)^2, chi = %s;  tau = 0 for both' % (vol_s4[0], chi_s4, vol_s2[0], chi_s2s2))
    # [std]
    us, ws = gl(40, 0.0, 1.0); e_s4 = 0.0; v_s4 = 0.0; agree = True
    for u, w in zip(us, ws):
        rho = u / (1 - u); jac = 1 / (1 - u) ** 2; d = std_point(g_s4_stereo, [rho, 0, 0, 0], [1e-3 * max(1.0, rho)] * 4, range(4))
        e_s4 += w * jac * 2 * math.pi ** 2 * rho ** 3 * d['eu']; v_s4 += w * jac * 2 * math.pi ** 2 * rho ** 3 * d['vol']
    d22 = std_point(g_s2s2, [0.3, -0.2, 0.7, 0.1], [1e-3] * 4, range(4)); e_s22 = d22['eu'] / d22['vol'] * 16 * math.pi ** 2
    chk('std', close(e_s4, 2, 1e-7) and close(v_s4, 8 * math.pi ** 2 / 3, 1e-7) and close(e_s22, 4, 1e-7),
        'numpy: (1/8 pi^2) int (|W|^2 - |r0|^2/2 + s^2/24) = %.9f on S^4 (vol %.9f = 8 pi^2/3 x %.9f) and %.9f on S^2 x S^2 (40 Gauss nodes, finite differences)' % (e_s4, v_s4, v_s4 / (8 * math.pi ** 2 / 3), e_s22))
    for name, x0, bp in bs[:2]:
        xf = [float(v) for v in x0]; d = std_point(g_s4_stereo if name == 's4' else g_s2s2, xf, [1e-3] * 4, range(4))
        agree &= close(d['s'], float(bp['s']), 1e-6) and close(d['r0'], float(bp['r0']), 1e-6) and close(d['wp'], float(bp['wp']), 1e-6) and close(d['wm'], float(bp['wm']), 1e-6)
    chk('bit==std', agree, 's, |r0|^2, |W+|^2, |W-|^2 of the engine equal the numpy values at the first point of each chart (tolerance 1e-6)')
    if FAULT != 'linear_R':
        chk('ctl', lin_bad, 'S^4: with R = d omega (the quadratic term dropped) eps R^R is not 24 e^0123 at any of the 4 points: Gauss-Bonnet would fail')
        chk('bit', lin_same, 'S^2 x S^2: R = d omega gives the same eps R^R (the connection lies in two commuting so(2) blocks, so 1/4 [omega, omega] = 0): this control cannot fail on a product')
    tick('part 2')

# ------------------------------------------------------------------------------------------------ (3) cones along a surface with [Sigma]^2 = 0
def predicted(chiM, tauM, chiS, selfS, beta):
    """the paper's right-hand values: chi(M) - (1 - beta) chi(Sigma), tau(M) - (1/3)(1 - beta^2) [Sigma]^2 (or a wrong version under a fault)"""
    b = F(beta)
    if FAULT == 'no_defect': return F(chiM), F(tauM)
    eu = chiM - ((1 - b * b) if FAULT == 'euler_beta2' else (1 - b)) * chiS
    sg = tauM - ((1 - b * b) if FAULT == 'sig_no_third' else (1 - b * b) / 3) * selfS
    return eu, sg
def part3():
    head('(3) cones along Sigma with [Sigma]^2 = 0: S^4 with the cone along S^2 (chi(Sigma) = 2), S^2 x football (two spheres, chi(Sigma) = 4)')
    betas = [F(1, 3), F(1, 2), F(2, 3), F(2), F(3)]; tp = [F(1, 3), F(3, 4), F(1, 7)]; sp = [F(1), F(1, 2), F(5, 2)]
    pw = True; tors = True; res = []; plain_bad = True; e2_bad = True
    for beta in betas:
        for t0, s0 in zip(tp, sp):
            for name, e, k in (('s4', frame_s4_cone(t0, s0, beta), 24), ('fb', frame_football((s0, -t0), t0 * 3, beta), 8)):
                ev = engine_eval(e); bp = bit_pointwise(ev); tors &= ev['tf']
                pw &= (ev['E4'] == k * ev['det'] and ev['P4'] == 0 and bp['euler_ok'] and bp['sig_ok'])
        # exact volume: S^4_beta: int_0^1 (2/(1+t^2)) ((1-t^2)/(1+t^2))^2 beta (2t/(1+t^2)) dt * 4 pi (S^2) * 2 pi ; football: 4 pi * int_0^oo (2/(1+t^2)) beta (2t/(1+t^2)) dt * 2 pi
        P = [F(0), F(4), F(0), F(-8), F(0), F(4)]                     # 4 t (1 - t^2)^2 over (1 + t^2)^4
        v4 = tscale(poly_integral(P, 4), beta * 8)                      # in units of pi^2
        vf = tscale(J0inf(1, 2), beta * 4 * 8)                          # 4 t / (1 + t^2)^2, times 4 pi * 2 pi
        eu4 = F(24) * v4[0] / 32; euf = F(8) * vf[0] / 32
        w4 = predicted(2, 0, 2, 0, beta); wf = predicted(4, 0, 4, 0, beta)
        res.append((beta, eu4, euf, v4, vf, w4, wf))
        plain_bad &= (eu4 != 2 and euf != 4); e2_bad &= (eu4 != 2 - (1 - beta * beta) * 2)
    chk('bit', tors and pw, 'at %d points (3 per beta and metric) eps R^R = 24 (S^4) and 8 (S^2 x S^2) times e^0123 and sum R^ab R^ab = 0, exact: locally the smooth model' % (2 * 3 * len(betas)))
    for (beta, eu4, euf, v4, vf, w4, wf) in res:
        chk('bit', v4[1:] == (0, 0) and eu4 == w4[0] and euf == wf[0] and w4[1] == 0 and wf[1] == 0,
            'beta = %s: Euler integral %s (S^4, vol %s pi^2) = chi(S^4) - (1 - beta) chi(S^2) = %s;  %s (S^2 x football) = 4 - 4 (1 - beta) = %s;  signature integral 0 = 0'
            % (beta, eu4, v4[0], w4[0], euf, wf[0]))
    if FAULT is None:
        chk('ctl', plain_bad, 'the plain values chi(M) = 2, 4 differ from the Euler integrals at every beta != 1 (the defect is needed)')
        chk('ctl', e2_bad, 'the Euler defect with (1 - beta^2) in place of (1 - beta) misses the S^4 integral at every beta')
    # [std]
    rs, ws = gl(32, 0.0, math.pi / 2); rf, wf_ = gl(32, 0.0, math.pi); okstd = True; txt = []
    for beta in (1 / 3, 2.0):
        e4 = sum(w * std_point(g_s4_cone(beta), [r, math.pi / 2, 0, 0], [hstep([r], 0, 0, math.pi / 2), 1e-3, 1, 1], (0, 1))['eu'] for r, w in zip(rs, ws)) * 2 * 2 * math.pi * 2 * math.pi
        ef = sum(w * std_point(g_football(beta), [math.pi / 2, 0, r, 0], [1e-3, 1, hstep([0, 0, r], 2, 0, math.pi), 1], (0, 2))['eu'] for r, w in zip(rf, wf_)) * 2 * 2 * math.pi * 2 * math.pi
        okstd &= close(e4, 2 * beta, 1e-7) and close(ef, 4 * beta, 1e-7); txt.append('beta %.4g: %.9f, %.9f' % (beta, e4, ef))
    chk('std', okstd, 'numpy, angular charts: Euler integrals of S^4_beta and S^2 x football = 2 beta, 4 beta (%s)' % '; '.join(txt))
    b0 = betas[0]; ev = engine_eval(frame_s4_cone(tp[0], sp[0], b0)); bp = bit_pointwise(ev)
    d = std_point(g_s4_cone(float(b0)), [2 * math.atan(float(tp[0])), 2 * math.atan(float(sp[0])), 0, 0], [1e-3, 1e-3, 1, 1], (0, 1))
    chk('bit==std', close(d['s'], float(bp['s']), 1e-6) and close(d['r0'], float(bp['r0']), 1e-6) and close(d['wp'] + d['wm'], float(bp['wp'] + bp['wm']), 1e-6),
        'beta = %s, t = %s: s = %s, |r0|^2 = %s, |W|^2 = %s from the engine equal the numpy values in the angular chart' % (b0, tp[0], bp['s'], bp['r0'], bp['wp'] + bp['wm']))
    tick('part 3')

# ------------------------------------------------------------------------------------------------ (4) CP^2 with a U(2)-invariant cone along a line
MPOW = 14; NPOOL = 40
def cp2_exact(beta, nut=1):
    """[bit] the radial densities F(t) = (eps R^R)_{t s phi psi} / (4 s/(1+s^2)^2) at s = 1 and G(t) likewise for sum R^ab R^ab, at NPOOL points
    t = i/(NPOOL+1); F (1+t^2)^MPOW rebuilt as a polynomial of the least degree D that matches all further points; integrals over t in (0, 1)"""
    ts = [F(i, NPOOL + 1) for i in range(1, NPOOL + 1)]; Fv = []; Gv_ = []; tors = True; pw = True
    for t0 in ts:
        ev = engine_eval(frame_cp2(t0, F(1), beta, nut)); bp = bit_pointwise(ev); tors &= ev['tf']; pw &= bp['euler_ok'] and bp['sig_ok']
        w = (1 + t0 * t0) ** MPOW; Fv.append(ev['E4'] * w); Gv_.append(ev['P4'] * w)
    out = {'tors': tors, 'pw': pw}
    for key, ys in (('E', Fv), ('P', Gv_)):
        found = None
        for D in range(0, NPOOL - 4):
            P = interp(ts[:D + 1], ys[:D + 1])
            if all(peval(P, x) == y for x, y in zip(ts[D + 1:], ys[D + 1:])): found = (D, P); break
        if found is None: out[key] = None; continue
        D, P = found; Plow = interp(ts[:D], ys[:D]) if D > 0 else [F(0)]
        lowfail = not all(peval(Plow, x) == y for x, y in zip(ts[D:], ys[D:]))
        if FAULT == 'low_degree': P = Plow
        out[key] = (D, P, poly_integral(P, MPOW), lowfail)
    return out
def part4():
    head('(4) CP^2 with the cone of angle 2 pi beta along the line at r = pi/2: dr^2 + sin^2 r (s1^2 + s2^2) + sin^2 r cos^2 r (beta + (1 - beta) cos^2 r)^2 s3^2')
    nut = 2 if FAULT == 'bad_nut' else 1; betas = [F(1), F(1, 3), F(1, 2), F(2)]; summary = []; lowall = True
    # s-independence of the radial density (U(2) invariance through the chart)
    sdep = True
    for beta in betas[:2]:
        for t0 in (F(1, 3), F(5, 7)):
            a = engine_eval(frame_cp2(t0, F(1), beta)); b = engine_eval(frame_cp2(t0, F(1, 2), beta)); fs = lambda s: 4 * s / (1 + s * s) ** 2
            sdep &= (a['E4'] / fs(F(1)) == b['E4'] / fs(F(1, 2)) and a['P4'] / fs(F(1)) == b['P4'] / fs(F(1, 2)))
    chk('bit', sdep, 'the two 4-forms divided by sin(theta) d theta/ds = 4 s/(1+s^2)^2 are the same at s = 1 and s = 1/2 (t = 1/3, 5/7; beta = 1/3, 1/2): the density is radial')
    sig_sign = None
    for beta in betas:
        o = cp2_exact(beta, nut)
        if o['E'] is None or o['P'] is None:
            chk('bit', False, 'beta = %s: no polynomial of degree < %d through the %d values of F (1+t^2)^%d' % (beta, NPOOL - 4, NPOOL, MPOW)); continue
        (DE, PE, IE, lowE), (DP, PP, IP, lowP) = o['E'], o['P']
        eu = tscale(IE, F(1, 2)); sg = tscale(IP, F(4, 3))              # (1/32 pi^2) 16 pi^2 int F dt ; (1/12 pi^2) 16 pi^2 int G dt
        if sig_sign is None:
            sig_sign = sg[0]
            chk('bit', abs(sig_sign) == 1 and sg[1:] == (0, 0), 'beta = 1 (Fubini-Study, smooth): the signature integral is %s: tau(CP^2) = %s in the orientation e^0123 of the chart, so [CP^1]^2 = %s there' % (tstr(sg), sig_sign, sig_sign))
        w = predicted(3, 1, 2, 1, beta); lowall &= lowE and lowP
        chk('bit', o['tors'] and o['pw'], 'beta = %s: torsion-free omega and the two density identities at all %d points' % (beta, NPOOL))
        chk('bit', True, 'beta = %s: F (1+t^2)^%d is a polynomial of degree %d and G (1+t^2)^%d one of degree %d: the interpolant through D+1 of the %d points matches the other %d and %d exactly'
            % (beta, MPOW, DE, MPOW, DP, NPOOL, NPOOL - DE - 1, NPOOL - DP - 1))
        summary.append((beta, eu, sg, w))
        chk('bit', eu[1:] == (0, 0) and eu[0] == w[0], 'beta = %s: (1/32 pi^2) int eps R^R = %s exactly; chi(CP^2) - (1 - beta) chi(CP^1) = %s' % (beta, tstr(eu), w[0]))
        chk('bit', sg[1:] == (0, 0) and sg[0] == w[1] * sig_sign, 'beta = %s: (1/12 pi^2) int sum R^ab R^ab = %s exactly; tau(CP^2) - (1/3)(1 - beta^2) [CP^1]^2 = %s (tau = [CP^1]^2 = %s)'
            % (beta, tstr(sg), w[1] * sig_sign, sig_sign))
    chk('ctl', lowall or FAULT is not None, 'one degree lower (interpolant through D points) misses the further points, for both densities at every beta: the degree is not slack')
    if FAULT is None and summary:
        b, eu, sg, w = summary[0]
        chk('ctl', all(e[0] != 3 and s_[0] != 1 for (bb, e, s_, ww) in summary if bb != 1), 'the plain values chi = 3, tau = 1 differ from the integrals at beta = 1/3, 1/2, 2')
        chk('ctl', all(s_[0] != 1 - (1 - bb * bb) for (bb, e, s_, ww) in summary if bb != 1), 'the signature defect without the 1/3, (1 - beta^2) [Sigma]^2, misses the integral at beta = 1/3, 1/2, 2')
        chk('ctl', all(e[0] != 3 - 2 * (1 - bb * bb) for (bb, e, s_, ww) in summary if bb != 1), 'the Euler defect (1 - beta^2) chi(Sigma) misses the integral at beta = 1/3, 1/2, 2')
    tick('part 4 [bit]')
    # [std]: the same metrics in the angular chart (r, theta, phi, psi)
    rs, ws = gl(40, 0.0, math.pi / 2); okE = okS = okT = True; txt = []; sw = (FAULT == 'swap_W'); ssign = None
    for beta in (1.0, 1 / 3, 1 / 2, 2.0):
        dens = [std_point(g_cp2(beta, float(nut)), [r, math.pi / 2, 0, 0], [hstep([r], 0, 0, math.pi / 2), 1e-3, 1, 1], (0, 1), swap=sw) for r in rs]
        e = sum(w * d['eu'] for w, d in zip(ws, dens)) * 16 * math.pi ** 2; s_ = sum(w * d['sg'] for w, d in zip(ws, dens)) * 16 * math.pi ** 2
        if ssign is None: ssign = 1.0 if s_ > 0 else -1.0
        okE &= close(e, 1 + 2 * beta, 1e-7); okS &= close(s_, ssign * (2 + beta * beta) / 3, 1e-7) and ssign == float(sig_sign or 0); txt.append('beta %.4g: %.9f, %.9f' % (beta, e, s_))
        d3 = std_point(g_cp2(beta, float(nut)), [rs[7], math.pi / 3, 0, 0], [hstep([rs[7]], 0, 0, math.pi / 2), 1e-3, 1, 1], (0, 1), swap=sw)
        okT &= close(d3['eu'] / math.sin(math.pi / 3), dens[7]['eu'], 1e-7) and close(d3['sg'] / math.sin(math.pi / 3), dens[7]['sg'], 1e-7)
    chk('std', okT, 'numpy: the densities at theta = pi/3 are sin(pi/3) times those at theta = pi/2 (radial), all four beta')
    chk('std', okE and okS, 'numpy, angular chart, 40 Gauss nodes: Euler and signature integrals = 1 + 2 beta and tau (2 + beta^2)/3 with the same tau = %+d as the engine (%s)' % (ssign, '; '.join(txt)))
    agree = True; ctl_sw = True
    for beta, t0 in ((F(1, 2), F(2, 5)), (F(2), F(3, 4)), (F(1, 3), F(1, 6))):
        ev = engine_eval(frame_cp2(t0, F(1), beta, nut)); bp = bit_pointwise(ev); r = 2 * math.atan(float(t0)); sinth = 1.0
        d = std_point(g_cp2(float(beta), float(nut)), [r, math.pi / 2, 0, 0], [hstep([r], 0, 0, math.pi / 2), 1e-3, 1, 1], (0, 1), swap=sw)
        dtdr = 1 / (1 + float(t0) ** 2) * 2                               # dr/dt; the engine's forms are per dt ds, the numpy ones per dr dtheta (ds = dtheta at s = 1)
        e_b = float(ev['E4']) / (8 * math.pi ** 2) / 4 / dtdr; s_b = float(ev['P4']) / (12 * math.pi ** 2) / dtdr
        agree &= close(d['wp'], float(bp['wp']), 1e-6) and close(d['wm'], float(bp['wm']), 1e-6) and close(d['s'], float(bp['s']), 1e-6) and close(d['r0'], float(bp['r0']), 1e-6)
        agree &= close(e_b, d['eu'], 1e-6) and close(s_b, d['sg'], 1e-6)
        if FAULT is None:
            dsw = std_point(g_cp2(float(beta)), [r, math.pi / 2, 0, 0], [hstep([r], 0, 0, math.pi / 2), 1e-3, 1, 1], (0, 1), swap=True); ctl_sw &= not close(s_b, dsw['sg'], 1e-6)
    chk('bit==std', agree, 'at (beta, t) = (1/2, 2/5), (2, 3/4), (1/3, 1/6): s, |r0|^2, |W+|^2, |W-|^2 and both densities of the engine equal the numpy values (tolerance 1e-6)')
    if FAULT is None: chk('ctl', ctl_sw, 'with W+ and W- exchanged the numpy signature density no longer equals the engine\'s sum R^ab R^ab at those points')
    if FAULT is None:
        e_bad = sum(w * std_point(g_cp2(0.5, 2.0), [r, math.pi / 2, 0, 0], [hstep([r], 0, 0, math.pi / 2), 1e-3, 1, 1], (0, 1))['eu'] for r, w in zip(rs, ws)) * 16 * math.pi ** 2
        chk('ctl', not close(e_bad, 2.0, 1e-4), 'with a conical nut (beta + (2 - beta) cos^2 r, beta = 1/2) the numpy Euler integral is %.6f, not 1 + 2 beta = 2: the formula sees the regularity at the nut' % (e_bad + 0.0))
    tick('part 4 [std]')

# ------------------------------------------------------------------------------------------------ (5) the paper's self-dual family on (CP^2, CP^1)
HYP_UV = [(F(1, 2), F(2, 3)), (F(1, 2), F(2, 5)), (F(1, 2), F(3, 5)), (F(1, 3), F(1, 2)), (F(1, 3), F(1, 4)), (F(2, 3), F(3, 4)), (F(2, 3), F(3, 5)), (F(1, 2), F(1, 2))]
def hyp_point(u, v):
    """tau = u^2 and beta = b^2 with b = u (1 - v^2)/(v (1 - u^2)); then V(tau) = 1/beta + (1 - tau)^2/(4 tau) = q^2 with q = (1 + v^2)/(2 v b)"""
    b = u * (1 - v * v) / (v * (1 - u * u)); return u * u, b * b, (1 + v * v) / (2 * v * b)
HYP_PTS = [hyp_point(u, v) for u, v in HYP_UV]
def part5():
    head('(5) the paper\'s family (5.4)-(5.6) as printed: V = 1/beta + 1/(e^{2 alpha} - 1), g0 = V (d alpha^2 + sinh^2 alpha g_S2) + V^-1 s3^2, '
         'g~ = 4 beta^-1 ((2 - beta) cosh alpha + beta sinh alpha)^-2 g0, at points where beta and V are rational squares')
    fac = {'no_conformal': None, 'ocr_factor': 'ocr'}.get(FAULT, 'printed')
    rows = []; sd0 = True; sd = True; ein = True; nonvac = True; tors = True; g0_not_ein = True; ocr = []
    for tau0, beta, q in HYP_PTS:
        s0 = F(1, 2)
        ev0 = engine_eval(frame_hyp(tau0, s0, beta, q, None)); b0 = bit_pointwise(ev0)
        ev = engine_eval(frame_hyp(tau0, s0, beta, q, fac)); b1 = bit_pointwise(ev)
        tors &= ev0['tf'] and ev['tf']; sd0 &= (b0['wp'] == 0); sd &= (b1['wp'] == 0); ein &= (b1['r0'] == 0); nonvac &= (b1['wm'] != 0 and b0['wm'] != 0)
        g0_not_ein &= (b0['r0'] != 0); rows.append((tau0, q, beta, b1['s'] / 4))
        if FAULT is None and beta != 1: ocr.append((beta, bit_pointwise(engine_eval(frame_hyp(tau0, s0, beta, q, 'ocr')))['s'] / 4))
    chk('bit', tors, 'omega torsion-free at all %d points, for g0 and g~' % len(HYP_PTS))
    chk('bit', sd0 and sd and nonvac, 'half the Weyl tensor vanishes: W+ = 0 exactly for g0 and for g~ in the chart orientation (the one with tau(CP^2) = -1 in part 4), W- != 0, at all %d points (tau, beta) = %s; so W- = 0 in the orientation with tau = +1, the paper\'s self-dual'
        % (len(HYP_PTS), ', '.join('(%s, %s)' % (t, b) for t, q, b, l in rows)))
    chk('bit', ein, 'g~ is Einstein: trace-free Ricci r0 = 0 exactly at all %d points' % len(HYP_PTS))
    chk('bit', all(l == F(3, 2) * b * b * (2 - b) for t, q, b, l in rows), 'the Einstein constant s/4 of g~ is (3/2) beta^2 (2 - beta), the constant printed with (5.6), at all %d points: %s (beta = 1: 3/2, g~ = 4 times the Fubini-Study metric with Ric = 6 g)'
        % (len(rows), ', '.join('%s' % l for t, q, b, l in rows)))
    if FAULT is None:
        chk('ctl', len(ocr) == len(HYP_PTS) - 1 and all(l != F(3, 2) * b * b * (2 - b) and l == F(3, 2) * b ** 3 * (2 - b) for b, l in ocr),
            'with the factor 4 beta^-2 (the OCR reading) in place of 4 beta^-1 the constant is (3/2) beta^3 (2 - beta), beta times the printed one and not the printed one, at the %d points with beta != 1' % len(ocr))
        chk('ctl', g0_not_ein, 'g0 itself (no conformal factor) has r0 != 0 at every point: the Einstein property is the conformal factor\'s')
    # [std] integrals of g~ over alpha in (0, oo), tau = tanh(alpha/2)
    us, ws = gl(64, 0.0, 1.0); ok = True; txt = []
    for beta in (0.5, 1.0, 1.5):
        e = s_ = v = 0.0
        for u, w in zip(us, ws):
            al = 2 * math.atanh(u); jac = 2 / (1 - u * u)
            d = std_point(g_hyp(beta, fac), [al, math.pi / 2, 0, 0], [1e-3 * min(1.0, al), 1e-3, 1, 1], (0, 1))
            f = w * jac * 2 * 2 * math.pi * 4 * math.pi; e += f * d['eu']; s_ += f * d['sg']; v += f * d['vol']
        lam = 1.5 * beta ** 2 * (2 - beta); vpred = 6 * math.pi ** 2 * beta * (4 - beta) / lam ** 2
        ok &= close(e, 1 + 2 * beta, 1e-6) and close(s_, -(2 + beta * beta) / 3, 1e-6) and close(v, vpred, 1e-6)
        txt.append('beta %.3g: %.8f, %.8f, vol/pred %.8f' % (beta, e, s_, v / vpred))
    chk('std', ok, 'numpy, the printed g~, 64 Gauss nodes in tanh(alpha/2): Euler integral 1 + 2 beta; signature integral -(2 + beta^2)/3 in the chart orientation, (5.7); vol = 6 pi^2 beta (4 - beta)/lambda^2 = (8 pi^2/3)(4 - beta)/(beta^3 (2 - beta)^2), lambda = (3/2) beta^2 (2 - beta) (%s)' % '; '.join(txt))
    tau0, beta, q = HYP_PTS[0]; b1 = bit_pointwise(engine_eval(frame_hyp(tau0, F(1, 2), beta, q, fac)))
    al = 2 * math.atanh(float(tau0)); d = std_point(g_hyp(float(beta), fac), [al, 2 * math.atan(0.5), 0, 0], [1e-3, 1e-3, 1, 1], (0, 1))
    chk('bit==std', close(d['wm'], float(b1['wm']), 1e-6) and abs(d['wp']) < 1e-6 * max(1, d['wm']) and close(d['s'], float(b1['s']), 1e-6) and d['r0'] < 1e-6 * max(1, d['s'] ** 2),
        '(tau, beta) = (%s, %s): |W-|^2 = %s and s = %s of g~ from the engine equal the numpy values; numpy |W+|^2 and |r0|^2 below 1e-6' % (tau0, beta, b1['wm'], b1['s']))
    tick('part 5')

def part_cells():
    head('(6) the cell Cl(0,4) (space squares -1) gives the same two 4-forms as Cl(4,0)')
    Gm, Sm = engine_objects([-1, -1, -1, -1]); same = True
    for t0, beta in ((F(2, 5), F(1, 2)), (F(3, 4), F(2))):
        a = engine_eval(frame_cp2(t0, F(1), beta)); b = engine_eval(frame_cp2(t0, F(1), beta), Gm, Sm); same &= (a['E4'] == b['E4'] and a['P4'] == b['P4'] and b['tf'])
    chk('bit', same, 'CP^2 family at (t, beta) = (2/5, 1/2), (3/4, 2): eps R^R and sum R^ab R^ab agree exactly in the two Euclidean cells (both are quadratic in R)')

def main():
    print('%s: frame algebra Cl(4,0) by the bit rule, forms with null generators, exact fractions; numpy %s for the standard route' % (STEP, np.__version__))
    if FAULT: print('FAULT: %s (the wrong version replaces the right one; the script must exit 1)' % FAULT)
    part1(); part2(); part3(); part4(); part5(); part_cells()
    finish(STEP)

if __name__ == '__main__':
    if '--fault' in sys.argv[1:]:
        _i = sys.argv.index('--fault'); FAULT = sys.argv[_i + 1] if _i + 1 < len(sys.argv) else None
        if FAULT not in FAULTS: raise SystemExit('--fault takes one of: ' + ', '.join(FAULTS))
    main()
