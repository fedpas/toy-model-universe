#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSB-CW.  Chern-Weil on the bit rule: the invariant quadratic forms of so(p,q) and the closed, transgressing forms P(F).   python3 gsb_chern_weil.py [--fault EUCL|FLIP|HALF]

Statement.  (1) The Ad-invariant symmetric bilinear forms on so(p,q) (the bivectors of Cl(p,q), bracket from the bit rule) form a space of
dimension 1 for p + q = 3, 5, 6 and of dimension 2 for p + q = 4; for p + q = 4 the two forms are the scalar part <XY>_0 and the pseudoscalar
part <XY>_4 of the Clifford product of two bivectors (the trace form and the eps-form), so tr R^R and eps R^R are the only quadratic ones on
so(1,3).  (2) For an invariant K and a connection A (F = dA + (1/4) f A^A, the engine's curvature), P_K(F) = K_BC F^B ^ F^C is closed;
(3) for two connections P(F_1) - P(F_0) = d( 2 int_0^1 K(A_1 - A_0, F_t) dt ), F_t the curvature of A_0 + t (A_1 - A_0); (4) under any
variation dA, d P = d( 2 K(dA, F) ): adding the integral of P to an action changes no field equation.
[bit]  the engine's Lie(sq) f table for the 12 algebras so(p,q), p + q = 3..6, p >= q: the invariance equations K(f(A,B), C) + K(B, f(A,C)) = 0
       for all generators, solved exactly (integer elimination, Fractions for the null space); the bit-rule forms <XY>_0, <XY>_4 (bmul) in the
       kernel.  P_K on random polynomial connections over 5 coordinates (forms = the bit rule with null generators, Grav(5, Lie(sq))), for
       every invariant form found, on so(3), so(2,1), so(4), so(3,1), so(2,2), so(4,1): dP = 0, the transgression (the t-integral exact:
       F_t is quadratic in t, Simpson's rule), and the first variation (the coefficient of s in P(F(A + s dA)) by exact interpolation).
[std]  plain so(p,q) matrices L_ab = E_ab eta_bb - E_ba eta_aa (numpy): structure constants by least squares, the kernel dimension by SVD, the
       trace form tr(XY) and eps_abcd X^ab Y^cd invariant to 1e-12; the matrix curvature F_mn = d_m A_n - d_n A_m + [A_m, A_n] of A = A^C L_C at
       rational points and tr(F ^ F)_{0123} compared with the engine's P for the form tr(L_B L_C).
Scope: the counts for every so(p,q) with p + q = 3..6; the P(F) statements on one random connection pair per algebra (polynomials of degree 1,
coefficients -3..3, seed fixed), exact.  Chern-Weil theory for all invariant polynomials and the characteristic classes are recalled
(Chern and Simons, Characteristic forms and geometric invariants; Kobayashi and Nomizu, Foundations of Differential Geometry).
Controls: the Euclidean contraction sum_B X^B Y^B on so(3,1) (not invariant): not in the kernel, dP != 0; a random symmetric form: dP != 0;
one structure constant of the table flipped: the kernel changes; the transgression with 1 in place of 2.  --fault EUCL | FLIP | HALF puts each
into its main check (exit 1)."""
import os, sys, time, random, itertools
from math import gcd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'EUCL', 'FLIP', 'HALF'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def sig(p, q): return [1] * p + [-1] * q
ALGS = [(p, N - p) for N in (3, 4, 5, 6) for p in range(N, (N - 1) // 2, -1)]          # p >= q

# ------------------------------------------------------------------------------------------------ exact linear algebra on integer rows
def int_rref(rows, ncols):
    """reduced row echelon form over Q of integer rows (kept integer, gcd-normalised); returns (pivot columns, rows)"""
    R = []; seen = set()
    for r in rows:
        if not any(r): continue
        g = 0
        for x in r: g = gcd(g, x)
        r = tuple(x // g for x in r); fst = next(x for x in r if x)
        if fst < 0: r = tuple(-x for x in r)
        if r not in seen: seen.add(r); R.append(list(r))
    piv = []; k = 0
    for c in range(ncols):
        p = next((i for i in range(k, len(R)) if R[i][c] != 0), None)
        if p is None: continue
        R[k], R[p] = R[p], R[k]; pr = R[k]
        for i in range(len(R)):
            if i != k and R[i][c] != 0:
                a, b = pr[c], R[i][c]; row = [a * x - b * y for x, y in zip(R[i], pr)]; g = 0
                for x in row: g = gcd(g, x)
                R[i] = [x // g for x in row] if g > 1 else row
        piv.append(c); k += 1
    return piv, R[:k]
def null_space(piv, R, ncols):
    free = [c for c in range(ncols) if c not in piv]; out = []
    for f in free:
        v = [F(0)] * ncols; v[f] = F(1)
        for i, c in enumerate(piv): v[c] = F(-R[i][f], R[i][c])
        out.append(v)
    return out

def sym_index(G):
    idx = {}
    for B in range(G):
        for C in range(B, G): idx[(B, C)] = len(idx)
    return idx
def invariance_rows(L, flip=False):
    """rows of K(f(A,B), C) + K(B, f(A,C)) = 0 over all A, B, C (unknowns K_BC, B <= C)"""
    G = L.G; idx = sym_index(G); f = dict(L.f)
    if flip:
        k0 = sorted(f)[0]; C0, c0 = f[k0]; f[k0] = (C0, -c0)
    rows = []
    for A in range(G):
        for B in range(G):
            for C in range(B, G):
                r = [0] * len(idx)
                if (A, B) in f: D, c = f[(A, B)]; r[idx[(min(D, C), max(D, C))]] += c
                if (A, C) in f: D, c = f[(A, C)]; r[idx[(min(B, D), max(B, D))]] += c
                rows.append(r)
    return rows, idx
def bit_form(L, grade_mask):
    """K_BC = the coefficient of the blade grade_mask in the Clifford product B_B B_C (bit rule): mask 0 gives <XY>_0, the full mask <XY>_N"""
    G = L.G; K = {}
    for B in range(G):
        for C in range(G):
            m, s = bmul(L.gens[B], L.gens[C], L.sq)
            if m == grade_mask and s: K[(B, C)] = F(s)
    return K
def as_vec(K, idx): return [K.get(k, F(0)) for k in sorted(idx, key=idx.get)]
def in_kernel(rows, v): return all(sum(F(a) * b for a, b in zip(r, v)) == 0 for r in rows)
def rank_F(vectors):
    return rank_exact([list(v) for v in vectors]) if vectors else 0

# ------------------------------------------------------------------------------------------------ [std] plain matrices
def so_mats(sq):
    N = len(sq); out = []
    for a in range(N):
        for b in range(a + 1, N):
            M = np.zeros((N, N)); M[a, b] = sq[b]; M[b, a] = -sq[a]; out.append(M)
    return out
def std_count(sq):
    Ls = so_mats(sq); G = len(Ls); basis = np.array([M.ravel() for M in Ls]).T
    c = np.zeros((G, G, G))
    for A in range(G):
        for B in range(G):
            com = Ls[A] @ Ls[B] - Ls[B] @ Ls[A]; c[A, B] = np.linalg.lstsq(basis, com.ravel(), rcond=None)[0]
    idx = sym_index(G); rows = []
    for A in range(G):
        for B in range(G):
            for C in range(B, G):
                r = np.zeros(len(idx))
                for D in range(G):
                    r[idx[(min(D, C), max(D, C))]] += c[A, B, D]; r[idx[(min(B, D), max(B, D))]] += c[A, C, D]
                rows.append(r)
    s = np.linalg.svd(np.array(rows), compute_uv=False); null = int((s < 1e-9 * s.max()).sum()) + max(0, len(idx) - len(s))
    tr_res = max(abs(np.trace((Ls[A] @ X - X @ Ls[A]) @ Y) + np.trace(X @ (Ls[A] @ Y - Y @ Ls[A]))) for A in range(G) for X in Ls for Y in Ls)
    return null, c, Ls, tr_res
def eps_res(sq):
    """eps_abcd X^ab Y^cd invariant on so(p,q), p + q = 4 (matrices with one index raised by eta)"""
    Ls = so_mats(sq); eta = np.diag(sq); out = 0.0
    eps = np.zeros((4, 4, 4, 4))
    for p in itertools.permutations(range(4)):
        s = 1
        for i in range(4):
            for j in range(i + 1, 4):
                if p[i] > p[j]: s = -s
        eps[p] = s
    up = lambda M: M @ np.linalg.inv(eta)                                          # X^{ab} from the matrix X^a_b
    form = lambda X, Y: np.einsum('abcd,ab,cd->', eps, up(X), up(Y))
    for Z in Ls:
        for X in Ls:
            for Y in Ls: out = max(out, abs(form(Z @ X - X @ Z, Y) + form(X, Z @ Y - Y @ Z)))
    nz = max(abs(form(X, Y)) for X in Ls for Y in Ls)
    return out, nz

# ------------------------------------------------------------------------------------------------ [bit] P(F) on forms over 5 coordinates
NC = 5
def rconn(rng, G): return [gs.rform(rng, NC, 1, 1, .7) for _ in range(G)]
def PK(Gv, K, Fc):
    Fm = Gv.Fm; out = {}
    for (B, C), k in K.items():
        if k: out = Fm.add(out, Fm.wedge(Fc[B], Fc[C]), k)
    return out
def KX(Gv, K, X, Y, c=1):
    Fm = Gv.Fm; out = {}
    for (B, C), k in K.items():
        if k: out = Fm.add(out, Fm.wedge(X[B], Y[C]), c * k)
    return out
def lin_comb(Fm, terms):
    out = {}
    for c, X in terms: out = Fm.add(out, X, c)
    return out
def is_zero(X): return all(not p for p in X.values())
def eqf(X, Y): return all(X.get(k, {}) == Y.get(k, {}) for k in set(X) | set(Y))
def interp_s1(vals, nodes):
    """coefficient of s^1 of the polynomial through (nodes, vals) (forms), exact Lagrange"""
    Fm = Forms(NC); n = len(nodes); out = {}
    # coefficient of s in prod_{j != i} (s - s_j) / (s_i - s_j)
    for i in range(n):
        others = [nodes[j] for j in range(n) if j != i]; den = F(1)
        for sj in others: den *= (nodes[i] - sj)
        # derivative at 0 of prod (s - s_j) = sum_k prod_{j != k} (-s_j)
        num = F(0)
        for k in range(len(others)):
            t = F(1)
            for j, sj in enumerate(others):
                if j != k: t *= -sj
            num += t
        out = Fm.add(out, vals[i], num / den)
    return out
def point_eval(form, pt):
    return {m: sum((v * np.prod([pt[i] ** e for i, e in enumerate(k)]) for k, v in p.items()), 0.0) for m, p in form.items()}
def std_trFF(A, Ls, pt):
    """[std] tr(F ^ F)_{0123} at pt, F_mn = d_m A_n - d_n A_m + [A_m, A_n], A_m = sum_C A^C_m L_C (numpy, exact polynomial derivatives evaluated in floats)"""
    G = len(Ls); N = Ls[0].shape[0]
    def comp(C, mu): return A[C].get(1 << mu, {})
    def ev(p): return sum((float(v) * np.prod([pt[i] ** e for i, e in enumerate(k)]) for k, v in p.items()), 0.0)
    def dv(p, i): return ev(pder(p, i))
    Am = [sum((ev(comp(C, mu)) * Ls[C] for C in range(G)), np.zeros((N, N))) for mu in range(NC)]
    Fmn = {}
    for m in range(NC):
        for n_ in range(NC):
            d = sum(((dv(comp(C, n_), m) - dv(comp(C, m), n_)) * Ls[C] for C in range(G)), np.zeros((N, N)))
            Fmn[(m, n_)] = d + Am[m] @ Am[n_] - Am[n_] @ Am[m]
    return 2 * np.trace(Fmn[(0, 1)] @ Fmn[(2, 3)] - Fmn[(0, 2)] @ Fmn[(1, 3)] + Fmn[(0, 3)] @ Fmn[(1, 2)])

def main():
    head('GSB-CW: invariant quadratic forms of so(p,q), p + q = 3..6, from the engine\'s f table; P(F) closed and transgressing' + (' [fault %s]' % FAULT if FAULT else ''))
    want = {3: 1, 4: 2, 5: 1, 6: 1}; kernels = {}
    for (p, q) in ALGS:
        N = p + q; sq = sig(p, q); L = Lie(sq)
        rows, idx = invariance_rows(L, flip=(FAULT == 'FLIP' and (p, q) == (3, 1)))
        piv, R = int_rref(rows, len(idx)); ns = null_space(piv, R, len(idx)); kernels[(p, q)] = (L, rows, idx, ns)
        K0 = as_vec(bit_form(L, 0), idx); ok0 = in_kernel(rows, K0)
        msg = 'so(%d,%d) (%d generators, %d equations, %d unknowns): the invariant symmetric bilinear forms have dimension %d (predicted %d); <XY>_0 lies in the kernel' % (p, q, L.G, len(rows), len(idx), len(ns), want[N])
        if N == 4:
            K4 = as_vec(bit_form(L, 15), idx); ok4 = in_kernel(rows, K4); indep = rank_F([K0, K4]) == 2
            chk('bit', len(ns) == 2 and ok0 and ok4 and indep and rank_F(ns + [K0, K4]) == 2, msg + ', and so does <XY>_4 (the eps-form): the two span it')
        else:
            chk('bit', len(ns) == want[N] and ok0 and rank_F(ns + [K0]) == want[N], msg + ', and spans it')
        nstd, c, Ls, trr = std_count(sq)
        fmatch = all(abs(2 * c[A, B, C] - (L.f[(A, B)][1] if (A, B) in L.f and L.f[(A, B)][0] == C else 0)) < 1e-9 for A in range(L.G) for B in range(L.G) for C in range(L.G))
        chk('bit==std', nstd == len(ns) and fmatch and trr < 1e-12, 'so(%d,%d): plain matrices: the engine\'s f table = 2 x the matrix structure constants; kernel dimension by SVD %d = exact %d; tr(XY) invariant (residual %.1e)' % (p, q, nstd, len(ns), trr))
        if N == 4:
            er, nz = eps_res(sq)
            chk('std', er < 1e-12 and nz > 0.5, 'so(%d,%d): [std] eps_abcd X^ab Y^cd is invariant (residual %.1e) and not zero' % (p, q, er))
    tick('kernels')
    head('P(F) on random polynomial connections over %d coordinates, every invariant form' % NC)
    PF_ALGS = [(3, 0), (2, 1), (4, 0), (3, 1), (2, 2), (4, 1)]
    for (p, q) in PF_ALGS:
        sq = sig(p, q); L, rows, idx, ns = kernels[(p, q)]; Gv = Grav(NC, L); Fm = Gv.Fm; G = L.G
        forms = [('<XY>_0', bit_form(L, 0))] + ([('<XY>_4', bit_form(L, 15))] if p + q == 4 else [])
        if FAULT == 'EUCL' and (p, q) == (3, 1): forms = [('Euclidean contraction', {(B, B): F(1) for B in range(G)})]
        rng = random.Random(5100 + 10 * p + q)
        A0 = rconn(rng, G); A1 = rconn(rng, G); dA = rconn(rng, G); eta_ = [Fm.add(A1[C], A0[C], -1) for C in range(G)]
        Ah = [Fm.add(A0[C], eta_[C], F(1, 2)) for C in range(G)]
        F0 = Gv.curvature(A0); F1 = Gv.curvature(A1); Fh = Gv.curvature(Ah)
        Fint = [lin_comb(Fm, [(F(1, 6), F0[C]), (F(4, 6), Fh[C]), (F(1, 6), F1[C])]) for C in range(G)]
        nodes = [F(0), F(1), F(-1), F(2), F(-2)]
        Fs = [Gv.curvature([Fm.add(A0[C], dA[C], s) for C in range(G)]) for s in nodes]
        for name, K in forms:
            P0 = PK(Gv, K, F0); P1 = PK(Gv, K, F1); closed = is_zero(Fm.d(P0)) and is_zero(Fm.d(P1)) and not is_zero(P0)
            Q = KX(Gv, K, eta_, Fint, 1 if FAULT == 'HALF' else 2); trans = eqf(Fm.add(P1, P0, -1), Fm.d(Q)) and not is_zero(Q)
            dP = interp_s1([PK(Gv, K, Fs_) for Fs_ in Fs], nodes); var_ok = eqf(dP, Fm.d(KX(Gv, K, dA, F0, 2))) and not is_zero(dP)
            chk('bit', closed and trans and var_ok, 'so(%d,%d), %s: P = K(F ^ F) is closed (d P = 0 on 5 coordinates), P(F_1) - P(F_0) = d(2 int_0^1 K(A_1 - A_0, F_t) dt) exactly, and the first variation is d(2 K(dA, F)) (P non-zero)' % (p, q, name))
        if (p, q) in ((3, 1), (2, 2), (4, 0)):
            Ktr = {(B, C): F(int(round(np.trace(Ls_[B] @ Ls_[C])))) for Ls_ in [so_mats(sq)] for B in range(G) for C in range(G) if abs(np.trace(Ls_[B] @ Ls_[C])) > 0.5}
            P0t = PK(Gv, Ktr, F0); Ls = so_mats(sq); worst = 0.0
            for pt in ([0.5, -0.25, 1.0, 0.75, -0.5], [-1.0, 0.5, 0.25, -0.75, 1.5]):
                v_bit = point_eval(P0t, pt).get(15, 0.0); v_std = std_trFF(A0, Ls, pt); worst = max(worst, abs(v_bit - v_std) / max(1.0, abs(v_std)))
            chk('bit==std', worst < 1e-9, 'so(%d,%d): the engine\'s P for K = tr(L_B L_C) equals the matrix tr(F ^ F)_{0123} at two rational points (relative %.1e; F of the matrix connection A^C L_C)' % (p, q, worst))
            if (p, q) == (3, 1):
                chk('bit', all(Ktr.get((B, C), 0) == 2 * bit_form(L, 0).get((B, C), 0) for B in range(G) for C in range(G)), 'so(3,1): the matrix trace form tr(L_B L_C) = 2 <B_B B_C>_0 (the scalar part of the bit-rule product)')
    tick('P(F)')
    head('controls')
    L, rows, idx, ns = kernels[(3, 1)]; G = L.G; Gv = Grav(NC, L); Fm = Gv.Fm
    Ke = {(B, B): F(1) for B in range(G)}; rng = random.Random(77); A0 = rconn(rng, G); F0 = Gv.curvature(A0)
    chk('ctl', not in_kernel(rows, as_vec(Ke, idx)) and not is_zero(Fm.d(PK(Gv, Ke, F0))), 'so(3,1): the Euclidean contraction sum_B X^B Y^B is not invariant and its P is not closed')
    rng2 = random.Random(78); Kr = {}
    for B in range(G):
        for C in range(B, G):
            v = F(rng2.randint(-3, 3)); Kr[(B, C)] = v; Kr[(C, B)] = v
    chk('ctl', not is_zero(Fm.d(PK(Gv, Kr, F0))), 'so(3,1): a random symmetric form gives d P != 0')
    rowsf, idxf = invariance_rows(L, flip=True); pivf, Rf = int_rref(rowsf, len(idxf))
    chk('ctl', len(idxf) - len(pivf) != len(ns), 'so(3,1) with one structure constant of the table flipped: the kernel dimension is %d, not %d' % (len(idxf) - len(pivf), len(ns)))
    A1 = rconn(rng, G); eta_ = [Fm.add(A1[C], A0[C], -1) for C in range(G)]; Ah = [Fm.add(A0[C], eta_[C], F(1, 2)) for C in range(G)]
    F1 = Gv.curvature(A1); Fh = Gv.curvature(Ah); Fint = [lin_comb(Fm, [(F(1, 6), F0[C]), (F(4, 6), Fh[C]), (F(1, 6), F1[C])]) for C in range(G)]
    K0 = bit_form(L, 0)
    chk('ctl', not eqf(Fm.add(PK(Gv, K0, F1), PK(Gv, K0, F0), -1), Fm.d(KX(Gv, K0, eta_, Fint, 1))), 'so(3,1): the transgression with 1 in place of 2 is not exact')
    tick('done')
    finish('GSB-CW')

if __name__ == '__main__': main()
