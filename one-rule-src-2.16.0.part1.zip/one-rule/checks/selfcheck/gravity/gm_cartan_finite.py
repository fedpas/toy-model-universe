#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-CFIN.  The finite gauge law of a connection with the Lie table as the parameter: A -> g^-1 A g + g^-1 dg gives F -> g^-1 F g.
    python3 gm_cartan_finite.py [--fault NODG|GINV|FACT]

 With g = exp(lambda) and ad_lambda Y = (1/2) f_AB^C lambda^A Y^B (the bracket of the engine's curvature F^C = d w^C + (1/4) f_AB^C w^A ^ w^B):
   g^-1 A g = sum_k (-ad_lambda)^k A/k!,   g^-1 dg = sum_k (-ad_lambda)^k d lambda/(k+1)!,   g^-1 F g = sum_k (-ad_lambda)^k F/k!.
 Exactness: lambda is a polynomial 0-form with lambda(0) = 0, so (ad_lambda)^k raises the degree in the coordinates by at least k; with the series to k = 4 and every product truncated
 at degree 4 (g as an exponential truncated at degree 4), A' is exact to degree 4 and F(A') to degree 3: the identity is asserted on every coefficient of degree <= 3. The first truncation
 error sits at degree 4: shown on one table (the degree-4 coefficients differ at truncation 4 and agree at truncation 5).
 Tables: gm_cartan_bianchi.tables() on at most 4 coordinates: so(1,2) x R^3, so(1,3), so(2,2) (3 coordinates), so(1,3) x R^4, so(1,4), so(2,3) (4), so(3) and so(4) on 3 and 4; three random
 connections per table (strong sampler of a2b_strong_sampling: degree 1, integers -50..50), lambda of degree <= 2 without constant term (same sampler).
 [bit]  the series with the engine's f table, wedge and d; F(A') by the engine's curvature (the part of degree <= 3: the curvature of A' to degree 3 plus d of its degree-4 part);
        the infinitesimal law as the first-order term (lambda -> t lambda, t the bookkeeping slot kept to t^1): delta A = D_A lambda (engine D_bivector), delta F = [F, lambda] = (1/2) f F lambda.
 [std]  so(3) as plain 3 x 3 matrices, no engine: g = (I - K)(I + K)^-1, the Cayley transform of a skew polynomial K(x) (g orthogonal, det 1, exactly), K(p) = rotation generator with
        g(p) the rotation with entries 3/5, 4/5 about z; jets of degree 2 at the rational point p (Fractions, b1lib's plain polynomial code); A' = g^T A g + g^T dg;
        F'(p) = d A' - d A' + [A', A'] equals g^T F g at p, three random connections; numpy: the structure constants of the matrices.
 [bit==std] the engine's f table = 2 x the matrix structure constants (each table); the engine's curvature of the Cayley-transformed connection = g^T F g of the matrix route.
 Controls (--fault puts each into the main check): NODG A -> g^-1 A g without g^-1 dg; GINV g in place of g^-1 in the conjugation; FACT 1/k! in place of 1/(k+1)! in g^-1 dg."""
import os, sys, random, itertools, time
from math import factorial
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from a2b_strong_sampling import s_form, s_poly
import gm_cartan_bianchi as CB
import numpy as np

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'NODG', 'GINV', 'FACT'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
D = 4; R50 = 50; SEEDS = (31, 1031, 2031)

def deg_le(X, d, n): return {m: q for m, q in ((m, {k: v for k, v in p.items() if sum(k[:n]) <= d}) for m, p in X.items()) if q}
def lst_deg(Xs, d, n): return [deg_le(x, d, n) for x in Xs]
def ad(Gv, lam, Y):
    """[lambda, Y] = (1/2) f_AB^C lambda^A Y^B (engine f table and wedge)"""
    Fm = Gv.Fm; out = [{} for _ in range(Gv.G)]
    for (A, B), (C, f) in Gv.L.f.items():
        if lam[A] and Y[B]: out[C] = Fm.add(out[C], Fm.wedge(lam[A], Y[B]), F(f, 2))
    return out
def exp_series(Gv, lam, Y, coef, kmax, sign=-1):
    """sum_{k <= kmax} coef(k) (sign ad_lambda)^k Y"""
    Fm = Gv.Fm; out = [Fm.scale(y, coef(0)) for y in Y]; T = Y
    for k in range(1, kmax + 1):
        T = [Fm.scale(t, sign) for t in ad(Gv, lam, T)]
        out = [Fm.add(o, t, coef(k)) for o, t in zip(out, T)]
    return out
def transform(Gv, lam, A, Dg, fault=None):
    """A' = g^-1 A g + g^-1 dg as the series (under the caller's truncation)"""
    Fm = Gv.Fm
    A1 = exp_series(Gv, lam, A, lambda k: F(1, factorial(k)), Dg, sign=(1 if fault == 'GINV' else -1))
    if fault == 'NODG': return A1
    dl = [Fm.d(l) for l in lam]
    A2 = exp_series(Gv, lam, dl, (lambda k: F(1, factorial(k))) if fault == 'FACT' else (lambda k: F(1, factorial(k + 1))), Dg)
    return [Fm.add(x, y) for x, y in zip(A1, A2)]
def curv_low(Gv, Ap, d, n):
    """the engine's curvature of A' on the coefficients of degree <= d: curvature of the part of degree <= d, plus d of the rest"""
    Fm = Gv.Fm; lo = lst_deg(Ap, d, n); hi = [Fm.add(x, y, -1) for x, y in zip(Ap, lo)]
    with trunc(n, xdeg=d): Fl = Gv.curvature(lo)
    return [deg_le(Fm.add(Fl[C], Fm.d(hi[C])), d, n) for C in range(Gv.G)]
def finite_case(Gv, A, lam, n, Dg=D, fault=None):
    """returns (F(A') = g^-1 F g on degree <= Dg - 1, the transformation is not trivial there)"""
    with trunc(n, xdeg=Dg):
        Ap = transform(Gv, lam, A, Dg, fault); Fc = Gv.curvature(A)
        Fp = exp_series(Gv, lam, Fc, lambda k: F(1, factorial(k)), Dg)
    Fl = curv_low(Gv, Ap, Dg - 1, n)
    ok = all(Fl[C] == deg_le(Fp[C], Dg - 1, n) for C in range(Gv.G))
    nontriv = any(deg_le(Gv.Fm.add(Fp[C], Fc[C], -1), Dg - 1, n) for C in range(Gv.G))
    return ok, nontriv, Ap, Fp, Fc
def rand_lambda(rng, n, G, nv=None):
    return [{0: p} if p else {} for p in ({k: v for k, v in s_poly(rng, n, 2, R50).items() if sum(k) > 0} for _ in range(G))]
def pad(X, n): return {m: {k + (0,): v for k, v in p.items()} for m, p in X.items()}
def times_t(X, n): return {m: {k[:n] + (k[n] + 1,): v for k, v in p.items()} for m, p in X.items()}
def t_part(X, n, j): return {m: q for m, q in ((m, {k[:n] + (0,): v for k, v in p.items() if k[n] == j}) for m, p in X.items()) if q}

# ------------------------------------------------------------------------------------------------ [std] so(3) matrices with polynomial entries (b1lib's plain polynomial code)
NC = 3; DJ = 2
def M0(n=3): return [[{} for _ in range(n)] for _ in range(n)]
def mmul(A, B): return [[lin(*[(F(1), sp_mul(A[i][k], B[k][j], DJ, NC)) for k in range(3) if A[i][k] and B[k][j]]) for j in range(3)] for i in range(3)]
def madd(A, B, c=1): return [[sp_add(A[i][j], B[i][j], c) for j in range(3)] for i in range(3)]
def mT(A): return [[A[j][i] for j in range(3)] for i in range(3)]
def mder(A, mu): return [[sp_der(A[i][j], mu) for j in range(3)] for i in range(3)]
def mval(A): return [[at0(A[i][j], NC) for j in range(3)] for i in range(3)]
def mconst(Mn): return [[const(NC, Mn[i][j]) for j in range(3)] for i in range(3)]
def minv_series(Mx):
    """M^-1 as a jet of degree 2 (Neumann series around the constant part)"""
    m0 = mval(Mx); det, m0i = det_inv(m0); assert det != 0
    Ni = mconst(m0i); Nn = madd(Mx, mconst(m0), -1); T = mmul(Ni, Nn); T = [[scale(x, -1) for x in r] for r in T]
    out = Ni; term = Ni
    for _ in range(DJ): term = mmul(T, term); out = madd(out, term)
    return out
def cayley(kv):
    """g = (I - K)(I + K)^-1 for the skew K of the vector kv (K v = kv x v)"""
    k1, k2, k3 = kv; K = [[{}, scale(k3, -1), k2], [k3, {}, scale(k1, -1)], [scale(k2, -1), k1, {}]]
    I = mconst([[F(int(i == j)) for j in range(3)] for i in range(3)])
    return mmul(madd(I, K, -1), minv_series(madd(I, K)))
def mat_conn(om, mats, p):
    """A_mu = sum_A w^A_mu L_A as matrices of jets around p"""
    out = []
    for mu in range(NC):
        Mx = M0()
        for A, L_ in enumerate(mats):
            q = shift_poly(om[A].get(1 << mu, {}), p, NC)
            if q: Mx = madd(Mx, [[scale(q, L_[i][j]) for j in range(3)] for i in range(3)])
        out.append(Mx)
    return out
def mat_F_at(Am):
    out = {}
    for m, n in itertools.combinations(range(NC), 2):
        a, b = mval(Am[m]), mval(Am[n]); d1, d2 = mval(mder(Am[n], m)), mval(mder(Am[m], n))
        out[(m, n)] = [[d1[i][j] - d2[i][j] + sum(a[i][k] * b[k][j] - b[i][k] * a[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    return out
def mat_transform(Am, g, mode=None):
    gt = mT(g); out = []
    for mu in range(NC):
        conj = mmul(mmul(gt, Am[mu]), g) if mode != 'GINV' else mmul(mmul(g, Am[mu]), gt)
        out.append(conj if mode == 'NODG' else madd(conj, mmul(gt, mder(g, mu))))
    return out
def conj_at(Fd, g0):
    gt = [[g0[j][i] for j in range(3)] for i in range(3)]
    mm_ = lambda X, Y: [[sum(X[i][k] * Y[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    return {k: mm_(mm_(gt, v), g0) for k, v in Fd.items()}

def main():
    head('GM-CFIN: the finite gauge law on the Lie tables (at most 4 coordinates)' + (' [fault %s]' % FAULT if FAULT else ''))
    tabs = [t for t in CB.tables() if t[2] <= 4]
    for name, sq, nc, base, s in tabs:
        L = Lie(sq); Gv = Grav(nc, L); G = L.G
        mats = CB.so_mats(sq, L.gens); c, jres = CB.std_structure(mats)
        f_ok = all(abs(2 * c[A, B, C] - (L.f[(A, B)][1] if (A, B) in L.f and L.f[(A, B)][0] == C else 0)) < 1e-12 for A in range(G) for B in range(G) for C in range(G))
        ok = True; nt = True
        for sd in SEEDS:
            rng = random.Random(sd + 100 * nc + len(sq)); A = [s_form(rng, nc, 1, 1, R50) for _ in range(G)]; lam = rand_lambda(rng, nc, G)
            o, t_, _, _, _ = finite_case(Gv, A, lam, nc, D, FAULT); ok &= o; nt &= t_
        chk('bit==std', f_ok and jres < 1e-12, '%s: the engine\'s f table (%d generators) = 2 x the structure constants of the matrices L_AB (numpy)' % (name, G))
        chk('bit', ok and nt, '%s: F(g^-1 A g + g^-1 dg) = g^-1 F g on every coefficient of degree <= 3, g = exp(lambda) truncated at degree 4, three random connections (g^-1 F g != F there)' % name)
        rng = random.Random(7 + nc + len(sq)); A = [pad(s_form(rng, nc, 1, 1, R50), nc) for _ in range(G)]
        lam0 = rand_lambda(rng, nc, G); lam = [times_t(pad(x, nc), nc) for x in lam0]
        with trunc(nc, xdeg=D, lam=1):
            Ap = transform(Gv, lam, A, D, FAULT); Fc = Gv.curvature(A); Fp = exp_series(Gv, lam, Fc, lambda k: F(1, factorial(k)), D)
        lp = [pad(x, nc) for x in lam0]
        with trunc(nc, xdeg=D, lam=0):
            DL = Gv.D_bivector(A, lp); br = [{} for _ in range(G)]
            for (P, Q), (C, f) in L.f.items(): br[C] = Gv.Fm.add(br[C], Gv.Fm.wedge(Fc[P], lp[Q]), F(f, 2))
        inf_ok = all(t_part(Ap[C], nc, 1) == {m: q for m, q in DL[C].items() if q} and t_part(Fp[C], nc, 1) == {m: q for m, q in br[C].items() if q} and t_part(Ap[C], nc, 0) == A[C] for C in range(G))
        chk('bit', inf_ok and any(DL), '%s: lambda -> t lambda: the t^1 terms of the finite law are delta A = D_A lambda (engine D_bivector) and delta F = (1/2) f F lambda = [F, lambda]: the infinitesimal law' % name)
    tick('tables')
    head('the degree of the error term (so(3) on 3 coordinates, one connection) [bit]')
    L = Lie([-1] * 3); Gv = Grav(3, L); rng = random.Random(99); A = [s_form(rng, 3, 1, 1, R50) for _ in range(3)]; lam = rand_lambda(rng, 3, 3)
    ok4, _, Ap4, Fp4, _ = finite_case(Gv, A, lam, 3, 4); ok5, _, Ap5, Fp5, _ = finite_case(Gv, A, lam, 3, 5)
    with trunc(3, xdeg=4): Ffull4 = Gv.curvature(Ap4)
    d4 = lambda X: {m: q for m, q in ((m, {k: v for k, v in p.items() if sum(k) == 4}) for m, p in X.items()) if q}
    low_same = all(deg_le(Fp4[C], 3, 3) == deg_le(Fp5[C], 3, 3) for C in range(3))
    err_at4 = any(d4(Ffull4[C]) != d4(Fp4[C]) for C in range(3)); fix_at5 = all(curv_low(Gv, Ap5, 4, 3)[C] == deg_le(Fp5[C], 4, 3) for C in range(3))
    chk('bit', ok4 and ok5 and low_same and err_at4 and fix_at5, 'truncation at degree 4: F(A\') = g^-1 F g on degree <= 3, the degree-4 coefficients differ (the first error term); at degree 5 they agree on degree <= 4; degree <= 3 is the same at both')
    head('controls: the wrong versions of the finite law (so(1,3) on 3 coordinates, three connections) [ctl]')
    name, sq, nc, base, s = tabs[1]; L = Lie(sq); Gv = Grav(nc, L)
    for fl, what in (('NODG', 'A -> g^-1 A g without g^-1 dg'), ('GINV', 'g in place of g^-1 in the conjugation (e^{+ad lambda} A)'), ('FACT', '1/k! in place of 1/(k+1)! in the series of g^-1 dg')):
        bad = 0
        for sd in SEEDS:
            rng = random.Random(sd + 100 * nc + len(sq)); A = [s_form(rng, nc, 1, 1, R50) for _ in range(L.G)]; lam = rand_lambda(rng, nc, L.G)
            bad += int(not finite_case(Gv, A, lam, nc, D, fl)[0])
        chk('ctl', bad == len(SEEDS), '%s: %s: F(A\') != g^-1 F g for %d of %d connections' % (name, what, bad, len(SEEDS)))
    tick('controls')
    head('[std] plain so(3) matrices: g = Cayley transform of a skew polynomial K, jets of degree 2 at p; [bit==std] the engine\'s curvature of the transformed connection')
    sq3 = [-1, -1, -1]; L3 = Lie(sq3); G3 = Grav(3, L3); mats = CB.so_mats(sq3, L3.gens); p = [F(1, 2), F(-2, 3), F(3, 4)]
    okS = True; okO = True; okB = True; nodg = 0; ginv = 0; okSk = True
    for sd in SEEDS:
        rng = random.Random(sd + 5); om = [s_form(rng, 3, 1, 1, R50) for _ in range(3)]
        kv = []
        for i in range(3):
            q = const(NC, F(1, 2) if i == 2 else 0)
            for j in range(3): q = sp_add(q, scale(var(NC, j), F(rng.randint(-5, 5), rng.randint(1, 4))))
            for j, k in itertools.combinations_with_replacement(range(3), 2): q = sp_add(q, scale(sp_mul(var(NC, j), var(NC, k), 2, NC), F(rng.randint(-5, 5), rng.randint(1, 4))))
            kv.append(q)
        g = cayley(kv); g0 = mval(g)
        okO &= all(madd(mmul(mT(g), g), mconst([[F(int(i == j)) for j in range(3)] for i in range(3)]), -1)[i][j] == {} for i in range(3) for j in range(3)) and g0[0][0] == F(3, 5) and abs(g0[0][1]) == F(4, 5)
        Am = mat_conn(om, mats, p); Fd = mat_F_at(Am); want = conj_at(Fd, g0)
        Ap = mat_transform(Am, g, FAULT if FAULT in ('NODG', 'GINV') else None)
        okS &= mat_F_at(Ap) == want and any(any(x != 0 for r in v for x in r) for v in want.values())
        nodg += int(mat_F_at(mat_transform(Am, g, 'NODG')) != want); ginv += int(mat_F_at(mat_transform(Am, g, 'GINV')) != want)
        lo1 = lambda q: {k: v for k, v in q.items() if sum(k) <= 1}                       # A' is exact to degree 1 (dg loses one degree)
        okSk &= all(lo1(sp_add(Ap[mu][i][j], Ap[mu][j][i])) == {} for mu in range(3) for i in range(3) for j in range(3))
        omp = [{1 << mu: q for mu in range(3) for q in [lo1(Ap[mu][ij[0]][ij[1]])] if q} for ij in ((1, 0), (2, 0), (2, 1))]
        with trunc(3, xdeg=1): Fe = G3.curvature(omp)
        okB &= all([[sum(at0(Fe[C].get((1 << m) | (1 << n), {}), NC) * mats[C][i][j] for C in range(3)) for j in range(3)] for i in range(3)] == want[(m, n)] for (m, n) in want)
    chk('std', okO, 'g = (I - K)(I + K)^-1 is orthogonal on the jets to degree 2 (g^T g = I) and g(p) has the entries 3/5, 4/5 of the triple (3, 4, 5), three random K')
    chk('std', okS, 'F\'(p) of A\' = g^T A g + g^T dg equals g^T(p) F(p) g(p) on all components, three random connections (exact, plain matrices)')
    chk('ctl', nodg == 3 and ginv == 3, 'matrices: without g^T dg (%d of 3) and with g A g^T in place of g^T A g (%d of 3) the transformed curvature is not g^T F g' % (nodg, ginv))
    chk('bit==std', okSk and okB, 'the engine\'s curvature of the Cayley-transformed connection (A\' skew on its exact jets to degree 1, its components on L_A) = g^T F g of the matrix route at p, three connections')
    tick('std')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GM-CFIN' + ('-' + FAULT if FAULT else ''))
