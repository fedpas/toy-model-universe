#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSB-DIRACSQ.  Squares of Dirac-type operators on the bit rule: Lichnerowicz on jets, the one-third rule for skew torsion, d + delta on forms.
   python3 gsb_dirac_sq.py [--fault C|HALF|TRACE|SIGN|NORIC]

(L) Lichnerowicz: for the torsion-free connection (A3 closed form) Dslash^2 psi = nabla^a nabla_a psi - (R/4) psi at the origin, n = 3, 4
    (E1's operators: Dslash = gamma^a nabla_a acting on the left, R the engine's scalar curvature, MTW sign).  Draws: frame e = dx + a 1-jet + a 2-jet
    with every coefficient an integer uniform in -50..50, spinor with every 2-jet coefficient uniform in -50..50; three draws per n.  The three terms
    are polynomials of degree <= 3 in the sampled coefficients (e(0) = 1, which a linear change of coordinates reaches); the degree is checked along
    a random line (fourth finite difference zero, third not), so a false identity of this form passes three draws with probability at most
    (3/101)^3 = 2.6e-5 per n (Schwartz-Zippel).
(T) The one-third rule: K^{pq} = sum_c eta_pp eta_qq A_pqc e^c with A totally antisymmetric (random polynomials of degree 1); the engine's torsion of
    omega + K is T_cab = -2 A_cab (totally skew).  D_t = the Dirac operator of omega + t K, nabla' the connection omega + K.  On spinors that vanish
    at the origin, D_t^2 - nabla'^a nabla'_a = (1 - 3t) (D_0^2 - nabla'^a nabla'_a) exactly: no first-order term at t = 1/3, a first-order term at
    t = 1/2 and t = 1; at t = 1/3 the difference depends only on psi(0) (order zero).  n = 3, 4, 5, two frames each.
(H) Hodge-Dirac in a flat chart (n = 3, 4; Lorentz and Euclidean squares; every grade p; random polynomial forms, coefficients -50..50): under the
    symbol map dx^I -> gamma^I, nabla = sum gamma^mu d_mu splits as d + delta: the grade p+1 part is d alpha (the engine's d) and the grade p-1 part is
    delta alpha = (-1)^(n(p+1)+s) * d * alpha (s = number of negative squares, * the Hodge star of g2_hodge), i.e. +div alpha with the bit rule's
    gamma_mu^2 = eta_mumu (= -d^dagger, d^dagger the codifferential); nabla^2 = eta^{mu nu} d_mu d_nu on every component; d d = 0 and delta delta = 0.
(W) Weitzenboeck on 1-forms in a curved frame (n = 3, 4, Lorentz, at the origin): (d delta + delta d) alpha with the engine's d and the frame Hodge
    star equals a nabla^c nabla_c alpha_b + b Ric_b^d alpha_d with (a, b) = (1, -1) (exact fit on two frames, verified on a third); nabla from the
    engine's D_covector, Ric from the engine's curvature (E1).
[bit]  the engine (Grav, D_spinor, D_covector, curvature, Forms.d, bmul), E1's engine_ops, A3's closed-form omega, g2_hodge's frame star.
[std]  (L), (T): E1's StdSpin (numpy: Dirac matrices, Christoffel symbols, five-point differences) at n = 3, 4 on draws with coefficients -3..3;
       (H): the textbook component codifferential sum_mu eta^mumu d_mu alpha_{mu ...} and the textbook star; (W): Christoffel calculus on
       g = e^T eta e (exact series): d(div alpha) + div(d alpha), the rough Laplacian g^{mu nu} nabla_mu nabla_nu alpha and the Ricci tensor.
Theorems recalled for every dimension: Lichnerowicz's formula (Lawson and Michelsohn, Spin Geometry); the skew-torsion rule (J.-M. Bismut,
A local index theorem for non-Kaehler manifolds; I. Agricola and T. Friedrich, On the holonomy of connections with skew-symmetric torsion).
Controls (--fault puts each into its main check, exit 1): C the coefficient -1/2 in place of -1/4; HALF the claim at t = 1/2; TRACE a torsion with a
trace part (no t removes the first-order term); SIGN delta with the opposite sign; NORIC the Weitzenboeck fit without the Ricci term."""
import os, sys, time, random, itertools
from math import comb
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import e1_lichnerowicz as E1
import g2_hodge as GH
import numpy as np

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'C', 'HALF', 'TRACE', 'SIGN', 'NORIC'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def bitsof(m): return [i for i in range(m.bit_length()) if m >> i & 1]
def mvz(X): return not X
def setup(n, sq, e, psi, deg=1):
    Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_)
    Dp = anholonomy(Gv, e, n, deg); om = omega_closed_form(Gv, e, S, n, 1, Dpre=anholonomy(Gv, e, n, 1) if deg != 1 else Dp)[0]
    e0, E0, det = E0_of(e, n, n)
    return dict(Gv=Gv, e=e, E=Dp[1], e0=e0, E0=E0, det=det, om=om, psi=psi, n=n, sq=list(sq))

# ------------------------------------------------------------------------------------------------ (L) Lichnerowicz with strong draws
def jets_frame(rng, n, lo=-50, hi=50, ident=True):
    mons = [ex for ex in itertools.product(range(3), repeat=n) if 1 <= sum(ex) <= 2]; e = []
    for a in range(n):
        form = {}
        for mu in range(n):
            p = {(0,) * n: F(1)} if (ident and a == mu) else {}
            for ex in mons:
                c = rng.randint(lo, hi)
                if c: p[ex] = F(c)
            if p: form[1 << mu] = p
        e.append(form)
    return e
def jets_spinor(rng, n, lo=-50, hi=50):
    mons = [ex for ex in itertools.product(range(3), repeat=n) if sum(ex) <= 2]; out = {}
    for S in range(1 << n):
        p = {}
        for ex in mons:
            c = rng.randint(lo, hi)
            if c: p[ex] = F(c)
        if p: out[S] = p
    return out
def lich_terms(n, sq, e, psi):
    d = setup(n, sq, e, psi); ops = E1.engine_ops(d); Gv = d['Gv']
    with trunc(n, xdeg=1): T = Gv.torsion(d['om'], e)
    tf = all(not p for x in T for p in x.values())
    with trunc(n, xdeg=0): R = Gv.curvature(d['om'])
    Rs = E1.scalar_R(E1.curv_frame(Gv, R, d['E0'], n), n)
    return ops['D2'], ops['Lap'], E1.mv_scale(ops['psi0'], Rs), Rs, tf, d
def part_L():
    head('(L) Lichnerowicz at the origin on strong draws (frame dx + 1-jet + 2-jet, spinor 2-jet, integers -50..50), torsion-free A3 connection')
    coef = F(-1, 2) if FAULT == 'C' else F(-1, 4)
    for n in (3, 4):
        sq = LORENTZ(n); rng = random.Random(8400 + n); ok = True; tfree = True; nzR = True
        for k in range(3):
            e = jets_frame(rng, n); psi = jets_spinor(rng, n)
            D2, Lap, Rpsi, Rs, tf, _ = lich_terms(n, sq, e, psi)
            ok &= E1.mv_add(D2, Lap, -1) == E1.mv_scale(Rpsi, coef); tfree &= tf; nzR &= Rs != 0 and not mvz(D2)
        chk('bit', ok and tfree and nzR, 'n=%d: Dslash^2 psi - nabla^a nabla_a psi = -(R/4) psi exactly at the origin on three strong draws (omega torsion-free as a 1-jet; R != 0, Dslash^2 psi != 0)' % n)
        # the degree along a random line b + t a in the space of sampled coefficients
        eb = jets_frame(rng, n); ea = jets_frame(rng, n, ident=False); pb = jets_spinor(rng, n); pa = jets_spinor(rng, n)
        vals = []
        for t in range(5):
            et = [{m: padd(eb[a_].get(m, {}), ea[a_].get(m, {}), t) for m in set(eb[a_]) | set(ea[a_])} for a_ in range(n)]
            pt = {S: padd(pb.get(S, {}), pa.get(S, {}), t) for S in set(pb) | set(pa)}
            D2, Lap, Rpsi, Rs, tf, _ = lich_terms(n, sq, et, pt); vals.append((D2, Lap, Rpsi))
        def diff(order, i):
            out = {}
            for t in range(order + 1):
                out = E1.mv_add(out, vals[t][i], (-1) ** (order - t) * comb(order, t))
            return out
        deg_ok = all(mvz(diff(4, i)) for i in range(3)) and any(not mvz(diff(3, i)) for i in range(3))
        chk('bit', deg_ok, 'n=%d: along a random line in the sampled coefficients the three terms (Dslash^2 psi, nabla^a nabla_a psi, R psi) have degree <= 3 (fourth finite difference zero) and degree 3 is reached: a false identity of this form passes three draws with probability <= (3/101)^3 = 2.6e-5' % n)
        chk('ctl', not (E1.mv_add(vals[0][0], vals[0][1], -1) == E1.mv_scale(vals[0][2], F(-1, 2))), 'n=%d: the coefficient -1/2 in place of -1/4 fails' % n)
        # [std] on a draw with small coefficients
        rs = random.Random(8500 + n); e = jets_frame(rs, n, -3, 3); psi = jets_spinor(rs, n, -3, 3)
        D2, Lap, Rpsi, Rs, tf, d = lich_terms(n, sq, e, psi); G = E1.gammas(sq); BL = E1.blades(G)
        sd = E1.StdSpin(e, psi, n, sq, G).at_origin()
        r1 = E1.relerr(E1.to_mat(BL, D2), sd['D2']); r2 = E1.relerr(E1.to_mat(BL, Lap), sd['Lap']); r3 = E1.relerr(sd['D2'] - sd['Lap'], -0.25 * float(Rs) * sd['Psi0'])
        chk('bit==std', max(r1, r2, r3) < 1e-6, 'n=%d: [std] Dirac matrices and Christoffel symbols (five-point differences) on a draw with coefficients -3..3: Dslash^2 psi (rel %.1e), nabla^a nabla_a psi (rel %.1e) equal the engine\'s, and the numpy residual of Lichnerowicz is %.1e' % (n, r1, r2, r3))
        tick('L n=%d' % n)

# ------------------------------------------------------------------------------------------------ (T) the one-third rule for totally skew torsion
def skew_A(rng, n):
    A = {}
    for trip in itertools.combinations(range(n), 3):
        v = dict(gs.rpoly(rng, n, 1, .8)); v[(0,) * n] = F(rng.choice([-3, -2, -1, 1, 2, 3]))          # A(0) != 0: the torsion is present at the point
        v = E1.nz_poly(v)
        for perm in itertools.permutations(range(3)):
            A[tuple(trip[i] for i in perm)] = scale(v, E1.perm_sign(list(perm)))
    return A
def K_from_A(Gv, e, A, sq):
    n = Gv.n; Fm = Gv.Fm; K = [{} for _ in range(Gv.G)]
    for idx, (p, q) in enumerate(pairs_of(Gv.L)):
        f = {}
        for c in range(n):
            if (p, q, c) in A: f = Fm.add(f, Fm.wedge({0: A[(p, q, c)]}, e[c]), sq[p] * sq[q])
        K[idx] = f
    return K
def K_trace(Gv, e, rng, sq):
    n = Gv.n; Fm = Gv.Fm; v = [E1.nz_poly(gs.rpoly(rng, n, 1, .8)) or {(0,) * n: F(1)} for _ in range(n)]; K = [{} for _ in range(Gv.G)]
    for idx, (p, q) in enumerate(pairs_of(Gv.L)):
        K[idx] = Fm.add(Fm.wedge({0: v[q]}, e[p]), Fm.wedge({0: v[p]}, e[q]), -1)
    return K
def om_plus(Gv, om, K, t): return [Gv.Fm.add(om[A], K[A], t) for A in range(Gv.G)]
def part_T():
    head('(T) the one-third rule: D_t = Dirac operator of omega + t K, K the contorsion of a totally skew torsion; nabla\' = omega + K')
    for n in (3, 4, 5):
        sq = LORENTZ(n); allok = True; tor_ok = True; zero_ok = True; ctl_half = True; ctl_tr = True; std_note = ''
        for k in range(2 if n < 5 else 1):
            d = E1.lc_setup(n, sq, 9100 + 10 * n + k, coef=2, density=.5 if n < 5 else .35)
            Gv, e, E0 = d['Gv'], d['e'], d['E0']; rng = random.Random(9200 + 10 * n + k)
            A = skew_A(rng, n); K = K_from_A(Gv, e, A, sq) if FAULT != 'TRACE' else K_trace(Gv, e, rng, sq)
            with trunc(n, xdeg=0): T = Gv.torsion(om_plus(Gv, d['om'], K, 1), e)
            if FAULT != 'TRACE':
                for c in range(n):
                    for a_ in range(n):
                        for b_ in range(n):
                            v = E1.form2_on(T[c], E0, n, a_, b_) * sq[c]; want = -2 * at0(A.get((c, a_, b_), {}), n)
                            tor_ok &= v == want
            psi = d['psi']; psi0 = {S: {k_: v for k_, v in p.items() if sum(k_) > 0} for S, p in psi.items()}; psi0 = {S: p for S, p in psi0.items() if p}
            psic = {S: {(0,) * n: p[(0,) * n]} for S, p in psi.items() if (0,) * n in p}
            ts = [F(0), F(1, 3), F(1, 2), F(1)]; r = {}
            ops1 = E1.engine_ops(dict(d, psi=psi0), om=om_plus(Gv, d['om'], K, 1)); Lap1 = ops1['Lap']
            for t in ts:
                D2 = ops1['D2'] if t == 1 else E1.engine_ops(dict(d, psi=psi0), om=om_plus(Gv, d['om'], K, t))['D2']
                r[t] = E1.mv_add(D2, Lap1, -1)
            claim_t = F(1, 2) if FAULT == 'HALF' else F(1, 3)
            allok &= mvz(r[claim_t]) and not mvz(r[F(0)]) and r[F(1, 2)] == E1.mv_scale(r[F(0)], F(-1, 2)) and r[F(1)] == E1.mv_scale(r[F(0)], F(-2))
            ctl_half &= not mvz(r[F(1, 2)]) and not mvz(r[F(1)])
            # order zero at t = 1/3: only psi(0) matters
            Kt = om_plus(Gv, d['om'], K, F(1, 3)); Lfull = E1.engine_ops(dict(d, psi=psi), om=om_plus(Gv, d['om'], K, 1)); Lc = E1.engine_ops(dict(d, psi=psic), om=om_plus(Gv, d['om'], K, 1))
            zf = E1.mv_add(E1.engine_ops(dict(d, psi=psi), om=Kt)['D2'], Lfull['Lap'], -1); zc = E1.mv_add(E1.engine_ops(dict(d, psi=psic), om=Kt)['D2'], Lc['Lap'], -1)
            zero_ok &= zf == zc and not mvz(zc)
            # control: a trace torsion; no t removes the first-order term (r_t is affine in t)
            Ktr = K_trace(Gv, e, random.Random(9300 + n + k), sq); o1 = E1.engine_ops(dict(d, psi=psi0), om=om_plus(Gv, d['om'], Ktr, 1))
            q0 = E1.mv_add(E1.engine_ops(dict(d, psi=psi0), om=d['om'])['D2'], o1['Lap'], -1); q1 = E1.mv_add(o1['D2'], o1['Lap'], -1)
            keys = sorted(set(q0) | set(q1)); slope = [q1.get(S, 0) - q0.get(S, 0) for S in keys]; base = [q0.get(S, 0) for S in keys]
            w, rk, cons = E1.fit([({S: -q0.get(S, 0) for S in keys}, [{S: q1.get(S, 0) - q0.get(S, 0) for S in keys}])], 1)
            ctl_tr &= not cons
            if n in (3, 4) and k == 0:
                G = E1.gammas(sq); BL = E1.blades(G); Kp = {pq: K[i] for i, pq in enumerate(pairs_of(Gv.L))}
                sc = lambda t: {pq: Gv.Fm.scale(f, t) for pq, f in Kp.items()}
                s1 = E1.StdSpin(e, psi0, n, sq, G, Kp=sc(1)).at_origin(); s0 = E1.StdSpin(e, psi0, n, sq, G, Kp=sc(0)).at_origin(); s3 = E1.StdSpin(e, psi0, n, sq, G, Kp=sc(F(1, 3))).at_origin()
                std0 = s0['D2'] - s1['Lap']; std3 = s3['D2'] - s1['Lap']
                e0r = E1.relerr(E1.to_mat(BL, r[F(0)]), std0); small = float(np.max(np.abs(std3)) / max(1e-300, np.max(np.abs(std0))))
                chk('bit==std', e0r < 1e-6 and small < 1e-6, 'n=%d: [std] numpy Dirac matrices with the contorsion: D_0^2 - nabla\'^2 on psi(0) = 0 equals the engine\'s (rel %.1e); at t = 1/3 the numpy difference is %.1e of it' % (n, e0r, small))
        chk('bit', tor_ok or FAULT == 'TRACE', 'n=%d: the engine\'s torsion of omega + K is T_cab = -2 A_cab at the origin, totally antisymmetric (%s)' % (n, 'two frames' if n < 5 else 'one frame'))
        chk('bit', allok, 'n=%d: on spinors vanishing at the origin D_t^2 - nabla\'^a nabla\'_a = (1 - 3t)(D_0^2 - nabla\'^a nabla\'_a) exactly for t = 0, 1/2, 1, and it is zero at t = %s (%s, totally skew torsion)' % (n, claim_t, 'two frames' if n < 5 else 'one frame'))
        chk('bit', zero_ok, 'n=%d: at t = 1/3 the difference applied to psi equals the one applied to the constant spinor psi(0), and is not zero: a term of order zero' % n)
        chk('ctl', ctl_half, 'n=%d: at t = 1/2 and t = 1 (the full torsion) a first-order term remains' % n)
        chk('ctl', ctl_tr, 'n=%d: a torsion with a trace part (K^{pq} = v^q e^p - v^p e^q): no t makes the first-order term vanish' % n)
        tick('T n=%d' % n)

# ------------------------------------------------------------------------------------------------ (H) d + delta in a flat chart
def sym(X, sq):
    out = {}
    for m, p in X.items():
        s = 1
        for i in bitsof(m): s *= sq[i]
        out[m] = scale(p, s)
    return out
def nabla_flat(A, sq, n):
    out = {}
    for S, p in A.items():
        for mu in range(n):
            dp = pder(p, mu)
            if not dp: continue
            m, s = bmul(1 << mu, S, sq); out[m] = padd(out.get(m, {}), dp, s * sq[mu])
    return {m: p for m, p in out.items() if p}
def grade_part(A, k): return {m: p for m, p in A.items() if popc(m) == k and p}
def star_flat(X, sq, route):
    st = GH.star_bit if route == 'bit' else GH.star_std; out = {}
    for m, p in X.items():
        J, s = st(m, sq); out[J] = padd(out.get(J, {}), p, s)
    return {m: p for m, p in out.items() if p}
def codiff_std(X, sq, n):
    """[std] (C alpha)_{I'} = sum_mu eta^mumu sgn(mu, I') d_mu alpha_{mu I'}  (the contraction sum_mu eta^mumu i_mu d_mu alpha)"""
    out = {}
    for m, p in X.items():
        for mu in bitsof(m):
            rest = m ^ (1 << mu); pos = sum(1 for i in bitsof(rest) if i < mu); s = (-1) ** pos * sq[mu]
            dp = pder(p, mu)
            if dp: out[rest] = padd(out.get(rest, {}), dp, s)
    return {m: p for m, p in out.items() if p}
def eqd(X, Y): return all(X.get(k, {}) == Y.get(k, {}) for k in set(X) | set(Y))
def part_H():
    head('(H) d + delta in a flat chart: symbol map dx^I -> gamma^I, every grade, random polynomial forms (coefficients -50..50, degree 2)')
    for n in (3, 4):
        for sq, sname in ((LORENTZ(n), 'Lorentz'), ([1] * n, 'Euclidean')):
            s_neg = sum(1 for x in sq if x < 0); Fm = Forms(n); rng = random.Random(8600 + 10 * n + s_neg)
            ok_d = ok_del = ok_box = ok_sq = ok_std = ok_star = True; signs = []
            for p in range(n + 1):
                al = gs.sform(rng, n, p, 2); A = sym(al, sq); NA = nabla_flat(A, sq, n)
                ok_d &= eqd(grade_part(NA, p + 1), sym(Fm.d(al), sq))
                sig = (-1) ** (n * (p + 1) + s_neg) * (-1 if FAULT == 'SIGN' else 1); signs.append(sig)
                sds = star_flat(Fm.d(star_flat(al, sq, 'bit')), sq, 'bit')
                ok_del &= eqd(grade_part(NA, p - 1), sym({m: scale(q, sig) for m, q in sds.items()}, sq)) if p > 0 else not grade_part(NA, -1)
                ok_std &= eqd(codiff_std(al, sq, n), {m: scale(q, sig) for m, q in star_flat(Fm.d(star_flat(al, sq, 'std')), sq, 'std').items()}) and (p == 0 or eqd(sym(codiff_std(al, sq, n), sq), grade_part(NA, p - 1)))
                ok_star &= all(GH.star_bit(m, sq) == GH.star_std(m, sq) for m in range(1 << n))
                N2 = nabla_flat(NA, sq, n); box = {}
                for mu in range(n):
                    for m, q in A.items(): box[m] = padd(box.get(m, {}), pder(pder(q, mu), mu), sq[mu])
                ok_box &= eqd(N2, {m: q for m, q in box.items() if q})
                dd = Fm.d(Fm.d(al)); dl = star_flat(Fm.d(star_flat(sds, sq, 'bit')), sq, 'bit')
                ok_sq &= not any(dd.values()) and not any(dl.values())
            chk('bit', ok_d, 'n=%d %s: the grade p+1 part of nabla alpha is the symbol of d alpha (engine d) for p = 0..%d' % (n, sname, n))
            chk('bit', ok_del, 'n=%d %s: the grade p-1 part is delta alpha = (-1)^(n(p+1)+s) * d * alpha (s = %d), signs %s for p = 0..%d' % (n, sname, s_neg, signs, n))
            chk('bit==std', ok_std and ok_star, 'n=%d %s: [std] the textbook contraction sum_mu eta^mumu i_mu d_mu alpha equals (-1)^(n(p+1)+s) * d * alpha with the textbook star, and equals the grade p-1 part; the bit-rule star = the textbook star on all %d masks' % (n, sname, 1 << n))
            chk('bit', ok_box and ok_sq, 'n=%d %s: nabla^2 alpha = eta^{mu nu} d_mu d_nu alpha on every component and every grade (the %s operator); d d = 0 and delta delta = 0' % (n, sname, 'wave' if s_neg else 'Laplace'))
    tick('H')

# ------------------------------------------------------------------------------------------------ (W) Weitzenboeck on 1-forms in a curved frame
def Gam_series(g, n, nv):
    gi, g0, g0i = std_inverse_metric(g, n, nv, 1); Gam = {}
    for lam in range(n):
        for mu in range(n):
            for nu in range(mu, n):
                t = {}
                for s in range(n):
                    br = sp_add(sp_add(sp_der(g[(s, nu)], mu), sp_der(g[(s, mu)], nu)), sp_der(g[(mu, nu)], s), -1)
                    if br and gi[(lam, s)]: t = sp_add(t, sp_mul(gi[(lam, s)], br, 1, n), F(1, 2))
                Gam[(lam, mu, nu)] = t; Gam[(lam, nu, mu)] = t
    return Gam, gi, g0, g0i
def std_weitz(e, al, n, sq):
    """[std] at the origin: Delta_l = d_l(div alpha) + (div d alpha)_l, Box_l = g^{mn} (nabla_m nabla_n alpha)_l, (Ric alpha)_l = R_l^m alpha_m (coordinate components)"""
    g = std_metric(e, n, sq, n, 2); Gam, gi, g0, g0i = Gam_series(g, n, n); a = [al.get(1 << mu, {}) for mu in range(n)]
    Na = {(m, l): sp_add(sp_der(a[l], m), lin(*[(F(-1), sp_mul(Gam[(r, m, l)], a[r], 1, n)) for r in range(n)])) for m in range(n) for l in range(n)}
    G0 = {k: at0(v, n) for k, v in Gam.items()}
    div = lin(*[(F(1), sp_mul(gi[(m, l)], Na[(m, l)], 1, n)) for m in range(n) for l in range(n)])
    beta = {(m, l): sp_add(sp_der(a[l], m), sp_der(a[m], l), -1) for m in range(n) for l in range(n)}
    def nb0(m, nu, l): return at0(sp_der(beta[(nu, l)], m), n) - sum(G0[(r, m, nu)] * at0(beta[(r, l)], n) + G0[(r, m, l)] * at0(beta[(nu, r)], n) for r in range(n))
    Delta = [at0(sp_der(div, l), n) + sum(g0i[m][nu] * nb0(m, nu, l) for m in range(n) for nu in range(n)) for l in range(n)]
    def nna0(m, nu, l): return at0(sp_der(Na[(nu, l)], m), n) - sum(G0[(r, m, nu)] * at0(Na[(r, l)], n) + G0[(r, m, l)] * at0(Na[(nu, r)], n) for r in range(n))
    Box = [sum(g0i[m][nu] * nna0(m, nu, l) for m in range(n) for nu in range(n)) for l in range(n)]
    Rm, _, _ = std_riemann(g, n, n, 1); ric = [[sum(Rm[(r, s, r, v)] for r in range(n)) for v in range(n)] for s in range(n)]
    Ra = [sum(ric[l][s] * g0i[s][m] * at0(a[m], n) for s in range(n) for m in range(n)) for l in range(n)]
    return Delta, Box, Ra
def bit_weitz(n, sq, seed):
    d = E1.lc_setup(n, sq, seed, coef=2, density=.5); Gv, e, E0 = d['Gv'], d['e'], d['E0']; Fm = Gv.Fm
    rng = random.Random(seed + 77); al = {1 << mu: E1.nz_poly(gs.rpoly(rng, n, 2, .7)) or {(0,) * n: F(1)} for mu in range(n)}
    E2 = anholonomy(Gv, e, n, 2)[1]; s_neg = sum(1 for x in sq if x < 0)
    sg = lambda p: (-1) ** (n * (p + 1) + s_neg)
    with trunc(n, xdeg=2):
        star = lambda X: GH.hodge_form(X, e, E2, Fm, sq, n, 'bit')
        dal = Fm.d(al); delta_al = Fm.scale(star(Fm.d(star(al))), sg(1)); delta_dal = Fm.scale(star(Fm.d(star(dal))), sg(2))
        Lap = Fm.add(Fm.d(delta_al), delta_dal)
    Delta = [sum((at0(Lap.get(1 << mu, {}), n) * E0[mu][b] for mu in range(n)), F(0)) for b in range(n)]
    om = d['om']; E = d['E']
    with trunc(n, xdeg=2): afr = [lin(*[(F(1), pm(al.get(1 << mu, {}), E2[mu][a_])) for mu in range(n)]) for a_ in range(n)]
    with trunc(n, xdeg=1):
        Da = Gv.D_covector(om, [{0: p} if p else {} for p in afr])
        Y = [[lin(*[(F(1), pm(Da[a_].get(1 << mu, {}), E[mu][c])) for mu in range(n)]) for a_ in range(n)] for c in range(n)]
    N2 = {}
    with trunc(n, xdeg=0):
        for a_ in range(n):
            Zc = Gv.D_covector(om, [({0: Y[c][a_]} if Y[c][a_] else {}) for c in range(n)])
            for c in range(n):
                Za = Gv.D_covector(om, [({0: Y[c][b_]} if Y[c][b_] else {}) for b_ in range(n)])
                tot = Fm.add(Zc[c], Fm.add(Za[a_], Fm.d({0: Y[c][a_]} if Y[c][a_] else {}), -1))
                for dd in range(n): N2[(dd, c, a_)] = sum((at0(tot.get(1 << mu, {}), n) * E0[mu][dd] for mu in range(n)), F(0))
        R = Gv.curvature(om)
    Box = [sum(sq[c] * N2[(c, c, b)] for c in range(n)) for b in range(n)]
    ric = E1.ricci(E1.curv_frame(Gv, R, E0, n), n, sq); a0 = [at0(p, n) for p in afr]
    Ra = [sum(ric[(b, dd)] * sq[dd] * a0[dd] for dd in range(n)) for b in range(n)]
    return Delta, Box, Ra, e, al, d
def part_W():
    head('(W) Weitzenboeck on 1-forms at the origin of random frames: (d delta + delta d) alpha = a nabla^c nabla_c alpha + b Ric alpha')
    for n in (3, 4):
        sq = LORENTZ(n); rows, rhs = [], []; data = []
        for k in range(3):
            Delta, Box, Ra, e, al, d = bit_weitz(n, sq, 9500 + 10 * n + k); data.append((Delta, Box, Ra))
            if k < 2:
                for b in range(n): rows.append([Box[b]] if FAULT == 'NORIC' else [Box[b], Ra[b]]); rhs.append(Delta[b])
            if k == 0:
                SD, SB, SR = std_weitz(e, al, n, sq); e0 = d['e0']; E0 = d['E0']
                fr = lambda v: [sum(v[mu] * E0[mu][b] for mu in range(n)) for b in range(n)]
                chk('bit==std', fr(SD) == Delta and fr(SB) == Box and fr(SR) == Ra and any(x != 0 for x in Ra), 'n=%d: [std] Christoffel calculus (exact series): d(div alpha) + div(d alpha), the rough Laplacian and R_l^m alpha_m equal the engine\'s (frame components, Ric alpha != 0)' % n)
        w, rk, nv_, cons = solve_exact(rows, rhs)
        want = [F(1)] if FAULT == 'NORIC' else [F(1), F(-1)]
        Delta, Box, Ra = data[2]; ver = all(Delta[b] == (w[0] * Box[b] + (w[1] if len(w) > 1 else 0) * Ra[b]) for b in range(n)) if w else False
        chk('bit', cons and w == want and ver, 'n=%d: exact fit on two frames (%d equations): (a, b) = %s, predicted (1, -1); verified on a third frame: (d delta + delta d) alpha = nabla^c nabla_c alpha - Ric alpha' % (n, len(rows), [str(x) for x in w] if w else None))
        if FAULT != 'NORIC':
            w0, _, _, c0 = solve_exact([[Box[b]] for (Delta_, Box_, Ra_) in data[:2] for b in range(n) for Box in [Box_]], [Delta_[b] for (Delta_, Box_, Ra_) in data[:2] for b in range(n)])
            chk('ctl', not c0, 'n=%d: without the Ricci term no coefficient a fits (the curvature term is needed)' % n)
    tick('W')

def main():
    head('GSB-DIRACSQ: Lichnerowicz on jets, the one-third rule, d + delta' + (' [fault %s]' % FAULT if FAULT else ''))
    part_H(); part_L(); part_T(); part_W()
    finish('GSB-DIRACSQ')

if __name__ == '__main__': main()
