#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GM-CARTAN.  One Bianchi identity for every Lie table: F = dA + 1/2 [A, A] has D_A F = 0, from the Jacobi identity.   python3 gm_cartan_bianchi.py

 Derivation: for a g-valued 1-form A, d[A, A] = -2 [A, dA] and [A, [A, A]] = 0 is the Jacobi identity; so D_A F = dF + [A, F] = (1/2) d[A, A] + [A, dA] + (1/2)[A, [A, A]] = 0, for every
 Lie algebra and every number of coordinates. Gauge covariance, infinitesimal: D_A D_A lambda = [F, lambda].
 The engine: Grav(n, Lie(sq)), A = omega^A B_A, F^C = d omega^C + (1/4) f_AB^C omega^A ^ omega^B, (D Y)^C = d Y^C + (1/2) f_AB^C omega^A ^ Y^B (the f table from the bit rule).
 Tables: so(1,n-1) x R^n (Lorentz squares and one null generator: Poincare), so(1,n) (extra square -1), so(2,n-1) (extra square +1), n = 3, 4, 5; so(m) (all squares -1), m = 3, 4,
 with forms on 3, 4, 5 coordinates (Yang-Mills).
 [bit]  random polynomial connections (strong sampler of a2b_strong_sampling.py: every monomial of degree <= 1, integers -50..50, three fields): D_A F = 0 on every component;
        D_A D_A lambda = (1/2) f F lambda for a random g-valued 0-form; the Jacobi identity of the f table; for the extended tables b1lib.embed_k: the h-part of F is R + k kappa^2 e^e
        with k = -s (Poincare: k = 0) and the g/h-part is kappa T (the torsion).
 [std]  the same algebras as plain matrices, L_AB = E_ab eta_bb - E_ba eta_aa (a degenerate eta for the null generator); structure constants by least squares and the Jacobi identity in
        numpy; matrix-valued A_mu = omega^A_mu L_A, F_{mu nu} = d_mu A_nu - d_nu A_mu + [A_mu, A_nu] and the cyclic sum of D_l F_{mu nu} = d_l F_{mu nu} + [A_l, F_{mu nu}] at rational points
        (exact Fractions, own matrix code).
 [bit==std] the engine's f table = 2 x the matrix structure constants ([2L_A, 2L_B] = f 2L_C); the engine's F^C L_C = the matrix F at the points.
 Bound: D_A F is cubic in the sampled coefficients: a false identity passes three fields with probability at most (3/101)^3 = 2.6e-5.
 Controls: one structure constant with the wrong sign (Jacobi fails, D_A F != 0); the quadratic term (1/2) f in place of (1/4) f; the Poincare table with the one bracket [P_0, P_1] = M_01
 added (Jacobi fails, D_A F != 0); the consistent bracket [P_a, P_b] = s M_ab is so(1,n) or so(2,n-1) and passes (the tables above)."""
import os, sys, random, itertools, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from a2b_strong_sampling import s_form, s_poly
import numpy as np

R50 = 50; SEEDS = (27, 1027, 2027); KAPPA = F(1, 2)
def tables():
    out = []
    for n in (3, 4, 5):
        lor = [1] + [-1] * (n - 1)
        out += [('so(1,%d) x R^%d (Poincare)' % (n - 1, n), lor + [0], n, lor, 0), ('so(1,%d)' % n, lor + [-1], n, lor, -1), ('so(2,%d)' % (n - 1), lor + [1], n, lor, 1)]
    for m in (3, 4):
        for n in (3, 4, 5): out.append(('so(%d) on %d coordinates' % (m, n), [-1] * m, n, None, None))
    return out
def jacobi_ok(L):
    f = {}
    for (A, B), (C, c) in L.f.items(): f[(A, B, C)] = F(c)
    G = L.G
    for A, B, C in itertools.combinations(range(G), 3):
        for E in range(G):
            tot = F(0)
            for (X, Y, Z) in ((A, B, C), (B, C, A), (C, A, B)):
                for D in range(G): tot += f.get((X, Y, D), 0) * f.get((D, Z, E), 0)
            if tot != 0: return False
    return True
def zero_forms(X): return all(not p for x in X for p in x.values())
def curvature_coef(Gv, om, c):
    Fm = Gv.Fm; R = [Fm.d(om[C]) for C in range(Gv.G)]
    for (A, B), (C, f) in Gv.L.f.items(): R[C] = Fm.add(R[C], Fm.wedge(om[A], om[B]), F(f) * c)
    return R
# ------------------------------------------------------------------------------------------------ [std] matrices (no engine)
def so_mats(sq, gens):
    N = len(sq); out = []
    for g in gens:
        a, b = [i for i in range(N) if g >> i & 1]; M = [[F(0)] * N for _ in range(N)]; M[a][b] += F(sq[b]); M[b][a] -= F(sq[a]); out.append(M)
    return out
def mm(A, B): n = len(A); return [[sum(A[i][k] * B[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
def madd(A, B, c=1): return [[a + c * b for a, b in zip(r, s)] for r, s in zip(A, B)]
def mscale(A, c): return [[c * a for a in r] for r in A]
def mcomm(A, B): return madd(mm(A, B), mm(B, A), -1)
def mzero(A): return all(x == 0 for r in A for x in r)
def std_structure(mats):
    """c with [L_A, L_B] = sum_C c_ABC L_C (numpy least squares), and the Jacobi residual"""
    G = len(mats); N = len(mats[0]); basis = np.array([[float(x) for r in M for x in r] for M in mats]).T
    c = np.zeros((G, G, G))
    for A in range(G):
        for B in range(G):
            cm = mcomm(mats[A], mats[B]); v = np.array([float(x) for r in cm for x in r]); sol = np.linalg.lstsq(basis, v, rcond=None)[0]; c[A, B] = sol
    jac = np.einsum('abd,dce->abce', c, c) + np.einsum('bcd,dae->abce', c, c) + np.einsum('cad,dbe->abce', c, c)
    return c, float(np.abs(jac).max())
def poly_at(p, pt): return sum((v * np_prod(pt, ex) for ex, v in p.items()), F(0))
def np_prod(pt, ex):
    r = F(1)
    for x, k in zip(pt, ex): r *= x ** k
    return r
def std_bianchi(mats, om, nc, pt):
    """matrix route at the point pt: A_mu = omega^A_mu L_A (omega of degree 1: second derivatives vanish); returns (F_{mu nu} at pt, max cyclic residual is zero)"""
    G = len(mats); N = len(mats[0]); Z = [[F(0)] * N for _ in range(N)]
    def comp(A, mu): return om[A].get(1 << mu, {})
    Amu = [Z for _ in range(nc)]; dA = [[Z for _ in range(nc)] for _ in range(nc)]          # dA[l][mu] = d_l A_mu (constant)
    Amu = []
    for mu in range(nc):
        M = Z
        for A in range(G):
            v = poly_at(comp(A, mu), pt)
            if v: M = madd(M, mats[A], v)
        Amu.append(M)
    for l in range(nc):
        for mu in range(nc):
            M = Z
            for A in range(G):
                v = poly_at(sp_der(comp(A, mu), l), pt)
                if v: M = madd(M, mats[A], v)
            dA[l][mu] = M
    Fm_ = {(m, n): madd(madd(dA[m][n], dA[n][m], -1), mcomm(Amu[m], Amu[n])) for m in range(nc) for n in range(nc)}
    dF = {(l, m, n): madd(mcomm(dA[l][m], Amu[n]), mcomm(Amu[m], dA[l][n])) for l in range(nc) for m in range(nc) for n in range(nc)}
    ok = True
    for l, m, n in itertools.combinations(range(nc), 3):
        cyc = Z
        for (a, b, c) in ((l, m, n), (m, n, l), (n, l, m)): cyc = madd(cyc, madd(dF[(a, b, c)], mcomm(Amu[a], Fm_[(b, c)])))
        ok &= mzero(cyc)
    return Fm_, ok

def main():
    bound = F(3, 2 * R50 + 1) ** len(SEEDS)
    for name, sq, nc, base, s in tables():
        head('%s: squares %s, forms on %d coordinates' % (name, sq, nc))
        L = Lie(sq); Gv = Grav(nc, L); G = L.G; Fm = Gv.Fm
        mats = so_mats(sq, L.gens); c, jres = std_structure(mats)
        f_ok = all(abs(2 * c[A, B, C] - (L.f[(A, B)][1] if (A, B) in L.f and L.f[(A, B)][0] == C else 0)) < 1e-12 for A in range(G) for B in range(G) for C in range(G))
        chk('bit==std', jacobi_ok(L) and jres < 1e-12 and f_ok, '%s: the engine\'s f table (%d generators) satisfies the Jacobi identity exactly; the matrices L_AB satisfy it (numpy, residual %.0e); f = 2 x the matrix structure constants' % (name, G, jres))
        okD = True; okG = True; okS = True; okM = True
        for sd in SEEDS:
            rng = random.Random(sd + 100 * nc + len(sq)); om = [s_form(rng, nc, 1, 1, R50) for _ in range(G)]
            Fc = Gv.curvature(om); DF = Gv.D_bivector(om, Fc); okD &= zero_forms(DF) and not zero_forms(Fc)
            lam = [({0: s_poly(rng, nc, 1, R50)}) for _ in range(G)]
            DDl = Gv.D_bivector(om, Gv.D_bivector(om, lam)); br = [{} for _ in range(G)]
            for (A, B), (C, f) in L.f.items(): br[C] = Fm.add(br[C], Fm.wedge(Fc[A], lam[B]), F(f, 2))
            okG &= all(not any(Fm.add(DDl[C], br[C], -1).values()) for C in range(G))
            pt = [F(rng.randint(-5, 5), rng.randint(1, 4)) for _ in range(nc)]
            Fmat, cyc = std_bianchi(mats, om, nc, pt); okS &= cyc
            for m, n in itertools.combinations(range(nc), 2):
                M = [[F(0)] * len(mats[0]) for _ in mats[0]]
                for C in range(G):
                    v = poly_at(Fc[C].get((1 << m) | (1 << n), {}), pt)
                    if v: M = madd(M, mats[C], v)
                okM &= M == Fmat[(m, n)]
        chk('bit', okD, '%s: D_A F = dF + (1/2) f A ^ F = 0 on every component, three random connections (F != 0)' % name)
        chk('bit', okG, '%s: D_A D_A lambda = (1/2) f F lambda for a random g-valued 0-form (infinitesimal gauge covariance: delta F = [F, lambda] for delta A = D lambda)' % name)
        chk('std', okS, '%s: matrix route at a rational point per field: the cyclic sum of D_l F_{mu nu} vanishes (exact Fractions)' % name)
        chk('bit==std', okM, '%s: the engine\'s F^C L_C = the matrix F_{mu nu} = d_mu A_nu - d_nu A_mu + [A_mu, A_nu] at the points (dictionary A = omega^A L_A)' % name)
        if base is not None:
            try: k, mu = embed_k(base, s, KAPPA, 7 + nc)
            except AssertionError as ex: k, mu = 'not proportional (%s)' % ex, None
            chk('bit', k == -s and mu == KAPPA, '%s: the h-part of F is R + k kappa^2 e^e with k = %s = -s, the g/h-part is %s T = kappa T (b1lib.embed_k, kappa = %s)' % (name, k, mu, KAPPA))
    print('    failure bound per table for a false identity on the three fields: (3/101)^3 = %.1e' % float(bound))
    head('controls')
    for nc, n in ((4, 4),):
        lor = [1] + [-1] * (n - 1); sq = lor + [-1]; L2 = Lie(sq); keys = sorted(L2.f); A0, B0 = keys[0]; C0, c0 = L2.f[(A0, B0)]
        L2.f[(A0, B0)] = (C0, -c0); L2.f[(B0, A0)] = (C0, c0); Gb = Grav(nc, L2)
        rng = random.Random(5); om = [s_form(rng, nc, 1, 1, R50) for _ in range(L2.G)]
        chk('ctl', not jacobi_ok(L2) and not zero_forms(Gb.D_bivector(om, Gb.curvature(om))), 'so(1,4) with the sign of the one bracket [B_%d, B_%d] flipped: the Jacobi identity fails and D_A F != 0' % (A0, B0))
        L = Lie(sq); Gv = Grav(nc, L)
        chk('ctl', not zero_forms(Gv.D_bivector(om, curvature_coef(Gv, om, F(1, 2)))), 'so(1,4): the quadratic term (1/2) f omega^omega in place of (1/4) f (the double of the right one): D_A F != 0')
        sqp = lor + [0]; L3 = Lie(sqp); P0, P1, M01 = L3.idx[(1 << 0) | (1 << n)], L3.idx[(1 << 1) | (1 << n)], L3.idx[(1 << 0) | (1 << 1)]
        L3.f[(P0, P1)] = (M01, 2); L3.f[(P1, P0)] = (M01, -2); G3 = Grav(nc, L3); om3 = [s_form(rng, nc, 1, 1, R50) for _ in range(L3.G)]
        chk('ctl', not jacobi_ok(L3) and not zero_forms(G3.D_bivector(om3, G3.curvature(om3))), 'the Poincare table with the one bracket [P_0, P_1] = M_01 added: the Jacobi identity fails and D_A F != 0 (all [P_a, P_b] = s M_ab together give so(1,4) or so(2,3), which pass above)')
    print('\n  reading: one script, the Lie table as the parameter: D_A F = 0 is the Jacobi identity of the table; the gravity tables add R + c e^e and the torsion, so(m) is Yang-Mills.')

if __name__ == '__main__':
    main(); finish('GM-CARTAN')
