#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""AREA.  The constitutive tensor of general linear electrodynamics on the bit rule: the 36 under GL(4) and the Lorentz group, the three matter
 conditions of the closure paper (sect. II C) on the quartic principal polynomial P of an area metric, and the 17 configuration variables against the pieces.
      python3 area_metric.py                  all checks; exit code 1 on a failure
      python3 area_metric.py --fault NAME     one control's wrong version in place of the right one (exits 1)
 Objects.  chi^{abcd} (antisymmetric in ab and in cd) is a 6 x 6 matrix X^{AB} on the plane labels 01, 02, 03, 12, 13, 23 (the bivectors Lie(sq).gens of the
   engine); a frame change A of GL(4) acts by X -> L X L^T, L the action of A on bivectors.  An area metric is a pair-symmetric X.
 Part 1 (CAND-090).  [bit] From the engine: the eps pairing E (wedge of two bivectors: Forms, the bit rule with null generators), the bivector metric G
   (squares of the bivectors under the bit rule with eta = (+,-,-,-)), the duality J (pseudoscalar times a bivector, g2_weyl.duality_J), the Lorentz algebra
   (h table: (1/2)[B_A, gamma_b] = h gamma_c; f table on bivectors).  GL(4) projectors: principal = pair-symmetric part minus the axion, skewon =
   pair-antisymmetric part, axion = (tr(E X)/6) E.  Lorentz projectors: scalar = (tr(X G^-1)/6) G; trace-free Ricci type = the +1 part of X -> J X J^T on the
   pair-symmetric part; Weyl type = its -1 part minus scalar and axion; skewon 6 and 9 = the -1 and +1 parts of X -> J X J^T on the skewon.  Exact 36 x 36
   matrices: idempotent, orthogonal, summing to 1, ranks 20, 15, 1 and 1, 9, 10, 1, 6, 9.  Equivariance: 20 random rational GL(4) frames (L from the
   wedge of the transformed vectors) and 20 rational Lorentz transformations (Cayley transforms (1 - K)^-1 (1 + K) of random rational combinations K of
   the h generators): per frame L^T E L = det(A) E (Lorentz: also L G L^T = G, L J = J L, Lambda^T eta Lambda = eta) and Pi(L X L^T) = L Pi(X) L^T for
   2 random X (integer entries uniform in -50..50) and each projector; the whole basis at one GL(4) frame and at the boost of the rotor 2 + gamma_0 gamma_1
   (bit-rule sandwich); the six generators of the f table commute with every projector; the f table is the wedge lift of the h table; the h generators
   are the textbook (M_ab)^d_c = delta^d_a eta_bc - delta^d_b eta_ac.  The cell classes D, E, A (6 vertices, 12 edges, 3 antipodal pairs of LNS-013): in the
   coordinate frame every piece is a sum of class parts (counts printed); the boost moves each class.
   [std] numpy on 4-tensors: textbook Levi-Civita symbol, the Ricci decomposition by Kulkarni-Nomizu products (Weyl = rest), skewon 6 = (1/2) Q o eta with
   Q^{bd} = eta_ac K^{abcd}; random float frames (scipy expm of the textbook generators); [bit==std] the nine 36 x 36 projector matrices agree.
 Part 2 (LNS-045, LNS-028d).  [bit] The quartic (120) (h6_area_metric.P_quartic, exact) of the area metric g ^ g + eps of every cell (k,d,r) of n = 4 (g the
   engine's bivector squares, eps from the wedge) and of the one non-metric area metric of h6_area_metric (its control Gw: G^{01,01} = -2/3,
   G^{02,02} = -4/3), as exact coefficients on the 35 quartic monomials; own exact Sturm sequences with Yun's square-free decomposition on 40 rational lines
   q + lambda h per case; the three conditions as the closure paper defines them: (1) hyperbolicity; (2) the dual P# of (19)-(21) (repeated factors removed;
   minimal degree, vanishing on the gradients at the smooth null covectors) and its hyperbolicity; (3) energy distinction (26)-(29) on 20 observers of the
   cone of P# and 40 lines (no null covector on which two observers disagree in sign).  [std] numpy: the Fresnel polynomial from the adjugate of the wave
   operator M(k)^{ad} = chi^{abcd} k_b k_c (adj M = W k k^T), its 35 coefficients by least squares; numpy roots on the same lines; Hessians at h; the rank of
   quadrics, cubics and quartics on 80 Gauss images (numerical, tolerance printed).
 Part 3 (LNS-030, LNS-048, LNS-013g).  [bit] the 17 configuration variables at G0 = 2 eta eta + eps (h6_count: their tangent space and the images of the 17
   coordinate directions) against the Lorentz pieces of part 1; [std] h6_count's Kulkarni-Nomizu pieces (lowered cells); [bit==std] the counts.  The closure
   equations of the closure paper and their integration constants are not in the package: nothing here is a statement about them.
 Controls (each also a --fault NAME): delta_trace, non_lorentz, classes, wrong_J, no_multiplicity, elliptic, spacelike_observer, wrong_dual, random17.
 Engine faults: the script builds Lie (h, f) and uses bmul and Forms.wedge; it builds no curvature and no Einstein form and never calls d."""
import os, sys, random, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from fractions import Fraction as F
from b1lib import chk, head, finish, Lie, Forms, bmul
from g2_weyl import PAIRS4, SYM21, CLASS, duality_J, J_matrix, J21_matrix, wrong_J_levi
from h6_area_metric import G_from_cells, P_quartic
import h6_count as HC
import numpy as np
from scipy.linalg import expm

FAULTS = ('delta_trace', 'non_lorentz', 'classes', 'wrong_J', 'no_multiplicity', 'elliptic', 'spacelike_observer', 'wrong_dual', 'random17')
FAULT = None                                                                   # set from the command line only when run as a script
ETA = [1, -1, -1, -1]
Z = (0, 0, 0, 0)

# ------------------------------------------------------------------------------------------------ exact matrices
def zeros(n, m=None): return [[F(0)] * (n if m is None else m) for _ in range(n)]
def eye(n):
    M = zeros(n)
    for i in range(n): M[i][i] = F(1)
    return M
def diag(v):
    M = zeros(len(v))
    for i, x in enumerate(v): M[i][i] = F(x)
    return M
def mm(A, B):
    p = len(B[0]); out = [[F(0)] * p for _ in range(len(A))]
    for i, Ai in enumerate(A):
        Oi = out[i]
        for k, a in enumerate(Ai):
            if a:
                for j, b in enumerate(B[k]):
                    if b: Oi[j] += a * b
    return out
def tp(A): return [list(r) for r in zip(*A)]
def lin(*terms):
    n, m = len(terms[0][1]), len(terms[0][1][0]); out = [[F(0)] * m for _ in range(n)]
    for c, M in terms:
        if c:
            for i in range(n):
                for j in range(m):
                    if M[i][j]: out[i][j] += c * M[i][j]
    return out
def trace(A): return sum((A[i][i] for i in range(len(A))), F(0))
def inv(M):
    n = len(M); A = [[F(x) for x in r] + [F(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[p] = A[p], A[c]; iv = 1 / A[c][c]; A[c] = [x * iv for x in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return [r[n:] for r in A]
def det(M):
    A = [[F(x) for x in r] for r in M]; n = len(A); d = F(1)
    for c in range(n):
        p = next((i for i in range(c, n) if A[i][c] != 0), None)
        if p is None: return F(0)
        if p != c: A[c], A[p] = A[p], A[c]; d = -d
        d *= A[c][c]
        for i in range(c + 1, n):
            if A[i][c] != 0:
                f = A[i][c] / A[c][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return d
def vec(X): return [X[a][b] for a in range(6) for b in range(6)]
def unit(j): X = zeros(6); X[j // 6][j % 6] = F(1); return X
def rand_X(rng): return [[F(rng.randint(-50, 50)) for _ in range(6)] for _ in range(6)]
def same(X, Y): return all(X[i][j] == Y[i][j] for i in range(len(X)) for j in range(len(X[0])))
def iszero(X): return all(x == 0 for r in X for x in r)
def basis_of(vecs): return HC.rref([list(v) for v in vecs])[0] if vecs else []

# ------------------------------------------------------------------------------------------------ part 1: engine objects, projectors, frames
def engine_objects(sq, J_wrong=False):
    """the engine's bivectors, bivector metric G (minus the scalar of B_A B_B), eps pairing E (wedge with null generators), duality J"""
    Lx = Lie(sq); gens = Lx.gens
    assert [tuple(i for i in range(4) if g >> i & 1) for g in gens] == PAIRS4
    G = zeros(6); E = zeros(6); Fm = Forms(4)
    for A, g in enumerate(gens):
        for B, g2 in enumerate(gens):
            m, s = bmul(g, g2, sq)
            if m == 0: G[A][B] = F(-s)
            w = Fm.wedge({g: {Z: F(1)}}, {g2: {Z: F(1)}}); E[A][B] = F(w.get(15, {}).get(Z, 0))
    J = J_matrix(wrong_J_levi(sq) if J_wrong else duality_J(sq)[0])
    return Lx, G, E, J, Fm
def projectors(G, E, J, fault=None):
    Gi = inv(G); Jt = tp(J)
    T = lambda X: mm(mm(J, X), Jt)
    sym = lambda X: [[(X[i][j] + X[j][i]) / 2 for j in range(6)] for i in range(6)]
    ant = lambda X: [[(X[i][j] - X[j][i]) / 2 for j in range(6)] for i in range(6)]
    def ax(X): return lin((trace(X) / 6, eye(6))) if fault == 'delta_trace' else lin((trace(mm(E, X)) / 6, E))
    def scal(X): return lin((trace(mm(X, Gi)) / 6, G))
    def principal(X): return lin((1, sym(X)), (-1, ax(X)))
    def skewon(X): return ant(X)
    def ricci9(X): S = sym(X); return lin((F(1, 2), S), (F(1, 2), T(S)))
    def weyl10(X): S = sym(X); return lin((F(1, 2), S), (F(-1, 2), T(S)), (-1, scal(X)), (-1, ax(X)))
    def skew6(X): K = ant(X); return lin((F(1, 2), K), (F(-1, 2), T(K)))
    def skew9(X): K = ant(X); return lin((F(1, 2), K), (F(1, 2), T(K)))
    GL = [('principal', principal, 20), ('skewon', skewon, 15), ('axion', ax, 1)]
    LOR = [('scalar', scal, 1), ('ricci9', ricci9, 9), ('weyl10', weyl10, 10), ('axion', ax, 1), ('skew6', skew6, 6), ('skew9', skew9, 9)]
    return GL, LOR
def pmat(fn):
    cols = [vec(fn(unit(j))) for j in range(36)]; return [[cols[j][i] for j in range(36)] for i in range(36)]
def set_props(S):
    mats = [pmat(fn) for _, fn, _ in S]
    idem = all(same(mm(P, P), P) for P in mats)
    orth = all(iszero(mm(P, Q)) for i, P in enumerate(mats) for j, Q in enumerate(mats) if i != j)
    comp = same(lin(*[(1, P) for P in mats]), eye(36))
    ranks = [HC.rank([list(r) for r in P]) for P in mats]
    return mats, idem, orth, comp, ranks
def wedge_lift(A, Fm, gens):
    """L[C][(ab)] = coefficient of B_C in (A e_a) ^ (A e_b), by the engine's wedge"""
    cols = []
    for (a, b) in PAIRS4:
        va = {1 << i: {Z: F(A[i][a])} for i in range(4) if A[i][a] != 0}; vb = {1 << i: {Z: F(A[i][b])} for i in range(4) if A[i][b] != 0}
        w = Fm.wedge(va, vb); cols.append([F(w.get(g, {}).get(Z, 0)) for g in gens])
    return [[cols[j][i] for j in range(6)] for i in range(6)]
def wedge_derivation(K, Fm, gens):
    """D(e_a ^ e_b) = K e_a ^ e_b + e_a ^ K e_b (the action of a vector generator K on bivectors), by the engine's wedge"""
    cols = []
    for (a, b) in PAIRS4:
        ka = {1 << i: {Z: F(K[i][a])} for i in range(4) if K[i][a] != 0}; kb = {1 << i: {Z: F(K[i][b])} for i in range(4) if K[i][b] != 0}
        w = Fm.add(Fm.wedge(ka, {1 << b: {Z: F(1)}}), Fm.wedge({1 << a: {Z: F(1)}}, kb)); cols.append([F(w.get(g, {}).get(Z, 0)) for g in gens])
    return [[cols[j][i] for j in range(6)] for i in range(6)]
def act(L, X): return mm(mm(L, X), tp(L))
def equivariant(fn, L, Xs): return all(same(fn(act(L, X)), act(L, fn(X))) for X in Xs)
def h_generators(Lx):
    Ks = [zeros(4) for _ in range(Lx.G)]
    for (A, b), (c, v) in Lx.h.items(): Ks[A][c][b] += v
    return Ks
def f_generators(Lx):
    Ms = [zeros(6) for _ in range(Lx.G)]
    for (A, B), (C, f) in Lx.f.items(): Ms[A][C][B] += F(f, 2)
    return Ms
def rand_gl(rng):
    while True:
        A = [[F(rng.randint(-4, 4), rng.choice([1, 2, 3])) for _ in range(4)] for _ in range(4)]
        if det(A) != 0: return A
def rand_lorentz(rng, Ks):
    while True:
        th = [F(rng.randint(-3, 3), rng.choice([2, 3, 4, 5])) for _ in range(6)]
        K = lin(*[(t, Kx) for t, Kx in zip(th, Ks)]); Im = lin((1, eye(4)), (-1, K))
        if det(Im) != 0: return mm(inv(Im), lin((1, eye(4)), (1, K)))
def mv_mul(X, Y, sq):
    out = {}
    for a, x in X.items():
        for b, y in Y.items():
            m, s = bmul(a, b, sq)
            if s: out[m] = out.get(m, F(0)) + s * x * y
    return {m: v for m, v in out.items() if v != 0}
def rotor_frame(sq):
    """the vector action of the rotor R = 2 + gamma_0 gamma_1: v -> R v R~ / (R R~), bit rule"""
    R, Rr = {0: F(2), 3: F(1)}, {0: F(2), 3: F(-1)}; n2 = mv_mul(R, Rr, sq); assert set(n2) == {0}
    Lam = zeros(4)
    for b in range(4):
        for m, v in mv_mul(mv_mul(R, {1 << b: F(1)}, sq), Rr, sq).items():
            assert m in (1, 2, 4, 8); Lam[m.bit_length() - 1][b] = v / n2[0]
    return Lam
def cls_of(A, B): return CLASS[(min(A, B), max(A, B))]
def class_proj(c): return lambda X: [[X[i][j] if cls_of(i, j) == c else F(0) for j in range(6)] for i in range(6)]

# ------------------------------------------------------------------------------------------------ part 1 [std]: numpy on 4-tensors
def levi4():
    E = np.zeros((4,) * 4)
    for p in itertools.permutations(range(4)): E[p] = (-1) ** sum(1 for i in range(4) for j in range(i + 1, 4) if p[i] > p[j])
    return E
EPSN, ETAN = levi4(), np.diag([1., -1., -1., -1.])
def chi_of(X):
    c = np.zeros((4,) * 4)
    for I, (a, b) in enumerate(PAIRS4):
        for J_, (cc, d) in enumerate(PAIRS4):
            v = X[I][J_]; c[a, b, cc, d] = v; c[b, a, cc, d] = -v; c[a, b, d, cc] = -v; c[b, a, d, cc] = v
    return c
def X_of(c): return np.array([[c[a, b, cc, d] for (cc, d) in PAIRS4] for (a, b) in PAIRS4])
def kn(h, k): return np.einsum('ac,bd->abcd', h, k) + np.einsum('ac,bd->abcd', k, h) - np.einsum('ad,bc->abcd', h, k) - np.einsum('ad,bc->abcd', k, h)
def std_pieces(c):
    s = (c + np.einsum('abcd->cdab', c)) / 2; k = (c - np.einsum('abcd->cdab', c)) / 2
    ax = np.sum(EPSN * c) / 24 * EPSN; pr = s - ax
    ric = np.einsum('ac,abcd->bd', ETAN, pr); R = np.einsum('bd,bd->', ETAN, ric)
    scal = R / 24 * kn(ETAN, ETAN); r9 = kn(ric - R / 4 * ETAN, ETAN) / 2
    Q = np.einsum('ac,abcd->bd', ETAN, k); s6 = kn(Q, ETAN) / 2
    return dict(principal=pr, skewon=k, axion=ax, scalar=scal, ricci9=r9, weyl10=pr - scal - r9, skew6=s6, skew9=k - s6)
NAMES = ['principal', 'skewon', 'axion', 'scalar', 'ricci9', 'weyl10', 'skew6', 'skew9']
def std_mats():
    cols = {n: [] for n in NAMES}
    for j in range(36):
        U = np.zeros((6, 6)); U[j // 6, j % 6] = 1; p = std_pieces(chi_of(U))
        for n in NAMES: cols[n].append(X_of(p[n]).flatten())
    return {n: np.array(cols[n]).T for n in NAMES}
def ad_std(Lam):
    cols = []
    for j in range(36):
        U = np.zeros((6, 6)); U[j // 6, j % 6] = 1
        cols.append(X_of(np.einsum('ae,bf,cg,dh,efgh->abcd', Lam, Lam, Lam, Lam, chi_of(U))).flatten())
    return np.array(cols).T
def textbook_M(a, b, eta):
    return [[F((1 if d == a else 0) * eta[b][c] - (1 if d == b else 0) * eta[a][c]) for c in range(4)] for d in range(4)]

# ------------------------------------------------------------------------------------------------ part 2: polynomials
MON4 = [e for e in itertools.product(range(5), repeat=4) if sum(e) == 4]
MON3 = [e for e in itertools.product(range(4), repeat=4) if sum(e) == 3]
MON2 = [e for e in itertools.product(range(3), repeat=4) if sum(e) == 2]
def mono(e, k):
    r = 1
    for x, p in zip(k, e):
        if p: r = r * x ** p
    return r
_VINV = []
def coeffs(f):
    """exact coefficients of a homogeneous quartic on MON4 from its values at the 35 lattice points of the simplex sum = 4 (unisolvent)"""
    if not _VINV: _VINV.append(inv([[F(mono(e, p)) for e in MON4] for p in MON4]))
    vals = [f([F(x) for x in p]) for p in MON4]
    return {e: c for e, c in zip(MON4, [sum(_VINV[0][i][j] * vals[j] for j in range(35) if vals[j]) for i in range(35)]) if c != 0}
def peval(cd, k): return sum((c * mono(e, k) for e, c in cd.items()), F(0))
def grad(cd):
    out = [{} for _ in range(4)]
    for e, c in cd.items():
        for i in range(4):
            if e[i]:
                e2 = tuple(x - (j == i) for j, x in enumerate(e)); out[i][e2] = out[i].get(e2, F(0)) + c * e[i]
    return out
def utrim(p):
    p = list(p)
    while p and p[-1] == 0: p.pop()
    return p
def uadd(a, b): return utrim([(a[i] if i < len(a) else 0) + (b[i] if i < len(b) else 0) for i in range(max(len(a), len(b)))])
def usub(a, b): return uadd(a, [-x for x in b])
def umul(a, b):
    if not a or not b: return []
    out = [F(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                if y: out[i + j] += x * y
    return utrim(out)
def udivmod(a, b):
    a, b = utrim(a), utrim(b); q = [F(0)] * max(1, len(a) - len(b) + 1)
    while a and len(a) >= len(b):
        c = a[-1] / b[-1]; dd = len(a) - len(b); q[dd] = c
        a = utrim([a[i] - (c * b[i - dd] if 0 <= i - dd < len(b) else 0) for i in range(len(a))])
    return utrim(q), a
def uder(a): return utrim([i * a[i] for i in range(1, len(a))])
def ugcd(a, b):
    a, b = utrim(a), utrim(b)
    while b: a, b = b, udivmod(a, b)[1]
    return [x / a[-1] for x in a]
def uval(a, x):
    r = F(0)
    for c in reversed(a): r = r * x + c
    return r
def yun(a):
    """square-free decomposition a = c f1 f2^2 f3^3 ... over Q (characteristic 0)"""
    a = utrim(a); out = []
    if len(a) <= 1: return out
    b = ugcd(a, uder(a)); c = udivmod(a, b)[0]; d = usub(udivmod(uder(a), b)[0], uder(c)); i = 1
    while len(c) > 1:
        f = ugcd(c, d); out.append((f, i)); c = udivmod(c, f)[0]; d = usub(udivmod(d, f)[0], uder(c)); i += 1
    return out
def sqfree(a): return udivmod(a, ugcd(a, uder(a)))[0]
def sturm(a):
    s = [utrim(a), uder(a)]
    while len(s[-1]) > 1:
        r = udivmod(s[-2], s[-1])[1]
        if not r: break
        s.append([-x for x in r])
    return s
def _var(vals):
    sg = [v > 0 for v in vals if v != 0]; return sum(1 for i in range(1, len(sg)) if sg[i] != sg[i - 1])
def nroots(a, lo=None, hi=None):
    """distinct real roots of a in (lo, hi] (None: an infinite end), Sturm on the square-free part"""
    s = sturm(sqfree(a))
    vl = _var([p[-1] * (-1) ** (len(p) - 1) for p in s if p]) if lo is None else _var([uval(p, lo) for p in s])
    vh = _var([p[-1] for p in s if p]) if hi is None else _var([uval(p, hi) for p in s])
    return vl - vh
def nreal_mult(a): return sum(i * nroots(f) for f, i in yun(a) if len(f) > 1)
def compose(cd, polys):
    deg = max((sum(e) for e in cd), default=0); pw = []
    for p in polys:
        lst = [[F(1)]]
        for _ in range(deg): lst.append(umul(lst[-1], p))
        pw.append(lst)
    out = []
    for e, c in cd.items():
        t = [c]
        for i in range(4):
            if e[i]: t = umul(t, pw[i][e[i]])
        out = uadd(out, t)
    return out
def on_line(cd, q, h): return compose(cd, [utrim([F(q[i]), F(h[i])]) for i in range(4)])
def np_real_roots(p):
    r = np.roots([float(x) for x in reversed(p)]); return int(sum(1 for z in r if abs(z.imag) <= 1e-6 * max(1.0, abs(z))))
def adj4(M):
    A = np.zeros((4, 4))
    for i in range(4):
        for j in range(4): A[j, i] = (-1) ** (i + j) * np.linalg.det(np.delete(np.delete(M, i, 0), j, 1))
    return A
def std_quartic(X, seed):
    """[std] W(k) = adj(M(k))_00 / k_0^2 from the wave operator M^{ad} = chi^{abcd} k_b k_c (numpy); 35 coefficients by least squares"""
    chi = chi_of([[float(x) for x in r] for r in X]); g = np.random.default_rng(seed)
    K = g.normal(size=(120, 4)); K[:, 0] = np.sign(K[:, 0]) * (0.5 + np.abs(K[:, 0])); Ws = []; ok = True
    for k in K:
        A = adj4(np.einsum('abcd,b,c->ad', chi, k, k)); W = A[0, 0] / k[0] ** 2
        ok &= bool(np.allclose(A, W * np.outer(k, k), atol=1e-9 * max(1.0, np.abs(A).max()))); Ws.append(W)
    V = np.array([[np.prod(k ** np.array(e)) for e in MON4] for k in K]); c = np.linalg.lstsq(V, np.array(Ws), rcond=None)[0]
    return c, float(np.max(np.abs(V @ c - np.array(Ws)))), ok
def as_vec(cd): return np.array([float(cd.get(e, 0)) for e in MON4])
def prop(u, v):
    nu, nv = np.linalg.norm(u), np.linalg.norm(v)
    return nu > 0 and nv > 0 and abs(abs(u @ v) / (nu * nv) - 1) < 1e-10
def hess_sig(c, h):
    H = np.zeros((4, 4))
    for e, ci in zip(MON4, c):
        for i in range(4):
            for j in range(4):
                ee = list(e); f = ee[i]; ee[i] -= 1
                if f == 0 or ee[i] < 0: continue
                g_ = ee[j]; ee[j] -= 1
                if g_ == 0 or ee[j] < 0: continue
                H[i, j] += ci * f * g_ * np.prod(np.array(h, dtype=float) ** np.array(ee))
    w = np.linalg.eigvalsh(H); s = 1e-9 * max(1.0, np.abs(w).max()); return int(sum(w > s)), int(sum(w < -s))
def cell_area(sq):
    """the area metric g ^ g + eps of a cell: the engine's bivector squares and the wedge pairing"""
    _, G, E, _, _ = engine_objects(sq); return lin((1, G), (1, E))
def quartic(X): Gt = G_from_cells({(A, B): X[A][B] for (A, B) in SYM21}); return coeffs(lambda k: P_quartic(Gt, k))
def rand_lines(rng, n=40): return [[F(rng.randint(-9, 9), rng.choice([1, 2, 3])) for _ in range(4)] for _ in range(n)]
def energy(Pd, h, Dd, T, lines, obs):
    """(26)-(29) on samples: every U in obs must lie in C(Dd, T) and U(h) > 0; on each line q + lam h no root of P lies in [min lam*, max lam*],
       lam*(U) = -U(q)/U(h): then every sampled null covector has the same sign of U(k) for all sampled observers"""
    bad = 0
    for q in lines:
        lam = [-sum(U[i] * q[i] for i in range(4)) / sum(U[i] * h[i] for i in range(4)) for U in obs]; lo, hi = min(lam), max(lam)
        s = sqfree(on_line(Pd, q, h)); bad += (nroots(s, lo, hi) + (1 if uval(s, lo) == 0 else 0)) > 0
    return bad
def in_cone(Dd, T, U):
    p = on_line(Dd, U, T); return uval(p, F(0)) != 0 and nreal_mult(p) == len(p) - 1 and nroots(p, F(0), None) == 0
def observers(Dd, T, rng, n=20):
    out = []
    while len(out) < n:
        U = [T[i] + F(rng.randint(-3, 3), 10) for i in range(4)]
        if in_cone(Dd, T, U): out.append(U)
    return out

# ------------------------------------------------------------------------------------------------ main
def main():
    t0 = time.time()
    head('Part 1a: the GL(4) split 36 = 20 + 15 + 1 [bit] (CAND-090)')
    Lx, G, E, J, Fm = engine_objects(ETA, J_wrong=(FAULT == 'wrong_J')); gens = Lx.gens
    chk('bit', all(G[A][B] == (ETA[a] * ETA[b] if A == B else 0) for A, (a, b) in enumerate(PAIRS4) for B in range(6)) and same(mm(E, E), eye(6))
        and [E[A][5 - A] for A in range(6)] == [1, -1, 1, 1, -1, 1], 'engine objects: bivector metric G = diag(eta_aa eta_bb) = diag(-1,-1,-1,1,1,1) from the squares of the bivectors; eps pairing E from the wedge: complement pairs with signs (+,-,+), E^2 = 1')
    GLs, LORs = projectors(G, E, J, FAULT)
    mats_gl, idem, orth, comp, ranks = set_props(GLs)
    chk('bit', idem and orth and comp and ranks == [20, 15, 1], 'GL(4) projectors principal / skewon / axion on Q^36: idempotent %s, orthogonal %s, sum 1 %s, ranks %s (20, 15, 1); the 21 pair-symmetric = principal 20 + axion 1' % (idem, orth, comp, ranks))
    rngF, rngX = random.Random(15), random.Random(1515)
    gl_frames = [rand_gl(rngF) for _ in range(20)]
    ok_id = ok_eq = True
    for A in gl_frames:
        L = wedge_lift(A, Fm, gens); dA = det(A); ok_id &= same(mm(mm(tp(L), E), L), lin((dA, E)))
        Xs = [rand_X(rngX) for _ in range(2)]; ok_eq &= all(equivariant(fn, L, Xs) for _, fn, _ in GLs)
    chk('bit', ok_id, '20 random rational GL(4) frames A (entries p/q, |p| <= 4, q <= 3): the wedge lift L satisfies L^T E L = det(A) E exactly')
    chk('bit', ok_eq, 'the three GL(4) projectors commute with each of the 20 frames: Pi(L X L^T) = L Pi(X) L^T for 2 random X per frame (entries uniform in -50..50)')
    L0 = wedge_lift(gl_frames[0], Fm, gens)
    chk('bit', all(equivariant(fn, L0, [unit(j) for j in range(36)]) for _, fn, _ in GLs), 'at the first GL(4) frame the three projectors commute with the action on the whole 36-element basis')
    dproj = lambda X: lin((trace(X) / 6, eye(6)))
    chk('ctl', not equivariant(dproj, L0, [unit(j) for j in range(36)]), 'control (delta_trace): the trace taken with delta, (tr X / 6) 1, is a rank-1 projector but does not commute with the first GL(4) frame')
    print('  part 1a: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 1b: the Lorentz split 20 = 1 + 9 + 10, 15 = 6 + 9 [bit] (CAND-090)')
    mats_lor, idem, orth, comp, ranks = set_props(LORs)
    chk('bit', idem and orth and comp and ranks == [1, 9, 10, 1, 6, 9], 'Lorentz projectors scalar / trace-free Ricci type / Weyl type / axion / skewon 6 / skewon 9: idempotent %s, orthogonal %s, sum 1 %s, ranks %s (1, 9, 10, 1, 6, 9)' % (idem, orth, comp, ranks))
    pr_m, sk_m = mats_gl[0], mats_gl[1]
    chk('bit', same(lin((1, mats_lor[0]), (1, mats_lor[1]), (1, mats_lor[2])), pr_m) and same(lin((1, mats_lor[4]), (1, mats_lor[5])), sk_m), 'the principal projector is scalar + Ricci type + Weyl type and the skewon projector is skewon 6 + skewon 9: the Lorentz pieces refine the GL(4) pieces')
    Ks = h_generators(Lx); Ms = f_generators(Lx)
    tb = [textbook_M(a, b, [[F(ETA[i]) if i == j else F(0) for j in range(4)] for i in range(4)]) for (a, b) in PAIRS4]
    chk('bit==std', all(same(Ks[A], tb[A]) for A in range(6)), 'the six h generators of the engine are the textbook (M_ab)^d_c = delta^d_a eta_bc - delta^d_b eta_ac')
    chk('bit', all(same(Ms[A], wedge_derivation(Ks[A], Fm, gens)) for A in range(6)), 'the f table on bivectors, (1/2)[B_A, B_B] = (f/2) B_C, is the wedge lift of the h action for all six generators')
    Xs = [rand_X(rngX) for _ in range(2)]
    inf_ok = all(same(fn(lin((1, mm(a, X)), (1, mm(X, tp(a))))), lin((1, mm(a, fn(X))), (1, mm(fn(X), tp(a))))) for a in Ms for X in Xs for _, fn, _ in LORs)
    chk('bit', inf_ok, 'the six generators of the f table commute with the six Lorentz projectors (X -> a X + X a^T, 2 random X)')
    lor_frames = [rand_lorentz(rngF, Ks) for _ in range(20)]
    if FAULT == 'non_lorentz': lor_frames[3] = mm(diag([2, 1, 1, 1]), lor_frames[3])
    etaM = diag(ETA); ok_id = ok_eq = True
    for Lam in lor_frames:
        L = wedge_lift(Lam, Fm, gens)
        ok_id &= same(mm(mm(tp(Lam), etaM), Lam), etaM) and same(act(L, G), G) and same(mm(L, J), mm(J, L)) and same(mm(mm(tp(L), E), L), E)
        Xs = [rand_X(rngX) for _ in range(2)]; ok_eq &= all(equivariant(fn, L, Xs) for _, fn, _ in LORs)
    chk('bit', ok_id, '20 rational Lorentz transformations (Cayley transforms of random rational combinations of the h generators): Lambda^T eta Lambda = eta, L G L^T = G, L J = J L, L^T E L = E')
    chk('bit', ok_eq, 'the six Lorentz projectors commute with each of the 20 Lorentz transformations (2 random X per frame)')
    Lam_b = rotor_frame(ETA); Lb = wedge_lift(Lam_b, Fm, gens)
    chk('bit', Lam_b[0][0] == F(5, 3) and abs(Lam_b[1][0]) == F(4, 3) and same(mm(mm(tp(Lam_b), etaM), Lam_b), etaM), 'the rotor R = 2 + gamma_0 gamma_1 (R R~ = 3) acts on vectors as the boost with cosh = %s, sinh = %s (bit-rule sandwich)' % (Lam_b[0][0], Lam_b[1][0]))
    test_b = [(nm, class_proj(nm[0])) for nm in ('D', 'E', 'A')] if FAULT == 'classes' else [(nm, fn) for nm, fn, _ in LORs]
    chk('bit', all(equivariant(fn, Lb, [unit(j) for j in range(36)]) for _, fn in test_b), 'at the boost of the rotor the %s commute with the action on the whole 36-element basis' % ('cell classes' if FAULT == 'classes' else 'six Lorentz projectors'))
    Lnl = wedge_lift(mm(diag([2, 1, 1, 1]), lor_frames[0]), Fm, gens)
    nl = [nm for nm, fn, _ in LORs if not equivariant(fn, Lnl, [unit(j) for j in range(36)])]
    chk('ctl', set(nl) >= {'scalar', 'ricci9', 'weyl10', 'skew6', 'skew9'}, 'control (non_lorentz): a non-Lorentz frame (one axis dilated by 2 after a Lorentz frame) breaks the scalar, Ricci type, Weyl type, skewon 6 and 9 projectors (not commuting: %s)' % ', '.join(nl))
    nlg = [nm for nm, fn, _ in LORs if not equivariant(fn, L0, [unit(j) for j in range(36)])]
    chk('ctl', set(nlg) >= {'scalar', 'ricci9', 'weyl10', 'skew6', 'skew9'}, 'control: the first random GL(4) frame breaks the same five Lorentz projectors (%s); only the axion is GL(4)-invariant among them' % ', '.join(nlg))
    _, Gw_, Ew_, Jw_, _ = engine_objects(ETA, J_wrong=True); Lw_ = projectors(Gw_, Ew_, Jw_)[1]; mw, iw, ow, cw, rw = set_props(Lw_)
    eqw = all(equivariant(fn, Lb, [unit(j) for j in range(36)]) for _, fn, _ in Lw_)
    chk('ctl', not (iw and ow and cw and rw == [1, 9, 10, 1, 6, 9] and eqw), 'control (wrong_J): with the complement map without the eta signs the six maps are not six Lorentz projectors of ranks 1, 9, 10, 1, 6, 9 (idempotent %s, orthogonal %s, sum 1 %s, ranks %s, boost-invariant %s)' % (iw, ow, cw, rw, eqw))
    print('  part 1b: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 1c: the cell classes 6 + 12 + 3 against the pieces [bit]')
    cl_m = {c: pmat(class_proj(c)) for c in 'DEA'}
    names_l = [nm for nm, _, _ in LORs]; allm = dict(zip(names_l, mats_lor))
    comm = all(same(mm(cl_m[c], P), mm(P, cl_m[c])) for c in 'DEA' for P in mats_lor)
    tab = {nm: tuple(HC.rank([list(r) for r in mm(allm[nm], cl_m[c])]) for c in 'DEA') for nm in names_l}
    print('  pieces by class (D vertices, E edges, A antipodal): ' + '; '.join('%s %s' % (nm, tab[nm]) for nm in names_l))
    chk('bit', comm and tab == {'scalar': (1, 0, 0), 'ricci9': (3, 6, 0), 'weyl10': (2, 6, 2), 'axion': (0, 0, 1), 'skew6': (0, 6, 0), 'skew9': (0, 6, 3)}, 'in the coordinate frame each piece is a sum of class parts: Weyl 10 = 2 + 6 + 2, Ricci type 9 = 3 + 6 + 0, scalar 1 + 0 + 0, axion 0 + 0 + 1 (the 21), skewon 6 = 0 + 6 + 0 and 9 = 0 + 6 + 3 (the 15) over vertices, edges, antipodal pairs')
    moved = [c for c in 'DEA' if not equivariant(class_proj(c), Lb, [unit(j) for j in range(36)])]
    chk('ctl', moved == ['D', 'E', 'A'], 'control (classes): the boost of the rotor 2 + gamma_0 gamma_1 moves each class (%s): the 6 + 12 + 3 is a split of one frame, not an invariant one' % ', '.join(moved))
    print('  part 1c: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 1d: the same projectors by the textbook route [std], and compared [bit==std]')
    S = std_mats()
    ok = all(np.allclose(S[n] @ S[n], S[n], atol=1e-12) for n in NAMES) and np.allclose(sum(S[n] for n in ('scalar', 'ricci9', 'weyl10', 'axion', 'skew6', 'skew9')), np.eye(36), atol=1e-12)
    rk = [int(np.linalg.matrix_rank(S[n], tol=1e-9)) for n in NAMES]
    chk('std', ok and rk == [20, 15, 1, 1, 9, 10, 6, 9], 'numpy projectors on 4-tensors (Levi-Civita symbol, Kulkarni-Nomizu Ricci decomposition, skewon 6 = (1/2) Q o eta): idempotent, the six Lorentz ones sum to 1, ranks %s' % rk)
    g = np.random.default_rng(16); Mt = [np.array([[float(x) for x in r] for r in tb[A]]) for A in range(6)]; ok_l = ok_g = ctl_g = True
    for _ in range(5):
        Lam = expm(sum(g.normal() * 0.6 * M for M in Mt)); Ad = ad_std(Lam); ok_l &= bool(np.allclose(Lam.T @ ETAN @ Lam, ETAN, atol=1e-10))
        ok_l &= all(np.allclose(S[n] @ Ad, Ad @ S[n], atol=1e-9 * np.abs(Ad).max()) for n in NAMES)
        Ag = g.normal(size=(4, 4)); Adg = ad_std(Ag)
        ok_g &= all(np.allclose(S[n] @ Adg, Adg @ S[n], atol=1e-9 * np.abs(Adg).max()) for n in ('principal', 'skewon', 'axion'))
        ctl_g &= not np.allclose(S['weyl10'] @ Adg, Adg @ S['weyl10'], atol=1e-6 * np.abs(Adg).max())
    chk('std', ok_l and ok_g, 'numpy: all eight commute with 5 random Lorentz transformations (scipy expm of the textbook generators); principal, skewon, axion commute with 5 random real GL(4) matrices')
    chk('ctl', ctl_g, 'control [std]: the Weyl-type projector does not commute with the random GL(4) matrices')
    bm = dict(zip(['principal', 'skewon', 'axion'], mats_gl)); bm.update(dict(zip(names_l, mats_lor)))
    dev = max(float(np.max(np.abs(np.array([[float(x) for x in r] for r in bm[n]]) - S[n]))) for n in NAMES)
    chk('bit==std', dev < 1e-12, 'the eight exact projector matrices of the bit rule equal the numpy ones (largest difference %.1e)' % dev)
    print('  part 1d: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 2a: the quartic P of the area metric g ^ g + eps on the 15 cells (k,d,r) of n = 4 [bit], against the adjugate route [std]')
    CELLS = [(k, d, 4 - k - d) for k in range(5) for d in range(5 - k)]
    cellP, ok_sq, ok_std, info = {}, True, True, []
    for (k, d, r) in CELLS:
        sq = [1] * k + [-1] * d + [0] * r; X = cell_area(sq); Pd = quartic(X); cellP[(k, d, r)] = Pd
        dg = 1
        for s in sq: dg *= s
        Qd = {tuple(2 * (j == i) for j in range(4)): F(s) for i, s in enumerate(sq) if s}
        target = coeffs(lambda kk: -dg * peval(Qd, kk) ** 2)
        ok_sq &= (Pd == target) and ((r == 0) == bool(Pd))
        c_std, res, ok_adj = std_quartic(X, 100 + 10 * k + d)
        ok_std &= ok_adj and res < 1e-8 and (prop(c_std, as_vec(Pd)) if r == 0 else float(np.max(np.abs(c_std))) < 1e-9)
    chk('bit', ok_sq, 'for every cell P = -det(g) (g^{ab} k_a k_b)^2 as an exact identity of the 35 coefficients: +Q^2 on (1,3,0) and (3,1,0), -Q^2 on (4,0,0), (2,2,0), (0,4,0); P = 0 identically on the ten cells with r >= 1 (det g = 0)')
    chk('bit==std', ok_std, 'numpy: adj M(k) = W(k) k k^T for the wave operator of each cell; W has 35 least-squares coefficients proportional to those of P on the five cells with r = 0 and is 0 on the ten with r >= 1')

    head('Part 2b: the first condition, hyperbolicity [bit] (Sturm with multiplicities, 40 rational lines per cell) and numpy roots [std]')
    def hdir(sq):
        pos = [i for i, s in enumerate(sq) if s > 0]; neg = [i for i, s in enumerate(sq) if s < 0]
        i = pos[0] if len(pos) == 1 else (neg[0] if len(neg) == 1 else 0); return [F(int(j == i)) for j in range(4)]
    hyp, quad, ok_np, rngL = {}, {}, True, random.Random(28)
    for (k, d, r) in CELLS:
        sq = [1] * k + [-1] * d + [0] * r; h = hdir(sq); Pd = cellP[(k, d, r)]
        if FAULT == 'elliptic' and (k, d, r) == (1, 3, 0): Pd = cellP[(4, 0, 0)]
        lines = rand_lines(rngL)
        if not Pd:
            hyp[(k, d, r)] = (False, 'P = 0')
        else:
            ps = [on_line(Pd, q, h) for q in lines]
            cnt = [nroots(p) if (FAULT == 'no_multiplicity') else nreal_mult(p) for p in ps]
            hyp[(k, d, r)] = (peval(Pd, h) != 0 and all(c == 4 for c in cnt), 'real roots on 40 lines: %s' % sorted(set(cnt)))
            ok_np &= all(np_real_roots(p) == nreal_mult(p) for p in ps)
        quad[(k, d, r)] = any(sq[i] != 0 and all(sq[i] * sq[j] <= 0 for j in range(4) if j != i) for i in range(4))
    for c in CELLS: print('  cell %s: quartic hyperbolic %s (%s); quadratic form has a hyperbolic basis direction %s' % (c, hyp[c][0], hyp[c][1], quad[c]))
    qh = {c for c in CELLS if hyp[c][0]}; qq = {c for c in CELLS if quad[c]}
    chk('bit', qh == {(1, 3, 0), (3, 1, 0)}, 'the quartic is hyperbolic (P(h) != 0, 4 real roots with multiplicity on all 40 lines; h the basis covector of the odd sign) on (1,3,0) and (3,1,0) only; on (2,2,0), (4,0,0), (0,4,0) some line has fewer real roots, on the r >= 1 cells P(h) = 0 for every h')
    chk('bit', qq == {(1, 3, 0), (3, 1, 0), (2, 1, 1), (1, 2, 1), (1, 1, 2), (1, 0, 3), (0, 1, 3)}, 'the quadratic form of the cell, from the labels (B(q,h)^2 - Q(h)Q(q) >= 0 for a basis covector h, exact): a hyperbolic direction exactly when k = 1 or d = 1 (seven cells, non-strict for r >= 1)')
    chk('bit', qq - qh == {(2, 1, 1), (1, 2, 1), (1, 1, 2), (1, 0, 3), (0, 1, 3)} and qh <= qq, 'the quartic map is the quadratic map on the five cells with r = 0 and differs on the five r >= 1 cells with k = 1 or d = 1, where the quadratic form is weakly hyperbolic and the quartic vanishes')
    chk('std', ok_np, 'numpy roots on the same lines give the same numbers of real roots (imaginary part below 1e-6) for every cell with P != 0')
    sig = {}
    for c in [(1, 3, 0), (3, 1, 0), (2, 2, 0), (4, 0, 0), (0, 4, 0)]:
        sq = [1] * c[0] + [-1] * c[1]; c_std = std_quartic(cell_area(sq), 7)[0]; sig[c] = hess_sig(c_std, [float(x) for x in hdir(sq)])
    chk('std', all((min(sig[c]) == 1 and sum(sig[c]) == 4) == (c in qh) for c in sig), 'numpy: the Hessian of the adjugate quartic at h has Lorentzian signature exactly on the hyperbolic cells (%s): the necessary condition of the derivative in a hyperbolic direction (recalled: Garding)' % ', '.join('%s %s' % (c, sig[c]) for c in sig))
    ell = [nreal_mult(on_line(cellP[(4, 0, 0)], q, [1, 0, 0, 0])) for q in rand_lines(random.Random(5))]
    chk('ctl', all(x == 0 for x in ell), 'control (elliptic): the definite quartic of (4,0,0), P = -(k.k)^2, has no real root on any of the 40 lines')
    dist = [nroots(on_line(cellP[(1, 3, 0)], q, [1, 0, 0, 0])) for q in rand_lines(random.Random(6))]
    chk('ctl', all(x == 2 for x in dist), 'control (no_multiplicity): counting distinct real roots only, the square P = Q^2 of (1,3,0) shows 2 roots on each of the 40 lines and would read as not hyperbolic')
    print('  part 2a-b: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 2c: the second condition, the dual P# of (19)-(21) [bit]')
    dual = {}
    for c in [(1, 3, 0), (3, 1, 0), (2, 2, 0)]:
        sq = [1] * c[0] + [-1] * c[1]; Pd = cellP[c]; gP = grad(Pd)
        nulls = [kk for kk in itertools.product(range(-4, 5), repeat=4) if any(kk) and sum(s * x * x for s, x in zip(sq, kk)) == 0]
        random.Random(7).shuffle(nulls); nulls = [[F(x) for x in kk] for kk in nulls[:16]]
        no_smooth = all(peval(gi, kk) == 0 for gi in gP for kk in nulls)
        xs = [[2 * sq[i] * kk[i] for i in range(4)] for kk in nulls]
        rows = [[F(mono(e, x)) for e in MON2] for x in xs]; ker = HC.nullspace(rows, 10)
        Qs = {e: F(sq[e.index(2)]) for e in MON2 if 2 in e}; ok_ker = len(ker) == 1 and HC.rank([ker[0], [Qs.get(e, F(0)) for e in MON2]]) == 1
        T = hdir(sq); hy = all(nreal_mult(on_line(Qs, q, T)) == 2 for q in rand_lines(random.Random(8)))
        ident = all(peval(Qs, [2 * sq[i] * kk[i] for i in range(4)]) == 4 * sum(sq[i] * kk[i] ** 2 for i in range(4)) for kk in rand_lines(random.Random(17), 20))
        dual[c] = (no_smooth, HC.rank(xs) == 4 and ident, ok_ker, hy, Qs, T)
        print('  cell %s: gradient of P = Q^2 zero at 16 null covectors %s; Gauss images of the reduced Q span %d dimensions; quadrics through them: %d (g_ab x^a x^b) %s; g_ab x^a x^b hyperbolic on 40 lines %s' % (c, no_smooth, HC.rank(xs), len(ker), ok_ker, hy))
    chk('bit', all(dual[c][0] for c in dual), 'for the square P = Q^2 the gradient vanishes at every sampled null covector (16 per cell): the set (20) of smooth null covectors is empty and (19)-(21) need the reduced polynomial Q, as the paper does (repeated factors removed)')
    chk('bit', all(dual[c][1] and dual[c][2] for c in dual), 'reduced Q: no linear form vanishes on the Gauss images dQ/dk at 16 null covectors (rank 4) and exactly one quadric does, g_ab x^a x^b; with Q#(dQ/dk) = 4 Q(k) identically, P# = g_ab x^a x^b (degree 2, the inverse quadratic, not its square) on (1,3,0), (3,1,0), (2,2,0)')
    chk('bit', dual[(1, 3, 0)][3] and dual[(3, 1, 0)][3] and not dual[(2, 2, 0)][3], 'P# is hyperbolic on (1,3,0) and (3,1,0) (2 real roots on 40 lines) and not on (2,2,0): the second condition holds exactly where the first does; on (4,0,0), (0,4,0) the set (20) has no real point and on the r >= 1 cells P = 0, so (19)-(21) define no dual there')
    print('  part 2c: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 2d: the third condition, energy distinction (26)-(29) on samples [bit]')
    en = {}
    for c in [(1, 3, 0), (3, 1, 0)]:
        sq = [1] * c[0] + [-1] * c[1]; Qd = {tuple(2 * (j == i) for j in range(4)): F(s) for i, s in enumerate(sq)}; Qs, T = dual[c][4], dual[c][5]
        obs = observers(Qs, T, random.Random(9)); lines = rand_lines(random.Random(10))
        sp = [i for i in range(4) if T[i] == 0][0]; Ubad = [T[i] + (2 if i == sp else 0) for i in range(4)]
        use = obs + [Ubad] if FAULT == 'spacelike_observer' else obs
        en[c] = (energy(Qd, T, Qs, T, lines, use), all(sum(U[i] * T[i] for i in range(4)) > 0 for U in obs), in_cone(Qs, T, Ubad), energy(Qd, T, Qs, T, lines, obs + [Ubad]))
    chk('bit', all(en[c][0] == 0 and en[c][1] for c in en), 'on (1,3,0) and (3,1,0): 20 observers U in the cone C(P#, T) (Sturm membership), T and h the basis vector and covector of the odd sign, U(h) > 0; on all 40 lines q + lam h the null covectors avoid [min lam*, max lam*]: every sampled massless momentum has the same energy sign for every sampled observer')
    chk('ctl', all(not en[c][2] and en[c][3] > 0 for c in en), 'control (spacelike_observer): adding U = T + 2 e (outside the cone) gives null covectors with both signs on %s of the 40 lines' % ', '.join(str(en[c][3]) for c in en))
    print('  part 2d: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 2e: the one non-metric area metric of h6_area_metric (Gw: G^{01,01} = -2/3, G^{02,02} = -4/3) [bit], [std]')
    X0 = cell_area(ETA); Xw = [list(r) for r in X0]; Xw[0][0] += F(1, 3); Xw[1][1] -= F(1, 3)
    Pw = quartic(Xw); Xwi = inv(Xw); Pwi = quartic(Xwi); h = [F(1), F(0), F(0), F(0)]; lines = rand_lines(random.Random(11))
    ps = [on_line(Pw, q, h) for q in lines]
    sqf = all(len(ugcd(p, uder(p))) == 1 for p in ps); cnt = [nreal_mult(p) for p in ps]
    chk('bit', sqf and peval(Pw, h) != 0 and all(c == 4 for c in cnt), 'Gw: P(h) = %s != 0 for h = (1,0,0,0), on each of 40 lines P(q + lam h) has 4 real roots and no repeated root (gcd with its derivative constant): hyperbolic on the samples, no repeated factor (not a square)' % peval(Pw, h))
    chk('std', all(np_real_roots(p) == 4 for p in ps), 'numpy roots: 4 real roots on each of the 40 lines')
    gw = grad(Pw); cand = Pw if FAULT == 'wrong_dual' else Pwi
    rem = [udivmod(compose(cand, [on_line(gi, q, h) for gi in gw]), p)[1] for q, p in zip(lines, ps)]
    chk('bit', all(not r_ for r_ in rem), 'the quartic of the inverse area metric G^-1 (6 x 6 inverse; eps.G^-1 = %s) vanishes on the Gauss image: P(q + lam h) divides P_{G^-1}(dP/dk(q + lam h)) in Q[lam] on all 40 lines (every null covector of each line, real or complex)' % (4 * trace(mm(cell_E(), Xwi))))
    r_ctl = udivmod(compose(Pw, [on_line(gi, lines[0], h) for gi in gw]), ps[0])[1]
    chk('ctl', bool(r_ctl), 'control (wrong_dual): P_G itself in place of P_{G^-1} leaves a non-zero remainder on the first line')
    Tv = [F(1), F(0), F(0), F(0)]; dh = all(nreal_mult(on_line(Pwi, q, Tv)) == 4 for q in rand_lines(random.Random(12)))
    chk('bit', peval(Pwi, Tv) != 0 and dh, 'P_{G^-1} is hyperbolic with respect to T = (1,0,0,0): 4 real roots on 40 rational lines')
    obs = observers(Pwi, Tv, random.Random(13)); use = obs + [[F(1), F(2), F(0), F(0)]] if FAULT == 'spacelike_observer' else obs
    eb = energy(Pw, h, Pwi, Tv, rand_lines(random.Random(14)), use)
    chk('bit', eb == 0 and all(U[0] > 0 for U in obs), 'energy distinction for Gw with O = C(P_{G^-1}, T): 20 observers, 40 lines, no null covector with two energy signs')
    # [std] the dual by numerical rank: the adjugate quartic, its real null covectors on 40 float lines, the Gauss images, quadrics / cubics / quartics through them
    cw_std = std_quartic(Xw, 21)[0]; gq = np.random.default_rng(22); xs = []
    def gradf(c, k): return np.array([sum(ci * e[i] * np.prod(np.array(k) ** (np.array(e) - np.eye(4, dtype=int)[i])) for ci, e in zip(c, MON4) if e[i]) for i in range(4)])
    while len(xs) < 80:
        q, hh = gq.normal(size=4), np.array([1., 0, 0, 0])
        pl = np.polynomial.polynomial.polyfit(np.linspace(-3, 3, 9), [sum(ci * np.prod((q + t * hh) ** np.array(e)) for ci, e in zip(cw_std, MON4)) for t in np.linspace(-3, 3, 9)], 4)
        for t in np.roots(pl[::-1]):
            if abs(t.imag) < 1e-9: x = gradf(cw_std, q + t.real * hh); xs.append(x / np.linalg.norm(x))
    sv = {}
    for nm, mons in (('quadrics', MON2), ('cubics', MON3), ('quartics', MON4)):
        Mx = np.array([[np.prod(x ** np.array(e)) for e in mons] for x in xs[:80]]); s = np.linalg.svd(Mx, compute_uv=False); sv[nm] = s / s[0]
    nullv = np.linalg.svd(np.array([[np.prod(x ** np.array(e)) for e in MON4] for x in xs[:80]]))[2][-1]
    chk('std', sv['quadrics'][-1] > 1e-6 and sv['cubics'][-1] > 1e-6 and sv['quartics'][-1] < 1e-9 and sv['quartics'][-2] > 1e-6, 'numerical (numpy): on 80 Gauss images of real null covectors of the adjugate quartic no quadric and no cubic vanishes (smallest relative singular values %.1e, %.1e) and exactly one quartic does (%.1e, next %.1e): the dual has degree 4' % (sv['quadrics'][-1], sv['cubics'][-1], sv['quartics'][-1], sv['quartics'][-2]))
    chk('bit==std', prop(nullv, as_vec(Pwi)), 'the numerical quartic through the Gauss images is proportional to the exact P_{G^-1} (cosine 1 within 1e-10): P# = P_{G^-1} for Gw')
    print('  part 2e: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('Part 3: the 17 configuration variables at G0 = 2 eta eta + eps against the pieces: [bit] engine projectors, [std] h6_count (LNS-030, LNS-048, LNS-013g)')
    u0 = HC.background(1)
    Jac = [[HC.eps_part(f) for f in HC.frame(*HC.at(u0, i)[0:3:2])] for i in range(21)]; Jac = [[Jac[i][k] for i in range(21)] for k in range(4)]
    Tup = HC.nullspace(Jac, 21)
    Jb = [[HC.eps_part(x) for x in HC.block_coords(*HC.at(u0, i)[0:3])] for i in range(21)]; Jb = [[Jb[i][k] for i in range(21)] for k in range(21)]
    d3 = [[[(a == 0) - (a == 1) if a == b else 0 for b in range(3)] for a in range(3)], [[(a == 1) - (a == 2) if a == b else 0 for b in range(3)] for a in range(3)]]
    dirs = {'g1': [], 'g2': [], 'g3': []}
    for kk in range(6): v = [F(0)] * 21; v[kk] = F(1); dirs['g1'].append(v)
    for kk in range(6): v = [F(0)] * 21; v[6 + kk] = F(1); dirs['g2'].append(v)
    for M in d3 + [[[1 if {x, y} == {a, b} else 0 for y in range(3)] for x in range(3)] for a, b in ((0, 1), (0, 2), (1, 2))]:
        dirs['g3'].append([F(0)] * 12 + [F(M[x][y]) for x in range(3) for y in range(3)])
    img = {kk: [HC.solve(Jb, v) for v in vs] for kk, vs in dirs.items()}
    if FAULT == 'random17':
        rr = random.Random(16); Tup = [[F(rr.randint(-9, 9)) for _ in range(21)] for _ in range(17)]
    def to_X(u):
        X = zeros(6)
        for i, (A, B) in enumerate(SYM21): X[A][B] = u[i]; X[B][A] = u[i]
        return X
    def to_u(X): return [X[A][B] for (A, B) in SYM21]
    pf = {'W': LORs[2][1], 'Ric': LORs[1][1], 'Scal': LORs[0][1], 'Eps': LORs[3][1]}
    unit21 = [[F(int(i == j)) for i in range(21)] for j in range(21)]
    Vb = {nm: basis_of([to_u(fn(to_X(e))) for e in unit21]) for nm, fn in pf.items()}
    def bit_counts(Tv):
        c = {nm: HC.inter(Tv, Vb[nm]) for nm in pf}; c['SE'] = HC.inter(Tv, Vb['Scal'] + Vb['Eps'])
        for nm, fn in pf.items(): c['p' + nm] = HC.rank([to_u(fn(to_X(t))) for t in Tv])
        return c
    cb = bit_counts(Tup)
    Jd, _, _, _ = duality_J(ETA); Ib = J21_matrix(Jd); H9, C12 = HC.eig(Ib, 1), HC.eig(Ib, -1); Ws, Ric, Scal, Eps = HC.pieces_std()
    cs = HC.counts([HC.low(v) for v in Tup], H9, C12, Ib, Ws, Ric, Scal, Eps)
    keys = ['W', 'Ric', 'Scal', 'Eps', 'SE', 'pW', 'pRic', 'pScal', 'pEps']
    print('  [bit] ' + ', '.join('%s %d' % (kk, cb[kk]) for kk in keys)); print('  [std] ' + ', '.join('%s %d' % (kk, cs[kk]) for kk in keys))
    chk('bit', (cb['W'], cb['Ric'], cb['SE'], cb['Scal'], cb['Eps'], cb['pRic']) == (10, 5, 1, 0, 0, 6), 'with the engine projectors (upper cells): the 17 contain all 10 Weyl-type directions, 5 of the 9 Ricci-type, one combination of scalar and axion (neither alone), and project onto 6 Ricci-type directions')
    chk('bit==std', all(cb[kk] == cs[kk] for kk in keys), 'the nine counts equal h6_count\'s Kulkarni-Nomizu counts on the lowered cells')
    rows_, okb = [], True
    for blk in ('g1', 'g2', 'g3'):
        cbb = bit_counts(img[blk]); csb = HC.counts([HC.low(v) for v in img[blk]], H9, C12, Ib, Ws, Ric, Scal, Eps); okb &= all(cbb[kk] == csb[kk] for kk in keys)
        for v, lab in zip(img[blk], range(len(img[blk]))):
            touch = [nm for nm, fn in pf.items() if not iszero(fn(to_X(v)))]; cl = ''.join(sorted(set(CLASS[SYM21[i]] for i in range(21) if v[i] != 0)))
            rows_.append('%s.%d: %s / cells %s' % (blk, lab, '+'.join(touch), cl))
    print('  the 17 coordinate directions (dg1: 11 12 13 22 23 33; dg2: same; dg3: diag(1,-1,0), diag(0,1,-1), sym 12, 13, 23) -> pieces / cell classes of the image:')
    for i in range(0, len(rows_), 3): print('    ' + ';  '.join(rows_[i:i + 3]))
    g3w = all(same(LORs[2][1](to_X(v)), to_X(v)) for v in img['g3'])
    chk('bit', g3w and okb, 'the 5 directions of dg3 (symmetric trace-free mixed block) lie in the Weyl type; the per-block counts of dg1, dg2, dg3 equal h6_count\'s')
    if FAULT != 'random17':
        rr = random.Random(16); R17 = [[F(rr.randint(-9, 9)) for _ in range(21)] for _ in range(17)]; cr = bit_counts(R17)
        chk('ctl', (cr['W'], cr['Ric'], cr['SE']) != (10, 5, 1), 'control (random17): a random 17-dimensional subspace meets the pieces as Weyl %d, Ricci type %d, scalar + axion %d' % (cr['W'], cr['Ric'], cr['SE']))
    print('  not in the package: the closure equations and their integration constants; the count above concerns the configuration variables only')
    print('  part 3: %.1f s' % (time.time() - t0))
    finish('AREA')

def cell_E(): return engine_objects(ETA)[2]

if __name__ == '__main__':
    if '--fault' in sys.argv[1:]:
        _i = sys.argv.index('--fault'); FAULT = sys.argv[_i + 1] if _i + 1 < len(sys.argv) else None
        if FAULT not in FAULTS: raise SystemExit('--fault takes one of: ' + ', '.join(FAULTS))
    main()
