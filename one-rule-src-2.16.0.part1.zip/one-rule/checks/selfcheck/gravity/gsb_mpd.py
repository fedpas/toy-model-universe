#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSB-MPD.  The Mathisson-Papapetrou-Dixon equations on the engine's Schwarzschild curvature: the conserved Killing quantities fix them.
   python3 gsb_mpd.py [--fault COEF|SIGN|NONKILLING]

Input (the pole-dipole equations as written): Dp^a/dtau = F^a = k_F R^a_bcd u^b S^cd,  DS^ab/dtau = k_S (p^a u^b - p^b u^a),  with the textbook
values k_F = -1/2, k_S = 1 (MTW sign of R, as the engine's: A4).  The Tulczyjew condition S^ab p_b = 0 is an input that fixes the centre; the
statement below needs none.
Statement checked.  For every Killing vector xi, Q = p_a xi^a + (1/2) S^ab nabla_a xi_b is constant along the equations: dQ/dtau = 0 at a point
for every u, p, S if and only if (k_F, k_S) = (-1/2, 1): an exact fit over random u, p, S and two Killing vectors (d_t and the rotation x d_y - y d_x)
at three rational points of Schwarzschild (Kerr-Schild chart, M = 1 and 2), verified on fresh draws.  F is orthogonal to u.  At one point the
quadrupole force -(1/6) J^bcde nabla^a R_bcde for a chosen J is computed by both routes.
[bit]  the frame e^a = dx^a - f l^a l_mu dx^mu, f = M/rho, l = (1, x/rho), as an exact 3-jet at the point (rho^-1 by g2_hodge.rho_pow_jet); A3's
       closed-form omega (1-jet; 2-jet for the quadrupole), the engine's curvature R^{ab}(E_c, E_d); nabla xi from D xi^a = d xi^a + h omega xi (the
       engine's D_vector), nabla nabla xi from D_vector and D_covector on the two indices; nabla R from D_covector on each index.
[std]  Christoffel calculus on g = e^T eta e (exact series): Riemann, nabla xi, nabla nabla xi, nabla R in coordinates; [bit==std] on the Riemann
       tensor, nabla xi and nabla nabla xi (every frame component, xi = d_t, three points) and on nabla R (five components, one point).
Scope: Schwarzschild only (Kerr not run); pole-dipole order; the quadrupole term at one point, no statement about its equations of motion.
The equations themselves are recalled: A. Papapetrou, Spinning test-particles in general relativity; W. G. Dixon, Dynamics of extended bodies in
general relativity.  Controls (--fault puts each into its main check, exit 1): COEF k_F = -1; SIGN k_S = -1; NONKILLING xi = d_x (not Killing)."""
import os, sys, time, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as GH

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'COEF', 'SIGN', 'NONKILLING'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N = 4; SQ = LORENTZ(4); I = range(4)

def ks_frame3(p, rho0, M, order=3):
    """Schwarzschild Kerr-Schild coframe as exact jets of x-degree <= order in delta = x - p (slots 0..3 = t, x, y, z)"""
    with trunc(N, xdeg=order):
        rinv = GH.rho_pow_jet(p, rho0, -1, order, N, (1, 2, 3))
        f = scale(rinv, M); X = [None] + [lin((F(1), const(N, p[i - 1])), (F(1), var(N, i))) for i in (1, 2, 3)]
        nh = [None] + [pm(X[i], rinv) for i in (1, 2, 3)]
        l_up = [const(N, 1)] + [scale(nh[i], -1) for i in (1, 2, 3)]; l_dn = [const(N, 1)] + [nh[i] for i in (1, 2, 3)]
        e = []
        for a in I:
            form = {}
            for mu in I:
                pol = lin((F(1 if a == mu else 0), const(N, 1)), (F(-1), pm(pm(f, l_up[a]), l_dn[mu])))
                if pol: form[1 << mu] = pol
            e.append(form)
    return e
def killing(kind, p):
    if kind == 't': return [const(N, 1), {}, {}, {}]
    if kind == 'rot': return [{}, lin((F(-1), const(N, p[1])), (F(-1), var(N, 2))), lin((F(1), const(N, p[0])), (F(1), var(N, 1))), {}]
    return [{}, const(N, 1), {}, {}]                                                            # d_x: not Killing
def setup(p, rho0, M, deg=1):
    Lie_ = Lie(SQ); Gv = Grav(N, Lie_); S = koszul_S(N, SQ, Lie_); e = ks_frame3(p, rho0, M, deg + 1)
    Dp = anholonomy(Gv, e, N, deg); om = omega_closed_form(Gv, e, S, N, deg, Dpre=Dp)[0]; E = Dp[1]
    e0, E0, det = E0_of(e, N, N)
    with trunc(N, xdeg=deg): T = Gv.torsion(om, e)
    with trunc(N, xdeg=0): R = Gv.curvature(om)
    Rf = {}
    for A, (c, d) in enumerate(pairs_of(Gv.L)):
        for a in I:
            for b in I:
                v = F(0)
                for mu in I:
                    for nu in range(mu + 1, N):
                        q = R[A].get((1 << mu) | (1 << nu))
                        if q: v += at0(q, N) * (E0[mu][a] * E0[nu][b] - E0[nu][a] * E0[mu][b])
                Rf[(c, d, a, b)] = v; Rf[(d, c, a, b)] = -v
    for c in I:
        for a in I:
            for b in I: Rf[(c, c, a, b)] = F(0)
    Rl = {k: SQ[k[0]] * SQ[k[1]] * v for k, v in Rf.items()}
    return dict(Gv=Gv, e=e, om=om, E=E, e0=e0, E0=E0, det=det, tfree=all(not q for x in T for q in x.values()), Rl=Rl)
def nabla_xi(d, xi):
    """[bit] X[(a, b)] = nabla_b xi^a at the origin, and Y[(c, a, b)] = nabla_c nabla_b xi^a at the origin"""
    Gv, e, om, E, E0 = d['Gv'], d['e'], d['om'], d['E'], d['E0']; Fm = Gv.Fm
    with trunc(N, xdeg=2): xa = [lin(*[(F(1), pm(e[a].get(1 << mu, {}), xi[mu])) for mu in I if xi[mu]]) for a in I]
    with trunc(N, xdeg=1):
        Dx = Gv.D_vector(om, [{0: q} if q else {} for q in xa])
        Xj = {(a, b): lin(*[(F(1), pm(Dx[a].get(1 << mu, {}), E[mu][b])) for mu in I]) for a in I for b in I}
    X0 = {k: at0(v, N) for k, v in Xj.items()}; Y = {}
    with trunc(N, xdeg=0):
        for b in I:
            Du = Gv.D_vector(om, [{0: Xj[(a, b)]} if Xj[(a, b)] else {} for a in I])                # upper index a, b fixed
            for a in I:
                Dl = Gv.D_covector(om, [{0: Xj[(a, bb)]} if Xj[(a, bb)] else {} for bb in I])      # lower index, a fixed
                tot = Fm.add(Du[a], Fm.add(Dl[b], Fm.d({0: Xj[(a, b)]} if Xj[(a, b)] else {}), -1))
                for c in I: Y[(c, a, b)] = sum((at0(tot.get(1 << mu, {}), N) * E0[mu][c] for mu in I), F(0))
    return X0, Y
def dQ(Rl, X0, Y, xi0, u, p, S, kF, kS):
    pl = [SQ[a] * p[a] for a in I]
    nxl = {(a, b): SQ[b] * X0[(b, a)] for a in I for b in I}                                      # nabla_a xi_b
    force = sum(Rl[(a, b, c, dd)] * xi0[a] * u[b] * S[(c, dd)] for a in I for b in I for c in I for dd in I)   # R_abcd xi^a u^b S^cd = F_a xi^a / k_F
    t1 = sum(pl[a] * u[c] * X0[(a, c)] for a in I for c in I)                                    # p_a u^c nabla_c xi^a
    torque = sum((p[a] * u[b] - p[b] * u[a]) * nxl[(a, b)] for a in I for b in I) / 2
    t2 = sum(S[(a, b)] * u[c] * SQ[b] * Y[(c, b, a)] for a in I for b in I for c in I) / 2           # (1/2) S^ab u^c nabla_c nabla_a xi_b
    return kF * force + t1 + kS * torque + t2, (force, torque, t1 + t2)
def rand_vecs(rng):
    u = [F(rng.randint(-9, 9), rng.randint(1, 5)) for _ in I]; p = [F(rng.randint(-9, 9), rng.randint(1, 5)) for _ in I]; S = {}
    for a in I:
        S[(a, a)] = F(0)
        for b in range(a + 1, N): v = F(rng.randint(-9, 9), rng.randint(1, 5)); S[(a, b)] = v; S[(b, a)] = -v
    return u, p, S

# ------------------------------------------------------------------------------------------------ [std] Christoffel calculus
def std_parts(e, xi, deg_g=3):
    g = std_metric(e, N, SQ, N, deg_g); gi, g0, g0i = std_inverse_metric(g, N, N, deg_g - 1); Gam = {}
    for l in I:
        for m in I:
            for v in range(m, N):
                t = {}
                for s in I:
                    br = sp_add(sp_add(sp_der(g[(s, v)], m), sp_der(g[(s, m)], v)), sp_der(g[(m, v)], s), -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, deg_g - 1, N), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    G0 = {k: at0(v, N) for k, v in Gam.items()}
    xl = [lin(*[(F(1), sp_mul(g[(mu, nu)], xi[nu], 2, N)) for nu in I if xi[nu]]) for mu in I]       # xi_mu to degree 2
    Nx = {(m, v): sp_add({k: c for k, c in sp_der(xl[v], m).items() if sum(k) <= 1}, lin(*[(F(-1), sp_mul(Gam[(r, m, v)], xl[r], 1, N)) for r in I])) for m in I for v in I}
    NNx = {(c, m, v): at0(sp_der(Nx[(m, v)], c), N) - sum(G0[(r, c, m)] * at0(Nx[(r, v)], N) + G0[(r, c, v)] * at0(Nx[(m, r)], N) for r in I) for c in I for m in I for v in I}
    Rm, _, _ = std_riemann(g, N, N, 1)
    Rlow = {(r, s, m, v): sum(g0[r][a] * Rm[(a, s, m, v)] for a in I) for (r, s, m, v) in itertools.product(I, repeat=4)}
    return dict(g0=g0, g0i=g0i, Nx0={k: at0(v, N) for k, v in Nx.items()}, NNx=NNx, Rlow=Rlow, xi0=[at0(q, N) for q in xi])

def std_geom1(e, K=1):
    """[std] Christoffel symbols (x-degree K + 1) and the lower Riemann tensor (x-degree K) of g = e^T eta e, exact series"""
    g = std_metric(e, N, SQ, N, K + 2); gi, g0, g0i = std_inverse_metric(g, N, N, K + 1); Gam = {}
    for l in I:
        for m in I:
            for v in range(m, N):
                t = {}
                for s in I:
                    br = sp_add(sp_add(sp_der(g[(s, v)], m), sp_der(g[(s, m)], v)), sp_der(g[(m, v)], s), -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, K + 1, N), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    Rup = {}
    for (r, s, m, v) in itertools.product(I, repeat=4):
        t = sp_add(sp_der(Gam[(r, v, s)], m), sp_der(Gam[(r, m, s)], v), -1)
        for l in I: t = sp_add(t, sp_mul(Gam[(r, m, l)], Gam[(l, v, s)], K, N)); t = sp_add(t, sp_mul(Gam[(r, v, l)], Gam[(l, m, s)], K, N), -1)
        Rup[(r, s, m, v)] = {k: c for k, c in t.items() if sum(k) <= K}
    Rl = {(r, s, m, v): lin(*[(F(1), sp_mul(g[(r, a)], Rup[(a, s, m, v)], K, N)) for a in I]) for (r, s, m, v) in itertools.product(I, repeat=4)}
    return Gam, Rl
def cov(T, rank, Gam, n, deg):
    """[std] (nabla T)_{c i1..ik} = d_c T - sum_j Gam^r_{c i_j} T_{..r..}, truncated at x-degree deg"""
    out = {}
    for c in range(n):
        for idx in itertools.product(range(n), repeat=rank):
            t = {k: v for k, v in sp_der(T[idx], c).items() if sum(k) <= deg}
            for j in range(rank):
                for r in range(n):
                    G_ = Gam[(r, c, idx[j])]
                    if not G_: continue
                    j2 = list(idx); j2[j] = r; q = T[tuple(j2)]
                    if q: t = sp_add(t, sp_mul(G_, q, deg, n), -1)
            out[(c,) + idx] = t
    return out

def main():
    head('GSB-MPD: pole-dipole equations and the Killing quantities on Schwarzschild (Kerr-Schild chart)' + (' [fault %s]' % FAULT if FAULT else ''))
    pts = [((F(1), F(2), F(2)), F(3), F(1)), ((F(2), F(3), F(6)), F(7), F(1)), ((F(2), F(6), F(9)), F(11), F(2))]
    kF = F(-1) if FAULT == 'COEF' else F(-1, 2); kS = F(-1) if FAULT == 'SIGN' else F(1)
    rows, rhs, ver = [], [], []; keep = None; rng = random.Random(1320); orth = True; std_ok = True; killing_ok = True; nonk = False
    for (p, rho0, M) in pts:
        d = setup(p, rho0, M); E0, e0 = d['E0'], d['e0']
        kinds = ['x'] if FAULT == 'NONKILLING' else ['t', 'rot']
        for kind in kinds + (['x'] if FAULT != 'NONKILLING' else []):
            xi = killing(kind, p); X0, Y = nabla_xi(d, xi)
            xi0 = [sum(e0[a][mu] * at0(xi[mu], N) for mu in I) for a in I]
            sym = all(SQ[b] * X0[(b, a)] + SQ[a] * X0[(a, b)] == 0 for a in I for b in I)
            if kind == 'x' and FAULT != 'NONKILLING':
                u, pp, S = rand_vecs(rng); val, _ = dQ(d['Rl'], X0, Y, xi0, u, pp, S, F(-1, 2), F(1)); nonk |= (val != 0) and not sym
                continue
            killing_ok &= sym or kind == 'x'
            if kind == 't' and keep is None: keep = (d, X0, Y, xi0)
            for k in range(6):
                u, pp, S = rand_vecs(rng); val, (fo, to, rest) = dQ(d['Rl'], X0, Y, xi0, u, pp, S, kF, kS)
                if k < 4: rows.append([fo, to]); rhs.append(-rest)
                else: ver.append(val)
                Fa = [kF * sum(SQ[a] * d['Rl'][(a, b, c, dd)] * u[b] * S[(c, dd)] for b in I for c in I for dd in I) for a in I]
                orth &= sum(SQ[a] * Fa[a] * u[a] for a in I) == 0
            if kind == 't':
                sd = std_parts(d['e'], xi)
                Rfr = lambda a, b, c, dd: sum(sd['Rlow'][(m, n_, r, s)] * E0[m][a] * E0[n_][b] * E0[r][c] * E0[s][dd] for m in I for n_ in I for r in I for s in I)
                std_ok &= all(Rfr(a, b, c, dd) == d['Rl'][(a, b, c, dd)] for (a, b, c, dd) in itertools.product(I, repeat=4))
                nfr = {(a, b): sum(sd['Nx0'][(m, n_)] * E0[m][a] * E0[n_][b] for m in I for n_ in I) for a in I for b in I}
                std_ok &= all(nfr[(a, b)] == SQ[b] * X0[(b, a)] for a in I for b in I)
                nnfr = lambda c, a, b: sum(sd['NNx'][(m, r, t_)] * E0[m][c] * E0[r][a] * E0[t_][b] for m in I for r in I for t_ in I)
                std_ok &= all(nnfr(c, a, b) == SQ[b] * Y[(c, b, a)] for c in I for a in I for b in I)
        chk('bit', d['tfree'], 'point %s (rho = %s, M = %s): the A3 connection of the Kerr-Schild jets is torsion-free to first order' % ([str(x) for x in p], rho0, M))
        tick('point rho=%s' % rho0)
    chk('bit', killing_ok, 'd_t and x d_y - y d_x: nabla_(a xi_b) = 0 at all three points (the engine\'s D_vector): Killing vectors of the chart')
    w, rank, nv_, cons = solve_exact(rows, rhs)
    want = [kF, kS]
    chk('bit', cons and rank == 2 and w == [F(-1, 2), F(1)] and w == want, 'exact fit over %d random (u, p, S) at three points and two Killing vectors: dQ/dtau = 0 forces (k_F, k_S) = (%s); the pole-dipole equations with (-1/2, 1) conserve Q' % (len(rows), ', '.join(str(x) for x in w) if w else '-'))
    chk('bit', all(v == 0 for v in ver), 'fresh draws (%d): dQ/dtau = 0 exactly with k_F = -1/2, k_S = 1' % len(ver))
    chk('bit', orth, 'F_a u^a = 0 on every draw (R_abcd u^a u^b = 0 by antisymmetry)')
    chk('bit==std', std_ok, '[std] Christoffel series at the three points (xi = d_t): the Riemann tensor, nabla_a xi_b and nabla_c nabla_a xi_b in frame components equal the engine\'s')
    if FAULT is None: chk('ctl', nonk, 'xi = d_x is not a Killing vector here (nabla_(a xi_b) != 0) and dQ/dtau != 0 for it')
    if FAULT is None:
        d0, X0_, Y_, x0_ = keep; u_, p_, S_ = rand_vecs(random.Random(7))
        chk('ctl', dQ(d0['Rl'], X0_, Y_, x0_, u_, p_, S_, F(-1), F(1))[0] != 0 and dQ(d0['Rl'], X0_, Y_, x0_, u_, p_, S_, F(-1, 2), F(-1))[0] != 0, 'xi = d_t: k_F = -1 (twice the force) and k_S = -1 (the torque reversed) each give dQ/dtau != 0')
    tick('pole-dipole')
    # quadrupole term at one point
    p, rho0, M = pts[0]; d2 = setup(p, rho0, M, deg=2); Gv = d2['Gv']; Fm = Gv.Fm; E, E0 = d2['E'], d2['E0']
    with trunc(N, xdeg=1):
        R = Gv.curvature(d2['om']); Rj = {}
        for A, (c, dd) in enumerate(pairs_of(Gv.L)):
            for a in I:
                for b in I:
                    t = {}
                    for mu in I:
                        for nu in range(mu + 1, N):
                            q = R[A].get((1 << mu) | (1 << nu), {})
                            if q: t = padd(t, pm(q, padd(pm(E[mu][a], E[nu][b]), pm(E[nu][a], E[mu][b]), -1)))
                    Rj[(c, dd, a, b)] = scale(t, SQ[c] * SQ[dd]); Rj[(dd, c, a, b)] = scale(t, -SQ[c] * SQ[dd])
        for c in I:
            for a in I:
                for b in I: Rj[(c, c, a, b)] = {}
    nR = {}
    with trunc(N, xdeg=0):
        dterm = {k: Fm.d({0: v}) if v else {} for k, v in Rj.items()}
        acc = {k: dict(dterm[k]) for k in Rj}
        for pos in range(4):
            for rest in itertools.product(I, repeat=3):
                lst = [{0: Rj[tuple(rest[:pos]) + (x,) + tuple(rest[pos:])]} if Rj[tuple(rest[:pos]) + (x,) + tuple(rest[pos:])] else {} for x in I]
                Dl = Gv.D_covector(d2['om'], lst)
                for x in I:
                    k = tuple(rest[:pos]) + (x,) + tuple(rest[pos:])
                    acc[k] = Fm.add(acc[k], Fm.add(Dl[x], Fm.d(lst[x]), -1))
        for k, f in acc.items():
            for c in I: nR[(c,) + k] = sum((at0(f.get(1 << mu, {}), N) * E0[mu][c] for mu in I), F(0))
    rngJ = random.Random(1321); v1 = [F(rngJ.randint(-3, 3)) for _ in I]; v2 = [F(rngJ.randint(-3, 3)) for _ in I]
    J = {}
    for (b, c, dd, ee) in itertools.product(I, repeat=4):
        J[(b, c, dd, ee)] = (v1[b] * v2[c] - v1[c] * v2[b]) * (v1[dd] * v2[ee] - v1[ee] * v2[dd])               # Riemann symmetries (a simple bivector squared)
    Fq = [-F(1, 6) * SQ[a] * sum(J[k] * nR[(a,) + k] for k in J) for a in I]
    Gam, Rl_s = std_geom1(d2['e'])
    NR = cov(Rl_s, 4, Gam, N, 0)
    nR_std = lambda c, a, b, cc, dd: sum(at0(NR[(m, r, s, t_, u_)], N) * E0[m][c] * E0[r][a] * E0[s][b] * E0[t_][cc] * E0[u_][dd] for m in I for r in I for s in I for t_ in I for u_ in I)
    keys = [(0, 0, 1, 0, 1), (1, 0, 2, 1, 3), (3, 1, 2, 1, 2), (2, 0, 3, 2, 3), (0, 1, 2, 3, 0)]
    okq = all(nR_std(*k) == nR[k] for k in keys) and any(x != 0 for x in Fq)
    chk('bit==std', okq, 'quadrupole order at rho = 3: nabla_e R_abcd from the engine (D_covector on each index, 2-jet connection) equals the Christoffel route on 5 sampled components; F^a = -(1/6) J^bcde nabla^a R_bcde = %s for J = (v1 ^ v2)(v1 ^ v2)' % [str(x) for x in Fq])
    tick('quadrupole')
    finish('GSB-MPD')

if __name__ == '__main__': main()
