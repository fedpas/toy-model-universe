#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSA-ORBITS.  The 1PN acceleration of a test body from the engine's geodesic on the isotropic Schwarzschild frame, and the Lambda term of the periastron
 advance in the form of a precession frequency.   python3 gsa_orbits.py [--fault coef3|gamma0|newton|half|sign_lambda]

 Part A (one-body 1PN).  Isotropic Schwarzschild coframe e^0 = N dt, e^i = Psi^2 dx^i, N = (1 - U/2)/(1 + U/2), Psi = 1 + U/2, U = M/r, and the PPN family
   e^0 = (1 - U + (beta - 1/2) U^2) dt, e^i = (1 + gamma U) dx^i, with M = lam^2 m and the coordinate velocity v = lam u: lam is a bookkeeping slot of b1lib.trunc
   kept to lam^4 (every kept coefficient exact).  Exact 2-jets in delta = x - p at rational points with rational |p|.
   [bit]  the coordinate acceleration of the geodesic (d5_perihelion's route): a^mu = E^mu_c du^c/dtau + (d_nu E^mu_c) u^nu u^c, du^c/dtau = -h_Ab^c omega^A(u) u^b,
          omega the A3 closed form, h the engine's table, E the inverse-frame jet; with u = (1, v) the quadratic form gives d^2 x^i/dt^2 = a^i - v^i a^0.
   [std]  the Christoffel symbols of g = e^T eta e at the point as series in lam (plain code), -Gamma u u; the recalled 1PN form (Will, Theory and Experiment in
          Gravitational Physics): a = -(m x/r^3)[1 - 2(beta + gamma) m/r + gamma v^2] + 2(1 + gamma)(m/r^3)(x.v) v, at beta = gamma = 1
          a = -M x/r^3 + (M/r^3)[(4M/r - v^2) x + 4 (x.v) v].
   [std]  floats: the 1PN equations of motion (scipy DOP853) for M = 1, e = 0.3, p = 200, 400, 800: periastron advance per orbit / (6 pi M/p) -> 1 (intercept of a
          linear fit in M/p); d5_perihelion has the same number from the full geodesic.  The N-body EIH equations are not computed (recalled).
 Part B (the Lambda term, an exact identity).  The precession frequency (1/2)(Lambda c^2/omega) sqrt(1 - e^2) (Kerr, Hauck and Mashhoon, as quoted; not in the
   package's second source) over one period 2 pi/omega, with omega^2 = G M/a^3, equals pi Lambda c^2 a^3 sqrt(1 - e^2)/(G M) and equals GRV-007's
   H^2 3 pi a^3 sqrt(1 - e^2)/M (geometric units, M -> G M/c^2) with Lambda = 3 H^2; and 3 pi p^3/(M (1 - e^2)^(5/2)) of d5_perihelion part 4 is the same with
   p = a (1 - e^2).  Fractions at rational (a, e, M, Lambda, c, G) with sqrt(1 - e^2) rational.
 Controls (each also a --fault NAME): coef3 (3 (x.v) v in place of 4 (x.v) v), gamma0 (the PPN frame with gamma = 0 against the gamma = 1 form), newton (the
   Newtonian term alone at lam^4), half (the frequency without its 1/2), sign_lambda (Lambda -> -Lambda in one form).
 Scope  test body in a static field: no back-reaction, no two-body 1PN, no N-body metric."""
import os, sys, time, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
from scipy.integrate import solve_ivp

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'coef3', 'gamma0', 'newton', 'half', 'sign_lambda'), 'unknown fault'
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N4 = 4; NV5 = 5; LAM = 4; SQ = LORENTZ(4)
def L(k, c=1): return {(0, 0, 0, 0, k): F(c)} if c != 0 else {}
def jm(a, b): return sp_mul(a, b, 2, 4)
def lser(p):
    """value at delta x = 0 as a series in lam {degree: coefficient}, degrees <= LAM"""
    out = {}
    for k, v in p.items():
        if sum(k[:4]) == 0 and k[4] <= LAM: out[k[4]] = out.get(k[4], 0) + v
    return {d: v for d, v in out.items() if v != 0}
def ls_mul(a, b):
    out = {}
    for i, x in a.items():
        for j, y in b.items():
            if i + j <= LAM: out[i + j] = out.get(i + j, 0) + x * y
    return {d: v for d, v in out.items() if v != 0}
def ls_add(a, b, c=1):
    out = dict(a)
    for d, v in b.items(): out[d] = out.get(d, 0) + c * v
    return {d: v for d, v in out.items() if v != 0}
def ls_inv(a):
    """1/a for a series with a[0] != 0"""
    a0 = a.get(0); assert a0; u = {d: v / a0 for d, v in a.items() if d}; out = {0: F(1)}; term = {0: F(1)}
    for _ in range(LAM):
        term = ls_mul(term, u); term = {d: -v for d, v in term.items()}; out = ls_add(out, term)
    return {d: v / a0 for d, v in out.items()}

# ------------------------------------------------------------------------------------------------ frames with the bookkeeping slot
def inv_r_jet(p, r0):
    X = [None] + [var(NV5, i) for i in (1, 2, 3)]
    d2 = lin(*[(F(1), jm(X[i], X[i])) for i in (1, 2, 3)])
    u = lin((F(2) / r0 ** 2, lin(*[(p[i - 1], X[i]) for i in (1, 2, 3)])), (F(1) / r0 ** 2, d2)); u2 = jm(u, u)
    return lin((1 / r0, const(NV5, 1)), (-1 / (2 * r0), u), (F(3, 8) / r0, u2))
def iso_frame(p, r0, m, kind='schw', beta=F(1), gamma=F(1)):
    U = jm(L(2, m), inv_r_jet(p, r0)); U2 = jm(U, U)
    if kind == 'schw':
        Nn = lin((F(1), const(NV5, 1)), (F(-1), U), (F(1, 2), U2)); Ps2 = lin((F(1), const(NV5, 1)), (F(1), U), (F(1, 4), U2))
    else:
        Nn = lin((F(1), const(NV5, 1)), (F(-1), U), (beta - F(1, 2), U2)); Ps2 = lin((F(1), const(NV5, 1)), (gamma, U))
    Nn = {k: v for k, v in Nn.items() if k[4] <= LAM}; Ps2 = {k: v for k, v in Ps2.items() if k[4] <= LAM}
    return [{1: Nn}] + [{1 << i: Ps2} for i in (1, 2, 3)]
def engine_accel(Gv, S, e, u):
    """[bit] d^2 x^i/dt^2 = a^i - v^i a^0 at the point as lam-series, a^mu the quadratic form of the engine's geodesic route at u = (1, lam u)"""
    with trunc(4, xdeg=None, lam=LAM):
        D_, E_, det = anholonomy(Gv, e, NV5, 1)
        om = omega_closed_form(Gv, e, S, NV5, 1, Dpre=(D_, E_, det))[0]
    ev = [[lser(e[c].get(1 << mu, {})) for mu in range(4)] for c in range(4)]
    uf = [{} for _ in range(4)]
    for c in range(4):
        for mu in range(4): uf[c] = ls_add(uf[c], ls_mul(ev[c][mu], u[mu]))
    omu = [{} for _ in range(Gv.G)]
    for A in range(Gv.G):
        for mu in range(4): omu[A] = ls_add(omu[A], ls_mul(lser(om[A].get(1 << mu, {})), u[mu]))
    du = [{} for _ in range(4)]
    for (A, b), (c, h) in Gv.L.h.items(): du[c] = ls_add(du[c], ls_mul(omu[A], uf[b]), -h)
    a = [{} for _ in range(4)]
    for mu in range(4):
        for c in range(4):
            a[mu] = ls_add(a[mu], ls_mul(lser(E_[mu][c]), du[c]))
            for nu in range(4): a[mu] = ls_add(a[mu], ls_mul(ls_mul(lser(sp_der(E_[mu][c], nu)), u[nu]), uf[c]))
    return [ls_add(a[i], ls_mul(u[i], a[0]), -1) for i in (1, 2, 3)]
def engine_E_lam(Gv, S, e):
    """[bit] the components of E_a(0) at the point as lam-series (curvature and Einstein form of the engine with the lam slot)"""
    with trunc(4, xdeg=None, lam=LAM):
        om = omega_closed_form(Gv, e, S, NV5, 1)[0]
        with trunc(4, xdeg=1): R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(0))
    return {(a, mu): lser(Ea[a].get(15 ^ (1 << mu), {})) for a in range(4) for mu in range(4)}
def std_accel(e, u):
    """[std] -Gamma^mu_nu rho u^nu u^rho of g = e^T eta e at the point as lam-series (diagonal metric at the point), then a^i - v^i a^0"""
    g = std_metric(e, 4, SQ, NV5, 2); g0 = {(m, n): lser(g[(m, n)]) for m in range(4) for n in range(4)}
    assert all(not g0[(m, n)] for m in range(4) for n in range(4) if m != n)
    gi = [ls_inv(g0[(m, m)]) for m in range(4)]; dg = lambda k, m, n: lser(sp_der(g[(m, n)], k))
    a = [{} for _ in range(4)]
    for mu in range(4):
        for nu in range(4):
            for rh in range(4):
                br = ls_add(ls_add(dg(nu, mu, rh), dg(rh, mu, nu)), dg(mu, nu, rh), -1)
                if br: a[mu] = ls_add(a[mu], ls_mul(ls_mul(ls_mul(gi[mu], br), u[nu]), u[rh]), F(-1, 2))
    return [ls_add(a[i], ls_mul(u[i], a[0]), -1) for i in (1, 2, 3)]
def pn_form(p, uu, m, beta=F(1), gamma=F(1), c4=None):
    """[std, recalled] the lam^2 and lam^4 coefficients of the 1PN acceleration (PPN form; beta = gamma = 1: Schwarzschild)"""
    r = K_r(p); xv = sum(a * b for a, b in zip(p, uu)); v2 = sum(b * b for b in uu); c4 = 2 * (1 + gamma) if c4 is None else c4
    return [(-m * p[i] / r ** 3, m * p[i] / r ** 3 * (2 * (beta + gamma) * m / r - gamma * v2) + c4 * m / r ** 3 * xv * uu[i]) for i in range(3)]
def K_r(p):
    s = sum(x * x for x in p); n, d = math.isqrt(s.numerator), math.isqrt(s.denominator); assert F(n, d) ** 2 == s; return F(n, d)

# ------------------------------------------------------------------------------------------------ Part A floats: the 1PN equations of motion
def pn_rhs(t, y, M=1.0):
    x, yy, vx, vy = y; r = math.hypot(x, yy); xv = x * vx + yy * vy; v2 = vx * vx + vy * vy; k = M / r ** 3
    ax = -k * x + k * ((4 * M / r - v2) * x + 4 * xv * vx); ay = -k * yy + k * ((4 * M / r - v2) * yy + 4 * xv * vy)
    return [vx, vy, ax, ay]
def advance_1pn(p, e, norb=6):
    rp = p / (1 + e); vp = math.sqrt((1 + e) / rp)                     # M = 1: Newtonian periastron speed, h = rp vp = sqrt(p)
    y0 = [rp, 0.0, 0.0, vp]; Tn = 2 * math.pi * (p / (1 - e * e)) ** 1.5
    ev = lambda t, y: y[0] * y[2] + y[1] * y[3]; ev.direction = 1
    sol = solve_ivp(pn_rhs, (0, (norb + 0.5) * Tn), y0, method='DOP853', rtol=1e-12, atol=1e-13, events=ev)
    ang = [math.atan2(s[1], s[0]) for s in sol.y_events[0]]
    ang = np.unwrap(np.array([0.0] + ang)); d = np.diff(ang)                  # successive periastra: the advance per orbit
    return float(np.mean(d[1:])) if len(d) > 2 else float('nan'), float(np.std(d[1:]))

def main():
    head('GSA-ORBITS: the 1PN test-body acceleration from the engine; the Lambda term of the periastron advance' + (' [fault %s]' % FAULT if FAULT else ''))
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
    from d_probe import d_sign_probe; d_sign_probe()
    # ================================================================================== A1 Schwarzschild, isotropic
    head('A1. isotropic Schwarzschild frame, M = lam^2 m, v = lam u: the lam^2 and lam^4 coefficients of d^2 x/dt^2, exact')
    PTS = [((F(3), F(4), F(12)), F(13)), ((F(2), F(3), F(6)), F(7)), ((F(-1), F(4), F(8)), F(9)), ((F(6), F(2), F(-9)), F(11)), ((F(12), F(-4), F(3)), F(13))]
    VEL = [(F(1, 3), F(-1, 2), F(1, 5)), (F(-2, 7), F(1, 4), F(3, 8))]
    ms = [F(1), F(2, 3), F(5, 2), F(1, 7), F(3)]
    ok_bs = ok_n = ok_1 = ok_c3 = ok_nw = True; ns = 0
    for (p, r0), m in zip(PTS, ms):
        e = iso_frame(p, r0, m)
        for uu in VEL:
            u = [{0: F(1)}] + [{1: c} for c in uu]
            ab = engine_accel(Gv, S, e, u); as_ = std_accel(e, u); pf = pn_form(p, uu, m, c4=(F(3) if FAULT == 'coef3' else None))
            ok_bs &= (ab == as_); ns += 1
            ok_n &= all(ab[i].get(2, 0) == pf[i][0] and ab[i].get(0, 0) == 0 and ab[i].get(1, 0) == 0 and ab[i].get(3, 0) == 0 for i in range(3))
            ok_1 &= all(ab[i].get(4, 0) == (pf[i][0] * 0 if FAULT == 'newton' else pf[i][1]) for i in range(3))
            p3 = pn_form(p, uu, m, c4=F(3)); ok_c3 &= any(ab[i].get(4, 0) != p3[i][1] for i in range(3)); ok_nw &= any(ab[i].get(4, 0) != 0 for i in range(3))
    chk('bit==std', ok_bs, 'engine (A3 omega, h table, inverse-frame jet; d5_perihelion\'s route with the lam slot) = Christoffel route as lam-series up to lam^4, all 3 components, %d (point, velocity) samples' % ns)
    chk('bit', ok_n, 'lam^0, lam^1, lam^3 coefficients 0 and lam^2 coefficient -m x/r^3: the Newtonian acceleration, at 5 points (|p| = 13, 7, 9, 11, 13) and 2 velocities each')
    chk('bit', ok_1, 'lam^4 coefficient = (m/r^3)[(4m/r - u^2) x + 4 (x.u) u] exactly at the same %d samples: the 1PN test-body term (recalled form, Will) from the engine\'s geodesic' % ns)
    (p, r0), m = PTS[0], ms[0]; Eis = engine_E_lam(Gv, S, iso_frame(p, r0, m)); Eg0 = engine_E_lam(Gv, S, iso_frame(p, r0, m, kind='ppn', beta=F(1), gamma=F(0)))
    Eg1 = engine_E_lam(Gv, S, iso_frame(p, r0, m, kind='ppn', beta=F(1), gamma=F(1)))
    chk('bit', all(not v for v in Eis.values()) and all(not v.get(2) for v in Eg1.values()), 'context: the isotropic frame solves E_a(0) = 0 on all 16 components at lam^0 .. lam^4 at |p| = 13 (curvature and Einstein form with the lam slot); the PPN frame with gamma = 1 at lam^2')
    chk('ctl', any(v.get(2) for v in Eg0.values()), 'the PPN frame with gamma = 0 is not vacuum at lam^2 (E_a != 0): the field equation fixes gamma = 1 at this order')
    chk('ctl', ok_c3 and ok_nw, 'controls: 3 (x.u) u in place of 4 (x.u) u fails, and the Newtonian term alone (lam^4 coefficient 0) fails, on every sample')
    tick('A1')
    # ================================================================================== A2 PPN family
    head('A2. the PPN frames e^0 = (1 - U + (beta - 1/2) U^2) dt, e^i = (1 + gamma U) dx^i: the lam^4 coefficient against the (beta, gamma) form')
    ok_ppn = True; ok_g0 = True; nppn = 0
    for beta, gamma in ((F(1), F(1)), (F(1), F(0)), (F(0), F(1)), (F(1, 2), F(3, 2)), (F(2), F(-1, 3))):
        for (p, r0), m in list(zip(PTS, ms))[:3]:
            ge = F(1) if (FAULT == 'gamma0' and (beta, gamma) == (F(1), F(0))) else gamma
            e = iso_frame(p, r0, m, kind='ppn', beta=beta, gamma=gamma); uu = VEL[nppn % 2]; u = [{0: F(1)}] + [{1: c} for c in uu]
            ab = engine_accel(Gv, S, e, u); pf = pn_form(p, uu, m, beta, ge); nppn += 1
            ok_ppn &= all(ab[i].get(2, 0) == pf[i][0] and ab[i].get(4, 0) == pf[i][1] for i in range(3))
            if (beta, gamma) == (F(1), F(0)): pw = pn_form(p, uu, m, F(1), F(1)); ok_g0 &= any(ab[i].get(4, 0) != pw[i][1] for i in range(3))
    chk('bit', ok_ppn, 'for (beta, gamma) = (1, 1), (1, 0), (0, 1), (1/2, 3/2), (2, -1/3) at 3 points each: lam^4 coefficient = (m x/r^3)(2 (beta + gamma) m/r - gamma u^2) + 2 (1 + gamma)(m/r^3)(x.u) u exactly: the engine reads beta from g_00 and gamma from g_ij')
    chk('ctl', ok_g0, 'the gamma = 0 frame does not give the Schwarzschild (gamma = 1) 1PN term')
    tick('A2')
    # ================================================================================== A3 floats
    head('A3. [std] floats: the 1PN equations of motion (M = 1, e = 0.3): periastron advance per orbit against 6 pi M/p')
    xs, ys = [], []
    for p in (200.0, 400.0, 800.0):
        adv, sd = advance_1pn(p, 0.3); xs.append(1 / p); ys.append(adv / (6 * math.pi / p)); print('    p = %4d: advance/(6 pi M/p) = %.8f (spread over orbits %.1e rad)' % (p, ys[-1], sd))
    R0, R1 = np.polyfit(xs, ys, 1)[::-1]
    chk('std', abs(R0 - 1) < 1e-3, 'linear fit in M/p: intercept %.6f (|intercept - 1| = %.1e < 1e-3), slope %.2f: the 1PN equations carry 6 pi M/(a (1 - e^2)) per orbit (d5_perihelion: the full geodesic)' % (R0, abs(R0 - 1), R1))
    tick('A3')
    # ================================================================================== B the Lambda term
    head('B. the Lambda term: the printed precession frequency per orbit = GRV-007\'s H^2 3 pi a^3 sqrt(1 - e^2)/M (exact Fractions)')
    ok_id = ok_d5 = True; n = 0; cnt = {'without the 1/2': [0, 0], 'Lambda -> -Lambda in the frequency': [0, 0], '(1 - e^2) in place of its root (e != 0)': [0, 0]}
    for (e_, se) in ((F(3, 5), F(4, 5)), (F(5, 13), F(12, 13)), (F(8, 17), F(15, 17)), (F(0), F(1))):
        for a in (F(400), F(7, 3), F(10 ** 6)):
            for M, Lam, c, G in ((F(1), F(3, 10 ** 8), F(1), F(1)), (F(2, 7), F(-1, 10 ** 5), F(1), F(1)), (F(19), F(1, 7), F(3), F(5, 11))):
                om2 = G * M / a ** 3                                               # Kepler, Newtonian order
                half = F(1) if FAULT == 'half' else F(1, 2); sl = -1 if FAULT == 'sign_lambda' else 1
                freq_times_period = 2 * half * Lam * sl * c ** 2 * se / om2       # (1/2)(Lambda c^2/omega) sqrt(1 - e^2) x 2 pi/omega, in units of pi
                form = Lam * c ** 2 * a ** 3 * se / (G * M)                        # pi Lambda c^2 a^3 sqrt(1 - e^2)/(G M), in units of pi
                H2 = Lam / 3; Mg = G * M / c ** 2; grv = 3 * H2 * a ** 3 * se / Mg # GRV-007: H^2 3 pi a^3 sqrt(1 - e^2)/M, geometric M, in units of pi
                pp = a * (1 - e_ * e_); d5 = 3 * H2 * pp ** 3 / (Mg * (1 - e_ * e_) ** 2 * se) if se else None   # 3 pi p^3/(M (1 - e^2)^(5/2)) times H2
                ok_id &= (freq_times_period == form == grv); ok_d5 &= (d5 == grv); n += 1
                for key, wrong, seen in (('without the 1/2', 2 * Lam * c ** 2 * se / om2, True), ('Lambda -> -Lambda in the frequency', -Lam * c ** 2 * se / om2, True),
                                         ('(1 - e^2) in place of its root (e != 0)', Lam * c ** 2 * se * se / om2, e_ != 0)):
                    if seen: cnt[key][1] += 1; cnt[key][0] += int(wrong != grv)
    chk('std', ok_id, '(1/2)(Lambda c^2/omega) sqrt(1 - e^2) x (2 pi/omega) = pi Lambda c^2 a^3 sqrt(1 - e^2)/(G M) = GRV-007\'s H^2 3 pi a^3 sqrt(1 - e^2)/M (M -> G M/c^2, Lambda = 3 H^2), exactly at %d samples (e = 3/5, 5/13, 8/17, 0; three a; Lambda of both signs; c = G = 1 and c = 3, G = 5/11)' % n)
    chk('std', ok_d5, 'd5_perihelion part 4\'s slope 3 pi p^3/(M (1 - e^2)^(5/2)) times H^2 is the same expression with p = a (1 - e^2), exactly')
    for name, (k, m_) in cnt.items(): chk('ctl', k == m_ and m_ > 0, 'the wrong version "%s" differs at %d of %d samples' % (name, k, m_))
    tick('B')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('GSA-ORBITS' + ('-' + FAULT if FAULT else ''))

if __name__ == '__main__': main()
