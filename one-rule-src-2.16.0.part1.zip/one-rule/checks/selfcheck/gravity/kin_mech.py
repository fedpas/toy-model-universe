#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""kin_mech.py -- the Cayley-Klein family and its contractions, the steady rotations of the free top, and the decomposition of a bivector into
commuting simple bivectors.   python3 kin_mech.py [--fault NAME]

(A) One extra generator of square s added to the Lorentz base Cl(1,3): [B_an, B_bn] = -2 s B_ab (the engine's commutator, without the half).
    In the basis (B_ab, P_a = lambda B_a4) with s = s0 lambda^2 the structure constants are polynomials in lambda (exponents 0 and 2) and
    lambda = 0 is the s = 0 table (Poincare) exactly; s = 2 is the s = 1 algebra up to P -> P/sqrt(2) (same table with mu^2 = 1/2). The boosts of
    the homogeneous algebra, K -> eps D K D^-1 with D = diag(eps, 1, ..) or diag(1/eps, 1, ..), have entries that are polynomials in eps and give at
    eps = 0 the Galilei and the Carroll boosts; the invariant (covectors, vectors) of rotations and boosts on R^(1+d) are (1, 0), (0, 0), (0, 1)
    for Galilei, Lorentz, Carroll (d = 2, 3). The 10-dimensional Poincare table contracts to the Galilei table (K, P -> eps K, eps P) and the
    Carroll table (K, H -> eps K, eps H); the three are told apart by (dimension of the derived algebra, of the centre, rank of the Killing form).
(B) The linearised flow of the free top at a pure rotation in the plane (a, b), for the Euclidean, the elliptic and the hyperbolic top with
    diagonal second moments: the characteristic polynomial in x = l^2 is x (x - x_c)(x - x_d) with x_c = -(lam_a - lam_c)(lam_b - lam_c)/(M_ac M_bc),
    lam the eigenvalues of J eta, M the moments of the planes (x_c = -1 for the Euclidean body velocity); the rotation is unstable exactly when
    another eigenvalue of J eta lies strictly between lam_a and lam_b; for the Euclidean top this is the intermediate-axis theorem.
(C) Bivectors of Cl(p,q), 2 <= n <= 6: B^2 has grades 0 and 4 and S^3 = B^2 S for B = u ^ v (S the skew operator x -> (1/2)[B, x]); a bivector
    whose characteristic polynomial in mu^2 has distinct rational roots is the sum of at most floor(n/2) commuting simple bivectors, recovered from B
    alone by the spectral projectors of S^2 and unique (the kernels of S^2 - nu are the planes); with a repeated root the splittings form a family;
    in Cl(2,2) a bivector with non-real roots, or with a repeated root and S^2 not scalar on its eigenspace, is not such a sum over the reals.
[bit]  The engine's Lie table of Cl(p,q) (f: bivector with bivector, h: bivector on a vector), exact fractions; the free-top engine of g1_clkappa
       (Alg, Body, sigma_engine, charpoly); the bit-rule product of the algebra for squares and commutation of bivectors.
[std]  so(eta) as plain matrices (L_ab)^c_d = delta^c_a eta_bd - delta^c_b eta_ad; numpy Killing forms, ranks, eigenvalues and the real Schur form;
       the Euler equations by hand and the top with a fixed point in R^eta as eta-skew matrices (L = J Omega^T - Omega J, L' = Omega L + L Omega^T);
       the textbook relations of the Galilei and Carroll algebras; spectral projectors from np.linalg.eig.
[ctl]  Rescaling the base generators (a pole in lambda); rescaling one P only (a pole); the Galilei rescaling of s = 1 (a limit that is not the s = 0 table); s = 2 against s = -1; a Carroll
       boost with an invariant covector; the criterion inverted; one commutator sign flipped in the flow; the Euclidean metric for a hyperbolic body;
       equal moments (every rotation neutral); two simple bivectors sharing a vector; floor(n/2) + 1 terms; the quadruple of Cl(2,2) taken as
       decomposable. Each wrong version is also a --fault option that puts it into the main lines (the run must then end with FAILS).
Scope. Cl(1,3) with s in {-1, 0, 1, 2}, lambda in {1, 2, 3, 5} on the engine and rational lambda on the matrices; d = 2, 3; random rational bodies
       (10 per curved top, 30 for the Euclidean one) with diagonal J, all planes; Cl(p,q) with 2 <= n <= 6 (25 signatures); the exhaustive table
       of the bivectors with entries -1, 0, 1 in the five signatures with n = 4. The classification of all kinematical algebras, the normal forms
       of Williamson in general, and a body with non-diagonal J (the same body in another frame) are recalled, not checked."""
import time
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib, g1_clkappa), also under python3 -I
from b1lib import *
import g1_clkappa as G1
import numpy as np
import scipy.linalg as sla

FAULT_NAMES = ['POLE', 'ONEP', 'NHLIMIT', 'S2NEW', 'CARCOV', 'INVERT', 'BADCOMM', 'WRONGETA', 'NONCOMM', 'MPLUS1', 'QUADRUPLE']
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)
def pcnt(x): return bin(x).count('1')

# ------------------------------------------------------------------------------------------------ exact helpers
def mm(X, Y): return G1.mat_mul(X, Y)
def madd(X, Y, c=1): return [[x + c * y for x, y in zip(rx, ry)] for rx, ry in zip(X, Y)]
def mscale(X, c): return [[c * x for x in r] for r in X]
def mid(n): return [[F(int(i == j)) for j in range(n)] for i in range(n)]
def mT(X): return [list(r) for r in zip(*X)]
def nullspace(rows, nvar):
    """exact basis of {w : rows w = 0}"""
    M = [[F(x) for x in r] for r in rows]; piv = []; r = 0
    for c in range(nvar):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
    free = [c for c in range(nvar) if c not in piv]; out = []
    for fc in free:
        w = [F(0)] * nvar; w[fc] = F(1)
        for i, pc_ in enumerate(piv): w[pc_] = -M[i][fc]
        out.append(w)
    return out
def jacobi_ok(f, G):
    """f[(A,B)] = (C, coefficient): [X_A, X_B] = coefficient X_C"""
    def br(u, v):
        r = {}
        for a, x in u.items():
            for b, y in v.items():
                if (a, b) in f:
                    c, co = f[(a, b)]; r[c] = r.get(c, 0) + x * y * co
        return {k: v for k, v in r.items() if v}
    for a in range(G):
        for b in range(G):
            for c in range(G):
                t = {}
                for x in (br({a: 1}, br({b: 1}, {c: 1})), br({b: 1}, br({c: 1}, {a: 1})), br({c: 1}, br({a: 1}, {b: 1}))):
                    for k, v in x.items(): t[k] = t.get(k, 0) + v
                if any(t.values()): return False
    return True

# =============================================================================================================== A. the Cayley-Klein family
SQB = [1, -1, -1, -1]                                                          # Cl(1,3): time +1, space -1 (the engine's convention)
def lie_s(s): return Lie(SQB + [s])
def std_matrices(sq):
    """[std] so(eta) in plain matrices: (L_ab)^c_d = delta^c_a eta_bd - delta^c_b eta_ad (a < b), eta = diag(sq)"""
    N = len(sq); pairs = [(i, j) for i in range(N) for j in range(i + 1, N)]; mats = []
    for (a, b) in pairs:
        M = [[F(0)] * N for _ in range(N)]; M[a][b] += F(sq[b]); M[b][a] -= F(sq[a]); mats.append(M)
    return pairs, mats
def std_table(sq):
    """[std] f[(A,B)] = {C: c} with [2 L_A, 2 L_B] = sum_C c (2 L_C), the engine's normalisation of [B_A, B_B]"""
    pairs, mats = std_matrices(sq); N = len(sq); P = len(pairs)
    flat = [[x for row in M for x in row] for M in mats]; sysm = [[flat[C][i] for C in range(P)] for i in range(N * N)]
    f = {}
    for A in range(P):
        for B in range(P):
            Cm = madd(mm(mats[A], mats[B]), mm(mats[B], mats[A]), -1); rhs = [x for row in Cm for x in row]
            if not any(rhs): continue
            w, r, nv, ok = solve_exact(sysm, rhs); assert ok, 'a commutator of generators is not in their span'
            f[(A, B)] = {C: 2 * w[C] for C in range(P) if w[C]}
    return f
def eng_dict(L): return {(A, B): {C: c} for (A, B), (C, c) in L.f.items()}
def std_killing(f, G):
    ad = np.zeros((G, G, G))
    for (A, B), d in f.items():
        for C, c in d.items(): ad[A][C][B] += float(c)
    K = np.array([[np.trace(ad[A] @ ad[B]) for B in range(G)] for A in range(G)]); ev = np.linalg.eigvalsh((K + K.T) / 2)
    return (int((ev > 1e-9).sum()), int((ev < -1e-9).sum()), int((abs(ev) <= 1e-9).sum()))

head('A. CAND-001: one extra generator of square s on Cl(1,3); the contraction s -> 0; Galilei and Carroll')
LS = {s: lie_s(s) for s in (-1, 0, 1, 2)}
for s, L in LS.items():
    n = 4; sh = {}
    for A, g in enumerate(L.gens):
        ij = tuple(i for i in range(5) if (g >> i) & 1)
        if ij[1] == n: sh[ij[0]] = A
    ok = True
    for a in range(n):
        for b in range(a + 1, n):
            ent = L.f.get((sh[a], sh[b])); want = (L.idx[(1 << a) | (1 << b)], -2 * s) if s else None
            ok &= ent == want
    chk('bit', ok and jacobi_ok(L.f, L.G), 's = %d: the engine\'s table has [B_an, B_bn] = %s B_ab for the six pairs a < b of the base (the full commutator, no half; sign minus), n = 4; Jacobi holds on all %d^3 triples' % (s, -2 * s, L.G))
for s, L in LS.items():
    fs = std_table(SQB + [s]); fe = eng_dict(L)
    chk('bit==std', fs == fe, 's = %d: the engine table equals the commutators of the plain matrices (L_ab)^c_d = delta^c_a eta_bd - delta^c_b eta_ad of so(eta), eta = diag(1,-1,-1,-1,%d), expanded in the same basis (%d nonzero brackets)' % (s, s, len(fe)))
kil = {}
for s, L in LS.items():
    ke, dg = killing_signature(L); ks = std_killing(std_table(SQB + [s]), L.G); kil[s] = ke
    chk('bit==std', ke == ks, 's = %d: Killing form signature (positive, negative, zero) = %s from the engine and %s from numpy on the matrices' % (s, ke, ks))
chk('bit', kil[-1] == (4, 6, 0) and kil[0] == (3, 3, 4) and kil[1] == (6, 4, 0), 'Killing signatures: s = -1 %s, s = 0 %s (Poincare: degenerate, the four translations), s = +1 %s, on the base with time squaring +1' % (kil[-1], kil[0], kil[1]))

def family(L, w):
    """structure constants of the basis lambda^(w_A) B_A: [X_A, X_B] = sum lambda^(w_A + w_B - w_C) f X_C, as {(A,B): (C, {exponent: coefficient})}"""
    return {(A, B): (C, {w[A] + w[B] - w[C]: c}) for (A, B), (C, c) in L.f.items()}
def fam_limit_ok(fam): return all(e >= 0 for (_, d) in fam.values() for e in d)
def fam_eval(fam, lam2):
    """the table at lambda^2 = lam2 (only even exponents occur for the P-scaling)"""
    out = {}
    for k, (C, d) in fam.items():
        tot = F(0)
        for e, c in d.items():
            assert e % 2 == 0, 'odd exponent'
            tot += c * F(lam2) ** (e // 2)
        if tot: out[k] = (C, tot)
    return out
def fam_limit(fam): return {k: (C, d[0]) for k, (C, d) in fam.items() if 0 in d}
def wP(L): return [1 if (L.gens[A] >> 4) & 1 else 0 for A in range(L.G)]
def wJ(L): return [0 if (L.gens[A] >> 4) & 1 else 1 for A in range(L.G)]
def wP0(L): return [1 if L.gens[A] == (1 | (1 << 4)) else 0 for A in range(L.G)]
for s0 in (-1, 1):
    Ls0 = LS[s0]; fam = family(Ls0, wP(Ls0)); expo = sorted({e for (_, d) in fam.values() for e in d})
    lim = fam_limit(fam); zero = dict(LS[0].f)
    ok_lim = all(e >= 0 for (_, d) in fam.values() for e in d) and lim == {k: v for k, v in zero.items()}
    ok_at = all(fam_eval(fam, lam * lam) == {k: (C, F(c)) for k, (C, c) in lie_s(s0 * lam * lam).f.items()} for lam in (1, 2, 3, 5))
    chk('bit', ok_lim and ok_at and jacobi_ok(lim, Ls0.G),
        's0 = %+d, P_a = lambda B_a4: the structure constants are polynomials in lambda with exponents %s (no negative power); the table at lambda = 1, 2, 3, 5 is the engine\'s table for s = s0 lambda^2 = %s; the limit lambda = 0 is the engine\'s s = 0 table exactly (%d brackets) and satisfies Jacobi' % (s0, expo, [s0 * l * l for l in (1, 2, 3, 5)], len(lim)))
    stdlam = True
    for lam in (F(1, 2), F(1, 3), F(5, 7)):
        ft = std_table(SQB + [s0 * lam * lam]); fe = fam_eval(fam, lam * lam)
        stdlam &= {k: {C: c} for k, (C, c) in fe.items()} == ft
    chk('bit==std', stdlam, 's0 = %+d: the rescaled table at the rational lambda = 1/2, 1/3, 5/7 equals the commutators of the plain matrices with eta_44 = s0 lambda^2 (so the algebra of s0 lambda^2 is the rescaled algebra of s0, for lambda != 0)' % s0)
L1 = LS[1]; fJ = family(L1, wJ(L1)); fP0 = family(L1, wP0(L1))
pole = not fam_limit_ok(fJ)
poles = sorted({e for (_, d) in fJ.values() for e in d})
onep_ok = fam_limit_ok(fP0) and fam_limit(fP0) == dict(LS[0].f)
chk('bit' if fault('POLE') else 'ctl', fam_limit_ok(fJ) if fault('POLE') else (pole and min(poles) == -1),
    'rescaling the base generators B_ab -> lambda B_ab instead of B_a4: the exponents are %s, the bracket [B_a4, B_b4] = -2s B_ab/lambda has a pole at lambda = 0: no limit' % poles)
chk('bit' if fault('ONEP') else 'ctl', onep_ok if fault('ONEP') else (not fam_limit_ok(fP0) and min(e for (_, d_) in fP0.values() for e in d_) == -1),
    'rescaling only P_0 = lambda B_04: [B_0j, B_j4] = +-2 B_04 gives the exponent -1 (a pole at lambda = 0): the four P_a have to be rescaled together')
Ltwo = LS[2]; famT = family(Ltwo, wP(Ltwo)); to1 = {k: (C, c) for k, (C, c) in fam_eval(famT, F(1, 2)).items()}
kil2 = killing_signature(Ltwo)[0]
chk('bit' if fault('S2NEW') else 'ctl', (kil2 == kil[-1]) if fault('S2NEW') else (to1 == dict(LS[1].f) and kil2 == kil[1] and kil2 != kil[-1]),
    's = 2: the basis (B_ab, P_a = mu B_a4) with mu^2 = 1/2 has the s = 1 table exactly, and the Killing signature %s equals that of s = 1, not that of s = -1 (%s): s = 2 is the s = 1 algebra, not a new one (isomorphic over R, by mu = 1/sqrt 2)' % (kil2, kil[-1]))
tline('A tables')

# the homogeneous algebras on R^(1+d) and their invariants (bd.mjp.25 again)
def kin_mats(d):
    L = Lie([1] + [-1] * d); n = d + 1; mats = {}
    for A, g in enumerate(L.gens):
        i, j = [k for k in range(n) if (g >> k) & 1]
        M = [[F(0)] * n for _ in range(n)]
        for (A2, b), (c, h) in L.h.items():
            if A2 == A: M[c][b] += h
        mats[(i, j)] = M
    return L, mats
def boost(Mb, kind, eps):
    n = len(Mb); M = [[F(0)] * n for _ in range(n)]; e2 = F(eps) ** 2
    for i in range(1, n):
        a, b = Mb[i][0], Mb[0][i]
        if kind == 'Galilei': M[i][0], M[0][i] = a, e2 * b
        elif kind == 'Carroll': M[i][0], M[0][i] = e2 * a, b
        else: M[i][0], M[0][i] = a, b
    return M
def inv_dims(mats):
    n = len(mats[0]); big = [r for M in mats for r in M]; bigT = [r for M in mats for r in mT(M)]
    return n - rank_exact(bigT), n - rank_exact(big)                 # (covectors killed by every generator, vectors killed)
KIN = {}
for d in (2, 3):
    L, mats = kin_mats(d); n = d + 1
    rots = [mats[(i, j)] for (i, j) in mats if i >= 1]
    Kmat = {i: mats[(0, i)] for i in range(1, n)}
    # the Lorentz boost of the engine: entries at [i][0] and [0][i]; the diagonal change of basis
    ok_conj = True
    for eps in (F(1, 2), F(2, 3)):
        for kind, Dd in (('Galilei', [eps] + [F(1)] * d), ('Carroll', [1 / eps] + [F(1)] * d)):
            D = [[Dd[i] if i == j else F(0) for j in range(n)] for i in range(n)]; Di = [[1 / Dd[i] if i == j else F(0) for j in range(n)] for i in range(n)]
            for i in range(1, n):
                conj = mscale(mm(mm(D, Kmat[i]), Di), eps)
                ok_conj &= conj == boost(Kmat[i], kind, eps)
    ok_poly = True
    for kind in ('Galilei', 'Carroll'):
        c1 = madd(mm(boost(Kmat[1], kind, 1), boost(Kmat[2], kind, 1)), mm(boost(Kmat[2], kind, 1), boost(Kmat[1], kind, 1)), -1)
        for eps in (F(1, 2), F(2), F(3)):
            ce = madd(mm(boost(Kmat[1], kind, eps), boost(Kmat[2], kind, eps)), mm(boost(Kmat[2], kind, eps), boost(Kmat[1], kind, eps)), -1)
            ok_poly &= ce == mscale(c1, eps * eps)
    dims = {}
    for kind in ('Galilei', 'Lorentz', 'Carroll'):
        gens = rots + [boost(Kmat[i], kind, 0) for i in range(1, n)]
        dims[kind] = inv_dims(gens)
    # [std] plain matrices as in the bridge: K_G = E_i0, K_L = E_i0 + E_0i, K_C = E_0i
    def std_gens(kind):
        G = []
        for i in range(1, n):
            for j in range(i + 1, n):
                R = np.zeros((n, n)); R[i, j] = 1; R[j, i] = -1; G.append(R)
        for i in range(1, n):
            K = np.zeros((n, n))
            if kind in ('Galilei', 'Lorentz'): K[i, 0] = 1
            if kind in ('Lorentz', 'Carroll'): K[0, i] = 1
            G.append(K)
        return G
    sd = {kind: (n - np.linalg.matrix_rank(np.vstack([g.T for g in std_gens(kind)])), n - np.linalg.matrix_rank(np.vstack(std_gens(kind)))) for kind in dims}
    sd = {k: (int(v[0]), int(v[1])) for k, v in sd.items()}      # (covectors, vectors)
    KIN[d] = dims
    want = {'Galilei': (1, 0), 'Lorentz': (0, 0), 'Carroll': (0, 1)}                       # (invariant covectors, invariant vectors)
    wrong = dims['Carroll'] if not fault('CARCOV') else None
    chk('bit', all(dims[k] == want[k] for k in want) if not fault('CARCOV') else (dims['Carroll'][0] == 1), 'd = %d: invariant (covectors, vectors) of rotations + boosts at eps = 0: Galilei %s, Lorentz %s, Carroll %s (the covector dt of Galilei, the vector d/dt of Carroll, neither for Lorentz)' % (d, dims['Galilei'], dims['Lorentz'], dims['Carroll']))
    chk('bit==std', dims == sd, 'd = %d: the same three pairs from plain matrices E_i0, E_0i (numpy rank): %s' % (d, sd))
chk('ctl', KIN[3]['Carroll'][0] == 0 and KIN[3]['Galilei'][1] == 0, 'Carroll has no invariant covector (its boost t -> t + v x moves dt) and Galilei no invariant vector (x -> x + v t moves d/dt)')
tline('A homogeneous')

# the 10-dimensional tables: Poincare contracts to Galilei and to Carroll
L0 = LS[0]; names = {}
for A, g in enumerate(L0.gens):
    ij = tuple(i for i in range(5) if (g >> i) & 1)
    names[A] = ('J' if ij[0] >= 1 and ij[1] <= 3 else ('K' if ij[0] == 0 and ij[1] <= 3 else ('H' if ij == (0, 4) else 'P')), ij)
wG = [1 if names[A][0] in ('K', 'P') else 0 for A in range(L0.G)]
wC = [1 if names[A][0] in ('K', 'H') else 0 for A in range(L0.G)]
def inv_triple(f, G):
    ad = np.zeros((G, G, G))
    for (A, B), (C, c) in f.items(): ad[A][C][B] += float(c)
    der = np.array([ad[A][:, B] for A in range(G) for B in range(G)]); dd = int(np.linalg.matrix_rank(der, tol=1e-9)) if der.size else 0
    cen = G - int(np.linalg.matrix_rank(np.vstack([ad[A] for A in range(G)]), tol=1e-9))
    K = np.array([[np.trace(ad[A] @ ad[B]) for B in range(G)] for A in range(G)])
    return dd, cen, int(np.linalg.matrix_rank(K, tol=1e-9))
def relations(f, kind):
    """the textbook relations (recalled) as predicates on a table; returns the list of failing relation names"""
    idx = {names[A][1]: A for A in names}; K = [idx[(0, i)] for i in (1, 2, 3)]; P = [idx[(i, 4)] for i in (1, 2, 3)]; H = idx[(0, 4)]
    g = lambda A, B: f.get((A, B))
    bad = []
    if any(g(K[i], K[j]) for i in range(3) for j in range(3)): bad.append('[K,K] = 0')
    if any(g(P[i], P[j]) for i in range(3) for j in range(3)): bad.append('[P,P] = 0')
    if g(P[0], H) or g(P[1], H) or g(P[2], H): bad.append('[P,H] = 0')
    if kind == 'Galilei':
        if any(g(K[i], P[j]) for i in range(3) for j in range(3)): bad.append('[K,P] = 0')
        if not all(g(K[i], H) and g(K[i], H)[0] == P[i] for i in range(3)): bad.append('[K,H] = +-P')
    if kind == 'Carroll':
        if any(g(K[i], H) for i in range(3)): bad.append('[K,H] = 0')
        if not all(g(K[i], P[j]) and g(K[i], P[j])[0] == H for i in range(3) for j in range(3) if i == j) or any(g(K[i], P[j]) for i in range(3) for j in range(3) if i != j): bad.append('[K_i,P_j] = delta_ij H')
    if not all(g(J, K_) and g(J, K_)[0] in K for J in [idx[(1, 2)]] for K_ in [K[0], K[1]]): bad.append('[J,K] = K')
    return bad
trip = {}
for kind, w in (('Galilei', wG), ('Carroll', wC)):
    fam = family(L0, w); ok_fl = fam_limit_ok(fam); lim = fam_limit(fam); trip[kind] = inv_triple(lim, L0.G)
    # [std] numpy tensor of the plain matrices contracted at eps = 1e-6
    fs = std_table(SQB + [0]); T = np.zeros((L0.G, L0.G, L0.G))
    for (A, B), d_ in fs.items():
        for C, c in d_.items(): T[A, B, C] = float(c)
    eps = 1e-6; Tc = np.array([[[T[A, B, C] * eps ** (w[A] + w[B] - w[C]) if T[A, B, C] else 0.0 for C in range(L0.G)] for B in range(L0.G)] for A in range(L0.G)])
    Tl = np.zeros_like(T)
    for (A, B), (C, c) in lim.items(): Tl[A, B, C] = float(c)
    chk('bit', ok_fl and jacobi_ok(lim, L0.G) and relations(lim, kind) == [] and len(lim) < len(L0.f),
        '%s: the Poincare table (s = 0) with %s rescaled by eps has no negative exponent; the limit is a Lie algebra (Jacobi) with the relations %s; %d of the %d brackets survive' % (kind, 'K and P' if kind == 'Galilei' else 'K and H', '[K,K] = [P,P] = [P,H] = 0, [K,P] = 0, [K_i,H] = +-P_i' if kind == 'Galilei' else '[K,K] = [P,P] = [P,H] = [K,H] = 0, [K_i,P_j] = +-delta_ij H', len(lim), len(L0.f)))
    chk('bit==std', np.abs(Tc - Tl).max() < 1e-5, '%s: numpy, the plain-matrix tensor with each entry times eps^(w_A + w_B - w_C) at eps = 1e-6 is within %.1e of the engine\'s limit table' % (kind, np.abs(Tc - Tl).max()))
LNH = family(LS[1], wG); limNH = fam_limit(LNH); limG = fam_limit(family(L0, wG))
nh_ok = fam_limit_ok(LNH) and limNH == dict(L0.f)
chk('bit' if fault('NHLIMIT') else 'ctl', nh_ok if fault('NHLIMIT') else (fam_limit_ok(LNH) and limNH != dict(L0.f) and jacobi_ok(limNH, L0.G) and relations(limNH, 'Galilei') != [] and len(limNH) > len(limG)),
    'the Galilei rescaling (K, P -> eps K, eps P) of the s = 1 algebra has a limit, but it is not the s = 0 table and not Galilei: [P_i, H] = -+2 K_i survives (the Newton-Hooke algebra, %d brackets against %d for Galilei); the rescaling picks the contraction, the value of s the starting point' % (len(limNH), len(limG)))
trip['Poincare'] = inv_triple(dict(L0.f), L0.G); trip['de Sitter'] = inv_triple(dict(LS[-1].f), L0.G); trip['anti de Sitter'] = inv_triple(dict(LS[1].f), L0.G)
chk('bit', len(set(trip.values())) == 4 and trip['Poincare'] == (10, 0, 6) and trip['Galilei'] == (9, 0, 3) and trip['Carroll'] == (10, 1, 3) and trip['de Sitter'] == (10, 0, 10),
    '(dimension of the derived algebra, dimension of the centre, rank of the Killing form): Poincare %s, Galilei %s, Carroll %s (H is central), de Sitter %s, anti de Sitter %s: the contractions are not isomorphic to each other or to the family' % (trip['Poincare'], trip['Galilei'], trip['Carroll'], trip['de Sitter'], trip['anti de Sitter']))
tline('A')

# =============================================================================================================== B. the free top
rngB = random.Random(361)
def axis_points(k):
    """engine masses at weight-1 points on the axes (a body with diagonal J): a point at the origin and pairs +-a_i e_i"""
    pts = [(F(rngB.randint(1, 6), rngB.randint(3, 7)), [F(0)] * 3)]
    for i in range(3):
        a = F(rngB.randint(1, 3), rngB.choice([4, 5, 7])) if k == -1 else F(rngB.randint(1, 5), rngB.choice([2, 3, 5]))
        m = F(rngB.randint(1, 6), rngB.randint(3, 7))
        for sg in (1, -1):
            q = [F(0)] * 3; q[i] = sg * a; pts.append((m, q))
    return pts
def second_moments(pts):
    return [sum(m * ([F(1)] + q)[i] ** 2 for m, q in pts) for i in range(4)]
def lin_data(k, pts, comm=None, planes=range(6)):
    A = G1.alg(k); bb = G1.Body(A, pts); cm = comm(A) if comm else A.comm; Sg = G1.sigma_engine(A, bb.I); out = {}
    for pl in planes:
        Bs = G1.gvec(A, G1.unit(pl)); PB = bb.I(Bs); stat = not bb.Iinv(cm(Bs, PB)).d
        Jm = [[G1.gread(bb.Iinv(cm(G1.gvec(A, G1.unit(j)), PB) + cm(Bs, bb.I(G1.gvec(A, G1.unit(j))))))[i] for j in range(6)] for i in range(6)]
        out[pl] = (stat, G1.charpoly(Jm), Jm)
    return Sg, out
PL = G1.PAIRS4                                                                      # engine order e01 e02 e03 e12 e31 e23 -> (0,1) (0,2) (0,3) (1,2) (1,3) (2,3)
def closed_roots(k, js, Mom, pl):
    """x_c for the other indices c of the plane pl: [(c, x_c)]; k = 0: the body velocity gives -1 on c = 0 and the translation planes are all zero"""
    a, b = PL[pl]; lam = [k * js[0]] + js[1:]; out = []
    for c in range(4):
        if c in (a, b): continue
        if k == 0 and a == 0: out.append((c, F(0))); continue
        if k == 0 and c == 0: out.append((c, F(-1))); continue
        Mac = Mom[tuple(sorted((a, c)))]; Mbc = Mom[tuple(sorted((b, c)))]
        out.append((c, -(lam[a] - lam[c]) * (lam[b] - lam[c]) / (Mac * Mbc)))
    return out
def cp_expected(roots):
    xs = [x for _, x in roots]; return [F(0)] * 0, -(xs[0] + xs[1]), xs[0] * xs[1]
def unstable_engine(cp):
    c2, c4 = cp[2], cp[4]; disc = c2 * c2 - 4 * c4
    return disc < 0 or c4 < 0 or (c4 >= 0 and -c2 > 0)
def between_rule(k, js, pl):
    a, b = PL[pl]; lam = [k * js[0]] + js[1:]
    return any(min(lam[a], lam[b]) < lam[c] < max(lam[a], lam[b]) for c in range(4) if c not in (a, b))
def std_top_jac(eta, Jd, p):
    """[std] the top with a fixed point in R^eta: Omega in so(eta) (basis E_ab), L = J Omega^T - Omega J (upper indices), L' = Omega L + L Omega^T;
    returns the 6 x 6 Jacobian at the rotation in plane p (the field is quadratic: central differences are exact)"""
    Eb = []
    for (a, b) in PL:
        M = np.zeros((4, 4)); M[a, b] += eta[b]; M[b, a] -= eta[a]; Eb.append(M)
    Jm = np.diag(Jd)
    def Lof(Om): return Jm @ Om.T - Om @ Jm
    def coords(Lm): return np.array([Lm[a, b] for (a, b) in PL])
    Mmap = np.array([coords(Lof(E)) for E in Eb]).T
    def field(w):
        Om = sum(w[i] * Eb[i] for i in range(6)); Lm = Lof(Om)
        return np.linalg.solve(Mmap, coords(Om @ Lm + Lm @ Om.T))
    e = np.zeros(6); e[p] = 1.0
    return np.array([(field(e + np.eye(6)[j]) - field(e - np.eye(6)[j])) / 2 for j in range(6)]).T
def spec_sq(Jac): return np.sort(np.real(np.linalg.eigvals(Jac) ** 2))

head('B. CAND-036: the linearised flow at a pure rotation of the free top; the rule on the eigenvalues of J eta')
res_roots = {}
ALL_OK = {}
for k in (1, -1):
    ok_cp = ok_stat = ok_mom = ok_rule = ok_unst = True; nbod = 10; nunst = 0; nplanes = 0; ok_std = True; stdn = 0
    for ib in range(nbod):
        pts = axis_points(k); js = second_moments(pts)
        Sg, data = lin_data(k, pts, comm=(G1.bad_comm if fault('BADCOMM') else None))
        Mom = {PL[i]: Sg[i][i] for i in range(6)}
        offd = all(Sg[i][j] == 0 for i in range(6) for j in range(6) if i != j)
        ok_mom &= offd and all(Mom[(0, i)] == js[0] + k * js[i] for i in (1, 2, 3)) and all(Mom[(i, j)] == js[i] + js[j] for (i, j) in ((1, 2), (1, 3), (2, 3))) and all(v > 0 for v in Mom.values())
        for pl in range(6):
            stat, cp, Jm = data[pl]; roots = closed_roots(k, js, Mom, pl); _, s2, p2 = cp_expected(roots)
            ok_stat &= stat
            ok_cp &= all(cp[i] == 0 for i in (1, 3, 5)) and cp[6] == 0 and cp[2] == s2 and cp[4] == p2
            un = unstable_engine(cp); rule = between_rule(k, js, pl); ok_rule &= un == rule; nunst += un; nplanes += 1
            if ib < 3:
                eta = [k, 1, 1, 1] if not fault('WRONGETA') else [1, 1, 1, 1]
                jac = std_top_jac(eta, [float(x) for x in ([js[0]] + js[1:])], pl); xs = [x for _, x in roots]
                want = np.sort(np.array([0.0, 0.0, float(xs[0]), float(xs[0]), float(xs[1]), float(xs[1])]))
                ok_std &= np.abs(spec_sq(jac) - want).max() < 1e-7; stdn += 1
    ALL_OK[k] = (ok_cp, ok_rule)
    nm = 'elliptic (S^3, eta = diag(1,1,1,1))' if k == 1 else 'hyperbolic (eta = diag(-1,1,1,1))'
    chk('bit', ok_stat and ok_mom, '%s: %d random bodies with diagonal J (masses at the origin and at +-a_i e_i, engine masses, rational): the six pure motions are stationary, the engine\'s Sigma is diagonal with the moments j0 + kappa j_i and j_i + j_j, all positive' % (nm, nbod))
    chk('bit', ok_cp, '%s: the characteristic polynomial of the engine\'s 6 x 6 linearisation is exactly x (x - x_c)(x - x_d) in x = l^2 with x_c = -(lam_a - lam_c)(lam_b - lam_c)/(M_ac M_bc), lam = (kappa j0, j1, j2, j3) the eigenvalues of J eta, on all %d (body, plane) pairs' % (nm, nplanes))
    chk('bit', ok_rule, '%s: unstable (a root x > 0 or complex) exactly when another eigenvalue of J eta lies strictly between lam_a and lam_b: %d of the %d (body, plane) pairs are unstable, the rest stable or neutral, and the rule agrees on all' % (nm, nunst, nplanes))
    chk('bit==std', ok_std, '%s: numpy eigenvalues of the 6 x 6 Jacobian of L\' = Omega L + L Omega^T on eta-skew matrices (L = J Omega^T - Omega J, plain matrices, no Clifford product) squared = {0, 0, x_c, x_c, x_d, x_d} for %d (body, plane) pairs (tolerance 1e-7)' % (nm, stdn))
tline('B curved')

# the Euclidean top: 30 bodies, the three rotations; the intermediate-axis theorem
ok_e = ok_t = ok_i = ok_std = True; nmid = 0; ncase = 0
for ib in range(30):
    while True:
        pts = axis_points(0); js = second_moments(pts)
        Sg, data = lin_data(0, pts, planes=(0, 3, 4, 5))
        I1, I2, I3 = Sg[5][5], Sg[4][4], Sg[3][3]; Ik = {1: I1, 2: I2, 3: I3}
        if len({I1, I2, I3}) == 3: break
    ok_t &= data[0][1][2:] == [0] * 5 and data[0][0]
    for pl, ax in ((3, 3), (4, 2), (5, 1)):
        stat, cp, Jm = data[pl]; o = [i for i in (1, 2, 3) if i != ax]
        xk = -(Ik[ax] - Ik[o[0]]) * (Ik[ax] - Ik[o[1]]) / (Ik[o[0]] * Ik[o[1]])
        ok_e &= stat and all(cp[i] == 0 for i in (1, 3, 5)) and cp[6] == 0 and cp[2] == 1 - xk and cp[4] == -xk       # x (x + 1)(x - xk) = x^3 + (1 - xk) x^2 - xk x
        midax = sorted([(I1, 1), (I2, 2), (I3, 3)])[1][1]
        ok_i &= unstable_engine(cp) == (ax == midax) and (xk > 0) == (ax == midax)
        # numpy: the Euler equations by hand, linearised at omega = e_ax
        Iv = [float(I1), float(I2), float(I3)]
        def euler(w): return np.array([(Iv[1] - Iv[2]) / Iv[0] * w[1] * w[2], (Iv[2] - Iv[0]) / Iv[1] * w[2] * w[0], (Iv[0] - Iv[1]) / Iv[2] * w[0] * w[1]])
        e = np.zeros(3); e[ax - 1] = 1.0
        jac = np.array([(euler(e + np.eye(3)[j]) - euler(e - np.eye(3)[j])) / 2 for j in range(3)]).T
        ok_std &= np.abs(np.sort(np.real(np.linalg.eigvals(jac) ** 2)) - np.sort([0.0, float(xk), float(xk)])).max() < 1e-9
        ncase += 1
    nmid += 1
chk('bit', ok_e and ok_t, 'Euclid (kappa = 0): 30 random bodies; the engine\'s characteristic polynomial at the rotations about the three axes is x (x + 1)(x - x_k) with x_k = -(I_k - I_i)(I_k - I_j)/(I_i I_j) (the root -1 is the body velocity turning at the angular rate), and all eigenvalues are 0 for the three translation planes of the first body')
chk('bit', ok_i, 'Euclid: the rotation is unstable exactly about the axis of the intermediate moment (x_k > 0 iff I_k is neither largest nor smallest), on %d (body, axis) pairs: the intermediate-axis theorem' % ncase)
chk('std', ok_std, 'numpy: the Euler equations I_1 w_1\' = (I_2 - I_3) w_2 w_3 and cyclic, linearised at w = e_k, have l^2 in {0, x_k, x_k} for the same %d pairs' % ncase)
# symmetric cases and equal moments
def body_from_j(k, j, a=None):
    """a body with J = diag(j0.., j3): masses at +-a e_i, m_i = j_i/(2 a^2), the origin mass chosen so that the sum of the masses is j0"""
    a = a if a is not None else (F(1, 4) if k == -1 else F(1, 2)); pts = []; tot = F(0)
    for i in range(3):
        m = j[i + 1] / (2 * a * a); tot += 2 * m
        for sg in (1, -1):
            q = [F(0)] * 3; q[i] = sg * a; pts.append((m, q))
    pts.append((j[0] - tot, [F(0)] * 3)); return pts
sym = {}
for k, j, aa in ((0, [F(40), F(2), F(2), F(3)], None), (0, [F(40), F(2), F(2), F(2)], None), (1, [F(40), F(2), F(2), F(3)], None), (-1, [F(200), F(2), F(2), F(3)], None), (1, [F(2), F(2), F(2), F(2)], F(2))):
    pts = body_from_j(k, j, aa); js = second_moments(pts); Sg, data = lin_data(k, pts); sym[(k, tuple(j))] = {}
    for pl in range(6):
        stat, cp, Jm = data[pl]; rk = rank_exact([list(row) for row in Jm])
        xs = [x for _, x in closed_roots(k, js, {PL[i]: Sg[i][i] for i in range(6)}, pl)]
        sym[(k, tuple(j))][pl] = (xs, rk, unstable_engine(cp))
sph = sym[(1, (F(2), F(2), F(2), F(2)))]; sph0 = sym[(0, (F(40), F(2), F(2), F(2)))]
chk('bit', all(all(x == 0 for x in sph[pl][0]) and not sph[pl][2] for pl in range(6)) and all(sph0[pl][0] == [F(0), F(0)] or sph0[pl][0] in ([F(-1), F(0)], [F(0), F(-1)]) for pl in range(3, 6)),
    'equal moments (a ball: J = 2 on all four axes of R^4 for the elliptic top, I_1 = I_2 = I_3 for the Euclidean one): in the elliptic top x_c = x_d = 0 for all six planes (every rotation is steady and neutral); in the Euclidean top the three roots are {0, -1, 0}')
neutral = [(key[0], pl, rk) for key, d in sym.items() for pl, (xs, rk, un) in d.items() if (key[0] != 0 or pl >= 3) and F(0) in xs and not un and key[1][1:] != (key[1][1],) * 3]
ranks_neutral = sorted({(kk, rk) for (kk, pl, rk) in neutral})
chk('bit', len(neutral) >= 3 and all(rk == 3 for (_, _, rk) in neutral),
    'a symmetric top (j1 = j2): the rotation in a plane that contains one of the two equal eigenvalues has x = 0 and is neutral by the rule (%d cases); the rank of the 6 x 6 linearisation there, as (kappa, rank): %s; the eigenvalue 0 has multiplicity 4, so the rank 3 in every case means a Jordan block: the linearised motion grows linearly in time there, which the rule on eigenvalues (exponential growth) does not see' % (len(neutral), ranks_neutral))
# time reversal is a symmetry, not a control
jac1 = std_top_jac([1, 1, 1, 1], [3.0, 2.0, 5.0, 7.0], 3); jac2 = -jac1
chk('std', np.abs(spec_sq(jac1) - spec_sq(jac2)).max() < 1e-12, 'the sign of the cross product reverses time (l -> -l): the spectrum is symmetric and l^2 and the criterion do not change: a symmetry of the equations, not a control')
# controls
bad_found = False
pts = axis_points(1); js = second_moments(pts)
Sg, dbad = lin_data(1, pts, comm=G1.bad_comm); Mom = {PL[i]: Sg[i][i] for i in range(6)}
for pl in range(6):
    _, s2, p2 = cp_expected(closed_roots(1, js, Mom, pl))
    if not (dbad[pl][1][2] == s2 and dbad[pl][1][4] == p2): bad_found = True
chk('bit' if fault('BADCOMM') else 'ctl', (not bad_found) if fault('BADCOMM') else bad_found, 'the flow with the commutator sign of one pair (e12, e23) flipped breaks the closed form of the linearisation on at least one plane of an elliptic body')
inv_bad = False
for k in (1, -1):
    for ib in range(4):
        pts = axis_points(k); js = second_moments(pts); Sg, d_ = lin_data(k, pts)
        if not all((not between_rule(k, js, pl)) == unstable_engine(d_[pl][1]) for pl in range(6)): inv_bad = True
chk('bit' if fault('INVERT') else 'ctl', (not inv_bad) if fault('INVERT') else inv_bad, 'the inverted criterion (unstable iff no eigenvalue of J eta lies between) disagrees with the engine on some plane of the sampled elliptic and hyperbolic bodies')
pts = axis_points(-1); js = second_moments(pts); Sg, d_ = lin_data(-1, pts); mism = False
for pl in range(6):
    jac = std_top_jac([1, 1, 1, 1], [float(x) for x in js], pl); xs = [x for _, x in closed_roots(-1, js, {PL[i]: Sg[i][i] for i in range(6)}, pl)]
    want = np.sort(np.array([0.0, 0.0, float(xs[0]), float(xs[0]), float(xs[1]), float(xs[1])]))
    mism |= np.abs(spec_sq(jac) - want).max() > 1e-7
chk('bit' if fault('WRONGETA') else 'ctl', (not mism) if fault('WRONGETA') else mism, 'the Euclidean metric eta = 1 for the hyperbolic body gives a different spectrum on some plane: the signature of eta is part of the answer')
# bd.geo.15 again: the invariants of the engine flow
rngc = random.Random(15); ok_inv = True
for k in (0, 1, -1):
    pts = axis_points(k); A = G1.alg(k); bb = G1.Body(A, pts)
    B0 = G1.MV(A.sq, {m: F(rngc.choice([-2, -1, 1, 2]), rngc.randint(1, 3)) for m in A.bivectors()})
    M, Bf = G1.engine_flow(A, bb.I, bb.Iinv, B0, 4)
    Pis, E, C2, C4 = G1.integrals(A, bb.I, M, Bf)
    ok_inv &= G1.ser_is_const(Pis, 4) and G1.ser_is_const(E, 4) and G1.ser_is_const(C2, 4) and G1.ser_is_const(C4, 4)
chk('bit', ok_inv, 'bd.geo.15 again: along the engine flow of a body with diagonal J (kappa = 0, 1, -1, random B0, exact series through t^4) the momentum M A(B) M~, the energy and the invariants <PP>_0, <PP>_4 are constant')
tline('B')

# =============================================================================================================== C. the decomposition of a bivector
class BitAlg:
    """the bit rule for the squares sq: e_a e_b = s(a,b) e_(a xor b)"""
    def __init__(self, sq):
        self.sq = list(sq); m = len(sq); M = 1 << m
        def sgn(a, b):
            c = 0; x = a; i = 0
            while x:
                if x & 1: c += pcnt(b & ((1 << i) - 1))
                x >>= 1; i += 1
            v = -1 if c & 1 else 1; x = a & b; i = 0
            while x:
                if x & 1: v *= self.sq[i]
                x >>= 1; i += 1
            return v
        self.s = [[sgn(a, b) for b in range(M)] for a in range(M)]
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                v = self.s[a][b]
                if v: out[a ^ b] = out.get(a ^ b, 0) + v * ca * cb
        return {k: v for k, v in out.items() if v}
    def comm(self, x, y):
        xy = self.mul(x, y); yx = self.mul(y, x); out = dict(xy)
        for k, v in yx.items(): out[k] = out.get(k, 0) - v
        return {k: v for k, v in out.items() if v}
def vsum(*ds):
    out = {}
    for d in ds:
        for k, v in d.items(): out[k] = out.get(k, 0) + v
    return {k: v for k, v in out.items() if v}
def vsc(d, c): return {k: c * v for k, v in d.items() if c * v}
def skew_engine(L, Bv):
    """the matrix S[c][b] of x -> (1/2)[B, x] from the engine's h table; Bv: {bivector mask: coefficient}"""
    n = L.N; S = [[F(0)] * n for _ in range(n)]
    for (A, b), (c, h) in L.h.items():
        co = Bv.get(L.gens[A])
        if co: S[c][b] += co * h
    return S
def skew_std(sq, Bv):
    n = len(sq); S = [[F(0)] * n for _ in range(n)]
    for m, co in Bv.items():
        a, b = [i for i in range(n) if (m >> i) & 1]; S[a][b] += co * sq[b]; S[b][a] -= co * sq[a]
    return S
def wedge(u, v, n):
    return {(1 << i) | (1 << j): u[i] * v[j] - u[j] * v[i] for i in range(n) for j in range(i + 1, n) if u[i] * v[j] - u[j] * v[i]}
def dotq(sq, u, v): return sum(sq[i] * u[i] * v[i] for i in range(len(sq)))
def solve_biv(L, S):
    """the bivector whose engine operator is S (exact), or None"""
    n = L.N; cols = []
    for A in range(L.G): cols.append(skew_engine(L, {L.gens[A]: F(1)}))
    rows = [[cols[A][i][j] for A in range(L.G)] for i in range(n) for j in range(n)]; rhs = [S[i][j] for i in range(n) for j in range(n)]
    w, r, nv, ok = solve_exact(rows, rhs)
    return {L.gens[A]: w[A] for A in range(L.G) if w[A]} if ok else None
def qpoly(S):
    """q(nu) of the characteristic polynomial p(x) = x^(n mod 2) q(x^2), coefficients from the top; the matrix S is eta-skew so odd coefficients vanish"""
    n = len(S); cp = G1.charpoly(S); assert all(cp[i] == 0 for i in range(1, n + 1, 2)), 'odd coefficients of an eta-skew operator vanish'
    ev = [cp[i] for i in range(0, n + 1, 2)]
    return ev if n % 2 == 0 else ev                                                  # p(x) = sum ev[j] x^(n - 2j): in nu = x^2 the degree is floor(n/2)
def poly_div_root(co, r):
    out = []; acc = F(0)
    for c in co[:-1]: acc = acc * r + c; out.append(acc)
    rem = acc * r + co[-1]; return out, rem
def rat_roots(co):
    """rational roots with multiplicity of the polynomial with descending coefficients co; returns (roots, remaining degree)"""
    co = [F(c) for c in co]
    while co and co[-1] == 0 and len(co) > 1: co = co[:-1]
    roots = []
    changed = True
    while len(co) > 1 and changed:
        changed = False
        nr = np.roots([float(c) for c in co])
        for r in nr:
            if abs(r.imag) < 1e-7:
                cand = F(r.real).limit_denominator(10 ** 4); q, rem = poly_div_root(co, cand)
                if rem == 0: roots.append(cand); co = q; changed = True; break
    return roots, len(co) - 1
def spectral_split(L, B):
    """from B alone: the roots nu of q, spectral projectors of S^2, the pieces S_i = S Pi_i; returns (S, nu list with multiplicities, pieces) or None if q does not split over Q"""
    S = skew_engine(L, B); n = L.N; ev = qpoly(S); k = n // 2
    co = [ev[j] for j in range(k + 1)]                                              # q(nu) = sum co[j] nu^(k - j)
    roots, rest = rat_roots(co)
    if rest: return S, None, None
    dist = sorted(set(roots))
    S2 = mm(S, S); I = mid(n); has0 = (n % 2 == 1)
    eig = list(dist) + ([F(0)] if has0 and F(0) not in dist else [])
    Pi = {}
    for nu in eig:
        P = I
        for nu2 in eig:
            if nu2 != nu: P = mm(P, mscale(madd(S2, I, -nu2), 1 / (nu - nu2)))
        Pi[nu] = P
    return S, {nu: roots.count(nu) for nu in dist}, Pi

def rand_orth(sq, rng, nref=4):
    n = len(sq); O = mid(n)
    for _ in range(nref):
        while True:
            v = [F(rng.randint(-3, 3)) for _ in range(n)]
            if dotq(sq, v, v) != 0: break
        vv = dotq(sq, v, v)
        R = [[F(int(i == j)) - 2 * v[i] * sq[j] * v[j] / vv for j in range(n)] for i in range(n)]                    # r_v(x) = x - 2 (x.v)/(v.v) v
        O = mm(R, O)
    return O
def check_orth(sq, O):
    n = len(sq); return all(sum(sq[k] * O[k][i] * O[k][j] for k in range(n)) == (sq[i] if i == j else 0) for i in range(n) for j in range(n))

head('C. CAND-076: the invariant decomposition of a bivector (n <= 6, every non-degenerate Cl(p,q))')
SIGS = [(n - q, q) for n in range(2, 7) for q in range(0, n + 1)]
rngC = random.Random(76)
# C0: T17 parts A, B, C again, in every signature
okA = okS = okB = okC = True; countA = 0
for (p, q) in SIGS:
    sq = [1] * p + [-1] * q; n = p + q; A_ = BitAlg(sq); L = Lie(sq)
    for _ in range(4 if n <= 4 else 2):
        Bv = {(1 << i) | (1 << j): F(rngC.randint(-3, 3)) for i in range(n) for j in range(i + 1, n)}; Bv = {k: v for k, v in Bv.items() if v}
        B2 = A_.mul(Bv, Bv)
        okA &= all(pcnt(m) in (0, 4) for m in B2)
        sc = -sum(sq[i] * sq[j] * Bv.get((1 << i) | (1 << j), 0) ** 2 for i in range(n) for j in range(i + 1, n))
        okS &= B2.get(0, 0) == sc
        w4 = {}
        for i, j, k_, l in itertools.combinations(range(n), 4):
            g = lambda a, b: Bv.get((1 << a) | (1 << b), 0)
            val = 2 * (g(i, j) * g(k_, l) - g(i, k_) * g(j, l) + g(i, l) * g(j, k_))
            if val: w4[(1 << i) | (1 << j) | (1 << k_) | (1 << l)] = val
        okA &= {m: v for m, v in B2.items() if pcnt(m) == 4} == w4
        countA += 1
    for _ in range(3):
        u = [F(rngC.randint(-2, 2)) for _ in range(n)]; v = [F(rngC.randint(-2, 2)) for _ in range(n)]; Bv = wedge(u, v, n)
        if not Bv: continue
        B2 = A_.mul(Bv, Bv); s_ = dotq(sq, u, v) ** 2 - dotq(sq, u, u) * dotq(sq, v, v); S = skew_engine(L, Bv)
        okB &= set(B2) <= {0} and B2.get(0, 0) == s_
        okC &= mm(mm(S, S), S) == mscale(S, s_) and S == skew_std(sq, Bv)
chk('bit', okA and okS, 'T17 parts A: in all %d signatures with 2 <= n <= 6, %d random integer bivectors: B^2 has grades 0 and 4 only, the scalar part is -sum_(i<j) eps_i eps_j B_ij^2 and the grade-4 part is B ^ B = 2 (B_ij B_kl - B_ik B_jl + B_il B_jk) (bit-rule product)' % (len(SIGS), countA))
chk('bit', okB and okC, 'T17 parts B, C: for u ^ v in every signature the square is scalar, B^2 = (u.v)^2 - u^2 v^2, the engine\'s operator S equals the plain-matrix operator, and S^3 = B^2 S (exact)')
tline('C0')

def decompose_case(sq, planes, cs, rng, tag, quiet=False):
    """planes: disjoint index pairs; cs: coefficients; builds B = sum c (O e_i) ^ (O e_j) and recovers the summands from B alone"""
    n = len(sq); L = Lie(sq); A_ = BitAlg(sq); O = rand_orth(sq, rng); assert check_orth(sq, O)
    cols = [[O[r][i] for r in range(n)] for i in range(n)]
    terms = [vsc(wedge(cols[i], cols[j], n), c) for (i, j), c in zip(planes, cs)]; B = vsum(*terms)
    S, mult, Pi = spectral_split(L, B)
    ok_se = S == skew_std(sq, B)
    if mult is None: return None, ok_se
    dist = sorted(mult); n_t = len(dist)
    parts = {}
    for nu in dist:
        if nu == 0: continue
        Si = mm(S, Pi[nu]); Bi = solve_biv(L, Si)
        if Bi is None: return None, ok_se
        parts[nu] = Bi
    return dict(L=L, A=A_, B=B, terms=terms, S=S, mult=mult, Pi=Pi, parts=parts, ok_se=ok_se), ok_se

DEC = 0; allok = True; ok_comm = ok_unique = ok_sum = ok_sq = ok_se_all = ok_m = True; ok_order = True
for (p, q) in SIGS:
    sq = [1] * p + [-1] * q; n = p + q
    for rep in range(2):
        idx = list(range(n)); rngC.shuffle(idx); m = rngC.randint(1, n // 2) if rep else n // 2
        planes = [(idx[2 * t], idx[2 * t + 1]) for t in range(m)]; cs = [F(t + 1) for t in range(m)]
        cs = [c * rngC.choice([1, -1]) for c in cs]
        info, ok_se = decompose_case(sq, planes, cs, rngC, 'sig')
        ok_se_all &= ok_se
        if info is None: allok = False; continue
        DEC += 1; L, A_, B, S = info['L'], info['A'], info['B'], info['S']
        parts = info['parts']; pieces = list(parts.values())
        ok_sum &= vsum(*pieces) == B
        ok_m &= len(pieces) == m and m <= n // 2
        ok_sq &= all(set(A_.mul(P_, P_)) <= {0} for P_ in pieces)
        ok_comm &= all(not A_.comm(P1, P2) for P1 in pieces for P2 in pieces)
        # the same through the engine's f table: [B_i, B_j] = sum f b_i b_j B_C = 0
        for P1 in pieces:
            for P2 in pieces:
                tot = {}
                for (Aa, Bb), (Cc, co) in L.f.items():
                    x = P1.get(L.gens[Aa]); y = P2.get(L.gens[Bb])
                    if x and y: tot[Cc] = tot.get(Cc, 0) + x * y * co
                ok_comm &= not any(tot.values())
        S2 = mm(S, S)
        ok_unique &= all(n - rank_exact(madd(S2, mscale(mid(n), nu), -1)) == 2 for nu in info['mult'] if nu != 0) and all(v == 1 for nu, v in info['mult'].items() if nu != 0)
        # the same pieces as the constructed terms (up to order), and the reverse order of the roots gives the same set
        ok_order &= sorted(sorted(t.items()) for t in info['terms']) == sorted(sorted(P_.items()) for P_ in pieces)
chk('bit==std', ok_se_all, 'in all %d signatures the operator of B from the engine\'s h table equals the plain-matrix operator sum B_ab L_ab (exact), for the %d bivectors built below' % (len(SIGS), DEC))
chk('bit', allok and DEC == 2 * len(SIGS), 'B = sum_k c_k (O e_i) ^ (O e_j) with O a product of four rational reflections of R^(p,q), disjoint planes, distinct squares: %d bivectors in %d signatures; from B alone the characteristic polynomial of S in nu = mu^2 has only rational roots and the spectral projectors of S^2 split S' % (DEC, len(SIGS)))
chk('bit', ok_sum and ok_m and ok_sq, 'the pieces B_i = S^-1(S Pi_i) satisfy sum B_i = B exactly, each B_i^2 is a scalar (bit-rule product: B_i is simple), and the number of pieces is m <= floor(n/2) for every case')
chk('bit', ok_comm, 'the pieces commute pairwise: [B_i, B_j] = 0 by the bit-rule product and through the engine\'s f table (every case)')
chk('bit', ok_unique and ok_order, 'distinct roots: dim ker (S^2 - nu_i) = 2 for each root (the planes are the only S-invariant planes on which S^2 is scalar, so no other splitting exists), and the pieces equal the constructed summands (the decomposition is unique)')
tline('C1')

# an order check, the isoclinic case, and the controls
rev = decompose_case([1, 1, 1, 1, -1, -1], [(0, 1), (2, 3)], [F(1), F(2)], rngC, 'ord')[0]
S_, mult_, Pi_ = spectral_split(rev['L'], rev['B'])
sets_equal = True
for order in (sorted(mult_), sorted(mult_, reverse=True)):
    got = []
    for nu in order:
        if nu == 0: continue
        got.append(sorted(solve_biv(rev['L'], mm(S_, Pi_[nu])).items()))
    sets_equal &= sorted(got) == sorted(sorted(t.items()) for t in rev['terms'])
chk('bit', sets_equal, 'Cl(4,2): the roots taken in increasing and in decreasing order give the same set of simple bivectors (the decomposition does not depend on the order)')

def isoclinic(sq, planes, rng, xs):
    n = len(sq); L = Lie(sq); A_ = BitAlg(sq); O = rand_orth(sq, rng); cols = [[O[r][i] for r in range(n)] for i in range(n)]
    terms = [wedge(cols[i], cols[j], n) for (i, j) in planes]; B = vsum(*terms)
    S = skew_engine(L, B); S2 = mm(S, S); co = qpoly(S); roots, rest = rat_roots([co[j] for j in range(n // 2 + 1)])
    nu = next(r for r in roots if roots.count(r) > 1); ker = n - rank_exact(madd(S2, mscale(mid(n), nu), -1))
    splits = [terms]
    for (al, be) in xs:
        # a vector of the 4-dimensional eigenspace: al * O e_i0 + be * O e_i2; the plane P = span(x, Sx) is S-invariant and orthogonal to its complement in the eigenspace
        x = [al * cols[planes[0][0]][r] + be * cols[planes[1][0]][r] for r in range(n)]
        Sx = [sum(S[r][c] * x[c] for c in range(n)) for r in range(n)]
        xx, yy = dotq(sq, x, x), dotq(sq, Sx, Sx)
        if xx == 0 or yy == 0: continue
        Pm = [[(x[r] * sq[c] * x[c]) / xx + (Sx[r] * sq[c] * Sx[c]) / yy for c in range(n)] for r in range(n)]        # eta-orthogonal projector on span(x, Sx)
        S1 = mm(S, Pm); B1 = solve_biv(L, S1)
        if B1 is None: continue
        B2 = vsum(B, vsc(B1, -1)); splits.append([B1, B2])
    return dict(L=L, A=A_, B=B, nu=nu, ker=ker, splits=splits)
iso_ok = True; iso_n = 0; iso_ker = True
for sq, planes, tagiso in (([1, 1, 1, 1], [(0, 1), (2, 3)], '(4,0)'), ([1, 1, -1, -1], [(0, 1), (2, 3)], '(2,2) elliptic pair'), ([1, 1, -1, -1], [(0, 2), (1, 3)], '(2,2) hyperbolic pair'), ([1] * 6, [(0, 1), (2, 3), (4, 5)][:2], '(6,0) two of three planes')):
    info = isoclinic(sq, planes, rngC, [(F(1), F(1)), (F(1), F(2)), (F(2), F(3))])
    sp = info['splits']; A_ = info['A']; L = info['L']
    good = [all(set(A_.mul(P_, P_)) <= {0} for P_ in s_) and not A_.comm(s_[0], s_[1]) and vsum(*s_) == info['B'] for s_ in sp]
    diff = len({tuple(sorted(tuple(sorted(P_.items())) for P_ in s_)) for s_ in sp})
    iso_ok &= all(good) and len(sp) >= 3 and diff == len(sp); iso_ker &= info['ker'] == 4; iso_n += len(sp)
chk('bit', iso_ok and iso_ker, 'isoclinic case (two planes with the same nu, kernel of S^2 - nu of dimension 4) in (4,0), (2,2) twice and (6,0): %d splittings into two commuting simple bivectors, all summing to B, all different (the constructed one and splittings through span(x, Sx) for three vectors x of the eigenspace): a family, not a unique decomposition' % iso_n)

# the controls on the decomposition
sqc = [1, 1, 1, 1]; Ac = BitAlg(sqc); b1 = {0b0011: F(1)}; b2 = {0b0110: F(1)}                         # e0e1 and e1e2 share e1
nc = Ac.comm(b1, b2)
Lc = Lie(sqc); tot = {}
for (Aa, Bb), (Cc, co) in Lc.f.items():
    x = b1.get(Lc.gens[Aa]); y = b2.get(Lc.gens[Bb])
    if x and y: tot[Cc] = tot.get(Cc, 0) + x * y * co
chk('bit' if fault('NONCOMM') else 'ctl', (not nc) if fault('NONCOMM') else (bool(nc) and any(tot.values())), 'two simple bivectors sharing a vector (e0e1 and e1e2) do not commute: the bit-rule commutator and the engine\'s f give a non-zero bivector, so their sum is not a decomposition of the kind studied (the sum is itself simple)')
mm1 = {n_: n_ // 2 + 1 for n_ in range(2, 7)}
chk('bit' if fault('MPLUS1') else 'ctl', all((2 * mm1[n_] <= n_) if fault('MPLUS1') else (2 * mm1[n_] > n_) for n_ in range(2, 7)), 'floor(n/2) + 1 commuting simple bivectors with disjoint non-degenerate planes need 2 (floor(n/2) + 1) > n dimensions, for every n = 2..6: at most floor(n/2) terms')
tline('C2')

# C3: the exhaustive table of Cl(p,q) with n = 4 and entries in {-1, 0, 1}, and the obstruction
def wform(X, Y):
    g = lambda Z, a, b: Z.get((1 << a) | (1 << b), 0)
    return g(X, 0, 1) * g(Y, 2, 3) + g(X, 2, 3) * g(Y, 0, 1) - g(X, 0, 2) * g(Y, 1, 3) - g(X, 1, 3) * g(Y, 0, 2) + g(X, 0, 3) * g(Y, 1, 2) + g(X, 1, 2) * g(Y, 0, 3)
def commutant(L, B):
    G = L.G; cols = []
    for A in range(G):
        col = [F(0)] * G
        for (Aa, Bb), (Cc, co) in L.f.items():
            if Aa == A and L.gens[Bb] in B: col[Cc] += co * B[L.gens[Bb]]
        cols.append(col)
    rows = [[cols[A][C] for A in range(G)] for C in range(G)]
    return [{L.gens[A]: w[A] for A in range(G) if w[A]} for w in nullspace(rows, G)]
def split_exists(L, B):
    """n = 4: does B = B1 + B2 exist with B1, B2 simple and commuting (over R)? exact for a commutant of dimension 2; returns (verdict, d)"""
    U = commutant(L, B); d = len(U); W = wform(B, B)
    if W == 0: return None, d
    if d != 2: return None, d
    u, v = U; Quu, Quv, Qvv = wform(u, u), wform(u, v), wform(v, v); Lu, Lv = wform(u, B), wform(v, B)
    disc = Quv * Quv - Quu * Qvv
    if disc < 0: return False, d
    if Quu == Quv == Qvv == 0: return (Lu != 0 or Lv != 0), d
    if disc > 0: return (Lu != 0 or Lv != 0), d
    # disc = 0: a single rational direction r with Q(r) = 0
    r = (-Quv, Quu) if Quu != 0 else (F(1), F(0))
    return (Lu * r[0] + Lv * r[1] != 0), d
def iso_split(L, sq, B, S):
    """isoclinic, S^2 = nu on the whole space (n = 4): split through span(x, Sx) for a basis vector x; True if two commuting simple bivectors are found"""
    n = L.N; A_ = BitAlg(sq)
    for r in range(n):
        x = [F(int(i == r)) for i in range(n)]; Sx = [sum(S[a][c] * x[c] for c in range(n)) for a in range(n)]
        xx, yy = dotq(sq, x, x), dotq(sq, Sx, Sx)
        if xx == 0 or yy == 0: continue
        Pm = [[(x[a] * sq[c] * x[c]) / xx + (Sx[a] * sq[c] * Sx[c]) / yy for c in range(n)] for a in range(n)]
        B1 = solve_biv(L, mm(S, Pm))
        if B1 is None: continue
        B2 = vsum(B, vsc(B1, -1))
        if set(A_.mul(B1, B1)) <= {0} and set(A_.mul(B2, B2)) <= {0} and not A_.comm(B1, B2): return True
    return False
tab = {}
KEYS = ['zero', 'simple', 'real distinct', 'complex', 'repeated', 'split', 'no split', 'isoclinic', 'isoclinic split', 'not classified']
for (p, q) in ((4, 0), (3, 1), (2, 2), (1, 3), (0, 4)):
    sq = [1] * p + [-1] * q; L = Lie(sq); cnt = {k: 0 for k in KEYS}; consistent = True
    for ent in itertools.product((-1, 0, 1), repeat=6):
        B = {m: F(e) for m, e in zip([(1 << i) | (1 << j) for i in range(4) for j in range(i + 1, 4)], ent) if e}
        if not B: cnt['zero'] += 1; continue
        if wform(B, B) == 0: cnt['simple'] += 1; continue
        S = skew_engine(L, B); co = qpoly(S); disc = co[1] * co[1] - 4 * co[0] * co[2]
        cls = 'complex' if disc < 0 else ('real distinct' if disc > 0 else 'repeated'); cnt[cls] += 1
        if cls == 'repeated' and mm(S, S) == mscale(mid(4), -co[1] / 2):
            cnt['isoclinic'] += 1; ok_iso = iso_split(L, sq, B, S); cnt['isoclinic split'] += ok_iso; consistent &= ok_iso; continue
        verdict, d = split_exists(L, B)
        if verdict is None: cnt['not classified'] += 1; continue
        cnt['split' if verdict else 'no split'] += 1
        if cls == 'complex': consistent &= verdict is False
        elif cls == 'repeated': consistent &= verdict is False
        elif co[2] != 0: consistent &= verdict is True
        else: consistent &= verdict is not None
    tab[(p, q)] = (cnt, consistent)
c22 = tab[(2, 2)][0]
show = lambda c: {k: v for k, v in c.items() if v}
chk('bit', all(tab[s_][1] for s_ in tab) and all(tab[s_][0]['complex'] == 0 and tab[s_][0]['no split'] == 0 and tab[s_][0]['not classified'] == 0 for s_ in tab if s_ != (2, 2)) and c22['complex'] > 0 and c22['no split'] > 0,
    'Cl(p,q), n = 4, the 3^6 - 1 = 728 non-zero bivectors with entries in {-1, 0, 1}, classified exactly by the roots of q(nu) = nu^2 + c1 nu + c2 and, for a commutant of dimension 2, by solving B = B1 + B2 (B1 in the commutant of B, B1 ^ B1 = 0, (B - B1) ^ (B - B1) = 0); a repeated root with S^2 = nu is split through span(x, Sx). (4,0): %s; (0,4): %s; (3,1): %s; (1,3): %s' % (show(tab[(4, 0)][0]), show(tab[(0, 4)][0]), show(tab[(3, 1)][0]), show(tab[(1, 3)][0])))
chk('bit', c22['complex'] + c22['repeated'] - c22['isoclinic'] - c22['not classified'] == c22['no split'] and c22['real distinct'] == c22['split'],
    'Cl(2,2), the same 728 bivectors: %s. Every bivector with non-real roots (%d) and every bivector with a repeated root and S^2 not scalar (%d, S not semisimple) has no splitting into two commuting simple bivectors over the reals; the %d with real distinct roots split; the %d isoclinic ones split (verified through span(x, Sx))' % (show(c22), c22['complex'], c22['no split'] - c22['complex'], c22['split'], c22['isoclinic split']))
# the Riesz example and a Jordan example
sq22 = [1, 1, -1, -1]; L22 = Lie(sq22); A22 = BitAlg(sq22)
BR = {0b0011: F(1, 2), 0b1001: F(1, 2), 0b0110: F(-1, 2), 0b1100: F(-1, 2)}                          # e0e1 + e0e3 - e1e2 - e2e3, halved
S = skew_engine(L22, BR); co = qpoly(S); disc = co[1] * co[1] - 4 * co[0] * co[2]
verdict, d = split_exists(L22, BR)
comp_ok = disc < 0 and verdict is False and S == skew_std(sq22, BR)
chk('bit' if fault('QUADRUPLE') else 'ctl', (verdict is not False) if fault('QUADRUPLE') else comp_ok,
    'Cl(2,2), B = (e0e1 + e0e3 - e1e2 - e2e3)/2 (the example with squares of the pieces +-i/2): q(nu) = nu^2 + (%s) nu + (%s) has discriminant %s < 0, so S has the eigenvalue quadruple +-a +-ib; the commutant of B has dimension %d and the quadratic form B1 ^ B1 on it is definite: no splitting into commuting simple bivectors over the reals exists (over C the pieces exist)' % (co[1], co[2], disc, d))
# a Jordan example: search the table for a bivector with a repeated root and no splitting
jordan = None
for ent in itertools.product((-1, 0, 1), repeat=6):
    B = {m: F(e) for m, e in zip([(1 << i) | (1 << j) for i in range(4) for j in range(i + 1, 4)], ent) if e}
    if not B or wform(B, B) == 0: continue
    S = skew_engine(L22, B); co = qpoly(S); disc = co[1] * co[1] - 4 * co[0] * co[2]
    if disc == 0 and co[2] != 0:
        nu = -co[1] / 2; S2 = mm(S, S)
        if S2 != mscale(mid(4), nu):
            v_, d_ = split_exists(L22, B)
            if v_ is False: jordan = (B, nu, d_); break
chk('bit', jordan is not None, 'Cl(2,2): a bivector with a repeated root nu = %s whose S^2 is not scalar (S is not semisimple: a nilpotent part commuting with a semisimple part) and which has no splitting over R: %s' % (jordan[1] if jordan else None, sorted(jordan[0].items()) if jordan else None))
tline('C3')

# [std] the spectra of random bivectors in every signature, numpy
rngN = np.random.default_rng(76); sum_tab = {}
okstd = True; okdef = True
for (p, q) in SIGS:
    sq = [1] * p + [-1] * q; n = p + q; eta = np.diag(sq).astype(float); ncx = 0; N = 300
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    for _ in range(N):
        Bv = {(1 << i) | (1 << j): int(rngN.integers(-5, 6)) for (i, j) in pairs}
        S = np.zeros((n, n))
        for m, co in Bv.items():
            a, b = [i for i in range(n) if (m >> i) & 1]; S[a, b] += co * sq[b]; S[b, a] -= co * sq[a]
        ev = np.linalg.eigvals(S); nu = ev ** 2
        cx = bool(np.any(np.abs(nu.imag) > 1e-7)); ncx += cx
        if q == 0 or p == 0:
            # definite: S is (up to sign) skew-symmetric; the real Schur form is block diagonal with 2 x 2 blocks and the pieces Z_k T_k Z_k^T sum to S
            T_, Z_ = sla.schur(S, output='real'); okdef &= np.abs(T_ + T_.T).max() < 1e-9 and np.allclose(Z_ @ T_ @ Z_.T, S, atol=1e-9)
            i_ = 0; pieces = []
            while i_ < n - 1:
                if abs(T_[i_, i_ + 1]) > 1e-9: pieces.append(Z_[:, i_:i_ + 2] @ T_[i_:i_ + 2, i_:i_ + 2] @ Z_[:, i_:i_ + 2].T); i_ += 2
                else: i_ += 1
            okdef &= np.abs(sum(pieces) - S).max() < 1e-8 and len(pieces) <= n // 2 and all(np.abs(a_ @ b_).max() < 1e-8 for ia, a_ in enumerate(pieces) for ib, b_ in enumerate(pieces) if ia != ib)
    sum_tab[(p, q)] = ncx
nc_sig = {s_: v for s_, v in sum_tab.items() if v}
chk('std', okdef and set(nc_sig) <= {s_ for s_ in SIGS if min(s_) >= 2} and (2, 2) in nc_sig,
    'numpy, 300 random integer bivectors (entries -5..5) per signature, n <= 6: in the definite signatures the real Schur form of S is block diagonal with at most floor(n/2) blocks of size 2, their pieces sum to S and multiply to 0 (residual < 1e-8); a non-real mu^2 occurs only for min(p,q) >= 2, in the sampled signatures %s (counts out of 300)' % nc_sig)
chk('std', all(sum_tab[s_] == 0 for s_ in SIGS if min(s_) <= 1), 'in the %d signatures with min(p,q) <= 1 (Euclidean and Lorentzian, n <= 6) no sampled bivector has a non-real mu^2: a quadruple needs a (2,2) subspace (recalled)' % sum(1 for s_ in SIGS if min(s_) <= 1))
tline('C')
finish('KINMECH' + ('-' + FAULT if FAULT else ''))
