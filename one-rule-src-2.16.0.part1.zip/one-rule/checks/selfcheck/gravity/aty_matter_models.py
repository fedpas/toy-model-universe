#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""ATY-MATTER.  The 4-manifolds of Atiyah, Manton and Schroers, "Geometric models of matter" (electron = Taub-NUT, proton = Atiyah-Hitchin,
neutron = CP^2 with the Fubini-Study metric, neutrino = the round S^4; baryon number = signature, electric charge = minus the self-intersection
of the surface at infinity): their intersection forms and characteristic numbers from the frame lattices of the cells, and Taub-NUT, CP^2 and
S^4 on the gravity engine in the Riemannian cell (+,+,+,+).
    python3 aty_matter_models.py                 run all checks
    python3 aty_matter_models.py --fault NAME    run with one wrong version put in (the run must end with exit code 1); the names are in FAULTS

 Part L (no engine object; exact integers and Fractions).
  [bit]  the frame lattice of the cell Cl(p,q) (Gram matrix = scalar part of the symmetrised products of the generators, bmul of the bit rule)
         and the clock sum over its 2^n labels, i^w(a) with w(a) = the sum of the squares of the generators in a (mod 4).
  [std]  the forms as plain integer matrices: S^4 (empty), CP^2 (1), -CP^2 (-1), S^2 x S^2 (H), CP^2 # -CP^2 (I_{1,1}), K3 with its complex
         orientation (3H + 2(-E8), recalled), the cell (1,8) (CP^2 blown up at 8 points); the E8 Cartan matrix and its even-coordinate roots
         (textbook); signature by exact congruence diagonalisation and by numpy eigenvalues; the lattice Gauss sum over L/2L with x.x mod 4;
         characteristic vectors by enumeration; Wu's condition c.c = 2 chi + 3 sigma for an almost complex structure (recalled);
         the double cover S^2 x S^2 -> CP^2 on the lattices (pull-back of the line class: h -> x + y).
 Part G (the engine; exact Fractions; 2-jets of the coframe at rational points).
  [bit]  omega = A3 closed form, R = d omega + 1/4 [omega, omega], E_a(c), with Lie(+,+,+,+); the duality J = multiplication by the pseudoscalar
         on the six bivector labels (g2_weyl.duality_J); d and the wedge of the engine's forms for the closed 2-forms; the Jordan type of a
         3 x 3 Weyl block read by g2_weyl.petrov.
  [std]  the Christoffel route on g = e^T e (exact, never the engine); a float route from the closed-form metrics (nested central differences,
         never the jets); scipy quad for volumes and curvature integrals; the Hodge star of the orientation e0 e1 e2 e3 from permutation signs.
  Coframes.  Taub-NUT in Gibbons-Hawking form, coordinates (tau, x, y, z): g = V dx.dx + (dtau + w)^2 / V, V = 1 + m/r,
         w = m (z/r)(x dy - y dx)/(x^2 + y^2) = m cos(theta) dphi (dw = *dV), e0 = (dtau + w)/sqrt V, e^i = sqrt V dx^i, at 8 points where
         r and sqrt V are rational (m = 2, the paper's units, and m = 1/2, 3); the round S^4, e^a = 2 dx^a/(1 + |x|^2), at 3 points;
         CP^2 (Fubini-Study, the paper's (4.1)), the unitary coframe theta = (dz - z (zbar.dz)/(s (s + 1)))/s, s = sqrt(1 + |z|^2),
         e0 + i e1 = theta_1, e2 + i e3 = theta_2 (z1 = x0 + i x1, z2 = x2 + i x3), at 3 points where s is rational.
 Controls (each a --fault option too): the Gauss sum read mod 2; van der Blij on non-characteristic vectors; S^2 x S^2 replaced by I_{1,1};
  CP^2 reversed; a wrong k in the cell (1,8); w with the factor 7/6; V = 1 + m/r^2; the self-dual combinations as hyperkahler forms; the
  harmonic form with h = (r + m)/r; a random frame's Weyl block; the Einstein form with c = 0; the CP^2 coframe without its correction term;
  the Hodge star of the opposite orientation; rule B of the paper as the OCR gives it.  Not wrong versions (checked as such): w -> -w (the orientation;
  the curvature changes side).
 Scope: the curvature statements are checked at the listed rational points only (exact); the integrals are floats (scipy quad, relative
  tolerance 1e-9) of closed forms that the points match exactly; the identification of particles with manifolds is the paper's, not checked."""
import sys, os, time, itertools, math, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from g2_weyl import duality_J, J_matrix, petrov, QI, PAIRS4, weyl_parts, engine_frame_riemann, std_frame_riemann
import g2_kerr as KJ
import numpy as np
from scipy import integrate

FAULTS = {
    'gauss-mod2': 'the clock sum and the lattice Gauss sums read with x.x mod 2 (a sign) instead of mod 4',
    'vdb-noncharacteristic': 'van der Blij tested on vectors that are not characteristic',
    's2s2-as-I11': 'the form of S^2 x S^2 replaced by the odd form I_{1,1} of CP^2 # -CP^2',
    'cp2-reversed': 'the neutron CP^2 taken with the reversed orientation, form (-1)',
    'e8-wrong-k': 'k = (1; -1, ..., -1) in place of (3; -1, ..., -1) in the cell (1,8)',
    'tn-omega': 'Taub-NUT with w = (7/6) m cos(theta) dphi (then dw is not *dV)',
    'tn-vpow': 'Taub-NUT with V = 1 + m/r^2 (not harmonic) at the point with r = 1',
    'hk-sd': 'the self-dual combinations e0 e_i + (1/2) eps e e taken as the hyperkahler forms',
    'harm-h': 'the harmonic form of Taub-NUT built with h = (r + m)/r in place of r/(r + m)',
    'petrov-random': 'the Weyl block of a random Riemannian frame in place of the Taub-NUT block',
    'einstein-c0': 'the Einstein form of S^4 and CP^2 read with c = 0',
    'fs-frame': 'the CP^2 coframe without its correction term, theta = dz/s (the metric |dz|^2/(1 + |z|^2))',
    'hodge-sign': 'the Hodge star of the opposite orientation',
    'rule-b-ocr': 'rule B of the paper read as the OCR gives it, (X\')^2 = 4 X^2, in place of the printed (X\')^2 = X^2/2',
}
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1]
    if FAULT not in FAULTS: raise SystemExit('unknown fault %s; known: %s' % (FAULT, ', '.join(sorted(FAULTS))))
    print('FAULT PUT IN: %s (%s)' % (FAULT, FAULTS[FAULT]), flush=True)

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
PI = math.pi

# ================================================================================================ Part L helpers (exact integers)
def gi_mul(a, b): return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])
def gi_pow(z, k):
    r = (1, 0)
    for _ in range(k): r = gi_mul(r, z)
    return r
def gauss_target(n, sig):
    """2^(n/2) zeta_8^sig as a Gaussian integer: 2^((n - |sig|)/2) (1 +- i)^|sig|"""
    assert (n - abs(sig)) % 2 == 0
    t = gi_pow((1, 1) if sig >= 0 else (1, -1), abs(sig)); f = 2 ** ((n - abs(sig)) // 2)
    return (t[0] * f, t[1] * f)
MOD2 = (FAULT == 'gauss-mod2')
def power_i(w, mod2=None):
    mod2 = MOD2 if mod2 is None else mod2
    return (2 * (w % 2)) if mod2 else (w % 4)
def counts_to_gi(cnt): return (cnt[0] - cnt[2], cnt[1] - cnt[3])
def bit_gram(p, q):
    """[bit] the frame lattice of Cl(p,q): G_ij = scalar part of (e_i e_j + e_j e_i)/2 from the bit rule"""
    sq = [1] * p + [-1] * q; n = p + q; G = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            m1, s1 = bmul(1 << i, 1 << j, sq); m2, s2 = bmul(1 << j, 1 << i, sq)
            assert m1 == m2
            G[i][j] = (s1 + s2) // 2 if m1 == 0 else 0
            assert m1 == 0 or s1 + s2 == 0
    return G
def clock_sum_bit(p, q, mod2=None):
    """[bit] the clock sum over the 2^n labels of Cl(p,q): sum_a i^w(a), w(a) = sum of the squares of the generators in a"""
    sq = [1] * p + [-1] * q; n = p + q; sqs = [bmul(1 << j, 1 << j, sq)[1] for j in range(n)]; cnt = [0, 0, 0, 0]
    for a in range(1 << n): cnt[power_i(sum(sqs[j] for j in range(n) if a >> j & 1), mod2)] += 1
    return counts_to_gi(cnt)
def qform(G, x): return sum(G[i][j] * x[i] * x[j] for i in range(len(x)) for j in range(len(x)))
def bil(G, x, y): return sum(G[i][j] * x[i] * y[j] for i in range(len(x)) for j in range(len(y)))
def gauss_lattice(G, mod2=None):
    """[std] sum over x in {0,1}^n of i^(x.G.x)"""
    n = len(G); cnt = [0, 0, 0, 0]
    for bits in itertools.product((0, 1), repeat=n): cnt[power_i(qform(G, bits), mod2)] += 1
    return counts_to_gi(cnt)
def osum(*Gs):
    n = sum(len(G) for G in Gs); M = [[0] * n for _ in range(n)]; o = 0
    for G in Gs:
        for i in range(len(G)):
            for j in range(len(G)): M[o + i][o + j] = G[i][j]
        o += len(G)
    return M
def neg(G): return [[-x for x in row] for row in G]
def diag(*d): return [[d[i] if i == j else 0 for j in range(len(d))] for i in range(len(d))]
def cong_diag(G):
    """[std] exact diagonalisation by congruence over Q (Sylvester): returns the diagonal"""
    A = [[F(x) for x in row] for row in G]; n = len(A); d = []
    for k in range(n):
        if A[k][k] == 0:
            j = next((j for j in range(k + 1, n) if A[j][j] != 0), None)
            if j is not None:
                A[k], A[j] = A[j], A[k]
                for row in A: row[k], row[j] = row[j], row[k]
            else:
                j = next((j for j in range(k + 1, n) if A[k][j] != 0), None)
                if j is not None:
                    for c in range(n): A[k][c] += A[j][c]
                    for r in range(n): A[r][k] += A[r][j]
        piv = A[k][k]; d.append(piv)
        if piv == 0: continue
        for i in range(k + 1, n):
            f = A[i][k] / piv
            if f:
                for c in range(n): A[i][c] -= f * A[k][c]
                for r in range(n): A[r][i] -= f * A[r][k]
    return d
def signature_exact(G):
    d = cong_diag(G); return sum(1 for x in d if x > 0) - sum(1 for x in d if x < 0), sum(1 for x in d if x == 0)
def signature_np(G):
    if not G: return 0
    ev = np.linalg.eigvalsh(np.array(G, float)); return int((ev > 1e-9).sum() - (ev < -1e-9).sum())
def det_exact(G):
    A = [[F(x) for x in row] for row in G]; n = len(A); det = F(1)
    for k in range(n):
        p = next((i for i in range(k, n) if A[i][k] != 0), None)
        if p is None: return F(0)
        if p != k: A[k], A[p] = A[p], A[k]; det = -det
        det *= A[k][k]
        for i in range(k + 1, n):
            f = A[i][k] / A[k][k]
            if f:
                for c in range(k, n): A[i][c] -= f * A[k][c]
    return det
def is_char(G, c):
    """c is characteristic: c.x = x.x mod 2 for every x (enough on a basis: (G c)_i = G_ii mod 2)"""
    return all((sum(G[i][j] * c[j] for j in range(len(c))) - G[i][i]) % 2 == 0 for i in range(len(c)))
def even(G): return all(G[i][i] % 2 == 0 for i in range(len(G)))

H2 = [[0, 1], [1, 0]]
E8C = [[2, 0, -1, 0, 0, 0, 0, 0], [0, 2, 0, -1, 0, 0, 0, 0], [-1, 0, 2, -1, 0, 0, 0, 0], [0, -1, -1, 2, -1, 0, 0, 0],
       [0, 0, 0, -1, 2, -1, 0, 0], [0, 0, 0, 0, -1, 2, -1, 0], [0, 0, 0, 0, 0, -1, 2, -1], [0, 0, 0, 0, 0, 0, -1, 2]]        # Bourbaki numbering (textbook)

def part_L():
    head('L1. [bit] the frame lattices of the cells and the clock sum; [std] the lattice Gauss sum and the closed form 2^(n/2) zeta_8^(p - q)')
    cells = [(0, 0), (1, 0), (0, 1), (1, 1), (2, 0), (0, 2), (3, 1), (1, 3), (1, 8), (4, 0)]
    okG = okS = okT = True
    for (p, q) in cells:
        G = bit_gram(p, q); okG &= (G == diag(*([1] * p + [-1] * q)))
        cs = clock_sum_bit(p, q); gl = gauss_lattice(G); tg = gauss_target(p + q, p - q)
        okS &= (cs == gl); okT &= (cs == tg)
    chk('bit==std', okG, 'the frame lattice of Cl(p,q) from the bit rule is diag(+1 x p, -1 x q) = I_{p,q} for the 10 cells (0,0), (1,0), (0,1), (1,1), (2,0), (0,2), (3,1), (1,3), (1,8), (4,0)')
    chk('bit==std', okS, 'the clock sum over the 2^n labels (exponent w(a) = sum of the squares in a) equals the lattice Gauss sum of I_{p,q} over L/2L with x.x mod 4, for the 10 cells')
    chk('bit==std', okT, 'both equal 2^(n/2) zeta_8^(p - q) exactly (Gaussian integers): the phase of the clock is the signature p - q mod 8 of I_{p,q}')
    ctl_cs = clock_sum_bit(1, 0, mod2=True)
    chk('ctl', ctl_cs != gauss_target(1, 1) and clock_sum_bit(1, 8, mod2=True)[1] == 0,
        'control: with x.x mod 2 (a sign) the sum of the cell (1,0) is %s, not 1 + i, and every sum is real: the phase, hence sigma mod 8, is lost' % (ctl_cs,))

    head('L2. [std] the forms of the paper\'s manifolds: rank, determinant, parity, signature (exact and numpy), Euler number 2 + b2 (closed, simply connected; recalled)')
    S2S2 = diag(1, -1) if FAULT == 's2s2-as-I11' else H2
    CP2 = [[-1]] if FAULT == 'cp2-reversed' else [[1]]
    K3 = osum(H2, H2, H2, neg(E8C), neg(E8C))
    forms = [('S4 (neutrino)', [], 0, 2, False), ('CP2 (neutron)', CP2, 1, 3, False), ('-CP2 (antineutron)', [[-1]], -1, 3, False),
             ('S2xS2', S2S2, 0, 4, True), ('CP2#-CP2', diag(1, -1), 0, 4, False), ('K3 (complex orientation)', K3, -16, 24, True),
             ('cell (1,8) = CP2 # 8(-CP2)', bit_gram(1, 8), -7, 11, False)]
    okall = True; rows = []
    for name, G, sig_want, chi_want, ev_want in forms:
        n = len(G); s_ex, nz = signature_exact(G) if G else (0, 0); s_np = signature_np(G); dt = det_exact(G) if G else F(1)
        chi = 2 + n; ev = even(G) if G else True
        ok = (s_ex == s_np == sig_want and nz == 0 and abs(dt) == 1 and chi == chi_want and (ev == ev_want or n == 0))
        okall &= ok; rows.append('%s: b2 = %d, det = %s, %s, sigma = %d, chi = %d' % (name, n, dt, 'even' if ev else 'odd', s_ex, chi))
    for r in rows: print('    ' + r)
    chk('std', okall, 'unimodular (det +-1), signatures 0, 1, -1, 0, 0, -16, -7 (exact congruence = numpy), Euler numbers 2, 3, 3, 4, 4, 24, 11; S2xS2 and K3 even, the others odd')
    chk('std', signature_exact(H2)[0] == signature_exact(diag(1, -1))[0] and even(H2) and not even(diag(1, -1)),
        'S2xS2 (H) and CP2 # -CP2 (I_{1,1}) have the same rank, signature 0 and Euler number 4; only the parity (a characteristic vector 0 or not) tells them apart')
    okg = True
    for name, G, sig_want, chi_want, ev_want in forms:
        if len(G) <= 10: okg &= (gauss_lattice(G) == gauss_target(len(G), signature_exact(G)[0] if G else 0))
    gH, gE = gauss_lattice(H2), gauss_lattice(neg(E8C)); gHE = gauss_lattice(osum(H2, neg(E8C)))
    gK3 = gi_mul(gi_mul(gi_mul(gH, gH), gi_mul(gH, gE)), gE)
    chk('std', okg and gHE == gi_mul(gH, gE) and gK3 == gauss_target(22, -16) and gauss_lattice(E8C) == gauss_target(8, 8),
        'Gauss sums over L/2L: 2^(n/2) zeta_8^sigma for the forms above of rank <= 10 and for E8 (16); multiplicative on H + (-E8) (rank 10, direct); K3 = H^3 (-E8)^2 gives 2^11 = 2^11 zeta_8^-16')

    head('L3. [std] characteristic vectors: van der Blij (c.c = sigma mod 8) and Wu\'s condition c.c = 2 chi + 3 sigma (recalled) by enumeration')
    small = [('CP2', CP2), ('-CP2', [[-1]]), ('S2xS2', S2S2), ('CP2#-CP2', diag(1, -1))]
    okv = True; nchar = 0
    for name, G in small:
        sig = signature_exact(G)[0]; n = len(G)
        for c in itertools.product(range(-7, 8), repeat=n):
            ch = is_char(G, c)
            if FAULT == 'vdb-noncharacteristic': ch = not ch
            if ch: nchar += 1; okv &= ((qform(G, c) - sig) % 8 == 0)
    chk('std', okv, 'every characteristic vector with entries in -7..7 of CP2, -CP2, S2xS2, CP2#-CP2 has c.c = sigma mod 8 (%d vectors)' % nchar)
    k18 = [1] + [-1] * 8 if FAULT == 'e8-wrong-k' else [3] + [-1] * 8
    G18 = bit_gram(1, 8); okk = all(G18[i][j] == 0 for i in range(9) for j in range(9) if i != j); cnt = 0
    for t in itertools.product((-1, 1, 3), repeat=9):                   # odd entries: characteristic for the diagonal form
        cnt += 1; okk &= ((sum(G18[i][i] * t[i] * t[i] for i in range(9)) - (-7)) % 8 == 0)
    chk('std', okk and is_char(K3, [0] * 22) and qform(K3, [0] * 22) % 8 == (-16) % 8,
        'cell (1,8): all %d vectors with entries in {-1, 1, 3} (odd, so characteristic) have c.c = -7 mod 8; K3 is even, so c = 0 is characteristic and 0 = -16 mod 8' % cnt)
    ctl = [((qform([[1]], [2]) - 1) % 8 != 0), ((qform(H2, (1, 1)) - 0) % 8 != 0), ((qform(K3, [1, 1] + [0] * 20) + 16) % 8 != 0)]
    chk('ctl', all(ctl) and not is_char([[1]], [2]) and not is_char(H2, (1, 1)), 'control: non-characteristic vectors break it: c = 2 in (1) (4), c = (1,1) in H (2), c = (1,1,0..) in K3 (2)')
    def wu(G, chi, sig, box=10):
        n = len(G); target = 2 * chi + 3 * sig
        if n == 0: return [] if target != 0 else [()]
        return [c for c in itertools.product(range(-box, box + 1), repeat=n) if is_char(G, c) and qform(G, c) == target]
    w_cp2 = wu(CP2, 3, signature_exact(CP2)[0]); w_m = wu([[-1]], 3, -1); w_s4 = wu([], 2, 0); w_s2 = wu(S2S2, 4, 0); w_11 = wu(diag(1, -1), 4, 0)
    chk('std', sorted(w_cp2) == [(-3,), (3,)], 'CP2 with the form (1): c = +-3 (the k = 3h of GOS-005 at n = 0) are the characteristic classes with c.c = 9 = 2 chi + 3 sigma: an almost complex structure is allowed')
    chk('std', w_m == [] and w_s4 == [], '-CP2 (form (-1)): c.c = 3 is needed and c.c <= 0 on a negative definite form: none; S4: only c = 0, and 2 chi +- 3 sigma = 4: none in either orientation')
    chk('std', (2, 2) in w_s2 and (-2, -2) in w_s2 and (3, 1) in w_11 and qform(K3, [0] * 22) == 2 * 24 + 3 * (-16),
        'S2xS2: c = +-(2,2), c.c = 8; CP2#-CP2: c = (3,1), c.c = 8; K3 (complex orientation): c = 0, 0 = 2 x 24 + 3 x (-16)')
    okdp = True
    for n in range(0, 10):
        k = [3] + [-1] * n; G = bit_gram(1, n); chi = 3 + n; sig = 1 - n
        okdp &= is_char(G, k) and qform(G, k) == 9 - n == 2 * chi + 3 * sig and (qform(G, k) - sig) % 8 == 0
    chk('bit', okdp, 'cells (1,n), n = 0..9: k = (3; -1, ..., -1) is characteristic with k.k = 9 - n = 2 chi + 3 sigma (chi = 3 + n, sigma = 1 - n) = sigma mod 8: GOS-005\'s k is c1 of CP2 blown up at n points')

    head('L4. [bit] E8 inside the cell (1,8): I_{1,8} = Z k + k^perp with k^perp = -E8; [std] the textbook E8')
    k = k18; kk = qform(G18, k)
    al = [[1, -1, -1, -1, 0, 0, 0, 0, 0]] + [[0] * i + [1, -1] + [0] * (8 - i - 1) for i in range(1, 8)]
    perp = all(bil(G18, k, a) == 0 for a in al); Ga = [[bil(G18, a, b) for b in al] for a in al]
    basis9 = [[1 if i == j else 0 for i in range(9)] for j in range(9)]
    split = (abs(kk) == 1) and all(bil(G18, k, [xi - bil(G18, k, eb) * kk * ki for xi, ki in zip(eb, k)]) == 0 for eb in basis9)
    roots = []
    def rec(prefix, rem_sq, rem_sum, left):                  # x1..x8 with sum of squares rem_sq and sum rem_sum
        b = math.isqrt(rem_sq)
        for v in range(-b, b + 1):
            rs, rsum = rem_sq - v * v, rem_sum - v
            if left == 1:
                if rs == 0 and rsum == 0: roots.append(tuple(prefix + [v]))
            elif rsum * rsum <= rs * (left - 1): rec(prefix + [v], rs, rsum, left - 1)
    if kk == 1 and k[0] == 3:
        for x0 in range(-4, 5): rec([x0], x0 * x0 + 2, -3 * x0, 8)     # x.x = -2 and k.x = 0 force |x0| <= 4 (Cauchy-Schwarz)
    dperp = det_exact(Ga)
    chk('bit', kk == 1 and perp and split and dperp == 1 and all(Ga[i][i] == -2 for i in range(8)) and len(roots) == 240,
        'k = (%d; -1^8) has k.k = %s; the 8 vectors h - e1 - e2 - e3, e_i - e_(i+1) are orthogonal to k with norm -2, Gram determinant %s; x - (k.x) k lies in k^perp for every basis x (the splitting); k^perp has %d vectors of norm -2' % (k[0], kk, dperp, len(roots)))
    half = F(1, 2)
    sr = [[half, -half, -half, -half, -half, -half, -half, half], [1, 1, 0, 0, 0, 0, 0, 0], [-1, 1, 0, 0, 0, 0, 0, 0], [0, -1, 1, 0, 0, 0, 0, 0],
          [0, 0, -1, 1, 0, 0, 0, 0], [0, 0, 0, -1, 1, 0, 0, 0], [0, 0, 0, 0, -1, 1, 0, 0], [0, 0, 0, 0, 0, -1, 1, 0]]
    Gs = [[sum(F(a[i]) * F(b[i]) for i in range(8)) for b in sr] for a in sr]
    R240 = [tuple(F(s1 if i == a else (s2 if i == b else 0)) for i in range(8)) for a in range(8) for b in range(a + 1, 8) for s1 in (1, -1) for s2 in (1, -1)]
    R240 += [tuple(F(s, 2) for s in signs) for signs in itertools.product((1, -1), repeat=8) if signs.count(-1) % 2 == 0]
    Sinv = det_inv([[F(x) for x in row] for row in sr])[1]
    integral = all(all((sum(v[i] * Sinv[i][j] for i in range(8))).denominator == 1 for j in range(8)) for v in R240)
    chk('std', Gs == [[F(x) for x in row] for row in E8C] and len(R240) == 240 and integral and det_exact(E8C) == 1 and signature_np(E8C) == 8 and even(E8C),
        'textbook E8: the simple roots in even coordinates have Gram = the Bourbaki Cartan matrix, det 1, even, positive definite; 112 + 128 = 240 roots, all integral in the root basis')
    perm = [None] * 8
    def match(i, used):
        if i == 8: return True
        for j in range(8):
            if j in used: continue
            if all(Ga[j][perm[t]] == -E8C[i][t] for t in range(i)) and Ga[j][j] == -E8C[i][i]:
                perm[i] = j
                if match(i + 1, used | {j}): return True
        return False
    chk('bit==std', match(0, set()), 'the Gram matrix of the 8 roots of k^perp is minus the Bourbaki Cartan matrix of E8 after relabelling (%s): I_{1,8} = (1) + (-E8)' % perm)

    head('L5. [bit] the surfaces at infinity and the cores on the lattice of the cell (1,0) (CP2); [std] the double cover S2xS2 -> CP2 on the lattice H')
    h = [1]; G10 = bit_gram(1, 0)
    line = qform(G10, h); conic = qform(G10, [2]); k3h = [3]
    genus = lambda d: 1 + (d * d - 3 * d) // 2
    chk('bit', line == 1 and conic == 4 and is_char(G10, k3h) and genus(1) == 0 and genus(2) == 0,
        'CP2 = Taub-NUT + the line at infinity: X = h, X.X = 1, charge -X.X = -1 (electron); CP2 = AH + RP2 with the core conic 2h, (2h).(2h) = 4, the form (4) on the image of H2_c(AH) has signature 1 (proton); adjunction with c1 = 3h gives genus 0 to both')
    x, y = (1, 0), (0, 1); pull = lambda a: (a, a)                          # pi^* (a h) = a (x + y)
    D, Dp = (1, 1), (1, -1)
    okpb = all(qform(H2, pull(a)) * 1 == 2 * qform(G10, [a]) for a in range(-3, 4))
    chk('std', okpb and qform(H2, D) == 2 and qform(H2, Dp) == -2 and bil(H2, D, Dp) == 0,
        'S2xS2 -> CP2 (symmetric square, degree 2): pi*(h) = x + y and pi*a.pi*b = 2 a.b; the diagonal D = x + y has D.D = 2, the antidiagonal D\' = x - y has D\'.D\' = -2, D.D\' = 0 (the paper\'s (A.3), (A.4))')
    rp2 = F(qform(H2, Dp), 2)
    chk('bit==std', rp2 == -1 and 2 * qform(H2, D) == conic,
        'rule A (D\' covers RP2 twice): RP2.RP2 = -2/2 = -1, charge -X.X = +1 for AH; the branch locus: conic.conic = 2 D.D = 4 = (2h).(2h) of the cell lattice')
    ruleB_printed = lambda xp, x: 2 * xp == x                 # (X')^2 = X^2/2: X' the branch locus upstairs, X its image downstairs
    ruleB_ocr = lambda xp, x: xp == 4 * x                     # the OCR's (X')^2 = 4 X^2
    ruleB = ruleB_ocr if FAULT == 'rule-b-ocr' else ruleB_printed
    Dsq = qform(H2, D)
    chk('std', ruleB(Dsq, conic) and not ruleB_ocr(Dsq, conic) and not ruleB_ocr(conic, Dsq),
        'the printed rule B, (X\')^2 = X^2/2 (X^2 = 2 (X\')^2, X\' the branch locus, X its image), fits (diagonal, conic) = (%d, %d) of the lattices; a wrong rule B, (X\')^2 = 4 X^2, fits neither reading' % (Dsq, conic))
    dg_ = lambda A: sorted(A[i][i] for i in range(len(A)))
    mirror = all(dg_(bit_gram(q, p)) == dg_(neg(bit_gram(p, q))) for (p, q) in [(1, 0), (0, 1), (2, 1), (1, 8)])
    chk('bit', mirror and bit_gram(0, 0) == neg(bit_gram(0, 0)) and signature_exact([[1]])[0] != signature_exact([[-1]])[0] and qform(H2, (1, -1)) == -qform(H2, (1, 1)),
        'orientation reversal negates the form = the mirror cell (q,p): the empty form of S4 (cell (0,0)) is its own mirror; (1) and (-1) differ by signature (neutron and antineutron); H = -H by (a,b) -> (a,-b)')
    tick('part L')

# ================================================================================================ Part G helpers
NV = 4
SQ = [1, 1, 1, 1]
LieE = Lie(SQ); Gv = Grav(4, LieE); S_ = koszul_S(4, SQ, LieE); FmE = Forms(4)        # built per run: an engine fault put into Lie in memory is seen
def J0(c): return const(NV, c)
def jm(a, b): return sp_mul(a, b, 2, NV)
def jinv(A): return KJ.recip2(A, NV)
def jsqrt(A):
    a0 = at0(A, NV); s0 = KJ.rat_sqrt(a0)
    if s0 is None or s0 == 0: raise ValueError('the square root is not rational at the point: %s' % a0)
    u = scale(sp_add(A, J0(a0), -1), 1 / a0); return scale(lin((F(1), J0(1)), (F(1, 2), u), (F(-1, 8), jm(u, u))), s0)
def perm_sign(seq):
    s = 1
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]: s = -s
    return s
ORI = -1 if FAULT == 'hodge-sign' else 1
H6 = [[F(0)] * 6 for _ in range(6)]
for _A, (_a, _b) in enumerate(PAIRS4):
    _c, _d = [t for t in range(4) if t not in (_a, _b)]; H6[PAIRS4.index((_c, _d))][_A] = F(ORI * perm_sign([_a, _b, _c, _d]))
I6 = [[F(1 if i == j else 0) for j in range(6)] for i in range(6)]
def mmul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def madd(A, B, c=1): return [[A[i][j] + c * B[i][j] for j in range(len(A[0]))] for i in range(len(A))]
def mscal(A, c): return [[c * x for x in row] for row in A]
def mzero(A): return all(x == 0 for row in A for x in row)
def mvec(A, v): return [sum(A[i][j] * v[j] for j in range(len(v))) for i in range(len(A))]
PP = mscal(madd(I6, H6), F(1, 2)); PM = mscal(madd(I6, H6, -1), F(1, 2))
BP = [[1, 0, 0, 0, 0, 1], [0, 1, 0, 0, -1, 0], [0, 0, 1, 1, 0, 0]]          # e01 + e23, e02 - e13, e03 + e12
BM = [[1, 0, 0, 0, 0, -1], [0, 1, 0, 0, 1, 0], [0, 0, 1, -1, 0, 0]]         # e01 - e23, e02 + e13, e03 - e12
def op6(T): return [[T[PAIRS4[A] + PAIRS4[B]] for B in range(6)] for A in range(6)]
def block3(M6, basis): return [[sum(F(basis[i][A]) * M6[A][B] * F(basis[j][B]) for A in range(6) for B in range(6)) / 2 for j in range(3)] for i in range(3)]
def ptype(W3):
    t, I2, I3, info = petrov([[QI(x) for x in row] for row in W3]); return t, info
def qre(x): return x.re if (isinstance(x, QI) and x.im == 0) else (F(x) if not isinstance(x, QI) else None)
def ricci(Rl): return [[sum(Rl[(a, b, a, d)] for a in range(4)) for d in range(4)] for b in range(4)]
def norm2(Rl): return sum(v * v for v in Rl.values())
def engine_eval(e, cs=(0,)):
    Rl, om, R = engine_frame_riemann(Gv, e, S_, 4)
    return Rl, {c: engine_E_from_R(Gv, e, R, 4, c) for c in cs}
def Ezero(comp): return all(v == 0 for v in comp.values())
def frame_comps_2form(Fm2, e):
    """frame components F_A (A = (a,b), a < b) at the origin of a coordinate 2-form {mask: poly}"""
    e0, E0, det = E0_of(e, 4, NV); out = [F(0)] * 6
    for mask, pol in Fm2.items():
        mu, nu = [i for i in range(4) if mask >> i & 1]; v = at0(pol, NV)
        if v == 0: continue
        for A, (a, b) in enumerate(PAIRS4): out[A] += v * (E0[mu][a] * E0[nu][b] - E0[nu][a] * E0[mu][b])
    return out

# ------------------------------------------------------------------------------------------------ the coframes
def tn_frame(p, m, kw=F(1), sgn=1, vpow=1, harm=None):
    m = F(m); X = [None] + [lin((F(1), J0(p[i - 1])), (F(1), var(NV, i))) for i in (1, 2, 3)]
    r = jsqrt(lin(*[(F(1), jm(X[i], X[i])) for i in (1, 2, 3)])); ir = jinv(r)
    V = lin((F(1), J0(1)), (m, ir if vpow == 1 else jm(ir, ir)))
    sV = jsqrt(V); isV = jinv(sV)
    q = jinv(lin((F(1), jm(X[1], X[1])), (F(1), jm(X[2], X[2])))); cz = jm(X[3], ir); mw = m * kw * sgn
    wx = scale(jm(jm(cz, X[2]), q), -mw); wy = scale(jm(jm(cz, X[1]), q), mw)
    e = [{1: isV, 2: jm(isV, wx), 4: jm(isV, wy)}, {2: sV}, {4: sV}, {8: sV}]
    hh = None
    if harm is not None:
        hh = jm(r, jinv(lin((F(1), r), (m, J0(1))))) if harm == 'r/(r+m)' else (jm(lin((F(1), r), (m, J0(1))), ir) if harm == '(r+m)/r' else J0(1))
    A1 = {1: hh, 2: jm(hh, wx), 4: jm(hh, wy)} if hh is not None else None
    return e, dict(r0=at0(r, NV), V0=at0(V, NV), A1=A1)
def s4_frame(p):
    X = [lin((F(1), J0(p[i])), (F(1), var(NV, i))) for i in range(4)]
    f = scale(jinv(lin((F(1), J0(1)), *[(F(1), jm(X[i], X[i])) for i in range(4)])), 2)
    return [{1 << a: f} for a in range(4)]
def cmul(a, b): return (sp_add(jm(a[0], b[0]), jm(a[1], b[1]), -1), sp_add(jm(a[0], b[1]), jm(a[1], b[0])))
def cp2_frame(p, plain=False):
    X = [lin((F(1), J0(p[i])), (F(1), var(NV, i))) for i in range(4)]
    s = jsqrt(lin((F(1), J0(1)), *[(F(1), jm(X[i], X[i])) for i in range(4)])); invs = jinv(s); k = jinv(jm(s, lin((F(1), s), (F(1), J0(1)))))
    z = [(X[0], X[1]), (X[2], X[3])]
    C = {}
    for j in (0, 1):
        zr, zi = z[j]; C[2 * j] = (zr, scale(zi, -1)); C[2 * j + 1] = (zi, zr)      # conj(z_j) dz_j: coefficients at dx^(2j) and dx^(2j+1)
    e = [dict(), dict(), dict(), dict()]
    for kk in (0, 1):
        for mu in range(4):
            de = (J0(1), {}) if mu == 2 * kk else ((({}, J0(1))) if mu == 2 * kk + 1 else ({}, {}))
            corr = ({}, {}) if plain else cmul(cmul(z[kk], (k, {})), C.get(mu, ({}, {})))
            th = (jm(invs, sp_add(de[0], corr[0], -1)), jm(invs, sp_add(de[1], corr[1], -1)))
            if th[0]: e[2 * kk][1 << mu] = th[0]
            if th[1]: e[2 * kk + 1][1 << mu] = th[1]
    return e

# ------------------------------------------------------------------------------------------------ float route (closed-form metrics, never the jets)
def g_tn(X, m, kw=1.0):
    t, x, y, z = X; r = math.sqrt(x * x + y * y + z * z); V = 1 + m / r; q = x * x + y * y
    a = np.array([1.0, -kw * m * z * y / (r * q), kw * m * z * x / (r * q), 0.0]); return V * np.diag([0.0, 1, 1, 1]) + np.outer(a, a) / V
def g_s4(X): return (2.0 / (1 + float(np.dot(X, X)))) ** 2 * np.eye(4)
_EB = [np.array([1, 0]), np.array([1j, 0]), np.array([0, 1]), np.array([0, 1j])]
def g_cp2(X):
    z = np.array([X[0] + 1j * X[1], X[2] + 1j * X[3]]); r2 = float(np.vdot(z, z).real)
    G = (np.eye(2) - np.outer(z, z.conj()) / (1 + r2)) / (1 + r2)
    return np.array([[np.real(np.vdot(_EB[a], G @ _EB[b])) for b in range(4)] for a in range(4)])
def fd_curv(gfun, x0, h=1e-4):
    x0 = np.array(x0, float); n = 4
    def Gam(x):
        g = gfun(x); gi = np.linalg.inv(g); dg = np.zeros((n, n, n))
        for kk in range(n):
            ek = np.zeros(n); ek[kk] = h; dg[kk] = (gfun(x + ek) - gfun(x - ek)) / (2 * h)
        B = np.transpose(dg, (1, 0, 2)) + np.transpose(dg, (1, 2, 0)) - dg
        return 0.5 * np.einsum('ls,smn->lmn', gi, B)
    G0 = Gam(x0); dG = np.zeros((n, n, n, n))
    for kk in range(n):
        ek = np.zeros(n); ek[kk] = h; dG[kk] = (Gam(x0 + ek) - Gam(x0 - ek)) / (2 * h)
    R = (np.einsum('mrns->rsmn', dG) - np.einsum('nrms->rsmn', dG) + np.einsum('rml,lns->rsmn', G0, G0) - np.einsum('rnl,lms->rsmn', G0, G0))
    g = gfun(x0); gi = np.linalg.inv(g); ric = np.einsum('rsrn->sn', R); Rl = np.einsum('ra,asmn->rsmn', g, R)
    K = np.einsum('abcd,ae,bf,cg,dh,efgh->', Rl, gi, gi, gi, gi, Rl)
    return g, ric, K

# ================================================================================================ Part G
TN_DIRS = [(F(2, 3), F(1, 3), F(2, 3)), (F(3, 7), F(-6, 7), F(2, 7)), (F(-1, 3), F(2, 3), F(-2, 3)), (F(0), F(4, 5), F(3, 5))]
TN_PTS = [(F(2), F(2, 3), 0), (F(2), F(8, 5), 1), (F(2), F(1, 4), 2), (F(2), F(9, 8), 3),
          (F(1, 2), F(1, 6), 1), (F(1, 2), F(2, 5), 0), (F(3), F(1), 0), (F(3), F(12, 5), 2)]          # (m, r, direction): sqrt(1 + m/r) rational
def tn_point(m, r, d): return tuple(r * c for c in TN_DIRS[d])
S4_PTS = [(F(1, 2), F(0), F(1, 3), F(-1)), (F(2), F(1), F(0), F(1, 5)), (F(0), F(0), F(0), F(0))]
def cp2_point(rho, u): return tuple(rho * c for c in u)
CP2_PTS = [cp2_point(F(3, 4), (F(1, 2), F(1, 2), F(1, 2), F(1, 2))), cp2_point(F(4, 3), (F(2, 7), F(3, 7), F(0), F(6, 7))), cp2_point(F(5, 12), (F(1, 3), F(-2, 3), F(2, 3), F(0)))]

def part_G():
    head('G0. [bit] the duality of the Riemannian cell: J = pseudoscalar times a bivector; [std] the Hodge star of e0 e1 e2 e3')
    J, I2, comm, compl = duality_J(SQ); JM = J_matrix(J)
    chk('bit', I2 == 1 and comm and compl and mmul(JM, JM) == I6, 'Cl(4,0): I^2 = +1, I commutes with the bivectors and maps each label to its complement, J^2 = 1: two real eigenspaces 3 + 3, no complex structure')
    chk('bit==std', JM == mscal(H6, -1), 'J = -* on the six labels (the pseudoscalar of the bit rule is minus the Hodge star of the orientation e0 e1 e2 e3 on bivectors)')
    chk('ctl', duality_J(LORENTZ(4))[1] == -1, 'control: in Cl(1,3) the same rule gives I^2 = -1 (the complex Q = E + iB of the Petrov rows)')
    chk('std', all(mvec(H6, [F(x) for x in b]) == [F(x) for x in b] for b in BP) and all(mvec(H6, [F(x) for x in b]) == [-F(x) for x in b] for b in BM),
        'the bases e01 + e23, e02 - e13, e03 + e12 (self-dual) and e01 - e23, e02 + e13, e03 - e12 (anti-self-dual) of the star of e0 e1 e2 e3')

    head('G1. [bit] Taub-NUT (Gibbons-Hawking, V = 1 + m/r) at 8 rational points: Ricci-flat, curvature self-dual, Weyl type D; [std] Christoffel and float routes')
    okE = okEq = okRic = okSD = okD = okN = okHK = okHKc = okFmet = True; found = set(); dens_eng = {}
    rng = random.Random(11)
    if FAULT == 'petrov-random':
        er = rand_frame(rng, 4, deg=2, coef=2, density=.5); Rr = engine_frame_riemann(Gv, er, S_, 4)[0]; Cr = weyl_parts(Rr, SQ)[0]
    for (m, r0, d) in TN_PTS:
        p = tn_point(m, r0, d)
        kw = F(7, 6) if FAULT == 'tn-omega' else F(1)
        vp = 2 if (FAULT == 'tn-vpow' and r0 == 1) else 1
        e, info = tn_frame(p, m, kw=kw, vpow=vp)
        assert info['r0'] == r0
        Rl, Es = engine_eval(e); Rs = std_frame_riemann(e, 4, SQ, NV)
        okE &= Ezero(Es[0]); okEq &= (Rl == Rs); okRic &= all(x == 0 for row in ricci(Rs) for x in row)
        R6 = op6(Rl); C6 = op6(Cr) if FAULT == 'petrov-random' else op6(weyl_parts(Rl, SQ)[0])
        okSD &= mzero(mmul(mmul(PM, R6), PM)) and mzero(mmul(mmul(PP, R6), PM)) and not mzero(mmul(mmul(PP, R6), PP))
        mu = m / (r0 + m) ** 3; W3 = block3(C6, BP); t, inf = ptype(W3)
        dbl, sim = (qre(inf['double']), qre(inf['simple'])) if t == 'D' else (None, None)
        if t == 'D' and dbl is not None and sim is not None and abs(dbl) == mu and sim == -2 * dbl: found.add('double %s mu' % ('+' if dbl > 0 else '-'))
        else: okD = False
        okD &= ptype(block3(C6, BM))[0] == 'O'
        okN &= norm2(Rl) == 24 * m * m / (r0 + m) ** 6; dens_eng[(m, r0)] = norm2(Rl) / 4
        hk = [[1, 0, 0, 0, 0, 1], [0, 1, 0, 0, -1, 0], [0, 0, 1, 1, 0, 0]] if FAULT == 'hk-sd' else BM
        for wv in hk:
            okHK &= all(x == 0 for x in mvec(R6, [F(x) for x in wv]))
            Om = {}
            for A, (a, b) in enumerate(PAIRS4):
                if wv[A]: Om = FmE.add(Om, FmE.wedge(e[a], e[b]), wv[A])
            okHKc &= all(at0(pol, NV) == 0 for pol in FmE.d(Om).values())
        g0 = std_metric(e, 4, SQ, NV, 0); gf = g_tn([0.0] + [float(c) for c in p], float(m))
        okFmet &= np.allclose(np.array([[float(at0(g0[(a, b)], NV)) for b in range(4)] for a in range(4)]), gf, rtol=1e-12, atol=1e-12)
    pts = '8 points: m = 2 at r = 2/3, 8/5, 1/4, 9/8; m = 1/2 at r = 1/6, 2/5; m = 3 at r = 1, 12/5 (directions (2,1,2)/3, (3,-6,2)/7, (-1,2,-2)/3, (0,4,3)/5)'
    chk('std', okFmet, 'the coframe gives the Gibbons-Hawking metric V dx.dx + (dtau + w)^2/V at the points (against the closed form in floats, 1e-12)')
    chk('bit', okE, 'the engine\'s E_a(0) = 0 exactly, all 16 components, at the ' + pts)
    chk('std', okRic, 'Ricci = 0 exactly by the Christoffel route on g = e^T e at the 8 points')
    chk('bit==std', okEq, 'the engine\'s frame Riemann tensor R_abcd equals the Christoffel route exactly at the 8 points')
    chk('bit', okSD, 'the curvature operator is self-dual for the orientation e0 e1 e2 e3 = dtau dx dy dz: its (-,-) and (+,-) blocks vanish, its (+,+) block does not (8 points)')
    chk('bit', okD and len(found) == 1, 'W+ (3 x 3, self-dual basis) is type D (g2_weyl.petrov: a double eigenvalue, rank(W+ - double) = 1) with eigenvalues {%s} x (1, 1, -2), mu = m/(r + m)^3, and W- is type O, at the 8 points' % ', '.join(sorted(found)))
    chk('bit', okN, '|Rm|^2 = R_abcd R_abcd = 24 m^2/(r + m)^6 exactly at the 8 points')
    chk('bit', okHK and okHKc, 'the three anti-self-dual forms e0 e_i - (1/2) eps_ijk e_j e_k are closed (engine d of the engine\'s wedge, at the points) and the curvature annihilates them: hyperkahler, with the complex orientations -e0 e1 e2 e3')
    ef = tn_frame(tn_point(*TN_PTS[0][:2], TN_PTS[0][2]), TN_PTS[0][0])[0]
    Om_sd = FmE.add(FmE.wedge(ef[0], ef[1]), FmE.wedge(ef[2], ef[3]))
    dOm = FmE.d(Om_sd); p0 = tn_point(*TN_PTS[0][:2], TN_PTS[0][2]); m0 = TN_PTS[0][0]
    chk('ctl', at0(dOm.get(0b1110, {}), NV) == -2 * m0 * p0[0] / TN_PTS[0][1] ** 3 and all(at0(pol, NV) == 0 for mk, pol in dOm.items() if mk != 0b1110),
        'control: the self-dual e0 e1 + e2 e3 is not closed: the engine\'s d gives 2 (dV/dx) dx dy dz = -2 m x/r^3 dx dy dz exactly (m = 2, r = 2/3): the closedness test is not vacuous')
    okTf = True
    for (m, r0, d) in TN_PTS[:3]:
        p = tn_point(m, r0, d); g, ricf, K = fd_curv(lambda X: g_tn(X, float(m)), [0.0] + [float(c) for c in p], h=3e-5)
        okTf &= np.abs(ricf).max() < 1e-4 * math.sqrt(K) * np.abs(g).max() and abs(K / float(24 * m * m / (r0 + m) ** 6) - 1) < 1e-5
    chk('std', okTf, 'float route from the closed-form Gibbons-Hawking metric (never the jets, step 3e-5): Ricci = 0 (below 1e-4 of the curvature scale) and |Rm|^2 = 24 m^2/(r + m)^6 (relative 1e-5) at 3 of the points')
    wsq = FmE.wedge({0b0011: {(0,) * 4: F(1)}, 0b1100: {(0,) * 4: F(-1)}}, {0b0011: {(0,) * 4: F(1)}, 0b1100: {(0,) * 4: F(-1)}})
    chk('bit', wsq == {0b1111: {(0,) * 4: F(-2)}}, 'the engine\'s wedge: (e01 - e23)^2 = -2 e0123, so the hyperkahler forms are self-dual for -e0 e1 e2 e3, the opposite of the curvature (the paper\'s choice of orientation)')
    # orientation reversal and wrong versions
    okFlip = True
    for (m, r0, d) in TN_PTS[:2]:
        e, _ = tn_frame(tn_point(m, r0, d), m, sgn=-1); Rl, Es = engine_eval(e); R6 = op6(Rl)
        okFlip &= Ezero(Es[0]) and mzero(mmul(mmul(PP, R6), PP)) and not mzero(mmul(mmul(PM, R6), PM))
    chk('bit', okFlip, 'w -> -w (dw = -*dV) is NOT a wrong version: E_a(0) = 0 at 2 points and the curvature moves to the anti-self-dual block (the orientation reversed: the anti-particle of the paper)')
    e, _ = tn_frame(tn_point(*TN_PTS[1][:2], TN_PTS[1][2]), TN_PTS[1][0], kw=F(7, 6)); _, Es = engine_eval(e)
    e2, _ = tn_frame(tn_point(F(3), F(1), 0), F(3), vpow=2); _, Es2 = engine_eval(e2)
    chk('ctl', not Ezero(Es[0]) and not Ezero(Es2[0]), 'controls: w with the factor 7/6 (m = 2, r = 8/5) and V = 1 + m/r^2 (m = 3, r = 1, where V = 4 as for Taub-NUT) give E_a(0) != 0')
    er = rand_frame(random.Random(5), 4, deg=2, coef=2, density=.5); Cr2 = op6(weyl_parts(engine_frame_riemann(Gv, er, S_, 4)[0], SQ)[0])
    chk('ctl', ptype(block3(Cr2, BP))[0] == 'I' and ptype(block3(Cr2, BM))[0] == 'I', 'control: a random Riemannian frame has W+ and W- of type I (the type test can say I)')
    tick('G1')

    head('G2. [bit] the L2 harmonic 2-form of Taub-NUT (the paper\'s (8.16), (C.9)): F = d(h (dtau + w)), h = r/(r + m), self-dual; [std] its integral')
    okH = okHn = okHv = True
    for (m, r0, d) in TN_PTS[:4] + TN_PTS[6:7]:
        hsel = '(r+m)/r' if FAULT == 'harm-h' else 'r/(r+m)'
        p = tn_point(m, r0, d); e, info = tn_frame(p, m, harm=hsel); F6 = frame_comps_2form(FmE.d(info['A1']), e)
        okH &= any(F6) and mvec(H6, F6) == F6 and mvec(JM, F6) == [-x for x in F6]
        okHn &= sum(x * x for x in F6) == 2 * m * m / (r0 + m) ** 4
        okHv &= [F6[0], F6[1], F6[2]] == [-m * p[i] / (r0 * (r0 + m) ** 2) for i in range(3)]
    chk('bit', okH, 'F = d(h (dtau + w)) (engine d of the 1-form jet) is self-dual (*F = F, J F = -F) at 5 points (m = 2 and m = 3)')
    chk('bit', okHn, '|F|^2 = sum_(a<b) F_ab^2 = 2 m^2/(r + m)^4 exactly at the 5 points')
    chk('bit', okHv, 'the components: F_0i = -h\' x_i/r = -m x_i/(r (r + m)^2) exactly at the 5 points (dr ^ (dtau + w) = -(x_i/r) e0 ^ e_i): the paper\'s form (C.9) in this frame')
    e, info = tn_frame(tn_point(*TN_PTS[0][:2], TN_PTS[0][2]), TN_PTS[0][0], harm='(r+m)/r'); Fa = frame_comps_2form(FmE.d(info['A1']), e)
    e, info = tn_frame(tn_point(*TN_PTS[0][:2], TN_PTS[0][2]), TN_PTS[0][0], harm='1'); Fb = frame_comps_2form(FmE.d(info['A1']), e)
    chk('ctl', mvec(H6, Fa) == [-x for x in Fa] and mvec(H6, Fb) != Fb and mvec(H6, Fb) != [-x for x in Fb],
        'controls: h = (r + m)/r gives an anti-self-dual F (singular at r = 0, the other solution of (C.3)); h = 1 (F = dw) is neither')
    tot = [4 * PI * mm * 4 * PI * integrate.quad(lambda r: r * r * (1 + mm / r) * 2 * mm * mm / (r + mm) ** 4, 0, np.inf, epsrel=1e-11)[0] / mm ** 2 for mm in (2.0, 0.5, 3.0)]
    chk('std', all(abs(t / (16 * PI ** 2) - 1) < 1e-9 for t in tot), 'integral of F^F = |F|^2 dV over Taub-NUT (fibre length 4 pi m, dV = V d3x dtau) divided by m^2: 16 pi^2 for m = 2, 1/2, 3 (the paper\'s (C.10)); then (p/4pi)^2 16pi^2 = p gives p = 1 = X.X (8.20)')
    tick('G2')

    head('G3. [bit] the round S4 and CP2 (Fubini-Study) on the engine: Einstein, W = 0 for S4, W- = 0 and W+ type D for CP2 with its complex orientation')
    okS = okSE = okSc = okSeq = okSf = True
    for p in S4_PTS:
        e = s4_frame(p); Rl, Es = engine_eval(e, (0, -1)); Rs = std_frame_riemann(e, 4, SQ, NV)
        want = {(a, b, c, d): F((1 if (a == c and b == d) else 0) - (1 if (a == d and b == c) else 0)) for a in range(4) for b in range(4) for c in range(4) for d in range(4)}
        okS &= (Rl == want); okSeq &= (Rl == Rs); okSE &= Ezero(Es[0 if FAULT == 'einstein-c0' else -1]); okSc &= not Ezero(Es[0])
        C6 = op6(weyl_parts(Rl, SQ)[0]); okS &= ptype(block3(C6, BP))[0] == 'O' and ptype(block3(C6, BM))[0] == 'O'
        g, ric, K = fd_curv(g_s4, [float(c) for c in p]); okSf &= np.allclose(ric, 3 * g, rtol=1e-5, atol=1e-6) and abs(K / 24 - 1) < 1e-5
    chk('bit', okS, 'S4: R_abcd = d_ac d_bd - d_ad d_bc exactly (sectional curvature 1) at 3 points, W+ and W- type O (conformally flat)')
    chk('bit', okSE and okSc, 'S4: the engine\'s E_a(c) = 0 exactly for c = -1 (Ric = 3 g: c = -lambda/3) and E_a(0) != 0 (control) at the 3 points')
    chk('bit==std', okSeq, 'S4: engine Riemann = Christoffel route exactly at the 3 points')
    chk('std', okSf, 'S4: float route from the closed form 4|dx|^2/(1 + |x|^2)^2: Ric = 3 g and |Rm|^2 = 24 (relative 1e-5)')
    okC = okCE = okCc = okCeq = okCf = okK = True; cfound = set()
    for p in CP2_PTS:
        e = cp2_frame(p, plain=(FAULT == 'fs-frame')); Rl, Es = engine_eval(e, (0, -2)); Rs = std_frame_riemann(e, 4, SQ, NV)
        okCeq &= (Rl == Rs); okCE &= Ezero(Es[0 if FAULT == 'einstein-c0' else -2]); okCc &= not Ezero(Es[0])
        ric = ricci(Rl); okC &= all(ric[b][d] == (6 if b == d else 0) for b in range(4) for d in range(4))
        R6 = op6(Rl); okC &= mmul(mmul(PM, R6), PM) == mscal(PM, 2) and mzero(mmul(mmul(PP, R6), PM))
        kap = [F(1), 0, 0, 0, 0, F(1)]; okK &= mvec(R6, kap) == [6 * x for x in kap]
        C6 = op6(weyl_parts(Rl, SQ)[0]); t, inf = ptype(block3(C6, BP)); okC &= t == 'D' and ptype(block3(C6, BM))[0] == 'O'
        if t == 'D': cfound.add('double %s, simple %s' % (qre(inf['double']), qre(inf['simple'])))
        Wp = mmul(mmul(PP, C6), PP); okC &= norm2(Rl) == 192 and 4 * sum(x * x for row in Wp for x in row) == 96
        g0 = std_metric(e, 4, SQ, NV, 0); gfl = g_cp2([float(c) for c in p])
        okCf &= np.allclose(np.array([[float(at0(g0[(a, b)], NV)) for b in range(4)] for a in range(4)]), gfl, rtol=1e-12, atol=1e-12)
        g, ricf, K = fd_curv(g_cp2, [float(c) for c in p]); okCf &= np.allclose(ricf, 6 * g, rtol=1e-5, atol=1e-6) and abs(K / 192 - 1) < 1e-5
    chk('std', okCf, 'CP2: the coframe gives the Fubini-Study metric |dz|^2/(1 + |z|^2) - |zbar.dz|^2/(1 + |z|^2)^2 at the 3 points (1e-12), and the float route gives Ric = 6 g, |Rm|^2 = 192 (1e-5)')
    chk('bit', okC, 'CP2 at 3 points (|z| = 3/4, 4/3, 5/12): Ric = 6 delta, the curvature is 2 on the anti-self-dual block (W- = 0) for e0 e1 e2 e3, the complex orientation; W+ type D %s; |Rm|^2 = 192, |W+|^2 = 96' % sorted(cfound))
    chk('bit', okK, 'CP2: the Kahler form e01 + e23 (self-dual) is an eigenvector of the curvature operator with eigenvalue 6 = the Einstein constant')
    chk('bit', okCE and okCc, 'CP2: the engine\'s E_a(c) = 0 exactly for c = -2 (Ric = 6 g) and E_a(0) != 0 (control) at the 3 points')
    chk('bit==std', okCeq, 'CP2: engine Riemann = Christoffel route exactly at the 3 points')
    e = cp2_frame(CP2_PTS[0], plain=True); Rl, Es = engine_eval(e, (0, -2)); R6 = op6(Rl)
    C6p = op6(weyl_parts(Rl, SQ)[0])
    chk('ctl', not Ezero(Es[-2]) and ptype(block3(C6p, BP))[0] == 'O' and ptype(block3(C6p, BM))[0] == 'O',
        'control: the coframe without its correction term (theta = dz/s, the conformally flat metric |dz|^2/(1 + |z|^2)) is not Einstein (E_a(-2) != 0) and has W+ = W- = 0: the correction term is what gives W+ its type D')
    tick('G3')

    head('G4. [std] the characteristic numbers from the engine\'s pointwise densities: chi = (1/32pi^2) int (|Rm|^2 - 4|Ric|^2 + s^2), sigma = (1/48pi^2) int (|W+|^2 - |W-|^2) (recalled)')
    vs4 = 2 * PI ** 2 * integrate.quad(lambda r: r ** 3 * (2 / (1 + r * r)) ** 4, 0, np.inf, epsrel=1e-12)[0]
    vcp = 2 * PI ** 2 * integrate.quad(lambda r: r ** 3 / (1 + r * r) ** 3, 0, np.inf, epsrel=1e-12)[0]
    okdet = all(abs(math.sqrt(np.linalg.det(g_cp2(np.array([a, b, c, d])))) * (1 + a * a + b * b + c * c + d * d) ** 3 - 1) < 1e-12 for (a, b, c, d) in [(0.3, -0.2, 0.5, 1.1), (2.0, 0.1, -0.4, 0.0)])
    chk('std', abs(vs4 / (8 * PI ** 2 / 3) - 1) < 1e-9 and abs(vcp / (PI ** 2 / 2) - 1) < 1e-9 and okdet,
        'volumes by quad: S4 (radius 1) 8 pi^2/3, CP2 (Fubini-Study) pi^2/2 (sqrt det g = (1 + |z|^2)^-3 checked at 2 points)')
    chis4 = (24 - 4 * 36 + 144) * vs4 / (32 * PI ** 2); sigs4 = 0.0
    chicp = (192 - 4 * 144 + 576) * vcp / (32 * PI ** 2); sigcp = (96 - 0) * vcp / (48 * PI ** 2)
    chk('std', abs(chis4 - 2) < 1e-9 and sigs4 == 0 and abs(chicp - 3) < 1e-9 and abs(sigcp - 1) < 1e-9,
        'with the densities of G3 (|Rm|^2 = 24, 192; |Ric|^2 = 36, 144; s = 12, 24; |W+|^2 = 0, 96; |W-|^2 = 0): chi(S4) = %.9f, sigma(S4) = 0, chi(CP2) = %.9f, sigma(CP2) = %.9f (the paper\'s Table 1, neutrino 0, neutron 1)' % (chis4, chicp, sigcp))
    itn = [4 * PI * mm * 4 * PI * integrate.quad(lambda r: r * r * (1 + mm / r) * 24 * mm * mm / (r + mm) ** 6, 0, np.inf, epsrel=1e-12)[0] for mm in (2.0, 0.5, 3.0)]
    chk('std', all(abs(t / (32 * PI ** 2) - 1) < 1e-9 for t in itn),
        'Taub-NUT: int |Rm|^2 dV = 32 pi^2 for m = 2, 1/2, 3 (fibre 4 pi m, exact value 384 pi^2 m^3 / (12 m^3)): the bulk Euler number 1 = chi(R4) and the paper\'s ||R||^2 = 8 pi^2 (its norm is 1/4 of ours)')
    sb = itn[0] / (48 * PI ** 2)
    chk('std', abs(sb - 2.0 / 3) < 1e-9, 'Taub-NUT: the bulk signature (1/48pi^2) int |W+|^2 = %.9f = 2/3 (the paper\'s (8.11)), while b2 = 0 gives sigma = 0: the bulk is not the signature on this non-compact space (the boundary eta term, recalled, not computed)' % sb)
    FTN = lambda r: F(-8) * (2 * r + 1) / (r + 2) ** 4
    dFTN = lambda r: F(-8) * (2 * (r + 2) - 4 * (2 * r + 1)) / (r + 2) ** 5
    okP = all(r * dFTN(r) / (2 * r * r * (r + 2)) == F(24) / (r + 2) ** 6 == dens_eng[(m, r)] for (m, r, d) in TN_PTS if m == 2)
    chk('bit==std', okP and FTN(F(0)) == F(-1, 2), 'the paper\'s F_TN = -8(2r + 1)/(r + 2)^4 ((B.21) as read through the OCR) gives r F\'/(a b^2 c) = 24/(r + 2)^6 (a = b = sqrt(r^2 + 2r), c = 2 sqrt(r/(r + 2))), equal to the engine\'s |Rm|^2/4 at the 4 points with m = 2; F(0) - F(oo) = -1/2 gives (-16 pi^2)(-1/2) = 8 pi^2 ((B.22))')
    Fah = lambda m1, m2, m3: 2 * (m1 + m2 + m3 - 1) ** 2 - 8 * m1 * m2 * m3
    chk('std', Fah(F(-1), F(1, 2), F(1, 2)) == 4 and Fah(F(0), F(0), F(1)) == 0,
        'Atiyah-Hitchin, the paper\'s arithmetic only (no metric here): (B.20) at its limits (B.25), (B.24) gives F(pi) = 4, F(oo) = 0, ||R||^2 = 16 pi^2, bulk chi 2 = chi(S2), bulk sigma 4/3 while sigma = 1')
    # the orientation of C^2 in the flat limit (V = m/r): z1 = sqrt(R) cos(th/2) e^(i(psi + ph)/2), z2 = sqrt(R) sin(th/2) e^(i(psi - ph)/2), R = 4 m r, psi = tau/m
    def ks(X, m=2.0):
        t, x, y, z = X; r = math.sqrt(x * x + y * y + z * z); th = math.acos(z / r); ph = math.atan2(y, x); R = 4 * m * r; ps = t / m
        z1 = math.sqrt(R) * math.cos(th / 2) * np.exp(0.5j * (ps + ph)); z2 = math.sqrt(R) * math.sin(th / 2) * np.exp(0.5j * (ps - ph))
        return np.array([z1.real, z1.imag, z2.real, z2.imag])
    X0 = np.array([0.7, 0.3, -0.5, 0.4]); hh = 1e-6
    Jk = np.array([(ks(X0 + hh * np.eye(4)[k]) - ks(X0 - hh * np.eye(4)[k])) / (2 * hh) for k in range(4)]).T
    gflat = lambda X: (lambda r: (2.0 / r) * np.diag([0.0, 1, 1, 1]) + np.outer([1.0, -2 * X[3] * X[2] / (r * (X[1] ** 2 + X[2] ** 2)), 2 * X[3] * X[1] / (r * (X[1] ** 2 + X[2] ** 2)), 0.0], [1.0, -2 * X[3] * X[2] / (r * (X[1] ** 2 + X[2] ** 2)), 2 * X[3] * X[1] / (r * (X[1] ** 2 + X[2] ** 2)), 0.0]) * r / 2.0)(math.sqrt(X[1] ** 2 + X[2] ** 2 + X[3] ** 2))
    zc = ks(X0); vt = Jk[:, 0]; iz = np.array([-zc[1], zc[0], -zc[3], zc[2]])
    chk('std', np.linalg.det(Jk) > 0 and np.allclose(Jk.T @ Jk, gflat(X0), rtol=1e-6, atol=1e-8) and np.allclose(vt, iz / (2 * 2.0), rtol=1e-6, atol=1e-9),
        'the flat limit V = m/r (m = 2) is C^2 by the Hopf map: the pulled-back flat metric is (m/r) dx.dx + (r/m)(dtau + w)^2, d/dtau is the scalar action i z/(2m), and dtau dx dy dz is the complex orientation of C^2 (positive Jacobian): Taub-NUT is self-dual for the orientation of C^2, as the paper says')
    tick('G4')

if __name__ == '__main__':
    part_L(); part_G(); finish('ATY-MATTER')
