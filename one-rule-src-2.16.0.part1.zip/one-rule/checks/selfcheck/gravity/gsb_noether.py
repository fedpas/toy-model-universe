#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""GSB-NOETHER.  Noether's second theorem for the Einstein-Cartan action, in a finite form.   python3 gsb_noether.py [--quick] [--fault NOR|LOR|EULER|BG|ROT]

Statement.  The action L = sum eps R^{ab} e^rest + lam_n c vol(e) (b1_first_variation.lag_EC) is invariant under diffeomorphisms and local
Lorentz rotations, which depend on arbitrary functions; its Euler-Lagrange forms E_a (frame) and Theta_A (connection) obey one identity per
arbitrary function:
    (N)  D E_a = (i_a T^b) ^ E_b + (i_a R^A) ^ Theta_A                    (diffeomorphisms; frame form: contracted with e^a_mu)
    (L)  (D Theta)_ab = e_a ^ E_b - e_b ^ E_a,  e_a = eta_aa e^a            (local Lorentz: the antisymmetric-stress identity)
Part A: (N) and (L) at n = 6 on one strong random field with torsion (c = 1/3) and at n = 5 on one strong field at a seed of its own.
Part B, the finite form of the theorem (n = 3, 4, c = 1/3): for every basis vector field xi = x^alpha d_mu with |alpha| <= 2 (hence, by
linearity, for every polynomial xi of degree <= 2), P(xi) = L_xi e^a ^ E_a + L_xi om^A ^ Theta_A equals d(i_xi L - L_xi om^A ^ Y_A) (the first
variation B1 plus L_xi L = d i_xi L); P is of first order in xi, P = (c_mu xi^mu + c_mu^nu d_nu xi^mu) vol_x, and its Euler operator in xi,
N_mu = c_mu - d_nu c_mu^nu (the coefficient of xi after integration by parts), is the zero polynomial.  For arbitrary forms E', Theta' (not
Euler-Lagrange forms) the Euler operator of L_xi e ^ E' + L_xi om ^ Theta' is the formal adjoint of the gauge generator,
    N'_mu = - e^a_mu (D E')_a + (i_mu T^a) ^ E'_a + (i_mu R^A) ^ Theta'_A - om^A_mu [ (D Theta')_A + h_Ab^a e^b ^ E'_a ],
so on the Euler-Lagrange forms the two brackets are (N) (frame form) and (L): the identities are the coefficients of xi and of i_xi om.
[bit]  the engine: Grav(n), curvature, torsion, Einstein form, D_covector, g2_forms_calc (interior, lie, D_dual_bivector), B1's Y and Theta;
       fields drawn by gravity_selfcheck.sform (every monomial of degree <= 1, integers uniform in -50..50).
[std]  P'(xi) from the plain component formula of the Lie derivative (g2_forms_calc.lie_std) and a plain wedge into the top degree (permutation
       signs), the same Euler extraction: [bit==std] on P'(xi) for every basis xi and on N'_mu.
Bounds (Schwartz-Zippel, coefficient set of 101 values): (N) contracted with e^a_mu has degree n + 1 in the sampled coefficients: one field
bounds a false identity of this form by (n + 1)/101 (7/101 at n = 6: a regression guard more than a bound); N_mu has degree n: three fields at
n = 3 give (3/101)^3 = 2.6e-5, two at n = 4 give (4/101)^2 = 1.6e-3; the adjoint identity has degree 3: (3/101)^3 per n.
Theorem recalled for every n and every invariant action: E. Noether, Invariante Variationsprobleme; Y. Kosmann-Schwarzbach, The Noether Theorems.
Controls (--fault puts each into its main check, exit 1): NOR (N) without the curvature term; LOR (L) with the coefficients flipped; EULER the
Euler operator with + d_nu; BG the Lagrangian with a fixed background vector in place of e^(n-1) (not invariant: its Euler operator in xi is not
zero); ROT the adjoint without the rotation term.  --quick skips n = 6 (the mutation table runs with it)."""
import os, sys, time, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import b1_first_variation as B1
from g2_forms_calc import interior, lie, lie_std, D_dual_bivector, form_eq

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
assert FAULT in (None, 'NOR', 'LOR', 'EULER', 'BG', 'ROT'), 'unknown fault'
QUICK = '--quick' in ARGS
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def nz(X): return any(p for p in X.values())
def pf(Fm, p, X): return Fm.wedge({0: p}, X) if p else {}
def wsum(Fm, pairs):
    out = {}
    for X, Y in pairs: out = Fm.add(out, Fm.wedge(X, Y))
    return out
def by_A(Gv, d): return [d[p] for p in pairs_of(Gv.L)]
def strong_fields(Gv, rng):
    n = Gv.n
    return [gs.sform(rng, n, 1) for _ in range(n)], [gs.sform(rng, n, 1) for _ in range(Gv.G)]

# ------------------------------------------------------------------------------------------------ part A: the two identities at n = 6 and n = 5
def part_A(n, seed, c):
    head('A  n = %d: the identities (N) and (L) on one strong random field with torsion (seed %d, c = %s)' % (n, seed, c))
    Gv = Grav(n); Fm = Gv.Fm; rng = random.Random(seed); e, om = strong_fields(Gv, rng); sq = LORENTZ(n)
    R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, c); DE = Gv.D_covector(om, E)
    Th = by_A(Gv, B1.Theta_forms(Gv, e, T)); rhs = Gv.einstein_rhs(e, T, R, c, F_)
    okN = okR = True; nzT = nzR = True; ctlN = False
    for mu in range(n):
        v = [{(0,) * n: F(1)} if k == mu else {} for k in range(n)]
        a1 = wsum(Fm, [(interior(Gv, v, T[b]), E[b]) for b in range(n)]); a2 = wsum(Fm, [(interior(Gv, v, R[A]), Th[A]) for A in range(Gv.G)])
        l1 = {}; r1 = {}
        for a in range(n): l1 = Fm.add(l1, pf(Fm, e[a].get(1 << mu, {}), DE[a])); r1 = Fm.add(r1, pf(Fm, e[a].get(1 << mu, {}), rhs[a]))
        okN &= form_eq(l1, a1 if FAULT == 'NOR' else Fm.add(a1, a2)); okR &= form_eq(l1, r1); nzT &= nz(a1); nzR &= nz(a2)
        ctlN |= not form_eq(l1, a1)
    chk('bit', okN and okR and nzT and nzR, 'n=%d: (N) e^a_mu (D E)_a = (i_mu T^b) ^ E_b + (i_mu R^A) ^ Theta_A exactly for mu = 0..%d (both terms non-zero), and it equals e^a_mu einstein_rhs_a (the torsion terms of the engine)' % (n, n - 1))
    chk('ctl', ctlN, 'n=%d: (N) without the curvature term (i_mu R^A) ^ Theta_A fails' % n)
    tick('n=%d (N)' % n)
    DTh = D_dual_bivector(Gv, om, Th); P = pairs_of(Gv.L)
    X1 = [Fm.wedge(Fm.scale(e[a], sq[a]), E[b]) for (a, b) in P]; X2 = [Fm.wedge(Fm.scale(e[b], sq[b]), E[a]) for (a, b) in P]
    want = [Fm.add(X2[A], X1[A], -1) if FAULT == 'LOR' else Fm.add(X1[A], X2[A], -1) for A in range(Gv.G)]
    chk('bit', all(form_eq(DTh[A], want[A]) and nz(DTh[A]) for A in range(Gv.G)), 'n=%d: (L) (D Theta)_ab = e_a ^ E_b - e_b ^ E_a exactly for all %d pairs (each side non-zero)' % (n, Gv.G))
    chk('ctl', not all(form_eq(DTh[A], Fm.add(X2[A], X1[A], -1)) for A in range(Gv.G)), 'n=%d: (L) with the coefficients flipped fails' % n)
    tick('n=%d (L)' % n)

# ------------------------------------------------------------------------------------------------ part B: the Euler operator in xi
def mono(n, alpha): return {tuple(alpha): F(1)}
def basis_fields(n):
    alphas = [a for a in itertools.product(range(3), repeat=n) if sum(a) <= 2]
    return [(mu, a) for mu in range(n) for a in alphas]
def vec(n, mu, alpha): return [mono(n, alpha) if k == mu else {} for k in range(n)]
def top(X, n): return X.get((1 << n) - 1, {})
def inv_count(seq):
    s = 0
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]: s += 1
    return s
def std_wedge_top(X, Y, n):
    """[std] the top-degree coefficient of X ^ Y by permutation signs (plain loops, no bit rule)"""
    full = (1 << n) - 1; out = {}
    for m1, p1 in X.items():
        for m2, p2 in Y.items():
            if m1 & m2 or (m1 | m2) != full: continue
            seq = [i for i in range(n) if m1 >> i & 1] + [i for i in range(n) if m2 >> i & 1]
            s = -1 if inv_count(seq) % 2 else 1
            out = padd(out, gs.pmul(p1, p2), s)
    return out
def extract(Pfun, n, sign=-1):
    """c_mu, c_mu^nu from P on the basis; returns (N_mu list, first_order_ok)"""
    zero = (0,) * n; ok = True; N = []
    for mu in range(n):
        c0 = Pfun(mu, zero)
        c1 = []
        for nu in range(n):
            a = [0] * n; a[nu] = 1; xnu = mono(n, a)
            c1.append(padd(Pfun(mu, tuple(a)), gs.pmul(xnu, c0), -1))
        for nu in range(n):
            for rho in range(nu, n):
                a = [0] * n; a[nu] += 1; a[rho] += 1
                xr = [0] * n; xr[rho] = 1; xn = [0] * n; xn[nu] = 1
                pred = padd(padd(gs.pmul(mono(n, a), c0), gs.pmul(mono(n, xr), c1[nu])), gs.pmul(mono(n, xn), c1[rho]))
                ok &= Pfun(mu, tuple(a)) == pred
        Nmu = dict(c0)
        for nu in range(n): Nmu = padd(Nmu, pder(c1[nu], nu), sign)
        N.append(Nmu)
    return N, ok
def part_B(n, seeds, c):
    head('B  n = %d: the coefficient of xi (Euler operator in xi on every basis field x^alpha d_mu, |alpha| <= 2; %d strong fields; c = %s)' % (n, len(seeds), c))
    Gv = Grav(n); Fm = Gv.Fm; G = Gv.G; L = Gv.L; full = (1 << n) - 1; zero = (0,) * n; sq = LORENTZ(n)
    for k, seed in enumerate(seeds):
        rng = random.Random(seed); e, om = strong_fields(Gv, rng)
        if FAULT == 'BG' and k == 0:
            b = {1 << (n - 1): {zero: F(1)}}; et = list(e[:n - 1]) + [b]
            R = Gv.curvature(om); T = Gv.torsion(om, et); E, _ = Gv.einstein(None, et, R, c); E = list(E[:n - 1]) + [{}]
            Th = by_A(Gv, B1.Theta_forms(Gv, et, T)); Yf = by_A(Gv, B1.Y_forms(Gv, et)); L0 = B1.lag_EC(Gv, et, om, c)
        else:
            R = Gv.curvature(om); T = Gv.torsion(om, e); E, _ = Gv.einstein(None, e, R, c)
            Th = by_A(Gv, B1.Theta_forms(Gv, e, T)); Yf = by_A(Gv, B1.Y_forms(Gv, e)); L0 = B1.lag_EC(Gv, e, om, c)
        Ep = [gs.sform(rng, n, n - 1) for _ in range(n)]; Tp = [gs.sform(rng, n, n - 2) for _ in range(G)]
        cache = {}; exact_ok = True; std_ok = True
        for (mu, a) in basis_fields(n):
            xi = vec(n, mu, a); Le = [lie(Gv, xi, x) for x in e]; Lo = [lie(Gv, xi, x) for x in om]
            P = Fm.add(wsum(Fm, [(Le[i], E[i]) for i in range(n)]), wsum(Fm, [(Lo[A], Th[A]) for A in range(G)]))
            K = Fm.add(interior(Gv, xi, L0), wsum(Fm, [(Lo[A], Yf[A]) for A in range(G)]), -1)
            exact_ok &= form_eq(P, Fm.d(K))
            Pp = Fm.add(wsum(Fm, [(Le[i], Ep[i]) for i in range(n)]), wsum(Fm, [(Lo[A], Tp[A]) for A in range(G)]))
            Ps = {}
            for i in range(n): Ps = padd(Ps, std_wedge_top(lie_std(xi, e[i], n), Ep[i], n))
            for A in range(G): Ps = padd(Ps, std_wedge_top(lie_std(xi, om[A], n), Tp[A], n))
            std_ok &= Ps == top(Pp, n)
            cache[(mu, a)] = (top(P, n), top(Pp, n), Ps)
        tag = ' (background vector in place of e^%d)' % (n - 1) if FAULT == 'BG' and k == 0 else ''
        chk('bit', exact_ok or (FAULT == 'BG' and k == 0), 'n=%d field %d%s: P(xi) = L_xi e ^ E + L_xi om ^ Theta equals d(i_xi L - L_xi om ^ Y) exactly for all %d basis fields (every polynomial xi of degree <= 2)' % (n, k, tag, len(cache)))
        sign = 1 if FAULT == 'EULER' else -1
        N, fo = extract(lambda mu, a: cache[(mu, a)][0], n, sign)
        chk('bit', fo and all(not x for x in N) and any(cache[(mu, (0,) * n)][0] for mu in range(n)), 'n=%d field %d%s: P is of first order in xi, and its Euler operator N_mu = c_mu - d_nu c_mu^nu is the zero polynomial for mu = 0..%d (c_mu = P(d_mu) is not zero): the coefficient of xi vanishes' % (n, k, tag, n - 1))
        if k == 0 and FAULT != 'EULER':
            Nw, _ = extract(lambda mu, a: cache[(mu, a)][0], n, 1)
            chk('ctl', any(x for x in Nw), 'n=%d: the Euler operator with + d_nu c_mu^nu is not zero' % n)
        Np, fop = extract(lambda mu, a: cache[(mu, a)][1], n, sign); Ns, _ = extract(lambda mu, a: cache[(mu, a)][2], n, sign)
        DEp = Gv.D_covector(om, Ep); DTp = D_dual_bivector(Gv, om, Tp); ok_adj = True; nzadj = False; ctl_rot = False
        for mu in range(n):
            v = [{zero: F(1)} if j == mu else {} for j in range(n)]
            cl = {}
            for a_ in range(n):
                cl = Fm.add(cl, pf(Fm, e[a_].get(1 << mu, {}), DEp[a_]), -1); cl = Fm.add(cl, Fm.wedge(interior(Gv, v, T[a_]), Ep[a_]))
            for A in range(G): cl = Fm.add(cl, Fm.wedge(interior(Gv, v, R[A]), Tp[A]))
            rot_all = {}; rot_no = {}
            for A in range(G):
                rotA = dict(DTp[A])
                for (A2, b_), (a_, h) in L.h.items():
                    if A2 == A: rotA = Fm.add(rotA, Fm.wedge(e[b_], Ep[a_]), h)
                rot_all = Fm.add(rot_all, pf(Fm, om[A].get(1 << mu, {}), rotA), -1); rot_no = Fm.add(rot_no, pf(Fm, om[A].get(1 << mu, {}), DTp[A]), -1)
            closed = top(Fm.add(cl, rot_no if FAULT == 'ROT' else rot_all), n); ok_adj &= Np[mu] == closed; nzadj |= bool(closed)
            ctl_rot |= Np[mu] != top(Fm.add(cl, rot_no), n)
        chk('bit', fop and ok_adj and nzadj, 'n=%d field %d: arbitrary E\', Theta\' (strong, not Euler-Lagrange forms): the Euler operator of L_xi e ^ E\' + L_xi om ^ Theta\' equals -e^a_mu (D E\')_a + (i_mu T^a) ^ E\'_a + (i_mu R^A) ^ Theta\'_A - om^A_mu [(D Theta\')_A + h_Ab^a e^b ^ E\'_a] exactly (non-zero)' % (n, k))
        chk('ctl', ctl_rot, 'n=%d field %d: the adjoint without the rotation term h e ^ E\' fails' % (n, k))
        chk('bit==std', std_ok and Ns == Np, 'n=%d field %d: [std] P\'(xi) by the component formula of the Lie derivative and a plain wedge equals the engine\'s for all %d basis fields, and so does its Euler operator' % (n, k, len(cache)))
        if k == 0 and FAULT != 'BG':
            # the two brackets on the Euler-Lagrange forms: frame form of (N) and the Lorentz identity in the h form
            DE = Gv.D_covector(om, E); DTh = D_dual_bivector(Gv, om, Th); okL = True
            for A in range(G):
                rotA = dict(DTh[A])
                for (A2, b_), (a_, h) in L.h.items():
                    if A2 == A: rotA = Fm.add(rotA, Fm.wedge(e[b_], E[a_]), h)
                okL &= not nz(rotA)
            chk('bit', okL, 'n=%d: on the Euler-Lagrange forms the bracket of om^A_mu vanishes for every A: (D Theta)_A = -h_Ab^a e^b ^ E_a, the Lorentz identity (L) in the h-table form' % n)
            # control: a fixed background vector (not invariant)
            b = {1 << (n - 1): {zero: F(1)}}; et = list(e[:n - 1]) + [b]
            Tb = Gv.torsion(om, et); Eb, _ = Gv.einstein(None, et, R, c); Eb = list(Eb[:n - 1]) + [{}]; Thb = by_A(Gv, B1.Theta_forms(Gv, et, Tb))
            def Pbg(mu, a):
                xi = vec(n, mu, a)
                return top(Fm.add(wsum(Fm, [(lie(Gv, xi, e[i]), Eb[i]) for i in range(n)]), wsum(Fm, [(lie(Gv, xi, om[A]), Thb[A]) for A in range(G)])), n)
            Nb, _ = extract(Pbg, n, -1)
            chk('ctl', any(x for x in Nb), 'n=%d: the Lagrangian with a fixed background vector in place of e^%d is not invariant, and its Euler operator in xi is not zero' % (n, n - 1))
        tick('n=%d field %d' % (n, k))

def main():
    head('GSB-NOETHER: Noether\'s second theorem for the Einstein-Cartan action, finite form' + (' [fault %s]' % FAULT if FAULT else '') + (' [quick: n = 6 skipped]' if QUICK else ''))
    part_B(3, [3101, 3102, 3103], F(1, 3))
    part_B(4, [4101, 4102], F(1, 3))
    part_A(5, 5207, F(1, 3))
    if not QUICK: part_A(6, 6006, F(1, 3))
    finish('GSB-NOETHER')

if __name__ == '__main__': main()
