# 04 — The bit-rule labelling of the rows

The scheme itself is `labelling/SCHEME.md` (read it first; it is short). This file says how to finish applying it, how to merge, and how the result drives the app.

## 1. What the labelling is, in three sentences

Each row is labelled by the set of primitive notions it uses (29 generators; a 29-bit mask; equivalently a square-free product of the first 29 primes). Each generator has an intrinsic square: +1 if the rule supplies the notion, −1 if it is imported from the literature, 0 if it is an input; so a row has a signature (p, q, r) and a grade (popcount), and the empty label is ℝ, the starting point. On top of the label, the physicist adds stage/type/phenomena and a physics name, the mathematician adds field/kind and a mathematical name, and both record the logical relations between rows (derives, equiv, instance, uses-input, cycle, contradicts).

## 2. State of the passes (10 Oct 2026, 15:00) — all ten done and merged; see `docs/labelling/JUDGE_LOG.md`. The table below records the state when this book was written.

| chunk | rows | content | physicist | mathematician |
|---|---|---|---|---|
| A | 142 | rule, cells, conventions/clock, Maxwell, shapes, lens-tab inputs | to do | to do |
| B | 172 | the equations page, steps 2–16, tally | to do | to do |
| C | 156 | finite groups, category lens | **done** (`out/phys_C.jsonl`; outline `.md` to do) | to do |
| D | 143 | Baez chapter | to do | **done** (`out/math_D.jsonl` + `math_D.md`) |
| E | 176 | Schuller chapter, Furey, Map, researchers, Ask | 80/176 done (`out/phys_E.jsonl`, resume) | to do |

Chunks: `labelling/chunks/chunk_{A..E}.json` (rows with id, group, page, tab, anchor, flags, standardRef, checkedBy, lines, links, theorems); `theorems.json`, `questions.json` for context. Personas: `labelling/PERSONA_PHYSICIST.md`, `labelling/PERSONA_MATHEMATICIAN.md` (exact output format inside).

## 3. Running a pass with a smaller model

A pass is one persona × one chunk. It needs no tools except reading three files and appending to two. Any model that can hold ~60 k tokens of input and write JSON reliably can do it; split a chunk in two (rows 1–80, 81–end) if the model's context is smaller, keeping the same output file.

Prompt (verbatim, fill the brackets):

> Read, in this order: `labelling/SCHEME.md`, `labelling/PERSONA_[PHYSICIST|MATHEMATICIAN].md`, then `labelling/chunks/chunk_[X].json` in full. For context you may read `labelling/chunks/theorems.json` and `questions.json`. Label every row as the persona file says. Output: `labelling/out/[phys|math]_[X].jsonl` (one JSON object per row per line; append in batches of about 20) and `labelling/out/[phys|math]_[X].md` (sections A, B, C). A row that is only about the Atlas itself (counts, credits, what a page shows) gets `notions: ["i-meta"]` and `type: "reading"`, `stage: "M"` (physicist) or `kind: "meta"` (mathematician). Do not run scripts, do not search the web, do not write anywhere else. When done, reply with the number of rows written, the five hubs with most dependants, the three most important missing pieces, and anything contradictory.

After each pass: `python3 labelling/validate_labels.py labelling/out/phys_A.jsonl labelling/chunks/chunk_A.json` must print `0 problems` (it checks completeness, duplicates, the 29 codes, the enums, the relation names). Fix by asking the same model to append the missing rows or correct the named ones; never edit the jsonl by hand without recording it.

Resuming chunk E (physicist): tell the model that the first 80 rows (up to `LNS-024`) exist in the file and must be kept; it appends the remaining 96 in chunk order.

Budget: a pass took the larger model 300–600 k tokens including reading. A smaller model will be cheaper per token; expect 10 passes + 1 outline ≈ the cost of reading 2 MB of text eleven times plus writing ~1.5 MB of JSON.

## 4. Merging

`python3 labelling/merge_labels.py` (already written and tested on the three finished passes) reads every `out/*.jsonl`, joins them to `matrix/atlas_matrix_v1.json` and writes:

- `labelling/labels_merged.json`: per row the union of notions with provenance (`agreed`, `onlyPhys`, `onlyMath`), signature, grade, mask, prime, cells, stage/type/phenomena, fields/kind, both homes, notes, dependencies with provenance, derived status, address;
- `labelling/graph.json`: edges by relation, hubs (most derived-from), leaves, equivalence classes (union–find over `equiv`), the longest derivation chains, cycles found in `derives` (to resolve or to declare as loops), declared loops and contradictions, neighbours at Hamming distance 1;
- `labelling/labelling_stats.md`: the readable summary (status counts, notion usage, signatures, grades, agreement between personas, hubs, chains, contradictions, the personas' notes).

Partial runs are fine: unlabelled rows are carried with status `unlabelled`.

## 5. The judge's step (resolving the two labellings into one)

Do this once all ten passes exist; it is a reading task, not a modelling task. Rules, applied in order, recorded in `labelling/JUDGE_LOG.md` (row id → decision → reason):

1. **Notions.** Keep the union. Where one persona alone added an `i-…` input or an `s-…` import, keep it (the other persona did not see a dependency; the row does carry it). Where the two differ on a rule notion (`+1`), keep both unless the row text plainly does not use one of them; then record the removal.
2. **Kind vs type.** They are two axes and both stay. Conflicts to resolve: physicist `derivation` with mathematician `reading` (keep `reading`: a reading is not a derivation); physicist `identity` with mathematician `range` (keep `range` for the kind, `identity` for the type; the status does not change); physicist `calibration` with mathematician `computation` (both stay).
3. **Relations.** Keep the union of edges. A `contradicts` from either persona is kept and listed for the author. A cycle found by the merge in `derives` is either (a) two rows that restate each other → change both edges to `equiv`, or (b) a definition and the theorem justifying it → declare `cycle` and keep, or (c) a mistake → remove the weaker edge; record which.
4. **Homes.** Keep both; the mode switch picks one.
5. **Cells.** Union.
6. **Notes.** Every persona note that says a row's status looks wrong becomes a `review` note on the row in the register (not a change of the row).

Expected scale, from the finished passes: ~1 note per 8 rows; 2 contradictions in 379 rows; 0 cycles so far; 221 `equiv` + 200 `derives` edges per 156 rows (physicist, category chunk).

## 6. What the labelling gives the app

- **Order inside a section**: physics mode sorts by `stage` then `shownOn.order`; mathematics mode by `kind` rank (definition < construction < lemma < theorem < range < classification < invariant < example < counterexample < computation < reduction < reading < conjecture < question < dead-end < pointer < meta) then field; the "grade" lens sorts by popcount (from zero outward).
- **The hero of a page** defaults to the hub of the page's rows (most `derives` dependants), overridable in `pages.json`.
- **"Rests on" and "leads to"** in the drawer: the `derives`/`instance`/`uses-input` edges in and out; the chain the row sits in; its equivalence class ("the same statement in n places" — these are the restatements the pages repeat today and V2 shows once).
- **Neighbours**: rows one notion away (same mask ± one bit), grouped by the notion that differs: "add the null generator and you get …", "drop the input and you get …". This is the navigation the brief calls "a way to connect elements we would not reach easily".
- **The address** (`cell · (p,q,r) · stage/kind · prime`) in the drawer and the register; search by notion ("every row that uses `clk` and `nul`"), by signature ("rows with r = 0": the rule and the literature alone), by grade.
- **Candidates**: the missing pieces of section C of every persona outline become rows `CAND-001…` with status `candidate`, their linked rows and their checkability; they render only in the Logbook ("what the fields expect next to these rows") until the author decides to make them rows with evidence. The finished passes give 25 (mathematician, Baez chapter) and the category and Schuller/Furey outlines will add more.

## 7. Worked example (from the finished passes)

`LNB-006` "Cl(5,5) ≅ End(Λℝ⁵) ≅ M₃₂(ℝ); so(10) = 10 + 25 + 10" — mathematician: notions `lbl sq clk mod biv tns`, cells `(5,5,0)`, kind `computation`, home "Cl(5,5) ≅ End(Λℝ⁵); 3-grading of so(10) of type D III", depends `T20 (instance)`, `LNB-015 (equiv)`. Signature (6,0,0): the rule alone; grade 6; address `(5,5,0) · (6,0,0) · ?/computation · 2·5·13·23·29·31`. Status: proved-by-atlas (its check ran). Neighbours: drop `clk` → the Fock-space rows of T20; add `src` → the Baez paper rows that cite it.

`LAB-020` (W(A_n) = S_{n+1} on the even subalgebra) — physicist: notions `lbl grd qf tns fin`, stage A, type `symmetry`, home "permutation symmetry of the generators", depends `T5 (derives)`, `T9 (instance)`. Signature (5,0,0).

`PAG-013` (a source list) — physicist: notions `src i-meta`, stage M, type definition, note "a source list, not a claim". Status: meta; no badge; Logbook only.

What the first 379 labelled rows show: the most used notions are `lbl` (159 rows), `src` (161: the lens chapters compare papers line by line), `nul` (115), `mod` (91), `grd` (85), `sq` (77), `biv` (73), `s-phy` (70), `lat` (69); signatures (3,0,0), (2,1,0), (4,0,0) lead; 37 rows are meta, 83 open, 7 cited, 163 proved by the Atlas. The mathematician's outline of the Baez chapter reorders it entirely (theorem Cl(n,n) = End Λ first, its instance second; the Jordan rows as one section instead of four tabs; "the empty ring" as a lemma, not a chapter) — exactly the kind of reorganisation V2's mathematics mode performs by sorting on `kind` and `field`.

## 8. Extending to five agents later

The scheme does not change. A topology persona and a combinatorics persona would add `fields` votes and homes; the merge takes unions. Do it only after the two-persona merge is accepted by the author; the marginal value is in the missing pieces (section C), where topology (bordism, Pin⁻ surfaces, finite spaces) is thin in the Atlas today.
