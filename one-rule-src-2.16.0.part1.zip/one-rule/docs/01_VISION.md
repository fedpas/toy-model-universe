# 01 — Vision

## The app in one paragraph

**ONE RULE** (working title; alternatives below) is a web atlas that shows how one labelling — blades of a Clifford algebra as bit masks, products by XOR with a sign — reaches, step by step and with a check at every step, the cells of the algebra, their clock, two known pieces of physics (light, and one generation of matter), gravity, mechanics, and the languages of several branches of mathematics and of several researchers. It starts at ℝ = Cl(0,0,0), the empty label, and never claims more than its scripts recompute. A reader sees results; a researcher opens the drawer and finds every check, source and open question behind them.

## Name

Working title **ONE RULE**, subtitle *an atlas of cells, clocks and lenses*. It says what the Atlas is (one construction), reads well in both modes, and leaves "Cascade Atlas" free as the name of the author's earlier package. Alternatives if the author prefers: **MOD EIGHT** (the clock), **CELLS & CLOCKS**, **THE EMPTY LABEL**. The name appears once, in the shell; pages do not repeat it. Decision for the author.

## Who it is for, and what each gets

| reader | setting | what the default view gives them |
|---|---|---|
| a curious person, a student before university | learner | plain words, no formulas, the pictures, one sentence per result, the honest badges |
| a physicist | physics · research | the chain algebra → kinematics → fields → dynamics → calibration, each statement with its physics name, formulas on, evidence one click away |
| a mathematician | mathematics · research | the same rows ordered definition → lemma → theorem → classification by field, with their mathematical names |
| a researcher of one field, or a reader of one author | any + a lens | every statement renamed in that field's or author's terms, the figures redrawn in that notation, the dictionary and the matrix of that lens |
| the author and his agents | Logbook | the register of rows with addresses, evidence, dependencies, readings, leads; how to add a row, a check, a lens |

## The three switches

1. **Mode: Physics | Mathematics.** Same rows, two orders and two vocabularies. Physics orders by stage (algebra → kinematics → fields → dynamics → observation) and names each statement by its physics home ("tetrad postulate", "Birkhoff"). Mathematics orders by field and kind (definition → lemma → theorem → classification → example) and names by the mathematical home ("Brauer–Wall class", "Arf–Brown–Kervaire invariant"). Texts may carry a mode variant; most are shared.
2. **Level: Research | Learner.** Research shows formulas (KaTeX) and full texts. Learner shows only rows that have a learner text, in plain words, with no formula anywhere on the page (numbers and words are allowed), and the same badges in plain words. The v15 Young Learner layer is the seed of the learner texts.
3. **Lens: none | branch | shape | researcher | labels | convention.** A lens renames (through its dictionary), reorders within a section (by its own grading when it has one), and redraws figures that support it. Registered lenses at launch:
   - branches: algebra, geometry, topology, category theory, combinatorics;
   - shapes (the four views of a label and the polytopes): Clifford, simplex, cube, prime, orthoplex, demicube, Gosset;
   - researchers: Furey, Baez, Schuller, Hestenes & Lasenby–Doran–Gull, Dorst–De Keninck–Gunn (PGA), Roelfs–Eelbode, Tian, Majkić, Pumplün, Hsu–Barker–Hobson–Lasenby;
   - labels: bits (base 2), primes, signature word (base 3), bit × square (base 6);
   - conventions: Space + / Time + (the mirror), Cl(1,3) vs Cl(3,1), the sign of the source, κ vs κ_H vs κ_G naming.
   A lens with no text for a row shows the row in the Atlas's own words with a small "no <lens> reading yet" mark in the drawer, never a silent fallback in the body. Lenses with many missing texts are filled by the translation protocol (`09_TRANSLATION_PROTOCOL.md`), reviewed, and shipped as `draft` until the author accepts them.

## Principles that decide every later choice

1. **From zero outward.** Navigation and ordering follow the grade of the rows: what uses fewer notions comes first; the empty label is the first page. The dependency graph (the needs strips of v15 plus the `derives` edges of the labelling) is the map of the app.
2. **Results first; evidence one click away; data two clicks away.** Section = hero (one sentence, one figure) + results (statements) + one drawer. The Logbook holds everything else.
3. **One badge, five words.** `open`, `not yet proved here`, `our reading`, `needs an input`, `new`. Nothing on standard-and-recomputed statements.
4. **Every statement is a row; every number comes from a stored check result.** Nothing shown as a number is typed by hand (the author's rule, kept).
5. **Figures are statements too.** A figure that states a law takes its caption from a row and declares which lenses it can redraw in; the figure's engine is the author's (ported), with a Python twin.
6. **The author can change a sentence in one place.** Correcting a text means editing one text record; the page follows at the next build; a test fails if a page emits a sentence that is not a row.
7. **Honesty beats completeness.** Where a chain has a gap (a step that is only cited, an input that is not derived, a page with no learner text), the gap is shown as a gap, not papered over.

## Site map

```
/                     Zero — the empty label, the rule in one screen, the three switches
/rule                 The rule — product, sign, squares; the four views; the playground
/cells                The lattice of cells (25 cards) → /cells/p,q[,r]  one cell
/clock                Step 1 — the Z4 form, the clock, the mirror, the triple, the trinity
/light                Calibration 1 — Maxwell (views, charges, ladders)
/steps                The twenty steps by stage → /steps/<id>  (comm, mirrors, dirac, spin, coupling, ym, matter, grav1, grav2, projective, gauge, nullsurf, forque, spring, rigid, groups, category, baez, schuller)
/shapes               Orthoplex, demicube, Gosset (also a lens family)
/matter               Calibration 2 — Furey (dictionary, papers, the 2026 model, three generations, what may help)
/lenses               Lens rooms index → /lenses/<key>  (dictionary, matrix column, rows seen through the lens)
/logbook              Register of rows · theorems · questions · sources · checks · reports · analyses · leads (new) · replication · bench · method
/ask                  The guide (chat), answering from the rows
/glossary             Terms, in both levels
```

Hash routing (`#/steps/grav2`, `#/cells/1,3`) keeps the app a static site. Settings (mode, level, lens, theme) live in the shell and in the address as plain tokens (`#/steps/grav2?m=math&l=learner&lens=cat`) so a link reproduces a view.

## Four journeys that must work on day one

1. **Learner, phone.** Opens `/`, reads the one-screen rule in plain words, taps "light", sees the four-view picture and three plain results with their badges, opens nothing else. No formula anywhere. (Acceptance: a test renders every page at level=learner and fails on any KaTeX node or on a row without a learner text in the body.)
2. **Physicist, laptop.** Opens `/steps/grav2`, reads the hero (the Einstein form is the e-variation of the Einstein–Cartan action; one figure), the eight results of step 10 with their physics names and no badges except two (`needs an input: κ`, `our reading`), opens the drawer: the identities, the sampling bound, the eight scripts, the Christoffel route, the controls, the mutation table, the rows it depends on. Switches to mathematics mode: the same rows reordered (definitions of the frame bundle objects first), with their mathematical homes.
3. **Category theorist with the lens.** Opens `/cells`, sets lens = category: cards say "Brauer–Wall class" and "super-opposite"; the lens room shows the 33 dictionary rows and the matrix column of the category report; rows without a category reading say so in the drawer.
4. **The author adding a result.** Writes one row and its texts (research + learner) in the content files, attaches the check id of a script that ran, runs the build: the row appears where its page and section say, with the right badge, in the register, in the graph. Nothing else to touch. (Acceptance: the handover doc walks through this with a real v16 row.)

## What V2 drops from v15, on purpose

- The three-audience copy with Italian slots (English only; learner replaces Young Learner; the Physicist/Mathematician split becomes the mode switch).
- The per-tab "at a glance" and "needs/inputs" strips as prose (their content becomes the drawer's "needs" list and the dependency map).
- Badges on every line and the CSS reader filter (status is data; the filter is a query).
- The five patch layers of the 25 cards (`nodes` → sector-translations → node-metadata → storyOverrides → ylAtlas); only the audited title, type and readings survive as rows; the old role names become a convention lens the author can keep or retire (decision for the author).
- The 8.4 MB eager bundle (per-page data chunks; Python mirrors fetched only on download).
- Repetition: a statement said five times on a page (the Furey count, the Λ sign, "a calibration is a run on something whose answer is known") is one row shown once, linked elsewhere.
