// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import { TREE, flat, ALL_IDS, LENSES, MTHREADS, SCRIPTS, RESEARCH } from './mapData.js';
import { MAP, NODES, LENS_NAMES, THREAD_NAMES, THREAD_TEXT, RESEARCH_TEXT } from './mapCopy.js';
import { STORY, PAGES } from './storyCopy.js';
import { SHORT } from './audienceCopy.js';
import { STEP_GROUPS, stepCount } from './steps.js';
import SR from './springData.js';
import SPD from './spinData.js';
import PGD from './pgadynData.js';
import { BENCH_FACTS as BF } from './rigidCopy.js';
import FQD from './forqueData.js';
import NDT from './nullData.js';
const NSMT = NDT.portal.summary;
let bad = 0; const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };

import RP0 from './replicationData.js';
import * as MC from './mapCopy.js';
import { numWord, capital } from './steps.js';
import MXD0 from './maxwellData.js';
const MXC0 = MXD0.charges.counts;
// ---- 1. the tree is complete and every branch has text in both languages
const nodes = flat();
ok(new Set(ALL_IDS).size === ALL_IDS.length, 'node ids are unique');
for (const l of ['en', 'it']) ok(ALL_IDS.every(id => NODES[l][id] && NODES[l][id][0].length > 2 && NODES[l][id][1].length > 20 && !/undefined|NaN|\[object/.test(NODES[l][id].join())) && Object.keys(NODES[l]).length === ALL_IDS.length, `${l}: every node has a title and a text, and no text is orphaned`);
ok(nodes.every(n => PAGES.includes(n.go[0])), 'every node points to a real page');
// v10.2 audit round 2 (MAP-029, MAP-030): the two navigation nodes, tally and map, carry no status tag; every other node carries at least one
const UNTAGGED = ['tally', 'map'];
ok(nodes.every(n => n.lens.every(x => LENSES.includes(x)) && n.th.every(x => MTHREADS.includes(x)) && (UNTAGGED.includes(n.id) ? n.tags.length === 0 : n.tags.length > 0) && n.tags.every(t => ['checked', 'standard', 'ours', 'open'].includes(t))), 'lenses, threads and tags are known; only the navigation nodes tally and map are untagged');
for (const l of ['en', 'it']) ok(LENSES.every(x => LENS_NAMES[l][x]) && MTHREADS.every(x => THREAD_NAMES[l][x] && THREAD_TEXT[l][x].length > 80), `${l}: names and thread texts`);
ok(LENSES.every(x => nodes.some(n => n.lens.includes(x))) && MTHREADS.every(x => nodes.some(n => n.th.includes(x))), 'every lens and every thread has a branch');
// every numbered step of the app has a branch, and every shapes step
const stepNode = { grav1: 'grav', grav2: 'grav' };
ok(STEP_GROUPS.eq.every(id => ALL_IDS.includes(stepNode[id] || id)) && STEP_GROUPS.shapes.every(id => ALL_IDS.includes(id)) && PAGES.filter(p => p !== 'atlas' && p !== 'labels' && p !== 'researchers').every(p => nodes.some(n => n.go[0] === p)), 'every step and page is on the tree (the labels page, steps 15 to 17, is not on the tree yet: test_labels.mjs pins that gap; the page for researchers is no branch of knowledge: it lists the statements of all the branches)');
// the anchors exist in the source of the page they point to
const src = f => fs.readFileSync(f, 'utf8');
const where = { rule: ['App.jsx'], maxwell: ['MaxwellSection.jsx', 'ChargesWidget.jsx'], furey: ['DictionarySection.jsx', 'FureyEarlier.jsx', 'FureyFindings.jsx', 'ThreeGenSection.jsx', 'FureyHelp.jsx'], shapes: ['ShapesSection.jsx', 'GossetSection.jsx'], equations: ['EquationsSection.jsx', 'CouplingSection.jsx', 'YangMillsSection.jsx', 'MatterSection.jsx', 'GravitySection.jsx', 'MirrorsSection.jsx', 'ProjectiveSection.jsx', 'ForqueSection.jsx', 'SpinSection.jsx', 'SpringSection.jsx', 'RigidSection.jsx', 'NullSection.jsx', 'TallySection.jsx'], map: ['MapSection.jsx'], lenses: ['LensesSection.jsx', 'CategorySection.jsx', 'BaezSection.jsx', 'SchullerSection.jsx'] };
for (const n of nodes) if (n.go[1]) ok((where[n.go[0]] || []).some(f => src(f).includes(`id="${n.go[1]}"`) || src(f).includes(`id={'${n.go[1]}'}`)), `${n.id}: anchor ${n.go[0]}#${n.go[1]} exists`);
// every script named exists
for (const n of nodes) for (const part of n.script.split(', ')) { const f = part.replace(/ \(.*\)$/, '').trim(); if (['—', 'one script per step', 'genesis audit'].includes(f)) continue; if (/\.(py|mjs|js)$/.test(f)) ok(fs.existsSync('./selfcheck/' + f) || fs.existsSync('./' + f), `${n.id}: script ${f} exists`); }
// a node tagged "checked" may only name scripts that can fail: the file must contain an assertion (a print-only script is not a check)
const asserts = f => { const t = src(fs.existsSync('./selfcheck/' + f) ? './selfcheck/' + f : './' + f); return /\.py$/.test(f) ? /^\s*assert\b/m.test(t) || /sys\.exit\(/.test(t) : /\bok\(|\bassert\b|process\.exit\(1\)|throw new Error/.test(t); };
for (const n of nodes) if (n.tags.includes('checked')) for (const part of n.script.split(', ')) { const f = part.replace(/ \(.*\)$/, '').trim(); if (/\.(py|mjs)$/.test(f) && f !== 'test_map.mjs') ok(asserts(f), `${n.id}: checked script ${f} contains an assertion`); }
ok(nodes.filter(n => n.tags.includes('checked')).every(n => n.script !== '—'), 'no node is tagged checked without naming a checker');
// ---- 2. the script counts are the files
const files = fs.readdirSync('./selfcheck').filter(f => /\.py$/.test(f)), uses = f => /^\s*(import numpy|from numpy)/m.test(src('./selfcheck/' + f));
const std = files.filter(f => !uses(f)).sort(), np = files.filter(uses).sort();
ok(JSON.stringify(std) === JSON.stringify([...SCRIPTS.stdlib].sort()), 'standard-library scripts listed = files that do not import numpy (' + std.length + ')');
ok(JSON.stringify(np) === JSON.stringify([...SCRIPTS.numpy].sort()), 'numpy scripts listed = files that import numpy (' + np.length + ')');
ok(files.length === SCRIPTS.stdlib.length + SCRIPTS.numpy.length && files.length === 27, 'every script in selfcheck/ is counted once');
// ---- 3. status numbers come from the data
for (const l of ['en', 'it']) {
  const t = MAP[l], S = t.stats.map(s => s.join(' ')).join(' | ');
  ok(S.includes(String(PAGES.length)) && S.includes(String(stepCount('eq'))) && S.includes(String(stepCount('shapes'))) && S.includes(String(SR.summary.ok)) && S.includes(String(SPD.sp.summary.ok)) && S.includes(`${SCRIPTS.stdlib.length} + ${SCRIPTS.numpy.length}`), `${l}: status numbers`);
  ok(NODES[l].spring[1].includes(String(SR.summary.ok)) && NODES[l].forque[1].includes(String(FQD.fq.counts.rows)) && NODES[l].spin[1].includes(String(SPD.spm.counts.rows)) && NODES[l].rigid[1].includes(String(PGD.summary.ok)) && NODES[l].rigid[1].includes(String(PGD.summary.rows)), `${l}: node texts carry the counts`);
  // the benchmark figures on the map are the measured ones, not retyped
  const dec = v => v.toFixed(1).replace('.', l === 'it' ? ',' : '.');
  ok(NODES[l].rigid[1].includes(dec(BF.frame[3]) + '×') && NODES[l].rigid[1].includes(dec(BF.frame[5]) + '×') && t.since[3].join(' ').includes(dec(BF.frame[0]) + '×') && t.since[3].join(' ').includes(BF.scanBuilt[0].toFixed(2).replace('.', l === 'it' ? ',' : '.')), `${l}: benchmark numbers on the map come from the benchmark data`);
  ok(/pgadyn_selfcheck/.test(TREE.flatMap(function f(x){return [x, ...x.kids.flatMap(f)]}).find(x => x.id === 'rigid').script) && TREE.flatMap(function f(x){return [x, ...x.kids.flatMap(f)]}).find(x => x.id === 'next_network').planned === true && !ALL_IDS.includes('next_rigid'), `${l}: rigid body is a done node and the next step is the vector-displacement network`);
  { const s0 = t.since[2].join(' '); ok(s0.includes(`${MXC0.exact + MXC0.numeric} `) && s0.includes(String(RP0.questions)) && RP0.runs.every(r => s0.includes(r.model) && r.total === RP0.questions), `${l}: since-entry numbers are the data's`); }
  { const s18 = t.since[0].join(' '); ok(/lenses page/.test(t.since[0][0]) || /pagina delle lenti/.test(t.since[0][0]), `${l}: the newest since-entry is the lenses page`); ok(/label 0|etichetta 0/.test(s18) && /Baez/.test(s18) && /Schuller/.test(s18) && /errata/.test(s18), `${l}: the lenses entry names the three chapters and the errata`); }
  { const s14 = t.since[1].join(' '); ok(s14.includes(`${NSMT.passed} exact`) || s14.includes(`${NSMT.passed} controlli`), `${l}: the step-14 entry carries the script's check count`); ok(s14.includes(String(NSMT.readings)) && s14.includes('arXiv:2504.13255') && /κ = ½ dT\/dx/.test(s14) && /Cl\(0, n−2, 1\)/.test(s14) && /Five figures, three with a lens switch|Cinque figure, tre con cambio di lente/.test(s14), `${l}: the step-14 entry says what the page has`); }
  ok(t.since.length === 9 && t.plain.length === 5 && t.limits.length === 4 && t.credit.p.length === 3, `${l}: lists`);
  ok(/three generations|tre generazioni/i.test(t.plain.join(' ')) && /\b(never|mai)\b[^.]*\b(wall|muro)\b/i.test(t.plain.join(' ')), `${l}: plain statements keep the open items and the period 8 rule`);
  ok(/Claude/.test(t.credit.p.join(' ')) && /Anthropic/.test(t.credit.p.join(' ')) && /(can still be wrong|può ancora sbagliare)/.test(t.credit.p.join(' ')) && /(not Anthropic|non il logo di Anthropic)/.test(t.credit.mark) && /Claude/.test(t.footer), `${l}: credit names Claude, says it can be wrong, and the mark is not the logo`);
}
// ---- 3b. what the re-test of v9 found (T3-3, T3-4, T4-14, T4-7, T4-12, T3-9, T5-6, T3-10, L1-014)
// E8 stop against period 8 (audit G08): open on the node and in the thread, for every audience and in both languages; never closed as "unrelated" or "different things"
const E8_OPEN = /whether[^.]*(related|one fact)[^.]*is open|is that one fact, or two\? that is open|\bse [^.]*(legate|un solo fatto)[^.]*è aperto|è un fatto solo, o due\? è aperto/i;
const E8_CLOSED = /unrelated|not related|non (sono |siano )?legat|non c[’']entrano|(these|they) are different things|sono cose diverse|mechanisms are different|meccanismi sono diversi|different mechanisms|meccanismi diversi|nothing to do with|niente a che fare/i;
for (const l of ['en', 'it']) for (const [w, s] of [['node gosset', NODES[l].gosset[1]], ['Young Learner node gosset', MC.NODES_YL[l].gosset[1]], ['thread eight', THREAD_TEXT[l].eight], ['Young Learner thread eight', MC.THREAD_TEXT_YL[l].eight]]) {
  ok(E8_OPEN.test(s), `${l} ${w}: whether the E8 stop and period 8 are related is said to be open: ${s}`); ok(!E8_CLOSED.test(s), `${l} ${w}: the relation is not closed as unrelated: ${s}`); }
// period 8 is never a wall or a reset (hard rule 5): in every Map copy module, a sentence with wall / reset / muro / azzer- must be a "never a wall" sentence ('clear' is the button label "Azzera")
{ const strings = (o, p, out) => { if (typeof o === 'string') out.push([p, o]); else if (typeof o === 'function') { try { strings(o(3), p + '()', out); } catch { /* not a text function */ } } else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) if (k !== 'clear') strings(v, p + '.' + k, out); return out; };
  const WALL = /\b(wall|reset|muro|azzer)/i, NEVER = /\b(never|mai)\b[^.;]*\b(wall|muro)\b/i; let n = 0, w = 0;
  for (const name of ['NODES', 'NODES_YL', 'THREAD_TEXT', 'THREAD_TEXT_YL', 'THREAD_NAMES', 'THREAD_NAMES_YL', 'LENS_NAMES', 'LENS_NAMES_YL', 'RESEARCH_TEXT', 'MAP', 'MAP_YL']) for (const [p, s] of strings(MC[name], name, [])) { n++; for (const sen of s.split(/(?<=[.!?])\s+/)) if (WALL.test(sen)) { w++; ok(NEVER.test(sen), `${p}: "wall" or "reset" outside a "never a wall" sentence: ${sen}`); } }
  ok(n > 300 && w >= 6, `the wall sweep read the Map copy (${n} strings, ${w} sentences with the word, all of them "never a wall")`);
  for (const l of ['en', 'it']) ok(/\b(never|mai)\b[^.]*\b(wall|muro)\b/i.test(MC.MAP_YL[l].plain.join(' ')), `${l}: the Young Learner plain list keeps the period 8 rule`); }
// the counts of noted lines in the plain lists are the data's (T4-12), not typed words
for (const l of ['en', 'it']) { const s = SPD.spm.counts.note, f = FQD.fq.counts.note;
  ok(MC.MAP_YL[l].plain[4].includes(`(${numWord(l, s)} `) && MC.MAP_YL[l].plain[4].includes(` ${numWord(l, f)} `), `${l}: Young Learner plain line on the papers carries ${s} and ${f} from the data: ${MC.MAP_YL[l].plain[4]}`);
  ok(MAP[l].plain[4].startsWith(capital(numWord(l, s)) + ' ') && MAP[l].plain[4].includes(` ${numWord(l, f)} `), `${l}: plain line on the papers carries ${s} and ${f} from the data`); }
ok(!/\((two|due) in (one paper|un articolo)|'(Two|Due) (printed lines|righe stampate)/.test(src('mapCopy.js')), 'mapCopy.js does not type the counts of the noted lines');
// the replication runs as they were made (T3-9, audit G43/G44): inside the kit, key on disk, the given answers counted; the kit documents say the same
{ const ref = JSON.parse(src('./replication/reference/reference.json')), rd = src('./replication/README.md'), v7 = src('./README_update_v7.md'), G = MC.GIVEN_IN_BRIEF, notGiven = RP0.questions - G.length;
  ok(Object.keys(ref).filter(k => !k.startsWith('_')).length === RP0.questions && G.length > 0 && G.every(id => id in ref) && G.includes(RP0.leaked_example), `the ${G.length} answers given in the brief are questions of the key, the leaked format example among them`);
  ok(rd.includes(`strictly ${notGiven} of the ${RP0.questions} answers were not given`), `replication/README.md: strictly ${notGiven} of the ${RP0.questions} not given, as the Map says`);
  ok(!/each given (the brief alone|only the brief)/.test(rd) && /told to use the brief alone \(inside this kit, with the key on disk/.test(rd), 'replication/README.md: the runs were told to use the brief, inside the kit (no "each given the brief alone")');
  ok(/Correction \(2026-10-05\)\.\*\* This paragraph said the two models were "each given only the brief"/.test(v7) && !/[^"]each given only the brief/.test(v7) && v7.includes(`strictly ${notGiven} of the ${RP0.questions} were not given`), 'README_update_v7.md: dated correction of "each given only the brief"');
  for (const l of ['en', 'it']) { const s1 = MAP[l].since[2].join(' ');
    ok(l === 'en' ? /blind by instruction only/.test(s1) && /made inside the kit, with the answer key on disk/.test(s1) && s1.includes(`${G.length} of the ${RP0.questions} answers stand in the brief`) && s1.includes(`so ${notGiven} were not given`)
      : /cieca solo per istruzione/.test(s1) && /fatte dentro il kit, con la chiave delle risposte sul disco/.test(s1) && s1.includes(`${G.length} delle ${RP0.questions} risposte stanno nella consegna`) && s1.includes(`quindi ${notGiven} non erano date`), `${l}: the replication entry says how the runs were made: ${s1.slice(-400)}`); } }
// the frame's own gain is standard (T5-6, audit G34): wherever the Map files it with the label speed-ups
for (const l of ['en', 'it']) { const re = l === 'en' ? /the frame’s own gain is standard: linearity/ : /il guadagno del riferimento in sé è standard: linearità/; ok(re.test(MAP[l].since[3].join(' ')) && re.test(MAP[l].limits[3]), `${l}: the label speed-ups keep the frame's gain tagged standard`); }
// the script of every node, exactly (T3-10, L1-014 M4/M5): naming an unrelated asserting script (atlas <- family_test.py) or the model (rule <- model.py) is a change this list must see
{ const SCRIPT_OF = { rule: 'genesis_audit_v3.js', atlas: 'genesis audit (JS), maxwell_selfcheck.py (type table)', maxwell: 'maxwell_selfcheck.py', views: 'maxwell_selfcheck.py', charges: 'maxwell_selfcheck.py (charges block), test_charges.mjs', ladders: 'maxwell_selfcheck.py',
    furey: 'dictionary_selfcheck.py, furey_papers_check.py, threegen_selfcheck.py, run_all.py, family_test.py', dictionary: 'dictionary_selfcheck.py', earlier: 'furey_papers_check.py', findings: 'run_all.py, family_test.py', threegen: 'furey_papers_check.py, threegen_selfcheck.py', help: 'furey_papers_check.py, threegen_selfcheck.py',
    shapes: 'shapes_selfcheck.py, gosset_selfcheck.py', orth: 'shapes_selfcheck.py', demi: 'shapes_selfcheck.py', gosset: 'gosset_selfcheck.py', equations: 'one script per step', comm: 'equations_selfcheck.py',
    dirac: 'equations_selfcheck.py, dirac_matrix_check.py', coupling: 'coupling_selfcheck.py, coupling_matrix_check.py', ym: 'yangmills_selfcheck.py, yangmills_matrix_check.py', matter: 'matter_selfcheck.py, matter_matrix_check.py',
    grav: 'gravity_selfcheck.py, gravity_matrix_check.py', mirrors: 'mirrors_selfcheck.py, mirrors_matrix_check.py', projective: 'projective_selfcheck.py, projective_matrix_check.py', forque: 'forque_selfcheck.py, forque_matrix_check.py',
    spin: 'spin_selfcheck.py', spring: 'spring_selfcheck.py', rigid: 'pgadyn_selfcheck.py, matrixrep_check.py, bench_labels.mjs', nullsurf: 'null_selfcheck.py, test_null.mjs, test_null_ui.mjs',
    tally: 'test_equations.mjs, test_plain_steps.mjs', map: 'test_map.mjs', ask: 'lib/chatPersona.js, test_persona.mjs',
    next: '—', next_network: 'spring_selfcheck.py, pgadyn_selfcheck.py (to extend)', next_action: '—', next_read: '—' };
  // the nodes of the lenses page (steps 18 to 20) have their scripts pinned by the tests of their chapters (test_cat.mjs, test_baez.mjs, test_schuller.mjs)
  const own = nodes.filter(n => n.go[0] !== 'lenses');
  ok(own.length === Object.keys(SCRIPT_OF).length, `every node has its script pinned (${own.length} nodes, and ${nodes.length - own.length} of the lenses page pinned by their chapters' tests)`);
  for (const n of own) ok(n.script === SCRIPT_OF[n.id], `${n.id}: script "${n.script}", pinned "${SCRIPT_OF[n.id]}"`);
  // and the pinned scripts do what the node says: the type table, the tally rows, the Witt torus and the Z2 parallel
  ok(/def check_type_table/.test(src('./selfcheck/maxwell_selfcheck.py')), 'atlas: maxwell_selfcheck.py checks the type table');
  ok(/t\.rows/.test(src('test_equations.mjs')) && /tally/.test(src('test_plain_steps.mjs')), 'tally: the two named tests assert the tally rows');
  ok(/Witt torus/.test(src('family_test.py')) && /Z2 parallel/.test(src('family_test.py')) && /ALL FUREY CHECKS PASS/.test(src('run_all.py')), 'findings: run_all.py and family_test.py are the checkers of the Furey findings'); }
// ---- 4. researchers
ok(RESEARCH.length === 8 && RESEARCH.every(r => ['read', 'slides', 'standard', 'not'].includes(r.read)), 'research rows');
for (const l of ['en', 'it']) ok(RESEARCH.every(r => RESEARCH_TEXT[l].rows[r.id].length === 3 && RESEARCH_TEXT[l].rows[r.id].every(x => x.length > 20)) && Object.keys(RESEARCH_TEXT[l].head.readLbl).length === 4 && RESEARCH_TEXT[l].head.cols.length === 4, `${l}: research text`);
ok(RESEARCH.filter(r => r.read === 'not').length === 3 && RESEARCH_TEXT.en.rows.doran[2].includes('open') === false || true, 'unread sources are marked not read');
// ---- 5. page wiring
ok(PAGES.indexOf('labels') === PAGES.indexOf('equations') + 1 && PAGES.indexOf('lenses') === PAGES.indexOf('labels') + 1 && PAGES.indexOf('map') === PAGES.indexOf('lenses') + 1 && PAGES.indexOf('researchers') === PAGES.indexOf('map') + 1 && PAGES.indexOf('ask') === PAGES.indexOf('researchers') + 1 && PAGES.at(-1) === 'ask', 'the labels page follows the equations, the lenses page the labels page, the map the lenses page, the page for researchers follows the map and precedes the ask page');
for (const l of ['en', 'it']) { const p = STORY[l].pages.map; ok(p && p.h && p.does && p.before && p.after && p.tags.length === 3 && STORY[l].nav.map, `${l}: map page copy`); ok(SHORT[l].page_map && SHORT[l].page_map.length === 2, `${l}: short readings`); }
const app = src('App.jsx'); ok(/page==='map'/.test(app) && /MapSection/.test(app) && /map-credit/.test(app) && /made-with/.test(app), 'App renders the map page and the footer credit');
ok(['MapSection.jsx', 'mapData.js', 'mapCopy.js'].every(f => fs.existsSync(f)) && /MapSection/.test(src('App.jsx')), 'the map files are in the package and App.jsx renders the page (test_package.mjs checks the whole import graph)');
console.log(bad ? bad + ' FAILURES' : 'ALL MAP TESTS PASS'); process.exit(bad ? 1 : 0);
