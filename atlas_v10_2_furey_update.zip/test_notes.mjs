// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The "Notes to the researcher" (v10.1 add-on, researcherNotes.js): the data behind the pop-up that opens with  ?for=<name>.
//  - every link of a note is a real page/tab of the atlas; every tag is one of the four; the tab ids are read from StoryShell.jsx, so a renamed tab breaks this test, not a reader's click;
//  - the numbers a note quotes are the numbers the atlas itself holds (the ledger of lib/chatPersona.js, the engine of step 17), so a note cannot drift from its page;
//  - every person named as "mentioned in the atlas" is, in fact, named in an atlas source; Ablamowicz (read for steps 15-17) is named on the For researchers page (sources) since v10.2, so the note no longer carries the flag;
//  - the language is the atlas's: checked / standard / ours / open, no claim about nature, no markup that the plain pop-up would print raw;
//  - the file ships no e-mail address (the addresses are private, in outreach_private/, outside the package: test_license.mjs forbids them here).
// Run: node test_notes.mjs
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs';
import { RESEARCHERS, ALIASES, HISTORICAL, TAG_NAMES, NOTE_TEXT, slugOf, noteOf } from './researcherNotes.js';
import { PAGES } from './storyCopy.js';
import { STEP_GROUPS } from './steps.js';
import * as E from './labelsEngine.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8');

// the tabs of each page, from the source of the router
const subsSrc = rd('StoryShell.jsx').match(/export const SUBS = (\{[^\n]*\});/)[1];
const SUBS = new Function('STEP_GROUPS', 'return ' + subsSrc)(STEP_GROUPS);
ok(Object.keys(SUBS).length >= 5 && SUBS.furey.includes('threegen') && SUBS.equations.includes('nullsurf') && SUBS.labels.includes('gauge'), 'the tab table could be read from StoryShell.jsx');
const goOk = go => { const [p, s, ...rest] = go.split('/'); return rest.length === 0 && PAGES.includes(p) && (s === undefined || (SUBS[p] || []).includes(s)); };

// ---- 1. structure
// the tags of a stop of the reading path (v10.2): a list from the four, in the order standard, checked, ours, open; a stop that only points to a page
// carries none, and those stops are exactly the ones listed here (audit round 2, RSN-009)
const ORDER = ['standard', 'checked', 'ours', 'open'], UNTAGGED = ['dorst: Step 11, pointors and spin (De Keninck, Roelfs, Eelbode)'];
const tagsOk = ts => Array.isArray(ts) && ts.every(k => TAG_NAMES.includes(k)) && ts.join() === ORDER.filter(k => ts.includes(k)).join();
ok(UNTAGGED.every(w => RESEARCHERS.some(r => r.note && r.note.path.some(p => r.slug + ': ' + p.title === w && Array.isArray(p.tags) && p.tags.length === 0))), 'the stops without a tag are exactly the listed pointers');
ok(RESEARCHERS.length === 13 && RESEARCHERS.filter(r => r.priority === 'send').length === 8 && RESEARCHERS.filter(r => r.priority === 'hold').length === 5, 'eight groups to write now, five on hold');
ok(new Set(RESEARCHERS.map(r => r.slug)).size === RESEARCHERS.length && RESEARCHERS.every(r => r.id === r.slug && /^[a-z]+$/.test(r.slug)), 'one slug per group, letters only (it goes into the address: ?for=slug)');
ok(Object.entries(ALIASES).every(([a, b]) => /^[a-z]+$/.test(a) && RESEARCHERS.some(r => r.slug === b && r.note)), 'every alias points to a group that has a note');
ok(slugOf('Eelbode') === 'roelfs' && slugOf('FUREY') === 'furey' && slugOf('de-keninck') === 'dorst' && slugOf('nobody') === null && slugOf('') === null && slugOf(null) === null && slugOf('todd') === null, 'slugOf: names, case, aliases, unknown, empty, and groups without a note');
ok(RESEARCHERS.every(r => (r.priority === 'send') === !!r.note) && noteOf('furey') && !noteOf('todd'), 'a note exists exactly for the groups to write now');
for (const r of RESEARCHERS) {
  const t = `[${r.id}]`;
  ok(r.people.length >= 1 && r.people.every(p => p.name && p.affil && ['to', 'cc'].includes(p.role)) && r.people.some(p => p.role === 'to'), `${t} people: a name, an affiliation, a role, and someone to write to`);
  ok(/^Dear /.test(r.salutation) && /,$/.test(r.salutation) && r.work && r.subject.length <= 120 && r.subject.length >= 20, `${t} salutation, work, subject (20-120 characters)`);
  ok(r.hooks.length === (r.priority === 'send' ? 3 : 2), `${t} three points for a letter to send, two for one on hold (${r.hooks.length})`);
  for (const h of r.hooks) ok(TAG_NAMES.includes(h.tag) && goOk(h.go) && h.text.length >= 60 && h.text.length <= 330, `${t} a point: a tag, a real link (${h.go}), 60-330 characters (${h.text.length})`);
  ok(r.hooks.reduce((n, h) => n + h.text.length, 0) <= 1000, `${t} the three points together stay under 1000 characters (the letter must stay short)`);
  if (r.note) {
    const n = r.note;
    ok(n.lead.length > 80 && n.path.length >= 3 && n.path.every(p => tagsOk(p.tags) && (p.tags.length >= 1 || UNTAGGED.includes(r.slug + ': ' + p.title)) && goOk(p.go) && p.title && p.what.length > 40), `${t} note: a lead, at least three stops, each with its tags (none only for a listed pointer), a real link, a title and a sentence`);
    ok(n.path.every(p => !p.parts || (p.parts.length >= 2 && p.parts.every(x => tagsOk(x.tags) && x.tags.length >= 1 && x.text.length > 40) && p.what === p.parts.map(x => x.text).join(' ') && p.tags.join() === ORDER.filter(k => p.parts.some(x => x.tags.includes(k))).join())), `${t} note: a stop made of parts reads as their text joined, with their tags united`);
    ok(n.path.every(p => (p.parts || [p]).every(x => !x.tags.includes('ours') || !/deriv/i.test(x.text || x.what))), `${t} note: a statement tagged ours never says derived`);
    ok(n.standard.length > 80 && /Standard/.test(n.standard) && /Open/.test(n.standard), `${t} note: says what is standard and what is open`);
    ok(n.check.length >= 1 && n.check.every(c => c.length > 30) && n.unread.length > 10, `${t} note: says where we may be wrong and what we have not read`);
    ok(n.path.some(p => p.tags.includes('checked')) && n.path.every(p => !p.tags.includes('derived')), `${t} note: something checked, nothing called derived`);
  } else ok(r.hooks.some(h => h.tag === 'open') && r.hooks.every(h => h.go === 'map' || goOk(h.go)), `${t} a hold letter admits in one point that the work has not been read`);
}

// ---- 2. language: no claim about nature, no raw markup, no address
const strings = [];
const walk = (v, where) => { if (typeof v === 'string') strings.push([where, v]); else if (Array.isArray(v)) v.forEach((x, i) => walk(x, where + '[' + i + ']')); else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) if (typeof x !== 'function') walk(x, where + '.' + k); };
walk(RESEARCHERS, 'R'); walk(NOTE_TEXT, 'T'); walk(HISTORICAL, 'H');
const CLAIM = /\b(prove[sd]?|proof of|proves|confirm(s|ed)?|discover(s|ed)?|breakthrough|revolution\w*|predicts?|explains? the standard model|derives? the standard model)\b/i;
const sentencesWithClaim = strings.filter(([, s]) => CLAIM.test(s)).filter(([, s]) => !/(nothing|not|no|never|does not|do not|without)\b[^.]{0,60}\b(prove|predict|derive|confirm)/i.test(s) && !/nothing predicts|predicts anything|not (a )?(theory|prediction)/i.test(s));
ok(sentencesWithClaim.length === 0, 'no sentence claims a proof, a confirmation, a discovery or a prediction (only denials of them): ' + sentencesWithClaim.slice(0, 2).map(([w, s]) => w + ': ' + s.slice(0, 60)).join(' | '));
ok(strings.every(([, s]) => !/[_^]\{|\\\\|<\/?[a-z]+>|\bTODO\b|\bXXX\b/i.test(s)), 'no raw markup (_{ ^{ tags) in a plain pop-up text: ' + strings.filter(([, s]) => /[_^]\{|<\/?[a-z]+>/i.test(s)).slice(0, 2).map(([w]) => w).join(','));
ok(strings.every(([, s]) => !/[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+\.[A-Za-z]{2,}/.test(s)), 'no e-mail address in the data');
for (const f of ['researcherNotes.js', 'ResearcherNote.jsx']) ok(!/[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}/.test(rd(f)), `${f} ships no e-mail address`);
ok(strings.some(([, s]) => /Claude/.test(s)) && NOTE_TEXT.who.includes('AI model') && /What this is not: a theory of nature/.test(NOTE_TEXT.scope), 'the note says that an AI helped build the atlas and that it is not a theory of nature');

// ---- 3. the atlas names the people it is said to name
const SRC = fs.readdirSync(PKG).filter(f => /\.(js|jsx)$/.test(f) && !/^(researcherNotes\.js|ResearcherNote\.jsx|build_label_bench\.mjs)$/.test(f)).map(f => rd(f)).concat(rd('lib/chatPersona.js')).join('\n');
const surname = n => n.replace(/^(\S+)\s+/, '');   // "Steven De Keninck" -> "De Keninck"
for (const r of RESEARCHERS) for (const p of r.people) {
  const named = SRC.includes(surname(p.name));
  if (r.inAtlas === false) ok(!named, `${p.name} is flagged as not named in the atlas, and is not: if the atlas now cites this person, drop the flag and the sentence in the note that says so`);
  else ok(named, `${p.name} is named in an atlas source`);
}
ok(RESEARCHERS.find(r => r.id === 'ablamowicz').note.lead.includes('has not compared it line by line'), 'the Ablamowicz note says that the atlas lists the paper but has not compared it line by line');
ok(HISTORICAL.length >= 20 && HISTORICAL.every(n => n.length > 5), 'the historical list is a list of names');

// ---- 4. the numbers of the notes are the numbers of the atlas
const P = rd('lib/chatPersona.js'), flat = RESEARCHERS.map(r => r.hooks.map(h => h.text).join(' ') + ' ' + (r.note ? r.note.path.map(p => p.what).join(' ') + r.note.standard + r.note.check.join(' ') : '')).join('\n');
const pin = (re, what) => ok(re.test(P), 'the atlas ledger holds: ' + what);
const cites = (re, what) => ok(re.test(flat), 'a note quotes: ' + what);
pin(/5582 admissible 8-dimensional blocks/, 'Furey: 5582 admissible 8-dimensional blocks'); cites(/5,582 admissible 8-dimensional blocks/, 'Furey: 5,582 blocks');
pin(/at most one complete set fits[^.]*three first fit at dimension 14/, 'Furey: at most one complete set at dimension 8, three first at 14'); cites(/at most one complete Standard Model set[\s\S]{0,160}three sets first fit at 14 complex dimensions/, 'Furey: one set, three sets first at 14');
pin(/ranks \(2,6,4,2,1,1\)/, 'Furey: Peirce ranks (2,6,4,2,1,1)'); cites(/ranks \(2,6,4,2,1,1\)/, 'Furey: ranks');
pin(/616 of 18480 candidate quadruples/, 'Furey: 616 of 18480 quadruples'); cites(/616 of 18,480/, 'Furey: 616 of 18,480');
pin(/41-row translation matrix[^:]*: 27 agree exactly, 9 agree after a noted correction[\s\S]{0,400}5 not checked/, 'Forque: 41 rows, 27 / 9 / 5'); cites(/41 rows, 27 agree exactly, 9 need a small adjustment[^.]*5 are not checked/, 'Forque: 27 / 9 / 5 of 41');
pin(/110 claims in 56 rows/, 'rigid body: 110 claims in 56 rows'); cites(/110 claims in 56 rows/, 'rigid body: 110 claims in 56 rows');
pin(/30 rows: 22 agree exactly, 2 agree after a noted correction, 6 not checked/, 'spinors: 30 rows, 22 / 2 / 6'); cites(/30 rows, 22 agree exactly, 2 after a noted correction, 5 are not checked, and the probability reading is computed for Cl\(3,0\) only/, 'spinors: 22 / 2 / 5 of 30 and the probability reading computed for Cl(3,0) only');
pin(/64 computed checks, 64 pass/, 'null surfaces: 64 computed checks'); cites(/64 checks/, 'null surfaces: 64 checks');
pin(/κ for five horizons: 1\/6, 1\/8, −1\/2, 0, 3\/10/, 'null surfaces: κ for five horizons'); cites(/dφ\/dt = a\/\(r₊² \+ a²\) = 1\/30/, 'Kerr: 1/30');
pin(/dφ\/dt=a\/\(r₊²\+a²\)=1\/30/, 'null surfaces: Kerr dφ/dt = 1/30');
pin(/759 octads, any 5 points in exactly one, M₂₄ order 244823040, 196560 Leech vectors/, 'Golay: 759 octads, M₂₄, Leech'); cites(/759 octads[^.]*244,823,040[^.]*196,560 Leech/, 'Golay: 759, 244,823,040, 196,560');
pin(/Weyl first nonzero at n=4 \(20=10\+10\)/, 'curvature: Weyl first non-zero at n = 4, 20 = 10 + 10'); cites(/Weyl first non-zero at n = 4 \(20 = 10 \+ 10\)/, 'curvature: 20 = 10 + 10');
pin(/61\.35°/, 'Maxwell charges: the perihelion advance 61.35°'); cites(/61\.35°/, 'Maxwell charges: 61.35°');
pin(/Cl\(0,n−2,1\)|Cl\(0,n−2,1\)/, 'null surfaces: the algebra Cl(0,n−2,1)'); cites(/Cl\(0,n−2,1\)/, 'null surfaces: Cl(0,n−2,1)');
const idx = n => E.RAILS.A[n][2] / E.RAILS.A[n][1];
ok(idx(6) === 8 && idx(7) === 64 && idx(8) === 960 && [2, 3, 4, 5].every(n => idx(n) === 1), 'engine: S_{n+1} fills O(Q) for n = 2…5 and has index 8, 64, 960 at n = 6, 7, 8');
cites(/index 8, 64, 960 at n = 6, 7, 8/, 'Ablamowicz: index 8, 64, 960');
ok(E.golay().octads.length === 759 && E.golay().hist[8] === 759, 'engine: the Golay code has 759 octads');

console.log(bad ? `${bad} FAILURES of ${checks}` : `ALL NOTES TESTS PASS: ${checks} checks`);
process.exit(bad ? 1 : 0);
