// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML, PKG } from './paths.mjs';
process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import { stepCount, stepTotal, STEP_OFFSET } from './steps.js';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import { PAPERS, FC as FUREY_FC } from './fureyCopy.js';
import fs from 'fs';
import { MENU_SECTOR_LIST, getCompleteDualMetricDisplayData } from './matrixData.js';
// Audit of language and audience: every page, EN/IT, three audiences.
//  1. step numbering is derived: "PAGE k OF 8", "STEP k OF N" (equations, N from steps.js), "STEP k OF 3" (shapes), in order, in both languages
//  2. the introduction of each page and section differs between the three audiences (the mathematician reads the full text)
//  3. Italian pages contain no English prose (code, equations, commands and a short allow-list excepted); SVG labels and the lens names are searched too
//  3c. (v10.2) English data on an Italian page (the statements, theorems and sources of the page for researchers, which have no Italian text) is marked
//      lang="en" and skipped by 3 and 3b, but only inside a section that says so in Italian (.lang-note): an unannounced lang="en" block is an error
//  3b. Italian pages contain no English labels: a visible text node (also SVG text) that reads exactly as on the English page and holds an English word
//      is an error, whatever its length (ROW 3, lens, NODES, Play). Words that are the same in both languages (names, notation, blade, bit, ...) are allowed.
//  4. the control bar and the chat labels are localised
//  5. a report of text blocks that are the same in EN and IT, and sections whose lede does not vary by audience
const PAGES=['rule','atlas','maxwell','furey','shapes','equations','labels','lenses','map','researchers','ask'], PROF=['Young Learner','Physicist','Mathematician'];
const SEL='p, li, td, th, h1, h2, h3, h4, h5, summary, button, label, small, .tag, figcaption, svg text';
const SKIP='pre, code, .fq-code, textarea, input, .chat-answer, .katex, script, style, .brand, main [lang="en"]';
const EN_W=['the','and','of','is','with','for','that','this','are','from','each','which','not','can','you','your','one','all','when','where','what','how'];
const IT_W=['il','lo','la','le','gli','di','del','della','dei','delle','e','che','per','con','un','una','uno','è','sono','non','come','da','nel','nella','si','più','ogni','dove','quando','cosa','tu','tuo','alla','dal','al'];
// phrases that are allowed to stay in English inside an Italian page (names of files, models, products, code identifiers)
const ALLOW=[/^(Claude Opus|OpenAI o3)$/, /selfcheck|\.py|\.json|python3|numpy|run_all/, /^(EN|IT)$/, /^Download /, /ganja/, /Dorst|De Keninck|Furey|Hestenes|Gosset|Cartan|Coxeter/, /· arXiv[: ]\d{4}\.\d{4,5}$/];   // the last one: the title of a paper stays in the language it was published in
// 0. static: no copy file writes a step number by hand (they are all derived in steps.js)
const errs0=[]; for(const f of fs.readdirSync('.').filter(f=>/(Copy|Section)\.(js|jsx)$/.test(f))){ const t=fs.readFileSync(f,'utf8'); if(/eyebrow: '(STEP|PASSO) \d/i.test(t))errs0.push(f+': a hand-written step eyebrow'); if(/\bnav: ?\[?'(Step|Passo) \d/.test(t))errs0.push(f+': a hand-written step in a nav label'); }
// 0b. static: the Italian atlas records (25 cells x 3 audiences x Spatial/Temporal, as the page shows them) contract "di/da/in/su/a" with an article
//     ("della cella", not "di la cella": T3-11) and say "1 generatore", not "i 1 generatori"
{ const its=[]; const walk=(x,p,d=0)=>{ if(d>6)return; if(typeof x==='string')its.push([p,x]); else if(x&&typeof x==='object')for(const [k,v] of Object.entries(x))walk(v,p+'.'+k,d+1); };
  for(const it of MENU_SECTOR_LIST)for(const pr of ['Young Learner','Physicist','Mathematician'])for(const mm of ['Spatial','Temporal'])walk(getCompleteDualMetricDisplayData(it.id,'it',pr,mm),`${it.id}/${pr}/${mm}`);
  const BAD=/(?:^|[\s(«“])(?:di|da|in|su|a) (?:(?:il|lo|la|i|gli|le) |l['’]\p{L})|(?:^|\s)(?:i|gli) [01] \p{L}/u;
  if(its.length<1000)errs0.push(`only ${its.length} Italian atlas strings found`);
  for(const [p,s] of its){ const m=s.match(BAD); if(m)errs0.push(`${p}: Italian "${m[0].trim()}" (an article not contracted, or a plural with 0/1): ${s.slice(Math.max(0,m.index-20),m.index+50)}`); }
  // the plural article before a written number follows the number as it is spoken (V2-3): "gli" when the word starts with a vowel (otto, ottanta,
  // ottocento, ottomila: a leading 8; undici, undicimila: 11, 11 000, ...), "i" otherwise; the same for the articles joined to di/a/da/in/su
  const GLI={i:'gli',dei:'degli',ai:'agli',dai:'dagli',nei:'negli',sui:'sugli'}, PL=Object.fromEntries(Object.entries(GLI).flatMap(([a,b])=>[[a,a],[b,a]]));
  const vowelNumber=n=>/^8/.test(n)||/^11(?:\d{3})*$/.test(n);
  let nArt=0; for(const [p,s] of its) for(const m of s.matchAll(/(?:^|[\s(«“])(i|gli|dei|degli|ai|agli|dai|dagli|nei|negli|sui|sugli) (\d+) \p{L}/gu)){ nArt++; const base=PL[m[1]], want=vowelNumber(m[2])?GLI[base]:base;
    if(m[1]!==want)errs0.push(`${p}: Italian "${m[1]} ${m[2]}" should be "${want} ${m[2]}": ${s.slice(Math.max(0,m.index-20),m.index+50)}`); }
  if(nArt<20)errs0.push(`only ${nArt} articles before numbers found in the Italian atlas strings`); }
const b=await chromium.launch();const errs=[...errs0], report={sameInBoth:{}, lede:{}, english:{}};
const stats={};
async function visit(lang,prof,page,w=1100){
  const pg=await b.newPage({viewport:{width:w,height:900}});
  pg.on('pageerror',e=>errs.push(`${lang}/${prof}/${page}: ${e.message}`));
  await pg.goto(APP_HTML + '#'+page);await pg.waitForTimeout(250);
  if(lang==='it')await setLang(pg,'it');
  await pg.locator(`[data-profile="${prof}"]`).click();await pg.waitForTimeout(150);
  const grab=()=>pg.evaluate(([SEL,SKIP])=>{
    const blocks=[...document.querySelectorAll(SEL)].filter(e=>!e.closest(SKIP)&&!e.querySelector(SEL.replace(/ ,/g,','))).map(e=>(e.textContent||'').replace(/\s+/g,' ').trim()).filter(Boolean);
    const eyebrows=[...document.querySelectorAll('.eyebrow')].map(e=>e.textContent.trim());
    const ledes=[...document.querySelectorAll('section')].map(s=>({id:s.id||s.className,t:(s.querySelector('.lede')?.textContent||'').trim()})).filter(x=>x.t);
    const controls=(document.querySelector('.controls')?.textContent||'')+' | '+(document.querySelector('.controls')?.getAttribute('aria-label')||'');   // the text of the control bar, then its accessible name
    // every visible text node (SVG labels included), for the label check 3b
    const texts=[]; const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    for(let n=w.nextNode();n;n=w.nextNode()){ const p=n.parentElement; if(!p||p.closest('pre, code, .fq-code, textarea, input, script, style, .brand, .settings-pop, main [lang="en"]'))continue; if(!p.closest('svg')&&!p.getClientRects().length)continue; const t=n.nodeValue.replace(/\s+/g,' ').trim(); if(/[A-Za-z]{3}/.test(t))texts.push(t); }
    // 3c: the visible blocks marked lang="en" whose section carries no Italian note
    const enUnnoted=[...document.querySelectorAll('main [lang="en"]')].filter(e=>e.getClientRects().length&&!e.closest('section')?.querySelector('.lang-note')).map(e=>(e.textContent||'').trim().slice(0,60));
    return {blocks,eyebrows,ledes,controls,texts,enUnnoted,pageIntro:document.querySelector('.page-intro .lede')?.textContent||''};
  },[SEL,SKIP]);
  // every fold and every expandable row (spin, forque, spring, rigid tables: their detail is drawn only when open) is opened before the page is read (T2-5)
  const look=async()=>{ for(let k=0;k<2;k++){ await pg.evaluate(()=>{ document.querySelectorAll('details').forEach(d=>{d.open=true;}); document.querySelectorAll('main button[aria-expanded="false"]').forEach(x=>{ if(!x.closest('.story-nav'))x.click(); }); }); await pg.waitForTimeout(120); } stats.opened=(stats.opened||0)+await pg.locator('main [aria-expanded="true"]').count(); return grab(); };
  // a page with tabs is visited tab by tab, in order, and the results are put together
  const tabs=await pg.locator('.tabbar [role=tab]').evaluateAll(es=>es.map(e=>e.dataset.tab));
  let data=await look(); data.views={'':data.texts}; if(tabs.length){ const acc={...data,blocks:[],eyebrows:[data.eyebrows[0]],ledes:[],views:{},enUnnoted:[]}; for(const id of tabs){ await pg.locator(`.tabbar [data-tab="${id}"]`).click(); await pg.waitForTimeout(120); const d=await look(); acc.blocks.push(...d.blocks); acc.enUnnoted.push(...d.enUnnoted); acc.eyebrows.push(...d.eyebrows.slice(1)); acc.ledes.push(...d.ledes); acc.views[id]=d.texts; } data=acc; }
  await pg.close();return data;
}
const words=t=>t.toLowerCase().match(/[a-zà-ú’']+/g)||[];
const isEnglishProse=t=>{ if(ALLOW.some(r=>r.test(t))) return false; const w=words(t); if(w.length<6) return false; const en=new Set(w.filter(x=>EN_W.includes(x))), it=new Set(w.filter(x=>IT_W.includes(x))); return en.size>=2&&it.size<=1; };
const seen={};
for(const lang of ['en','it']) for(const page of PAGES) for(const prof of PROF){
  const d=await visit(lang,prof,page); seen[`${lang}/${page}/${prof}`]=d;
}
// ---- 1. numbering
for(const lang of ['en','it']) for(const page of PAGES) for(const prof of PROF){
  const d=seen[`${lang}/${page}/${prof}`], P=lang==='en'?'PAGE':'PAGINA', S=lang==='en'?'STEP':'PASSO', O=lang==='en'?'OF':'DI';
  const tag=`${lang}/${page}/${prof}`;
  if(!d.eyebrows.includes(`${P} ${PAGES.indexOf(page)+1} ${O} ${PAGES.length}`))errs.push(`${tag}: page eyebrow missing: ${d.eyebrows.slice(0,3)}`);
  const steps=d.eyebrows.filter(e=>new RegExp(`^${S} \\d+`).test(e));
  const want={shapes:stepCount('shapes'),equations:stepCount('eq'),labels:stepCount('labels'),lenses:stepCount('lens')}[page]||0, off={labels:STEP_OFFSET.labels,lenses:STEP_OFFSET.lens}[page]||0, tot=page==='labels'?stepTotal('labels'):page==='lenses'?stepTotal('lens'):want;
  if(steps.length!==want)errs.push(`${tag}: ${steps.length} step eyebrows, expected ${want}`);
  steps.forEach((e,i)=>{ if(!e.startsWith(`${S} ${off+i+1} ${O} ${tot} · `))errs.push(`${tag}: step eyebrow ${i+1} reads "${e}"`); });
  if(d.eyebrows.some(e=>new RegExp(`^${S} \\d+ ·`).test(e)))errs.push(`${tag}: an eyebrow with a step number but no total`);
  // 4. controls
  // v10.2: the title "Presentation matrix" was removed from the control bar (page-1 clean-up); the bar keeps its localised accessible name
  const want4=lang==='en'?['AUDIENCE','METRIC','| Presentation controls']:['PUBBLICO','METRICA','| Controlli di presentazione'];
  for(const x of want4) if(!d.controls.includes(x))errs.push(`${tag}: control label "${x}" missing in "${d.controls.slice(0,80)}"`);
  if(/Presentation matrix|Matrice di presentazione/.test(d.controls))errs.push(`${tag}: the removed title of the control bar is back`);
  if(lang==='it'&&/LANGUAGE|AUDIENCE|METRIC\b|Presentation/.test(d.controls))errs.push(`${tag}: English control label in Italian`);
}
// ---- 2. the introductions differ by audience
for(const lang of ['en','it']) for(const page of PAGES){
  const [a,p,m]=PROF.map(x=>seen[`${lang}/${page}/${x}`]);
  const pi=[a.pageIntro,p.pageIntro,m.pageIntro]; if(new Set(pi).size!==3)errs.push(`${lang}/${page}: the page introduction does not vary by audience`);
  const ids=new Set([...a.ledes,...p.ledes,...m.ledes].map(x=>x.id));
  for(const id of ids){ const get=d=>d.ledes.find(x=>x.id===id)?.t||''; const t=[get(a),get(p),get(m)]; if(t.some(x=>!x))continue; if(new Set(t).size!==3){ (report.lede[`${lang}/${page}`]??=[]).push(id); if(!/^(atlas-hero|explorer-intro|chat)/.test(id)) errs.push(`${lang}/${page}/${id}: lede does not vary by audience`); } }
}
// ---- 3. no English prose in Italian
for(const page of PAGES) for(const prof of PROF){
  for(const t of seen[`it/${page}/${prof}`].blocks){ if(isEnglishProse(t)) { const k=t.slice(0,140); (report.english[`${page}`]??=new Set()).add(k); } }
}
for(const [pg,set] of Object.entries(report.english)) for(const t of set) errs.push(`it/${pg}: English prose: ${t}`);
// ---- 3c. a block marked lang="en" on an Italian page sits in a section that says, in Italian, that it is in English
for(const page of PAGES) for(const prof of PROF){ const u=seen[`it/${page}/${prof}`].enUnnoted; if(u.length)errs.push(`it/${page}/${prof}: ${u.length} blocks marked lang="en" in a section without an Italian note (.lang-note): ${u.slice(0,3).join(' | ')}`); }
// ---- 3b. no English labels in Italian: a text node identical on the English page that holds a word which is not shared by both languages
const SHARED=new Set(`clifford cl dirac maxwell furey gosset witt peirce cartan dieudonné coxeter hestenes dorst keninck lasenby todd holmer mann joan hamish freya stephen
 claude opus openai anthropic yang mills gauss ampère faraday lorentz weyl ricci riemann bianchi einstein sitter anti kerr schwarzschild hooke runge kutta euler newton pauli
 majorana hamilton fano petrie hamming study spin pin span dim det end hom ric ref dual last max min cos sin cosh sinh sqrt exp log diag const mask join wedge meet forque
 forques blade blades bit bits boost boosts standard algebra gauge irrep pointor pointors python numpy json ganja pga cga sta replica english italiano yvon takabayasi
 dzhanibekov picard cayley killing laplace jacobi atiyah bott shapiro lawson michelsohn lie spinor spinors txy txz tyz xyz txw tyw tzw xyw xzw yzw txyz abcd agbgcg
 bivector bivectors octonion octonions fig affine script anti-de schmangle bub uwu xor eps
 roadmap trialities superalgebra tri coleman mandula pati salam neutrino tau arxiv ii iii`.split(/\s+/).filter(Boolean));   // eps: the ASCII name of ε in the forque script's notation (seen once the rows are opened); the last line: names of Furey's papers and of two particles, which are the same words in Italian
const englishWord=t=>(t.match(/[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ’'-]{2,}/g)||[]).map(x=>x.toLowerCase().replace(/[’'-]+$/,'')).find(x=>!SHARED.has(x)&&!/^[ijk]?[0-9]*$/.test(x));
const TITLES = [...PAPERS.map(p => p.ty), ...Object.values(FUREY_FC.en.earlier.papers).map(p => p.t)].map(t => new RegExp('^' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$'));   // the titles of published papers stay in the language they were published in
const LABEL_ALLOW=[/\.(py|json|mjs|js|cjs)\b/, /^python3 /, /^· #/, /“[^”]*”|«[^»]*»/, ...TITLES];
for(const page of PAGES) for(const prof of PROF){
  const en=seen[`en/${page}/${prof}`].views, it=seen[`it/${page}/${prof}`].views;
  for(const v of Object.keys(it)){ const E=new Set(en[v]||[]); for(const t of new Set(it[v])){ if(!E.has(t)||LABEL_ALLOW.some(r=>r.test(t)))continue; const w=englishWord(t); if(w)(report.labels??={})[`${t.slice(0,90)}`]=(report.labels?.[t.slice(0,90)]||`it/${page}${v?'/'+v:''} (${w})`); } }
}
for(const [t,where] of Object.entries(report.labels||{})) errs.push(`${where}: English label in Italian: "${t}"`);
// ---- 5. report: text blocks identical in EN and IT (notation excepted)
const md=['# Language and audience audit','',`Pages: ${PAGES.join(', ')}; audiences: ${PROF.join(', ')}.`,''];
for(const page of PAGES){
  const en=new Set(PROF.flatMap(p=>seen[`en/${page}/${p}`].blocks)), it=new Set(PROF.flatMap(p=>seen[`it/${page}/${p}`].blocks));
  const same=[...en].filter(t=>it.has(t)&&words(t).length>=3&&/[a-zA-Z]{4,}/.test(t));
  report.sameInBoth[page]=same; md.push(`## ${page}: ${en.size} EN blocks, ${it.size} IT blocks; ${same.length} identical in both languages`,''); same.slice(0,60).forEach(t=>md.push('- '+t.slice(0,160))); md.push('');
}
md.push('## Introductions that do not vary by audience','',...Object.entries(report.lede).map(([k,v])=>`- ${k}: ${v.join(', ')}`),'');
// the report is a run log, written outside the package files (test_logs/, which run_tests.sh keeps and the package check skips)
fs.mkdirSync('./test_logs',{recursive:true}); fs.writeFileSync('./test_logs/i18n_audit_report.md',md.join('\n'));
const nSame=Object.values(report.sameInBoth).reduce((s,x)=>s+x.length,0);
if((stats.opened||0)<200)errs.push(`only ${stats.opened||0} expandable rows were open when the pages were read`);
console.log(`blocks identical in EN and IT (notation, names): ${nSame}; ${stats.opened} expandable rows read open; written to test_logs/i18n_audit_report.md`);
await b.close();console.log(errs.length?errs.slice(0,80):'I18N AUDIT OK');if(errs.length>80)console.log('... '+errs.length+' in all');process.exit(errs.length?1:0);
