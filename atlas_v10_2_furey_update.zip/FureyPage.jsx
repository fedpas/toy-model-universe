// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import DictionarySection from './DictionarySection.jsx';
import ThreeGenSection from './ThreeGenSection.jsx';
import FureyFindings from './FureyFindings.jsx';
import FureyEarlier from './FureyEarlier.jsx';
import FureyHelp from './FureyHelp.jsx';
import { TabBar, TabPanel, useSub } from './StoryShell.jsx';

// Test 2 (Furey) is five tabs that read one at a time: the dictionary, her papers, her 2026 model, the board of Fig. 1 and the count of three generations, and what may help her.
export default function FureyPage({ lang = 'en', profile = 'Young Learner', go }) {
  const [sub, setSub] = useSub('furey');
  return <><TabBar lang={lang} page="furey" active={sub} onPick={setSub} />
    <TabPanel lang={lang} page="furey" id={sub} onPick={setSub} goMap={go}>
      {sub === 'dictionary' && <DictionarySection lang={lang} profile={profile} />}
      {sub === 'earlier' && <FureyEarlier lang={lang} profile={profile} />}
      {sub === 'findings' && <FureyFindings lang={lang} profile={profile} />}
      {sub === 'threegen' && <ThreeGenSection lang={lang} profile={profile} />}
      {sub === 'help' && <FureyHelp lang={lang} profile={profile} />}
    </TabPanel></>;
}
