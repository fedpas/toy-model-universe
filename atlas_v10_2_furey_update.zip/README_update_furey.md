# Update: the Furey page (Test 2), rewritten

Copy these files over the v10.2 package (same paths), then `sh build.sh`.

Only the Furey page changes: five tabs (Dictionary, Her papers, Her 2026 model, Three generations, What may help), 17 widgets, copy in English and Italian for the three audiences (`fureyCopy.js`). The theme and every other page are untouched; the files outside the Furey page (`StoryShell.jsx`, `mapData.js`, `mapCopy.js`, `audienceCopy.js`, `storyCopy.js`, `researcherNotes.js`, `researchersData.js`, `lib/chatPersona.js`, `claimsData.js`, `claimsLocators.json`) only carry the new tab names, counts and script.

New check script: `selfcheck/furey_papers_check.py` (numpy, about 15 s, 30 checks); `sh selfcheck/regen_furey_papers.sh` rewrites `fureyPapersData.js` and its mirror.
Tests: `node test_furey_papers.mjs` (new), plus the updated `test_findings`, `test_threegen`, `test_map`, `test_license`, `test_persona`, `test_notes`, `test_audience`, `test_i18n_audit`, `test_theme_ui`. Run `sh run_tests.sh` after the build.
