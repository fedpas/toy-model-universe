// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Verified results of the explicit 16-dimensional model of Furey's 2026 paper (run_all.py -> furey_results.json; furey_papers_check.py -> furey_papers.json).
// Every number here is cross-checked against those JSON files by test_findings.mjs and test_furey_papers.mjs. The words of the five cards are in fureyCopy.js (findings.cards).
import { FC } from './fureyCopy.js';
export const REAL_BLOCKS = [2, 6, 4, 2, 1, 1];
export const COMPLEX_BLOCKS = [1, 3, 2, 1, 1];
export const BLOCK_NAMES = ['ℂ_𝕆', 'ℂ³_𝕆', 'ℂ²_ℍ', 'ℂ_ℂ', 'ℂ_last'];
export const BLOCK_COLORS = ['#61dff0', '#4fd18b', '#ffa06f', '#a78bfa', '#ffd166'];
export const NUMBERS = { realDiag: 62, realOff: 194, cxDiag: 16, cxOff: 48, deltaSM: 31, edgesTotal: 48, maxEdge: 12, generation: 16, replicas: 8, axes: 16, fanoLines: 7, quadruples: 18480, diagonalising: 616 };
// [a, b, capacityC, label, kind]: the ten edges between the five complex blocks. kind 'sm' = the six edges whose first labels in Fig. 1 are the fields of the first generation
// ((u,d)_L, u_R, d_R, (nu_e,e)_L, e_R, nu_eR), 'rep' = the four edges beyond one generation (b_R, h, (nu_tau,tau)_L, tau_R). The types are those of the irreps (see fureyPapersEngine.js).
export const EDGES = [
  [1, 2, 12, 'Q_L (3,2,+1/6) 6ℂ + Q̄_L', 'sm'],
  [1, 3, 6, 'u_R 3ℂ', 'sm'],
  [1, 4, 6, 'd_R 3ℂ', 'sm'],
  [0, 2, 4, 'L 2ℂ', 'sm'],
  [0, 3, 2, 'e_R 1ℂ', 'sm'],
  [0, 4, 2, 'ν_R 1ℂ', 'sm'],
  [0, 1, 6, 'b_R 3ℂ', 'rep'],
  [2, 3, 4, 'h 2ℂ', 'rep'],
  [2, 4, 4, 'L-like 2ℂ', 'rep'],
  [3, 4, 2, 'τ_R 1ℂ', 'rep']
];

const STATUS = {
  en: { verified: 'Verified by explicit construction', open: 'Open' },
  it: { verified: 'Verificato per costruzione esplicita', open: 'Aperto' }
};
// the reproduction note of the tab: one line (it is also the smallest formal block of the page, which test_yl_ui.mjs reads)
export const FINDINGS_UI = {
  en: { status: STATUS.en, repro: 'Reproduce: python3 furey_papers_check.py runs the 30 checks of the Furey page; python3 run_all.py prints ALL FUREY CHECKS PASS and writes furey_results.json; python3 family_test.py (the Witt torus and the Z₂ parallel) prints ALL FAMILY ASSERTIONS PASS and writes family_results.json.' },
  it: { status: STATUS.it, repro: 'Riproduzione: python3 furey_papers_check.py esegue i 30 controlli della pagina di Furey; python3 run_all.py stampa ALL FUREY CHECKS PASS e scrive furey_results.json; python3 family_test.py (il toro di Witt e il parallelo Z₂) stampa ALL FAMILY ASSERTIONS PASS e scrive family_results.json.' }
};

// the five cards, one per claim FUR-001 to FUR-005 (the locators of claimsLocators.json name them by id).
// flags: the tags of each card (checked / standard / ours / open); visual: the widget the tab draws beside it (peirce, edges, axes, none)
const META = [
  ['blocks', 'verified', ['checked'], 'peirce'],
  ['edges', 'verified', ['checked', 'open'], 'edges'],
  ['witt', 'verified', ['checked'], 'axes'],
  ['z2', 'open', ['checked', 'open'], 'none'],
  ['open', 'open', ['ours', 'open'], 'none']
];
const card = (lang, id) => { const c = FC[lang].findings.cards[id]; return { 'Young Learner': [c.t[0], c.yl], Physicist: [c.t[1], c.p], Mathematician: [c.t[2], (c.p + ' ' + c.m).trim()] }; };
export const FINDINGS = META.map(([id, status, flags, visual]) => ({ id, status, flags, visual, en: card('en', id), it: card('it', id) }));
