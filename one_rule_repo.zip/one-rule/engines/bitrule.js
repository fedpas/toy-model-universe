// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/bitrule.js — the one bit-rule kernel of V2 (07_ENGINES_FIGURES.md §1).
// A blade is a bit mask a; e_a e_b = s(a,b) e_{a xor b} with s(a,b) = (−1)^{#{(i in a, j in b): j < i}} · Π_{i in a&b} eps[i], eps[i] ∈ {+1, −1, 0}.
// The algorithm is that of researchers_checks/bitrule_A.py (N_pairs, s, mul), line for line; tests/kernel.test.mjs compares the two.
// Multivectors are Maps mask → coefficient; coefficients may be Numbers, BigInts or anything with the `num` adapter below (exact rationals through numeric.js).

export const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };

/** N(a,b) = #{(i,j): i ∈ a, j ∈ b, j < i} — the number of transpositions that sort the word ab. */
export function nPairs(a, b) {
  let c = 0, i = 0;
  while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; }
  return c;
}
/** (−1)^{N(a,b)} */
export const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
/** s(a,b): the reordering sign times the squares of the shared generators; 0 when a shared generator is null. */
export function sign(a, b, eps) {
  let v = reorderSign(a, b); let m = a & b, i = 0;
  while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; }
  return v;
}
/** the cell Cl(p,q,r) as a sign vector */
export const cell = (p, q, r = 0) => [...Array(p).fill(1), ...Array(q).fill(-1), ...Array(r).fill(0)];
/** numeric adapter: plain Numbers by default; pass {add, mul, scale, zero, isZero} for exact types */
export const num = { add: (x, y) => x + y, mul: (x, y) => x * y, scale: (s, x) => s * x, zero: 0, isZero: x => x === 0 };
/** product of two multivectors (Maps mask → coeff) in the cell eps */
export function mul(x, y, eps, N = num) {
  const out = new Map();
  for (const [a, ca] of x) for (const [b, cb] of y) {
    const s = sign(a, b, eps); if (s === 0) continue;
    const k = a ^ b, v = N.scale(s, N.mul(ca, cb));
    out.set(k, out.has(k) ? N.add(out.get(k), v) : v);
  }
  for (const [k, v] of out) if (N.isZero(v)) out.delete(k);
  return out;
}
export const add = (x, y, c = 1, N = num) => { const out = new Map(x); for (const [k, v] of y) { const w = N.scale(c, v); out.set(k, out.has(k) ? N.add(out.get(k), w) : w); } for (const [k, v] of out) if (N.isZero(v)) out.delete(k); return out; };
export const blade = (a, c = 1) => new Map([[a, c]]);
export const gen = i => blade(1 << i);
export const one = () => blade(0);
export const gradePart = (x, k) => new Map([...x].filter(([a]) => popcount(a) === k));
export const square = (a, eps) => sign(a, a, eps);
/** the full sign table S[a][b] of a cell (N = 2^n), as bitrule_A/clC build it */
export function signTable(eps) { const N = 1 << eps.length; const S = []; for (let a = 0; a < N; a++) { S.push(new Int8Array(N)); for (let b = 0; b < N; b++) S[a][b] = sign(a, b, eps); } return S; }

// ---- labels as lenses: the same mask printed in another base (02_CONTENT_MODEL.md §9, SCHEME §5). Nothing here changes the algebra. ----
export const PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131];
const SUB = '₀₁₂₃₄₅₆₇₈₉';
const sub = i => String(i).split('').map(d => SUB[+d]).join('');
/**
 * label(mask, lens, eps): 'bits' → "1011" (bit 0 on the right); 'primes' → "2·5·7" (the k-th generator is the k-th prime; 1 for the empty label);
 * 'clifford' → "e₁e₃e₄" (1-based, "1" for the scalar); 'sigword' → the cell as a word over +,−,0 with the blade's generators in capitals (base 3 on the cell, membership shown by case);
 * 'bitsq' → one digit per generator in base 6: 0 absent, 1 present with square +1, 2 present with square −1, 3 present with square 0 (then 4, 5 unused) — presence × square in one word;
 * 'set' → "{1,3,4}".
 */
export function label(mask, lens = 'clifford', eps = null) {
  const n = eps ? eps.length : Math.max(1, 32 - Math.clz32(mask || 1));
  const idx = []; for (let i = 0; i < n; i++) if ((mask >> i) & 1) idx.push(i);
  switch (lens) {
    case 'bits': return [...Array(n)].map((_, i) => ((mask >> (n - 1 - i)) & 1)).join('');
    case 'primes': return idx.length ? idx.map(i => PRIMES[i]).join('·') : '1';
    case 'set': return '{' + idx.map(i => i + 1).join(',') + '}';
    case 'sigword': return eps ? eps.map((e, i) => { const ch = e > 0 ? '+' : e < 0 ? '−' : '0'; return (mask >> i) & 1 ? `[${ch}]` : ch; }).join('') : label(mask, 'bits');
    case 'bitsq': return eps ? eps.map((e, i) => ((mask >> i) & 1 ? (e > 0 ? '1' : e < 0 ? '2' : '3') : '0')).join('') : label(mask, 'bits');
    default: return idx.length ? idx.map(i => 'e' + sub(i + 1)).join('') : '1';
  }
}
/** the inverse of label(·,'primes'): a square-free product of the first primes → mask */
export function maskFromPrimes(product) { let m = 0, p = typeof product === 'string' ? product.split('·').reduce((acc, f) => acc * BigInt(f.trim()), 1n) : BigInt(product); PRIMES.forEach((q, i) => { if (p % BigInt(q) === 0n) { m |= 1 << i; p /= BigInt(q); } }); if (p !== 1n) throw new Error('not a label: leftover ' + p); return m; }
