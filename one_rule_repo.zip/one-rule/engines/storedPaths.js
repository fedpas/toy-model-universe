// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/storedPaths.js — which blocks of the stored results of the check scripts the figures read (PARTS: key paths into each file) and where each file comes
// from (SOURCES: the file the script wrote under checks/selfcheck/, and the script). tools/migrate/figures_from_v15.mjs copies exactly these blocks, as they are,
// into engines/storedParts.js (the app bundles that, not the whole files: 08 §5 budget), and tests/engines.test.mjs compares every block with its file.
export const SOURCES = {
  GOSSET: 'checks/selfcheck/gosset.json (gosset_selfcheck.py)',
  PROJECTIVE: 'checks/selfcheck/projective.json (projective_selfcheck.py)',
  FUREY_PAPERS: 'checks/selfcheck/furey_papers.json (furey_papers_check.py)',
  PGADYN: 'checks/selfcheck/pgadyn.json (pgadyn_selfcheck.py)',
  NULL: 'checks/selfcheck/null.json (null_selfcheck.py)',
  GRAVITY: 'checks/selfcheck/gravity.json (gravity_selfcheck.py)',
  LENS_SCH: 'checks/selfcheck/reports/lens_sch_check.json (lens_sch_check.py)',
  LENS_BAEZ: 'checks/selfcheck/reports/lens_baez_check.json (lens_baez_check.py)',
  DICTIONARY: 'checks/selfcheck/dictionary.json (dictionary_selfcheck.py)',
};
/** the key paths each figure reads (figure → block): gosset-plane, extra-generator, ladders, pga-orbits, null-figures, bianchi-check, schuller-chain and bands,
 *  e8-ladder (baezEngine LADDER_PIECES), dictionary-boards */
export const PARTS = {
  GOSSET: [['coxeter'], ['rank']],
  PROJECTIVE: [['ladder']],
  FUREY_PAPERS: [['roadmap']],
  PGADYN: [['moon'], ['planets'], ['planets_data']],
  NULL: [['portal']],
  GRAVITY: [['identities'], ['einstein_identities'], ['sampling']],
  LENS_SCH: [['p1', 'cells'], ['p2', 'comb_E']],
  LENS_BAEZ: [['P3', 'dec']],
  DICTIONARY: [['states'], ['cartan'], ['channels']],
};
/** the file of a source (the path before the script's name) */
export const fileOf = name => SOURCES[name].split(' ')[0];
/** the block at a key path of an object (undefined when the path is not there) */
export const at = (obj, path) => path.reduce((o, k) => (o == null ? undefined : o[k]), obj);
/** the parts of a whole stored object: a copy holding only the blocks of PARTS[name], each as it is */
export function partsOf(name, whole) {
  const out = {};
  for (const p of PARTS[name]) { let to = out; p.forEach((k, i) => { if (i === p.length - 1) to[k] = at(whole, p); else to = to[k] = to[k] || {}; }); }
  return out;
}
