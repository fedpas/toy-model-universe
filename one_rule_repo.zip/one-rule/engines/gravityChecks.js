// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/gravityChecks.js — the stored results of the gravity checks that the gravity figures draw (einstein-form-identity, kerr-schild-f, horizon-first-law).
// Nothing is computed here: every number is copied from the log of the shipped run of its script (checks/selfcheck/gravity/logs/*.log), and tests/engines.test.mjs
// (sections I and J) reads the logs again and compares every number and every count. Exact results stay exact (rationals as strings); the floating ones are the
// values the logs print.

/** A4, a4_einstein_tensor.py: the engine's Einstein form E_a equals s_n (G − Λ_n δ) Θ for any frame (GRV-010). Exact on random non-vacuum polynomial frames; the
 *  floating-point third route (numpy, five-point finite differences) agrees with the exact Einstein tensor within the script's bound (allNum &= err < 1e-5). */
export const A4 = {
  script: 'checks/selfcheck/gravity/a4_einstein_tensor.py',
  log: 'checks/selfcheck/gravity/logs/a4_einstein_tensor.log',
  bound: 1e-5,
  cValues: ['0', '1/3', '-2/5'],
  cases: [
    { n: 3, frames: 6, ratio: -1, lambdaOverC: 1, fdRelErr: 1.4e-6 },
    { n: 4, frames: 4, ratio: -1, lambdaOverC: 3, fdRelErr: 1.2e-9 },
    { n: 5, frames: 2, ratio: -1, lambdaOverC: 6, fdRelErr: 2.2e-9 },
  ],
  /** wrong versions that must differ from the engine: [name, n, differs on, samples] */
  controls: [
    ['Ricci instead of Einstein', 3, 18, 18], ['trace coefficient 1 instead of 1/2', 3, 18, 18], ['wrong Lambda_n = c n(n-1)/2', 3, 12, 12], ['sign s_n = +1', 3, 18, 18],
    ['Ricci instead of Einstein', 4, 12, 12], ['trace coefficient 1 instead of 1/2', 4, 12, 12], ['wrong Lambda_n = c n(n-1)/2', 4, 8, 8], ['sign s_n = +1', 4, 12, 12],
    ['Ricci instead of Einstein', 5, 6, 6], ['trace coefficient 1 instead of 1/2', 5, 6, 6], ['wrong Lambda_n = c n(n-1)/2', 5, 4, 4], ['sign s_n = +1', 5, 6, 6],
  ],
  fails: 0,
};

/** CHECK 1 of gravity_new_checks.py: the Einstein form E_a on the Kerr–Schild Schwarzschild frame of step 12, exact at rational points (GRV-012): the number of
 *  non-zero components of E_a (of 16) and the Kretschmann scalar K of the engine's curvature (= 48 M² / ρ⁶ exactly) at six points for M = 1 and M = 3/2
 *  (ρ = 2M is the horizon), and the controls that must not be vacuum. */
export const KS = {
  script: 'checks/selfcheck/gravity/gravity_new_checks.py',
  log: 'checks/selfcheck/gravity/logs/gravity_new_checks.log',
  components: 16,
  points: [
    { M: '1', rho: '13', nonzero: 0, K: '48/4826809' }, { M: '1', rho: '11', nonzero: 0, K: '48/1771561' }, { M: '1', rho: '3', nonzero: 0, K: '16/243' },
    { M: '1', rho: '3/2', nonzero: 0, K: '1024/243' }, { M: '1', rho: '1', nonzero: 0, K: '48' }, { M: '1', rho: '2', nonzero: 0, K: '3/4' },
    { M: '3/2', rho: '13', nonzero: 0, K: '108/4826809' }, { M: '3/2', rho: '11', nonzero: 0, K: '108/1771561' }, { M: '3/2', rho: '3', nonzero: 0, K: '4/27' },
    { M: '3/2', rho: '3/2', nonzero: 0, K: '256/27' }, { M: '3/2', rho: '1', nonzero: 0, K: '108' }, { M: '3/2', rho: '2', nonzero: 0, K: '27/16' },
  ],
  controls: [
    { name: 'wrong power f = M rho0/rho^2', nonzero: 16, K: '224/4826809' },
    { name: 'charge only f = -Q2/(2 rho^2), Q2=1', nonzero: 16, K: '56/815730721' },
    { name: 'charge only f = -Q2/(2 rho^2), Q2=2', nonzero: 16, K: '224/815730721' },
    { name: 'mass + charge', nonzero: 16, K: '6920/815730721' },
    { name: 'cosmological term c = 1/3 on the same frame', nonzero: 16, K: null },
  ],
  fails: 0,
};

/** C1, c1_birkhoff.py: Birkhoff in the radial Kerr–Schild class (GRV-012): with f = Σ a_k ρ^k, k = −3..3, and c unknown, E_a(c) = 0 over 7 radii/directions in all 16
 *  components has rank 6 in the 8 unknowns; its null space is exactly span{M/ρ, (c/2)ρ²}; f = M/ρ + (c/2)ρ² solves it for M in {1/3, −2, 5/7} and c in {0, 1/4, −1/3}. */
export const C1 = {
  script: 'checks/selfcheck/gravity/c1_birkhoff.py',
  log: 'checks/selfcheck/gravity/logs/c1_birkhoff.log',
  powers: [-3, -2, -1, 0, 1, 2, 3],
  unknowns: 8, rank: 6, nullity: 2,
  kept: [{ k: -1, c: '0', reads: 'M/rho' }, { k: 2, c: '1', reads: '(c/2) rho^2' }],
  jetSamples: 28, radii: 7,
  solutions: { M: ['1/3', '-2', '5/7'], c: ['0', '1/4', '-1/3'], samples: 63 },
  controls: [['angular dependence of f', 8, 8], ['f = M/rho^2 (wrong power), c = 0', 4, 4], ['solution with a wrong c', 12, 12], ['closed form with tt coefficient 1 instead of 2', 4, 4], ['closed form with the tangential coefficient swapped', 4, 4]],
  fails: 0,
};

/** a rational written as in the logs ("48/4826809", "3/2", "-2") as a Number, for drawing */
export const ratio = s => { const [a, b] = String(s).split('/'); return b ? Number(a) / Number(b) : Number(a); };


/** F2, f2_first_law.py: the first law and Smarr from the engine's numbers on 29 (member, horizon) pairs of the Kerr–Newman family (LAB-008). For each: the member
 *  (Schwarzschild, Reissner–Nordström, extremal RN, Kerr, Kerr–Newman), the coupling κ (1, 2 or 4, standing in for 8πG), (M, a, Q), the horizon and its radius, and
 *  the engine's surface gravity kH, angular velocity Ω, Abar = A/(4π) and potential Φ — exact rationals as the log prints them. The first law dM = ½ kH dAbar + Ω dJ +
 *  (κ/2) Φ dQ held on every row (fitted from three rows, then checked); Smarr M = kH Abar + 2 Ω J + (κ/2) Φ Q (J = M a) on all 29 pairs; eleven wrong versions failed
 *  on every row where they can be seen. tests/engines.test.mjs re-reads the log and checks every number, and that each pair's three Smarr terms sum to M exactly. */
export const F2 = {
  script: 'checks/selfcheck/gravity/f2_first_law.py',
  log: 'checks/selfcheck/gravity/logs/f2_first_law.log',
  /** [member, κ, M, a, Q, horizon, r, kH, Ω, Abar, Φ] */
  horizons: [
    ['Schwarzschild', 1, '3/2', '0', '0', 'outer', '3', '1/6', '0', '9', '0'],
    ['Schwarzschild', 1, '1', '0', '0', 'outer', '2', '1/4', '0', '4', '0'],
    ['Schwarzschild', 1, '5/2', '0', '0', 'outer', '5', '1/10', '0', '25', '0'],
    ['RN', 1, '3/2', '0', '2', 'outer', '2', '1/8', '0', '4', '1'],
    ['RN', 1, '3/2', '0', '2', 'inner', '1', '-1/2', '0', '1', '2'],
    ['RN', 1, '3', '0', '4', 'outer', '4', '1/16', '0', '16', '1'],
    ['RN', 1, '3', '0', '4', 'inner', '2', '-1/4', '0', '4', '2'],
    ['RN', 1, '9/2', '0', '4', 'outer', '8', '7/128', '0', '64', '1/2'],
    ['RN', 1, '9/2', '0', '4', 'inner', '1', '-7/2', '0', '1', '4'],
    ['RN', 4, '3/2', '0', '1', 'outer', '2', '1/8', '0', '4', '1/2'],
    ['RN', 4, '3/2', '0', '1', 'inner', '1', '-1/2', '0', '1', '1'],
    ['RN', 2, '5/2', '0', '3/2', 'outer', '9/2', '8/81', '0', '81/4', '1/3'],
    ['RN', 2, '5/2', '0', '3/2', 'inner', '1/2', '-8', '0', '1/4', '3'],
    ['extremal RN', 2, '1', '0', '1', 'outer', '1', '0', '0', '1', '1'],
    ['extremal RN', 2, '2', '0', '2', 'outer', '2', '0', '0', '4', '1'],
    ['Kerr', 1, '5', '3', '0', 'outer', '9', '2/45', '1/30', '90', '0'],
    ['Kerr', 1, '5', '3', '0', 'inner', '1', '-2/5', '3/10', '10', '0'],
    ['Kerr', 1, '5', '4', '0', 'outer', '8', '3/80', '1/20', '80', '0'],
    ['Kerr', 1, '5', '4', '0', 'inner', '2', '-3/20', '1/5', '20', '0'],
    ['Kerr', 1, '5/2', '2', '0', 'outer', '4', '3/40', '1/10', '20', '0'],
    ['Kerr', 1, '5/2', '2', '0', 'inner', '1', '-3/10', '2/5', '5', '0'],
    ['Kerr', 1, '13/2', '6', '0', 'outer', '9', '5/234', '2/39', '117', '0'],
    ['Kerr', 1, '13/2', '6', '0', 'inner', '4', '-5/104', '3/26', '52', '0'],
    ['Kerr-Newman', 1, '5', '1', '4', 'outer', '9', '2/41', '1/82', '82', '18/41'],
    ['Kerr-Newman', 1, '5', '1', '4', 'inner', '1', '-2', '1/2', '2', '2'],
    ['Kerr-Newman', 1, '7/2', '2', '2', 'outer', '6', '1/16', '1/20', '40', '3/10'],
    ['Kerr-Newman', 1, '7/2', '2', '2', 'inner', '1', '-1/2', '2/5', '5', '2/5'],
    ['Kerr-Newman', 1, '15/2', '2', '8', 'outer', '12', '9/296', '1/74', '148', '24/37'],
    ['Kerr-Newman', 1, '15/2', '2', '8', 'inner', '3', '-9/26', '2/13', '13', '24/13'],
  ],
  firstLawFit: ['1/2', '1', '1/2'],
  firstLaw: [{ kappa: 1, rows: 70, of: 70 }, { kappa: 2, rows: 8, of: 8 }, { kappa: 4, rows: 6, of: 6 }],
  smarrFit: ['1', '2', '1/2'],
  smarr: { pairs: 29, of: 29 },
  /** [wrong version, fails on, rows where it can be seen] */
  controls: [['2 kH in the first law', 82, 82], ['kH/2 in the first law', 82, 82], ['outer area with the inner kH', 39, 39], ['Phi -> -Phi in the first law', 34, 34], ['J = a (M dropped) in the first law', 42, 42], ['Omega of the inner horizon with the outer area', 21, 21], ['2 kH in Smarr', 27, 27], ['kH/2 in Smarr', 27, 27], ['Smarr with the first-law weights (alpha, beta, gamma)', 27, 27], ['J = a (M dropped) in Smarr', 14, 14], ['retarded chart: its kH (= -kH) with the future sign', 8, 8]],
  fails: 0,
};
