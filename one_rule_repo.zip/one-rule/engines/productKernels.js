// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The dense product of two multivectors of the neutral algebra Cl(k,k) (n = 2k generators, e_i^2 = +1 for even i and -1 for odd i), done five ways, and the exact-integer check that they agree.
// Written to be read next to selfcheck/matrixrep_check.py, which proves the representation exactly (in Python integers); the same tables are rebuilt here and compared with its fixtures.
//   bit rule         e_a e_b = s(a,b) e_(a xor b): 4^n terms, the sign of each term worked out with popcounts
//   sign table       the same 4^n terms with the signs read from a table of 4^n entries (set-up, not timed)
//   matrix route     Cl(k,k) = M_(2^k)(R): the multivector goes to a 2^k x 2^k real matrix (a butterfly on each of k sites, k 4^k additions), one matrix product (8^k multiplications), and back
//   period 8         Cl(N+8) = M16(Cl(N)): the 16 x 16 matrix over Cl(N), whose product is 16^3 = 4096 products in Cl(N) (done here by the bit rule with the sign table of Cl(N))
// Allocation: as written, one call of the matrix route allocates seven Float64Arrays (toMatrices 2, called twice; matrixProduct 1; fromMatrices 2) and the sign-table product one.
// The same functions take optional output buffers; with buffers allocated once (productRouteBuffers) the arithmetic is the same and nothing is allocated inside the call.
// So the timings separate the route plus its allocation (matrixRoute), the route itself (matrixRouteReuse, against signTableReuse) and the seven allocations alone (routeAllocs).
// Nothing is approximated: with integer inputs every double is exact, so the answers are compared with ===. Timings depend on the machine and the engine; they are not exact.
// V2 (task T3.2): the REFERENCE is the one kernel, engines/bitrule.js. productSign is the kernel's sign in Cl(8,8) (generators 0..15; a generator from 16 on
// squares to +1, as in v15), productBitRule takes every sign from it, productSignTable and the base table of the period-8 route are the kernel's signTable.
// The other ways are COMPARISON implementations, kept to be timed and checked against the kernel's product (productCheck, tests/engines.test.mjs): the v15
// popcount sign (comparisonProductSign) and the matrix routes, in the block marked below. A timing of the bitRule row now times the kernel's sign; the v15 sign
// stays available as comparisonProductSign. engines/stored/productKernels_v15.json holds what the v15 module returned on a fixed set of inputs, and
// tests/engines.test.mjs (section H) compares the two (bit for bit).
import { sign, signTable, popcount } from './bitrule.js';

/** the signature of Cl(8,8) as a sign vector for the kernel: +1, −1, +1, −1, … for generators 0..15, and +1 from 16 on (31 entries) */
const KK = Array.from({ length: 31 }, (_, i) => (i < 16 && (i & 1) ? -1 : 1));
const flatTable = n => { const N = 1 << n, S = signTable(KK.slice(0, n)), T = new Int8Array(N * N); for (let a = 0; a < N; a++) T.set(S[a], a * N); return T; };
/** sign of e_a e_b: the kernel's (the swaps that put the generators in order, and the generators that meet: odd ones square to -1) */
export function productSign(a, b) { return sign(a, b, KK); }
export function productBitRule(x, y, n) {
  const N = 1 << n, out = new Float64Array(N);
  for (let a = 0; a < N; a++) { const xa = x[a]; if (xa === 0) continue; for (let b = 0; b < N; b++) out[a ^ b] += productSign(a, b) * xa * y[b]; }
  return out;
}
export function productSignTable(n) {                                         // 4^n entries (n <= 12 is 16 MB): the kernel's sign table, laid out flat
  return flatTable(n);
}
export function productWithTable(x, y, n, T, out) {                           // out: optional output buffer of 2^n doubles (zeroed here); without it one is allocated
  const N = 1 << n;
  if (out) out.fill(0); else out = new Float64Array(N);
  for (let a = 0; a < N; a++) { const xa = x[a], row = a * N; if (xa === 0) continue; for (let b = 0; b < N; b++) out[a ^ b] += T[row + b] * xa * y[b]; }
  return out;
}

// ---------------------------------------------------------------- comparison implementations (not the reference): the v15 sign route and the matrix routes, kept to be timed and compared with the kernel's product
const PK_ODD = 0xAAAA;                                                        // bits 1, 3, 5, ...: the generators that square to -1 (n <= 16)
const pkPop = x => { x -= (x >> 1) & 0x55555555; x = (x & 0x33333333) + ((x >> 2) & 0x33333333); return Math.imul((x + (x >> 4)) & 0x0F0F0F0F, 0x01010101) >>> 24; };
/** the v15 sign of this benchmark (popcounts of shifted masks and a mask of the odd generators): a comparison for the kernel's productSign, equal to it on every pair */
export function comparisonProductSign(a, b) {
  let s = 0, t = a >> 1; while (t) { s += pkPop(t & b); t >>= 1; }
  return (s + pkPop(a & b & PK_ODD)) & 1 ? -1 : 1;
}

// ---------------------------------------------------------------- the representation: signed permutation matrices, one 2 x 2 factor (I, Z, X or eps, up to sign) for each of the k sites
const PK_M2 = [[1, 0, 0, 1], [1, 0, 0, -1], [0, 1, 1, 0], [0, 1, -1, 0]];   // I, Z = diag(1,-1), X = [[0,1],[1,0]], eps = [[0,1],[-1,0]]  (row by row)
const pkM2mul = (A, B) => [A[0] * B[0] + A[1] * B[2], A[0] * B[1] + A[1] * B[3], A[2] * B[0] + A[3] * B[2], A[2] * B[1] + A[3] * B[3]];
const PK_PM = PK_M2.map(P => PK_M2.map(Q => {                                  // PK_PM[p][q] = [r, s]  with  p q = s r
  const C = pkM2mul(P, Q);
  for (let r = 0; r < 4; r++) { if (C.every((v, i) => v === PK_M2[r][i])) return [r, 1]; if (C.every((v, i) => v === -PK_M2[r][i])) return [r, -1]; }
  throw new Error('not a signed Pauli matrix');
}));
export function productRep(n, N = 0) {                                          // N base generators stay (the bit rule of Cl(N)); the other n - N = 2k become a 2^k x 2^k matrix
  if ((n - N) % 2 || n - N < 2 || N < 0 || n > 16) throw new Error('productRep: n - N must be even and at least 2');
  const k = (n - N) >> 1, m = 1 << k, B = 1 << N, NB = 1 << n, size = m * m * B, slot = new Int32Array(NB), sg = new Int8Array(NB);
  const apply = (ops, t, sgn) => {                                              // right-multiply by new generator t: the Z string on the sites below its own, then X (t even) or eps (t odd) on its site
    const j = t >> 1;
    for (let i = 0; i < j; i++) { const [r, s] = PK_PM[ops[i]][1]; ops[i] = r; sgn *= s; }
    const [r, s] = PK_PM[ops[j]][t & 1 ? 3 : 2]; ops[j] = r; return sgn * s;
  };
  const gOps = new Array(k).fill(0); let gSign = 1; for (let t = 0; t < 2 * k; t++) gSign = apply(gOps, t, gSign);        // Gamma, the product of all new generators: diagonal, Gamma^2 = +1
  for (let b = 0; b < NB; b++) {
    const S = b & (B - 1), T = b >> N, odd = popcount(S) & 1, ops = odd ? gOps.slice() : new Array(k).fill(0); let sgn = odd ? gSign : 1;
    for (let t = 0; t < 2 * k; t++) if (T >> t & 1) sgn = apply(ops, t, sgn);
    let addr = 0; for (let j = 0; j < k; j++) addr += ops[j] * Math.pow(4, j);
    slot[b] = addr * B + S; sg[b] = sgn;
  }
  const rc = new Int32Array(m * m);                                             // the Pauli address of matrix entry (r, c): digit j is 2 r_j + c_j
  for (let r = 0; r < m; r++) for (let c = 0; c < m; c++) { let a = 0; for (let j = 0; j < k; j++) a += (((r >> j & 1) << 1) | (c >> j & 1)) * Math.pow(4, j); rc[r * m + c] = a; }
  const baseSign = N > 0 ? flatTable(N) : null;                                  // the sign table of the base Cl(N): the kernel's
  return { n, N, k, m, B, NB, size, slot, sg, rc, baseSign };
}
export function toMatrices(rep, x, v = new Float64Array(rep.size), M = new Float64Array(rep.size)) {   // multivector (2^n numbers) -> m x m entries, each a multivector of Cl(N), laid out [r][c][S]; v, M: work and output buffers (every entry is overwritten)
  const { k, m, B, NB, size, slot, sg, rc } = rep;
  for (let b = 0; b < NB; b++) v[slot[b]] = sg[b] * x[b];
  for (let j = 0; j < k; j++) {
    const u = Math.pow(4, j) * B;
    for (let hi = 0; hi < size; hi += 4 * u) for (let lo = 0; lo < u; lo++) {
      const i0 = hi + lo, i1 = i0 + u, i2 = i1 + u, i3 = i2 + u, I = v[i0], Z = v[i1], X = v[i2], E = v[i3];
      v[i0] = I + Z; v[i1] = X + E; v[i2] = X - E; v[i3] = I - Z;                  // slots 00, 01, 10, 11 of (row bit, column bit)
    }
  }
  for (let rcI = 0; rcI < m * m; rcI++) { const from = rc[rcI] * B, to = rcI * B; for (let s = 0; s < B; s++) M[to + s] = v[from + s]; }
  return M;
}
export function fromMatrices(rep, M, v = new Float64Array(rep.size), out = new Float64Array(rep.NB)) {   // v, out: work and output buffers (every entry is overwritten)
  const { k, m, B, NB, size, slot, sg, rc } = rep;
  for (let rcI = 0; rcI < m * m; rcI++) { const to = rc[rcI] * B, from = rcI * B; for (let s = 0; s < B; s++) v[to + s] = M[from + s]; }
  for (let j = 0; j < k; j++) {
    const u = Math.pow(4, j) * B;
    for (let hi = 0; hi < size; hi += 4 * u) for (let lo = 0; lo < u; lo++) {
      const i0 = hi + lo, i1 = i0 + u, i2 = i1 + u, i3 = i2 + u, m00 = v[i0], m01 = v[i1], m10 = v[i2], m11 = v[i3];
      v[i0] = m00 + m11; v[i1] = m00 - m11; v[i2] = m01 + m10; v[i3] = m01 - m10;  // 2i, 2z, 2x, 2e
    }
  }
  const div = m;
  for (let b = 0; b < NB; b++) out[b] = sg[b] * v[slot[b]] / div;
  return out;
}
export function matrixProduct(rep, A, Bm, C) {                                 // C = A B for m x m matrices over Cl(N): m^3 products in Cl(N) (plain multiplications when N = 0); C: optional output buffer (zeroed here)
  const { m, B, size, baseSign } = rep;
  if (C) C.fill(0); else C = new Float64Array(size);
  if (B === 1) {
    for (let r = 0; r < m; r++) { const rm = r * m; for (let c = 0; c < m; c++) { const a = A[rm + c], cm = c * m; for (let d = 0; d < m; d++) C[rm + d] += a * Bm[cm + d]; } }
    return C;
  }
  for (let r = 0; r < m; r++) for (let c = 0; c < m; c++) {
    const oa = (r * m + c) * B;
    for (let d = 0; d < m; d++) {
      const ob = (c * m + d) * B, oc = (r * m + d) * B;
      for (let s1 = 0; s1 < B; s1++) { const a = A[oa + s1], row = s1 * B; for (let s2 = 0; s2 < B; s2++) C[oc + (s1 ^ s2)] += baseSign[row + s2] * a * Bm[ob + s2]; }
    }
  }
  return C;
}
export const productMatrixRoute = (rep, x, y) => fromMatrices(rep, matrixProduct(rep, toMatrices(rep, x), toMatrices(rep, y)));             // as written: seven Float64Arrays allocated per call
// the same route with its seven work arrays allocated once, before the clock (the engine avoids per-call typed arrays for the same reason: pgaEngine.js, z). The answer is the buffer b.out, overwritten by the next call.
export const productRouteBuffers = rep => ({ vx: new Float64Array(rep.size), Mx: new Float64Array(rep.size), vy: new Float64Array(rep.size), My: new Float64Array(rep.size), C: new Float64Array(rep.size), v: new Float64Array(rep.size), out: new Float64Array(rep.NB) });
export const productMatrixRouteReuse = (rep, x, y, b) => fromMatrices(rep, matrixProduct(rep, toMatrices(rep, x, b.vx, b.Mx), toMatrices(rep, y, b.vy, b.My), b.C), b.v, b.out);
// the seven allocations of one route call alone, same sizes, each written and read once: the part of the route's time that is allocation (no product is computed)
export function productRouteAllocs(rep, i) {
  let s = 0;
  for (let k = 0; k < 6; k++) { const a = new Float64Array(rep.size); a[(i + k) & (rep.size - 1)] = 1; s += a[rep.size >> 1]; }
  const o = new Float64Array(rep.NB); o[i & (rep.NB - 1)] = 1; return s + o[rep.NB >> 1];
}

// ---------------------------------------------------------------- end of the comparison implementations

// ---------------------------------------------------------------- the check and the set-up the timings use
export function productInputs(n, seed = 1) {                                   // two seeded dense multivectors with nonzero integer coefficients in -9..9
  let a = seed | 0;
  const rnd = () => { a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const draw = () => { const out = new Float64Array(1 << n); for (let i = 0; i < out.length; i++) { const v = 1 + Math.floor(rnd() * 9); out[i] = rnd() < 0.5 ? -v : v; } return out; };
  return { x: draw(), y: draw() };
}
export const PRODUCT_NS = [2, 4, 6, 8, 10, 12, 14];
export const productHasTable = n => n <= 12;
export const productPeriodN = n => (n >= 10 ? n - 8 : null);                   // the base Cl(N) under the 16 x 16 blocks (N = 2, 4, 6 at n = 10, 12, 14)
export function productSetup(n, wantTable = true) {
  const { x, y } = productInputs(n), ctx = { n, x, y, repFull: productRep(n, 0), table: wantTable && productHasTable(n) ? productSignTable(n) : null };
  const N = productPeriodN(n); ctx.rep8 = N == null ? null : productRep(n, N);
  ctx.buf = productRouteBuffers(ctx.repFull); ctx.outT = new Float64Array(1 << n);                     // allocated once, for the variants that reuse their buffers
  ctx.Mx = toMatrices(ctx.repFull, x); ctx.My = toMatrices(ctx.repFull, y);
  if (ctx.rep8) { ctx.Px = toMatrices(ctx.rep8, x); ctx.Py = toMatrices(ctx.rep8, y); }
  return ctx;
}
// the functions that are timed (each returns a number, so the engine cannot drop the work): the product of x and y, or the matrix product alone when the matrices are given
export function productVariants(ctx) {
  const { n, x, y, repFull, rep8, table, Mx, My, Px, Py, buf, outT } = ctx, mid = (1 << n) >> 1, o = {};
  o.bitRule = () => productBitRule(x, y, n)[mid];
  if (table) o.signTable = () => productWithTable(x, y, n, table)[mid];
  if (table) o.signTableReuse = () => productWithTable(x, y, n, table, outT)[mid];
  o.matmulGiven = () => matrixProduct(repFull, Mx, My)[mid];
  o.matrixRoute = () => productMatrixRoute(repFull, x, y)[mid];
  o.matrixRouteReuse = () => productMatrixRouteReuse(repFull, x, y, buf)[mid];
  o.routeAllocs = i => productRouteAllocs(repFull, i);
  if (rep8) o.period8 = () => productMatrixRoute(rep8, x, y)[mid];
  return o;
}
// every variant gives the same integers as the bit rule (the kernel's product, the reference), on the inputs that are timed (seed 1, the set-up's own) and on a second pair (seed 7 + n); the variants with reused buffers are run twice, so a buffer left dirty by the first call would show
export function productCheck(n) {
  const ctx = productSetup(n), same = (u, v) => u.length === v.length && u.every((q, i) => q === v[i]);
  let ok = true, sum = 0, timedChecksum = null;
  for (const { x, y } of [{ x: ctx.x, y: ctx.y }, productInputs(n, 7 + n)]) {
    const ref = productBitRule(x, y, n);
    ok = ok && same(fromMatrices(ctx.repFull, toMatrices(ctx.repFull, x)), x);                                     // the way in and out loses nothing
    ok = ok && same(productMatrixRoute(ctx.repFull, x, y), ref);
    for (let r = 0; r < 2; r++) ok = ok && same(productMatrixRouteReuse(ctx.repFull, x, y, ctx.buf), ref);
    if (ctx.table) { ok = ok && same(productWithTable(x, y, n, ctx.table), ref); for (let r = 0; r < 2; r++) ok = ok && same(productWithTable(x, y, n, ctx.table, ctx.outT), ref); }
    if (ctx.rep8) ok = ok && same(fromMatrices(ctx.rep8, toMatrices(ctx.rep8, x)), x) && same(productMatrixRoute(ctx.rep8, x, y), ref);
    sum = 0; for (let i = 0; i < ref.length; i++) sum += ref[i] * (1 + (i % 7));                                     // checksum: that of the second pair; timedChecksum: that of the timed inputs
    if (timedChecksum === null) timedChecksum = sum;
  }
  return { n, ok, checksum: sum, timedChecksum, terms: Math.pow(4, n), mults: Math.pow(8, n / 2), inputs: 'timed inputs (seed 1) and seed 7 + n' };
}
// the operation counts the page prints next to the timings
export const productCounts = n => ({ bitTerms: Math.pow(4, n), matMults: Math.pow(8, n / 2), gain: Math.pow(2, n / 2), period8Terms: n >= 10 ? 4096 * Math.pow(4, n - 8) : null, convAdds: (n / 2) * Math.pow(2, n) });
