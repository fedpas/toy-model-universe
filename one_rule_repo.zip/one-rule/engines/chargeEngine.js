// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// A charge moving in the electromagnetic field (c = 1, units of m = 1).  The force is read off the table that selfcheck/maxwell_selfcheck.py checks exactly:
// the grade-1 part of the product F u, in the textbook components  f_t = E.u,  f_i = u_t E_i + sum_j B_ij u_j.  Each term is one piece of F (an edge between two
// vertices of the simplex) sending the velocity at one end to the force at the other; they are the contraction half of the moves of  grad F = J,  with d_a replaced by u_a.
// The equation of motion is  du/dtau = (q/m) f,  dx/dtau = u,  dt/dtau = u_t, integrated here with fourth-order Runge-Kutta in the proper time tau.
// The checks the widget shows (circle radius, hyperbola, drift, wave, perihelion advance) are the closed forms of the numeric rows of the same script.
import M from './maxwellData.js';

const CH = M.charges;
export const FIELDS = ['E_x', 'E_y', 'E_z', 'B_x', 'B_y', 'B_z'];
export const TERMS = Object.fromEntries(Object.entries(CH.worlds).map(([d, w]) => [d, w.terms.map(t => ({ ...t }))]));
const T3 = TERMS['3'].map(t => [t.out, FIELDS.indexOf(t.field), t.in, t.sign]);

// the force (per unit q/m) on a charge with four-velocity u = (u_t, u_x, u_y, u_z) in the field F = [E_x, E_y, E_z, B_x, B_y, B_z]
export function force(F, u) {
  const f = [0, 0, 0, 0];
  for (let i = 0; i < T3.length; i++) { const t = T3[i], v = F[t[1]]; if (v !== 0) f[t[0]] += t[3] * v * u[t[2]]; }
  return f;
}
export const gammaOf = v => 1 / Math.sqrt(1 - v * v);
const vel = (v, d) => { const g = gammaOf(v); return [g, g * v * d[0], g * v * d[1], g * v * d[2]]; };
export const norm3 = u => Math.hypot(u[1], u[2], u[3]);

const P = (id, min, max, step, def, live) => ({ id, min, max, step, def, live });
export const PRESET_IDS = ['circle', 'hyper', 'crossed', 'spiral', 'orbit', 'wave'];
// world: the number of space dimensions the situation needs (2: the plane, 3: space); rate: simulated time per second; ext: half the width of the picture in length units
export const SPEC = {
  circle: {
    world: 2, rate: 2.5, hmax: 0.01, view: 'fit', ext: 2.4,
    params: [P('B', 0.2, 3, 0.05, 1, true), P('qm', -2, 2, 0.05, 1, true), P('v0', 0, 0.97, 0.01, 0.8, false)],
    field: p => [0, 0, 0, 0, 0, p.B], qm: p => p.qm, init: p => ({ x: [0, 0, 0], u: vel(p.v0, [1, 0, 0]) })
  },
  hyper: {
    world: 2, rate: 1.4, hmax: 0.01, view: 'follow', ext: 5,
    params: [P('E', 0.2, 3, 0.05, 1, true), P('qm', -2, 2, 0.05, 1, true), P('v0', 0, 0.95, 0.01, 0.5, false)],
    field: p => [p.E, 0, 0, 0, 0, 0], qm: p => p.qm, init: p => ({ x: [0, 0, 0], u: vel(p.v0, [0, 1, 0]) })
  },
  crossed: {
    world: 2, rate: 3, hmax: 0.01, view: 'follow', ext: 6,
    params: [P('B', 0.2, 3, 0.05, 1, true), P('rho', 0, 1.6, 0.02, 0.6, true), P('qm', -2, 2, 0.05, 1, true), P('v0', 0, 0.95, 0.01, 0, false)],
    field: p => [0, p.rho * p.B, 0, 0, 0, p.B], qm: p => p.qm, init: p => ({ x: [0, 0, 0], u: vel(p.v0, [1, 0, 0]) })
  },
  spiral: {
    world: 3, rate: 3, hmax: 0.01, view: 'follow', ext: 3.2, sideExt: 5.5,
    params: [P('E', 0, 2, 0.05, 0.1, true), P('B', 0.2, 3, 0.05, 1.5, true), P('qm', -2, 2, 0.05, 1, true), P('v0', 0, 0.95, 0.01, 0.8, false)],
    field: p => [0, 0, p.E, 0, 0, p.B], qm: p => p.qm, init: p => ({ x: [0, 0, 0], u: vel(p.v0, [1, 0, 0]) })
  },
  orbit: {
    world: 3, rate: 1.6, hmax: 0.01, view: 'fit', ext: 1.3,
    params: [P('kappa', -0.6, 0.6, 0.01, 0.3, true), P('v0', 0.1, 0.9, 0.01, 0.4, false)],
    field: (p, t, x) => { const r3 = Math.pow(x[0] * x[0] + x[1] * x[1] + x[2] * x[2], 1.5) || 1e-9; return [p.kappa * x[0] / r3, p.kappa * x[1] / r3, p.kappa * x[2] / r3, 0, 0, 0]; },
    qm: () => -1, init: p => ({ x: [1, 0, 0], u: vel(p.v0, [0, 1, 0]) })
  },
  wave: {
    world: 3, rate: 2, hmax: 0.01, view: 'follow', ext: 2.6, sideExt: 3.6,
    params: [P('a', 0, 3, 0.05, 1.5, true)],
    field: (p, t, x) => { const f = p.a * Math.cos(t - x[2]); return [f, 0, 0, 0, f, 0]; }, qm: () => 1, init: () => ({ x: [0, 0, 0], u: [1, 0, 0, 0] })
  }
};
export const defaults = id => Object.fromEntries(SPEC[id].params.map(q => [q.id, q.def]));

// ---- one run: the state s = [t, x, y, z, u_t, u_x, u_y, u_z], the proper time, the trail and what the checks need
export function initRun(id, p) {
  const sp = SPEC[id], i = sp.init(p), s = [0, i.x[0], i.x[1], i.x[2], i.u[0], i.u[1], i.u[2], i.u[3]];
  const r = { id, s, tau: 0, steps: 0, P0: { ...p }, changed: false, trail: [[i.x[0], i.x[1], i.x[2], 0]], x0: i.x.slice(), maxDist: 0, ang: Math.atan2(i.x[1], i.x[0]), peri: [], radial: 0, cyc: [], k: 0, fell: false, u0: i.u.slice() };
  r.radial = i.x[0] * i.u[1] + i.x[1] * i.u[2];
  return r;
}
const rk4 = (s, h, rhs) => {
  const k1 = rhs(s), k2 = rhs(s.map((v, i) => v + h / 2 * k1[i])), k3 = rhs(s.map((v, i) => v + h / 2 * k2[i])), k4 = rhs(s.map((v, i) => v + h * k3[i]));
  return s.map((v, i) => v + h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]));
};
// the length of one cycle in proper time over which the checks average (wave: 2 pi; crossed fields: a turn in the drift frame), or 0
const cycleOf = (id, p) => id === 'wave' ? 2 * Math.PI : id === 'crossed' && p.rho < 1 && p.qm !== 0 ? 2 * Math.PI / (Math.abs(p.qm) * p.B * Math.sqrt(1 - p.rho * p.rho)) : 0;

export function advance(run, p, dtSim) {
  const sp = SPEC[run.id], qm = sp.qm(p), tEnd = run.s[0] + dtSim, Tc = run.changed ? 0 : cycleOf(run.id, run.P0);
  const rhs = s => { const f = force(sp.field(p, s[0], [s[1], s[2], s[3]]), [s[4], s[5], s[6], s[7]]); return [s[4], s[5], s[6], s[7], qm * f[0], qm * f[1], qm * f[2], qm * f[3]]; };
  let guard = 0;
  while (run.s[0] < tEnd - 1e-12 && guard++ < 4000 && !run.fell) {
    const s = run.s, r = Math.hypot(s[1], s[2], s[3]);
    let h = Math.min(sp.hmax * (run.id === 'orbit' ? Math.min(1, Math.pow(r, 1.5)) : 1), (tEnd - s[0]) / s[4]);
    if (Tc) h = Math.min(h, (run.k + 1) * Tc - run.tau);
    if (!(h > 1e-12)) h = 1e-9;
    const n = rk4(s, h, rhs), ang0 = run.ang;
    if (run.id === 'orbit') {
      const a = Math.atan2(n[2], n[1]), da = ((a - Math.atan2(s[2], s[1]) + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI; run.ang += da;
      const g = n[1] * n[5] + n[2] * n[6] + n[3] * n[7];
      if (run.radial < 0 && g >= 0) { const f = -run.radial / (g - run.radial); run.peri.push(ang0 + f * da); }
      run.radial = g;
      if (Math.hypot(n[1], n[2], n[3]) < 0.02) run.fell = true;
    }
    run.s = n; run.tau += h; run.steps++;
    run.maxDist = Math.max(run.maxDist, Math.hypot(n[1] - run.x0[0], n[2] - run.x0[1], n[3] - run.x0[2]));
    if (Tc && Math.abs(run.tau - (run.k + 1) * Tc) < 1e-9) { run.k++; run.cyc.push([n[0], n[1], n[3], run.tau]); }
    if (run.steps % 3 === 0) { run.trail.push([n[1], n[2], n[3], n[0]]); if (run.trail.length > 1800) run.trail.splice(0, 300); }
  }
}

// ---- what is on screen: the field at the charge, the force, the invariants and the checks
export function readout(run, p) {
  const sp = SPEC[run.id], s = run.s, u = [s[4], s[5], s[6], s[7]], F = sp.field(p, s[0], [s[1], s[2], s[3]]), qm = sp.qm(p), f = force(F, u).map(v => qm * v);
  const E2 = F[0] * F[0] + F[1] * F[1] + F[2] * F[2], B2 = F[3] * F[3] + F[4] * F[4] + F[5] * F[5], EB = F[0] * F[3] + F[1] * F[4] + F[2] * F[5];
  return { t: s[0], tau: run.tau, gamma: u[0], speed: norm3(u) / u[0], u2: u[0] * u[0] - u[1] * u[1] - u[2] * u[2] - u[3] * u[3] - 1, F, f, u, I1: E2 - B2, I2: EB, check: check(run, p) };
}
// each check compares the running state with a closed form of the numeric rows of the script; it is null when the fields were changed in flight (the closed form belongs to the fields at the start)
function check(run, p) {
  if (run.changed || run.steps === 0) return null;
  const q = run.P0, s = run.s, sp = SPEC[run.id], u0 = run.u0, g0 = u0[0], t = s[0], tau = run.tau, qm = sp.qm(q), id = run.id;
  if (id === 'circle') {
    const Om = Math.abs(qm) * q.B; if (!(Om > 1e-9) || !(q.v0 > 0)) return null;
    const R = g0 * q.v0 / Om, half = Math.PI / Om;
    return tau >= half + 0.02 ? { kind: 'circle', formula: R, measured: run.maxDist / 2 } : { kind: 'circle', formula: R, measured: null, wait: half - tau };
  }
  if (id === 'hyper') {
    const a = Math.abs(qm) * q.E; if (!(a > 1e-9)) return null; const m2 = 1 + u0[2] * u0[2], x = Math.sign(qm) * (Math.sqrt(m2 + (a * t) * (a * t)) - Math.sqrt(m2)) / a;
    return { kind: 'hyper', formula: x, measured: s[1], newton: a * t, speed: norm3([0, s[5], s[6], s[7]]) / s[4], diff: Math.abs(x - s[1]) };
  }
  if (id === 'crossed') {
    if (q.rho >= 1) return { kind: 'runaway', rho: q.rho };
    const last = run.cyc[run.cyc.length - 1];
    return { kind: 'drift', formula: q.rho, measured: last ? last[1] / last[0] : null, turns: run.cyc.length };
  }
  if (id === 'spiral') {
    const w = qm * q.E * tau, zf = g0 * Math.sinh(w); return { kind: 'spiral', formula: zf, measured: s[7], diff: Math.abs(zf - s[7]) };
  }
  if (id === 'orbit') {
    const L = Math.abs(run.x0[0] * u0[2] - run.x0[1] * u0[1]), k2 = q.kappa * q.kappa / (L * L);
    if (q.kappa <= 0) return { kind: 'repulsive' };
    if (k2 >= 1) return { kind: 'falls', ratio: Math.sqrt(k2) };
    const sg = Math.sqrt(1 - k2), form = 360 * (1 / sg - 1), meas = run.peri.length >= 2 ? 360 * ((run.peri[1] - run.peri[0]) / (2 * Math.PI) - 1) : null;
    return { kind: 'orbit', formula: form, measured: meas, perihelia: run.peri.length, L, s: sg };
  }
  if (id === 'wave') {
    const a = q.a, last = run.cyc[run.cyc.length - 1], ux = a * Math.sin(tau);
    return { kind: 'wave', conserved: s[4] - s[7], formula: a * a / (4 + a * a), measured: last ? last[2] / last[0] : null, diff: Math.abs(ux - s[5]), turns: run.cyc.length };
  }
  return null;
}
