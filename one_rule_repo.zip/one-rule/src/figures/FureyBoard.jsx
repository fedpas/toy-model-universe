// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure furey-board (Furey, three generations): the 5 × 5 board of Fig. 1 of the nested-embeddings paper (engines/fureyPapersEngine.js, exact integers; the same
// bookkeeping furey_papers_check.py checks). The rows and columns are the five complex blocks ℂ_𝕆, ℂ³_𝕆, ℂ²_ℍ, ℂ_ℂ, ℂ_last; the diagonal holds the gauge bosons and
// the 20 off-diagonal cells the paper's labels (row = source, column = target; † the conjugate). Each cell carries its Standard Model type, the irrep of the edge
// col ⊗ conj(row), printed in its corner — v15 coloured the six types, the design keeps colour for the clock —; the tally counts the cells of each type and the number
// of complete sets they make. The controls are v15's: one label per cell or both (the hermitian 16 × 16 form), shading by type or by first generation, and the cell
// whose irrep, labels, charges and transpose are read out under the board. Port of v15 FureyWidgets2.Board (and the dictionary's board of DictionarySection.jsx).
import React, { useState, useEffect } from 'react';
import { FIG1, TYPES, cell, typeOfCell, labelText, labelIrrep, cellMatches, cellCharges, cellsByType, completeSets, isFirstSetCell, fmtShow, fmtQ, dimOf } from '../../engines/fureyPapersEngine.js';
import { FigSvg, Controls, Chips, r1 } from './kit.jsx';

const BLOCKS = ['ℂ_𝕆', 'ℂ³_𝕆', 'ℂ²_ℍ', 'ℂ_ℂ', 'ℂ_last'];
const TYPE_TXT = { Q_L: 'Q_L', u_R: 'u_R', d_R: 'd_R', L: 'L', e_R: 'e_R', nu_R: 'ν_R' };
const TYPE_PLAIN = { Q_L: ['quarks', 'left'], u_R: ['up quark', 'right'], d_R: ['down quark', 'right'], L: ['electron and', 'neutrino left'], e_R: ['electron', 'right'], nu_R: ['neutrino', 'right'] };
const EXTRA_PLAIN = { b_R: ['bottom quark', 'right'], h: ['Higgs pair', ''], '(nu_tau,tau)_L': ['tau and', 'neutrino left'], tau_R: ['tau', 'right'] };
const CELLS = Object.keys(FIG1);

/** a name written with underscores (ν_e, b_R) as SVG text with real subscripts */
export function Sc({ s }) {
  const parts = []; let last = 0, m; const re = /_([^\s,()†]+)/g;
  while ((m = re.exec(s))) { if (m.index > last) parts.push(s.slice(last, m.index)); parts.push({ sub: m[1] }); last = m.index + m[0].length; }
  if (last < s.length) parts.push(s.slice(last));
  return <>{parts.map((p, i) => (typeof p === 'string' ? <tspan key={i}>{p}</tspan> : <tspan key={i} dy="3" fontSize="72%">{p.sub}<tspan dy="-3">{'\u200b'}</tspan></tspan>))}</>;
}
const plainName = (r, c) => { const lb = FIG1[r + ',' + c][0], base = lb.replace(/\+$/, ''), nm = EXTRA_PLAIN[base] || TYPE_PLAIN[typeOfCell(r, c)]; return lb.endsWith('+') ? ['anti ' + nm[0], nm[1]] : nm; };

export default function FureyBoard({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okCell = v => typeof v === 'string' && /^[0-4],[0-4]$/.test(v);
  const [doubled, setDoubled] = useState(params.doubled === true);
  const [view, setView] = useState(params.view === 'first' ? 'first' : 'type');
  const [sel, setSel] = useState(okCell(params.cell) ? params.cell : '1,2');
  useEffect(() => { setDoubled(params.doubled === true); setView(params.view === 'first' ? 'first' : 'type'); setSel(okCell(params.cell) ? params.cell : '1,2'); }, [params.doubled, params.view, params.cell]);
  const [sr, sc] = sel.split(',').map(Number), sdiag = sr === sc, counts = cellsByType(), CW = 72, CH = 48, X0 = 52, Y0 = 26;
  const tally = TYPES.map(t => [t, counts[t] * (doubled ? 2 : 1)]), sets = completeSets(doubled), x = sdiag ? null : cell(sr, sc);
  return (
    <div className="fig fig-furey-board">
      <FigSvg id="furey-board" row={row} viewBox="0 0 420 352">
        {[0, 1, 2, 3, 4].map(i => (
          <g key={'h' + i}>
            <text x={X0 + i * CW + CW / 2} y={Y0 - 9} textAnchor="middle" className="t-small">{research ? <Sc s={BLOCKS[i]} /> : String(i + 1)}</text>
            <text x={X0 - 6} y={Y0 + i * CH + CH / 2 + 4} textAnchor="end" className="t-small">{research ? <Sc s={BLOCKS[i]} /> : String(i + 1)}</text>
          </g>
        ))}
        {[0, 1, 2, 3, 4].flatMap(r => [0, 1, 2, 3, 4].map(c => {
          const px = X0 + c * CW, py = Y0 + r * CH, key = r + ',' + c, on = key === sel, partner = r === sc && c === sr && !sdiag;
          if (r === c) return (
            <g key={key} className="fig-cell" onClick={() => setSel(key)} data-board-cell={key} data-gauge="1">
              <rect x={px + 2} y={py + 2} width={CW - 4} height={CH - 4} rx={5} className="ink" style={{ fillOpacity: 0.06, stroke: 'var(--fg)', strokeOpacity: on ? 1 : 0.3, strokeWidth: on ? 2.5 : 1 }} />
              <text x={px + CW / 2} y={py + CH / 2 + 4} textAnchor="middle" className="t-tiny t-muted">{research ? 'gauge' : 'force carriers'}</text>
            </g>
          );
          const t = typeOfCell(r, c), lb = FIG1[key], first = isFirstSetCell(r, c), faded = view === 'first' && !first;
          return (
            <g key={key} className="fig-cell" onClick={() => setSel(key)} data-board-cell={key} data-type={t} data-first={first ? 1 : 0} data-matches={cellMatches(r, c) ? 1 : 0}>
              <title>{research ? `${r + 1} → ${c + 1}: ${lb.map(labelText).join(', ')} · ${fmtShow(cell(r, c))} · ${TYPE_TXT[t]}` : `${plainName(r, c).join(' ')}`}</title>
              <rect x={px + 2} y={py + 2} width={CW - 4} height={CH - 4} rx={5} className="on-panel"
                style={{ stroke: 'var(--fg)', strokeOpacity: on || partner ? 1 : faded ? 0.25 : 0.6, strokeWidth: on ? 2.5 : partner ? 1.8 : 1, strokeDasharray: partner ? '5 3' : undefined, fillOpacity: 1 }} />
              {view === 'first' && first && <rect x={px + 4} y={py + 4} width={CW - 8} height={CH - 8} rx={4} className="ink" style={{ fillOpacity: 0.1 }} />}
              {research ? (
                <>
                  <text x={px + CW / 2} y={py + (doubled ? 19 : 25)} textAnchor="middle" className="t-small t-bold" style={{ opacity: faded ? 0.45 : 1 }}><Sc s={labelText(lb[0])} /></text>
                  {doubled && <text x={px + CW / 2} y={py + 33} textAnchor="middle" className="t-small" style={{ opacity: faded ? 0.45 : 1 }}><Sc s={labelText(lb[1])} /></text>}
                  <text x={px + CW - 6} y={py + CH - 6} textAnchor="end" className="t-mono t-micro t-muted"><Sc s={TYPE_TXT[t]} /></text>
                </>
              ) : (
                <>
                  <text x={px + CW / 2} y={py + 20} textAnchor="middle" className="t-micro t-bold" style={{ opacity: faded ? 0.45 : 1 }}>{plainName(r, c)[0]}</text>
                  <text x={px + CW / 2} y={py + 31} textAnchor="middle" className="t-micro" style={{ opacity: faded ? 0.45 : 1 }}>{plainName(r, c)[1]}</text>
                  {doubled && <g><circle cx={px + CW / 2 - 5} cy={py + CH - 9} r={2.6} className="ink" /><circle cx={px + CW / 2 + 5} cy={py + CH - 9} r={2.6} className="ink" /></g>}
                </>
              )}
            </g>
          );
        }))}
        <g transform={`translate(8, ${Y0 + 5 * CH + 20})`} data-tally={tally.map(([t, k]) => `${t}:${k}`).join(',')} data-complete={sets}>
          {tally.map(([t, k], i) => (research
            ? <text key={t} x={i * 68} y={0} className="t-small"><Sc s={TYPE_TXT[t]} />{`: ${k}`}</text>
            : <text key={t} x={(i % 2) * 204} y={Math.floor(i / 2) * 14} className="t-small">{`${TYPE_PLAIN[t].join(' ')}: ${k}`}</text>))}
          <text x={0} y={research ? 18 : 46} className="t-small">{`${research ? 'cells of each type' : 'boxes of each kind'} · complete sets: ${sets}`}</text>
        </g>
        {research && (
          <g transform={`translate(8, ${Y0 + 5 * CH + 58})`} data-cell={sel}>
            {sdiag ? <text x={0} y={0} className="t-small">{`gauge · `}<Sc s={BLOCKS[sr]} /></text> : (
              <>
                <text x={0} y={0} className="t-small">{`from ${sr} to ${sc} · irrep ${fmtShow(x)}, ${dimOf(x)}ℂ · type `}<Sc s={TYPE_TXT[typeOfCell(sr, sc)]} />{` · charges ${cellCharges(sr, sc).map(q => fmtQ(q.q) + (q.n > 1 ? ' ×' + q.n : '')).join(', ')}`}</text>
                <text x={0} y={16} className="t-small">{'labels '}{FIG1[sel].map((lb, i) => <tspan key={i}>{i ? ', ' : ''}<Sc s={labelText(lb)} />{` ${fmtShow(labelIrrep(lb))}`}</tspan>)}{` · transpose (${sc}, ${sr}) · ${cellMatches(sr, sc) ? 'every label = the irrep' : 'a label differs'}`}</text>
              </>
            )}
          </g>
        )}
      </FigSvg>
      <Controls label="board">
        <Chips label={research ? 'labels' : 'names'} items={[false, true]} value={doubled} onPick={setDoubled} render={d => (d ? (research ? 'both labels' : 'both names') : (research ? 'one label per cell' : 'one name per box'))} param="doubled" />
        <Chips label="shade" items={['type', 'first']} value={view} onPick={setView} render={v => (v === 'type' ? (research ? 'by type' : 'kind of particle') : (research ? 'first generation' : 'first family'))} param="view" />
        {research && (
          <label className="fig-group" data-param="cell"><span className="fig-group-label">cell</span>
            <select className="fig-select" data-param="cell" value={sel} onChange={e => setSel(e.target.value)}>
              {[...CELLS, '0,0', '1,1', '2,2', '3,3', '4,4'].map(k => { const [r, c] = k.split(',').map(Number); return <option key={k} value={k}>{r === c ? `${r} → ${c}: gauge` : `${r} → ${c}: ${FIG1[k].map(labelText).join(', ')}`}</option>; })}
            </select>
          </label>
        )}
      </Controls>
    </div>
  );
}
FureyBoard.meta = { id: 'furey-board', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
FureyBoard.data = () => ({ blocks: BLOCKS, cells: CELLS.map(k => { const [r, c] = k.split(',').map(Number); return { cell: k, labels: FIG1[k], irrep: fmtShow(cell(r, c)), type: typeOfCell(r, c), matches: cellMatches(r, c) }; }), byType: cellsByType(), completeSets: { onShell: completeSets(false), doubled: completeSets(true) } });
