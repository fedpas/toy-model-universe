// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure riemann-split (step 12): the independent components of the curvature in n dimensions, Riemann n²(n² − 1)/12 = Ricci n(n + 1)/2 + Weyl
// n(n + 1)(n + 2)(n − 3)/12 for n ≥ 3 (engines/labels.js curvature; gravity_selfcheck.py found the same dimensions by linear algebra, gravity.json curvature_space,
// n = 2 … 7). One bar per n = 2 … 8: the Ricci part solid, the Weyl part hollow, the total printed; at n = 2 the one component is the bar (the three Ricci
// components are fixed by it). The dashed line marks where Weyl starts, n = 4. The chips n = 2 … 8 are v15's (interactive entry n). Port of v15 LabelsWidgets.Curvature.
import React, { useState, useEffect } from 'react';
import { curvature } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, r1, pick, isIn } from './kit.jsx';

const NS = [2, 3, 4, 5, 6, 7, 8];
const ROWS = NS.map(curvature), MAX = ROWS[ROWS.length - 1].riemann;

export default function RiemannSplit({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [n, setN] = useState(pick(params.n, isIn(NS), 4));
  useEffect(() => { setN(pick(params.n, isIn(NS), 4)); }, [params.n]);
  const sc = 262 / MAX, x0 = 50, cur = curvature(n);
  return (
    <div className="fig fig-riemann-split">
      <FigSvg id="riemann-split" row={row} viewBox="0 0 420 262">
        {ROWS.map((r, i) => {
          const y = 8 + i * 30, wr = Math.max(2, (r.n === 2 ? 1 : r.ricci) * sc), ww = r.weyl * sc, on = r.n === n;
          return (
            <g key={r.n} data-n={r.n} data-riemann={r.riemann} data-ricci={r.n === 2 ? 1 : r.ricci} data-weyl={r.weyl}>
              <title>{r.n === 2 ? 'n = 2: Riemann 1, Weyl 0' : `n = ${r.n}: Riemann ${r.riemann} = Ricci ${r.ricci} + Weyl ${r.weyl}`}</title>
              {on && <rect x={0} y={y - 4} width={420} height={28} className="ink" style={{ fillOpacity: 0.06 }} data-selected={r.n} />}
              <text x={6} y={y + 15} className={'t-mono t-small' + (on ? ' t-bold' : '')}>{`n = ${r.n}`}</text>
              <rect x={x0} y={y} width={r1(wr)} height={20} className="ink" style={{ fillOpacity: 0.8 }} data-part="ricci" />
              {ww > 0 && <rect x={r1(x0 + wr)} y={y} width={r1(ww)} height={20} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1 }} data-part="weyl" />}
              <text x={r1(x0 + wr + ww + 6)} y={y + 15} className="t-mono t-small">{r.n === 2 ? '1' : `${r.riemann} = ${r.ricci} + ${r.weyl}`}</text>
            </g>
          );
        })}
        <line x1={40} y1={8 + 2 * 30 - 5} x2={415} y2={8 + 2 * 30 - 5} className="stroke-ink" style={{ strokeDasharray: '4 3' }} />
        <g transform="translate(50, 226)">
          <rect x={0} y={-9} width={12} height={10} className="ink" style={{ fillOpacity: 0.8 }} /><text x={17} y={0} className="t-small">Ricci</text>
          <rect x={70} y={-9} width={12} height={10} className="on-panel" style={{ stroke: 'var(--fg)' }} /><text x={87} y={0} className="t-small">Weyl</text>
          <text x={140} y={0} className="t-small t-muted">Riemann = Ricci + Weyl</text>
          {research && <text x={0} y={20} className="t-mono t-tiny" data-cur={n}>{n === 2 ? 'n = 2: Riemann 1 · Weyl 0' : `n = ${n}: Riemann ${cur.riemann} = Ricci ${cur.ricci} + Weyl ${cur.weyl}`}</text>}
        </g>
      </FigSvg>
      <Controls label="dimension">
        <Chips label="n" items={NS} value={n} onPick={setN} param="n" mono />
      </Controls>
    </div>
  );
}
RiemannSplit.meta = { id: 'riemann-split', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
RiemannSplit.data = () => ({ rows: ROWS });
