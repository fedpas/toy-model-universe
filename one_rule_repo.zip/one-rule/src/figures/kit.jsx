// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/kit.jsx — what every figure shares: the accessible SVG frame (role="img", aria-label and title from the caption row A passes), the clock colour
// token, the reduced-motion hook, a player that stays paused until its control is pressed, and the small controls (buttons, steppers, toggles, sliders), each
// marked with data-param (the param of the figure's `interactive` entry in content/figures.json) or data-play (the animation control).
// Colours are design tokens only (05 §1): var(--c0) … var(--c7) for the clock, var(--fg) var(--muted) var(--line) var(--line-2) var(--accent) var(--panel).
import React, { useEffect, useState } from 'react';

/** the clock colour token of c = 0 … 7 (always drawn with a printed "c = n" beside it) */
export const clockVar = c => `var(--c${((c % 8) + 8) % 8})`;
export const SUBS = '₀₁₂₃₄₅₆₇₈₉';
export const sub = k => String(k).replace(/\d/g, d => SUBS[d]);
export const fmt = x => (Object.is(x, -0) ? 0 : x) < 0 ? '−' + Math.abs(x) : String(Object.is(x, -0) ? 0 : x);
export const f2 = x => (Math.abs(x) < 5e-13 ? '0' : fmt(+x.toFixed(2)));

/** the accessible name of a figure: the text of the caption row when A passes one, else the figure id with the row id (no caption is invented here) */
export function figureLabel(id, row, part) {
  let base;
  if (typeof row === 'string') base = `${id} (${row})`;
  else {
    const t = row && (row.caption || row.text || row.body || row.short || row.label || row.title);
    base = t ? String(t) : row && row.id ? `${id} (${row.id})` : id;
  }
  return part ? `${base} — ${part}` : base;
}

/** the frame of every drawing: an inline SVG with role="img", aria-label, a title attribute and a <title> child */
export function FigSvg({ id, row, part, viewBox, className = '', children, ...rest }) {
  const label = figureLabel(id, row, part);
  return (
    <svg className={'fig-svg ' + className} viewBox={viewBox} role="img" aria-label={label} title={label} preserveAspectRatio="xMidYMid meet" {...rest}>
      <title>{label}</title>
      {children}
    </svg>
  );
}

/** true when the reader asked for reduced motion (never true during server rendering) */
export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return undefined;
    let m; try { m = window.matchMedia('(prefers-reduced-motion: reduce)'); } catch (e) { return undefined; }
    const f = () => setReduced(!!m.matches); f();
    if (m.addEventListener) m.addEventListener('change', f); else if (m.addListener) m.addListener(f);
    return () => { if (m.removeEventListener) m.removeEventListener('change', f); else if (m.removeListener) m.removeListener(f); };
  }, []);
  return reduced;
}

/**
 * A frame counter 0 … total that is paused until play() (the drawing starts complete, at `start`, default total).
 * Under reduced motion nothing moves by itself: step() jumps to the next stop of `stops` (or by one frame), and play() shows the end at once.
 */
export function usePlayer(total, { ms = 60, start = total, stops = null, resetKey = '', loop = false } = {}) {
  const reduced = useReducedMotion();
  const [frame, setFrame] = useState(start);
  const [playing, setPlaying] = useState(false);
  useEffect(() => { setFrame(start); setPlaying(false); }, [total, start, resetKey]);
  useEffect(() => {
    if (!playing) return undefined;
    if (reduced) { setFrame(loop ? frame : total); setPlaying(false); return undefined; }
    const id = setInterval(() => setFrame(f => (f >= total ? (loop ? 0 : f) : f + 1)), ms);
    return () => clearInterval(id);
  }, [playing, reduced, total, ms, loop]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (playing && !loop && frame >= total) setPlaying(false); }, [frame, playing, total, loop]);
  const play = () => { if (playing) { setPlaying(false); return; } if (frame >= total && !loop) setFrame(0); setPlaying(true); };
  const step = () => {
    setPlaying(false);
    setFrame(f => { if (f >= total) return 0; if (stops && stops.length) { const nx = stops.find(s => s > f); return nx === undefined ? total : nx; } return f + 1; });
  };
  return { frame, playing, reduced, play, step };
}

/** the play control: Play / Pause, or Step under reduced motion (an icon drawn in SVG, never an emoji). It is the animation control of 07 §3 (f), marked data-play;
 *  every other control of a figure is the port of a v15 control and carries data-param = the param of its `interactive` entry in figures.json (interface 13). */
export function PlayButton({ player, label = 'Play' }) {
  const { playing, reduced, play, step } = player;
  const icon = playing
    ? <svg className="fig-icon" viewBox="0 0 12 12" aria-hidden="true"><rect x="2" y="2" width="3" height="8" /><rect x="7" y="2" width="3" height="8" /></svg>
    : <svg className="fig-icon" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 2 L10 6 L3 10 Z" /></svg>;
  if (reduced) return <button type="button" className="fig-btn" data-play="step" onClick={step}>{icon}<span>Step</span></button>;
  return <button type="button" className="fig-btn" data-play="play" onClick={play} aria-pressed={playing}>{icon}<span>{playing ? 'Pause' : label}</span></button>;
}
/** a plain action button of the animation (a step forward, a reset): data-play as well */
export function PlayAction({ label, onClick, kind = 'step' }) {
  return <button type="button" className="fig-btn" data-play={kind} onClick={onClick}>{label}</button>;
}

export function Controls({ children, label }) { return <div className="fig-controls" role="group" aria-label={label}>{children}</div>; }

/** a − value + stepper for a small integer */
export function Stepper({ label, value, min, max, onChange, display, param }) {
  return (
    <span className="fig-group" data-param={param}>
      <span className="fig-group-label">{label}</span>
      <button type="button" className="fig-btn fig-btn-sq" data-param={param} aria-label={`${label} minus one`} disabled={value <= min} onClick={() => onChange(value - 1)}>−</button>
      <span className="fig-num" aria-live="polite">{display ? display(value) : value}</span>
      <button type="button" className="fig-btn fig-btn-sq" data-param={param} aria-label={`${label} plus one`} disabled={value >= max} onClick={() => onChange(value + 1)}>+</button>
    </span>
  );
}

/** a row of toggle or radio buttons */
export function Chips({ label, items, value, onPick, render = x => String(x), isOn = (x, v) => x === v, mono = false, param, aria }) {
  return (
    <span className="fig-group" role="group" aria-label={label || aria} data-param={param}>
      {label ? <span className="fig-group-label">{label}</span> : null}
      {items.map((x, i) => <button key={i} type="button" className={'fig-btn' + (mono ? ' fig-mono' : '')} data-param={param} aria-pressed={!!isOn(x, value)} onClick={() => onPick(x)}>{render(x)}</button>)}
    </span>
  );
}

/** one on/off button */
export function Toggle({ label, on, onChange, param }) {
  return <button type="button" className="fig-btn" data-param={param} aria-pressed={!!on} onClick={() => onChange(!on)}>{label}</button>;
}

/** a slider (research level only: the learner level has no slider, tests/figures.render.test.mjs) */
export function Range({ label, value, min, max, step = 1, onChange, display, param }) {
  return (
    <label className="fig-group" data-param={param}>
      <span className="fig-group-label">{label}</span>
      <input className="fig-range" type="range" data-param={param} min={min} max={max} step={step} value={value} aria-label={label} onChange={e => onChange(+e.target.value)} />
      <span className="fig-num">{display ? display(value) : value}</span>
    </label>
  );
}

/** a parameter of figures.json params (FigureFrame passes them) when it is one of the allowed values, else the default */
export const pick = (v, ok, d) => (ok(v) ? v : d);
export const isIn = list => v => list.includes(v);

/** an arrowhead at (x2, y2) pointing from (x1, y1); returns a path d */
export function arrowHead(x1, y1, x2, y2, size = 7) {
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, bx = x2 - ux * size, by = y2 - uy * size;
  return `M${r1(x2)} ${r1(y2)} L${r1(bx - uy * size * 0.5)} ${r1(by + ux * size * 0.5)} L${r1(bx + uy * size * 0.5)} ${r1(by - ux * size * 0.5)} Z`;
}
export const r1 = x => Math.round(x * 10) / 10;

/** the label lens of the kernel printer (engines/bitrule.js label) a page lens maps to, or null for the figure's own default */
export function labelLens(lens) {
  switch (lens) {
    case 'bits': case 'primes': case 'sigword': case 'bitsq': case 'clifford': return lens;
    case 'prime': return 'primes';
    case 'cube': return 'bits';
    case 'simplex': return 'set';
    default: return null;
  }
}

/** a short formula string for an SVG <text>: "_x" / "^x" (x a run of letters and digits, or {…}) become sub- and superscript tspans — "B_A", "ω^A", "dx^{μν}".
 *  The shift is a dy (in the small type's em) and the next plain run shifts back by the same amount in the parent's em, which every browser draws alike. */
const SMALL = 0.72, DOWN = 0.32, UP = -0.42;   // the sub/superscript size and its shift, in the parent's em
export function tx(s) {
  const out = []; let k = 0, last = 0, off = 0; const re = /([_^])(?:\{([^}]*)\}|([\p{L}\p{N}]+))/gu; let m;
  const plain = t => { if (!t) return; if (off) { out.push(<tspan key={k++} dy={`${+(-off).toFixed(3)}em`}>{t}</tspan>); off = 0; } else out.push(t); };
  while ((m = re.exec(s))) {
    plain(s.slice(last, m.index));
    const to = m[1] === '_' ? DOWN : UP;
    out.push(<tspan key={k++} dy={`${+((to - off) / SMALL).toFixed(3)}em`} style={{ fontSize: `${SMALL * 100}%` }}>{m[2] ?? m[3]}</tspan>);
    off = to; last = re.lastIndex;
  }
  plain(s.slice(last));
  return out;
}
