// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure schuller-chain (the Schuller lens): his chain, our trail — the seven stones of the report's Fig. 1, from the matter action to the gravitational closure
// equations, in his order. Each stone is taken from the rows it rests on: engines/schullerEngine.js STONES gives the rows (C1 … C8, C11, C12 of the translation
// matrix) and the ids of the scripts behind it; the name is the title of the stone's first row in content/matrix.json (read as the Logbook reads it,
// useTable('matrix'), or params.matrix) without its section reference, and the grade is drawn as the border — E exact a double line, S structural a single line,
// A analogy a dashed line — the best grade of the first row's cells (tests/figures.render.test.mjs recomputes it). The controls are v15's (SchullerWidgets SW1):
// a stone (its rows, their cells and the notes quoted from the report open under the chain; the script ids at research level) and, on stone 3, the map of the cells
// Cl(k, d), n = k + d = 2 … 9, hyperbolic or not (schullerEngine.js hypMap, the same cells as lens_sch_check.py stores, P1). Port of v15 SchullerWidgets.SW1.
import React, { useState, useEffect, useMemo } from 'react';
import { STONES, hypMap } from '../../engines/schullerEngine.js';
import { LENS_SCH } from '../../engines/stored.js';
import { useTable } from '../app/content.js';
import { FigSvg } from './kit.jsx';

const okMatrix = m => !!m && Array.isArray(m.rows) && Array.isArray(m.columns);
const GRADE = { E: 'exact', S: 'structural', A: 'analogy' };
const KIND = { hyperbolic: 'H', elliptic: 'e', ultrahyperbolic: 'u' };
/** the best grade of a row's cells (E, then S, then A; '-' for a row with no cell) */
export const bestGrade = r => { const g = Object.values((r && r.cells) || {}).map(c => c.grade); return g.includes('E') ? 'E' : g.includes('S') ? 'S' : g.includes('A') ? 'A' : '-'; };
/** a stone's name: the title of its first row without the section reference */
export const stoneName = title => String(title || '').replace(/\s*\((closure|review)\b.*$/, '').trim();
let MAP = null; const liveMap = () => MAP || (MAP = hypMap(2, 9));

function Border({ g, x, y, w, h }) {
  if (g === 'E') return <g><rect x={x} y={y} width={w} height={h} rx={7} className="stroke-ink" style={{ strokeWidth: 1.1 }} /><rect x={x + 2.6} y={y + 2.6} width={w - 5.2} height={h - 5.2} rx={5} className="stroke-ink" style={{ strokeWidth: 1.1 }} /></g>;
  if (g === 'A') return <rect x={x} y={y} width={w} height={h} rx={7} className="stroke-ink" style={{ strokeWidth: 1.2, strokeDasharray: '4 3' }} />;
  return <rect x={x} y={y} width={w} height={h} rx={7} className="stroke-ink" style={{ strokeWidth: 1.4 }} />;
}

export default function SchullerChain({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [M0] = useTable('matrix');
  const M = okMatrix(params.matrix) ? params.matrix : okMatrix(M0) ? M0 : null;
  const okStone = v => Number.isInteger(v) && v >= 1 && v <= STONES.length;
  const [sel, setSel] = useState(okStone(params.stone) ? params.stone : null), [grid, setGrid] = useState(params.grid === true);
  useEffect(() => { setSel(okStone(params.stone) ? params.stone : null); }, [params.stone]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setGrid(params.grid === true); }, [params.grid]);
  const rowOf = useMemo(() => { const m = new Map(); if (M) for (const r of M.rows) if (r.src === 'schuller') m.set(r.id, r); return m; }, [M]);
  const st = sel ? STONES[sel - 1] : null, showGrid = grid && sel === 3;
  const map = useMemo(() => (showGrid ? liveMap() : null), [showGrid]);
  const SH = 30, Y0 = 8, H = Y0 + STONES.length * SH + 22;
  const pick = id => setSel(s => (s === id ? null : id));
  return (
    <div className="fig fig-schuller-chain">
      <FigSvg id="schuller-chain" row={row} viewBox={`0 0 420 ${H}`}>
        <line x1={16} y1={Y0 + 12} x2={16} y2={Y0 + (STONES.length - 1) * SH + 12} className="stroke-muted" style={{ strokeWidth: 1.4 }} />
        {STONES.map((s, i) => {
          const y = Y0 + i * SH, first = rowOf.get(s.rows[0]), on = sel === s.id;
          return (
            <g key={s.id} role="button" tabIndex={0} aria-pressed={on} aria-label={`stone ${s.id}${research ? `, ${GRADE[s.grade]}` : ''}${first ? `: ${stoneName(first.title)}` : ''}`} data-param="stone" className="fig-cell"
              data-stone={s.id} data-grade={s.grade} data-rows={s.rows.join(',')} data-first-best={first ? bestGrade(first) : ''} onClick={() => pick(s.id)}
              onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(s.id); } }}>
              {on && <rect x={32} y={y} width={384} height={SH - 6} rx={7} className="ink" style={{ fillOpacity: 0.08 }} />}
              <Border g={s.grade} x={32} y={y} w={384} h={SH - 6} />
              <circle cx={16} cy={y + 12} r={10} className={on ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.2 }} />
              <text x={16} y={y + 15.5} textAnchor="middle" className="t-small t-bold" style={on ? { fill: 'var(--panel)' } : undefined}>{s.id}</text>
              {research && <text x={44} y={y + 15.5} className="t-mono t-small t-bold">{s.grade}</text>}
              <text x={research ? 60 : 44} y={y + 15.5} className="t-small">{first ? stoneName(first.title) : s.rows.join(', ')}</text>
            </g>
          );
        })}
        <g transform={`translate(32, ${H - 8})`}>
          {['E', 'S', 'A'].map((g, i) => (
            <g key={g} transform={`translate(${i * 112}, 0)`}>
              <Border g={g} x={0} y={-10} w={26} h={13} />
              <text x={32} y={0} className="t-tiny">{research ? `${g} ${GRADE[g]}` : GRADE[g]}</text>
            </g>
          ))}
        </g>
      </FigSvg>
      {st && (
        <div className="fig-note" data-panel={st.id}>
          {st.rows.map(id => { const r = rowOf.get(id); return (
            <div key={id} data-row={id}>
              <p><code className="fig-mono">{id}</code> <b lang="en">{r ? r.title : '…'}</b></p>
              {research && r && (Object.keys(r.cells || {}).length
                ? <ul>{(M.columns || []).filter(k => r.cells[k.key]).map(k => <li key={k.key}><span className="fig-mono">{r.cells[k.key].grade}</span> <b>{k.long}</b> <span lang="en">{r.cells[k.key].note}</span></li>)}</ul>
                : <p>No cell: a gap.</p>)}
            </div>); })}
          {research && <p><span className="fig-group-label">checks</span> {st.checks.length ? st.checks.map(c => <code key={c} className="fig-mono">{c}</code>) : <span>none: the atlas only reads this stone</span>}</p>}
          {st.id === 3 && <p><button type="button" className="fig-btn" data-param="grid" aria-expanded={showGrid} onClick={() => setGrid(g => !g)}>{showGrid ? 'Hide the cells' : 'Show the cells Cl(k, d)'}</button></p>}
        </div>
      )}
      {showGrid && map && (
        <FigSvg id="schuller-chain" row={row} part="cells" viewBox="0 0 420 214">
          <text x={40} y={12} className="t-tiny t-bold">{research ? 'Cl(k, d), n = k + d = 2 … 9: the first condition of stone 3 for a quadratic P' : 'which cells pass the first test'}</text>
          <text x={30} y={34} textAnchor="end" className="t-mono t-micro t-muted">d \ k</text>
          {Array.from({ length: 10 }, (_, k) => <text key={'k' + k} x={40 + k * 20 + 10} y={34} textAnchor="middle" className="t-mono t-micro">{k}</text>)}
          {Array.from({ length: 10 }, (_, d) => (
            <g key={'d' + d}>
              <text x={30} y={40 + d * 16 + 11} textAnchor="end" className="t-mono t-micro">{d}</text>
              {Array.from({ length: 10 }, (_, k) => {
                const n = k + d; if (n < 2 || n > 9) return null;
                const kind = map.cells[`${k},${d}`], x = 40 + k * 20, y = 40 + d * 16;
                return (
                  <g key={k} data-hyp={`${k},${d}`} data-kind={kind}>
                    <rect x={x + 1} y={y + 1} width={18} height={14} rx={2} className={kind === 'hyperbolic' ? 'ink' : 'on-panel'}
                      style={kind === 'hyperbolic' ? { fillOpacity: 0.2, stroke: 'var(--fg)' } : { stroke: 'var(--line)' }} />
                    <text x={x + 10} y={y + 11} textAnchor="middle" className="t-mono t-micro">{research ? KIND[kind] : kind === 'hyperbolic' ? '✓' : '·'}</text>
                  </g>
                );
              })}
            </g>
          ))}
          <g transform="translate(262, 52)">
            {(research ? [['hyperbolic', 'H hyperbolic'], ['elliptic', 'e elliptic'], ['ultrahyperbolic', 'u ultrahyperbolic']] : [['hyperbolic', '✓ passes'], ['elliptic', '· does not']]).map(([kind, lab], i) => (
              <g key={kind} transform={`translate(0, ${i * 20})`}>
                <rect x={0} y={-10} width={18} height={14} rx={2} className={kind === 'hyperbolic' ? 'ink' : 'on-panel'} style={kind === 'hyperbolic' ? { fillOpacity: 0.2, stroke: 'var(--fg)' } : { stroke: 'var(--line)' }} />
                <text x={9} y={0.5} textAnchor="middle" className="t-mono t-micro">{lab.split(' ')[0]}</text>
                <text x={24} y={1} className="t-tiny">{lab.split(' ').slice(1).join(' ')}</text>
              </g>
            ))}
            <text x={0} y={research ? 66 : 46} className="t-micro t-muted" data-hyperbolic={map.hyperbolic}>{`${map.hyperbolic} hyperbolic cells: k = 1 or d = 1`}</text>
            {research && <text x={0} y={80} className="t-micro t-muted" data-stored-match={JSON.stringify(map.cells) === JSON.stringify(LENS_SCH.p1.cells) ? 1 : 0}>{JSON.stringify(map.cells) === JSON.stringify(LENS_SCH.p1.cells) ? 'the cells lens_sch_check.py stores (P1)' : 'differs from lens_sch_check.py (P1)'}</text>}
          </g>
        </FigSvg>
      )}
    </div>
  );
}
SchullerChain.meta = { id: 'schuller-chain', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
SchullerChain.data = (params = {}) => {
  const M = okMatrix(params.matrix) ? params.matrix : null, rows = M ? new Map(M.rows.filter(r => r.src === 'schuller').map(r => [r.id, r])) : null;
  return { stones: STONES.map(s => ({ ...s, name: rows && rows.get(s.rows[0]) ? stoneName(rows.get(s.rows[0]).title) : null })), cells: liveMap().cells, hyperbolic: liveMap().hyperbolic, ok: liveMap().ok };
};
