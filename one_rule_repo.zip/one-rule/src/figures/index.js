// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/index.js — FIGURES: figure id (content/figures.json) → React component taking { params, lens, level, theme, row } (docs/BUILD_CONTRACTS.md, interface 2).
// Each component draws inline SVG with the design tokens only, starts paused when animated, and carries Component.meta = { id, lenses, learner }.
// A's FigureFrame renders the caption, the "what this draws" line and the lens chips from the caption row; a figure draws and never writes a caption.
// The stylesheet below is imported here so that the esbuild bundle of the app carries it into dist/app.css.
import './figures.css';
import Lattice from './Lattice.jsx';
import ClockWheel from './ClockWheel.jsx';
import FourViews from './FourViews.jsx';
import GaussSum from './GaussSum.jsx';
import Trinity from './Trinity.jsx';
import BivectorLab from './BivectorLab.jsx';
import PetrieOrthoplex from './PetrieOrthoplex.jsx';
import CommGraph from './CommGraph.jsx';
import DiracPic from './DiracPic.jsx';
import FourViewsMaxwell from './FourViewsMaxwell.jsx';
import MirrorsCube from './MirrorsCube.jsx';
import SpinFourI from './SpinFourI.jsx';
import CubeCategory from './CubeCategory.jsx';
import SignFlux from './SignFlux.jsx';
import EinsteinFormIdentity from './EinsteinFormIdentity.jsx';
import KerrSchildF from './KerrSchildF.jsx';
import FiveBits from './FiveBits.jsx';
import TennisRacket from './TennisRacket.jsx';
import SpringCube from './SpringCube.jsx';
import GossetPlane from './GossetPlane.jsx';
import Zonogon from './Zonogon.jsx';
import E8Ladder from './E8Ladder.jsx';
import KeplerTrio from './KeplerTrio.jsx';
import ExtraGenerator from './ExtraGenerator.jsx';
import Rain from './Rain.jsx';
import RiemannSplit from './RiemannSplit.jsx';
import GolayRing from './GolayRing.jsx';
import OQF2 from './OQF2.jsx';
import Ladders from './Ladders.jsx';
import FureyBoard from './FureyBoard.jsx';
import DictionaryBoards from './DictionaryBoards.jsx';
import NullFigures from './NullFigures.jsx';
import PgaOrbits from './PgaOrbits.jsx';
import HangIt from './HangIt.jsx';
import FreeTop from './FreeTop.jsx';
import OneTable from './OneTable.jsx';
import Bands from './Bands.jsx';
import SignedNetwork from './SignedNetwork.jsx';
import Charges from './Charges.jsx';
import HorizonFirstLaw from './HorizonFirstLaw.jsx';
import ConnectionForms from './ConnectionForms.jsx';
import BianchiCheck from './BianchiCheck.jsx';
import MatrixHeatmap from './MatrixHeatmap.jsx';
import SchullerChain from './SchullerChain.jsx';

export const FIGURES = {
  'lattice': Lattice,
  'clock-wheel': ClockWheel,
  'four-views': FourViews,
  'gauss-sum': GaussSum,
  'trinity': Trinity,
  'bivector-lab': BivectorLab,
  'petrie-orthoplex': PetrieOrthoplex,
  'comm-graph': CommGraph,
  'dirac-pic': DiracPic,
  'four-views-maxwell': FourViewsMaxwell,
  'mirrors-cube': MirrorsCube,
  'spin-four-i': SpinFourI,
  'cube-category': CubeCategory,
  'sign-flux': SignFlux,
  'einstein-form-identity': EinsteinFormIdentity,
  'kerr-schild-f': KerrSchildF,
  'five-bits': FiveBits,
  'tennis-racket': TennisRacket,
  'spring-cube': SpringCube,
  'gosset-plane': GossetPlane,
  'zonogon': Zonogon,
  'e8-ladder': E8Ladder,
  'kepler-trio': KeplerTrio,
  'extra-generator': ExtraGenerator,
  'rain': Rain,
  'riemann-split': RiemannSplit,
  'golay-ring': GolayRing,
  'o-q-f2': OQF2,
  'ladders': Ladders,
  'furey-board': FureyBoard,
  'dictionary-boards': DictionaryBoards,
  'null-figures': NullFigures,
  'pga-orbits': PgaOrbits,
  'hang-it': HangIt,
  'free-top': FreeTop,
  'one-table': OneTable,
  'bands': Bands,
  'signed-network': SignedNetwork,
  'charges': Charges,
  'horizon-first-law': HorizonFirstLaw,
  'connection-forms': ConnectionForms,
  'bianchi-check': BianchiCheck,
  'matrix-heatmap': MatrixHeatmap,
  'schuller-chain': SchullerChain,
};
export { Lattice, ClockWheel, FourViews, GaussSum, Trinity, BivectorLab, PetrieOrthoplex, CommGraph, DiracPic, FourViewsMaxwell, MirrorsCube, SpinFourI, CubeCategory, SignFlux, EinsteinFormIdentity, KerrSchildF, FiveBits, TennisRacket, SpringCube, GossetPlane, Zonogon, E8Ladder, KeplerTrio, ExtraGenerator, Rain, RiemannSplit, GolayRing, OQF2, Ladders, FureyBoard, DictionaryBoards, NullFigures, PgaOrbits, HangIt, FreeTop, OneTable, Bands, SignedNetwork, Charges, HorizonFirstLaw, ConnectionForms, BianchiCheck, MatrixHeatmap, SchullerChain };
export default FIGURES;
