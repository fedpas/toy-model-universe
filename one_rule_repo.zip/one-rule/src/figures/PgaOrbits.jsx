// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure pga-orbits (step 16, later rungs): Newton on bodies, in floating point (engines/pgaEngine.js newtonAcc, rk4Bodies, energyBodies, MOON, PLANET_G — the same
// constants as pgadyn_selfcheck.py rows N8 and N9, which prove the statements exactly). The Moon and the Earth in the plane, the orbit drawn relative to the Earth; or
// the Sun and five planets from the stored ephemeris of pgadyn.json (planets_data, 2018-01-16), drawn about the Sun on a square-root or a linear radial scale. The
// figure opens on a run already advanced by one Kepler period of the Moon (or one year), so that the orbit is on the page; Play goes on from there (paused until
// pressed, 07 §3), Reset starts again at t = 0. The readouts: the revolutions counted, the closed-form Kepler orbit of the starting state beside the stored constants
// (e, a, period), the planets' momentum fraction beside the stored one, and the drift of the energy and of the angular momentum. The controls are v15's: Moon or
// planets, RK4 or Euler, the time step, the Moon's starting speed, the radial scale, and Play / Step / Reset / speed. Port of v15 RigidWidgets2.Orbits.
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { newtonAcc, rk4Bodies, energyBodies, MOON, PLANET_G } from '../../engines/pgaEngine.js';
import { PGADYN as PD } from '../../engines/stored.js';
import { FigSvg, Controls, Chips, Range, PlayButton, PlayAction, useReducedMotion, r1, f2 } from './kit.jsx';

const PL = Object.keys(PD.planets_data), PMASS = PL.map(k => Number(PD.planets_data[k].mass_kg));
const euler1 = (st, mass, G, h) => { const a = newtonAcc(st.x, mass, G, st.x.map(p => p.map(() => 0))); return { x: st.x.map((p, i) => p.map((c, k) => c + h * st.v[i][k])), v: st.v.map((p, i) => p.map((c, k) => c + h * a[i][k])) }; };
export const moonInit = f => { const { mE, mM, vM, d } = MOON, cog = d * mM / (mE + mM); return { x: [[-cog, 0], [d - cog, 0]], v: [[0, -vM * f * cog / d], [0, vM * f * (d - cog) / d]] }; };
export const planetsInit = () => ({ x: PL.map(k => PD.planets_data[k].pos_km.map(Number)), v: PL.map(k => PD.planets_data[k].vel_kms.map(Number)) });
/** the closed-form Kepler orbit of the Moon's starting state (as v15 printed it): a, e and the period in days */
export function moonKepler(f = 1) { const mu = MOON.G * (MOON.mE + MOON.mM), r0 = MOON.d, v2 = (MOON.vM * f) ** 2, a = 1 / (2 / r0 - v2 / mu), e = r0 * v2 / mu - 1; return { a, e, T: a > 0 ? 2 * Math.PI * Math.sqrt(a ** 3 / mu) / 86400 : NaN, apogee: a * (1 + e) }; }
/** the planets' total momentum over the sum of the bodies' momenta, at the stored starting state */
export function momentumFraction(st = planetsInit()) { const en = energyBodies(st, PMASS, PLANET_G); return Math.hypot(...en.P) / st.v.reduce((s, v, i) => s + PMASS[i] * Math.hypot(...v), 0); }

/** a run: { st, t, trail, rev, last, th } advanced by k steps (the same bookkeeping as v15: the Moon's revolutions by its crossings of the x axis, the Earth's angle about the Sun) */
function makeRun(which, f) { const st = which === 'moon' ? moonInit(f) : planetsInit(), a0 = which === 'moon' ? 0 : Math.atan2(st.x[3][1] - st.x[0][1], st.x[3][0] - st.x[0][0]); return { which, st, t: 0, trail: PL.map(() => []), mtrail: [], rev: 0, last: 0, th: [a0, 0], e0: null }; }
function advanceRun(s, k, integ, h) {
  const mass = s.which === 'moon' ? [MOON.mE, MOON.mM] : PMASS, G = s.which === 'moon' ? MOON.G : PLANET_G; let st = s.st;
  if (!s.e0) s.e0 = energyBodies(st, mass, G);
  for (let i = 0; i < k; i++) {
    const prevY = st.x[1][1] - st.x[0][1]; st = integ === 'rk4' ? rk4Bodies(st, mass, G, h) : euler1(st, mass, G, h); s.t += h;
    if (s.which === 'moon') { const y = st.x[1][1] - st.x[0][1]; if (prevY < 0 && y >= 0 && st.x[1][0] > st.x[0][0]) { s.rev++; s.last = s.t; } }
    if (i % 3 === 0) { if (s.which === 'moon') s.mtrail.push([st.x[1][0] - st.x[0][0], st.x[1][1] - st.x[0][1]]); else st.x.forEach((p, b) => s.trail[b].push([p[0] - st.x[0][0], p[1] - st.x[0][1]])); }
    if (s.which === 'planets') { const e = st.x[3], su = st.x[0], ang = Math.atan2(e[1] - su[1], e[0] - su[0]); let d = ang - s.th[0]; d = Math.atan2(Math.sin(d), Math.cos(d)); s.th[1] += d; s.th[0] = ang; }
  }
  if (s.mtrail.length > 600) s.mtrail.splice(0, s.mtrail.length - 600);
  s.trail.forEach(tr => { if (tr.length > 900) tr.splice(0, tr.length - 900); });
  s.st = st; return s;
}
const PRERUN = new Map();
/** the opening state: the run advanced by one Kepler period of the Moon (or one year of the planets) with the given method and step; cached */
export function prerun(which, integ, h, f) {
  const key = [which, integ, h, f].join('|');
  if (!PRERUN.has(key)) { const days = which === 'moon' ? (Number.isFinite(moonKepler(f).T) ? moonKepler(f).T : 60) : 365.25; const s = makeRun(which, f); advanceRun(s, Math.ceil(days * 86400 / h), integ, h); PRERUN.set(key, s); }
  const s = PRERUN.get(key); return { ...s, st: s.st, trail: s.trail.map(t => t.slice()), mtrail: s.mtrail.slice(), th: s.th.slice() };
}
const clone = s => ({ ...s, trail: s.trail.map(t => t.slice()), mtrail: s.mtrail.slice(), th: s.th.slice() });

export default function PgaOrbits({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [which, setWhich] = useState(params.which === 'planets' ? 'planets' : 'moon');
  const [integ, setInteg] = useState(params.integ === 'euler' ? 'euler' : 'rk4');
  const [dt, setDt] = useState(5000), [pdt, setPdt] = useState(14400), [vf, setVf] = useState(100), [rad, setRad] = useState('sqrt'), [speed, setSpeed] = useState(1);
  useEffect(() => { setWhich(params.which === 'planets' ? 'planets' : 'moon'); setInteg(params.integ === 'euler' ? 'euler' : 'rk4'); }, [params.which, params.integ]);
  const h = which === 'moon' ? dt : pdt, f = vf / 100, key = `${which}|${f}`;
  const sim = useRef(null), [, setTick] = useState(0), [playing, setPlaying] = useState(false), reduced = useReducedMotion();
  const opening = useMemo(() => prerun(which, integ, h, f), [key]);   // eslint-disable-line react-hooks/exhaustive-deps
  if (!sim.current || sim.current.key !== key) sim.current = { key, run: clone(opening) };
  const s = sim.current.run;
  const advance = k => { advanceRun(s, k, integ, h); setTick(x => x + 1); };
  useEffect(() => { if (!playing || reduced) return undefined; const id = setInterval(() => advance(which === 'moon' ? 4 * speed : 6 * speed), 33); return () => clearInterval(id); }, [playing, reduced, speed, which, integ, h, key]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = { playing, reduced, play: () => setPlaying(p => !p), step: () => advance(which === 'moon' ? 100 : 60) };
  const reset = () => { sim.current = { key, run: makeRun(which, f) }; setPlaying(false); setTick(x => x + 1); };
  const mass = which === 'moon' ? [MOON.mE, MOON.mM] : PMASS, G = which === 'moon' ? MOON.G : PLANET_G;
  const en = energyBodies(s.st, mass, G), e0 = s.e0 || en, dE = Math.abs((en.E - e0.E) / e0.E), dL = Math.abs((en.Lz - e0.Lz) / e0.Lz);
  const days = s.t / 86400, kep = moonKepler(f), ms = 120 / (kep.a > 0 ? Math.max(MOON.d, kep.a * (1 + Math.abs(kep.e))) * 1.05 : 8e8);
  const pr = p => { const r = Math.hypot(p[0], p[1]) || 1, rr = rad === 'sqrt' ? 120 * Math.sqrt(r / 8.5e8) : 120 * r / 8.5e8; return [r1(180 + rr * p[0] / r), r1(130 - rr * p[1] / r)]; };
  const rel = b => [s.st.x[b][0] - s.st.x[0][0], s.st.x[b][1] - s.st.x[0][1]];
  const date = new Date(Date.UTC(2018, 0, 16) + s.t * 1000).toISOString().slice(0, 10), earthRev = s.th[1] / (2 * Math.PI);
  const H = research ? 330 : 280;
  return (
    <div className="fig fig-pga-orbits">
      <FigSvg id="pga-orbits" row={row} viewBox={`0 0 360 ${H}`}>
        {which === 'moon' ? (
          <g data-which="moon" data-rev={s.rev} data-days={days.toFixed(2)}>
            <path d={s.mtrail.map((p, i) => (i ? 'L' : 'M') + r1(180 + ms * p[0]) + ' ' + r1(130 - ms * p[1])).join(' ')} className="stroke-ink" style={{ strokeOpacity: 0.55, strokeWidth: 1.2 }} />
            <circle cx={180} cy={130} r={6} className="ink" /><text x={188} y={126} className="t-small">Earth</text>
            {(() => { const p = rel(1); return <g data-moon="1"><circle cx={r1(180 + ms * p[0])} cy={r1(130 - ms * p[1])} r={3.8} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.6 }} /><text x={r1(188 + ms * p[0])} y={r1(126 - ms * p[1])} className="t-small">Moon</text></g>; })()}
          </g>
        ) : (
          <g data-which="planets" data-days={days.toFixed(2)}>
            <circle cx={180} cy={130} r={5} className="ink" /><text x={187} y={126} className="t-tiny">Sun</text>
            {PL.slice(1).map((k, i) => { const b = i + 1, q = pr(rel(b)); return (
              <g key={k} data-planet={k}>
                <path d={s.trail[b].map((p, j) => (j ? 'L' : 'M') + pr(p).join(' ')).join(' ')} className="stroke-ink" style={{ strokeOpacity: 0.4, strokeWidth: 1 }} />
                <circle cx={q[0]} cy={q[1]} r={3.2} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />
                <text x={q[0] + 5} y={q[1] - 4} className="t-micro">{k}</text>
              </g>); })}
          </g>
        )}
        <text x={8} y={270} className="t-mono t-tiny" data-de={dE} data-dl={dL}>{`t = ${f2(days)} days · |ΔE/E| = ${dE.toExponential(1)} · |ΔL/L| = ${dL.toExponential(1)} (${integ === 'rk4' ? 'RK4' : 'Euler'})`}</text>
        {research && (which === 'moon'
          ? <>
            <text x={8} y={288} className="t-mono t-tiny">{s.rev ? `revolutions: ${s.rev}, ${f2(s.last / 86400 / s.rev)} days each` : 'no full revolution yet'}</text>
            <text x={8} y={304} className="t-mono t-tiny" data-kepler={`${kep.e.toFixed(4)},${Math.round(kep.a / 1000)},${kep.T.toFixed(2)}`}>{`Kepler from the start: e = ${kep.e.toFixed(4)}, a = ${Math.round(kep.a / 1000)} km, T = ${kep.T.toFixed(2)} days`}</text>
            {f === 1 && <text x={8} y={320} className="t-mono t-tiny t-muted" data-stored-moon={`${PD.moon.e},${PD.moon.a_km},${PD.moon.period_days}`}>{`stored (pgadyn.json): e = ${PD.moon.e}, a = ${PD.moon.a_km} km, T = ${PD.moon.period_days} days`}</text>}
          </>
          : <>
            <text x={8} y={288} className="t-mono t-tiny">{`${date} · revolutions of the Earth: ${f2(earthRev)}${earthRev >= 1 ? `, ${f2(days / earthRev)} days each` : ''}`}</text>
            <text x={8} y={304} className="t-mono t-tiny" data-momentum={momentumFraction().toFixed(3)}>{`momentum fraction at the start ${momentumFraction().toFixed(3)} · stored ${PD.planets.momentum_fraction}`}</text>
          </>)}
      </FigSvg>
      <Controls label="orbits">
        <Chips label={research ? 'bodies' : 'what'} items={['moon', 'planets']} value={which} onPick={w => { setWhich(w); setPlaying(false); }} render={w => (w === 'moon' ? 'Moon and Earth' : 'Sun and planets')} param="which" />
        {research && <Chips label="method" items={['rk4', 'euler']} value={integ} onPick={setInteg} render={m => (m === 'rk4' ? 'RK4' : 'Euler')} param="integ" />}
        {research && which === 'moon' && <Range label="Δt (s)" value={dt} min={1000} max={120000} step={1000} onChange={setDt} param="dt" />}
        {research && which === 'moon' && <Range label="starting speed (m/s)" value={vf} min={60} max={140} step={1} onChange={setVf} display={v => (v / 100 * MOON.vM).toFixed(0)} param="vf" />}
        {research && which === 'planets' && <Range label="Δt (h)" value={pdt} min={3600} max={432000} step={3600} onChange={setPdt} display={v => (v / 3600).toFixed(0)} param="dt" />}
        {research && which === 'planets' && <Chips label="radius" items={['sqrt', 'lin']} value={rad} onPick={setRad} render={r => (r === 'sqrt' ? '√r' : 'linear')} param="rad" />}
        <PlayButton player={player} />
        {research && <PlayAction label="Step" onClick={() => advance(which === 'moon' ? 100 : 60)} />}
        <PlayAction label="Reset" kind="reset" onClick={reset} />
        {research && <span className="fig-group" data-play="speed">{[1, 4, 16].map(k => <button key={k} type="button" className="fig-btn fig-btn-sq" data-play="speed" aria-pressed={speed === k} onClick={() => setSpeed(k)}>{`×${k}`}</button>)}</span>}
      </Controls>
    </div>
  );
}
PgaOrbits.meta = { id: 'pga-orbits', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
PgaOrbits.data = (params = {}) => { const which = params.which === 'planets' ? 'planets' : 'moon', s = prerun(which, 'rk4', which === 'moon' ? 5000 : 14400, 1), mass = which === 'moon' ? [MOON.mE, MOON.mM] : PMASS, G = which === 'moon' ? MOON.G : PLANET_G; return { which, days: s.t / 86400, revolutions: s.rev, energy: energyBodies(s.st, mass, G), energyStart: s.e0, kepler: moonKepler(1), momentumFraction: momentumFraction(), stored: { moon: PD.moon, planets: PD.planets } }; };
