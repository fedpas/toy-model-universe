// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure e8-ladder (step 19, Baez): the Levi ladder of E8. The 240 roots are built by engines/baezEngine.js (ladder, linkChain: exact, from D8 ∪ (D8 + ½));
// deleting α₈, α₇, α₆, α₅, α₄ in turn leaves the rungs E₇, E₆, D₅, A₄, A₂ + A₁. Each rung is a bar of its roots, split by the grade of the next deleted node: the
// middle (grade 0, solid) is the next rung — a band joins it to the bar below —, the two grade ±1 pieces are hollow, and the first step also has the grades ±2
// (240 = 1 + 56 + 126 + 56 + 1; then 3-graded). The selected step is outlined; under it, at research level, its grade-1 piece split under the su(3) + su(2) of the
// E7 paper as lens_baez_check.py stores it (LADDER_PIECES, bzw·P3b; a piece new at that step has a heavy border), and, with the second control, the sizes of the
// common neighbourhoods of a chain of adjacent roots (56, 27, 16, 10, 6, then 3). Both controls are v15's (the step buttons, the links chip). Port of v15 BaezWidgets.BW3.
import React, { useState, useEffect, useMemo } from 'react';
import { ladder, linkChain, LADDER_PIECES } from '../../engines/baezEngine.js';
import { FigSvg, Controls, Chips, Toggle, r1, sub, pick, isIn } from './kit.jsx';

const STEPS = [8, 7, 6, 5, 4];
const RUNG = [['E', '8'], ['E', '7'], ['E', '6'], ['D', '5'], ['A', '4'], ['A', '2', ' + A', '1']];
const rungName = k => RUNG[k].map((s, i) => (i % 2 ? sub(s) : s)).join('');
const rep = p => `(${p.su3 === '3b' ? '3̄' : p.su3},${p.su2})`;
let CACHE = null;
const data = () => CACHE || (CACHE = { lad: ladder(), links: linkChain() });

export default function E8Ladder({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [step, setStep] = useState(pick(params.step, isIn(STEPS), 7));
  const [links, setLinks] = useState(params.links === true);
  useEffect(() => { setStep(pick(params.step, isIn(STEPS), 7)); setLinks(params.links === true); }, [params.step, params.links]);
  const { lad, links: chain } = useMemo(data, []);
  const k0 = STEPS.indexOf(step), x0 = 58, S = 300 / 240, top = 14, RH = research ? 48 : 40, bh = 14;
  const grades = k => (k === 0 ? [[-2, 1], [-1, lad.g1[0]], [0, lad.sizes[1]], [1, lad.g1[0]], [2, 1]] : k < 5 ? [[-1, lad.g1[k]], [0, lad.sizes[k + 1]], [1, lad.g1[k]]] : [[0, lad.sizes[5]]]);
  const segs = k => { let x = x0; return grades(k).map(([g, c]) => { const w = Math.max(c * S, 2.5), s = { g, c, x, w }; x += w; return s; }); };
  const pieces = LADDER_PIECES[String(step)] || null, prev = LADDER_PIECES[String(step - 1)] || [];
  const mult = (d, p) => (d.find(x => x.su3 === p.su3 && x.su2 === p.su2) || { m: 0 }).m;
  const ladderH = top + 6 * RH, H = ladderH + (research ? 82 : 6);
  return (
    <div className="fig fig-e8-ladder">
      <FigSvg id="e8-ladder" row={row} viewBox={`0 0 420 ${H}`}>
        {RUNG.map((_, k) => {
          const y = top + k * RH, sg = segs(k), on = k === k0, kept = sg.find(s => s.g === 0);
          const next = k < 5 ? { x: x0, w: Math.max(lad.sizes[k + 1] * S, 2.5), y: top + (k + 1) * RH } : null;
          return (
            <g key={k} data-rung={k} data-roots={lad.sizes[k]} data-dim={lad.dims[k]} data-g1={k < 5 ? lad.g1[k] : undefined} data-graded={k < 5 ? lad.graded[k] : undefined}>
              {next && <polygon points={`${r1(kept.x)},${y + bh} ${r1(kept.x + kept.w)},${y + bh} ${r1(next.x + next.w)},${next.y} ${r1(next.x)},${next.y}`} className="ink" style={{ fillOpacity: on ? 0.16 : 0.06 }} />}
              <text x={x0 - 8} y={y + 11} textAnchor="end" className="t-head">{rungName(k)}</text>
              {sg.map(s => (
                <rect key={s.g} x={r1(s.x)} y={y} width={r1(s.w)} height={bh} className={s.g === 0 || Math.abs(s.g) === 2 ? 'ink' : 'on-panel'} data-grade={s.g} data-count={s.c}
                  style={s.g === 0 ? { fillOpacity: 0.78 } : Math.abs(s.g) === 2 ? undefined : { stroke: 'var(--fg)', strokeWidth: 1 }}>
                  <title>{`${rungName(k)}: ${s.c} root${s.c === 1 ? '' : 's'} of grade ${s.g}${k < 5 ? ` for α${sub(STEPS[k])}` : ''}`}</title>
                </rect>
              ))}
              {on && k < 5 && <rect x={x0 - 3} y={y - 3} width={r1(sg.reduce((a, s) => a + s.w, 0) + 6)} height={bh + 6} rx={3} className="stroke-ink" style={{ strokeWidth: 1.6 }} data-selected={step} />}
              <text x={x0} y={y + bh + 12} className="t-mono t-tiny t-muted">
                {research
                  ? `${lad.sizes[k]} roots · dim ${lad.dims[k]}${k < 5 ? ` · ${grades(k).map(([, c]) => c).join(' + ')}` : ''}${links && k < 5 ? ` · links ${chain[k + 1]}` : ''}`
                  : `${lad.sizes[k]} roots`}
              </text>
            </g>
          );
        })}
        {links && research && <text x={x0 + 300} y={top + 5 * RH + 11} textAnchor="end" className="t-mono t-tiny" data-chain={chain.join(',')}>{`then ${chain[6]}`}</text>}
        {research && (
          <g transform={`translate(${x0}, ${ladderH + 6})`} data-pieces={pieces ? step : 'none'}>
            <text x={0} y={0} className="t-small">{`${rungName(k0)} → ${rungName(k0 + 1)}: grade 1 = ${lad.g1[k0]} roots, ${lad.graded[k0]}-graded`}</text>
            {pieces
              ? pieces.reduce((acc, p) => { const nw = p.m - mult(prev, p), lab = `${p.m > 1 ? p.m + ' × ' : ''}${rep(p)} · ${p.m * p.dim}${nw > 0 ? ` +${nw}` : ''}`, w = 14 + lab.length * 5.4;
                if (acc.x + w > 350) { acc.x = 0; acc.y += 24; }
                acc.out.push(
                  <g key={p.su3 + p.su2} transform={`translate(${r1(acc.x)}, ${acc.y})`} data-piece={`${p.su3}|${p.su2}`} data-m={p.m} data-new={nw}>
                    <rect x={0} y={0} width={r1(w)} height={20} rx={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: nw > 0 ? 2 : 0.8 }} />
                    <text x={r1(w / 2)} y={14} textAnchor="middle" className="t-tiny">{lab}</text>
                  </g>); acc.x += w + 6; return acc; }, { x: 0, y: 10, out: [] }).out
              : <text x={0} y={24} className="t-tiny t-muted">pieces stored for the steps α₇ … α₄</text>}
          </g>
        )}
      </FigSvg>
      <Controls label="ladder">
        <Chips label="step" items={STEPS} value={step} onPick={setStep} render={n => `α${sub(n)}`} param="step" />
        {research && <Toggle label="links" on={links} onChange={setLinks} param="links" />}
      </Controls>
    </div>
  );
}
E8Ladder.meta = { id: 'e8-ladder', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
E8Ladder.data = () => { const { lad, links } = data(); return { rungs: RUNG.map((_, k) => rungName(k)), ...lad, links, pieces: LADDER_PIECES }; };
