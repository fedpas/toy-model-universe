// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure bianchi-check (steps 7 to 9, gravity): what gravity_selfcheck.py stores about its identities (checks/selfcheck/gravity.json, read through engines/stored.js,
// never recomputed). Top: the identities, each checked exactly on three independent random polynomial fields for n = 2 … 5 — second Bianchi, first Bianchi, the
// local Lorentz covariance of R and of T, the spinor commutator — and D E_a = torsion terms for n = 3, 4, 5 with c = 0 and c = 1: a filled dot where the identity
// holds with non-zero terms, a hollow ring where both sides are 0 (n = 2: 3-forms in two dimensions, no bound), a cross where it fails (none is stored). Bottom: the
// residual degree D of each check and its Schwartz–Zippel bound on a log scale, the hollow ring one field (D/101), the filled dot all three fields ((D/101)³), as the
// script stores them (sampling.bounds). No control: a new figure, v15 had none.
import React from 'react';
import { GRAVITY } from '../../engines/stored.js';
import { FigSvg, r1, tx } from './kit.jsx';

const NS = ['2', '3', '4', '5'];
/** the identity rows: [key of terms_nonzero, key of the truth value, label] */
export const IDENTITIES = [
  ['second_bianchi', 'second_bianchi', 'second Bianchi  D R = 0'],
  ['first_bianchi', 'first_bianchi', 'first Bianchi  D T = R ∧ e'],
  ['curvature_covariance', 'local_lorentz_covariance', 'Lorentz covariance of R'],
  ['torsion_covariance', 'local_lorentz_covariance', 'Lorentz covariance of T'],
  ['spinor_commutator', 'spinor_commutator', 'spinor  [D, D]ψ = ½Rψ'],
];
const frac = s => { const [a, b] = String(s).split('/').map(Number); return b ? a / b : a; };
const SUPS = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const pow10 = k => '10' + (k < 0 ? '⁻' : '') + String(Math.abs(k)).replace(/\d/g, d => SUPS[d]);

export default function BianchiCheck({ params = {}, lens = null, level = 'research', theme, row }) {
  const ID = GRAVITY.identities, EI = GRAVITY.einstein_identities, S = GRAVITY.sampling, B = Object.entries(S.bounds).sort((a, b) => frac(a[1].all_fields) - frac(b[1].all_fields));
  const CX = n => 262 + NS.indexOf(n) * 40, RY = i => 44 + i * 19;
  const mark = (kind, x, y, key, extra = {}) => kind === 'nonzero'
    ? <circle key={key} cx={x} cy={y} r={5} className="ink" {...extra} />
    : kind === 'trivial' ? <circle key={key} cx={x} cy={y} r={4.5} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.2 }} {...extra} />
      : <path key={key} d={`M${x - 4} ${y - 4} l8 8 M${x + 4} ${y - 4} l-8 8`} className="stroke-ink" style={{ strokeWidth: 1.6 }} {...extra} />;
  const BY = RY(IDENTITIES.length + 1) + 34, LO = -7, HI = -1, AX0 = 64, AX1 = 410, LX = v => AX0 + (Math.log10(v) - LO) / (HI - LO) * (AX1 - AX0), BR = 27;
  const H = BY + 22 + B.length * BR + 26;
  return (
    <div className="fig fig-bianchi-check">
      <FigSvg id="bianchi-check" row={row} viewBox={`0 0 420 ${H}`}>
        <text x={4} y={14} className="t-tiny t-bold">exact on three random polynomial fields</text>
        {NS.map(n => <text key={n} x={CX(n)} y={30} textAnchor="middle" className="t-mono t-micro">{`n = ${n}`}</text>)}
        {IDENTITIES.map(([tk, hk, lab], i) => (
          <g key={tk} data-identity={tk}>
            <text x={4} y={RY(i) + 3} className="t-micro">{lab}</text>
            {NS.map(n => { const holds = ID[n][hk] === true, nz = ID[n].terms_nonzero[tk] === true, kind = !holds ? 'fails' : nz ? 'nonzero' : 'trivial'; return mark(kind, CX(n), RY(i), n, { 'data-n': n, 'data-holds': holds ? 1 : 0, 'data-nonzero': nz ? 1 : 0 }); })}
          </g>
        ))}
        <g data-identity="einstein_divergence">
          <text x={4} y={RY(IDENTITIES.length) + 3} className="t-micro">{tx('D E_a = torsion terms  (c = 0 | 1)')}</text>
          <text x={CX('2')} y={RY(IDENTITIES.length) + 3} textAnchor="middle" className="t-micro t-muted">–</text>
          {NS.slice(1).flatMap(n => ['0', '1'].map((c, j) => { const holds = EI[`${n},${c}`]?.covariant_divergence_of_E_is_torsion_terms === true; return mark(holds ? 'nonzero' : 'fails', CX(n) - 6 + 12 * j, RY(IDENTITIES.length), `${n},${c}`, { r: holds ? 3.6 : undefined, 'data-n': n, 'data-c': c, 'data-holds': holds ? 1 : 0 }); }))}
        </g>
        <g transform={`translate(4, ${RY(IDENTITIES.length + 1) + 6})`}>
          {mark('nonzero', 4, -3, 'l1')}<text x={13} y={0} className="t-micro">holds, terms non-zero</text>
          {mark('trivial', 112, -3, 'l2')}<text x={121} y={0} className="t-micro">holds as 0 = 0 (no bound)</text>
          {mark('fails', 236, -3, 'l3')}<text x={245} y={0} className="t-micro">fails (none)</text>
        </g>
        <text x={4} y={BY} className="t-tiny t-bold">{`the bound: a false identity of degree D passes all ${S.fields_per_case} fields with probability ≤ (D/${S.values_per_coefficient})³`}</text>
        {Array.from({ length: HI - LO + 1 }, (_, k) => LO + k).map(e => (
          <g key={e}>
            <line x1={r1(LX(10 ** e))} y1={BY + 10} x2={r1(LX(10 ** e))} y2={BY + 16 + B.length * BR} className="hair-2" />
            <text x={r1(LX(10 ** e))} y={BY + 26 + B.length * BR} textAnchor="middle" className="t-mono t-micro t-muted">{pow10(e)}</text>
          </g>
        ))}
        {B.map(([name, b], i) => {
          const y = BY + 22 + i * BR, p1 = frac(b.one_field), p3 = frac(b.all_fields);
          return (
            <g key={name} data-bound={name} data-degree={b.degree} data-one={b.one_field} data-all={b.all_fields}>
              <text x={4} y={y + 13} className="t-mono t-micro">{`D = ${b.degree}`}</text>
              <text x={AX0} y={y} className="t-micro">{name.replace(/D E_a/, 'D Eₐ')}</text>
              <text x={AX1} y={y} textAnchor="end" className="t-mono t-micro t-muted">{`${b.all_fields} ≈ ${b.all_fields_decimal}`}</text>
              <line x1={r1(LX(p3))} y1={y + 10} x2={r1(LX(p1))} y2={y + 10} className="stroke-muted" />
              <circle cx={r1(LX(p1))} cy={y + 10} r={3.6} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.2 }} data-p={b.one_field} />
              <circle cx={r1(LX(p3))} cy={y + 10} r={4} className="ink" data-p={b.all_fields} />
            </g>
          );
        })}
        <text x={4} y={H - 4} className="t-micro t-muted">{`ring: one field (D/${S.values_per_coefficient}) · dot: all ${S.fields_per_case} · coefficients in −${S.coefficient_range} … ${S.coefficient_range} · gravity_selfcheck.py`}</text>
      </FigSvg>
    </div>
  );
}
BianchiCheck.meta = { id: 'bianchi-check', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
BianchiCheck.data = () => ({ identities: GRAVITY.identities, einstein_identities: GRAVITY.einstein_identities, sampling: GRAVITY.sampling });
