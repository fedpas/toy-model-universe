// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure kepler-trio (step 19, Baez): one square decides the orbit's algebra. With generator squares (+1, +1, +1, ε) and ε = −sign(E), the six moves e_j e_k square
// to −1 (turn), 0 (slide) or +1 (stretch) — the kernel's sign of each bivector (engines/baezEngine.js kepler, exact; the Killing form's (positive, negative, zero)
// counts come with it) — so the energy picks so(4), e(3) or so(3,1). Left: the textbook conic r = 1/(1 + e cos θ), e = √(1 + 2E) (keplerOrbit, floating point: a
// picture, not a check), solid for the ellipse, dashed for the parabola, dotted for the hyperbola, as v15 drew them; right: the six moves as v15's small drawings
// (a circle with a dot: turn; a block on a track: slide; a bar pulled at both ends: stretch). Controls, as in v15: the energy slider (research level) and the three
// presets. Port of v15 BaezWidgets.BW4.
import React, { useState, useEffect, useMemo } from 'react';
import { kepler, keplerOrbit, epsOfEnergy, MOVES } from '../../engines/baezEngine.js';
import { FigSvg, Controls, Chips, Range, r1, sub, pick } from './kit.jsx';

const PRESET_E = { 1: -0.3, 0: 0, '-1': 0.3 };
const KIND = { 1: ['ellipse', 'loops round'], 0: ['parabola', 'just escapes'], '-1': ['hyperbola', 'flies past'] };
const ALG = { 1: 'so(4)', 0: 'e(3)', '-1': 'so(3,1)' };
const MOVE = { '-1': 'turn', 0: 'slide', 1: 'stretch' };
const DASH = { 1: undefined, 0: '7 4', '-1': '2 4' };
const sgn = v => (v > 0 ? '+' + v : v < 0 ? '−' + -v : '0');
const moveName = m => 'e' + sub([0, 1, 2, 3].filter(i => (m >> i) & 1).map(i => i + 1).join(''));
let K = null;
const trio = () => K || (K = Object.fromEntries([1, 0, -1].map(e => [e, kepler(e)])));

function MoveIcon({ q, x, y }) {
  if (q === -1) return <g transform={`translate(${x}, ${y})`}><circle cx={0} cy={0} r={7} className="stroke-ink" style={{ strokeWidth: 1.6 }} /><circle cx={7} cy={0} r={2.2} className="ink" /></g>;
  if (q === 0) return <g transform={`translate(${x}, ${y})`}><line x1={-11} y1={4} x2={11} y2={4} className="stroke-ink" style={{ strokeWidth: 1.6 }} /><rect x={-4} y={-4} width={8} height={6} className="ink" /></g>;
  return <g transform={`translate(${x}, ${y})`}><line x1={-8} y1={0} x2={8} y2={0} className="stroke-ink" style={{ strokeWidth: 3 }} /><path d="M-13 0 L-8 -4 L-8 4 Z M13 0 L8 -4 L8 4 Z" className="ink" /></g>;
}

export default function KeplerTrio({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const init = () => (Number.isFinite(params.E) && params.E >= -0.4 && params.E <= 0.4 ? Math.round(params.E * 10) : -3);
  const [s, setS] = useState(init);
  useEffect(() => { setS(init()); }, [params.E]);   // eslint-disable-line react-hooks/exhaustive-deps
  const E = s / 10, eps = epsOfEnergy(E), T = useMemo(trio, []), k = T[eps], orbit = useMemo(() => keplerOrbit(E), [E]);
  const PW = 220, PH = 200, pad = 16, xs = [0, ...orbit.pts.map(q => q[0])], ys = [0, ...orbit.pts.map(q => q[1])];
  const sx = Math.max(...xs) - Math.min(...xs), sy = Math.max(...ys) - Math.min(...ys);
  const sc = Math.min(60, (PW - 2 * pad) / Math.max(1e-9, sx), (PH - 2 * pad) / Math.max(1e-9, sy));
  const ox = pad + (PW - 2 * pad - sx * sc) / 2 - Math.min(...xs) * sc, oy = pad + (PH - 2 * pad - sy * sc) / 2 + Math.max(...ys) * sc;
  const path = orbit.pts.map(([x, y], j) => `${j ? 'L' : 'M'}${r1(ox + x * sc)} ${r1(oy - y * sc)}`).join('');
  const H = 230;
  return (
    <div className="fig fig-kepler-trio">
      <FigSvg id="kepler-trio" row={row} viewBox={`0 0 420 ${H}`}>
        <g data-eps={eps} data-e={orbit.e.toFixed(4)}>
          <rect x={0.5} y={0.5} width={PW} height={PH} className="hair-2" />
          <path d={path} className="stroke-ink" style={{ strokeWidth: 2.2, strokeDasharray: DASH[eps] }} />
          <circle cx={r1(ox)} cy={r1(oy)} r={6} className="ink" /><text x={r1(ox + 9)} y={r1(oy - 8)} className="t-small">Sun</text>
          <text x={8} y={PH - 8} className="t-small">{KIND[eps][research ? 0 : 1]}</text>
        </g>
        <g transform="translate(236, 6)">
          {MOVES.map((m, j) => {
            const q = k.squares[j], cx = (j % 2) * 92, cy = Math.floor(j / 2) * 62;
            return (
              <g key={m} transform={`translate(${cx}, ${cy})`} data-move={m} data-sq={q}>
                <title>{`${moveName(m)} squares to ${sgn(q)}: ${MOVE[q]}`}</title>
                <rect x={0} y={0} width={86} height={56} rx={5} className="on-panel" style={{ stroke: 'var(--line)' }} />
                <MoveIcon q={q} x={43} y={16} />
                <text x={43} y={36} textAnchor="middle" className="t-small">{research ? moveName(m) : `move ${j + 1}`}</text>
                <text x={43} y={50} textAnchor="middle" className="t-tiny">{research ? `${MOVE[q]} (${sgn(q)})` : MOVE[q]}</text>
              </g>
            );
          })}
        </g>
        <text x={0} y={PH + 20} className={research ? 't-mono t-tiny' : 't-small'} data-killing={k.killing.join(',')} data-turn={k.turn} data-slide={k.slide} data-stretch={k.stretch}>
          {research
            ? `E = ${E === 0 ? '0' : (E < 0 ? '−' : '') + Math.abs(E).toFixed(1)} · ε = ${sgn(eps)} · Killing (${k.killing.join(', ')}) · ${ALG[eps]} · ${k.turn} turn, ${k.slide} slide, ${k.stretch} stretch`
            : `${k.turn} turn, ${k.slide} slide, ${k.stretch} stretch`}
        </text>
      </FigSvg>
      <Controls label="energy">
        {research && <Range label="E" value={s} min={-4} max={4} step={1} onChange={setS} display={v => (v === 0 ? '0' : (v < 0 ? '−' : '') + (Math.abs(v) / 10).toFixed(1))} param="E" />}
        <Chips label={research ? 'ε' : 'orbit'} items={[1, 0, -1]} value={eps} onPick={e => setS(Math.round(PRESET_E[e] * 10))} render={e => KIND[e][research ? 0 : 1]} param="preset" />
      </Controls>
    </div>
  );
}
KeplerTrio.meta = { id: 'kepler-trio', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
KeplerTrio.data = (params = {}) => { const E = Number.isFinite(params.E) ? params.E : -0.3, T = trio(); return { E, eps: epsOfEnergy(E), moves: MOVES, trio: T, orbitE: keplerOrbit(E).e }; };
