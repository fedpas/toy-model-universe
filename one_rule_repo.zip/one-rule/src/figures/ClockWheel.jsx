// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure clock-wheel: the eight clock classes c = 0 … 7 as sectors (colour var(--cN), always with the printed "c = n"), the chosen cell's sector,
// and the phase of its Gauss sum as an arrow (engines/labels.js clockWheel; the phase is π c / 4, core·B3). Port of the wheel of v15 LabelsWidgets.CellLattice.
import React, { useState, useEffect } from 'react';
import { clockWheel, TYPE_SYMBOL } from '../../engines/labels.js';
import { FigSvg, clockVar, Controls, Stepper, arrowHead, r1, fmt } from './kit.jsx';

const pt = (cx, cy, r, a) => [cx + r * Math.cos(a), cy - r * Math.sin(a)];
function wedge(cx, cy, r0, r, a0, a1) {
  const [x0, y0] = pt(cx, cy, r, a0), [x1, y1] = pt(cx, cy, r, a1), [x2, y2] = pt(cx, cy, r0, a1), [x3, y3] = pt(cx, cy, r0, a0);
  return `M${r1(x0)} ${r1(y0)} A${r} ${r} 0 0 0 ${r1(x1)} ${r1(y1)} L${r1(x2)} ${r1(y2)} A${r0} ${r0} 0 0 1 ${r1(x3)} ${r1(y3)} Z`;
}
const gaussText = (re, im) => { if (!im) return fmt(re); if (!re) return (im === 1 ? '' : im === -1 ? '−' : fmt(im)) + 'i'; return `${fmt(re)} ${im < 0 ? '−' : '+'} ${Math.abs(im) === 1 ? '' : Math.abs(im)}i`; };
export { gaussText };

/** the wheel as an SVG group, for this figure and for the lattice inset: sectors, "c = n" labels, types (research), the phase arrow.
 *  compact (the lattice inset): the "c = n" labels sit inside the sectors and the types are left to the lattice's slots. */
export function WheelDrawing({ cx, cy, R, p, q, level = 'research', compact = false }) {
  const W = clockWheel(p, q), r0 = R * (compact ? 0.42 : 0.46), gap = 0.022, research = level !== 'learner';
  const ang = W.angle, tip = r0 - (compact ? 3 : 5), [ax, ay] = pt(cx, cy, tip, ang);
  return (
    <g className="fig-wheel">
      <circle cx={cx} cy={cy} r={R} className="hair-2" />
      {W.sectors.map(s => {
        const a = s.c * Math.PI / 4, on = s.c === W.c, [lx, ly] = pt(cx, cy, compact ? (r0 + R) / 2 : R + 15, a), [tx, ty] = pt(cx, cy, (r0 + R) / 2, a);
        const anchor = compact || Math.abs(Math.cos(a)) < 0.3 ? 'middle' : Math.cos(a) > 0 ? 'start' : 'end';
        return (
          <g key={s.c}>
            <path d={wedge(cx, cy, r0, R, a - Math.PI / 8 + gap, a + Math.PI / 8 - gap)} style={{ fill: clockVar(s.c), fillOpacity: on ? 0.6 : 0.22, stroke: on ? 'var(--fg)' : 'none', strokeWidth: on ? 2 : 0 }}>
              <title>{`c = ${s.c}: ${TYPE_SYMBOL[s.type]}`}</title>
            </path>
            <text x={r1(lx)} y={r1(ly + (compact ? 3 : 4))} textAnchor={anchor} className={'t-mono ' + (compact ? 't-tiny' : 't-small') + (on ? ' t-bold' : '')}>{`c = ${s.c}`}</text>
            {research && !compact && <text x={r1(tx)} y={r1(ty + 4)} textAnchor="middle">{TYPE_SYMBOL[s.type]}</text>}
          </g>
        );
      })}
      <line x1={cx} y1={cy} x2={r1(ax)} y2={r1(ay)} className="stroke-ink" style={{ strokeWidth: compact ? 2 : 2.5, strokeLinecap: 'round' }} />
      <path d={arrowHead(cx, cy, ax, ay, compact ? 6 : 8)} className="ink" />
      <circle cx={cx} cy={cy} r={compact ? 2.5 : 3.5} className="ink" />
    </g>
  );
}

export default function ClockWheel({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const init = [Number.isInteger(params.p) ? params.p : 1, Number.isInteger(params.q) ? params.q : 3];
  const [[p, q], setPQ] = useState(init);
  useEffect(() => { setPQ(init); }, [params.p, params.q]);   // eslint-disable-line react-hooks/exhaustive-deps
  const nMax = params.nMax || 8, W = clockWheel(p, q), cx = 160, cy = 150, R = 104;
  return (
    <div className="fig fig-clock-wheel">
      <FigSvg id="clock-wheel" row={row} viewBox={research ? '0 0 320 330' : '0 0 320 306'}>
        <WheelDrawing cx={cx} cy={cy} R={R} p={p} q={q} level={level} />
        <text x={cx} y={292} textAnchor="middle" className="t-mono t-head">{research ? `Cl(${p},${q})` : `${p},${q}`}{research ? ` = ${W.algebra}` : ''}</text>
        {research && <text x={cx} y={312} textAnchor="middle" className="t-mono t-small t-muted">{`Σ iʷ = ${gaussText(W.gauss.re, W.gauss.im)}   ·   c = ${W.c}`}</text>}
      </FigSvg>
      {research && (
        <Controls label="cell">
          <Stepper label="p" value={p} min={0} max={nMax - q} onChange={v => setPQ([v, q])} param="p" />
          <Stepper label="q" value={q} min={0} max={nMax - p} onChange={v => setPQ([p, v])} param="q" />
        </Controls>
      )}
    </div>
  );
}
ClockWheel.meta = { id: 'clock-wheel', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
ClockWheel.data = (params = {}) => clockWheel(Number.isInteger(params.p) ? params.p : 1, Number.isInteger(params.q) ? params.q : 3);
