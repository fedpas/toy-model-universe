// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure trinity: an element X = a e1 + b e2 + c e12 of Cl(2,0) squares to the scalar a² + b² − c² (the kernel's product, engines/labels.js trinity), and the sign of
// that square sorts the flows exp(tX) into rotations (X² < 0), translations (X² = 0) and boosts (X² > 0). Research: the (ρ, c) plane with the cone ρ = |c|, and the
// phase plane of the spring x'' = −k x (X = springX(k)) with its orbits; learner: the three kinds side by side. Port of v15 LabelsWidgets.Trinity. Paused until play.
import React, { useState, useEffect, useMemo } from 'react';
import { trinity, trinityOrbit, springX, expTX, apply, matrixOf } from '../../engines/labels.js';
import { FigSvg, Controls, PlayButton, usePlayer, r1, f2 } from './kit.jsx';

const CLASS_WORD = { '-1': 'rotation', 0: 'translation', 1: 'boost' };
const STARTS = (() => { const s = []; for (const r of [0.7, 1.5, 2.3]) for (let i = 0; i < 6; i++) { const an = i * Math.PI / 3 + (r > 1 ? Math.PI / 6 : 0); s.push([r * Math.cos(an), r * Math.sin(an)]); } return s; })();
const FRAMES = 120;

/** where the marked point v0 = (1.5, 0) is at phase ph ∈ [0, 1) (v15's timing: one turn for a rotation, out and back for the other two) */
function markAt(a, b, c, ph) {
  const T = trinity(a, b, c), M = matrixOf(a, b, c), v0 = [1.5, 0], tri = ph < 0.5 ? ph * 2 - 0.5 : 1.5 - ph * 2; let tm;
  if (T.cls < 0) tm = ph * 2 * Math.PI / Math.sqrt(-T.s); else if (T.cls > 0) tm = tri * 2 * 2.6 / Math.sqrt(T.s); else tm = tri * 8 / Math.max(1e-9, Math.hypot(M[0][0] * v0[0], M[1][0] * v0[0]));
  return apply(expTX(a, b, c, tm), v0);
}

function PhasePlane({ x0, y0, size, a, b, c, ph }) {
  const S = size / 6, O = [x0 + size / 2, y0 + size / 2], sc = v => [r1(O[0] + v[0] * S), r1(O[1] - v[1] * S)];
  const orbits = useMemo(() => STARTS.map(v => ({ v, lines: trinityOrbit(a, b, c, v, { clip: 3 }) })), [a, b, c]);
  const mv = markAt(a, b, c, ph), inside = Math.abs(mv[0]) <= 3 && Math.abs(mv[1]) <= 3, m = sc(mv);
  return (
    <g>
      <rect x={x0} y={y0} width={size} height={size} className="hair-2" />
      <line x1={x0} y1={O[1]} x2={x0 + size} y2={O[1]} className="hair" />
      <line x1={O[0]} y1={y0} x2={O[0]} y2={y0 + size} className="hair" />
      {orbits.map(({ v, lines }, i) => (lines.length
        ? lines.map((L, j) => <path key={i + '-' + j} d={L.map((p, k) => (k ? 'L' : 'M') + sc(p).join(' ')).join('')} className="stroke-ink" style={{ strokeOpacity: 0.5, strokeWidth: 1.2 }} />)
        : <circle key={i} cx={sc(v)[0]} cy={sc(v)[1]} r={1.8} className="ink" />))}
      {inside && <circle cx={m[0]} cy={m[1]} r={5} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 2 }} />}
    </g>
  );
}

export default function Trinity({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [k, setK] = useState(Number.isFinite(params.k) ? params.k : 1);
  useEffect(() => { if (Number.isFinite(params.k)) setK(params.k); }, [params.k]);
  const player = usePlayer(FRAMES, { ms: 50, start: FRAMES / 4, loop: true, stops: [15, 30, 45, 60, 75, 90, 105, 120] });   // paused at a quarter: the marked point is at v0 for the boost and the translation
  const ph = (player.frame % FRAMES) / FRAMES;
  if (!research) {
    const kinds = [1, 0, -1];
    return (
      <div className="fig fig-trinity">
        <FigSvg id="trinity" row={row} viewBox="0 0 600 226">
          {kinds.map((kk, i) => { const [a, b, c] = springX(kk), T = trinity(a, b, c); return (
            <g key={kk}>
              <PhasePlane x0={10 + i * 200} y0={8} size={180} a={a} b={b} c={c} ph={ph} />
              <text x={100 + i * 200} y={214} textAnchor="middle" className="t-head">{CLASS_WORD[T.cls]}</text>
            </g>); })}
        </FigSvg>
        <Controls label="trinity"><PlayButton player={player} /></Controls>
      </div>
    );
  }
  const [a, b, c] = springX(k), T = trinity(a, b, c), rho = Math.hypot(a, b);
  const cx0 = 30, cy0 = 122, sx = 62, sy = 38, clampC = Math.max(-3, Math.min(3, c));
  return (
    <div className="fig fig-trinity">
      <FigSvg id="trinity" row={row} viewBox="0 0 500 270">
        <polygon points={`${cx0},${cy0} ${cx0 + 3 * sx},${cy0 - 3 * sy} ${cx0},${cy0 - 3 * sy}`} className="ink" style={{ fillOpacity: 0.1 }} />
        <polygon points={`${cx0},${cy0} ${cx0 + 3 * sx},${cy0 + 3 * sy} ${cx0},${cy0 + 3 * sy}`} className="ink" style={{ fillOpacity: 0.1 }} />
        <line x1={cx0} y1={cy0} x2={cx0 + 3 * sx} y2={cy0 - 3 * sy} className="stroke-ink" style={{ strokeWidth: 1.6 }} />
        <line x1={cx0} y1={cy0} x2={cx0 + 3 * sx} y2={cy0 + 3 * sy} className="stroke-ink" style={{ strokeWidth: 1.6 }} />
        <line x1={cx0} y1={8} x2={cx0} y2={236} className="hair" />
        <line x1={cx0} y1={cy0} x2={226} y2={cy0} className="hair" />
        <text x={222} y={cy0 - 6} textAnchor="end" className="t-small t-muted">ρ</text>
        <text x={cx0 + 6} y={18} className="t-small t-muted">c</text>
        <text x={cx0 + 8} y={cy0 - 2.3 * sy} className="t-small">{CLASS_WORD[-1]}</text>
        <text x={cx0 + 8} y={cy0 + 2.6 * sy} className="t-small">{CLASS_WORD[-1]}</text>
        <text x={cx0 + 3 * sx - 4} y={cy0 + 16} textAnchor="end" className="t-small">{CLASS_WORD[1]}</text>
        <circle cx={r1(cx0 + Math.min(3, rho) * sx)} cy={r1(cy0 - clampC * sy)} r={6} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 2 }} />
        <text x={cx0} y={256} className="t-mono t-small">{`X = ${f2(a)} e₁ + ${f2(b)} e₂ + ${f2(c)} e₁₂ · X² = ${f2(T.s)}`}</text>
        <PhasePlane x0={256} y0={8} size={236} a={a} b={b} c={c} ph={ph} />
        <text x={374} y={262} textAnchor="middle" className="t-head">{CLASS_WORD[T.cls]}</text>
      </FigSvg>
      <Controls label="trinity">
        <PlayButton player={player} />
        <label className="fig-group"><span className="fig-group-label">k</span>
          <input className="fig-range" type="range" min={-2} max={2} step={0.1} value={k} data-param="k" aria-label="k" onChange={e => setK(+e.target.value)} />
          <span className="fig-num">{f2(k)}</span>
        </label>
      </Controls>
    </div>
  );
}
Trinity.meta = { id: 'trinity', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
Trinity.data = (params = {}) => { const k = Number.isFinite(params.k) ? params.k : 1; return { k, ...trinity(...springX(k)) }; };
