// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure horizon-first-law (step 12, the classical shadow of the paper): the stored results of f2_first_law.py (engines/gravityChecks.js F2, every number read back
// from the shipped log by tests/engines.test.mjs), not a live computation. One bar for each of the 29 (member, horizon) pairs of the Kerr–Newman family the script
// checked, with the engine's surface gravity kH, angular velocity Ω, area Abar = A/(4π) and potential Φ: Smarr's M = kH Abar + 2 Ω J + (κ/2) Φ Q, J = M a, drawn as its
// three terms — kH Abar solid (to the left of 0 on an inner horizon, where kH < 0), 2 Ω J hollow, (κ/2) Φ Q shaded — with the mass M marked where they add up; the
// numbers are exact and every pair adds up to its M exactly. Under the bars: the first law dM = ½ kH dAbar + Ω dJ + (κ/2) Φ dQ held on every row for each coupling κ
// (1, 2, 4: stand-ins for 8πG), Smarr on all 29 pairs, and the wrong versions, each of which failed on every row where it can be seen.
import React from 'react';
import { F2, ratio } from '../../engines/gravityChecks.js';
import { FigSvg, r1, tx } from './kit.jsx';

const MEMBER = { Schwarzschild: 'Schwarzschild', RN: 'Reissner–Nordström', 'extremal RN': 'extremal RN', Kerr: 'Kerr', 'Kerr-Newman': 'Kerr–Newman' };
const sgn = s => String(s).replace('-', '−');
/** the three Smarr terms of a stored horizon, as Numbers (the test checks them exactly) */
export function smarrTerms(h) {
  const [, kappa, M, a, Q, , , kH, Om, Ab, Phi] = h, m = ratio(M);
  return { M: m, area: ratio(kH) * ratio(Ab), spin: 2 * ratio(Om) * m * ratio(a), charge: (kappa / 2) * ratio(Phi) * ratio(Q) };
}

export default function HorizonFirstLaw({ params = {}, lens = null, level = 'research', theme, row }) {
  const T = F2.horizons.map(smarrTerms), lo = Math.min(0, ...T.map(t => t.area)), hi = Math.max(...T.map(t => Math.max(t.area, 0) + t.spin + t.charge));
  const X0 = 150, X1 = 410, sc = (X1 - X0) / (hi - lo), X = v => X0 + (v - lo) * sc, RH = 10.5, top = 22;
  let y = top, last = null; const rows = [];
  F2.horizons.forEach((h, i) => { if (h[0] !== last) { if (last !== null) y += 7; rows.push({ head: h[0], y }); y += 12; last = h[0]; } rows.push({ i, y }); y += RH; });
  const H = y + 64;
  return (
    <div className="fig fig-horizon-first-law">
      <FigSvg id="horizon-first-law" row={row} viewBox={`0 0 420 ${H}`}>
        <defs>
          <pattern id="hfl-shade" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="4" className="stroke-ink" style={{ strokeOpacity: 0.55 }} /></pattern>
        </defs>
        <line x1={r1(X(0))} y1={top - 6} x2={r1(X(0))} y2={y} className="hair" />
        <text x={r1(X(0))} y={12} textAnchor="middle" className="t-mono t-micro t-muted">0</text>
        {[Math.ceil(lo), ...Array.from({ length: Math.floor(hi / 4) }, (_, k) => 4 * (k + 1))].filter(v => v !== 0).map(v => <g key={v}><line x1={r1(X(v))} y1={top - 6} x2={r1(X(v))} y2={y} className="hair-2" /><text x={r1(X(v))} y={12} textAnchor="middle" className="t-mono t-micro t-muted">{sgn(v)}</text></g>)}
        {rows.map((rw, k) => {
          if (rw.head) return <text key={'h' + k} x={4} y={rw.y + 8} className="t-tiny t-bold">{MEMBER[rw.head]}</text>;
          const h = F2.horizons[rw.i], t = T[rw.i], [, kappa, M, a, Q, hz] = h, yc = rw.y, bh = RH - 3;
          const pos0 = Math.max(0, 0), segs = [];
          if (t.area < 0) segs.push(['area', X(t.area), X(0)]); else if (t.area > 0) segs.push(['area', X(0), X(t.area)]);
          let x = X(Math.max(t.area, 0));
          if (t.spin > 0) { segs.push(['spin', x, x + t.spin * sc]); x += t.spin * sc; }
          if (t.charge > 0) { segs.push(['charge', x, x + t.charge * sc]); x += t.charge * sc; }
          return (
            <g key={rw.i} data-horizon={rw.i} data-member={h[0]} data-m={M} data-terms={[t.area, t.spin, t.charge].map(v => +v.toFixed(12)).join(',')}>
              <title>{`${MEMBER[h[0]]}, κ = ${kappa}, (M, a, Q) = (${M}, ${a}, ${Q}), ${hz} horizon r = ${h[6]}: surface gravity ${sgn(h[7])}, Ω = ${h[8]}, A/4π = ${h[9]}, Φ = ${h[10]}`}</title>
              <text x={X0 - 6} y={yc + bh - 1} textAnchor="end" className="t-mono t-micro">{`${sgn(M)}, ${a}, ${Q}${kappa !== 1 ? ` κ${kappa}` : ''} ${hz === 'outer' ? 'out' : 'in'}`}</text>
              {segs.map(([kind, a0, a1]) => <rect key={kind} x={r1(Math.min(a0, a1))} y={yc} width={r1(Math.max(0.8, Math.abs(a1 - a0)))} height={bh} data-term={kind}
                className={kind === 'area' ? 'ink' : 'on-panel'} style={kind === 'area' ? { fillOpacity: 0.8 } : kind === 'spin' ? { stroke: 'var(--fg)', strokeWidth: 0.8 } : { fill: 'url(#hfl-shade)', stroke: 'var(--fg)', strokeWidth: 0.8 }} />)}
              <path d={`M${r1(X(t.M))} ${yc - 1.5} l2.6 ${(bh + 3) / 2} l-2.6 ${(bh + 3) / 2} l-2.6 ${-(bh + 3) / 2} z`} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 0.8 }} data-mass={M} />
            </g>
          );
        })}
        <g transform={`translate(4, ${y + 14})`}>
          <rect x={0} y={-8} width={10} height={8} className="ink" style={{ fillOpacity: 0.8 }} /><text x={14} y={0} className="t-tiny">{tx('k_H Ā')}</text>
          <rect x={70} y={-8} width={10} height={8} className="on-panel" style={{ stroke: 'var(--fg)' }} /><text x={84} y={0} className="t-tiny">2 Ω J</text>
          <rect x={128} y={-8} width={10} height={8} style={{ fill: 'url(#hfl-shade)', stroke: 'var(--fg)' }} /><text x={142} y={0} className="t-tiny">(κ/2) Φ Q</text>
          <path d="M210 -9 l2.6 5 l-2.6 5 l-2.6 -5 z" className="ink" /><text x={217} y={0} className="t-tiny">M: Smarr adds up</text>
          <text x={0} y={18} className="t-mono t-micro" data-first-law={F2.firstLaw.map(f => `${f.kappa}:${f.rows}/${f.of}`).join(',')}>{`first law on every row: ${F2.firstLaw.map(f => `${f.rows}/${f.of} (κ = ${f.kappa})`).join(', ')} · Smarr ${F2.smarr.pairs}/${F2.smarr.of} pairs`}</text>
          <text x={0} y={32} className="t-mono t-micro" data-controls={F2.controls.length}>{`${F2.controls.length} wrong versions (2 kH, kH/2, −Φ, J = a, …) fail on every row they reach · ${F2.fails} fails`}</text>
          <text x={0} y={46} className="t-mono t-micro t-muted">f2_first_law.py · (M, a, Q) per bar, outer / inner horizon · Ā = A/4π</text>
        </g>
      </FigSvg>
    </div>
  );
}
HorizonFirstLaw.meta = { id: 'horizon-first-law', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
HorizonFirstLaw.data = () => ({ ...JSON.parse(JSON.stringify(F2)), smarrTerms: F2.horizons.map(smarrTerms) });
