// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure hang-it (step 16): a body — a segment, square, cube or tesseract — or a chain of up to three, hung from a spring on the ceiling under gravity, moved by the
// rigid-body equations of plane-based geometric algebra R(n,0,1) (engines/pgaEngine.js alg, chainRest, stepWorld, energyWorld: every sign of every product from the
// kernel's table; pgadyn_selfcheck.py proves the same statements exactly, E4, E5, E11, E12). The hooked vertex is the label printed in bits (its complement, the opposite
// corner, carries the next body); springs are zigzags, the dotted lines the paths of the centres. It starts paused at its rest state (tilt 0 is a balance, E11) and
// Drop sets it moving; the readouts are v15's: the energy and its drift (none without damping), the largest |M M̃ − 1|, the rest at tilt 0. The controls are v15's:
// the dimension, the bodies, the hooked vertex bit by bit, the stiffness, gravity, damping, starting tilt and viewing angle, Drop / Step / Reset. Port of v15
// RigidWidgets2.HangIt.
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { alg, chainRest, stepWorld, energyWorld, verticesFrame, edgeList, project } from '../../engines/pgaEngine.js';
import { FigSvg, Controls, Chips, Range, PlayButton, PlayAction, useReducedMotion, r1, f2 } from './kit.jsx';

const H = 1 / 300;
const NAMES = { 1: 'segment', 2: 'square', 3: 'cube', 4: 'tesseract' };
const bits = (n, x) => x.toString(2).padStart(n, '0');
const bladeName = (n, v) => { const m = (v << 1) | (popc(v) & 1); let s = ''; for (let i = 0; i <= n; i++) if ((m >> i) & 1) s += i; return m ? 'e' + s : '1'; };
const popc = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
const zig = (x1, y1, x2, y2, m = 9, w = 4) => { const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, px = -dy / L, py = dx / L, pts = [[x1, y1]]; for (let i = 1; i < 2 * m; i++) { const s = i / (2 * m), sg = i % 2 ? 1 : -1; pts.push([x1 + dx * s + px * w * sg, y1 + dy * s + py * w * sg]); } pts.push([x2, y2]); return pts.map(([x, y], i) => (i ? 'L' : 'M') + r1(x) + ' ' + r1(y)).join(' '); };

/** the hung chain at rest and its world (the setup of v15: sizes shrinking with the axis and the body, masses 1, the anchor at height 3) */
export function hangSetup(n = 3, nb = 1, top = 7, k = 8, g = 30, tilt = 35) {
  const A = alg(n), full = (1 << n) - 1, tp = n === 1 ? 1 : Math.min(top, full) || 1;
  const sizes = Array.from({ length: nb }, (_, b) => Array.from({ length: n }, (_, i) => Math.max(0.35, 1.0 - 0.14 * i - 0.12 * b)));
  const R = chainRest(A, { top: tp, nb, sizes, k, g: g / 10, m: 1, y0: 3, tilt: tilt * Math.PI / 180 });
  const w = { n, g: g / 10, alpha: 0, bodies: R.bodies.map(b => ({ m: b.m, c: b.c })), springs: R.springs }, st = R.bodies.map(b => ({ M: b.M, B: b.B }));
  const c0 = st.map(x => A.pos(A.sand(x.M, A.point(new Array(n).fill(0)))));
  return { A, n, nb, tp, full, sizes, R, w, st0: st, E0: energyWorld(A, w, st).E, c0 };
}
/** advance a state by `steps` RK4 steps of 1/300 in the world w; returns the new state */
export function hangRun(setup, w, steps, st = setup.st0) { let s = st; for (let i = 0; i < steps; i++) s = stepWorld(setup.A, w, s, H); return s; }

export default function HangIt({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okN = v => [1, 2, 3, 4].includes(v);
  const [n, setN] = useState(okN(params.n) ? params.n : 3), [nb, setNb] = useState([1, 2, 3].includes(params.nb) ? params.nb : 1);
  const [top, setTop] = useState(7), [k, setK] = useState(8), [g, setG] = useState(30), [al, setAl] = useState(0), [tilt, setTilt] = useState(35), [view, setView] = useState(25);
  useEffect(() => { setN(okN(params.n) ? params.n : 3); setNb([1, 2, 3].includes(params.nb) ? params.nb : 1); }, [params.n, params.nb]);
  const [seed, setSeed] = useState({ k: 8, g: 30 }), [rev, setRev] = useState(0), [playing, setPlaying] = useState(false), [, setTick] = useState(0), reduced = useReducedMotion();
  const setup = useMemo(() => hangSetup(n, nb, top, seed.k, seed.g, tilt), [n, nb, top, seed.k, seed.g, tilt]);
  const { A } = setup;
  const w = useMemo(() => ({ ...setup.w, g: g / 10, alpha: al / 20, springs: setup.w.springs.map(q => ({ ...q, k })) }), [setup, k, g, al]);
  const sim = useRef(null);
  const fresh = () => ({ setup, rev, st: setup.st0, t: 0, trails: setup.st0.map(() => []), steps: 0, E0: setup.E0, live: false });
  if (!sim.current || sim.current.setup !== setup || sim.current.rev !== rev) sim.current = fresh();
  const s = sim.current;
  const ran = () => s.steps > 0;
  const live = (kk, gg, aa) => { s.E0 = energyWorld(A, { ...setup.w, g: gg / 10, alpha: aa / 20, springs: setup.w.springs.map(q => ({ ...q, k: kk })) }, s.st).E; s.live = true; };
  const onK = v => { setK(v); if (ran()) live(v, g, al); else setSeed(q => ({ ...q, k: v })); };
  const onG = v => { setG(v); if (ran()) live(k, v, al); else setSeed(q => ({ ...q, g: v })); };
  const onAl = v => { setAl(v); if (ran()) live(k, g, v); };
  const advance = steps => {
    let st = s.st; const z = new Array(n).fill(0);
    for (let i = 0; i < steps; i++) { st = stepWorld(A, w, st, H); if ((s.steps + i) % 6 === 0) st.forEach((x, b) => { s.trails[b].push(A.pos(A.sand(x.M, A.point(z)))); if (s.trails[b].length > 220) s.trails[b].shift(); }); }
    s.st = st; s.t += steps * H; s.steps += steps; setTick(x => x + 1);
  };
  useEffect(() => { if (!playing || reduced) return undefined; const id = setInterval(() => advance(10), 33); return () => clearInterval(id); }, [playing, reduced, w, setup, rev]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = { playing, reduced, play: () => setPlaying(p => !p), step: () => advance(30) };
  const reset = () => { setSeed({ k, g }); setRev(r => r + 1); setPlaying(false); };
  const vw = view * Math.PI / 180, sc = nb === 1 ? 46 : nb === 2 ? 38 : 32, ox = 180, oy = 20 + sc * 3, pr = x => { const p = project(n, x, vw); return [ox + sc * p[0], oy - sc * p[1]]; };
  const bodies = s.st.map((x, b) => verticesFrame(A, x.M, setup.sizes[b])), en = energyWorld(A, w, s.st), drift = Math.abs(en.E - s.E0);
  const cen = s.st.map(x => A.pos(A.sand(x.M, A.point(new Array(n).fill(0))))), moved = Math.max(...cen.map((p, b) => Math.max(...p.map((v, i) => Math.abs(v - setup.c0[b][i])))));
  const nerr = Math.max(...s.st.map(x => A.normErr(x.M))), E = edgeList(n), anchor = pr(setup.R.anchor), tp = setup.tp, full = setup.full;
  const wp = (b, p) => pr(A.pos(A.sand(s.st[b].M, A.point(p))));
  const HH = research ? 320 : 270;
  return (
    <div className="fig fig-hang-it">
      <FigSvg id="hang-it" row={row} viewBox={`0 0 360 ${HH}`}>
        <g data-n={n} data-bodies={nb} data-top={tp} data-t={f2(s.t)}>
          <line x1={150} y1={r1(anchor[1])} x2={210} y2={r1(anchor[1])} className="stroke-ink" style={{ strokeWidth: 3, strokeOpacity: 0.6 }} />
          {s.trails.map((tr, b) => <path key={'t' + b} d={tr.map((p, i) => { const q = pr(p); return (i ? 'L' : 'M') + r1(q[0]) + ' ' + r1(q[1]); }).join(' ')} className="stroke-muted" style={{ strokeDasharray: '2 2', strokeOpacity: 0.6 }} />)}
          {setup.w.springs.map((sp, i) => { const a = wp(sp.a, sp.pa), b = sp.b < 0 ? anchor : wp(sp.b, sp.pb); return <path key={'s' + i} d={zig(a[0], a[1], b[0], b[1])} className="stroke-ink" style={{ strokeWidth: 1.4 }} data-spring={i} />; })}
          {bodies.map((V, b) => (
            <g key={b} data-body={b}>
              {E.map(([a, c]) => { const p = pr(V[a]), q = pr(V[c]); return <line key={a + '-' + c} x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className="stroke-ink" style={{ strokeWidth: 1.3, strokeOpacity: 0.85 - 0.2 * b }} />; })}
              {V.map((v, i) => { const p = pr(v), hot = i === tp || i === (full ^ tp); return <circle key={i} cx={r1(p[0])} cy={r1(p[1])} r={hot ? 4.2 : 2} className={hot ? 'ink' : 'ink-muted'} style={hot ? { stroke: 'var(--panel)', strokeWidth: 1 } : undefined} data-hook={i === tp ? 1 : undefined} />; })}
            </g>
          ))}
        </g>
        <text x={8} y={HH - (research ? 70 : 24)} className="t-small">{`hooked at ${bits(n, tp)}${research ? ` (blade ${bladeName(n, tp)})` : ''} · opposite corner ${bits(n, full ^ tp)}`}</text>
        <text x={8} y={HH - (research ? 54 : 8)} className="t-mono t-tiny">{`t = ${f2(s.t)}${research ? ` · kinetic ${en.K.toFixed(4)}, gravity ${en.Ug.toFixed(4)}, springs ${en.Us.toFixed(4)}, total ${en.E.toFixed(4)}` : ''}`}</text>
        {research && <text x={8} y={HH - 38} className="t-mono t-tiny" data-drift={drift}>{al ? 'damping on: the total energy falls' : `energy drift since the start: ${drift.toExponential(1)}`}</text>}
        {research && <text x={8} y={HH - 22} className="t-mono t-tiny" data-norm={nerr}>{`largest |M M̃ − 1| over the bodies: ${nerr.toExponential(1)}`}</text>}
        {research && tilt === 0 && !s.live && <text x={8} y={HH - 6} className="t-mono t-tiny" data-rest={moved}>{`tilt 0: every centre has moved at most ${moved.toExponential(1)}`}</text>}
      </FigSvg>
      <Controls label="hang it">
        <Chips label={research ? 'body' : 'shape'} items={[1, 2, 3, 4]} value={n} onPick={q => { setN(q); setTop(q === 1 ? 1 : (1 << q) - 1); setSeed({ k, g }); }} render={q => NAMES[q]} param="n" />
        <Chips label="chain" items={[1, 2, 3]} value={nb} onPick={q => { setNb(q); setSeed({ k, g }); }} render={q => (q === 1 ? '1 body' : `${q} bodies`)} param="nb" />
        {research && n >= 2 && <span className="fig-group" role="group" aria-label="hooked vertex, bit by bit" data-param="top"><span className="fig-group-label">hooked</span>{Array.from({ length: n }, (_, i) => <button key={i} type="button" className="fig-btn fig-mono" data-param="top" aria-pressed={!!((tp >> i) & 1)} onClick={() => { setTop((tp ^ (1 << i)) || 1); setSeed({ k, g }); }}>{`bit ${i + 1}: ${(tp >> i) & 1}`}</button>)}</span>}
        {research && <Range label="stiffness k" value={k} min={2} max={30} step={1} onChange={onK} param="k" />}
        {research && <Range label="gravity g" value={g} min={0} max={60} step={1} onChange={onG} display={v => f2(v / 10)} param="g" />}
        {research && <Range label="damping α" value={al} min={0} max={20} step={1} onChange={onAl} display={v => f2(v / 20)} param="alpha" />}
        {research && <Range label="tilt" value={tilt} min={0} max={85} step={1} onChange={v => { setTilt(v); setSeed({ k, g }); }} display={v => `${v}°`} param="tilt" />}
        {research && n >= 3 && <Range label="view" value={view} min={-60} max={60} step={1} onChange={setView} display={v => `${v}°`} param="view" />}
        <PlayButton player={player} label="Drop" />
        {research && <PlayAction label="Step" onClick={() => advance(30)} />}
        <PlayAction label="Reset" kind="reset" onClick={reset} />
      </Controls>
    </div>
  );
}
HangIt.meta = { id: 'hang-it', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
HangIt.data = (params = {}) => { const S = hangSetup([1, 2, 3, 4].includes(params.n) ? params.n : 3, [1, 2, 3].includes(params.nb) ? params.nb : 1); const E = energyWorld(S.A, S.w, S.st0); return { n: S.n, bodies: S.nb, top: S.tp, sizes: S.sizes, anchor: S.R.anchor, energy: E, centres: S.c0 }; };
