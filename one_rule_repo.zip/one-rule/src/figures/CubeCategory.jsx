// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure cube-category (step 18): the label-0 card on the cube of labels (engines/categoryEngine.js cube; signs from the kernel; the card compared with
// checks/selfcheck/reports/lens_cat_check.json P3 by tests/engines.test.mjs). Default Cl(3,0,1), the first cell of the v15 widget: the 2^n labels as the corners of the
// n-cube in the v15 projection, each shaded by k, its number of null bits (the label lies in J^k and not in J^{k+1}, so the shades are the Loewy layers of the radical J),
// with k printed beside it; the edges along a null generator dashed. Research level: the card in one line. Lenses print the corners: cube / bits as bit strings, prime /
// primes as products of primes, clifford as e-words. The controls are v15's (the signature picker of CW1): steppers p, q, r (here n = p + q + r <= 5, the cube is
// drawn) and its presets. Port of v15 CategoryWidgets.jsx (CubePic, CW1).
import React, { useMemo, useState, useEffect } from 'react';
import { cube, sigOf } from '../../engines/categoryEngine.js';
import { label, algebraName } from '../../engines/labels.js';
import { FigSvg, Controls, Stepper, Chips, r1, labelLens } from './kit.jsx';

const V = [[112, 0], [0, 112], [52, -44], [212, 26], [0, 212]];   // the v15 projection of the cube of labels (n <= 5)
const PRESETS = ['3,0,1', '3,0,0', '1,1,0', '0,0,2'];   // the presets of v15 CW1 (the research picker)
const pqrOf = params => { const ok = x => Number.isInteger(x) && x >= 0; const p = ok(params.p) ? params.p : 3, q = ok(params.q) ? params.q : 0, r = ok(params.r) ? params.r : 1; return p + q + r >= 1 && p + q + r <= 5 ? [p, q, r] : [3, 0, 1]; };

export default function CubeCategory({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [sig, setSig] = useState(pqrOf(params));
  useEffect(() => { setSig(pqrOf(params)); }, [params.p, params.q, params.r]);   // eslint-disable-line react-hooks/exhaustive-deps
  const [p, q, r] = sig, step = (k, v) => { const t = [...sig]; t[k] = v; const m = t[0] + t[1] + t[2]; if (m >= 1 && m <= 5) setSig(t); };
  const C = useMemo(() => cube(sigOf(p, q, r)), [p, q, r]), n = C.n, card = C.card;
  const raw = C.corners.map(({ a }) => { let x = 0, y = 0; for (let i = 0; i < n; i++) if ((a >> i) & 1) { x += V[i][0]; y += V[i][1]; } return [x, y]; });
  const W = 420, H = research ? 312 : 270, top = 22, bot = H - (research ? 70 : 34);
  const xs = raw.map(t => t[0]), ys = raw.map(t => t[1]), mnx = Math.min(...xs), mxx = Math.max(...xs), mny = Math.min(...ys), mxy = Math.max(...ys);
  const s = Math.min((W - 60) / (mxx - mnx || 1), (bot - top) / (mxy - mny || 1), 1.3), ox = (W - (mxx - mnx) * s) / 2, oy = top + ((bot - top) - (mxy - mny) * s) / 2;
  const P = raw.map(([x, y]) => [ox + (x - mnx) * s, oy + (y - mny) * s]), rr = n <= 3 ? 10 : n === 4 ? 8.5 : 6;
  const L = labelLens(lens), printLabel = L === 'bits' || L === 'primes' || L === 'clifford' || L === 'set' ? a => label(a, L, C.eps) : null;
  const shade = k => (k ? 0.1 + (0.24 * k) / Math.max(1, r) : 0);
  const tyName = algebraName(p, q);
  return (
    <div className="fig fig-cube-category">
      <FigSvg id="cube-category" row={row} viewBox={`0 0 ${W} ${H}`}>
        {C.edges.map(e => <line key={e.a + '-' + e.b} x1={r1(P[e.a][0])} y1={r1(P[e.a][1])} x2={r1(P[e.b][0])} y2={r1(P[e.b][1])} className="stroke-ink" style={{ strokeOpacity: e.nullDir ? 0.6 : 0.25, strokeWidth: e.nullDir ? 1.3 : 1, strokeDasharray: e.nullDir ? '4 3' : undefined }} />)}
        {C.corners.map(c => { const [x, y] = P[c.a]; return (
          <g key={c.a} data-corner={c.a} data-k={c.k}>
            <title>{`${label(c.a, 'clifford', C.eps)} · ${c.k} null bit${c.k === 1 ? '' : 's'} · square ${c.square > 0 ? '+1' : c.square < 0 ? '−1' : '0'}`}</title>
            {c.k > 0 && <circle cx={r1(x)} cy={r1(y)} r={rr} className="on-panel" />}
            <circle cx={r1(x)} cy={r1(y)} r={rr} className={c.k ? 'ink' : 'on-panel'} style={c.k ? { fillOpacity: shade(c.k), stroke: 'var(--fg)', strokeWidth: 1.2 } : { stroke: 'var(--fg)', strokeOpacity: 0.7, strokeWidth: 1.2 }} />
            {c.k > 0 && <text x={r1(x)} y={r1(y + 3.5)} textAnchor="middle" className="t-mono t-tiny">{c.k}</text>}
            {printLabel && <text x={r1(x + rr + 3)} y={r1(y - rr + 1)} className="t-mono t-micro">{printLabel(c.a)}</text>}
          </g>); })}
        <g transform={`translate(16, ${bot + 24})`}>
          {Array.from({ length: r + 1 }, (_, k) => <g key={k} transform={`translate(${k * 64}, 0)`}><circle cx={6} cy={-4} r={6} className={k ? 'ink' : 'on-panel'} style={k ? { fillOpacity: shade(k), stroke: 'var(--fg)', strokeWidth: 1 } : { stroke: 'var(--fg)', strokeOpacity: 0.7, strokeWidth: 1 }} /><text x={16} y={0} className="t-mono t-tiny">{`k = ${k}: ${card.layers[k]}`}</text></g>)}
          <line x1={(r + 1) * 64 + 4} y1={-4} x2={(r + 1) * 64 + 26} y2={-4} className="stroke-ink" style={{ strokeOpacity: 0.6, strokeWidth: 1.3, strokeDasharray: '4 3' }} />
          <text x={(r + 1) * 64 + 30} y={0} className="t-tiny">{research ? 'null direction' : 'zero switch'}</text>
        </g>
        {research && <text x={16} y={H - 24} className="t-mono t-tiny t-muted">{`Cl(${p},${q},${r}): dim ${card.dim} · J ${card.J} · Loewy ${card.loewy} · centre ${card.centre} · super-centre ${card.sc}`}</text>}
        {research && <text x={16} y={H - 10} className="t-mono t-tiny t-muted">{`modulo J: Cl(${p},${q}) = ${tyName} · c = ${card.clock}`}</text>}
      </FigSvg>
      <Controls label="signature">
        {['p', 'q', 'r'].map((x, k) => <Stepper key={x} label={x} value={sig[k]} min={0} max={5 - (p + q + r - sig[k])} onChange={v => step(k, v)} param={x} />)}
        <Chips label="presets" items={PRESETS} value={sig.join(',')} onPick={k => setSig(k.split(',').map(Number))} render={k => { const [a, b, c] = k.split(','); return `Cl(${a},${b}${c !== '0' ? ',' + c : ''})`; }} param="preset" mono />
      </Controls>
    </div>
  );
}
CubeCategory.meta = { id: 'cube-category', lenses: ['cube', 'bits', 'primes', 'clifford'], learner: false };
/** the numbers the figure draws, for the frame's data download */
CubeCategory.data = (params = {}) => { const [p, q, r] = pqrOf(params), C = cube(sigOf(p, q, r)); return { cell: [p, q, r], corners: C.corners, edges: C.edges, card: { dim: C.card.dim, J: C.card.J, layers: C.card.layers, loewy: C.card.loewy, centre: C.card.centre, sc: C.card.sc, type: C.card.type, clock: C.card.clock } }; };
