// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure comm-graph: the six bivectors of a cell Cl(p, 4−p) as the vertices of an octahedron, complementary bivectors opposite; two bivectors are joined when they share
// one generator, and then [e_a, e_b] = ±2 e_{a xor b} (the kernel's signs, engines/labels.js commGraph; counts and roles compared with checks/selfcheck/equations.json).
// The mark of a vertex is its role (the first p generators are time): E one time index (filled), B none (ring), T two (square). Lenses print the labels with the kernel:
// Clifford e₁e₂, simplex {1,2} (an edge of the tetrahedron: the graph is its line graph), cube 0011, prime 2·3. Port of v15 EquationsSection.Octa.
import React, { useState, useEffect, useMemo } from 'react';
import { commGraph, label } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, r1, labelLens } from './kit.jsx';

const OCT = [[3, 90], [5, 150], [6, 210], [12, 270], [10, 330], [9, 30]];   // mask, angle: e12 e13 e23 e34 e24 e14 (opposite = complementary)

function Mark({ x, y, role }) {
  if (role === 'T') return <rect x={x - 6.5} y={y - 6.5} width={13} height={13} rx={2} className="ink-muted" style={{ stroke: 'var(--panel)', strokeWidth: 1.5 }} />;
  if (role === 'B') return <circle cx={x} cy={y} r={7} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.6 }} />;
  return <circle cx={x} cy={y} r={7} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 1.5 }} />;
}

export default function CommGraph({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const valid = x => Number.isInteger(x) && x >= 0 && x <= 4;
  const [p, setP] = useState(valid(params.p) ? params.p : 1);
  useEffect(() => { if (valid(params.p)) setP(params.p); }, [params.p]);   // eslint-disable-line react-hooks/exhaustive-deps
  const G = useMemo(() => commGraph(p, 4 - p), [p]), lensKey = labelLens(lens) || 'clifford';
  const pos = Object.fromEntries(OCT.map(([m, a]) => [m, [r1(150 + 100 * Math.cos(a * Math.PI / 180)), r1(140 - 100 * Math.sin(a * Math.PI / 180)), a]]));
  const name = m => (research ? label(m, lensKey, G.eps) : label(m, 'set', G.eps).replace(/[{}]/g, '').replace(',', ' '));
  const roleOf = Object.fromEntries(G.bivectors.map(b => [b.m, b]));
  const roles = ['E', 'B', 'T'].filter(r => G.bivectors.some(b => b.role === r));
  return (
    <div className="fig fig-comm-graph">
      <FigSvg id="comm-graph" row={row} viewBox="0 0 300 318">
        {G.edges.map(e => (
          <line key={e.a + '-' + e.b} x1={pos[e.a][0]} y1={pos[e.a][1]} x2={pos[e.b][0]} y2={pos[e.b][1]} className="stroke-ink" style={{ strokeOpacity: 0.5, strokeWidth: 1.3 }}>
            <title>{`[${label(e.a, 'clifford', G.eps)}, ${label(e.b, 'clifford', G.eps)}] = ${e.coef < 0 ? '−' : ''}2 ${label(e.k, 'clifford', G.eps)}`}</title>
          </line>
        ))}
        {OCT.map(([m, a]) => { const [x, y] = pos[m], b = roleOf[m]; return (
          <g key={m}>
            <title>{`${label(m, 'clifford', G.eps)}: ${b.role}, square ${b.square > 0 ? '+1' : '−1'}`}</title>
            <Mark x={x} y={y} role={b.role} />
            <text x={r1(150 + 128 * Math.cos(a * Math.PI / 180))} y={r1(140 - 124 * Math.sin(a * Math.PI / 180) + 4)} textAnchor="middle" className="t-mono t-small">{name(m)}</text>
          </g>); })}
        <g transform="translate(0, 308)">
          {roles.map((r, i) => <g key={r} transform={`translate(${150 - roles.length * 26 + i * 52 + 14}, 0)`}><Mark x={0} y={-4} role={r} /><text x={12} y={0} className="t-small">{r}</text></g>)}
        </g>
      </FigSvg>
      {research && <Controls label="cell"><Chips label="cell" items={[0, 1, 2, 3, 4]} value={p} onPick={setP} render={x => `Cl(${x},${4 - x})`} param="p" mono /></Controls>}
    </div>
  );
}
CommGraph.meta = { id: 'comm-graph', lenses: ['clifford', 'simplex', 'cube', 'prime', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
CommGraph.data = (params = {}) => { const p = Number.isInteger(params.p) ? params.p : 1, G = commGraph(p, 4 - p); return { cell: [p, 4 - p], bivectors: G.bivectors, edges: G.edges, commuting: G.commuting, roles: G.roles }; };
