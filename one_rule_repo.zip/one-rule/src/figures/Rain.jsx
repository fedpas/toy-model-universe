// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure rain (step 12): rain falling through the horizon, in the Painlevé–Gullstrand slice (engines/labels.js pgG, pgRays, pgClass; the square of the radial gradient
// h̄(eᵣ) = eᵣ + g eₜ is the kernel's product in Cl(1,1), pgSquareByBitRule = g² − 1). Distance r across (in units of 2M; the horizon r = 1 is the dashed line, the
// inside is shaded), time up. Each pair of lines from a point is a light cone, outgoing dr/dt = 1 − g, ingoing −1 − g: hollow outside (the gradient is spacelike), on
// its edge at the horizon, filled inside (timelike). The curve is a raindrop, dr/dt = −g, falling from r = 2.2; reversed (g → −g) the cones lean out and the drop
// climbs. The large cone is at the chosen r. Controls, as in v15: the distance slider (research level) and the reverse switch. Port of v15 LabelsWidgets.Horizon.
import React, { useState, useEffect, useMemo } from 'react';
import { pgG, pgRays, pgClass, pgSquareByBitRule } from '../../engines/labels.js';
import { FigSvg, Controls, Range, Toggle, r1, f2 } from './kit.jsx';

export const STOPS = [0.2, 0.35, 0.5, 0.65, 0.8, 0.95, 1.1, 1.3, 1.6, 2, 2.5, 3];
const WORD = { '-1': ['outside: spacelike gradient', 'outside'], 0: ['on the horizon: null gradient', 'at the edge'], 1: ['inside: timelike gradient', 'inside'] };
const px = r => 20 + r * 100, py = t => 300 - t * 95, clampX = x => Math.max(2, Math.min(338, x));

function Cone({ r, t, big, sg }) {
  const g = pgG(r, 0.5), ray = pgRays(g, sg), cl = pgClass(g, 1e-9), h = big ? 0.34 : 0.2;
  const o = [px(r), py(t)], A = [clampX(px(r + ray.out * h)), py(t + h)], B = [clampX(px(r + ray.inn * h)), py(t + h)];
  const fill = cl > 0 ? 0.42 : cl === 0 ? 0.2 : 0.06;
  return (
    <g data-cone={r} data-class={cl} data-big={big ? 1 : 0}>
      <title>{`r = ${f2(r)} (2M): ${WORD[cl][0]}; outgoing ${f2(ray.out)}, ingoing ${f2(ray.inn)}`}</title>
      <polygon points={`${r1(o[0])},${r1(o[1])} ${r1(A[0])},${r1(A[1])} ${r1(B[0])},${r1(B[1])}`} className="ink" style={{ fillOpacity: fill, stroke: 'var(--fg)', strokeWidth: big ? 1.8 : 1 }} />
      {big && <circle cx={r1(o[0])} cy={r1(o[1])} r={4} className="ink" />}
    </g>
  );
}

export default function Rain({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const init = () => (Number.isFinite(params.rho) && params.rho >= 0.3 && params.rho <= 3 ? params.rho : 0.6);
  const [rho, setRho] = useState(init);
  const [rev, setRev] = useState(params.rev === true);
  useEffect(() => { setRho(init()); setRev(params.rev === true); }, [params.rho, params.rev]);   // eslint-disable-line react-hooks/exhaustive-deps
  const sg = rev ? -1 : 1, g = pgG(rho, 0.5), sq = pgSquareByBitRule(g), cls = pgClass(g, 1e-9);
  const rain = useMemo(() => { const r0 = 2.2, out = []; for (let r = r0; r >= 0.03; r -= 0.02) out.push([px(r), rev ? py((r ** 1.5 - 0.03 ** 1.5) / 1.5) : py((r0 ** 1.5 - r ** 1.5) / 1.5)]); return out; }, [rev]);
  const H = research ? 336 : 322;
  return (
    <div className="fig fig-rain">
      <FigSvg id="rain" row={row} viewBox={`0 0 340 ${H}`}>
        <rect x={px(0)} y={6} width={px(1) - px(0)} height={294} className="ink" style={{ fillOpacity: 0.05 }} />
        <line x1={px(1)} y1={6} x2={px(1)} y2={300} className="stroke-ink" style={{ strokeDasharray: '5 4', strokeWidth: 1.5 }} data-horizon="1" />
        <line x1={20} y1={300} x2={330} y2={300} className="hair" />
        <text x={px(1) + 4} y={18} className="t-small">{research ? 'horizon r = 2M' : 'the edge'}</text>
        {STOPS.map(r => <Cone key={r} r={r} t={0.35} sg={sg} />)}
        <Cone r={rho} t={1.5} big sg={sg} />
        <polyline points={rain.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ')} className="stroke-ink" style={{ strokeWidth: 2 }} data-rain={rev ? 'reversed' : 'falling'} />
        <text x={px(2.2) - 6} y={296} textAnchor="end" className="t-small">rain</text>
        <text x={330} y={314} textAnchor="end" className="t-tiny t-muted">{research ? 'r / 2M' : 'distance'}</text>
        <text x={20} y={research ? 316 : 316} className="t-small t-bold" data-state={cls}>{WORD[cls][research ? 0 : 1]}</text>
        {research && <text x={20} y={330} className="t-mono t-tiny t-muted" data-g={g} data-square={sq}>{`g = √(2M/r) = ${g.toFixed(3)} · (eᵣ + g eₜ)² = g² − 1 = ${sq.toFixed(3)}`}</text>}
      </FigSvg>
      <Controls label="horizon">
        {research && <Range label="r / 2M" value={rho} min={0.3} max={3} step={0.01} onChange={setRho} display={v => v.toFixed(2)} param="rho" />}
        <Toggle label={research ? 'reverse time (g → −g)' : 'run backwards'} on={rev} onChange={setRev} param="rev" />
      </Controls>
    </div>
  );
}
Rain.meta = { id: 'rain', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
Rain.data = (params = {}) => { const rho = Number.isFinite(params.rho) ? params.rho : 0.6, g = pgG(rho, 0.5); return { rho, g, square: pgSquareByBitRule(g), class: pgClass(g, 1e-9), cones: STOPS.map(r => ({ r, g: pgG(r, 0.5), class: pgClass(pgG(r, 0.5), 1e-9), rays: pgRays(pgG(r, 0.5), 1) })) }; };
