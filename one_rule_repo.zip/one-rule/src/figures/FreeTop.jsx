// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure free-top (step 16, later rung): a free box with three moments of inertia, moved by the rigid-body equations of R(3,0,1) (engines/pgaEngine.js alg, stepRK4,
// kinetic: the kernel's signs; pgadyn_selfcheck.py T1–T3 prove the statements exactly). Left: the sphere of the angular momentum L, seen from an angle; each grey
// curve is a polhode (a curve of constant energy, Euler's equations by RK4 in floating point), the poles are the three principal axes — a filled pole is unstable
// (a small push grows, μ > 0: the middle axis), a hollow one oscillates (μ < 0), a dashed one is free (two moments equal) —, and the heavy trail and dot are the
// body's L now. Right: the box whose moments these are. It starts paused, a small push off the chosen axis; Play spins it. The readouts are v15's: μ of each axis
// and what a push does, |L| and the energy against the start, the sign changes of L along the axis. The controls are v15's: the three presets, the three moments,
// the axis, the size of the push, the turn of the sphere, Play / Step / speed. Port of v15 RigidWidgets2.FreeTop.
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { alg, stepRK4, kinetic, verticesFrame, edgeList, project } from '../../engines/pgaEngine.js';
import { FigSvg, Controls, Chips, Range, PlayButton, PlayAction, useReducedMotion, r1, f2 } from './kit.jsx';

const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const eulerL = (L, I) => cross(L, L.map((x, i) => x / I[i]));
const rk4L = (L, I, h) => { const k1 = eulerL(L, I), a = L.map((x, i) => x + h / 2 * k1[i]), k2 = eulerL(a, I), b = L.map((x, i) => x + h / 2 * k2[i]), k3 = eulerL(b, I), c = L.map((x, i) => x + h * k3[i]), k4 = eulerL(c, I); return L.map((x, i) => x + h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i])); };
/** μ of axis a (ω₀ = 1): the square of the rate of a small push, (I_c − I_a)(I_a − I_b)/(I_b I_c) (T2) */
export const topMu = (I, a) => { const [b, c] = [0, 1, 2].filter(i => i !== a); return (I[c] - I[a]) * (I[a] - I[b]) / (I[b] * I[c]); };
export const PRESETS = { paper: [100 * 5 / 12, 100 * 1.36 / 12, 100 * 4.36 / 12], repo: [100 * 4.36 / 12, 100 * 1.36 / 12, 100 * 5 / 12], sym: [30, 30, 55] };
export const kindOf = m => (m > 1e-9 ? 'inv' : m < -1e-9 ? 'osc' : 'free');
const LofC = (B, c) => [c[0b1100] * B[0b1100], -c[0b1010] * B[0b1010], c[0b0110] * B[0b0110]];
const AX = ['x', 'y', 'z'];
const POLHODES = new Map();
function polhodes(I) {
  const key = I.join(','); if (POLHODES.has(key)) return POLHODES.get(key);
  const out = [], N = 26, gold = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < N; i++) { const z = 1 - 2 * (i + 0.5) / N, r = Math.sqrt(1 - z * z); let L = [r * Math.cos(gold * i), r * Math.sin(gold * i), z]; const L0 = L, pts = [L]; for (let s = 0; s < 420; s++) { L = rk4L(L, I, 0.03); pts.push(L); if (s > 30 && Math.hypot(L[0] - L0[0], L[1] - L0[1], L[2] - L0[2]) < 0.04) break; } out.push(pts); }
  POLHODES.set(key, out); return out;
}

export default function FreeTop({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const pre = ['paper', 'repo', 'sym'].includes(params.preset) ? params.preset : 'paper';
  const [preset, setPreset] = useState(pre), [I, setI] = useState(PRESETS[pre]), [seedI, setSeedI] = useState(PRESETS[pre]);
  const [axis, setAxis] = useState(pre === 'paper' ? 2 : 0), [eps, setEps] = useState(15), [az, setAz] = useState(30), [speed, setSpeed] = useState(2), [rev, setRev] = useState(0);
  useEffect(() => { setPreset(pre); setI(PRESETS[pre]); setSeedI(PRESETS[pre]); setAxis(pre === 'paper' ? 2 : 0); }, [pre]);
  const [playing, setPlaying] = useState(false), [, setTick] = useState(0), reduced = useReducedMotion();
  const Im = I.map(x => x / 100), mu = [0, 1, 2].map(a => topMu(Im, a)), order = [0, 1, 2].sort((a, b) => Im[a] - Im[b]), mid = order[1];
  const A = useMemo(() => alg(3), []);
  const mkCc = Iv => { const c = A.z(); for (const m of A.BIV) c[m] = m & 1 ? 1 : 0; c[0b1100] = Iv[0] / 100; c[0b1010] = Iv[1] / 100; c[0b0110] = Iv[2] / 100; return c; };
  const cc = useMemo(() => mkCc(I), [A, I]);   // eslint-disable-line react-hooks/exhaustive-deps
  const init = useMemo(() => { const Is = seedI.map(x => x / 100), e = eps / 100, L = [0, 0, 0]; L[axis] = 1; L[(axis + 1) % 3] = e; L[(axis + 2) % 3] = e / 2; const nl = Math.hypot(...L), B = A.z(); B[0b1100] = L[0] / nl / Is[0]; B[0b1010] = -L[1] / nl / Is[1]; B[0b0110] = L[2] / nl / Is[2]; return { M: A.motor([0, 0, 0], []), B }; }, [A, seedI, axis, eps]);
  const sim = useRef(null);
  if (!sim.current || sim.current.init !== init || sim.current.rev !== rev) sim.current = { init, rev, st: init, trail: [], t: 0, flips: 0, e0: kinetic(A, init.B, mkCc(seedI)), l0: Math.hypot(...LofC(init.B, mkCc(seedI))) };
  const s = sim.current;
  const newBody = (a, v) => { const nI = I.map((x, i) => (i === a ? v : x)); setPreset(''); setI(nI); if (s.t === 0) { setSeedI(nI); return; } const c2 = mkCc(nI), B = s.st.B.slice(); for (const m of [0b1100, 0b1010, 0b0110]) B[m] = s.st.B[m] * cc[m] / c2[m]; s.st = { M: s.st.M, B }; s.e0 = kinetic(A, B, c2); s.l0 = Math.hypot(...LofC(B, c2)); };
  const advance = steps => { let st = s.st; for (let i = 0; i < steps; i++) { const prev = LofC(st.B, cc)[axis]; st = stepRK4(A, st, cc, null, 0.01); const now = LofC(st.B, cc)[axis]; if (prev * now < 0) s.flips++; if (i % 3 === 0) s.trail.push(LofC(st.B, cc)); } if (s.trail.length > 500) s.trail.splice(0, s.trail.length - 500); s.st = st; s.t += steps * 0.01; setTick(x => x + 1); };
  useEffect(() => { if (!playing || reduced) return undefined; const id = setInterval(() => advance(3 * speed), 33); return () => clearInterval(id); }, [playing, reduced, speed, cc, axis, init, rev]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = { playing, reduced, play: () => setPlaying(p => !p), step: () => advance(60) };
  const PH = useMemo(() => polhodes(Im), [I]);   // eslint-disable-line react-hooks/exhaustive-deps
  const el = 0.5, ca = Math.cos(az * Math.PI / 180), sa = Math.sin(az * Math.PI / 180), R = 95, cx = 112, cy = 112;
  const pj = p => { const x = p[0] * ca - p[1] * sa, y = p[0] * sa + p[1] * ca; return [cx + R * x, cy - R * (p[2] * Math.cos(el) - y * Math.sin(el)), y * Math.cos(el) + p[2] * Math.sin(el)]; };
  const paths = pts => { let f = '', b = '', lf = false, lb = false; pts.forEach(p => { const q = pj(p), front = q[2] <= 0, seg = `${r1(q[0])} ${r1(q[1])}`; if (front) { f += (lf ? 'L' : 'M') + seg; lf = true; lb = false; } else { b += (lb ? 'L' : 'M') + seg; lb = true; lf = false; } }); return [f, b]; };
  const Lc = LofC(s.st.B, cc), nl = Math.hypot(...Lc), Ln = Lc.map(x => x / nl), E = kinetic(A, s.st.B, cc);
  const sizes = [6 * (Im[1] + Im[2] - Im[0]), 6 * (Im[0] + Im[2] - Im[1]), 6 * (Im[0] + Im[1] - Im[2])].map(x => Math.sqrt(Math.max(0.04, x)));
  const Vb = verticesFrame(A, s.st.M, sizes), P3 = Vb.map(p => project(3, p, 0)), Eb = edgeList(3), bs = 34;
  const kindTxt = a => { const k = kindOf(mu[a]); return k === 'inv' ? `grows like e^(${f2(Math.sqrt(mu[a]))} t)` : k === 'osc' ? `oscillates, period ${f2(2 * Math.PI / Math.sqrt(-mu[a]))}` : 'free: two moments equal'; };
  const HH = research ? 330 : 236, trail = paths(s.trail), dot = pj(Ln);
  return (
    <div className="fig fig-free-top">
      <FigSvg id="free-top" row={row} viewBox={`0 0 360 ${HH}`}>
        <circle cx={cx} cy={cy} r={R} className="hair" style={{ stroke: 'var(--muted)' }} />
        {PH.map((pts, i) => { const [f, b] = paths(pts); return <g key={i}><path d={b} className="stroke-ink" style={{ strokeOpacity: 0.1 }} /><path d={f} className="stroke-ink" style={{ strokeOpacity: 0.28 }} /></g>; })}
        {[0, 1, 2].flatMap(a => [1, -1].map(sg => { const p = [0, 0, 0]; p[a] = sg; const q = pj(p), k = kindOf(mu[a]), front = q[2] <= 0; return (
          <g key={a + '' + sg} data-axis={a} data-kind={k}>
            <circle cx={r1(q[0])} cy={r1(q[1])} r={front ? 5.5 : 3.8} className={k === 'inv' ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.4, strokeDasharray: k === 'free' ? '2 1.5' : undefined, opacity: front ? 1 : 0.45 }} />
            <text x={r1(q[0] + 7)} y={r1(q[1] - 6)} className="t-tiny" style={{ opacity: front ? 0.9 : 0.4 }}>{(sg > 0 ? '+' : '−') + AX[a]}</text>
          </g>); }))}
        <path d={trail[0]} className="stroke-ink" style={{ strokeWidth: 2 }} /><path d={trail[1]} className="stroke-ink" style={{ strokeWidth: 1, strokeOpacity: 0.3 }} />
        <circle cx={r1(dot[0])} cy={r1(dot[1])} r={5} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 1.5 }} data-l={Ln.map(x => x.toFixed(3)).join(',')} />
        <g transform={`translate(${research ? 282 : 286} 112)`}>{Eb.map(([a, b]) => <line key={a + '-' + b} x1={r1(bs * P3[a][0])} y1={r1(-bs * P3[a][1])} x2={r1(bs * P3[b][0])} y2={r1(-bs * P3[b][1])} className="stroke-ink" style={{ strokeOpacity: 0.75 }} />)}</g>
        <text x={8} y={226} className="t-mono t-tiny" data-flips={s.flips}>{`t = ${f2(s.t)} · sign changes of L along ${AX[axis]}: ${s.flips}`}</text>
        {research && <>
          {[0, 1, 2].map(a => <text key={a} x={8} y={246 + 16 * a} className="t-mono t-tiny" data-mu={mu[a]}>{`${AX[a]}: I = ${Im[a].toFixed(3)} · μ = ${mu[a].toFixed(3)} · ${kindTxt(a)}${a === mid ? ' (middle)' : ''}`}</text>)}
          <text x={8} y={302} className="t-mono t-tiny" data-cons={`${Math.abs(nl - s.l0)},${Math.abs(E - s.e0)}`}>{`|L| = ${nl.toFixed(4)} · energy ${E.toFixed(4)} (start ${s.e0.toFixed(4)})`}</text>
          <text x={8} y={318} className="t-mono t-tiny">{`a box with these moments has sides ${sizes.map(f2).join(' × ')}`}</text>
        </>}
      </FigSvg>
      <Controls label="free top">
        <Chips label="box" items={['paper', 'repo', 'sym']} value={preset} onPick={k => { setPreset(k); setI(PRESETS[k]); setSeedI(PRESETS[k]); setAxis(k === 'paper' ? 2 : 0); setRev(r => r + 1); setPlaying(false); }} render={k => ({ paper: 'box of the paper', repo: 'x and z exchanged', sym: 'symmetric top' })[k]} param="preset" />
        {research && [0, 1, 2].map(a => <Range key={a} label={`I${['ₓ', 'ᵧ', 'z'][a]}`} value={Math.round(I[a])} min={5} max={100} step={1} onChange={v => newBody(a, v)} display={() => Im[a].toFixed(3)} param="I" />)}
        <Chips label="spin about" items={[0, 1, 2]} value={axis} onPick={setAxis} render={a => `${AX[a]}${a === mid ? ' (middle)' : a === order[0] ? ' (smallest)' : ' (largest)'}`} param="axis" />
        {research && <Range label="push" value={eps} min={1} max={80} step={1} onChange={setEps} display={v => (v / 100).toFixed(2)} param="eps" />}
        {research && <Range label="turn" value={az} min={0} max={359} step={1} onChange={setAz} display={v => `${v}°`} param="az" />}
        <PlayButton player={player} />
        {research && <PlayAction label="Step" onClick={() => advance(60)} />}
        {research && <span className="fig-group" data-play="speed">{[1, 2, 6].map(k => <button key={k} type="button" className="fig-btn fig-btn-sq" data-play="speed" aria-pressed={speed === k} onClick={() => setSpeed(k)}>{`×${k}`}</button>)}</span>}
      </Controls>
    </div>
  );
}
FreeTop.meta = { id: 'free-top', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
FreeTop.data = (params = {}) => { const I = PRESETS[['paper', 'repo', 'sym'].includes(params.preset) ? params.preset : 'paper'].map(x => x / 100); return { I, mu: [0, 1, 2].map(a => topMu(I, a)), kinds: [0, 1, 2].map(a => kindOf(topMu(I, a))) }; };
