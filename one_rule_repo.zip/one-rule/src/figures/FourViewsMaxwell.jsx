// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure four-views-maxwell (the light calibration): Maxwell's ∇F = J for the bivector F of Cl(k, d) (default Cl(1,3); k + d <= 5), drawn four ways like the figure
// four-views (engines/labels.js maxwellViews; signs from the kernel; moves, roles and counts compared with checks/selfcheck/maxwell.json for all 15 stored cells).
// Every term is one move of a field piece e_S (a bivector) along an axis a: e_a e_S = ± e_{S xor a}, a contraction to a vector (δF = J, solid) or a wedge to a trivector
// (dF = 0, dashed). Clifford: the table of the moves, field pieces by axes, with the sign. Simplex: the pieces are the edges; a contraction runs to an end of its edge, a
// wedge into a face through it. Cube: the labels are corners; the moves are the cube edges that leave the bivector layer. Prime: the labels are products of primes; a
// contraction divides by the prime of the axis, a wedge multiplies by it. Marks: E (one time index) filled, B (none) ring, T (two) square; ρ / J and Faraday / ∇·B
// likewise filled (with time) and ring (without). The controls are v15's: the number of time and of space generators (chips k and d, here k + d <= 5), an equation (its
// moves stand out in all four views; the names and equations are those maxwell_selfcheck.py stores, engines/maxwellData.js), and the mirror (k, d) → (d, k).
// Port of v15 MaxwellSection.jsx (ViewClifford, ViewSimplex, ViewCube, ViewPrime), on the parts of FourViews.jsx.
import React, { useMemo, useState, useEffect } from 'react';
import { maxwellViews, label, PRIMES } from '../../engines/labels.js';
import MAXWELL from '../../engines/maxwellData.js';
import { FigSvg, Controls, Chips, sub, r1, arrowHead, labelLens } from './kit.jsx';
import { simplexPts, cubePoint } from './FourViews.jsx';

const VB_W = 210, VB_H = 200;
const bitsOf = m => { const o = []; for (let i = 0; m >> i; i++) if ((m >> i) & 1) o.push(i); return o; };
const ROLE_ORDER = { E: 0, T: 1, B: 2 };

function Mark({ x, y, role, r = 5 }) {
  if (role === 'T') return <rect x={r1(x - r)} y={r1(y - r)} width={2 * r} height={2 * r} rx={1.5} className="ink-muted" style={{ stroke: 'var(--panel)', strokeWidth: 1 }} />;
  const filled = role === 'E' || role === 'rho' || role === 'Faraday';
  return filled ? <circle cx={x} cy={y} r={r} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 1 }} /> : <circle cx={x} cy={y} r={r} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.3 }} />;
}

/** names of a label in the current notation: γ-words (research default), digits of the generators (learner), or the kernel's printer in a label lens */
function namer(V, lens, research) {
  const L = labelLens(lens);
  if (L === 'bits' || L === 'primes' || L === 'sigword' || L === 'bitsq' || L === 'set') return m => label(m, L, V.eps);
  if (!research) return m => (m ? bitsOf(m).map(i => i + 1).join(' ') : '1');
  return m => (m ? 'γ' + sub(bitsOf(m).join('')) : '1');
}

// ---------------------------------------------------------------- Clifford: the table of the moves
const fadeOf = (hot, i) => (hot != null && i.target !== hot ? { opacity: 0.18 } : undefined);

function CliffordPanel({ V, research, row, isLens, nm, hot }) {
  const rows = [...V.field].sort((a, b) => ROLE_ORDER[V.blades[a].role] - ROLE_ORDER[V.blades[b].role] || a - b), n = V.n;
  const x0 = 60, cw = (VB_W - 6 - x0) / n, y0 = 46, rh = Math.min(20, 128 / rows.length);
  const inc = (S, a) => V.incidences.find(i => i.source === S && i.axis === a);
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views-maxwell" row={row} part="Clifford view" viewBox={`0 0 ${VB_W} ${VB_H}`}>
        <text x={6} y={14} className="t-small t-muted">Clifford</text>
        {V.axes.map((a, i) => <text key={a} x={r1(x0 + i * cw + cw / 2)} y={y0 - 8} textAnchor="middle" className="t-mono t-tiny">{research ? '∂' + a : a}</text>)}
        {rows.map((S, j) => { const y = y0 + j * rh; return (
          <g key={S}>
            <Mark x={9} y={r1(y + rh / 2 - 1)} role={V.blades[S].role} r={3.6} />
            <text x={x0 - 5} y={r1(y + rh / 2 + 2.5)} textAnchor="end" className="t-mono t-tiny">{nm(S)}</text>
            {V.axes.map((_, a) => { const i = inc(S, a), w = i.op === 'wedge'; return (
              <g key={a} data-move={`${S},${a}`} style={fadeOf(hot, i)}>
                <rect x={r1(x0 + a * cw + 1.2)} y={r1(y + 1)} width={r1(cw - 2.4)} height={r1(rh - 2.6)} rx={2.5} className="on-panel" style={{ stroke: 'var(--fg)', strokeOpacity: hot === i.target ? 1 : 0.55, strokeWidth: hot === i.target ? 1.6 : 0.9, strokeDasharray: w ? '2.5 2' : undefined }} />
                <text x={r1(x0 + a * cw + cw / 2)} y={r1(y + rh / 2 + 2.4)} textAnchor="middle" className={'t-mono t-micro' + (w ? ' t-muted' : '')}>{(research && i.sign < 0 ? '−' : '') + nm(i.target)}</text>
              </g>); })}
          </g>); })}
        {research && (
          <g transform={`translate(6, ${VB_H - 8})`}>
            <rect x={0} y={-8} width={12} height={9} rx={2} className="on-panel" style={{ stroke: 'var(--fg)', strokeOpacity: 0.55, strokeWidth: 0.9 }} /><text x={16} y={0} className="t-micro">to a vector</text>
            <rect x={78} y={-8} width={12} height={9} rx={2} className="on-panel" style={{ stroke: 'var(--fg)', strokeOpacity: 0.55, strokeWidth: 0.9, strokeDasharray: '2.5 2' }} /><text x={94} y={0} className="t-micro">to a trivector</text>
          </g>
        )}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- simplex: the pieces are edges
function SimplexPanel({ V, research, row, isLens, nm, hot }) {
  const n = V.n, cx = 105, cy = 104, P = simplexPts(n, n <= 3 ? 64 : 70).map(([x, y]) => [cx + x, cy + y]);
  const cen = m => { const v = bitsOf(m).map(i => P[i]); return [v.reduce((s, p) => s + p[0], 0) / v.length, v.reduce((s, p) => s + p[1], 0) / v.length]; };
  const faces = V.blades.filter(b => b.grade === 3).map(b => b.m);
  const toward = (from, to, f) => [from[0] + (to[0] - from[0]) * f, from[1] + (to[1] - from[1]) * f];
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views-maxwell" row={row} part="simplex view" viewBox={`0 0 ${VB_W} ${VB_H}`}>
        <text x={6} y={14} className="t-small t-muted">Simplex</text>
        {faces.map(m => <polygon key={'f' + m} points={bitsOf(m).map(i => `${r1(P[i][0])},${r1(P[i][1])}`).join(' ')} className="ink" style={{ fillOpacity: 0.05 }} />)}
        {V.field.map(S => { const [a, b] = bitsOf(S), role = V.blades[S].role; return <line key={'e' + S} x1={r1(P[a][0])} y1={r1(P[a][1])} x2={r1(P[b][0])} y2={r1(P[b][1])} style={{ stroke: role === 'B' ? 'var(--muted)' : 'var(--fg)', strokeWidth: 2.4, strokeDasharray: role === 'T' ? '1.5 2.5' : undefined, strokeLinecap: 'round' }}><title>{`${nm(S)} (${role})`}</title></line>; })}
        {V.incidences.map(i => { const m = cen(i.source), w = i.op === 'wedge', t = w ? cen(i.target) : P[bitsOf(i.target)[0]], [ex, ey] = toward(m, t, w ? 0.62 : 0.72), [sx, sy] = toward(m, t, w ? 0.12 : 0.18); return (
          <g key={`${i.source},${i.axis}`} data-move={`${i.source},${i.axis}`} style={fadeOf(hot, i)}>
            <line x1={r1(sx)} y1={r1(sy)} x2={r1(ex)} y2={r1(ey)} className="stroke-ink" style={{ strokeWidth: hot === i.target ? 1.8 : 1, strokeOpacity: 0.8, strokeDasharray: w ? '2.5 2' : undefined }} />
            <path d={arrowHead(sx, sy, ex, ey, 4.5)} className="ink" style={{ fillOpacity: 0.8 }} />
          </g>); })}
        {P.map(([x, y], i) => { const inner = Math.hypot(x - cx, y - cy) < 36; return (
          <g key={'v' + i}><Mark x={r1(x)} y={r1(y)} role={V.blades[1 << i].role} r={4.2} />
            <text x={r1(inner ? x + 8 : cx + (x - cx) * 1.2)} y={r1(inner ? y + 15 : cy + (y - cy) * 1.2 + 4)} textAnchor={inner ? 'start' : 'middle'} className="t-mono t-tiny">{research ? nm(1 << i) : String(i + 1)}</text></g>); })}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- cube: the labels are corners
function CubePanel({ V, research, row, isLens, nm, hot }) {
  const n = V.n, N = 1 << n, raw = Array.from({ length: N }, (_, m) => cubePoint(m, n));
  const xs = raw.map(p => p[0]), ys = raw.map(p => p[1]), mnx = Math.min(...xs), mxx = Math.max(...xs), mny = Math.min(...ys), mxy = Math.max(...ys);
  const s = Math.min((VB_W - 30) / (mxx - mnx || 1), (VB_H - 62) / (mxy - mny || 1)), ox = (VB_W - (mxx - mnx) * s) / 2, oy = 30 + ((VB_H - 62) - (mxy - mny) * s) / 2;
  const P = raw.map(([x, y]) => [ox + (x - mnx) * s, oy + (y - mny) * s]);
  const lit = new Map(V.incidences.map(i => [Math.min(i.source, i.target) + ',' + Math.max(i.source, i.target), i]));
  const edges = []; for (let m = 0; m < N; m++) for (let a = 0; a < n; a++) if (!((m >> a) & 1)) edges.push([m, m | (1 << a)]);
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views-maxwell" row={row} part="cube view" viewBox={`0 0 ${VB_W} ${VB_H}`}>
        <text x={6} y={14} className="t-small t-muted">Cube</text>
        {edges.map(([a, b]) => { const i = lit.get(a + ',' + b); return i
          ? <line key={a + '-' + b} x1={r1(P[a][0])} y1={r1(P[a][1])} x2={r1(P[b][0])} y2={r1(P[b][1])} className="stroke-ink" data-move={`${i.source},${i.axis}`} style={{ strokeWidth: hot === i.target ? 2.6 : 1.7, strokeDasharray: i.op === 'wedge' ? '3 2' : undefined, ...fadeOf(hot, i) }} />
          : <line key={a + '-' + b} x1={r1(P[a][0])} y1={r1(P[a][1])} x2={r1(P[b][0])} y2={r1(P[b][1])} className="hair" style={{ strokeWidth: 0.7 }} />; })}
        {V.blades.map(b => { const [x, y] = P[b.m]; return b.grade >= 1 && b.grade <= 3
          ? <g key={b.m}><Mark x={r1(x)} y={r1(y)} role={b.role} r={b.grade === 2 ? 4.2 : 3} /><title>{`${nm(b.m)} (${b.role})`}</title>{research && b.grade === 2 && <text x={r1(x)} y={r1(y - 7)} textAnchor="middle" className="t-mono t-micro">{label(b.m, 'bits', V.eps)}</text>}</g>
          : <circle key={b.m} cx={r1(x)} cy={r1(y)} r={1.8} className="ink-muted" />; })}
        <text x={VB_W / 2} y={VB_H - 8} textAnchor="middle" className="t-mono t-tiny t-muted">{(research ? 'layers ' : '') + V.layers.join(' · ')}</text>
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- prime: the labels are products of primes
function PrimePanel({ V, research, row, isLens, hot }) {
  const P = m => bitsOf(m).reduce((x, i) => x * PRIMES[i], 1);
  const col = g => V.blades.filter(b => b.grade === g).map(b => b.m).sort((a, b) => P(a) - P(b));
  const X = { 1: 30, 2: 105, 3: 180 }, at = new Map();
  for (const g of [1, 2, 3]) { const c = col(g), top = 40, h = VB_H - 70; c.forEach((m, j) => at.set(m, [X[g], top + (c.length === 1 ? h / 2 : (h * j) / (c.length - 1))])); }
  const ch = Math.min(16, (VB_H - 70) / Math.max(1, Math.max(...[1, 2, 3].map(g => col(g).length)) - 1) - 2);
  const chip = (m, strong) => { const [x, y] = at.get(m), role = V.blades[m].role, filled = role === 'E' || role === 'rho' || role === 'Faraday'; return (
    <g key={'c' + m}>
      <rect x={r1(x - 15)} y={r1(y - ch / 2)} width={30} height={r1(ch)} rx={4} className="on-panel" style={{ stroke: filled ? 'var(--fg)' : 'var(--muted)', strokeWidth: strong ? 1.5 : 1 }} />
      <text x={x} y={r1(y + 3.5)} textAnchor="middle" className="t-mono t-tiny">{P(m)}</text>
      <title>{`${label(m, 'primes', V.eps)} (${role})`}</title>
    </g>); };
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views-maxwell" row={row} part="prime view" viewBox={`0 0 ${VB_W} ${VB_H}`}>
        <text x={6} y={14} className="t-small t-muted">Prime</text>
        {research && <text x={67} y={28} textAnchor="middle" className="t-mono t-micro t-muted">÷ p</text>}
        {research && <text x={142} y={28} textAnchor="middle" className="t-mono t-micro t-muted">× p</text>}
        {V.incidences.map(i => { const [x1, y1] = at.get(i.source), [x2, y2] = at.get(i.target), w = i.op === 'wedge', xa = w ? x1 + 15 : x1 - 15, xb = w ? x2 - 15 : x2 + 15; return (
          <line key={`${i.source},${i.axis}`} data-move={`${i.source},${i.axis}`} x1={r1(xa)} y1={r1(y1)} x2={r1(xb)} y2={r1(y2)} className="stroke-ink" style={{ strokeWidth: hot === i.target ? 1.8 : 0.9, strokeOpacity: 0.7, strokeDasharray: w ? '2.5 2' : undefined, ...fadeOf(hot, i) }}>
            <title>{`${P(i.source)} ${w ? '×' : '÷'} ${PRIMES[i.axis]} = ${P(i.target)}`}</title>
          </line>); })}
        {[1, 2, 3].flatMap(g => col(g).map(m => chip(m, g === 2)))}
        {research && <text x={VB_W / 2} y={VB_H - 8} textAnchor="middle" className="t-mono t-tiny t-muted">{`÷p: ${V.incidences.filter(i => i.op === 'contract').length} moves · ×p: ${V.incidences.filter(i => i.op === 'wedge').length} moves`}</text>}
      </FigSvg>
    </div>
  );
}

const PANELS = { clifford: CliffordPanel, simplex: SimplexPanel, cube: CubePanel, prime: PrimePanel };
const LENS_PANEL = { clifford: 'clifford', tian: 'clifford', simplex: 'simplex', cube: 'cube', bits: 'cube', prime: 'prime', primes: 'prime' };
const cellOf = params => { const k = Number.isInteger(params.k) ? params.k : 1, d = Number.isInteger(params.d) ? params.d : 3; return k >= 1 && d >= 1 && k + d <= 5 ? [k, d] : [1, 3]; };

/** the equations of the cell (k, d) as maxwell_selfcheck.py names them: { target, id, name, eq } */
export const equationsOf = (k, d) => (MAXWELL.equations[`${k},${d}`] || []).map(([target, id, name, eq]) => ({ target, id, name, eq }));

export default function FourViewsMaxwell({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [[k, d], setKD] = useState(cellOf(params));
  useEffect(() => { setKD(cellOf(params)); }, [params.k, params.d]);   // eslint-disable-line react-hooks/exhaustive-deps
  const [eq, setEq] = useState(typeof params.eq === 'string' ? params.eq : 'all');
  useEffect(() => { setEq(typeof params.eq === 'string' ? params.eq : 'all'); }, [params.eq]);
  const V = useMemo(() => maxwellViews(k, d), [k, d]);
  const EQS = equationsOf(k, d), cur = EQS.find(e => e.id === eq) || null, hot = cur ? cur.target : null;
  const pickK = v => setKD(([, dd]) => [v, Math.min(dd, 5 - v)]), pickD = v => setKD(([kk]) => [Math.min(kk, 5 - v), v]);
  const lensPanel = LENS_PANEL[lens] || null, nm = namer(V, lens, research);
  const order = ['clifford', 'simplex', 'cube', 'prime'].sort((x, y) => (x === lensPanel ? -1 : y === lensPanel ? 1 : 0));
  return (
    <div className="fig fig-four-views-maxwell" data-cell={`${k},${d}`}>
      <div className="fig-panels">
        {order.map(key => { const P = PANELS[key]; return <P key={key} V={V} research={research} row={row} isLens={key === lensPanel} nm={nm} hot={hot} />; })}
      </div>
      {cur && research && <p className="fig-readout" data-eq={cur.id} data-target={cur.target}><span>{`${cur.name}: ${cur.eq}`}</span></p>}
      <Controls label="Maxwell">
        <Chips label={research ? 'time k' : 'time'} items={[1, 2, 3, 4]} value={k} onPick={pickK} param="k" mono />
        <Chips label={research ? 'space d' : 'space'} items={[1, 2, 3, 4]} value={d} onPick={pickD} param="d" mono />
        <label className="fig-group"><span className="fig-group-label">equation</span>
          <select className="fig-select" value={cur ? cur.id : 'all'} data-param="eq" onChange={e => setEq(e.target.value)}>
            <option value="all">all equations</option>
            {EQS.map(e => <option key={e.id} value={e.id}>{research ? `${e.name}: ${e.eq}` : e.name}</option>)}
          </select>
        </label>
        {k !== d && <button type="button" className="fig-btn" data-param="mirror" onClick={() => setKD([d, k])}>{`the mirror (${d}, ${k})`}</button>}
      </Controls>
    </div>
  );
}
FourViewsMaxwell.meta = { id: 'four-views-maxwell', lenses: ['clifford', 'simplex', 'cube', 'prime', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
FourViewsMaxwell.data = (params = {}) => { const [k, d] = cellOf(params), V = maxwellViews(k, d); return { cell: [k, d], axes: V.axes, blades: V.blades, incidences: V.incidences, counts: V.counts, layers: V.layers, equations: equationsOf(k, d) }; };
