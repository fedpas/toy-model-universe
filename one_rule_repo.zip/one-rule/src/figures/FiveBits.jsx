// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure five-bits (step 19): the 32 labels of five bits on the grid of (a, b) = (number of weak bits, number of colour bits) (engines/baezEngine.js fiveBits; compared
// with checks/selfcheck/reports/lens_baez_check.json P1 by tests/engines.test.mjs). Every cell holds its labels as dots; a cell has one parity (a + b set bits), and the
// 16 even labels (filled) are one generation: their cells carry the Peirce piece of the Jordan-pair paper (the paper's names, not computed) and, at research level,
// the hypercharge Y = a/2 − b/3; the odd cells are drawn as rings. Research level also prints the anomaly sums of the 16 even labels. The controls are v15's: flip
// all five bits (the 16 odd labels become the family on show, their pieces those of their complements, marked *), pick labels (a label's numbers are printed, and the
// picked labels of the family are summed: their charges Q), all and clear. It opens on the even family. Port of v15 BaezWidgets.BW1.
import React, { useMemo, useState } from 'react';
import { fiveBits, family, flipAll, labelInfo, chargeSum } from '../../engines/baezEngine.js';
import { FigSvg, Controls, Toggle, r1 } from './kit.jsx';

const PIECE = { 'e-bar_R': ['ē', 'R'], 'nu-bar_R': ['ν̄', 'R'], q_L: ['q', 'L'], 'd-bar_R': ['d̄', 'R'], 'u-bar_R': ['ū', 'R'], l_L: ['l', 'L'] };
const minus = s => String(s).replace(/^-/, '−');

/** a piece name with its subscript (R or L) as an SVG tspan */
function Piece({ x, y, name, star = false }) {
  const [base, subs] = PIECE[name] || [name, ''];
  return <text x={x} y={y} textAnchor="middle" className="t-small t-bold">{(star ? '* ' : '') + base}<tspan dy={3} style={{ fontSize: '8px' }}>{subs}</tspan></text>;
}

export default function FiveBits({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const F = useMemo(() => fiveBits(), []);
  const [flipped, setFlipped] = useState(params.flipped === true), [sel, setSel] = useState(null), [picks, setPicks] = useState(() => new Set());
  const fam = useMemo(() => family(flipped), [flipped]), lit = useMemo(() => new Set(fam), [fam]);
  const tap = x => { setSel(x); if (lit.has(x)) setPicks(pp => { const nn = new Set(pp); if (nn.has(x)) nn.delete(x); else nn.add(x); return nn; }); };
  const flip = () => { setFlipped(f => !f); setSel(v => (v == null ? v : flipAll(v))); setPicks(pp => new Set([...pp].map(flipAll))); };
  const info = sel == null ? null : labelInfo(sel), pk = [...picks], bitsOf5 = x => x.toString(2).padStart(5, '0');
  const W = 420, x0 = 70, cw = 86, y0 = 46, rh = 72, H = y0 + 3 * rh + (research ? 36 : 12) + 34;
  return (
    <div className="fig fig-five-bits">
      <FigSvg id="five-bits" row={row} viewBox={`0 0 ${W} ${H}`}>
        {[0, 1, 2, 3].map(b => <text key={'b' + b} x={x0 + b * cw + cw / 2} y={y0 - 12} textAnchor="middle" className="t-mono t-small">{research ? `b = ${b}` : `${b} colour`}</text>)}
        {[0, 1, 2].map(a => <text key={'a' + a} x={x0 - 10} y={y0 + a * rh + rh / 2 + 4} textAnchor="end" className="t-mono t-small">{research ? `a = ${a}` : `${a} weak`}</text>)}
        {F.cells.map(c => { const x = x0 + c.b * cw, y = y0 + c.a * rh, k = c.labels.length, cols = Math.min(k, 3), rows = Math.ceil(k / 3); return (
          <g key={`${c.a},${c.b}`} data-cell={`${c.a},${c.b}`} data-n={c.n} data-even={c.even ? 1 : 0} data-piece={c.piece || ''}>
            <title>{`a = ${c.a}, b = ${c.b}: ${c.n} label${c.n === 1 ? '' : 's'} (${c.labels.join(', ')})${c.even ? `, piece ${c.piece}, Y = ${c.Y}` : ', odd'}; Q = ${c.Q.join(', ')}`}</title>
            <rect x={x + 3} y={y + 3} width={cw - 6} height={rh - 6} rx={5} className={c.even ? 'hair' : 'hair-2'} />
            {c.even !== flipped && research && <Piece x={x + cw / 2} y={y + 20} name={flipped ? labelInfo(flipAll(c.labels[0])).piece : c.piece} star={flipped} />}
            {c.even !== flipped && research && <text x={x + cw - 8} y={y + 16} textAnchor="end" className="t-mono t-micro t-muted">{minus(c.Y)}</text>}
            {c.labels.map((lab, i) => { const cx = x + cw / 2 + ((i % 3) - (cols - 1) / 2) * 14, cy = y + (c.even !== flipped && research ? 40 : 32) + (Math.floor(i / 3) - (rows - 1) / 2) * 14, on = lit.has(lab); return (
              <g key={lab} role="button" tabIndex={0} aria-pressed={picks.has(lab)} aria-label={`label ${bitsOf5(lab)}`} data-param="picks" className="fig-cell"
                onClick={() => tap(lab)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tap(lab); } }}>
                <circle cx={r1(cx)} cy={r1(cy)} r={7} className="hit" />
                {(picks.has(lab) || sel === lab) && <circle cx={r1(cx)} cy={r1(cy)} r={6.6} className="stroke-ink" style={{ strokeWidth: picks.has(lab) ? 1.6 : 0.9, strokeDasharray: picks.has(lab) ? undefined : '2 1.5' }} />}
                <circle cx={r1(cx)} cy={r1(cy)} r={4.4} data-label={lab} data-lit={on ? 1 : 0} className={on ? 'ink' : 'on-panel'} style={on ? undefined : { stroke: 'var(--muted)', strokeWidth: 1.1 }} />
              </g>); })}
            <text x={x + 8} y={y + rh - 9} className="t-mono t-micro t-muted">{c.n}</text>
          </g>); })}
        {research && <text x={x0} y={H - 46} className="t-mono t-tiny t-muted">{`even labels: Σ Y = ${F.sums.Y} · Σ Y³ = ${F.sums.Y3} · Σ Q = ${F.sums.Q} · by grade ${F.grading.join(' ')}`}</text>}
        <text x={x0} y={H - 26} className="t-mono t-tiny" data-read={sel ?? ''}>{info ? (research
          ? `${bitsOf5(sel)}: a = ${info.a}, b = ${info.b} · Y = ${minus(info.Y)} · Q = ${minus(info.Q)} · T₃ = ${minus(info.T3)}${info.piece ? ` · ${info.piece}` : ''}`
          : `${bitsOf5(sel)}: ${info.a} weak, ${info.b} colour · charge ${minus(info.Q)}`) : (research ? 'pick a label' : 'tap a dot')}</text>
        <text x={x0} y={H - 10} className="t-mono t-tiny" data-pick-count={pk.length} data-sum={chargeSum(pk)}>{`${pk.length} picked${pk.length ? ` · Σ Q = ${minus(chargeSum(pk))}` : ''}${flipped ? ' · the flipped family (*)' : ''}`}</text>
      </FigSvg>
      <Controls label="labels">
        <Toggle label={research ? 'flip all five bits' : 'flip every switch'} on={flipped} onChange={flip} param="flipped" />
        <button type="button" className="fig-btn" data-param="picks" onClick={() => setPicks(new Set(fam))}>all</button>
        <button type="button" className="fig-btn" data-param="picks" onClick={() => setPicks(new Set())}>clear</button>
      </Controls>
    </div>
  );
}
FiveBits.meta = { id: 'five-bits', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
FiveBits.data = () => { const F = fiveBits(); return { cells: F.cells, sums: F.sums, grading: F.grading }; };
