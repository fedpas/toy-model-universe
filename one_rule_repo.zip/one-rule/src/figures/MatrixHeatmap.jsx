// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure matrix-heatmap: the translation matrix of content/matrix.json as one picture — every author row (an object of the Schuller, Baez and category reports, one
// block per report, in the table's order, a small gap between parts) against the 22 columns of the atlas. A cell is drawn by its grade as a shape, never by colour
// alone: E (exact: computed in a script) a filled square, S (structural) an open square, A (analogy) a dot; no cell, nothing. The table is read as the Logbook reads
// it (useTable('matrix') and registerModel.js matrixCounts; params.matrix, when given, is drawn instead). The controls are v15's (LensMatrix.jsx): a column (the rows
// with a cell there stay, the others fade), the grades (the other cells fade; a row stays when it has one of them), and a row (its cells and their notes, quoted
// from the report, open under the picture). Port of v15 LensMatrix.jsx, all three reports at once.
import React, { useState, useEffect, useMemo } from 'react';
import { useTable } from '../app/content.js';
import { peekTable } from '../app/store.js';
import { matrixCounts } from '../logbook/registerModel.js';
import { FigSvg, Controls, Chips } from './kit.jsx';

const GRADES = ['E', 'S', 'A'];
const NAME = { E: 'exact', S: 'structural', A: 'analogy' };
const okMatrix = m => !!m && Array.isArray(m.rows) && Array.isArray(m.columns);
const CW = 8, RH = 8, LW = 22, GAP = 10, PART = 4, TOP = 72;

/** a cell's shape: E a filled square, S an open square, A a dot */
function Shape({ g, x, y }) {
  if (g === 'E') return <rect x={x + 1} y={y + 1} width={CW - 2} height={RH - 2} className="ink" style={{ fillOpacity: 0.85 }} />;
  if (g === 'S') return <rect x={x + 1.6} y={y + 1.6} width={CW - 3.2} height={RH - 3.2} className="stroke-ink" style={{ strokeWidth: 1.1 }} />;
  return <circle cx={x + CW / 2} cy={y + RH / 2} r={1.7} className="ink" />;
}

export default function MatrixHeatmap({ params = {}, lens = null, level = 'research', theme, row }) {
  const [M0] = useTable('matrix');
  const M = okMatrix(params.matrix) ? params.matrix : okMatrix(M0) ? M0 : null;
  const cleanGrades = v => (Array.isArray(v) ? GRADES.filter(g => v.includes(g)) : []);
  const [col, setCol] = useState(typeof params.column === 'string' ? params.column : '');
  const [grades, setGrades] = useState(cleanGrades(params.grades));
  const [sel, setSel] = useState(typeof params.row === 'string' ? params.row : null);
  useEffect(() => { setCol(typeof params.column === 'string' ? params.column : ''); }, [params.column]);
  useEffect(() => { setGrades(cleanGrades(params.grades)); }, [JSON.stringify(params.grades || [])]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setSel(typeof params.row === 'string' ? params.row : null); }, [params.row]);
  const counts = useMemo(() => matrixCounts(M), [M]);
  const layout = useMemo(() => {
    if (!M) return null;
    const blocks = (M.sources || []).map((s, b) => {
      const rows = M.rows.filter(r => r.src === s.key); let y = TOP, last = null; const at = [];
      for (const r of rows) { if (last !== null && r.part !== last) y += PART; at.push({ r, y }); y += RH; last = r.part; }
      return { s, b, x0: 4 + b * (LW + 22 * CW + GAP), rows: at, bottom: y };
    });
    return { blocks, bottom: Math.max(TOP, ...blocks.map(k => k.bottom)) };
  }, [M]);
  if (!M) {
    return (
      <div className="fig fig-matrix-heatmap">
        <FigSvg id="matrix-heatmap" row={row} viewBox="0 0 620 60">
          <rect x={1} y={1} width={618} height={58} rx={6} className="on-panel" style={{ stroke: 'var(--line)', strokeDasharray: '4 3' }} />
          <text x={310} y={34} textAnchor="middle" className="t-small t-muted">loading the translation matrix</text>
        </FigSvg>
      </div>
    );
  }
  const cols = M.columns, colIdx = new Map(cols.map((c, i) => [c.key, i]));
  const isShown = r => (!col || (r.cells || {})[col]) && (!grades.length || Object.values(r.cells || {}).some(x => grades.includes(x.grade)));
  const shown = M.rows.filter(isShown).length, selRow = sel ? M.rows.find(r => r.uid === sel) : null;
  const H = layout.bottom + 40;
  const pickRow = uid => setSel(s => (s === uid ? null : uid));
  return (
    <div className="fig fig-matrix-heatmap">
      <FigSvg id="matrix-heatmap" row={row} viewBox={`0 0 620 ${H}`}>
        {layout.blocks.map(({ s, x0, rows, bottom }) => {
          const n = rows.length, c = matrixCounts({ rows: rows.map(a => a.r), columns: cols });
          return (
            <g key={s.key} data-source={s.key} data-rows={n} data-counts={`${c.E},${c.S},${c.A},${c.rowsWithoutCell}`}>
              <text x={x0} y={11} className="t-tiny t-bold">{s.name.length > 44 ? s.name.slice(0, s.name.indexOf('(') > 0 ? s.name.indexOf('(') : 44).trim() : s.name}</text>
              <text x={x0} y={22} className="t-mono t-micro t-muted">{`${n} rows · E ${c.E} · S ${c.S} · A ${c.A} · ${c.rowsWithoutCell} gaps`}</text>
              {cols.map((k, i) => (
                <text key={k.key} transform={`translate(${x0 + LW + i * CW + CW / 2 + 2.6}, ${TOP - 4}) rotate(-90)`} className={col === k.key ? 't-micro t-bold' : 't-micro t-muted'}>
                  <title>{`${k.long} (${k.where})`}</title>{k.short}
                </text>
              ))}
              <rect x={x0 + LW - 0.5} y={TOP - 1} width={22 * CW + 1} height={bottom - TOP + 2} rx={2} className="hair" />
              {col && colIdx.has(col) && <rect x={x0 + LW + colIdx.get(col) * CW - 0.5} y={TOP - 2} width={CW + 1} height={bottom - TOP + 4} className="stroke-ink" style={{ strokeWidth: 0.9, strokeDasharray: '2 1.5' }} data-column={col} />}
              {rows.map(({ r, y }) => {
                const on = isShown(r), picked = sel === r.uid;
                return (
                  <g key={r.uid} data-uid={r.uid} data-shown={on ? 1 : 0} style={on ? undefined : { opacity: 0.2 }}>
                    {picked && <rect x={x0} y={y - 0.5} width={LW + 22 * CW} height={RH + 1} className="ink" style={{ fillOpacity: 0.1 }} />}
                    <g role="button" tabIndex={0} aria-pressed={picked} aria-label={`${r.id}: ${r.title}`} data-param="row" className="fig-cell" onClick={() => pickRow(r.uid)}
                      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickRow(r.uid); } }}>
                      <rect x={x0} y={y} width={LW - 2} height={RH} className="hit" />
                      <text x={x0 + LW - 3} y={y + RH - 1.4} textAnchor="end" className={picked ? 't-mono t-micro t-bold' : 't-mono t-micro'} style={{ fontSize: 6.5 }}>{r.id}</text>
                    </g>
                    {cols.map((k, i) => {
                      const x = (r.cells || {})[k.key]; if (!x) return null;
                      const dim = grades.length && !grades.includes(x.grade);
                      return (
                        <g key={k.key} data-cell={`${r.uid},${k.key}`} data-grade={x.grade} style={dim ? { opacity: 0.2 } : undefined}>
                          <title>{`${r.id} ${r.title} × ${k.long}: ${x.grade} ${NAME[x.grade] || ''}`}</title>
                          <Shape g={x.grade} x={x0 + LW + i * CW} y={y} />
                        </g>
                      );
                    })}
                  </g>
                );
              })}
            </g>
          );
        })}
        <g transform={`translate(4, ${layout.bottom + 18})`} data-total={`${counts.rows},${counts.columns},${counts.cells},${counts.E},${counts.S},${counts.A},${counts.rowsWithoutCell}`}>
          {GRADES.map((g, i) => (
            <g key={g} transform={`translate(${i * 128}, 0)`}>
              <Shape g={g} x={0} y={-7} />
              <text x={12} y={0} className="t-tiny">{`${g} ${NAME[g]} `}<tspan className="t-mono t-muted">{counts[g]}</tspan></text>
            </g>
          ))}
          <text x={384} y={0} className="t-tiny t-muted">{`no cell: ${counts.rowsWithoutCell} rows`}</text>
          <text x={0} y={15} className="t-mono t-micro t-muted" data-shown={shown}>{`${counts.rows} rows × ${counts.columns} columns · ${counts.cells} graded cells${shown !== counts.rows ? ` · ${shown} of ${counts.rows} rows shown` : ''}`}</text>
        </g>
      </FigSvg>
      {selRow && (
        <div className="fig-note" data-panel={selRow.uid} role="region" aria-label={selRow.id}>
          <p><code className="fig-mono">{selRow.id}</code> <b lang="en">{selRow.title}</b> <button type="button" className="fig-btn" data-param="row" onClick={() => setSel(null)}>Close</button></p>
          {Object.keys(selRow.cells || {}).length ? (
            <ul>{cols.filter(k => (selRow.cells || {})[k.key]).map(k => <li key={k.key} data-col={k.key}><span className="fig-mono">{selRow.cells[k.key].grade}</span> <b>{k.long}</b> <span lang="en">{selRow.cells[k.key].note}</span></li>)}</ul>
          ) : <p>No cell: a gap.</p>}
        </div>
      )}
      <Controls label="translation matrix">
        <label className="fig-group"><span className="fig-group-label">column</span>
          <select className="fig-select" value={col} data-param="column" onChange={e => setCol(e.target.value)}>
            <option value="">All columns</option>
            {cols.map(k => <option key={k.key} value={k.key}>{k.long}</option>)}
          </select>
        </label>
        <Chips label="grades" items={GRADES} value={grades} isOn={(g, v) => v.includes(g)} onPick={g => setGrades(v => (v.includes(g) ? v.filter(x => x !== g) : GRADES.filter(x => x === g || v.includes(x))))} param="grades" mono />
      </Controls>
    </div>
  );
}
MatrixHeatmap.meta = { id: 'matrix-heatmap', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download (the table as the app has loaded it, or params.matrix) */
MatrixHeatmap.data = (params = {}) => {
  const M = okMatrix(params.matrix) ? params.matrix : okMatrix(peekTable('matrix')) ? peekTable('matrix') : null;
  if (!M) return { loaded: false, counts: matrixCounts(null) };
  return { loaded: true, counts: matrixCounts(M), columns: M.columns.map(c => c.key), cells: M.rows.map(r => ({ uid: r.uid, src: r.src, part: r.part, grades: Object.fromEntries(Object.entries(r.cells || {}).map(([k, x]) => [k, x.grade])) })) };
};
