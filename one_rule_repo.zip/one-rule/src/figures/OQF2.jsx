// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure o-q-f2 (step 17): two rails, one count. For n = 2 … 8, each bar is |O(Q)|, the symmetries of the finite shadow (the form Q over F₂) of a cell, on a log scale:
// the outline is |O(Q)|, the solid part what a family of familiar groups fills. Right: W(E_n) reduced mod 2 in O(Q) of Cl(n,0) — it fills it exactly for n = 3 … 8.
// Left: S_{n+1} in O(Q) of Cl(0,n) — full for n = 2 … 5, then short. The numbers are those groups_check.py prints (engines/labels.js RAILS, compared with its log by
// tests/engines.test.mjs). Each bar carries the clock colour of its cell, Cl(n,0) or Cl(0,n), with its c printed. The chips n = 2 … 8 are v15's (interactive
// entry n): the chosen row is shaded and its numbers are printed under the rails. Port of v15 LabelsWidgets.Rails.
import React, { useState, useEffect } from 'react';
import { RAILS, clockOf, TYPE_SYMBOL } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, clockVar, r1, sub, pick, isIn } from './kit.jsx';

const NS = [2, 3, 4, 5, 6, 7, 8];
const bits = x => Math.log2(x), SC = 160 / bits(348364800), CX = 210;
const nf = x => x.toLocaleString('en').replace(/,/g, ' ');
const typeName = t => t.replace(/(\d)/g, d => sub(d));

export default function OQF2({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [n, setN] = useState(pick(params.n, isIn(NS), 8));
  useEffect(() => { setN(pick(params.n, isIn(NS), 8)); }, [params.n]);
  const e = RAILS.E[n], a = RAILS.A[n];
  return (
    <div className="fig fig-o-q-f2">
      <FigSvg id="o-q-f2" row={row} viewBox="0 0 420 284">
        <text x={8} y={12} className="t-tiny t-muted">{research ? 'Aₙ: Sₙ₊₁ in O(Q) of Cl(0,n)' : 'the family of the simplex'}</text>
        <text x={412} y={12} textAnchor="end" className="t-tiny t-muted">{research ? 'Eₙ: W(Eₙ) mod 2 = O(Q) of Cl(n,0)' : 'the family E'}</text>
        {NS.map((m, i) => {
          const y = 22 + i * 30, A = RAILS.A[m], E = RAILS.E[m], on = m === n, cA = clockOf(0, m), cE = clockOf(m, 0);
          return (
            <g key={m} data-n={m}>
              {on && <rect x={0} y={y - 3} width={420} height={26} className="ink" style={{ fillOpacity: 0.06 }} data-selected={m} />}
              {A && (
                <g data-rail="A" data-order={A[2]} data-filled={A[1]} data-clock={cA}>
                  <title>{`Cl(0,${m}): S${sub(m + 1)} = ${nf(A[1])} inside |O(Q)| = ${nf(A[2])} (c = ${cA})`}</title>
                  <rect x={r1(CX - 18 - bits(A[2]) * SC)} y={y} width={r1(bits(A[2]) * SC)} height={20} style={{ fill: 'none', stroke: clockVar(cA), strokeWidth: 1.5 }} />
                  <rect x={r1(CX - 18 - bits(A[1]) * SC)} y={y} width={r1(bits(A[1]) * SC)} height={20} style={{ fill: clockVar(cA), fillOpacity: 0.8 }} />
                  {research && <text x={CX - 22} y={y + 14} textAnchor="end" className="t-tiny t-bold">{`S${sub(m + 1)}`}</text>}
                  <text x={r1(CX - 22 - bits(A[2]) * SC)} y={y + 14} textAnchor="end" className="t-mono t-micro t-muted">{`c = ${cA}`}</text>
                </g>
              )}
              <text x={CX} y={y + 14} textAnchor="middle" className="t-mono t-small">{m}</text>
              {E && (
                <g data-rail="E" data-order={E[3]} data-filled={E[3]} data-clock={cE}>
                  <title>{`Cl(${m},0): ${E[0]}, |W| = ${nf(E[2])}, kernel ${E[4]}, image ${nf(E[3])} = |O(Q)| (c = ${cE})`}</title>
                  <rect x={CX + 18} y={y} width={r1(bits(E[3]) * SC)} height={20} style={{ fill: clockVar(cE), fillOpacity: 0.8, stroke: clockVar(cE), strokeWidth: 1.5 }} />
                  {research && <text x={CX + 22} y={y + 14} className="t-tiny t-bold">{typeName(E[0])}</text>}
                  <text x={r1(CX + 24 + bits(E[3]) * SC)} y={y + 14} className="t-mono t-micro t-muted">{`c = ${cE}`}</text>
                </g>
              )}
            </g>
          );
        })}
        {research && (
          <g transform="translate(8, 238)" data-row={n}>
            <text x={0} y={0} className="t-mono t-tiny">{e ? `n = ${n}: ${typeName(e[0])}, |W| = ${nf(e[2])}, kernel ${e[4]}, image ${nf(e[3])} = |O(Q)| (${TYPE_SYMBOL[e[1]]})` : `n = ${n}: no E rail`}</text>
            <text x={0} y={16} className="t-mono t-tiny">{a ? `n = ${n}: S${sub(n + 1)} = ${nf(a[1])} inside |O(Q)| = ${nf(a[2])} (${TYPE_SYMBOL[a[0]]}), index ${nf(a[2] / a[1])}` : `n = ${n}: no A rail`}</text>
            <text x={0} y={34} className="t-tiny t-muted">log scale · outline |O(Q)| · solid: the family</text>
          </g>
        )}
      </FigSvg>
      <Controls label="rank">
        <Chips label="n" items={NS} value={n} onPick={setN} param="n" mono />
      </Controls>
    </div>
  );
}
OQF2.meta = { id: 'o-q-f2', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
OQF2.data = () => ({ E: RAILS.E, A: RAILS.A });
