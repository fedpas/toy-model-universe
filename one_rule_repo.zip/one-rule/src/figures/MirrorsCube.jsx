// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure mirrors-cube (step 3): the corners of the n-cube read as mirrors (engines/labels.js mirrors; the corner S is the product of the coordinate mirrors of its
// axes and flips exactly those axes, checked by the kernel's sandwich): the corners in columns by their number of mirrors (the binomial layers), the even ones (the
// rotors, the demicube) filled and the odd ones (the reflections) as rings; for n > 5 the layers as bars. Beside it, two mirrors make a rotation: the stored example
// of mirrors.json (normals (2, 0) and (8/5, −4/5)), the point e1 reflected in the second mirror and then in the first (the kernel's products in Cl(2,0)) lands on
// (3/5, 4/5). Counts and the example are compared with checks/selfcheck/mirrors.json by tests/engines.test.mjs. Lenses print the corners: cube / bits as bit strings,
// prime / primes as products of primes, clifford as e-words. The controls are v15's: the chips n = 2 … 8, a corner to pick (n <= 5; what it flips and how many
// mirrors it needs is printed under the picture) and "only the even corners". Port of v15 MirrorsSection.jsx (CubePic, LayerBars, TwoMirrors).
import React, { useMemo, useState, useEffect } from 'react';
import { mirrors, twoMirrors, MIRROR_EXAMPLES, label } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, Toggle, sub, r1, arrowHead, labelLens } from './kit.jsx';

const fr = s => { const [a, b] = String(s).split('/'); return b ? Number(a) / Number(b) : Number(a); };
const nOf = params => (Number.isInteger(params.n) && params.n >= 2 && params.n <= 8 ? params.n : 4);

export default function MirrorsCube({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [n, setN] = useState(nOf(params));
  useEffect(() => { setN(nOf(params)); }, [params.n]);   // eslint-disable-line react-hooks/exhaustive-deps
  const okCorner = (v, m) => Number.isInteger(v) && v >= 0 && v < 1 << m;
  const [sel, setSel] = useState(okCorner(params.corner, nOf(params)) ? params.corner : (1 << nOf(params)) - 1);
  const [evenOnly, setEvenOnly] = useState(params.evenOnly === true);
  useEffect(() => { setEvenOnly(params.evenOnly === true); }, [params.evenOnly]);
  const pickN = m => { setN(m); setSel(m <= 5 ? (1 << m) - 1 : 0); };
  const M = useMemo(() => mirrors(n), [n]), corner = okCorner(sel, n) ? sel : (1 << n) - 1, cw0 = corner, wsel = (() => { let c = 0; for (let x = cw0; x; x &= x - 1) c++; return c; })();
  const ex = MIRROR_EXAMPLES.rotation_3_4_5, T = useMemo(() => twoMirrors(ex.normals[0].map(fr), ex.normals[1].map(fr), ex.q), []);   // eslint-disable-line react-hooks/exhaustive-deps
  const L = labelLens(lens), printLabel = L === 'bits' || L === 'primes' || L === 'clifford' || L === 'set' ? m => label(m, L, M.eps) : null;
  const W = 420, H = (research ? 266 : 244) + (n <= 5 ? 16 : 0), top = 46, bottom = 210, lw = 250;
  const cw = Math.min(46, (lw - 50) / n), x0 = 26 + (lw - 50 - cw * n) / 2, maxCol = Math.max(...M.counts.layers), dy = Math.min(24, (bottom - top) / maxCol);
  // the two mirrors, in the right part: lines through the centre normal to the stored normals, the unit circle, e1 and its two images
  const C = [330, 128], S = 56, P = ([x, y]) => [C[0] + S * x, C[1] - S * y];
  const mirrorLine = a => { const d = [-a[1], a[0]], m = Math.hypot(d[0], d[1]), u = [d[0] / m * 1.2, d[1] / m * 1.2]; return [P([-u[0], -u[1]]), P(u)]; };
  const pts = [[T.x, research ? 'x' : '1'], [T.y, research ? 'R₂x' : '2'], [T.z, research ? 'R₁R₂x' : '3']];
  const ang = Math.atan2(T.z[1], T.z[0]), arc = (() => { const k = 20, steps = []; for (let i = 0; i <= k; i++) { const t = ang * i / k; steps.push(P([Math.cos(t) * 0.42, Math.sin(t) * 0.42])); } return { steps }; })();
  return (
    <div className="fig fig-mirrors-cube">
      <FigSvg id="mirrors-cube" row={row} viewBox={`0 0 ${W} ${H}`}>
        {/* the corners by number of mirrors */}
        <text x={r1(x0 + (cw * (n + 1)) / 2)} y={12} textAnchor="middle" className="t-tiny t-muted">{research ? 'number of mirrors' : 'mirrors'}</text>
        {n <= 5 ? M.layers.map((col, k) => { const x = x0 + k * cw + cw / 2, y0 = (top + bottom) / 2 - ((col.length - 1) * dy) / 2; return (
          <g key={'k' + k} data-weight={k} data-count={col.length}>
            <text x={r1(x)} y={top - 16} textAnchor="middle" className="t-mono t-small">{k}</text>
            {col.map((S2, j) => { const y = y0 + j * dy, even = k % 2 === 0, on = S2 === corner, pickIt = () => setSel(S2); return (
              <g key={S2} data-mask={S2} role="button" tabIndex={0} aria-pressed={on} aria-label={`corner ${label(S2, 'clifford', M.eps)}, ${k} mirror${k === 1 ? '' : 's'}`} data-param="corner" className="fig-cell"
                style={evenOnly && !even ? { opacity: 0.15 } : undefined} onClick={pickIt} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickIt(); } }}>
                <title>{`${label(S2, 'clifford', M.eps)} · ${k} mirror${k === 1 ? '' : 's'}${research ? ` · flips ${label(S2, 'set', M.eps)}` : ''}`}</title>
                <circle cx={r1(x)} cy={r1(y)} r={9} className="hit" />
                {on && <circle cx={r1(x)} cy={r1(y)} r={8} className="stroke-ink" style={{ strokeWidth: 1.6 }} />}
                <circle cx={r1(x)} cy={r1(y)} r={4.6} className={even ? 'ink' : 'on-panel'} style={even ? undefined : { stroke: 'var(--fg)', strokeWidth: 1.4 }} />
                {printLabel && <text x={r1(x + 7)} y={r1(y + 3)} className="t-mono t-micro">{printLabel(S2)}</text>}
              </g>); })}
            <text x={r1(x)} y={bottom + 18} textAnchor="middle" className="t-mono t-small t-bold">{col.length}</text>
          </g>); })
          : M.counts.layers.map((c, k) => { const x = x0 + k * cw + 4, h = (bottom - top - 10) * c / maxCol, even = k % 2 === 0; return (
            <g key={'b' + k} data-weight={k} data-count={c}>
              <title>{`${k} mirrors: ${c} corners`}</title>
              <rect x={r1(x)} y={r1(bottom - h)} width={r1(cw - 8)} height={r1(h)} rx={2} className={even ? 'ink' : 'on-panel'} style={{ ...(even ? { fillOpacity: 0.75 } : { stroke: 'var(--fg)', strokeWidth: 1.2 }), ...(evenOnly && !even ? { opacity: 0.15 } : {}) }} />
              <text x={r1(x + (cw - 8) / 2)} y={top - 16} textAnchor="middle" className="t-mono t-small">{k}</text>
              <text x={r1(x + (cw - 8) / 2)} y={bottom + 18} textAnchor="middle" className="t-mono t-tiny t-bold">{c}</text>
            </g>); })}
        <line x1={x0} y1={bottom + 4} x2={x0 + cw * (n + 1)} y2={bottom + 4} className="hair" />
        {n <= 5 && <text x={x0} y={bottom + 36} className="t-mono t-tiny" data-corner={corner} data-mirrors={wsel}>{research
          ? `${label(corner, 'clifford', M.eps)}: flips ${corner ? label(corner, 'set', M.eps) : 'nothing'}, diag(${Array.from({ length: n }, (_, i) => ((corner >> i) & 1 ? '−1' : '+1')).join(', ')}) · ${wsel} mirror${wsel === 1 ? '' : 's'} · ${wsel % 2 ? 'odd: a reflection' : 'even: a rotor'}`
          : `${label(corner, 'bits', M.eps)}: ${wsel} mirror${wsel === 1 ? '' : 's'}, ${wsel % 2 ? 'a mirror image' : 'a turn'}`}</text>}
        {research && <text x={x0} y={H - 12} className="t-mono t-tiny t-muted">{`|B${sub(n)}| = ${M.counts.B_order} · |D${sub(n)}| = ${M.counts.D_order} · rotors ${M.counts.rotors}`}</text>}
        {/* two mirrors make a rotation */}
        <circle cx={C[0]} cy={C[1]} r={S} className="hair-2" />
        {T.normals.map((a, i) => { const [p, q] = mirrorLine(a), end = p[0] < q[0] - 0.5 || (Math.abs(p[0] - q[0]) <= 0.5 && p[1] < q[1]) ? p : q; return (
          <g key={'m' + i}>
            <line x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className="stroke-ink" style={{ strokeWidth: 1.6, strokeDasharray: i ? '5 3' : undefined }} />
            <text x={r1(end[0] - 5)} y={r1(end[1] + 4)} textAnchor="end" className="t-mono t-tiny">{research ? `mirror ${i + 1}` : String(i + 1)}</text>
          </g>); })}
        <polyline points={arc.steps.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ')} className="stroke-muted" style={{ strokeWidth: 1.2 }} />
        <path d={arrowHead(arc.steps[arc.steps.length - 2][0], arc.steps[arc.steps.length - 2][1], arc.steps[arc.steps.length - 1][0], arc.steps[arc.steps.length - 1][1], 5)} className="ink-muted" />
        {pts.map(([p, nm], i) => { const [x, y] = P(p); return (
          <g key={'p' + i} data-point={i}>
            <circle cx={r1(x)} cy={r1(y)} r={3.6} className="ink" />
            <text x={r1(x + (p[0] >= 0 ? 6 : -6))} y={r1(y + (p[1] >= 0 ? -6 : 13))} textAnchor={p[0] >= 0 ? 'start' : 'end'} className="t-mono t-small">{nm}</text>
          </g>); })}
        <circle cx={C[0]} cy={C[1]} r={1.8} className="ink" />
        {research && <text x={C[0]} y={H - 12} textAnchor="middle" className="t-mono t-tiny t-muted">{`R₁R₂x = (${ex.matrix[0][0]}, ${ex.matrix[1][0]})`}</text>}
      </FigSvg>
      <Controls label="mirrors">
        <Chips label="n" items={[2, 3, 4, 5, 6, 7, 8]} value={n} onPick={pickN} param="n" mono />
        <Toggle label={research ? 'demicube only' : 'only the turns (even)'} on={evenOnly} onChange={setEvenOnly} param="evenOnly" />
      </Controls>
    </div>
  );
}
MirrorsCube.meta = { id: 'mirrors-cube', lenses: ['cube', 'bits', 'primes', 'clifford'], learner: true };
/** the numbers the figure draws, for the frame's data download */
MirrorsCube.data = (params = {}) => { const M = mirrors(nOf(params)), ex = MIRROR_EXAMPLES.rotation_3_4_5, T = twoMirrors(ex.normals[0].map(fr), ex.normals[1].map(fr), ex.q); return { n: M.n, layers: M.layers, counts: M.counts, allFlip: M.allFlip, twoMirrors: { normals: ex.normals, x: T.x, y: T.y, z: T.z, storedMatrix: ex.matrix } }; };
