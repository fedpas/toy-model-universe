// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure four-views: one product e_a e_b = s(a,b) e_{a xor b} of the cell Cl(p,q,r) (n <= 5), drawn four ways side by side (engines/labels.js views; every sign
// from the kernel, every printed label from the kernel's label(mask, lens, eps)):
//   Clifford — the word a b as strands: sorting it crosses strands (each crossing −1), equal generators meet in a cap worth their square ε (+1, −1 or 0);
//   simplex  — a label is a face (its vertices); the product keeps the symmetric difference;
//   cube     — a label is a corner of the n-cube; the product walks from a along the axes of b to a xor b;
//   prime    — a label is a square-free product of primes; A·B = G²·K with G the shared primes (their squares become the ε) and K = lcm/gcd the new label.
// The simplex, cube and prime notations see which generators are used, not their order: the reordering sign is in the Clifford view only.
// Port of the four views of v15 MaxwellSection.jsx (ViewClifford / ViewSimplex / ViewCube / ViewPrime) and genesis_audit_v3 (simplexView, cubeView, primeView).
import React, { useState, useEffect, useMemo } from 'react';
import { views, label, PRIMES } from '../../engines/labels.js';
import { FigSvg, Controls, Stepper, sub, r1, arrowHead, labelLens } from './kit.jsx';

const VB = '0 0 310 240';
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const sup = k => String(k).replace(/\d/g, d => SUP[d]);
const epsTxt = e => (e > 0 ? '+1' : e < 0 ? '−1' : '0');
const signTxt = s => (s > 0 ? '' : s < 0 ? '−' : '');
const gname = (i, research) => (research ? 'e' + sub(i + 1) : String(i + 1));
const digits = (idx) => (idx.length ? idx.map(i => i + 1).join(' ') : '·');

// ---------------------------------------------------------------- Clifford: the string diagram of the sorting
function CliffordPanel({ v, research, row, isLens }) {
  const T = [...v.word.a.map(g => ({ g, from: 'a' })), ...v.word.b.map(g => ({ g, from: 'b' }))], m = T.length, na = v.word.a.length;
  const order = T.map((_, j) => j).sort((i, j) => T[i].g - T[j].g || i - j), pos = Array(m); order.forEach((j, k) => { pos[j] = k; });
  const sorted = order.map(j => T[j]), caps = [], keep = [];
  for (let k = 0; k < m; k++) { if (k + 1 < m && sorted[k].g === sorted[k + 1].g) { caps.push({ k, g: sorted[k].g, eps: v.eps[sorted[k].g] }); k++; } else keep.push(k); }
  let N = 0; for (let i = 0; i < m; i++) for (let j = i + 1; j < m; j++) if (pos[i] > pos[j]) N++;
  const dx = Math.min(30, 250 / Math.max(m, 1)), gapA = na && m > na ? dx * 0.7 : 0;
  const xTop = j => 155 - ((m - 1) * dx + gapA) / 2 + j * dx + (j >= na ? gapA : 0), xMid = k => 155 - (m - 1) * dx / 2 + k * dx, xBot = k => 155 - (keep.length - 1) * dx / 2 + k * dx;
  const yT = 58, yM = 124, yB = 192, rr = 9.5, zero = v.s === 0;
  const tok = (x, y, g, key, dim) => <g key={key}><circle cx={r1(x)} cy={y} r={rr} className="on-panel" style={{ stroke: dim ? 'var(--muted)' : 'var(--fg)', strokeWidth: 1.2 }} /><text x={r1(x)} y={y + 4} textAnchor="middle" className={'t-mono t-small' + (dim ? ' t-muted' : '')}>{g + 1}</text></g>;
  const signLine = `(−1)${sup(N)}${caps.map(c => ' · ' + (c.eps < 0 ? '(−1)' : c.eps > 0 ? '(+1)' : '0')).join('')} = ${v.s > 0 ? '+1' : v.s < 0 ? '−1' : '0'}`;
  const eq = research
    ? `${v.labels.a.clifford} · ${v.labels.b.clifford} = ${zero ? '0' : signTxt(v.s) + v.labels.k.clifford}`
    : `${digits(v.word.a)}  ·  ${digits(v.word.b)}  =  ${zero ? '0' : signTxt(v.s) + ' ' + digits(v.word.k)}`;
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views" row={row} part="Clifford view" viewBox={VB}>
        <text x={8} y={16} className="t-small t-muted">Clifford</text>
        {research && <text x={302} y={16} textAnchor="end" className="t-mono t-small">{signLine}</text>}
        {research && na > 0 && <text x={r1((xTop(0) + xTop(na - 1)) / 2)} y={yT - 17} textAnchor="middle" className="t-mono t-small t-muted">{v.labels.a.clifford}</text>}
        {research && m > na && <text x={r1((xTop(na) + xTop(m - 1)) / 2)} y={yT - 17} textAnchor="middle" className="t-mono t-small t-muted">{v.labels.b.clifford}</text>}
        {T.map((t, j) => <line key={'s' + j} x1={r1(xTop(j))} y1={yT + rr} x2={r1(xMid(pos[j]))} y2={yM - rr} className="stroke-ink" style={{ strokeWidth: 1.4 }} />)}
        {caps.map(c => { const x1 = xMid(c.k), x2 = xMid(c.k + 1); return (
          <g key={'c' + c.k}>
            <path d={`M${r1(x1)} ${yM + rr} C${r1(x1)} ${yM + 34}, ${r1(x2)} ${yM + 34}, ${r1(x2)} ${yM + rr}`} className="stroke-ink" style={{ strokeWidth: 1.4 }} />
            <text x={r1((x1 + x2) / 2)} y={yM + 46} textAnchor="middle" className="t-mono t-tiny">{research ? `${gname(c.g, true)}² = ${epsTxt(c.eps)}` : epsTxt(c.eps)}</text>
          </g>); })}
        {keep.map((k, i) => <line key={'d' + k} x1={r1(xMid(k))} y1={yM + rr} x2={r1(xBot(i))} y2={yB - rr} className={zero ? 'stroke-muted' : 'stroke-ink'} style={{ strokeWidth: 1.4 }} />)}
        {T.map((t, j) => tok(xTop(j), yT, t.g, 't' + j))}
        {sorted.map((t, k) => tok(xMid(k), yM, t.g, 'm' + k))}
        {keep.map((k, i) => tok(xBot(i), yB, sorted[k].g, 'b' + k, zero))}
        {m === 0 && <text x={155} y={yM + 4} textAnchor="middle" className="t-mono t-small t-muted">1 · 1 = 1</text>}
        <text x={155} y={230} textAnchor="middle" className="t-mono t-small t-bold">{eq}</text>
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- simplex: labels as faces
function simplexPts(n, R) {
  if (n === 1) return [[0, 0]];
  if (n === 2) return [[-R, 0], [R, 0]];
  if (n === 4) return [[0, -R], [-R * 0.95, R * 0.62], [R * 0.95, R * 0.62], [R * 0.28, R * 0.02]];
  return Array.from({ length: n }, (_, k) => [R * Math.cos(-Math.PI / 2 + 2 * Math.PI * k / n), R * Math.sin(-Math.PI / 2 + 2 * Math.PI * k / n)]);
}
function hull(P) {   // monotone chain, for at most five points
  const pts = [...P].sort((a, b) => a[0] - b[0] || a[1] - b[1]); if (pts.length < 3) return pts;
  const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = [];
  for (const p of pts) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }
  for (const p of [...pts].reverse()) { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); }
  return lo.slice(0, -1).concat(up.slice(0, -1));
}
function Mini({ cx, cy, n, mask, shared, research }) {
  const P = simplexPts(n, n === 2 ? 32 : 37).map(([x, y]) => [cx + x, cy + y]), idx = [...Array(n).keys()], inM = i => (mask >> i) & 1;
  const face = idx.filter(inM).map(i => P[i]), H = face.length >= 3 ? hull(face) : null;
  return (
    <g>
      {idx.flatMap(i => idx.filter(j => j > i).map(j => <line key={i + '-' + j} x1={r1(P[i][0])} y1={r1(P[i][1])} x2={r1(P[j][0])} y2={r1(P[j][1])} className="hair" />))}
      {H && <polygon points={H.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ')} className="ink" style={{ fillOpacity: 0.14 }} />}
      {face.length === 2 && <line x1={r1(face[0][0])} y1={r1(face[0][1])} x2={r1(face[1][0])} y2={r1(face[1][1])} className="stroke-ink" style={{ strokeWidth: 3 }} />}
      {idx.map(i => <g key={'v' + i}>
        {(shared >> i) & 1 ? <circle cx={r1(P[i][0])} cy={r1(P[i][1])} r={8} className="stroke-ink" style={{ strokeWidth: 1 }} /> : null}
        <circle cx={r1(P[i][0])} cy={r1(P[i][1])} r={inM(i) ? 4.5 : 3.2} className={inM(i) ? 'ink' : 'on-panel'} style={inM(i) ? undefined : { stroke: 'var(--muted)', strokeWidth: 1 }} />
        <text x={r1(cx + (P[i][0] - cx) * 1.32 + (n === 1 ? 10 : 0))} y={r1(cy + (P[i][1] - cy) * 1.32 + 3 + (n <= 2 ? -10 : 0))} textAnchor="middle" className="t-mono t-tiny t-muted">{i + 1}</text>
      </g>)}
      {mask === 0 && research && <text x={cx} y={cy + 4} textAnchor="middle" className="t-small t-muted">∅</text>}
    </g>
  );
}
function SimplexPanel({ v, research, row, isLens }) {
  const cy = 112;
  const eq = research ? `${v.labels.a.set} △ ${v.labels.b.set} = ${v.labels.k.set}` : `${digits(v.word.a)}  ·  ${digits(v.word.b)}  =  ${digits(v.word.k)}`;
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views" row={row} part="simplex view" viewBox={VB}>
        <text x={8} y={16} className="t-small t-muted">Simplex</text>
        <Mini cx={52} cy={cy} n={v.n} mask={v.a} shared={v.shared} research={research} />
        <text x={103.5} y={cy + 5} textAnchor="middle" className="t-head">·</text>
        <Mini cx={155} cy={cy} n={v.n} mask={v.b} shared={v.shared} research={research} />
        <text x={206} y={cy + 5} textAnchor="middle" className="t-head">=</text>
        <Mini cx={258} cy={cy} n={v.n} mask={v.k} shared={0} research={research} />
        <text x={155} y={230} textAnchor="middle" className="t-mono t-small t-bold">{eq}</text>
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- cube: labels as corners, the product as a walk
const AXV = { 1: [[200, 0]], 2: [[150, 0], [0, -120]], 3: [[120, 0], [0, -100], [62, -50]], 4: [[80, 0], [0, -62], [36, -30], [118, 54]], 5: [[40, 0], [0, -38], [20, -17], [112, 16], [8, 94]] };
const BASE = { 1: [55, 120], 2: [80, 186], 3: [58, 186], 4: [40, 126], 5: [50, 92] };
const CP = (m, n) => { let [x, y] = BASE[n]; AXV[n].forEach((d, i) => { if ((m >> i) & 1) { x += d[0]; y += d[1]; } }); return [x, y]; };
function CubePanel({ v, research, row, isLens }) {
  const n = v.n, N = 1 << n, edges = [];
  for (let m = 0; m < N; m++) for (let i = 0; i < n; i++) if (!((m >> i) & 1)) edges.push([m, m | (1 << i), i]);
  const bits = m => label(m, 'bits', v.eps), allLabels = n <= 3;
  const eq = research ? `${bits(v.a)} ⊕ ${bits(v.b)} = ${bits(v.k)}` : `${bits(v.a)} XOR ${bits(v.b)} = ${bits(v.k)}`;
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views" row={row} part="cube view" viewBox={VB}>
        <text x={8} y={16} className="t-small t-muted">Cube</text>
        {edges.map(([x, y, i]) => { const P = CP(x, n), Q = CP(y, n); return <line key={x + '-' + y} x1={P[0]} y1={P[1]} x2={Q[0]} y2={Q[1]} className="hair" style={{ strokeWidth: n >= 4 && i >= 3 ? 0.7 : 1 }} />; })}
        {v.path.slice(1).map((m, i) => { const P = CP(v.path[i], n), Q = CP(m, n), ax = Math.log2(v.path[i] ^ m); return (
          <g key={'w' + i}>
            <line x1={P[0]} y1={P[1]} x2={Q[0]} y2={Q[1]} className="stroke-ink" style={{ strokeWidth: 3, strokeLinecap: 'round' }} />
            <path d={arrowHead(P[0], P[1], (P[0] + Q[0]) / 2 + (Q[0] - P[0]) * 0.08, (P[1] + Q[1]) / 2 + (Q[1] - P[1]) * 0.08, 7)} className="ink" />
            {(() => { const dx = Q[0] - P[0], dy = Q[1] - P[1], L = Math.hypot(dx, dy) || 1; let nx = -dy / L, ny = dx / L; if (ny > 0 || (ny === 0 && nx > 0)) { nx = -nx; ny = -ny; } return <text x={r1((P[0] + Q[0]) / 2 + nx * 11)} y={r1((P[1] + Q[1]) / 2 + ny * 11 + 3)} textAnchor="middle" className="t-mono t-tiny">{gname(ax, research)}</text>; })()}
          </g>); })}
        {Array.from({ length: N }, (_, m) => { const P = CP(m, n), isA = m === v.a, isK = m === v.k; return (
          <g key={'v' + m}>
            <circle cx={P[0]} cy={P[1]} r={isK ? 5.5 : isA ? 4.5 : 2.4} className={isK || isA ? 'ink' : 'ink-muted'} />
            {isA && <circle cx={P[0]} cy={P[1]} r={8.5} className="stroke-ink" style={{ strokeWidth: 1.4 }} />}
            {(allLabels || isA || isK) && <text x={P[0]} y={P[1] - (isA || isK ? 12 : 7)} textAnchor="middle" className={'t-mono ' + (isA || isK ? 't-small t-bold' : 't-tiny t-muted')}>{bits(m)}</text>}
          </g>); })}
        <text x={155} y={230} textAnchor="middle" className="t-mono t-small t-bold">{eq}</text>
        <desc>{`walk ${v.path.map(bits).join(' → ')}`}</desc>
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- prime: labels as square-free products
function PrimePanel({ v, research, row, isLens }) {
  const n = v.n, colX = i => (n <= 1 ? 150 : 74 + i * Math.min(48, 176 / (n - 1))), rowsY = { a: 58, b: 104, k: 176 };
  const P = i => PRIMES[i];
  const chip = (i, y, key, strong) => <g key={key}><rect x={r1(colX(i) - 15)} y={y - 13} width={30} height={20} rx={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: strong ? 1.6 : 1 }} /><text x={r1(colX(i))} y={y + 2} textAnchor="middle" className="t-mono t-small">{P(i)}</text></g>;
  const lab = m => label(m, 'primes', v.eps), G = v.prime.G;
  const eq = research
    ? `${lab(v.a)} × ${lab(v.b)} = ${G > 1 ? (v.sharedIdx.length === 1 ? `${lab(v.shared)}² · ` : `(${lab(v.shared)})² · `) : ''}${lab(v.k)}`
    : `${v.prime.A} × ${v.prime.B} = ${v.prime.A * v.prime.B}${G > 1 ? ` = ${G * G} × ${v.prime.K}` : ''}`;
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id="four-views" row={row} part="prime view" viewBox={VB}>
        <text x={8} y={16} className="t-small t-muted">Prime</text>
        {[['a', v.a, v.prime.A], ['b', v.b, v.prime.B], ['k', v.k, v.prime.K]].map(([key, m, val]) => (
          <g key={'r' + key}>
            <text x={18} y={rowsY[key] + 2} className="t-mono t-small t-muted">{key === 'k' ? (research ? 'ab' : '=') : key}</text>
            <text x={302} y={rowsY[key] + 2} textAnchor="end" className="t-mono t-small t-bold">{val}</text>
            {[...Array(n).keys()].filter(i => (m >> i) & 1).map(i => chip(i, rowsY[key], key + i, key === 'k'))}
          </g>
        ))}
        {v.sharedIdx.map(i => (
          <g key={'g' + i}>
            <line x1={colX(i)} y1={rowsY.a + 7} x2={colX(i)} y2={rowsY.b - 13} className="stroke-ink" style={{ strokeWidth: 1.4 }} />
            <text x={colX(i)} y={rowsY.b + 26} textAnchor="middle" className="t-mono t-tiny">{research ? `${P(i)}² → ${epsTxt(v.eps[i])}` : `${P(i)}×${P(i)}`}</text>
          </g>
        ))}
        <line x1={40} y1={rowsY.b + 40} x2={290} y2={rowsY.b + 40} className="hair" />
        <text x={155} y={230} textAnchor="middle" className="t-mono t-small t-bold">{eq}</text>
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the figure
const PANELS = { clifford: CliffordPanel, simplex: SimplexPanel, cube: CubePanel, prime: PrimePanel };
const LENS_PANEL = { clifford: 'clifford', tian: 'clifford', simplex: 'simplex', cube: 'cube', prime: 'prime' };

export default function FourViews({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const num = (x, d) => (Number.isInteger(x) && x >= 0 ? x : d);
  const init = () => { let p = num(params.p, 3), q = num(params.q, 0), r = num(params.r, 0); if (p + q + r < 1 || p + q + r > 5) { p = 3; q = 0; r = 0; } const N = 1 << (p + q + r); return { p, q, r, a: num(params.a, 3) & (N - 1), b: num(params.b, 5) & (N - 1) }; };
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.p, params.q, params.r, params.a, params.b]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { p, q, r, a, b } = st, n = p + q + r;
  const v = useMemo(() => views(p, q, r, a, b), [p, q, r, a, b]);
  const setCell = (pp, qq, rr) => { const m = pp + qq + rr; if (m < 1 || m > 5) return; const N = (1 << m) - 1; setSt({ p: pp, q: qq, r: rr, a: a & N, b: b & N }); };
  const flip = (key, i) => setSt(s => ({ ...s, [key]: s[key] ^ (1 << i) }));
  const lensPanel = LENS_PANEL[lens] || null, printLens = labelLens(lens) || 'clifford';
  const order = ['clifford', 'simplex', 'cube', 'prime'].sort((x, y) => (x === lensPanel ? -1 : y === lensPanel ? 1 : 0));
  const printed = m => label(m, printLens === 'set' ? 'set' : printLens, v.eps);
  return (
    <div className="fig fig-four-views">
      <div className="fig-panels">
        {order.map(k => { const P = PANELS[k]; return <P key={k} v={v} research={research} row={row} isLens={k === lensPanel} />; })}
      </div>
      {research && (
        <Controls label="product">
          <Stepper label="p" value={p} min={0} max={5 - q - r} onChange={x => setCell(x, q, r)} param="p" />
          <Stepper label="q" value={q} min={0} max={5 - p - r} onChange={x => setCell(p, x, r)} param="q" />
          <Stepper label="r" value={r} min={0} max={5 - p - q} onChange={x => setCell(p, q, x)} param="r" />
          {['a', 'b'].map(key => (
            <span key={key} className="fig-group" role="group" aria-label={`label ${key}`} data-param={key}>
              <span className="fig-group-label">{key}</span>
              {[...Array(n).keys()].map(i => <button key={i} type="button" className="fig-btn fig-btn-sq fig-mono" aria-pressed={!!((st[key] >> i) & 1)} aria-label={`${key}: generator ${i + 1}`} data-param={key} onClick={() => flip(key, i)}>{i + 1}</button>)}
              <span className="fig-num">{printed(st[key])}</span>
            </span>
          ))}
        </Controls>
      )}
    </div>
  );
}
/** the geometry the Maxwell version of this figure shares (FourViewsMaxwell.jsx): simplex vertices, a convex hull, the oblique cube layout */
export { simplexPts, hull, CP as cubePoint, AXV as CUBE_AXES };
FourViews.meta = { id: 'four-views', lenses: ['clifford', 'simplex', 'cube', 'prime', 'tian', 'bits', 'primes', 'sigword', 'bitsq'], learner: true };
/** the numbers the figure draws, for the frame's data download */
FourViews.data = (params = {}) => { const d = (x, v) => (Number.isInteger(x) && x >= 0 ? x : v); return views(d(params.p, 3), d(params.q, 0), d(params.r, 0), d(params.a, 3), d(params.b, 5)); };
