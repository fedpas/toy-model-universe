// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure gauss-sum: the sum of i^w over the 2^n blades of Cl(p,q), w = π + 2Q with the squares read from the kernel (engines/labels.js gaussPath, core·B1–B3),
// drawn as unit arrows added head to tail in the complex plane, blades in counting order. After the first 2^k blades the partial sum is the sum of the first k
// generators (a dot, numbered k); the last arrow, from 0 to the sum, carries the colour of the cell's clock c with its printed "c = n". Paused until play.
import React, { useState, useEffect, useMemo } from 'react';
import { gaussPath } from '../../engines/labels.js';
import { FigSvg, clockVar, Controls, Stepper, PlayButton, usePlayer, arrowHead, r1 } from './kit.jsx';
import { gaussText } from './ClockWheel.jsx';

const SIZE = 340, PAD = 28;

export default function GaussSum({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const valid = (pp, qq) => Number.isInteger(pp) && Number.isInteger(qq) && pp >= 0 && qq >= 0 && pp + qq <= 8;
  const init = valid(params.p, params.q) ? [params.p, params.q] : [3, 1];
  const [[p, q], setPQ] = useState(init);
  useEffect(() => { if (valid(params.p, params.q)) setPQ([params.p, params.q]); }, [params.p, params.q]);   // eslint-disable-line react-hooks/exhaustive-deps
  const G = useMemo(() => gaussPath(p, q), [p, q]);
  const total = G.steps.length, stops = G.milestones.map(m => 1 << m.k);
  const player = usePlayer(total, { ms: Math.max(16, Math.min(140, Math.round(3200 / total))), stops, resetKey: `${p},${q}` });
  const f = player.frame;
  // the frame: every partial sum and the origin, equal scales on both axes
  const xs = [0, ...G.steps.map(s => s.x)], ys = [0, ...G.steps.map(s => s.y)];
  const minX = Math.min(...xs) - 0.6, maxX = Math.max(...xs) + 0.6, minY = Math.min(...ys) - 0.6, maxY = Math.max(...ys) + 0.6;
  const s = Math.min((SIZE - 2 * PAD) / (maxX - minX), (SIZE - 2 * PAD) / (maxY - minY));
  const ox = PAD + ((SIZE - 2 * PAD) - (maxX - minX) * s) / 2, oy = PAD + ((SIZE - 2 * PAD) - (maxY - minY) * s) / 2;
  const X = x => r1(ox + (x - minX) * s), Y = y => r1(oy + (maxY - y) * s);
  const heads = total <= 32, done = f >= total, cur = f > 0 ? G.steps[f - 1] : null;
  const grid = [];
  if (s >= 12) { for (let x = Math.ceil(minX); x <= Math.floor(maxX); x++) grid.push(<line key={'gx' + x} x1={X(x)} y1={Y(maxY)} x2={X(x)} y2={Y(minY)} className="hair-2" />); for (let y = Math.ceil(minY); y <= Math.floor(maxY); y++) grid.push(<line key={'gy' + y} x1={X(minX)} y1={Y(y)} x2={X(maxX)} y2={Y(y)} className="hair-2" />); }
  const [sx, sy] = G.sum;
  return (
    <div className="fig fig-gauss-sum">
      <FigSvg id="gauss-sum" row={row} viewBox={`0 0 ${SIZE} ${SIZE + (research ? 30 : 8)}`}>
        {grid}
        <line x1={X(minX)} y1={Y(0)} x2={X(maxX)} y2={Y(0)} className="hair" />
        <line x1={X(0)} y1={Y(minY)} x2={X(0)} y2={Y(maxY)} className="hair" />
        {research && <text x={X(maxX) + 2} y={Y(0) + 4} className="t-small t-muted">Re</text>}
        {research && <text x={X(0)} y={Y(maxY) - 6} textAnchor="middle" className="t-small t-muted">Im</text>}
        {G.steps.slice(0, f).map(st => (
          <g key={st.a}>
            <line x1={X(st.x0)} y1={Y(st.y0)} x2={X(st.x)} y2={Y(st.y)} className="stroke-muted" style={{ strokeWidth: total > 64 ? 1.2 : 1.6, strokeLinecap: 'round' }} />
            {heads && <path d={arrowHead(X(st.x0), Y(st.y0), X(st.x), Y(st.y), 5)} className="ink-muted" />}
          </g>
        ))}
        {done && (
          <g>
            <line x1={X(0)} y1={Y(0)} x2={X(sx)} y2={Y(sy)} style={{ stroke: clockVar(G.c), strokeWidth: 2.5, strokeLinecap: 'round' }} />
            <path d={arrowHead(X(0), Y(0), X(sx), Y(sy), 9)} style={{ fill: clockVar(G.c) }} />
            {(() => { const dx = X(sx) - X(0), dy = Y(sy) - Y(0), L = Math.hypot(dx, dy) || 1; let nx = -dy / L, ny = dx / L; if (nx > 0 || (nx === 0 && ny > 0)) { nx = -nx; ny = -ny; } const lx = X(0) + dx * 0.5 + nx * 14, ly = Y(0) + dy * 0.5 + ny * 14; return <text x={r1(lx)} y={r1(ly + 4)} textAnchor={nx < -0.3 ? 'end' : nx > 0.3 ? 'start' : 'middle'} className="t-mono t-small t-bold">{`c = ${G.c}`}</text>; })()}
          </g>
        )}
        {G.milestones.filter(m => (1 << m.k) <= f).map(m => (
          <g key={'m' + m.k}>
            <circle cx={X(m.x)} cy={Y(m.y)} r={4} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 2 }} />
            {research && <text x={X(m.x) + 6} y={Y(m.y) - 6} className="t-mono t-tiny t-muted">{m.k}</text>}
          </g>
        ))}
        {cur && !done && <circle cx={X(cur.x)} cy={Y(cur.y)} r={5} className="stroke-ink" style={{ strokeWidth: 2 }} />}
        <circle cx={X(0)} cy={Y(0)} r={2.5} className="ink" />
        {research && <text x={SIZE / 2} y={SIZE + 20} textAnchor="middle" className="t-mono t-small">{`Cl(${p},${q}) · ${total} blades · Σ iʷ = ${done ? gaussText(sx, sy) : '…'}`}</text>}
      </FigSvg>
      <Controls label="Gauss sum">
        <PlayButton player={player} />
        {research && <Stepper label="p" value={p} min={0} max={8 - q} onChange={v => setPQ([v, q])} param="p" />}
        {research && <Stepper label="q" value={q} min={0} max={8 - p} onChange={v => setPQ([p, v])} param="q" />}
      </Controls>
    </div>
  );
}
GaussSum.meta = { id: 'gauss-sum', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
GaussSum.data = (params = {}) => { const G = gaussPath(Number.isInteger(params.p) ? params.p : 3, Number.isInteger(params.q) ? params.q : 1); return { cell: [G.p, G.q], blades: G.steps.map(({ a, w }) => ({ a, w })), sum: G.sum, milestones: G.milestones, c: G.c }; };
