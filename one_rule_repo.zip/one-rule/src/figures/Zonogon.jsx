// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure zonogon (shapes, step 2): the n-cube projected with the edge vectors (cos πi/n, sin πi/n) — its shadow is the 2n-gon — split into its even corners, the
// n-demicube (the even blades), and its odd corners (engines/labels.js zonogon; the parity and the grade of a corner are the kernel's popcount of its label).
// Demicube lens (default): the edges of the demicube, between even corners that differ in two bits; an even corner is a filled dot whose darkness steps with its grade
// (0, 2, 4, 6, 8: the legend counts them), an odd corner a hollow ring — v15 coloured the grades, the design keeps colour for the clock. Cube lens: the edges of the
// n-cube instead, and for n ≤ 4 each corner's label printed in bits. The control is v15's: the chips n = 3 … 8 (interactive entry n). Port of v15 ShapesSection.Zonogon.
import React, { useState, useEffect, useMemo } from 'react';
import { zonogon, label } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, r1, pick, isIn } from './kit.jsx';

const NS = [3, 4, 5, 6, 7, 8];
const SHADE = { 0: 0.22, 2: 0.42, 4: 0.62, 6: 0.82, 8: 1 };

export default function Zonogon({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [n, setN] = useState(pick(params.n, isIn(NS), 5));
  useEffect(() => { setN(pick(params.n, isIn(NS), 5)); }, [params.n]);
  const Z = useMemo(() => zonogon(n), [n]), cube = lens === 'cube';
  const xs = Z.corners.map(c => c.x), ys = Z.corners.map(c => c.y), cx = (Math.min(...xs) + Math.max(...xs)) / 2, cy = (Math.min(...ys) + Math.max(...ys)) / 2;
  const half = Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys)) / 2 || 1, W = 320, O = 160, S = 140;
  const P = Z.corners.map(c => [r1(O + (c.x - cx) / half * S), r1(O - (c.y - cy) / half * S)]);
  const r = n > 6 ? 2.4 : n > 4 ? 3.2 : 4.6, grades = Object.keys(Z.byGrade).map(Number).sort((a, b) => a - b);
  const edges = cube ? Z.cubeEdges : Z.edges, thin = n > 6 ? 0.35 : 0.8;
  const H = W + 40;
  return (
    <div className="fig fig-zonogon">
      <FigSvg id="zonogon" row={row} viewBox={`0 0 ${W} ${H}`}>
        <g data-n={n} data-lens={cube ? 'cube' : 'demicube'}>
          {edges.map(([a, b]) => <line key={a + '-' + b} x1={P[a][0]} y1={P[a][1]} x2={P[b][0]} y2={P[b][1]} className="stroke-muted" style={{ strokeWidth: thin, strokeOpacity: n > 6 ? 0.5 : 0.7 }} data-edge={`${a},${b}`} />)}
          {Z.corners.filter(c => !c.even).map(c => (
            <circle key={c.m} cx={P[c.m][0]} cy={P[c.m][1]} r={r} className="on-panel" style={{ stroke: 'var(--muted)', strokeWidth: 0.9 }} data-odd={c.m}>
              <title>{research ? `odd blade ${label(c.m, 'clifford')} (label ${c.m})` : `odd corner ${label(c.m, 'bits', Array(n).fill(1))}`}</title>
            </circle>
          ))}
          {Z.corners.filter(c => c.even).map(c => (
            <circle key={c.m} cx={P[c.m][0]} cy={P[c.m][1]} r={r} className="ink" style={{ fillOpacity: SHADE[c.grade], stroke: 'var(--fg)', strokeWidth: 0.6 }} data-mask={c.m} data-grade={c.grade}>
              <title>{research ? `even blade ${label(c.m, 'clifford')} (label ${c.m}, grade ${c.grade})` : `even corner ${label(c.m, 'bits', Array(n).fill(1))}, ${c.grade} ones`}</title>
            </circle>
          ))}
          {cube && n <= 4 && Z.corners.map(c => <text key={'t' + c.m} x={P[c.m][0] + 7} y={P[c.m][1] - 6} className="t-mono t-micro">{label(c.m, 'bits', Array(n).fill(1))}</text>)}
        </g>
        <g transform={`translate(10, ${W + 16})`} data-legend="grades">
          <text x={0} y={0} className="t-small t-muted">{research ? 'grade' : 'ones'}</text>
          {grades.map((g, i) => (
            <g key={g} transform={`translate(${44 + i * 54}, 0)`} data-grade-count={`${g},${Z.byGrade[g]}`}>
              <circle cx={4} cy={-4} r={4} className="ink" style={{ fillOpacity: SHADE[g], stroke: 'var(--fg)', strokeWidth: 0.6 }} />
              <text x={11} y={0} className="t-small t-mono">{`${g}: ${Z.byGrade[g]}`}</text>
            </g>
          ))}
          <text x={0} y={20} className="t-tiny t-muted">{research
            ? `${Z.evenLabels.length} even corners · ${cube ? `${Z.cubeEdges.length} edges of the cube` : `${Z.edges.length} edges of the demicube`} · ${1 << (n - 1)} odd corners (hollow)`
            : `${Z.evenLabels.length} even corners (filled), ${1 << (n - 1)} odd (hollow)`}</text>
        </g>
      </FigSvg>
      <Controls label="cube">
        <Chips label="n" items={NS} value={n} onPick={setN} param="n" mono />
      </Controls>
    </div>
  );
}
Zonogon.meta = { id: 'zonogon', lenses: ['demicube', 'cube'], learner: true };
/** the numbers the figure draws, for the frame's data download */
Zonogon.data = (params = {}) => { const Z = zonogon(pick(params.n, isIn(NS), 5)); return { n: Z.n, evenLabels: Z.evenLabels, edges: Z.edges, byGrade: Z.byGrade, byPair: Z.byPair, corners: Z.corners.map(c => ({ m: c.m, x: c.x, y: c.y, grade: c.grade })) }; };
