// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure bands (step 15 and the Schuller chapter): allowed and forbidden energies. The one-period matrix M of ψ″ = (V − E)ψ is a unit multivector of Cl(2,0) = M₂(ℝ),
// M = g + X with g = ½ tr M and X² = g² − 1: a band where X² < 0 (|½ tr M| < 1), a gap where X² > 0, an edge between (engines/schullerEngine.js: the comb cell as the
// kernel's product of a kick and a flight, combCell, against its closed form cos kl + (g/2k) sin kl; the edges by bisection, bandEdges — floating point, the numbers
// lens_sch_check.py stores for every slider position, P2, compared by tests/engines.test.mjs to 1e−7). The curve is ½ tr M against E, the shaded stripes the bands,
// the dashed strip |½ tr M| ≤ 1, the dots the edges, the heavy line the chosen energy. Modes, as in v15: the Dirac comb (kick g, spacing l) or the two-step potential
// of fibre·G5e; v15's third mode (exact SL(2,ℤ) words) shows no picture and is left to the drawer. The controls are v15's: the mode, the kick, the spacing and the
// energy (research level). Port of v15 SchullerWidgets.SW5.
import React, { useState, useEffect, useMemo } from 'react';
import { halfTraceComb, halfTraceSteps, bandEdges, combCell, floquetClass, G5_CELL } from '../../engines/schullerEngine.js';
import { LENS_SCH } from '../../engines/stored.js';
import { FigSvg, Controls, Chips, Range, r1, pick, isIn } from './kit.jsx';

export const COMB_E = LENS_SCH.p2.comb_E;   // [lo, hi, steps] of the stored edges
const CLS = { band: ['band: X² < 0', 'allowed (a band)'], gap: ['gap: X² > 0', 'forbidden (a gap)'], edge: ['edge: X² = 0', 'the edge'] };
const EDGES = new Map();
/** the band edges of the comb (g, l) or of the two-step cell, cached */
export function edgesOf(mode, g, l) {
  const key = mode === 'g5' ? 'g5' : `${g},${l}`;
  if (!EDGES.has(key)) EDGES.set(key, mode === 'g5' ? bandEdges(e => halfTraceSteps(e, G5_CELL), 0.05, 90, 18000) : bandEdges(e => halfTraceComb(e, g, l), ...COMB_E));
  return EDGES.get(key);
}
const fmt = (x, d) => { const v = Math.abs(x) < 0.5 * 10 ** -d ? 0 : x; return v.toFixed(d).replace('-', '−'); };

export default function Bands({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [mode, setMode] = useState(research && params.mode === 'g5' ? 'g5' : 'comb');
  const [g, setG] = useState(Number.isFinite(params.g) ? params.g : 2), [l, setL] = useState(Number.isFinite(params.l) ? params.l : 1), [En, setEn] = useState(Number.isFinite(params.E) ? params.E : 8);
  useEffect(() => { setMode(research && params.mode === 'g5' ? 'g5' : 'comb'); }, [params.mode, research]);
  const isG5 = mode === 'g5', f = isG5 ? (e => halfTraceSteps(e, G5_CELL)) : (e => halfTraceComb(e, g, l)), lo = isG5 ? 0.05 : COMB_E[0], hi = isG5 ? 60 : COMB_E[1];
  const edges = useMemo(() => edgesOf(mode, g, l), [mode, g, l]), E0 = Math.max(lo, Math.min(hi, En));
  const cc = combCell(E0, g, l), half = isG5 ? f(E0) : cc.half, x2 = half * half - 1, cls = floquetClass(half);
  const W = 420, PH = 190, px = e => 30 + (e - lo) / (hi - lo) * (W - 40), py = v => PH / 2 - Math.max(-3, Math.min(3, v)) * (PH / 2 - 12) / 3;
  const pts = useMemo(() => { const out = []; for (let i = 0; i <= 400; i++) { const e = lo + (hi - lo) * i / 400; out.push(`${r1(px(e))},${r1(py(f(e)))}`); } return out.join(' '); }, [mode, g, l]);   // eslint-disable-line react-hooks/exhaustive-deps
  const bnd = [lo, ...edges.filter(e => e > lo && e < hi), hi], bands = []; for (let i = 0; i + 1 < bnd.length; i++) { const mid = (bnd[i] + bnd[i + 1]) / 2; if (Math.abs(f(mid)) <= 1) bands.push([bnd[i], bnd[i + 1]]); }
  const step = (hi - lo) > 70 ? 20 : 10, ticks = []; for (let e = Math.ceil(lo / step) * step; e <= hi; e += step) ticks.push(e);
  const H = research ? 262 : 232;
  return (
    <div className="fig fig-bands">
      <FigSvg id="bands" row={row} viewBox={`0 0 ${W} ${H}`}>
        <g data-mode={mode} data-edges={edges.map(e => e.toFixed(9)).join(',')}>
          {bands.map(([a, b], i) => <rect key={i} x={r1(px(a))} y={8} width={r1(Math.max(1, px(b) - px(a)))} height={PH - 16} className="ink" style={{ fillOpacity: 0.1 }} data-band={`${a.toFixed(3)},${b.toFixed(3)}`} />)}
          <rect x={30} y={r1(py(1))} width={W - 40} height={r1(py(-1) - py(1))} className="stroke-muted" style={{ strokeDasharray: '4 3' }} />
          <line x1={30} y1={PH / 2} x2={W - 10} y2={PH / 2} className="hair" />
          {lo < 0 && hi > 0 && <line x1={r1(px(0))} y1={8} x2={r1(px(0))} y2={PH - 8} className="hair" />}
          <polyline points={pts} className="stroke-ink" style={{ strokeWidth: 1.6 }} />
          {edges.filter(e => e >= lo && e <= hi).map((e, i) => <circle key={i} cx={r1(px(e))} cy={r1(py(f(e)))} r={3} className="ink" data-edge={e} />)}
          <line x1={r1(px(E0))} y1={6} x2={r1(px(E0))} y2={PH - 6} className="stroke-ink" style={{ strokeWidth: 2 }} data-e={E0} data-class={cls} />
          <path d={`M${r1(px(E0) - 5)},${PH - 2} l5,-8 l5,8 z`} className="ink" />
          {ticks.map(e => <text key={e} x={r1(px(e))} y={PH + 14} textAnchor="middle" className="t-mono t-micro t-muted">{String(e).replace('-', '−')}</text>)}
          <text x={4} y={r1(py(1) + 4)} className="t-mono t-micro t-muted">1</text><text x={4} y={r1(py(-1) + 4)} className="t-mono t-micro t-muted">−1</text>
          <text x={W - 10} y={16} textAnchor="end" className="t-tiny t-muted">{research ? 'E → · ½ tr M' : 'energy →'}</text>
        </g>
        <text x={4} y={PH + 34} className="t-small t-bold">{research ? `E = ${fmt(E0, 2)}: ${CLS[cls][0]}` : `Energy ${fmt(E0, 2)}: ${CLS[cls][1]}`}</text>
        {research && <text x={4} y={PH + 50} className="t-mono t-tiny" data-half={half}>{`½ tr M = ${fmt(half, 6)}${isG5 ? '' : ` (closed form ${fmt(cc.closed, 6)})`} · X² = ${fmt(x2, 6)}`}</text>}
        {research && <text x={4} y={PH + 66} className="t-mono t-micro t-muted">{`${edges.length} edges: ${edges.map(e => fmt(e, 3)).join('; ')}`}</text>}
      </FigSvg>
      <Controls label="bands">
        {research && <Chips label="mode" items={['comb', 'g5']} value={mode} onPick={setMode} render={m => (m === 'comb' ? 'Dirac comb' : 'two-step potential')} param="mode" />}
        {research && !isG5 && <Range label="kick g" value={g} min={-4} max={4} step={0.5} onChange={setG} display={v => fmt(v, 1)} param="g" />}
        {research && !isG5 && <Range label="spacing l" value={l} min={0.5} max={2} step={0.25} onChange={setL} display={v => fmt(v, 2)} param="l" />}
        {research && <Range label="E" value={E0} min={isG5 ? 0 : lo} max={hi} step={0.25} onChange={setEn} display={v => fmt(v, 2)} param="E" />}
      </Controls>
    </div>
  );
}
Bands.meta = { id: 'bands', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
Bands.data = (params = {}) => { const g = Number.isFinite(params.g) ? params.g : 2, l = Number.isFinite(params.l) ? params.l : 1, mode = params.mode === 'g5' ? 'g5' : 'comb'; return { mode, g, l, edges: edgesOf(mode, g, l), window: mode === 'g5' ? [0.05, 60] : COMB_E.slice(0, 2) }; };
