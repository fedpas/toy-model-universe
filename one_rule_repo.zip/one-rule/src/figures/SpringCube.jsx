// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spring-cube (step 15): the normal modes of the spring network on the n-cube (engines/springEngine.js modes; levels and counts compared with
// checks/selfcheck/spring.json by tests/engines.test.mjs). Every label s is a mode: the masses at the corners x move with the sign (−1)^{|x ∧ s|} (filled +, ring −),
// at ω² = 2|s|; the 2^n modes stand in columns by their level |s|, C(n, j) in a column (1, 3, 3, 1 for the 3-cube). Lenses print the labels: cube / bits as bit
// strings (default at research level), prime / primes as products of primes. Under them, v15's moving cube with its controls: n = 2, 3, 4, a mode (its bits) or a
// pluck (one mass let go; its energy, springs plus motion, stays what it was at t = 0), the time t (a slider at research level) and play (paused until pressed).
// The masses are drawn filled where they are up and as rings where they are down. Port of v15 SpringWidgets.jsx (CubeSprings, Spectra).
import React, { useMemo, useState, useEffect } from 'react';
import { modes, project, mode, pluck, pluckVel, springEnergy, kinetic, binom, bits as bitStr } from '../../engines/springEngine.js';
import { label } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, Range, PlayButton, useReducedMotion, r1, labelLens } from './kit.jsx';

const nOf = params => (Number.isInteger(params.n) && params.n >= 1 && params.n <= 4 ? params.n : 3);

export default function SpringCube({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [n, setN0] = useState(nOf(params));
  useEffect(() => { setN0(nOf(params)); }, [params.n]);   // eslint-disable-line react-hooks/exhaustive-deps
  const [view, setView] = useState(params.view === 'pluck' ? 'pluck' : 'mode'), [sm, setS] = useState(1), [vv0, setV] = useState(0);
  const [tt, setTt] = useState(0), [playing, setPlaying] = useState(false), reduced = useReducedMotion();
  useEffect(() => { if (!playing || reduced) return undefined; const id = setInterval(() => setTt(x => (x + 1) % 101), 70); return () => clearInterval(id); }, [playing, reduced]);
  const player = { playing, reduced, play: () => setPlaying(on => !on), step: () => setTt(x => (x + 10) % 101) };
  const setN = k => { setN0(k); setS(1); setV(0); setTt(0); };
  const M = useMemo(() => modes(n), [n]);
  const L = labelLens(lens), lab = s => label(s, L === 'primes' ? 'primes' : L === 'clifford' ? 'clifford' : 'bits', Array(n).fill(1));
  const cols = M.levels.length, maxCol = Math.max(...M.levels.map(l => l.mult)), W = 420, cw = Math.min(100, (W - 20) / cols), x0 = (W - cw * cols) / 2;
  const k = n <= 3 ? 24 : 18, raw = Array.from({ length: 1 << n }, (_, x) => project(n, x, k)), xs = raw.map(p => p[0]), ys = raw.map(p => p[1]);
  const bw = Math.max(...xs) - Math.min(...xs), bh = Math.max(...ys) - Math.min(...ys), cellH = bh + 30, top = 34, H = top + maxCol * cellH + (research ? 24 : 6);
  const at = (cx, cy) => raw.map(([x, y]) => [cx - bw / 2 + (x - Math.min(...xs)), cy - bh / 2 + (y - Math.min(...ys))]);
  return (
    <div className="fig fig-spring-cube">
      <FigSvg id="spring-cube" row={row} viewBox={`0 0 ${W} ${H}`}>
        {M.levels.map((l, j) => <text key={'h' + j} x={r1(x0 + j * cw + cw / 2)} y={18} textAnchor="middle" className="t-mono t-small">{research ? `ω² = ${l.w2}` : `level ${j}`}</text>)}
        {M.levels.map((l, j) => { const list = M.modes.filter(m => m.level === j); return list.map((m, i) => {
          const cx = x0 + j * cw + cw / 2, cy = top + (maxCol - list.length) * cellH / 2 + i * cellH + bh / 2 + 4, P = at(cx, cy);
          return (
            <g key={m.s} data-mode={m.s} data-level={m.level} data-signs={m.signs.join(',')}>
              {view === 'mode' && m.s === Math.min(sm, (1 << n) - 1) && <rect x={r1(cx - bw / 2 - 8)} y={r1(cy - bh / 2 - 8)} width={r1(bw + 16)} height={r1(bh + (research ? 26 : 16))} rx={5} className="stroke-ink" style={{ strokeWidth: 1.2, strokeDasharray: '3 2' }} />}
              <title>{`mode ${lab(m.s)}: ω² = ${m.w2}; signs at the corners ${m.signs.map(v => (v > 0 ? '+' : '−')).join('')}`}</title>
              {M.edges.map(([a, b]) => <line key={a + '-' + b} x1={r1(P[a][0])} y1={r1(P[a][1])} x2={r1(P[b][0])} y2={r1(P[b][1])} className="hair" />)}
              {P.map(([x, y], v) => <circle key={v} cx={r1(x)} cy={r1(y)} r={3.3} className={m.signs[v] > 0 ? 'ink' : 'on-panel'} style={m.signs[v] > 0 ? undefined : { stroke: 'var(--fg)', strokeWidth: 1.1 }} />)}
              {research && <text x={r1(cx)} y={r1(cy + bh / 2 + 13)} textAnchor="middle" className="t-mono t-micro t-muted">{lab(m.s)}</text>}
            </g>); }); })}
        {research && <text x={10} y={H - 8} className="t-mono t-tiny t-muted">{`n = ${n}: ${M.counts.V} masses, ${M.counts.E} springs · modes by level ${M.levels.map(l => l.mult).join(', ')}`}</text>}
      </FigSvg>
      <MovingCube n={n} view={view} s={Math.min(sm, (1 << n) - 1) || 1} v={Math.min(vv0, (1 << n) - 1)} tt={tt} research={research} row={row} lab={lab} onPluck={i => { setV(i); setTt(0); }} />
      <Controls label="springs">
        <Chips label="n" items={[2, 3, 4]} value={n} onPick={setN} param="n" mono />
        <Chips label={research ? 'view' : 'show'} items={['mode', 'pluck']} value={view} onPick={setView} render={k => (k === 'mode' ? 'a mode' : 'pluck a mass')} param="view" />
        {view === 'mode' && <span className="fig-group" role="group" aria-label="the bits of the mode" data-param="s">
          <span className="fig-group-label">mode</span>
          {Array.from({ length: n }, (_, k) => n - 1 - k).map(i => { const ns = Math.min(sm, (1 << n) - 1) || 1, on = !!((ns >> i) & 1); return <button key={i} type="button" className="fig-btn fig-btn-sq fig-mono" aria-pressed={on} aria-label={`bit ${i + 1}`} data-param="s" onClick={() => setS((ns ^ (1 << i)) || 1)}>{on ? '1' : '0'}</button>; })}
        </span>}
        {research && <Range label="t" value={tt} min={0} max={100} step={1} onChange={setTt} display={x => (x / 10).toFixed(1)} param="t" />}
        <PlayButton player={player} />
      </Controls>
    </div>
  );
}

/** v15's moving cube: one mode s, or the pluck of mass v, at time t = tt / 10 (engines/springEngine.js mode, pluck, pluckVel; energy springEnergy + kinetic) */
function MovingCube({ n, view, s, v, tt, research, row, lab, onPluck }) {
  const tm = tt / 10, x = view === 'mode' ? mode(n, s, tm) : pluck(n, v, tm);
  const E = view === 'pluck' ? springEnergy(n, x) + kinetic(pluckVel(n, v, tm)) : null, E0 = view === 'pluck' ? springEnergy(n, pluck(n, v, 0)) + kinetic(pluckVel(n, v, 0)) : null;
  const U = Array.from({ length: 1 << n }, (_, i) => project(n, i, 1)), ux = U.map(p => p[0]), uy = U.map(p => p[1]);
  const k = Math.min(230 / Math.max(1e-9, Math.max(...ux) - Math.min(...ux)), 104 / Math.max(1e-9, Math.max(...uy) - Math.min(...uy)), 130);
  const ox = 210 - (Math.min(...ux) + Math.max(...ux)) / 2 * k, oy = 136 - (Math.min(...uy) + Math.max(...uy)) / 2 * k, amp = view === 'mode' ? 24 : 40;
  const rest = i => [ox + U[i][0] * k, oy + U[i][1] * k], pos = i => [rest(i)[0], rest(i)[1] - amp * x[i]];
  const E_ = []; for (let a = 0; a < 1 << n; a++) for (let i = 0; i < n; i++) if (!((a >> i) & 1)) E_.push([a, a | (1 << i)]);
  let j = 0; for (let y = s; y; y &= y - 1) j++;
  return (
    <FigSvg id="spring-cube" row={row} part="in time" viewBox="0 0 420 250">
      {E_.map(([a, b]) => { const A = pos(a), B = pos(b); return <line key={a + '-' + b} x1={r1(A[0])} y1={r1(A[1])} x2={r1(B[0])} y2={r1(B[1])} className="stroke-ink" style={{ strokeOpacity: 0.5, strokeWidth: 1.3 }} />; })}
      {U.map((_, i) => { const [px, py] = rest(i); return <circle key={'r' + i} cx={r1(px)} cy={r1(py)} r={2} className="stroke-muted" />; })}
      {U.map((_, i) => { const [px, py] = pos(i), on = view === 'pluck' && i === v, up = x[i] >= 0;
        const dot = <><circle cx={r1(px)} cy={r1(py)} r={on ? 7.5 : 5.5} className={up ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: on ? 2 : 1.2 }} />{n <= 3 && <text x={r1(px + 9)} y={r1(py - 7)} className="t-mono t-micro">{lab(i)}</text>}</>;
        return view === 'pluck'
          ? <g key={i} data-live-mass={i} role="button" tabIndex={0} aria-pressed={on} aria-label={`pluck the mass ${bitStr(n, i)}`} data-param="v" className="fig-cell" onClick={() => onPluck(i)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPluck(i); } }}><circle cx={r1(px)} cy={r1(py)} r={10} className="hit" />{dot}</g>
          : <g key={i} data-live-mass={i}>{dot}</g>; })}
      <text x={8} y={18} className="t-mono t-tiny" data-live-view={view} data-live-t={tm.toFixed(1)}>{view === 'mode'
        ? (research ? `mode ${bitStr(n, s)}: |s| = ${j}, ω² = ${2 * j} · ${binom(n, j)} mode${binom(n, j) === 1 ? '' : 's'} on this level · t = ${tm.toFixed(1)}` : `mode ${bitStr(n, s)}: level ${j}`)
        : (research ? `mass ${bitStr(n, v)} let go · t = ${tm.toFixed(1)}` : `mass ${bitStr(n, v)} let go`)}</text>
      {view === 'pluck' && research && <text x={8} y={242} className="t-mono t-tiny" data-energy={E.toFixed(9)} data-energy0={E0.toFixed(9)}>{`energy ${E.toFixed(4)} · at t = 0: ${E0.toFixed(4)}`}</text>}
    </FigSvg>
  );
}
SpringCube.meta = { id: 'spring-cube', lenses: ['cube', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
SpringCube.data = (params = {}) => { const M = modes(nOf(params)); return { n: M.n, modes: M.modes, levels: M.levels, counts: M.counts }; };
