// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure sign-flux (step 18): the signed 3-cube (engines/categoryEngine.js signGauges; the edge signs are the kernel's e_i e_a, the count compared with cat_check.py K1d
// by tests/engines.test.mjs). The 12 edges carry the rule's signs (dashed and marked − where the sign is −1); in each of the 6 squares the product of its four edge
// signs is −1, so every square anticommutes. Research level: the count of edge-sign choices that make every square anticommute (128 of 4096) and the size of the
// gauge orbit they form (each is the rule's signs with the edges at some corners flipped). The controls are v15's: click an edge to flip its sign, pick a corner and
// flip all its edges, or go back to the rule's signs or to all +1; the squares and, when every square is −1 again, the corners that bring the rule's signs back are
// read off (engines/categoryEngine.js squaresOdd, gaugeOf). It opens on the rule's own signs. Port of v15 CategoryWidgets.jsx CW6.
import React, { useMemo, useState } from 'react';
import { signGauges, ruleSigns, squaresOdd, gaugeOf, flipCorner, edgeKey } from '../../engines/categoryEngine.js';
import { label } from '../../engines/labels.js';
import { FigSvg, Controls, r1, labelLens } from './kit.jsx';

const V3 = [[112, 0], [0, 112], [52, -44]];

export default function SignFlux({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const G = useMemo(() => signGauges(3), []);
  const [signs, setSigns] = useState(() => ruleSigns(3)), [corner, setCorner] = useState(null);
  const odd = squaresOdd(signs, 3), nOdd = odd.filter(Boolean).length, gauge = gaugeOf(signs, 3);
  const edges = G.edges.map(e => ({ ...e, sign: signs[edgeKey(e.a, e.i)] })), squares = G.squares.map((q, f) => ({ ...q, odd: odd[f] }));
  const flipEdge = e => setSigns(s => ({ ...s, [edgeKey(e.a, e.i)]: -s[edgeKey(e.a, e.i)] }));
  const act = f => ({ onClick: f, onKeyDown: ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); f(); } } });
  const W = 420, H = research ? 318 : 296, s = 1.16, ox = (W - 164 * s) / 2, oy = 34 + 44 * s;
  const P = Array.from({ length: 8 }, (_, a) => { let x = 0, y = 0; for (let i = 0; i < 3; i++) if ((a >> i) & 1) { x += V3[i][0]; y += V3[i][1]; } return [ox + x * s, oy + y * s]; });
  const L = labelLens(lens), nameOf = a => label(a, L === 'primes' || L === 'clifford' || L === 'set' ? L : 'bits', [1, 1, 1]);
  return (
    <div className="fig fig-sign-flux">
      <FigSvg id="sign-flux" row={row} viewBox={`0 0 ${W} ${H}`}>
        {edges.map(e => { const [x1, y1] = P[e.a], [x2, y2] = P[e.b], neg = e.sign < 0; return (
          <g key={e.a + '-' + e.i} data-edge={`${e.a},${e.i}`} data-sign={e.sign} role="button" tabIndex={0} aria-label={`edge ${nameOf(e.a)} – ${nameOf(e.b)}, sign ${neg ? '−1' : '+1'}: flip it`} data-param="signs" className="fig-cell" {...act(() => flipEdge(e))}>
            <title>{`${nameOf(e.a)} – ${nameOf(e.b)}: sign ${neg ? '−1' : '+1'}`}</title>
            <line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className="hit" style={{ stroke: 'var(--fg)', strokeOpacity: 0, strokeWidth: 12 }} />
            <line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className="stroke-ink" style={{ strokeWidth: 2.6, strokeOpacity: neg ? 1 : 0.55, strokeDasharray: neg ? '6 4' : undefined, strokeLinecap: 'round' }} />
          </g>); })}
        {P.map(([x, y], a) => <g key={'c' + a} data-corner={a} role="button" tabIndex={0} aria-pressed={corner === a} aria-label={`corner ${nameOf(a)}`} data-param="corner" className="fig-cell" {...act(() => setCorner(c => (c === a ? null : a)))}><circle cx={r1(x)} cy={r1(y)} r={7} className={corner === a ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeOpacity: 0.75, strokeWidth: 1.4 }} />{research && <text x={r1(x + 10)} y={r1(y - 9)} className="t-mono t-tiny">{nameOf(a)}</text>}</g>)}
        {/* the six squares, each with its four edge signs, and their product */}
        {squares.map((q, f) => { const x = 46 + f * 58, y = H - (research ? 70 : 52), z = 24, [c0, c1, c2, c3] = q.corners, sg = (u, v) => { const e = edges.find(t => (t.a === u && t.b === v) || (t.a === v && t.b === u)); return e.sign; };
          const sides = [[c0, c1, 0, z, z, z], [c1, c2, z, z, z, 0], [c3, c2, 0, 0, z, 0], [c0, c3, 0, z, 0, 0]];
          return (
            <g key={'f' + f} data-face={f} data-odd={q.odd ? 1 : 0} transform={`translate(${x}, ${y})`}>
              <title>{`square ${q.corners.map(nameOf).join(' ')}: product of its edge signs ${q.odd ? '−1, it anticommutes' : '+1'}`}</title>
              {sides.map(([u, v, x1, y1, x2, y2], t) => <line key={t} x1={x1} y1={y1} x2={x2} y2={y2} className="stroke-ink" style={{ strokeWidth: 2, strokeOpacity: sg(u, v) < 0 ? 1 : 0.55, strokeDasharray: sg(u, v) < 0 ? '4 3' : undefined }} />)}
              <text x={z / 2} y={z + 15} textAnchor="middle" className="t-mono t-tiny">{q.odd ? '−1' : '+1'}</text>
            </g>); })}
        <g transform="translate(18, 16)">
          <line x1={0} y1={-4} x2={22} y2={-4} className="stroke-ink" style={{ strokeWidth: 2.6, strokeOpacity: 0.55 }} /><text x={26} y={0} className="t-tiny">+1</text>
          <line x1={56} y1={-4} x2={78} y2={-4} className="stroke-ink" style={{ strokeWidth: 2.6, strokeDasharray: '6 4' }} /><text x={82} y={0} className="t-tiny">−1</text>
        </g>
        <text x={W - 18} y={16} textAnchor="end" className="t-mono t-tiny" data-odd-count={nOdd} data-gauge={gauge ? gauge.join(',') : 'none'}>{`${nOdd} of 6 squares −1${gauge ? (gauge.length ? ` · from the rule by flipping ${gauge.map(nameOf).join(', ')}` : ' · the rule') : ''}`}</text>
        {research && <text x={18} y={H - 10} className="t-mono t-tiny t-muted">{`anticommuting choices ${G.count.odd} of ${G.count.total} · gauge orbit ${G.gauges.distinct}`}</text>}
      </FigSvg>
      <Controls label="signs">
        <button type="button" className="fig-btn" data-param="signs" onClick={() => setSigns(ruleSigns(3))}>the rule's signs</button>
        <button type="button" className="fig-btn" data-param="signs" onClick={() => setSigns(Object.fromEntries(G.edges.map(e => [edgeKey(e.a, e.i), 1])))}>all +1</button>
        <button type="button" className="fig-btn" data-param="signs" disabled={corner == null} onClick={() => setSigns(s => flipCorner(s, corner, 3))}>{corner == null ? 'pick a corner to flip' : `flip the edges at ${nameOf(corner)}`}</button>
      </Controls>
    </div>
  );
}
SignFlux.meta = { id: 'sign-flux', lenses: ['bits', 'primes', 'clifford'], learner: false };
/** the numbers the figure draws, for the frame's data download */
SignFlux.data = () => { const G = signGauges(3); return { edges: G.edges, squares: G.squares, count: G.count, gauges: G.gauges }; };
