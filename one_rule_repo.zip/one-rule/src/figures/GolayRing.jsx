// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure golay-ring (step 17): the [24,12,8] Golay code (engines/labels.js golay: the cyclic [23,12] code plus a parity bit, the construction groups_check.py
// compares with the Turyn construction; its log prints the same weights). Left: the weights of the 4096 words, 0, 8, 12, 16, 24 (1, 759, 2576, 759, 1). Right: the 24
// points on a ring; choose up to five and the octads (the 759 words of weight 8) that contain them are counted in the middle — once exactly one is left, its other
// points are shaded. The controls are v15's: the points (a button for each, and a tap on the ring), Clear, and Show an octad (the first five points of one octad).
// Port of v15 LabelsWidgets.GolayCard.
import React, { useState, useMemo } from 'react';
import { golay } from '../../engines/labels.js';
import { FigSvg, Controls, r1 } from './kit.jsx';

const WS = [0, 8, 12, 16, 24];
let G = null;
const code = () => G || (G = golay());
export const through = (octads, picks) => { const mask = picks.reduce((m, i) => m | (1 << i), 0); return picks.length ? octads.filter(o => (o & mask) === mask) : octads; };

export default function GolayRing({ params = {}, lens = null, level = 'research', theme, row }) {
  const C = useMemo(code, []);
  const [picks, setPicks] = useState(() => (Array.isArray(params.points) ? params.points.filter(i => Number.isInteger(i) && i >= 0 && i < 24).slice(0, 5) : []));
  const [demo, setDemo] = useState(0);
  const hit = through(C.octads, picks), one = picks.length >= 1 && hit.length === 1 ? hit[0] : 0;
  const toggle = i => setPicks(p => (p.includes(i) ? p.filter(x => x !== i) : p.length >= 5 ? [...p.slice(1), i] : [...p, i]));
  const showOctad = () => { const o = C.octads[(demo * 37) % C.octads.length], bits = []; for (let i = 0; i < 24; i++) if ((o >> i) & 1) bits.push(i); setPicks(bits.slice(0, 5)); setDemo(demo + 1); };
  const mx = Math.max(...WS.map(w => C.hist[w])), Rr = 92, cx = 300, cy = 118;
  return (
    <div className="fig fig-golay-ring">
      <FigSvg id="golay-ring" row={row} viewBox="0 0 420 250">
        <g data-hist={WS.map(w => `${w}:${C.hist[w]}`).join(',')}>
          {WS.map((w, i) => { const h = C.hist[w] / mx * 150, x = 10 + i * 34; return (
            <g key={w} data-weight={w} data-words={C.hist[w]}>
              <rect x={x} y={r1(190 - Math.max(2, h))} width={26} height={r1(Math.max(2, h))} className="ink" style={{ fillOpacity: 0.75 }} />
              <text x={x + 13} y={206} textAnchor="middle" className="t-mono t-small">{w}</text>
              <text x={x + 13} y={r1(184 - Math.max(2, h))} textAnchor="middle" className="t-mono t-tiny">{C.hist[w]}</text>
            </g>); })}
          <text x={10} y={226} className="t-tiny t-muted">weights of the 4096 words</text>
        </g>
        <g data-picked={picks.join(',')} data-through={hit.length}>
          {Array.from({ length: 24 }, (_, i) => {
            const a = 2 * Math.PI * i / 24 - Math.PI / 2, x = cx + Rr * Math.cos(a), y = cy + Rr * Math.sin(a), on = picks.includes(i), inO = !!one && !!((one >> i) & 1);
            return (
              <g key={i} className="fig-cell" onClick={() => toggle(i)} data-point={i} data-on={on ? 1 : 0} data-octad={inO ? 1 : 0}>
                <circle cx={r1(x)} cy={r1(y)} r={9} className={on || inO ? 'ink' : 'on-panel'} style={{ fillOpacity: on ? 1 : inO ? 0.35 : 1, stroke: 'var(--fg)', strokeWidth: 1.2, strokeOpacity: on || inO ? 1 : 0.5 }} />
                <text x={r1(x)} y={r1(y + 3.5)} textAnchor="middle" className="t-mono t-micro" style={on ? { fill: 'var(--panel)' } : undefined}>{i}</text>
              </g>
            );
          })}
          <text x={cx} y={cy - 4} textAnchor="middle" className="t-small t-bold">{`${picks.length} point${picks.length === 1 ? '' : 's'} chosen`}</text>
          <text x={cx} y={cy + 13} textAnchor="middle" className="t-small">{hit.length === 1 ? 'exactly one octad' : `${hit.length} octads through them`}</text>
        </g>
      </FigSvg>
      <Controls label="points">
        <span className="fig-group" role="group" aria-label="points of the ring" data-param="points">
          {Array.from({ length: 24 }, (_, i) => <button key={i} type="button" className="fig-btn fig-btn-sq fig-mono" data-param="points" aria-pressed={picks.includes(i)} aria-label={`point ${i}`} onClick={() => toggle(i)}>{i}</button>)}
        </span>
        <button type="button" className="fig-btn" data-param="points" onClick={() => setPicks([])}>Clear</button>
        <button type="button" className="fig-btn" data-param="points" onClick={showOctad}>Show an octad</button>
      </Controls>
    </div>
  );
}
GolayRing.meta = { id: 'golay-ring', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
GolayRing.data = (params = {}) => { const C = code(), picks = Array.isArray(params.points) ? params.points.slice(0, 5) : []; return { weights: Object.fromEntries(WS.map(w => [w, C.hist[w]])), octads: C.octads.length, picks, through: through(C.octads, picks).length }; };
