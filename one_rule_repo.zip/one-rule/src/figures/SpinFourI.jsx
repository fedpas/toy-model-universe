// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spin-four-i (step 5): the three kinds of i and a fourth (engines/spinEngine.js threeI; products from the kernel; the unit squares compared with
// checks/selfcheck/spin.json planar by tests/engines.test.mjs). For every pair of squares e₁² = a, e₂² = b in {+1, 0, −1} (rows a, columns b) the three units — kind 1,
// the generator e₁ (grades 0 and 1); kind 2, the bivector e₁e₂ (grades 0 and 2); kind 3, w u w against the reference vector u — are drawn by the unit set of their
// number system: a circle when the unit squares to −1, two lines when it squares to 0, a hyperbola when it squares to +1, a dot when kind 3 has no reference vector.
// Below, the fourth: the pseudoscalar I of Cl(d,0), d = 1..8, its square drawn the same way and a filled mark when I is central. The v15 widget let the reader pick
// (a, b): the figure shows all nine pairs at once, and the chips a, b (interactive entries a and b) mark one pair and print its three units under the grid.
// Port of v15 SpinWidgets.ThreeI.
import React, { useMemo, useState, useEffect } from 'react';
import { threeI } from '../../engines/spinEngine.js';
import { FigSvg, Controls, Chips, r1 } from './kit.jsx';

const sgnTxt = v => (v > 0 ? '+1' : v < 0 ? '−1' : '0');

/** the unit set of a number system whose unit squares to v: circle (−1), two lines (0), hyperbola (+1); a dot when there is no unit (null) */
export function UnitGlyph({ x, y, v, g = 24 }) {
  const title = v === null ? 'no reference vector' : `unit squares to ${sgnTxt(v)}`;
  if (v === null) return <g><title>{title}</title><circle cx={x} cy={y} r={1.8} className="ink-muted" /></g>;
  if (v < 0) return <g data-square="-1"><title>{title}</title><circle cx={x} cy={y} r={r1(g * 0.36)} className="stroke-ink" style={{ strokeWidth: 1.3 }} /></g>;
  if (v === 0) { const h = g * 0.4, dx = g * 0.24; return <g data-square="0"><title>{title}</title><line x1={r1(x - dx)} y1={r1(y - h)} x2={r1(x - dx)} y2={r1(y + h)} className="stroke-ink" style={{ strokeWidth: 1.3 }} /><line x1={r1(x + dx)} y1={r1(y - h)} x2={r1(x + dx)} y2={r1(y + h)} className="stroke-ink" style={{ strokeWidth: 1.3 }} /></g>; }
  const s = g * 0.2, branch = sgn => Array.from({ length: 13 }, (_, i) => { const t = -1.25 + (2.5 * i) / 12; return `${r1(x + sgn * s * Math.cosh(t))},${r1(y - s * Math.sinh(t))}`; }).join(' ');
  return <g data-square="1"><title>{title}</title><polyline points={branch(1)} className="stroke-ink" style={{ strokeWidth: 1.3 }} /><polyline points={branch(-1)} className="stroke-ink" style={{ strokeWidth: 1.3 }} /></g>;
}

export default function SpinFourI({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const T = useMemo(() => threeI(), []), vals = [1, 0, -1], okV = v => vals.includes(v);
  const [a, setA] = useState(okV(params.a) ? params.a : 1), [b, setB] = useState(okV(params.b) ? params.b : 1);
  useEffect(() => { setA(okV(params.a) ? params.a : 1); }, [params.a]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setB(okV(params.b) ? params.b : 1); }, [params.b]);   // eslint-disable-line react-hooks/exhaustive-deps
  const cur = T.pairs.find(p => p.a === a && p.b === b);
  const W = 420, x0 = 78, cw = 110, y0 = 48, rh = 54, gy = y0 + 3 * rh + 30 + 18, H = gy + 66 + (research ? 22 : 0);
  return (
    <div className="fig fig-spin-four-i">
      <FigSvg id="spin-four-i" row={row} viewBox={`0 0 ${W} ${H}`}>
        {vals.map((b, j) => <text key={'b' + b} x={x0 + j * cw + cw / 2} y={y0 - 14} textAnchor="middle" className="t-mono t-small">{research ? `e₂² = ${sgnTxt(b)}` : sgnTxt(b)}</text>)}
        {vals.map((a, i) => <text key={'a' + a} x={x0 - 10} y={y0 + i * rh + rh / 2 + 4} textAnchor="end" className="t-mono t-small">{research ? `e₁² = ${sgnTxt(a)}` : sgnTxt(a)}</text>)}
        {T.pairs.map(p => { const i = vals.indexOf(p.a), j = vals.indexOf(p.b), cx = x0 + j * cw, cy = y0 + i * rh; return (
          <g key={`${p.a},${p.b}`} data-pair={`${p.a},${p.b}`}>
            <title>{`e₁² = ${sgnTxt(p.a)}, e₂² = ${sgnTxt(p.b)}: kind 1 squares to ${sgnTxt(p.k1)}, kind 2 to ${sgnTxt(p.k2)}, kind 3 ${p.k3 === null ? 'has no reference vector' : `to ${sgnTxt(p.k3)} (against ${p.ref})`}`}</title>
            <rect x={cx + 3} y={cy + 3} width={cw - 6} height={rh - 6} rx={5} className={p === cur ? 'stroke-ink' : 'hair-2'} style={p === cur ? { strokeWidth: 1.6 } : undefined} />
            {[p.k1, p.k2, p.k3].map((v, t) => <g key={t}>
              {research && <text x={cx + 22 + t * 33} y={cy + 14} textAnchor="middle" className="t-mono t-micro t-muted">{t + 1}</text>}
              <UnitGlyph x={cx + 22 + t * 33} y={cy + rh / 2 + (research ? 4 : 0)} v={v} g={22} />
            </g>)}
          </g>); })}
        {cur && <text x={4} y={y0 + 3 * rh + 14} className="t-mono t-tiny" data-picked={`${cur.a},${cur.b}`}>{research
          ? `(a, b) = (${sgnTxt(cur.a)}, ${sgnTxt(cur.b)}): kinds 1, 2, 3 square to ${[cur.k1, cur.k2, cur.k3].map(v => (v === null ? '—' : sgnTxt(v))).join(', ')}${cur.k3 === null ? ' (kind 3: no reference vector)' : ` (kind 3 against ${cur.ref})`}`
          : `${sgnTxt(cur.a)}, ${sgnTxt(cur.b)}: the three units square to ${[cur.k1, cur.k2, cur.k3].map(v => (v === null ? '—' : sgnTxt(v))).join(', ')}`}</text>}
        {/* the fourth: the pseudoscalar of Cl(d,0) */}
        <text x={x0 - 10} y={gy + (research ? 0 : 4)} textAnchor="end" className="t-mono t-small">I²</text>
        {research && <text x={x0 - 10} y={gy + 12} textAnchor="end" className="t-mono t-micro t-muted">Cl(d,0)</text>}
        <text x={x0 - 10} y={gy + 38} textAnchor="end" className="t-small">{research ? 'central' : 'centre'}</text>
        {T.fourth.map((f, k) => { const x = x0 + 14 + k * 40; return (
          <g key={'d' + f.d} data-d={f.d} data-sq={f.sq} data-central={f.central ? 1 : 0}>
            <title>{`d = ${f.d}: I² = ${sgnTxt(f.sq)}, ${f.central ? 'central' : 'not central'}`}</title>
            <text x={x} y={gy - 18} textAnchor="middle" className="t-mono t-tiny t-muted">{research ? `d = ${f.d}` : f.d}</text>
            <UnitGlyph x={x} y={gy} v={f.sq} g={22} />
            <circle cx={x} cy={gy + 34} r={4} className={f.central ? 'ink' : 'on-panel'} style={f.central ? undefined : { stroke: 'var(--fg)', strokeWidth: 1.2 }} />
          </g>); })}
        {research && (
          <g transform={`translate(${x0}, ${H - 12})`}>
            {[-1, 0, 1].map((v, t) => <g key={v}><UnitGlyph x={t * 92 + 8} y={-4} v={v} g={14} /><text x={t * 92 + 20} y={0} className="t-mono t-tiny">{`squares to ${sgnTxt(v)}`}</text></g>)}
          </g>
        )}
      </FigSvg>
      <Controls label="squares">
        <Chips label={research ? 'e₁² = a' : 'a'} items={[-1, 0, 1]} value={a} onPick={setA} render={sgnTxt} param="a" mono />
        <Chips label={research ? 'e₂² = b' : 'b'} items={[-1, 0, 1]} value={b} onPick={setB} render={sgnTxt} param="b" mono />
      </Controls>
    </div>
  );
}
SpinFourI.meta = { id: 'spin-four-i', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
SpinFourI.data = () => threeI();
