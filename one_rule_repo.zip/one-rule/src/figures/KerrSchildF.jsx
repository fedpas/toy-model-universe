// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure kerr-schild-f (step 10): the stored results of gravity_new_checks.py (CHECK 1) and c1_birkhoff.py (engines/gravityChecks.js KS and C1, every number read back
// from the shipped logs by tests/engines.test.mjs), not a live computation. Left: on the Kerr–Schild Schwarzschild frame of step 12 the Einstein form E_a has 0 of its
// 16 components non-zero at six points for M = 1 and for M = 3/2 (inside, on and outside the horizon ρ = 2M, exact rational points), while the controls (a wrong power
// of ρ, a charge term, mass with charge, a cosmological term on the same frame) have all 16 non-zero. Right: the Kretschmann scalar K of the engine's curvature at
// the same points, which the log finds equal to 48 M²/ρ⁶ exactly, on log scales, with that curve for both masses and the horizons marked. Research level: the
// Laurent test of c1_birkhoff.py (f = Σ a_k ρ^k, k = −3 … 3, with c unknown: rank 6 of 8 unknowns, null space M/ρ and (c/2)ρ²).
import React from 'react';
import { KS, C1, ratio } from '../../engines/gravityChecks.js';
import { FigSvg, r1 } from './kit.jsx';

const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const pow10 = e => '10' + String(e).split('').map(c => SUP[c]).join('');
const MASSES = ['1', '3/2'];

export default function KerrSchildF({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const W = 420, H = research ? 270 : 252, top = 34, bot = 190;
  // left: non-zero components of E_a (of 16)
  const yA = v => bot - (v / KS.components) * (bot - top - 20), groups = MASSES.map(M => KS.points.filter(p => p.M === M).sort((a, b) => ratio(b.rho) - ratio(a.rho)));
  const gx = (g, i) => 42 + g * 92 + i * 14.5, cx = i => 222 + i * 9;
  // right: K against ρ, log-log
  const lx0 = 290, lx1 = 412, ly0 = top, ly1 = bot, rMin = 0, rMax = Math.log10(14), kMin = -6, kMax = 2.5;
  const XB = rho => lx0 + ((Math.log10(rho) - rMin) / (rMax - rMin)) * (lx1 - lx0), YB = K => ly0 + ((kMax - Math.log10(K)) / (kMax - kMin)) * (ly1 - ly0);
  const curve = M => { const m = ratio(M), pts = []; for (let i = 0; i <= 24; i++) { const rho = 10 ** (rMin + (rMax - rMin) * i / 24), K = 48 * m * m / rho ** 6; if (Math.log10(K) <= kMax && Math.log10(K) >= kMin) pts.push(`${r1(XB(rho))},${r1(YB(K))}`); } return pts.join(' '); };
  return (
    <div className="fig fig-kerr-schild-f">
      <FigSvg id="kerr-schild-f" row={row} viewBox={`0 0 ${W} ${H}`}>
        {/* left panel */}
        <text x={8} y={16} className="t-tiny">{research ? 'non-zero components of Eₐ (of 16)' : 'parts of the equation not zero (of 16)'}</text>
        {[0, 8, 16].map(v => <g key={v}><line x1={30} y1={r1(yA(v))} x2={262} y2={r1(yA(v))} className={v ? 'hair-2' : 'hair'} /><text x={26} y={r1(yA(v) + 3.5)} textAnchor="end" className="t-mono t-micro t-muted">{v}</text></g>)}
        {groups.map((pts, g) => (
          <g key={'g' + g} data-mass={MASSES[g]}>
            {pts.map((p, i) => (
              <g key={p.rho} data-rho={p.rho} data-nonzero={p.nonzero}>
                <title>{`M = ${p.M}, ρ = ${p.rho}${ratio(p.rho) < 2 * ratio(p.M) ? ' (inside the horizon)' : ratio(p.rho) === 2 * ratio(p.M) ? ' (on the horizon)' : ''}: ${p.nonzero} of 16 components of E_a non-zero`}</title>
                <circle cx={r1(gx(g, i))} cy={r1(yA(p.nonzero))} r={3.6} className={g ? 'on-panel' : 'ink'} style={g ? { stroke: 'var(--fg)', strokeWidth: 1.3 } : undefined} />
                {research && <text x={r1(gx(g, i))} y={bot + 14} textAnchor="middle" className="t-mono t-micro t-muted">{p.rho}</text>}
              </g>
            ))}
            <text x={r1(gx(g, 2.5))} y={bot + (research ? 28 : 16)} textAnchor="middle" className="t-mono t-tiny">{`M = ${MASSES[g]}`}</text>
          </g>
        ))}
        {KS.controls.map((c, i) => (
          <g key={'c' + i} data-control={i} data-nonzero={c.nonzero}>
            <title>{`control, ${c.name}: ${c.nonzero} of 16 components non-zero`}</title>
            <rect x={r1(cx(i) - 3.2)} y={r1(yA(c.nonzero) - 3.2)} width={6.4} height={6.4} className="ink" />
          </g>
        ))}
        <text x={cx(2)} y={bot + (research ? 28 : 16)} textAnchor="middle" className="t-tiny">{research ? 'controls' : 'wrong ones'}</text>
        {/* right panel */}
        <text x={lx0 - 6} y={16} className="t-tiny">{research ? 'Kretschmann K' : 'curvature'}</text>
        <rect x={lx0} y={ly0} width={lx1 - lx0} height={ly1 - ly0} className="hair" />
        {[-4, -2, 0, 2].map(e => <g key={'k' + e}><line x1={lx0} y1={r1(YB(10 ** e))} x2={lx1} y2={r1(YB(10 ** e))} className="hair-2" />{research && <text x={lx0 - 3} y={r1(YB(10 ** e) + 3)} textAnchor="end" className="t-mono t-micro t-muted">{pow10(e)}</text>}</g>)}
        {[1, 2, 3, 10].map(rho => <text key={'r' + rho} x={r1(XB(rho))} y={ly1 + 11} textAnchor="middle" className="t-mono t-micro t-muted">{rho}</text>)}
        <text x={lx1} y={ly1 + 24} textAnchor="end" className="t-tiny">{research ? 'ρ' : 'distance'}</text>
        {MASSES.map((M, g) => (
          <g key={'h' + M} data-horizon={2 * ratio(M)}>
            <line x1={r1(XB(2 * ratio(M)))} y1={ly0} x2={r1(XB(2 * ratio(M)))} y2={ly1} className="stroke-muted" style={{ strokeWidth: 0.8, strokeDasharray: g ? '3 3' : '1.5 2.5' }} />
            <polyline points={curve(M)} className="stroke-ink" style={{ strokeWidth: 1.1, strokeOpacity: 0.7, strokeDasharray: g ? '4 3' : undefined }} />
          </g>
        ))}
        {KS.points.map(p => { const g = MASSES.indexOf(p.M); return (
          <g key={`${p.M},${p.rho}`} data-k={p.K}>
            <title>{research ? `M = ${p.M}, ρ = ${p.rho}: K = ${p.K} = 48 M²/ρ⁶` : `mass ${p.M}, distance ${p.rho}: curvature ${p.K}`}</title>
            <circle cx={r1(XB(ratio(p.rho)))} cy={r1(YB(ratio(p.K)))} r={3.2} className={g ? 'on-panel' : 'ink'} style={g ? { stroke: 'var(--fg)', strokeWidth: 1.2 } : undefined} />
          </g>); })}
        {research && MASSES.map(M => <text key={'hl' + M} x={r1(XB(2 * ratio(M)) + 2)} y={ly0 + 9} className="t-mono t-micro t-muted">2M</text>)}
        {research && <text x={8} y={H - 10} className="t-mono t-tiny t-muted">{`Laurent test ρ⁻³ … ρ³, c free: rank ${C1.rank} of ${C1.unknowns}, null space M/ρ and (c/2)ρ²`}</text>}
      </FigSvg>
    </div>
  );
}
KerrSchildF.meta = { id: 'kerr-schild-f', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
KerrSchildF.data = () => JSON.parse(JSON.stringify({ KS, C1 }));
