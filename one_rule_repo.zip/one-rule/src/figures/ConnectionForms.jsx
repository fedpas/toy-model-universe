// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure connection-forms (step 9, gravity): the frame algebra acting on forms, as the tables gravity_selfcheck.py builds and uses (its classes Lie and Forms), here
// from the kernel through engines/labels.js frameAlgebra(4) — four space-time directions, γ₀ squaring to +1 and γ₁, γ₂, γ₃ to −1. Rows: the six bivectors B_A = γ_a γ_b,
// the three boosts (B² = +1) above the three rotations (B² = −1). Left block: ½[B_A, B_B] = ±B_C, a filled cell where the two planes share one index, a dashed
// cell with 0 where they share none (disjoint planes commute), the diagonal plain. Right block: ½[B_A, γ_b] = ±γ_c, non-zero only when b is an index of B_A. Under
// them: the forms, the same rule with every square 0 (dx^μ dx^ν = ±dx^μν, 0 on the diagonal), and the components the script counts for n = 4 (ω, e, R, T and the
// pair classes, gravity.json ladder; tests/figures.render.test.mjs compares what is drawn with it). No control: a new figure, v15 had none.
import React from 'react';
import { frameAlgebra } from '../../engines/labels.js';
import { FigSvg, sub, tx } from './kit.jsx';

const SUPS = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const sup = k => String(k).replace(/\d/g, d => SUPS[d]);
const g = s => 'γ' + sub(s);
const sgn = c => (c < 0 ? '−' : '+');

export default function ConnectionForms({ params = {}, lens = null, level = 'research', theme, row }) {
  const A = frameAlgebra(4), G = A.gens.length, n = A.n, C = A.counts;
  const CW = 33, RH = 22, LX = 44, Y0 = 46, FX = LX, HX = LX + G * CW + 18, Hb = Y0 + G * RH;
  const FY = Hb + 40, FC = 40, FR = 21, KX = LX + n * FC + 26;
  const H = FY + n * FR + 30;
  return (
    <div className="fig fig-connection-forms">
      <FigSvg id="connection-forms" row={row} viewBox={`0 0 420 ${H}`}>
        <text x={FX} y={14} className="t-tiny t-bold">{tx('½[B_A, B_B] = ±B_C')}</text>
        <text x={HX} y={14} className="t-tiny t-bold">{tx('½[B_A, γ_b] = ±γ_c')}</text>
        {A.names.map((nm, B) => <text key={'fc' + B} x={FX + B * CW + CW / 2} y={Y0 - 8} textAnchor="middle" className="t-mono t-micro">{g(nm)}</text>)}
        {Array.from({ length: n }, (_, b) => <text key={'hc' + b} x={HX + b * CW + CW / 2} y={Y0 - 8} textAnchor="middle" className="t-mono t-micro">{g(b)}</text>)}
        {[['boosts', 0, A.squares.filter(s => s === 1).length], ['rotations', A.squares.filter(s => s === 1).length, G]].map(([lab, a, b]) => (
          <g key={lab} data-group={lab}>
            <line x1={9} y1={Y0 + a * RH + 3} x2={9} y2={Y0 + b * RH - 3} className="stroke-muted" />
            <text transform={`translate(6, ${Y0 + (a + b) * RH / 2}) rotate(-90)`} textAnchor="middle" className="t-micro t-muted">{lab}</text>
          </g>
        ))}
        {A.names.map((nm, Ai) => (
          <g key={nm} data-bivector={nm} data-square={A.squares[Ai]}>
            <text x={LX - 6} y={Y0 + Ai * RH + RH / 2 + 3.5} textAnchor="end" className="t-mono t-micro">{g(nm)}</text>
            {A.f[Ai].map((c, B) => {
              const x = FX + B * CW, y = Y0 + Ai * RH, cls = Ai === B ? 'diagonal' : c ? 'share' : 'disjoint';
              return (
                <g key={'f' + B} data-f={`${Ai},${B}`} data-class={cls} data-coef={c ? c.coef : 0} data-c={c ? c.C : ''}>
                  <rect x={x + 1} y={y + 1} width={CW - 2} height={RH - 2} rx={2} className={cls === 'share' ? 'ink' : 'on-panel'}
                    style={cls === 'share' ? { fillOpacity: 0.1, stroke: 'var(--line)' } : cls === 'disjoint' ? { stroke: 'var(--fg)', strokeWidth: 0.8, strokeDasharray: '3 2' } : { stroke: 'var(--line)' }} />
                  <text x={x + CW / 2} y={y + RH / 2 + 3.5} textAnchor="middle" className={c ? 't-mono t-micro' : 't-mono t-micro t-muted'}>{c ? sgn(c.coef) + g(A.names[c.C]) : cls === 'disjoint' ? '0' : '·'}</text>
                </g>
              );
            })}
            {A.h[Ai].map((c, b) => {
              const x = HX + b * CW, y = Y0 + Ai * RH;
              return (
                <g key={'h' + b} data-h={`${Ai},${b}`} data-coef={c ? c.coef : 0} data-c={c ? c.c : ''}>
                  <rect x={x + 1} y={y + 1} width={CW - 2} height={RH - 2} rx={2} className={c ? 'ink' : 'on-panel'} style={c ? { fillOpacity: 0.1, stroke: 'var(--line)' } : { stroke: 'var(--line)' }} />
                  {c && <text x={x + CW / 2} y={y + RH / 2 + 3.5} textAnchor="middle" className="t-mono t-micro">{sgn(c.coef) + g(c.c)}</text>}
                </g>
              );
            })}
          </g>
        ))}
        <text x={LX} y={FY - 22} className="t-tiny t-bold">{tx('dx^μ dx^ν: the same rule, every square 0')}</text>
        {Array.from({ length: n }, (_, nu) => <text key={'dc' + nu} x={LX + nu * FC + FC / 2} y={FY - 6} textAnchor="middle" className="t-mono t-micro">{'dx' + sup(nu)}</text>)}
        {A.forms.map((rw, mu) => (
          <g key={'d' + mu}>
            <text x={LX - 6} y={FY + mu * FR + FR / 2 + 3.5} textAnchor="end" className="t-mono t-micro">{'dx' + sup(mu)}</text>
            {rw.map((c, nu) => (
              <g key={nu} data-form={`${mu},${nu}`} data-sign={c.sign}>
                <rect x={LX + nu * FC + 1} y={FY + mu * FR + 1} width={FC - 2} height={FR - 2} rx={2} className="on-panel" style={{ stroke: 'var(--line)' }} />
                <text x={LX + nu * FC + FC / 2} y={FY + mu * FR + FR / 2 + 3.5} textAnchor="middle" className={c.sign ? 't-mono t-micro' : 't-mono t-micro t-muted'}>{c.sign ? sgn(c.sign) + 'dx' + sup(mu < nu ? `${mu}${nu}` : `${nu}${mu}`) : '0'}</text>
              </g>
            ))}
          </g>
        ))}
        <g transform={`translate(${KX}, ${FY - 22})`} data-counts={[C.omega_components, C.tetrad_components, C.curvature_components, C.torsion_components].join(',')}
          data-pairs={[C.pair_classes.diagonal, C.pair_classes.share_one_index, C.pair_classes.disjoint].join(',')}>
          <text x={0} y={0} className="t-tiny t-bold">{`components, n = ${n}`}</text>
          {[
            [`ω = ω^A B_A`, `${n} × ${G} = ${C.omega_components}`],
            [`e = e^a γ_a`, `${n} × ${n} = ${C.tetrad_components}`],
            [`R^C = dω^C + ¼ f ω^A ω^B`, `${G} × ${G} = ${C.curvature_components}`],
            [`T^c = de^c + h ω^A e^b`, `${n} × ${G} = ${C.torsion_components}`],
          ].map(([a, b], i) => <g key={i}><text x={0} y={18 + i * 15} className="t-mono t-micro">{tx(a)}</text><text x={186} y={18 + i * 15} textAnchor="end" className="t-mono t-micro">{b}</text></g>)}
          <text x={0} y={86} className="t-micro t-muted">{`pairs of planes: ${C.pair_classes.diagonal} diagonal, ${C.pair_classes.share_one_index} share an index,`}</text>
          <text x={0} y={98} className="t-micro t-muted">{`${C.pair_classes.disjoint} disjoint · gravity_selfcheck.py`}</text>
        </g>
      </FigSvg>
    </div>
  );
}
ConnectionForms.meta = { id: 'connection-forms', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
ConnectionForms.data = () => { const A = frameAlgebra(4); return { n: A.n, squares: A.eps, bivectors: A.names, bivectorSquares: A.squares, f: A.f, h: A.h, forms: A.forms, counts: A.counts }; };
