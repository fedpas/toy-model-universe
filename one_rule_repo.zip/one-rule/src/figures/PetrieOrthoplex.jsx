// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure petrie-orthoplex: the n-orthoplex drawn on its Petrie polygon — the two poles +e_i and −e_i of every line opposite on the circle (filled and hollow marks),
// an edge between any two poles of different lines (the product of the two vectors, from the kernel, in the edge's tooltip). Counts from engines/labels.js petrie
// (faces = words over 0, +, −; compared with checks/selfcheck/shapes.json by tests/engines.test.mjs). Port of v15 ShapesSection.Petrie.
import React, { useState, useEffect, useMemo } from 'react';
import { petrie, label } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, r1, labelLens } from './kit.jsx';

const pole = (s, i, lensKey, research, eps) => (s > 0 ? '+' : '−') + (research ? label(1 << i, lensKey, eps) : String(i + 1));

export default function PetrieOrthoplex({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const valid = x => Number.isInteger(x) && x >= 0 && x <= 8;
  const [n, setN] = useState(valid(params.n) ? params.n : 4);
  useEffect(() => { if (valid(params.n)) setN(params.n); }, [params.n]);   // eslint-disable-line react-hooks/exhaustive-deps
  const P = useMemo(() => petrie(n), [n]), lensKey = labelLens(lens) || 'clifford';
  const R = 112, c = 150, at = v => [r1(c + R * Math.cos(v.angle)), r1(c - R * Math.sin(v.angle))], dense = n > 6, labels = n <= 5;
  const prod = e => { const A = P.vertices[e.u], B = P.vertices[e.v]; return `(${pole(A.s, A.i, 'clifford', true, P.eps)})(${pole(B.s, B.i, 'clifford', true, P.eps)}) = ${e.coef < 0 ? '−' : ''}${label(e.blade, 'clifford', P.eps)}`; };
  return (
    <div className="fig fig-petrie-orthoplex">
      <FigSvg id="petrie-orthoplex" row={row} viewBox={research ? '0 0 300 318' : '0 0 300 300'}>
        {n === 0 && <circle cx={c} cy={c} r={4.5} className="ink" />}
        {n === 1 && <line x1={at(P.vertices[0])[0]} y1={at(P.vertices[0])[1]} x2={at(P.vertices[1])[0]} y2={at(P.vertices[1])[1]} className="hair" />}
        {P.edges.map(e => { const [x1, y1] = at(P.vertices[e.u]), [x2, y2] = at(P.vertices[e.v]); return (
          <line key={e.u + '-' + e.v} x1={x1} y1={y1} x2={x2} y2={y2} className="stroke-ink" style={{ strokeOpacity: dense ? 0.28 : 0.45, strokeWidth: dense ? 0.5 : 0.9 }}>
            <title>{prod(e)}</title>
          </line>); })}
        {P.vertices.map(v => { const [x, y] = at(v), plus = v.s > 0, rr = dense ? 3.2 : 4.6; return (
          <g key={v.i + (plus ? '+' : '-')}>
            <circle cx={x} cy={y} r={rr} className={plus ? 'ink' : 'on-panel'} style={plus ? { stroke: 'var(--panel)', strokeWidth: 1.5 } : { stroke: 'var(--fg)', strokeWidth: 1.4 }}>
              <title>{pole(v.s, v.i, lensKey, true, P.eps)}</title>
            </circle>
            {labels && <text x={r1(c + (R + 17) * Math.cos(v.angle))} y={r1(c - (R + 17) * Math.sin(v.angle) + 4)} textAnchor="middle" className="t-mono t-small">{pole(v.s, v.i, lensKey, research, P.eps)}</text>}
          </g>); })}
        {research && <text x={150} y={308} textAnchor="middle" className="t-mono t-small t-muted">{`n = ${n} · ${P.vertices.length} vertices · ${P.edges.length} edges · ${P.facets} facets`}</text>}
      </FigSvg>
      {research && <Controls label="orthoplex"><Chips label="n" items={[0, 1, 2, 3, 4, 5, 6, 7, 8]} value={n} onPick={setN} param="n" mono /></Controls>}
    </div>
  );
}
PetrieOrthoplex.meta = { id: 'petrie-orthoplex', lenses: ['orthoplex', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
PetrieOrthoplex.data = (params = {}) => { const P = petrie(Number.isInteger(params.n) ? params.n : 4); return { n: P.n, vertices: P.vertices.map(({ i, s }) => ({ generator: i + 1, sign: s })), edges: P.edges, faces_by_vertices: P.faces, facets: P.facets, faces_total_with_empty: P.total }; };
