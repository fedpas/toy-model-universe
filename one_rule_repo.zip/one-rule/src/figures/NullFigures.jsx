// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure null-figures (step 13): two of v15's five null-surface pictures, from engines/nullEngine.js (the formulas null_selfcheck.py checks; the tube's squares and
// brackets are the kernel's) and the stored null.json (κ_H of each horizon, the dimensions of the horizon algebra).
//  1. The cone, the normal and the photon that stands still: in the regular chart ds² = T dv² + 2 dv dx − r² dΩ², T(x) on the left; on the right the light cones up
//     the x axis, the surface x = const through the probe (the line), ξ = ∂ᵥ along it and n = dx across. As T → 0 one edge of the cone lies along the surface: ξ is
//     null. In the cube lens, the tube's tangent algebra Cl(T, −1, −1): K1 = 3, K2 = 5, J = 6 on the 3-cube, [K1, K2] = −2T J dashed when it vanishes (T = 0).
//  2. The horizon's algebra: the cell Cl(1, n−1) = M₂(Cl(0, n−2)) beside the horizon algebra Cl(0, n−2, 1), half its size, split into the ideal J through the null bit
//     (filled; J·J = 0) and the quotient (hollow) — as boxes (Clifford lens), as the corners of the (n−1)-cube by grade (cube lens), as the faces of the simplex with
//     the star of the null vertex ℓ heavy (simplex lens), or as factors of 2 (prime lens).
// Controls, as in v15: the horizon (the five cases of S12.1), the probe's distance from it (research level) with "on the horizon", and n = 2 … 6. The other three
// pictures of v15 (the neck, the criterion of Eq. (1), Kerr's ergosurface) are not drawn here. Port of v15 NullWidgets.ConeWidget and LadderWidget.
import React, { useState, useEffect, useMemo } from 'react';
import { HORIZONS, PROBE, tMax, kappaNum, surfaceKind, tube, NS, QUOT, CELL, inJ, blade, choose, popc } from '../../engines/nullEngine.js';
import { NULL } from '../../engines/stored.js';
import { FigSvg, Controls, Chips, Range, r1, sub, arrowHead, pick, isIn } from './kit.jsx';

const CASES = HORIZONS.map(h => h.id);
const CASE_NAME = { schw: 'Schwarzschild', rn_out: 'Reissner–Nordström, outer', rn_in: 'Reissner–Nordström, inner', extremal: 'Extremal', areal: 'Areal radius' };
const f3 = (v, d = 3) => (Math.abs(v) < 5 * 10 ** -(d + 1) ? '0' : String(+v.toFixed(d)).replace('-', '−'));
const pow2 = k => '2' + String(k).replace(/\d/g, d => '⁰¹²³⁴⁵⁶⁷⁸⁹'[d]).replace('-', '⁻');

function ConePanel({ h, d, cube, research, row }) {
  const x = h.xh + d, T = h.T(x), tm = tMax(h), kind = surfaceKind(T), ci = HORIZONS.indexOf(h);
  const y0 = h.xh - PROBE - 0.05, y1 = h.xh + PROBE + 0.05, Y = v => 222 - (v - y0) / (y1 - y0) * 192, tl = tm * 1.15, TX = v => 14 + (v + tl) / (2 * tl) * 100;
  const curve = Array.from({ length: 61 }, (_, i) => { const v = y0 + (y1 - y0) * i / 60; return `${r1(TX(h.T(v)))},${r1(Y(v))}`; }).join(' ');
  const cx = 290, py = Y(x);
  const cone = (qy, Tc, L, strong, key) => {
    const s = -Tc / tm, nn = Math.hypot(1, s), ux = 1 / nn, uy = s / nn, P = a => a.map(p => p.map(r1).join(',')).join(' ');
    return (
      <g key={key} data-cone-t={f3(Tc, 4)} data-probe={strong ? 1 : 0}>
        <polygon points={P([[cx, qy], [cx, qy - L], [cx + L * ux, qy - L * uy]])} className="ink" style={{ fillOpacity: strong ? 0.28 : 0.1 }} />
        <polygon points={P([[cx, qy], [cx, qy + L], [cx - L * ux, qy + L * uy]])} className="ink" style={{ fillOpacity: strong ? 0.28 : 0.1 }} />
        <line x1={cx} y1={r1(qy - L)} x2={cx} y2={r1(qy + L)} className="stroke-ink" style={{ strokeWidth: strong ? 1.8 : 0.8, strokeOpacity: strong ? 1 : 0.55 }} />
        <line x1={r1(cx - L * ux)} y1={r1(qy + L * uy)} x2={r1(cx + L * ux)} y2={r1(qy - L * uy)} className="stroke-ink" style={{ strokeWidth: strong ? 1.8 : 0.8, strokeOpacity: strong ? 1 : 0.55 }} />
      </g>
    );
  };
  const tb = tube(T), P3 = m => [236 + 70 * (m & 1) + 36 * ((m >> 2) & 1), 206 - 70 * ((m >> 1) & 1) - 28 * ((m >> 2) & 1)];
  const kap = NULL.portal.kappa[ci];
  return (
    <FigSvg id="null-figures" row={row} part="the cone and the normal" viewBox={`0 0 420 ${research ? 262 : 240}`}>
      <g data-case={h.id} data-t={f3(T, 5)} data-kind={kind}>
        <line x1={r1(TX(0))} y1={26} x2={r1(TX(0))} y2={226} className="hair" />
        <polyline points={curve} className="stroke-muted" style={{ strokeWidth: 1.8 }} />
        <line x1={8} y1={r1(py)} x2={124} y2={r1(py)} className="stroke-ink" style={{ strokeDasharray: '4 3', strokeOpacity: 0.7 }} />
        <circle cx={r1(TX(T))} cy={r1(py)} r={4.5} className="ink" />
        {research && <text x={r1(TX(0))} y={18} textAnchor="middle" className="t-small">T(x)</text>}
        {research && <text x={r1(TX(0) + 4)} y={r1(Y(h.xh) - 4)} className="t-tiny t-muted">{`x = ${h.xh}`}</text>}
        {!cube && (
          <g data-view="clifford">
            {[-0.5, -0.25, 0, 0.25, 0.5].map(di => cone(Y(h.xh + di), h.T(h.xh + di), 22, false, 'f' + di))}
            <line x1={cx - 92} y1={r1(py)} x2={cx + 92} y2={r1(py)} className="stroke-ink" style={{ strokeWidth: 2.4 }} data-surface="1" />
            {cone(py, T, 34, true, 'p')}
            <line x1={cx + 44} y1={r1(py)} x2={cx + 76} y2={r1(py)} className="stroke-ink" style={{ strokeWidth: 1.5 }} /><path d={arrowHead(cx + 44, py, cx + 80, py, 7)} className="ink" />
            <text x={cx + 46} y={r1(py + 15)} className="t-small">{research ? 'ξ = ∂ᵥ' : 'along'}</text>
            <line x1={cx - 64} y1={r1(py)} x2={cx - 64} y2={r1(py - 28)} className="stroke-ink" style={{ strokeWidth: 1.5 }} /><path d={arrowHead(cx - 64, py, cx - 64, py - 32, 7)} className="ink" />
            <text x={cx - 60} y={r1(py - 24)} className="t-small">{research ? 'n = dx' : 'across'}</text>
            <text x={cx - 90} y={r1(py + 14)} className="t-small">{research ? 'x = const' : 'the surface'}</text>
          </g>
        )}
        {cube && (
          <g data-view="cube" data-k1k2={f3(tb.K1K2.c)}>
            {[0, 1, 2, 3, 4, 5, 6, 7].flatMap(m => [0, 1, 2].map(b => (((m >> b) & 1) ? null : [m, m | (1 << b)]))).filter(Boolean).map(([a, b]) => <line key={a + '-' + b} x1={P3(a)[0]} y1={P3(a)[1]} x2={P3(b)[0]} y2={P3(b)[1]} className="hair" />)}
            {[[3, 5], [3, 6], [5, 6]].map(([a, b]) => { const k12 = a === 3 && b === 5, zero = k12 && Math.abs(T) < 1e-12; return <line key={'k' + a + b} x1={P3(a)[0]} y1={P3(a)[1]} x2={P3(b)[0]} y2={P3(b)[1]} className="stroke-ink" style={{ strokeWidth: k12 ? 3 : 1.6, strokeDasharray: zero ? '4 3' : undefined, strokeOpacity: zero ? 0.5 : 1 }} data-bracket={`${a},${b}`} />; })}
            {[0, 1, 2, 3, 4, 5, 6, 7].map(m => { const [px, qy] = P3(m), even = popc(m) % 2 === 0 && m; return <g key={m}><circle cx={px} cy={qy} r={even ? 8 : 6} className={even ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.5, strokeOpacity: m === 0 || m === 7 ? 0.5 : 1 }} /><text x={px + 11} y={qy - 7} className="t-mono t-tiny">{m}</text></g>; })}
            <text x={P3(3)[0] - 4} y={P3(3)[1] - 14} className="t-small">K1</text><text x={P3(5)[0] + 4} y={P3(5)[1] + 22} className="t-small">K2</text><text x={P3(6)[0] - 20} y={P3(6)[1] - 10} className="t-small">J</text>
            {research && <text x={190} y={18} className="t-tiny t-muted">3-cube: K1 = 3, K2 = 5, J = 6</text>}
          </g>
        )}
        <text x={150} y={240} className="t-small t-bold">{`${research ? 'the surface x = const is ' : 'the surface is '}${kind}`}</text>
        {research && <text x={8} y={256} className="t-mono t-tiny t-muted" data-kappa={kap.kappa}>{cube
          ? `K1² = K2² = T = ${f3(tb.sq.K1)} · J² = ${tb.sq.J} · [J, K1] = ${tb.JK1.c} K2 · [K1, K2] = −2T J = ${f3(tb.K1K2.c)} J`
          : `T = g_tt = ${f3(T)} · n·n = −T · κ_H = ½ dT/dx = ${kap.kappa} (${f3(kappaNum(h), 4)})`}</text>}
      </g>
    </FigSvg>
  );
}

function LadderPanel({ n, view, research, row }) {
  const rec = NULL.portal.ladder.find(r => r.n === n), m = n - 1, N = 1 << m, nq = QUOT[n];
  const cols = Array.from({ length: m + 1 }, () => []); for (let S = 0; S < N; S++) cols[popc(S)].push(S);
  const mx = Math.max(...cols.map(c => c.length)), CW = 380 / (m + 1), RH = Math.min(28, 190 / mx);
  const vpos = S => { const k = popc(S), j = cols[k].indexOf(S); return [30 + CW * k + CW / 2 - 10, 124 + RH * (j - (cols[k].length - 1) / 2)]; };
  const poly = Array.from({ length: m }, (_, i) => { const a = (2 * Math.PI * i) / Math.max(m, 3) - Math.PI / 2 + (m === 2 ? Math.PI / 4 : 0); return m === 1 ? [210, 124] : m === 2 ? [210 + (i ? 70 : -70), 124] : [210 + 92 * Math.cos(a), 128 + 92 * Math.sin(a)]; });
  const box = (k, x, y, w, hh, filled, tx) => <g key={k}><rect x={x} y={y} width={w} height={hh} rx={5} className={filled ? 'ink' : 'on-panel'} style={{ fillOpacity: filled ? 0.18 : 1, stroke: 'var(--fg)', strokeWidth: 1.4 }} /><text x={x + w / 2} y={y + hh / 2 + 4} textAnchor="middle" className="t-small">{tx}</text></g>;
  return (
    <FigSvg id="null-figures" row={row} part="the horizon algebra" viewBox={`0 0 420 ${research ? 252 : 236}`}>
      <g data-n={n} data-view={view} data-dim={rec.dim} data-j={rec.J}>
        {view === 'clifford' && (
          <g>
            <text x={8} y={16} className="t-small t-bold">{research ? `the cell: ${CELL[n]}` : 'the cell'}</text>
            {[0, 1, 2, 3].map(i => box('c' + i, 8 + 98 * (i % 2), 28 + 88 * (i >> 1), 92, 80, false, nq))}
            <text x={8} y={222} className="t-tiny t-muted">{`2×2 matrices over ${nq}`}</text>
            <text x={222} y={16} className="t-small t-bold">{research ? `the horizon: Cl(0,${n - 2},1)` : 'the horizon'}</text>
            {box('J', 222, 28, 90, 176, true, 'J · J = 0')}{box('Q', 318, 28, 94, 176, false, `quotient ${nq}`)}
            <text x={222} y={222} className="t-tiny" data-j-dim={rec.J}>{`dim ${pow2(n - 1)} = ${rec.dim} · dim J = ${pow2(n - 2)} = ${rec.J}`}</text>
          </g>
        )}
        {view === 'cube' && (
          <g>
            {Array.from({ length: N }, (_, S) => Array.from({ length: m }, (_, b) => (((S >> b) & 1) ? null : [S, S | (1 << b)]))).flat().filter(Boolean).map(([a, b]) => <line key={a + '-' + b} x1={r1(vpos(a)[0])} y1={r1(vpos(a)[1])} x2={r1(vpos(b)[0])} y2={r1(vpos(b)[1])} className="hair" />)}
            {Array.from({ length: N }, (_, S) => { const [px, qy] = vpos(S), J = inJ(n, S); return <circle key={S} cx={r1(px)} cy={r1(qy)} r={6} className={J ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} data-blade={S} data-in-j={J ? 1 : 0}><title>{`${blade(n, S)} (${S.toString(2).padStart(m, '0')})${J ? ' · in J' : ''}`}</title></circle>; })}
            {cols.map((c, k) => <text key={k} x={r1(30 + CW * k + CW / 2 - 10)} y={14} textAnchor="middle" className="t-mono t-tiny t-muted">{k}</text>)}
            <text x={8} y={232} className="t-tiny t-muted">columns: grade · filled: through the null bit (J) · hollow: the quotient</text>
          </g>
        )}
        {view === 'simplex' && (
          <g>
            {poly.flatMap((a, i) => poly.map((b, j) => (j > i ? [i, j] : null)).filter(Boolean)).map(([i, j]) => <line key={i + '-' + j} x1={r1(poly[i][0])} y1={r1(poly[i][1])} x2={r1(poly[j][0])} y2={r1(poly[j][1])} className="stroke-ink" style={{ strokeWidth: i === 0 ? 3 : 1.2, strokeOpacity: i === 0 ? 1 : 0.45 }} data-star={i === 0 ? 1 : 0} />)}
            {poly.map((p, i) => <g key={i}><circle cx={r1(p[0])} cy={r1(p[1])} r={i === 0 ? 10 : 7} className={i === 0 ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.5 }} /><text x={r1(p[0] + (p[0] >= 210 ? 14 : -14))} y={r1(p[1] + (p[1] >= 128 ? 16 : -10))} textAnchor={p[0] >= 210 ? 'start' : 'end'} className="t-small">{i === 0 ? 'ℓ' : 'e' + sub(i)}</text></g>)}
            <text x={8} y={16} className="t-small">{`${m} generators: ℓ (null) and ${m - 1} for the sphere`}</text>
            <text x={8} y={232} className="t-tiny" data-star-faces={rec.J}>{`faces through ℓ: ${Array.from({ length: m }, (_, k) => choose(m - 1, k)).join(' + ')} = ${rec.J}`}</text>
          </g>
        )}
        {view === 'prime' && (
          <g>
            {[[n, rec.dim * 2, 'the cell'], [n - 1, rec.dim, 'the horizon algebra'], [n - 2, rec.J, 'the ideal J']].map(([k, val, name], i) => (
              <g key={i} data-prime-row={val}>
                <text x={8} y={24 + 70 * i} className="t-small">{`${name} = ${val} = ${pow2(k)}`}</text>
                {Array.from({ length: k }, (_, j) => <g key={j}><circle cx={20 + 28 * j} cy={44 + 70 * i} r={11} className="ink" style={{ fillOpacity: 0.12 + 0.12 * i, stroke: 'var(--fg)', strokeWidth: 1.4 }} /><text x={20 + 28 * j} y={48 + 70 * i} textAnchor="middle" className="t-small">2</text></g>)}
              </g>
            ))}
            <text x={8} y={232} className="t-tiny t-muted">only the prime 2</text>
          </g>
        )}
        {research && <text x={8} y={248} className="t-mono t-tiny t-muted">{`n = ${n} · Cl(0,${n - 2},1): dim ${rec.dim} · dim J = ${rec.J} · quotient Cl(0,${n - 2}) = ${nq}`}</text>}
      </g>
    </FigSvg>
  );
}

export default function NullFigures({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [ci, setCi] = useState(pick(params.case, isIn(CASES), 'schw'));
  const [d, setD] = useState(Number.isFinite(params.probe) && Math.abs(params.probe) <= PROBE ? params.probe : 0);
  const [n, setN] = useState(pick(params.n, isIn(NS), 4));
  useEffect(() => { setCi(pick(params.case, isIn(CASES), 'schw')); setD(Number.isFinite(params.probe) && Math.abs(params.probe) <= PROBE ? params.probe : 0); setN(pick(params.n, isIn(NS), 4)); }, [params.case, params.probe, params.n]);
  const h = HORIZONS.find(x => x.id === ci), view = lens === 'cube' ? 'cube' : lens === 'simplex' ? 'simplex' : lens === 'prime' ? 'prime' : 'clifford';
  return (
    <div className="fig fig-null-figures">
      <div className="fig-stack">
        <ConePanel h={h} d={d} cube={lens === 'cube'} research={research} row={row} />
        <LadderPanel n={n} view={view} research={research} row={row} />
      </div>
      <Controls label="null surfaces">
        <Chips label={research ? 'horizon' : 'which edge'} items={CASES} value={ci} onPick={c => setCi(c)} render={c => CASE_NAME[c]} param="case" />
        {research && <Range label="probe x − xₕ" value={d} min={-PROBE} max={PROBE} step={0.01} onChange={setD} display={v => f3(v, 2)} param="probe" />}
        {research && <button type="button" className="fig-btn" data-param="probe" onClick={() => setD(0)}>on the horizon</button>}
        {research && <Chips label="n" items={NS} value={n} onPick={setN} param="n" mono />}
      </Controls>
    </div>
  );
}
NullFigures.meta = { id: 'null-figures', lenses: ['clifford', 'simplex', 'cube', 'prime'], learner: true };
/** the numbers the figure draws, for the frame's data download */
NullFigures.data = (params = {}) => { const h = HORIZONS.find(x => x.id === params.case) || HORIZONS[0], d = Number.isFinite(params.probe) ? params.probe : 0, T = h.T(h.xh + d); return { case: h.id, xh: h.xh, probe: d, T, kind: surfaceKind(T), tube: tube(T), kappa: NULL.portal.kappa[HORIZONS.indexOf(h)], ladder: NULL.portal.ladder }; };
