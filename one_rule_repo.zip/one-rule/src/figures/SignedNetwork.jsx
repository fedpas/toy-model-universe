// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure signed-network (step 15): the Clifford spring network on the n-cube. The springs are the cube's edges; the edge from x along axis i carries the sign of
// e_i e_x (engines/springEngine.js signedD, through spinEngine's product: the kernel's sign), drawn solid for +1 and dashed for −1. The signed matrix D satisfies
// D² = n·I, and the product of the four signs round every square face is −1 (for n ≤ 3 each face is marked). Under the cube, the two spectra: the plain network
// (ω² = 0, 2, …, 2n with multiplicities C(n, j)) and the signed one (n ± √n, 2^{n−1} each), a dot's area its multiplicity — the levels spring_selfcheck.py proves
// exactly (spring.json clifford, compared by tests/engines.test.mjs). The control is v15's chips n = 2 … 5 (interactive entry n). Port of v15 SpringWidgets.Spectra
// and FaceCloser (the signed network of LabelsAsModes's section).
import React, { useState, useEffect, useMemo } from 'react';
import { signedD, signedChecks, plainLevels, signedLevels, edges, faces, project } from '../../engines/springEngine.js';
import { FigSvg, Controls, Chips, r1, pick, isIn } from './kit.jsx';

const NS = [2, 3, 4, 5];
const f2 = x => String(+x.toFixed(2));
const bits = (n, x) => x.toString(2).padStart(n, '0');

export default function SignedNetwork({ params = {}, lens = null, level = 'research', theme, row }) {
  const [n, setN] = useState(pick(params.n, isIn(NS), 3));
  useEffect(() => { setN(pick(params.n, isIn(NS), 3)); }, [params.n]);
  const D = useMemo(() => signedD(n), [n]), C = useMemo(() => signedChecks(n), [n]), E = edges(n), F = faces(n);
  const P = useMemo(() => { const U = Array.from({ length: 1 << n }, (_, x) => project(n, x, 1)), xs = U.map(p => p[0]), ys = U.map(p => p[1]), k = Math.min(250 / Math.max(1e-9, Math.max(...xs) - Math.min(...xs)), 150 / Math.max(1e-9, Math.max(...ys) - Math.min(...ys)), 120);
    const ox = 210 - (Math.min(...xs) + Math.max(...xs)) / 2 * k, oy = 96 - (Math.min(...ys) + Math.max(...ys)) / 2 * k; return U.map(p => [r1(ox + p[0] * k), r1(oy + p[1] * k)]); }, [n]);
  const pl = plainLevels(n), sg = signedLevels(n), top = 2 * n, X = w => 40 + w * 340 / top, minus = C.flux.filter(v => v === -1).length;
  return (
    <div className="fig fig-signed-network">
      <FigSvg id="signed-network" row={row} viewBox="0 0 420 330">
        <g data-n={n} data-dsq={C.dsq ? 1 : 0} data-trace={C.tr} data-flux-minus={minus} data-faces={F.length}>
          {E.map(([a, b]) => { const s = D[b][a]; return <line key={a + '-' + b} x1={P[a][0]} y1={P[a][1]} x2={P[b][0]} y2={P[b][1]} className="stroke-ink" style={{ strokeWidth: 1.5, strokeDasharray: s < 0 ? '4 3' : undefined, strokeOpacity: 0.85 }} data-spring={`${a},${b}`} data-sign={s} />; })}
          {n <= 3 && F.map(([x, i, j], k) => { const cs = [x, x | (1 << i), x | (1 << i) | (1 << j), x | (1 << j)], cx = cs.reduce((u, c) => u + P[c][0], 0) / 4, cy = cs.reduce((u, c) => u + P[c][1], 0) / 4; return <text key={'f' + k} x={r1(cx)} y={r1(cy + 3)} textAnchor="middle" className="t-mono t-micro t-muted" data-face-flux={C.flux[k]}>{C.flux[k] < 0 ? '−1' : '+1'}</text>; })}
          {P.map(([x, y], v) => <g key={v}><circle cx={x} cy={y} r={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />{n <= 3 && <text x={x + 7} y={y - 6} className="t-mono t-micro">{bits(n, v)}</text>}</g>)}
        </g>
        <g transform="translate(0, 196)">
          <line x1={30} y1={96} x2={390} y2={96} className="hair" />
          {Array.from({ length: top + 1 }, (_, w) => <g key={w}><line x1={r1(X(w))} y1={96} x2={r1(X(w))} y2={100} className="hair" /><text x={r1(X(w))} y={112} textAnchor="middle" className="t-mono t-micro t-muted">{w}</text></g>)}
          {[['plain', pl, 22], ['signed', sg, 66]].map(([lab, lv, y]) => (
            <g key={lab} data-spectrum={lab}>
              <text x={4} y={y - 14} className="t-tiny">{lab === 'plain' ? 'plain springs' : 'signed springs'}</text>
              {lv.map(l => { const r = 2.5 + Math.sqrt(l.mult) * 2.2; return (
                <g key={l.w2} data-w2={l.w2.toFixed(6)} data-mult={l.mult}>
                  <circle cx={r1(X(l.w2))} cy={y} r={r1(r)} className={lab === 'plain' ? 'ink' : 'on-panel'} style={{ fillOpacity: lab === 'plain' ? 0.7 : 1, stroke: 'var(--fg)', strokeWidth: 1.2 }} />
                  <text x={r1(X(l.w2))} y={r1(y - r - 3)} textAnchor="middle" className="t-mono t-micro">{l.mult}</text>
                </g>); })}
            </g>
          ))}
          <text x={390} y={126} textAnchor="end" className="t-tiny t-muted">ω²</text>
        </g>
        <text x={4} y={186} className="t-mono t-tiny">{`D² = ${n}·I: ${C.dsq ? 'yes' : 'no'} · flux −1 through ${minus} of ${F.length} faces · signed: ${n} ± √${n}`}</text>
      </FigSvg>
      <Controls label="network">
        <Chips label="n" items={NS} value={n} onPick={setN} param="n" mono />
      </Controls>
    </div>
  );
}
SignedNetwork.meta = { id: 'signed-network', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
SignedNetwork.data = (params = {}) => { const n = pick(params.n, isIn(NS), 3), C = signedChecks(n); return { n, dsq: C.dsq, trace: C.tr, flux: C.flux, plain: plainLevels(n), signed: signedLevels(n) }; };
