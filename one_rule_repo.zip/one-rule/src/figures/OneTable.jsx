// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure one-table (step 20, Schuller): one table, three squares. The product table e_a e_b (row a, column b) of 2 or 3 generators whose squares are each +1, −1 or 0,
// from the kernel (engines/schullerEngine.js productTable and tableStats, through engines/labels.js): the labels and the XOR are the same for every choice, only the
// squares of the shared generators enter the sign. A cell prints the sign and the label of the product; a minus is a hatched cell, a vanishing product (a shared
// generator is null) an empty one with 0. All squares 0 is the exterior algebra Λ(ℝⁿ) = Cl(0,0,n); squares ±1 give Cl(p,q). Under the table: how many products vanish,
// how many carry a minus, e_F² of the top blade, the labels e_F reaches, the non-zero top pairings — the numbers lens_sch_check.py stores for every choice (P1c,
// compared by tests/engines.test.mjs). The controls are v15's: the number of generators, the square of each, and the three presets. Port of v15 SchullerWidgets.SW2.
import React, { useState, useEffect, useMemo } from 'react';
import { productTable, tableStats, bladeLabel } from '../../engines/schullerEngine.js';
import { FigSvg, Controls, Chips, r1, sub } from './kit.jsx';

const SQ = [1, -1, 0];
const sqTxt = v => (v > 0 ? '+1' : v < 0 ? '−1' : '0');
const name = (a, n) => { const b = bladeLabel(a, n); return b === '1' ? '1' : 'e' + sub(b.slice(1)); };
const okSq = v => Array.isArray(v) && (v.length === 2 || v.length === 3) && v.every(x => SQ.includes(x));

export default function OneTable({ params = {}, lens = null, level = 'research', theme, row }) {
  const [sq, setSq] = useState(okSq(params.sq) ? params.sq : [0, 0]);
  useEffect(() => { setSq(okSq(params.sq) ? params.sq : [0, 0]); }, [params.sq]);   // eslint-disable-line react-hooks/exhaustive-deps
  const n = sq.length, N = 1 << n, tab = useMemo(() => productTable(sq), [sq.join()]), st = useMemo(() => tableStats(sq), [sq.join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  const p = sq.filter(s => s === 1).length, q = sq.filter(s => s === -1).length, r = n - p - q;
  const C = n === 2 ? 64 : 38, X0 = 48, Y0 = 26, W = Math.max(420, X0 + N * C + 8), H = Y0 + N * C + 66;
  return (
    <div className="fig fig-one-table">
      <FigSvg id="one-table" row={row} viewBox={`0 0 ${W} ${H}`}>
        <defs>
          <pattern id="one-table-hatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="5" className="stroke-muted" style={{ strokeOpacity: 0.45 }} /></pattern>
        </defs>
        <g data-squares={sq.join(',')} data-zeros={st.zeros} data-minus={st.minus}>
          {Array.from({ length: N }, (_, b) => <text key={'c' + b} x={X0 + b * C + C / 2} y={Y0 - 8} textAnchor="middle" className="t-small t-bold">{name(b, n)}</text>)}
          {tab.map((rowCells, a) => (
            <g key={a}>
              <text x={X0 - 6} y={Y0 + a * C + C / 2 + 4} textAnchor="end" className="t-small t-bold">{name(a, n)}</text>
              {rowCells.map((c, b) => (
                <g key={b} data-ab={`${a},${b}`} data-sign={c.sign} data-label={c.label}>
                  <rect x={X0 + b * C + 1} y={Y0 + a * C + 1} width={C - 2} height={C - 2} rx={3} className="on-panel" style={{ stroke: 'var(--line)' }} />
                  {c.sign < 0 && <rect x={X0 + b * C + 1} y={Y0 + a * C + 1} width={C - 2} height={C - 2} rx={3} style={{ fill: 'url(#one-table-hatch)', stroke: 'var(--fg)', strokeWidth: 0.8 }} />}
                  <text x={X0 + b * C + C / 2} y={Y0 + a * C + C / 2 + 4} textAnchor="middle" className={c.sign === 0 ? 't-tiny t-muted' : n === 2 ? 't-small' : 't-tiny'}>{c.sign === 0 ? '0' : (c.sign < 0 ? '−' : '') + name(c.label, n)}</text>
                </g>
              ))}
            </g>
          ))}
        </g>
        <g transform={`translate(4, ${Y0 + N * C + 18})`}>
          <text x={0} y={0} className="t-mono t-tiny">{`Cl(${p},${q},${r}): ${st.zeros} of ${N * N} products vanish, ${st.minus} carry a minus`}</text>
          <text x={0} y={16} className="t-mono t-tiny" data-ef={st.eF_sq}>{`e_F² = ${sqTxt(st.eF_sq)} · e_F reaches ${st.eF_rank} of ${N} labels (2^(p+q) = ${2 ** (p + q)}) · top pairings ${st.pair}`}</text>
          <text x={0} y={32} className="t-tiny t-muted">{r === n ? 'all squares 0: the exterior algebra Λ(ℝⁿ)' : r ? 'a null generator: e_F² = 0' : 'r = 0: e_F invertible'}</text>
        </g>
      </FigSvg>
      <Controls label="squares">
        <Chips label="generators" items={[2, 3]} value={n} onPick={k => setSq(s => (k > s.length ? [...s, 0] : s.slice(0, k)))} param="n" mono />
        {sq.map((s, i) => <Chips key={i} label={`e${sub(i + 1)}²`} items={SQ} value={s} onPick={v => setSq(a => a.map((x, j) => (j === i ? v : x)))} render={sqTxt} param="sq" mono />)}
        <span className="fig-group" data-param="sq">{[['zero', 'all 0: Λ(ℝⁿ)'], ['plus', 'all +1'], ['minus', 'all −1']].map(([k, lab]) => <button key={k} type="button" className="fig-btn" data-param="sq" onClick={() => setSq(Array(n).fill(k === 'zero' ? 0 : k === 'plus' ? 1 : -1))}>{lab}</button>)}</span>
      </Controls>
    </div>
  );
}
OneTable.meta = { id: 'one-table', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
OneTable.data = (params = {}) => { const sq = okSq(params.sq) ? params.sq : [0, 0]; return { squares: sq, table: productTable(sq), stats: tableStats(sq) }; };
