// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure einstein-form-identity (step 10): the stored results of a4_einstein_tensor.py (engines/gravityChecks.js A4, every number read back from the shipped log by
// tests/engines.test.mjs), not a live computation. For n = 3, 4, 5, three lanes: the floating-point third route (numpy, five-point finite differences) against the
// exact Einstein tensor, as its worst relative error on a log scale with the script's bound 10⁻⁵ as a line; the exact routes (the engine's E_a against
// −(G − Λ_n δ)·Θ, rational arithmetic), whose residual is 0 in every component of every frame and c; and the wrong versions that must differ from the engine
// (Ricci for Einstein, trace coefficient 1, a wrong Λ_n, the sign +1), each as a filled square when it differed on all its samples.
import React from 'react';
import { A4 } from '../../engines/gravityChecks.js';
import { FigSvg, r1 } from './kit.jsx';

const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const pow10 = e => '10' + String(e).split('').map(c => SUP[c]).join('');
const sci = v => { const e = Math.floor(Math.log10(v)), m = v / 10 ** e; return `${+m.toFixed(1)}·${pow10(e)}`; };

export default function EinsteinFormIdentity({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const W = 420, H = 270, xl = 44, xr = 330, lo = -10, hi = -4, lane1 = [46, 146], yExact = 184, yCtl = 230;
  const X = j => xl + 46 + j * ((xr - xl - 92) / 2), Y = v => lane1[0] + ((hi - Math.log10(v)) / (hi - lo)) * (lane1[1] - lane1[0]);
  const ctl = n => A4.controls.filter(c => c[1] === n);
  return (
    <div className="fig fig-einstein-form-identity">
      <FigSvg id="einstein-form-identity" row={row} viewBox={`0 0 ${W} ${H}`}>
        {A4.cases.map((c, j) => <text key={'h' + c.n} x={X(j)} y={14} textAnchor="middle" className="t-mono t-small t-bold">{`n = ${c.n}`}</text>)}
        {/* lane 1: the floating-point route, log scale */}
        <text x={8} y={34} className="t-tiny">{research ? 'floating-point route: worst relative error' : 'by numbers: the largest error'}</text>
        {[-4, -6, -8, -10].map(e => <g key={e}><line x1={xl} y1={r1(Y(10 ** e))} x2={xr} y2={r1(Y(10 ** e))} className="hair-2" /><text x={xl - 4} y={r1(Y(10 ** e) + 3.5)} textAnchor="end" className="t-mono t-micro t-muted">{pow10(e)}</text></g>)}
        <line x1={xl} y1={r1(Y(A4.bound))} x2={xr} y2={r1(Y(A4.bound))} className="stroke-ink" style={{ strokeWidth: 1.2, strokeDasharray: '5 3' }} data-bound={A4.bound} />
        <text x={xr + 4} y={r1(Y(A4.bound) + 3.5)} className="t-mono t-tiny">{research ? `bound ${pow10(-5)}` : 'limit'}</text>
        {A4.cases.map((c, j) => (
          <g key={'f' + c.n} data-n={c.n} data-residual={c.fdRelErr}>
            <title>{`n = ${c.n}: the floating-point Einstein tensor is within ${sci(c.fdRelErr)} of the exact one (bound ${pow10(-5)})`}</title>
            <line x1={X(j)} y1={lane1[1]} x2={X(j)} y2={r1(Y(c.fdRelErr))} className="hair" />
            <circle cx={X(j)} cy={r1(Y(c.fdRelErr))} r={4.5} className="ink" />
            <text x={X(j) + 8} y={r1(Y(c.fdRelErr) + 3.5)} className="t-mono t-tiny">{sci(c.fdRelErr)}</text>
          </g>
        ))}
        {/* lane 2: the exact routes */}
        <text x={8} y={yExact - 16} className="t-tiny">{research ? 'exact routes: residual in every component' : 'exactly: what is left over'}</text>
        <line x1={xl} y1={yExact} x2={xr} y2={yExact} className="hair" />
        {A4.cases.map((c, j) => (
          <g key={'e' + c.n} data-n={c.n} data-exact={c.frames * A4.cValues.length * c.n * c.n}>
            <title>{`n = ${c.n}: residual 0 in all ${c.n * c.n} components, ${c.frames} frames × ${A4.cValues.length} values of c; ratio ${c.ratio}, Λ/c = ${c.lambdaOverC}`}</title>
            <circle cx={X(j)} cy={yExact} r={4.5} className="ink" />
            <text x={X(j) + 8} y={yExact + 4} className="t-mono t-tiny">{research ? `0 (${c.frames * A4.cValues.length * c.n * c.n})` : '0'}</text>
          </g>
        ))}
        {/* lane 3: the wrong versions */}
        <text x={8} y={yCtl - 14} className="t-tiny">{research ? 'wrong versions: each differs on all its samples' : 'wrong answers: all caught'}</text>
        {A4.cases.map((c, j) => ctl(c.n).map(([name, , diff, of], t) => (
          <g key={`c${c.n}-${t}`} data-n={c.n} data-control={t}>
            <title>{`n = ${c.n}: "${name}" differs from the engine on ${diff} of ${of} samples`}</title>
            <rect x={r1(X(j) - 24 + t * 12.5)} y={yCtl - 5} width={9} height={9} rx={1.5} className={diff === of ? 'ink' : 'on-panel'} style={diff === of ? undefined : { stroke: 'var(--fg)' }} />
          </g>
        )))}
        {research && <text x={8} y={H - 8} className="t-mono t-tiny t-muted">{`a4_einstein_tensor.py · c ∈ {${A4.cValues.join(', ')}} · ${A4.fails} fails`}</text>}
      </FigSvg>
    </div>
  );
}
EinsteinFormIdentity.meta = { id: 'einstein-form-identity', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
EinsteinFormIdentity.data = () => JSON.parse(JSON.stringify(A4));
