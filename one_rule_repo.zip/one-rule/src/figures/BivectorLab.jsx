// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure bivector-lab: a bivector B = Σ b_ij e_ij of a cell with n = 4 squares to S + W e1234 (the kernel's product, engines/labels.js bivector4); the squares λ of its two
// commuting simple parts solve λ² − S λ + W² I²/4 = 0, I² = (−1)^q. The (S, W) plane shows where the roots are complex (I² = +1 and |W| > |S|), the point of B, and,
// as bars, the share of complex roots among 400 sampled integer bivectors in each of the five signatures (sampleBivectors, the same seed on every machine).
// Port of v15 LabelsWidgets.BivectorLab. Research level only.
import React, { useState, useMemo } from 'react';
import { bivectorLab, sampleBivectors, SIGS4, BIV_NAMES } from '../../engines/labels.js';
import { FigSvg, Controls, Stepper, Chips, r1, f2, sub } from './kit.jsx';

const PRESETS = [[1, 0, 0, 0, 0, 0], [1, 0, 0, 0, 0, 1], [1, 0, 0, 0, -1, 0], [1, 1, 0, 0, 1, 0]];
const bname = nm => 'e' + sub(nm.slice(1));
const presetName = c => c.map((x, i) => (x ? `${x < 0 ? '−' : '+'}${Math.abs(x) === 1 ? '' : Math.abs(x)}${bname(BIV_NAMES[i])}` : '')).join('').replace(/^\+/, '') || '0';
let MC = null; const mcAll = () => MC || (MC = SIGS4.map(([p, q]) => ({ p, q, ...sampleBivectors(p, q, 400) })));

export default function BivectorLab({ params = {}, lens = null, level = 'research', theme, row }) {
  const [si, setSi] = useState(Number.isInteger(params.signature) ? params.signature : 2);
  const [co, setCo] = useState(Array.isArray(params.coef) && params.coef.length === 6 ? params.coef : PRESETS[3]);
  const [p, q] = SIGS4[si], v = useMemo(() => bivectorLab(p, q, co), [p, q, co]), mc = useMemo(mcAll, []);
  const R = Math.max(6, Math.abs(v.S), Math.abs(v.W)) * 1.15, X = u => r1(110 + u / R * 92), Y = u => r1(110 - u / R * 92);
  const lam = v.lam.map(([re, im]) => (im ? `${f2(re)} ${im > 0 ? '+' : '−'} ${f2(Math.abs(im))}i` : f2(re))).join(',  ');
  return (
    <div className="fig fig-bivector-lab">
      <FigSvg id="bivector-lab" row={row} viewBox="0 0 520 240">
        {/* the (S, W) plane: complex roots in the wedge |W| > |S| when I² = +1 */}
        <rect x={18} y={18} width={184} height={184} className="hair-2" />
        {v.I2 > 0 && <polygon points={`110,110 ${X(R)},${Y(R)} ${X(-R)},${Y(R)}`} className="ink" style={{ fillOpacity: 0.1 }} />}
        {v.I2 > 0 && <polygon points={`110,110 ${X(R)},${Y(-R)} ${X(-R)},${Y(-R)}`} className="ink" style={{ fillOpacity: 0.1 }} />}
        <line x1={18} y1={110} x2={202} y2={110} className="hair" /><line x1={110} y1={18} x2={110} y2={202} className="hair" />
        <text x={198} y={104} textAnchor="end" className="t-small t-muted">S</text><text x={116} y={30} className="t-small t-muted">W</text>
        {v.I2 > 0 && <text x={110} y={44} textAnchor="middle" className="t-small">complex</text>}
        <circle cx={X(v.S)} cy={Y(v.W)} r={5.5} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 2 }} />
        <text x={110} y={222} textAnchor="middle" className="t-mono t-small">{`Cl(${p},${q}) · I² = ${v.I2 > 0 ? '+1' : '−1'}`}</text>
        {/* the bars: share of complex roots among 400 sampled bivectors per signature */}
        <text x={250} y={24} className="t-small t-muted">complex roots, 400 samples</text>
        {mc.map((m, i) => { const fr = m.complex / Math.max(1, m.real + m.complex), y = 40 + i * 34, on = i === si; return (
          <g key={i}>
            <text x={250} y={y + 15} className={'t-mono t-small' + (on ? ' t-bold' : '')}>{`Cl(${m.p},${m.q})`}</text>
            <rect x={312} y={y + 3} width={150} height={16} rx={3} className="hair-2" />
            {fr > 0 && <rect x={312} y={y + 3} width={r1(Math.max(4, fr * 150))} height={16} rx={3} className="ink" style={{ fillOpacity: 0.55 }} />}
            <text x={512} y={y + 15} textAnchor="end" className="t-mono t-small">{`${Math.round(fr * 100)}%`}</text>
          </g>); })}
      </FigSvg>
      <dl className="fig-readout">
        <div><dt>S</dt><dd>{f2(v.S)}</dd></div><div><dt>W</dt><dd>{f2(v.W)}</dd></div><div><dt>disc</dt><dd>{f2(v.disc)}</dd></div>
        <div><dt>λ</dt><dd>{lam}</dd></div><div><dt>kind</dt><dd>{v.label}</dd></div>
      </dl>
      <Controls label="bivector">
        <Chips label="cell" items={SIGS4.map((_, i) => i)} value={si} onPick={setSi} render={i => `Cl(${SIGS4[i][0]},${SIGS4[i][1]})`} param="signature" mono />
        <Chips label="preset" items={PRESETS} value={co} onPick={c => setCo(c)} isOn={(x, val) => x.join() === val.join()} render={presetName} param="coef" mono />
        {BIV_NAMES.map((nm, i) => <Stepper key={nm} label={'b' + sub(nm.slice(1))} value={co[i]} min={-3} max={3} display={x => (x < 0 ? '−' + -x : String(x))} onChange={x => setCo(co.map((y, j) => (j === i ? x : y)))} param="coef" />)}
      </Controls>
    </div>
  );
}
BivectorLab.meta = { id: 'bivector-lab', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
BivectorLab.data = (params = {}) => { const si = Number.isInteger(params.signature) ? params.signature : 2, co = Array.isArray(params.coef) && params.coef.length === 6 ? params.coef : PRESETS[3], [p, q] = SIGS4[si]; return { cell: [p, q], coef: co, ...bivectorLab(p, q, co), samples: mcAll() }; };
