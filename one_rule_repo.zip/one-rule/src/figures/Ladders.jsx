// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure ladders (the Furey papers): the two ladders of reflections of the Roadmap papers as furey_papers_check.py stores them (engines/stored.js FUREY_PAPERS
// roadmap, nothing recomputed). Top: the Spin(10) line, 45 → 21 → 15 → 11 → 10; middle: the SU(5) line, 24 → 12 → 10 → 9; each bar is the dimension of what is
// left after the reflections switched on so far (𝕆, 𝕆′, ℍ, ℂ). Bottom: the Part III shortcuts, the dimensions of four intersections (24, 12, 9, 9). The control is
// v15's slider of the number of reflections switched on (interactive entry k); the bars of that step are solid and its reflections are printed. Port of v15
// FureyWidgets.Cascade.
import React, { useState, useEffect } from 'react';
import { FUREY_PAPERS } from '../../engines/stored.js';
import { FigSvg, Controls, Range, r1, pick } from './kit.jsx';

const R = FUREY_PAPERS.roadmap;
const REFL = { O: '𝕆', Or: '𝕆′', H: 'ℍ', C: 'ℂ' };
const SHORT = [['vector_spinor', 'spinor intersection'], ['three_way_O', 'three-way with 𝕆'], ['four_way_no_O', 'four-way without 𝕆'], ['five_way_O_H_C', 'five-way (𝕆, ℍ, ℂ)']];
const shortName = nm => (nm.includes('=') ? nm.split('=')[1].trim() : nm).replace(/ \(->O\)$/, '').replace(/\+/g, '⊕').replace('Pati-Salam', 'Pati–Salam').replace('Left-Right', 'Left–Right');
const refl = list => list.map(r => REFL[r] || r).join(', ') || '—';

export default function Ladders({ params = {}, lens = null, level = 'research', theme, row }) {
  const [k, setK] = useState(pick(params.k, v => Number.isInteger(v) && v >= 0 && v <= 4, 0));
  useEffect(() => { setK(pick(params.k, v => Number.isInteger(v) && v >= 0 && v <= 4, 0)); }, [params.k]);
  const lines = [['Spin(10) line', R.spin10_line, 45, 24], ['SU(5) line', R.su5_line, 24, 132]];
  const bar = (list, max, y0, kk, key) => list.map((s, j) => {
    const x = 34 + j * 76, h = 64 * s.dim / max, on = j === kk;
    return (
      <g key={key + j} data-line={key} data-step={j} data-dim={s.dim} data-on={on ? 1 : 0}>
        <title>{`${shortName(s.name)}: dimension ${s.dim}; reflections ${refl(s.reflections)}`}</title>
        <rect x={x} y={r1(y0 + 64 - h)} width={58} height={r1(h)} rx={3} className="ink" style={{ fillOpacity: on ? 0.85 : 0.18, stroke: 'var(--fg)', strokeWidth: on ? 1.6 : 0.6 }} />
        <text x={x + 29} y={r1(Math.min(y0 + 58, y0 + 64 - h + 13))} textAnchor="middle" className="t-mono t-small t-bold" style={on ? { fill: 'var(--panel)' } : undefined}>{s.dim}</text>
        <text x={x + 29} y={y0 + 78} textAnchor="middle" className="t-micro">{shortName(s.name)}</text>
      </g>
    );
  });
  const kA = Math.min(k, R.spin10_line.length - 1), kB = Math.min(k, R.su5_line.length - 1);
  return (
    <div className="fig fig-ladders">
      <FigSvg id="ladders" row={row} viewBox="0 0 420 334">
        {lines.map(([name, list, max, y0], i) => (
          <g key={name}>
            <text x={4} y={y0 - 8} className="t-small t-muted">{name}</text>
            {bar(list, max, y0, i === 0 ? kA : kB, i === 0 ? 'spin10' : 'su5')}
          </g>
        ))}
        <text x={4} y={238} className="t-mono t-tiny" data-k={k}>{`${k} reflection${k === 1 ? '' : 's'}: ${refl(R.spin10_line[kA].reflections)} → ${R.spin10_line[kA].dim} · ${refl(R.su5_line[kB].reflections)} → ${R.su5_line[kB].dim}`}</text>
        <text x={4} y={254} className="t-small t-muted">Part III shortcuts (intersections)</text>
        {SHORT.map(([key, name], j) => { const d = R.intersections[key], x = 34 + j * 96, h = 40 * d / 24; return (
          <g key={key} data-intersection={key} data-dim={d}>
            <rect x={x} y={r1(314 - h)} width={70} height={r1(h)} rx={3} className="ink" style={{ fillOpacity: 0.55 }} />
            <text x={x + 35} y={r1(314 - h - 4)} textAnchor="middle" className="t-mono t-small t-bold">{d}</text>
            <text x={x + 35} y={327} textAnchor="middle" className="t-micro">{name}</text>
          </g>); })}
      </FigSvg>
      <Controls label="reflections">
        {level !== 'learner' && <Range label="reflections switched on" value={k} min={0} max={4} step={1} onChange={setK} param="k" />}
      </Controls>
    </div>
  );
}
Ladders.meta = { id: 'ladders', lenses: [], learner: false };
/** the numbers the figure draws, for the frame's data download */
Ladders.data = () => ({ spin10_line: R.spin10_line, su5_line: R.su5_line, intersections: R.intersections });
