// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure dirac-pic: the Dirac equation ∇ψJ = mψγ₀ in the even subalgebra of Cl(1,3) as incidences (engines/spinEngine.js diracPic; every sign from the kernel, the 40
// incidences compared with checks/selfcheck/equations.json by tests/engines.test.mjs). The 8 even blades (the components of ψ) are the rows on the left, the 8 odd blades
// (the equations) the rows on the right, in the order of the v15 picture; the five kinds of term (∂t, ∂x, ∂y, ∂z and the mass term m) are drawn side by side as five
// panels over the same rows, so every panel is a one-to-one map from the even to the odd blades (v15 told the kinds apart by colour; the design keeps colour for the clock).
// Research level: a term with sign −1 is dashed. Lenses: hestenes prints the blades as γ-words (γ₀₁ = γ₀γ₁), cube / bits as bit strings, prime / primes as products of
// primes, clifford as e-words; the default is the v15 naming by axes (t, x, y, z). The control is v15's: pick an equation (an odd blade on the right; interactive entry
// hot) and its terms stand out, with their kinds listed under the panels. Port of v15 EquationsSection.DiracPic.
import React, { useMemo, useState, useEffect } from 'react';
import { diracPic } from '../../engines/spinEngine.js';
import { label, sigVec } from '../../engines/labels.js';
import { FigSvg, sub, r1, labelLens } from './kit.jsx';

const EPS13 = sigVec(1, 3);
const AX = ['t', 'x', 'y', 'z'];
const HEAD = { dt: ['∂t', 't'], dx: ['∂x', 'x'], dy: ['∂y', 'y'], dz: ['∂z', 'z'], m: ['m', 'mass'] };
const pc = m => { let c = 0; for (let x = m; x; x &= x - 1) c++; return c; };

/** the name of a blade of Cl(1,3) in the current lens (bit 0 = t) */
export function bladeName(m, lens, research = true) {
  if (lens === 'hestenes') return m ? 'γ' + sub([0, 1, 2, 3].filter(i => (m >> i) & 1).join('')) : '1';
  const L = labelLens(lens);
  if (L === 'bits' || L === 'primes' || L === 'set' || L === 'sigword' || L === 'bitsq' || L === 'clifford') return label(m, L, EPS13);
  return m ? AX.filter((_, i) => (m >> i) & 1).join('') : '1';
}

function Dot({ x, y, m, side }) {
  const g = pc(m);
  if (side === 'L' && (g === 0 || g === 4)) return <rect x={r1(x - 3.4)} y={r1(y - 3.4)} width={6.8} height={6.8} className="ink" />;
  if (side === 'R' && g === 3) return <circle cx={x} cy={y} r={3.4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.2 }} />;
  return <circle cx={x} cy={y} r={3.4} className="ink" />;
}

export default function DiracPic({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const D = useMemo(() => diracPic(), []);
  const okHot = v => D.odd.includes(v), [hot, setHot] = useState(okHot(params.hot) ? params.hot : null);
  useEffect(() => { setHot(okHot(params.hot) ? params.hot : null); }, [params.hot]);   // eslint-disable-line react-hooks/exhaustive-deps
  const used = hot == null ? [] : D.incidences.filter(e => e.to === hot), pickHot = m => setHot(h => (h === m ? null : m));
  const W = 420, top = 40, rh = 24, x0 = 54, pw = 60, gap = 4, H = top + 8 * rh + (research ? 30 : 12) + (hot != null ? 18 : 0);
  const yl = new Map(D.even.map((m, i) => [m, top + rh * (i + 0.5)])), yr = new Map(D.odd.map((m, i) => [m, top + rh * (i + 0.5)]));
  const nm = m => bladeName(m, lens, research), xr = x0 + 5 * pw + 4 * gap + 6;
  return (
    <div className="fig fig-dirac-pic">
      <FigSvg id="dirac-pic" row={row} viewBox={`0 0 ${W} ${H}`}>
        {research && <text x={x0 - 8} y={18} textAnchor="end" className="t-tiny t-muted">ψ</text>}
        {research && <text x={xr} y={18} className="t-tiny t-muted">equation</text>}
        {D.even.map(m => <text key={'l' + m} x={x0 - 8} y={r1(yl.get(m) + 3.5)} textAnchor="end" className="t-mono t-small">{nm(m)}</text>)}
        {D.odd.map(m => (
          <g key={'r' + m} role="button" tabIndex={0} aria-pressed={hot === m} aria-label={`equation ${nm(m)}`} data-param="hot" data-equation={m} className="fig-cell"
            onClick={() => pickHot(m)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickHot(m); } }}>
            <rect x={xr - 4} y={r1(yr.get(m) - rh / 2 + 2)} width={W - xr} height={rh - 4} rx={3} className="hit" />
            {hot === m && <rect x={xr - 4} y={r1(yr.get(m) - rh / 2 + 2)} width={W - xr} height={rh - 4} rx={3} className="ink" style={{ fillOpacity: 0.1 }} />}
            <text x={xr} y={r1(yr.get(m) + 3.5)} className={'t-mono t-small' + (hot === m ? ' t-bold' : '')}>{nm(m)}</text>
          </g>
        ))}
        {D.kinds.map((k, j) => {
          const px = x0 + j * (pw + gap), a = px + 8, b = px + pw - 8, inc = D.incidences.filter(e => e.kind === k);
          return (
            <g key={k} data-kind={k}>
              <title>{`${HEAD[k][0]}: ${inc.length} terms`}</title>
              <rect x={px} y={top - 6} width={pw} height={8 * rh + 12} rx={4} className="hair-2" />
              <text x={px + pw / 2} y={top - 12} textAnchor="middle" className={'t-small' + (research ? ' t-mono' : '')}>{HEAD[k][research ? 0 : 1]}</text>
              {inc.map(e => (
                <line key={e.from} x1={a} y1={r1(yl.get(e.from))} x2={b} y2={r1(yr.get(e.to))} className="stroke-ink" data-from={e.from} data-to={e.to} data-sign={e.sign}
                  style={{ strokeWidth: hot === e.to ? 2 : 1.2, strokeOpacity: hot == null ? 0.85 : hot === e.to ? 1 : 0.12, strokeDasharray: research && e.sign < 0 ? '3 2.5' : undefined }}>
                  <title>{`${HEAD[k][0]}: ${nm(e.from)} → ${nm(e.to)}${research ? ` (${e.sign > 0 ? '+' : '−'})` : ''}`}</title>
                </line>
              ))}
              {D.even.map(m => <Dot key={'a' + m} x={a} y={r1(yl.get(m))} m={m} side="L" />)}
              {D.odd.map(m => <Dot key={'b' + m} x={b} y={r1(yr.get(m))} m={m} side="R" />)}
            </g>
          );
        })}
        {research && (
          <g transform={`translate(${x0}, ${top + 8 * rh + 22})`}>
            <line x1={0} y1={-4} x2={18} y2={-4} className="stroke-ink" style={{ strokeWidth: 1.2 }} /><text x={22} y={0} className="t-tiny">+</text>
            <line x1={40} y1={-4} x2={58} y2={-4} className="stroke-ink" style={{ strokeWidth: 1.2, strokeDasharray: '3 2.5' }} /><text x={62} y={0} className="t-tiny">−</text>
            <text x={5 * pw + 4 * gap} y={0} textAnchor="end" className="t-mono t-tiny t-muted">{`J = ${D.J.sign < 0 ? '−' : ''}${nm(D.J.mask)} · ${D.incidences.length} terms`}</text>
          </g>
        )}
        {hot != null && <text x={x0} y={H - 6} className="t-mono t-tiny" data-hot={hot} data-terms={used.length}>{`${nm(hot)}: ${used.length} terms — ${used.map(e => HEAD[e.kind][research ? 0 : 1] + (research ? ` ${nm(e.from)}${e.sign < 0 ? ' (−)' : ''}` : '')).join(', ')}`}</text>}
      </FigSvg>
    </div>
  );
}
DiracPic.meta = { id: 'dirac-pic', lenses: ['hestenes', 'cube', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
DiracPic.data = () => { const D = diracPic(); return { cell: [1, 3], even: D.even, odd: D.odd, J: D.J, incidences: D.incidences }; };
