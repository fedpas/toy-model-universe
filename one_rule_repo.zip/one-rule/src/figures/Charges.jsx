// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure charges (calibration: from the field to the motion): a charge moving in the fields, in six situations. The force on the charge is the grade-1 part of F u,
// read from the term table that maxwell_selfcheck.py checks exactly (engines/chargeEngine.js, which reads that table from engines/maxwellData.js), and the motion is
// RK4 in the proper time (floating point). Top: the plane seen from above (x right, y up) with the path, the charge, its velocity (thin arrow), the electric field at it
// (dashed arrow), the magnetic field (⊙ out of the page, ⊗ into it) and the force (heavy arrow). Below: the speed against time with the limit c, or, for the spiral and
// the light wave, the side view (z right, x up; for the wave also in the frame that moves with the mean drift, z stretched four times). The figure opens on a run
// already advanced by four seconds of its animation (longer, until its check can be read), so the path is on the page; Play goes on (paused until pressed), Reset starts again. The readouts: t, τ, γ, v/c,
// u·u − 1, and the check of the situation (the closed form against the run). The controls are v15's: the situation, the sliders of its field and start (research
// level), the frame of the wave, Play / Step / Reset / speed. Port of v15 ChargesWidget.
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { SPEC, PRESET_IDS, defaults, initRun, advance, readout } from '../../engines/chargeEngine.js';
import { FigSvg, Controls, Chips, Range, PlayButton, PlayAction, useReducedMotion, r1, f2, arrowHead } from './kit.jsx';

const NAME = { circle: ['B only: a circle', 'a circle'], hyper: ['E only: a speed limit', 'a speed limit'], crossed: ['E and B crossed: a drift', 'a drift'], spiral: ['E parallel to B: a spiral', 'a spiral'], orbit: ['a point charge: an orbit', 'an orbit'], wave: ['a light wave: a figure of eight', 'a figure of eight'] };
const PNAME = { B: 'B', E: 'E', rho: 'E / B', qm: 'q/m', v0: 'starting speed', kappa: 'attraction κ', a: 'wave strength a' };
const W = 360, PH = 250;
const f3 = x => { const r = Math.abs(x) < 5e-5 ? 0 : Math.round(x * 1000) / 1000; return String(r).replace('-', '−'); };
const ext = pts => pts.reduce((b, [x, y]) => [Math.min(b[0], x), Math.max(b[1], x), Math.min(b[2], y), Math.max(b[3], y)], [Infinity, -Infinity, Infinity, -Infinity]);
function makeView(run, sp, a, b, H) {
  const cur = [a(run.s), b(run.s)]; let cx, cy, half;
  if (sp.view === 'follow') { cx = cur[0]; cy = cur[1]; half = sp.ext; } else { const pts = run.trail.map(p => [a([0, p[0], p[1], p[2]]), b([0, p[0], p[1], p[2]])]).concat([cur]); const [x0, x1, y0, y1] = ext(pts); cx = (x0 + x1) / 2; cy = (y0 + y1) / 2; half = Math.max(sp.ext, 0.58 * Math.max(x1 - x0, y1 - y0) + 0.15); }
  const s = Math.min(W, H) / (2 * half); return { X: v => W / 2 + (v - cx) * s, Y: v => H / 2 - (v - cy) * s, s, cx, cy };
}
const arr = (v, k = 1) => { const L = Math.hypot(v[0], v[1]); return L < 1e-9 ? [0, 0] : [v[0] / L * (12 + 26 * Math.tanh(L * k)), -v[1] / L * (12 + 26 * Math.tanh(L * k))]; };
function Arrow({ x1, y1, dx, dy, w = 1.6, dash, kind }) {
  if (Math.hypot(dx, dy) < 1.5) return null;
  return <g data-arrow={kind}><line x1={r1(x1)} y1={r1(y1)} x2={r1(x1 + dx)} y2={r1(y1 + dy)} className="stroke-ink" style={{ strokeWidth: w, strokeDasharray: dash }} /><path d={arrowHead(x1, y1, x1 + dx, y1 + dy, 6)} className="ink" /></g>;
}
const Bmark = ({ x, y, Bz }) => (Math.abs(Bz) > 1e-9 ? <g data-b={Bz > 0 ? 'out' : 'in'}><circle cx={r1(x)} cy={r1(y)} r={6} className="stroke-ink" style={{ strokeWidth: 1.3 }} />{Bz > 0 ? <circle cx={r1(x)} cy={r1(y)} r={1.6} className="ink" /> : <path d={`M${r1(x - 4)} ${r1(y - 4)}l8 8M${r1(x + 4)} ${r1(y - 4)}l-8 8`} className="stroke-ink" />}</g> : null);

const OPEN = new Map();
/** the opening run of a situation: advanced by four seconds of its animation (rate × 4 of simulated time), or longer — up to twelve — until its check has a measured value
 *  (half a turn, a turn in the drift frame, two perihelia, a cycle of the wave), with the speed history */
export function openingRun(id, p = defaults(id)) {
  const key = id + JSON.stringify(p);
  if (!OPEN.has(key)) {
    const run = initRun(id, p), hist = [];
    for (let i = 0; i < 360; i++) { advance(run, p, SPEC[id].rate * 4 / 120); const o = readout(run, p); hist.push([run.s[0], o.speed]); if (i >= 119 && (!o.check || o.check.measured !== null)) break; }
    OPEN.set(key, { run, hist });
  }
  const o = OPEN.get(key); return { run: { ...o.run, s: o.run.s.slice(), trail: o.run.trail.map(t => t.slice()), peri: o.run.peri.slice(), cyc: o.run.cyc.map(c => c.slice()), P0: { ...o.run.P0 } }, hist: o.hist.map(h => h.slice()) };
}

export default function Charges({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const pid0 = PRESET_IDS.includes(params.preset) ? params.preset : 'circle';
  const [id, setId] = useState(pid0), [P, setP] = useState(defaults(pid0)), [speed, setSpeed] = useState(1), [frame, setFrame] = useState('lab');
  const [playing, setPlaying] = useState(false), [, setTick] = useState(0), reduced = useReducedMotion();
  useEffect(() => { setId(pid0); setP(defaults(pid0)); }, [pid0]);
  const sim = useRef(null);
  if (!sim.current || sim.current.id !== id) sim.current = { id, ...openingRun(id, defaults(id)) };
  const S = sim.current, run = S.run, sp = SPEC[id];
  const adv = dt => { advance(run, P, dt); const o = readout(run, P); if (!S.hist.length || run.s[0] - S.hist[S.hist.length - 1][0] > 0.05) { S.hist.push([run.s[0], o.speed]); if (S.hist.length > 1500) S.hist.splice(0, 300); } setTick(x => x + 1); };
  useEffect(() => { if (!playing || reduced) return undefined; const k = setInterval(() => adv(sp.rate * speed * 0.033), 33); return () => clearInterval(k); }, [playing, reduced, speed, id, P]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = { playing, reduced, play: () => setPlaying(x => !x), step: () => adv(sp.rate * 0.25) };
  const fresh = (nid, np) => { sim.current = { id: nid, run: initRun(nid, np), hist: [] }; setTick(x => x + 1); };
  const pickPreset = pid => { const np = defaults(pid); setId(pid); setP(np); setPlaying(false); sim.current = { id: pid, ...openingRun(pid, np) }; };
  const onParam = (q, v) => { const np = { ...P, [q.id]: v }; setP(np); if (q.live) { if (run.steps === 0) run.P0 = { ...np }; else run.changed = true; setTick(x => x + 1); } else fresh(id, np); };
  const o = readout(run, P), side = id === 'spiral' || id === 'wave', c = o.check;
  // the top view
  const vt = makeView(run, sp, s => s[1], s => s[2], PH), px = vt.X(run.s[1]), py = vt.Y(run.s[2]);
  const Ev = [o.F[0], o.F[1]], Bz = o.F[5], fo = [o.f[1], o.f[2]], u = [o.u[1], o.u[2]], cen = id === 'orbit' ? [vt.X(0), vt.Y(0)] : null;
  const grid = ['circle', 'hyper', 'crossed', 'spiral'].includes(id) ? [[60, 50], [180, 50], [300, 50], [60, 150], [180, 150], [300, 150], [60, 230], [180, 230], [300, 230]] : [];
  const top = run.trail.map((p, i) => (i ? 'L' : 'M') + r1(vt.X(p[0])) + ' ' + r1(vt.Y(p[1]))).join('');
  // the side view (spiral, wave) or the speed chart
  const SH = 190, avg = frame === 'avg' && id === 'wave', a = Math.max(0.05, run.changed ? P.a : run.P0.a || P.a || 0.05), vd = a * a / (4 + a * a);
  const vs = side ? (avg ? (() => { const sy = SH / (2 * 1.15 * (a + 0.3)); return { X: v => W / 2 + v * sy * 4, Y: v => SH / 2 - (v - a) * sy }; })() : makeView(run, { ...sp, ext: sp.sideExt || sp.ext }, s => s[3], s => s[1], SH)) : null;
  const zOf = p => (avg ? p[2] - vd * p[3] : p[2]);
  const Tm = Math.max(10, S.hist.length ? S.hist[S.hist.length - 1][0] : 0), CX = v => 30 + v / Tm * (W - 44), CY = v => SH - 30 - v * (SH - 60);
  const chk = (() => {
    if (run.changed) return 'the field changed in flight: the closed forms belong to the start';
    if (!c) return null; const k = c.kind;
    if (k === 'circle') return c.measured === null ? `radius from the formula γ m v/(q B): ${f3(c.formula)} (half a turn to measure)` : `radius: path ${f3(c.measured)} · formula γ m v/(q B) ${f3(c.formula)}`;
    if (k === 'hyper') return `x: run ${f3(c.measured)} · formula ${f3(c.formula)} · speed ${f3(c.speed)} c (Newton: ${f2(c.newton)} c)`;
    if (k === 'drift') return c.measured === null ? `drift E/B = ${f3(c.formula)} (one turn to measure)` : `mean velocity over ${c.turns} turn${c.turns === 1 ? '' : 's'}: ${f3(c.measured)} · E/B ${f3(c.formula)}`;
    if (k === 'runaway') return `E/B = ${f2(c.rho)} ≥ 1: no drift frame, the charge runs away along E`;
    if (k === 'spiral') return `u_z: run ${f3(c.measured)} · γ₀ sinh(qEτ/m) ${f3(c.formula)}`;
    if (k === 'orbit') return c.measured === null ? `perihelion advance per turn from the formula: ${f2(c.formula)}° (${c.perihelia} perihelia so far)` : `perihelion advance per turn: ${f2(c.measured)}° measured · ${f2(c.formula)}° formula`;
    if (k === 'repulsive') return 'repulsion: the charge is scattered once';
    if (k === 'falls') return `κ/L = ${f2(c.ratio)} ≥ 1: no stable orbit`;
    if (k === 'wave') return c.measured === null ? `u_t − u_z = ${f3(c.conserved)} · mean drift a²/(4 + a²) = ${f3(c.formula)} (one cycle to measure)` : `u_t − u_z = ${f3(c.conserved)} · mean drift ${f3(c.measured)} · a²/(4 + a²) ${f3(c.formula)}`;
    return null;
  })();
  return (
    <div className="fig fig-charges">
      <div className="fig-stack">
        <FigSvg id="charges" row={row} part="seen from above" viewBox={`0 0 ${W} ${PH + (research ? 34 : 20)}`}>
          <rect x={0.5} y={0.5} width={W - 1} height={PH - 1} rx={6} className="hair-2" />
          <g data-preset={id} data-t={f2(o.t)}>
            {grid.map(([gx, gy], i) => (
              <g key={i} style={{ opacity: 0.45 }}>
                {Math.hypot(Ev[0], Ev[1]) > 1e-9 && <Arrow x1={gx} y1={gy} dx={arr(Ev, 0.6)[0] * 0.8} dy={arr(Ev, 0.6)[1] * 0.8} w={1.2} dash="3 2" kind="E-grid" />}
                <Bmark x={gx + 22} y={gy + 18} Bz={Bz} />
              </g>
            ))}
            {cen && <g data-centre={P.kappa >= 0 ? '+' : '−'}><circle cx={r1(cen[0])} cy={r1(cen[1])} r={7} className="ink" /><text x={r1(cen[0])} y={r1(cen[1] + 3.5)} textAnchor="middle" className="t-tiny t-bold" style={{ fill: 'var(--panel)' }}>{P.kappa >= 0 ? '+' : '−'}</text></g>}
            <path d={top} className="stroke-ink" style={{ strokeWidth: 1.5, strokeOpacity: 0.7 }} data-trail={run.trail.length} />
            <Arrow x1={px} y1={py} dx={arr(u, 1.2)[0]} dy={arr(u, 1.2)[1]} w={1.2} kind="velocity" />
            {Math.hypot(Ev[0], Ev[1]) > 1e-9 && <Arrow x1={px} y1={py} dx={arr(Ev, 0.8)[0] * 0.7} dy={arr(Ev, 0.8)[1] * 0.7} w={1.4} dash="4 3" kind="E" />}
            <Bmark x={px - 14} y={py - 14} Bz={Bz} />
            <Arrow x1={px} y1={py} dx={arr(fo, 1)[0]} dy={arr(fo, 1)[1]} w={2.8} kind="force" />
            <circle cx={r1(px)} cy={r1(py)} r={5} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />
            {research && <text x={8} y={16} className="t-tiny t-muted">y ↑ x →</text>}
          </g>
          <text x={4} y={PH + 14} className="t-mono t-tiny" data-speed={o.speed} data-u2={o.u2}>{research ? `t = ${f2(o.t)} · τ = ${f2(o.tau)} · γ = ${f2(o.gamma)} · v/c = ${f3(o.speed)} · u·u − 1 = ${Math.abs(o.u2) < 1e-9 ? '0' : o.u2.toExponential(1)}` : `time ${f2(o.t)} · speed ${f3(o.speed)} of the speed of light`}</text>
          {research && chk && <text x={4} y={PH + 30} className="t-mono t-micro" data-check={c ? c.kind : 'changed'} data-formula={c && Number.isFinite(c.formula) ? c.formula : ''} data-measured={c && Number.isFinite(c.measured) ? c.measured : ''}>{chk}</text>}
        </FigSvg>
        <FigSvg id="charges" row={row} part={side ? 'seen from the side' : 'speed against time'} viewBox={`0 0 ${W} ${SH}`}>
          <rect x={0.5} y={0.5} width={W - 1} height={SH - 1} rx={6} className="hair-2" />
          {side ? (
            <g data-view={avg ? 'drift frame' : 'side'}>
              {id === 'wave' && !avg && Array.from({ length: W / 4 }, (_, i) => { const z = vs.cx + (i * 4 + 2 - W / 2) / vs.s, v = Math.cos(run.s[0] - z); return <rect key={'w' + i} x={i * 4} y={1} width={4} height={SH - 2} className={v > 0 ? 'ink' : 'ink-muted'} style={{ fillOpacity: +(Math.abs(v) * 0.14).toFixed(3) }} />; })}
              <path d={run.trail.map((p, i) => (i ? 'L' : 'M') + r1(vs.X(zOf(p))) + ' ' + r1(vs.Y(p[0]))).join('')} className="stroke-ink" style={{ strokeWidth: 1.5, strokeOpacity: 0.7 }} />
              {(() => { const pz = avg ? run.s[3] - vd * run.s[0] : run.s[3], qx = vs.X(pz), qy = vs.Y(run.s[1]), uu = [o.u[3] - (avg ? vd * o.u[0] : 0), o.u[1]], ff = [o.f[3], o.f[1]]; return (
                <g>
                  <Arrow x1={qx} y1={qy} dx={arr(uu, 1.2)[0]} dy={arr(uu, 1.2)[1]} w={1.2} kind="velocity" />
                  {!avg && <Arrow x1={qx} y1={qy} dx={arr(ff)[0]} dy={arr(ff)[1]} w={2.8} kind="force" />}
                  <circle cx={r1(qx)} cy={r1(qy)} r={5} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />
                </g>); })()}
              {research && <text x={8} y={16} className="t-tiny t-muted">{avg ? "x ↑ z′ → (×4)" : 'x ↑ z →'}</text>}
            </g>
          ) : (
            <g data-view="speed" data-points={S.hist.length}>
              <line x1={30} y1={r1(CY(1))} x2={W - 14} y2={r1(CY(1))} className="stroke-ink" style={{ strokeDasharray: '5 4' }} /><text x={34} y={r1(CY(1) - 4)} className="t-small">c</text>
              <line x1={30} y1={r1(CY(0))} x2={W - 14} y2={r1(CY(0))} className="hair" /><line x1={30} y1={r1(CY(0))} x2={30} y2={r1(CY(1))} className="hair" />
              <text x={8} y={r1(CY(0) + 4)} className="t-mono t-micro">0</text><text x={8} y={r1(CY(1) + 4)} className="t-mono t-micro">1</text>
              <path d={S.hist.map(([tt, v], i) => (i ? 'L' : 'M') + r1(CX(tt)) + ' ' + r1(CY(v))).join('')} className="stroke-ink" style={{ strokeWidth: 1.8 }} />
              <text x={W / 2} y={SH - 8} textAnchor="middle" className="t-tiny t-muted">{research ? 'speed v/c against t' : 'speed against time'}</text>
            </g>
          )}
        </FigSvg>
      </div>
      <Controls label="charges">
        <Chips label={research ? 'situation' : 'what'} items={PRESET_IDS} value={id} onPick={pickPreset} render={k => NAME[k][research ? 0 : 1]} param="preset" />
        {research && sp.params.map(q => <Range key={q.id} label={PNAME[q.id] + (q.live ? '' : ' ↻')} value={P[q.id]} min={q.min} max={q.max} step={q.step} onChange={v => onParam(q, v)} display={f2} param={q.id} />)}
        {research && id === 'wave' && <Chips label="frame" items={['lab', 'avg']} value={frame} onPick={setFrame} render={k => (k === 'lab' ? 'lab' : 'drift frame')} param="frame" />}
        <PlayButton player={player} />
        {research && <PlayAction label="Step" onClick={() => adv(sp.rate * 0.25)} />}
        <PlayAction label="Reset" kind="reset" onClick={() => { fresh(id, P); setPlaying(false); }} />
        {research && <span className="fig-group" data-play="speed">{[0.5, 1, 2].map(k => <button key={k} type="button" className="fig-btn fig-btn-sq" data-play="speed" aria-pressed={speed === k} onClick={() => setSpeed(k)}>{`×${k}`}</button>)}</span>}
      </Controls>
    </div>
  );
}
Charges.meta = { id: 'charges', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
Charges.data = (params = {}) => { const id = PRESET_IDS.includes(params.preset) ? params.preset : 'circle', p = defaults(id), { run } = openingRun(id, p), o = readout(run, p); return { preset: id, params: p, t: o.t, tau: o.tau, gamma: o.gamma, speed: o.speed, u2: o.u2, check: o.check, trail: run.trail.length }; };
