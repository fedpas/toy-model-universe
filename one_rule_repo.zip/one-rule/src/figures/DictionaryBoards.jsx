// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure dictionary-boards (Furey, the dictionary): one entry of the dictionary of dictionary_selfcheck.py (checks/selfcheck/dictionary.json through engines/stored.js;
// nothing recomputed) on three boards. The Peirce simplex: the 8 vertices o, O1, O2, O3, H1, H2, c, r and its 28 edges, the entry's edge drawn heavy with an arrow and
// the other edges of its channel (a perfect matching of the 8 vertices) medium, replica edges dashed. The Fano plane of the 7 channels (the dashed circle is the line
// 1, 10, 11 of the even channels), the entry's channel ringed. The 8-cube: 256 corners, the entry's 8 real faces filled and their 8 ω-partners ringed. The faces are
// then listed in the active lens: bits (cube), prime names (prime), vertex sets (simplex), grades and cosets (clifford), or the edge, Y and Q (furey). The control is v15's
// entry picker (the matter, gauge, diagonal and replica entries). The 16 × 16 coset and prime grids of v15 are left to the Logbook (07 §3). Port of v15 DictionarySection.
import React, { useState, useEffect, useMemo } from 'react';
import { DICTIONARY as D } from '../../engines/stored.js';
import { popcount } from '../../engines/bitrule.js';
import { FigSvg, Controls, r1, arrowHead } from './kit.jsx';

const VERTS = ['o', 'O1', 'O2', 'O3', 'H1', 'H2', 'c', 'r'];
const FANO_POS = { 3: [60, 250], 8: [300, 250], 9: [180, 50], 2: [180, 183], 11: [180, 250], 1: [240, 150], 10: [120, 150] };
const GROUPS = [['matter', 'matter'], ['gauge', 'gauge roots'], ['cartan', 'diagonal'], ['replica', 'replicas']];
export const ENTRIES = [
  ...D.states.map(s => ({ ...s, group: s.kind === 'matter' ? 'matter' : s.kind === 'gauge' ? 'gauge' : 'replica' })),
  ...D.cartan.map(c => ({ ...c, kind: 'cartan', group: 'cartan', channel: 0, classes: [0, c.phase_class] })),
];
const PLAIN = { uL: 'up quark, left-handed', dL: 'down quark, left-handed', uR: 'up quark, right-handed', dR: 'down quark, right-handed', nuL: 'neutrino, left-handed', eL: 'electron, left-handed', eR: 'electron, right-handed', nuR: 'neutrino, right-handed', Wp: 'W plus, from H1 to H2', Wm: 'W minus, from H2 to H1', Y0: 'hypercharge minus 3/8', Q0: 'electric charge minus 3/8', T3: 'weak charge', l3: 'first colour charge', l8: 'second colour charge' };
const plainName = e => { const m = /^(uL|dL|uR|dR)(\d)$/.exec(e.id); if (m) return `${PLAIN[m[1]]}, colour ${m[2]}`; if (PLAIN[e.id]) return PLAIN[e.id]; if (e.kind === 'gauge') return `gluon from ${e.from} to ${e.to}`; if (e.kind === 'replica') return `spare link from ${e.from} to ${e.to}`; return e.label; };
const fr = s => String(s).replace('-', '−');
const vpos = (i, R, cx, cy) => [cx + R * Math.cos(-Math.PI / 2 + i * Math.PI / 4), cy + R * Math.sin(-Math.PI / 2 + i * Math.PI / 4)];
const CUBE = (() => { const n = 8, a = Array.from({ length: n }, (_, i) => [Math.cos(Math.PI * i / n + 0.3), Math.sin(Math.PI * i / n + 0.3)]), vs = [];
  for (let v = 0; v < 256; v++) { let x = 0, y = 0; for (let i = 0; i < n; i++) if ((v >> i) & 1) { x += a[i][0]; y += a[i][1]; } vs.push([x, y]); }
  const xs = vs.map(p => p[0]), ys = vs.map(p => p[1]); return { vs, minx: Math.min(...xs), maxx: Math.max(...xs), miny: Math.min(...ys), maxy: Math.max(...ys) }; })();

function faceText(f, lens) {
  if (lens === 'cube' || lens === 'bits') return f.bits;
  if (lens === 'prime' || lens === 'primes') return String(f.pname);
  if (lens === 'simplex') return '{' + f.S.join(',') + '}';
  return `g${f.grade}·c${f.class}`;
}

export default function DictionaryBoards({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const ok = v => ENTRIES.some(e => e.id === v);
  const [id, setId] = useState(ok(params.entry) ? params.entry : 'uL1');
  useEffect(() => { setId(ok(params.entry) ? params.entry : 'uL1'); }, [params.entry]);   // eslint-disable-line react-hooks/exhaustive-deps
  const e = ENTRIES.find(x => x.id === id), isEdge = e.kind !== 'cartan', ch = e.channel;
  const real = useMemo(() => new Set(e.faces.map(f => f.N)), [e]), phase = useMemo(() => new Set(e.phase_faces.map(f => f.N)), [e]);
  const P = Object.fromEntries(VERTS.map((v, i) => [v, vpos(i, 72, 100, 102)]));
  const chanEdges = isEdge ? D.channels.by_channel[String(ch)].edges : [];
  const isSel = q => isEdge && ((q.edge[0] === e.from && q.edge[1] === e.to) || (q.edge[0] === e.to && q.edge[1] === e.from));
  const cs = 196 / Math.max(CUBE.maxx - CUBE.minx, CUBE.maxy - CUBE.miny), cx = (CUBE.minx + CUBE.maxx) / 2, cy = (CUBE.miny + CUBE.maxy) / 2;
  const Q = v => [r1(210 + (CUBE.vs[v][0] - cx) * cs), r1(330 + (CUBE.vs[v][1] - cy) * cs)];
  const fano = c => [r1(222 + FANO_POS[c][0] * 0.52), r1(4 + FANO_POS[c][1] * 0.6)];
  const lensKey = lens === 'furey' || !lens ? 'furey' : lens;
  const H = research ? 482 : 446;
  return (
    <div className="fig fig-dictionary-boards">
      <FigSvg id="dictionary-boards" row={row} viewBox={`0 0 420 ${H}`}>
        <g data-board="peirce" data-entry={e.id} data-channel={ch}>
          <text x={4} y={12} className="t-tiny t-muted">{research ? 'Peirce simplex' : 'the eight boxes'}</text>
          {D.channels.edges28.map((q, i) => { const [a, b] = q.edge.map(v => P[v]), sel = isSel(q), mate = isEdge && q.channel === ch;
            return <line key={i} x1={r1(a[0])} y1={r1(a[1])} x2={r1(b[0])} y2={r1(b[1])} className="stroke-ink" data-peirce-edge={q.edge.join('-')} data-edge-channel={q.channel} data-on={sel ? 2 : mate ? 1 : 0}
              style={{ strokeOpacity: sel ? 1 : mate ? 0.75 : 0.14, strokeWidth: sel ? 3 : mate ? 1.6 : 0.8, strokeDasharray: q.kind === 'replica' ? '4 3' : undefined }} />; })}
          {isEdge && (() => { const a = P[e.from], b = P[e.to], L = Math.hypot(b[0] - a[0], b[1] - a[1]), t = (L - 13) / L; return <path d={arrowHead(a[0], a[1], a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, 8)} className="ink" />; })()}
          {VERTS.map(v => { const [x, y] = P[v], hot = isEdge && (v === e.from || v === e.to); return (
            <g key={v} data-vertex={v}>
              <circle cx={r1(x)} cy={r1(y)} r={hot ? 12 : 10} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: hot ? 2 : 1 }} />
              <text x={r1(x)} y={r1(y + 3.5)} textAnchor="middle" className="t-tiny t-bold">{v}</text>
            </g>); })}
        </g>
        <g data-board="fano">
          <text x={222} y={12} className="t-tiny t-muted">{research ? 'Fano plane of the channels' : 'seven groups'}</text>
          {[[3, 8], [8, 9], [9, 3], [3, 1], [8, 10], [9, 11]].map(([a, b], i) => <line key={i} x1={fano(a)[0]} y1={fano(a)[1]} x2={fano(b)[0]} y2={fano(b)[1]} className="hair" style={{ stroke: 'var(--muted)' }} />)}
          <circle cx={r1(222 + 180 * 0.52)} cy={r1(4 + 183 * 0.6)} r={r1(67 * 0.56)} className="stroke-ink" style={{ strokeDasharray: '5 3', strokeOpacity: 0.7 }} />
          {Object.keys(FANO_POS).map(Number).map(c => { const [x, y] = fano(c), on = isEdge && c === ch; return (
            <g key={c} data-fano={c} data-on={on ? 1 : 0}>
              <circle cx={x} cy={y} r={on ? 11 : 9} className={on ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: on ? 2 : 1 }} />
              <text x={x} y={r1(y + 3.5)} textAnchor="middle" className="t-mono t-tiny t-bold" style={on ? { fill: 'var(--panel)' } : undefined}>{c}</text>
            </g>); })}
        </g>
        <g data-board="cube" data-real={[...real].sort((a, b) => a - b).join(',')} data-phase={[...phase].sort((a, b) => a - b).join(',')}>
          <text x={4} y={214} className="t-tiny t-muted">{research ? '8-cube: real part filled, ω-partner ringed' : 'the 256 corners: the lit ones'}</text>
          {CUBE.vs.map((_, v) => { if (real.has(v) || phase.has(v)) return null; const [x, y] = Q(v); return <circle key={v} cx={x} cy={y} r={1.1} className="ink-muted" style={{ fillOpacity: 0.45 }} />; })}
          {[...phase].map(v => { const [x, y] = Q(v); return <circle key={'p' + v} cx={x} cy={y} r={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.6 }} data-face-phase={v} />; })}
          {[...real].map(v => { const [x, y] = Q(v); return <circle key={'r' + v} cx={x} cy={y} r={4} className="ink" data-face-real={v} data-grade={popcount(v)} />; })}
        </g>
        <g transform={`translate(4, ${research ? 440 : 432})`} data-lens={lensKey}>
          <text x={0} y={0} className="t-small t-bold">{research ? e.label : plainName(e)}</text>
          {research && (
            <>
              <text x={0} y={16} className="t-mono t-tiny">{isEdge
                ? `${e.from} → ${e.to} · channel ${ch} · Y = ${fr(e.Y)} · Q = ${fr(e.Q)} · grades ${e.grades.join(', ')} · cosets ${e.classes.join(', ')}`
                : `diagonal · ${e.faces.length} code faces, ${e.phase_faces.length} phase faces in coset ${e.phase_class}`}</text>
              <text x={0} y={32} className="t-mono t-micro t-muted">{e.faces.map(f => faceText(f, lensKey)).join('  ')}</text>
            </>
          )}
        </g>
      </FigSvg>
      <Controls label="dictionary">
        <label className="fig-group" data-param="entry"><span className="fig-group-label">{research ? 'entry' : 'pick'}</span>
          <select className="fig-select" data-param="entry" value={id} onChange={ev => setId(ev.target.value)}>
            {GROUPS.map(([g, name]) => <optgroup key={g} label={name}>{ENTRIES.filter(x => x.group === g).map(x => <option key={x.id} value={x.id}>{research ? x.label : plainName(x)}</option>)}</optgroup>)}
          </select>
        </label>
      </Controls>
    </div>
  );
}
DictionaryBoards.meta = { id: 'dictionary-boards', lenses: ['furey', 'clifford', 'simplex', 'cube', 'prime'], learner: true };
/** the numbers the figure draws, for the frame's data download */
DictionaryBoards.data = (params = {}) => { const e = ENTRIES.find(x => x.id === params.entry) || ENTRIES[0]; return { entry: e.id, label: e.label, channel: e.channel, from: e.from || null, to: e.to || null, faces: e.faces, phase_faces: e.phase_faces, channelEdges: e.kind !== 'cartan' ? D.channels.by_channel[String(e.channel)].edges : [] }; };
