// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure lattice: the 45 cells Cl(p,q) with n = p + q <= 8, by n (columns) and clock c = p − q mod 8 (rows). Cells with the same n and c are one algebra,
// so a slot is one algebra and lists its signatures; the 24 cards with a cell (ATL-001 … ATL-025, v15 AUDITED_ATLAS) are marked with a dot; a cell is selectable
// and the clock wheel of the selected cell sits in the empty corner (n <= 2, c = 3 … 5). Everything is computed by engines/labels.js (cellLattice) from the kernel.
// Lenses: the labels lenses print each cell with the kernel's label (sigword: the cell as a word over +, −; bitsq: presence × square; bits / primes / set and the
// shape lenses cube / prime / simplex: the label of the generators that square to −1). Port of v15 LabelsWidgets.CellLattice.
import React, { useState, useEffect, useMemo } from 'react';
import { cellLattice, cellLabel, TYPE_SYMBOL } from '../../engines/labels.js';
import { FigSvg, clockVar, sub, r1 } from './kit.jsx';
import { WheelDrawing } from './ClockWheel.jsx';

const ML = 52, MT = 30, CW = 60, RH = 66, NCOL = 9, NROW = 8;
const shortAlg = s => (s.k === 1 ? TYPE_SYMBOL[s.type] : `M${sub(s.k)}(${TYPE_SYMBOL[s.type]})`);
const LATTICE_LENSES = { sigword: 'sigword', bitsq: 'bitsq', bits: 'bits', cube: 'bits', primes: 'primes', prime: 'primes', simplex: 'set' };

export default function Lattice({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const L = useMemo(() => cellLattice(8), []);
  const valid = (pp, qq) => Number.isInteger(pp) && Number.isInteger(qq) && pp >= 0 && qq >= 0 && pp + qq <= 8;
  const init = valid(params.p, params.q) ? [params.p, params.q] : [1, 3];
  const [[p, q], setSel] = useState(init);
  useEffect(() => { if (valid(params.p, params.q)) setSel([params.p, params.q]); }, [params.p, params.q]);   // eslint-disable-line react-hooks/exhaustive-deps
  const pick = (pp, qq) => { setSel([pp, qq]); if (typeof params.onSelect === 'function') params.onSelect({ p: pp, q: qq }); };
  const lensKey = LATTICE_LENSES[lens] || null;
  const sel = L.cells.find(x => x.p === p && x.q === q);
  const showWheel = params.wheel !== false;
  const W = ML + NCOL * CW + 8, H = MT + NROW * RH + 30;
  return (
    <div className="fig fig-lattice">
      <div className="fig-scroll">
      <FigSvg id="lattice" row={row} viewBox={`0 0 ${W} ${H}`} className="fig-svg-wide">
        {/* column heads: n; row heads: the clock colour with its printed c = n */}
        {Array.from({ length: NCOL }, (_, n) => <text key={'n' + n} x={ML + n * CW + CW / 2} y={MT - 10} textAnchor="middle" className={'t-mono t-small' + (sel && sel.n === n ? ' t-bold' : ' t-muted')}>{research ? `n = ${n}` : n}</text>)}
        {Array.from({ length: NROW }, (_, c) => (
          <g key={'c' + c}>
            <rect x={4} y={MT + c * RH + RH / 2 - 6} width={10} height={10} rx={2} style={{ fill: clockVar(c) }} />
            <text x={18} y={MT + c * RH + RH / 2 + 3} className={'t-mono t-small' + (sel && sel.c === c ? ' t-bold' : '')}>{`c = ${c}`}</text>
          </g>
        ))}
        {L.slots.map(s => {
          const x = ML + s.n * CW, y = MT + s.c * RH, k = s.cells.length;
          const first = research ? y + 36 : y + (RH - k * 14) / 2 + 12;
          return (
            <g key={`${s.n},${s.c}`} className="fig-slot" data-slot={`${s.n},${s.c}`}>
              <title>{`${s.algebra} · n = ${s.n}, c = ${s.c}`}</title>
              <rect x={x + 2} y={y + 2} width={CW - 4} height={RH - 4} rx={4} style={{ fill: clockVar(s.c), fillOpacity: 0.16 }} />
              <rect x={x + 2} y={y + 2} width={CW - 4} height={4} rx={2} style={{ fill: clockVar(s.c) }} />
              {research && <text x={x + CW / 2} y={y + 21} textAnchor="middle" className="t-small">{shortAlg(s)}</text>}
              {s.cells.map((c, i) => {
                const by = first + i * 13.5, on = c.p === p && c.q === q, txt = cellLabel(c.p, c.q, lensKey);
                return (
                  <g key={`${c.p},${c.q}`} className={'fig-cell' + (on ? ' is-on' : '')} data-cell={`${c.p},${c.q}`} data-clock={c.c} data-token={c.token} data-param="cell" onClick={() => pick(c.p, c.q)}>
                    <title>{`Cl(${c.p},${c.q}) = ${c.algebra} · c = ${c.c}${c.cards.length ? ' · ' + c.cards.join(', ') : ''}`}</title>
                    <rect className="fig-cell-ring" x={x + 4} y={r1(by - 10.5)} width={CW - 8} height={13.5} rx={3} style={{ fill: on ? clockVar(c.c) : 'none', fillOpacity: on ? 0.45 : 0, stroke: on ? 'var(--fg)' : 'none' }} />
                    {c.cards.length > 0 && <circle cx={x + 8.5} cy={r1(by - 4)} r={3.2} className="ink" />}
                    <text x={c.cards.length ? x + 34 : x + CW / 2} y={r1(by)} textAnchor="middle" className={'t-mono ' + (txt.length > 7 ? 't-micro' : txt.length > 5 ? 't-tiny' : 't-small') + (on ? ' t-bold' : '')}>{txt}</text>
                    <rect className="hit" x={x + 3} y={r1(by - 11)} width={CW - 6} height={14} />
                  </g>
                );
              })}
            </g>
          );
        })}
        {showWheel && sel && <WheelDrawing cx={ML + 1.5 * CW} cy={MT + 4.5 * RH} R={78} p={p} q={q} level={level} compact />}
        <g transform={`translate(${ML}, ${MT + NROW * RH + 18})`}>
          <circle cx={6} cy={-4} r={3.2} className="ink" />
          <text x={14} y={0} className="t-small">card</text>
          {research && sel && <text x={NCOL * CW} y={0} textAnchor="end" className="t-mono t-small t-muted">{`Cl(${p},${q}) = ${sel.algebra}`}</text>}
        </g>
      </FigSvg>
      </div>
      <div className="fig-controls">
        <label className="fig-group"><span className="fig-group-label">cell</span>
          <select className="fig-select" value={`${p},${q}`} data-param="cell" onChange={e => { const [a, b] = e.target.value.split(',').map(Number); pick(a, b); }}>
            {L.cells.map(c => <option key={`${c.p},${c.q}`} value={`${c.p},${c.q}`}>{research ? `Cl(${c.p},${c.q})  c = ${c.c}` : `${c.p},${c.q}  c = ${c.c}`}</option>)}
          </select>
        </label>
      </div>
    </div>
  );
}
Lattice.meta = { id: 'lattice', lenses: ['clifford', 'simplex', 'cube', 'prime', 'bits', 'primes', 'sigword', 'bitsq'], learner: true };
/** the numbers the figure draws, for the frame's data download */
Lattice.data = () => cellLattice(8).cells.map(({ p, q, n, c, type, k, copies, dim, algebra, cards }) => ({ p, q, n, c, type, k, copies, dim, algebra, cards }));
