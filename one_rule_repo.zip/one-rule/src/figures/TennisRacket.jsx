// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure tennis-racket (step 14): Euler's equations of a free rigid body, I_C[dB/dt] = B × I_C[B], integrated by RK4 (engines/forquePhysics.js racket; the predicted rate
// compared with checks/selfcheck/forque_matrix.json and the measured one with the prediction by tests/engines.test.mjs). Inertias 5, 3, 1 (the v15 widget's start):
// the body spins about the middle axis with a tiny disturbance; the three components ω₁, ω₂, ω₃ of the spin (B₂₃, B₃₁, B₁₂) are drawn against time (solid, dashed,
// dotted), and the spin about the middle axis turns over again and again. Research level: the growth rate from the formula and from this run, and the energy drift.
// The controls are v15's sliders of the three inertias, 1 … 10 in steps of ½ (research level; interactive entry I); it opens on the starting body. Port of v15
// ForqueSection.Racket.
import React, { useMemo, useState, useEffect } from 'react';
import { racket } from '../../engines/forquePhysics.js';
import { FigSvg, Controls, Range, r1 } from './kit.jsx';

const DASH = [undefined, '6 3', '1.5 3'];
const sci = v => { if (!v) return '0'; const e = Math.floor(Math.log10(Math.abs(v))), m = v / 10 ** e; const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' }; return `${+m.toFixed(1)}·10${String(e).split('').map(c => SUP[c]).join('')}`; };

export default function TennisRacket({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okI = v => Array.isArray(v) && v.length === 3 && v.every(x => Number.isFinite(x) && x > 0);
  const [I, setI] = useState(okI(params.I) ? params.I : [5, 3, 1]);
  useEffect(() => { setI(okI(params.I) ? params.I : [5, 3, 1]); }, [JSON.stringify(params.I || null)]);   // eslint-disable-line react-hooks/exhaustive-deps
  const R = useMemo(() => racket(I), [I.join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  const W = 420, H = research ? 232 : 206, xl = 40, xr = 380, top = 18, bot = 168, mid = (top + bot) / 2;
  const X = t => xl + ((xr - xl) * t) / R.T, Y = v => mid - ((bot - top) / 2) * Math.max(-1.25, Math.min(1.25, v)) / 1.25;
  return (
    <div className="fig fig-tennis-racket">
      <FigSvg id="tennis-racket" row={row} viewBox={`0 0 ${W} ${H}`}>
        <line x1={xl} y1={mid} x2={xr} y2={mid} className="hair" />
        {[1, -1].map(v => <g key={v}><line x1={xl} y1={r1(Y(v))} x2={xr} y2={r1(Y(v))} className="hair-2" /><text x={xl - 5} y={r1(Y(v) + 3.5)} textAnchor="end" className="t-mono t-micro t-muted">{v > 0 ? '1' : '−1'}</text></g>)}
        <text x={xl - 5} y={mid + 3.5} textAnchor="end" className="t-mono t-micro t-muted">0</text>
        {[0, 1, 2].map(c => (
          <g key={c} data-component={c}>
            <title>{`ω${'₁₂₃'[c]} against time${c === R.m ? ' (the middle axis)' : ''}`}</title>
            <polyline points={R.ts.map((t, i) => `${r1(X(t))},${r1(Y(R.ws[i][c]))}`).join(' ')} className="stroke-ink" style={{ strokeWidth: c === R.m ? 1.8 : 1.3, strokeDasharray: DASH[c], strokeLinejoin: 'round' }} />
            <text x={xr + 6} y={r1(Y(R.ws[R.ws.length - 1][c]) + 3.5)} className="t-mono t-tiny">{research ? `ω${'₁₂₃'[c]}` : String(c + 1)}</text>
          </g>
        ))}
        <text x={xr} y={bot + 16} textAnchor="end" className="t-tiny">{research ? 'time t' : 'time'}</text>
        {research && <text x={xl} y={bot + 16} className="t-mono t-tiny t-muted">{`inertias ${R.I.join(', ')} · spin about axis ${R.m + 1}`}</text>}
        {research && <text x={xl} y={H - 10} className="t-mono t-tiny t-muted">{`growth rate: formula ${R.predicted.toFixed(4)} · this run ${R.measured === null ? '—' : R.measured.toFixed(4)} · energy drift ${sci(R.energyDrift)}`}</text>}
      </FigSvg>
      {research && (
        <Controls label="inertias">
          {[0, 1, 2].map(i => <Range key={i} label={`I${'₁₂₃'[i]}`} value={I[i]} min={1} max={10} step={0.5} onChange={v => setI(a => a.map((x, j) => (j === i ? v : x)))} param="I" />)}
        </Controls>
      )}
    </div>
  );
}
TennisRacket.meta = { id: 'tennis-racket', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
TennisRacket.data = (params = {}) => { const I = Array.isArray(params.I) && params.I.length === 3 ? params.I : [5, 3, 1], R = racket(I); return { inertias: I, t: R.ts, omega: R.ws, middleAxis: R.m, predictedRate: R.predicted, measuredRate: R.measured, energyDrift: R.energyDrift, momentumDrift: R.momentumDrift }; };
