// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure gosset-plane (shapes, step 3): the 72, 126 or 240 roots of E6, E7, E8 in the Coxeter plane, as gosset_selfcheck.py stores them (engines/labels.js
// gossetPlane reads checks/selfcheck/gosset.json; nothing is recomputed). h roots on each ring (h the Coxeter number), drawn on hairline circles; a root that is an
// edge of the orthoplex (±e_i ± e_j) is a filled dot, a corner of the demicube (½(±1, …, ±1)) a hollow one — v15 told the two apart by colour, the design keeps
// colour for the clock. The control is v15's: the chips E6, E7, E8 above the picture (interactive entry n). Port of v15 GossetSection.Plane.
import React, { useState, useEffect, useMemo } from 'react';
import { gossetPlane } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, r1, sub, pick, isIn } from './kit.jsx';

const NS = [6, 7, 8];
const KIND = { e: ['orthoplex edge', 'edge of the orthoplex'], d: ['demicube corner', 'corner of the half-cube'] };

export default function GossetPlane({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [n, setN] = useState(pick(params.n, isIn(NS), 8));
  useEffect(() => { setN(pick(params.n, isIn(NS), 8)); }, [params.n]);
  const G = useMemo(() => gossetPlane(n), [n]);
  const W = 320, C = 160, R = 140, m = Math.max(...G.points.map(p => Math.hypot(p.x, p.y))), s = R / m, rad = n === 8 ? 3 : 3.6;
  const H = W + (research ? 40 : 30), word = k => KIND[k][research ? 0 : 1];
  return (
    <div className="fig fig-gosset-plane">
      <FigSvg id="gosset-plane" row={row} viewBox={`0 0 ${W} ${H}`}>
        <g data-n={n} data-roots={G.roots} data-h={G.h}>
          {G.rings.map(rg => <circle key={'r' + rg.ring} cx={C} cy={C} r={r1(rg.r * s)} className="hair" data-ring-count={rg.count} />)}
          {G.points.map((p, i) => (
            <circle key={i} cx={r1(C + p.x * s)} cy={r1(C - p.y * s)} r={rad} className={p.kind === 'e' ? 'ink' : 'on-panel'} style={p.kind === 'e' ? undefined : { stroke: 'var(--fg)', strokeWidth: 1.1 }} data-kind={p.kind} data-ring={p.ring}>
              <title>{`${word(p.kind)}, ring ${p.ring + 1}`}</title>
            </circle>
          ))}
        </g>
        <g transform={`translate(10, ${W + 14})`}>
          <circle cx={4} cy={-4} r={3.4} className="ink" /><text x={12} y={0} className="t-small">{`${word('e')} · ${G.kinds.e}`}</text>
          <circle cx={W / 2 - 6} cy={-4} r={3.4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.1 }} /><text x={W / 2 + 2} y={0} className="t-small">{`${word('d')} · ${G.kinds.d}`}</text>
          {research
            ? <text x={0} y={20} className="t-mono t-tiny t-muted">{`E${sub(n)}: ${G.roots} roots · ${G.rings.length} rings × h = ${G.h}`}</text>
            : <text x={0} y={14} className="t-tiny t-muted">{`${G.roots} roots on ${G.rings.length} rings of ${G.h}`}</text>}
        </g>
      </FigSvg>
      <Controls label="Gosset series">
        <Chips label={research ? 'E' : 'series'} items={NS} value={n} onPick={setN} render={k => 'E' + sub(k)} param="n" />
      </Controls>
    </div>
  );
}
GossetPlane.meta = { id: 'gosset-plane', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
GossetPlane.data = (params = {}) => { const G = gossetPlane(pick(params.n, isIn(NS), 8)); return { n: G.n, h: G.h, roots: G.roots, kinds: G.kinds, rings: G.rings, points: G.points.map(p => [p.x, p.y, p.ring, p.kind]) }; };
