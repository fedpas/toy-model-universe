// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/FigureFrame.jsx — the frame of a figure of figures.json: the drawing (FIGURES[id] from src/figures/ when it exists,
// else a quiet placeholder naming the figure), its caption from the caption row's texts, and the lenses it can redraw in.
import { useSettings, textFor } from '../app/content.js';
import { figuresById, lensesByKey } from '../app/store.js';
import { figureComponent } from '../app/optional.js';
import { useResolvedTheme } from '../app/theme.js';
import ErrorBoundary from './ErrorBoundary.jsx';

function Placeholder({ id, failed }) {
  return (
    <div className="fig__placeholder" role="img" aria-label={`Figure ${id}${failed ? ' could not be drawn' : ', not drawn in this build'}`}>
      <span className="fig__ph-kind">Figure</span>
      <code className="fig__ph-id">{id}</code>
      {failed ? <span className="fig__ph-note">could not be drawn</span> : null}
    </div>
  );
}

export default function FigureFrame({ id }) {
  const s = useSettings();
  const theme = useResolvedTheme(s.theme);
  const fig = figuresById()?.get(id);
  if (!fig) return null;
  const learner = s.level === 'learner';
  if (learner && !fig.learner) return null;
  const Comp = figureComponent(id);
  const caption = fig.captionRow ? textFor(fig.captionRow, { mode: s.mode, level: s.level, lens: s.lens, register: 'caption' }) : null;
  const lenses = (fig.lenses || []).map(k => lensesByKey()?.get(k)).filter(Boolean).filter(l => !learner || l.kind === 'shape');
  return (
    <figure className="fig" data-figure={id}>
      <div className="fig__draw">
        {Comp ? (
          <ErrorBoundary name={`figure ${id}`} resetKey={`${s.lens}|${s.level}|${theme}`} fallback={<Placeholder id={id} failed />}>
            <Comp params={fig.params || {}} lens={s.lens} level={s.level} theme={theme} row={fig.captionRow} />
          </ErrorBoundary>
        ) : <Placeholder id={id} />}
      </div>
      {caption ? <figcaption className="fig__caption">{caption}</figcaption> : null}
      {lenses.length ? (
        <div className="fig__lenses" role="group" aria-label="Redraw in a lens">
          {lenses.map(l => (
            <button key={l.key} type="button" className="chip chip--lens" aria-pressed={s.lens === l.key} onClick={() => s.set({ lens: s.lens === l.key ? null : l.key })}>
              {l.name}
            </button>
          ))}
        </div>
      ) : null}
    </figure>
  );
}
