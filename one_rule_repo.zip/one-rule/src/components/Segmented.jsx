// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Segmented.jsx — a segmented control (radio group with roving focus): Physics | Mathematics, Research | Learner.
import { useRef } from 'react';

export default function Segmented({ label, value, options, onChange, className = '' }) {
  const ref = useRef(null);
  const onKey = e => {
    const i = options.findIndex(o => o.value === value);
    let j = null;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') j = (i + 1) % options.length;
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') j = (i - 1 + options.length) % options.length;
    if (j == null) return;
    e.preventDefault();
    onChange(options[j].value);
    const b = ref.current && ref.current.querySelectorAll('button')[j];
    if (b) b.focus();
  };
  return (
    <div className={`seg ${className}`} role="radiogroup" aria-label={label} ref={ref} onKeyDown={onKey}>
      {options.map(o => (
        <button key={o.value} type="button" role="radio" aria-checked={o.value === value} tabIndex={o.value === value ? 0 : -1}
          className="seg__opt" aria-label={o.label} onClick={() => onChange(o.value)} data-value={o.value}>
          <span className="seg__long" aria-hidden="true">{o.label}</span>
          <span className="seg__short" aria-hidden="true">{o.short || o.label}</span>
        </button>
      ))}
    </div>
  );
}
