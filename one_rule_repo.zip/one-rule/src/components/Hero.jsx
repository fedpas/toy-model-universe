// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Hero.jsx — the hero: one statement (the short register when the row has one, else the full text) and one figure (a
// figure of figures.json, or the drawing a page passes as `aside`, such as the map of the steps). Always visible, never folded.
// At learner level one connective line under the statement says how we know: the scripts that ran, those only read, the inputs it
// needs (howWeKnow: numbers from the tables, no law stated; counted in the connective budget of tests/coverage.test.mjs).
import { useSettings } from '../app/content.js';
import { howWeKnow } from '../app/queries.js';
import Statement from './Statement.jsx';
import FigureFrame from './FigureFrame.jsx';

export default function Hero({ hero, aside = null, children }) {
  const s = useSettings();
  if (!hero) return null;
  const how = s.level === 'learner' ? howWeKnow(hero.id) : null;
  const fig = aside || (hero.figure ? <FigureFrame id={hero.figure} /> : null);
  return (
    <div className={`hero${fig ? ' hero--fig' : ''}`} id="hero">
      <div className="hero__text">
        <Statement id={hero.id} register={hero.register} variant="hero" />
        {how ? <p className="hero__how" data-connective="how-we-know" data-row={hero.id}>{how}</p> : null}
        {children}
      </div>
      {fig ? <div className="hero__fig">{fig}</div> : null}
    </div>
  );
}
