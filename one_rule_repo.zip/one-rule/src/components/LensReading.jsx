// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LensReading.jsx — the readings of a row in the active lens (content/lens_readings.json, BUILD_CONTRACTS
// interface 7), as one compact line under the statement: "In the <lens> lens: <term> <match>", the first two readings and
// "+n" for the others. A reading is shown beside the statement, never in its place. Nothing renders when no lens is active or
// the row has no reading in that lens; at learner level only the terms written without a formula are shown.
import { useState } from 'react';
import { useSettings, useTable } from '../app/content.js';
import { lensesByKey, lensReadingsIndex } from '../app/store.js';
import RichText from './RichText.jsx';

/** a term holds a formula when it has `$`, a backslash, a `^` or `_` (super- and subscripts) or `=` */
export const hasFormula = t => /[$\\^_=]/.test(String(t ?? ''));

const TRAILING = new Set(['for', 'with', 'of', 'in', 'on', 'at', 'by', 'to', 'the', 'a', 'an', 'and', 'or', 'but']);
/** the match word of a record: the head of its grade, at most three words ("exact", "partial", "structural", "exact with convention") */
export function matchWord(match) {
  let t = String(match ?? '').replace(/^\s*match:\s*/i, '').replace(/\$[^$]*\$/g, ' ');
  const bracket = /^\s*\[([^\]]+)\]/.exec(t);
  if (bracket) t = bracket[1];
  t = t.split(/[,;:(/]/)[0].replace(/^\s*[ESA]\s+(?=[a-z])/, '').replace(/\*+/g, '').replace(/\s+/g, ' ').trim();
  const words = t ? t.split(' ').slice(0, 3) : [];
  while (words.length > 1 && TRAILING.has(words[words.length - 1].toLowerCase())) words.pop();
  return words.join(' ');
}

const matchRank = r => { const w = matchWord(r.match).toLowerCase(); return /^exact\b/.test(w) ? 0 : /^(structural|partial|standard|dictionary|checked)\b/.test(w) ? 1 : 2; };
/** the order of a row's readings in one lens: links by evidence first, the registry's entries first, exact matches first, then as stored */
export function orderReadings(list) {
  return list
    .map((r, i) => [r, i])
    .sort(([a, i], [b, j]) => (a.via === b.via ? 0 : a.via === 'evidence' ? -1 : 1)
      || (a.source === b.source ? 0 : a.source === 'lenses.dictionary' ? -1 : 1)
      || matchRank(a) - matchRank(b) || i - j)
    .map(([r]) => r);
}

/** the readings of a row in a lens that can be shown at this level (null while lens_readings.json is not loaded) */
export function readingsFor(rowId, lensKey, level) {
  const idx = lensReadingsIndex();
  if (!idx) return null;
  const list = (lensKey && idx.get(lensKey) && idx.get(lensKey).get(rowId)) || [];
  return orderReadings(level === 'learner' ? list.filter(r => !hasFormula(r.term)) : list);
}

const SHOW = 2;

function Line({ id, s }) {
  useTable('lens_readings'); // loads the table the first time a lens is active; the index below reads it from the cache
  const [open, setOpen] = useState(false);
  const list = readingsFor(id, s.lens, s.level);
  if (!list || !list.length) return null;
  const lens = lensesByKey()?.get(s.lens);
  const shown = open ? list : list.slice(0, SHOW);
  const more = list.length - SHOW;
  return (
    <div className={`lens-reading${open ? ' is-open' : ''}`} data-lens={s.lens} data-row={id}>
      <span className="lens-reading__lead">In the {lens ? lens.name : s.lens} lens:</span>
      {shown.map((r, i) => {
        const w = matchWord(r.match);
        return (
          <span className="lens-reading__item" key={i}>
            <span className="lens-reading__term"><RichText text={r.term} level={s.level} /></span>
            {w ? <span className="lens-reading__match">{w}</span> : null}
          </span>
        );
      })}
      {more > 0 ? (
        <button type="button" className="lens-reading__more" aria-expanded={open} onClick={() => setOpen(v => !v)}>
          {open ? 'Show fewer' : <>+{more}<span className="vh"> more {more === 1 ? 'reading' : 'readings'} in this lens</span></>}
        </button>
      ) : null}
    </div>
  );
}

export default function LensReading({ id }) {
  const s = useSettings();
  if (!s.lens || !id) return null;
  return <Line id={id} s={s} />;
}
