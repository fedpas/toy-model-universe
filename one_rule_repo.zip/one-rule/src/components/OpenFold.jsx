// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/OpenFold.jsx — the rows with status open (questions, dead ends, conjectures, pointers), collapsed at the end of a
// page with their badges; never between results. Learner level calls it "Not finished yet".
import { useSettings } from '../app/content.js';
import Statement from './Statement.jsx';
import Drawer from './Drawer.jsx';
import { BadgeIcon } from './Icons.jsx';

export default function OpenFold({ groups, open, onToggle, drawers = true, drawer, onDrawer }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  const rows = groups.flatMap(g => g.rows);
  if (!rows.length) return null;
  const title = learner ? 'Not finished yet' : 'Open items';
  return (
    <details className="fold" id="sec-open-items" data-outline={title} open={!!open} onToggle={e => onToggle && onToggle(e.currentTarget.open)}>
      <summary className="fold__summary">
        <span className="fold__icon"><BadgeIcon kind="open" size={14} /></span>
        <span className="fold__title">{title}</span>
        <span className="fold__count">{rows.length}</span>
      </summary>
      <div className="fold__body">
        {groups.map(g => (
          <div className="fold__group" key={g.id}>
            {groups.length > 1 ? <h3 className="fold__group-title">{g.label}</h3> : null}
            {g.rows.map(id => <Statement key={id} id={id} />)}
          </div>
        ))}
        {drawers ? (
          <Drawer sid="__open" rows={rows} open={drawer && drawer.open} focus={drawer && drawer.focus} onToggle={o => onDrawer && onDrawer('__open', o)} />
        ) : null}
      </div>
    </details>
  );
}
