// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Drawer.jsx — one drawer per section (05 §4): a <details> that opens in place, with the tabs
// Evidence · Needs · Rests on / leads to · Readings · Numbers · Address, filled from the rows (evidence, depends, readingRefs,
// notions, address) and the recorded check runs. At learner level it is "How do we know?": the scripts and whether they passed.
import { useEffect, useMemo, useRef, useState } from 'react';
import { useSettings, useTable, statusOf } from '../app/content.js';
import { rowsById, dependants, checksIndex, lastRuns, lensesByKey, lensReadingsIndex, inputsById, textRecord } from '../app/store.js';
import { DRAWER_TABS, DRAWER_TAB_NAMES, notionSquare } from '../app/vocab.js';
import { rowHome } from '../app/queries.js';
import Statement from './Statement.jsx';
import Link from './Link.jsx';
import { ChevronDown, CheckMark, CrossMark, DotMark } from './Icons.jsx';

const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;
const baseName = p => String(p || '').split('/').pop();

/** distinct scripts named by the evidence of these rows (by file name, as some entries give only the name) */
function scriptCount(rows) {
  const set = new Set();
  for (const id of rows) for (const e of (rowsById()?.get(id)?.evidence || [])) if (e.script || e.check) set.add(baseName(e.script || e.check));
  return set.size;
}

/** a row's evidence resolved against checks.json and the last runs: one item per script */
export function resolveEvidence(row, idx, runs) {
  const seen = new Map();
  for (const e of row.evidence || []) {
    const path = e.script ? (e.script.startsWith('checks/') ? e.script : 'checks/' + e.script) : null;
    let check = idx && path ? idx.byScript.get(path) : null;
    if (!check && idx && e.script) { const c = idx.byBase.get(baseName(e.script)) || []; if (c.length) check = c[0]; }
    const key = check ? check.script : path || e.check;
    const prev = seen.get(key);
    if (prev) { if (e.mode === 'ran') prev.mode = 'ran'; continue; }
    const run = runs ? runs.get(check ? check.script : path) || null : null;
    seen.set(key, { key, script: check ? check.script : path, check, checkId: e.check, mode: e.mode, run });
  }
  return [...seen.values()];
}
function runWord(ev) {
  if (ev.mode === 'read') return { kind: 'none', word: 'read, not run here' };
  if (ev.run && ev.run.passed === true) return { kind: 'pass', word: 'passed' };
  if (ev.run && ev.run.passed === false) return { kind: 'fail', word: 'failed' };
  if (ev.mode === 'ran') return { kind: 'none', word: 'no recorded run' };
  return { kind: 'none', word: 'not marked as run' };
}
const RunMark = ({ kind }) => (kind === 'pass' ? <CheckMark /> : kind === 'fail' ? <CrossMark /> : <DotMark />);

function RowRef({ id, rel }) {
  const h = rowHome(id);
  return (
    <span className="rowref">
      <Link to={h.path} at={h.at} className="rowref__id">{id}</Link>
      {rel ? <span className="rowref__rel">{rel}</span> : null}
    </span>
  );
}

function LineHead({ id, mode }) {
  const r = rowsById()?.get(id);
  const home = r ? (mode === 'math' ? r.homeMath || r.homePhys : r.homePhys || r.homeMath) : '';
  return (
    <div className="dl__head">
      <span className="dl__id">{id}</span>
      {home ? <span className="dl__home">{home}</span> : null}
    </div>
  );
}

function useChecks() {
  const [checks, e1] = useTable('checks');
  const [runs, e2] = useTable('check_runs');
  const idx = checks ? checksIndex() : null;
  const last = runs ? lastRuns() : null;
  return { ready: !!(idx && last), error: e1 || e2, idx, last };
}

// ---------------------------------------------------------------- the tabs
function EvidenceTab({ rows, sid, focusRow, mode }) {
  const { ready, error, idx, last } = useChecks();
  const withEv = rows.filter(id => (rowsById()?.get(id)?.evidence || []).length);
  if (error) return <p className="drawer__note">The checks table could not be loaded ({String(error.message || error)}).</p>;
  if (!ready) return <p className="drawer__note">Loading the checks…</p>;
  if (!withEv.length) return <p className="drawer__note">No check is attached to these statements.</p>;
  const described = new Set(); // a script's description and check ids are printed at its first line in this drawer only
  return withEv.map(id => {
    const items = resolveEvidence(rowsById().get(id), idx, last).map(ev => {
      const first = !described.has(ev.key);
      described.add(ev.key);
      return { ...ev, describe: first };
    });
    return (
      <div className={`dl${focusRow === id ? ' is-focus' : ''}`} key={id} id={`line-${sid}-evidence-${id}`}>
        <LineHead id={id} mode={mode} />
        <ul className="ev">
          {items.map(ev => {
            const w = runWord(ev);
            return (
              <li className={`ev__item ev__item--${w.kind}`} key={ev.key}>
                <div className="ev__line">
                  <span className="ev__mark"><RunMark kind={w.kind} /></span>
                  <span className="ev__word">{w.word}</span>
                  {ev.check ? <a className="ev__script" href={ev.check.script} target="_blank" rel="noopener noreferrer">{ev.check.script.replace(/^checks\//, '')}</a> : <span className="ev__script">{(ev.script || ev.checkId || '').replace(/^checks\//, '')}</span>}
                  {ev.run && ev.run.date ? <span className="ev__date">{ev.run.date}</span> : null}
                </div>
                {ev.describe && ev.check && ev.check.what ? <p className="ev__what">{ev.check.what}</p> : null}
                {ev.describe && ev.check && ev.check.ids && ev.check.ids.length ? (
                  <details className="ev__ids">
                    <summary>{plural(ev.check.ids.length, 'check id')}</summary>
                    <ul>{ev.check.ids.map(c => <li key={c.id}><code>{c.id}</code> {c.statement}{c.range ? <span className="ev__range"> ({c.range})</span> : null}</li>)}</ul>
                  </details>
                ) : null}
              </li>
            );
          })}
        </ul>
      </div>
    );
  });
}

function NeedsTab({ rows, details, sid, focusRow }) {
  const inputs = inputsById();
  const used = [];
  const seen = new Set(details);
  for (const id of rows) for (const d of rowsById()?.get(id)?.depends || []) if (d.rel === 'uses-input' && !seen.has(d.id)) { seen.add(d.id); used.push(d.id); }
  if (!details.length && !used.length) return <p className="drawer__note">No input is recorded for these statements.</p>;
  return (
    <>
      {details.length ? (
        <div className="needs">
          {details.map(id => (
            <div className={`dl dl--statement${focusRow === id ? ' is-focus' : ''}`} key={id} id={`line-${sid}-needs-${id}`}>
              <LineHead id={id} />
              <Statement id={id} variant="compact" evidence={false} />
            </div>
          ))}
        </div>
      ) : null}
      {used.length ? (
        <div className="dl">
          <div className="dl__head"><span className="dl__label">Inputs the statements use</span></div>
          <ul className="reflist">
            {used.map(id => {
              const inp = inputs && inputs.get(id);
              const r = rowsById()?.get(id);
              const kind = (inp && inp.kindName) || (r && r.inputKindName) || '';
              return <li key={id}><RowRef id={id} />{kind ? <span className="reflist__note">{kind}</span> : null}</li>;
            })}
          </ul>
        </div>
      ) : null}
    </>
  );
}

function DependsTab({ rows, sid, focusRow, mode }) {
  const deps = dependants();
  const lines = rows.map(id => ({ id, out: rowsById()?.get(id)?.depends || [], inn: (deps && deps.get(id)) || [] })).filter(x => x.out.length || x.inn.length);
  if (!lines.length) return <p className="drawer__note">No dependency is recorded for these statements.</p>;
  return lines.map(({ id, out, inn }) => (
    <div className={`dl${focusRow === id ? ' is-focus' : ''}`} key={id} id={`line-${sid}-depends-${id}`}>
      <LineHead id={id} mode={mode} />
      {out.length ? <div className="dl__row"><span className="dl__label">Rests on</span><span className="reflist reflist--inline">{out.map((d, i) => <RowRef key={d.id + i} id={d.id} rel={d.rel} />)}</span></div> : null}
      {inn.length ? <div className="dl__row"><span className="dl__label">Leads to</span><span className="reflist reflist--inline">{inn.slice(0, 40).map((d, i) => <RowRef key={d.id + i} id={d.id} rel={d.rel} />)}{inn.length > 40 ? <span className="reflist__note">and {inn.length - 40} more</span> : null}</span></div> : null}
    </div>
  ));
}

function ReadingsTab({ rows, sid, focusRow, s }) {
  const lens = s.lens ? lensesByKey()?.get(s.lens) : null;
  return rows.map(id => {
    const r = rowsById()?.get(id);
    const lensHit = lens ? (textRecord(id, s) || {}).lensHit : null;
    const readings = lens ? ((lensReadingsIndex()?.get(lens.key)?.get(id)) || []) : [];
    return (
      <div className={`dl${focusRow === id ? ' is-focus' : ''}`} key={id} id={`line-${sid}-readings-${id}`}>
        <LineHead id={id} mode={s.mode} />
        <div className="dl__row"><span className="dl__label">Specialist readings</span><span>{r && r.readingRefs ? plural(r.readingRefs, 'reading') : 'none recorded'}</span></div>
        {r && r.homePhys ? <div className="dl__row"><span className="dl__label">Physics name</span><span>{r.homePhys}</span></div> : null}
        {r && r.homeMath ? <div className="dl__row"><span className="dl__label">Mathematics name</span><span>{r.homeMath}</span></div> : null}
        {readings.length ? <div className="dl__row"><span className="dl__label">{lens.name} reading</span><span>{readings.slice(0, 3).map((x, i) => <span key={i} className="dl__reading">{x.term}{x.match ? <span className="dl__match"> · {x.match}</span> : null}{i < Math.min(readings.length, 3) - 1 ? '; ' : ''}</span>)}{readings.length > 3 ? ` (+${readings.length - 3})` : ''}</span></div> : null}
        {lens && !lensHit && !readings.length ? <p className="drawer__note">No {lens.name} reading yet.</p> : null}
      </div>
    );
  });
}

function NumbersTab({ rows, numbers, sid, focusRow, mode }) {
  const { ready, idx, last } = useChecks();
  if (!ready && !numbers.length) return <p className="drawer__note">Loading the recorded runs…</p>;
  const lines = [];
  for (const id of rows) {
    const r = rowsById()?.get(id);
    const items = ready && r ? resolveEvidence(r, idx, last).filter(ev => ev.run) : [];
    if (items.length) lines.push({ id, items });
  }
  if (!lines.length && !numbers.length) return <p className="drawer__note">No stored numbers for these statements.</p>;
  return (
    <>
      {numbers.map(id => (
        <div className={`dl dl--statement${focusRow === id ? ' is-focus' : ''}`} key={id} id={`line-${sid}-numbers-${id}`}>
          <LineHead id={id} mode={mode} />
          <Statement id={id} variant="compact" evidence={false} />
        </div>
      ))}
      {lines.map(({ id, items }) => (
        <div className={`dl${focusRow === id ? ' is-focus' : ''}`} key={id} id={`line-${sid}-numbers-${id}`}>
          <LineHead id={id} mode={mode} />
          <div className="table-scroll">
          <table className="nums">
            <thead><tr><th scope="col">script</th><th scope="col">run</th><th scope="col">ok</th><th scope="col">fail</th><th scope="col">seconds</th><th scope="col">result</th></tr></thead>
            <tbody>
              {items.map(ev => (
                <tr key={ev.key}>
                  <td className="nums__script">{baseName(ev.script)}</td>
                  <td>{ev.run.date || '—'}</td>
                  <td className="num">{ev.run.ok ?? '—'}</td>
                  <td className="num">{ev.run.fail ?? '—'}</td>
                  <td className="num">{ev.run.seconds ?? '—'}</td>
                  <td className="nums__status">{ev.run.status || ev.run.lastLine || (ev.run.passed ? 'passed' : 'failed')}</td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      ))}
    </>
  );
}

function AddressTab({ rows, sid, focusRow, mode }) {
  return rows.map(id => {
    const r = rowsById()?.get(id);
    const st = statusOf(id);
    if (!r || !st) return null;
    const groups = { 1: [], [-1]: [], 0: [] };
    for (const n of r.notions || []) groups[notionSquare(n)].push(n);
    const sig = st.signature || [0, 0, 0];
    return (
      <div className={`dl${focusRow === id ? ' is-focus' : ''}`} key={id} id={`line-${sid}-address-${id}`}>
        <LineHead id={id} mode={mode} />
        <div className="dl__row"><span className="dl__label">Address</span><code className="addr">{st.address}</code></div>
        <div className="dl__row"><span className="dl__label">Signature</span><code>({sig.join(',')})</code><span className="dl__label">grade</span><code>{st.grade}</code><span className="dl__label">status</span><code>{st.status}</code></div>
        <div className="dl__row"><span className="dl__label">Notions</span>
          <span className="notions">
            {groups[1].length ? <span className="notions__g"><span className="notions__sq">+1</span>{groups[1].map(n => <code key={n}>{n}</code>)}</span> : null}
            {groups[-1].length ? <span className="notions__g"><span className="notions__sq">−1</span>{groups[-1].map(n => <code key={n}>{n}</code>)}</span> : null}
            {groups[0].length ? <span className="notions__g"><span className="notions__sq">0</span>{groups[0].map(n => <code key={n}>{n}</code>)}</span> : null}
          </span>
        </div>
        {(r.cells || []).length ? <div className="dl__row"><span className="dl__label">Cells</span><span className="reflist reflist--inline">{r.cells.map(c => <code key={c}>{c}</code>)}</span></div> : null}
        {(st.neighbours || []).length ? (
          <div className="dl__row"><span className="dl__label">One notion away</span>
            <span className="reflist reflist--inline">{st.neighbours.slice(0, 16).map(n => <RowRef key={n} id={n} />)}{st.neighbours.length > 16 ? <span className="reflist__note">and {st.neighbours.length - 16} more</span> : null}</span>
          </div>
        ) : null}
      </div>
    );
  });
}

function tabHas(tab, rows, details, numbers) {
  const R = id => rowsById()?.get(id);
  const all = [...rows, ...details, ...numbers];
  switch (tab) {
    case 'evidence': return all.some(id => (R(id)?.evidence || []).length);
    case 'needs': return details.length > 0 || rows.some(id => (R(id)?.depends || []).some(d => d.rel === 'uses-input'));
    case 'depends': { const deps = dependants(); return all.some(id => (R(id)?.depends || []).length || (deps && (deps.get(id) || []).length)); }
    case 'readings': return all.length > 0;
    case 'numbers': return numbers.length > 0 || rows.some(id => (R(id)?.evidence || []).length);
    case 'address': return all.length > 0;
    default: return false;
  }
}
function tabOfRow(id, details, numbers, available) {
  const prefer = details.includes(id) ? 'needs' : numbers.includes(id) ? 'numbers' : (rowsById()?.get(id)?.evidence || []).length ? 'evidence' : 'address';
  return available.includes(prefer) ? prefer : available[0];
}

function Tabs({ sid, rows, details, numbers, tabs, focus, s }) {
  const allRows = useMemo(() => [...rows, ...details, ...numbers], [rows, details, numbers]);
  const available = (tabs && tabs.length ? DRAWER_TABS.filter(t => tabs.includes(t)) : DRAWER_TABS).filter(t => tabHas(t, rows, details, numbers));
  const [tab, setTab] = useState(() => {
    if (focus && focus.row) return tabOfRow(focus.row, details, numbers, available);
    if (!rows.length && details.length && available.includes('needs')) return 'needs'; // a section that only lists inputs
    return available[0];
  });
  const listRef = useRef(null);
  useEffect(() => {
    if (!focus || !focus.row) return;
    const t = tabOfRow(focus.row, details, numbers, available);
    setTab(t);
    const raf = typeof requestAnimationFrame === 'function' ? requestAnimationFrame : f => setTimeout(f, 0);
    raf(() => { const el = document.getElementById(`line-${sid}-${t}-${focus.row}`); if (el) el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); });
  }, [focus && focus.nonce]); // eslint-disable-line react-hooks/exhaustive-deps
  const active = available.includes(tab) ? tab : available[0];
  const onKey = e => {
    const i = available.indexOf(active);
    let j = null;
    if (e.key === 'ArrowRight') j = (i + 1) % available.length;
    else if (e.key === 'ArrowLeft') j = (i - 1 + available.length) % available.length;
    else if (e.key === 'Home') j = 0;
    else if (e.key === 'End') j = available.length - 1;
    if (j == null) return;
    e.preventDefault();
    setTab(available[j]);
    const btn = listRef.current && listRef.current.querySelectorAll('[role="tab"]')[j];
    if (btn) btn.focus();
  };
  const focusRow = focus ? focus.row : null;
  const panelProps = { sid, focusRow, mode: s.mode };
  let panel = null;
  if (active === 'evidence') panel = <EvidenceTab rows={allRows} {...panelProps} />;
  else if (active === 'needs') panel = <NeedsTab rows={rows} details={details} {...panelProps} />;
  else if (active === 'depends') panel = <DependsTab rows={allRows} {...panelProps} />;
  else if (active === 'readings') panel = <ReadingsTab rows={allRows} sid={sid} focusRow={focusRow} s={s} />;
  else if (active === 'numbers') panel = <NumbersTab rows={rows} numbers={numbers} {...panelProps} />;
  else if (active === 'address') panel = <AddressTab rows={allRows} {...panelProps} />;
  return (
    <div className="drawer__body">
      <div className="tabs" role="tablist" aria-label="Evidence and more" ref={listRef} onKeyDown={onKey}>
        {available.map(t => (
          <button key={t} type="button" role="tab" id={`tab-${sid}-${t}`} aria-selected={t === active} aria-controls={`panel-${sid}`} tabIndex={t === active ? 0 : -1} className="tabs__tab" onClick={() => setTab(t)}>
            {DRAWER_TAB_NAMES[t]}
          </button>
        ))}
      </div>
      <div className="tabs__panel" role="tabpanel" id={`panel-${sid}`} aria-labelledby={`tab-${sid}-${active}`} tabIndex={0}>{panel}</div>
    </div>
  );
}

function HowWeKnow({ rows }) {
  const { ready, idx, last } = useChecks();
  if (!ready) return <div className="drawer__body"><p className="drawer__note">Loading…</p></div>;
  const items = new Map();
  for (const id of rows) { const r = rowsById()?.get(id); if (r) for (const ev of resolveEvidence(r, idx, last)) if (!items.has(ev.key)) items.set(ev.key, ev); }
  if (!items.size) return <div className="drawer__body"><p className="drawer__note">No script is recorded for these statements.</p></div>;
  return (
    <div className="drawer__body">
      <ul className="ev ev--plain">
        {[...items.values()].map(ev => {
          const w = runWord(ev);
          return (
            <li className={`ev__item ev__item--${w.kind}`} key={ev.key}>
              <div className="ev__line">
                <span className="ev__mark"><RunMark kind={w.kind} /></span>
                <span className="ev__word">{w.word}</span>
                {ev.check ? <a className="ev__script" href={ev.check.script} download>{baseName(ev.check.script)}</a> : <span className="ev__script">{baseName(ev.script || ev.checkId)}</span>}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/**
 * Props: sid (section id), rows (statements shown in the body), details (rows of role detail: inputs), numbers (role evidence),
 * tabs (pages.json drawer list), open, onToggle(open), focus ({ row, nonce } to bring a row's line into view).
 */
export default function Drawer({ sid, rows = [], details = [], numbers = [], tabs, open, onToggle, focus }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  const all = [...rows, ...details, ...numbers];
  const nScripts = scriptCount(all);
  if (learner && !nScripts) return null;
  if (!all.length) return null;
  const parts = [];
  if (!learner && details.length) {
    // a section that only lists inputs names their kinds in the summary, so the reader sees them without opening it
    const kinds = rows.length ? [] : [...new Set(details.map(id => { const r = rowsById()?.get(id); const i = inputsById()?.get(id); return (i && i.kindName) || (r && r.inputKindName) || ''; }).filter(Boolean))];
    parts.push(plural(details.length, 'input') + (kinds.length ? `: ${kinds.join(', ')}` : ''));
  }
  if (nScripts) parts.push(plural(nScripts, 'script'));
  return (
    <details className="drawer" id={`drawer-${sid}`} open={!!open} onToggle={e => onToggle && onToggle(e.currentTarget.open)}>
      <summary className="drawer__summary">
        <span className="drawer__title">{learner ? 'How do we know?' : 'Evidence and more'}</span>
        {parts.length ? <span className="drawer__count">{parts.join(' · ')}</span> : null}
        <span className="drawer__caret"><ChevronDown /></span>
      </summary>
      {open ? (learner ? <HowWeKnow rows={rows} /> : <Tabs sid={sid} rows={rows} details={details} numbers={numbers} tabs={tabs} focus={focus} s={s} />) : null}
    </details>
  );
}
