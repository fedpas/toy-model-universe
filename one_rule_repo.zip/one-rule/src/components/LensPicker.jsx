// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LensPicker.jsx — the lens switch: one radio list, "none" first, the lenses grouped by kind, each with the number of
// rows on this page that have a text in that lens (a lens with none is listed, greyed, "no readings yet").
import { useMemo } from 'react';
import { useSettings } from '../app/content.js';
import { peekTable, lensesByKey } from '../app/store.js';
import { lensCounts } from '../app/queries.js';
import { LENS_KIND_ORDER, LENS_KIND_NAMES } from '../app/vocab.js';
import Popover from './Popover.jsx';
import Link from './Link.jsx';
import { LensIcon } from './Icons.jsx';

export default function LensPicker({ rowIds }) {
  const s = useSettings();
  const lenses = peekTable('lenses') || [];
  const counts = useMemo(() => lensCounts(rowIds || [], s.level), [rowIds, s.level]);
  const current = s.lens ? lensesByKey()?.get(s.lens) : null;
  const kinds = [...LENS_KIND_ORDER, ...[...new Set(lenses.map(l => l.kind))].filter(k => !LENS_KIND_ORDER.includes(k))];
  const choose = (key, close) => { s.set({ lens: key }); close(); };
  return (
    <Popover label={current ? `Lens: ${current.name}` : 'Lens'} className={`pop--lens${s.lens ? ' is-active' : ''}`} panelClass="lens-panel" icon={<LensIcon />} text={current ? current.name : s.lens ? s.lens : 'Lens'}>
      {close => (
        <div className="lens-list">
          <label className="lens-opt lens-opt--none">
            <input type="radio" name="one-rule-lens" checked={!s.lens} onChange={() => choose(null, close)} />
            <span className="lens-opt__name">None</span>
            <span className="lens-opt__count">the Atlas’s own words</span>
          </label>
          {kinds.map(kind => {
            const items = lenses.filter(l => l.kind === kind);
            if (!items.length) return null;
            return (
              <fieldset className="lens-group" key={kind}>
                <legend className="lens-group__title">{LENS_KIND_NAMES[kind] || kind}</legend>
                {items.map(l => {
                  const n = counts.get(l.key) || 0;
                  return (
                    <label className={`lens-opt${n ? '' : ' is-empty'}`} key={l.key}>
                      <input type="radio" name="one-rule-lens" checked={s.lens === l.key} onChange={() => choose(l.key, close)} />
                      <span className="lens-opt__name">{l.name}</span>
                      <span className="lens-opt__count">{n ? `${n} on this page` : 'no readings yet'}</span>
                    </label>
                  );
                })}
              </fieldset>
            );
          })}
          <p className="lens-list__foot">
            {current ? <Link to={`lenses/${current.key}`} onClick={close}>About the {current.name} lens</Link> : <Link to="lenses" onClick={close}>All lenses</Link>}
          </p>
        </div>
      )}
    </Popover>
  );
}
