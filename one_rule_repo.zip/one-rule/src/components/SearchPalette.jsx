// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/SearchPalette.jsx — the search palette (BUILD_CONTRACTS interface 11). A "Search" button in the bar, or Ctrl/⌘-K, opens a
// dialog with one input; the hits (src/app/search.js: row ids, words of the texts at the current level, page titles, step names, lens
// names, glossary terms) are a listbox driven from the input (↑ ↓ move, Enter opens, Escape closes, Tab stays inside). A hit leads, with
// the current settings, to the row's home and at=<row>, to a page, a lens room or the glossary. A hit is not a statement: it shows the id,
// the page, the status word and at most the first 120 characters of the record, marked data-snippet (tests/coverage.test.mjs).
import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useSettings } from '../app/content.js';
import { buildHref } from '../app/router.js';
import { pushHash } from '../app/location.js';
import { paletteHits, wordIndex } from '../app/search.js';
import { STATUS_PLAIN } from '../app/vocab.js';
import Badge from './Badge.jsx';
import { SearchIcon, CloseIcon } from './Icons.jsx';

const KIND_WORD = { page: 'Page', step: 'Chapter', lens: 'Lens', term: 'Glossary' };
const optId = i => `search-opt-${i}`;

/** the status of a row hit: its badge when it has one, else the plain word of its status */
function HitStatus({ status, level }) {
  if (!status) return null;
  if (status.badge) return <Badge status={status.status} badge={status.badge} level={level} />;
  const w = STATUS_PLAIN[status.status];
  return w ? <span className="hit__status">{w[level === 'learner' ? 'learner' : 'research']}</span> : null;
}

/** the list of hits (rendered on its own by the coverage test) */
export function SearchResults({ hits, active = -1, onPick, onHover }) {
  const s = useSettings();
  return (
    <ul className="palette__list" id="search-list" role="listbox" aria-label="Hits">
      {hits.map((h, i) => (
        <li key={h.key} id={optId(i)} role="option" aria-selected={i === active} className={`hit hit--${h.kind}${i === active ? ' is-active' : ''}`}
          data-kind={h.kind} data-hit={h.id} data-path={h.path} data-at={h.at || undefined}
          onMouseDown={e => e.preventDefault()} onClick={() => onPick && onPick(h)} onMouseMove={() => onHover && i !== active && onHover(i)}>
          <span className="hit__line">
            <span className={`hit__id${h.kind === 'row' ? ' hit__id--row' : ''}`}>{h.kind === 'row' ? h.id : KIND_WORD[h.kind]}</span>
            {h.kind !== 'row' ? <span className="hit__label">{h.label}</span> : null}
            {h.kind === 'row' || h.kind === 'step' ? <span className="hit__page">{h.page}</span> : null}
            <HitStatus status={h.status} level={s.level} />
          </span>
          {h.snippet && h.snippet.text ? (
            <span className="hit__snippet"><span data-snippet="">{h.snippet.text}</span>{h.snippet.cut ? '…' : null}</span>
          ) : null}
        </li>
      ))}
    </ul>
  );
}

function Palette({ onClose }) {
  const s = useSettings();
  const dlg = useRef(null);
  const input = useRef(null);
  const [q, setQ] = useState('');
  const [active, setActive] = useState(-1);
  const hits = useMemo(() => paletteHits(q, s), [q, s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setActive(hits.length ? 0 : -1); }, [hits]);
  // the index of the words is built on the first opening (once per mode · level · lens), after the dialog has drawn
  useEffect(() => { const t = setTimeout(() => wordIndex(s), 0); return () => clearTimeout(t); }, [s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps

  // open as a modal dialog (the rest of the page inert); Escape and the dialog's own close end it
  useEffect(() => {
    const d = dlg.current;
    if (!d) return undefined;
    if (!d.open) { try { d.showModal(); } catch { d.setAttribute('open', ''); } }
    if (input.current) input.current.focus();
    const onCancel = e => { e.preventDefault(); onClose(); };
    const onEnd = () => onClose();
    d.addEventListener('cancel', onCancel);
    d.addEventListener('close', onEnd);
    return () => { d.removeEventListener('cancel', onCancel); d.removeEventListener('close', onEnd); if (d.open) d.close(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (active < 0) return;
    const el = document.getElementById(optId(active));
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
  }, [active]);

  const open = h => {
    if (!h) return;
    pushHash(buildHref(h.path, s, h.at ? { at: h.at } : null));
    onClose();
  };
  const onKeyDown = e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (!hits.length) return;
      const step = e.key === 'ArrowDown' ? 1 : -1;
      setActive(i => (i < 0 ? (step > 0 ? 0 : hits.length - 1) : (i + step + hits.length) % hits.length));
    } else if (e.key === 'Enter' && e.target === input.current) {
      e.preventDefault();
      open(hits[active] || hits[0]);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    } else if (e.key === 'Tab') {
      // the focus stays in the dialog: the input and the close button
      const f = [...dlg.current.querySelectorAll('input, button:not([disabled]), [href], [tabindex]:not([tabindex="-1"])')];
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  };
  const n = hits.length;
  return (
    <dialog ref={dlg} className="palette" aria-modal="true" aria-labelledby="search-title" onKeyDown={onKeyDown}
      onClick={e => { if (e.target === dlg.current) onClose(); }}>
      <div className="palette__in">
        <h2 className="vh" id="search-title">Search the Atlas</h2>
        <div className="palette__head">
          <span className="palette__icon"><SearchIcon size={16} /></span>
          <input ref={input} className="palette__input" type="search" value={q} onChange={e => setQ(e.target.value)}
            role="combobox" aria-expanded={n > 0} aria-controls="search-list" aria-autocomplete="list"
            aria-activedescendant={active >= 0 && n ? optId(active) : undefined} aria-label="Search the Atlas"
            placeholder="A row id, a word, a page, a lens or a term" autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false} />
          <button type="button" className="palette__close" onClick={onClose} aria-label="Close the search"><CloseIcon /></button>
        </div>
        <SearchResults hits={hits} active={active} onPick={open} onHover={setActive} />
        <p className="palette__status" role="status">
          {!q.trim() ? 'Type a row id, a word of a statement, a page, a lens or a term.' : n ? `${n} ${n === 1 ? 'hit' : 'hits'}` : 'Nothing matches these words at this level.'}
        </p>
        <p className="palette__keys" aria-hidden="true"><kbd>↑</kbd><kbd>↓</kbd> move · <kbd>Enter</kbd> opens · <kbd>Esc</kbd> closes</p>
      </div>
    </dialog>
  );
}

export default function SearchPalette() {
  const [open, setOpen] = useState(false);
  const [mac, setMac] = useState(false);
  const btn = useRef(null);
  const isOpen = useRef(false);
  isOpen.current = open;
  // closing gives the focus back to the Search button
  const close = () => {
    setOpen(false);
    const b = btn.current;
    if (b) setTimeout(() => { try { b.focus({ preventScroll: true }); } catch { b.focus(); } }, 0);
  };
  const closeRef = useRef(close);
  closeRef.current = close;
  useEffect(() => {
    try { setMac(/Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent || '')); } catch { /* the Ctrl label stays */ }
    const onKey = e => {
      if (!((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && (e.key === 'k' || e.key === 'K'))) return;
      e.preventDefault();
      if (isOpen.current) closeRef.current(); else setOpen(true);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);
  return (
    <>
      <button ref={btn} type="button" className="search-btn" aria-haspopup="dialog" aria-expanded={open} aria-keyshortcuts="Control+K Meta+K" aria-label="Search" onClick={() => setOpen(true)}>
        <SearchIcon />
        <span className="search-btn__text" aria-hidden="true">Search</span>
        <kbd className="search-btn__kbd" aria-hidden="true">{mac ? '⌘K' : 'Ctrl K'}</kbd>
      </button>
      {open && typeof document !== 'undefined' ? createPortal(<Palette onClose={close} />, document.body) : null}
    </>
  );
}
