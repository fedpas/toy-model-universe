// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/ErrorBoundary.jsx — keeps one failing part (a figure, a module of another owner) from taking the page down.
import { Component } from 'react';

export default class ErrorBoundary extends Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(error) { return { error }; }
  componentDidCatch(error) { if (typeof console !== 'undefined') console.warn(`[one-rule] ${this.props.name || 'a part of the page'} failed to render:`, error && error.message); }
  componentDidUpdate(prev) { if (this.state.error && prev.resetKey !== this.props.resetKey) this.setState({ error: null }); }
  render() {
    if (this.state.error) return typeof this.props.fallback === 'function' ? this.props.fallback(this.state.error) : this.props.fallback || null;
    return this.props.children;
  }
}
