// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/RichText.jsx — the words of a text record, unchanged, with `$…$` typeset by KaTeX at research level
// and the first occurrence of each assigned glossary term underlined. The text content stays the record's body.
import { useKatex, hasMath, splitMath, texToHtml } from '../app/math.js';
import GlossaryTerm from './GlossaryTerm.jsx';

export default function RichText({ text, level, terms, uid }) {
  const research = level !== 'learner';
  const mathy = research && hasMath(text);
  const katex = useKatex(mathy);
  const segs = mathy ? splitMath(text) : [{ type: 'text', value: text, start: 0, end: text.length }];

  let marks = [];
  if (terms && terms.length) {
    for (const t of terms) {
      const re = new RegExp(t.re.source, t.re.flags.includes('g') ? t.re.flags : t.re.flags + 'g');
      for (const m of text.matchAll(re)) {
        const st = m.index, en = st + m[0].length;
        if (segs.some(sg => sg.type === 'math' && st < sg.end && en > sg.start)) continue;
        marks.push({ st, en, t });
        break;
      }
    }
    marks.sort((a, b) => a.st - b.st);
    const kept = [];
    for (const mk of marks) if (!kept.length || mk.st >= kept[kept.length - 1].en) kept.push(mk);
    marks = kept;
  }

  const out = [];
  for (const sg of segs) {
    if (sg.type === 'math') {
      const html = katex ? texToHtml(sg.value) : null;
      out.push(html
        ? <span key={`m${sg.start}`} className="math" data-tex={sg.value} dangerouslySetInnerHTML={{ __html: html }} />
        : <span key={`m${sg.start}`} className="tex">{`$${sg.value}$`}</span>);
      continue;
    }
    let pos = sg.start;
    for (const mk of marks) {
      if (mk.st < sg.start || mk.en > sg.end) continue;
      if (mk.st > pos) out.push(text.slice(pos, mk.st));
      out.push(<GlossaryTerm key={`g${mk.st}`} entry={mk.t} uid={uid}>{text.slice(mk.st, mk.en)}</GlossaryTerm>);
      pos = mk.en;
    }
    if (pos < sg.end) out.push(text.slice(pos, sg.end));
  }
  return <>{out}</>;
}
