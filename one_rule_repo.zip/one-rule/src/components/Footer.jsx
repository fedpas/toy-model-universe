// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Footer.jsx — the name, the versions of the build ("v<app> · content <date>", from content/version.json, which the
// build writes from package.json and the content files: BUILD_CONTRACTS interface 10) and the way to the method.
import { useTable } from '../app/content.js';
import Link from './Link.jsx';

/** "v2.0.0 · content 2026-10-10"; without an app version only the content part */
export function versionLine(ver) {
  const content = (ver && ver.contentVersion) || 'unknown';
  return ver && ver.appVersion ? `v${ver.appVersion} · content ${content}` : `content ${content}`;
}

export default function Footer() {
  const [ver] = useTable('version');
  return (
    <footer className="foot">
      <div className="foot__in">
        <p className="foot__name"><span className="foot__brand">ONE RULE</span> <span className="foot__sub">an atlas of cells, clocks and lenses</span></p>
        <p className="foot__meta">
          <span className="foot__version" data-version="">{versionLine(ver)}</span>
          <Link to="logbook/method" className="foot__link">How this is checked</Link>
          <Link to="glossary" className="foot__link">Glossary</Link>
        </p>
        <p className="foot__lic">© 2026 the Cascade Atlas authors · PolyForm Noncommercial 1.0.0</p>
      </div>
    </footer>
  );
}
