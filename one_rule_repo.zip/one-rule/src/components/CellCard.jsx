// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/CellCard.jsx — one card of the cells page: the cell, its clock colour with c printed beside it (computed by the
// kernel), the first words of its row up to the cell name (a snippet of the text record, marked data-snippet: the card is a way to the
// cell's page, where the row is a statement), the row's badge; a tap opens the cell's page.
import { useSettings, statusOf } from '../app/content.js';
import { clockOf, cellName } from '../app/cellmath.js';
import Badge from './Badge.jsx';
import Link from './Link.jsx';

export default function CellCard({ card }) {
  const s = useSettings();
  const st = statusOf(card.primary);
  const c = card.sig ? clockOf(card.sig[0], card.sig[1], card.sig[2]) : null;
  const inner = (
    <>
      <span className="cell-card__band" style={c != null ? { background: `var(--c${c})` } : undefined} aria-hidden="true" />
      <span className="cell-card__top">
        <span className="cell-card__sig">{card.sig ? cellName(card.sig) : card.cellLabel || ''}</span>
        {c != null ? <span className="cell-card__clock"><span className="swatch" style={{ background: `var(--c${c})` }} aria-hidden="true" />c = {c}</span> : null}
      </span>
      <span className="cell-card__title" data-snippet="">{card.title}</span>
      <span className="cell-card__foot">
        {st ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null}
        {card.more > 0 ? <span className="cell-card__more" title={`${card.more} more ${card.more === 1 ? 'line' : 'lines'} on the cell page`}>+{card.more}</span> : null}
      </span>
    </>
  );
  return card.route
    ? <Link to={card.route} className="cell-card" data-card={card.primary}>{inner}</Link>
    : <div className="cell-card" data-card={card.primary}>{inner}</div>;
}
