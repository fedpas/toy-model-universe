// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/PageContext.js — what a page tells the statements on it: where each row's drawer line is (openEvidence),
// and which glossary terms each statement underlines (the first occurrence of a term on the page).
import { createContext } from 'react';

export const PageContext = createContext({
  openEvidence: null,   // (rowId) => void, or null when the page has no drawers
  hasDrawer: () => false,
  gloss: null,          // Map rowId → [{ id, term, def, re }]
});
