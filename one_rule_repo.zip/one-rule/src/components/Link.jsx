// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Link.jsx — an in-app link: the hash route plus the current settings, so the view travels with the reader.
import { useSettings } from '../app/content.js';
import { buildHref } from '../app/router.js';

export default function Link({ to, at, extra, children, ...rest }) {
  const s = useSettings();
  const params = { ...(extra || {}) };
  if (at) params.at = at;
  return <a href={buildHref(to, s, params)} {...rest}>{children}</a>;
}
