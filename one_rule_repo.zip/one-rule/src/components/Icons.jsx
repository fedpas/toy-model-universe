// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Icons.jsx — the small line icons of the app (currentColor; always decorative, the words carry the meaning).

const svg = (size, children, cls) => (
  <svg className={cls || 'icon'} width={size} height={size} viewBox="0 0 12 12" aria-hidden="true" focusable="false">{children}</svg>
);

/** the five badge shapes of 05 §4: open = dashed circle, cited = hollow square, ours = lamp, input = plug, new = star */
export function BadgeIcon({ kind, size = 12 }) {
  const st = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.4, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (kind) {
    case 'open': return svg(size, <circle cx="6" cy="6" r="4.4" {...st} strokeDasharray="2.1 1.7" />, 'icon icon--badge');
    case 'cited': return svg(size, <rect x="2" y="2" width="8" height="8" rx="0.5" {...st} />, 'icon icon--badge');
    case 'ours': return svg(size, <g {...st}><path d="M4.2 7.6C3.3 6.9 2.8 6 2.8 5a3.2 3.2 0 0 1 6.4 0c0 1-.5 1.9-1.4 2.6V8.6H4.2z" /><path d="M4.6 10.4h2.8" /></g>, 'icon icon--badge');
    case 'input': return svg(size, <g {...st}><path d="M4 1.5v2.5M8 1.5v2.5" /><path d="M2.8 4h6.4v1.6a3.2 3.2 0 0 1-6.4 0z" /><path d="M6 8.8v1.9" /></g>, 'icon icon--badge');
    case 'new': return svg(size, <path {...st} d="M6 1.4l1.35 2.85 3.1.4-2.28 2.15.58 3.08L6 8.4 3.25 9.88l.58-3.08L1.55 4.65l3.1-.4z" />, 'icon icon--badge');
    default: return null;
  }
}

export const Chevron = ({ size = 12 }) => svg(size, <path d="M4.5 2.5L8 6l-3.5 3.5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />, 'icon icon--chevron');
export const ChevronDown = ({ size = 12 }) => svg(size, <path d="M2.5 4.5L6 8l3.5-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />, 'icon icon--caret');
export const ThemeIcon = ({ size = 16 }) => svg(size, <g><circle cx="6" cy="6" r="4.6" fill="none" stroke="currentColor" strokeWidth="1.2" /><path d="M6 1.4a4.6 4.6 0 0 1 0 9.2z" fill="currentColor" /></g>);
export const ListIcon = ({ size = 16 }) => svg(size, <g fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"><path d="M4.2 3h6M4.2 6h6M4.2 9h6" /><path d="M1.8 3h.01M1.8 6h.01M1.8 9h.01" strokeWidth="1.8" /></g>);
/** a lens: a biconvex glass on its axis (the magnifier is the search) */
export const LensIcon = ({ size = 14 }) => svg(size, <g fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"><path d="M6 1.3C8.5 3.1 8.5 8.9 6 10.7C3.5 8.9 3.5 3.1 6 1.3z" /><path d="M.9 6h2.2M8.9 6h2.2" /></g>);
export const SearchIcon = ({ size = 14 }) => svg(size, <g fill="none" stroke="currentColor" strokeWidth="1.3"><circle cx="5" cy="5" r="3.5" /><path d="M7.7 7.7l3 3" strokeLinecap="round" /></g>);
export const CloseIcon = ({ size = 12 }) => svg(size, <path d="M3 3l6 6M9 3L3 9" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />);
export const MenuIcon = ({ size = 16 }) => svg(size, <path d="M1.8 3.2h8.4M1.8 6h8.4M1.8 8.8h8.4" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />);
export const CheckMark = ({ size = 12 }) => svg(size, <path d="M2.4 6.4l2.3 2.2 4.9-5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />, 'icon icon--pass');
export const CrossMark = ({ size = 12 }) => svg(size, <path d="M3 3l6 6M9 3L3 9" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />, 'icon icon--fail');
export const DotMark = ({ size = 12 }) => svg(size, <circle cx="6" cy="6" r="2.4" fill="none" stroke="currentColor" strokeWidth="1.4" />, 'icon icon--none');

/** the mark of the name: eight ticks around a ring, the clock's eight values; one tick drawn in the accent */
export function BrandMark({ size = 22 }) {
  const ticks = [];
  for (let k = 0; k < 8; k++) {
    const a = (Math.PI / 4) * k - Math.PI / 2;
    const x1 = 12 + Math.cos(a) * 6.2, y1 = 12 + Math.sin(a) * 6.2, x2 = 12 + Math.cos(a) * 9.6, y2 = 12 + Math.sin(a) * 9.6;
    ticks.push(<line key={k} x1={x1.toFixed(2)} y1={y1.toFixed(2)} x2={x2.toFixed(2)} y2={y2.toFixed(2)} className={k === 0 ? 'brand__tick brand__tick--on' : 'brand__tick'} />);
  }
  return (
    <svg className="brand__mark" width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <circle cx="12" cy="12" r="2.2" className="brand__dot" />
      {ticks}
    </svg>
  );
}
