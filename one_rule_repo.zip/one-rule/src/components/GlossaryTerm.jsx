// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/GlossaryTerm.jsx — a term of glossary.json inside a statement: dotted underline, the definition at the current
// level on hover or focus (a tooltip, never a modal), and a link to the Glossary page.
import { useRef, useState } from 'react';
import Link from './Link.jsx';

export default function GlossaryTerm({ entry, uid, children }) {
  const tipId = `gl-${uid}-${entry.id}`;
  const ref = useRef(null);
  const [shift, setShift] = useState(0);
  // keep the tooltip inside the window: shift it left when the term sits near the right edge
  const place = () => {
    const el = ref.current;
    if (!el || typeof window === 'undefined') return;
    const r = el.getBoundingClientRect();
    const w = Math.min(360, window.innerWidth * 0.8);
    const over = r.left + w - (window.innerWidth - 16);
    setShift(over > 0 ? -Math.ceil(over) : 0);
  };
  return (
    <span className="gloss" tabIndex={0} aria-describedby={tipId} ref={ref} onMouseEnter={place} onFocus={place}
      style={shift ? { '--tip-shift': `${shift}px` } : undefined}>
      {children}
      <span className="gloss__tip" role="tooltip" id={tipId}>
        <span className="gloss__term">{entry.term}</span>
        <span className="gloss__def">{entry.def}</span>
        <Link to="glossary" at={entry.id} className="gloss__more">Glossary</Link>
      </span>
    </span>
  );
}
