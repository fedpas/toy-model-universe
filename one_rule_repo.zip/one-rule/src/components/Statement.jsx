// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Statement.jsx — one row, in the words of its text record for the current (mode, level, lens).
// At most one Badge (from the computed status); a "›" that opens the row's line in its section drawer; glossary terms underlined.
// When a lens is active, the row's readings in that lens follow the text on one line (LensReading); with no lens, nothing is added.
// It renders nothing when the row has no text at this level, and it refuses free text: passing children throws.
import { useContext, useState } from 'react';
import { useSettings, textFor, statusOf } from '../app/content.js';
import { useRoute } from '../app/router.js';
import { rowHome, pageLabel } from '../app/queries.js';
import { PageContext } from './PageContext.js';
import RichText from './RichText.jsx';
import Badge from './Badge.jsx';
import Link from './Link.jsx';
import LensReading from './LensReading.jsx';
import { Chevron } from './Icons.jsx';

// characters above which a statement is shown folded to a few lines with "Show all" (the full text stays in the page)
const LONG = { body: 700, compact: 700, hero: 520 };

export default function Statement(props) {
  if (props.children != null) throw new Error('Statement renders the text record of its row and takes no children');
  const { id, register = 'full', variant = 'body', badge = true, evidence = true, where = false } = props;
  const s = useSettings();
  const ctx = useContext(PageContext);
  const route = useRoute();
  const [expanded, setExpanded] = useState(false);
  const text = textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register });
  if (text == null) return null;

  const st = statusOf(id);
  const terms = ctx.gloss ? ctx.gloss.get(id) : null;
  const foldable = LONG[variant] != null && text.length > LONG[variant];
  const canOpen = evidence && ctx.openEvidence && ctx.hasDrawer(id);
  const home = where ? rowHome(id) : null;
  const cls = ['statement', `statement--${variant}`];
  if (foldable && !expanded) cls.push('statement--folded');
  if (route.at === id) cls.push('is-target');
  const textId = `txt-${variant}-${id}`;

  return (
    <div className={cls.join(' ')} data-row={id} data-register={register} id={variant === 'body' || variant === 'hero' ? `row-${id}` : undefined}>
      <p className="statement__text" id={textId}>
        <RichText text={text} level={s.level} terms={terms} uid={`${variant}-${id}`} />
      </p>
      <LensReading id={id} />
      {(badge || canOpen || foldable || home) && (
        <div className="statement__meta">
          {badge && st ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null}
          {home && home.path !== route.path ? <Link to={home.path} at={id} className="statement__where">{pageLabel(home.path, s)}</Link> : null}
          {foldable ? (
            <button type="button" className="statement__more" aria-expanded={expanded} aria-controls={textId} onClick={() => setExpanded(x => !x)}>
              {expanded ? 'Show less' : 'Show all'}
            </button>
          ) : null}
          {canOpen ? (
            <button type="button" className="statement__ev" aria-label={`Evidence and more for this statement (${id})`} title="Evidence and more" onClick={() => ctx.openEvidence(id)}>
              <Chevron />
            </button>
          ) : null}
        </div>
      )}
    </div>
  );
}
