// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Badge.jsx — the only component that draws a status badge (BUILD_CONTRACTS §5, 05 §4).
// Shape + word, never colour alone: open (dashed circle), not yet proved here (hollow square), our reading (lamp),
// needs an input: <kind> (plug), new (star). Learner words: not finished, not yet proved here, our idea, we had to choose this, new.
// Props: { status, badge, level } — the fields of a status record (content/derived/status.json); or { kind, level } for a legend.
import { BadgeIcon } from './Icons.jsx';
import { badgeKind, BADGE_WORDS } from '../app/vocab.js';

export default function Badge({ status, badge, level = 'research', kind: forced = null, className = '' }) {
  const kind = forced || badgeKind(status, badge);
  if (!kind) return null;
  const learner = level === 'learner';
  const word = learner ? BADGE_WORDS[kind].learner : (!forced && badge) || BADGE_WORDS[kind].research;
  return (
    <span className={`badge badge--${kind}${className ? ' ' + className : ''}`} role="img" aria-label={`Status: ${word}`} title={learner || forced || !badge ? word : badge}>
      <BadgeIcon kind={kind} />
      <span className="badge__word" aria-hidden="true">{word}</span>
    </span>
  );
}
