// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/PrevNext.jsx — the previous and next page in the order of pages.json.
import { useSettings } from '../app/content.js';
import { peekTable } from '../app/store.js';
import { pageLabel } from '../app/queries.js';
import Link from './Link.jsx';

export default function PrevNext({ route }) {
  const s = useSettings();
  const pages = peekTable('pages') || [];
  const i = pages.findIndex(p => p.route === route);
  if (i < 0) return null;
  const prev = pages[i - 1], next = pages[i + 1];
  return (
    <nav className="pn" aria-label="Previous and next page">
      {prev ? (
        <Link to={prev.route} className="pn__link pn__link--prev" rel="prev">
          <span className="pn__dir">Previous</span>
          <span className="pn__title">{pageLabel(prev.route, s)}</span>
        </Link>
      ) : <span />}
      {next ? (
        <Link to={next.route} className="pn__link pn__link--next" rel="next">
          <span className="pn__dir">Next</span>
          <span className="pn__title">{pageLabel(next.route, s)}</span>
        </Link>
      ) : <span />}
    </nav>
  );
}
