// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Shell.jsx — the sticky shell: the name, the contents, the search, the three switches (mode, level, lens), the page
// outline and the theme menu. Every switch writes the address; nothing else holds the view.
import { useMemo, useState } from 'react';
import { useSettings } from '../app/content.js';
import { peekTable } from '../app/store.js';
import { pageLabel, rowsOfMatch } from '../app/queries.js';
import Segmented from './Segmented.jsx';
import LensPicker from './LensPicker.jsx';
import Popover from './Popover.jsx';
import Link from './Link.jsx';
import SearchPalette from './SearchPalette.jsx';
import { BrandMark, ListIcon, MenuIcon, ThemeIcon } from './Icons.jsx';

function Contents({ route }) {
  const s = useSettings();
  const pages = peekTable('pages') || [];
  const current = route.match && route.match.page != null ? route.match.page : null;
  return (
    <Popover label="Contents" className="pop--contents" panelClass="contents-panel" icon={<MenuIcon />} text="Contents">
      {close => (
        <ol className="contents">
          {pages.map(p => (
            <li key={p.route || 'zero'}>
              <Link to={p.route} onClick={close} aria-current={current === p.route ? 'page' : undefined} className="contents__link">{pageLabel(p.route, s)}</Link>
            </li>
          ))}
        </ol>
      )}
    </Popover>
  );
}

function Outline() {
  const s = useSettings();
  const [items, setItems] = useState([]);
  const read = () => {
    const els = [...document.querySelectorAll('#main [data-outline]')];
    setItems(els.map(el => ({ id: el.id, label: el.getAttribute('data-outline') })).filter(x => x.id && x.label));
  };
  const max = s.level === 'learner' ? 8 : 60;
  const go = (id, close) => {
    const el = document.getElementById(id);
    if (el) {
      if (el.tagName === 'DETAILS') el.open = true;
      el.scrollIntoView({ block: 'start', behavior: 'smooth' });
      const h = el.querySelector('h2, summary');
      if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
    }
    close();
  };
  return (
    <Popover label="On this page" className="pop--outline" panelClass="outline-panel" icon={<ListIcon />} text="On this page" onOpen={read}>
      {close => items.length ? (
        <ul className="outline">
          {items.slice(0, max).map(it => <li key={it.id}><button type="button" className="outline__item" onClick={() => go(it.id, close)}>{it.label}</button></li>)}
        </ul>
      ) : <p className="outline__empty">This page has no sections.</p>}
    </Popover>
  );
}

function ThemeMenu() {
  const s = useSettings();
  const opts = [['auto', 'Same as the system'], ['light', 'Light'], ['dark', 'Dark']];
  return (
    <Popover label="Theme" className="pop--theme" panelClass="theme-panel" icon={<ThemeIcon />} caret={false}>
      {close => (
        <div className="theme-list" role="radiogroup" aria-label="Theme">
          {opts.map(([v, label]) => (
            <label className="theme-opt" key={v}>
              <input type="radio" name="one-rule-theme" checked={s.theme === v} onChange={() => { s.set({ theme: v }); close(); }} />
              <span>{label}</span>
            </label>
          ))}
        </div>
      )}
    </Popover>
  );
}

export default function Shell({ route }) {
  const s = useSettings();
  const rowIds = useMemo(() => rowsOfMatch(route.match), [route.match]);
  const skip = e => { e.preventDefault(); const m = document.getElementById('main'); if (m) { m.focus(); m.scrollIntoView({ block: 'start' }); } };
  return (
    <header className="shell">
      <a className="skip" href="#main" onClick={skip}>Skip to content</a>
      <div className="shell__bar">
        <Link to="" className="brand" aria-label="ONE RULE, start page">
          <BrandMark />
          <span className="brand__name">ONE RULE</span>
        </Link>
        <div className="shell__nav"><Contents route={route} /><SearchPalette /></div>
        <div className="shell__switches">
          <Segmented label="Mode" value={s.mode} onChange={v => s.set({ mode: v })}
            options={[{ value: 'phys', label: 'Physics', short: 'Phys' }, { value: 'math', label: 'Mathematics', short: 'Math' }]} />
          <Segmented label="Level" value={s.level} onChange={v => s.set({ level: v })}
            options={[{ value: 'research', label: 'Research' }, { value: 'learner', label: 'Learner' }]} />
          <LensPicker rowIds={rowIds} />
        </div>
        <div className="shell__tools">
          <Outline />
          <ThemeMenu />
        </div>
      </div>
    </header>
  );
}
