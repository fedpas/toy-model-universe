// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/StepMap.jsx — the map of the twenty steps (06 /steps): the steps by stage, one row each, and an arrow from step B to
// step A when a row shown on A derives from a row shown on B (stepGraph in src/app/queries.js); the thicker the arrow, the more pairs of
// rows behind it. The arrows run on the left of the column of steps, those that go down the list wider than those that go up, so that two
// steps that rest on each other show two arrows. Every step is a Link; pointing at one or focusing it lights its arrows. The drawing holds
// no text but the step numbers and names of steps.json; the stage names are set beside it in HTML. Tokens only.
import { useMemo, useState } from 'react';
import { useSettings } from '../app/content.js';
import { stepGraph } from '../app/queries.js';
import { STAGE_ORDER, STAGE_NAMES } from '../app/vocab.js';
import Link from './Link.jsx';

const W = 400, X = 156, R = 11, ROW = 26, GAP = 24, TOP = 24, FOOT = 8;
const LEFT = X - R - 3;          // where the arrows leave and reach a step
const REACH = 176;               // the widest bend
const bend = (dy, down) => REACH * (1 - Math.exp(-Math.abs(dy) / 220)) * (down ? 1 : 0.62) + 10;
const width = links => (links >= 5 ? 2.4 : links >= 2 ? 1.7 : 1.1);
const pct = (v, of) => `${((100 * v) / of).toFixed(3)}%`;

/** positions of the steps: grouped by stage in the order of the stages, by number inside a stage */
export function stepMapLayout(graph) {
  const groups = STAGE_ORDER.map(st => ({ stage: st, nodes: graph.nodes.filter(n => n.stage === st) })).filter(g => g.nodes.length);
  const other = graph.nodes.filter(n => !STAGE_ORDER.includes(n.stage));
  if (other.length) groups.push({ stage: null, nodes: other });
  const pos = new Map();
  const order = [];   // the steps as the eye reads them (and as the keyboard visits them): by stage, then by number
  let row = 0;
  const bands = groups.map((g, gi) => {
    const top = TOP + gi * GAP + row * ROW;
    g.nodes.forEach((n, i) => { pos.set(n.route, { x: X, y: top + i * ROW + ROW / 2, node: n }); order.push(n); });
    row += g.nodes.length;
    return { stage: g.stage, top, bottom: top + g.nodes.length * ROW };
  });
  const H = (bands.length ? bands[bands.length - 1].bottom : TOP) + FOOT;
  return { bands, pos, order, H };
}

export default function StepMap() {
  const s = useSettings();
  const learner = s.level === 'learner';
  const graph = stepGraph();
  const L = useMemo(() => (graph ? stepMapLayout(graph) : null), [graph]);
  const [active, setActive] = useState(null);
  if (!graph || !L) return null;
  const near = new Set();
  if (active) for (const e of graph.edges) { if (e.from === active) near.add(e.to); if (e.to === active) near.add(e.from); }
  const edges = graph.edges.map(e => {
    const a = L.pos.get(e.from), b = L.pos.get(e.to);
    const down = b.y > a.y, k = bend(b.y - a.y, down);
    const on = active && (e.from === active || e.to === active);
    return { ...e, on, d: `M${LEFT} ${a.y.toFixed(1)}C${(LEFT - k).toFixed(1)} ${a.y.toFixed(1)} ${(LEFT - k).toFixed(1)} ${b.y.toFixed(1)} ${LEFT} ${b.y.toFixed(1)}` };
  });
  // the lit arrows are drawn last, over the others
  edges.sort((x, y) => (x.on ? 1 : 0) - (y.on ? 1 : 0) || x.links - y.links);
  const nameOf = n => (learner ? n.navLearner || n.nav : n.nav);
  const caption = learner
    ? 'An arrow runs from a step to a step that uses it; the thicker the arrow, the more links between the two.'
    : 'An arrow runs from a step to a step that builds on it: a statement shown on the second derives from one shown on the first. The thicker the arrow, the more such pairs.';
  return (
    <figure className={`stepmap${active ? ' is-lit' : ''}`} data-steps={graph.nodes.length} data-edges={graph.edges.length}>
      <div className="stepmap__frame" style={{ aspectRatio: `${W} / ${L.H}` }}>
        <svg className="stepmap__svg" viewBox={`0 0 ${W} ${L.H}`} width="100%" height="100%" focusable="false">
          <defs>
            <marker id="stepmap-head" viewBox="0 0 8 8" refX="7.4" refY="4" markerWidth="7" markerHeight="7" markerUnits="userSpaceOnUse" orient="auto">
              <path d="M0 .7L7.6 4 0 7.3z" className="stepmap__head" />
            </marker>
            <marker id="stepmap-head-on" viewBox="0 0 8 8" refX="7.4" refY="4" markerWidth="8" markerHeight="8" markerUnits="userSpaceOnUse" orient="auto">
              <path d="M0 .7L7.6 4 0 7.3z" className="stepmap__head stepmap__head--on" />
            </marker>
          </defs>
          <g aria-hidden="true">
            {L.bands.map((b, i) => <rect key={i} className="stepmap__band" x={2} y={b.top - 3} width={W - 4} height={b.bottom - b.top + 6} rx={6} />)}
          </g>
          <g className="stepmap__edges" aria-hidden="true">
            {edges.map(e => (
              <path key={`${e.from}>${e.to}`} d={e.d} className={`stepmap__edge${e.on ? ' is-on' : active ? ' is-off' : ''}`} style={{ strokeWidth: width(e.links) }}
                markerEnd={`url(#${e.on ? 'stepmap-head-on' : 'stepmap-head'})`} data-from={e.from} data-to={e.to} data-links={e.links} />
            ))}
          </g>
          {L.order.map(n => {
            const p = L.pos.get(n.route);
            const cls = active ? (active === n.route ? ' is-active' : near.has(n.route) ? ' is-near' : ' is-far') : '';
            return (
              <Link key={n.route} to={n.route} className={`stepmap__node${cls}`} aria-label={`Step ${n.no}: ${nameOf(n)}`} data-step={n.no}
                onMouseEnter={() => setActive(n.route)} onMouseLeave={() => setActive(null)} onFocus={() => setActive(n.route)} onBlur={() => setActive(null)}>
                <rect className="stepmap__hit" x={X - R - 5} y={p.y - ROW / 2 + 1} width={W - (X - R - 5) - 5} height={ROW - 2} rx={5} />
                <circle className="stepmap__dot" cx={X} cy={p.y} r={R} />
                <text className="stepmap__no" x={X} y={p.y} textAnchor="middle" dominantBaseline="central">{n.no}</text>
                <text className="stepmap__name" x={X + R + 8} y={p.y} dominantBaseline="central">{nameOf(n)}</text>
              </Link>
            );
          })}
        </svg>
        {L.bands.map((b, i) => (b.stage ? (
          <span key={i} className="stepmap__stage" style={{ top: pct(b.top - 21, L.H), left: pct(X - R, W) }}>{STAGE_NAMES[b.stage]}</span>
        ) : null))}
      </div>
      <figcaption className="stepmap__caption" data-connective="step-map">{caption}</figcaption>
    </figure>
  );
}
