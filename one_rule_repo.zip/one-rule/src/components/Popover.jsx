// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Popover.jsx — a button that opens a panel in place (never modal): Escape or a click outside closes it.
import { useEffect, useId, useRef, useState } from 'react';
import { ChevronDown } from './Icons.jsx';

export default function Popover({ label, icon, text, className = '', panelClass = '', caret = true, onOpen, children }) {
  const [open, setOpen] = useState(false);
  const root = useRef(null);
  const btn = useRef(null);
  const id = useId();
  useEffect(() => {
    if (!open) return undefined;
    const onDown = e => { if (root.current && !root.current.contains(e.target)) setOpen(false); };
    const onKey = e => { if (e.key === 'Escape') { setOpen(false); if (btn.current) btn.current.focus(); } };
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    if (onOpen) onOpen();
    return () => { document.removeEventListener('pointerdown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  const close = () => setOpen(false);
  return (
    <div className={`pop ${className}`} ref={root}>
      <button type="button" ref={btn} className="pop__btn" aria-expanded={open} aria-controls={id} aria-label={label} onClick={() => setOpen(o => !o)}>
        {icon}
        {text ? <span className="pop__text">{text}</span> : null}
        {caret ? <ChevronDown /> : null}
      </button>
      {open ? (
        <div className={`pop__panel ${panelClass}`} id={id} role="group" aria-label={label}>
          {typeof children === 'function' ? children(close) : children}
        </div>
      ) : null}
    </div>
  );
}
