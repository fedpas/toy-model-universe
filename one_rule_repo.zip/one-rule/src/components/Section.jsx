// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Section.jsx — a section of a page: its title, the connective line pages.json gives it (if any), the result
// statements (a hairline between them, no cards), the figures that state its rows, and one drawer.
import Statement from './Statement.jsx';
import FigureFrame from './FigureFrame.jsx';
import Drawer from './Drawer.jsx';

export default function Section({ sec, drawers = true, drawer, onDrawer, custom }) {
  const hasFigs = sec.figures && sec.figures.length > 0;
  return (
    <section className="sec" id={`sec-${sec.id}`} aria-labelledby={`h-${sec.id}`} data-outline={sec.label}>
      <h2 className="sec__title" id={`h-${sec.id}`}>{sec.label}</h2>
      {sec.connective ? <p className="sec__connective" data-connective="section">{sec.connective}</p> : null}
      <div className={`sec__grid${hasFigs ? ' sec__grid--fig' : ''}`}>
        <div className={`sec__body${custom ? ' sec__body--wide' : ''}`}>
          {custom ? custom(sec) : sec.body.map(id => <Statement key={id} id={id} />)}
        </div>
        {hasFigs ? <div className="sec__figs">{sec.figures.map(f => <FigureFrame key={f} id={f} />)}</div> : null}
      </div>
      {drawers ? (
        <Drawer
          sid={sec.id}
          rows={sec.body}
          details={sec.details}
          numbers={sec.numbers}
          tabs={sec.tabs}
          open={drawer && drawer.open}
          focus={drawer && drawer.focus}
          onToggle={o => onDrawer && onDrawer(sec.id, o)}
        />
      ) : null}
    </section>
  );
}
