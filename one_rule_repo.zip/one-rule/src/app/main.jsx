// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/main.jsx — the browser entry: settings from the address (or the stored ones), then the app.
import { createRoot } from 'react-dom/client';
import '../styles/tokens.css';
import '../styles/base.css';
import '../styles/components.css';
import { initSettings } from './settings.js';
import App from './App.jsx';

initSettings();
const el = document.getElementById('root');
const root = createRoot(el, {
  // a part that fails is replaced by its fallback (ErrorBoundary); report it as a warning, not as a page error
  onCaughtError: error => console.warn('[one-rule] a part of the page failed and was replaced:', error && error.message),
});
root.render(<App />);
