// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/cellmath.js — numbers of a cell computed live from the single kernel (engines/bitrule.js), never typed:
// the atlas Gauss sum Σ_a i^(|a∧P| − |a∧Q|) over the blades of Cl(p,q,r) (null bits weigh 0) and its phase, the clock c (core·B2, B3).
import { cell, popcount } from '../../engines/bitrule.js';

const I_POW = [[1, 0], [0, 1], [-1, 0], [0, -1]]; // i^0..i^3 as (re, im)

/** { re, im, c } for Cl(p,q,r); c = the phase of the sum in units of π/4, mod 8 */
export function gaussSum(p, q, r = 0) {
  const eps = cell(p, q, r);
  const n = eps.length;
  if (n > 12) return null;
  let P = 0, Q = 0;
  eps.forEach((e, i) => { if (e > 0) P |= 1 << i; else if (e < 0) Q |= 1 << i; });
  let re = 0, im = 0;
  for (let a = 0; a < 1 << n; a++) {
    const k = (((popcount(a & P) - popcount(a & Q)) % 4) + 4) % 4;
    re += I_POW[k][0]; im += I_POW[k][1];
  }
  const c = ((Math.round(Math.atan2(im, re) / (Math.PI / 4)) % 8) + 8) % 8;
  return { re, im, c };
}

export const clockOf = (p, q, r = 0) => { const g = gaussSum(p, q, r); return g ? g.c : null; };

/** "p,q" or "p,q,r" → [p, q, r] or null */
export function parseSignature(key) {
  const m = /^(\d{1,2}),(\d{1,2})(?:,(\d{1,2}))?$/.exec(key || '');
  return m ? [+m[1], +m[2], +(m[3] || 0)] : null;
}
export const cellName = ([p, q, r]) => (r ? `Cl(${p},${q},${r})` : `Cl(${p},${q})`);
export const cellString = ([p, q, r]) => `(${p},${q},${r})`;
