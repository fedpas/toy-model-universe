// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/math.js — `$…$` in research texts rendered with KaTeX. KaTeX (script, CSS, fonts in dist/katex/) is loaded only when a
// research-level text on screen needs it; learner level never loads or renders it. Tests install the engine with setKatex().
import { useEffect, useSyncExternalStore } from 'react';

let engine = null;
let loading = null;
const subs = new Set();
const emit = () => subs.forEach(f => f());
const htmlCache = new Map();

export function setKatex(k) { engine = k || null; htmlCache.clear(); emit(); }
export const getKatex = () => engine;

function addCss() {
  if (document.querySelector('link[data-katex]')) return;
  const l = document.createElement('link');
  l.rel = 'stylesheet'; l.href = './katex/katex.min.css'; l.setAttribute('data-katex', '');
  document.head.appendChild(l);
}
export function ensureKatex() {
  if (engine || typeof document === 'undefined') return Promise.resolve(engine);
  if (!loading) {
    loading = new Promise((resolve, reject) => {
      addCss();
      if (window.katex) { setKatex(window.katex); resolve(engine); return; }
      const s = document.createElement('script');
      s.src = './katex/katex.min.js'; s.async = true;
      s.onload = () => { setKatex(window.katex); resolve(engine); };
      s.onerror = () => { loading = null; reject(new Error('katex/katex.min.js could not be loaded')); };
      document.head.appendChild(s);
    });
  }
  return loading;
}

/** React hook: the engine (or null); starts loading it when `needed` */
export function useKatex(needed) {
  const k = useSyncExternalStore(f => { subs.add(f); return () => subs.delete(f); }, getKatex, getKatex);
  useEffect(() => { if (needed && !engine) ensureKatex().catch(() => { /* the raw $…$ stays visible */ }); }, [needed]);
  return k;
}

/** does the text hold an inline formula $…$ (an unescaped pair on one line)? */
const MATH_RE = /(?<!\\)\$([^$\n]+?)(?<!\\)\$/g;
export const hasMath = text => typeof text === 'string' && text.includes('$') && new RegExp(MATH_RE.source).test(text);

/** split a text into [{ type: 'text'|'math', value, start, end }] */
export function splitMath(text) {
  const out = [];
  let last = 0;
  for (const m of text.matchAll(MATH_RE)) {
    if (m.index > last) out.push({ type: 'text', value: text.slice(last, m.index), start: last, end: m.index });
    out.push({ type: 'math', value: m[1], start: m.index, end: m.index + m[0].length });
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push({ type: 'text', value: text.slice(last), start: last, end: text.length });
  return out;
}

/** KaTeX HTML for a TeX string (cached), or null without an engine */
export function texToHtml(tex) {
  if (!engine) return null;
  if (htmlCache.has(tex)) return htmlCache.get(tex);
  let html;
  try { html = engine.renderToString(tex, { throwOnError: false, output: 'htmlAndMathml', strict: 'ignore' }); } catch { html = null; }
  htmlCache.set(tex, html);
  return html;
}
