// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/store.js — the cache of content tables and the indexes built from them (texts by key, rows by page, dependants …).
// content.js exposes the contract functions on top of this module; tests prime the cache with primeTable().

const cache = new Map();   // name → parsed table
const pending = new Map(); // name → Promise
const errors = new Map();  // name → Error of the last failed load
const GLOBAL = '__ONE_RULE_CONTENT__';

export function primeTable(name, data) { cache.set(name, data); errors.delete(name); }
export function peekTable(name) { return cache.get(name); }
export function tableError(name) { return errors.get(name) || null; }

function viaScript(name) {
  // file:// pages cannot fetch; the build writes content/<name>.js next to each table, which sets window.__ONE_RULE_CONTENT__[name]
  return new Promise((resolve, reject) => {
    const g = (window[GLOBAL] = window[GLOBAL] || {});
    if (name in g) { resolve(g[name]); return; }
    const s = document.createElement('script');
    s.src = `./content/${name}.js`;
    s.async = true;
    s.onload = () => (name in g ? resolve(g[name]) : reject(new Error(`content/${name}.js did not define the table`)));
    s.onerror = () => reject(new Error(`content/${name} could not be loaded`));
    document.head.appendChild(s);
  });
}

/** Promise of the parsed ./content/<name>.json (derived tables: derived_<name>) */
export function loadTableRaw(name) {
  if (cache.has(name)) return Promise.resolve(cache.get(name));
  if (pending.has(name)) return pending.get(name);
  let p;
  if (typeof document === 'undefined' || typeof window === 'undefined') {
    p = Promise.reject(new Error(`table ${name} is not primed (no browser to fetch it)`));
  } else if (window.location.protocol === 'file:' || typeof fetch !== 'function') {
    p = viaScript(name);
  } else {
    p = fetch(`./content/${name}.json`)
      .then(r => { if (!r.ok) throw new Error(`content/${name}.json: HTTP ${r.status}`); return r.json(); })
      .catch(err => viaScript(name).catch(() => { throw err; }));
  }
  p = p.then(
    d => { cache.set(name, d); pending.delete(name); errors.delete(name); return d; },
    e => { pending.delete(name); errors.set(name, e); throw e; },
  );
  pending.set(name, p);
  return p;
}

// ---- memoised indexes: recomputed only when the tables they read change identity ----
const memo = new Map();
function derive(key, names, fn) {
  const deps = names.map(n => cache.get(n));
  if (deps.some(d => d === undefined || d === null)) return null;
  const m = memo.get(key);
  if (m && m.deps.length === deps.length && m.deps.every((d, i) => d === deps[i])) return m.value;
  const value = fn(...deps);
  memo.set(key, { deps, value });
  return value;
}

const SEP = '\u0001';
export const textKey = (row, lang, mode, level, lens, register) => [row, lang, mode, level, lens || '', register || 'full'].join(SEP);

export const textIndex = () => derive('textIndex', ['texts'], texts => {
  const m = new Map();
  for (const t of texts) {
    const k = textKey(t.row, t.lang || 'en', t.mode || 'both', t.level, t.lens, t.register);
    if (!m.has(k)) m.set(k, t);
  }
  return m;
});

/** lens key → level → Set of row ids that have a text in that lens */
export const lensTextIndex = () => derive('lensTextIndex', ['texts'], texts => {
  const m = new Map();
  for (const t of texts) {
    if (!t.lens) continue;
    if (!m.has(t.lens)) m.set(t.lens, new Map());
    const byLevel = m.get(t.lens);
    if (!byLevel.has(t.level)) byLevel.set(t.level, new Set());
    byLevel.get(t.level).add(t.row);
  }
  return m;
});

/**
 * lens key → row id → [records of content/lens_readings.json]: the readings of a row in a lens (BUILD_CONTRACTS interface 7),
 * in the order of the file. The table is not a core table: it is loaded when a lens is active (LensReading) or a lens page opens.
 */
export const lensReadingsIndex = () => derive('lensReadingsIndex', ['lens_readings'], recs => {
  const m = new Map();
  for (const r of Array.isArray(recs) ? recs : []) {
    if (!r || !r.lens || !r.row) continue;
    if (!m.has(r.lens)) m.set(r.lens, new Map());
    const byRow = m.get(r.lens);
    if (!byRow.has(r.row)) byRow.set(r.row, []);
    byRow.get(r.row).push(r);
  }
  return m;
});

/**
 * The text record for (row, mode, level, lens, register) after the fallback chain of 02 §2:
 * (lang, mode, level, lens) → (lang, both, level, lens) → (lang, mode, level, null) → (lang, both, level, null).
 * Returns { record, lensHit } or null.
 */
export function textRecord(rowId, { mode = 'phys', level = 'research', lens = null, register = 'full', lang = 'en' } = {}) {
  const idx = textIndex();
  if (!idx) return null;
  const tries = lens ? [[mode, lens], ['both', lens], [mode, null], ['both', null]] : [[mode, null], ['both', null]];
  for (const [m, l] of tries) {
    const rec = idx.get(textKey(rowId, lang, m, level, l, register));
    if (rec) return { record: rec, lensHit: !!l };
  }
  return null;
}

export const rowsById = () => derive('rowsById', ['rows'], rows => new Map(rows.map(r => [r.id, r])));

/** page route → [{ row, so }] for every shownOn entry (a row may sit on several pages) */
export const rowsByPage = () => derive('rowsByPage', ['rows'], rows => {
  const m = new Map();
  for (const r of rows) for (const so of r.shownOn || []) {
    if (!m.has(so.page)) m.set(so.page, []);
    m.get(so.page).push({ row: r, so });
  }
  return m;
});

/** id → [{ id: dependant, rel }]: the rows that rest on it */
export const dependants = () => derive('dependants', ['rows'], rows => {
  const m = new Map();
  for (const r of rows) for (const d of r.depends || []) {
    if (!m.has(d.id)) m.set(d.id, []);
    m.get(d.id).push({ id: r.id, rel: d.rel });
  }
  return m;
});

/** cell string as written in rows.cells → [row ids] */
export const rowsByCell = () => derive('rowsByCell', ['rows'], rows => {
  const m = new Map();
  for (const r of rows) for (const c of r.cells || []) {
    if (!m.has(c)) m.set(c, []);
    m.get(c).push(r.id);
  }
  return m;
});

export const pagesByRoute = () => derive('pagesByRoute', ['pages'], pages => new Map(pages.map(p => [p.route, p])));
export const stepsByRoute = () => derive('stepsByRoute', ['steps'], steps => new Map(steps.map(s => [s.route, s])));
export const lensesByKey = () => derive('lensesByKey', ['lenses'], lenses => new Map(lenses.map(l => [l.key, l])));
export const figuresById = () => derive('figuresById', ['figures'], figs => new Map(figs.map(f => [f.id, f])));
export const inputsById = () => derive('inputsById', ['inputs'], inputs => new Map(inputs.map(i => [i.id, i])));

/** script path (as in checks.json, "checks/…") → check record; basename → [records] for the short names some evidence entries use */
export const checksIndex = () => derive('checksIndex', ['checks'], checks => {
  const byScript = new Map(), byBase = new Map();
  for (const c of checks) {
    if (!c.script) continue;
    byScript.set(c.script, c);
    const base = c.script.split('/').pop();
    if (!byBase.has(base)) byBase.set(base, []);
    byBase.get(base).push(c);
  }
  return { byScript, byBase };
});
/** script → its latest run (the build's lastRun, 02 §5) */
export const lastRuns = () => derive('lastRuns', ['check_runs'], runs => {
  const m = new Map();
  for (const r of runs) {
    if (!r.script) continue;
    const prev = m.get(r.script);
    if (!prev || (r.date || '') >= (prev.date || '')) m.set(r.script, r);
  }
  return m;
});
