// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/router.js — hash routes (#/, #/rule, #/cells, #/cells/p,q, #/clock, #/light, #/steps, #/steps/<id>, #/shapes, #/matter,
// #/lenses, #/lenses/<key>, #/logbook[/<tab>], #/ask, #/glossary) and links that carry the current settings.
import { useMemo, useSyncExternalStore } from 'react';
import { getHash, parseHash, pushHash, subscribeLocation } from './location.js';
import { settingsQuery } from './settings.js';
import { pagesByRoute, peekTable } from './store.js';

/** path → what to render */
export function matchRoute(path) {
  const segs = path.split('/').filter(Boolean);
  if (!segs.length) return { name: 'zero', page: '' };
  const [a, b] = segs;
  const pages = pagesByRoute();
  if (a === 'cells') return b ? { name: 'cell', key: segs.slice(1).join('/') } : { name: 'cells', page: 'cells' };
  if (a === 'steps' && !b) return { name: 'steps', page: 'steps' };
  if (a === 'lenses') return b ? { name: 'lens', key: b, page: 'lenses' } : { name: 'lenses', page: 'lenses' };
  if (a === 'logbook') return { name: 'logbook', page: 'logbook', tab: b || null };
  if (a === 'ask' && !b) return { name: 'ask', page: 'ask' };
  if (a === 'glossary' && !b) return { name: 'glossary', page: 'glossary' };
  const route = segs.join('/');
  if (pages && pages.has(route)) return { name: 'page', page: route };
  return { name: 'notfound', path };
}

export function parseRoute(hash) {
  const { path, query } = parseHash(hash);
  return { path, query, at: query.get('at'), match: matchRoute(path) };
}

/** React hook: the current route { path, query, at, match } — matched again once pages.json is loaded (generic routes come from it) */
export function useRoute() {
  const hash = useSyncExternalStore(subscribeLocation, getHash, getHash);
  const pages = peekTable('pages');
  return useMemo(() => parseRoute(hash), [hash, pages]);
}

/** the address of a route under the given settings, with optional extra parameters (e.g. { at: 'GRV-012' }) */
export function buildHref(path, settings, extra) {
  const q = settingsQuery(settings || {});
  if (extra) for (const [k, v] of Object.entries(extra)) if (v != null && v !== '') q.set(k, String(v));
  const qs = q.toString();
  const p = String(path || '').replace(/^\/+/, '');
  return '#/' + p.split('/').map(s => encodeURIComponent(s).replace(/%2C/gi, ',')).join('/') + (qs ? '?' + qs : '');
}

export function navigate(path, settings, extra) { pushHash(buildHref(path, settings, extra)); }

/** route of a cell page from a cells entry: "(1,3,0)" → "cells/1,3"; "(1,n-1,0)" → "cells/1,n-1,0"; "all n" → "cells/all n" */
export function cellRoute(cell) {
  const m = /^\((\d+),(\d+),(\d+)\)$/.exec(cell);
  if (m) return `cells/${m[1]},${m[2]}${m[3] !== '0' ? ',' + m[3] : ''}`;
  return 'cells/' + cell.replace(/^\(|\)$/g, '');
}
