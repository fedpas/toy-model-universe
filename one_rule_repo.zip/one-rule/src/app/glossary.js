// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/glossary.js — which statement underlines which glossary term: the first statement on the page whose text holds the term.
// Definitions at the current level only (a term without a learner definition is not underlined at learner level).
import { textFor } from './content.js';
import { peekTable } from './store.js';

// terms whose definition is bound to one chapter ("a corner of a body in the rigid-body chapter", "a Walsh mode", "the 𝔽₂ form Q"):
// the same word elsewhere means something else, so they are explained on the Glossary page and not underlined in statements
const CONTEXT_BOUND = new Set(['form', 'vertex', 'mode']);
const esc = t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

let cacheKey = null, cacheEntries = null;
function entries(level) {
  const gl = peekTable('glossary');
  if (!gl) return [];
  if (cacheKey === gl && cacheEntries && cacheEntries.level === level) return cacheEntries.list;
  const list = [];
  for (const g of gl) {
    if (!g || !g.term || CONTEXT_BOUND.has(g.term)) continue;
    const def = level === 'learner' ? (typeof g.learner === 'string' ? g.learner : null) : g.definition;
    if (!def) continue;
    const variants = g.term.split(/\s*\/\s*/).map(v => v.trim()).filter(v => v.length >= 3);
    const res = variants.map(v => new RegExp(`(?<![\\p{L}\\p{N}])${esc(v)}(?![\\p{L}\\p{N}])`, 'iu'));
    list.push({ id: g.id, term: g.term, def, res });
  }
  cacheKey = gl; cacheEntries = { level, list };
  return list;
}

/** Map rowId → [{ id, term, def, re }] for the given rows in display order */
export function glossaryFor(orderedIds, s) {
  const out = new Map();
  const list = entries(s.level);
  if (!list.length) return out;
  const done = new Set();
  for (const id of orderedIds) {
    if (done.size === list.length) break;
    const text = textFor(id, s);
    if (!text) continue;
    for (const e of list) {
      if (done.has(e.id)) continue;
      const re = e.res.find(r => r.test(text));
      if (!re) continue;
      if (!out.has(id)) out.set(id, []);
      out.get(id).push({ id: e.id, term: e.term, def: e.def, re });
      done.add(e.id);
    }
  }
  return out;
}
