// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/content.js — content access for every part of the app (BUILD_CONTRACTS §Interfaces 1).
// Exports exactly: loadTable, useTable, useSettings, textFor, statusOf. The cache and indexes live in store.js.
import { useEffect, useReducer, useSyncExternalStore } from 'react';
import { loadTableRaw, peekTable, tableError, textRecord } from './store.js';
import { getSettings, subscribeSettings } from './settings.js';

/** Promise of the parsed content/<name>.json, fetched from ./content/<name>.json; derived tables are named derived_<name>. */
export function loadTable(name) {
  return loadTableRaw(name);
}

/** React hook: [data, error]; data is null while loading. */
export function useTable(name) {
  const [, force] = useReducer(x => x + 1, 0);
  const data = peekTable(name);
  useEffect(() => {
    if (peekTable(name) !== undefined) return undefined;
    let alive = true;
    loadTableRaw(name).then(() => alive && force(), () => alive && force());
    return () => { alive = false; };
  }, [name]);
  return data !== undefined ? [data, null] : [null, tableError(name)];
}

/** { mode: 'phys'|'math', level: 'research'|'learner', lens: string|null, theme: 'auto'|'light'|'dark', set(partial) } — from the address. */
export function useSettings() {
  return useSyncExternalStore(subscribeSettings, getSettings, getSettings);
}

/**
 * The body of the text record for a row after the fallback chain of 02 §2, or null.
 * Options: { mode, level, lens, register = 'full' }. Learner level never falls back to a research text.
 * texts.json must be loaded (the app loads it before any page renders); while it is not, this returns null and starts the load.
 */
export function textFor(rowId, { mode = 'phys', level = 'research', lens = null, register = 'full' } = {}) {
  if (peekTable('texts') === undefined) { loadTableRaw('texts').catch(() => {}); return null; }
  const hit = textRecord(rowId, { mode, level, lens, register });
  return hit ? hit.record.body : null;
}

/** The record of content/derived/status.json for a row (status, new, badge, signature, grade, mask, prime, address, neighbours), or null. */
export function statusOf(rowId) {
  const st = peekTable('derived_status');
  if (st === undefined) { loadTableRaw('derived_status').catch(() => {}); return null; }
  return (st && st[rowId]) || null;
}
