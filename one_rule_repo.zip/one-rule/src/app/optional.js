// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/optional.js — the parts other owners build: src/figures/index.js (FIGURES) and src/logbook/LogbookPage.jsx (default export).
// build.sh aliases '@one-rule/figures' and '@one-rule/logbook' to them when they exist, else to the placeholders in src/pages/optional/.
// The modules are required inside try/catch so that a module that throws while loading leaves the rest of the app working.

let FIGURES = {};
let LogbookPage = null;
const problems = [];
try {
  // eslint-disable-next-line no-undef
  const m = require('@one-rule/figures');
  FIGURES = (m && (m.FIGURES || (m.default && m.default.FIGURES))) || {};
} catch (e) { problems.push(['figures', e]); }
try {
  // eslint-disable-next-line no-undef
  const m = require('@one-rule/logbook');
  LogbookPage = (m && (m.default || m.LogbookPage)) || null;
} catch (e) { problems.push(['logbook', e]); }
if (problems.length && typeof console !== 'undefined') for (const [w, e] of problems) console.warn(`[one-rule] the ${w} module did not load; a placeholder is shown instead:`, e && e.message);

let figuresOn = true;
/** tests can switch the drawings off to isolate the pages from the figures' own code */
export function setFiguresEnabled(on) { figuresOn = !!on; }
/** the component C registered for a figure id (a function, or a memo/forwardRef object), or null */
export function figureComponent(id) {
  if (!figuresOn || !FIGURES) return null;
  const c = FIGURES[id];
  return c && (typeof c === 'function' || (typeof c === 'object' && c.$$typeof)) ? c : null;
}
export { LogbookPage };
