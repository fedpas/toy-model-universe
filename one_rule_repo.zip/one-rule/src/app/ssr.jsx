// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/ssr.jsx — the app rendered to a string for the tests (tests/coverage.test.mjs bundles this module for node):
// prime the tables, set the address, render. No browser, no fetch. renderSearch renders the hits of the search palette for a query
// (the palette itself opens only in a browser), so the test can check that a hit shows no more of a row than its snippet.
import { renderToStaticMarkup } from 'react-dom/server';
import { primeTable } from './store.js';
import { setServerHash } from './location.js';
import { setKatex } from './math.js';
import { setFiguresEnabled } from './optional.js';
import { getSettings } from './settings.js';
import { paletteHits } from './search.js';
import { SearchResults } from '../components/SearchPalette.jsx';
import App, { CORE_TABLES } from './App.jsx';
export { textFor, statusOf } from './content.js';
export { buildPageModel, cellCards } from './queries.js';
export { getSettings } from './settings.js';
export { paletteHits, rankRows, SNIPPET } from './search.js';
export { parsePersonaRules, statusLine } from './personaRules.js';

export function prime(tables) { for (const [name, data] of Object.entries(tables)) primeTable(name, data); }
export const coreTables = CORE_TABLES;
export function setKatexEngine(k) { setKatex(k); }
export function figures(on) { setFiguresEnabled(on); }
/** render the whole app (shell, page, footer) at an address such as '#/steps/grav2?m=math&l=learner' */
export function render(hash) {
  setServerHash(hash);
  return renderToStaticMarkup(<App />);
}
/** the palette's hits for a query under the settings of an address: { hits, html } */
export function renderSearch(query, hash) {
  setServerHash(hash);
  const hits = paletteHits(query, getSettings());
  return { hits, html: renderToStaticMarkup(<SearchResults hits={hits} active={hits.length ? 0 : -1} />) };
}
