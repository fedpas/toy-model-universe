// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/location.js — the address as a tiny store: the hash (route and settings) is the single source of truth.
// In the browser it follows `hashchange`; on the server (tests) the hash is set with setServerHash before each render.

const subs = new Set();
let serverHash = '';
const hasWindow = () => typeof window !== 'undefined' && typeof window.location !== 'undefined';

export function getHash() {
  return hasWindow() ? window.location.hash || '' : serverHash;
}
export function setServerHash(h) { serverHash = h || ''; }

export function subscribeLocation(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}
const emit = () => subs.forEach(f => f());
if (hasWindow() && typeof window.addEventListener === 'function') window.addEventListener('hashchange', emit);

/** replace the address without a history entry (settings changes) */
export function replaceHash(hash) {
  if (!hasWindow()) { serverHash = hash; emit(); return; }
  try { window.history.replaceState(window.history.state, '', hash); } catch { window.location.replace(hash); }
  emit();
}
/** go to an address with a history entry (navigation) */
export function pushHash(hash) {
  if (!hasWindow()) { serverHash = hash; emit(); return; }
  if (window.location.hash === hash) { emit(); return; }
  window.location.hash = hash; // fires hashchange → emit
}

/** '#/steps/grav2?m=math&at=GRV-012' → { path: 'steps/grav2', query: URLSearchParams } */
export function parseHash(hash) {
  const h = (hash || '').replace(/^#/, '');
  const qi = h.indexOf('?');
  const raw = qi < 0 ? h : h.slice(0, qi);
  let path = raw.replace(/^\/+|\/+$/g, '');
  try { path = decodeURIComponent(path); } catch { /* keep as typed */ }
  return { path, query: new URLSearchParams(qi < 0 ? '' : h.slice(qi + 1)) };
}
