// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/settings.js — mode, level, lens and theme. They live in the address (?m= &l= &lens= &theme=), so a link reproduces a view;
// localStorage keeps the last ones as a convenience for an address that names none (every access in try/catch).
import { getHash, parseHash, replaceHash, subscribeLocation } from './location.js';

export const DEFAULTS = Object.freeze({ mode: 'phys', level: 'research', lens: null, theme: 'auto' });
const SETTING_KEYS = ['m', 'l', 'lens', 'theme'];
const STORE_KEY = 'one-rule.settings';
const THEMES = ['auto', 'light', 'dark'];

export function normalize(s) {
  return {
    mode: s.mode === 'math' ? 'math' : 'phys',
    level: s.level === 'learner' ? 'learner' : 'research',
    lens: typeof s.lens === 'string' && /^[a-z0-9-]{1,40}$/.test(s.lens) ? s.lens : null,
    theme: THEMES.includes(s.theme) ? s.theme : 'auto',
  };
}
export function settingsFromQuery(q) {
  return normalize({ mode: q.get('m'), level: q.get('l'), lens: q.get('lens'), theme: q.get('theme') });
}
/** the query of a settings object: only what differs from the defaults */
export function settingsQuery(s) {
  const q = new URLSearchParams();
  if (s.mode === 'math') q.set('m', 'math');
  if (s.level === 'learner') q.set('l', 'learner');
  if (s.lens) q.set('lens', s.lens);
  if (s.theme && s.theme !== 'auto') q.set('theme', s.theme);
  return q;
}
const same = (a, b) => a.mode === b.mode && a.level === b.level && a.lens === b.lens && a.theme === b.theme;

function readStored() {
  try {
    const raw = window.localStorage.getItem(STORE_KEY);
    return raw ? normalize(JSON.parse(raw)) : null;
  } catch { return null; }
}
function writeStored(s) {
  try { window.localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch { /* private mode or blocked storage: the address still holds the view */ }
}

/** the address with these settings, keeping the path and any other parameter */
export function hashWithSettings(hash, s, { dropAt = false } = {}) {
  const { path, query } = parseHash(hash);
  const q = new URLSearchParams(query);
  SETTING_KEYS.forEach(k => q.delete(k));
  if (dropAt) q.delete('at');
  const merged = new URLSearchParams(settingsQuery(s));
  for (const [k, v] of q) merged.set(k, v);
  const qs = merged.toString();
  return '#/' + path + (qs ? '?' + qs : '');
}

function set(partial) {
  const now = getSettings();
  const next = normalize({ mode: now.mode, level: now.level, lens: now.lens, theme: now.theme, ...partial });
  if (same(next, now)) return;
  if (typeof window !== 'undefined') writeStored(next);
  replaceHash(hashWithSettings(getHash(), next, { dropAt: true }));
}

let snapHash = null, snap = null;
/** the current settings, as a stable object per address (for useSyncExternalStore) */
export function getSettings() {
  const h = getHash();
  if (h !== snapHash || !snap) {
    snapHash = h;
    snap = Object.freeze({ ...settingsFromQuery(parseHash(h).query), set });
  }
  return snap;
}
export { subscribeLocation as subscribeSettings };

/** once, before the first render in the browser: an address without settings takes the stored ones; later views are stored */
let started = false;
export function initSettings() {
  if (started || typeof window === 'undefined') return;
  started = true;
  const h = getHash();
  const { query } = parseHash(h);
  if (!SETTING_KEYS.some(k => query.has(k))) {
    const stored = readStored();
    if (stored && !same(stored, DEFAULTS)) replaceHash(hashWithSettings(h, stored));
  }
  let last = getSettings();
  subscribeLocation(() => { const s = getSettings(); if (!same(s, last)) { last = s; writeStored(normalize(s)); } });
}
