// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/personaRules.js — content/persona_rules.md read as a table (BUILD_CONTRACTS interface 12). Plain JavaScript, no JSX: the build
// (tools/build_chunks.mjs) and the coverage test run it under node, the app reads its output (content/persona_rules.json).
//   { title, sections: [{ id, title, lead: [lines], items: [{ text, learner }] }], statusWords: [{ kind, word, text, learner }] }
// A status word is an item "**word** (`kind`): text" of the section whose title names the status words; "  Plain words: text" on the
// next line is its learner wording. The HTML comment at the top (the licence) is not content.

const slug = t => String(t).toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '');
const STATUS_ITEM = /^\*\*(.+?)\*\*\s*\(`([a-z-]+)`\):\s*(.+)$/;

export function parsePersonaRules(md) {
  const text = String(md || '').replace(/<!--[\s\S]*?-->/g, '');
  let title = null;
  const sections = [];
  let cur = null, item = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/\s+$/, '');
    let m;
    if ((m = /^#\s+(.+)$/.exec(line))) { title = m[1].trim(); cur = null; item = null; continue; }
    if ((m = /^##\s+(.+)$/.exec(line))) { cur = { id: slug(m[1]), title: m[1].trim(), lead: [], items: [] }; sections.push(cur); item = null; continue; }
    if (!cur) continue;
    if (!line.trim()) { item = null; continue; }
    if ((m = /^-\s+(.+)$/.exec(line))) { item = { text: m[1].trim(), learner: null }; cur.items.push(item); continue; }
    if (item && (m = /^\s{2,}Plain words:\s*(.+)$/.exec(line))) { item.learner = m[1].trim(); continue; }
    if (item && (m = /^\s{2,}(\S.*)$/.exec(line))) { item.text += ' ' + m[1].trim(); continue; }
    cur.lead.push(line.trim());
  }
  const sw = sections.find(s => /status words/i.test(s.title));
  const statusWords = [];
  for (const it of (sw ? sw.items : [])) {
    const m = STATUS_ITEM.exec(it.text);
    if (m) statusWords.push({ kind: m[2], word: m[1], text: m[3], learner: it.learner });
  }
  return { title, sections, statusWords };
}

/** the line the Ask page shows for a status word at a level (the learner wording when there is one) */
export const statusLine = (w, level) => (level === 'learner' && w.learner ? w.learner : w.text);
