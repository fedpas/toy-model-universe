// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/queries.js — pages as queries over the rows (02 §7, 06): which rows a section shows, in which order, what goes to the drawer
// and to the open fold; titles from pages.json and steps.json; the cards of the cells page and the step index. Pure functions of the tables.
import { textFor, statusOf } from './content.js';
import {
  peekTable, rowsByPage, rowsById, pagesByRoute, stepsByRoute, lensesByKey, figuresById, lensTextIndex, lensReadingsIndex, rowsByCell,
} from './store.js';
import { KIND_ORDER, STAGE_ORDER, FIELD_ORDER, STAGE_NAMES, DRAWER_TABS, rankIn } from './vocab.js';
import { cellRoute } from './router.js';
import { clockOf } from './cellmath.js';

// ---------------------------------------------------------------- titles
const isAllCaps = t => { const up = (t.match(/[A-Z]/g) || []).length, lo = (t.match(/[a-z]/g) || []).length; return up >= 6 && up >= 4 * lo; };
const capFirst = t => (t ? t.charAt(0).toUpperCase() + t.slice(1) : t);

export function pageTitle(route, s) {
  const p = pagesByRoute()?.get(route);
  if (!p) return route;
  const t = p.title || {};
  return (s.level === 'learner' ? t.learner : null) || t[s.mode] || t.phys || route;
}
export const stepOf = route => stepsByRoute()?.get(route) || null;
const isStep = st => st && st.group !== 'shapes';
const stepNav = (st, s) => (s.level === 'learner' ? st.navLearner || st.nav : st.nav);

/** { eyebrow, title, deck } for a page header; numbers come from steps.json */
export function pageHeading(route, s) {
  const st = stepOf(route);
  let title = pageTitle(route, s), deck = null, eyebrow = null;
  if (isStep(st)) {
    eyebrow = `Step ${st.no} of ${st.total}` + (STAGE_NAMES[st.stage] ? ` · ${STAGE_NAMES[st.stage]}` : '');
    title = capFirst(title.replace(/^Step \d+:\s*/i, ''));
    if (isAllCaps(title)) { deck = title; title = stepNav(st, s); }
  }
  return { eyebrow, title, deck };
}
/** a short label for a link to a page (needs chips, prev/next, contents) */
export function pageLabel(route, s) {
  const st = stepOf(route);
  if (isStep(st)) return `Step ${st.no}: ${stepNav(st, s)}`;
  const t = pageTitle(route, s);
  return isAllCaps(t) ? capFirst(t.toLowerCase()) : t;
}

const SLUG_PREFIX = ['eq', 'ns', 'ln', 'nl', 'sh', 'cat', 'bz', 'sc'];
const SLUG_WORDS = { res: 'results', persp: 'perspectives', deadends: 'dead ends', twozeros: 'two zeros', label0: 'label 0' };
/**
 * A section title from pages.json; anchor-like slugs ("eq-grav2", "cat-w-label0") are turned into words: a slug that names a step
 * takes the step's name from steps.json, or "Results" on that step's own page (where the name is the page title).
 */
export function sectionLabel(title, id, s, route) {
  const t = title || id || '';
  if (!/^[a-z0-9-]+$/.test(t)) return t;
  let parts = t.split('-');
  let figure = false;
  if (parts.length > 1 && SLUG_PREFIX.includes(parts[0])) parts = parts.slice(1);
  if (parts.length > 1 && parts[0] === 'w') { figure = true; parts = parts.slice(1); }
  const key = parts.join('-');
  const st = (peekTable('steps') || []).find(x => x.id === key);
  let words;
  if (st && route && st.route === route) words = 'Results';
  else if (st) words = stepNav(st, s);
  else words = parts.map(w => SLUG_WORDS[w] || w).join(' ');
  return capFirst(words) + (figure ? ' (figure)' : '');
}

// ---------------------------------------------------------------- order
export const visibleIn = (row, mode) => !Array.isArray(row.visibleTo) || !row.visibleTo.length || row.visibleTo.includes(mode);

/** sort shownOn entries: physics by shownOn.order, mathematics by kind rank then field; a lens with its own ordering wins */
export function sortEntries(entries, s) {
  const lens = s.lens ? lensesByKey()?.get(s.lens) : null;
  const ord = lens ? lens.ordering : null;
  const byOrder = (a, b) => (a.so.order ?? 0) - (b.so.order ?? 0);
  const kind = e => rankIn(KIND_ORDER, e.row.kind);
  const field = e => rankIn(FIELD_ORDER, (e.row.fields || [])[0]);
  const stage = e => rankIn(STAGE_ORDER, e.row.stage);
  const grade = e => { const g = statusOf(e.row.id); return g && typeof g.grade === 'number' ? g.grade : 99; };
  let cmp;
  if (ord === 'kind') cmp = (a, b) => kind(a) - kind(b) || field(a) - field(b) || byOrder(a, b);
  else if (ord === 'stage') cmp = (a, b) => stage(a) - stage(b) || byOrder(a, b);
  else if (ord === 'grade') cmp = (a, b) => grade(a) - grade(b) || byOrder(a, b);
  else if (s.mode === 'math') cmp = (a, b) => kind(a) - kind(b) || field(a) - field(b) || byOrder(a, b);
  else cmp = byOrder;
  return entries.map((e, i) => ({ e, i })).sort((x, y) => cmp(x.e, y.e) || x.i - y.i).map(x => x.e);
}

// ---------------------------------------------------------------- the page model
const hasText = (id, s) => textFor(id, s) != null;

/** the figure of a hero: pages.json's, else the first figure whose caption row is the hero row */
export function heroFigure(def, s) {
  const figs = peekTable('figures') || [];
  const id = def.hero && def.hero.figure;
  let f = id ? figuresById()?.get(id) : null;
  if (!f && def.hero && def.hero.row) f = figs.find(x => x.captionRow === def.hero.row && (s.level !== 'learner' || x.learner)) || null;
  if (f && s.level === 'learner' && !f.learner) return null;
  return f ? f.id : null;
}

/**
 * Model of a page for the current settings:
 * { def, route, hero: { id, register, figure } | null, sections: [...], open: [{ id, label, rows }], openRows, rowSection, results, learnerShort }
 * A section: { id, label, connective, body, details, numbers, drawerRows, figures, tabs, show }.
 */
export function buildPageModel(route, s, opts = {}) {
  const def = pagesByRoute()?.get(route);
  if (!def) return null;
  const learner = s.level === 'learner';
  const custom = new Set(opts.custom || []);
  const all = (rowsByPage()?.get(route) || []).filter(e => visibleIn(e.row, s.mode));
  const heroId = def.hero && def.hero.row && rowsById()?.get(def.hero.row) && visibleIn(rowsById().get(def.hero.row), s.mode) ? def.hero.row : null;

  // sections: the declared ones (by their query), then any section the rows name that pages.json does not declare
  const groups = [];
  const claimed = new Set();
  for (const sec of def.sections || []) {
    const key = (sec.query && sec.query['shownOn.section']) || sec.id;
    const entries = all.filter(e => e.so.section === key || e.so.section === sec.id);
    entries.forEach(e => claimed.add(e));
    groups.push({ sec, id: sec.id, entries });
  }
  const extra = new Map();
  for (const e of all) if (!claimed.has(e)) { if (!extra.has(e.so.section)) extra.set(e.so.section, []); extra.get(e.so.section).push(e); }
  for (const [sid, entries] of extra) groups.push({ sec: { id: sid, title: { phys: sid, math: sid }, drawer: DRAWER_TABS }, id: sid, entries });

  let heroReg = null;
  if (heroId) heroReg = hasText(heroId, { ...s, register: 'short' }) ? 'short' : hasText(heroId, s) ? 'full' : null;
  const hero = heroId && heroReg ? { id: heroId, register: heroReg, figure: heroFigure(def, s) } : null;

  const usedFigures = new Set(hero && hero.figure ? [hero.figure] : []);
  const figs = peekTable('figures') || [];
  const rowSection = new Map();
  const sections = [], open = [], openRows = [];
  let results = 0;
  if (hero) rowSection.set(hero.id, '__hero');
  for (const g of groups) {
    const body = [], details = [], numbers = [], openHere = [];
    for (const e of sortEntries(g.entries, s)) {
      const id = e.row.id;
      if (id === heroId) continue;
      if (e.so.role === 'detail') { if (!learner && hasText(id, s)) details.push(id); continue; }
      if (e.so.role === 'evidence') { if (!learner && hasText(id, s)) numbers.push(id); continue; }
      if (!hasText(id, s)) continue;
      const st = statusOf(id);
      if (st && st.status === 'open' && !custom.has(g.id)) openHere.push(id); else body.push(id);
    }
    const ids = new Set(g.entries.map(e => e.row.id));
    const figures = figs.filter(f => f.captionRow && ids.has(f.captionRow) && !usedFigures.has(f.id) && (!learner || f.learner)).map(f => f.id);
    figures.forEach(f => usedFigures.add(f));
    const drawerRows = [...body, ...details, ...numbers];
    drawerRows.forEach(id => rowSection.set(id, g.id));
    const connective = def.connective && typeof def.connective[g.id] === 'string' ? def.connective[g.id] : null;
    const show = body.length > 0 || (!learner && (details.length > 0 || numbers.length > 0 || figures.length > 0));
    const label = sectionLabel((g.sec.title || {})[s.mode] || (g.sec.title || {}).phys, g.id, s, route);
    const allIds = [...ids].filter(id => hasText(id, s));
    sections.push({ id: g.id, label, connective, body, details, numbers, drawerRows, figures, all: allIds, tabs: g.sec.drawer || DRAWER_TABS, show: show || (custom.has(g.id) && allIds.length > 0) });
    results += body.length;
    if (openHere.length) { open.push({ id: g.id, label, rows: openHere }); openHere.forEach(id => { openRows.push(id); rowSection.set(id, '__open'); }); }
  }
  return { def, route, hero, sections, open, openRows, rowSection, results, learnerShort: learner && results < 3 };
}

/** the rows a route shows, for the lens picker's counts */
export function rowsOfMatch(match) {
  if (!match) return [];
  if (match.name === 'cell') {
    const key = cellKeyOf(match.key);
    return key ? (rowsByCell()?.get(key) || []) : [];
  }
  if (match.page == null || match.name === 'lens' || match.name === 'glossary') return [];
  return [...new Set((rowsByPage()?.get(match.page) || []).map(e => e.row.id))];
}
/** lens key → number of the given rows that have a text in that lens at this level */
export function lensCounts(rowIds, level) {
  const idx = lensTextIndex();
  const rd = lensReadingsIndex();
  const out = new Map();
  if (!idx && !rd) return out;
  const lenses = new Set([...(idx ? idx.keys() : []), ...(rd ? rd.keys() : [])]);
  for (const lens of lenses) {
    const set = idx && idx.get(lens) ? idx.get(lens).get(level) : null;
    const byRow = rd ? rd.get(lens) : null;
    // a row counts when it has a text in the lens at this level, or a reading in the lens (readings with a formula are hidden at learner level)
    const hasReading = id => { const rs = byRow && byRow.get(id); if (!rs || !rs.length) return false; return level === 'learner' ? rs.some(r => !/[$\\^_=]/.test(String(r.term || ''))) : true; };
    out.set(lens, rowIds.filter(id => (set && set.has(id)) || hasReading(id)).length);
  }
  return out;
}

// ---------------------------------------------------------------- links to rows
const QUESTION_RE = /^Q[A-Z]?\d+[a-z]?$/;
/** where a row (or a theorem / question id) lives: { path, at } */
export function rowHome(id) {
  if (/^T\d+$/.test(id)) return { path: 'logbook/theorems', at: id };
  if (/^CAND-/.test(id)) return { path: 'logbook/candidates', at: id };
  const r = rowsById()?.get(id) || rowsById()?.get(id.replace(/[a-z]$/, ''));
  if (r && r.shownOn && r.shownOn.length) {
    const so = [...r.shownOn].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0];
    return { path: so.page, at: r.id };
  }
  if (QUESTION_RE.test(id) || (peekTable('questions') || []).some(q => q.id === id)) return { path: 'logbook/questions', at: id };
  return { path: 'logbook/register', at: id };
}

// ---------------------------------------------------------------- cells
/** "1,3" → "(1,3,0)"; "1,n-1,0" → "(1,n-1,0)"; "all n" → "all n"; "row 8" → "row 8" */
export function cellKeyOf(key) {
  if (!key) return null;
  const k = key.trim();
  const m = /^(\d{1,2}),(\d{1,2})(?:,(\d{1,2}))?$/.exec(k);
  if (m) return `(${m[1]},${m[2]},${m[3] || 0})`;
  if (/^[\w+\- ]+(,[\w+\- ]+)+$/.test(k)) return `(${k})`;
  return k;
}

const CELL_RE = /Cl\((\d{1,2}),(\d{1,2})(?:,(\d{1,2}))?\)/;
/** the 25 cards of the cells page: one per first line of an ATL row, with its further lines; title = the text up to the cell name */
export function cellCards(s) {
  const entries = (rowsByPage()?.get('cells') || []).filter(e => e.so.section === 'cards' && visibleIn(e.row, s.mode));
  entries.sort((a, b) => (a.so.order ?? 0) - (b.so.order ?? 0));
  const cards = [], byPrimary = new Map();
  for (const e of entries) {
    const pid = e.row.splitFrom || e.row.id;
    if (!byPrimary.has(pid)) { const c = { primary: pid, lines: [] }; byPrimary.set(pid, c); cards.push(c); }
    byPrimary.get(pid).lines.push(e.row.id);
  }
  const out = [];
  for (const c of cards) {
    const text = textFor(c.primary, s);
    if (!text) continue;
    const row = rowsById().get(c.primary);
    const m = CELL_RE.exec(text);
    let title, sig = null, route = null, cellLabel = null;
    if (m && m.index < 160) {
      let end = m.index + m[0].length;
      const iso = /^(?:[≅=][^\s,;]+)+/.exec(text.slice(end));
      if (iso) end += iso[0].length;
      title = text.slice(0, end).replace(/[.,;:]+$/, '');
      sig = [+m[1], +m[2], +(m[3] || 0)];
      route = `cells/${sig[0]},${sig[1]}${sig[2] ? ',' + sig[2] : ''}`;
    } else {
      const cut = /[,.:;]/.exec(text);
      title = cut && cut.index > 0 && cut.index < 90 ? text.slice(0, cut.index) : text.slice(0, 80).replace(/\s+\S*$/, '') + '…';
      cellLabel = (row && row.cells && row.cells[0]) || null;
      route = cellLabel ? cellRoute(cellLabel) : null;
      // a card whose text names no Cl(p,q) but whose row names one cell "(p,q,r)" is that cell's card
      const m2 = cellLabel ? /^\((\d{1,2}),(\d{1,2}),(\d{1,2})\)$/.exec(cellLabel) : null;
      if (m2) { sig = [+m2[1], +m2[2], +m2[3]]; cellLabel = null; }
    }
    out.push({ ...c, title, sig, route, cellLabel, more: c.lines.length - 1 });
  }
  return out;
}

/** the clock of a signature, c = p − q mod 8 (null bits weigh 0), as the kernel's Gauss sum gives it (cellmath.js) */
const clockOfSig = sig => (sig ? clockOf(sig[0], sig[1], sig[2]) : null);

/**
 * The cards laid out as the lattice: one column per n = p + q + r (0 … the largest n of a card, at least 8), and in a column the cards
 * ordered by their clock c, then by p (larger first), then as the page orders them. Cards that name no single cell (a family "(1,n-1,0)",
 * "all n") are `loose`. → { columns, placed: [{ card, n, c, col, row }], loose: [card] }; col and row count from 1.
 */
export function latticeLayout(cards) {
  const placed = [], loose = [];
  cards.forEach((card, i) => {
    if (!card.sig) { loose.push(card); return; }
    const [p, q, r] = card.sig;
    placed.push({ card, n: p + q + r, c: clockOfSig(card.sig), p, i });
  });
  const columns = Math.max(9, ...placed.map(x => x.n + 1));
  placed.sort((a, b) => a.n - b.n || a.c - b.c || b.p - a.p || a.i - b.i);
  const depth = new Map();
  for (const x of placed) { const k = (depth.get(x.n) || 0) + 1; depth.set(x.n, k); x.col = x.n + 1; x.row = k; }
  return { columns, placed: placed.map(({ card, n, c, col, row }) => ({ card, n, c, col, row })), loose };
}

// ---------------------------------------------------------------- the learner's "How do we know?" line under a hero
const plural2 = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;
const scriptName = e => String(e.script || e.check || '').split('/').pop();
/**
 * One connective line from a row's evidence and status (numbers from rows.json, no law stated): the scripts that ran (named once each),
 * those only read, the inputs it uses; "checked by" only when the status is proved by the Atlas or standard.
 * e.g. "Checked by 6 scripts that ran; 1 input needed."  → string, or null for a row that is not in the tables.
 */
export function howWeKnow(rowId) {
  const r = rowsById()?.get(rowId);
  if (!r) return null;
  const ran = new Set(), read = new Set();
  for (const e of r.evidence || []) { const k = scriptName(e); if (!k) continue; if (e.mode === 'ran') ran.add(k); else if (e.mode === 'read') read.add(k); }
  for (const k of ran) read.delete(k);
  const inputs = new Set((r.depends || []).filter(d => d.rel === 'uses-input').map(d => d.id));
  const st = (statusOf(rowId) || {}).status;
  const parts = [];
  if (ran.size) parts.push(st === 'proved-by-atlas' || st === 'standard' ? `Checked by ${plural2(ran.size, 'script')} that ran` : `${plural2(ran.size, 'script')} ran on it`);
  if (read.size) parts.push(ran.size ? `${read.size} more read, not run here` : `Read in ${plural2(read.size, 'script')}, not run here`);
  if (!ran.size && !read.size) parts.push('No script is recorded for it');
  if (inputs.size) parts.push(`${plural2(inputs.size, 'input')} needed`);
  return parts.join('; ') + '.';
}

// ---------------------------------------------------------------- the map of the steps
let graphMemo = null;
/**
 * The steps as a graph (06 /steps): the twenty steps of steps.json that have a page, and an edge B → A when a row shown on step A derives
 * from a row shown on step B (rows.json `depends`, rel "derives"); `links` counts the pairs of rows behind an edge.
 * → { nodes: [step records by number], edges: [{ from, to, links }] } or null while the tables load.
 */
export function stepGraph() {
  const rows = peekTable('rows'), steps = peekTable('steps'), pages = pagesByRoute();
  if (!rows || !steps || !pages) return null;
  if (graphMemo && graphMemo.rows === rows && graphMemo.steps === steps && graphMemo.pages === pages) return graphMemo.value;
  const nodes = steps.filter(st => isStep(st) && pages.has(st.route)).sort((a, b) => a.no - b.no);
  const routes = new Set(nodes.map(n => n.route));
  const pagesOf = new Map(rows.map(r => [r.id, new Set((r.shownOn || []).map(so => so.page))]));
  const pairs = new Map();
  for (const r of rows) {
    for (const so of r.shownOn || []) {
      if (!routes.has(so.page)) continue;
      for (const d of r.depends || []) {
        if (d.rel !== 'derives') continue;
        for (const from of pagesOf.get(d.id) || []) {
          if (from === so.page || !routes.has(from)) continue;
          const k = `${from}\u0001${so.page}`;
          if (!pairs.has(k)) pairs.set(k, new Set());
          pairs.get(k).add(`${r.id}\u0001${d.id}`);
        }
      }
    }
  }
  const no = new Map(nodes.map(n => [n.route, n.no]));
  const edges = [...pairs].map(([k, set]) => { const [from, to] = k.split('\u0001'); return { from, to, links: set.size }; })
    .sort((a, b) => no.get(a.to) - no.get(b.to) || no.get(a.from) - no.get(b.from));
  const value = { nodes, edges };
  graphMemo = { rows, steps, pages, value };
  return value;
}

// ---------------------------------------------------------------- steps
function dominantField(route) {
  const n = new Map();
  for (const e of rowsByPage()?.get(route) || []) for (const f of e.row.fields || []) n.set(f, (n.get(f) || 0) + 1);
  let best = null, bc = -1;
  for (const f of FIELD_ORDER) if ((n.get(f) || 0) > bc) { best = f; bc = n.get(f) || 0; }
  return bc > 0 ? best : null;
}
/** one card per step page (steps.json, without the shape chapters), with counts from the page model at these settings */
export function stepCards(s) {
  const steps = (peekTable('steps') || []).filter(st => isStep(st) && pagesByRoute()?.has(st.route));
  return steps.map(st => {
    const m = buildPageModel(st.route, s);
    const body = m.sections.flatMap(sec => sec.body);
    const provedAtlas = body.filter(id => (statusOf(id) || {}).status === 'proved-by-atlas').length;
    return { step: st, route: st.route, hero: m.hero, results: m.results, open: m.openRows.length, provedAtlas, stage: st.stage, field: dominantField(st.route) };
  });
}
