// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/search.js — the words of the texts as a small inverted index, built on the first search for each (mode, level, lens) from the
// texts the pages show (textFor), and the two searches that read it:
//   paletteHits — the search palette (BUILD_CONTRACTS interface 11): row ids, words of the texts at the current level, page titles,
//                 step names, lens names and glossary terms; a hit carries where it leads (path and at) and a snippet of at most
//                 SNIPPET characters of its record, never more;
//   rankRows    — the Ask page (interface 12): the rows whose texts at the current level hold the question's words, ranked by the
//                 number of the question's words they hold, then by how often.
// Pure functions of the tables; nothing here writes a sentence.
import { textFor, statusOf } from './content.js';
import { peekTable, rowsById, pagesByRoute } from './store.js';
import { pageLabel, rowHome, visibleIn, stepOf } from './queries.js';
import { parseSignature, cellName } from './cellmath.js';

export const SNIPPET = 120;

// ---------------------------------------------------------------- words
const WORD = /[\p{L}\p{N}]+/gu;
/** a text as the index reads it: compatibility forms unfolded (ℝ → r, E₈ → e8, e₁₂ → e12), accents dropped, lower case */
export const fold = t => String(t ?? '').normalize('NFKD').replace(/\p{M}+/gu, '').toLowerCase();
export const tokens = t => fold(t).match(WORD) || [];

const STOP = new Set(('a an and any are as at be been being but by can could did do does doing for from had has have how i if in into is it its ' +
  'me mean means my no nor not of on or our so some such tell than that the their them then there these they this those to too us was ' +
  'we were what when where which while who whom whose why will with would you your about explain show give please').split(' '));
/** the words of a question that count: no function words, no single letters (single digits count) */
export function questionWords(q) {
  const out = [];
  for (const w of tokens(q)) if (!STOP.has(w) && (w.length > 1 || /\d/.test(w)) && !out.includes(w)) out.push(w);
  return out;
}

// ---------------------------------------------------------------- the index, once per (mode, level, lens) and per version of the tables
const cache = new Map();
function build(s) {
  const body = new Map(), post = new Map();
  for (const r of peekTable('rows') || []) {
    if (!visibleIn(r, s.mode)) continue;
    const t = textFor(r.id, s);
    if (t == null) continue;
    body.set(r.id, t);
    for (const w of tokens(t)) {
      let m = post.get(w);
      if (!m) post.set(w, (m = new Map()));
      m.set(r.id, (m.get(r.id) || 0) + 1);
    }
  }
  return { body, post, vocab: [...post.keys()] };
}
/** { body: Map rowId → text, post: Map word → Map rowId → count, vocab } for these settings, or null while the tables load */
export function wordIndex(s) {
  const texts = peekTable('texts'), rows = peekTable('rows');
  if (!texts || !rows) return null;
  const key = `${s.mode}|${s.level}|${s.lens || ''}`;
  const c = cache.get(key);
  if (c && c.texts === texts && c.rows === rows) return c.index;
  const index = build(s);
  cache.set(key, { texts, rows, index });
  return index;
}

/** the index words a question word stands for: itself, its singular, and (from four letters) the words it begins */
function expand(index, w) {
  const out = new Set();
  if (index.post.has(w)) out.add(w);
  const stem = w.length >= 4 && w.endsWith('s') ? w.slice(0, -1) : w;
  if (index.post.has(stem)) out.add(stem);
  if (stem.length >= 4) for (const v of index.vocab) if (v.startsWith(stem)) out.add(v);
  return out;
}

const STATUS_RANK = { 'proved-by-atlas': 0, standard: 1, ours: 2, cited: 3, input: 4, open: 5, meta: 6 };
const byId = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

/**
 * The rows whose texts at these settings hold the question's words: [{ id, matched, count }], at most `limit`, ranked by the number of
 * the question's words matched, then by their occurrences, then checked before open, then by id.
 */
export function rankRows(question, s, limit = 12) {
  const index = wordIndex(s);
  if (!index) return [];
  const words = questionWords(question);
  if (!words.length) return [];
  const score = new Map();
  for (const w of words) {
    const counted = new Set();
    for (const v of expand(index, w)) {
      for (const [id, c] of index.post.get(v)) {
        let sc = score.get(id);
        if (!sc) score.set(id, (sc = { id, matched: 0, count: 0 }));
        if (!counted.has(id)) { sc.matched++; counted.add(id); }
        sc.count += c;
      }
    }
  }
  const rank = id => STATUS_RANK[(statusOf(id) || {}).status] ?? 7;
  return [...score.values()].sort((a, b) => b.matched - a.matched || b.count - a.count || rank(a.id) - rank(b.id) || byId(a.id, b.id)).slice(0, limit);
}

// ---------------------------------------------------------------- where a hit leads
const CELL = /^\((\d+),(\d+),(\d+)\)$/;
/** a row's place: its home (rowHome); a line of a cell card is read on its cell's page, where every line is a statement */
export function rowPlace(id) {
  const h = rowHome(id);
  if (h.path !== 'cells') return h;
  const r = rowsById()?.get(id);
  const so = r && (r.shownOn || []).slice().sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).find(x => x.page === 'cells');
  const m = so && so.section === 'cards' ? CELL.exec((r.cells || [])[0] || '') : null;
  return m ? { path: `cells/${m[1]},${m[2]}${m[3] !== '0' ? ',' + m[3] : ''}`, at: id } : h;
}
/** the name of a place for a hit: a page's label, a cell's name, the Logbook and its tab */
export function placeLabel(path, s) {
  const p = String(path || '');
  if (p.startsWith('cells/')) { const sig = parseSignature(p.slice(6)); return sig ? cellName(sig) : p.slice(6); }
  if (p === 'logbook' || p.startsWith('logbook/')) { const tab = p.split('/')[1]; return pageLabel('logbook', s) + (tab ? ` · ${tab}` : ''); }
  return pageLabel(p, s);
}

/** at most SNIPPET characters (code points) of a text, from its start */
export function snippetOf(text) {
  if (text == null) return null;
  const cps = Array.from(String(text));
  return { text: cps.slice(0, SNIPPET).join(''), cut: cps.length > SNIPPET };
}

// ---------------------------------------------------------------- the palette
/** how well a name answers the query: 3 it starts with it, 2 it holds it, 1 every query word begins a word of it, 0 no */
function nameScore(name, qf, qwords) {
  if (!name) return 0;
  const f = fold(name);
  if (f.startsWith(qf)) return 3;
  if (f.includes(qf)) return 2;
  if (qwords.length) { const ws = tokens(name); if (qwords.every(w => ws.some(t => t.startsWith(w)))) return 1; }
  return 0;
}
const best = (names, qf, qw) => Math.max(0, ...names.map(n => nameScore(n, qf, qw)));

const ID_QUERY = /^[A-Za-z]{1,5}(?:-[0-9A-Za-z]{0,5})?$/;

/**
 * The hits of the palette for a query at these settings, in this order: the row whose id is the query; the pages (titles, step names);
 * the shape chapters; the lenses; the glossary terms; the rows whose id begins with the query; the rows whose words hold it.
 * A hit: { key, kind: 'row'|'page'|'step'|'lens'|'term', id, label, path, at, page, status, snippet }.
 */
export function paletteHits(query, s, { rows: maxRows = 12, ids: maxIds = 6 } = {}) {
  const q = String(query ?? '').trim();
  if (!q) return [];
  const qf = fold(q), qw = questionWords(q).filter(w => w.length > 1);
  const learner = s.level === 'learner';
  const hits = [], seen = new Set();
  const push = h => { if (!seen.has(h.key)) { seen.add(h.key); hits.push(h); } };
  const index = wordIndex(s);
  const shown = id => !!(index && index.body.has(id));
  const rowHit = id => {
    const place = rowPlace(id);
    const st = statusOf(id);
    return { key: 'row:' + id, kind: 'row', id, label: id, path: place.path, at: place.at, page: placeLabel(place.path, s), status: st ? { status: st.status, badge: st.badge } : null, snippet: snippetOf(index.body.get(id)) };
  };

  // the rows by id: the exact one first, the others after the places
  const idRows = [];
  if (ID_QUERY.test(q) && index) {
    const up = q.toUpperCase();
    for (const id of index.body.keys()) if (id.toUpperCase().startsWith(up)) idRows.push(id);
    idRows.sort((a, b) => (a.toUpperCase() === up ? -1 : 0) - (b.toUpperCase() === up ? -1 : 0) || byId(a, b));
    if (idRows.length && idRows[0].toUpperCase() === up) push(rowHit(idRows.shift()));
  }

  // pages: their titles in both modes and for the learner, their step names
  const places = [];
  for (const p of peekTable('pages') || []) {
    const st = stepOf(p.route);
    const t = p.title || {};
    const names = [pageLabel(p.route, s), t.phys, t.math, t.learner, st && st.nav, st && st.navLearner, st && st.name];
    const sc = best(names, qf, qw);
    if (sc) places.push({ sc, h: { key: 'page:' + p.route, kind: 'page', id: p.route, label: pageLabel(p.route, s), path: p.route, at: null, page: pageLabel(p.route, s), status: null, snippet: null } });
  }
  // the chapters of steps.json that have no page of their own (the shapes): their page, at their section when it has one
  for (const st of peekTable('steps') || []) {
    if (pagesByRoute()?.has(st.route)) continue;
    const parent = st.route.split('/')[0];
    if (!pagesByRoute()?.has(parent)) continue;
    const sc = best([st.nav, st.navLearner, st.name], qf, qw);
    if (!sc) continue;
    const secId = `sh-${st.id}`;
    const hasSec = (pagesByRoute().get(parent).sections || []).some(x => x.id === secId);
    const name = learner ? st.navLearner || st.nav : st.nav;
    places.push({ sc, h: { key: 'step:' + st.route, kind: 'step', id: st.id, label: name, path: parent, at: hasSec ? secId : null, page: pageLabel(parent, s), status: null, snippet: null } });
  }
  places.sort((a, b) => b.sc - a.sc).forEach(x => push(x.h));

  // lenses and glossary terms
  for (const l of peekTable('lenses') || []) {
    if (!best([l.name, l.short, l.key], qf, qw)) continue;
    push({ key: 'lens:' + l.key, kind: 'lens', id: l.key, label: l.name, path: `lenses/${l.key}`, at: null, page: placeLabel('lenses', s), status: null, snippet: snippetOf(l.describes || null) });
  }
  for (const g of peekTable('glossary') || []) {
    if (!g || !g.term) continue;
    if (!best([g.term, ...g.term.split(/\s*\/\s*/)], qf, qw)) continue;
    const def = learner ? (typeof g.learner === 'string' ? g.learner : null) : g.definition || null;
    push({ key: 'term:' + g.id, kind: 'term', id: g.id, label: g.term, path: 'glossary', at: g.id, page: placeLabel('glossary', s), status: null, snippet: snippetOf(def) });
  }

  // the other rows whose id begins with the query, then the rows by their words
  idRows.slice(0, maxIds).forEach(id => push(rowHit(id)));
  if (index) for (const r of rankRows(q, s, maxRows)) if (shown(r.id)) push(rowHit(r.id));
  return hits;
}
