// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/theme.js — the theme actually in use ('light' | 'dark'): the setting, or the system preference when it is 'auto'.
import { useSyncExternalStore } from 'react';

const query = () => (typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null);
function subscribe(fn) {
  const q = query();
  if (!q) return () => {};
  q.addEventListener ? q.addEventListener('change', fn) : q.addListener(fn);
  return () => (q.removeEventListener ? q.removeEventListener('change', fn) : q.removeListener(fn));
}
const systemDark = () => { const q = query(); return !!(q && q.matches); };

export function useResolvedTheme(theme) {
  const dark = useSyncExternalStore(subscribe, systemDark, () => false);
  if (theme === 'light' || theme === 'dark') return theme;
  return dark ? 'dark' : 'light';
}

/** reflect the settings on <html>: data-theme (only when forced) and data-level (learner type sizes) */
export function applyDocumentSettings({ theme, level }) {
  if (typeof document === 'undefined') return;
  const el = document.documentElement;
  if (theme === 'light' || theme === 'dark') el.setAttribute('data-theme', theme); else el.removeAttribute('data-theme');
  if (level === 'learner') el.setAttribute('data-level', 'learner'); else el.removeAttribute('data-level');
}
