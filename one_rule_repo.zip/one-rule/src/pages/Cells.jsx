// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Cells.jsx — `/cells`: the pages.json entry of the cells, with its "cards" section drawn as the lattice of the cell cards
// (one per first line of an ATL row; the further lines of a card are on the cell's page): one column per n = p + q, and in a column the
// cards in the order of their clock c = p − q mod 8, each in its clock colour (computed by the kernel), with a legend of the eight
// colours. On a narrow screen the same list is the grid of cards (the placement lives in the stylesheet). Cards that name a family of
// cells rather than one cell follow the lattice.
import { useMemo } from 'react';
import { useSettings } from '../app/content.js';
import { cellCards, latticeLayout } from '../app/queries.js';
import Page from './Page.jsx';
import CellCard from '../components/CellCard.jsx';

const CLOCKS = [0, 1, 2, 3, 4, 5, 6, 7];

/** the eight clock colours, each with its word (05 §1: a word always accompanies a colour) */
export function ClockLegend() {
  return (
    <div className="clock-legend">
      <span className="clock-legend__lead" id="clock-legend-lead">Clock colour</span>
      <ul className="clock-legend__list" aria-labelledby="clock-legend-lead">
        {CLOCKS.map(c => (
          <li className="clock-legend__item" key={c} data-clock={c}>
            <span className="swatch" style={{ background: `var(--c${c})` }} aria-hidden="true" />
            <span className="clock-legend__word">c = {c}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CellLattice({ sec }) {
  const s = useSettings();
  const cards = useMemo(() => cellCards(s), [s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  const ids = new Set(sec.all);
  const L = useMemo(() => latticeLayout(cards.filter(c => ids.has(c.primary))), [cards, sec.all]); // eslint-disable-line react-hooks/exhaustive-deps
  const learner = s.level === 'learner';
  const heads = Array.from({ length: L.columns }, (_, n) => n);
  return (
    <div className="lattice" style={{ '--cols': L.columns }}>
      <ClockLegend />
      <div className="lattice__heads" aria-hidden="true">
        {heads.map(n => <span className="lattice__head" key={n}>{learner ? `${n} ${n === 1 ? 'switch' : 'switches'}` : `n = ${n}`}</span>)}
      </div>
      <ol className="cell-grid lattice__grid" aria-label={learner ? 'The cards, by number of switches' : 'The cards, by n and clock'}>
        {L.placed.map(x => (
          <li key={x.card.primary} className="lattice__slot" style={{ '--col': x.col, '--row': x.row }} data-n={x.n} data-clock={x.c}>
            <CellCard card={x.card} />
          </li>
        ))}
      </ol>
      {L.loose.length ? (
        <div className="lattice__loose">
          <h3 className="lattice__loose-title">{learner ? 'Any number of switches' : 'Every n'}</h3>
          <ul className="cell-grid">
            {L.loose.map(c => <li key={c.primary}><CellCard card={c} /></li>)}
          </ul>
        </div>
      ) : null}
    </div>
  );
}

const CUSTOM = { cards: sec => <CellLattice sec={sec} /> };

export default function Cells() {
  return <Page route="cells" custom={CUSTOM} />;
}
