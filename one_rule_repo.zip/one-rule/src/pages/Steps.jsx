// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Steps.jsx — `/steps`: the map of the twenty steps (which step builds on which, from the rows' derivations: StepMap, beside
// the hero), then the index of the steps from steps.json, grouped by stage (physics) or by the field most of the step's rows belong to
// (mathematics); each card with its number, its name, its hero line and its counts.
import { useMemo } from 'react';
import { useSettings } from '../app/content.js';
import { stepCards } from '../app/queries.js';
import { STAGE_ORDER, STAGE_NAMES, FIELD_ORDER, FIELD_NAMES } from '../app/vocab.js';
import Page from './Page.jsx';
import Link from '../components/Link.jsx';
import Statement from '../components/Statement.jsx';
import StepMap from '../components/StepMap.jsx';

const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;

function StepCard({ c }) {
  const s = useSettings();
  return (
    <article className="step-card">
      <Link to={c.route} className="step-card__link">
        <span className="step-card__no" aria-label={`Step ${c.step.no}`}>{c.step.no}</span>
        <span className="step-card__name">{s.level === 'learner' ? c.step.navLearner || c.step.nav : c.step.nav}</span>
      </Link>
      {c.hero ? <Statement id={c.hero.id} register={c.hero.register} variant="card" evidence={false} /> : null}
      <p className="step-card__counts">
        <span>{plural(c.results, 'result')}</span>
        {c.open ? <span>{c.open} open</span> : null}
      </p>
    </article>
  );
}

function StepIndex() {
  const s = useSettings();
  const cards = useMemo(() => stepCards(s), [s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  const math = s.mode === 'math';
  const order = math ? [...FIELD_ORDER, null] : STAGE_ORDER;
  const keyOf = c => (math ? c.field : c.stage);
  const nameOf = k => (math ? (k ? FIELD_NAMES[k] : 'Other') : STAGE_NAMES[k]);
  const groups = order.map(k => ({ k, items: cards.filter(c => keyOf(c) === k) })).filter(g => g.items.length);
  const title = math ? 'The steps by field' : 'The steps by stage';
  return (
    <section className="sec sec--index" id="sec-index" aria-labelledby="h-index" data-outline={title}>
      <h2 className="sec__title" id="h-index">{title}</h2>
      {groups.map(g => (
        <div className="step-group" key={String(g.k)}>
          <h3 className="step-group__title">{nameOf(g.k)}</h3>
          <ol className="step-cards">
            {g.items.map(c => <li key={c.route}><StepCard c={c} /></li>)}
          </ol>
        </div>
      ))}
    </section>
  );
}

export default function Steps() {
  return <Page route="steps" heroAside={<StepMap />} afterHero={<StepIndex />} />;
}
