// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Page.jsx — the generic page: the pages.json entry of a route, rendered with the shared frame.
// `custom` maps a section id to its own renderer (the cards of the cells page); such a section keeps all its rows, open ones included.
import { useMemo } from 'react';
import { useSettings } from '../app/content.js';
import { buildPageModel } from '../app/queries.js';
import PageView from './PageView.jsx';
import NotFound from './NotFound.jsx';

export default function Page({ route, custom, ...rest }) {
  const s = useSettings();
  const customKeys = custom ? Object.keys(custom).join(',') : '';
  const model = useMemo(
    () => buildPageModel(route, s, { custom: customKeys ? customKeys.split(',') : [] }),
    [route, s.mode, s.level, s.lens, customKeys], // eslint-disable-line react-hooks/exhaustive-deps
  );
  if (!model) return <NotFound />;
  return <PageView model={model} custom={custom} {...rest} />;
}
