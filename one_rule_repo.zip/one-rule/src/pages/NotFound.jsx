// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/NotFound.jsx — an address that names no page.
import Link from '../components/Link.jsx';

export default function NotFound() {
  return (
    <article className="page page--missing" data-route="missing">
      <header className="ph">
        <h1 className="ph__title" id="page-title">No page at this address</h1>
        <p className="ph__lede">The address may be mistyped. <Link to="">Go to the start page</Link> or open the contents in the bar above.</p>
      </header>
    </article>
  );
}
