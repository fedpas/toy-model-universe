// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/optional/logbook.jsx — stands in for src/logbook/LogbookPage.jsx while that module does not exist;
// the logbook route then renders the pages.json entry of the Logbook with the generic page.
export default null;
