// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/optional/figures.js — stands in for src/figures/index.js while that module does not exist: no drawings, every
// figure renders as a labelled placeholder.
export const FIGURES = {};
