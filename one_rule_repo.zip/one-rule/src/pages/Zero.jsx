// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Zero.jsx — `/`: the two rows of the start page and one card per stage of the twenty steps, with the counts of
// statements proved by the Atlas and of open items, taken from the data (research level, so the counts describe the Atlas, not the view).
import { useMemo } from 'react';
import { useSettings, statusOf } from '../app/content.js';
import { stepCards, buildPageModel, pageLabel } from '../app/queries.js';
import { STAGE_ORDER, STAGE_NAMES } from '../app/vocab.js';
import { pagesByRoute } from '../app/store.js';
import Page from './Page.jsx';
import Link from '../components/Link.jsx';

const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;

function Counts({ proved, open }) {
  return (
    <p className="stage-card__counts">
      <span className="count"><span className="count__n">{proved}</span> proved here</span>
      <span className="count"><span className="count__n">{open}</span> open</span>
    </p>
  );
}

function StageCards() {
  const s = useSettings();
  const research = { mode: s.mode, level: 'research', lens: s.lens };
  const cards = useMemo(() => stepCards(research), [s.mode, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  const calib = useMemo(() => ['light', 'matter'].filter(r => pagesByRoute()?.has(r)).map(r => {
    const m = buildPageModel(r, research);
    const proved = m.sections.reduce((k, sec) => k + sec.body.filter(id => (statusOf(id) || {}).status === 'proved-by-atlas').length, 0);
    return { route: r, proved, open: m.openRows.length };
  }), [s.mode, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  const stages = STAGE_ORDER.filter(st => cards.some(c => c.stage === st));
  const provedHere = c => c.provedAtlas;
  return (
    <section className="sec sec--stages" id="sec-stages" aria-labelledby="h-stages" data-outline="The steps by stage">
      <h2 className="sec__title" id="h-stages">The steps by stage</h2>
      <div className="stage-cards">
        {stages.map(st => {
          const cs = cards.filter(c => c.stage === st);
          return (
            <article className="stage-card" key={st}>
              <h3 className="stage-card__title">{STAGE_NAMES[st]}</h3>
              <Counts proved={cs.reduce((k, c) => k + provedHere(c), 0)} open={cs.reduce((k, c) => k + c.open, 0)} />
              <ol className="stage-card__steps">
                {cs.map(c => (
                  <li key={c.route}>
                    <Link to={c.route} className="stage-card__step">
                      <span className="stage-card__no">{c.step.no}</span>
                      <span>{s.level === 'learner' ? c.step.navLearner || c.step.nav : c.step.nav}</span>
                    </Link>
                  </li>
                ))}
              </ol>
            </article>
          );
        })}
        {calib.length ? (
          <article className="stage-card stage-card--calib">
            <h3 className="stage-card__title">Calibrations</h3>
            <Counts proved={calib.reduce((k, c) => k + c.proved, 0)} open={calib.reduce((k, c) => k + c.open, 0)} />
            <ul className="stage-card__steps">
              {calib.map(c => <li key={c.route}><Link to={c.route} className="stage-card__step"><span>{pageLabel(c.route, s)}</span></Link></li>)}
            </ul>
          </article>
        ) : null}
      </div>
      <p className="stage-cards__total">{plural(cards.length, 'step')} · <Link to="steps">all steps</Link> · <Link to="cells">the cells</Link> · <Link to="lenses">the lenses</Link></p>
    </section>
  );
}

export default function Zero() {
  return <Page route="" drawers={false} afterSections={<StageCards />} />;
}
