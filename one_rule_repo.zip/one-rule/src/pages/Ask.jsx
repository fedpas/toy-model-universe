// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Ask.jsx — `/ask`: the guide answers from the rows, deterministically (07 §6, BUILD_CONTRACTS interface 12). The question's
// words are matched against the texts at the current level (rankRows in src/app/search.js); the answer is the list of the matching rows,
// the rows with most of the words first, at most twelve, each rendered with Statement (its own words, its badge, the page it lives on)
// beside its id, with one drawer for their evidence. The status words are explained from content/persona_rules.md in a fold. No prose is
// generated; an empty answer says so in one line. The question lives in the address (?q=), so a link reproduces the answer.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSettings, useTable } from '../app/content.js';
import { useRoute, buildHref } from '../app/router.js';
import { pushHash } from '../app/location.js';
import { rowsById } from '../app/store.js';
import { rankRows, questionWords } from '../app/search.js';
import { statusLine } from '../app/personaRules.js';
import { BADGE_KINDS } from '../app/vocab.js';
import { PageContext } from '../components/PageContext.js';
import Page from './Page.jsx';
import Statement from '../components/Statement.jsx';
import Drawer from '../components/Drawer.jsx';
import Badge from '../components/Badge.jsx';
import { SearchIcon } from '../components/Icons.jsx';

export const ASK_MAX = 12;

/** the status words, each with its line from content/persona_rules.md at the current level (connectives, one line each) */
function StatusWords() {
  const s = useSettings();
  const [rules] = useTable('persona_rules');
  const words = rules && Array.isArray(rules.statusWords) ? rules.statusWords : [];
  if (!words.length) return null;
  return (
    <details className="fold fold--words" id="sec-status-words" data-outline="How to read the status words">
      <summary className="fold__summary">
        <span className="fold__title">How to read the status words</span>
      </summary>
      <ul className="words">
        {words.map(w => (
          <li className="words__item" key={w.kind} data-kind={w.kind}>
            <span className="words__mark">
              {BADGE_KINDS.includes(w.kind) ? <Badge kind={w.kind} level={s.level} /> : <span className="words__plain">{w.word}</span>}
            </span>
            <span className="words__line" data-connective="persona" data-kind={w.kind}>{statusLine(w, s.level)}</span>
          </li>
        ))}
      </ul>
    </details>
  );
}

function Answer({ asked, s }) {
  const ranked = useMemo(() => rankRows(asked, s, ASK_MAX), [asked, s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  const ids = useMemo(() => ranked.map(h => h.id), [ranked]);
  const matched = new Map(ranked.map(h => [h.id, h.matched]));
  const [open, setOpen] = useState(false);
  const [focus, setFocus] = useState({ sid: 'ask', row: null, nonce: 0 });
  useEffect(() => { setOpen(false); }, [ids]);
  const learner = s.level === 'learner';
  const openEvidence = useCallback(row => { setOpen(true); setFocus(f => ({ sid: 'ask', row, nonce: f.nonce + 1 })); }, []);
  const hasDrawer = useCallback(row => ids.includes(row) && (!learner || ((rowsById()?.get(row)?.evidence) || []).length > 0), [ids, learner]);
  const ctx = useMemo(() => ({ openEvidence, hasDrawer, gloss: null }), [openEvidence, hasDrawer]);
  if (!ids.length) return <p className="ask__empty" data-connective="ask-empty">No statement holds these words at this level.</p>;
  return (
    <div className="ask__answer">
      <p className="ask__count" data-connective="ask-count">
        {ids.length === 1 ? 'One row holds these words.' : `${ids.length} rows hold these words; those with the most of them come first.`}
      </p>
      <PageContext.Provider value={ctx}>
        <ol className="ask__hits">
          {ids.map(id => (
            <li className="ask__hit" key={id} data-row={id} data-matched={matched.get(id)}>
              <span className="ask__id">{id}</span>
              <Statement id={id} where />
            </li>
          ))}
        </ol>
        <Drawer sid="ask" rows={ids} open={open} focus={focus.row ? focus : null} onToggle={setOpen} />
      </PageContext.Provider>
    </div>
  );
}

function AskBox() {
  const s = useSettings();
  const route = useRoute();
  const asked = (route.query.get('q') || '').trim();
  const [q, setQ] = useState(asked);
  useEffect(() => { setQ(asked); }, [asked]);
  const words = useMemo(() => questionWords(asked), [asked]);
  const submit = e => {
    e.preventDefault();
    const v = q.trim();
    pushHash(buildHref('ask', s, v ? { q: v } : null));
  };
  return (
    <section className="sec sec--ask" id="sec-ask" aria-labelledby="h-ask" data-outline="Your question">
      <h2 className="sec__title" id="h-ask">Your question</h2>
      <form className="ask__form" role="search" onSubmit={submit}>
        <label className="vh" htmlFor="ask-q">Your question, in words of the Atlas</label>
        <span className="ask__icon" aria-hidden="true"><SearchIcon size={16} /></span>
        <input id="ask-q" name="q" className="ask__input" type="search" value={q} onChange={e => setQ(e.target.value)}
          placeholder="Words of a statement, such as clock or mirror" autoComplete="off" spellCheck={false} />
        <button type="submit" className="btn btn--on ask__go">Ask</button>
      </form>
      {asked ? (
        <div className="ask__result" aria-live="polite">
          {words.length ? <p className="ask__words">Words looked for: {words.slice(0, 12).map((w, i) => <span key={w}>{i ? ' · ' : ''}<b>{w}</b></span>)}</p> : null}
          <Answer asked={asked} s={s} />
        </div>
      ) : null}
      <StatusWords />
    </section>
  );
}

export default function Ask() {
  // the page works at every level (the answer is drawn from the texts at that level), so it carries no "no plain-words version" notice
  return <Page route="ask" afterHero={<AskBox />} learnerNotice={false} />;
}
