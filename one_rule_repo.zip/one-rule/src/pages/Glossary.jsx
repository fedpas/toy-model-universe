// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Glossary.jsx — `/glossary`: the terms of glossary.json with their definition at the current level, and the status words
// the badges use.
import { useEffect } from 'react';
import { useSettings } from '../app/content.js';
import { useRoute } from '../app/router.js';
import { peekTable } from '../app/store.js';
import { BADGE_KINDS } from '../app/vocab.js';
import PageHeader from '../components/PageHeader.jsx';
import PrevNext from '../components/PrevNext.jsx';
import Badge from '../components/Badge.jsx';

export default function Glossary() {
  const s = useSettings();
  const route = useRoute();
  const terms = peekTable('glossary') || [];
  const learner = s.level === 'learner';
  useEffect(() => {
    if (!route.at) return;
    const el = document.getElementById(`term-${route.at}`);
    if (el) el.scrollIntoView({ block: 'start' });
  }, [route.at]);
  return (
    <article className="page page--glossary" data-route="glossary">
      <PageHeader route="glossary" />
      <section className="sec" id="sec-terms" aria-labelledby="h-terms" data-outline="Terms">
        <h2 className="sec__title" id="h-terms">Terms</h2>
        <dl className="glossary">
          {terms.map(t => {
            const def = learner ? (typeof t.learner === 'string' ? t.learner : null) : t.definition;
            return (
              <div className={`glossary__entry${route.at === t.id ? ' is-target' : ''}`} key={t.id} id={`term-${t.id}`}>
                <dt className="glossary__term">{t.term}</dt>
                <dd className="glossary__def" data-source={def ? 'glossary' : undefined}>{def || <span className="empty">No plain-words definition yet.</span>}</dd>
              </div>
            );
          })}
        </dl>
      </section>
      <section className="sec" id="sec-status-words" aria-labelledby="h-status-words" data-outline="Status words">
        <h2 className="sec__title" id="h-status-words">Status words</h2>
        <ul className="legend">
          {BADGE_KINDS.map(k => (
            <li className="legend__item" key={k}>
              <Badge kind={k} level="research" />
              <span className="legend__alt">learner word</span>
              <Badge kind={k} level="learner" />
            </li>
          ))}
        </ul>
      </section>
      <PrevNext route="glossary" />
    </article>
  );
}
