// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/GateLogbook.jsx — `/logbook[/<tab>]`: the Logbook of src/logbook/LogbookPage.jsx when it is built, else the Logbook's
// entry of pages.json with the generic page.
import { LogbookPage } from '../app/optional.js';
import ErrorBoundary from '../components/ErrorBoundary.jsx';
import Page from './Page.jsx';

export default function GateLogbook({ tab }) {
  if (!LogbookPage) return <Page route="logbook" />;
  return (
    <ErrorBoundary name="the Logbook" resetKey={tab || ''} fallback={<Page route="logbook" />}>
      <LogbookPage tab={tab || 'register'} />
    </ErrorBoundary>
  );
}
