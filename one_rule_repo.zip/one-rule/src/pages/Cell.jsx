// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Cell.jsx — `/cells/p,q[,r]`: one cell. The hero is its card's line; then every row whose `cells` include the signature,
// grouped by stage (physics) or by field (mathematics), each with a link to the page it lives on. n, the clock and the mirror are
// computed by the kernel.
import { useMemo } from 'react';
import { useSettings, textFor, statusOf } from '../app/content.js';
import { rowsById, rowsByCell } from '../app/store.js';
import { cellCards, cellKeyOf, sortEntries, visibleIn } from '../app/queries.js';
import { STAGE_ORDER, STAGE_NAMES, FIELD_ORDER, FIELD_NAMES, DRAWER_TABS } from '../app/vocab.js';
import { parseSignature, clockOf, cellName } from '../app/cellmath.js';
import PageView from './PageView.jsx';
import Statement from '../components/Statement.jsx';
import Link from '../components/Link.jsx';

function cellModel(key, s) {
  const sig = parseSignature(key);
  const cellStr = cellKeyOf(key);
  const learner = s.level === 'learner';
  const ids = (rowsByCell() && rowsByCell().get(cellStr)) || [];
  const rows = ids.map(id => rowsById().get(id)).filter(r => r && visibleIn(r, s.mode));
  const routeKey = sig ? `cells/${sig[0]},${sig[1]}${sig[2] ? ',' + sig[2] : ''}` : `cells/${key}`;
  const card = cellCards(s).find(c => c.route === routeKey && ids.includes(c.primary));
  const hero = card && textFor(card.primary, s) != null ? { id: card.primary, register: 'full', figure: null } : null;
  const entries = sortEntries(rows.filter(r => !hero || r.id !== hero.id).map((row, i) => ({ row, so: { order: i } })), s);
  const groupKey = s.mode === 'math' ? r => (r.fields && r.fields[0]) || 'other' : r => r.stage || 'M';
  const order = s.mode === 'math' ? [...FIELD_ORDER, 'other'] : STAGE_ORDER;
  const names = s.mode === 'math' ? { ...FIELD_NAMES, other: 'Other' } : STAGE_NAMES;
  const sections = [], open = [], openRows = [];
  const rowSection = new Map();
  if (hero) rowSection.set(hero.id, '__hero');
  let results = 0;
  for (const k of order) {
    const here = entries.filter(e => groupKey(e.row) === k);
    if (!here.length) continue;
    const body = [], openHere = [];
    for (const e of here) {
      if (textFor(e.row.id, s) == null) continue;
      const st = statusOf(e.row.id);
      if (st && st.status === 'open') openHere.push(e.row.id); else body.push(e.row.id);
    }
    const id = `${s.mode === 'math' ? 'field' : 'stage'}-${k}`;
    body.forEach(r => rowSection.set(r, id));
    sections.push({ id, label: names[k] || k, connective: null, body, details: [], numbers: [], drawerRows: body, figures: [], all: body, tabs: DRAWER_TABS, show: body.length > 0 });
    results += body.length;
    if (openHere.length) { open.push({ id, label: names[k] || k, rows: openHere }); openHere.forEach(r => { openRows.push(r); rowSection.set(r, '__open'); }); }
  }
  return { route: 'cells', sig, cellStr, hero, sections, open, openRows, rowSection, results, learnerShort: learner && results < 3, empty: !ids.length };
}

function CellFacts({ sig }) {
  if (!sig) return null;
  const [p, q, r] = sig;
  const c = clockOf(p, q, r);
  const mirror = [q, p, r];
  return (
    <ul className="facts" aria-label="Computed from the signature">
      <li className="fact"><span className="fact__k">n</span><span className="fact__v">{p + q + r}</span></li>
      {c != null ? <li className="fact"><span className="fact__k">clock</span><span className="swatch" style={{ background: `var(--c${c})` }} aria-hidden="true" /><span className="fact__v">c = {c}</span></li> : null}
      {p !== q ? <li className="fact"><span className="fact__k">mirror</span><Link to={`cells/${q},${p}${r ? ',' + r : ''}`} className="fact__v">{cellName(mirror)}</Link></li> : <li className="fact"><span className="fact__k">mirror</span><span className="fact__v">itself</span></li>}
    </ul>
  );
}

export default function Cell({ cellKey }) {
  const s = useSettings();
  const model = useMemo(() => cellModel(cellKey, s), [cellKey, s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  const heading = { eyebrow: 'Cell', title: model.sig ? cellName(model.sig) : model.cellStr, deck: null };
  const custom = {};
  for (const sec of model.sections) custom[sec.id] = x => x.body.map(id => <Statement key={id} id={id} where />);
  return (
    <PageView
      model={model}
      heading={heading}
      needs={['cells']}
      headerExtra={<CellFacts sig={model.sig} />}
      custom={custom}
      afterSections={model.empty ? <p className="empty">No row of the Atlas names this cell. <Link to="cells">All cells</Link></p> : null}
      prevNext={null}
    />
  );
}
