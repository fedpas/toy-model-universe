// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Lenses.jsx — `/lenses`: the pages.json entry of the lenses, then one card per lens of lenses.json grouped by kind
// (its description, the size of its dictionary, the figures that redraw in it, the rows read in it: the rows with a reading in
// content/lens_readings.json or a text written in the lens).
import { useSettings, useTable } from '../app/content.js';
import { peekTable, lensTextIndex, lensReadingsIndex } from '../app/store.js';
import { LENS_KIND_ORDER, LENS_KIND_NAMES } from '../app/vocab.js';
import Page from './Page.jsx';
import Link from '../components/Link.jsx';

const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;

/** the rows read in a lens: a reading of lens_readings.json or a text written in the lens; null while lens_readings.json loads */
export function lensRows(key) {
  const idx = lensReadingsIndex();
  if (!idx) return null;
  const rows = new Set(idx.get(key) ? idx.get(key).keys() : []);
  const byLevel = lensTextIndex()?.get(key);
  if (byLevel) for (const set of byLevel.values()) for (const r of set) rows.add(r);
  return rows;
}

export function lensFacts(l) {
  const figs = (peekTable('figures') || []).filter(f => (f.lenses || []).includes(l.key)).length;
  const rows = lensRows(l.key);
  return { dict: (l.dictionary || []).length, figs, readings: rows ? rows.size : null };
}

function LensIndex() {
  const s = useSettings();
  useTable('lens_readings'); // the counts of rows read; the cards show them once the table is in
  const lenses = peekTable('lenses') || [];
  const kinds = [...LENS_KIND_ORDER, ...[...new Set(lenses.map(l => l.kind))].filter(k => !LENS_KIND_ORDER.includes(k))];
  return (
    <section className="sec sec--lenses" id="sec-lens-index" aria-labelledby="h-lens-index" data-outline="Every lens">
      <h2 className="sec__title" id="h-lens-index">Every lens</h2>
      {kinds.map(kind => {
        const items = lenses.filter(l => l.kind === kind);
        if (!items.length) return null;
        return (
          <div className="lens-group-block" key={kind}>
            <h3 className="step-group__title">{LENS_KIND_NAMES[kind] || kind}</h3>
            <ul className="lens-cards">
              {items.map(l => {
                const f = lensFacts(l);
                return (
                  <li key={l.key}>
                    <Link to={`lenses/${l.key}`} className={`lens-card${s.lens === l.key ? ' is-active' : ''}`}>
                      <span className="lens-card__name">{l.name}</span>
                      {l.describes ? <span className="lens-card__desc">{l.describes}</span> : null}
                      <span className="lens-card__facts">
                        <span>{f.dict ? plural(f.dict, 'dictionary entry', 'dictionary entries') : 'no dictionary yet'}</span>
                        {f.figs ? <span>{plural(f.figs, 'figure')}</span> : null}
                        {f.readings == null ? null : <span>{f.readings ? plural(f.readings, 'row read', 'rows read') : 'no readings yet'}</span>}
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}
    </section>
  );
}

export default function Lenses() {
  return <Page route="lenses" afterSections={<LensIndex />} />;
}
