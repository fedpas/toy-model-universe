// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/PageView.jsx — the frame every page shares (06): header → hero → sections → open fold → previous/next.
// It renders a page model (src/app/queries.js); the drawers and the open fold are opened from the statements' "›".
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSettings } from '../app/content.js';
import { useRoute } from '../app/router.js';
import { glossaryFor } from '../app/glossary.js';
import { rowsById } from '../app/store.js';
import { PageContext } from '../components/PageContext.js';
import PageHeader from '../components/PageHeader.jsx';
import Hero from '../components/Hero.jsx';
import Section from '../components/Section.jsx';
import OpenFold from '../components/OpenFold.jsx';
import PrevNext from '../components/PrevNext.jsx';
import Drawer from '../components/Drawer.jsx';

export function LearnerNotice() {
  const s = useSettings();
  return (
    <div className="notice" role="note">
      <p className="notice__text">This page has no plain-words version yet.</p>
      <button type="button" className="btn" onClick={() => s.set({ level: 'research' })}>Show the research version</button>
    </div>
  );
}

export default function PageView({ model, heading, needs, headerExtra, heroAside, afterHero, afterSections, custom, drawers = true, prevNext, learnerNotice = true }) {
  const s = useSettings();
  const route = useRoute();
  const [openSet, setOpenSet] = useState(() => new Set());
  const [focus, setFocus] = useState({ sid: null, row: null, nonce: 0 });
  const [foldOpen, setFoldOpen] = useState(false);

  const shown = model.sections.filter(sec => sec.show);
  const order = useMemo(
    () => [model.hero && model.hero.id, ...shown.flatMap(sec => (custom && custom[sec.id] ? [] : sec.body)), ...model.openRows].filter(Boolean),
    [model], // eslint-disable-line react-hooks/exhaustive-deps
  );
  const gloss = useMemo(() => glossaryFor(order, s), [order, s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps

  const setDrawerOpen = useCallback((sid, open) => {
    setOpenSet(prev => { const n = new Set(prev); if (open) n.add(sid); else n.delete(sid); return n; });
  }, []);
  const openEvidence = useCallback(rowId => {
    const sid = model.rowSection.get(rowId);
    if (!sid) return;
    if (sid === '__open') setFoldOpen(true);
    setOpenSet(prev => new Set(prev).add(sid));
    setFocus(f => ({ sid, row: rowId, nonce: f.nonce + 1 }));
  }, [model]);
  // at learner level a drawer ("How do we know?") exists only where a script checks the row
  const learnerLevel = s.level === 'learner';
  const hasDrawer = useCallback(rowId => {
    if (!drawers || !model.rowSection.has(rowId)) return false;
    if (!learnerLevel) return true;
    const r = rowsById() && rowsById().get(rowId);
    return !!(r && (r.evidence || []).length);
  }, [model, drawers, learnerLevel]);
  const ctx = useMemo(() => ({ openEvidence: drawers ? openEvidence : null, hasDrawer, gloss }), [openEvidence, hasDrawer, gloss, drawers]);

  // a deep link with at=<row|section> brings that place into view (opening the fold or the drawer that holds it)
  useEffect(() => {
    const at = route.at;
    if (!at || typeof document === 'undefined') return undefined;
    const sid = model.rowSection.get(at);
    const inBody = shown.some(sec => sec.body.includes(at)) || (model.hero && model.hero.id === at);
    if (sid === '__open') setFoldOpen(true);
    else if (sid && !inBody && drawers) openEvidence(at);
    const t = setTimeout(() => {
      const el = document.getElementById(`row-${at}`) || document.getElementById(`sec-${at}`);
      if (el) el.scrollIntoView({ block: 'start' });
    }, 30);
    return () => clearTimeout(t);
  }, [route.at, model]); // eslint-disable-line react-hooks/exhaustive-deps

  const drawerFor = sid => ({ open: openSet.has(sid), focus: focus.sid === sid ? focus : null });

  return (
    <PageContext.Provider value={ctx}>
      <article className="page" data-route={model.route}>
        <PageHeader route={model.route} heading={heading} needs={needs}>{headerExtra}</PageHeader>
        {model.learnerShort && learnerNotice ? <LearnerNotice /> : null}
        <Hero hero={model.hero} aside={heroAside} />
        {!model.hero && heroAside ? <div className="hero-aside">{heroAside}</div> : null}
        {drawers && model.hero ? (
          <div className="hero__drawer">
            <Drawer sid="__hero" rows={[model.hero.id]} open={openSet.has('__hero')} focus={focus.sid === '__hero' ? focus : null} onToggle={o => setDrawerOpen('__hero', o)} />
          </div>
        ) : null}
        {afterHero}
        {shown.map(sec => (
          <Section key={sec.id} sec={sec} drawers={drawers} drawer={drawerFor(sec.id)} onDrawer={setDrawerOpen} custom={custom && custom[sec.id]} />
        ))}
        {afterSections}
        <OpenFold groups={model.open} open={foldOpen} onToggle={setFoldOpen} drawers={drawers} drawer={drawerFor('__open')} onDrawer={setDrawerOpen} />
        {prevNext !== null ? <PrevNext route={prevNext || model.route} /> : null}
      </article>
    </PageContext.Provider>
  );
}
