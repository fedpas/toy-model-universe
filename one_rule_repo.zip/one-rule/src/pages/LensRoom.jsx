// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/LensRoom.jsx — `/lenses/<key>`: one lens of lenses.json: what it describes, its conventions, its dictionary
// (atlas element → the lens's term, match, evidence), the figures that redraw in it, the pages where rows have a reading in it
// and the rows read in it (content/lens_readings.json: readings attached by a shared check or by the atlas phrase).
import { useState } from 'react';
import { useSettings, useTable } from '../app/content.js';
import { lensesByKey, lensReadingsIndex, rowsById, peekTable } from '../app/store.js';
import { LENS_KIND_NAMES } from '../app/vocab.js';
import { pageLabel, rowHome } from '../app/queries.js';
import PageHeader from '../components/PageHeader.jsx';
import RichText from '../components/RichText.jsx';
import Link from '../components/Link.jsx';
import { orderReadings, matchWord } from '../components/LensReading.jsx';
import NotFound from './NotFound.jsx';
import { lensFacts, lensRows } from './Lenses.jsx';

const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;

/** route → number of the given rows shown on it, in the order of pages.json */
function readingPages(rows) {
  const pages = new Map();
  for (const id of rows) for (const page of new Set((rowsById()?.get(id)?.shownOn || []).map(so => so.page))) pages.set(page, (pages.get(page) || 0) + 1);
  const order = new Map((peekTable('pages') || []).map((p, i) => [p.route, i]));
  return [...pages.entries()].sort((a, b) => (order.get(a[0]) ?? 1e9) - (order.get(b[0]) ?? 1e9) || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
}

/** the rows in the order a reader meets them: by the page of their first place (pages.json order), then by their order there */
function inReadingOrder(ids) {
  const order = new Map((peekTable('pages') || []).map((p, i) => [p.route, i]));
  const key = id => {
    const so = [...(rowsById()?.get(id)?.shownOn || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0];
    return so ? [order.get(so.page) ?? 1e9, so.order ?? 0] : [2e9, 0];
  };
  return ids.map(id => [id, key(id)]).sort((a, b) => a[1][0] - b[1][0] || a[1][1] - b[1][1] || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)).map(x => x[0]);
}

export default function LensRoom({ lensKey }) {
  const s = useSettings();
  useTable('lens_readings'); // the rows read in this lens; the sections below fill in once the table is in
  // the dictionary and the rows read are data: folded by default (first SHOW entries), opened or searched on request
  // (01_VISION: results first, data behind a click)
  const SHOW = 12;
  const [allDict, setAllDict] = useState(false);
  const [q, setQ] = useState('');
  const [allRows, setAllRows] = useState(false);
  const lens = lensesByKey()?.get(lensKey);
  if (!lens) return <NotFound />;
  const learner = s.level === 'learner';
  const facts = lensFacts(lens);
  const read = lensRows(lens.key);
  const pages = read ? readingPages(read) : [];
  const byRow = lensReadingsIndex()?.get(lens.key) || null;
  const readRows = byRow ? inReadingOrder([...byRow.keys()]) : [];
  const figs = (peekTable('figures') || []).filter(f => (f.lenses || []).includes(lens.key));
  const conv = lens.conventions && typeof lens.conventions === 'object' ? Object.entries(lens.conventions) : [];
  const active = s.lens === lens.key;
  const dict = lens.dictionary || [];
  const qn = q.trim().toLowerCase();
  const hits = qn ? dict.filter(d => [d.atlas, d.term, d.match, ...(d.evidence || [])].some(x => String(x || '').toLowerCase().includes(qn))) : dict;
  const shown = allDict || qn ? hits : hits.slice(0, SHOW);
  const rowsShown = allRows ? readRows : readRows.slice(0, SHOW);
  const heading = { eyebrow: `Lens · ${LENS_KIND_NAMES[lens.kind] || lens.kind}`, title: lens.name, deck: null };
  return (
    <article className="page page--lens" data-route={`lenses/${lens.key}`}>
      <PageHeader route="lenses" heading={heading} needs={['lenses']}>
        {lens.describes ? <p className="ph__lede">{lens.describes}</p> : null}
        {read ? (
          <p className="facts lens-facts">
            <span className="fact"><span className="fact__v">{read.size}</span>{' '}<span className="fact__k">{read.size === 1 ? 'row read in this lens' : 'rows read in this lens'}</span></span>{' '}
            {pages.length ? <span className="fact"><span className="fact__v">{pages.length}</span>{' '}<span className="fact__k">{pages.length === 1 ? 'page' : 'pages'}</span></span> : null}
          </p>
        ) : null}
        <p className="ph__actions">
          <button type="button" className={`btn${active ? ' btn--on' : ''}`} aria-pressed={active} onClick={() => s.set({ lens: active ? null : lens.key })}>
            {active ? 'Stop reading through this lens' : 'Read the Atlas through this lens'}
          </button>
        </p>
      </PageHeader>

      {conv.length ? (
        <section className="sec" id="sec-conventions" aria-labelledby="h-conventions" data-outline="Conventions">
          <h2 className="sec__title" id="h-conventions">Conventions</h2>
          <dl className="kv">{conv.map(([k, v]) => <div className="kv__row" key={k}><dt>{k}</dt><dd><code>{String(v)}</code></dd></div>)}</dl>
        </section>
      ) : null}

      <section className="sec" id="sec-dictionary" aria-labelledby="h-dictionary" data-outline="Dictionary">
        <h2 className="sec__title" id="h-dictionary">Dictionary</h2>
        {!facts.dict ? <p className="empty">This lens has no dictionary yet.</p> : learner ? (
          <div className="notice" role="note">
            <p className="notice__text">The dictionary uses formulas; it is shown at research level.</p>
            <button type="button" className="btn" onClick={() => s.set({ level: 'research' })}>Show the research version</button>
          </div>
        ) : (
          <>
          <p className="dict__tools">
            <label className="dict__search"><span className="vh">Search the dictionary</span><input type="search" value={q} onChange={e => setQ(e.target.value)} placeholder={`Search ${dict.length} entries`} /></label>
            <span className="dict__count">{qn ? `${hits.length} of ${dict.length} entries match` : allDict ? `${dict.length} entries` : `${Math.min(SHOW, dict.length)} of ${dict.length} entries`}</span>
          </p>
          <div className="table-scroll" tabIndex={0} role="region" aria-label={`${lens.name} dictionary`}>
            <table className="dict">
              <thead><tr><th scope="col">In the Atlas</th><th scope="col">In this lens</th><th scope="col">Match</th><th scope="col">Evidence</th></tr></thead>
              <tbody>
                {shown.map((d, i) => (
                  <tr key={i}>
                    <td><RichText text={String(d.atlas || '')} level={s.level} /></td>
                    <td><RichText text={String(d.term || '')} level={s.level} /></td>
                    <td className="dict__match"><RichText text={String(d.match || '')} level={s.level} /></td>
                    <td className="dict__ev">{(d.evidence || []).map(e => <code key={e}>{e}</code>)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!qn && dict.length > SHOW ? (
            <p className="dict__more"><button type="button" className="btn" aria-expanded={allDict} onClick={() => setAllDict(v => !v)}>{allDict ? `Show the first ${SHOW}` : `Show all ${dict.length} entries`}</button></p>
          ) : null}
          </>
        )}
      </section>

      <section className="sec" id="sec-figures" aria-labelledby="h-figures" data-outline="Figures">
        <h2 className="sec__title" id="h-figures">Figures that redraw in this lens</h2>
        {figs.length ? <ul className="chips">{figs.map(f => <li key={f.id}><code className="chip chip--code">{f.id}</code></li>)}</ul> : <p className="empty">No figure redraws in this lens yet.</p>}
      </section>

      <section className="sec" id="sec-readings" aria-labelledby="h-readings" data-outline="Pages with readings">
        <h2 className="sec__title" id="h-readings">Pages with readings</h2>
        {pages.length ? (
          <ul className="chips">{pages.map(([p, n]) => <li key={p}><Link to={p} className="chip">{pageLabel(p, s)} <span className="chip__n">{n}</span></Link></li>)}</ul>
        ) : read ? <p className="empty">No row has a reading in this lens yet.</p> : null}
      </section>

      {readRows.length ? (
        <section className="sec" id="sec-rows-read" aria-labelledby="h-rows-read" data-outline="Rows read in this lens">
          <h2 className="sec__title" id="h-rows-read">Rows read in this lens</h2>
          {learner ? (
            <div className="notice" role="note">
              <p className="notice__text">The readings use formulas; they are shown at research level.</p>
              <button type="button" className="btn" onClick={() => s.set({ level: 'research' })}>Show the research version</button>
            </div>
          ) : (
            <>
            <p className="dict__tools"><span className="dict__count">{allRows ? plural(readRows.length, 'row') : `${rowsShown.length} of ${plural(readRows.length, 'row')}`}</span></p>
            <ul className="lens-rows">
              {rowsShown.map(id => {
                const list = orderReadings(byRow.get(id));
                const first = list[0];
                const w = matchWord(first.match);
                const home = rowHome(id);
                return (
                  <li className="lens-rows__item" key={id} data-row={id}>
                    <Link to={home.path} at={id} className="lens-rows__id">{id}</Link>
                    <span className="lens-rows__term">
                      <span className="lens-rows__text"><RichText text={first.term} level={s.level} /></span>
                      {w ? <span className="lens-rows__note">{w}</span> : null}
                      {list.length > 1 ? <span className="lens-rows__note">+{list.length - 1}</span> : null}
                    </span>
                  </li>
                );
              })}
            </ul>
            {readRows.length > SHOW ? (
              <p className="dict__more"><button type="button" className="btn" aria-expanded={allRows} onClick={() => setAllRows(v => !v)}>{allRows ? `Show the first ${SHOW}` : `Show all ${readRows.length} rows`}</button></p>
            ) : null}
            </>
          )}
        </section>
      ) : null}
    </article>
  );
}
