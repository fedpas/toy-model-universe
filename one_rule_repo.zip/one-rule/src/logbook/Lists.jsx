// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/Lists.jsx — the simpler Logbook tabs, each a list of one table: questions, sources, reports, analyses,
// candidates (content/candidates.json: filtered by field and by checkable; the rows a candidate links, each opening in the
// register and, as a Link, on the page where it is shown).
import { useDeferredValue, useEffect, useId, useMemo, useState } from 'react';
import { useTable, useSettings, textFor } from '../app/content.js';
import Badge from '../components/Badge.jsx';
import Link from '../components/Link.jsx';
import { Fold, Chip, Tag, Kv, RefLink, Loading, plural } from './ui.jsx';
import { candidateFacets, filterCandidates, rowHomeOf, pageLabel, excerpt, refKind, FIELD_ORDER, CHECKABLE_ORDER } from './registerModel.js';

const match = (q, ...vals) => !q || vals.some(v => String(v ?? '').toLowerCase().includes(q));

function useFocus(target, tab, prefix) {
  const [open, setOpen] = useState(() => new Set());
  useEffect(() => {
    if (!target || target.tab !== tab || !target.id) return;
    setOpen(o => new Set(o).add(target.id));
    requestAnimationFrame(() => { const el = document.getElementById(prefix + target.id); if (el) el.scrollIntoView({ block: 'start' }); });
  }, [target, tab, prefix]);
  const toggle = (id, o) => setOpen(s => { const n = new Set(s); o ? n.add(id) : n.delete(id); return n; });
  return [open, toggle];
}

function Toolbar({ value, onChange, options, query, setQuery, placeholder }) {
  const name = useId();
  return (
    <div className="lb-toolbar">
      <div className="lb-seg" role="radiogroup" aria-label="Show">
        {options.map(([v, l, n]) => <label key={v}><input type="radio" name={name} checked={value === v} onChange={() => onChange(v)} /> {l} <span className="lb-count">{n}</span></label>)}
      </div>
      <label className="lb-field lb-field-inline"><span className="lb-eyebrow">Search</span><input type="search" value={query} placeholder={placeholder} onChange={e => setQuery(e.target.value)} /></label>
    </div>
  );
}

export function Questions({ target }) {
  const [qs, err] = useTable('questions');
  const [show, setShow] = useState('all');
  const [query, setQuery] = useState('');
  const q = useDeferredValue(query.trim().toLowerCase());
  const [open, toggle] = useFocus(target, 'questions', 'lb-q-');
  useEffect(() => { if (target && target.tab === 'questions') { setShow('all'); setQuery(''); } }, [target]);
  if (!qs) return <Loading what="the questions" error={err} />;
  const n = qs.filter(x => x.answered).length;
  const list = qs.filter(x => (show === 'all' || (show === 'answered') === !!x.answered) && match(q, x.id, x.topic, x.ask, x.answer, x.whom, x.checked, x.notChecked));
  return (
    <div className="lb-stack-lg">
      <Toolbar value={show} onChange={setShow} options={[['all', 'all', qs.length], ['answered', 'answered', n], ['not', 'not answered', qs.length - n]]} query={query} setQuery={setQuery} placeholder="topic, words of the question or answer…" />
      {list.map(x => (
        <Fold key={x.id} id={'lb-q-' + x.id} className="lb-card" open={open.has(x.id)} onToggle={o => toggle(x.id, o)}
          summary={<span className="lb-sum"><span className="lb-mono lb-strong">{x.id}</span><Chip dash={!x.answered}>{x.answered ? 'answered' : 'not answered'}</Chip><span className="lb-sum-title">{x.topic}</span></span>}>
          <Kv items={[
            ['question', <p className="lb-prose">{x.ask}</p>],
            ['ask', x.whom],
            ['checked', x.checked],
            ['not checked', x.notChecked],
            ['answer', x.answered && x.answer ? <div><p className="lb-prose">{x.answer}</p>{(x.answerTags || []).length ? <p className="lb-inline">{x.answerTags.map(t => <Tag key={t}>{t}</Tag>)}</p> : null}</div> : null],
          ]} />
        </Fold>
      ))}
      {!list.length ? <p className="lb-note">No question matches.</p> : null}
    </div>
  );
}

export function Sources({ target }) {
  const [src, err] = useTable('sources');
  const [show, setShow] = useState('all');
  const [query, setQuery] = useState('');
  const q = useDeferredValue(query.trim().toLowerCase());
  const [open, toggle] = useFocus(target, 'sources', 'lb-s-');
  if (!src) return <Loading what="the sources" error={err} />;
  const n = src.filter(x => x.read).length;
  const list = src.filter(x => (show === 'all' || (show === 'read') === !!x.read) && match(q, x.id, x.source, x.itSays, x.weComputed, x.verdict, x.atlasTerms));
  return (
    <div className="lb-stack-lg">
      <Toolbar value={show} onChange={setShow} options={[['all', 'all', src.length], ['read', 'read', n], ['unread', 'unread', src.length - n]]} query={query} setQuery={setQuery} placeholder="author, title, words of the verdict…" />
      {list.map(x => (
        <Fold key={x.id} id={'lb-s-' + x.id} className="lb-card" open={open.has(x.id)} onToggle={o => toggle(x.id, o)}
          summary={<span className="lb-sum"><span className="lb-mono lb-strong">{x.id}</span><Chip dash={!x.read}>{x.read ? 'read' : 'unread'}</Chip>{x.deadEnd ? <Chip dash>dead end</Chip> : null}<span className="lb-sum-title">{x.source}</span></span>}>
          <Kv items={[
            ['it says', x.itSays],
            ['we computed', x.weComputed],
            ['verdict', x.verdict],
            ['atlas terms', x.atlasTerms],
            ['tags', (x.tags || []).length ? <span className="lb-inline">{x.tags.map(t => <Tag key={t}>{t}</Tag>)}</span> : null],
          ]} />
        </Fold>
      ))}
      {!list.length ? <p className="lb-note">No source matches.</p> : null}
    </div>
  );
}

const rel = f => (f ? './' + String(f).replace(/^\.?\//, '') : null);

export function Reports() {
  const [reps, err] = useTable('reports');
  if (!reps) return <Loading what="the reports" error={err} />;
  return (
    <div className="lb-stack-lg">
      <p className="lb-muted">{plural(reps.length, 'report')}</p>
      <ul className="lb-plain lb-stack">
        {reps.map(r => (
          <li key={r.id} className="lb-card lb-pad">
            <h3 className="lb-h3">{r.file ? <a href={rel(r.file)} target="_blank" rel="noopener">{r.title}</a> : r.title}</h3>
            <p className="lb-prose">{r.line}</p>
            <Kv items={[
              ['scripts', (r.script || []).length ? <span className="lb-inline">{r.script.map(([s, n]) => <Tag key={s}>{s} · {n}</Tag>)}</span> : null],
              ['test suite', r.suite ? <span className="lb-mono">{r.suite}</span> : null],
              ['linked from', (r.on || []).length ? r.on.join(', ') : null],
              ['file', r.file ? <span className="lb-mono lb-small">{r.file}</span> : null],
            ]} />
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Analyses() {
  const [an, err] = useTable('analyses');
  if (!an) return <Loading what="the analyses" error={err} />;
  return (
    <div className="lb-stack-lg">
      <p className="lb-muted">{plural(an.length, 'analysis', 'analyses')}</p>
      <ul className="lb-plain lb-stack">
        {an.map(a => (
          <li key={a.id} className="lb-card lb-pad">
            <h3 className="lb-h3">{a.html ? <a href={rel(a.html)} target="_blank" rel="noopener">{a.title}</a> : a.title} <span className="lb-muted lb-small">{a.kind}</span></h3>
            <p className="lb-prose">{a.line}</p>
            <Kv items={[
              ['sources', (a.sources || []).length ? <span className="lb-stack">{a.sources.map(s => <span key={s} className="lb-mono lb-small">{s}</span>)}</span> : null],
              ['code', a.code ? <span className="lb-mono lb-small">{a.code}</span> : null],
              ['checks', (a.checks || []).length ? <Fold summary={plural(a.checks.length, 'check id')}><span className="lb-inline">{a.checks.map(c => <Tag key={c}>{c}</Tag>)}</span></Fold> : null],
            ]} />
          </li>
        ))}
      </ul>
    </div>
  );
}

const FIELD_RANK = ['physics', ...FIELD_ORDER];
const fieldRank = f => { const i = FIELD_RANK.indexOf(f); return i < 0 ? FIELD_RANK.length : i; };
const byFieldOrder = (a, b) => fieldRank(a) - fieldRank(b) || String(a).localeCompare(String(b));

/** one radio group of the candidates' filters: "all" and each value with its count over all candidates */
function Facet({ label, value, onChange, values, counts, total }) {
  const name = useId();
  return (
    <div className="lb-seg" role="radiogroup" aria-label={label}>
      <span className="lb-eyebrow">{label}</span>
      {[['all', 'all', total], ...values.map(v => [v, v, counts[v] || 0])].map(([v, l, n]) => (
        <label key={v}><input type="radio" name={name} checked={value === v} onChange={() => onChange(v)} /> {l} <span className="lb-count">{n}</span></label>
      ))}
    </div>
  );
}

/** the rows a candidate links: the id opens the row in the register; where it is shown is a Link to that page, at that row */
function LinkedRows({ ids, nav, rowsById, status, settings }) {
  if (!ids || !ids.length) return <span className="lb-muted">none</span>;
  return (
    <div className="lb-scroll">
      <table className="lb-table lb-linked">
        <thead><tr><th scope="col">row</th><th scope="col">status</th><th scope="col">shown on</th><th scope="col">research text</th></tr></thead>
        <tbody>
          {ids.map(id => {
            const r = rowsById ? rowsById.get(id) : null;
            const kind = refKind(id);
            if (!r) {
              return (
                <tr key={id} data-row={id}>
                  <td><RefLink id={id} nav={nav} /></td><td colSpan={3} className="lb-muted">{kind === 'theorem' ? 'a theorem: it opens in Theorems' : rowsById ? 'not a row of rows.json' : 'loading the rows…'}</td>
                </tr>
              );
            }
            const st = status ? status[id] : null;
            const home = rowHomeOf(r);
            const text = textFor(id, { mode: settings.mode, level: 'research', lens: settings.lens });
            return (
              <tr key={id} data-row={id}>
                <td><RefLink id={id} nav={nav} /></td>
                <td>{st ? (st.badge ? <Badge status={st.status} badge={st.badge} level="research" /> : <span className="lb-mono lb-small">{st.status}</span>) : null}</td>
                <td>{home ? <Link to={home.page} at={id} className="lb-pagelink">{pageLabel(home.page)}{home.section ? ` › ${home.section}` : ''}</Link> : <span className="lb-muted">not on a page</span>}</td>
                <td className="lb-excerpt lb-small" data-snippet="">{text ? excerpt(text, 110) : <span className="lb-muted">no research text</span>}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function Candidates({ nav, target }) {
  const [cands, err] = useTable('candidates');
  const [rows] = useTable('rows');
  const [status] = useTable('derived_status');
  const settings = useSettings();
  const [open, toggle] = useFocus(target, 'candidates', 'lb-c-');
  const [query, setQuery] = useState('');
  const [field, setField] = useState('all');
  const [checkable, setCheckable] = useState('all');
  const q = useDeferredValue(query.trim());
  // a candidate asked for from elsewhere (the search, a link): every filter off, so that it is shown
  useEffect(() => { if (target && target.tab === 'candidates' && target.id) { setField('all'); setCheckable('all'); setQuery(''); } }, [target]);
  const rowsById = useMemo(() => (rows ? new Map(rows.map(r => [r.id, r])) : null), [rows]);
  const facets = useMemo(() => candidateFacets(cands), [cands]);
  const shown = useMemo(() => filterCandidates(cands, { field, checkable, q }), [cands, field, checkable, q]);
  const byField = useMemo(() => {
    const m = new Map();
    for (const c of shown) { const f = c.field || '—'; if (!m.has(f)) m.set(f, []); m.get(f).push(c); }
    return [...m].sort((a, b) => byFieldOrder(a[0], b[0]));
  }, [shown]);
  if (!cands && !err) return <Loading what="the candidates" />;
  if (err || !Array.isArray(cands) || !cands.length) return <p className="lb-note">No candidates yet.</p>;
  const fields = Object.keys(facets.field).sort(byFieldOrder);
  const checkables = CHECKABLE_ORDER.filter(k => facets.checkable[k]).concat(Object.keys(facets.checkable).filter(k => !CHECKABLE_ORDER.includes(k)));
  const filtered = field !== 'all' || checkable !== 'all' || !!q;
  return (
    <div className="lb-stack-lg">
      <div className="lb-toolbar">
        <span className="lb-muted" role="status" aria-live="polite">{filtered ? `${shown.length} of ${plural(cands.length, 'candidate')}` : `${plural(cands.length, 'candidate')} in ${plural(fields.length, 'field')}`}</span>
        <label className="lb-field lb-field-inline"><span className="lb-eyebrow">Search</span><input type="search" value={query} placeholder="title, statement, row id…" onChange={e => setQuery(e.target.value)} /></label>
        {filtered ? <button type="button" className="lb-btn" onClick={() => { setField('all'); setCheckable('all'); setQuery(''); }}>Reset filters</button> : null}
      </div>
      <div className="lb-stack lb-cand-filters">
        <Facet label="Field" value={field} onChange={setField} values={fields} counts={facets.field} total={facets.total} />
        <Facet label="Checkable" value={checkable} onChange={setCheckable} values={checkables} counts={facets.checkable} total={facets.total} />
      </div>
      {byField.map(([f, list]) => (
        <section key={f} className="lb-stack">
          <h3 className="lb-h3">{f} <span className="lb-muted">({list.length})</span></h3>
          {list.map(c => (
            <Fold key={c.id} id={'lb-c-' + c.id} className="lb-card" open={open.has(c.id)} onToggle={o => toggle(c.id, o)}
              summary={<span className="lb-sum"><span className="lb-mono lb-strong">{c.id}</span>{c.checkable ? <Chip dash={c.checkable !== 'yes'}>checkable: {c.checkable}</Chip> : null}<span className="lb-sum-title">{c.title}</span><span className="lb-muted lb-small">{plural((c.linksRows || []).length, 'linked row')}</span></span>}>
              <Kv items={[
                ['statement', c.statement ? <p className="lb-prose">{c.statement}</p> : null],
                ['linked rows', <LinkedRows ids={c.linksRows || []} nav={nav} rowsById={rowsById} status={status} settings={settings} />],
                ['check note', c.checkNote],
                ['source', c.source],
                ['proposed by', (c.proposedBy || []).join(', ')],
                ['notions', (c.notions || []).length ? <span className="lb-inline">{c.notions.map(n => <Tag key={n}>{n}</Tag>)}</span> : null],
              ]} />
            </Fold>
          ))}
        </section>
      ))}
      {!byField.length ? <p className="lb-note">No candidate matches.</p> : null}
    </div>
  );
}
