// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/Method.jsx — the ground rules of the build book and the statuses with their badges, copied verbatim from the docs
// into methodText.js (generated); and the state of this content, computed from the tables: the content version (version.json,
// written by the build), the texts by status per level and lens (texts.json), the readings per lens (lens_readings.json) and
// the counts the migration recorded (MIGRATION_COUNTS.json). No number is typed here.
import { useMemo } from 'react';
import { useTable } from '../app/content.js';
import Badge from '../components/Badge.jsx';
import { Md, Fold, TextMark, num, plural } from './ui.jsx';
import { rules, statusIntro, statuses, priority, badgeWords, learnerWords, textStatuses, draftRule, SOURCES } from './methodText.js';
import { textStatusCounts, lensReadingCounts } from './registerModel.js';

const sample = kind => (kind === 'new' ? { status: 'proved-by-atlas', badge: 'new' } : kind === 'input' ? { status: 'input', badge: 'needs an input' } : { status: kind, badge: (badgeWords.find(b => b[0] === kind) || [])[2] });
const fmt = v => (typeof v === 'number' ? num(v) : Array.isArray(v) ? (v.length ? v.join(', ') : '—') : v && typeof v === 'object' ? Object.entries(v).map(([k, x]) => `${k} ${fmt(x)}`).join(' · ') : String(v ?? '—'));

function VersionLine() {
  const [ver, err] = useTable('version');
  if (!ver) return <p className="lb-small lb-muted" data-version="unknown">{err ? 'Content version: not available' : 'Loading the content version…'}</p>;
  return (
    <p className="lb-small lb-version" data-version={ver.contentVersion || ''}>
      <span className="lb-muted">Content version</span> <span className="lb-mono lb-strong">{ver.contentVersion || 'unknown'}</span>
      {ver.appVersion ? <> <span className="lb-muted">· app</span> <span className="lb-mono lb-strong">{ver.appVersion}</span></> : null}
      {Array.isArray(ver.tables) ? <span className="lb-muted"> · {plural(ver.tables.length, 'content table')}</span> : null}
    </p>
  );
}

function TextCounts() {
  const [texts, err] = useTable('texts');
  const c = useMemo(() => (texts ? textStatusCounts(texts) : null), [texts]);
  if (!c) return <p className="lb-muted">{err ? `texts.json: not available (${String(err.message || err)})` : 'Loading the texts…'}</p>;
  const lensName = l => (l ? l : '—');
  return (
    <>
      <div className="lb-scroll">
        <table className="lb-table lb-counts" aria-label="Texts by status, per level and lens">
          <thead><tr><th scope="col">level</th><th scope="col">lens</th>{c.statuses.map(s => <th key={s} scope="col" className="lb-numcol">{s}</th>)}<th scope="col" className="lb-numcol">all</th></tr></thead>
          <tbody>
            {c.rows.map(g => (
              <tr key={`${g.level}|${g.lens || ''}`} data-level={g.level} data-lens={g.lens || ''}>
                <th scope="row">{g.level || '—'}</th><td className="lb-mono">{lensName(g.lens)}</td>
                {c.statuses.map(s => <td key={s} className="lb-numcol" data-status={s}>{num(g.counts[s] || 0)}</td>)}
                <td className="lb-numcol lb-strong">{num(g.total)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot><tr><th scope="row" colSpan={2}>all texts</th>{c.statuses.map(s => <td key={s} className="lb-numcol">{num(c.total.counts[s] || 0)}</td>)}<td className="lb-numcol lb-strong">{num(c.total.total)}</td></tr></tfoot>
        </table>
      </div>
      <p className="lb-small lb-muted">— in the lens column: no lens chosen. A lens gets a line once it has texts of its own.</p>
    </>
  );
}

function ReadingCounts() {
  const [records, err] = useTable('lens_readings');
  const [lenses] = useTable('lenses');
  const list = useMemo(() => (records && lenses ? lensReadingCounts(records, lenses) : null), [records, lenses]);
  const rowsAll = useMemo(() => (Array.isArray(records) ? new Set(records.map(r => r && r.row).filter(Boolean)).size : 0), [records]);
  if (!list) return <p className="lb-muted">{err ? `lens_readings.json: not available (${String(err.message || err)})` : 'Loading the lens readings…'}</p>;
  const withSome = list.filter(l => l.records > 0), none = list.filter(l => !l.records);
  const total = list.reduce((a, l) => a + l.records, 0);
  return (
    <>
      <div className="lb-scroll">
        <table className="lb-table lb-counts" aria-label="Lens readings per lens">
          <thead><tr><th scope="col">lens</th><th scope="col">kind</th><th scope="col" className="lb-numcol">readings</th><th scope="col" className="lb-numcol">rows</th></tr></thead>
          <tbody>
            {withSome.map(l => (
              <tr key={l.key} data-lens={l.key}>
                <th scope="row">{l.name} <span className="lb-mono lb-muted lb-small">{l.key}</span>{l.registered ? null : <span className="lb-muted lb-small"> (not in lenses.json)</span>}</th>
                <td>{l.kind || '—'}</td><td className="lb-numcol" data-readings={l.records}>{num(l.records)}</td><td className="lb-numcol">{num(l.rows)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot><tr><th scope="row" colSpan={2}>{plural(withSome.length, 'lens', 'lenses')} with readings</th><td className="lb-numcol lb-strong">{num(total)}</td><td className="lb-numcol lb-strong">{num(rowsAll)}</td></tr></tfoot>
        </table>
      </div>
      {none.length ? <p className="lb-small"><span className="lb-muted">No reading in {plural(none.length, 'lens', 'lenses')}: </span>{none.map(l => l.name).join(', ')}.</p> : null}
      <p className="lb-small lb-muted">rows: the rows with at least one reading in that lens (in the last line: in any lens).</p>
    </>
  );
}

function MigrationCounts() {
  const [mc, err] = useTable('MIGRATION_COUNTS');
  if (!mc) return err ? <p className="lb-muted">MIGRATION_COUNTS.json: not available</p> : <p className="lb-muted">Loading…</p>;
  return (
    <div className="lb-two">
      {Object.entries(mc).map(([sec, vals]) => (
        <div key={sec}>
          <h4>{sec}</h4>
          {vals && typeof vals === 'object' && !Array.isArray(vals)
            ? <dl className="lb-kv lb-kv-tight">{Object.entries(vals).map(([k, v]) => <div key={k} className="lb-kv-item"><dt>{k}</dt><dd className="lb-num">{fmt(v)}</dd></div>)}</dl>
            : <p className="lb-num">{fmt(vals)}</p>}
        </div>
      ))}
    </div>
  );
}

export default function Method() {
  return (
    <div className="lb-stack-lg lb-method">
      <VersionLine />
      <section className="lb-card lb-pad">
        <h3 className="lb-h3">Ground rules</h3>
        <ol className="lb-rules">{rules.map((r, i) => <li key={i} className="lb-prose"><Md text={r} /></li>)}</ol>
        <p className="lb-small lb-muted">{SOURCES.rules}</p>
      </section>
      <section className="lb-card lb-pad" aria-label="Texts by status">
        <h3 className="lb-h3">Who wrote the texts</h3>
        <ul className="lb-plain lb-stack lb-textstatus">
          {textStatuses.map(([k, meaning]) => (
            <li key={k}><span className="lb-textstatus-word">{k === 'human' ? <span className="lb-mono">human</span> : <TextMark rec={{ status: k }} withSource={false} />}</span> <span>{meaning}</span></li>
          ))}
        </ul>
        <TextCounts />
        <p className="lb-prose"><Md text={draftRule} /></p>
        <p className="lb-small lb-muted">{SOURCES.texts}</p>
      </section>
      <section className="lb-card lb-pad" aria-label="Lens readings per lens">
        <h3 className="lb-h3">Readings per lens</h3>
        <ReadingCounts />
      </section>
      <section className="lb-card lb-pad">
        <h3 className="lb-h3">Statuses</h3>
        <p className="lb-prose"><Md text={statusIntro} /></p>
        <div className="lb-scroll">
          <table className="lb-table">
            <thead><tr><th scope="col">status</th><th scope="col">rule</th></tr></thead>
            <tbody>{statuses.map(([k, rule]) => <tr key={k}><td><span className="lb-mono">{k}</span></td><td><Md text={rule} /></td></tr>)}</tbody>
          </table>
        </div>
        <p className="lb-prose"><Md text={priority} /></p>
        <p className="lb-small lb-muted">{SOURCES.statuses}</p>
      </section>
      <section className="lb-card lb-pad">
        <h3 className="lb-h3">The five badges</h3>
        <div className="lb-scroll">
          <table className="lb-table">
            <thead><tr><th scope="col">status</th><th scope="col">badge</th><th scope="col">shape</th><th scope="col">research word</th><th scope="col">learner word</th></tr></thead>
            <tbody>{badgeWords.map(([kind, shape, word], i) => { const s = sample(kind); return (
              <tr key={kind}><td><span className="lb-mono">{kind}</span></td><td><Badge status={s.status} badge={s.badge} level="research" /></td><td>{shape}</td><td>{word}</td><td>{learnerWords[i]}</td></tr>
            ); })}</tbody>
          </table>
        </div>
        <p className="lb-small lb-muted">{SOURCES.badges}</p>
      </section>
      <Fold className="lb-card" summary={<span className="lb-sum"><span className="lb-strong">Counts recorded by the migration</span><span className="lb-muted lb-mono">MIGRATION_COUNTS.json</span></span>}>
        <MigrationCounts />
      </Fold>
    </div>
  );
}
