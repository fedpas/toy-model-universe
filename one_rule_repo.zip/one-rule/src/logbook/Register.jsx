// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/Register.jsx — the register: every row with its status, place, signature, kind and stage, filtered by
// the facets of registerModel.js (the same functions tests/logbook.test.mjs runs), paginated, with a drawer per row.
// The facet "learner text" files each row by its learner text at the current settings: none, human, draft or reviewed.
import { useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import { useTable, statusOf } from '../app/content.js';
import Badge from '../components/Badge.jsx';
import RowDrawer from './RowDrawer.jsx';
import { Loading, Fold, plural } from './ui.jsx';
import { textStatuses } from './methodText.js';
import {
  buildRegister, facetCounts, filterRows, emptyFilters, activeFilterCount, sortRows, dependentsIndex, excerpt, pageLabel,
  NOTIONS, NOTION_INFO, STAGES, FIELD_ORDER, STATUS_ORDER, LEARNER_ORDER, SORTS, PAGE_SIZE, sqWord, kindRank,
} from './registerModel.js';

const learnerTitle = v => (v === 'none' ? 'the row has no learner text at these settings' : (textStatuses.find(s => s[0] === v) || [])[1]);

/** the derived status table; if the build named it differently, fall back to statusOf() once it answers */
function useStatusTable(rows) {
  const [table, err] = useTable('derived_status');
  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (table || !err || !rows || !rows.length) return undefined;
    let n = 0; const t = setInterval(() => { n++; setTick(k => k + 1); if (statusOf(rows[0].id) || n > 40) clearInterval(t); }, 250);
    return () => clearInterval(t);
  }, [table, err, rows]);
  return useMemo(() => {
    if (table) return table;
    if (!rows) return null;
    const m = {}; let any = false;
    for (const r of rows) { const s = statusOf(r.id); if (s) { m[r.id] = s; any = true; } }
    return any ? m : (err ? {} : null);
  }, [table, err, rows, tick]); // eslint-disable-line react-hooks/exhaustive-deps
}

function FacetList({ name, values, counts, sel, onToggle, label = v => v, title }) {
  return (
    <div className="lb-facet" role="group" aria-label={name}>
      {values.map(v => (
        <label key={String(v)} className="lb-check" title={title ? title(v) : undefined}>
          <input type="checkbox" checked={sel.has(v)} onChange={() => onToggle(v)} />
          <span className="lb-check-label">{label(v)}</span>
          <span className="lb-count">{counts[v] || 0}</span>
        </label>
      ))}
    </div>
  );
}

export default function Register({ nav, target, settings }) {
  const [rows, rowsErr] = useTable('rows');
  const [texts] = useTable('texts');
  const [pages] = useTable('pages');
  const status = useStatusTable(rows);
  const reg = useMemo(() => (rows && status ? buildRegister({ rows, status, texts, mode: settings.mode, lens: settings.lens }) : null), [rows, status, texts, settings.mode, settings.lens]);
  const counts = useMemo(() => (reg ? facetCounts(reg) : null), [reg]);
  const dependents = useMemo(() => dependentsIndex(rows), [rows]);
  const maskById = useMemo(() => new Map((reg || []).map(x => [x.id, x.mask])), [reg]);
  const pageOrder = useMemo(() => (pages || []).map(p => p.route), [pages]);
  const pageTitle = useMemo(() => new Map((pages || []).map(p => [p.route, p.title && (p.title[settings.mode] || p.title.phys)])), [pages, settings.mode]);

  const [F, setF] = useState(emptyFilters);
  const [sortKey, setSortKey] = useState('id');
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState(() => new Set());
  const [railOpen, setRailOpen] = useState(() => { try { return !window.matchMedia('(max-width: 959px)').matches; } catch { return true; } });
  const q = useDeferredValue(F.q);
  const list = useMemo(() => (reg ? sortRows(filterRows(reg, { ...F, q }), sortKey, pageOrder) : []), [reg, F, q, sortKey, pageOrder]);
  const nPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  const cur = Math.min(page, nPages - 1);
  const shown = list.slice(cur * PAGE_SIZE, cur * PAGE_SIZE + PAGE_SIZE);
  const topRef = useRef(null);

  // a row asked for from another tab: show it alone (search by its id) with its drawer open
  useEffect(() => {
    if (!target || target.tab !== 'register' || !target.id) return;
    setF({ ...emptyFilters(), q: target.id }); setPage(0); setOpen(new Set([target.id]));
    requestAnimationFrame(() => { const el = document.getElementById('lb-row-' + target.id); if (el) el.scrollIntoView({ block: 'start' }); });
  }, [target]);

  const upd = patch => { setF(f => ({ ...f, ...patch })); setPage(0); };
  const toggleIn = (key, v) => { setF(f => { const s = new Set(f[key]); s.has(v) ? s.delete(v) : s.add(v); return { ...f, [key]: s }; }); setPage(0); };
  const toggleRow = id => setOpen(o => { const s = new Set(o); s.has(id) ? s.delete(id) : s.add(id); return s; });
  const goPage = p => { setPage(p); if (topRef.current) topRef.current.scrollIntoView({ block: 'start' }); };

  if (!reg) return <Loading what="the register" error={rowsErr} />;

  const pagesSorted = Object.keys(counts.page).sort((a, b) => {
    const ia = pageOrder.indexOf(a), ib = pageOrder.indexOf(b);
    return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib) || a.localeCompare(b);
  });
  const groups = Object.keys(counts.group).sort();
  const statuses = STATUS_ORDER.filter(s => counts.status[s]).concat(Object.keys(counts.status).filter(s => !STATUS_ORDER.includes(s)));
  const learnerValues = LEARNER_ORDER.concat(Object.keys(counts.learner).filter(s => !LEARNER_ORDER.includes(s)));
  const kinds = Object.keys(counts.kind).sort((a, b) => kindRank(a) - kindRank(b));
  const nActive = activeFilterCount(F);
  const chosen = [
    ...[...F.status].map(v => `status ${v}`), ...[...F.learner].map(v => `learner text ${v}`), ...[...F.page].map(v => `page ${pageLabel(v)}`), ...[...F.group].map(v => `group ${v}`),
    ...[...F.kind].map(v => `kind ${v}`), ...[...F.stage].map(v => `stage ${v}`), ...[...F.field].map(v => `field ${v}`),
    ...(F.notion.size ? [`notions (${F.notionMode} of) ${[...F.notion].join(' ')}`] : []),
    ...(F.sig === 'r0' ? ['r = 0'] : F.sig === 'rpos' ? ['r > 0'] : []), ...(F.isNew ? ['new (v16)'] : []), ...(F.review ? ['review note'] : []),
    ...(F.q.trim() ? [`search “${F.q.trim()}”`] : []),
  ];

  return (
    <div className="lb-register" ref={topRef}>
      <aside className={`lb-rail${railOpen ? ' is-open' : ''}`} aria-label="Filters">
        <button type="button" className="lb-btn lb-rail-toggle" aria-expanded={railOpen} onClick={() => setRailOpen(!railOpen)}>
          Filters{nActive ? ` (${nActive} active)` : ''}
        </button>
        <div className="lb-rail-body">
          <label className="lb-field">
            <span className="lb-eyebrow">Search</span>
            <input type="search" value={F.q} placeholder="id, word, check, notion…" onChange={e => upd({ q: e.target.value })} />
          </label>
          <div className="lb-field">
            <span className="lb-eyebrow">Status</span>
            <FacetList name="status" values={statuses} counts={counts.status} sel={F.status} onToggle={v => toggleIn('status', v)} />
          </div>
          <div className="lb-field">
            <span className="lb-eyebrow">Signature</span>
            <div className="lb-facet" role="radiogroup" aria-label="signature">
              {[['any', 'any r', counts.total], ['r0', 'r = 0 (no input)', counts.sig.r0], ['rpos', 'r > 0 (uses an input)', counts.sig.rpos]].map(([v, l, n]) => (
                <label key={v} className="lb-check"><input type="radio" name="lb-sig" checked={F.sig === v} onChange={() => upd({ sig: v })} /><span className="lb-check-label">{l}</span><span className="lb-count">{n}</span></label>
              ))}
            </div>
          </div>
          <div className="lb-field">
            <span className="lb-eyebrow">Learner text</span>
            <FacetList name="learner text" values={learnerValues} counts={counts.learner} sel={F.learner} onToggle={v => toggleIn('learner', v)} title={learnerTitle} />
          </div>
          <div className="lb-field">
            <label className="lb-check"><input type="checkbox" checked={F.isNew} onChange={e => upd({ isNew: e.target.checked })} /><span className="lb-check-label">new (v16)</span><span className="lb-count">{counts.new}</span></label>
            <label className="lb-check"><input type="checkbox" checked={F.review} onChange={e => upd({ review: e.target.checked })} /><span className="lb-check-label">has a review note</span><span className="lb-count">{counts.review}</span></label>
          </div>
          <Fold summary={<><span className="lb-eyebrow">Page</span>{F.page.size ? <span className="lb-count">{F.page.size} chosen</span> : null}</>}>
            <FacetList name="page" values={pagesSorted} counts={counts.page} sel={F.page} onToggle={v => toggleIn('page', v)} label={pageLabel} title={v => pageTitle.get(v)} />
          </Fold>
          <Fold summary={<><span className="lb-eyebrow">Group</span>{F.group.size ? <span className="lb-count">{F.group.size} chosen</span> : null}</>}>
            <FacetList name="group" values={groups} counts={counts.group} sel={F.group} onToggle={v => toggleIn('group', v)} />
          </Fold>
          <Fold summary={<><span className="lb-eyebrow">Kind</span>{F.kind.size ? <span className="lb-count">{F.kind.size} chosen</span> : null}</>}>
            <FacetList name="kind" values={kinds} counts={counts.kind} sel={F.kind} onToggle={v => toggleIn('kind', v)} />
          </Fold>
          <Fold summary={<><span className="lb-eyebrow">Stage</span>{F.stage.size ? <span className="lb-count">{F.stage.size} chosen</span> : null}</>}>
            <FacetList name="stage" values={STAGES.map(s => s[0]).filter(s => counts.stage[s])} counts={counts.stage} sel={F.stage} onToggle={v => toggleIn('stage', v)} label={v => `${v} · ${(STAGES.find(s => s[0] === v) || [])[1]}`} />
          </Fold>
          <Fold summary={<><span className="lb-eyebrow">Field</span>{F.field.size ? <span className="lb-count">{F.field.size} chosen</span> : null}</>}>
            <FacetList name="field" values={FIELD_ORDER.filter(f => counts.field[f])} counts={counts.field} sel={F.field} onToggle={v => toggleIn('field', v)} />
          </Fold>
          <Fold summary={<><span className="lb-eyebrow">Notions</span>{F.notion.size ? <span className="lb-count">{F.notion.size} chosen</span> : null}</>}>
            <div className="lb-seg" role="radiogroup" aria-label="how the chosen notions combine">
              {[['all', 'all of'], ['any', 'any of']].map(([v, l]) => <label key={v}><input type="radio" name="lb-nm" checked={F.notionMode === v} onChange={() => upd({ notionMode: v })} /> {l}</label>)}
            </div>
            <FacetList name="notions" values={NOTIONS} counts={counts.notion} sel={F.notion} onToggle={v => toggleIn('notion', v)} label={v => <><span className="lb-mono">{v}</span> <span className="lb-muted">{sqWord(v)}</span></>} title={v => NOTION_INFO[v]} />
          </Fold>
          <button type="button" className="lb-btn" disabled={!nActive} onClick={() => { setF(emptyFilters()); setPage(0); }}>Reset filters</button>
        </div>
      </aside>

      <div className="lb-reg-main">
        <div className="lb-toolbar" role="status" aria-live="polite">
          <span><strong className="lb-num">{list.length}</strong> of <span className="lb-num">{counts.total}</span> rows</span>
          {chosen.length ? <span className="lb-muted lb-chosen">{chosen.join(' · ')}</span> : null}
          <label className="lb-sort"><span className="lb-muted">Order</span>
            <select value={sortKey} onChange={e => { setSortKey(e.target.value); setPage(0); }}>{SORTS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          </label>
          {open.size ? <button type="button" className="lb-btn" onClick={() => setOpen(new Set())}>Close drawers</button> : null}
        </div>
        <div className="lb-scroll">
          <table className="lb-table lb-reg-table">
            <thead>
              <tr><th scope="col">Row</th><th scope="col">Status</th><th scope="col">Page › section</th><th scope="col" className="lb-th-sig">(p,q,r)</th><th scope="col">Kind</th><th scope="col">Stage</th><th scope="col">Research text</th></tr>
            </thead>
            <tbody>
              {shown.map(x => {
                const isOpen = open.has(x.id); const st = x.st || {};
                return [
                  <tr key={x.id} id={'lb-row-' + x.id} className={isOpen ? 'is-open' : ''} onClick={e => { if (!e.target.closest('button, a, input, select')) toggleRow(x.id); }}>
                    <td data-label="Row"><button type="button" className="lb-rowbtn" aria-expanded={isOpen} aria-controls={'lb-drawer-' + x.id} onClick={() => toggleRow(x.id)}>{x.id}</button></td>
                    <td data-label="Status"><span className="lb-statuscell">{st.badge !== x.status ? <span className="lb-mono lb-small lb-nowrap">{x.status}</span> : null}{st.badge ? <Badge status={st.status} badge={st.badge} level="research" /> : null}</span></td>
                    <td data-label="Page"><span className="lb-mono lb-small">{(x.row.shownOn || []).map(s => `${pageLabel(s.page)} › ${s.section}`).join('; ') || '—'}</span></td>
                    <td data-label="(p,q,r)"><span className="lb-mono lb-num">({x.sig.join(',')})</span></td>
                    <td data-label="Kind">{x.row.kind || '—'}</td>
                    <td data-label="Stage"><span title={(STAGES.find(s => s[0] === x.row.stage) || [])[1]}>{x.row.stage || '—'}</span></td>
                    <td data-label="Text" className="lb-excerpt" data-snippet="">{excerpt(x.text, 120) || <span className="lb-muted">no research text</span>}</td>
                  </tr>,
                  isOpen ? (
                    <tr key={x.id + '-d'} className="lb-drawer-row" id={'lb-drawer-' + x.id}>
                      <td colSpan={7}><RowDrawer x={x} nav={nav} settings={settings} dependents={dependents} maskById={maskById} /></td>
                    </tr>
                  ) : null,
                ];
              })}
            </tbody>
          </table>
          {!shown.length ? <p className="lb-note">No row matches these filters.</p> : null}
        </div>
        {nPages > 1 ? (
          <nav className="lb-pager" aria-label="Register pages">
            <button type="button" className="lb-btn" disabled={cur === 0} onClick={() => goPage(0)}>First</button>
            <button type="button" className="lb-btn" disabled={cur === 0} onClick={() => goPage(cur - 1)}>Previous</button>
            <span className="lb-num">rows {cur * PAGE_SIZE + 1}–{Math.min(list.length, (cur + 1) * PAGE_SIZE)} · page {cur + 1} of {nPages}</span>
            <button type="button" className="lb-btn" disabled={cur >= nPages - 1} onClick={() => goPage(cur + 1)}>Next</button>
            <button type="button" className="lb-btn" disabled={cur >= nPages - 1} onClick={() => goPage(nPages - 1)}>Last</button>
          </nav>
        ) : null}
        <p className="lb-small lb-muted">{plural(counts.total, 'row')} · statuses computed by the content build; signature (p,q,r) = notions the rule supplies, imported, inputs.</p>
      </div>
    </div>
  );
}
