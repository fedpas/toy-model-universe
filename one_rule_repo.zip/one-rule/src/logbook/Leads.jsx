// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/Leads.jsx — the wave-3 leads of content/leads.json: outcome, scripts and their runs, rows changed; the
// proposed edits row by row (today / proposed); the rows needing one wording; the coordinator's notes; the new rows.
import { useMemo } from 'react';
import { useTable } from '../app/content.js';
import { Fold, Chip, Kv, RefList, RefLink, RunLine, Loading, plural } from './ui.jsx';
import { lastRunIndex, runFor, editsByRow, listOf } from './registerModel.js';

export default function Leads({ nav }) {
  const [L, err] = useTable('leads');
  const [runs] = useTable('check_runs');
  const [rows] = useTable('rows');
  const last = useMemo(() => (runs ? lastRunIndex(runs) : null), [runs]);
  const byRow = useMemo(() => (L ? editsByRow(L.edits) : []), [L]);
  if (!L) return <Loading what="the leads" error={err} />;
  const leads = L.leads || [];
  const newRows = rows ? rows.filter(r => r.since === 'v16').map(r => r.id) : null;
  const merge = [...new Set([...(L.mergeNeeded || []), ...(rows ? rows.filter(r => r.mergeNeeded).map(r => r.id) : [])])];
  const notes = listOf(L.coordinatorNotes);
  return (
    <div className="lb-stack-lg">
      <p className="lb-muted">{plural(leads.length, 'lead')} · {plural((L.edits || []).length, 'proposed edit')} on {plural(byRow.length, 'row')}{newRows ? ` · ${plural(newRows.length, 'row')} marked new` : ''}</p>

      <section className="lb-grid-cards" aria-label="The leads">
        {leads.map(l => (
          <article key={l.id} className="lb-card lb-pad">
            <h3 className="lb-h3"><span className="lb-mono">{l.id}</span></h3>
            <p className="lb-prose">{l.outcome}</p>
            <Kv items={[
              ['scripts', <ul className="lb-list">{(l.scripts || []).map(s => { const run = runFor(last, s); return <li key={s}><button type="button" className="lb-linkbtn lb-mono" onClick={() => nav.go('checks', { id: run ? run.script : s })}>{s}</button> {last ? <RunLine run={run} compact /> : null}</li>; })}</ul>],
              ['rows changed', <RefList ids={l.rowsReworded || []} nav={nav} empty="none" />],
              ['result', l.resultFile ? <span className="lb-mono lb-small">{l.resultFile}</span> : null],
              ['ship notes', l.shipNotes ? <span className="lb-mono lb-small">{l.shipNotes}</span> : null],
            ]} />
          </article>
        ))}
      </section>

      <section className="lb-two">
        <div className="lb-card lb-pad">
          <h3 className="lb-h3">Merge needed</h3>
          <RefList ids={merge} nav={nav} empty="none" />
        </div>
        <div className="lb-card lb-pad">
          <h3 className="lb-h3">Coordinator notes</h3>
          {notes.length ? <ul className="lb-list">{notes.map((n, i) => <li key={i}>{String(n)}</li>)}</ul> : <p className="lb-muted">none</p>}
        </div>
      </section>

      {newRows ? (
        <section className="lb-card lb-pad">
          <h3 className="lb-h3">Rows marked new <span className="lb-muted">({newRows.length})</span></h3>
          <RefList ids={newRows} nav={nav} max={60} />
        </section>
      ) : null}

      <section aria-label="Proposed edits by row" className="lb-stack">
        <h3 className="lb-h3">Proposed edits, row by row</h3>
        {byRow.map(([rowId, edits]) => (
          <Fold key={rowId} className="lb-card" summary={<span className="lb-sum"><span className="lb-mono lb-strong">{rowId}</span><span className="lb-muted">{plural(edits.length, 'edit')} · {[...new Set(edits.map(e => e.lead))].join(', ')}</span>{merge.includes(rowId) ? <Chip dash>merge needed</Chip> : null}</span>}>
            <p><RefLink id={rowId} nav={nav} note=" in the register" /></p>
            {edits.map((e, i) => (
              <div key={i} className="lb-edit">
                <p className="lb-inline"><Chip>{e.lead}</Chip>{e.kind ? <span className="lb-mono lb-small">{e.kind}</span> : null}{(e.rows || []).length > 1 ? <span className="lb-muted lb-small">also {e.rows.filter(r => r !== rowId).join(', ')}</span> : null}</p>
                {e.heading ? <p className="lb-small lb-muted">{e.heading}</p> : null}
                {e.instruction && (!e.today || !e.proposed) ? <p className="lb-small lb-muted">{e.instruction}</p> : null}
                <div className="lb-diff">
                  <div><h4>Today</h4><p className="lb-prose lb-quote">{e.today || <span className="lb-muted">—</span>}</p></div>
                  <div><h4>Proposed</h4><p className="lb-prose lb-quote">{e.proposed || <span className="lb-muted">—</span>}</p></div>
                </div>
                {e.flagChange ? <p className="lb-small">flags: <span className="lb-mono">{e.flagChange.from}</span> → <span className="lb-mono">{e.flagChange.to}</span></p> : null}
                {e.note ? <p className="lb-small">{e.note}</p> : null}
                {(e.quotes || []).length > 2 || ((e.quotes || []).length && (!e.today || !e.proposed)) ? (
                  <Fold summary={`all ${e.quotes.length} quoted passages of this edit`}>
                    <ol className="lb-list lb-small">{e.quotes.map((qt, k) => <li key={k} className="lb-quote">{qt}</li>)}</ol>
                  </Fold>
                ) : null}
              </div>
            ))}
          </Fold>
        ))}
      </section>
    </div>
  );
}
