// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/MapTab.jsx — the dependency map: the pages as a layered graph (levels = the longest chain of needs in
// content/pages.json), and, for one row, what it rests on and what leads from it, two levels each way.
import { useEffect, useMemo, useState } from 'react';
import { useTable, useSettings, textFor } from '../app/content.js';
import { Loading, RefLink, RefList, Fold, plural } from './ui.jsx';
import { pageLayers, tabRoutes, pageLabel, rowGraph, dependentsIndex, refKind, excerpt, RELS, DIRECTED_RELS, STATUS_ORDER } from './registerModel.js';

const NW = 156, NH = 30, GX = 64, GY = 10, PAD = 20, TOP = 36;
const DASH = { derives: null, instance: '2 3', 'uses-input': '7 4', equiv: '1 3', cycle: '9 3 2 3', contradicts: '4 2' };
const clip = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

export default function MapTab({ nav, target }) {
  return (
    <div className="lb-stack-lg">
      <PageMap nav={nav} />
      <RowMap nav={nav} target={target} />
    </div>
  );
}

function PageMap({ nav }) {
  const settings = useSettings();
  const [pages, err] = useTable('pages');
  const [needs] = useTable('needs');
  const [steps] = useTable('steps');
  const [rows] = useTable('rows');
  const [status] = useTable('derived_status');
  const [sel, setSel] = useState(null);
  const L = useMemo(() => (pages ? pageLayers(pages) : null), [pages]);
  const byRoute = useMemo(() => new Map((pages || []).map(p => [p.route, p])), [pages]);
  const stepBy = useMemo(() => new Map((Array.isArray(steps) ? steps : []).map(s => [s.route, s])), [steps]);
  const tabsOf = useMemo(() => {
    const m = new Map(); if (!rows || !needs) return m;
    const tr = tabRoutes(rows);
    for (const [tab, v] of Object.entries(needs)) { const r = tr.get(tab); if (r == null) continue; if (!m.has(r)) m.set(r, []); m.get(r).push([tab, v]); }
    return m;
  }, [rows, needs]);
  const rowsOn = useMemo(() => { const m = new Map(); for (const r of rows || []) for (const p of new Set((r.shownOn || []).map(s => s.page))) { if (!m.has(p)) m.set(p, []); m.get(p).push(r.id); } return m; }, [rows]);
  if (!L) return <Loading what="the pages" error={err} />;

  const title = r => { const p = byRoute.get(r); const t = p && p.title; return (t && (settings.level === 'learner' ? t.learner : t[settings.mode])) || pageLabel(r); };
  const label = r => { const s = stepBy.get(r); return s ? `${s.no} · ${s.nav}` : clip(title(r), 22); };
  const pos = new Map();
  L.layers.forEach((layer, l) => layer.forEach((r, i) => pos.set(r, { x: PAD + l * (NW + GX), y: TOP + i * (NH + GY) })));
  const width = PAD * 2 + L.layers.length * (NW + GX) - GX, height = TOP + Math.max(...L.layers.map(l => l.length)) * (NH + GY) + PAD;
  const near = sel ? new Set([sel, ...((byRoute.get(sel) || {}).needs || []), ...(L.neededBy.get(sel) || [])]) : null;
  const p = sel ? byRoute.get(sel) : null;
  const onPage = sel != null ? rowsOn.get(sel) || [] : [];
  const stCount = {}; if (status) for (const id of onPage) { const s = status[id] && status[id].status; if (s) stCount[s] = (stCount[s] || 0) + 1; }

  return (
    <section className="lb-card lb-pad" aria-label="Dependency map of the pages">
      <h3 className="lb-h3">Pages and what they need</h3>
      <p className="lb-small lb-muted">Arrows point from a page to the pages it needs; levels are the longest chain of needs. Choose a page to see its links.</p>
      <div className="lb-graph">
        <svg viewBox={`0 0 ${width} ${height}`} width={width} height={height} role="group" aria-label={`Dependency map: ${L.layers.flat().length} pages in ${L.layers.length} levels`}>
          <defs><marker id="lb-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" className="lb-arrowhead" /></marker></defs>
          {L.layers.map((_, l) => <text key={l} className="lb-g-level" x={PAD + l * (NW + GX)} y={20}>LEVEL {l}</text>)}
          {L.edges.map((e, i) => {
            const a = pos.get(e.from), b = pos.get(e.to); if (!a || !b) return null;
            const x1 = a.x, y1 = a.y + NH / 2, x2 = b.x + NW, y2 = b.y + NH / 2, mx = (x1 + x2) / 2;
            const hot = sel && (e.from === sel || e.to === sel);
            return <path key={i} className={`lb-edge${hot ? ' is-hot' : sel ? ' is-dim' : ''}`} d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`} markerEnd="url(#lb-arrow)" />;
          })}
          {[...pos].map(([r, q]) => (
            <g key={r} className={`lb-node${sel === r ? ' is-sel' : ''}${near && !near.has(r) ? ' is-dim' : ''}${stepBy.has(r) ? ' is-step' : ''}`} tabIndex={0} role="button"
              aria-label={`${title(r)} (${pageLabel(r)})`} onClick={() => setSel(sel === r ? null : r)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSel(sel === r ? null : r); } }}>
              <title>{`${title(r)} — ${pageLabel(r)}`}</title>
              <rect x={q.x} y={q.y} width={NW} height={NH} rx="4" />
              <text x={q.x + 8} y={q.y + NH / 2 + 4}>{label(r)}</text>
            </g>
          ))}
        </svg>
      </div>
      {L.isolated.length ? <p className="lb-small"><span className="lb-muted">Pages with no need and needed by none: </span>{L.isolated.map(r => <button key={r} type="button" className="lb-ref" onClick={() => setSel(r)}>{pageLabel(r)}</button>)}</p> : null}
      {p ? (
        <div className="lb-panel" role="status" aria-live="polite">
          <h4>{title(sel)} <span className="lb-mono lb-muted">{pageLabel(sel)}{p.stepNo ? ` · step ${p.stepNo}` : ''}</span></h4>
          <dl className="lb-rels">
            <div><dt>needs</dt><dd>{(p.needs || []).length ? p.needs.map(r => <button key={r} type="button" className="lb-ref" onClick={() => setSel(r)}>{pageLabel(r)}</button>) : <span className="lb-muted">nothing</span>}</dd></div>
            <div><dt>needed by</dt><dd>{(L.neededBy.get(sel) || []).length ? L.neededBy.get(sel).map(r => <button key={r} type="button" className="lb-ref" onClick={() => setSel(r)}>{pageLabel(r)}</button>) : <span className="lb-muted">no page</span>}</dd></div>
            <div><dt>hero row</dt><dd>{p.hero && p.hero.row ? <RefLink id={p.hero.row} nav={nav} /> : <span className="lb-muted">none</span>}</dd></div>
            <div><dt>rows shown</dt><dd>{plural(onPage.length, 'row')}{status && onPage.length ? <span className="lb-muted"> · {STATUS_ORDER.filter(s => stCount[s]).map(s => `${stCount[s]} ${s}`).join(' · ')}</span> : null}</dd></div>
          </dl>
          {(tabsOf.get(sel) || []).length ? (
            <div className="lb-small">
              <h4>What the v15 tabs of this page take from outside (needs table)</h4>
              <ul className="lb-list">{tabsOf.get(sel).map(([tab, v]) => <li key={tab}><span className="lb-mono">{tab}</span>{(v.needs || []).length ? <span className="lb-muted"> · needs {v.needs.join(', ')}</span> : null}{v.learner ? <> · {v.learner}</> : null}</li>)}</ul>
            </div>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function RowMap({ nav, target }) {
  const settings = useSettings();
  const [rows, err] = useTable('rows');
  const [typed, setTyped] = useState('');
  const [center, setCenter] = useState(null);
  const [rels, setRels] = useState(() => new Set(DIRECTED_RELS));
  const rowsById = useMemo(() => new Map((rows || []).map(r => [r.id, r])), [rows]);
  const dependents = useMemo(() => dependentsIndex(rows), [rows]);
  useEffect(() => { if (target && target.tab === 'map' && target.id) { setTyped(target.id); setCenter(target.id); } }, [target]);
  const G = useMemo(() => (center && rowsById.has(center) ? rowGraph(center, rowsById, dependents, [...rels], 2, 40) : null), [center, rowsById, dependents, rels]);
  if (!rows) return <Loading what="the rows" error={err} />;

  const submit = v => { const id = v.trim(); const hit = rowsById.has(id) ? id : [...rowsById.keys()].find(k => k.toLowerCase() === id.toLowerCase()); setCenter(hit || id); if (hit) setTyped(hit); };
  const levels = [-2, -1, 0, 1, 2];
  const heads = { '-2': 'rests on (2nd)', '-1': 'rests on', 0: 'row', 1: 'leads to', 2: 'leads to (2nd)' };
  const pos = new Map();
  let maxN = 1;
  if (G) levels.forEach((k, ci) => { const col = G.cols[k] || []; maxN = Math.max(maxN, col.length + (G.hidden[k] ? 1 : 0)); col.forEach((id, i) => pos.set(id, { x: PAD + ci * (NW + GX), y: TOP + i * (NH + GY) })); });
  const width = PAD * 2 + 5 * (NW + GX) - GX, height = TOP + maxN * (NH + GY) + PAD;
  const tip = id => { const k = refKind(id); if (k !== 'row') return id; const t = textFor(id, { mode: settings.mode, level: 'research', lens: settings.lens }); const r = rowsById.get(id); return `${id}${r ? ` · ${r.kind || ''}` : ''}${t ? ' — ' + excerpt(t, 140) : ''}`; };
  const act = id => { const k = refKind(id); if (k === 'theorem') nav.go('theorems', { id }); else if (k === 'question') nav.go('questions', { id }); else if (k === 'check') nav.go('checks', { id }); else if (rowsById.has(id)) { setCenter(id); setTyped(id); } };

  return (
    <section className="lb-card lb-pad" aria-label="Rests on and leads to, for one row">
      <h3 className="lb-h3">One row: what it rests on, what leads from it</h3>
      <form className="lb-rowmap-form" onSubmit={e => { e.preventDefault(); submit(typed); }}>
        <label className="lb-field lb-field-inline"><span className="lb-eyebrow">Row id</span>
          <input list="lb-row-ids" value={typed} placeholder="e.g. GRV-010" onChange={e => { setTyped(e.target.value); if (rowsById.has(e.target.value.trim())) setCenter(e.target.value.trim()); }} />
        </label>
        <datalist id="lb-row-ids">{rows.map(r => <option key={r.id} value={r.id} />)}</datalist>
        <button type="submit" className="lb-btn">Show</button>
        <fieldset className="lb-rels-pick"><legend className="lb-eyebrow">Relations</legend>
          {RELS.map(k => (
            <label key={k} className="lb-check-inline"><input type="checkbox" checked={rels.has(k)} onChange={() => setRels(s => { const n = new Set(s); n.has(k) ? n.delete(k) : n.add(k); return n; })} />
              <svg width="26" height="8" aria-hidden="true"><line x1="0" y1="4" x2="26" y2="4" className="lb-edge" strokeDasharray={DASH[k] || undefined} /></svg>{k}</label>
          ))}
        </fieldset>
      </form>
      {center && !rowsById.has(center) ? <p className="lb-note">No row has the id “{center}”.</p> : null}
      {!center ? <p className="lb-muted">Type a row id to draw its graph (or open one from a row's drawer).</p> : null}
      {G ? (
        <>
          <div className="lb-graph">
            <svg viewBox={`0 0 ${width} ${height}`} width={width} height={height} role="group" aria-label={`${center}: ${levels.filter(k => k < 0).reduce((a, k) => a + (G.cols[k] || []).length, 0)} nodes it rests on, ${levels.filter(k => k > 0).reduce((a, k) => a + (G.cols[k] || []).length, 0)} that lead from it`}>
              <defs><marker id="lb-arrow2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" className="lb-arrowhead" /></marker></defs>
              {levels.map((k, ci) => <text key={k} className="lb-g-level" x={PAD + ci * (NW + GX)} y={20}>{heads[k].toUpperCase()}</text>)}
              {G.edges.map((e, i) => {
                const a = pos.get(e.from), b = pos.get(e.to); if (!a || !b) return null;
                const x1 = a.x, y1 = a.y + NH / 2, x2 = b.x + NW, y2 = b.y + NH / 2, mx = (x1 + x2) / 2;
                return <path key={i} className="lb-edge" strokeDasharray={DASH[e.rel] || undefined} d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`} markerEnd="url(#lb-arrow2)"><title>{`${e.from} ${e.rel} ${e.to}`}</title></path>;
              })}
              {[...pos].map(([id, q]) => (
                <g key={id} className={`lb-node${id === center ? ' is-sel' : ''}${refKind(id) !== 'row' ? ' is-step' : ''}`} tabIndex={0} role="button" aria-label={tip(id)} data-snippet=""
                  onClick={() => act(id)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(id); } }}>
                  <title>{tip(id)}</title>
                  <rect x={q.x} y={q.y} width={NW} height={NH} rx="4" />
                  <text x={q.x + 8} y={q.y + NH / 2 + 4} className="lb-mono-svg">{id}</text>
                </g>
              ))}
              {levels.map((k, ci) => (G.hidden[k] ? <text key={'h' + k} className="lb-g-level" x={PAD + ci * (NW + GX) + 8} y={TOP + (G.cols[k] || []).length * (NH + GY) + NH / 2 + 4}>+{G.hidden[k]} more</text> : null))}
            </svg>
          </div>
          <p className="lb-small"><RefLink id={center} nav={nav} note=" in the register" /></p>
          <Fold summary="The same graph as lists">
            <dl className="lb-rels">{levels.filter(k => k !== 0).map(k => <div key={k}><dt>{heads[k]}</dt><dd><RefList ids={G.all[k] || []} nav={nav} empty="none" />{G.hidden[k] ? <span className="lb-muted"> ({G.hidden[k]} not drawn above)</span> : null}</dd></div>)}</dl>
          </Fold>
        </>
      ) : null}
    </section>
  );
}
