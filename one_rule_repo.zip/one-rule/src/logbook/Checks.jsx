// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/Checks.jsx — the check scripts of content/checks.json by family, each with its ids and their statements,
// method and controls, the last recorded run (content/check_runs.json) and the rows whose evidence names it.
import { useDeferredValue, useEffect, useMemo, useState } from 'react';
import { useTable } from '../app/content.js';
import { Fold, Kv, RefList, RunLine, Loading, plural } from './ui.jsx';
import { lastRunIndex, familyTop, runPassed } from './registerModel.js';

export default function Checks({ nav, target }) {
  const [checks, err] = useTable('checks');
  const [runs] = useTable('check_runs');
  const last = useMemo(() => (runs ? lastRunIndex(runs) : null), [runs]);
  const [query, setQuery] = useState('');
  const q = useDeferredValue(query.trim().toLowerCase());
  const [openFam, setOpenFam] = useState(() => new Set());
  const [openScript, setOpenScript] = useState(() => new Set());

  useEffect(() => {
    if (!target || target.tab !== 'checks' || !target.id || !checks) return;
    const id = target.id; const base = '/' + id.split('/').pop();
    const c = checks.find(x => x.script === id || x.script === 'checks/' + id) || checks.find(x => x.script.endsWith(base)) || checks.find(x => (x.ids || []).some(i => i.id === id));
    if (!c) { setQuery(id); return; }
    setQuery(''); setOpenFam(s => new Set(s).add(familyTop(c))); setOpenScript(s => new Set(s).add(c.script));
    requestAnimationFrame(() => { const el = document.getElementById('lb-chk-' + c.script); if (el) el.scrollIntoView({ block: 'start' }); });
  }, [target, checks]);

  const families = useMemo(() => {
    if (!checks) return [];
    const m = new Map();
    for (const c of checks) {
      if (q && ![c.script, c.family, c.what, c.notes, ...(c.ids || []).flatMap(i => [i.id, i.statement])].some(v => String(v || '').toLowerCase().includes(q))) continue;
      const f = familyTop(c); if (!m.has(f)) m.set(f, []); m.get(f).push(c);
    }
    return [...m];
  }, [checks, q]);

  useEffect(() => { if (q && families.length && families.length <= 3) setOpenFam(new Set(families.map(f => f[0]))); }, [q, families]);

  if (!checks) return <Loading what="the checks" error={err} />;
  const nIds = checks.reduce((a, c) => a + (c.ids || []).length, 0);
  const lastRuns = last ? Object.values(last) : [];
  return (
    <div className="lb-stack-lg">
      <p className="lb-muted">{plural(checks.length, 'script')} · {nIds} check ids · {runs ? `${runs.length} recorded runs; last runs: ${lastRuns.filter(r => r.passed === true).length} passed, ${lastRuns.filter(r => r.passed !== true).length} not passed` : 'loading the runs…'}</p>
      <label className="lb-field lb-field-inline"><span className="lb-eyebrow">Search</span>
        <input type="search" value={query} placeholder="script, check id, words of a statement…" onChange={e => setQuery(e.target.value)} />
      </label>
      {!families.length ? <p className="lb-note">No script matches.</p> : null}
      {families.map(([f, list]) => {
        const ids = list.reduce((a, c) => a + (c.ids || []).length, 0);
        const passed = last ? list.filter(c => runPassed(last[c.script]) === true).length : null;
        const famOpen = openFam.has(f);
        return (
          <Fold key={f} className="lb-card" open={famOpen} onToggle={o => setOpenFam(s => { const n = new Set(s); o ? n.add(f) : n.delete(f); return n; })}
            summary={<span className="lb-sum"><span className="lb-mono lb-strong">{f}</span><span className="lb-muted">{plural(list.length, 'script')} · {ids} ids{passed != null ? ` · last run passed ${passed} of ${list.length}` : ''}</span></span>}>
            <div className="lb-stack">
              {list.map(c => (
                <Fold key={c.script} id={'lb-chk-' + c.script} className="lb-sub" open={openScript.has(c.script)}
                  onToggle={o => setOpenScript(s => { const n = new Set(s); o ? n.add(c.script) : n.delete(c.script); return n; })}
                  summary={<span className="lb-sum"><span className="lb-mono">{c.script.replace(/^checks\//, '')}</span>{last ? <RunLine run={last[c.script]} compact /> : null}</span>}>
                  <Kv items={[
                    ['family', <span className="lb-mono">{c.family}</span>],
                    ['what it computes', c.what],
                    ['method', c.method],
                    ['independent route', c.independentRoute],
                    ['controls', c.controls],
                    ['dependencies', c.deps],
                    ['stored result', c.storedResult ? <span className="lb-mono">{c.storedResult}</span> : null],
                    ['log', c.log],
                    ['notes', c.notes],
                    ['since', c.since],
                    ['last run', last ? <span className="lb-stack"><RunLine run={last[c.script]} />{last[c.script] ? <span className="lb-muted lb-small">{last[c.script].machine}{last[c.script].source ? ` · ${last[c.script].source}` : ''}</span> : null}</span> : null],
                    ['check ids', (c.ids || []).length ? (
                      <Fold summary={plural(c.ids.length, 'check id') + ' with statements'}>
                        <ul className="lb-list lb-ids">{c.ids.map(i => <li key={i.id}><span className="lb-mono">{i.id}</span> {i.statement}</li>)}</ul>
                      </Fold>
                    ) : <span className="lb-muted">the script prints no ids</span>],
                    ['rows naming it', <RefList ids={c.rowsNaming || []} nav={nav} max={30} empty="none" />],
                  ]} />
                </Fold>
              ))}
            </div>
          </Fold>
        );
      })}
    </div>
  );
}
