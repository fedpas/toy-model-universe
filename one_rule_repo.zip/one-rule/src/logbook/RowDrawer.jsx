// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/RowDrawer.jsx — everything recorded about one row: its texts (with a "draft" or "reviewed" mark when a model wrote
// them), status and legacy flags, address, evidence with the last run of each script, what it rests on and what leads from it,
// the review note, neighbours, readings. Research texts and readings render their `$…$` through the pages' RichText (KaTeX);
// at learner level nothing is typeset, and the learner text is always plain words.
import { useMemo } from 'react';
import { useTable, textFor } from '../app/content.js';
import { lensReadingsIndex } from '../app/store.js';
import Badge from '../components/Badge.jsx';
import RichText from '../components/RichText.jsx';
import { orderReadings, matchWord } from '../components/LensReading.jsx';
import { Kv, RefList, RunLine, Tag, Fold, Chip, TextMark, plural } from './ui.jsx';
import { checksIndex, lastRunIndex, resolveEvidence, groupByRel, readingsForRow, sqWord, pageLabel, PRIMES, NOTIONS, STAGES, NOTION_INFO } from './registerModel.js';

const stageName = s => (STAGES.find(x => x[0] === s) || [s, ''])[1];
/** a field of a reading as the pages print it: `$…$` typeset at research level, the plain characters at learner level */
const Rt = ({ text, level }) => (text == null || text === '' ? null : <RichText text={String(text)} level={level} />);

export default function RowDrawer({ x, nav, settings, dependents, maskById }) {
  const r = x.row, st = x.st || {};
  const [checks] = useTable('checks');
  const [runs] = useTable('check_runs');
  const [readings] = useTable('readings');
  const cidx = useMemo(() => (checks ? checksIndex(checks) : null), [checks]);
  const last = useMemo(() => (runs ? lastRunIndex(runs) : null), [runs]);
  const evidence = useMemo(() => resolveEvidence(r, cidx, last), [r, cidx, last]);
  const reads = useMemo(() => (readings ? readingsForRow(r, readings) : null), [r, readings]);
  // the row's readings in the lenses (content/lens_readings.json): lens by lens in the order of the registry
  const [lensReadings] = useTable('lens_readings');
  const [lenses] = useTable('lenses');
  const byLens = useMemo(() => {
    const idx = lensReadings ? lensReadingsIndex() : null;
    if (!idx || !lenses) return [];
    return lenses.map(l => [l, idx.get(l.key)?.get(r.id)]).filter(([, list]) => list && list.length).map(([l, list]) => [l, orderReadings(list)]);
  }, [lensReadings, lenses, r.id]);
  const nLensReadings = byLens.reduce((n, [, list]) => n + list.length, 0);
  // the text records of the register entry (the lookup chain of 02 §2 at these settings); the pages' textFor if the entry has none
  const researchRec = x.researchRec || null, learnerRec = x.learnerRec || null;
  const research = (researchRec && researchRec.body) || textFor(r.id, { mode: settings.mode, level: 'research', lens: settings.lens }) || x.text;
  const learner = (learnerRec && learnerRec.body) || textFor(r.id, { mode: settings.mode, level: 'learner', lens: settings.lens }) || x.learner;
  // KaTeX only at research level: with the learner switch on, the drawer prints the `$…$` source as it is
  const mathLevel = settings.level === 'learner' ? 'learner' : 'research';
  const out = groupByRel(r.depends);
  const inn = groupByRel(dependents.get(r.id) || []);
  const neighbours = (st.neighbours || []);
  const homes = settings.mode === 'math' ? [['home (mathematics)', r.homeMath], ['home (physics)', r.homePhys]] : [['home (physics)', r.homePhys], ['home (mathematics)', r.homeMath]];

  // the notion by which a neighbour differs: one bit of the mask
  const diff = id => {
    const m = maskById.get(id); if (m == null || typeof st.mask !== 'number') return null;
    const d = m ^ st.mask; const i = NOTIONS.findIndex((_, k) => d === 1 << k); if (i < 0) return null;
    return (m & d ? '+' : '−') + NOTIONS[i];
  };

  return (
    <div className="lb-drawer" role="region" aria-label={`${r.id}: everything recorded`}>
      <section className="lb-drawer-text">
        <div className="lb-texthead"><h4>Research text</h4><TextMark rec={researchRec} /></div>
        <p className="lb-prose" data-text="research">{research ? <RichText text={research} level={mathLevel} /> : <span className="lb-muted">no research text</span>}</p>
        {learner ? (
          <>
            <div className="lb-texthead"><h4>Learner text</h4><TextMark rec={learnerRec} /></div>
            <p className="lb-prose" data-text="learner">{learner}</p>
          </>
        ) : null}
      </section>
      <Kv items={[
        ['status', <span className="lb-inline"><span className="lb-mono">{x.status}</span><Badge status={st.status} badge={st.badge} level="research" />{st.openAlso ? <span className="lb-muted">legacy flag “open” also set</span> : null}</span>],
        ['legacy flags', (r.legacyFlags || []).length ? <span className="lb-inline">{r.legacyFlags.map(f => <Tag key={f}>{f}</Tag>)}<span className="lb-muted">{r.legacyLabel ? `v15 ${r.legacyLabel}` : ''}{r.legacyLines ? ` · ${plural(r.legacyLines, 'line')}` : ''}</span></span> : <span className="lb-muted">none</span>],
        ['address', st.address ? <span className="lb-mono lb-wrap">{st.address}</span> : null],
        ['signature', <span className="lb-mono">({x.sig.join(',')}) · grade {x.grade}{st.prime ? ` · prime ${st.prime}` : ''}</span>],
        ['notions', <span className="lb-inline">{(r.notions || []).map(n => <Tag key={n} title={NOTION_INFO[n]}>{n} <span className="lb-muted">{sqWord(n)} · {PRIMES[NOTIONS.indexOf(n)]}</span></Tag>)}</span>],
        ['kind · stage · type', <span>{r.kind || '—'} · {r.stage ? `${r.stage} (${stageName(r.stage)})` : '—'} · {r.ptype || '—'}</span>],
        ['fields', (r.fields || []).join(', ') || null],
        ['phenomena', (r.phenomena || []).join(', ') || null],
        ['cells', (r.cells || []).length ? <span className="lb-mono">{r.cells.join('  ')}</span> : null],
        ...homes,
        ['standard source', r.standardRef],
        ['shown on', (r.shownOn || []).length ? <span className="lb-stack">{r.shownOn.map((s, i) => <span key={i}><span className="lb-mono">{pageLabel(s.page)} › {s.section}</span> <span className="lb-muted">· {s.role} · order {s.order}</span></span>)}</span> : <span className="lb-muted">not on a page</span>],
        ['visible in', (r.visibleTo || []).join(', ')],
        ['since', r.since],
        ['theorems named', (r.theorems || []).length ? <RefList ids={r.theorems} nav={nav} /> : null],
      ]} />

      <section>
        <h4>Evidence {evidence.length ? <span className="lb-muted">({evidence.length})</span> : null}</h4>
        {!evidence.length ? <p className="lb-muted">no evidence attached</p> : (
          <ul className="lb-evidence">
            {evidence.map((e, i) => (
              <li key={i}>
                <div className="lb-inline"><span className="lb-mono">{e.check}</span><Chip dash={e.mode !== 'ran'}>{e.mode}</Chip>
                  {e.script ? <button type="button" className="lb-linkbtn lb-mono" onClick={() => nav.go('checks', { id: e.script })}>{e.script}</button> : <span className="lb-muted">no script named</span>}
                </div>
                {e.statement ? <div className="lb-small">{e.statement}</div> : null}
                <div><RunLine run={e.run} /></div>
              </li>
            ))}
          </ul>
        )}
        {!checks || !runs ? <p className="lb-muted lb-small">loading the checks and their runs…</p> : null}
      </section>

      <section className="lb-two">
        <div>
          <h4>Rests on</h4>
          {out.length ? <dl className="lb-rels">{out.map(([rel, ids]) => <div key={rel}><dt>{rel}</dt><dd><RefList ids={ids} nav={nav} /></dd></div>)}</dl> : <p className="lb-muted">no relation recorded</p>}
        </div>
        <div>
          <h4>Leads to</h4>
          {inn.length ? <dl className="lb-rels">{inn.map(([rel, ids]) => <div key={rel}><dt>{rel}</dt><dd><RefList ids={ids} nav={nav} /></dd></div>)}</dl> : <p className="lb-muted">no row rests on it</p>}
        </div>
      </section>

      {r.review || (r.notesPersona || []).length ? (
        <section>
          {r.review ? <><h4>Review note</h4><p className="lb-prose lb-review">{r.review}</p></> : null}
          {(r.notesPersona || []).length ? <><h4>Notes of the labelling personas</h4><ul className="lb-list">{r.notesPersona.map((n, i) => <li key={i}>{n}</li>)}</ul></> : null}
        </section>
      ) : null}

      {(r.v16 || []).length || r.mergeNeeded ? (
        <section>
          <h4>Wave-3 leads (v16)</h4>
          <ul className="lb-list">{(r.v16 || []).map((v, i) => <li key={i}>{v}</li>)}</ul>
          {r.mergeNeeded ? <p><Chip dash>merge needed</Chip></p> : null}
        </section>
      ) : null}

      <section>
        <h4>Neighbours <span className="lb-muted">(one notion away{neighbours.length ? `: ${neighbours.length}` : ''})</span></h4>
        {neighbours.length ? <RefList ids={neighbours} nav={nav} notes={diff} /> : <p className="lb-muted">none</p>}
      </section>

      {nLensReadings ? (
        <section>
          <h4>Readings by lens <span className="lb-muted">({nLensReadings})</span></h4>
          <Fold summary={`${plural(nLensReadings, 'reading')} in ${plural(byLens.length, 'lens', 'lenses')} (${byLens.map(([l]) => l.name).join(', ')}), each attached by a shared check or by the atlas phrase`} defaultOpen={nLensReadings <= 6}>
            <ul className="lb-list lb-small">
              {byLens.flatMap(([l, list]) => list.map((d, i) => (
                <li key={`${l.key}-${i}`} data-lens={l.key}>
                  <span className="lb-muted">{l.name} →</span> <span className="lb-reading-term"><Rt text={d.term} level={mathLevel} /></span>{' '}
                  <span className="lb-muted">({matchWord(d.match) ? `${matchWord(d.match)} · ` : ''}{d.via === 'evidence' ? `via ${(d.evidence || []).join(', ')}` : <>via the phrase “<Rt text={d.atlas} level={mathLevel} />”</>})</span>
                </li>
              )))}
            </ul>
          </Fold>
        </section>
      ) : null}

      <section>
        <h4>Lens readings <span className="lb-muted">({r.readingRefs || 0})</span></h4>
        {reads && reads.length ? (
          <Fold summary={`${plural(reads.length, 'reading')} naming ${r.splitFrom || r.id}`}>
            <ul className="lb-list lb-small">{reads.map((d, i) => <li key={i}><span className="lb-muted">{d.source} · {d.field}:</span> <Rt text={d.atlas_element} level={mathLevel} /> → <Rt text={d.field_term} level={mathLevel} /> <span className="lb-muted">(<Rt text={d.grade_or_status} level={mathLevel} />)</span></li>)}</ul>
          </Fold>
        ) : reads ? <p className="lb-muted">no reading names this row</p> : null}
      </section>

      {(r.links || []).length || (r.lensTags || []).length ? (
        <Kv items={[['links', (r.links || []).length ? <span className="lb-inline">{r.links.map(l => <Tag key={l}>{l}</Tag>)}</span> : null], ['v15 lens tags', (r.lensTags || []).length ? <span className="lb-inline">{r.lensTags.map(l => <Tag key={l}>{l}</Tag>)}</span> : null]]} />
      ) : null}
      <p className="lb-small"><button type="button" className="lb-linkbtn" onClick={() => nav.go('map', { id: r.id })}>Show {r.id} in the dependency map</button></p>
    </div>
  );
}
