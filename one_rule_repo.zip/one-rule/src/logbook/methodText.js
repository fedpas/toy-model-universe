// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/methodText.js — GENERATED from the build book, verbatim; do not edit by hand (regenerate if the docs change).
// rules: docs/00_README.md "Ground rules for whoever builds this"; statuses, statusIntro, priority: docs/LABELLING_SCHEME.md §6
// (= docs/labelling/SCHEME.md); badgeWords: docs/05_DESIGN_SYSTEM.md §4, the Badge row (kind, shape, research word) and its learner words;
// textStatuses: docs/02_CONTENT_MODEL.md §2, the comment of the field "status" of a text record; draftRule: docs/09_TRANSLATION_PROTOCOL.md §4.
// A few words differ from the docs, for the word rule of shipped text (docs/BUILD_CONTRACTS.md): rules[0] says "the v15/v16 packages" and
// "rephrased", statusIntro "five v15 flags".
export const SOURCES = { rules: "docs/00_README.md · Ground rules", statuses: "docs/LABELLING_SCHEME.md §6 · Derived status", badges: "docs/05_DESIGN_SYSTEM.md §4 · Badge", texts: "docs/02_CONTENT_MODEL.md §2 · status of a text · docs/09_TRANSLATION_PROTOCOL.md §4 · Review and status" };
export const textStatuses = [["human", "the author's words"], ["draft", "a model's words, not yet reviewed"], ["reviewed", "a model's words the author accepted"]];
export const draftRule = "Accepted drafts are written to `texts.json` with `status: \"draft\"`, `source: \"translator:<lens>@<build date>\"`. The register shows drafts with a small \"draft\" mark in the drawer (not in the body); the author flips a draft to `reviewed` (or edits it, which makes it `human`) in the content file. A release may ship drafts; the Logbook's Method tab states how many texts are drafts per lens. Nothing a draft says can change a row's status: status comes from evidence and label only.";
export const rules = [
 "**The information is the author's; the form is new.** Every statement, number, check, source and reading comes from the v15/v16 packages. Nothing is invented, softened, strengthened or dropped. A sentence may be rephrased only through the texts table, with its status marked (`human` if the author wrote it, `draft` if a model did), never in place.",
 "**A page shows what is proved first, and the rest behind a click.** Reasoning data (checks, sampling bounds, logs, scripts, counts, audit lists, dependency graphs) lives in drawers and in the Logbook. The default view of any page is results.",
 "**At most one badge per statement**, and only for what is open, not yet proved by the Atlas, a reading of ours, an input, or new. Statements that are standard and recomputed carry no badge.",
 "**Every statement on a page is a row.** Connective prose (one line that leads from one statement to the next) is allowed and budgeted; a law, a result, a number, a claim is never typed into a component.",
 "**Lenses are a switch, not pages.** Mode (physics | mathematics), level (research | learner) and lens are three independent settings that change the text, the order and the figures of the same rows.",
 "**Learner means no formulas.** A learner page shows only rows that have a learner text; it never falls back to the research text.",
 "**The check scripts are kept exactly as they are** (same files, same ids, same stored results). V2 reads their results; it does not rewrite them.",
 "**Do not guess what the author wants.** Where this book says \"decision for the author\", build the default it names and list the decision in the handover.",
 "**No contact details of any person in any file**; no narration of earlier states in shipped text (the author's `no-history` rule: write what is true now).",
 "**Verify counts.** Every migration step in `03_MIGRATION.md` states the number it must produce. A step that produces another number stops and reports."
];
export const statusIntro = "The five v15 flags are kept as vocabulary but **computed** from the label and the evidence attached to the row:";
export const statuses = [
 [
  "meta",
  "the row is about the Atlas itself (kind meta, notions = {i-meta}); Logbook only, no badge"
 ],
 [
  "proved-by-atlas",
  "a script ran and its check id or log is attached (the v15 `checked` with \"ran / pass\"); shown without a badge"
 ],
 [
  "standard",
  "q > 0 with a source that was read; shown without a badge"
 ],
 [
  "cited",
  "the row names a script or a source as \"read\", not \"ran\": **not yet proved by the Atlas**; badge"
 ],
 [
  "input",
  "r > 0 (the row needs a datum); badge naming the input"
 ],
 [
  "ours",
  "kind = reading; badge"
 ],
 [
  "open",
  "kind ∈ {question, conjecture, pointer}; badge. A `dead-end` or `counterexample` is a settled negative result and takes the status its evidence gives it (no `open` badge)"
 ],
 [
  "new",
  "the row entered or changed in the latest wave (v16: the 26 rows of the wave-3 leads); badge until the next release"
 ]
];
export const priority = "A row shows at most one badge in the default view, in this priority: open > cited > ours > input > new. The full status lives in the row's drawer.";
export const badgeWords = [["open","dashed circle","open"],["cited","hollow square","not yet proved here"],["ours","lamp","our reading"],["input","plug","needs an input: <kind>"],["new","star","new"]];
export const learnerWords = ["not finished","not yet proved here","our idea","we had to choose this","new"];
