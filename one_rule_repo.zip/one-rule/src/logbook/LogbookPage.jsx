// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/LogbookPage.jsx — the Logbook, the researcher layer of the app (docs/06_PAGES.md §/logbook).
// Default export, props { tab }: A's router passes the tab of #/logbook/<tab>. Every tab reads the content tables through
// src/app/content.js; statuses are drawn only by src/components/Badge.jsx.
import { useEffect, useRef, useState } from 'react';
import { useTable, useSettings } from '../app/content.js';
import Register from './Register.jsx';
import Theorems from './Theorems.jsx';
import Checks from './Checks.jsx';
import Replication from './Replication.jsx';
import Leads from './Leads.jsx';
import MatrixTab from './MatrixTab.jsx';
import MapTab from './MapTab.jsx';
import Method from './Method.jsx';
import { Questions, Sources, Reports, Analyses, Candidates } from './Lists.jsx';
import './logbook.css';

export const TABS = [
  ['register', 'Register'], ['theorems', 'Theorems'], ['questions', 'Questions'], ['sources', 'Sources'], ['checks', 'Checks'],
  ['reports', 'Reports'], ['analyses', 'Analyses'], ['leads', 'Leads'], ['candidates', 'Candidates'], ['replication', 'Replication'],
  ['matrix', 'Matrix'], ['map', 'Map'], ['method', 'Method'],
];
const KEYS = TABS.map(t => t[0]);
const ALIASES = { 'dependency-map': 'map', dependencies: 'map', runbook: 'replication', run: 'replication', bench: 'replication' };
const norm = t => { const k = String(t || '').toLowerCase(); return KEYS.includes(k) ? k : ALIASES[k] || 'register'; };

// what another tab asked to open (a row, a theorem, a script…); kept outside the component so it survives a remount by the router
const carry = { target: null, n: 0 };

// the address: #/logbook/<tab>?<settings>&at=<id> (A's links into the Logbook carry at=<id>; ours write it too, so a link can be shared)
function hashParts() {
  try {
    const h = window.location.hash || ''; const qi = h.indexOf('?');
    const segs = (qi < 0 ? h : h.slice(0, qi)).replace(/^#\/?/, '').split('/').filter(Boolean);
    return { h, segs, q: new URLSearchParams(qi < 0 ? '' : h.slice(qi + 1)) };
  } catch { return null; }
}
function setHashTab(t, id) {
  const p = hashParts(); if (!p) return;
  p.q.delete('at'); if (id) p.q.set('at', id);
  const qs = p.q.toString();
  const next = `#/logbook/${t}${qs ? '?' + qs : ''}`;
  try { if (p.h !== next) window.location.hash = next; } catch { /* no window (tests) */ }
}

export default function LogbookPage({ tab }) {
  const settings = useSettings();
  const [pages] = useTable('pages');
  const [cur, setCur] = useState(() => norm(tab));
  const [target, setTarget] = useState(() => { const p = hashParts(); if (!(p && p.q.get('at'))) carry.target = null; return carry.target; });
  useEffect(() => { setCur(norm(tab)); }, [tab]);
  // an address with at=<id> (a link from a page, a shared link, the back button): open that item in its tab
  useEffect(() => {
    const apply = () => {
      const p = hashParts(); if (!p) return;
      const at = p.q.get('at'); if (!at) return;
      const k = p.segs[0] === 'logbook' ? norm(p.segs[1]) : null; if (!k) return;
      if (carry.target && carry.target.id === at && carry.target.tab === k) return;
      carry.n += 1; carry.target = { tab: k, id: at, n: carry.n }; setTarget(carry.target); setCur(k);
    };
    apply();
    window.addEventListener('hashchange', apply);
    return () => window.removeEventListener('hashchange', apply);
  }, []);
  const tabRefs = useRef({});

  const nav = {
    go(t, opts) {
      const k = norm(t);
      if (opts && opts.id) { carry.n += 1; carry.target = { tab: k, id: opts.id, n: carry.n }; setTarget(carry.target); }
      setCur(k); setHashTab(k, opts && opts.id);
      try { window.scrollTo({ top: 0 }); } catch { /* ignore */ }
    },
  };
  const pick = k => { carry.target = null; setTarget(null); setCur(k); setHashTab(k); };
  const onKey = e => {
    const i = KEYS.indexOf(cur); let j = null;
    if (e.key === 'ArrowRight') j = (i + 1) % KEYS.length; else if (e.key === 'ArrowLeft') j = (i - 1 + KEYS.length) % KEYS.length;
    else if (e.key === 'Home') j = 0; else if (e.key === 'End') j = KEYS.length - 1;
    if (j == null) return;
    e.preventDefault(); pick(KEYS[j]); const el = tabRefs.current[KEYS[j]]; if (el) el.focus();
  };
  const page = (pages || []).find(p => p.route === 'logbook');
  const title = (page && page.title && (settings.level === 'learner' ? page.title.learner : page.title[settings.mode])) || 'Logbook';
  const t = target && target.tab === cur ? target : null;
  const props = { nav, target: t, settings };

  return (
    <div className="lb">
      <header className="lb-head">
        <h1>{title}</h1>
        <div className="lb-tabs" role="tablist" aria-label="Logbook" onKeyDown={onKey}>
          {TABS.map(([k, label]) => (
            <button key={k} type="button" role="tab" id={'lb-tab-' + k} aria-selected={cur === k} aria-controls="lb-panel" tabIndex={cur === k ? 0 : -1}
              ref={el => { tabRefs.current[k] = el; }} className={`lb-tab${cur === k ? ' is-on' : ''}`} onClick={() => pick(k)}>{label}</button>
          ))}
        </div>
      </header>
      <section id="lb-panel" role="tabpanel" aria-labelledby={'lb-tab-' + cur} className="lb-panel-main">
        {cur === 'register' ? <Register {...props} /> : null}
        {cur === 'theorems' ? <Theorems {...props} /> : null}
        {cur === 'questions' ? <Questions {...props} /> : null}
        {cur === 'sources' ? <Sources {...props} /> : null}
        {cur === 'checks' ? <Checks {...props} /> : null}
        {cur === 'reports' ? <Reports {...props} /> : null}
        {cur === 'analyses' ? <Analyses {...props} /> : null}
        {cur === 'leads' ? <Leads {...props} /> : null}
        {cur === 'candidates' ? <Candidates {...props} /> : null}
        {cur === 'replication' ? <Replication {...props} /> : null}
        {cur === 'matrix' ? <MatrixTab {...props} /> : null}
        {cur === 'map' ? <MapTab {...props} /> : null}
        {cur === 'method' ? <Method {...props} /> : null}
      </section>
    </div>
  );
}
