// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/registerModel.js — the Logbook's data functions (pure ES module: no React, no DOM).
// The Logbook tabs compute everything they show with these functions, and tests/logbook.test.mjs runs the same
// functions on content/*.json, so the counts in the register's filters are tested, not trusted.

// ---- vocabulary of the labelling (docs/LABELLING_SCHEME.md; the same lists as tools/build_content.mjs) ----------------
export const NOTIONS = ['lbl', 'sgn', 'sq', 'grd', 'qf', 'clk', 'mir', 'nul', 'tns', 'mod', 'biv', 'cnx', 'var', 'sol', 'lat', 'fin', 'div', 'dyn', 's-alg', 's-geo', 's-phy', 's-cat', 'src', 'i-chart', 'i-time', 'i-J', 'i-act', 'i-tab', 'i-meta'];
export const PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109];
/** the square of a notion: +1 supplied by the rule, −1 imported from the literature, 0 an input */
export const SQ = n => (n.startsWith('i-') ? 0 : (n.startsWith('s-') || n === 'src') ? -1 : 1);
// "the notion" column of the table in docs/LABELLING_SCHEME.md §1, verbatim (used as tooltips of the notion filter)
export const NOTION_INFO = {
  lbl: 'labels as bit masks, XOR, popcount, the group ℤ₂ⁿ, blades as subsets, the Cube/Simplex/Prime views of a label',
  sgn: 'the sign cocycle s(a,b), reordering parity, associativity, the gauge of the sign, cochains that are not cocycles (octonion sign)',
  sq: 'the squares ε of the generators, the signature (p,q,r), the cell Cl(p,q,r), Spatial/Temporal convention, which generator is "space" or "time" as algebra',
  grd: 'grade, parity π, the even subalgebra, filtration, Λ as associated graded, pseudoscalar/volume element',
  qf: 'the label form Q and its polar form, O(Q) over 𝔽₂, isometry classes of triples (V,Q,π), Witt index, totally singular subspaces',
  clk: 'the ℤ₄ form w = π + 2Q, the Gauss sum, the clock c = p − q mod 8, the type table ℝ/ℂ/ℍ and doubled types, Brown invariant, Frobenius–Schur count',
  mir: 'the mirror Cl(p,q) ↔ Cl(q,p), reversion, Clifford conjugation, the dagger, the top-blade Frobenius form, states/positivity',
  nul: 'null generators, the radical J, Loewy layers, super-centre, exterior algebra, forms and d as the null bit rule, paired nulls vs null generators',
  tns: 'doubling, graded tensor product, periodicity, Cl(n,n) = End(Λ), Morita/Azumaya, base change to Λ(ℝʳ), halving/face/complement moves',
  mod: 'modules, spinors, ideals, Peirce idempotents, Fock space and CAR, ladder operators, projectors, the Born rule',
  biv: 'bivectors, commutators, Lie algebras so(p,q) and their subalgebras, rotors/versors, the trinity of bivector squares (rotation/boost/translation), Cartan–Dieudonné, invariant decomposition',
  cnx: 'connection, curvature, torsion, Bianchi identities, covariant derivative, the Einstein form, local Lorentz covariance, the extra generator (projective/conformal reading), horizon generators',
  var: 'Euler–Lagrange forms, first variation, Noether identities, stress and spin forms, currents, charge conservation (computed by the engine once an action is given)',
  sol: 'exact solutions and series computed on the engine: Kerr–Schild frames, FRW series, plane waves, surface gravity, Komar/Smarr, weak-field limit, perihelion, deviation',
  lat: 'lattices and root systems: I_{p,q}, E_n = k^⊥, Gosset polytopes, orthoplex/demicube/cube counts, W(E_n) mod 2, van der Blij',
  fin: 'finite structures: codes (Hamming, Golay), Steiner systems, O(Q)(𝔽₂) as a group, transvections, quadrics, Peres–Mermin, label symmetry groups',
  div: 'division algebras on labels: octonions as a cochain, Fano plane, G₂, triality, Cayley–Dickson, composition',
  dyn: 'mechanics on the engine: forque, rigid bodies, PGA flows, springs and Walsh modes, signed networks, Floquet bands, Kepler through Fock',
  's-alg': 'standard algebra recalled or compared: Brauer–Wall (Wall), Hurwitz, Wood, Dieudonné, Nakayama/Skowroński–Yamagata, Lundholm–Svensson type table, representation type (Wang, Ladkani), Hochschild',
  's-geo': "standard geometry and relativity: the Christoffel route, Schwarzschild/Kerr/RN/KN/FRW, Birkhoff, first law, Petrov, Weyl, MacDowell–Mansouri, Cartan geometry, Wald's identity, Pin⁻ bordism / ABK",
  's-phy': "standard physics: Maxwell, Lorentz force, Dirac, Yang–Mills, Einstein–Cartan, Belinfante, Hehl–Datta, the Standard Model content, Floquet–Bloch, Kitaev / Fidkowski–Kitaev classes, Wigner's little group",
  's-cat': 'standard category theory and topology: sVec, Frobenius algebras, monoidal categories, nerves, incidence algebras, simplicial complexes, cohomology H², Koszul sign',
  src: "a specific researcher's text compared line by line: Furey, Baez, Schuller, Hestenes / Lasenby–Doran–Gull, Dorst / De Keninck / Gunn, Roelfs–Eelbode, Tian, Majkić, Pumplün, Hsu–Barker–Hobson–Lasenby, Vollick",
  'i-chart': 'a chart, coordinates, a frame class, the flat derivative ∇, units and constants with dimensions',
  'i-time': 'a time orientation / which generator is time / the sign convention of the signature taken as a datum / the direction of a flow',
  'i-J': 'a complex structure J, the "i", an involution chosen, a Witt split or vacuum chosen, the grade a field lives in',
  'i-act': 'a postulated equation or action (Maxwell, Dirac, coupling, Yang–Mills, matter, gravity, a force law), the coupling κ, the sign of the source, Λ, the constitutive relation',
  'i-tab': "an outside table or labelling: the octonion multiplication table, SM labels and hypercharges, Furey's partition, a paper's positions or Fig. 1, JPL ephemerides, the role names of the cards",
  'i-meta': 'nothing of the algebra: the statement is about the Atlas itself (its pages, scripts, counts, method, credit, open lists)',
};
export const STAGES = [['A', 'algebra'], ['K', 'kinematics'], ['F', 'fields'], ['D', 'dynamics'], ['O', 'observation'], ['M', 'method']];
export const KIND_ORDER = ['definition', 'construction', 'lemma', 'theorem', 'range', 'classification', 'invariant', 'example', 'counterexample', 'computation', 'reduction', 'reading', 'conjecture', 'question', 'dead-end', 'pointer', 'meta'];
export const FIELD_ORDER = ['algebra', 'geometry', 'topology', 'category', 'combinatorics', 'analysis'];
export const STATUS_ORDER = ['proved-by-atlas', 'standard', 'cited', 'ours', 'input', 'open', 'meta', 'candidate'];
export const RELS = ['derives', 'equiv', 'instance', 'uses-input', 'cycle', 'contradicts'];
/** the status of a text record (docs/02_CONTENT_MODEL.md §2): human (the author's words), draft, reviewed (a model's words) */
export const TEXT_STATUSES = ['human', 'draft', 'reviewed'];
/** the values of the register's filter "learner text": none, or the status of the row's learner text */
export const LEARNER_ORDER = ['none', ...TEXT_STATUSES];
/** the relations that make "rests on / leads to" (docs/04_LABELLING.md §6) */
export const DIRECTED_RELS = ['derives', 'instance', 'uses-input'];
export const PAGE_SIZE = 50;

const rank = list => { const m = new Map(list.map((k, i) => [k, i])); return k => (m.has(k) ? m.get(k) : list.length); };
export const kindRank = rank(KIND_ORDER), stageRank = rank(STAGES.map(s => s[0])), statusRank = rank(STATUS_ORDER), fieldRank = rank(FIELD_ORDER);

export const pageLabel = route => (route === '' ? '/' : route == null ? '—' : route);
export const excerpt = (text, n = 120) => { const t = String(text || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n).trimEnd() + '…' : t; };
export const signatureOf = notions => { const s = [0, 0, 0]; for (const n of notions || []) s[SQ(n) === 1 ? 0 : SQ(n) === -1 ? 1 : 2]++; return s; };
export const maskOf = notions => (notions || []).reduce((m, n) => (NOTIONS.indexOf(n) >= 0 ? m | (1 << NOTIONS.indexOf(n)) : m), 0);
export const notionsOfMask = mask => NOTIONS.filter((_, i) => mask & (1 << i));
export const sqWord = n => (SQ(n) === 1 ? '+1' : SQ(n) === -1 ? '−1' : '0');

// ---- texts: the lookup order of docs/02_CONTENT_MODEL.md §2 ----------------------------------------------------------
/** returns (rowId, {mode, level, lens}) → the text record | null, with the fallback (mode, level, lens) → (both, level, lens) → (mode, level, null) → (both, level, null) */
export function makeTextRecordLookup(texts) {
  const by = new Map();
  for (const t of texts || []) {
    if ((t.lang || 'en') !== 'en' || (t.register && t.register !== 'full')) continue;
    const k = `${t.row}|${t.mode || 'both'}|${t.level}|${t.lens ?? ''}`;
    if (!by.has(k)) by.set(k, t);
  }
  return (id, { mode = 'both', level = 'research', lens = null } = {}) => {
    const L = lens ?? '';
    return by.get(`${id}|${mode}|${level}|${L}`) ?? by.get(`${id}|both|${level}|${L}`) ?? by.get(`${id}|${mode}|${level}|`) ?? by.get(`${id}|both|${level}|`) ?? null;
  };
}
/** returns (rowId, {mode, level, lens}) → body | null (the same records as makeTextRecordLookup) */
export function makeTextLookup(texts) {
  const rec = makeTextRecordLookup(texts);
  return (id, opts) => { const t = rec(id, opts); return t ? t.body : null; };
}
/** the status of a text record as the register files it: its status word, 'none' when there is no record */
export const textStatusOf = rec => (rec ? String(rec.status || 'unknown') : 'none');
/** the mark a text carries in the row drawer: 'draft' or 'reviewed' (a model's words); none for the author's own words */
export const textMark = rec => (rec && (rec.status === 'draft' || rec.status === 'reviewed') ? rec.status : null);

// ---- the register ---------------------------------------------------------------------------------------------------
/** one entry per row: the row, its derived status record, signature, mask, pages, research and learner text records and a search blob */
export function buildRegister({ rows, status, texts, mode = 'phys', lens = null }) {
  const lookRec = makeTextRecordLookup(texts);
  return (rows || []).map(r => {
    const st = (status && status[r.id]) || null;
    const pages = [...new Set((r.shownOn || []).map(s => s.page))];
    const researchRec = lookRec(r.id, { mode, level: 'research', lens });
    const learnerRec = lookRec(r.id, { mode, level: 'learner', lens });
    const text = (researchRec && researchRec.body) || '';
    const learner = learnerRec ? learnerRec.body : null;
    const ev = (r.evidence || []).flatMap(e => [e.check, e.script]);
    const blob = [r.id, r.group, r.kind, r.stage, r.ptype, ...(r.fields || []), ...(r.phenomena || []), ...(r.notions || []), ...pages.map(pageLabel), ...(r.shownOn || []).map(s => s.section),
      r.homePhys, r.homeMath, r.standardRef, ...ev, ...(r.links || []), ...(r.theorems || []), r.review, text].filter(Boolean).join(' \u0001 ').toLowerCase();
    return {
      id: r.id, row: r, st, status: st ? st.status : 'unknown',
      sig: st && Array.isArray(st.signature) ? st.signature : signatureOf(r.notions),
      mask: st && typeof st.mask === 'number' ? st.mask : maskOf(r.notions),
      grade: st && typeof st.grade === 'number' ? st.grade : (r.notions || []).length,
      pages, text, learner, researchRec, learnerRec, learnerStatus: textStatusOf(learnerRec), isNew: st ? !!st.new : r.since === 'v16',
      hasReview: typeof r.review === 'string' && r.review.trim() !== '', blob,
    };
  });
}

export function emptyFilters() {
  return { q: '', status: new Set(), learner: new Set(), page: new Set(), group: new Set(), kind: new Set(), stage: new Set(), field: new Set(), notion: new Set(), notionMode: 'all', sig: 'any', isNew: false, review: false };
}
export function activeFilterCount(F) {
  let n = 0; for (const k of ['status', 'learner', 'page', 'group', 'kind', 'stage', 'field', 'notion']) if (F[k] && F[k].size) n++;
  return n + (F.sig !== 'any') + !!F.isNew + !!F.review + !!(F.q && F.q.trim());
}

/** within a facet the chosen values are alternatives (or); facets combine with and; notions: all of / any of; search: every word */
export function filterRows(reg, F) {
  const has = s => s && s.size > 0;
  const words = (F.q || '').trim().toLowerCase().split(/\s+/).filter(Boolean);
  let nm = 0; if (has(F.notion)) for (const n of F.notion) { const i = NOTIONS.indexOf(n); if (i >= 0) nm |= 1 << i; }
  return reg.filter(x => {
    const r = x.row;
    if (has(F.status) && !F.status.has(x.status)) return false;
    if (has(F.learner) && !F.learner.has(x.learnerStatus)) return false;
    if (has(F.page) && !x.pages.some(p => F.page.has(p))) return false;
    if (has(F.group) && !F.group.has(r.group)) return false;
    if (has(F.kind) && !F.kind.has(r.kind)) return false;
    if (has(F.stage) && !F.stage.has(r.stage)) return false;
    if (has(F.field) && !(r.fields || []).some(f => F.field.has(f))) return false;
    if (nm && (F.notionMode === 'any' ? (x.mask & nm) === 0 : (x.mask & nm) !== nm)) return false;
    if (F.sig === 'r0' && x.sig[2] !== 0) return false;
    if (F.sig === 'rpos' && !(x.sig[2] > 0)) return false;
    if (F.isNew && !x.isNew) return false;
    if (F.review && !x.hasReview) return false;
    if (words.length && !words.every(w => x.blob.includes(w))) return false;
    return true;
  });
}

/** the counts printed next to every filter value: over all rows (a row counts once per value it carries) */
export function facetCounts(reg) {
  const c = { total: reg.length, status: {}, learner: {}, page: {}, group: {}, kind: {}, stage: {}, field: {}, notion: {}, sig: { r0: 0, rpos: 0 }, new: 0, review: 0 };
  const inc = (m, k) => { m[k] = (m[k] || 0) + 1; };
  for (const x of reg) {
    const r = x.row;
    inc(c.status, x.status); inc(c.learner, x.learnerStatus); for (const p of x.pages) inc(c.page, p);
    inc(c.group, r.group); inc(c.kind, r.kind); inc(c.stage, r.stage);
    for (const f of new Set(r.fields || [])) inc(c.field, f);
    for (const n of new Set(r.notions || [])) inc(c.notion, n);
    if (x.sig[2] === 0) c.sig.r0++; else c.sig.rpos++;
    if (x.isNew) c.new++; if (x.hasReview) c.review++;
  }
  return c;
}

export const SORTS = [['id', 'id'], ['page', 'page order'], ['stage', 'stage, then page order'], ['kind', 'kind, then field'], ['grade', 'grade (number of notions)'], ['status', 'status']];
/** pageOrder: the routes of pages.json in their order (optional) */
export function sortRows(list, key = 'id', pageOrder = []) {
  if (key === 'id') return list;
  const pr = rank(pageOrder);
  const first = x => (x.row.shownOn && x.row.shownOn[0]) || {};
  const byPage = (a, b) => pr(first(a).page) - pr(first(b).page) || String(first(a).section).localeCompare(String(first(b).section)) || (first(a).order ?? 0) - (first(b).order ?? 0);
  const cmp = {
    page: byPage,
    stage: (a, b) => stageRank(a.row.stage) - stageRank(b.row.stage) || byPage(a, b),
    kind: (a, b) => kindRank(a.row.kind) - kindRank(b.row.kind) || fieldRank((a.row.fields || [])[0]) - fieldRank((b.row.fields || [])[0]),
    grade: (a, b) => a.grade - b.grade,
    status: (a, b) => statusRank(a.status) - statusRank(b.status),
  }[key];
  return cmp ? list.map((x, i) => [x, i]).sort((a, b) => cmp(a[0], b[0]) || a[1] - b[1]).map(p => p[0]) : list;
}

// ---- relations ------------------------------------------------------------------------------------------------------
/** id → [{id: the row that depends on it, rel}] (the "leads to" side) */
export function dependentsIndex(rows) {
  const m = new Map();
  for (const r of rows || []) for (const d of r.depends || []) { if (!m.has(d.id)) m.set(d.id, []); m.get(d.id).push({ id: r.id, rel: d.rel }); }
  return m;
}
export function groupByRel(edges) {
  const g = {}; for (const e of edges || []) (g[e.rel] ||= []).includes(e.id) || g[e.rel].push(e.id);
  return RELS.filter(k => g[k]).map(k => [k, g[k]]).concat(Object.keys(g).filter(k => !RELS.includes(k)).map(k => [k, g[k]]));
}
/** the kind of an id named in a relation */
export const refKind = id => (/^T\d{1,2}$/.test(id) ? 'theorem' : /^Q[A-Z]\d+$/.test(id) ? 'question' : String(id).includes('·') ? 'check' : 'row');

/** the rests-on (left) and leads-to (right) graph of a row, `depth` levels each way, over the chosen relations */
export function rowGraph(id, rowsById, dependents, rels = DIRECTED_RELS, depth = 2, cap = 40) {
  const R = new Set(rels); const placed = new Map([[id, 0]]); const cols = { 0: [id] }; const edges = [];
  const out = x => ((rowsById.get(x) || {}).depends || []).filter(d => R.has(d.rel)).map(d => ({ id: d.id, rel: d.rel }));
  const inn = x => (dependents.get(x) || []).filter(d => R.has(d.rel));
  for (const [dir, next] of [[-1, out], [1, inn]]) {
    let frontier = [id];
    for (let k = 1; k <= depth; k++) {
      const col = []; const lvl = dir * k;
      for (const a of frontier) for (const e of next(a)) {
        if (!placed.has(e.id)) { placed.set(e.id, lvl); col.push(e.id); }
        if (placed.get(e.id) === lvl) edges.push(dir < 0 ? { from: a, to: e.id, rel: e.rel } : { from: e.id, to: a, rel: e.rel });
      }
      cols[lvl] = col; frontier = col;
    }
  }
  const shown = {}; const hidden = {};
  for (const [k, v] of Object.entries(cols)) { shown[k] = v.slice(0, cap); hidden[k] = Math.max(0, v.length - cap); }
  const vis = new Set(Object.values(shown).flat());
  const seen = new Set();
  return { cols: shown, all: cols, hidden, edges: edges.filter(e => vis.has(e.from) && vis.has(e.to) && !seen.has(`${e.from}|${e.to}|${e.rel}`) && seen.add(`${e.from}|${e.to}|${e.rel}`)) };
}

// ---- checks and their runs ----------------------------------------------------------------------------------------
/** script → its last run: the record with the latest date; on equal dates the later record (as tools/build_content.mjs) */
export function lastRunIndex(runs) {
  const last = {};
  for (const r of runs || []) if (r.script) { const k = r.script; if (!last[k] || r.date >= last[k].date) last[k] = r; }
  return last;
}
/** the last run of a script named in a row or a lead: the full path, else the first run whose script ends with /basename (as build_content.mjs) */
export function runFor(last, s) {
  if (!s || !last) return null;
  const k = s.startsWith('checks/') ? s : 'checks/' + s;
  if (last[k]) return last[k];
  const base = '/' + s.split('/').pop();
  return Object.values(last).find(x => x.script.endsWith(base)) || null;
}
export const familyTop = c => String((c && c.family) || 'other').split('/')[0];
export const runPassed = run => (run ? run.passed === true : null);

/** indexes of checks.json: by script path, by basename without extension, by check id (with the id's statement) */
export function checksIndex(checks) {
  const byScript = new Map(), byBase = new Map(), byId = new Map();
  for (const c of checks || []) {
    if (c.script) { byScript.set(c.script, c); const b = c.script.split('/').pop().replace(/\.(py|mjs|js|sh|html)$/, ''); if (!byBase.has(b)) byBase.set(b, c); }
    for (const i of c.ids || []) if (!byId.has(i.id)) byId.set(i.id, { check: c, statement: i.statement });
  }
  return { byScript, byBase, byId };
}
/** a row's evidence with the check record, the check id's statement and the last run, one line per (script, check, mode) */
export function resolveEvidence(row, cidx, last) {
  const out = [], seen = new Set();
  for (const e of (row && row.evidence) || []) {
    const base = e.script ? e.script.split('/').pop().replace(/\.(py|mjs|js|sh|html)$/, '') : null;
    const idHit = cidx && e.check ? cidx.byId.get(e.check) : null;
    const rec = cidx ? ((e.script && (cidx.byScript.get(e.script.startsWith('checks/') ? e.script : 'checks/' + e.script) || cidx.byBase.get(base))) || (idHit && idHit.check) || cidx.byBase.get(e.check) || null) : null;
    const run = e.script ? runFor(last, e.script) : rec ? (last && last[rec.script]) || null : runFor(last, e.check);
    const key = `${rec ? rec.script : e.script || ''}|${e.check}|${e.mode}`;
    if (seen.has(key)) continue; seen.add(key);
    out.push({ check: e.check, script: rec ? rec.script : e.script, named: e.script, mode: e.mode, rec, statement: idHit ? idHit.statement : null, run });
  }
  return out;
}

// ---- readings that name a row or a theorem (the rule of atlas_work/enrich_matrix.py that produced rows.readingRefs) ----
const rx = id => new RegExp('\\b' + id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b');
const readingBlob = d => [d.atlas_element, d.note, d.field_term].map(v => String(v ?? '')).join(' ');
/** the readings whose text names the row (a split row "X-012b" is named through "X-012", as its readingRefs count) */
export function readingsForRow(row, readings) { const re = rx((row && (row.splitFrom || row.id)) || ''); return (readings || []).filter(d => re.test(readingBlob(d))); }
export function readingsForTheorem(id, readings) { const re = new RegExp('\\b' + id + '\\b(?!\\d)'); return (readings || []).filter(d => re.test(readingBlob(d))); }

// ---- the translation matrix -----------------------------------------------------------------------------------------
export function matrixCounts(matrix) {
  const c = { E: 0, S: 0, A: 0, cells: 0, rowsWithoutCell: 0, rows: 0, columns: 0 };
  if (!matrix) return c;
  c.rows = (matrix.rows || []).length; c.columns = (matrix.columns || []).length;
  for (const r of matrix.rows || []) { const cs = Object.values(r.cells || {}); if (!cs.length) c.rowsWithoutCell++; for (const x of cs) { c.cells++; if (x.grade in c) c[x.grade]++; } }
  return c;
}

// ---- the dependency map of pages ------------------------------------------------------------------------------------
/** levels = the longest chain of needs (pages.json); pages with no need and needed by none are listed apart */
export function pageLayers(pages) {
  const by = new Map((pages || []).map(p => [p.route, p]));
  const level = new Map(); const visiting = new Set();
  const L = r => {
    if (level.has(r)) return level.get(r);
    if (visiting.has(r)) return 0; visiting.add(r);
    const n = ((by.get(r) || {}).needs || []).filter(x => by.has(x));
    const v = n.length ? 1 + Math.max(...n.map(L)) : 0; visiting.delete(r); level.set(r, v); return v;
  };
  const neededBy = new Map();
  for (const p of pages || []) for (const n of p.needs || []) { if (!neededBy.has(n)) neededBy.set(n, []); neededBy.get(n).push(p.route); }
  const linked = [], isolated = [];
  for (const p of pages || []) ((p.needs || []).length || neededBy.has(p.route) ? linked : isolated).push(p.route);
  linked.forEach(L);
  const layers = [];
  for (const r of linked) (layers[level.get(r)] ||= []).push(r);
  const stepNo = r => ((by.get(r) || {}).stepNo ?? 99);
  for (const l of layers) l && l.sort((a, b) => stepNo(a) - stepNo(b) || a.localeCompare(b));
  const edges = []; for (const r of linked) for (const n of (by.get(r) || {}).needs || []) if (by.has(n)) edges.push({ from: r, to: n });
  return { level, layers: layers.map(l => l || []), edges, isolated, neededBy };
}
/** needs.json is keyed by v15 tab; the route of a tab is where most rows of that tab are shown (rows.tabV15 → shownOn.page) */
export function tabRoutes(rows) {
  const m = new Map();
  for (const r of rows || []) for (const s of r.shownOn || []) { const t = r.tabV15; if (!t) continue; if (!m.has(t)) m.set(t, new Map()); const c = m.get(t); c.set(s.page, (c.get(s.page) || 0) + 1); }
  const out = new Map(); for (const [t, c] of m) out.set(t, [...c].sort((a, b) => b[1] - a[1])[0][0]);
  return out;
}

// ---- leads ----------------------------------------------------------------------------------------------------------
/** proposed edits grouped by the row they change, rows in id order */
export function editsByRow(edits) {
  const m = new Map();
  for (const e of edits || []) for (const r of e.rows || []) { if (!m.has(r)) m.set(r, []); m.get(r).push(e); }
  return [...m].sort((a, b) => a[0].localeCompare(b[0]));
}
export const listOf = v => (Array.isArray(v) ? v : v && typeof v === 'object' ? Object.keys(v).sort((a, b) => +a - +b).map(k => v[k]) : v ? [v] : []);

// ---- the Method tab: texts by status, readings by lens ---------------------------------------------------------------
const levelRank = rank(['research', 'learner']);
/**
 * the text records counted by status, one line per (level, lens): { statuses, rows: [{ level, lens, counts: {status: n}, total }], total }.
 * Lines without a lens come first (research, then learner), then the lenses in alphabetical order; statuses outside the
 * three words of TEXT_STATUSES are appended in the order met.
 */
export function textStatusCounts(texts) {
  const statuses = [...TEXT_STATUSES];
  const groups = new Map();
  for (const t of texts || []) {
    const s = textStatusOf(t);
    if (!statuses.includes(s)) statuses.push(s);
    const level = String(t.level || '');
    const lens = t.lens || null;
    const k = `${level}\u0001${lens || ''}`;
    if (!groups.has(k)) groups.set(k, { level, lens, counts: {}, total: 0 });
    const g = groups.get(k);
    g.counts[s] = (g.counts[s] || 0) + 1; g.total++;
  }
  for (const level of ['research', 'learner']) if (!groups.has(`${level}\u0001`)) groups.set(`${level}\u0001`, { level, lens: null, counts: {}, total: 0 });
  const rows = [...groups.values()].sort((a, b) => (a.lens ? 1 : 0) - (b.lens ? 1 : 0) || String(a.lens || '').localeCompare(String(b.lens || ''))
    || levelRank(a.level) - levelRank(b.level) || a.level.localeCompare(b.level));
  const total = { counts: {}, total: 0 };
  for (const g of rows) { for (const [s, n] of Object.entries(g.counts)) total.counts[s] = (total.counts[s] || 0) + n; total.total += g.total; }
  return { statuses, rows, total };
}

/** the readings of content/lens_readings.json per lens, in the order of the lens registry (lenses.json): { key, name, kind, records, rows } */
export function lensReadingCounts(records, lenses) {
  const by = new Map();
  for (const r of Array.isArray(records) ? records : []) {
    if (!r || !r.lens) continue;
    if (!by.has(r.lens)) by.set(r.lens, { records: 0, rows: new Set() });
    const b = by.get(r.lens); b.records++; if (r.row) b.rows.add(r.row);
  }
  const out = (lenses || []).map(l => { const b = by.get(l.key); return { key: l.key, name: l.name || l.key, kind: l.kind || null, records: b ? b.records : 0, rows: b ? b.rows.size : 0, registered: true }; });
  for (const [key, b] of by) if (!out.some(o => o.key === key)) out.push({ key, name: key, kind: null, records: b.records, rows: b.rows.size, registered: false });
  return out;
}

// ---- the Replication tab: the runbook (content/runbook.json) and the last run of every script ------------------------
/** a script path written from the folder checks/ (the runbook's way; checks.json writes "checks/…") */
export const relScript = s => String(s || '').replace(/^checks\//, '');
/** the scripts a runbook entry names ("peirce_test.py, witt_test.py, z2_test.py" names three) */
export const runbookParts = e => String((e && e.script) || '').split(',').map(s => s.trim()).filter(Boolean);
const baseNoExt = p => String(p || '').split('/').pop().replace(/\.(py|mjs|js|sh|html)$/, '');
/** the group of a script: its folder under checks/ (each subfolder of selfcheck/ is a group of its own; '' is checks/ itself) */
export function scriptGroup(p) {
  const rel = relScript(p);
  const segs = rel.split('/').filter(Boolean);
  if (!rel.endsWith('/')) segs.pop(); // the file name ("replication/" names a folder)
  if (!segs.length) return '';
  return segs[0] === 'selfcheck' && segs.length > 1 ? `selfcheck/${segs[1]}` : segs[0];
}
export const groupTitle = g => `checks/${g ? g + '/' : ''}`;

/**
 * The list of the Replication tab. First every entry of the runbook, in its order, with its command exactly as recorded;
 * then every script of checks.json that no entry names, with the command of its check record if it has one, else none.
 * A part of an entry is matched to its check record by path, else by file name (the rule by which the rows' evidence is
 * resolved), and carries the last run of that script. Groups are folders, in the order the runbook lists them, then the
 * other folders in the order of checks.json. Nothing here writes a command: `command` is a field of a table or null.
 */
export function runbookModel({ runbook, checks, runs }) {
  const cidx = checksIndex(checks);
  const last = lastRunIndex(runs);
  const covered = new Map(); // check record → key of the runbook item that names it (two records may share a script path)
  const items = [];
  (Array.isArray(runbook) ? runbook : []).forEach((e, i) => {
    const parts = runbookParts(e).map(path => {
      const rec = cidx.byScript.get('checks/' + path) || cidx.byBase.get(baseNoExt(path)) || null;
      const run = rec ? last[rec.script] || null : runFor(last, path);
      return { path, rec, run, recordedAs: rec && relScript(rec.script) !== path ? relScript(rec.script) : null };
    });
    const key = `runbook:${i}`;
    for (const p of parts) if (p.rec && !covered.has(p.rec)) covered.set(p.rec, key);
    const rec0 = parts.length ? parts[0].rec : null;
    items.push({
      key, source: 'runbook', index: i, group: scriptGroup(parts.length ? parts[0].path : e.script), script: String(e.script || ''), parts,
      what: e.what || (rec0 && rec0.what) || null, prints: e.checks || null,
      command: typeof e.command === 'string' && e.command.trim() ? e.command : null, commandFrom: typeof e.command === 'string' && e.command.trim() ? 'runbook' : null,
      deps: (rec0 && rec0.deps) || null, family: (rec0 && rec0.family) || null,
    });
  });
  (Array.isArray(checks) ? checks : []).forEach((c, i) => {
    if (!c || !c.script || covered.has(c)) return;
    const own = typeof c.command === 'string' && c.command.trim() ? c.command : null;
    items.push({
      key: `checks:${i}`, source: 'checks', index: i, group: scriptGroup(c.script), script: relScript(c.script),
      parts: [{ path: relScript(c.script), rec: c, run: last[c.script] || null, recordedAs: null }],
      what: c.what || null, prints: null, command: own, commandFrom: own ? 'checks' : null, deps: c.deps || null, family: c.family || null,
    });
  });
  const order = [];
  for (const it of items) if (!order.includes(it.group)) order.push(it.group);
  // per folder, counted in scripts (an entry may name several): how many, how many with a command, how many whose last run passed
  const groups = order.map(g => {
    const list = items.filter(it => it.group === g);
    const parts = list.flatMap(it => it.parts.map(p => ({ p, it })));
    return {
      key: g, title: groupTitle(g), items: list, scripts: parts.length,
      withCommand: parts.filter(x => x.it.command).length, runs: parts.filter(x => x.p.run).length, passed: parts.filter(x => x.p.run && x.p.run.passed === true).length,
    };
  });
  // totals: over the check records of checks.json ("scripts", as the Checks tab counts them) and the runs of check_runs.json
  const withCommand = new Set();
  for (const it of items) if (it.command) for (const p of it.parts) if (p.rec) withCommand.add(p.rec);
  const L = Object.values(last);
  const dates = L.map(r => r.date).filter(Boolean).sort();
  const nScripts = Array.isArray(checks) ? checks.length : 0;
  const totals = {
    entries: Array.isArray(runbook) ? runbook.length : 0,
    scripts: nScripts,
    withCommand: withCommand.size,
    withoutCommand: nScripts - withCommand.size,
    itemsWithCommand: items.filter(it => it.command).length,
    itemsWithout: items.filter(it => !it.command).length,
    runs: Array.isArray(runs) ? runs.length : 0,
    lastRuns: L.length,
    passed: L.filter(r => r.passed === true).length,
    notPassed: L.filter(r => r.passed !== true).sort((a, b) => String(a.script).localeCompare(String(b.script))),
    ok: L.reduce((a, r) => a + (typeof r.ok === 'number' ? r.ok : 0), 0),
    fail: L.reduce((a, r) => a + (typeof r.fail === 'number' ? r.fail : 0), 0),
    counted: L.filter(r => typeof r.ok === 'number' || typeof r.fail === 'number').length,
    firstDate: dates[0] || null, lastDate: dates[dates.length - 1] || null,
  };
  return { items, groups, totals, covered };
}
/** does a runbook item match the words of a search (every word, in its script, text, command or recorded paths)? */
export function runbookMatch(it, q) {
  const words = String(q || '').trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (!words.length) return true;
  const blob = [it.script, it.what, it.prints, it.command, it.deps, it.family, groupTitle(it.group), ...it.parts.flatMap(p => [p.path, p.recordedAs, p.run && p.run.status])].filter(Boolean).join(' \u0001 ').toLowerCase();
  return words.every(w => blob.includes(w));
}

// ---- the Candidates tab ----------------------------------------------------------------------------------------------
export const CHECKABLE_ORDER = ['yes', 'partly', 'no'];
/** the counts next to the candidates' filters: by field and by checkable, over all candidates */
export function candidateFacets(cands) {
  const c = { total: 0, field: {}, checkable: {} };
  for (const x of Array.isArray(cands) ? cands : []) {
    c.total++;
    const f = x.field || '—', k = x.checkable || '—';
    c.field[f] = (c.field[f] || 0) + 1; c.checkable[k] = (c.checkable[k] || 0) + 1;
  }
  return c;
}
/** the candidates shown for a field ('all' or a field), a checkable value ('all' or yes/partly/no) and the words of a search */
export function filterCandidates(cands, { field = 'all', checkable = 'all', q = '' } = {}) {
  const words = String(q || '').trim().toLowerCase().split(/\s+/).filter(Boolean);
  return (Array.isArray(cands) ? cands : []).filter(x => {
    if (field !== 'all' && (x.field || '—') !== field) return false;
    if (checkable !== 'all' && (x.checkable || '—') !== checkable) return false;
    if (!words.length) return true;
    const blob = [x.id, x.title, x.statement, x.field, x.source, x.checkNote, ...(x.linksRows || []), ...(x.proposedBy || []), ...(x.notions || [])].filter(Boolean).join(' \u0001 ').toLowerCase();
    return words.every(w => blob.includes(w));
  });
}
/** where a row is shown first (the shownOn entry with the lowest order, as the pages link a row), or null */
export function rowHomeOf(row) {
  const so = [...((row && row.shownOn) || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0];
  return so ? { page: so.page, section: so.section || null } : null;
}
