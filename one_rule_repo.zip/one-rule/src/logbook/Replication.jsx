// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/Replication.jsx — how to run the checks again: every entry of content/runbook.json (what it checks, what a run
// prints, the command exactly as recorded), then every other script of content/checks.json ("no command recorded"), grouped by
// folder in the runbook's order, each script with its last run from content/check_runs.json; the totals above them, and the
// replication kit and the label bench as their check records state them. The list is runbookModel() of registerModel.js, the
// function tests/logbook.test.mjs runs: no command is written here.
import { useDeferredValue, useEffect, useId, useMemo, useState } from 'react';
import { useTable } from '../app/content.js';
import { Fold, Kv, RunLine, Loading, Tile, num, plural } from './ui.jsx';
import { runbookModel, runbookMatch, relScript, lastRunIndex } from './registerModel.js';

const HIGHLIGHT_FAMILIES = ['replication', 'label_bench'];

/** one script of the runbook list (exported for tests/logbook.test.mjs, which renders every item) */
export function RunbookItem({ it, nav }) {
  const single = it.parts.length === 1 ? it.parts[0] : null;
  const rec = (it.parts.find(p => p.rec) || {}).rec || null;
  return (
    <li className="lb-rb" id={'lb-rb-' + it.key} data-script={it.script} data-command={it.command ? 'yes' : 'no'}>
      <div className="lb-rb-head">
        <span className="lb-mono lb-strong lb-wrap">{it.script}</span>
        {single ? <RunLine run={single.run} compact /> : null}
      </div>
      {it.what ? <p className="lb-prose lb-small">{it.what}</p> : null}
      {it.command
        ? <pre className="lb-cmd" aria-label={`command for ${it.script}`}><code>{it.command}</code></pre>
        : <p className="lb-small lb-nocmd">no command recorded</p>}
      <Kv items={[
        ['a run prints', it.prints],
        // one script: the header carries passed / counts / date, this line what the record of the run says; several: one line each
        ['last run', single
          ? (single.run ? <span className="lb-stack">{single.run.status ? <span>{single.run.status}</span> : null}<span className="lb-muted lb-small">{single.run.machine}{single.run.source ? ` · ${single.run.source}` : ''}</span></span> : null)
          : <ul className="lb-plain lb-stack">{it.parts.map(p => <li key={p.path}><span className="lb-mono lb-small">{p.path}</span> <RunLine run={p.run} /></li>)}</ul>],
        ['recorded as', it.parts.some(p => p.recordedAs) ? <span className="lb-stack">{it.parts.filter(p => p.recordedAs).map(p => <span key={p.path} className="lb-mono lb-small">{p.recordedAs}</span>)}</span> : null],
        ['dependencies', it.deps],
        ['command from', it.commandFrom === 'checks' ? 'checks.json' : null],
      ]} />
      {rec ? <p className="lb-small"><button type="button" className="lb-linkbtn" onClick={() => nav.go('checks', { id: rec.script })}>Full record in Checks</button></p> : null}
    </li>
  );
}

export default function Replication({ nav, target }) {
  const [runbook, errR] = useTable('runbook');
  const [checks, errC] = useTable('checks');
  const [runs, errX] = useTable('check_runs');
  const model = useMemo(() => (runbook && checks && runs ? runbookModel({ runbook, checks, runs }) : null), [runbook, checks, runs]);
  const last = useMemo(() => (runs ? lastRunIndex(runs) : null), [runs]);
  const [show, setShow] = useState('all');
  const [query, setQuery] = useState('');
  const q = useDeferredValue(query.trim());
  const [openG, setOpenG] = useState(() => new Set());
  const name = useId();

  const visible = useMemo(() => {
    if (!model) return [];
    const keep = it => (show === 'all' || (show === 'cmd') === !!it.command) && runbookMatch(it, q);
    return model.groups.map(g => ({ ...g, shown: g.items.filter(keep) })).filter(g => g.shown.length);
  }, [model, show, q]);

  // a search that leaves few folders opens them
  useEffect(() => { if (q && visible.length && visible.length <= 4) setOpenG(new Set(visible.map(g => g.key))); }, [q, visible]);
  // an item asked for from elsewhere (a script path): open its folder and scroll to it
  useEffect(() => {
    if (!target || target.tab !== 'replication' || !target.id || !model) return;
    const id = target.id;
    const it = model.items.find(x => x.key === id || x.script === id || x.parts.some(p => p.path === relScript(id) || (p.rec && p.rec.script === id)));
    if (!it) { setQuery(id); return; }
    setShow('all'); setQuery(''); setOpenG(s => new Set(s).add(it.group));
    requestAnimationFrame(() => { const el = document.getElementById('lb-rb-' + it.key); if (el) el.scrollIntoView({ block: 'start' }); });
  }, [target, model]);

  if (!model) return <Loading what="the runbook" error={errR || errC || errX} />;
  const T = model.totals;
  const named = model.items.filter(it => it.source === 'runbook').reduce((a, it) => a + it.parts.length, 0);
  const unlisted = model.items.filter(it => it.source === 'runbook').flatMap(it => it.parts.filter(p => !p.rec).map(p => p.path));
  const highlights = (checks || []).filter(c => HIGHLIGHT_FAMILIES.includes(c.family));
  const toggle = (k, o) => setOpenG(s => { const n = new Set(s); o ? n.add(k) : n.delete(k); return n; });

  return (
    <div className="lb-stack-lg lb-replication">
      <p className="lb-prose lb-muted">How to run the checks again: for each script the runbook gives what it checks, what a run prints and the command,
        relative to the folder of the check scripts (<span className="lb-mono">checks/</span>); every script shows its last recorded run. Scripts the runbook does not name follow, with no command recorded.</p>

      <div className="lb-tiles" aria-label="Totals">
        <Tile label="Check scripts" value={num(T.scripts)} sub={`${num(T.withCommand)} with a command in the runbook, ${num(T.withoutCommand)} with none`} />
        <Tile label="Runbook entries" value={num(T.entries)} sub={`${plural(named, 'script')} named${unlisted.length ? `; ${num(unlisted.length)} not in checks.json` : ''}`} />
        <Tile label="Recorded runs" value={num(T.runs)} sub={`the last run of each of ${plural(T.lastRuns, 'script')} is shown`} />
        <Tile label="Last run passed" value={num(T.passed)} sub={`of ${num(T.lastRuns)}; ${num(T.notPassed.length)} not marked passed`} />
        <Tile label="Lines ok · fail" value={`${num(T.ok)} · ${num(T.fail)}`} sub={`counted in ${plural(T.counted, 'last run')}`} />
        <Tile label="Last runs dated" value={T.firstDate && T.lastDate && T.firstDate !== T.lastDate ? `${T.firstDate} – ${T.lastDate}` : (T.lastDate || '—')} />
      </div>

      {T.notPassed.length || unlisted.length ? (
        <div className="lb-two">
          {T.notPassed.length ? (
            <Fold className="lb-card" summary={<span className="lb-sum"><span className="lb-strong">{plural(T.notPassed.length, 'last run')} not marked passed</span><span className="lb-muted">what their records say</span></span>}>
              <ul className="lb-plain lb-stack lb-small">{T.notPassed.map(r => <li key={r.script}><span className="lb-mono">{relScript(r.script)}</span> <span className="lb-muted">{r.status}</span></li>)}</ul>
            </Fold>
          ) : null}
          {unlisted.length ? (
            <Fold className="lb-card" summary={<span className="lb-sum"><span className="lb-strong">Named by the runbook, not in checks.json</span><span className="lb-muted">{plural(unlisted.length, 'script')}</span></span>}>
              <ul className="lb-plain lb-stack lb-small">{unlisted.map(p => <li key={p} className="lb-mono">{p}</li>)}</ul>
            </Fold>
          ) : null}
        </div>
      ) : null}

      {highlights.length ? (
        <section className="lb-two" aria-label="The replication kit and the label bench">
          {highlights.map(c => (
            <article key={c.script} className="lb-card lb-pad lb-stack lb-highlight">
              <h3 className="lb-h3"><span className="lb-mono">{relScript(c.script)}</span> <span className="lb-muted lb-small">{c.family}</span></h3>
              <p className="lb-prose lb-small">{c.what}</p>
              <div className="lb-small">{last && last[c.script] ? <RunLine run={last[c.script]} /> : <span className="lb-muted">no recorded run</span>}</div>
              <Fold summary={<span className="lb-muted lb-small">independent route, method, notes, stored result</span>}>
                <Kv items={[
                  ['independent route', c.independentRoute],
                  ['method', c.method],
                  ['notes', c.notes],
                  ['stored result', c.storedResult ? <span className="lb-mono lb-small">{c.storedResult}</span> : null],
                ]} />
              </Fold>
              <p className="lb-small"><button type="button" className="lb-linkbtn" onClick={() => nav.go('checks', { id: c.script })}>Full record in Checks</button></p>
            </article>
          ))}
        </section>
      ) : null}

      <div className="lb-toolbar">
        <div className="lb-seg" role="radiogroup" aria-label="Show">
          {[['all', 'all', T.itemsWithCommand + T.itemsWithout], ['cmd', 'with a command', T.itemsWithCommand], ['none', 'no command recorded', T.itemsWithout]].map(([v, l, n]) => (
            <label key={v}><input type="radio" name={name} checked={show === v} onChange={() => setShow(v)} /> {l} <span className="lb-count">{n}</span></label>
          ))}
        </div>
        <label className="lb-field lb-field-inline"><span className="lb-eyebrow">Search</span>
          <input type="search" value={query} placeholder="script, words, command…" onChange={e => setQuery(e.target.value)} />
        </label>
      </div>

      {!visible.length ? <p className="lb-note">No script matches.</p> : null}
      {visible.map(g => (
        <Fold key={g.key} className="lb-card" open={openG.has(g.key)} onToggle={o => toggle(g.key, o)}
          summary={<span className="lb-sum"><span className="lb-mono lb-strong">{g.title}</span><span className="lb-muted">{plural(g.scripts, 'script')}{g.items.length !== g.scripts ? ` in ${plural(g.items.length, 'entry', 'entries')}` : ''} · {num(g.withCommand)} with a command · last run passed {num(g.passed)} of {num(g.scripts)}{g.shown.length !== g.items.length ? ` · ${g.shown.length} shown` : ''}</span></span>}>
          <ul className="lb-plain lb-rb-list">{g.shown.map(it => <RunbookItem key={it.key} it={it} nav={nav} />)}</ul>
        </Fold>
      ))}
    </div>
  );
}
