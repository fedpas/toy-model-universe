// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/MatrixTab.jsx — the translation matrix of content/matrix.json as one heatmap: author rows × atlas columns,
// a cell per graded meeting (E, S, A; the letter is always printed), its note in the panel on click.
import { useMemo, useState } from 'react';
import { useTable } from '../app/content.js';
import { Loading } from './ui.jsx';
import { matrixCounts } from './registerModel.js';

const GRADE = { E: 'E exact', S: 'S structural', A: 'A analogy' };

export default function MatrixTab() {
  const [M, err] = useTable('matrix');
  const [sel, setSel] = useState(null);
  const counts = useMemo(() => matrixCounts(M), [M]);
  if (!M) return <Loading what="the translation matrix" error={err} />;
  const cols = M.columns || [], rows = M.rows || [];
  const srcName = new Map((M.sources || []).map(s => [s.key, s.name]));
  const colBy = new Map(cols.map(c => [c.key, c]));
  const rowBy = new Map(rows.map(r => [r.uid, r]));
  const s = sel && rowBy.get(sel.uid), c = sel && colBy.get(sel.col), cell = s && c && (s.cells || {})[c.key];
  let lastSrc = null;
  return (
    <div className="lb-stack-lg">
      <div className="lb-legend" aria-label="Legend">
        <span><i className="lb-sw lb-g-E" aria-hidden="true">E</i>exact <span className="lb-num lb-muted">{counts.E}</span></span>
        <span><i className="lb-sw lb-g-S" aria-hidden="true">S</i>structural <span className="lb-num lb-muted">{counts.S}</span></span>
        <span><i className="lb-sw lb-g-A" aria-hidden="true">A</i>analogy <span className="lb-num lb-muted">{counts.A}</span></span>
        <span><i className="lb-sw lb-g-gap" aria-hidden="true" />no cell</span>
        <span className="lb-muted">{counts.rows} rows × {counts.columns} columns · {counts.cells} graded cells · {counts.rowsWithoutCell} rows with no cell</span>
      </div>
      <div className="lb-note lb-matrix-note" role="status" aria-live="polite">
        {cell ? (
          <>
            <p><span className="lb-mono lb-strong">{s.uid}</span> {s.title} <span className="lb-muted">({srcName.get(s.src) || s.src})</span></p>
            <p>× <strong>{c.long}</strong> <span className="lb-muted">({c.where})</span> → <span className="lb-chip">{GRADE[cell.grade] || cell.grade}</span></p>
            <p className="lb-prose">{cell.note}</p>
          </>
        ) : <p className="lb-muted">Choose a cell to read its note.</p>}
      </div>
      <div className="lb-hm" role="region" aria-label="Translation matrix heatmap" tabIndex={0}>
        <table>
          <thead>
            <tr>
              <th scope="col" className="lb-hm-corner">author row</th>
              {cols.map(col => <th key={col.key} scope="col" className="lb-hm-col" title={`${col.long} (${col.where})`}><span>{col.short}</span></th>)}
            </tr>
          </thead>
          <tbody>
            {rows.flatMap(r => {
              const out = [];
              if (r.src !== lastSrc) { lastSrc = r.src; out.push(<tr key={'src-' + r.src} className="lb-hm-src"><th scope="rowgroup" colSpan={cols.length + 1}>{srcName.get(r.src) || r.src}</th></tr>); }
              out.push(
                <tr key={r.uid}>
                  <th scope="row" className="lb-hm-row" title={r.title}><span className="lb-mono">{r.uid}</span> {r.title}</th>
                  {cols.map(col => {
                    const x = (r.cells || {})[col.key];
                    if (!x) return <td key={col.key}><span className="lb-cell lb-g-gap" /></td>;
                    const on = sel && sel.uid === r.uid && sel.col === col.key;
                    return (
                      <td key={col.key}>
                        <button type="button" className={`lb-cell lb-g-${x.grade}${on ? ' is-sel' : ''}`} aria-pressed={on}
                          aria-label={`${r.uid} ${r.title} × ${col.long}: ${GRADE[x.grade] || x.grade}`} onClick={() => setSel({ uid: r.uid, col: col.key })}>{x.grade}</button>
                      </td>
                    );
                  })}
                </tr>,
              );
              return out;
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
