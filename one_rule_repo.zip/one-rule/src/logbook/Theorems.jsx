// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/Theorems.jsx — T1–T20 as stored in content/theorems.json: status and verifier, statement, limits,
// remarks, the script with its last run, and the rows that use each theorem; the readings that name it, their `$…$`
// typeset by the pages' RichText at research level.
import { useEffect, useMemo, useState } from 'react';
import { useTable } from '../app/content.js';
import RichText from '../components/RichText.jsx';
import { Fold, Chip, Tag, Kv, RefList, RunLine, Loading, plural } from './ui.jsx';
import { lastRunIndex, dependentsIndex, readingsForTheorem } from './registerModel.js';

export default function Theorems({ nav, target, settings }) {
  const level = settings && settings.level === 'learner' ? 'learner' : 'research';
  const [theorems, err] = useTable('theorems');
  const [runs] = useTable('check_runs');
  const [rows] = useTable('rows');
  const [readings] = useTable('readings');
  const last = useMemo(() => (runs ? lastRunIndex(runs) : null), [runs]);
  const dependents = useMemo(() => (rows ? dependentsIndex(rows) : null), [rows]);
  const [open, setOpen] = useState(() => new Set());
  useEffect(() => {
    if (!target || target.tab !== 'theorems' || !target.id) return;
    setOpen(o => new Set(o).add(target.id));
    requestAnimationFrame(() => { const el = document.getElementById('lb-thm-' + target.id); if (el) el.scrollIntoView({ block: 'start' }); });
  }, [target]);
  if (!theorems) return <Loading what="the theorems" error={err} />;
  const count = (k, v) => theorems.filter(t => t[k] === v).length;
  const statuses = [...new Set(theorems.map(t => t.status))], verifiers = [...new Set(theorems.map(t => t.verifier))];
  return (
    <div className="lb-stack-lg">
      <p className="lb-muted">{plural(theorems.length, 'theorem')} · {statuses.map(s => `${count('status', s)} ${s}`).join(' · ')} · second reader: {verifiers.map(v => `${count('verifier', v)} ${v}`).join(' · ')}</p>
      {theorems.map(t => {
        const isOpen = open.has(t.id);
        const resting = dependents ? [...new Set((dependents.get(t.id) || []).map(d => d.id))] : null;
        return (
          <Fold key={t.id} id={'lb-thm-' + t.id} className="lb-card" open={isOpen}
            onToggle={o => setOpen(s => { const n = new Set(s); o ? n.add(t.id) : n.delete(t.id); return n; })}
            summary={<span className="lb-sum"><span className="lb-mono lb-strong">{t.id}</span><Chip>{t.status}</Chip><Chip dash={t.verifier !== 'verified'}>{t.verifier}</Chip><span className="lb-sum-title">{t.title}</span></span>}>
            <p className="lb-prose">{t.statement}</p>
            <Kv items={[
              ['status note', t.statusNote],
              ['second reader', t.verifierNote],
              ['script', t.script ? <span className="lb-stack"><button type="button" className="lb-linkbtn lb-mono" onClick={() => nav.go('checks', { id: t.script })}>{t.script}</button><RunLine run={last ? last[t.script] : null} /></span> : null],
              ['what the script checks', t.checks],
              ['limits', (t.limits || []).length ? <ul className="lb-list">{t.limits.map((l, i) => <li key={i}>{l}</li>)}</ul> : <span className="lb-muted">none declared</span>],
              ['remarks', (t.remarks || []).length ? <div className="lb-stack">{t.remarks.map((r, i) => <p key={i} className="lb-prose">{(r.tags || []).map(g => <Tag key={g}>{g}</Tag>)} {r.text}</p>)}</div> : null],
              ['rows using it', <RefList ids={t.rowsUsing || []} nav={nav} empty="none listed" />],
              ['rows whose relations name it', resting ? <RefList ids={resting} nav={nav} empty="none" /> : null],
              ['readings naming it', readings ? <TheoremReadings id={t.id} readings={readings} level={level} /> : null],
            ]} />
          </Fold>
        );
      })}
    </div>
  );
}

const Rt = ({ text, level }) => (text == null || text === '' ? null : <RichText text={String(text)} level={level} />);

function TheoremReadings({ id, readings, level }) {
  const list = useMemo(() => readingsForTheorem(id, readings), [id, readings]);
  if (!list.length) return <span className="lb-muted">none</span>;
  return (
    <Fold summary={plural(list.length, 'reading')}>
      <ul className="lb-list lb-small">{list.map((d, i) => <li key={i}><span className="lb-muted">{d.source} · {d.field}:</span> <Rt text={d.atlas_element} level={level} /> → <Rt text={d.field_term} level={level} /> <span className="lb-muted">(<Rt text={d.grade_or_status} level={level} />)</span></li>)}</ul>
    </Fold>
  );
}
