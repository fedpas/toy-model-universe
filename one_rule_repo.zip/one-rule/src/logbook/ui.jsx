// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/logbook/ui.jsx — small shared pieces of the Logbook tabs (folds, chips, id links, run lines, text marks, tiles). No badges
// here: a row's status is drawn only by src/components/Badge.jsx; the text marks say who wrote a text, not what the row is.
import { useState } from 'react';
import { refKind, pageLabel, textMark } from './registerModel.js';
import { textStatuses } from './methodText.js';

/** a <details> whose body renders only while open (the long lists stay out of the DOM until asked for) */
export function Fold({ summary, children, open, onToggle, className = '', id, defaultOpen = false }) {
  const [own, setOwn] = useState(defaultOpen);
  const isOpen = open ?? own;
  return (
    <details id={id} className={`lb-fold ${className}`} open={isOpen}
      onToggle={e => { const o = e.currentTarget.open; if (o !== isOpen) { onToggle ? onToggle(o) : setOwn(o); } }}>
      <summary>{summary}</summary>
      {isOpen ? <div className="lb-fold-body">{children}</div> : null}
    </details>
  );
}

export function Chip({ children, dash = false, title }) {
  return <span className={`lb-chip${dash ? ' lb-chip-dash' : ''}`} title={title}>{children}</span>;
}

export function Tag({ children, title }) { return <span className="lb-tag" title={title}>{children}</span>; }

/** an id named somewhere (a row, a theorem, a question) as a button that opens it in its tab */
export function RefLink({ id, nav, note }) {
  const k = refKind(id);
  const go = () => nav.go(k === 'theorem' ? 'theorems' : k === 'question' ? 'questions' : k === 'check' ? 'checks' : 'register', { id });
  return <button type="button" className="lb-ref" onClick={go} title={k === 'row' ? `open ${id} in the register` : `open ${id}`}>{id}{note ? <span className="lb-ref-note">{note}</span> : null}</button>;
}

export function RefList({ ids, nav, max = 40, empty = '—', notes }) {
  const [all, setAll] = useState(false);
  if (!ids || !ids.length) return <span className="lb-muted">{empty}</span>;
  const shown = all ? ids : ids.slice(0, max);
  return (
    <span className="lb-refs">
      {shown.map(id => <RefLink key={id} id={id} nav={nav} note={notes ? notes(id) : null} />)}
      {ids.length > max ? <button type="button" className="lb-linkbtn" onClick={() => setAll(!all)}>{all ? 'show fewer' : `show all ${ids.length}`}</button> : null}
    </span>
  );
}

/** a definition list; items: [label, value] with null values skipped */
export function Kv({ items }) {
  return (
    <dl className="lb-kv">
      {items.filter(it => it && it[1] != null && it[1] !== '' && !(Array.isArray(it[1]) && !it[1].length)).map(([k, v]) => (
        <div key={k} className="lb-kv-item"><dt>{k}</dt><dd>{v}</dd></div>
      ))}
    </dl>
  );
}

export function Loading({ what, error }) {
  if (error) return <p className="lb-note" role="status">{what}: not available ({String(error.message || error)}).</p>;
  return <p className="lb-muted" role="status">Loading {what}…</p>;
}

/** inline **bold** and `code` of the docs, without HTML injection */
export function Md({ text }) {
  const parts = String(text || '').split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return <>{parts.map((p, i) => (p.startsWith('**') && p.endsWith('**') ? <strong key={i}>{p.slice(2, -2)}</strong> : p.startsWith('`') && p.endsWith('`') ? <code key={i}>{p.slice(1, -1)}</code> : p))}</>;
}

const secs = s => (typeof s === 'number' ? `${s} s` : s ? String(s) : null);
/** the last recorded run of a script: passed or not, ok/fail counts, seconds, date, the status words of the log */
export function RunLine({ run, compact = false }) {
  if (!run) return <span className="lb-muted">no recorded run</span>;
  const counts = typeof run.ok === 'number' || typeof run.fail === 'number' ? `ok ${run.ok ?? '—'} · fail ${run.fail ?? '—'}` : null;
  return (
    <span className="lb-run">
      <Chip dash={run.passed !== true}>{run.passed === true ? 'passed' : 'not passed'}</Chip>
      {counts ? <span className="lb-num">{counts}</span> : null}
      {secs(run.seconds) ? <span className="lb-num">{secs(run.seconds)}</span> : null}
      <span className="lb-num lb-muted">{run.date}</span>
      {!compact && run.status ? <span className="lb-muted lb-run-status">{run.status}</span> : null}
    </span>
  );
}

export const PageName = ({ route }) => <span className="lb-mono">{pageLabel(route)}</span>;

const MARK_SHAPE = {
  // a pencil: a model's words not yet reviewed
  draft: <path d="M2.2 9.8 2.6 7.6 7.9 2.3a1.1 1.1 0 0 1 1.6 0l.2.2a1.1 1.1 0 0 1 0 1.6L4.4 9.4zM7 3.2 8.8 5" />,
  // a tick in a circle: a model's words the author accepted
  reviewed: <><circle cx="6" cy="6" r="4.6" /><path d="M3.9 6.1 5.4 7.6 8.2 4.6" /></>,
};
/**
 * The mark of a text record that is not the author's own words (docs/09_TRANSLATION_PROTOCOL.md §4): "draft" (pencil,
 * dashed outline) or "reviewed" (tick, solid outline); word and shape, never colour alone. Nothing for a human text.
 */
export function TextMark({ rec, withSource = true }) {
  const kind = textMark(rec);
  if (!kind) return null;
  const meaning = (textStatuses.find(s => s[0] === kind) || [])[1];
  return (
    <span className="lb-markline">
      <span className={`lb-mark lb-mark-${kind}`} data-mark={kind} title={meaning ? `${kind}: ${meaning}` : kind}>
        <svg viewBox="0 0 12 12" width="12" height="12" aria-hidden="true" focusable="false">{MARK_SHAPE[kind]}</svg>
        {kind}
      </span>
      {withSource && rec.source ? <span className="lb-mono lb-small lb-muted lb-wrap">{rec.source}</span> : null}
    </span>
  );
}

/** a stat tile: a label (sentence case) over one value, with an optional line under it; numbers come from the tables */
export function Tile({ label, value, sub }) {
  return (
    <div className="lb-tile">
      <span className="lb-tile-label">{label}</span>
      <span className="lb-tile-value">{value}</span>
      {sub ? <span className="lb-tile-sub">{sub}</span> : null}
    </div>
  );
}

/** a number with thousands separators (en) */
export const num = n => (typeof n === 'number' ? n.toLocaleString('en-US') : String(n ?? '—'));

/** count words: "1 row", "3 rows" */
export const plural = (n, one, many = one + 's') => `${n} ${n === 1 ? one : many}`;
