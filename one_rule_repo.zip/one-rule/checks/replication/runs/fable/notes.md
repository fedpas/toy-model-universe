# Notes for the blind replication (run `fable`)

## Files read
Only the two files in the working folder:
- `./replication/runs/fable/INSTRUCTIONS.md`
- `./replication/runs/fable/answers_template.json`

No other file on the machine was opened, and no web access was used. No sympy was available
(`import sympy` failed), so everything is Python 3.13 standard library + numpy 2.5.3.

## Code written (all my own) and commands run
1. `ls -la ./replication/runs/fable/` – see what the folder contains.
2. `python3 -c "import numpy, sys; ..."` / `python3 -c "import sympy"` – check what is installed.
3. Wrote `q1q2.py`; ran `python3 q1q2.py` → writes `_q1q2.json`.
   - q1: enumerates blades of Cl(p,q), finds the centre and the sign count of blade squares
     (signature of the trace form), classifies as M(d,R) / M(d,C) / M(d,H) / sum; independently
     re-derives every signature from the recursion Cl(p+1,q+1)=M(2,Cl(p,q)),
     Cl(p+2,q)=Cl(q,p)⊗M(2,R), Cl(p,q+2)=Cl(q,p)⊗H with Cl(0,0)=R, Cl(1,0)=R⊕R, Cl(0,1)=C.
     Both methods agree on all 16 signatures.
   - q2: blade product by concatenation + sign-tracked sort + cancellation; also prints the
     result under the alternative bit-order reading (see ambiguities).
4. Wrote `q3q4.py`; ran `python3 q3q4.py` (about 7 minutes, dominated by the long RK4 drift
   runs) → writes `_q3q4.json`. Analytic formulas plus RK4 integration of
   d(γv)/dt = E + v×B for the cyclotron, drift, hyperbolic, plane-wave and Coulomb cases, and a
   field-tensor check F' = Λ F Λᵀ for the boost. One fix in between: the cyclotron period detector
   initially looked for the wrong sign of the p_y crossing (edited, re-ran).
5. Wrote `q5to8.py`; ran `python3 q5to8.py` → writes `_q5to8.json`. E8 root enumeration and Gram
   matrix; Jordan–Wigner Fock space with CAR, su(3) closure and Casimir checks; Pauli-matrix model
   of Cl(3,0) for the rotor; vis-viva + RK4 two-body check for the Moon.
6. Wrote `assemble.py`; ran `python3 assemble.py` → `answers.json` (keys checked against the
   template), then `python3 -c "import json; json.load(open('answers.json'))"` to validate.

## Numerical cross-checks that passed
- q4: radius 4/3 and period 10π/3 reproduced by integration; mean velocity in crossed fields
  converged to (0, −0.6, 0) from two different initial momenta; x(3) = √10 − 1 and v = 3/√10
  reproduced; plane-wave drift 0.36 = a²/(4+a²) reproduced to 8 digits with γ − p_z conserved;
  three successive perihelion advances all 61.34813°; invariants E²−B² = −63 and E·B = 32 equal
  in both frames.
- q5: inner-product histogram with r₀ is {−2:1, −1:56, 0:126, 1:56, 2:1}; 72 roots orthogonal
  to any A2 pair (same count for several random pairs).
- q6: the Casimir is constant on each N sector (0, 4/3, 4/3, 0); the T^k commute with N and close.
- q8: period from integration 27.321937 d equals the vis-viva value.

## Ambiguities in the brief
- **q2 (marked unsure):** "labels written in binary" – I read each 6-digit string as an ordinary
  binary number, so the rightmost digit is bit 0 (e.g. 001000 = 8 = bit 3 → e₃). If instead the
  leftmost digit were meant as bit 0, three of the eight signs change: the list would be
  [1, 1, 1, 1, 1, −1, 1, −1] instead of my [1, 1, 1, −1, −1, −1, 1, 1]. I consider the ordinary
  reading the natural one, but listed q2 under `unsure` because the answer hinges on it.
- **q1:** the brief says "Example id: q1_1_3. Example value (for a different signature): M(2,H)".
  Under the brief's own definition (p generators squaring to +1, q to −1) I find Cl(1,3) ≅ M(2,H)
  and Cl(3,1) ≅ M(4,R) (consistent with the Majorana representation: real 4×4 gammas exist for
  three + and one − generator), and M(2,H) is the answer for no other listed signature. So the
  parenthetical "for a different signature" is either loose wording or a sign that the reference
  table was built with p and q swapped. I followed the stated definition; if the reference uses the
  opposite convention, most of the asymmetric q1 entries would flip.
- **q4 drift:** no initial conditions are given; the mean velocity is independent of them
  (E×B/B²), which the integration confirmed, so this is not actually ambiguous.
- **q4_kepler_deg:** the start (r = 1, tangential speed 0.5) is at apoapsis of a nearly circular
  orbit (r ∈ [0.903, 1]); the perihelion advance 360(1/√(1−κ²/L²) − 1) does not depend on that.
- **q8:** "relative orbit" was taken to mean μ = G(M+m). Using GM alone would change the period
  by ~0.6 %, outside the tolerance, so the choice matters; G(M+m) is the correct one for the
  relative two-body motion.
- Formatting: q7 components and the q4 boost are given as floats (0.0, 1.0, …); integer counts as
  integers. `unsure` contains only `q2`.
