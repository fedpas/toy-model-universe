"""q5 E8 roots, q6 three fermion modes / SU(3), q7 Cl(3,0) rotor, q8 two-body orbit.  Own code, numpy only."""
import numpy as np, itertools, math, json

out = {}

# ---------------- q5 ----------------
roots = []
for i, j in itertools.combinations(range(8), 2):
    for si in (1, -1):
        for sj in (1, -1):
            v = np.zeros(8); v[i] = si; v[j] = sj; roots.append(v)
for signs in itertools.product((1, -1), repeat=8):
    if sum(1 for s in signs if s < 0) % 2 == 0:
        roots.append(0.5 * np.array(signs, dtype=float))
R = np.array(roots)
out['q5_roots'] = len(R)
G = R @ R.T                                     # Gram matrix (all roots have norm^2 = 2)
assert np.allclose(np.diag(G), 2)
r0 = np.array([1, 1, 0, 0, 0, 0, 0, 0.0])
ip = R @ r0
out['q5_ip1'] = int(np.sum(np.isclose(ip, 1)))
out['q5_ip0'] = int(np.sum(np.isclose(ip, 0)))
print('inner-product histogram with r0:', {k: int(np.sum(np.isclose(ip, k))) for k in (-2, -1, 0, 1, 2)})
# distances: |r - r'|^2 = 4 - 2 r.r' ; smallest nonzero distance <-> largest inner product < 2, i.e. r.r' = 1
D2 = 4 - 2 * G
np.fill_diagonal(D2, np.inf)
dmin = D2.min()
out['q5_edges'] = int(np.sum(np.isclose(D2, dmin)) // 2)
print('min distance^2 =', dmin, ' edges =', out['q5_edges'], ' (= 240*56/2 =', 240 * 56 // 2, ')')
# orthogonal complement of an A2 (two roots with inner product -1)
cnt = set()
for trial in range(5):
    i = np.random.randint(240)
    js = np.where(np.isclose(G[i], -1))[0]
    j = js[np.random.randint(len(js))]
    n = int(np.sum(np.isclose(G[i], 0) & np.isclose(G[j], 0)))
    cnt.add(n)
assert len(cnt) == 1
out['q5_orth_A2'] = cnt.pop()
print('roots orthogonal to an A2 pair:', out['q5_orth_A2'])

# ---------------- q6 ----------------
# Jordan-Wigner construction of three fermionic modes on 8-dim Fock space
I2 = np.eye(2); Z = np.diag([1.0, -1.0]); am = np.array([[0, 1.0], [0, 0]])  # am |1> = |0> with |0>=(1,0), |1>=(0,1)
def kron(*ms):
    r = np.eye(1)
    for m in ms:
        r = np.kron(r, m)
    return r
a = [kron(am, I2, I2), kron(Z, am, I2), kron(Z, Z, am)]
# check CAR
for i in range(3):
    for j in range(3):
        acom = a[i] @ a[j].T + a[j].T @ a[i]
        assert np.allclose(acom, np.eye(8) * (i == j))
        assert np.allclose(a[i] @ a[j] + a[j] @ a[i], 0)
N = sum(ai.T @ ai for ai in a)
out['q6_dim'] = 8
evN = np.round(np.diag(N)).astype(int)
out['q6_N_mult'] = [int(np.sum(evN == k)) for k in range(4)]
# Gell-Mann matrices
lam = [np.array([[0, 1, 0], [1, 0, 0], [0, 0, 0]], dtype=complex),
       np.array([[0, -1j, 0], [1j, 0, 0], [0, 0, 0]]),
       np.array([[1, 0, 0], [0, -1, 0], [0, 0, 0]], dtype=complex),
       np.array([[0, 0, 1], [0, 0, 0], [1, 0, 0]], dtype=complex),
       np.array([[0, 0, -1j], [0, 0, 0], [1j, 0, 0]]),
       np.array([[0, 0, 0], [0, 0, 1], [0, 1, 0]], dtype=complex),
       np.array([[0, 0, 0], [0, 0, -1j], [0, 1j, 0]]),
       np.array([[1, 0, 0], [0, 1, 0], [0, 0, -2]], dtype=complex) / math.sqrt(3)]
out['q6_su3_dim'] = len(lam)
T = []
for l in lam:
    Tk = np.zeros((8, 8), dtype=complex)
    for i in range(3):
        for j in range(3):
            Tk += a[i].T @ a[j] * (l[i, j] / 2)
    T.append(Tk)
# check su(3) commutation relations close: [T^a, T^b] = i f_abc T^c  -> verify by projecting onto span
basis = np.array([Tk.flatten() for Tk in T])
for A_ in range(8):
    for B_ in range(8):
        C = (T[A_] @ T[B_] - T[B_] @ T[A_]).flatten()
        coef, res, *_ = np.linalg.lstsq(basis.T, C, rcond=None)
        assert np.allclose(basis.T @ coef, C), 'algebra does not close'
C2 = sum(Tk @ Tk for Tk in T)
assert np.allclose(C2, C2.conj().T)
# Casimir is diagonal in the occupation basis here; take its value per N-sector
cas = []
for k in range(4):
    idx = np.where(evN == k)[0]
    block = C2[np.ix_(idx, idx)]
    vals = np.linalg.eigvalsh(block)
    assert np.allclose(vals, vals[0]), ('sector not irreducible?', k, vals)
    cas.append(float(np.real(vals[0])))
out['q6_casimir_by_N'] = cas
print('N multiplicities', out['q6_N_mult'], ' Casimir by N:', cas, ' (4/3 =', 4 / 3, ')')
# also check commutation with N
assert all(np.allclose(Tk @ N - N @ Tk, 0) for Tk in T)

# ---------------- q7 ----------------
# Cl(3,0) via Pauli matrices as a faithful representation (e_i -> sigma_i)
s1 = np.array([[0, 1], [1, 0]], dtype=complex)
s2 = np.array([[0, -1j], [1j, 0]])
s3 = np.array([[1, 0], [0, -1]], dtype=complex)
e = [s1, s2, s3]
e12 = e[0] @ e[1]
def rotor(theta):
    return math.cos(theta / 2) * np.eye(2) - math.sin(theta / 2) * e12
def reverse_rotor(theta):
    return math.cos(theta / 2) * np.eye(2) + math.sin(theta / 2) * e12
def vec_components(M):
    # vector part: components along sigma_i via (1/2) tr(M sigma_i); check no other part
    comps = [np.real(np.trace(M @ ei)) / 2 for ei in e]
    rec = sum(c * ei for c, ei in zip(comps, e))
    assert np.allclose(rec, M), 'result not a pure vector'
    return [float(round(c, 12)) + 0.0 for c in comps]
th = math.pi / 2
Rm, Rt = rotor(th), reverse_rotor(th)
assert np.allclose(Rm @ Rt, np.eye(2))
for i in range(3):
    out[f'q7_Re{i + 1}'] = vec_components(Rm @ e[i] @ Rt)
    print(f'R e{i + 1} R~ =', out[f'q7_Re{i + 1}'])
R2pi = rotor(2 * math.pi)
assert np.allclose(R2pi, R2pi[0, 0] * np.eye(2))
out['q7_R2pi'] = float(round(np.real(R2pi[0, 0]), 12))
print('R(2pi) =', out['q7_R2pi'])

# ---------------- q8 ----------------
G_ = 6.6703e-11; M = 5.97237e24; m = 7.342e22
mu = G_ * (M + m)
r = 362400e3; v = 1085.0
inv_a = 2 / r - v ** 2 / mu
a_ = 1 / inv_a
T_ = 2 * math.pi * math.sqrt(a_ ** 3 / mu)
out['q8_semi_major_km'] = a_ / 1e3
out['q8_period_days'] = T_ / 86400
ecc = abs(r * v ** 2 / mu - 1)   # tangential start -> at an apsis; e = |r v^2/mu - 1|
print(f'q8: mu={mu:.6e}, a = {a_/1e3:.3f} km, T = {T_:.2f} s = {T_/86400:.6f} days, e = {ecc:.5f}, '
      f'start at {"perigee" if r < a_ else "apogee"}')
# numerical check of the period by integrating the relative two-body problem
def f2(t, y):
    x, vv = y[:2], y[2:]
    rr = np.linalg.norm(x)
    return np.concatenate([vv, -mu * x / rr ** 3])
def rk4(f, y, t, dt):
    k1 = f(t, y); k2 = f(t + dt / 2, y + dt / 2 * k1)
    k3 = f(t + dt / 2, y + dt / 2 * k2); k4 = f(t + dt, y + dt * k3)
    return y + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
y = np.array([r, 0, 0, v]); t = 0; dt = 10.0; prev = y.copy()
Tnum = None
while t < 40 * 86400:
    yn = rk4(f2, y, t, dt); t += dt
    if t > 86400 and y[1] < 0 <= yn[1] and yn[0] > 0:
        Tnum = t - dt + (-y[1] / (yn[1] - y[1])) * dt
        break
    y = yn
print(f'q8 numeric period: {Tnum/86400:.6f} days')

json.dump(out, open('./replication/runs/fable/_q5to8.json', 'w'), indent=1)
