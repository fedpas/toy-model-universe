"""q3 counting and q4 relativistic charge dynamics.  Own code, numpy only."""
import numpy as np, json, math

out = {}

# ---------------- q3 ----------------
# Cl(k,k) = M(2^k, R)  (verified in q1q2.py for k=4; the trace/center criterion gives real type, dim 2^(2k) = d^2)
for k in (4, 5):
    out[f'q3_size_{k}'] = 2 ** k
for n in (8, 10):
    out[f'q3_terms_{n}'] = (2 ** n) ** 2           # every pair of basis coefficients
    d = 2 ** (n // 2)
    out[f'q3_mults_{n}'] = d ** 3                  # schoolbook d x d matrix product
out['q3_blocks_products'] = 16 ** 3                # 16x16 schoolbook product: 16^3 Cl(N) products
# terms in Cl(N+8): (2^(N+8))^2 = 2^(2N+16); 16^3 Cl(N)-products each with (2^N)^2 terms: 2^(12+2N); ratio 2^4
out['q3_ratio'] = (2 ** 16) // (16 ** 3)
assert out['q3_ratio'] == 16
print({k: v for k, v in out.items() if k.startswith('q3')})

# ---------------- q4 ----------------
def gamma_of_p(p):
    return math.sqrt(1.0 + float(np.dot(p, p)))

def rk4(f, y, t, dt):
    k1 = f(t, y); k2 = f(t + dt / 2, y + dt / 2 * k1)
    k3 = f(t + dt / 2, y + dt / 2 * k2); k4 = f(t + dt, y + dt * k3)
    return y + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

def lorentz(Efun, Bfun):
    """state y = (x(3), p(3)), p = gamma v, q = m = 1."""
    def f(t, y):
        x, p = y[:3], y[3:]
        g = gamma_of_p(p); v = p / g
        E = Efun(t, x); B = Bfun(t, x)
        return np.concatenate([v, E + np.cross(v, B)])
    return f

# --- cyclotron: B = 1 z, v = 0.8 perpendicular ---
v0 = 0.8; g0 = 1 / math.sqrt(1 - v0 ** 2)
out['q4_radius'] = g0 * v0 / 1.0           # r = gamma m v / (q B)
out['q4_period'] = 2 * math.pi * g0 / 1.0  # T = 2 pi gamma m / (q B)
# numerical check
f = lorentz(lambda t, x: np.zeros(3), lambda t, x: np.array([0, 0, 1.0]))
y = np.array([0, 0, 0, g0 * v0, 0, 0.0]); t = 0; dt = 1e-3
xs = []
# integrate until the velocity direction comes back (one full turn)
p0 = y[3:].copy(); turned = False; T_num = None
while t < 20:
    yn = rk4(f, y, t, dt); t += dt
    if t > 1.0 and not turned:
        # crossing of p_y from positive to negative while p_x > 0 -> back to start direction
        if y[4] > 0 >= yn[4] and yn[3] > 0:
            # linear interpolation of crossing time
            frac = -y[4] / (yn[4] - y[4]); T_num = t - dt + frac * dt; turned = True
    y = yn; xs.append(y[:3].copy())
xs = np.array(xs)
r_num = (xs[:, 0].max() - xs[:, 0].min()) / 2
print(f'cyclotron: r = {out["q4_radius"]:.6f} (num {r_num:.6f});  T = {out["q4_period"]:.6f} (num {T_num:.6f})')

# --- drift: E = 3 x, B = 5 z ---
E = np.array([3.0, 0, 0]); B = np.array([0, 0, 5.0])
vd = np.cross(E, B) / np.dot(B, B)
out['q4_drift_speed'] = float(np.linalg.norm(vd))
out['q4_drift_vy'] = float(vd[1])
out['q4_drift_gamma'] = 1 / math.sqrt(1 - np.dot(vd, vd))
# numerical: average velocity over a long time from rest (and from another initial p) -> should be vd
f = lorentz(lambda t, x: E, lambda t, x: B)
for pinit in ([0, 0, 0.0], [0.7, -0.4, 0.0]):
    y = np.array([0, 0, 0] + pinit, dtype=float); t = 0; dt = 2e-3; Tend = 4000.0
    n = int(Tend / dt)
    for _ in range(n):
        y = rk4(f, y, t, dt); t += dt
    print(f'drift (p0={pinit}): mean v = {y[:3] / t}  (vd = {vd})')
print('drift speed', out['q4_drift_speed'], 'vy', out['q4_drift_vy'], 'gamma', out['q4_drift_gamma'])

# --- hyperbolic: E = 1 x ---
tt = 3.0
out['q4_hyp_x'] = math.sqrt(1 + tt ** 2) - 1
out['q4_hyp_v'] = tt / math.sqrt(1 + tt ** 2)
f = lorentz(lambda t, x: np.array([1.0, 0, 0]), lambda t, x: np.zeros(3))
y = np.zeros(6); t = 0; dt = 1e-3
for _ in range(3000):
    y = rk4(f, y, t, dt); t += dt
print(f'hyperbolic: x = {out["q4_hyp_x"]:.8f} (num {y[0]:.8f}); v = {out["q4_hyp_v"]:.8f} (num {y[3] / gamma_of_p(y[3:]):.8f})')

# --- plane wave drift ---
a = 1.5
out['q4_wave_drift'] = a ** 2 / (4 + a ** 2)      # derived: <dz/dt> = a^2 / (4 + a^2)
f = lorentz(lambda t, x: np.array([a * math.cos(t - x[2]), 0, 0]),
            lambda t, x: np.array([0, a * math.cos(t - x[2]), 0]))
y = np.zeros(6); t = 0; dt = 2e-3
# integrate exactly an integer number of phase periods: phase phi = t - z ; one phase period takes lab time 2pi(1 + a^2/4)
Tper = 2 * math.pi * (1 + a ** 2 / 4)
Tend = 50 * Tper
n = int(round(Tend / dt)); dt = Tend / n
for _ in range(n):
    y = rk4(f, y, t, dt); t += dt
print(f'wave drift: analytic {out["q4_wave_drift"]:.8f}, numeric z/t = {y[2] / t:.8f}, phase = {t - y[2]:.6f} (50 periods -> {50 * 2 * math.pi:.6f})')
# conserved checks
print('   gamma - p_z =', gamma_of_p(y[3:]) - y[5], ' (should be 1)')

# --- relativistic Kepler precession ---
kappa = 0.3; r0 = 1.0; vt = 0.5
g = 1 / math.sqrt(1 - vt ** 2); L = g * r0 * vt; Etot = g - kappa / r0
nu = math.sqrt(1 - kappa ** 2 / L ** 2)
out['q4_kepler_deg'] = 360.0 * (1 / nu - 1)
print(f'kepler: L={L:.6f}, E={Etot:.6f}, nu={nu:.8f}, advance = {out["q4_kepler_deg"]:.6f} deg;  '
      f'r range {1/(kappa*Etot/(L**2-kappa**2) + abs(1-kappa*Etot/(L**2-kappa**2))):.5f}..{r0}')
# numerical integration in the plane; find successive perihelia (minima of r)
def fk(t, y):
    x, p = y[:3], y[3:]
    gg = gamma_of_p(p); v = p / gg
    r = np.linalg.norm(x)
    return np.concatenate([v, -kappa * x / r ** 3])
y = np.array([r0, 0, 0, 0, g * vt, 0.0]); t = 0; dt = 2e-4
rs = []; phis = []; ts = []
for _ in range(int(60 / dt)):
    y = rk4(fk, y, t, dt); t += dt
    rs.append(np.linalg.norm(y[:3])); phis.append(math.atan2(y[1], y[0])); ts.append(t)
rs = np.array(rs); phis = np.unwrap(np.array(phis))
# local minima of r (perihelia), refine with parabola
peri = []
for i in range(1, len(rs) - 1):
    if rs[i] < rs[i - 1] and rs[i] <= rs[i + 1]:
        # parabolic refinement of the angle at the minimum
        y0, y1, y2 = rs[i - 1], rs[i], rs[i + 1]
        denom = (y0 - 2 * y1 + y2)
        off = 0.5 * (y0 - y2) / denom if denom != 0 else 0.0
        phi_min = phis[i] + off * (phis[i + 1] - phis[i])
        peri.append(phi_min)
adv = np.diff(peri) - 2 * math.pi
print('kepler numeric: successive perihelion angle differences minus 360 (deg):', np.degrees(adv))

# --- boost of fields ---
E = np.array([1.0, 2, 3]); B = np.array([4.0, 5, 6]); v = np.array([0.6, 0, 0])
gb = 1 / math.sqrt(1 - 0.36)
n_ = v / np.linalg.norm(v)
Epar = np.dot(E, n_) * n_; Eperp = E - Epar
Bpar = np.dot(B, n_) * n_; Bperp = B - Bpar
Ep = Epar + gb * (Eperp + np.cross(v, B))
Bp = Bpar + gb * (Bperp - np.cross(v, E))
out['q4_boost'] = [float(x) for x in np.concatenate([Ep, Bp])]
out['q4_E2mB2'] = float(np.dot(E, E) - np.dot(B, B))
out['q4_EdotB'] = float(np.dot(E, B))
print('boost:', out['q4_boost'])
print('invariants: E2-B2 =', out['q4_E2mB2'], np.dot(Ep, Ep) - np.dot(Bp, Bp), '  E.B =', out['q4_EdotB'], np.dot(Ep, Bp))
# cross-check via the field tensor F' = L F L^T
F = np.array([[0, -E[0], -E[1], -E[2]],
              [E[0], 0, -B[2], B[1]],
              [E[1], B[2], 0, -B[0]],
              [E[2], -B[1], B[0], 0]])      # F^{mu nu} with F^{0i} = -E_i, F^{ij} = -eps_ijk B_k
Lm = np.eye(4); Lm[0, 0] = Lm[1, 1] = gb; Lm[0, 1] = Lm[1, 0] = -gb * 0.6
Fp = Lm @ F @ Lm.T
Ep2 = np.array([-Fp[0, 1], -Fp[0, 2], -Fp[0, 3]]); Bp2 = np.array([Fp[3, 2], Fp[1, 3], Fp[2, 1]])
print('tensor check: E\' =', Ep2, ' B\' =', Bp2)

json.dump(out, open('./replication/runs/fable/_q3q4.json', 'w'), indent=1)
