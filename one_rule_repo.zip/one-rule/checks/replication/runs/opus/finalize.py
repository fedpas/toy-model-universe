#!/usr/bin/env python3
"""Assemble answers.json from computed_values.json (produced by solve.py) in template key order."""
import json

with open("answers_template.json") as f:
    template = json.load(f)
with open("computed_values.json") as f:
    vals = json.load(f)

methods = {
    "q1": "Derived from the (p-q) mod 8 Bott classification (recalled), and independently checked by computer: built each algebra from bit-label blades, used the centre/pseudoscalar square and the signature of the trace form <xy>_0 (d for M(d,R), -2d for M(d,H), 0 for complex) to identify K and d.",
    "q2": "Computed: sign = (-1)^(number of transpositions to reorder the generator word) times the squares of the shared generators; the fast bit rule was cross-checked against an explicit bubble sort for all 64x64 pairs.",
    "q3": "Derived by counting: Cl(k,k) = M(2^k,R) (also confirmed by the q1 code); dense schoolbook product has (2^n)^2 terms; schoolbook d x d matrix product has d^3 multiplications; 16x16 block product uses 16^3 Cl(N) products, ratio 4^8/16^3 = 16.",
    "q4": "Derived analytically (gyroradius gamma v/B, period 2 pi gamma/B; E x B drift; hyperbolic motion; plane-wave light-front invariants giving a^2/(4+a^2); Sommerfeld orbit equation u''+(1-kappa^2/L^2)u = const giving 360/sqrt(1-kappa^2/L^2)-360; field transformation and invariants) and every item cross-checked by RK4 integration of the relativistic Lorentz-force / Coulomb equations or by an explicit F^{mu nu} boost.",
    "q5": "Computed: enumerated all 240 roots and counted inner products, minimal-distance pairs, and roots orthogonal to every A2 pair (r0, r) with r.r0 = -1 (always 72, the E6 roots); matches the recalled E8 facts.",
    "q6": "Computed: built a_1..a_3 by Jordan-Wigner on an 8-dim space, formed T^k from the Gell-Mann matrices, and diagonalised the Casimir in each N-sector (0, 4/3, 4/3, 0, consistent with trivial, 3, 3bar, trivial).",
    "q7": "Derived (R e1 R~ = cos(theta) e1 + sin(theta) e2) and computed with a self-written geometric product in Cl(3,0); R(2 pi) = cos(pi) = -1.",
    "q8": "Computed from vis-viva with mu = G(M+m): 1/a = 2/r - v^2/mu, T = 2 pi sqrt(a^3/mu); period cross-checked by RK4 integration of the relative orbit.",
}

out = {}
for k in template:
    if k == "unsure":
        out[k] = []
    elif k == "methods":
        out[k] = methods
    else:
        out[k] = vals[k]

with open("answers.json", "w") as f:
    json.dump(out, f, indent=1)
print(json.dumps(out, indent=1))
