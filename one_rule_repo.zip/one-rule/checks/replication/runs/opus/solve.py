#!/usr/bin/env python3
"""Self-written solver for the blind replication brief (INSTRUCTIONS.md).
Only standard library + numpy. Prints intermediate checks and writes answers.json."""
import json, math, itertools
import numpy as np

ans = {}

# ---------------------------------------------------------------- Clifford core
def blade_sign(a, b, metric):
    """e_a e_b = s e_(a^b); metric[i] = +1/-1 is e_i^2. Blades ordered by increasing index."""
    s = 1
    # count transpositions: for each bit j of b, count bits i of a with i > j
    x = a >> 1
    while x:
        if bin(x & b).count("1") & 1:
            s = -s
        x >>= 1
    common = a & b
    i = 0
    while common:
        if common & 1:
            s *= metric[i]
        common >>= 1
        i += 1
    return s

def blade_sign_bruteforce(a, b, metric):
    """Independent check: write the generator word and bubble-sort it."""
    word = [i for i in range(len(metric)) if a >> i & 1] + [i for i in range(len(metric)) if b >> i & 1]
    s = 1
    w = word[:]
    changed = True
    while changed:
        changed = False
        for k in range(len(w) - 1):
            if w[k] > w[k + 1]:
                w[k], w[k + 1] = w[k + 1], w[k]
                s = -s
                changed = True
    # contract equal neighbours
    out = []
    for g in w:
        if out and out[-1] == g:
            out.pop()
            s *= metric[g]
        else:
            out.append(g)
    return s

# ---------------------------------------------------------------- q1
def classify(p, q):
    n = p + q
    metric = [1] * p + [-1] * q
    N = 1 << n
    diff = sum(blade_sign(A, A, metric) for A in range(N))   # signature of trace form
    I = N - 1
    I2 = blade_sign(I, I, metric)
    if n % 2 == 0:
        if diff > 0:
            d = diff; assert d * d == N; return f"M({d},R)"
        else:
            d = -diff // 2; assert 4 * d * d == N; return f"M({d},H)"
    else:
        if I2 == -1:
            assert diff == 0
            d = int(round(math.sqrt(N // 2))); assert 2 * d * d == N; return f"M({d},C)"
        if diff > 0:
            d = diff // 2; assert 2 * d * d == N; return f"M({d},R)+M({d},R)"
        d = -diff // 4; assert 8 * d * d == N; return f"M({d},H)+M({d},H)"

def classify_table(p, q):
    n = p + q
    r = (p - q) % 8
    if r in (0, 2):
        return f"M({2**(n//2)},R)"
    if r == 1:
        d = 2 ** ((n - 1) // 2); return f"M({d},R)+M({d},R)"
    if r in (3, 7):
        return f"M({2**((n-1)//2)},C)"
    if r in (4, 6):
        return f"M({2**((n-2)//2)},H)"
    if r == 5:
        d = 2 ** ((n - 3) // 2); return f"M({d},H)+M({d},H)"

sigs = [(1,0),(0,1),(2,0),(0,2),(1,1),(3,0),(0,3),(2,1),(1,3),(3,1),(4,4),(0,8),(5,3),(2,6),(6,0),(0,6)]
for p, q in sigs:
    c1, c2 = classify(p, q), classify_table(p, q)
    print("q1", p, q, c1, c2)
    assert c1 == c2
    ans[f"q1_{p}_{q}"] = c1

# ---------------------------------------------------------------- q2
metric6 = [1 if i % 2 == 0 else -1 for i in range(6)]
pairs = ["000110 001010", "101000 000101", "111111 111111", "010101 101010",
         "001000 001000", "011011 110110", "100001 010010", "000111 001110"]
q2 = []
for pr in pairs:
    a, b = (int(x, 2) for x in pr.split())
    s1 = blade_sign(a, b, metric6)
    s2 = blade_sign_bruteforce(a, b, metric6)
    assert s1 == s2
    q2.append(s1)
print("q2", q2)
ans["q2"] = q2
# global consistency check of the fast rule vs bubble sort on all pairs
for a in range(64):
    for b in range(64):
        assert blade_sign(a, b, metric6) == blade_sign_bruteforce(a, b, metric6)

# ---------------------------------------------------------------- q3
for k in (4, 5):
    assert classify(k, k) == f"M({2**k},R)"
ans["q3_size_4"] = 2 ** 4
ans["q3_size_5"] = 2 ** 5
ans["q3_terms_8"] = (2 ** 8) ** 2
ans["q3_terms_10"] = (2 ** 10) ** 2
ans["q3_mults_8"] = (2 ** 4) ** 3
ans["q3_mults_10"] = (2 ** 5) ** 3
ans["q3_blocks_products"] = 16 ** 3
# ratio: 4^(N+8) / (16^3 * 4^N) = 4^8/16^3
assert 4 ** 8 % 16 ** 3 == 0
ans["q3_ratio"] = 4 ** 8 // 16 ** 3
print("q3", {k: v for k, v in ans.items() if k.startswith("q3")})

# ---------------------------------------------------------------- q4
def lorentz_rhs(state, Efun, Bfun):
    # state = (t, x(3), u(3)) with u = gamma v, derivative wrt lab time t
    t, x, u = state[0], state[1:4], state[4:7]
    g = math.sqrt(1 + u @ u)
    v = u / g
    E, B = Efun(t, x), Bfun(t, x)
    return np.concatenate(([1.0], v, E + np.cross(v, B)))

def rk4(f, y, h, n, record=None):
    out = [y.copy()] if record else None
    for _ in range(n):
        k1 = f(y); k2 = f(y + h/2*k1); k3 = f(y + h/2*k2); k4 = f(y + h*k3)
        y = y + h/6*(k1 + 2*k2 + 2*k3 + k4)
        if record: out.append(y.copy())
    return (y, out) if record else y

# circular motion
v0 = 0.8; g0 = 1/math.sqrt(1 - v0**2)
ans["q4_radius"] = g0 * v0 / 1.0
ans["q4_period"] = 2 * math.pi * g0 / 1.0
# numerical check
Ez = lambda t, x: np.zeros(3)
Bz1 = lambda t, x: np.array([0, 0, 1.0])
y0 = np.array([0, 0, 0, 0, g0*v0, 0, 0], float)  # velocity along x... use y-dir below
y0 = np.array([0, 0, 0, 0, 0, g0*v0, 0], float)
h = ans["q4_period"] / 20000
_, traj = rk4(lambda y: lorentz_rhs(y, Ez, Bz1), y0, h, 20000, record=True)
traj = np.array(traj)
xs = traj[:, 1:3]
diam = np.max(np.linalg.norm(xs[:, None, :] - xs[None, ::200, :], axis=2))
print("q4 radius", ans["q4_radius"], "numeric diameter/2", diam/2,
      "return after one period", np.linalg.norm(traj[-1, 1:4]))

# E x B drift
E = np.array([3.0, 0, 0]); B = np.array([0, 0, 5.0])
vd = np.cross(E, B) / (B @ B)
ans["q4_drift_speed"] = float(np.linalg.norm(vd))
ans["q4_drift_vy"] = float(vd[1])
ans["q4_drift_gamma"] = 1/math.sqrt(1 - vd @ vd)
# numeric check from rest
y0 = np.zeros(7)
h = 1e-3; nst = 200000
yN = rk4(lambda y: lorentz_rhs(y, lambda t, x: E, lambda t, x: B), y0, h, nst)
print("q4 drift analytic", vd, "numeric mean vel from rest", yN[1:4] / yN[0], "(t=%g)" % yN[0])

# hyperbolic motion
t = 3.0
ans["q4_hyp_x"] = math.sqrt(1 + t*t) - 1
ans["q4_hyp_v"] = t / math.sqrt(1 + t*t)
yN = rk4(lambda y: lorentz_rhs(y, lambda t, x: np.array([1.0, 0, 0]), Ez), np.zeros(7), 1e-3, 3000)
print("q4 hyp", ans["q4_hyp_x"], ans["q4_hyp_v"], "numeric", yN[1], np.linalg.norm(yN[4:7])/math.sqrt(1+yN[4:7]@yN[4:7]))

# plane wave drift
a = 1.5
ans["q4_wave_drift"] = a*a / (4 + a*a)
Ew = lambda t, x: np.array([a*math.cos(t - x[2]), 0, 0])
Bw = lambda t, x: np.array([0, a*math.cos(t - x[2]), 0])
h = 2e-3; nst = 300000
yN = rk4(lambda y: lorentz_rhs(y, Ew, Bw), np.zeros(7), h, nst)
print("q4 wave drift analytic", ans["q4_wave_drift"], "numeric z/t", yN[3]/yN[0], "t", yN[0])

# relativistic Kepler
kap = 0.3; r0 = 1.0; vt = 0.5
gt = 1/math.sqrt(1 - vt**2)
L = r0 * gt * vt
omega = math.sqrt(1 - kap**2 / L**2)
ans["q4_kepler_deg"] = 360.0 / omega - 360.0
def kep_rhs(y):
    x, u = y[0:2], y[2:4]
    r = math.hypot(*x)
    g = math.sqrt(1 + u @ u)
    return np.concatenate((u / g, -kap * x / r**3))
y = np.array([r0, 0, 0, gt*vt])
h = 2e-4
peri = []
rprev2 = rprev = None; yprev = None
for i in range(400000):
    k1 = kep_rhs(y); k2 = kep_rhs(y + h/2*k1); k3 = kep_rhs(y + h/2*k2); k4 = kep_rhs(y + h*k3)
    ynew = y + h/6*(k1 + 2*k2 + 2*k3 + k4)
    # perihelion: radial velocity x.u changes sign from - to +; interpolate linearly
    s_old = y[:2] @ y[2:]; s_new = ynew[:2] @ ynew[2:]
    if s_old < 0 <= s_new:
        fr = -s_old / (s_new - s_old)
        yi = y + fr * (ynew - y)
        peri.append(math.atan2(yi[1], yi[0]))
    y = ynew
    if len(peri) >= 4:
        break
adv = []
for i in range(1, len(peri)):
    d = (peri[i] - peri[i-1]) % (2*math.pi)
    adv.append(math.degrees(d))
print("q4 kepler analytic", ans["q4_kepler_deg"], "numeric advances (mod 360)", adv,
      "E=", gt - kap/r0, "L=", L)

# field boost
v = np.array([0.6, 0, 0]); gb = 1/math.sqrt(1 - v @ v)
E = np.array([1.0, 2, 3]); B = np.array([4.0, 5, 6])
nhat = v / np.linalg.norm(v)
Epar = (E @ nhat) * nhat; Bpar = (B @ nhat) * nhat
Ep = Epar + gb * (E - Epar + np.cross(v, B))
Bp = Bpar + gb * (B - Bpar - np.cross(v, E))
# independent check with the field tensor F^{mu nu} and boost matrix
def Ftensor(E, B):
    Ex, Ey, Ez_ = E; Bx, By, Bz_ = B
    return np.array([[0, -Ex, -Ey, -Ez_],
                     [Ex, 0, -Bz_, By],
                     [Ey, Bz_, 0, -Bx],
                     [Ez_, -By, Bx, 0]])
Lam = np.array([[gb, -gb*0.6, 0, 0], [-gb*0.6, gb, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
Fp = Lam @ Ftensor(E, B) @ Lam.T
Ep2 = np.array([Fp[1, 0], Fp[2, 0], Fp[3, 0]])
Bp2 = np.array([Fp[3, 2], Fp[1, 3], Fp[2, 1]])
print("q4 boost", Ep, Bp, "tensor check", Ep2, Bp2)
assert np.allclose(Ep, Ep2) and np.allclose(Bp, Bp2)
ans["q4_boost"] = [float(round(x, 12)) for x in np.concatenate((Ep, Bp))]
ans["q4_E2mB2"] = float(E @ E - B @ B)
ans["q4_EdotB"] = float(E @ B)
print("q4 invariants", ans["q4_E2mB2"], Ep @ Ep - Bp @ Bp, ans["q4_EdotB"], Ep @ Bp)

# ---------------------------------------------------------------- q5
roots = []
for i, j in itertools.combinations(range(8), 2):
    for si in (1, -1):
        for sj in (1, -1):
            r = [0.0]*8; r[i] = si; r[j] = sj; roots.append(r)
for signs in itertools.product((0.5, -0.5), repeat=8):
    if sum(1 for s in signs if s < 0) % 2 == 0:
        roots.append(list(signs))
R = np.array(roots)
G = R @ R.T
r0v = np.array([1, 1, 0, 0, 0, 0, 0, 0.0])
ip = R @ r0v
ans["q5_roots"] = len(R)
ans["q5_ip1"] = int(np.sum(np.isclose(ip, 1)))
ans["q5_ip0"] = int(np.sum(np.isclose(ip, 0)))
D2 = np.sum((R[:, None, :] - R[None, :, :])**2, axis=2)
mind = np.min(D2[D2 > 1e-9])
ans["q5_edges"] = int(np.sum(np.isclose(D2, mind))) // 2
# A2: r1 = r0, r2 any root with ip -1 with r1
idx2 = [k for k in range(len(R)) if np.isclose(ip[k], -1)]
counts = set()
for k in idx2:
    counts.add(int(np.sum(np.isclose(ip, 0) & np.isclose(R @ R[k], 0))))
print("q5", len(R), ans["q5_ip1"], ans["q5_ip0"], "min dist^2", mind, ans["q5_edges"], "orth A2 counts", counts)
assert len(counts) == 1
ans["q5_orth_A2"] = counts.pop()

# ---------------------------------------------------------------- q6
I2 = np.eye(2); Z = np.diag([1.0, -1.0]); sm = np.array([[0, 1.0], [0, 0]])  # annihilator |1>->|0>
def kron(*ms):
    out = np.array([[1.0]])
    for m in ms: out = np.kron(out, m)
    return out
a_ops = [kron(*([Z]*i + [sm] + [I2]*(2 - i))) for i in range(3)]
for i in range(3):
    for j in range(3):
        assert np.allclose(a_ops[i] @ a_ops[j].T + a_ops[j].T @ a_ops[i], np.eye(8) * (i == j))
        assert np.allclose(a_ops[i] @ a_ops[j] + a_ops[j] @ a_ops[i], 0)
Nop = sum(a.T @ a for a in a_ops)
s3 = math.sqrt(3)
lam = [np.array(m, dtype=complex) for m in (
    [[0,1,0],[1,0,0],[0,0,0]], [[0,-1j,0],[1j,0,0],[0,0,0]], [[1,0,0],[0,-1,0],[0,0,0]],
    [[0,0,1],[0,0,0],[1,0,0]], [[0,0,-1j],[0,0,0],[1j,0,0]], [[0,0,0],[0,0,1],[0,1,0]],
    [[0,0,0],[0,0,-1j],[0,1j,0]], [[1/s3,0,0],[0,1/s3,0],[0,0,-2/s3]])]
for l in lam:
    assert abs(np.trace(l)) < 1e-12
    assert np.allclose(l, l.conj().T)
T = [sum((l[i, j]/2) * (a_ops[i].T @ a_ops[j]) for i in range(3) for j in range(3)) for l in lam]
# check the su(3) algebra closes: [T^a, T^b] should lie in span(T) (structure constants f_123 = 1)
assert np.allclose(T[0] @ T[1] - T[1] @ T[0], 1j * T[2])
C2 = sum(t @ t for t in T)
Nd = np.round(np.diag(Nop)).astype(int)
assert np.allclose(Nop, np.diag(np.diag(Nop)))
mult = [int(np.sum(Nd == n)) for n in range(4)]
cas = []
for n in range(4):
    idx = np.where(Nd == n)[0]
    blk = C2[np.ix_(idx, idx)]
    ev = np.linalg.eigvalsh(blk)
    assert np.allclose(ev, ev[0])
    cas.append(float(ev[0].real))
ans["q6_dim"] = 8
ans["q6_N_mult"] = mult
ans["q6_su3_dim"] = len(T)
ans["q6_casimir_by_N"] = [round(c, 12) for c in cas]
print("q6", mult, cas)

# ---------------------------------------------------------------- q7
metric3 = [1, 1, 1]
def gp(A, B, metric):
    out = {}
    for a, ca in A.items():
        for b, cb in B.items():
            s = blade_sign(a, b, metric)
            out[a ^ b] = out.get(a ^ b, 0) + s * ca * cb
    return {k: v for k, v in out.items() if abs(v) > 1e-15}
def rotor(theta):
    return {0: math.cos(theta/2), 0b011: -math.sin(theta/2)}
def rev(A):
    out = {}
    for k, v in A.items():
        g = bin(k).count("1")
        out[k] = v * (-1 if (g*(g-1)//2) % 2 else 1)
    return out
Rr = rotor(math.pi/2)
for i, key in zip(range(3), ("q7_Re1", "q7_Re2", "q7_Re3")):
    res = gp(gp(Rr, {1 << i: 1.0}, metric3), rev(Rr), metric3)
    vec = [res.get(1 << k, 0.0) for k in range(3)]
    others = {k: v for k, v in res.items() if bin(k).count("1") != 1 and abs(v) > 1e-12}
    assert not others
    vec = [float(round(c, 12)) + 0.0 for c in vec]
    print("q7", key, vec)
    ans[key] = vec
R2 = rotor(2*math.pi)
print("q7 R(2pi)", R2)
ans["q7_R2pi"] = float(round(R2[0], 12))

# ---------------------------------------------------------------- q8
Gc = 6.6703e-11; M = 5.97237e24; m = 7.342e22
mu = Gc * (M + m)
r = 362400e3; vv = 1085.0
inv_a = 2/r - vv*vv/mu
a_m = 1/inv_a
Tsec = 2*math.pi*math.sqrt(a_m**3/mu)
ans["q8_period_days"] = Tsec / 86400
ans["q8_semi_major_km"] = a_m / 1e3
ecc = abs(1 - r/a_m)  # start at an apsis since velocity perpendicular
print("q8 mu", mu, "a km", a_m/1e3, "T days", Tsec/86400, "e", ecc, "start is", "perigee" if r < a_m else "apogee")
# numerical check of period with RK4 (relative orbit)
def two_rhs(y):
    x, u = y[:2], y[2:]
    rr = math.hypot(*x)
    return np.concatenate((u, -mu * x / rr**3))
y = np.array([r, 0, 0, vv]); h = 60.0; tcur = 0.0; prev_y = y
crossed = False
while True:
    k1 = two_rhs(y); k2 = two_rhs(y + h/2*k1); k3 = two_rhs(y + h/2*k2); k4 = two_rhs(y + h*k3)
    yn = y + h/6*(k1 + 2*k2 + 2*k3 + k4)
    if y[1] < 0 <= yn[1] and tcur > 1e5:
        frac = -y[1] / (yn[1] - y[1])
        print("q8 numeric period days", (tcur + frac*h)/86400)
        break
    y = yn; tcur += h

# ---------------------------------------------------------------- write
template_keys = None
with open("answers_template.json") as f:
    template = json.load(f)
template_keys = [k for k in template if k not in ("unsure", "methods")]
missing = set(template_keys) - set(ans)
extra = set(ans) - set(template_keys)
assert not missing and not extra, (missing, extra)
print(json.dumps(ans, indent=1))
with open("computed_values.json", "w") as f:
    json.dump(ans, f, indent=1)
