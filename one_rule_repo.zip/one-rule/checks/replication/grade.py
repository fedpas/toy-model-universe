#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Grade an answers.json against reference/reference.json.   python3 grade.py runs/<name>/answers.json [--json out.json]
Integers and strings must match exactly; floats to a relative tolerance of 2e-3 (absolute 1e-6 when the reference is 0); lists elementwise.
A missing or null answer is a miss. The 'unsure' list is reported, and so is the split of misses into 'marked unsure' and 'confident'."""
import json, sys, os, math
here = os.path.dirname(os.path.abspath(__file__))
ref = json.load(open(os.path.join(here, 'reference', 'reference.json')))
ans = json.load(open(sys.argv[1]))
TOL = 2e-3
def close(a, b):
    if isinstance(b, str): return isinstance(a, str) and a.replace(' ', '') == b
    if isinstance(b, list): return isinstance(a, list) and len(a) == len(b) and all(close(x, y) for x, y in zip(a, b))
    if isinstance(b, bool) or a is None or isinstance(a, (str, list, dict, bool)): return False
    if isinstance(b, int): return isinstance(a, (int, float)) and float(a) == b
    return abs(a - b) <= max(1e-6, TOL * abs(b))
ids = [k for k in sorted(ref) if not k.startswith('_')]
unsure = set(ans.get('unsure') or [])
rows = []
for k in ids:
    ok = close(ans.get(k), ref[k]); rows.append({'id': k, 'ok': ok, 'unsure': k in unsure or any(k.startswith(u + '_') for u in unsure if u.startswith('q')), 'answer': ans.get(k), 'reference': ref[k]})
miss = [r for r in rows if not r['ok']]
blocks = {}
for r in rows:
    b = r['id'].split('_')[0]; blocks.setdefault(b, [0, 0]); blocks[b][1] += 1; blocks[b][0] += r['ok']
out = {'total': len(rows), 'correct': len(rows) - len(miss), 'blocks': {b: f'{c}/{t}' for b, (c, t) in sorted(blocks.items())}, 'misses': [{k: r[k] for k in ('id', 'answer', 'reference', 'unsure')} for r in miss],
       'confident_misses': [r['id'] for r in miss if not r['unsure']], 'unsure_listed': sorted(unsure), 'methods': ans.get('methods')}
print(f"{out['correct']}/{out['total']} correct   blocks: " + '  '.join(f'{b} {v}' for b, v in out['blocks'].items()))
for m in out['misses']: print('  MISS', m['id'], 'answered', json.dumps(m['answer']), '| reference', json.dumps(m['reference']), '(marked unsure)' if m['unsure'] else '')
print('confident misses:', len(out['confident_misses']), '   unsure listed:', len(out['unsure_listed']))
if '--json' in sys.argv: json.dump(out, open(sys.argv[sys.argv.index('--json') + 1], 'w'), indent=1)
