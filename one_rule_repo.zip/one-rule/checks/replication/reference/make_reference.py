#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The reference answers of the blind replication kit, computed here independently of the atlas code (numpy; nothing is imported from the app).
Each answer is derived by a route that differs from the one a replicator is likely to take (a table, a formula, a closed form), and where two routes exist both are run and compared.
  python3 make_reference.py            writes reference.json next to this file"""
import json, itertools, math, os
import numpy as np

R = {}
# ---- q1: the matrix algebra of Cl(p,q), e_i^2 = +1 for p generators and -1 for q (Lawson-Michelsohn / Porteous table by (p - q) mod 8); checked against 2^n = real dimension
def algebra(p, q):
    n = p + q; s = (p - q) % 8; d = lambda e: 2 ** e
    if s in (0, 2): out, dim = [(d(n // 2), 'R')], d(n // 2) ** 2
    elif s == 1: out, dim = [(d((n - 1) // 2), 'R')] * 2, 2 * d((n - 1) // 2) ** 2
    elif s in (3, 7): out, dim = [(d((n - 1) // 2), 'C')], 2 * d((n - 1) // 2) ** 2
    elif s in (4, 6): out, dim = [(d((n - 2) // 2), 'H')], 4 * d((n - 2) // 2) ** 2
    else: out, dim = [(d((n - 3) // 2), 'H')] * 2, 8 * d((n - 3) // 2) ** 2
    assert dim == 2 ** n, (p, q, dim)
    return '+'.join('M(%d,%s)' % x for x in out)
SIGS = [(1, 0), (0, 1), (2, 0), (0, 2), (1, 1), (3, 0), (0, 3), (2, 1), (1, 3), (3, 1), (4, 4), (0, 8), (5, 3), (2, 6), (6, 0), (0, 6)]
for p, q in SIGS: R['q1_%d_%d' % (p, q)] = algebra(p, q)
# a second route for a few of them: the real dimension of the centre and the squares of the pseudoscalar (the classical test); here only the quick consistency that every entry has real dimension 2^n was used above

# ---- q2: sign of e_a e_b by bubble-sorting the word of generators (not by the popcount formula)
N6 = 6; sq = lambda i: 1 if i % 2 == 0 else -1
def sign_by_sorting(a, b, n=N6):
    word = [i for i in range(n) if a >> i & 1] + [i for i in range(n) if b >> i & 1]; s = 1
    changed = True
    while changed:
        changed = False
        for k in range(len(word) - 1):
            if word[k] > word[k + 1]: word[k], word[k + 1] = word[k + 1], word[k]; s = -s; changed = True
    out = []; k = 0
    while k < len(word):
        if k + 1 < len(word) and word[k] == word[k + 1]: s *= sq(word[k]); k += 2
        else: out.append(word[k]); k += 1
    assert sum(1 << i for i in out) == a ^ b
    return s
PAIRS = [(0b000110, 0b001010), (0b101000, 0b000101), (0b111111, 0b111111), (0b010101, 0b101010), (0b001000, 0b001000), (0b011011, 0b110110), (0b100001, 0b010010), (0b000111, 0b001110)]
R['q2'] = [sign_by_sorting(a, b) for a, b in PAIRS]
# matrix cross-check: the same signs from an explicit real representation of Cl(3,3) by 8x8 matrices
def rep33():
    X = np.array([[0, 1], [1, 0]]); E = np.array([[0, 1], [-1, 0]]); Z = np.diag([1, -1]); I = np.eye(2, dtype=int); G = []
    for j in range(3):
        for last in (X, E):
            mats = [Z] * j + [last] + [I] * (2 - j); M = mats[0]
            for m in mats[1:]: M = np.kron(M, m)
            G.append(M)
    return G
G = rep33()
for i in range(6): assert (G[i] @ G[i] == sq(i) * np.eye(8, dtype=int)).all()
def blade(a):
    M = np.eye(8, dtype=int)
    for i in range(6):
        if a >> i & 1: M = M @ G[i]
    return M
for (a, b), s in zip(PAIRS, R['q2']): assert (blade(a) @ blade(b) == s * blade(a ^ b)).all()

# ---- q3: counts (arithmetic)
R['q3_size_4'] = 2 ** 4; R['q3_size_5'] = 2 ** 5
R['q3_terms_8'] = 4 ** 8; R['q3_terms_10'] = 4 ** 10
R['q3_mults_8'] = (2 ** 4) ** 3; R['q3_mults_10'] = (2 ** 5) ** 3
R['q3_blocks_products'] = 16 ** 3; R['q3_ratio'] = (4 ** 8) // (16 ** 3)

# ---- q4: charges and fields, c = 1
def rk4(f, y, t1, steps):
    h = t1 / steps; t = 0.0
    for _ in range(steps):
        k1 = f(t, y); k2 = f(t + h / 2, y + h / 2 * k1); k3 = f(t + h / 2, y + h / 2 * k2); k4 = f(t + h, y + h * k3); y = y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4); t += h
    return y
# a: circular orbit, B = 1 along z, q/m = 1, v = 0.8: radius gamma v / B and period 2 pi gamma / B; verified by integrating p' = v x B
v0 = 0.8; gam = 1 / math.sqrt(1 - v0 ** 2); R['q4_radius'] = gam * v0; R['q4_period'] = 2 * math.pi * gam
def lorentz(E, B):
    def f(t, y):
        p = y[3:6]; g = math.sqrt(1 + p @ p); v = p / g
        return np.concatenate([v, E(t, y) + np.cross(v, B(t, y))])
    return f
y = rk4(lorentz(lambda t, y: np.zeros(3), lambda t, y: np.array([0, 0, 1.0])), np.array([0, 0, 0, gam * v0, 0, 0]), 2 * math.pi * gam, 4000)
assert np.allclose(y[:3], 0, atol=1e-6) and np.allclose(y[3:6], [gam * v0, 0, 0], atol=1e-6)         # back where it started after one period
# b: crossed E = 3 x-hat, B = 5 z-hat: drift velocity E x B / B^2 = (0, -3/5, 0), gamma = 5/4  (checked: the mean velocity of an RK4 orbit)
Ef, Bf = np.array([3.0, 0, 0]), np.array([0, 0, 5.0])
R['q4_drift_speed'] = 3 / 5; R['q4_drift_vy'] = -3 / 5; R['q4_drift_gamma'] = 1 / math.sqrt(1 - 0.36)
y0 = np.zeros(6); T = 400.0; y = rk4(lorentz(lambda t, y: Ef, lambda t, y: Bf), y0, T, 40000)
assert abs(y[1] / T - (-0.6)) < 5e-3 and abs(y[0] / T) < 5e-3, y[:3] / T
# c: constant E = 1 x-hat, charge at rest at x = 0, q/m = 1, at t = 3
R['q4_hyp_x'] = math.sqrt(1 + 9) - 1; R['q4_hyp_v'] = 3 / math.sqrt(1 + 9)
y = rk4(lorentz(lambda t, y: np.array([1.0, 0, 0]), lambda t, y: np.zeros(3), ), np.zeros(6), 3.0, 3000)
assert abs(y[0] - R['q4_hyp_x']) < 1e-9 and abs(y[3] / math.sqrt(1 + y[3] ** 2) - R['q4_hyp_v']) < 1e-9
# d: plane wave E = (a cos(t - z), 0, 0), B = (0, a cos(t - z), 0), a = 1.5, q/m = 1, at rest: mean dz/dt over many periods = a^2/(4 + a^2)
a = 1.5; R['q4_wave_drift'] = a * a / (4 + a * a)
def wave(t, y): ph = math.cos(t - y[2]); return np.array([a * ph, 0, 0]), np.array([0, a * ph, 0])
def fw(t, y):
    E, B = wave(t, y); p = y[3:6]; g = math.sqrt(1 + p @ p); v = p / g; return np.concatenate([v, E + np.cross(v, B)])
T = 400 * math.pi; y = rk4(fw, np.zeros(6), T, 100000); R['_wave_numeric'] = y[2] / T
assert abs(y[2] / T - R['q4_wave_drift']) < 2e-3, y[2] / T
# e: Kepler with relativistic momentum, d(gamma v)/dt = -kappa r-hat / r^2, kappa = 0.3, start r = 1, tangential v = 0.5: angle between successive perihelia
kappa = 0.3; L = 0.5 / math.sqrt(1 - 0.25); R['q4_kepler_deg'] = math.degrees(2 * math.pi * (1 / math.sqrt(1 - kappa ** 2 / L ** 2) - 1))
def kep(t, y):
    r = y[:2]; p = y[2:]; rr = math.hypot(*r); g = math.sqrt(1 + p @ p); return np.concatenate([p / g, -kappa * r / rr ** 3])
y = np.array([1.0, 0, 0, 0.5 / math.sqrt(0.75)]); y = np.array([1.0, 0.0, 0.0, 0.5 / math.sqrt(0.75)])
h = 1e-3; t = 0.0; rs = []; ths = []; prev = None
while t < 60:
    y = rk4(kep, y, h, 1); t += h; rs.append(math.hypot(y[0], y[1])); ths.append(math.atan2(y[1], y[0]))
rs = np.array(rs); ths = np.unwrap(np.array(ths))
peri = [i for i in range(1, len(rs) - 1) if rs[i] < rs[i - 1] and rs[i] <= rs[i + 1]]
assert len(peri) >= 3
adv = [math.degrees(ths[peri[i + 1]] - ths[peri[i]] - 2 * math.pi) for i in range(len(peri) - 1)]
R['_kepler_numeric'] = adv
assert all(abs(x - R['q4_kepler_deg']) < 0.05 for x in adv), (adv, R['q4_kepler_deg'])
# f: boost along +x (the new frame moves with velocity v = 0.6 x-hat relative to the old one): E' = gamma (E + v_frame-less...) written out from the field tensor
Evec, Bvec = np.array([1.0, 2, 3]), np.array([4.0, 5, 6]); vb = 0.6; gb = 1 / math.sqrt(1 - vb ** 2)
F = np.zeros((4, 4))                       # F^{mu nu}, signature (+,-,-,-): F^{0i} = -E_i, F^{ij} = -eps_{ijk} B_k
for i in range(3):
    F[0, i + 1] = -Evec[i]; F[i + 1, 0] = Evec[i]
for i, j, k in itertools.permutations(range(3)):
    F[i + 1, j + 1] = -np.sign(np.linalg.det(np.eye(3)[[i, j, k]])) * Bvec[k]
Lm = np.eye(4); Lm[0, 0] = Lm[1, 1] = gb; Lm[0, 1] = Lm[1, 0] = -gb * vb          # coordinates of the new frame: x'^0 = gamma(t - v x), x'^1 = gamma(x - v t)
Fp = Lm @ F @ Lm.T
Ep = np.array([Fp[1, 0], Fp[2, 0], Fp[3, 0]]); Bp = np.array([-Fp[2, 3], -Fp[3, 1], -Fp[1, 2]])
R['q4_boost'] = [round(float(x), 9) for x in list(Ep) + list(Bp)]
assert abs(Ep @ Ep - Bp @ Bp - (Evec @ Evec - Bvec @ Bvec)) < 1e-9 and abs(Ep @ Bp - Evec @ Bvec) < 1e-9
R['q4_E2mB2'] = float(Evec @ Evec - Bvec @ Bvec); R['q4_EdotB'] = float(Evec @ Bvec)

# ---- q5: the E8 root system, by enumeration
roots = []
for i, j in itertools.combinations(range(8), 2):
    for si in (1, -1):
        for sj in (1, -1):
            v = [0] * 8; v[i] = si; v[j] = sj; roots.append(tuple(2 * x for x in v))                     # doubled coordinates: ints
for signs in itertools.product((1, -1), repeat=8):
    if signs.count(-1) % 2 == 0: roots.append(tuple(signs))
A = np.array(roots); G8 = A @ A.T                                                                             # inner products times 4 (doubled coordinates)
assert (np.diag(G8) == 8).all()
R['q5_roots'] = len(roots)
r0 = roots.index((2, 2, 0, 0, 0, 0, 0, 0)); R['q5_ip1'] = int((G8[r0] == 4).sum()); R['q5_ip0'] = int((G8[r0] == 0).sum())
R['q5_edges'] = int((G8 == 4).sum() // 2)
a1 = r0; a2 = int(np.where(G8[r0] == -4)[0][0]); R['q5_orth_A2'] = int(((G8[a1] == 0) & (G8[a2] == 0)).sum())

# ---- q6: three fermionic modes (Jordan-Wigner), SU(3) from the bilinears a_i^dag a_j
I2 = np.eye(2); Zp = np.diag([1., -1.]); lo = np.array([[0, 1.], [0, 0]])                                      # annihilation on one mode: |1> -> |0>
a = [np.kron(np.kron(lo, I2), I2), np.kron(np.kron(Zp, lo), I2), np.kron(np.kron(Zp, Zp), lo)]
for i in range(3):
    for j in range(3):
        anti = a[i] @ a[j].T + a[j].T @ a[i]; assert np.allclose(anti, (i == j) * np.eye(8))
Nop = sum(x.T @ x for x in a); lam = []
lam += [np.array([[0, 1, 0], [1, 0, 0], [0, 0, 0]]), np.array([[0, -1j, 0], [1j, 0, 0], [0, 0, 0]]), np.diag([1, -1, 0]), np.array([[0, 0, 1], [0, 0, 0], [1, 0, 0]]), np.array([[0, 0, -1j], [0, 0, 0], [1j, 0, 0]]),
        np.array([[0, 0, 0], [0, 0, 1], [0, 1, 0]]), np.array([[0, 0, 0], [0, 0, -1j], [0, 1j, 0]]), np.diag([1, 1, -2]) / math.sqrt(3)]
T = [sum(lam[k][i, j] * a[i].T @ a[j] for i in range(3) for j in range(3)) / 2 for k in range(8)]
C2 = sum(t @ t for t in T); Nd = np.round(np.diag(Nop)).astype(int)
R['q6_dim'] = 8; R['q6_N_mult'] = [int((Nd == n).sum()) for n in range(4)]
R['q6_casimir_by_N'] = [round(float(np.real(np.mean(np.diag(C2)[Nd == n]))), 9) for n in range(4)]
assert all(np.allclose(np.diag(C2)[Nd == n], np.diag(C2)[Nd == n][0]) for n in range(4))
R['q6_su3_dim'] = 8
# ---- q7: Cl(3,0) with Pauli matrices
s1 = np.array([[0, 1], [1, 0]], complex); s2 = np.array([[0, -1j], [1j, 0]]); s3 = np.diag([1, -1]).astype(complex); th = math.pi / 2
Rr = math.cos(th / 2) * np.eye(2) - math.sin(th / 2) * (s1 @ s2); Rt = math.cos(th / 2) * np.eye(2) + math.sin(th / 2) * (s1 @ s2)     # R and its reverse
def vec(M): return [round(float(np.real(np.trace(M @ s) / 2)), 9) + 0.0 for s in (s1, s2, s3)]
R['q7_Re1'] = vec(Rr @ s1 @ Rt); R['q7_Re2'] = vec(Rr @ s2 @ Rt); R['q7_Re3'] = vec(Rr @ s3 @ Rt)
th = 2 * math.pi; R2 = math.cos(th / 2) * np.eye(2) - math.sin(th / 2) * (s1 @ s2); R['q7_R2pi'] = round(float(np.real(np.trace(R2) / 2)), 9)
# ---- q8: the Moon, relative two-body orbit by vis-viva and Kepler's third law
G_, M_, m_, r_, v_ = 6.6703e-11, 5.97237e24, 7.342e22, 362400e3, 1085.0
mu = G_ * (M_ + m_); inv_a = 2 / r_ - v_ * v_ / mu; a_ = 1 / inv_a; R['q8_period_days'] = 2 * math.pi * math.sqrt(a_ ** 3 / mu) / 86400
R['q8_semi_major_km'] = a_ / 1e3
json.dump(R, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'reference.json'), 'w'), indent=1, sort_keys=True)
print('reference.json written:', len([k for k in R if not k.startswith('_')]), 'answers')
print({k: R[k] for k in R if k.startswith('q4_') or k.startswith('q8_')})
print('numeric cross-checks:', R['_wave_numeric'], R['_kepler_numeric'][:3])
