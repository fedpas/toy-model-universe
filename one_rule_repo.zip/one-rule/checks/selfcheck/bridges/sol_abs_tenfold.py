#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sol_abs_tenfold.py: from the bit rule's own modules to the d = 0 column of the periodic table of topological phases.

  bd·sol·25  for k = 0..10 an irreducible real module of Cl(0,k) is built inside the bit-rule regular representation as the minimal left ideal
             A P, P = prod (1 + e_a)/2 over a maximal set of commuting blades of square +1 (a totally singular subspace, W1 of T11); its
             dimension and the number of irreducible modules (2 exactly when the central top blade squares to +1) agree with the type table;
             restricting the irreducible module(s) of Cl(0,k) to Cl(0,k-1) gives the integer matrix i*, and the Atiyah-Bott-Shapiro cokernel
             A_k = M(Cl(0,k-1)) / i* M(Cl(0,k)) (Smith normal form) is, for k = 1..10, Z2, Z2, 0, Z, 0, 0, 0, Z, Z2, Z2 = KO^{-k}(point) =
             pi_0(R_k), the d = 0 entries of the eight real symmetry classes.
  bd·sol·26  (info, arithmetic on the complex type counts, not a check) the complex case: Cl(0,k) (x) C has 1 or 2 irreducible modules (k even /
             odd); the same cokernel gives 0, Z, 0, Z, ... for k = 1..10 = KU^{-k}(point) = pi_0(C_k), the two complex classes (A, AIII).

  python3 sol_abs_tenfold.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; about a second."""
import sys
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

def left_right(k):
    eps = [-1] * k; N = 1 << k
    L = []; R = {}
    for i in range(k):
        M = np.zeros((N, N))
        for b in range(N): M[b ^ (1 << i), b] = sgn(1 << i, b, eps)
        L.append(M)
    def Rmat(a):
        M = np.zeros((N, N))
        for b in range(N): M[b ^ a, b] = sgn(b, a, eps)
        return M
    return eps, L, Rmat
def commuting_singular(k, eps):
    N = 1 << k; top = N - 1
    chosen = []; span = {0}
    order = ([top] if k and sgn(top, top, eps) == 1 and all(sgn(top, 1 << i, eps) == sgn(1 << i, top, eps) for i in range(k)) else []) + list(range(1, N))
    for a in order:
        if a in span or sgn(a, a, eps) != 1: continue
        if all(sgn(a, b, eps) == sgn(b, a, eps) for b in span):
            # the whole new span must square to +1
            new = {s ^ a for s in span}
            if all(sgn(x, x, eps) == 1 for x in new):
                chosen.append(a); span |= new
    return chosen
def irrep(k):
    """orthonormal basis B of a minimal left ideal and the restricted generators; number of irreducible modules"""
    eps, L, Rmat = left_right(k); N = 1 << k
    gens = commuting_singular(k, eps)
    P = np.eye(N)
    for a in gens: P = P @ (np.eye(N) + Rmat(a)) / 2
    U, s, _ = np.linalg.svd(P); B = U[:, s > 1e-9]
    Lr = [B.T @ M @ B for M in L]
    top = N - 1
    central_plus = k % 2 == 1 and sgn(top, top, eps) == 1
    return B, Lr, (2 if central_plus else 1), len(gens)
TYPE = {0: ('R', 1), 1: ('C', 2), 2: ('H', 4), 3: ('H', 4), 4: ('H', 8), 5: ('C', 8), 6: ('R', 8), 7: ('R', 8)}   # Cl(0,k): (D, irrep dim) for k mod 8, period 8 with factor 16
def expected_dim(k): return TYPE[k % 8][1] * 16 ** (k // 8)
def smith_coker(M, ncols):
    """cokernel of the integer row-span of M in Z^ncols, as a list of invariants (0 meaning Z)"""
    M = [list(map(int, r)) for r in M]
    import math
    if ncols == 1:
        g = 0
        for r in M: g = math.gcd(g, abs(r[0]))
        return [g] if g != 1 else []
    # ncols == 2: rank and gcd of 2x2 minors and entries
    rows_ = [r for r in M if any(r)]
    if not rows_: return [0, 0]
    d1 = 0
    for r in rows_:
        for x in r: d1 = math.gcd(d1, abs(x))
    d2 = 0
    for i in range(len(rows_)):
        for j in range(i + 1, len(rows_)):
            d2 = math.gcd(d2, abs(rows_[i][0] * rows_[j][1] - rows_[i][1] * rows_[j][0]))
    rank = 2 if d2 else 1
    inv = []
    if d1 != 1: inv.append(d1)
    if rank == 2:
        if d2 // d1 != 1: inv.append(d2 // d1)
    else: inv.append(0)
    return inv
def fmt(inv):
    if not inv: return '0'
    return '+'.join('Z' if x == 0 else f'Z{x}' for x in inv)
def check25_26():
    ok = True; dims = {}; nirr = {}; data = {}
    for k in range(0, 11):
        B, Lr, m, w = irrep(k)
        dims[k] = B.shape[1]; nirr[k] = m; data[k] = (B, Lr)
        ok &= dims[k] == expected_dim(k)
        ok &= all(np.allclose(X @ X, -np.eye(dims[k])) for X in Lr)
        ok &= all(np.allclose(Lr[i] @ Lr[j] + Lr[j] @ Lr[i], 0) for i in range(k) for j in range(i))
    seq = []
    for k in range(1, 11):
        B, Lr = data[k]
        # restrict to the first k-1 generators
        sub = Lr[:k - 1]; dsub = dims[k - 1]
        if nirr[k - 1] == 2:
            om = np.eye(dims[k])
            for X in sub: om = om @ X
            tr = np.trace(om); mp = (dims[k] + tr) / (2 * dsub); mm = (dims[k] - tr) / (2 * dsub)
            rows_ = [[round(mp), round(mm)]] * nirr[k]
            ok &= abs(mp - round(mp)) < 1e-9 and abs(mm - round(mm)) < 1e-9
        else:
            mult = dims[k] / dsub; ok &= abs(mult - round(mult)) < 1e-9
            rows_ = [[round(mult)]] * nirr[k]
        seq.append(fmt(smith_coker(rows_, nirr[k - 1])))
    want = ['Z2', 'Z2', '0', 'Z', '0', '0', '0', 'Z', 'Z2', 'Z2']
    row('bd·sol·25', ok and seq == want, f'irreducible real modules of Cl(0,k) from the bit rule, dims {[dims[k] for k in range(11)]}, number {[nirr[k] for k in range(11)]}; ABS cokernels A_k (k = 1..10): {seq} = KO^(-k)(pt)')
    # complex: number of irreducible complex modules 1 (k even) or 2 (k odd), complex dims 2^floor(k/2)
    cseq = []
    for k in range(1, 11):
        n_sub = 2 if (k - 1) % 2 == 1 else 1; n_top = 2 if k % 2 == 1 else 1
        dsub = 2 ** ((k - 1) // 2); dtop = 2 ** (k // 2)
        if n_sub == 2: rows_ = [[dtop // (2 * dsub), dtop // (2 * dsub)]] * n_top
        else: rows_ = [[dtop // dsub]] * n_top
        cseq.append(fmt(smith_coker(rows_, n_sub)))
    cwant = ['0', 'Z', '0', 'Z', '0', 'Z', '0', 'Z', '0', 'Z']
    info('bd·sol·26', f'complex Cl(0,k) (x) C: the ABS cokernels (k = 1..10) from the counts of complex modules are {cseq}, KU^(-k)(pt): {cseq == cwant}')

if __name__ == '__main__':
    check25_26()
    finish()
