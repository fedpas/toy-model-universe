#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjp_time.py: time as a weight in arXiv:2403.19689 (v3) (its norm (9), the Galilean boosts and the speed limit of its footnote 7): proper
time against an additive weight, the boost-invariant linear weights of Galilei, Lorentz and Carroll, the null rotation of Cl(2,0,1), and the
paper's data read as events of a Galilean space-time with a speed limit.

    python3 selfcheck/bridges/mjp_time.py              one line per check, ids bd·mjp·23 .. bd·mjp·27; exit 1 on any FAIL
    python3 selfcheck/bridges/mjp_time.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library (fractions) and numpy; exact rational arithmetic for the Lorentzian statements; random data from seeded generators; under
1 s on one core; reads and writes no file; runs from any folder, also with python3 -I.
  bd·mjp·23  an additive weight (9) is not a Lorentzian interval: in the bit-rule Cl(1,3) the arrows u = g0 and v = (5/4) g0 + (3/4) g1 have
             proper time 1 each and (u + v)^2 = 9/2 > 4 = (1 + 1)^2; for 200 random future-timelike rational pairs the proper time is strictly
             super-additive in 200 (reverse Cauchy-Schwarz, exact), the squared interval is additive in 0 (u.v > 0); the same count in Cl(3,1)
             (time generator of square -1, tau^2 = -v^2); in Cl(3,0) the length is strictly sub-additive in 200 (seed 23).  The time component
             is additive because it is linear (printed, not counted).
  bd·mjp·24  signs along a chain of arrows: the sum of k <= 6 future-timelike arrows is future-timelike with proper time at least the sum (200 random
             chains); two spacelike arrows can sum to a timelike, a null or a spacelike arrow ((1, 3/2) + (1, -3/2) = (2, 0); (0, 1) + (1, -2) = (1, -1);
             (0, 1) + (0, 1)): outside the cone the sign of the composite is not a function of the signs of the legs (Cl(1,3) and Cl(3,1)).
  bd·mjp·25  linear weights that every boost and rotation keeps: on R^{1+d} (d = 2, 3) the invariant covectors form a space of dimension 1 for
             Galilei (dt), 0 for Lorentz, 0 for Carroll; the invariant vectors: 0, 0, 1 (d/dt).  An additive weight that the boosts keep exists for
             absolute (Galilean) time only.
  bd·mjp·26  the null rotation of Cl(2,0,1) (bit rule, e0 null): the motor M = 1 + (v/2) e0 e1 acts on the vectors as the Carroll boost
             t -> t + v x (x, y unchanged) and on the bivectors (the points of the plane-based reading) as the Galilei boost x -> x - v t (t = the
             e12 coefficient), the inverse transpose; the bivectors e12, e01, e02 close to iso(2) with the brackets of the homogeneous Galilei
             algebra of the plane (J, K1, K2) under J -> e12/2, K_i -> e0 e_i, with J^2 = -1/4 and K1^2 = 0 (exact, v in {1/3, 2, -5/7}).
  bd·mjp·27  the paper's data as events: X(f) = (||f||, D(f)) in R x R^2 (additive on composition by construction: differences of a
             potential E and of the positions P), and the speed-1 reading ||f|| > |D(f)| (footnote 7)
             is kept by composition (200 random weighted categories B_3 with random positions); a Galilei boost (v = 0.9) keeps every weight and
             takes arrows out of the cone, a Lorentz boost of R^{1,2} keeps the cone and changes the weights; the linear maps that keep both dt
             and the cone form so(2) (dimension 1, the rotations of the plane Z0) (seed 27).
"""
import sys, itertools
from fractions import Fraction as Fr
import numpy as np

SAB = '--sabotage' in sys.argv
ROWS, FAILS = [], []
def report(cid, ok, text, short):
    ROWS.append(cid)
    if SAB:
        print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  ' + short + '\n       the sabotaged run computes: ' + text)
        if ok: FAILS.append(cid)
    else:
        print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
        if not ok: FAILS.append(cid)
def finish():
    if SAB:
        print('\n' + ('ALL CAUGHT' if not FAILS else f'{len(FAILS)} MISSED: ' + ' '.join(FAILS)))
    else:
        print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def mul(x, y, eps):
    """bit-rule product of multivectors given as dicts label -> Fraction"""
    z = {}
    for a, xa in x.items():
        for b, yb in y.items():
            s = sgn(a, b, eps)
            if s:
                z[a ^ b] = z.get(a ^ b, 0) + s * xa * yb
    return {k: v for k, v in z.items() if v != 0}
def vec(comps):
    return {1 << i: Fr(c) for i, c in enumerate(comps) if c != 0}
def scal(x): return x.get(0, Fr(0))
def square(v, eps): return scal(mul(v, v, eps))
def add(x, y, s=1):
    z = dict(x)
    for k, v in y.items(): z[k] = z.get(k, 0) + s * v
    return {k: v for k, v in z.items() if v != 0}

def rand_timelike(rng, d=3):
    xs = [Fr(int(rng.integers(-9, 10)), int(rng.integers(1, 10))) for _ in range(d)]
    t = sum(abs(x) for x in xs) + Fr(int(rng.integers(1, 10)), int(rng.integers(1, 10)))   # t > |x|_1 >= |x|_2
    return [t] + xs

def check23(sab):
    rng = np.random.default_rng(23)
    L = [1, -1, -1, -1]; Lm = [-1, 1, 1, 1]; Eu = [1, 1, 1]
    u = vec([1, 0, 0, 0]); v = vec([Fr(5, 4), Fr(3, 4), 0, 0])
    tu, tv, tuv = square(u, L), square(v, L), square(add(u, v), L)
    ex_ok = tu == 1 and tv == 1 and tuv == Fr(9, 2)
    sup = sq_add = t_add = sup_m = sub_e = 0
    for _ in range(200):
        a = rand_timelike(rng); b = rand_timelike(rng)
        if sab: b = [x * 3 for x in a]                     # sabotage: collinear pairs only (proper time is additive on a ray)
        A, B = vec(a), vec(b)
        uu, vv, uv2 = square(A, L), square(B, L), square(add(A, B), L)
        dot = (uv2 - uu - vv) / 2
        sup += dot > 0 and dot * dot > uu * vv               # tau(a+b) > tau(a) + tau(b)  <=>  a.b > sqrt(a^2 b^2)
        sq_add += uv2 == uu + vv
        t_add += (a[0] + b[0]) == add(A, B).get(1, 0)    # linear: printed, not counted
        uu, vv, uv2 = -square(A, Lm), -square(B, Lm), -square(add(A, B), Lm)
        dot = (uv2 - uu - vv) / 2
        sup_m += dot > 0 and dot * dot > uu * vv
        A3, B3 = vec(a[1:]), vec(b[1:])
        ee, ff, ef2 = square(A3, Eu), square(B3, Eu), square(add(A3, B3), Eu)
        dot = (ef2 - ee - ff) / 2
        sub_e += dot * dot < ee * ff                         # |a+b| < |a| + |b|  <=>  a.b < |a||b|
    ok = ex_ok and sup == 200 and sq_add == 0 and sup_m == 200 and sub_e == 200
    return ok, (f'u = g0, v = (5/4)g0 + (3/4)g1: u^2 = {tu}, v^2 = {tv}, (u+v)^2 = {tuv} against (tau_u + tau_v)^2 = 4; random future-timelike pairs '
                f'(seed 23): super-additive {sup}/200, squared interval additive {sq_add}/200; Cl(3,1): super-additive {sup_m}/200; Cl(3,0) lengths: '
                f'strictly sub-additive {sub_e}/200; the time component is additive in {t_add}/200 (linear, not counted)')

def check24(sab):
    rng = np.random.default_rng(24); L = [1, -1, -1, -1]; ok = True; good = 0
    for _ in range(200):
        k = int(rng.integers(2, 7))
        legs = [rand_timelike(rng) for _ in range(k)]
        if sab: legs[-1] = [-x for x in legs[-1]]          # sabotage: one past-directed leg
        S = vec([0, 0, 0, 0]); taus2 = []
        for l in legs:
            S = add(S, vec(l)); taus2.append(square(vec(l), L))
        s2 = square(S, L); t = S.get(1, 0)
        # tau(S) >= sum tau_i  <=>  s2 >= (sum sqrt(taus2))^2 ; checked in floating point after the exact sign test
        fut = s2 > 0 and t > 0 and float(s2) ** 0.5 >= sum(float(x) ** 0.5 for x in taus2) - 1e-12
        good += fut
    ok &= good == 200
    ex = []
    for conv, eps in (('Cl(1,3)', [1, -1]), ('Cl(3,1)', [-1, 1])):
        sgn_t = 1 if eps[0] == 1 else -1                    # the sign of the square of a timelike vector in this convention
        def kind(v):
            q = square(vec(v), eps) * sgn_t
            return 'timelike' if q > 0 else ('null' if q == 0 else 'spacelike')
        pairs = [([1, Fr(3, 2)], [1, Fr(-3, 2)]), ([0, 1], [1, -2]), ([0, 1], [0, 1])]
        res = [(kind(a), kind(b), kind([x + y for x, y in zip(a, b)])) for a, b in pairs]
        ex.append(conv + ': ' + ', '.join(f'{r[0]}+{r[1]}={r[2]}' for r in res))
        ok &= [r[2] for r in res] == ['timelike', 'null', 'spacelike'] and all(r[0] == r[1] == 'spacelike' for r in res)
    return ok, f'future-timelike chains of 2..6 arrows: composite future-timelike with tau >= sum in {good}/200 (seed 24); ' + '; '.join(ex)

def gens(kind, d):
    m = d + 1; G = []
    for i in range(1, m):
        for j in range(i + 1, m):
            R = np.zeros((m, m)); R[i, j] = 1; R[j, i] = -1; G.append(R)
    for i in range(1, m):
        K = np.zeros((m, m))
        if kind == 'Galilei': K[i, 0] = 1                 # x_i += v t
        elif kind == 'Lorentz': K[i, 0] = 1; K[0, i] = 1
        elif kind == 'Carroll': K[0, i] = 1               # t += v x_i
        G.append(K)
    return G
def common_kernel(mats):
    M = np.vstack(mats)
    return M.shape[1] - np.linalg.matrix_rank(M)
def check25(sab):
    want = {'Galilei': (1, 0), 'Lorentz': (0, 0), 'Carroll': (0, 1)}
    res = {}; ok = True
    for d in (2, 3):
        for kind in ('Galilei', 'Lorentz', 'Carroll'):
            G = gens(kind, d)
            if sab: G = G[: d * (d - 1) // 2]              # sabotage: rotations only (no boosts)
            cov = common_kernel([g.T for g in G]); vv = common_kernel(G)
            res[(kind, d)] = (int(cov), int(vv)); ok &= (cov, vv) == want[kind]
    return ok, ('invariant (covectors, vectors) of rotations + boosts on R^{1+d}: ' +
                ', '.join(f'{k} d={d}: {res[(k, d)]}' for d in (2, 3) for k in ('Galilei', 'Lorentz', 'Carroll')))

def check26(sab):
    eps = [0, 1, 1]                                         # e0 null (label 1), e1 (label 2), e2 (label 4)
    ok = True; txt = []
    for v in (Fr(1, 3), Fr(2), Fr(-5, 7)):
        e01 = 1 | 2
        s01 = sgn(1, 2, eps)                                # e0 e1 = s01 e_{01}
        B = {e01: Fr(s01)}                                   # the bivector e0 e1
        if sab: B = {2 | 4: Fr(1)}                           # sabotage: the rotation bivector e1 e2 in place of the null one
        M = add({0: Fr(1)}, {k: x * v / 2 for k, x in B.items()})
        Mr = add({0: Fr(1)}, {k: -x * v / 2 for k, x in B.items()})   # reversion flips the sign of a bivector
        def act(x): return mul(mul(M, x, eps), Mr, eps)
        g1 = [1, 2, 4]                                      # e0, e1, e2
        A1 = [[act({c: Fr(1)}).get(r, Fr(0)) for c in g1] for r in g1]
        carroll = [[1, v, 0], [0, 1, 0], [0, 0, 1]]
        # bivectors in the complement basis of (e0, e1, e2): e12 (6), e02 (5), e01 (3), with the signs of x -> x e_top (a duality map)
        top = 7
        def dual(a): return mul({a: Fr(1)}, {top: Fr(1)}, [1, 1, 1])     # complement with a non-degenerate metric (one sign table, that of Cl(3,0))
        g2 = [6, 5, 3]
        sg = [dual(c)[c ^ top] for c in g1]                 # e_c e_top = sg * e_(c ^ top) in Cl(3,0)
        A2 = [[act({g2[c]: sg[c]}).get(g2[r], Fr(0)) * sg[r] for c in range(3)] for r in range(3)]
        galilei = [[1, 0, 0], [-v, 1, 0], [0, 0, 1]]
        prod = [[sum(A2[i][k] * A1[j][k] for k in range(3)) for j in range(3)] for i in range(3)]   # A2 A1^T
        inv_t = prod == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
        good = A1 == carroll and A2 == galilei and inv_t
        ok &= good
        txt.append(f'v = {v}: vectors {"Carroll" if A1 == carroll else A1}, bivectors {"Galilei (x -> x - v t)" if A2 == galilei else A2}, A2 = A1^-T {inv_t}')
    # brackets: J = e12/2, K1 = e0 e1, K2 = e0 e2 against [J, K1] = -K2, [J, K2] = K1, [K1, K2] = 0, the brackets of the rotation J and the
    # boosts K1, K2 of the Galilei matrices on (t, x, y) (the homogeneous Galilei algebra of the plane)
    def br(x, y): return add(mul(x, y, eps), mul(y, x, eps), -1)
    J = {6: Fr(sgn(2, 4, eps), 2)}
    K1 = {3: Fr(sgn(1, 2, eps))}; K2 = {5: Fr(sgn(1, 4, eps))}
    gal = [[0, 0, 0], [0, 0, 1], [0, -1, 0]]
    Gt = gens('Galilei', 2)                                 # R, K1, K2 as 3x3 matrices on (t, x, y)
    Jm, K1m, K2m = Gt[0], Gt[1], Gt[2]
    def mbr(a, b): return a @ b - b @ a
    mat_ok = np.allclose(mbr(Jm, K1m), -K2m) and np.allclose(mbr(Jm, K2m), K1m) and np.allclose(mbr(K1m, K2m), 0)
    cl_ok = br(J, K1) == {k: -x for k, x in K2.items()} and br(J, K2) == K1 and br(K1, K2) == {}
    sq = (scal(mul(J, J, eps)), scal(mul(K1, K1, eps)), mul(K1, K1, eps) == {})
    ok &= mat_ok and cl_ok and sq[0] == Fr(-1, 4) and sq[2]
    return ok, ('; '.join(txt) + f'; brackets: Clifford [J,K1] = -K2, [J,K2] = K1, [K1,K2] = 0: {cl_ok}; the same for the Galilei matrices on (t,x,y): {mat_ok}; '
                f'J^2 = {sq[0]}, K1^2 = 0: {sq[2]} (the translation kind of T17)')

def check27(sab):
    rng = np.random.default_rng(27); n = 3; D = 1 << n
    keep = 0; gal_out = 0; lor_change = 0; trials = 200
    for _ in range(trials):
        P = rng.normal(size=(D, 2))
        # weights: a potential E with E(S + i) - E(S) > |P(S + i) - P(S)| on the Hasse edges
        E = np.zeros(D)
        for S in sorted(range(D), key=pc):
            if S == 0: continue
            E[S] = max(E[S ^ (1 << i)] + np.linalg.norm(P[S] - P[S ^ (1 << i)]) + 0.05 + rng.random() * (0.0 if sab else 0.5)
                       for i in range(n) if S >> i & 1)
        if sab:                                              # sabotage: one Hasse edge with a weight below the planar distance
            E[1] = 0.5 * np.linalg.norm(P[1] - P[0])
        arrows = [(S, T) for S in range(D) for T in range(D) if (S & T) == S and S != T]
        X = {(S, T): np.array([E[T] - E[S], *(P[T] - P[S])]) for S, T in arrows}
        inside = all(X[a][0] > np.linalg.norm(X[a][1:]) for a in arrows)
        keep += inside
        v = 0.9
        gb = lambda x: np.array([x[0], x[1] + v * x[0], x[2]])
        g = 1 / np.sqrt(1 - v * v)
        lb = lambda x: np.array([g * (x[0] + v * x[1]), g * (x[1] + v * x[0]), x[2]])
        gal_out += any(gb(X[a])[0] <= np.linalg.norm(gb(X[a])[1:]) for a in arrows)
        lor_change += any(abs(lb(X[a])[0] - X[a][0]) > 1e-9 for a in arrows)
    # Lie algebra: X in so(1,2) (X^T eta + eta X = 0) and dt o X = 0 (first row zero)
    eta = np.diag([1.0, -1.0, -1.0]); rows = []
    for i in range(3):
        for j in range(3):
            r = np.zeros(9)
            for k in range(3):
                r[k * 3 + i] += eta[k, j]                     # (X^T eta)_{ij} = sum_k X_{ki} eta_{kj}
            r2 = np.zeros(9)
            for k in range(3): r2[k * 3 + j] += eta[i, k]      # (eta X)_{ij} = sum_k eta_{ik} X_{kj}
            rows.append(r + r2)
    if not sab:
        for j in range(3):
            r = np.zeros(9); r[0 * 3 + j] = 1; rows.append(r)   # dt o X = 0
    dim = 9 - np.linalg.matrix_rank(np.array(rows))
    ok = keep == trials and gal_out > 0 and lor_change == trials and dim == 1
    return ok, (f'B_3 with random positions and weights E above the planar distance (seed 27): every arrow inside the speed-1 cone in {keep}/{trials}; '
                f'a Galilei boost (v = 0.9) takes some arrow out of the cone in {gal_out}/{trials}, a Lorentz boost changes some weight in {lor_change}/{trials}; '
                f'linear maps keeping dt and the cone: dimension {dim}')

CHECKS = [('bd·mjp·23', check23, 'proper time is super-additive, not an additive weight'),
          ('bd·mjp·24', check24, 'timelike chains stay timelike; spacelike legs give any sign'),
          ('bd·mjp·25', check25, 'boost-invariant linear weights: Galilei 1, Lorentz 0, Carroll 0'),
          ('bd·mjp·26', check26, 'Cl(2,0,1) null rotation: Carroll on vectors, Galilei on bivectors'),
          ('bd·mjp·27', check27, 'the paper\'s data as Galilean events with a speed limit')]

def main():
    for cid, f, short in CHECKS:
        ok, text = f(SAB)
        report(cid, ok, text, short)
    finish()

if __name__ == '__main__':
    main()
