#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""phy_staggered.py: the signed cube of the spring step (step 15) against the staggered (Kogut-Susskind) operator of lattice gauge theory.

The signed network of the spring step is D = sum_i L_{e_i}, left multiplication by the generators of Cl(n,0) on the 2^n labels (SPR-004).

  bd·phy·16  the bit-rule sign of left multiplication by e_i on the label x, with all squares +1, is (-1)^{#(j in x, j < i)}, the
             Kogut-Susskind phase eta_i(x) = (-1)^{x_0 + ... + x_{i-1}} on the n-cube (n = 2..6, every label, every i); so D is the sum over
             directions of eta_i(x) times the hop x -> x xor e_i, and D^2 = n.
  bd·phy·17  the staggered Dirac operator of lattice gauge theory is the antisymmetric combination D_KS = (1/2) sum_i eta_i(x) (T_i - T_i^{-1});
             on the periodic lattice of side 2, which the hypercube is, T_i^{-1} = T_i in every direction, so D_KS = 0 identically (n = 2..6),
             while D is the symmetric combination (1/2) sum_i eta_i (T_i + T_i^{-1}) = sum_i eta_i T_i.  On lattices of side 3 and 4
             ((n, L) = (2,3), (2,4), (3,3)) the same phases give a nonzero D_KS.  On the cube the signed network is the symmetric (Majorana,
             mass-like) part of the staggered operator; the antisymmetric (Dirac, derivative) part vanishes on a lattice of period 2.

  python3 phy_staggered.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; about a second."""
import itertools
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))          # phy_bitrule.py sits next to this script
import numpy as np
from phy_bitrule import Alg, Reporter, popcount

def ks_phase(x, i):
    """eta_i(x) = (-1)^{x_0 + ... + x_{i-1}} with x a bit mask (period-2 lattice) or a tuple of coordinates"""
    if isinstance(x, int):
        return -1 if popcount(x & ((1 << i) - 1)) & 1 else 1
    return -1 if sum(x[:i]) & 1 else 1

def main():
    R = Reporter()
    ok16 = True; sq = []
    for n in range(2, 7):
        A = Alg([1] * n)
        for i in range(n):
            for x in range(1 << n):
                # left multiplication by e_i: e_i e_x = S[1<<i, x] e_{x xor e_i}; compare with the KS phase
                ok16 &= A.S[1 << i, x] == ks_phase(x, i)
        D = np.zeros((1 << n, 1 << n))
        for x in range(1 << n):
            for i in range(n):
                D[x ^ (1 << i), x] += A.S[1 << i, x]
        sq.append(np.abs(D @ D - n * np.eye(1 << n)).max() < 1e-12)
    R('bd·phy·16', ok16 and all(sq), 'the bit-rule sign of e_i on the label x is the Kogut-Susskind phase eta_i(x) for n = 2..6, every i and x; D = sum_i eta_i T_i has D^2 = n I')

    # bd·phy·17: antisymmetric (Dirac) versus symmetric (Majorana) staggered combinations on side-L lattices
    def staggered(n, L):
        sites = list(itertools.product(range(L), repeat=n)); idx = {s: k for k, s in enumerate(sites)}
        N = len(sites)
        Dks = np.zeros((N, N)); Dsym = np.zeros((N, N))
        for s in sites:
            for i in range(n):
                eta = ks_phase(s, i)
                fwd = list(s); fwd[i] = (fwd[i] + 1) % L
                bwd = list(s); bwd[i] = (bwd[i] - 1) % L
                Dks[idx[tuple(fwd)], idx[s]] += 0.5 * eta
                Dks[idx[tuple(bwd)], idx[s]] -= 0.5 * eta
                Dsym[idx[tuple(fwd)], idx[s]] += 0.5 * eta
                Dsym[idx[tuple(bwd)], idx[s]] += 0.5 * eta
        return Dks, Dsym
    ok17 = True; txt = []
    for n in range(2, 7):
        Dks, Dsym = staggered(n, 2)
        zero = np.abs(Dks).max() < 1e-12
        A = Alg([1] * n)
        D = np.zeros((1 << n, 1 << n))
        for x in range(1 << n):
            for i in range(n):
                D[x ^ (1 << i), x] += A.S[1 << i, x]
        # the site (x_0..x_{n-1}) with x_i in {0,1} is the label sum x_i 2^i
        perm = [sum(c << i for i, c in enumerate(s)) for s in itertools.product(range(2), repeat=n)]
        Dsym_lab = np.zeros_like(D)
        for a, pa in enumerate(perm):
            for b, pb in enumerate(perm):
                Dsym_lab[pa, pb] = Dsym[a, b]
        samesym = np.abs(Dsym_lab - D).max() < 1e-12
        ok17 &= zero and samesym
        txt.append('n=%d: |D_KS| = %.0f, D_sym = D: %s' % (n, np.abs(Dks).max(), samesym))
    for n, L in ((2, 3), (2, 4), (3, 3)):
        Dks, _ = staggered(n, L)
        w = np.linalg.eigvals(Dks)
        nz = np.abs(Dks).max() > 0.4
        ok17 &= nz
        txt.append('n=%d, L=%d: |D_KS| = %.1f, spectrum purely imaginary with max |w| = %.3f' % (n, L, np.abs(Dks).max(), np.abs(w).max()))
    R('bd·phy·17', ok17, '; '.join(txt) + ': on the hypercube (period 2) the staggered Dirac operator vanishes and the signed cube D is its symmetric (Majorana) partner')
    R.finish()

if __name__ == '__main__':
    main()
