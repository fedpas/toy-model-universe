#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cat_functor.py: the ladder moves are functors; the labels are functorial only in the frame.

  python3 selfcheck/bridges/cat_functor.py      one line per check, ids bd·cat·16 .. bd·cat·18; exit 1 on any FAIL

Standard library only (floats only in bd·cat·18 for the 45-degree rotor, tolerance 1e-12), deterministic, under 1 s; runs from any folder,
reads and writes no file.
  bd·cat·16  halving is a natural isomorphism: for every eps in {+1,-1,0}^n (n <= 4), every t with eps_t != 0 and every signed permutation sigma of the
             other generators that preserves their squares, phi_t(Cl(sigma') x) = Cl(sigma)(phi_t x) on every label (phi_t: Cl(eps') -> Cl^0(eps),
             f_i -> e_i e_t).
  bd·cat·17  Cl is a functor on quadratic spaces with q-preserving linear maps: the projection V -> V/N killing the null generators gives the algebra
             map Cl(p,q,r) -> Cl(p,q) = Cl/J, the mother map z -> f+ - f- gives an injective algebra map Cl(p,q,r) -> Cl(p+r,q+r), and
             Cl(sigma o mu) = Cl(sigma) o Cl(mu) on every label (r >= 1, n <= 4).
  bd·cat·18  the 45-degree rotor of Cl(2,0) sends e_1 to (e_1 + e_2)/sqrt 2, not a signed blade; the 90-degree rotor (its square) acts on the labels as
             the transposition of the two bits, which is not a square in Aut(V,Q,pi) of Cl(2,0) (a group of order 2): no homomorphism
             SO(2) -> Aut(V,Q,pi) extends the action of the signed permutations, so (V,Q,pi) is attached to the frame and its isomorphism class
             is frame-free.
"""
import itertools, math, sys

ROWS = []
def row(i, ok, text):
    cid = i
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
def mul(A, B, eps):
    out = {}
    for a, ca in A.items():
        for b, cb in B.items():
            c = ca * cb * sgn(a, b, eps)
            if c: out[a ^ b] = out.get(a ^ b, 0) + c
    return {k: v for k, v in out.items() if v}
def add(A, B, s=1):
    out = dict(A)
    for k, v in B.items(): out[k] = out.get(k, 0) + s * v
    return {k: v for k, v in out.items() if v}
def blade_map(images, eps_target, n_src):
    """the algebra map defined on generators by images (multivectors in the target): e_a -> ordered product of the images"""
    def f(a):
        x = {0: 1}
        for i in range(n_src):
            if a >> i & 1: x = mul(x, images[i], eps_target)
        return x
    return f
def apply(fmap, X):
    out = {}
    for a, c in X.items():
        for k, v in fmap(a).items(): out[k] = out.get(k, 0) + c * v
    return {k: v for k, v in out.items() if v}

def check16():
    ok = True; squares = 0
    for n in range(2, 5):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e)
            for t in range(n):
                if e[t] == 0: continue
                others = [i for i in range(n) if i != t]
                ep = [-e[t] * e[i] for i in others]                     # f_i = e_i e_t squares to -eps_t eps_i
                phi = blade_map([{(1 << i) | (1 << t): sgn(1 << i, 1 << t, e)} for i in others], e, n - 1)
                # every permutation of the other generators preserving squares, with every sign pattern
                for perm in itertools.permutations(range(n - 1)):
                    if any(ep[perm[k]] != ep[k] for k in range(n - 1)): continue
                    for signs in itertools.product((1, -1), repeat=n - 1):
                        sp = blade_map([{1 << perm[k]: signs[k]} for k in range(n - 1)], ep, n - 1)          # Cl(sigma') on Cl(eps')
                        imgs = [None] * n
                        for k, i in enumerate(others): imgs[i] = {1 << others[perm[k]]: signs[k]}
                        imgs[t] = {1 << t: 1}
                        s_big = blade_map(imgs, e, n)                                                     # Cl(sigma) on Cl(eps), sigma(t) = t
                        for a in range(1 << (n - 1)):
                            if apply(phi, sp(a)) != apply(s_big, phi(a)): ok = False
                        squares += 1
    row('bd·cat·16', ok,
        f'the halving isomorphism phi_t: Cl(eps\') -> Cl^0(eps), f_i -> e_i e_t, commutes with Cl of every square-preserving signed permutation fixing t '
        f'({squares} naturality squares, every eps with n <= 4, null generators riding along): halving is a natural isomorphism Cl o (halve) => Cl^0 on the '
        'groupoid of pointed quadratic spaces (V, t), q(t) != 0; Cl^0 itself is a functor with no choice')

def check17():
    ok = True; cnt = 0
    for n in range(1, 5):
        for r in range(1, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); m = p + q; eq = sig(p, q)
                # (a) projection killing the null generators: an algebra map Cl(p,q,r) -> Cl(p,q), kernel = labels with a null bit
                rho = blade_map([{1 << i: 1} for i in range(m)] + [{} for _ in range(r)], eq, n)
                for a in range(1 << n):
                    for b in range(1 << n):
                        lhs = apply(rho, {a ^ b: sgn(a, b, e)} if sgn(a, b, e) else {})
                        rhs = mul(rho(a), rho(b), eq)
                        if lhs != rhs: ok = False
                if any((rho(a) == {}) != (a >> m != 0) for a in range(1 << n)): ok = False
                # (b) mother: null generator j -> f+_j - f-_j in Cl(p+r, q+r) (generators: p plus, q minus, r extra plus, r extra minus)
                eb = [1] * p + [-1] * q + [1] * r + [-1] * r
                imgs = [{1 << i: 1} for i in range(m)] + [{1 << (m + j): 1, 1 << (m + r + j): -1} for j in range(r)]
                mu = blade_map(imgs, eb, n)
                for a in range(1 << n):
                    for b in range(1 << n):
                        lhs = apply(mu, {a ^ b: sgn(a, b, e)} if sgn(a, b, e) else {})
                        if lhs != mul(mu(a), mu(b), eb): ok = False
                # injective: the images of the 2^n labels are linearly independent (distinct leading labels suffice; check rank exactly)
                vecs = [[mu(a).get(c, 0) for c in range(1 << (m + 2 * r))] for a in range(1 << n)]
                import fractions
                M = [[fractions.Fraction(x) for x in v] for v in vecs]; rk = 0
                for c in range(len(M[0])):
                    pv = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
                    if pv is None: continue
                    M[rk], M[pv] = M[pv], M[rk]
                    for i in range(len(M)):
                        if i != rk and M[i][c] != 0:
                            f = M[i][c] / M[rk][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
                    rk += 1
                if rk != 1 << n: ok = False
                # (c) composition: sigma flips the sign of every f-_j (an isometry); Cl(sigma o mu) = Cl(sigma) o Cl(mu)
                sig_imgs = [{1 << i: (-1 if i >= m + r else 1)} for i in range(m + 2 * r)]
                S = blade_map(sig_imgs, eb, m + 2 * r)
                comp_imgs = [apply(S, x) for x in imgs]                 # (sigma o mu) on generators
                C = blade_map(comp_imgs, eb, n)
                if any(C(a) != apply(S, mu(a)) for a in range(1 << n)): ok = False
                cnt += 1
    row('bd·cat·17', ok,
        f'for every Cl(p,q,r) with r >= 1, n <= 4 ({cnt} cells): the projection V -> V/N induces the algebra map onto Cl(p,q) with kernel J (catw·P1), '
        'the mother map z -> f+ - f- induces an injective algebra map into Cl(p+r,q+r) (cat·M1), and Cl(sigma o mu) = Cl(sigma) o Cl(mu): '
        'restrict, quotient and mother are Cl applied to morphisms of quadratic spaces')

def check18():
    e = sig(2, 0)
    # 90-degree rotor R = (1 + e_12)/sqrt2: R e_1 R~ = (1 + e12) e1 (1 - e12) / 2, exact with integers
    R2 = {0: 1, 3: 1}; R2t = {0: 1, 3: -1}
    img1 = mul(mul(R2, {1: 1}, e), R2t, e); img1 = {k: v // 2 for k, v in img1.items()}
    img2 = mul(mul(R2, {2: 1}, e), R2t, e); img2 = {k: v // 2 for k, v in img2.items()}
    swaps = (set(img1) == {2} and set(img2) == {1})
    # 45-degree rotor, floats: R = cos(pi/8) + sin(pi/8) e_12 (rotation by pi/4)
    c, s = math.cos(math.pi / 8), math.sin(math.pi / 8)
    def fmul(A, B):
        out = {}
        for a, x in A.items():
            for b, y in B.items(): out[a ^ b] = out.get(a ^ b, 0.0) + x * y * sgn(a, b, e)
        return out
    R45 = {0: c, 3: s}; R45t = {0: c, 3: -s}
    im = fmul(fmul(R45, {1: 1.0}), R45t)
    nonblade = sum(1 for k, v in im.items() if abs(v) > 1e-12) > 1
    sq = fmul(R45, R45)
    is_R90 = abs(sq.get(0, 0) - 1 / math.sqrt(2)) < 1e-12 and abs(sq.get(3, 0) - 1 / math.sqrt(2)) < 1e-12
    # Aut(V, Q, pi) of Cl(2,0): linear bijections of F_2^2 keeping Q and pi
    Qt = [1 if sgn(a, a, e) == -1 else 0 for a in range(4)]; Pt = [pc(a) % 2 for a in range(4)]
    auts = []
    for i1 in range(1, 4):
        for i2 in range(1, 4):
            if i1 == i2: continue
            T = [0, i1, i2, i1 ^ i2]
            if all(Qt[T[a]] == Qt[a] and Pt[T[a]] == Pt[a] for a in range(4)): auts.append(tuple(T))
    tau = (0, 2, 1, 3)
    squares = {tuple(g[g[a]] for a in range(4)) for g in auts}
    ok = swaps and nonblade and is_R90 and tau in auts and tau not in squares and len(auts) == 2
    print(f'     R90 e1 R90~ = {img1}, R90 e2 R90~ = {img2} (labels swapped); R45 e1 R45~ = ' + ', '.join(f'{v:+.4f} e_{k}' for k, v in sorted(im.items()) if abs(v) > 1e-12)
          + f'; R45^2 = R90: {is_R90}; |Aut(V,Q,pi)| = {len(auts)}, squares in it: {sorted(squares)}')
    row('bd·cat·18', ok,
        'the 45-degree rotor of Cl(2,0) does not send labels to labels; its square, the 90-degree rotor, acts on the labels as the bit transposition, which is not a '
        'square in Aut(V,Q,pi) (order 2): no homomorphism from SO(2) (where the 90-degree rotation is a square) to Aut(V,Q,pi) extends the signed-permutation action. '
        '(V,Q,pi) is a functor of the framed space (frame lattice I_(p,q), signed permutations), not of (V,g); its isomorphism class is frame-free')

if __name__ == '__main__':
    check16(); check17(); check18()
    verdict()
