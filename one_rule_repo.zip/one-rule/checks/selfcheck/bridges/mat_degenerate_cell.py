#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mat_degenerate_cell.py: the cell (V, Q, pi) and the Z_4 form w = pi + 2Q of Cl(p,q,r) when null generators are present (r >= 1).

  python3 selfcheck/bridges/mat_degenerate_cell.py        one line per check, ids bd·mat·1 .. bd·mat·4; exit 1 on any FAIL

Standard library only, exact integers, deterministic, under 1 s; runs from any folder, reads and writes no file.
  bd·mat·1  the triple (V, Q, pi) with the binary form Q(a) = [e_a^2 = -1] does not determine the cell once r >= 1: every pair of cells with
            n <= 4 and different r whose triples are isomorphic (a full isometry test on every label) is listed; smallest pair Cl(1,0) and Cl(0,0,1).
  bd·mat·2  w = pi + 2Q is a Z_4 quadratic refinement of the dot product (core·B1) exactly for r = 0 and for the two cells Cl(0,0,1), Cl(0,1,1)
            (every (p,q,r) with n <= 5); smallest failure Cl(1,0,1) with the labels {1}, {2}.
  bd·mat·3  for r >= 1 the sum of i^(pi + 2Q) over all labels is not a Gauss sum of a Z_4 quadratic form (its modulus is not 2^{n/2} in 54 of the
            56 degenerate cells with n <= 6); the same sum over the labels without a null bit, i.e. over the quotient Cl(p,q,r)/J = Cl(p,q), is
            (1+i)^p (1-i)^q with phase p - q: the clock of a degenerate cell is the Brown invariant of its semisimple quotient.
  bd·mat·4  the ternary square map Qt(a) = e_a^2 in {-1, 0, +1} together with pi determines the cell: for all pairs of signatures with n <= 4,
            (V, Qt, pi) are isomorphic iff r agrees and p - q agrees mod 8.
"""
import itertools, sys

ROWS = []
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Q(a, e): return 1 if sgn(a, a, e) == -1 else 0
def pi(a): return pc(a) % 2
def w4(a, e): return (pi(a) + 2 * Q(a, e)) % 4
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
def row(i, text, ok):
    ROWS.append((i, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def gsum(exps):
    re = im = 0
    for k in exps:
        z = [(1, 0), (0, 1), (-1, 0), (0, -1)][k % 4]; re += z[0]; im += z[1]
    return (re, im)
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def gpow(x, k):
    r = (1, 0)
    for _ in range(k): r = gmul(r, x)
    return r
def phase8(z):
    # phase of a Gaussian integer of the form 2^{k/2} e^{i pi c/4}: read c in Z_8 from the signs and equality of |re|, |im|
    re, im = z
    table = {(1, 0): 0, (1, 1): 1, (0, 1): 2, (-1, 1): 3, (-1, 0): 4, (-1, -1): 5, (0, -1): 6, (1, -1): 7}
    key = ((re > 0) - (re < 0), (im > 0) - (im < 0))
    assert re == 0 or im == 0 or abs(re) == abs(im), z
    return table[key]

# ---------------------------------------------------------------- bd·mat·1: (V, Q, pi) is blind to null bits
def Qiso_exists(e1, e2):
    """an F_2-linear bijection T with Q(Ta) = Q(a) and pi(Ta) = pi(a) (Q the binary form [e_a^2 = -1])"""
    n = len(e1); V = range(1 << n)
    def rec(i, imgs):
        if i == n:
            span = {0}
            for v in imgs: span |= {s ^ v for s in span}
            if len(span) != 1 << n: return False
            def T(a):
                x = 0
                for j in range(n):
                    if a >> j & 1: x ^= imgs[j]
                return x
            return all(Q(T(a), e2) == Q(a, e1) and pi(T(a)) == pi(a) for a in V)
        for v in V:
            if Q(v, e2) != Q(1 << i, e1) or pi(v) != 1: continue
            good = True
            for S in range(1 << i):
                a = sum(1 << j for j in range(i) if S >> j & 1) | (1 << i)
                x = v
                for j in range(i):
                    if S >> j & 1: x ^= imgs[j]
                if Q(x, e2) != Q(a, e1): good = False; break
            if good and rec(i + 1, imgs + [v]): return True
        return False
    return rec(0, [])
def check1():
    collisions = []
    for n in range(1, 5):
        cells = [(p, n - r - p, r) for r in range(n + 1) for p in range(n - r + 1)]
        for x in range(len(cells)):
            for y in range(x + 1, len(cells)):
                (p1, q1, r1), (p2, q2, r2) = cells[x], cells[y]
                if Qiso_exists(sig(p1, q1, r1), sig(p2, q2, r2)):
                    if r1 == r2 == 0: continue                       # the r = 0 identifications are the clock (core·B6c), expected
                    collisions.append(f'Cl({p1},{q1},{r1})~Cl({p2},{q2},{r2})')
    e1, e0 = sig(1, 0), sig(0, 0, 1)
    same = all(Q(a, e1) == Q(a, e0) for a in range(2))
    differ = sgn(1, 1, e1) != sgn(1, 1, e0)
    want = {'Cl(1,0,0)~Cl(0,0,1)', 'Cl(1,0,1)~Cl(0,0,2)'}
    row('bd·mat·1', 'the triple (V, Q, pi) with the binary form Q(a) = [e_a^2 = -1] does not fix the cell once null generators are allowed: '
        f'cells with n <= 4 sharing an isomorphic (V, Q, pi) although they differ in r: {", ".join(collisions)}. '
        'Smallest witness Cl(1,0) and Cl(0,0,1): (F_2, Q = 0, pi = id) for both, e^2 = +1 against e^2 = 0. '
        'So the triple (V, Q, pi) is the cell for r = 0; with null generators the cell is (V, Qt, pi) with the ternary square map Qt (bd·mat·4)',
        same and differ and want <= set(collisions))

# ---------------------------------------------------------------- bd·mat·2: the Z_4 refinement identity with null bits
def check2():
    holds, fails = [], []
    for n in range(1, 6):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e)
            if e != sorted(e, key=lambda x: (x == 0, -x)): continue           # one representative per (p,q,r): +1 first, then -1, then 0
            good = all((w4(a ^ b, e) - w4(a, e) - w4(b, e)) % 4 == (2 * pc(a & b)) % 4 for a in range(1 << n) for b in range(1 << n))
            p, q, r = e.count(1), e.count(-1), e.count(0)
            (holds if good else fails).append((p, q, r))
    expect_holds = all(r == 0 or (p, q, r) in ((0, 0, 1), (0, 1, 1)) for p, q, r in holds)
    expect_fails = all(r >= 1 and (p, q, r) not in ((0, 0, 1), (0, 1, 1)) for p, q, r in fails)
    e = sig(1, 0, 1); a, b = 1, 2
    wit = (w4(a ^ b, e) - w4(a, e) - w4(b, e)) % 4
    row('bd·mat·2', 'w = pi + 2Q is a Z_4 quadratic refinement of the dot product (core·B1) for exactly the signatures with r = 0, plus the two cells Cl(0,0,1) and Cl(0,1,1) '
        f'(whose (V, Q, pi) coincide with those of Cl(1,0) and Cl(1,1), bd·mat·1; all (p,q,r) with n <= 5); it fails for every other degenerate cell. Smallest counterexample Cl(1,0,1), a = {{1}}, b = {{2}}: w(a+b) - w(a) - w(b) = {wit} mod 4, '
        'while 2|a & b| = 0. The Z_4 form of the Atlas is a form on the non-degenerate cell only',
        expect_holds and expect_fails and wit == 2 and (1, 0, 1) in fails)

# ---------------------------------------------------------------- bd·mat·3: the Gauss sum of the literal w with null bits, and the patch
def check3():
    ok = True; bad_modulus = []; lit = {}
    for n in range(1, 7):
        for r in range(1, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r)
                S_lit = gsum([w4(a, e) for a in range(1 << n)])                       # the literal sum of i^w over all labels
                lit[(p, q, r)] = S_lit
                if S_lit[0] ** 2 + S_lit[1] ** 2 != 2 ** n: bad_modulus.append((p, q, r))   # a Z_4 quadratic form on F_2^n has |sum| = 2^{n/2}
                N = sum(1 << i for i in range(n) if e[i] == 0)
                S_pat = gsum([w4(a, e) for a in range(1 << n) if a & N == 0])         # the labels of the quotient Cl(p,q,r)/J = Cl(p,q)
                if S_pat != gmul(gpow((1, 1), p), gpow((1, -1), q)): ok = False
                if phase8(S_pat) != (p - q) % 8: ok = False
    row('bd·mat·3', 'with null generators the literal sum of i^w, w = pi + 2Q, over all labels is not a Gauss sum of a Z_4 quadratic form: its modulus differs from 2^{n/2} '
        f'for {len(bad_modulus)} of {len(lit)} degenerate cells with n <= 6 (Cl(0,0,1): 1 + i; Cl(1,1,1): 4 + 2i), so for r >= 1 the clock is not the Brown invariant '
        'of (V, w). The same sum over the labels without a null bit, i.e. over the quotient cell Cl(p,q,r)/J = Cl(p,q) (J the radical), is (1+i)^p (1-i)^q with phase '
        'p - q for every (p,q,r), n <= 6: the clock of a degenerate cell is the Brown invariant of its semisimple quotient (the sum of core·B3, with weight 0 on the '
        'null bits, is 2^r times this quotient sum: bd·xck·3)',
        ok and lit[(0, 0, 1)] == (1, 1) and lit[(1, 1, 1)] == (4, 2) and len(bad_modulus) > 0)

# ---------------------------------------------------------------- bd·mat·4: (V, Qt, pi) with the ternary square map determines the cell
def Qt(a, e): return sgn(a, a, e)
def iso_exists(e1, e2):
    """an F_2-linear bijection T with Qt(Ta) = Qt(a) and pi(Ta) = pi(a); backtracking on the images of the basis vectors"""
    n = len(e1); V = range(1 << n)
    def rec(i, imgs):
        if i == n:
            span = {0}
            for v in imgs: span |= {s ^ v for s in span}
            if len(span) != 1 << n: return False
            # check the whole map
            def T(a):
                x = 0
                for j in range(n):
                    if a >> j & 1: x ^= imgs[j]
                return x
            return all(Qt(T(a), e2) == Qt(a, e1) and pi(T(a)) == pi(a) for a in V)
        for v in V:
            if Qt(v, e2) != Qt(1 << i, e1) or pi(v) != 1: continue
            # partial consistency on sums with the images already chosen
            good = True
            for S in range(1 << i):
                a = sum(1 << j for j in range(i) if S >> j & 1) | (1 << i)
                x = v
                for j in range(i):
                    if S >> j & 1: x ^= imgs[j]
                if Qt(x, e2) != Qt(a, e1): good = False; break
            if good and rec(i + 1, imgs + [v]): return True
        return False
    return rec(0, [])
def check4():
    ok = True; pairs = 0
    for n in range(1, 5):
        cells = [(p, n - r - p, r) for r in range(n + 1) for p in range(n - r + 1)]
        for x in range(len(cells)):
            for y in range(x, len(cells)):
                (p1, q1, r1), (p2, q2, r2) = cells[x], cells[y]
                has = iso_exists(sig(p1, q1, r1), sig(p2, q2, r2))
                want = (r1 == r2) and ((p1 - q1) % 8 == (p2 - q2) % 8)
                if has != want: ok = False
                pairs += 1
    row('bd·mat·4', f'(V, Qt, pi) with the ternary square map Qt(a) = e_a^2 in {{-1,0,+1}} determines the cell: for all {pairs} pairs of signatures with n <= 4, '
        'an F_2-linear bijection preserving Qt and pi exists iff r agrees and p - q agrees mod 8 (Cl(4,0,r) = Cl(0,4,r) included). '
        'So for r >= 1 the cell is (V, Qt, pi), equivalently (V_D, Q, pi) together with r, V_D the labels without a null bit', ok)

if __name__ == '__main__':
    for f in (check1, check2, check3, check4): f()
    verdict()
