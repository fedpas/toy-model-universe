#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mja_zero.py: Definition 4 of arXiv:2403.19689 (v3) ("commutative nonassociative ring" (V, (+), .)) against associators, and the paper's
auxiliary zero 0 = |0| e3 (Def. 2 (2)) against the zero, the null generator, label 0 and the identity arrows.

    python3 selfcheck/bridges/mja_zero.py              one line per check, ids bd·mja·29 .. bd·mja·31; exit 1 on any FAIL
    python3 selfcheck/bridges/mja_zero.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only (exact integers; floats with tolerance 1e-9 in the reading R2); deterministic; under 2 s; runs from any folder, reads
and writes no file.
  bd·mja·29  Definition 4, clause 1, on the labels: of the 5^n triples with a (+) b and b (+) c defined, 4^n have both bracketings defined (equal)
             and 5^n - 4^n neither, none exactly one (n <= 5); on the arrows of B_n with the commutative (+) of (8) (either order of composition)
             the same: 0 of 4 (n = 2) and 12 of 84 (n = 3) hypothesis triples have both bracketings defined, the rest neither, none exactly one
             (that a category with an isomorphism pair f, g gives f (+) g two values, id_X and id_Y, is a remark from the definition of (8),
             not tested).  The product of Definition 4 is real-valued: on
             B_3 (Hasse drawing) 48 of the 361 ordered arrow pairs have f.g < 0, so (f.g) h is not a positive multiple; distributivity
             f.(g (+) h) = f.g + f.h holds in R1 on all 342 triples (g, h composable) and fails in R2 (popcount weights) on all 342.
  bd·mja·30  associators: the arrow vectors of B_3 (Hasse) multiply associatively in Cl(2,0): associator 0 on all 6859 triples (R1, exact, bit
             rule) and on the 1000 triples of the first ten arrows (R2a, floats).  Controls that are not zero: the Cayley-Dickson sign on 3-bit labels has associator -1 on 168 of the 512
             triples, among them all 6 pairwise disjoint nonzero triples (the octonion sign stays non-associative on disjoint labels); the Petit
             algebra C[t; conj]/(t^2 - i) has ((t t) t) - (t (t t)) = 2i t, while t^2 - 2 gives an associative algebra.
  bd·mja·31  one line per object (square, dimension of the left annihilator, unit role): the paper's 0 = |0| e3 with |0| = 0 in Cl(3,0); e3;
             the null generator of Cl(3,0,1); label 0 (e_0 = 1); an identity arrow P_S of the incidence algebra of B_3; the identity of an
             object X outside B_3 in the category algebra of B_3 + {X}; the global unit of that category algebra.
"""
import itertools, sys
from fractions import Fraction as Fr
from math import sqrt

SABOTAGE = '--sabotage' in sys.argv
ROWS = []
def row(cid, ok, text):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def cl_mul(x, y, eps):
    out = {}
    for a, u in x.items():
        for b, v in y.items():
            s = sgn(a, b, eps)
            if s: out[a ^ b] = out.get(a ^ b, 0) + s * u * v
    return {k: v for k, v in out.items() if v != 0}
def bn(n):
    obj = list(range(1 << n)); return obj, [(S, T) for S in obj for T in obj if S & T == S and S != T]
def hasse(n):
    v = [(n * 2 ** i - 2 ** n + 1, n) for i in range(n)]
    return {S: (sum(v[i][0] for i in range(n) if S >> i & 1), sum(v[i][1] for i in range(n) if S >> i & 1)) for S in range(1 << n)}
def D(P, f): return (P[f[1]][0] - P[f[0]][0], P[f[1]][1] - P[f[0]][1])
def dot(u, v): return u[0] * v[0] + u[1] * v[1]

def chk29(sab):
    ok = True; notes = []
    lab = []
    for n in range(0, 6):
        N = 1 << n; op = lambda a, b: a | b if a & b == 0 else None
        if sab and n == 3: op = lambda a, b: a | b if (a & b) in (0, 1) else None     # sabotage: a rule that is not a partial monoid
        hyp = both = neither = one = 0
        for a in range(N):
            for b in range(N):
                ab = op(a, b)
                if ab is None: continue
                for c in range(N):
                    bc = op(b, c)
                    if bc is None: continue
                    hyp += 1
                    l, r = op(ab, c), op(a, bc)
                    if l is not None and r is not None: both += 1; ok &= l == r
                    elif l is None and r is None: neither += 1
                    else: one += 1
        lab.append((n, hyp, both, neither, one))
        if hyp != 5 ** n or both != 4 ** n or one: ok = False
    notes.append('labels (n, hypothesis, both, neither, one): ' + ', '.join(str(t) for t in lab))
    arr_counts = []
    for n in (2, 3):
        obj, arr = bn(n)
        def osum(f, g):
            vals = set()
            if f[1] == g[0]: vals.add((f[0], g[1]))
            if g[1] == f[0]: vals.add((g[0], f[1]))
            return vals.pop() if len(vals) == 1 else (None if not vals else 'two')
        hyp = both = neither = one = 0
        for a in arr:
            for b in arr:
                ab = osum(a, b)
                if ab is None: continue
                for c in arr:
                    bc = osum(b, c)
                    if bc is None: continue
                    hyp += 1
                    l, r = osum(ab, c), osum(a, bc)
                    if l is not None and r is not None: both += 1; ok &= l == r
                    elif l is None and r is None: neither += 1
                    else: one += 1
        arr_counts.append((n, hyp, both, neither, one))
        if one != 0 or neither == 0: ok = False
    notes.append('arrows of B_n with the commutative (+) (n, hypothesis, both, neither, exactly one): ' + ', '.join(str(t) for t in arr_counts))
    # isomorphism pair: X <-> Y, g f = id_X, f g = id_Y
    dom = {'f': 'X', 'g': 'Y'}; cod = {'f': 'Y', 'g': 'X'}
    comp = {('g', 'f'): 'id_X', ('f', 'g'): 'id_Y'}                      # comp[(second, first)]: g o f = id_X, f o g = id_Y
    vals = set()
    if cod['f'] == dom['g']: vals.add(comp[('g', 'f')])
    if cod['g'] == dom['f']: vals.add(comp[('f', 'g')])
    notes.append('remark, from the definition of (8) and not tested: an isomorphism pair f: X -> Y, g: Y -> X gives f (+) g in {g o f = id_X, f o g = id_Y}, '
                 + str(len(vals)) + ' values')
    # the real-valued product and distributivity on B_3 (Hasse)
    obj, arr = bn(3); P = hasse(3)
    negpairs = sum(1 for f in arr for g in arr if dot(D(P, f), D(P, g)) < 0)
    tot_pairs = len(arr) ** 2
    if negpairs == 0: ok = False
    r1_bad = r2_bad = trip = 0
    for f in arr:
        for g in arr:
            for h in arr:
                if g[1] != h[0]: continue
                gh = (g[0], h[1]); trip += 1
                Df, Dg, Dh, Dgh = D(P, f), D(P, g), D(P, h), D(P, gh)
                if dot(Df, Dgh) != dot(Df, Dg) + dot(Df, Dh): r1_bad += 1
                w = (lambda x: pc(x[1] ^ x[0])) if not sab else (lambda x: sqrt(dot(D(P, x), D(P, x))))   # sabotage: Euclidean lengths as weights
                cos = lambda u, v: dot(u, v) / sqrt(dot(u, u) * dot(v, v))
                lhs = w(f) * w(gh) * cos(Df, Dgh); rhs = w(f) * w(g) * cos(Df, Dg) + w(f) * w(h) * cos(Df, Dh)
                if abs(lhs - rhs) > 1e-9: r2_bad += 1
    notes.append(f'B_3 Hasse: f.g < 0 on {negpairs} of {tot_pairs} ordered pairs; distributivity fails on {r1_bad} of {trip} triples in R1 and on {r2_bad} in R2')
    if r1_bad or r2_bad != trip or negpairs != 48 or arr_counts != [(2, 4, 0, 4, 0), (3, 84, 12, 72, 0)]: ok = False
    return ok, '; '.join(notes), notes[-1]

def cd_sign(n):
    """Cayley-Dickson sign table on n-bit labels: (a, b)(c, d) = (a c - conj(d) b, d a + b conj(c)), top bit = the doubling bit"""
    if n == 0: return {(0, 0): 1}
    s0 = cd_sign(n - 1); h = 1 << (n - 1)
    def conj(x): return 1 if x == 0 else -1
    s = {}
    for x in range(1 << n):
        for y in range(1 << n):
            a, p = x & (h - 1), x >> (n - 1)
            c, q = y & (h - 1), y >> (n - 1)
            if p == 0 and q == 0: s[(x, y)] = s0[(a, c)]                                   # (a,0)(c,0) = (ac, 0)
            elif p == 0 and q == 1: s[(x, y)] = s0[(c, a)]                                 # (a,0)(0,d) = (0, d a)
            elif p == 1 and q == 0: s[(x, y)] = s0[(a, c)] * conj(c)                       # (0,b)(c,0) = (0, b conj(c))
            else: s[(x, y)] = -conj(c) * s0[(c, a)]                                        # (0,b)(0,d) = (-conj(d) b, 0)
    return s
def chk30(sab):
    ok = True
    obj, arr = bn(3); P = hasse(3); e2 = [1, 1]
    vecs = [{k: v for k, v in ((1, D(P, f)[0]), (2, D(P, f)[1])) if v} for f in arr]
    bad = 0; trip = 0
    for x in vecs:
        for y in vecs:
            xy = cl_mul(x, y, e2)
            for z in vecs:
                trip += 1
                if cl_mul(xy, z, e2) != cl_mul(x, cl_mul(y, z, e2), e2): bad += 1
    # R2a with floats: u_f = |f| D/|D| in Cl(2,0)
    us = []
    for f in arr:
        Df = D(P, f); L = sqrt(dot(Df, Df)); w = pc(f[1] ^ f[0])
        us.append({1: w * Df[0] / L, 2: w * Df[1] / L})
    bad2 = 0
    for x in us[:10]:
        for y in us[:10]:
            xy = cl_mul(x, y, e2)
            for z in us[:10]:
                l = cl_mul(xy, z, e2); r = cl_mul(x, cl_mul(y, z, e2), e2)
                if any(abs(l.get(k, 0) - r.get(k, 0)) > 1e-9 for k in set(l) | set(r)): bad2 += 1
    s = cd_sign(3)
    if sab: s = {(x, y): sgn(x, y, [-1, -1, -1]) for x in range(8) for y in range(8)}      # sabotage: Cl(0,3) in place of the octonions
    assoc_neg = sum(1 for a in range(8) for b in range(8) for c in range(8) if s[(a, b)] * s[(a ^ b, c)] != s[(b, c)] * s[(a, b ^ c)])
    disj = [(a, b, c) for a in range(1, 8) for b in range(1, 8) for c in range(1, 8) if not (a & b or b & c or a & c)]
    disj_neg = sum(1 for a, b, c in disj if s[(a, b)] * s[(a ^ b, c)] != s[(b, c)] * s[(a, b ^ c)])
    # Petit algebra over K = C with sigma = conjugation: x + y t, (x + y t)(u + v t) = (x u + y conj(v) a) + (x v + y conj(u)) t
    def petit(a):
        def m(p, q):
            x, y = p; u, v = q
            return (x * u + y * v.conjugate() * a, x * v + y * u.conjugate())
        return m
    t = (0j, 1 + 0j); one = (1 + 0j, 0j); I = (1j, 0j)
    m1 = petit(1j); m2 = petit(2 + 0j)
    assoc1 = (m1(m1(t, t), t)[0] - m1(t, m1(t, t))[0], m1(m1(t, t), t)[1] - m1(t, m1(t, t))[1])
    basis = [one, I, t, (0j, 1j)]
    a2 = max(abs(m2(m2(x, y), z)[k] - m2(x, m2(y, z))[k]) for x in basis for y in basis for z in basis for k in (0, 1))
    if bad or bad2 or assoc_neg != 168 or assoc1 != (0j, 2j) or a2 > 1e-12 or disj_neg != len(disj) or len(disj) != 6: ok = False
    return ok, (f'arrow vectors of B_3 (Hasse) in Cl(2,0): associator 0 on all {trip} triples (R1, exact) and on 1000 triples (R2a, floats), {bad + bad2} failures; '
                f'controls: Cayley-Dickson sign on 3-bit labels non-associative on {assoc_neg} of 512 triples, among them all {disj_neg} of the {len(disj)} pairwise disjoint nonzero triples; Petit C[t;conj]/(t^2 - i): ((tt)t) - (t(tt)) = '
                f'{int(assoc1[1].imag)}i t; C[t;conj]/(t^2 - 2): associator 0 on the basis'), f'octonion control: {assoc_neg} non-associative triples'

def chk31(sab):
    ok = True; lines = []
    def ann_dim(x, eps, D):
        cols = []
        for b in range(D):
            y = cl_mul(x, {b: 1}, eps); cols.append(y)
        # dimension of {y : x y = 0} = D - rank of the map y -> x y
        piv = {}; r = 0
        for v in cols:
            v = {k: Fr(c) for k, c in v.items()}
            while v:
                k = min(v)
                if k in piv:
                    f = v[k]
                    for kk, c in piv[k].items():
                        z = v.get(kk, 0) - f * c
                        if z: v[kk] = z
                        else: v.pop(kk, None)
                else:
                    f = v[k]; piv[k] = {kk: c / f for kk, c in v.items()}; r += 1; break
        return D - r
    e30 = [1, 1, 1]
    norm0 = 0 if not sab else 1
    zero = {4: norm0} if norm0 else {}
    sq = cl_mul(zero, zero, e30); lines.append((f'paper 0 = |0| e3, |0| = {norm0}, in Cl(3,0)', sq.get(0, 0) if sq else 0, ann_dim(zero, e30, 8), 'unit of +, absorbing'))
    e3 = {4: 1}; lines.append(('e3 in Cl(3,0)', cl_mul(e3, e3, e30).get(0, 0), ann_dim(e3, e30, 8), 'invertible, no unit'))
    pga = [1, 1, 1, 0]; e0 = {8: 1}
    lines.append(('null generator of Cl(3,0,1)', cl_mul(e0, e0, pga).get(0, 0), ann_dim(e0, pga, 16), 'nilpotent, nonzero, no unit'))
    one = {0: 1}; lines.append(('label 0, e_0 = 1', cl_mul(one, one, e30).get(0, 0), ann_dim(one, e30, 8), 'unit of the product and of (+)'))
    # incidence algebra of B_3 (+ an outside object X): basis = matrix units (T, S), S subset T, objects 0..7 and X = 8
    objs = list(range(8)) + [8]
    basis = [(T, S) for S in range(8) for T in range(8) if S & T == S] + [(8, 8)]
    def imul(x, y):
        out = {}
        for (t, s), u in x.items():
            for (t2, s2), v in y.items():
                if s == t2: out[(t, s2)] = out.get((t, s2), 0) + u * v
        return {k: v for k, v in out.items() if v}
    def iann(x):
        return sum(1 for b in basis if not imul(x, {b: 1}))           # matrix units: x y = 0 on basis elements spans the annihilator here
    PS = {(2, 2): 1}
    lines.append(('identity arrow P_S of B_3, S = {1}, in the category algebra of B_3 + {X} (dimension 28)', 'P_S' if imul(PS, PS) == PS else 'other', iann(PS), 'unit only for arrows into S'))
    idX = {(8, 8): 1}
    kills = all(not imul(idX, {b: 1}) and not imul({b: 1}, idX) for b in basis if b != (8, 8))
    lines.append(('identity of an object X outside B_3', 'id_X' if imul(idX, idX) == idX else 'other', iann(idX), f'annihilates every arrow of B_3 on both sides: {kills}'))
    glob = {(o, o): 1 for o in objs}
    unit = all(imul(glob, {b: 1}) == {b: 1} and imul({b: 1}, glob) == {b: 1} for b in basis)
    lines.append(('global unit 1 = sum of all identities', '1' if imul(glob, glob) == glob else 'other', iann(glob), f'unit of composition: {unit}'))
    want = [0, 8, 1, 0, 0, 8, 1, 0, 'P_S', 26, 'id_X', 27, '1', 0]
    got = [lines[0][1], lines[0][2], lines[1][1], lines[1][2], lines[2][1], lines[2][2], lines[3][1], lines[3][2], lines[4][1], lines[4][2], lines[5][1], lines[5][2], lines[6][1], lines[6][2]]
    if got != want or not kills or not unit: ok = False
    for name, s, a, role in lines:
        print(f'     {name}: square {s}, left annihilator dimension {a}, {role}')
    return ok, ('the auxiliary zero against five neighbours (square, left annihilator, unit role; lines above): the paper\'s 0 is the zero element (square 0, '
                'annihilator 8 of 8); e3 squares to 1; the null generator of Cl(3,0,1) squares to 0 with annihilator 8 of 16; label 0 is the unit; an identity arrow is '
                'an idempotent; the identity of an outside object annihilates every arrow of B_3, so "0 (+) f = f" of (8) is the global unit 1, not an identity arrow'), str(got[:2])

CHECKS = [('bd·mja·29', chk29), ('bd·mja·30', chk30), ('bd·mja·31', chk31)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            ok, _, seen = f(True)
            print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  broken input sees: ' + seen)
            missed += ok
        print('\nALL CAUGHT' if not missed else f'\n{missed} MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS:
        ok, text, _ = f(False)
        row(cid, ok, text)
    verdict()
