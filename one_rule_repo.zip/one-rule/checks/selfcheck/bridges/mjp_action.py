#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjp_action.py: the rows of the table (2.53) of arXiv:2403.19689 (v3) (a table of the author's book, as reproduced in the paper) that can be
computed on the label category B_n: limits as meets, the adjunction of the diagonal functor, 'minimal action' against 'unique arrow to the
limit cone', sums over paths and their tropical (zero-temperature) limit.

    python3 selfcheck/bridges/mjp_action.py              one line per check, ids bd·mjp·16 .. bd·mjp·22; exit 1 on any FAIL
    python3 selfcheck/bridges/mjp_action.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

numpy and the standard library; exact integers where possible; random data from seeded generators; about 1 s on one core; reads and writes
no file; runs from any folder, also with python3 -I.
  bd·mjp·16  in the label category B_n (n <= 4) every discrete diagram d_1..d_k (k = 0..3, all tuples) has a limit, and it is d_1 AND .. AND d_k
             (k = 0: the top label); the colimit is the OR.  Control: in 200 random posets of 8 elements only a fraction of the pairs has a limit
             (seed 16): 'every finite discrete diagram has a limit' holds for the labels and not for noise.
  bd·mjp·17  the adjunction of the row 'scalar field of type J': for J discrete with |J| = 2, 3, Delta : B_n -> B_n^J is left adjoint to the meet:
             Hom(Delta c, d) is non-empty iff Hom(c, AND d) is (every c, d, n <= 4: 74584 comparisons, the check).  Read off, not counted: the
             unit eta_c : c -> AND(c, .., c) is the identity at every object (c AND c = c), so the 'universal arrow at a point' of the row
             'Lagrangian density' is an identity of weight 0; the counit legs have the weights |d_j| - |AND d| that the line lists.
  bd·mjp·18  'unique arrow to the limit cone' against 'minimal action': with a strictly increasing energy E (a positive additive weight), the
             limit cone of a discrete diagram is the unique cone of minimal total leg weight sum_j (E(d_j) - E(c)) (every pair and triple of B_n,
             n <= 4, 20 random E; every pair with a limit in 200 random posets).  The converse fails: in the bowtie poset c1, c2 < a, b the pair
             {a, b} has no limit and still a unique cone of minimal weight (E = 0, 1, 2, 2: cone c2, weight 2); in the random posets k pairs
             have no limit and a minimal cone (seed 18).
  bd·mjp·19  sums over paths on the thin category B_n: every maximal path 0 -> [n] has the same weight E([n]) - E(0) for every additive weight
             (popcount: n; 20 random potentials, seed 19); the maximal chains, counted by a recursion over the covering steps of B_n, number n!,
             and the chains of all lengths number 1, 1, 3, 13, 75, 541, 4683 (n = 0..6, the ordered Bell numbers).  So every path is a minimiser
             and Z(beta) = (number of paths) e^{-beta (E([n]) - E(0))}: the minimal-action principle selects nothing.
  bd·mjp·20  the free category on the Hasse diagram of B_n (the n! maximal paths are distinct arrows) with generic positive edge weights w(S, i):
             the min-plus (tropical) recursion over the DAG gives the minimum of the enumeration of the n! paths, the minimiser is unique, and
             F(beta) = -(1/beta) ln sum_paths e^{-beta w(path)} lies within ln(n!)/beta of the minimum (beta = 1, 10, 100: the log-sum-exp bound,
             a generic inequality) (n = 3..6, seed 20).  With weights per generator (w(S, i) = w_i) every path has the weight sum_i w_i, so all
             n! paths tie (a reading, not computed).
  bd·mjp·21  the sum over the n! maximal chains 0 -> [n] of the creation products on the vacuum: with the bit-rule (Jordan-Wigner) signs
             sum_sigma c_{sigma(n)}^+ .. c_{sigma(1)}^+ |0> = 0 for n >= 2, with all signs +1 (hard-core bosons) n! |[n]> (n = 2..6); random
             edge-sign tables give 0 in k of 200 (n = 2..4, seed 21).  Two more readings of the same sum, not computed here: in B_n the chains compose
             to one arrow (the sum is n! |[n]><0| in the incidence algebra); in the free category they are n! arrows.
  bd·mjp·22  the row 'action = set of displacements of each point': the sum over the arrows out of S weighted by e^{-beta w} equals
             prod_{i not in S} (1 + e^{-beta q_i}) for a charge weight (the grand partition function of the empty fermion modes), at every S,
             n <= 6, beta in {0.3, 1, 2.5}; for 200 random interacting energies (strictly increasing, not additive on disjoint labels) the
             product formula with the one-particle energies fails at S = 0 in 200 of 200 (seed 22).
"""
import sys, itertools
from math import factorial, log, exp
import numpy as np

SAB = '--sabotage' in sys.argv
ROWS, FAILS = [], []
def report(cid, ok, text, short):
    ROWS.append(cid)
    if SAB:
        print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  ' + short + '\n       the sabotaged run computes: ' + text)
        if ok: FAILS.append(cid)
    else:
        print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
        if not ok: FAILS.append(cid)
def finish():
    if SAB:
        print('\n' + ('ALL CAUGHT' if not FAILS else f'{len(FAILS)} MISSED: ' + ' '.join(FAILS)))
    else:
        print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

def limit_in_poset(elems, leq, diagram):
    cones = [c for c in elems if all(leq(c, d) for d in diagram)]
    lims = [L for L in cones if all(leq(c, L) for c in cones)]
    return (lims[0] if len(lims) == 1 else None), cones
def random_poset(m, rng):
    R = np.zeros((m, m), dtype=bool)
    p = rng.uniform(0.15, 0.45)
    for i in range(m):
        for j in range(i + 1, m): R[i, j] = rng.random() < p
    for k in range(m): R = R | (R[:, [k]] & R[[k], :])
    return (lambda x, y: x == y or bool(R[x, y])), R

def check16(sab):
    bad = tot = 0
    for n in range(0, 5):
        D = 1 << n; top = D - 1; elems = list(range(D))
        leq = lambda x, y: (x & y) == x
        geq = lambda x, y: (x & y) == y
        for k in range(0, 4):
            for diag in itertools.product(elems, repeat=k):
                tot += 1
                L, _ = limit_in_poset(elems, leq, diag)
                want = top
                for d in diag: want &= d
                if sab and k > 0:                                             # sabotage: OR in place of AND
                    want = 0
                    for d in diag: want |= d
                C, _ = limit_in_poset(elems, geq, diag)                       # colimit = limit in the opposite order
                wc = 0
                for d in diag: wc |= d
                if L != want or C != wc: bad += 1
    rng = np.random.default_rng(16); have = pairs = 0
    for _ in range(200):
        leq, R = random_poset(8, rng)
        for a in range(8):
            for b in range(a + 1, 8):
                pairs += 1
                L, _ = limit_in_poset(range(8), leq, (a, b))
                have += L is not None
    ok = bad == 0 and have < pairs
    return ok, (f'B_n, n = 0..4: limit of every discrete diagram with k = 0..3 objects = AND (colimit = OR): {tot - bad}/{tot}; '
                f'random posets of 8 elements (seed 16): a pair has a limit in {have}/{pairs} ({100 * have / pairs:.0f}%)')

def check17(sab):
    bad = tot = 0; unit_id = True; counit_w = set()
    for n in range(1, 5):
        D = 1 << n; elems = range(D)
        leq = lambda x, y: (x & y) == x
        for k in (2, 3):
            for d in itertools.product(elems, repeat=k):
                m = D - 1
                for x in d: m = (m | x) if sab else (m & x)                      # sabotage: OR as the right adjoint
                for c in elems:
                    tot += 1
                    if all(leq(c, x) for x in d) != leq(c, m): bad += 1
                for x in d: counit_w.add(pc(x) - pc(m))
            for c in elems:
                m = D - 1
                for _ in range(k): m &= c
                if m != c: unit_id = False
    ok = bad == 0
    return ok, (f'Hom(Delta c, d) non-empty <-> Hom(c, AND d) non-empty: {tot - bad}/{tot} (n = 1..4, |J| = 2, 3); read off, not counted: the unit eta_c '
                f'is the identity at every object (c AND c = c: {unit_id}, weight 0); the counit leg weights |d_j| - |AND d| take the values {sorted(counit_w)}')

def check18(sab):
    rng = np.random.default_rng(18); bad = tot = 0
    for n in range(1, 5):
        D = 1 << n
        for _ in range(5):
            if sab:                                                          # sabotage: an energy that is not increasing (weights of both signs)
                E = rng.normal(size=D)
            else:
                E = np.array([pc(a) + 0.45 * rng.random() for a in range(D)])   # strictly increasing along inclusion (steps >= 0.55)
            for k in (2, 3):
                for diag in itertools.product(range(D), repeat=k):
                    tot += 1
                    m = D - 1
                    for x in diag: m &= x
                    cones = [c for c in range(D) if all((c & x) == c for x in diag)]
                    wts = [sum(E[x] - E[c] for x in diag) for c in cones]
                    best = min(wts); arg = [c for c, w in zip(cones, wts) if abs(w - best) < 1e-12]
                    if arg != [m]: bad += 1
    # random posets: limit => unique minimal cone; count pairs with no limit and a minimal cone
    nolim_min = lim_ok = lims = 0
    for _ in range(200):
        leq, R = random_poset(8, rng)
        h = np.array([R[:, x].sum() for x in range(8)], dtype=float) + 0.001 * rng.random(8)   # strictly increasing: number of elements below
        for a in range(8):
            for b in range(a + 1, 8):
                L, cones = limit_in_poset(range(8), leq, (a, b))
                if not cones: continue
                wts = [h[a] + h[b] - 2 * h[c] for c in cones]
                best = min(wts); arg = [c for c, w in zip(cones, wts) if abs(w - best) < 1e-12]
                if L is not None:
                    lims += 1; lim_ok += arg == [L]
                else:
                    nolim_min += 1
    # bowtie: elements c1 = 0, c2 = 1, a = 2, b = 3
    leq = lambda x, y: x == y or (x in (0, 1) and y in (2, 3))
    L, cones = limit_in_poset(range(4), leq, (2, 3))
    Eb = [0, 1, 2, 2]
    wts = {c: Eb[2] + Eb[3] - 2 * Eb[c] for c in cones}
    bow = L is None and min(wts, key=wts.get) == 1 and sorted(wts.values()) == [2, 4]
    ok = bad == 0 and lim_ok == lims and nolim_min > 0 and bow
    return ok, (f'B_n (n = 1..4, 5 energies each): the meet is the unique minimal-weight cone in {tot - bad}/{tot} diagrams; random posets: limit = unique '
                f'minimal cone in {lim_ok}/{lims} pairs with a limit, {nolim_min} pairs with cones but no limit (a minimal cone exists there); bowtie: '
                f'no limit, unique minimal cone c2 of weight {wts.get(1)} (c1: {wts.get(0)}): {bow}')

def maximal_chains(n):
    """number of maximal chains 0 -> [n] of B_n, by a recursion over the covering steps T \\ {i} -> T"""
    D = 1 << n; m = [0] * D; m[0] = 1
    for T in sorted(range(1, D), key=pc):
        m[T] = sum(m[T ^ (1 << i)] for i in range(n) if T >> i & 1)
    return m[D - 1]
def chains(n):
    """number of strict chains 0 -> [n] (all lengths)"""
    D = 1 << n; full = D - 1
    cnt = [0] * D; cnt[0] = 1
    for T in sorted(range(D), key=pc):
        if T == 0: continue
        sub = T
        s = 0
        S = (T - 1) & T
        while True:
            s += cnt[S]
            if S == 0: break
            S = (S - 1) & T
        cnt[T] = s
    return cnt[full]
def check19(sab):
    rng = np.random.default_rng(19); ok = True; fub = []
    for n in range(0, 7):
        fub.append(chains(n))
    ok &= fub == [1, 1, 3, 13, 75, 541, 4683]
    eq_all = True; mx = []
    for n in range(1, 7):
        D = 1 << n
        perms = list(itertools.permutations(range(n)))       # a maximal chain adds the modes one at a time, in the order of a permutation
        mx.append(maximal_chains(n))
        for trial in range(21):
            if trial == 0: E = [pc(a) for a in range(D)]
            else: E = list(rng.normal(size=D))
            if sab:                                                          # sabotage: an edge weight that is not a potential difference
                wedge = {(S, i): rng.random() for S in range(D) for i in range(n)}
                pw = lambda path: sum(wedge[(S, i)] for S, i in path)
            else:
                pw = lambda path: sum(E[S | (1 << i)] - E[S] for S, i in path)
            vals = set()
            for p in perms:
                S = 0; path = []
                for i in p: path.append((S, i)); S |= 1 << i
                vals.add(round(pw(path), 9))
            if len(vals) != 1 or abs(list(vals)[0] - (E[D - 1] - E[0])) > 1e-9: eq_all = False
    ok &= eq_all and mx == [factorial(n) for n in range(1, 7)]
    return ok, (f'chains 0 -> [n] of all lengths, n = 0..6: {fub}; maximal chains (recursion over the covering steps), n = 1..6: {mx} = n!; every maximal '
                f'path has weight E([n]) - E(0) for popcount and 20 random potentials: {eq_all} (every path is a minimiser)')

def check20(sab):
    rng = np.random.default_rng(20); ok = True; msgs = []
    for n in range(3, 7):
        D = 1 << n
        w = {(S, i): float(rng.uniform(0.5, 2.0)) for S in range(D) for i in range(n) if not S >> i & 1}
        perms = list(itertools.permutations(range(n)))
        pws = []
        for p in perms:
            S = 0; tot = 0.0
            for i in p: tot += w[(S, i)]; S |= 1 << i
            pws.append(tot)
        pws = np.array(pws); mn = pws.min()
        uniq = int(np.sum(np.abs(pws - mn) < 1e-12)) == 1
        # min-plus over the DAG (Bellman-Ford in topological order)
        best = {0: 0.0}
        for S in sorted(range(D), key=pc):
            if S not in best: continue
            for i in range(n):
                if not S >> i & 1:
                    T = S | (1 << i); val = best[S] + w[(S, i)]
                    if T not in best: best[T] = val
                    else: best[T] = max(best[T], val) if sab else min(best[T], val)   # sabotage: (max, +) in place of (min, +)
        trop_ok = abs(best[D - 1] - mn) < 1e-12
        lim_ok = True
        for beta in (1.0, 10.0, 100.0):
            Fb = mn - np.log(np.sum(np.exp(-beta * (pws - mn)))) / beta
            if not (0 <= mn - Fb <= log(factorial(n)) / beta + 1e-12): lim_ok = False
        ok &= uniq and trop_ok and lim_ok
        msgs.append(f'n={n}: min {mn:.4f}, unique {uniq}, min-plus {trop_ok}, |F - min| <= ln(n!)/beta {lim_ok}')
    return ok, 'free category on the Hasse diagram, generic weights (seed 20): ' + '; '.join(msgs) + ' (the bound on F is the generic log-sum-exp bound)'

def check21(sab):
    ok = True; msgs = []; rng = np.random.default_rng(21)
    for n in range(2, 7):
        D = 1 << n
        perms = list(itertools.permutations(range(n)))
        def amp(edge_sign):
            tot = 0
            for p in perms:
                S = 0; s = 1
                for i in p: s *= edge_sign(i, S); S |= 1 << i
                tot += s
            return tot
        fer = amp(lambda i, S: 1 if sab else sgn(1 << i, S, [1] * n))        # sabotage: the sign dropped (|s|)
        bos = amp(lambda i, S: 1)
        zeros = 0
        if n <= 4:
            for _ in range(200):
                t = {(i, S): int(rng.choice([-1, 1])) for S in range(D) for i in range(n)}
                zeros += amp(lambda i, S: t[(i, S)]) == 0
        ok &= fer == 0 and bos == factorial(n) and (n > 4 or zeros < 200)
        msgs.append(f'n={n}: fermionic {fer}, bosonic {bos}' + (f', random signs zero in {zeros}/200' if n <= 4 else ''))
    return ok, 'sum over the n! maximal chains of the creation products on |0>, coefficient of |[n]>: ' + '; '.join(msgs)

def check22(sab):
    rng = np.random.default_rng(22); ok = True; worst = 0.0
    for n in range(1, 7):
        D = 1 << n
        q = rng.uniform(0.2, 2.0, size=n)
        E = np.array([sum(q[i] for i in range(n) if a >> i & 1) for a in range(D)])
        for beta in (0.3, 1.0, 2.5):
            for S in range(D):
                Ts = range(D) if sab else [T for T in range(D) if (S & T) == S]   # sabotage: every label counted (arrows in both directions)
                lhs = sum(exp(-beta * (E[T] - E[S])) for T in Ts)
                rhs = 1.0
                for i in range(n):
                    if not S >> i & 1: rhs *= 1 + exp(-beta * q[i])
                worst = max(worst, abs(lhs - rhs) / rhs)
    ok &= worst < 1e-12
    fails = 0; n = 5; D = 1 << n
    for _ in range(200):
        E = np.array([pc(a) + 0.45 * rng.random() for a in range(D)]); E[0] = 0.0
        lhs = sum(exp(-(E[T] - E[0])) for T in range(D))
        rhs = 1.0
        for i in range(n): rhs *= 1 + exp(-(E[1 << i] - E[0]))
        fails += abs(lhs - rhs) > 1e-9
    ok &= fails == 200
    return ok, (f'free (charge) weights, n = 1..6, beta in {{0.3, 1, 2.5}}, every S: max relative deviation from prod (1 + e^(-beta q_i)) = {worst:.1e}; '
                f'random interacting energies (n = 5, seed 22): the product formula fails in {fails}/200')

CHECKS = [('bd·mjp·16', check16, 'limits in B_n are meets; random posets lack some'),
          ('bd·mjp·17', check17, 'Delta -| AND on B_n: the hom comparisons'),
          ('bd·mjp·18', check18, 'limit => unique minimal cone weight; converse fails (bowtie)'),
          ('bd·mjp·19', check19, 'thin path sums are degenerate; n! maximal chains and ordered Bell counts'),
          ('bd·mjp·20', check20, 'free Hasse category: tropical limit, unique minimiser'),
          ('bd·mjp·21', check21, 'path sum 0 -> [n] of creation products: n! (hard-core bosons), 0 (fermions)'),
          ('bd·mjp·22', check22, 'out-sum = free-fermion grand partition function for charge weights')]

def main():
    for cid, f, short in CHECKS:
        ok, text = f(SAB)
        report(cid, ok, text, short)
    finish()

if __name__ == '__main__':
    main()
