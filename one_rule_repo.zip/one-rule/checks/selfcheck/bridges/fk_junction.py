#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""fk_junction.py: the clock as a junction observable.

Two stacks of time-reversal-invariant (BDI) Kitaev chains with windings W (left) and W' (right) are joined end to end.  A chain with pairing +t
at the sweet spot (mu = 0, Delta = t) has H = i t sum_x b_x a_{x+1} with Majoranas a_x = c_x + c_x^+ (T-even) and b_x = -i(c_x - c_x^+) (T-odd)
under T = complex conjugation; its left end carries the zero mode a_0, its right end b_{L-1}.  A chain with pairing -t has the opposite
assignment.  The left stack has |W| chains of L = 2 sites (so it has bulk), the right stack |W'| chains of 1 site.  At the interface the free
zero modes are p T-even and q T-odd Majoranas with p - q = W' - W: the cell Cl(p, q) of the interface, clock (W' - W) mod 8.

The outer ends of both stacks stand for ends infinitely far away: their zero modes are exactly decoupled (no term touches them) and are left
out of the Hilbert space, except one of them kept as a decoupled spectator when the number of remaining Majoranas is odd.  All remaining
Majoranas (the bulk of the left stack and every interface mode) are kept, and the Hamiltonian is
    H = (sweet-spot bulk bonds) + (every T-invariant, parity-even monomial of weight 2 and 4 in the junction region, random weights),
the junction region being the interface modes and the bulk Majorana next to each of them.  T-invariance is built in: the real generators are
e_j = gamma_j (T-even) and i gamma_j (T-odd), a monomial e_S with a real coefficient commutes with T, and it is Hermitian exactly when
e_S^2 = +1 (the form Q(S) = 0).  The many-body Hamiltonian is a sparse matrix on the Jordan-Wigner Fock space (dimension up to 2^14); the
ground-state multiplicity is counted with sparse Lanczos plus deflation (a found state is shifted up and the next lowest state is searched
again), tolerance 1e-8 on the energy.

  bd·fk·1  the interface zero modes of the free (BdG) junction form the cell Cl(p,q) with p - q = W' - W, for every tested (W, W').
  bd·fk·2  control, free fermions: with every T-invariant quadratic coupling (random) and no quartic term, the junction ground state is
           2^(d/2)-fold degenerate, d = |W - W'| (d + 1 with the spectator for odd d): the free invariant is the integer |W - W'|.
  bd·fk·3  with all T-invariant parity-even quadratic and quartic junction terms (random: seed 101 for W = 8, seeds 101 and 202 for the others),
           the ground-state degeneracy is 1, 2, 2, 4, 2, 4, 2, 2 for (W - W') = 0, 1, ..., 7 mod 8 (odd residues counted with the spectator),
           the same for every tested realisation of a residue: W = 8 against W' = 0, 1, 2, 3, 4, -1, -2, -3, and (4,4), (4,-4), (2,-2), (4,0),
           (1,-1), (3,-3), (3,0), (2,-3), (1,0), (4,-3).
  bd·fk·4  residue 0, constructive: for (8,0) and (4,-4), whose 8 interface modes all have the same T-parity, the [8,4,4] Hamming stabilizers
           (the Fano-line blades of core·B11) give a unique T-invariant, parity-definite ground state with a gap, which stays unique and gapped
           when a random T-invariant perturbation of size 0.1 is added; (4,4) is gapped by quadratic pairing alone.
  bd·fk·5  the lower bound for every Hamiltonian of the class: on the junction Fock space the time reversal satisfies (T^2, T P = +-P T) = (+1,+),
           (+1,-), (-1,+), (-1,-) for (W' - W) = 0, 2, 4, 6 mod 8, so for an even nonzero residue every T-invariant parity-even junction
           Hamiltonian is at least 2-fold degenerate (Kramers or parity doubling); for odd residues the spectator and the product of the
           junction Majoranas anticommute and commute with every such H: at least 2-fold.

  python3 fk_junction.py                 run the checks: one line per check id, exit code 1 on any FAIL (about 40 s on one core)
  python3 fk_junction.py --only <id>     run only the check <id> (for example bd·fk·1)
  python3 fk_junction.py --sabotage      run every check on a deliberately broken input (CAUGHT/MISSED lines, with what the broken run
                                         computed; exit code 0 when every check catches its break, the last line ALL CAUGHT):
    bd·fk·1 mislabels the T-parity of the right stack; bd·fk·2 adds the Hamming quartic terms to the free (8,0) junction; bd·fk·3 adds random
    T-odd Hermitian bilinears i e_a e_b (same T-parity) at the junction, which split the degeneracies; bd·fk·4 keeps only 3 of the 4 Hamming
    generators (a 2-fold ground state); bd·fk·5 mislabels the T-parity of the right stack in three junctions.
numpy and scipy.sparse (sparse matrices and the Lanczos solver eigsh) and the standard library; deterministic (fixed seeds)."""
import os, sys, itertools
for _v in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'): os.environ.setdefault(_v, '1')   # one core
import numpy as np
from scipy.sparse import csr_matrix, identity
from scipy.sparse.linalg import eigsh

TOL = 1e-8

# ============================================================== the sign of selfcheck/core_check.py and the label form Q
def pc(a): return bin(a).count('1')
def sq_sign(idx, eps):
    """sign of e_S^2 for the ordered product e_S of generators idx (ascending) with squares eps: (-1)^(k(k-1)/2) prod eps"""
    k = len(idx); s = (-1) ** (k * (k - 1) // 2)
    for i in idx: s *= eps[i]
    return s

# ============================================================== the junction lattice model
class Junction:
    """Majoranas of the junction after removing the decoupled outer zero modes.  Each Majorana: (name, Tparity 'E'/'O', role)."""
    def __init__(self, W, Wp, L_left=2, L_right=1, flip_right=False):
        self.W, self.Wp = W, Wp
        maj = []; bonds = []; outer = []; interface = []; adjacent = {}
        def chain(tag, sgn, L, side):
            # sgn = +1: bonds i b_x a_{x+1}; zero modes a_0 (left end), b_{L-1} (right end); sgn = -1: bonds -i a_x b_{x+1}
            names = []
            for x in range(L):
                names.append((f'{tag}a{x}', 'E')); names.append((f'{tag}b{x}', 'O'))
            if flip_right and side == 'R':                       # sabotage: mislabel the T-parity of the right stack
                names = [(n, 'O' if t == 'E' else 'E') for n, t in names]
            bl = []
            for x in range(L - 1):
                bl.append((f'{tag}b{x}', f'{tag}a{x + 1}') if sgn > 0 else (f'{tag}a{x}', f'{tag}b{x + 1}'))
            left_end = f'{tag}a0' if sgn > 0 else f'{tag}b0'; right_end = f'{tag}b{L - 1}' if sgn > 0 else f'{tag}a{L - 1}'
            return names, bl, left_end, right_end
        sL = 1 if W >= 0 else -1; sR = 1 if Wp >= 0 else -1
        for c in range(abs(W)):
            names, bl, le, re = chain(f'L{c}', sL, L_left, 'L')
            maj += names; bonds += bl; outer.append(le); interface.append(re)
            if L_left >= 2:                                      # the bulk Majorana bonded to... the one next to the interface mode
                x = L_left - 1; adjacent[re] = f'L{c}a{x}' if sL > 0 else f'L{c}b{x}'
        for c in range(abs(Wp)):
            names, bl, le, re = chain(f'R{c}', sR, L_right, 'R')
            maj += names; bonds += bl; outer.append(re); interface.append(le)
            if L_right >= 2:
                adjacent[le] = f'R{c}b0' if sR > 0 else f'R{c}a0'
        self.all_maj = maj; self.bonds = bonds; self.outer = outer; self.interface = interface; self.adjacent = adjacent
        types = dict(maj)
        rest = [n for n, t in maj if n not in outer]
        self.spectator = None
        if len(rest) % 2 == 1:                                   # keep one decoupled outer mode so that the Fock space exists
            self.spectator = outer[0]; rest.append(outer[0])
        # Jordan-Wigner order: T-even first, then T-odd
        ev = [n for n in rest if types[n] == 'E']; od = [n for n in rest if types[n] == 'O']
        self.order = ev + od; self.p = len(ev); self.q = len(od); self.n = len(self.order)
        self.pos = {nm: i for i, nm in enumerate(self.order)}
        self.eps = [1] * self.p + [-1] * self.q
        self.types = types
        region = list(interface) + [adjacent[m] for m in interface if m in adjacent]
        self.region = sorted({self.pos[m] for m in region})
    # ---------------------------------------------------------- free BdG check of the interface cell (bd·fk·1)
    def interface_cell(self):
        names = [n for n, _ in self.all_maj]; ix = {n: i for i, n in enumerate(names)}; N = len(names)
        A = np.zeros((N, N))
        for u, v in self.bonds:
            A[ix[u], ix[v]] += 2.0; A[ix[v], ix[u]] -= 2.0
        _, s, Vt = np.linalg.svd(A)
        ker = Vt[np.concatenate([s, np.zeros(N - len(s))]) < 1e-9] if N else np.zeros((0, 0))
        Pk = ker.T @ ker if len(ker) else np.zeros((N, N))
        p_int = round(sum(Pk[ix[m], ix[m]] for m in self.interface if self.types[m] == 'E'))
        q_int = round(sum(Pk[ix[m], ix[m]] for m in self.interface if self.types[m] == 'O'))
        tot_zero = len(ker)
        return p_int, q_int, tot_zero

# ============================================================== Fock-space operators (Jordan-Wigner, sparse)
class Fock:
    def __init__(self, J):
        self.J = J; self.m = J.n // 2; self.dim = 1 << self.m
        self.s = np.arange(self.dim, dtype=np.int64)
        pp = np.zeros(self.dim, dtype=np.int64)
        for k in range(self.m): pp ^= (self.s >> k) & 1
        self.popparity = pp                                     # parity of popcount(s)
    def gamma_phase(self, j, cur):
        k = j // 2; low = (1 << k) - 1
        par = self.popparity[cur & low]
        ph = np.where(par == 1, -1.0, 1.0).astype(complex)
        if j % 2 == 1: ph = ph * 1j * np.where((cur >> k) & 1, -1.0, 1.0)
        return ph, 1 << k
    def monomial(self, idx, real_gen=True):
        """e_{i1} ... e_{ik} (ascending idx) applied to every basis state: returns (mask, phase vector) with M|s> = phase(s)|s ^ mask>"""
        cur = self.s.copy(); ph = np.ones(self.dim, dtype=complex); mask = 0
        for j in reversed(idx):
            g, mk = self.gamma_phase(j, cur)
            if real_gen and j >= self.J.p: g = g * 1j               # e_j = i gamma_j for a T-odd Majorana
            ph *= g; cur ^= mk; mask ^= mk
        return mask, ph
    def matrix(self, terms):
        acc = {}
        for coef, idx in terms:
            mask, ph = self.monomial(idx)
            acc[mask] = acc.get(mask, 0) + coef * ph
        rows = []; cols = []; data = []
        for mask, ph in acc.items():
            nz = np.abs(ph) > 1e-15
            rows.append((self.s ^ mask)[nz]); cols.append(self.s[nz]); data.append(ph[nz])
        if not rows: return csr_matrix((self.dim, self.dim), dtype=complex)
        return csr_matrix((np.concatenate(data), (np.concatenate(rows), np.concatenate(cols))), shape=(self.dim, self.dim))
    def parity(self): return csr_matrix((np.where(self.popparity == 1, -1.0, 1.0).astype(complex), (self.s, self.s)), shape=(self.dim, self.dim))
    def time_reversal_U(self):
        """U with T = U K and T gamma_j T^-1 = +gamma_j (T-even, j < p), -gamma_j (T-odd).  Needs U gamma_j U^-1 = s_j sigma_j gamma_j,
        sigma_j = +1 for real (even JW index) and -1 for imaginary gamma_j; U is a product of Majoranas."""
        n, p = self.J.n, self.J.p
        t = [(1 if j < p else -1) * (1 if j % 2 == 0 else -1) for j in range(n)]
        minus = [j for j in range(n) if t[j] == -1]
        A = minus if len(minus) % 2 == 0 else [j for j in range(n) if t[j] == 1]
        mask, ph = self.monomial(sorted(A), real_gen=False)
        return csr_matrix((ph, (self.s ^ mask, self.s)), shape=(self.dim, self.dim))

# ============================================================== Hamiltonians
def bulk_terms(J, t=1.0):
    terms = []
    for u, v in J.bonds:
        if u in J.pos and v in J.pos:
            i, j = sorted((J.pos[u], J.pos[v])); terms.append((-t, (i, j)))   # a gapped pair (sign immaterial)
    return terms
def hermitian_ok(idx, J): return sq_sign(idx, J.eps) == 1
def junction_terms(J, rng, s2=0.1, s4=0.1, quartic=True):
    """every T-invariant Hermitian monomial of weight 2 and 4 in the junction region, with Gaussian weights normalised so that the
    sum of squared weights is s2 (quadratic part) and s4 (quartic part): a junction interaction smaller than the bulk gap 2"""
    R = J.region
    q2 = [(i, j) for i, j in itertools.combinations(R, 2) if hermitian_ok((i, j), J)]
    c2 = rng.normal(size=len(q2)); c2 *= np.sqrt(s2 / np.sum(c2 ** 2)) if len(q2) else 1
    terms = list(zip(c2, q2))
    if quartic:
        q4 = [c for c in itertools.combinations(R, 4) if hermitian_ok(c, J)]
        if q4:
            c4 = rng.normal(size=len(q4)); c4 *= np.sqrt(s4 / np.sum(c4 ** 2)); terms += list(zip(c4, q4))
    return terms
HAMMING = [(0, 1, 3, 7), (1, 2, 4, 7), (2, 3, 5, 7), (3, 4, 6, 7)]       # four independent Fano-line blades g_a g_b g_c g_8 (core·B11)
def fk_terms(J, gens=HAMMING, g=1.0):
    """the [8,4,4] stabilizers on the 8 interface modes (all of one T-parity), as T-invariant Hermitian monomials"""
    ints = sorted(J.pos[m] for m in J.interface)
    assert len(ints) == 8
    out = []
    for G in gens:
        idx = tuple(sorted(ints[k] for k in G))
        out.append((-g, idx))
    return out

# ============================================================== ground-state multiplicity (Lanczos + deflation)
def _lowest(Hs, seed, tol):
    """lowest eigenvalue of a Hermitian sparse block and its exact multiplicity (Lanczos + deflation), and the next eigenvalue"""
    dim = Hs.shape[0]
    if dim <= 1024:
        w = np.linalg.eigvalsh(Hs.toarray()); e0 = w[0]; m = int(np.sum(w < e0 + tol))
        return e0, m, (w[m] if m < dim else np.inf)
    from scipy.sparse.linalg import LinearOperator
    rng = np.random.default_rng(seed); v0 = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    w, V = eigsh(Hs, k=4, which='SA', tol=1e-11, v0=v0, maxiter=50000)
    o = np.argsort(w); w, V = w[o], V[:, o]; e0 = w[0]
    found = [V[:, i] for i in range(4) if w[i] < e0 + tol]
    if len(found) < 4: return e0, len(found), w[len(found)]
    shift = 10.0 * (abs(e0) + 10.0)
    while True:
        B, _ = np.linalg.qr(np.array(found).T)
        Hd = LinearOperator((dim, dim), matvec=lambda x, B=B: Hs @ x + shift * (B @ (B.conj().T @ x)), dtype=complex)
        w2, V2 = eigsh(Hd, k=4, which='SA', tol=1e-11, v0=v0, maxiter=50000)
        o = np.argsort(w2); w2, V2 = w2[o], V2[:, o]
        new = [V2[:, i] for i in range(4) if w2[i] < e0 + tol]
        found += new
        if len(new) < 4: return e0, len(found), w2[len(new)]
def ground_multiplicity(H, parity=None, tol=TOL, seed=0):
    """number of exactly degenerate lowest states (|E - E0| < tol) of a parity-even H, counted sector by sector; and the gap above"""
    if parity is None:
        e0, m, nxt = _lowest(H, seed, tol); return m, e0, nxt - e0
    res = []
    for sec in (0, 1):
        ix = np.where(parity == sec)[0]
        res.append(_lowest(H[ix][:, ix], seed + sec, tol))
    e0 = min(r[0] for r in res)
    m = sum(r[1] for r in res if r[0] < e0 + tol)
    nxt = min([r[2] for r in res if r[0] < e0 + tol] + [r[0] for r in res if r[0] >= e0 + tol])
    return m, e0, nxt - e0

# ============================================================== cases
MAIN = [(8, 0), (8, -1), (8, -2), (8, -3), (8, 4), (8, 3), (8, 2), (8, 1)]      # residues (W - W') mod 8 = 0, 1, ..., 7
SMALL = [(4, 4), (4, -4), (2, -2), (4, 0), (1, -1), (3, -3), (3, 0), (2, -3), (1, 0), (4, -3)]
EXPECT = {0: 1, 1: 2, 2: 2, 3: 4, 4: 2, 5: 4, 6: 2, 7: 2}

def degeneracy(W, Wp, seed, quartic=True, extra=None, sabotage_T=False, sabotage_P=False):
    J = Junction(W, Wp); F = Fock(J); rng = np.random.default_rng(seed)
    terms = bulk_terms(J) + junction_terms(J, rng, quartic=quartic)
    H = F.matrix(terms)
    if sabotage_T:                                                   # i x (anti-Hermitian T-invariant bilinear e_a e_b, Q = 1): Hermitian, T-odd
        add = [(0.7 * rng.normal(), (i, j)) for i, j in itertools.combinations(J.region, 2) if sq_sign((i, j), J.eps) == -1]
        H = H + 1j * F.matrix(add)
    if sabotage_P:                                                   # a parity-odd T-invariant Hermitian term: one T-even Majorana
        ev = [i for i in J.region if i < J.p] or list(range(J.p))
        H = H + F.matrix([(0.7, (ev[0],))])
    if extra is not None: H = H + F.matrix(extra(J, rng))
    par = None if sabotage_P else F.popparity
    m, e0, gap = ground_multiplicity(H, par, seed=seed)
    return m, gap, F.dim, J

# ============================================================== checks
def check1(sab):
    ok = True; rows = []
    for W, Wp in MAIN + SMALL:
        J = Junction(W, Wp, flip_right=sab)
        p, q, z = J.interface_cell()
        good = (p - q == Wp - W) and (p + q == abs(W) + abs(Wp)) and z == 2 * (abs(W) + abs(Wp))
        ok &= good; rows.append(f'({W},{Wp}):Cl({p},{q})')
    return ok, 'interface cells of the free junctions: ' + ' '.join(rows) + ' (p - q = W\' - W)'
def check2(sab):
    ok = True; rows = []
    cases = [(8, 0), (4, -4), (4, 4), (6, 0), (4, 0), (2, -1), (3, 0), (1, -1)]
    for W, Wp in cases:
        extra = (lambda J, rng: fk_terms(J)) if (sab and (W, Wp) == (8, 0)) else None
        m, gap, dim, J = degeneracy(W, Wp, seed=11, quartic=False, extra=extra)
        d = abs(W - Wp); want = 2 ** ((d + (d % 2)) // 2)
        ok &= (m == want); rows.append(f'({W},{Wp}): {m} (2^{(d + (d % 2)) // 2})')
    return ok, 'free junctions (quadratic T-invariant couplings only): ground-state multiplicity ' + '; '.join(rows)
def check3(sab):
    ok = True; table = {}; rows = []
    for W, Wp in MAIN + SMALL:
        r = (W - Wp) % 8
        for seed in ((101,) if abs(W) + abs(Wp) > 8 else (101, 202)):
            m, gap, dim, J = degeneracy(W, Wp, seed=seed, sabotage_T=sab)
            table.setdefault(r, set()).add(m)
            ok &= (m == EXPECT[r]) and gap > 1e-4
            if seed == 101:
                pi, qi, _ = J.interface_cell()
                rows.append(f'({W},{Wp}) r={r} interface Cl({pi},{qi}) [kept Majoranas Cl({J.p},{J.q}), dim {dim}]: {m}, gap {gap:.3f}')
    ok &= all(len(v) == 1 for v in table.values())
    return ok, 'interacting junctions (all T-invariant parity-even quadratic + quartic junction terms; seed 101, and 202 for |W|+|W\'| <= 8), multiplicity by residue ' + \
        str({r: sorted(v) for r, v in sorted(table.items())}) + ' :: ' + '; '.join(rows)
def check4(sab):
    ok = True; rows = []
    gens = HAMMING[:3] if sab else HAMMING
    for W, Wp in [(8, 0), (4, -4)]:
        J = Junction(W, Wp); F = Fock(J)
        H = F.matrix(bulk_terms(J) + fk_terms(J, gens))
        m, e0, gap = ground_multiplicity(H, F.popparity)
        rng = np.random.default_rng(404)
        Hp = H + F.matrix(junction_terms(J, rng, s2=0.01, s4=0.01))
        m2, e2, gap2 = ground_multiplicity(Hp, F.popparity)
        # T-invariance and parity of the perturbed Hamiltonian, and parity-definiteness of the ground state
        U = F.time_reversal_U(); P = F.parity()
        dT = abs(U @ Hp.conj() @ U.conj().T - Hp).max(); dP = abs(P @ Hp - Hp @ P).max()
        ok &= (m == 1 and gap > 0.5 and m2 == 1 and gap2 > 0.2 and dT < 1e-10 and dP < 1e-10)
        rows.append(f'({W},{Wp}): Hamming stabilizers {m} state(s), gap {gap:.3f}; with perturbation {m2}, gap {gap2:.3f}')
    J = Junction(4, 4); F = Fock(J)
    pair = []
    for k in range(4):
        a = J.pos[f'R{k}a0']; b = J.pos[f'L{k}b1']; pair.append((-1.0, tuple(sorted((a, b)))))
    m3, e3, gap3 = ground_multiplicity(F.matrix(bulk_terms(J) + pair), F.popparity)
    ok &= (m3 == 1 and gap3 > 0.5)
    rows.append(f'(4,4): quadratic pairing {m3} state(s), gap {gap3:.3f}')
    return ok, 'residue 0, constructive: ' + '; '.join(rows)
def check5(sab):
    ok = True; rows = []
    want = {0: (1, 1), 2: (1, -1), 4: (-1, 1), 6: (-1, -1)}
    for W, Wp in [(8, 0), (8, -2), (8, 4), (8, 2), (4, 4), (4, -4), (2, -2), (1, -1), (3, -3), (4, 0)]:
        J = Junction(W, Wp, flip_right=sab and (W, Wp) in ((8, 2), (2, -2), (1, -1))); F = Fock(J)
        U = F.time_reversal_U(); P = F.parity(); I = identity(F.dim, dtype=complex, format='csr')
        T2 = U @ U.conj(); s = 1 if abs(T2 - I).max() < 1e-12 else (-1 if abs(T2 + I).max() < 1e-12 else 0)
        TP = U @ P.conj() @ U.conj().T; c = 1 if abs(TP - P).max() < 1e-12 else (-1 if abs(TP + P).max() < 1e-12 else 0)
        r = (Wp - W) % 8
        ok &= (s, c) == want[r]
        rows.append(f'({W},{Wp}) W\'-W={r}: T^2={s:+d}, TP={"+" if c == 1 else "-"}PT')
    # odd residues: the spectator alpha and the product Gamma of the junction Majoranas anticommute and commute with H
    for W, Wp in [(8, -1), (3, 0), (2, -3)]:
        J = Junction(W, Wp); F = Fock(J)
        sp = J.pos[J.spectator]; others = tuple(i for i in range(J.n) if i != sp)
        A = F.matrix([(1.0, (sp,))]); G = F.matrix([(1.0, others)])
        H = F.matrix(bulk_terms(J) + junction_terms(J, np.random.default_rng(5)))
        anti = abs(A @ G + G @ A).max() < 1e-10; comm = abs(A @ H - H @ A).max() < 1e-10 and abs(G @ H - H @ G).max() < 1e-10
        ok &= anti and comm
        rows.append(f'({W},{Wp}): spectator and Gamma anticommute {anti}, commute with H {comm}')
    return ok, 'symmetry lower bound: ' + '; '.join(rows)

CHECKS = [('bd·fk·1', check1, 'interface zero modes of the free junction form Cl(p,q) with p - q = W\' - W'),
          ('bd·fk·2', check2, 'free junction: ground state 2^(|W-W\'|/2)-fold (integer invariant |W - W\'|)'),
          ('bd·fk·3', check3, 'interacting junction: degeneracy 1,2,2,4,2,4,2,2 by (W - W\') mod 8, same for every realisation'),
          ('bd·fk·4', check4, 'residue 0: Hamming/FK stabilizers give a unique gapped T-invariant ground state, robust'),
          ('bd·fk·5', check5, 'T^2 and T vs P of the junction force degeneracy >= 2 for every nonzero residue')]

def main():
    sab = '--sabotage' in sys.argv
    only = sys.argv[sys.argv.index('--only') + 1] if '--only' in sys.argv else None
    if only is not None and only not in [c[0] for c in CHECKS]: sys.exit(f'unknown check id {only}')
    run, fails = 0, []
    for cid, f, short in CHECKS:
        if only is not None and cid != only: continue
        ok, text = f(sab); run += 1
        if sab: print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  ' + short + '\n       the sabotaged run computes: ' + text)
        else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
        if (ok and sab) or (not ok and not sab): fails.append(cid)
    if sab: print('\n' + ('ALL CAUGHT' if not fails else f'{len(fails)} MISSED: ' + ' '.join(fails)))
    else: print(f'\n{run - len(fails)}/{run} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not fails else '  FAILED: ' + ' '.join(fails)))
    sys.exit(1 if fails else 0)

if __name__ == '__main__':
    main()
