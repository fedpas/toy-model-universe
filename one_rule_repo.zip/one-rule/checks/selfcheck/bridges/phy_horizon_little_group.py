#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""phy_horizon_little_group.py: the null-surface step (step 13), the Lorentz algebra and Wigner's little group, joined.

At T = 0 the tangent algebra of the tube is Cl(0,2,1) and its three bivectors span iso(2) (NUL-004).  The little group of a massless particle
is a subalgebra of so(1,3) acting on the ambient vectors, while iso(2) here is the bivector algebra of a degenerate cell acting on its own
vectors.  The script builds the natural map between the two and checks that it is a Lie algebra isomorphism that also intertwines the two
actions on the tangent space l^perp of the null surface.

  bd·phy·5  in Cl(1,3) (time +1) with l = e0 + e1 null, the bivectors B with [B, l] = 0 (equivalently l.B = 0) form a 3-dimensional Lie
            subalgebra of so(1,3), the stabiliser of l, with basis l e2, l e3, e2 e3.
  bd·phy·6  the map l e2 -> n e2, l e3 -> n e3, e2 e3 -> e2 e3 into the bivectors of Cl(0,2,1) (n the null generator, e2, e3 of square -1) is a
            Lie algebra isomorphism (all 9 brackets agree), and both algebras are iso(2): [J, K1] = 2 K2, [J, K2] = -2 K1, [K1, K2] = 0, with
            K1, K2 spanning an abelian ideal.
  bd·phy·7  the action x -> (1/2)[B, x] of the stabiliser on l^perp = span(l, e2, e3) in Cl(1,3) equals the action of the image bivectors on
            span(n, e2, e3) in Cl(0,2,1) under l -> n, e2 -> e2, e3 -> e3 (a null rotation shifts e_k by a multiple of l and kills l).
  bd·phy·8  the tube algebra Cl(T, -1, -1): [K1, K2] = -2 T J, so the bivectors form so(1,2), iso(2), so(3) at T = 1, 0, -1 (computed
            independently of the null-surface script, which checks the same contraction for NUL-004).

  python3 phy_horizon_little_group.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; under a second."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))          # phy_bitrule.py sits next to this script
import numpy as np
from phy_bitrule import Alg, Reporter

def main():
    R = Reporter()
    A = Alg.pq(1, 3)                       # Cl(1,3): e0^2 = +1 (time), e1,e2,e3 squares -1
    e0, e1, e2, e3 = (A.blade(1 << i) for i in range(4))
    l = e0 + e1
    # all six bivector blades
    biv = [A.blade(m) for m in range(16) if A.grade[m] == 2]
    # stabiliser: B with [B, l] = 0 (for a bivector B and vector l, [B,l] = 2 B.l, so l.B = 0)
    M = np.array([A.commutator(B, l) for B in biv]).T        # 16 x 6
    # null space of M
    u, s, vt = np.linalg.svd(M)
    rank = int((s > 1e-9).sum())
    dim_stab = 6 - rank
    stab_basis = vt[rank:].T                                   # 6 x dim
    # check the explicit basis l e2, l e3, e2 e3 spans it
    K1 = A.mul(l, e2); K2 = A.mul(l, e3); J = A.mul(e2, e3)
    def in_span(B):
        coeffs = np.array([B[m] for m in range(16) if A.grade[m] == 2])
        resid = coeffs - stab_basis @ (stab_basis.T @ coeffs)
        return np.abs(resid).max() < 1e-9
    closed = all(in_span(A.commutator(X, Y)) for X in (K1, K2, J) for Y in (K1, K2, J))
    R('bd·phy·5', dim_stab == 3 and all(in_span(X) for X in (K1, K2, J)) and closed,
      'the stabiliser of the null vector l = e0 + e1 in so(1,3) has dimension %d, is spanned by l e2, l e3, e2 e3 and is closed under the bracket' % dim_stab)

    # the degenerate cell Cl(0,2,1): generators n (null, bit 2), f2, f3 (square -1, bits 0, 1); order the bits so the comparison is simple
    D = Alg([-1, -1, 0])
    f2, f3, nn = D.blade(1), D.blade(2), D.blade(4)
    K1d = D.mul(nn, f2); K2d = D.mul(nn, f3); Jd = D.mul(f2, f3)
    # structure constants: express brackets in the bases (K1, K2, J) and (K1d, K2d, Jd)
    def coords(A_, X, basis):
        Bm = np.array(basis).T
        c, res, rk, sv = np.linalg.lstsq(Bm, X, rcond=None)
        assert np.abs(Bm @ c - X).max() < 1e-9, 'not in span'
        return c
    basA = (K1, K2, J); basD = (K1d, K2d, Jd)
    same = True; table = []
    for i in range(3):
        for j in range(3):
            ca = coords(A, A.commutator(basA[i], basA[j]), basA)
            cd = coords(D, D.commutator(basD[i], basD[j]), basD)
            same &= np.abs(ca - cd).max() < 1e-9
            table.append(ca)
    table = np.array(table).reshape(3, 3, 3)
    # iso(2) pattern: [K1,K2] = 0; [J,K1] = c K2, [J,K2] = -c K1 with c != 0; K1, K2 an abelian ideal
    c = table[2, 0, 1]
    iso2 = (np.abs(table[0, 1]).max() < 1e-9 and abs(c) > 1e-9 and np.abs(table[2, 0] - np.array([0, c, 0])).max() < 1e-9
            and np.abs(table[2, 1] - np.array([-c, 0, 0])).max() < 1e-9)
    R('bd·phy·6', same and iso2,
      'the map l e_k -> n e_k, e2 e3 -> e2 e3 is a Lie algebra isomorphism stabiliser(l) in so(1,3) -> bivectors of Cl(0,2,1); '
      'both are iso(2): [J,K1] = %+g K2, [J,K2] = %+g K1, [K1,K2] = 0' % (c, -c))

    # bd·phy·7: intertwining of the actions on the tangent space of the null surface
    tanA = (l, e2, e3); tanD = (nn, f2, f3)
    ok = True; desc = []
    for i, (BA, BD) in enumerate(zip(basA, basD)):
        for k, (xA, xD) in enumerate(zip(tanA, tanD)):
            yA = 0.5 * A.commutator(BA, xA); yD = 0.5 * D.commutator(BD, xD)
            cA = coords(A, yA, tanA); cD = coords(D, yD, tanD)
            ok &= np.abs(cA - cD).max() < 1e-9
            if i == 0:
                desc.append('K1: %s -> %s' % (['l', 'e2', 'e3'][k], np.round(cA, 6).tolist()))
    R('bd·phy·7', ok, 'the actions on l^perp = span(l, e2, e3) and on span(n, e2, e3) agree under l -> n: ' + '; '.join(desc) +
      ' (a null rotation shifts e2 by a multiple of l and kills l: the ideal of null rotations is the radical direction)')

    # bd·phy·8: the tube algebra Cl(T,-1,-1) and its contraction
    res = []
    okc = True
    for T in (1, 0, -1):
        C = Alg([T, -1, -1])
        t, s2, s3 = C.blade(1), C.blade(2), C.blade(4)
        k1, k2, j = C.mul(t, s2), C.mul(t, s3), C.mul(s2, s3)
        br = C.commutator(k1, k2)
        cj = coords(C, br, (k1, k2, j))
        okc &= np.abs(cj - np.array([0, 0, -2 * T])).max() < 1e-9
        res.append('T=%d: [K1,K2] = %+g J' % (T, cj[2]))
    R('bd·phy·8', okc, 'the tube algebra Cl(T,-1,-1): ' + ', '.join(res) + ' (so(1,2), iso(2), so(3)); at T = 0 the bracket of K1 and K2 vanishes and the bivectors form iso(2), the little-group algebra of bd·phy·6')
    R.finish()

if __name__ == '__main__':
    main()
