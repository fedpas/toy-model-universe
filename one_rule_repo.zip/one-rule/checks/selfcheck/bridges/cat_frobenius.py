#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cat_frobenius.py: the Frobenius forms of Cl(p,q,r) read in super vector spaces.

  python3 selfcheck/bridges/cat_frobenius.py      one line per check, ids bd·cat·5 .. bd·cat·8 and bd·cat·22; exit 1 on any FAIL

Standard library only, exact integer ranks modulo the prime 1000003 and exact rationals; generic functionals from generators with fixed seeds;
deterministic, about 3 s; runs from any folder, reads and writes no file.
  bd·cat·5   the top-label form lambda (the coefficient of e_{1...1}, the complement pairing of cat·F1) is non-degenerate and super-symmetric,
             lambda(e_a e_b) = (-1)^{|a||b|} lambda(e_b e_a), for every eps in {+1,-1,0}^n, n <= 7; its parity is n mod 2, and the Nakayama sign of
             cat·F2 is the Koszul sign.
  bd·cat·6   the scalar part <e_a e_b>_0 is symmetric in the ungraded sense, super-symmetric only for p = q = 0, and non-degenerate iff r = 0 (n <= 6).
  bd·cat·7   the parity of a homogeneous non-degenerate Frobenius form is forced (= r mod 2) only for the exterior algebra Cl(0,0,r); with p + q >= 1
             both parities occur (generic-rank test, every signature with n <= 5).
  bd·cat·8   the super-symmetric functionals are exactly lambda(z .) with z in the super-centre Lambda(R^r), non-degenerate iff z is a unit: a torsor
             under the units of the super-centre for every signature with n <= 5.
  bd·cat·22  the window (handle) element sum_a e_a e_a^dual of lambda is 2^n e_{1...1}, of square 0 iff r >= 1 (n <= 5); Lambda(R^r) with lambda is a
             commutative Frobenius monoid in sVec that is not special.
"""
import itertools, random, sys

ROWS = []
def row(i, ok, text):
    cid = i
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
P = 1000003
def rank_mod(M):
    M = [[x % P for x in r] for r in M]; rk = 0; rows = len(M); cols = len(M[0]) if M else 0
    for c in range(cols):
        piv = next((i for i in range(rk, rows) if M[i][c]), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]; inv = pow(M[rk][c], P - 2, P); M[rk] = [x * inv % P for x in M[rk]]
        for i in range(rows):
            if i != rk and M[i][c]:
                f = M[i][c]; M[i] = [(x - f * y) % P for x, y in zip(M[i], M[rk])]
        rk += 1
    return rk

def check5():
    ok = True; cnt = 0
    for n in range(1, 8):
        F = (1 << n) - 1
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e)
            for a in range(1 << n):
                b = a ^ F                                  # lambda(e_a e_b) != 0 only for b = complement of a (cat·F1)
                lab, lba = sgn(a, b, e), sgn(b, a, e)
                if lab != (-1) ** (pc(a) * pc(b)) * lba: ok = False
                if lab == 0: ok = False                    # non-degenerate: +-1 on the antidiagonal
                if (-1) ** (pc(b) * (n - pc(b))) != (-1) ** (pc(a) * pc(b)): ok = False   # cat·F2's Nakayama sign = Koszul sign
            cnt += 1
    row('bd·cat·5', ok,
        f'the top-label form lambda is non-degenerate and super-symmetric, lambda(e_a e_b) = (-1)^(|a||b|) lambda(e_b e_a), for all {cnt} sign '
        'vectors with n <= 7 (null generators included); its parity is n mod 2; the Nakayama sign (-1)^(|b|(n-|b|)) of cat·F2 is the Koszul sign. '
        'In sVec every Cl(p,q,r) is a symmetric Frobenius algebra (even for n even, odd for n odd)')

def check6():
    ok = True; rows = []
    for n in range(1, 7):
        for r in range(0, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); N = 1 << n
                T = [[sgn(a, b, e) if a == b else 0 for b in range(N)] for a in range(N)]            # <e_a e_b>_0
                Tt = [[sgn(b, a, e) if a == b else 0 for b in range(N)] for a in range(N)]
                sym = T == Tt
                ssym = all(T[a][b] == (-1) ** (pc(a) * pc(b)) * Tt[a][b] for a in range(N) for b in range(N))
                nondeg = rank_mod(T) == N
                if not sym or ssym != (p + q == 0) or nondeg != (r == 0): ok = False
    row('bd·cat·6', ok,
        'the scalar part <e_a e_b>_0 is symmetric (ungraded) for every signature with n <= 6, super-symmetric only for p = q = 0 (where it is degenerate; '
        'otherwise <e_i e_i>_0 = eps_i would have to equal -eps_i), and non-degenerate exactly when r = 0: the trace of quantum mechanics is the Frobenius form of Vec, the complement form that of sVec')

def check7():
    rng = random.Random(20261007); ok = True; table = {}
    for n in range(1, 6):
        for r in range(0, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); N = 1 << n
                found = {}
                for par in (0, 1):
                    best = 0
                    for _ in range(6):
                        mu = [rng.randrange(1, P) if pc(c) % 2 == par else 0 for c in range(N)]
                        M = [[sgn(a, b, e) * mu[a ^ b] for b in range(N)] for a in range(N)]
                        best = max(best, rank_mod(M))
                    found[par] = best == N
                table[(p, q, r)] = found
                want = {n % 2: True, 1 - n % 2: False} if p + q == 0 else {0: True, 1: True}
                if found != want: ok = False
    row('bd·cat·7', ok,
        'homogeneous non-degenerate Frobenius forms (generic rank, 6 seeded draws per parity, every signature with n <= 5): for the exterior algebra '
        'Cl(0,0,r) only parity r mod 2 occurs (the Berezin integral); as soon as p + q >= 1 both parities occur, because an odd unit e_i '
        'shifts the parity (lambda(e_i .)): the parity of the Frobenius structure is an invariant exactly when no odd unit exists')

def nullspace_mod(M, ncols):
    """basis of {x : M x = 0} modulo P (row reduction)"""
    M = [[x % P for x in r] for r in M]; piv = []; rk = 0
    for c in range(ncols):
        pr = next((i for i in range(rk, len(M)) if M[i][c]), None)
        if pr is None: continue
        M[rk], M[pr] = M[pr], M[rk]; inv = pow(M[rk][c], P - 2, P); M[rk] = [x * inv % P for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c]:
                f = M[i][c]; M[i] = [(x - f * y) % P for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncols) if c not in piv]; basis = []
    for fc in free:
        v = [0] * ncols; v[fc] = 1
        for i, pc_ in enumerate(piv): v[pc_] = (-M[i][fc]) % P
        basis.append(v)
    return basis

def check8():
    rng = random.Random(8); ok = True; cnt = 0
    for n in range(1, 6):
        for r in range(0, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); N = 1 << n; F = N - 1
                D = sum(1 << i for i in range(n) if e[i] != 0); Z = F ^ D
                # super-symmetry: mu(e_a e_b) = (-1)^{|a||b|} mu(e_b e_a) for all a, b: linear conditions on mu(c), c = a xor b
                rows = []
                for a in range(N):
                    for b in range(N):
                        coef = sgn(a, b, e) - (-1) ** (pc(a) * pc(b)) * sgn(b, a, e)
                        if coef:
                            rw = [0] * N; rw[a ^ b] = coef; rows.append(rw)
                sol = nullspace_mod(rows, N) if rows else [[int(i == j) for j in range(N)] for i in range(N)]
                support = sorted({c for v in sol for c in range(N) if v[c]})
                want = sorted(c for c in range(N) if c & D == D)            # labels containing every non-null bit
                # lambda(z .) for z in the super-centre Lambda(R^r) = span{e_S : S subset of the null bits}
                lam_z = []
                for S in range(N):
                    if S & D: continue
                    v = [0] * N
                    for c in range(N):                                         # lambda(e_S e_c) = s(S,c) [S xor c = F]
                        if S ^ c == F: v[c] = sgn(S, c, e) % P
                    lam_z.append(v)
                same_space = rank_mod(sol + lam_z) == len(sol) == len(lam_z) == 2 ** r
                # non-degenerate iff z is a unit (non-zero scalar part): generic z with z_0 = 0 is degenerate, with z_0 != 0 is not
                def pairing(coeffs):
                    mu = [0] * N
                    for k, S in enumerate([S for S in range(N) if not S & D]):
                        for c in range(N):
                            if S ^ c == F: mu[c] = (mu[c] + coeffs[k] * sgn(S, c, e)) % P
                    return [[sgn(a, b, e) * mu[a ^ b] for b in range(N)] for a in range(N)]
                cs = [rng.randrange(1, P) for _ in range(2 ** r)]
                unit_ok = rank_mod(pairing(cs)) == N
                cs0 = [0] + cs[1:]
                nonunit_deg = rank_mod(pairing(cs0)) < N
                if support != want or not same_space or not unit_ok or not nonunit_deg: ok = False
                cnt += 1
    row('bd·cat·8', ok,
        f'for every Cl(p,q,r) with n <= 5 ({cnt} signatures) the super-symmetric functionals are exactly lambda(z .) with z in the super-centre '
        'Lambda(R^r) (support: the labels containing every non-null bit; dimension 2^r), and lambda(z .) is non-degenerate iff z is a unit: '
        'the super-symmetric Frobenius forms are a torsor under the units of the super-centre, for every signature (with r = 0: lambda up to a scalar)')

def check22():
    """window (handle) element H = sum_a e_a e_a^v for the top-label form, with the dual basis taken from the pairing itself"""
    from fractions import Fraction as Fr
    ok = True; cnt = 0
    for n in range(1, 6):
        for r in range(0, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); N = 1 << n; F = N - 1
                G = [[Fr(sgn(a, b, e)) if a ^ b == F else Fr(0) for b in range(N)] for a in range(N)]     # lambda(e_a e_b)
                # dual basis e_a^v = sum_b C[a][b] e_b with lambda(e_c e_a^v) = delta_ca  ->  C = (G^T)^{-1} rows; G is a signed permutation
                Cdual = [[Fr(0)] * N for _ in range(N)]
                for a in range(N):                     # lambda(e_c e_b) = G[c][b] is nonzero only for b = c xor F; solve G[c][b] x_b = delta_ca
                    b = a ^ F; Cdual[a][b] = 1 / G[a][b]
                H = {}
                for a in range(N):
                    for b in range(N):
                        if Cdual[a][b]:
                            s_ = sgn(a, b, e)
                            if s_: H[a ^ b] = H.get(a ^ b, Fr(0)) + Cdual[a][b] * s_
                H = {k: v for k, v in H.items() if v}
                top_sq = sgn(F, F, e)
                if H != {F: Fr(N)}: ok = False
                if (top_sq == 0) != (r >= 1): ok = False
                # Lambda(R^r) (p = q = 0): super-commutative, and m o Delta = multiplication by H, nilpotent: not special
                if p + q == 0:
                    if any(sgn(a, b, e) != (-1) ** (pc(a) * pc(b)) * sgn(b, a, e) for a in range(N) for b in range(N)): ok = False
                cnt += 1
    row('bd·cat·22', ok,
        f'for every Cl(p,q,r) with n <= 5 ({cnt} signatures) the window (handle) element of the top-label form, sum_a e_a e_a^dual, is exactly 2^n e_(1...1); '
        'it squares to 0 iff r >= 1: label 0 makes the handle element nilpotent. The exterior algebra Lambda(R^r) is super-commutative, so with lambda it is a '
        'commutative Frobenius monoid in sVec, not special (m o Delta = multiplication by 2^r e_top, nilpotent)')

if __name__ == '__main__':
    check5(); check6(); check7(); check8(); check22()
    verdict()
