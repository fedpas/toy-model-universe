#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""xck_merge.py: cross-checks between the mathematics bridge scripts, computed independently of them.

  python3 selfcheck/bridges/xck_merge.py      one line per check, ids bd·xck·1 .. bd·xck·8; exit 1 on any FAIL

Standard library only, exact integers and rationals (bd·xck·5 uses 2000 integer samples from a fixed seed), deterministic, about 16 s;
runs from any folder, reads and writes no file.
  bd·xck·1  the triple (V, Q, pi) with null generators, by a full isometry test (Q and pi preserved on every label, not only on basis images):
            exactly 5 pairs of non-isomorphic cells with n <= 3 share a triple, Cl(1,0)~Cl(0,0,1), Cl(1,1)~Cl(0,1,1), Cl(1,0,1)~Cl(0,0,2),
            Cl(1,1,1)~Cl(0,1,2), Cl(1,0,2)~Cl(0,0,3). The horizon algebra Cl(0,2,1) shares its triple with neither Cl(1,2) nor Cl(2,1): Q = 1 on 3
            labels against 4 and 2. With null bits Q is not a quadratic form, so a test on basis images alone is not sound.
  bd·xck·2  Cl(0,8): the 30 Lagrangians of the Z_4 form w (bd·cat·13) and the 30 maximal totally singular subspaces of Q that contain 1...1
            (bd·alg·12) are the same 30 subspaces; Q has 270 maximal totally singular subspaces in all.
  bd·xck·3  for every degenerate cell with n <= 6, the sum with weight 0 on the null bits (core·B3) equals the Gauss sum of the mother cell
            Cl(p+r,q+r) and 2^r times the Gauss sum over the labels without a null bit (cat·K4a), the quotient Cl(p,q): the two null-bit sums
            of the package are the sums of the two canonical non-degenerate cells attached to Cl(p,q,r), with one phase (p - q) pi/4.
  bd·xck·4  in the non-degenerate Cl(2,2) the bivector B = (e1 + f1)^(e2 + f2) has B^2 = 0 and the derivation D = x -> x.B has D != 0, D^2 = 0
            (a totally null plane): a null rotation is the only s = 0 kind inside a non-degenerate cell exactly when min(p,q) <= 1 (T17 (b)).
  bd·xck·5  Cl(1,1,1): P = k0^2 - k1^2 has the hyperbolic direction h = e0 (B(k,h)^2 - P(h)P(k) = k1^2 >= 0 on 2000 integer samples) and the null
            covector e2 gives a double root: hyperbolic, not strictly hyperbolic (T18 (f) holds for r = 0).
  bd·xck·6  van der Blij: k = (3; -1^n) is characteristic in I_{1,n} with k.k = 9 - n = 1 - n mod 8, the clock of Cl(1,n) (n = 3..13), and in
            I_{p,q} every characteristic vector c in {+-1, +-3}^n, the top label 1...1 included, has c.c = p - q mod 8, the clock (n <= 7).
  bd·xck·7  the roots of E_8 = k^perp in I_{1,8} orthogonal to e_8, then also to e_7, e_6, e_5, e_4 number 240, 126, 72, 40, 20, 8: the Gosset
            descent of Schuller F15 is the chain E_8 > E_7 > E_6 > D_5 > A_4 > A_2 + A_1 obtained by dropping one frame vector of Cl(1,8) at a time.
  bd·xck·8  Cl(0,8): the 30 Lagrangians of (V, w) are one orbit of S_8 permuting the generators (the orbit of the extended Hamming code, of
            size 8!/1344 = 30): the choice of Furey's axes among them is a choice of frame, the datum is that a Lagrangian exists (clock 0).
"""
import sys, itertools
from fractions import Fraction as F

ROWS = []
def row(i, text, ok):
    ROWS.append((i, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Q(a, e): return 1 if sgn(a, a, e) == -1 else 0
def pi(a): return pc(a) % 2
def w4(a, e): return (pi(a) + 2 * Q(a, e)) % 4
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r

def full_iso(e1, e2):
    """an F_2-linear bijection T with Q(Ta) = Q(a) and pi(Ta) = pi(a) for EVERY a (verified at the leaf)"""
    n = len(e1); V = range(1 << n)
    def lin(imgs, a):
        x = 0
        for j, v in enumerate(imgs):
            if a >> j & 1: x ^= v
        return x
    def rec(i, imgs):
        if i == n:
            span = {lin(imgs, a) for a in V}
            if len(span) != 1 << n: return False
            return all(Q(lin(imgs, a), e2) == Q(a, e1) and pi(lin(imgs, a)) == pi(a) for a in V)
        for v in V:
            if Q(v, e2) != Q(1 << i, e1) or pi(v) != 1: continue
            good = all(Q(lin(imgs + [v], a | (1 << i)), e2) == Q(a | (1 << i), e1) for a in range(1 << i))
            if good and rec(i + 1, imgs + [v]): return True
        return False
    return rec(0, [])

def check1():
    coll = []; counts = {}
    for n in range(1, 4):
        cs = [(p, n - r - p, r) for r in range(n + 1) for p in range(n - r + 1)]
        for x in range(len(cs)):
            for y in range(x + 1, len(cs)):
                (p1, q1, r1), (p2, q2, r2) = cs[x], cs[y]
                if full_iso(sig(p1, q1, r1), sig(p2, q2, r2)) and not (r1 == r2 and (p1 - q1) % 8 == (p2 - q2) % 8):
                    coll.append(f'Cl{cs[x]}~Cl{cs[y]}')
    for cell in ((1, 2, 0), (2, 1, 0), (0, 2, 1)):
        e = sig(*cell); counts[cell] = sum(Q(a, e) for a in range(8))
    spurious = [c for c in ('Cl(1, 2, 0)~Cl(0, 2, 1)', 'Cl(2, 1, 0)~Cl(0, 2, 1)') if c in coll]
    row('bd·xck·1', f'full isometry test of the literal (V,Q,pi) for n <= 3: {len(coll)} collisions: {", ".join(coll)}; the horizon algebra Cl(0,2,1) shares '
        f'its triple with neither Cl(1,2) nor Cl(2,1) (number of labels with Q = 1: {counts}); with null bits Q is not a quadratic form, so a test on basis '
        'images alone is not sound', len(coll) == 5 and not spurious and counts[(1, 2, 0)] == 4 and counts[(0, 2, 1)] == 3 and counts[(2, 1, 0)] == 2)

def max_iso_subspaces(n, e, pred):
    """all subspaces of dimension n/2 on which pred holds, as frozensets (n = 8: backtracking over echelon bases)"""
    cands = [a for a in range(1, 1 << n) if pred(a)]
    out = set()
    def rec(span, basis, start):
        if len(basis) == n // 2:
            out.add(frozenset(span)); return
        for idx in range(start, len(cands)):
            v = cands[idx]
            if v in span: continue
            if all(pred(s ^ v) for s in span):
                rec(span | {s ^ v for s in span}, basis + [v], idx + 1)
    rec({0}, [], 0)
    return out
def check2():
    n = 8; e = sig(0, 8); top = (1 << n) - 1
    Lw = max_iso_subspaces(n, e, lambda a: w4(a, e) == 0)
    LQ = max_iso_subspaces(n, e, lambda a: Q(a, e) == 0)
    LQ_top = {L for L in LQ if top in L}
    row('bd·xck·2', f'Cl(0,8): Lagrangians of the Z_4 form w: {len(Lw)}; maximal totally singular subspaces of Q of dimension 4: {len(LQ)}, of which {len(LQ_top)} '
        f'contain 1...1; the two sets of 30 coincide: {Lw == LQ_top} (bd·cat·13 and bd·alg·12 count the same objects; the 270 of cat·W2 are the ungraded ones)',
        len(Lw) == 30 and len(LQ) == 270 and Lw == LQ_top)

def gsum(exps):
    re = im = 0
    for k in exps:
        z = [(1, 0), (0, 1), (-1, 0), (0, -1)][k % 4]; re += z[0]; im += z[1]
    return (re, im)
def check3():
    ok = True; cells = 0
    for n in range(1, 7):
        for r in range(1, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); N = sum(1 << i for i in range(n) if e[i] == 0)
                P = (1 << p) - 1; Qm = ((1 << q) - 1) << p
                atlas = gsum([(pc(a & P) - pc(a & Qm)) for a in range(1 << n)])                       # core·B3's exponent, weight 0 on null bits
                mother = gsum([w4(a, sig(p + r, q + r)) for a in range(1 << (n + r))])                 # the cell Cl(p+r, q+r), n + r generators
                quotient = gsum([w4(a, e) for a in range(1 << n) if a & N == 0])                       # cat·K4a: the labels of Cl(p,q)
                if atlas != mother or atlas != (quotient[0] << r, quotient[1] << r): ok = False
                cells += 1
    row('bd·xck·3', f'for all {cells} degenerate cells with n <= 6: the sum with weight 0 on the null bits (core·B3) equals the Gauss sum of the mother cell Cl(p+r,q+r) '
        'exactly and 2^r times the Gauss sum of the quotient Cl(p,q) (cat·K4a): the two null-bit sums of the package are the sums of the two canonical non-degenerate cells '
        'attached to Cl(p,q,r), both with phase (p - q) pi/4 (as in bd·cat·4, bd·mat·3, bd·alg·7, bd·geo·5)', ok)

# ---------------------------------------------------------------- multivectors with exact rationals
def mv_mul(A, B, e):
    out = {}
    for a, ca in A.items():
        for b, cb in B.items():
            s = sgn(a, b, e)
            if s: out[a ^ b] = out.get(a ^ b, 0) + ca * cb * s
    return {k: v for k, v in out.items() if v != 0}
def check4():
    e = sig(2, 2)                                  # e1, e2 square +1 (bits 0,1); f1, f2 square -1 (bits 2,3)
    u = {1: F(1), 4: F(1)}; v = {2: F(1), 8: F(1)}   # u = e1 + f1, v = e2 + f2: both null, orthogonal
    uu, vv = mv_mul(u, u, e), mv_mul(v, v, e)
    uv, vu = mv_mul(u, v, e), mv_mul(v, u, e)
    B = {k: F(1, 2) * (uv.get(k, 0) - vu.get(k, 0)) for k in set(uv) | set(vu)}; B = {k: c for k, c in B.items() if c}
    BB = mv_mul(B, B, e)
    # D x = x . B = (x B - B x)/2 on vectors; D^2 on the four basis vectors
    def D(x):
        xB, Bx = mv_mul(x, B, e), mv_mul(B, x, e)
        return {k: c for k, c in {k: F(1, 2) * (xB.get(k, 0) - Bx.get(k, 0)) for k in set(xB) | set(Bx)}.items() if c}
    D1 = [D({1 << i: F(1)}) for i in range(4)]
    D2 = [D(x) for x in D1]
    nonzero = any(D1); square_zero = not any(D2)
    row('bd·xck·4', f'Cl(2,2): u = e1 + f1 and v = e2 + f2 have u^2 = {uu}, v^2 = {vv} (both 0, orthogonal), B = u ^ v has B^2 = {BB} (0), D = x -> x.B is non-zero ({nonzero}) with D^2 = 0 '
        f'({square_zero}): a totally null plane inside a non-degenerate cell, so a null rotation is the only s = 0 kind inside a non-degenerate cell exactly when '
        'min(p,q) <= 1 (T17 (b); as in bd·geo·10; check_T17.py part C lists both kinds for (2,2,0))', not uu and not vv and not BB and nonzero and square_zero)

def check5():
    # P(k) = k0^2 - k1^2 on R^3 (the third generator null): h = e0 hyperbolic iff B(k,h)^2 - P(h)P(k) >= 0 for all k
    import random
    rnd = random.Random(7); ok = True
    for _ in range(2000):
        k = [rnd.randint(-5, 5) for _ in range(3)]
        Bkh = k[0]; Ph = 1; Pk = k[0] ** 2 - k[1] ** 2
        if Bkh ** 2 - Ph * Pk < 0: ok = False
    # not strictly hyperbolic: along h = e0 the polynomial t -> P(k + t h) = (k0 + t)^2 - k1^2 has a double root when k1 = 0, e.g. k = e2 (the null covector)
    k = [0, 0, 1]; roots_double = (k[0] ** 2 - k[1] ** 2 == 0)
    row('bd·xck·5', 'Cl(1,1,1): P = k0^2 - k1^2 has the hyperbolic direction h = e0 (B(k,h)^2 - P(h)P(k) = k1^2 >= 0 on 2000 integer samples), and the null covector k = e2 '
        f'gives a double root ({roots_double}): hyperbolic, not strictly hyperbolic, with one null generator (T18 (f) is the case r = 0; '
        'bd·geo·8 on its smallest case)', ok and roots_double)

def check6():
    ok = True
    for n in range(3, 14):
        G = [(1 if i == 0 else -1) for i in range(n + 1)]
        k = [3] + [-1] * n
        def dot(x, y): return sum(G[i] * x[i] * y[i] for i in range(n + 1))
        if any((dot(k, [int(i == j) for i in range(n + 1)]) - G[j]) % 2 for j in range(n + 1)): ok = False     # characteristic
        kk = dot(k, k)
        if kk != 9 - n or (kk - (1 - n)) % 8: ok = False
    # I_{p,q}: every characteristic c in {+-1, +-3}^n has c.c = p - q mod 8, n <= 7
    for n in range(1, 8):
        for p in range(n + 1):
            q = n - p; eps = sig(p, q)
            for c in itertools.product((1, -1, 3, -3), repeat=n):
                cc = sum(eps[i] * c[i] ** 2 for i in range(n))
                if (cc - (p - q)) % 8: ok = False
            if (sum(eps) - (p - q)) % 8: ok = False                                                            # the top label 1...1 itself
    row('bd·xck·6', 'van der Blij (as in bd·alg·8, bd·cat·15 and bd·mat·17): k = (3; -1^n) is characteristic in I_{1,n} with k.k = 9 - n = 1 - n mod 8 '
        '(the clock of Cl(1,n)), n = 3..13; and in I_{p,q} every characteristic vector c in {+-1,+-3}^n, the top label 1...1 included, has c.c = p - q mod 8 (the clock), n <= 7', ok)

def check7():
    n = 8; G = [1] + [-1] * n
    def dot(x, y): return sum(G[i] * x[i] * y[i] for i in range(n + 1))
    k = [3] + [-1] * n
    roots = []
    def rec(i, x, rem_sq, rem_sum):
        if i == n:
            if rem_sq == 0 and rem_sum == 0: roots.append(list(x))
            return
        bound = int(rem_sq ** 0.5) + 1
        for v in range(-bound, bound + 1):
            if v * v > rem_sq: continue
            left = n - i - 1; rs = rem_sq - v * v
            if (rem_sum - v) ** 2 > left * rs: continue
            rec(i + 1, x + [v], rs, rem_sum - v)
    for x0 in range(-4, 5): rec(0, [x0], x0 * x0 + 2, -3 * x0)       # x.k = 3 x0 + sum x_i = 0, x.x = x0^2 - sum x_i^2 = -2
    counts = [len(roots)]
    cur = roots
    for j in range(n, 3, -1):                                            # drop e_8, e_7, e_6, e_5, e_4
        cur = [x for x in cur if x[j] == 0]
        counts.append(len(cur))
    row('bd·xck·7', f'roots of E_8 in I_(1,8) orthogonal to e_8, e_7, ..., e_4 in turn: {counts} (E_8, E_7, E_6, D_5, A_4, A_2 + A_1): the Gosset descent of Schuller F15 '
        '(240, 126, 72, 40, 20, 8) is the chain of complements of one frame vector of the cell Cl(1,8) at a time, E_(n-1) = E_n meet e_n^perp', counts == [240, 126, 72, 40, 20, 8])

def check8():
    n = 8; e = sig(0, 8)
    Lw = max_iso_subspaces(n, e, lambda a: w4(a, e) == 0)
    # the extended Hamming code of core·B11 (Fano lines + bit 8)
    lines = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
    gens = [sum(1 << (k - 1) for k in L) | (1 << 7) for L in lines]
    H = {0}
    for g in gens: H |= {s ^ g for s in H}
    H = frozenset(H)
    def perm_label(a, p):
        return sum(((a >> i) & 1) << p[i] for i in range(n))
    orbit = set()
    for p in itertools.permutations(range(n)):
        orbit.add(frozenset(perm_label(a, p) for a in H))
    row('bd·xck·8', f'Cl(0,8): the orbit of the extended Hamming code under S_8 (permuting generators) has {len(orbit)} elements and equals the set of {len(Lw)} Lagrangians of w: '
        f'{orbit == Lw}; 8!/|AGL(3,2)| = {40320 // 1344}: the choice of Furey\'s axes among the graded Lagrangians is a choice in one orbit of the frame permutations, '
        'and the datum is the existence of a Lagrangian (clock 0)', H in Lw and orbit == Lw and len(orbit) == 30)

if __name__ == '__main__':
    for f in (check1, check2, check3, check4, check5, check6, check7, check8): f()
    verdict()
