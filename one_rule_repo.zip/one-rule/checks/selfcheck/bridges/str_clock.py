#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""str_clock.py: the clock in worldsheet and K-theory language.

  bd·str·1  Pin-: for n <= 6 the Z_4 refinements of the dot product on F_2^n are exactly the 2^n bit-rule forms w = pi + 2Q of the cells with
            eps in {+1,-1}^n, and the Gauss sum of i^w has modulus 2^(n/2) and phase (p - q) pi/4: (V, w) of Cl(p,q) is
            (H^1(#^n RP^2; Z_2), a Pin- enhancement), and the clock is its Arf-Brown invariant.
  bd·str·2  Atiyah-Bott-Shapiro from the bit rule: for k = 1..10 the cokernel of the restriction of ungraded modules Cl(0,k) -> Cl(0,k-1),
            computed (Smith normal form) from minimal left ideals built with the bit rule (numpy), is Z2 Z2 0 Z 0 0 0 Z Z2 Z2 = KO^{-k}(pt).
  bd·str·3  (info, a read-off of bd·str·2, not a check) the Type I D-brane charge list KO^{-(9-p)}(pt), p = 9..-1, indexed from the groups of
            bd·str·2 (Z for D9, D5, D1; Z2 for D8, D7, D0, D(-1)).
  bd·str·4  (info, symmetric by construction, not a check) with nu boundary Majoranas the brane group KO^{nu} + KO^{-nu} depends only on
            {c, -c}, c = nu mod 8.
  bd·str·5  row 8 (n = 8): the cells whose ungraded algebra is M_16(R) are five (Cl(8,0), Cl(5,3), Cl(4,4), Cl(1,7), Cl(0,8)); the cells with
            clock 0 (one graded algebra) are three.  The type comes from a Frobenius-Schur count over the bit-rule blades (no table).

  python3 str_clock.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; under a second."""
import itertools, sys
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):                               # the bit rule (same as selfcheck/core_check.py)
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q): return [1] * p + [-1] * q

# ---------------------------------------------------------------- bd·str·1  Pin- enhancements = bit-rule w
def check1():
    ok = True; nphase = 0
    for n in range(1, 7):
        # every Z_4 function with w(a^b) = w(a) + w(b) + 2|a&b| is fixed by its values on the basis (each odd); enumerate them all
        found = set()
        for vals in itertools.product((1, 3), repeat=n):
            w = [0] * (1 << n)
            for a in range(1, 1 << n):
                low = a & -a; i = low.bit_length() - 1; rest = a ^ low
                w[a] = (w[rest] + vals[i] + 2 * pc(rest & low)) % 4
            if any((w[a ^ b] - w[a] - w[b] - 2 * pc(a & b)) % 4 for a in range(1 << n) for b in range(1 << n)): ok = False
            found.add(tuple(w))
        bit = set()
        for eps in itertools.product((1, -1), repeat=n):
            e = list(eps)
            wb = tuple((pc(a) % 2 + 2 * (1 if sgn(a, a, e) == -1 else 0)) % 4 for a in range(1 << n))
            bit.add(wb)
            p, q = e.count(1), e.count(-1)
            S = sum(1j ** x for x in wb)
            ph = (np.angle(S) / (2 * np.pi) * 8) % 8
            if abs(abs(S) - 2 ** (n / 2)) > 1e-9 or round(ph) % 8 != (p - q) % 8: ok = False
            nphase += 1
        if found != bit or len(found) != 2 ** n: ok = False
    row('bd·str·1', ok, f'for n <= 6 the Z_4 refinements w of the dot product on F_2^n (w(a+b) = w(a) + w(b) + 2 a.b) are exactly the 2^n forms w = pi + 2Q of the cells with eps in {+1,-1}^n (a torsor over F_2^n, as Pin- structures on #^n RP^2 are over H^1); the Gauss sum of i^w has modulus 2^(n/2) and phase (p - q) pi/4 in all {nphase} cases: the clock is the Arf-Brown invariant of that Pin- surface')

# ---------------------------------------------------------------- module machinery for Cl(0,k): minimal left ideals from a Lagrangian
def left_op(g, eps):
    """left multiplication by the blade g as (perm, sign) on labels"""
    N = 1 << len(eps); perm = np.array([a ^ g for a in range(N)]); s = np.array([sgn(g, a, eps) for a in range(N)], float)
    return perm, s
def apply(op, X):                                  # X: N x m (columns are elements)
    perm, s = op; Y = np.zeros_like(X); Y[perm] = s[:, None] * X; return Y
def mul(x, y, eps):                                # product of two elements given as dense vectors
    N = len(x); out = np.zeros(N)
    for a in np.nonzero(x)[0]:
        for b in np.nonzero(y)[0]:
            out[a ^ b] += x[a] * y[b] * sgn(int(a), int(b), eps)
    return out
def max_singular(eps, labels):
    """greedy maximal set of independent, mutually commuting blades with square +1 among the given labels"""
    chosen, span = [], {0}
    for a in labels:
        if a in span or sgn(a, a, eps) != 1: continue
        if any(sgn(a, b, eps) != sgn(b, a, eps) for b in chosen): continue
        chosen.append(a); span |= {x ^ a for x in span}
    return chosen
def idempotent(eps, chosen, signs):
    N = 1 << len(eps); f = np.zeros(N); f[0] = 1.0
    for a, s in zip(chosen, signs):
        g = np.zeros(N); g[0] = 0.5; g[a] = 0.5 * s
        f = mul(f, g, eps)
    return f
def left_ideal(eps, f):
    """orthonormal basis of Cl.f: columns e_a f for every label a"""
    N = 1 << len(eps); cols = np.zeros((N, N))
    nz = np.nonzero(f)[0]
    for a in range(N):
        for b in nz: cols[a ^ b, a] += f[b] * sgn(a, int(b), eps)
    U, S, Vt = np.linalg.svd(cols, full_matrices=False)
    r = int((S > 1e-8 * S[0]).sum()); return U[:, :r]
from functools import lru_cache
@lru_cache(maxsize=None)
def irreps(k):
    """the irreducible modules of Cl(0,k): list of (basis, eps); one per isomorphism class (1 or 2 classes)"""
    eps = [-1] * k
    if k == 0: return [np.ones((1, 1))], eps
    chosen = max_singular(eps, list(range(1, 1 << k)))
    mods, seen = [], set()
    top = (1 << k) - 1
    central = all(sgn(top, 1 << i, eps) == sgn(1 << i, top, eps) for i in range(k)) and sgn(top, top, eps) == 1
    for signs in itertools.product((1, -1), repeat=len(chosen)):
        f = idempotent(eps, chosen, signs)
        if np.allclose(f, 0): continue
        B = left_ideal(eps, f)
        key = 0
        if central:                                   # the class is fixed by the sign of the central top blade
            tr = np.trace(B.T @ apply(left_op(top, eps), B)); key = int(np.sign(round(tr)))
        if key in seen: continue
        seen.add(key); mods.append((key, B))
        if len(mods) == (2 if central else 1): break
    mods.sort(key=lambda t: -t[0])
    return [B for _, B in mods], eps
def restriction_vector(B, k):
    """multiplicities of the irreducibles of Cl(0,k-1) in the restriction of the Cl(0,k)-module with basis B (generators e_0..e_{k-2})"""
    sub = irreps(k - 1)[0]; d_sub = sub[0].shape[0] if k - 1 > 0 else 1
    if k - 1 == 0: return [B.shape[1]]
    if len(sub) == 1: return [B.shape[1] // sub[0].shape[1]]
    top = (1 << (k - 1)) - 1; eps = [-1] * k
    tr = np.trace(B.T @ apply(left_op(top, eps), B)); d = B.shape[1]; ds = sub[0].shape[1]
    return [int(round((d + tr) / (2 * ds))), int(round((d - tr) / (2 * ds)))]
def snf_coker(rows, ncols):
    """cokernel of Z^r -> Z^c given by integer row vectors: returns sorted list of invariant factors (0 = free Z)"""
    M = [list(r) for r in rows]
    if not M: return [0] * ncols
    R, C = len(M), ncols; d = []; t = 0
    while t < min(R, C):
        piv = None
        for i in range(t, R):
            for j in range(t, C):
                if M[i][j] and (piv is None or abs(M[i][j]) < abs(M[piv[0]][piv[1]])): piv = (i, j)
        if piv is None: break
        i, j = piv; M[t], M[i] = M[i], M[t]
        for r_ in M: r_[t], r_[j] = r_[j], r_[t]
        while True:
            ch = False
            for i in range(t + 1, R):
                if M[i][t]:
                    q = M[i][t] // M[t][t]; M[i] = [x - q * y for x, y in zip(M[i], M[t])]
                    if M[i][t]: M[t], M[i] = M[i], M[t]; ch = True
            for j in range(t + 1, C):
                if M[t][j]:
                    q = M[t][j] // M[t][t]
                    for r_ in M: r_[j] -= q * r_[t]
                    if M[t][j]:
                        for r_ in M: r_[t], r_[j] = r_[j], r_[t]
                        ch = True
            if not ch: break
        d.append(abs(M[t][t])); t += 1
    return sorted([x for x in d if x != 1] + [0] * (C - len(d)))
def name(inv):
    if inv == []: return '0'
    return ' + '.join('Z' if x == 0 else f'Z{x}' for x in inv)

KO_WANT = {1: 'Z2', 2: 'Z2', 3: '0', 4: 'Z', 5: '0', 6: '0', 7: '0', 8: 'Z', 9: 'Z2', 10: 'Z2'}
KO = {0: 'Z'}
def check2():
    ok = True; table = []
    for k in range(1, 11):
        mods, eps = irreps(k)
        vecs = [restriction_vector(B, k) for B in mods]
        ncols = len(irreps(k - 1)[0]) if k - 1 > 0 else 1
        coker = name(snf_coker(vecs, ncols))
        KO[k] = coker; table.append(f'{k}:{coker}')
        if coker != KO_WANT[k]: ok = False
    row('bd·str·2', ok, 'Atiyah-Bott-Shapiro from the bit rule: coker(ungraded modules of Cl(0,k) -> of Cl(0,k-1)) for k = 1..10 is ' + ', '.join(table) + ' = KO^{-k}(pt) (pi_{k-1}(O): Z2 Z2 0 Z 0 0 0 Z, period 8); every module is a minimal left ideal Cl.f, f from a maximal set of commuting blades of square +1')
def check3():
    want = {9: 'Z', 8: 'Z2', 7: 'Z2', 6: '0', 5: 'Z', 4: '0', 3: '0', 2: '0', 1: 'Z', 0: 'Z2', -1: 'Z2'}
    got = {p: KO[9 - p] for p in range(9, -2, -1)}
    info('bd·str·3', 'the Type I Dp-brane charge groups KO^{-(9-p)}(pt) indexed from bd·str·2: ' + ', '.join(f'D{p}:{got[p]}' for p in range(9, -2, -1)) + f' (Z for D9, D5, D1; Z2 for the non-BPS D8, D7, D0, D(-1); equal to that list: {got == want})')
def check4():
    ko = lambda k: KO[k % 8 if k % 8 else 8] if k % 8 else 'Z'
    pairs = {c: tuple(sorted((ko(c), ko(-c)))) for c in range(8)}
    ok = all(pairs[c] == pairs[(-c) % 8] for c in range(8))
    info('bd·str·4', 'with nu Kitaev chains (nu boundary Majoranas = nu Clifford generators) the brane group KO^{nu} + KO^{-nu}, as a function of the clock c = nu mod 8, is ' + ', '.join(f'{c}:{pairs[c][0]}+{pairs[c][1]}' for c in range(8)) + f': the same for c and -c ({ok}; symmetric by construction)')

# ---------------------------------------------------------------- bd·str·5  GEN-009: row 8, graded against ungraded
def fs_type(eps):
    """ungraded type of the bit-rule algebra from its centre and the Frobenius-Schur count nu = sum of the squares of the blades"""
    n = len(eps); N = 1 << n; top = N - 1
    nu = sum(sgn(a, a, eps) for a in range(N))
    central = n % 2 == 1                          # the top blade is central for odd n (core·B14)
    k = 2 if central and sgn(top, top, eps) == 1 else 1
    if nu > 0: D = 'R'
    elif nu == 0: D = 'C'
    else: D = 'H'
    dimD = {'R': 1, 'C': 2, 'H': 4}[D]
    if central and sgn(top, top, eps) == -1: D, dimD = 'C', 2
    Nm = int(round((N / (k * dimD)) ** 0.5))
    return (k, D, Nm)
def check5():
    m16 = []; clock0 = []
    for p in range(9):
        q = 8 - p; t = fs_type(sig(p, q))
        if t == (1, 'R', 16): m16.append(f'Cl({p},{q})')
        if (p - q) % 8 == 0: clock0.append(f'Cl({p},{q})')
    ok = m16 == ['Cl(1,7)', 'Cl(4,4)', 'Cl(5,3)', 'Cl(0,8)', 'Cl(8,0)'] or sorted(m16) == sorted(['Cl(0,8)', 'Cl(1,7)', 'Cl(4,4)', 'Cl(5,3)', 'Cl(8,0)'])
    ok = ok and sorted(clock0) == sorted(['Cl(0,8)', 'Cl(4,4)', 'Cl(8,0)'])
    top = (1 << 8) - 1
    wsq = sorted(f'Cl({p},{8 - p})' for p in range(9) if sgn(top, top, sig(p, 8 - p)) == 1)
    ok = ok and wsq == sorted(['Cl(8,0)', 'Cl(6,2)', 'Cl(4,4)', 'Cl(2,6)', 'Cl(0,8)'])
    row('bd·str·5', ok, f'row 8 (n = 8): the cells whose ungraded algebra is M16(R) are {sorted(m16)} (five; Frobenius-Schur count over the 256 blades), the cells with clock 0 (one graded algebra, core·B6c) are {sorted(clock0)} (three), the cells whose volume element squares to +1 are {wsq} (five, q even): three cells of row 8 share the graded algebra, five share the ungraded one')

if __name__ == '__main__':
    check1(); check2(); check3(); check4(); check5()
    finish()
