#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""phy_cell_vs_signature.py: the frame-free cell (V, Q, pi) against the number of time directions.

Two cells with the same n and the same clock p - q mod 8 have isomorphic triples (V, Q, pi) (core·B6c).  The wave operator of Cl(p,q) is
hyperbolic exactly when min(p,q) = 1 (T18 (f)).  For n = 5, 7, 8 the script builds an explicit isometry of triples between a Lorentzian
cell and a non-Lorentzian one (same n, same clock) and applies the hyperbolicity test of T18 (f) to both.

  bd·phy·1   Cl(5,0) -> Cl(1,4): five odd blades of Cl(1,4), mutually anticommuting, of square +1; their 32 products are single blades up to
             sign, and the label map is a bijection of F_2^5 that is additive and keeps the parity and the square sign: the triples are isomorphic.
  bd·phy·2a  the same for Cl(5,2) -> Cl(1,6) (n = 7, clock 3).
  bd·phy·2b  the same for Cl(5,3) -> Cl(1,7) (n = 8, clock 2).
  bd·phy·3   hyperbolicity (T18 (f)): the form q_h(k) = B(k,h)^2 - P(h)P(k) is positive semidefinite for a generator direction h of the
             Lorentzian member of each pair, and for no generator direction and none of 200 random directions h (seed 1) of the other member.
  bd·phy·4   the label map of bd·phy·1 sends the generators of Cl(5,0) to blades of grades 1, 3, 3, 3, 3 of Cl(1,4): which labels are generators
             is data beyond the triple; the vector eps of squares carries min(p,q), the number of time directions.
  bd·phy·20  for n = 2..12: the classes (n, clock) that hold both a Lorentzian and a non-Lorentzian cell: none for n = 2, 3, 4, 6, and every
             Lorentzian class for the other n.

  python3 phy_cell_vs_signature.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; about a second."""
import sys
import itertools
import numpy as np

def popcount(x):
    return bin(x).count('1')

def reorder_sign(a, b):
    s = 0
    a2 = a >> 1
    while a2:
        s += popcount(a2 & b)
        a2 >>= 1
    return -1 if s & 1 else 1

def sign(a, b, eps):
    s = reorder_sign(a, b)
    c = a & b
    i = 0
    while c:
        if c & 1:
            s *= eps[i]
            if s == 0:
                return 0
        c >>= 1
        i += 1
    return s

class Alg:
    def __init__(self, eps):
        self.eps = list(eps); self.n = len(eps); self.N = 1 << self.n
        self.S = np.zeros((self.N, self.N), dtype=np.int64)
        for a in range(self.N):
            for b in range(self.N):
                self.S[a, b] = sign(a, b, self.eps)
    def mul(self, x, y):
        z = np.zeros(self.N, dtype=np.result_type(x, y))
        for a in np.nonzero(x)[0]:
            for b in np.nonzero(y)[0]:
                s = self.S[a, b]
                if s:
                    z[a ^ b] += s * x[a] * y[b]
        return z
    def blade(self, a, c=1):
        v = np.zeros(self.N, dtype=np.int64); v[a] = c; return v
    def square_sign(self, a):
        return int(self.S[a, a])

ROWS, FAILS = [], []
def report(cid, ok, text):
    ROWS.append(cid)
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    if not ok:
        FAILS.append(cid)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def graded_embedding(src_eps, tgt_eps, images):
    """images: list of target labels (one per source generator), all odd, square +1 (if src eps = +1) etc.
    Returns (ok, labelmap) where labelmap[a] = target label of the product of the images along a."""
    A = Alg(tgt_eps); n = len(src_eps)
    # the images must square to src_eps[i] and anticommute pairwise, and be odd
    for i, im in enumerate(images):
        if popcount(im) % 2 == 0:
            return False, None, 'image not odd'
        if A.square_sign(im) != src_eps[i]:
            return False, None, 'wrong square'
    for i in range(n):
        for j in range(i + 1, n):
            a, b = images[i], images[j]
            if A.S[a, b] != -A.S[b, a]:
                return False, None, 'images do not anticommute'
    labelmap = {}
    for a in range(1 << n):
        v = A.blade(0)
        for i in range(n):
            if a >> i & 1:
                v = A.mul(v, A.blade(images[i]))
        nz = np.nonzero(v)[0]
        if len(nz) != 1 or abs(v[nz[0]]) != 1:
            return False, None, 'product not a single blade'
        labelmap[a] = int(nz[0])
    return True, labelmap, ''

def check_isometry(src_eps, tgt_eps, images, cid, name):
    ok, lm, why = graded_embedding(src_eps, tgt_eps, images)
    if not ok:
        report(cid, False, name + ': ' + why); return
    S = Alg(src_eps); T = Alg(tgt_eps)
    bij = len(set(lm.values())) == (1 << len(src_eps))
    parity = all(popcount(a) % 2 == popcount(lm[a]) % 2 for a in lm)
    qform = all(S.square_sign(a) == T.square_sign(lm[a]) for a in lm)
    # the pairing: the label map must be additive (XOR -> XOR) for it to be a map of (V, Q, pi)
    additive = all(lm[a ^ b] == lm[a] ^ lm[b] for a in lm for b in lm)
    report(cid, bij and parity and qform and additive,
           name + ': the products of the image blades %s are single blades up to sign; the label map is bijective (%s), keeps the parity (%s), keeps Q, the square sign (%s), and is additive on XOR (%s)' %
           ([bin(i) for i in images], bij, parity, qform, additive))
    return lm

def hyperbolic_directions(eps, trials=200, seed=1):
    """T18 (f) criterion: h is hyperbolic for P(k) = sum eps_i k_i^2 iff q_h(k) = B(k,h)^2 - P(h)P(k) is positive semidefinite.
    Returns (found_for_generator_h, found_in_random_search)."""
    n = len(eps); E = np.diag(eps).astype(float)
    def psd_for(h):
        Ph = h @ E @ h
        M = np.outer(E @ h, E @ h) - Ph * E   # q_h(k) = k^T M k
        w = np.linalg.eigvalsh((M + M.T) / 2)
        return w.min() > -1e-9 and w.max() > 1e-9
    gens = [psd_for(np.eye(n)[i]) for i in range(n)]
    rng = np.random.default_rng(seed)
    rand = any(psd_for(rng.normal(size=n)) for _ in range(trials))
    return any(gens), rand

def main():
    # n = 5: Cl(5,0) (elliptic, clock 5) and Cl(1,4) (Lorentzian, clock -3 = 5)
    e0, e1, e2, e3, e4 = 1, 2, 4, 8, 16
    lm5 = check_isometry([1] * 5, [1, -1, -1, -1, -1], [e0, e1 | e2 | e3, e1 | e2 | e4, e1 | e3 | e4, e2 | e3 | e4],
                         'bd·phy·1', 'Cl(5,0) -> Cl(1,4) as (V,Q,pi)')
    # n = 7: Cl(5,2) (ultrahyperbolic, clock 3) -> Cl(1,6) (Lorentzian, clock -5 = 3): the same images for the first five generators; the
    # two negative generators of Cl(5,2) go to e5, e6 (square -1), which anticommute with e0 and with every grade-3 blade that does not contain them
    e5, e6 = 32, 64
    lm7 = check_isometry([1] * 5 + [-1] * 2, [1] + [-1] * 6,
                         [e0, e1 | e2 | e3, e1 | e2 | e4, e1 | e3 | e4, e2 | e3 | e4, e5, e6],
                         'bd·phy·2a', 'Cl(5,2) -> Cl(1,6) as (V,Q,pi)')
    e7 = 128
    lm8 = check_isometry([1] * 5 + [-1] * 3, [1] + [-1] * 7,
                         [e0, e1 | e2 | e3, e1 | e2 | e4, e1 | e3 | e4, e2 | e3 | e4, e5, e6, e7],
                         'bd·phy·2b', 'Cl(5,3) -> Cl(1,7) as (V,Q,pi)')
    # bd·phy·3: hyperbolicity differs inside each pair
    pairs = [((1, 4), (5, 0)), ((1, 6), (5, 2)), ((1, 7), (5, 3))]
    allok = True; txt = []
    for (p1, q1), (p2, q2) in pairs:
        h1 = hyperbolic_directions([1] * p1 + [-1] * q1)
        h2 = hyperbolic_directions([1] * p2 + [-1] * q2)
        okpair = h1[0] and not h2[0] and not h2[1]
        allok &= okpair
        txt.append('Cl(%d,%d) hyperbolic %s/%s, Cl(%d,%d) %s/%s' % (p1, q1, h1[0], h1[1], p2, q2, h2[0], h2[1]))
    report('bd·phy·3', allok, 'the hyperbolicity test of T18 (f) on each pair with the same (n, clock) and isomorphic triples (a generator direction h / 200 random h): ' + '; '.join(txt) +
           '; the triple (V,Q,pi) does not see hyperbolicity, min(p,q) of the vector eps does')
    # bd·phy·4: the generators of Cl(5,0) land on grade-3 blades of Cl(1,4): the real form (eps) is not a function of the triple
    if lm5:
        grades = sorted(popcount(lm5[1 << i]) for i in range(5))
        report('bd·phy·4', grades == [1, 3, 3, 3, 3],
               'the images of the five generators of Cl(5,0) in Cl(1,4) have grades %s: which labels are generators is data beyond the triple; '
               'the vector eps carries min(p,q), the number of time directions, and the triple does not' % grades)
    else:
        report('bd·phy·4', False, 'no label map')
    # bd·phy·20: for which n does the class (n, p - q mod 8) contain both a Lorentzian and a non-Lorentzian cell?
    rows = []
    okn = True
    for n in range(2, 13):
        classes = {}
        for p in range(n + 1):
            classes.setdefault((p - (n - p)) % 8, []).append((p, n - p))
        mixed = [c for c, cells in classes.items() if any(min(pq) == 1 for pq in cells) and any(min(pq) != 1 for pq in cells)]
        lor_classes = [c for c, cells in classes.items() if any(min(pq) == 1 for pq in cells)]
        rows.append('n=%d: %d Lorentzian classes, %d of them mixed' % (n, len(lor_classes), len(mixed)))
        okn &= (len(mixed) == 0) if n in (2, 3, 4, 6) else (len(mixed) == len(lor_classes))
    report('bd·phy·20', okn, 'classes (n, clock) that hold both a Lorentzian and a non-Lorentzian cell, n = 2..12: ' + '; '.join(rows) +
           '; for n <= 12 the frame-free triple fixes hyperbolicity exactly for n = 2, 3, 4, 6 (the partner (5, n-5) of (1, n-1) needs n >= 5, and at n = 6 it is the Lorentzian (5,1) itself)')
    finish()

if __name__ == '__main__':
    main()
