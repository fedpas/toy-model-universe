#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mjc_comma.py: the levels of comma-propagation, C_1 = C and C_{n+1} = C_n ↓ C_n (the arrow category; arXiv:2406.16884, eq. (2), the
reference [14] of arXiv:2403.19689 (v3)), counted for small C and compared with the label cubes B_n of the Atlas.

    python3 selfcheck/bridges/mjc_comma.py              one line per check, ids bd·mjc·30 .. bd·mjc·32; exit 1 on any FAIL
    python3 selfcheck/bridges/mjc_comma.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only; deterministic, about 2 s; runs from any folder, reads and writes no file.  The arrow category Arr(C): objects the
arrows f of C, arrows f -> g the pairs (h, k) with k o f = g o h, composed componentwise.
  bd·mjc·30  the iterated arrow categories, built explicitly (identities, composition, associativity checked on every composable triple of
             every level built), have as objects and arrows exactly the functors B_k -> C and B_(k+1) -> C counted independently (backtracking over
             the edge labellings of the k-cube with every square commuting): C_(k+1) = Fun(B_k, C), the k-th level is the category of commutative
             k-cubes in C (the exponential law), for C = 1, 2 = B_1, the Kronecker category, Z_2 (levels C_1..C_4, cubes k = 0..4) and B_2,
             {1, e} (levels C_1..C_3, cubes k = 0..3).
  bd·mjc·31  C = 2: levels C_1..C_5 have (objects, arrows) (2, 3), (3, 6), (6, 20), (20, 168), (168, 7581): the numbers of monotone maps B_k -> 2,
             i.e. of up-sets of B_k (the opens of bd·mjc·25), recounted independently from pairs of up-sets U subset V of B_(k-1); C = 1: every level
             is (1, 1) (the hierarchy over the one-object category is constant up to isomorphism); C = B_2: (4, 9), (9, 36), (36, 400),
             (400, 28224) = squares of the numbers for 2: the Atlas's doubling B_(m+1) = B_m x B_1 commutes with every level
             (Arr(C x D) = Arr(C) x Arr(D), checked as counts for C = D = 2 and C = 2, D = B_2).
  bd·mjc·32  against the Atlas's counts on B_m: the k-th level has M(k)^m objects (M = 2, 3, 6, 20, 168): equal to 2^m and 3^m for k = 0, 1 only;
             4^m and (j+2)^m are the simplices Fun([j], B_m) of the nerve (chains), not cubes; |Fun([j], B_m)| = (j+2)^m and
             |Fun(B_k, B_m)| = M(k)^m computed for m <= 3, j, k <= 3; the first departure is k = j = 2 (the square B_2 against the chain [2]).
"""
import sys, itertools

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if not SABOTAGE: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    else: print('  sabotaged input, what the check sees: ' + text)
    return bool(ok)

def sub(a, b): return (a & b) == a
class Cat:
    def __init__(self, m, dom, cod, ident, comp):
        self.m, self.dom, self.cod, self.ident, self.comp = m, dom, cod, ident, comp
        self.A = len(dom)
        self.hom = {}
        for f in range(self.A): self.hom.setdefault((dom[f], cod[f]), []).append(f)
    def H(self, x, y): return self.hom.get((x, y), [])
    def c(self, f, g): return self.comp[(f, g)]
def build(m, arrows, table):
    names = list(arrows); k = len(names); idx = {x: i for i, x in enumerate(names)}
    dom = [arrows[x][0] for x in names] + list(range(m)); cod = [arrows[x][1] for x in names] + list(range(m))
    ident = [k + o for o in range(m)]; comp = {}
    for f in range(k + m):
        for g in range(k + m):
            if cod[f] != dom[g]: continue
            if f >= k: comp[(f, g)] = g
            elif g >= k: comp[(f, g)] = f
            else:
                v = table[(names[f], names[g])]; comp[(f, g)] = (k + dom[f]) if v == '1' else idx[v]
    return Cat(m, dom, cod, ident, comp)
def boolean_lattice(n):
    L = range(1 << n); arrows = [(s, t) for s in L for t in L if sub(s, t)]; index = {x: i for i, x in enumerate(arrows)}
    comp = {(i, j): index[(arrows[i][0], arrows[j][1])] for i in range(len(arrows)) for j in range(len(arrows)) if arrows[i][1] == arrows[j][0]}
    return Cat(1 << n, [x[0] for x in arrows], [x[1] for x in arrows], [index[(s, s)] for s in L], comp)
def group_Z2():
    return Cat(1, [0, 0], [0, 0], [0], {(0, 0): 0, (0, 1): 1, (1, 0): 1, (1, 1): 0})

def arrow_category(C, with_comp=True, sab=False):
    """Arr(C); returns the category (or only the number of arrows when with_comp is False)"""
    objs = list(range(C.A))
    arr = []
    for f in objs:
        for g in objs:
            for h in C.H(C.dom[f], C.dom[g]):
                for k in C.H(C.cod[f], C.cod[g]):
                    if sab or C.c(f, k) == C.c(h, g): arr.append((f, g, h, k))   # k o f = g o h  (sabotage: no commutativity asked)
    if not with_comp: return len(objs), len(arr)
    index = {a: i for i, a in enumerate(arr)}
    dom = [a[0] for a in arr]; cod = [a[1] for a in arr]
    ident = [index[(f, f, C.ident[C.dom[f]], C.ident[C.cod[f]])] for f in objs]
    comp = {}
    by_dom = {}
    for i, a in enumerate(arr): by_dom.setdefault(a[0], []).append(i)
    for i, (f, g, h, k) in enumerate(arr):
        for j in by_dom.get(g, []):
            (_, l, h2, k2) = arr[j]
            key = (f, l, C.c(h, h2), C.c(k, k2))
            comp[(i, j)] = index.get(key, -1)
    return Cat(len(objs), dom, cod, ident, comp)
def is_category(C):
    if any(v < 0 for v in C.comp.values()): return False
    by_dom = {}
    for (f, g) in C.comp: by_dom.setdefault(f, []).append(g)
    for (f, g), fg in C.comp.items():
        for h in by_dom.get(g, []):
            if C.c(fg, h) != C.c(f, C.c(g, h)): return False
    return all(C.c(C.ident[C.dom[f]], f) == f and C.c(f, C.ident[C.cod[f]]) == f for f in range(C.A))

def functors_from_cube(C, k):
    """number of functors B_k -> C: object labels for the 2^k vertices, arrows for the k 2^(k-1) edges, every square commuting"""
    N = 1 << k
    edges = [(S, i) for S in range(N) for i in range(k) if not (S >> i & 1)]
    squares = [(S, i, j) for S in range(N) for i in range(k) for j in range(i + 1, k) if not (S >> i & 1) and not (S >> j & 1)]
    count = 0
    for ob in itertools.product(range(C.m), repeat=N):
        choice = [C.H(ob[S], ob[S | (1 << i)]) for (S, i) in edges]
        if any(len(c) == 0 for c in choice): continue
        eidx = {e: t for t, e in enumerate(edges)}
        assign = {}
        sq_by_edge = {}
        for (S, i, j) in squares:
            last = max(eidx[(S, i)], eidx[(S | (1 << i), j)], eidx[(S, j)], eidx[(S | (1 << j), i)])
            sq_by_edge.setdefault(last, []).append((S, i, j))
        def rec(t):
            nonlocal count
            if t == len(edges): count += 1; return
            for a in choice[t]:
                assign[edges[t]] = a
                good = True
                for (S, i, j) in sq_by_edge.get(t, []):
                    if C.c(assign[(S, i)], assign[(S | (1 << i), j)]) != C.c(assign[(S, j)], assign[(S | (1 << j), i)]): good = False; break
                if good: rec(t + 1)
            del assign[edges[t]]
        rec(0)
    return count

def bases():
    return {'1': build(1, {}, {}), '2': boolean_lattice(1), 'B_2': boolean_lattice(2),
            'Kronecker': build(2, {'f': (0, 1), 'g': (0, 1)}, {}), 'Z2': group_Z2(), '{1,e}': build(1, {'e': (0, 0)}, {('e', 'e'): 'e'})}

def levels(C, depth, sab=False):
    """[(objects, arrows)] of C_1 .. C_depth (C_1 = C); the last level counted without composition; associativity checked on each level built"""
    out = [(C.m, C.A)]; cat_ok = is_category(C); X = C
    for lev in range(2, depth + 1):
        if lev < depth:
            X = arrow_category(X, sab=sab and lev == 2); cat_ok &= is_category(X); out.append((X.m, X.A))
        else:
            out.append(arrow_category(X, with_comp=False, sab=sab and lev == 2))
    return out, cat_ok

# ================================================================== bd·mjc·30  levels = functor categories from the label cubes
def check30(sab=False):
    ok = True; rows = []
    depth = {'1': 4, '2': 4, 'B_2': 3, 'Kronecker': 4, 'Z2': 4, '{1,e}': 3}
    for name, C in bases().items():
        lv, cat_ok = levels(C, depth[name], sab)
        fun = [functors_from_cube(C, k) for k in range(0, depth[name] + 1)]
        match = all(lv[k][0] == fun[k] and lv[k][1] == fun[k + 1] for k in range(depth[name]))
        if not (cat_ok and match): ok = False
        rows.append(f'{name}: levels {lv}, |Fun(B_k, C)| k = 0..{depth[name]}: {fun}')
    return report('bd·mjc·30', ok, 'C_(k+1) = Fun(B_k, C) (objects = functors from the k-cube, arrows = functors from the (k+1)-cube), every level built is a category: ' + '; '.join(rows))

# ================================================================== bd·mjc·31  C = 2: Dedekind numbers; C = 1 constant; doubling commutes with the levels
def upsets(n):
    N = 1 << n; near = [sum(1 << b for b in range(N) if sub(a, b)) for a in range(N)]; out = []
    for X in range(1 << N):
        Y = X; good = True
        while Y:
            a = (Y & -Y).bit_length() - 1; Y &= Y - 1
            if near[a] & ~X: good = False; break
        if good: out.append(X)
    return out
def product_cat(C, D):
    arr = [(f, g) for f in range(C.A) for g in range(D.A)]; index = {a: i for i, a in enumerate(arr)}
    dom = [C.dom[f] * D.m + D.dom[g] for (f, g) in arr]; cod = [C.cod[f] * D.m + D.cod[g] for (f, g) in arr]
    ident = [index[(C.ident[x], D.ident[y])] for x in range(C.m) for y in range(D.m)]
    comp = {(i, j): index[(C.c(arr[i][0], arr[j][0]), D.c(arr[i][1], arr[j][1]))] for i in range(len(arr)) for j in range(len(arr))
            if (arr[i][0], arr[j][0]) in C.comp and (arr[i][1], arr[j][1]) in D.comp}
    return Cat(C.m * D.m, dom, cod, ident, comp)
def check31(sab=False):
    two = boolean_lattice(1)
    lv2, ok2 = levels(two, 5)
    M = [len(upsets(k)) for k in range(0, 5)]                          # monotone maps B_k -> 2 = up-sets of B_k
    U4 = upsets(4); M5 = sum(1 for U in U4 for V in U4 if sub(U, V))      # monotone maps B_5 = B_4 x 2 -> 2 = pairs U subset V of up-sets of B_4
    M.append(M5)
    if sab: M[3] += 1                                                  # sabotage: one up-set of B_3 too many
    lv1, ok1 = levels(bases()['1'], 5)
    lvB2, okB = levels(boolean_lattice(2), 4)
    # products: Arr(C x D) against Arr(C) x Arr(D), counts and an explicit bijection on objects and arrows
    prod_ok = True
    for (C, D) in ((two, two), (two, boolean_lattice(2))):
        A1 = arrow_category(product_cat(C, D)); A2 = product_cat(arrow_category(C), arrow_category(D))
        prod_ok &= (A1.m, A1.A) == (A2.m, A2.A)
    ok = ok2 and ok1 and okB and prod_ok and [x[0] for x in lv2] == M[:5] and [x[1] for x in lv2] == M[1:6] and all(x == (1, 1) for x in lv1) \
         and lvB2 == [(M[k] ** 2, M[k + 1] ** 2) for k in range(4)]
    return report('bd·mjc·31', ok, f'C = 2: levels C_1..C_5 {lv2}; monotone maps B_k -> 2 (up-sets of B_k) {M[:5]}, and from pairs of up-sets of B_4: {M5}; C = 1: {lv1}; C = B_2: {lvB2} = squares; Arr(C x D) and Arr(C) x Arr(D) have equal counts for (2, 2), (2, B_2): {prod_ok}')

# ================================================================== bd·mjc·32  against 2^m, 3^m, 4^m: cubes against simplices
def chain(j):
    """the chain [j] = {0 < 1 < ... < j} as a category"""
    arrows = [(a, b) for a in range(j + 1) for b in range(j + 1) if a <= b]; index = {x: i for i, x in enumerate(arrows)}
    comp = {(i, k): index[(arrows[i][0], arrows[k][1])] for i in range(len(arrows)) for k in range(len(arrows)) if arrows[i][1] == arrows[k][0]}
    return Cat(j + 1, [x[0] for x in arrows], [x[1] for x in arrows], [index[(a, a)] for a in range(j + 1)], comp)
def monotone_count(P_leq, Q_leq, p, q):
    """number of order-preserving maps from ({0..p-1}, P_leq) to ({0..q-1}, Q_leq); backtracking in the order 0..p-1, which must be a
    linear extension of P_leq (true for the chains and, ordered by the integer value of the labels, for B_k)"""
    below = [[y for y in range(x) if P_leq(y, x)] for x in range(p)]
    f = [0] * p
    def rec(x):
        if x == p: return 1
        tot = 0
        for v in range(q):
            if all(Q_leq(f[y], v) for y in below[x]):
                f[x] = v; tot += rec(x + 1)
        return tot
    return rec(0)
def check32(sab=False):
    ok = True; rows = []
    Mk = [2, 3, 6, 20]
    for m in (1, 2, 3):
        Q = lambda a, b: sub(a, b)
        simp = [monotone_count(lambda x, y: x <= y, Q, j + 1, 1 << m) for j in range(0, 4)]
        cube = [monotone_count((lambda x, y: sub(x, y)) if not sab else (lambda x, y: x <= y), Q, 1 << k, 1 << m) for k in range(0, 4)]
        rows.append(f'm={m}: chains [j] -> B_m {simp}, cubes B_k -> B_m {cube}')
        if simp != [(j + 2) ** m for j in range(4)] or cube != [x ** m for x in Mk]: ok = False
        if not (cube[0] == 2 ** m and cube[1] == 3 ** m and cube[2] != 4 ** m): ok = False
    return report('bd·mjc·32', ok, 'level counts against the Atlas: ' + '; '.join(rows) + ': the levels give 2^m, 3^m, 6^m, 20^m (cubes), the nerve gives 2^m, 3^m, 4^m, 5^m (chains); they agree for k = j = 0, 1 and part at the square B_2 against the chain [2]')

CHECKS = [('bd·mjc·30', check30), ('bd·mjc·31', check31), ('bd·mjc·32', check32)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear()
            okk = f(sab=True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            if okk: missed += 1
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    nfail = sum(1 for _, okk in RESULTS if not okk)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
