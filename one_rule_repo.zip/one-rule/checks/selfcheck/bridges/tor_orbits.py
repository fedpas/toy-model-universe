#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""tor_orbits.py: inputs as torsors.  For each input of the Atlas that is a choice of STRUCTURE (time direction, complex structure J,
Witt split, Lagrangian of a clock-0 cell, Furey's block partition, orthonormal frame, involution), count the orbits of a group that
the algebra supplies on the space of choices: one orbit = gauge (the choice carries no information), k orbits = a datum with k values.

  python3 selfcheck/bridges/tor_orbits.py              one line per check, ids bd·tor·1 .. bd·tor·7; exit 1 on any FAIL
  python3 selfcheck/bridges/tor_orbits.py --sabotage   every check against a broken input (a restricted group, a wrong signature, ...); each must print CAUGHT

Standard library only; exact integers and fractions; no randomness; deterministic, about 13 s; runs from any folder, reads and writes no file.
The bit rule as in core_check.py.
  bd·tor·1  time direction, Cl(1,n-1), n = 2..6: unit timelike vectors are one orbit of the even Clifford group and two of the rotors (R g0 R^-1
            has u.g0 of the sign of R R~): the datum is a time orientation (2 values).
  bd·tor·2  complex structure J (a unit spatial bivector) under the spatial rotors: two orbits at n = 3 (J and -J), one for n = 4..6.
  bd·tor·3  Witt split (Fock vacuum) of Cl(k,k), k = 1..4, on the coordinate splits: one orbit of the signed permutations, two of the even Clifford
            group and of the rotors (separated by the family of the Lagrangian): gauge under Pin, a datum with 2 values under Spin.
  bd·tor·4  the graded Lagrangians of the clock-0 cells with n <= 8 (Furey's axes among them) are one orbit of the rotor-induced label group.
  bd·tor·5  Furey's block projectors fix her Hamming code H_F (the torus is gauge: Stab(omega) is transitive on the 30 Lagrangians); the block
            partition of the 16 axes is a datum: 6720 partitions in 11 orbits of the full graded group fixing omega and the torus.
  bd·tor·6  orthonormal coordinate frames, every (p,q) with n <= 5: one free orbit of the square-preserving signed permutations; 2 orbits of the even
            Clifford group, 4 (p, q >= 1) or 2 (definite) of the rotors.
  bd·tor·7  involutions, every cell with n <= 8: reversion and Clifford conjugation are isomorphic iff n = 0 mod 4 and the cell is indefinite
            (e_i -> e_i I); reversion = dagger iff q = 0, conjugation = dagger iff p = 0.
The groups: rotors (even R, R R~ = 1) and the even Clifford group act by R x R^-1; the Pin-type (twisted) action adds odd versors;
on the labels the algebra acts through its monomial automorphisms: conjugation by the 90-degree rotors exp(pi e_v / 4) of even blades
with e_v^2 = -1 induces the transvection x -> x + B(x,v) v on the labels (graded), and by (1 + e_v)/sqrt 2 for any blade of square -1
(ungraded).  Each check states the group it lets act.
"""
import sys, itertools
from fractions import Fraction as Fr

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def cell(p, q): return [1] * p + [-1] * q
def mul(A, B, eps):
    out = {}
    for a, x in A.items():
        for b, y in B.items():
            c = x * y * sgn(a, b, eps)
            if c: out[a ^ b] = out.get(a ^ b, 0) + c
    return {k: v for k, v in out.items() if v}
def rev(A): return {a: c * (-1) ** (pc(a) * (pc(a) - 1) // 2) for a, c in A.items()}
def scal(A): return A.get(0, 0)

RESULTS = []
def report(cid, ok, text, verbose=True):
    RESULTS.append((cid, ok))
    if verbose: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)

def orbits(objs, gens, act):
    seen = set(); out = []
    for o in objs:
        if o in seen: continue
        orb = {o}; st = [o]
        while st:
            x = st.pop()
            for g in gens:
                y = act(g, x)
                if y not in orb: orb.add(y); st.append(y)
        seen |= orb; out.append(len(orb))
    return sorted(out)

# ============================================================================================ bd·tor·1  time direction
def check1(sab=False, verbose=True):
    """For Cl(1,n-1), n = 2..6 (gamma_0 = generator 0, square +1): <e_a gamma0 e_b~ gamma0>_0 = delta_ab for all even labels a, b.
       Hence for every even R = sum r_a e_a: <R gamma0 R~ gamma0>_0 = sum r_a^2 > 0, so u = R gamma0 R^-1 has u.gamma0 of the sign of R R~:
       rotors keep the future sheet, even versors with R R~ < 0 swap the sheets.  R' = 1 + u gamma0 maps gamma0 to every future unit u
       (R' gamma0 R'~ = 2(1 + u.gamma0) u, R' R'~ = 2(1 + u.gamma0) > 0), and R = gamma0 gamma1 (R R~ = -1) maps gamma0 to -gamma0."""
    ok = True
    for n in range(2, 7):
        eps = [1] + [-1] * (n - 1) if not sab else [1, 1] + [-1] * (n - 2)   # SABOTAGE: two time directions (Cl(2,n-2))
        g0 = {1: 1}
        evens = [a for a in range(1 << n) if pc(a) % 2 == 0]
        for a in evens:
            for b in evens:
                v = scal(mul(mul(mul({a: 1}, g0, eps), rev({b: 1}), eps), g0, eps))
                if v != (1 if a == b else 0): ok = False
        # transitivity on the future sheet with exact rational unit vectors u (u.u = 1, u0 > 0)
        samples = [(Fr(5, 4), Fr(3, 4)), (Fr(1),), (Fr(5, 4), Fr(0), Fr(3, 4))]
        if n >= 3: samples += [(Fr(3), Fr(2), Fr(2)), (Fr(3, 2), Fr(1), Fr(1, 2))]
        if n >= 4: samples += [(Fr(2), Fr(1), Fr(1), Fr(1))]
        for s in samples:
            if len(s) > n: continue
            u = {1 << i: s[i] for i in range(len(s)) if s[i]}
            if sum(eps[i] * s[i] ** 2 for i in range(len(s))) != 1: continue
            ug = scal(mul(u, g0, eps))
            Rp = {0: Fr(1)}
            for k, v in mul(u, g0, eps).items(): Rp[k] = Rp.get(k, 0) + v
            img = mul(mul(Rp, g0, eps), rev(Rp), eps)
            norm = mul(Rp, rev(Rp), eps)
            if img != {k: 2 * (1 + ug) * v for k, v in u.items()} or norm != {0: 2 * (1 + ug)} or not 2 * (1 + ug) > 0: ok = False
        # gamma0 gamma1: R R~ = -1, R gamma0 R~ = gamma0, so R gamma0 R^-1 = -gamma0
        R = {3: 1}
        if mul(R, rev(R), eps) != {0: -1} or mul(mul(R, g0, eps), rev(R), eps) != {1: 1}: ok = False
    report('bd·tor·1', ok, 'time direction, Cl(1,n-1), n = 2..6: <e_a g0 e_b~ g0>_0 = delta_ab on even labels, so u = R g0 R^-1 has u.g0 of the sign of R R~ for every even R; '
           'R\' = 1 + u g0 reaches every rational future unit u tested; g0 g1 swaps the sheets. Unit timelike vectors: one orbit of the even Clifford group, '
           'two orbits of the rotors: the datum is a time orientation (2 values), the rest of g0 is gauge', verbose)

# ============================================================================================ bd·tor·2  complex structure J
def check2(sab=False, verbose=True):
    """J of the Dirac step: unit spatial bivectors +-g_i g_j (1 <= i < j <= n-1) in Cl(1,n-1), acted on by the right spatial rotors.
       Orbits under the 90-degree rotors (1 + g_k g_l)/sqrt2 (exact: R'^~ J R' / 2 with R' = 1 + g_k g_l): 2 for n = 3, 1 for n = 4, 5, 6.
       At n = 3 the spatial even algebra span{1, g1 g2} is commutative, so every spatial rotor fixes J: exactly 2 orbits (J, -J)."""
    res = {}
    for n in range(3, 7):
        eps = [1] + [-1] * (n - 1)
        J = [(s, (1 << i) | (1 << j)) for i in range(1, n) for j in range(i + 1, n) for s in (1, -1)]
        planes = [(k, l) for k in range(1, n) for l in range(k + 1, n)]
        if sab and n >= 4: planes = [(1, 2)]                       # SABOTAGE: only rotations in one plane act
        gens = []
        for (k, l) in planes:
            Rp = {0: 1, (1 << k) | (1 << l): 1}
            def act(Rp, x, eps=eps):
                s, lab = x
                img = mul(mul(rev(Rp), {lab: s}, eps), Rp, eps)
                (lab2, c), = img.items()
                return (c // 2, lab2)
            gens.append(Rp)
        res[n] = orbits(J, gens, lambda g, x, eps=eps: (lambda img: (list(img.values())[0] // 2, list(img.keys())[0]))(mul(mul(rev(g), {x[1]: x[0]}, eps), g, eps)))
    # n = 3: J = g1 g2 commutes with the basis 1, g1 g2 of the spatial even algebra
    eps = [1, -1, -1]; J = {6: 1}
    comm3 = all(mul(J, {b: 1}, eps) == mul({b: 1}, J, eps) for b in (0, 6))
    ok = [len(res[n]) for n in range(3, 7)] == [2, 1, 1, 1] and comm3
    report('bd·tor·2', ok, 'complex structure J = unit spatial bivector of Cl(1,n-1) under the right spatial rotors: orbit counts ' +
           ', '.join(f'n={n}: {len(res[n])}' for n in range(3, 7)) + '; at n = 3 every spatial rotor commutes with J, so J and -J are two values (an orientation of the '
           'spatial plane); for n >= 4 the choice of J is gauge', verbose)

# ============================================================================================ bd·tor·3  Witt split
def check3(sab=False, verbose=True):
    """Coordinate Witt splits of Cl(k,k): L = span{e_i + s_i f_sigma(i)} (k! 2^k of them).  Acting group: square-preserving signed
       permutations (A on the e's, D on the f's), the monomial part of the Pin group.  Full group: 1 orbit; det A det D = +1 (even
       Clifford group): 2 orbits; det A = det D = +1 (rotors): 2 orbits.  Invariant: sign(sigma) prod s_i (the family of L)."""
    out = {}; ok = True
    for k in range(1, 5):
        objs = [(perm, s) for perm in itertools.permutations(range(k)) for s in itertools.product((1, -1), repeat=k)]
        def act(g, x):
            (pe, te, pf, tf) = g; (perm, s) = x
            newp = [0] * k; news = [0] * k
            for i in range(k):
                newp[pe[i]] = pf[perm[i]]; news[pe[i]] = s[i] * te[i] * tf[perm[i]]
            return (tuple(newp), tuple(news))
        idp = tuple(range(k)); one = (1,) * k
        def flip(i): return tuple(-1 if j == i else 1 for j in range(k))
        def swap(i, j): p = list(range(k)); p[i], p[j] = p[j], p[i]; return tuple(p)
        full = [(swap(i, i + 1), one, idp, one) for i in range(k - 1)] + [(idp, one, swap(i, i + 1), one) for i in range(k - 1)] + \
               [(idp, flip(i), idp, one) for i in range(k)] + [(idp, one, idp, flip(i)) for i in range(k)]
        if sab: full = [g for g in full if g[1] == one and g[3] == one]          # SABOTAGE: permutations only, no sign changes
        def both(i, j): return tuple(-1 if t in (i, j) else 1 for t in range(k))
        rot = [(swap(i, i + 1), flip(i), idp, one) for i in range(k - 1)] + [(idp, one, swap(i, i + 1), flip(i)) for i in range(k - 1)] + \
              [(idp, both(i, j), idp, one) for i in range(k) for j in range(i + 1, k)] + [(idp, one, idp, both(i, j)) for i in range(k) for j in range(i + 1, k)]
        even = rot + [(idp, flip(0), idp, flip(0))]
        o_full, o_even, o_rot = orbits(objs, full, act), orbits(objs, even, act), orbits(objs, rot, act)
        out[k] = (len(objs), len(o_full), len(o_even), len(o_rot))
        def inv(x):
            perm, s = x; sg = 1
            for i in range(k):
                for j in range(i + 1, k):
                    if perm[i] > perm[j]: sg = -sg
            pr = 1
            for t in s: pr *= t
            return sg * pr
        # the invariant separates the two orbits of the even Clifford group
        if not sab:
            for g in even:
                if any(inv(act(g, x)) != inv(x) for x in objs): ok = False
        if (len(o_full), len(o_even), len(o_rot)) != (1, 2, 2): ok = False
    report('bd·tor·3', ok, 'Witt split (Fock vacuum) of Cl(k,k), k = 1..4: coordinate splits ' + ', '.join(f'k={k}: {v[0]}' for k, v in out.items()) +
           '; orbits under the full signed permutations 1, under det A det D = +1 (even Clifford group) 2, under the rotors 2; the invariant sign(sigma) prod s_i '
           '(the family of the Lagrangian) separates them: gauge under Pin, a datum with 2 values under Spin', verbose)

# ============================================================================================ bd·tor·4  Lagrangians of clock-0 cells
def Qf(a, e): return 1 if sgn(a, a, e) == -1 else 0
def wf(a, e): return (pc(a) % 2 + 2 * Qf(a, e)) % 4
def subspaces(n, pred, dim):
    cands = [a for a in range(1, 1 << n) if pred(a)]; out = set()
    def rec(span, basis, start):
        if len(basis) == dim: out.add(frozenset(span)); return
        for idx in range(start, len(cands)):
            v = cands[idx]
            if v in span: continue
            if all(pred(s ^ v) for s in span): rec(span | {s ^ v for s in span}, basis + [v], idx + 1)
    rec({0}, [], 0); return out
def check4(sab=False, verbose=True):
    """Lagrangians of the clock-0 cells with n <= 8.  Graded: subgroups L, |L|^2 = 2^n, w = 0 on L (cat·W1, bd·cat·13); acting group G_w
       generated by the label transvections t_v, w(v) = 2 (conjugation by the even rotors exp(pi e_v/4)).  Ungraded: totally singular
       subspaces of Q of dimension n/2; group G_Q generated by t_v with Q(v) = 1 (conjugation by (1 + e_v)/sqrt2)."""
    rows = []; ok = True
    for (p, q) in [(1, 1), (2, 2), (3, 3), (4, 4), (8, 0), (0, 8)]:
        n = p + q; e = cell(p, q)
        W = [wf(a, e) for a in range(1 << n)]; Qt = [Qf(a, e) for a in range(1 << n)]
        Lw = subspaces(n, lambda a: W[a] == 0, n // 2); LQ = subspaces(n, lambda a: Qt[a] == 0, n // 2)
        def tv_dot(v): return [x ^ (v if pc(x & v) % 2 else 0) for x in range(1 << n)]
        def tv_Q(v): return [x ^ (v if (Qt[x ^ v] + Qt[x] + Qt[v]) % 2 else 0) for x in range(1 << n)]
        gw = [tv_dot(v) for v in range(1, 1 << n) if W[v] == 2]
        if sab and (p, q) == (4, 4): gw = [tv_dot(v) for v in range(1, 1 << n) if W[v] == 2 and pc(v) == 2]   # SABOTAGE: coordinate permutations only
        gq = [tv_Q(v) for v in range(1, 1 << n) if Qt[v] == 1]
        act = lambda g, L: frozenset(g[a] for a in L)
        ow, oq, oqw = orbits(Lw, gw, act), orbits(LQ, gq, act), orbits(LQ, gw, act)
        even_ones = sum(1 for L in LQ if all(pc(a) % 2 == 0 for a in L))
        rows.append(f'Cl({p},{q}): {len(Lw)} graded in {len(ow)} orbit(s), {len(LQ)} ungraded in {len(oq)}; under G_w the ungraded split {oqw}')
        if len(ow) != 1 or len(oq) != 1 or sorted(oqw) != sorted([even_ones, len(LQ) - even_ones]) or even_ones != len(Lw): ok = False
    if verbose and not sab:
        for r in rows: print('     ' + r)
    report('bd·tor·4', ok, 'Lagrangians of the clock-0 cells n <= 8: the graded ones (graded Morita trivialisations, Furey\'s axes) are ONE orbit of the rotor-induced '
           'group G_w, the ungraded ones one orbit of G_Q; under the graded group the ungraded ones split in two (inside the even labels or not): the choice of a '
           'graded Lagrangian is gauge', verbose)

# ============================================================================================ bd·tor·5  Furey's partition
def qmul(p, q):
    a1, b1, c1, d1 = p; a2, b2, c2, d2 = q
    return (a1*a2-b1*b2-c1*c2-d1*d2, a1*b2+b1*a2+c1*d2-d1*c2, a1*c2-b1*d2+c1*a2+d1*b2, a1*d2+b1*c2-c1*b2+d1*a2)
def qconj(p): return (p[0], -p[1], -p[2], -p[3])
def omul(x, y):
    a, b = x[:4], x[4:]; c, d = y[:4], y[4:]
    return tuple(u - v for u, v in zip(qmul(a, c), qmul(qconj(d), b))) + tuple(u + v for u, v in zip(qmul(d, a), qmul(b, qconj(c))))
E8 = [tuple(int(i == j) for j in range(8)) for i in range(8)]
def Lmat(x): cols = [omul(x, E8[m]) for m in range(8)]; return [[cols[m][r] for m in range(8)] for r in range(8)]
def Rmat(x): cols = [omul(E8[m], x) for m in range(8)]; return [[cols[m][r] for m in range(8)] for r in range(8)]
def mm(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B)) if A[i][k]) for j in range(len(B[0]))] for i in range(len(A))]
def eye(n): return [[int(i == j) for j in range(n)] for i in range(n)]
def neg(A): return [[-x for x in r] for r in A]
def blk(A, B, C, D): return [A[i] + B[i] for i in range(8)] + [C[i] + D[i] for i in range(8)]
def furey_model():
    """V = O + O' (16 real dimensions), the Cl(0,8) generators of the Furey page (run_all.py), omega = L_e7 on both copies,
       the six real block projectors (times 2, integer): O1, O2 = (1 -+ L_k R_k)/2 on the first copy, H, C, e7R, R on the second."""
    Z = [[0] * 8 for _ in range(8)]; I8 = eye(8); I16 = eye(16)
    k = E8[3]; Lk, Rk = Lmat(k), Rmat(k); LR = mm(Lk, Rk)
    P1 = [[int(i == j) - LR[i][j] for j in range(8)] for i in range(8)]; P2 = [[int(i == j) + LR[i][j] for j in range(8)] for i in range(8)]
    def proj2(P8, second):
        P = [[0] * 16 for _ in range(16)]
        for i in range(8):
            for j in range(8): P[i][j] = P8[i][j]
        for m in second: P[8 + m][8 + m] = 2
        return P
    real = {'O1': proj2(P1, ()), 'O2': proj2(P2, ()), 'H': proj2(Z, (4, 5, 6, 7)), 'C': proj2(Z, (1, 2)), 'e7R': proj2(Z, (3,)), 'R': proj2(Z, (0,))}
    om = blk(Lk, Z, Z, Lk)
    g = [blk(Z, Lmat(E8[m]), Lmat(E8[m]), Z) for m in range(1, 8)] + [blk(Z, I8, neg(I8), Z)]
    return real, om, g, I16
def check5(sab=False, verbose=True):
    real, om, g, I16 = furey_model()
    def blade(S):
        M = I16
        for a in S: M = mm(M, g[a])
        return M
    lab = lambda S: sum(1 << i for i in S)
    units = [E8[m] for m in range(1, 8)]
    lines = []
    for a in range(7):
        for b in range(a + 1, 7):
            pr = omul(units[a], units[b]); c = max(range(8), key=lambda i: abs(pr[i])) - 1
            if c > b: lines.append((a, b, c))
    HF = {0}
    for l in lines:
        v = lab(l + (7,)); HF |= {s ^ v for s in HF}
    HF = frozenset(HF)
    Omega = lab((0, 1, 3, 4, 5, 6)); ok = blade((0, 1, 3, 4, 5, 6)) == om
    # (a) weight-4 blades commuting with every block projector: exactly the 14 of H_F
    w4 = list(itertools.combinations(range(8), 4))
    D4 = {lab(S) for S in w4 if all(mm(P, blade(S)) == mm(blade(S), P) for P in real.values())}
    ok &= D4 == {h for h in HF if pc(h) == 4}
    # (b) the 18480 independent commuting quadruples: 30 spans x 616 bases; the diagonalising ones are the 616 bases of H_F
    spans = {}; good = 0
    for quad in itertools.combinations([lab(S) for S in w4], 4):
        if all(pc(x & y) % 2 == 0 for x, y in itertools.combinations(quad, 2)):
            sp = {0}
            for v in quad: sp |= {s ^ v for s in sp}
            if len(sp) == 16:
                spans[frozenset(sp)] = spans.get(frozenset(sp), 0) + 1
                if all(v in D4 for v in quad): good += 1
    ok &= sum(spans.values()) == 18480 and len(spans) == 30 and set(spans.values()) == {616} and good == 616
    # (c) label group G_w of Cl(0,8) (rotor-induced transvections); stabilisers by Schreier generators
    N = 256; e = [-1] * 8; W = [wf(a, e) for a in range(N)]
    gens = [tuple(x ^ (v if pc(x & v) % 2 else 0) for x in range(N)) for v in range(1, N) if W[v] == 2]
    if sab: gens = [tuple(x ^ (v if pc(x & v) % 2 else 0) for x in range(N)) for v in range(1, N) if W[v] == 2 and pc(v) == 2]   # SABOTAGE: S_8 only
    ID = tuple(range(N))
    def comp(a, b): return tuple(a[b[x]] for x in range(N))
    def inv(a):
        r = [0] * N
        for x in range(N): r[a[x]] = x
        return tuple(r)
    def schreier(gs, act, pt):
        tr = {pt: ID}; st = [pt]
        while st:
            x = st.pop()
            for gg in gs:
                y = act(gg, x)
                if y not in tr: tr[y] = comp(gg, tr[x]); st.append(y)
        S = set()
        for x, tx in tr.items():
            for gg in gs:
                s = comp(inv(tr[act(gg, x)]), comp(gg, tx))
                if s != ID: S.add(s)
        return list(S), len(tr)
    apt = lambda gg, x: gg[x]; aset = lambda gg, S: frozenset(gg[a] for a in S)
    SO, orbO = schreier(gens, apt, Omega)
    o30 = orbits(list(spans), SO, aset)
    ok &= len(o30) == 1
    bases = [frozenset(q) for q in itertools.combinations([h for h in HF if pc(h) == 4], 4) if len(functools_span(q)) == 16]
    SH, _ = schreier(gens, aset, HF); o616_H = orbits(bases, SH, aset)
    SHO, orbOH = schreier(SH, apt, Omega); o616_HO = orbits(bases, SHO, aset)
    ok &= orbO == 56 and orbOH == 56 and sum(1 for v in range(1, N) if W[v] == 2) == 56
    # (d) the block partition of the 16 axes.  Axes = standard basis of V (the torus is diagonal); parity from the top blade; omega pairs axes.
    gam = blade(tuple(range(8))); par = [gam[i][i] for i in range(16)]
    pair = {i: [r for r in range(16) if om[r][i]][0] for i in range(16)}
    pairs = sorted({tuple(sorted((i, pair[i]))) for i in range(16)})
    furey = (frozenset({0, 3}), frozenset({1, 2, 4, 5, 6, 7}), frozenset({12, 13, 14, 15}), frozenset({9, 10}), 11, 8)
    # admissible partitions: O1 (1 pair), O2 (3 pairs), H (2), C (1), and the last pair split into (e7R, R)
    adm = []
    for order in itertools.permutations(range(8)):
        if not (order[1] < order[2] < order[3] and order[4] < order[5]): continue
        P = [pairs[i] for i in order]
        for last in (P[7], P[7][::-1]):
            adm.append((frozenset(P[0]), frozenset(P[1] + P[2] + P[3]), frozenset(P[4] + P[5]), frozenset(P[6]), last[0], last[1]))
    ok &= furey in adm and len(adm) == 6720
    def act_axes(perm, part):
        o1, o2, h, c, x, y = part
        return (frozenset(perm[i] for i in o1), frozenset(perm[i] for i in o2), frozenset(perm[i] for i in h), frozenset(perm[i] for i in c), perm[x], perm[y])
    # (i) the full graded group fixing omega and the torus: permutations of omega-pairs within each parity class, swap of the classes, omega on one pair
    ev = [pp for pp in pairs if par[pp[0]] == 1]; od = [pp for pp in pairs if par[pp[0]] == -1]
    def pairperm(mapping):
        perm = list(range(16))
        for (a, b), (c, d) in mapping.items(): perm[a], perm[b] = c, d
        return tuple(perm)
    G1 = []
    for cls in (ev, od):
        for i in range(len(cls) - 1):
            m = {pp: pp for pp in pairs}; m[cls[i]], m[cls[i + 1]] = cls[i + 1], cls[i]; G1.append(pairperm(m))
    m = {pp: pp for pp in pairs}
    for a, b in zip(ev, od): m[a], m[b] = b, a
    G1.append(pairperm(m))
    for pp in pairs:
        perm = list(range(16)); perm[pp[0]], perm[pp[1]] = pp[1], pp[0]; G1.append(tuple(perm))
    o_full = orbits(adm, G1, act_axes)
    # (ii) the label-preserving group: affine maps of the 16 axes (characters of H_F relative to axis 0) with linear part from Stab(H_F) n Stab(Omega)
    hb = sorted(HF)
    diag = {h: None for h in hb}
    for h in hb:
        S = tuple(i for i in range(8) if h >> i & 1); B = blade(S); diag[h] = [B[i][i] for i in range(16)]
    psi = [tuple((0 if diag[h][i] * diag[h][0] == 1 else 1) for h in hb) for i in range(16)]
    ok &= len(set(psi)) == 16
    index = {p_: i for i, p_ in enumerate(psi)}
    hpos = {h: t for t, h in enumerate(hb)}
    G2 = []
    for T in SHO:
        Ti = inv(T)
        perm = tuple(index[tuple(psi[i][hpos[Ti[h]]] for h in hb)] for i in range(16))
        G2.append(perm)
    for i in range(16):                                      # translations by every character: axis j -> the axis of psi_j + psi_i
        G2.append(tuple(index[tuple(a ^ b for a, b in zip(psi[j], psi[i]))] for j in range(16)))
    o_label = orbits(adm, G2, act_axes)
    # parity profile of Furey's partition: every block homogeneous, the O-blocks even
    prof = [sorted({par[i] for i in blk_}) for blk_ in furey[:4]] + [[par[furey[4]]], [par[furey[5]]]]
    ok &= prof == [[1], [1], [-1], [-1], [-1], [-1]]
    if verbose and not sab:
        print(f'     H_F = span of the Fano-line blades; omega = blade 0,1,3,4,5,6; label orbit of omega: {orbO} (all even blades of square -1), also under Stab(H_F): {orbOH}; Stab(omega) on the 30 Lagrangians: {o30}; '
              f'on the 616 bases of H_F: Stab(H_F) {o616_H}, Stab(H_F) n Stab(omega) {len(o616_HO)} orbits')
        print(f'     admissible block partitions of the 16 axes: {len(adm)}; orbits under the full graded group fixing omega and the torus: {len(o_full)}; '
              f'under the label-preserving group: {len(o_label)}; Furey\'s partition: O-blocks even, H, C, e7R, R odd')
    # cross-check of the full-group count: the orbit of a partition is fixed by the number of even omega-pairs in each block
    # (O1: 1 pair, O2: 3, H: 2, C: 1, last: 1; 4 even pairs in all), up to the swap of the two parity classes (no profile is swap-fixed)
    sizes = (1, 3, 2, 1, 1)
    profiles = [x for x in itertools.product(*[range(s_ + 1) for s_ in sizes]) if sum(x) == 4]
    swapfix = [x for x in profiles if tuple(s_ - y for s_, y in zip(sizes, x)) == x]
    ok &= len(profiles) == 22 and not swapfix and len(o_full) == len(profiles) // 2
    ok &= o616_H == [56, 224, 336] and len(o616_HO) == 10 and len(o_full) == 11 and len(o_label) == 22
    report('bd·tor·5', ok, 'Furey: the block projectors commute with exactly the 14 weight-4 blades of her Hamming code H_F, so the 616 of 18480 diagonalising quadruples are the '
           '616 bases of the ONE Lagrangian H_F (18480 = 30 x 616): the blocks force the torus, and the torus is gauge (Stab(omega) is transitive on the 30). The block '
           f'partition of the 16 axes is a datum: {len(adm)} omega-compatible partitions fall into {len(o_full)} orbits of the full graded group fixing omega and the torus '
           f'({len(o_label)} under the label-preserving group)', verbose)
def functools_span(q):
    sp = {0}
    for v in q: sp |= {s ^ v for s in sp}
    return sp

# ============================================================================================ bd·tor·6  orthonormal frames
def check6(sab=False, verbose=True):
    """Coordinate frames of the frame lattice I_(p,q): ordered frames (t_i e_pi(i)) with the same Gram matrix, i.e. the square-preserving
       signed permutations, acted on by the same group (left multiplication).  Full group: one orbit, free (a torsor).  Subgroups:
       det_+ det_- = +1 (images of the even Clifford group): 2 orbits; det_+ = det_- = +1 (rotors): 4 orbits if p, q >= 1, 2 if definite."""
    ok = True; rows = []
    for n in range(1, 6):
        for p in range(n + 1):
            q = n - p
            frames = [(pp, t) for pp in itertools.permutations(range(n)) if all((pp[i] < p) == (i < p) for i in range(n)) for t in itertools.product((1, -1), repeat=n)]
            def act(g, f):
                (gp, gt), (fp, ft) = g, f
                return (tuple(gp[fp[i]] for i in range(n)), tuple(ft[i] * gt[fp[i]] for i in range(n)))
            idp = tuple(range(n)); one = (1,) * n
            def flip(*ix): return tuple(-1 if j in ix else 1 for j in range(n))
            def swap(i, j): x = list(range(n)); x[i], x[j] = x[j], x[i]; return tuple(x)
            blocks = [list(range(p)), list(range(p, n))]
            full = [(swap(b[i], b[i + 1]), one) for b in blocks for i in range(len(b) - 1)] + [(idp, flip(i)) for i in range(n)]
            rot = [(swap(b[i], b[i + 1]), flip(b[i])) for b in blocks for i in range(len(b) - 1)] + \
                  [(idp, flip(b[i], b[j])) for b in blocks for i in range(len(b)) for j in range(i + 1, len(b))]
            even = rot + ([(idp, flip(0, p))] if p and q else [])
            if sab: full = rot                                                 # SABOTAGE: only the rotor part acts
            of, oe, orr = orbits(frames, full, act), orbits(frames, even, act), orbits(frames, rot, act)
            want_r = 4 if p and q else 2
            want_e = 2
            if n == 1: want_r, want_e = 2, 2
            if len(of) != 1 or of[0] != len(frames) or len(oe) != want_e or len(orr) != want_r: ok = False
            if n == 4: rows.append(f'Cl({p},{q}): {len(frames)} frames, orbits {len(of)}/{len(oe)}/{len(orr)}')
    report('bd·tor·6', ok, 'orthonormal frames, every (p,q) with n <= 5: the coordinate frames are one free orbit (a torsor) of the square-preserving signed permutations '
           '(Pin, monomial part); under the even Clifford group 2 orbits (an orientation), under the rotors 4 for p, q >= 1 and 2 for definite cells '
           '(orientation and time orientation): the frame is gauge, up to these orientations (' + '; '.join(rows) + ')', verbose)

# ============================================================================================ bd·tor·7  involution
def tau_coef(name, a, eps):
    k = pc(a); r = (-1) ** (k * (k - 1) // 2)
    if name == 'rev': return r
    if name == 'conj': return (-1) ** k * r
    if name == 'dag': return sgn(a, a, eps)
def positive(name, eps, twist=False):
    return all(tau_coef(name, a, eps) * sgn(a, a, eps) * ((-1) ** pc(a) if twist else 1) == 1 for a in range(1 << len(eps)))
def independent(labels):
    basis = {}
    for v in labels:
        x = v
        while x:
            h = x.bit_length() - 1
            if h in basis: x ^= basis[h]
            else: basis[h] = x; break
        if x == 0: return False
    return True
def block_map(eps, blocks, t_src, t_tgt):
    """e'_i -> e_i w_B for i in a block B (blocks disjoint, |B| even), e'_j -> e_j otherwise; valid iff the images are odd, anticommute,
       are independent, and t_tgt acts on each image as t_src acts on the generator of the source.  Returns (valid, eps')."""
    n = len(eps); imgs = []
    owner = {}
    for B in blocks:
        for i in B: owner[i] = sum(1 << j for j in B)
    for i in range(n):
        lab = (1 << i) ^ owner[i] if i in owner else 1 << i
        imgs.append(lab)
    epsp = [sgn(l, l, eps) for l in imgs]
    ok = all(pc(l) % 2 == 1 for l in imgs) and all(sgn(imgs[i], imgs[j], eps) == -sgn(imgs[j], imgs[i], eps) for i in range(n) for j in range(i + 1, n))
    ok = ok and independent(imgs) and all(x != 0 for x in epsp)
    ok = ok and all(tau_coef(t_tgt, imgs[i], eps) == tau_coef(t_src, 1 << i, epsp) for i in range(n))
    return ok, epsp
def check7(sab=False, verbose=True):
    """Is the choice among reversion, Clifford conjugation and dagger a gauge, i.e. is (Cl(p,q), grading, t1) = (Cl(p,q), grading, t2)?
       Invariants: dim Fix(t), positivity of <x t(x)>_0 and of <x alpha t(x)>_0.  Isomorphisms: identity when t1 = t2 as maps; block maps
       (one block of any composition, or blocks of 4 covering every generator) between (cell, t1) and (cell', t2), joined by union-find."""
    invs = ['rev', 'conj', 'dag']
    if sab: invs = ['rev', 'conj', 'rev']                      # SABOTAGE: the dagger replaced by a second copy of the reversion
    names = {0: 'rev', 1: 'conj', 2: 'dag'}
    ok = True; table = {}; undecided = []
    for n in range(1, 9):
        nodes = [(p, n - p, t) for p in range(n + 1) for t in range(3)]
        parent = {x: x for x in nodes}
        def find(x):
            while parent[x] != x: x = parent[x]
            return x
        def union(x, y): parent[find(x)] = find(y)
        for p in range(n + 1):
            q = n - p; eps = cell(p, q)
            for t1 in range(3):
                for t2 in range(3):
                    if t1 < t2 and all(tau_coef(invs[t1], a, eps) == tau_coef(invs[t2], a, eps) for a in range(1 << n)): union((p, q, t1), (p, q, t2))
            cfgs = []
            for k in range(p + 1):
                for m in range(q + 1):
                    if (k + m) % 2 == 0 and k + m >= 2: cfgs.append([list(range(k)) + list(range(p, p + m))])
            if n % 4 == 0 and n >= 4:
                for kk in itertools.product(range(5), repeat=n // 4):
                    if sum(kk) != p or any(x > 4 for x in kk): continue
                    plus = list(range(p)); minus = list(range(p, n)); bl = []
                    for x in kk: bl.append(plus[:x] + minus[:4 - x]); plus = plus[x:]; minus = minus[4 - x:]
                    cfgs.append(bl)
            for bl in cfgs:
                for ts in range(3):
                    for tt in range(3):
                        valid, epsp = block_map(eps, bl, invs[ts], invs[tt])
                        if valid: union((epsp.count(1), epsp.count(-1), ts), (p, q, tt))
        for p in range(n + 1):
            q = n - p; eps = cell(p, q)
            iv = [(sum(1 for a in range(1 << n) if tau_coef(invs[t], a, eps) == 1), positive(invs[t], eps), positive(invs[t], eps, True)) for t in range(3)]
            res = []
            for t1, t2 in ((0, 1), (0, 2), (1, 2)):
                iso = find((p, q, t1)) == find((p, q, t2)); sep = iv[t1] != iv[t2]
                if iso and sep: ok = False
                if not iso and not sep: undecided.append(f'Cl({p},{q}) {names[t1]}/{names[t2]}')
                res.append('=' if iso else ('|' if sep else '?'))
            table[(p, q)] = res
    # expected pattern (ours, from the invariants): rev = conj iff n = 0 mod 4 and p, q >= 1; rev = dag iff q = 0; conj = dag iff p = 0
    for (p, q), res in table.items():
        n = p + q
        want = ['=' if (n % 4 == 0 and p and q) else '|', '=' if q == 0 else '|', '=' if p == 0 else '|']
        if res != want: ok = False
    if verbose and not sab:
        print('     rev/conj, rev/dag, conj/dag for n <= 8 ("=" isomorphic, "|" separated): ' +
              ' '.join(f'({p},{q}):{"".join(r)}' for (p, q), r in sorted(table.items()) if p + q in (4, 6)) + ' ...')
    report('bd·tor·7', ok and not undecided, 'involution, every cell with n <= 8, every pair decided: reversion and Clifford conjugation give isomorphic structures iff n = 0 mod 4 '
           'and the cell is indefinite (e.g. Cl(1,3), Cl(3,1): e_i -> e_i I); reversion = dagger iff q = 0, conjugation = dagger iff p = 0; otherwise the choice of '
           'involution is a datum', verbose)

CHECKS = [check1, check2, check3, check4, check5, check6, check7]
WHY = {'bd·tor·1': 'two time directions (Cl(2,n-2)): <e_a g0 e_b~ g0>_0 is then not positive on the even labels and the time-orientation invariant is lost',
       'bd·tor·2': 'only rotations in one plane act: the one-orbit cases n >= 4 become several orbits',
       'bd·tor·3': 'permutations without sign changes: the one-orbit case becomes several orbits',
       'bd·tor·4': 'only coordinate permutations act on Cl(4,4): the one graded orbit of 30 splits',
       'bd·tor·5': 'only S_8 acts on the labels: the orbit of the label of omega shrinks from 56 to 28 (the weight-6 blades only), so omega is not one orbit with all even blades of square -1',
       'bd·tor·6': 'only the rotor part acts: the one free orbit of frames becomes 2 or 4 orbits',
       'bd·tor·7': 'the dagger replaced by the reversion: the rev/dag column then differs from the stated pattern'}

if __name__ == '__main__':
    if '--sabotage' in sys.argv:
        missed = 0
        for chk in CHECKS:
            RESULTS.clear(); chk(sab=True, verbose=False)
            cid, ok = RESULTS[-1]
            print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  (' + WHY[cid] + ')')
            missed += ok
        print('ALL CAUGHT' if not missed else f'{missed} MISSED')
        sys.exit(1 if missed else 0)
    for chk in CHECKS: chk()
    bad = [c for c, ok in RESULTS if not ok]
    print(f'\n{len(RESULTS) - len(bad)}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
