#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mja_norms.py: linear-additive and square-additive norms, and the items of arXiv:2403.19689 (v3) from Def. 2 (3) to Corollary 1 (eqs. (8)
to (13)) tested on the labels: which additivity is the grading, which is the quadratic form, and how the clock w = pi + 2Q holds both.

    python3 selfcheck/bridges/mja_norms.py              one line per check, ids bd·mja·21 .. bd·mja·25; exit 1 on any FAIL
    python3 selfcheck/bridges/mja_norms.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only, exact integers; deterministic (seed 8); about 5 s; runs from any folder, reads and writes no file.
  bd·mja·21  the labels with the partial sum (+) (disjoint union) and the popcount weight satisfy the paper's (8) and (9): commutative, unit 0,
             Kleene-associative (a triple has both bracketings defined or neither), |a (+) b| = |a| + |b| on all 3^n defined pairs; no inverses
             (a (+) b = 0 only for a = b = 0); n <= 6.  The identity |a XOR b| = |a| + |b| - 2|a AND b| of popcounts is a remark, not tested.
  bd·mja·22  for every non-degenerate eps (n <= 6): Q(a XOR b) = Q(a) + Q(b) + B(a,b) mod 2 with B(a,b) = |a||b| + |a AND b|, i.e. the square of a
             product is the product of the squares up to the commutation sign (on disjoint labels B(a,b) = |a||b|, by the definition of B).
             Noise: for 300 random cocycles (random commutation matrix, seed 8) the commutation on disjoint labels is (-1)^{|a||b|} only when
             every generator pair anticommutes.
  bd·mja·23  w = pi + 2Q: w(a XOR b) = w(a) + w(b) + 2|a AND b| mod 4 (core·B1), so w is additive mod 4 on the 3^n disjoint pairs, and
             w(a) = sum_i eps_i a_i mod 4 (core·B2): for Cl(n,0), w = popcount mod 4; on disjoint pairs the carry of pi and the defect of Q
             cancel (2 pi(a) pi(b) each); of the 2^(n + C(n,2)) quadratic forms Q' on F_2^n exactly 2^n make pi + 2Q' additive on disjoint labels,
             and they are the Clifford forms Q_eps, eps in {+1,-1}^n (n <= 5).
  bd·mja·24  the paper's inner-product items on the labels: f f = |f|^2 (13) holds on a label exactly when |a| = 1 and eps = +1 there (the
             Clifford square e_a^2 is +-1; the dot product gives a.a = |a|, linear, a remark); antisymmetry (12) of disjoint blades holds exactly when
             |a||b| is odd; the dot product a.b = |a AND b| has 0 as its only label orthogonal to all (11); 'orthogonal implies anticommute'
             (Corollary 1 (2)) holds for vectors and fails for blades: for n = 3, 18 of the 42 ordered pairs of distinct nonzero blades commute.
  bd·mja·25  planar vectors with integer coordinates in [-4, 4]^2: |u + v| = |u| + |v| exactly for positively collinear pairs (or a zero
             vector), |u + v|^2 = |u|^2 + |v|^2 exactly for orthogonal pairs; both at once exactly when u = 0 or v = 0.
"""
import itertools, random, sys
from math import comb

SABOTAGE = '--sabotage' in sys.argv
ROWS = []
def row(cid, ok, text):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Q(a, eps): return 1 if sgn(a, a, eps) == -1 else 0
def pi(a): return pc(a) % 2
def w4(a, eps): return (pi(a) + 2 * Q(a, eps)) % 4
def nondeg(n): return [list(e) for e in itertools.product((1, -1), repeat=n)]
def alleps(n): return [list(e) for e in itertools.product((1, -1, 0), repeat=n)]

def chk21(sab):
    ok = True; bad = 0
    oplus = (lambda a, b: a ^ b if a & b == 0 else None) if not sab else (lambda a, b: a ^ b if pc(a & b) <= 1 else None)
    for n in range(0, 7):
        N = 1 << n; defined = 0
        for a in range(N):
            for b in range(N):
                s = oplus(a, b)
                if s is None: continue
                defined += 1
                if oplus(b, a) != s or pc(s) != pc(a) + pc(b): bad += 1
                if s == 0 and (a or b): bad += 1
            if oplus(0, a) != a: bad += 1
        if defined != 3 ** n: bad += 1
        if n <= 4:
            for a in range(N):
                for b in range(N):
                    for c in range(N):
                        ab, bc = oplus(a, b), oplus(b, c)
                        l = oplus(ab, c) if ab is not None else None
                        r = oplus(a, bc) if bc is not None else None
                        if l != r: bad += 1
    return bad == 0, ('labels with (+) = disjoint union and the popcount weight: commutative, unit 0, Kleene-associative, |a (+) b| = |a| + |b| on the 3^n '
                      'defined pairs, a (+) b = 0 only for a = b = 0 (n <= 6; triples n <= 4): the paper\'s (8), (9) '
                      'and "no inverse" hold exactly in the label model'), f'violations {bad}'

def chk22(sab):
    ok = True; bad = 0
    for n in range(0, 7):
        for e in nondeg(n):
            N = 1 << n
            for a in range(N):
                for b in range(N):
                    B = (pc(a) * pc(b) + pc(a & b)) % 2
                    if sab: B = (pc(a & b)) % 2                              # sabotage: the dot product in place of the polar form of Q
                    if (Q(a ^ b, e) - Q(a, e) - Q(b, e)) % 2 != B: bad += 1
    rng = random.Random(8); only = 0; tot = 0
    for _ in range(300):
        n = rng.randint(2, 4)
        beta = {(i, j): rng.choice((1, -1)) for i in range(n) for j in range(i)}
        qv = [rng.choice((1, -1)) for _ in range(n)]
        def c(a, b):
            s = 1
            for i in range(n):
                for j in range(n):
                    if a >> i & 1 and b >> j & 1:
                        if j < i: s *= beta[(i, j)]
                        if i == j: s *= qv[i]
            return s
        N = 1 << n
        graded = all(c(a, b) * c(b, a) == (-1) ** (pc(a) * pc(b)) for a in range(N) for b in range(N) if a & b == 0)
        allanti = all(v == -1 for v in beta.values())
        tot += 1
        if graded == allanti: only += 1
    if only != tot or bad: ok = False
    return ok, (f'Q(a XOR b) = Q(a) + Q(b) + |a||b| + |a AND b| mod 2 for every non-degenerate eps, n <= 6 (|a||b| on disjoint labels); '
                f'random cocycles (seed 8): graded commutativity on disjoint labels exactly when all generators anticommute in {only} of {tot}'), f'violations {bad}'

def all_quadratic_forms(n):
    lin = list(itertools.product((0, 1), repeat=n)); quad = list(itertools.product((0, 1), repeat=comb(n, 2)))
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    for l in lin:
        for qd in quad:
            def Qp(a, l=l, qd=qd):
                v = sum(l[i] for i in range(n) if a >> i & 1)
                v += sum(qd[k] for k, (i, j) in enumerate(pairs) if a >> i & 1 and a >> j & 1)
                return v % 2
            yield l, qd, Qp
def chk23(sab):
    ok = True; bad = 0
    for n in range(0, 7):
        for e in nondeg(n):
            N = 1 << n
            for a in range(N):
                if w4(a, e) != sum(e[i] for i in range(n) if a >> i & 1) % 4: bad += 1
                for b in range(N):
                    d = (w4(a ^ b, e) - w4(a, e) - w4(b, e)) % 4
                    if d != (2 * pc(a & b)) % 4: bad += 1
                    if a & b == 0:
                        carry = (pi(a ^ b) - pi(a) - pi(b)) % 4; qdef = (2 * (Q(a ^ b, e) - Q(a, e) - Q(b, e))) % 4
                        if carry != (2 * pi(a) * pi(b)) % 4 or qdef != (2 * pi(a) * pi(b)) % 4: bad += 1
            if n <= 6 and all(x == 1 for x in e):
                if any(w4(a, e) != pc(a) % 4 for a in range(N)): bad += 1
    found = {}
    for n in range(1, 6):
        N = 1 << n; good = []
        cliff = {tuple(Q(a, e) for a in range(N)) for e in nondeg(n)}
        for l, qd, Qp in all_quadratic_forms(n):
            tab = tuple(Qp(a) for a in range(N))
            if sab: tab = tuple((Qp(a) + (pc(a) >= 2)) % 2 for a in range(N))        # sabotage: a non-quadratic perturbation
            add = all((pi(a ^ b) + 2 * tab[a ^ b] - pi(a) - 2 * tab[a] - pi(b) - 2 * tab[b]) % 4 == 0 for a in range(N) for b in range(N) if a & b == 0)
            if add: good.append(tab)
        found[n] = len(good)
        if len(good) != 2 ** n or set(good) != cliff: ok = False
    if bad: ok = False
    return ok, ('w(a XOR b) = w(a) + w(b) + 2|a AND b| mod 4 and w(a) = sum eps_i a_i mod 4 for every non-degenerate eps (n <= 6); for Cl(n,0) w = popcount mod 4; '
                'on disjoint pairs the carry of pi and the defect of 2Q are both 2 pi(a) pi(b); quadratic forms Q\' with pi + 2Q\' additive on disjoint labels: '
                + ', '.join(f'n={n}: {k}' for n, k in found.items()) + ' of 2^(n + C(n,2)), exactly the Clifford forms'), f'found {found}, violations {bad}'

def chk24(sab):
    ok = True; notes = []
    for n in range(1, 6):
        for e in alleps(n):
            N = 1 << n
            sq = (lambda a: sgn(a, a, e)) if not (sab and n == 2) else (lambda a: pc(a))     # sabotage: the dot square a.a in place of e_a^2
            holds = {a for a in range(N) if sq(a) == pc(a) ** 2}
            want = {1 << i for i in range(n) if e[i] == 1}
            if holds != want: ok = False
            for a in range(N):
                for b in range(N):
                    if a & b == 0 and a and b:
                        anti = sgn(a, b, e) == -sgn(b, a, e)
                        if anti != ((pc(a) * pc(b)) % 2 == 1): ok = False
        orth = [a for a in range(1 << n) if all(pc(a & b) == 0 for b in range(1 << n))]
        if orth != [0]: ok = False
    e = [1, 1, 1]; comm = 0; tot = 0
    for a in range(1, 8):
        for b in range(1, 8):
            if a == b: continue
            tot += 1
            if sgn(a, b, e) == sgn(b, a, e): comm += 1
    vec_anti = all(sgn(1 << i, 1 << j, e) == -sgn(1 << j, 1 << i, e) for i in range(3) for j in range(3) if i != j)
    notes.append(f'n = 3: {comm} of {tot} ordered pairs of distinct nonzero blades commute although their scalar product is 0')
    if comm != 18 or tot != 42 or not vec_anti: ok = False
    if sab: notes[0] = notes[0] + ' (sabotaged run: the dot square used for e_a^2 at n = 2)'
    return ok, ('on labels: e_a^2 = |a|^2 exactly for the generators with eps = +1 (the dot square a.a = |a| is linear: a remark); disjoint blades '
                'anticommute exactly when |a||b| is odd; 0 is the only label with a.b = 0 for all b (n <= 5, every eps); ' + notes[0]
                + '; generators always anticommute'), notes[0]

def chk25(sab):
    vs = [(x, y) for x in range(-4, 5) for y in range(-4, 5)]
    lin = sq = both = 0; bad = 0
    for u in vs:
        for v in vs:
            s = (u[0] + v[0], u[1] + v[1])
            a, b, c = u[0] ** 2 + u[1] ** 2, v[0] ** 2 + v[1] ** 2, s[0] ** 2 + s[1] ** 2
            l = (c - a - b) >= 0 and (c - a - b) ** 2 == 4 * a * b                 # sqrt c = sqrt a + sqrt b
            q = (c == a + b)
            if sab: q = (c <= a + b)                                              # sabotage: the triangle inequality in place of Pythagoras
            pcol = (u[0] * v[1] - u[1] * v[0] == 0) and (u[0] * v[0] + u[1] * v[1] >= 0)
            orth = u[0] * v[0] + u[1] * v[1] == 0
            if l != pcol or q != orth: bad += 1
            if (l and q) != (a == 0 or b == 0): bad += 1
            lin += l; sq += q; both += l and q
    return bad == 0, (f'{len(vs) ** 2} ordered pairs of integer vectors in [-4,4]^2: |u+v| = |u| + |v| on {lin} (exactly the positively collinear pairs, zero '
                      f'vectors included), |u+v|^2 = |u|^2 + |v|^2 on {sq} (exactly the orthogonal pairs), both on {both} (exactly when u = 0 or v = 0)'), f'violations {bad}'

CHECKS = [('bd·mja·21', chk21), ('bd·mja·22', chk22), ('bd·mja·23', chk23), ('bd·mja·24', chk24), ('bd·mja·25', chk25)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            ok, _, seen = f(True)
            print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  broken input sees: ' + seen)
            missed += ok
        print('\nALL CAUGHT' if not missed else f'\n{missed} MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS:
        ok, text, _ = f(False)
        row(cid, ok, text)
    verdict()
