#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjg_topology.py: which 'algebraic topology' the label category carries: the nerve of B_n as the triangulated cube, the proper part as a
sphere, the cube complex with the Koszul (bit-rule) signs, the A-space of arXiv:2403.19689 (v3) (points and arcs) against the nerve, the area
cochain of the planar vectors (Def. 5) and the shoelace identity, the bit-rule sign on the nerve, and the Z_4 forms (Pin^- structures) that
an additive weight induces.

    python3 selfcheck/bridges/mjg_topology.py              one line per check, ids bd·mjg·22 .. bd·mjg·28; exit 1 on any FAIL
    python3 selfcheck/bridges/mjg_topology.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Standard library plus numpy (numpy only for float barycentric coordinates in bd·mjg·22 and the float part of bd·mjg·26); ranks exact over Q
(Fractions) and over F_2 (integer bitsets); deterministic (seeded generators); about 1 s; runs from any folder, reads and writes no file.

 bd·mjg·22  the order complex (= nerve, non-degenerate simplices) of B_n with the vertex x(S) in {0,1}^n is the standard triangulation of the
            cube [0,1]^n: its n! maximal simplices (maximal chains = permutations) have volume 1/n! each (exact determinants), total 1, and 400
            seeded random points of the cube lie in exactly one closed maximal simplex each (n <= 5); Euler characteristic 1 (n <= 6).
            Sabotage: the vertex of one label moved off the cube.
 bd·mjg·23  the proper part B_n minus {0, [n]}: its order complex has reduced homology Z in degree n - 2 only, over Q and over F_2 (a sphere
            S^(n-2), n = 2..5), and its reduced Euler characteristic equals the Moebius number mu(0, [n]) = (-1)^n (Hall).
            Sabotage: one atom {0} removed from the proper part.
 bd·mjg·24  the cube complex: cells = arrows S -> T, dimension |T \\ S|, boundary d[S,T] = sum_(i in T\\S) s({i}, T\\S\\{i}) ([S+i, T] - [S, T-i])
            with the bit-rule sign s (the Jordan-Wigner sign of theorem T6 of the Atlas); d^2 = 0; homology Z in degree 0 only (the cube), and Z in degrees 0 and
            n - 1 without the top cell 0 -> [n] (the sphere S^(n-1)), over Q and F_2 (n <= 5); Euler characteristic sum (-1)^|T\\S| = 1.
            Sabotage: the sign dropped (d^2 != 0).
 bd·mjg·25  the A-space as a space (objects = points, one arc per non-identity arrow, nothing filled) is a graph with b_1 = #arrows - #objects
            + #components: 3^n - 2^(n+1) + 1 for B_n (0, 2, 12, 50 for n = 1..4); the nerve fills one triangle per composable pair and has b_1 = 0
            for B_n; both have b_1 = 1 for two parallel arrows and for the free category on the square graph; the one-object category Z_2 (a
            loop) has graph b_1 = 1 and nerve H_1 = Z/2 (b_1 = 0 over Q, 1 over F_2) and nerve H_2 = F_2 over F_2: computed from the normalised
            nerve. Sabotage: the nerve of B_n without its 2-simplices (the input complex changed, its Betti numbers computed).
 bd·mjg·26  the area cochain A(f, g) = D(f) ^ D(g) on composable pairs is a 2-cocycle and equals d beta with beta(f) = P(dom f) ^ P(cod f) (the
            shoelace formula: A(f, g) = twice the signed area of the triangle P(S), P(T), P(U)), exactly over Q for seeded rational P on B_n
            (n <= 4); with the vectors F(f) = ||f|| D(f)/|D(f)| (norm = weight) the cochain F(f) ^ F(g) is not a cocycle on k of M composable
            triples (Petrie view of B_4). Sabotage: beta with the opposite orientation.
 bd·mjg·27  the bit-rule sign on composable pairs, sigma(f, g) = s(T\\S, U\\T), is the same for every eps in {+1,-1,0}^n (disjoint labels), is a
            2-cocycle on the nerve of B_n and the coboundary of c(S -> T) = s(S, T\\S) (n <= 5); H^2 of the nerve of B_n over F_2 is 0 (n <= 3);
            on the label group (one object, xor) the bit-rule sign is a 2-cocycle that is not a coboundary for n >= 2 (s(e1, e2) != s(e2, e1))
            and H^2(Z_2^n; F_2) has dimension 1, 3, 6 = n(n+1)/2 (bar complex, n = 1, 2, 3). Sabotage: a seeded random sign table.
 bd·mjg·28  an integer weight additive on disjoint labels, q(a) = sum_(i in a) w_i, reduced mod 4, is a Z_4 refinement of the dot product
            (q(a xor b) = q(a) + q(b) + 2|a and b| mod 4 for all a, b) iff every atom weight w_i is odd; then q = w_eps = pi + 2Q of the bit rule
            with eps_i = (-1)^((w_i - 1)/2), and the Gauss sum is (1+i)^p (1-i)^q: Brown invariant p - q mod 8; the popcount gives Cl(n,0) and
            n mod 8 (n <= 6, 100 seeded weight vectors per n; that the Brown invariant is then p - q mod 8 is read off the Gauss sum); control: q(x) = x^T M x mod 4 for 200 seeded integer symmetric M is additive on
            disjoint pairs exactly when every off-diagonal entry of M is even. Sabotage: one even atom weight declared a refinement.
"""
import sys, math, itertools, random
from fractions import Fraction as Fr
import numpy as np

SAB = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if SAB: print('  sabotaged input, what the check sees: ' + text)
    else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def rank_Q(cols_dict_list, nrows):
    """rank of a sparse matrix given as a list of columns {row: value}"""
    rows = {}
    M = [dict(c) for c in cols_dict_list]
    rk = 0; pivots = {}
    for col in M:
        col = {k: Fr(v) for k, v in col.items() if v}
        while col:
            r = min(col)
            if r in pivots:
                pv = pivots[r]; f = col[r] / pv[r]
                for k, v in pv.items():
                    nv = col.get(k, 0) - f * v
                    if nv: col[k] = nv
                    else: col.pop(k, None)
            else:
                pivots[r] = col; rk += 1; break
    return rk
def rank_F2(cols_dict_list):
    piv = {}; rk = 0
    for col in cols_dict_list:
        x = 0
        for k, v in col.items():
            if v % 2: x ^= 1 << k
        while x:
            h = x.bit_length() - 1
            if h in piv: x ^= piv[h]
            else: piv[h] = x; rk += 1; break
    return rk
def chains(elems, less, maxlen=None):
    """all strict chains (as tuples, increasing) of a finite poset"""
    out = [[(e,) for e in elems]]
    while out[-1] and (maxlen is None or len(out) < maxlen):
        nxt = [c + (e,) for c in out[-1] for e in elems if less(c[-1], e)]
        if not nxt: break
        out.append(nxt)
    return out
def betti_complex(simp):
    """simp[k] = list of k-simplices (tuples); returns reduced Betti numbers over Q and F_2"""
    idx = [{s: i for i, s in enumerate(L)} for L in simp]
    def bd(k):            # columns: k-simplices -> (k-1)-simplices; k = 0: augmentation
        cols = []
        for s in simp[k]:
            if k == 0: cols.append({0: 1}); continue
            col = {}
            for j in range(len(s)):
                f = s[:j] + s[j + 1:]; r = idx[k - 1][f]; col[r] = col.get(r, 0) + (-1) ** j
            cols.append(col)
        return cols
    K = len(simp); rq = [rank_Q(bd(k), 0) for k in range(K)]; r2 = [rank_F2(bd(k)) for k in range(K)]
    bq = [len(simp[k]) - rq[k] - (rq[k + 1] if k + 1 < K else 0) for k in range(K)]
    b2 = [len(simp[k]) - r2[k] - (r2[k + 1] if k + 1 < K else 0) for k in range(K)]
    return bq, b2

# ------------------------------------------------------------------------------------------------------------------------------------
def check22(sab):
    ok = True; info = []
    rng = np.random.default_rng(22)
    for n in range(1, 6):
        X = {a: np.array([(a >> i) & 1 for i in range(n)], dtype=float) for a in range(1 << n)}
        if sab and n >= 2: X[1] = X[1] + np.array([0.3] + [0.0] * (n - 1))
        simplices = []
        for perm in itertools.permutations(range(n)):
            S = 0; vs = [0]
            for i in perm: S |= 1 << i; vs.append(S)
            simplices.append(vs)
        vols = []
        for vs in simplices:
            M = [[Fr(int(round(v * 10))) / 10 for v in (X[vs[k]] - X[vs[0]])] for k in range(1, n + 1)]
            # exact determinant by elimination
            M = [r[:] for r in M]; det = Fr(1)
            for c in range(n):
                p = next((r for r in range(c, n) if M[r][c] != 0), None)
                if p is None: det = Fr(0); break
                if p != c: M[c], M[p] = M[p], M[c]; det = -det
                det *= M[c][c]
                for r in range(c + 1, n):
                    f = M[r][c] / M[c][c]; M[r] = [a - f * b for a, b in zip(M[r], M[c])]
            vols.append(abs(det) / math.factorial(n))
        tot = sum(vols)
        ok &= all(v == Fr(1, math.factorial(n)) for v in vols) and tot == 1
        cnt_ok = True
        for _ in range(400):
            p = rng.random(n); inside = 0
            for vs in simplices:
                A = np.array([X[v] for v in vs[1:]]) - X[vs[0]]
                lam = np.linalg.solve(A.T, p - X[vs[0]]); bary = np.concatenate([[1 - lam.sum()], lam])
                inside += bool((bary >= -1e-12).all())
            cnt_ok &= inside == 1
        ok &= cnt_ok
        info.append(f'n={n}: {len(simplices)} simplices, volume sum {tot}, points covered once: {cnt_ok}')
    for n in range(1, 7):
        ch = chains(list(range(1 << n)), lambda a, b: a != b and a & ~b == 0)
        chi = sum((-1) ** k * len(L) for k, L in enumerate(ch)); ok &= chi == 1
    return report('bd·mjg·22', ok, 'order complex of B_n on the cube vertices: ' + '; '.join(info) + '; Euler characteristic 1 (n <= 6)')

def check23(sab):
    ok = True; info = []
    for n in range(2, 6):
        full = (1 << n) - 1
        elems = [a for a in range(1, full)]
        if sab and n == 3: elems.remove(1)
        ch = chains(elems, lambda a, b: a != b and a & ~b == 0)
        bq, b2 = betti_complex(ch)
        want = [1 if k == n - 2 else 0 for k in range(len(ch))]
        def mob(x, y):
            if x == y: return 1
            return -sum(mob(x, z) for z in range(1 << n) if x & ~z == 0 and z & ~y == 0 and z != y)
        m = mob(0, full)
        chi_red = -1 + sum((-1) ** k * len(L) for k, L in enumerate(ch))
        ok &= bq == want and b2 == want and m == (-1) ** n and chi_red == m
        info.append(f'n={n}: reduced Betti (Q) {bq}, (F_2) {b2}, mu = {m}, reduced chi = {chi_red}')
    return report('bd·mjg·23', ok, 'proper part of B_n: ' + '; '.join(info) + ' (a sphere S^(n-2))')

def check24(sab):
    ok = True; info = []
    for n in range(1, 6):
        full = (1 << n) - 1
        cells = [[(S, T) for T in range(1 << n) for S in range(1 << n) if S & ~T == 0 and pc(T & ~S) == k] for k in range(n + 1)]
        idx = [{c: i for i, c in enumerate(L)} for L in cells]
        def bd(k, drop_top=False):
            cols = []
            for S, T in cells[k]:
                A = T & ~S; col = {}
                for i in range(n):
                    if A >> i & 1:
                        s = 1 if sab else sgn(1 << i, A & ~(1 << i), (1,) * n)
                        for c, sg in (((S | 1 << i, T), 1), ((S, T & ~(1 << i)), -1)):
                            r = idx[k - 1][c]; col[r] = col.get(r, 0) + s * sg
                cols.append(col)
            return cols
        d2zero = True
        for k in range(2, n + 1):
            B1 = bd(k - 1); B2 = bd(k)
            for col in B2:
                acc = {}
                for r, v in col.items():
                    for rr, vv in B1[r].items(): acc[rr] = acc.get(rr, 0) + v * vv
                d2zero &= all(v == 0 for v in acc.values())
        def betti(drop_top):
            sizes = [len(L) for L in cells]
            if drop_top: sizes[n] -= 1
            rq = [0] + [rank_Q(bd(k) if not (drop_top and k == n) else [], 0) for k in range(1, n + 1)]
            r2 = [0] + [rank_F2(bd(k)) if not (drop_top and k == n) else 0 for k in range(1, n + 1)]
            bq = [sizes[k] - rq[k] - (rq[k + 1] if k < n else 0) for k in range(n + 1)]
            b2 = [sizes[k] - r2[k] - (r2[k + 1] if k < n else 0) for k in range(n + 1)]
            return bq, b2
        bq, b2 = betti(False); bqs, b2s = betti(True)
        sph = [1 if k in (0, n - 1) else 0 for k in range(n + 1)]
        if n == 1: sph = [2, 0]
        chi = sum((-1) ** k * len(L) for k, L in enumerate(cells))
        ok &= d2zero and bq == b2 == [1] + [0] * n and bqs == b2s == sph and chi == 1
        info.append(f'n={n}: d^2 = 0 {d2zero}, cube Betti {bq}, boundary Betti {bqs}')
    return report('bd·mjg·24', ok, 'cube complex on the arrows with the bit-rule sign: ' + '; '.join(info))

def nerve_betti(objs, mors, comp, maxk=3, unfilled=False):
    """normalised nerve of a finite category: mors = {name: (dom, cod)} non-identity morphisms; comp[(g, f)] = g o f name or None (identity);
    unfilled: no simplices above dimension 1 (the graph of the category)"""
    simp = [[(o,) for o in objs]]
    simp.append([(f,) for f in mors])
    for k in range(2, maxk + 1):
        simp.append([] if unfilled else [s + (g,) for s in simp[k - 1] for g in mors if mors[g][0] == mors[s[-1]][1]])
    idx = [{s: i for i, s in enumerate(L)} for L in simp]
    def bd(k):
        cols = []
        for s in simp[k]:
            col = {}
            if k == 1:
                f = s[0]; col[idx[0][(mors[f][1],)]] = col.get(idx[0][(mors[f][1],)], 0) + 1; col[idx[0][(mors[f][0],)]] = col.get(idx[0][(mors[f][0],)], 0) - 1
            else:
                faces = [(s[1:], 1)]
                for i in range(1, k):
                    c = comp[(s[i], s[i - 1])]
                    if c is not None: faces.append((s[:i - 1] + (c,) + s[i + 1:], (-1) ** i))
                faces.append((s[:-1], (-1) ** k))
                for f, sg in faces:
                    r = idx[k - 1][f]; col[r] = col.get(r, 0) + sg
            cols.append({r: v for r, v in col.items() if v})
        return cols
    rq = [0] + [rank_Q(bd(k), 0) for k in range(1, maxk + 1)]
    r2 = [0] + [rank_F2(bd(k)) for k in range(1, maxk + 1)]
    bq = [len(simp[k]) - rq[k] - (rq[k + 1] if k < maxk else 0) for k in range(maxk)]
    b2 = [len(simp[k]) - r2[k] - (r2[k + 1] if k < maxk else 0) for k in range(maxk)]
    return bq, b2

def check25(sab):
    ok = True; info = []
    def poset_cat(n):
        objs = list(range(1 << n)); mors = {(S, T): (S, T) for T in objs for S in objs if S & ~T == 0 and S != T}
        comp = {}
        for g in mors:
            for f in mors:
                if f[1] == g[0]: comp[(g, f)] = (f[0], g[1])
        return objs, mors, comp
    for n in range(1, 5):
        objs, mors, comp = poset_cat(n)
        graph_b1 = len(mors) - len(objs) + 1
        bq, b2 = nerve_betti(objs, mors, comp, maxk=3 if n <= 3 else 2, unfilled=sab)   # sabotage: the nerve of B_n without its 2-simplices
        ok &= graph_b1 == 3 ** n - 2 ** (n + 1) + 1 and bq[1] == 0
        info.append(f'B_{n}: graph b1 {graph_b1}, nerve b1 {bq[1]}')
    # two parallel arrows
    objs = ['a', 'b']; mors = {'f': ('a', 'b'), 'g': ('a', 'b')}; comp = {}
    bq, b2 = nerve_betti(objs, mors, comp, maxk=2); ok &= bq[1] == 1; info.append(f'parallel pair: graph b1 1, nerve b1 {bq[1]}')
    # free square
    objs = ['A', 'X', 'Y', 'B']; mors = {'f': ('A', 'X'), 'g': ('X', 'B'), 'h': ('A', 'Y'), 'k': ('Y', 'B'), 'gf': ('A', 'B'), 'kh': ('A', 'B')}
    comp = {('g', 'f'): 'gf', ('k', 'h'): 'kh'}
    bq, b2 = nerve_betti(objs, mors, comp, maxk=3); gb = len(mors) - len(objs) + 1
    ok &= bq[1] == 1 and gb == 3; info.append(f'free square: graph b1 {gb}, nerve b1 {bq[1]}')
    # commutative square = B_2 already; the group Z_2 (one object, g o g = id)
    objs = ['*']; mors = {'g': ('*', '*')}; comp = {('g', 'g'): None}
    bq, b2 = nerve_betti(objs, mors, comp, maxk=4)
    ok &= bq[1] == 0 and b2[1] == 1 and b2[2] == 1
    info.append(f'Z_2 (a loop): graph b1 1, nerve Betti over Q {bq}, over F_2 {b2}')
    return report('bd·mjg·25', ok, 'A-space graph against the nerve: ' + '; '.join(info))

def check26(sab):
    ok = True; info = []
    rs = random.Random(26)
    def det(u, v): return u[0] * v[1] - u[1] * v[0]
    for n in range(2, 5):
        for trial in range(5):
            P = {a: (Fr(rs.randint(-20, 20), rs.randint(1, 5)), Fr(rs.randint(-20, 20), rs.randint(1, 5))) for a in range(1 << n)}
            D = lambda S, T: (P[T][0] - P[S][0], P[T][1] - P[S][1])
            beta = (lambda S, T: det(P[T], P[S])) if sab else (lambda S, T: det(P[S], P[T]))
            A = lambda S, T, U: det(D(S, T), D(T, U))
            prs = [(S, T, U) for U in range(1 << n) for T in range(1 << n) if T & ~U == 0 and T != U for S in range(1 << n) if S & ~T == 0 and S != T]
            for S, T, U in prs:
                ok &= A(S, T, U) == beta(S, T) + beta(T, U) - beta(S, U)
                area2 = det(D(S, T), D(S, U)); ok &= area2 == A(S, T, U)
                for V in range(1 << n):
                    if U & ~V == 0 and U != V:
                        ok &= A(T, U, V) - A(S, U, V) + A(S, T, V) - A(S, T, U) == 0
        info.append(f'n={n}: {len(prs)} pairs')
    # F-version on the Petrie view of B_4
    n = 4; cols = np.array([[math.cos(math.pi * i / n), math.sin(math.pi * i / n)] for i in range(n)])
    Pf = {a: cols[[i for i in range(n) if a >> i & 1]].sum(axis=0) if a else np.zeros(2) for a in range(1 << n)}
    def F(S, T):
        d = Pf[T] - Pf[S]; return pc(T & ~S) * d / np.linalg.norm(d)
    AF = lambda S, T, U: float(det(F(S, T), F(T, U)))
    bad = tot = 0
    for U in range(1 << n):
        for T in range(1 << n):
            if T & ~U or T == U: continue
            for S in range(1 << n):
                if S & ~T or S == T: continue
                for V in range(1 << n):
                    if U & ~V == 0 and U != V:
                        tot += 1; bad += abs(AF(T, U, V) - AF(S, U, V) + AF(S, T, V) - AF(S, T, U)) > 1e-9
    ok &= bad > 0
    return report('bd·mjg·26', ok, 'A(f, g) = D(f) ^ D(g) = beta(f) + beta(g) - beta(g o f) with beta(f) = P(dom) ^ P(cod), = twice the triangle area, and dA = 0 on every '
                  'composable triple (exact, 5 seeded rational P per n; ' + ', '.join(info) + f'); F-cochain (norm = weight, Petrie B_4): dA_F != 0 on {bad} of {tot} triples')

def check27(sab):
    ok = True; info = []
    rs = random.Random(27)
    for n in range(1, 6):
        V = range(1 << n)
        prs = [(S, T, U) for U in V for T in V if T & ~U == 0 for S in V if S & ~T == 0]
        sigmas = []
        eps_list = list(itertools.product((1, -1, 0), repeat=n)) if n <= 3 else [(1,) * n, (-1,) * n, tuple([1, -1, 0] * 2)[:n]]
        for eps in eps_list:
            sigmas.append({(S, T, U): sgn(T & ~S, U & ~T, eps) for S, T, U in prs})
        indep = all(s == sigmas[0] for s in sigmas)
        sig = dict(sigmas[0])
        if sab:
            for key in sig: sig[key] = rs.choice((1, -1))
        coc = all(sig[(T, U, W)] * sig[(S, U, W)] * sig[(S, T, W)] * sig[(S, T, U)] == 1
                  for S, T, U in prs for W in V if U & ~W == 0)
        cob = all(sig[(S, T, U)] == sgn(S, T & ~S, (1,) * n) * sgn(T, U & ~T, (1,) * n) * sgn(S, U & ~S, (1,) * n) for S, T, U in prs)
        ok &= indep and coc and cob
        info.append(f'n={n}: eps-independent {indep}, cocycle {coc}, = dc {cob}')
    # H^2 of the nerve of B_n over F_2 (order complex), n <= 3
    h2 = {}
    for n in range(1, 4):
        ch = chains(list(range(1 << n)), lambda a, b: a != b and a & ~b == 0)
        bq, b2 = betti_complex(ch)
        h2[n] = b2[2] if len(b2) > 2 else 0
        ok &= all(b == 0 for b in b2)                   # reduced: contractible
    # the label group: H^2(Z_2^n; F_2) by the bar complex
    hdim = {}
    for n in (1, 2, 3):
        G = 1 << n
        def d1cols():   # columns indexed by c in C^1 basis (functions delta_a), rows = pairs (a,b) -> index a*G+b
            cols = []
            for x in range(G):
                col = {}
                for a in range(G):
                    for b in range(G):
                        v = (b == x) + ((a ^ b) == x) + (a == x)
                        if v % 2: col[a * G + b] = 1
                cols.append(col)
            return cols
        def d2cols():
            cols = []
            for x in range(G * G):
                xa, xb = divmod(x, G); col = {}
                for a in range(G):
                    for b in range(G):
                        for c in range(G):
                            v = ((b, c) == (xa, xb)) + ((a ^ b, c) == (xa, xb)) + ((a, b ^ c) == (xa, xb)) + ((a, b) == (xa, xb))
                            if v % 2: col[(a * G + b) * G + c] = 1
                cols.append(col)
            return cols
        r1 = rank_F2(d1cols()); r2 = rank_F2(d2cols())
        hdim[n] = (G * G - r2) - r1
        ok &= hdim[n] == n * (n + 1) // 2
    # the bit-rule sign on the group is not a coboundary for n >= 2: antisymmetric on e1, e2
    nonsym = sgn(1, 2, (1, 1)) != sgn(2, 1, (1, 1)); ok &= nonsym
    return report('bd·mjg·27', ok, 'bit-rule sign on composable pairs of B_n: ' + '; '.join(info) + f'; H^*(nerve of B_n; F_2) reduced = 0 (n <= 3): True; '
                  f'H^2(Z_2^n; F_2) dims {hdim} (bar complex); s(e1,e2) != s(e2,e1): {nonsym} (the group class is not 0)')

def check28(sab):
    ok = True; info = []
    rs = random.Random(28)
    I4 = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
    for n in range(1, 7):
        vecs = [[1] * n] + [[rs.randint(1, 9) for _ in range(n)] for _ in range(100)]
        if sab: vecs[0] = [2] + [1] * (n - 1)
        for w in vecs:
            q = [sum(w[i] for i in range(n) if a >> i & 1) % 4 for a in range(1 << n)]
            refine = all((q[a ^ b] - q[a] - q[b] - 2 * pc(a & b)) % 4 == 0 for a in range(1 << n) for b in range(1 << n))
            allodd = all(x % 2 for x in w)
            if sab and w is vecs[0]:
                ok &= refine                               # the sabotage claims the even weight gives a refinement
                continue
            ok &= refine == allodd
            if allodd:
                eps = tuple(1 if x % 4 == 1 else -1 for x in w)
                wl = [(pc(a) % 2 + 2 * (1 if sgn(a, a, eps) == -1 else 0)) % 4 for a in range(1 << n)]
                ok &= wl == q
                G = (0, 0)
                for v in q: G = (G[0] + I4[v][0], G[1] + I4[v][1])
                p_ = eps.count(1); q_ = eps.count(-1)
                T = (1, 0)
                for _ in range(p_): T = gmul(T, (1, 1))
                for _ in range(q_): T = gmul(T, (1, -1))
                ok &= G == T                                       # the Brown invariant p - q mod 8 is read off this Gauss sum
        info.append(f'n={n}: popcount -> Cl({n},0), Brown {n % 8}')
    # control: x^T M x mod 4
    good = 0
    for _ in range(200):
        n = rs.randint(2, 5)
        M = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i, n):
                M[i][j] = M[j][i] = rs.randint(0, 3)
        def qM(a): return sum(M[i][j] for i in range(n) for j in range(n) if a >> i & 1 and a >> j & 1) % 4
        add = all((qM(a | b) - qM(a) - qM(b)) % 4 == 0 for a in range(1 << n) for b in range(1 << n) if a & b == 0)
        even_off = all(M[i][j] % 2 == 0 for i in range(n) for j in range(n) if i != j)
        ok &= add == even_off; good += add
    return report('bd·mjg·28', ok, 'atom weights mod 4: a Z_4 refinement of the dot product iff all odd, then = w_eps of the bit rule, Gauss sum (1+i)^p (1-i)^q; '
                  + ', '.join(info) + f'; control x^T M x mod 4: additive on disjoint pairs exactly when M has even off-diagonal ({good} of 200)')

CHECKS = [('bd·mjg·22', check22), ('bd·mjg·23', check23), ('bd·mjg·24', check24), ('bd·mjg·25', check25), ('bd·mjg·26', check26),
          ('bd·mjg·27', check27), ('bd·mjg·28', check28)]

def main():
    if SAB:
        missed = 0
        for cid, fn in CHECKS:
            okk = fn(True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            missed += okk
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        return missed == 0
    for cid, fn in CHECKS: fn(False)
    nfail = sum(1 for _, o in RESULTS if not o)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    return nfail == 0

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
