#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sol_hubbard_cube.py: the Clifford signing of the cube (the pi-flux sector of bd·sol·27) against interactions.

  bd·sol·31  Hubbard model on the 3-cube graph (8 sites, spin 1/2, half filling 4 up + 4 down, Hilbert dimension 4900):
             H = -sum_<ij>,sigma s_ij (c^+_i c_j + h.c.) + U sum n_i_up n_i_dn, for each of the 32 flux sectors of s and U = 0, 2, 4, 8: the
             all-pi sector (the bit-rule signs) has the lowest ground energy, and no other sector reaches it, for every U tested; at U = 0
             its ground energy is twice the free-fermion value -4 sqrt(3) of bd·sol·27 (two spins).

  python3 sol_hubbard_cube.py      one line per check id; exit code 1 on any FAIL
numpy and scipy (sparse matrices and the Lanczos solver scipy.sparse.linalg.eigsh); deterministic; a few seconds."""
import itertools, math, sys
import numpy as np
from scipy.sparse import csr_matrix, kron, identity, diags
from scipy.sparse.linalg import eigsh

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

n = 3; N = 1 << n
E = [(a, a ^ (1 << i)) for a in range(N) for i in range(n) if not (a >> i) & 1]
def tree():
    seen = {0}; t = set(); fr = [0]
    while fr:
        nx = []
        for a in fr:
            for i in range(n):
                b = a ^ (1 << i)
                if b not in seen: seen.add(b); t.add((min(a, b), max(a, b))); nx.append(b)
        fr = nx
    return t
TREE = tree(); FREE = [e for e in E if (min(e), max(e)) not in TREE]
FACES = [(a, i, j) for a in range(N) for i in range(n) for j in range(i + 1, n) if not (a >> i) & 1 and not (a >> j) & 1]
states = [s for s in range(1 << N) if pc(s) == N // 2]; index = {s: k for k, s in enumerate(states)}
def hop_matrix(signs):
    """one-species hopping in the 70-dim 4-particle sector, with Jordan-Wigner signs"""
    rows, cols, vals = [], [], []
    for (a, b), s in signs.items():
        for st in states:
            for i, j in ((a, b), (b, a)):                      # c^+_i c_j
                if (st >> j) & 1 and not (st >> i) & 1:
                    lo, hi = min(i, j), max(i, j)
                    between = pc(st & (((1 << hi) - 1) ^ ((1 << (lo + 1)) - 1)))
                    new = st ^ (1 << j) ^ (1 << i)
                    rows.append(index[new]); cols.append(index[st]); vals.append(-s * (-1) ** between)
    return csr_matrix((vals, (rows, cols)), shape=(len(states), len(states)))
def double_occ():
    d = np.zeros(len(states) ** 2)
    for u, su in enumerate(states):
        for v, sv in enumerate(states):
            d[u * len(states) + v] = pc(su & sv)
    return diags(d)
DOCC = double_occ(); I1 = identity(len(states), format='csr')
def sector_signs(bits):
    s = {e: 1 for e in E}
    for e, b in zip(FREE, bits): s[e] = b
    return s
def all_pi(s):
    def sg(x, y): return s.get((x, y), s.get((y, x)))
    return all(sg(a, a ^ (1 << i)) * sg(a ^ (1 << i), a ^ (1 << i) ^ (1 << j)) * sg(a ^ (1 << i) ^ (1 << j), a ^ (1 << j)) * sg(a ^ (1 << j), a) == -1 for a, i, j in FACES)
def free_half(s):
    A = np.zeros((N, N))
    for (a, b), v in s.items(): A[a, b] = A[b, a] = v
    return -0.5 * np.sum(np.abs(np.linalg.eigvalsh(A)))
def main():
    ok = True; lines = []
    sectors = [sector_signs(bits) for bits in itertools.product((1, -1), repeat=len(FREE))]
    for U in (0.0, 2.0, 4.0, 8.0):
        res = []
        for s in sectors:
            h = hop_matrix(s)
            H = kron(h, I1) + kron(I1, h) + U * DOCC
            e0 = eigsh(H.tocsc(), k=1, which='SA', tol=1e-10)[0][0]
            res.append((e0, all_pi(s), free_half(s)))
        res.sort(key=lambda x: x[0])
        best, second = res[0], next(r for r in res if r[0] > res[0][0] + 1e-8)
        nbest = sum(1 for r in res if abs(r[0] - best[0]) < 1e-8)
        ok &= best[1] and nbest == 1
        if U == 0.0:
            ok &= abs(best[0] - 2 * (-4 * math.sqrt(3))) < 1e-8
        lines.append(f'U={U:g}: min E0 = {best[0]:.6f} in the all-pi sector (unique: {nbest == 1}), next sector {second[0]:.6f}')
    row('bd·sol·31', ok, 'Hubbard on the 3-cube, half filling, 32 flux sectors: ' + '; '.join(lines))

if __name__ == '__main__':
    main()
    finish()
