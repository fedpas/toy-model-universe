#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""geo_cartan.py: Klein pairs of the projective step, the Klein form of screws, the Euler-Arnold flow, and the Koszul / ABS operator on the labels.

  python3 selfcheck/bridges/geo_cartan.py      one line per check, ids bd·geo·13 .. bd·geo·16; exit 1 on any FAIL

Standard library plus numpy (numpy only for the signatures of exact rational matrices, by eigenvalues with a relative tolerance of 1e-9, and for
integer matrix products), deterministic (fixed seeds), under 1 s; runs from any folder, reads and writes no file.
 bd·geo·13  Klein pairs: base Cl(0,d) (space) or Cl(1,d-1) (Lorentz), d = 2..5, extra generator e_n of square s in {-1, 0, +1}; g = bivectors,
            h = base bivectors, m = span B_an: [h, m] acts on m as h acts on the base vectors and [B_an, B_bn] = -2s B_ab, so (g, h) is a symmetric
            pair for every s; the involution is the sandwich by e_n (the mirror in e_n) for s != 0 and no sandwich for s = 0 (e_n X e_n = 0).
 bd·geo·14  the invariant symmetric bilinear forms on the six bivectors of e(3) (Cl(0,3,1) and Cl(3,0,1)), so(4) and so(1,3) form a 2-dimensional
            space in each case; for e(3) the scalar pairing <XY>_0 has a 3-dimensional radical and the top-blade pairing has signature (3,3):
            the Klein form of screw theory is the top-label Frobenius pairing restricted to bivectors.
 bd·geo·15  Euler-Arnold: for P = A[B] with A symmetric for the non-degenerate invariant form, the flow dP/dt = [P, B] has zero time derivative of
            both invariant quadratics of P and of the energy (exact, seeded rational data, four algebras). This holds for every Lie-Poisson flow
            with a symmetric A and does not fix a sign convention.
 bd·geo·16  on the 2^n labels (n = 1..7) D_eps = sum_i L_{e_i} is wedge by v = e_1 + .. + e_n plus eps-weighted contraction, both of square 0, and
            D_eps^2 = (p - q) I; for eps = +1 the contraction is the augmented boundary of the full simplex and D = d + d^T has Laplacian n I;
            for eps = 0, D^2 = 0; D is odd and the super-dimension is 0; sigma(v) = v ^ + v _| squares to |v|^2 I for seeded integer v.
"""
import itertools, random, sys
from fractions import Fraction as Fr
import numpy as np

ROWS = []
def row(cid, text, ok):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return ok
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

def pc(a): return bin(a).count('1')
class Cl:
    def __init__(self, eps): self.eps = list(eps); self.n = len(eps)
    def sgn(self, a, b):
        s = 1
        for i in range(self.n):
            if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
        for i in range(self.n):
            if a >> i & 1 and b >> i & 1: s *= self.eps[i]
        return s
    def mul(self, x, y):
        out = {}
        for a, u in x.items():
            for b, v in y.items():
                s = self.sgn(a, b)
                if s: out[a ^ b] = out.get(a ^ b, 0) + s * u * v
        return {k: v for k, v in out.items() if v != 0}
def add(x, y, k=1):
    out = dict(x)
    for a, v in y.items(): out[a] = out.get(a, 0) + k * v
    return {a: v for a, v in out.items() if v != 0}
def scal(x, k): return {a: k * v for a, v in x.items() if k * v != 0}
def comm(cl, x, y): return add(cl.mul(x, y), cl.mul(y, x), -1)
def B(i, j): return {(1 << i) | (1 << j): Fr(1)}
def sig_counts(M):
    ev = np.linalg.eigvalsh(np.array([[float(v) for v in r] for r in M]))
    tol = 1e-9 * max(1.0, max(abs(ev)))
    return (int(sum(ev > tol)), int(sum(ev < -tol)), int(sum(abs(ev) <= tol)))

# ---------------------------------------------------------------- 13. Klein pairs and the symmetric involution
def c13():
    ok = True; seen = []
    for base in ('space', 'lorentz'):
        for d in range(2, 6):
            for s in (-1, 0, 1):
                eps = ([-1] * d) if base == 'space' else ([1] + [-1] * (d - 1))
                cl = Cl(eps + [s]); nn = d
                h = {(i, j): B(i, j) for i, j in itertools.combinations(range(d), 2)}
                m = {a: B(a, nn) for a in range(d)}
                def lab(x): return list(x.keys())
                # [h, m] in m with the vector representation: [B_ij, B_an] equals the image of [B_ij, e_a] under e_c -> B_cn
                for (i, j), X in h.items():
                    for a, Y in m.items():
                        Z = comm(cl, X, Y)
                        V = comm(cl, X, {1 << a: Fr(1)})                       # vector representation of the base (grade 1)
                        img = {}
                        for lb, v in V.items():
                            c = lb.bit_length() - 1
                            img = add(img, scal(cl.mul({1 << c: Fr(1)}, {1 << nn: Fr(1)}), v))
                        ok &= Z == img
                for a, b in itertools.combinations(range(d), 2):
                    Z = comm(cl, m[a], m[b])
                    ok &= Z == scal(cl.mul({1 << a: Fr(1)}, {1 << b: Fr(1)}), -2 * s)
                # theta automorphism: brackets of h with h stay in h, of h with m in m, of m with m in h (checked above) -> theta is an automorphism
                ok &= all(all(pc(l) == 2 and not (l >> nn & 1) for l in comm(cl, X, Y)) for X in h.values() for Y in h.values())
                # theta as a sandwich by e_n: e_n X e_n^{-1} for s != 0
                en = {1 << nn: Fr(1)}
                if s != 0:
                    inv = scal(en, Fr(1, s))
                    ok &= all(cl.mul(cl.mul(en, X), inv) == X for X in h.values())
                    ok &= all(cl.mul(cl.mul(en, Y), inv) == scal(Y, -1) for Y in m.values())
                else:
                    ok &= cl.mul(en, en) == {} and all(cl.mul(cl.mul(en, X), en) == {} for X in list(h.values()) + list(m.values()))
                seen.append((base, d, s))
    row('bd·geo·13', 'for a space base Cl(0,d) and a Lorentz base Cl(1,d-1), d = 2..5, and s = -1, 0, +1: [h, m] acts on m = span B_an exactly as h acts on the base '
        'vectors (B_an <-> e_a), [B_an, B_bn] = -2s B_ab, so (g, h) is the Klein pair of the sphere / Euclid / hyperbolic space and of de Sitter / Minkowski / '
        'anti-de Sitter, symmetric in all three cases; the involution is the mirror in e_n (x -> e_n x e_n^-1) for s != 0 and is no sandwich for s = 0 (e_n X e_n = 0)', ok)

# ---------------------------------------------------------------- 14. invariant forms: the Klein form is the top-blade pairing
def invariant_forms(eps):
    cl = Cl(eps); n = len(eps)
    basis = [B(i, j) for i, j in itertools.combinations(range(n), 2)]
    labs = [next(iter(b)) for b in basis]; k = len(basis)
    # structure constants
    C = [[None] * k for _ in range(k)]
    for x in range(k):
        for y in range(k):
            Z = comm(cl, basis[x], basis[y])
            C[x][y] = [Z.get(labs[z], Fr(0)) for z in range(k)]
    # unknown symmetric M (k(k+1)/2 entries): M([X,Y],Z) + M(Y,[X,Z]) = 0 for all X, Y, Z
    pairs = [(i, j) for i in range(k) for j in range(i, k)]
    pidx = {p: t for t, p in enumerate(pairs)}
    def var(i, j): return pidx[(min(i, j), max(i, j))]
    rows = []
    for x in range(k):
        for y in range(k):
            for z in range(k):
                r = [Fr(0)] * len(pairs)
                for w in range(k):
                    if C[x][y][w]: r[var(w, z)] += C[x][y][w]
                    if C[x][z][w]: r[var(y, w)] += C[x][z][w]
                if any(r): rows.append(r)
    # nullspace dimension by exact elimination
    Mx = [r[:] for r in rows]; piv_cols = []; rk = 0
    for col in range(len(pairs)):
        piv = next((i for i in range(rk, len(Mx)) if Mx[i][col] != 0), None)
        if piv is None: continue
        Mx[rk], Mx[piv] = Mx[piv], Mx[rk]
        pv = Mx[rk][col]; Mx[rk] = [v / pv for v in Mx[rk]]
        for i in range(len(Mx)):
            if i != rk and Mx[i][col] != 0:
                f = Mx[i][col]; Mx[i] = [a - f * b for a, b in zip(Mx[i], Mx[rk])]
        piv_cols.append(col); rk += 1
    dim = len(pairs) - rk
    # the two candidate forms
    def form(part):
        G = [[Fr(0)] * k for _ in range(k)]
        for x in range(k):
            for y in range(k):
                P = cl.mul(basis[x], basis[y])
                G[x][y] = P.get(0, Fr(0)) if part == 0 else P.get((1 << n) - 1, Fr(0))
        return G
    def is_inv(G):
        for x in range(k):
            for y in range(k):
                for z in range(k):
                    if sum(C[x][y][w] * G[w][z] + C[x][z][w] * G[y][w] for w in range(k)) != 0: return False
        return True
    G0, G4 = form(0), form(4)
    return dim, is_inv(G0), is_inv(G4), sig_counts(G0), sig_counts(G4), G0, G4, cl, basis
def c14():
    out = {}
    ok = True
    for name, eps in (('e(3) Cl(0,3,1)', [-1, -1, -1, 0]), ('e(3) Cl(3,0,1)', [1, 1, 1, 0]), ('so(4) Cl(0,4)', [-1] * 4), ('so(1,3) Cl(1,3)', [1, -1, -1, -1])):
        dim, i0, i4, s0, s4, *_ = invariant_forms(eps)
        out[name] = (dim, s0, s4)
        ok &= dim == 2 and i0 and i4
    ok &= out['e(3) Cl(0,3,1)'][1][2] == 3 and out['e(3) Cl(0,3,1)'][2] == (3, 3, 0) and out['e(3) Cl(3,0,1)'][2] == (3, 3, 0)
    row('bd·geo·14', 'invariant symmetric forms on the six bivectors (dimension, signature of <XY>_0, signature of <XY>_top): ' + str(out) +
        ': for the motor algebra e(3) the scalar pairing has a 3-dimensional radical (the null-bit labels, T3 F4) and the top-blade (Frobenius, "join") pairing is '
        'the non-degenerate Klein form of screw theory, signature (3,3); FRQ-002\'s energy pairing is that form', ok)

# ---------------------------------------------------------------- 15. Euler-Arnold flow conserves the invariant forms
def c15():
    rng = random.Random(15); ok = True
    for eps in ([-1, -1, -1, 0], [1, 1, 1, 0], [-1, -1, -1, -1], [-1, -1, -1, 1]):
        dim, i0, i4, s0, s4, G0, G4, cl, basis = invariant_forms(eps)
        k = len(basis); labs = [next(iter(b)) for b in basis]
        def vec(x): return [x.get(l, Fr(0)) for l in labs]
        def mv(c): return {labs[i]: c[i] for i in range(k) if c[i] != 0}
        def bil(G, a, b): return sum(a[i] * G[i][j] * b[j] for i in range(k) for j in range(k))
        # pick the non-degenerate invariant form as the pairing (top blade for e(3), scalar otherwise)
        G = G4 if 0 in eps else G0
        for _ in range(5):
            # inertia: A = G^{-1} S with S symmetric positive: then <X, A Y>_G = X^T S Y is symmetric
            S = [[Fr(0)] * k for _ in range(k)]
            for i in range(k):
                for j in range(i, k):
                    v = Fr(rng.randint(-3, 3), rng.randint(1, 3)) if i != j else Fr(rng.randint(5, 9))
                    S[i][j] = S[j][i] = v
            Bc = [Fr(rng.randint(-4, 4)) for _ in range(k)]
            # P = G^{-1} S B, solve G P = S B exactly
            rhs = [sum(S[i][j] * Bc[j] for j in range(k)) for i in range(k)]
            Mx = [G[i][:] + [rhs[i]] for i in range(k)]
            for col in range(k):
                piv = next(i for i in range(col, k) if Mx[i][col] != 0)
                Mx[col], Mx[piv] = Mx[piv], Mx[col]
                pv = Mx[col][col]; Mx[col] = [v / pv for v in Mx[col]]
                for i in range(k):
                    if i != col and Mx[i][col] != 0:
                        f = Mx[i][col]; Mx[i] = [a - f * b for a, b in zip(Mx[i], Mx[col])]
            Pc = [Mx[i][k] for i in range(k)]
            Pdot = vec(comm(cl, mv(Pc), mv(Bc)))                  # coadjoint flow dP/dt = [P, B]
            # d/dt of the two invariant quadratics of P and of the energy 1/2 <B, P>_G with B fixed by P = A B (dB = A^{-1} dP):
            d0 = 2 * bil(G0, Pc, Pdot); d4 = 2 * bil(G4, Pc, Pdot)
            dE = bil(G, Bc, Pdot)                                   # d/dt (1/2) <B, A B> = <B, A dB> = <B, dP>
            ok &= d0 == 0 and d4 == 0 and dE == 0
    row('bd·geo·15', 'Euler-Arnold flow dP/dt = [P, B], P = A[B] with A symmetric for the non-degenerate invariant form (Klein form for e(3) in both PGA conventions, '
        'Killing form for so(4), so(3,1)): both invariant quadratics of P and the energy <B, A B>/2 have zero time derivative exactly (seeded rational data). '
        'These conservation laws hold for every Lie-Poisson flow with a symmetric A and do not fix the sign of the flow', ok)

# ---------------------------------------------------------------- 16. Koszul / ABS on the label space
def c16():
    ok = True; info = []
    for n in range(1, 8):
        N = 1 << n
        for eps in ([1] * n, [-1] * n, [0] * n, [1] * (n // 2) + [-1] * (n - n // 2)):
            cl = Cl(eps)
            D = np.zeros((N, N), dtype=np.int64)
            for i in range(n):
                for a in range(N):
                    s = cl.sgn(1 << i, a)
                    if s: D[(1 << i) ^ a, a] += s
            p = eps.count(1); q = eps.count(-1)
            ok &= np.array_equal(D @ D, (p - q) * np.eye(N, dtype=np.int64))
            # wedge part (raises popcount) and contraction part (lowers)
            up = np.zeros_like(D); dn = np.zeros_like(D)
            for a in range(N):
                for b in range(N):
                    if D[b, a]:
                        if pc(b) > pc(a): up[b, a] = D[b, a]
                        else: dn[b, a] = D[b, a]
            ok &= np.array_equal(up @ up, 0 * up) and np.array_equal(dn @ dn, 0 * dn)
            if all(e == 1 for e in eps):
                ok &= np.array_equal(dn, up.T)                     # d = boundary, D = d + d^T
                ok &= np.array_equal(dn @ up + up @ dn, n * np.eye(N, dtype=np.int64))
                # dn is the augmented simplicial boundary: face a -> sum over removed vertex with alternating signs
                for a in range(N):
                    verts = [i for i in range(n) if a >> i & 1]
                    for t, i in enumerate(verts):
                        ok &= abs(dn[a ^ (1 << i), a]) == 1
            if all(e == 0 for e in eps):
                ok &= np.array_equal(dn, 0 * dn) and np.array_equal(D @ D, 0 * D)
            grade_sign = np.diag([(-1) ** pc(a) for a in range(N)])
            ok &= int(np.trace(grade_sign)) == 0                    # str(I) = 0: super-dimension of Lambda
            ok &= np.array_equal(grade_sign @ D, -D @ grade_sign)   # D is odd
        # ABS symbol sigma(v) = v ^ + v _| for random integer v (eps = +1)
        rng = np.random.default_rng(16 + n)
        cl = Cl([1] * n)
        for _ in range(3):
            v = rng.integers(-3, 4, size=n)
            S = np.zeros((N, N), dtype=np.int64)
            for i in range(n):
                for a in range(N):
                    S[(1 << i) ^ a, a] += v[i] * cl.sgn(1 << i, a)
            ok &= np.array_equal(S @ S, int(v @ v) * np.eye(N, dtype=np.int64))
        info.append(n)
    row('bd·geo·16', 'on the 2^n labels (n = 1..7), D_eps = sum_i L_{e_i} splits as wedge by v = e_1 + .. + e_n plus eps-weighted contraction, both square to 0, '
        'D_eps^2 = (p - q) I; for eps = +1 the contraction is the augmented boundary of the full simplex on n vertices and D = d + d^T has Laplacian n I '
        '(the simplex has no reduced homology: T6 (b)); for eps = 0 D is the differential v ^ (D^2 = 0); D is odd and str(I) = 0 (T20 (d)); '
        'sigma(v) = v ^ + v _| squares to |v|^2 for seeded integer v: the spring operator of T19 (4) is the ABS (Koszul) symbol at v = (1,...,1)', ok)

if __name__ == '__main__':
    for f in (c13, c14, c15, c16): f()
    verdict()
