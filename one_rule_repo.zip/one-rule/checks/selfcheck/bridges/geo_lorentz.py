#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""geo_lorentz.py: Lorentzian and causal geometry in the cells: the branch of the horizon, hyperbolicity with null generators, the horizon
algebra as a null little group, totally null planes, the right reference of the Dirac equation, and the spin group of Cl(1,2).

  python3 selfcheck/bridges/geo_lorentz.py      one line per check, ids bd·geo·7 .. bd·geo·12; exit 1 on any FAIL

Standard library only, exact rationals, deterministic (fixed seed), under 1 s; runs from any folder, reads and writes no file.
 bd·geo·7   in the chart ds^2 = T dv^2 + 2c dv dx (time +1), xi = d_v satisfies xi.grad xi = -c (T'/2) xi at T = 0; the chart c = +1 has its
            v = const null lines future-directed outgoing, so it is the retarded chart and its T = 0 surface is the past horizon, where
            xi.grad xi = -kappa xi; the advanced chart c = -1 gives +kappa xi on the future horizon; kappa = T'/2 = 1/6, 1/8, -1/2, 0, 3/10 for the
            five sample horizons.
 bd·geo·8   P = sum eps_i k_i^2 with eps in {+1,-1,0} (s plus, t minus, r null): a hyperbolic direction exists iff s = 1 or t = 1, for every r
            (n <= 6; exact basis witness, integer counter-witnesses for 60 seeded h otherwise); P is strictly hyperbolic iff in addition r = 0.
 bd·geo·9   in Cl(1,n-1) with l = e0 + e1 the C(n-1,2) bivectors of l-perp commute with l, are independent, and have the brackets of the
            bivectors of Cl(0,n-2,1) under l -> the null generator (n = 3..7); l-perp has radical span(l), and m = (e0 - e1)/2 with l.m = 1 lies
            outside l-perp (T7 (3)).
 bd·geo·10  in the non-degenerate Cl(2,2) the plane of u = e1 + f1, v = e2 + f2 is totally null: B = u ^ v has B^2 = 0 and D x = x.B has D^2 = 0;
            a null rotation in Cl(1,3) has D^2 != 0, D^3 = 0; with min(p,q) = 1 two orthogonal null vectors are parallel (n = 4, 5 search).
 bd·geo·11  Cl(1,3), J = gamma2 gamma1: psi0 = m + p gamma0 solves p psi0 = m psi0 gamma0 for five on-shell momenta (two past-directed); a boost
            or rotation L of the observer acts on the left and keeps gamma0 on the right; a change of the right reference (gamma0, J) ->
            (L gamma0 L~, L J L~) is undone by psi -> psi L~ and leaves the current psi gamma0 psi~ = 2(m + p.gamma0) p unchanged; the sign of
            psi psi~ = 2m(m + p.u) is the same for every future unit u: the datum is a time orientation.
 bd·geo·12  the unit even versors of Cl(1,2) have a Lie algebra of dimension 3 with Killing signature (2,1): Spin(1,2) = SL(2,R); the group
            {x in Cl(1,2) : x xbar = 1} has a Lie algebra of grades 1 + 2, dimension 6, the dimension of the even versors of Cl(1,3) = SL(2,C).
"""
import itertools, random, sys
from fractions import Fraction as Fr

ROWS = []
def row(cid, text, ok):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return ok
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

def pc(a): return bin(a).count('1')

class Cl:
    """the bit rule with squares eps (exact)"""
    def __init__(self, eps):
        self.eps = list(eps); self.n = len(eps)
    def sgn(self, a, b):
        s = 1
        for i in range(self.n):
            if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
        for i in range(self.n):
            if a >> i & 1 and b >> i & 1: s *= self.eps[i]
        return s
    def mul(self, x, y):
        out = {}
        for a, u in x.items():
            for b, v in y.items():
                s = self.sgn(a, b)
                if s:
                    out[a ^ b] = out.get(a ^ b, 0) + s * u * v
        return {k: v for k, v in out.items() if v != 0}
    def vec(self, comps): return {1 << i: Fr(c) for i, c in enumerate(comps) if c}
    def blade(self, *idx):
        m = 0
        for i in idx: m |= 1 << i
        # sign of ordered product e_i1 e_i2 ... relative to the sorted blade
        x = {0: Fr(1)}
        for i in idx: x = self.mul(x, {1 << i: Fr(1)})
        return x
def add(x, y, k=1):
    out = dict(x)
    for a, v in y.items(): out[a] = out.get(a, 0) + k * v
    return {a: v for a, v in out.items() if v != 0}
def scal(x, k): return {a: k * v for a, v in x.items() if k * v != 0}
def rev(x): return {a: (v if (pc(a) * (pc(a) - 1) // 2) % 2 == 0 else -v) for a, v in x.items()}
def conj(x): return {a: (v if (pc(a) * (pc(a) + 1) // 2) % 2 == 0 else -v) for a, v in x.items()}
def grade(x, k): return {a: v for a, v in x.items() if pc(a) == k}
def sc(x): return x.get(0, Fr(0))
def comm(cl, x, y): return add(cl.mul(x, y), cl.mul(y, x), -1)

# ---------------------------------------------------------------- 7. surface gravity and the horizon branch
class Rat:
    """rational function value and derivative at a point (dual numbers over Fractions)"""
    def __init__(self, v, d=Fr(0)): self.v = Fr(v); self.d = Fr(d)
    def __add__(self, o): o = o if isinstance(o, Rat) else Rat(o); return Rat(self.v + o.v, self.d + o.d)
    __radd__ = __add__
    def __sub__(self, o): o = o if isinstance(o, Rat) else Rat(o); return Rat(self.v - o.v, self.d - o.d)
    def __rsub__(self, o): return Rat(o) - self
    def __mul__(self, o): o = o if isinstance(o, Rat) else Rat(o); return Rat(self.v * o.v, self.v * o.d + self.d * o.v)
    __rmul__ = __mul__
    def __truediv__(self, o):
        o = o if isinstance(o, Rat) else Rat(o)
        return Rat(self.v / o.v, (self.d * o.v - self.v * o.d) / (o.v * o.v))
    def __rtruediv__(self, o): return Rat(o) / self
    def __pow__(self, k):
        r = Rat(1)
        for _ in range(k): r = r * self
        return r
HORIZONS = [("Schwarzschild r_S=3", lambda x: 1 - 3 / x, Fr(3), Fr(1, 6)),
            ("Reissner-Nordstrom outer", lambda x: (1 - 2 / x) * (1 - 1 / x), Fr(2), Fr(1, 8)),
            ("Reissner-Nordstrom inner", lambda x: (1 - 2 / x) * (1 - 1 / x), Fr(1), Fr(-1, 2)),
            ("extremal", lambda x: (1 - 1 / x) ** 2, Fr(1), Fr(0)),
            ("areal radius x^2", lambda x: (x - 2) * (x + 1) / (x + 3), Fr(2), Fr(3, 10))]
def c7():
    ok = True; out = []
    for name, Tf, xh, kap in HORIZONS:
        Tx = Tf(Rat(xh, 1)); T, dT = Tx.v, Tx.d
        ok &= (T == 0) and (dT / 2 == kap)
        for c in (1, -1):
            # metric in (v, x): g = [[T, c], [c, 0]] (angular part irrelevant for xi = d_v), ginv at T = 0: [[0, 1/c], [1/c, -T/c^2]]
            gi = [[Fr(0), Fr(1, c)], [Fr(1, c), -T]]
            # xi = d_v constant components; (xi.grad xi)^a = Gamma^a_vv = -1/2 g^{ax} dT/dx (g_vv = T(x), g_vx = c constant)
            acc = [-Fr(1, 2) * gi[a][1] * dT for a in range(2)]
            lam = acc[0]                               # acc = lam * xi, xi = (1, 0)
            ok &= acc[1] == 0 and lam == -c * kap
            # branch: with time +1, future-directed causal vectors have positive products with the future timelike d_v (T > 0 outside);
            # along v = const the null direction is +-d_x; g(d_v, d_x) = c, so the future-directed one is c*d_x: outgoing (x grows) for c = +1
            outgoing_along_v_const = (c == 1)
            out.append((name, c, str(lam), 'past horizon (retarded chart)' if outgoing_along_v_const else 'future horizon (advanced chart)'))
    row('bd·geo·7', 'xi = d_v in ds^2 = T dv^2 + 2c dv dx: xi.grad xi = -c (T\'/2) xi at T = 0, kappa = T\'/2 = 1/6, 1/8, -1/2, 0, 3/10 (the five sample horizons); '
        'the chart c = +1 has its v = const null lines future-directed outgoing (g(d_v, d_x) = +1), so it is the retarded chart and its T = 0 surface '
        'is the past (white-hole) horizon, where xi.grad xi = -kappa xi; the advanced chart c = -1 gives +kappa xi on the future horizon. Samples: '
        + '; '.join(f'{a} c={b}: {s} xi, {t}' for a, b, s, t in out[:4]), ok)

# ---------------------------------------------------------------- 8. hyperbolicity with null generators
def c8():
    rng = random.Random(8)
    ok = True; table = {}
    for n in range(1, 7):
        for s in range(n + 1):
            for t in range(n - s + 1):
                r = n - s - t
                eps = [1] * s + [-1] * t + [0] * r
                P = lambda k: sum(e * x * x for e, x in zip(eps, k))
                B = lambda k, h: sum(e * a * b for e, a, b in zip(eps, k, h))
                def hyp_test(h):
                    # B(k,h)^2 - P(h) P(k) >= 0 for all k: a quadratic form in k; check its matrix is PSD exactly via the explicit formula
                    # M = (eps h)(eps h)^T - P(h) diag(eps). For diagonal eps this is PSD iff ... test on a finite certificate instead:
                    Ph = P(h)
                    if Ph == 0: return False
                    for k in itertools.product(range(-2, 3), repeat=n):
                        if B(k, h) ** 2 - Ph * P(k) < 0: return False
                    return True
                # positive claim: a basis direction of the lone sign works (exact for all k: the form is -eps_i sum_{j != i} eps_j k_j^2)
                found = False
                for i in range(n):
                    if eps[i] == 0: continue
                    others = [eps[j] for j in range(n) if j != i]
                    if all(o * eps[i] <= 0 for o in others): found = True
                want = (s == 1 or t == 1)
                ok &= found == want
                # negative claim: for 60 random h with P(h) != 0 an explicit integer witness k exists when not want
                if not want:
                    for _ in range(60):
                        h = [rng.randint(-3, 3) for _ in range(n)]
                        if P(h) == 0: continue
                        ok &= not hyp_test(h)
                # strict: discriminant B(xi,h)^2 - P(h)P(xi) > 0 for xi not parallel to h; fails at a radical xi when r >= 1
                strict = None
                if want and n >= 2:
                    i = next(i for i in range(n) if eps[i] != 0 and all(eps[j] * eps[i] <= 0 for j in range(n) if j != i))
                    h = [1 if j == i else 0 for j in range(n)]
                    bad = [xi for xi in itertools.product(range(-1, 2), repeat=n)
                           if any(xi[j] for j in range(n) if j != i) and B(xi, h) ** 2 - P(h) * P(xi) == 0]
                    strict = not bad
                    ok &= strict == (r == 0)
                table[(s, t, r)] = (found, strict)
    ex = table[(1, 1, 1)]
    row('bd·geo·8', 'P = sum eps_i k_i^2 with eps in {+1,-1,0}: a hyperbolic direction (B(k,h)^2 >= P(h)P(k) for all k, P(h) != 0) exists iff s = 1 or t = 1, '
        'for every number r of null generators (exact for the basis witness; 60 seeded h refuted by integer witnesses otherwise; n <= 6); it is strictly '
        f'hyperbolic (distinct roots off h) iff also r = 0 (T18 (f) is the case r = 0); smallest case with r >= 1: signature (1,1,1) (Cl(1,1,1)) is hyperbolic, not strictly: {ex}', ok and ex == (True, False))

# ---------------------------------------------------------------- 9. horizon algebra = null little group, every n
def c9():
    ok = True; dims = []
    for n in range(3, 8):
        st = Cl([1] + [-1] * (n - 1))                       # time +1, space -1 (atlas convention T)
        l = st.vec([1, 1] + [0] * (n - 2))
        m = st.vec([Fr(1, 2), Fr(-1, 2)] + [0] * (n - 2))
        ok &= st.mul(l, l) == {} and sc(add(st.mul(l, m), st.mul(m, l))) == 2   # l.m = 1 (sym product 2 l.m)
        # basis of l-perp: l, e2 .. e_{n-1}
        perp = [l] + [st.vec([0] * j + [1] + [0] * (n - 1 - j)) for j in range(2, n)]
        # m not in l-perp: l.m != 0; radical of the restricted form is span(l)
        G = [[sc(scal(add(st.mul(a, b), st.mul(b, a)), Fr(1, 2))) for b in perp] for a in perp]
        ok &= all(G[0][j] == 0 for j in range(len(perp))) and all(G[i][j] == (-1 if i == j else 0) for i in range(1, len(perp)) for j in range(1, len(perp)))
        # bivectors of l-perp
        idx = list(range(len(perp)))
        biv = {}
        for i, j in itertools.combinations(idx, 2):
            biv[(i, j)] = grade(st.mul(perp[i], perp[j]), 2)
        # each commutes with l as a vector map: B x l - l x B = 0 (commutator of B with l)
        ok &= all(comm(st, B, l) == {} for B in biv.values())
        # independence: coordinates in the bivector basis of the spacetime algebra
        keys = sorted({a for B in biv.values() for a in B})
        rows = [[B.get(a, Fr(0)) for a in keys] for B in biv.values()]
        # rank by Gaussian elimination
        Mx = [r[:] for r in rows]; rk = 0; col = 0
        while rk < len(Mx) and col < len(keys):
            piv = next((i for i in range(rk, len(Mx)) if Mx[i][col] != 0), None)
            if piv is None: col += 1; continue
            Mx[rk], Mx[piv] = Mx[piv], Mx[rk]
            for i in range(len(Mx)):
                if i != rk and Mx[i][col] != 0:
                    f = Mx[i][col] / Mx[rk][col]
                    Mx[i] = [a - f * b for a, b in zip(Mx[i], Mx[rk])]
            rk += 1; col += 1
        ok &= rk == (n - 1) * (n - 2) // 2 == (n * (n - 1) // 2) - (n - 1)
        # compare the brackets with Cl(0, n-2, 1), null bit first: generator 0 <-> l, generator j <-> e_{j+1}
        hz = Cl([0] + [-1] * (n - 2))
        hb = {(i, j): hz.mul({1 << i: Fr(1)}, {1 << j: Fr(1)}) for i, j in itertools.combinations(idx, 2)}
        def coords(x, basis):
            # express x in the basis (dict of pair -> multivector) by matching leading labels (bases are blade-like up to l)
            sol = {}
            rest = dict(x)
            for key, Bv in basis.items():
                # pick a label unique to this basis element
                lab = max(Bv, key=lambda a: (a not in sum([list(o) for kk, o in basis.items() if kk != key], []), a))
                if lab in rest and lab not in sum([list(o) for kk, o in basis.items() if kk != key], []):
                    c = rest[lab] / Bv[lab]; sol[key] = c; rest = add(rest, Bv, -c)
            return sol, rest
        for k1, k2 in itertools.combinations(list(biv), 2):
            cs = comm(st, biv[k1], biv[k2])
            ch = comm(hz, hb[k1], hb[k2])
            s1, rest1 = coords(cs, biv)
            s2, rest2 = coords(ch, hb)
            ok &= rest1 == {} and rest2 == {} and {k: v for k, v in s1.items() if v} == {k: v for k, v in s2.items() if v}
        dims.append((n, rk))
    row('bd·geo·9', 'in Cl(1,n-1) with l = e0 + e1: the bivectors of l-perp commute with l, have rank C(n-1,2) = dim so(1,n-1) - (n-1) (the stabiliser of a null line), and '
        'their brackets equal those of the bivectors of the horizon algebra Cl(0,n-2,1) under l -> null generator, n = 3..7 ' + str(dims) +
        '; the restricted form on l-perp has radical span(l) and l.m = 1 for m = (e0 - e1)/2 outside l-perp: the unpaired null of the surface is a paired null of '
        'spacetime whose partner is cut off (T7 (3), T18 (a))', ok)

# ---------------------------------------------------------------- 10. T17: totally null planes in a non-degenerate cell
def outer2(cl, u, v): return grade(cl.mul(u, v), 2)
def Dmap(cl, B, n):
    """matrix of D x = x . B = (x B - B x)/2 on vectors"""
    cols = []
    for i in range(n):
        x = {1 << i: Fr(1)}
        y = scal(add(cl.mul(x, B), cl.mul(B, x), -1), Fr(1, 2))
        cols.append([y.get(1 << j, Fr(0)) for j in range(n)])
    return [[cols[j][i] for j in range(n)] for i in range(n)]
def mm(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def zero(A): return all(v == 0 for r in A for v in r)
def c10():
    ok = True
    c22 = Cl([1, 1, -1, -1])
    u, v = c22.vec([1, 0, 1, 0]), c22.vec([0, 1, 0, 1])
    B = outer2(c22, u, v)
    gram = [[sc(c22.mul(u, u)), sc(scal(add(c22.mul(u, v), c22.mul(v, u)), Fr(1, 2)))], [None, sc(c22.mul(v, v))]]
    B2 = c22.mul(B, B)
    D = Dmap(c22, B, 4); D2 = mm(D, D)
    ok &= gram[0][0] == 0 and gram[0][1] == 0 and gram[1][1] == 0 and B2 == {} and zero(D2) and not zero(D)
    c13 = Cl([1, -1, -1, -1])
    un, w = c13.vec([1, 1, 0, 0]), c13.vec([0, 0, 1, 0])
    Bn = outer2(c13, un, w)
    Dn = Dmap(c13, Bn, 4)
    ok &= c13.mul(Bn, Bn) == {} and not zero(mm(Dn, Dn)) and zero(mm(mm(Dn, Dn), Dn))
    # no totally null plane in a cell with min(p,q) = 1: the maximal isotropic dimension of diag(eps) is min(p,q) (Witt index); search n = 4, 5
    ok2 = True
    for eps in ([1, -1, -1, -1], [1, 1, 1, -1], [1, -1, -1, -1, -1]):
        cl = Cl(eps); n = len(eps)
        vs = [v for v in itertools.product(range(-1, 2), repeat=n) if any(v) and sum(e * x * x for e, x in zip(eps, v)) == 0]
        for a, b in itertools.combinations(vs, 2):
            if sum(e * x * y for e, x, y in zip(eps, a, b)) == 0:
                # a, b null and orthogonal: must be parallel in Lorentzian signature
                if any(a[i] * b[j] != a[j] * b[i] for i in range(n) for j in range(n)): ok2 = False
    row('bd·geo·10', 'Cl(2,2) is non-degenerate, yet u = e1 + f1, v = e2 + f2 span a totally null plane: B = u ^ v has B^2 = 0, D != 0, D^2 = 0 (D x = x.B); a null '
        'rotation in Cl(1,3) (B = (e0 + e1) ^ e2) has D^2 != 0, D^3 = 0; in cells with min(p,q) = 1 two orthogonal null vectors are parallel (n = 4, 5 search). '
        'So a null rotation is the only s = 0 kind inside a non-degenerate cell exactly when min(p,q) <= 1 (T17 (b); check_T17.py lists '
        "'totally null plane' for (2,2,0))", ok and ok2)

# ---------------------------------------------------------------- 11. the right-hand gamma0 is a reference, not an observer
def c11():
    ok = True
    st = Cl([1, -1, -1, -1])
    g0 = st.vec([1, 0, 0, 0]); J = st.blade(2, 1)          # J = gamma2 gamma1
    ok &= st.mul(J, J) == {0: Fr(-1)} and comm(st, J, g0) == {}
    def dot(a, b): return sc(scal(add(st.mul(a, b), st.mul(b, a)), Fr(1, 2)))
    cases = [([5, 0, 0, 3], 4), ([5, 3, 0, 0], 4), ([13, 0, 5, 0], 12), ([-5, 0, 0, 3], 4), ([-13, 3, 4, 12], 0)]
    # rational boosts / rotations (rotors with R R~ = 1): cosh(phi/2) = 5/4, sinh = 3/4 ; rotation cos = 3/5, sin = 4/5 (half-angle in rotor)
    Lb = add({0: Fr(5, 4)}, scal(st.blade(1, 0), Fr(3, 4)))          # boost in the (0,1) plane
    Lr = add({0: Fr(3, 5)}, scal(st.blade(1, 3), Fr(4, 5)))          # rotation in the (1,3) plane (moves J = gamma2 gamma1)
    Lc = st.mul(Lb, Lr)
    for L in (Lb, Lr, Lc): ok &= st.mul(L, rev(L)) == {0: Fr(1)}
    for pv, m in cases:
        if m == 0: continue
        p = st.vec(pv)
        ok &= sc(st.mul(p, p)) == m * m
        psi = add({0: Fr(m)}, st.mul(p, g0))
        ok &= st.mul(p, psi) == scal(st.mul(psi, g0), m)                       # algebraic Dirac equation
        cur = st.mul(st.mul(psi, g0), rev(psi))
        ok &= cur == scal(p, 2 * (m + dot(p, g0)))                           # current along p
        rho = st.mul(psi, rev(psi))
        ok &= rho == {0: 2 * m * (m + dot(p, g0))}                          # psi psi~ = 2m(m + p.gamma0), beta = 0 or pi
        for L in (Lb, Lr, Lc):
            # observer change: left action, same gamma0 on the right
            pL = st.mul(st.mul(L, p), rev(L)); psiL = st.mul(L, psi)
            ok &= st.mul(pL, psiL) == scal(st.mul(psiL, g0), m)
            ok &= st.mul(st.mul(psiL, g0), rev(psiL)) == st.mul(st.mul(L, cur), rev(L))
            # right change of reference: (gamma0, J) -> (L g0 L~, L J L~), psi -> psi L~
            g0r = st.mul(st.mul(L, g0), rev(L)); Jr = st.mul(st.mul(L, J), rev(L)); psir = st.mul(psi, rev(L))
            ok &= st.mul(p, psir) == scal(st.mul(psir, g0r), m) and comm(st, Jr, g0r) == {}
            ok &= st.mul(st.mul(psir, g0r), rev(psir)) == cur                  # the current does not move
            # the sign of m + p.u is the same for every future unit timelike u = L g0 L~ (boost/rotation keep the time orientation)
            ok &= (m + dot(p, g0r) > 0) == (m + dot(p, g0) > 0) == (pv[0] > 0)
    row('bd·geo·11', 'Cl(1,3), J = gamma2 gamma1, five on-shell momenta (two past-directed): psi0 = m + p gamma0 solves p psi0 = m psi0 gamma0; a boost or rotation L of the observer '
        'acts on the left (p -> L p L~, psi -> L psi) and keeps gamma0 on the right; a change of the right reference (gamma0, J) -> (L gamma0 L~, L J L~) is undone by '
        'psi -> psi L~ and leaves the current psi gamma0 psi~ = 2(m + p.gamma0) p unchanged; psi psi~ = 2m(m + p.u) has the sign of p0 for every future unit u. '
        'So gamma0 in the mass term and current is a reference of the right action, and the datum is a time orientation', ok)

# ---------------------------------------------------------------- 12. the unit even versors of Cl(1,2) form SL(2,R); SL(2,C) is {x xbar = 1}
def c12():
    c12a = Cl([1, -1, -1])
    biv = [c12a.blade(i, j) for i, j in itertools.combinations(range(3), 2)]
    # Lie algebra of {x even, x x~ = 1}: tangent X even with X + X~ = 0: grade 2 only (dimension 3)
    even_lab = [a for a in range(8) if pc(a) % 2 == 0]
    tan_even = [a for a in even_lab if rev({a: Fr(1)}) == {a: Fr(-1)}]
    # Lie algebra of {x, x xbar = 1}: X + Xbar = 0 -> labels with conj sign -1
    tan_conj = [a for a in range(8) if conj({a: Fr(1)}) == {a: Fr(-1)}]
    # Killing form signature of the bivector algebra (3-dim): ad matrices
    def ad(X, basis):
        cols = []
        for Y in basis:
            Z = comm(c12a, X, Y)
            cols.append([Z.get(next(iter(b)), Fr(0)) / next(iter(b.values())) for b in basis])
        return [[cols[j][i] for j in range(len(basis))] for i in range(len(basis))]
    K = [[sum(mm(ad(X, biv), ad(Y, biv))[i][i] for i in range(3)) for Y in biv] for X in biv]
    pos = sum(1 for i in range(3) if K[i][i] > 0); neg = sum(1 for i in range(3) if K[i][i] < 0)
    offd = all(K[i][j] == 0 for i in range(3) for j in range(3) if i != j)
    # the even versors of Cl(1,3) map onto {x x~ = 1} of Cl^0(1,3) = Cl(1,2) via f_i = e_i e_0 (dimension 6)
    st = Cl([1, -1, -1, -1])
    even13 = [a for a in range(16) if pc(a) % 2 == 0]
    tan13 = [a for a in even13 if rev({a: Fr(1)}) == {a: Fr(-1)}]
    ok = len(tan_even) == 3 and len(tan_conj) == 6 and sorted(pc(a) for a in tan_conj) == [1, 1, 1, 2, 2, 2] and offd and (pos, neg) == (2, 1) and len(tan13) == 6
    row('bd·geo·12', f'Cl(1,2): the unit even versors have a Lie algebra of dimension {len(tan_even)} (bivectors, Killing signature (+,-) = {(pos, neg)}: sl(2,R), Spin(1,2) = SL(2,R)); '
        f'SL(2,C) = {{x in Cl(1,2) : x xbar = 1}} has a Lie algebra of grades 1 + 2, dimension {len(tan_conj)}, the image of the even versors of Cl(1,3) '
        f'(tangent dimension {len(tan13)}) under Cl^0(1,3) = Cl(1,2): SL(2,C) is the spin group of Cl(1,3), and the unit even versors of Cl(1,2) form SL(2,R)', ok)

if __name__ == '__main__':
    for f in (c7, c8, c9, c10, c11, c12): f()
    verdict()
