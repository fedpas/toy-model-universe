#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjg_ladder.py: the sizes of the rungs of the two ladders (labels F_2^n, n = 0..6) from the geometric side, and the meeting rung U2 = D3.
The ladder up adds structure to the 2^n points: the partial sum on disjoint labels with the popcount weight is its rung U2; the ladder down
forgets structure of the cell: the exterior algebra Cl(0,0,n) without its sign is its rung D3.  The A-space is that of arXiv:2403.19689 (v3), §2.

    python3 selfcheck/bridges/mjg_ladder.py              one line per check, ids bd·mjg·29 .. bd·mjg·30 (info line bd·mjg·31); exit 1 on any FAIL
    python3 selfcheck/bridges/mjg_ladder.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Standard library only, exact integers and Fractions, deterministic (seed 30), under 1 s; runs from any folder, reads and writes no file.

 bd·mjg·29  enumerated sizes equal the closed forms for n = 0..6: defined ordered pairs of the partial sum (a and b = 0) 3^n; arrows S <= T 3^n,
            non-identity 3^n - 2^n; cover edges n 2^(n-1); composable pairs 4^n, strict 4^n - 2.3^n + 2^n; nerve k-simplices (k+2)^n (k <= 3,
            n <= 4); weight classes C(n, k); first Betti number of the A-space graph (objects and non-identity arrows, components by union-find)
            b_1 = 3^n - 2^(n+1) + 1 (n >= 1); cube faces 3^n with f_k = C(n,k) 2^(n-k).
            Sabotage: the composable pairs counted with S < T only.
 bd·mjg·30  the meeting rung: forgetting the sign of the exterior algebra Lambda(R^n) = Cl(0,0,n) (support and grade of the bit-rule product
            with eps = 0) gives exactly the partial sum on disjoint labels with additive popcount (U2), n <= 6, and for every eps the bit-rule
            product restricted to disjoint labels is the wedge (same sign, eps-independent, n <= 4); every position map that is additive on
            the partial sum, P(a (+) b) = P(a) + P(b) with P(0) = 0, is L o x for the cube embedding x : labels -> {0,1}^n and the linear map
            L(e_i) = P({i}): all maps from the labels to Z_3 with P(0) = 0 are tested (n <= 3; the statement is the same over every abelian
            group), and the additive ones are exactly the 3^n maps L o x; 100 seeded random rational maps into Q^2 and Q^3 (n = 2..5) are not
            additive.
            Sabotage: eps = +1 in place of eps = 0 for the support.
 bd·mjg·31  (info, a table, not a check) the size table, one row per n.
"""
import sys, itertools, random
from fractions import Fraction as Fr
from math import comb

SAB = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if SAB: print('  sabotaged input, what the check sees: ' + text)
    else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return bool(ok)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

def sizes(n, sab=False):
    V = range(1 << n)
    d = {}
    d['points'] = 1 << n
    d['defined pairs'] = sum(1 for a in V for b in V if a & b == 0)
    d['arrows'] = sum(1 for S in V for T in V if S & ~T == 0)
    d['non-identity'] = sum(1 for S in V for T in V if S & ~T == 0 and S != T)
    d['cover edges'] = sum(1 for S in V for T in V if S & ~T == 0 and pc(T & ~S) == 1)
    comp = [(S, T, U) for U in V for T in V if T & ~U == 0 for S in V if S & ~T == 0 and (S != T if sab else True)]
    d['composable'] = len(comp)
    d['strict composable'] = sum(1 for S, T, U in comp if S != T and T != U)
    d['nerve'] = [sum(1 for c in itertools.product(V, repeat=k + 1) if all(c[j] & ~c[j + 1] == 0 for j in range(k))) for k in range(4)] if n <= 4 else None
    d['weights'] = [sum(1 for a in V if pc(a) == k) for k in range(n + 1)]
    comp_of = list(V)                                                  # union-find on the objects, joined along the non-identity arrows
    def find(x):
        while comp_of[x] != x: x = comp_of[x]
        return x
    for S in V:
        for T in V:
            if S & ~T == 0 and S != T: comp_of[find(S)] = find(T)
    d['graph b1'] = d['non-identity'] - (1 << n) + len({find(x) for x in V})
    d['faces'] = [sum(1 for S in V for T in V if S & ~T == 0 and pc(T & ~S) == k) for k in range(n + 1)]
    return d

def check29(sab):
    ok = True
    for n in range(0, 7):
        d = sizes(n, sab)
        ok &= d['defined pairs'] == 3 ** n and d['arrows'] == 3 ** n and d['non-identity'] == 3 ** n - 2 ** n
        ok &= d['cover edges'] == (n * 2 ** (n - 1) if n else 0) and d['composable'] == 4 ** n and d['strict composable'] == 4 ** n - 2 * 3 ** n + 2 ** n
        ok &= d['weights'] == [comb(n, k) for k in range(n + 1)] and d['faces'] == [comb(n, k) * 2 ** (n - k) for k in range(n + 1)]
        if n >= 1: ok &= d['graph b1'] == 3 ** n - 2 ** (n + 1) + 1
        if d['nerve']: ok &= d['nerve'] == [(k + 2) ** n for k in range(4)]
    return report('bd·mjg·29', ok, 'enumerated sizes equal 3^n (defined pairs, arrows), 3^n - 2^n, n 2^(n-1), 4^n, 4^n - 2.3^n + 2^n, (k+2)^n (n <= 4), C(n,k), 3^n - 2^(n+1) + 1 (the first Betti number of the A-space graph, n >= 1), C(n,k) 2^(n-k) for n = 0..6')

def check30(sab):
    ok = True
    for n in range(0, 7):
        eps = (1,) * n if sab else (0,) * n
        for a in range(1 << n):
            for b in range(1 << n):
                s = sgn(a, b, eps)
                ok &= (s != 0) == (a & b == 0)
                if s: ok &= pc(a ^ b) == pc(a) + pc(b)
    for n in range(1, 5):
        for eps in itertools.product((1, -1, 0), repeat=n):
            ok &= all(sgn(a, b, eps) == sgn(a, b, (0,) * n) for a in range(1 << n) for b in range(1 << n) if a & b == 0)
    fact = True; additive = {}
    for n in range(1, 4):                                              # every map labels -> Z_3 with P(0) = 0
        N = 1 << n; cnt = 0
        for vals in itertools.product(range(3), repeat=N - 1):
            P = (0,) + vals
            if all(P[a | b] == (P[a] + P[b]) % 3 for a in range(N) for b in range(N) if a & b == 0):
                cnt += 1
                fact &= all(P[a] == sum(P[1 << i] for i in range(n) if a >> i & 1) % 3 for a in range(N))   # P = L o x
        additive[n] = cnt
        fact &= cnt == 3 ** n
    rs = random.Random(30); rnd_add = 0
    for _ in range(100):
        n = rs.randint(2, 5); dim = rs.choice((2, 3))
        R = {a: [Fr(rs.randint(-9, 9)) for _ in range(dim)] for a in range(1 << n)}; R[0] = [Fr(0)] * dim
        rnd_add += all(R[a | b] == [x + y for x, y in zip(R[a], R[b])] for a in range(1 << n) for b in range(1 << n) if a & b == 0)
    ok &= fact and rnd_add == 0
    return report('bd·mjg·30', ok, 'support and grade of Cl(0,0,n) = the partial sum on disjoint labels with additive popcount (n <= 6); the bit-rule product on disjoint '
                  f'labels is eps-independent (n <= 4); the maps labels -> Z_3 additive on the partial sum number {additive} = 3^n, each L o x (cube embedding): {fact}; '
                  f'seeded random rational positions additive in {rnd_add} of 100')

def info31():
    hdr = 'n | points | pairs/arrows 3^n | non-id | edges | composable 4^n | strict | nerve 0..3 (from the formula for n > 4) | A-space b1 | f-vector'
    rows = []
    for n in range(0, 7):
        d = sizes(n)
        rows.append(f'{n} | {d["points"]} | {d["arrows"]} | {d["non-identity"]} | {d["cover edges"]} | {d["composable"]} | {d["strict composable"]} | '
                    f'{d["nerve"] if d["nerve"] else [(k + 2) ** n for k in range(4)]} | {d["graph b1"] if n else 0} | {d["faces"]}')
    print('info bd·mjg·31  the size table (a table, not a check): ' + hdr + ' :: ' + ' :: '.join(rows))

CHECKS = [('bd·mjg·29', check29), ('bd·mjg·30', check30)]

def main():
    if SAB:
        missed = 0
        for cid, fn in CHECKS:
            okk = fn(True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            missed += okk
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        return missed == 0
    for cid, fn in CHECKS: fn(False)
    info31()
    nfail = sum(1 for _, o in RESULTS if not o)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    return nfail == 0

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
