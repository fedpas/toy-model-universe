#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""fur_commutant.py: the commutant of the Standard Model gauge algebra in Furey's 16-dimensional model, and the order-3 question (idea H9, QT8).

    python3 selfcheck/bridges/fur_commutant.py              one line per check, ids bd·fur·1 .. bd·fur·5; exit 1 on any FAIL
    python3 selfcheck/bridges/fur_commutant.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Deterministic, under 1 s; runs from any folder, reads and writes no file.

The model (as in the Atlas's reports/furey/model.py and run_all.py, rebuilt here with exact integers):
  octonions by Cayley-Dickson from the quaternions, (a,b)(c,d) = (ac - conj(d) b, d a + b conj(c)), basis
  0:1 1:i 2:j 3:k 4:l 5:li 6:lj 7:lk (k = e7 of the paper's labelling);  V = O + O' (16 real dimensions);
  complex structure omega = L_k on both copies;  real Peirce blocks O1 = range (I - L_k R_k)/2 = span{1,k} (first copy),
  O2 = range (I + L_k R_k)/2 (first copy, 6), H = second copy {4,5,6,7}, C = second copy {1,2}, e7R = second copy {3},
  R = second copy {0};  complex blocks C_O = O1, C3_O = O2, C2_H = H, C_C = C, C_last = e7R + R (sizes 1, 3, 2, 1, 1).
The 12-dimensional gauge algebra g_SM = su(3) + su(2) + u(1)_Y:
  su(3): the 8 derivations of O that kill k, acting on the first copy;  su(2): the 3 antisymmetric maps of the H block that commute with
  omega and have complex trace 0;  u(1)_Y: omega Y with Y = P_O2/3 + P_H/2 + P_C (the hypercharge of run_all.py).
Everything is exact (fractions.Fraction); standard library only.  The labels of the 20 cells of the paper's Fig. 1 are the paper's
(as listed in the Atlas's Furey report, table of the ten edges); the script only maps cells to cells and compares gauge numbers.
"""
import sys
from fractions import Fraction as Fr
from itertools import product

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, ok))
    print((('ok   ' if ok else 'FAIL ') + cid + '  ' + text) if not SABOTAGE else ('  sabotaged input, what the check sees: ' + text))
    return ok

# ------------------------------------------------------------------ exact octonions (model.py's Cayley-Dickson, integers)
def qmul(p, q):
    a1, b1, c1, d1 = p; a2, b2, c2, d2 = q
    return [a1*a2 - b1*b2 - c1*c2 - d1*d2, a1*b2 + b1*a2 + c1*d2 - d1*c2, a1*c2 - b1*d2 + c1*a2 + d1*b2, a1*d2 + b1*c2 - c1*b2 + d1*a2]
def qconj(p): return [p[0], -p[1], -p[2], -p[3]]
def omul(x, y):
    a, b, c, d = x[:4], x[4:], y[:4], y[4:]
    first = [u - v for u, v in zip(qmul(a, c), qmul(qconj(d), b))]
    second = [u + v for u, v in zip(qmul(d, a), qmul(b, qconj(c)))]
    return first + second
def unit(a, n=8): v = [0] * n; v[a] = 1; return v
T = [[omul(unit(a), unit(b)) for b in range(8)] for a in range(8)]          # T[a][b] = e_a e_b
SIGN = {}
for a in range(8):
    for b in range(8):
        nz = [(c, v) for c, v in enumerate(T[a][b]) if v]
        assert len(nz) == 1 and nz[0][0] == a ^ b and abs(nz[0][1]) == 1          # the octonion table is XOR with a sign
        SIGN[(a, b)] = nz[0][1]

# ------------------------------------------------------------------ exact matrices as dicts {(row, col): Fraction}
N16 = 16
def mat(n=N16): return {}
def mmul(A, B):
    out = {}
    Bc = {}
    for (k, j), v in B.items(): Bc.setdefault(k, []).append((j, v))
    for (i, k), v in A.items():
        for j, w in Bc.get(k, ()):
            out[(i, j)] = out.get((i, j), 0) + v * w
    return {k: v for k, v in out.items() if v}
def madd(A, B, s=1):
    out = dict(A)
    for k, v in B.items():
        out[k] = out.get(k, 0) + s * v
        if not out[k]: del out[k]
    return out
def mscale(A, s): return {k: v * s for k, v in A.items() if v * s}
def comm(A, B): return madd(mmul(A, B), mmul(B, A), -1)
def ident(idx): return {(i, i): Fr(1) for i in idx}
def Lmat8(a): return {(a ^ m, m): Fr(SIGN[(a, m)]) for m in range(8)}       # L_{e_a}: e_m -> e_a e_m
def Rmat8(a): return {(m ^ a, m): Fr(SIGN[(m, a)]) for m in range(8)}       # R_{e_a}: e_m -> e_m e_a
def embed(A8, copy):                                                          # an 8x8 map on copy 0 (first) or 1 (second)
    o = 8 * copy
    return {(i + o, j + o): v for (i, j), v in A8.items()}
K = 3
Lk, Rk = Lmat8(K), Rmat8(K)
OMEGA = madd(embed(Lk, 0), embed(Lk, 1))
LR = mmul(Lk, Rk)
PO1 = embed(mscale(madd(ident(range(8)), LR, -1), Fr(1, 2)), 0)
PO2 = embed(mscale(madd(ident(range(8)), LR, 1), Fr(1, 2)), 0)
PH = ident([12, 13, 14, 15]); PC = ident([9, 10]); Pe7R = ident([11]); PR = ident([8])
REAL_BLOCKS = [('O1', PO1), ('O2', PO2), ('H', PH), ('C', PC), ('e7R', Pe7R), ('R', PR)]
CBLOCKS = [('C_O', PO1), ('C3_O', PO2), ('C2_H', PH), ('C_C', PC), ('C_last', madd(Pe7R, PR))]
def trace(A): return sum(v for (i, j), v in A.items() if i == j)

# ------------------------------------------------------------------ exact linear algebra
def nullspace(rows, nvar):
    """basis of {x : r.x = 0 for every row}, rows as dicts var -> coefficient (exact)"""
    piv = {}                                                                  # pivot col -> fully reduced row
    for r in rows:
        r = {k: Fr(v) for k, v in r.items() if v}
        for c in list(r):
            if c in piv and c in r:
                f = r[c]
                for kk, x in piv[c].items():
                    y = r.get(kk, 0) - f * x
                    if y: r[kk] = y
                    else: r.pop(kk, None)
        if not r: continue
        c = min(r); f = r[c]; r = {kk: x / f for kk, x in r.items()}
        for pc_, pr in piv.items():
            if c in pr:
                g = pr[c]
                for kk, x in r.items():
                    y = pr.get(kk, 0) - g * x
                    if y: pr[kk] = y
                    else: pr.pop(kk, None)
        piv[c] = r
    free = [j for j in range(nvar) if j not in piv]
    basis = []
    for f in free:
        v = {f: Fr(1)}
        for c, pr in piv.items():
            if f in pr: v[c] = -pr[f]
        basis.append(v)
    return basis
def rank_of(mats):
    """rank of a list of matrices (as vectors)"""
    keys = {}
    rows = []
    for M in mats:
        rows.append({keys.setdefault(k, len(keys)): v for k, v in M.items()})
    n = len(keys)
    if not rows: return 0
    # rank = number of rows minus dim of left nullspace: do elimination directly
    piv = {}; rk = 0
    for r in rows:
        r = {k: Fr(v) for k, v in r.items() if v}
        while r:
            c = min(r)
            if c in piv:
                f = r[c]
                for kk, x in piv[c].items():
                    y = r.get(kk, 0) - f * x
                    if y: r[kk] = y
                    else: r.pop(kk, None)
            else:
                f = r[c]; piv[c] = {kk: x / f for kk, x in r.items()}; rk += 1; break
    return rk
def commutant(gens, idx=range(N16)):
    """basis of the matrices X (supported on idx x idx) with [X, g] = 0 for every g"""
    idx = list(idx); pos = {(i, j): n for n, (i, j) in enumerate(product(idx, idx))}
    rows = {}
    for g in gens:
        gr = {}; gc = {}
        for (i, j), v in g.items(): gr.setdefault(i, []).append((j, v)); gc.setdefault(j, []).append((i, v))
        # ([X,g])_{a,b} = sum_k X_{a,k} g_{k,b} - g_{a,k} X_{k,b}
        for a in idx:
            for b in idx:
                r = {}
                for k, v in gc.get(b, ()):                                   # g_{k,b}
                    if (a, k) in pos: r[pos[(a, k)]] = r.get(pos[(a, k)], 0) + v
                for k, v in gr.get(a, ()):                                   # g_{a,k}
                    if (k, b) in pos: r[pos[(k, b)]] = r.get(pos[(k, b)], 0) - v
                r = {kk: vv for kk, vv in r.items() if vv}
                if r: rows[(id(g), a, b)] = r
    inv = {n: ij for ij, n in pos.items()}
    return [{inv[n]: v for n, v in vec.items()} for vec in nullspace(list(rows.values()), len(pos))]

# ------------------------------------------------------------------ the gauge algebra
def derivations_killing(kill):
    """derivations D of O (8x8, D[i][j] = coefficient of e_i in D(e_j)) with D(e_kill) = 0"""
    var = lambda i, j: 8 * i + j
    rows = []
    for a in range(8):
        for b in range(8):
            s = SIGN[(a, b)]; c = a ^ b
            for i in range(8):
                r = {}
                r[var(i, c)] = r.get(var(i, c), 0) + s                              # D(e_a e_b) = s D(e_c)
                kk = i ^ b; r[var(kk, a)] = r.get(var(kk, a), 0) - SIGN[(kk, b)]      # D(e_a) e_b
                kk = a ^ i; r[var(kk, b)] = r.get(var(kk, b), 0) - SIGN[(a, kk)]      # e_a D(e_b)
                r = {x: y for x, y in r.items() if y}
                if r: rows.append(r)
    for i in range(8):
        if kill is not None: rows.append({var(i, kill): 1})
    return [{(v // 8, v % 8): x for v, x in vec.items()} for vec in nullspace(rows, 64)]

def su2_on_H():
    J = {(i - 12, j - 12): v for (i, j), v in OMEGA.items() if 12 <= i < 16 and 12 <= j < 16}
    pairs = [(i, j) for i in range(4) for j in range(i + 1, 4)]
    def X_of(vec):
        X = {}
        for n, (i, j) in enumerate(pairs):
            if vec.get(n): X[(i, j)] = vec[n]; X[(j, i)] = -vec[n]
        return X
    # unknowns x_n (antisymmetric X); equations [X, J] = 0 and tr(J X) = 0
    rows = []
    for a in range(4):
        for b in range(4):
            r = {}
            for n in range(len(pairs)):
                C = comm(X_of({n: 1}), J)
                if C.get((a, b)): r[n] = C[(a, b)]
            if r: rows.append(r)
    r = {}
    for n in range(len(pairs)):
        t = trace(mmul(J, X_of({n: 1})))
        if t: r[n] = t
    rows.append(r)
    return [{(i + 12, j + 12): v for (i, j), v in X_of(vec).items()} for vec in nullspace(rows, len(pairs))]

def gauge_algebra(sab=None):
    su3 = [embed(D, 0) for D in derivations_killing(K)]
    su2 = su2_on_H()
    Y = madd(madd(mscale(PO2, Fr(1, 3)), mscale(PH, Fr(1, 2))), PC)
    u1 = [mmul(OMEGA, Y)]
    if sab == 'move_e7':                                                       # replace one su(3) generator by a g2 derivation that moves k
        g2 = [embed(D, 0) for D in derivations_killing(None)]
        extra = next(G for G in g2 if rank_of(su3 + [G]) > len(su3))
        su3 = su3[:-1] + [extra]
    if sab == 'drop_Y': u1 = []
    if sab == 'drop_su3_gen': su3 = su3[:-1]
    return su3, su2, u1, Y

# ------------------------------------------------------------------ bd·fur·1: the gauge algebra in the model
def check1(sab=False):
    su3, su2, u1, Y = gauge_algebra('move_e7' if sab else None)
    G = su3 + su2 + u1
    dim = rank_of(G)
    closes = all(rank_of(G + [comm(A, B)]) == dim for A in G for B in G)
    with_omega = all(not comm(A, OMEGA) for A in G)
    with_blocks = all(not comm(A, P) for A in G for _, P in REAL_BLOCKS)
    ideals = (rank_of(su3) == 8 and rank_of(su2) == 3 and all(not comm(A, B) for A in su3 for B in su2 + u1) and all(not comm(A, B) for A in su2 for B in u1))
    # block content: dimension of the commutant of g_SM restricted to each complex block (4 = trivial 2-dim rep; 2 = irreducible of complex type)
    content = {}
    for name, P in CBLOCKS:
        idx = sorted({i for (i, j) in P})
        gens = [{(i, j): v for (i, j), v in A.items() if i in idx and j in idx} for A in G]
        content[name] = len(commutant([g for g in gens if g] or [{}], idx))
    ok = dim == 12 and closes and with_omega and with_blocks and ideals and content == {'C_O': 4, 'C3_O': 2, 'C2_H': 2, 'C_C': 2, 'C_last': 4}
    return report('bd·fur·1', ok, f'the gauge algebra su(3) + su(2) + u(1)_Y of the model (8 derivations of O killing e7 on the first copy, 3 on the H block commuting with omega, omega Y): dimension {dim}, closes under the commutator: {closes}, commutes with omega: {with_omega} and with the six real Peirce projectors: {with_blocks}, the three summands commute: {ideals}; real dimension of its commutant on each complex block {content} (4: trivial 2-dimensional representation, 2: irreducible of complex type)')

# ------------------------------------------------------------------ bd·fur·2: the commutant, its structure, with and without omega
def structure(Cbasis):
    """dimension of the centre of the algebra spanned by Cbasis (exact)"""
    n = len(Cbasis)
    rows = {}
    for l, Bl in enumerate(Cbasis):
        for k, Bk in enumerate(Cbasis):
            for key, v in comm(Bk, Bl).items():
                rows.setdefault((l, key), {})[k] = v
    return len(nullspace(list(rows.values()), n))
def check2(sab=False):
    su3, su2, u1, Y = gauge_algebra('drop_Y' if sab else None)
    G = su3 + su2 + u1
    C = commutant(G)
    Cw = commutant(G + [OMEGA])
    zC, zCw = structure(C), structure(Cw)
    # not a division algebra: the projector onto the block C_O commutes with g_SM and is a non-trivial idempotent
    in_C = rank_of(C + [PO1]) == len(C)
    off = {}
    for (n1, P1), (n2, P2) in product(CBLOCKS, CBLOCKS):
        if n1 < n2:
            d = rank_of([mmul(mmul(P2, X), P1) for X in C])
            if d: off[f'{n1}->{n2}'] = d
    ok = len(C) == 22 and zC == 7 and len(Cw) == 14 and zCw == 8 and in_C and off == {'C_O->C_last': 4}
    return report('bd·fur·2', ok, f'the commutant of the 12-dimensional gauge algebra in M16(R) (256 unknowns, exact) has dimension {len(C)}, centre of dimension {zC}: M4(R) on the four real dimensions of the two hypercharge-0 singlet blocks C_O + C_last, and C on each of C3_O, C2_H, C_C; it is not a division algebra (the projector onto C_O lies in it: {in_C}); the only non-zero pieces between different blocks are {off}; adding omega (complex-linear maps) leaves dimension {len(Cw)} with centre {zCw}: M2(C) + C + C + C')

# ------------------------------------------------------------------ bd·fur·3: elements of order 3 that normalise the Peirce blocks permute no cell
def block_classes(G, blocks, with_omega=True):
    C = commutant(G + ([OMEGA] if with_omega else []))
    names = [n for n, _ in blocks]; P = dict(blocks)
    size = {n: trace(P[n]) for n in names}
    hom = {(a, b): rank_of([mmul(mmul(P[b], X), P[a]) for X in C]) for a in names for b in names}
    classes = []
    for a in names:                                                           # a ~ b iff same size and Hom_g(a, b) != 0
        for cl in classes:
            if size[cl[0]] == size[a] and hom[(cl[0], a)]: cl.append(a); break
        else: classes.append([a])
    return classes, hom
def check3(sab=False):
    su3, su2, u1, Y = gauge_algebra('drop_Y' if sab else None)
    G = su3 + su2 + u1
    cls_c, hom_c = block_classes(G, CBLOCKS)
    cls_r, _ = block_classes(G, REAL_BLOCKS, with_omega=False)
    maxc = max(len(c) for c in cls_c); maxr = max(len(c) for c in cls_r)
    phases = all(hom_c[(n, n)] == 2 for n, _ in CBLOCKS)                     # omega-linear commutant on each block is C: an order-3 element there is a cube root of unity
    ok = maxc <= 2 and maxr <= 2 and phases
    return report('bd·fur·3', ok, f'an element of the commutant that normalises the Peirce blocks can only exchange blocks of equal size carrying isomorphic gauge representations; these classes are {cls_c} for the five complex blocks and {cls_r} for the six real ones (largest class: {maxc} complex, {maxr} real blocks); with at most two blocks per class an element of order 3 fixes every block and maps each of the 20 cells of Fig. 1 to itself; on each complex block the complex-linear commutant is C (real dimension 2 on every block: {phases}), so it acts by a cube root of unity: block phases only. H9 (an order-3 generation symmetry commuting with the gauge algebra) has no solution inside the model')

# ------------------------------------------------------------------ bd·fur·4: the order-2 swap of the two hypercharge-0 singlet blocks
CELLS = {(0, 1): ('b_R', 'beyond'), (0, 2): ('(nu_e,e)_L', 'first'), (0, 3): ('e_R', 'first'), (0, 4): ('nu_eR', 'first'), (1, 2): ('Q_L', 'first'),
         (1, 3): ('u_R', 'first'), (1, 4): ('d_R', 'first'), (2, 3): ('h', 'beyond'), (2, 4): ('(nu_tau,tau)_L', 'beyond'), (3, 4): ('tau_R', 'beyond')}
def check4(sab=False):
    su3, su2, u1, Y = gauge_algebra()
    G = su3 + su2 + u1
    if not sab:
        swap_axes = [(0, 8), (3, 11)]                                         # C_O = span{1, k} (first copy)  <->  C_last = span{1', k'} (second copy)
        sigma = {0: 4, 4: 0, 1: 1, 2: 2, 3: 3}
    else:                                                                     # sabotage: swap C_O with C_C (hypercharge 0 against 1)
        swap_axes = [(0, 9), (3, 10)]
        sigma = {0: 3, 3: 0, 1: 1, 2: 2, 4: 4}
    S = ident(range(16))
    for a, b in swap_axes:
        del S[(a, a)]; del S[(b, b)]; S[(a, b)] = Fr(1); S[(b, a)] = Fr(1)
    in_comm = all(not comm(S, A) for A in G)
    with_omega = not comm(S, OMEGA)
    involution = mmul(S, S) == ident(range(16))
    P = [p for _, p in CBLOCKS]
    permutes = all(mmul(mmul(S, P[i]), S) == P[sigma[i]] for i in range(5))
    ys = [trace(mmul(Y, p)) / trace(p) for p in P]                           # hypercharge of each block
    same_numbers = all(ys[i] == ys[sigma[i]] for i in range(5))
    cell_map = {}
    for (i, j), (lab, gen) in CELLS.items():
        a, b = sorted((sigma[i], sigma[j]))
        cell_map[lab] = CELLS[(a, b)][0]
    moved = {k: v for k, v in cell_map.items() if k != v}
    fixed = sorted(k for k, v in cell_map.items() if k == v)
    not_in_aut_O = S.get((8, 0), 0) != 0                                     # S sends 1 to 1': no diag(phi, phi) with phi in Aut(O) does
    ok = in_comm and with_omega and involution and permutes and same_numbers and moved == {'b_R': 'd_R', 'd_R': 'b_R', '(nu_e,e)_L': '(nu_tau,tau)_L', '(nu_tau,tau)_L': '(nu_e,e)_L', 'e_R': 'tau_R', 'tau_R': 'e_R'} and fixed == sorted(['nu_eR', 'Q_L', 'u_R', 'h']) and not_in_aut_O
    return report('bd·fur·4', ok, f'the exchange S of the two hypercharge-0 singlet blocks (1, k of the first copy with 1\', k\' of the second) commutes with the gauge algebra: {in_comm}, with omega: {with_omega}, is an involution permuting the complex blocks: {permutes}, keeps hypercharges {[str(y) for y in ys]}: {same_numbers}; on the cells of Fig. 1 (labels as printed in the paper) it exchanges {moved} and fixes {fixed}: an order-2 cell permutation that swaps the first-generation cells d_R, (nu_e,e)_L, e_R with b_R, (nu_tau,tau)_L, tau_R and fixes exactly the cells whose irreps lack a third copy (Q_L, u_R, nu_R) and h; S sends 1 to 1\', so it is not an automorphism of O acting on both copies (not in G2, not in the label group): {not_in_aut_O}')

# ------------------------------------------------------------------ bd·fur·5: label automorphisms of O against the colour su(3)
def check5(sab=False):
    D = derivations_killing(K)
    if sab: D = D[:1]                                                         # sabotage: only one colour generator
    lin = []
    for i1 in range(1, 8):
        for i2 in range(1, 8):
            for i4 in range(1, 8):
                g = [0] * 8
                for a in range(8):
                    v = 0
                    if a & 1: v ^= i1
                    if a & 2: v ^= i2
                    if a & 4: v ^= i4
                    g[a] = v
                if len(set(g)) == 8: lin.append(tuple(g))
    autos = []
    for g in lin:
        for sb in range(1 << 7):
            s = [1] + [(-1) ** ((sb >> (a - 1)) & 1) for a in range(1, 8)]
            if all(SIGN[(g[a], g[b])] * s[a] * s[b] == s[a ^ b] * SIGN[(a, b)] for a in range(8) for b in range(8)):
                autos.append((g, s))
    def as_mat(x):
        g, s = x; return {(g[a], a): Fr(s[a]) for a in range(8)}
    def order(x):
        M = as_mat(x); P = M; k = 1
        while P != ident(range(8)): P = mmul(M, P); k += 1
        return k
    commuting = [x for x in autos if all(not comm(as_mat(x), Dm) for Dm in D)]
    nontriv = [x for x in commuting if as_mat(x) != ident(range(8))]
    fix_k_order3 = [x for x in autos if x[0][K] == K and order(x) == 3]
    ok = len(autos) == 1344 and len(D) == 8 and not nontriv and len(fix_k_order3) > 0
    return report('bd·fur·5', ok, f'in the basis of the model the automorphisms of O that permute the basis lines number {len(autos)} (2^3.GL(3,2)); {len(fix_k_order3)} of them have order 3 and fix e7 = k; the derivations killing e7 span {len(D)} dimensions (the colour su(3)), and the label automorphisms commuting with all of them other than the identity number {len(nontriv)}: no order-3 label symmetry of O commutes with colour')

CHECKS = [('bd·fur·1', check1), ('bd·fur·2', check2), ('bd·fur·3', check3), ('bd·fur·4', check4), ('bd·fur·5', check5)]
if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear(); ok = f(sab=True)
            print(('CAUGHT ' if not ok else 'MISSED ') + cid)
            missed += ok
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    nfail = sum(1 for _, ok in RESULTS if not ok)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
