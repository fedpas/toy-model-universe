#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""phy_trio.py: the trio -1, 0, +1 where physics has names.

  bd·phy·13  Witt (x) A_eps with A_eps = R[h]/(h^2 = eps) (Schuller lens), L_m = L_m (x) 1, M_m = L_m (x) h: eps = 0 gives [L_m, L_n] = (m-n) L_{m+n},
             [L_m, M_n] = (m-n) M_{m+n}, [M_m, M_n] = 0, the centreless bms_3 = gca_2 (the 2d Carrollian = Galilean conformal algebra); eps = +1
             gives two commuting Witt algebras E_pm = (L pm M)/2 (the Lorentzian 2d conformal algebra, light-cone split, modes |m| <= 4);
             eps = -1 gives [M_m, M_n] = -(m-n) L_{m+n}, Witt (x) C (the Euclidean 2d conformal algebra).  The Jacobi identity holds on the
             modes |m| <= 2.  These are the standard trichotomy of 2d conformal algebras.
  bd·phy·14  gravity and the projective step (k = -s, GRV-007): in convention T (time +1, space -1) the bivectors of Cl(1,3) plus one extra
             generator of square s close into so(1,4) for s = -1 and so(2,3) for s = +1, told apart by the Killing signature (positive,
             negative, zero) = (4, 6, 0) and (6, 4, 0): de Sitter for a space-like extra generator, anti-de Sitter for a time-like one; s = 0
             gives the Poincare algebra iso(1,3) (Killing (3, 3, 4)).
  bd·phy·15  (info, a read-off, not a check) the bivector squares -1, +1, 0 of Cl(2,0), Cl(1,1), Cl(1,0,1): one number behind the Kepler
             trio (bound, scattering, parabolic orbit), the tube trio (so(3), so(1,2), iso(2), bd·phy·8) and the band trio (band, gap, band edge).

  python3 phy_trio.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; under a second."""
import itertools
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))          # phy_bitrule.py sits next to this script
import numpy as np
from phy_bitrule import Alg, Reporter

def witt_tensor(eps, M=4):
    """basis: (m, 0) = L_m, (m, 1) = M_m for |m| <= M. bracket as dict."""
    def br(x, y):
        (m, a), (n, b) = x, y
        c = a + b
        coef = (m - n)
        if c == 0:
            return {(m + n, 0): coef}
        if c == 1:
            return {(m + n, 1): coef}
        # h^2 = eps
        return {(m + n, 0): coef * eps} if eps else {}
    return br

def main():
    R = Reporter()
    # bd·phy·13
    M = 4
    modes = range(-M, M + 1)
    txt = []; ok = True
    for eps in (0, 1, -1):
        br = witt_tensor(eps, M)
        # Jacobi on modes small enough that the sums stay within the window checked (|m+n+k| <= M)
        def brd(X, D):
            """bracket of a basis element X with a dict D (linear combination)"""
            out = {}
            for key, v in D.items():
                for key2, v2 in br(X, key).items():
                    out[key2] = out.get(key2, 0) + v * v2
            return out
        jac = True
        for m, n, k in itertools.product(range(-2, 3), repeat=3):
            for a, b, c in itertools.product((0, 1), repeat=3):
                X, Y, Z = (m, a), (n, b), (k, c)
                tot = {}
                for P, Q, S in ((X, Y, Z), (Y, Z, X), (Z, X, Y)):
                    for key, v in brd(P, br(Q, S)).items():
                        tot[key] = tot.get(key, 0) + v
                jac &= all(abs(v) < 1e-12 for v in tot.values())
        if eps == 0:
            MM = br((2, 1), (-1, 1)); LM = br((2, 0), (-1, 1))
            pattern = (MM == {} and LM == {(1, 1): 3})
            txt.append('eps=0: [M2,M-1] = 0, [L2,M-1] = 3 M1: bms_3')
        elif eps == 1:
            # E+ = (L + M)/2, E- = (L - M)/2 commute and each is Witt: check [E+_m, E-_n] = 0 symbolically
            def Ebr(sm, m, sn, n):
                # (L_m + sm M_m)/2 with (L_n + sn M_n)/2
                out = {}
                for a, ca in ((0, 0.5), (1, 0.5 * sm)):
                    for b, cb in ((0, 0.5), (1, 0.5 * sn)):
                        for key, v in br((m, a), (n, b)).items():
                            out[key] = out.get(key, 0) + ca * cb * v
                return {k: v for k, v in out.items() if abs(v) > 1e-12}
            cross = all(Ebr(1, m, -1, n) == {} for m in modes for n in modes)
            same = all(Ebr(1, m, 1, n) == ({(m + n, 0): 0.5 * (m - n), (m + n, 1): 0.5 * (m - n)} if m != n else {}) for m in modes for n in modes)
            pattern = cross and same
            txt.append('eps=+1: E+ and E- commute, each a Witt algebra: Witt + Witt (light-cone)')
        else:
            MM = br((2, 1), (-1, 1))
            pattern = (MM == {(1, 0): -3})
            txt.append('eps=-1: [M2,M-1] = -3 L1: M = iL, Witt (x) C')
        ok &= jac and pattern
    R('bd·phy·13', ok, '; '.join(txt) + ' (the Jacobi identity holds on the modes |m| <= 2)')

    # bd·phy·14: Killing signatures of the bivector algebra of Cl(1,3) + extra generator of square s
    res = []; ok14 = True
    expected = {-1: (4, 6, 0), 1: (6, 4, 0), 0: (3, 3, 4)}
    for s in (-1, 1, 0):
        A = Alg([1, -1, -1, -1, s])
        biv = [m for m in range(32) if A.grade[m] == 2]
        B = [A.blade(m) for m in biv]
        # structure constants ad matrices
        ad = []
        for X in B:
            Mx = np.zeros((10, 10))
            for j, Y in enumerate(B):
                c = A.commutator(X, Y)
                Mx[:, j] = [c[m] for m in biv]
            ad.append(Mx)
        K = np.array([[np.trace(ad[i] @ ad[j]) for j in range(10)] for i in range(10)])
        w = np.linalg.eigvalsh(K)
        sig = (int((w > 1e-9).sum()), int((w < -1e-9).sum()), int((np.abs(w) <= 1e-9).sum()))
        ok14 &= sig == expected[s]
        res.append('s=%+d: Killing (pos, neg, zero) = %s' % (s, sig))
    R('bd·phy·14', ok14, '; '.join(res) + ': so(1,4) de Sitter for s = -1 (space-like extra generator in convention T), so(2,3) anti-de Sitter for s = +1, iso(1,3) for s = 0')

    # bd·phy·15: one scalar square, three readings
    C2 = Alg.pq(2, 0); rot = C2.mul(C2.blade(1), C2.blade(2))             # e1 e2, square -1
    C11 = Alg.pq(1, 1); boo = C11.mul(C11.blade(1), C11.blade(2))         # e1 e2 with squares +1, -1: square +1
    C101 = Alg([1, 0]); nul = C101.mul(C101.blade(1), C101.blade(2))      # e1 n: square 0
    sq = [float(C2.mul(rot, rot)[0]), float(C11.mul(boo, boo)[0]), float(C101.mul(nul, nul)[0])]
    R.info('bd·phy·15', 'the bivector squares of Cl(2,0), Cl(1,1), Cl(1,0,1) are %s: rotation (band / bound orbit / so(3) tube), '
      'boost (gap / scattering / so(1,2) tube), null (band edge / parabolic orbit / iso(2) tube): one number, three readings' % sq)
    R.finish()

if __name__ == '__main__':
    main()
