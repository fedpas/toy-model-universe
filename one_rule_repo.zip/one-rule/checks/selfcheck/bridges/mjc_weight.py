#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mjc_weight.py: the positive additive weight of arXiv:2403.19689 (v3) (Def. 2 (1), eq. (9), the norm axioms of §3) on a zoo of
categories, on the label category B_n (weights = coboundaries), and the paper's distance d(f, g) = ||l|| for f = l o g (the subtraction of
§4) as a Lawvere metric.

    python3 selfcheck/bridges/mjc_weight.py              one line per check, ids bd·mjc·15 .. bd·mjc·19; exit 1 on any FAIL
    python3 selfcheck/bridges/mjc_weight.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library (fractions for exact ranks) and scipy (linprog, HiGHS) for the LP column of bd·mjc·15; every LP answer is paired with an exact
witness or an exact obstruction.  Deterministic (seeds 31, 33, 34), about 1 s; runs from any folder, reads and writes no file.
  bd·mjc·15  the zoo: which categories carry a positive additive weight w (w(g o f) = w(f) + w(g), w > 0 on non-identity arrows): B_0..B_4,
             the Kronecker category (two parallel arrows), a non-cancellative acyclic category (l1 f = l2 f forces w(l1) = w(l2)): yes, by
             w = phi(cod) - phi(dom); the monoid {1, e} (e idempotent), Z_2, Z_3, S_3, the pair groupoid on two objects, a preorder with a cycle of
             isomorphisms (a = b < c), a split idempotent (r s = 1, s r = e): no, with the exact obstruction; the free monoid on one letter, the
             free category on a 2-cycle and on a loop plus an edge (infinite): yes, path length, checked on every composable pair of total
             length <= 8 (finite categories: yes iff acyclic, bd·mjc·12).
  bd·mjc·16  the additive weights on B_n (all signs) form a space of dimension 2^n - 1, equal to the space of coboundaries phi(T) - phi(S) (n = 1..4,
             exact ranks): every weight is a potential difference; those that depend on T xor S only form the n-dimensional space of bd·mjc·2;
             control: the crown poset (a, b < c, d), whose nerve is a circle, has additive weights of dimension 4 against 3 coboundaries; random
             positive weights on B_3 (seed 31) are additive in 0 of 200.  The line also says that delta phi is positive iff phi is strictly
             increasing: the two conditions are one by definition, a remark that is not part of the check.
  bd·mjc·17  the paper's d(f, g) = ||f ⊖ g|| = ||l|| for f = l o g, on B_n with the popcount weight (n = 2..4): defined on k of N ordered pairs
             (printed); d(f, f) = 0, d(f, h) = d(f, g) + d(g, h) along factorizations (the triangle law of a Lawvere metric holds with equality),
             d(f, g) = ||f|| - ||g||; symmetric pairs with f != g: 0, so as a classical metric it fails (symmetry, finiteness), and both
             symmetrizations of Lawvere (+ and max) give infinity for every f != g; in the non-cancellative category the two candidate values
             ||l1||, ||l2|| agree for every additive weight.
  bd·mjc·18  the weight on the Hom-sets of the labels: d(S, T) = |T \ S| (the weight of S -> T when S is a subset of T; for any S, T the cost of the
             insertions) satisfies d(S, S) = 0 and the triangle law on all triples (n <= 4) and is not symmetric; its symmetrizations are classical
             metrics: by + the Hamming distance popcount(S xor T), by max the larger of |S \ T|, |T \ S|.
  bd·mjc·19  control (generic, not a finding): random posets on 8 elements (seed 33) carry a positive additive weight in 200 of 200; random
             transformation monoids on 3 points with a non-identity element (seed 34) in 0 of 200 (each has an idempotent or identity power).
"""
import sys, random, itertools
from fractions import Fraction

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if not SABOTAGE: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    else: print('  sabotaged input, what the check sees: ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def rank_q(rows, ncols):
    M = [[Fraction(x) for x in r] for r in rows]; rk = 0; col = 0
    while rk < len(M) and col < ncols:
        piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if piv is None: col += 1; continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col] / M[rk][col]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1; col += 1
    return rk

class Cat:
    def __init__(self, m, dom, cod, ident, comp, name=''):
        self.m, self.dom, self.cod, self.ident, self.comp, self.name = m, dom, cod, ident, comp, name
        self.A = len(dom); self.isid = set(ident); self.nonid = [f for f in range(self.A) if f not in self.isid]
    def c(self, f, g): return self.comp[(f, g)]
def build(name, m, arrows, table):
    """arrows: dict name -> (dom, cod) of non-identity arrows; table: dict (f, g) -> name of g o f ('1' for the identity), for every composable
    pair of non-identity arrows"""
    names = list(arrows); k = len(names); idx = {x: i for i, x in enumerate(names)}
    dom = [arrows[x][0] for x in names] + list(range(m)); cod = [arrows[x][1] for x in names] + list(range(m))
    ident = [k + o for o in range(m)]; comp = {}
    for f in range(k + m):
        for g in range(k + m):
            if cod[f] != dom[g]: continue
            if f >= k: comp[(f, g)] = g
            elif g >= k: comp[(f, g)] = f
            else:
                v = table[(names[f], names[g])]; comp[(f, g)] = (k + dom[f]) if v == '1' else idx[v]
    return Cat(m, dom, cod, ident, comp, name)
def boolean_lattice(n):
    L = range(1 << n); arrows = [(s, t) for s in L for t in L if (s & t) == s]; index = {x: i for i, x in enumerate(arrows)}
    comp = {(i, j): index[(arrows[i][0], arrows[j][1])] for i in range(len(arrows)) for j in range(len(arrows)) if arrows[i][1] == arrows[j][0]}
    return Cat(1 << n, [x[0] for x in arrows], [x[1] for x in arrows], [index[(s, s)] for s in L], comp, f'B_{n}'), arrows
def group_cat(name, elems, mul, e):
    idx = {x: i for i, x in enumerate(elems)}; comp = {(i, j): idx[mul(elems[j], elems[i])] for i in range(len(elems)) for j in range(len(elems))}
    return Cat(1, [0] * len(elems), [0] * len(elems), [idx[e]], comp, name)

def endo_nonid(C): return [f for f in C.nonid if C.dom[f] == C.cod[f]]
def acyclic(C):
    if endo_nonid(C): return False
    reach = [[False] * C.m for _ in range(C.m)]
    for f in C.nonid: reach[C.dom[f]][C.cod[f]] = True
    return not any(reach[a][b] and reach[b][a] for a in range(C.m) for b in range(C.m) if a != b)
def weight_lp(C):
    from scipy.optimize import linprog
    idx = {f: i for i, f in enumerate(C.nonid)}; rows = []
    for f in C.nonid:
        for g in C.nonid:
            if C.cod[f] != C.dom[g]: continue
            r = [0] * len(idx); h = C.c(f, g); r[idx[f]] -= 1; r[idx[g]] -= 1
            if h not in C.isid: r[idx[h]] += 1
            rows.append(r)
    if not idx or not rows: return True
    return linprog([0] * len(idx), A_eq=rows, b_eq=[0] * len(rows), bounds=[(1, None)] * len(idx), method='highs').status == 0
def weight_witness(C, flip=False):
    order = []; indeg = {o: 0 for o in range(C.m)}; out = {o: set() for o in range(C.m)}
    for f in C.nonid:
        if C.dom[f] != C.cod[f] and C.cod[f] not in out[C.dom[f]]: out[C.dom[f]].add(C.cod[f]); indeg[C.cod[f]] += 1
    st = [o for o in range(C.m) if indeg[o] == 0]
    while st:
        o = st.pop(); order.append(o)
        for p in out[o]:
            indeg[p] -= 1
            if indeg[p] == 0: st.append(p)
    if len(order) < C.m: return None
    phi = {o: i for i, o in enumerate(order)}
    w = {f: (phi[C.dom[f]] - phi[C.cod[f]]) if flip else (phi[C.cod[f]] - phi[C.dom[f]]) for f in range(C.A)}
    if any(w[f] <= 0 for f in C.nonid) or any(w[C.c(f, g)] != w[f] + w[g] for (f, g) in C.comp): return None
    return w
def obstruction(C):
    for f in C.nonid:
        for g in C.nonid:
            if C.cod[f] == C.dom[g] and C.c(f, g) in C.isid: return 'identity composite'
    for f in endo_nonid(C):
        x = f
        for _ in range(C.A + 1):
            if C.c(x, x) == x: return 'idempotent power'
            x = C.c(x, f)
            if x in C.isid: return 'identity power'
    return None

def zoo(sab=False):
    Z = []
    for n in range(0, 5): Z.append((boolean_lattice(n)[0], True))
    Z.append((build('Kronecker', 2, {'f': (0, 1), 'g': (0, 1)}, {}), True))
    Z.append((build('non-cancellative', 3, {'f': (0, 1), 'l1': (1, 2), 'l2': (1, 2), 'h': (0, 2)}, {('f', 'l1'): 'h', ('f', 'l2'): 'h'}), True))
    Z.append((build('{1,e}', 1, {'e': (0, 0)}, {('e', 'e'): 'e'}), False))
    Z.append((group_cat('Z2', [0, 1], lambda a, b: (a + b) % 2, 0), False))
    Z.append((group_cat('Z3', [0, 1, 2], lambda a, b: (a + b) % 3, 0), False))
    S3 = list(itertools.permutations(range(3)))
    Z.append((group_cat('S3', S3, lambda a, b: tuple(a[b[i]] for i in range(3)), (0, 1, 2)), False))
    Z.append((build('pair groupoid', 2, {'u': (0, 1), 'v': (1, 0)}, {('u', 'v'): '1', ('v', 'u'): '1'}), False))
    Z.append((build('a = b < c', 3, {'u': (0, 1), 'v': (1, 0), 'p': (0, 2), 'q': (1, 2)},
                    {('u', 'v'): '1', ('v', 'u'): '1', ('u', 'q'): 'p', ('v', 'p'): 'q'}), False))
    Z.append((build('split idempotent', 2, {'s': (0, 1), 'r': (1, 0), 'e': (1, 1)},
                    {('s', 'r'): '1', ('r', 's'): 'e', ('e', 'e'): 'e', ('s', 'e'): 's', ('e', 'r'): 'r'}), False))
    if sab:                                                            # sabotage: B_2 replaced by the pair groupoid, the expectation (yes) kept
        Z[2] = (build('pair groupoid as B_2', 2, {'u': (0, 1), 'v': (1, 0)}, {('u', 'v'): '1', ('v', 'u'): '1'}), True)
    return Z

def free_lengths(sab=False):
    """free categories (infinite): arrows = paths (tuples of edges); length is additive and positive; test all pairs of total length <= 8"""
    graphs = {'free monoid on one letter': [('x', 0, 0)], 'free category on a 2-cycle': [('f', 0, 1), ('g', 1, 0)],
              'free category on a loop plus an edge': [('x', 0, 0), ('y', 0, 1)]}
    res = {}
    for name, E in graphs.items():
        paths = [((), o) for o in range(2)]                            # (edges, start) ; identities have no edges
        frontier = [(tuple([e]), e[1]) for e in E]
        allp = []
        for L in range(1, 9):
            allp += frontier
            nxt = []
            for (p, s) in frontier:
                end = p[-1][2]
                for e in E:
                    if e[1] == end: nxt.append((p + (e,), s))
            frontier = nxt
        def length(p): return len(p) if not sab else len(set(p))       # sabotage: count distinct edges, not edges
        ok = all(length(p + q) == length(p) + length(q) for (p, s) in allp for (q, t) in allp
                 if p[-1][2] == q[0][1] and len(p) + len(q) <= 8) and all(length(p) > 0 for (p, s) in allp)
        res[name] = ok
    return res

# ================================================================== bd·mjc·15  the zoo
def check15(sab=False):
    rows = []; ok = True
    for C, expect in zoo(sab):
        lp = weight_lp(C); w = weight_witness(C); ob = obstruction(C)
        exact = (w is not None) and ob is None
        if not (lp == exact == expect == acyclic(C)) or ((w is None) == (ob is None)): ok = False
        rows.append(f'{C.name}: {"yes" if exact else "no (" + str(ob) + ")"}')
    fl = free_lengths(sab)
    if not all(fl.values()): ok = False
    return report('bd·mjc·15', ok, 'positive additive weight: ' + '; '.join(rows) + '; ' + '; '.join(f'{k}: {"yes, path length" if v else "length not additive"}' for k, v in fl.items()) + ' (LP, exact witness and acyclicity agree on every finite member)')

# ================================================================== bd·mjc·16  weights on B_n are coboundaries
def additive_space(C):
    """dimension of the space of additive weights (any sign) on the non-identity arrows, and of the coboundaries phi(cod) - phi(dom)"""
    idx = {f: i for i, f in enumerate(C.nonid)}; rows = []
    for f in C.nonid:
        for g in C.nonid:
            if C.cod[f] != C.dom[g]: continue
            r = [0] * len(idx); h = C.c(f, g); r[idx[f]] -= 1; r[idx[g]] -= 1
            if h not in C.isid: r[idx[h]] += 1
            rows.append(r)
    dimW = len(idx) - (rank_q(rows, len(idx)) if rows else 0)
    cob = []
    for o in range(C.m):
        r = [0] * len(idx)
        for f in C.nonid:
            r[idx[f]] += (1 if C.cod[f] == o else 0) - (1 if C.dom[f] == o else 0)
        cob.append(r)
    dimB = rank_q(cob, len(idx)) if idx else 0
    return dimW, dimB
def check16(sab=False):
    ok = True; dims = {}
    for n in range(1, 5):
        C, arrows = boolean_lattice(n)
        if sab and n == 2:                                             # sabotage: the crown poset a, b < c, d in place of B_2
            C = build('crown', 4, {'ac': (0, 2), 'ad': (0, 3), 'bc': (1, 2), 'bd': (1, 3)}, {})
        dW, dB = additive_space(C); dims[n] = (dW, dB)
        # translation-invariant weights: w(S -> T) = c(T xor S); rank of the constraints restricted to that family
        if not (sab and n == 2):
            ti_rows = []
            labels = range(1, 1 << n)
            idx = {d: i for i, d in enumerate(labels)}
            for f in C.nonid:
                for g in C.nonid:
                    if C.cod[f] != C.dom[g]: continue
                    h = C.c(f, g); r = [0] * len(idx)
                    for x, sgn_ in ((h, 1), (f, -1), (g, -1)):
                        d = arrows[x][0] ^ arrows[x][1]
                        if d: r[idx[d]] += sgn_
                    ti_rows.append(r)
            ti = len(idx) - rank_q(ti_rows, len(idx))
            if ti != n: ok = False
        if not (sab and n == 2) and not (dW == dB == (1 << n) - 1): ok = False
        if sab and n == 2 and dW != dB: ok = False
    crown = build('crown', 4, {'ac': (0, 2), 'ad': (0, 3), 'bc': (1, 2), 'bd': (1, 3)}, {})
    cW, cB = additive_space(crown)
    rng = random.Random(31); C3, arr3 = boolean_lattice(3); pos_ok = 0
    for _ in range(200):
        phi = [rng.randint(-3, 3) for _ in range(8)]
        mono = all(phi[t] > phi[s] for (s, t) in arr3 if s != t)
        positive = all(phi[arr3[f][1]] - phi[arr3[f][0]] > 0 for f in C3.nonid)
        pos_ok += (mono == positive)                                   # one condition written twice (by definition): a remark, not tested
    rnd_add = 0
    for _ in range(200):
        w = {f: rng.randint(1, 4) for f in C3.nonid}
        rnd_add += all(w[C3.c(f, g)] == w[f] + w[g] for f in C3.nonid for g in C3.nonid if C3.cod[f] == C3.dom[g])
    if not ((cW, cB) == (4, 3) and rnd_add == 0): ok = False
    return report('bd·mjc·16', ok, f'additive weights on B_n (any sign), (dimension, dimension of the coboundaries phi(T) - phi(S)) = {dims} = (2^n - 1, 2^n - 1): every weight is a potential difference (H^1 of the nerve is 0); the weights that depend on T xor S only: dimension n; control: the crown poset (a, b < c, d) has {cW} weights against {cB} coboundaries; random positive weights on B_3 additive in {rnd_add} of 200 (seed 31); remark, one condition by definition and not part of the check: delta phi > 0 iff phi strictly increasing ({pos_ok} of 200 random phi)')

# ================================================================== bd·mjc·17  the paper's d(f, g) as a Lawvere metric
def check17(sab=False):
    ok = True; stats = {}
    for n in (2, 3, 4):
        C, arrows = boolean_lattice(n)
        norm = (lambda f: pc(arrows[f][0] ^ arrows[f][1]) ** 2) if sab else (lambda f: pc(arrows[f][0] ^ arrows[f][1]))   # sabotage: a non-additive norm
        V = list(range(C.A))
        def d(f, g):                                                   # f = l o g: same domain, cod g <= cod f; l unique in a poset
            if arrows[f][0] != arrows[g][0] or (arrows[g][1] & arrows[f][1]) != arrows[g][1]: return None
            l = arrows.index((arrows[g][1], arrows[f][1])); return norm(l)
        defined = sum(1 for f in V for g in V if d(f, g) is not None)
        refl = all(d(f, f) == 0 for f in V)
        tri = all(d(f, h) == d(f, g) + d(g, h) for f in V for g in V for h in V if d(f, g) is not None and d(g, h) is not None)
        trans = all(d(f, h) is not None for f in V for g in V for h in V if d(f, g) is not None and d(g, h) is not None)
        diff = all(d(f, g) == norm(f) - norm(g) for f in V for g in V if d(f, g) is not None)
        sym = sum(1 for f in V for g in V if f != g and d(f, g) is not None and d(g, f) is not None)
        sep = all(d(f, g) != 0 or f == g for f in V for g in V if d(f, g) is not None)
        stats[n] = (defined, len(V) ** 2)
        if not (refl and tri and trans and diff and sym == 0 and sep): ok = False
    # non-cancellative category: h = l1 o f = l2 o f; additive weights force w(l1) = w(l2)
    NC = build('nc', 3, {'f': (0, 1), 'l1': (1, 2), 'l2': (1, 2), 'h': (0, 2)}, {('f', 'l1'): 'h', ('f', 'l2'): 'h'})
    idx = {f: i for i, f in enumerate(NC.nonid)}
    rows = []
    for f in NC.nonid:
        for g in NC.nonid:
            if NC.cod[f] == NC.dom[g]:
                r = [0] * len(idx); r[idx[NC.c(f, g)]] += 1; r[idx[f]] -= 1; r[idx[g]] -= 1; rows.append(r)
    test = [0] * len(idx); test[1] = 1; test[2] = -1                   # w(l1) - w(l2): in the row space of the constraints?
    forced = rank_q(rows, len(idx)) == rank_q(rows + [test], len(idx))
    if not forced: ok = False
    return report('bd·mjc·17', ok, f'd(f, g) = ||l|| for f = l o g on B_n with the popcount weight: defined on {stats} (defined, all) ordered pairs; d(f, f) = 0, d(f, h) = d(f, g) + d(g, h) whenever the right side is defined (the triangle law of a Lawvere metric, with equality), d(f, g) = ||f|| - ||g||, d(f, g) = 0 only for f = g; ordered pairs f != g with both d(f, g) and d(g, f) finite: 0 (not symmetric, mostly infinite: not a classical metric; its + and max symmetrizations are infinite off the diagonal); non-cancellative l1 o f = l2 o f: w(l1) = w(l2) for every additive weight: {forced}')

# ================================================================== bd·mjc·18  the Hom-set metric of the labels
def check18(sab=False):
    ok = True; asym = {}
    for n in range(1, 5):
        L = range(1 << n)
        d = (lambda S, T: pc(T & ~S) ** 2) if sab else (lambda S, T: pc(T & ~S))   # sabotage: squared insertion cost
        refl = all(d(S, S) == 0 for S in L)
        tri = all(d(S, U) <= d(S, T) + d(T, U) for S in L for T in L for U in L)
        asym[n] = sum(1 for S in L for T in L if d(S, T) != d(T, S))
        ham = all(d(S, T) + d(T, S) == pc(S ^ T) for S in L for T in L)
        mx = lambda S, T: max(d(S, T), d(T, S))
        mx_ok = all(mx(S, U) <= mx(S, T) + mx(T, U) for S in L for T in L for U in L) and all(mx(S, T) == 0 or S != T for S in L for T in L)
        chain = all(d(S, U) == d(S, T) + d(T, U) for S in L for T in L for U in L if (S & T) == S and (T & U) == T)
        if not (refl and tri and asym[n] > 0 and ham and mx_ok and chain): ok = False
    return report('bd·mjc·18', ok, f'd(S, T) = |T \\ S| on the labels: d(S, S) = 0 and the triangle law on all triples (n = 1..4), asymmetric pairs {asym}; along S subset T subset U it is additive (the weight of the arrows of B_n, the [0, inf]-enriched form of (9)); symmetrized by + it is the Hamming distance popcount(S xor T), by max a classical metric as well')

# ================================================================== bd·mjc·19  controls: random posets and random monoids
def random_poset_cat(m, prob, rng):
    up = [1 << i for i in range(m)]
    for i in range(m - 1, -1, -1):
        for j in range(i + 1, m):
            if rng.random() < prob: up[i] |= up[j]
    arrows = [(x, y) for x in range(m) for y in range(m) if up[x] >> y & 1]; index = {a: i for i, a in enumerate(arrows)}
    comp = {(i, j): index[(arrows[i][0], arrows[j][1])] for i in range(len(arrows)) for j in range(len(arrows)) if arrows[i][1] == arrows[j][0]}
    return Cat(m, [a[0] for a in arrows], [a[1] for a in arrows], [index[(x, x)] for x in range(m)], comp)
def random_transformation_monoid(rng):
    gens = [tuple(rng.randrange(3) for _ in range(3)) for _ in range(2)]
    el = {(0, 1, 2)} | set(gens); changed = True
    while changed:
        changed = False
        for a in list(el):
            for b in list(el):
                c = tuple(b[a[i]] for i in range(3))
                if c not in el: el.add(c); changed = True
    el = sorted(el); idx = {x: i for i, x in enumerate(el)}
    comp = {(i, j): idx[tuple(el[j][el[i][k]] for k in range(3))] for i in range(len(el)) for j in range(len(el))}
    return Cat(1, [0] * len(el), [0] * len(el), [idx[(0, 1, 2)]], comp)
def check19(sab=False):
    rng = random.Random(33); yes_p = 0
    for _ in range(200):
        C = random_poset_cat(8, 0.47, rng)
        if sab: C = random_transformation_monoid(rng)                    # sabotage: the poset control replaced by monoids
        yes_p += weight_witness(C) is not None and obstruction(C) is None and weight_lp(C)
    rng = random.Random(34); yes_m = 0; nm = 0
    while nm < 200:
        C = random_transformation_monoid(rng)
        if not C.nonid: continue
        nm += 1; yes_m += weight_witness(C) is not None and obstruction(C) is None
    ok = yes_p == 200 and yes_m == 0
    return report('bd·mjc·19', ok, f'control (generic, not a finding): random posets on 8 elements (seed 33) carry a positive additive weight in {yes_p} of 200; random transformation monoids on 3 points with a non-identity element (seed 34) in {yes_m} of 200')

CHECKS = [('bd·mjc·15', check15), ('bd·mjc·16', check16), ('bd·mjc·17', check17), ('bd·mjc·18', check18), ('bd·mjc·19', check19)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear()
            okk = f(sab=True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            if okk: missed += 1
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    nfail = sum(1 for _, okk in RESULTS if not okk)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
