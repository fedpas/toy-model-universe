#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mat_cell_classification.py: the triple (V, Q, pi) of a non-degenerate cell Cl(p,q) (r = 0), classified for every n by a construction,
and its link to the odd unimodular lattice I_{p,q} = Z^p (+) (-Z)^q.

  python3 selfcheck/bridges/mat_cell_classification.py     one line per check, ids bd·mat·5 .. bd·mat·8; exit 1 on any FAIL

Standard library only, exact integers, deterministic, about 2 s; runs from any folder, reads and writes no file.
  bd·mat·5  the four 3-subsets of a +1 block {1,2,3,4} are an orthonormal basis of the dot product with w = 3 on each: an explicit isometry of
            (V, w) = (V, Q, pi) between Cl(4,0) and Cl(0,4); extended by the identity on the other bits it maps the triple of Cl(p,q) onto that
            of Cl(p-4,q+4), checked on every label for every (p,q) with 4 <= n <= 9. With the Brown invariant (core·B3) separating the rest,
            (V, Q, pi) up to isomorphism is (n, p - q mod 8) for every n (core·B6c; the argument is in the row text).
  bd·mat·6  the bilinear form of w = pi + 2Q is the dot product |a & b| mod 2 (non-degenerate for every n); the polar form of the binary Q is
            pi(a)pi(b) + |a & b|, with radical {0} for n even and {0, 1...1} for n odd (every Cl(p,q), n <= 7).
  bd·mat·7  w(a) = x.x mod 4 for the 0/1 vector x of the label a in I_{p,q}, every label of every Cl(p,q) with n <= 8, and the Gauss sum of i^w
            is the product prod_i (1 + i^{eps_i}) = (1+i)^p (1-i)^q: the clock is the Brown invariant of (I/2I, x.x mod 4), which is the
            signature of I_{p,q} mod 8 (Brown's theorem; Taylor, arXiv:2208.06319, Thm 2.5).
  bd·mat·8  for Cl(n,0) the binary Q on the even labels is (x.x)/2 mod 2, the mod-2 norm form of the even sublattice D_n of I_n, and Q = floor(w/2)
            on every label (n <= 8).
"""
import sys

ROWS = []
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Q(a, e): return 1 if sgn(a, a, e) == -1 else 0
def pi(a): return pc(a) % 2
def w4(a, e): return (pi(a) + 2 * Q(a, e)) % 4
def sig(p, q): return [1] * p + [-1] * q
def row(i, text, ok):
    ROWS.append((i, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

def lin(imgs, a):
    x = 0
    for j, v in enumerate(imgs):
        if a >> j & 1: x ^= v
    return x

# ---------------------------------------------------------------- bd·mat·5: the constructive isometry
def four_block_images(off):
    """images of the four generators e_off..e_off+3 of a +1 block: the 3-subsets (complements of e_i in the block)"""
    blk = 0b1111 << off
    return [blk ^ (1 << (off + i)) for i in range(4)]
def check5():
    ok = True; tested = 0
    # the block itself: w = 3 on each 3-subset in Cl(4,0), pairwise dot products 0, linearly independent
    e4 = sig(4, 0); imgs = four_block_images(0)
    if any(w4(v, e4) != 3 for v in imgs): ok = False
    if any(pc(imgs[i] & imgs[j]) % 2 != (1 if i == j else 0) for i in range(4) for j in range(4)): ok = False
    span = {0}
    for v in imgs: span |= {s ^ v for s in span}
    if len(span) != 16: ok = False
    # Cl(p,q) -> Cl(p-4, q+4): map the first four +1 generators (bits 0..3) to the 3-subsets of that block, keep the rest; then the image sits in
    # Cl(p-4,q+4) read with the SAME bit positions, i.e. we show (V, w_{Cl(p,q)}) = (V, w') where w' is w of Cl(p,q) pulled back by T, and w' equals
    # the form of the cell with four +1 bits turned into -1 bits. Concretely: check w_{p,q}(T a) = w_{p-4,q+4}(a) for every a.
    for n in range(4, 10):
        for p in range(4, n + 1):
            q = n - p
            e_src, e_dst = sig(p, q), [-1] * 4 + sig(p - 4, q)      # the destination cell: the four bits became -1 bits, the others as before
            T = four_block_images(0) + [1 << j for j in range(4, n)]
            if any(w4(lin(T, a), e_src) != w4(a, e_dst) for a in range(1 << n)): ok = False
            if any(pi(lin(T, a)) != pi(a) for a in range(1 << n)): ok = False
            tested += 1
    row('bd·mat·5', 'the four 3-subsets of a +1 block {1,2,3,4} are orthonormal for the dot product and carry w = 3: an explicit isometry of (V, w) = (V, Q, pi) between '
        f'Cl(4,0) and Cl(0,4). Extended by the identity on the other bits it maps the triple of Cl(p,q) onto the triple of Cl(p-4, q+4) exactly ({tested} cells, 4 <= n <= 9, '
        'every label). With the Brown invariant (core·B3) separating the rest, (V, Q, pi) up to isomorphism is (n, p - q mod 8) for every n, the statement of core·B6c '
        '(argument: orthonormal basis of (V, dot) with w in {1, 3} on it, so (V, w) = <1>^p (+) <3>^q; <1>^4 = <3>^4 by the block; the Brown invariant separates the rest)', ok)

# ---------------------------------------------------------------- bd·mat·6: the two bilinear forms
def check6():
    ok = True; rads = {}
    for n in range(1, 8):
        for p in range(n + 1):
            e = sig(p, n - p); V = range(1 << n)
            # bilinear form of w: (w(a+b) - w(a) - w(b))/2 mod 2
            for a in V:
                for b in V:
                    if ((w4(a ^ b, e) - w4(a, e) - w4(b, e)) % 4) // 2 != pc(a & b) % 2: ok = False
                    if (Q(a ^ b, e) + Q(a, e) + Q(b, e)) % 2 != (pi(a) * pi(b) + pc(a & b)) % 2: ok = False
            radQ = [a for a in V if all((Q(a ^ b, e) + Q(a, e) + Q(b, e)) % 2 == 0 for b in V)]
            rads[(p, n - p)] = radQ
            want = [0] if n % 2 == 0 else [0, (1 << n) - 1]
            if radQ != want: ok = False
    row('bd·mat·6', 'the bilinear form of w = pi + 2Q is the dot product |a & b| mod 2 (non-degenerate for every n) and the polar form of the binary Q is '
        'pi(a)pi(b) + |a & b| mod 2, whose radical is {0} for n even and {0, F} (F = 1...1, the pseudoscalar) for n odd; every Cl(p,q) with n <= 7. '
        'So the F_2 form Q is non-degenerate exactly for even n (the Arf-invariant case of the type R/H), and the radical class at odd n is the central pseudoscalar (T10 (6), n = 7)', ok)

# ---------------------------------------------------------------- bd·mat·7: w is the mod-4 norm of the odd lattice I_{p,q}
def check7():
    ok = True
    for n in range(1, 9):
        for p in range(n + 1):
            q = n - p; e = sig(p, q)
            for a in range(1 << n):
                xx = sum(e[i] for i in range(n) if a >> i & 1)                # x.x for the 0/1 vector x in Z^{p,q}
                if xx % 4 != w4(a, e): ok = False
            # the Gauss sum factorises: prod_i (1 + i^{eps_i})
            re, im = 1, 0
            for i in range(n):
                z = (1, 1) if e[i] == 1 else (1, -1)
                re, im = re * z[0] - im * z[1], re * z[1] + im * z[0]
            S = [0, 0]
            for a in range(1 << n):
                k = w4(a, e); S[0] += [1, 0, -1, 0][k]; S[1] += [0, 1, 0, -1][k]
            if (re, im) != tuple(S): ok = False
    row('bd·mat·7', 'w(a) = x.x mod 4 for x the 0/1 vector of the label a in the odd unimodular lattice I_{p,q} = Z^p (+) (-Z)^q, every label of every Cl(p,q), n <= 8; '
        'and the Gauss sum factorises as prod_i (1 + i^{eps_i}) = (1+i)^p (1-i)^q. So the Z_4 form of the Atlas is the mod-4 norm of I_{p,q} reduced to I/2I, and '
        '"clock = Brown invariant" is the classical "Brown invariant of (L/2L, x.x mod 4) = signature of L mod 8" for L = I_{p,q} (Brown\'s theorem; Taylor, arXiv:2208.06319, Thm 2.5)', ok)

# ---------------------------------------------------------------- bd·mat·8: on even labels Q is the mod-2 norm of D_n
def check8():
    ok = True
    for n in range(1, 9):
        e = sig(n, 0)
        for a in range(1 << n):
            if pc(a) % 2: continue
            if (pc(a) // 2) % 2 != Q(a, e): ok = False                         # x.x/2 mod 2 with x.x = |a|
        # and on odd labels Q = (|a| - 1)/2 mod 2 = floor(w/2)
        for a in range(1 << n):
            if Q(a, e) != (w4(a, e) // 2): ok = False
    row('bd·mat·8', 'for Cl(n,0) the binary form on the even labels is Q(a) = (x.x)/2 mod 2 = the mod-2 norm form of the even sublattice D_n of I_n, and on every label '
        'Q = floor(w/2) (the upper bit of the Z_4 form), n <= 8. The form T9 identifies with E_n/2E_n is this binary Q; the clock uses the Z_4 form w. The two Z_8 statements '
        '(Brown invariant of w = signature of the odd lattice; Gauss-Milgram phase of E_n = signature of the even lattice) share the number n because both lattices have signature n, not through one mechanism', ok)

if __name__ == '__main__':
    for f in (check5, check6, check7, check8): f()
    verdict()
