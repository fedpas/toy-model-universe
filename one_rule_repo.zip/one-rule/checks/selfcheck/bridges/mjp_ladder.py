#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjp_ladder.py: the two ladders that join the labels of arXiv:2403.19689 (v3) to the cells, in the occupation-number reading.  The up
ladder adds structure to the 2^n labels: U0 the points, U1 the disjoint partial sum, U2 the weight (the popcount), U3 the order and the arrows
of B_n, U4 the positions of the paper, U5 the sign, U6 the squares (the cell), U7 the clock.  The down ladder forgets structure of the cell:
D0 the full cell with its clock and null part, D1 the triple (V, Q, pi), D2 the exterior algebra Lambda(R^n) (the squares forgotten), D3 the
partial sum with the popcount (the sign forgotten), D4 the order B_n, D5 the points.  The checks: the sizes at the rungs, what the sign adds
(hard-core bosons against fermions), which cells share a triple when the null part is forgotten, where the two ladders meet, where the integer
weight is a grading, and the frame that the partial sum carries.

    python3 selfcheck/bridges/mjp_ladder.py              one line per check, ids bd·mjp·33 .. bd·mjp·38; exit 1 on any FAIL
    python3 selfcheck/bridges/mjp_ladder.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

numpy and the standard library; exact integers; no random data; about 5 s on one core; reads and writes no file; runs from any folder, also
with python3 -I.
  bd·mjp·33  sizes by enumeration, n = 0..6: labels (Fock states) 2^n; pairs with a defined partial sum = non-zero products of creation operators
             (the bit-rule products of Lambda(R^n)) = arrows of B_n = 3^n; composable pairs 4^n; chains S_0 <= .. <= S_k (the k-simplices of the
             nerve, degenerate ones included) (k+2)^n for k = 0..3.  (The algebra dimensions 2^n, 3^n, 4^n of Lambda(R^n), the incidence algebra
             and Cl(n,n) are those of bd·mjp·4.)
  bd·mjp·34  what the sign adds (U5, D2 -> D3): the algebra of the paper's partial sum on the labels (e_a e_b = e_{a+b} for disjoint a, b, else 0:
             the hard-core boson, or zeon, algebra) and Lambda(R^n) (the same with the bit-rule sign) have the same dimension 2^n, the same
             zero pattern and the same weight grading; the first is commutative, the second has a commutator space of dimension 2^(n-1) - 1 (the
             even labels of weight >= 2; n = 1..5): not isomorphic for n >= 2.  Their left multiplications by the generators are sigma_i^+ (no string) and the Jordan-Wigner c_i^+ (n <= 5).
  bd·mjp·35  what the null part adds (D0 -> D1): for n <= 3 the triples (V, Q, pi) of the cells Cl(p,q,r) fall into fewer isometry classes than the
             cells (classes of (n, r, p - q mod 8)); the cells that share a triple include Cl(1,0) and Cl(0,0,1): a Majorana (square +1) and a
             creation operator (square 0) have the same triple (bd·cat·1).
  bd·mjp·36  where the ladders meet (U2 = D3): for every eps in {+1,-1,0}^n (n <= 5), the bit rule restricted to disjoint labels, with the sign
             forgotten, is the partial sum of the labels with the popcount: the same table as the one built upward from F_2^n; it does not depend on
             eps.  The order built from the partial sum (S <= T iff S + c = T for some c) is inclusion.  (The weight is the popcount on both
             sides by definition; it is not compared.)
  bd·mjp·37  the integer weight is a grading only below the squares: the popcount is additive on every non-zero product of the cell exactly when
             every eps_i = 0 (Lambda(R^n)); for eps in {+1,-1}^n the 4^n - 3^n products of overlapping labels are non-zero and break it (every
             eps in {+1,-1,0}^n, n <= 4).  The parity pi stays a grading for every eps (popcount(a xor b) = popcount(a) + popcount(b) mod 2 for
             all a, b: printed, not counted).
  bd·mjp·38  the partial sum is frame data: the automorphisms of (labels, +) are the n! permutations of the generators (brute force, n <= 3); the
             isometries of (V, w) of Cl(p,q) (brute force over GL(n, F_2), n <= 4) number |O(V,w)| = p! q! times the number of partial sums with the
             same form; that number is 1 for every cell with n <= 3 and for Cl(4,0), Cl(0,4), and 2 for Cl(1,3), Cl(2,2), Cl(3,1).
"""
import sys, itertools
from math import comb
import numpy as np

SAB = '--sabotage' in sys.argv
ROWS, FAILS = [], []
def report(cid, ok, text, short):
    ROWS.append(cid)
    if SAB:
        print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  ' + short + '\n       the sabotaged run computes: ' + text)
        if ok: FAILS.append(cid)
    else:
        print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
        if not ok: FAILS.append(cid)
def finish():
    if SAB:
        print('\n' + ('ALL CAUGHT' if not FAILS else f'{len(FAILS)} MISSED: ' + ' '.join(FAILS)))
    else:
        print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

def check33(sab):
    rows = []; ok = True
    for n in range(0, 7):
        D = 1 << n
        defined = sum(1 for a in range(D) for b in range(D) if (a & b) == 0 or sab)     # sabotage: the sum defined everywhere (XOR)
        arrows = sum(1 for S in range(D) for T in range(D) if (S & T) == S)
        comp = sum(1 for S in range(D) for T in range(D) for U in range(D) if (S & T) == S and (T & U) == T)
        nonzero = sum(1 for a in range(D) for b in range(D) if sgn(a, b, [0] * n) != 0)
        chains = []
        for k in range(0, 4):
            cnt = 0
            for ch in itertools.product(range(D), repeat=k + 1):
                if all((ch[i] & ch[i + 1]) == ch[i] for i in range(k)): cnt += 1
            chains.append(cnt)
        good = defined == 3 ** n and arrows == 3 ** n and comp == 4 ** n and nonzero == 3 ** n and all(chains[k] == (k + 2) ** n for k in range(4))
        ok &= good
        rows.append(f'n={n}: {D}, {defined}, {arrows}, {nonzero}, {comp}, chains {chains}')
    return ok, ('labels, defined sums, arrows, non-zero creation products, composable pairs, chains k = 0..3: ' + '; '.join(rows[3:]) +
                f' (n = 0..6 all match 2^n, 3^n, 3^n, 3^n, 4^n, (k+2)^n: {ok})')

def check34(sab):
    ok = True; rows = []
    for n in range(1, 6):
        D = 1 << n
        def zeon(a, b): return 1 if (a & b) == 0 else 0
        def ext(a, b): return sgn(a, b, [0] * n)
        if sab: ext = zeon                                  # sabotage: the sign forgotten on both sides
        def struct(f):
            T = np.zeros((D, D, D), dtype=np.int64)          # T[a, b, c]: coefficient of e_c in e_a e_b
            for a in range(D):
                for b in range(D):
                    s = f(a, b)
                    if s: T[a, b, a ^ b] = s
            return T
        Z, E = struct(zeon), struct(ext)
        same_zero = np.array_equal(np.abs(Z), np.abs(E))
        def comm_dim(T):
            vecs = [T[a, b] - T[b, a] for a in range(D) for b in range(D)]
            return np.linalg.matrix_rank(np.array(vecs)) if any(v.any() for v in vecs) else 0
        cz, ce = comm_dim(Z), comm_dim(E)
        # left multiplications by the generators
        SPm = np.array([[0, 0], [1, 0]]); ZZ = np.diag([1, -1]); I2 = np.eye(2, dtype=int)
        def kron_list(ms):
            out = np.array([[1]])
            for m in ms: out = np.kron(out, m)
            return out
        Lz = all(np.array_equal(Z[1 << i].T, kron_list([SPm if j == i else I2 for j in range(n - 1, -1, -1)])) for i in range(n))
        Le = all(np.array_equal(E[1 << i].T, kron_list([SPm if j == i else (ZZ if j < i else I2) for j in range(n - 1, -1, -1)])) for i in range(n))
        good = same_zero and cz == 0 and (n < 2 or ce > 0) and Lz and Le
        ok &= good
        rows.append(f'n={n}: same zero pattern {same_zero}, commutator space zeon {cz}, Lambda {ce}, L(e_i) = sigma^+ / JW c^+: {Lz}/{Le}')
    return ok, 'hard-core bosons (zeons, the paper\'s partial sum as an algebra) against Lambda(R^n): ' + '; '.join(rows)

def triple(eps):
    n = len(eps); D = 1 << n
    Q = [1 if sgn(a, a, eps) == -1 else 0 for a in range(D)]
    P = [pc(a) % 2 for a in range(D)]
    return Q, P
def isometric(t1, t2, n):
    Q1, P1 = t1; Q2, P2 = t2; D = 1 << n
    for imgs in itertools.permutations(range(1, D), n):
        # images of the basis vectors; check independence and the map on every label
        span = {0}
        okb = True
        for v in imgs:
            if v in span: okb = False; break
            span |= {s ^ v for s in span}
        if not okb: continue
        good = True
        for a in range(D):
            img = 0
            for i in range(n):
                if a >> i & 1: img ^= imgs[i]
            if Q1[a] != Q2[img] or P1[a] != P2[img]: good = False; break
        if good: return True
    return False
def check35(sab):
    ok = True; rows = []; shared_example = False
    for n in range(1, 4):
        cells = [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]
        tr = {c: triple([1] * c[0] + [-1] * c[1] + [0] * c[2]) for c in cells}
        if sab:                                             # sabotage: keep the null part (the quadruple: Q, pi and the null mask)
            nullmask = lambda c: sum(1 << i for i in range(c[0] + c[1], n))
            tr = {c: (tr[c][0], [tr[c][1][a] + 2 * (1 if a and (a & nullmask(c)) == a else 0) for a in range(1 << n)]) for c in cells}
        classes = []
        for c in cells:
            for cl in classes:
                if isometric(tr[c], tr[cl[0]], n): cl.append(c); break
            else: classes.append([c])
        cellclasses = len({(n, c[2], (c[0] - c[1]) % 8) for c in cells})
        if n == 1 and any(set(cl) >= {(1, 0, 0), (0, 0, 1)} for cl in classes): shared_example = True
        ok &= len(classes) < cellclasses
        rows.append(f'n={n}: {len(cells)} cells, {cellclasses} cell classes, {len(classes)} triple classes')
    ok &= shared_example
    return ok, 'isometry classes of (V, Q, pi) against the cells: ' + '; '.join(rows) + f'; Cl(1,0) and Cl(0,0,1) share a triple: {shared_example}'

def check36(sab):
    ok = True; cnt = 0
    for n in range(0, 6):
        D = 1 << n
        up = {(a, b): (a ^ b) for a in range(D) for b in range(D) if (a & b) == 0}     # built upward from F_2^n
        for eps in itertools.product([1, -1, 0], repeat=n):
            eps = list(eps); cnt += 1
            down = {}
            for a in range(D):
                for b in range(D):
                    if (a & b) == 0 or sab:                  # sabotage: the squares not forgotten (overlapping products kept)
                        s = sgn(a, b, eps)
                        if s: down[(a, b)] = a ^ b
            if down != up: ok = False
            # the sign on disjoint pairs does not depend on eps
            if any(sgn(a, b, eps) != sgn(a, b, [0] * n) for (a, b) in up): ok = False
        order = all(((S & T) == S) == any((S & c) == 0 and (S ^ c) == T for c in range(D)) for S in range(D) for T in range(D))
        ok &= order
    return ok, f'the partial sum, built upward and obtained downward by forgetting squares and sign: equal for all {cnt} eps in {{+1,-1,0}}^n, n = 0..5, with the sign on disjoint pairs independent of eps: {ok}; the order of the partial sum is inclusion'

def check37(sab):
    ok = True; rows = []; par = True
    for n in range(1, 5):
        D = 1 << n; graded = {}
        for eps in itertools.product([1, -1, 0], repeat=n):
            eps = list(eps)
            prod_eps = [0] * n if sab else eps               # sabotage: the product of the cell with its squares forgotten (every cell taken as Lambda)
            bad = sum(1 for a in range(D) for b in range(D) if sgn(a, b, prod_eps) != 0 and pc(a ^ b) != pc(a) + pc(b))
            graded[tuple(eps)] = bad
            if (bad == 0) != all(e == 0 for e in eps): ok = False
            if all(e != 0 for e in eps) and bad != 4 ** n - 3 ** n: ok = False
            # the parity is a grading for every eps: pc(a ^ b) = pc(a) + pc(b) mod 2 for all a, b (an identity, printed, not counted)
            par &= not any(sgn(a, b, prod_eps) != 0 and pc(a ^ b) % 2 != (pc(a) + pc(b)) % 2 for a in range(D) for b in range(D))
        rows.append(f'n={n}: popcount a grading for {sum(1 for v in graded.values() if v == 0)} of {3 ** n} eps (only eps = 0), '
                    f'non-graded products for eps = +1: {graded[tuple([1] * n)]} = 4^n - 3^n')
    return ok, '; '.join(rows) + f'; the parity pi is a grading for every eps: {par} (pc(a xor b) = pc(a) + pc(b) mod 2, not counted)'

def w4(a, eps):
    return (pc(a) % 2 + 2 * (1 if sgn(a, a, eps) == -1 else 0)) % 4
def check38(sab):
    from math import factorial
    ok = True; rows = []
    # automorphisms of the partial monoid (labels, +): brute force for n <= 3
    aut = {}
    for n in range(1, 4):
        D = 1 << n; cnt = 0
        for perm in itertools.permutations(range(1, D)):
            f = (0,) + perm
            if all(((f[a] & f[b]) == 0) == ((a & b) == 0) and ((a & b) or f[a ^ b] == f[a] ^ f[b]) for a in range(D) for b in range(D)):
                cnt += 1
        aut[n] = cnt; ok &= cnt == factorial(n)
    # isometries of (V, w) against the frame permutations S_p x S_q, every Cl(p,q) with 1 <= n <= 4
    for n in range(1, 5):
        D = 1 << n
        for p in range(n + 1):
            q = n - p; eps = [1] * p + [-1] * q
            if sab: eps = [1] * n                            # sabotage: the signature forgotten (every cell taken as Cl(n,0))
            w = [w4(a, [1] * p + [-1] * q) for a in range(D)]
            wq = [w4(a, eps) for a in range(D)]
            iso = 0
            for imgs in itertools.permutations(range(1, D), n):
                span = {0}; indep = True
                for v in imgs:
                    if v in span: indep = False; break
                    span |= {x ^ v for x in span}
                if not indep: continue
                good = True
                for a in range(D):
                    img = 0
                    for i in range(n):
                        if a >> i & 1: img ^= imgs[i]
                    if wq[img] != w[a]: good = False; break
                iso += good
            frames = iso // (factorial(p) * factorial(q)) if iso % (factorial(p) * factorial(q)) == 0 else None
            rows.append((p, q, iso, frames))
    bigger = [(p, q, iso, fr) for (p, q, iso, fr) in rows if fr is not None and fr > 1]
    ok &= all(fr is not None for (_, _, _, fr) in rows) and len(bigger) > 0
    ok &= all(fr == (2 if (p, q) in ((1, 3), (2, 2), (3, 1)) else 1) for (p, q, _, fr) in rows)   # the counts the docstring states
    return ok, (f'automorphisms of (labels, +): {[aut[n] for n in (1, 2, 3)]} = n! (n = 1..3); |O(V, w)| and the number of partial sums (frames up to S_p x S_q) '
                f'with the same form w: ' + ', '.join(f'Cl({p},{q}): {iso}, {fr}' for (p, q, iso, fr) in rows if p + q >= 2) +
                f'; cells with more than one partial sum: {len(bigger)}')

CHECKS = [('bd·mjp·33', check33, 'sizes at the rungs: 2^n, 3^n, 4^n, (k+2)^n'),
          ('bd·mjp·34', check34, 'the sign turns hard-core bosons (zeons) into fermions (Lambda)'),
          ('bd·mjp·35', check35, 'forgetting the null part: cells share a triple (Cl(1,0) ~ Cl(0,0,1))'),
          ('bd·mjp·36', check36, 'U2 = D3 for every eps; the order of the partial sum is inclusion'),
          ('bd·mjp·37', check37, 'the popcount is a grading only for eps = 0 (4^n - 3^n products break it for eps = +1)'),
          ('bd·mjp·38', check38, 'the partial sum is frame data: Aut = S_n, O(V, w) larger')]

def main():
    for cid, f, short in CHECKS:
        ok, text = f(SAB)
        report(cid, ok, text, short)
    finish()

if __name__ == '__main__':
    main()
