#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sol_lattice_springs.py: the spring and rigid-body steps (steps 15, 16) and the signed cube read in lattice language.

  bd·sol·18  the pi-flux (Kogut-Susskind staggered) lattice on Z^n with hopping phases eta_mu(x) = (-1)^(x_1 + ... + x_(mu-1)): its magnetic unit
             cell is the n-cube of bit labels, the phases are the bit-rule signs of L_{e_mu} in Cl(n,0), and the Bloch Hamiltonian is
             H(k) = sum_mu 2 cos(k_mu) L_mu; H(0) = 2 D with D the signed cube of step 15 (D^2 = nI), H(k)^2 = 4 sum cos^2 k_mu (n = 2, 3, 4);
             the real-space spectrum of periodic lattices equals the union of the H(k) spectra (n = 2, 3).  At the Dirac point k_mu = pi/2
             the 2^n-fold zero level is (complex irrep dimension 2^floor(n/2)) x (tastes 2^ceil(n/2)).
  bd·sol·19  the vector-displacement spring network of the n-cube frame (2^n nodes, n 2^(n-1) bars) in n dimensions: rank of the compatibility
             matrix, zero modes = C(n+1,2) rigid motions (the bivectors of the PGA Cl(n,0,1)) + mechanisms, no state of self-stress; n = 2: 1
             mechanism, n = 3: 6, n = 4: 22, n = 5: 65; a cube braced by one diagonal per face (18 bars) is rigid (6 zero modes).  The
             Calladine / Kane-Lubensky index N_0 - N_ss = dN - N_b and the chiral (BDI) form H = [[0, C], [C^T, 0]] with
             H^2 = diag(C C^T, C^T C) hold.
  bd·sol·20  on a ring the sign is not unique up to gauge (unlike the cube, T6 (a)): periodic and antiperiodic boundary conditions of a Kitaev
             ring (N = 12, t = Delta = 1) are the two classes of H^1(S^1; F_2).  The ground-state fermion parity (the sign of the Pfaffian of
             the Majorana matrix) differs between them exactly in the topological phase |mu| < 2t (mu = 0, 0.8, 1.5 against 2.5, 3.5): the
             measurable face of a sign class (fermion-parity switch, 4 pi Josephson).
  bd·sol·30  fermion doubling: the naive first-order stencil sum sin(k_mu) Gamma_mu vanishes at all 2^d corners of the Brillouin zone
             (d = 1..4); a Wilson mass (one more anticommuting generator) leaves one (the lattice stencils of SHP-003).

  python3 sol_lattice_springs.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; about a second."""
import itertools, math, sys
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Lmat(n, mu):
    N = 1 << n; M = np.zeros((N, N)); eps = [1] * n
    for a in range(N): M[a ^ (1 << mu), a] = sgn(1 << mu, a, eps)
    return M

# ================================================================ 18: pi-flux lattice
def eta(x, mu): return (-1) ** (sum(x[:mu]) % 2)
def real_space(n, m):
    Ls = 2 * m; sites = list(itertools.product(range(Ls), repeat=n)); idx = {s: i for i, s in enumerate(sites)}
    H = np.zeros((len(sites), len(sites)))
    for x in sites:
        for mu in range(n):
            y = list(x); y[mu] = (y[mu] + 1) % Ls; y = tuple(y)
            H[idx[y], idx[x]] += eta(x, mu); H[idx[x], idx[y]] += eta(x, mu)
    return H
def check18():
    ok = True; info = []
    for n in (2, 3, 4):
        L = [Lmat(n, mu) for mu in range(n)]
        ok &= all(np.allclose(L[a] @ L[b] + L[b] @ L[a], 2 * (a == b) * np.eye(1 << n)) for a in range(n) for b in range(n))
        ok &= all(np.allclose(M, M.T) for M in L)
        # bit-rule sign of L_mu on label a equals the KS phase eta_mu(bits of a)
        for a in range(1 << n):
            bits = [(a >> i) & 1 for i in range(n)]
            for mu in range(n): ok &= (L[mu][a ^ (1 << mu), a] == eta(bits, mu))
        D = sum(L); ok &= np.allclose(D @ D, n * np.eye(1 << n))
        Hk = lambda k: sum(2 * math.cos(k[mu]) * L[mu] for mu in range(n))
        ok &= np.allclose(Hk([0] * n), 2 * D)
        rng = np.random.default_rng(18)
        for _ in range(5):
            k = rng.uniform(0, math.pi, n); ok &= np.allclose(Hk(k) @ Hk(k), 4 * sum(math.cos(x) ** 2 for x in k) * np.eye(1 << n))
        if n <= 3:
            m = 2; Hr = real_space(n, m); er = np.sort(np.linalg.eigvalsh(Hr))
            eb = np.sort(np.concatenate([np.linalg.eigvalsh(Hk([math.pi * j / m for j in js])) for js in itertools.product(range(m), repeat=n)]))
            ok &= np.allclose(er, eb)
            info.append(f'n={n}: real space {Hr.shape[0]} sites = union of H(k) spectra')
        zeros = int(np.sum(np.abs(np.linalg.eigvalsh(Hk([math.pi / 2] * n))) < 1e-9))
        irr = 2 ** (n // 2); tastes = (1 << n) // irr
        ok &= zeros == (1 << n) and tastes == 2 ** ((n + 1) // 2)
        info.append(f'n={n}: Dirac point zero level {zeros} = {irr} x {tastes} tastes')
    row('bd·sol·18', ok, 'pi-flux lattice: KS phases = bit-rule signs, H(k) = sum 2 cos k_mu L_mu, H(0) = 2D, H(k)^2 = 4 sum cos^2 k_mu; ' + '; '.join(info))

# ================================================================ 19: rigidity of n-cube frames
def frame(n, braced=False):
    nodes = [np.array([(a >> i) & 1 for i in range(n)], dtype=float) for a in range(1 << n)]
    bars = [(a, a ^ (1 << i)) for a in range(1 << n) for i in range(n) if not (a >> i) & 1]
    if braced and n == 3:
        for i, j in itertools.combinations(range(3), 2):                     # one diagonal per face: 6 faces
            for fixed in (0, 1):
                k = 3 - i - j
                a = (fixed << k); b = a | (1 << i) | (1 << j)
                bars.append((a, b))
    return nodes, bars
def compat(n, nodes, bars):
    C = np.zeros((len(bars), n * len(nodes)))
    for r, (a, b) in enumerate(bars):
        d = nodes[b] - nodes[a]; d = d / np.linalg.norm(d)
        C[r, n * a:n * a + n] = -d; C[r, n * b:n * b + n] = d
    return C
def rigid_fields(n, nodes):
    F = []
    for i in range(n):                                                      # translations
        v = np.zeros(n * len(nodes))
        for a in range(len(nodes)): v[n * a + i] = 1
        F.append(v)
    for i, j in itertools.combinations(range(n), 2):                        # rotations in the (i,j) plane
        v = np.zeros(n * len(nodes))
        for a, x in enumerate(nodes):
            v[n * a + i] = -x[j]; v[n * a + j] = x[i]
        F.append(v)
    return np.array(F)
def check19():
    ok = True; lines = []
    expect_mech = {2: 1, 3: 6, 4: 22, 5: 65}
    for n in (2, 3, 4, 5):
        nodes, bars = frame(n); C = compat(n, nodes, bars)
        rk = np.linalg.matrix_rank(C); N0 = C.shape[1] - rk; Nss = C.shape[0] - rk
        R = rigid_fields(n, nodes)
        in_ker = np.allclose(C @ R.T, 0) and np.linalg.matrix_rank(R) == math.comb(n + 1, 2)
        mech = N0 - math.comb(n + 1, 2)
        index_ok = (N0 - Nss) == n * len(nodes) - len(bars)
        Hc = np.block([[np.zeros((C.shape[0], C.shape[0])), C], [C.T, np.zeros((C.shape[1], C.shape[1]))]])
        chiral_ok = np.allclose(Hc @ Hc, np.block([[C @ C.T, np.zeros((C.shape[0], C.shape[1]))], [np.zeros((C.shape[1], C.shape[0])), C.T @ C]]))
        zero_H = int(np.sum(np.abs(np.linalg.eigvalsh(Hc)) < 1e-9)) == N0 + Nss
        ok &= in_ker and index_ok and chiral_ok and zero_H and Nss == 0 and mech == expect_mech[n]
        lines.append(f'n={n}: {len(nodes)} nodes, {len(bars)} bars, zero modes {N0} = {math.comb(n + 1, 2)} rigid + {mech} mechanisms, self-stress {Nss}')
    nodes, bars = frame(3, braced=True); C = compat(3, nodes, bars)
    rk = np.linalg.matrix_rank(C); N0 = C.shape[1] - rk; Nss = C.shape[0] - rk
    ok &= (len(bars) == 18 and N0 == 6 and Nss == 0)
    lines.append(f'braced cube: {len(bars)} bars, zero modes {N0}, self-stress {Nss}')
    row('bd·sol·19', ok, 'n-cube frames: ' + '; '.join(lines) + '; rigid motions = C(n+1,2) PGA bivectors; Calladine index and the chiral form H = [[0,C],[C^T,0]] hold')

# ================================================================ 20: Kitaev ring, sign classes = spin structures
def pfaffian(A):
    A = A.astype(float).copy(); n = A.shape[0]
    if n % 2: return 0.0
    pf = 1.0
    for k in range(0, n - 1, 2):
        kp = k + 1 + int(np.argmax(np.abs(A[k + 1:, k])))
        if kp != k + 1:
            A[[k + 1, kp], :] = A[[kp, k + 1], :]; A[:, [k + 1, kp]] = A[:, [kp, k + 1]]; pf = -pf
        if A[k + 1, k] == 0: return 0.0
        pf *= A[k, k + 1]
        if k + 2 < n:
            tau = A[k, k + 2:] / A[k, k + 1]
            A[k + 2:, k + 2:] += np.outer(tau, A[k + 1, k + 2:]) - np.outer(A[k + 1, k + 2:], tau)
    return pf
def kitaev_ring_A(N, t, mu, delta, bc):
    """Majorana matrix A (H = (i/4) sum A_jk g_j g_k) for H = sum -mu (c^+c - 1/2) - t (c^+_j c_{j+1} + h.c.) + delta (c_j c_{j+1} + h.c.);
    bc = +1 periodic, -1 antiperiodic.  Majoranas a_j = c + c^+, b_j = -i (c - c^+)."""
    A = np.zeros((2 * N, 2 * N))
    def add(j, k, v): A[j, k] += v; A[k, j] -= v
    for j in range(N):
        add(2 * j, 2 * j + 1, -mu)                                          # -mu c^+c = (i mu / 2) a b + const
        s = bc if j == N - 1 else 1; k = (j + 1) % N
        add(2 * j + 1, 2 * k, s * (t + delta)); add(2 * j, 2 * k + 1, -s * (t - delta))
    return A
def ground_parity(A):
    return int(np.sign(pfaffian(A)))
def check20():
    ok = True; lines = []
    for mu in (0.0, 0.8, 1.5, 2.5, 3.5):
        pp = ground_parity(kitaev_ring_A(12, 1.0, mu, 1.0, +1)); pa = ground_parity(kitaev_ring_A(12, 1.0, mu, 1.0, -1))
        topo = abs(mu) < 2
        if (pp != pa) != topo: ok = False
        lines.append(f'mu={mu}: Pf sign PBC {pp:+d}, APBC {pa:+d}')
    row('bd·sol·20', ok, 'Kitaev ring N = 12, t = Delta = 1: ' + '; '.join(lines) + '  (parities differ iff |mu| < 2t)')

# ================================================================ 30: fermion doubling of first-order stencils (SHP-003, lattice stencils)
def check30():
    ok = True; lines = []
    for d in (1, 2, 3, 4):
        # naive symmetric-difference Dirac stencil: symbol h(k) = sum_mu sin(k_mu) Gamma_mu, Gamma_mu the bit-rule L_mu (Clifford)
        L = [Lmat(d, mu) for mu in range(d)]
        grid = [0.0, math.pi / 2, math.pi, 3 * math.pi / 2]
        zeros = 0
        for k in itertools.product([0.0, math.pi], repeat=d):
            Hk = sum(math.sin(k[mu]) * L[mu] for mu in range(d)); zeros += int(np.allclose(Hk, 0))
        # Wilson term r sum (1 - cos k_mu) times a matrix anticommuting with all Gamma_mu (exists in Cl(d+1,0)): only k = 0 stays gapless
        Lw = [Lmat(d + 1, mu) for mu in range(d + 1)]
        wil = 0
        for k in itertools.product([0.0, math.pi], repeat=d):
            Hk = sum(math.sin(k[mu]) * Lw[mu] for mu in range(d)) + sum(1 - math.cos(x) for x in k) * Lw[d]
            wil += int(np.min(np.abs(np.linalg.eigvalsh(Hk))) < 1e-9)
        ok &= zeros == 2 ** d and wil == 1
        lines.append(f'd={d}: naive zeros {zeros} = 2^d, with a Wilson mass {wil}')
    row('bd·sol·30', ok, 'first-order lattice stencils: ' + '; '.join(lines) + ' (the Wilson mass is an extra anticommuting generator: it breaks the chiral symmetry it anticommutes with); the pi-flux staggering of bd·sol·18 keeps 2^ceil(d/2) tastes')

if __name__ == '__main__':
    for f in (check18, check19, check20, check30): f()
    finish()
