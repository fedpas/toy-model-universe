#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""str_spinors.py: spinors and supersymmetry in D = 2..12 from the bit rule.

  bd·str·6  the type of the even part Cl^0(s,t) (Frobenius-Schur count over the even blades and the centre), for s + t = D <= 12, is a function
            of s - t mod 8 alone and is the same for (s,t) and (t,s); Majorana-Weyl (Cl^0 of type R+R) exactly when s - t = 0 mod 8
            (worldsheet (1,1), target (9,1)).
  bd·str·7  Hull's exotic signatures from the even part alone: IIA (32 real supercharges, non-chiral) and IIB (chiral 32 real supercharges and
            real self-dual 5-forms, i.e. top blade of square +1) for s + t = 10, M (a real 32-component spinor) for s + t = 11; with s >= t
            the lists are those of Hull (hep-th/9807127, abstract), and each list is closed under s <-> t.  Hull's criteria are the input.
  bd·str·8  the Hodge star on middle forms of Cl(D-1,1) squares to the square of the top blade: real self-dual middle forms in Lorentzian
            D = 2, 6, 10 (D = 2 mod 4), a complex structure (duality rotation) in D = 4, 8, 12.
  bd·str·9  the 3-psi rule (psi.psi)psi = 0 for the minimal real spinor of Spin(D-1,1), all invariant symmetric pairings S x S -> V, built from
            minimal left ideals of the bit-rule Cl(D-1,1) (12 random integer psi per D): it holds exactly for D = 3, 4, 6, 10 among D = 3..11.

  python3 str_spinors.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; a few seconds."""
import itertools, sys
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q): return [1] * p + [-1] * q

# ---------------------------------------------------------------- type of the even part from the bit rule
def even_type(eps):
    """(k, D, N) with Cl^0 = M_N(D)^k: centre from the top blade (in Cl^0 for even n), FS count over even blades"""
    n = len(eps); top = (1 << n) - 1
    ev = [a for a in range(1 << n) if pc(a) % 2 == 0]
    nu = sum(sgn(a, a, eps) for a in ev)
    k, cplx = 1, False
    if n % 2 == 0 and n > 0:
        if sgn(top, top, eps) == 1: k = 2
        else: cplx = True
    if cplx or nu == 0: D = 'C'
    elif nu > 0: D = 'R'
    else: D = 'H'
    dimD = {'R': 1, 'C': 2, 'H': 4}[D]
    N = int(round((len(ev) / (k * dimD)) ** 0.5))
    assert k * N * N * dimD == len(ev)
    return k, D, N
def spinor_dim(t):                                 # real dimension of an irreducible module of one simple factor
    k, D, N = t; return N * {'R': 1, 'C': 2, 'H': 4}[D]

def check6():
    ok = True; table = {}
    for D in range(2, 13):
        for s in range(D + 1):
            t = D - s; ty = even_type(sig(s, t))
            key = (s - t) % 8
            if (key, D % 2) in table and table[(key, D % 2)][:2] != ty[:2]: ok = False
            table[(key, D % 2)] = ty
            if even_type(sig(t, s)) != ty: ok = False                     # mirror invariance of Cl^0 (core·B5c)
            mw = ty[0] == 2 and ty[1] == 'R'
            if mw != ((s - t) % 8 == 0): ok = False
    names = {(c, par): f'{table[(c, par)][0] if table[(c, par)][0] > 1 else ""}{table[(c, par)][1]}' for (c, par) in table}
    ev = ', '.join(f's-t={c}:{names[(c, 0)]}' for c in range(0, 8, 2))
    od = ', '.join(f's-t={c}:{names[(c, 1)]}' for c in range(1, 8, 2))
    row('bd·str·6', ok, f'the even part Cl^0(s,t) (the algebra of Spin(s,t)), for every s + t = D <= 12, depends only on s - t mod 8 and is the same for (s,t) and (t,s): even D {ev}; odd D {od}. Majorana-Weyl spinors (Cl^0 = R+R) exactly when s - t = 0 mod 8: (1,1) worldsheet, (9,1), (5,5), (1,9) target')

# ---------------------------------------------------------------- Hull's signatures
HULL = {'M': [(10, 1), (9, 2), (6, 5)], 'IIA': [(10, 0), (9, 1), (8, 2), (6, 4), (5, 5)], 'IIB': [(9, 1), (7, 3), (5, 5)]}
def check7():
    pred = {'M': [], 'IIA': [], 'IIB': []}; full = {'M': [], 'IIA': [], 'IIB': []}
    for s in range(12):
        t = 11 - s
        if t >= 0:
            ty = even_type(sig(s, t))
            if ty[1] == 'R' and spinor_dim(ty) == 32: full['M'].append((s, t))      # a real 32-component spinor of Spin(s,t)
    for s in range(11):
        t = 10 - s; e = sig(s, t); ty = even_type(e); top = (1 << 10) - 1
        w = spinor_dim(ty)
        # IIB: a chiral real 32 (real chirality: top blade square +1, two simple factors) and real self-dual 5-forms (same condition)
        if ty[0] == 2 and sgn(top, top, e) == 1 and w in (16, 32): full['IIB'].append((s, t))
        # IIA: a non-chiral real 32 containing both chiralities once: R+R (16 + 16') or C (one complex Weyl 16 = real 32 = S + S-bar)
        if (ty[0] == 2 and ty[1] == 'R' and w == 16) or (ty[0] == 1 and ty[1] == 'C' and w == 32): full['IIA'].append((s, t))
    for kname in pred: pred[kname] = [st for st in full[kname] if st[0] >= st[1]]
    ok = all(sorted(pred[k_]) == sorted(HULL[k_]) for k_ in HULL)
    ok = ok and all(sorted(full[k_]) == sorted(set(full[k_]) | {(t_, s_) for s_, t_ in full[k_]}) for k_ in full)
    row('bd·str·7', ok, f'from the even part alone: M-theory-type signatures (real 32-spinor, s + t = 11) {full["M"]}; IIA-type (s + t = 10) {full["IIA"]}; IIB-type {full["IIB"]}; with s >= t these are exactly the lists of Hull (hep-th/9807127, abstract): M (10,1), (9,2), (6,5); IIA (10,0), (9,1), (8,2), (6,4), (5,5); IIB (9,1), (7,3), (5,5); each list is closed under s <-> t (core·B5c)')

# ---------------------------------------------------------------- Hodge star on middle forms
def check8():
    ok = True; real_sd = []
    for D in range(2, 13, 2):
        e = sig(D - 1, 1); top = (1 << D) - 1; k = D // 2
        # star(e_a) = e_a * top (right multiplication by the top blade) maps grade k to grade D - k = k; star^2 = top^2 on every blade
        sq = set()
        for a in range(1 << D):
            if pc(a) != k: continue
            b = a ^ top; s1 = sgn(a, top, e); s2 = sgn(b, top, e)
            sq.add(s1 * s2)
        if sq != {sgn(top, top, e)}: ok = False
        if sgn(top, top, e) == 1: real_sd.append(D)
    ok = ok and real_sd == [2, 6, 10]
    row('bd·str·8', ok, f'in Cl(D-1,1) right multiplication by the top blade maps middle-grade blades to middle-grade blades and squares to the top-blade square: +1 (real self-dual middle forms: chiral boson, 6d tensor, IIB 5-form) exactly for D in {real_sd} among D = 2..12 even; -1 (a complex structure: electric-magnetic duality rotation) for D = 4, 8, 12')

# ---------------------------------------------------------------- the 3-psi rule
def left_op(g, eps):
    N = 1 << len(eps); perm = np.array([a ^ g for a in range(N)]); s = np.array([sgn(g, a, eps) for a in range(N)], float)
    return perm, s
def apply(op, X):
    perm, s = op; Y = np.zeros_like(X); Y[perm] = s[:, None] * X; return Y
def mul(x, y, eps):
    out = np.zeros(len(x))
    for a in np.nonzero(x)[0]:
        for b in np.nonzero(y)[0]:
            out[a ^ b] += x[a] * y[b] * sgn(int(a), int(b), eps)
    return out
def even_idempotent(eps):
    """primitive idempotent of Cl^0: product of (1 + e_a)/2 over a greedy maximal set of commuting even blades of square +1"""
    n = len(eps); N = 1 << n; chosen, span = [], {0}
    for a in range(1, N):
        if pc(a) % 2 or a in span or sgn(a, a, eps) != 1: continue
        if any(sgn(a, b, eps) != sgn(b, a, eps) for b in chosen): continue
        chosen.append(a); span |= {x ^ a for x in span}
    f = np.zeros(N); f[0] = 1.0
    for a in chosen:
        g = np.zeros(N); g[0] = 0.5; g[a] = 0.5; f = mul(f, g, eps)
    return f
def ideal_basis(eps, f, parity):
    n = len(eps); N = 1 << n; labs = [a for a in range(N) if pc(a) % 2 == parity]
    cols = np.zeros((N, len(labs))); nz = np.nonzero(f)[0]
    for j, a in enumerate(labs):
        for b in nz: cols[a ^ b, j] += f[b] * sgn(a, int(b), eps)
    U, S, Vt = np.linalg.svd(cols, full_matrices=False)
    r = int((S > 1e-8 * S[0]).sum()); return U[:, :r]
def nullspace(M, tol=1e-8):
    if M.shape[0] == 0: return np.eye(M.shape[1])
    G = M.T @ M; w, V = np.linalg.eigh(G)
    return V[:, w < tol * max(1.0, w.max())]
def three_psi(D, seed=0):
    eps = [1] * (D - 1) + [-1]                     # mostly plus; the last generator is time
    f = even_idempotent(eps)
    QS = ideal_basis(eps, f, 0); QT = ideal_basis(eps, f, 1)      # S = Cl^0 f (spinor), T = Cl^1 f (the image of V x S)
    d, dt = QS.shape[1], QT.shape[1]
    G = [QT.T @ apply(left_op(1 << m, eps), QS) for m in range(D)]                  # Gamma_mu : S -> T
    gens = [(1 << m) | (1 << (m + 1)) for m in range(D - 1)]                         # e_m e_{m+1} generate spin(D-1,1)
    XS = [QS.T @ apply(left_op(g, eps), QS) for g in gens]
    XT = [QT.T @ apply(left_op(g, eps), QT) for g in gens]
    # invariant bilinear forms beta(psi, chi) = psi^T A chi on S x T: XS^T A + A XT = 0  (vec(A) column-major)
    rows = []
    for a_, b_ in zip(XS, XT):
        rows.append(np.kron(np.eye(dt), a_.T) + np.kron(b_.T, np.eye(d)))
    NS = nullspace(np.vstack(rows))
    As = [NS[:, j].reshape((d, dt), order='F') for j in range(NS.shape[1])]
    # symmetric pairings S x S -> V: B_mu(psi, phi) = beta(psi, Gamma_mu phi), symmetrised
    Sym = [[0.5 * (A @ Gm + (A @ Gm).T) for Gm in G] for A in As]
    vecS = np.array([np.concatenate([m.ravel() for m in s_]) for s_ in Sym]).T if Sym else np.zeros((0, 0))
    rk_sym = np.linalg.matrix_rank(vecS, tol=1e-8) if Sym else 0
    # 3-psi: sum_mu eps_mu B_mu(psi,psi) Gamma_mu psi = 0, linear in the coefficients of the pairing
    rng = np.random.RandomState(seed + D); cons = []
    for _ in range(12):
        psi = rng.randint(-3, 4, size=d).astype(float)
        cols = []
        for s_ in Sym:
            v = np.zeros(dt)
            for m in range(D): v += eps[m] * (psi @ s_[m] @ psi) * (G[m] @ psi)
            cols.append(v)
        cons.append(np.array(cols).T)
    C = np.vstack(cons) if Sym else np.zeros((0, 0))
    # dimension of {coefficients with 3-psi} modulo {coefficients with Sym = 0}
    K3 = nullspace(C) if Sym else np.zeros((0, 0))
    K0 = nullspace(vecS) if Sym else np.zeros((0, 0))
    d3 = (K3.shape[1] - K0.shape[1]) if Sym else 0
    # nullness of psi.psi (a corollary) for the solutions
    return d, rk_sym, d3
def check9():
    res = {}; ok = True
    for D in range(3, 12):
        d, rs, d3 = three_psi(D)
        res[D] = (d, rs, d3)
        holds = rs >= 1 and d3 == rs
        if holds != (D in (3, 4, 6, 10)) or rs < 1: ok = False
    want_d = {3: 2, 4: 4, 5: 8, 6: 8, 7: 16, 8: 16, 9: 16, 10: 16, 11: 32}
    ok = ok and all(res[D][0] == want_d[D] for D in res)
    txt = '; '.join(f'D={D}: dim S={res[D][0]}, pairings={res[D][1]}, with 3-psi={res[D][2]}' for D in res)
    row('bd·str·9', ok, 'the 3-psi rule (psi.psi)psi = 0 (Baez-Huerta I, Sec. 4) with S = Cl^0 f a minimal left ideal of the bit-rule Cl(D-1,1), V x S -> Cl^1 f by left multiplication, all Spin-invariant symmetric pairings S x S -> V: ' + txt + '. It holds for every pairing exactly when D = 3, 4, 6, 10 and for none otherwise')

if __name__ == '__main__':
    check6(); check7(); check8(); check9()
    finish()
