#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sol_point_groups.py: the finite-group lens (step 17), the mirror and the types read as point groups, double groups, time reversal and
Weyl nodes.

  bd·sol·21  the 3-bit labels are the orthorhombic point group mmm (D2h): a -> diag((-1)^a_i) is an isomorphism (XOR = product), and pi(a) = 1
             exactly for the improper operations (det = -1: three mirrors and the inversion).  The spin-1/2 double group with the standard
             convention (inversion acts as +1 on spinors) is the sign table of Cl(0,3): the mirror lifts M_k = I (x) (-i sigma_k) satisfy
             M_a M_b = s_{Cl(0,3)}(a,b) M_{a xor b} for all 64 pairs; with the other convention (inversion as i) the sign table is that of
             Cl(3,0).  The two are the mirror pair Cl(0,3) / Cl(3,0): a rephasing of the improper elements by i, allowed for charged fermions
             (U(1)), not for Majorana (real) ones, whose Pin+/Pin- choice is the T^2 = -1 / +1 distinction of bd·sol·2.
  bd·sol·22  B_3 (signed permutations, the cube as a group of mirrors, step 3) has order 48 and is the cubic point group O_h = m-3m (it contains
             the inversion; rotation subgroup of order 24 with element orders {1:1, 2:9, 3:8, 4:6}); D_3 (even sign changes) has order 24, no
             inversion, and the element-order profile of T_d.  Crystallographic restriction: every element of B_3 and of the tetrahedral
             rotation group (image of 2.A4, the 24 Hurwitz units) has integer trace; the icosahedral group (image of 2.A5, the 120 icosians)
             has traces (1 +- sqrt5)/2, so 2.A5 is the double group of a non-crystallographic point group.
  bd·sol·23  types and time reversal (Dyson/Wigner): for every Cl(p,q) with n <= 4, the finite group G = {+-e_a} on an irreducible complex
             module has Frobenius-Schur indicator +1, 0, -1 exactly for the types R, C, H of the type table (the sign of nu, T4 (iv)); for
             FS = +-1 an antiunitary T = U K commuting with G exists and T^2 = FS; for the H type every G-invariant Hermitian operator is
             (Kramers) doubly degenerate.
  bd·sol·24  Weyl nodes: in the Pauli cell Cl(3,0) = M_2(C) no nonzero 2x2 matrix anticommutes with sigma_x, sigma_y, sigma_z (the node of
             H = chi sigma.k cannot be gapped), while the Hermitian masses anticommuting with the 4x4 Dirac matrices sigma_x (x) sigma_k span a
             real 2-dimensional space (one mass up to a U(1) rotation); the chirality chi = +-1 is the eigenvalue sign of the central
             pseudoscalar sigma_x sigma_y sigma_z = chi i, and the lower band of H = chi sigma.k carries Chern number -chi on a sphere around
             the node (Fukui-Hatsugai lattice computation): Berry monopole charge = central element.

  python3 sol_point_groups.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; about a second."""
import itertools, math, sys
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
sx = np.array([[0, 1], [1, 0]], dtype=complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], dtype=complex)
S = [sx, sy, sz]; I2 = np.eye(2)

# ================================================================ 21: mmm and its double groups
def check21():
    ok = True
    D = {a: np.diag([(-1) ** ((a >> i) & 1) for i in range(3)]) for a in range(8)}
    ok &= all(np.allclose(D[a] @ D[b], D[a ^ b]) for a in range(8) for b in range(8))
    ok &= all((round(np.linalg.det(D[a])) == -1) == (pc(a) % 2 == 1) for a in range(8))
    def lifts(inv_phase):
        # spinor (x) parity: inversion acts as inv_phase on spinors and flips the parity label; rotations C2_k = -i sigma_k
        P = np.array([[0, 1], [1, 0]], dtype=complex)                     # inversion on a 2-dim 'parity' space (even/odd orbital)
        Inv = inv_phase * np.kron(I2, P)
        C2 = [np.kron(-1j * s, np.eye(2)) for s in S]
        M = [Inv @ c for c in C2]                                          # mirror = inversion x C2 about the normal
        def Ma(a):
            X = np.eye(4, dtype=complex)
            for i in range(3):
                if a >> i & 1: X = X @ M[i]
            return X
        return Ma, M
    Ma, M = lifts(1.0)
    ok_std = all(np.allclose(Ma(a) @ Ma(b), sgn(a, b, [-1, -1, -1]) * Ma(a ^ b)) for a in range(8) for b in range(8))
    ok_std &= all(np.allclose(m @ m, -np.eye(4)) for m in M)
    Ma2, M2 = lifts(1j)
    ok_alt = all(np.allclose(Ma2(a) @ Ma2(b), sgn(a, b, [1, 1, 1]) * Ma2(a ^ b)) for a in range(8) for b in range(8))
    # group structure: standard convention gives Q8 x Z2 (element orders), Cl(3,0) convention the Pauli group
    def orders(Mf):
        els = [s * Mf(a) for a in range(8) for s in (1, -1)]
        prof = {}
        for g in els:
            k, X = 1, g.copy()
            while not np.allclose(X, np.eye(4)): X = X @ g; k += 1
            prof[k] = prof.get(k, 0) + 1
        return dict(sorted(prof.items()))
    o_std, o_alt = orders(Ma), orders(Ma2)
    ok &= ok_std and ok_alt and o_std == {1: 1, 2: 3, 4: 12} and o_alt == {1: 1, 2: 7, 4: 8}
    row('bd·sol·21', ok, f'3-bit labels = mmm (XOR = product, pi = improper); spin-1/2 double group with inversion = +1: sign table of Cl(0,3) (mirror lifts square -1), element orders {o_std} (Q8 x Z2); inversion = i: sign table of Cl(3,0), orders {o_alt} (Pauli group)')

# ================================================================ 22: O_h, T_d, crystallographic restriction
def gen_group(gens):
    els = [np.eye(gens[0].shape[0])]; frontier = [np.eye(gens[0].shape[0])]
    key = lambda M: tuple(np.round(M, 6).flatten())
    seen = {key(els[0])}
    while frontier:
        new = []
        for A in frontier:
            for g in gens:
                B = g @ A; k = key(B)
                if k not in seen: seen.add(k); els.append(B); new.append(B)
        frontier = new
    return els
def order_of(M):
    k, X = 1, M.copy()
    while not np.allclose(X, np.eye(len(M))): X = X @ M; k += 1
    return k
def quat_to_rot(q):
    a, b, c, d = q
    return np.array([[a*a+b*b-c*c-d*d, 2*(b*c-a*d), 2*(b*d+a*c)], [2*(b*c+a*d), a*a-b*b+c*c-d*d, 2*(c*d-a*b)], [2*(b*d-a*c), 2*(c*d+a*b), a*a-b*b-c*c+d*d]])
def check22():
    mir = [np.diag([-1 if i == k else 1 for i in range(3)]).astype(float) for k in range(3)]
    perms = [np.eye(3)[list(p)] for p in itertools.permutations(range(3))]
    B3 = gen_group(mir + perms)
    ok = len(B3) == 48 and any(np.allclose(g, -np.eye(3)) for g in B3)
    rot = [g for g in B3 if np.linalg.det(g) > 0]
    prof = {}
    for g in rot: k = order_of(g); prof[k] = prof.get(k, 0) + 1
    ok &= len(rot) == 24 and prof == {1: 1, 2: 9, 3: 8, 4: 6}
    # D_3: signed permutation matrices with an even number of minus signs
    D3 = [g for g in B3 if (np.sum(g < 0) % 2) == 0]
    ok &= len(D3) == 24 and not any(np.allclose(g, -np.eye(3)) for g in D3)
    profD = {}
    for g in D3: k = order_of(g); profD[k] = profD.get(k, 0) + 1
    # T_d = 43m: E, 8 C3, 3 C2, 6 S4, 6 sigma_d -> orders {1:1, 2:9, 3:8, 4:6}
    ok &= profD == {1: 1, 2: 9, 3: 8, 4: 6} and sum(1 for g in D3 if np.linalg.det(g) < 0) == 12
    # Hurwitz units (2.A4) and icosians (2.A5)
    hur = [q for q in itertools.product([0, 1, -1], repeat=4) if sum(x * x for x in q) == 1]
    hur += [tuple(s * 0.5 for s in sg) for sg in itertools.product([1, -1], repeat=4)]
    phi = (1 + 5 ** 0.5) / 2
    ico = set()
    for q in hur: ico.add(tuple(np.round(q, 9)))
    base = [(0.5, phi / 2, 1 / (2 * phi), 0.0)]
    even_perms = [p for p in itertools.permutations(range(4)) if sum(1 for i in range(4) for j in range(i + 1, 4) if p[i] > p[j]) % 2 == 0]
    for b in base:
        for p in even_perms:
            for sg in itertools.product([1, -1], repeat=4):
                v = tuple(np.round([sg[i] * b[p[i]] for i in range(4)], 9)); ico.add(v)
    ico = [np.array(v) for v in ico]
    rots_T = {tuple(np.round(quat_to_rot(q), 9).flatten()) for q in hur}
    rots_I = {tuple(np.round(quat_to_rot(q), 9).flatten()) for q in ico}
    tr_T = sorted({float(round(np.trace(np.array(r).reshape(3, 3)), 6)) for r in rots_T})
    tr_I = sorted({float(round(np.trace(np.array(r).reshape(3, 3)), 6)) for r in rots_I})
    integral_T = all(abs(t - round(t)) < 1e-6 for t in tr_T)
    nonint_I = [t for t in tr_I if abs(t - round(t)) > 1e-6]
    ok &= len(hur) == 24 and len(ico) == 120 and len(rots_T) == 12 and len(rots_I) == 60 and integral_T and sorted(np.round(nonint_I, 6)) == sorted(np.round([(1 - 5 ** 0.5) / 2, (1 + 5 ** 0.5) / 2], 6))
    ok &= all(abs(np.trace(g) - round(np.trace(g))) < 1e-9 for g in B3)
    row('bd·sol·22', ok, f'B_3 order {len(B3)} = O_h (inversion included; rotations {len(rot)} with orders {dict(sorted(prof.items()))}); D_3 order {len(D3)}, no inversion, orders {dict(sorted(profD.items()))} = T_d; 2.A4 -> {len(rots_T)} rotations, traces {tr_T} (crystallographic); 2.A5 -> {len(rots_I)} rotations, traces {tr_I} (non-integral: not a lattice point group)')

# ================================================================ 23: Frobenius-Schur = time-reversal type
def complex_irrep(p, q):
    """an irreducible complex module of Cl(p,q): n even: JW gammas on n/2 qubits; n odd: JW gammas on (n-1)/2 qubits plus the chirality
    Gamma = i^m g_0 ... g_(2m-1) (one of the two irreps).  The minus generators get a factor i."""
    n = p + q; m = n // 2
    def kron(*ms):
        o = np.array([[1]], dtype=complex)
        for x in ms: o = np.kron(o, x)
        return o
    g = []
    for j in range(m):
        for P in (sx, sy): g.append(kron(*([sz] * j + [P] + [I2] * (m - j - 1))))
    if n % 2 == 1:
        Gm = np.eye(2 ** m, dtype=complex)
        for x in g: Gm = Gm @ x
        g.append((1j) ** m * Gm)
    return [g[j] if j < p else 1j * g[j] for j in range(n)]
TYPE = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']
def check23():
    ok = True; rows_ = []
    for n in range(1, 5):
        for p in range(n + 1):
            q = n - p; e = complex_irrep(p, q); N = e[0].shape[0]
            def blade(a):
                X = np.eye(N, dtype=complex)
                for i in range(n):
                    if a >> i & 1: X = X @ e[i]
                return X
            G = [s * blade(a) for a in range(1 << n) for s in (1, -1)]
            fs = sum(np.trace(g @ g) for g in G) / len(G) / 1.0
            fs = int(round(fs.real))
            t = TYPE[(p - q) % 8]
            want = {'R': 1, 'R2': 1, 'C': 0, 'H': -1, 'H2': -1}[t]
            # irreducibility over C of the module: commutant dimension 1
            if fs != want: ok = False
            # antiunitary T = U K with U g* U^-1 = g: solve the linear system for U
            if fs != 0:
                rows_eq = []
                for gen in e:
                    # U conj(gen) - gen U = 0  -> (conj(gen)^T (x) I - I (x) gen) vec(U) = 0
                    rows_eq.append(np.kron(gen.conj().T, np.eye(N)) - np.kron(np.eye(N), gen))
                A = np.vstack(rows_eq); _, sv, Vh = np.linalg.svd(A)
                null = Vh[np.abs(np.concatenate([sv, np.zeros(Vh.shape[0] - len(sv))])) < 1e-9]
                if len(null) != 1: ok = False
                else:
                    U = null[0].reshape(N, N, order='F'); U = U / np.sqrt(abs(np.linalg.det(U)) ** (1 / N))
                    T2 = U @ U.conj(); s_ = T2[0, 0] / abs(T2[0, 0])
                    if not np.allclose(T2 / T2[0, 0], np.eye(N)) or round(s_.real) != fs: ok = False
                    if fs == -1:
                        rng = np.random.default_rng(23)
                        Hh = sum(rng.normal() * (blade(a) if np.allclose(blade(a), blade(a).conj().T) else 1j * blade(a)) for a in range(1 << n))
                        Hh = (Hh + Hh.conj().T) / 2
                        # restrict to T-invariant: H -> (H + T H T^-1)/2
                        Hs = (Hh + U @ Hh.conj() @ np.linalg.inv(U)) / 2
                        w = np.sort(np.linalg.eigvalsh(Hs))
                        if not all(abs(w[2 * i] - w[2 * i + 1]) < 1e-9 for i in range(N // 2)): ok = False
            rows_.append(f'Cl({p},{q}):{t}:{fs:+d}')
    row('bd·sol·23', ok, 'Frobenius-Schur indicator of G = {+-e_a} on the complex irrep = +1/0/-1 for types R/C/H, and T^2 = FS for the commuting antiunitary; H-type T-invariant Hamiltonians are Kramers-degenerate: ' + ' '.join(rows_))

# ================================================================ 24: Weyl nodes and the central pseudoscalar
def chern_lower(chi, Nth=40, Nph=80):
    """Fukui-Hatsugai: Chern number of the lower band of H = chi sigma.k on the unit sphere"""
    th = np.linspace(1e-4, np.pi - 1e-4, Nth); ph = np.linspace(0, 2 * np.pi, Nph, endpoint=False)
    def vec(t, f):
        k = np.array([np.sin(t) * np.cos(f), np.sin(t) * np.sin(f), np.cos(t)])
        H = chi * sum(k[i] * S[i] for i in range(3)); w, v = np.linalg.eigh(H); return v[:, 0]
    V = [[vec(t, f) for f in ph] for t in th]
    F = 0.0
    for i in range(Nth - 1):
        for j in range(Nph):
            a, b, c, d = V[i][j], V[i + 1][j], V[i + 1][(j + 1) % Nph], V[i][(j + 1) % Nph]
            U = np.vdot(a, b) * np.vdot(b, c) * np.vdot(c, d) * np.vdot(d, a)
            F += np.angle(U)
    # the caps (poles) are small; add the polar loops
    top = [V[0][j] for j in range(Nph)]; bot = [V[-1][j] for j in range(Nph)]
    def loop(vs):
        U = 1.0 + 0j
        for j in range(len(vs)): U *= np.vdot(vs[j], vs[(j + 1) % len(vs)])
        return np.angle(U)
    F += -loop(top) + loop(bot)
    return F / (2 * np.pi)
def check24():
    # anticommuting space in M_2(C)
    A = np.vstack([np.kron(s.T, I2) + np.kron(I2, s) for s in S])                    # vec(M s + s M)
    dim2 = 4 - np.linalg.matrix_rank(A)
    G4 = [np.kron(sx, s) for s in S]                                                  # 4x4 Dirac kinetic matrices
    A4 = np.vstack([np.kron(g.T, np.eye(4)) + np.kron(np.eye(4), g) for g in G4])
    null = np.linalg.svd(A4)[2][np.linalg.matrix_rank(A4):]
    # Hermitian anticommuting masses: the null space contains sz (x) 1 and sy (x) 1 -> as Hermitian matrices, count real dimension
    herm = []
    for v in null:
        Mx = v.reshape(4, 4, order='F'); herm += [Mx + Mx.conj().T, 1j * (Mx - Mx.conj().T)]
    hdim = np.linalg.matrix_rank(np.array([h.flatten() for h in herm]))
    ok = dim2 == 0
    cen = {}
    for chi in (1, -1):
        w = chi ** 3 * sx @ sy @ sz
        cen[chi] = complex(np.round(w[0, 0], 9))
        ok &= np.allclose(w, chi * 1j * I2)
    c_plus, c_minus = chern_lower(1), chern_lower(-1)
    ok &= abs(c_plus + 1) < 1e-6 and abs(c_minus - 1) < 1e-6
    row('bd·sol·24', ok and hdim == 2, f'2x2 matrices anticommuting with sigma_x,y,z: dimension {dim2} (Weyl node ungappable); 4x4 Dirac (sigma_x (x) sigma_k): Hermitian anticommuting masses span real dimension {hdim} (one mass up to the U(1) rotation sigma_z/sigma_y (x) 1); central pseudoscalar chi^3 sigma_x sigma_y sigma_z = {cen}; lower-band Chern numbers {c_plus:+.3f} (chi = +1), {c_minus:+.3f} (chi = -1)')

if __name__ == '__main__':
    for f in (check21, check22, check23, check24): f()
    finish()
