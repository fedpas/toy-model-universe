#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjg_frames.py: the extra direction e3 and the auxiliary zero of arXiv:2403.19689 (v3) (Def. 2 (2), Def. 3 (11), Def. 5) against the null
generator of Cl(2,0,1) and the extra generator of the Kepler trio; the Euclidean group of the plane in Cl(2,0,1); Galilean and Carroll boosts as
one rotor of Cl(d,0,1) and the Galilean boost as a null rotation of Cl(1,3); Galilean boosts and 'curving' (moving P) on the label diagram.

    python3 selfcheck/bridges/mjg_frames.py              one line per check, ids bd·mjg·12 .. bd·mjg·14, bd·mjg·16 (info bd·mjg·15); exit 1 on any FAIL
    python3 selfcheck/bridges/mjg_frames.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Standard library plus numpy (floats for sandwiches with tolerance 1e-9; Fractions where exact), deterministic (seeded generators), under 1 s; runs from
any folder, reads and writes no file. The bit rule of the Atlas, e_a e_b = s(a,b) e_(a xor b) (cat_cell.py), with eps_i in {+1, -1, 0};
reversion of a grade-k blade is (-1)^(k(k-1)/2).

 bd·mjg·12  which object is the zero, which a unit, which a null vector: in Cl(3,0), e3^2 = 1 and e3 anticommutes with e1, e2 (a unit vector
            orthogonal to the plane); the paper's 0 = ||0|| e3 with ||0|| = 0 is the zero element (0 x = 0 for every blade x, by construction:
            a remark); in Cl(2,0,1) the
            generator e0 has e0^2 = 0, e0 != 0, e0 e1 != 0, and e0 is orthogonal to every vector (the radical): the statement 'the zero vector is
            the unique vector orthogonal to all' (11) holds in Cl(3,0) and fails in Cl(2,0,1); in Cl(0,0,2) (the exterior algebra)
            every vector is orthogonal to every vector; in the Kepler trio Cl(-1,-1,-1,s) the extra generator has square s: a unit for s = -1, +1
            (E < 0, E > 0), a null vector for s = 0 (E = 0); label 0 is the unit 1 (e_0 x = x), and a product of two labels with a common null bit
            is the element 0. Sabotage: eps_3 = 0 in 'Cl(3,0)'.
 bd·mjg·13  (the plane of the planar vectors in the projective algebra) in Cl(2,0,1) with the point X(x, y) = e12 - x e02 + y e01: the rotors cos(t/2) + sin(t/2) e12 and the
            translators 1 + (d/2) e0i (exact exponentials, (e0i)^2 = 0) map normalised points to normalised points and act as isometries of R^2
            (200 seeded motors and point pairs), the action is a homomorphism (M1 M2 acts as M1 after M2), the bivectors e12, e01, e02 close
            as e(2) ([e12, e0i] in span e0j, [e01, e02] = 0); the planar vector D = X(P(b)) - X(P(a)) has no e12 part (an ideal point), is fixed by
            translators and turned by rotors. Sabotage: e0^2 = +1 (Cl(3,0)) in place of e0^2 = 0.
 bd·mjg·14  in Cl(d,0,1), d = 2, 3, the rotor R = 1 + (v/2) e0 e1 acts on grade 1 (x = t e0 + sum x_i e_i) as t -> t + v x_1, x -> x (a Carroll
            boost: e0 a null time) and on grade d (the points of the projective algebra, weight w the coefficient of e_1..d) as x_1 -> x_1 + v w,
            w -> w (a Galilean boost with the weight as absolute time, = a translation of the projective algebra); in Cl(1,3) (e0^2 = +1,
            e1..3^2 = -1) the null bivector B = (e0 + e3) e1 has B^2 = 0, and R = 1 + (w/2) B is a Lorentz transformation that fixes the
            coordinate u = t - z and acts as x -> x + w u, y -> y: a Galilean boost of the transverse plane with absolute time u (the
            light-cone form of a null rotation, theorem T17 of the Atlas). Sabotage: l = e0 + 0.5 e3 (not null) in place of e0 + e3.
 bd·mjg·15  (info, a reading, not a check) Galilean boosts of the label diagram: with event (||f||, D(f)) of each arrow, the boost
            (t, x) -> (t, x + v t) keeps every weight and gives D_v(f) = D(f) + v ||f||; when ||f|| = h(cod) - h(dom) this is, by substitution,
            the diagram of the moved positions P_v(a) = P(a) + v h(a) (here h = popcount on B_3 and B_4, rational view, seeded v), injective
            except for finitely many v (the bad v are counted); in the free category on the square graph with weights (1, 2 | 2, 2) the two
            parallel composites get D_v differing by -v, so no position map gives the boosted diagram (the weight is not a height difference:
            its class in H^1 is not 0).
 bd·mjg·16  'curving' = moving P (Section 2, footnote 5): P' = phi o P for a similarity, an affine map with det > 0, a reflection and a
            diffeomorphism phi(x, y) = (x + 0.4 sin y, y + 0.3 sin x) of the plane, on the Petrie view of B_4: the category, the weights,
            injectivity and exactness of D' = dP' are kept by all; cos(theta) of every pair of arrows (so f.g of (10)) is kept by the
            similarity only; the orientation of the commutative triangles (sign of D(f) ^ D(g) on composable pairs) is kept by the
            orientation-preserving affine maps, reversed by the reflection, and changed on k pairs by the diffeomorphism.
            Sabotage: the affine map passed as the similarity.
"""
import sys, math, itertools, random
from fractions import Fraction as Fr
import numpy as np

SAB = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if SAB: print('  sabotaged input, what the check sees: ' + text)
    else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def mul(x, y, eps):
    out = {}
    for a, ca in x.items():
        for b, cb in y.items():
            s = sgn(a, b, eps)
            if s: out[a ^ b] = out.get(a ^ b, 0) + s * ca * cb
    return {k: v for k, v in out.items() if (abs(v) > 1e-14 if isinstance(v, float) else v != 0)}
def rev(x): return {a: (c if (pc(a) * (pc(a) - 1) // 2) % 2 == 0 else -c) for a, c in x.items()}
def sandwich(R, X, eps): return mul(mul(R, X, eps), rev(R), eps)
def comm(x, y, eps):
    p, q = mul(x, y, eps), mul(y, x, eps)
    out = {k: p.get(k, 0) - q.get(k, 0) for k in set(p) | set(q)}
    return {k: v for k, v in out.items() if abs(v) > 1e-12}
def close(x, y, tol=1e-9): return all(abs(x.get(k, 0) - y.get(k, 0)) < tol for k in set(x) | set(y))
def arrows(n): return [(S, T) for T in range(1 << n) for S in range(1 << n) if S & ~T == 0 and S != T]
def pairs(n):
    return [(S, T, U) for U in range(1 << n) for T in range(1 << n) if T & ~U == 0 and T != U for S in range(1 << n) if S & ~T == 0 and S != T]
def cols_petrie(n): return np.array([[math.cos(math.pi * i / n), math.sin(math.pi * i / n)] for i in range(n)])
def view(cols, n): return np.array([cols[[i for i in range(n) if a >> i & 1]].sum(axis=0) if a else np.zeros(2) for a in range(1 << n)])

# ------------------------------------------------------------------------------------------------------------------------------------
def check12(sab):
    rows = []; ok = True
    eps3 = (1, 1, 0) if sab else (1, 1, 1)
    e = lambda i: {1 << i: 1}
    # Cl(3,0): e3 a unit vector orthogonal to the plane
    sq3 = mul(e(2), e(2), eps3); ac = close(mul(e(2), e(0), eps3), {k: -v for k, v in mul(e(0), e(2), eps3).items()})
    unit3 = close(sq3, {0: 1})
    zero = {}; zero_abs = all(mul(zero, {a: 1}, eps3) == {} for a in range(8))      # by construction (0 times anything): a remark
    # orthogonal to all vectors: v with (v x + x v)/2 = 0 for every basis vector x, among the vectors of a 3-dim space: the radical
    def radical(eps):
        n = len(eps); rad = []
        for i in range(n):
            if all(close({k: v for k, v in (lambda p, q: {kk: p.get(kk, 0) + q.get(kk, 0) for kk in set(p) | set(q)})(mul(e(i), e(j), eps), mul(e(j), e(i), eps)).items()}, {}) for j in range(n)):
                rad.append(i)
        return rad
    rad3 = radical(eps3)
    ok &= unit3 and ac and rad3 == []
    rows.append(f'Cl(3,0): e3^2 = {sq3}, e3 anticommutes with e1: {ac}, radical {rad3}; the zero element absorbs (by construction, a remark): {zero_abs}')
    # Cl(2,0,1): e0 null, nonzero, not absorbing, orthogonal to everything
    eps = (0, 1, 1)
    sq0 = mul(e(0), e(0), eps); nz = mul(e(0), e(1), eps); rad = radical(eps)
    ok &= sq0 == {} and nz != {} and rad == [0]
    rows.append(f'Cl(2,0,1): e0^2 = {sq0 or 0}, e0 e1 = {nz}, radical (generators orthogonal to all) {rad}: (11) fails')
    radL = radical((0, 0)); ok &= radL == [0, 1]
    rows.append(f'Cl(0,0,2) (the exterior algebra): radical {radL} (every vector)')
    # Kepler trio: Cl(-1,-1,-1,s), extra generator index 3
    kep = {}
    for s in (-1, 0, 1):
        ep = (-1, -1, -1, s); sq = mul(e(3), e(3), ep); kep[s] = sq.get(0, 0)
        ok &= sq == ({0: s} if s else {}) and radical(ep) == ([3] if s == 0 else [])
    rows.append(f'Kepler trio Cl(-1,-1,-1,s): extra generator squares {kep} (unit for s = -1, +1; null for s = 0)')
    # label 0 and the zero of the monoid with a null bit
    unit_ok = all(mul({0: 1}, {a: 1}, eps) == {a: 1} for a in range(8))
    zero_prod = [(a, b) for a in range(8) for b in range(8) if mul({a: 1}, {b: 1}, eps) == {}]
    ok &= unit_ok and all(a & b & 1 for a, b in zero_prod) and len(zero_prod) == 16
    rows.append(f'Cl(2,0,1): label 0 acts as the unit: {unit_ok}; label products equal to 0: {len(zero_prod)} pairs, exactly those sharing the null bit')
    return report('bd·mjg·12', ok, '; '.join(rows))

def check13(sab):
    eps = (1, 1, 1) if sab else (0, 1, 1)                       # bit 0 = e0, bit 1 = e1, bit 2 = e2
    E12, E01, E02 = 6, 3, 5
    def X(x, y): return {E12: 1.0, E02: -x, E01: y}
    def read(Xp):
        w = Xp.get(E12, 0.0)
        return (-Xp.get(E02, 0.0) / w, Xp.get(E01, 0.0) / w, w, {k: v for k, v in Xp.items() if k not in (E12, E01, E02) and abs(v) > 1e-9})
    rng = np.random.default_rng(15); ok = True
    def motor(t, d1, d2):
        R = {0: math.cos(t / 2), E12: math.sin(t / 2)}; T = {0: 1.0, E01: d1 / 2, E02: d2 / 2}
        return mul(T, R, eps)
    iso = norm = hom = True
    for _ in range(200):
        M = motor(*rng.uniform(-3, 3, size=3)); M2 = motor(*rng.uniform(-3, 3, size=3))
        p, q = rng.uniform(-2, 2, size=2), rng.uniform(-2, 2, size=2)
        xp, yp, wp, junk = read(sandwich(M, X(*p), eps)); xq, yq, wq, junk2 = read(sandwich(M, X(*q), eps))
        norm &= abs(wp - 1) < 1e-9 and abs(wq - 1) < 1e-9 and not junk and not junk2
        iso &= abs(math.hypot(xp - xq, yp - yq) - float(np.linalg.norm(p - q))) < 1e-9
        a = read(sandwich(mul(M, M2, eps), X(*p), eps)); b = read(sandwich(M, sandwich(M2, X(*p), eps), eps))
        hom &= abs(a[0] - b[0]) < 1e-9 and abs(a[1] - b[1]) < 1e-9
    ok &= iso and norm and hom
    c1 = comm({E12: 1}, {E01: 1}, eps); c2 = comm({E12: 1}, {E02: 1}, eps); c3 = comm({E01: 1}, {E02: 1}, eps)
    alg = set(c1) <= {E02} and set(c2) <= {E01} and c3 == {} and c1 != {} and c2 != {}
    ok &= alg
    # D as an ideal point
    p, q = np.array([0.3, -1.2]), np.array([1.7, 0.4])
    Dv = {k: X(*q).get(k, 0) - X(*p).get(k, 0) for k in (E12, E01, E02)}
    ideal = abs(Dv[E12]) < 1e-12
    Tm = motor(0.0, 0.7, -0.4); Dt = sandwich(Tm, Dv, eps)
    fixed = close(Dt, {k: v for k, v in Dv.items() if abs(v) > 1e-12})
    Rm = motor(math.pi / 2, 0, 0); Dr = sandwich(Rm, Dv, eps)
    turned = abs(Dr.get(E12, 0)) < 1e-12 and abs(math.hypot(Dr.get(E02, 0), Dr.get(E01, 0)) - math.hypot(Dv[E02], Dv[E01])) < 1e-9 and not close(Dr, Dv)
    ok &= ideal and fixed and turned
    return report('bd·mjg·13', ok, f'Cl(2,0,1), points X = e12 - x e02 + y e01: 200 seeded motors keep normalised points: {norm}, act as isometries: {iso}, compose as motions: {hom}; '
                  f'[e12, e01] = {c1}, [e12, e02] = {c2}, [e01, e02] = {c3 or 0} (e(2)): {alg}; D = X(q) - X(p) has e12 part 0 (ideal point): {ideal}, '
                  f'fixed by a translator: {fixed}, turned by a rotor: {turned}')

def check14(sab):
    ok = True; info = []
    for d in (2, 3):
        eps = (0,) + (1,) * d; n = d + 1
        v = 0.7; R = {0: 1.0, 0b11: v / 2}
        ok &= close(mul(R, rev(R), eps), {0: 1.0})
        # grade 1 matrix: columns = images of e0, e1, .., ed
        M1 = np.zeros((n, n))
        for j in range(n):
            img = sandwich(R, {1 << j: 1.0}, eps)
            for k, c in img.items():
                assert pc(k) == 1
                M1[k.bit_length() - 1, j] = c
        want1 = np.eye(n); want1[0, 1] = v                     # t' = t + v x1
        g1 = np.allclose(M1, want1, atol=1e-12)
        # grade d: basis = complements of single generators; weight = coefficient of e_1..d (complement of e0)
        full = (1 << n) - 1; basis = [full ^ (1 << j) for j in range(n)]
        Md = np.zeros((n, n))
        for j, bj in enumerate(basis):
            img = sandwich(R, {bj: 1.0}, eps)
            for k, c in img.items():
                Md[basis.index(k), j] = c
        # weight coordinate w (basis[0] = e_1..d) fixed; the coefficient of e0 e_(2..d) (basis[1]) shifts by a multiple of v w
        g_w_fixed = abs(Md[0, 0] - 1) < 1e-12 and all(abs(Md[0, j]) < 1e-12 for j in range(1, n))
        shift = Md[1, 0]
        g_d = g_w_fixed and abs(abs(shift) - v) < 1e-12 and np.allclose(np.delete(np.delete(Md, 0, 0), 0, 1), np.eye(n - 1), atol=1e-12)
        ok &= g1 and g_d
        info.append(f'd={d}: grade 1 t -> t + {M1[0, 1]:.2f} x1 (v = {v}): {g1}; grade d: weight fixed, x1-coefficient shifted by {shift:+.2f} w: {g_d}')
    # Cl(1,3): null rotation as a Galilean boost
    eps = (1, -1, -1, -1)
    l = {1: 1.0, 8: 0.5} if sab else {1: 1.0, 8: 1.0}
    B = mul(l, {2: 1.0}, eps); B2 = mul(B, B, eps)
    w = 0.6; R = {0: 1.0}; R.update({k: w / 2 * c for k, c in B.items()})
    L = np.zeros((4, 4))
    for j in range(4):
        img = sandwich(R, {1 << j: 1.0}, eps)
        for k, c in img.items():
            if pc(k) == 1: L[k.bit_length() - 1, j] = c
            elif abs(c) > 1e-12: L[0, 0] = float('nan')
    eta = np.diag(eps).astype(float)
    lor = np.allclose(L.T @ eta @ L, eta, atol=1e-12) and close(mul(R, rev(R), eps), {0: 1.0})
    rng = np.random.default_rng(16); gal = True; cs = set()
    for _ in range(50):
        t, x, y, z = rng.normal(size=4); Xv = np.array([t, x, y, z]); Y = L @ Xv
        u, up = t - z, Y[0] - Y[3]
        gal &= abs(u - up) < 1e-9 and abs(Y[2] - y) < 1e-12
        if abs(u) > 1e-3: cs.add(float(round((Y[1] - x) / (w * u), 9)))
    gal &= len(cs) == 1 and B2 == {}
    ok &= lor and gal
    info.append(f'Cl(1,3): B = (e0 + e3) e1, B^2 = {B2 or 0}; R = 1 + (w/2) B is a Lorentz transformation: {lor}; u = t - z fixed, y fixed, x -> x + c w u with c = {sorted(cs)} (the sign is the orientation of B): {gal}')
    return report('bd·mjg·14', ok, '; '.join(info))

def info15():
    """a reading: the boost of the events is the move of P by substitution; the counts of bad velocities and the free square are printed"""
    info = []
    rs = random.Random(17)
    for n in (3, 4):
        cols = [(Fr(rs.randint(-5, 5)), Fr(rs.randint(-5, 5))) for _ in range(n)]
        P = {a: (sum((cols[i][0] for i in range(n) if a >> i & 1), Fr(0)), sum((cols[i][1] for i in range(n) if a >> i & 1), Fr(0))) for a in range(1 << n)}
        while len(set(P.values())) < 1 << n:
            cols = [(Fr(rs.randint(-5, 5)), Fr(rs.randint(-5, 5))) for _ in range(n)]
            P = {a: (sum((cols[i][0] for i in range(n) if a >> i & 1), Fr(0)), sum((cols[i][1] for i in range(n) if a >> i & 1), Fr(0))) for a in range(1 << n)}
        v = (Fr(rs.randint(-7, 7), 3), Fr(rs.randint(-7, 7), 5))
        Pv = {a: (P[a][0] + v[0] * pc(a), P[a][1] + v[1] * pc(a)) for a in P}
        good = all((Pv[T][0] - Pv[S][0], Pv[T][1] - Pv[S][1]) == (P[T][0] - P[S][0] + v[0] * pc(T & ~S), P[T][1] - P[S][1] + v[1] * pc(T & ~S)) for S, T in arrows(n))
        bad_v = set()
        for a in P:
            for b in P:
                if pc(a) != pc(b):
                    k = pc(a) - pc(b); bad_v.add(((P[b][0] - P[a][0]) / k, (P[b][1] - P[a][1]) / k))
        inj = len(set(Pv.values())) == 1 << n
        info.append(f'n={n}: D_v = dP_v on all {len(arrows(n))} arrows: {good}; bad velocities (P_v not injective): {len(bad_v)}, the seeded v among them: {v in bad_v}, P_v injective: {inj}')
    # free square: weights (1, 2 | 2, 2): parallel composites 3 and 4
    P = {'A': (Fr(0), Fr(0)), 'X': (Fr(1), Fr(2)), 'Y': (Fr(2), Fr(-1)), 'B': (Fr(3), Fr(1))}
    v = (Fr(1, 2), Fr(1, 3)); w = {'gf': 3, 'kh': 4}
    Dgf = (P['B'][0] - P['A'][0] + v[0] * w['gf'], P['B'][1] - P['A'][1] + v[1] * w['gf'])
    Dkh = (P['B'][0] - P['A'][0] + v[0] * w['kh'], P['B'][1] - P['A'][1] + v[1] * w['kh'])
    diff = (Dgf[0] - Dkh[0], Dgf[1] - Dkh[1])
    info.append(f'free square, weights (1,2 | 2,2): D_v(g o f) - D_v(k o h) = {diff[0]}, {diff[1]} = -v: no position map for v != 0')
    return ('a Galilean boost (t, x) -> (t, x + v t) of the arrow events (||f||, D(f)) is the move P -> P + v h when ||f|| = h(cod) - h(dom), by substitution '
            '(a reading, not a check; h = popcount, exact, rational cube view, seeded v): ' + '; '.join(info))

def check16(sab):
    n = 4; P = view(cols_petrie(n), n); A = arrows(n); Pp = pairs(n)
    th = 0.7; Rm = np.array([[math.cos(th), -math.sin(th)], [math.sin(th), math.cos(th)]])
    sim = lambda p: 1.8 * (Rm @ p) + np.array([0.3, -0.2])
    Aff = np.array([[1.0, 0.8], [0.1, 1.5]]); aff = lambda p: Aff @ p + np.array([0.5, 0.1])
    refl = lambda p: np.array([p[0], -p[1]])
    dif = lambda p: np.array([p[0] + 0.4 * math.sin(p[1]), p[1] + 0.3 * math.sin(p[0])])
    maps = [('similarity', aff if sab else sim), ('affine', aff), ('reflection', refl), ('diffeo', dif)]
    def cosang(u, v): return float(u @ v / (np.linalg.norm(u) * np.linalg.norm(v)))
    def wedge(u, v): return float(u[0] * v[1] - u[1] * v[0])
    info = []; res = {}
    for name, phi in maps:
        Q = np.array([phi(p) for p in P])
        inj = len(np.unique(np.round(Q, 9), axis=0)) == 1 << n
        exact = all(np.allclose((Q[T] - Q[S]) + (Q[U] - Q[T]), Q[U] - Q[S]) for S, T, U in Pp)
        cos_changed = sum(1 for f in A for g in A if abs(cosang(P[f[1]] - P[f[0]], P[g[1]] - P[g[0]]) - cosang(Q[f[1]] - Q[f[0]], Q[g[1]] - Q[g[0]])) > 1e-9)
        flips = sum(1 for S, T, U in Pp if np.sign(round(wedge(P[T] - P[S], P[U] - P[T]), 9)) != np.sign(round(wedge(Q[T] - Q[S], Q[U] - Q[T]), 9)))
        res[name] = (inj, exact, cos_changed, flips)
        info.append(f'{name}: injective {inj}, exact {exact}, cos changed on {cos_changed} of {len(A) ** 2} pairs, triangle orientation changed on {flips} of {len(Pp)}')
    ok = all(r[0] and r[1] for r in res.values())
    ok &= res['similarity'][2] == 0 and res['similarity'][3] == 0
    ok &= res['affine'][2] > 0 and res['affine'][3] == 0
    ndeg = sum(1 for S, T, U in Pp if abs(wedge(P[T] - P[S], P[U] - P[T])) > 1e-9)
    ok &= res['reflection'][2] == 0 and res['reflection'][3] == ndeg
    ok &= res['diffeo'][2] > 0 and 0 < res['diffeo'][3]
    return report('bd·mjg·16', ok, 'moving P by phi on the Petrie view of B_4 (weights unchanged by construction): ' + '; '.join(info) +
                  f' (non-degenerate triangles: {ndeg})')

CHECKS = [('bd·mjg·12', check12), ('bd·mjg·13', check13), ('bd·mjg·14', check14), ('bd·mjg·16', check16)]

def main():
    if SAB:
        missed = 0
        for cid, fn in CHECKS:
            okk = fn(True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            missed += okk
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        return missed == 0
    for cid, fn in CHECKS: fn(False)
    print('info bd·mjg·15  ' + info15())
    nfail = sum(1 for _, o in RESULTS if not o)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    return nfail == 0

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
