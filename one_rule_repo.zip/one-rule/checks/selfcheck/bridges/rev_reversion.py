#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""rev_reversion.py: the cell with its reversion.  Classify (Cl(p,q), grading, tau) up to isomorphism of superalgebras with
anti-involution, tau = reversion (and, as further rows, Clifford conjugation and the dagger of Thm T15), for every n = p + q <= 10.

  python3 selfcheck/bridges/rev_reversion.py              one line per check, ids bd·rev·1 .. bd·rev·6; exit 1 on any FAIL
  python3 selfcheck/bridges/rev_reversion.py --sabotage   every check runs against a deliberately broken input and must print CAUGHT

Standard library only, exact integer arithmetic, no randomness, deterministic, about 3 s; runs from any folder, reads and writes no file.
r = 0 throughout (non-degenerate cells).
  bd·rev·1  for every Cl(p,q) with n <= 10 the forms t(x) = <x x~>_0 and t'(x) = <x alpha(x~)>_0 are diagonal on blades; t is positive definite iff
            q = 0 and t' iff p = 0; both are invariants of (algebra, grading, reversion); the reversion is a graded anti-involution (n <= 7).
  bd·rev·2  for every cell with p >= 5, q >= 1, n <= 10, the block of five plus and one minus generators gives an isomorphism Cl(p-4,q+4) -> Cl(p,q)
            of superalgebras with reversion (verified on every label pair for n <= 7).
  bd·rev·3  reversion, every n <= 10: two cells with the same triple (same n, same p - q mod 8) have isomorphic reversions iff they are equal or
            both indefinite (p, q >= 1); every same-triple pair is joined by verified block maps or separated by bd·rev·1, never both.
  bd·rev·4  Clifford conjugation alpha(x~): the same partition as the reversion; <x x->_0 is positive definite iff p = 0 (n <= 10).
  bd·rev·5  the dagger e_a^dagger = e_a^-1 (Thm T15): <x x^dagger>_0 is positive definite for every cell, and two cells are isomorphic with their
            daggers iff they have the same triple (n <= 10).
  bd·rev·6  the global maps e_i -> +-e_sigma(i) w^k alone miss 13 isomorphic pairs with n <= 10 (e.g. Cl(5,3) ~ Cl(1,7)); the block family is needed.

The bit rule: e_a e_b = s(a,b) e_(a xor b), s = (reordering sign) x (product of the squares eps_i of the shared generators).
A cell Cl(p,q) is taken with eps = (+1)^p (-1)^q.  Two cells have the same triple (V,Q,pi) iff n = n' and p - q = p' - q' mod 8
(core·B6c), i.e. iff p = p' mod 4.

Method (decision procedure for each pair with the same triple):
  * Isomorphisms come from the BLOCK FAMILY of generator maps: for a set B of generators with |B| even,
        e'_i -> e_i w_B (i in B),   e'_j -> e_j (j not in B),   w_B = the product of the generators in B,
    composed with permutations of the generators.  For |B| even every image is odd and the images pairwise anticommute; the
    map is an isomorphism of superalgebras Cl(eps') -> Cl(eps) (the image labels are independent over F_2) and it intertwines an
    anti-involution tau iff tau acts on each image f_i as it acts on the generator e'_i of the target (an anti-automorphism is
    fixed by its values on generators; universal property).  The case B = all generators is the global map e_i -> e_i w; the
    case |B| = 2 is a permutation.  The search runs over every block composition (k plus and m minus generators in B).
  * Non-isomorphisms come from two invariants of (A, grading, tau): the real quadratic forms t_tau(x) = <x tau(x)>_0 and
    t_{alpha tau}(x) = <x alpha(tau(x))>_0 (<.>_0 = 2^-n trace of the left regular representation, alpha the grade involution).
    An isomorphism of superalgebras with anti-involution carries one form to the other, so whether each is positive definite is
    an invariant.  On the blade basis both forms are diagonal: t_rev(e_a) = prod_{i in a} eps_i, t_{alpha rev}(e_a) = prod (-eps_i).
  * The classification is complete for a given n when every same-triple pair is either joined by a chain of verified block maps
    or separated by an invariant, and no pair is both.
"""
import sys, itertools

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    """the bit-rule sign (core_check.py): e_a e_b = sgn(a,b) e_(a xor b)"""
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def cell(p, q): return [1] * p + [-1] * q

def tau_coef(name, a, eps):
    """tau(e_a) = c e_a for the involutions used here (all are diagonal on blades)"""
    k = pc(a); rev = (-1) ** (k * (k - 1) // 2)
    if name == 'rev': return rev                       # reversion: a blade of grade k gets (-1)^{k(k-1)/2}
    if name == 'conj': return (-1) ** k * rev          # Clifford conjugation = grade involution o reversion
    if name == 'dag': return sgn(a, a, eps)            # dagger of Thm T15: e_a^dagger = e_a^{-1} = (e_a^2) e_a
    if name == 'nosign': return 1                      # SABOTAGE: reversion with the sign (-1)^{k(k-1)/2} dropped
    if name == 'grade': return (-1) ** k               # SABOTAGE: conjugation with the reversion sign dropped (= alpha)
    raise ValueError(name)

def is_graded_anti_involution(name, eps):
    """tau(e_a e_b) = tau(e_b) tau(e_a) on every label pair, tau^2 = id; diagonal on blades so it preserves the grading"""
    n = len(eps)
    for a in range(1 << n):
        if tau_coef(name, a, eps) ** 2 != 1: return False
        for b in range(1 << n):
            if sgn(a, b, eps) * tau_coef(name, a ^ b, eps) != tau_coef(name, b, eps) * tau_coef(name, a, eps) * sgn(b, a, eps): return False
    return True

def positive(name, eps, twist=False):
    """is t_tau (twist=False) or t_{alpha tau} (twist=True) positive definite?  t(e_a) = coefficient of 1 in e_a tau(e_a)"""
    for a in range(1 << len(eps)):
        d = tau_coef(name, a, eps) * sgn(a, a, eps) * ((-1) ** pc(a) if twist else 1)
        if d != 1: return False
    return True

def independent(labels):
    basis = {}
    for v in labels:
        x = v
        while x:
            h = x.bit_length() - 1
            if h in basis: x ^= basis[h]
            else: basis[h] = x; break
        if x == 0: return False
    return True

def block_move(eps, B, name):
    """the block map for the set B of generators: returns (valid, eps') where eps' are the squares of the images.
       valid = images odd, pairwise anticommuting, independent, and tau-compatible generator by generator"""
    n = len(eps); Bm = sum(1 << i for i in B)
    imgs = []
    for i in range(n):
        if i in B:
            lab = (1 << i) ^ Bm; s = sgn(1 << i, Bm, eps)          # e_i w_B = s e_lab
        else:
            lab = 1 << i; s = 1
        imgs.append((s, lab))
    epsp = [sgn(l, l, eps) for (_, l) in imgs]                    # (s e_l)^2 = e_l^2
    ok = all(pc(l) % 2 == 1 for _, l in imgs)
    ok &= all(sgn(imgs[i][1], imgs[j][1], eps) == -sgn(imgs[j][1], imgs[i][1], eps) for i in range(n) for j in range(i + 1, n))
    ok &= independent([l for _, l in imgs]) and all(x != 0 for x in epsp)
    # tau-compatibility: tau(f_i) = tau_coef(lab_i; eps) f_i must equal phi(tau'(e'_i)) = tau_coef(generator i; eps') f_i
    ok &= all(tau_coef(name, imgs[i][1], eps) == tau_coef(name, 1 << i, epsp) for i in range(n))
    return ok, epsp, imgs

def full_label_check(eps, B, name):
    """cross-check of the universal-property argument on every label pair (used for n <= 7): the induced map is a
       homomorphism Cl(eps') -> Cl(eps), parity-preserving, bijective on labels, and intertwines tau on every label"""
    ok, epsp, imgs = block_move(eps, B, name)
    if not ok: return False
    n = len(eps); phi = {}
    for a in range(1 << n):
        s, lab = 1, 0
        for i in range(n):
            if a >> i & 1:
                si, li = imgs[i]
                s = s * si * sgn(lab, li, eps); lab ^= li
        phi[a] = (s, lab)
    if len({l for _, l in phi.values()}) != 1 << n: return False
    for a in range(1 << n):
        sa, la = phi[a]
        if pc(la) % 2 != pc(a) % 2: return False
        if tau_coef(name, a, epsp) != tau_coef(name, la, eps): return False
        for b in range(1 << n):
            sb, lb = phi[b]; sab, lab = phi[a ^ b]
            if sa * sb * sgn(la, lb, eps) != sgn(a, b, epsp) * sab or la ^ lb != lab: return False
    return True

def counts(eps): return (eps.count(1), eps.count(-1))

def classify(n, name, blocks='all'):
    """union-find on the cells (p,q), p + q = n, joined by every valid block map (blocks='all': every block composition;
       blocks='global': only B = all generators, i.e. the maps e_i -> +-e_sigma(i) w^k).  Returns the classes and the invariants."""
    parent = {(p, n - p): (p, n - p) for p in range(n + 1)}
    def find(x):
        while parent[x] != x: x = parent[x]
        return x
    moves = []
    for p in range(n + 1):
        q = n - p; eps = cell(p, q)
        comps = [(p, q)] if blocks == 'global' else [(k, m) for k in range(p + 1) for m in range(q + 1) if (k + m) % 2 == 0 and k + m >= 2]
        for (k, m) in comps:
            B = list(range(k)) + list(range(p, p + m))               # k plus generators and m minus generators (WLOG, up to permutation)
            ok, epsp, _ = block_move(eps, B, name)
            if ok:
                tgt = counts(epsp)
                if tgt != (p, q): moves.append(((p, q), tgt, (k, m)))
                parent[find((p, q))] = find(tgt)
    classes = {}
    for x in parent: classes.setdefault(find(x), []).append(x)
    inv = {(p, n - p): (positive(name, cell(p, n - p)), positive(name, cell(p, n - p), twist=True)) for p in range(n + 1)}
    return sorted(sorted(c) for c in classes.values()), inv, moves

def same_triple(x, y): return sum(x) == sum(y) and (x[0] - x[1] - (y[0] - y[1])) % 8 == 0
def formula(x): return (sum(x), (x[0] - x[1]) % 8, x[0] == 0, x[1] == 0)          # (n, clock, negative definite, positive definite)

def decide(name, nmax=10, blocks='all'):
    """for every n <= nmax: decide every same-triple pair; returns (complete, conflict-free, partition == formula partition,
       partition == triple partition, report lines)"""
    complete = conflict_free = eq_formula = eq_triple = True; lines = []
    for n in range(1, nmax + 1):
        classes, inv, moves = classify(n, name, blocks)
        cls_of = {x: tuple(c) for c in classes for x in c}
        cells = [(p, n - p) for p in range(n + 1)]
        for x, y in itertools.combinations(cells, 2):
            if not same_triple(x, y): continue
            iso = cls_of[x] == cls_of[y]; sep = inv[x] != inv[y]
            if not iso and not sep: complete = False
            if iso and sep: conflict_free = False
        for x, y in itertools.combinations(cells, 2):
            if (cls_of[x] == cls_of[y]) != (formula(x) == formula(y)): eq_formula = False
            if (cls_of[x] == cls_of[y]) != same_triple(x, y): eq_triple = False
        big = [c for c in classes if len(c) > 1]
        sepd = []
        for x, y in itertools.combinations(cells, 2):
            if same_triple(x, y) and cls_of[x] != cls_of[y]: sepd.append(f'{x}|{y}')
        lines.append(f'n={n}: classes with >1 cell: ' + (', '.join('{' + ' '.join(map(str, c)) + '}' for c in big) or '-')
                     + '; same triple, not isomorphic: ' + (', '.join(sepd) or '-'))
    return complete, conflict_free, eq_formula, eq_triple, lines

# ------------------------------------------------------------------------------------------------------------- the checks
RESULTS = []
def report(cid, ok, text, verbose=True):
    RESULTS.append((cid, ok))
    if verbose: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return ok

def check1(sab=False, verbose=True):
    """invariants: t_rev positive definite iff q = 0, t_{alpha rev} positive definite iff p = 0 (every cell, n <= 10);
       the reversion is a grading-preserving anti-involution (every label pair, every cell with n <= 7)"""
    name = 'conj' if sab else 'rev'                       # SABOTAGE: Clifford conjugation in place of the reversion
    ok = all(is_graded_anti_involution(name, cell(p, n - p)) for n in range(1, 8) for p in range(n + 1))
    for n in range(1, 11):
        for p in range(n + 1):
            q = n - p; eps = cell(p, q)
            if positive(name, eps) != (q == 0) or positive(name, eps, twist=True) != (p == 0): ok = False
    return report('bd·rev·1', ok, 'for every Cl(p,q) with n <= 10 the forms t(x) = <x x~>_0 and t\'(x) = <x alpha(x~)>_0 are diagonal on blades with '
                  'entries prod_(i in a) eps_i and prod (-eps_i); t is positive definite iff q = 0 and t\' iff p = 0. Both are invariants of '
                  '(algebra, grading, reversion); the reversion is a graded anti-involution (all label pairs, n <= 7)', verbose)

def check2(sab=False, verbose=True):
    """block certificate: for every cell (p,q) with p >= 5, q >= 1 and n <= 10, the block of five plus generators and one minus
       generator gives a valid map, an isomorphism Cl(p-4,q+4) -> Cl(p,q) of superalgebras with reversion; full label check n <= 7"""
    ok = True; cnt = 0; full = 0
    for n in range(6, 11):
        for p in range(5, n):
            q = n - p; eps = cell(p, q)
            B = [0, 1, 2, 3, 4, p] if not sab else [0, 1, 2, p]     # SABOTAGE: a block of 4 (images of grade 3, reversion sign -1)
            valid, epsp, _ = block_move(eps, B, 'rev')
            if not valid or counts(epsp) != (p - 4, q + 4): ok = False
            if n <= 7:
                if not full_label_check(eps, B, 'rev'): ok = False
                full += 1
            cnt += 1
    return report('bd·rev·2', ok, f'block map: for every cell with p >= 5, q >= 1, n <= 10 ({cnt} cells) the images e_i w_B of a block B of five plus '
                  'and one minus generators (and e_j outside B) are odd, fixed by the reversion, pairwise anticommuting and independent, with '
                  f'squares of signature (p-4, q+4): an isomorphism Cl(p-4,q+4) -> Cl(p,q) of superalgebras with reversion ({full} of them verified '
                  'on every label pair, n <= 7)', verbose)

def check3(sab=False, verbose=True):
    """the classification for the reversion, n <= 10: complete, conflict-free, and equal to the formula partition"""
    name = 'dag' if sab else 'rev'                        # SABOTAGE: the dagger in place of the reversion (a different, coarser answer)
    complete, cf, eqf, eqt, lines = decide(name)
    if verbose and not sab:
        for l in lines: print('     ' + l)
    return report('bd·rev·3', complete and cf and eqf,
                  'reversion, every n <= 10: every pair of cells with the same triple is either joined by verified block maps or separated by '
                  'bd·rev·1, never both; the classes are exactly: same n, same p - q mod 8, and both indefinite or equal. Two cells with the same '
                  'triple have isomorphic reversions iff they are equal or both indefinite (p, q >= 1)', verbose)

def check4(sab=False, verbose=True):
    """Clifford conjugation: a graded anti-involution, and the same partition as the reversion (alpha is part of the graded
       structure); its positivity invariant has p and q exchanged"""
    name = 'grade' if sab else 'conj'                     # SABOTAGE: conjugation without the reversion sign = alpha, an automorphism
    ok = all(is_graded_anti_involution(name, cell(p, n - p)) for n in range(1, 8) for p in range(n + 1))
    complete, cf, eqf, eqt, _ = decide(name)
    ok &= complete and cf and eqf
    ok &= all(positive(name, cell(p, n - p)) == (p == 0) for n in range(1, 11) for p in range(n + 1))
    return report('bd·rev·4', ok, 'Clifford conjugation x- = alpha(x~), every n <= 10: the same partition as the reversion (complete, conflict-free); '
                  '<x x->_0 is positive definite iff p = 0 (the roles of p and q exchanged)', verbose)

def check5(sab=False, verbose=True):
    """dagger of T15 (e_a^dagger = e_a^{-1}): positive for every cell, and the partition is the triple partition"""
    name = 'rev' if sab else 'dag'                        # SABOTAGE: the reversion in place of the dagger (a finer answer)
    ok = all(is_graded_anti_involution(name, cell(p, n - p)) for n in range(1, 8) for p in range(n + 1))
    ok &= all(positive(name, cell(p, n - p)) for n in range(1, 11) for p in range(n + 1))
    complete, cf, eqf, eqt, _ = decide(name)
    ok &= complete and cf and eqt
    return report('bd·rev·5', ok, 'dagger e_a^dagger = e_a^-1 (Thm T15), every n <= 10: <x x^dagger>_0 is positive definite for every cell, block maps '
                  'with blocks of 4 are dagger-compatible, and two cells are isomorphic with their daggers iff they have the same triple: the '
                  'dagger forgets the definiteness that the reversion keeps', verbose)

def check6(sab=False, verbose=True):
    """the global family e_i -> +-e_sigma(i) w^k alone is not sufficient: it misses pairs that the block family joins"""
    blocks = 'all' if sab else 'global'                   # SABOTAGE: let the 'global' search use every block (then it is complete)
    missed = []
    for n in range(1, 11):
        cg, _, _ = classify(n, 'rev', blocks)
        ca, _, _ = classify(n, 'rev', 'all')
        of_g = {x: tuple(c) for c in cg for x in c}; of_a = {x: tuple(c) for c in ca for x in c}
        for x, y in itertools.combinations(sorted(of_a), 2):
            if of_a[x] == of_a[y] and of_g[x] != of_g[y]: missed.append(f'{x}~{y}')
    if verbose and not sab: print('     isomorphic pairs that the global family misses: ' + ', '.join(missed))
    return report('bd·rev·6', len(missed) > 0 and '(1, 7)~(5, 3)' in missed,
                  f'the global maps e_i -> +-e_sigma(i) w^k (permutations and the pseudoscalar map) are not a sufficient family: for n <= 10 they '
                  f'miss {len(missed)} isomorphic pairs (e.g. Cl(5,3) ~ Cl(1,7) at n = 8, where the global map does not respect the reversion); '
                  'the block family with blocks of 6 is needed', verbose)

CHECKS = [check1, check2, check3, check4, check5, check6]

if __name__ == '__main__':
    if '--sabotage' in sys.argv:
        WHY = {
            'bd·rev·1': 'Clifford conjugation in place of the reversion: positivity then holds iff p = 0, not q = 0',
            'bd·rev·2': 'a block of 4 in place of 6: images of grade 3 have reversion sign -1, the map does not respect the reversion',
            'bd·rev·3': 'the dagger in place of the reversion: the partition becomes the triple partition, e.g. Cl(4,0) ~ Cl(0,4)',
            'bd·rev·4': 'conjugation without the reversion sign (the grade involution alpha): not an anti-automorphism',
            'bd·rev·5': 'the reversion in place of the dagger: not positive for q >= 1, and the partition is finer than the triple',
            'bd·rev·6': 'the global search allowed every block: it then finds every isomorphism, nothing is missed',
        }
        missed = 0
        for chk in CHECKS:
            RESULTS.clear()
            chk(sab=True, verbose=False)
            cid, ok = RESULTS[-1]
            print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  (' + WHY[cid] + ')')
            if ok: missed += 1
        # the machinery sees a non-matching answer: the dagger partition differs from the reversion partition
        diff = []
        for n in range(1, 11):
            cr, _, _ = classify(n, 'rev'); cd, _, _ = classify(n, 'dag')
            of_r = {x: tuple(c) for c in cr for x in c}; of_d = {x: tuple(c) for c in cd for x in c}
            for x, y in itertools.combinations(sorted(of_r), 2):
                if (of_r[x] == of_r[y]) != (of_d[x] == of_d[y]): diff.append(f'{x}{y}')
        print(f'     non-matching answer seen: {len(diff)} pairs (n <= 10) are isomorphic with their daggers but not with their reversions, '
              'e.g. ' + ', '.join(diff[:4]))
        print('ALL CAUGHT' if missed == 0 else f'{missed} MISSED')
        sys.exit(1 if missed else 0)
    for chk in CHECKS: chk()
    bad = [c for c, ok in RESULTS if not ok]
    print(f'\n{len(RESULTS) - len(bad)}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
