#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mja_ladder.py: the sizes of the rungs of the two ladders on the labels F_2^n: counts on the labels and on the category B_n by brute force
against their formulas, and the number of isomorphism classes of the objects at the rungs D0, D1, D2 of the ladder down.
The ladder up adds one structure at a time to the 2^n bare points (U0): U1 the disjoint partial sum a (+) b (a and b = 0), unit 0; U2 the
weight popcount; U3 the order S subset T with its arrows (the category B_n); U4 positions in the plane and the planar vectors of
arXiv:2403.19689 (v3); U5 the sign on disjoint labels; U6 the squares eps (the cell); U7 the clock.  The ladder down forgets one structure at
a time, starting from the cell with its clock and null part (D0): D1 the triple (V, Q, pi); D2 the exterior algebra Cl(0,0,n); D3 (+) on
disjoint labels with the weight; D4 the order B_n; D5 the 2^n points.

    python3 selfcheck/bridges/mja_ladder.py              one line per check, ids bd·mja·32, bd·mja·33, bd·mja·36 (info line bd·mja·34); exit 1 on any FAIL
    python3 selfcheck/bridges/mja_ladder.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only, exact integers; deterministic; about 3 s; runs from any folder, reads and writes no file.
  bd·mja·32  by brute force, n = 0..6 (composable pairs and chains to n = 5): labels 2^n; defined pairs of (+) 3^n; arrows of B_n (identities
             included) 3^n; composable pairs 4^n; chains S_0 in ... in S_k (k = 1..4) (k+2)^n; strict chains of k+1 objects sum_j (-1)^j C(k,j) (k+2-j)^n; their alternating sum
             (the Euler characteristic of the order complex) 1; Hasse edges n 2^(n-1); commuting squares C(n,2) 2^(n-2).
  bd·mja·33  isomorphism classes of the cells with n generators at three rungs of the ladder down, n = 1..4: D0 (the cell with its clock and null
             part: classes (r, p - q mod 8)), D1 (the literal triple (V, Q, pi) up to isometry, full test on every label), D2 (the sign alone: the
             exterior algebra, one class); D0 and D1 agree exactly on the cells with r = 0.
  bd·mja·34  (info line, not a check) the algebra dimension at each rung up, read off the checks that compute it.
  bd·mja·36  the partial sum is definable from the order: a (+) b = a v b exactly when a ^ b is the bottom (meet and join computed from the order,
             n <= 4), and the order and the partial monoid have the same automorphisms, n! of them (all permutations of the 2^n labels tested,
             n <= 3): the rungs D3 and D4 carry the same information on the labels.
"""
import itertools, sys
from math import comb

SABOTAGE = '--sabotage' in sys.argv
ROWS = []
def row(cid, ok, text):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

def chk32(sab):
    ok = True; tab = []
    for n in range(0, 7):
        N = 1 << n
        sub = (lambda s, t: s & t == s) if not sab else (lambda s, t: s <= t)       # sabotage: the integer order in place of inclusion
        arrows = sum(1 for s in range(N) for t in range(N) if sub(s, t))
        comp = sum(1 for s in range(N) for t in range(N) if sub(s, t) for u in range(N) if sub(t, u)) if n <= 5 else None
        pairs = sum(1 for a in range(N) for b in range(N) if a & b == 0)
        hasse = sum(1 for s in range(N) for t in range(N) if sub(s, t) and pc(s ^ t) == 1)
        squares = sum(1 for s in range(N) for t in range(N) if sub(s, t) and pc(s ^ t) == 2)
        row_ok = arrows == 3 ** n and (comp is None or comp == 4 ** n) and pairs == 3 ** n and hasse == n * 2 ** max(n - 1, 0) * (n > 0) and squares == comb(n, 2) * 2 ** max(n - 2, 0) * (n > 1)
        chains = []; strict = []
        if n <= 5:
            lst = list(range(N))
            for k in range(1, 5):
                if n <= 4 or k <= 2:
                    # count chains of k+1 objects by dynamic programming over the last object
                    cnt = {s: 1 for s in lst}; scnt = {s: 1 for s in lst}
                    for _ in range(k):
                        cnt = {t: sum(cnt[s] for s in lst if sub(s, t)) for t in lst}
                        scnt = {t: sum(scnt[s] for s in lst if sub(s, t) and s != t) for t in lst}
                    c, sc = sum(cnt.values()), sum(scnt.values())
                    chains.append(c); strict.append(sc)
                    if c != (k + 2) ** n or sc != sum((-1) ** j * comb(k, j) * (k + 2 - j) ** n for j in range(k + 1)): row_ok = False
            if n <= 4:
                euler = 0; scnt = {s: 1 for s in lst}; k = 0
                while sum(scnt.values()):
                    euler += (-1) ** k * sum(scnt.values()); k += 1
                    scnt = {t: sum(scnt[s] for s in lst if sub(s, t) and s != t) for t in lst}
                if euler != 1: row_ok = False
        tab.append((n, arrows, comp, pairs, hasse, squares, chains, strict))
        if not row_ok: ok = False
    return ok, ('(n, arrows, composable pairs, defined pairs, Hasse edges, squares, chains k = 1..4, strict chains k = 1..4): '
                + '; '.join(f'{t}' for t in tab[:5]) + '; n = 5, 6 also checked: 3^n, 4^n (n = 5), (k+2)^n and inclusion-exclusion (n = 5, k <= 2), Euler characteristic 1 (n <= 4)'), str(tab[2])

def isometric(Qa, Qb, Pa, Pb, n):
    Ba = [[(Qa[(1 << i) ^ (1 << j)] + Qa[1 << i] + Qa[1 << j]) % 2 for j in range(n)] for i in range(n)]
    def rec(i, imgs):
        if i == n:
            span = {0}
            for v in imgs: span |= {s ^ v for s in span}
            if len(span) != 1 << n: return False
            def T(a):
                x = 0
                for j in range(n):
                    if a >> j & 1: x ^= imgs[j]
                return x
            return all(Qb[T(a)] == Qa[a] and Pb[T(a)] == Pa[a] for a in range(1 << n))
        for v in range(1, 1 << n):
            if Qb[v] != Qa[1 << i] or Pb[v] != Pa[1 << i]: continue
            if any((Qb[v ^ imgs[j]] + Qb[v] + Qb[imgs[j]]) % 2 != Ba[i][j] for j in range(i)): continue
            if rec(i + 1, imgs + [v]): return True
        return False
    return rec(0, [])
def classes(items, same):
    reps = []
    for x in items:
        if not any(same(x, r) for r in reps): reps.append(x)
    return len(reps)
def chk33(sab):
    ok = True; out = []
    for n in range(1, 5):
        cells = [(p, n - r - p, r) for r in range(n + 1) for p in range(n - r + 1)]
        d0 = len({(r, (p - q) % 8) for p, q, r in cells})
        def lit(c):
            p, q, r = c; e = [1] * p + [-1] * q + [0] * r
            return [1 if sgn(a, a, e) == -1 else 0 for a in range(1 << n)], [pc(a) % 2 for a in range(1 << n)]
        L = {c: lit(c) for c in cells}
        same1 = lambda x, y: isometric(L[x][0], L[y][0], L[x][1], L[y][1], n)
        if sab: same1 = lambda x, y: (x[2], (x[0] - x[1]) % 8) == (y[2], (y[0] - y[1]) % 8)     # sabotage: the D0 relation in place of the triple
        d1 = classes(cells, same1)
        r0 = [c for c in cells if c[2] == 0]
        d0r0 = len({(p - q) % 8 for p, q, r in r0}); d1r0 = classes(r0, same1)
        lam = {tuple(sgn(a, b, [1] * cells[0][0] + [-1] * cells[0][1] + [0] * cells[0][2]) if a & b == 0 else 0 for a in range(1 << n) for b in range(1 << n))}
        for p, q, r in cells:
            e = [1] * p + [-1] * q + [0] * r
            lam.add(tuple(sgn(a, b, e) if a & b == 0 else 0 for a in range(1 << n) for b in range(1 << n)))
        if len(lam) != 1: ok = False
        out.append(f'n={n}: {len(cells)} cells, D0 {d0}, D1 {d1}, D2 {len(lam)}; r = 0: D0 {d0r0}, D1 {d1r0}')
        if d1r0 != d0r0 or d1 >= d0: ok = False
    return ok, ('isomorphism classes per rung of the ladder down: ' + '; '.join(out) + ': forgetting the pairing (D1) identifies cells only when r >= 1 (bd·cat·1); '
                'forgetting Q (D2) identifies all with Lambda'), '; '.join(out)

def chk36(sab):
    ok = True; out = []
    for n in range(0, 7):
        N = 1 << n
        leq = (lambda s, t: s & t == s) if not (sab and n == 3) else (lambda s, t: s <= t)       # sabotage: a total order (not a lattice of sets)
        def meet(a, b):
            lows = [c for c in range(N) if leq(c, a) and leq(c, b)]
            m = [c for c in lows if all(leq(d, c) for d in lows)]
            return m[0] if len(m) == 1 else None
        def join(a, b):
            ups = [c for c in range(N) if leq(a, c) and leq(b, c)]
            m = [c for c in ups if all(leq(c, d) for d in ups)]
            return m[0] if len(m) == 1 else None
        bottom = [c for c in range(N) if all(leq(c, d) for d in range(N))][0]
        if n <= 4:
            for x in range(N):
                for y in range(N):
                    from_order = join(x, y) if meet(x, y) == bottom else None
                    direct = (x | y) if x & y == 0 else None
                    if from_order != direct: ok = False
    for n in range(1, 4):
        N = 1 << n
        leq = (lambda s, t: s & t == s)
        if sab and n == 3: leq = lambda s, t: s <= t
        auto_order = auto_sum = 0
        for perm in itertools.permutations(range(N)):
            if all(leq(s, t) == leq(perm[s], perm[t]) for s in range(N) for t in range(N)): auto_order += 1
            if all(((s & t) == 0) == ((perm[s] & perm[t]) == 0) and (s & t or perm[s | t] == (perm[s] | perm[t])) for s in range(N) for t in range(N)): auto_sum += 1
        out.append(f'n={n}: |Aut(labels, subset)| {auto_order}, |Aut(labels, (+))| {auto_sum}')
        fact = 1
        for k in range(2, n + 1): fact *= k
        if auto_order != fact or auto_sum != fact: ok = False
    return ok, ('on the labels the partial sum is definable from the order: a (+) b = a v b exactly when a ^ b = 0 (meet and join computed from the order, '
                'n <= 4); ' + '; '.join(out) + ' = n!: forgetting (+) and keeping the order (D3 -> D4) loses no structure on B_n; the algebra attached changes '
                'from the monoid algebra (2^n) to the incidence algebra (3^n)'), '; '.join(out)

def info34():
    print('info bd·mja·34  algebra dimension per rung up (n = 0..4): U0 functions on the points 2^n = 1, 2, 4, 8, 16; U1/U2 contracted monoid algebra R_0[M] '
          '2^n (bd·mja·27); U3 incidence algebra 3^n = 1, 3, 9, 27, 81 (bd·mja·10); U4 Cat-algebra in R1/R2a 1, 2, 4, 4, 4 (bd·mja·18); U5 Lambda(R^n) 2^n '
          '(bd·mja·4); U6 Cl(p,q,r) 2^n, inside the neutral cell Cl(n,n) of dimension 4^n = 1, 4, 16, 64, 256 (bd·mja·9, bd·mja·12); U7 the clock: a Z_8 value, '
          'no further dimension. H^2 with F_2 coefficients: 0 (B_n), C(n,2) (partial monoid), n(n+1)/2 (group) (bd·mja·7).')

CHECKS = [('bd·mja·32', chk32), ('bd·mja·33', chk33), ('bd·mja·36', chk36)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            ok, _, seen = f(True)
            print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  broken input sees: ' + seen)
            missed += ok
        print('\nALL CAUGHT' if not missed else f'\n{missed} MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS:
        ok, text, _ = f(False)
        row(cid, ok, text)
    info34()
    verdict()
