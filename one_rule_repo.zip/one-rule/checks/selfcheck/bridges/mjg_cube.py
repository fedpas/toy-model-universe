#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjg_cube.py: the label category B_n against the shapes page: the Hasse diagram is the n-cube graph, the 3^n arrows are the 3^n faces of
the n-cube (interval [S, T] = the face x_i = 1 on S, x_i = 0 off T), the 4^n composable pairs are the (face, vertex) incidences, composition is
the join of two faces meeting at a vertex, and the orthoplex is the dual.  The A-space of the info line is that of arXiv:2403.19689 (v3), §2.

    python3 selfcheck/bridges/mjg_cube.py              one line per check, ids bd·mjg·17 .. bd·mjg·20 (and info bd·mjg·21); exit 1 on any FAIL
    python3 selfcheck/bridges/mjg_cube.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Standard library only, exact integers, deterministic, about 1 s; runs from any folder, reads and writes no file.

 bd·mjg·17  the cover relations S < S + {i} of B_n are exactly the pairs of labels at Hamming distance 1: the Hasse diagram is the n-cube graph
            (n 2^(n-1) edges, n-regular), and every edge changes the parity of the label (the two halves are the demicubes) (n <= 7).
            Sabotage: Hamming distance 2.
 bd·mjg·18  the faces of the cube [0,1]^n, computed as the argmax sets on the 2^n vertices of the 5^n integer functionals c in {-2..2}^n, are
            exactly the 3^n vertex sets {x(U): S <= U <= T} of the intervals (arrows) S -> T, n <= 4; the affine dimension of the face is the
            weight |T \\ S|; f-vector f_k = C(n,k) 2^(n-k) and Euler characteristic sum (-1)^k f_k = 1 (n <= 7; the boundary, without the
            top face, has 1 - (-1)^n by arithmetic).  Sabotage: functionals in {-1, +1}^n only.
 bd·mjg·19  composable pairs S <= T <= U (4^n of them, identities included) are in bijection with the incidences (face, vertex) of the
            cube, the faces computed as argmax sets of integer functionals as in bd·mjg·18 (n <= 5): (S, T, U) goes to (face [S, U], vertex
            x(T)); the composite [S, U] is the smallest face containing [S, T] and [T, U] (their join), found by search over all intervals
            (that its dimension is the sum of theirs, the paper's (9) as dimension of the join, is an identity of popcounts: a remark); nerve
            k-simplices S_0 <= .. <= S_k number (k + 2)^n, strict ones sum_j (-1)^j C(k, j) (k + 2 - j)^n (n <= 5, k <= 3).
            Sabotage: the pair mapped to (face [S, T], vertex x(T)).
 bd·mjg·20  the orthoplex as the dual: S -> T goes to the signed set {+i: i in S} + {-i: i not in T}, a face of the n-orthoplex with n - |T \\ S|
            vertices (identities -> the 2^n facets, 0 -> [n] -> the empty face); this is a bijection from the 3^n arrows onto the 3^n - 1
            nonempty faces (signed sets without an antipodal pair, as in orthoplex/orthoplex_check.py: 242 at n = 5) plus the empty face, and it reverses
            inclusion of faces (n <= 5). Sabotage: inclusion tested as preserved.
 bd·mjg·21  (info, not a check) the A-space of the paper chooses a side of Z0 (above or below) for each non-identity arrow: 2^(3^n - 2^n)
            choices; nothing in it is computed to match the two poles of the orthoplex axes.
"""
import sys, itertools
from math import comb

SAB = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if SAB: print('  sabotaged input, what the check sees: ' + text)
    else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return bool(ok)
def pc(a): return bin(a).count('1')

def check17(sab):
    ok = True; info = []
    for n in range(1, 8):
        covers = {(S, S | 1 << i) for S in range(1 << n) for i in range(n) if not S >> i & 1}
        dist = 2 if sab else 1
        ham = {(a, b) for a in range(1 << n) for b in range(1 << n) if pc(a ^ b) == dist and a < b}
        deg = [sum(1 for (a, b) in covers if v in (a, b)) for v in range(1 << n)]
        ok &= covers == ham and len(covers) == n * 2 ** (n - 1) and set(deg) == {n} and all(pc(a) % 2 != pc(b) % 2 for a, b in covers)
        info.append(str(len(covers)))
    return report('bd·mjg·17', ok, 'cover relations of B_n = pairs at Hamming distance 1; edges n 2^(n-1) = ' + ', '.join(info) + ' (n = 1..7); n-regular; every edge flips the parity')

def check18(sab):
    ok = True; info = []
    for n in range(1, 5):
        verts = list(range(1 << n)); X = lambda a: [(a >> i) & 1 for i in range(n)]
        faces = set()
        rng = (-1, 1) if sab else range(-2, 3)
        for c in itertools.product(rng, repeat=n):
            vals = [sum(ci * xi for ci, xi in zip(c, X(a))) for a in verts]; m = max(vals)
            faces.add(frozenset(a for a in verts if vals[a] == m))
        intervals = {(S, T): frozenset(U for U in verts if S & ~U == 0 and U & ~T == 0) for T in verts for S in verts if S & ~T == 0}
        ok &= faces == set(intervals.values()) and len(faces) == 3 ** n
        for (S, T), F in intervals.items():
            base = X(min(F)); diffs = [[x - y for x, y in zip(X(a), base)] for a in F]
            # rank over Q of 0/1/-1 integer rows (small): Gaussian elimination
            M = [row[:] for row in diffs]; rk = 0
            for col in range(n):
                piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
                if piv is None: continue
                M[rk], M[piv] = M[piv], M[rk]
                for i in range(len(M)):
                    if i != rk and M[i][col]:
                        f = M[i][col] / M[rk][col]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
                rk += 1
            ok &= rk == pc(T & ~S)
        info.append(f'n={n}: {len(faces)} faces')
    fv = {}
    for n in range(1, 8):
        f = [sum(1 for T in range(1 << n) for S in range(1 << n) if S & ~T == 0 and pc(T & ~S) == k) for k in range(n + 1)]
        ok &= f == [comb(n, k) * 2 ** (n - k) for k in range(n + 1)]
        chi = sum((-1) ** k * f[k] for k in range(n + 1))
        ok &= chi == 1
        fv[n] = f
    return report('bd·mjg·18', ok, 'argmax sets of integer functionals on the cube vertices = interval vertex sets, ' + ', '.join(info) + '; dimension = weight; '
                  f'f-vectors {fv[3]}, {fv[4]}, {fv[5]} (n = 3, 4, 5); Euler characteristic 1 (n <= 7), so the boundary has 1 - (-1)^n')

def argmax_faces(n):
    """the faces of [0,1]^n as the argmax sets (vertex labels) of the integer functionals c in {-2..2}^n"""
    verts = range(1 << n); faces = set()
    for c in itertools.product(range(-2, 3), repeat=n):
        vals = [sum(c[i] for i in range(n) if a >> i & 1) for a in verts]; m = max(vals)
        faces.add(frozenset(a for a in verts if vals[a] == m))
    return faces
def check19(sab):
    ok = True; info = []
    for n in range(1, 6):
        V = range(1 << n)
        comp = [(S, T, U) for U in V for T in V for S in V if S & ~T == 0 and T & ~U == 0]
        vset = lambda S, U: frozenset(W for W in V if S & ~W == 0 and W & ~U == 0)      # the vertex labels of the interval [S, U]
        img = [(vset(S, T), T) if sab else (vset(S, U), T) for S, T, U in comp]
        inc = {(F, v) for F in argmax_faces(n) for v in F}                              # (face, vertex) incidences of the cube
        ok &= len(comp) == 4 ** n and set(img) == inc and len(set(img)) == len(comp)
        # join: the smallest interval containing [S,T] and [T,U] is [S,U] (dims add: an identity of popcounts, a remark)
        for S, T, U in comp:
            cands = [(A, B) for B in V for A in V if A & ~B == 0 and A & ~S == 0 and A & ~T == 0 and U & ~B == 0 and T & ~B == 0]
            smallest = min(cands, key=lambda ab: pc(ab[1] & ~ab[0]))
            ok &= smallest == (S, U)
        cnt = []
        for k in range(4):
            ch = [c for c in itertools.product(V, repeat=k + 1) if all(c[j] & ~c[j + 1] == 0 for j in range(k))]
            strict = [c for c in ch if all(c[j] != c[j + 1] for j in range(k))]
            ok &= len(ch) == (k + 2) ** n and len(strict) == sum((-1) ** j * comb(k, j) * (k + 2 - j) ** n for j in range(k + 1))
            cnt.append(f'{len(ch)}/{len(strict)}')
        info.append(f'n={n}: ' + ' '.join(cnt))
    return report('bd·mjg·19', ok, 'composable pairs = (face, vertex) incidences of the cube (faces as argmax sets of integer functionals), 4^n; composite = join of the two faces (dimensions add); nerve k-simplices all/strict for k = 0..3: '
                  + '; '.join(info))

def check20(sab):
    ok = True; info = []
    for n in range(1, 6):
        V = range(1 << n)
        arr = [(S, T) for T in V for S in V if S & ~T == 0]
        def sig(S, T): return frozenset([(i, 1) for i in range(n) if S >> i & 1] + [(i, -1) for i in range(n) if not T >> i & 1])
        orth = {frozenset(f) for m in range(0, n + 1) for f in itertools.combinations([(i, s) for i in range(n) for s in (1, -1)], m) if len({i for i, _ in f}) == m}
        img = {sig(S, T) for S, T in arr}
        ok &= img == orth and len(img) == 3 ** n
        ok &= all(len(sig(S, T)) == n - pc(T & ~S) for S, T in arr)
        ok &= {sig(S, T) for S, T in arr if S == T} == {f for f in orth if len(f) == n} and sig(0, (1 << n) - 1) == frozenset()
        def face_sub(a, b): return b[0] & ~a[0] == 0 and a[1] & ~b[1] == 0     # face [S,T] inside face [S',T']: S' <= S and T <= T'
        rev_ok = True
        for a in arr:
            for b in arr:
                inside = face_sub(a, b)
                rel = sig(*a) <= sig(*b) if sab else sig(*a) >= sig(*b)
                rev_ok &= inside == rel
        ok &= rev_ok
        info.append(f'n={n}: {len(orth) - 1} nonempty faces')
    return report('bd·mjg·20', ok, 'S -> T to the signed set (+S, -complement of T): bijection onto the orthoplex faces with the empty face, n - weight vertices, '
                  'identities to facets, inclusion reversed; ' + ', '.join(info))

CHECKS = [('bd·mjg·17', check17), ('bd·mjg·18', check18), ('bd·mjg·19', check19), ('bd·mjg·20', check20)]

def main():
    if SAB:
        missed = 0
        for cid, fn in CHECKS:
            okk = fn(True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            missed += okk
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        return missed == 0
    for cid, fn in CHECKS: fn(False)
    print('info bd·mjg·21  the A-space of the paper chooses a side of Z0 for each non-identity arrow: 2^(3^n - 2^n) choices; no computed relation to the 3^n faces')
    nfail = sum(1 for _, o in RESULTS if not o)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    return nfail == 0

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
