#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""kep_fock.py: is the Kepler energy trio the step-11 trio through Fock's projection?

    python3 selfcheck/bridges/kep_fock.py              one line per check, ids bd·kep·1 .. bd·kep·6; exit 1 on any FAIL
    python3 selfcheck/bridges/kep_fock.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Deterministic, under 1 s; runs from any folder, reads and writes no file.

Everything is SYMBOLIC and exact: polynomials with Fraction coefficients in the phase-space variables x, p, the radius r (reduced by
r^2 = |x|^2, an exact normal form because r^2 - |x|^2 is monic in r and Q[x, p, r]/(r^2 - |x|^2) is a domain for n >= 2), the reduced mass mu, the
coupling k (potential -k/r) and the Fock parameter c. A rational function is a numerator over a power of r (phase space) or over a power of
D = c + |p|^2 (momentum space); an identity is checked by bringing both sides to one denominator and comparing numerators exactly.
Dimensions n = 2 (the planar problem on T*R^2) and n = 3 (the spatial problem on T*R^3). Standard library only.

Conventions. {f, g} = sum_i (df/dx_i dg/dp_i - df/dp_i dg/dx_i);  H = |p|^2/(2 mu) - k/r and G = 2 mu H = |p|^2 - 2 mu k/r;
L_ab = x_a p_b - x_b p_a;  A = |p|^2 x - (x.p) p - mu k x/r (the Laplace-Runge-Lenz vector, = p x L - mu k x/r for n = 3);
m(c) = (|p|^2 - c)/2 x - (x.p) p, the Fock family (linear in x, independent of k and r);  c = -2 mu E (so c = p0^2 for E < 0);
Fock's map F_c(p) = (z0, z) = ((c - |p|^2), 2p) / (c + |p|^2), onto the quadric Q_c = {z0^2 + c |z|^2 = 1};
Fock's metric g_c = 4 |dp|^2 / (c + |p|^2)^2 on momentum space.
Generators are labelled (A, B), A < B in {0, 1, .., n}: (a, b) with a, b >= 1 is L_ab, (0, a) is the boost-like generator (A_a or m_a).
The bracket of all of them is ONE formula,
    {L_AB, L_CD} = g_AC L_BD - g_AD L_BC - g_BC L_AD + g_BD L_AC,   g = diag(g00, 1, .., 1),
with g00 = -2 mu H (a function) for (L, A) and g00 = c (a number) for (L, m(c)); c = 0 is the Inonu-Wigner contraction.

Check ids bd·kep·1 .. bd·kep·6 (what each computes is in its comment block below).  Fock (1935), Moser (1970), Milnor (1983),
Bander-Itzykson (1966): pointers, sources unread.
"""
import sys
from fractions import Fraction as Fr
from itertools import combinations, product

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, ok))
    if SABOTAGE: print('  sabotaged input, what the check sees: ' + text)
    else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return ok

# ===================================================================== exact multivariate polynomials {exponent tuple: coefficient}
def padd(A, B, s=1):
    out = dict(A)
    for e, v in B.items():
        w = out.get(e, 0) + s * v
        if w: out[e] = w
        else: out.pop(e, None)
    return out
def pscale(A, s): return {e: v * s for e, v in A.items()} if s else {}
def pmul(A, B):
    out = {}
    for ea, va in A.items():
        for eb, vb in B.items():
            e = tuple(i + j for i, j in zip(ea, eb))
            out[e] = out.get(e, 0) + va * vb
    return {e: v for e, v in out.items() if v}
def pderiv(A, i):
    out = {}
    for e, v in A.items():
        if e[i]:
            f = list(e); f[i] -= 1; out[tuple(f)] = v * e[i]
    return out
def pmono(nv, i, k=1):
    e = [0] * nv; e[i] = k; return {tuple(e): 1}
def pconst(nv, v): return {(0,) * nv: v} if v else {}
def peval(A, vals):
    tot = Fr(0)
    for e, v in A.items():
        t = Fr(v)
        for x, k in zip(vals, e):
            if k: t *= Fr(x) ** k
        tot += t
    return tot

# ===================================================================== phase space T*(R^n - 0): functions N / r^e
class PhaseRing:
    """variables x_0..x_{n-1}, p_0..p_{n-1}, r, mu, k, c; N is kept reduced modulo r^2 = |x|^2 (degree <= 1 in r)"""
    def __init__(self, n):
        self.n, self.nv = n, 2 * n + 4
        self.ix, self.ip = list(range(n)), list(range(n, 2 * n))
        self.ir, self.imu, self.ik, self.ic = 2 * n, 2 * n + 1, 2 * n + 2, 2 * n + 3
        X = {}
        for i in self.ix: X = padd(X, pmono(self.nv, i, 2))
        self.Xpow = [pconst(self.nv, 1), X]
    def xp(self, j):
        while len(self.Xpow) <= j: self.Xpow.append(pmul(self.Xpow[-1], self.Xpow[1]))
        return self.Xpow[j]
    def reduce(self, N):
        out = {}; ir = self.ir
        for t, v in N.items():
            q = t[ir]
            if q < 2:
                out[t] = out.get(t, 0) + v; continue
            base = t[:ir] + (q % 2,) + t[ir + 1:]
            for u, w in self.xp(q // 2).items():
                e = tuple(a + b for a, b in zip(base, u)); out[e] = out.get(e, 0) + v * w
        return {e: v for e, v in out.items() if v}
    # elementary functions
    def x(self, i): return PS(pmono(self.nv, self.ix[i]), 0, self)
    def p(self, i): return PS(pmono(self.nv, self.ip[i]), 0, self)
    def sym(self, i): return PS(pmono(self.nv, i), 0, self)
    def const(self, v): return PS(pconst(self.nv, v), 0, self)
    def invr(self): return PS(pconst(self.nv, 1), 1, self)
    def sample(self):
        """an exact sample point (|x| rational) used only to PRINT the value of a non-zero residual"""
        xs = [3, 4] if self.n == 2 else [1, 2, 2]
        ps = [Fr(1, 2), Fr(-1, 3), Fr(1, 4)][:self.n]
        r = 5 if self.n == 2 else 3
        return xs + ps + [r, Fr(1), Fr(1), Fr(1, 7)]       # mu = 1, k = 1, c = 1/7

class PS:
    __slots__ = ('N', 'e', 'R')
    def __init__(self, N, e, R):
        self.R = R; self.N = R.reduce(N); self.e = e
        if not self.N: self.e = 0
        ir = R.ir
        while self.e > 0 and self.N and all(t[ir] == 1 for t in self.N):        # N = r N'  ->  N' / r^(e-1)
            self.N = {t[:ir] + (0,) + t[ir + 1:]: v for t, v in self.N.items()}; self.e -= 1
    def _lift(self, o): return o if isinstance(o, PS) else self.R.const(o)
    def _shift(self, d):                                                    # N r^d
        ir = self.R.ir
        return {t[:ir] + (t[ir] + d,) + t[ir + 1:]: v for t, v in self.N.items()}
    def __add__(self, o):
        o = self._lift(o); e = max(self.e, o.e)
        return PS(padd(self._shift(e - self.e), o._shift(e - o.e)), e, self.R)
    __radd__ = __add__
    def __neg__(self): return PS(pscale(self.N, -1), self.e, self.R)
    def __sub__(self, o): return self + (-self._lift(o))
    def __rsub__(self, o): return self._lift(o) - self
    def __mul__(self, o):
        if not isinstance(o, PS): return PS(pscale(self.N, o), self.e, self.R)
        return PS(pmul(self.N, o.N), self.e + o.e, self.R)
    __rmul__ = __mul__
    def dx(self, i):                                                        # d/dx_i of N(x, r(x)) / r^e, dr/dx_i = x_i / r
        R = self.R; nv = R.nv; e = self.e
        r1, xi = pmono(nv, R.ir), pmono(nv, R.ix[i])
        first = PS(pderiv(self.N, R.ix[i]), e, R)                                # (dN/dx_i) / r^e
        rest = padd(pmul(pmul(r1, xi), pderiv(self.N, R.ir)), pscale(pmul(xi, self.N), -e))
        return first + PS(rest, e + 2, R) if rest else first                    # + x_i (r dN/dr - e N) / r^(e+2)
    def dp(self, i): return PS(pderiv(self.N, self.R.ip[i]), self.e, self.R)
    def zero(self): return not self.N
    def at(self, vals): return peval(self.N, vals) / Fr(vals[self.R.ir]) ** self.e

def pb(f, g):
    n = f.R.n; out = f.R.const(0)
    for i in range(n): out = out + f.dx(i) * g.dp(i) - f.dp(i) * g.dx(i)
    return out
def dot(u, v): return sum((a * b for a, b in zip(u[1:], v[1:])), u[0] * v[0])

# ===================================================================== the one bracket formula of so(diag(g00, 1, .., 1))
def labels(n):
    """(a, b), 1 <= a < b <= n: the rotations L_ab;  (0, a): the boost-like generator (A_a, m_a, or e_a e_ext in the Clifford algebra)"""
    return [(a, b) for a in range(1, n + 1) for b in range(a + 1, n + 1)] + [(0, a) for a in range(1, n + 1)]
def bracket_expansion(F, Gl):
    """{L_F, L_G} = sum_label (u + v g00) L_label, returned as {label: (u, v)} with integers u, v"""
    A, B = F; C, D = Gl; out = {}
    def g(i, j): return (0, 0) if i != j else ((0, 1) if i == 0 else (1, 0))
    def term(gij, I, J, s):
        if gij == (0, 0) or I == J: return
        lab, sg = ((I, J), 1) if I < J else ((J, I), -1)
        u, v = out.get(lab, (0, 0)); out[lab] = (u + s * sg * gij[0], v + s * sg * gij[1])
    term(g(A, C), B, D, 1); term(g(A, D), B, C, -1); term(g(B, C), A, D, -1); term(g(B, D), A, C, 1)
    return {k: v for k, v in out.items() if v != (0, 0)}
def structure_at(n, c):
    """structure constants of g_c at a number c: C[f][g] = {h: coefficient}"""
    labs = labels(n)
    return {f: {g: {h: u + v * c for h, (u, v) in bracket_expansion(f, g).items() if u + v * c != 0} for g in labs} for f in labs}

def signature(M):
    """(positive, negative, zero) of a symmetric rational matrix by exact congruence diagonalisation"""
    n = len(M); A = [[Fr(x) for x in r] for r in M]; pos = neg = 0; active = list(range(n))
    while active:
        piv = next((i for i in active if A[i][i] != 0), None)
        if piv is None:
            pair = next(((i, j) for i in active for j in active if i < j and A[i][j] != 0), None)
            if pair is None: break
            i, j = pair
            for k in range(n): A[i][k] += A[j][k]
            for k in range(n): A[k][i] += A[k][j]
            piv = i
        d = A[piv][piv]
        if d > 0: pos += 1
        else: neg += 1
        for i in active:
            if i != piv and A[i][piv] != 0:
                f = A[i][piv] / d
                for k in range(n): A[i][k] -= f * A[piv][k]
                for k in range(n): A[k][i] -= f * A[k][piv]
        active.remove(piv)
    return (pos, neg, n - pos - neg)
def killing_from_structure(C, labs):
    idx = {h: i for i, h in enumerate(labs)}; m = len(labs)
    ad = {}
    for f in labs:
        M = [[Fr(0)] * m for _ in range(m)]
        for g in labs:
            for h, v in C[f][g].items(): M[idx[h]][idx[g]] += v
        ad[f] = M
    return [[sum(ad[f][i][j] * ad[g][j][i] for i in range(m) for j in range(m)) for g in labs] for f in labs]
def rank(rows):
    M = [list(r) for r in rows if any(r)]; rk = 0
    if not M: return 0
    for col in range(len(M[0])):
        piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]; pv = M[rk][col]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col] / pv; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1
    return rk

def kepler_functions(R, sab_sign=-1):
    """L_ab, the Laplace-Runge-Lenz vector A (sab_sign = -1 is the correct sign of the potential term) and G = 2 mu H"""
    n = R.n; x = [R.x(i) for i in range(n)]; p = [R.p(i) for i in range(n)]
    mu, k, ir = R.sym(R.imu), R.sym(R.ik), R.invr()
    p2, xp = dot(p, p), dot(x, p)
    G = p2 - 2 * mu * k * ir
    L = {(a, b): x[a - 1] * p[b - 1] - x[b - 1] * p[a - 1] for a in range(1, n + 1) for b in range(a + 1, n + 1)}
    A = {a: p2 * x[a - 1] - xp * p[a - 1] + sab_sign * mu * k * x[a - 1] * ir for a in range(1, n + 1)}
    return x, p, p2, xp, G, L, A
def fock_m(R, x, p, p2, xp, c):
    """the Fock family m_a(c) = (|p|^2 - c)/2 x_a - (x.p) p_a; c a PS function (the symbol c, or c = -2 mu H on the energy surface)"""
    return {a: (p2 - c) * Fr(1, 2) * x[a - 1] - xp * p[a - 1] for a in range(1, R.n + 1)}
def gen_dict(L, B):
    d = {lab: v for lab, v in L.items()}
    for a, v in B.items(): d[(0, a)] = v
    return d

# =====================================================================================================================================
# bd·kep·1  The Poisson algebra of the Kepler problem, exact and symbolic (mu, k symbols; every point of T*(R^n - 0); n = 2, 3):
#   {L, L} = L, {L_ab, A_c} = d_ac A_b - d_bc A_a, {A_a, A_b} = -2 mu H L_ab: the bracket formula with g00 = -2 mu H;
#   {H, L} = {H, A} = 0;  A ^ L = 0 (n = 3: A.L = 0);  |A|^2 = mu^2 k^2 + 2 mu H |L|^2.
#   Decisive because it replaces the finite-difference check baez·K1a by an identity in the polynomial ring; nothing is sampled.
#   Sabotage: the potential term of A with the wrong sign (A = p x L + mu k x/r): {H, A} is then not zero (value printed).
# =====================================================================================================================================
def check1(sab):
    ok = True; info = []
    for n in (2, 3):
        R = PhaseRing(n)
        x, p, p2, xp, G, L, A = kepler_functions(R, +1 if sab else -1)
        gens = gen_dict(L, A); labs = labels(n); g00 = -G
        cnt = bad = 0
        for f, g in combinations(labs, 2):
            exp = R.const(0)
            for h, (u, v) in bracket_expansion(f, g).items(): exp = exp + (u + v * g00) * gens[h]
            cnt += 1
            if not (pb(gens[f], gens[g]) - exp).zero(): bad += 1
        cons = [pb(G, gens[f]) for f in labs]; badc = sum(1 for z in cons if not z.zero())
        wedge = [A[a] * L[(b, cc)] - A[b] * L[(a, cc)] + A[cc] * L[(a, b)] for a, b, cc in combinations(range(1, n + 1), 3)]
        badw = sum(1 for z in wedge if not z.zero())
        L2 = R.const(0)
        for v in L.values(): L2 = L2 + v * v
        A2 = dot([A[a] for a in range(1, n + 1)], [A[a] for a in range(1, n + 1)])
        mu, k = R.sym(R.imu), R.sym(R.ik)
        cas = A2 - mu * mu * k * k - G * L2
        ok &= bad == 0 and badc == 0 and badw == 0 and cas.zero()
        s = R.sample(); val = cons[-1].at(s)
        info.append(f'n = {n}: {cnt} brackets, {cnt - bad} equal to the formula; {len(labs) - badc} of {len(labs)} generators commute with H '
                    f'({{2 mu H, A_{n}}} at a sample point = {val}); A ^ L = 0 in {len(wedge) - badw} of {len(wedge)} components; '
                    f'|A|^2 = mu^2 k^2 + 2 mu H |L|^2: {cas.zero()}')
    report('bd·kep·1', ok, 'exact symbolic Poisson algebra of L and A on T*(R^n - 0) (mu, k symbols, reduction r^2 = |x|^2): {L,L} = L, '
           '{L_ab, A_c} = d_ac A_b - d_bc A_a, {A_a, A_b} = -2 mu H L_ab, {H, L} = {H, A} = 0, A ^ L = 0, |A|^2 = mu^2 k^2 + 2 mu H |L|^2. '
           + '; '.join(info))
    return ok

# =====================================================================================================================================
# bd·kep·2  One Inonu-Wigner family in the energy.  The Fock family m(c) = (|p|^2 - c)/2 x - (x.p) p satisfies, identically in x, p, c:
#   A = m(c) + ((2 mu H + c)/2) x, so A = m(-2 mu E) on the energy surface Sigma_E = {H = E}, and in fact A = m(-2 mu H) as functions;
#   {L, L} = L, {L_ab, m_c} = d_ac m_b - d_bc m_a, {m_a, m_b} = c L_ab (the bracket formula with g00 = c: structure constants
#   polynomial in c);  {A_a, A_b} - {m_a, m_b} = -(2 mu H + c) L_ab, which vanishes on Sigma_E for c = -2 mu E.
#   The Killing form of g_c, computed from these structure constants as a polynomial in c, is diag(-2(n-1) on L, -2(n-1) c on m):
#   signature (0, N, 0) for c > 0, (0, N - n, n) for c = 0, (n, N - n, 0) for c < 0 (N = n(n+1)/2), and g_c is so(n+1), e(n), so(n,1).
#   With the rescaling M = A / sqrt(|2 mu E|) (E != 0), M = A (E = 0): [M, M] = eps L with eps = -sign(E) (+1, 0, -1 for E <, =, > 0).
#   Decisive because the whole trio is ONE family of structure constants in c = -2 mu E, contracted at c = 0, and the bound / parabolic /
#   scattering algebras are its members; the Killing signatures are the ones core·B16 lists for (+1,+1,+1,eps).
#   Sabotage (the requested one): the wrong sign of E in the rescaling: c = +2 mu E in the Fock family and |rho| with the sign of +2 mu E
#   in the rescaling square; then A != m on Sigma_E (residual 2 mu H x printed) and the bound / scattering algebras flip.
# =====================================================================================================================================
def check2(sab):
    ok = True; info = []
    sgnE = 1 if sab else -1                      # c = sgnE * 2 mu E  (correct: c = -2 mu E)
    for n in (2, 3):
        R = PhaseRing(n); N = n * (n + 1) // 2
        x, p, p2, xp, G, L, A = kepler_functions(R)
        c = R.sym(R.ic)
        m = fock_m(R, x, p, p2, xp, c)
        idA = all((A[a] - m[a] - (G + c) * Fr(1, 2) * x[a - 1]).zero() for a in m)
        mE = fock_m(R, x, p, p2, xp, sgnE * G)        # the Fock family put on the energy surface of the point: c = -2 mu H
        resid = [A[a] - mE[a] for a in mE]; onshell = all(z.zero() for z in resid)
        gens = gen_dict(L, m); labs = labels(n); bad = 0; cnt = 0
        for f, g in combinations(labs, 2):
            exp = R.const(0)
            for h, (u, v) in bracket_expansion(f, g).items(): exp = exp + (u + v * c) * gens[h]
            cnt += 1
            if not (pb(gens[f], gens[g]) - exp).zero(): bad += 1
        diffAA = all((pb(A[a], A[b]) - pb(m[a], m[b]) + (G + c) * L[(a, b)]).zero() for a, b in combinations(range(1, n + 1), 2))
        # Killing form of g_c as a polynomial in c: entries u + v c; evaluate the polynomial identity by its values at three c (degree <= 1 per
        # structure constant, so the Killing form has degree <= 2 in c and three values determine it)
        Ks = {cv: killing_from_structure(structure_at(n, cv), labs) for cv in (Fr(-1), Fr(0), Fr(1))}
        diagonal = all(Ks[cv][i][j] == 0 for cv in Ks for i in range(N) for j in range(N) if i != j)
        Lpart = all(Ks[cv][i][i] == -2 * (n - 1) for cv in Ks for i in range(N - n))
        mpart = all(Ks[cv][i][i] == -2 * (n - 1) * cv for cv in Ks for i in range(N - n, N))
        sigs = {cv: signature(Ks[cv]) for cv in Ks}
        # rescaling on Sigma_E: {A_a, A_b} = -2 mu E L_ab there, M = A / sqrt(rho): [M, M] = (-2 mu E / rho) L
        mu_s = Fr(2); want = {-1: (0, N, 0), 0: (0, N - n, n), 1: (n, N - n, 0)}     # keyed by sign(E)
        got = {}
        for E in (Fr(-1, 8), Fr(0), Fr(1, 8)):
            rho = abs(2 * mu_s * E) if E != 0 else Fr(1)
            if sab and E != 0: rho = -rho                     # sabotage: the square of the rescaling has the wrong sign of E
            eps = -2 * mu_s * E / rho
            got[(E > 0) - (E < 0)] = (eps, signature(killing_from_structure(structure_at(n, eps), labs)))
        resc = all(got[s][1] == want[s] for s in want)
        ok &= idA and onshell and bad == 0 and diffAA and diagonal and Lpart and mpart and resc
        s = R.sample(); rv = resid[0].at(s)
        info.append(f'n = {n}: A = m(c) + ((2 mu H + c)/2) x: {idA}; A - m(-2 mu E) on Sigma_E = 0: {onshell} (component 1 at a sample point: {rv}); '
                    f'{cnt - bad} of {cnt} brackets of (L, m(c)) equal the formula with g00 = c; {{A,A}} - {{m,m}} = -(2 mu H + c) L: {diffAA}; '
                    f'Killing form diag(-{2 * (n - 1)} on L, -{2 * (n - 1)} c on m): {diagonal and Lpart and mpart}, signatures at c = 1, 0, -1: '
                    f'{sigs[Fr(1)]}, {sigs[Fr(0)]}, {sigs[Fr(-1)]}; rescaled on Sigma_E for E < 0, = 0, > 0: eps = '
                    f'{got[-1][0]}, {got[0][0]}, {got[1][0]}, Killing {got[-1][1]}, {got[0][1]}, {got[1][1]}')
    report('bd·kep·2', ok, 'one Inonu-Wigner family in c = -2 mu E: A = m(-2 mu E) on Sigma_E with the Fock family m(c) = (|p|^2 - c)/2 x - (x.p) p; '
           '(L, m(c)) close with {m_a, m_b} = c L_ab identically in c (contraction e(n) at c = 0); bound / parabolic / scattering = c > 0, = 0, < 0 = '
           'so(n+1), e(n), so(n,1). ' + '; '.join(info))
    return ok

# ===================================================================== momentum space: rational functions N / D^e, D a fixed polynomial
class MomRing:
    """variables p_1..p_n, c (indices 0..n-1, n); D = sD c + |p|^2 (sD = +1: Fock's denominator; sD = -1: the sabotage, c -> -c), or a given
    D = p_v (control); lin = (v, a, q) with D = a v + q, a = +-1 and q free of v, used to cancel factors of D exactly (synthetic division)"""
    def __init__(self, n, D=None, sD=1):
        self.n, self.nv, self.ic, self.sD = n, n + 1, n, sD
        p2 = {}
        for i in range(n): p2 = padd(p2, pmono(self.nv, i, 2))
        if D is None:
            D = padd(pscale(pmono(self.nv, n), sD), p2); self.lin = (n, sD, p2)
        else:
            v = next(i for i in range(self.nv) if any(t[i] for t in D)); self.lin = (v, 1, {})
            assert D == pmono(self.nv, v)
        self.D = D; self.dD = [pderiv(D, i) for i in range(n)]; self.Dp = [pconst(self.nv, 1)]
    def divD(self, N):
        """N / D if D divides N exactly, else None"""
        v, a, q = self.lin; by = {}
        for t, val in N.items(): by.setdefault(t[v], {})[t[:v] + (0,) + t[v + 1:]] = val
        Q = {}; cur = dict(by.get(max(by), {})); d = max(by)
        for j in range(d, 0, -1):
            Qj = pscale(cur, Fr(1, a))
            for key, val in Qj.items(): Q[key[:v] + (j - 1,) + key[v + 1:]] = val
            cur = padd(by.get(j - 1, {}), pmul(q, Qj), -1)
        return None if cur else Q
    def Dpow(self, j):
        while len(self.Dp) <= j: self.Dp.append(pmul(self.Dp[-1], self.D))
        return self.Dp[j]
    def p(self, i): return DF(pmono(self.nv, i), 0, self)
    def c(self): return DF(pmono(self.nv, self.ic), 0, self)
    def const(self, v): return DF(pconst(self.nv, v), 0, self)
    def poly(self, P): return DF(P, 0, self)

class DF:
    __slots__ = ('N', 'e', 'X')
    def __init__(self, N, e, X):
        if e < 0: N = pmul(N, X.Dpow(-e)); e = 0
        while e > 0 and N:                                                      # cancel common factors of D (exact)
            Q = X.divD(N)
            if Q is None: break
            N, e = Q, e - 1
        self.N, self.e, self.X = N, (e if N else 0), X
    def _lift(self, o): return o if isinstance(o, DF) else self.X.const(o)
    def __add__(self, o):
        o = self._lift(o); e = max(self.e, o.e)
        return DF(padd(pmul(self.N, self.X.Dpow(e - self.e)), pmul(o.N, self.X.Dpow(e - o.e))), e, self.X)
    __radd__ = __add__
    def __neg__(self): return DF(pscale(self.N, -1), self.e, self.X)
    def __sub__(self, o): return self + (-self._lift(o))
    def __rsub__(self, o): return self._lift(o) - self
    def __mul__(self, o):
        if not isinstance(o, DF): return DF(pscale(self.N, o), self.e, self.X)
        return DF(pmul(self.N, o.N), self.e + o.e, self.X)
    __rmul__ = __mul__
    def d(self, i):
        if self.e == 0: return DF(pderiv(self.N, i), 0, self.X)
        return DF(padd(pmul(self.X.D, pderiv(self.N, i)), pscale(pmul(self.N, self.X.dD[i]), -self.e)), self.e + 1, self.X)
    def zero(self): return not self.N
    def at_c(self, cv):
        """substitute the number cv for c (numerator and D); returns (N, Dpow) as plain polynomials in p"""
        ic = self.X.ic
        def sub(P):
            out = {}
            for t, v in P.items():
                e = t[:ic] + (0,) + t[ic + 1:]; out[e] = out.get(e, 0) + v * Fr(cv) ** t[ic]
            return {e: v for e, v in out.items() if v}
        return sub(self.N), sub(self.X.Dpow(self.e))

def fock_map(X):
    """F_c(p) = (z0, z) = ((sD c - |p|^2), 2p) / D in the ring X (D = sD c + |p|^2)"""
    n = X.n; p2 = {}
    for i in range(n): p2 = padd(p2, pmono(X.nv, i, 2))
    z0 = DF(padd(pscale(pmono(X.nv, X.ic), X.sD), p2, -1), 1, X)
    z = [DF(pscale(pmono(X.nv, i), 2), 1, X) for i in range(n)]
    return z0, z

def riemann_residual(g, ginv, X, K):
    """R_lijk - K (g_lj g_ik - g_lk g_ij) for the metric g (matrix of DF), with R^l_ijk = d_j G^l_ki - d_k G^l_ji + G^l_jm G^m_ki - G^l_km G^m_ji;
    returns the number of non-zero components (the metric has constant sectional curvature K iff it is 0)"""
    n = X.n; rng = range(n)
    dg = [[[g[a][b].d(i) for i in rng] for b in rng] for a in rng]
    Gam = [[[sum(((dg[m][j][i] + dg[m][i][j] - dg[i][j][m]) * ginv[l][m] for m in rng), X.const(0)) * Fr(1, 2)
             for j in rng] for i in rng] for l in rng]                       # Gam[l][i][j] = Gamma^l_ij
    bad = 0; zero = X.const(0)
    Rup = {}
    for mm in rng:
        for i in rng:
            for j in rng:
                for k in rng:
                    if j < k:
                        Rup[(mm, i, j, k)] = (Gam[mm][k][i].d(j) - Gam[mm][j][i].d(k) +
                                              sum((Gam[mm][j][q] * Gam[q][k][i] - Gam[mm][k][q] * Gam[q][j][i] for q in rng), zero))
    for l in rng:
        for i in rng:
            for j in rng:
                for k in rng:
                    if j >= k: continue                                      # antisymmetric in (j, k)
                    Rlow = sum((g[l][mm] * Rup[(mm, i, j, k)] for mm in rng), zero)
                    if not (Rlow - K * (g[l][j] * g[i][k] - g[l][k] * g[i][j])).zero(): bad += 1
    return bad

# =====================================================================================================================================
# bd·kep·3  Fock's map and its target, one family in c (n = 2, 3; c a symbol, so all three energies at once):
#   (a) F_c(p) = ((c - |p|^2), 2p)/(c + |p|^2) satisfies z0^2 + c |z|^2 = 1 identically: the round sphere of radius 1/sqrt(c) (c > 0),
#       the two-sheeted hyperboloid (c < 0), and at c = 0 the hyperplane z0 = -1 with z = 2p/|p|^2 (inversion);
#   (b) F_c pulls |dz|^2 + dz0^2/c back to g_c = 4|dp|^2/(c + |p|^2)^2 (dz0 carries a factor c, so the pull-back is polynomial in c and holds at
#       c = 0 too);
#   (c) g_c has constant sectional curvature c (full Riemann tensor from the Christoffel symbols, exact rational functions);
#       control of the curvature convention: the half-space metric |dp|^2/p_n^2 gives -1.
#   So the targets are S^n (E < 0), R^n (E = 0), H^n (E > 0), of curvature -2 mu E, one family.
#   Sabotage: Fock's map with the wrong sign of E (c -> -c, i.e. p0^2 = +2 mu E): the quadric identity fails and the curvature is -c.
# =====================================================================================================================================
def check3(sab):
    ok = True; info = []
    sD = -1 if sab else 1
    for n in (2, 3):
        X = MomRing(n, sD=sD); c = X.c(); rng = range(n)
        z0, z = fock_map(X)
        quad = (z0 * z0 + c * sum((zi * zi for zi in z[1:]), z[0] * z[0]) - 1).zero()
        # pulled-back metric: J0 = dz0/dp has a factor c; h = sum_a dz_a dz_a + c (J0/c)(J0/c)
        J = [[zi.d(j) for j in rng] for zi in z]; J0 = [z0.d(j) for j in rng]
        divisible = all(all(t[X.ic] >= 1 for t in J0[j].N) for j in rng)
        J0c = [DF({t[:X.ic] + (t[X.ic] - 1,) + t[X.ic + 1:]: v for t, v in J0[j].N.items()}, J0[j].e, X) for j in rng] if divisible else None
        D = X.poly(X.D)
        g = [[DF(pconst(X.nv, 4 if i == j else 0), 2, X) for j in rng] for i in rng]           # Fock's metric 4 delta / D^2 (in the ring's D)
        pull = divisible and all((sum((J[a][i] * J[a][j] for a in rng), X.const(0)) + c * J0c[i] * J0c[j] - g[i][j]).zero()
                                 for i in rng for j in rng)
        ginv = [[(D * D * Fr(1, 4)) if i == j else X.const(0) for j in rng] for i in rng]
        inv_ok = all((sum((g[i][k] * ginv[k][j] for k in rng), X.const(0)) - (1 if i == j else 0)).zero() for i in rng for j in rng)
        badK = riemann_residual(g, ginv, X, c)                    # constant curvature +c ?
        badKm = riemann_residual(g, ginv, X, -c)                  # or -c ?
        curv = 'c' if badK == 0 else ('-c' if badKm == 0 else 'not constant c or -c')
        z0_at0 = z0.at_c(0); flat = (padd(z0_at0[0], z0_at0[1]) == {})               # z0 = -1 at c = 0
        # control: the half-space metric |dp|^2 / p_n^2 has curvature -1 (fixes the sign convention of the Riemann tensor)
        Y = MomRing(n, D=pmono(n + 1, n - 1))
        gH = [[DF(pconst(n + 1, 1 if i == j else 0), 2, Y) for j in rng] for i in rng]
        gHi = [[DF(pmul(Y.D, Y.D), 0, Y) if i == j else Y.const(0) for j in rng] for i in rng]
        ctrl = riemann_residual(gH, gHi, Y, Y.const(-1)) == 0
        ok &= quad and pull and inv_ok and badK == 0 and flat and ctrl
        info.append(f'n = {n}: z0^2 + c|z|^2 = 1: {quad}; pull-back of |dz|^2 + dz0^2/c = 4|dp|^2/(c+|p|^2)^2: {pull}; '
                    f'sectional curvature of g_c: {curv} ({badK} non-zero components of R - c(gg - gg)); at c = 0, z0 = -1: {flat}; '
                    f'half-space control curvature -1: {ctrl}')
    report('bd·kep·3', ok, "Fock's map F_c(p) = (c - |p|^2, 2p)/(c + |p|^2) onto z0^2 + c|z|^2 = 1, an isometry from Fock's metric "
           "g_c = 4|dp|^2/(c+|p|^2)^2 of constant curvature c = -2 mu E: sphere, flat (inversion, z0 = -1), hyperbolic. " + '; '.join(info))
    return ok

# ===================================================================== helpers: the momentum-space vector field of a function linear in x
def ps_to_mom(P, R, X):
    """a phase-space polynomial in (p, c) only -> the momentum ring"""
    out = {}
    for t, v in P.N.items():
        assert P.e == 0 and all(t[i] == 0 for i in R.ix) and t[R.ir] == t[R.imu] == t[R.ik] == 0
        e = tuple(t[i] for i in R.ip) + (t[R.ic],); out[e] = out.get(e, 0) + v
    return DF(out, 0, X)
def vfield(f, R, X):
    """V_f(p) = df/dx for f linear in x: the p-part of the Hamiltonian flow of f is -V_f, and f -> V_f is a Lie algebra homomorphism
    ({x.V, x.W} = x.[V, W], [V, W] = (V.grad) W - (W.grad) V)"""
    return [ps_to_mom(f.dx(i), R, X) for i in range(R.n)]
def vbracket(V, W, X):
    n = X.n
    return [sum((V[k] * W[l].d(k) - W[k] * V[l].d(k) for k in range(n)), X.const(0)) for l in range(n)]
def killing_residual(V, X):
    """L_V g_c for g_c = 4 delta / D^2, multiplied by D^3/4: -2 (V.grad D) delta_ij + D (d_i V_j + d_j V_i)"""
    n = X.n; D = X.poly(X.D); VD = sum((V[k] * X.poly(X.dD[k]) for k in range(n)), X.const(0))
    return [(D * (V[j].d(i) + V[i].d(j)) - (2 * VD if i == j else 0)) for i in range(n) for j in range(i, n)]
def omega(lab, n, X):
    """the target Killing field z -> Omega z on (z0, z1..zn) (index 0 = z0): Omega_{L_ab} = E_ab - E_ba, Omega_{m_a} = -(E_a0 - c E_0a)"""
    M = [[X.const(0) for _ in range(n + 1)] for _ in range(n + 1)]
    A, B = lab
    if A >= 1: M[A][B] = X.const(1); M[B][A] = X.const(-1)
    else: M[B][0] = X.const(-1); M[0][B] = X.c()
    return M
def matmul(P, Q, X):
    m = len(P)
    return [[sum((P[i][k] * Q[k][j] for k in range(m)), X.const(0)) for j in range(m)] for i in range(m)]

# =====================================================================================================================================
# bd·kep·4  Pushing the Poisson algebra through Fock's map (n = 2, 3; c a symbol):
#   every generator f of g_c (L_ab and m_a(c)) is linear in x, so its Hamiltonian flow moves the momentum by the field -V_f(p), V_f = df/dx;
#   (a) f -> V_f is a Lie algebra homomorphism: V_{f,g} = [V_f, V_g] for all pairs;
#   (b) every V_f is a Killing field of Fock's metric g_c (Killing equation, identity in p and c);
#   (c) F_c pushes V_f to the linear field z -> Omega_f z of the quadric: rotations for L_ab, -(z0 d_a - c z_a d_0) for m_a;
#   (d) every Omega_f preserves the form z0^2 + c|z|^2; Omega_{f,g} = Omega_g Omega_f - Omega_f Omega_g (bracket of linear fields);
#       the Omega_f are independent at c = 1, 0, -1 (rank N);
#   (e) the Killing fields of g_c among polynomial fields of degree <= 3 form a space of dimension exactly N = n(n+1)/2 (c = 1, 0, -1, 4, -1/4):
#       the image is the whole Killing algebra in that class (control: the solver finds N - n for the less symmetric 4|dp|^2/(1 + p_1^2)^2).
#   So the Poisson algebra (L, m(c)) - on Sigma_E the algebra of (L, A) - becomes the Killing algebra of S^n, R^n, H^n under Fock's map.
#   Sabotage: the Fock family with the wrong sign of E (m(-c)) against Fock's metric g_c: the Killing equation and (c) fail.
# =====================================================================================================================================
def fock_D(n, cv):
    D = pconst(n, Fr(cv))
    for i in range(n): D = padd(D, pmono(n, i, 2))
    return D
def killing_dimension(n, D, deg=3):
    """dimension of the space of polynomial vector fields V of degree <= deg with -2 (V.grad D) delta + D (dV + dV^T) = 0, i.e. the Killing
    fields of 4|dp|^2/D^2 (exact linear algebra over Q; D a polynomial in p_1..p_n)"""
    monos = [e for e in product(range(deg + 1), repeat=n) if sum(e) <= deg]
    nun = n * len(monos); rows = {}
    dD = [pderiv(D, i) for i in range(n)]
    for comp in range(n):
        for mi, e in enumerate(monos):
            col = comp * len(monos) + mi; V = [dict() for _ in range(n)]; V[comp] = {e: 1}
            VD = {}
            for k in range(n): VD = padd(VD, pmul(V[k], dD[k]))
            for i in range(n):
                for j in range(i, n):
                    expr = pmul(D, padd(pderiv(V[j], i), pderiv(V[i], j)))
                    if i == j: expr = padd(expr, pscale(VD, -2))
                    for t, v in expr.items():
                        rows.setdefault((i, j, t), [Fr(0)] * nun)[col] += v
    return nun - rank(list(rows.values()))

def check4(sab):
    ok = True; info = []
    for n in (2, 3):
        R = PhaseRing(n); X = MomRing(n); N = n * (n + 1) // 2
        x, p, p2, xp, G, L, A = kepler_functions(R)
        c = R.sym(R.ic)
        m = fock_m(R, x, p, p2, xp, -c if sab else c)
        gens = gen_dict(L, m); labs = labels(n)
        V = {f: vfield(gens[f], R, X) for f in labs}
        hom = all(all((a - b).zero() for a, b in zip(vfield(pb(gens[f], gens[g]), R, X), vbracket(V[f], V[g], X)))
                  for f, g in combinations(labs, 2))
        kill_bad = [f for f in labs if not all(r.zero() for r in killing_residual(V[f], X))]
        z0, z = fock_map(X); zz = [z0] + z
        Om = {f: omega(f, n, X) for f in labs}
        push_bad = []
        for f in labs:
            dF = [sum((zz[A_].d(j) * V[f][j] for j in range(n)), X.const(0)) for A_ in range(n + 1)]
            Oz = [sum((Om[f][A_][B_] * zz[B_] for B_ in range(n + 1)), X.const(0)) for A_ in range(n + 1)]
            if not all((u - v).zero() for u, v in zip(dF, Oz)): push_bad.append(f)
        Gc = [[X.const(1) if (i == j == 0) else (X.c() if i == j else X.const(0)) for j in range(n + 1)] for i in range(n + 1)]
        preserve = True
        for f in labs:
            P1, P2 = matmul([list(r) for r in zip(*Om[f])], Gc, X), matmul(Gc, Om[f], X)
            preserve &= all((P1[i][j] + P2[i][j]).zero() for i in range(n + 1) for j in range(n + 1))
        brk = True
        for f, g in combinations(labs, 2):
            exp = [[X.const(0) for _ in range(n + 1)] for _ in range(n + 1)]
            for h, (u, v) in bracket_expansion(f, g).items():
                coef = X.const(u) + X.c() * v
                exp = [[exp[i][j] + coef * Om[h][i][j] for j in range(n + 1)] for i in range(n + 1)]
            lhs = [[a - b for a, b in zip(r1, r2)] for r1, r2 in zip(matmul(Om[g], Om[f], X), matmul(Om[f], Om[g], X))]
            brk &= all((lhs[i][j] - exp[i][j]).zero() for i in range(n + 1) for j in range(n + 1))
        ranks = []
        for cv in (1, 0, -1):
            rows = [[peval(Om[f][i][j].N, [0] * n + [cv]) for i in range(n + 1) for j in range(n + 1)] for f in labs]
            ranks.append(rank(rows))
        kdim = {cv: killing_dimension(n, fock_D(n, cv)) for cv in (1, 0, -1, 4, Fr(-1, 4))}
        ctrl = killing_dimension(n, padd(pconst(n, 1), pmono(n, 0, 2)))      # control: 4|dp|^2/(1 + p_1^2)^2 has fewer symmetries
        good = (hom and not kill_bad and not push_bad and preserve and brk and all(r_ == N for r_ in ranks) and all(v == N for v in kdim.values())
                and ctrl == N - n)
        ok &= good
        info.append(f'n = {n}: V_{{f,g}} = [V_f, V_g]: {hom}; Killing for g_c: {N - len(kill_bad)} of {N}; F_c pushes V_f to Omega_f z: '
                    f'{N - len(push_bad)} of {N}; Omega_f preserve z0^2 + c|z|^2: {preserve}; Omega brackets = the formula: {brk}; '
                    f'rank of the Omega_f at c = 1, 0, -1: {ranks}; dimension of the polynomial (degree <= 3) Killing fields of g_c at '
                    f'c = 1, 0, -1, 4, -1/4: {list(kdim.values())} (control: the metric 4|dp|^2/(1 + p_1^2)^2 has {ctrl})')
    report('bd·kep·4', ok, "Fock's map carries the Poisson algebra of (L, m(c)) - on Sigma_E that of (L, A) - onto the Killing algebra of its target: "
           "each generator acts on momentum space by a Killing field of g_c, pushed by F_c to a rotation or to z0 d_a - c z_a d_0. " + '; '.join(info))
    return ok

# ===================================================================== the bit rule (as in core_check.py): e_a e_b = s(a, b) e_{a xor b}
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def mv_mul(A, B, eps):
    out = {}
    for a, ca in A.items():
        for b, cb in B.items():
            v = ca * cb * sgn(a, b, eps)
            if v: out[a ^ b] = out.get(a ^ b, 0) + v
    return {k: v for k, v in out.items() if v != 0}
def mv_comm(A, B, eps):
    P, Q = mv_mul(A, B, eps), mv_mul(B, A, eps)
    out = dict(P)
    for k, v in Q.items(): out[k] = out.get(k, 0) - v
    return {k: v for k, v in out.items() if v != 0}

# =====================================================================================================================================
# bd·kep·5  The step-11 algebra (core·B16): the bit-rule algebra Cl(-1, .., -1, s) (n base generators of square -1, one extra generator of
#   square s; n = 2, 3).  phi: L_ab -> (1/2) e_a e_b, (0,a) -> -(1/2) e_a e_ext.  For eps = +1, 0, -1 (the rescaled g_eps of bd·kep·2):
#   (a) phi is a Lie algebra isomorphism g_eps -> bivectors of Cl(-1, .., -1, s) exactly when s = -eps (all brackets; the other two s fail);
#   (b) the Killing signatures of the bivector algebras are (0,N,0), (0,N-n,n), (n,N-n,0) for s = -1, 0, +1 (core·B16 for n = 3);
#   (c) ad(phi(f)) on the Clifford vectors (e_ext <-> z0, e_a <-> z_a) is the transpose of Fock's Omega_f at c = eps: the Fock target carries the
#       dual of the Clifford vector representation (for s = 0 the Clifford vectors are planes, as in PGA, and Fock's z are points);
#   (d) the rotations L are the isotropy algebra of the Fock pole z = (-1, 0) (the image of |p| = infinity, the collision direction): the
#       Klein pair (g, h) of step 11 with h = the base bivectors.
#   So E < 0, = 0, > 0 is s = -1, 0, +1 = sign(E): sphere, Euclid, hyperbolic space of step 11 with a space base.
#   Sabotage: the identification with s = +eps (the sign of core·B16 ignored): (a) fails for eps = +1 and -1.
# =====================================================================================================================================
def check5(sab):
    ok = True; info = []
    for n in (2, 3):
        labs = labels(n); N = len(labs); ext = n
        def phi(lab):
            A, B = lab
            if A >= 1: return {(1 << (A - 1)) | (1 << (B - 1)): Fr(1, 2)}
            return {(1 << (B - 1)) | (1 << ext): Fr(-1, 2)}
        table = {}
        for eps in (1, 0, -1):
            C = structure_at(n, eps)
            for s in (-1, 0, 1):
                sig_cl = [-1] * n + [s]; good = True
                for f, g in combinations(labs, 2):
                    exp = {}
                    for h, v in C[f][g].items():
                        for k, w in phi(h).items(): exp[k] = exp.get(k, 0) + v * w
                    exp = {k: v for k, v in exp.items() if v}
                    if mv_comm(phi(f), phi(g), sig_cl) != exp: good = False; break
                table[(eps, s)] = good
        s_of = {eps: -eps for eps in (1, 0, -1)} if not sab else {eps: eps for eps in (1, 0, -1)}
        iso = all(table[(eps, s_of[eps])] for eps in (1, 0, -1))
        only = all(table[(eps, s)] == (s == -eps) for eps in (1, 0, -1) for s in (-1, 0, 1))
        # Killing signatures of the bivector algebras straight from the bit rule (as core·B16)
        sig_s = {}
        for s in (-1, 0, 1):
            sig_cl = [-1] * n + [s]
            bl = [(1 << i) | (1 << j) for i in range(n + 1) for j in range(i + 1, n + 1)]
            Cb = {}
            for x_ in bl:
                Cb[x_] = {}
                for y_ in bl:
                    Cb[x_][y_] = mv_comm({x_: Fr(1)}, {y_: Fr(1)}, sig_cl)
            sig_s[s] = signature(killing_from_structure(Cb, bl))
        want = {-1: (0, N, 0), 0: (0, N - n, n), 1: (n, N - n, 0)}
        sig_ok = all(sig_s[s] == want[s] for s in want)
        # (c) ad(phi f) on vectors equals the transpose of Omega_f at c = eps (index 0 <-> e_ext, a <-> e_{a-1})
        def vec(i): return 1 << ext if i == 0 else 1 << (i - 1)
        def Omega(f, cv):
            A, B = f; Om = [[0] * (n + 1) for _ in range(n + 1)]
            if A >= 1: Om[A][B], Om[B][A] = 1, -1
            else: Om[B][0], Om[0][B] = -1, cv
            return Om
        dual = True
        for eps in (1, 0, -1):
            s = s_of[eps]; sig_cl = [-1] * n + [s]
            for f in labs:
                Om = Omega(f, eps)
                for col in range(n + 1):
                    img = mv_comm(phi(f), {vec(col): Fr(1)}, sig_cl)
                    if any(pc(kk) != 1 for kk in img): dual = False
                    for row in range(n + 1):
                        if img.get(vec(row), 0) != Om[col][row]: dual = False
        # (d) isotropy of the pole z = (-1, 0, .., 0): Omega_f pole = 0 exactly for the rotations, at every eps
        iso_pole = True
        for eps in (1, 0, -1):
            fixers = [f for f in labs if all(-Omega(f, eps)[row][0] == 0 for row in range(n + 1))]
            iso_pole &= fixers == [f for f in labs if f[0] >= 1]
        good = iso and only and sig_ok and dual and iso_pole
        ok &= good
        tab = ' '.join(f'(eps {e:+d}, s {s:+d}): {"iso" if table[(e, s)] else "no"}' for e in (1, 0, -1) for s in (-1, 0, 1))
        info.append(f'n = {n}: {tab}; Killing signatures of the bivectors of Cl(-1..-1, s) for s = -1, 0, +1: {sig_s[-1]}, {sig_s[0]}, {sig_s[1]}; '
                    f'ad(phi f) = transpose of Omega_f: {dual}; isotropy of the Fock pole = span L: {iso_pole}')
    report('bd·kep·5', ok, 'the Kepler algebra g_eps (eps = -sign E) is the bivector algebra of Cl(-1,..,-1, s) of step 11 exactly for s = -eps = sign E '
           '(core·B16), via L_ab -> e_a e_b / 2, m_a -> -e_a e_ext / 2, and Fock\'s quadric carries the dual of its vector representation. ' + '; '.join(info))
    return ok

# =====================================================================================================================================
# bd·kep·6  Hodographs, symbolic at EVERY phase-space point (so for every orbit: any mu, k, energy, eccentricity, orientation; n = 2, 3),
#   with the Fock parameter put on the orbit's own energy, c = -2 mu H (sabotage: c = +2 mu H):
#   (a) c + |p|^2 = 2 mu k / r: Fock's denominator never vanishes on an orbit (k > 0) and is Moser's time change;
#   (b) the hodograph sphere |L|^2 (|p|^2 + 2 mu H) + 2 N.p = 0 with the conserved N_a = sum_c L_ac A_c ({N, H} = 0), and L ^ p = 0 (n = 3):
#       in Fock's coordinates  |L|^2 z0 = N.z  and  L ^ z = 0 : the image of the momentum curve lies in a fixed 2-plane through the origin of
#       R^(n+1) (normals (|L|^2, -N) and the (n-2) equations L ^ z = 0, independent when L != 0), hence in a great circle of S^n (E < 0), a
#       straight line of the hyperplane z0 = -1 (E = 0) or a plane section through the origin of the hyperboloid (E > 0);
#   (c) intrinsically: the momentum curve is a pregeodesic of g_c, (grad_pdot pdot) ^ pdot = 0 along the Kepler flow;
#   (d) its speed is |pdot|_{g_c} = 1/(mu r): with ds = dt/(mu r) it is a unit-speed geodesic.
#   Sabotage: c = +2 mu H (the wrong sign of E in Fock's map): (a), (b), (c) fail (values printed).
# =====================================================================================================================================
def check6(sab):
    ok = True; info = []
    for n in (2, 3):
        R = PhaseRing(n)
        x, p, p2, xp, G, L, A = kepler_functions(R)
        mu, k, ir = R.sym(R.imu), R.sym(R.ik), R.invr()
        cf = G if sab else -G                                  # c = -2 mu H on the orbit's own energy surface
        D = cf + p2
        den = (D - 2 * mu * k * ir).zero()
        def Lf(a, b): return L[(a, b)] if a < b else (-L[(b, a)] if a > b else R.const(0))
        Nv = [sum((Lf(a, cc) * A[cc] for cc in range(1, n + 1)), R.const(0)) for a in range(1, n + 1)]
        consN = all(pb(v, G).zero() for v in Nv)
        L2 = sum((v * v for v in L.values()), R.const(0))
        sphere = (L2 * (p2 + G) + 2 * dot(Nv, p)).zero()
        plane = L2 * (cf - p2) - 2 * dot(Nv, p)                 # = D (|L|^2 z0 - N.z)
        orbit_plane = all((L[(a, b)] * p[cc - 1] - L[(a, cc)] * p[b - 1] + L[(b, cc)] * p[a - 1]).zero()
                          for a, b, cc in combinations(range(1, n + 1), 3))
        # Kepler flow: delta f = {f, 2 mu H} = 2 mu df/dt (a constant rescaling of time; pregeodesy is invariant under it)
        dp_ = [pb(p[i], G) for i in range(n)]
        ddp = [pb(v, G) for v in dp_]
        sp2 = dot(dp_, dp_)
        W = [D * ddp[i] + 2 * sp2 * p[i] for i in range(n)]      # D (nabla_pdot pdot) up to a multiple of pdot (Fock's Christoffel symbols)
        geo = [W[i] * dp_[j] - W[j] * dp_[i] for i, j in combinations(range(n), 2)]
        geo_ok = all(z.zero() for z in geo)
        speed = (sp2 * R.sym(R.ir) * R.sym(R.ir) - D * D).zero()  # |delta p|^2 r^2 = D^2  <=>  |pdot|_{g_c} = 1/(mu r)
        good = den and consN and sphere and plane.zero() and orbit_plane and geo_ok and speed
        ok &= good
        s = R.sample()
        info.append(f'n = {n}: c + |p|^2 = 2 mu k/r: {den}; N conserved: {consN}; hodograph sphere: {sphere}; Fock image in the plane |L|^2 z0 = N.z: '
                    f'{plane.zero()} (residual D(|L|^2 z0 - N.z) at a sample point: {plane.at(s)}); L ^ p = 0: {orbit_plane}; pregeodesic of g_c: '
                    f'{geo_ok} (residual at a sample point: {geo[0].at(s)}); speed 1/(mu r): {speed}')
    report('bd·kep·6', ok, 'every Kepler hodograph (any orbit, n = 2, 3) is carried by Fock\'s map with c = -2 mu E into a 2-plane through the origin, '
           'and is a pregeodesic of g_c with unit speed for ds = dt/(mu r): a great circle of S^n (E < 0), a line (E = 0), a geodesic of H^n (E > 0). '
           + '; '.join(info))
    return ok

# =====================================================================================================================================
CHECKS = [('bd·kep·1', check1), ('bd·kep·2', check2), ('bd·kep·3', check3), ('bd·kep·4', check4), ('bd·kep·5', check5), ('bd·kep·6', check6)]

def main():
    if SABOTAGE:
        missed = 0
        for cid, fn in CHECKS:
            okk = fn(True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            missed += okk
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        return missed == 0
    for cid, fn in CHECKS: fn(False)
    good = all(o for _, o in RESULTS)
    nfail = sum(1 for _, o in RESULTS if not o)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if good else 'SOME BRIDGE CHECK FAILED'))
    return good

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
