#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mat_null_part.py: the null part of a degenerate cell Cl(p,q,r), read as a Rees monoid and as a base change.

  python3 selfcheck/bridges/mat_null_part.py      one line per check, ids bd·mat·9 .. bd·mat·11; exit 1 on any FAIL

Standard library only, exact integers (ranks modulo the prime 1000003), deterministic, under 1 s; runs from any folder, reads and writes no file.
  bd·mat·9   the label monoid with zero of core·B8 is Z_2^{p+q} x R_r, R_r = N^r / (an entry >= 2) the Rees quotient of the free commutative monoid
             N^r, via a -> (a_D, a_N); every eps in {+1,-1,0}^n with n <= 4, every pair of labels. Its group completion Z_2^{p+q} x Z^r is the
             grading group of core·B9.
  bd·mat·10  Cl(p,q,r) is graded Azumaya over its super-centre Lambda(R^r): the R-span of the 4^n operators x -> (-1)^{|b||x|} e_a x e_b has
             dimension 4^{p+q} 2^r = dim_R End_Lambda(Cl(p,q,r)) for every signature with n <= 4 (for r = 0 this is core·B10).
  bd·mat·11  the Loewy layers of Cl(p,q,r): dim J^k / J^{k+1} = C(r,k) 2^{p+q}, k = 0..r, from the product table, every signature with n <= 5;
             the semisimple quotient is Cl(p,q) with its own triple (V_D, Q, pi).
"""
import itertools, sys

ROWS = []
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def row(i, text, ok):
    ROWS.append((i, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def rank_mod(vecs, P=1000003):
    vecs = [[x % P for x in v] for v in vecs if any(v)]; rank = 0
    if not vecs: return 0
    ncol = len(vecs[0])
    for c in range(ncol):
        piv = next((i for i in range(rank, len(vecs)) if vecs[i][c]), None)
        if piv is None: continue
        vecs[rank], vecs[piv] = vecs[piv], vecs[rank]; inv = pow(vecs[rank][c], P - 2, P)
        vecs[rank] = [x * inv % P for x in vecs[rank]]
        for i in range(len(vecs)):
            if i != rank and vecs[i][c]:
                f = vecs[i][c]; vecs[i] = [(x - f * y) % P for x, y in zip(vecs[i], vecs[rank])]
        rank += 1
    return rank

# ---------------------------------------------------------------- bd·mat·9: the monoid with zero is Z_2^{p+q} x Rees(N^r)
def check9():
    ok = True; count = 0
    for n in range(1, 5):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e); N = sum(1 << i for i in range(n) if e[i] == 0); D = ((1 << n) - 1) ^ N
            count += 1
            for a in range(1 << n):
                for b in range(1 << n):
                    prod_zero = (sgn(a, b, e) == 0)
                    # Rees quotient: the null exponent vectors add in N^r and the sum has an entry >= 2 iff a_N and b_N share a bit
                    rees_zero = bool(a & b & N)
                    if prod_zero != rees_zero: ok = False
                    if not prod_zero and ((a ^ b) & D) != ((a & D) ^ (b & D)): ok = False       # the Z_2^{p+q} factor is XOR on the non-null bits
                    if not prod_zero and ((a ^ b) & N) != ((a & N) | (b & N)): ok = False       # the Rees factor is disjoint union = addition in N^r
    row('bd·mat·9', f'the label monoid with zero of core·B8 (a.b = a xor b if no null bit is shared, else 0) is the product Z_2^{{p+q}} x R_r with R_r = N^r / (entry >= 2) '
        f'the Rees quotient of the free commutative monoid, via a ↦ (a_D, a_N): all {count} choices of eps with n <= 4, every pair of labels. Its group completion is Z_2^{{p+q}} x Z^r '
        '(core·B9); the sign s is a 2-cocycle on it (core·B8) and the algebra is R^s[M] = Cl(p,q) (x)^ Lambda(R^r) (core·B7): the "monoid, not a group" of the Atlas is the Rees quotient, '
        'and Lambda(R^r) is the contracted monoid algebra of R_r with the Koszul sign', ok)

# ---------------------------------------------------------------- bd·mat·10: graded Azumaya over the super-centre
def check10():
    ok = True; table = {}
    for n in range(1, 5):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e)
            if e != sorted(e, key=lambda x: (x == 0, -x)): continue
            p, q, r = e.count(1), e.count(-1), e.count(0); Nn = 1 << n
            vecs = []
            for a in range(Nn):
                for b in range(Nn):
                    M = [0] * (Nn * Nn)
                    for x in range(Nn):                                        # x ↦ (-1)^{|b||x|} e_a e_x e_b
                        s1 = sgn(a, x, e)
                        if s1 == 0: continue
                        s2 = sgn(a ^ x, b, e)
                        if s2 == 0: continue
                        M[(a ^ x ^ b) * Nn + x] = s1 * s2 * (-1) ** (pc(b) * pc(x))
                    vecs.append(M)
            rk = rank_mod(vecs)
            table[(p, q, r)] = rk
            if rk != 4 ** (p + q) * 2 ** r: ok = False
    row('bd·mat·10', 'the R-span of the 4^n operators x ↦ (-1)^{|b||x|} e_a x e_b on Cl(p,q,r) has dimension exactly 4^{p+q} 2^r for every signature with n <= 4 '
        f'(for example Cl(1,1,1): {table[(1, 1, 1)]} = 16 x 2; Cl(0,0,2): {table[(0, 0, 2)]} = 4; Cl(2,0): {table[(2, 0, 0)]} = 16). This is dim_R M_{{2^{{p+q}}}}(Lambda(R^r)) = dim_R End_Lambda(A): '
        'the map A (x)^_Lambda A^sop -> End_Lambda(A) is onto, hence an isomorphism (equal dimensions), so Cl(p,q,r) = Cl(p,q) (x)_R Lambda(R^r) is graded Azumaya over the '
        'supercommutative ring Lambda(R^r) = its super-centre (T2 (4)). For r = 0 this is core·B10; for r >= 1 the number r is a base ring, not a group coordinate (QA1, QC1)', ok)

# ---------------------------------------------------------------- bd·mat·11: Loewy layers from the product table
def check11():
    ok = True
    from math import comb
    for n in range(1, 6):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e)
            if e != sorted(e, key=lambda x: (x == 0, -x)): continue
            p, q, r = e.count(1), e.count(-1), e.count(0); Nn = 1 << n
            N = sum(1 << i for i in range(n) if e[i] == 0)
            # J^k spanned by products of k radical labels: compute by closure on label sets
            J = {a for a in range(Nn) if a & N}
            layer = {0: Nn}
            Jk = set(J); k = 1
            while Jk:
                layer[k] = len(Jk)
                Jk = {a ^ b for a in Jk for b in J if sgn(a, b, e) != 0}
                k += 1
            dims = [layer[j] - layer.get(j + 1, 0) for j in range(k)]
            want = [comb(r, j) * 2 ** (p + q) for j in range(r + 1)]
            if dims != want: ok = False
    row('bd·mat·11', 'the powers of the radical J (spanned by the labels with a null bit) have layers dim J^k/J^{k+1} = C(r,k) 2^{p+q}, k = 0..r, recomputed by closure on the label '
        'sets for every signature with n <= 5: the Loewy structure of Cl(p,q,r) is that of Lambda(R^r) tensored with the semisimple Cl(p,q) (T2 (3)); the Loewy length is r + 1 '
        'and the quotient A/J = Cl(p,q) carries the non-degenerate triple (V_D, Q, pi) whose Brown invariant is the clock (bd·mat·3)', ok)

if __name__ == '__main__':
    for f in (check9, check10, check11): f()
    verdict()
