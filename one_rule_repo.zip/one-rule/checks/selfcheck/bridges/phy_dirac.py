#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""phy_dirac.py: the Dirac step (step 4), the states of the spin step (step 5, T15) and the coupling step (step 6), joined.

  bd·phy·9   the dagger involution of T15 on Cl(1,3) (e_i -> e_i^{-1}) equals Hestenes' psi^dagger = gamma0 psi~ gamma0 on all 16 blades, so the
             state functional <x^dagger x>_0 of T15 is the gamma0 component of the Dirac current: <psi^dagger psi>_0 = (psi gamma0 psi~).gamma0
             = Psi^dagger Psi, positive for 300 random nonzero even psi, while the reversion scalar <psi psi~>_0 = rho cos(beta) = Psi-bar Psi
             takes both signs.  The involution and the time direction gamma0 are one datum.
  bd·phy·10  the chirality map C(psi) = I psi J commutes with the right action of J (50 random psi): the two Weyl halves are J-complex
             subspaces of real dimension 4 each (2 complex dimensions).
  bd·phy·11  at n = 5 (signature 1+4, psi even): X = psi gamma0 psi~ has grades 1 and 5 only, with a nonzero grade-5 part for generic psi,
             and <A X>_0 = A . <X>_1 for every vector A (200 random cases): the coupling term A.X sees only the grade-1 part, so the
             projection nabla F = e <X>_1 adds no input.
  bd·phy·12  the Dirac sign (T16 (3)), with explicit real 4x4 matrices of Cl(3,1) ({gamma, gamma} = 2 eta, eta = diag(-1,1,1,1) in the
             matrix convention), 50 random momenta and masses: the real operators gamma.d - m and gamma.d + m (Weinberg's form, no i) are
             singular on E^2 = |p|^2 + m^2 and gamma.d - m is not singular off it, while i gamma.d - m is not singular there and is singular
             on the tachyonic shell E^2 = |p|^2 - m^2 when it exists.

  python3 phy_dirac.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic (seed 7); about a second."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))          # phy_bitrule.py sits next to this script
import numpy as np
from phy_bitrule import Alg, Reporter

def main():
    R = Reporter()
    rng = np.random.default_rng(7)
    A = Alg.pq(1, 3)
    g0 = A.blade(1)
    # bd·phy·9: dagger = gamma0 (reverse) gamma0 on every blade
    same = True
    for m in range(16):
        b = A.blade(m)
        lhs = A.dagger(b)
        rhs = A.mul(A.mul(g0, A.reverse(b)), g0)
        same &= np.abs(lhs - rhs).max() < 1e-12
    pos = True; both = [False, False]
    for _ in range(300):
        psi = A.random_even(rng)
        st = A.scalar(A.mul(A.dagger(psi), psi))
        X = A.mul(A.mul(psi, g0), A.reverse(psi))          # the Dirac current, a vector
        X0 = X[1]                                          # its gamma0 component (gamma0^2 = +1 so X.gamma0 = X0)
        pos &= st > 0 and abs(st - X0) < 1e-9
        rs = A.scalar(A.mul(psi, A.reverse(psi)))
        both[0] |= rs > 0; both[1] |= rs < 0
    R('bd·phy·9', same and pos and all(both),
      'the dagger of T15 is gamma0 psi~ gamma0 on all 16 blades; <psi^dagger psi>_0 = (psi gamma0 psi~).gamma0 > 0 for 300 random even psi '
      '(the Dirac probability density Psi^dagger Psi, which depends on the frame), while <psi psi~>_0 = Psi-bar Psi takes both signs: '
      'the involution and the time direction gamma0 are one datum')

    # bd·phy·10: chirality commutes with right multiplication by J
    I = A.blade(15); J = A.mul(A.blade(4), A.blade(2))      # gamma2 gamma1
    okc = True
    for _ in range(50):
        psi = A.random_even(rng)
        C1 = A.mul(A.mul(I, A.mul(psi, J)), J)             # C(psi J)
        C2 = A.mul(A.mul(I, psi), J); C2 = A.mul(C2, J)     # C(psi) J
        okc &= np.abs(C1 - C2).max() < 1e-9
    # eigenspaces
    Cmat = np.zeros((8, 8)); even = [m for m in range(16) if A.grade[m] % 2 == 0]
    for k, m in enumerate(even):
        v = A.mul(A.mul(I, A.blade(m)), J)
        Cmat[:, k] = v[even]
    w = np.linalg.eigvals(Cmat)
    dims = (int(np.sum(np.abs(w - 1) < 1e-9)), int(np.sum(np.abs(w + 1) < 1e-9)))
    R('bd·phy·10', okc and dims == (4, 4),
      'C(psi) = I psi J commutes with the right action of J (50 random psi); the eigenspaces of C on the even part have real dimensions %s, 2 + 2 complex: the Weyl halves' % (dims,))

    # bd·phy·11: n = 5, the grade-5 part of the current and the coupling term
    B = Alg([1, -1, -1, -1, -1])
    g0b = B.blade(1)
    g5 = 0.0; okA = True
    for _ in range(200):
        psi = B.random_even(rng)
        X = B.mul(B.mul(psi, g0b), B.reverse(psi))
        X1 = B.grade_part(X, 1); X5 = B.grade_part(X, 5)
        g5 = max(g5, np.abs(X5).max())
        other = X - X1 - X5
        okA &= np.abs(other).max() < 1e-9
        Av = B.random_vec(rng)
        lhs = B.scalar(B.mul(Av, X)); rhs = B.scalar(B.mul(Av, X1))
        okA &= abs(lhs - rhs) < 1e-9
    R('bd·phy·11', okA and g5 > 1e-3,
      'n = 5: X = psi gamma0 psi~ has grades 1 and 5 only, grade-5 part nonzero (max |X5| = %.3f), and <A X>_0 = A.<X>_1 for every vector A: '
      'the coupling term sees only the vector current, and the projection to <X>_1 adds no input' % g5)

    # bd·phy·12: Dirac sign with explicit real matrices of Cl(3,1) in the matrix convention eta = diag(-1,1,1,1): gamma0^2 = -1, gamma_k^2 = +1
    s1 = np.array([[0, 1], [1, 0]], float); s3 = np.array([[1, 0], [0, -1]], float); eps = np.array([[0, 1], [-1, 0]], float); I2 = np.eye(2)
    # real Majorana-type set: three anticommuting symmetric matrices squaring to +1 and one antisymmetric squaring to -1
    gk = [np.kron(s1, I2), np.kron(s3, I2), np.kron(eps, eps)]      # squares +1
    g0m = np.kron(eps, s1)                                           # square -1, anticommutes with the three above
    gam = [g0m] + gk
    eta = np.diag([-1.0, 1, 1, 1])
    rel = all(np.abs(gam[a] @ gam[b] + gam[b] @ gam[a] - 2 * eta[a, b] * np.eye(4)).max() < 1e-12 for a in range(4) for b in range(4))
    ok12 = rel
    for _ in range(50):
        p = rng.normal(size=3); m = abs(rng.normal()) + 0.2
        Eph = np.sqrt(p @ p + m * m); Et = np.sqrt(abs(p @ p - m * m)) if p @ p > m * m else None
        # plane wave exp(i(p.x - E t)): d_t -> -iE, d_k -> i p_k. The real operator gamma^mu d_mu - m acts as gamma0(-iE) + i gamma.p - m
        def detreal(E, sgn):
            Op = -1j * E * gam[0] + 1j * sum(p[k] * gam[k + 1] for k in range(3)) + sgn * m * np.eye(4)
            return abs(np.linalg.det(Op))
        def detI(E):
            Op = 1j * (-1j * E * gam[0] + 1j * sum(p[k] * gam[k + 1] for k in range(3))) - m * np.eye(4)
            return abs(np.linalg.det(Op))
        ok12 &= detreal(Eph, -1) < 1e-8 and detreal(Eph, +1) < 1e-8 and detreal(Eph * 1.3, -1) > 1e-6
        ok12 &= detI(Eph) > 1e-6
        if Et is not None:
            ok12 &= detI(Et) < 1e-8
    R('bd·phy·12', ok12,
      'real gammas of Cl(3,1), eta = diag(-1,1,1,1): the determinants of gamma.d - m and gamma.d + m (no i; Weinberg form) vanish on E^2 = |p|^2 + m^2 and that of gamma.d - m not off it; '
      'the determinant of i gamma.d - m does not vanish there and vanishes on the tachyonic shell E^2 = |p|^2 - m^2 when it exists (50 random p, m)')
    R.finish()

if __name__ == '__main__':
    main()
