#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mat_En_in_Cl1n.py: the E_n lattices inside the frame lattice I_{1,n} of the Lorentzian cell Cl(1,n): van der Blij's congruence, the
reason for T9 (a), and the type of the quadric of E_n/2E_n.

  python3 selfcheck/bridges/mat_En_in_Cl1n.py       one line per check, ids bd·mat·17 .. bd·mat·19; exit 1 on any FAIL

Standard library only, exact integers and rationals, deterministic, under 1 s; runs from any folder, reads and writes no file.
  bd·mat·17  k = (3; -1^n) is a characteristic vector of the odd unimodular lattice I_{1,n} (k.x = x.x mod 2), k.k = 9 - n = 1 - n mod 8, the
             signature of I_{1,n} (van der Blij's congruence) and the clock of Cl(1,n); |det Cartan(E_n)| = |k.k|. n = 3..13.
  bd·mat·18  E_n = k^perp reduced mod 2 into the label space F_2^{1+n} of Cl(1,n) is a bijection of E_n/2E_n onto the 2^n even labels (pi(a); a),
             the labels of Cl^0(1,n) = Cl(n,0), and x.x/2 mod 2 is the binary Q of Cl(1,n) on that label, equal to Q of Cl(n,0) on a. n = 3..10.
  bd·mat·19  on the even labels of Cl(1,n) the Z_4 form of I_{1,n} takes the values 0 and 2 only and equals 2 Q_Cl(n,0); the sum over the even
             labels of (-1)^Q is Re((1+i)(1-i)^n), and for even n its sign is the Arf type of E_n/2E_n (+ at n = 8, 10; - at n = 4, 6). n = 3..10.
"""
import sys
from fractions import Fraction as F
from math import comb

ROWS = []
def row(i, text, ok):
    ROWS.append((i, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Qf(a, e): return 1 if sgn(a, a, e) == -1 else 0

def gram_I1n(n): return [[(1 if i == 0 else -1) if i == j else 0 for j in range(n + 1)] for i in range(n + 1)]
def dot(x, y, G): return sum(x[i] * G[i][j] * y[j] for i in range(len(x)) for j in range(len(y)))
def En_basis(n):
    """simple roots of E_n inside I_{1,n}: alpha_0 = (1; -1,-1,-1,0..), alpha_i = e_i - e_{i+1} (i = 1..n-1); all orthogonal to k"""
    B = []
    v = [0] * (n + 1); v[0] = 1; v[1] = v[2] = v[3] = -1; B.append(v)
    for i in range(1, n):
        v = [0] * (n + 1); v[i] = 1; v[i + 1] = -1; B.append(v)
    return B
def det_frac(M):
    n = len(M); A = [[F(x) for x in r] for r in M]; d = F(1)
    for c in range(n):
        piv = next((i for i in range(c, n) if A[i][c] != 0), None)
        if piv is None: return F(0)
        if piv != c: A[c], A[piv] = A[piv], A[c]; d = -d
        d *= A[c][c]
        for i in range(c + 1, n):
            if A[i][c] != 0:
                f = A[i][c] / A[c][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return d

# ---------------------------------------------------------------- bd·mat·17: van der Blij and the clock of Cl(1,n)
def check17():
    ok = True; out = []
    for n in range(3, 14):
        G = gram_I1n(n); k = [3] + [-1] * n
        # characteristic: k.x = x.x mod 2 on the basis vectors (then for all x, by bilinearity mod 2 of x.x on a unimodular lattice)
        for i in range(n + 1):
            e = [0] * (n + 1); e[i] = 1
            if (dot(k, e, G) - dot(e, e, G)) % 2: ok = False
        kk = dot(k, k, G); sigma = 1 - n; clock = (1 - n) % 8
        B = En_basis(n); Gp = [[dot(u, v, G) for v in B] for u in B]; d = int(det_frac(Gp))
        if kk != 9 - n or (kk - sigma) % 8 != 0 or abs(d) != abs(9 - n): ok = False
        if (kk - clock) % 8 != 0: ok = False
        out.append(f'n={n}: k.k={kk}, sigma={sigma}, clock Cl(1,{n})={clock}, |det E_{n}|={abs(d)}')
    row('bd·mat·17', 'k = (3; -1^n) is characteristic in I_{1,n} (k.x = x.x mod 2) and k.k = 9 - n = 1 - n = sigma(I_{1,n}) mod 8 (van der Blij), which is the clock of Cl(1,n): '
        'det(Cartan E_n) = k.k is congruent mod 8 to the clock of the cell Cl(1,n) whose label space carries E_n; the E_n series and the clock share the number 8 through '
        'van der Blij\'s congruence for the characteristic vector whose complement E_n is. n = 3..13: ' + '; '.join(out[:2] + ['...'] + out[5:7]), ok)

# ---------------------------------------------------------------- bd·mat·18: E_n/2E_n = the even labels of Cl(1,n)
def check18():
    ok = True
    for n in range(3, 11):
        G = gram_I1n(n); B = En_basis(n); e_big = [1] + [-1] * n; e_small = [1] * n
        seen = {}
        for c in range(1 << n):
            x = [0] * (n + 1)
            for j in range(n):
                if c >> j & 1:
                    for t in range(n + 1): x[t] += B[j][t]
            lab = sum((x[t] & 1) << t for t in range(n + 1))                  # bit 0 = time coordinate, bits 1..n = space
            if pc(lab) % 2: ok = False                                       # the image is an even label
            xx = dot(x, x, G)
            if xx % 2: ok = False                                            # E_n is even
            q = (xx // 2) % 2
            if q != Qf(lab, e_big): ok = False                               # x.x/2 mod 2 = Q of Cl(1,n) on the label
            a = lab >> 1
            if lab != (a << 1 | (pc(a) % 2)): ok = False                     # the label is (pi(a); a)
            if Qf(lab, e_big) != Qf(a, e_small): ok = False                  # = Q of Cl(n,0) on a (the even subalgebra Cl^0(1,n) = Cl(n,0))
            seen[lab] = c
        if len(seen) != 1 << n: ok = False
    row('bd·mat·18', 'E_n = k^perp reduced mod 2 into the label space F_2^{1+n} of Cl(1,n) is a bijection of E_n/2E_n onto the 2^n even labels (pi(a); a), the labels of the even '
        'subalgebra Cl^0(1,n) = Cl(n,0); x.x/2 mod 2 equals the binary form Q of Cl(1,n) on that label, which equals Q of Cl(n,0) on a (f_i = e_i e_0). So T9 (a), '
        '"E_n/2E_n carries the label form of Cl(n,0)", is the statement that E_n/2E_n is the even part of the label space of the Lorentzian cell Cl(1,n) that contains the '
        'ambient lattice I_{1,n}; n = 3..10', ok)

# ---------------------------------------------------------------- bd·mat·19: the Z_4 form on the even labels and the Arf type of E_n/2E_n
def check19():
    ok = True; out = []
    for n in range(3, 11):
        e_big = [1] + [-1] * n; e_small = [1] * n
        S = 0; vals = set()
        for a in range(1 << n):
            lab = a << 1 | (pc(a) % 2)
            w = (pc(lab & 1) - pc(lab >> 1)) % 4                            # x.x mod 4 of I_{1,n} on the label: |a & P| - |a & Q|
            vals.add(w)
            if w != 2 * Qf(a, e_small): ok = False
            S += (-1) ** Qf(a, e_small)
        if vals - {0, 2}: ok = False
        # Re((1+i)(1-i)^n) exactly: (1+i)(1-i) = 2, so (1+i)(1-i)^n = 2 (1-i)^(n-1)
        re, im = 2, 0
        for _ in range(n - 1): re, im = re + im, im - re                     # multiply by (1 - i): (re + i im)(1 - i) = (re + im) + i(im - re)
        if S != re: ok = False
        if n % 2 == 0:
            zeros = sum(1 for a in range(1 << n) if Qf(a, e_small) == 0)
            eps = +1 if zeros == 2 ** (n - 1) + 2 ** (n // 2 - 1) else (-1 if zeros == 2 ** (n - 1) - 2 ** (n // 2 - 1) else 0)
            if eps == 0 or (eps > 0) != (S > 0): ok = False
            out.append(f'n={n}: sum={S}, Arf type {"+" if eps > 0 else "-"}, singular points {zeros - 1}')
    row('bd·mat·19', 'the Z_4 form of I_{1,n} on the even labels of Cl(1,n) takes the values 0 and 2 only and equals 2 Q_Cl(n,0) (E_n is even because k is characteristic); '
        'the Gauss sum over the even labels, sum (-1)^Q = Re((1+i)(1-i)^n) = 2 Re (1-i)^(n-1), has the sign of the Arf type of E_n/2E_n for even n: ' + '; '.join(out) +
        ' (hyperbolic at n = 8 with 135 points, elliptic at n = 4, 6 with 5 and 27 points: T11 (3)), so the type of the quadric of E_n is read off the clock of Cl(1,n); n = 3..10', ok)

if __name__ == '__main__':
    for f in (check17, check18, check19): f()
    verdict()
