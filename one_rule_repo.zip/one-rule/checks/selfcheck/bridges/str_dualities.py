#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""str_dualities.py: the doubling as generalized geometry, T-duality, B-shifts, triality, the two ideals of Cl(4,3), and the worldsheet
algebra Witt (x) A_eps with its central extensions.  Standard library only (exact integers and fractions).

  bd·str·10  T-duality on polyforms: on the labels of Lambda(R^n) (n <= 5) the bit-rule operators c_i^+ (eps_i = 0) and c_i = L(eps_i = +1) - c_i^+
             satisfy the CAR of T + T*; conjugation by v_i = c_i^+ - c_i (= L_{e_i} with eps_i = -1) swaps dx^i wedge and iota_i and fixes the
             other 2n - 2 generators (the O(n,n) T-duality reflection), and v_i is odd: it maps even forms to odd forms (IIA <-> IIB).
  bd·str·11  B-shifts are null: each c_i^+ c_j^+ squares to 0, N = sum B_ij c_i^+ c_j^+ (n = 4, B with entries in {-1,0,1}) has N^3 = 0,
             exp(N) = 1 + N + N^2/2 is even, fixes every dx^k wedge and sends iota_k to iota_k - sum_j B_kj dx^j wedge (the B-transform of
             generalized geometry).
  bd·str·12  triality as Fourier duality on F_2^4: H/2 (H the Sylvester-Hadamard matrix) maps the D4 roots to themselves, the vector weights
             +-e_i onto the half-spin weights of the even labels of Cl(4,0) (core·B10b) and back, and fixes the odd half-spin set: an outer
             automorphism of D4 exchanging 8v and 8s.
  bd·str·13  the two ideals of Cl(4,3) (core·B14): the grade involution (all reflections, parity) and the reversion exchange them, Clifford
             conjugation fixes them, and the even part (centre R) embeds in each, so both carry the same Spin module: they differ as pinor
             (parity) classes, and whether a conjugation exchanges them depends on the anti-involution chosen (an input).
  bd·str·14  Witt (x) A_eps (Schuller lens) with the 2-cocycle (m^3 - m)/12 delta tau(ab), tau in A_eps^*, tau = (26, 7): the Jacobi identity
             holds exactly (modes |m| <= 4); eps = +1 splits into two commuting Virasoro algebras with c_+- = (tau(1) +- tau(h))/2 (the
             closed-string worldsheet); eps = 0 is BMS3 = GCA2 with (c_L, c_M) = (tau(1), tau(h)) and [M, M] = 0 (the tensionless string);
             eps = -1 is Witt (x) C.

  python3 str_dualities.py      one line per check id; exit code 1 on any FAIL
deterministic; about a second."""
import itertools, sys
from fractions import Fraction as F

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

# operators on the 2^n labels as dicts {(row, col): value}; small dense lists are enough here
def L(i, eps):
    n = len(eps); N = 1 << n; M = [[0] * N for _ in range(N)]
    for a in range(N):
        s = sgn(1 << i, a, eps)
        if s: M[a ^ (1 << i)][a] += s
    return M
def mm(A, B):
    N = len(A); return [[sum(A[i][k] * B[k][j] for k in range(N) if A[i][k]) for j in range(N)] for i in range(N)]
def add(A, B, s=1): return [[x + s * y for x, y in zip(r1, r2)] for r1, r2 in zip(A, B)]
def sc(A, c): return [[c * x for x in r] for r in A]
def I(N): return [[F(int(i == j)) for j in range(N)] for i in range(N)]
def Z(N): return [[0] * N for _ in range(N)]

def check10():
    ok = True
    for n in range(1, 6):
        N = 1 << n
        cp = [L(i, [0] * n) for i in range(n)]                              # creation c_i^+ = dx^i wedge (null generator: T20 (a))
        cm = [add(L(i, [1] * n), cp[i], -1) for i in range(n)]              # contraction c_i = iota_i
        # CAR
        for i in range(n):
            for j in range(n):
                if add(mm(cm[i], cp[j]), mm(cp[j], cm[i])) != (sc(I(N), 1) if i == j else Z(N)): ok = False
                if add(mm(cp[i], cp[j]), mm(cp[j], cp[i])) != Z(N) or add(mm(cm[i], cm[j]), mm(cm[j], cm[i])) != Z(N): ok = False
        for i in range(n):
            v = L(i, [1] * i + [-1] + [1] * (n - i - 1))                      # e_i with eps_i = -1: c^+ - c, square -1
            if add(v, add(cp[i], cm[i], -1), -1) != Z(N): ok = False
            vinv = sc(v, -1)                                                 # v^2 = -1
            if mm(v, vinv) != sc(I(N), 1): ok = False
            # twisted adjoint alpha(v) x v^{-1} = -v x v^{-1} on the generators: reflection in v
            for j in range(n):
                for X, Y in ((cp[j], cm[j]), (cm[j], cp[j])):
                    img = sc(mm(mm(v, X), vinv), -1)
                    want = Y if j == i else X
                    if img != want: ok = False
            # parity: v maps even-degree labels to odd ones
            for a in range(N):
                for b in range(N):
                    if v[b][a] and (pc(a) + pc(b)) % 2 == 0: ok = False
    row('bd·str·10', ok, 'on the 2^n labels of Lambda(R^n), n <= 5: c_i^+ (the bit rule with eps_i = 0) and c_i satisfy the CAR (the Clifford algebra of T + T* with its split pairing, T20); v_i = c_i^+ - c_i is L_{e_i} of the cell with eps_i = -1, and its twisted adjoint action swaps dx^i wedge <-> iota_i and fixes all other generators: the T-duality reflection of O(n,n) along circle i; v_i is odd, so it maps even polyforms to odd ones (IIB <-> IIA, Hohm-Kwak-Zwiebach)')

def check11():
    n = 4; N = 1 << n; ok = True
    cp = [L(i, [0] * n) for i in range(n)]; cm = [add(L(i, [1] * n), cp[i], -1) for i in range(n)]
    Bs = [(0, 1, 1), (0, 2, -1), (1, 3, 1), (2, 3, 1), (0, 3, -1)]
    Nn = Z(N)
    for i, j, b in Bs: Nn = add(Nn, sc(mm(cp[i], cp[j]), b))
    N2 = mm(Nn, Nn); N3 = mm(N2, Nn)
    for i, j, b in Bs:
        sq = mm(mm(cp[i], cp[j]), mm(cp[i], cp[j]))
        if sq != Z(N): ok = False                                            # each B-shift generator is a null bivector
    if N3 != Z(N): ok = False                                               # nilpotent of order <= 3 at n = 4 (N^2 ~ B wedge B)
    E = add(add(sc(I(N), 1), Nn), sc(N2, F(1, 2))); Einv = add(add(sc(I(N), 1), Nn, -1), sc(N2, F(1, 2)))
    if mm(E, Einv) != sc(I(N), 1): ok = False
    for a in range(N):
        for b in range(N):
            if E[b][a] and (pc(a) + pc(b)) % 2: ok = False                   # e^B is even: it keeps IIA and IIB apart
    Bm = [[0] * n for _ in range(n)]
    for i, j, b in Bs: Bm[i][j] += b; Bm[j][i] -= b
    for k in range(n):                                                       # e^B iota_k e^{-B} = iota_k - sum_j B_kj dx^j
        img = mm(mm(E, cm[k]), Einv)
        want = cm[k]
        for j in range(n): want = add(want, sc(cp[j], -Bm[k][j]))
        if img != want: ok = False
        if mm(mm(E, cp[k]), Einv) != cp[k]: ok = False
    row('bd·str·11', ok, 'B-shifts: each c_i^+ c_j^+ is a null bivector (square 0, the "translation" class of T17); N = sum B_ij c_i^+ c_j^+ (n = 4) has N^3 = 0, e^N = 1 + N + N^2/2 is even (it keeps the parity of the polyform), fixes every dx^k wedge and sends iota_k to iota_k - sum_j B_kj dx^j wedge: the B-transform of T + T*; the null part of the doubled cell is the B-field gauge')

def check12():
    H = [[1, 1, 1, 1], [1, -1, 1, -1], [1, 1, -1, -1], [1, -1, -1, 1]]
    M = [[F(x, 2) for x in r] for r in H]
    act = lambda v: tuple(sum(M[i][j] * v[j] for j in range(4)) for i in range(4))
    vec = {tuple(F(s) if k == i else F(0) for k in range(4)) for i in range(4) for s in (1, -1)}
    half = lambda par: {tuple(F((-1) ** ((a >> k) & 1), 2) for k in range(4)) for a in range(16) if pc(a) % 2 == par}
    S, C = half(0), half(1)                                                # even labels of Cl(4,0): half-spin weights (core·B10b, n = 4)
    roots = set()
    for i in range(4):
        for j in range(i + 1, 4):
            for s1 in (1, -1):
                for s2 in (1, -1):
                    v = [F(0)] * 4; v[i] = F(s1); v[j] = F(s2); roots.add(tuple(v))
    ok = {act(v) for v in vec} == S and {act(v) for v in S} == vec and {act(v) for v in C} == C and {act(r) for r in roots} == roots and len(roots) == 24
    row('bd·str·12', ok, 'triality on labels: the Walsh-Hadamard matrix H/2 of F_2^4 maps the 24 roots of D4 to themselves, the 8 vector weights +-e_i onto the 8 half-spin weights (-1)^a/2 of the even labels a of Cl(4,0), those back to the vector weights, and the odd-label weights to themselves: an outer automorphism exchanging 8v and 8s (the light-cone exchange of X^i and S^a); the Fourier duality of the label group F_2^4 is the triality of Spin(8) on weights')

def check13():
    p, q = 4, 3; eps = [1] * p + [-1] * q; n = 7; N = 1 << n; top = N - 1
    rev = lambda a: (-1) ** (pc(a) * (pc(a) - 1) // 2)
    gi = lambda a: (-1) ** pc(a)
    ok = sgn(top, top, eps) == 1 and all(sgn(top, 1 << i, eps) == sgn(1 << i, top, eps) for i in range(n))
    ok = ok and gi(top) == -1 and rev(top) == -1 and gi(top) * rev(top) == 1         # grade involution and reversion flip omega, conjugation fixes it
    # the even part: is omega in it? no (n odd); the centre of Cl^0 is R: one simple even part, so both ideals restrict to the same Spin module.
    ev = [a for a in range(N) if pc(a) % 2 == 0]
    central_even = [a for a in ev if all(sgn(a, b, eps) == sgn(b, a, eps) for b in ev)]
    ok = ok and central_even == [0]
    # explicit: the map x -> x(1 + omega)/2 restricted to Cl^0 is injective (Cl^0 embeds in each ideal), so both ideals are Cl^0-modules of the same kind
    def proj_rank(sign):
        img = {}
        for a in ev:
            img[a] = {a: F(1, 2), a ^ top: F(sign * sgn(a, top, eps), 2)}
        return len(img) == len(ev) and all(len(v) == 2 for v in img.values())
    ok = ok and proj_rank(1) and proj_rank(-1)
    row('bd·str·13', ok, 'Cl(4,3): the central top blade (square +1) splits the algebra into two ideals; the grade involution (e_i -> -e_i: every generator reflected, parity) and the reversion send omega to -omega and exchange the ideals, Clifford conjugation fixes them; the even part (the algebra of Spin(4,3)) has centre R and embeds in each ideal, so the two ideals carry the same Spin representation and differ only in the sign of the odd generators: two pinor (parity) classes; whether a conjugation exchanges them depends on the anti-involution chosen (the reversion does, Clifford conjugation does not), an input')

def check14():
    M = 4; ok = True; modes = range(-M, M + 1)
    def run(eps, tau):
        # basis (m, a) with a in {0: 1, 1: h}; A_eps product by the bit rule with one generator of square eps
        def amul(a, b): return (a ^ b, sgn(a, b, [eps]))
        def br(x, y):
            out = {}
            for (m, a), cx in x.items():
                for (k, b), cy in y.items():
                    c, s = amul(a, b)
                    if s == 0: continue
                    key = (m + k, c)
                    if abs(m + k) <= 3 * M: out[key] = out.get(key, 0) + cx * cy * s * (m - k)
                    if m + k == 0: out['c'] = out.get('c', 0) + cx * cy * s * F(m ** 3 - m, 12) * tau[c]
            return {k_: v for k_, v in out.items() if v != 0}
        def brv(x, y):
            out = {}
            xc = {k_: v for k_, v in x.items() if k_ != 'c'}
            for k_, v in br(xc, y).items(): out[k_] = out.get(k_, 0) + v
            return out
        good = True
        gens = [{(m, a): F(1)} for m in modes for a in (0, 1)]
        for X, Y, W in itertools.product(gens, repeat=3):
            j = {}
            for P_, Q_, R_ in ((X, Y, W), (Y, W, X), (W, X, Y)):
                inner = {k_: v for k_, v in br(Q_, R_).items() if k_ != 'c'}
                for k_, v in brv(P_, inner).items(): j[k_] = j.get(k_, 0) + v
            if any(v != 0 for v in j.values()): good = False
        return good, br
    c1, c2 = F(26), F(7)
    for eps in (1, 0, -1):
        good, br = run(eps, {0: c1, 1: c2})
        if not good: ok = False
        if eps == 1:                                                        # E_+- = L (x) (1 +- h)/2: two commuting Virasoro algebras
            for m in modes:
                for k in modes:
                    Ep = lambda r: {(r, 0): F(1, 2), (r, 1): F(1, 2)}; Em = lambda r: {(r, 0): F(1, 2), (r, 1): F(-1, 2)}
                    if br(Ep(m), Em(k)): ok = False
                    if m + k == 0:
                        cp_ = br(Ep(m), Ep(k)).get('c', 0); cm_ = br(Em(m), Em(k)).get('c', 0)
                        if cp_ != F(m ** 3 - m, 12) * (c1 + c2) / 2 or cm_ != F(m ** 3 - m, 12) * (c1 - c2) / 2: ok = False
        if eps == 0:                                                        # BMS3: [M_m, M_k] = 0, central terms c_L = tau(1), c_M = tau(h)
            for m in modes:
                for k in modes:
                    if br({(m, 1): F(1)}, {(k, 1): F(1)}): ok = False
                    lm = br({(m, 0): F(1)}, {(k, 1): F(1)})
                    want = {}
                    if m != k and abs(m + k) <= 3 * M: want[(m + k, 1)] = F(m - k)
                    if m + k == 0 and m ** 3 - m != 0: want['c'] = F(m ** 3 - m, 12) * c2
                    if lm != want: ok = False
    row('bd·str·14', ok, 'Witt (x) A_eps with A_eps the one-generator cell (eps = +1: Cl(1,0) = R + R; 0: Cl(0,0,1), dual numbers; -1: Cl(0,1) = C) and central term (m^3 - m)/12 delta_{m+n} tau(ab), tau = (tau(1), tau(h)) = (26, 7): Jacobi holds exactly for all modes |m| <= 4; eps = +1: E_+- = L (x) (1 +- h)/2 are two commuting Virasoro algebras with c_+- = (tau(1) +- tau(h))/2 (left and right movers); eps = 0: [M, M] = 0 and [L_m, M_n] = (m - n) M_{m+n} + c_M (m^3 - m)/12 delta with c_M = tau(h): BMS3 = GCA2, the tensionless-string algebra')

if __name__ == '__main__':
    check10(); check11(); check12(); check13(); check14()
    finish()
