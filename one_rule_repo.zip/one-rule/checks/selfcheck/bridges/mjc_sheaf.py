#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mjc_sheaf.py: sieves, presheaves and the Alexandrov topology on the label category B_n; the cell as a presheaf and its gluing; the
closing remark of §1 of arXiv:2403.19689 (v3) (no Grothendieck-style space of open sets of the objects represents the morphisms of a category;
§1, eq. (3)) tested in both readings.

    python3 selfcheck/bridges/mjc_sheaf.py              one line per check, ids bd·mjc·25 .. bd·mjc·29 and bd·mjc·37; exit 1 on any FAIL
    python3 selfcheck/bridges/mjc_sheaf.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only (exact ranks over Q with fractions); deterministic (seeds 51, 52, 53), about 1 s; runs from any folder, reads and writes no file.
  bd·mjc·25  the Alexandrov topology of B_n (opens = down-sets; the presheaves on B_n are the sheaves on it): numbers of opens 2, 3, 6, 20, 168 for
             n = 0..4 (enumerated); the specialization order of the topology is inclusion (B_n is recovered from its topology); the sieves on S are
             the down-sets of the slice B_n/S = B_|S|, total numbers of sieves 2, 5, 14, 49 for n = 0..3 (enumerated against the sum over S).
  bd·mjc·26  the cell as a presheaf: S -> F(S) = span{e_a : a subset of S} with the projections as restrictions is a functor B_n^op -> Vect; on every
             open D the compatible families (the limit over S in D) form a space of dimension |D| = dim span{e_a : a in D} (exact, every open,
             n <= 3); gluing holds on every cover of an open by two opens (n <= 3) and by three opens (n <= 2); control: 200 random sub-presheaves
             S -> span{e_a : a in X, a subset of S} (seed 51) glue as well (generic: every presheaf on a poset is a sheaf on its Alexandrov topology).
             The sabotage changes the input: the restriction from {0} to the empty set is multiplied by 2, which breaks functoriality.
  bd·mjc·27  the algebra structure: the projection Cl(T) -> Cl(S) (blades with a bit outside S go to 0) is an algebra map exactly when eps_j = 0 for
             every j in T \ S (all eps in {+1,-1,0}^n, all S subset T, n <= 3): the cell is a presheaf of algebras only for the null cell
             Cl(0,0,n) (the exterior algebra); F(D) is a subalgebra of the exterior algebra exactly for the principal opens D = down(S) (2^n of
             the opens, n <= 4).  The inclusions Cl(S) -> Cl(T) are algebra maps for every eps (a subset is closed under xor): a remark, not
             tested.  The sabotage changes the input: the null squares are replaced by +1 in the product, the prediction is kept.
  bd·mjc·28  the closing remark of §1, reading (A), the paper's construction: the category C(D) of the open sets of the discrete space Ob D with inclusions is B_|Ob D|,
             the same for every D with the same objects (the discrete category on two objects, the arrow 0 -> 1, the pair groupoid, the
             Kronecker category): the morphisms of D are lost, as the paper says; its ring of opens (subsets, exclusive union, intersection) is
             (F_2^n, xor, and), the labels of the Atlas, the restrictions U -> U cap V are ring maps and glue (the structure sheaf of Spec F_2^n),
             and the exclusive union of disjoint sets is the sum ⊕ of the labels.
  bd·mjc·29  the closing remark of §1, reading (B), Grothendieck's presheaf side: for the arrow 0 -> 1, B_2, the Kronecker category, Z_3, {1, e} and the split idempotent,
             the natural transformations y(a) -> y(b) between representable presheaves number exactly |Hom(a, b)| for every a, b (brute force
             over all families of maps): the Yoneda embedding keeps every morphism; the Alexandrov topology of random posets (seed 52) recovers the
             poset in 200 of 200; what it loses: the presheaf category does not separate {1, e} from its idempotent completion, which has two
             non-isomorphic objects (computed: e is a retract of 1 and not isomorphic to it).
  bd·mjc·37  the closing remark of §1 made precise: the presheaf U -> R^Mor(D|U) (the arrows with both ends in U; restriction = dropping the arrows that leave U) is a
             sheaf on the Alexandrov space of the reachability preorder of D (opens = down-sets) and is not a sheaf on the discrete space of objects
             as soon as D has an arrow between distinct objects (smallest: the arrow 0 -> 1 and the cover {0}, {1}); computed on all covers by two
             opens for the arrow, B_2, the Kronecker category, the crown, the pair groupoid, a loop with an edge, and 100 random acyclic
             digraphs (seed 53).
"""
import sys, random, itertools
from fractions import Fraction

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if not SABOTAGE: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    else: print('  sabotaged input, what the check sees: ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def sub(a, b): return (a & b) == a                                     # a subset of b
def rank(rows, ncols):
    M = [[Fraction(x) for x in r] for r in rows]; rk = 0; col = 0
    while rk < len(M) and col < ncols:
        piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if piv is None: col += 1; continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col] / M[rk][col]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1; col += 1
    return rk
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

def downsets(n, up=False):
    """all down-sets (or up-sets) of B_n as bitmasks over the 2^n labels"""
    N = 1 << n
    near = [sum(1 << b for b in range(N) if (sub(b, a) if not up else sub(a, b))) for a in range(N)]
    out = []
    for X in range(1 << N):
        Y = X; good = True
        while Y:
            a = (Y & -Y).bit_length() - 1; Y &= Y - 1
            if near[a] & ~X: good = False; break
        if good: out.append(X)
    return out

# ================================================================== bd·mjc·25  Alexandrov topology, specialization order, sieves
def check25(sab=False):
    counts = {}; spec_ok = True; sieves = {}
    for n in range(0, 5):
        D = downsets(n, up=sab)                                        # sabotage: up-sets taken as the opens of the presheaf convention
        counts[n] = len(D)
        if n <= 3:
            N = 1 << n
            # specialization: x <= y iff every open containing y contains x (down-set topology); must be inclusion
            spec = {(x, y) for x in range(N) for y in range(N) if all((X >> x & 1) for X in D if X >> y & 1)}
            if spec != {(x, y) for x in range(N) for y in range(N) if sub(x, y)}: spec_ok = False
            # sieves on S: sets of arrows into S closed under precomposition = down-sets of the slice (the labels below S)
            tot = 0
            for S in range(N):
                below = [a for a in range(N) if sub(a, S)]
                tot += sum(1 for X in range(1 << len(below)) if all(not (X >> i & 1) or all((X >> j & 1) for j, b in enumerate(below) if sub(b, a)) for i, a in enumerate(below)))
            sieves[n] = tot
    expect_sieves = {n: sum([2, 3, 6, 20][pc(S)] for S in range(1 << n)) for n in range(0, 4)}
    ok = counts == {0: 2, 1: 3, 2: 6, 3: 20, 4: 168} and spec_ok and sieves == expect_sieves
    return report('bd·mjc·25', ok, f'Alexandrov topology of B_n (opens = down-sets): numbers of opens {counts}; specialization order = inclusion (n <= 3): {spec_ok}; sieves on S = down-sets of B_|S|, total sieves {sieves} = sum over S of the numbers of opens of B_|S|')

# ================================================================== bd·mjc·26  the cell as a presheaf; limits over opens; gluing
def limit_dim(D, n, X=None, twist=False):
    """dimension of the space of compatible families (x_S)_{S in D}, x_S in span{e_a : a subset of S, a in X}, x_S = proj_S(x_T) for S subset T in D
    (twist: the restriction from {0} to the empty set multiplied by 2, not a functor)"""
    N = 1 << n; X = (1 << N) - 1 if X is None else X
    elems = [S for S in range(N) if D >> S & 1]
    var = {}
    for S in elems:
        for a in range(N):
            if sub(a, S) and X >> a & 1: var[(S, a)] = len(var)
    rows = []
    for S in elems:
        for T in elems:
            if S != T and sub(S, T):
                for a in range(N):
                    if (S, a) in var:                                  # coefficient of e_a in x_S equals that in x_T (a subset of S subset T)
                        r = [0] * len(var); r[var[(S, a)]] += 1; r[var[(T, a)]] -= 2 if twist and (S, T) == (0, 1) else 1; rows.append(r)
    return len(var) - (rank(rows, len(var)) if rows and var else 0)
def check26(sab=False):
    ok = True; glue2 = glue3 = 0; tested2 = tested3 = 0; dims_ok = True
    for n in range(0, 4):
        Ds = downsets(n); N = 1 << n
        LD = {}
        for D in Ds:
            d = limit_dim(D, n, twist=sab)                               # sabotage: a restriction map multiplied by 2 (not a presheaf)
            LD[D] = d
            if d != pc(D): dims_ok = False
        # gluing for binary covers: dim F(D1 u D2) = dim F(D1) + dim F(D2) - dim F(D1 n D2) and F(D1 u D2) -> F(D1) + F(D2) injective
        for D1 in Ds:
            for D2 in Ds:
                U = D1 | D2; I = D1 & D2
                tested2 += 1; glue2 += (LD[U] == LD[D1] + LD[D2] - LD[I])
        if n <= 2:
            for D1, D2, D3 in itertools.product(Ds, repeat=3):
                U = D1 | D2 | D3
                inc_exc = LD[D1] + LD[D2] + LD[D3] - LD[D1 & D2] - LD[D1 & D3] - LD[D2 & D3] + LD[D1 & D2 & D3]
                tested3 += 1; glue3 += (LD[U] == inc_exc)
    # control: random sub-presheaves of the cell
    rng = random.Random(51); ctrl = 0; n = 3; Ds = downsets(n)
    for _ in range(200):
        X = rng.randrange(1 << 8)
        LDX = {D: limit_dim(D, n, X) for D in Ds}
        ctrl += all(LDX[D] == pc(D & X) for D in Ds) and all(LDX[D1 | D2] == LDX[D1] + LDX[D2] - LDX[D1 & D2] for D1 in Ds for D2 in Ds)
    ok = dims_ok and glue2 == tested2 and glue3 == tested3 and ctrl == 200
    return report('bd·mjc·26', ok, f'the cell presheaf S -> span{{e_a : a subset of S}} (restriction = projection): the compatible families over every open D have dimension |D| (every open, n <= 3): {dims_ok}; gluing for covers by two opens {glue2} of {tested2} (n <= 3), by three opens {glue3} of {tested3} (n <= 2); control: 200 random sub-presheaves (seed 51) glue and have dimension |D cap X| in {ctrl} of 200 (generic)')

# ================================================================== bd·mjc·27  presheaf of algebras only for the null cell
def check27(sab=False):
    ok = True; agree = total = 0
    for n in range(1, 4):
        N = 1 << n
        for eps in itertools.product((1, -1, 0), repeat=n):
            for S in range(N):
                for T in range(N):
                    if not sub(S, T): continue
                    # projection pi(e_a) = e_a if a subset of S else 0; algebra map iff pi(e_a e_b) = pi(e_a) pi(e_b) for all a, b subset of T
                    hom = True
                    for a in range(N):
                        if not sub(a, T): continue
                        for b in range(N):
                            if not sub(b, T): continue
                            s = sgn(a, b, eps if not sab else tuple(x if x else 1 for x in eps))   # sabotage: the null squares replaced by +1 in the product
                            lhs = s if sub(a ^ b, S) else 0
                            rhs = s if (sub(a, S) and sub(b, S)) else 0
                            if lhs != rhs: hom = False; break
                        if not hom: break
                    pred = all(eps[j] == 0 for j in range(n) if (T & ~S) >> j & 1)
                    total += 1; agree += (hom == pred)
    # F(D) closed under the exterior product exactly for principal opens
    sub_ok = True; counts = {}
    for n in range(0, 5):
        N = 1 << n; Ds = downsets(n); closed = 0
        for D in Ds:
            cl = D != 0 and all(not (D >> a & 1) or not (D >> b & 1) or (a & b) or (D >> (a | b) & 1) for a in range(N) for b in range(N))
            principal = any(D == sum(1 << x for x in range(N) if sub(x, S)) for S in range(N))
            if cl != principal: sub_ok = False
            closed += cl
        counts[n] = closed
    ok = ok and agree == total and sub_ok and all(counts[n] == 1 << n for n in counts)
    return report('bd·mjc·27', ok, f'the projection Cl(T) -> Cl(S) is an algebra map exactly when eps_j = 0 for every j in T \\ S: {agree} of {total} cases (all eps, all S subset T, n = 1..3); opens D with F(D) a subalgebra of the exterior algebra: {counts} = 2^n, exactly the principal opens down(S)')

# ================================================================== bd·mjc·28  reading (A): the paper's C(D) is B_n; its ring of opens is the labels
def check28(sab=False):
    Ds = {'discrete on 2 objects': (2, []), 'arrow 0 -> 1': (2, [(0, 1)]), 'pair groupoid': (2, [(0, 1), (1, 0)]), 'Kronecker': (2, [(0, 1), (0, 1)])}
    Cs = {}
    for name, (m, arrows) in Ds.items():
        objs = list(range(m))
        if sab and arrows: objs = objs + [('arrow', i) for i in range(len(arrows))]   # sabotage: the arrows are counted as points of the space
        opens = list(range(1 << len(objs)))
        incl = sorted((U, V) for U in opens for V in opens if sub(U, V))
        Cs[name] = (len(opens), len(incl))
    same = len(set(Cs.values())) == 1 and list(Cs.values())[0] == (4, 9)
    # the ring of opens of the discrete n-point space: (subsets, exclusive union, intersection) = (F_2^n, xor, and)
    ring_ok = True
    for n in range(0, 5):
        N = 1 << n
        for U in range(N):
            for V in range(N):
                sym = set(i for i in range(n) if U >> i & 1) ^ set(i for i in range(n) if V >> i & 1)
                if sum(1 << i for i in sym) != U ^ V: ring_ok = False
                if (U & V) != sum(1 << i for i in range(n) if U >> i & 1 and V >> i & 1): ring_ok = False
                if not (U & V) and (U ^ V) != (U | V): ring_ok = False        # exclusive union of disjoint sets = the sum ⊕
        # restrictions A -> A cap W are ring maps (xor, and) and the presheaf glues (binary covers)
        for U in range(N):
            for W in range(N):
                if not sub(W, U): continue
                if any(((A ^ B) & W) != ((A & W) ^ (B & W)) or ((A & B) & W) != ((A & W) & (B & W)) for A in range(N) for B in range(N) if sub(A, U) and sub(B, U)): ring_ok = False
        for U1 in range(N):
            for U2 in range(N):                                        # gluing: sections on U1, U2 agreeing on U1 cap U2 glue uniquely on U1 cup U2
                pairs = {(A & U1, A & U2) for A in range(N) if sub(A, U1 | U2)}
                compat = {(A1, A2) for A1 in range(N) for A2 in range(N) if sub(A1, U1) and sub(A2, U2) and (A1 & U2) == (A2 & U1)}
                if pairs != compat or len(pairs) != 1 << pc(U1 | U2): ring_ok = False
    ok = same and ring_ok
    return report('bd·mjc·28', ok, f'reading (A): the category of open sets of the discrete space Ob D with inclusions, (objects, arrows) = {Cs}: B_2 for each D with two objects, so it does not see the morphisms of D (the closing remark of §1 holds in this reading); the ring of opens (subsets, exclusive union, intersection) is (F_2^n, xor, and), the restrictions A -> A cap W are ring maps and the sections glue (n <= 4): {ring_ok}; the exclusive union of disjoint sets is the sum ⊕ of the labels')

# ================================================================== bd·mjc·29  reading (B): Yoneda keeps the morphisms
class Cat:
    def __init__(self, m, dom, cod, ident, comp, name=''):
        self.m, self.dom, self.cod, self.ident, self.comp, self.name = m, dom, cod, ident, comp, name
        self.A = len(dom); self.isid = set(ident)
    def c(self, f, g): return self.comp[(f, g)]
def build(name, m, arrows, table):
    names = list(arrows); k = len(names); idx = {x: i for i, x in enumerate(names)}
    dom = [arrows[x][0] for x in names] + list(range(m)); cod = [arrows[x][1] for x in names] + list(range(m))
    ident = [k + o for o in range(m)]; comp = {}
    for f in range(k + m):
        for g in range(k + m):
            if cod[f] != dom[g]: continue
            if f >= k: comp[(f, g)] = g
            elif g >= k: comp[(f, g)] = f
            else:
                v = table[(names[f], names[g])]; comp[(f, g)] = (k + dom[f]) if v == '1' else idx[v]
    return Cat(m, dom, cod, ident, comp, name)
def nat_count(C, a, b, sab=False):
    """natural transformations Hom(-, a) -> Hom(-, b): families alpha_x : Hom(x, a) -> Hom(x, b) with alpha_x'(h o u) = alpha_x(h) o u"""
    H = {x: [f for f in range(C.A) if C.dom[f] == x and C.cod[f] == a] for x in range(C.m)}
    K = {x: [f for f in range(C.A) if C.dom[f] == x and C.cod[f] == b] for x in range(C.m)}
    keys = [(x, h) for x in range(C.m) for h in H[x]]
    choices = [K[x] for (x, h) in keys]
    count = 0
    for vals in itertools.product(*choices):
        al = dict(zip(keys, vals)); natural = True
        for (x, h) in keys:
            for u in range(C.A):
                if C.cod[u] != x: continue
                xp = C.dom[u]; hu = C.c(u, h)                          # h o u
                if al[(xp, hu)] != C.c(u, al[(x, h)]): natural = False; break
            if not natural: break
        if sab: natural = True                                         # sabotage: naturality not imposed
        count += natural
    return count
def check29(sab=False):
    cats = [build('arrow', 2, {'f': (0, 1)}, {}),
            build('B_2', 4, {'a': (0, 1), 'b': (0, 2), 'c': (1, 3), 'd': (2, 3), 't': (0, 3)}, {('a', 'c'): 't', ('b', 'd'): 't'}),
            build('Kronecker', 2, {'f': (0, 1), 'g': (0, 1)}, {}),
            build('Z3', 1, {'x': (0, 0), 'y': (0, 0)}, {('x', 'x'): 'y', ('x', 'y'): '1', ('y', 'x'): '1', ('y', 'y'): 'x'}),
            build('{1,e}', 1, {'e': (0, 0)}, {('e', 'e'): 'e'}),
            build('split idempotent', 2, {'s': (0, 1), 'r': (1, 0), 'e': (1, 1)}, {('s', 'r'): '1', ('r', 's'): 'e', ('e', 'e'): 'e', ('s', 'e'): 's', ('e', 'r'): 'r'})]
    yon_ok = 0; total = 0; rows = []
    for C in cats:
        good = all(nat_count(C, a, b, sab) == sum(1 for f in range(C.A) if C.dom[f] == a and C.cod[f] == b) for a in range(C.m) for b in range(C.m))
        yon_ok += good; total += 1
    # Alexandrov topology of random posets recovers the poset
    rng = random.Random(52); rec = 0
    for _ in range(200):
        m = 6; up = [1 << i for i in range(m)]
        for i in range(m - 1, -1, -1):
            for j in range(i + 1, m):
                if rng.random() < 0.35: up[i] |= up[j]
        leq = {(x, y) for x in range(m) for y in range(m) if up[x] >> y & 1}
        opens = [X for X in range(1 << m) if all(not (X >> y & 1) or all(X >> x & 1 for x in range(m) if (x, y) in leq) for y in range(m))]
        spec = {(x, y) for x in range(m) for y in range(m) if all(X >> x & 1 for X in opens if X >> y & 1)}
        rec += spec == leq
    # {1, e} against its idempotent completion: objects 1 and e; Hom(x, y) = y M x; e is a retract of 1, not isomorphic to it
    M = {('1', '1'): '1', ('1', 'e'): 'e', ('e', '1'): 'e', ('e', 'e'): 'e'}
    mul = lambda x, y: M[(x, y)]
    def hom(x, y): return {mul(mul(y, m_), x) for m_ in ('1', 'e')}
    retract = 'e' in hom('e', '1') and 'e' in hom('1', 'e') and mul('e', 'e') == 'e'
    iso = any(mul(g, f) == '1' and mul(f, g) == 'e' for f in hom('1', 'e') for g in hom('e', '1'))   # g o f = id_1 and f o g = id_e (id_e = e)
    ok = yon_ok == total and rec == 200 and retract and not iso
    return report('bd·mjc·29', ok, f'reading (B): |Nat(y(a), y(b))| = |Hom(a, b)| for every pair of objects in {yon_ok} of {total} categories (arrow, B_2, Kronecker, Z3, {{1,e}}, split idempotent; brute force over all families): the presheaf side keeps every morphism (Yoneda); the Alexandrov topology recovers random posets (seed 52) in {rec} of 200; in the idempotent completion of {{1,e}} the object e is a retract of 1: {retract}, isomorphic to it: {iso}')

# ================================================================== bd·mjc·37  morphisms are local for the Alexandrov topology, not for the discrete one
def glue_failures(m, arrows, opens):
    """covers U = U1 cup U2 by two opens where the free presheaf on the arrows of D|U fails gluing: an arrow of D|U in neither D|U1 nor D|U2"""
    def inside(U): return {k for k, (d, c) in enumerate(arrows) if U >> d & 1 and U >> c & 1}
    fails = 0; tested = 0
    for U1 in opens:
        for U2 in opens:
            tested += 1
            if inside(U1 | U2) != inside(U1) | inside(U2): fails += 1
    return fails, tested
def reach_downsets(m, arrows):
    leq = [[x == y for y in range(m)] for x in range(m)]
    for (d, c) in arrows: leq[d][c] = True
    for k in range(m):
        for i in range(m):
            for j in range(m):
                if leq[i][k] and leq[k][j]: leq[i][j] = True
    return [X for X in range(1 << m) if all(not (X >> y & 1) or all(X >> x & 1 for x in range(m) if leq[x][y]) for y in range(m))]
def check37(sab=False):
    Ds = {'arrow': (2, [(0, 1)]), 'B_2': (4, [(0, 1), (0, 2), (1, 3), (2, 3), (0, 3)]), 'Kronecker': (2, [(0, 1), (0, 1)]),
          'crown': (4, [(0, 2), (0, 3), (1, 2), (1, 3)]), 'pair groupoid': (2, [(0, 1), (1, 0)]), 'loop + edge': (2, [(0, 0), (0, 1)])}
    rows = []; ok = True
    for name, (m, arrows) in Ds.items():
        disc = glue_failures(m, arrows, list(range(1 << m)))
        alex_opens = reach_downsets(m, arrows)
        if sab: alex_opens = list(range(1 << m))                            # sabotage: the discrete topology under the Alexandrov name
        alex = glue_failures(m, arrows, alex_opens)
        rows.append(f'{name}: discrete {disc[0]} of {disc[1]} covers fail, Alexandrov {alex[0]} of {alex[1]}')
        has_edge = any(d != c for (d, c) in arrows)
        if alex[0] != 0 or (disc[0] > 0) != has_edge: ok = False
    rng = random.Random(53); rnd_ok = 0
    for _ in range(100):
        m = 5; arrows = [(i, j) for i in range(m) for j in range(i + 1, m) if rng.random() < 0.4]
        alex = glue_failures(m, arrows, reach_downsets(m, arrows) if not sab else list(range(1 << m)))
        disc = glue_failures(m, arrows, list(range(1 << m)))
        rnd_ok += alex[0] == 0 and ((disc[0] > 0) == bool(arrows))
    ok = ok and rnd_ok == 100
    return report('bd·mjc·37', ok, 'the free presheaf on the arrows of D|U: ' + '; '.join(rows) + f'; 100 random acyclic digraphs on 5 objects (seed 53): sheaf on the Alexandrov space and not on the discrete one (when an arrow exists) in {rnd_ok} of 100')

CHECKS = [('bd·mjc·25', check25), ('bd·mjc·26', check26), ('bd·mjc·27', check27), ('bd·mjc·28', check28), ('bd·mjc·29', check29), ('bd·mjc·37', check37)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear()
            okk = f(sab=True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            if okk: missed += 1
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    nfail = sum(1 for _, okk in RESULTS if not okk)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
