#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mja_exterior.py: the bit rule restricted to disjoint labels, the contraction filtration, and the three second cohomology groups of the
labels: the group Z_2^n, the partial monoid of disjoint labels, the category B_n; the sum (8) of arXiv:2403.19689 (v3) on the arrows of B_n.

    python3 selfcheck/bridges/mja_exterior.py              one line per check, ids bd·mja·1 .. bd·mja·8 and bd·mja·37; exit 1 on any FAIL
    python3 selfcheck/bridges/mja_exterior.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only; exact integers and F_2 bitsets; deterministic (seeds 1, 2); about 8 s; runs from any folder, reads and writes no file.
  bd·mja·1  for every eps in {+1,-1,0}^n, n <= 6, the bit-rule sign s(a,b) on a disjoint pair (a AND b = 0) equals (-1)^N(a,b), the sign
            of eps = 0: it does not depend on the squares; on every overlapping pair it does (two eps give different values).
  bd·mja·2  an independent engine (the word e_a e_b sorted by transpositions, equal generators cancelled with eps_i) equals the bit rule on
            every pair for every eps, n <= 4; on disjoint pairs the sign is the parity of the shuffle sorted(a) ++ sorted(b), n <= 6.
  bd·mja·3  the partial sum a (+) b = a XOR b for a AND b = 0 is defined on 3^n ordered pairs (n = 0..6); pairwise disjoint k-tuples number
            (k+1)^n (k = 2 for n <= 5, k = 3 for n <= 3; the line prints '-' where it does not count).
  bd·mja·4  the truncated product (bit rule on disjoint pairs, 0 on overlapping pairs) is, for every eps, the bit rule of Cl(0,0,n) =
            Lambda(R^n) and associative (n <= 5); disjoint blades graded-commute, e_a e_b = (-1)^{|a||b|} e_b e_a, for every eps (n <= 6);
            on overlapping pairs with nonzero product the exponent is |a||b| + |a AND b|.
  bd·mja·5  Chevalley: the left multiplication by a generator is wedge plus contraction, e_i x = e_i ^ x + iota_i x (iota_i the
            antiderivation with iota_i e_j = eps_i delta_ij), and iterating it gives the bit rule on every pair, every eps, n <= 4.
  bd·mja·6  filtration by grade: the associated graded product is the exterior product for every eps (n <= 5); the pairs of contraction
            order k = |a AND b| number C(n,k) 3^(n-k), summing to 4^n (n <= 6).  The product of e_a and e_b has grade |a| + |b| - 2|a AND b|
            (F_i F_j in F_{i+j}) because its label is a XOR b: a remark that holds by construction, not part of the check.
  bd·mja·7  second cohomology with F_2 (= +-1) coefficients, normalised cochains: H^2(Z_2^n) has dimension n(n+1)/2 (n <= 4), H^2 of the
            partial monoid of disjoint labels has dimension C(n,2) (n <= 5), H^2 (and H^1) of the nerve of the category B_n is 0 (n <= 4);
            restriction from the group to the partial monoid is onto with an n-dimensional kernel (the squares); the bit-rule sign pulled
            back to the composable pairs of B_n is the coboundary of the 1-cochain sigma(S -> T) = s(T \ S, S) (n <= 5).
  bd·mja·8  noise: of the 512 normalised +-1 sign tables on Z_2^2 exactly 16 are associative (the cocycles); 0 of 2000 random tables on
            Z_2^3 (seed 1) and 200 of 200 random cocycles (seed 2) are associative; on the disjoint labels of n = 3 exactly 128 of the 4096
            tables are associative where defined, in 8 commutation classes of 16; the class of Lambda (commutation (-1)^{|a||b|}) is one,
            the commutative class another.
  bd·mja·37  the paper's sum (8) on the arrows of B_n in a generic drawing (each arrow its own vector; f (+) g = the composite in whichever order
            is defined) is a commutative partial monoid with dim H^2 = 0, 2, 12, 50 for n = 1..4; the commutation bits (f g = +- g f) detect every
            class; a class in which every composable pair anticommutes exists, and so does the pull-back of the class of Lambda (anticommuting
            exactly when |T \ S| |U \ T| is odd), n = 2..4; the category itself (one order of composition) has H^2 = 0.
"""
import itertools, random, sys
from math import comb

SABOTAGE = '--sabotage' in sys.argv
ROWS = []
def row(cid, ok, text):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

# ------------------------------------------------------------------ the bit rule (core_check.py)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def idx(a): return [i for i in range(a.bit_length()) if a >> i & 1]
def epsilons(n): return [list(e) for e in itertools.product((1, -1, 0), repeat=n)]

# ------------------------------------------------------------------ independent engines
def word_product(a, b, eps, broken=False):
    """e_a e_b by sorting the word sorted(a) ++ sorted(b) with transpositions (sign -1 each) and cancelling e_i e_i = eps_i"""
    w = idx(a) + idx(b); s = 1
    for k in range(1, len(w)):                       # insertion sort; never swap equal letters
        j = k
        while j > 0 and w[j - 1] > w[j]:
            w[j - 1], w[j] = w[j], w[j - 1]; j -= 1
            if not (broken and w[j] == 0 and w[j + 1] == 1): s = -s     # sabotage: the transposition of e_0, e_1 keeps the sign
    out = []; k = 0
    while k < len(w):
        if k + 1 < len(w) and w[k] == w[k + 1]:
            s *= eps[w[k]]; k += 2
        else:
            out.append(w[k]); k += 1
    lab = 0
    for i in out: lab |= 1 << i
    return s, lab
def shuffle_sign(a, b):
    w = idx(a) + idx(b)
    inv = sum(1 for x in range(len(w)) for y in range(x + 1, len(w)) if w[x] > w[y])
    return (-1) ** inv

# ------------------------------------------------------------------ F_2 linear algebra on int bitsets
def f2_rank(rows):
    basis = {}
    for r in rows:
        while r:
            h = r.bit_length() - 1
            if h in basis: r ^= basis[h]
            else: basis[h] = r; break
    return len(basis)
def f2_nullspace(eqs, nvars):
    """basis of {x in F_2^nvars : <eq, x> = 0 for every eq} (eqs are int bitsets)"""
    piv = {}                                        # pivot column -> reduced row
    for r in eqs:
        for c, pr in piv.items():
            if r >> c & 1: r ^= pr
        if not r: continue
        c = r.bit_length() - 1
        for c2 in list(piv):
            if piv[c2] >> c & 1: piv[c2] ^= r
        piv[c] = r
    free = [c for c in range(nvars) if c not in piv]
    basis = []
    for f in free:
        v = 1 << f
        for c, pr in piv.items():
            if pr >> f & 1: v |= 1 << c
        basis.append(v)
    return basis

# ------------------------------------------------------------------ normalised 2-cohomology of a partial magma with units (F_2 values)
class PartialMagma:
    """a partial monoid: elems = the non-unit elements, mul(x, y) -> element, the unit U, or None (undefined); normalised F_2 cochains
    live on the defined pairs of non-unit elements; c(U, z) = c(z, U) = 0 and f(U) = 0."""
    def __init__(self, elems, mul, unit=0):
        self.E = elems; self.U = unit; self.mul = mul
        self.pairs = [(x, y) for x in elems for y in elems if mul(x, y) is not None]
        self.ppos = {p: i for i, p in enumerate(self.pairs)}
    def m(self, x, y):
        if x == self.U: return y
        if y == self.U: return x
        return self.mul(x, y)
    def cocycle_eqs(self):
        eqs = []
        for (x, y) in self.pairs:
            xy = self.m(x, y)
            for z in self.E:
                yz = self.m(y, z)
                if yz is None: continue
                l = self.m(xy, z); r = self.m(x, yz)
                if l is None and r is None: continue
                assert l == r, 'associativity of the partial monoid itself'
                e = 1 << self.ppos[(x, y)] ^ 1 << self.ppos[(y, z)]
                if xy != self.U: e ^= 1 << self.ppos[(xy, z)]
                if yz != self.U: e ^= 1 << self.ppos[(x, yz)]
                eqs.append(e)
        return eqs
    def coboundaries(self):
        rows = []
        for x in self.E:
            v = 0
            for (a, b), i in self.ppos.items():
                cnt = (a == x) + (b == x) + (self.m(a, b) == x)
                if cnt % 2: v ^= 1 << i
            rows.append(v)
        return rows
    def h2(self):
        Z = f2_nullspace(self.cocycle_eqs(), len(self.pairs)); B = self.coboundaries()
        dz, db = len(Z), f2_rank(B)
        return dz, db, dz - db, Z, B

def group_magma(n):
    return PartialMagma(list(range(1, 1 << n)), lambda x, y: x ^ y)
def disjoint_magma(n, broken=False):
    if broken:   # sabotage: the total XOR (the group) in place of the disjoint partial sum
        return group_magma(n)
    return PartialMagma(list(range(1, 1 << n)), lambda x, y: (x | y) if x & y == 0 else None)

def poset_chain_cohomology(elems, leq, kmax=3):
    """F_2 cohomology H^0..H^{kmax-1} of the order complex (chains x0 < x1 < ... < xk; coboundary = sum over deleted vertices)"""
    lt = {(x, y) for x in elems for y in elems if x != y and leq(x, y)}
    chains = {0: [(x,) for x in elems]}
    for k in range(1, kmax + 1):
        chains[k] = [c + (y,) for c in chains[k - 1] for y in elems if (c[-1], y) in lt]
    pos = {k: {c: i for i, c in enumerate(chains[k])} for k in chains}
    def dmat(k):                                     # rows: images of the basis cochains of degree k
        rows = []
        for c in chains[k]:
            v = 0
            for cc in chains[k + 1]:
                faces = sum(1 for m in range(k + 2) if cc[:m] + cc[m + 1:] == c)
                if faces % 2: v ^= 1 << pos[k + 1][cc]
            rows.append(v)
        return rows
    ranks = {-1: 0}
    for k in range(kmax): ranks[k] = f2_rank(dmat(k))
    return {k: len(chains[k]) - ranks[k] - ranks[k - 1] for k in range(kmax)}

def boolean_nerve_h(n, poset=None):
    elems = list(range(1 << n)) if poset is None else poset[0]
    leq = (lambda x, y: x & y == x) if poset is None else poset[1]
    return poset_chain_cohomology(elems, leq, kmax=3)

def octahedral():    # three levels of two incomparable elements, all relations between consecutive levels: order complex = S^2
    el = list(range(6)); lev = [0, 0, 1, 1, 2, 2]
    return el, (lambda x, y: x == y or lev[x] < lev[y])
def crown():         # a, b < c, d: order complex = a 4-cycle = S^1
    el = list(range(4)); lev = [0, 0, 1, 1]
    return el, (lambda x, y: x == y or lev[x] < lev[y])

# ================================================================== checks
def chk1(sab):
    rule = sgn
    if sab:   # an eps-dependent factor on disjoint pairs: eps_i whenever i in a and i + 1 in b
        def rule(a, b, eps):
            s = sgn(a, b, eps)
            for i in range(len(eps) - 1):
                if a >> i & 1 and b >> (i + 1) & 1 and eps[i] != 0: s *= eps[i]
            return s
    ok = True; dep_disjoint = 0; tot_disjoint = 0; overlap_dep = 0; overlap_tot = 0
    for n in range(0, 7):
        E = epsilons(n); N = 1 << n
        for a in range(N):
            for b in range(N):
                vals = {rule(a, b, e) for e in E}
                if a & b == 0:
                    tot_disjoint += 1
                    if vals != {(-1) ** sum(1 for i in idx(a) for j in idx(b) if j < i)}: dep_disjoint += 1; ok = False
                else:
                    overlap_tot += 1
                    if len(vals) > 1: overlap_dep += 1
                    else: ok = False
    want_d = sum(3 ** n for n in range(7)); want_o = sum(4 ** n - 3 ** n for n in range(7))
    ok = ok and tot_disjoint == want_d and overlap_tot == want_o and overlap_dep == want_o
    return ok, (f'on the {tot_disjoint} disjoint pairs of n = 0..6 (sum of 3^n) the sign is (-1)^N(a,b) for all 3^n sign vectors eps: '
                f'independent of the squares; all {overlap_dep} overlapping pairs (sum of 4^n - 3^n) change with eps'), \
           f'disjoint pairs whose sign depends on eps: {dep_disjoint}'

def chk2(sab):
    ok = True; bad = 0; cnt = 0
    for n in range(0, 5):
        for e in epsilons(n):
            for a in range(1 << n):
                for b in range(1 << n):
                    s, lab = word_product(a, b, e, broken=sab); cnt += 1
                    if lab != a ^ b or s != sgn(a, b, e): bad += 1
    bad2 = 0; cnt2 = 0
    for n in range(0, 7):
        for a in range(1 << n):
            for b in range(1 << n):
                if a & b: continue
                cnt2 += 1
                sh = shuffle_sign(a, b)
                if sab: sh = sh if not (a & 1 and b & 2) else -sh
                if sh != sgn(a, b, [0] * n): bad2 += 1
    ok = bad == 0 and bad2 == 0
    return ok, (f'the word engine (transpositions, e_i e_i = eps_i) equals the bit rule on all {cnt} (pair, eps) cases, n <= 4; the shuffle '
                f'parity of sorted(a) ++ sorted(b) equals the disjoint sign on all {cnt2} disjoint pairs, n <= 6'), \
           f'mismatches: word engine {bad}, shuffle {bad2}'

def chk3(sab):
    ok = True; table = []
    for n in range(0, 7):
        N = 1 << n
        defined = (lambda a, b: pc(a & b) <= 1) if sab else (lambda a, b: a & b == 0)
        p2 = sum(1 for a in range(N) for b in range(N) if defined(a, b))
        p3 = sum(1 for a in range(N) for b in range(N) if defined(a, b) for c in range(N) if defined(a, c) and defined(b, c)) if n <= 5 else None
        p4 = sum(1 for a in range(N) for b in range(N) if defined(a, b) for c in range(N) if defined(a, c) and defined(b, c)
                 for d in range(N) if defined(a, d) and defined(b, d) and defined(c, d)) if n <= 3 else None
        table.append((n, p2, '-' if p3 is None else p3, '-' if p4 is None else p4))
        if p2 != 3 ** n or (p3 is not None and p3 != 4 ** n) or (p4 is not None and p4 != 5 ** n): ok = False
    return ok, ('defined pairs, pairwise disjoint triples and quadruples (n, pairs, triples, quadruples): '
                + ', '.join(f'({n}, {a}, {b}, {c})' for n, a, b, c in table) + ' = (3^n, 4^n, 5^n); triples counted to n = 5, quadruples to n = 3'), \
           'counts ' + str(table[:4])

def chk4(sab):
    ok = True; bad_assoc = 0; bad_eq = 0; bad_gc = 0; bad_gc2 = 0
    for n in range(0, 6):
        for e in epsilons(n):
            N = 1 << n
            def t(a, b):
                if a & b: return 0
                s = sgn(a, b, e)
                if sab and a == 1 and b == 2: s = -s                 # sabotage: one sign flipped
                return s
            for a in range(N):
                for b in range(N):
                    if t(a, b) != sgn(a, b, [0] * n): bad_eq += 1
            for a in range(N):
                for b in range(N):
                    tab = t(a, b)
                    for c in range(N):
                        l = tab * t(a ^ b, c) if tab else 0
                        tbc = t(b, c); r = tbc * t(a, b ^ c) if tbc else 0
                        if l != r: bad_assoc += 1
    for n in range(0, 7):
        for e in epsilons(n) if n <= 5 else [[1] * n, [-1] * n, [0] * n, [1, -1, 0, 1, -1, 0]]:
            N = 1 << n
            for a in range(N):
                for b in range(N):
                    sab_, sba = sgn(a, b, e), sgn(b, a, e)
                    if sab and a == 1 and b == 2: sab_ = -sab_
                    if a & b == 0:
                        if sab_ != (-1) ** (pc(a) * pc(b)) * sba: bad_gc += 1
                    elif sab_ != 0 and sab_ != (-1) ** (pc(a) * pc(b) + pc(a & b)) * sba: bad_gc2 += 1
    ok = bad_assoc == 0 and bad_eq == 0 and bad_gc == 0 and bad_gc2 == 0
    return ok, ('for every eps (n <= 5) the truncated product equals the bit rule of Cl(0,0,n) = Lambda(R^n) on every pair and is associative on '
                'every triple; disjoint blades satisfy e_a e_b = (-1)^{|a||b|} e_b e_a for every eps (n <= 5; four eps at n = 6); overlapping '
                'pairs with nonzero product: exponent |a||b| + |a AND b|'), \
           f'failures: equal {bad_eq}, associativity {bad_assoc}, graded commutativity {bad_gc}, overlap rule {bad_gc2}'

def wedge(a, b):
    return (0, 0) if a & b else (shuffle_sign(a, b), a | b)
def contract(i, a, eps, broken=False):
    """iota_i e_a for the antiderivation with iota_i e_j = eps_i delta_ij: (-1)^{position of i in a} eps_i e_{a - i}"""
    if not a >> i & 1: return (0, 0)
    m = sum(1 for j in idx(a) if j < i)
    v = eps[i] if not broken else -eps[i]
    return ((-1) ** m * v, a ^ (1 << i))
def gen_mult(i, x, eps, broken=False):
    out = {}
    for a, c in x.items():
        for s, lab in (wedge(1 << i, a), contract(i, a, eps, broken)):
            if s: out[lab] = out.get(lab, 0) + s * c
    return {k: v for k, v in out.items() if v}
def chk5(sab):
    bad = 0; cnt = 0
    for n in range(0, 5):
        for e in epsilons(n):
            for a in range(1 << n):
                for b in range(1 << n):
                    x = {b: 1}
                    for i in reversed(idx(a)): x = gen_mult(i, x, e, broken=sab)
                    s = sgn(a, b, e); want = {a ^ b: s} if s else {}
                    cnt += 1
                    if x != want: bad += 1
    return bad == 0, (f'e_i x = e_i ^ x + iota_i x, iterated over the generators of a, gives e_a e_b of the bit rule in all {cnt} (pair, eps) cases, '
                      'n <= 4: the Clifford product is the exterior product plus contractions with the squares eps_i'), f'mismatches: {bad} of {cnt}'

def chk6(sab):
    bad_f = bad_gr = 0; counts = []                                    # bad_f: the grade of a XOR b, an identity of popcounts (a remark)
    for n in range(0, 6):
        for e in epsilons(n):
            N = 1 << n
            for a in range(N):
                for b in range(N):
                    s = sgn(a, b, e)
                    if s and pc(a ^ b) != pc(a) + pc(b) - 2 * pc(a & b): bad_f += 1
                    if s and pc(a ^ b) > pc(a) + pc(b): bad_f += 1
                    # associated graded: component of grade |a| + |b|
                    top = (s, a ^ b) if (s and pc(a ^ b) == pc(a) + pc(b)) else (0, 0)
                    if sab and s: top = (s, a ^ b)                     # sabotage: keep the whole product (no grading)
                    if top != wedge(a, b): bad_gr += 1
    ok_counts = True
    for n in range(0, 7):
        N = 1 << n
        by = [0] * (n + 1)
        for a in range(N):
            for b in range(N): by[pc(a & b)] += 1
        counts.append(by)
        if by != [comb(n, k) * 3 ** (n - k) for k in range(n + 1)] or sum(by) != 4 ** n: ok_counts = False
    ok = bad_gr == 0 and ok_counts
    return ok, ('the associated graded product equals the exterior product for every eps (n <= 5); pairs by contraction order k: ' + '; '.join(f'n={n}: {c}' for n, c in enumerate(counts) if n in (2, 3, 4))
                + f' = C(n,k) 3^(n-k), total 4^n (n <= 6); remark, by construction (the label of e_a e_b is a XOR b) and not part of the check: every nonzero '
                f'product has grade |a| + |b| - 2|a AND b|, F_i F_j in F_(i+j) ({bad_f} exceptions)'), f'failures: filtration {bad_f}, associated graded {bad_gr}'

def chk7(sab):
    out = []; ok = True
    for n in range(1, 5):
        dz, db, h, _, _ = group_magma(n).h2()
        out.append(f'group n={n}: {h}')
        if h != n * (n + 1) // 2: ok = False
    for n in range(1, 6):
        dz, db, h, _, _ = disjoint_magma(n, broken=sab).h2()
        out.append(f'partial monoid n={n}: {h}')
        if h != comb(n, 2): ok = False
    for n in range(1, 5):
        H = boolean_nerve_h(n, poset=octahedral() if sab else None)
        out.append(f'B_{n}: H1 {H[1]}, H2 {H[2]}')
        if H[0] != 1 or H[1] != 0 or H[2] != 0: ok = False
    # restriction from the group to the partial monoid
    rest = []
    for n in range(1, 5):
        G = group_magma(n); P = disjoint_magma(n)
        _, _, hG, ZG, BG = G.h2(); _, _, hP, ZP, BP = P.h2()
        def restrict(v):
            r = 0
            for (x, y), i in P.ppos.items():
                if v >> G.ppos[(x, y)] & 1: r ^= 1 << i
            return r
        img = f2_rank([restrict(z) for z in ZG] + BP) - f2_rank(BP)
        kern = hG - img
        rest.append((n, img, kern))
        if img != hP or kern != n: ok = False
        # the bit-rule cocycles for eps in {+1,-1}^n restrict to one and the same function
        funcs = set()
        for e in itertools.product((1, -1), repeat=n):
            funcs.add(tuple(sgn(x, y, list(e)) for (x, y) in P.pairs))
        if len(funcs) != 1: ok = False
    # the pulled-back sign on B_n is the coboundary of sigma(S -> T) = s(T \ S, S)
    bad = 0
    for n in range(1, 6):
        N = 1 << n; e0 = [0] * n
        for S in range(N):
            for d1 in range(N):
                if d1 & S: continue
                for d2 in range(N):
                    if d2 & (S | d1): continue
                    # arrows f: S -> S + d1, g: S + d1 -> S + d1 + d2, composite g f: S -> S + d1 + d2; pulled-back cocycle s(d2, d1)
                    lhs = sgn(d2, d1, e0)
                    sig = lambda d, X: sgn(d, X, e0)
                    rhs = sig(d1, S) * sig(d2, S | d1) * sig(d1 | d2, S)
                    if sab and n == 2 and S == 0 and d1 == 1 and d2 == 2: rhs = -rhs
                    if lhs != rhs: bad += 1
    if bad: ok = False
    return ok, ('dim H^2 with F_2 coefficients (normalised): ' + '; '.join(out) + ' (n(n+1)/2, C(n,2), 0); restriction group -> partial monoid '
                + ', '.join(f'n={n}: image {i}, kernel {k}' for n, i, k in rest) + ' (onto, kernel = the n squares; the 2^n sign vectors in {+1,-1}^n '
                'restrict to one function); on the composable pairs of B_n (n <= 5) s(d2,d1) = sigma(f) sigma(g) sigma(g f) with sigma(S -> T) = s(T \\ S, S): '
                'a coboundary'), f'output: {out[-4:]}, coboundary failures {bad}'

def is_assoc_full(t, n):
    N = 1 << n
    return all(t[a][b] * t[a ^ b][c] == t[b][c] * t[a][b ^ c] for a in range(N) for b in range(N) for c in range(N))
def chk8(sab):
    ok = True; rng = random.Random(1)
    # n = 2: all 512 normalised tables
    n = 2; N = 4; cnt = 0
    nz = [(a, b) for a in range(1, N) for b in range(1, N)]
    for bits in range(1 << len(nz)):
        t = [[1] * N for _ in range(N)]
        for k, (a, b) in enumerate(nz):
            if bits >> k & 1: t[a][b] = -1
        if is_assoc_full(t, n): cnt += 1
    if cnt != 16: ok = False
    # n = 3: random tables and random cocycles
    n = 3; N = 8
    rand_assoc = 0
    for _ in range(2000):
        t = [[1] * N for _ in range(N)]
        for a in range(1, N):
            for b in range(1, N): t[a][b] = rng.choice((1, -1))
        if is_assoc_full(t, n): rand_assoc += 1
    rng2 = random.Random(2); coc_assoc = 0
    for _ in range(200):
        beta = {(i, j): rng2.choice((1, -1)) for i in range(n) for j in range(n) if j < i}
        q = [rng2.choice((1, -1)) for _ in range(n)]
        f = [1] + [rng2.choice((1, -1)) for _ in range(N - 1)]
        def c(a, b):
            s = 1
            for i in idx(a):
                for j in idx(b):
                    if j < i: s *= beta[(i, j)]
                    if j == i: s *= q[i]
            return s
        t = [[c(a, b) * f[a] * f[b] * f[a ^ b] for b in range(N)] for a in range(N)]
        if sab: t[3][5] = -t[3][5]
        if is_assoc_full(t, n): coc_assoc += 1
    if rand_assoc != 0 or coc_assoc != 200: ok = False
    # n = 3 restricted to disjoint labels: all 4096 tables on the 12 nonzero disjoint pairs
    pairs = [(a, b) for a in range(1, N) for b in range(1, N) if a & b == 0]
    trip = [(a, b, c) for a in range(1, N) for b in range(1, N) for c in range(1, N) if a & b == 0 and b & c == 0 and a & c == 0]
    assoc = []; classes = {}
    for bits in range(1 << len(pairs)):
        t = {p: (-1 if bits >> k & 1 else 1) for k, p in enumerate(pairs)}
        tt = lambda a, b: 1 if a == 0 or b == 0 else t[(a, b)]
        if all(tt(a, b) * tt(a | b, c) == tt(b, c) * tt(a, b | c) for a, b, c in trip):
            assoc.append(t)
            key = tuple(t[(1 << i, 1 << j)] * t[(1 << j, 1 << i)] for i in range(n) for j in range(i))
            classes[key] = classes.get(key, 0) + 1
    lam = tuple(-1 for i in range(n) for j in range(i)); com = tuple(1 for i in range(n) for j in range(i))
    if len(assoc) != 128 or len(classes) != 8 or any(v != 16 for v in classes.values()) or lam not in classes or com not in classes: ok = False
    # the commutation is (-1)^{|a||b|} on all disjoint pairs exactly in the class of Lambda
    lam_tables = [t for t in assoc if all(t[(a, b)] * t[(b, a)] == (-1) ** (pc(a) * pc(b)) for (a, b) in pairs)]
    if len(lam_tables) != 16: ok = False
    return ok, (f'n = 2: {cnt} of 512 normalised sign tables are associative (= the cocycles, 2^3 classes x 2 coboundaries); n = 3: {rand_assoc} of 2000 '
                f'random tables (seed 1) and {coc_assoc} of 200 random cocycles (seed 2) are associative; disjoint labels of n = 3: {len(assoc)} of 4096 '
                f'tables are associative where defined, {len(classes)} classes of the commutation (16 each), the class of Lambda ((-1)^(|a||b|)) has '
                f'{len(lam_tables)} tables'), f'random cocycles associative: {coc_assoc} of 200'

def chk37(sab):
    ok = True; out = []
    want = {1: 0, 2: 2, 3: 12, 4: 50}
    for n in range(1, 5):
        N = 1 << n
        arr = [(S, T) for S in range(N) for T in range(N) if S & T == S and S != T]
        def osum(f, g):                                    # the sum (8): the composite in whichever order is defined
            vals = set()
            if f[1] == g[0]: vals.add((f[0], g[1]))
            if g[1] == f[0] and not sab: vals.add((g[0], f[1]))      # sabotage: one order only (the category itself)
            return vals.pop() if len(vals) == 1 else None
        def comp(f, g): return (f[0], g[1]) if f[1] == g[0] else None
        M = PartialMagma(arr, osum, unit='0'); C = PartialMagma(arr, comp, unit='0')
        dz, db, h, Z, B = M.h2(); hc = C.h2()[2]
        upairs = sorted({tuple(sorted(p)) for p in M.pairs})
        def commutation(z):
            v = 0
            for k, (f, g) in enumerate(upairs):
                if (f, g) in M.ppos and (g, f) in M.ppos and ((z >> M.ppos[(f, g)]) ^ (z >> M.ppos[(g, f)])) & 1: v |= 1 << k
            return v
        Cm = [commutation(z) for z in Z]
        rk = f2_rank(Cm) if Z else 0
        allanti = (1 << len(upairs)) - 1
        graded = 0
        for k, (f, g) in enumerate(upairs):
            if (pc(f[1] ^ f[0]) * pc(g[1] ^ g[0])) % 2: graded |= 1 << k
        has_all = f2_rank(Cm + [allanti]) == rk; has_gr = f2_rank(Cm + [graded]) == rk
        out.append(f'n={n}: H^2 of (V, (+)) {h} (commutation rank {rk}, unordered composable pairs {len(upairs)}; all pairs anticommuting: {has_all}; '
                   f'pairs anticommuting iff |d_f||d_g| odd: {has_gr}), H^2 of the category {hc}')
        if h != want[n] or rk != h or hc != 0 or (n >= 2 and not (has_all and has_gr)): ok = False
    return ok, ('the sum (8) on the arrows of B_n in a generic drawing (V = arrows, (+) = the composite in either order), normalised F_2 cochains: '
                + '; '.join(out) + ': commutativity of (8) opens sign classes that the category does not have; each class is determined by its commutation '
                'bits (which composable pairs anticommute), no squares'), '; '.join(out[1:3])

CHECKS = [('bd·mja·1', chk1), ('bd·mja·2', chk2), ('bd·mja·3', chk3), ('bd·mja·4', chk4), ('bd·mja·5', chk5), ('bd·mja·6', chk6),
          ('bd·mja·7', chk7), ('bd·mja·8', chk8), ('bd·mja·37', chk37)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            ok, _, seen = f(True)
            print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  broken input sees: ' + seen)
            missed += ok
        print('\nALL CAUGHT' if not missed else f'\n{missed} MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS:
        ok, text, _ = f(False)
        row(cid, ok, text)
    verdict()
