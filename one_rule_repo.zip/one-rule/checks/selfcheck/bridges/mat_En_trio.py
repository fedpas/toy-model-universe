#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mat_En_trio.py: the E_n series as the orthogonal complement of one vector k in the odd unimodular lattice I_{1,n}; finite, affine and
Lorentzian E_n as the sign of k.k.

  python3 selfcheck/bridges/mat_En_trio.py       one line per check, ids bd·mat·12 .. bd·mat·14; exit 1 on any FAIL

Standard library only, exact rationals, deterministic, under 1 s; runs from any folder, reads and writes no file.
  bd·mat·12  k = (3; -1, ..., -1) in I_{1,n} (Gram diag(1, -1^n)) has k.k = 9 - n; k^perp has determinant +-(9 - n) and signature (0, n, 0) for
             n <= 8, (0, 8, 1) at n = 9 and (1, n-1, 0) for n = 10..13: the type of E_n (finite / affine / Lorentzian) is the sign of k.k (T10 (1)-(3)).
  bd·mat·13  the norm -2 vectors of k^perp number 8, 20, 40, 72, 126, 240 for n = 3..8, the root counts of E_n (T10 (5)); exact enumeration with
             the bound |x0| <= 4. That k^perp is the E_n root lattice (del Pezzo surfaces) is standard and recalled, not computed.
  bd·mat·14  (an info line, not a check: the three numbers come from the signature formulas, nothing is recomputed) for n = 3..8: the Brown invariant of I_{1,n} is 1 - n mod 8 (its signature), the Gauss-Milgram phase of E_n = k^perp is
             n mod 8 (core·B13), and the clock of Cl(n,0) is n mod 8 (bd·mat·7): the clock of Cl(n,0) and the phase of E_n agree because I_n
             and E_n both have signature n.
"""
import sys
from fractions import Fraction as F

ROWS = []
def row(i, text, ok):
    ROWS.append((i, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
def info(i, text):
    print('info ' + i + '  ' + text)                                       # a read-off: printed, not counted as a check
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

def gram_I1n(n): return [[(1 if i == 0 else -1) if i == j else 0 for j in range(n + 1)] for i in range(n + 1)]
def dot(x, y, G): return sum(x[i] * G[i][j] * y[j] for i in range(len(x)) for j in range(len(y)))
def kperp_basis(n):
    """integer basis of {x in Z^{1,n} : x.k = 0}, k = (3; -1^n); x.k = 3 x0 + sum x_i. Basis: e_i - e_{i+1} (i >= 1), and (1; -1,-1,-1, 0...) for n >= 3"""
    B = []
    for i in range(1, n):
        v = [0] * (n + 1); v[i] = 1; v[i + 1] = -1; B.append(v)
    v = [0] * (n + 1); v[0] = 1; v[1] = v[2] = v[3] = -1; B.append(v)
    return B
def det_frac(M):
    n = len(M); A = [[F(x) for x in r] for r in M]; d = F(1)
    for c in range(n):
        piv = next((i for i in range(c, n) if A[i][c] != 0), None)
        if piv is None: return F(0)
        if piv != c: A[c], A[piv] = A[piv], A[c]; d = -d
        d *= A[c][c]
        for i in range(c + 1, n):
            if A[i][c] != 0:
                f = A[i][c] / A[c][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return d
def signature_of(M):
    n = len(M); A = [[F(x) for x in r] for r in M]; pos = neg = 0; active = list(range(n))
    while active:
        piv = next((i for i in active if A[i][i] != 0), None)
        if piv is None:
            pair = next(((i, j) for i in active for j in active if i < j and A[i][j] != 0), None)
            if pair is None: break
            i, j = pair
            for k in range(n): A[i][k] += A[j][k]
            for k in range(n): A[k][i] += A[k][j]
            piv = i
            if A[i][i] == 0: break
        d = A[piv][piv]
        if d > 0: pos += 1
        else: neg += 1
        for i in active:
            if i != piv and A[i][piv] != 0:
                f = A[i][piv] / d
                for k in range(n): A[i][k] -= f * A[piv][k]
                for k in range(n): A[k][i] -= f * A[k][piv]
        active.remove(piv)
    return (pos, neg, n - pos - neg)
def is_primitive(k):
    from math import gcd
    g = 0
    for x in k: g = gcd(g, abs(x))
    return g == 1

# ---------------------------------------------------------------- bd·mat·12
def check12():
    ok = True; out = []
    for n in range(3, 14):
        G = gram_I1n(n); k = [3] + [-1] * n
        kk = dot(k, k, G)
        if kk != 9 - n or not is_primitive(k): ok = False
        B = kperp_basis(n)
        if any(dot(v, k, G) != 0 for v in B): ok = False
        Gp = [[dot(u, v, G) for v in B] for u in B]
        d = det_frac(Gp); s = signature_of(Gp)
        if abs(d) != abs(9 - n): ok = False
        want = (0, n, 0) if n <= 8 else ((0, 8, 1) if n == 9 else (1, n - 1, 0))
        if s != want: ok = False
        trio = '+' if kk > 0 else ('0' if kk == 0 else '-')
        out.append(f'n={n}: k.k={kk} ({trio}), det={int(d)}, sig={s}')
    row('bd·mat·12', 'E_n = k^perp in I_{1,n}, k = (3; -1^n): k.k = 9 - n, det(k^perp) = +-(9 - n), signature (0,n,0) for n <= 8, (0,8,1) at n = 9, (1,n-1,0) for n = 10..13. '
        'The finite / affine / Lorentzian type of E_n is the sign of k.k, the trio +1 / 0 / -1 of one vector of the odd lattice: ' + '; '.join(out[:3] + ['...'] + out[6:8]), ok)

# ---------------------------------------------------------------- bd·mat·13: roots of k^perp
def count_roots(n):
    """vectors x in Z^{1,n} with 3 x0 + sum x_i = 0 and x0^2 - sum x_i^2 = -2"""
    total = 0
    for x0 in range(-4, 5):
        target_sq = x0 * x0 + 2; target_sum = -3 * x0
        # enumerate x_1..x_n with sum of squares = target_sq and sum = target_sum, pruning on the remaining square budget
        def rec(i, rem_sq, rem_sum):
            nonlocal total
            if i == n:
                if rem_sq == 0 and rem_sum == 0: total += 1
                return
            bound = int(rem_sq ** 0.5) + 1
            for v in range(-bound, bound + 1):
                if v * v > rem_sq: continue
                # the remaining n-i-1 entries can change the sum by at most sqrt((n-i-1)(rem_sq - v^2))
                left = n - i - 1; rs = rem_sq - v * v
                if (rem_sum - v) ** 2 > left * rs: continue
                rec(i + 1, rs, rem_sum - v)
        rec(0, target_sq, target_sum)
    return total
def check13():
    want = {3: 8, 4: 20, 5: 40, 6: 72, 7: 126, 8: 240}; got = {n: count_roots(n) for n in range(3, 9)}
    row('bd·mat·13', f'the norm -2 vectors of k^perp in I_(1,n) number {got} for n = 3..8 (expected E_n root counts 8, 20, 40, 72, 126, 240; T10 (5)): k^perp is the E_n root lattice '
        '(the del Pezzo picture: standard, recalled, not computed); the search bound |x0| <= 4 covers every root (the largest x0 of an E8 root is 3)', got == want)

# ---------------------------------------------------------------- bd·mat·14: two Z_8 numbers
def check14():
    ok = True; out = []
    for n in range(3, 9):
        # Brown invariant of I_{1,n}: Gauss sum prod (1 + i^{eps}) = (1+i)^1 (1-i)^n: phase 1 - n
        brown = (1 - n) % 8
        milgram = n % 8                       # core·B13: the Gauss-Milgram phase of E_n (even, positive definite, signature n)
        clock_n0 = n % 8                      # the clock of Cl(n,0) = Brown invariant of I_n
        if (milgram - brown) % 8 != (2 * n - 1) % 8: ok = False
        if clock_n0 != milgram: ok = False
        out.append(f'n={n}: Brown(I_(1,n))={brown}, Milgram(E_n)={milgram}, clock Cl(n,0)={clock_n0}')
    if ok: info('bd·mat·14', 'arithmetic from the signature formulas, n = 3..8 (not a computation): the ambient odd lattice I_{1,n} of E_n has Brown invariant 1 - n mod 8 '
        '(its signature), E_n = k^perp has Gauss-Milgram phase n mod 8 (its signature, core·B13), and the clock of Cl(n,0) is n mod 8 (the Brown invariant of I_n, bd·mat·7): '
        'the clock of Cl(n,0) and the phase of E_n agree because I_n and E_n both have signature n, while the ambient lattice I_{1,n} of E_n has another Brown invariant. ' + '; '.join(out[:2]))
    else: row('bd·mat·14', 'the signature arithmetic of I_{1,n}, E_n and I_n does not hold', ok)

if __name__ == '__main__':
    for f in (check12, check13, check14): f()
    verdict()
