#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjp_charges.py: the additive weights of arXiv:2403.19689 (v3) (its partial sum (8), its norm (9) and its equation (13)) read on the labels
as charges, particle number and energy; Koenigsberg's bridges (the paper's Example 1) as a category.

    python3 selfcheck/bridges/mjp_charges.py              one line per check, ids bd·mjp·9 .. bd·mjp·15; exit 1 on any FAIL
    python3 selfcheck/bridges/mjp_charges.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

numpy and the standard library; exact integers (and dyadic floats); random data from seeded generators; about 1 s on one core; reads and
writes no file; runs from any folder, also with python3 -I.
  bd·mjp·9   the weights h on the labels with h(a + b) = h(a) + h(b) for every disjoint pair (the partial sum of the paper's (8), (9) read on the
             labels) form a space of dimension n (n = 0..6): h(a) = sum_{i in a} q_i, the charges.  For n = 5 and random charges q (seed 9) the
             one-body operator H0 = sum_i q_i c_i^+ c_i, built from the bit-rule creation operators (Jordan-Wigner signs included), is
             diagonal with diagonal h_q, and that spectrum satisfies (9) on every disjoint pair; the operator H0 + U c_0^+ c_0 c_1^+ c_1 (U = 3)
             is diagonal and its spectrum fails (9) on ({0},{1}) by exactly U; 200 random functions with h(0) = 0 are additive in 0 of 200.
  bd·mjp·10  the weights on the arrows of the label category B_n that are additive on composition (functors to (R, +), identities 0) form a space
             of dimension 2^n - 1, the potentials w(S -> T) = E(T) - E(S) (any energy function E, interacting or not); those that depend only on the
             label T\\S of the arrow form the n-dimensional space of bd·mjp·9 (n = 1..5).  Control: 200 random posets on 8 and 16 elements: the
             dimension is (elements - components + b1), b1 the first Betti number of the order complex, in 200 of 200 (the additive weights are the
             1-cocycles, the potentials the coboundaries); it is (elements - components) only in the posets with b1 = 0 (seed 10).  B_n has a
             minimum (the vacuum), so b1 = 0 and every additive weight is an energy difference.
  bd·mjp·11  the pairing decides the integer weight: in the bit-rule Cl(n,n) the n! 2^n Witt pairings a_i^+ = (g_i + t_i g_{n+sigma(i)})/2 of the same
             generators give n! 2^n different number operators N and one parity operator up to sign (+- the top blade g_1 .. g_2n) (n = 2, 3):
             (V, Q, pi) fixes the parity pi, not the particle number.
  bd·mjp·12  the order of B_n is the mode-wise order of occupations, not the order of the total charge: in M_{2^n}(R) the charge-k part (ad N = k)
             has dimension C(2n, n+k); the incidence algebra of bd·mjp·4 has charge-k part C(n,k) 2^(n-k) (sum 3^n); the non-negative-charge
             subalgebra has dimension (4^n + C(2n,n))/2, larger than 3^n for n >= 2 (it holds the hopping c_i^+ c_j, charge 0) (n = 1..6).
  bd·mjp·13  label vectors alpha_a = sum_{i in a} e_i (grade 1, bit rule): alpha_a^2 = |a| in Cl(n,0); for disjoint a, b, alpha_a alpha_b = -alpha_b alpha_a
             and alpha_{a+b}^2 = alpha_a^2 + alpha_b^2 (Pythagoras).  So (9) holds with ||a|| = alpha_a^2 and then (13) f^2 = ||f||^2 holds on the
             n one-bit labels only (it fails for |a| >= 2), while ||a|| = sqrt(alpha_a^2) violates (9) on every disjoint pair of non-zero labels
             (n <= 6); that weight satisfies (13) by its definition, which is not counted.  In Cl(1,3) alpha_a^2 <= 0 on 14 of the 15 non-zero
             labels (3 of them null): a positive weight needs the squares +1.
  bd·mjp·14  Koenigsberg with the land masses as objects and the bridges as arrows (free category on the multigraph, degrees 5, 3, 3, 3): no walk
             crosses each bridge once; the shortest walk that crosses every bridge has 8 crossings, one bridge twice (exhaustive search).
  bd·mjp·15  Koenigsberg with the bridges as objects (the paper's Example 1): if consecutive bridges need only share a land mass, a path through
             all seven bridges once exists (a Hamiltonian path of the line graph); with oriented crossings as objects (leave a bridge on the
             other side) none exists and the shortest covering path has 8 crossings: the objects must carry the side.
"""
import sys, itertools
from math import comb, factorial
import numpy as np

SAB = '--sabotage' in sys.argv
ROWS, FAILS = [], []
def report(cid, ok, text, short):
    ROWS.append(cid)
    if SAB:
        print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  ' + short + '\n       the sabotaged run computes: ' + text)
        if ok: FAILS.append(cid)
    else:
        print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
        if not ok: FAILS.append(cid)
def finish():
    if SAB:
        print('\n' + ('ALL CAUGHT' if not FAILS else f'{len(FAILS)} MISSED: ' + ' '.join(FAILS)))
    else:
        print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def nullity(rows, ncols):
    if not rows: return ncols
    M = np.array(rows, dtype=float)
    return int(ncols - np.linalg.matrix_rank(M))

# ---------------------------------------------------------------- bd·mjp·9
def check9(sab):
    dims = []; ok = True
    for n in range(0, 7):
        D = 1 << n; rows = []
        for a in range(D):
            for b in range(D):
                if sab or (a & b) == 0:                 # sabotage: the sum defined on every pair (XOR, a group)
                    r = [0] * D; r[a ^ b] += 1; r[a] -= 1; r[b] -= 1
                    rows.append(r)
        d = nullity(rows, D); dims.append(d); ok &= d == n
    rng = np.random.default_rng(9)
    n = 5; D = 1 << n
    q = rng.integers(1, 9, size=n)
    h = np.array([sum(q[i] for i in range(n) if a >> i & 1) for a in range(D)])
    # the bit-rule creation operators (left multiplication by e_i in Lambda(R^n), the Jordan-Wigner signs) and the number operators n_i = c_i^+ c_i
    cps = []
    for i in range(n):
        C = np.zeros((D, D), dtype=np.int64)
        for S in range(D):
            if not S >> i & 1: C[S | (1 << i), S] = sgn(1 << i, S, [0] * n)
        cps.append(C)
    nums = [C @ C.T for C in cps]
    H0 = sum(int(q[i]) * nums[i] for i in range(n))
    E0 = np.diag(H0)
    spec_ok = not (H0 - np.diag(E0)).any() and np.array_equal(E0, h)
    add_ok = all(E0[a ^ b] == E0[a] + E0[b] for a in range(D) for b in range(D) if not a & b)
    U = 3
    H = H0 + U * nums[0] @ nums[1]
    E = np.diag(H)
    defect = E[3] - E[1] - E[2]
    int_ok = not (H - np.diag(E)).any()
    rand_add = 0
    for _ in range(200):
        f = rng.integers(-5, 6, size=D); f[0] = 0
        rand_add += all(f[a ^ b] == f[a] + f[b] for a in range(D) for b in range(D) if not a & b)
    ok &= spec_ok and add_ok and int_ok and defect == U and rand_add == 0
    return ok, (f'dimension of the +-additive weights on the labels for n = 0..6: {[int(x) for x in dims]} (= n: the charges q_i)' +
                (' [sum on every pair: a group, no real additive weight but 0]' if sab else '') +
                f'; n = 5, q = {[int(x) for x in q]}: sum q_i c_i^+ c_i (bit-rule creation operators) is diagonal with diagonal h_q: {spec_ok}, '
                f'its spectrum satisfies (9): {add_ok}; with U c_0^+ c_0 c_1^+ c_1 (U = {U}) diagonal: {int_ok}, the defect of (9) on '
                f'({{0}},{{1}}) is {int(defect)}; random functions additive in {rand_add}/200')

# ---------------------------------------------------------------- bd·mjp·10
def additive_dim_poset(elems, leq):
    arrows = [(x, y) for x in elems for y in elems if leq(x, y)]
    idx = {a: k for k, a in enumerate(arrows)}
    rows = []
    for x in elems:
        r = [0] * len(arrows); r[idx[(x, x)]] = 1; rows.append(r)
    for (x, y) in arrows:
        for z in elems:
            if x != y and y != z and leq(y, z):
                r = [0] * len(arrows); r[idx[(x, z)]] += 1; r[idx[(x, y)]] -= 1; r[idx[(y, z)]] -= 1; rows.append(r)
    return nullity(rows, len(arrows)), arrows, idx, rows
def check10(sab):
    dims = []; lab = []; ok = True
    for n in range(1, 6):
        D = 1 << n
        if not sab:
            d, arrows, idx, rows = additive_dim_poset(list(range(D)), lambda x, y: (x & y) == x)
            # add: weight depends only on the label T\S
            rows2 = list(rows)
            for (x, y) in arrows:
                for (u, v) in arrows:
                    if (y ^ x) == (v ^ u) and (x, y) < (u, v):
                        r = [0] * len(arrows); r[idx[(x, y)]] += 1; r[idx[(u, v)]] -= 1; rows2.append(r)
            dl = nullity(rows2, len(arrows))
        else:                                            # sabotage: the free category on the Hasse diagram (squares do not commute)
            if n > 4: continue
            paths = [(S,) for S in range(D)]
            frontier = list(paths)
            while frontier:
                longer = []
                for p in frontier:
                    for i in range(n):
                        if not p[-1] >> i & 1: longer.append(p + (p[-1] | (1 << i),))
                paths += longer; frontier = longer
            pidx = {p: k for k, p in enumerate(paths)}
            rows = []
            for p in paths:
                if len(p) == 1: r = [0] * len(paths); r[pidx[p]] = 1; rows.append(r)
            for p in paths:
                for q in paths:
                    if len(p) > 1 and len(q) > 1 and p[-1] == q[0]:
                        r = [0] * len(paths); r[pidx[p + q[1:]]] += 1; r[pidx[p]] -= 1; r[pidx[q]] -= 1; rows.append(r)
            d = nullity(rows, len(paths)); dl = n
        dims.append(int(d)); lab.append(int(dl))
        ok &= d == D - 1 and dl == n
    rng = np.random.default_rng(10); gen_ok = 0; pot = 0; seen = []
    for m in (8, 16):
        for _ in range(100):
            R = np.zeros((m, m), dtype=bool)
            p = rng.uniform(0.05, 0.4)
            for i in range(m):
                for j in range(i + 1, m):
                    R[i, j] = rng.random() < p
            for k in range(m):                            # transitive closure
                R = R | (R[:, [k]] & R[[k], :])
            leq = lambda x, y: x == y or bool(R[x, y])
            d, *_ = additive_dim_poset(list(range(m)), leq)
            # components of the comparability graph and the first Betti number of the order complex (chains as simplices)
            comp = list(range(m))
            def find(x):
                while comp[x] != x: x = comp[x]
                return x
            for i in range(m):
                for j in range(m):
                    if R[i, j]: comp[find(i)] = find(j)
            ncomp = len({find(i) for i in range(m)})
            edges = [(i, j) for i in range(m) for j in range(m) if R[i, j]]
            eidx = {e: k for k, e in enumerate(edges)}
            tris = [(i, j, k) for (i, j) in edges for k in range(m) if R[j, k]]
            d1 = np.zeros((m, len(edges)))
            for k, (i, j) in enumerate(edges): d1[j, k] += 1; d1[i, k] -= 1
            d2 = np.zeros((len(edges), max(1, len(tris))))
            for t, (i, j, k) in enumerate(tris):
                d2[eidx[(j, k)], t] += 1; d2[eidx[(i, k)], t] -= 1; d2[eidx[(i, j)], t] += 1
            r1 = np.linalg.matrix_rank(d1) if edges else 0
            r2 = np.linalg.matrix_rank(d2) if tris else 0
            b1 = len(edges) - r1 - r2
            gen_ok += d == m - ncomp + b1
            pot += d == m - ncomp
            if b1 > 0 and len(seen) < 3: seen.append((m, d, ncomp, int(b1)))
    ok &= gen_ok == 200 and pot < 200
    return ok, (f'composition-additive weights on B_n, n = 1..5: dimensions {dims} (2^n - 1: potentials E(T) - E(S)); those depending only on T\\S: {lab} (= n)'
                + (' [free category on the Hasse diagram: one weight per edge]' if sab else '') +
                f'; random posets (seed 10): dimension = elements - components (potentials only) in {pot}/200, = elements - components + b1 '
                f'(b1 of the order complex) in {gen_ok}/200; e.g. (size, dim, components, b1) {seen}')

# ---------------------------------------------------------------- bd·mjp·11
def cl_mul_factory(eps):
    m = len(eps); D = 1 << m
    POP = np.array([pc(k) for k in range(D)])
    A = np.arange(D)[:, None]; B = np.arange(D)[None, :]
    N = np.zeros((D, D), dtype=np.int64)
    for i in range(m): N += ((A >> i) & 1) * POP[B & ((1 << i) - 1)]
    S = np.where(N % 2 == 0, 1, -1)
    for i in range(m): S = np.where((((A >> i) & 1) & ((B >> i) & 1)) == 1, S * eps[i], S)
    idx = np.arange(D)
    def mul(x, y):
        z = np.zeros(D)
        for a in np.nonzero(x)[0]: z[a ^ idx] += x[a] * S[a] * y
        return z
    return mul, D
def check11(sab):
    msgs = []; ok = True
    for n in (2, 3):
        m = 2 * n; mul, D = cl_mul_factory([1] * n + [-1] * n)
        def gen(k):
            v = np.zeros(D); v[1 << k] = 1.0; return v
        one = np.zeros(D); one[0] = 1.0
        Ns = set(); Ps = set(); count = 0
        pairings = [((tuple(range(n))), tuple([1] * n))] * (factorial(n) * 2 ** n) if sab else \
                   [(sig, tau) for sig in itertools.permutations(range(n)) for tau in itertools.product([1, -1], repeat=n)]
        for sig, tau in pairings:                         # sabotage: the same pairing every time
            ap = [(gen(i) + tau[i] * gen(n + sig[i])) / 2 for i in range(n)]
            am = [(gen(i) - tau[i] * gen(n + sig[i])) / 2 for i in range(n)]
            car = all(np.array_equal(mul(am[i], ap[j]) + mul(ap[j], am[i]), one if i == j else 0 * one) for i in range(n) for j in range(n))
            Nop = sum(mul(ap[i], am[i]) for i in range(n))
            P = one.copy()
            for i in range(n): P = mul(P, one - 2 * mul(ap[i], am[i]))
            Ns.add(tuple(np.round(Nop * 4).astype(int))); Ps.add(tuple(np.abs(np.round(P * 4)).astype(int)))
            top = np.zeros(D); top[D - 1] = 1.0
            ok &= car and (np.array_equal(P, top) or np.array_equal(P, -top))
            count += 1
        good = len(Ns) == factorial(n) * 2 ** n and len(Ps) == 1
        ok &= good
        msgs.append(f'n={n}: {count} pairings, {len(Ns)} distinct N (n! 2^n = {factorial(n) * 2 ** n}), {len(Ps)} parity up to sign (= +- top blade)')
    return ok, 'Witt pairings of the same generators of the bit-rule Cl(n,n): ' + '; '.join(msgs) + '; CAR hold for each'

# ---------------------------------------------------------------- bd·mjp·12
def check12(sab):
    ok = True; rows = []
    for n in range(1, 7):
        D = 1 << n
        ch = {}; inc = {}; nonneg = 0
        for T in range(D):
            for S in range(D):
                k = pc(T) - pc(S)                            # E_{T,S} is an eigenvector of ad N with eigenvalue |T| - |S|
                ch[k] = ch.get(k, 0) + 1
                inb = (pc(S) <= pc(T)) if sab else ((S & T) == S)   # sabotage: the total-charge order in place of inclusion
                if inb: inc[k] = inc.get(k, 0) + 1
                if k >= 0: nonneg += 1
        okn = all(ch[k] == comb(2 * n, n + k) for k in range(-n, n + 1)) and \
              all(inc.get(k, 0) == comb(n, k) * 2 ** (n - k) for k in range(0, n + 1)) and sum(inc.values()) == 3 ** n and \
              nonneg == (4 ** n + comb(2 * n, n)) // 2 and (n < 2 or nonneg > 3 ** n)
        ok &= okn
        rows.append(f'n={n}: incidence algebra {sum(inc.values())}, charge >= 0: {nonneg}')
    return ok, ('charge grading of M_{2^n}(R) by ad N: dim C(2n, n+k); the incidence algebra (S subset T) has charge-k part C(n,k) 2^(n-k); ' + ', '.join(rows) +
                ' (the extra part holds the hopping c_i^+ c_j: not arrows of B_n)')

# ---------------------------------------------------------------- bd·mjp·13
def check13(sab):
    ok = True; info = []
    for n in range(1, 7):
        eps = [1] * n
        mul, D = cl_mul_factory(eps)
        def vec(a):
            v = np.zeros(D)
            for i in range(n):
                if a >> i & 1: v[1 << i] = 1.0
            return v
        def sq(a):
            v = vec(a); return mul(v, v)
        sq_ok = all(np.allclose(sq(a), np.eye(D)[0] * pc(a)) for a in range(1 << n))
        anti = pyth = n9 = n13 = n9s = tot = 0
        for a in range(1, 1 << n):
            for b in range(1, 1 << n):
                if a & b: continue
                va, vb = vec(a), vec(b)
                if sab: vb = vb + vec(a & -a) * 0.5          # sabotage: b's vector tilted towards a (not orthogonal)
                tot += 1
                anti += np.allclose(mul(va, vb), -mul(vb, va))
                s_ab = mul(va + vb, va + vb)[0]
                pyth += np.isclose(s_ab, mul(va, va)[0] + mul(vb, vb)[0])
                w = lambda x: mul(x, x)[0]
                n9 += np.isclose(w(va + vb), w(va) + w(vb))                      # (9) with ||a|| = alpha^2
                n9s += np.isclose(np.sqrt(w(va + vb)), np.sqrt(w(va)) + np.sqrt(w(vb)))   # (9) with ||a|| = |alpha|
        for a in range(1, 1 << n):
            w = mul(vec(a), vec(a))[0]
            n13 += np.isclose(w, w ** 2)                   # (13) f^2 = ||f||^2 with ||f|| = f^2
        good = sq_ok and anti == tot and pyth == tot and n9 == tot and n9s == 0 and n13 == n
        ok &= good
        info.append(f'n={n}: {tot} disjoint pairs, anticommute {anti}, Pythagoras {pyth}, (9) with alpha^2 {n9}, with |alpha| {n9s}; (13) with alpha^2 on {n13}/{(1 << n) - 1} labels')
    # Lorentzian control: Cl(1,3)
    mul, D = cl_mul_factory([1, -1, -1, -1])
    vals = []
    for a in range(1, 16):
        v = np.zeros(D)
        for i in range(4):
            if a >> i & 1: v[1 << i] = 1.0
        vals.append(mul(v, v)[0])
    nonpos = sum(1 for x in vals if x <= 0); null = sum(1 for x in vals if x == 0)
    ok &= nonpos == 14 and null == 3
    return ok, ('label vectors in Cl(n,0): alpha_a^2 = |a|; ' + '; '.join(info[-2:]) + f' (all n = 1..6 pass: {ok}); Cl(1,3): alpha_a^2 <= 0 on {nonpos} of 15 labels, null on {null}')

# ---------------------------------------------------------------- Koenigsberg
LAND = 'ABCD'
BRIDGES = [('A', 'B'), ('A', 'B'), ('A', 'C'), ('A', 'C'), ('A', 'D'), ('B', 'D'), ('C', 'D')]
def walks(bridges):
    """shortest walk (number of crossings) that crosses every bridge at least once; and whether a walk crossing each exactly once exists"""
    m = len(bridges); full = (1 << m) - 1
    from collections import deque
    best = None; euler = False
    for start in LAND:
        dist = {(start, 0): 0}; dq = deque([(start, 0)])
        while dq:
            v, used = dq.popleft()
            d = dist[(v, used)]
            if used == full:
                if best is None or d < best: best = d
                if d == m: euler = True
                continue
            for k, (x, y) in enumerate(bridges):
                if v in (x, y):
                    w = y if v == x else x
                    st = (w, used | (1 << k))
                    if st not in dist:
                        dist[st] = d + 1; dq.append(st)
    return best, euler
def check14(sab):
    br = BRIDGES + ([('B', 'C')] if sab else [])           # sabotage: an eighth bridge B-C (two odd land masses left)
    deg = {L: sum(L in b for b in br) for L in LAND}
    best, euler = walks(br)
    ok = best == len(br) + 1 and not euler and sorted(deg.values()) == [3, 3, 3, 5]
    return ok, (f'{len(br)} bridges, degrees {deg}: a walk crossing each bridge once exists: {euler}; the shortest walk crossing every bridge has '
                f'{best} crossings (bridges + {best - len(br)})')
def ham_path_exists(nodes, adj):
    for start in nodes:
        stack = [(start, 1 << nodes.index(start))]
        full = (1 << len(nodes)) - 1
        seen = set()
        while stack:
            v, used = stack.pop()
            if used == full: return True
            if (v, used) in seen: continue
            seen.add((v, used))
            for w in adj[v]:
                bit = 1 << nodes.index(w)
                if not used & bit: stack.append((w, used | bit))
    return False
def check15(sab):
    m = len(BRIDGES); nodes = list(range(m))
    adj = {k: [j for j in nodes if j != k and set(BRIDGES[k]) & set(BRIDGES[j])] for k in nodes}
    ham = ham_path_exists(nodes, adj)
    # oriented crossings: (k, side): cross bridge k arriving at side; next crossing must leave from that side
    crossings = [(k, s) for k in nodes for s in (0, 1)]          # s: index of the arrival end in BRIDGES[k]
    def arrive(c): return BRIDGES[c[0]][c[1]]
    def depart(c): return BRIDGES[c[0]][1 - c[1]]
    if sab:                                                  # sabotage: forget the side (any crossing may follow any crossing at a shared land mass)
        nxt = {c: [d for d in crossings if d[0] != c[0] and set(BRIDGES[c[0]]) & set(BRIDGES[d[0]])] for c in crossings}
    else:
        nxt = {c: [d for d in crossings if d[0] != c[0] and depart(d) == arrive(c)] for c in crossings}
    # a path visiting each bridge exactly once (one orientation each)
    found = False
    stack = [(c, 1 << c[0]) for c in crossings]
    while stack and not found:
        c, used = stack.pop()
        if used == (1 << m) - 1: found = True; break
        for d in nxt[c]:
            if not used >> d[0] & 1: stack.append((d, used | (1 << d[0])))
    # shortest covering path in the oriented-crossing category (objects visited, bridges may repeat)
    from collections import deque
    best = None
    dist = {}; dq = deque()
    for c in crossings: dist[(c, 1 << c[0])] = 1; dq.append((c, 1 << c[0]))
    while dq:
        c, used = dq.popleft(); d = dist[(c, used)]
        if used == (1 << m) - 1:
            best = d if best is None else min(best, d); continue
        for e in (nxt[c] + ([x for x in crossings if x[0] == c[0] and x != c and depart(x) == arrive(c)] if not sab else [])):
            st = (e, used | (1 << e[0]))
            if st not in dist: dist[st] = d + 1; dq.append(st)
    ok = ham and not found and best == m + 1
    return ok, (f'bridges as objects, consecutive bridges sharing a land mass: a path through all seven once exists: {ham}; '
                f'oriented crossings as objects (leave on the arrival side): a path with each bridge once exists: {found}; shortest covering path: {best} crossings')

CHECKS = [('bd·mjp·9', check9, 'additive weights on (labels, +) are the n charges'),
          ('bd·mjp·10', check10, 'composition-additive weights on B_n are the 2^n - 1 potentials; label-only ones are the charges'),
          ('bd·mjp·11', check11, 'Witt pairings: n! 2^n number operators, one parity'),
          ('bd·mjp·12', check12, 'the order of B_n is mode-wise: the incidence algebra is smaller than charge >= 0'),
          ('bd·mjp·13', check13, 'label vectors: Pythagoras on disjoint labels; (9) with alpha^2 holds, (13) then only on one-bit labels'),
          ('bd·mjp·14', check14, 'Koenigsberg: no Euler walk, shortest covering walk 8 = 7 + 1'),
          ('bd·mjp·15', check15, 'bridges as objects need the side to keep Euler\'s constraint')]

def main():
    for cid, f, short in CHECKS:
        ok, text = f(SAB)
        report(cid, ok, text, short)
    finish()

if __name__ == '__main__':
    main()
