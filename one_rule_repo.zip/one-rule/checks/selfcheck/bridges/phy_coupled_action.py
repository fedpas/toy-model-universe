#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""phy_coupled_action.py: one action for the Dirac and the Maxwell equation of the coupling step (step 6), and the sign of the source.

In Hestenes' Cl(1,3) (gamma0^2 = +1) the coupling term L_int = -e <A psi gamma0 psi~>_0 = -e A.X is added to the free Dirac and Maxwell
Lagrangians, and the Euler-Lagrange equations of the single action
    L = <grad psi I gamma3 psi~>_0 - m <psi psi~>_0 - e <A psi gamma0 psi~>_0 + (1/2) <F F>_0,   F = grad ^ A,
are compared with the two equations of the coupling step.

  bd·phy·18  the psi-equation: EL_psi = T . (grad psi I sigma3 - e A psi - m psi gamma0) with the same invertible T (|det T| = 256) as in the
             free case, for 50 random (psi, d psi, A, e) at m = 0.83: the coupling term -e A psi of the Dirac equation is the Euler-Lagrange
             image of L_int.
  bd·phy·19  the A-equation: EL_A = c . (grad F - e X)_1 with one constant c (c = 1 here) for 30 random quadratic potentials, psi and e;
             flipping the sign of L_int flips the coupling term in both equations with the same c.  So, with the coupling term -e A psi in
             the Dirac equation, the source of the Maxwell equation is +e X: the relative sign is fixed by the action, and what remains is
             the size |e| and the overall sign of the F^2 term (the positivity of the field energy, standard).

  python3 phy_coupled_action.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic (seed 3); about two seconds."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))          # phy_bitrule.py sits next to this script
import numpy as np
from phy_bitrule import Alg, Reporter

def main():
    R = Reporter()
    rng = np.random.default_rng(3)
    A = Alg.pq(1, 3)
    g = [A.blade(1 << i) for i in range(4)]
    gup = [g[0], -g[1], -g[2], -g[3]]                     # reciprocal frame: gamma^0 = gamma0, gamma^k = -gamma_k
    I = A.blade(15)
    sig3 = A.mul(g[3], g[0])                               # sigma3 = gamma3 gamma0
    Isig3 = A.mul(I, sig3)
    Ig3 = A.mul(I, g[3])
    EVEN = [m for m in range(16) if A.grade[m] % 2 == 0]; ODD = [m for m in range(16) if A.grade[m] % 2 == 1]
    sc = lambda x: float(x[0])
    def mv(c, labels):
        x = np.zeros(16)
        for k, a in enumerate(labels):
            x[a] = c[k]
        return x
    def vecv(c):
        return A.vec(c)
    # quadratic forms of the Dirac Lagrangian: L_D = sum_mu dpsi_mu^T B_mu psi - m psi^T S psi - e psi^T C(A) psi
    B = np.zeros((4, 8, 8)); S = np.zeros((8, 8))
    for mu in range(4):
        for i, a in enumerate(EVEN):
            for j, b in enumerate(EVEN):
                B[mu, i, j] = sc(A.mul(A.mul(A.mul(gup[mu], A.blade(a)), Ig3), A.reverse(A.blade(b))))
    for i, a in enumerate(EVEN):
        for j, b in enumerate(EVEN):
            S[i, j] = sc(A.mul(A.blade(a), A.reverse(A.blade(b))))
    def Cmat(Av):
        C = np.zeros((8, 8))
        for i, a in enumerate(EVEN):
            for j, b in enumerate(EVEN):
                C[i, j] = sc(A.mul(A.mul(A.mul(Av, A.blade(a)), g[0]), A.reverse(A.blade(b))))
        return C
    # free case: T from a basis of (psi, dpsi)
    m = 0.83
    def EL_free(psi, dpsi):
        return sum((B[mu].T - B[mu]) @ dpsi[mu] for mu in range(4)) - 2 * m * (S @ psi)
    def D_free(psi, dpsi):
        D = sum(A.mul(gup[mu], A.mul(mv(dpsi[mu], EVEN), Isig3)) for mu in range(4)) - m * A.mul(mv(psi, EVEN), g[0])
        return np.array([D[a] for a in ODD])
    n = 40
    def basis(k):
        v = np.zeros(n); v[k] = 1; return v[:8], v[8:].reshape(4, 8)
    ELm = np.array([EL_free(*basis(k)) for k in range(n)]).T
    Dm = np.array([D_free(*basis(k)) for k in range(n)]).T
    T = ELm @ np.linalg.pinv(Dm)
    free_ok = np.abs(ELm - T @ Dm).max() < 1e-10 and abs(abs(np.linalg.det(T)) - 256) < 1e-6
    # coupled psi-equation
    ok18 = free_ok
    for _ in range(50):
        psi = rng.normal(size=8); dpsi = rng.normal(size=(4, 8)); Av = vecv(rng.normal(size=4)); e = rng.normal()
        C = Cmat(Av)
        EL = EL_free(psi, dpsi) - e * (C + C.T) @ psi
        D = sum(A.mul(gup[mu], A.mul(mv(dpsi[mu], EVEN), Isig3)) for mu in range(4)) - e * A.mul(Av, mv(psi, EVEN)) - m * A.mul(mv(psi, EVEN), g[0])
        Dv = np.array([D[a] for a in ODD])
        ok18 &= np.abs(EL - T @ Dv).max() < 1e-9
    R('bd·phy·18', ok18, 'the Euler-Lagrange equation of L_D - e<A psi gamma0 psi~> equals T.(grad psi I sigma3 - e A psi - m psi gamma0) with the T of the free case (|det T| = 256) in 50 random cases: '
      'the coupling term of the Dirac equation of step 6 is the image of L_int')

    # A-equation.  L_EM = (1/2) <F F>_0 with F = grad ^ A: quadratic form in the 16 numbers dA[mu][nu] = d_mu A_nu.
    def F_of(dA):
        F = np.zeros(16)
        for mu in range(4):
            dAmu = vecv(dA[mu])
            prod = A.mul(gup[mu], dAmu)
            F += A.grade_part(prod, 2)
        return F
    M = np.zeros((16, 16))
    for p in range(16):
        for q in range(16):
            ep = np.zeros(16); ep[p] = 1; eq = np.zeros(16); eq[q] = 1
            Fp = F_of(ep.reshape(4, 4)); Fq = F_of(eq.reshape(4, 4))
            M[p, q] = sc(A.mul(Fp, Fq))
    M = (M + M.T) / 2                                         # L_EM = (1/2) dA^T M dA
    ratios = set(); ok19 = True; flip_ok = True
    for _ in range(30):
        # quadratic potential A_nu(x) = (1/2) sum_{lam, rho} h[nu, lam, rho] x_lam x_rho (h symmetric in lam, rho); at x = 0: dA = 0, d_lam d_rho A_nu = h
        h = rng.normal(size=(4, 4, 4)); h = (h + h.transpose(0, 2, 1)) / 2
        psi = rng.normal(size=8); e = rng.normal()
        X = A.mul(A.mul(mv(psi, EVEN), g[0]), A.reverse(mv(psi, EVEN)))      # the current, grade 1
        Xc = np.array([X[1 << nu] for nu in range(4)])
        # EL_A^nu = dL/dA_nu - d_mu dL/d(d_mu A_nu) at x = 0 = -e X_nu(lower index? see below) - sum_mu d_mu (M dA)_{(mu nu)}
        # dL_int/dA_nu: L_int = -e <A X>_0 = -e sum_nu A_nu X^nu eta_nunu  (A = A_nu gamma^nu? here A = sum A_nu gamma_nu with the vec() basis)
        # keep it uniform: A = sum_nu a_nu gamma_nu, X = sum X_nu gamma_nu, <A X>_0 = sum eta_nunu a_nu X_nu
        eta = np.array([1.0, -1, -1, -1])
        dLint = -e * eta * Xc
        # d_mu of (M dA)_{(mu,nu)} with dA_{(lam,rho)}(x) = sum_rho' h[rho, lam, rho'] x_rho'  -> d_mu dA_{(lam,rho)} = h[rho, lam, mu]
        ELA = np.zeros(4)
        for nu in range(4):
            tot = 0.0
            for mu in range(4):
                for lam in range(4):
                    for rho in range(4):
                        tot += M[mu * 4 + nu, lam * 4 + rho] * h[rho, lam, mu]
            ELA[nu] = dLint[nu] - tot
        # grad F at x = 0 from the second derivatives: grad F = sum_mu gamma^mu d_mu F, F = sum_lam <gamma^lam (d_lam A)>_2
        gradF = np.zeros(16)
        for mu in range(4):
            dF = np.zeros(16)
            for lam in range(4):
                ddA = vecv(h[:, lam, mu])                      # d_mu d_lam A as a vector with components h[nu, lam, mu]
                dF += A.grade_part(A.mul(gup[lam], ddA), 2)
            gradF += A.mul(gup[mu], dF)
        rhs = A.grade_part(gradF, 1) - e * X
        rhsc = np.array([rhs[1 << nu] for nu in range(4)])
        # compare ELA (index-lowered gradient: dL/dA_nu) with eta * rhs components
        cand = eta * rhsc
        if np.abs(cand).max() > 1e-9:
            c = (ELA @ cand) / (cand @ cand)
            ok19 &= np.abs(ELA - c * cand).max() < 1e-9
            ratios.add(round(float(c), 6))
        # flipping the sign of L_int flips the coupling term in both equations: the relative sign is tied
        dLint2 = +e * eta * Xc
        ELA2 = ELA - dLint + dLint2
        rhs2 = A.grade_part(gradF, 1) + e * X
        cand2 = eta * np.array([rhs2[1 << nu] for nu in range(4)])
        c2 = (ELA2 @ cand2) / (cand2 @ cand2)
        flip_ok &= np.abs(ELA2 - c2 * cand2).max() < 1e-9 and abs(c2 - c) < 1e-9
    R('bd·phy·19', ok19 and len(ratios) == 1 and flip_ok,
      'the Euler-Lagrange equation of (1/2)<F F> - e<A X> in A equals c.(grad F - e X) with the single constant c = %s for 30 random quadratic potentials, psi, e; '
      'flipping L_int flips the coupling term in both equations with the same c: the sign of the source is fixed by the action, only |e| and the overall sign of the F^2 term (field-energy positivity) remain' % sorted(ratios))
    R.finish()

if __name__ == '__main__':
    main()
