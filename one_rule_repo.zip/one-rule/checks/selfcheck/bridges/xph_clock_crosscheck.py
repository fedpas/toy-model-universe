#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""xph_clock_crosscheck.py: three physics readings of the clock are one function of c = p - q mod 8.

The clock reads as the pair (T^2, T commutes / anticommutes with the fermion parity P) of a Majorana edge (bd·sol·2), as the type of the even
part Cl^0 (2R, C, 2H, C for s - t = 0, 2, 4, 6; bd·str·6) and as the Dyson class of a parity sector of a random even Hamiltonian (GOE, GUE, GSE,
GUE; bd·str·20).  Here both invariants are computed again, independently (own Jordan-Wigner Majoranas, own bit-rule Frobenius-Schur count),
for every (p,q) with n even <= 8, and compared through the standard map: (T^2 = +1, [T,P] = 0) <-> 2R <-> GOE; (T anticommutes with P) <-> C
<-> GUE; (T^2 = -1, [T,P] = 0) <-> 2H <-> GSE.

  bd·xph·1  for every (p,q), n even <= 8: the Majorana-edge pair (T^2, [T,P]) and the even-part type agree with the map above and depend on c
            only; the table is c = 0: (+1, commute, 2R); 2: (+1, anti, C); 4: (-1, commute, 2H); 6: (-1, anti, C).
  bd·xph·2  for Cl(N,0), N = 8, 10, 12, 14, 16, the even-part type is 2R, C, 2H, C, 2R, i.e. the Dyson classes GOE, GUE, GSE, GUE, GOE that
            bd·str·20 finds numerically for the Majorana SYK model.

  python3 xph_clock_crosscheck.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; under a second."""
import itertools, sys
import numpy as np

def popcount(x):
    return bin(x).count('1')

def reorder_sign(a, b):
    s = 0; a2 = a >> 1
    while a2:
        s += popcount(a2 & b); a2 >>= 1
    return -1 if s & 1 else 1

def sign(a, b, eps):
    s = reorder_sign(a, b); c = a & b; i = 0
    while c:
        if c & 1:
            s *= eps[i]
        c >>= 1; i += 1
    return s

ROWS, FAILS = [], []
def report(cid, ok, text):
    ROWS.append(cid)
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    if not ok:
        FAILS.append(cid)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

X = np.array([[0, 1], [1, 0]], complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
def kron_all(ops):
    out = np.array([[1.0 + 0j]])
    for o in ops:
        out = np.kron(out, o)
    return out

def majoranas(n):
    """2m Jordan-Wigner Majoranas on m qubits: gamma_{2j} = Z..Z X I.., gamma_{2j+1} = Z..Z Y I..; all square to 1, anticommute"""
    m = n // 2; g = []
    for j in range(m):
        g.append(kron_all([Z] * j + [X] + [I2] * (m - j - 1)))
        g.append(kron_all([Z] * j + [Y] + [I2] * (m - j - 1)))
    return g

def even_part_type(p, q):
    """type of Cl^0(p,q), n = p + q even: from the square of the top blade (central in the even part) and the Frobenius-Schur
    count over the even blades (sum of squares of the even blades): omega^2 = -1 -> C; else 2R if the count is positive, 2H if negative"""
    eps = [1] * p + [-1] * q; n = p + q; top = (1 << n) - 1
    if sign(top, top, eps) == -1:
        return 'C'
    nu = sum(sign(a, a, eps) for a in range(1 << n) if popcount(a) % 2 == 0)
    return '2R' if nu > 0 else '2H'

def edge_invariants(p, q):
    """find an antiunitary T = U K (U a product of Majoranas, K complex conjugation in the Fock basis) with p T-even and q T-odd
    Majoranas; return (T^2, +1 if T commutes with the parity P else -1)"""
    n = p + q; g = majoranas(n); m = n // 2
    P = kron_all([Z] * m)                              # fermion parity
    target = [1] * p + [-1] * q
    for S in itertools.product((0, 1), repeat=n):
        U = np.eye(1 << m, dtype=complex)
        for k in range(n):
            if S[k]:
                U = U @ g[k]
        # T gamma T^-1 = U conj(gamma) U^-1
        par = []
        for k in range(n):
            Tg = U @ g[k].conj() @ np.linalg.inv(U)
            if np.allclose(Tg, g[k]):
                par.append(1)
            elif np.allclose(Tg, -g[k]):
                par.append(-1)
            else:
                par.append(0)
        if sorted(par) == sorted(target) and 0 not in par:
            T2 = U @ U.conj()                          # T^2 = U K U K = U conj(U)
            t2 = 1 if np.allclose(T2, np.eye(1 << m)) else (-1 if np.allclose(T2, -np.eye(1 << m)) else 0)
            TP = U @ P.conj() @ np.linalg.inv(U)       # T P T^-1
            tp = 1 if np.allclose(TP, P) else (-1 if np.allclose(TP, -P) else 0)
            return t2, tp
    return None

def main():
    MAP = {(1, 1): '2R', (1, -1): 'C', (-1, -1): 'C', (-1, 1): '2H'}
    ok = True; table = {}
    for n in (2, 4, 6, 8):
        for p in range(n + 1):
            q = n - p; c = (p - q) % 8
            inv = edge_invariants(p, q)
            ty = even_part_type(p, q)
            good = inv is not None and MAP[inv] == ty
            ok &= good
            table.setdefault(c, set()).add((inv, ty))
    ok &= all(len(v) == 1 for v in table.values())
    txt = '; '.join('c=%d: T^2=%+d, %s, Cl^0 type %s' % (c, list(v)[0][0][0], 'commute' if list(v)[0][0][1] == 1 else 'anticommute', list(v)[0][1]) for c, v in sorted(table.items()))
    report('bd·xph·1', ok, 'for every (p,q) with n even <= 8 the edge pair (T^2, [T,P]) (bd·sol·2) and the even-part type (bd·str·6) match the standard map and depend on c only: ' + txt)
    want = {8: '2R', 10: 'C', 12: '2H', 14: 'C', 16: '2R'}
    dyson = {'2R': 'GOE', 'C': 'GUE', '2H': 'GSE'}
    got = {N: even_part_type(N, 0) for N in want}
    report('bd·xph·2', got == want, 'Cl(N,0), N = 8..16: even-part types ' + ', '.join('%d:%s(%s)' % (N, got[N], dyson[got[N]]) for N in sorted(got)) +
           ' = the Dyson classes GOE, GUE, GSE, GUE, GOE of the SYK sectors that bd·str·20 finds numerically')
    finish()

if __name__ == '__main__':
    main()
