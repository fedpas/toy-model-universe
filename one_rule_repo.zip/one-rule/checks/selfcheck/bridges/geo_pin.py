#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""geo_pin.py: the cell (V, Q, pi) read in spin geometry: the Pin extension class, Z_4 enhancements of the surface #^n RP^2 and their
Arf-Brown-Kervaire invariant, the null generators, and the Atiyah-Bott-Shapiro sequence.

  python3 selfcheck/bridges/geo_pin.py      one line per check, ids bd·geo·1 .. bd·geo·6; exit 1 on any FAIL

Standard library only, exact integers (Gaussian integers for the Gauss sums), deterministic, about 8 s; runs from any folder, reads and writes no file.
 bd·geo·1  Q of Cl(p,q) is sigma_2(a) + |a & N| mod 2 (N the negative generators), the restriction of the Pin extension class (w2 for Pin+,
           w2 + w1^2 for Pin-) to the reflection group Z_2^n, n <= 9; in the blade group {+-e_a} the commutator of e_a, e_b is the polar form of Q (n <= 6).
 bd·geo·2  w = pi + 2Q is a Z_4 enhancement of the dot product (the intersection form of #^n RP^2 in the crosscap basis), n <= 6, and its
           normalised Gauss sum is exp(2 pi i (p-q)/8) for every Cl(p,q), n <= 8: the clock is the Arf-Brown-Kervaire invariant (Debray-Gunningham,
           eq. 3.14); Cl(1,0) and Cl(0,1) are RP^2 with its two Pin- structures (ABK = +1, -1).
 bd·geo·3  the Z_4 enhancements of the dot product on F_2^n are exactly the 2^n forms w_eps, and the orbits of the isometry group of the dot product
           (even transvections and coordinate transpositions) on them are exactly the ABK classes, n <= 8.
 bd·geo·4  twisting an enhancement by a class a: beta(w + 2 a.x) = beta(w) - 2 w(a) mod 8; the mirror Q -> Q + pi is the twist by w1 = pi
           (characteristic vector 1...1) and beta = w(1...1) mod 4 (every Cl(p,q), n <= 7).
 bd·geo·5  null generators: w = pi + 2Q with pi counting every generator is not an enhancement when r >= 1 (smallest counterexample printed) and
           its Gauss sum on Cl(0,0,1) is 1 + i; the form w_D(a & D) with weight 0 on the null bits is an enhancement of the degenerate form |a & b & D|,
           with radical the null span, w = 0 there and Gauss sum 2^r G_D; putting w = 2 on one radical vector makes the Gauss sum 0 (n <= 6, every r).
 bd·geo·6  Atiyah-Bott-Shapiro: from the bit-rule types of Cl(0,k) and the swap of the two irreducibles by the next generator, the cokernels
           coker(M(Cl_k) -> M(Cl_{k-1})) are Z2, Z2, 0, Z, 0, 0, 0, Z for k = 1..8 (KO^{-k}(pt)); the clock of the same cells is another
           period-8 invariant (the Brauer-Wall class).
"""
import itertools, sys

ROWS = []
def row(cid, text, ok):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return ok
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

def pc(a): return bin(a).count('1')

def sgn(a, b, eps):
    """bit-rule sign s(a,b) (0 if a common generator is null)"""
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

def Q(a, eps): return 1 if sgn(a, a, eps) == -1 else 0
def pi_(a): return pc(a) % 2
def w4(a, eps): return (pi_(a) + 2 * Q(a, eps)) % 4

IP = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def gsum(vals):
    re = im = 0
    for k in vals:
        z = IP[k % 4]; re += z[0]; im += z[1]
    return (re, im)
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def gpow(x, k):
    r = (1, 0)
    for _ in range(k): r = gmul(r, x)
    return r
def phase8(z, n2):
    """z = 2^{n2/2} * zeta_8^k exactly: return k (or None)"""
    for k in range(8):
        # zeta_8^k * 2^{n2/2} = (1+i)^k / 2^{k/2} * 2^{n2/2}  -> compare (1+i)^k * 2^{(n2-k)/2}
        t = gpow((1, 1), k)
        e = n2 - k
        if e % 2 == 0:
            m = 2 ** (e // 2) if e >= 0 else None
            if m is not None and (t[0] * m, t[1] * m) == z: return k
            if e < 0 and (z[0] * 2 ** (-e // 2), z[1] * 2 ** (-e // 2)) == t: return k
        else:
            # odd: (1+i)^k 2^{e/2} = (1+i)^{k+1} 2^{(e-1)/2} / (1+i)... use z * (1+i) comparison
            zz = gmul(z, (1, 1))           # z (1+i) = 2^{n2/2} zeta^{k+1} sqrt2 = 2^{(n2+1)/2} zeta^{k+1}
            t2 = gpow((1, 1), k + 1); e2 = n2 + 1 - (k + 1)
            if e2 >= 0 and (t2[0] * 2 ** (e2 // 2), t2[1] * 2 ** (e2 // 2)) == zz: return k
    return None
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r

# ---------------------------------------------------------------- 1. Q is the Pin extension class on the reflection torus
def c1():
    ok = True; nchk = 0
    for n in range(1, 10):
        for p in range(n + 1):
            q = n - p; e = sig(p, q); N = ((1 << q) - 1) << p
            for a in range(1 << n):
                s2 = (pc(a) * (pc(a) - 1) // 2) % 2          # sigma_2 = number of pairs
                if Q(a, e) != (s2 + pc(a & N)) % 2: ok = False
                nchk += 1
    # the group {+-e_a}: squares and commutators are Q and its polar form (the extension data)
    ok2 = True
    for n in range(1, 7):
        for p in range(n + 1):
            e = sig(p, n - p)
            for a in range(1 << n):
                for b in range(1 << n):
                    comm = sgn(a, b, e) * sgn(b, a, e)        # e_a e_b = comm * e_b e_a
                    pol = (Q(a ^ b, e) + Q(a, e) + Q(b, e)) % 2
                    if comm != (-1) ** pol: ok2 = False
    row('bd·geo·1', f'Q_Cl(p,q)(a) = sigma_2(a) + |a & N| mod 2 for all {nchk} (cell, label) pairs, n <= 9: the pullback of w2 (Pin+, all eps = +1) '
        'or w2 + w1^2 (Pin-, all eps = -1; Kirby-Taylor Lemma 1.3 conventions) to the diagonal reflection group Z_2^n; and in {+-e_a} '
        'e_a e_b = (-1)^{polar Q(a,b)} e_b e_a (n <= 6): the finite Pin group of the frame is the central extension with class Q', ok and ok2)

# ---------------------------------------------------------------- 2. clock = ABK invariant of the Pin- surface
def c2():
    ok = True; table = []
    for n in range(1, 9):
        for p in range(n + 1):
            q = n - p; e = sig(p, q)
            # enhancement identity w(a+b) = w(a) + w(b) + 2 a.b
            if n <= 6:
                for a in range(1 << n):
                    for b in range(1 << n):
                        if (w4(a ^ b, e) - w4(a, e) - w4(b, e) - 2 * pc(a & b)) % 4: ok = False
                    if w4(a, e) % 2 != pc(a & a) % 2: ok = False        # w(x) = x.x mod 2 (w1 = pi)
            k = phase8(gsum([w4(a, e) for a in range(1 << n)]), n)
            if k != (p - q) % 8: ok = False
            if n == 1: table.append((p, q, k))
    rp2 = sorted(table) == [(0, 1, 7), (1, 0, 1)]
    row('bd·geo·2', 'w = pi + 2Q satisfies w(a+b) = w(a) + w(b) + 2 a.b and w = a.a mod 2 (n <= 6): a Z_4 enhancement of the intersection form of '
        '#^n RP^2 in the crosscap basis; the normalised Gauss sum is zeta_8^(p-q) for every Cl(p,q), n <= 8 (Debray-Gunningham eq. 3.14): '
        f'clock = ABK invariant in Omega_2^Pin- = Z_8; n = 1: {table} (RP^2 with its two Pin- structures, ABK = +1, -1)', ok and rp2)

# ---------------------------------------------------------------- 3. orbits of O(dot) on enhancements = ABK classes
def c3():
    ok = True; info = []
    for n in range(1, 9):
        # enhancement <-> its values on the standard basis (odd: 1 or 3) <-> eps
        def wtab(eps):
            return tuple(w4(a, eps) for a in range(1 << n))
        enh = {}
        for bits in range(1 << n):
            eps = [(-1 if bits >> i & 1 else 1) for i in range(n)]
            enh[wtab(eps)] = bits
        all_enh_count = len(enh)
        # every function w: F2^n -> Z4 with the enhancement identity is determined by w(e_i) in {1,3}: count = 2^n
        ok &= all_enh_count == (1 << n)
        # isometries of the dot product: transvections t_a(x) = x + (x.a) a with a.a = 0 (even a; in characteristic 2,
        # B(t x, t y) = B(x,y) + B(x,a) B(y,a) B(a,a)), and the transpositions of two coordinates
        gens = [('t', a) for a in range(1, 1 << n) if pc(a) % 2 == 0] + [('s', i) for i in range(n - 1)]
        def act(g, x):
            if g[0] == 't':
                a = g[1]
                return x ^ a if pc(x & a) % 2 else x
            i = g[1]; bi, bj = x >> i & 1, x >> (i + 1) & 1
            return (x & ~(3 << i)) | (bj << i) | (bi << (i + 1))
        for g in gens:                       # each generator preserves the dot product
            for x in range(1 << n):
                for y in range(1 << n):
                    if pc(act(g, x) & act(g, y)) % 2 != pc(x & y) % 2: ok = False
        # act on enhancement w by precomposition w o g^{-1} (transvections are involutions)
        keys = list(enh.keys()); idx = {k: i for i, k in enumerate(keys)}
        seen = [-1] * len(keys); orbit_beta = {}
        oid = 0
        for s in range(len(keys)):
            if seen[s] >= 0: continue
            stack = [s]; seen[s] = oid; betas = set()
            while stack:
                u = stack.pop(); wt = keys[u]
                betas.add(phase8(gsum(wt), n))
                for g in gens:
                    w2 = tuple(wt[act(g, x)] for x in range(1 << n))
                    v = idx.get(w2)
                    if v is None: ok = False; continue
                    if seen[v] < 0: seen[v] = oid; stack.append(v)
            orbit_beta[oid] = betas; oid += 1
        # each orbit has one beta, distinct orbits distinct betas
        bl = [tuple(sorted(b)) for b in orbit_beta.values()]
        ok &= all(len(b) == 1 for b in bl) and len(set(bl)) == len(bl)
        info.append((n, oid, sorted(b[0] for b in bl)))
    row('bd·geo·3', 'the Z_4 enhancements of the dot product on F_2^n are exactly the 2^n functions w_eps (eps in {+1,-1}^n), and the orbits of the '
        'group generated by the even transvections and the coordinate transpositions (isometries of dot) are exactly the ABK classes, n <= 8 (n, number of orbits, ABK values): ' + str(info) +
        ': (V, Q, pi) up to isomorphism = a Pin- structure on #^n RP^2 up to isometry of its enhancement = the clock (the classification of core·B6c, here for n <= 8)', ok)

# ---------------------------------------------------------------- 4. twisting by a class; the mirror is the twist by w1
def c4():
    ok = True
    for n in range(1, 8):
        for p in range(n + 1):
            e = sig(p, n - p)
            b0 = phase8(gsum([w4(x, e) for x in range(1 << n)]), n)
            for a in range(1 << n):
                tw = [(w4(x, e) + 2 * pc(x & a)) % 4 for x in range(1 << n)]
                b1 = phase8(gsum(tw), n)
                if b1 != (b0 - 2 * w4(a, e)) % 8: ok = False
            F = (1 << n) - 1
            mir = [(w4(x, e) + 2 * pi_(x)) % 4 for x in range(1 << n)]
            m = [-x for x in e]
            if mir != [w4(x, m) for x in range(1 << n)]: ok = False           # twist by w1 = mirror
            if (b0 - w4(F, e)) % 4: ok = False                              # beta = q(characteristic) mod 4
    row('bd·geo·4', 'for every Cl(p,q), n <= 7, and every class a: beta(w + 2 a.x) = beta(w) - 2 w(a) mod 8 (exact Gauss sums); the mirror Q -> Q + pi is the '
        'twist by the orientation character w1 = pi (characteristic vector 1...1) and beta = w(1...1) mod 4, so the twist sends beta to -beta '
        '(core·B4b in surface language: reversing the Pin- structure)', ok)

# ---------------------------------------------------------------- 5. null generators and the radical
def c5():
    # (a) literal w with pi counting all generators fails
    ce = None
    for n in range(1, 5):
        for p in range(n + 1):
            for q in range(n - p + 1):
                r = n - p - q
                if r == 0: continue
                e = sig(p, q, r)
                for a in range(1 << n):
                    for b in range(1 << n):
                        if (w4(a ^ b, e) - w4(a, e) - w4(b, e) - 2 * pc(a & b)) % 4:
                            if ce is None: ce = ((p, q, r), a, b, w4(a ^ b, e), w4(a, e), w4(b, e))
    e001 = [0]
    lit = gsum([w4(a, e001) for a in range(2)])
    okA = ce is not None and lit == (1, 1)
    # (b) pulled-back form
    okB = True
    for n in range(1, 7):
        for r in range(1, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); D = (1 << (p + q)) - 1
                eD = sig(p, q)
                wp = [w4(a & D, eD) for a in range(1 << n)]
                for a in range(1 << n):
                    for b in range(1 << n):
                        if (wp[a ^ b] - wp[a] - wp[b] - 2 * pc(a & b & D)) % 4: okB = False
                GD = gpow((1, 1), p); GD = gmul(GD, gpow((1, -1), q))
                if gsum(wp) != (GD[0] << r, GD[1] << r): okB = False
                # radical of |a & b & D| is the null span, w = 0 there
                rad = [a for a in range(1 << n) if all(pc(a & b & D) % 2 == 0 for b in range(1 << n))]
                if sorted(rad) != sorted(a for a in range(1 << n) if a & D == 0): okB = False
                if any(wp[a] for a in rad): okB = False
                # (c) w = 2 on the first null bit: still an enhancement of the degenerate form, Gauss sum 0
                nb = 1 << (p + q)
                wbad = [(wp[a] + 2 * (1 if a & nb else 0)) % 4 for a in range(1 << n)]
                if gsum(wbad) != (0, 0): okB = False
    row('bd·geo·5', f'with null generators the literal w = pi + 2Q (pi counting every generator) is not an enhancement: smallest counterexample (p,q,r), a, b, w(a+b), w(a), w(b) = {ce}; '
        f'and in Cl(0,0,1) its Gauss sum is {lit} = 1 + i, not 2 = 2^r G. The form that core·B3 sums (weight 0 on the null bits) is w_D(a & D): '
        'an enhancement of the degenerate form |a & b & D| whose radical is exactly the null span, with w = 0 there and Gauss sum 2^r G_D (n <= 6, every r); '
        'putting w = 2 on one radical vector gives Gauss sum 0: weight 0 on the null bits is the one choice that keeps the null bits in the radical and the clock defined', okA and okB)

# ---------------------------------------------------------------- 6. Atiyah-Bott-Shapiro from the bit-rule types
def algebra_type(p, q):
    """(number of simple factors c, division algebra D, irreducible real module dimension d) from the bit rule:
    centre dimension and omega^2 give c; the Frobenius-Schur count nu = sum_a e_a^2 = kN ind(D) (T4 (iv)) gives D."""
    n = p + q; e = sig(p, q); F = (1 << n) - 1
    nu = sum(sgn(a, a, e) for a in range(1 << n))
    om2 = sgn(F, F, e)
    central_top = (n % 2 == 1)
    if central_top and om2 == 1: c = 2
    else: c = 1
    if central_top and om2 == -1:
        D, dimD = 'C', 2
    else:
        # dim = c * N^2 * dimD ; nu = c * N * ind, ind(R) = 1, ind(H) = -2
        D = 'R' if nu > 0 else 'H'
        dimD = 1 if D == 'R' else 4
    N2 = (1 << n) // (c * dimD)
    N = int(round(N2 ** 0.5)); assert N * N == N2
    if D == 'C' and nu != 0: raise ValueError
    if D == 'R' and nu != c * N: raise ValueError
    if D == 'H' and nu != -2 * c * N: raise ValueError
    return c, D, N * dimD
def c6():
    # ABS uses Cl_k with v^2 = -|v|^2: the atlas cell Cl(0,k)
    types = [algebra_type(0, k) for k in range(0, 10)]
    # swap check: for k with Cl(0,k) having two simple factors (k = 3 mod 4), the next generator e_{k+1} anticommutes with the
    # central top blade of Cl(0,k) inside Cl(0,k+1): it exchanges the two irreducibles
    okswap = True
    for k in range(1, 10):
        if types[k][0] == 2:
            e = sig(0, k + 1); top = (1 << k) - 1; g = 1 << k
            okswap &= sgn(g, top, e) == -sgn(top, g, e)
    groups = []
    for k in range(1, 9):
        cK, _, dK = types[k]; cK1, _, dK1 = types[k - 1]
        m = dK // dK1                      # each irreducible of Cl_k restricts to m copies in total
        # restriction matrix rows: irreducibles of Cl_k; cols: irreducibles of Cl_{k-1}
        if cK1 == 1:
            R = [[m] for _ in range(cK)]
        else:                              # two irreducibles below, swapped by the next generator: equal multiplicity
            R = [[m // 2, m // 2] for _ in range(cK)]
        # cokernel of Z^{cK} -> Z^{cK1} (row vectors), by Smith form of a <= 2 x 2 integer matrix
        import math
        if cK1 == 1:
            g = 0
            for rr in R: g = math.gcd(g, rr[0])
            groups.append('0' if g == 1 else ('Z' if g == 0 else f'Z{g}'))
        else:
            # image lattice spanned by rows in Z^2
            rows = [rr for rr in R]
            det = None
            if len(rows) >= 2:
                det = abs(rows[0][0] * rows[1][1] - rows[0][1] * rows[1][0])
            if det:
                groups.append('0' if det == 1 else f'Z{det}')
            else:
                g = 0
                for rr in rows: g = math.gcd(g, math.gcd(rr[0], rr[1]))
                groups.append('Z' if g == 1 else f'Z+Z{g}')
    want = ['Z2', 'Z2', '0', 'Z', '0', '0', '0', 'Z']
    clock = [(0 - k) % 8 for k in range(1, 9)]
    row('bd·geo·6', f'types of Cl(0,k), k = 0..9 from the bit rule (factors, D, irreducible dimension): {types[:9]}; the next generator swaps the two '
        f'irreducibles whenever there are two ({okswap}); ABS cokernels coker(M(Cl_k) -> M(Cl_(k-1))), k = 1..8: {groups} = KO^(-k)(pt) '
        f'(Atiyah-Bott-Shapiro). The clock of the same cells is {clock}: the Brauer-Wall class (a group Z_8) and KO^(-k)(pt) are two different '
        'period-8 invariants; the clock is the first', okswap and groups == want)

if __name__ == '__main__':
    for f in (c1, c2, c3, c4, c5, c6): f()
    verdict()
