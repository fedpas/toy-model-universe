# Bridge checks (selfcheck/bridges)

The scripts of this folder compute the statements that join the cells of the atlas to the languages of physics and of mathematics: the clock as an edge invariant of Majorana modes, as a K-theory degree and as a lattice phase; the frame-free cell against the number of time directions; the null generator as a horizon, a creation operator and a base change; and so on. They are checks, not readings: each prints what it computes.

Every script prints one line per check id, `ok   <id>  <what is computed>` (or `FAIL <id>  ...`), and as its last line `<n>/<n> bridge checks hold.  ALL BRIDGE CHECKS PASS`; it exits 1 when a check fails. A line `info <id>  ...` reads a value off or does arithmetic that cannot fail: it is not a check, it is not counted, and it never stands behind a `checked` tag. The ids are `bd·<family>·<n>`. A statement of the atlas that a bridge check computes names the script and the ids in its `checkedBy`, in the form `selfcheck/bridges/<file>.py, bd·<family>·<n>`.

The scripts read no file outside this folder, write nothing, use no network, use fixed seeds and print the same lines on every run. They run from any folder: `python3 selfcheck/bridges/<file>.py`.

## Physics family (phy, str, sol, xph, fk, mjp)

Ids `bd·phy·n` (the frame-free cell, Dirac, coupling, null surfaces, trios, the staggered cube), `bd·str·n` (worldsheet, K-theory, spinors, dualities, lattices), `bd·sol·n` (Majorana edges, bands, media, lattices, point groups), `bd·xph·n` (two cross-checks that compute two of these readings again, independently, and compare them), `bd·fk·n` (the junction of two stacks of Kitaev chains) and `bd·mjp·n` (the labels, weights and category of arXiv:2403.19689 (v3) read as occupation patterns, charges, path sums, time and clocks).

- **Run and rebuild.** `sh selfcheck/regen_bridges_phys.sh` runs the 31 scripts one at a time on one core and writes `bridges_phys.json`: every printed line (id, script, kind `check` or `info`, text, ok), the processor seconds of each script, its imports and the counts (121 checks, 7 info lines). `node test_bridges_phys.mjs` runs every script again from another folder and compares the lines with the json, checks this table, the imports and the words, runs a sabotaged copy of every script (one documented changed line, listed in the test, must make the copy exit 1 with `FAIL` for the intended id), `fk_junction.py --sabotage` and the `--sabotage` mode of the six `mjp_*.py` scripts, and checks that every `bd·phy`, `bd·str`, `bd·sol`, `bd·xph`, `bd·fk` or `bd·mjp` id that a file of the package cites is a row of the json.
- **Dependencies.** Python 3 with numpy for every script except three: `str_dualities.py`, `str_lattices.py` and `str_null.py` use the standard library only and pass with `python3 -I`. scipy is used by two scripts: `sol_hubbard_cube.py` (sparse matrices and the Lanczos solver `eigsh`) and `fk_junction.py` (the same, on Fock spaces of dimension up to 2^14). `phy_bitrule.py` is the bit-rule engine (no check of its own) that `phy_coupled_action.py`, `phy_dirac.py`, `phy_horizon_little_group.py`, `phy_staggered.py` and `phy_trio.py` import from this folder. `sol_furey_fk.py` carries the octonion lines of `model.py` (the test checks that they are lines of `model.py`).
- **Seconds.** Processor seconds of one run on one core (`OMP_NUM_THREADS=1`), as stored in `bridges_phys.json`; every script stays under 60 on an idle core. `fk_junction.py` is the longest (38 to 46 s on an idle core, up to 55 s when other processes share the cores); `python3 fk_junction.py --only bd·fk·1` runs one of its checks, and `python3 fk_junction.py --sabotage` runs each of its five checks on a deliberately broken input and prints `CAUGHT` for each (`ALL CAUGHT`, exit 0).

| id | script | what it computes | range | seconds |
|---|---|---|---|---|
| bd·phy·1 | phy_cell_vs_signature.py | an explicit isometry of triples (V, Q, pi) Cl(5,0) -> Cl(1,4) from five odd anticommuting blades of square +1 | n = 5 | 0.4 |
| bd·phy·2a | phy_cell_vs_signature.py | the same for Cl(5,2) -> Cl(1,6) | n = 7 | 0.4 |
| bd·phy·2b | phy_cell_vs_signature.py | the same for Cl(5,3) -> Cl(1,7) | n = 8 | 0.4 |
| bd·phy·3 | phy_cell_vs_signature.py | the hyperbolicity test of T18 (f) holds for the Lorentzian member of each pair and for no tested direction of the other | the three pairs; 200 random directions | 0.4 |
| bd·phy·4 | phy_cell_vs_signature.py | the generators of Cl(5,0) go to blades of grades 1, 3, 3, 3, 3: the frame is data beyond the triple; eps carries min(p,q) | n = 5 | 0.4 |
| bd·phy·20 | phy_cell_vs_signature.py | the classes (n, clock) that hold a Lorentzian and a non-Lorentzian cell: none exactly for n = 2, 3, 4, 6 | n = 2..12 | 0.4 |
| bd·phy·5 | phy_horizon_little_group.py | the stabiliser of the null vector l = e0 + e1 in so(1,3) has dimension 3, basis l e2, l e3, e2 e3 | Cl(1,3) | 0.1 |
| bd·phy·6 | phy_horizon_little_group.py | l e_k -> n e_k, e2 e3 -> e2 e3 is a Lie algebra isomorphism onto the bivectors of Cl(0,2,1); both are iso(2) | Cl(1,3), Cl(0,2,1) | 0.1 |
| bd·phy·7 | phy_horizon_little_group.py | the isomorphism intertwines the actions on l-perp and on span(n, e2, e3) | Cl(1,3), Cl(0,2,1) | 0.1 |
| bd·phy·8 | phy_horizon_little_group.py | the tube algebra Cl(T,-1,-1): [K1, K2] = -2T J, so(1,2), iso(2), so(3) | T = 1, 0, -1 | 0.1 |
| bd·phy·9 | phy_dirac.py | the dagger of T15 is gamma0 psi~ gamma0; its state functional is the gamma0 component of the Dirac current (positive), while the reversion scalar takes both signs | Cl(1,3); 300 random psi | 0.2 |
| bd·phy·10 | phy_dirac.py | the chirality I psi J commutes with the right action of J; the Weyl halves have real dimension 4 + 4 | Cl(1,3); 50 random psi | 0.2 |
| bd·phy·11 | phy_dirac.py | the current psi gamma0 psi~ has grades 1 and 5, and the coupling term sees only its grade-1 part | Cl(1,4); 200 random cases | 0.2 |
| bd·phy·12 | phy_dirac.py | the real operators gamma.d - m and gamma.d + m are singular on E^2 = p^2 + m^2; i gamma.d - m on the tachyonic shell | real 4x4 matrices of Cl(3,1); 50 random p, m | 0.2 |
| bd·phy·13 | phy_trio.py | Witt (x) A_eps is bms3 = gca2 (eps = 0), Witt + Witt (+1), Witt (x) C (-1); the Jacobi identity holds | modes up to 4 (Jacobi up to 2) | 0.1 |
| bd·phy·14 | phy_trio.py | the Killing signatures of the bivectors of Cl(1,3) plus one generator of square s: so(1,4), so(2,3), iso(1,3) | s = -1, +1, 0 | 0.1 |
| bd·phy·16 | phy_staggered.py | the bit-rule signs on the n-cube are the Kogut-Susskind phases; D^2 = n | n = 2..6 | 0.1 |
| bd·phy·17 | phy_staggered.py | the antisymmetric staggered operator vanishes on the lattice of side 2 and the signed cube D is the symmetric part; side 3 and 4 give a nonzero one | n = 2..6; (n, L) = (2,3), (2,4), (3,3) | 0.1 |
| bd·phy·18 | phy_coupled_action.py | the Euler-Lagrange equation in psi of the coupled action is T times the Dirac equation with the term -e A psi | Cl(1,3); 50 random cases | 0.2 |
| bd·phy·19 | phy_coupled_action.py | the Euler-Lagrange equation in A is c (grad F - e X) with one c; flipping L_int flips both equations together | Cl(1,3); 30 random cases | 0.2 |
| bd·str·1 | str_clock.py | the Z_4 refinements of the dot product are the bit-rule forms w = pi + 2Q, with Gauss phase p - q (the Arf-Brown invariant of a Pin- surface) | n up to 6 | 0.7 |
| bd·str·2 | str_clock.py | the Atiyah-Bott-Shapiro cokernels of the bit-rule modules of Cl(0,k) are KO^{-k}(pt) | k = 1..10 | 0.7 |
| bd·str·5 | str_clock.py | row 8: five cells with ungraded algebra M_16(R), three with clock 0 | n = 8 | 0.7 |
| bd·str·6 | str_spinors.py | the type of the even part Cl^0(s,t) depends on s - t mod 8 only; Majorana-Weyl exactly when s - t = 0 mod 8 | s + t up to 12 | 3.1 |
| bd·str·7 | str_spinors.py | Hull's lists of M, IIA and IIB signatures from the even part (Hull's criteria are the input) | s + t = 10, 11 | 3.1 |
| bd·str·8 | str_spinors.py | the Hodge star on middle forms of Cl(D-1,1) squares to the top-blade square: real self-dual forms for D = 2, 6, 10 | D = 2..12 even | 3.1 |
| bd·str·9 | str_spinors.py | the 3-psi rule holds for every invariant symmetric pairing exactly for D = 3, 4, 6, 10 | D = 3..11 | 3.1 |
| bd·str·10 | str_dualities.py | T-duality on polyforms: CAR of T + T*, the reflection swaps dx^i wedge and iota_i and is odd | n up to 5 | 0.9 |
| bd·str·11 | str_dualities.py | B-shifts are null bivectors; e^N is even and is the B-transform | n = 4 | 0.9 |
| bd·str·12 | str_dualities.py | triality as the Hadamard transform of F_2^4 on the weights of D4 | n = 4 | 0.9 |
| bd·str·13 | str_dualities.py | the two ideals of Cl(4,3): exchanged by the grade involution and the reversion, fixed by Clifford conjugation, one Spin module | Cl(4,3) | 0.9 |
| bd·str·14 | str_dualities.py | Witt (x) A_eps with central terms: Jacobi; Vir + Vir, BMS3 = GCA2, Witt (x) C | modes up to 4 | 0.9 |
| bd·str·15 | str_lattices.py | E8 two ways: Construction A on the code of Furey's Fano blades and D8 + (D8 + s), 240 and 2160 vectors | rank 8 | 8.8 |
| bd·str·16 | str_lattices.py | the Brown phase of Z^n/2Z^n and the Gauss-Milgram phase of D_n are both n mod 8 | n = 1..24 | 8.8 |
| bd·str·17 | str_lattices.py | del Pezzo: K.K = 9 - n, the E_n roots, the exceptional classes 6, 10, 16, 27, 56, 240 | n = 3..8 | 8.8 |
| bd·str·18 | str_lattices.py | the 56 of E7 split 7 x 8 over seven orthogonal roots, whose triples form a Fano plane | E8 | 8.8 |
| bd·str·19 | str_lattices.py | Thurston's form on Z[w]^10 is even, unimodular, of signature (2,18) | rank 20 | 8.8 |
| bd·str·20 | str_syk.py | Majorana SYK level statistics by parity sector are GOE, GUE, GSE as the type of Cl^0(N,0) | N = 8, 10, 12, 14, 16 | 14.4 |
| bd·str·21 | str_null.py | the horizon generator l is a paired null of Cl(1,n-1) and the radical of the subalgebra Cl(0,n-2,1) | n = 3..6 | 0.0 |
| bd·str·23 | str_extra.py | the graded map A (x) A^op -> End(A) has image of dimension 4^(p+q) 2^r = dim End_Z(A) | every Cl(p,q,r), n up to 4, r at least 1 | 1.8 |
| bd·str·24 | str_extra.py | Furey's Lagrangian as the Cayley 4-form: eigenvalue 14 once, stabiliser of dimension 21 = dim spin(7) | Cl(0,8) | 1.8 |
| bd·str·25 | str_extra.py | E_n mod 2 is the set of even labels of Cl(1,n), and dropping the H-bit gives the labels of Cl(n,0); the same for A_n | n = 3..9 (E_n), 1..9 (A_n) | 1.8 |
| bd·str·26 | str_extra.py | E7: 135 sets of seven orthogonal roots, 30 of them Hamming codes mod 2, one of them Furey's Fano lines; the 56 split 7 x 8 | n = 7 | 1.8 |
| bd·str·27 | str_extra.py | the 3-psi rule on Cayley-Dickson labels holds for R, C, H, O and fails for the sedenions | 1, 2, 4, 8, 16 labels; 40 random psi | 1.8 |
| bd·sol·1 | sol_fk_clock.py | the T-invariant real algebra of p T-even and q T-odd Majoranas is the bit rule of Cl(p,q); Hermitian iff Q = 0, fermion-odd iff pi = 1 | n even up to 8 (all products up to 6) | 3.1 |
| bd·sol·2 | sol_fk_clock.py | the edge invariants (T^2, T against P) depend on the clock only | n even up to 12 | 3.1 |
| bd·sol·3 | sol_fk_clock.py | the generic level degeneracy of a T-invariant edge is 1 exactly when c = 0 mod 8, else 2 | n even up to 10 | 3.1 |
| bd·sol·4 | sol_fk_clock.py | a Lagrangian of w exists exactly when c = 0 mod 8 | exhaustive for n even up to 8; built up to 16 | 3.1 |
| bd·sol·5 | sol_fk_clock.py | the stabilizer Hamiltonian of a Lagrangian has a unique T-invariant ground state and gap 2 | c = 0 cells, n up to 12 | 3.1 |
| bd·sol·6 | sol_fk_clock.py | Furey's seven Fano blades as an 8-Majorana interaction: a unique ground state of definite parity | Cl(8,0), Cl(0,8) | 3.1 |
| bd·sol·7 | sol_fk_clock.py | the mirror is the relabelling T -> T P | n even up to 10 | 3.1 |
| bd·sol·8 | sol_fk_clock.py | stacks of BDI chains: winding p - q, end modes (p,q) and (q,p), p - q left after T-invariant couplings | eight stacks, 12 sites | 3.1 |
| bd·sol·9 | sol_fk_clock.py | Construction A on the code of bd·sol·6: 240 roots spanning an even unimodular lattice (E8) | rank 8 | 3.1 |
| bd·sol·10 | sol_furey_fk.py | Furey's line blades as Fidkowski-Kitaev couplings: a perfect Hamming code, a unique ground state for all 128 sign choices, minimum -5 with her orientation, her blocks are not levels | 128 sign choices | 0.1 |
| bd·sol·11 | sol_null_bands.py | the PT dimer is a vector of Cl(1,1); at the exceptional point a paired null; splitting exponents 1/2 and 1 | one dimer | 1.9 |
| bd·sol·12 | sol_null_bands.py | the *-closure of Cl(p,q,r) is Cl(p+r,q+r), with the clock of Cl(p,q,r) at weight 0 on the null bits | every Cl(p,q,r), n up to 4 | 1.9 |
| bd·sol·13 | sol_null_bands.py | Kronig-Penney: X^2 = g^2 - 1, van Hove exponent -1/2 at the band edges, L states per band | the first three band edges | 1.9 |
| bd·sol·14 | sol_maxwell_media.py | constitutive tensors 36 = 21 + 15; the axion part is invisible to the wave operator; the vacuum Fresnel polynomial | 20 random k | 0.2 |
| bd·sol·15 | sol_maxwell_media.py | uniaxial media: the Fresnel factorisation and the hyperbolicity in t or z of each sign class | four sign classes | 0.2 |
| bd·sol·16 | sol_maxwell_media.py | a Drude axis: hyperboloid below omega_p, ellipsoid above, the vacuum form in the limit | seven frequencies | 0.2 |
| bd·sol·17 | sol_maxwell_media.py | the Poynting balance fixes the relative sign of source and force | 200 random linear fields, exact | 0.2 |
| bd·sol·18 | sol_lattice_springs.py | the pi-flux lattice: phases = bit-rule signs, H(k), Dirac points, tastes | n = 2, 3, 4 | 0.1 |
| bd·sol·19 | sol_lattice_springs.py | n-cube frames: C(n+1,2) rigid motions, 1, 6, 22, 65 mechanisms, no self-stress; the braced cube is rigid | n = 2..5 | 0.1 |
| bd·sol·20 | sol_lattice_springs.py | Kitaev ring: the ground parities of periodic and antiperiodic rings differ exactly when abs(mu) < 2t | N = 12, five values of mu | 0.1 |
| bd·sol·30 | sol_lattice_springs.py | fermion doubling: 2^d zeros of the naive stencil, one with a Wilson mass | d = 1..4 | 0.1 |
| bd·sol·21 | sol_point_groups.py | the 3-bit labels are mmm; the spin double groups are the sign tables of Cl(0,3) and Cl(3,0) | n = 3 | 0.2 |
| bd·sol·22 | sol_point_groups.py | B3 = O_h, D3 = T_d; integral traces of the crystallographic groups, (1 +- sqrt5)/2 for 2.A5 | point groups | 0.2 |
| bd·sol·23 | sol_point_groups.py | the Frobenius-Schur indicator is the type R, C, H; T^2 = FS; Kramers degeneracy for H | n up to 4 | 0.2 |
| bd·sol·24 | sol_point_groups.py | a Weyl node cannot be gapped in Cl(3,0); Dirac masses; Chern number -chi | Cl(3,0) | 0.2 |
| bd·sol·25 | sol_abs_tenfold.py | the Atiyah-Bott-Shapiro cokernels from bit-rule modules are KO^{-k}(pt) | k = 1..10 | 0.9 |
| bd·sol·27 | sol_kitaev_lieb.py | Lieb's flux phase on the cube: the half-filled energy is lowest exactly in the all-pi sector | n = 2, 3, 4, every flux sector | 4.8 |
| bd·sol·28 | sol_kitaev_lieb.py | Kitaev's spin from four Majoranas: D is the central top blade of the even part; the projection picks one chirality | Cl(4,0) | 4.8 |
| bd·sol·29 | sol_kitaev_lieb.py | the central split happens exactly for p - q = 1 mod 4 | odd n up to 7 | 4.8 |
| bd·sol·31 | sol_hubbard_cube.py | Hubbard model on the 3-cube: the all-pi sector has the lowest ground energy | 32 flux sectors; U = 0, 2, 4, 8 | 2.1 |
| bd·xph·1 | xph_clock_crosscheck.py | the edge pair (T^2, T against P) and the type of the even part are one function of the clock | n even up to 8 | 0.4 |
| bd·xph·2 | xph_clock_crosscheck.py | the even-part types of Cl(N,0) are the Dyson classes of the SYK sectors | N = 8..16 even | 0.4 |
| bd·xph·3 | xph_null_join.py | the dagger of l is e_t - e_r; the subalgebra of l, e2, e3 is Cl(0,2,1), and with the dagger of l it is Cl(1,3) | n = 4 | 0.4 |
| bd·xph·4 | xph_null_join.py | dimensions 2^(n-1) and 2^n; the clock of the closure is the clock with weight 0 on the null bit | n = 3..6 | 0.4 |
| bd·fk·1 | fk_junction.py | the interface zero modes of a free junction of two BDI stacks form Cl(p,q) with p - q = W' - W | 18 junctions | 55.0 |
| bd·fk·2 | fk_junction.py | free junctions: the ground state is 2^(d/2)-fold degenerate, d = abs(W - W') | 8 junctions | 55.0 |
| bd·fk·3 | fk_junction.py | interacting junctions: degeneracy 1, 2, 2, 4, 2, 4, 2, 2 by (W - W') mod 8 | 18 junctions; seeds 101, 202 | 55.0 |
| bd·fk·4 | fk_junction.py | residue 0: the Hamming stabilizers give a unique gapped ground state, robust to a perturbation | (8,0), (4,-4), (4,4) | 55.0 |
| bd·fk·5 | fk_junction.py | T^2 and T against P on the junction force a degeneracy of at least 2 for every nonzero residue | 13 junctions | 55.0 |
| bd·mjp·1 | mjp_fock.py | the Jordan-Wigner creation operator c_i^+ (Pauli strings) equals left multiplication by e_i in Lambda(R^n) (bit rule, eps = 0), entry by entry | n = 1..5 | 3.8 |
| bd·mjp·2 | mjp_fock.py | C_a^+ C_b^+ = s(a,b) C_(a xor b)^+ on the 3^n disjoint pairs and 0 on the 4^n - 3^n overlapping ones (Pauli exclusion); C_a^+ takes the vacuum to the label a | n = 1..5 | 3.8 |
| bd·mjp·3 | mjp_fock.py | the Witt pairs (g_i + g_(n+i))/2, (g_i - g_(n+i))/2 of the bit-rule Cl(n,n) satisfy the CAR; the Fock ideal Cl(n,n) P0 has dimension 2^n and a_i^+ acts on it as the Jordan-Wigner matrix | n = 1..4 | 3.8 |
| bd·mjp·4 | mjp_fock.py | creation operators and number projectors generate the incidence algebra of B_n (dimension 3^n, the matrix units E_(T,S) with S subset T); with the annihilation operators all of M_(2^n)(R), dimension 4^n | n = 1..5 (4^n: n = 1..4) | 3.8 |
| bd·mjp·5 | mjp_fock.py | the arrow S -> T goes to s(T\S, S) C^+_(T\S) P_S = E_(T,S); composition is kept on the 4^n composable pairs; [N, A] = (weight of the arrow) A | n = 1..5 | 3.8 |
| bd·mjp·6 | mjp_fock.py | control: with random edge signs the creation operators and number projectors still generate dimension 3^n (the incidence algebra does not see the sign; a generic statement) | n = 3, 4; 200 tables each | 3.8 |
| bd·mjp·7 | mjp_fock.py | the bit rule has flux -1 on every square face of B_n; random edge-sign tables give anticommuting creation operators in 8 of 200 (n = 3) and 0 of 200 (n = 4) | faces n = 2..6; tables n = 3, 4 | 3.8 |
| bd·mjp·8 | mjp_fock.py | an ordering of the modes is a gauge: CAR, flux -1 on every face, c_i^+(sigma) = G c_i^+ G with G the sign of the sorting permutation | n = 3, 4, 5; 20 orderings each | 3.8 |
| bd·mjp·9 | mjp_charges.py | the weights additive on disjoint labels form a space of dimension n (the charges); sum q_i c_i^+ c_i is diagonal with spectrum h_q, and U c_0^+ c_0 c_1^+ c_1 breaks (9) by exactly U | n = 0..6; operators n = 5 | 0.5 |
| bd·mjp·10 | mjp_charges.py | the composition-additive weights on B_n are the 2^n - 1 potentials E(T) - E(S); those that depend only on the label T\S are the n charges; on random posets the dimension is elements - components + b1 | n = 1..5; 200 random posets | 0.5 |
| bd·mjp·11 | mjp_charges.py | the n! 2^n Witt pairings of the same generators of Cl(n,n) give n! 2^n number operators and one parity operator up to sign: the cell fixes the parity, not the particle number | n = 2, 3 | 0.5 |
| bd·mjp·12 | mjp_charges.py | the charge grading of M_(2^n)(R) by ad N has dimensions C(2n, n+k); the incidence algebra has charge-k part C(n,k) 2^(n-k); the charge >= 0 part, (4^n + C(2n,n))/2, is larger for n >= 2 | n = 1..6 | 0.5 |
| bd·mjp·13 | mjp_charges.py | label vectors of Cl(n,0): square = popcount, Pythagoras and anticommutation on disjoint labels; (9) holds with the norm alpha^2 and (13) then only on the n one-bit labels; with the norm sqrt(alpha^2) (9) fails on every disjoint pair; in Cl(1,3) alpha^2 <= 0 on 14 of 15 labels | n = 1..6; Cl(1,3) | 0.5 |
| bd·mjp·14 | mjp_charges.py | Koenigsberg with the land masses as objects: no walk crosses each bridge once; the shortest covering walk has 8 crossings | 7 bridges, exhaustive | 0.5 |
| bd·mjp·15 | mjp_charges.py | Koenigsberg with the bridges as objects (the paper's Example 1): a path through all seven exists if consecutive bridges only share a land mass, none with oriented crossings (shortest covering path 8) | 7 bridges, exhaustive | 0.5 |
| bd·mjp·16 | mjp_action.py | every discrete diagram of B_n has a limit, the AND, and a colimit, the OR; in random posets of 8 elements a pair has a limit in 56% of the cases | n = 0..4, diagrams of 0..3 objects; 200 posets | 0.6 |
| bd·mjp·17 | mjp_action.py | the diagonal functor is left adjoint to the meet: Hom(Delta c, d) is non-empty iff Hom(c, AND d) is (74584 comparisons) | n = 1..4; J of 2 and 3 objects | 0.6 |
| bd·mjp·18 | mjp_action.py | for a strictly increasing energy the limit cone is the unique cone of least total leg weight; the converse fails (a bowtie poset; 80 pairs of random posets) | n = 1..4, 20 energies; 200 posets | 0.6 |
| bd·mjp·19 | mjp_action.py | on the thin category B_n every maximal path has the weight E([n]) - E(0), so every path is a minimiser; n! maximal chains; 1, 1, 3, 13, 75, 541, 4683 chains of all lengths | n = 0..6; 20 potentials | 0.6 |
| bd·mjp·20 | mjp_action.py | free category on the Hasse diagram with generic edge weights: the min-plus recursion gives the least path weight, the minimiser is unique, F(beta) lies within ln(n!)/beta of it | n = 3..6; beta = 1, 10, 100 | 0.6 |
| bd·mjp·21 | mjp_action.py | the sum over the n! maximal chains of the creation products on the vacuum: 0 with the Jordan-Wigner signs, n! for hard-core bosons; random signs give 0 in some of 200 tables | n = 2..6 (random signs n = 2..4) | 0.6 |
| bd·mjp·22 | mjp_action.py | for a charge weight the sum over the arrows out of S of e^(-beta w) is the free-fermion grand partition function prod (1 + e^(-beta q_i)); it fails for 200 of 200 random interacting energies | n = 1..6, every S; beta = 0.3, 1, 2.5 | 0.6 |
| bd·mjp·23 | mjp_time.py | proper time is not an additive weight: g0 and (5/4) g0 + (3/4) g1 have proper time 1, their sum has (u + v)^2 = 9/2 > 4; strictly super-additive on random future-timelike pairs (Cl(1,3), Cl(3,1)); Euclidean length strictly sub-additive | exact rationals; 200 pairs | 0.3 |
| bd·mjp·24 | mjp_time.py | a sum of future-timelike arrows is future-timelike with proper time at least the sum; two spacelike arrows can sum to a timelike, a null or a spacelike arrow | 200 chains of 2..6 arrows; Cl(1,3), Cl(3,1) | 0.3 |
| bd·mjp·25 | mjp_time.py | the linear forms and vectors kept by rotations and boosts of R^(1+d): Galilei (1, 0), Lorentz (0, 0), Carroll (0, 1) | d = 2, 3 | 0.3 |
| bd·mjp·26 | mjp_time.py | the null rotor 1 + (v/2) e0 e1 of Cl(2,0,1) is a Carroll boost on vectors and a Galilei boost on bivectors (the inverse transpose); e12/2, e0 e1, e0 e2 have the brackets of the homogeneous Galilei algebra of the plane | exact; v = 1/3, 2, -5/7 | 0.3 |
| bd·mjp·27 | mjp_time.py | the paper's arrows as events (weight, D(f)): with weights above the planar distance every arrow lies in the speed-1 cone; a Galilei boost takes arrows out of it, a Lorentz boost changes weights; the maps keeping dt and the cone form so(2) | B_3, 200 random categories | 0.3 |
| bd·mjp·28 | mjp_clock.py | the conformal weight alpha.alpha/2 of the label vectors of Z^n is additive exactly on the disjoint pairs; not with the simple roots of A_n; for random Gram matrices exactly when diagonal | n = 1..6; A_2..A_6; 200 Grams | 2.3 |
| bd·mjp·29 | mjp_clock.py | the bit-rule sign is a bimultiplicative cocycle on F_2^n with the commutator of the lattice vertex superalgebra (Bakalov-Kac (4.2)); the square condition (4.1) holds for all squares -1 only | every eps, n = 1..5 | 2.3 |
| bd·mjp·30 | mjp_clock.py | clocks (exact Gauss sums) of the cells of the paper's relations: Cl(3,0) 3, Cl(2,0) 2, Cl(2,0,1) 2 = Cl(3,1); the Gram matrix of the inner product (10) has signature (2,0) | 4 cells; 200 random categories | 2.3 |
| bd·mjp·31 | mjp_clock.py | w = pi + 2Q is a Z_4 charge: w(a) = sum eps_i mod 4, additive on disjoint labels (w_D with null bits); the Gauss sum is prod (1 + i^eps_i); w on all of V is additive for 3 of the 90 cells with r >= 1 | every eps, n <= 6 (additivity n <= 4) | 2.3 |
| bd·mjp·32 | mjp_clock.py | integer generator weights q read mod 4 are the form w_D of the cell with squares +1, -1, 0 for q_i = 1, 3, 0 mod 4, clock #{q = 1} - #{q = 3}; of no cell when some q_i = 2 mod 4 | 884 weight vectors, n <= 5 | 2.3 |
| bd·mjp·33 | mjp_ladder.py | sizes by enumeration: labels 2^n; defined partial sums = non-zero creation products = arrows of B_n 3^n; composable pairs 4^n; chains of length k (k+2)^n | n = 0..6; k = 0..3 | 5.3 |
| bd·mjp·34 | mjp_ladder.py | the algebra of the partial sum (hard-core bosons, zeons) and Lambda(R^n) share dimension and zero pattern; the first is commutative, the second has a commutator space of dimension 2^(n-1) - 1; left multiplications sigma^+ against the Jordan-Wigner c^+ | n = 1..5 | 5.3 |
| bd·mjp·35 | mjp_ladder.py | the triples (V, Q, pi) of the cells Cl(p,q,r) fall into fewer isometry classes than the cells; Cl(1,0) and Cl(0,0,1) share a triple | n = 1..3 | 5.3 |
| bd·mjp·36 | mjp_ladder.py | the two ladders meet: the bit rule on disjoint labels with the sign forgotten is the partial sum, the sign there does not depend on eps, and the order of the partial sum is inclusion | 364 eps, n = 0..5 | 5.3 |
| bd·mjp·37 | mjp_ladder.py | the popcount is a grading of the product of the cell only for eps = 0; for eps in {+1,-1}^n the 4^n - 3^n overlapping products break it | every eps, n = 1..4 | 5.3 |
| bd·mjp·38 | mjp_ladder.py | the partial sum is frame data: its automorphisms are the n! permutations; the partial sums with the form w (up to S_p x S_q) are 1 for n <= 3 and for Cl(4,0), Cl(0,4), and 2 for Cl(1,3), Cl(2,2), Cl(3,1) | n <= 3 (automorphisms), n <= 4 (isometries) | 5.3 |

### Info lines (read-offs, not checks)

- bd·phy·15 (phy_trio.py): the bivector squares -1, +1, 0 of Cl(2,0), Cl(1,1), Cl(1,0,1) read as three trios (orbits, tubes, bands): three one-line squares, a table.
- bd·str·3 (str_clock.py): the Type I D-brane charge list indexed from the groups that bd·str·2 computes: a read-off of bd·str·2.
- bd·str·4 (str_clock.py): KO^{nu} + KO^{-nu} as a function of {c, -c}: symmetric by construction, it cannot fail.
- bd·str·22 (str_null.py): AdS_d and the conformal model of its boundary give the same cell Cl(2,d-1): signature arithmetic, it cannot fail (the line also reads the type M_4(C) of Cl^0(2,4) from the bit rule).
- bd·sol·26 (sol_abs_tenfold.py): the complex cokernels KU^{-k}(pt) from the counts of complex modules: arithmetic on the counts.
- bd·mjp·39 (mjp_clock.py): the K-theory row of the two clocks of the cells of arXiv:2403.19689 (v3), read off bd·str·2 (Cl(0,k) <-> KO^{-k}(pt)): clock 2 sits at KO^{-6}(pt) = 0, clock 3 at KO^{-5}(pt) = 0: a read-off of bd·str·2.
- bd·mjp·40 (mjp_clock.py): the Fidkowski-Kitaev row of Cl(2,0), read off bd·sol·2: two T-even Majoranas, T^2 = +1, T anticommutes with the fermion parity; Cl(3,0) (three Majoranas) lies outside the range (n even) of bd·sol·2: a read-off of bd·sol·2.

The six `mjp_*.py` scripts (ids `bd·mjp·1` to `bd·mjp·40`) compute the readings of arXiv:2403.19689 (v3) in the occupation-number, string and space-time lenses: the labels as Fock states and the arrows of B_n as creation operators (`mjp_fock.py`), additive weights as charges, particle number and energy (`mjp_charges.py`), the computable rows of the table (2.53) of the paper as limits and path sums (`mjp_action.py`), time as a weight (`mjp_time.py`), the cells, clocks and Z_4 charges of the paper's relations (`mjp_clock.py`), and the two ladders from the labels to the cells and back (`mjp_ladder.py`). They use numpy and the standard library and pass with `python3 -I` from any folder. Each has a mode `python3 mjp_<name>.py --sabotage` that runs every one of its checks on a deliberately broken input (one documented change per check, in the script) and prints `CAUGHT <id>` for each and `ALL CAUGHT` (exit 0); `node test_bridges_phys.mjs` runs it for the six scripts. A few lines print, beside the check, a count that holds by definition and is not counted: the face-flux count of bd·mjp·7 (the same equation as anticommutation), the unit of the adjunction in bd·mjp·17 (c AND c = c), the time component in bd·mjp·23 (linear), the orthogonal pairs in bd·mjp·28 (polarization) and the parity grading in bd·mjp·37 (popcount of a xor b = popcount a + popcount b mod 2). bd·mjp·6 (the dimension 3^n for random signs) is a control, a generic statement, and the bound on F(beta) in bd·mjp·20 is the generic log-sum-exp bound.

## Mathematics

The mathematics bridge scripts recompute the statements that join the cells of the Atlas to standard mathematics: the cell as a twisted group
algebra and as a lattice mod 2 (`mat_*`, `alg_*`), spin geometry, Lorentzian geometry and Klein pairs (`geo_*`), Frobenius, Morita and modular
categories (`cat_*`), cross-checks between these scripts (`xck_*`), the graded Hochschild groups of the degenerate cells (`hh_*`) and the cell
with its reversion (`rev_*`), which choices of structure are gauge and which are data (`tor_*`), the image of W(E_n) mod 2 (`en_*`), the
commutant of the gauge algebra in Furey's model (`fur_*`), the Kepler trio through Fock's projection (`kep_*`) and three readings of the categorial
geometry of arXiv:2403.19689 (v3) on the labels: categories, nerves and sheaves (`mjc_*`), algebras on the labels and the category algebra
(`mja_*`), positions, cubes and frames (`mjg_*`). Every check id has the form
`bd·<family>·n`; a statement of the Atlas that rests on one of them names the script and the id (`selfcheck/bridges/<script>.py, bd·mat·5`).

- Run one script: `python3 selfcheck/bridges/<script>.py` from any folder (`python3 -I` gives the same output). Each prints one line per check,
  `ok   <id>  <what is computed>` (or `FAIL <id>  …`), indented lines with the witnesses, and the verdict line
  `<k>/<k> bridge checks hold.  ALL BRIDGE CHECKS PASS`; it exits 1 on any failing check. No script reads or writes a file or uses the network;
  random data come from generators with fixed seeds, so the output is the same on every run.
- Rebuild the log: `sh selfcheck/regen_bridges_math.sh` runs every script and writes `selfcheck/bridges/bridges_math.json`
  (`rows`: id, script, text, ok, seconds of the whole script; `summary`: the scripts, the counts and the info lines). It stops at the first
  error and then leaves the stored json as it is.
- Test: `node test_bridges_math.mjs` (no browser, about 8 minutes; `--citations` runs only the id, source and citation parts): the json equals a fresh run; every script exits 0 with its verdict line;
  every id of this table is a row; the imports are the allowed ones; no script reads, writes or connects; one sabotaged copy per script of the
  families mat to kep (a one-line change that breaks the check it targets) must stop with `FAIL` for that id; every script of the families mjc,
  mja, mjg runs with `--sabotage` (each of its checks on a deliberately broken input) and must print `CAUGHT <id>` for every one of its checks
  and exit 0; every `bd·` id of these families that any file of the
  package cites is a row of the json, and a `checkedBy` that names a bridge script names the script that prints the id.
- Memory: `en_weyl.py` holds about 0.5 GB at n = 20; every other script stays far below.
- Dependencies: the Python standard library (`array` in `en_weyl.py`); numpy (exact integer and rational data, float eigenvalues only for signatures and for picking
  candidate zero divisors that an exact determinant then confirms) in `alg_finite_fields.py`, `alg_octonion.py` and `geo_cartan.py`; numpy in
  `mjc_labels.py` (integer matrices, ranks modulo a prime paired with an exact bound), `mja_catalg.py` (bd·mja·35 only), `mja_incidence.py`,
  `mja_semiring.py` (bd·mja·28 only), `mjg_frames.py`, `mjg_positions.py`, `mjg_topology.py` and `mjg_vectors.py` (floats with tolerance 1e-9
  for planar geometry, exact fractions where a statement is exact). scipy (`linprog`, HiGHS) in `mjc_sum.py` and `mjc_weight.py` only: a
  linear-programming cross-check that an exact witness or an exact obstruction confirms in the same check; the two scripts need it to run.

Seconds: the run time of the whole script on one idle core (every row of a script shows the same number). Range: the cases the script runs;
a statement for all n rests on the argument or the source named in the row text, not on the range.

| id | script | what it computes | range | seconds |
|---|---|---|---|---|
| `bd·mat·17` | `mat_En_in_Cl1n.py` | k = (3; -1^n) is characteristic in I_{1,n}, k.k = 9 - n = 1 - n mod 8 = clock of Cl(1,n) = det E_n (van der Blij) | n = 3..13 | 0.1 |
| `bd·mat·18` | `mat_En_in_Cl1n.py` | E_n/2E_n maps bijectively onto the even labels of Cl(1,n), with x.x/2 = Q | n = 3..10 | 0.1 |
| `bd·mat·19` | `mat_En_in_Cl1n.py` | on the even labels of Cl(1,n) the Z_4 form is 2 Q_Cl(n,0); the sign of the even Gauss sum is the Arf type of E_n/2E_n | n = 3..10 | 0.1 |
| `bd·mat·12` | `mat_En_trio.py` | E_n = k^perp in I_{1,n}, k = (3; -1^n): k.k = 9 - n, determinant and signature of k^perp | n = 3..13 | 0.1 |
| `bd·mat·13` | `mat_En_trio.py` | the norm -2 vectors of k^perp number 8, 20, 40, 72, 126, 240 | n = 3..8 | 0.1 |
| `bd·mat·5` | `mat_cell_classification.py` | explicit isometry of the triples of Cl(4,0) and Cl(0,4) (the four 3-subsets of a block), extended to Cl(p,q) -> Cl(p-4,q+4) | 4 <= n <= 9 | 1.4 |
| `bd·mat·6` | `mat_cell_classification.py` | the bilinear form of w is the dot product; the polar form of Q has radical {0} (n even) or {0, 1...1} (n odd) | n <= 7 | 1.4 |
| `bd·mat·7` | `mat_cell_classification.py` | w(a) = x.x mod 4 in the odd lattice I_{p,q}; the Gauss sum is (1+i)^p (1-i)^q: clock = signature of I_{p,q} mod 8 | n <= 8 | 1.4 |
| `bd·mat·8` | `mat_cell_classification.py` | for Cl(n,0), Q on the even labels is the mod-2 norm of D_n, and Q = floor(w/2) | n <= 8 | 1.4 |
| `bd·mat·15` | `mat_codes_misc.py` | the Lagrangians of w on Cl(n,0) are the doubly-even self-dual codes: only at n = 8 (extended Hamming); Q has them at n = 2, 8 | n = 2, 4, 6, 8 | 1.5 |
| `bd·mat·16` | `mat_codes_misc.py` | explicit ungraded isomorphism Cl(p,q) = Cl(q+1, p-1) | p >= 1, n <= 6 | 1.5 |
| `bd·mat·1` | `mat_degenerate_cell.py` | the triple (V, Q, pi) does not fix the cell once r >= 1: every pair of cells with isomorphic triples and different r is listed (full isometry test) | n <= 4 | 0.1 |
| `bd·mat·2` | `mat_degenerate_cell.py` | w = pi + 2Q is a Z_4 refinement of the dot product exactly for r = 0 and for Cl(0,0,1), Cl(0,1,1) | n <= 5 | 0.1 |
| `bd·mat·3` | `mat_degenerate_cell.py` | for r >= 1 the sum of i^(pi+2Q) over all labels is not a Gauss sum; over the labels without a null bit (the quotient Cl(p,q)) it is (1+i)^p (1-i)^q | r >= 1, n <= 6 | 0.1 |
| `bd·mat·4` | `mat_degenerate_cell.py` | (V, Qt, pi) with the ternary square map determines the cell: isomorphic iff r and p - q mod 8 agree | all pairs, n <= 4 | 0.1 |
| `bd·mat·9` | `mat_null_part.py` | the label monoid with zero is Z_2^{p+q} x Rees(N^r) | all eps, n <= 4 | 0.4 |
| `bd·mat·10` | `mat_null_part.py` | the operators x -> (-1)^{\|b\|\|x\|} e_a x e_b span 4^{p+q} 2^r dimensions: Cl(p,q,r) is graded Azumaya over Lambda(R^r) | n <= 4 | 0.4 |
| `bd·mat·11` | `mat_null_part.py` | Loewy layers dim J^k/J^{k+1} = C(r,k) 2^{p+q} | n <= 5 | 0.4 |
| `bd·geo·13` | `geo_cartan.py` | Klein pairs of the projective step: [h, m] in m, [m, m] = -2s h; the involution is the mirror in e_n iff s != 0 | d = 2..5, s = -1, 0, 1 | 0.4 |
| `bd·geo·14` | `geo_cartan.py` | invariant forms on the bivectors: 2-dimensional; for e(3) the top-blade pairing is the Klein form, signature (3,3) | e(3), so(4), so(1,3) | 0.4 |
| `bd·geo·15` | `geo_cartan.py` | Euler-Arnold flow dP/dt = [P, B]: the invariant quadratics and the energy are conserved exactly | four algebras, seeded data | 0.4 |
| `bd·geo·16` | `geo_cartan.py` | D_eps = sum L_{e_i} on the labels: D^2 = (p - q) I, simplex boundary for eps = +1, ABS symbol sigma(v)^2 = \|v\|^2 | n = 1..7 | 0.4 |
| `bd·geo·17` | `geo_kepler.py` | Fock's map sends Kepler hodographs of E < 0, = 0, > 0 to geodesics of S^3, R^3, H^3 | three orbits | 0.1 |
| `bd·geo·7` | `geo_lorentz.py` | xi.grad xi = -c (T'/2) xi: the chart c = +1 is retarded (past horizon), c = -1 advanced (future horizon) | five horizons | 0.3 |
| `bd·geo·8` | `geo_lorentz.py` | a hyperbolic direction exists iff s = 1 or t = 1, for every r; strictly hyperbolic iff also r = 0 | n <= 6 | 0.3 |
| `bd·geo·9` | `geo_lorentz.py` | the bivectors of l-perp in Cl(1,n-1) have the brackets of the horizon algebra Cl(0,n-2,1) | n = 3..7 | 0.3 |
| `bd·geo·10` | `geo_lorentz.py` | a totally null plane in the non-degenerate Cl(2,2); null rotations in Cl(1,3); none with min(p,q) = 1 | n = 4, 5 | 0.3 |
| `bd·geo·11` | `geo_lorentz.py` | the Dirac gamma0 is a reference of the right action; the datum is a time orientation | Cl(1,3), five momenta | 0.3 |
| `bd·geo·12` | `geo_lorentz.py` | the unit even versors of Cl(1,2) form SL(2,R) (Lie algebra dimension 3, Killing (2,1)); {x xbar = 1} has dimension 6 | Cl(1,2), Cl(1,3) | 0.3 |
| `bd·geo·1` | `geo_pin.py` | Q = sigma_2(a) + \|a & N\| mod 2: the Pin extension class on the reflection group; commutators in {+-e_a} are the polar form of Q | n <= 9 (n <= 6) | 7.8 |
| `bd·geo·2` | `geo_pin.py` | w is a Z_4 enhancement of #^n RP^2; normalised Gauss sum exp(2 pi i (p-q)/8): clock = ABK invariant | n <= 8 | 7.8 |
| `bd·geo·3` | `geo_pin.py` | the Z_4 enhancements are the 2^n forms w_eps; the orbits of the isometries of dot are the ABK classes | n <= 8 | 7.8 |
| `bd·geo·4` | `geo_pin.py` | twisting by a class a: beta(w + 2 a.x) = beta(w) - 2 w(a); the mirror is the twist by w1 | n <= 7 | 7.8 |
| `bd·geo·5` | `geo_pin.py` | with null generators pi + 2Q is not an enhancement; weight 0 on the null bits gives Gauss sum 2^r G_D, weight 2 gives 0 | n <= 6, every r | 7.8 |
| `bd·geo·6` | `geo_pin.py` | ABS cokernels from the bit-rule types of Cl(0,k): Z2, Z2, 0, Z, 0, 0, 0, Z = KO^{-k}(pt) | k = 1..8 | 7.8 |
| `bd·alg·1` | `alg_core_bw.py` | H^2(Z_2^n; F_2) has dimension n(n+1)/2 and q(a) = c(a,a) is a complete invariant | n <= 4 | 6.4 |
| `bd·alg·2` | `alg_core_bw.py` | the super-commutation form of Cl(p,q) is the dot product; w refines it | n <= 6 | 6.4 |
| `bd·alg·3` | `alg_core_bw.py` | every graded-central-simple twisted group algebra of Z_2^n is Cl(p',q') or M(R)/M(H); BW class = Brown invariant | n <= 4 | 6.4 |
| `bd·alg·4` | `alg_core_bw.py` | explicit block isometries a -> a + \|a & B\| B between triples with equal p - q mod 8 | n <= 8 | 6.4 |
| `bd·alg·5` | `alg_core_bw.py` | the isometry class of Q alone gives the ungraded type R, R2, C, H, H2 | n <= 12 | 6.4 |
| `bd·alg·6` | `alg_core_bw.py` | the super-opposite has the square form of the mirror; Brown(w) + Brown(-w) = 0; the diagonal is a Lagrangian | n <= 5 | 6.4 |
| `bd·alg·7` | `alg_core_bw.py` | null generators: pi + 2Q is not the clock exponent; the clock sum is 2^r times the quotient Gauss sum | n <= 6, r = 1, 2 | 6.4 |
| `bd·alg·8` | `alg_core_bw.py` | the cell is Z^{p,q} mod 2; every characteristic vector c has c.c = p - q mod 8 (van der Blij) | n <= 6 | 6.4 |
| `bd·alg·9` | `alg_core_bw.py` | L_i = R'_i exactly for null generators; the left and twisted right actions span 4^{p+q} 2^r dimensions | n <= 5 | 6.4 |
| `bd·alg·18` | `alg_finite_fields.py` | no n = 2 sign-cochain algebra over F_l is a division algebra | l = 3..23 | 2.2 |
| `bd·alg·21` | `alg_finite_fields.py` | det L_x of the 512 sign-cochain algebras on Z_2^2: 510 have zero divisors, 2 are the quaternions | n = 2 | 2.2 |
| `bd·alg·19` | `alg_finite_fields.py` | the Brauer-Wall class of Cl(p,q) over F_l is the real clock reduced | n even <= 8, l = 3..13 | 2.2 |
| `bd·alg·20` | `alg_finite_fields.py` | over F_p the algebra with squares (a, 0) has J^2 = 0 and quotient F_p[e1]/(e1^2 - a), a field iff a is a non-residue | p = 3..13 | 2.2 |
| `bd·alg·10` | `alg_groups.py` | the blade group {+-e_a}: extraspecial 2^{1+n}_+ (type R) or _- (type H) for n even; centre cyclic iff type C for n odd | n <= 6 | 4.4 |
| `bd·alg·11` | `alg_groups.py` | O(Q) of Cl(0,6) is S_8, the 28 transvections are the transpositions | n = 6 | 4.4 |
| `bd·alg·12` | `alg_groups.py` | 270 maximal totally singular subspaces of Cl(0,8); the 30 through the top label are the doubly-even self-dual codes | n = 8 | 4.4 |
| `bd·alg·13` | `alg_groups.py` | the blade group of Cl(8k,0) is extraspecial of + type (Arf 0) | k = 1, 2, 3 | 4.4 |
| `bd·alg·23` | `alg_groups.py` | over F_2 the tables of Cl(2,0), Cl(1,1), Cl(0,2) coincide: F_2[Z_2^2], not semisimple | n = 2 | 4.4 |
| `bd·alg·14` | `alg_octonion.py` | Cayley-Dickson octonions on the labels: associator (-1)^det, alternative, normed; the Albuquerque-Majid cochain too | 3-bit labels | 6.3 |
| `bd·alg·15` | `alg_octonion.py` | the label automorphisms of O: 2^3.GL(3,2), order 1344, non-split | 3-bit labels | 6.3 |
| `bd·alg·16` | `alg_octonion.py` | split and null octonions as the trio of the doubling bit; the null octonions have J^2 = 0 and quotient H | 3-bit labels | 6.3 |
| `bd·alg·24` | `alg_octonion.py` | the alternative null-pattern cochains: 80, in 5 gauge classes, exactly 1 non-associative (CD(H, 0)) | n = 3 | 6.3 |
| `bd·alg·22` | `alg_octonion.py` | among the 128 quaternionic-line cochains on Z_2^3, 16 (one gauge orbit) are the octonions, 112 have zero divisors | n = 3 | 6.3 |
| `bd·alg·17` | `alg_octonion.py` | Der(O) = g2 (14), the stabiliser of e7 is su(3) (8); no label automorphism but 1 commutes with it | 3-bit labels | 6.3 |
| `bd·cat·1` | `cat_cell.py` | the triple does not fix the cell for r >= 1: 5 pairs of non-isomorphic cells share a triple (full isometry test) | n <= 3 | 0.2 |
| `bd·cat·2` | `cat_cell.py` | with r >= 1 the Gauss sum of pi + 2Q never has the Brown form with phase (p - q) pi/4 | r >= 1, n <= 6 | 0.2 |
| `bd·cat·3` | `cat_cell.py` | w_D (weight 0 on the null bits) is the pull-back of the r = 0 form; radical = null span; Gauss sum 2^r (1+i)^p (1-i)^q | all eps, n <= 5 | 0.2 |
| `bd·cat·4` | `cat_cell.py` | the Gauss sum of w_D equals that of the mother cell Cl(p+r,q+r) and 2^r times that of the quotient Cl(p,q) | r >= 1, n <= 6 | 0.2 |
| `bd·cat·19` | `cat_cohomology.py` | dim H^2 of the contracted label monoid is n(n+1)/2 - r | n <= 5, every r | 0.5 |
| `bd·cat·20` | `cat_cohomology.py` | the radical of every twisted contracted algebra is the span of the labels with a null bit | n <= 3 | 0.5 |
| `bd·cat·21` | `cat_cohomology.py` | the octonions are commutative in (Vec_{Z2^3}, phi = dF, R = F F^T), a symmetric category | 3-bit labels | 0.5 |
| `bd·cat·5` | `cat_frobenius.py` | the top-label form is non-degenerate and super-symmetric, parity n mod 2 | all eps, n <= 7 | 2.2 |
| `bd·cat·6` | `cat_frobenius.py` | the scalar part is symmetric, super-symmetric only for p = q = 0, non-degenerate iff r = 0 | n <= 6 | 2.2 |
| `bd·cat·7` | `cat_frobenius.py` | the parity of a homogeneous Frobenius form is forced only for Cl(0,0,r) | n <= 5 | 2.2 |
| `bd·cat·8` | `cat_frobenius.py` | the super-symmetric Frobenius forms are a torsor under the units of the super-centre Lambda(R^r) | n <= 5 | 2.2 |
| `bd·cat·22` | `cat_frobenius.py` | the window element of the top-label form is 2^n e_{1...1}, of square 0 iff r >= 1 | n <= 5 | 2.2 |
| `bd·cat·16` | `cat_functor.py` | halving phi_t is a natural isomorphism Cl o (halve) => Cl^0 | all eps, n <= 4 | 0.6 |
| `bd·cat·17` | `cat_functor.py` | quotient V -> V/N and mother map are algebra maps; Cl is a functor on q-preserving maps | r >= 1, n <= 4 | 0.6 |
| `bd·cat·18` | `cat_functor.py` | the labels are functorial in the frame only: the 90-degree rotor is not a square in Aut(V,Q,pi) | Cl(2,0) | 0.6 |
| `bd·cat·12` | `cat_modular.py` | theta = i^w is the metric group Sem^p (x) Sem-bar^q; Gauss sum (1+i)^p (1-i)^q | n <= 8 | 1.6 |
| `bd·cat·13` | `cat_modular.py` | a Lagrangian of (V, i^w) exists iff p - q = 0 mod 8; Furey's code is one of the 30 of Cl(0,8) | n <= 8 | 1.6 |
| `bd·cat·14` | `cat_modular.py` | w = x.x mod 4 on Z^{p,q}; the discriminant group of D_{p,q} with twists exp(2 pi i (p-q)/8) | n <= 4 (n <= 10) | 1.6 |
| `bd·cat·15` | `cat_modular.py` | the E_n roots in I_{1,n} have the Cartan Gram matrix, are orthogonal to k, det = k.k = 9 - n | n = 3..12 | 1.6 |
| `bd·cat·23` | `cat_modular.py` | from a Lagrangian: Cl(p,q) = End(S) as superalgebras for the cells of clock 0 | six cells, n <= 8 | 1.6 |
| `bd·cat·9` | `cat_morita.py` | the super-opposite of the bit rule with squares eps is the bit rule with squares -eps | all eps, n <= 6 | 8.4 |
| `bd·cat·10` | `cat_morita.py` | Cl(4,0) = Cl(0,4) as superalgebras, not with their reversions; Cl(5,1) = Cl(1,5) with them | n <= 6 | 8.4 |
| `bd·cat·11` | `cat_morita.py` | the graded product has radical dimension 2^{n+n'} - 2^{p+q+p'+q'}: the Morita classes form the monoid Z_8 x N | n + n' <= 5 | 8.4 |
| `bd·xck·1` | `xck_merge.py` | full isometry test: exactly 5 pairs of non-isomorphic cells share a triple; the horizon algebra Cl(0,2,1) is not among them | n <= 3 | 15.3 |
| `bd·xck·2` | `xck_merge.py` | the 30 Lagrangians of w on Cl(0,8) are the 30 maximal totally singular subspaces of Q through 1...1 | n = 8 | 15.3 |
| `bd·xck·3` | `xck_merge.py` | the weight-0 null-bit sum equals the mother cell sum and 2^r times the quotient sum | r >= 1, n <= 6 | 15.3 |
| `bd·xck·4` | `xck_merge.py` | Cl(2,2): a totally null plane, D != 0, D^2 = 0 | Cl(2,2) | 15.3 |
| `bd·xck·5` | `xck_merge.py` | Cl(1,1,1): hyperbolic direction e0, double root at the null covector e2 | Cl(1,1,1) | 15.3 |
| `bd·xck·6` | `xck_merge.py` | van der Blij: k.k = 9 - n = 1 - n mod 8 in I_{1,n}; c.c = p - q mod 8 for characteristic c in I_{p,q} | n = 3..13; n <= 7 | 15.3 |
| `bd·xck·7` | `xck_merge.py` | roots of E_8 orthogonal to e_8, e_7, ..., e_4: 240, 126, 72, 40, 20, 8 | n = 8 | 15.3 |
| `bd·xck·8` | `xck_merge.py` | the 30 Lagrangians of w on Cl(0,8) are one S_8-orbit (of the extended Hamming code) | n = 8 | 15.3 |
| `bd·hh·1` | `hh_graded.py` | d o d = 0 on the super Hochschild complex; HH^0 of Cl(p,q) in Cl(p,q,r) has dimension 2^r | p + q <= 2, r <= 2 | 6.7 |
| `bd·hh·2` | `hh_graded.py` | every Cl(p,q) is rigid: HH^0 = (1,0), HH^1 = HH^2 = 0 | 1 <= p + q <= 3 | 6.7 |
| `bd·hh·3` | `hh_graded.py` | the relative groups over Lambda(R^r) vanish in degrees 1, 2: every free graded L_r-algebra with fibre Cl(p,q) is Cl(p,q,r) | r = 1: p + q <= 3; r = 2: p + q <= 2 | 6.7 |
| `bd·hh·4` | `hh_graded.py` | over R[eps] every associative deformation of Cl(p,q) is the base change (Z = B) | p + q <= 3 | 6.7 |
| `bd·hh·5` | `hh_graded.py` | controls: HH^1, HH^2 of Cl(0,0,1) and HH^2 of degenerate cells over R are not zero | n <= 3 | 6.7 |
| `bd·hh·6` | `hh_graded.py` | M_(1\|1)(R) from matrix units: HH^0 = (1,0), HH^1 = HH^2 = 0, graded isomorphic to Cl(1,1) | n = 2 | 6.7 |
| `bd·rev·1` | `rev_reversion.py` | <x x~>_0 is positive definite iff q = 0, <x alpha(x~)>_0 iff p = 0 | n <= 10 | 2.6 |
| `bd·rev·2` | `rev_reversion.py` | blocks of five plus and one minus generators give Cl(p-4,q+4) = Cl(p,q) with reversion | p >= 5, q >= 1, n <= 10 | 2.6 |
| `bd·rev·3` | `rev_reversion.py` | same triple, isomorphic reversions iff equal or both indefinite | n <= 10 | 2.6 |
| `bd·rev·4` | `rev_reversion.py` | Clifford conjugation: the same partition; <x x->_0 positive definite iff p = 0 | n <= 10 | 2.6 |
| `bd·rev·5` | `rev_reversion.py` | the dagger e_a^-1: positive for every cell, partition = the triple partition | n <= 10 | 2.6 |
| `bd·rev·6` | `rev_reversion.py` | the global maps e_i -> +-e_sigma(i) w^k miss 13 isomorphic pairs; the block family is needed | n <= 10 | 2.6 |
| `bd·tor·1` | `tor_orbits.py` | unit timelike vectors: one orbit of the even Clifford group, two of the rotors: the datum is a time orientation (2 values) | Cl(1,n-1), n = 2..6 | 14.1 |
| `bd·tor·2` | `tor_orbits.py` | the complex structure J (a unit spatial bivector) under the spatial rotors: 2 orbits at n = 3 (J, -J), 1 for n = 4..6 | coordinate bivectors, n = 3..6 | 14.1 |
| `bd·tor·3` | `tor_orbits.py` | Witt splits (Fock vacua) of Cl(k,k): one orbit of the signed permutations (Pin), two of the even Clifford group and of the rotors (Spin) | coordinate splits, k = 1..4 | 14.1 |
| `bd·tor·4` | `tor_orbits.py` | the graded Lagrangians of a clock-0 cell (Furey's axes among them) are one orbit of the rotor-induced label group | clock-0 cells, n <= 8 | 14.1 |
| `bd·tor·5` | `tor_orbits.py` | Furey's blocks fix the torus H_F (gauge: Stab(omega) is transitive on the 30); the block partition of the 16 axes is a datum: 6720 partitions in 11 orbits | Furey's model | 14.1 |
| `bd·tor·6` | `tor_orbits.py` | orthonormal coordinate frames: one free orbit of the square-preserving signed permutations; 2 orbits of the even Clifford group; 4 or 2 of the rotors | n <= 5 | 14.1 |
| `bd·tor·7` | `tor_orbits.py` | reversion and Clifford conjugation are isomorphic iff n = 0 mod 4 and the cell is indefinite (e_i -> e_i I); reversion = dagger iff q = 0, conjugation = dagger iff p = 0 | n <= 8 | 14.1 |
| `bd·en·1` | `en_weyl.py` | the quadratic module E_n/2E_n: det 9 - n, radical {0, r} for n odd with q(r) = 1 iff n = 3 mod 4, Gauss sum, type, \|O(q)\| (brute force n <= 6) | n = 3..20 | 27.6 |
| `bd·en·2` | `en_weyl.py` | the image of W(E_n) in GL(E_n/2E_n) is all of O(q): certified lower bound = orbit-stabiliser upper bound = order formula | n = 3..20 | 27.6 |
| `bd·en·3` | `en_weyl.py` | \|W(E_n)\| = 12, 120, 1920, 51840, 2903040, 696729600; the kernel of W(E_n) -> O(q) is the centre (orders 2, 1, 1, 1, 2, 2) | n = 3..8 | 27.6 |
| `bd·en·4` | `en_weyl.py` | n odd: for n = 3 mod 4 the image is all of Sp_{n-1}(2) on V/r; for n = 1 mod 4 it holds the 2^{n-1} radical translations and maps onto O(V/r, q mod r) | n = 3..19 odd | 27.6 |
| `bd·en·5` | `en_weyl.py` | the W(E_n)-orbit of a root class is the set of nonsingular vectors outside rad b; the label-weight closure holds to n = 200: the image is generated by all orthogonal transvections | n = 4..20; closure n <= 200 | 27.6 |
| `bd·en·6` | `en_weyl.py` | Gosset descent: the roots of E_n orthogonal to e_n are the roots of E_{n-1}; the W(E_n)-orbit of e_n has 6, 10, 16, 27, 56, 240 elements | n = 3..8 | 27.6 |
| `bd·fur·1` | `fur_commutant.py` | the gauge algebra su(3) + su(2) + u(1)_Y of Furey's model: dimension 12, closed, commutes with omega and the six Peirce projectors | 16-dimensional model | 0.3 |
| `bd·fur·2` | `fur_commutant.py` | its commutant in M16(R) has dimension 22 (M4(R) on the two hypercharge-0 singlets, C on each of C3_O, C2_H, C_C), centre 7; with omega 14, centre 8 | 16-dimensional model | 0.3 |
| `bd·fur·3` | `fur_commutant.py` | an order-3 element of the commutant that normalises the Peirce blocks fixes every block and every cell of Fig. 1: block phases only | 16-dimensional model | 0.3 |
| `bd·fur·4` | `fur_commutant.py` | the exchange of the two hypercharge-0 singlet blocks commutes with the gauge algebra and omega and swaps d_R, (nu_e,e)_L, e_R with b_R, (nu_tau,tau)_L, tau_R; not an automorphism of O | 16-dimensional model | 0.3 |
| `bd·fur·5` | `fur_commutant.py` | 1344 label automorphisms of O; 32 of order 3 fix e7; none but the identity commutes with the colour su(3) | 16-dimensional model | 0.3 |
| `bd·kep·1` | `kep_fock.py` | exact Poisson algebra of L and the Laplace-Runge-Lenz vector A: {A_a, A_b} = -2 mu H L_ab, conserved, \|A\|^2 = mu^2 k^2 + 2 mu H \|L\|^2 | n = 2, 3, symbolic | 0.4 |
| `bd·kep·2` | `kep_fock.py` | one Inonu-Wigner family m(c), c = -2 mu E: so(n+1), e(n), so(n,1) for bound / parabolic / scattering orbits | n = 2, 3, symbolic | 0.4 |
| `bd·kep·3` | `kep_fock.py` | Fock's map is an isometry from g_c = 4\|dp\|^2/(c + \|p\|^2)^2, of constant curvature c, onto sphere / flat / hyperboloid | n = 2, 3, symbolic | 0.4 |
| `bd·kep·4` | `kep_fock.py` | Fock's map carries the Poisson algebra of (L, m(c)) onto the Killing algebra of its target | n = 2, 3; c = 1, 0, -1, 4, -1/4 | 0.4 |
| `bd·kep·5` | `kep_fock.py` | the Kepler algebra is the bivector algebra of Cl(-1,..,-1, s) of step 11 exactly for s = sign E = -eps (core·B16) | n = 2, 3 | 0.4 |
| `bd·kep·6` | `kep_fock.py` | every hodograph goes by Fock's map to a geodesic: a great circle of S^n (E < 0), a line (E = 0), a geodesic of H^n (E > 0) | n = 2, 3, any orbit | 0.4 |
| `bd·mjc·30` | `mjc_comma.py` | the iterated arrow categories C_(k+1) = C_k ↓ C_k of arXiv:2406.16884 are categories whose objects and arrows are the functors B_k -> C and B_(k+1) -> C (counted by backtracking): the k-th level is the category of commutative k-cubes in C | C = 1, 2, Kronecker, Z_2 (k <= 4); B_2, {1, e} (k <= 3) | 1.5 |
| `bd·mjc·31` | `mjc_comma.py` | C = 2: the levels have (objects, arrows) (2, 3), (3, 6), (6, 20), (20, 168), (168, 7581), the numbers of up-sets of B_k; C = 1 is constant; C = B_2 gives the squares; Arr(C x D) and Arr(C) x Arr(D) have equal counts | levels C_1..C_5 | 1.5 |
| `bd·mjc·32` | `mjc_comma.py` | over B_m the k-th level has M(k)^m objects (M = 2, 3, 6, 20) against the (j+2)^m chains of the nerve: equal for k = j = 0, 1, apart from k = j = 2 (the square against the chain [2]) | m <= 3; j, k <= 3 | 1.5 |
| `bd·mjc·1` | `mjc_labels.py` | (labels, ⊕) with a ⊕ b = a xor b when a and b = 0: defined on 3^n ordered pairs, commutative, unit 0, strongly (Kleene) associative and so associative as Def. 4 prints it; positive, cancellative, no inverses | n = 0..6 | 1.3 |
| `bd·mjc·2` | `mjc_labels.py` | the additive weights on (labels, ⊕) form a space of dimension n; popcount is the one with value 1 on every atom; the printed axiom "norm >= 1" of §3 fails exactly on the unit 0 | n = 0..5 | 1.3 |
| `bd·mjc·3` | `mjc_labels.py` | the translation category of (labels, ⊕) is B_n; enumerated: 2^n objects, 3^n arrows, 4^n composable pairs, (k+2)^n k-simplices of the nerve, the non-degenerate ones by inclusion-exclusion | n = 0..5, k <= 4 | 1.3 |
| `bd·mjc·4` | `mjc_labels.py` | control: random posets of 8 and 16 elements with about 3^n arrows have the nerve counts 3^n, 4^n, 5^n in 0 of 400 | n = 3, 4; 400 posets (seed 11) | 1.3 |
| `bd·mjc·5` | `mjc_labels.py` | D(S -> T) = T xor S is a functor B_n -> (labels, ⊕) and popcount D satisfies (9); the sum (8) on the arrows of B_n is single-valued and satisfies the printed associativity of Def. 4, the strong one fails from n = 3 | n = 2..4 | 1.3 |
| `bd·mjc·6` | `mjc_labels.py` | on disjoint labels the bit rule is (-1)^N(a,b) for every eps: the exterior algebra Cl(0,0,n); the untwisted algebra of the same partial monoid has commutator span 0 (from its table), the exterior one 2^(n-1) - 1: not isomorphic for n >= 2 | every eps for n <= 4, 40 for n = 5, 6 | 1.3 |
| `bd·mjc·7` | `mjc_labels.py` | the sign classes of (labels, ⊕): H^2 with +-1 coefficients is F_2^C(n,2), detected by the commutation signs; at n = 3, 128 cocycles among the 4096 tables, in 8 classes; the wedge is the class with every commutation sign -1; random tables are cocycles in 7 of 200 | n = 2..4 (seed 12) | 1.3 |
| `bd·mjc·8` | `mjc_labels.py` | the category algebra of B_n in M_(2^n)(R) = Cl(n,n): the units E_(T,S), S subset T, span 3^n and are Kronecker products of 2x2 units; with Jordan-Wigner creators the Cl(n,n) relations hold; creators and Peirce idempotents generate exactly 3^n, with the annihilators 4^n; inside the triangular algebra, equal to it only for n <= 1; radical of Loewy length n + 1 | n = 1..4 | 1.3 |
| `bd·mjc·33` | `mjc_ladder.py` | the support of the bit rule of Cl(p,q,r) has 4^(p+q) 3^r pairs and is the domain of ⊕ exactly for p + q = 0: the partial sum of the labels is the label monoid of the null cell, reached from any cell by the contraction eps -> 0 | every eps, n <= 4 | 0.1 |
| `bd·mjc·34` | `mjc_ladder.py` | from a relabelled B_n the order alone gives a ⊕ b = a v b when a ^ b is the bottom and the weight as the height, isomorphic to (labels, ⊕, popcount); random posets on 8 elements give the labels of B_3 in 0 of 200 | n <= 5 (seeds 61, 62) | 0.1 |
| `bd·mjc·35` | `mjc_ladder.py` | up (points, ⊕, popcount) and down (every cell contracted to eps = 0: support of the product, grading by word length in the generators) give the same structure; the sign on ⊕ is one class, the wedge, for every eps | all eps, n <= 4 | 0.1 |
| `bd·mjc·36` | `mjc_ladder.py` | translation-invariant positions P(S) = sum of the u_i over S make D(S -> T) = P(T xor S) a homomorphism to (R^2, +); injective as eq. (4) asks iff the subset sums are distinct: regular drawings never, the half-turn drawing for n = 2 only, u_i = (1, 2^i) always | n <= 8, exact | 0.1 |
| `bd·mjc·20` | `mjc_nerve.py` | (dim H^0, H^1, H^2) of the nerve, with d o d = 0: B_n (1,0,0); Kronecker and crown (1,1,0); {1, e}, Z_2, Z_3, S_3 and the pair groupoid (1,0,0) over R; Z_2 over F_2 and Z_3 over F_3 (1,1,1); the free monoid (1,1,0); with R^2 coefficients every dimension doubles | B_0..B_4 and a zoo | 0.4 |
| `bd·mjc·21` | `mjc_nerve.py` | D = delta P is a 1-cocycle on every composable pair (generic); the printed component rule of (8) agrees with D(g o f) exactly on the pairs with b1 = a2 | 109 categories (seed 42); B_3, 50 P (seed 43) | 0.4 |
| `bd·mjc·22` | `mjc_nerve.py` | the area cochain D(f) ^ D(g) and the Cl(2,0) product cochain are 2-cocycles and coboundaries (shoelace form); Stokes <A, c> = <B, dc> on random 2-chains: generic (the Leibniz rule) | 66 categories, 200 chains of B_3 (seed 44) | 0.4 |
| `bd·mjc·23` | `mjc_nerve.py` | on the Kronecker category a positive weight with w(f) != w(g) is not a coboundary: its class in H^1 is the datum the planar vectors miss; on B_3 every positive additive weight and popcount are coboundaries | Kronecker; B_3, 50 weights (seed 45) | 0.4 |
| `bd·mjc·24` | `mjc_nerve.py` | control: random posets on 8 elements have H^1 != 0 in 36 of 200; with a least element adjoined (1,0,0) in 200 of 200 (generic) | 200 posets (seed 45) | 0.4 |
| `bd·mjc·25` | `mjc_sheaf.py` | Alexandrov topology of B_n: 2, 3, 6, 20, 168 opens; the specialization order is inclusion; the sieves on S are the down-sets below S, 2, 5, 14, 49 in all | n = 0..4 (sieves n <= 3) | 0.7 |
| `bd·mjc·26` | `mjc_sheaf.py` | the cell as a presheaf S -> span{e_a : a subset of S}: the compatible families over an open D have dimension the number of points of D; gluing on covers by two and by three opens; random sub-presheaves glue as well (generic) | n <= 3 (three opens n <= 2); 200 controls (seed 51) | 0.7 |
| `bd·mjc·27` | `mjc_sheaf.py` | the projection Cl(T) -> Cl(S) is an algebra map exactly when eps_j = 0 for every j in T \ S (a presheaf of algebras only for the null cell); F(D) is a subalgebra of the exterior algebra exactly for the 2^n principal opens | all eps, all S subset T, n = 1..3; opens n <= 4 | 0.7 |
| `bd·mjc·28` | `mjc_sheaf.py` | the closing remark of §1, reading (A): the category of open sets of the discrete space of objects is B_2 for every category with two objects (the arrows are lost); its ring of opens is (F_2^n, xor, and), the restrictions are ring maps and the sections glue | four categories; n <= 4 | 0.7 |
| `bd·mjc·29` | `mjc_sheaf.py` | reading (B): the natural transformations y(a) -> y(b) are as many as the arrows a -> b (Yoneda keeps every morphism, brute force); the Alexandrov topology recovers random posets; in the idempotent completion of {1, e} the object e is a retract of 1, not isomorphic to it | six categories; 200 posets (seed 52) | 0.7 |
| `bd·mjc·37` | `mjc_sheaf.py` | the presheaf of arrows of the restricted category is a sheaf on the Alexandrov space of the reachability preorder and not on the discrete space as soon as an arrow joins distinct objects | six categories; 100 digraphs (seed 53) | 0.7 |
| `bd·mjc·9` | `mjc_sum.py` | all connected categories with at most 4 objects and 4 non-identity arrows up to isomorphism (584), by backtracking over composition tables; the monoids recounted by brute force, with the same numbers of classes | monoids of order <= 4 (5 by backtracking) | 7.0 |
| `bd·mjc·10` | `mjc_sum.py` | the sum (8) is single-valued exactly when no two non-identity arrows run A -> B and B -> A between distinct objects and the non-identity endomorphisms of each object commute | 584 enumerated and 300 random categories | 7.0 |
| `bd·mjc·11` | `mjc_sum.py` | the printed associativity of Def. 4 holds in every acyclic category and fails in 50 others (counted by kind); strong associativity fails already in acyclic ones and in B_3 | the same categories | 7.0 |
| `bd·mjc·12` | `mjc_sum.py` | a finite category has a positive additive weight iff it is acyclic: an exact witness phi(cod) - phi(dom) or an exact obstruction, and the linear program (scipy) agrees | 888 categories | 7.0 |
| `bd·mjc·13` | `mjc_sum.py` | control: 300 random concrete categories: (8) single-valued in 226, the printed associativity in 194, a positive weight in 123; all three in every acyclic one and in B_1..B_4 | seed 21 | 7.0 |
| `bd·mjc·15` | `mjc_weight.py` | positive additive weights on a zoo: yes for B_0..B_4, Kronecker, a non-cancellative acyclic category and three free categories (path length); no, with the exact obstruction, for {1, e}, Z_2, Z_3, S_3, the pair groupoid, a = b < c and a split idempotent; LP and exact agree | 15 categories; paths of length <= 8 | 0.9 |
| `bd·mjc·16` | `mjc_weight.py` | the additive weights on B_n (any sign) are the coboundaries phi(T) - phi(S), dimension 2^n - 1; the translation-invariant ones have dimension n; the crown has 4 weights against 3 coboundaries; random positive weights on B_3 are additive in 0 of 200 | n = 1..4 (seed 31) | 0.9 |
| `bd·mjc·17` | `mjc_weight.py` | the distance d(f, g) = norm(l) for f = l o g (§4) on B_n with popcount: d(f, f) = 0, the triangle law with equality, d(f, g) = norm(f) - norm(g), never symmetric off the diagonal: a Lawvere metric, not a classical one; in a non-cancellative category l1 o f = l2 o f forces w(l1) = w(l2) | n = 2..4 | 0.9 |
| `bd·mjc·18` | `mjc_weight.py` | on the labels d(S, T) = popcount(T \ S) satisfies d(S, S) = 0 and the triangle law, is asymmetric and additive along chains; its symmetrizations are the Hamming distance (by +) and a metric (by max) | n = 1..4 | 0.9 |
| `bd·mjc·19` | `mjc_weight.py` | control (generic): random posets carry a positive additive weight in 200 of 200, random transformation monoids in 0 of 200 | seeds 33, 34 | 0.9 |
| `bd·mja·16` | `mja_catalg.py` | (fg)(gf) = f(gg)f forces kappa(f, g) = (G^2 - norm(f)^2 norm(g)^2)/A^2 to be one number: -1 in reading R1 (norm = planar length) and R2a (wedge from the weights), several values in R2 with free additive weights, so no associative algebra; smallest case B_2 on the unit square, kappa = -1 and -2 | B_2..B_4, Hasse and random drawings (seed 4) | 0.5 |
| `bd·mja·17` | `mja_catalg.py` | (9) with the Euclidean norm holds on a composable pair exactly when the planar vectors are positively collinear: on every pair of the line drawing, on none of the Hasse and random drawings | B_2..B_4 (seed 5) | 0.5 |
| `bd·mja·18` | `mja_catalg.py` | the algebra generated by the arrow vectors in Cl(3,0) has dimension 1, 2, 4, 4, 4 (Hasse drawing of B_0..B_4), 4 for random drawings, 2 for the line drawing and the Kronecker category; e3, e13, e23, e123 are never reached; random posets give 1, 2 or 4 | B_0..B_4; 200 posets (seed 6) | 0.5 |
| `bd·mja·19` | `mja_catalg.py` | in the Hasse drawing D(S -> T) depends only on T \ S: 2^n - 1 vectors for 3^n - 2^n arrows; the sum (8) on vectors is the disjoint union of labels, on 3^n - 2^(n+1) + 1 pairs; Gram rank 2; random drawings keep 3^n - 2^n vectors | n = 1..4 | 0.5 |
| `bd·mja·20` | `mja_catalg.py` | Corollary 1: e_i^2 = 1 and e_i e_j = -e_j e_i in the bit-rule Cl(3,0); in B_1 with D(f) = e1 and weight 2, (13) gives f^2 = 4 against e1^2 = 1 | Cl(3,0); B_1 | 0.5 |
| `bd·mja·35` | `mja_catalg.py` | the lifted reading R3, x_f = D(f) + sqrt(norm(f)^2 - abs(D(f))^2) e3: x_f^2 = norm(f)^2 and the lifts of B_2 generate all of Cl(3,0); in the Hasse drawing of B_3 no arrow has a lift; the lifted inner product differs from (10) | B_2, B_3 | 0.5 |
| `bd·mja·1` | `mja_exterior.py` | on every disjoint pair the bit-rule sign is (-1)^N(a,b) for all 3^n sign vectors; every overlapping pair changes with eps | n = 0..6 | 7.6 |
| `bd·mja·2` | `mja_exterior.py` | an independent word engine (sorting by transpositions, e_i e_i = eps_i) equals the bit rule on every pair and every eps; the shuffle parity equals the disjoint sign | n <= 4; shuffles n <= 6 | 7.6 |
| `bd·mja·3` | `mja_exterior.py` | the partial sum is defined on 3^n ordered pairs; pairwise disjoint triples number 4^n, quadruples 5^n | pairs n <= 6, triples n <= 5, quadruples n <= 3 | 7.6 |
| `bd·mja·4` | `mja_exterior.py` | the truncated product (the bit rule on disjoint pairs, 0 elsewhere) is the bit rule of Cl(0,0,n) = Lambda(R^n) for every eps and is associative; disjoint blades graded-commute; on overlapping pairs the exponent is pc(a) pc(b) + pc(a AND b) | every eps, n <= 5 (four at n = 6) | 7.6 |
| `bd·mja·5` | `mja_exterior.py` | Chevalley: the left multiplication by a generator is wedge plus contraction, and iterating it gives the bit rule on every pair | every eps, n <= 4 | 7.6 |
| `bd·mja·6` | `mja_exterior.py` | the associated graded product of the grade filtration is the exterior product for every eps; the pairs of contraction order k number C(n,k) 3^(n-k) | every eps n <= 5; counts n <= 6 | 7.6 |
| `bd·mja·7` | `mja_exterior.py` | dim H^2 with F_2 coefficients: n(n+1)/2 for Z_2^n, C(n,2) for the partial monoid of disjoint labels, 0 for the nerve of B_n; restriction from the group onto the partial monoid with kernel the n squares; the bit-rule sign on B_n is a coboundary | n <= 4 (partial monoid n <= 5) | 7.6 |
| `bd·mja·8` | `mja_exterior.py` | noise: 16 of the 512 normalised sign tables on Z_2^2 are associative; 0 of 2000 random tables and 200 of 200 random cocycles on Z_2^3; on the disjoint labels of n = 3, 128 of 4096 tables in 8 classes of 16 | seeds 1, 2 | 7.6 |
| `bd·mja·37` | `mja_exterior.py` | the sum (8) on the arrows of B_n in a generic drawing is a commutative partial monoid with dim H^2 = 0, 2, 12, 50, each class determined by its commutation bits; the category itself has H^2 = 0 | n = 1..4 | 7.6 |
| `bd·mja·9` | `mja_incidence.py` | the bit-rule matrices of Cl(n,n) on the 2^n labels: the relations and 4^n independent products, Cl(n,n) = M_(2^n)(R); the creators are null with {c, c+} = 1, P_S the diagonal units; inside the bit-rule algebra the Witt nulls give orthogonal Peirce idempotents with one-dimensional Peirce spaces | n <= 4 (creators n <= 5; inner n <= 3) | 6.1 |
| `bd·mja·10` | `mja_incidence.py` | the P_S and the arrows c_i+ P_S generate the incidence algebra of B_n, of dimension 3^n, the span of the E_(T,S) and the Kronecker power of T_2; signed or unsigned creators give the same; E_(T,S) = s(T \ S, S) c+ P_S | n <= 5 | 6.1 |
| `bd·mja·11` | `mja_incidence.py` | its trace-form radical is the span of the strict arrows (3^n - 2^n), J^k has dimension sum_(j >= k) C(n,j) 2^(n-j), Loewy length n + 1; a proper subalgebra of the Borel algebra for n >= 2 | n <= 5 | 6.1 |
| `bd·mja·12` | `mja_incidence.py` | with k of the n modes reversed the algebra has dimension 4^k 3^(n-k) (all modes: Cl(n,n)); the creators alone give Lambda(R^n), the unsigned ones a commutative algebra of dimension 2^n; the xor permutations and the X_i lie outside the incidence algebra | n <= 4 | 6.1 |
| `bd·mja·13` | `mja_incidence.py` | Hochschild groups of the incidence algebra of B_n: HH^0 = R, HH^k = 0 (full bar complex for n <= 2, complex of strict chains for n <= 3); controls with nonzero groups: the crown, the octahedral poset, Lambda(R^1), Lambda(R^2) | n <= 3 | 6.1 |
| `bd·mja·14` | `mja_incidence.py` | dim Ext^k(S_S, S_T) = 1 exactly for k = popcount(T \ S): global dimension n, the quiver is the Hasse diagram, the relations are the commuting squares, the Euler characteristic is the Moebius function; Lambda(R^r): Ext^k = C(k+r-1, r-1); a control with Ext^2 = 2 | n <= 4; r = 1, 2 | 6.1 |
| `bd·mja·15` | `mja_incidence.py` | noise: random posets give an incidence subalgebra of dimension the number of comparable pairs (3^n in a few); non-transitive relations give no subalgebra | n = 2, 3; 200 each (seed 3) | 6.1 |
| `bd·mja·32` | `mja_ladder.py` | brute-force sizes: defined pairs and arrows 3^n, composable pairs 4^n, chains (k+2)^n and strict chains by inclusion-exclusion, Euler characteristic 1, Hasse edges n 2^(n-1), squares C(n,2) 2^(n-2) | n = 0..6 (composable pairs and chains n <= 5) | 0.1 |
| `bd·mja·33` | `mja_ladder.py` | isomorphism classes of the cells at the rungs D0 (r and p - q mod 8), D1 (the triple, full isometry test) and D2 (one class, Lambda): D0 and D1 agree exactly when r = 0 | n = 1..4 | 0.1 |
| `bd·mja·36` | `mja_ladder.py` | the partial sum is definable from the order (a ⊕ b = a v b when a ^ b is the bottom), and the order and the partial monoid have the same n! automorphisms | n <= 4 (automorphisms n <= 3) | 0.1 |
| `bd·mja·21` | `mja_norms.py` | the labels with ⊕ and popcount satisfy (8) and (9): commutative, unit 0, Kleene-associative, popcount additive on the 3^n defined pairs, no inverses | n <= 6 (triples n <= 4) | 5.4 |
| `bd·mja·22` | `mja_norms.py` | Q(a xor b) = Q(a) + Q(b) + pc(a) pc(b) + pc(a AND b) mod 2 for every non-degenerate eps; random cocycles graded-commute on disjoint labels exactly when all generators anticommute | n <= 6; 300 cocycles (seed 8) | 5.4 |
| `bd·mja·23` | `mja_norms.py` | w = pi + 2Q: w(a xor b) = w(a) + w(b) + 2 pc(a AND b) mod 4 and w(a) = sum of eps_i a_i mod 4; the quadratic forms Q' with pi + 2Q' additive on disjoint labels are exactly the 2^n Clifford forms | n <= 6 (forms n <= 5) | 5.4 |
| `bd·mja·24` | `mja_norms.py` | on labels e_a^2 = pc(a)^2 exactly for the generators with eps = +1; disjoint blades anticommute exactly when pc(a) pc(b) is odd; 0 is the only label orthogonal to all; 18 of the 42 pairs of distinct blades of Cl(3,0) commute with scalar product 0 | every eps, n <= 5 | 5.4 |
| `bd·mja·25` | `mja_norms.py` | planar integer vectors: abs(u + v) = abs(u) + abs(v) exactly for the positively collinear pairs, Pythagoras exactly for the orthogonal ones, both only with a zero vector | [-4, 4]^2, 6561 pairs | 5.4 |
| `bd·mja·26` | `mja_semiring.py` | the label basis has a negative structure constant for every eps with n >= 2 (and for eps = -1 at n = 1); no sign gauge removes them; the exterior part has (3^n + x_n)/2 non-negative constants with x_n = 2 x_(n-1) + x_(n-2) | n <= 5 (gauges n = 2, 3; x_n n <= 6) | 1.4 |
| `bd·mja·27` | `mja_semiring.py` | sign-free algebras: the group algebra of F_2^n (semisimple, commutative) and R_0[M] (local, commutative) against Lambda (local, commutator space 2^(n-1) - 1); dropping signs fails over R; the tables are associative over the Boolean semiring | n <= 4 | 1.4 |
| `bd·mja·28` | `mja_semiring.py` | non-negative structure constants: the matrix units of Cl(n,n), with the incidence units closed under products, and the idempotents of Cl(1,0); for C none of 20000 and for H none of 5000 random bases | n <= 3; seed 7 | 1.4 |
| `bd·mja·29` | `mja_zero.py` | Def. 4, clause 1: of the 5^n triples with a ⊕ b and b ⊕ c defined, 4^n have both bracketings and the rest neither; the same on the arrows of B_n with (8); on B_3, 48 of 361 arrow pairs have f.g < 0, and distributivity holds in R1 and fails in R2 | labels n <= 5; B_2, B_3 | 0.1 |
| `bd·mja·30` | `mja_zero.py` | the arrow vectors of B_3 multiply associatively in Cl(2,0) (R1 exact, R2a floats); controls: the Cayley-Dickson sign is non-associative on 168 of 512 triples, the 6 disjoint ones among them; a Petit algebra has associator 2i t | B_3; 3-bit labels | 0.1 |
| `bd·mja·31` | `mja_zero.py` | the paper's 0 = norm(0) e3 is the zero element; e3, the null generator of Cl(3,0,1), label 0, an identity arrow, the identity of an outside object and the global unit compared by square, annihilator and unit role: the 0 of (8) acts as the global unit | Cl(3,0), Cl(3,0,1), B_3 + {X} | 0.1 |
| `bd·mjg·17` | `mjg_cube.py` | the cover relations of B_n are the pairs at Hamming distance 1: the Hasse diagram is the n-cube graph, n-regular, and every edge flips the parity | n = 1..7 | 0.6 |
| `bd·mjg·18` | `mjg_cube.py` | the faces of [0,1]^n, as argmax sets of integer functionals, are exactly the 3^n interval vertex sets, of dimension the weight; f-vector C(n,k) 2^(n-k), Euler characteristic 1 | faces n <= 4; f-vectors n <= 7 | 0.6 |
| `bd·mjg·19` | `mjg_cube.py` | the composable pairs S <= T <= U are the (face, vertex) incidences of the cube (faces as argmax sets), 4^n; the composite is the join of the two faces; nerve chains (k+2)^n, strict ones by inclusion-exclusion | n <= 5, k <= 3 | 0.6 |
| `bd·mjg·20` | `mjg_cube.py` | S -> T to the signed set (+S, -complement of T) is a bijection onto the faces of the n-orthoplex with the empty face, n minus the weight vertices, inclusion reversed | n <= 5 | 0.6 |
| `bd·mjg·12` | `mjg_frames.py` | e3 of Cl(3,0) is a unit vector orthogonal to the plane; in Cl(2,0,1) the null generator spans the radical, so (11) holds in Cl(3,0) and fails there; the extra square s of the Kepler trio; label 0 is the unit and the products sharing the null bit are 0 | Cl(3,0), Cl(2,0,1), Cl(0,0,2), Cl(-1,-1,-1,s) | 0.3 |
| `bd·mjg·13` | `mjg_frames.py` | in Cl(2,0,1) rotors and translators act on points as isometries and compose as motions; the bivectors close as e(2); the planar vector D is an ideal point, invariant under translators and turned by rotors | 200 seeded motors | 0.3 |
| `bd·mjg·14` | `mjg_frames.py` | the rotor 1 + (v/2) e0 e1 of Cl(d,0,1) is a Carroll boost on vectors and a Galilean boost on points; in Cl(1,3) the null rotation 1 + (w/2)(e0 + e3) e1 is a Lorentz transformation acting as x -> x + c w u with u = t - z invariant | d = 2, 3; Cl(1,3), 50 seeded points | 0.3 |
| `bd·mjg·16` | `mjg_frames.py` | moving P by a similarity, an affine map, a reflection and a diffeomorphism keeps the category, the weights, injectivity and exactness; angles only under the similarity; the orientation of the composable triangles under the orientation-preserving affine maps, reversed by the reflection, changed on 10 of 110 by the diffeomorphism | Petrie view of B_4 | 0.3 |
| `bd·mjg·29` | `mjg_ladder.py` | enumerated sizes against closed forms: 3^n pairs and arrows, 3^n - 2^n, n 2^(n-1), 4^n, 4^n - 2.3^n + 2^n, (k+2)^n, C(n,k), the first Betti number 3^n - 2^(n+1) + 1 of the A-space graph (components by union-find), the f-vector | n = 0..6 (nerve n <= 4) | 0.1 |
| `bd·mjg·30` | `mjg_ladder.py` | support and grade of Cl(0,0,n) are the partial sum with additive popcount; the bit rule on disjoint labels is eps-independent; the maps from the labels to Z_3 additive on the partial sum are exactly the 3^n maps L o x (all maps tested); random positions are not additive | n <= 6; eps n <= 4; Z_3 n <= 3 | 0.1 |
| `bd·mjg·1` | `mjg_positions.py` | the Petrie cube view (the Cube view of the shapes page) is injective exactly for n = 1, 2, 4, 8; for odd n one coincidence; the relation for an odd prime factor; the isometric view is injective only for n = 1; Gaussian views are injective | n <= 8; Gaussian n <= 6 | 1.0 |
| `bd·mjg·2` | `mjg_positions.py` | unit-column cube views: the weight is at least the planar length on every non-identity arrow, with equality exactly on the cover edges; random P violate it | Petrie n <= 6; 100 views per n <= 5 | 1.0 |
| `bd·mjg·3` | `mjg_positions.py` | the weight is additive on every composable non-identity pair, the planar Euclidean length exactly on the positively collinear ones | n = 2..6, three views | 1.0 |
| `bd·mjg·4` | `mjg_positions.py` | the printed component rule of (8) gives the vector of the composite on 34 of 1400 composable pairs (Petrie and random views); it is rarely symmetric or associative | n = 2..5 | 1.0 |
| `bd·mjg·5` | `mjg_positions.py` | reading R1 (norm = planar length) with (9) forces P({0}) = P({1}) in B_2 (exact intersection of two circles): no injective P for n >= 2; line drawings satisfy it; random P violate (9) | B_2 exact; B_3, 50 heights | 1.0 |
| `bd·mjg·6` | `mjg_positions.py` | reading R3: a linear phi with phi(m_i) = 1 exists for the Petrie view at n = 2 and for the time view, not for Petrie n = 3..6; for the time view a norm max(abs(x), c abs(y)) gives every weight, (9) and the triangle inequality | n = 1..6 | 1.0 |
| `bd·mjg·7` | `mjg_positions.py` | positions additive on the partial sum: every cube view, no random P; cube views carry 2^n - 1 distinct planar vectors, random P 3^n - 2^n | n = 1..6 | 1.0 |
| `bd·mjg·33` | `mjg_positions.py` | the Laplacian of the n-cube graph has smallest nonzero eigenvalue 2, of multiplicity n, with the centred coordinates as eigenspace; the spectral drawing is additive on the partial sum; random relabellings are not | n <= 6; 200 relabellings per n | 1.0 |
| `bd·mjg·22` | `mjg_topology.py` | the order complex of B_n on the cube vertices is the standard triangulation of [0,1]^n: n! simplices of volume 1/n!, random points covered once; Euler characteristic 1 | n <= 5 (Euler n <= 6) | 1.1 |
| `bd·mjg·23` | `mjg_topology.py` | the proper part of B_n is a sphere S^(n-2) over Q and F_2; reduced Euler characteristic = mu(0, [n]) = (-1)^n | n = 2..5 | 1.1 |
| `bd·mjg·24` | `mjg_topology.py` | the cube complex on the arrows with the bit-rule sign: d^2 = 0, the cube is acyclic and its boundary is a sphere S^(n-1), over Q and F_2 | n <= 5 | 1.1 |
| `bd·mjg·25` | `mjg_topology.py` | the A-space as a graph has b_1 = 3^n - 2^(n+1) + 1 for B_n, the nerve b_1 = 0; parallel arrows and the free square b_1 = 1; Z_2: graph b_1 = 1, nerve H_1 = Z/2 | B_1..B_4 and three categories | 1.1 |
| `bd·mjg·26` | `mjg_topology.py` | the area cochain D(f) ^ D(g) is a 2-cocycle and the coboundary of the shoelace cochain (exact); with F(f) = norm(f) D(f)/abs(D(f)) it is not a cocycle | n = 2..4, 5 seeded P; Petrie B_4 | 1.1 |
| `bd·mjg·27` | `mjg_topology.py` | the bit-rule sign on the composable pairs of B_n is eps-independent, a 2-cocycle and the coboundary of c(S -> T) = s(S, T \ S); the nerve has no reduced F_2 cohomology; H^2(Z_2^n; F_2) = n(n+1)/2 | n <= 5; group n <= 3 | 1.1 |
| `bd·mjg·28` | `mjg_topology.py` | an integer weight additive on disjoint labels is a Z_4 refinement of the dot product mod 4 iff every atom weight is odd; then it is w_eps of the bit rule, Gauss sum (1+i)^p (1-i)^q; control x^T M x mod 4 | n <= 6, 100 vectors per n; 200 M (seed 28) | 1.1 |
| `bd·mjg·9` | `mjg_vectors.py` | composable cube vectors are orthogonal, the weight is l1 = (l2)^2 and additive; v(f)^2 = sum of eps over T \ S, additive, positive on every arrow only for eps = (1, .., 1), equal to the squared weight only on edges; diagonal quadratic forms are additive, non-diagonal ones not | n <= 6; eps n <= 4; 400 forms (seed 11) | 1.2 |
| `bd·mjg·10` | `mjg_vectors.py` | the additive weights on B_n have dimension 2^n - 1 (height differences); the commutative square with weights (1,1,1,2) has no additive extension, the free square has one; random posets: dim Z^1 - (objects - components) = b_1 | n <= 4; 200 posets (seed 13) | 1.2 |
| `bd·mjg·11` | `mjg_vectors.py` | Petrie view n = 4: f.g = norm(f) norm(g) cos(theta) differs from D(f).D(g) exactly where cos != 0 and a weight differs from the length; it is the scalar part of F(f) F(g) in Cl(2,0); distributivity fails on 6308 of 7150; line drawings are distributive | Petrie B_4 | 1.2 |
| `bd·mjg·32` | `mjg_vectors.py` | every factorisation f = l o g: norm(l) = norm(f) - norm(g), so the distances of §4 are weight differences; the undirected Hasse distance is the Hamming distance, a metric | n <= 5 (metric n <= 4) | 1.2 |

Info lines (printed as `info <id>  …`, not counted as checks, listed in `summary.info` of the json):

- `bd·mat·14` (`mat_En_trio.py`): the Brown invariant 1 − n of I_{1,n}, the Gauss–Milgram phase n of E_n and the clock n of Cl(n,0), for
  n = 3..8. The three numbers are read off the signature formulas, nothing is recomputed, so the line is a read-off and cannot back a `checked` tag.
- `bd·mjc·38` (`mjc_labels.py`): the sizes 2^n, 3^n, 4^n, 5^n of the objects, arrows, composable pairs and 3-simplices of B_n and the dimensions
  2^n, 3^n, 4^n of the exterior algebra, the category algebra and Cl(n,n), n = 0..6, from their formulas: a table.
- `bd·mjc·14` (`mjc_sum.py`): "two non-identity arrows compose to an identity" and "a non-identity split monomorphism exists" are one sentence,
  a definition; the line counts such categories (249 of the 884 enumerated and random ones) and says why 0 cannot stand for that identity
  under (9).
- `bd·mja·34` (`mja_ladder.py`): the algebra dimension at each rung of the ladder up, read off the checks that compute it.
- `bd·mjg·21` (`mjg_cube.py`): the A-space chooses a side of the plane for each non-identity arrow, 2^(3^n - 2^n) choices; nothing in it is
  computed against the faces.
- `bd·mjg·15` (`mjg_frames.py`): a Galilean boost of the arrow events (norm(f), D(f)) is the move P -> P + v h when the weight is
  h(cod) - h(dom), by substitution: a reading; the line prints the counts of the velocities that make P + v h not injective and the
  difference -v of the two composites of the free square.
- `bd·mjg·31` (`mjg_ladder.py`): the size table of the rungs, one row per n = 0..6.
- `bd·mjg·8` (`mjg_positions.py`): the printed axiom "norm >= 1" of §3 on the popcount weight, the zero vector and an edge scaled by 1/2:
  constants and a definition, a read-off (bd·mjc·2 computes the axiom on the labels).

In the lines of the families mjc, mja, mjg a part of a statement that holds by definition or by an identity (a telescoping sum, an identity
of popcounts, an antisymmetric wedge) is printed as a remark and is not tested. The rungs U0..U7 (structure added to the 2^n points) and
D0..D5 (structure forgotten from the cell) named in the rows are the two ladders on the labels, listed in the docstrings of `mjc_ladder.py`
and `mja_ladder.py`; the readings R1, R2, R2a, R3 of the norm are defined in the docstrings of `mja_catalg.py` and `mjg_positions.py`.

Two checks recompute an identity that holds by construction; they confirm the computation, they do not test a convention:
`bd·cat·3` (the form w_D is core·B1 on the non-null bits) and `bd·geo·15` (the conservation laws hold for every Lie–Poisson flow with a
symmetric inertia map, whatever the sign of the flow).
