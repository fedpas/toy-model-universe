#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mjc_ladder.py: where the two ladders on the labels F_2^n meet: the partial sum ⊕ as the label monoid of the null cell, the step from the
cells to the exterior algebra as the contraction eps -> 0, and the order B_n as a structure that already defines ⊕ and the weight.
The ladder up adds one structure at a time to the 2^n bare points (U0): U1 the disjoint partial sum a ⊕ b (a and b = 0), unit 0; U2 the
weight popcount; U3 the order S subset T with its arrows (the category B_n); U4 positions P: labels -> R^2 and the planar vectors
D(S -> T) = P(T) - P(S) of arXiv:2403.19689 (v3); U5 the sign on disjoint labels; U6 the squares eps (the cell); U7 the clock.  The ladder
down forgets one structure at a time, starting from the cell with its clock and null part (D0): D1 the triple (V, Q, pi); D2 the exterior
algebra Cl(0,0,n); D3 ⊕ on disjoint labels with the weight; D4 the order B_n; D5 the 2^n points.

    python3 selfcheck/bridges/mjc_ladder.py              one line per check, ids bd·mjc·33 .. bd·mjc·36; exit 1 on any FAIL
    python3 selfcheck/bridges/mjc_ladder.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only; deterministic (seeds 61, 62), under 1 s; runs from any folder, reads and writes no file.
  bd·mjc·33  the support of the bit rule (the pairs (a, b) with e_a e_b != 0) of Cl(p,q,r) has 4^(p+q) 3^r elements (every eps, n <= 4); it is the
             domain of the partial sum ⊕ exactly when p + q = 0: the paper's partial addition on the labels is the label monoid of the null cell
             Cl(0,0,n) (bd·mat·9, bd·cat·19 at r = n), and the ladder step D1 -> D2 is the contraction eps -> 0 (the total xor becomes ⊕), not a
             forgetful map; the weight that survives the contraction is the grading popcount.
  bd·mjc·34  D3 and D4 carry the same information on the labels: from a randomly relabelled copy of B_n (seed 61, n <= 5) the order alone defines
             a ⊕ b = a v b when a ^ b = bottom and ||a|| = height of a, and the result is isomorphic to (labels, ⊕, popcount) by the relabelling;
             control: random posets on 8 elements (seed 62) are lattices in k of 200 and give a partial commutative monoid with additive height
             isomorphic to the labels of B_3 in 0 of 200 (printed).
  bd·mjc·35  the two orders of entering the structure give the same rung U2 = D3 for every n <= 4: up, (points) -> ⊕ -> popcount; down, from every
             cell Cl(p,q,r) (all eps): contract to eps = 0, take the support of the product (⊕) and the grading by word length in the
             generators, computed from the contracted table; the two are equal, and what the down route forgets on the way, the sign on ⊕,
             is one class for every eps (the wedge class, bd·mjc·7).
  bd·mjc·36  rung U4 has no rung in the down ladder: positions are an input.  Translation-invariant positions P(S) = sum of u_i over i in S
             (a zonotope drawing of the cube) make D(S -> T) = u(T xor S) a homomorphism of (labels, ⊕) to (R^2, +) (D = P(T) - P(S) is
             additive on composable arrows for every P, by telescoping: not tested); the injectivity that eq. (4) of the paper asks holds iff
             the 2^n subset sums are distinct.  Exact integer test (Gaussian integers for the 4th roots, Eisenstein for the 3rd and 6th):
             the regular drawings (u_i the n-th roots of unity, n = 2, 3, 4, 6) are never injective (all of them sum to 0, the empty sum);
             the half-turn drawing (angles pi i / n) is injective for n = 2 and not for n = 3 (u_0 + u_2 = u_1); u_i = (1, 2^i) is injective
             for n <= 8.
"""
import sys, random, itertools

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if not SABOTAGE: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    else: print('  sabotaged input, what the check sees: ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def osum(a, b): return (a | b) if not (a & b) else None

# ================================================================== bd·mjc·33  support of the product; ⊕ = the label monoid of the null cell
def check33(sab=False):
    ok = True; table = {}
    for n in range(0, 5):
        for eps in itertools.product((1, -1, 0), repeat=n):
            p = eps.count(1); q = eps.count(-1); r = eps.count(0)
            supp = {(a, b) for a in range(1 << n) for b in range(1 << n) if sgn(a, b, eps) != 0}
            if sab: supp = {(a, b) for a in range(1 << n) for b in range(1 << n)}   # sabotage: the support taken to be all pairs
            dom_osum = {(a, b) for a in range(1 << n) for b in range(1 << n) if osum(a, b) is not None}
            if len(supp) != 4 ** (p + q) * 3 ** r: ok = False
            if (supp == dom_osum) != (p + q == 0): ok = False
            table[(n, p, q, r)] = len(supp)
    sample = {k: v for k, v in table.items() if k[0] == 3}
    return report('bd·mjc·33', ok, f'support of the bit rule of Cl(p,q,r) = 4^(p+q) 3^r pairs (every eps, n <= 4; at n = 3 by (n,p,q,r): {sample}); it is the domain of ⊕ exactly when p + q = 0: the partial sum of the labels is the label monoid of the null cell, reached from any cell by the contraction eps -> 0')

# ================================================================== bd·mjc·34  the order defines ⊕ and the weight
def from_order(m, leq):
    """from an abstract finite poset: bottom, joins, meets (None if missing), the partial sum a v b when a ^ b = bottom, the height"""
    def lub(a, b):
        ups = [c for c in range(m) if leq[a][c] and leq[b][c]]
        least = [c for c in ups if all(leq[c][d] for d in ups)]
        return least[0] if least else None
    def glb(a, b):
        downs = [c for c in range(m) if leq[c][a] and leq[c][b]]
        great = [c for c in downs if all(leq[d][c] for d in downs)]
        return great[0] if great else None
    bots = [c for c in range(m) if all(leq[c][d] for d in range(m))]
    if not bots: return None
    bot = bots[0]
    plus = {}
    for a in range(m):
        for b in range(m):
            g = glb(a, b)
            if g is None: return None
            if g == bot:
                j = lub(a, b)
                if j is None: return None
                plus[(a, b)] = j
    height = {}
    for a in sorted(range(m), key=lambda x: sum(leq[y][x] for y in range(m))):
        below = [b for b in range(m) if leq[b][a] and b != a]
        height[a] = 0 if not below else 1 + max(height[b] for b in below)
    return bot, plus, height
def iso_to_labels(m, bot, plus, height, n):
    """is (elements, plus, height) isomorphic to (labels of B_n, ⊕, popcount)?  atoms = height 1; the map sends a to the set of atoms below"""
    if m != 1 << n: return False
    atoms = [a for a in range(m) if height[a] == 1]
    if len(atoms) != n: return False
    # the image of a: the sum of the atoms in its decomposition; compute recursively from plus
    img = {bot: 0}
    for k, a in enumerate(atoms): img[a] = 1 << k
    changed = True
    while changed:
        changed = False
        for (a, b), c in plus.items():
            if a in img and b in img and c not in img and not (img[a] & img[b]): img[c] = img[a] | img[b]; changed = True
    if len(img) != m or len(set(img.values())) != m: return False
    if any(pc(img[a]) != height[a] for a in range(m)): return False
    lab_plus = {(img[a], img[b]): img[c] for (a, b), c in plus.items()}
    return lab_plus == {(x, y): x | y for x in range(m) for y in range(m) if not (x & y)}
def check34(sab=False):
    ok = True; rng = random.Random(61); rec = {}
    for n in range(0, 6):
        perm = list(range(1 << n)); rng.shuffle(perm); inv = {perm[x]: x for x in range(1 << n)}
        m = 1 << n
        leq = [[((inv[a] & inv[b]) == inv[a]) for b in range(m)] for a in range(m)]
        if sab and n == 3: leq = [[(inv[a] <= inv[b]) for b in range(m)] for a in range(m)]   # sabotage: B_3 replaced by the chain of its 8 labels
        res = from_order(m, leq)
        good = res is not None and iso_to_labels(m, res[0], res[1], res[2], n)
        rec[n] = good
        if not good: ok = False
    rng2 = random.Random(62); lattices = 0; iso = 0
    for _ in range(200):
        m = 8; up = [1 << i for i in range(m)]
        for i in range(m - 1, -1, -1):
            for j in range(i + 1, m):
                if rng2.random() < 0.47: up[i] |= up[j]
        leq = [[bool(up[a] >> b & 1) for b in range(m)] for a in range(m)]
        res = from_order(m, leq)
        if res is not None: lattices += 1; iso += iso_to_labels(m, res[0], res[1], res[2], 3)
    if iso != 0: ok = False
    return report('bd·mjc·34', ok, f'from a randomly relabelled B_n (seed 61) the order alone gives a ⊕ b = a v b when a ^ b = bottom and ||a|| = height, isomorphic to (labels, ⊕, popcount): {rec}; control: random posets on 8 elements (seed 62): bottom, all meets and the needed joins exist in {lattices} of 200, the result is the labels of B_3 in {iso} of 200')

# ================================================================== bd·mjc·35  the two routes to U2 = D3
def word_length(n, eps0):
    """the grading of the algebra with squares eps0: for each label a, the least number of generators e_i whose product is +-e_a (breadth-first
    search on the multiplication table; a product with sign 0 is not a step)"""
    dist = {0: 0}; frontier = [0]
    while frontier:
        nxt = []
        for x in frontier:
            for i in range(n):
                if sgn(x, 1 << i, eps0) != 0 and (x ^ (1 << i)) not in dist: dist[x ^ (1 << i)] = dist[x] + 1; nxt.append(x ^ (1 << i))
        frontier = nxt
    return dist
def check35(sab=False):
    ok = True; agree = total = 0; classes = set()
    for n in range(0, 5):
        up_route = ({(a, b): a | b for a in range(1 << n) for b in range(1 << n) if not (a & b)}, {a: pc(a) for a in range(1 << n)})
        for eps in itertools.product((1, -1, 0), repeat=n):
            eps0 = tuple(0 for _ in eps) if not sab else eps            # sabotage: no contraction, the support of the cell itself
            supp = {(a, b): a ^ b for a in range(1 << n) for b in range(1 << n) if sgn(a, b, eps0) != 0}
            grading = word_length(n, eps0)
            total += 1; agree += (supp, grading) == up_route
            if n == 3: classes.add(tuple(sgn(1 << i, 1 << j, eps) * sgn(1 << j, 1 << i, eps) for i in range(n) for j in range(i + 1, n)))
    ok = agree == total and classes == {(-1, -1, -1)}
    return report('bd·mjc·35', ok, f'up (points -> ⊕ -> popcount) and down (cell -> contraction eps -> 0 -> support of the product and grading by word length in the generators) give the same structure in {agree} of {total} cells (all eps, n <= 4); commutation signs of the basis on ⊕ for the 27 cells with n = 3: {classes} (one class, the wedge)')

# ================================================================== bd·mjc·36  positions are an input: translation-invariant drawings and (4)
def eis(k, m):
    """the m-th root of unity zeta^k for m in (1, 2, 3, 4, 6) as an exact pair (a, b) meaning a + b w, w = exp(2 pi i / 3) (Eisenstein) or
    a + b i (Gaussian, m = 4)"""
    if m == 4: return [(1, 0), (0, 1), (-1, 0), (0, -1)][k % 4]
    six = [(1, 0), (1, 1), (0, 1), (-1, 0), (-1, -1), (0, -1)]          # 1, -w^2 = 1 + w, w, -1, -1 - w = w^2, -w  (powers of exp(i pi/3))
    if m == 6: return six[k % 6]
    if m == 3: return six[(2 * k) % 6]
    if m == 2: return six[(3 * k) % 6]
    return (1, 0)
def subset_sums_distinct(us):
    sums = set()
    for S in range(1 << len(us)):
        s = (sum(us[i][0] for i in range(len(us)) if S >> i & 1), sum(us[i][1] for i in range(len(us)) if S >> i & 1))
        if s in sums: return False
        sums.add(s)
    return True
def check36(sab=False):
    ok = True; regular = {}; half = {}; generic = {}
    for n in (2, 3, 4, 6):
        regular[n] = subset_sums_distinct([eis(i, n) for i in range(n)])
    for n in (2, 3):                                                      # angles pi i / n = the (2n)-th roots zeta_(2n)^i, i < n (exact for 2n = 4, 6)
        half[n] = subset_sums_distinct([eis(i, 2 * n) for i in range(n)])
    for n in range(1, 9):
        us = [(1, 2 ** i) for i in range(n)]
        if sab: us = [(1, 1 + (i % 2)) for i in range(n)]               # sabotage: only two distinct directions
        generic[n] = subset_sums_distinct(us)
    # the homomorphism property: D(S -> T) = u(T xor S) is additive on composable pairs (exact, generic u, n = 4)
    n = 4; us = [(1, 2 ** i) for i in range(n)]
    P = {S: (sum(us[i][0] for i in range(n) if S >> i & 1), sum(us[i][1] for i in range(n) if S >> i & 1)) for S in range(1 << n)}
    hom = all((P[T][0] - P[S][0], P[T][1] - P[S][1]) == P[T ^ S] for S in range(16) for T in range(16) if (S & T) == S)
    ok = not any(regular.values()) and half == {2: True, 3: False} and all(generic.values()) and hom
    return report('bd·mjc·36', ok, f'translation-invariant positions P(S) = sum_(i in S) u_i: D(S -> T) = P(T) - P(S) equals P(T xor S) on every arrow, a homomorphism of (labels, ⊕) to (R^2, +): {hom}; injective as eq. (4) of the paper asks iff the subset sums are distinct: regular drawings (n-th roots of unity) {regular}, half-turn drawings (angles pi i / n) {half}, u_i = (1, 2^i) {generic}')

CHECKS = [('bd·mjc·33', check33), ('bd·mjc·34', check34), ('bd·mjc·35', check35), ('bd·mjc·36', check36)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear()
            okk = f(sab=True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            if okk: missed += 1
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    nfail = sum(1 for _, okk in RESULTS if not okk)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
