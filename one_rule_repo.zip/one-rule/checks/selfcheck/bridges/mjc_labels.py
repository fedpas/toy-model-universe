#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjc_labels.py: the labels F_2^n as a partial commutative monoid (disjoint union, unit 0, weight popcount), its translation category
(the Boolean lattice B_n), the sum (8) of arXiv:2403.19689 (v3) on the arrows of B_n, the bit rule on disjoint labels, and the category
algebra of B_n inside Cl(n,n) = M_{2^n}(R).  The paper's items: Def. 2 (3) with eqs. (8), (9), the norm axioms of §3, Def. 4.

    python3 selfcheck/bridges/mjc_labels.py              one line per check, ids bd·mjc·1 .. bd·mjc·8 (info line bd·mjc·38); exit 1 on any FAIL
    python3 selfcheck/bridges/mjc_labels.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library and numpy (integer matrices; ranks modulo the prime 32749, paired with an exact upper bound in each check); deterministic
(seeded generators), about 2 s; runs from any folder, reads and writes no file.
  The info line bd·mjc·38 lists the sizes 2^n, 3^n, 4^n, 5^n of the objects, arrows, composable pairs and 3-simplices and the dimensions
  2^n, 3^n, 4^n of the exterior algebra, the category algebra and Cl(n,n) (n = 0..6), from their formulas: a table, not a check.
  bd·mjc·1  (labels, ⊕) with a ⊕ b = a xor b defined iff a and b = 0: defined on exactly 3^n ordered pairs, commutative, unit 0, associative in
            the strong (Kleene) sense on all triples, so also in the weaker form printed in Def. 4; positive (a ⊕ b = 0 only for
            a = b = 0), cancellative, no label but 0 has an inverse (n = 0..6).
  bd·mjc·2  the additive weights w(a ⊕ b) = w(a) + w(b) on the labels form a space of dimension exactly n (w = sum of c_i over the bits of a);
            popcount is the one with value 1 on every atom; the printed axiom "||v|| >= 1" (§3) fails on exactly one label, the unit 0 (n = 0..5).
  bd·mjc·3  the translation category of (labels, ⊕) (arrows s -> s ⊕ d) is isomorphic to B_n by (s, d) -> (s, s or d), compatible with dom,
            cod, identities and composition; counted by enumeration, not by formula: 2^n objects, 3^n arrows, 4^n composable pairs, (k+2)^n
            k-simplices of the nerve (k = 0..4) and sum_j (-1)^j C(k,j) (k+2-j)^n non-degenerate ones (n = 0..5).
  bd·mjc·4  control (expected to fail): random posets on 8 and 16 elements (seed 11, 200 each, the edge probability chosen so that the mean
            number of arrows is near 3^n) satisfy the counts 3^n, 4^n, 5^n of bd·mjc·3 for k = 1, 2, 3 in 0 of 400.  The line also reports
            that the incidence algebra of each poset is closed of dimension = number of arrows: true of every poset (by transitivity), a
            generic remark that is not part of the check.
  bd·mjc·5  the difference map D(S -> T) = T xor S is a functor B_n -> (labels, ⊕): D(g o f) = D(f) ⊕ D(g), and ||f|| = popcount D(f) makes (9)
            hold on all composable pairs; the paper's sum (8) on the non-identity arrows of B_n plus 0 is single-valued (0 two-valued pairs),
            satisfies the printed associativity of Def. 4 (when a ⊕ b and b ⊕ c are defined, both sides agree or are both undefined), and is
            not strongly associative from n = 3 on (counts of triples with b ⊕ c and a ⊕ (b ⊕ c) defined and a ⊕ b undefined; n = 2..4).
  bd·mjc·6  the bit rule s(a,b) on disjoint labels is (-1)^N(a,b) for every eps in {+1,-1,0}^n (all eps for n <= 4, 40 random for n = 5, 6):
            on ⊕ the bit rule does not see the signature; the restricted table (0 off the disjoint pairs) is associative and is the exterior
            algebra Cl(0,0,n); the untwisted algebra of the same partial monoid (sign +1 on every disjoint pair) has commutator span 0,
            computed from its table, while the exterior algebra has commutator span of dimension 2^(n-1) - 1 (the labels of even weight
            >= 2): they are not isomorphic for n >= 2.
  bd·mjc·7  the sign classes of (labels, ⊕): normalised 2-cocycles with values +-1 modulo coboundaries, H^2 = F_2^C(n,2) (n = 2..4, linear
            algebra over F_2), detected by the commutation signs; at n = 3 all 4096 normalised sign tables are tested: 128 cocycles in 8
            classes; the wedge is the class with every commutation sign -1 (bd·cat·19 at r = n gives the same dimension); control (expected to
            fail): random sign tables (seed 12) are cocycles in 7 of 200.
  bd·mjc·8  the category algebra of B_n inside M_{2^n}(R) = Cl(n,n) (n = 1..4): the matrix units E_{T,S}, S subset T, span 3^n dimensions, are
            the Kronecker products of the 2x2 triangular units (the n-th tensor power of the 3-dimensional triangular algebra T_2); with the
            Jordan-Wigner creation operators c_i^+ and e_i = c_i^+ + c_i, f_i = c_i^+ - c_i the Cl(n,n) relations hold (e_i^2 = 1, f_i^2 = -1,
            all anticommute) and the 4^n blades span M_{2^n}; c_i^+ = (e_i + f_i)/2 is null; the c_i^+ generate a 2^n-dimensional algebra
            with the restricted bit rule (the exterior algebra); the c_i^+ with the Peirce idempotents E_{S,S} = prod (c c^+ or c^+ c) generate
            exactly the category algebra (3^n); adding the c_i generates all 4^n; the category algebra is contained in the triangular algebra
            of a linear extension (2^(n-1)(2^n + 1)), equal only for n <= 1; its radical (span of the strict arrows) has Loewy length n + 1.
"""
import sys, random, itertools
from math import comb
import numpy as np

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if not SABOTAGE: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    else: print('  sabotaged input, what the check sees: ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def osum(a, b): return (a | b) if not (a & b) else None            # the disjoint sum of the labels
def kle(x, y, op):                                                   # Kleene extension: undefined propagates
    if x is None or y is None: return None
    return op(x, y)
def sgn(a, b, eps):                                                  # the bit rule of the atlas (core_check.py)
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Nsign(a, b):                                                     # (-1)^N(a,b), N = #{(i,j): i in a, j in b, j < i}
    n = 0
    for i in range(max(a.bit_length(), 1)):
        if a >> i & 1: n += pc(b & ((1 << i) - 1))
    return -1 if n % 2 else 1

# ------------------------------------------------------------------ exact rank over Q of integer vectors (mod-p rank, a lower bound; the checks pair it with an upper bound)
P = 32749                                                            # a prime small enough that the mod-p products below stay exact in int64
class Span:
    """row-reduced basis modulo P; rank mod P is a lower bound for the rank over Q (each check pairs it with an exact upper bound)"""
    def __init__(self, dim): self.dim = dim; self.R = np.zeros((0, dim), dtype=np.int64); self.piv = []
    def reduce(self, v):
        v = np.asarray(v, dtype=np.int64) % P
        if self.piv: v = (v - (v[self.piv] @ self.R)) % P
        return v
    def add(self, v):
        v = self.reduce(v)
        nz = np.nonzero(v)[0]
        if len(nz) == 0: return False
        c = int(nz[0]); v = (v * pow(int(v[c]), P - 2, P)) % P
        if self.piv: self.R = (self.R - np.outer(self.R[:, c], v)) % P
        self.R = np.vstack([self.R, v]); self.piv.append(c); return True
    def __len__(self): return len(self.piv)

def rank_q_fraction(rows, ncols):
    """exact rank over Q (fractions); rows: lists of ints"""
    from fractions import Fraction
    M = [[Fraction(x) for x in r] for r in rows]; rk = 0; col = 0
    while rk < len(M) and col < ncols:
        piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if piv is None: col += 1; continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col] / M[rk][col]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1; col += 1
    return rk

def random_poset(m, prob, rng):
    """a random partial order on m elements: random DAG on 0..m-1 (i < j edges with probability prob), transitive closure"""
    up = [0] * m
    for i in range(m):
        up[i] |= 1 << i
    for i in range(m - 1, -1, -1):
        for j in range(i + 1, m):
            if rng.random() < prob: up[i] |= up[j]
    return up                                                         # up[i] = bitset of {j : i <= j}

def chains_poset(up, m, kmax):
    """numbers of k-simplices (weak chains x0 <= ... <= xk) and of strict chains, k = 0..kmax, by dynamic programming"""
    weak = [1] * m; strict = [1] * m; W = [m]; S = [m]
    for k in range(1, kmax + 1):
        nw = [0] * m; ns = [0] * m
        for x in range(m):
            for y in range(m):
                if up[x] >> y & 1:
                    nw[y] += weak[x]
                    if x != y: ns[y] += strict[x]
        weak, strict = nw, ns; W.append(sum(weak)); S.append(sum(strict))
    return W, S

# ================================================================== bd·mjc·1  the partial commutative monoid of labels
def check1(sab=False):
    op = (lambda a, b: a ^ b) if sab else osum                       # sabotage: the total xor (a group, every label its own inverse)
    ok = True; tab = {}
    for n in range(0, 7):
        L = range(1 << n)
        defined = sum(1 for a in L for b in L if op(a, b) is not None)
        comm = all(op(a, b) == op(b, a) for a in L for b in L)
        unit = all(op(0, a) == a and op(a, 0) == a for a in L)
        strong = all(kle(op(a, b), c, op) == kle(a, op(b, c), op) for a in L for b in L for c in L)
        weak = all(kle(op(a, b), c, op) == kle(a, op(b, c), op) for a in L for b in L for c in L
                   if op(a, b) is not None and op(b, c) is not None)
        positive = all(not (op(a, b) == 0 and (a or b)) for a in L for b in L)
        cancel = all(op(a, b) is None or op(a, b) != op(a, c) or b == c for a in L for b in L for c in L) if n <= 5 else True
        inverses = sum(1 for a in L if a and any(op(a, b) == 0 for b in L))
        tab[n] = defined
        if not (defined == 3 ** n and comm and unit and strong and weak and positive and cancel and inverses == 0): ok = False
    return report('bd·mjc·1', ok, f'(labels, ⊕), a ⊕ b = a xor b iff a and b = 0, unit 0: defined ordered pairs {tab} = 3^n; commutative, unit, associative in the strong (Kleene) sense on all triples and in the printed form of Def. 4; positive, cancellative; labels other than 0 with an inverse: 0 (n = 0..6)' + (f'; sabotaged op has {inverses} invertible labels at n = 6' if sab else ''))

# ================================================================== bd·mjc·2  additive weights: dimension n, popcount, the printed axiom ||v|| >= 1
def check2(sab=False):
    ok = True; dims = {}; bad_t7 = {}
    for n in range(0, 6):
        L = range(1 << n)
        op = (lambda a, b: a ^ b) if sab else osum                   # sabotage: impose additivity on the total xor
        rows = []
        for a in L:
            for b in L:
                c = op(a, b)
                if c is None: continue
                r = [0] * (1 << n); r[c] += 1; r[a] -= 1; r[b] -= 1
                if any(r): rows.append(r)
        rk = rank_q_fraction(rows, 1 << n) if n <= 4 else None
        if n == 5:
            S = Span(1 << n)
            for r in rows: S.add(r)
            rk = len(S)                                                # mod-p rank: lower bound; the n vectors below give the upper bound n on the kernel
        dims[n] = (1 << n) - rk
        basis_ok = all(all(sum(r[x] * ((x >> i) & 1) for x in L) == 0 for r in rows) for i in range(n))
        pop_add = all(pc(op(a, b)) == pc(a) + pc(b) for a in L for b in L if op(a, b) is not None)
        bad_t7[n] = [a for a in L if pc(a) < 1]
        if not (dims[n] == n and basis_ok and pop_add and bad_t7[n] == [0]): ok = False
    return report('bd·mjc·2', ok, f'additive weights w(a ⊕ b) = w(a) + w(b) on the labels: kernel dimension {dims} = n (spanned by the n bit indicators, which satisfy every constraint); popcount is additive (9) and is 1 on each atom; labels with popcount < 1 (the printed axiom "||v|| >= 1"): {bad_t7[5]} at n = 5, only the unit 0 for every n = 0..5')

# ================================================================== bd·mjc·3  translation category = B_n; counts by enumeration
def check3(sab=False):
    ok = True; counts = {}
    for n in range(0, 6):
        L = list(range(1 << n))
        # translation category: arrows (s, d) with s and d disjoint; dom s, cod s ⊕ d; (s', d') o (s, d) = (s, d ⊕ d') when s' = s ⊕ d
        T = [(s, d) for s in L for d in L if not (s & d)]
        if sab: up = [sum(1 << y for y in L if y >= x) for x in L]   # sabotage: the labels as a chain (integer order)
        else: up = [sum(1 << y for y in L if (x & y) == x) for x in L]
        Barr = [(x, y) for x in L for y in L if up[x] >> y & 1]
        F = {(s, d): (s, s | d) for (s, d) in T}
        bij = len(set(F.values())) == len(T) and set(F.values()) == set(Barr)
        comp_ok = True
        for (s, d) in T:
            for d2 in L:
                t = s | d
                if t & d2: continue
                comp = (s, d | d2)                                     # composite in the translation category
                if F[comp] != (s, (t | d2)) or F[(t, d2)][0] != F[(s, d)][1]: comp_ok = False
        ident = all(F[(s, 0)] == (s, s) for s in L)
        W, S = chains_poset(up, len(L), 4)
        formulaW = [(k + 2) ** n for k in range(5)]
        formulaS = [sum((-1) ** j * comb(k, j) * (k + 2 - j) ** n for j in range(k + 1)) for k in range(5)]
        counts[n] = W
        if not (bij and comp_ok and ident and len(T) == 3 ** n and W == formulaW and S == formulaS): ok = False
    return report('bd·mjc·3', ok, f'translation category of (labels, ⊕) -> B_n, (s, d) -> (s, s or d): a bijection on arrows compatible with dom, cod, identities and composition; enumerated k-simplices of the nerve, k = 0..4: ' + '; '.join(f'n={n}: {counts[n]}' for n in (2, 3, 4, 5)) + ' = (k+2)^n; non-degenerate = sum_j (-1)^j C(k,j)(k+2-j)^n (n = 0..5); objects 2^n, arrows 3^n, composable pairs 4^n')

# ================================================================== bd·mjc·4  control: random posets of the same size
def check4(sab=False):
    rng = random.Random(11); hits = 0; inc_ok = 0; tot = 0; mean_arrows = {}
    for n, prob in ((3, 0.47), (4, 0.28)):
        m = 1 << n; arr_sum = 0
        for _ in range(200):
            up = random_poset(m, prob, rng)
            if sab:                                                    # sabotage: the control is replaced by B_n itself
                up = [sum(1 << y for y in range(m) if (x & y) == x) for x in range(m)]
            W, S = chains_poset(up, m, 3)
            arr_sum += W[1]
            if W[1] == 3 ** n and W[2] == 4 ** n and W[3] == 5 ** n: hits += 1
            # incidence algebra of the poset: span of matrix units E_{y,x}, x <= y, closed under product; its dimension is the number of arrows
            arrows = [(x, y) for x in range(m) for y in range(m) if up[x] >> y & 1]
            closed = all((up[x] >> z & 1) for (x, y) in arrows for (y2, z) in arrows if y2 == y)
            if closed and len(arrows) == W[1]: inc_ok += 1
            tot += 1
        mean_arrows[n] = round(arr_sum / 200, 1)
    ok = hits == 0                                                     # the closure count inc_ok holds for every poset (transitivity): reported, not tested
    return report('bd·mjc·4', ok, f'control: random posets on 8 and 16 elements (seed 11, 200 each, mean arrows {mean_arrows} against 3^n = 27, 81): the counts 3^n, 4^n, 5^n of the nerve (k = 1, 2, 3) hold in {hits} of {tot}; remark, true of every poset by transitivity and not part of the check: the incidence algebra (span of E_(y,x), x <= y) is closed of dimension = number of arrows in {inc_ok} of {tot}')

# ================================================================== bd·mjc·5  the difference functor and the paper's sum (8) on the arrows of B_n
def paper_sum(f, g, comp, is_id):
    """(8): f ⊕ g for arrows f, g given as (dom, cod, name); returns the set of values (0 = the auxiliary zero)"""
    vals = set()
    if f == 'ZERO': return {g}
    if g == 'ZERO': return {f}
    if f[1] == g[0]: vals.add(comp(f, g))                              # g o f
    if g[1] == f[0]: vals.add(comp(g, f))                              # f o g
    return vals
def check5(sab=False):
    ok = True; strong_fail = {}; twoval = {}; weak_bad = {}; ex = None
    for n in (2, 3, 4):
        L = list(range(1 << n))
        if sab: arrows = [(x, y) for x in L for y in L if x != y]      # sabotage: the indiscrete category (pair groupoid) on the labels
        else: arrows = [(x, y) for x in L for y in L if (x & y) == x and x != y]
        def comp(f, g):                                                # g o f, f first (cod f = dom g)
            c = (f[0], g[1])
            return 'ZERO' if c[0] == c[1] else c                       # a composite that is an identity goes to 0 (only in the sabotage)
        D = lambda f: f[0] ^ f[1]
        add_ok = all(D((f[0], g[1])) == osum(D(f), D(g)) and pc(D((f[0], g[1]))) == pc(D(f)) + pc(D(g))
                     for f in arrows for g in arrows if f[1] == g[0])
        V = arrows + ['ZERO']
        def s0(a, b):
            v = paper_sum(a, b, comp, None)
            return None if not v else (next(iter(v)) if len(v) == 1 else 'TWO')
        TAB = {(a, b): s0(a, b) for a in V for b in V}
        def s(a, b):
            if a is None or b is None or a == 'TWO' or b == 'TWO': return None
            return TAB.get((a, b), s0(a, b))
        tv = sum(1 for v in TAB.values() if v == 'TWO'); twoval[n] = tv
        sf = 0; wb = 0
        for a in V:
            for b in V:
                ab = TAB[(a, b)]
                for c in V:
                    bc = TAB[(b, c)]
                    L1 = s(ab, c); R1 = s(a, bc)
                    if ab not in (None, 'TWO') and bc not in (None, 'TWO') and L1 != R1: wb += 1
                    if bc not in (None, 'TWO') and R1 not in (None, 'TWO') and ab is None:
                        sf += 1
                        if ex is None and n == 3: ex = (a, b, c)
        strong_fail[n] = sf; weak_bad[n] = wb
        if not add_ok: ok = False
    if not (all(v == 0 for v in twoval.values()) and all(v == 0 for v in weak_bad.values()) and strong_fail[2] == 0 and strong_fail[3] > 0 and strong_fail[4] > 0): ok = False
    return report('bd·mjc·5', ok, f'D(S -> T) = T xor S: D(g o f) = D(f) ⊕ D(g) and popcount D is additive (9) on all composable pairs (n = 2..4); the paper\'s sum (8) on the non-identity arrows of B_n plus 0: two-valued pairs {twoval}, triples violating the printed associativity of Def. 4 {weak_bad}; triples with b ⊕ c and a ⊕ (b ⊕ c) defined but a ⊕ b undefined (strong associativity fails) {strong_fail}; smallest at n = 3: a, b, c = {ex} (arrows as (dom, cod) labels)')

# ================================================================== bd·mjc·6  the bit rule on disjoint labels is the wedge, for every eps
def check6(sab=False):
    ok = True; rng = random.Random(5); n_eps = 0; comm_dims = {}
    for n in range(0, 7):
        L = range(1 << n)
        eps_list = list(itertools.product((1, -1, 0), repeat=n)) if n <= 4 else [tuple(rng.choice((1, -1, 0)) for _ in range(n)) for _ in range(40)]
        for eps in eps_list:
            n_eps += 1
            for a in L:
                for b in L:
                    if a & b: continue
                    s = sgn(a, b, eps)
                    if sab and a == 1 and b == 2: s = -s                # sabotage: one sign flipped
                    if s != Nsign(a, b): ok = False
        if n <= 5:
            def mul(a, b):
                if a & b: return (0, 0)
                s = Nsign(a, b)
                if sab and a == 1 and b == 2: s = -s
                return (s, a | b)
            assoc = True
            for a in L:
                for b in L:
                    s1, ab = mul(a, b)
                    for c in L:
                        if not s1: r1 = 0
                        else:
                            s2, abc = mul(ab, c); r1 = (s1 * s2, abc) if s2 else 0
                        s3, bc = mul(b, c)
                        if not s3: r2 = 0
                        else:
                            s4, abc2 = mul(a, bc); r2 = (s3 * s4, abc2) if s4 else 0
                        if r1 != r2: assoc = False
            gcomm = all(mul(a, b)[0] == ((-1) ** (pc(a) * pc(b))) * mul(b, a)[0] for a in L for b in L if not (a & b))
            # dimension of the span of commutators [e_a, e_b]: exterior (twisted) against untwisted (sign +1 on every disjoint pair)
            def mul_u(a, b): return (0, 0) if a & b else (1, a | b)
            twisted = set(); untwisted = set()
            for a in L:
                for b in L:
                    if a & b: continue
                    s_ab = mul(a, b)[0]; s_ba = mul(b, a)[0]
                    if s_ab - s_ba: twisted.add(a | b)
                    (u_ab, c_ab), (u_ba, c_ba) = mul_u(a, b), mul_u(b, a)
                    if (u_ab, c_ab) != (u_ba, c_ba): untwisted.add(c_ab); untwisted.add(c_ba)
            comm_dims[n] = (len(twisted), len(untwisted))
            if not (assoc and gcomm): ok = False
    expect = {n: (sum(1 for c in range(1 << n) if pc(c) >= 2 and any(pc(a) % 2 and pc(c ^ a) % 2 for a in range(1 << n) if (a & c) == a)), 0) for n in comm_dims}
    if comm_dims != expect or comm_dims[2][0] == 0: ok = False
    return report('bd·mjc·6', ok, f'the bit rule on disjoint labels: s(a,b) = (-1)^N(a,b) for all {n_eps} sign vectors eps in {{+1,-1,0}}^n (all for n <= 4, 40 random for n = 5, 6), so on ⊕ the signature is invisible; the table restricted to disjoint pairs (0 elsewhere) is associative and graded-commutative (the exterior algebra Cl(0,0,n), n <= 5); commutator span dimension (exterior, untwisted) = {comm_dims}: the untwisted algebra of the same partial monoid (sign +1, its table computed) is commutative, so the two are not isomorphic for n >= 2')

# ================================================================== bd·mjc·7  the sign classes of (labels, ⊕): H^2 with coefficients +-1, and the random control
def f2_rank(rows):
    piv = {}
    for r in rows:
        while r:
            h = r.bit_length() - 1
            if h in piv: r ^= piv[h]
            else: piv[h] = r; break
    return len(piv)
def h2_partial(n, total=False):
    """normalised 2-cochains s: pairs (a, b) with a, b != 0 in the domain -> F_2 (log of the sign); cocycle: s(a,b) + s(a⊕b,c) = s(b,c) + s(a,b⊕c)
    on every triple where both sides are defined; coboundaries of t: labels -> F_2 with t(0) = 0.  total=True: the group Z_2^n (sabotage)."""
    L = range(1 << n)
    dom = (lambda a, b: True) if total else (lambda a, b: not (a & b))
    op = lambda a, b: a ^ b
    pairs = [(a, b) for a in L for b in L if a and b and dom(a, b)]
    idx = {pq: k for k, pq in enumerate(pairs)}
    def var(a, b): return (1 << idx[(a, b)]) if (a and b) else 0
    rows = []
    for a in L:
        for b in L:
            if not dom(a, b): continue
            for c in L:
                if not dom(op(a, b), c) or not dom(b, c): continue
                r = var(a, b) ^ var(op(a, b), c) ^ var(b, c) ^ var(a, op(b, c))
                if r: rows.append(r)
    dimZ = len(pairs) - f2_rank(rows)
    cob = []
    for x in L:
        if not x: continue
        r = 0
        for (a, b) in pairs:                                           # (dt)(a,b) = t(a) + t(b) + t(a⊕b): coefficient of t(x)
            if (a == x) ^ (b == x) ^ (op(a, b) == x): r |= 1 << idx[(a, b)]
        cob.append(r)
    dimB = f2_rank(cob)
    return dimZ, dimB, len(pairs)
def check7(sab=False):
    ok = True; table = {}
    for n in (2, 3, 4):
        dZ, dB, npairs = h2_partial(n, total=sab)                     # sabotage: the total group Z_2^n in place of the partial monoid
        table[n] = (dZ, dB, dZ - dB)
        if dZ - dB != comb(n, 2): ok = False
    # exhaustion at n = 3: all 2^12 normalised sign tables; cocycles and their commutation signs
    n = 3; L = range(1 << n); pairs = [(a, b) for a in L for b in L if a and b and not (a & b)]
    ncoc = 0; classes = set()
    for bits in range(1 << len(pairs)):
        s = {pq: (-1 if bits >> k & 1 else 1) for k, pq in enumerate(pairs)}
        sg = lambda a, b: 1 if (a == 0 or b == 0) else s[(a, b)]
        if all(sg(a, b) * sg(a | b, c) == sg(b, c) * sg(a, b | c) for a in L for b in L for c in L if not (a & b) and not ((a | b) & c)):
            ncoc += 1; classes.add(tuple(sg(1 << i, 1 << j) * sg(1 << j, 1 << i) for i in range(n) for j in range(i + 1, n)))
    wedge_cls = tuple(Nsign(1 << i, 1 << j) * Nsign(1 << j, 1 << i) for i in range(n) for j in range(i + 1, n))
    rng = random.Random(12); rnd = 0
    for _ in range(200):
        s = {pq: rng.choice((1, -1)) for pq in pairs}
        sg = lambda a, b: 1 if (a == 0 or b == 0) else s[(a, b)]
        rnd += all(sg(a, b) * sg(a | b, c) == sg(b, c) * sg(a, b | c) for a in L for b in L for c in L if not (a & b) and not ((a | b) & c))
    if not (ncoc == 2 ** table[3][0] and len(classes) == 2 ** comb(3, 2) and wedge_cls == (-1, -1, -1) and rnd < 200): ok = False
    return report('bd·mjc·7', ok, f'sign classes of the partial monoid (labels, ⊕) with coefficients +-1 (linear algebra over F_2; (dim Z^2, dim B^2, dim H^2)): {table}: H^2 = F_2^C(n,2), detected by the commutation signs s(i,j)s(j,i); at n = 3 exhaustion of all 4096 normalised tables finds {ncoc} cocycles in {len(classes)} classes; the wedge (the bit rule on ⊕, every eps) is the class with all commutation signs -1 {wedge_cls}, the untwisted algebra the trivial class (consistent with bd·cat·19 at r = n); control: random tables (seed 12) are cocycles in {rnd} of 200')

# ================================================================== bd·mjc·8  the category algebra of B_n inside Cl(n,n) = M_{2^n}(R)
def E(T, S, N): M = np.zeros((N, N), dtype=np.int64); M[T, S] = 1; return M
def gen_algebra(gens, N, bound):
    """the subalgebra generated by gens and 1: closure of span{1} under right multiplication by the generators (mod-p rank)"""
    S = Span(N * N); basis = []
    I = np.eye(N, dtype=np.int64)
    if S.add(I.flatten()): basis.append(I)
    k = 0
    while k < len(basis):
        b = basis[k]; k += 1
        for g in gens:
            x = b @ g
            if S.add(x.flatten()): basis.append(x)
            if len(basis) > bound: return len(basis)
    return len(basis)
def check8(sab=False):
    ok = True; table = {}
    for n in range(1, 5):
        N = 1 << n
        units = [E(T, S, N) for S in range(N) for T in range(N) if (S & T) == S]
        Sp = Span(N * N)
        for u in units: Sp.add(u.flatten())
        dimI = len(Sp)
        closed = all(((x @ y) == 0).all() or Sp.reduce((x @ y).flatten()).any() == False for x in units[:60] for y in units[:60])
        # Kronecker form: E_{T,S} = kron over bits (high bit first) of the 2x2 units E_{t_i, s_i}
        kron_ok = True
        for S in range(N):
            for T in range(N):
                if (S & T) != S: continue
                M = np.ones((1, 1), dtype=np.int64)
                for i in range(n - 1, -1, -1):
                    m2 = np.zeros((2, 2), dtype=np.int64); m2[(T >> i) & 1, (S >> i) & 1] = 1; M = np.kron(M, m2)
                if not (M == E(T, S, N)).all(): kron_ok = False
        # Jordan-Wigner creation operators and the Cl(n,n) generators
        def cdag(i):
            M = np.zeros((N, N), dtype=np.int64)
            for S in range(N):
                if S >> i & 1: continue
                sign = 1 if sab else (-1 if pc(S & ((1 << i) - 1)) % 2 else 1)   # sabotage: no Jordan-Wigner string
                M[S | (1 << i), S] = sign
            return M
        C = [cdag(i) for i in range(n)]; A = [c.T.copy() for c in C]
        e = [C[i] + A[i] for i in range(n)]; f = [C[i] - A[i] for i in range(n)]
        Id = np.eye(N, dtype=np.int64)
        gens = e + f
        rel = all((g @ g == Id).all() for g in e) and all((g @ g == -Id).all() for g in f)
        anti = all(((gens[i] @ gens[j] + gens[j] @ gens[i]) == 0).all() for i in range(2 * n) for j in range(i + 1, 2 * n))
        blades = Span(N * N)
        for mask in range(1 << (2 * n)):
            M = Id.copy()
            for i in range(2 * n):
                if mask >> i & 1: M = M @ gens[i]
            blades.add(M.flatten())
        null_ok = all(((e[i] + f[i]) == 2 * C[i]).all() and (C[i] @ C[i] == 0).all() for i in range(n))
        dim_cre = gen_algebra(C, N, 4 ** n)
        # products of creation operators follow the restricted bit rule: c_a c_b = (-1)^N(a,b) c_(a ⊕ b) or 0
        def cprod(a):
            M = Id.copy()
            for i in range(n):
                if a >> i & 1: M = M @ C[i]
            return M
        wedge_ok = all(((cprod(a) @ cprod(b)) == (Nsign(a, b) * cprod(a | b) if not (a & b) else 0)).all() for a in range(N) for b in range(N))
        # Peirce idempotents as products of c c+ and c+ c
        peirce_ok = True; Pid = []
        for S in range(N):
            M = Id.copy()
            for i in range(n): M = M @ ((C[i] @ A[i]) if S >> i & 1 else (A[i] @ C[i]))
            Pid.append(M)
            if not (M == E(S, S, N)).all(): peirce_ok = False
        dim_inc = gen_algebra(C + Pid, N, 4 ** n)
        dim_all = gen_algebra(C + Pid + A, N, 4 ** n)
        tri = (N * (N + 1)) // 2                                       # triangular algebra of the linear extension (integer order of the labels)
        in_tri = all(T >= S for S in range(N) for T in range(N) if (S & T) == S)
        # radical: strict arrows; Loewy length n + 1
        strict = [E(T, S, N) for S in range(N) for T in range(N) if (S & T) == S and S != T]
        Rsum = sum(strict) if strict else np.zeros((N, N), dtype=np.int64)
        powers = []; M = Id.copy()
        for k in range(1, n + 2): M = M @ Rsum; powers.append(int((M != 0).sum()))
        loewy = next(k for k, v in enumerate(powers, start=1) if v == 0)
        table[n] = dict(inc=dimI, blades=len(blades), cre=dim_cre, gen=dim_inc, all=dim_all, tri=tri, loewy=loewy)
        if not (dimI == 3 ** n and kron_ok and rel and anti and len(blades) == 4 ** n and null_ok and dim_cre == 2 ** n and wedge_ok and peirce_ok
                and dim_inc == 3 ** n and dim_all == 4 ** n and in_tri and (tri == 3 ** n) == (n <= 1) and loewy == n + 1): ok = False
    return report('bd·mjc·8', ok, 'category algebra of B_n in M_(2^n)(R) = Cl(n,n), n = 1..4: ' + '; '.join(f'n={n}: span E_(T,S) {t["inc"]}, blades of e_i, f_i {t["blades"]}, generated by c+ {t["cre"]}, by c+ and Peirce idempotents {t["gen"]}, with c added {t["all"]}, triangular {t["tri"]}, Loewy length of the radical {t["loewy"]}' for n, t in table.items()) + '; E_(T,S) = kron of 2x2 units; e_i^2 = 1, f_i^2 = -1, all anticommute; c+ = (e + f)/2 null; c_a c_b = (-1)^N(a,b) c_(a ⊕ b) (the restricted bit rule); E_(S,S) = prod of c c+ and c+ c')

CHECKS = [('bd·mjc·1', check1), ('bd·mjc·2', check2), ('bd·mjc·3', check3), ('bd·mjc·4', check4), ('bd·mjc·5', check5), ('bd·mjc·6', check6),
          ('bd·mjc·7', check7), ('bd·mjc·8', check8)]

def size_table():
    rows = []
    for n in range(0, 7):
        rows.append(f'n={n}: objects {2**n}, arrows {3**n}, composable pairs {4**n}, 3-simplices {5**n}; algebras: exterior {2**n}, category algebra {3**n}, Cl(n,n) {4**n}')
    return rows

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear()
            okk = f(sab=True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            if okk: missed += 1
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    print('info bd·mjc·38  the sizes from their formulas (a table, not a check): ' + ' | '.join(size_table()))
    nfail = sum(1 for _, okk in RESULTS if not okk)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
