#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mat_codes_misc.py: doubly-even self-dual codes as the Lagrangians of the Z_4 form w of Cl(n,0), and the ungraded isomorphism behind
"Q alone fixes the type up to c <-> 2 - c".

  python3 selfcheck/bridges/mat_codes_misc.py       one line per check, ids bd·mat·15 .. bd·mat·16; exit 1 on any FAIL

Standard library only, exact integers, deterministic, about 2 s; runs from any folder, reads and writes no file.
  bd·mat·15  for Cl(n,0) the Z_4 form is w(a) = |a| mod 4, and a w-isotropic subspace is a doubly-even self-orthogonal code. Exhaustive for
             n = 2, 4, 6, 8: the maximal w-isotropic dimension is 0, 1, 2, 4, so a Lagrangian of w exists only at n = 8 (Brown invariant 0), where
             it is the extended Hamming code [8,4,4]; the binary Q (maximal totally singular dimension 1, 1, 2, 4) has Lagrangians at n = 2 and 8.
             In the language of w this is Wood 1993, Sect. 5 (a self-dual isotropic subspace exists iff the Brown invariant is 0 mod 8).
  bd·mat·16  with a +1 generator t, f_1 = t and f_j = e_j t (j != 1) satisfy the Clifford relations of Cl(q+1, p-1) and their subset products are
             the 2^n blades up to sign: an explicit ungraded isomorphism Cl(p,q) = Cl(q+1, p-1) (every Cl(p,q) with p >= 1, n <= 6), the
             identification c <-> 2 - c of core·B6b; the binary Q sees the ungraded algebra and pi adds the grading.
"""
import sys

ROWS = []
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Q(a, e): return 1 if sgn(a, a, e) == -1 else 0
def pi(a): return pc(a) % 2
def w4(a, e): return (pi(a) + 2 * Q(a, e)) % 4
def sig(p, q): return [1] * p + [-1] * q
def row(i, text, ok):
    ROWS.append((i, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

def max_isotropic_dim(n, iso):
    """largest dimension of a subspace of F_2^n on which iso(a) holds for every element (iso a predicate on labels); exhaustive backtracking in which
    every subspace is reached once: a new basis vector v must be the smallest element of the enlarged span outside the old span"""
    best = [0]; found_lagr = [None]
    cands = [a for a in range(1, 1 << n) if iso(a)]
    def rec(span, basis, start):
        if len(basis) > best[0]:
            best[0] = len(basis); found_lagr[0] = list(span)
        for idx in range(start, len(cands)):
            v = cands[idx]
            if v in span: continue
            if all(iso(s ^ v) for s in span):
                new = span | {s ^ v for s in span}
                if min(x for x in new if x not in span) != v: continue     # each subspace once (the chain of smallest new elements)
                rec(new, basis + [v], idx + 1)
    rec({0}, [], 0)
    return best[0], found_lagr[0]

def check15():
    ok = True; table = {}
    for n in (2, 4, 6, 8):
        e = sig(n, 0)
        dw, Ww = max_isotropic_dim(n, lambda a: w4(a, e) == 0)
        dq, _ = max_isotropic_dim(n, lambda a: Q(a, e) == 0)
        table[n] = (dw, dq)
        # w-isotropic subspaces are doubly-even self-orthogonal codes
        if dw == n // 2 and n != 8: ok = False
        if n == 8:
            if dw != 4: ok = False
            weights = sorted(pc(x) for x in Ww)
            if weights != [0] + [4] * 14 + [8]: ok = False
            if any(pc(x & y) % 2 for x in Ww for y in Ww): ok = False
    want = {2: (0, 1), 4: (1, 1), 6: (2, 2), 8: (4, 4)}
    row('bd·mat·15', f'for Cl(n,0), w(a) = |a| mod 4 and a w-isotropic subspace is a doubly-even self-orthogonal code. Maximal w-isotropic dimension against maximal '
        f'Q-singular dimension, n = 2, 4, 6, 8: {table} (expected {want}). A Lagrangian of w (dimension n/2) exists only at n = 8 among these, where it is the extended '
        'Hamming code (weights 0, 4 x 14, 8), while the binary Q (hyperbolic at n = 2 and 8, elliptic at n = 4 and 6) has Lagrangians at n = 2 and n = 8: with w the '
        'statement T14 (4) needs no pseudoscalar condition, and in this form it is Wood 1993, Sect. 5: a self-dual isotropic subspace exists iff the Brown invariant is 0 mod 8',
        ok and table == want)

def check16():
    ok = True; cells = 0
    for n in range(2, 7):
        for p in range(1, n + 1):
            q = n - p; e = sig(p, q); t = 0                                # e_1 (bit 0) squares to +1
            gens = [(1, 1 << t)]
            for j in range(1, n):
                s, lab = sgn(1 << j, 1 << t, e), (1 << j) | (1 << t)       # f_j = e_j e_t
                gens.append((s, lab))
            # squares and anticommutation of the f's
            sq = []
            for i, (s, a) in enumerate(gens):
                ss = s * s * sgn(a, a, e)
                sq.append(ss)
                for k, (s2, b) in enumerate(gens):
                    if i < k:
                        ab = sgn(a, b, e); ba = sgn(b, a, e)
                        if ab != -ba: ok = False
            want_p, want_q = 1 + sum(1 for j in range(1, n) if e[j] == -1), sum(1 for j in range(1, n) if e[j] == 1)
            if sorted(sq) != sorted(sig(want_p, want_q)): ok = False
            if (want_p, want_q) != (q + 1, p - 1): ok = False
            # the f's generate: the products of subsets of f's are +- distinct blades
            labs = set()
            for S in range(1 << n):
                lab = 0
                for j in range(n):
                    if S >> j & 1: lab ^= gens[j][1]
                labs.add(lab)
            if len(labs) != 1 << n: ok = False
            cells += 1
    row('bd·mat·16', f'with t a +1 generator of Cl(p,q), f_1 = t and f_j = e_j t (j != 1) anticommute, have squares +1 (q+1 times) and -1 (p-1 times) and their subset products are '
        f'+- the 2^n distinct blades: an explicit ungraded isomorphism Cl(p,q) = Cl(q+1, p-1) for all {cells} cells with p >= 1, n <= 6. This is the identification c <-> 2 - c that '
        'Q alone does not separate (core·B6b): the binary form Q classifies the ungraded algebra (Elduque and Rodrigo-Escudero, arXiv:1801.07002, Cor. 11: dimension and Arf invariant), '
        'and the parity pi is exactly the grading that separates the eight Brauer-Wall classes from the five ungraded types', ok)

if __name__ == '__main__':
    for f in (check15, check16): f()
    verdict()
