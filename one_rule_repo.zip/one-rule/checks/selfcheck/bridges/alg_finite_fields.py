#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""alg_finite_fields.py: the bit rule over finite fields F_l (l an odd prime): sign cochains and semifields, the Brauer-Wall class of Cl(p,q)
over F_l, and a null generator as the reduction of a ramified prime.

  python3 selfcheck/bridges/alg_finite_fields.py      one line per check, ids bd·alg·18 .. bd·alg·21; exit 1 on any FAIL

Standard library plus numpy (exact int64 arithmetic modulo l only), deterministic, about 3 s; runs from any folder, reads and writes no file.
 bd·alg·18  for n = 2 no normalised sign cochain on Z_2^2 gives a division algebra over F_l: exhaustive over all 512 cochains for l = 3, 5, 7, and over
            the 64 cochains with every e_a^2 = -1 (the only candidates, and only for l = 3 mod 4) for l = 3, 7, 11, 19, 23.
 bd·alg·21  det L_x of the 512 sign-cochain algebras on Z_2^2 as exact integer polynomials: 510 vanish at a non-zero x in {-1,0,1}^4 and 2 equal
            (sum x_a^2)^2 (the quaternions (-1,-1), associative): no +-1 sign cochain on Z_2^n (n >= 2) gives a semifield over a finite field.
 bd·alg·19  the Brauer-Wall class of Cl(p,q) over F_l (n even <= 8, l = 3, 5, 7, 11, 13) is trivial exactly when the volume element squares to a
            square of F_l: iff p - q = 0 mod 4 for l = 3 mod 4, always for l = 1 mod 4. With BW(F_l) = Z_4 or Z_2 x Z_2 (recalled, not computed)
            the finite-field clock is the real clock reduced.
 bd·alg·20  over F_p (p = 3..13) the algebra with squares (a, 0) has the square-zero ideal J = span(e2, e12) and the quotient F_p[e1]/(e1^2 - a),
            a field exactly for the non-residues a; that this is the reduction of a maximal order of a quaternion algebra ramified at p is
            recalled, not computed.
"""
import sys
from itertools import product, permutations
import numpy as np

ROWS = []
def row(i, ok, text):
    cid = 'bd·alg·' + str(i)
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

PERMS = list(permutations(range(4)))
def perm_sign(p):
    s = 1
    for i in range(4):
        for j in range(i + 1, 4):
            if p[i] > p[j]: s = -s
    return s
PSIGN = [perm_sign(p) for p in PERMS]

def det4_mod(M, l):
    """exact det mod l of an array of 4x4 integer matrices (shape (K,4,4)) by the Leibniz formula"""
    tot = np.zeros(M.shape[0], dtype=np.int64)
    for p, s in zip(PERMS, PSIGN):
        term = np.ones(M.shape[0], dtype=np.int64)
        for i in range(4): term = (term * M[:, i, p[i]]) % l
        tot = (tot + s * term) % l
    return tot % l

def projective_points(l):
    pts = []
    for x in product(range(l), repeat=4):
        nz = next((v for v in x if v), None)
        if nz == 1: pts.append(x)
    return np.array(pts, dtype=np.int64)

def division_count(cochains, l):
    X = projective_points(l); cnt = 0
    for s in cochains:
        # L_x[c][b] = sum_a x_a s(a,b) [a^b = c]
        M = np.zeros((X.shape[0], 4, 4), dtype=np.int64)
        for a in range(4):
            for b in range(4):
                M[:, a ^ b, b] = (M[:, a ^ b, b] + X[:, a] * s[(a, b)]) % l
        if np.all(det4_mod(M, l) != 0): cnt += 1
    return cnt, X.shape[0]

def all_cochains():
    keys = [(a, b) for a in range(1, 4) for b in range(1, 4)]
    for bits in range(1 << 9):
        s = {(a, b): 1 for a in range(4) for b in range(4)}
        for k, key in enumerate(keys): s[key] = -1 if bits >> k & 1 else 1
        yield s

def check18():
    ok = True; res = {}
    full = list(all_cochains())
    for l in (3, 5, 7):
        c, npts = division_count(full, l); res[f'F{l} all 512'] = c
        if c: ok = False
    survivors = [s for s in full if all(s[(a, a)] == -1 for a in (1, 2, 3))]
    if len(survivors) != 64: ok = False
    for l in (3, 7, 11, 19, 23):
        c, npts = division_count(survivors, l); res[f'F{l} 64'] = c
        if c: ok = False
    row(18, ok, f'n = 2 sign-cochain algebras over F_l: division algebras found {res} (projective points of F_l^4 tested exhaustively, exact): none. For l = 1 mod 4 none can exist (e_a^2 = +-1 is a square, so span(1, e_a) has zero divisors); for l = 3 mod 4 only the 64 cochains with all e_a^2 = -1 can, and none does for l <= 23. So a semifield needs cochain values beyond +-1 (the Pumplün report, N11, for l = 3, 5, 7; here l <= 23)')

def check21():
    ok = True
    def det_poly(s):
        poly = {}
        for p, sg in zip(PERMS, PSIGN):
            coef = sg; expo = [0] * 4
            for c in range(4):
                b = p[c]; a = c ^ b; coef *= s[(a, b)]; expo[a] += 1
            poly[tuple(expo)] = poly.get(tuple(expo), 0) + coef
        return {k: v for k, v in poly.items() if v}
    def ev(poly, x):
        t = 0
        for ex, c in poly.items():
            m = c
            for i in range(4): m *= x[i] ** ex[i]
            t += m
        return t
    norm2 = {}
    for a in range(4):
        for b in range(4):
            ex = [0] * 4; ex[a] += 2; ex[b] += 2; norm2[tuple(ex)] = norm2.get(tuple(ex), 0) + 1
    nzero = nnorm = nother = nassoc = 0
    for s in all_cochains():
        P = det_poly(s)
        if any(any(x) and ev(P, x) == 0 for x in product((-1, 0, 1), repeat=4)): nzero += 1; continue
        if P == norm2:
            nnorm += 1
            if all(s[(a, b)] * s[(a ^ b, c)] == s[(b, c)] * s[(a, b ^ c)] for a in range(4) for b in range(4) for c in range(4)): nassoc += 1
        else: nother += 1
    if (nzero, nnorm, nother, nassoc) != (510, 2, 0, 2): ok = False
    row(21, ok, f'det L_x of the 512 sign-cochain algebras on Z_2^2, as exact integer polynomials: {nzero} vanish at a non-zero x in {{-1,0,1}}^4 (zero divisors over every field), {nnorm} equal (sum x_a^2)^2 and are associative ({nassoc}), {nother} other. So over any field of characteristic != 2 a 4-dimensional +-1 sign-cochain algebra is a division algebra only if it is the quaternion algebra (-1,-1); over a finite field never, hence no +-1 sign cochain on Z_2^n (n >= 2) gives a semifield (every algebra contains such a 4-dimensional graded subalgebra): the sign-cochain part of question Q2 of the Pumplün report')

def is_square(x, l): return x % l != 0 and pow(x % l, (l - 1) // 2, l) == 1
def check19():
    ok = True; table = {}
    for l in (3, 5, 7, 11, 13):
        for n in range(2, 9, 2):
            for p in range(n + 1):
                q = n - p; e = [1] * p + [-1] * q; top = (1 << n) - 1
                z2 = sgn(top, top, e)                           # the volume element squares to +-1
                trivial = is_square(z2, l)                      # even part has split centre <=> class 0 in BW(F_l) (Br(F_l) = 0)
                pred = (l % 4 == 1) or ((p - q) % 4 == 0)
                if trivial != pred: ok = False
                table.setdefault(l % 4, set()).add(((p - q) % 4, trivial))
    row(19, ok, 'Brauer-Wall class of Cl(p,q) over F_l, n even <= 8, l = 3, 5, 7, 11, 13: trivial exactly when the volume element squares to a square of F_l, i.e. iff p - q = 0 mod 4 for l = 3 mod 4 and always for l = 1 mod 4: with BW(F_l) = Z_4 (l = 3 mod 4) or Z_2 x Z_2 (l = 1 mod 4) (recalled, not computed), the finite-field clock of Cl(p,q) is p - q mod 4, resp. p + q mod 2: the real clock reduced, no further invariant (QC2)')

def check20():
    ok = True; seen = {}
    for pr in (3, 5, 7, 11, 13):
        for a in range(1, pr):
            e = [a, 0]
            # structure constants over F_p: e_x e_y = sgn e_{x^y}, with the square a of e1 entering as a scalar
            def m(x, y): return sgn(x, y, e) % pr
            J = [x for x in range(4) if x & 2]                  # labels with the null bit: e2, e12
            JJ0 = all(m(x, y) == 0 for x in J for y in J)
            ideal = all((m(x, y) == 0 or (x ^ y) & 2) and (m(y, x) == 0 or (x ^ y) & 2) for x in J for y in range(4))
            field = not any((t * t - a) % pr == 0 for t in range(pr))   # F_p[e1]/(e1^2 - a) is a field iff a is a non-residue
            nonres = pow(a, (pr - 1) // 2, pr) == pr - 1
            if not (JJ0 and ideal and field == nonres): ok = False
            seen[(pr, nonres)] = seen.get((pr, nonres), 0) + 1
    row(20, ok, 'over F_p (p = 3..13) the bit rule with squares (a, 0) has the square-zero ideal J = span(e2, e12) and quotient F_p[e1]/(e1^2 - a), a field F_{p^2} exactly for the (p-1)/2 non-residues a: the shape (F_{p^2} + F_{p^2} e2, e2^2 = 0, e2 x = conj(x) e2) of the reduction of a maximal order of the quaternion algebra (a, p) over Q_p, which is ramified exactly for a non-residue (recalled, not computed). At n = 2, "null generator mod p" with a field quotient reads "ramified at p" (QC2, QE6)')

if __name__ == '__main__':
    for f in (check18, check21, check19, check20): f()
    verdict()
