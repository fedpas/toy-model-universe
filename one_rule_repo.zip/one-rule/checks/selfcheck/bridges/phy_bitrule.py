#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""phy_bitrule.py: the small bit-rule engine that phy_coupled_action.py, phy_dirac.py, phy_horizon_little_group.py, phy_staggered.py and
phy_trio.py import (a library: it holds no check and prints nothing).

Blades are bit masks; e_a e_b = s(a,b) e_{a xor b} with s(a,b) = (-1)^{#(i in a, j in b, j < i)} prod_{i in a&b} eps_i, eps_i in {+1, -1, 0}.
Alg holds the sign table of one cell and multiplies multivectors stored as numpy vectors of length 2^n; Reporter prints the check lines
(ok / FAIL / info) and the verdict line of a bridge script.  numpy and the standard library."""
import sys
import numpy as np

def popcount(x):
    return bin(x).count('1')

def reorder_sign(a, b):
    s = 0
    a2 = a >> 1
    while a2:
        s += popcount(a2 & b)
        a2 >>= 1
    return -1 if s & 1 else 1

def sign(a, b, eps):
    s = reorder_sign(a, b)
    c = a & b
    i = 0
    while c:
        if c & 1:
            s *= eps[i]
            if s == 0:
                return 0
        c >>= 1
        i += 1
    return s

class Alg:
    def __init__(self, eps):
        self.eps = list(eps); self.n = len(eps); self.N = 1 << self.n
        self.S = np.zeros((self.N, self.N), dtype=np.int64)
        for a in range(self.N):
            for b in range(self.N):
                self.S[a, b] = sign(a, b, self.eps)
        self.grade = np.array([popcount(a) for a in range(self.N)])

    @staticmethod
    def pq(p, q, r=0):
        return Alg([1] * p + [-1] * q + [0] * r)

    def mul(self, x, y):
        z = np.zeros(self.N, dtype=np.result_type(x, y, float))
        for a in np.nonzero(x)[0]:
            for b in np.nonzero(y)[0]:
                s = self.S[a, b]
                if s:
                    z[a ^ b] += s * x[a] * y[b]
        return z

    def blade(self, a, c=1.0):
        v = np.zeros(self.N); v[a] = c; return v

    def vec(self, coeffs):
        v = np.zeros(self.N)
        for i, c in enumerate(coeffs):
            v[1 << i] = c
        return v

    def grade_part(self, x, k):
        y = np.array(x, dtype=float).copy(); y[self.grade != k] = 0; return y

    def reverse(self, x):
        y = np.array(x, dtype=float).copy()
        for a in range(self.N):
            k = self.grade[a]
            if (k * (k - 1) // 2) % 2:
                y[a] = -y[a]
        return y

    def dagger(self, x):
        """the involution of T15: e_i -> e_i^{-1} = eps_i e_i (null generators fixed), extended as an anti-automorphism"""
        y = self.reverse(x)
        for a in range(self.N):
            s = 1
            for i in range(self.n):
                if a >> i & 1 and self.eps[i] == -1:
                    s = -s
            y[a] *= s
        return y

    def commutator(self, x, y):
        return self.mul(x, y) - self.mul(y, x)

    def scalar(self, x):
        return float(x[0])

    def random_even(self, rng, scale=1.0):
        x = rng.normal(size=self.N) * scale; x[self.grade % 2 == 1] = 0; return x

    def random_vec(self, rng):
        return self.vec(rng.normal(size=self.n))

class Reporter:
    """one line per check id: 'ok   <id>  <text>' or 'FAIL <id>  <text>'; 'info <id>  <text>' for a line that reads a value off and is not a check;
    finish() prints '<k>/<n> bridge checks hold.' and exits 1 when a check fails"""
    def __init__(self):
        self.ids = []; self.fails = []
    def __call__(self, cid, ok, text):
        self.ids.append(cid)
        print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
        if not ok:
            self.fails.append(cid)
    def info(self, cid, text):
        print('info ' + cid + '  ' + text)
    def finish(self):
        n = len(self.ids)
        print(f'\n{n - len(self.fails)}/{n} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not self.fails else '  FAILED: ' + ' '.join(self.fails)))
        sys.exit(1 if self.fails else 0)
