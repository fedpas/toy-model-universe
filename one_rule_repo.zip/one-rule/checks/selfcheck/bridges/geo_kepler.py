#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""geo_kepler.py: the Kepler energy trio and the three Klein geometries of the projective step, through Fock's projection.

  python3 selfcheck/bridges/geo_kepler.py      one line, id bd·geo·17; exit 1 if the check fails

Standard library only, exact rationals, deterministic, under 1 s; runs from any folder, reads and writes no file.
 bd·geo·17  for a Kepler orbit (potential -k/r, angular momentum L, eccentricity e) the momentum hodograph is the circle
            p(theta) = (k/L)(-sin theta, e + cos theta); with e = 3/5 (E < 0), e = 1 (E = 0), e = 5/3 (E > 0), p0^2 = 2|E| is a rational square.
            Fock's map sends the hodograph
              E < 0: to the unit sphere S^3 by xi = (p0^2 - |p|^2, 2 p0 p) / (p0^2 + |p|^2): |xi| = 1 and the images span a 2-plane through 0
                     (a great circle, a geodesic of S^3);
              E > 0: to the hyperboloid H^3 by xi = (p0^2 + |p|^2, 2 p0 p) / (|p|^2 - p0^2): xi0^2 - |xi|^2 = 1, rank 2 (a geodesic of H^3);
              E = 0: by the inversion p -> p / |p|^2 to a straight line of R^3 (affine rank 1).
            So the Kepler orbits of energy E < 0, = 0, > 0 go to geodesics of the sphere, Euclidean space and hyperbolic space, the three Klein
            geometries of the projective step with a space base (s = -1, 0, +1), whose bivector algebras core·B16 matches with the Kepler
            symmetry algebras. A wrong p0 is a control: its image is not planar. Fock (1935) and Moser (1970): pointers, sources unread.
"""
import sys
from fractions import Fraction as Fr

def rank(rows):
    M = [list(r) for r in rows]; rk = 0; ncol = len(M[0])
    for c in range(ncol):
        piv = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c] / M[rk][c]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1
    return rk

def hodograph(e, k=Fr(2), L=Fr(3), ts=range(-6, 7)):
    pts = []
    for t in ts:
        t = Fr(t, 2)
        c, s = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)
        pts.append(((k / L) * (-s), (k / L) * (e + c), Fr(0)))     # orbit in the plane z = 0; a 3-vector
    E = (k * k / (2 * L * L)) * (e * e - 1)
    return pts, E

def main():
    ok = True; out = []
    k, L = Fr(2), Fr(3)
    # E < 0
    pts, E = hodograph(Fr(3, 5)); p0 = (k / L) * Fr(4, 5)
    ok &= E < 0 and p0 * p0 == -2 * E
    xs = []
    for p in pts:
        pp = sum(c * c for c in p)
        xi = [(p0 * p0 - pp) / (p0 * p0 + pp)] + [2 * p0 * c / (p0 * p0 + pp) for c in p]
        ok &= sum(c * c for c in xi) == 1
        xs.append(xi)
    r1 = rank(xs); ok &= r1 == 2; out.append(('E<0', str(E), 'S^3', r1))
    # E > 0
    pts, E = hodograph(Fr(5, 3)); p0 = (k / L) * Fr(4, 3)
    ok &= E > 0 and p0 * p0 == 2 * E
    xs = []
    for p in pts:
        pp = sum(c * c for c in p)
        if pp == p0 * p0: continue                                  # the asymptotic directions go to infinity
        xi = [(p0 * p0 + pp) / (pp - p0 * p0)] + [2 * p0 * c / (pp - p0 * p0) for c in p]
        ok &= xi[0] ** 2 - sum(c * c for c in xi[1:]) == 1
        xs.append(xi)
    r2 = rank(xs); ok &= r2 == 2; out.append(('E>0', str(E), 'H^3', r2))
    # E = 0
    pts, E = hodograph(Fr(1)); ok &= E == 0
    inv = []
    for p in pts:
        pp = sum(c * c for c in p)
        if pp == 0: continue
        inv.append([c / pp for c in p])
    diffs = [[a - b for a, b in zip(v, inv[0])] for v in inv[1:]]
    r3 = rank(diffs); ok &= r3 == 1; out.append(('E=0', str(E), 'R^3', r3))
    # control: a wrong p0 breaks the great circle (the map lands off the sphere)
    pts, E = hodograph(Fr(3, 5)); p0w = (k / L)
    bad = [((p0w * p0w - sum(c * c for c in p)) / (p0w * p0w + sum(c * c for c in p))) for p in pts]
    xsw = [[b] + [2 * p0w * c / (p0w * p0w + sum(cc * cc for cc in p)) for c in p] for b, p in zip(bad, pts)]
    ctrl = rank(xsw) > 2
    ok &= ctrl
    print(('ok   ' if ok else 'FAIL ') + 'bd·geo·17  Kepler hodographs under Fock\'s map (energy, target, rank of the image points): ' + str(out) +
          '; a great circle of S^3, a geodesic of H^3, a straight line of R^3: the energy trio of the Kepler problem is the trio sphere / Euclid / hyperbolic '
          'of step 11 (space base, s = -1, 0, +1), geometrically and not only as Lie algebras (core·B16); with the wrong p0 the image is not planar (' + str(ctrl) + ')')
    print(f'\n{1 if ok else 0}/1 bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if ok else 'SOME BRIDGE CHECK FAILED'))
    return ok

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
