#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mjc_nerve.py: the nerve of a category, its cohomology H^0, H^1, H^2, and what the paper's planar picture is as cochains: the planar vectors
D(f) = P(cod f) - P(dom f) of Def. 1 and (4), the printed component rule of (8), the area f ^ g of composable pairs and the geometric product
f g = f . g + f ^ g as 2-cochains, and the weight (9) as a 1-cocycle (the paper: arXiv:2403.19689 (v3), Def. 1, eqs. (4), (8), (9)).

    python3 selfcheck/bridges/mjc_nerve.py              one line per check, ids bd·mjc·20 .. bd·mjc·24; exit 1 on any FAIL
    python3 selfcheck/bridges/mjc_nerve.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library only; exact ranks over Q (fractions) and over F_p; integer positions; deterministic (seeds 41..45), under 1 s; runs from any
folder, reads and writes no file.  Normalised chains: a k-simplex is a string of k composable non-identity arrows (f1 first); the boundary is
d(f1..fk) = (f2..fk) + sum_i (-1)^i (.., f_{i+1} o f_i, ..) + (-1)^k (f1..f_{k-1}), a face with an identity entry being 0.
  bd·mjc·20  (dim H^0, dim H^1, dim H^2) over R of the nerve, with d o d = 0 checked on every complex: B_0..B_4 (1,0,0) (a least element: a cone);
             the Kronecker category (two parallel arrows) and the crown poset (1,1,0) (a circle); {1, e} with e idempotent (1,0,0); Z_2, Z_3,
             S_3 and the pair groupoid on two objects (1,0,0) over R, while Z_2 over F_2 and Z_3 over F_3 give (1,1,1); the free monoid on one
             letter (infinite; the subcomplex of total length <= 6) (1,1,0).  With coefficients in R^2 (the complex tensored with R^2, computed
             for B_3, Kronecker, crown, Z_3, the pair groupoid) every dimension doubles: (2,0,0), (2,2,0), ...
  bd·mjc·21  D = delta P (P integer positions in the plane, injective as in (4)) is a 1-cocycle, D(g o f) = D(f) + D(g), on every composable pair,
             and a coboundary by construction, for every category tested (B_1..B_4, Kronecker, monoids, groups, 100 random concrete categories,
             seed 42): generic, a theorem.  The printed component rule of (8), f ⊕ g = (a1 + b1) e1 + (a2 + b2) e2, agrees with D(g o f) on k of N
             composable pairs of B_3 under random P (seed 43), exactly those with b1 = a2: it is not a cocycle.
  bd·mjc·22  the area cochain A(f, g) = D(f) ^ D(g) and the geometric-product cochain G(f, g) = D(f) D(g) in Cl(2,0) (scalar f . g plus bivector
             f ^ g) are 2-cocycles on every 3-simplex and coboundaries: A = delta B with B(f) = P(dom f) ^ P(cod f) (the shoelace form) and
             G = delta (P cup D), (P cup D)(f) = P(dom f) D(f); the Stokes identity <A, c> = <B, dc> holds on 200 random integer 2-chains of B_3
             (seed 44); the same on random concrete categories: generic (the Leibniz rule of the cup product), not a finding.  The sabotage
             perturbs the area cochain A on the pairs that leave object 0, in the cocycle clauses and in the Stokes pairing.
  bd·mjc·23  what the plane cannot see: on the Kronecker category the cycle f - g spans H_1, every D = delta P gives <D, f - g> = 0 (parallel
             arrows have equal planar vectors), while a positive weight with w(f) != w(g) gives <w, f - g> != 0: the class [w] in H^1 is the one
             cohomological datum of the paper's structure; on B_3 every positive additive weight is a coboundary (class 0).  Two remarks of
             the line hold by definition and are not part of the check: parallel arrows have equal planar vectors, and on a one-object
             category every planar vector is 0 (all arrows are loops at the one point P(*)).
  bd·mjc·24  control: random posets on 8 elements (seed 45) have H^1 != 0 in k of 200 and H^2 != 0 in k' of 200 (printed); with a least element
             adjoined, (1,0,0) in 200 of 200 (generic for posets with a minimum, not a finding about the labels).
"""
import sys, random, itertools
from fractions import Fraction

SABOTAGE = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if not SABOTAGE: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    else: print('  sabotaged input, what the check sees: ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def rank(rows, p=None):
    """rank of a list of sparse rows {col: int} over Q (p None, exact fractions) or over F_p"""
    piv = {}
    rk = 0
    for r in rows:
        v = {k: (Fraction(x) if p is None else x % p) for k, x in r.items() if (x if p is None else x % p)}
        while v:
            c = min(v)
            if c in piv:
                pr = piv[c]; f = v[c] / pr[c] if p is None else (v[c] * pow(pr[c], p - 2, p)) % p
                for k, x in pr.items():
                    nv = v.get(k, 0) - f * x
                    if p is not None: nv %= p
                    if nv: v[k] = nv
                    elif k in v: del v[k]
            else:
                piv[c] = v; rk += 1; break
    return rk

class Cat:
    def __init__(self, m, dom, cod, ident, comp, name=''):
        self.m, self.dom, self.cod, self.ident, self.comp, self.name = m, dom, cod, ident, comp, name
        self.A = len(dom); self.isid = set(ident); self.nonid = [f for f in range(self.A) if f not in self.isid]
    def c(self, f, g): return self.comp[(f, g)]
def build(name, m, arrows, table):
    names = list(arrows); k = len(names); idx = {x: i for i, x in enumerate(names)}
    dom = [arrows[x][0] for x in names] + list(range(m)); cod = [arrows[x][1] for x in names] + list(range(m))
    ident = [k + o for o in range(m)]; comp = {}
    for f in range(k + m):
        for g in range(k + m):
            if cod[f] != dom[g]: continue
            if f >= k: comp[(f, g)] = g
            elif g >= k: comp[(f, g)] = f
            else:
                v = table[(names[f], names[g])]; comp[(f, g)] = (k + dom[f]) if v == '1' else idx[v]
    return Cat(m, dom, cod, ident, comp, name)
def boolean_lattice(n):
    L = range(1 << n); arrows = [(s, t) for s in L for t in L if (s & t) == s]; index = {x: i for i, x in enumerate(arrows)}
    comp = {(i, j): index[(arrows[i][0], arrows[j][1])] for i in range(len(arrows)) for j in range(len(arrows)) if arrows[i][1] == arrows[j][0]}
    return Cat(1 << n, [x[0] for x in arrows], [x[1] for x in arrows], [index[(s, s)] for s in L], comp, f'B_{n}'), arrows
def group_cat(name, elems, mul, e):
    idx = {x: i for i, x in enumerate(elems)}; comp = {(i, j): idx[mul(elems[j], elems[i])] for i in range(len(elems)) for j in range(len(elems))}
    return Cat(1, [0] * len(elems), [0] * len(elems), [idx[e]], comp, name)
def poset_cat(name, m, less):
    """less: set of strict pairs (x, y), x < y, already transitively closed"""
    arrows = [(x, x) for x in range(m)] + sorted(less); index = {a: i for i, a in enumerate(arrows)}
    comp = {(i, j): index[(arrows[i][0], arrows[j][1])] if arrows[i][0] != arrows[j][1] else index[(arrows[i][0], arrows[i][0])]
            for i in range(len(arrows)) for j in range(len(arrows)) if arrows[i][1] == arrows[j][0]}
    return Cat(m, [a[0] for a in arrows], [a[1] for a in arrows], [index[(x, x)] for x in range(m)], comp, name)

# ------------------------------------------------------------------ the normalised nerve of a finite category, degrees 0..kmax
def nerve(C, kmax):
    S = [[(o,) for o in range(C.m)]]                                   # vertices as 1-tuples of objects
    chains = [tuple()]
    S1 = [(f,) for f in C.nonid]; S.append(S1)
    cur = S1
    for k in range(2, kmax + 1):
        nxt = [s + (g,) for s in cur for g in C.nonid if C.cod[s[-1]] == C.dom[g]]
        S.append(nxt); cur = nxt
    return S
def boundary(C, s, k):
    """the faces of a k-simplex with signs: list of (sign, face) with face a (k-1)-simplex key; identity faces dropped"""
    if k == 1:
        f = s[0]; return [(1, (C.cod[f],)), (-1, (C.dom[f],))]
    out = [(1, s[1:])]
    for i in range(k - 1):
        h = C.c(s[i], s[i + 1])
        if h in C.isid: continue
        out.append(((-1) ** (i + 1), s[:i] + (h,) + s[i + 2:]))
    out.append(((-1) ** k, s[:-1]))
    return out
def homology(C, kmax=3, p=None, check_dd=True, coeff=1):
    """(dim H^0, .., dim H^(kmax-1)) with coefficients in the field^coeff (coeff = 2: R^2, the chain complex tensored with R^2)"""
    S = nerve(C, kmax); index = [{s: i for i, s in enumerate(Sk)} for Sk in S]
    ranks = {}; dd_ok = True
    for k in range(1, kmax + 1):
        rows = []
        for s in S[k]:
            for t in range(coeff):                                     # one row per simplex and coefficient coordinate
                r = {}
                for sg, face in boundary(C, s, k):
                    key = index[k - 1][face] * coeff + t
                    r[key] = r.get(key, 0) + sg
                rows.append(r)
        ranks[k] = rank(rows, p)
        if check_dd and k >= 2:
            for s in S[k]:
                tot = {}
                for sg, face in boundary(C, s, k):
                    for sg2, f2 in boundary(C, face, k - 1): tot[f2] = tot.get(f2, 0) + sg * sg2
                if any(tot.values()): dd_ok = False
    H = tuple(coeff * len(S[k]) - ranks.get(k, 0) - ranks.get(k + 1, 0) for k in range(0, kmax))
    return H, dd_ok

def free_monoid_homology(L, kmax=3):
    """the free monoid on one letter: arrows x^a (a >= 1); simplices = compositions (a1..ak) of total <= L (a subcomplex)"""
    S = [[()]]
    for k in range(1, kmax + 1):
        S.append([c for c in itertools.product(range(1, L + 1), repeat=k) if sum(c) <= L])
    index = [{s: i for i, s in enumerate(Sk)} for Sk in S]; ranks = {}
    for k in range(1, kmax + 1):
        rows = []
        for s in S[k]:
            faces = [(1, s[1:])] + [((-1) ** (i + 1), s[:i] + (s[i] + s[i + 1],) + s[i + 2:]) for i in range(k - 1)] + [((-1) ** k, s[:-1])]
            r = {}
            for sg, fc in faces: r[index[k - 1][fc]] = r.get(index[k - 1][fc], 0) + sg
            rows.append(r)
        ranks[k] = rank(rows)
    return tuple(len(S[k]) - ranks.get(k, 0) - ranks.get(k + 1, 0) for k in range(0, kmax))

def zoo():
    Z = {}
    for n in range(0, 5): Z[f'B_{n}'] = boolean_lattice(n)[0]
    Z['Kronecker'] = build('Kronecker', 2, {'f': (0, 1), 'g': (0, 1)}, {})
    Z['crown'] = build('crown', 4, {'ac': (0, 2), 'ad': (0, 3), 'bc': (1, 2), 'bd': (1, 3)}, {})
    Z['{1,e}'] = build('{1,e}', 1, {'e': (0, 0)}, {('e', 'e'): 'e'})
    Z['Z2'] = group_cat('Z2', [0, 1], lambda a, b: (a + b) % 2, 0)
    Z['Z3'] = group_cat('Z3', [0, 1, 2], lambda a, b: (a + b) % 3, 0)
    S3 = list(itertools.permutations(range(3)))
    Z['S3'] = group_cat('S3', S3, lambda a, b: tuple(a[b[i]] for i in range(3)), (0, 1, 2))
    Z['pair groupoid'] = build('pair groupoid', 2, {'u': (0, 1), 'v': (1, 0)}, {('u', 'v'): '1', ('v', 'u'): '1'})
    return Z

# ================================================================== bd·mjc·20  cohomology of the nerve
def check20(sab=False):
    Z = zoo(); res = {}; dd_all = True
    expect = {'B_0': (1, 0, 0), 'B_1': (1, 0, 0), 'B_2': (1, 0, 0), 'B_3': (1, 0, 0), 'B_4': (1, 0, 0), 'Kronecker': (1, 1, 0), 'crown': (1, 1, 0),
              '{1,e}': (1, 0, 0), 'Z2': (1, 0, 0), 'Z3': (1, 0, 0), 'S3': (1, 0, 0), 'pair groupoid': (1, 0, 0)}
    for name, C in Z.items():
        if sab and name == 'B_3': C = Z['crown']                          # sabotage: the crown poset computed under the name B_3
        H, dd = homology(C, 3); res[name] = H; dd_all &= dd
    res['Z2 over F_2'] = homology(Z['Z2'], 3, p=2)[0]; res['Z3 over F_3'] = homology(Z['Z3'], 3, p=3)[0]
    res['free monoid N (total <= 6)'] = free_monoid_homology(6)
    r2 = {name: homology(Z[name], 3, check_dd=False, coeff=2)[0] for name in ('B_3', 'Kronecker', 'crown', 'Z3', 'pair groupoid')}
    double_ok = all(r2[k] == tuple(2 * x for x in res[k]) for k in r2)
    res['with R^2 coefficients'] = r2
    ok = double_ok and dd_all and all(res[k] == v for k, v in expect.items()) and res['Z2 over F_2'] == (1, 1, 1) and res['Z3 over F_3'] == (1, 1, 1) and res['free monoid N (total <= 6)'] == (1, 1, 0)
    return report('bd·mjc·20', ok, '(dim H^0, H^1, H^2) of the nerve: ' + '; '.join(f'{k}: {v}' for k, v in res.items()) + f'; d o d = 0 on every complex: {dd_all}')

# ------------------------------------------------------------------ planar cochains
def wedge(u, v): return u[0] * v[1] - u[1] * v[0]
def dot(u, v): return u[0] * v[0] + u[1] * v[1]
def sub(u, v): return (u[0] - v[0], u[1] - v[1])
def random_positions(m, rng):
    pts = set(); P = []
    while len(P) < m:
        p = (rng.randint(-9, 9), rng.randint(-9, 9))
        if p not in pts: pts.add(p); P.append(p)                         # injective, as (4) asks
    return P
def random_concrete(rng):
    m = rng.randint(2, 4); sizes = [rng.randint(1, 3) for _ in range(m)]
    gens = []
    for _ in range(rng.randint(2, 4)):
        a = rng.randrange(m); b = rng.randrange(m); gens.append((a, b, tuple(rng.randrange(sizes[b]) for _ in range(sizes[a]))))
    arrows = {(o, o, tuple(range(sizes[o]))) for o in range(m)} | set(gens); changed = True
    while changed:
        changed = False
        for (a, b, f) in list(arrows):
            for (b2, c, g) in list(arrows):
                if b2 == b:
                    h = (a, c, tuple(g[f[x]] for x in range(sizes[a])))
                    if h not in arrows: arrows.add(h); changed = True
        if len(arrows) > 60: return None
    arrows = sorted(arrows); index = {x: i for i, x in enumerate(arrows)}
    comp = {(i, j): index[(a, c, tuple(g[f[x]] for x in range(sizes[a])))] for i, (a, b, f) in enumerate(arrows) for j, (b2, c, g) in enumerate(arrows) if b2 == b}
    return Cat(m, [x[0] for x in arrows], [x[1] for x in arrows], [index[(o, o, tuple(range(sizes[o])))] for o in range(m)], comp)
def random_cats(seed, N):
    rng = random.Random(seed); out = []
    while len(out) < N:
        C = random_concrete(rng)
        if C is not None: out.append(C)
    return out

# ================================================================== bd·mjc·21  D = delta P; the printed component rule
def check21(sab=False):
    rng = random.Random(42); Z = zoo(); cats = [Z[k] for k in ('B_1', 'B_2', 'B_3', 'B_4', 'Kronecker', '{1,e}', 'Z3', 'S3', 'pair groupoid')] + random_cats(42, 100)
    cocycle_ok = 0
    for C in cats:
        P = random_positions(C.m, rng)
        D = {f: sub(P[C.cod[f]], P[C.dom[f]]) for f in range(C.A)}
        if sab: D = {f: (D[f][0] + (1 if C.dom[f] == 0 and f in C.nonid else 0), D[f][1]) for f in range(C.A)}   # sabotage: shift the arrows out of object 0
        cocycle_ok += all(D[C.c(f, g)] == (D[f][0] + D[g][0], D[f][1] + D[g][1]) for (f, g) in C.comp)
    C3, arr3 = boolean_lattice(3); rng2 = random.Random(43); agree = total = predicted = 0
    for _ in range(50):
        P = random_positions(8, rng2)
        for f in C3.nonid:
            for g in C3.nonid:
                if C3.cod[f] != C3.dom[g]: continue
                a1, b1 = sub(P[C3.cod[f]], P[C3.dom[f]]); a2, b2 = sub(P[C3.cod[g]], P[C3.dom[g]])
                printed = (a1 + b1, a2 + b2); true = sub(P[C3.cod[g]], P[C3.dom[f]])
                total += 1; agree += (printed == true); predicted += (b1 == a2)
    ok = cocycle_ok == len(cats) and agree == predicted and agree < total
    return report('bd·mjc·21', ok, f'D(f) = P(cod f) - P(dom f) is a 1-cocycle (D(g o f) = D(f) + D(g) on every composable pair) in {cocycle_ok} of {len(cats)} categories (B_1..B_4, Kronecker, {{1,e}}, Z3, S3, pair groupoid, 100 random concrete categories; random injective integer P, seed 42): generic; the printed rule f ⊕ g = (a1 + b1) e1 + (a2 + b2) e2 equals D(g o f) = (a1 + a2) e1 + (b1 + b2) e2 on {agree} of {total} composable pairs of B_3 (50 random P, seed 43), exactly the {predicted} pairs with b1 = a2')

# ================================================================== bd·mjc·22  area and geometric-product cochains; Stokes
def cl_vv(u, v): return (dot(u, v), 0, 0, wedge(u, v))                 # product of two vectors in Cl(2,0): (scalar, e1, e2, e12)
def cl_add(*xs): return tuple(sum(x[i] for x in xs) for i in range(4))
def cl_neg(x): return tuple(-t for t in x)
def check22(sab=False):
    rng = random.Random(44); Z = zoo(); cats = [Z[k] for k in ('B_2', 'B_3', 'Kronecker', 'crown', '{1,e}', 'S3')] + random_cats(44, 60)
    coc = cob = gco = gcb = 0
    for C in cats:
        P = random_positions(C.m, rng)
        D = {f: sub(P[C.cod[f]], P[C.dom[f]]) for f in range(C.A)}
        A = lambda f, g: wedge(D[f], D[g]) + (1 if sab and C.dom[f] == 0 and C.dom[g] != 0 else 0)   # sabotage: a perturbed area cochain
        B = lambda f: wedge(P[C.dom[f]], P[C.cod[f]])
        G = lambda f, g: cl_vv(D[f], D[g])
        PD = lambda f: cl_vv(P[C.dom[f]], D[f])
        S = nerve(C, 3)
        coc += all(A(t[1], t[2]) - A(C.c(t[0], t[1]), t[2]) + A(t[0], C.c(t[1], t[2])) - A(t[0], t[1]) == 0 for t in S[3])
        cob += all(A(f, g) == B(g) - B(C.c(f, g)) + B(f) for (f, g) in [s for s in S[2]])
        gco += all(cl_add(G(t[1], t[2]), cl_neg(G(C.c(t[0], t[1]), t[2])), G(t[0], C.c(t[1], t[2])), cl_neg(G(t[0], t[1]))) == (0, 0, 0, 0) for t in S[3])
        gcb += all(G(f, g) == cl_add(PD(g), cl_neg(PD(C.c(f, g))), PD(f)) for (f, g) in S[2])
    # Stokes on random 2-chains of B_3
    C3, _ = boolean_lattice(3); P = random_positions(8, rng); D = {f: sub(P[C3.cod[f]], P[C3.dom[f]]) for f in range(C3.A)}
    A3 = lambda f, g: wedge(D[f], D[g]) + (1 if sab and C3.dom[f] == 0 and C3.dom[g] != 0 else 0)   # sabotage: the same perturbed area cochain
    S2 = nerve(C3, 2)[2]; stokes = 0
    for _ in range(200):
        c = {s: rng.randint(-3, 3) for s in rng.sample(S2, 6)}
        lhs = sum(k * A3(s[0], s[1]) for s, k in c.items())
        rhs = 0
        for s, k in c.items():
            for sg, face in boundary(C3, s, 2): rhs += k * sg * wedge(P[C3.dom[face[0]]], P[C3.cod[face[0]]])
        stokes += (lhs == rhs)
    N = len(cats)
    ok = coc == cob == gco == gcb == N and stokes == 200
    return report('bd·mjc·22', ok, f'A(f,g) = D(f) ^ D(g): delta A = 0 on every 3-simplex in {coc} of {N} categories and A = delta B with B(f) = P(dom f) ^ P(cod f) (shoelace) in {cob} of {N}; G(f,g) = D(f) D(g) = f . g + f ^ g in Cl(2,0): delta G = 0 in {gco} of {N}, G = delta(P cup D) in {gcb} of {N} (B_2, B_3, Kronecker, crown, {{1,e}}, S3, 60 random concrete categories, seed 44); Stokes <A, c> = <B, dc> on {stokes} of 200 random 2-chains of B_3: a theorem (Leibniz rule of the cup product), generic')

# ================================================================== bd·mjc·23  what the plane cannot see
def is_coboundary(C, w):
    """is the 1-cochain w (dict on non-identity arrows) = phi(cod) - phi(dom) for some phi?  exact rank test"""
    idx = {f: i for i, f in enumerate(C.nonid)}
    rows = []
    for o in range(C.m):
        r = {}
        for f in C.nonid: r[idx[f]] = r.get(idx[f], 0) + (1 if C.cod[f] == o else 0) - (1 if C.dom[f] == o else 0)
        rows.append({k: v for k, v in r.items() if v})
    wv = {idx[f]: w[f] for f in C.nonid if w[f]}
    return rank(rows) == rank(rows + [wv])
def check23(sab=False):
    rng = random.Random(45); K = zoo()['Kronecker']; f, g = K.nonid
    planar_zero = all((lambda P: sub(P[K.cod[f]], P[K.dom[f]]) == sub(P[K.cod[g]], P[K.dom[g]]))(random_positions(2, rng)) for _ in range(50))   # by definition (parallel arrows): a remark
    w = {f: 1, g: 2} if not sab else {f: 1, g: 1}                         # sabotage: equal weights on the parallel arrows
    w_class = w[f] - w[g]
    w_cob = is_coboundary(K, w)
    C3, arr3 = boolean_lattice(3); allcob = True
    for _ in range(50):
        phi_rand = {f2: rng.randint(1, 4) for f2 in C3.nonid}
        # a random positive additive weight on B_3: build it from a random strictly increasing phi
        phi = [0] * 8
        for x in sorted(range(8), key=pc): phi[x] = max([phi[y] for y in range(8) if (y & x) == y and y != x], default=0) + rng.randint(1, 3)
        wt = {f2: phi[arr3[f2][1]] - phi[arr3[f2][0]] for f2 in C3.nonid}
        allcob &= is_coboundary(C3, wt)
    pop = {f2: pc(arr3[f2][0] ^ arr3[f2][1]) for f2 in C3.nonid}
    one = zoo()['S3']; loops_zero = all(one.dom[x] == one.cod[x] for x in one.nonid)   # by definition (one object): a remark
    ok = w_class != 0 and not w_cob and allcob and is_coboundary(C3, pop)
    return report('bd·mjc·23', ok, f'Kronecker category: a positive weight w(f) = 1, w(g) = 2 gives <w, f - g> = {w_class} on the cycle f - g that spans H_1, not a coboundary: {not w_cob}; on B_3 every positive additive weight tested (50) and popcount are coboundaries: {allcob and is_coboundary(C3, pop)}; remarks that hold by definition: the planar vectors of the parallel arrows f, g are equal, so every D = delta P vanishes on f - g (50 random P: {planar_zero}), and on a one-object category (S3) every arrow is a loop, so every planar vector is 0 ({loops_zero})')

# ================================================================== bd·mjc·24  control: random posets
def check24(sab=False):
    rng = random.Random(45); h1 = h2 = 0; cone_ok = 0
    for _ in range(200):
        m = 8; less = set()
        up = [1 << i for i in range(m)]
        for i in range(m - 1, -1, -1):
            for j in range(i + 1, m):
                if rng.random() < 0.3: up[i] |= up[j]
        less = {(x, y) for x in range(m) for y in range(m) if x != y and up[x] >> y & 1}
        C = poset_cat('rp', m, less)
        H, _ = homology(C, 3, check_dd=False)
        h1 += H[1] > 0; h2 += H[2] > 0
        # adjoin a least element (object m below everything)
        less2 = less | {(m, x) for x in range(m)}
        if sab: less2 = less                                              # sabotage: no least element adjoined
        C2 = poset_cat('rp+min', m + 1, less2)
        cone_ok += homology(C2, 3, check_dd=False)[0] == (1, 0, 0)
    ok = h1 > 0 and cone_ok == 200
    return report('bd·mjc·24', ok, f'control: random posets on 8 elements (seed 45): H^1 != 0 in {h1} of 200, H^2 != 0 in {h2} of 200; with a least element adjoined (1,0,0) in {cone_ok} of 200 (B_n is contractible because it has the least element 0, a generic fact)')

CHECKS = [('bd·mjc·20', check20), ('bd·mjc·21', check21), ('bd·mjc·22', check22), ('bd·mjc·23', check23), ('bd·mjc·24', check24)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear()
            okk = f(sab=True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            if okk: missed += 1
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    nfail = sum(1 for _, okk in RESULTS if not okk)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
