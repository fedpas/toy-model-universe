#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sol_kitaev_lieb.py: the signed cube of the spring step as a Z_2 gauge field, and the central split as Kitaev's honeycomb gauge projection.

  bd·sol·27  free fermions hopping on the n-cube graph with a Z_2 gauge field s (a sign per edge), half filling (2^(n-1) particles):
             E_half(s) = -(1/2) sum |lambda_i(A_s)| >= -(1/2) sqrt(2^n tr A_s^2) = -2^(n-1) sqrt(n) (Cauchy-Schwarz, tr A_s^2 = n 2^n for every s),
             with equality iff A_s^2 = n I, i.e. iff the flux through every square face is pi: the bit-rule (Huang) signing D.  Every flux
             sector (gauge classes) is enumerated for n = 2, 3, 4: the minimum is attained exactly in the all-pi sector, and the zero-flux cube
             (plain adjacency) is higher.  This is Lieb's flux-phase statement on the cube.
  bd·sol·28  Kitaev's honeycomb representation of a spin-1/2: four Majoranas b^x, b^y, b^z, c (the cell Cl(4,0) of T-even Majoranas),
             sigma^a = i b^a c, D = b^x b^y b^z c.  D squares to 1 and commutes with every sigma^a (it is the top blade, central in the even part
             Cl^0(4,0) = Cl(0,3) = H + H: the central split of core·B14); sigma^x sigma^y sigma^z = i D, so the physical subspace D = +1 carries
             the Pauli algebra with central pseudoscalar +i and D = -1 the other irrep (-i): the gauge constraint selects one ideal of the
             split, one chirality of Cl(3,0) (bd·sol·24).
  bd·sol·29  for odd n <= 7, r = 0, the top blade is central with square +1 exactly when p - q = 1 mod 4 (the condition of core·B14): besides the
             four signed cells [n,+1] (p - q = 1), Cl(0,3), Cl(5,0), Cl(1,4), ... split too; Cl^0(4,0) = Cl(0,3) is the one Kitaev's projection
             splits.

  python3 sol_kitaev_lieb.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; a few seconds."""
import itertools, math, sys
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

# ================================================================ 27: Lieb flux phase on the n-cube
def cube_edges(n): return [(a, a ^ (1 << i)) for a in range(1 << n) for i in range(n) if not (a >> i) & 1]
def spanning_tree_edges(n):
    """BFS tree from vertex 0: the edges fixed to +1 by a gauge choice"""
    seen = {0}; tree = set(); frontier = [0]
    while frontier:
        nxt = []
        for a in frontier:
            for i in range(n):
                b = a ^ (1 << i)
                if b not in seen: seen.add(b); tree.add((min(a, b), max(a, b))); nxt.append(b)
        frontier = nxt
    return tree
def check27():
    ok = True; lines = []
    for n in (2, 3, 4):
        E = cube_edges(n); N = 1 << n
        tree = spanning_tree_edges(n); free = [e for e in E if (min(e), max(e)) not in tree]
        bound = -2 ** (n - 1) * math.sqrt(n)
        # Clifford signing D (bit rule, all eps = +1)
        D = np.zeros((N, N))
        for a, b in E:
            i = (a ^ b).bit_length() - 1; s = sgn(1 << i, a, [1] * n); D[a, b] = D[b, a] = s
        eD = -0.5 * np.sum(np.abs(np.linalg.eigvalsh(D)))
        A0 = np.zeros((N, N))
        for a, b in E: A0[a, b] = A0[b, a] = 1
        e0 = -0.5 * np.sum(np.abs(np.linalg.eigvalsh(A0)))
        best = None; nbest = 0; allpi_best = True; nsect = 0
        faces = [(a, i, j) for a in range(N) for i in range(n) for j in range(i + 1, n) if not (a >> i) & 1 and not (a >> j) & 1]
        for signs in itertools.product((1, -1), repeat=len(free)):
            nsect += 1
            M = np.zeros((N, N))
            for a, b in E: M[a, b] = M[b, a] = 1
            for (a, b), s in zip(free, signs): M[a, b] = M[b, a] = s
            e = -0.5 * np.sum(np.abs(np.linalg.eigvalsh(M)))
            allpi = all(M[a, a ^ (1 << i)] * M[a ^ (1 << i), a ^ (1 << i) ^ (1 << j)] * M[a ^ (1 << i) ^ (1 << j), a ^ (1 << j)] * M[a ^ (1 << j), a] == -1 for a, i, j in faces)
            if best is None or e < best - 1e-9: best = e; nbest = 1; best_allpi = allpi
            elif abs(e - best) < 1e-9: nbest += 1; best_allpi = best_allpi and allpi
            if allpi and abs(e - bound) > 1e-9: allpi_best = False
        ok &= abs(best - bound) < 1e-9 and abs(eD - bound) < 1e-9 and nbest == 1 and best_allpi and allpi_best and e0 > bound + 1e-9
        lines.append(f'n={n}: {nsect} flux sectors, min E_half = {best:.4f} = -2^(n-1) sqrt(n) attained by {nbest} sector (all faces pi); zero flux {e0:.4f}')
    row('bd·sol·27', ok, 'half-filled fermions on the n-cube with a Z_2 gauge field: ' + '; '.join(lines))

# ================================================================ 28: Kitaev's projection = central split
def check28():
    sx = np.array([[0, 1], [1, 0]], dtype=complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.diag([1, -1]).astype(complex); I2 = np.eye(2)
    g = [np.kron(sx, I2), np.kron(sy, I2), np.kron(sz, sx), np.kron(sz, sy)]       # four Majoranas b^x, b^y, b^z, c
    bx, by, bz, c = g
    sig = [1j * bx @ c, 1j * by @ c, 1j * bz @ c]
    D = bx @ by @ bz @ c
    ok = np.allclose(D @ D, np.eye(4)) and all(np.allclose(D @ s, s @ D) for s in sig)
    ok &= np.allclose(sig[0] @ sig[1] @ sig[2], 1j * D)
    ok &= all(np.allclose(s @ s, np.eye(4)) for s in sig) and all(np.allclose(sig[a] @ sig[b] + sig[b] @ sig[a], 0) for a in range(3) for b in range(a))
    # D is the top blade of the four T-even Majoranas: central in the even part, not in the whole algebra
    ok &= all(not np.allclose(D @ x, x @ D) for x in g)
    # bit rule: Cl(4,0) top blade squares +1 and commutes with the even blades
    eps = [1, 1, 1, 1]
    ok &= sgn(15, 15, eps) == 1 and all(sgn(15, a, eps) == sgn(a, 15, eps) for a in range(16) if pc(a) % 2 == 0)
    res = {}
    for d in (1, -1):
        w, V = np.linalg.eigh(D); P = V[:, np.isclose(w, d)]
        s = [P.conj().T @ x @ P for x in sig]
        prod = s[0] @ s[1] @ s[2]
        res[d] = complex(np.round(prod[0, 0], 9))
        ok &= P.shape[1] == 2 and np.allclose(prod, d * 1j * np.eye(2))
    row('bd·sol·28', ok, f'Kitaev spin from four Majoranas: D = b^x b^y b^z c is the central top blade of the even part (D^2 = 1, [D, sigma^a] = 0), sigma^x sigma^y sigma^z = iD; on D = +-1 the Pauli algebra has central pseudoscalar {res}: the gauge projection is the central split and picks one chirality')

# ================================================================ 29: which cells split (central top blade of square +1)
def check29():
    split = []
    for n in range(1, 8, 2):
        for p in range(n + 1):
            q = n - p; eps = [1] * p + [-1] * q; top = (1 << n) - 1
            central = all(sgn(top, 1 << i, eps) == sgn(1 << i, top, eps) for i in range(n))
            if central and sgn(top, top, eps) == 1: split.append((p, q))
    signed = [c for c in split if c[0] - c[1] == 1]
    others = [c for c in split if c[0] - c[1] != 1]
    ok = all((p - q) % 4 == 1 for p, q in split) and (0, 3) in others and (5, 0) in others and len(signed) == 4
    # Kitaev's even algebra Cl0(4,0) is Cl(0,3) (T5 (a): f_i = e_i e_4), which is one of the 'other' split cells
    eps4 = [1, 1, 1, 1]; f = [(1 << i) | (1 << 3) for i in range(3)]
    sq = [sgn(a, a, eps4) for a in f]; anti = all(sgn(f[i], f[j], eps4) == -sgn(f[j], f[i], eps4) for i in range(3) for j in range(i))
    ok &= sq == [-1, -1, -1] and anti
    row('bd·sol·29', ok, f'odd n <= 7, r = 0: the top blade is central with square +1 exactly for p - q = 1 mod 4: {split}; of these only {signed} are signed cells [n,+1]; the others ({others}) split too, e.g. Cl(0,3) = H + H, which is Cl0(4,0), the even algebra that the Kitaev projection D = +-1 splits (bd·sol·28)')

if __name__ == '__main__':
    for f in (check27, check28, check29): f()
    finish()
