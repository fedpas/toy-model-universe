#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cat_morita.py: the mirror, the reversion and the null generators in the Morita 2-category of superalgebras.

  python3 selfcheck/bridges/cat_morita.py      one line per check, ids bd·cat·9 .. bd·cat·11; exit 1 on any FAIL

Standard library only, exact integers and rationals, deterministic, about 9 s; runs from any folder, reads and writes no file.
  bd·cat·9   the super-opposite of the bit rule with squares eps is the bit rule with squares -eps on the nose: (-1)^{|a||b|} s_eps(b,a) = s_{-eps}(a,b)
             for every label pair and every eps in {+1,-1,0}^n, n <= 6.
  bd·cat·10  Cl(4,0) and Cl(0,4) are isomorphic superalgebras (f_i = e_i w, w = e_1234), so they have the same cell (V,Q,pi); with their reversions
             they are not isomorphic (the trace form <x^2>_0 on the odd reversion-fixed part is (4,0) against (0,4)); Cl(5,1) and Cl(1,5) are
             isomorphic with their reversions; table of the invariant for n <= 6.
  bd·cat·11  the graded product of Cl(p,q,r) and Cl(p',q',r') has a radical of dimension 2^{n+n'} - 2^{p+q+p'+q'} (trace-form rank), non-zero as soon
             as r + r' >= 1, while a Morita-trivial superalgebra End(S) is semisimple: no cell with r >= 1 is invertible, and the Morita classes of
             the cells form the monoid Z_8 x N, (clock, r) (n + n' <= 5).
"""
import itertools, sys
from fractions import Fraction as Fr

ROWS = []
def row(i, ok, text):
    cid = i
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
def mul(A, B, eps):
    out = {}
    for a, ca in A.items():
        for b, cb in B.items():
            c = ca * cb * sgn(a, b, eps)
            if c: out[a ^ b] = out.get(a ^ b, 0) + c
    return {k: v for k, v in out.items() if v}
def rev(A): return {m: c * (-1) ** (pc(m) * (pc(m) - 1) // 2) for m, c in A.items()}
P = 1000003
def rank_mod(M):
    M = [[x % P for x in r] for r in M]; rk = 0
    for c in range(len(M[0]) if M else 0):
        piv = next((i for i in range(rk, len(M)) if M[i][c]), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]; inv = pow(M[rk][c], P - 2, P); M[rk] = [x * inv % P for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c]:
                f = M[i][c]; M[i] = [(x - f * y) % P for x, y in zip(M[i], M[rk])]
        rk += 1
    return rk
def signature(M):
    """(pos, neg, zero) of a symmetric rational matrix by congruence diagonalisation"""
    n = len(M); A = [[Fr(x) for x in r] for r in M]; pos = neg = 0; act = list(range(n))
    while act:
        piv = next((i for i in act if A[i][i] != 0), None)
        if piv is None:
            pr = next(((i, j) for i in act for j in act if i < j and A[i][j] != 0), None)
            if pr is None: break
            i, j = pr
            for k in range(n): A[i][k] += A[j][k]
            for k in range(n): A[k][i] += A[k][j]
            piv = i
        d = A[piv][piv]
        if d > 0: pos += 1
        else: neg += 1
        for i in act:
            if i != piv and A[i][piv] != 0:
                f = A[i][piv] / d
                for k in range(n): A[i][k] -= f * A[piv][k]
                for k in range(n): A[k][i] -= f * A[k][piv]
        act.remove(piv)
    return (pos, neg, n - pos - neg)

def check9():
    ok = True; cnt = 0
    for n in range(1, 7):
        for e in itertools.product((1, -1, 0), repeat=n):
            m = [-x for x in e]
            for a in range(1 << n):
                for b in range(1 << n):
                    if (-1) ** (pc(a) * pc(b)) * sgn(b, a, e) != sgn(a, b, m): ok = False
            cnt += 1
    row('bd·cat·9', ok,
        f'the super-opposite product x*y = (-1)^(|x||y|) y x of the bit rule with squares eps is the bit rule with squares -eps, label by label '
        f'({cnt} sign vectors, n <= 6, null generators included): the mirror is the super-opposite on the nose, the dual object of the Morita '
        '2-category of superalgebras (inverse in the Brauer-Wall group for r = 0)')

def invariant(p, q):
    """signatures of the trace form t(x) = <x x>_0 on the four pieces (even/odd) x (reversion +1/-1); <e_a e_b>_0 = 0 for a != b"""
    e = sig(p, q); n = p + q; out = []
    for par in (0, 1):
        for rs in (1, -1):
            labs = [a for a in range(1 << n) if pc(a) % 2 == par and (-1) ** (pc(a) * (pc(a) - 1) // 2) == rs]
            d = [sgn(a, a, e) for a in labs]
            out.append((d.count(1), d.count(-1)))
    return tuple(out)

def omega_map(p, q):
    """f_i = e_i w in Cl(p,q), w the top blade; returns (images, squares, odd?, reversion sign on f_i) when w^2 = +1 and n even"""
    e = sig(p, q); n = p + q; w = {(1 << n) - 1: 1}
    imgs = [mul({1 << i: 1}, w, e) for i in range(n)]
    sq = [mul(f, f, e) for f in imgs]
    anti = all(mul(imgs[i], imgs[j], e) == {k: -v for k, v in mul(imgs[j], imgs[i], e).items()} for i in range(n) for j in range(i + 1, n))
    odd = all(pc(k) % 2 == 1 for f in imgs for k in f)
    rsgn = []
    for f in imgs:
        rf = rev(f)
        rsgn.append(1 if rf == f else (-1 if rf == {k: -v for k, v in f.items()} else 0))
    # the 2^n ordered products of the f_i span the algebra
    vecs = []
    for S in range(1 << n):
        x = {0: 1}
        for i in range(n):
            if S >> i & 1: x = mul(x, imgs[i], e)
        vecs.append([x.get(a, 0) for a in range(1 << n)])
    return imgs, sq, odd, anti, rsgn, rank_mod(vecs) == 1 << n

def check10():
    ok = True
    _, sq, odd, anti, rs, span = omega_map(4, 0)
    sq_ok = all(s == {0: -1} for s in sq)
    print(f'     Cl(4,0): f_i = e_i e_1234 are odd {odd}, anticommute {anti}, square to -1 {sq_ok}, span {span}: Cl(4,0) = Cl(0,4) as superalgebras; '
          f'the reversion of Cl(4,0) sends f_i to {rs[0]:+d} f_i (Clifford conjugation of Cl(0,4), not its reversion)')
    ok &= odd and anti and sq_ok and span and all(x == -1 for x in rs)
    I40, I04 = invariant(4, 0), invariant(0, 4)
    print(f'     invariant (even,+) (even,-) (odd,+) (odd,-) as (pos,neg): Cl(4,0) {I40}; Cl(0,4) {I04}')
    ok &= I40 != I04 and I40[2] == (4, 0) and I04[2] == (0, 4)
    _, sq, odd, anti, rs, span = omega_map(5, 1)
    sq_want = [{0: -x} for x in sig(5, 1)]
    print(f'     Cl(5,1): f_i = e_i e_123456 odd {odd}, anticommute {anti}, squares {[s[0] for s in sq]}, span {span}, reversion sign on f_i {rs}: '
          'Cl(5,1) = Cl(1,5) with their reversions')
    ok &= odd and anti and sq == sq_want and span and all(x == 1 for x in rs) and invariant(5, 1) == invariant(1, 5)
    # table: cells with the same (V, Q, pi) (same n, same p - q mod 8) split by the involutive invariant
    lines = []
    for n in range(1, 7):
        groups = {}
        for p in range(n + 1): groups.setdefault((p - (n - p)) % 8, []).append((p, n - p))
        for c, cells in sorted(groups.items()):
            if len(cells) < 2: continue
            byinv = {}
            for (p, q) in cells: byinv.setdefault(invariant(p, q), []).append(f'({p},{q})')
            lines.append(f'n={n} c={c}: ' + ' | '.join(' '.join(v) for v in byinv.values()))
    print('     same cell, split by the trace-form invariant of (algebra, grading, reversion):\n       ' + '\n       '.join(lines))
    row('bd·cat·10', ok,
        'Cl(4,0) = Cl(0,4) as superalgebras (same cell) but not with their reversions (odd reversion-fixed trace form (4,0) vs (0,4)); Cl(5,1) = Cl(1,5) '
        'with their reversions: the triple does not see the reversion, and the reversion does not recover (p,q) either')

def check11():
    ok = True; cnt = 0
    for n1 in range(1, 4):
        for n2 in range(1, 6 - n1):
            for r1 in range(n1 + 1):
                for p1 in range(n1 - r1 + 1):
                    for r2 in range(n2 + 1):
                        for p2 in range(n2 - r2 + 1):
                            q1, q2 = n1 - r1 - p1, n2 - r2 - p2
                            e = sig(p1, q1) + sig(p2, q2) + [0] * (r1 + r2)       # concatenation = graded product (cat·K5a, core·B7)
                            n = n1 + n2; N = 1 << n
                            T = [[sgn(a, b, e) if a == b else 0 for b in range(N)] for a in range(N)]   # trace form 2^-n Tr L_{e_a e_b}
                            rad = N - rank_mod(T)
                            if rad != N - 2 ** (p1 + q1 + p2 + q2): ok = False
                            if (rad > 0) != (r1 + r2 > 0): ok = False
                            cnt += 1
    row('bd·cat·11', ok,
        f'for {cnt} pairs of cells (n + n\' <= 5) the graded product has radical dimension 2^(n+n\') - 2^(p+q+p\'+q\') (trace-form kernel), non-zero iff '
        'r + r\' >= 1; a Morita-trivial superalgebra End(S) has radical 0, so no cell with r >= 1 has an inverse: super-Morita classes of the cells '
        'form the monoid Z_8 x N, (clock, r), not a group (QA1, QC1)')

if __name__ == '__main__':
    check9(); check10(); check11()
    verdict()
