#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""hh_graded.py: graded (super) Hochschild cohomology of the cells and of the degenerate cells over their super-centre (QA1, QC1).

Question: for r >= 1, is every graded algebra over the exterior algebra L_r = Lambda(R^r) (r odd generators) that is free as an L_r-module with
fibre Cl(p,q) the base change Cl(p,q) (x)^ L_r = Cl(p,q,r)?  Equivalently: do the Hochschild groups that govern the deformations of Cl(p,q)
over L_r vanish?

    python3 selfcheck/bridges/hh_graded.py              one line per check, ids bd·hh·1 .. bd·hh·6; exit 1 on any FAIL
    python3 selfcheck/bridges/hh_graded.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Exact arithmetic throughout (fractions.Fraction; all structure constants are 0, +1, -1); standard library only; deterministic, about 7 s;
runs from any folder, reads and writes no file.
  bd·hh·1  the super Hochschild complex of Cl(p,q) with coefficients in Cl(p,q,r) satisfies d o d = 0 on every basis cochain of degree 0 and 1,
           and HH^0 (the super-centraliser) has dimension 2^r ((p,q) in (1,0), (0,1), (1,1), (2,0); r = 0, 1, 2).
  bd·hh·2  every non-degenerate cell Cl(p,q) with 1 <= p + q <= 3 has HH^0 = (1, 0) and HH^1 = HH^2 = 0 in both parities: rigid as a superalgebra.
  bd·hh·3  the relative groups HH^n_{L_r}(A, A) = HH^n(Cl(p,q), Cl(p,q,r)) of A = Cl(p,q) (x)^ Lambda(R^r) are HH^0 = 2^r, HH^1 = HH^2 = 0 (r = 1 for
           the nine cells with p + q <= 3, r = 2 for the five with p + q <= 2): every free graded L_r-algebra with fibre Cl(p,q) is the base change.
  bd·hh·4  from first principles over L_1 = R[eps]: the associative L_1-deformations e_a * e_b = e_a e_b + eps mu1(a,b) of Cl(p,q) and those
           produced by phi = id + eps g span spaces of equal dimension (the nine cells with p + q <= 3).
  bd·hh·5  controls that are not zero: the null seed Cl(0,0,1) over R has HH^1 = HH^2 = (1, 1); the cochain f(theta, theta) = 1 (the deformation
           theta^2 = t towards Cl(1,0) and Cl(0,1)) is a cocycle and not a coboundary; the degenerate cells over R have HH^2 != 0.
  bd·hh·6  M_(1|1)(R) from matrix units: associative, HH^0 = (1, 0), HH^1 = HH^2 = 0; e -> E12 + E21, f -> E12 - E21 is a graded isomorphism
           Cl(1,1) -> M_(1|1)(R), and the dense engine gives the same groups for the bit-rule Cl(1,1).

Conventions.  A superalgebra A has a homogeneous basis with parities; the super Hochschild complex with coefficients in a super
bimodule M is C^n = Hom(A^{(x)n}, M) (all linear maps, both parities) with
  (df)(a1..a_{n+1}) = (-1)^{|a1||f|} a1 f(a2..a_{n+1}) + sum_{i=1..n} (-1)^i f(a1.., a_i a_{i+1}, ..) + (-1)^{n+1} f(a1..a_n) a_{n+1},
|f| the parity of f.  HH^0 is the super-centraliser {m : a m = (-1)^{|a||m|} m a}.  For the bit-rule algebras the complex splits into
blocks by the weight w = (output label) xor (input labels) in Z_2^N; the parity of a cochain is |w| mod 2, so every block has one parity
and HH^n_even, HH^n_odd are read off the blocks.

Relative groups.  For A = A0 (x)^ L_r (free over L_r, with L_r super-central), an L_r-multilinear cochain on A is determined by its
values on A0, so C^n_{L_r}(A, A) = Hom(A0^{(x)n}, A) with the A0-bimodule A = Cl(p,q,r) (restriction of the regular bimodule to the
subalgebra Cl(p,q) on the non-null bits), and the differentials agree.  So the relative groups are HH^n(Cl(p,q), Cl(p,q,r)), computed
here with the bit rule (null bits last).  The lifting statement for r = 1 is also computed from first principles (bd·hh·4).
"""
import sys
from fractions import Fraction
from itertools import product

SABOTAGE = '--sabotage' in sys.argv

# ------------------------------------------------------------------ the bit rule (as in core_check.py)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s

# ------------------------------------------------------------------ exact sparse rank over Q
def rank(vectors):
    """rank over Q of a list of sparse vectors {index: number}; pivot rows keep their smallest index as pivot"""
    piv = {}; rk = 0
    for v in vectors:
        v = {k: Fraction(x) for k, x in v.items() if x}
        while v:
            k = min(v)
            if k in piv:
                f = v[k]
                for kk, x in piv[k].items():
                    y = v.get(kk, 0) - f * x
                    if y: v[kk] = y
                    else: v.pop(kk, None)
            else:
                f = v[k]; piv[k] = {kk: x / f for kk, x in v.items()}; rk += 1
                break
    return rk

# ------------------------------------------------------------------ block engine: A0 = bit-rule algebra on m bits, M = bit-rule algebra on m+r bits containing A0
class BitBimodule:
    def __init__(self, epsA, epsM, koszul=True, broken_pair=None):
        self.m = len(epsA); self.N = len(epsM); self.epsA = epsA; self.epsM = epsM; self.koszul = koszul
        self.dA = 1 << self.m
        self.sA = [[sgn(a, b, epsA) for b in range(self.dA)] for a in range(self.dA)]
        self.sM = {}
        for x in range(1 << self.N):
            for a in range(self.dA):
                self.sM[(a, x)] = sgn(a, x, epsM); self.sM[(x, a)] = sgn(x, a, epsM)
        if broken_pair is not None:                       # sabotage: flip one left-action sign, M is then not a bimodule
            self.sM[broken_pair] = -self.sM[broken_pair]
    def column(self, n, w, t):
        """d_n applied to the basis cochain f: t -> e_c (c = w xor t1 xor ... xor tn), as a sparse vector on the basis tuples of C^{n+1}_w"""
        dA = self.dA; c = w
        for b in t: c ^= b
        pf = pc(w) % 2 if self.koszul else 0
        col = {}
        def add(tup, val):
            if val:
                key = tup
                col[key] = col.get(key, 0) + val
        for a1 in range(dA):                                                   # (-1)^{|a1||f|} a1 f(a2..)
            add((a1,) + t, (-1) ** ((pc(a1) % 2) * pf) * self.sM[(a1, c)])
        for i in range(1, n + 1):                                              # (-1)^i f(.., a_i a_{i+1}, ..)
            b = t[i - 1]
            for x in range(dA):
                add(t[:i - 1] + (x, x ^ b) + t[i:], (-1) ** i * self.sA[x][x ^ b])
        for y in range(dA):                                                    # (-1)^{n+1} f(a1..an) a_{n+1}
            add(t + (y,), (-1) ** (n + 1) * self.sM[(c, y)])
        return {k: v for k, v in col.items() if v}
    def hh(self, nmax=2):
        """dims of HH^n for n = 0..nmax, split by parity: {n: (even, odd)}, and the max |d d| entry found (n <= nmax - 1)"""
        res = {n: [0, 0] for n in range(nmax + 1)}; dd_bad = 0
        for w in range(1 << self.N):
            par = pc(w) % 2
            ranks = {-1: 0}
            for n in range(nmax + 1):
                cols = [self.column(n, w, t) for t in product(range(self.dA), repeat=n)]
                ranks[n] = rank(cols)
                dimC = self.dA ** n
                ker = dimC - ranks[n]
                res[n][par] += ker - ranks[n - 1]
                if n < nmax:                                                    # d_{n+1} o d_n = 0 on every basis cochain of the block
                    for col in cols:
                        tot = {}
                        for tup, v in col.items():
                            for k2, v2 in self.column(n + 1, w, tup).items():
                                tot[k2] = tot.get(k2, 0) + v * v2
                        if any(tot.values()): dd_bad += 1
        return {n: tuple(v) for n, v in res.items()}, dd_bad

# ------------------------------------------------------------------ dense engine: any superalgebra given by structure constants, regular bimodule
class Algebra:
    def __init__(self, parity, mul, koszul=True):
        self.d = len(parity); self.par = parity; self.mul = mul; self.koszul = koszul      # mul[(i,j)] = {k: coef}
    def is_associative(self):
        for i in range(self.d):
            for j in range(self.d):
                for k in range(self.d):
                    l = {}; r = {}
                    for x, cx in self.mul[(i, j)].items():
                        for y, cy in self.mul[(x, k)].items(): l[y] = l.get(y, 0) + cx * cy
                    for x, cx in self.mul[(j, k)].items():
                        for y, cy in self.mul[(i, x)].items(): r[y] = r.get(y, 0) + cx * cy
                    if {a: b for a, b in l.items() if b} != {a: b for a, b in r.items() if b}: return False
        return True
    def column(self, n, t, c):
        pf = (self.par[c] + sum(self.par[x] for x in t)) % 2 if self.koszul else 0
        col = {}
        def add(key, val):
            if val: col[key] = col.get(key, 0) + val
        for a1 in range(self.d):
            for k, v in self.mul[(a1, c)].items(): add(((a1,) + t, k), (-1) ** (self.par[a1] * pf) * v)
        for i in range(1, n + 1):
            b = t[i - 1]
            for x in range(self.d):
                for y in range(self.d):
                    v = self.mul[(x, y)].get(b, 0)
                    add((t[:i - 1] + (x, y) + t[i:], c), (-1) ** i * v)
        for y in range(self.d):
            for k, v in self.mul[(c, y)].items(): add((t + (y,), k), (-1) ** (n + 1) * v)
        return {k: v for k, v in col.items() if v}
    def hh(self, nmax=2):
        res = {}; prev = {0: 0, 1: 0}
        for n in range(nmax + 1):
            ranks = {}; dims = {}
            for par in (0, 1):
                cols = [self.column(n, t, c) for t in product(range(self.d), repeat=n) for c in range(self.d)
                        if (self.par[c] + sum(self.par[x] for x in t)) % 2 == par]
                ranks[par] = rank(cols); dims[par] = len(cols)
            res[n] = tuple(dims[p] - ranks[p] - prev[p] for p in (0, 1)); prev = ranks
        return res

def clifford_as_algebra(eps):
    n = len(eps); d = 1 << n
    return Algebra([pc(a) % 2 for a in range(d)], {(a, b): ({a ^ b: sgn(a, b, eps)} if sgn(a, b, eps) else {}) for a in range(d) for b in range(d)})

def m11(radical_square_zero=False):
    """M_{1|1}(R) by matrix units: E11 (0), E22 (1) even, E12 (2), E21 (3) odd; sabotage variant: E12 E21 = E21 E12 = 0"""
    idx = {(1, 1): 0, (2, 2): 1, (1, 2): 2, (2, 1): 3}; inv = {v: k for k, v in idx.items()}
    mul = {}
    for x in range(4):
        for y in range(4):
            (i, j), (k, l) = inv[x], inv[y]
            mul[(x, y)] = {idx[(i, l)]: 1} if j == k else {}
    if radical_square_zero:
        mul[(2, 3)] = {}; mul[(3, 2)] = {}
    return Algebra([0, 0, 1, 1], mul)

FIBRES = [(1, 0), (0, 1), (2, 0), (1, 1), (0, 2), (3, 0), (2, 1), (1, 2), (0, 3)]
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r

RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, ok))
    if not SABOTAGE: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    else: print('  sabotaged input, what the check sees: ' + text)
    return ok

# ================================================================== bd·hh·1: the complex is a complex, and the super-centraliser of Cl(p,q) in Cl(p,q,r) is L_r
def check1(sab=False):
    ok = True; bad = 0; hh0 = {}
    for (p, q) in [(1, 0), (0, 1), (1, 1), (2, 0)]:
        for r in (0, 1, 2):
            epsA = sig(p, q); epsM = sig(p, q, r)
            broken = (1, (1 << (p + q)) if r else 1) if sab else None          # flip the left action of e_1 on one basis element
            B = BitBimodule(epsA, epsM, broken_pair=broken)
            h, dd = B.hh(nmax=1)
            bad += dd; hh0[(p, q, r)] = sum(h[0])
            if dd or sum(h[0]) != 2 ** r: ok = False
    return report('bd·hh·1', ok, f'the super Hochschild complex (Koszul sign (-1)^(|a1||f|)) of Cl(p,q) with coefficients in Cl(p,q,r) satisfies d o d = 0 on every basis cochain of degree 0 and 1 ({bad} failures), for (p,q) in (1,0),(0,1),(1,1),(2,0) and r = 0, 1, 2; HH^0 = the super-centraliser has dimension 2^r: {hh0} (it is L_r = Lambda(R^r), the super-centre of the degenerate cell)')

# ================================================================== bd·hh·2: the fibres are rigid
def check2(sab=False):
    ok = True; table = {}
    fibres = FIBRES if not sab else [(1, 0), (0, 1)]
    for (p, q) in fibres:
        epsA = sig(p, q)
        if sab: epsA = epsA[:-1] + [0]                                        # sabotage: the last generator becomes null (a non-separable fibre)
        B = BitBimodule(epsA, epsA)
        h, dd = B.hh(nmax=2)
        table[f'{p},{q}'] = [h[0], h[1], h[2]]
        if dd or sum(h[0]) != 1 or h[1] != (0, 0) or h[2] != (0, 0): ok = False
    return report('bd·hh·2', ok, f'graded Hochschild groups (even, odd) of every cell Cl(p,q) with 1 <= p+q <= 3, coefficients in itself, exact over Q: HH^0 = (1,0), HH^1 = HH^2 = (0,0) for all nine cells {table}: every non-degenerate cell up to n = 3 (including Cl(1,1) = M_(1|1)(R)) is rigid as a superalgebra and has no outer super-derivations')

# ================================================================== bd·hh·3: the relative groups over L_r vanish
def check3(sab=False):
    ok = True; table = {}
    cases = [((p, q), 1) for (p, q) in FIBRES] + [((p, q), 2) for (p, q) in FIBRES if p + q <= 2]
    if sab: cases = [((1, 0), 1), ((0, 1), 1)]
    for (p, q), r in cases:
        epsA = sig(p, q); epsM = sig(p, q, r)
        if sab:                                                               # sabotage: the fibre's last generator is null (non-separable fibre)
            epsA = epsA[:-1] + [0]; epsM = epsA + [0] * r
        B = BitBimodule(epsA, epsM)
        h, dd = B.hh(nmax=2)
        table[f'{p},{q};r={r}'] = [sum(h[0]), h[1], h[2]]
        if dd or sum(h[0]) != 2 ** r or h[1] != (0, 0) or h[2] != (0, 0): ok = False
    return report('bd·hh·3', ok, f'relative groups HH^n_(L_r)(A, A) = HH^n(Cl(p,q), Cl(p,q,r)) for A = Cl(p,q) (x)^ Lambda(R^r): r = 1 for all nine cells with p+q <= 3 and r = 2 for the five with p+q <= 2: HH^0 = 2^r (the base L_r), HH^1 = HH^2 = 0 in both parities {table}; the lifts of Cl(p,q) along each step L_r/m^(k+1) -> L_r/m^k (m the nilpotent ideal) differ by classes in the summand HH^2(Cl(p,q), Cl(p,q) (x) m^k/m^(k+1)) of these groups, so every free graded L_r-algebra with fibre Cl(p,q) is the base change Cl(p,q,r)')

# ================================================================== bd·hh·4: first principles for r = 1: every associative L_1-deformation of Cl(p,q) is a base change
def deformations_r1(eps, sign_rule=True):
    """B = A0 + eps A0 with eps odd, super-central, eps^2 = 0.  Product: e_a * e_b = s(a,b) e_{a^b} + eps mu1(a,b), mu1 odd and unknown,
    extended L_1-bilinearly: (eps^k e_a) * (eps^l e_b) = (-1)^(l|a|) eps^(k+l) (e_a * e_b).  Returns dim Z (associative mu1) and
    dim Bg (mu1 produced from mu1 = 0 by phi = id + eps g, g odd)."""
    m = len(eps); d = 1 << m
    var = {}
    for a in range(d):
        for b in range(d):
            for c in range(d):
                if (pc(a) + pc(b) + pc(c)) % 2 == 1: var[(a, b, c)] = len(var)
    # an element of B: dict (label, k) -> linear form {var index or None: coef}
    def lf_add(x, y, s=1):
        out = dict(x)
        for k, v in y.items():
            out[k] = out.get(k, 0) + s * v
            if not out[k]: del out[k]
        return out
    def lf_mul(x, y):
        nx = any(k is not None for k in x); ny = any(k is not None for k in y)
        assert not (nx and ny)
        out = {}
        for kx, vx in x.items():
            for ky, vy in y.items():
                key = kx if kx is not None else ky
                out[key] = out.get(key, 0) + vx * vy
        return {k: v for k, v in out.items() if v}
    def basic(a, b, mu1=None):
        """e_a * e_b as an element of B (with unknown mu1 if mu1 is None, else with the given mu1 dict (a,b)->{c: coef})"""
        el = {}
        s = sgn(a, b, eps)
        if s: el[(a ^ b, 0)] = {None: s}
        for c in range(d):
            if mu1 is None:
                if (a, b, c) in var: el[(c, 1)] = {var[(a, b, c)]: 1}
            else:
                v = mu1.get((a, b), {}).get(c, 0)
                if v: el[(c, 1)] = {None: v}
        return el
    def mult(X, Y, mu1=None):
        out = {}
        for (a, k), cx in X.items():
            for (b, l), cy in Y.items():
                if k + l >= 2: continue
                sign = (-1) ** (l * (pc(a) % 2)) if sign_rule else 1
                coef = lf_mul(cx, cy)
                for (c, j), cz in basic(a, b, mu1).items():
                    if j + k + l >= 2: continue
                    key = (c, j + k + l)
                    out[key] = lf_add(out.get(key, {}), lf_mul(coef, cz), sign)
                    if not out[key]: del out[key]
        return out
    eqs = []
    for a in range(d):
        for b in range(d):
            for c in range(d):
                ea, eb, ec = {(a, 0): {None: 1}}, {(b, 0): {None: 1}}, {(c, 0): {None: 1}}
                L = mult(mult(ea, eb), ec); R = mult(ea, mult(eb, ec))
                for key in set(L) | set(R):
                    diff = lf_add(L.get(key, {}), R.get(key, {}), -1)
                    if None in diff and diff[None]: return None                 # the undeformed product would not be associative
                    diff = {k: v for k, v in diff.items() if k is not None and v}
                    if diff: eqs.append(diff)
    dimZ = len(var) - rank(eqs)
    # gauge: phi(e_a) = e_a + eps g(e_a), g odd; mu1^g = eps-part of phi^-1(phi(e_a) * phi(e_b)) with mu1 = 0
    gens = []
    for a in range(d):
        for c in range(d):
            if (pc(a) + pc(c)) % 2 == 1: gens.append((a, c))                    # g: e_a -> e_c, odd
    Bvecs = []
    for (ga, gc) in gens:
        def phi(x):
            out = {}
            for (lab, k), cf in x.items():
                out[(lab, k)] = lf_add(out.get((lab, k), {}), cf)
                if k == 0 and lab == ga:
                    out[(gc, 1)] = lf_add(out.get((gc, 1), {}), cf)
            return {k: v for k, v in out.items() if v}
        def phi_inv(x):
            out = {}
            for (lab, k), cf in x.items():
                out[(lab, k)] = lf_add(out.get((lab, k), {}), cf)
                if k == 0 and lab == ga:
                    out[(gc, 1)] = lf_add(out.get((gc, 1), {}), cf, -1)
            return {k: v for k, v in out.items() if v}
        vec = {}
        zero_mu = {}
        for a in range(d):
            for b in range(d):
                prod_ = phi_inv(mult(phi({(a, 0): {None: 1}}), phi({(b, 0): {None: 1}}), zero_mu))
                for (c, j), cf in prod_.items():
                    if j == 1 and cf.get(None):
                        vec[var[(a, b, c)]] = cf[None]
        Bvecs.append(vec)
    dimB = rank(Bvecs)
    # every gauge-produced mu1 is associative (B inside Z): rank(eqs) annihilates them
    inside = all(sum(e.get(k, 0) * v for k, v in vec.items()) == 0 for vec in Bvecs for e in eqs)
    return dimZ, dimB, len(var), inside

def check4(sab=False):
    ok = True; table = {}
    fibres = FIBRES if not sab else [(1, 0)]
    for (p, q) in fibres:
        eps = sig(p, q)
        if sab: eps = [0]                                                     # sabotage: the fibre is the null seed Lambda_1 = Cl(0,0,1)
        res = deformations_r1(eps)
        if res is None: ok = False; continue
        dimZ, dimB, nvar, inside = res
        table[f'{p},{q}' if not sab else '0,0,1'] = (dimZ, dimB)
        if not inside or dimZ != dimB: ok = False
    return report('bd·hh·4', ok, f'from first principles over L_1 = R[eps] (eps odd, super-central, eps^2 = 0): the L_1-bilinear products e_a * e_b = e_a e_b + eps mu1(a,b) on Cl(p,q) (x)^ L_1 that are associative form a space Z, those obtained from the base change by phi = id + eps g form B; (dim Z, dim B) = {table} for the nine cells with p+q <= 3: Z = B, so every associative L_1-deformation of Cl(p,q) is isomorphic to the base change Cl(p,q,1)')

# ================================================================== bd·hh·5: controls that are not zero (the machinery sees non-rigidity)
def check5(sab=False):
    ok = True
    koszul = not sab                                                          # sabotage: drop the Koszul signs (ungraded complex)
    # (a) the null seed Lambda_1 = Cl(0,0,1) over R, coefficients in itself
    B = BitBimodule([0], [0], koszul=koszul)
    h, dd = B.hh(nmax=2)
    # (b) the even 2-cochain f(theta, theta) = 1 (the infinitesimal deformation theta^2 = t, towards Cl(1,0) for t > 0, Cl(0,1) for t < 0)
    w = 0
    col_f = B.column(2, w, (1, 1))                                            # d f: zero iff f is a cocycle
    im_d1 = [B.column(1, w, (t,)) for t in range(2)]
    def tup_index(tp): return tp
    f_vec = {(1, 1): 1}
    nontrivial = (not col_f) and rank(im_d1 + [f_vec]) > rank(im_d1)
    # (c) degenerate cells over R (absolute groups): HH^2 of Cl(1,0,1), Cl(0,1,1), Cl(0,0,2), Cl(1,1,1)
    absolute = {}
    for (p, q, r) in [(1, 0, 1), (0, 1, 1), (0, 0, 2), (1, 1, 1)]:
        Bd = BitBimodule(sig(p, q, r), sig(p, q, r), koszul=koszul)
        hd, ddd = Bd.hh(nmax=2)
        absolute[f'{p},{q},{r}'] = hd[2]; dd += ddd
        if sum(hd[2]) == 0: ok = False
    if dd or h[1] != (1, 1) or sum(h[2]) == 0 or not nontrivial: ok = False
    return report('bd·hh·5', ok, f'controls that are not zero: the null seed Lambda_1 = Cl(0,0,1) over R has HH^1 = {h[1]} (even: the Euler derivation theta -> theta; odd: theta -> 1) and HH^2 = {h[2]} (even, odd); the even cochain f(theta,theta) = 1, the first-order deformation theta^2 = t that leads to Cl(1,0) (t > 0) and Cl(0,1) (t < 0), is a cocycle and not a coboundary: {nontrivial}; the degenerate cells over R have HH^2 = (even, odd) {absolute}, never 0: over R the null square is a deformation direction')

# ================================================================== bd·hh·6: M_{1|1}(R) by matrix units, and its graded isomorphism with Cl(1,1)
def check6(sab=False):
    ok = True
    M = m11(radical_square_zero=sab)                                           # sabotage: kill E12 E21 and E21 E12 (radical square zero)
    assoc = M.is_associative()
    h = M.hh(nmax=2)
    # explicit graded isomorphism Cl(1,1) -> M_{1|1}(R): e (square +1) -> E12 + E21, f (square -1) -> E12 - E21, both odd
    def mat_mul(X, Y):
        out = {}
        for x, cx in X.items():
            for y, cy in Y.items():
                for z, cz in M.mul[(x, y)].items(): out[z] = out.get(z, 0) + cx * cy * cz
        return {k: v for k, v in out.items() if v}
    E = {2: 1, 3: 1}; F = {2: 1, 3: -1}; ONE = {0: 1, 1: 1}
    images = {0: ONE, 1: E, 2: F, 3: mat_mul(E, F)}
    eps = [1, -1]; iso = True
    for a in range(4):
        for b in range(4):
            s = sgn(a, b, eps)
            lhs = mat_mul(images[a], images[b]); rhs = {k: s * v for k, v in images[a ^ b].items()} if s else {}
            if lhs != rhs: iso = False
    span = rank(list(images.values())) == 4
    h_cl = clifford_as_algebra([1, -1]).hh(nmax=2)                            # cross-check of the two engines on Cl(1,1)
    if not (assoc and iso and span and sum(h[0]) == 1 and h[1] == (0, 0) and h[2] == (0, 0) and h_cl == h): ok = False
    return report('bd·hh·6', ok, f'M_(1|1)(R) built from matrix units (E11, E22 even, E12, E21 odd): associative, HH^0 = {h[0]}, HH^1 = {h[1]}, HH^2 = {h[2]} (even, odd); e -> E12 + E21, f -> E12 - E21 is a graded algebra isomorphism Cl(1,1) -> M_(1|1)(R), and the dense engine gives the same groups for the bit-rule Cl(1,1): {h_cl == h}')

CHECKS = [('bd·hh·1', check1), ('bd·hh·2', check2), ('bd·hh·3', check3), ('bd·hh·4', check4), ('bd·hh·5', check5), ('bd·hh·6', check6)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            RESULTS.clear()
            ok = f(sab=True)
            print(('CAUGHT ' if not ok else 'MISSED ') + cid)
            if ok: missed += 1
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS: f()
    nfail = sum(1 for _, ok in RESULTS if not ok)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if nfail else 0)
