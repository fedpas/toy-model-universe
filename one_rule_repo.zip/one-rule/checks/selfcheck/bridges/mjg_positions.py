#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjg_positions.py: the O-space of arXiv:2403.19689 (v3) (eq. (4)) on the label category B_n: position maps P : labels -> R^2, planar vectors
D(f) = P(cod f) - P(dom f), the weight ||f|| = |T \\ S| of the arrow S -> T, and the readings in which the paper's (8), (9) and the printed
component rule hold.

    python3 selfcheck/bridges/mjg_positions.py              one line per check, ids bd·mjg·1 .. bd·mjg·7 and bd·mjg·33 (info bd·mjg·8); exit 1 on any FAIL
    python3 selfcheck/bridges/mjg_positions.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Standard library plus numpy (floats for planar geometry with tolerances 1e-9 and printed margins; exact Fractions where a statement is exact),
deterministic (seeded generators), about 1 s; runs from any folder, reads and writes no file.

Conventions. Labels a in [0, 2^n) are bit sets; an arrow S -> T exists iff S is a subset of T; its weight is |T \\ S| (popcount); a composable
non-identity pair is S < T < U (strict). The cube view with columns m_i in R^2 is P(a) = sum_{i in a} m_i. The Petrie view (the 'Cube view' of
the Atlas's shapes page, ShapesSection.jsx, Zonogon) has m_i = (cos(pi i/n), sin(pi i/n)); the isometric view has angles 2 pi i/n; Gaussian views
have seeded normal columns; random P puts each label at a seeded random point.

 bd·mjg·1  injectivity of the O-space map (4) for the cube views: the Petrie view is injective on the 2^n labels exactly for n in {1, 2, 4, 8}
           (n <= 8); for odd n its only coincidence is P(even positions) = P(odd positions); for every n with an odd prime factor p the
           relation sum_j (-1)^j m_{j n/p} = 0 holds (residual < 1e-12); the isometric view is injective only for n = 1; 200 seeded
           Gaussian views (n <= 6) are all injective. (For all n, an argument that is not computed here: the powers of a primitive 2n-th root
           of unity below phi(2n) are linearly independent over Q, so the view is injective iff n is a power of 2.)
           Sabotage: the isometric angles in place of the Petrie angles.
 bd·mjg·2  weight against planar length: for unit columns (Petrie views n <= 6 and 100 seeded unit-column views per n <= 5) ||f|| >= |D(f)|
           on all 3^n - 2^n non-identity arrows, with equality exactly on the n 2^(n-1) cover edges (weight 1); scaling P by 0.9 makes the
           inequality strict on every arrow (needed for a path of length ||f|| off the plane Z0); random P violate ||f|| >= |D(f)| on k of N
           arrows (control). Sabotage: weight sqrt(|T \\ S|) (the Euclidean length in R^n) in place of |T \\ S|.
 bd·mjg·3  on the 4^n - 2.3^n + 2^n composable non-identity pairs the weight is additive on all of them; the Euclidean length is additive
           exactly on the positively collinear pairs, and their number is printed per view (a small fraction, zero for many views).
           Sabotage: the l1 length of the n-dimensional cube vector (additive everywhere) in place of the planar Euclidean length.
 bd·mjg·4  the printed component rule f (+) g = (a1 + b1) e1 + (a2 + b2) e2 of (8) (f = a1 e1 + b1 e2, g = a2 e1 + b2 e2) gives the vector
           P(U) - P(S) of the composite on few composable pairs (counted per view: Petrie and random P, n = 2..5); it is symmetric in (f, g)
           only when a1 + b1 = a2 + b2 and associative on few composable triples (in the Petrie square n = 2 both pairs have b1 = a2 = 0 and
           agree).  Two remarks of the line hold by algebra and are not part of the check: the agreement happens exactly when b1 = a2, and
           the vector sum (a1 + a2) e1 + (b1 + b2) e2 gives P(U) - P(S) on every pair, for every P.
           Sabotage: the vector sum fed in as the printed rule.
 bd·mjg·5  (reading R1: weight = Euclidean length) in B_2 with the popcount weight, P(0) = (0,0), P(11) = (2,0): the circles |x| = 1 and
           |x - (2,0)| = 1 meet in the single point (1,0) (exact), so (9) with ||f|| = |D(f)| forces P({0}) = P({1}): no injective P for any
           n >= 2. A line drawing P(a) = h(a) u with a strictly increasing injective height h satisfies ||f|| = h(T) - h(S) = |D(f)| and (9)
           on every arrow and pair (B_3, 50 seeded heights) and is injective; random P with ||f|| := |D(f)| violate (9) on k of N pairs.
           Sabotage: the diagonal weight 1.9 in place of 2 (then the circles meet in two points).
 bd·mjg·6  (reading R3: a planar norm) there is a linear phi on R^2 with phi(m_i) = 1 for all i (equivalently a norm N on R^2 with N(D(f)) =
           ||f|| and (9) on B_n, by the equality case of the triangle inequality) for the Petrie view at n = 2 and for the time view
           m_i = (1, 2^i / 2^n), and not for the Petrie views n = 3..6 (least-squares residual printed); for the time view the norm
           N(x, y) = max(|x|, c|y|) reproduces every weight and the equality (9) on every composable pair, satisfies the triangle inequality
           on 2000 seeded pairs, and the time view is injective (n <= 6). Sabotage: the Petrie view n = 4 in place of the time view.
 bd·mjg·7  positions compatible with the partial sum: P(a (+) b) = P(a) + P(b) - P(0) on every disjoint pair holds for every cube view and
           fails for random P; for a cube view D(S -> T) = D(0 -> T \\ S), so the 3^n - 2^n non-identity arrows carry 2^n - 1 distinct planar
           vectors (injective views), against 3^n - 2^n for random P. Sabotage: one label of a cube view moved by (0.1, 0).
 bd·mjg·8  (info, a read-off, not a check; bd·mjc·2 computes the axiom on the labels) the printed axiom '||v|| >= 1' of §3 holds for the
           popcount weight on all 3^n - 2^n arrow vectors of B_n (n <= 6: the popcount of a nonempty difference), fails for the zero vector
           (||0|| = 0) and for alpha f with 0 < alpha < 1/||f|| (the positive scalars of Def. 2 (4)); the planar lengths |D(f)| of the Petrie
           view are below 1 on k arrows.
 bd·mjg·33  the canonical flat drawing: the graph Laplacian nI - A of the Hasse diagram of B_n (the n-cube graph) has smallest nonzero
            eigenvalue 2 with multiplicity n, and its eigenspace is spanned by the centred coordinates x_i - 1/2 (n <= 6); so every spectral
            drawing of the labels from that eigenspace is a cube view (additive on the partial sum: P(a (+) b) = P(a) + P(b) - P(0)); control:
            the same drawing read through 200 seeded random relabellings of the vertices is additive only for the relabellings that are cube
            automorphisms (k of 200). Sabotage: the eigenvectors of eigenvalue 4 in place of 2.
"""
import sys, math, itertools, random
from fractions import Fraction as Fr
import numpy as np

SAB = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if SAB: print('  sabotaged input, what the check sees: ' + text)
    else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def arrows(n):            # (S, T) with S subset of T, S != T
    return [(S, T) for T in range(1 << n) for S in range(1 << n) if S & ~T == 0 and S != T]
def pairs(n):             # S < T < U strict
    out = []
    for U in range(1 << n):
        for T in range(1 << n):
            if T & ~U or T == U: continue
            for S in range(1 << n):
                if S & ~T == 0 and S != T: out.append((S, T, U))
    return out
def triples(n):
    out = []
    for (S, T, U) in pairs(n):
        for V in range(1 << n):
            if U & ~V == 0 and U != V: out.append((S, T, U, V))
    return out
def cols_petrie(n): return np.array([[math.cos(math.pi * i / n), math.sin(math.pi * i / n)] for i in range(n)])
def cols_iso(n): return np.array([[math.cos(2 * math.pi * i / n), math.sin(2 * math.pi * i / n)] for i in range(n)])
def view(cols, n):
    return np.array([cols[[i for i in range(n) if a >> i & 1]].sum(axis=0) if a else np.zeros(2) for a in range(1 << n)])
def coincidences(P, tol=1e-9):
    N = len(P); d = np.sqrt(((P[:, None, :] - P[None, :, :]) ** 2).sum(-1)); iu = np.triu_indices(N, 1)
    dd = d[iu]; co = [(int(iu[0][k]), int(iu[1][k])) for k in np.where(dd < tol)[0]]
    pos = dd[dd >= tol]
    return co, (float(pos.min()) if len(pos) else float('inf'))
def odd_prime_factor(n):
    m = n
    while m % 2 == 0: m //= 2
    if m == 1: return None
    p = 3
    while m % p: p += 2
    return p

# ------------------------------------------------------------------------------------------------------------------------------------
def check1(sab):
    inj = []; info = []; good = True; margin = float('inf')
    for n in range(1, 9):
        cols = cols_iso(n) if sab else cols_petrie(n)
        P = view(cols, n); co, mind = coincidences(P)
        if not co: inj.append(n); margin = min(margin, mind)
        if n % 2 == 1 and n > 1 and not sab:
            ev = sum(1 << i for i in range(0, n, 2)); od = sum(1 << i for i in range(1, n, 2))
            good &= co == [(min(ev, od), max(ev, od))]
        p = odd_prime_factor(n)
        if p and not sab:
            rel = sum(((-1) ** j) * cols[j * n // p] for j in range(p)); good &= float(np.abs(rel).max()) < 1e-12
        info.append(f'n={n}: {len(co)} coincident pairs')
    iso_inj = [n for n in range(1, 9) if not coincidences(view(cols_iso(n), n))[0]]
    rng = np.random.default_rng(1); gauss_ok = True; gmin = float('inf')
    for n in range(1, 7):
        for _ in range(200 if n <= 4 else 40):
            co, mind = coincidences(view(rng.normal(size=(n, 2)), n)); gauss_ok &= not co; gmin = min(gmin, mind)
    ok = inj == [1, 2, 4, 8] and good and iso_inj == [1] and gauss_ok
    return report('bd·mjg·1', ok, f'the cube view P(a) = sum_(i in a) (cos(pi i/n), sin(pi i/n)) (the Atlas\'s Cube view) is injective on the labels exactly '
                  f'for n in {inj} (n <= 8; smallest distance between distinct images {margin:.4f}); odd n: the one coincidence is P(even positions) = '
                  f'P(odd positions); the relation sum_j (-1)^j m_(j n/p) = 0 for an odd prime p | n holds: {good}; isometric view injective only for '
                  f'n in {iso_inj}; seeded Gaussian views (n <= 6) all injective: {gauss_ok} (smallest distance {gmin:.2e}). ' + '; '.join(info))

def check2(sab):
    ok = True; info = []
    rng = np.random.default_rng(2)
    for n in range(1, 7):
        views = [cols_petrie(n)]
        if n <= 5:
            for _ in range(100):
                c = rng.normal(size=(n, 2)); views.append(c / np.linalg.norm(c, axis=1)[:, None])
        A = arrows(n)
        for c in views:
            P = view(c, n)
            w = np.array([math.sqrt(pc(T & ~S)) if sab else pc(T & ~S) for S, T in A])
            d = np.array([np.linalg.norm(P[T] - P[S]) for S, T in A])
            eq = set(k for k in range(len(A)) if abs(w[k] - d[k]) < 1e-9)
            edges = set(k for k, (S, T) in enumerate(A) if pc(T & ~S) == 1)
            ok &= bool((w >= d - 1e-9).all()) and eq == edges
            d9 = 0.9 * d; ok &= bool((w > d9 + 1e-9).all())
        info.append(f'n={n}: ratio ||f||/|D| in [{min(w / np.maximum(d, 1e-300)):.3f}, {max(w / np.maximum(d, 1e-300)):.3f}] (Petrie), equality on {len(edges)} edges')
    # control: random positions
    viol = []; rs = random.Random(3)
    for n in (3, 4):
        A = arrows(n); bad = 0; tot = 0
        for _ in range(50):
            P = np.array([[rs.uniform(-n, n), rs.uniform(-n, n)] for _ in range(1 << n)])
            bad += sum(1 for S, T in A if pc(T & ~S) < np.linalg.norm(P[T] - P[S]) - 1e-9); tot += len(A)
        viol.append(f'n={n}: {bad} of {tot}')
    ok &= all(int(v.split(': ')[1].split(' of ')[0]) > 0 for v in viol)
    return report('bd·mjg·2', ok, 'unit-column cube views (Petrie n <= 6, 100 seeded per n <= 5): ||f|| >= |D(f)| on every non-identity arrow with equality exactly '
                  'on the cover edges; scaled by 0.9 the inequality is strict on every arrow; ' + '; '.join(info) +
                  '; control, random P in [-n, n]^2 (50 per n, seed 3): ||f|| < |D(f)| on ' + ', '.join(viol) + ' arrows')

def check3(sab):
    ok = True; info = []
    rng = np.random.default_rng(4)
    for n in range(2, 7):
        Pp = pairs(n); N = len(Pp); ok &= N == 4 ** n - 2 * 3 ** n + 2 ** n
        views = [('Petrie', view(cols_petrie(n), n)), ('Gauss', view(rng.normal(size=(n, 2)), n)), ('randomP', rng.normal(size=(1 << n, 2)))]
        for name, P in views:
            add = col = 0; mismatch = 0
            for S, T, U in Pp:
                a, b = P[T] - P[S], P[U] - P[T]
                if sab:
                    la, lb, lab = pc(T & ~S), pc(U & ~T), pc(U & ~S)
                else:
                    la, lb, lab = np.linalg.norm(a), np.linalg.norm(b), np.linalg.norm(a + b)
                e = abs(lab - la - lb) < 1e-9
                c = abs(a[0] * b[1] - a[1] * b[0]) < 1e-9 and a @ b > 0
                add += e; col += c; mismatch += e != c
            ok &= mismatch == 0 and add < N
            if name == 'Petrie': info.append(f'n={n}: {add} of {N}')
    return report('bd·mjg·3', ok, 'the weight is additive on every composable non-identity pair; the planar Euclidean length is additive exactly on the positively '
                  'collinear pairs (Petrie, Gaussian view and random P, n = 2..6); Petrie view, Euclidean-additive pairs: ' + ', '.join(info))

def check4(sab):
    ok = True; info = []; tot_agree = tot_N = 0
    rng = np.random.default_rng(5)
    for n in range(2, 6):
        for name, P in (('Petrie', view(cols_petrie(n), n)), ('randomP', rng.normal(size=(1 << n, 2)))):
            Pp = pairs(n); N = len(Pp)
            def printed(f, g):
                return np.array([f[0] + g[0], f[1] + g[1]]) if sab else np.array([f[0] + f[1], g[0] + g[1]])
            agree = cond = sym = 0
            for S, T, U in Pp:
                f, g = P[T] - P[S], P[U] - P[T]
                a = np.allclose(printed(f, g), P[U] - P[S], atol=1e-9); agree += a
                cond += abs(f[1] - g[0]) < 1e-9                         # agreement iff b1 = a2: an identity of the two formulas (a remark)
                sym += np.allclose(printed(f, g), printed(g, f), atol=1e-9)
            Tt = triples(n); assoc = 0
            for S, T, U, V in Tt:
                f, g, h = P[T] - P[S], P[U] - P[T], P[V] - P[U]
                assoc += np.allclose(printed(printed(f, g), h), printed(f, printed(g, h)), atol=1e-9)
            tot_agree += agree; tot_N += N
            info.append(f'n={n} {name}: printed = P(U)-P(S) on {agree} of {N} pairs (b1 = a2 on {cond}), symmetric on {sym}, associative on {assoc} of {len(Tt)} triples')
    ok &= tot_agree < tot_N
    return report('bd·mjg·4', ok, f'printed rule (a1 + b1) e1 + (a2 + b2) e2 against the composite\'s vector P(U) - P(S): agreement on {tot_agree} of {tot_N} '
                  'pairs in all (exactly when b1 = a2, and the vector sum agrees on every pair for every P: two remarks that hold by algebra); ' + '; '.join(info))

def check5(sab):
    # exact: P(empty) = (0,0), P(11) = (2,0); |x|^2 = 1 and |x - (2,0)|^2 = W^2 with W = w(0 -> 01) (1; sabotage: diagonal 1.9 -> rescale)
    diag = Fr(19, 10) if sab else Fr(2)
    # circles |x| = 1, |x - (diag,0)| = 1  ->  x = diag/2, y^2 = 1 - diag^2/4
    x = diag / 2; y2 = 1 - diag * diag / 4
    single = y2 == 0
    pts = 1 if y2 == 0 else (2 if y2 > 0 else 0)
    # positive control: line drawings with injective strictly increasing heights on B_3
    rs = random.Random(6); lines_ok = True
    n = 3; A = arrows(n); Pp = pairs(n)
    for _ in range(50):
        while True:
            h = {0: 0}
            for a in sorted(range(1, 1 << n), key=pc):
                h[a] = max(h[b] for b in range(1 << n) if b & ~a == 0 and b != a) + rs.randint(1, 4) + rs.random()
            if len(set(h.values())) == 1 << n: break
        u = np.array([math.cos(1.0), math.sin(1.0)]); P = np.array([h[a] * u for a in range(1 << n)])
        lines_ok &= all(abs((h[T] - h[S]) - np.linalg.norm(P[T] - P[S])) < 1e-9 for S, T in A)
        lines_ok &= all(abs(np.linalg.norm(P[U] - P[S]) - np.linalg.norm(P[T] - P[S]) - np.linalg.norm(P[U] - P[T])) < 1e-9 for S, T, U in Pp)
        lines_ok &= not coincidences(P)[0]
    # control: random P with w := |D|
    rng = np.random.default_rng(7); bad = tot = 0
    for _ in range(50):
        P = rng.normal(size=(8, 2))
        for S, T, U in Pp:
            tot += 1; bad += abs(np.linalg.norm(P[U] - P[S]) - np.linalg.norm(P[T] - P[S]) - np.linalg.norm(P[U] - P[T])) > 1e-9
    ok = single and x == 1 and lines_ok and bad > 0
    return report('bd·mjg·5', ok, f'B_2, popcount weights, ||f|| = |D(f)| and (9): the circles |x| = 1, |x - ({diag},0)| = 1 meet in {pts} point(s) '
                  f'(x = {x}, y^2 = {y2}), so P({{0}}) = P({{1}}) = (1, 0): no injective P for n >= 2; line drawings P = h u (B_3, 50 seeded injective heights) satisfy '
                  f'||f|| = |D(f)| and (9) everywhere and are injective: {lines_ok}; random P with ||f|| := |D(f)| (B_3, seed 7): (9) fails on {bad} of {tot} pairs')

def check6(sab):
    ok = True; info = []
    for n in range(2, 7):
        c = cols_petrie(n); phi, res, rk, _ = np.linalg.lstsq(c, np.ones(n), rcond=None)
        r = float(np.linalg.norm(c @ phi - 1))
        info.append(f'Petrie n={n}: residual {r:.3f}')
        ok &= (r < 1e-12) if n == 2 else (r > 0.05)
    rs = random.Random(8)
    for n in range(1, 7):
        c = cols_petrie(4) if (sab and n == 4) else np.array([[1.0, 2 ** i / 2 ** n] for i in range(n)])
        nn = len(c)
        P = view(c, nn)
        cmax = max(1.0, float(np.abs(P[:, 1]).max())); cc = 1.0 / (2 * cmax)
        N = lambda v: max(abs(v[0]), cc * abs(v[1]))
        ok &= all(abs(N(P[T] - P[S]) - pc(T & ~S)) < 1e-9 for S, T in arrows(nn))
        ok &= all(abs(N(P[U] - P[S]) - N(P[T] - P[S]) - N(P[U] - P[T])) < 1e-9 for S, T, U in pairs(nn))
        tri = all(N(np.array([x1 + x2, y1 + y2])) <= N(np.array([x1, y1])) + N(np.array([x2, y2])) + 1e-12
                  for x1, y1, x2, y2 in ([rs.uniform(-3, 3) for _ in range(4)] for _ in range(2000)))
        ok &= tri and not coincidences(P)[0]
    return report('bd·mjg·6', ok, 'a linear phi with phi(m_i) = 1 for every column exists for Petrie n = 2 and for the time view m_i = (1, 2^i/2^n), not for '
                  'Petrie n = 3..6 (' + ', '.join(info) + '); for the time view N(x, y) = max(|x|, c|y|) gives N(D(f)) = ||f|| on every arrow and (9) on '
                  'every composable pair, satisfies the triangle inequality on 2000 seeded pairs, and the time view is injective (n = 1..6)')

def check7(sab):
    ok = True; info = []
    rng = np.random.default_rng(9)
    for n in range(1, 7):
        for name, P in (('Petrie', view(cols_petrie(n), n)), ('Gauss', view(rng.normal(size=(n, 2)), n)), ('randomP', rng.normal(size=(1 << n, 2)))):
            P = P.copy()
            if sab and name != 'randomP' and n >= 2: P[3] = P[3] + np.array([0.1, 0.0])
            hom = all(np.allclose(P[a | b], P[a] + P[b] - P[0], atol=1e-9) for a in range(1 << n) for b in range(1 << n) if a & b == 0)
            vecs = [P[T] - P[S] for S, T in arrows(n)]
            distinct = len(np.unique(np.round(np.array(vecs), 7), axis=0)) if vecs else 0
            if name == 'randomP':
                ok &= (not hom or n == 1) and distinct == 3 ** n - 2 ** n
            else:
                ok &= hom and (name == 'Petrie' and n not in (1, 2, 4) or distinct == 2 ** n - 1)
            if name != 'randomP': info.append(f'n={n} {name}: {distinct}')
            else: info.append(f'n={n} random: {distinct}')
    return report('bd·mjg·7', ok, 'P(a (+) b) = P(a) + P(b) - P(0) on every disjoint pair for the cube views and not for random P; distinct nonzero planar vectors of the '
                  '3^n - 2^n arrows: ' + ', '.join(info) + ' (cube views: 2^n - 1 when injective; random P: 3^n - 2^n)')

def info8():
    """a read-off: the popcount of a nonempty difference is >= 1, the zero vector and the scalar 1/2 are constants"""
    info = []; wmin = None
    for n in range(1, 7):
        A = arrows(n)
        w = [pc(T & ~S) for S, T in A]; wmin = min(w) if wmin is None else min(wmin, min(w))
        P = view(cols_petrie(n), n)
        short = sum(1 for S, T in A if np.linalg.norm(P[T] - P[S]) < 1 - 1e-9)
        info.append(f'n={n}: |D| < 1 on {short} of {len(A)}')
    return (f'the printed axiom ||v|| >= 1 (a read-off, not a check): popcount weights are >= 1 on every non-identity arrow (smallest {wmin}, n <= 6), '
            f'the zero vector has ||0|| = 0 and an edge times alpha = 1/2 has norm 1/2; Petrie planar lengths: ' + ', '.join(info))

def check33(sab):
    ok = True; info = []
    for n in range(1, 7):
        N = 1 << n
        A = np.zeros((N, N))
        for a in range(N):
            for i in range(n): A[a, a ^ (1 << i)] = 1
        L = n * np.eye(N) - A
        vals, vecs = np.linalg.eigh(L)
        lam = 4.0 if sab and n >= 2 else 2.0
        E = vecs[:, np.abs(vals - lam) < 1e-8]
        X = np.array([[((a >> i) & 1) - 0.5 for i in range(n)] for a in range(N)])
        # E inside span(X) and of dimension n
        coef, res, rk, _ = np.linalg.lstsq(X, E, rcond=None)
        inside = np.allclose(X @ coef, E, atol=1e-9)
        smallest = float(min(v for v in vals if v > 1e-9))
        ok &= inside and E.shape[1] == n and abs(smallest - 2) < 1e-9
        rng = np.random.default_rng(330 + n)
        Pd = E[:, :2] if E.shape[1] >= 2 else np.hstack([E, np.zeros((N, 1))])
        add = all(np.allclose(Pd[a | b], Pd[a] + Pd[b] - Pd[0], atol=1e-9) for a in range(N) for b in range(N) if a & b == 0)
        ok &= add
        if n >= 3:
            hits = 0
            for _ in range(200):
                perm = rng.permutation(N); Q = Pd[perm]
                hits += all(np.allclose(Q[a | b], Q[a] + Q[b] - Q[0], atol=1e-9) for a in range(N) for b in range(N) if a & b == 0)
            info.append(f'n={n}: {hits} of 200')
            ok &= hits < 200
    return report('bd·mjg·33', ok, 'Laplacian of the n-cube graph: smallest nonzero eigenvalue 2, multiplicity n, eigenspace = span of the centred coordinates (n <= 6); the spectral '
                  'drawing from it is additive on the partial sum; random relabellings additive in ' + ', '.join(info))

CHECKS = [('bd·mjg·1', check1), ('bd·mjg·2', check2), ('bd·mjg·3', check3), ('bd·mjg·4', check4), ('bd·mjg·5', check5), ('bd·mjg·6', check6),
          ('bd·mjg·7', check7), ('bd·mjg·33', check33)]

def main():
    if SAB:
        missed = 0
        for cid, fn in CHECKS:
            okk = fn(True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            missed += okk
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        return missed == 0
    for cid, fn in CHECKS: fn(False)
    print('info bd·mjg·8  ' + info8())
    nfail = sum(1 for _, o in RESULTS if not o)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    return nfail == 0

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
