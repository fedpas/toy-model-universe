#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cat_cohomology.py: the sign as a 2-cocycle on the contracted label monoid; Clifford algebras and octonions as commutative algebras in
symmetric monoidal categories of Z_2^n-graded spaces.

  python3 selfcheck/bridges/cat_cohomology.py      one line per check, ids bd·cat·19 .. bd·cat·21; exit 1 on any FAIL

Standard library only, linear algebra over F_2 with integer bitsets, deterministic, under 1 s; runs from any folder, reads and writes no file.
  bd·cat·19  for the contracted monoid M_{n,r} (labels F_2^n, product a xor b when a and b share no null bit, 0 otherwise) the normalised F_2-valued
             2-cocycles modulo coboundaries have dim H^2 = n(n+1)/2 - r (n <= 5, every r); the invariants are the squares of the n - r invertible
             generators and the C(n,2) commutation signs; the degenerate Clifford sign is the class with every commutation sign -1 (QB2).
  bd·cat·20  for every class of the contracted monoids with n <= 3 (bicharacter representatives, each checked associative) the radical of the
             twisted algebra (the kernel of the trace form) is the span of the labels with a null bit, whatever the class.
  bd·cat·21  the octonion signs F on 3-bit labels satisfy assoc = dF = (-1)^det; (Vec_{Z2^3}, phi = dF, R = F F^T) satisfies both hexagon identities
             on all 512 triples and is symmetric with R(a,a) = 1, and the octonions are commutative in it; Cl(0,3) is the same with phi = 1.
"""
import itertools, sys

ROWS = []
def row(i, ok, text):
    cid = i
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def f2_reduce(rows):
    basis = {}
    for r in rows:
        x = r
        while x:
            h = x.bit_length() - 1
            if h in basis: x ^= basis[h]
            else: basis[h] = x; break
    return basis
def f2_rank(rows): return len(f2_reduce(rows))

def complex_data(n, r):
    N = ((1 << r) - 1) << (n - r)                       # null bits: the top r bits
    V = 1 << n
    defined = [(a, b) for a in range(1, V) for b in range(1, V) if not (a & b & N)]
    idx = {pb: k for k, pb in enumerate(defined)}
    conds = []
    for a in range(1, V):
        for b in range(1, V):
            if a & b & N: continue
            for c in range(1, V):
                if (a | b) & c & N: continue
                rw = 0
                for (x, y) in ((a, b), (a ^ b, c), (b, c), (a, b ^ c)):
                    if x and y: rw ^= 1 << idx[(x, y)]
                if rw: conds.append(rw)
    cob = []
    for t in range(1, V):
        rw = 0
        for (x, y) in defined:
            if ((x == t) + (y == t) + ((x ^ y) == t)) % 2: rw ^= 1 << idx[(x, y)]
        cob.append(rw)
    return N, defined, idx, conds, cob

def check19():
    ok = True; table = []
    for n in range(1, 6):
        for r in range(0, n + 1):
            N, defined, idx, conds, cob = complex_data(n, r)
            dimZ = len(defined) - f2_rank(conds); dimB = f2_rank(cob); H = dimZ - dimB
            if H != n * (n + 1) // 2 - r: ok = False
            # invariants: squares c(e_i,e_i) for non-null i, commutators c(e_i,e_j) + c(e_j,e_i) for i < j; they vanish on coboundaries and
            # are independent on cocycles: rank of (invariants restricted to Z) = H.  Use bicharacter representatives to realise every value.
            inv_rows = []
            for i in range(n):
                if not (N >> i & 1): inv_rows.append(1 << idx[(1 << i, 1 << i)])
            for i in range(n):
                for j in range(i + 1, n): inv_rows.append((1 << idx[(1 << i, 1 << j)]) ^ (1 << idx[(1 << j, 1 << i)]))
            # each invariant kills every coboundary
            for c in cob:
                if any(pc(c & iv) % 2 for iv in inv_rows): ok = False
            # the bit rule with eps (non-null bits first: eps = +-1, null bits 0) is a cocycle of this complex with commutators all 1
            for epsD in itertools.product((1, -1), repeat=n - r):
                e = list(epsD) + [0] * r
                vec = 0
                for (x, y) in defined:
                    if sgn(x, y, e) == -1: vec |= 1 << idx[(x, y)]
                if any(pc(cc & vec) % 2 for cc in conds): ok = False
                comm_all = all(pc(vec & ((1 << idx[(1 << i, 1 << j)]) ^ (1 << idx[(1 << j, 1 << i)]))) % 2 == 1 for i in range(n) for j in range(i + 1, n))
                sq_ok = all(pc(vec & (1 << idx[(1 << i, 1 << i)])) % 2 == (1 if e[i] == -1 else 0) for i in range(n - r))
                if not (comm_all and sq_ok): ok = False
                if n > 4: break
            table.append(f'({n},{r}):{H}')
    row('bd·cat·19', ok,
        'QB2: on the contracted label monoid M_(n,r) dim H^2(M; F_2) = n(n+1)/2 - r for every n <= 5 and r (' + ' '.join(table) + '); the class is fixed by the '
        'squares of the n - r invertible generators and the C(n,2) commutation signs; the degenerate Clifford sign is the class with all commutation '
        'signs -1 (a null generator carries no square datum): no further cohomology enters, the null part is the free super-commutative algebra')

def check20():
    ok = True; classes = 0
    for n in range(1, 4):
        for r in range(0, n + 1):
            N = ((1 << r) - 1) << (n - r); V = 1 << n
            nonnull = [i for i in range(n) if not (N >> i & 1)]
            pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
            for sq in itertools.product((0, 1), repeat=len(nonnull)):
                for cm in itertools.product((0, 1), repeat=len(pairs)):
                    # bicharacter representative: c(a,b) = sum_{i>j} cm_ij a_i b_j + sum_i sq_i a_i b_i  (a cocycle on M for every choice)
                    M = {}
                    for (i, j), v in zip(pairs, cm): M[(j, i)] = v          # a_j b_i with j > i
                    for i, v in zip(nonnull, sq): M[(i, i)] = v
                    def s(a, b):
                        if a & b & N: return 0
                        t = sum(v for (i, j), v in M.items() if a >> i & 1 and b >> j & 1)
                        return -1 if t % 2 else 1
                    # trace form 2^-n Tr L_{e_a e_b}: L_{e_c} has trace 2^n [c = 0], so the form is s(a,b) [a = b, defined]
                    T = [[(s(a, b) if a == b else 0) for b in range(V)] for a in range(V)]
                    kernel = [a for a in range(V) if all(T[a][b] == 0 for b in range(V))]
                    if sorted(kernel) != sorted(a for a in range(V) if a & N): ok = False
                    # associativity of the representative (it is a cocycle)
                    for a in range(V):
                        for b in range(V):
                            for c in range(V):
                                l = s(a, b) * s(a ^ b, c) if s(a, b) else 0
                                rr = s(b, c) * s(a, b ^ c) if s(b, c) else 0
                                if l != rr: ok = False
                    classes += 1
    row('bd·cat·20', ok,
        f'for all {classes} cohomology classes of the contracted monoids with n <= 3 (bicharacter representatives, each checked associative), the radical '
        '(kernel of the trace form) of the twisted algebra is the span of the labels with a null bit, whatever the class (e.g. commuting nulls, '
        'R[x,y]/(x^2,y^2), against the exterior algebra): the radical is the ideal of non-units of the monoid, not a cohomological notion')

def cd_conj(z):
    if len(z) == 1: return list(z)
    h = len(z) // 2
    return cd_conj(z[:h]) + [-t for t in z[h:]]
def cd_mul(x, y):
    n = len(x)
    if n == 1: return [x[0] * y[0]]
    h = n // 2; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    p1 = cd_mul(a, c); p2 = cd_mul(cd_conj(d), b); p3 = cd_mul(d, a); p4 = cd_mul(b, cd_conj(c))
    return [u - v for u, v in zip(p1, p2)] + [u + v for u, v in zip(p3, p4)]
def check21():
    unit = lambda i: [1 if t == i else 0 for t in range(8)]
    F = {}
    okF = True
    for a in range(8):
        for b in range(8):
            r_ = cd_mul(unit(a), unit(b)); nz = [t for t in range(8) if r_[t]]
            if nz != [a ^ b] or abs(r_[a ^ b]) != 1: okF = False
            F[(a, b)] = r_[a ^ b]
    def dF(a, b, c): return F[(a, b)] * F[(a ^ b, c)] * F[(b, c)] * F[(a, b ^ c)]
    def det(a, b, c):
        M = [[(x >> i) & 1 for i in range(3)] for x in (a, b, c)]
        return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0])) % 2
    def assoc(a, b, c):
        x = cd_mul(cd_mul(unit(a), unit(b)), unit(c)); y = cd_mul(unit(a), cd_mul(unit(b), unit(c)))
        return 1 if x == y else (-1 if x == [-t for t in y] else 0)
    okA = all(assoc(a, b, c) == dF(a, b, c) == (-1) ** det(a, b, c) for a in range(8) for b in range(8) for c in range(8))
    def hexagons(phi, R):
        h1 = all(phi(b, c, a) * R(a, b ^ c) * phi(a, b, c) == R(a, c) * phi(b, a, c) * R(a, b) for a in range(8) for b in range(8) for c in range(8))
        h2 = all(phi(c, a, b) * R(a ^ b, c) * phi(a, b, c) == R(a, c) * phi(a, c, b) * R(b, c) for a in range(8) for b in range(8) for c in range(8))
        sym = all(R(a, b) * R(b, a) == 1 for a in range(8) for b in range(8))
        tann = all(R(a, a) == 1 for a in range(8))
        return h1, h2, sym, tann
    RO = lambda a, b: F[(a, b)] * F[(b, a)]
    hO = hexagons(dF, RO)
    comm = all(F[(a, b)] == RO(a, b) * F[(b, a)] for a in range(8) for b in range(8))
    e = [-1, -1, -1]
    RC = lambda a, b: sgn(a, b, e) * sgn(b, a, e)
    hC = hexagons(lambda a, b, c: 1, RC)
    # the non-trivial braiding is visible: the octonion R differs from the trivial one, and from the Clifford one, on some pairs
    diffO = sum(1 for a in range(8) for b in range(8) if RO(a, b) == -1); diffOC = sum(1 for a in range(8) for b in range(8) if RO(a, b) != RC(a, b))
    print(f'     octonions: hexagons {hO[0]}, {hO[1]}; symmetric {hO[2]}; R(a,a) = 1 {hO[3]}; commutative in it {comm}; R = -1 on {diffO} of 64 pairs; '
          f'Cl(0,3): hexagons {hC[0]}, {hC[1]}, symmetric {hC[2]}, R(a,a) = 1 {hC[3]}; the two braidings differ on {diffOC} pairs')
    ok = okF and okA and all(hO) and comm and all(hC)
    row('bd·cat·21', ok,
        'the octonion signs F satisfy assoc = dF = (-1)^det (cat·K3a, cat·K3b); (Vec_(Z2^3), phi = dF, R = F F^T) satisfies both hexagons on all 512 triples, is symmetric '
        'with R(a,a) = 1 (Tannakian), and the octonions are commutative in it: a commutative associative algebra in a category symmetric monoidally '
        'equivalent to Rep(Z2^3) (Albuquerque-Majid); Cl(0,3) is the same with phi = 1')

if __name__ == '__main__':
    check19(); check20(); check21()
    verdict()
