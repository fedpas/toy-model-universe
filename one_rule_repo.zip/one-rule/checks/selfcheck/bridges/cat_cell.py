#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cat_cell.py: the cell (V, Q, pi) and the Z_4 form w = pi + 2Q of Cl(p,q,r) when null generators are present, and the two canonical
non-degenerate cells attached to a degenerate one.

  python3 selfcheck/bridges/cat_cell.py      one line per check, ids bd·cat·1 .. bd·cat·4; exit 1 on any FAIL

Standard library only, exact integers (Gaussian integers as pairs), deterministic, under 1 s; runs from any folder, reads and writes no file.
  bd·cat·1  the triple (V, Q, pi) (Q(a) = [e_a^2 = -1], pi(a) = |a| mod 2) does not fix the cell once r >= 1: Cl(1,0) and Cl(0,0,1) have the
            same triple and are not isomorphic; the full list of such pairs for n <= 3, by a full isometry test (Q and pi on every label).
  bd·cat·2  w = pi + 2Q on Cl(p,q,r), r >= 1: its Gauss sum is not of the form 2^{n/2} times an 8th root of unity with phase (p - q) pi / 4
            (Cl(0,0,1): 1 + i, phase 1, against the clock 0); every cell with r >= 1 and n <= 6.
  bd·cat·3  the form w_D(a) = pi(a_D) + 2 Q(a_D) (a_D the non-null bits of a) is the pull-back of the r = 0 form along V -> V/N: a Z_4 refinement of
            the dot product on the non-null bits, the null bits span the radical of its polar form and w_D = 0 there, and its Gauss sum is
            2^r (1+i)^p (1-i)^q exactly (every eps in {+1,-1,0}^n, n <= 5).
  bd·cat·4  the Gauss sum of w_D on Cl(p,q,r) equals the Gauss sum of the mother cell Cl(p+r, q+r) exactly and 2^r times that of the quotient
            Cl(p,q) = Cl/J; w on all of V agrees with neither (every cell with r >= 1, n <= 6).
"""
import itertools, sys

ROWS = []
def row(i, ok, text):
    cid = i
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):                       # the bit rule of the atlas (core_check.py), eps_i in {+1,-1,0}
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Qlit(a, eps): return 1 if sgn(a, a, eps) == -1 else 0
def pi(a): return pc(a) % 2
def wlit(a, eps): return (pi(a) + 2 * Qlit(a, eps)) % 4
def Dmask(eps): return sum(1 << i for i in range(len(eps)) if eps[i] != 0)
def wD(a, eps):
    aD = a & Dmask(eps)
    return (pi(aD) + 2 * Qlit(aD, eps)) % 4
I_POW = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def gsum(vals):
    re = im = 0
    for k in vals: z = I_POW[k % 4]; re += z[0]; im += z[1]
    return (re, im)
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def gpow(x, k):
    r = (1, 0)
    for _ in range(k): r = gmul(r, x)
    return r
def target(p, q, scale=1): t = gmul(gpow((1, 1), p), gpow((1, -1), q)); return (t[0] * scale, t[1] * scale)
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r

def is_eighth_root_times_sqrt(z, n):
    """z == 2^{n/2} * zeta_8^k for some k?  Compare z^2 with 2^n * i^k (exact)."""
    z2 = gmul(z, z)
    return any(z2 == (I_POW[k][0] * 2 ** n, I_POW[k][1] * 2 ** n) for k in range(4))
def phase8(z):
    """the k in 0..7 with z = |z| zeta_8^k, or None (exact: z must lie on one of the 8 rays)"""
    re, im = z
    rays = {(1, 0): 0, (1, 1): 1, (0, 1): 2, (-1, 1): 3, (-1, 0): 4, (-1, -1): 5, (0, -1): 6, (1, -1): 7}
    from math import gcd
    g = gcd(abs(re), abs(im))
    if g == 0: return None
    return rays.get((re // g, im // g))

# ---------------------------------------------------------------- isometries of (V, Q, pi): basis images pruned by Q, pi and the polar form, every label tested at the end
def isometric(Qa, Qb, Pa, Pb, n):
    Ba = [[(Qa[(1 << i) ^ (1 << j)] + Qa[1 << i] + Qa[1 << j]) % 2 for j in range(n)] for i in range(n)]
    def rec(i, imgs):
        if i == n:
            span = {0}
            for v in imgs: span |= {s ^ v for s in span}
            if len(span) != 1 << n: return False
            def T(a):
                x = 0
                for j in range(n):
                    if a >> j & 1: x ^= imgs[j]
                return x
            # the whole map is tested: with null bits Q is not a quadratic form, so its values on a basis and the polar form do not fix it
            return all(Qb[T(a)] == Qa[a] and Pb[T(a)] == Pa[a] for a in range(1 << n))
        for v in range(1, 1 << n):
            if Qb[v] != Qa[1 << i] or Pb[v] != Pa[1 << i]: continue
            if any((Qb[v ^ imgs[j]] + Qb[v] + Qb[imgs[j]]) % 2 != Ba[i][j] for j in range(i)): continue
            if rec(i + 1, imgs + [v]): return True
        return False
    return rec(0, [])

def check1():
    e1, e2 = sig(1, 0), sig(0, 0, 1)
    t1 = ([Qlit(a, e1) for a in range(2)], [pi(a) for a in range(2)])
    t2 = ([Qlit(a, e2) for a in range(2)], [pi(a) for a in range(2)])
    # Cl(1,0): (x e)^2 for x = a + b e is (a^2 + b^2) + 2ab e, zero only for a = b = 0; Cl(0,0,1): e^2 = 0, e != 0
    nil1 = [(a, b) for a in range(-3, 4) for b in range(-3, 4) if (a, b) != (0, 0) and a * a + b * b == 0 and 2 * a * b == 0]
    nil2 = sgn(1, 1, e2) == 0
    print(f'     Cl(1,0): Q = {t1[0]}, pi = {t1[1]};  Cl(0,0,1): Q = {t2[0]}, pi = {t2[1]}  (same triple)')
    print(f'     Cl(1,0) has a nonzero nilpotent element: {bool(nil1)};  Cl(0,0,1): e^2 = 0 with e != 0: {nil2}  (not isomorphic)')
    ok = t1 == t2 and not nil1 and nil2
    # every collision for n <= 3: two cells (p,q,r), (p',q',r') with isometric literal triples but different superalgebras;
    # the superalgebra class of Cl(p,q,r) is (n, r, p - q mod 8) (radical dimension 2^n - 2^{p+q}; quotient Cl(p,q), B6c)
    coll = []
    for n in range(1, 4):
        cs = [(p, n - r - p, r) for r in range(n + 1) for p in range(n - r + 1)]
        for x in range(len(cs)):
            for y in range(x + 1, len(cs)):
                (p1, q1, r1), (p2, q2, r2) = cs[x], cs[y]
                ea, eb = sig(p1, q1, r1), sig(p2, q2, r2)
                same_triple = isometric([Qlit(a, ea) for a in range(1 << n)], [Qlit(a, eb) for a in range(1 << n)],
                                        [pi(a) for a in range(1 << n)], [pi(a) for a in range(1 << n)], n)
                same_alg = r1 == r2 and (p1 - q1) % 8 == (p2 - q2) % 8
                if same_triple and not same_alg: coll.append(f'Cl{cs[x]}~Cl{cs[y]}')
    print(f'     literal-triple collisions between non-isomorphic cells, n <= 3: {len(coll)}: ' + ', '.join(coll))
    row('bd·cat·1', ok and len(coll) == 5,
        'the literal (V,Q,pi) does not fix the cell when r >= 1: Cl(1,0) = R+R and Cl(0,0,1) = R[x]/x^2 have the same triple; '
        f'{len(coll)} such pairs for n <= 3 by a full isometry test on every label: ' + ', '.join(coll) + ' (the triple is the cell only for r = 0)')

def check2():
    good = []; brown = []; table = []; allr = 0
    for n in range(1, 7):
        for r in range(1, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r); allr += 1
                S = gsum([wlit(a, e) for a in range(1 << n)])
                k = phase8(S); brown_like = is_eighth_root_times_sqrt(S, n)
                if brown_like: brown.append(((p, q, r), S, k))
                if brown_like and k == (p - q) % 8: good.append((p, q, r))
                if n <= 3: table.append(f'Cl({p},{q},{r}): {S}')
    print('     literal Gauss sums, n <= 3: ' + '; '.join(table))
    print('     the literal sums of Brown form 2^(n/2) zeta_8^k: ' + '; '.join(f'Cl{c}: {S}, phase {k}' for c, S, k in brown))
    ok = not good and any(c == (0, 0, 1) for c, S, k in brown)
    row('bd·cat·2', ok,
        f'with the literal w = pi + 2Q none of the {allr} cells with r >= 1, n <= 6, has a Gauss sum of Brown form with phase (p - q) pi / 4: '
        f'{allr - len(brown)} are not of Brown form at all, and the {len(brown)} that are have the wrong phase; smallest: Cl(0,0,1) gives 1 + i (phase 1, clock 0)')

def check3():
    ok = True; cnt = 0
    for n in range(1, 6):
        for e in itertools.product((1, -1, 0), repeat=n):
            e = list(e); D = Dmask(e); N = ((1 << n) - 1) ^ D
            p, q, r = e.count(1), e.count(-1), e.count(0)
            W = [wD(a, e) for a in range(1 << n)]
            for a in range(1 << n):
                if W[a] != W[a & D]: ok = False                      # pull-back along V -> V/N
                for b in range(1 << n):
                    if (W[a ^ b] - W[a] - W[b]) % 4 != (2 * pc(a & b & D)) % 4: ok = False
            rad = [a for a in range(1 << n) if all(pc(a & b & D) % 2 == 0 for b in range(1 << n))]
            if sorted(rad) != sorted(a for a in range(1 << n) if a & D == 0): ok = False
            if any(W[a] != 0 for a in rad): ok = False
            if gsum(W) != target(p, q, 2 ** r): ok = False
            cnt += 1
    row('bd·cat·3', ok,
        f'w_D(a) = pi(a_D) + 2Q(a_D) is the pull-back of the r = 0 form along V -> V/N, a Z_4 refinement of the dot product on the '
        f'non-null bits with radical = span of the null bits and w_D = 0 there, Gauss sum 2^r (1+i)^p (1-i)^q ({cnt} sign vectors, n <= 5)')

def check4():
    ok = True; lit_mismatch = 0; total = 0; coinc = []
    for n in range(1, 7):
        for r in range(1, n + 1):
            for p in range(n - r + 1):
                q = n - r - p; e = sig(p, q, r)
                SD = gsum([wD(a, e) for a in range(1 << n)])
                Smother = gsum([wD(a, sig(p + r, q + r)) for a in range(1 << (n + r))])     # Cl(p+r, q+r), r = 0
                Squot = gsum([wD(a, sig(p, q)) for a in range(1 << (p + q))])               # Cl(p,q) = Cl/J
                if SD != Smother or SD != (Squot[0] * 2 ** r, Squot[1] * 2 ** r): ok = False
                Slit = gsum([wlit(a, e) for a in range(1 << n)])
                if Slit != Smother and Slit != Squot: lit_mismatch += 1
                else: coinc.append(f'Cl({p},{q},{r}): literal {Slit}, quotient {Squot}, mother {Smother}')
                total += 1
    print('     literal sum coinciding with the quotient or the mother sum: ' + '; '.join(coinc))
    row('bd·cat·4', ok,
        f'for every Cl(p,q,r), r >= 1, n <= 6 ({total} cells): the Gauss sum of w_D equals the Gauss sum of the mother cell Cl(p+r,q+r) '
        f'exactly and is 2^r times that of the quotient Cl(p,q): the sum over all labels with weight 0 on the null bits (core·B3) is the mother sum, the sum over the '
        f'labels without a null bit (cat·K4a) the quotient sum, with one phase; the literal sum equals neither in {lit_mismatch} of {total} (coincidences listed above)')

if __name__ == '__main__':
    check1(); check2(); check3(); check4()
    verdict()
