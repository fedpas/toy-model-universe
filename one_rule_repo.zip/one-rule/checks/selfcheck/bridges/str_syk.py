#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""str_syk.py: the type of the even part decides the random-matrix class of the Majorana SYK model.

  bd·str·20  N Majoranas gamma_i (gamma_i^2 = 1, the cell Cl(N,0)) built on the 2^(N/2) labels of Lambda(R^(N/2)) from the bit rule (T20:
             c^+ + c and i(c^+ - c)); a random q = 4 Hamiltonian (seed 7 + N) split by fermion parity.  For N = 8..16: N = 0 mod 8 no
             degeneracy and different spectra in the two sectors (GOE), N = 2, 6 mod 8 the two sectors have the same spectrum (GUE),
             N = 4 mod 8 every level doubly degenerate inside a sector (GSE).  The type of the even part Cl^0(N,0) from the bit rule
             (Frobenius-Schur count and centre) is R+R, C, H+H, C, R+R: the Dyson class is the type of the even part (clock 1 - N mod 8).

  python3 str_syk.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; about ten seconds."""
import itertools, sys
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Lmat(i, eps):
    n = len(eps); N = 1 << n; M = np.zeros((N, N))
    for a in range(N):
        s = sgn(1 << i, a, eps)
        if s: M[a ^ (1 << i), a] = s
    return M
def even_type(eps):
    n = len(eps); top = (1 << n) - 1; ev = [a for a in range(1 << n) if pc(a) % 2 == 0]
    nu = sum(sgn(a, a, eps) for a in ev)
    if n % 2 == 0 and sgn(top, top, eps) == -1: return 'C'
    k = 2 if n % 2 == 0 else 1
    base = 'R' if nu > 0 else ('C' if nu == 0 else 'H')
    return ('2' if k == 2 else '') + base

def syk(N, seed):
    m = N // 2
    plus = [Lmat(j, [1] * m) for j in range(m)]                       # c_j^+ + c_j
    minus = [Lmat(j, [1] * j + [-1] + [1] * (m - j - 1)) for j in range(m)]   # c_j^+ - c_j
    g = []
    for j in range(m): g += [plus[j].astype(complex), 1j * minus[j]]
    D = 1 << m; Id = np.eye(D)
    ok = all(np.allclose(g[a] @ g[b] + g[b] @ g[a], 2 * Id * (a == b)) for a in range(N) for b in range(N))
    rng = np.random.RandomState(seed)
    H = np.zeros((D, D), complex)
    for quad in itertools.combinations(range(N), 4):
        a, b, c, d = quad; H += rng.randn() * (g[a] @ g[b] @ g[c] @ g[d])
    ok = ok and np.allclose(H, H.conj().T)
    par = np.array([(-1) ** pc(x) for x in range(D)])
    ev = [np.sort(np.linalg.eigvalsh(H[np.ix_(par == s, par == s)])) for s in (1, -1)]
    scale = max(abs(ev[0]).max(), 1.0)
    gaps = [np.diff(e) / scale for e in ev]
    deg_in = all((gp[0::2] < 1e-9).all() and (gp[1::2] > 1e-7).all() for gp in gaps)     # every level exactly doubled inside a sector
    nondeg_in = all((gp > 1e-7).all() for gp in gaps)
    same = np.allclose(ev[0], ev[1], atol=1e-9 * scale)
    return ok, deg_in, nondeg_in, same

def check20():
    ok = True; out = []
    for N in (8, 10, 12, 14, 16):
        good, deg_in, nondeg_in, same = syk(N, 7 + N)
        if N % 8 == 0: cls = 'GOE' if (nondeg_in and not same) else '?'
        elif N % 8 in (2, 6): cls = 'GUE' if (nondeg_in and same) else '?'
        else: cls = 'GSE' if (deg_in and not same) else '?'
        ty = even_type([1] * N)
        want = {0: ('GOE', '2R'), 2: ('GUE', 'C'), 4: ('GSE', '2H'), 6: ('GUE', 'C')}[N % 8]
        if not good or (cls, ty) != want: ok = False
        out.append(f'N={N}: {cls}, Cl^0(N,0) = {ty}')
    row('bd·str·20', ok, 'Majorana SYK (q = 4, random couplings, gammas from the bit-rule Fock labels T20) split by fermion parity: ' + '; '.join(out) + ' -- the Dyson class (GOE / GUE / GSE as in Cotler et al., Sec. 3.1, N mod 8 = 0 / 2,6 / 4) is the type of the even part, R+R / C / H+H, i.e. the clock 1 - N mod 8 of Cl^0(N,0) = Cl(0,N-1)')

if __name__ == '__main__':
    check20()
    finish()
