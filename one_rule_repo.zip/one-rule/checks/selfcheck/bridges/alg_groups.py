#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""alg_groups.py: the finite-group lens in the language of extraspecial 2-groups and orthogonal groups over F_2.

  python3 selfcheck/bridges/alg_groups.py      one line per check, ids bd·alg·10 .. bd·alg·13 and bd·alg·23; exit 1 on any FAIL

Standard library only, exact, deterministic, about 5 s; runs from any folder, reads and writes no file.
 bd·alg·10  the blade group G_{p,q} = {+-e_a}, a central extension of Z_2^n by Z_2 with class Q (n <= 6): for n even it is extraspecial 2^{1+n} with
            2^n + eps 2^(n/2) elements of square 1, eps = + for the real type (c = 0, 2) and - for the quaternionic type (c = 4, 6); for n odd its
            centre has order 4 and is cyclic exactly for the complex type; the group invariants separate the ungraded types.
 bd·alg·11  O(Q) of Cl(0,6) (the class of Cl(3,3), Cl(4,2)) is S_8: the 28 non-singular labels are the 28 two-subsets of 8 points, B(u,v) = 1 iff
            they meet in one point, and the 28 transvections generate a group of order 40320 with the transposition-length distribution of S_8
            (1, 28, 322, 1960, 6769, 13132, 13068, 5040).
 bd·alg·12  the label form of Cl(0,8) has 270 maximal totally singular subspaces in two families of 135; the 30 that contain the top label are
            exactly the doubly-even self-dual [8,4,4] codes, and Furey's axes (core·B11) are one of them.
 bd·alg·13  the blade group of Cl(8k,0) (k = 1, 2, 3) is extraspecial of + type: the sum of the signs of e_a^2 is +2^(n/2) (Arf 0); that for k = 3
            this is the abstract type of the normal 2^(1+24)_+ in the Monster's 2^(1+24).Co_1 is standard and recalled, not computed.
 bd·alg·23  over the field F_2 the tables of Cl(2,0), Cl(1,1), Cl(0,2) coincide (every sign is 1) and give the group algebra F_2[Z_2^2], with
            (1 + e_1)^2 = 0: the cells differ in the exponent of the sign over Z (the class Q, the blade group), not in the rule over F_2.
"""
import sys
from itertools import combinations
from math import comb

ROWS = []
def row(i, ok, text):
    cid = 'bd·alg·' + str(i)
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q): return [1] * p + [-1] * q
TYPE = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']

def check10():
    ok = True; inv_by_type = {}
    for n in range(1, 7):
        for p in range(n + 1):
            q = n - p; e = sig(p, q); N = 1 << n; c = (p - q) % 8
            # group elements (s, a), s in {+1,-1}; product (s,a)(t,b) = (s t sgn(a,b), a^b)
            def mul(x, y): return (x[0] * y[0] * sgn(x[1], y[1], e), x[1] ^ y[1])
            G = [(s, a) for s in (1, -1) for a in range(N)]
            Z = [g for g in G if all(mul(g, h) == mul(h, g) for h in G)]
            inv = {g: next(k for k in G if mul(g, k) == (1, 0)) for g in G}
            comms = set()
            for g in G:
                for h in G:
                    comms.add(mul(mul(g, h), mul(inv[g], inv[h])))
            nsq1 = sum(1 for g in G if mul(g, g) == (1, 0))
            zcyc = any(mul(z, z) == (-1, 0) for z in Z)
            invs = (len(Z), zcyc, nsq1, len(comms))
            inv_by_type.setdefault((n, TYPE[c]), set()).add(invs)
            if n % 2 == 0:
                m = n // 2; eps = 1 if TYPE[c] == 'R' else -1
                if len(Z) != 2 or (n >= 2 and comms != {(1, 0), (-1, 0)}) or nsq1 != (1 << (2 * m)) + eps * (1 << m): ok = False
            else:
                if len(Z) != 4 or zcyc != (TYPE[c] == 'C'): ok = False
    # invariants separate the types within each n and agree inside a type
    for n in range(1, 7):
        sets = [v for (m, t), v in inv_by_type.items() if m == n]
        if any(len(v) != 1 for v in sets) or len({next(iter(v)) for v in sets}) != len(sets): ok = False
    row(10, ok, 'the blade group G_{p,q} = {+-e_a} (order 2^(n+1), n <= 6): n even -> extraspecial 2^{1+n}, with 2^n + eps 2^(n/2) elements of square 1, eps = +1 for type R (c = 0, 2) and -1 for type H (c = 4, 6) (D8 for Cl(2,0), Cl(1,1); Q8 for Cl(0,2)); n odd -> centre of order 4, cyclic exactly for type C; group invariants are constant on each ungraded type and separate the types: the finite-group lens is the classification of these central extensions, H^2(Z_2^n;Z_2) = quadratic forms (bd·alg·1)')

def check11():
    ok = True
    n = 6; e = sig(0, 6); N = 1 << n
    Q = [1 if sgn(a, a, e) == -1 else 0 for a in range(N)]
    def B(u, v): return (Q[u ^ v] + Q[u] + Q[v]) % 2
    # phi: label of Cl(0,6) -> even subset of {0..6} (core·B15): a -> a + parity(a) e_6; then a 2-subset of {0..7}
    def phi(a): return a ^ ((pc(a) % 2) << 6)
    ns = [v for v in range(1, N) if Q[v] == 1]
    if len(ns) != 28: ok = False
    def two_subset(v):
        x = phi(v)
        if pc(x) == 2: return frozenset(i for i in range(7) if x >> i & 1)
        if pc(x) == 6: return frozenset([7] + [i for i in range(7) if not x >> i & 1])
        return None
    T = {v: two_subset(v) for v in ns}
    if None in T.values() or len(set(T.values())) != 28: ok = False
    for u in ns:
        for v in ns:
            if u != v and B(u, v) != (1 if len(T[u] & T[v]) == 1 else 0): ok = False
    # transvections as permutations of the 64 labels; BFS on the group they generate
    def tv(v): return tuple(x ^ (v if B(x, v) else 0) for x in range(N))
    gens = [tv(v) for v in ns]
    for g in gens:
        if any(Q[g[x]] != Q[x] for x in range(N)): ok = False
    ident = tuple(range(N)); dist = {ident: 0}; frontier = [ident]
    while frontier:
        nxt = []
        for g in frontier:
            for t in gens:
                h = tuple(t[g[x]] for x in range(N))
                if h not in dist: dist[h] = dist[g] + 1; nxt.append(h)
        frontier = nxt
    hist = [0] * (max(dist.values()) + 1)
    for d in dist.values(): hist[d] += 1
    stirling = [1, 28, 322, 1960, 6769, 13132, 13068, 5040]       # unsigned Stirling numbers c(8, 8-d)
    if len(dist) != 40320 or hist != stirling: ok = False
    row(11, ok, f'O(Q) of Cl(0,6) (the Klein-quadric class of Cl(3,3), Cl(4,2)) = S_8: the 28 non-singular labels map (through core·B15\'s even subsets) to the 28 two-subsets of 8 points with B(u,v) = 1 iff they meet in one point; the 28 transvections generate a group of order {len(dist)} with length distribution {hist} = the cycle-count (Stirling) distribution of S_8, maximum 7 attained by the 5040 eight-cycles: T12\'s \'7 > 6\' is \'an 8-cycle needs 7 transpositions\', and [O(Q) : S_7] = 8 is T9 (d)')

def check12():
    ok = True
    n = 8; e = sig(0, 8); N = 1 << n
    Q = [1 if sgn(a, a, e) == -1 else 0 for a in range(N)]
    def B(u, v): return (Q[u ^ v] + Q[u] + Q[v]) % 2
    sing = [v for v in range(1, N) if Q[v] == 0]
    if len(sing) != 135: ok = False
    lag = set()
    def span(vs):
        s = {0}
        for v in vs: s |= {x ^ v for x in s}
        return frozenset(s)
    def rec(chosen, S, start):
        if len(chosen) == 4:
            lag.add(S); return
        for i in range(start, len(sing)):
            v = sing[i]
            if v in S or any(B(v, u) for u in chosen): continue
            S2 = span(chosen + [v])
            # canonical: v must be the smallest singular vector of S2 not in S (avoid repeats cheaply)
            if min(x for x in S2 if x not in S) != v: continue
            rec(chosen + [v], S2, i + 1)
    rec([], frozenset([0]), 0)
    lags = sorted(lag, key=lambda s: sorted(s))
    if len(lags) != 270: ok = False
    # families: same family iff dim of intersection is even (codimension even in dimension 4)
    L0 = lags[0]
    fam = [1 if (len(L & L0).bit_length() - 1) % 2 == 0 else 2 for L in lags]
    for i in range(0, 270, 37):                                  # consistency of the relation on a sample of pairs
        for j in range(0, 270, 29):
            same = ((len(lags[i] & lags[j]).bit_length() - 1) % 2 == 0)
            if same != (fam[i] == fam[j]): ok = False
    top = N - 1
    thr = [L for L in lags if top in L]
    codes_ok = all(sorted(pc(x) for x in L) == [0] + [4] * 14 + [8] for L in thr)
    # all doubly-even self-dual codes of length 8 = 30
    furey_lines = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
    F = span([sum(1 << (k - 1) for k in L) | (1 << 7) for L in furey_lines])
    fam_counts = (fam.count(1), fam.count(2))
    thr_fam = (sum(1 for L in thr if fam[lags.index(L)] == 1), sum(1 for L in thr if fam[lags.index(L)] == 2))
    if fam_counts != (135, 135) or len(thr) != 30 or not codes_ok or F not in lag: ok = False
    row(12, ok, f'Lagrangians of the label form of Cl(0,8) (O+_8(2)): {len(lags)} maximal totally singular subspaces = maximal sets of 16 commuting blades of square +1, in two families {fam_counts}; {len(thr)} contain the top label, and they are exactly the doubly-even self-dual [8,4,4] codes (weights 0, 4^14, 8), split {thr_fam} between the families; Furey\'s axes (core·B11) are one of these 30. The axes of V are a choice among 270 (30 with the volume element diagonal): an input')

def check13():
    ok = True; out = {}
    for k in (1, 2, 3):
        n = 8 * k
        S = sum(comb(n, j) * (-1) ** (j * (j - 1) // 2) for j in range(n + 1))   # sum_a (-1)^{Q(a)}, Q_{Cl(n,0)}(a) = C(|a|,2) mod 2
        out[n] = S
        if S != 2 ** (n // 2): ok = False                                       # + 2^{n/2}: Arf 0, plus type
    # cross-check the closed form against the bit rule at n = 8
    e = sig(8, 0)
    if sum((1 if sgn(a, a, e) == 1 else -1) for a in range(256)) != out[8]: ok = False
    row(13, ok, f'sum over labels of the sign of e_a^2 for Cl(8k,0) = {out} = +2^(n/2): Arf 0, so the blade group of Cl(8k,0) is extraspecial 2^(1+8k)_+; for k = 3 this is the abstract type of the normal 2^(1+24)_+ in the Monster\'s 2^(1+24).Co_1 (the identification with the Monster subgroup is standard and recalled, not computed; Co_1 acts on Leech/2Leech, a + type form of rank 24, isometric to Q_Cl(24,0) by Arf)')

def check23():
    ok = True
    tabs = {}
    for p, q in ((2, 0), (1, 1), (0, 2)):
        e = sig(p, q)
        tabs[(p, q)] = tuple(sgn(a, b, e) % 2 for a in range(4) for b in range(4))      # the sign read in F_2: -1 = 1
    same = len(set(tabs.values())) == 1 and set(next(iter(tabs.values()))) == {1}
    # (1 + e_1)^2 = 1 + 2 e_1 + e_1^2 = 1 + 0 + 1 = 0 over F_2 when e_1^2 = +-1
    nil = all((1 + sgn(1, 1, sig(p, q)) % 2) % 2 == 0 for p, q in ((2, 0), (1, 1), (0, 2)))
    if not (same and nil): ok = False
    row(23, ok, 'over the field F_2 the bit-rule tables of Cl(2,0), Cl(1,1), Cl(0,2) coincide (every sign is 1): the commutative group algebra F_2[Z_2^2], not semisimple ((1 + e_1)^2 = 0); the cells are told apart only by the exponent of the sign over Z (the class Q, the blade group {+-e_a}): the finite lens keeps the signs and drops the coefficients')

if __name__ == '__main__':
    for f in (check10, check11, check12, check13, check23): f()
    verdict()
