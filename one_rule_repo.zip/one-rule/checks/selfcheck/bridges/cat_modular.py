#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cat_modular.py: the clock as the central charge of a pointed modular category, its Lagrangians, and the lattices of the cells.

  python3 selfcheck/bridges/cat_modular.py      one line per check, ids bd·cat·12 .. bd·cat·15 and bd·cat·23; exit 1 on any FAIL

Standard library only, exact integers, Gaussian integers and rationals, deterministic, about 2 s; runs from any folder, reads and writes no file.
  bd·cat·12  theta(a) = i^{w(a)} on V = F_2^n is a metric group: multiplicative over the generators (theta(e_i) = i for a square +1, -i for -1),
             bicharacter (-1)^{a.b}, theta(a)^2 = (-1)^{|a|}, Gauss sum (1+i)^p (1-i)^q: the clock is the central charge mod 8 of the pointed
             modular category C(V, theta) = Sem^p (x) Sem-bar^q (every (p,q), n <= 8).
  bd·cat·13  Lagrangian subgroups (|L|^2 = |V|, theta = 1 on L) exist iff p - q = 0 mod 8 (every (p,q) with n <= 8, exhaustive); each consists of even,
             mutually commuting labels of square +1, Furey's Hamming code of core·B11 is one of the 30 Lagrangians of Cl(0,8), and no generator has
             twist +-1.
  bd·cat·14  w(a) = x.x mod 4 for every x in Z^{p,q} reducing to a (n <= 4); the even sublattice D_{p,q} has discriminant group {0, v, s, c} with
             theta(v) = -1 and theta(s) = theta(c) = exp(2 pi i (p-q)/8), Gauss sum 2 exp(2 pi i (p-q)/8) (every (p,q), n <= 10).
  bd·cat·15  for n = 3..12 the roots e_0 - e_1 - e_2 - e_3 and e_i - e_{i+1} of I_{1,n} have the Cartan matrix of E_n as Gram matrix, are orthogonal to
             the characteristic vector k = (3; -1, ..., -1), and det Cartan(E_n) = k.k = 9 - n = sigma(I_{1,n}) + 8 (van der Blij).
  bd·cat·23  a Lagrangian L gives the even idempotent P and the graded module S = Cl P with Cl(p,q) = End(S) as superalgebras, for Cl(1,1), Cl(2,2),
             Cl(3,3), Cl(4,4), Cl(8,0), Cl(0,8): the cells of clock 0 are Morita-trivial, constructively, on the labels.
"""
import itertools, sys
from fractions import Fraction as Fr

ROWS = []
def row(i, ok, text):
    cid = i
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def sig(p, q, r=0): return [1] * p + [-1] * q + [0] * r
def Q(a, e): return 1 if sgn(a, a, e) == -1 else 0
def w(a, e): return (pc(a) % 2 + 2 * Q(a, e)) % 4
I_POW = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def gsum(ks):
    re = im = 0
    for k in ks: re += I_POW[k % 4][0]; im += I_POW[k % 4][1]
    return (re, im)
def target(p, q):
    t = (1, 0)
    for _ in range(p): t = gmul(t, (1, 1))
    for _ in range(q): t = gmul(t, (1, -1))
    return t

def check12():
    ok = True
    for n in range(1, 9):
        for p in range(n + 1):
            q = n - p; e = sig(p, q); W = [w(a, e) for a in range(1 << n)]
            gen = [1 if e[i] == 1 else 3 for i in range(n)]            # theta(e_i) = i^1 or i^3
            for a in range(1 << n):
                if W[a] != sum(gen[i] for i in range(n) if a >> i & 1) % 4: ok = False      # Sem^p (x) Sem-bar^q
                if (2 * W[a]) % 4 != (2 * pc(a)) % 4: ok = False                              # theta^2 = (-1)^{|a|}
            if n <= 6:
                for a in range(1 << n):
                    for b in range(1 << n):
                        if (W[a ^ b] - W[a] - W[b]) % 4 != (2 * pc(a & b)) % 4: ok = False   # bicharacter (-1)^{a.b}
            # non-degenerate: the bicharacter (-1)^{a.b} has trivial radical (the dot product is the identity matrix)
            if gsum(W) != target(p, q): ok = False
    row('bd·cat·12', ok,
        'theta = i^w is the metric group Sem^p (x) Sem-bar^q (multiplicative over the generators, bicharacter (-1)^(a.b), non-degenerate, '
        'theta^2 = parity), Gauss sum (1+i)^p (1-i)^q: the clock is the central charge mod 8 of the pointed modular category C(V, i^w), every (p,q), n <= 8')

def lagrangians(n, e):
    W = [w(a, e) for a in range(1 << n)]
    iso = [a for a in range(1, 1 << n) if W[a] == 0]
    level = {frozenset([0])}
    for k in range(n // 2):
        nxt = set()
        for S in level:
            for v in iso:
                if v in S: continue
                T = S | {s ^ v for s in S}
                if all(W[t] == 0 for t in T): nxt.add(frozenset(T))
        level = nxt
        if not level: break
    return [L for L in level if len(L) == 2 ** (n // 2)] if n % 2 == 0 else []

def check13():
    ok = True; counts = {}; ham = None
    lines = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
    gens = [sum(1 << (k - 1) for k in L) | (1 << 7) for L in lines]
    span = {0}
    for g in gens: span |= {s ^ g for s in span}
    ham = frozenset(span)
    for n in range(1, 9):
        for p in range(n + 1):
            q = n - p; e = sig(p, q)
            Ls = lagrangians(n, e)
            if bool(Ls) != ((p - q) % 8 == 0): ok = False
            for L in Ls:
                if any(pc(a) % 2 for a in L): ok = False                                       # even labels
                if any(sgn(a, a, e) != 1 for a in L): ok = False                               # squares +1
                if any(sgn(a, b, e) != sgn(b, a, e) for a in L for b in L): ok = False          # commuting
            if Ls: counts[f'Cl({p},{q})'] = len(Ls)
            if any(w(1 << i, e) % 2 == 0 for i in range(n)): ok = False     # theta(e_i) = +-i, never +-1: no hyperbolic cell
    ok &= ham in set(lagrangians(8, sig(0, 8)))
    print('     Lagrangian counts (cells with n <= 8 and clock 0): ' + ', '.join(f'{k}: {v}' for k, v in counts.items()))
    row('bd·cat·13', ok,
        'a Lagrangian of (V, i^w) exists iff p - q = 0 mod 8 (every (p,q) with n <= 8, exhaustive); each one consists of even, mutually commuting '
        'labels of square +1 (a split commutative subalgebra of dimension 2^(n/2) = N, cat·W1), Furey\'s Hamming code (core·B11) is one of the '
        f'{counts.get("Cl(0,8)")} of Cl(0,8); no generator has twist +-1, so no cell is hyperbolic; that a Lagrangian makes C(V, i^w) a Drinfeld centre of a twisted Vec_(Z2^(n/2)) is recalled, not computed')

def check14():
    ok = True
    for n in range(1, 5):                                   # x.x mod 4 on Z^{p,q} depends only on x mod 2 and equals w
        for p in range(n + 1):
            q = n - p; e = sig(p, q)
            for x in itertools.product(range(-2, 3), repeat=n):
                a = sum(1 << i for i in range(n) if x[i] % 2)
                if sum(e[i] * x[i] * x[i] for i in range(n)) % 4 != w(a, e): ok = False
    ZETA = {}
    for n in range(1, 11):
        for p in range(n + 1):
            q = n - p; e = sig(p, q)
            def dot(x, y): return sum(Fr(e[i]) * x[i] * y[i] for i in range(n))
            s = [Fr(1, 2)] * n; e1 = [Fr(1)] + [Fr(0)] * (n - 1); z = [Fr(0)] * n
            reps = {'0': z, 'v': e1, 's': s, 'c': [s[i] + e1[i] for i in range(n)]}
            qv = {k: (dot(x, x) / 2) % 1 for k, x in reps.items()}                  # discriminant quadratic form of D_{p,q}
            eighths = {k: int(v * 8) for k, v in qv.items()}
            if any(v * 8 != int(v * 8) for v in qv.values()): ok = False
            # Gauss sum sum_x exp(2 pi i q(x)) = sum zeta_8^{8q}; expect 2 zeta_8^{p-q}
            cnt = [0] * 8
            for k in eighths.values(): cnt[k % 8] += 1
            want = [0] * 8; want[(p - q) % 8] = 2
            # 1 + (-1) cancel: zeta_8^0 + zeta_8^4 = 0
            net = [cnt[k] - cnt[(k + 4) % 8] for k in range(4)]
            wnet = [want[k] - want[(k + 4) % 8] for k in range(4)]
            if net != wnet: ok = False
            if eighths['v'] != 4 or eighths['s'] != (p - q) % 8: ok = False            # fermion, spinor twist = clock
            two_s_in_D = (n % 2 == 0)                                                   # 2s = (1,...,1) has even coordinate sum iff n even
            if two_s_in_D != (n % 2 == 0): ok = False
    row('bd·cat·14', ok,
        'w(a) = x.x mod 4 for every x in Z^{p,q} reducing to a (n <= 4): the cell (V, w) is the mod-2 reduction of the frame lattice I_{p,q}; the even '
        'sublattice D_{p,q} has discriminant {0, v, s, c} with theta(v) = -1 (a fermion) and theta(s) = theta(c) = exp(2 pi i (p-q)/8), Gauss sum '
        '2 exp(2 pi i (p-q)/8) (every (p,q), n <= 10): the clock is the central charge of a pointed minimal modular extension of sVec')

def det_bareiss(M):
    M = [r[:] for r in M]; n = len(M); sign = 1; prev = 1
    for k in range(n - 1):
        if M[k][k] == 0:
            sw = next((i for i in range(k + 1, n) if M[i][k] != 0), None)
            if sw is None: return 0
            M[k], M[sw] = M[sw], M[k]; sign = -sign
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                M[i][j] = (M[i][j] * M[k][k] - M[i][k] * M[k][j]) // prev
        prev = M[k][k]
    return sign * M[n - 1][n - 1]
def cartan_E(n):
    A = [[0] * n for _ in range(n)]
    for i in range(n): A[i][i] = 2
    for i, j in [(0, 2), (1, 3), (2, 3)] + [(k, k + 1) for k in range(3, n - 1)]:
        if j < n: A[i][j] = A[j][i] = -1
    return A
def check15():
    ok = True; dets = []
    for n in range(3, 13):
        def dot(x, y): return -x[0] * y[0] + sum(x[i] * y[i] for i in range(1, n + 1))     # I_{1,n} with the sign making roots norm 2
        a0 = [1, -1, -1, -1] + [0] * (n - 3)                         # e_0 - e_1 - e_2 - e_3
        chain = [[0] + [1 if j == i else (-1 if j == i + 1 else 0) for j in range(1, n + 1)] for i in range(1, n)]   # e_i - e_(i+1)
        order = [chain[0], a0, chain[1]] + chain[2:]                 # nodes 0..n-1 of cartan_E: branch node 3 = e_3 - e_4
        G = [[dot(x, y) for y in order] for x in order]
        k = [3] + [-1] * n
        orth = all(dot(k, x) == 0 for x in order)
        charac = all(c % 2 == 1 for c in k)
        kk = -dot(k, k)                                              # k.k in the form x_0^2 - sum x_i^2
        dE = det_bareiss(cartan_E(n))
        good = (G == cartan_E(n)) and orth and charac and kk == 9 - n == dE and (kk - (1 - n)) % 8 == 0
        if not good: ok = False
        dets.append(f'{n}:{dE}')
    row('bd·cat·15', ok,
        'for n = 3..12 the roots e_0-e_1-e_2-e_3, e_i-e_(i+1) of the frame lattice I_(1,n) of Cl(1,n) have Gram matrix Cartan(E_n), are orthogonal to the '
        'characteristic vector k = (3;-1,...,-1), and det Cartan(E_n) = k.k = 9 - n = sigma(I_(1,n)) + 8 (van der Blij: k.k = sigma mod 8); dets ' + ' '.join(dets))

def mvmul(A, B, e):
    out = {}
    for a, x in A.items():
        for b, y in B.items():
            c = x * y * sgn(a, b, e)
            if c: out[a ^ b] = out.get(a ^ b, 0) + c
    return {k: v for k, v in out.items() if v}
P_MOD = 1000003
def rank_mod(M):
    M = [[x % P_MOD for x in r] for r in M]; rk = 0
    for c in range(len(M[0]) if M else 0):
        piv = next((i for i in range(rk, len(M)) if M[i][c]), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]; inv = pow(M[rk][c], P_MOD - 2, P_MOD); M[rk] = [x * inv % P_MOD for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c]:
                f = M[i][c]; M[i] = [(x - f * y) % P_MOD for x, y in zip(M[i], M[rk])]
        rk += 1
    return rk
def check23():
    ok = True; done = []
    for (p, q) in [(1, 1), (2, 2), (3, 3), (4, 4), (8, 0), (0, 8)]:
        n = p + q; e = sig(p, q); N = 1 << n
        L = sorted(lagrangians(n, e)[0])
        # a basis of L and the even idempotent P = prod (1 + e_l)/2 (scaled by 2^k to stay integral)
        basis = []; span = {0}
        for v in L:
            if v not in span: basis.append(v); span |= {x ^ v for x in span}
        Pm = {0: 1}
        for v in basis: Pm = mvmul(Pm, {0: 1, v: 1}, e)
        if any(pc(k) % 2 for k in Pm): ok = False                                    # P is even
        if mvmul(Pm, Pm, e) != {k: v * 2 ** len(basis) for k, v in Pm.items()}: ok = False   # (2^k P)^2 = 2^k (2^k P)
        # S = Cl P: a basis e_a P over coset representatives of V / L
        reps = []; seen = set()
        for a in range(N):
            if a in seen: continue
            reps.append(a); seen |= {a ^ l for l in L}
        S = [mvmul({a: 1}, Pm, e) for a in reps]
        dimS = len(S); evenS = sum(1 for a in reps if pc(a) % 2 == 0)
        # coordinates of a multivector in the basis S: e_a P has its support in the coset a + L, so read the coefficient at the label a
        def coords(X):
            return [Fr(X.get(a, 0), S[k][a]) for k, a in enumerate(reps)]
        # the left action of every blade on S: matrices, flattened; Cl -> End(S) is injective iff the 2^n matrices are independent
        mats = []
        for b in range(N):
            M = []
            for k in range(dimS):
                M.extend(coords(mvmul({b: 1}, S[k], e)))
            if any(x.denominator != 1 for x in M): ok = False
            mats.append([int(x) for x in M])
        if rank_mod(mats) != N or dimS * dimS != N or evenS * 2 != dimS: ok = False
        # odd blades act by odd maps (exchange S_0 and S_1), even blades by even maps
        for b in range(N):
            for k, a in enumerate(reps):
                img = mvmul({b: 1}, S[k], e)
                targets = [kk for kk, aa in enumerate(reps) if img.get(aa, 0)]
                if any((pc(reps[kk]) + pc(a) + pc(b)) % 2 for kk in targets): ok = False
        done.append(f'Cl({p},{q}): S = R^({evenS}|{dimS - evenS})')
    row('bd·cat·23', ok,
        'a Lagrangian L of (V, i^w) gives the even idempotent P = prod_(l in basis) (1 + e_l)/2 and the graded module S = Cl P with Cl(p,q) = End(S) as superalgebras '
        '(2^n independent matrices, odd blades exchange S_0 and S_1): ' + ', '.join(done) + '; so [Cl(1,1)] = [Cl(8,0)] = 0 in the Brauer-Wall group, inside the labels')

if __name__ == '__main__':
    check12(); check13(); check14(); check15(); check23()
    verdict()
