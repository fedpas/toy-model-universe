#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjp_clock.py: the squares, the cell and its clock, read in the string and solid-state lenses against the weights and the inner product of
arXiv:2403.19689 (v3): conformal weights of lattice vertex operators on the labels, the bit-rule sign as a lattice cocycle, the clock of the
cells the paper's relations give, the Z_4 form w = pi + 2Q as an additive charge, and the paper's integer weights read mod 4.

    python3 selfcheck/bridges/mjp_clock.py              one line per check, ids bd·mjp·28 .. bd·mjp·32, and the info lines bd·mjp·39, bd·mjp·40;
                                                        exit 1 on any FAIL
    python3 selfcheck/bridges/mjp_clock.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library and numpy; exact Gaussian integers for the Gauss sums; random data from seeded generators; about 2 s on one core; reads and
writes no file; runs from any folder, also with python3 -I.
  bd·mjp·28  conformal weights: for the lattice Z^n and the label vectors alpha_a in {0,1}^n, h(alpha) = alpha.alpha/2 satisfies
             h(alpha_a + alpha_b) = h(alpha_a) + h(alpha_b) + |a AND b|, so h = |a|/2 is additive exactly on the disjoint pairs, the domain of the
             partial sum (n <= 6); with the simple roots of A_n (n = 2..6) as images of the generators it fails on some disjoint pairs; among 200
             random integer Gram matrices it is additive on every disjoint pair exactly for the diagonal ones (seed 28).  The line also counts
             200 random pairs of vectors of Z^4 whose fusion weight is additive and the orthogonal pairs among them: the two counts agree by the
             polarization identity (printed, not counted).
  bd·mjp·29  the bit-rule sign is a bimultiplicative cocycle on F_2^n (s(a + a', b) = s(a,b) s(a',b), s(a, b + b') = s(a,b) s(a,b') for XOR, every
             eps in {+1,-1}^n, n <= 5), equal to (-1)^{sum_{i>j} a_i b_j} for eps = +1, with commutator s(a,b) s(b,a) = (-1)^{alpha.beta + alpha^2 beta^2}
             (alpha.beta = |a AND b|, alpha^2 = |a|) for every eps: the condition (4.2) of the cocycle of the lattice vertex superalgebra V_Z^n
             (Bakalov-Kac, math/0402315, section 4.1); its square condition (4.1) eps(alpha,alpha) = (-1)^{k(k+1)/2} (k = |a|) holds exactly for all
             squares -1 (Cl(0,n)) and fails on the odd labels for all squares +1; 200 random sign tables (n = 3) are bimultiplicative in 0 (seed 29).
  bd·mjp·30  the cells of the paper's relations and their clocks (Brown invariant of w = pi + 2Q, exact Gauss sums): Cl(3,0) (Corollary 1),
             clock 3; Cl(2,0) (the plane Z0 of the arrows), clock 2; Cl(2,0,1) (e3 read as a null direction), clock 2 = that of the quotient
             Cl(2,0) and of the mother cell Cl(3,1) (w_D, bd·cat·3).  The paper's data do not move these: for 200 random categories (random posets,
             positions, weights) the Gram matrix of the inner product (10) is positive semidefinite of rank 2, signature (2,0), clock 2 (seed 30).
  bd·mjp·31  the Z_4 form is a charge: for eps in {+1,-1}^n, w(a) = sum_{i in a} eps_i mod 4 on every label, so w(a + b) = w(a) + w(b) on the
             disjoint pairs (the paper's (9) mod 4), while Q fails there by pi(a) pi(b); the Gauss sum is sum_a i^{w(a)} = prod_i (1 + i^{eps_i}),
             the grand partition function of bd·mjp·22 at fugacity i; with null bits (eps_i = 0) the same product is the Gauss sum of w_D,
             2^r (1+i)^p (1-i)^q (every eps in {+1,-1,0}^n, n <= 6), while w on all of V gives a null generator the charge 1 and is additive on
             the disjoint pairs in only 3 of the 90 cells with r >= 1 and n <= 4 (Cl(0,0,1) and the two orderings of Cl(0,1,1)); 200 random Z_4
             functions are additive on disjoint pairs in 0 (seed 31).
  bd·mjp·32  the paper's integer weights read mod 4: for integer generator weights q_i >= 1 (q in {1..8}^n, n <= 3, and 300 random q, n = 4, 5) the
             additive weight h_q(a) = sum_{i in a} q_i reduced mod 4 is the form w_D of a bit-rule cell exactly when no q_i = 2 mod 4, with
             e_i^2 = +1 for q_i = 1, -1 for q_i = 3, 0 for q_i = 0 mod 4; its Gauss sum gives the clock #{q = 1} - #{q = 3} mod 8.
  info bd·mjp·39  the K-theory row of the two clocks, read off bd·str·2 (Cl(0,k) <-> KO^{-k}(pt), clock -k): clock 2 sits at KO^{-6}(pt) = 0,
             clock 3 at KO^{-5}(pt) = 0.  A read-off, not a check.
  info bd·mjp·40  the Fidkowski-Kitaev row of Cl(2,0), read off bd·sol·2: two T-even Majoranas, c = 2: T^2 = +1, T anticommutes with the fermion
             parity.  Cl(3,0) has an odd number of Majoranas, outside the range (n even) of bd·sol·2.  A read-off, not a check.
"""
import sys, itertools
import numpy as np

SAB = '--sabotage' in sys.argv
ROWS, FAILS = [], []
def report(cid, ok, text, short):
    ROWS.append(cid)
    if SAB:
        print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  ' + short + '\n       the sabotaged run computes: ' + text)
        if ok: FAILS.append(cid)
    else:
        print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
        if not ok: FAILS.append(cid)
def info(cid, text):
    if not SAB: print('info ' + cid + '  ' + text)
def finish():
    if SAB:
        print('\n' + ('ALL CAUGHT' if not FAILS else f'{len(FAILS)} MISSED: ' + ' '.join(FAILS)))
    else:
        print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def Qf(a, eps): return 1 if sgn(a, a, eps) == -1 else 0
def w4(a, eps): return (pc(a) % 2 + 2 * Qf(a, eps)) % 4
def wD(a, eps):
    aD = a & sum(1 << i for i in range(len(eps)) if eps[i] != 0)
    return (pc(aD) % 2 + 2 * Qf(aD, eps)) % 4
IP = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def gsum(vals):
    re = im = 0
    for k in vals: re += IP[k % 4][0]; im += IP[k % 4][1]
    return (re, im)
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def phase8(z):
    from math import gcd
    re, im = z; g = gcd(abs(re), abs(im))
    if g == 0: return None
    rays = {(1, 0): 0, (1, 1): 1, (0, 1): 2, (-1, 1): 3, (-1, 0): 4, (-1, -1): 5, (0, -1): 6, (1, -1): 7}
    return rays.get((re // g, im // g))

def check28(sab):
    ok = True; dis_ok = True
    for n in range(1, 7):
        D = 1 << n
        for a in range(D):
            for b in range(D):
                al = np.array([(a >> i) & 1 for i in range(n)]); be = np.array([(b >> i) & 1 for i in range(n)])
                h = lambda x: x @ x / 2
                if sab: h = lambda x: np.abs(x).sum() ** 2 / 2   # sabotage: a weight that is the square of the l1 length (not a lattice form)
                additive = abs(h(al + be) - h(al) - h(be)) < 1e-12
                if additive != ((a & b) == 0): dis_ok = False
    ok &= dis_ok
    An_fail = []
    for n in range(2, 7):
        G = 2 * np.eye(n) - np.eye(n, k=1) - np.eye(n, k=-1)
        f = 0
        for a in range(1, 1 << n):
            for b in range(1, 1 << n):
                if a & b: continue
                x = np.array([(a >> i) & 1 for i in range(n)]); y = np.array([(b >> i) & 1 for i in range(n)])
                if abs((x + y) @ G @ (x + y) - x @ G @ x - y @ G @ y) > 1e-12: f += 1
        An_fail.append(f)
    ok &= all(f > 0 for f in An_fail)
    rng = np.random.default_rng(28); agree = 0; ndiag = 0
    for _ in range(200):
        n = 4
        M = rng.integers(-1, 2, size=(n, n)) * (rng.random((n, n)) < 0.25)
        G = np.diag(rng.integers(1, 4, size=n)).astype(int) + np.triu(M, 1) + np.triu(M, 1).T
        diag = not np.any(G - np.diag(np.diag(G)))
        ndiag += diag
        alladd = True
        for a in range(1, 16):
            for b in range(1, 16):
                if a & b: continue
                x = np.array([(a >> i) & 1 for i in range(n)]); y = np.array([(b >> i) & 1 for i in range(n)])
                if (x + y) @ G @ (x + y) != x @ G @ x + y @ G @ y: alladd = False
        agree += alladd == diag
    ok &= agree == 200 and 0 < ndiag < 200
    fus = orth = 0
    for _ in range(200):
        x = rng.integers(-2, 3, size=4); y = rng.integers(-2, 3, size=4)
        fus += (x + y) @ (x + y) == x @ x + y @ y; orth += x @ y == 0
    return ok, (f'Z^n, n = 1..6: h additive exactly on the disjoint pairs: {dis_ok}; A_n simple roots (n = 2..6): failing disjoint pairs {An_fail}; random Grams '
                f'(seed 28): additive on all disjoint pairs iff diagonal in {agree}/200 ({ndiag} diagonal); random Z^4 vectors: fusion additive in {fus}/200, '
                f'orthogonal pairs {orth} (equal by polarization, not counted)')

def check29(sab):
    ok = True; bim = comm = eq1 = True
    for n in range(1, 6):
        D = 1 << n
        for eps in itertools.product([1, -1], repeat=n):
            eps = list(eps)
            S = [[sgn(a, b, eps) for b in range(D)] for a in range(D)]
            if sab: S[1][1] = -S[1][1]                   # sabotage: one entry of the table flipped
            for a in range(D):
                for b in range(D):
                    if S[a][b] * S[b][a] != (-1) ** (pc(a & b) + pc(a) * pc(b)): comm = False
                    for c in (1, D - 1, (a * 7 + 3) % D):
                        if S[a ^ c][b] != S[a][b] * S[c][b] or S[a][b ^ c] != S[a][b] * S[a][c]: bim = False
            if all(e == 1 for e in eps):
                for a in range(D):
                    for b in range(D):
                        ex = sum(((a >> i) & 1) * ((b >> j) & 1) for i in range(n) for j in range(i))
                        if S[a][b] != (-1) ** ex: eq1 = False
    # Bakalov-Kac (4.1): eps(alpha, alpha) = (-1)^{|alpha|^2 (|alpha|^2 + 1)/2}; with |alpha|^2 = |a| on the labels
    bk_minus = all(sgn(a, a, [-1] * n) == (-1) ** (pc(a) * (pc(a) + 1) // 2) for n in range(1, 6) for a in range(1 << n))
    bk_plus_fail = sum(1 for a in range(1 << 5) if sgn(a, a, [1] * 5) != (-1) ** (pc(a) * (pc(a) + 1) // 2))
    rng = np.random.default_rng(29); rb = 0
    for _ in range(200):
        D = 8; T = rng.choice([-1, 1], size=(D, D))
        rb += all(T[a ^ c][b] == T[a][b] * T[c][b] and T[a][b ^ c] == T[a][b] * T[a][c] for a in range(D) for b in range(D) for c in range(D))
    ok = bim and comm and eq1 and rb == 0 and bk_minus and bk_plus_fail == 16
    return ok, (f'bit-rule sign, every eps in {{+1,-1}}^n, n = 1..5: bimultiplicative {bim}; commutator (-1)^(alpha.beta + alpha^2 beta^2) {comm}; for eps = +1 '
                f'equal to (-1)^(sum_(i>j) a_i b_j) {eq1}; the square condition eps(alpha,alpha) = (-1)^(k(k+1)/2), k = |a|: holds for all squares -1 '
                f'(Cl(0,n)) {bk_minus}, fails for all squares +1 on {bk_plus_fail} of the 32 labels at n = 5 (the odd ones); random sign tables bimultiplicative in {rb}/200')

def clock_of(eps, use_wD=False):
    n = len(eps)
    vals = [(wD(a, eps) if use_wD else w4(a, eps)) for a in range(1 << n)]
    return gsum(vals)
def check30(sab):
    cells = {'Cl(3,0)': [1, 1, 1], 'Cl(2,0)': [1, 1], 'Cl(2,0,1)': [1, 1, 0], 'Cl(3,1)': [1, 1, 1, -1]}
    if sab: cells['Cl(3,0)'] = [1, 1, -1]                # sabotage: one generator of square -1 (Cl(2,1))
    res = {}
    for name, eps in cells.items():
        z = clock_of(eps, use_wD=0 in eps)
        res[name] = (z, phase8(z))
    ok = res['Cl(3,0)'][1] == 3 and res['Cl(2,0)'][1] == 2 and res['Cl(2,0,1)'][1] == 2 and res['Cl(3,1)'][1] == 2 and \
         res['Cl(2,0,1)'][0] == (0, 4) and res['Cl(2,0)'][0] == (0, 2) and res['Cl(3,0)'][0] == (-2, 2)
    # the paper's inner product (10) on random categories: f.g = |f||g| cos(theta)
    rng = np.random.default_rng(30); sig_ok = 0
    for _ in range(200):
        m = int(rng.integers(3, 9))
        P = rng.normal(size=(m, 2))
        arrows = [(i, j) for i in range(m) for j in range(m) if i < j and rng.random() < 0.5] or [(0, 1), (1, 2)]
        Wt = {a: float(np.linalg.norm(P[a[1]] - P[a[0]]) * (1 + 2 * rng.random())) for a in arrows}
        U = np.array([(P[j] - P[i]) / np.linalg.norm(P[j] - P[i]) * Wt[(i, j)] for (i, j) in arrows])
        G = U @ U.T                                        # G_fg = |f||g| cos(theta_fg)
        ev = np.linalg.eigvalsh(G)
        pos = int(np.sum(ev > 1e-9)); neg = int(np.sum(ev < -1e-9))
        sig_ok += (pos, neg) == (2, 0) or (len(arrows) < 2 and (pos, neg) == (1, 0))
    ok &= sig_ok == 200
    return ok, ('; '.join(f'{k}: Gauss sum {v[0][0]}+{v[0][1]}i, clock {v[1]}' for k, v in res.items()) +
                f'; the inner product (10) on 200 random categories with random positions and weights (seed 30): signature (2,0) in {sig_ok}/200')

def check31(sab):
    ok = True; lin = add_w = gs = True; qfail = 0
    for n in range(1, 7):
        D = 1 << n
        for eps in itertools.product([1, -1, 0], repeat=n):
            eps = list(eps)
            nonnull = all(e != 0 for e in eps)
            wf = (lambda a: w4(a, eps)) if nonnull else (lambda a: wD(a, eps))
            if sab: wf = (lambda a: (pc(a) % 2 + 2 * Qf(a, eps)) % 4 if pc(a) != 2 else 1)   # sabotage: w altered on the two-bit labels
            for a in range(D):
                if nonnull and wf(a) != sum(eps[i] for i in range(n) if a >> i & 1) % 4: lin = False
            if n <= 4:
                for a in range(D):
                    for b in range(D):
                        if a & b: continue
                        if wf(a ^ b) != (wf(a) + wf(b)) % 4: add_w = False
                        if nonnull and Qf(a ^ b, eps) != (Qf(a, eps) + Qf(b, eps)) % 2: qfail += 1
            z = gsum([wf(a) for a in range(D)])
            prod = (1, 0)
            for e in eps: prod = gmul(prod, ((1, 0)[0] + IP[e % 4][0], IP[e % 4][1]))
            if z != prod: gs = False
    # with null bits, the form w = pi + 2Q on all of V (not w_D) gives a null generator the charge 1 and is not additive on disjoint labels
    wV_fail = 0; wV_cells = 0; wV_add = []
    for n in range(1, 5):
        for eps in itertools.product([1, -1, 0], repeat=n):
            eps = list(eps)
            if 0 not in eps: continue
            wV_cells += 1
            D = 1 << n
            if any((w4(a ^ b, eps) - w4(a, eps) - w4(b, eps)) % 4 for a in range(D) for b in range(D) if not a & b): wV_fail += 1
            else: wV_add.append(eps)
    rng = np.random.default_rng(31); ra = 0
    for _ in range(200):
        n = 4; f = list(rng.integers(0, 4, size=1 << n)); f[0] = 0
        ra += all(f[a ^ b] == (f[a] + f[b]) % 4 for a in range(16) for b in range(16) if not a & b)
    ok = lin and add_w and gs and qfail > 0 and ra == 0 and wV_add == [[0], [-1, 0], [0, -1]]
    return ok, (f'every eps in {{+1,-1,0}}^n, n <= 6: w(a) = sum eps_i mod 4 (eps non-zero) {lin}; w (w_D with null bits) additive on disjoint pairs (n <= 4) {add_w}; '
                f'Q additive there: fails on {qfail} pairs (the twist pi(a)pi(b)); Gauss sum = prod (1 + i^eps_i) {gs}; with null bits, w on all of V (not w_D) is '
                f'not additive on disjoint labels in {wV_fail}/{wV_cells} cells (n <= 4), additive only for eps = {wV_add}; random Z_4 functions additive in {ra}/200')

def check32(sab):
    ok = True; cnt = good = 0; bad = []
    rng = np.random.default_rng(32)
    qs = [q for n in range(1, 4) for q in itertools.product(range(1, 9), repeat=n)]
    qs += [tuple(int(x) for x in rng.integers(1, 13, size=int(rng.integers(4, 6)))) for _ in range(300)]
    for q in qs:
        n = len(q); cnt += 1
        valid = all(x % 4 != 2 for x in q)
        eps = [{1: 1, 3: -1, 0: 0, 2: None}[x % 4] for x in q]
        h = [sum(q[i] for i in range(n) if a >> i & 1) % 4 for a in range(1 << n)]
        if sab: h = [sum(q) % 4 if a else 0 for a in range(1 << n)]    # sabotage: the weight of the whole set at every non-zero label
        if valid:
            w = [wD(a, eps) for a in range(1 << n)]
            match = h == w
            z = gsum(h); c = phase8(z)
            pc_ = (sum(1 for x in q if x % 4 == 1) - sum(1 for x in q if x % 4 == 3)) % 8
            r = sum(1 for x in q if x % 4 == 0)
            if match and c == pc_ and abs(z[0]) + abs(z[1]) > 0: good += 1
            elif len(bad) < 3: bad.append(q)
        else:
            # some generator weight is 2 mod 4: h is the form w_D of no bit-rule cell on these generators (every eps in {+1,-1,0}^n tried)
            none = all(h != [wD(a, list(e)) for a in range(1 << n)] for e in itertools.product([1, -1, 0], repeat=n))
            if none: good += 1
            elif len(bad) < 3: bad.append(q)
    ok = good == cnt
    return ok, (f'{cnt} weight vectors q (all of {{1..8}}^n for n <= 3, 300 random for n = 4, 5; seed 32): h_q mod 4 = w_D of the cell with e_i^2 = +1, -1, 0 for '
                f'q_i = 1, 3, 0 mod 4 and clock #{{q=1}} - #{{q=3}} mod 8, or (some q_i = 2 mod 4) the form of no cell: {good}/{cnt}' + (f'; failures e.g. {bad}' if bad else ''))

CHECKS = [('bd·mjp·28', check28, 'conformal weight additive exactly on disjoint labels (Z^n)'),
          ('bd·mjp·29', check29, 'bit-rule sign = bimultiplicative lattice cocycle with the vertex-operator commutator'),
          ('bd·mjp·30', check30, 'clocks of Cl(3,0), Cl(2,0), Cl(2,0,1), Cl(3,1); the Gram of the inner product (10) is (2,0)'),
          ('bd·mjp·31', check31, 'w is a Z_4 charge; Gauss sum = partition function at fugacity i'),
          ('bd·mjp·32', check32, 'integer weights mod 4 are the forms of cells unless some q_i = 2 mod 4')]

def main():
    for cid, f, short in CHECKS:
        ok, text = f(SAB)
        report(cid, ok, text, short)
    info('bd·mjp·39', 'K-theory row (read off bd·str·2: Cl(0,k) <-> KO^{-k}(pt), clock -k mod 8): clock 2 (Cl(2,0) = clock of Cl(0,6)) sits at KO^{-6}(pt) = 0, '
         'clock 3 (Cl(3,0) = clock of Cl(0,5)) at KO^{-5}(pt) = 0; a read-off, not a check')
    info('bd·mjp·40', 'Fidkowski-Kitaev row (read off bd·sol·2): Cl(2,0) = two T-even Majoranas, c = 2: T^2 = +1, T anticommutes with the fermion parity; '
         'Cl(3,0) has three Majoranas, an odd number, outside the range (n even) of bd·sol·2; a read-off, not a check')
    finish()

if __name__ == '__main__':
    main()
