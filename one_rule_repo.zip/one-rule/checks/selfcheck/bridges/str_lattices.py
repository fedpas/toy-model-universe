#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""str_lattices.py: lattices, E8 two ways, del Pezzo surfaces and U-duality, seven qubits, Thurston's form.
Standard library only (exact integers and fractions; one float phase read with tolerance 1e-9).

  bd·str·15  E8 two ways: (bosonic) Construction A on Furey's Lagrangian (core·B11, the [8,4,4] code) gives an even unimodular lattice with
             240 vectors of norm 2 and 2160 of norm 4; (fermionic) D8 + (D8 + s) of core·B10c has the same counts.
  bd·str·16  one Z_8 for the clock and the lattices: for L = Z^n the Brown invariant of (L/2L, x.x mod 4) (= (V,w) of Cl(n,0)) and the
             Gauss-Milgram phase of the discriminant form of the even sublattice D_n (glue 0, v, s, c with q = 0, 1/2, n/8, n/8) are both
             n mod 8 (n = 1..24); the spinor glue has integer weight exactly when 8 | n.
  bd·str·17  del Pezzo: in I_{1,n} with K = -3H + sum E_i, K.K = 9 - n, the norm -2 vectors of K-perp are the E_n roots (8, 20, 40, 72, 126,
             240), and the exceptional classes (x.x = -1, K.x = -1) number 6, 10, 16, 27, 56, 240 for n = 3..8: the vertex counts of the
             Gosset polytopes (n-4)_21 of the shapes page (the 1/2-BPS charges of M-theory on T^n, Iqbal-Neitzke-Vafa).
  bd·str·18  seven qubits: in E8 with a root theta, the 56 roots with <r,theta> = 1 (T13) against 7 mutually orthogonal roots of E7 = theta-perp
             split as 7 x 8: each weight meets exactly 3 of the 7 roots, the 7 triples form a Fano plane (each pair of roots in one triple),
             8 = 2^3 weights per triple: 56 = 7 x (2,2,2) under SL(2)^7 (Duff-Ferrara).
  bd·str·19  Thurston's triangle-count form on Eisenstein 10-tuples (baez·T3): its polar form on Z[w]^10 = Z^20 is integral, even, of
             determinant 1 and signature (2,18): the lattice is II_{2,18} = U + U + E8 + E8, the heterotic E8 x E8 Narain lattice on T^2.

  python3 str_lattices.py      one line per check id; exit code 1 on any FAIL
deterministic; about ten seconds."""
import itertools, math, sys
from fractions import Fraction as F

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)
def pc(a): return bin(a).count('1')

def det(M):
    M = [[F(x) for x in r] for r in M]; d = F(1); N = len(M)
    for c in range(N):
        p = next((i for i in range(c, N) if M[i][c] != 0), None)
        if p is None: return F(0)
        if p != c: M[c], M[p] = M[p], M[c]; d = -d
        d *= M[c][c]
        for i in range(c + 1, N):
            f = M[i][c] / M[c][c]
            if f: M[i] = [x - f * y for x, y in zip(M[i], M[c])]
    return d

# ---------------------------------------------------------------- bd·str·15
def check15():
    lines = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
    gens = [sum(1 << (k - 1) for k in L) | (1 << 7) for L in lines]          # core·B11: Furey's Fano-line blades g_a g_b g_c g_8
    code = {0}
    for g in gens: code |= {c ^ g for c in code}
    # Construction A: x in Z^8 with x mod 2 in the code, norm x.x/2; count norms 2 and 4 (|x_i| <= 2 suffices for x.x <= 8)
    cnt = {2: 0, 4: 0}
    for x in itertools.product(range(-2, 3), repeat=8):
        nn = sum(t * t for t in x)
        if nn not in (4, 8): continue
        m = sum(1 << i for i in range(8) if x[i] % 2)
        if m in code: cnt[nn // 2] += 1
    even = all(pc(c) % 4 == 0 for c in code)
    # unimodular: [Z^8 : L] = 2^8 / |code| = 16, and the scale 1/2 on the form multiplies the covolume by 2^-4
    covol2 = F(2 ** 8, len(code)) ** 2 / F(2) ** 8
    # fermionic: D8 (integer, even sum) and D8 + (1/2)^8, norm x.x
    cntf = {2: 0, 4: 0}
    for x in itertools.product(range(-2, 3), repeat=8):
        nn = sum(t * t for t in x)
        if nn in (2, 4) and sum(x) % 2 == 0: cntf[nn] += 1
    for s in itertools.product((1, -1, 3, -3), repeat=8):                 # half-integer vectors with entries +-1/2, +-3/2 (norm <= 4)
        nn = F(sum(t * t for t in s), 4)
        if nn in (2, 4) and (sum(s) // 2) % 2 == 0 and sum(s) % 2 == 0: cntf[int(nn)] += 1
    ok = len(code) == 16 and even and covol2 == 1 and cnt == {2: 240, 4: 2160} and cntf == {2: 240, 4: 2160}
    row('bd·str·15', ok, f'E8 two ways: Construction A on the 16-word code spanned by Furey\'s Fano-line blades (core·B11) is even (doubly even code) and unimodular (covolume^2 = {covol2}), with {cnt[2]} vectors of norm 2 and {cnt[4]} of norm 4; the fermionic D8 + (D8 + s) of core·B10c has {cntf[2]} and {cntf[4]}: the bosonic (lattice) and fermionic (16 Majorana-Weyl fermions with a GSO projection) constructions of the E8 current algebra of the heterotic string')

# ---------------------------------------------------------------- bd·str·16
def check16():
    ok = True; rows = []
    for n in range(1, 25):
        # Brown invariant of (Z^n/2Z^n, x.x mod 4): the w of Cl(n,0) (core·B2); phase in eighths
        re = im = 0
        for a in range(1 << n) if n <= 14 else []:
            k = pc(a) % 4; re += (1, 0, -1, 0)[k]; im += (0, 1, 0, -1)[k]
        if n > 14:                                                          # binomial sum, exact
            re = sum(math.comb(n, j) * (1, 0, -1, 0)[j % 4] for j in range(n + 1)); im = sum(math.comb(n, j) * (0, 1, 0, -1)[j % 4] for j in range(n + 1))
        ph_brown = round(math.atan2(im, re) / (2 * math.pi) * 8) % 8
        # Gauss-Milgram of D_n: q(0) = 0, q(v) = 1/2, q(s) = q(c) = n/8 (mod 1)
        qs = [F(0), F(1, 2), F(n, 8), F(n, 8)]
        S = sum(complex(math.cos(2 * math.pi * float(q)), math.sin(2 * math.pi * float(q))) for q in qs)
        ph_milgram = round(math.atan2(S.imag, S.real) / (2 * math.pi) * 8) % 8
        if abs(abs(S) - 2) > 1e-9 or ph_brown != n % 8 or ph_milgram != n % 8: ok = False
        integral_s = (F(n, 8).denominator == 1)
        if integral_s != (n % 8 == 0): ok = False
        rows.append(n)
    row('bd·str·16', ok, 'for n = 1..24: the Brown phase of (Z^n/2Z^n, x.x mod 4) (the clock sum of Cl(n,0), core·B2-B3) and the Gauss-Milgram phase of the discriminant form of D_n (glue classes 0, v, s, c with q = 0, 1/2, n/8, n/8; |sum| = 2) are both n mod 8; the spinor class s (the demicube corners, length^2 n/4) has integer q = h_s = n/8 exactly when 8 | n (E8 at n = 8, D16+ at n = 16, Leech/Niemeier rank 24): one Z_8, the signature mod 8')

# ---------------------------------------------------------------- bd·str·17
def check17():
    ok = True; out = {}
    roots_want = {3: 8, 4: 20, 5: 40, 6: 72, 7: 126, 8: 240}
    exc_want = {3: 6, 4: 10, 5: 16, 6: 27, 7: 56, 8: 240}
    for n in range(3, 9):
        dot = lambda x, y: x[0] * y[0] - sum(a * b for a, b in zip(x[1:], y[1:]))
        K = (-3,) + (-1,) * n                                               # K = -3H + sum E_i, written as (a; b_i) with x = aH - sum b_i E_i
        if dot(K, K) != 9 - n: ok = False
        nr = ne = 0
        for a in range(0, 7):
            for b in itertools.product(range(-1, 4), repeat=n):
                x = (a,) + b
                xx = dot(x, x); kx = dot(K, x)
                if xx == -1 and kx == -1: ne += 1
        for a in range(-3, 4):
            for b in itertools.product(range(-2, 3), repeat=n):
                x = (a,) + b
                if dot(x, x) == -2 and dot(K, x) == 0: nr += 1
        out[n] = (nr, ne)
        if nr != roots_want[n] or ne != exc_want[n]: ok = False
    row('bd·str·17', ok, 'del Pezzo dP_n (I_{1,n}, K = -3H + sum E_i): K.K = 9 - n (the det of T10), the norm -2 vectors of K-perp number ' + ', '.join(f'{out[n][0]}' for n in out) + ' (E3..E8 roots), the exceptional classes (x.x = -1 = K.x) number ' + ', '.join(f'{out[n][1]}' for n in out) + ' for n = 3..8 = the vertices of -1_21, 0_21, 1_21 (5-demicube), 2_21, 3_21, 4_21 (shapes and Gosset pages): the minimal (1/2-BPS) charges of M-theory on T^n under E_n U-duality')

# ---------------------------------------------------------------- bd·str·18
def e8_roots():
    R = []
    for i in range(8):
        for j in range(i + 1, 8):
            for s1 in (2, -2):
                for s2 in (2, -2):
                    v = [0] * 8; v[i] = s1; v[j] = s2; R.append(tuple(v))       # doubled coordinates: inner product /4
    for s in itertools.product((1, -1), repeat=8):
        if s.count(-1) % 2 == 0: R.append(s)
    return R
def ip(x, y): return F(sum(a * b for a, b in zip(x, y)), 4)
def check18():
    R = e8_roots(); th = R[0]
    E7 = [r for r in R if ip(r, th) == 0]; W56 = [r for r in R if ip(r, th) == 1]
    ok = len(R) == 240 and len(E7) == 126 and len(W56) == 56
    # 7 mutually orthogonal roots of E7 (backtracking)
    best = []
    def bt(start, cur):
        nonlocal best
        if len(cur) == 7: best = cur[:]; return True
        for k in range(start, len(E7)):
            r = E7[k]
            if all(ip(r, c) == 0 for c in cur):
                cur.append(r)
                if bt(k + 1, cur): return True
                cur.pop()
        return False
    bt(0, [])
    ok = ok and len(best) == 7
    supp = {}
    for w in W56:
        vals = [ip(w, a) for a in best]
        if any(v not in (-1, 0, 1) for v in vals): ok = False
        key = tuple(i for i, v in enumerate(vals) if v != 0)
        supp.setdefault(key, []).append(w)
    triples = sorted(supp)
    fano = len(triples) == 7 and all(len(t) == 3 for t in triples) and all(len(v) == 8 for v in supp.values())
    pairs_ok = all(sum(1 for t in triples if i in t and j in t) == 1 for i in range(7) for j in range(i + 1, 7))
    ok = ok and fano and pairs_ok
    row('bd·str·18', ok, f'E8 ⊃ E7 x A1: 240 = 126 + 56 + 56 + 2 around a root theta; 7 mutually orthogonal roots of E7 found; each of the 56 weights has inner product +-1 with exactly 3 of them and 0 with the other 4, the 7 triples {triples} each carry 8 = 2^3 weights and every pair of the 7 roots lies in exactly one triple: a Fano plane, 56 = 7 x (2,2,2) under SL(2)^7 (the seven-qubit picture of the 4d N = 8 black-hole charges)')

# ---------------------------------------------------------------- bd·str·19
def check19():
    sq3 = math.sqrt(3.0)
    def Qform(v):
        v = list(v) + [-sum(v)]; z = [0j]
        for t in range(11): z.append(z[-1] + v[t])
        area = 0.5 * sum((z[t].conjugate() * z[t + 1]).imag for t in range(11))
        return 4 / sq3 * area - sum(abs(t) ** 2 for t in v)
    om = complex(-0.5, sq3 / 2)
    basis = []
    for j in range(10):
        for u in (1, om):
            v = [0j] * 10; v[j] = u; basis.append(v)
    n = 20; B = [[0] * n for _ in range(n)]; integral = True
    for i in range(n):
        for k in range(n):
            if i == k: val = Qform(basis[i])
            else: val = (Qform([x + y for x, y in zip(basis[i], basis[k])]) - Qform(basis[i]) - Qform(basis[k])) / 2
            r = round(val)
            if abs(val - r) > 1e-9: integral = False
            B[i][k] = r
    even = all(B[i][i] % 2 == 0 for i in range(n))
    d = det(B)
    # signature by exact congruence diagonalisation (Sylvester) on the integer matrix
    A = [[F(x) for x in r] for r in B]; pos = neg = 0; act = list(range(n))
    while act:
        pv = next((i for i in act if A[i][i] != 0), None)
        if pv is None:
            pr = next(((i, j) for i in act for j in act if i < j and A[i][j] != 0), None)
            if pr is None: break
            i, j = pr
            for k in range(n): A[i][k] += A[j][k]
            for k in range(n): A[k][i] += A[k][j]
            pv = i
        dd = A[pv][pv]
        if dd > 0: pos += 1
        else: neg += 1
        for i in act:
            if i != pv and A[i][pv] != 0:
                f = A[i][pv] / dd
                for k in range(n): A[i][k] -= f * A[pv][k]
                for k in range(n): A[k][i] -= f * A[k][pv]
        act.remove(pv)
    ok = integral and even and abs(d) == 1 and (pos, neg) == (2, 18)
    row('bd·str·19', ok, f'Thurston\'s triangle count T(v) on Eisenstein 10-tuples (the form of baez·T3): its polar form on the Z-basis {{1, w}} of Z[w]^10 is integral ({integral}), even (diagonal entries {sorted(set(B[i][i] for i in range(n)))}), of determinant {d} and signature ({pos},{neg}): an even unimodular lattice of signature (2,18), hence II_{{2,18}} = U + U + E8 + E8 (uniqueness of indefinite even unimodular lattices, standard); the number of triangles is always even (2V - 4)')

if __name__ == '__main__':
    check15(); check16(); check17(); check18(); check19()
    finish()
