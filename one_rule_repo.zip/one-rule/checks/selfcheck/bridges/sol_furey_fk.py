#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sol_furey_fk.py: Furey's 16-dimensional V read as the Fock space of 8 Majorana edge modes, and her seven Fano-line blades (the explicit
Cl(0,8) = End_R(V) of witt_test.py) read as Fidkowski-Kitaev quartic couplings.

  bd·sol·10  the 7 line blades of the explicit Furey model are diagonal, commute and square to +1; for every sign choice s in {+1,-1}^7 the
             energy E_s(axis) = -sum_l s_l diag(A_l)[axis] is computed on the 16 coordinate axes: the 16 axis patterns form a translate of
             the perfect Hamming [7,4,3] code, so all 128 sign choices have a unique ground state (level shapes (1,7,7,1) for 16 of them,
             (1,3,4,4,3,1) for 112); with her own orientation (all s = +1) the minimum is -5; and for no sign choice does every one of her six
             blocks (O1, O2, H, C, e7R, R; sizes 2, 6, 4, 2, 1, 1) lie inside one level, nor every level inside one block.

The octonion product is that of the package's model.py, copied below line for line, so that the script reads no file outside its folder.
  python3 sol_furey_fk.py      one line per check id; exit code 1 on any FAIL
numpy and the standard library; deterministic; under a second."""
import sys, itertools
import numpy as np

# ---- the octonion model of model.py (these lines are those of model.py): quaternions (basis 1,i,j,k) and octonions by Cayley-Dickson,
# (a,b)(c,d) = (ac - conj(d) b, d a + b conj(c)); index 0:1 1:i 2:j 3:k 4:l 5:li 6:lj 7:lk
def qmul(p,q):
    a1,b1,c1,d1=p; a2,b2,c2,d2=q
    return np.array([a1*a2-b1*b2-c1*c2-d1*d2, a1*b2+b1*a2+c1*d2-d1*c2, a1*c2-b1*d2+c1*a2+d1*b2, a1*d2+b1*c2-c1*b2+d1*a2])
def qconj(p): return np.array([p[0],-p[1],-p[2],-p[3]])
def omul(x,y):
    a,b=x[:4],x[4:]; c,d=y[:4],y[4:]
    return np.concatenate([qmul(a,c)-qmul(qconj(d),b), qmul(d,a)+qmul(b,qconj(c))])
E=np.eye(8)
def Lmat(x): return np.array([omul(x,E[m]) for m in range(8)]).T
I8=np.eye(8); I16=np.eye(16)
def blk(A,B,C,D): return np.block([[A,B],[C,D]])
Z=np.zeros((8,8))

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

units = [E[m] for m in range(1, 8)]
g = [blk(Z, Lmat(u), Lmat(u), Z) for u in units] + [blk(Z, I8, -I8, Z)]
def blade(S):
    M = I16.copy()
    for a in S: M = M @ g[a]
    return M
lines = []
for a in range(7):
    for b in range(a + 1, 7):
        p = omul(units[a], units[b]); c = int(np.argmax(abs(p))) - 1
        if c > b: lines.append((a, b, c))
A = [blade(tuple(sorted(l + (7,)))) for l in lines]
D = np.array([np.diag(M) for M in A])                                   # 7 x 16 table of +-1
blocks = {'O1': [0, 3], 'O2': [1, 2, 4, 5, 6, 7], 'H': [12, 13, 14, 15], 'C': [9, 10], 'e7R': [11], 'R': [8]}
blk_of = {i: n for n, ix in blocks.items() for i in ix}

def main():
    diag_ok = all(np.allclose(M, np.diag(np.diag(M))) for M in A) and all(np.allclose(M @ M, I16) for M in A) and \
        all(np.allclose(M @ N, N @ M) for M in A for N in A)
    pats = [tuple(int(x) for x in D[:, i]) for i in range(16)]            # the sign pattern of the 7 line blades on each axis
    bits = [tuple((1 - x) // 2 for x in pt) for pt in pats]
    xor = lambda u, v: tuple(x ^ y for x, y in zip(u, v))
    shifted = {xor(b_, bits[0]) for b_ in bits}                           # translate so that axis 0 is the origin
    linear = all(xor(u, v) in shifted for u in shifted for v in shifted)
    dmin = min(sum(xor(u, v)) for u in bits for v in bits if u != v)
    perfect = len(set(bits)) == 16 and dmin == 3 and 16 * (1 + 7) == 2 ** 7
    unique = 0; shapes = {}; refine = 0; coarsen = 0
    for s in itertools.product((1, -1), repeat=7):
        lv = np.round(-np.array(s) @ D, 9); levels = sorted(set(lv))
        if int(np.sum(lv == levels[0])) == 1: unique += 1
        sh = tuple(int(np.sum(lv == L)) for L in levels); shapes[sh] = shapes.get(sh, 0) + 1
        if all(len({lv[i] for i in ix}) == 1 for ix in blocks.values()): refine += 1
        if all(len({blk_of[i] for i in range(16) if lv[i] == L}) == 1 for L in levels): coarsen += 1
    own = -np.ones(7) @ D
    own_gs = [i for i in range(16) if abs(own[i] - own.min()) < 1e-9]
    own_levels = {k: sorted(int(x) for x in set(np.round(own[ix], 6))) for k, ix in blocks.items()}
    ok = (diag_ok and linear and perfect and unique == 128 and shapes == {(1, 7, 7, 1): 16, (1, 3, 4, 4, 3, 1): 112}
          and own.min() == -5 and refine == 0 and coarsen == 0)
    row('bd·sol·10', ok,
        f'the explicit Furey model (the construction of witt_test.py): the 7 line blades are diagonal, commute, square to +1; the sign patterns of the 16 axes form a '
        f'translate of a linear code (linear: {linear}) with minimum distance {dmin}: the perfect Hamming [7,4,3] code; hence every one of the 128 '
        f'sign choices of an FK interaction -sum s_l A_l has a unique ground state (counted: {unique}), level shapes {shapes}; with her own '
        f'orientation (all s = +1) the minimum is {int(own.min())} (not -7: her line orientation is not a character of the code group) on axis '
        f'{own_gs} (block {[blk_of[i] for i in own_gs]}); energies per block {own_levels}; sign choices whose levels contain her blocks: {refine}; '
        f'whose levels lie inside her blocks: {coarsen}')

if __name__ == '__main__':
    main()
    finish()
