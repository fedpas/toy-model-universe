#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sol_maxwell_media.py: Calibration 1 (Maxwell) read with the constitutive relation of a medium.

Premetric form: dF = 0 and d H = J with H = chi(F); in components d_b (chi^{abcd} d_c A_d) = J^a, chi antisymmetric in ab and in cd.
  bd·sol·14  counting and the axion: the chi's antisymmetric in (ab) and (cd) form a 36-dimensional space = 21 (pair-symmetric: the area metric
             of Schuller's general linear electrodynamics, LNS-013) + 15 (pair-antisymmetric: skewon); inside the 21 the totally antisymmetric
             part (axion, the 'epsilon part' of LNS-013) is 1-dimensional and the cyclic-free part 20.  The axion part gives the wave operator
             M^{ad}(k) = chi^{abcd} k_b k_c identically 0 (and eps^{abcd} d_b d_c = 0 on any field): a constant theta is invisible to every bulk
             wave and acts only through d theta (interfaces).  For the vacuum chi of eta = diag(+,-,-,-) the Fresnel polynomial (from
             adj M = W(k) k k^T) is +-(eta^-1(k,k))^2 (20 random k).
  bd·sol·15  a uniaxial medium (eps = diag(e_perp, e_perp, e_par), mu = 1): det(omega^2 eps + k k^T - |k|^2 1) = omega^2 e_par x (ordinary
             quadric) x (extraordinary quadric); the extraordinary quadric P_e = -omega^2 + k_perp^2/e_par + k_z^2/e_perp has signature (1,3)
             for (e_perp, e_par) = (+,+), (2,2) for (-,+), (3,1) with the odd direction z for (+,-), definite for (-,-).  With the
             hyperbolicity test of T18 (f) (LNS-012; 4000 random covectors and the axes): hyperbolic with respect to dt only in (+,+), with
             respect to dz only in (+,-), with respect to neither in (-,+) [the 'two times' (2,2) of Smolyaninov-Narimanov] and (-,-).
  bd·sol·16  dispersion decides: with a Drude axis e_par(omega) = 1 - omega_p^2/omega^2 (omega_p = 1, e_perp = 2.25) the extraordinary
             iso-frequency surface is a hyperboloid for omega < omega_p and an ellipsoid above (seven frequencies); as omega -> infinity
             eps -> 1 and P_e -> the vacuum (1,3) form, hyperbolic in t.  The principal symbol of the time-domain equations is the
             omega -> infinity limit, so a causal medium is hyperbolic in t (T18), and the (2,2) or z-time signatures live in the dispersion
             relation at fixed omega (measurable as iso-frequency surfaces), not in the principal symbol.
  bd·sol·17  the relative sign between the source term and the force law is decided by energy conservation with a positive field energy:
             with the textbook signs (dE/dt = curl B - J, dB/dt = -curl E, force density rho E + J x B, u = (E^2 + B^2)/2)
             du/dt + div(E x B) + J.E = 0 (the work J.E done on the charges balances); with the source sign flipped the balance is 2 J.E
             (200 random linear fields, exact rationals).  One datum fixes the relative sign: the positivity of the field energy.

  python3 sol_maxwell_media.py      one line per check id; exit code 1 on any FAIL
numpy, fractions and the standard library; deterministic; under a second."""
import itertools, sys
from fractions import Fraction as Fr
import numpy as np

ROWS, FAILS = [], []
def row(i, ok, text):
    ROWS.append(i)
    print(('ok   ' if ok else 'FAIL ') + i + '  ' + text)
    if not ok: FAILS.append(i)
def info(i, text):
    print('info ' + i + '  ' + text)
def finish():
    print(f'\n{len(ROWS) - len(FAILS)}/{len(ROWS)} bridge checks hold.' + ('  ALL BRIDGE CHECKS PASS' if not FAILS else '  FAILED: ' + ' '.join(FAILS)))
    sys.exit(1 if FAILS else 0)

def levi4():
    E = np.zeros((4, 4, 4, 4))
    for p in itertools.permutations(range(4)):
        inv = sum(1 for i in range(4) for j in range(i + 1, 4) if p[i] > p[j])
        E[p] = (-1) ** inv
    return E
EPS = levi4()
PAIRS = [(a, b) for a in range(4) for b in range(a + 1, 4)]

def chi_from_matrix(Mx):
    """6x6 matrix on the pairs (a<b) -> chi^{abcd}, antisymmetric in ab and cd"""
    chi = np.zeros((4, 4, 4, 4))
    for I, (a, b) in enumerate(PAIRS):
        for J, (c, d) in enumerate(PAIRS):
            v = Mx[I, J]
            chi[a, b, c, d] = v; chi[b, a, c, d] = -v; chi[a, b, d, c] = -v; chi[b, a, d, c] = v
    return chi
def wave_op(chi, k): return np.einsum('abcd,b,c->ad', chi, k, k)
def adjugate(M):
    n = M.shape[0]; A = np.zeros_like(M)
    for i in range(n):
        for j in range(n):
            minor = np.delete(np.delete(M, i, 0), j, 1)
            A[j, i] = (-1) ** (i + j) * np.linalg.det(minor)
    return A

# ================================================================ 14: counting, axion, vacuum Fresnel
def check14():
    # basis of the 36-dim space as 6x6 matrices; symmetric 21, antisymmetric 15
    basis = []
    for I in range(6):
        for J in range(6):
            Mx = np.zeros((6, 6)); Mx[I, J] = 1; basis.append(chi_from_matrix(Mx))
    V = np.array([c.flatten() for c in basis]); dim36 = np.linalg.matrix_rank(V)
    sym = [chi_from_matrix((np.eye(6)[I][:, None] * np.eye(6)[J][None, :] + np.eye(6)[J][:, None] * np.eye(6)[I][None, :])) for I in range(6) for J in range(I, 6)]
    dim21 = np.linalg.matrix_rank(np.array([c.flatten() for c in sym]))
    ant = [chi_from_matrix((np.eye(6)[I][:, None] * np.eye(6)[J][None, :] - np.eye(6)[J][:, None] * np.eye(6)[I][None, :])) for I in range(6) for J in range(I + 1, 6)]
    dim15 = np.linalg.matrix_rank(np.array([c.flatten() for c in ant]))
    # totally antisymmetric part inside the symmetric 21: project each sym basis element on eps
    tot = [c for c in sym]
    proj = np.array([[np.sum(c * EPS)] for c in tot]); dim_ax = np.linalg.matrix_rank(proj)
    # cyclic identity chi^{a[bcd]} = 0 cuts the 21 to 20
    def cyc(c): return c + np.einsum('abcd->acdb', c) + np.einsum('abcd->adbc', c)
    C = np.array([cyc(c).flatten() for c in sym]); dim20 = len(sym) - np.linalg.matrix_rank(C)
    # axion: wave operator identically zero
    rng = np.random.default_rng(14)
    ax_zero = all(np.allclose(wave_op(EPS, rng.normal(size=4)), 0) for _ in range(20))
    Hs = rng.normal(size=(4, 4)); Hs = Hs + Hs.T; ax_zero &= np.allclose(np.einsum('abcd,bc->ad', EPS, Hs), 0)
    # vacuum: chi^{abcd} = eta^{ac} eta^{bd} - eta^{ad} eta^{bc}
    eta = np.diag([1., -1, -1, -1])
    chiv = np.einsum('ac,bd->abcd', eta, eta) - np.einsum('ad,bc->abcd', eta, eta)
    okv = True
    for _ in range(20):
        k = rng.normal(size=4); M = wave_op(chiv, k); A = adjugate(M)
        kk = k @ eta @ k                                            # eta^-1 = eta here
        # M k = 0 (gauge: the covector k is in the kernel), so adj M = W k k^T with W the Fresnel polynomial; W proportional to kk^2
        ku = k; W = A[0, 0] / (ku[0] * ku[0])
        okv &= bool(np.allclose(A, W * np.outer(ku, ku), atol=1e-8 * max(1, abs(W)))) and (abs(W / kk ** 2 + 1.0) < 1e-8 or abs(W / kk ** 2 - 1.0) < 1e-8)
    ok = dim36 == 36 and dim21 == 21 and dim15 == 15 and dim_ax == 1 and dim20 == 20 and ax_zero and okv
    row('bd·sol·14', ok, f'constitutive tensors: {dim36} = {dim21} (area metric, pair-symmetric) + {dim15} (skewon); inside the 21: axion {dim_ax}, cyclic-free (principal) {dim20}; the axion part gives the wave operator chi^abcd k_b k_c = 0 identically (theta acts only through its gradient); vacuum Fresnel W(k) = +-(eta(k,k))^2')

# ================================================================ 15: uniaxial and hyperbolic media against T18
def ext_form(ep, ez):
    """P_e(omega, kx, ky, kz) = -omega^2 + (kx^2 + ky^2)/ez + kz^2/ep as a 4x4 diagonal form"""
    return np.diag([-1.0, 1 / ez, 1 / ez, 1 / ep])
def signature(G):
    w = np.linalg.eigvalsh(G); return (int(np.sum(w > 1e-12)), int(np.sum(w < -1e-12)))
def hyperbolic_wrt(G, h, trials=4000, seed=15):
    """the hyperbolicity test of T18 (f) (LNS-012): P(h) != 0 and B(q,h)^2 - P(h) P(q) >= 0 for all q, with P(q) = q G q (G the matrix of the principal polynomial on covectors)"""
    Ph = h @ G @ h
    if abs(Ph) < 1e-12: return False
    rng = np.random.default_rng(seed)
    for _ in range(trials):
        q = rng.normal(size=4)
        if (q @ G @ h) ** 2 - Ph * (q @ G @ q) < -1e-9: return False
    # also the eigen-directions
    for q in np.eye(4):
        if (q @ G @ h) ** 2 - Ph * (q @ G @ q) < -1e-9: return False
    return True
def fresnel_factor_check(ep, ez, rng):
    ok = True
    epsm = np.diag([ep, ep, ez])
    for _ in range(10):
        om = rng.normal(); k = rng.normal(size=3)
        Mw = om ** 2 * epsm + np.outer(k, k) - (k @ k) * np.eye(3)
        lhs = np.linalg.det(Mw)
        Po = ep * om ** 2 - k @ k                                         # ordinary: k^2 = e_perp omega^2
        Pe = om ** 2 - (k[0] ** 2 + k[1] ** 2) / ez - k[2] ** 2 / ep      # extraordinary
        rhs = om ** 2 * ez * Po * Pe * ep / 1.0
        ok &= abs(lhs - rhs) < 1e-8 * max(1, abs(lhs))
    return ok
def check15():
    rng = np.random.default_rng(150); ok = True; table = []
    dt = np.array([1.0, 0, 0, 0]); dz = np.array([0, 0, 0, 1.0])
    expect = {(1, 1): ((1, 3), True, False), (-1, 1): ((2, 2), False, False), (1, -1): ((3, 1), False, True), (-1, -1): ((4, 0), False, False)}
    for (sp, sz), (sig_exp, hyp_t, hyp_z) in expect.items():
        ep, ez = 2.0 * sp, 3.0 * sz
        ok &= fresnel_factor_check(ep, ez, rng)
        G = ext_form(ep, ez); s = signature(G)
        s_norm = s if s in ((1, 3), (2, 2)) else s                         # report (positive, negative) counts
        ht, hz = hyperbolic_wrt(G, dt), hyperbolic_wrt(G, dz)
        # (positive, negative) counts: (+,+) -> (3,1) as (pos, neg) with -omega^2 the single negative
        pos, neg = s
        sig_pq = (neg, pos) if True else s                                 # as (number of minus, number of plus): (1,3) means one minus
        if sig_pq != sig_exp or ht != hyp_t or hz != hyp_z: ok = False
        table.append(f'(e_perp,e_par)=({ep:+.0f},{ez:+.0f}): (minus,plus) = {sig_pq}, hyperbolic in t: {ht}, in z: {hz}')
    row('bd·sol·15', ok, 'uniaxial medium: the Fresnel determinant factors as omega^2 e_par e_perp x ordinary x extraordinary; extraordinary form: ' + '; '.join(table))

# ================================================================ 16: Drude dispersion
def check16():
    wp = 1.0; ep = 2.25; lines = []; ok = True
    for om in (0.3, 0.7, 0.99, 1.01, 2.0, 10.0, 1e3):
        ez = 1 - wp ** 2 / om ** 2
        spatial = np.diag([1 / ez, 1 / ez, 1 / ep])                       # iso-frequency surface k_perp^2/e_par + k_z^2/e_perp = omega^2
        s = signature(spatial)
        kind = 'hyperboloid' if min(s) > 0 else ('ellipsoid' if s[0] == 3 else 'none')
        lines.append(f'omega={om:g}: {kind}')
        if (om < wp) != (kind == 'hyperboloid'): ok = False
    G_inf = ext_form(ep, 1 - wp ** 2 / 1e6 ** 2)
    hyp_inf = hyperbolic_wrt(np.diag([-1.0, 1.0, 1.0, 1 / ep]), np.array([1.0, 0, 0, 0]))
    # principal symbol at omega -> infinity: eps -> 1, the vacuum form, hyperbolic in t
    G_vac = np.diag([-1.0, 1, 1, 1])
    ok &= hyperbolic_wrt(G_vac, np.array([1.0, 0, 0, 0])) and np.allclose(ext_form(1.0, 1.0), G_vac)
    row('bd·sol·16', ok, 'Drude axis e_par = 1 - omega_p^2/omega^2, e_perp = 2.25: ' + ', '.join(lines) + '; omega -> infinity gives eps -> 1 and the vacuum (1,3) principal symbol, hyperbolic in t')

# ================================================================ 17: Poynting fixes the relative sign of source and force
def check17():
    import random
    rnd = random.Random(17); ok_plus = ok_minus = True
    def r(): return Fr(rnd.randint(-9, 9), rnd.randint(1, 4))
    for _ in range(200):
        E0 = [r() for _ in range(3)]; B0 = [r() for _ in range(3)]
        A = [[r() for _ in range(3)] for _ in range(3)]; C = [[r() for _ in range(3)] for _ in range(3)]   # E = E0 + A x, B = B0 + C x at x = 0
        J = [r() for _ in range(3)]
        curl = lambda M: [M[2][1] - M[1][2], M[0][2] - M[2][0], M[1][0] - M[0][1]]          # (curl F)_i from the Jacobian M[i][j] = d_j F_i
        cE, cB = curl(A), curl(C)
        # div(E x B) = B.curl E - E.curl B at x = 0
        divS = sum(B0[i] * cE[i] for i in range(3)) - sum(E0[i] * cB[i] for i in range(3))
        JE = sum(J[i] * E0[i] for i in range(3))
        for s, flag in ((1, 'plus'), (-1, 'minus')):
            dE = [cB[i] - s * J[i] for i in range(3)]; dB = [-cE[i] for i in range(3)]
            du = sum(E0[i] * dE[i] for i in range(3)) + sum(B0[i] * dB[i] for i in range(3))
            balance = du + divS + JE                                        # field energy change + flux + work done on charges
            if s == 1 and balance != 0: ok_plus = False
            if s == -1 and balance != 2 * JE: ok_minus = False
    row('bd·sol·17', ok_plus and ok_minus, 'Poynting: with dE/dt = curl B - J and the force rho E + J x B, du/dt + div S + J.E = 0 exactly (200 random linear fields, exact rationals); with the source sign flipped the balance is 2 J.E: the relative sign of source and force is fixed by energy conservation with u = (E^2 + B^2)/2 > 0')

if __name__ == '__main__':
    for f in (check14, check15, check16, check17): f()
    finish()
