#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
r"""mja_semiring.py: semiring against ring.  arXiv:2403.19689 (v3) works over (R, 0, +, 1, x) as a semiring with positive scalars only
(Def. 2 (4), Def. 3); which products of the bit rule are definable without additive inverses, in which basis, and what the sign-free algebras
on the labels are.

    python3 selfcheck/bridges/mja_semiring.py              one line per check, ids bd·mja·26 .. bd·mja·28; exit 1 on any FAIL
    python3 selfcheck/bridges/mja_semiring.py --sabotage   every check runs on a deliberately broken input and must print CAUGHT

Standard library (exact integers and fractions) and numpy (float linear solves for the random bases of bd·mja·28 only); deterministic
(seed 7); about 2 s; runs from any folder, reads and writes no file.
  bd·mja·26  in the label basis the bit-rule table has a negative constant for every eps in {+1,-1,0}^n with n >= 2, and for n = 1 exactly when
             eps = -1 (n <= 5); none of the 2^(2^n - 1) sign gauges e_a -> +-e_a (n = 2, 3, every eps) gives a table without a negative entry,
             and positive rescalings keep every sign: no Clifford cell with n >= 2 has non-negative structure constants in a basis of rescaled
             blades.  That a gauge leaves the ratio s(a,b) s(b,a) unchanged is a remark (the gauge enters squared), not tested.  The disjoint (exterior) part has (3^n + x_n)/2 non-negative constants of 3^n, with the signed sum
             x_n = sum of s(a,b) over disjoint pairs = 1, 3, 7, 17, 41, 99, 239 obeying x_n = 2 x_(n-1) + x_(n-2) (n <= 6).
  bd·mja·27  the sign-free algebras on the labels (structure constants 0 and 1): the unsigned rule with non-null squares is the group algebra of
             F_2^n (commutative, trace form non-degenerate: semisimple, 2^n characters), with null squares the contracted monoid algebra of the
             disjoint union R_0[M] = R[x_1..x_n]/(x_i^2) (commutative, local, radical 2^n - 1); Lambda(R^n) has the same radical but is not
             commutative for n >= 2 (its commutator space [A,A] has dimension 2^(n-1) - 1, n <= 4), so R_0[M] and Lambda are not isomorphic for n >= 2;
             dropping signs is not multiplicative over R (it is mod 2, where -1 = 1: a remark); over the Boolean semiring ({0,1}, or, and) the unsigned tables and the
             incidence relation of B_n are associative (n <= 4).
  bd·mja·28  bases with non-negative structure constants: the neutral cell Cl(n,n) = M_{2^n}(R) has one (the matrix units E_{T,S} of bd·mja·10,
             products 0 or one unit, by their definition), and the units with S subset T (the incidence algebra of B_n) are closed under products; Cl(1,0) = R + R has one (its two
             idempotents (1 +- e)/2); for C = Cl(0,1) none of 20000 and for H = Cl(0,2) none of 5000 random bases (seed 7) has non-negative
             constants.
"""
import itertools, random, sys
from math import comb

SABOTAGE = '--sabotage' in sys.argv
ROWS = []
def row(cid, ok, text):
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def alleps(n): return [list(e) for e in itertools.product((1, -1, 0), repeat=n)]

def chk26(sab):
    ok = True; neg = {}
    for n in range(0, 6):
        for e in alleps(n):
            N = 1 << n
            rule = sgn if not (sab and n == 2) else (lambda a, b, e: 0 if any(e[i] == 0 for i in range(n) if a >> i & b >> i & 1) else
                                                   (-1) ** sum(1 for i in range(n) if a >> i & b >> i & 1 and e[i] == -1))   # sabotage: reordering sign dropped
            has_neg = any(rule(a, b, e) < 0 for a in range(N) for b in range(N))
            want = n >= 2 or (n == 1 and e[0] == -1)
            if has_neg != want: ok = False
        neg[n] = sum(1 for a in range(1 << n) for b in range(1 << n) if sgn(a, b, [1] * n) < 0)
    # gauge invariance of the commutation ratio, and no gauge removes all negative entries
    gauge_free = 0
    for n in range(2, 4):
        N = 1 << n
        for e in alleps(n):
            base = [[sgn(a, b, e) for b in range(N)] for a in range(N)]
            for bits in range(1 << (N - 1)):
                f = [1] + [(-1 if bits >> (k - 1) & 1 else 1) for k in range(1, N)]
                t = [[base[a][b] * f[a] * f[b] * f[a ^ b] for b in range(N)] for a in range(N)]
                if all(t[a][b] >= 0 for a in range(N) for b in range(N)): gauge_free += 1
    if gauge_free: ok = False
    disj = {}; xs = []
    for n in range(0, 7):
        N = 1 << n
        nn = sum(1 for a in range(N) for b in range(N) if a & b == 0 and sgn(a, b, [0] * n) > 0)
        x = sum(sgn(a, b, [0] * n) for a in range(N) for b in range(N) if a & b == 0)
        disj[n] = nn; xs.append(x)
        if 2 * nn != 3 ** n + x: ok = False
    if xs[:2] != [1, 3] or any(xs[k] != 2 * xs[k - 1] + xs[k - 2] for k in range(2, 7)): ok = False
    return ok, ('label basis: a negative constant for every eps with n >= 2 and for eps = -1 at n = 1 (n <= 5); negative entries of Cl(n,0): '
                + ', '.join(f'n={n}: {k}' for n, k in neg.items()) + f'; sign gauges (n = 2, 3, every eps): {gauge_free} gauged tables '
                'without a negative entry; exterior part: non-negative constants ' + ', '.join(f'{k}' for k in disj.values()) + ' = (3^n + x_n)/2 of 3^n, signed sums x_n = ' + ', '.join(str(x) for x in xs) + ' with x_n = 2x_(n-1) + x_(n-2) (n = 0..6)'), \
           'with the reordering sign dropped at n = 2, eps in {+1, 0}^2 gives tables without a negative entry'

def table_alg(n, rule):
    N = 1 << n
    return [[rule(a, b) for b in range(N)] for a in range(N)]          # entries (coefficient, label) or None
def assoc(T, n):
    N = 1 << n
    def m(x, y):
        out = {}
        for a, u in x.items():
            for b, v in y.items():
                r = T[a][b]
                if r is None: continue
                c, lab = r
                if c: out[lab] = out.get(lab, 0) + c * u * v
        return {k: v for k, v in out.items() if v}
    return all(m(m({a: 1}, {b: 1}), {c: 1}) == m({a: 1}, m({b: 1}, {c: 1})) for a in range(N) for b in range(N) for c in range(N)), m
def trace_form_rank(T, n):
    from fractions import Fraction as Fr
    N = 1 << n
    def trL(x):          # trace of left multiplication by basis element x
        return sum(T[x][b][0] for b in range(N) if T[x][b] is not None and T[x][b][1] == b)
    M = [[0] * N for _ in range(N)]
    for a in range(N):
        for b in range(N):
            r = T[a][b]
            if r is not None and r[0]: M[a][b] = r[0] * trL(r[1])
    # rank over Q
    M = [[Fr(x) for x in rr] for rr in M]; rk = 0; cols = N
    for c in range(cols):
        p = next((i for i in range(rk, N) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]
        for i in range(N):
            if i != rk and M[i][c] != 0:
                f = M[i][c] / M[rk][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        rk += 1
    return rk
def comm_dim(T, n):
    N = 1 << n; vecs = []
    for a in range(N):
        for b in range(N):
            v = {}
            for (x, y, s) in ((a, b, 1), (b, a, -1)):
                r = T[x][y]
                if r is not None and r[0]: v[r[1]] = v.get(r[1], 0) + s * r[0]
            v = {k: c for k, c in v.items() if c}
            if v: vecs.append(v)
    piv = {}
    from fractions import Fraction as Fr
    for v in vecs:
        v = {k: Fr(x) for k, x in v.items()}
        while v:
            k = min(v)
            if k in piv:
                f = v[k]
                for kk, x in piv[k].items():
                    y = v.get(kk, 0) - f * x
                    if y: v[kk] = y
                    else: v.pop(kk, None)
            else:
                f = v[k]; piv[k] = {kk: x / f for kk, x in v.items()}; break
    return len(piv)
def chk27(sab):
    ok = True; out = []
    for n in range(1, 5):
        G = table_alg(n, lambda a, b: (1, a ^ b))                                   # unsigned, non-null squares: group algebra of F_2^n
        M = table_alg(n, lambda a, b: (1, a | b) if a & b == 0 else None)           # unsigned, null squares: contracted monoid algebra
        L = table_alg(n, lambda a, b: (sgn(a, b, [0] * n), a | b) if a & b == 0 else None)   # Lambda(R^n)
        if sab and n == 3: M = table_alg(n, lambda a, b: (sgn(a, b, [0] * n), a | b) if a & b == 0 else None)
        aG, _ = assoc(G, n); aM, _ = assoc(M, n); aL, _ = assoc(L, n)
        rG = trace_form_rank(G, n); rM = trace_form_rank(M, n); rL = trace_form_rank(L, n)
        cG, cM, cL = comm_dim(G, n), comm_dim(M, n), comm_dim(L, n)
        out.append(f'n={n}: group alg. trace rank {rG}, [A,A] {cG}; R_0[M] trace rank {rM}, [A,A] {cM}; Lambda trace rank {rL}, [A,A] {cL}')
        if not (aG and aM and aL) or rG != 2 ** n or rM != 1 or rL != 1 or cG != 0 or cM != 0 or cL != 2 ** (n - 1) - 1: ok = False
    # dropping signs: multiplicative mod 2, not over R
    drop_R = 0; drop_2 = 0
    for n in (2, 3):
        for e in [list(x) for x in itertools.product((1, -1), repeat=n)]:
            N = 1 << n
            for a in range(N):
                for b in range(N):
                    s = sgn(a, b, e)
                    if s != 1: drop_R += 1                         # |e_a e_b| = e_{a^b} but |e_a||e_b| maps to e_{a^b} with sign s: equal over R iff s = 1
    if drop_R == 0: ok = False
    # Boolean semiring: unsigned tables and the incidence relation
    bool_ok = True
    for n in range(1, 5):
        N = 1 << n
        def bm(x, y, rule):
            out = set()
            for a in x:
                for b in y:
                    r = rule(a, b)
                    if r is not None: out.add(r)
            return frozenset(out)
        for rule in (lambda a, b: a ^ b, lambda a, b: (a | b) if a & b == 0 else None):
            for a in range(N):
                for b in range(N):
                    for c in range(N):
                        if bm(bm({a}, {b}, rule), {c}, rule) != bm({a}, bm({b}, {c}, rule), rule): bool_ok = False
        rel = {(s, t) for s in range(N) for t in range(N) if s & t == s}
        comp = {(s, u) for (s, t) in rel for (t2, u) in rel if t == t2}
        if comp != rel: bool_ok = False
    if not bool_ok: ok = False
    return ok, ('; '.join(out) + f' (group algebra semisimple and commutative; R_0[M] and Lambda local with radical 2^n - 1, R_0[M] commutative, Lambda not for n >= 2); '
                f'dropping signs fails over R on {drop_R} (pair, eps) cases of n = 2, 3 (mod 2 it holds, -1 = 1: a remark); over the Boolean semiring the unsigned tables and the '
                'incidence relation of B_n compose associatively (n <= 4)'), '; '.join(out[1:3])

def chk28(sab):
    ok = True; notes = []
    # Cl(n,n) in the matrix-unit basis (constants 0/1) and the incidence algebra: products of units
    for n in range(1, 4):
        N = 1 << n
        units = [(t, s) for t in range(N) for s in range(N)]
        def mul(x, y):
            return [(1, (x[0], y[1]))] if x[1] == y[0] else []
        inc = {(t, s) for (t, s) in units if s & t == s}
        closed = all(lab in inc for x in inc for y in inc for c, lab in mul(x, y))
        if not closed: ok = False
    # Cl(1,0): idempotents (1 + e)/2, (1 - e)/2
    def m10(x, y): return (x[0] * y[0] + x[1] * y[1], x[0] * y[1] + x[1] * y[0])       # (a + b e)(c + d e), e^2 = 1
    p, q = (0.5, 0.5), (0.5, -0.5)
    if not (m10(p, p) == p and m10(q, q) == q and m10(p, q) == (0, 0)): ok = False
    # C and H: random bases
    rng = random.Random(7)
    def cmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
    def hmul(x, y):
        a1, b1, c1, d1 = x; a2, b2, c2, d2 = y
        return (a1 * a2 - b1 * b2 - c1 * c2 - d1 * d2, a1 * b2 + b1 * a2 + c1 * d2 - d1 * c2,
                a1 * c2 - b1 * d2 + c1 * a2 + d1 * b2, a1 * d2 + b1 * c2 - c1 * b2 + d1 * a2)
    def solve(Bm, v):
        import numpy as _np
        return _np.linalg.solve(_np.array(Bm, dtype=float).T, _np.array(v, dtype=float))
    found = {'C': 0, 'H': 0}
    def splitmul(x, y): return (x[0] * y[0] + x[1] * y[1], x[0] * y[1] + x[1] * y[0])
    for name, dim, mul in (('C', 2, cmul if not sab else splitmul), ('H', 4, hmul)):    # sabotage: split complex numbers in place of C
        trials = 20000 if name == 'C' else 5000
        for k in range(trials):
            B = [tuple(rng.uniform(-1, 1) for _ in range(dim)) for _ in range(dim)]
            if sab and name == 'C' and k == 0: B = [(0.5, 0.5), (0.5, -0.5)]
            try:
                consts = [solve(B, mul(x, y)) for x in B for y in B]
            except Exception:
                continue
            if all(c >= -1e-12 for v in consts for c in v): found[name] += 1
    if found['C'] or found['H']: ok = False
    notes.append(f'random bases with non-negative constants: C {found["C"]} of 20000, H {found["H"]} of 5000')
    return ok, ('Cl(n,n) = M_{2^n}(R) in the matrix-unit basis has constants in {0, 1} (by the definition of the units) and the units E_{T,S} with S subset T span a closed sub-semialgebra '
                '(the incidence algebra of B_n), n <= 3; Cl(1,0) = R + R has the idempotent basis (1 +- e)/2; ' + notes[0]
                + ': the split cells carry a sign-free basis, C and H show none'), notes[0]

CHECKS = [('bd·mja·26', chk26), ('bd·mja·27', chk27), ('bd·mja·28', chk28)]

if __name__ == '__main__':
    if SABOTAGE:
        missed = 0
        for cid, f in CHECKS:
            ok, _, seen = f(True)
            print(('CAUGHT ' if not ok else 'MISSED ') + cid + '  broken input sees: ' + seen)
            missed += ok
        print('\nALL CAUGHT' if not missed else f'\n{missed} MISSED')
        sys.exit(1 if missed else 0)
    for cid, f in CHECKS:
        ok, text, _ = f(False)
        row(cid, ok, text)
    verdict()
