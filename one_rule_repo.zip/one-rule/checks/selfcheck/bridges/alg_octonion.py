#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""alg_octonion.py: the octonions on the eight labels, their graded automorphisms, the split and the null Cayley-Dickson algebras, sign-cochain
division algebras, and the order-3 question (idea H9) against the colour su(3).

  python3 selfcheck/bridges/alg_octonion.py      one line per check, ids bd·alg·14 .. bd·alg·17, bd·alg·22, bd·alg·24; exit 1 on any FAIL

Standard library (exact integers and fractions; random vectors from a generator with a fixed seed) plus numpy in bd·alg·22 (float determinants
pick candidate zero divisors, each confirmed by an exact integer determinant); deterministic, about 7 s; runs from any folder, reads and writes no file.
 bd·alg·14  Cayley-Dickson R -> C -> H -> O (mu = -1 three times): e_a e_b = +-e_{a xor b}, the associator sign is (-1)^det on all 512 label triples,
            the algebra is alternative and normed (exact, 200 seeded integer pairs); the Albuquerque-Majid cochain
            F(x,y) = (-1)^{sum_{i<=j} x_i y_j + y1 x2 x3 + x1 y2 x3 + x1 x2 y3} (a recalled formula) passes the same tests.
 bd·alg·15  the automorphisms of O that permute the eight basis lines form a group of order 1344 = 8 x 168 onto GL(3,2) with kernel the 8 sign
            characters; the extension 2^3.GL(3,2) is non-split (no lift of a generating pair satisfies the presentation of GL(3,2), and it has
            elements of order 8, which a split extension cannot have); it has elements of order 3 and 7.
 bd·alg·16  split octonions (mu = -1, -1, +1): normed with a norm of signature (4,4), associator (-1)^det; null octonions (mu = -1, -1, 0): the product
            of two labels is 0 exactly when both carry the doubling bit, the algebra is alternative, the four labels with that bit span an ideal J
            with J^2 = 0 and quotient H, and the associator is (-1)^det wherever both bracketings are non-zero.
 bd·alg·24  the alternative sign cochains on Z_2^3 with the null zero pattern and a quaternion quotient: 80 cochains in 5 gauge classes, 4 associative
            (all H (x) R[eps], e.g. the cell Cl(0,2,1)) and 1 not associative, the class of the null octonions CD(H, 0).
 bd·alg·22  the real +-1 sign-cochain algebras on Z_2^3 whose 7 lines are all quaternionic (necessary for division by bd·alg·21): 128; 16 of them, one
            gauge orbit, are octonion presentations (associator (-1)^det, normed), and each of the other 112 has an exact zero divisor in {-1,0,1}^8.
 bd·alg·17  Der(O) has dimension 14 (g2) and the derivations killing e7 dimension 8 (su(3)); no label automorphism other than the identity commutes
            with that su(3), while label automorphisms of order 3 fixing e7 exist.
"""
import random, sys
from fractions import Fraction as Fr
from itertools import product

ROWS = []
def row(i, ok, text):
    cid = 'bd·alg·' + str(i)
    ROWS.append((cid, bool(ok)))
    print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
def verdict():
    n, bad = len(ROWS), sum(1 for _, ok in ROWS if not ok)
    print(f'\n{n - bad}/{n} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not bad else 'SOME BRIDGE CHECK FAILED'))
    sys.exit(1 if bad else 0)
def pc(a): return bin(a).count('1')

# ------------------------------------------------------------------ Cayley-Dickson with parameters mu (one per doubling)
def cd_conj(x):
    n = len(x)
    if n == 1: return x[:]
    h = n // 2
    return cd_conj(x[:h]) + [-v for v in x[h:]]
def cd_mul(x, y, mus):
    """(a,b)(c,d) = (a c + mu conj(d) b, d a + b conj(c))"""
    n = len(x)
    if n == 1: return [x[0] * y[0]]
    h = n // 2; mu = mus[-1]
    a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    first = [u + mu * v for u, v in zip(cd_mul(a, c, mus[:-1]), cd_mul(cd_conj(d), b, mus[:-1]))]
    second = [u + v for u, v in zip(cd_mul(d, a, mus[:-1]), cd_mul(b, cd_conj(c), mus[:-1]))]
    return first + second
def unit(a, n=8): v = [0] * n; v[a] = 1; return v
def table_from(mus):
    T = {}
    for a in range(8):
        for b in range(8):
            v = cd_mul(unit(a), unit(b), mus)
            nz = [(k, c) for k, c in enumerate(v) if c]
            T[(a, b)] = nz
    return T
def det3(a, b, c):
    M = [[(x >> i) & 1 for i in range(3)] for x in (a, b, c)]
    d = (M[0][0] * (M[1][1] * M[2][2] + M[1][2] * M[2][1]) + M[0][1] * (M[1][0] * M[2][2] + M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] + M[1][1] * M[2][0])) % 2
    return d
def sign_table(T):
    """for a table with e_a e_b = s e_{a^b} or 0: return s or 0, None if not of that shape"""
    S = {}
    for (a, b), nz in T.items():
        if not nz: S[(a, b)] = 0
        elif len(nz) == 1 and nz[0][0] == a ^ b and abs(nz[0][1]) == 1: S[(a, b)] = nz[0][1]
        else: return None
    return S
def mul_signs(S, x, y):
    out = [0] * 8
    for a in range(8):
        if x[a]:
            for b in range(8):
                if y[b] and S[(a, b)]: out[a ^ b] += S[(a, b)] * x[a] * y[b]
    return out
def assoc_sign(S, a, b, c):
    l = S[(a, b)] * S[(a ^ b, c)]; r = S[(b, c)] * S[(a, b ^ c)]
    return None if l == 0 or r == 0 else l * r
RNG = random.Random(20261007)
def rvec(): return [RNG.randint(-5, 5) for _ in range(8)]
def alt_norm_ok(S, normsig):
    def N(x): return sum(s * v * v for s, v in zip(normsig, x))
    for _ in range(200):
        x, y = rvec(), rvec()
        xx = mul_signs(S, x, x)
        if mul_signs(S, xx, y) != mul_signs(S, x, mul_signs(S, x, y)): return False
        if mul_signs(S, mul_signs(S, y, x), x) != mul_signs(S, y, xx): return False
        if normsig is not None and N(mul_signs(S, x, y)) != N(x) * N(y): return False
    return True

def check14():
    ok = True
    S = sign_table(table_from([-1, -1, -1]))
    if S is None: ok = False
    else:
        if any(S[(a, a)] != -1 for a in range(1, 8)): ok = False
        if any(assoc_sign(S, a, b, c) != (-1) ** det3(a, b, c) for a in range(8) for b in range(8) for c in range(8)): ok = False
        if not alt_norm_ok(S, [1] * 8): ok = False
    def fam(x, y):
        X = [(x >> i) & 1 for i in range(3)]; Y = [(y >> i) & 1 for i in range(3)]
        f = sum(X[i] * Y[j] for i in range(3) for j in range(3) if i <= j) + Y[0] * X[1] * X[2] + X[0] * Y[1] * X[2] + X[0] * X[1] * Y[2]
        return (-1) ** (f % 2)
    SAM = {(a, b): fam(a, b) for a in range(8) for b in range(8)}
    okAM = all(assoc_sign(SAM, a, b, c) == (-1) ** det3(a, b, c) for a in range(8) for b in range(8) for c in range(8)) and alt_norm_ok(SAM, [1] * 8)
    row(14, ok and okAM, 'Cayley-Dickson octonions on the 3-bit labels: e_a e_b = +-e_{a xor b}, every non-zero label squares to -1, associator sign (-1)^det(a,b,c) on all 512 triples, alternative and normed (exact, 200 seeded integer pairs); the Albuquerque-Majid cochain F(x,y) = (-1)^{sum_{i<=j} x_i y_j + y1x2x3 + x1y2x3 + x1x2y3} (recalled formula) passes the same tests: ' + ('yes' if okAM else 'no'))

def lin_maps():
    """GL(3,2) as images of the basis (g(1), g(2), g(4)); g(a) = xor of images of the bits of a"""
    out = []
    for i1 in range(1, 8):
        for i2 in range(1, 8):
            for i4 in range(1, 8):
                imgs = [0] * 8
                for a in range(8):
                    v = 0
                    if a & 1: v ^= i1
                    if a & 2: v ^= i2
                    if a & 4: v ^= i4
                    imgs[a] = v
                if len(set(imgs)) == 8: out.append(tuple(imgs))
    return out
def graded_autos(S):
    autos = []
    for g in lin_maps():
        for sb in range(1 << 7):
            s = [1] + [(-1) ** ((sb >> (a - 1)) & 1) for a in range(1, 8)]
            if all(S[(g[a], g[b])] * s[a] * s[b] == s[a ^ b] * S[(a, b)] for a in range(8) for b in range(8)):
                autos.append((g, tuple(s)))
    return autos
def comp(x, y):                       # x o y: first y then x;  y: e_a -> t(a) e_{h a}; x: e_b -> s(b) e_{g b}
    (g, s), (h, t) = x, y
    return (tuple(g[h[a]] for a in range(8)), tuple(t[a] * s[h[a]] for a in range(8)))
IDA = (tuple(range(8)), tuple([1] * 8))
def order(x):
    k, y = 1, x
    while y != IDA: y = comp(x, y); k += 1
    return k

def check15():
    ok = True
    S = sign_table(table_from([-1, -1, -1]))
    A = graded_autos(S)
    imgs = {}
    for g, s in A: imgs.setdefault(g, []).append(s)
    if len(A) != 1344 or len(imgs) != 168 or any(len(v) != 8 for v in imgs.values()): ok = False
    kernel = imgs.get(tuple(range(8)), [])
    if sorted(kernel) != sorted(tuple((-1) ** pc(a & m) for a in range(8)) for m in range(8)): ok = False      # the 8 characters
    def lin_order(g):
        k, y = 1, g
        while y != tuple(range(8)): y = tuple(g[y[a]] for a in range(8)); k += 1
        return k
    def gmul(g, h): return tuple(g[h[a]] for a in range(8))
    def ginv(g):
        r = [0] * 8
        for a in range(8): r[g[a]] = a
        return tuple(r)
    # a generating pair of GL(3,2) = PSL(2,7) = <x, y | x^2 = y^3 = (xy)^7 = [x,y]^4 = 1>
    gl = list(imgs)
    pair = next((g2, g3) for g2 in gl if lin_order(g2) == 2 for g3 in gl if lin_order(g3) == 3
                and lin_order(gmul(g2, g3)) == 7 and lin_order(gmul(gmul(ginv(g2), ginv(g3)), gmul(g2, g3))) == 4)
    def inv(x):
        k = order(x); y = IDA
        for _ in range(k - 1): y = comp(x, y)
        return y
    def power(x, k):
        y = IDA
        for _ in range(k): y = comp(x, y)
        return y
    complement = False
    for s2 in imgs[pair[0]]:
        for s3 in imgs[pair[1]]:
            x, y = (pair[0], s2), (pair[1], s3)
            if power(x, 2) == IDA and power(y, 3) == IDA and power(comp(x, y), 7) == IDA \
               and power(comp(comp(inv(x), inv(y)), comp(x, y)), 4) == IDA:
                complement = True
    ords = {}
    for x in A: ords[order(x)] = ords.get(order(x), 0) + 1
    # in a split extension V : GL(3,2) (V = F_2^3 or its dual) an element (v, g) with g of order 4 has (v,g)^4 = ((1+g)^3 v, 1) = 1:
    # check (1+g)^3 = 0 on F_2^3 and on the dual for every g of order 4, so a split extension has no element of order 8
    def as_mat(g): return [[(g[1 << j] >> i) & 1 for j in range(3)] for i in range(3)]
    def mmul(A_, B_): return [[sum(A_[i][k] * B_[k][j] for k in range(3)) % 2 for j in range(3)] for i in range(3)]
    def tr(A_): return [[A_[j][i] for j in range(3)] for i in range(3)]
    nil = True
    for g in gl:
        if lin_order(g) == 4:
            for M in (as_mat(g), tr(as_mat(g))):
                P = [[(M[i][j] + (i == j)) % 2 for j in range(3)] for i in range(3)]
                if mmul(mmul(P, P), P) != [[0] * 3 for _ in range(3)]: nil = False
    nonsplit = (not complement) and ords.get(8, 0) > 0 and nil
    if not nonsplit or 3 not in ords or 7 not in ords: ok = False
    row(15, ok, f'automorphisms of O permuting the basis lines: {len(A)} = 8 x {len(imgs)}, onto GL(3,2) with kernel the 8 sign characters; the extension 2^3.GL(3,2) is non-split: no lifts of a generating pair of GL(3,2) satisfy x^2 = y^3 = (xy)^7 = [x,y]^4 = 1, and it has {ords.get(8, 0)} elements of order 8, which a split extension cannot have ((1+g)^3 = 0 for g of order 4); element orders {dict(sorted(ords.items()))} (order 3 and 7 present). This is the stabiliser of the Z_2^3 label grading inside G_2 (the identification is standard and recalled, not computed)')

def check16():
    ok = True
    Ssp = sign_table(table_from([-1, -1, 1]))
    if Ssp is None: ok = False
    else:
        sq = [Ssp[(a, a)] for a in range(8)]
        normsig = [1 if (a == 0 or sq[a] == -1) else -1 for a in range(8)]          # N(e_a) = e_a conj(e_a) = -e_a^2 for a != 0
        if sorted(normsig) != [-1] * 4 + [1] * 4: ok = False
        if any(assoc_sign(Ssp, a, b, c) != (-1) ** det3(a, b, c) for a in range(8) for b in range(8) for c in range(8)): ok = False
        if not alt_norm_ok(Ssp, normsig): ok = False
    S0 = sign_table(table_from([-1, -1, 0]))
    zero_ok = assoc_ok = alt_ok = rad_ok = False
    if S0 is not None:
        zero_ok = all((S0[(a, b)] == 0) == bool(a & b & 4) for a in range(8) for b in range(8))
        trip = [(a, b, c) for a in range(8) for b in range(8) for c in range(8) if assoc_sign(S0, a, b, c) is not None]
        both_zero = all((S0[(a, b)] * S0[(a ^ b, c)] == 0) == (S0[(b, c)] * S0[(a, b ^ c)] == 0) for a in range(8) for b in range(8) for c in range(8))
        assoc_ok = both_zero and all(assoc_sign(S0, a, b, c) == (-1) ** det3(a, b, c) for a, b, c in trip)
        alt_ok = alt_norm_ok(S0, None)
        J = [a for a in range(8) if a & 4]
        # J is a two-sided ideal, J.J = 0, and the quotient (labels 0..3) is the quaternion table
        rad_ok = all(S0[(a, b)] == 0 for a in J for b in J) and all((a ^ b) & 4 for a in J for b in range(8) if S0[(a, b)]) \
                 and all(S0[(a, a)] == -1 for a in (1, 2, 3)) and S0[(1, 2)] * S0[(2, 1)] == -1
        ntrip = len(trip)
    SO = sign_table(table_from([-1, -1, -1]))
    family = all(SO[(a, b)] == S0[(a, b)] == Ssp[(a, b)] for a in range(8) for b in range(8) if not a & b & 4) and \
             all(Ssp[(a, b)] == -SO[(a, b)] and S0[(a, b)] == 0 for a in range(8) for b in range(8) if a & b & 4)
    if not (zero_ok and assoc_ok and alt_ok and rad_ok and family): ok = False
    row(16, ok, f'one family: the octonion, split and null tables agree on every pair of labels not both carrying the doubling bit, and on those pairs split = -octonion and null = 0, so the doubling bit behaves as a generator of square -1, +1, 0 exactly as in the Clifford cells ({family}); split octonions (mu = -1,-1,+1): norm of signature (4,4), normed, alternative, associator (-1)^det on all triples; null octonions (mu = -1,-1,0): e_a e_b = 0 exactly when both labels carry the doubling bit (a monoid with zero, as for a null Clifford generator), the zero pattern is associative, the associator is (-1)^det on all {ntrip} triples with non-zero bracketings, the algebra is alternative (exact, 200 seeded pairs), and the four labels with the doubling bit span an ideal J with J.J = 0 and quotient H: a null octonion algebra exists in the labelling (QB3)')

def bareiss_det(M):
    M = [r[:] for r in M]; n = len(M); sign = 1; prev = 1
    for k in range(n - 1):
        if M[k][k] == 0:
            sw = next((i for i in range(k + 1, n) if M[i][k] != 0), None)
            if sw is None: return 0
            M[k], M[sw] = M[sw], M[k]; sign = -sign
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                M[i][j] = (M[i][j] * M[k][k] - M[i][k] * M[k][j]) // prev
        prev = M[k][k]
    return sign * M[n - 1][n - 1]
def check22():
    import numpy as np
    ok = True
    lines = []
    for a in range(1, 8):
        for b in range(a + 1, 8):
            L = sorted({a, b, a ^ b})
            if L not in lines: lines.append(L)
    def cochain(choice):
        s = {(a, b): 1 for a in range(8) for b in range(8)}
        for a in range(1, 8): s[(a, a)] = -1
        for L, sg in zip(lines, choice):
            a, b, c = L
            for (x, y, z) in ((a, b, c), (b, c, a), (c, a, b)):
                s[(x, y)] = sg; s[(y, x)] = -sg
        return s
    X = [x for x in product((-1, 0, 1), repeat=8) if any(x)]
    Xa = np.array(X, dtype=float)
    n_oct = n_zero = n_bad = 0; octs = []
    for choice in product((1, -1), repeat=7):
        s = cochain(choice)
        octo = all(assoc_sign(s, a, b, c) == (-1) ** det3(a, b, c) for a in range(8) for b in range(8) for c in range(8))
        M = np.zeros((len(X), 8, 8))
        for a in range(8):
            for b in range(8): M[:, a ^ b, b] += Xa[:, a] * s[(a, b)]
        cand = np.nonzero(np.abs(np.linalg.det(M)) < 0.5)[0]
        exact_zero = False
        for k in cand[:3]:
            x = X[k]; Mx = [[0] * 8 for _ in range(8)]
            for a in range(8):
                for b in range(8): Mx[a ^ b][b] += x[a] * s[(a, b)]
            if bareiss_det(Mx) == 0: exact_zero = True; break
        if octo and not exact_zero and alt_norm_ok(s, [1] * 8): n_oct += 1; octs.append(s)
        elif exact_zero and not octo: n_zero += 1
        else: n_bad += 1
    # the 16 octonion presentations form one gauge orbit: s'(a,b) = s(a,b) b(a) b(b) / b(a^b)
    s0 = octs[0] if octs else None; orbit = set()
    if s0:
        for bb in range(1 << 7):
            beta = [1] + [(-1) ** ((bb >> (a - 1)) & 1) for a in range(1, 8)]
            orbit.add(tuple(s0[(a, b)] * beta[a] * beta[b] * beta[a ^ b] for a in range(8) for b in range(8)))
    same_orbit = {tuple(s[(a, b)] for a in range(8) for b in range(8)) for s in octs} == orbit
    if (n_oct, n_zero, n_bad) != (16, 112, 0) or not same_orbit: ok = False
    row(22, ok, f'real sign-cochain algebras on Z_2^3 whose 7 lines are all quaternionic (necessary for division by bd·alg·21): 128; octonion presentations (associator (-1)^det, normed) {n_oct}, forming one gauge orbit: {same_orbit}; with an exact zero divisor in {{-1,0,1}}^8 {n_zero}; other {n_bad}. Among +-1 sign-cochain algebras of Z_2^3 over R the octonions are the only division algebra, by a finite computation')

def check24():
    ok = True
    def zero(a, b): return bool(a & b & 4)
    def base(sig):
        s = {}
        for a in range(8):
            for b in range(8):
                if a == 0 or b == 0: s[(a, b)] = 1
                elif zero(a, b): s[(a, b)] = 0
        for a in (1, 2, 3): s[(a, a)] = -1
        for (x, y, z) in ((1, 2, 3), (2, 3, 1), (3, 1, 2)): s[(x, y)] = sig; s[(y, x)] = -sig
        return s
    var = [(a, b) for a in range(1, 8) for b in range(1, 8) if not zero(a, b) and not (a < 4 and b < 4)]
    def A(s, a, b, c): return s[(a, b)] * s[(a ^ b, c)] - s[(b, c)] * s[(a, b ^ c)]
    cons = [(t, a, b, c) for a in range(1, 8) for b in range(1, 8) for c in range(1, 8) for t in 'LR']
    order = {v: i for i, v in enumerate(var)}
    def keys(con):
        _, a, b, c = con; ks = set()
        for (x, y, z) in ((a, b, c), (b, a, c), (a, c, b)):
            for k in ((x, y), (x ^ y, z), (y, z), (x, y ^ z)): ks.add(k)
        return ks
    def holds(s, con):
        t, a, b, c = con
        return (A(s, a, b, c) + (A(s, b, a, c) if t == 'L' else A(s, a, c, b))) == 0
    bymax = {}
    for con in cons:
        idx = [order[k] for k in keys(con) if k in order]
        bymax.setdefault(max(idx) if idx else -1, []).append(con)
    sols = []
    for sig in (1, -1):
        s = base(sig)
        if not all(holds(s, c) for c in bymax.get(-1, [])): continue
        def rec(i):
            if i == len(var): sols.append(dict(s)); return
            for val in (1, -1):
                s[var[i]] = val
                if all(holds(s, c) for c in bymax.get(i, [])): rec(i + 1)
            del s[var[i]]
        rec(0)
    ks = sorted(sols[0].keys()) if sols else []
    classes = {}
    for s in sols:
        best = None
        for bb in range(1 << 7):
            beta = [1] + [(-1) ** ((bb >> (a - 1)) & 1) for a in range(1, 8)]
            t = tuple(s[k] * beta[k[0]] * beta[k[1]] * beta[k[0] ^ k[1]] for k in ks)
            if best is None or t < best: best = t
        classes.setdefault(best, s)
    n_assoc = n_non = 0; non_ok = False; comm_patterns = set()
    for s in classes.values():
        assoc_all = all(A(s, a, b, c) == 0 for a in range(8) for b in range(8) for c in range(8))
        comm = tuple(s[(4, x)] * s[(x, 4)] for x in (1, 2, 3))
        if assoc_all:
            n_assoc += 1; comm_patterns.add(comm)
            # witness for H (x) R[eps]: a label u in {0,1,2,3} with e_u e_4 (label u^4) commuting with e_1, e_2, e_3
            if not any(all(s[(u ^ 4, x)] * s[(x, u ^ 4)] == 1 for x in (1, 2, 3)) for u in range(4)): ok = False
        else:
            n_non += 1
            non_ok = comm == (-1, -1, -1) and all(assoc_sign(s, a, b, c) in (None, (-1) ** det3(a, b, c)) for a in range(8) for b in range(8) for c in range(8))
    S0 = sign_table(table_from([-1, -1, 0]))
    cd_in = False
    for bb in range(1 << 7):
        beta = [1] + [(-1) ** ((bb >> (a - 1)) & 1) for a in range(1, 8)]
        t = {k: S0[k] * beta[k[0]] * beta[k[1]] * beta[k[0] ^ k[1]] for k in ks}
        if any(all(t[k] == s[k] for k in ks) for s in sols): cd_in = True; break
    if (len(sols), len(classes), n_assoc, n_non) != (80, 5, 4, 1) or not non_ok or not cd_in or (1, 1, 1) not in comm_patterns: ok = False
    row(24, ok, f'alternative sign cochains on Z_2^3 with the null zero pattern (product 0 iff both labels carry bit 4) and quaternion quotient: {len(sols)} cochains, {len(classes)} gauge classes; {n_assoc} associative (null element commuting with i, j, k or with exactly one of them: all isomorphic to H (x) R[eps], e.g. the cell Cl(0,2,1)), {n_non} not associative: the null element anticommutes with i, j, k, the associator is (-1)^det wherever defined, and the class contains CD(H,0): {cd_in}. The null analogue of the octonions is unique (QB3)')

def solve_rational(rows, nvar):
    """null space basis of a rational linear system (list of dict var->coef)"""
    M = [[Fr(r.get(j, 0)) for j in range(nvar)] for r in rows]
    piv_cols = []; rk = 0
    for col in range(nvar):
        piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        pv = M[rk][col]; M[rk] = [x / pv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv_cols.append(col); rk += 1
    free = [j for j in range(nvar) if j not in piv_cols]
    basis = []
    for f in free:
        v = [Fr(0)] * nvar; v[f] = Fr(1)
        for i, pcol in enumerate(piv_cols): v[pcol] = -M[i][f]
        basis.append(v)
    return basis
def check17():
    ok = True
    S = sign_table(table_from([-1, -1, -1]))
    # D as 8x8 matrix D[i][j] = coefficient of e_i in D(e_j); variable index 8*i + j
    rows = []
    for a in range(8):
        for b in range(8):
            s = S[(a, b)]; c = a ^ b
            # D(e_a e_b) = s D(e_c) = sum_i s D[i][c] e_i ;  D(e_a) e_b = sum_k D[k][a] S[k,b] e_{k^b} ; e_a D(e_b) = sum_k D[k][b] S[a,k] e_{a^k}
            for i in range(8):
                r = {}
                r[8 * i + c] = r.get(8 * i + c, 0) + s
                k = i ^ b; r[8 * k + a] = r.get(8 * k + a, 0) - S[(k, b)]
                k = a ^ i; r[8 * k + b] = r.get(8 * k + b, 0) - S[(a, k)]
                rows.append({kk: v for kk, v in r.items() if v})
    g2 = solve_rational(rows, 64)
    su3 = solve_rational(rows + [{8 * i + 7: 1} for i in range(8)], 64)
    if len(g2) != 14 or len(su3) != 8: ok = False
    A = graded_autos(S)
    def as_matrix(x):
        g, s = x; M = [[0] * 8 for _ in range(8)]
        for a in range(8): M[g[a]][a] = s[a]
        return M
    def commutes(M, Dv):
        D = [[Dv[8 * i + j] for j in range(8)] for i in range(8)]
        MD = [[sum(M[i][k] * D[k][j] for k in range(8)) for j in range(8)] for i in range(8)]
        DM = [[sum(D[i][k] * M[k][j] for k in range(8)) for j in range(8)] for i in range(8)]
        return MD == DM
    centralising = [x for x in A if all(commutes(as_matrix(x), D) for D in su3)]
    fix7_order3 = [x for x in A if x[0][7] == 7 and order(x) == 3]
    if centralising != [IDA] or not fix7_order3: ok = False
    row(17, ok, f'Der(O) has dimension {len(g2)} (g2) and the derivations with D(e7) = 0 dimension {len(su3)} (su(3)); of the 1344 label automorphisms only the identity commutes with this su(3), although {len(fix7_order3)} of them have order 3 and fix e7: they permute the colours inside SU(3) and do not commute with it. An order-3 label symmetry compatible with the octonion product exists (H9), but not one that commutes with colour')

if __name__ == '__main__':
    for f in (check14, check15, check16, check24, check22, check17): f()
    verdict()
