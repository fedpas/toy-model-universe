#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""mjg_vectors.py: the arrows of the label category B_n as vectors: the n-dimensional cube vectors and the squares eps of the bit rule; the
paper's 'commutative diagrams are equal vectors' (Def. 1); the inner product f.g = ||f|| ||g|| cos(theta) of Def. 3 (eq. (10)); the paper is
arXiv:2403.19689 (v3).

    python3 selfcheck/bridges/mjg_vectors.py              one line per check, ids bd·mjg·9 .. bd·mjg·11 and bd·mjg·32; exit 1 on any FAIL
    python3 selfcheck/bridges/mjg_vectors.py --sabotage   run every check on a deliberately broken input; each must print CAUGHT

Standard library plus numpy (ranks of small integer matrices are computed exactly over Q with Fractions; floats only for the planar angles,
tolerance 1e-9), deterministic (seeded generators), about 1 s; runs from any folder, reads and writes no file.

The bit rule of the Atlas: e_a e_b = s(a,b) e_(a xor b), s(a,b) = (-1)^N(a,b) prod_(i in a and b) eps_i, N(a,b) = #{(i,j): i in a, j in b, j < i}.
The cube vector of the arrow S -> T is x(T) - x(S) in {0,1}^n (x(a) the 0/1 coordinates of a); its Clifford vector is v(f) = sum_(i in T \\ S) e_i.

 bd·mjg·9   (the squares) composable arrows of B_n have orthogonal cube vectors (disjoint supports), so the weight ||f|| = |x(T)-x(S)|_1
            = |x(T)-x(S)|_2^2 is additive (l1 on the positive orthant; Pythagoras); with the bit rule, v(f)^2 = sum_(i in T \\ S) eps_i (a scalar)
            for every eps in {+1,-1,0}^n (n <= 4), additive on every composable pair, positive on every non-identity arrow exactly for
            eps = (1, .., 1) (1 of 3^n), and composable Clifford vectors anticommute; v(f)^2 = ||f||^2 (the printed (13)) holds only on the arrows
            of weight <= 1. Control: x^T G x is additive on all composable pairs for every diagonal G and for none of 200 seeded non-diagonal
            symmetric G (n = 3, 4). Sabotage: one off-diagonal entry added to the diagonal forms.
 bd·mjg·10  (Def. 1, 'equal vectors') the additive weights on B_n form a space of dimension 2^n - 1 = dim{h(T) - h(S)} (n <= 4): every additive
            weight is a height difference (H^1 of the nerve is 0); in the commutative square B_2 the generator weights (1, 1, 1, 2) have no
            additive extension, in the free category on the same square graph they have one, with composites of weights 2 and 3 and a space of
            additive weights of dimension 4; controls: 200 seeded random posets on 8 points satisfy
            dim(additive weights) - (|Ob| - #components) = b_1(order complex) (generic), with b_1 > 0 in k of them.  Remarks that hold by
            telescoping (D = dP for every P) and are not part of the check: every two chains with the same endpoints have the same sum of
            planar vectors and the same weight (Petrie view and seeded random P, n <= 4), and the two parallel composites of the free square
            have equal planar vectors.  Sabotage: the free square in place of the commutative square.
 bd·mjg·11  (Def. 3, eq. (10), (13)) with the Petrie view n = 4 (injective) and the popcount weight: f.g = ||f|| ||g|| cos(theta) equals the
            Euclidean D(f).D(g) on a pair exactly when cos(theta) = 0 or ||f|| = |D(f)| and ||g|| = |D(g)|; it is the scalar part of the Cl(2,0)
            product F(f) F(g) of the rescaled vectors F(f) = ||f|| D(f)/|D(f)| (bit rule, every pair), F(f)^2 = ||f||^2; distributivity
            (f (+) g).h = f.h + g.h fails on k of M (composable f, g; any h) and F(g o f) = F(f) + F(g) only on the positively collinear pairs; under
            a line drawing P = h u (reading R1) distributivity holds on all.  That orthogonal arrows anticommute in f g = f.g + f ^ g
            (Corollary 1 (2)) is a remark (f.g = 0 there and the wedge is antisymmetric), not part of the check. Sabotage: cos(theta)
            replaced by 1.
 bd·mjg·32  (the subtraction of §4) for every factorisation f = l o g of non-identity arrows of B_n (n <= 5), ||l|| = ||f|| - ||g|| and
            ||g|| = ||f|| - ||l||: the distances d(f, g) = ||l||, d(f, l) = ||g|| of §4 are differences of weights (and D(f) - D(g) = D(l) for
            every P, by telescoping: a remark); they are defined on k
            of N ordered pairs of non-identity arrows (common domain with g a first factor, or common codomain with l a last factor); on objects
            they are the directed (Lawvere) distance |U \\ T| for T <= U, and the shortest-path distance of the undirected Hasse diagram is the
            Hamming distance |T xor U| = the l1 distance of the cube embedding, a metric (triangle inequality on all triples, n <= 4).
            Sabotage: seeded random positive weights on the arrows (not additive).
"""
import sys, math, itertools, random
from fractions import Fraction as Fr
import numpy as np

SAB = '--sabotage' in sys.argv
RESULTS = []
def report(cid, ok, text):
    RESULTS.append((cid, bool(ok)))
    if SAB: print('  sabotaged input, what the check sees: ' + text)
    else: print(('ok   ' if ok else 'FAIL ') + cid + '  ' + text)
    return bool(ok)

def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1 and pc(b & ((1 << i) - 1)) % 2: s = -s
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1: s *= eps[i]
    return s
def mvmul(x, y, eps):
    out = {}
    for a, ca in x.items():
        for b, cb in y.items():
            s = sgn(a, b, eps)
            if s: out[a ^ b] = out.get(a ^ b, 0) + s * ca * cb
    return {k: v for k, v in out.items() if v != 0}
def arrows(n): return [(S, T) for T in range(1 << n) for S in range(1 << n) if S & ~T == 0 and S != T]
def pairs(n):
    return [(S, T, U) for U in range(1 << n) for T in range(1 << n) if T & ~U == 0 and T != U for S in range(1 << n) if S & ~T == 0 and S != T]
def xvec(a, n): return np.array([(a >> i) & 1 for i in range(n)])
def cols_petrie(n): return np.array([[math.cos(math.pi * i / n), math.sin(math.pi * i / n)] for i in range(n)])
def view(cols, n): return np.array([cols[[i for i in range(n) if a >> i & 1]].sum(axis=0) if a else np.zeros(2) for a in range(1 << n)])
def rank_Q(rows, ncols):
    M = [[Fr(v) for v in r] for r in rows]; rk = 0
    for c in range(ncols):
        piv = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c] / M[rk][c]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1
    return rk

# ------------------------------------------------------------------------------------------------------------------------------------
def check9(sab):
    ok = True; info = []
    for n in range(1, 7):
        for S, T, U in pairs(n):
            a, b = xvec(T, n) - xvec(S, n), xvec(U, n) - xvec(T, n)
            ok &= int(a @ b) == 0 and int(np.abs(a + b).sum()) == pc(U & ~S) == int((a + b) @ (a + b))
    pos_eps = []; tot_eps = 0; sq_ok = True; anti_ok = True; w2 = {}
    for n in range(1, 5):
        A = arrows(n); Pp = pairs(n)
        for eps in itertools.product((1, -1, 0), repeat=n):
            tot_eps += 1
            v = {(S, T): {1 << i: 1 for i in range(n) if (T & ~S) >> i & 1} for S, T in A}
            sq = {}
            for f, vf in v.items():
                s2 = mvmul(vf, vf, eps); val = s2.get(0, 0)
                sq_ok &= set(s2) <= {0} and val == sum(eps[i] for i in range(n) if (f[1] & ~f[0]) >> i & 1); sq[f] = val
            for S, T, U in Pp:
                sq_ok &= sq[(S, U)] == sq[(S, T)] + sq[(T, U)]
                p1 = mvmul(v[(S, T)], v[(T, U)], eps); p2 = mvmul(v[(T, U)], v[(S, T)], eps)
                anti_ok &= all(p1.get(k, 0) == -p2.get(k, 0) for k in set(p1) | set(p2))
            if all(val > 0 for val in sq.values()): pos_eps.append((n, eps))
            if all(e == 1 for e in eps):
                w2[n] = sum(1 for f in A if sq[f] == pc(f[1] & ~f[0]) ** 2)
    ok &= sq_ok and anti_ok and pos_eps == [(n, (1,) * n) for n in range(1, 5)]
    ok &= all(w2[n] == n * 2 ** (n - 1) for n in w2)
    # control: quadratic forms on R^n
    rng = np.random.default_rng(11); diag_ok = True; nondiag_bad = 0
    for n in (3, 4):
        Pp = pairs(n)
        def additive(G): return all(abs((xvec(U, n) - xvec(S, n)) @ G @ (xvec(U, n) - xvec(S, n)) - (xvec(T, n) - xvec(S, n)) @ G @ (xvec(T, n) - xvec(S, n))
                                       - (xvec(U, n) - xvec(T, n)) @ G @ (xvec(U, n) - xvec(T, n))) < 1e-9 for S, T, U in Pp)
        for _ in range(200):
            G = np.diag(rng.normal(size=n))
            if sab: G[0, 1] = G[1, 0] = 0.5
            diag_ok &= additive(G)
            H = rng.normal(size=(n, n)); H = H + H.T
            nondiag_bad += not additive(H)
    ok &= diag_ok and nondiag_bad == 400
    return report('bd·mjg·9', ok, 'composable cube vectors are orthogonal and ||f|| = l1 = (l2)^2 is additive (n <= 6); bit rule, every eps in {+1,-1,0}^n, n <= 4 '
                  f'({tot_eps} signatures): v(f)^2 = sum of eps over T \\ S, additive on every composable pair, composable vectors anticommute; positive on every '
                  f'non-identity arrow only for eps = (1,..,1) ({len(pos_eps)} of {tot_eps}); v(f)^2 = ||f||^2 on {w2} arrows = the arrows of weight 1 (n 2^(n-1)); '
                  f'control: diagonal G additive in 400 of 400: {diag_ok}; seeded non-diagonal symmetric G not additive in {nondiag_bad} of 400')

def check10(sab):
    ok = True; info = []; chains_ok = True
    rng = np.random.default_rng(12)
    for n in range(1, 5):
        for P in (view(cols_petrie(n), n), rng.normal(size=(1 << n, 2))):
            for S in range(1 << n):
                for T in range(1 << n):
                    if S & ~T or S == T: continue
                    diff = [i for i in range(n) if (T & ~S) >> i & 1]
                    sums = set(); ws = set()
                    for perm in itertools.permutations(diff):
                        cur = S; vec = np.zeros(2); w = 0
                        for i in perm:
                            vec = vec + P[cur | 1 << i] - P[cur]; w += 1; cur |= 1 << i
                        sums.add(tuple(np.round(vec, 9))); ws.add(w)
                    chains_ok &= len(sums) == 1 and len(ws) == 1       # telescoping: a remark, not part of the check
    dims = {}
    for n in range(1, 5):
        A = arrows(n); idx = {f: k for k, f in enumerate(A)}
        rows = []
        for S, T, U in pairs(n):
            r = [0] * len(A); r[idx[(S, U)]] += 1; r[idx[(S, T)]] -= 1; r[idx[(T, U)]] -= 1; rows.append(r)
        dims[n] = len(A) - rank_Q(rows, len(A))
        ok &= dims[n] == 2 ** n - 1
    # the square: commutative (B_2) against free
    def square_system(free):
        arrs = ['f', 'g', 'h', 'k', 'gf', 'kh'] if free else ['f', 'g', 'h', 'k', 'd']
        eqs = [('gf', 'f', 'g'), ('kh', 'h', 'k')] if free else [('d', 'f', 'g'), ('d', 'h', 'k')]
        given = {'f': 1, 'g': 1, 'h': 1, 'k': 2}
        unknown = [a for a in arrs if a not in given]
        rows = []; rhs = []
        for c, a, b in eqs:
            r = [0] * len(unknown); r[unknown.index(c)] = 1; rows.append(r); rhs.append(given[a] + given[b])
        rk = rank_Q(rows, len(unknown)); rk_aug = rank_Q([r + [v] for r, v in zip(rows, rhs)], len(unknown) + 1)
        return rk == rk_aug, dict(zip([c for c, _, _ in eqs], rhs))
    comm_consistent, _ = square_system(free=sab)
    free_consistent, free_w = square_system(free=True)
    ok &= not comm_consistent and free_consistent and free_w == {'gf': 2, 'kh': 3}
    # planar vectors of the two free composites: equal for every P (same endpoints)
    P = rng.normal(size=(4, 2)); par_eq = np.allclose((P[1] - P[0]) + (P[3] - P[1]), (P[2] - P[0]) + (P[3] - P[2]))   # telescoping: a remark
    # free square: dim of additive weights 4, height differences 3
    rows = [[-1, -1, 0, 0, 1, 0], [0, 0, -1, -1, 0, 1]]; dfree = 6 - rank_Q(rows, 6); ok &= dfree == 4
    # random posets: dim Z^1 - dim B^1 = b_1 of the order complex
    rs = random.Random(13); nb1 = 0; ident = True
    for _ in range(200):
        m = 8; R = [[False] * m for _ in range(m)]
        for i in range(m):
            for j in range(i + 1, m):
                if rs.random() < 0.3: R[i][j] = True
        for k in range(m):
            for i in range(m):
                for j in range(m):
                    if R[i][k] and R[k][j]: R[i][j] = True
        arr = [(i, j) for i in range(m) for j in range(m) if R[i][j]]; ia = {a: k for k, a in enumerate(arr)}
        tri = [(i, j, k) for (i, j) in arr for k in range(m) if R[j][k]]
        rows = []
        for i, j, k in tri:
            r = [0] * len(arr); r[ia[(i, k)]] += 1; r[ia[(i, j)]] -= 1; r[ia[(j, k)]] -= 1; rows.append(r)
        dZ = len(arr) - (rank_Q(rows, len(arr)) if rows else 0)
        # components of the comparability graph
        par = list(range(m))
        def fd(x):
            while par[x] != x: par[x] = par[par[x]]; x = par[x]
            return x
        for i, j in arr: par[fd(i)] = fd(j)
        comp = len({fd(x) for x in range(m)})
        # b_1 by ranks of boundaries: b1 = dim C1 - rank d1 - rank d2
        d1 = [[(1 if v == j else -1 if v == i else 0) for (i, j) in arr] for v in range(m)]
        r1 = rank_Q(d1, len(arr)) if arr else 0
        d2 = [[(1 if (a == (j, k)) else -1 if a == (i, k) else 1 if a == (i, j) else 0) for (i, j, k) in tri] for a in arr]
        r2 = rank_Q(d2, len(tri)) if tri else 0
        b1 = len(arr) - r1 - r2
        ident &= dZ - (m - comp) == b1; nb1 += b1 > 0
    ok &= ident and 0 < nb1 < 200
    return report('bd·mjg·10', ok, f'additive weights on B_n: '
                  f'dimension {dims} = 2^n - 1 (height differences); commutative square with generator weights (1,1,1,2): additive extension exists: {comm_consistent}; '
                  f'free square: exists, composites weighted {free_w}, dim of additive weights {dfree} = 3 + b_1; 200 seeded posets on 8 points: '
                  f'dim Z^1 - (|Ob| - #comp) = b_1 in all: {ident}; b_1 > 0 in {nb1}; remarks by telescoping, not part of the check: chains with the same endpoints have '
                  f'equal planar vector sums and equal weights (Petrie view and seeded P, n <= 4): {chains_ok}, the free composites have equal planar vectors: {par_eq}')

def check11(sab):
    ok = True
    n = 4; P = view(cols_petrie(n), n); A = arrows(n); Pp = pairs(n)
    D = {f: P[f[1]] - P[f[0]] for f in A}; W = {f: pc(f[1] & ~f[0]) for f in A}
    def cos(u, v): return 1.0 if sab else float(u @ v / (np.linalg.norm(u) * np.linalg.norm(v)))
    def dot(f, g): return W[f] * W[g] * cos(D[f], D[g])
    eq_ok = True; neq = 0
    for f in A:
        for g in A:
            c = float(D[f] @ D[g] / (np.linalg.norm(D[f]) * np.linalg.norm(D[g])))
            same = abs(dot(f, g) - D[f] @ D[g]) < 1e-9
            pred = abs(c) < 1e-9 or (abs(W[f] - np.linalg.norm(D[f])) < 1e-9 and abs(W[g] - np.linalg.norm(D[g])) < 1e-9)
            eq_ok &= same == pred; neq += not same
    # the Cl(2,0) product of the rescaled vectors F, bit rule
    F = {f: W[f] * D[f] / np.linalg.norm(D[f]) for f in A}
    cl_ok = True
    for f in A:
        for g in A:
            prod = mvmul({1: F[f][0], 2: F[f][1]}, {1: F[g][0], 2: F[g][1]}, (1, 1))
            cl_ok &= abs(prod.get(0, 0) - W[f] * W[g] * float(D[f] @ D[g] / (np.linalg.norm(D[f]) * np.linalg.norm(D[g])))) < 1e-9
        sq = mvmul({1: F[f][0], 2: F[f][1]}, {1: F[f][0], 2: F[f][1]}, (1, 1)); cl_ok &= abs(sq.get(0, 0) - W[f] ** 2) < 1e-9 and abs(sq.get(3, 0)) < 1e-12
    dist_fail = tot = 0; Fadd = 0; coll = 0
    for S, T, U in Pp:
        f, g, fg = (S, T), (T, U), (S, U)
        a, b = D[f], D[g]
        Fadd += np.allclose(F[fg], F[f] + F[g], atol=1e-9); coll += abs(a[0] * b[1] - a[1] * b[0]) < 1e-9 and a @ b > 0
        for h in A:
            tot += 1; dist_fail += abs(dot(fg, h) - dot(f, h) - dot(g, h)) > 1e-9
    ok &= eq_ok and cl_ok and dist_fail > 0 and Fadd == coll
    # line drawing (reading R1): distributivity everywhere
    rs = random.Random(14); h = {a: pc(a) + rs.random() * 0.5 for a in range(1 << n)}; h[0] = 0.0
    u = np.array([0.6, 0.8]); PL = {a: h[a] * u for a in range(1 << n)}
    DL = {f: PL[f[1]] - PL[f[0]] for f in A}; WL = {f: h[f[1]] - h[f[0]] for f in A}
    def dotL(f, g): return WL[f] * WL[g] * float(DL[f] @ DL[g] / (np.linalg.norm(DL[f]) * np.linalg.norm(DL[g])))
    lin_ok = all(abs(dotL((S, U), hh) - dotL((S, T), hh) - dotL((T, U), hh)) < 1e-9 for S, T, U in Pp for hh in A)
    ok &= lin_ok
    # Corollary 1 (2): orthogonal pairs anticommute in f g = f.g + D(f) ^ D(g)
    northo = 0; anti = True
    for f in A:
        for g in A:
            if abs(float(D[f] @ D[g])) < 1e-9:
                northo += 1
                fg = (dot(f, g), D[f][0] * D[g][1] - D[f][1] * D[g][0]); gf = (dot(g, f), D[g][0] * D[f][1] - D[g][1] * D[f][0])
                anti &= abs(fg[0] + gf[0]) < 1e-9 and abs(fg[1] + gf[1]) < 1e-9
    return report('bd·mjg·11', ok, f'Petrie view n = 4, popcount weight: f.g = ||f|| ||g|| cos(theta) differs from D(f).D(g) on {neq} of {len(A) ** 2} pairs, exactly where '
                  f'cos(theta) != 0 and a weight differs from the planar length: {eq_ok}; it is the scalar part of F(f) F(g) in Cl(2,0) (bit rule) with F(f)^2 = ||f||^2: '
                  f'{cl_ok}; distributivity (f (+) g).h = f.h + g.h fails on {dist_fail} of {tot}; F(g o f) = F(f) + F(g) on {Fadd} pairs = the {coll} positively collinear '
                  f'pairs of {len(Pp)}; line drawing P = h u: distributive on all: {lin_ok}; remark (f.g = 0 and an antisymmetric wedge), not part of the check: the {northo} orthogonal pairs anticommute: {anti}')

def check32(sab):
    ok = True; info = []; tele = True
    rs = random.Random(32)
    for n in range(1, 6):
        A = arrows(n); W = {f: pc(f[1] & ~f[0]) for f in A}
        if sab: W = {f: rs.randint(1, 9) for f in A}
        Pp = pairs(n); P = np.random.default_rng(320 + n).normal(size=(1 << n, 2))
        for S, T, U in Pp:
            f, g, l = (S, U), (S, T), (T, U)
            ok &= W[l] == W[f] - W[g] and W[g] == W[f] - W[l]
            tele &= np.allclose((P[U] - P[S]) - (P[T] - P[S]), P[U] - P[T])   # telescoping: a remark
        defined = sum(1 for f in A for g in A if f != g and ((f[0] == g[0] and g[1] & ~f[1] == 0) or (f[1] == g[1] and f[0] & ~g[0] == 0)))
        info.append(f'n={n}: {defined} of {len(A) * (len(A) - 1)}')
    for n in range(1, 5):
        V = range(1 << n); dist = {}
        for s0 in V:
            dd = {s0: 0}; fr = [s0]
            while fr:
                nx = []
                for x in fr:
                    for i in range(n):
                        y = x ^ (1 << i)
                        if y not in dd: dd[y] = dd[x] + 1; nx.append(y)
                fr = nx
            dist[s0] = dd
        ok &= all(dist[a][b] == pc(a ^ b) for a in V for b in V)
        ok &= all(dist[a][c] <= dist[a][b] + dist[b][c] for a in V for b in V for c in V)
    return report('bd·mjg·32', ok, f'every factorisation f = l o g in B_n: ||l|| = ||f|| - ||g|| (n <= 5; D(f) - D(g) = D(l) by telescoping, a remark: {tele}); ordered pairs on which the subtraction of §4 defines d: '
                  + ', '.join(info) + '; undirected Hasse distance = Hamming = l1 of the cube, a metric (n <= 4)')

CHECKS = [('bd·mjg·9', check9), ('bd·mjg·10', check10), ('bd·mjg·11', check11), ('bd·mjg·32', check32)]

def main():
    if SAB:
        missed = 0
        for cid, fn in CHECKS:
            okk = fn(True)
            print(('CAUGHT ' if not okk else 'MISSED ') + cid)
            missed += okk
        print('ALL SABOTAGES CAUGHT' if not missed else f'{missed} SABOTAGE(S) MISSED')
        return missed == 0
    for cid, fn in CHECKS: fn(False)
    nfail = sum(1 for _, o in RESULTS if not o)
    print(f'\n{len(RESULTS) - nfail}/{len(RESULTS)} bridge checks hold.  ' + ('ALL BRIDGE CHECKS PASS' if not nfail else 'SOME BRIDGE CHECK FAILED'))
    return nfail == 0

if __name__ == '__main__':
    sys.exit(0 if main() else 1)
