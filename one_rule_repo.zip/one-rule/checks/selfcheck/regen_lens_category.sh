#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild categorySelfcheckSource.js, the mirror of the check script the category chapter (step 18) offers for download: selfcheck/reports/cat_check.py, byte for byte
# Run from anywhere; every path is inside the package; deterministic and re-runnable; stops at the first error (set -e). Run it again whenever cat_check.py changes.
set -e
cd "$(dirname "$0")/.."
python3 - <<'PY'
import json
src = open('selfcheck/reports/cat_check.py', encoding='utf-8').read()
out = 'export const CAT_CHECK_PY = ' + json.dumps(src, ensure_ascii=False) + ';\n'
open('categorySelfcheckSource.js', 'w', encoding='utf-8').write(out)
PY
echo "regen_lens_category: done"
