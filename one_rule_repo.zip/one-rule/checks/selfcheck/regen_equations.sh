#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# Rebuild equations.json (exact, standard library) and the two modules the page imports from the two Dirac-step scripts:
#   selfcheck/equations.json          the data equations_selfcheck.py computes
#   equationsData.js                  {eq: equations.json, matrix: dirac_matrix.json} as an ES module (default export)
#   equationsSelfcheckSource.js       EQ_PY (equations_selfcheck.py) and DIRAC_PY (dirac_matrix_check.py), the two scripts of the page's download box
# dirac_matrix.json is the stored output of dirac_matrix_check.py (needs numpy; run it with --write dirac_matrix.json to renew it).
# Run from anywhere; every path is inside the package; stops at the first error (set -e), and a failing check leaves the stored files as they were (the json is written to a temporary file first).
set -e
cd "$(dirname "$0")/.."
TMP=$(mktemp)
python3 selfcheck/equations_selfcheck.py --write "$TMP" | tail -1
cp "$TMP" selfcheck/equations.json; rm -f "$TMP"
python3 selfcheck/equations_selfcheck.py --compare selfcheck/equations.json | tail -1
python3 - <<'PY'
import json
HDR = '// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n// Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)\n'
eq = json.load(open('selfcheck/equations.json', encoding='utf-8')); mx = json.load(open('selfcheck/dirac_matrix.json', encoding='utf-8'))
open('equationsData.js', 'w', encoding='utf-8').write(HDR + 'export default ' + json.dumps({'eq': eq, 'matrix': mx}) + '\n')
a = open('selfcheck/equations_selfcheck.py', encoding='utf-8').read(); b = open('selfcheck/dirac_matrix_check.py', encoding='utf-8').read()
open('equationsSelfcheckSource.js', 'w', encoding='utf-8').write('export const EQ_PY = ' + json.dumps(a, ensure_ascii=False) + ';\nexport const DIRAC_PY = ' + json.dumps(b, ensure_ascii=False) + ';\n')
PY
echo "regen_equations: done"
