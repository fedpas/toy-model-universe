#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild gravity.json (exact; the random fields use fixed seeds) and gravity_matrix.json, and the two modules the pages import from them:
# gravityData.js (both json files) and gravitySelfcheckSource.js (gravity_selfcheck.py and gravity_matrix_check.py byte for byte, for the download buttons).
# Run from anywhere; every path is inside the package; stops at the first error (set -e), and a failing check of the stored json is an error.
set -e
cd "$(dirname "$0")"
last() { n=$1; shift; out=$("$@") || { printf '%s\n' "$out" >&2; echo "regen: failed: $*" >&2; exit 1; }; printf '%s\n' "$out" | tail -"$n"; }   # run a command, stop on its failure (a pipe into tail would hide it), print its last lines
# each script writes its json before it exits on a failing check, so it writes into a new file, and that file replaces the stored json only when the second run
# (the comparison) has also passed: a failing check leaves the stored json files (and the modules below) as they were.
NEW=gravity.json.new; NEWM=gravity_matrix.json.new
trap 'rm -f "$NEW" "$NEWM"' EXIT
last 2 python3 -I gravity_selfcheck.py --write "$NEW"
last 1 python3 -I gravity_selfcheck.py --compare "$NEW"
last 2 python3 -I gravity_matrix_check.py --write "$NEWM"
last 1 python3 -I gravity_matrix_check.py --compare "$NEWM"
mv "$NEW" gravity.json
mv "$NEWM" gravity_matrix.json
cd ..
python3 -I - <<'PY'
import json
JS_HEADER = '// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n// Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)\n'
gv = json.load(open('selfcheck/gravity.json', encoding='utf-8')); gm = json.load(open('selfcheck/gravity_matrix.json', encoding='utf-8'))
open('gravityData.js', 'w', encoding='utf-8').write(JS_HEADER + 'export default ' + json.dumps({'gv': gv, 'matrix': gm}, ensure_ascii=False) + ';\n')
src = lambda f: json.dumps(open('selfcheck/' + f, encoding='utf-8').read(), ensure_ascii=False)
open('gravitySelfcheckSource.js', 'w', encoding='utf-8').write('export const GV_PY = ' + src('gravity_selfcheck.py') + ';\nexport const GVM_PY = ' + src('gravity_matrix_check.py') + ';\n')
PY
echo "regen_gravity: done"
