#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A3.  The closed form of the connection omega (Cartan-Koszul) as the inverse of the torsion map, on the bit-rule engine.   python3 a3_closed_form.py

 Claim.  In frame components the map omega -> T is a CONSTANT square matrix L of size n*C(n,2) (read from the engine's torsion operator on the flat frame); its inverse is
         omega^{ab}_c = 1/2 [ sq_b D^a_{bc} + sq_a D^b_{ca} - sq_a sq_b sq_c D^c_{ab} ],  D = frame components of de.
         So T = 0 has exactly one solution omega(e), and it is this one.
 [bit]       L read from the engine (Clifford tables h, forms with null generators); L S = S L = -1 exactly, n = 2..8 and every sign pattern of the frame metric up to n = 6;
             support locality (each entry of L S involves only the three indices of its row), which together with the exhaustive n <= 3 patterns settles every n;
             the engine's torsion of random polynomial frames vanishes at random rational points for the closed-form omega, n = 2..8;
             it equals today's pointwise solve (n = 3, 4, 5).
 [std]       the same matrix L from the textbook index formula (no Clifford algebra); omega from the metric by Christoffel symbols (tetrad postulate), exact; numpy dense solve.
 Controls    wrong sign, 1/2 -> 1, 1/2 -> 1/3, the last term dropped, Euclidean signs on a Lorentz frame: all must fail."""
import time
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

def all_sign_patterns(n): return [list(p) for p in itertools.product((1, -1), repeat=n)]

# ======================================================================= part 1: the matrices
def part1():
    head('PART 1  the torsion map L (from the engine) and its inverse S (the Koszul formula): exact, whole matrices')
    for n in range(2, 9):
        sq = LORENTZ(n); Lie_, Lrows = torsion_L_engine(n, sq); Lstd = torsion_L_std(n, sq); S = koszul_S(n, sq, Lie_); N = n * (n * (n - 1) // 2)
        rowkeys = [(c, d, b) for c in range(n) for d in range(n) for b in range(d + 1, n)]; colkeys = [(A, c) for A in range(Lie_.G) for c in range(n)]
        chk('bit==std', Lrows == Lstd, 'n=%d: the torsion map L read from the engine (Clifford tables) equals the textbook index formula entry by entry (%d x %d, %d non-zero entries)' % (n, N, N, sum(len(r) for r in Lrows.values())))
        LS = sparse_mul(Lrows, S); SL = sparse_mul(S, Lrows)
        chk('bit', is_scaled_identity(LS, -1, rowkeys) and is_scaled_identity(SL, -1, colkeys), 'n=%d: L S = S L = -1 exactly (size %d): omega = S D solves T = 0 and nothing else does' % (n, N))
        pairs_ = pairs_of(Lie_); by = {'c outside the pair (a,b)': set(), 'c = a or c = b': set()}
        for (A, c), row in S.items(): by['c outside the pair (a,b)' if c not in pairs_[A] else 'c = a or c = b'].update(row.values())
        okent = by['c outside the pair (a,b)'] <= {F(1, 2), F(-1, 2)} and by['c = a or c = b'] <= {F(1, 2), F(-1, 2), F(1), F(-1)}
        chk('bit', okent, 'n=%d: the entries of S: %s; they are +-1/2 when the three indices differ and may be +-1 when two coincide (two terms add)' % (n, '; '.join('%s: %s' % (k, sorted(map(str, v))) for k, v in by.items() if v)))
        # support locality: row of L has <= 2 entries; each S row of those columns is supported on the row's three indices
        loc = True
        for (c, d, b), row in Lrows.items():
            idx = {c, d, b}; assert len(row) <= 2
            for (A, mu) in row:
                for (c2, d2, b2) in S[(A, mu)]:
                    if not ({c2, d2, b2} <= idx): loc = False
        chk('bit', loc, 'n=%d: locality: every row of L has at most 2 entries and the S-rows they reach live on the three indices (c,d,b) of the row: an entry of L S depends on three indices only' % n)
        tick('n=%d' % n)
    head('PART 1b  every sign pattern of the frame metric (the entries carry sq_i = +-1), n = 2..6, whole matrices')
    for n in range(2, 7):
        ok = True; cnt = 0
        for sq in all_sign_patterns(n):
            Lie_, Lrows = torsion_L_engine(n, sq); S = koszul_S(n, sq, Lie_)
            rowkeys = [(c, d, b) for c in range(n) for d in range(n) for b in range(d + 1, n)]; colkeys = [(A, c) for A in range(Lie_.G) for c in range(n)]
            ok &= (Lrows == torsion_L_std(n, sq)) and is_scaled_identity(sparse_mul(Lrows, S), -1, rowkeys) and is_scaled_identity(sparse_mul(S, Lrows), -1, colkeys); cnt += 1
        chk('bit==std', ok, 'n=%d: all %d sign patterns: engine L = textbook L, and L S = S L = -1' % (n, cnt))
        tick('patterns n=%d' % n)
    rng = random.Random(5)
    for n in (7, 8):
        ok = True; cnt = 0
        for sq in [LORENTZ(n), [-1] * n, [1] * n] + [[rng.choice((1, -1)) for _ in range(n)] for _ in range(3)]:
            Lie_, Lrows = torsion_L_engine(n, sq); S = koszul_S(n, sq, Lie_)
            rowkeys = [(c, d, b) for c in range(n) for d in range(n) for b in range(d + 1, n)]; colkeys = [(A, c) for A in range(Lie_.G) for c in range(n)]
            ok &= (Lrows == torsion_L_std(n, sq)) and is_scaled_identity(sparse_mul(Lrows, S), -1, rowkeys) and is_scaled_identity(sparse_mul(S, Lrows), -1, colkeys); cnt += 1
        chk('bit==std', ok, 'n=%d: Lorentz, all-minus, all-plus and three random sign patterns (%d): L S = S L = -1' % (n, cnt))
    print('  note: an entry of L S depends only on the order and the signs of the three indices of its row (locality above); the n = 2, 3 runs with all sign patterns therefore contain every case,'
          '\n        so L S = -1 holds for every n. The runs for n up to 8 are a regression guard, not the argument.')
    head('PART 1c  controls on the matrix level (all must fail)')
    n = 4; sq = LORENTZ(n); Lie_, Lrows = torsion_L_engine(n, sq); S = koszul_S(n, sq, Lie_)
    rowkeys = [(c, d, b) for c in range(n) for d in range(n) for b in range(d + 1, n)]
    def variant(f): return {k: {kk: f(kk, v) for kk, v in row.items()} for k, row in S.items()}
    for name, Sv in (('wrong sign', variant(lambda kk, v: -v)), ('1/2 -> 1', variant(lambda kk, v: 2 * v)), ('1/2 -> 1/3', variant(lambda kk, v: v * F(2, 3))),
                     ('Euclidean signs on a Lorentz frame', koszul_S(n, [-1] * n, Lie_))):
        chk('ctl', not is_scaled_identity(sparse_mul(Lrows, Sv), -1, rowkeys), 'L S = -1 fails for the variant "%s"' % name)
    S_drop = {}                                                     # drop the third term: the entry (c2 = c, pair = (a, b))
    for A, (a, b) in enumerate(pairs_of(Lie_)):
        for c in range(n): S_drop[(A, c)] = {k: v for k, v in S[(A, c)].items() if not (k[0] == c and (k[1], k[2]) == (a, b))}
    chk('ctl', not is_scaled_identity(sparse_mul(Lrows, S_drop), -1, rowkeys), 'L S = -1 fails when the last term (-D^c_{ab}) is dropped')

# ======================================================================= part 2: the frame lemma
def part2():
    head('PART 2  the lemma: in ANY frame the engine\'s torsion has frame components D + L w  (L the constant matrix of part 1)')
    for n, seed in ((3, 11), (4, 12), (5, 13), (6, 14)):
        rng = random.Random(seed); sq = LORENTZ(n); Lie_, Lrows = torsion_L_engine(n, sq); Gv = Grav(n, Lie_); ok = True
        for trial in range(3):
            e = rand_frame(rng, n); w = {(A, c): F(rng.randint(-3, 3)) for A in range(Gv.G) for c in range(n)}
            om = [{} for _ in range(Gv.G)]
            for A in range(Gv.G):
                for mu in range(n):
                    t = {}
                    for c in range(n): t = padd(t, e[c].get(1 << mu, {}), w[(A, c)])
                    if t: om[A][1 << mu] = t
            T = Gv.torsion(om, e); e0, E0, det = E0_of(e, n, n)
            Tc = {}
            for c in range(n):
                for mu in range(n):
                    for nu in range(mu + 1, n):
                        v = at0(T[c].get((1 << mu) | (1 << nu), {}), n); Tc[(c, mu, nu)] = v; Tc[(c, nu, mu)] = -v
            D, _, _ = anholonomy(Gv, e, n, 0)
            for (c, d, b), Dv in D.items():
                got = sum(E0[mu][d] * E0[nu][b] * Tc.get((c, mu, nu), 0) for mu in range(n) for nu in range(n) if mu != nu)
                want = at0(Dv, n) + sum(v * w[key] for key, v in Lrows.get((c, d, b), {}).items())
                ok &= (got == want)
        chk('bit', ok, 'n=%d: 3 random polynomial frames, random frame components w: engine T (frame components) = D + L w for every (c,d,b)' % n)

# ======================================================================= part 3: the closed-form omega kills the engine's torsion
def part3():
    head('PART 3  the closed-form omega on random polynomial frames: the engine\'s torsion is exactly zero (values at the point)')
    res = {}
    for n in range(2, 9):
        rng = random.Random(100 + n); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_)
        trials = 4 if n <= 5 else 2; ok = True; nonflat = True; cnt = 0
        for trial in range(trials):
            e = rand_frame(rng, n)
            for shift in (0, 1):
                ee = e
                while shift:
                    ee = translate_frame(e, [F(rng.randint(-5, 5), rng.randint(1, 4)) for _ in range(n)], n)
                    if det_inv([[at0(ee[a].get(1 << mu, {}), n) for mu in range(n)] for a in range(n)])[0] != 0: break
                om, w, D = omega_closed_form(Gv, ee, S, n, 0)
                ok &= torsion_zero_at0(Gv, om, ee, n); cnt += 1
                nonflat &= any(v != 0 for v in w.values())
        chk('bit', ok and nonflat, 'n=%d: %d random polynomial frames (degree 2; at the origin and at a random rational point): T(omega_closed_form) = 0 in all components, omega not zero' % (n, cnt))
        tick('n=%d' % n)

# ======================================================================= part 4/5/6: pointwise solve, Christoffel, numpy
def christoffel0(g, n, nv):
    gi, g0, g0i = std_inverse_metric(g, n, nv, 0)
    dg = lambda k, a, b: at0(sp_der(g[(a, b)], k), nv)
    return {(l, m, v): sum(F(1, 2) * g0i[l][s] * (dg(m, s, v) + dg(v, s, m) - dg(s, m, v)) for s in range(n)) for l in range(n) for m in range(n) for v in range(n)}
def part4():
    head('PART 4  against today\'s pointwise solve (a square linear system solved by elimination) and against the metric')
    for n in (3, 4, 5):
        rng = random.Random(200 + n); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); ok = True; uniq = True
        for trial in range(2):
            e = rand_frame(rng, n); om, w, D = omega_closed_form(Gv, e, S, n, 0)
            om2, rank, nvar, cons, neq = solve_torsion_free(Gv, e, 0)
            uniq &= (cons and rank == nvar == neq)
            ok &= all({m: at0(p, n) for m, p in om[A].items()} == {m: at0(p, n) for m, p in om2[A].items()} for A in range(Gv.G))
        chk('bit', uniq, 'n=%d: the pointwise system is square (%d x %d) and of full rank: the solution is unique' % (n, neq, nvar))
        chk('bit', ok, 'n=%d: closed form = pointwise solve, every component, 2 random frames' % n)
    head('PART 5  [std] omega from the metric: Christoffel symbols and the tetrad postulate, w^a_{b mu} = (Gamma^l_{mu nu} e^a_l - d_mu e^a_nu) E^nu_b,  w^{ab} = w^a_b sq_b')
    for n in range(2, 7):
        rng = random.Random(300 + n); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); ok = True; cnt = 0
        for trial in range(3 if n <= 5 else 2):
            e = rand_frame(rng, n); e0, E0, det = E0_of(e, n, n)
            g = std_metric(e, n, sq, n, 2); Gam = christoffel0(g, n, n)
            de0 = {(a, mu, nu): at0(sp_der(e[a].get(1 << nu, {}), mu), n) for a in range(n) for mu in range(n) for nu in range(n)}   # d_mu e^a_nu
            om, w, D = omega_closed_form(Gv, e, S, n, 0)
            for A, (a, b) in enumerate(pairs_of(Lie_)):
                for mu in range(n):
                    wab = sum((sum(Gam[(l, mu, nu)] * e0[a][l] for l in range(n)) - de0[(a, mu, nu)]) * E0[nu][b] for nu in range(n)) * sq[b]
                    ok &= (wab == at0(om[A].get(1 << mu, {}), n)); cnt += 1
        chk('bit==std', ok, 'n=%d: the closed-form omega equals the Levi-Civita connection of g = e^T eta e, all %d components of the sampled frames, exactly' % (n, cnt))
    head('PART 6  [std] numpy: dense solve of the textbook torsion equations L w = -D in floating point (n up to 8), against the closed form')
    for n in (3, 4, 6, 8):
        rng = random.Random(400 + n); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_)
        e = rand_frame(rng, n); om, w, D = omega_closed_form(Gv, e, S, n, 0)
        rows = torsion_L_std(n, sq); pairs = [(a, b) for a in range(n) for b in range(a + 1, n)]; keys = [(c, d, b) for c in range(n) for d in range(n) for b in range(d + 1, n)]
        cols = [(A, c) for A in range(len(pairs)) for c in range(n)]; cidx = {k: i for i, k in enumerate(cols)}
        Lm = np.zeros((len(keys), len(cols)))
        for i, k in enumerate(keys):
            for kk, v in rows.get(k, {}).items(): Lm[i, cidx[kk]] = float(v)
        rhs = -np.array([float(at0(D[k], n)) for k in keys]); sol = np.linalg.solve(Lm, rhs)
        err = max(abs(sol[cidx[k]] - float(at0(w[k], n))) for k in cols)
        chk('bit==std', err < 1e-9 and abs(np.linalg.det(Lm)) > 0.5, 'n=%d: numpy.linalg.solve of the textbook system (%d x %d, |det L| = %.3g) agrees with the engine-based closed form to %.2g' % (n, len(keys), len(cols), abs(np.linalg.det(Lm)), err))

# ======================================================================= part 7: controls on frames
def part7():
    head('PART 7  controls on frames: wrong versions of the closed form leave a torsion in the engine')
    n = 4; rng = random.Random(77); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_)
    e = rand_frame(rng, n); Dpre = anholonomy(Gv, e, n, 0)
    om, w, D = omega_closed_form(Gv, e, S, n, 0, 1, Dpre); chk('bit', torsion_zero_at0(Gv, om, e, n), 'reference: the closed form gives T = 0 on this frame')
    def nonzero_T(om_):
        T = Gv.torsion(om_, e); return sum(1 for c in T for p in c.values() if at0(p, n) != 0)
    om, _, _ = omega_closed_form(Gv, e, S, n, 0, -1, Dpre); chk('ctl', nonzero_T(om) > 0, 'wrong sign: %d non-zero torsion components' % nonzero_T(om))
    S2 = {k: {kk: 2 * v for kk, v in row.items()} for k, row in S.items()}; om, _, _ = omega_closed_form(Gv, e, S2, n, 0, 1, Dpre); chk('ctl', nonzero_T(om) > 0, '1/2 -> 1: %d non-zero torsion components' % nonzero_T(om))
    S3 = {k: {kk: v * F(2, 3) for kk, v in row.items()} for k, row in S.items()}; om, _, _ = omega_closed_form(Gv, e, S3, n, 0, 1, Dpre); chk('ctl', nonzero_T(om) > 0, '1/2 -> 1/3: %d non-zero torsion components' % nonzero_T(om))
    SE = koszul_S(n, [-1] * n, Lie_); om, _, _ = omega_closed_form(Gv, e, SE, n, 0, 1, Dpre); chk('ctl', nonzero_T(om) > 0, 'Euclidean signs on a Lorentz frame: %d non-zero torsion components' % nonzero_T(om))
    S4 = {}
    for A, (a, b) in enumerate(pairs_of(Lie_)):
        for c in range(n): S4[(A, c)] = {k: v for k, v in S[(A, c)].items() if not (k[0] == c and (k[1], k[2]) == (a, b))}
    om, _, _ = omega_closed_form(Gv, e, S4, n, 0, 1, Dpre); chk('ctl', nonzero_T(om) > 0, 'last term dropped: %d non-zero torsion components' % nonzero_T(om))

if __name__ == '__main__':
    part1(); part2(); part3(); part4(); part7()
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('A3')
