#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G1. Free top in the elliptic, Euclidean and hyperbolic algebras.   python3 g1_free_top.py [--quick] [--n N] [--fault FK|FC|F2]

[bit]  the Atlas forque engine (forque_selfcheck: Alg(3, 1, kappa), Body.I_def, picard) for kappa = +1, 0, -1; bodies of mass points normalised in Cl_kappa
       (engine mass mu/(1 + kappa|q|^2) at the weight-1 point, see g1_clkappa).  Flow M' = -M B/2, B' = A^-1(B x A(B)), exact series through t^N.
[bit==Gunn]  Gunn's printed inertia matrix (9.19) and his compact system (9.26)-(9.27) with Omega = -B/2, A_G built from (9.19) (not from I_def).
[std]  no Clifford product: kappa = +-1 the top with a fixed point in R^{eta} (eta = diag(kappa,1,1,1)), J = sum mu v v^T (exact matrix series);
       kappa = 0 the textbook Newton-Euler body; classical linear-stability formula for the Euclidean control.
--fault FK: e0^2 flipped in the engine (kappa -> -kappa);  FC: commutator sign of the pair (e12, e23) flipped in the flow;  F2: Omega = -B in the dictionary."""
import sys, os, time, random
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import b1lib
from b1lib import head, chk, finish
from fractions import Fraction as F
from g1_clkappa import *

ARGS = sys.argv[1:]
QUICK = '--quick' in ARGS
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
N = int(ARGS[ARGS.index('--n') + 1]) if '--n' in ARGS else (3 if QUICK else 7)
KAPPAS = (1,) if QUICK else (1, 0, -1)
NAME = {1: 'elliptic', 0: 'Euclid', -1: 'hyperbolic'}
def eng_alg(k, d=3): return alg(-k if FAULT == 'FK' else k, d)
def eng_comm(A): return bad_comm(A) if FAULT == 'FC' else A.comm
OMF = F(-1) if FAULT == 'F2' else F(-1, 2)                      # the dictionary Omega = OMF * B
def bcoef(B): return [B.d.get((1 << a) | (1 << b), F(0)) for a, b in PAIRS4]
def ser_list_eq(a, b, n): return all(x == y for x, y in zip(a[:n + 1], b[:n + 1]))
rng = random.Random(150915)
def rand_body(k, npts):
    vals = [F(-1, 2), F(-1, 3), F(-1, 4), F(0), F(1, 4), F(1, 3), F(1, 2)] if k == -1 else [F(a, b) for a in range(-2, 3) for b in (1, 2)]
    return [(F(rng.randint(1, 3)), [rng.choice(vals) for _ in range(3)]) for _ in range(npts)]
def rand_B(A): return MV(A.sq, {m: F(rng.choice([-2, -1, 1, 2]), rng.randint(1, 3)) for m in A.bivectors()})
def mtot(pts): return sum(F(mu) for mu, _ in pts)
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)

# ============================================================================================ 0. reading of the engine
head('0. The engine: point, star, join, normalisation; Gunn (9.15) against (9.8)')
stars = {}
for k in KAPPAS:
    A = eng_alg(k); q = [F(1, 2), F(-1, 3), F(1, 4)]; X = A.point(q)
    chk('bit', trivector_coords(A, X)[0] == 1, '%s: Alg.point(q) has weight (e123 coefficient) 1 for every kappa' % NAME[k])
    chk('bit', X * X == A.one().scale(-qnorm2(k, q)), '%s: X^2 = -(1 + kappa|q|^2) = %s, unit weight in Gunn\'s sense only if kappa|q|^2 = 0' % (NAME[k], -qnorm2(k, q)))
    stars[k] = [(A.star(MV(A.sq, {S: F(1)}))).d for S in range(16)]
if len(stars) > 1: chk('bit', all(stars[k] == stars[1] for k in stars), 'star (signed complement) and hence join are the same for kappa = +1, 0, -1: metric-free')
RAT = {1: [((1, 1, 1), 2), ((2, 2, 0), 3), ((4, 2, 2), 5), ((0, 0, 0), 1)], 0: [((1, -2, 3), 1), ((0, 1, 1), 1), ((2, 0, -1), 1), ((1, 1, 0), 1)],
       -1: [((F(3, 5), 0, 0), F(4, 5)), ((F(1, 3), F(2, 3), 0), F(2, 3)), ((F(2, 7), F(3, 7), 0), F(6, 7)), ((0, 0, 0), 1)]}
for k in KAPPAS:
    A = eng_alg(k); okn = ok15 = oksym = okratio = ok93 = True; pts = []
    for (q, n), mu in zip(RAT[k], (1, 2, 3, 1)):
        q = [F(x) for x in q]; assert qnorm2(k, q) == F(n) ** 2; R = A.point(q).scale(1 / F(n)); pts.append((F(mu), q, R))
        okn &= (R * R == A.one().scale(-1))
        for _ in range(2):
            Om, Xi = rand_B(A), rand_B(A)
            ok15 &= gunn_915(A, R, Om, Om, mu) == gunn_98(A, R, Om, mu); oksym &= gunn_915(A, R, Om, Xi, mu) == gunn_915(A, R, Xi, Om, mu)
            v98 = gunn_98(A, R.scale(2), Om, mu); okratio &= v98 != 0 and gunn_915(A, R.scale(2), Om, Om, mu) / v98 == 4
    chk('bit', okn, '%s: rational kappa-unit points R = X/||X|| (R^2 = -1) for the (9.15)/(9.8) test' % NAME[k])
    chk('bit', ok15, '%s: Gunn (9.15) A(Om, Om) = (9.8) -Om v Pi for normalised R, 4 points x 2 random Om' % NAME[k])
    chk('bit', oksym, '%s: (9.15) is symmetric in (Om, Xi)' % NAME[k])
    chk('ctl', okratio, '%s: for 2R (not normalised) (9.15)/(9.8) = 4 = lambda^2: the two definitions differ off the unit quadric (Thm 186 lambda^4 is the (9.15) weight; the momentum (9.3) weight is lambda^2)' % NAME[k])
    body = Body(A, [(mu / F(n) ** 2, q) for (mu, q, R), (_, n) in zip(pts, RAT[k])])
    for i in range(6):
        b = gvec(A, unit(i)); AG93 = A.zero()
        for mu, q, R in pts: AG93 = AG93 + A.join(R, A.comm(b, R)).scale(2 * mu)
        ok93 &= AG93 == body.I(b).scale(-2)
    chk('bit', ok93, '%s: Gunn (9.3) momentum of explicitly normalised points = -2 I_def of the engine body with masses mu/||X||^2 (A_G = -2 A_Atlas; the normalisation rule)' % NAME[k])
tline('part 0')

# ============================================================================================ a, b, c, 2: random bodies
head('a/b/c/2. Random bodies: (9.19), Gunn\'s flow, integrals, point momenta, [std] tops (N = %d)' % N)
STARC = set()
for k in KAPPAS:
    for ib in range(1 if QUICK else 3):
        pts = rand_body(k, rng.randint(4, 6)); A = eng_alg(k); body = body_n(A, k, pts); epts = engine_pts(k, pts)
        tag = '%s body %d (%d points)' % (NAME[k], ib + 1, len(pts))
        Sig = sigma_engine(A, body.I); G19 = gunn_919(k, pts); m = mtot(pts)
        chk('bit==std', all(Sig[i][i] == G19[i][i] for i in range(6)), '%s: diagonal of b_a v A(b_a) = (9.19) diagonal (w^2+k x^2, .., x^2+y^2, x^2+z^2, y^2+z^2), normalised points' % tag)
        chk('bit==std', Sig == G19, '%s: full 6x6 join-pairing matrix = (9.19) as read (off-diagonal signs included), without the leading 2' % tag)
        pd = True
        for r in range(1, 7):
            sub = [row[:r] for row in Sig[:r]]; cp = charpoly(sub); det = cp[-1] * (-1) ** r; pd &= det > 0
        chk('bit', pd, '%s: the inertia form is positive definite (leading minors > 0), Gunn Rem. 191' % tag)
        chk('bit', [Sig[0][0] + k * Sig[5][5], Sig[1][1] + k * Sig[4][4], Sig[2][2] + k * Sig[3][3]] == [m] * 3, '%s: the moment identity M01 + kappa M23 = M02 + kappa M31 = M03 + kappa M12 = m = %s (Rem. 191 normalisation, no 2)' % (tag, m))
        chk('bit', (k * Sig[0][0] + Sig[5][5] == m) == (k == 1), '%s: printed (9.20) kappa M01 + M23 = m holds iff kappa = +1' % tag)
        B0 = rand_B(A); t1 = time.time()
        M, B = engine_flow(A, body.I, body.Iinv, B0, N, comm=eng_comm(A))
        AG, AGi = gunn_maps(A, [[2 * x for x in r] for r in G19])
        chk('bit==std', all(AG(gvec(A, unit(i))) == body.I(gvec(A, unit(i))).scale(-2) for i in range(6)), '%s: A_G built from (9.19) (with its 2) = -2 A_Atlas as maps' % tag)
        g, Om = gunn_flow(A, AG, AGi, B0.scale(OMF), N)
        chk('bit==std', ser_eq(g, M, N) and ser_eq(Om, B.scale(OMF), N), '%s: Gunn (9.26)-(9.27) with A_G from (9.19) = engine flow, g = M, Omega = -B/2, through t^%d' % (tag, N))
        Pis, E, C2, C4 = integrals(A, body.I, M, B)
        chk('bit', ser_is_const(Pis, N) and ser_is_const(E, N) and ser_is_const(C2, N) and ser_is_const(C4, N) and E.c[0].scalar() > 0,
            '%s: Pi_s = M A(B) M~, E = B v A(B)/2 > 0, <PP>_0, <PP>_4 constant through t^%d' % (tag, N))
        PM = point_momentum(A, M, epts)
        chk('bit', ser_eq(PM, Pis, N - 1), '%s: sum mu R_i v R_i\' of the moving normalised points = Pi_s through t^%d (the A built from points is this body)' % (tag, N - 1))
        if k != 0:
            Lam, Bs, J, vs = std_top(k, epts, bcoef(B0), N)
            Le = vector_matrix_series(A, M)
            chk('bit==std', all(ser_list_eq(Le[i][j], Lam[i][j], N) for i in range(4) for j in range(4)) and all(ser_list_eq([c.d.get((1 << a) | (1 << b), F(0)) for c in B.c], Bs[r], N) for r, (a, b) in enumerate(PAIRS4)),
                '%s: motor sandwich on vectors = Lam(t) and B(t) = [std] top with a fixed point in R^{%s} (J = sum mu v v^T), through t^%d' % (tag, '4' if k == 1 else '3,1', N))
            okp = True
            for (me, q), Rw in zip(epts, world_points(A, M, epts)):
                wc = [[c_ for c_ in trivector_coords(A, c)] for c in Rw.c]; v = [F(1) / k] + list(q)
                for i in range(4):
                    sv = [sum(Lam[i][j][t] * v[j] for j in range(4)) for t in range(N + 1)]
                    okp &= sv == [(wc[t][0] / k if i == 0 else wc[t][i]) for t in range(N + 1)]
            chk('bit==std', okp, '%s: world points M R_i M~ = Lam(t) v_i (v = R I^-1 = (w/kappa, x, y, z))' % tag)
            eta = [F(k), 1, 1, 1]; OB = om_basis(eta); Om0 = [[sum(bcoef(B0)[c] * OB[c][i][j] for c in range(6)) for j in range(4)] for i in range(4)]
            Lb = [[sum(J[i][l] * Om0[j][l] - Om0[i][l] * J[l][j] for l in range(4)) for j in range(4)] for i in range(4)]
            St = A.star(body.I(B0)); ratios = set()
            for a, b in PAIRS4:
                x, y = St.d.get((1 << a) | (1 << b), F(0)), eta[a] * Lb[a][b] * eta[b]
                ratios.add('0' if x == y == 0 else (x / y if y else 'inf'))
            ratios.discard('0'); STARC |= ratios
            chk('bit==std', len(ratios) == 1 and list(ratios)[0] in (1, -1), '%s: star(Pi) = c eta L eta with one c in {+1,-1}; found c = %s' % (tag, sorted(map(str, ratios))))
            if k == -1:
                Lw, Bw, _, _ = std_top(k, epts, bcoef(B0), N, eta=[F(1), F(1), F(1), F(1)])
                chk('ctl', not all(ser_list_eq(Le[i][j], Lw[i][j], N) for i in range(4) for j in range(4)), '%s: the Euclidean R^4 top (eta = 1) on the same J does NOT give the hyperbolic flow' % tag)
        else:
            pts_std, wstd = std_newton_euler(epts, bcoef(B0), N); okp = True
            for Rw, ps in zip(world_points(A, M, epts), pts_std):
                wc = [trivector_coords(A, c) for c in Rw.c]
                okp &= [c[0] for c in wc] == [F(1)] + [F(0)] * N
                for i in range(3): okp &= [c[i + 1] for c in wc] == ps[i]
            wB = [[c.d.get(0b1100, F(0)) for c in B.c], [-c.d.get(0b1010, F(0)) for c in B.c], [c.d.get(0b0110, F(0)) for c in B.c]]
            chk('bit==std', okp and all(ser_list_eq(wB[i], wstd[i], N) for i in range(3)), '%s: world points and body angular velocity (B23, -B13, B12) = textbook Newton-Euler through t^%d' % (tag, N))
        print('    (%s: flows and comparisons %.1f s)' % (tag, time.time() - t1), flush=True)
if STARC: print('  momentum dictionary: star(Pi) = c eta L eta with c in', sorted(map(str, STARC)))
tline('parts a/b/c/2')

if not QUICK:
    # ======================================================================================== d. controls
    head('d. Controls (a wrong body, a wrong sign, the naive engine body)')
    for k in (1, -1):
        pts = rand_body(k, 5); A = eng_alg(k); epts = engine_pts(k, pts); B0 = rand_B(A)
        A0 = alg(0); bE = Body(A0, [(mu, q) for mu, q in pts])
        IE, IEi = linear_map(A, {mm: bE.I(MV(A0.sq, {mm: F(1)})) for mm in A.bivectors()}, A.bivectors())
        M, B = engine_flow(A, IE, IEi, B0, N - 1, comm=eng_comm(A))
        Pis, E, C2, C4 = integrals(A, IE, M, B); PM = point_momentum(A, M, epts)
        chk('ctl', not ser_is_const(PM, N - 2), 'ctl-E %s: Euclidean inertia of the same points (kappa not applied in X x B): the point momenta are NOT conserved' % NAME[k])
        chk('bit', ser_is_const(Pis, N - 1) and ser_is_const(E, N - 1) and ser_is_const(C2, N - 1) and ser_is_const(C4, N - 1),
            'ctl-E %s (blindness): M A_E(B) M~, E, <PP>_0, <PP>_4 are still constant: the integrals cannot see a wrong body' % NAME[k])
        SigE = sigma_engine(A, IE)
        chk('ctl', SigE[0][0] + k * SigE[5][5] != mtot(pts), 'ctl-E %s: the Euclidean A violates the moment identity (M01 + kappa M23 = %s, not m = %s)' % (NAME[k], SigE[0][0] + k * SigE[5][5], mtot(pts)))
    # page-style diagonal A (pgadyn: A(e_m) = c_m dual(e_m), translations c = m): the Euclidean box, then used for kappa = +1
    box = [(F(1), [sx * F(1, 4), sy * F(2, 4), sz * F(3, 4)]) for sx in (1, -1) for sy in (1, -1) for sz in (1, -1)]
    A0 = alg(0); b0 = body_n(A0, 0, box); S0 = sigma_engine(A0, b0.I)
    cdiag = {}
    for i, (mm, s) in enumerate(GB3): cdiag[mm] = S0[i][i]
    def diag_images(A):
        out = {}
        for mm in A.bivectors():
            comp = A.full ^ mm; sg = FQ.bmul(mm, comp, A.sq)[1]; out[mm] = MV(A.sq, {comp: cdiag[mm] * sg})
        return out
    ID0, _ = linear_map(A0, diag_images(A0), A0.bivectors())
    chk('bit', sigma_engine(A0, ID0) == S0, 'page-style diagonal A (A(e_m) = c_m dual(e_m), c = Euclidean moments of the box, c_0k = m) = the engine\'s Euclidean box inertia')
    A1 = alg(1); ID1, ID1i = linear_map(A1, diag_images(A1), A1.bivectors()); SD = sigma_engine(A1, ID1)
    chk('ctl', SD[0][0] + SD[5][5] != 8, 'ctl-D elliptic: the page diagonal A violates the moment identity (M01 + M23 = %s, m = 8): no elliptic body has it' % (SD[0][0] + SD[5][5]))
    M, B = engine_flow(A1, ID1, ID1i, rand_B(A1), N - 1)
    chk('ctl', not ser_is_const(point_momentum(A1, M, engine_pts(1, box)), N - 2), 'ctl-D elliptic: flow with the page diagonal A; the normalised box points\' momenta are NOT conserved')
    # commutator sign reversed
    k = 1; pts = rand_body(k, 5); A = eng_alg(k); body = body_n(A, k, pts); epts = engine_pts(k, pts); B0 = rand_B(A)
    M, B = engine_flow(A, body.I, body.Iinv, B0, N - 1, sign=-1)
    Pis, E, C2, C4 = integrals(A, body.I, M, B)
    chk('ctl', not ser_is_const(Pis, N - 1), 'ctl-S elliptic: commutator sign reversed: Pi_s NOT conserved')
    chk('ctl', not ser_is_const(point_momentum(A, M, epts), N - 2), 'ctl-S elliptic: commutator sign reversed: point momenta NOT conserved')
    chk('bit', ser_is_const(E, N - 1) and ser_is_const(C2, N - 1) and ser_is_const(C4, N - 1), 'ctl-S elliptic (blindness): E, <PP>_0, <PP>_4 still constant with the reversed sign')
    # the naive engine body: weight-1 points with mass mu
    nb = Body(A, [(mu, q) for mu, q in pts]); M, B = engine_flow(A, nb.I, nb.Iinv, B0, N - 1)
    chk('ctl', not ser_is_const(point_momentum(A, M, epts), N - 2), 'ctl-W elliptic: naive engine body (weight-1 points, mass mu) read as mass mu at normalised points: momenta NOT conserved')
    chk('bit', ser_is_const(point_momentum(A, M, [(mu, q) for mu, q in pts]), N - 2), 'naive engine body = normalised points with masses mu (1 + kappa|q|^2) (momentum weight lambda^2): conserved')
    tline('part d')

    # ======================================================================================== 3. Gunn ch. 11: polhode; linear stability
    head('3. Gunn ch. 11: the polhode of the 2D symmetric body (1, 1, 2); linear stability of pure rotations (ours)')
    for k in (1, 0, -1):
        A2 = eng_alg(k, 2); pts2 = [(F(1), [sx * F(1, 2), sy * F(1, 2)]) for sx in (1, -1) for sy in (1, -1)]
        b2 = body_n(A2, k, pts2); S2 = sigma_engine(A2, b2.I, GB2)
        Mm, M12 = S2[0][0], S2[2][2]; nu = 2 * (Mm - k * M12) / Mm
        chk('bit', S2[0][0] == S2[1][1] and all(S2[i][j] == 0 for i in range(3) for j in range(3) if i != j), '%s 2D body (1,1,2): A diagonal with M01 = M02' % NAME[k])
        chk('bit==std', nu == {1: F(6, 5), 0: F(2), -1: F(10, 3)}[k], '%s: polhode rate 2(M - kappa M12)/M = %s (from the printed polhode equations of Gunn: 6/5, 2, 10/3)' % (NAME[k], nu))
        P0 = MV(A2.sq, {0b100: F(1), 0b001: F(4)}); B0 = b2.Iinv(P0); q12 = gread(B0.scale(OMF), GB2)[2]; B0 = B0.scale(1 / q12)
        Mt, Bt = engine_flow(A2, b2.I, b2.Iinv, B0, N, comm=eng_comm(A2))
        qs = [gread(c.scale(OMF), GB2) for c in Bt.c]; a0, b0_, _ = qs[0]
        from math import factorial
        cosv = [((-1) ** (t // 2) * nu ** t / factorial(t)) if t % 2 == 0 else F(0) for t in range(N + 1)]
        sinv = [((-1) ** (t // 2) * nu ** t / factorial(t)) if t % 2 == 1 else F(0) for t in range(N + 1)]
        ccw = all(qs[t][0] == a0 * cosv[t] - b0_ * sinv[t] and qs[t][1] == b0_ * cosv[t] + a0 * sinv[t] for t in range(N + 1))
        cw = all(qs[t][0] == a0 * cosv[t] + b0_ * sinv[t] and qs[t][1] == b0_ * cosv[t] - a0 * sinv[t] for t in range(N + 1))
        chk('bit==std', (ccw or cw) and all(qs[t][2] == (1 if t == 0 else 0) for t in range(N + 1)),
            '%s: with q12 = 1 (momentum line e2 + 4 e0) the velocity point (q01, q02) turns on a circle at rate %s, exact through t^%d; sense %s (Gunn\'s printed equations: CCW)' % (NAME[k], nu, N, 'CCW' if ccw else ('CW' if cw else 'none')))
    import numpy as np
    def rsqrt(x):
        x = F(x)
        if x < 0: return None
        from math import isqrt
        n, d = isqrt(x.numerator), isqrt(x.denominator)
        return F(n, d) if n * n == x.numerator and d * d == x.denominator else None
    def boxpts(xyzw): x, y, z, w = [F(c) for c in xyzw]; return [(F(1), [sx * x / w, sy * y / w, sz * z / w]) for sx in (1, -1) for sy in (1, -1) for sz in (1, -1)]
    lab = ['e01', 'e02', 'e03', 'e12', 'e31', 'e23']
    RULE = {}
    for ibox, xyzw in enumerate([(1, 2, 3, 4), (3, 1, 2, 4), (2, 4, 6, 5)]):
        for k in (0, 1, -1):
            if k == -1 and xyzw[3] ** 2 <= sum(c * c for c in xyzw[:3]): continue          # improper hyperbolic box: skipped
            A = eng_alg(k); bp = boxpts(xyzw); bb = body_n(A, k, bp); Sg = sigma_engine(A, bb.I); STAB = {}
            chk('bit', all(Sg[i][j] == 0 for i in range(6) for j in range(6) if i != j), '%s box (x,y,z,w) = %s: A diagonal, moments %s' % (NAME[k], xyzw, [str(Sg[i][i]) for i in range(6)]))
            stat = True
            for a_ in range(6):
                Bs = gvec(A, unit(a_)); PB = bb.I(Bs); cm = eng_comm(A); stat &= not bb.Iinv(cm(Bs, PB)).d
                Jm = [[gread(bb.Iinv(cm(gvec(A, unit(j)), PB) + cm(Bs, bb.I(gvec(A, unit(j))))))[i] for j in range(6)] for i in range(6)]
                STAB[a_] = charpoly(Jm)
            chk('bit', stat, '%s box %s: the six pure motions b_a (unit) are stationary points of the Euler flow' % (NAME[k], xyzw))
            unst = {}
            for a_ in range(6):
                cp = STAB[a_]; c2, c4, c6 = cp[2], cp[4], cp[6]
                chk('bit', all(cp[i] == 0 for i in range(1, 7, 2)) and c6 == 0, '%s box %s %s: det(l - J) even in l, l^2 = 0 a root' % (NAME[k], xyzw, lab[a_]))
                dsc = c2 * c2 - 4 * c4; r = rsqrt(dsc)
                mus = sorted([F(0), (-c2 - r) / 2, (-c2 + r) / 2]) if r is not None else None
                fl = sorted((complex(z) for z in np.roots([1.0, float(c2), float(c4), float(c6)])), key=lambda z: (z.real, z.imag))
                unst[a_] = any(abs(z.imag) > 1e-12 or z.real > 1e-12 for z in fl)
                print('    %-10s box %s %s: l^2 roots %s  -> %s' % (NAME[k], xyzw, lab[a_], [str(m_) for m_ in mus] if mus else ['%.4g' % z.real for z in fl], 'UNSTABLE' if unst[a_] else 'linearly stable'))
            js = [sum(me * v[i] * v[i] for me, v in [(me, [F(1)] + q) for me, q in engine_pts(k, bp)]) for i in range(4)]
            lam = [k * js[0]] + js[1:]
            rule = {i: any(min(lam[pa], lam[pb]) < lam[c] < max(lam[pa], lam[pb]) for c in range(4) if c not in (pa, pb)) for i, (pa, pb) in enumerate(PAIRS4)}
            RULE[(ibox, k)] = (unst, rule)
            if k == 0:
                I1, I2, I3 = Sg[5][5], Sg[4][4], Sg[3][3]
                pred = {3: (I3 - I1) * (I2 - I3) / (I1 * I2), 4: (I2 - I3) * (I1 - I2) / (I3 * I1), 5: (I1 - I2) * (I3 - I1) / (I2 * I3)}
                Q = lambda a_, x: x ** 3 + STAB[a_][2] * x ** 2 + STAB[a_][4] * x + STAB[a_][6]
                chk('bit==std', all(Q(a_, pred[a_]) == 0 and Q(a_, F(-1)) == 0 for a_ in (3, 4, 5)),
                    'Euclid box %s (control): rotations e23, e31, e12: l^2 roots = {0, -1 (body momentum turning), textbook (I_k - I_i)(I_j - I_k)/(I_i I_j) = %s}' % (xyzw, [str(pred[a_]) for a_ in (5, 4, 3)]))
                mid = sorted([(I1, 5), (I2, 4), (I3, 3)])[1][1]
                chk('bit', all(unst[a_] == (a_ == mid) for a_ in (3, 4, 5)) and all(STAB[a_][2:] == [0] * 5 for a_ in (0, 1, 2)),
                    'Euclid box %s: only the rotation about the axis of the middle moment (%s) is unstable (tennis racket); translations: all eigenvalues 0' % (xyzw, lab[mid]))
            else:
                chk('bit', all(unst[i] == rule[i] for i in range(6)),
                    '%s box %s: unstable planes %s = planes (a,b) with another eigenvalue of J eta, (kappa j0, j1, j2, j3) = %s, strictly between (rule %s)' % (NAME[k], xyzw,
                    [lab[i] for i in range(6) if unst[i]], [str(x) for x in lam], 'found on box 1' if ibox == 0 else ('predicted; box 2 permutes the j of box 1' if ibox == 1 else 'PREDICTED; box 3: elliptic j0 between the spatial j, a new ordering')))
    tline('part 3')
finish('G1' + ('-' + FAULT if FAULT else '') + ('-quick' if QUICK else ''))
