#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G3, parts P1..P4.  Invariants of the N-body flow of the page example (Sun and five planets), Kepler's third law from the flow,
the wrong-exponent control, and the page table against the constants in the Horizons headers.   python3 g3_nbody.py

 Tags in this step (there is no gravity engine in it):
   [bit]      exact arithmetic on the Atlas's own numbers (Fraction / Decimal from the printed decimals) or the Atlas's own code (pgadyn_selfcheck.planets_rows, the page's JavaScript RK4)
   [std]      an independent float64 route that never touches the Atlas code (numpy / scipy DOP853, Kepler's equation, quadrature, the Horizons header values)
   [bit==std] the two compared        [ctl] a wrong version that must fail (the line is ok when it does fail)
 Nothing is bent to pass: a FAIL line is a result."""
import sys, os, time, json, math, subprocess
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from b1lib import head, chk, finish
import numpy as np
from fractions import Fraction as Fr
from decimal import Decimal, getcontext
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
import g3_lib as lib

NUM = {}                      # the numbers of the run (written to logs/g3_nbody.numbers.json)
OUT = os.path.join(lib.G2, 'logs', 'g3_nbody.numbers.json')
YEAR = 365.25 * 86400.0
T30 = 30 * YEAR
AU = lib.AU_KM

# ----------------------------------------------------------------------------------------------------------------- P1
def part1(m, x, v):
    head('P1  the page table against the constants in the Horizons headers (data classes: page table; Horizons observer-table headers)')
    t0 = time.time()
    pg = lib.atlas_module(); getcontext().prec = 60
    sun, mer, ven = lib.hz_header('sun'), lib.hz_header('mercury'), lib.hz_header('venus')
    GMs, GMm, GMv = Fr(sun['GM']), Fr(mer['GM']), Fr(ven['GM'])
    print('  headers: GM_Sun %s  GM_Mercury %s  GM_Venus %s  ratio Sun/Mercury %s  Sun/Venus %s  T_sid Mercury %s d  Venus %s d' % (sun['GM'], mer['GM'], ven['GM'], mer['ratio'], ven['ratio'], mer['T_sid_d'], ven['T_sid_d']))
    # (a) GM of the Sun
    GA = Fr('6.6723E-11') * Fr('1.988544E30') / 10 ** 9
    rel = GA / GMs - 1
    NUM['GM_atlas_km3s2'] = float(GA); NUM['GM_hdr_km3s2'] = float(GMs); NUM['GM_rel'] = float(rel)
    chk('bit', True, 'GM_Sun(Atlas) = G M_Sun = 6.6723E-11 x 1.988544E30 = %.9e km^3/s^2 (exact Fraction); header GM_Sun = %s' % (float(GA), sun['GM']))
    chk('bit==std', abs(float(GA) / (lib.G_ATLAS * 1.988544e30) - 1) < 1e-15, 'the exact product equals the float64 product G_ATLAS x M_sun to 1e-15')
    chk('std', -3e-4 < float(rel) < -1.5e-4, 'GM_Sun(Atlas)/GM_Sun(header) - 1 = %+.4e  (pre-declared in (-3e-4, -1.5e-4))' % float(rel))
    chk('ctl', not abs(float(GMs * Fr(1001, 1000) / GMs - 1)) < 5e-4, 'control: a header GM doctored by +1e-3 is outside the 5e-4 band used below (the band discriminates)')
    # (b) mass ratios
    rM = Fr('1.988544E30') / Fr('3.302E23') / Fr(mer['ratio']) - 1
    rV = Fr('1.988544E30') / Fr('48.685E23') / Fr(ven['ratio']) - 1
    NUM['ratio_rel'] = {'Mercury': float(rM), 'Venus': float(rV)}
    chk('std', -5e-4 < float(rM) < 0 and -5e-4 < float(rV) < 0, 'mass ratio Sun/planet from the table masses vs header: Mercury %+.3e (%.1f vs %s), Venus %+.3e (%.1f vs %s); both low, inside 5e-4' % (float(rM), float(Fr('1.988544E30') / Fr('3.302E23')), mer['ratio'], float(rV), float(Fr('1.988544E30') / Fr('48.685E23')), ven['ratio']))
    # (c) osculating periods
    NUM['T_osc'] = {}
    for k, nm, h in ((1, 'Mercury', mer), (2, 'Venus', ven)):
        r = x[k] - x[0]; w = v[k] - v[0]; Ts = float(h['T_sid_d']) * 86400.0
        mu_h = float(GMs + Fr(h['GM'])); mu_A = lib.G_ATLAS * (m[0] + m[k])
        eh = lib.kepler_elements(r, w, mu_h); eA = lib.kepler_elements(r, w, mu_A)
        # [bit] route: Decimal vis-viva from the printed digits; second formula a = h^2/(mu (1-e^2)) from the angular momentum and the Laplace vector (float)
        T = atlas_table_dec(); rr = [T['x'][k][c] - T['x'][0][c] for c in range(3)]; ww = [T['v'][k][c] - T['v'][0][c] for c in range(3)]
        r2 = sum(c * c for c in rr); v2 = sum(c * c for c in ww); mu_d = Decimal(sun['GM']) + Decimal(h['GM'])
        a_d = 1 / (2 / r2.sqrt() - v2 / mu_d)
        a_he = float(np.linalg.norm(eh['h']) ** 2 / (mu_h * (1 - eh['e'] ** 2)))
        chk('bit==std', abs(float(a_d) / eh['a'] - 1) < 1e-12 and abs(a_he / eh['a'] - 1) < 1e-12, '%s: a(osc) Decimal vis-viva %.6f km = float %.6f km = h^2/(mu(1-e^2)) %.6f km (1e-12)' % (nm, float(a_d), eh['a'], a_he))
        dH, dA = eh['T'] / Ts - 1, eA['T'] / Ts - 1
        NUM['T_osc'][nm] = dict(a_AU_hdr=eh['a'] / AU, e=eh['e'], T_hdr_GM_d=eh['T'] / 86400, T_atlasG_d=eA['T'] / 86400, T_sid_d=Ts / 86400, rel_hdr=dH, rel_atlas=dA)
        chk('std', abs(dH) < 5e-4, '%s: osculating period (header GM) %.6f d vs sidereal %.8f d: %+.3e (pre-declared 5e-4; e = %.4f)' % (nm, eh['T'] / 86400, Ts / 86400, dH, eh['e']))
        chk('std', abs(dA) < 2e-3, '%s: osculating period (Atlas G, G (M+m)) %.6f d vs sidereal: %+.3e (pre-declared 2e-3)' % (nm, eA['T'] / 86400, dA))
        # (d, part) STD_A against the header period
        a_hdr_AU = (mu_h * (Ts / (2 * math.pi)) ** 2) ** (1 / 3) / AU
        std = float(pg.STD_A[nm]); NUM['T_osc'][nm]['a_from_period_AU'] = a_hdr_AU; NUM['T_osc'][nm]['STD_A'] = std
        chk('std', abs(a_hdr_AU / std - 1) < 5e-5, '%s: STD_A (from memory) %.6f au vs a from the header sidereal period and GM %.6f au: %+.2e (pre-declared 5e-5)' % (nm, std, a_hdr_AU, a_hdr_AU / std - 1))
    r = x[2] - x[0]; w = v[2] - v[0]
    Tven_as_mer = lib.kepler_elements(r, w, float(GMs + GMm))['T'] / 86400
    chk('ctl', abs(Tven_as_mer / float(mer['T_sid_d']) - 1) > 0.5, 'control: the period of Venus\'s state compared with Mercury\'s sidereal period is off by %+.2f (fails the 5e-4 band, as it must)' % (Tven_as_mer / float(mer['T_sid_d']) - 1))
    # (d) the Atlas's claim N9
    try:
        n9 = pg.planets_rows(); n9ok = True
    except AssertionError as ex:
        n9 = {}; n9ok = False; print('  Atlas N9 assertion failed:', ex)
    chk('bit', n9ok, 'the Atlas\'s own planets_rows() (row N9) runs and holds as published: worst a error %s, momentum fraction %s' % (n9.get('worst_a_error'), n9.get('momentum_fraction')))
    worst = 0.0; same = True; NUM['N9'] = {}
    for k in range(1, 6):
        nm = lib.NAMES[k]; r = x[k] - x[0]; w = v[k] - v[0]; mu_A = lib.G_ATLAS * (m[0] + m[k])
        el = lib.kepler_elements(r, w, mu_A); a_AU = el['a'] / AU; std = float(pg.STD_A[nm]); dev = a_AU / std - 1; worst = max(worst, abs(dev))
        same &= ('%.4f' % a_AU) == n9[nm]['a_AU'] if n9ok else False
        NUM['N9'][nm] = dict(r_AU=el['r'] / AU, a_AU=a_AU, e=el['e'], STD_A=std, dev=dev, T_osc_d=el['T'] / 86400)
        print('  %-8s r = %.4f au  a(osc, Atlas G) = %.4f au  STD_A = %.6f  deviation %+.3f %%  e = %.4f  T(osc) = %.3f d' % (nm, el['r'] / AU, a_AU, std, 100 * dev, el['e'], el['T'] / 86400))
    NUM['N9']['worst_dev'] = worst; NUM['N9_momentum_fraction'] = n9.get('momentum_fraction')
    chk('bit==std', n9ok and n9['Earth']['r_AU'] == '0.9837' and n9['Earth']['speed_kms'] == '30.29' and abs(float(NUM['N9']['Earth']['r_AU']) - 0.9837) < 6e-5, 'the Earth line of N9 (0.984 au from the Sun, 30.29 km/s) is reproduced: r = %.4f au, speed %.2f km/s' % (NUM['N9']['Earth']['r_AU'], float(np.linalg.norm(v[3] - v[0]))))
    chk('bit==std', same, 'my float64 osculating a (4 decimals) equals the a_AU printed by the Atlas code for all five planets')
    chk('std', worst < 2e-3, 'N9: worst |a/STD_A - 1| = %.4f %% < 0.2 %% (the Atlas prints %s)' % (100 * worst, n9.get('worst_a_error')))
    sa = dict(pg.STD_A); sa['Mars'] = sa['Mars'] * Decimal('1.005')
    wd = max(abs(NUM['N9'][lib.NAMES[k]]['a_AU'] / float(sa[lib.NAMES[k]]) - 1) for k in range(1, 6))
    chk('ctl', wd > 2e-3, 'control: STD_A of Mars doctored by +0.5 %% makes the 0.2 %% test fail (worst %.3f %%)' % (100 * wd))
    print('  [time] P1 %.1f s' % (time.time() - t0))

def atlas_table_dec():
    m, x, v = lib.table_decimal(); return dict(m=m, x=x, v=v)

# ----------------------------------------------------------------------------------------------------------------- P2
def exact_residuals(power, twist=0, reaction=True, prec=60):
    """the identities dP/dt = dL/dt = 0 and dE/dt = 0 at the table state, in `prec`-digit Decimal; relative to natural scales"""
    getcontext().prec = prec
    m, x, v = lib.table_decimal(); G = Decimal('6.6723E-20'); N = 6; pw = Decimal(str(power)); D0 = Decimal(0)
    a = [[D0] * 3 for _ in range(N)]
    for i in range(N):
        for j in range(N):
            if i == j or ((not reaction) and j < i): continue
            r = [x[j][c] - x[i][c] for c in range(3)]; d = sum(c * c for c in r).sqrt(); f = G * m[j] / d ** pw
            for c in range(3): a[i][c] += f * r[c]
            if twist: a[i][0] += Decimal(twist) * f * (-r[1]); a[i][1] += Decimal(twist) * f * r[0]
    nrm = lambda u: sum(c * c for c in u).sqrt()
    P = [sum(m[i] * a[i][c] for i in range(N)) for c in range(3)]
    Lm = [sum(m[i] * (x[i][(c + 1) % 3] * a[i][(c + 2) % 3] - x[i][(c + 2) % 3] * a[i][(c + 1) % 3]) for i in range(N)) for c in range(3)]
    sP = sum(m[i] * nrm(a[i]) for i in range(N)); sL = sum(m[i] * nrm(x[i]) * nrm(a[i]) for i in range(N)); sE = sum(m[i] * nrm(v[i]) * nrm(a[i]) for i in range(N))
    kin = sum(m[i] * sum(v[i][c] * a[i][c] for c in range(3)) for i in range(N))
    def dEdt(q):
        pot = D0; qq = Decimal(str(q))
        for i in range(N):
            for j in range(i + 1, N):
                r = [x[j][c] - x[i][c] for c in range(3)]; d = sum(c * c for c in r).sqrt(); dv = [v[j][c] - v[i][c] for c in range(3)]
                pot += G * m[i] * m[j] * sum(r[c] * dv[c] for c in range(3)) / d ** qq
        return (kin + pot) / sE
    res = dict(P=float(nrm(P) / sP), L=float(nrm(Lm) / sL), E_newton=float(abs(dEdt(3))), E_matching=float(abs(dEdt(power))))
    getcontext().prec = 60
    return res

def inv_series(Y, m, G, power):
    n = len(m); X = Y[:3 * n].T.reshape(-1, n, 3); V = Y[3 * n:].T.reshape(-1, n, 3)
    P = (m[None, :, None] * V).sum(1); Lm = (m[None, :, None] * np.cross(X, V)).sum(1)
    K = 0.5 * (m[None, :] * (V * V).sum(-1)).sum(1)
    D = np.sqrt(((X[:, :, None, :] - X[:, None, :, :]) ** 2).sum(-1)); iu = np.triu_indices(n, 1); d = D[:, iu[0], iu[1]]; mm = (m[:, None] * m[None, :])[iu]
    U = -(G * mm[None, :] * d ** (2.0 - power) / (power - 2.0)).sum(1); UN = -(G * mm[None, :] / d).sum(1)
    R = (m[None, :, None] * X).sum(1) / m.sum()
    return dict(P=P, L=Lm, K=K, E=K + U, EN=K + UN, R=R)

def deviations(t, S, m):
    """max relative deviations of the invariants along a series (S from inv_series)"""
    P0, L0, E0, EN0 = S['P'][0], S['L'][0], S['E'][0], S['EN'][0]; M = m.sum(); V0 = P0 / M
    nr = lambda a: np.linalg.norm(a, axis=-1)
    dR = S['R'] - S['R'][0] - V0[None, :] * t[:, None]
    return dict(dP=float((nr(S['P'] - P0) / np.linalg.norm(P0)).max()), dL=float((nr(S['L'] - L0) / np.linalg.norm(L0)).max()), dLc=[float((np.abs(S['L'][:, c] - L0[c]) / np.linalg.norm(L0)).max()) for c in range(3)],
                dE=float((np.abs(S['E'] - E0) / abs(E0)).max()), dEN=float((np.abs(S['EN'] - EN0) / abs(EN0)).max()),
                dCOM=float(nr(dR).max() / (np.linalg.norm(V0) * t[-1])), L0=float(np.linalg.norm(L0)), P0=float(np.linalg.norm(P0)), E0=float(E0))

def dop_run(m, x, v, G, power, T, rtol=1e-13, dense=False):
    t0 = time.time(); sol = lib.flow(x, v, T, G * m, power, rtol=rtol, dense=dense)
    S = inv_series(sol.y, m, G, power); d = deviations(sol.t, S, m); d.update(steps=len(sol.t) - 1, nfev=int(sol.nfev), secs=time.time() - t0, success=bool(sol.success))
    return sol, S, d

def rk4_run(m, x0, v0, G, h, T, power=3.0, nsamp=600):
    mu = G * m; n = int(round(T / h)); every = max(1, n // nsamp); x, v = x0.copy(), v0.copy(); ts = [0.0]; Ys = [np.concatenate([x.ravel(), v.ravel()])]
    for k in range(1, n + 1):
        x, v = lib.rk4_step(x, v, mu, h, power)
        if k % every == 0 or k == n: ts.append(k * h); Ys.append(np.concatenate([x.ravel(), v.ravel()]))
    return np.array(ts), np.array(Ys).T, (x, v)

def part2(m, x, v):
    head('P2  invariants of the six-body flow (Sun, Mercury, Venus, Earth, Mars, Jupiter; the page\'s force law, power 3; 30 years)')
    t0 = time.time(); G = lib.G_ATLAS
    # (0) my float64 force law against the Atlas's exact PGA `accel` (Fractions, ideal vectors of the points) on the Atlas's own integer-separation data
    pg = lib.atlas_module(); A3 = pg.Alg(3); xs, ms = pg.newton_data(3); ps = [A3.point([Fr(c) for c in xx]) for xx in xs]; Gf = Fr(3, 2); worst = 0.0
    for power, twist in ((3, 0), (2, 0), (3, 1)):
        ex = pg.accel(A3, ps, ms, Gf, power, twist); mine = lib.acc(np.array(xs, float), float(Gf) * np.array([float(q) for q in ms]), float(power), twist=float(twist))
        exf = np.array([[float(c) for c in row_] for row_ in ex]); worst = max(worst, float(np.abs(exf - mine).max() / np.abs(exf).max()))
    chk('bit==std', worst < 1e-14, 'my float64 force law equals the Atlas\'s exact PGA accel (exponent 3, exponent 2, and with the perpendicular twist) on the 4-body 5-12-13 data to %.1e relative' % worst)
    # (i) exact identities at the table state
    ex3 = exact_residuals(3); NUM['exact_p3'] = ex3
    chk('bit', max(ex3.values()) < 1e-40, 'exact identities at the table state (60-digit Decimal): |dP/dt| %.1e, |dL/dt| %.1e, |dE/dt| %.1e (natural scales), pre-declared < 1e-40' % (ex3['P'], ex3['L'], ex3['E_newton']))
    # (ii) DOP853 over 30 years
    sol, S, d = dop_run(m, x, v, G, 3.0, T30, dense=True); NUM['dop_p3'] = d
    print('  DOP853 rtol 1e-13: %d steps, %d RHS calls, %.1f s;  |P0| = %.4e kg km/s (%.3f of sum m|v|),  |L0| = %.4e,  E0 = %.4e' % (d['steps'], d['nfev'], d['secs'], d['P0'], d['P0'] / float((m * np.linalg.norm(v, axis=1)).sum()), d['L0'], d['E0']))
    frac = d['P0'] / float((m * np.linalg.norm(v, axis=1)).sum())
    chk('bit==std', abs(frac - float(NUM['N9_momentum_fraction'])) < 1e-3, 'total momentum / sum m|v| = %.4f equals the 0.102 of the Atlas (N9): the six bodies drift as a whole because the outer planets are missing' % frac)
    chk('std', d['success'] and d['dP'] < 1e-12, 'momentum |P(t) - P(0)|/|P0| max over the steps = %.2e  (pre-declared < 1e-12)' % d['dP'])
    chk('std', d['dL'] < 1e-11, 'angular momentum (3 components, norm of the vector difference)/|L0| max = %.2e  (< 1e-11); per component (x, y, z)/|L0|: %.1e, %.1e, %.1e; L0 direction (%.4f, %.4f, %.4f)' % ((d['dL'],) + tuple(d['dLc']) + tuple(S['L'][0] / np.linalg.norm(S['L'][0]))))
    chk('std', d['dE'] < 1e-11, 'energy |E(t) - E(0)|/|E0| max = %.2e  (< 1e-11)' % d['dE'])
    chk('std', d['dCOM'] < 1e-9, 'centre of mass on a straight line R(t) = R(0) + P0 t/M: max deviation / (|V| T) = %.2e  (< 1e-9); total momentum is NOT zero: the centre of mass drifts at %.3e km/s' % (d['dCOM'], d['P0'] / m.sum()))
    sol2, S2, d2 = dop_run(m, x, v, G, 3.0, T30, rtol=1e-11); NUM['dop_p3_rtol1e-11'] = d2
    print('  DOP853 rtol 1e-11: %d steps; dP %.2e dL %.2e dE %.2e' % (d2['steps'], d2['dP'], d2['dL'], d2['dE']))
    chk('std', d2['dE'] >= 0.5 * d['dE'] and d2['dL'] >= 0.5 * d['dL'], 'the measured drift is the integrator\'s: loosening rtol from 1e-13 to 1e-11 does not reduce it (dE %.2e -> %.2e, dL %.2e -> %.2e)' % (d['dE'], d2['dE'], d['dL'], d2['dL']))
    yfin = sol.y[:, -1]; yfin2 = sol2.y[:, -1]
    NUM['dop_rtol_final_pos_diff_km'] = float(np.abs(yfin[:18] - yfin2[:18]).max())
    print('  final positions, rtol 1e-13 vs 1e-11: max difference %.3e km' % NUM['dop_rtol_final_pos_diff_km'])
    # (iii) the page's own JavaScript RK4 against my Python RK4 (same algorithm) and the page's energy function
    h = 14400.0; steps = 2000; every = 100
    inp = json.dumps(dict(x=x.tolist(), v=v.tolist(), mass=m.tolist(), G=G, h=h, steps=steps, every=every))
    pr = subprocess.run(['node', lib.NODE_RUN], input=inp, capture_output=True, text=True, timeout=300)
    chk('bit', pr.returncode == 0 and len(pr.stdout) > 100, 'the page\'s own rk4Bodies / energyBodies (pgaEngine.js, imported unchanged, run under node) produced %d characters of output' % len(pr.stdout))
    js = json.loads(pr.stdout)
    xp, vp = x.copy(), v.copy(); mu = G * m; mx = 0.0; mxE = 0.0
    scale = np.maximum(np.linalg.norm(x, axis=1), 1e6)           # km: orbit scale of each body, 1e6 km for the Sun
    for k in range(1, steps + 1):
        xp, vp = lib.rk4_step(xp, vp, mu, h)
        if k % every == 0:
            i = k // every; mx = max(mx, float((np.linalg.norm(np.array(js['x'][i]) - xp, axis=1) / scale).max())); Ep = lib.invariants(xp, vp, m, G)['E']; mxE = max(mxE, abs(js['E'][i] / Ep - 1))
    chk('bit==std', mx < 1e-9, 'page RK4 (JS, pgaEngine.js unchanged) vs my Python RK4, 2000 steps of 14400 s: max position difference / orbit scale = %.3e (pre-declared < 1e-9)' % mx)
    chk('bit==std', mxE < 1e-12, 'the page\'s energyBodies (K + U) equals my energy to %.2e relative at the 20 sample points (< 1e-12)' % mxE)
    NUM['js_vs_py_rk4'] = dict(max_pos_rel=mx, max_E_rel=mxE)
    # (iv) RK4 at three steps over 30 years
    NUM['rk4'] = {}
    mdrift = {}
    for hh in (7200.0, 14400.0, 43200.0, 86400.0):
        t1 = time.time(); ts, Y, (xf, vf) = rk4_run(m, x, v, G, hh, T30)
        Sr = inv_series(Y, m, G, 3.0); dr = deviations(ts, Sr, m)
        slope = np.polyfit(ts, (Sr['E'] - Sr['E'][0]) / abs(Sr['E'][0]), 1)[0]
        per_earth = slope * 365.25 * 86400; per_merc = slope * 87.969257 * 86400
        yref = sol.sol(ts[-1])                                           # DOP853 dense output at the RK4's last time (ts[-1] = n h, within h/2 of 30 years)
        dpos = float(np.linalg.norm((Y[:18, -1] - yref[:18]).reshape(6, 3), axis=1).max())
        e_err = float(np.linalg.norm(Y[3 * 3:3 * 4, -1] - yref[3 * 3:3 * 4])); m_err = float(np.linalg.norm(Y[3:6, -1] - yref[3:6]))
        NUM['rk4'][str(int(hh))] = dict(dP=dr['dP'], dL=dr['dL'], dE=dr['dE'], slope_per_s=float(slope), per_earth_orbit=float(per_earth), per_mercury_orbit=float(per_merc), max_pos_diff_vs_dop_km=dpos, earth_err_km=e_err, mercury_err_km=m_err, secs=time.time() - t1)
        mdrift[hh] = dr['dE']
        print('  RK4 h = %6.0f s (%d steps, %.0f s): dP %.1e dL %.1e max dE %.2e | secular dE/E per Earth orbit %+.2e, per Mercury orbit %+.2e | position vs DOP853 at 30 y: Earth %.3e km, Mercury %.3e km (worst body %.3e km)' % (hh, int(round(T30 / hh)), time.time() - t1, dr['dP'], dr['dL'], dr['dE'], per_earth, per_merc, e_err, m_err, dpos))
        chk('std', dr['dP'] < 1e-12, 'RK4 h = %.0f s keeps the momentum (a linear invariant) to %.1e' % (hh, dr['dP']))
    chk('std', mdrift[86400.0] > mdrift[43200.0] > mdrift[14400.0] > mdrift[7200.0], 'RK4 energy error grows with the step: %.2e (7200 s) < %.2e (14400 s) < %.2e (43200 s) < %.2e (86400 s)' % (mdrift[7200.0], mdrift[14400.0], mdrift[43200.0], mdrift[86400.0]))
    sl = [abs(NUM['rk4'][str(int(hh))]['per_earth_orbit']) for hh in (14400.0, 43200.0, 86400.0)]
    NUM['rk4_exponent_14400_86400'] = math.log(sl[2] / sl[0]) / math.log(86400.0 / 14400.0); NUM['rk4_exponent_14400_43200'] = math.log(sl[1] / sl[0]) / math.log(3.0)
    print('  RK4 secular energy drift per unit time scales as h^%.2f (14400 -> 43200 s) and h^%.2f (14400 -> 86400 s)' % (NUM['rk4_exponent_14400_43200'], NUM['rk4_exponent_14400_86400']))
    chk('std', mdrift[14400.0] > 10 * d['dE'], 'the page\'s RK4 at its default step (14400 s) is worse than DOP853 rtol 1e-13 in energy by a factor %.1e' % (mdrift[14400.0] / d['dE']))
    chk('bit==std', NUM['rk4']['7200']['max_pos_diff_vs_dop_km'] < 1e5, 'RK4 h = 7200 s and DOP853 (compared at the same time) end 30 years at positions that differ by at most %.3e km (pre-declared < 1e5 km for the smallest step)' % NUM['rk4']['7200']['max_pos_diff_vs_dop_km'])
    # (v) controls: non-central part, no back-reaction (exact, at the table state), a time-step control above
    twx = exact_residuals(3, twist=1); nrx = exact_residuals(3, reaction=False); NUM['exact_twist'] = twx; NUM['exact_noreaction'] = nrx
    chk('ctl', twx['L'] > 1e-3 and twx['P'] < 1e-40, 'control: a perpendicular (non-central) part breaks the angular momentum (relative dL/dt %.2e) and, being pairwise equal and opposite, not the momentum (%.1e), as the Atlas\'s N1' % (twx['L'], twx['P']))
    chk('ctl', nrx['P'] > 1e-3, 'control: dropping the back-reaction breaks the momentum (relative dP/dt %.2e)' % nrx['P'])
    # the float64 flow with a twist, one year: L is not conserved
    mu = G * m
    def rhs_tw(t, y):
        xx = y[:18].reshape(6, 3); return np.concatenate([y[18:], lib.acc(xx, mu, 3.0, twist=0.01).ravel()])
    sw = solve_ivp(rhs_tw, (0, YEAR), np.concatenate([x.ravel(), v.ravel()]), method='DOP853', rtol=1e-12, atol=np.concatenate([np.full(18, 1e-9), np.full(18, 1e-15)]))
    Sw = inv_series(sw.y, m, G, 3.0); dw = deviations(sw.t, Sw, m)
    chk('ctl', dw['dL'] > 1e-6 and dw['dL'] > 1e3 * d['dL'], 'control: with a 1 %% perpendicular part the flow changes L by %.2e over one year (DOP853 baseline for 30 y: %.2e)' % (dw['dL'], d['dL']))
    NUM['twist_flow_dL_1y'] = dw['dL']
    print('  [time] P2 %.1f s' % (time.time() - t0))
    return sol, S, d

# ----------------------------------------------------------------------------------------------------------------- P3 and P4
def pair_state(m, x, v, i):
    idx = [0, i]; return m[idx], x[idx], v[idx]

def turning_points(r0, v0, mu_p, p):
    r0 = np.asarray(r0, float); v0 = np.asarray(v0, float); r = np.linalg.norm(r0); Lz = np.linalg.norm(np.cross(r0, v0))
    V = lambda s: -mu_p * s ** (2.0 - p) / (p - 2.0)
    E = 0.5 * (v0 @ v0) + V(r)
    rad = lambda s: 2.0 * (E - V(s)) - Lz ** 2 / s ** 2
    def find(sign):
        s = r
        for k in range(1, 6000):
            s2 = r * math.exp(sign * 0.0005 * k)
            if rad(s2) <= 0: return brentq(rad, min(s, s2), max(s, s2), xtol=1e-13 * r, rtol=1e-15)
            s = s2
        raise RuntimeError('no turning point')
    return find(-1.0), find(+1.0), E, Lz, rad

def apsidal_quadrature(r0, v0, mu_p, p, N=32):
    """perihelion-to-perihelion angle minus 2 pi, by quadrature of the orbit equation in the effective potential (no differential equation integrated).
    N = 32 Gauss-Legendre nodes: the integrand is analytic in psi, so few nodes converge (N = 32 and 48 agree to 2e-9 rad); more nodes lose digits to the cancellation in the radicand at the end points (N = 400 gives 5.6e-8 rad at p = 3)."""
    rmin, rmax, E, Lz, rad = turning_points(r0, v0, mu_p, p)
    xg, wg = np.polynomial.legendre.leggauss(N); psi = 0.5 * math.pi * (xg + 1.0); w = 0.5 * math.pi * wg
    rr = 0.5 * (rmax + rmin) - 0.5 * (rmax - rmin) * np.cos(psi)
    f = Lz / rr ** 2 * (0.5 * (rmax - rmin) * np.sin(psi)) / np.sqrt(rad(rr))
    return 2.0 * float((w * f).sum()) - 2 * math.pi, rmin, rmax

def wrap(a): return (a + math.pi) % (2 * math.pi) - math.pi

def pair_flow(m, x, v, i, Gp, power, n_orb, T_guess):
    """two bodies (Sun and planet i) in the table frame; DOP853; ray-crossing times and perihelion passages"""
    m2, x2, v2 = pair_state(m, x, v, i); mu2 = Gp * m2
    r0 = x2[1] - x2[0]; w0 = v2[1] - v2[0]; u = r0 / np.linalg.norm(r0); Lh = np.cross(r0, w0); Lh /= np.linalg.norm(Lh); ww = np.cross(Lh, u)
    def ev_ray(t, y): return (y[3:6] - y[0:3]) @ ww
    ev_ray.direction = +1
    def ev_peri(t, y): return (y[3:6] - y[0:3]) @ (y[9:12] - y[6:9])
    ev_peri.direction = +1
    t_end = (n_orb + 2.2) * T_guess
    sol = lib.flow(x2, v2, t_end, mu2, power, events=[ev_ray, ev_peri])
    te = sol.t_events[0]; ts = te[te > 0.5 * T_guess]
    tp = sol.t_events[1]; yp = sol.y_events[1]
    th = []
    for yy in yp:
        rel = yy[3:6] - yy[0:3]; th.append(math.atan2(rel @ ww, rel @ u))
    adv = [wrap(th[k + 1] - th[k]) for k in range(len(th) - 1)]
    return dict(ts=ts, tp=tp, adv=adv, sol=sol, x2=x2, v2=v2, r0=r0, w0=w0, mu2=mu2, u=u, ww=ww)

def rk4_pair_period(m, x, v, i, G, h, n_orb, T_guess):
    """RK4 (the page's algorithm) on the pair; crossings of the initial ray located by cubic Hermite interpolation of the y coordinate"""
    m2, x2, v2 = pair_state(m, x, v, i); mu2 = G * m2
    r0 = x2[1] - x2[0]; w0 = v2[1] - v2[0]; u = r0 / np.linalg.norm(r0); Lh = np.cross(r0, w0); Lh /= np.linalg.norm(Lh); ww = np.cross(Lh, u)
    xx, vv = x2.copy(), v2.copy(); t = 0.0; cross = []
    yv = lambda xx, vv: ((xx[1] - xx[0]) @ ww, (vv[1] - vv[0]) @ ww, (xx[1] - xx[0]) @ u)
    y0, d0, x0_ = yv(xx, vv)
    while len(cross) < n_orb:
        xn, vn = lib.rk4_step(xx, vv, mu2, h); y1, d1, x1_ = yv(xn, vn)
        if y0 < 0 <= y1 and x1_ > 0 and t > 0.5 * T_guess:
            lo, hi = 0.0, 1.0
            def hf(s): return (2 * s ** 3 - 3 * s ** 2 + 1) * y0 + (s ** 3 - 2 * s ** 2 + s) * h * d0 + (-2 * s ** 3 + 3 * s ** 2) * y1 + (s ** 3 - s ** 2) * h * d1
            for _ in range(60):
                mid = 0.5 * (lo + hi)
                if hf(mid) < 0: lo = mid
                else: hi = mid
            cross.append(t + 0.5 * (lo + hi) * h)
        xx, vv, y0, d0, x0_, t = xn, vn, y1, d1, x1_, t + h
    return cross[n_orb - 1] / n_orb

NORB = {1: 10, 2: 6, 3: 5, 4: 4, 5: 3}

def part3(m, x, v):
    head('P3  Kepler III from the flow: each planet alone with the Sun (two bodies, both moving), T from successive crossings of the initial ray')
    t0 = time.time(); G = lib.G_ATLAS; NUM['kepler3'] = {}
    Q = {}; Ts = {}; As = {}
    for i in range(1, 6):
        nm = lib.NAMES[i]; m2, x2, v2 = pair_state(m, x, v, i); mu = G * (m2[0] + m2[1]); el = lib.kepler_elements(x2[1] - x2[0], v2[1] - v2[0], mu)
        pf = pair_flow(m, x, v, i, G, 3.0, NORB[i], el['T'])
        ts = pf['ts']; ok_n = len(ts) >= NORB[i]
        T = ts[NORB[i] - 1] / NORB[i]; ratio = T ** 2 / el['a'] ** 3 * mu / (4 * math.pi ** 2)
        spread = float(np.max(np.abs(np.diff(np.concatenate([[0.0], ts[:NORB[i]]])) / el['T'] - 1)))
        # a constant along the flow
        Y = pf['sol'].y; rel = Y[3:6] - Y[0:3]; wl = Y[9:12] - Y[6:9]; rr = np.linalg.norm(rel, axis=0); vv2 = (wl * wl).sum(0); a_t = 1.0 / (2.0 / rr - vv2 / mu)
        da = float(np.abs(a_t / el['a'] - 1).max())
        # Kepler's equation route (no ODE): position after one formula period and after 3.7 periods against the flow
        te_ = [el['T'], 3.7 * el['T']]
        sol_e = lib.flow(x2, v2, 3.7 * el['T'] + 1.0, G * m2, 3.0, t_eval=te_)
        perr = []
        for k_, tt in enumerate(te_):
            pk, _ = lib.kepler_propagate(x2[1] - x2[0], v2[1] - v2[0], mu, tt); pf_ = sol_e.y[3:6, k_] - sol_e.y[0:3, k_]
            perr.append(float(np.linalg.norm(pk - pf_) / el['a']))
        t1 = time.time(); T4 = rk4_pair_period(m, x, v, i, G, 14400.0, NORB[i], el['T']); r4 = T4 ** 2 / el['a'] ** 3 * mu / (4 * math.pi ** 2)
        Q[nm] = ratio; Ts[nm] = T; As[nm] = el['a']
        NUM['kepler3'][nm] = dict(a_AU=el['a'] / AU, e=el['e'], T_formula_d=el['T'] / 86400, T_flow_d=T / 86400, n_orb=NORB[i], ratio_minus1=ratio - 1, rk4_ratio_minus1=r4 - 1, T_rk4_d=T4 / 86400,
                                   successive_period_spread=spread, a_const=da, kepler_eq_pos_err=perr)
        print('  %-8s a = %.5f au  e = %.4f  T(formula) = %.6f d  T(flow, %d crossings) = %.6f d  | T^2 mu/(4 pi^2 a^3) - 1: DOP853 %+.2e, RK4(14400 s) %+.2e | |a(t)/a0 - 1| max %.1e | Kepler-equation position error after 1 and 3.7 periods %.1e, %.1e a' % (nm, el['a'] / AU, el['e'], el['T'] / 86400, NORB[i], T / 86400, ratio - 1, r4 - 1, da, perr[0], perr[1]))
        chk('std', ok_n and abs(ratio - 1) < 1e-9, '%s: T^2/a^3 = 4 pi^2/(G (M + m)) to %.2e with DOP853 rtol 1e-13 (pre-declared < 1e-9)' % (nm, abs(ratio - 1)))
        chk('bit==std', abs(r4 - 1) < 1e-5, '%s: with the page\'s RK4 at 14400 s the same ratio is off by %.2e (pre-declared < 1e-5)' % (nm, abs(r4 - 1)))
        chk('std', da < 1e-10 and max(perr) < 1e-9, '%s: osculating a constant along the flow to %.1e; the Kepler-equation propagator reproduces the flow after 1 and 3.7 periods to %.1e a (< 1e-9)' % (nm, da, max(perr)))
    vals = np.array(list(Q.values())); sp = float(vals.max() - vals.min())
    la = np.log([As[k] for k in lib.NAMES[1:]]); lt = np.log([Ts[k] for k in lib.NAMES[1:]]); slope = float(np.polyfit(la, lt, 1)[0])
    mus = np.array([G * (m[0] + m[i]) for i in range(1, 6)]); slope_mu = float(np.polyfit(la, lt + 0.5 * np.log(mus), 1)[0]); slope_pred = float(np.polyfit(la, 1.5 * la - 0.5 * np.log(mus), 1)[0])
    NUM['kepler3_spread'] = sp; NUM['kepler3_slope_raw'] = slope; NUM['kepler3_slope_raw_predicted'] = slope_pred; NUM['kepler3_slope_with_mu'] = slope_mu
    chk('std', sp < 1e-9, 'the five ratios T^2 mu/(4 pi^2 a^3) agree with each other to %.2e (< 1e-9): T^2/a^3 is the same for all planets once mu = G (M + m) is used' % sp)
    chk('std', abs(slope_mu - 1.5) < 1e-9, 'slope of ln(T sqrt(mu)) on ln a over the five planets = %.12f (1.5 to 1e-9)' % slope_mu)
    chk('bit==std', abs(slope - slope_pred) < 1e-9, 'the raw slope of ln T on ln a is %.8f, not 1.5: the masses enter (Jupiter m/M = 9.5e-4); predicted from the masses alone %.8f (difference %.1e)' % (slope, slope_pred, abs(slope - slope_pred)))
    print('  [time] P3 %.1f s' % (time.time() - t0))

def part4(m, x, v, base):
    head('P4  control: wrong force exponent (force ~ d^-1.9 and d^-2.1; G rescaled so that the force at 1 au is unchanged)')
    t0 = time.time(); G = lib.G_ATLAS; NUM['wrong'] = {}
    for p in (2.9, 3.1):
        Gp = G * AU ** (p - 3.0)
        # six-body flow, 30 years
        sol, S, d = dop_run(m, x, v, Gp, p, T30); NUM['wrong'][str(p)] = dict(six=d)
        b = NUM['dop_p3']
        print('  p = %.1f six-body, DOP853 30 y: dP %.2e dL %.2e | Newtonian-form energy K - sum G m m/d: max change %.2e of |E| | matching-potential energy: %.2e' % (p, d['dP'], d['dL'], d['dEN'], d['dE']))
        chk('ctl', d['dP'] < 1e-12 and d['dL'] < max(10 * b['dL'], 1e-11), 'p = %.1f: P and L are conserved as well as for p = 3 (dP %.1e, dL %.1e vs %.1e): the invariants alone do not see the exponent' % (p, d['dP'], d['dL'], b['dL']))
        chk('ctl', d['dEN'] > 1e-4, 'p = %.1f: the Newtonian-form energy K - G m m/d changes by %.2e of |E| (> 1e-4): it does see the exponent' % (p, d['dEN']))
        chk('ctl', d['dE'] < 1e-10, 'p = %.1f: the energy with the matching potential -G m m d^(2-p)/(p-2) is conserved to %.1e (< 1e-10): the energy law still holds, with its own potential' % (p, d['dE']))
        ex = exact_residuals(p); NUM['wrong'][str(p)]['exact'] = ex
        chk('ctl', ex['P'] < 1e-40 and ex['L'] < 1e-40 and ex['E_matching'] < 1e-40 and ex['E_newton'] > 1e-6, 'p = %.1f exact (60 digits): dP/dt %.1e, dL/dt %.1e, dE_matching/dt %.1e (all zero), dE_newton/dt %.1e (not zero)' % (p, ex['P'], ex['L'], ex['E_matching'], ex['E_newton']))
        # two-body runs
        Qp = {}; adv_f = {}; rows = {}
        for i in range(1, 6):
            nm = lib.NAMES[i]; m2, x2, v2 = pair_state(m, x, v, i); muN = G * (m2[0] + m2[1]); mup = Gp * (m2[0] + m2[1])
            el = lib.kepler_elements(x2[1] - x2[0], v2[1] - v2[0], muN)
            rmin, rmax, E_, Lz_, rad_ = turning_points(x2[1] - x2[0], v2[1] - v2[0], mup, p); a_eff = 0.5 * (rmin + rmax)
            pf = pair_flow(m, x, v, i, Gp, p, NORB[i], 2 * math.pi * math.sqrt(a_eff ** 3 / muN) * (a_eff / AU) ** ((p - 3.0) / 2.0))
            n = NORB[i]; ts = pf['ts']
            if len(ts) < n: print('   ! %s: only %d crossings' % (nm, len(ts))); continue
            T = ts[n - 1] / n; Qi = T ** 2 * muN / (4 * math.pi ** 2 * a_eff ** 3)
            adv = float(np.mean(pf['adv'])); aq, _, _ = apsidal_quadrature(x2[1] - x2[0], v2[1] - v2[0], mup, p)
            k_ = p - 1.0; th = 2 * math.pi * (1 / math.sqrt(3 - k_) - 1)
            Qp[nm] = Qi; adv_f[nm] = (adv, aq, th)
            rows[nm] = dict(a_AU=a_eff / AU, e=el['e'], T_d=T / 86400, Q=Qi, adv_flow=adv, adv_quad=aq, adv_theory_nearcircular=th, n_peri=len(pf['adv']) + 1)
        NUM['wrong'][str(p)]['pairs'] = rows
        QE = Qp['Earth']; aE = rows['Earth']['a_AU']
        worst_pl = 0.0; spread = max(Qp.values()) / min(Qp.values()) - 1
        for nm in Qp:
            pred = (rows[nm]['a_AU'] / aE) ** (p - 3.0); worst_pl = max(worst_pl, abs(Qp[nm] / QE / pred - 1))
            print('   %-8s a_eff = %.4f au e = %.4f  Q = T^2 mu_N/(4 pi^2 a^3) = %.4f  (Q/Q_Earth)/(a/a_E)^(p-3) = %.4f |  perihelion advance per orbit: flow %+.6f  quadrature %+.6f  near-circular theory %+.4f rad' % (nm, rows[nm]['a_AU'], rows[nm]['e'], Qp[nm], Qp[nm] / QE / (rows[nm]['a_AU'] / aE) ** (p - 3.0), adv_f[nm][0], adv_f[nm][1], adv_f[nm][2]))
        NUM['wrong'][str(p)]['Q_spread'] = spread; NUM['wrong'][str(p)]['Q_worst_vs_power_law'] = worst_pl
        chk('ctl', spread > 0.05, 'p = %.1f: T^2 mu/(4 pi^2 a^3) differs between planets by %.1f %% (> 5 %%); for p = 3 the spread is %.1e' % (p, 100 * spread, NUM['kepler3_spread']))
        chk('ctl', worst_pl < 0.10, 'p = %.1f: Q/Q_Earth follows (a/a_E)^(p-3) within %.1f %% (pre-declared 10 %%; similar orbits: exact for circular ones)' % (p, 100 * worst_pl))
        okq = all(abs(adv_f[nm][0] - adv_f[nm][1]) < 1e-5 for nm in adv_f)
        chk('bit==std', okq, 'p = %.1f: perihelion advance per orbit from the flow equals the apsidal-angle quadrature to %.1e rad at most (< 1e-5)' % (p, max(abs(adv_f[nm][0] - adv_f[nm][1]) for nm in adv_f)))
        chk('ctl', all(abs(adv_f[nm][0]) > 0.1 for nm in adv_f), 'p = %.1f: the orbits do not close: advance per orbit between %.3f and %.3f rad in absolute value (> 0.1)' % (p, min(abs(adv_f[nm][0]) for nm in adv_f), max(abs(adv_f[nm][0]) for nm in adv_f)))
        okth = all(abs(adv_f[nm][0] / adv_f[nm][2] - 1) < tol for nm, tol in (('Venus', 0.03), ('Earth', 0.03), ('Mercury', 0.15)) if nm in adv_f)
        chk('ctl', okth, 'p = %.1f: advance vs the near-circular theory 2 pi (1/sqrt(3-k) - 1) = %+.4f rad: Venus %.3f, Earth %.3f (3 %%), Mercury %.3f (15 %%) of the theory' % (p, adv_f['Earth'][2], adv_f['Venus'][0] / adv_f['Venus'][2], adv_f['Earth'][0] / adv_f['Earth'][2], adv_f['Mercury'][0] / adv_f['Mercury'][2]))
    # p = 3 : the orbits close
    rows3 = {}
    for i in range(1, 6):
        nm = lib.NAMES[i]; m2, x2, v2 = pair_state(m, x, v, i); mu = G * (m2[0] + m2[1]); el = lib.kepler_elements(x2[1] - x2[0], v2[1] - v2[0], mu)
        pf = pair_flow(m, x, v, i, G, 3.0, NORB[i], el['T']); aq, rmin, rmax = apsidal_quadrature(x2[1] - x2[0], v2[1] - v2[0], mu, 3.0)
        rows3[nm] = dict(adv_flow=float(np.mean(pf['adv'])), adv_quad=aq, a_eff_rel=0.5 * (rmin + rmax) / el['a'] - 1, n_peri=len(pf['adv']) + 1)
    NUM['p3_close'] = rows3
    chk('ctl', all(abs(r_['adv_flow']) < 1e-8 and abs(r_['adv_quad']) < 1e-8 for r_ in rows3.values()), 'p = 3: the orbits close: perihelion advance per orbit (flow, quadrature) at most %.1e, %.1e rad (< 1e-8); (r_min + r_max)/2 equals the Kepler a to %.1e' % (max(abs(r_['adv_flow']) for r_ in rows3.values()), max(abs(r_['adv_quad']) for r_ in rows3.values()), max(abs(r_['a_eff_rel']) for r_ in rows3.values())))
    print('  [time] P4 %.1f s' % (time.time() - t0))

if __name__ == '__main__':
    T_all = time.time()
    m, x, v = lib.table_arrays()
    print('G3  parts P1..P4.  Table: Sun, Mercury, Venus, Earth, Mars, Jupiter, 16 Jan 2018; G = %.4e km^3 kg^-1 s^-2' % lib.G_ATLAS)
    part1(m, x, v)
    sol, S, d = part2(m, x, v)
    part3(m, x, v)
    part4(m, x, v, d)
    os.makedirs(os.path.dirname(OUT), exist_ok=True); json.dump(NUM, open(OUT, 'w'), indent=1, default=float)
    print('\n  [time] total %.1f s; numbers written to logs/g3_nbody.numbers.json' % (time.time() - T_all))
    finish('G3')
