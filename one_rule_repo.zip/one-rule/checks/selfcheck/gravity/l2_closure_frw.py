#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""L2.  Which of the closure paper's two printed FRW forms carries the sign slip?  (Duell, Schuller, Stritzelberger, Wolz, arXiv:1611.08878v3)
      python3 l2_closure_frw.py                 the check suite (exact Fractions, no engine object is used)
      python3 l2_closure_frw.py --fault F3      the suite with one analogue fault in this script's own switches
      python3 l2_closure_frw.py --fault-table   all eight analogue faults in turn; table to stdout (and to logs/l2_closure_frw.fault.log)
 Printed forms: (104) C = -(1/2 kappa) (-det ghat^{..})^{-1/2} (R[ghat] - 2 Lambda); (105) C_AB = (1/8 kappa) (-det ghat^{..})^{-1/2} I I (g g - g g);
 (80) L = sum_N C_{A1..AN} k^{A1}..k^{AN}; (92) L_geometry = N L(phi, (1/N) phidot) at zero shift; (106) S = (1/2 kappa) Int sqrt(-det G) [R(G) + 2 Lambda];
 (94) S_matter = Int sqrt(-det G) [G^{ab} d_a phi d_b phi - m^2 phi^2]; (93) total = S_geometry + S_matter.
 Convention switches (a cell = (sig3, delta, sig4, s, sigK, sigL), 64 cells):
   sig3  sign convention of the 3D Ricci scalar;  delta = +1: R built on ghat (negative definite, the paper's), -1: on h = -ghat (the jets are negated)
   sig4  sign convention of the 4D Ricci scalar;  s = +1: G = N^2 dt^2 - a^2 gamma (mainly minus, (31)), -1: the reader's metric is -G (jets negated)
   sigK  sign of the kinetic term of (94);        sigL: printed Lambda = sigL x the reader's Lambda, in BOTH forms (a relabelling)
 Route [std]: R from the exact 2-jets of the FRW metric with h6_closure_kg.ricci_scalar (plain index calculus, usual sign), the printed densities evaluated
 at 8 rational jet points (a, adot, addot, N, Ndot, Nddot), an exact fit on the basis {a^2 addot/N, a^2 adot Ndot/N^2, a adot^2/N, a N, a^3 N} (5 points fit,
 3 points verify), the Euler-Lagrange equation of the lapse from the fitted coefficients, N = 1.  Route [std2]: the closed forms typed by hand.
 Tags: [std], [std2], [ctl] (a wrong version; the line is ok when it fails).  The eight engine faults cannot reach this script (no R, E_a, d, h or f of
 the bit rule is called; importing b1lib loads the engine but nothing is used); the analogue is --fault F1..F8."""
import sys, os, time, itertools, math, io, contextlib, random
from fractions import Fraction as F
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import b1lib
from b1lib import chk, head, finish
import h6_closure_kg as H6

FAULT = set()
FAULTS = [('F1', 'sigma4 ignored (4D R sign switch not applied)'), ('F2', 'signature switch s not applied to the 4-metric'),
          ('F3', 'definiteness switch delta not applied to ghat'), ('F4', 'lapse frozen in the 4D jets (Ndot = Nddot = 0)'),
          ('F5', 'sigmaL applied to (106) only'), ('F6', 'matter kinetic term not flipped with s'),
          ('F7', 'C_AB coefficient 1/(4 kappa) instead of 1/(8 kappa)'), ('F8', 'comoving normalisation 1/8 dropped in (106)')]
R3I = range(3); R4I = range(4)
TXT = os.path.join(HERE, 'data', 'txt_clean', 'grav_closure.txt')             # the paper's text layer: not in the package (not redistributable)

# ------------------------------------------------------------------------------------------------ small exact helpers
def neg(x): return [neg(y) for y in x] if isinstance(x, list) else -x
def qsqrt(q):
    q = F(q); n, d = math.isqrt(q.numerator), math.isqrt(q.denominator)
    if q < 0 or n * n != q.numerator or d * d != q.denominator: raise ValueError('not a rational square: %s' % q)
    return F(n, d)
def solve(A, b):
    """exact Gauss-Jordan; None if singular"""
    n = len(A); M = [list(A[i]) + [b[i]] for i in range(n)]
    for c in range(n):
        p = next((r for r in range(c, n) if M[r][c] != 0), None)
        if p is None: return None
        M[c], M[p] = M[p], M[c]; pv = M[c][c]; M[c] = [x / pv for x in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c]; M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][n] for i in range(n)]

# ------------------------------------------------------------------------------------------------ jets of the reader's metrics
def reader3(a0, a1, k, delta):
    """the 3-metric that R in (104) is built from: ghat (delta = +1) or h = -ghat (delta = -1); returns R_usual, w, the DeWitt quadratic form KQ of
    d_t (inverse metric), and whether the printed -det(inverse metric) is positive"""
    Gi, dGi, ddGi = H6.frw_jets_3d(a0, k)                                       # ghat^{ab} = -(1/4a^2)(1 + 2k|y|^2) delta at y = 0
    gdot = [[(F(1, 2) * a1 / a0 ** 3 if a == b else F(0)) for b in R3I] for a in R3I]   # d_t ghat^{ab}
    if delta == -1 and 'F3' not in FAULT: Gi, dGi, ddGi, gdot = neg(Gi), neg(dGi), neg(ddGi), neg(gdot)
    R, g = H6.ricci_scalar(Gi, dGi, ddGi, 3)
    det = H6.det_leibniz(Gi)
    w = 1 / qsqrt(abs(det))
    KQ = sum((g[a][m] * g[b][n] - g[a][b] * g[m][n]) * gdot[a][b] * gdot[m][n] for a, b, m, n in itertools.product(R3I, repeat=4))
    return dict(R=R, w=w, KQ=KQ, printed_real=(-det > 0))

def jets4(a0, a1, a2, N0, N1, N2, k, s):
    """2-jet of the reader's inverse 4-metric at (t0, y = 0): G = N(t)^2 dt^2 - a(t)^2 gamma_k (s = +1) or -G (s = -1)"""
    if 'F4' in FAULT: N1, N2 = F(0), F(0)
    ia2 = [1 / a0 ** 2, -2 * a1 / a0 ** 3, 6 * a1 * a1 / a0 ** 4 - 2 * a2 / a0 ** 3]          # a^-2 and its t-derivatives
    iN2 = [1 / N0 ** 2, -2 * N1 / N0 ** 3, 6 * N1 * N1 / N0 ** 4 - 2 * N2 / N0 ** 3]          # N^-2 and its t-derivatives
    Gi = [[F(0)] * 4 for _ in R4I]; dGi = [[[F(0)] * 4 for _ in R4I] for _ in R4I]; ddGi = [[[[F(0)] * 4 for _ in R4I] for _ in R4I] for _ in R4I]
    Gi[0][0], dGi[0][0][0], ddGi[0][0][0][0] = iN2
    for a in range(1, 4):
        Gi[a][a] = -F(1, 4) * ia2[0]; dGi[a][a][0] = -F(1, 4) * ia2[1]; ddGi[a][a][0][0] = -F(1, 4) * ia2[2]
        for c in range(1, 4): ddGi[a][a][c][c] += -F(1, 4) * ia2[0] * 4 * k
    if s == -1 and 'F2' not in FAULT: Gi, dGi, ddGi = neg(Gi), neg(dGi), neg(ddGi)
    return Gi, dGi, ddGi

def reader4(pt, k, s, want_R=True):
    Gi, dGi, ddGi = jets4(*pt, k, s)
    if want_R: R, g = H6.ricci_scalar(Gi, dGi, ddGi, 4)
    else: R, g = None, H6.mat_inv(Gi)
    return dict(R=R, sd=qsqrt(-H6.det_leibniz(g)), G00=Gi[0][0])

# ------------------------------------------------------------------------------------------------ the printed densities (per unit comoving volume: / sqrt(det gamma) = 8)
def L104(p3, N, kappa, Lam, cell, var=None):
    sig3, delta, sig4, s, sigK, sigL = cell
    if 'F5' in FAULT: sigL = 1
    R = sig3 * p3['R']; lam = sigL * Lam; kap_C, kap_K = kappa, kappa
    cK = F(1, 4) if 'F7' in FAULT else F(1, 8)
    if var == 'kin2k': kap_K = 2 * kappa
    if var == 'all2k': kap_C, kap_K = 2 * kappa, 2 * kappa
    if var == 'S5': lam = -lam
    if var in ('S6', 'S7'): kap_C, kap_K = -kappa, -kappa
    if var == 'S7': lam = -lam
    if var == 'S8': R = -R
    C = -F(1, 2) / kap_C * p3['w'] * (R - 2 * lam)
    kin = cK / kap_K * p3['w'] * p3['KQ']
    if var == 'S9': kin = -kin
    if var == 'vol': C, kin = lam / kappa * p3['w'], F(0)
    return (N * C + kin / N) / 8

def L106(p4, kappa, Lam, cell, var=None):
    sig3, delta, sig4, s, sigK, sigL = cell
    R = (1 if 'F1' in FAULT else sig4) * p4['R']; lam = sigL * Lam; ov = F(1); kR = kappa
    if var == 'S1': R = -R
    if var == 'S2': lam = -lam
    if var == 'S3': ov = F(-1)
    if var == 'S4': ov, lam = F(-1), -lam         # -(1/2 kappa)(R - 2 Lambda), computed literally (equal to S1 as an expression)
    if var == 'all2k': kR = 2 * kappa
    if var == 'R2k': return (F(1, 2) / (2 * kappa) * p4['sd'] * R + F(1, 2) / kappa * p4['sd'] * 2 * lam) * (F(1) if 'F8' in FAULT else F(1, 8))
    if var == 'vol': R = F(0)
    return ov * F(1, 2) / kR * p4['sd'] * (R + 2 * lam) * (F(1) if 'F8' in FAULT else F(1, 8))

def Lmatter(p4, phid, m2phi2, cell):
    sig3, delta, sig4, s, sigK, sigL = cell
    G00 = abs(p4['G00']) if 'F6' in FAULT else p4['G00']
    return p4['sd'] * (sigK * G00 * phid * phid - m2phi2) / 8

# ------------------------------------------------------------------------------------------------ fit, Euler-Lagrange of the lapse, closed constraint
def basis(pt):
    a0, a1, a2, N0, N1, N2 = pt
    return [a0 * a0 * a2 / N0, a0 * a0 * a1 * N1 / N0 ** 2, a0 * a1 * a1 / N0, a0 * N0, a0 ** 3 * N0]
BASIS_TXT = ['a^2 addot/N', 'a^2 adot Ndot/N^2', 'a adot^2/N', 'a N', 'a^3 N']

def fit(pts, vals):
    pv = [basis(p) for p in pts]
    c = solve(pv[:5], vals[:5])
    if c is None: return None, False
    return c, all(sum(ci * bi for ci, bi in zip(c, b)) == v for b, v in zip(pv[5:], vals[5:]))

def EL_lapse(c, a0, a1, a2=F(0)):
    """E = dL/dN - d/dt dL/dNdot at N = 1, Ndot = 0 for L = sum c_i basis_i"""
    return -(c[0] + c[1]) * a0 * a0 * a2 - (c[2] + 2 * c[1]) * a0 * a1 * a1 + c[3] * a0 + c[4] * a0 ** 3

def matter_E(cell, a0, k, phid, m2phi2):
    """d Lm/dN at N = 1 (Lm = N X + Y/N), from the reader's metric at N = 1 and N = 2"""
    sig3, delta, sig4, s, sigK, sigL = cell
    L1 = Lmatter(reader4((a0, F(0), F(0), F(1), F(0), F(0)), k, s, want_R=False), phid, m2phi2, cell)
    L2 = Lmatter(reader4((a0, F(0), F(0), F(2), F(0), F(0)), k, s, want_R=False), phid, m2phi2, cell)
    X = (2 * L2 - L1) / 3; Y = L1 - X
    return X - Y

def closed(c, kappa, Lam, k, Em_kin, Em_mass, aref):
    """(e_k, e_L, e_m, e_mass): adot^2 + e_k k = e_L (Lambda/3) a^2 + e_m (kappa/3) a^2 phidot^2 + e_mass (kappa/3) a^2 m^2 phi^2"""
    if c is None: return None
    r3 = c[2] + 2 * c[1]
    if r3 == 0: return None
    ek = (-(c[3] / r3) / k) if k != 0 else None
    eL = (3 * (c[4] / r3) / Lam) if Lam != 0 else None
    em = (Em_kin / (aref * r3)) / (kappa / 3 * aref * aref)
    emass = (Em_mass / (aref * r3)) / (kappa / 3 * aref * aref)
    return (ek, eL, em, emass)

def eps(cell):
    sig3, delta, sig4, s, sigK, sigL = cell
    return sig3 * delta, sig4 * s, sigK * s

def predicted(cell, form):
    e3, e4, rK = eps(cell); sigL = cell[5]
    return (e3, -sigL, rK, 1) if form == 104 else (1, e4 * sigL, -e4 * rK, -e4)

def closed_form_coeffs(cell, form, kappa, Lam, k):
    """[std2] the hand-typed closed forms"""
    e3, e4, rK = eps(cell); sigL = cell[5]
    if form == 104: return [F(0), F(0), F(-3) / kappa, 3 * e3 * k / kappa, sigL * Lam / kappa]
    return [-3 * e4 / kappa, 3 * e4 / kappa, -3 * e4 / kappa, -3 * e4 * k / kappa, sigL * Lam / kappa]

CELLS = list(itertools.product((1, -1), repeat=6))
ADMISSIBLE = lambda cell: cell[0] == 1 and cell[1] == 1 and cell[3] == 1 and cell[4] == 1 and cell[5] == 1
CELLTXT = lambda cell: '(' + ','.join('+' if x == 1 else '-' for x in cell) + ')'

# ================================================================================================ the suite
def suite():
    rng = random.Random(26)
    PTS = []
    while len(PTS) < 8:
        p = (F(rng.randint(2, 9), rng.randint(1, 4)), F(rng.randint(-7, 7), rng.randint(1, 5)), F(rng.randint(-9, 9), rng.randint(1, 6)),
             F(rng.randint(1, 4) ** 2, rng.randint(1, 3) ** 2), F(rng.randint(-5, 5), rng.randint(1, 4)), F(rng.randint(-5, 5), rng.randint(1, 3)))
        PTS.append(p)
    KS = (0, 1, -1); KL = ((F(7, 3), F(-5, 11)), (F(-2), F(4, 3)))
    AREF = F(2)

    head('L2 part 0: the printed equations in the text layer, and the identities behind the switches [std]')
    t0 = time.time()
    try: txt = ' '.join(open(TXT, encoding='utf-8').read().split())
    except OSError: txt = None
    if txt is None:
        print('  info: the text layer of the closure paper (data/txt_clean/grav_closure.txt) is not in the package: the match of the printed equations with it is skipped', flush=True)
    else:
        for q in ('where R[g] denotes the Ricci curvature scalar built from an inverse three-dimensional metric', 'But this is exactly the 3+1 decomposition',
                  'it is the above sign convention that generalizes the mainly-minus signature convention of',
                  'with the gravitational constant κ and cosmological constant Λ having emerged as', 'C[ϕ] = −', 'R[bg (ϕ)] − 2 Λ', '∂ 2 G(x)) + 2Λ'):
            chk('std', q in txt, 'text layer of the closure paper (txt_clean) contains: "%s"' % q)
    for n in (3, 4):
        for trial in range(2):
            rg = range(n)
            while True:
                A = [[F(rng.randint(-4, 4)) for _ in rg] for _ in rg]
                Gi = [[A[i][j] + A[j][i] + (F(5) if i == j else F(0)) for j in rg] for i in rg]
                if H6.det_leibniz(Gi) != 0: break
            dGi = [[[F(0)] * n for _ in rg] for _ in rg]; ddGi = [[[[F(0)] * n for _ in rg] for _ in rg] for _ in rg]
            for a in rg:
                for b in range(a, n):
                    for c in rg:
                        v = F(rng.randint(-3, 3), rng.randint(1, 3)); dGi[a][b][c] = dGi[b][a][c] = v
                        for d in range(c, n):
                            v = F(rng.randint(-3, 3), rng.randint(1, 3)); ddGi[a][b][c][d] = ddGi[b][a][c][d] = ddGi[a][b][d][c] = ddGi[b][a][d][c] = v
            Rp, gp = H6.ricci_scalar(Gi, dGi, ddGi, n); Rm, gm = H6.ricci_scalar(neg(Gi), neg(dGi), neg(ddGi), n)
            chk('std', Rm == -Rp and H6.det_leibniz(neg(gp)) == (-1) ** n * H6.det_leibniz(gp),
                'n = %d, random rational 2-jet %d: R_usual[-g] = -R_usual[g] (%s) and det(-g) = (-1)^n det g: delta and s act as signs' % (n, trial + 1, Rp))
    p3n, p3p = reader3(F(2), F(1, 2), 1, 1), reader3(F(2), F(1, 2), 1, -1)
    chk('std', p3n['printed_real'] and not p3p['printed_real'] and p3n['w'] == p3p['w'] and p3n['KQ'] == p3p['KQ'] and p3p['R'] == -p3n['R'],
        'ghat negative definite: -det ghat^{..} > 0 (printed root real); h = -ghat: -det h^{..} < 0, the printed root is not real (|det| used, cell inadmissible); w, the DeWitt form and -R agree')
    print('  part 0: %.1f s' % (time.time() - t0))

    head('L2 part 1: 64 cells x k = 0, +1, -1 x (kappa, Lambda) = (7/3, -5/11), (-2, 4/3); [std] jet pipeline and [std2] closed forms')
    t0 = time.time()
    R4c = {(s, k): [reader4(p, k, s) for p in PTS] for s in (1, -1) for k in KS}
    R3c = {(d, k): [reader3(p[0], p[1], k, d) for p in PTS] for d in (1, -1) for k in KS}
    Emc = {(s, sK, k): (matter_E((1, 1, 1, s, sK, 1), AREF, k, F(1), F(0)), matter_E((1, 1, 1, s, sK, 1), AREF, k, F(0), F(1))) for s in (1, -1) for sK in (1, -1) for k in KS}
    print('  jets and Ricci scalars: %.1f s' % (time.time() - t0))

    def form_fit(form, cell, k, kappa, Lam, var=None):
        if form == 104: vals = [L104(R3c[(cell[1], k)][i], PTS[i][3], kappa, Lam, cell, var) for i in range(8)]
        else: vals = [L106(R4c[(cell[3], k)][i], kappa, Lam, cell, var) for i in range(8)]
        return fit(PTS, vals)

    RES = {}; nfit = nver = nfirst = n104 = n106 = nstd2 = 0; bad = []
    for cell in CELLS:
        for k in KS:
            for (kappa, Lam) in KL:
                Em = Emc[(cell[3], cell[4], k)]
                for form in (104, 106):
                    c, ver = form_fit(form, cell, k, kappa, Lam)
                    nfit += 1; nver += bool(ver)
                    nfirst += bool(c is not None and c[0] + c[1] == 0)
                    e = closed(c, kappa, Lam, k, Em[0], Em[1], AREF)
                    pe = predicted(cell, form)
                    okp = e is not None and all(x is None or x == y for x, y in zip(e, pe))
                    if form == 104: n104 += okp
                    else: n106 += okp
                    if not okp and len(bad) < 3: bad.append((CELLTXT(cell), k, form, e, pe))
                    nstd2 += bool(c is not None and c == closed_form_coeffs(cell, form, kappa, Lam, k))
                    RES[(cell, k, kappa, Lam, form)] = (c, e)
    N_ = len(CELLS) * len(KS) * len(KL)
    chk('std', nver == 2 * N_, 'the 5-monomial basis reproduces the 3 verification jet points exactly in %d of %d fits (a missing monomial, e.g. Nddot, would show)' % (nver, 2 * N_))
    chk('std', nfirst == 2 * N_, 'no addot in the lapse equation (c[a^2 addot/N] + c[a^2 adot Ndot/N^2] = 0) in %d of %d fits: a first-order constraint' % (nfirst, 2 * N_))
    chk('std', n104 == N_, '(104)-(105): adot^2 + eps3 k = -sigL (Lambda/3) a^2 + rhoK (kappa/3) a^2 phidot^2 + (kappa/3) a^2 m^2 phi^2 in %d of %d (cell, k, kappa, Lambda), eps3 = sig3 delta, rhoK = sigK s' % (n104, N_)
        + ('' if not bad else '  first mismatch %s' % (bad[:1],)))
    chk('std', n106 == N_, '(106): adot^2 + k = eps4 sigL (Lambda/3) a^2 - eps4 rhoK (kappa/3) a^2 phidot^2 - eps4 (kappa/3) a^2 m^2 phi^2 in %d of %d, eps4 = sig4 s' % (n106, N_))
    chk('std2', nstd2 == 2 * N_, 'the hand-typed closed Lagrangians equal the fitted coefficients exactly in %d of %d fits' % (nstd2, 2 * N_))

    def agree(cell, var104=None, var106=None, ks=KS):
        """vacuum constraints equal / matter coefficients equal / Lagrangians equal up to a total derivative, over the given k and both (kappa, Lambda)"""
        vac = att = lag = True
        for k in ks:
            for (kappa, Lam) in KL:
                Em = Emc[(cell[3], cell[4], k)]
                if var104 is None and var106 is None: (c1, e1), (c2, e2) = RES[(cell, k, kappa, Lam, 104)], RES[(cell, k, kappa, Lam, 106)]
                else:
                    c1, _ = form_fit(104, cell, k, kappa, Lam, var104); c2, _ = form_fit(106, cell, k, kappa, Lam, var106)
                    e1, e2 = closed(c1, kappa, Lam, k, Em[0], Em[1], AREF), closed(c2, kappa, Lam, k, Em[0], Em[1], AREF)
                if c1 is None or c2 is None or e1 is None or e2 is None: return False, False, False
                r1, r2 = c1[2] + 2 * c1[1], c2[2] + 2 * c2[1]
                vac &= (c1[3] / r1 == c2[3] / r2) and (c1[4] / r1 == c2[4] / r2)
                att &= (e1[2] == e2[2]) and (e1[3] == e2[3])
                lag &= (r1, c1[3], c1[4]) == (r2, c2[3], c2[4])
        return vac, att, lag
    AG = {cell: agree(cell) for cell in CELLS}
    AG0 = {cell: agree(cell, ks=(0,))[0] for cell in CELLS}
    pred = {cell for cell in CELLS if eps(cell)[0] == 1 and eps(cell)[1] == -1}
    vac_set = {c for c in CELLS if AG[c][0]}; lag_set = {c for c in CELLS if AG[c][2]}; mat_set = {c for c in CELLS if AG[c][0] and AG[c][1]}
    chk('std', vac_set == pred, 'vacuum constraints agree for every k in exactly %d cells, the predicted %d: sig3 delta = +1 and sig4 s = -1 (any sigK, sigL)' % (len(vac_set), len(pred)))
    chk('std', lag_set == pred and mat_set == pred, 'in the same %d cells the two Lagrangians are equal up to a total derivative, overall sign included, and agree with the Klein-Gordon matter (%d, %d)' % (len(pred), len(lag_set), len(mat_set)))
    k0set = {c for c in CELLS if AG0[c]}
    chk('std', k0set == {c for c in CELLS if eps(c)[1] == -1}, 'at k = 0 alone the vacuum constraints agree in %d cells: exactly eps4 = -1 (eps3 is invisible without spatial curvature)' % len(k0set))
    uni = [c for c in CELLS if c[0] == c[2] and c[1] == c[3]]
    chk('std', len(uni) == 16 and not any(AG[c][0] for c in uni), 'one formula for both R (sig3 = sig4) on one metric family (delta = s): %d cells, none agrees (eps3 = eps4 always)' % len(uni))
    chk('std', all(AG[c] == AG[c[:4] + (1, 1)] for c in CELLS), 'sigK and sigL never change any agreement flag (they act on both forms alike)')
    print('  cells (sig3, delta, sig4, s) with eps3 = sig3 delta, eps4 = sig4 s; the flags hold for all four (sigK, sigL); vacuum constraints at sigL = +1:')
    for c4 in itertools.product((1, -1), repeat=4):
        cell = c4 + (1, 1); e3, e4, _ = eps(cell)
        f104 = 'adot^2 %s k = -(L/3)a^2' % ('+' if e3 == 1 else '-'); f106 = 'adot^2 + k = %s(L/3)a^2' % ('+' if e4 == 1 else '-')
        adm = 'admissible' if ADMISSIBLE(cell) else ('closure-excluded' if e3 == -1 else '') + (' printed root not real' if cell[1] == -1 else '') + (' not mainly-minus' if cell[3] == -1 else '')
        print('   %s eps3 %+d eps4 %+d | (104)-(105): %-24s | (106): %-24s | all k: %-5s k=0: %-5s Lagrangian: %-5s | %s' % (
            CELLTXT(c4), e3, e4, f104, f106, AG[cell][0], AG0[cell], AG[cell][2], adm.strip()))
    adm = [c for c in CELLS if ADMISSIBLE(c)]
    chk('std', len(adm) == 2 and AG[(1, 1, -1, 1, 1, 1)] == (True, True, True) and AG[(1, 1, 1, 1, 1, 1)] == (False, False, False),
        'admissible cells (closure-consistent eps3 = +1, ghat negative definite, mainly minus, (94) and Lambda as printed): exactly 2, differing only in sig4; sig4 = -1 agrees in every respect, sig4 = +1 (H6) agrees in none')
    e104 = [RES[(c, k, kap, L, 104)][1] for c in adm for k in KS for (kap, L) in KL]
    chk('std', all(e is not None and e[1] == -1 and e[2] == 1 and e[3] == 1 for e in e104),
        'every admissible cell, (104)-(105) with the printed matter (94): adot^2 + k = -(Lambda/3)a^2 + (kappa/3) a^2 (phidot^2 + m^2 phi^2): attraction for kappa > 0, de Sitter needs Lambda < 0')
    e106p, e106m = RES[((1, 1, 1, 1, 1, 1), 1, F(7, 3), F(-5, 11), 106)][1], RES[((1, 1, -1, 1, 1, 1), 1, F(7, 3), F(-5, 11), 106)][1]
    chk('std', e106p is not None and e106m is not None and e106p[1:] == (1, -1, -1) and e106m[1:] == (-1, 1, 1),
        '(106) with the printed matter: sig4 = +1 gives adot^2 + k = +(Lambda/3)a^2 - (kappa/3) a^2 rho (attraction needs kappa < 0); sig4 = -1 gives the (104)-(105) constraint')
    def prod(c, kap, L, f):
        e = RES[(c, 1, kap, L, f)][1]
        return None if e is None else e[1] * e[2]
    chk('std', all(prod(c, kap, L, 104) is not None and prod(c, kap, L, 104) == prod(c, kap, L, 106) == -c[5] * c[4] * c[3] for c in CELLS for (kap, L) in KL),
        'every cell, both forms: (sign of Lambda for de Sitter) x (sign of kappa for attraction) = e_L e_m = -sigL sigK s, the same in (104)-(105) and (106): '
        'with kappa fixed by attraction for (94), de Sitter needs Lambda/kappa < 0 in both forms in every admissible cell (the volume term +(Lambda/kappa) sqrt(-g) is printed alike)')
    print('  part 1: %.1f s' % (time.time() - t0))

    head('L2 part 2: reproduction of H6 (the all-plus cell) [std], controls [ctl] in every cell, de Sitter jets, slip hypotheses')
    t0 = time.time()
    allp = (1, 1, 1, 1, 1, 1); nrep = 0
    for (a0, a1, a2, N, kappa, Lam, k) in ((F(2), F(1, 2), F(-3, 4), F(7, 4), F(7, 3), F(-5, 11), 1), (F(3, 2), F(-2, 3), F(1, 5), F(1, 3), F(-2), F(4, 3), -1), (F(1), F(1), F(1), F(1), F(1), F(2), 1)):
        mine1 = L104(reader3(a0, a1, k, 1), N, kappa, Lam, allp); mine2 = L106(reader4((a0, a1, a2, N, F(0), F(0)), k, 1), kappa, Lam, allp)
        nrep += (mine1 == H6.frw_L1(a0, a1, N, kappa, Lam, k)[0]) + (mine2 == H6.frw_L2(a0, a1, a2, N, kappa, Lam, k)[0])
    e1, e2 = RES[(allp, 1, F(7, 3), F(-5, 11), 104)][1], RES[(allp, 1, F(7, 3), F(-5, 11), 106)][1]
    chk('std', nrep == 6 and e1 is not None and e2 is not None and e1[:2] == (1, -1) and e2[:2] == (1, 1), 'all-plus cell = H6 exactly: L equals frw_L1 and frw_L2 at H6\'s three parameter sets (%d of 6) and the constraints are adot^2 + k = -(Lambda/3)a^2 / +(Lambda/3)a^2' % nrep)

    def lam_solve(form, cell, k, kappa, a0, a1, var=None, phid=F(0)):
        """Lambda at which the (possibly wrong) form's lapse equation holds at (a0, a1); E is affine in Lambda"""
        Em = matter_E(cell, a0, k, phid, F(0)) if phid else F(0)
        E = []
        for L in (F(0), F(1)):
            c, _ = form_fit(form, cell, k, kappa, L, var)
            if c is None: return None, None
            E.append(EL_lapse(c, a0, a1) + Em)
        return (None if E[1] == E[0] else -E[0] / (E[1] - E[0])), E
    def E_at(form, cell, k, kappa, Lam, a0, a1, var=None, phid=F(0)):
        c, _ = form_fit(form, cell, k, kappa, Lam, var)
        return None if c is None else EL_lapse(c, a0, a1) + (matter_E(cell, a0, k, phid, F(0)) if phid else F(0))
    a0, a1, kappa = F(2), F(1, 2), F(7, 3)
    nv = nk = nm = nva = 0
    for cell in CELLS:
        for form in (104, 106):
            Ls, _ = lam_solve(form, cell, 1, kappa, a0, a1)
            nv += (Ls is not None and E_at(form, cell, 1, kappa, Ls, a0, a1, 'vol') != 0)
            nk += (Ls is not None and E_at(form, cell, 1, kappa, Ls, a0, a1, 'kin2k' if form == 104 else 'R2k') != 0)
            Lm, _ = lam_solve(form, cell, 1, kappa, a0, a1, None, F(1))
            nm += (Lm is not None and E_at(form, cell, 1, kappa, Lm, a0, a1, 'all2k', F(1)) != 0)
        nva += (not agree(cell, var104='vol')[0])
    chk('ctl', nv == 128, 'volume term alone (C = (Lambda/kappa) w, C_AB = 0, an exact closure solution; and its (106) analogue) fails the lapse equation at a solution point of the correct form in %d of 128 (cell, form)' % nv)
    chk('ctl', nk == 128, 'kappa -> 2 kappa in C_AB (and in the R term of (106)) fails the lapse equation at a solution point of the correct form in %d of 128' % nk)
    chk('ctl', nm == 128, 'kappa -> 2 kappa in the whole gravitational form fails the lapse equation WITH the Klein-Gordon matter (phidot = 1) in %d of 128' % nm)
    chk('ctl', nva == 64, 'the volume-only (104) is judged to agree with (106) in no cell (%d of 64 disagree): the agreement test can fail in every cell' % nva)
    agc, h6c = (1, 1, -1, 1, 1, 1), allp
    for (k, a0_, a1_, nm_) in ((1, None, F(0), 'closed, a = cosh(Ht)/H at t = 0'), (0, None, None, 'flat, a = exp(Ht) at t = 0'), (-1, None, F(5, 4), 'open, a = sinh(Ht)/H at sinh = 3/4')):
        H = F(3, 5)
        if k == 1: a0_ = 1 / H
        if k == 0: a0_, a1_ = F(1), H
        if k == -1: a0_ = F(3, 4) / H
        vals = {(cell, f, sg): E_at(f, cell, k, kappa, sg * 3 * H * H, a0_, a1_) for cell in (agc, h6c) for f in (104, 106) for sg in (1, -1)}
        chk('ctl', vals[(agc, 104, -1)] == 0 and vals[(agc, 106, -1)] == 0 and vals[(agc, 104, 1)] != 0 and vals[(agc, 106, 1)] != 0,
            'de Sitter %s, H = 3/5: agreeing cell: both forms hold at Lambda = -3H^2 and fail at +3H^2' % nm_)
        chk('ctl', vals[(h6c, 104, -1)] == 0 and vals[(h6c, 106, 1)] == 0 and vals[(h6c, 104, 1)] != 0 and vals[(h6c, 106, -1)] != 0,
            '  H6 cell: (104)-(105) holds at -3H^2 only, (106) at +3H^2 only')
    SL = [('S1', None, 'S1', 'R -> -R in (106)', (True, True, True), False), ('S2', None, 'S2', 'Lambda -> -Lambda in (106)', (True, False, False), False),
          ('S3', None, 'S3', 'overall sign of (106)', (False, True, False), False), ('S4', None, 'S4', 'overall sign and Lambda of (106) [= S1 as an expression]', (True, True, True), False),
          ('S5', 'S5', None, 'Lambda -> -Lambda in (104)', (True, False, False), False), ('S6', 'S6', None, 'overall sign of (104)-(105) (kappa -> -kappa)', (False, True, False), False),
          ('S7', 'S7', None, '(kappa, Lambda) -> (-kappa, -Lambda) in (104)-(105)', (True, True, True), False),
          ('S8', 'S8', None, 'R -> -R in (104) (excluded by the closure, H6)', (False, False, False), True), ('S9', 'S9', None, 'C_AB -> -C_AB in (105) (excluded by the closure, H6)', (False, True, False), True)]
    print('  slip hypotheses, one printed sign (or one pair) changed in the H6 cell; flags = (vacuum constraint, matter coefficients, Lagrangian) agree:')
    for (nm_, v1, v2, txt_, exp, excl) in SL:
        got = agree(h6c, v1, v2)
        print('   %s %-62s %s' % (nm_, txt_, got))
        chk('std' if exp[2] else 'ctl', got == exp, '%s %s: (vacuum, matter, Lagrangian) agree = %s as predicted%s' % (nm_, txt_, got, ' (a full repair)' if exp[2] else ' (not a repair)'))
    print('  part 2: %.1f s' % (time.time() - t0))

def fault_table():
    global FAULT
    out = []; P = lambda s='': (print(s, flush=True), out.append(s))
    P('L2 analogue fault table: faults in this script\'s own convention switches (the engine faults M1..M8 cannot reach it)')
    for (fid, fname) in [('--', 'no fault')] + FAULTS:
        FAULT = set() if fid == '--' else {fid}; b1lib.FAILS.clear(); buf = io.StringIO(); exc = None
        with contextlib.redirect_stdout(buf):
            try: suite()
            except Exception as ex: exc = '%s: %s' % (type(ex).__name__, str(ex)[:80])
        lines = buf.getvalue().splitlines(); nok = sum(l.startswith('  ok') for l in lines); nf = sum(l.startswith('  FAIL') for l in lines)
        P('%s  %-52s %s  (%d ok, %d fail%s)' % (fid, fname, 'baseline' if fid == '--' else ('SEEN    ' if (nf or exc) else 'NOT seen'), nok, nf, ', exception ' + exc if exc else ''))
        for l in [l.strip()[:150] for l in lines if l.startswith('  FAIL')][:2]: P('       first: ' + l)
    FAULT = set(); b1lib.FAILS.clear()
    log = os.path.join(HERE, 'logs', 'l2_closure_frw.fault.log')
    open(log, 'w').write('\n'.join(out) + '\n')

def main():
    argv = sys.argv[1:]
    if '--fault-table' in argv: fault_table(); return
    if '--fault' in argv: FAULT.add(argv[argv.index('--fault') + 1])
    t0 = time.time()
    suite()
    print('\n  total %.1f s; engine objects used: none (the eight engine faults cannot be seen; analogue: --fault-table)' % (time.time() - t0))
    finish('L2')

if __name__ == '__main__': main()
