#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A2. Jet lemma and sampling bound.   python3 a2_sampling.py [--quick]      (--quick: fewer seeds in the calibration)
 Part 1  [bit] what the jet lemma needs, on the engine: the residual of a false identity at the origin reads the 1-jet only (terms of degree >= 2 change
         nothing, degree-1 terms do), and the residual at a point p of a field equals the residual at 0 of the field re-expanded around p (no explicit x)
 Part 2  [bit] deterministic expansion at n = 3: the jet coefficients are polynomial variables; each identity holds as an exact polynomial identity
         (second Bianchi, first Bianchi, torsion and curvature covariance, spinor commutator, D E_a = torsion terms at c = 0 and c = 1, linear in c)
 Part 3  [std] the Schwartz-Zippel table: jet order, degree, the point mass p of the sampler, the per-run bound D p (printed); p checked against rpoly
 Part 4  [std][ctl] calibration at n = 3: measured miss rates of four false identities under four samplings must lie below the bound; the bound is
         attained by Q = x (x - 1) ... (x - D + 1) with x uniform (the bound is tight, not loose by construction)"""
import sys, os, time, itertools, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from fractions import Fraction as F

QUICK = '--quick' in sys.argv
def T0(): return time.time()
def tline(part, t): print('  time %s: %.1f s' % (part, time.time() - t), flush=True)

# ------------------------------------------------------------------------------------------------ false identities (my own functions; the engine's are the true ones)
def curvature_q(Gv, om, q, f=None):
    Fm = Gv.Fm; R = [Fm.d(om[C]) for C in range(Gv.G)]
    for (A, B), (C, ff) in (f or Gv.L.f).items(): R[C] = Fm.add(R[C], Fm.wedge(om[A], om[B]), ff * q)
    return R
def D_biv_f(Gv, om, Y, f):
    Fm = Gv.Fm; out = [Fm.d(Y[C]) for C in range(Gv.G)]
    for (A, B), (C, ff) in f.items(): out[C] = Fm.add(out[C], Fm.wedge(om[A], Y[B]), F(ff, 2))
    return out
def D_vec_h(Gv, om, X, h):
    Fm = Gv.Fm; out = [Fm.d(X[c]) for c in range(Gv.n)]
    for (A, b), (c, hh) in h.items(): out[c] = Fm.add(out[c], Fm.wedge(om[A], X[b]), hh)
    return out
def flipped_f(L_):
    f = dict(L_.f); k = sorted(f)[0]; C, v = f[k]; f[k] = (C, -v); return f
def flipped_h(L_):
    h = dict(L_.h); k = sorted(h)[3]; c, v = h[k]; h[k] = (c, -v); return h
def residual_DR(Gv, om, q=F(1, 4), f=None):
    f = f or Gv.L.f; return D_biv_f(Gv, om, curvature_q(Gv, om, q, f), f)
def residual_DT(Gv, om, e, h=None):
    h = h or Gv.L.h; Fm = Gv.Fm; R = Gv.curvature(om); T = D_vec_h(Gv, om, e, h); DT = D_vec_h(Gv, om, T, h); rhs = [{} for _ in range(Gv.n)]
    for (A, b), (c, hh) in h.items(): rhs[c] = Fm.add(rhs[c], Fm.wedge(R[A], e[b]), hh)
    return [Fm.add(DT[c], rhs[c], -1) for c in range(Gv.n)]
def allzero(forms): return all(gs.eqz(x) for x in forms)

# ------------------------------------------------------------------------------------------------ Part 1: what the jet lemma needs
def part1():
    head('Part 1 [bit] the jet lemma on the engine: finite order at the origin, no explicit x-dependence'); t = T0(); n = 3; Gv = Grav(n); Fm = Gv.Fm
    rng = random.Random(3); om = [gs.rform(rng, n, 1, 1, .8) for _ in range(Gv.G)]
    at0 = lambda forms: [{m: {k: v for k, v in p.items() if sum(k) == 0} for m, p in X.items()} for X in forms]
    strip = lambda forms: [{m: p for m, p in X.items() if p} for X in forms]
    base = strip(at0(residual_DR(Gv, om, F(1, 3))))
    chk('bit', not allzero(base), 'n = 3: the false identity (1/3 in R) has a non-zero residual at the origin on a random 1-jet')
    for deg in (2, 3):
        om2 = [Fm.add(om[A], {m: {k: v for k, v in gs.rpoly(rng, n, deg, .9).items() if sum(k) >= 2} for m in om[A]}) for A in range(Gv.G)]
        same = gs.lst_eq(strip(at0(residual_DR(Gv, om2, F(1, 3)))), base)
        chk('bit', same, 'n = 3: adding terms of degree %d to omega leaves the residual at the origin unchanged (the identity reads the 1-jet)' % deg)
    om1 = [Fm.add(om[A], {m: {k: v for k, v in gs.rpoly(rng, n, 1, .9).items() if sum(k) == 1} for m in om[A]}) for A in range(Gv.G)]
    chk('bit', not gs.lst_eq(strip(at0(residual_DR(Gv, om1, F(1, 3)))), base), 'n = 3: adding degree-1 terms (a different 1-jet) changes the residual at the origin')
    # translation: residual at p of omega == residual at 0 of omega re-expanded around p
    p = [F(1, 2), F(-2, 3), F(3)]
    res_p = residual_DR(Gv, om, F(1, 3)); val_p = [{m: sum(v * math.prod(pp ** kk for pp, kk in zip(p, k)) for k, v in poly.items()) for m, poly in X.items()} for X in res_p]
    om_sh = [{m: shift_poly(poly, p, n) for m, poly in X.items()} for X in om]
    res_0 = residual_DR(Gv, om_sh, F(1, 3)); val_0 = [{m: poly.get((0,) * n, F(0)) for m, poly in X.items()} for X in res_0]
    same = all(set(k for k, v in val_p[c].items() if v) == set(k for k, v in val_0[c].items() if v) and all(val_p[c][k] == val_0[c].get(k, 0) for k in val_p[c]) for c in range(Gv.G))
    chk('bit', same and any(v for X in val_p for v in X.values()), 'n = 3: residual at p = (1/2, -2/3, 3) == residual at 0 of the field re-expanded around p (shift_poly), non-zero')
    tline('part 1', t)

# ------------------------------------------------------------------------------------------------ Part 2: deterministic expansion at n = 3 (symbolic jets)
class Alloc:
    def __init__(self, n, N): self.n = n; self.nv = n + N; self.k = 0
    def var(self):
        i = self.n + self.k; self.k += 1; assert i < self.nv; return i
    def jet_poly(self, order):
        """a polynomial of degree <= order in x whose coefficients are fresh variables"""
        p = {}
        for ex in itertools.product(range(order + 1), repeat=self.n):
            if sum(ex) > order: continue
            key = list(ex) + [0] * (self.nv - self.n); key[self.var()] = 1; p[tuple(key)] = F(1)
        return p
    def form(self, degree, order=1):
        return {sum(1 << i for i in idx): self.jet_poly(order) for idx in itertools.combinations(range(self.n), degree)}
def part2():
    head('Part 2 [bit] deterministic expansion at n = 3: every identity as an exact polynomial identity in the jet coefficients (1-jets, all points)'); t = T0()
    n = 3; Gv = Grav(n); Fm = Gv.Fm; L_ = Gv.L; G = Gv.G
    ev = [S for S in range(1 << n) if popc(S) % 2 == 0]
    N = G * n * (n + 1) + n * n * (n + 1) + G * (n + 1) + len(ev) * (n + 1)
    al = Alloc(n, N); om = [al.form(1) for _ in range(G)]; e = [al.form(1) for _ in range(n)]; lam = [{0: al.jet_poly(1)} for _ in range(G)]; psi = {S: {0: al.jet_poly(1)} for S in ev}
    nvars = al.k; print('  symbolic jets: %d coefficient variables (omega %d, e %d, lambda %d, psi %d), %d slots per monomial' % (nvars, G * n * (n + 1), n * n * (n + 1), G * (n + 1), len(ev) * (n + 1), al.nv))
    R = Gv.curvature(om); T = Gv.torsion(om, e)
    DR = Gv.D_bivector(om, R); chk('bit', allzero(DR), 'n = 3: D R = 0 as a polynomial identity in the 36 jet coefficients of omega (second Bianchi, all 1-jets, all points)')
    R3 = curvature_q(Gv, om, F(1, 3)); chk('ctl', not allzero(D_biv_f(Gv, om, R3, L_.f)), 'n = 3: the same expansion with 1/3 in R is a non-zero polynomial (the expansion can fail)')
    DT = Gv.D_vector(om, T); rhs = [{} for _ in range(n)]
    for (A, b), (c, h) in L_.h.items(): rhs[c] = Fm.add(rhs[c], Fm.wedge(R[A], e[b]), h)
    chk('bit', gs.lst_eq(DT, rhs), 'n = 3: D T = R e as a polynomial identity in the 72 jet coefficients of (omega, e) (first Bianchi)')
    chk('ctl', not gs.lst_eq(D_vec_h(Gv, om, D_vec_h(Gv, om, e, flipped_h(L_)), flipped_h(L_)), rhs), 'n = 3: with one h entry flipped D T = R e fails as a polynomial')
    dom = Gv.D_bivector(om, lam); de = gs.zero_list(n)
    for (A, b), (c, h) in L_.h.items(): de[c] = Fm.add(de[c], Fm.wedge(lam[A], e[b]), -h)
    dT = [Fm.d(de[c]) for c in range(n)]
    for (A, b), (c, h) in L_.h.items(): dT[c] = Fm.add(dT[c], Fm.add(Fm.wedge(dom[A], e[b]), Fm.wedge(om[A], de[b])), h)
    wantT = gs.zero_list(n)
    for (A, b), (c, h) in L_.h.items(): wantT[c] = Fm.add(wantT[c], Fm.wedge(lam[A], T[b]), -h)
    chk('bit', gs.lst_eq(dT, wantT), 'n = 3: delta T = -(1/2)[lambda, T] under delta omega = D lambda, delta e = -(1/2)[lambda, e], as a polynomial identity (84 coefficients)')
    dR = [Fm.d(dom[C]) for C in range(G)]
    for (A, B), (C, f) in L_.f.items(): dR[C] = Fm.add(dR[C], Fm.add(Fm.wedge(dom[A], om[B]), Fm.wedge(om[A], dom[B])), F(f, 4))
    wantR = gs.zero_list(G)
    for (A, B), (C, f) in L_.f.items(): wantR[C] = Fm.add(wantR[C], Fm.wedge(R[A], lam[B]), F(f, 2))
    chk('bit', gs.lst_eq(dR, wantR), 'n = 3: delta R = (1/2)[R, lambda] as a polynomial identity (48 coefficients)')
    DD = Gv.D_spinor(om, Gv.D_spinor(om, psi)); want = {}
    for A, g in enumerate(L_.gens):
        for S, p in psi.items():
            m, s = bmul(g, S, L_.sq); want[m] = Fm.add(want.get(m, {}), Fm.wedge(R[A], p), F(s, 2))
    want = {m: x for m, x in want.items() if x}
    chk('bit', all(gs.Gr_eq(DD.get(m, {}), want.get(m, {})) for m in set(DD) | set(want)), 'n = 3: D D psi = (1/2) R psi as a polynomial identity (52 coefficients, psi an even multivector)')
    for c in (0, 1):
        E, F_ = Gv.einstein(None, e, R, F(c)); DE = Gv.D_covector(om, E); rhs = Gv.einstein_rhs(e, T, R, F(c), F_)
        chk('bit', gs.lst_eq(DE, rhs), 'n = 3 c = %d: D E_a = torsion terms as a polynomial identity in the 72 jet coefficients of (omega, e)' % c)
    print('  (both sides are linear in c, so c = 0 and c = 1 cover every c)')
    tline('part 2', t)

# ------------------------------------------------------------------------------------------------ Part 3: the Schwartz-Zippel table
def p_rpoly(density, values=7): return 1 - density + density / values
def part3():
    head('Part 3 [std] jet order, degree and the Schwartz-Zippel bound per run, for each identity the Atlas checks on random polynomial fields'); t = T0()
    rows = [('I1 second Bianchi D R = 0', 'omega: 2 (1 after d d = 0)', 3, 'identities: rform deg 1, density 0.6, 7 values', p_rpoly(.6), 'n = 2..5, one seed each'),
            ('I2 first Bianchi D T = R e', 'e: 2 (1 after d d = 0); omega: 1', 3, 'same', p_rpoly(.6), 'n = 2..5, one seed each'),
            ('I3 covariance delta R, delta T', 'lambda: 2 (1 after d d = 0); omega, e: 1', 3, 'lambda: rpoly deg 2 density 0.5; omega, e as above', p_rpoly(.5), 'n = 2..5, one seed each'),
            ('I4 spinor D D psi = (1/2) R psi', 'psi: 2 (1 after d d = 0); omega: 1', 3, 'psi: rpoly deg 2 density 0.5', p_rpoly(.5), 'n = 2..5, one seed each'),
            ('I5 D E_a = torsion terms (n = 3, 4, 5)', 'omega: 2 (1 after d d = 0); e: 1', 'n', 'einstein_identities: rform deg 1 density 0.5', p_rpoly(.5), '(3,0),(3,1),(4,0),(4,1),(5,0)'),
            ('dS embedding F = R + k e e, F^{an} = mu T', 'omega, e: 1', 2, 'desitter_embedding: rform deg 1 density 0.5', p_rpoly(.5), 'n = 3, 4; s = -1, +1'),
            ('A3 T(omega(e)) = 0 (rational; times det^2)', 'e: 1', '2n', 'rand_frame coef 3 density 0.55 (non-constant coefficients)', p_rpoly(.55), 'n = 2..6, several seeds'),
            ('A4 E_a = -(G - Lambda) Theta (rational)', 'e: 2', '<=10n', 'rand_frame coef 2 density 0.5, 5 values', p_rpoly(.5, 5), 'n = 3, 4, 5'),
            ('B1 first variation', 'omega, e, delta: 1', 'n (MM: 4)', 'rform deg 1, density as set by b1', p_rpoly(.5), 'n = 3, 4, 5')]
    print('  %-44s %-42s %-8s %-58s %-7s %-12s %s' % ('identity', 'jet order', 'degree', 'sampler', 'p', 'bound/run', 'runs'))
    for (name, order, D, sampler, p, runs) in rows:
        bound = ('%.2f' % (D * p)) if isinstance(D, int) else ('%s x %.3f' % (D, p))
        print('  %-44s %-42s %-8s %-58s %.4f  %-12s %s' % (name, order, D, sampler, p, bound, runs))
    print('  p = largest point mass of one coefficient = P(coefficient = 0) = 1 - density + density/values; the rform component drop (0.1) adds <= 0.1 m_c.')
    print('  Every bound above is >= 1 (vacuous) at the engine\'s settings; a sampler with coefficients uniform in {-50..50}, density 1, gives D/101 per run.')
    # p checked against the engine's rpoly: frequency of zero coefficients and of the fallback
    rng = random.Random(5); n = 3; zeros = tot = fb = 0; mons = [ex for ex in itertools.product(range(2), repeat=n) if sum(ex) <= 1]
    for _ in range(4000):
        q = gs.rpoly(rng, n, 1, .6)
        if q == {(0,) * n: F(1)} and len(q) == 1: fb += 1
        for ex in mons: tot += 1; zeros += (q.get(ex, 0) == 0)
    p_meas = zeros / tot; p_th = p_rpoly(.6); sig = math.sqrt(p_th * (1 - p_th) / tot)
    chk('std', abs(p_meas - p_th) < 4 * sig + 0.4 ** 4 / 4, 'rpoly(deg 1, density 0.6): measured P(coefficient = 0) = %.4f vs p = %.4f (+-%.4f; the fallback, measured %.4f vs 0.4^4 = %.4f, shifts it by < 0.007)' % (p_meas, p_th, 4 * sig, fb / 4000, .4 ** 4))
    tline('part 3', t)

# ------------------------------------------------------------------------------------------------ Part 4: calibration
def my_poly(rng, n, deg, R, density):
    mons = [e for e in itertools.product(range(deg + 1), repeat=n) if sum(e) <= deg]
    return {e: F(rng.randint(-R, R)) for e in mons if rng.random() < density}
def my_form(rng, n, degree, deg, R, density):
    return {sum(1 << i for i in idx): my_poly(rng, n, deg, R, density) for idx in itertools.combinations(range(n), degree)}
def part4():
    head('Part 4 [std][ctl] calibration at n = 3: measured miss rates of false identities against the bound D p'); t = T0(); n = 3; Gv = Grav(n); L_ = Gv.L
    S = 60 if QUICK else 300; D = 3
    f_flip = flipped_f(L_); h_flip = flipped_h(L_)
    settings = [(1, 1.0), (2, 1.0), (5, 1.0), (3, 0.6)]
    falses = {'R with 1/3': lambda om, e: residual_DR(Gv, om, F(1, 3)), 'R with 1/2 (= fault M1)': lambda om, e: residual_DR(Gv, om, F(1, 2)),
              'one f entry flipped': lambda om, e: residual_DR(Gv, om, F(1, 4), f_flip), 'one h entry flipped (D T = R e)': lambda om, e: residual_DT(Gv, om, e, h_flip)}
    for (R, dens) in settings:
        p = 1 - dens + dens / (2 * R + 1); bound = D * p; rng = random.Random(1000 * R + int(10 * dens))
        miss = {k: 0 for k in falses}; true_fail = 0
        for s in range(S):
            om = [my_form(rng, n, 1, 1, R, dens) for _ in range(Gv.G)]; e = [my_form(rng, n, 1, 1, R, dens) for _ in range(n)]
            if not allzero(residual_DR(Gv, om)) or not allzero(residual_DT(Gv, om, e)): true_fail += 1
            for k, fn in falses.items():
                if allzero(fn(om, e)): miss[k] += 1
        chk('bit', true_fail == 0, 'coefficients uniform in {-%d..%d}, density %.1f, %d seeds: the true identities (engine f, h, 1/4) pass every seed' % (R, R, dens, S))
        for k, m in miss.items():
            rate = m / S; tag = 'ctl' if bound < 1 else 'std'
            chk(tag, rate <= bound, 'same sampling: false identity "%s" missed %d/%d = %.4f  <=  bound D p = %d x %.3f = %.3f%s' % (k, m, S, rate, D, p, bound, '' if bound < 1 else ' (vacuous: reported as a measurement)'))
    # the bound is attainable: Q = x (x - 1) ... (x - D + 1), x uniform in {0 .. 2R}
    for R in (2, 5):
        rng = random.Random(77 + R); M = 2 * R + 1; S2 = 2000 if QUICK else 6000; hits = sum(1 for _ in range(S2) if rng.randrange(M) < D)
        rate = hits / S2; b = D / M; sig = math.sqrt(b * (1 - b) / S2)
        chk('ctl', abs(rate - b) < 4 * sig, 'tight case Q = x(x-1)(x-2), x uniform in {0..%d}: measured zero rate %.4f vs bound D/|S| = %.4f (+-%.4f): the bound is attained' % (M - 1, rate, b, 4 * sig))
    tline('part 4', t)

if __name__ == '__main__':
    print('A2 jet lemma and sampling bound%s' % (' (--quick)' if QUICK else '')); t_all = T0()
    part1(); part2(); part3(); part4()
    tline('total', t_all); finish('A2')
