#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A6-strong.  The topological companions of a6_topological.py on strong random data, with a stated failure bound.

   python3 a6_strong.py [PART ...]     PARTs: degree cs2 cs1 ny t0 mm n5 n2 calib table   (no PART: all of them, the shipped run)

 Statement: the identities of a6_topological.py hold exactly on data whose every jet coefficient is an integer uniform in {-R..R} (R = 50: point mass
 p = 1/101; R = 500 where stated), three independent seeds per case, connections (and frames) of x-degree 2 and 1 as A6 has them (n = 4):
   Chern-Simons (f table)   k(R,R) = d k(omega, a d omega + x Q): exact fit (a, x) = (1, 1/6), rank 2; k(Q,Q) = 0       (Euler and Pontryagin)
   the exact k(R,R)         21 + 21 symmetric unknowns (k, m): nullity 12, k-part span(Pontryagin, Euler), m-part = the m with m(omega, Q) = 0
   h table                  tr(R R) = d tr(omega d omega + (2/3) omega^3), eps R R = d eps omega (d omega + (2/3) omega omega); tr [h] = -R^{ab} R_{ab} [f]
   Nieh-Yan                 d(e^a T_a) = T^a T_a - e^a e^b R_ab, fit (1, -1);   Holst  e^a e^b R_ab = e_a D T^a
   T = 0                    A3's closed form on strong frames: T = 0 through first order, Holst = 0 at the point, eps e e R = 2 e^a E_a(0) = 2 R_s vol(e)
   MacDowell-Mansouri       eps F F = eps R R + 2c eps R e e + c^2 eps e^4 and eps F F - d CS_E = 8c L_R + 24 c^2 vol(e)   (c = 0, 1, -2/3, 5/7)
   n = 5                    R^{ab} R_{ab} = d CS_P (fit (1, 1/6)), nullity 1 of (k, m), Nieh-Yan and Holst as 4-forms;   n = 2: eps_{ab} R^{ab} = d(2 omega^{01}).
 Bound: a false identity whose residual is a non-zero polynomial of degree <= D in the sampled coefficients (denominators cleared) passes one seed with
   probability <= D p / (1 - r p) (Schwartz-Zippel, recalled; r = degree of a rejected polynomial: det e(0) for frames), three seeds <= its cube.
   What is counted: R = d omega + Q/4 has degree 1 and 2 in the coefficients of omega, T = de + h omega e degree 1 and 2, d adds none; so R R, the
   Chern-Simons side, T T, e e R, e D T, eps F F, L_R and vol(e) all have degree <= 4: D = 4 for every form identity, D = 1 at n = 2 (R = d omega).
   At T = 0 the closed form is rational in the frame jets (E0 = adj(e0)/det e0): T to first order (3n + 1)/det^3, R(0) 4n/det^4, Holst e0 e0 R(0) and
   e^a E_a(0) 4n + 2, R_s vol(e) by Christoffel symbols (7n - 2)/det^6: D = 3n + 1, 4n + 2, 7n - 2; r = n.
   Fits and ranks: a rank seen on a sample is a lower bound of the generic rank, so 'rank 2 of 2' seen once is certain and the fit is then unique; a
   null space seen on a sample contains the space of the identities, so a sample nullity is an upper bound with certainty. The lower bound comes from
   the exhibited null vectors (k, k/6), which carry the bound of the Chern-Simons identity, and from the m-part counted exactly from the f table.
   A degenerate sample can only lower a rank: a visible failure, not a false pass.
 [bit]  a6_topological's functions (Pieces, kform, kpair, cs_form, fit, kspace_cols, ranks_split, vec_rep, nieh_yan_pieces, holst, eps_R_ee, ...) run
   unchanged on data from a2b_strong_sampling's s_poly and s_frame; the engine's d, curvature, torsion, D_vector, einstein; A3's closed form (b1lib);
   B1's lag_MM and lag_EC.  Degree check: the exact degree in t along a random line t -> b + t a (finite differences) of a false residual reaches D.
 [std]  A6's numpy route (no engine) at A6's three points for every seed: so(1,3) matrices, textbook R, tr(R R), 8 Pf(R), Chern-Simons with 2/3,
   T = de + Om e, 7-point stencils (exact for degree <= 6). Tolerance 1e-9 times the scale of the compared values (for a stencil the scale also holds
   max |C| / h over its points); the worst relative difference is printed.  At T = 0 the Christoffel route (exact fractions): eps R_klmn = 0, R_s.
 Controls: cubic coefficient 1/8; the Euclidean pairing (no fit, k(Q,Q) != 0, not in span(P, E)); m = k/8 in place of k/6; the cubic terms k(omega, Q)
   are not zero; y = 1/2 on the h route; 1/2 in place of 2/3 and the sign of tr flipped on the numpy route; Nieh-Yan with a missing factor and with
   Euclidean contractions; a constant contorsion and the wrong-sign closed form at T = 0; MacDowell-Mansouri with c in place of 2c and 12 c^2 in place
   of 24 c^2.  Calibration: four false versions (cubic 1/8; x = 1/3, the textbook 2/3 with the textbook 1/2 in R; the Euclidean pairing; 7c L_R in
   place of 8c L_R) on 20 strong seeds each, n = 4.
 Scope: n = 4 (n = 5 and n = 2 in part 8), exact fractions, fixed seeds.  The bound is a statement about the sampling; a pass adds no physics."""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from fractions import Fraction as F
from decimal import Decimal, Context, ROUND_CEILING
import numpy as np
from b1lib import (chk, head, finish, Grav, Lie, trunc, at0, rank_exact, pairs_of, koszul_S, omega_closed_form, engine_om_R,
                   translate_frame, E0_of, std_metric, std_riemann, std_einstein_mixed)
import a6_topological as A6
import a2b_strong_sampling as AB
from b1_first_variation import lag_MM, lag_EC, wedge_list
from b2_strong import fd_degree

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
R50, R500 = 50, 500
N3 = 3                                                                         # independent seeds per case
TOL = 1e-9                                                                     # [std] tolerance, relative to the stated scale

# ------------------------------------------------------------------------------------------------ strong data in A6's layout (a2b's s_poly, s_frame)
def s_conn(rng, n, deg, R):
    """omega^{ab}_mu(x), a < b, every coefficient of x-degree <= deg an integer uniform in {-R..R}: A6's layout {(a, b): [polynomial per mu]}"""
    return {(a, b): [AB.s_poly(rng, n, deg, R) for _ in range(n)] for (a, b) in itertools.combinations(range(n), 2)}
def s_frame_data(rng, n, deg, R):
    """e^a_mu(x), A6's layout [[polynomial]] (no invertibility needed for the form identities)"""
    return [[AB.s_poly(rng, n, deg, R) for _ in range(n)] for _ in range(n)]

# ------------------------------------------------------------------------------------------------ the bound
BOUND = {}                                                                     # (identity, n, R) -> dict(D, r, N passed, runs)
def note(name, n, D, ok, R=R50, r=0):
    d = BOUND.setdefault((name, n, R), dict(D=D, r=r, N=0, runs=0)); d['N'] += int(bool(ok)); d['runs'] += 1
def bound(D, R, r): p = F(1, 2 * R + 1); return D * p / (1 - r * p)
def up(x, d=3):
    """the Fraction x printed with d significant digits, never below its exact value"""
    return '%.*e' % (d - 1, float(Context(prec=d, rounding=ROUND_CEILING).divide(Decimal(x.numerator), Decimal(x.denominator))))
def near(a, b, scale): return abs(a - b) <= TOL * max(1.0, scale)
def d3_scaled(Cfun, x, h=0.2):
    """A6's 7-point d of a 3-form at x, and the float scale max |C| / h over the stencil points"""
    big = [0.0]
    def C(xx):
        out = Cfun(xx); big[0] = max([big[0]] + [abs(v) for v in out.values()]); return out
    return A6.std_d3(C, x, h), big[0] / h

# ------------------------------------------------------------------------------------------------ the m-part from the f table (exact, no sampling)
def perm_sign(t):
    s = 1
    for i in range(len(t)):
        for j in range(i + 1, len(t)):
            if t[i] > t[j]: s = -s
    return s
def m_alg(Gv):
    """[bit] the matrix of m -> m(omega, Q) = sum_{A,B} m_AB omega^A ^ Q^B, Q^B = f_CD^B omega^C ^ omega^D (the engine's f table), in the basis
    omega^X ^ omega^Y ^ omega^Z (X < Y < Z); columns: the symmetric unknowns m_AB, A <= B (the order of a6_topological.kvec).  The 3-forms
    omega^X omega^Y omega^Z are independent as polynomials in omega (n >= 3), so the null space is the m with m(omega, Q) = 0 for every omega."""
    G = Gv.G; unk = [(a, b) for a in range(G) for b in range(a, G)]; tri = {t: i for i, t in enumerate(itertools.combinations(range(G), 3))}
    M = [[F(0)] * len(unk) for _ in tri]; byB = {}
    for (C, D), (B, val) in Gv.L.f.items(): byB.setdefault(B, []).append((C, D, val))
    for j, (a, b) in enumerate(unk):
        for (A, B) in sorted({(a, b), (b, a)}):
            for (C, D, val) in byB.get(B, []):
                t = (A, C, D)
                if len(set(t)) == 3: M[tri[tuple(sorted(t))]][j] += perm_sign(t) * val
    return M
def matvec(M, v): return [sum(a * b for a, b in zip(row, v)) for row in M]
def cs_parts(Gv, k, om, pre=None):
    """(k(R,R), d k(omega, d omega), d k(omega, Q)) for one connection; pre = (R, Q, d omega) if already computed"""
    Fm = Gv.Fm; R, Q, dom = pre or (Gv.curvature(om), A6.Qforms(Gv, om), [Fm.d(w) for w in om])
    return A6.kpair(Gv, k, R, R), Fm.d(A6.kpair(Gv, k, om, dom)), Fm.d(A6.kpair(Gv, k, om, Q))

# ================================================================================================ degree along a line
def part_degree():
    t = time.time(); n = 4; Gv = Grav(n, Lie(A6.LOR(n))); Fm = Gv.Fm; kU, kE = A6.kform(Gv, 'Eucl'), A6.kform(Gv, 'E')
    head('Degree [bit]: exact degree in t of a false residual along a random line t -> b + t a of strong data (finite differences): D is reached')
    def res(k, x):
        return lambda om, e: [Fm.add(cs_parts(Gv, k, om)[0], Fm.d(A6.cs_form(Gv, k, om, x)), -1)]
    d1 = AB.line_degree(n, Gv.G, res(kU, F(1, 6)), 5, 61); d2 = AB.line_degree(n, Gv.G, res(kE, F(1, 8)), 5, 62)
    chk('bit', d1 == 4 and d2 == 3, 'n = 4, x-degree-1 omega: the Euclidean pairing k(R,R) - d k(omega, d omega + Q/6) has degree %d along the line (D = 4 reached: '
        'its quartic term k(Q,Q) is not zero); Euler with the cubic coefficient 1/8 has degree %d (its residual is (1/24) d k(omega, Q))' % (d1, d2))
    sq = Gv.L.sq; S = koszul_S(n, sq, Gv.L); rng = random.Random(77400); Dh = 4 * n + 2
    while True:
        a = AB.s_frame(rng, n, 2, R50); b = AB.s_frame(rng, n, 2, R50); line = [[Fm.add(x, y, s) for x, y in zip(b, a)] for s in range(Dh + 2)]
        dets = [E0_of(fr, n, n)[2] for fr in line]
        if all(dt != 0 for dt in dets): break
    vals = []
    for fr, dt in zip(line, dets):
        om, Rr = engine_om_R(Gv, fr, S, n)
        with trunc(n, xdeg=0): dual = A6.eps_R_ee(Gv, fr, Rr)
        vals.append({0: at0(dual.get(15, {}), n) * dt ** 4})
    dd = fd_degree(vals)
    chk('bit', dd == Dh, 'n = 4, A3 closed form (T = 0) on a line of strong frames: det(e(0))^4 times the dual eps e e R at the point has degree %d '
        '(t = 0..%d): the count 4n + 2 = %d of e0 e0 R(0) (the Holst count) is reached and not exceeded' % (dd, Dh + 1, Dh))
    print('  time degree: %.1f s' % (time.time() - t), flush=True)

# ================================================================================================ parts 1, 3, 4: Chern-Simons
def h_route(Gv, om, pc, tag, deg, kP, kE):
    Fm = Gv.Fm; n = Gv.n; sq = Gv.L.sq
    Wv = A6.vec_rep(Gv, om); Rv = A6.vec_rep(Gv, pc.R); dWv = [[Fm.d(x) for x in row] for row in Wv]; WW = A6.mat_wedge(Fm, Wv, Wv)
    tgt = A6.trace_wedge(Fm, Rv, Rv); p1 = Fm.d(A6.trace_wedge(Fm, Wv, dWv)); p3 = Fm.d(A6.trace_wedge(Fm, WW, Wv))
    w, rk, nv, cons = A6.fit(tgt, [p1, p3]); ok1 = cons and rk == 2 and w == [1, F(2, 3)]
    chk('bit', ok1, '%s h table: tr(R ^ R) = d tr(z omega d omega + y omega^3), exact fit (z, y) = %s, rank %d (predicted (1, 2/3))' % (tag, A6.fmt(w), rk))
    chk('ctl', not A6.eqf(Fm, Fm.add(p1, p3, F(1, 2)), tgt), '%s h table: y = 1/2 is not exact' % tag)
    ok2 = A6.eqf(Fm, tgt, Fm.scale(pc.comb(kP, 'RR'), -1)); chk('bit', ok2, '%s tr(R ^ R) [h table] = - R^{ab} R_{ab} [f table]' % tag)
    upi = lambda M: [[Fm.scale(M[a][b], sq[b]) for b in range(n)] for a in range(n)]
    Wu, WWu, Ru = upi(Wv), upi(WW), upi(Rv); dWu = [[Fm.d(x) for x in row] for row in Wu]
    tE = A6.eps_pairs(Gv, Ru, Ru); w2, rk2, nv2, cons2 = A6.fit(tE, [Fm.d(A6.eps_pairs(Gv, Wu, dWu)), Fm.d(A6.eps_pairs(Gv, Wu, WWu))])
    ok3 = cons2 and rk2 == 2 and w2 == [1, F(2, 3)]
    chk('bit', ok3, '%s h table: eps R R = d eps omega (z d omega + y omega omega), exact fit (z, y) = %s (predicted (1, 2/3))' % (tag, A6.fmt(w2)))
    ok4 = A6.eqf(Fm, tE, pc.comb(kE, 'RR')); chk('bit', ok4, '%s eps R R [h table] = eps R R [f table]' % tag)
    note('h table: tr and eps fits (1, 2/3); tr = -R^{ab}R_{ab}; eps [h] = eps [f]; x-degree %d' % deg, n, 4, ok1 and ok2 and ok3 and ok4)

def std_route(Gv, W, om, pc, tag, kP, kE):
    SF = A6.StdFields(W); csP = A6.cs_form(Gv, kP, om, F(1, 6), Q=pc.Q); csE = A6.cs_form(Gv, kE, om, F(1, 6), Q=pc.Q)
    rrP = pc.comb(kP, 'RR'); rrE = pc.comb(kE, 'RR'); ok = dict(d=True, Pf=True, R=True, V=True, C=True); ctl = dict(half=True, sign=True); worst = 0.0
    for x in A6.PTS:
        Om, dOm = SF.conn(x); Rm = SF.curv(Om, dOm); P = A6.std_pont(Rm); Eu = A6.std_euler_pf(Rm); sv = max(abs(P), abs(Eu))
        dP, sP = d3_scaled(lambda xx: A6.std_cs_tr(*SF.conn(xx), 2. / 3), x); dE, sE = d3_scaled(lambda xx: A6.std_cs_euler(*SF.conn(xx), 2. / 3), x)
        sd = max(sv, sP, sE); ok['d'] &= near(dP, P, sd) and near(dE, Eu, sd); worst = max(worst, abs(dP - P) / max(1.0, sd), abs(dE - Eu) / max(1.0, sd))
        ok['Pf'] &= near(Eu, A6.std_euler_eps(Rm), sv)
        hP = d3_scaled(lambda xx: A6.std_cs_tr(*SF.conn(xx), .5), x)[0]; hE = d3_scaled(lambda xx: A6.std_cs_euler(*SF.conn(xx), .5), x)[0]
        ctl['half'] &= not near(hP, P, sd) and not near(hE, Eu, sd)
        U = A6.std_Rup(Rm); su = float(np.abs(U).max())
        for A, (a, b) in enumerate(pairs_of(Gv.L)):
            for (m, v) in itertools.combinations(range(4), 2): ok['R'] &= near(A6.ev(pc.R[A].get((1 << m) | (1 << v), {}), x), U[a, b, m, v], su)
        vP = A6.ev(rrP.get(15, {}), x); vE = A6.ev(rrE.get(15, {}), x); ok['V'] &= near(vP, -P, sv) and near(vE, Eu, sv); ctl['sign'] &= not near(vP, P, sv)
        cP = A6.std_cs_tr(Om, dOm, 2. / 3); cE = A6.std_cs_euler(Om, dOm, 2. / 3); s3 = max([1.0] + [abs(v) for v in list(cP.values()) + list(cE.values())])
        for tri in A6.TRIPLES:
            msk = sum(1 << i for i in tri); ok['C'] &= near(A6.ev(csP.get(msk, {}), x), -cP[tri], s3) and near(A6.ev(csE.get(msk, {}), x), cE[tri], s3)
    chk('std', ok['d'], '%s: d CS_tr(2/3) = tr(R ^ R) and d CS_eps(2/3) = 8 Pf(R) at 3 points (worst |difference| / scale %.1e, tolerance %.0e)' % (tag, worst, TOL))
    chk('std', ok['Pf'], '%s: 8 Pf(R^{..}) = eps_{abcd} R^{ab} R^{cd} at 3 points' % tag)
    chk('ctl', ctl['half'], '%s [std]: the coefficient 1/2 in place of 2/3 fails for tr and for eps at every point' % tag)
    chk('bit==std', ok['R'], '%s: engine R^{ab}_{mu nu} = textbook R = d omega + omega omega (matrices, eta) at 3 points, all 36 components' % tag)
    chk('bit==std', ok['V'], '%s: engine R^{ab} R_{ab} = - tr(R ^ R)_std and engine eps R R = 8 Pf_std at 3 points' % tag)
    chk('bit==std', ok['C'], '%s: engine CS_P (x = 1/6) = - CS_tr,std (2/3) and engine CS_E (1/6) = CS_eps,std (2/3), 4 components at 3 points' % tag)
    chk('ctl', ctl['sign'], '%s: engine R^{ab} R_{ab} against + tr(R ^ R)_std (sign flipped) fails' % tag)

def part_cs(n=4, degs=(2, 1)):
    Gv = Grav(n, Lie(A6.LOR(n))); Fm = Gv.Fm; kP, kE, kU = A6.kform(Gv, 'P'), A6.kform(Gv, 'E'), A6.kform(Gv, 'Eucl'); keep = {}
    head('1, 3, 4. Chern-Simons forms, n = 4, strong omega (every coefficient an integer uniform in -50..50) of x-degree %s, three seeds each: '
         'the f-table fit, the h-table fit, the numpy route at three points' % ' and '.join(str(d) for d in degs))
    for deg in degs:
        for seed in AB.seeds_for('A6S-CS', n, N3, deg):
            rng = random.Random(seed); W = s_conn(rng, n, deg, R50); om = A6.eng_conn(Gv, W); pc = A6.Pieces(Gv, om); keep[(deg, seed)] = (W, om, pc)
            tag = 'deg %d seed %d' % (deg, seed)
            for k, name in ((kE, 'Euler eps_{abcd} R^{ab} R^{cd}'), (kP, 'Pontryagin R^{ab} R_{ab}')):
                tgt = pc.comb(k, 'RR'); w, rk, nv, cons = A6.fit(tgt, [pc.comb(k, 'WdW'), pc.comb(k, 'WQ')]); okf = cons and rk == 2 and w == [1, F(1, 6)]
                chk('bit', okf, '%s %s: exact fit (a, x) = %s, rank %d of 2 (predicted (1, 1/6) = textbook 2/3 times the engine 1/4)' % (tag, name, A6.fmt(w), rk))
                okd = not A6.iszero(tgt) and A6.eqf(Fm, Fm.d(A6.cs_form(Gv, k, om, F(1, 6), Q=pc.Q)), tgt)
                chk('bit', okd, '%s %s = d CS exactly (CS assembled as a 3-form, the engine d applied; %d monomials in the 4-form)' % (tag, name, sum(len(p) for p in tgt.values())))
                chk('ctl', not A6.eqf(Fm, Fm.d(A6.cs_form(Gv, k, om, F(1, 8), Q=pc.Q)), tgt), '%s %s: cubic coefficient 1/8 is not exact' % (tag, name))
                okq = A6.iszero(A6.kpair(Gv, k, pc.Q, pc.Q)); chk('bit', okq, '%s %s: the quartic term k(Q, Q) vanishes' % (tag, name))
                note('%s: k(R,R) = d CS, fit (1, 1/6), k(Q,Q) = 0; x-degree %d' % (name.split(' ')[0], deg), n, 4, okf and okd and okq)
            w, rk, nv, cons = A6.fit(pc.comb(kU, 'RR'), [pc.comb(kU, 'WdW'), pc.comb(kU, 'WQ')])
            chk('ctl', not cons, '%s Euclidean pairing sum R^{ab} R^{ab} on the Lorentz algebra: no (a, x) makes it exact' % tag)
            chk('ctl', not A6.iszero(A6.kpair(Gv, kU, pc.Q, pc.Q)), '%s Euclidean pairing: k(Q, Q) is not zero' % tag)
            h_route(Gv, om, pc, tag, deg, kP, kE); std_route(Gv, W, om, pc, tag, kP, kE)
        tick('parts 1, 3, 4, x-degree %d' % deg)
    return Gv, keep

# ================================================================================================ part 2: the exact k(R,R)
def part_kspace(Gv, keep):
    G = Gv.G
    head('2. All symmetric (k, m) with k(R,R) = d[k(omega, d omega) + m(omega, Q)] (21 + 21 unknowns) on the three strong x-degree-2 connections; '
         'the m with m(omega, Q) = 0 also counted exactly from the f table')
    M = m_alg(Gv); malg = len(M[0]) - rank_exact(M)
    vP = A6.kvec(Gv, A6.kform(Gv, 'P')); vE = A6.kvec(Gv, A6.kform(Gv, 'E')); vU = A6.kvec(Gv, A6.kform(Gv, 'Eucl'))
    chk('bit', malg == 10, 'exact, f table only: the m with m(omega, Q) = 0 for every omega form a space of dimension %d (%d unknowns, %d conditions, rank %d)' % (malg, len(M[0]), len(M), len(M[0]) - malg))
    chk('ctl', any(matvec(M, vP)) and any(matvec(M, vE)), 'the cubic Chern-Simons terms k_P(omega, Q) and k_E(omega, Q) are not zero: m = k is not in that space')
    sixth = lambda v, q=6: v + [x / q for x in v]
    for (deg, seed), (W, om, pc) in keep.items():
        if deg != 2: continue
        cols = A6.kspace_cols(Gv, [pc]); half = len(cols) // 2; kc, mc = cols[:half], cols[half:]
        keys = sorted({(m, k) for X in cols for m, p in X.items() for k in p})
        rm, rall = A6.ranks_split([[X.get(m, {}).get(kk, F(0)) for X in mc + kc] for (m, kk) in keys], len(mc)); nul_all = len(cols) - rall; nul_m = len(mc) - rm
        m3 = [pc.comb({(A, B): F(1), (B, A): F(1)} if A < B else {(A, A): F(1)}, 'WQ3') for A in range(G) for B in range(A, G)]
        k3 = sorted({(m, k) for X in m3 for m, p in X.items() for k in p}); r3 = A6.ranks_split([[X.get(m, {}).get(kk, F(0)) for X in m3] for (m, kk) in k3], len(m3))[1]
        inP = not A6.residual(cols, sixth(vP)); inE = not A6.residual(cols, sixth(vE)); indep = rank_exact([vP, vE]) == 2
        ok = nul_all - nul_m == 2 and inP and inE and indep and nul_m == malg and len(m3) - r3 == malg
        chk('bit', ok, 'seed %d: nullity of (k, m) %d (rank %d, %d rows); with k = 0: %d; undifferentiated m(omega, Q): %d; f-table count: %d. So the k-part is '
            '%d-dimensional = span(Pontryagin, Euler), both null with m = k/6 (%s, %s), and the nullity is exactly 2 + %d' % (seed, nul_all, rall, len(keys), nul_m, len(m3) - r3, malg, nul_all - nul_m, inP, inE, malg))
        chk('ctl', bool(A6.residual(cols, sixth(vU))) and rank_exact([vP, vE, vU]) == 3, 'seed %d: the Euclidean pairing (k_Eucl, k_Eucl/6) is not a null vector and k_Eucl is not in span(k_P, k_E)' % seed)
        chk('ctl', bool(A6.residual(cols, sixth(vP, 8))) and bool(A6.residual(cols, sixth(vE, 8))), 'seed %d: m = k/8 in place of k/6 is not a null vector (Pontryagin, Euler)' % seed)
        note('the exact k(R,R): nullity 2 + 10, k-part span(P, E) (null vectors by the CS identity)', 4, 4, ok)
    tick('part 2')

# ================================================================================================ parts 5 and 6 (i): Nieh-Yan, Holst
def part_ny(n=4):
    Gv = Grav(n, Lie(A6.LOR(n))); Fm = Gv.Fm; sq = Gv.L.sq
    head('5, 6 (i). Nieh-Yan d(e^a T_a) = T^a T_a - e^a e^b R_ab and Holst e^a e^b R_ab = e_a D T^a, n = 4, strong (e, omega) of x-degree 2 and 1, '
         'three seeds each (no condition on e or T); [std] textbook T = de + Om e and stencils at 3 points')
    for deg in (2, 1):
        for seed in AB.seeds_for('A6S-NY', n, N3, deg):
            rng = random.Random(seed); W = s_conn(rng, n, deg, R50); E = s_frame_data(rng, n, deg, R50); om = A6.eng_conn(Gv, W); e = A6.eng_frame(E)
            tag = 'deg %d seed %d' % (deg, seed); eT, TT, eeR, R, T = A6.nieh_yan_pieces(Gv, e, om); deT = Fm.d(eT)
            ok1 = not A6.iszero(TT) and not A6.iszero(eeR) and A6.eqf(Fm, deT, Fm.add(TT, eeR, -1))
            chk('bit', ok1, '%s: d(e^a T_a) = T^a T_a - e^a e^b R_ab exactly (T T != 0, e e R != 0)' % tag)
            w, rk, nv, cons = A6.fit(deT, [TT, eeR]); ok2 = cons and rk == 2 and w == [1, -1]
            chk('bit', ok2, '%s: exact fit of the coefficients (T T, e e R) = %s, rank %d (predicted (1, -1))' % (tag, A6.fmt(w), rk))
            chk('ctl', not A6.eqf(Fm, deT, Fm.add(TT, eeR, F(-1, 2))) and not A6.eqf(Fm, deT, Fm.add(Fm.scale(TT, 2), eeR, -1)), '%s: a missing factor (- 1/2 e e R, or 2 T T) fails' % tag)
            eTu, TTu, eeRu, _, _ = A6.nieh_yan_pieces(Gv, e, om, eta=False); w, rk, nv, cons = A6.fit(Fm.d(eTu), [TTu, eeRu])
            chk('ctl', not cons, '%s: Euclidean contractions (e^a T^a, T^a T^a, e^a e^b R^{ab}) on the Lorentz frame: no coefficients make it exact' % tag)
            note('Nieh-Yan d(e^a T_a) = T^a T_a - e^a e^b R_ab, fit (1, -1); x-degree %d' % deg, n, 4, ok1 and ok2)
            DT = Gv.D_vector(om, T); rhs = {}
            for c in range(n): rhs = Fm.add(rhs, Fm.wedge(e[c], DT[c]), sq[c])
            ok3 = not A6.iszero(eeR) and A6.eqf(Fm, eeR, rhs); chk('bit', ok3, '%s: Holst e^a e^b R_ab = e_a D T^a exactly (first Bianchi D T = R e; T != 0 here)' % tag)
            note('Holst e^a e^b R_ab = e_a D T^a; x-degree %d' % deg, n, 4, ok3)
            SF = A6.StdFields(W, E); okS = okB = True; worst = 0.0
            for x in A6.PTS:
                seT, sTT, seeR, sT = A6.std_ny(SF, x); d, sdc = d3_scaled(lambda xx: A6.std_ny(SF, xx)[0], x); sv = max(abs(sTT), abs(seeR)); sd = max(sv, sdc)
                okS &= near(d, sTT - seeR, sd); worst = max(worst, abs(d - sTT + seeR) / max(1.0, sd))
                okB &= near(A6.ev(TT.get(15, {}), x), sTT, sv) and near(A6.ev(eeR.get(15, {}), x), seeR, sv)
                s3 = max([1.0] + [abs(v) for v in seT.values()]); st = float(np.abs(sT).max())
                for tri in A6.TRIPLES: okB &= near(A6.ev(eT.get(sum(1 << i for i in tri), {}), x), seT[tri], s3)
                for a in range(n):
                    for (m, v) in itertools.combinations(range(4), 2): okB &= near(A6.ev(T[a].get((1 << m) | (1 << v), {}), x), sT[a, m, v], st)
            chk('std', okS, '%s [std]: textbook T = de + omega e, d(e^a T_a) (7-point stencil) = T^a T_a - e^a e^b R_ab at 3 points (worst |difference| / scale %.1e)' % (tag, worst))
            chk('bit==std', okB, '%s: engine T^a, e^a T_a, T^a T_a, e^a e^b R_ab = textbook values at 3 points' % tag)
        tick('parts 5, 6 (i), x-degree %d' % deg)

# ================================================================================================ part 6 (ii): T = 0
def part_T0(R):
    n = 4; Gv = Grav(n, Lie(A6.LOR(n))); Fm = Gv.Fm; sq = Gv.L.sq; S = koszul_S(n, sq, Gv.L)
    head('6 (ii). Holst at T = 0: A3 closed-form omega of three strong frames (x-degree 2, every coefficient uniform in -%d..%d, det e(0) != 0 by rejection), '
         'at the origin (counted in the bound) and at a rational point (the same frame translated; not counted)' % (R, R))
    for seed in AB.seeds_for('A6S-H0', n, N3, R % 7):
        rng = random.Random(seed); e0f = AB.s_frame(rng, n, 2, R)
        while True:
            pt = [F(rng.randint(-3, 3), rng.randint(2, 5)) for _ in range(n)]; et = translate_frame(e0f, pt, n)
            if E0_of(et, n, n)[2] != 0: break
        for where, e in (('origin', e0f), ('rational point', et)):
            om, Rr = engine_om_R(Gv, e, S, n)
            with trunc(n, xdeg=1):
                T = Gv.torsion(om, e); H = A6.holst(Gv, e, Rr); dual = A6.eps_R_ee(Gv, e, Rr); Ea, _ = Gv.einstein(None, e, Rr, 0); eE = {}
                for a in range(n): eE = Fm.add(eE, Fm.wedge(e[a], Ea[a]))
            okT = all(not p for c in T for p in c.values()); okH = at0(H.get(15, {}), n) == 0; dv = at0(dual.get(15, {}), n)
            g = std_metric(e, n, sq, n, 2); Rs_, g0, g0i = std_riemann(g, n, n, 1); Gm, ric, Rsc = std_einstein_mixed(Rs_, g0, g0i, n)
            Rl = {(k_, l, m, v): sum(g0[k_][r_] * Rs_[(r_, l, m, v)] for r_ in range(n)) for k_ in range(n) for l in range(n) for m in range(n) for v in range(n)}
            okStd = sum(int(A6.LC4[p]) * Rl[p] for p in itertools.permutations(range(n))) == 0
            okLink = 2 * at0(eE.get(15, {}), n) == dv and dv == 2 * Rsc * E0_of(e, n, n)[2]
            K = [{1 << mu: {(0,) * n: F(rng.choice((-1, 1)) * rng.randint(1, R))} for mu in range(n)} for _ in range(Gv.G)]
            omK = [Fm.add(om[A], K[A]) for A in range(Gv.G)]; omS = omega_closed_form(Gv, e, S, n, 1, -1)[0]
            with trunc(n, xdeg=1):
                TK = Gv.torsion(omK, e); HK = A6.holst(Gv, e, Gv.curvature(omK)); TS = Gv.torsion(omS, e); HS = A6.holst(Gv, e, Gv.curvature(omS))
            ctlK = any(at0(p, n) != 0 for c in TK for p in c.values()) and at0(HK.get(15, {}), n) != 0
            ctlS = any(at0(p, n) != 0 for c in TS for p in c.values()) and at0(HS.get(15, {}), n) != 0
            tag = 'R = %d seed %d, %s' % (R, seed, where)
            chk('bit', okT and okH, '%s: T(omega_closed_form) = 0 through first order (every coefficient of the 1-jet) and Holst e^a e^b R_ab = 0 at the point' % tag)
            chk('std', okStd, '%s: eps^{klmn} R_{klmn} = 0 for the Riemann tensor of g = e^T eta e (Christoffel route, exact fractions)' % tag)
            chk('bit', dv != 0, '%s: the dual eps_{abcd} e^a e^b R^{cd} is NOT zero at T = 0 (%d digits)' % (tag, len(str(abs(dv.numerator)))))
            chk('bit==std', okLink, '%s: eps_{abcd} e^a e^b R^{cd} = 2 e^a ^ E_a(0) [engine E_a] = 2 R_s vol(e) [std scalar curvature] at the point' % tag)
            chk('ctl', ctlK and ctlS, '%s: omega + a constant contorsion, and the closed form with the wrong sign: T != 0 and Holst != 0 at the point' % tag)
            if where == 'origin':
                note('T = 0: T(closed form) = 0 through first order', n, 3 * n + 1, okT, R, n); note('T = 0: Holst = 0 at the point', n, 4 * n + 2, okH, R, n)
                note('T = 0: [std] eps^{klmn} R_{klmn} = 0', n, 4 * n + 2, okStd, R, n); note('T = 0: eps e e R = 2 e^a E_a(0) = 2 R_s vol(e)', n, 7 * n - 2, okLink, R, n)
    tick('part 6 (ii), R = %d' % R)

# ================================================================================================ part 7: MacDowell-Mansouri
def part_mm(n=4):
    Gv = Grav(n, Lie(A6.LOR(n))); Fm = Gv.Fm; kE = A6.kform(Gv, 'E')
    head('7. MacDowell-Mansouri, n = 4, strong (e, omega) of x-degree 1, three seeds: eps F F (B1 lag_MM) = eps R R + 2c eps R e e + c^2 eps e e e e, '
         'and eps F F - d CS_E = 8c L_R + 24 c^2 vol(e), at c = 0, 1, -2/3, 5/7 (quadratic in c: three values fix it for every c)')
    for seed in AB.seeds_for('A6S-MM', n, N3, 1):
        rng = random.Random(seed); om = A6.eng_conn(Gv, s_conn(rng, n, 1, R50)); e = A6.eng_frame(s_frame_data(rng, n, 1, R50))
        R = Gv.curvature(om); eRR = A6.kpair(Gv, kE, R, R); eRee = A6.eps_R_ee(Gv, e, R); e4 = {}
        for p in itertools.permutations(range(n)): e4 = Fm.add(e4, wedge_list(Fm, [e[i] for i in p]), Gv.eps(list(p)))
        vol = wedge_list(Fm, e); LR = lag_EC(Gv, e, om, 0); Ea, _ = Gv.einstein(None, e, R, 0); eE = {}
        for a in range(n): eE = Fm.add(eE, Fm.wedge(e[a], Ea[a]))
        ok1 = not A6.iszero(vol) and A6.eqf(Fm, e4, Fm.scale(vol, 24)) and A6.eqf(Fm, eRee, Fm.scale(LR, 4)) and A6.eqf(Fm, eE, Fm.scale(eRee, F(1, 2)))
        chk('bit', ok1, 'seed %d: eps e e e e = 24 vol(e); eps R e e = 4 L_R (B1 lag_EC); e^a ^ E_a(0) (engine E_a) = (1/2) eps R e e' % seed)
        dcs = Fm.d(A6.cs_form(Gv, kE, om, F(1, 6))); ok2 = A6.eqf(Fm, dcs, eRR); chk('bit', ok2, 'seed %d: eps R R = d CS_E (x = 1/6) on this connection' % seed)
        ok = ok3 = ctl = True
        for c in (F(0), F(1), F(-2, 3), F(5, 7)):
            L = lag_MM(Gv, e, om, c)
            ok &= A6.eqf(Fm, L, Fm.add(Fm.add(eRR, eRee, 2 * c), e4, c * c)); ok3 &= A6.eqf(Fm, Fm.add(L, dcs, -1), Fm.add(Fm.scale(LR, 8 * c), vol, 24 * c * c))
            if c != 0:
                ctl &= not A6.eqf(Fm, L, Fm.add(Fm.add(eRR, eRee, c), e4, c * c)) and not A6.eqf(Fm, Fm.add(L, dcs, -1), Fm.add(Fm.scale(LR, 8 * c), vol, 12 * c * c))
        chk('bit', ok, 'seed %d: eps F F = eps R R + 2c eps R e e + c^2 eps e e e e at c = 0, 1, -2/3, 5/7' % seed)
        chk('bit', ok3, 'seed %d: eps F F - d CS_E = 8c L_R + 24 c^2 vol(e) at c = 0, 1, -2/3, 5/7' % seed)
        chk('ctl', ctl, 'seed %d: cross term c in place of 2c fails; 12 c^2 vol in place of 24 c^2 vol fails (c = 1, -2/3, 5/7)' % seed)
        note('MM: eps e^4 = 24 vol, eps R e e = 4 L_R, e^a E_a = (1/2) eps R e e', n, 4, ok1)
        note('MM: eps R R = d CS_E; eps F F expansion; eps F F - d CS_E = 8c L_R + 24 c^2 vol', n, 4, ok2 and ok and ok3)
    tick('part 7')

# ================================================================================================ part 8: n = 5 and n = 2
def part_n5(N5=N3):
    n = 5; Gv = Grav(n, Lie(A6.LOR(n))); Fm = Gv.Fm; kP = A6.kform(Gv, 'P'); vP = A6.kvec(Gv, kP)
    head('8. Other dimensions: n = 5, strong (e, omega) of x-degree 1, %d seeds: R^{ab} R_{ab} = d CS_P, the (k, m) nullity, Nieh-Yan and Holst as 4-forms' % N5)
    M = m_alg(Gv); m5 = len(M[0]) - rank_exact(M)
    chk('bit', m5 == 0, 'n = 5, exact, f table only: no non-zero m has m(omega, Q) = 0 for every omega (%d unknowns, %d conditions)' % (len(M[0]), len(M)))
    for seed in AB.seeds_for('A6S-N5', n, N5, 1):
        rng = random.Random(seed); om = A6.eng_conn(Gv, s_conn(rng, n, 1, R50)); e = A6.eng_frame(s_frame_data(rng, n, 1, R50)); pc = A6.Pieces(Gv, om)
        tgt = pc.comb(kP, 'RR'); w, rk, nv, cons = A6.fit(tgt, [pc.comb(kP, 'WdW'), pc.comb(kP, 'WQ')])
        ok1 = cons and rk == 2 and w == [1, F(1, 6)] and A6.eqf(Fm, Fm.d(A6.cs_form(Gv, kP, om, F(1, 6), Q=pc.Q)), tgt)
        chk('bit', ok1, 'n = 5 seed %d: R^{ab} R_{ab} = d CS_P, exact fit (a, x) = %s, rank %d, CS assembled and d applied' % (seed, A6.fmt(w), rk))
        cols = A6.kspace_cols(Gv, [pc]); nul = A6.nullity_mod_p(cols); inP = not A6.residual(cols, vP + [x / 6 for x in vP])
        chk('bit', nul == 1 and inP, 'n = 5 seed %d: nullity of (k, m) is %d (mod 2^31-1, an upper bound) and (k_P, k_P/6) is an exact null vector: exactly 1, no Euler-type form (110 unknowns)' % (seed, nul))
        chk('ctl', bool(A6.residual(cols, vP + [x / 8 for x in vP])), 'n = 5 seed %d: (k_P, k_P/8) is not a null vector' % seed)
        eT, TT, eeR, R, T = A6.nieh_yan_pieces(Gv, e, om); DT = Gv.D_vector(om, T); rhs = {}
        for c in range(n): rhs = Fm.add(rhs, Fm.wedge(e[c], DT[c]), Gv.L.sq[c])
        ok3 = not A6.iszero(TT) and A6.eqf(Fm, Fm.d(eT), Fm.add(TT, eeR, -1)) and A6.eqf(Fm, eeR, rhs)
        chk('bit', ok3, 'n = 5 seed %d: Nieh-Yan d(e^a T_a) = T^a T_a - e^a e^b R_ab and Holst e^a e^b R_ab = e_a D T^a as 4-form identities' % seed)
        note('n = 5: R^{ab} R_{ab} = d CS_P, fit (1, 1/6); nullity 1', n, 4, ok1 and nul == 1 and inP); note('n = 5: Nieh-Yan; Holst = e_a D T^a', n, 4, ok3)
    tick('part 8, n = 5')
def part_n2():
    head('8. n = 2, strong omega of x-degree 3, three seeds')
    G2 = Grav(2, Lie(A6.LOR(2))); Fm2 = G2.Fm
    for seed in AB.seeds_for('A6S-N2', 2, N3, 3):
        rng = random.Random(seed); om2 = A6.eng_conn(G2, s_conn(rng, 2, 3, R50)); R2 = G2.curvature(om2)
        ok = not G2.L.f and A6.eqf(Fm2, Fm2.scale(R2[0], 2), Fm2.d(Fm2.scale(om2[0], 2))) and not A6.iszero(R2[0])
        chk('bit', ok, 'n = 2 seed %d: so(1,1) has no structure constants; eps_{ab} R^{ab} = 2 R^{01} = d(2 omega^{01}) (strong omega of x-degree 3)' % seed)
        chk('ctl', not A6.eqf(Fm2, Fm2.scale(R2[0], 2), Fm2.d(om2[0])), 'n = 2 seed %d: d(omega^{01}) without the factor 2 fails' % seed)
        note('n = 2: eps_{ab} R^{ab} = d(2 omega^{01})', 2, 1, ok)
    tick('part 8, n = 2')

# ================================================================================================ calibration
def part_calib(N=20):
    n = 4; Gv = Grav(n, Lie(A6.LOR(n))); Fm = Gv.Fm; kP, kE, kU = A6.kform(Gv, 'P'), A6.kform(Gv, 'E'), A6.kform(Gv, 'Eucl')
    head('Calibration [ctl] n = 4: four false versions on %d strong seeds each (x-degree-1 omega and e): misses must be <= D/101 per try, and are expected to be 0' % N)
    names = [('cubic coefficient 1/8 (Euler and Pontryagin)', 3, 2 * N), ('x = 1/3: the textbook 2/3 with the textbook 1/2 in R (Euler and Pontryagin)', 3, 2 * N),
             ('the Euclidean pairing: some (a, x) fits', 4, N), ('MacDowell-Mansouri with 7c L_R in place of 8c L_R (c = 1)', 4, N)]
    miss = [0] * 4; true_fail = 0
    for seed in AB.seeds_for('A6S-CAL', n, N):
        rng = random.Random(seed); om = A6.eng_conn(Gv, s_conn(rng, n, 1, R50)); e = A6.eng_frame(s_frame_data(rng, n, 1, R50))
        pre = (Gv.curvature(om), A6.Qforms(Gv, om), [Fm.d(w) for w in om])
        for k in (kE, kP):
            tgt, a, q = cs_parts(Gv, k, om, pre); true_fail += not A6.eqf(Fm, Fm.add(a, q, F(1, 6)), tgt)
            miss[0] += A6.eqf(Fm, Fm.add(a, q, F(1, 8)), tgt); miss[1] += A6.eqf(Fm, Fm.add(a, q, F(1, 3)), tgt)
            if k is kE: dcs = Fm.add(a, q, F(1, 6))                                   # d CS_E = d k_E(omega, d omega + Q/6)
        tgt, a, q = cs_parts(Gv, kU, om, pre); miss[2] += A6.fit(tgt, [a, q])[3]
        L = lag_MM(Gv, e, om, F(1)); LR = lag_EC(Gv, e, om, 0); vol = wedge_list(Fm, e); lhs = Fm.add(L, dcs, -1)
        true_fail += not A6.eqf(Fm, lhs, Fm.add(Fm.scale(LR, 8), vol, 24)); miss[3] += A6.eqf(Fm, lhs, Fm.add(Fm.scale(LR, 7), vol, 24))
    chk('bit', true_fail == 0, 'the true identities (1/6; 8c L_R + 24 c^2 vol) hold on all %d seeds' % N)
    for (name, D, tries), m in zip(names, miss):
        chk('ctl', F(m, tries) <= F(D, 101), 'false version "%s": missed %d of %d tries <= bound %d/101 per try' % (name, m, tries, D))
        chk('ctl', m == 0, 'false version "%s": caught at every one of the %d tries' % (name, tries))
    tick('calibration')

# ================================================================================================ the bound table
def part_table():
    head('Bound table: per seed D p / (1 - r p), p = 1/(2R+1), and combined over the N seeds that passed (exact; the printed values are not below the exact ones)')
    print('  %-84s %2s %3s %4s %2s %2s %10s %10s' % ('identity', 'n', 'D', 'R', 'r', 'N', 'per seed', 'combined'))
    worst = {}
    for (name, n, R), d in sorted(BOUND.items(), key=lambda kv: (kv[0][2], kv[0][1], kv[1]['D'], kv[0][0])):
        b = bound(d['D'], R, d['r']); cb = b ** d['N'] if d['N'] else None
        print('  %-84s %2d %3d %4d %2d %2d %10s %10s' % (name, n, d['D'], R, d['r'], d['N'], up(b), up(cb) if cb is not None else 'none'))
        key = (d['D'], R); worst[key] = max(worst.get(key, F(0)), cb if cb is not None else F(1))
    chk('bit', all(d['N'] == d['runs'] and d['runs'] >= 3 for d in BOUND.values()), 'every identity passed on every seed, at least three seeds per case (%d cases)' % len(BOUND))
    chk('bit', all(bound(d['D'], R, d['r']) < 1 for (nm, n, R), d in BOUND.items()), 'every per-seed bound is below 1')
    if (4, R50) in worst:
        f4 = worst[(4, R50)]
        chk('bit', f4 == F(4, 101) ** 3 and f4 < F(63, 10 ** 6), 'every form identity (D = 4, R = 50, three seeds): false-pass probability at most (4/101)^3 = %s < 6.3e-5' % up(f4))
    if (26, R500) in worst:
        t500, t50, h500 = worst[(26, R500)], worst.get((26, R50), F(1)), worst.get((18, R500), F(1))
        chk('bit', t500 == F(26, 997) ** 3 and t500 < F(18, 10 ** 6) and h500 == F(18, 997) ** 3,
            'at T = 0 (three frames, r = 4): the link with R_s vol (D = 26) at most %s with R = 500 (< 1.8e-5) and %s with R = 50; Holst = 0 (D = 18) at most %s with R = 500' % (up(t500), up(t50), up(h500)))

PARTS = ['degree', 'cs2', 'cs1', 'ny', 't0', 'mm', 'n5', 'n2', 'calib', 'table']
def main():
    args = [a for a in sys.argv[1:] if not a.startswith('-')]
    if any(a not in PARTS for a in args): raise SystemExit('parts: ' + ' '.join(PARTS))
    parts = args or PARTS
    if 'degree' in parts: part_degree()
    for deg in (2, 1):
        if 'cs%d' % deg in parts:
            Gv, keep = part_cs(degs=(deg,))
            if deg == 2: part_kspace(Gv, keep)
    if 'ny' in parts: part_ny()
    if 't0' in parts: part_T0(R50); part_T0(R500)
    if 'mm' in parts: part_mm()
    if 'n5' in parts: part_n5()
    if 'n2' in parts: part_n2()
    if 'calib' in parts: part_calib(20)
    if 'table' in parts: part_table()
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('A6-strong')

if __name__ == '__main__': main()
