#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""L3: the curvature F(c) = R + c e^a^e^b (the engine's own F, built inside Grav.einstein) against the Weyl 2-form W of H1.
   python3 l3_cartan_weyl.py
 [bit]  omega = A3 closed form (1-jet), R = d omega + (1/4)[omega, omega], F(c) and E_a(c) from Grav.einstein(None, e, R, c) at the origin of exact 2-jets;
        W from H1 (engine_frame_riemann + weyl_parts); the five-generator curvature (H3 / b1lib.embed_k pattern) on the frame; H1's duality J and Petrov type.
 [std]  (i) H1's exact Christoffel route on the same jets (std_frame_riemann); (ii) an own numpy route from the closed-form metric g = eta - 2 f l l (Kerr: C2's
        float metric): Christoffel symbols and Riemann (MTW sign) by 4th-order central differences, closed-form frame, own Weyl projection (no engine, no jets).
 Frame components X^{ab}_{cd} = X^{ab}(E_c, E_d), a < b, c < d: 36 per object.  H1 conventions: R_abcd = sq_a sq_b R^{ab}_{cd}, Ric_bd = eta^{ac} R_abcd.
 Results: F(c) - W = (e^a P^b - e^b P^a) + (c + Rs/12) e^a e^b, P^a_b = (1/2) trace-free Ricci; = (1/2)(e^a M^b - e^b M^a) - (tr M / 3) e^a e^b with
 M = G - 3c delta read from E_a(c) (A4).  Import-safe: no engine object at import."""
import sys, os, time, itertools, random, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from b1lib import *
from g2_weyl import (engine_frame_riemann, std_frame_riemann, weyl_parts, duality_J, act_J, cell_vector, metric_cell_vector, complex_Q, petrov, PAIRS4)
from h5l_frames import ks_frame_jetK
import g2_kerr as GK
import numpy as np

SQ = [1, -1, -1, -1]
PAIRS = list(PAIRS4)
K36 = [(a, b, c, d) for (a, b) in PAIRS for (c, d) in PAIRS]
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def dl(x, y): return 1 if x == y else 0
def fmtc(cs): return ', '.join(str(c) for c in cs)

# ------------------------------------------------------------------------------------------------ [bit] F(c), E_a(c), frame components
def frame_comps(X, E0, n=4):
    """frame components X(E_c, E_d), c < d, at the origin of the jets of a 2-form X {mask: poly}"""
    co = {}
    for mu in range(n):
        for nu in range(mu + 1, n):
            p = X.get((1 << mu) | (1 << nu))
            v = at0(p, n) if p else F(0)
            if v: co[(mu, nu)] = v
    return {(c, d): sum((v * (E0[mu][c] * E0[nu][d] - E0[nu][c] * E0[mu][d]) for (mu, nu), v in co.items()), F(0)) for (c, d) in PAIRS}
def engine_F(Gv, e, S, cs, om=None):
    """[bit] the engine's F^{ab}(c) = R^{ab} + c e^a^e^b (the F_ that Grav.einstein contracts into E_a) as 36 frame components, and E_a(c) components, for c in cs"""
    n = 4
    if om is None: om = omega_closed_form(Gv, e, S, n, 1)[0]
    e0, E0, det = E0_of(e, n, n); Fc, Ec = {}, {}
    with trunc(n, xdeg=1):
        R = Gv.curvature(om)
        for c in cs:
            Ea, F_ = Gv.einstein(None, e, R, F(c))
            Fc[c] = {(a, b) + cd: v for (a, b) in PAIRS for cd, v in frame_comps(F_[(a, b)], E0).items()}
            Ec[c] = einstein_components(Ea, n, n)
    return dict(om=om, R=R, e0=e0, E0=E0, det=det, F=Fc, E=Ec)
def weyl36(Rl, sq=SQ):
    """H1's projection: W^{ab}_{cd} (36), R^{ab}_{cd} (36), Ric_bd, Rs, trace-free Ricci, P^a_b = (1/2) sq_a tf_ab"""
    C, Ric, Rs, tf = weyl_parts(Rl, sq)
    return dict(W={k: sq[k[0]] * sq[k[1]] * C[k] for k in K36}, R={k: sq[k[0]] * sq[k[1]] * Rl[k] for k in K36}, Ric=Ric, Rs=Rs, tf=tf,
                P=[[F(1, 2) * sq[a] * tf[(a, b)] for b in range(4)] for a in range(4)])
EE = {k: F(dl(k[:2], k[2:])) for k in K36}                                    # e^a ^ e^b
def P36(P):
    """(e^a ^ P^b - e^b ^ P^a)(E_c, E_d) with P^b = P[b][x] e^x"""
    return {(a, b, c, d): dl(a, c) * P[b][d] - dl(a, d) * P[b][c] - dl(b, c) * P[a][d] + dl(b, d) * P[a][c] for (a, b, c, d) in K36}
def lin36(*terms): return {k: sum((F(cf) * X[k] for cf, X in terms), F(0)) for k in K36}
def is0(X): return all(v == 0 for v in X.values())
def eq36(X, Y): return all(X[k] == Y[k] for k in K36)
def nnz(X): return sum(1 for v in X.values() if v != 0)
def fit36(target, pieces):
    """exact solve of target = sum_k w_k pieces[k] over the 36 components: (w or None if inconsistent, rank)"""
    w, rank, nvar, cons = solve_exact([[pc[k] for pc in pieces] for k in K36], [target[k] for k in K36]); return w, rank
def link_pred(Fc, W, M, beta=F(1, 2), gamma=F(-1, 3)):
    """F(c) - W against beta (e^a M^b - e^b M^a) + gamma tr(M) e^a e^b (M = G - 3c delta from E_a)"""
    trM = sum(M[a][a] for a in range(4)); return eq36(lin36((1, Fc), (-1, W)), lin36((beta, P36(M)), (gamma * trM, EE)))

# ------------------------------------------------------------------------------------------------ [bit] duality (H1), five-generator curvature (H3 pattern)
def lowered_full(X36, sq=SQ):
    T = {k: F(0) for k in itertools.product(range(4), repeat=4)}
    for (a, b, c, d), v in X36.items():
        w = sq[a] * sq[b] * v; T[(a, b, c, d)] = w; T[(b, a, c, d)] = -w; T[(a, b, d, c)] = -w; T[(b, a, d, c)] = w
    return T
def jparts(X36, J):
    """(J-even part, J-odd part) of the 21-cell vector of the lowered X (H1: S -> S(J., J.))"""
    S = cell_vector(lowered_full(X36)); JS = act_J(S, J)
    return [(s + j) / 2 for s, j in zip(S, JS)], [(s - j) / 2 for s, j in zip(S, JS)]
def ext_blocks(e, om, s, kappa, n=4):
    """[bit] curvature of A = omega + kappa e^a B_{a,ext} in the algebra of squares (+,-,-,-, s): (Lorentz block 36, translation block {(a,c,d)}) at the point"""
    sq_ext = list(SQ) + [s]; Lx = Lie(sq_ext); Gx = Grav(n, Lx); Lb = Lie(list(SQ)); Fm = Gx.Fm
    A = [{} for _ in range(Lx.G)]
    for A_, g in enumerate(Lb.gens): A[Lx.idx[g]] = om[A_]
    for a in range(n): A[Lx.idx[(1 << a) | (1 << n)]] = Fm.scale(e[a], F(kappa))
    with trunc(n, xdeg=1): Fx = Gx.curvature(A)
    e0, E0, det = E0_of(e, n, n)
    Lor = {(a, b) + cd: v for (a, b) in PAIRS for cd, v in frame_comps(Fx[Lx.idx[(1 << a) | (1 << b)]], E0).items()}
    Tr = {(a,) + cd: v for a in range(n) for cd, v in frame_comps(Fx[Lx.idx[(1 << a) | (1 << n)]], E0).items()}
    return Lor, Tr

# ------------------------------------------------------------------------------------------------ [std] own float route from a closed-form metric
ETA = np.diag([1.0, -1.0, -1.0, -1.0]); ETAI = np.linalg.inv(ETA)
def _d4(fun, X, k, h):
    d = np.zeros(4); d[k] = h
    return (-fun(X + 2 * d) + 8 * fun(X + d) - 8 * fun(X - d) + fun(X - 2 * d)) / (12 * h)
def _christ(gfun, X, h):
    dg = np.array([_d4(gfun, X, k, h) for k in range(4)])                   # dg[k, a, b] = d_k g_ab
    gi = np.linalg.inv(gfun(X))
    T = np.einsum('msv->smv', dg) + np.einsum('vsm->smv', dg) - dg           # d_m g_sv + d_v g_sm - d_s g_mv
    return 0.5 * np.einsum('ls,smv->lmv', gi, T)
def std_float(gfun, efun, X, h):
    """[std] floats: R^{ab}_{cd} and the Weyl C^{ab}_{cd} (dicts over K36), Rs; MTW sign R^r_{smv} = d_m G^r_{vs} - d_v G^r_{ms} + G G - G G; frame e[a, mu] closed form"""
    G0 = _christ(gfun, X, h); dG = np.array([_d4(lambda Y: _christ(gfun, Y, h), X, k, h) for k in range(4)])
    Riem = (np.einsum('mrvs->rsmv', dG) - np.einsum('vrms->rsmv', dG) + np.einsum('rml,lvs->rsmv', G0, G0) - np.einsum('rvl,lms->rsmv', G0, G0))
    e0 = efun(X); E0 = np.linalg.inv(e0)
    Rl = np.einsum('ax,xr,rsmv,sb,mc,vd->abcd', ETA, e0, Riem, E0, E0, E0)     # R_abcd = eta_aa e^a_r R^r_smv E^s_b E^m_c E^v_d
    Ric = np.einsum('ac,abcd->bd', ETAI, Rl); Rs = np.einsum('bd,bd->', ETAI, Ric)
    C = (Rl - 0.5 * (np.einsum('ac,bd->abcd', ETA, Ric) - np.einsum('ad,bc->abcd', ETA, Ric) - np.einsum('bc,ad->abcd', ETA, Ric) + np.einsum('bd,ac->abcd', ETA, Ric))
         + Rs / 6.0 * (np.einsum('ac,bd->abcd', ETA, ETA) - np.einsum('ad,bc->abcd', ETA, ETA)))
    up = lambda T: np.einsum('ax,by,xycd->abcd', ETAI, ETAI, T)
    Ru, Cu = up(Rl), up(C)
    return dict(R={k: Ru[k] for k in K36}, C={k: Cu[k] for k in K36}, Rs=Rs)
def ks_float_fns(M, H2, s):
    """closed forms of the radial Kerr-Schild family f = M/rho + (H2/2) rho^2 - s/rho^2: g = eta - 2 f l l, e = 1 - f l^a l_mu"""
    M, H2, s = float(M), float(H2), float(s)
    def parts(X):
        x, y, z = X[1], X[2], X[3]; rho = math.sqrt(x * x + y * y + z * z); f = M / rho + H2 / 2 * rho ** 2 - s / rho ** 2
        return f, np.array([1.0, -x / rho, -y / rho, -z / rho]), np.array([1.0, x / rho, y / rho, z / rho])
    def gfun(X): f, lu, ld = parts(X); return ETA - 2 * f * np.outer(ld, ld)
    def efun(X): f, lu, ld = parts(X); return np.eye(4) - f * np.outer(lu, ld)
    return gfun, efun
def kerr_float_fns(M, a):
    """C2's float closed forms (g2_kerr.float_metric, kerr_float): Kerr in Kerr-Schild form"""
    def efun(X):
        r, f, l = GK.kerr_float(X[1], X[2], X[3], M, a); ld = np.array(l); lu = np.array([l[0], -l[1], -l[2], -l[3]]); return np.eye(4) - f * np.outer(lu, ld)
    return (lambda X: GK.float_metric(X, M, a)), efun

# ------------------------------------------------------------------------------------------------ one frame
def analyse(Gv, S, J, fr):
    """the checks every frame gets; returns the data the part-level checks need"""
    name, e, cs = fr['name'], fr['e'], fr['cs']
    d = engine_F(Gv, e, S, cs)
    with trunc(4, xdeg=0): tz = torsion_zero_at0(Gv, d['om'], e, 4)
    chk('bit', tz, '%s: precondition T = 0 at the point (A3 omega; the engine torsion reads the h table)' % name)
    wb = weyl36(engine_frame_riemann(Gv, e, S, 4, om=d['om'])[0]); ws = weyl36(std_frame_riemann(e, 4, SQ))
    chk('bit==std', all(eq36(d['F'][c], lin36((1, ws['R']), (c, EE))) for c in cs),
        '%s: the engine F(c) = R_std + c e^e exactly (Christoffel route on the same jets), all 36 components, c in {%s}' % (name, fmtc(cs)))
    chk('bit==std', eq36(wb['W'], ws['W']), '%s: W from the engine R = W from the Christoffel route (H1 projection), 36 components, %d nonzero' % (name, nnz(wb['W'])))
    if fr.get('flt'):
        gfun, efun, X, h = fr['flt']; sf = std_float(gfun, efun, X, h)
        sc = max(abs(float(v)) for c in cs for v in d['F'][c].values()) or 1.0
        err = max(abs(float(d['F'][c][k]) - (sf['R'][k] + float(c) * float(EE[k]))) for c in cs for k in K36)
        errW = max(abs(float(wb['W'][k]) - sf['C'][k]) for k in K36)
        chk('bit==std', err <= 1e-6 * sc and errW <= 1e-6 * sc, '%s: engine F(c) = R + c delta and W = C of the own float route from the closed-form metric '
            '(finite differences, no jets): max |diff| %.1e and %.1e (scale %.1e)' % (name, err, errW, sc))
        fr['sf'] = sf; fr['sc'] = sc
    P = wb['P']; trfree = all(v == 0 for v in wb['tf'].values())
    Ez = {c: all(v == 0 for v in d['E'][c].values()) for c in cs}; FW = {c: eq36(d['F'][c], wb['W']) for c in cs}
    Mx = {c: mixed_from_components(d['E'][c], d['e0'], d['det'], 4) for c in cs}
    chk('bit', all(Ez[c] == FW[c] for c in cs), '%s: E_a(c) = 0 <=> F(c) = W for each c (both true exactly at c in {%s})' % (name, fmtc([c for c in cs if FW[c]])))
    chk('bit', all(link_pred(d['F'][c], wb['W'], Mx[c]) for c in cs), '%s: F(c) - W = (1/2)(e^a M^b - e^b M^a) - (tr M/3) e^a e^b, M = G - 3c delta read from the '
        'engine E_a(c) (A4), all 36 components, every c' % name)
    jok = True
    for c in cs:
        ev, od = jparts(d['F'][c], J); evP, odP = jparts(P36(P), J); al = c + wb['Rs'] / 12
        ev2, od2 = jparts(lin36((1, d['F'][c]), (-1, wb['W']), (-1, P36(P))), J)
        jok &= ev == evP and all(x == 0 for x in odP) and all(x == 0 for x in ev2) and od2 == [al * x for x in metric_cell_vector(SQ)]
    chk('bit', jok, '%s: duality (H1 J, Lorentz squares): J-even part of F(c) = the trace-free Ricci piece e^a P^b - e^b P^a (%s), J-odd part of F(c) - W = '
        '(c + Rs/12) x bivector metric, every c' % (name, 'zero: Einstein' if trfree else 'non-zero'))
    return dict(d=d, wb=wb, ws=ws, P=P, Rs=wb['Rs'], trfree=trfree, Ez=Ez, FW=FW, M=Mx)

def alphas(r, cs):
    """alpha(c) from F(c) - W = alpha e^a e^b (exact fit; None if inconsistent)"""
    out = {}
    for c in cs:
        w, rk = fit36(lin36((1, r['d']['F'][c]), (-1, r['wb']['W'])), [EE]); out[c] = w[0] if w else None
    return out

# ------------------------------------------------------------------------------------------------ frames
ANG = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(0), F(1)), (F(1), F(0))), ((F(-5, 13), F(12, 13)), (F(-8, 17), F(15, 17))), ((F(12, 13), F(5, 13)), (F(0), F(1)))]
SDS = [(F(1), F(1, 5), (2, 3, 6), 7), (F(1), F(-1, 5), (1, 2, 2), 3), (F(2), F(1, 4), (2, 6, 9), 11), (F(1, 3), F(-1, 9), (4, 4, 7), 9),
       (F(3), F(1, 9), (-2, 3, -6), 7), (F(5), F(-1, 4), (3, 4, 12), 13)]
SCHW = [(F(1), F(0), (1, 4, 8), 9)]
DS = [(F(0), F(1, 5), (2, 3, 6), 7), (F(0), F(-1, 5), (1, 2, 2), 3), (F(0), F(1, 4), (2, 6, 9), 11), (F(0), F(-1, 9), (4, 4, 7), 9)]
RN = [(F(1), F(0), F(1, 2), (2, 3, 6), 7), (F(1), F(0), F(1, 2), (1, 2, 2), 3), (F(1), F(1, 5), F(1, 3), (2, 6, 9), 11), (F(2), F(-1, 4), F(1), (4, 4, 7), 9)]
KERR = [(F(9), 0), (F(7), 2), (F(4), 3), (F(20), 1)]
EXT = {F(1, 4): (-1, F(1, 2)), F(-1, 9): (1, F(1, 3)), F(1, 9): (-1, F(1, 3)), F(-1, 4): (1, F(1, 2))}       # H2 -> (s, kappa) with c = -s kappa^2 = H2
def cs_of(H2): return sorted(set([F(H2), F(0), F(H2) / 2, -F(H2), F(1, 3), F(-2, 7)]))
def ks_fr(kind, M, H2, s, p, rho):
    p = tuple(F(x) for x in p); X = np.array([0.0] + [float(x) for x in p])
    name = '%s M = %s, H2 = %s%s, p = (%s), rho = %s' % (kind, M, H2, (', s = %s' % s) if s else '', ', '.join(str(x) for x in p), rho)
    return dict(name=name, kind=kind, M=F(M), H2=F(H2), s=F(s), e=ks_frame_jetK(p, rho, M, H2, s, order=2), cs=cs_of(H2),
                flt=ks_float_fns(M, H2, s) + (X, 1e-3 * rho))

def part_sds(Gv, S, J, JE):
    head('Part 1. Schwarzschild-(anti-)de Sitter (M != 0): F(H2) = W exactly; F(c) - W = alpha e^a e^b with alpha fitted')
    out = []
    for (M, H2, p, rho) in SDS + SCHW:
        fr = ks_fr('SdS' if H2 > 0 else ('SAdS' if H2 < 0 else 'Schwarzschild'), M, H2, 0, p, rho)
        if H2 == 0: fr['cs'] = [F(0), F(1, 5), F(1, 3), F(-2, 7)]
        r = analyse(Gv, S, J, fr); d, W = r['d'], r['wb']['W']; out.append((fr, r))
        chk('bit', eq36(d['F'][H2], W) and nnz(W) > 0, '%s: F(c = H2) = W, all 36 frame components exactly (%d nonzero)' % (fr['name'], nnz(W)))
        chk('std', eq36(lin36((1, r['ws']['R']), (H2, EE)), r['ws']['W']), '%s: the Christoffel route alone (exact): R_std + H2 e^e = W_std' % fr['name'])
        sf, sc = fr['sf'], fr['sc']
        chk('std', max(abs(sf['R'][k] + float(H2) * float(EE[k]) - sf['C'][k]) for k in K36) <= 1e-6 * sc, '%s: the float route alone: R + H2 delta = C to 1e-6 of the scale' % fr['name'])
        al = alphas(r, fr['cs'])
        chk('bit', all(al[c] == c - H2 for c in fr['cs']), '%s: fitted alpha(c) = c - H2 for c in {%s} (alphas %s)' % (fr['name'], fmtc(fr['cs']), fmtc([al[c] for c in fr['cs']])))
        typ, I2, I3, info = petrov(complex_Q(lowered_full(d['F'][H2])))
        chk('bit', typ == 'D' and info.get('double') == -M / F(rho) ** 3, '%s: F(H2) read as a curvature table has Petrov type %s, double eigenvalue %s = -M/rho^3' % (fr['name'], typ, info.get('double')))
        if H2 != 0:
            chk('ctl', not eq36(d['F'][H2 / 2], W) and not eq36(d['F'][-H2], W), '%s: wrong c = H2/2 and c = -H2 (= the opposite sign R - H2 e^e): F != W (ok)' % fr['name'])
        evE, odE = jparts(d['F'][H2], JE); Wl = lowered_full(W)
        mag0 = all(Wl[(0, i, j, k)] == 0 for i in (1, 2, 3) for (j, k) in ((1, 2), (1, 3), (2, 3)))
        chk('bit', mag0 and all(x == 0 for x in evE), '%s: the magnetic cells W_0ijk vanish in the Kerr-Schild frame (W purely electric), so the Euclidean-squares '
            'duality J_E (J^2 = +1) gives the same even/odd split here: J_E-even part of F(H2) = 0 (the J_E control can only bite where B != 0: Part 3)' % fr['name'])
        Rl_raw = {k: F(0) for k in itertools.product(range(4), repeat=4)}
        for (a, b, c, dd), v in r['wb']['R'].items():
            Rl_raw[(a, b, c, dd)] = v; Rl_raw[(b, a, c, dd)] = -v; Rl_raw[(a, b, dd, c)] = -v; Rl_raw[(b, a, dd, c)] = v
        WE = {k: v for k, v in weyl_parts(Rl_raw, [1, 1, 1, 1])[0].items() if k in EE}
        chk('bit', eq36(d['F'][H2], WE), '%s: the projection of the MIXED components R^{ab}_{cd} with delta traces (squares (+,+,+,+)) is W = F(H2) exactly: '
            'the mixed tensor needs no squares' % fr['name'])
        WEl = weyl_parts(lowered_full(r['wb']['R']), [1, 1, 1, 1])[0]
        chk('ctl', not eq36(d['F'][H2], {k: SQ[k[0]] * SQ[k[1]] * WEl[k] for k in K36}), '%s: delta traces on the LOWERED R_abcd (Euclidean squares where eta is '
            'needed), raised back: not F(H2) (ok)' % fr['name'])
    tick('part 1'); return out

def part_ds(Gv, S, J):
    head('Part 2. de Sitter and anti-de Sitter (M = 0): F(H2) = 0 (Cartan-flat); F(c) = alpha e^a e^b with alpha fitted')
    out = []
    for (M, H2, p, rho) in DS:
        fr = ks_fr('dS' if H2 > 0 else 'AdS', M, H2, 0, p, rho); r = analyse(Gv, S, J, fr); d = r['d']; out.append((fr, r))
        chk('bit', is0(d['F'][H2]) and is0(r['wb']['W']), '%s: F(c = H2) = 0, all 36 components, and W = 0: flat in the Cartan sense' % fr['name'])
        chk('std', is0(lin36((1, r['ws']['R']), (H2, EE))) and max(abs(fr['sf']['R'][k] + float(H2) * float(EE[k])) for k in K36) <= 1e-6 * fr['sc'],
            '%s: the Christoffel route alone: R_std = -H2 e^e exactly; float route: R + H2 delta = 0 to 1e-6' % fr['name'])
        al = {c: (fit36(d['F'][c], [EE])[0] or [None])[0] for c in fr['cs']}
        chk('bit', all(al[c] == c - H2 for c in fr['cs']), '%s: F(c) = alpha e^a e^b exactly with fitted alpha = c - H2 for c in {%s} (alphas %s)' % (fr['name'], fmtc(fr['cs']), fmtc([al[c] for c in fr['cs']])))
        chk('ctl', not is0(d['F'][-H2]), '%s: the opposite sign R - H2 e^e is not zero (it is %s e^e) (ok)' % (fr['name'], al[-H2]))
    tick('part 2'); return out

def part_nonE(Gv, S, J, JE):
    head('Part 3. Reissner-Nordstrom (also with H2), Kerr (M = 5, a = 3) and random frames: F(c) - W = beta (e^a P^b - e^b P^a) + alpha e^a e^b')
    out = []
    for (M, H2, s, p, rho) in RN:
        fr = ks_fr('RN', M, H2, s, p, rho); fr['cs'] = sorted(set([F(0), H2, F(1, 3), F(-2, 7)])); out.append((fr, analyse(Gv, S, J, fr)))
    dks = []
    for (rr, ia) in KERR: dks += GK.rational_kerr_points(F(3), [rr], [ANG[ia]])
    for dk in dks:
        X = np.array([0.0] + [float(x) for x in dk['p']])
        fr = dict(name='Kerr M = 5, a = 3, r = %s, cos th = %s' % (dk['r'], dk['cth']), kind='Kerr', M=F(5), H2=F(0), s=F(0), cs=[F(0), F(1, 3), F(-2, 7)],
                  e=GK.kerr_ks_frame_jet(dk['p'], 5, 3, dk['r'])[0], flt=kerr_float_fns(5, 3) + (X, 1e-3 * math.sqrt(float(sum(x * x for x in dk['p'])))))
        out.append((fr, analyse(Gv, S, J, fr)))
    for seed in (5, 6):
        fr = dict(name='random frame seed %d' % seed, kind='rand', H2=None, cs=[F(0), F(1, 3), F(-2, 7)], e=rand_frame(random.Random(seed), 4, 2, 3))
        out.append((fr, analyse(Gv, S, J, fr)))
    for fr, r in out:
        d, W, P, Rs, cs = r['d'], r['wb']['W'], r['P'], r['Rs'], fr['cs']
        if fr['kind'] == 'Kerr':
            al = alphas(r, cs)
            chk('bit', r['trfree'] and Rs == 0 and eq36(d['F'][F(0)], W) and nnz(W) > 0 and all(al[c] == c for c in cs),
                '%s: Ricci flat; F(0) = R = W (36 components, %d nonzero); F(c) - W = c e^e (fitted alphas %s)' % (fr['name'], nnz(W), fmtc([al[c] for c in cs])))
            typ, I2, I3, info = petrov(complex_Q(lowered_full(d['F'][F(0)])))
            chk('bit', typ == 'D', '%s: F(0) has Petrov type %s (H1: Kerr is D)' % (fr['name'], typ))
            sf, sc = fr['sf'], fr['sc']
            chk('std', max(abs(sf['R'][k] - sf['C'][k]) for k in K36) <= 1e-6 * sc, '%s: the float route alone: R = C (Ricci flat) to 1e-6 of the scale' % fr['name'])
            evE, odE = jparts(d['F'][F(0)], JE)
            chk('ctl', any(x != 0 for x in evE), '%s: Euclidean squares in the duality J (J^2 = +1): the J_E-even part of F(0) = W is NOT zero although Ricci = 0 '
                '(W has magnetic cells here), so J_E does not isolate the Ricci piece (ok)' % fr['name'])
            continue
        if fr['kind'] == 'rand':
            evE, odE = jparts(d['F'][F(0)], JE)
            chk('ctl', evE != jparts(P36(P), J)[0], '%s: Euclidean squares in the duality J: the J_E-even part of F(0) is not the trace-free Ricci piece (ok)' % fr['name'])
        fits = {c: fit36(lin36((1, d['F'][c]), (-1, W)), [P36(P), EE]) for c in cs}
        okfit = all(w is not None and rk == 2 and w[0] == 1 and w[1] == c + Rs / 12 for c, (w, rk) in fits.items())
        extra = (' Rs = %s = -12 H2: the Maxwell part is traceless' % Rs) if fr['kind'] == 'RN' else (' Rs = %s' % Rs)
        chk('bit', (not r['trfree']) and okfit, '%s: trace-free Ricci != 0; fit (rank 2) beta = 1, alpha = c + Rs/12 for c in {%s} (alphas %s);%s'
            % (fr['name'], fmtc(cs), fmtc([(fits[c][0][1] if fits[c][0] else None) for c in cs]), extra))
        if fr['kind'] == 'RN': chk('bit', Rs == -12 * fr['H2'], '%s: Rs = -12 H2 exactly (the charge term adds no trace)' % fr['name'])
        ws = r['ws']
        chk('std', all(eq36(lin36((1, ws['R']), (c, EE), (-1, ws['W'])), lin36((1, P36(ws['P'])), (c + ws['Rs'] / 12, EE))) for c in cs),
            '%s: the Christoffel route alone: R_std + c e^e - W_std = (e^a P^b - e^b P^a)_std + (c + Rs_std/12) e^e, every c' % fr['name'])
        chk('ctl', all(fit36(lin36((1, d['F'][c]), (-1, W)), [EE])[0] is None for c in cs) and not any(r['FW'].values()),
            '%s: "F(c) - W = alpha e^a e^b" has NO solution alpha for any tested c (c = 0%s included): no c makes F(c) = W on a non-Einstein frame (ok)'
            % (fr['name'], (', c = H2 = %s' % fr['H2']) if fr.get('H2') else ''))
    tick('part 3'); return out

def part_ext(Gv, S, frames):
    head('Part 4. The five-generator curvature (H3: k = -s): its Lorentz block is F(H2), its translation block kappa T = 0')
    for fr, r in frames:
        H2 = fr['H2']
        if H2 not in EXT: continue
        s, kappa = EXT[H2]; Lor, Tr = ext_blocks(fr['e'], r['d']['om'], s, kappa)
        chk('bit', eq36(Lor, r['d']['F'][H2]) and eq36(Lor, r['wb']['W']) and all(v == 0 for v in Tr.values()),
            '%s: s = %+d, kappa = %s (c = -s kappa^2 = H2): Lorentz block = F(H2) = W (%s), translation block = 0' % (fr['name'], s, kappa, 'zero' if is0(Lor) else '%d nonzero' % nnz(Lor)))
        LorW, _ = ext_blocks(fr['e'], r['d']['om'], -s, kappa)
        chk('ctl', not eq36(LorW, r['wb']['W']) and eq36(LorW, r['d']['F'][-H2]), '%s: the wrong square s = %+d gives R - H2 e^e = F(-H2), not W (ok)' % (fr['name'], -s))
    tick('part 4')

def part_link(allfr):
    head('Part 5. The Einstein form: E_a(c) = 0 <=> F(c) = W; F(c) - W written through M = G - 3c delta')
    for fr, r in allfr:
        if r['trfree']: continue
        okf, bad1, bad2, c0 = True, False, False, []
        for c in fr['cs']:
            M = r['M'][c]; trM = sum(M[a][a] for a in range(4)); tgt = lin36((1, r['d']['F'][c]), (-1, r['wb']['W']))
            if trM != 0:
                w, rk = fit36(tgt, [P36(M), lin36((trM, EE))]); okf &= w is not None and rk == 2 and w == [F(1, 2), F(-1, 3)]
                bad1 |= link_pred(r['d']['F'][c], r['wb']['W'], M, F(1, 2), F(-1, 4))
            else:                                                                # c = -Rs/12: tr M = 0, gamma is not determined there; fit beta alone
                c0.append(c); w, rk = fit36(tgt, [P36(M)]); okf &= w is not None and rk == 1 and w == [F(1, 2)]
            bad2 |= link_pred(r['d']['F'][c], r['wb']['W'], M, F(-1, 2), F(-1, 3))
        chk('bit', okf, '%s: fit of F(c) - W = beta (e^a M^b - e^b M^a) + gamma tr(M) e^a e^b over 36 components: beta = 1/2, gamma = -1/3 (rank 2) at every c with '
            'tr M != 0; beta = 1/2 alone (rank 1) at c = -Rs/12 where tr M = 0 (%s)' % (fr['name'], ('c = ' + fmtc(c0)) if c0 else 'none tested'))
        chk('ctl', not bad1 and not bad2, '%s: (beta, gamma) = (1/2, -1/4) at the c with tr M != 0 and (-1/2, -1/3) at every c fail (ok)' % fr['name'])
    rows = [(fr['name'], c, r['Ez'][c], r['FW'][c]) for fr, r in allfr for c in fr['cs']]
    tt = sum(1 for x in rows if x[2] and x[3]); ff = sum(1 for x in rows if not x[2] and not x[3]); mixed = len(rows) - tt - ff
    print('  truth table over %d (frame, c) pairs: E_a(c) = 0 and F(c) = W: %d; both false: %d; mixed: %d' % (len(rows), tt, ff, mixed))
    for fr, r in allfr:
        tr = [c for c in fr['cs'] if r['FW'][c]]; print('    %-62s F(c) = W and E_a(c) = 0 exactly at c in {%s}' % (fr['name'][:62], fmtc(tr)))
    want = all((r['FW'][c] == (fr['kind'] in ('SdS', 'SAdS', 'Schwarzschild', 'dS', 'AdS', 'Kerr') and c == fr['H2'])) for fr, r in allfr for c in fr['cs'])
    chk('bit', mixed == 0 and want, 'E_a(c) = 0 <=> F(c) = W on all %d (frame, c) pairs; true exactly for the Einstein frames at c = H2 (%d pairs), false on RN, '
        'random frames and every c != H2' % (len(rows), tt))
    tick('part 5')

def main():
    Gv = Grav(4, Lie(list(SQ))); S = koszul_S(4, SQ, Gv.L)
    J, I2, comm, compl = duality_J(SQ); JE = duality_J([1, 1, 1, 1])[0]
    head('L3: the curvature F(c) = R + c e^a e^b against the Weyl 2-form; n = 4, (+,-,-,-), exact at rational points (2-jets); duality I^2 = %s' % I2)
    s1 = part_sds(Gv, S, J, JE); s2 = part_ds(Gv, S, J); s3 = part_nonE(Gv, S, J, JE)
    part_ext(Gv, S, s1 + s2); part_link(s1 + s2 + s3)
    finish('L3')

if __name__ == '__main__': main()
