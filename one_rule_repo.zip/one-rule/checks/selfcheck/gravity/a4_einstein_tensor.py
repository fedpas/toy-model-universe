#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A4.  The Einstein form E_a equals the Einstein tensor of the metric e^T eta e for ANY frame (not only e = dx).   python3 a4_einstein_tensor.py [n ...]

 Claim.  E_a = s_n (G^h_a - Lambda_n delta^h_a) Theta_h,   Theta_h = iota_{E_h} (e^0 ^ ... ^ e^{n-1}) = det(e) sum_mu (-1)^mu E^mu_h dx^{hat mu},
         with G the Einstein tensor of the Levi-Civita connection, Lambda_n = c (n-1)(n-2)/2, and s_n = -1 (hand derivation: the contraction of two epsilon symbols gives
         (1/4) delta^{abc}_{hfg} R^{bc}_{fg} = (1/2) R delta - Ric).
 [bit]  omega = closed form of A3 (first-order jet), R = d omega + (1/4)[omega, omega], E_a = sum eps F e...e (the engine), read at the origin of random polynomial frames.
 [std]  Riemann of g = e^T eta e at the origin by two routes (Christoffel jets; second derivatives of g) in exact fractions, Ricci, Einstein tensor; a third route in numpy floats
        (five-point finite differences of the metric function).
 Controls: Ricci instead of Einstein, trace coefficient 1 instead of 1/2, wrong Lambda_n, wrong sign of s_n."""
import time, sys
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

def engine_E(Gv, e, S, n, c, om=None):
    """[bit] E_a(c) components and the engine's curvature R^{ab}_{mu nu} at the origin, for a frame e (polynomials up to degree 2)"""
    if om is None: om = omega_closed_form(Gv, e, S, n, 1)[0]
    with trunc(n, xdeg=1):
        R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(c))
    comp = einstein_components(Ea, n, n)
    Rab = {}                                                           # R^{ab}_{mu nu}, all index orders
    for A, (a, b) in enumerate(pairs_of(Gv.L)):
        for mu in range(n):
            for nu in range(mu + 1, n):
                v = at0(R[A].get((1 << mu) | (1 << nu), {}), n)
                Rab[(a, b, mu, nu)] = v; Rab[(b, a, mu, nu)] = -v; Rab[(a, b, nu, mu)] = -v; Rab[(b, a, nu, mu)] = v
    return comp, Rab, om

def numeric_einstein(e, n, sq, h=1e-3):
    """[std, numpy floats] G^mu_nu at the origin: five-point finite differences of g(x) = sum_a sq_a e^a_mu(x) e^a_nu(x) (exact for the polynomial g)
    and of Gamma(x) (error O(h^4))"""
    pol = []
    for a in range(n):
        row = []
        for mu in range(n):
            p = e[a].get(1 << mu, {}); K = np.array([list(k[:n]) for k in p], dtype=float).reshape(len(p), n); v = np.array([float(x) for x in p.values()])
            row.append((K, v))
        pol.append(row)
    def ev(K, v, x): return float(np.prod(np.power(x, K), axis=1) @ v) if len(v) else 0.0
    def g(x):
        E_ = np.array([[ev(*pol[a][mu], x) for mu in range(n)] for a in range(n)]); return E_.T @ np.diag(np.array(sq, dtype=float)) @ E_
    def d1(f, x, k):
        dx = np.zeros(n); dx[k] = h
        return (-f(x + 2 * dx) + 8 * f(x + dx) - 8 * f(x - dx) + f(x - 2 * dx)) / (12 * h)
    def gam(x):
        gi = np.linalg.inv(g(x)); dg = np.array([d1(g, x, k) for k in range(n)])
        return 0.5 * (np.einsum('ls,msn->lmn', gi, dg) + np.einsum('ls,nsm->lmn', gi, dg) - np.einsum('ls,smn->lmn', gi, dg))
    x0 = np.zeros(n); G0 = gam(x0); dG = np.array([d1(gam, x0, k) for k in range(n)])            # dG[k, l, m, n] = d_k Gamma^l_{mn}
    Rm = np.zeros((n, n, n, n))                                                  # R^r_{s m v} = d_m G^r_{v s} - d_v G^r_{m s} + G^r_{m l} G^l_{v s} - G^r_{v l} G^l_{m s}
    Rm = np.einsum('mrvs->rsmv', dG) - np.einsum('vrms->rsmv', dG) + np.einsum('rml,lvs->rsmv', G0, G0) - np.einsum('rvl,lms->rsmv', G0, G0)
    ric = np.einsum('rsrv->sv', Rm); gi = np.linalg.inv(g(x0)); Rs = np.einsum('sv,sv->', gi, ric)
    return gi @ ric - 0.5 * Rs * np.eye(n)

def one_frame(n, seed):
    rng = random.Random(seed); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_)
    e = rand_frame(rng, n, deg=2, coef=2, density=.5)
    e0, E0, det = E0_of(e, n, n)
    g = std_metric(e, n, sq, n, 2)
    R1, g0, g0i = std_riemann(g, n, n, 1); R2, _, _ = std_riemann(g, n, n, 2)
    Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, n); Gm2, _, _ = std_einstein_mixed(R2, g0, g0i, n)
    Gfr = to_frame_mixed(Gm, e0, E0, n)                                 # G^b_a
    ricmix = [[sum(g0i[m][s_] * ric[s_][v] for s_ in range(n)) for v in range(n)] for m in range(n)]
    ricfr = to_frame_mixed(ricmix, e0, E0, n)
    return dict(sq=sq, Gv=Gv, S=S, e=e, e0=e0, E0=E0, det=det, R1=R1, R2=R2, Gm=Gm, Gm2=Gm2, Gfr=Gfr, ricfr=ricfr, Rs=Rs)

def run_n(n, ncase, cs):
    head('n = %d: %d random non-vacuum polynomial frames (degree 2), c in %s' % (n, ncase, [str(c) for c in cs]))
    Lam = lambda c: c * F((n - 1) * (n - 2), 2)
    allR = True; allE = True; allRoute = True; ratios = set(); nonvac = True; allNum = True; Lfit = set(); numerr = 0.0
    ctl = {'Ricci instead of Einstein': [0, 0], 'trace coefficient 1 instead of 1/2': [0, 0], 'wrong Lambda_n = c n(n-1)/2': [0, 0], 'sign s_n = +1': [0, 0]}
    for case in range(ncase):
        d = one_frame(n, 1000 * n + case); Gv, S, e, e0, E0, det, sq = d['Gv'], d['S'], d['e'], d['e0'], d['E0'], d['det'], d['sq']
        allRoute &= (d['R1'] == d['R2']) and (d['Gm'] == d['Gm2'])
        nonvac &= any(d['Gfr'][b][a] != 0 for b in range(n) for a in range(n))
        Gnum = numeric_einstein(e, n, sq); Gex = np.array([[float(x) for x in row] for row in d['Gm']])
        err = np.max(np.abs(Gnum - Gex)) / max(1.0, np.max(np.abs(Gex))); numerr = max(numerr, err); allNum &= (err < 1e-5)
        om = omega_closed_form(Gv, e, S, n, 1)[0]
        for c in cs:
            comp, Rab, _ = engine_E(Gv, e, S, n, c, om)
            if c == cs[0]:
                for r in range(n):
                    for s_ in range(n):
                        for m in range(n):
                            for v in range(m + 1, n):
                                allR &= (sum(E0[r][a] * e0[b][s_] * sq[b] * Rab.get((a, b, m, v), 0) for a in range(n) for b in range(n)) == d['R1'][(r, s_, m, v)])
            M = [[d['Gfr'][h][a] - (Lam(c) if h == a else 0) for a in range(n)] for h in range(n)]
            pred1 = predicted_components(M, e0, E0, det, n, s=1)
            for k in comp:
                if pred1[k] != 0: ratios.add(comp[k] / pred1[k])
                else: allE &= (comp[k] == 0)
            Mric = [[d['ricfr'][h][a] for a in range(n)] for h in range(n)]
            Mtr1 = [[d['ricfr'][h][a] - (d['Rs'] if h == a else 0) - (Lam(c) if h == a else 0) for a in range(n)] for h in range(n)]
            Mlam = [[d['Gfr'][h][a] - ((c * F(n * (n - 1), 2)) if h == a else 0) for a in range(n)] for h in range(n)]
            for name, Mx, sgn in (('Ricci instead of Einstein', Mric, -1), ('trace coefficient 1 instead of 1/2', Mtr1, -1), ('wrong Lambda_n = c n(n-1)/2', Mlam, -1), ('sign s_n = +1', M, 1)):
                if name.startswith('wrong Lambda') and c == 0: continue                   # Lambda is invisible at c = 0
                ctl[name][1] += 1; ctl[name][0] += int(predicted_components(Mx, e0, E0, det, n, s=sgn) != comp)
        if len(cs) > 1 and cs[0] == 0:
            c1 = cs[1]; comp0, _, _ = engine_E(Gv, e, S, n, 0, om); comp1, _, _ = engine_E(Gv, e, S, n, c1, om)
            pd = predicted_components([[F(-1) if h == a else F(0) for a in range(n)] for h in range(n)], e0, E0, det, n, s=1)       # E(c)-E(0) = s_n (-Lambda_n) Theta = Lambda_n Theta = -Lambda_n pd
            Lfit |= set(-(comp1[k] - comp0[k]) / pd[k] / c1 for k in comp if pd[k] != 0)
        if case == 0: print('    first frame: det e = %s;  G^0_0, G^0_1 (frame) = %s, %s;  Ricci scalar R = %s' % (det, d['Gfr'][0][0], d['Gfr'][0][1] if n > 1 else '', d['Rs']), flush=True)
    chk('std', allRoute, 'n=%d: the two exact Riemann routes (Christoffel jets; second derivatives of g) agree, and so do the two Einstein tensors' % n)
    chk('std', allNum, 'n=%d: the numpy five-point finite-difference Einstein tensor agrees with the exact one (worst relative error %.2g)' % (n, numerr))
    chk('bit==std', allR, 'n=%d: the engine\'s curvature R = d omega + 1/4 [omega, omega] (omega = A3 closed form) equals the Riemann tensor of the metric, every component, %d frames' % (n, ncase))
    chk('bit', nonvac, 'n=%d: the frames are not vacuum (the Einstein tensor is non-zero), so the match below is not a match of zeros' % n)
    chk('bit==std', allE and ratios == {F(-1)}, 'n=%d: E_a (engine) = s_n (G^h_a - Lambda_n delta^h_a) Theta_h in all %d x %d components, every frame and c: the ratio takes the single value s_n = %s' % (n, n, n, sorted(map(str, ratios))))
    if Lfit: chk('bit', Lfit == {F((n - 1) * (n - 2), 2)}, 'n=%d: from E(c) - E(0): Lambda_n / c = %s, and (n-1)(n-2)/2 = %s' % (n, sorted(map(str, Lfit)), F((n - 1) * (n - 2), 2)))
    return ctl

def main():
    ns = [int(a) for a in sys.argv[1:]] or [3, 4, 5]
    allctl = {}
    for n in ns:
        cs = [F(0), F(1, 3), F(-2, 5)]
        ncase = {3: 6, 4: 4, 5: 2, 6: 1}.get(n, 1)
        for k, v in run_n(n, ncase, cs).items(): allctl[(n, k)] = v
        tick('n=%d' % n)
    head('controls (a wrong version must differ from the engine on every sample where it can be seen)')
    for (n, k), (dif, seen) in allctl.items():
        chk('ctl', dif == seen and seen > 0, 'n=%d: "%s" differs from the engine\'s E_a on %d of %d samples' % (n, k, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('A4')
if __name__ == '__main__': main()
