#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""L4. The c -> 0 limit of the MacDowell-Mansouri form, and the consistency of A6 (eps F F = d CS_E + 8c L_EC(c)) with B1 (first variation (8c, 4c, 2)).
   python3 l4_mm_limit.py [--no-deg2]
 n = 4, eps_0123 = +1, k_E(X, Y) = eps_{abcd} X^{ab} ^ Y^{cd} (all indices), CS(x) = k_E(omega, d omega + x Q), Q^C = f_AB^C omega^A ^ omega^B, R = d omega + Q/4.
 Exact Fractions on the engine path; A2b strong fields (integer jet coefficients uniform in [-50, 50]) of degree 1, three seeds; one extra seed of degree 2.
 S1  c = 0, B1 route: free fit dL_MM(0) = x pe + y po + z d pt -> (0, 0, 2), rank 3; d pt(0) = d k_E(dom, R)
 S2  c = 0, A6 route: L_MM(0) = d CS_E; delta CS(x) by a free fit; d(delta CS_E) = dL_MM(0) (consistency); controls x = 1/4, Euclidean pairing
 S3  every c: free fits (8c, 4c, 2) at c = 1/3, -2/5, 5/7; dL_MM(c) as a polynomial in c (4 nodes): coefficient forms; varied identity with B1's EC pieces; piece links
 S4  regularity: L_MM(c) - d CS_E = c W1 + c^2 W2, fits; (L_MM(c) - d CS_E)/(8c) = lag_EC(c); controls lam = 6, x = 1/4 (singular, exact remainder)
 S5  [std] numpy, no engine: the MM variation at points (7-point stencil in t, 5-point stencils in x), delta CS of the textbook CS (2/3), the regular quotient;
     [bit==std] engine values at the same points."""
import sys, os, time, itertools, random
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from fractions import Fraction as F
import numpy as np
import b1lib
from b1lib import chk, head, finish, Grav, Lie, det_inv
import b1_first_variation as B1m
import a6_topological as A6
import a2b_strong_sampling as A2b

N = 4; SQ = [1, -1, -1, -1]; RS = 50
NODES = [F(0), F(1, 3), F(-2, 5), F(5, 7)]
T_START = time.time()
def tline(part, t): print('  time %s: %.1f s (total %.1f s)' % (part, time.time() - t, time.time() - T_START), flush=True)
def iszero(X): return all(not p for p in X.values())
def eqf(Fm, X, Y): return iszero(Fm.add(X, Y, -1))
def lin(Fm, terms):
    tot = {}
    for c, X in terms: tot = Fm.add(tot, X, c)
    return tot
def fmtw(w): return 'none' if w is None else '(' + ', '.join(str(x) for x in w) + ')'

# ------------------------------------------------------------------------------------------------ exported helpers
def interp_c(Fm, nodes, vals):
    """[bit] coefficient forms [V0, V1, ...] of the polynomial in c through (nodes, vals) (exact Vandermonde inverse)"""
    m = len(nodes); V = [[F(c) ** k for k in range(m)] for c in nodes]; det, Vi = det_inv(V); assert det != 0
    return [lin(Fm, [(Vi[k][j], vals[j]) for j in range(m)]) for k in range(m)]
def variation(Gv, Lfun, e, om, de, dom):
    """[bit] first variation (coefficient of t^1) and the t^(n+1) coefficient (must be 0) of Lfun(e + t de, om + t dom) (B1's interpolation)"""
    return B1m.first_variation(Gv, Lfun, e, om, de, dom)
def cs_variation_pieces(Gv, kE, om, dom, R=None, Q=None):
    """[bit] the pieces of delta CS: (k(dom, d om), k(dom, Q), d k(om, dom), k(dom, R)); delta CS(x) = 2 p1 + 3x p2 - p3 (found by the fit, S2)"""
    Fm = Gv.Fm; Q = Q if Q is not None else A6.Qforms(Gv, om); R = R if R is not None else Gv.curvature(om)
    return (A6.kpair(Gv, kE, dom, [Fm.d(w) for w in om]), A6.kpair(Gv, kE, dom, Q), Fm.d(A6.kpair(Gv, kE, om, dom)), A6.kpair(Gv, kE, dom, R))
def boundary_th(Gv, e, dom):
    """[bit] th = sum_{a<b} dom^{ab} ^ Y_ab (B1's EC boundary 3-form before d)"""
    Fm = Gv.Fm; Y = B1m.Y_forms(Gv, e); th = {}
    for (a, b) in itertools.combinations(range(Gv.n), 2): th = Fm.add(th, Fm.wedge(dom[Gv.L.idx[(1 << a) | (1 << b)]], Y[(a, b)]))
    return th
def F_list(Gv, e, R, c):
    """[bit] the engine's F^B = R^B + c e^a e^b as a list over bivector indices"""
    _, F_ = Gv.einstein(None, e, R, F(c)); out = [None] * Gv.G
    for (a, b), X in F_.items(): out[Gv.L.idx[(1 << a) | (1 << b)]] = X
    return out
def L_EC_regular(Gv, e, om, c, CSform=None):
    """[bit] (eps F F - d CS_E)/(8c) for c != 0 (= lag_EC(c), S4)"""
    Fm = Gv.Fm; CSform = CSform if CSform is not None else A6.cs_form(Gv, A6.kform(Gv, 'E'), om, F(1, 6))
    return Fm.scale(Fm.add(B1m.lag_MM(Gv, e, om, F(c)), Fm.d(CSform), -1), 1 / (8 * F(c)))

# ------------------------------------------------------------------------------------------------ engine part (S1-S4)
def engine_seed(Gv, label, e, om, de, dom, full=True):
    Fm = Gv.Fm; t = time.time(); kE = A6.kform(Gv, 'E'); R = Gv.curvature(om); Q = A6.Qforms(Gv, om); out = {}
    # ---- S1: B1 route at c = 0
    first0, top0 = variation(Gv, lambda ee, oo: B1m.lag_MM(Gv, ee, oo, F(0)), e, om, de, dom)
    pe0, po0, dpt0 = B1m.mm_pieces(Gv, e, om, de, dom, F(0))
    w, rank, nvar, cons = A6.fit(first0, [pe0, po0, dpt0])
    chk('bit', iszero(top0) and cons and w == [0, 0, 2] and rank == 3 and not iszero(pe0) and not iszero(po0) and not iszero(first0),
        '%s S1 c = 0: free fit dL_MM(0) = x (de^a E_a(0)) + y (eps dom T e) + z d(eps dom R) gives (x, y, z) = %s, rank %d of 3, consistent; the pieces de^a E_a(0) and eps dom T e are non-zero: the bulk part vanishes identically' % (label, fmtw(w), rank))
    p1, p2, p3, pR = cs_variation_pieces(Gv, kE, om, dom, R, Q)
    chk('bit', eqf(Fm, dpt0, Fm.d(pR)) and eqf(Fm, first0, Fm.scale(Fm.d(pR), 2)),
        '%s S1 link: B1 boundary term at c = 0 is A6 Euler pairing, d pt(0) = d k_E(dom, R); dL_MM(0) = 2 d k_E(dom, R) exactly' % label)
    tline('%s S1' % label, t); t = time.time()
    # ---- S2: A6 route at c = 0
    CS = A6.cs_form(Gv, kE, om, F(1, 6), Q=Q); dCSf = Fm.d(CS); L0 = B1m.lag_MM(Gv, e, om, F(0))
    chk('bit', eqf(Fm, L0, dCSf) and not iszero(L0), '%s S2 A6 identity re-read on these fields: L_MM(0) = eps R R = d CS_E, x = 1/6' % label)
    var = lambda x: variation(Gv, lambda ee, oo: A6.cs_form(Gv, kE, oo, x), e, om, de, dom)
    dCS, topc = var(F(1, 6))
    w3, r3, _, c3 = A6.fit(dCS, [p1, p2, p3]); w2, r2, _, c2 = A6.fit(dCS, [pR, p3])
    chk('bit', iszero(topc) and c3 and r3 == 3 and w3 == [2, F(1, 2), -1],
        '%s S2 delta CS_E = a k_E(dom, d omega) + b k_E(dom, Q) + g d k_E(omega, dom): free fit (a, b, g) = %s, rank %d (hand: 2, 3x = 1/2, -1)' % (label, fmtw(w3), r3))
    chk('bit', c2 and w2 == [2, -1], '%s S2 delta CS_E = 2 k_E(dom, R) - d k_E(omega, dom): fit %s (the engine form of delta CS = 2 tr(delta omega R) + d(...))' % (label, fmtw(w2)))
    ddCS = Fm.d(dCS)
    chk('bit', eqf(Fm, ddCS, first0) and eqf(Fm, ddCS, Fm.scale(Fm.d(pR), 2)),
        '%s S2 CONSISTENCY at c = 0: d(delta CS_E) [A6 route] = dL_MM(0) [B1 route] = 2 d k_E(dom, R), exactly' % label)
    # controls: wrong CS coefficient x = 1/4 (Lagrangian level: exact remainder; 3-form level: bulk remainder), Euclidean pairing
    CSb = A6.cs_form(Gv, kE, om, F(1, 4), Q=Q); rem = Fm.add(L0, Fm.d(CSb), -1); dkQ = Fm.d(A6.kpair(Gv, kE, om, Q))
    chk('ctl', not iszero(rem), '%s S2 control x = 1/4: L_MM(0) != d CS(1/4)' % label)
    chk('bit', eqf(Fm, rem, Fm.scale(dkQ, F(-1, 12))),
        '%s S2 the x = 1/4 remainder is itself exact: L_MM(0) - d CS(1/4) = (1/6 - 1/4) d k_E(omega, Q) = -(1/12) d k_E(omega, Q) (no bulk variation)' % label)
    dCSb, _ = var(F(1, 4)); wb2 = A6.fit(dCSb, [pR, p3]); wb3 = A6.fit(dCSb, [p1, p2, p3]); bulk = Fm.add(dCSb, Fm.add(Fm.scale(pR, 2), p3, -1), -1)
    chk('ctl', not wb2[3] and not iszero(bulk), '%s S2 control x = 1/4: delta CS(1/4) is not 2 k_E(dom, R) + d(...) (fit inconsistent): a bulk remainder is left in the 3-form' % label)
    chk('bit', eqf(Fm, bulk, Fm.scale(p2, F(1, 4))) and wb3[3] and wb3[0] == [2, F(3, 4), -1],
        '%s S2 that remainder is (3x - 1/2) k_E(dom, Q) = (1/4) k_E(dom, Q); free fit %s' % (label, fmtw(wb3[0])))
    kU = A6.kform(Gv, 'Eucl')
    dLU, _ = variation(Gv, lambda ee, oo: (lambda RR: A6.kpair(Gv, kU, RR, RR))(Gv.curvature(oo)), e, om, de, dom)
    wU = A6.fit(dLU, [Fm.d(A6.kpair(Gv, kU, dom, R))])
    chk('ctl', not wU[3], '%s S2 control: Euclidean pairing sum R^{ab} R^{ab}: no z with delta = z d k(dom, R) (bulk remainder; not so(1,3)-invariant)' % label)
    tline('%s S2' % label, t); t = time.time()
    out.update(first0=first0, dpt0=dpt0, dCS=dCS)
    if not full:
        c = F(1, 3); fv, tp = variation(Gv, lambda ee, oo: B1m.lag_MM(Gv, ee, oo, c), e, om, de, dom); ep, op, dth = B1m.rhs_pieces(Gv, e, om, de, dom, c)
        chk('bit', iszero(tp) and eqf(Fm, fv, lin(Fm, [(1, ddCS), (8 * c, ep), (8 * c, op), (8 * c, dth)])),
            '%s S3 CONSISTENCY c = 1/3: dL_MM(c) = d(delta CS_E) + 8c (de^a E_a(c) + dom Theta + d(dom Y)) with B1 EC pieces' % label)
        tline('%s S3 (c = 1/3 only)' % label, t); return out
    # ---- S3: every c
    dL = {F(0): first0}; PE = {}; PO = {}; DPT = {}
    for c in NODES[1:]:
        fv, tp = variation(Gv, lambda ee, oo: B1m.lag_MM(Gv, ee, oo, c), e, om, de, dom); pe, po, dpt = B1m.mm_pieces(Gv, e, om, de, dom, c)
        w, rank, _, cons = A6.fit(fv, [pe, po, dpt])
        chk('bit', iszero(tp) and cons and rank == 3 and w == [8 * c, 4 * c, F(2)], '%s S3 c = %s: free fit (x, y, z) = %s = (8c, 4c, 2), rank %d' % (label, c, fmtw(w), rank))
        if c == F(1, 3): chk('ctl', cons and w != [0, 0, 2], '%s S3 control c = 1/3: the fit returns bulk coefficients %s, not (0, 0, 2)' % (label, fmtw(w)))
        dL[c] = fv; PE[c] = pe; PO[c] = po; DPT[c] = dpt
    V = interp_c(Fm, NODES, [dL[c] for c in NODES])
    dvol, _ = variation(Gv, lambda ee, oo: B1m.wedge_list(Fm, ee), e, om, de, dom)
    dLR, _ = variation(Gv, lambda ee, oo: B1m.lag_EC(Gv, ee, oo, F(0)), e, om, de, dom)
    chk('bit', iszero(V[3]) and not iszero(V[2]), '%s S3 dL_MM(c) has degree exactly 2 in c: cubic coefficient of the 4-node interpolation is 0 (degree <= 2 by construction: F affine in c), c^2 coefficient non-zero' % label)
    chk('bit', eqf(Fm, V[2], Fm.scale(dvol, 24)) and eqf(Fm, V[1], Fm.scale(dLR, 8)) and eqf(Fm, V[0], ddCS),
        '%s S3 as a polynomial in c, exactly: dL_MM(c) = d(delta CS_E) + 8c delta L_R + 24 c^2 delta vol(e) (each coefficient form compared)' % label)
    th = boundary_th(Gv, e, dom); ok_id = ok_po = ok_pe = ok_pt = True
    for c in NODES[1:]:
        ep, op, dth = B1m.rhs_pieces(Gv, e, om, de, dom, c)
        ok_id &= eqf(Fm, dL[c], lin(Fm, [(1, ddCS), (8 * c, ep), (8 * c, op), (8 * c, dth)]))
        ok_po &= eqf(Fm, PO[c], Fm.scale(op, 2)); ok_pe &= eqf(Fm, PE[c], ep)
        ok_pt &= eqf(Fm, A6.kpair(Gv, kE, dom, F_list(Gv, e, R, c)), Fm.add(pR, th, 4 * c)) and eqf(Fm, DPT[c], Fm.add(Fm.d(pR), Fm.d(th), 4 * c))
    chk('bit', ok_id, '%s S3 CONSISTENCY c = 1/3, -2/5, 5/7: dL_MM(c) = d(delta CS_E) + 8c (de^a E_a(c) + dom^{ab} Theta_ab + d(dom^{ab} Y_ab)) with B1 EC pieces' % label)
    chk('bit', ok_po and ok_pe and ok_pt, '%s S3 piece links: MM omega-piece eps dom T e = 2 x EC dom Theta; MM e-piece = EC e-piece; pt(c) = k_E(dom, R) + 4c sum dom Y (3-forms)' % label)
    tline('%s S3' % label, t); t = time.time()
    # ---- S4: regularity
    Lc = {c: B1m.lag_MM(Gv, e, om, c) for c in NODES}; W = interp_c(Fm, NODES, [Lc[c] for c in NODES])
    LR = B1m.lag_EC(Gv, e, om, F(0)); vol = B1m.wedge_list(Fm, e); wa = A6.fit(W[1], [LR]); wb = A6.fit(W[2], [vol])
    chk('bit', iszero(W[3]) and eqf(Fm, W[0], dCSf) and wa[3] and wb[3] and wa[0] == [8] and wb[0] == [24],
        '%s S4 L_MM(c) = d CS_E + c (alpha L_R) + c^2 (beta vol(e)), cubic coefficient 0: fit (alpha, beta) = (%s, %s), so L_EC(c) = L_R + (beta/alpha) c vol(e) = L_R + %s c vol(e)' % (label, wa[0][0] if wa[0] else '-', wb[0][0] if wb[0] else '-', (wb[0][0] / wa[0][0]) if wa[0] and wb[0] else '-'))
    okq = okq6 = okb = okbr = True
    for c in NODES[1:]:
        q = L_EC_regular(Gv, e, om, c, CS); okq &= eqf(Fm, q, B1m.lag_EC(Gv, e, om, c)); okq6 &= not eqf(Fm, q, B1m.lag_EC(Gv, e, om, c, lam=F(6)))
        qb = L_EC_regular(Gv, e, om, c, CSb); okb &= not eqf(Fm, qb, B1m.lag_EC(Gv, e, om, c)); okbr &= eqf(Fm, Fm.add(qb, B1m.lag_EC(Gv, e, om, c), -1), Fm.scale(dkQ, F(-1, 12) / (8 * c)))
    chk('bit', okq and eqf(Fm, Fm.scale(W[1], F(1, 8)), LR),
        '%s S4 exact division: (eps F F - d CS_E)/(8c) = B1 lag_EC(c) = L_R + 3c vol(e) at c = 1/3, -2/5, 5/7; its c -> 0 value W1/8 = L_R (Palatini 4-form)' % label)
    chk('ctl', okq6, '%s S4 control: lam = 6 instead of 3 in lag_EC fails at every c' % label)
    chk('ctl', okb, '%s S4 control x = 1/4: (eps F F - d CS(1/4))/(8c) != L_EC(c) at every c' % label)
    chk('bit', okbr, '%s S4 with x = 1/4 the difference is -(1/(96 c)) d k_E(omega, Q): singular as c -> 0 but exact (no bulk variation)' % label)
    tline('%s S4' % label, t)
    out.update(dL=dL, PE=PE, OP={c: B1m.rhs_pieces(Gv, e, om, de, dom, c)[1] for c in (F(1, 3),)}, DPT=DPT, LEC={c: B1m.lag_EC(Gv, e, om, c) for c in (F(1, 3),)})
    return out

# ------------------------------------------------------------------------------------------------ [std] numpy route (never touches the engine; B1's Std reads only the polynomial data)
LC4 = A6.LC4
TW7 = [(-3, -1 / 60), (-2, 9 / 60), (-1, -45 / 60), (1, 45 / 60), (2, -9 / 60), (3, 1 / 60)]
def alt3(Z): return Z - Z.transpose(1, 0, 2) + Z.transpose(1, 2, 0)          # X_m Y_nr - X_n Y_mr + X_r Y_mn from Z[m,n,r] = X_m Y_nr
class StdMM(B1m.Std):
    """[std] textbook so(1,3): F^{ab}_{mn} = R^{ab}_{mn} + c (e^a_m e^b_n - e^a_n e^b_m); L = (1/4) eps^{mnrs} eps_{abcd} F^{ab}_{mn} F^{cd}_{rs}"""
    def Farr(self, x, t=0.0, c=None):
        c = self.c if c is None else c; R, T, e, om = self.curv_tors(x, t)
        return R + c * (np.einsum('am,bn->abmn', e, e) - np.einsum('an,bm->abmn', e, e))
    def Lmm(self, x, t=0.0, c=None): Fa = self.Farr(x, t, c); return 0.25 * np.einsum('mnrs,abcd,abmn,cdrs->', LC4, LC4, Fa, Fa)
    def dLmm(self, x): return sum(w * self.Lmm(x, t) for t, w in TW7)
    def J(self, y):
        Fa = self.Farr(y); dom_ = self.fields(y)[3]; return alt3(np.einsum('abcd,abm,cdnr->mnr', LC4, dom_, Fa))
    def top_d3(self, fun, x):
        g = self.grad(fun, x); full = tuple(range(4)); return sum((-1) ** i * g[i][tuple(j for j in full if j != i)] for i in range(4))
    def cs3(self, x, t, coef):
        om = self.fields(x, t)[1]; dom = self.grad(lambda y: self.fields(y, t)[1], x)
        dw = np.einsum('mabn->abmn', dom) - np.einsum('nabm->abmn', dom)
        ww = np.einsum('acm,c,cbn->abmn', om, self.sq, om) - np.einsum('acn,c,cbm->abmn', om, self.sq, om)
        return alt3(np.einsum('abcd,abm,cdnr->mnr', LC4, om, dw + coef * ww))
    def dcs(self, x, coef): return sum(w * self.cs3(x, t, coef) for t, w in TW7)
    def cs_pred(self, x):
        R = self.curv_tors(x)[0]; dom_ = self.fields(x)[3]; P = alt3(np.einsum('abcd,abm,cdnr->mnr', LC4, dom_, R))
        def W2(y):
            f = self.fields(y); X = np.einsum('abcd,abm,cdn->mn', LC4, f[1], f[3]); return X - X.T
        g = self.grad(W2, x); return 2 * P - alt3(g)
TRIPLES = list(itertools.combinations(range(4), 3))
def ev(p, x): return sum(float(c) * float(np.prod([x[i] ** k[i] for i in range(4)])) for k, c in p.items())
def evf(X, mask, x): return ev(X.get(mask, {}), x)
def close(a, b): return abs(a - b) <= 1e-8 * max(1.0, abs(a), abs(b))

def std_seed(label, e, om, de, dom, eng, rng):
    t = time.time(); pts = [np.array([rng.uniform(-.5, .5) for _ in range(4)]) for _ in range(2)]
    worst = 0.0; ok_dec = ok_nt = ctl_z = ok_cs = ctl_cs = ok_reg = True; bs_L = bs_J = bs_cs = bs_pe = bs_op = bs_lec = True
    for c in (F(0), F(1, 3)):
        S = StdMM(4, SQ, e, om, de, dom, float(c))
        for x in pts:
            lhs = S.dLmm(x); ep, op, _ = S.rhs(x); dJ = S.top_d3(S.J, x); rhs = 8 * float(c) * (ep + op) + 2 * dJ
            ok_dec &= close(lhs, rhs); ok_nt &= abs(lhs) > 1e-6; ctl_z &= not close(lhs, 8 * float(c) * (ep + op) + dJ)
            worst = max(worst, abs(lhs - rhs) / max(1.0, abs(lhs)))
            fv = eng['first0'] if c == 0 else eng['dL'][c]; dpt = eng['dpt0'] if c == 0 else eng['DPT'][c]
            bs_L &= close(evf(fv, 15, x), lhs); bs_J &= close(evf(dpt, 15, x), dJ)
            if c != 0:
                bs_pe &= close(evf(eng['PE'][c], 15, x), ep); bs_op &= close(evf(eng['OP'][c], 15, x), op)
                reg = (S.Lmm(x, 0.0, float(c)) - S.Lmm(x, 0.0, 0.0)) / (8 * float(c)); ok_reg &= close(reg, S.lagrangian(x, 0.0))
                bs_lec &= close(evf(eng['LEC'][c], 15, x), reg)
        if c == 0:
            for x in pts:
                d = S.dcs(x, 2 / 3); p = S.cs_pred(x); db = S.dcs(x, 1 / 2)
                ok_cs &= all(close(d[tr], p[tr]) for tr in TRIPLES); ctl_cs &= not all(close(db[tr], p[tr]) for tr in TRIPLES)
                bs_cs &= all(close(evf(eng['dCS'], (1 << tr[0]) | (1 << tr[1]) | (1 << tr[2]), x), d[tr]) for tr in TRIPLES)
    chk('std', ok_dec and ok_nt, '%s S5 numpy, 2 points, c = 0 and 1/3: dL_MM (7-point stencil in t) = 8c (de^a E_a + dom Theta) + 2 d(eps dom F) (5-point stencils), non-zero; at c = 0 only 2 d(eps dom R) is left (worst relative %.1e)' % (label, worst))
    chk('ctl', ctl_z, '%s S5 [std] control: z = 1 instead of 2 fails at every point' % label)
    chk('std', ok_cs, '%s S5 numpy textbook CS = eps omega (d omega + (2/3) omega omega): delta CS = 2 eps dom R - d(eps omega dom) at 2 points, 4 components' % label)
    chk('ctl', ctl_cs, '%s S5 [std] control: cubic coefficient 1/2 instead of 2/3 leaves a bulk remainder at every point' % label)
    chk('std', ok_reg, '%s S5 numpy (L_MM(c) - L_MM(0))/(8c) = L_R + 3c det(e) (B1 Std lagrangian) at c = 1/3, 2 points' % label)
    chk('bit==std', bs_L and bs_J and bs_cs, '%s S5 engine dL_MM(c), 2 d pt(c) (c = 0, 1/3) and delta CS_E (4 components) = numpy values at the points' % label)
    chk('bit==std', bs_pe and bs_op and bs_lec, '%s S5 engine de^a E_a(1/3), dom Theta (B1 EC pieces) and lag_EC(1/3) = numpy values' % label)
    tline('%s S5' % label, t)

def main():
    argv = sys.argv[1:]; deg2 = '--no-deg2' not in argv
    nseed = int(argv[argv.index('--seeds') + 1]) if '--seeds' in argv else 3            # --seeds k: the first k seeds only
    Gv = Grav(N, Lie(SQ)); Fm = Gv.Fm
    head('L4: n = 4, A2b strong fields (integers uniform in [-%d, %d]), degree 1, seeds %s; c nodes %s' % (RS, RS, A2b.seeds_for('L4', N, nseed), ', '.join(str(c) for c in NODES)))
    for seed in A2b.seeds_for('L4', N, nseed):
        rng = random.Random(seed); om, e = A2b.fields(rng, N, Gv.G, RS); dom, de = A2b.fields(rng, N, Gv.G, RS)
        eng = engine_seed(Gv, 'seed %d' % seed, e, om, de, dom)
        std_seed('seed %d' % seed, e, om, de, dom, eng, random.Random(seed + 7))
    if deg2:
        seed = A2b.seeds_for('L4', N, 1, extra=2)[0]; rng = random.Random(seed)
        head('L4: one extra seed of degree 2 (engine only; S1, S2 and the consistency at c = 1/3)')
        om = [A2b.s_form(rng, N, 1, 2, RS) for _ in range(Gv.G)]; e = [A2b.s_form(rng, N, 1, 2, RS) for _ in range(N)]
        dom = [A2b.s_form(rng, N, 1, 2, RS) for _ in range(Gv.G)]; de = [A2b.s_form(rng, N, 1, 2, RS) for _ in range(N)]
        engine_seed(Gv, 'deg2 seed %d' % seed, e, om, de, dom, full=False)
    print('\nTOTAL %.1f s' % (time.time() - T_START)); finish('L4')

if __name__ == '__main__': main()
