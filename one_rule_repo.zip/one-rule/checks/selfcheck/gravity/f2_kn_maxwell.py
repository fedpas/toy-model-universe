#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F2-M: Maxwell on the Kerr-Newman frames of F2 (f2_first_law, imported as K14), the variational stress of B3, and the Noether chain between them.   python3 f2_kn_maxwell.py
 Frames: F2's kn_frame_jet (exact 2-jets) at F2's 10 KN points; an own KN builder of any jet order (kn_jets) for the Noether chain (frame 3-jets).
 Part 1 [bit] d*F = 0 at the point (bit-rule star, g2_hodge.hodge_form) and nabla^a F_ab = 0 (A3 omega, g2_hodge.D_two_index); [std] exact plain derivatives
        d_mu(sqrt(-g) F^{mu nu}) = 0 with det g = -1 checked as a 1-jet; [bit==std] the engine's *F at the point = (1/2) sqrt(-g) eps F^{..} (eps_0123 = +1).
 Part 2 [bit] E_a(c = 0) = kappa tau_a, tau from B3's matter_variation of L_A = -(1/2) F^*F, kappa = 4 s/Q^2, no fit, all 16 components.
 Part 3 [bit] Noether chain with frame 3-jets: E_a = kappa tau_a as 1-jets, D E_a = 0 and D tau_a = (i_a F) ^ EL_A at the point (B3), the 4 x 4 map J -> (i_a F) ^ J,
        its determinant against the Pfaffian of F_ab; RN (a = 0): Pf = 0, rank 2.
 Part 4 [ctl] wrong potentials (r^2 numerator; l of the opposite rotation), the sign of the matter action, s -> -s; Q -> -Q in A is a symmetry; [std] floats: Gauss flux of
        *F through r = const (oblate surfaces) = -4 pi Q.
 Exports (import-safe, no engine object at import): kn_jets(p, M, a, s, r0, Q, order=3, a_pot=None, power=3), pot_from(data, Q, power=3, l=None), maxwell_point(Gv, S, e, E, A),
   einstein_tau(Gv, S, e, A, kap, sA=1), noether_chain(Gv, S, e, A, kap), std_div(e, A), kn_flux(M, a, s, Q, R0, nth=40, nph=48)."""
import sys, os, time, itertools, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from fractions import Fraction as F
import numpy as np
import f2_first_law as K14
import g2_kerr as GK
import g2_hodge as H
import g2_forms_calc as FC
import b3_matter as B3

SQ = [1, -1, -1, -1]; FULL = 15
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
SETS = [(F(5), F(1), F(4), 1, [9, 20, 4, F(1, 2)]), (F(7, 2), F(2), F(2), 1, [6, 3]), (F(5), F(1), F(2), 4, [9])]      # F2 part 1
def kn_points():
    out = []
    for (M, a, Q, kap, rs) in SETS:
        s = F(kap) * Q * Q / 4
        for P in (GK.rational_kerr_points(a, rs, K14.ANG[:1]) if len(rs) > 2 else GK.rational_kerr_points(a, rs, K14.ANG)): out.append((M, a, Q, kap, s, P))
    return out

# ------------------------------------------------------------------------------------------------ own Kerr-Newman jets of any order (exact, truncated products)
def _rec(A, order, nv=4):
    A0 = at0(A, nv); u = scale(padd(A, const(nv, A0), -1), -1 / A0); t = const(nv, 1); res = dict(t)
    for _ in range(order): t = sp_mul(t, u, order, 4); res = padd(res, t)
    return scale(res, 1 / A0)
def kn_jets(p, M, a, s, r0, Q, order=3, a_pot=None, power=3, nv=4):
    """coframe e^A = dx^A - f l^A l_mu dx^mu, f = (M r - s) r^2/(r^4 + a^2 z^2), inverse E = delta + f l^mu l_A, potential A = Q r^power/(r^4 + a^2 z^2) l(a_pot)_mu dx^mu;
       r(x) by the chord iteration on r^4 - (rho^2 - a^2) r^2 - a^2 z^2 = 0; all jets exact to x-degree `order`"""
    mul = lambda x, y: sp_mul(x, y, order, 4); p = [F(c) for c in p]; M, a, s, r0 = F(M), F(a), F(s), F(r0)
    X = [None] + [lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))) for i in (1, 2, 3)]
    rho2 = lin(*[(F(1), mul(X[i], X[i])) for i in (1, 2, 3)]); z2 = mul(X[3], X[3]); a2 = a * a
    Pp = 4 * r0 ** 3 - 2 * (sum(c * c for c in p) - a2) * r0; r = const(nv, r0)
    def Pof(r):
        r2 = mul(r, r); return lin((F(1), mul(r2, r2)), (F(-1), mul(padd(rho2, const(nv, a2), -1), r2)), (-a2, z2))
    for _ in range(order + 2): r = padd(r, Pof(r), -1 / Pp)
    assert not Pof(r), 'r jet not exact'
    r2 = mul(r, r); r3 = mul(r2, r); den = _rec(lin((F(1), mul(r2, r2)), (a2, z2)), order)
    f = mul(lin((M, r3), (-s, r2)), den)
    def ell(al):
        iA = _rec(lin((F(1), r2), (al * al, const(nv, 1))), order); ir = _rec(r, order)
        return [const(nv, 1), mul(lin((F(1), mul(r, X[1])), (al, X[2])), iA), mul(lin((F(1), mul(r, X[2])), (-al, X[1])), iA), mul(X[3], ir)]
    l_dn = ell(a); l_up = [l_dn[0]] + [scale(q, -1) for q in l_dn[1:]]
    e = []; E = [[None] * 4 for _ in range(4)]
    for A_ in range(4):
        form = {}
        for mu in range(4):
            pol = lin((F(1 if A_ == mu else 0), const(nv, 1)), (F(-1), mul(mul(f, l_up[A_]), l_dn[mu])))
            if pol: form[1 << mu] = pol
            E[mu][A_] = lin((F(1 if A_ == mu else 0), const(nv, 1)), (F(1), mul(mul(f, l_up[mu]), l_dn[A_])))
        e.append(form)
    lp = l_dn if a_pot is None else ell(F(a_pot))
    h = scale(mul(r3 if power == 3 else r2, den), F(Q))
    A = {1 << mu: q for mu in range(4) for q in [mul(h, lp[mu])] if q}
    return e, E, A, dict(r=r, f=f, l_dn=l_dn)
def pot_from(data, Q, power=3, l=None):
    """F2-style 2-jet potential Q r^power/(r^4 + a^2 z^2) l_mu dx^mu from kn_frame_jet's data (power 3 = F2's kn_potential)"""
    r, a, p = data['r'], data['a'], data['p']; nv = 4; z = lin((F(1), const(nv, p[2])), (F(1), var(nv, 3))); jm = GK._jm; r2 = jm(r, r)
    num = jm(r2, r) if power == 3 else r2
    hh = scale(jm(num, GK.recip2(lin((F(1), jm(r2, r2)), (a * a, jm(z, z))), nv)), F(Q)); l = l or data['l_dn']
    return {1 << mu: q for mu in range(4) for q in [jm(hh, l[mu])] if q}

# ------------------------------------------------------------------------------------------------ [bit] Maxwell at the point, the stress by variation, the Noether chain
def maxwell_point(Gv, S, e, E, A):
    """(d*F at the point: {mask: value}, nabla^a F_ab at the point: list, *F at the point, F_ab frame components at the point)"""
    Fm = Gv.Fm
    with trunc(4, xdeg=1):
        Fc = Fm.d(A); starF = H.hodge_form(Fc, e, E, Fm, SQ, 4); Fab_c = H.frame_components(Fc, E, 4)
    dstar = {m: at0(p, 4) for m, p in Fm.d(starF).items() if at0(p, 4) != 0}
    Fab = {}
    for a in range(4):
        for b in range(4):
            if a != b:
                c = Fab_c.get((1 << a) | (1 << b), {}); Fab[(a, b)] = c if a < b else scale(c, -1)
    om = omega_closed_form(Gv, e, S, 4, 1)[0]
    with trunc(4, xdeg=0): DF = H.D_two_index(Gv, om, Fab, 4)
    div = H.frame_divergence_at0(DF, E, SQ, 4)
    star0 = {m: at0(p, 4) for m, p in starF.items() if at0(p, 4) != 0}
    F0 = {(a, b): at0(Fab[(a, b)], 4) for a in range(4) for b in range(a + 1, 4)}
    return dstar, div, star0, F0
def einstein_tau(Gv, S, e, A, kap, sA=1):
    """E_a(c = 0) components at the point (engine) and kappa tau_a (B3 variation of -(sA/2) F^*F), 16 components each"""
    om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0)
    with trunc(4, xdeg=1): Fc = Gv.Fm.d(A)
    F5 = B3.lift_form(Fc); e5 = [B3.lift_form(x) for x in e]
    tau = B3.matter_variation(Gv, e5, lambda ep, Ep: B3.L_maxwell(Gv, ep, Ep, F5, sA), xdeg=0)
    ct = einstein_components(tau, 4, 5)
    return comp, {k: kap * v for k, v in ct.items()}
def noether_chain(Gv, S, e, A, kap):
    """frame 3-jets: E_a and kappa tau_a as 1-jets, D E_a at the point, B3's (D tau_a, (i_a F)^EL_A) at the point, the 4 x 4 map M[a][mu] and EL_A at the point"""
    Fm = Gv.Fm; om = omega_closed_form(Gv, e, S, 4, 2)[0]
    with trunc(4, xdeg=1):
        R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(0))
    DE0 = [at0(x.get(FULL, {}), 4) for x in Gv.D_covector([ftr(x, 0) for x in om], Ea)]
    e5 = [B3.lift_form(x) for x in e]; A5 = B3.lift_form(A); om5 = [B3.lift_form(x) for x in om]
    with trunc(4, xdeg=2): F5 = Fm.d(A5)
    tau = B3.matter_variation(Gv, e5, lambda ep, Ep: B3.L_maxwell(Gv, ep, Ep, F5, 1), xdeg=1)
    same1 = all(B3.form_eq_deg(B3.lift_form(x), Fm.scale(t, kap), 1) for x, t in zip(Ea, tau))
    nz1 = sum(1 for x in Ea for p in x.values() for k, v in p.items() if sum(k[:4]) == 1 and v != 0)
    lhs, rhs, _, EL0 = B3.noether_at0(Gv, [ftr(x, 0) for x in om5], e5, A5, 'A', sA=1, tau=tau)
    with trunc(4, xdeg=1):
        Einv, _ = inverse_series(frame_matrix(e5, 4), 4, 5, 1)
    Mx = []
    for a in range(4):
        ia = FC.interior(Gv, [Einv[mu][a] for mu in range(4)], F5)
        Mx.append([(-1) ** mu * at0(ia.get(1 << mu, {}), 5) for mu in range(4)])
    j = [at0(EL0.get(FULL ^ (1 << mu), {}), 5) for mu in range(4)]
    return dict(same1=same1, nz1=nz1, DE0=DE0, lhs=lhs, rhs=rhs, M=Mx, j=j)
def jet(P, n, deg): return {k: v for k, v in P.items() if sum(k[:n]) <= deg}
def ftr(X, deg):
    out = {}
    for m, p in X.items():
        q = {k: v for k, v in p.items() if sum(k[:4]) <= deg}
        if q: out[m] = q
    return out
def det4(M):
    return sum(perm_sign(p) * M[0][p[0]] * M[1][p[1]] * M[2][p[2]] * M[3][p[3]] for p in itertools.permutations(range(4)))
def perm_sign(p):
    s = 1; p = list(p)
    for i in range(len(p)):
        for k in range(i + 1, len(p)):
            if p[i] > p[k]: s = -s
    return s
def pfaff(F0): return F0[(0, 1)] * F0[(2, 3)] - F0[(0, 2)] * F0[(1, 3)] + F0[(0, 3)] * F0[(1, 2)]

# ------------------------------------------------------------------------------------------------ [std] plain derivatives (no engine)
def std_div(e, A):
    """[std] d_mu(sqrt(-g) F^{mu nu}) at the point with g = e^T eta e (2-jet), g^-1 (1-jet), det g as a 1-jet; also (1/2) sqrt(-g) eps F^{..} at the point"""
    n = 4; g = std_metric(e, n, SQ, n, 2); gi, g0, g0i = std_inverse_metric(g, n, n, 1)
    detg = {}
    for p in itertools.permutations(range(4)):
        t = const(4, perm_sign(p))
        for i in range(4): t = sp_mul(t, g[(i, p[i])], 1, n)
        detg = sp_add(detg, t)
    Fl = {(m, v): sp_add(sp_der(A.get(1 << v, {}), m), sp_der(A.get(1 << m, {}), v), -1) for m in range(4) for v in range(4)}
    Fl = {k: {kk: c for kk, c in p.items() if sum(kk) <= 1} for k, p in Fl.items()}
    Fup = {(m, v): lin(*[(F(1), sp_mul(sp_mul(gi[(m, al)], gi[(v, be)], 1, n), Fl[(al, be)], 1, n)) for al in range(4) for be in range(4)]) for m in range(4) for v in range(4)}
    div = [sum(at0(sp_der(Fup[(m, v)], m), 4) for m in range(4)) for v in range(4)]
    F0up = {k: at0(p, 4) for k, p in Fup.items()}; sg = 1                                              # sqrt(-g) = 1 (checked as a 1-jet below)
    star = {}
    for (m, v) in [(m, v) for m in range(4) for v in range(m + 1, 4)]:
        star[(1 << m) | (1 << v)] = sum(F(1, 2) * sg * perm_sign((m, v, r, t)) * F0up[(r, t)] for r in range(4) for t in range(4) if len({m, v, r, t}) == 4)
    return div, detg == const(4, -1), {k: v for k, v in star.items() if v != 0}, {k: at0(p, 4) for k, p in Fl.items()}

# ------------------------------------------------------------------------------------------------ [std] floats: Gauss flux through r = R0
def _r_of(x, y, z, a):
    b = x * x + y * y + z * z - a * a; return math.sqrt((b + math.sqrt(b * b + 4 * a * a * z * z)) / 2)
def _ell(x, y, z, a, r): A_ = r * r + a * a; return np.array([1.0, (r * x + a * y) / A_, (r * y - a * x) / A_, z / r])
def kn_metric(X, M, a, s):
    r = _r_of(X[1], X[2], X[3], a); f = (M * r - s) * r ** 2 / (r ** 4 + a * a * X[3] ** 2); l = _ell(X[1], X[2], X[3], a, r)
    return np.diag([1.0, -1, -1, -1]) - 2 * f * np.outer(l, l)
def kn_A(X, a, Q):
    r = _r_of(X[1], X[2], X[3], a); return Q * r ** 3 / (r ** 4 + a * a * X[3] ** 2) * _ell(X[1], X[2], X[3], a, r)
EPS4 = np.zeros((4, 4, 4, 4))
for _p in itertools.permutations(range(4)): EPS4[_p] = perm_sign(_p)
def kn_flux(M, a, s, Q, R0, nth=40, nph=48, h=1e-4):
    """[std] integral of *F over t = 0, r = R0 (x = sin th (R0 cos ph - a sin ph), y = sin th (R0 sin ph + a cos ph), z = R0 cos th), orientation (theta, phi)"""
    xs, ws = np.polynomial.legendre.leggauss(nth); tot = 0.0
    for xg, wg in zip(xs, ws):
        th = (xg + 1) * math.pi / 2; wth = wg * math.pi / 2
        for j in range(nph):
            ph = 2 * math.pi * j / nph; st, ct, sp, cp = math.sin(th), math.cos(th), math.sin(ph), math.cos(ph)
            X = np.array([0.0, st * (R0 * cp - a * sp), st * (R0 * sp + a * cp), R0 * ct])
            dA = np.zeros((4, 4))
            for k in range(4):
                ek = np.zeros(4); ek[k] = h
                dA[k] = (-kn_A(X + 2 * ek, a, Q) + 8 * kn_A(X + ek, a, Q) - 8 * kn_A(X - ek, a, Q) + kn_A(X - 2 * ek, a, Q)) / (12 * h)
            Fco = dA - dA.T; g = kn_metric(X, M, a, s); gi = np.linalg.inv(g); Fup = gi @ Fco @ gi.T
            SF = 0.5 * math.sqrt(abs(np.linalg.det(g))) * np.einsum('mnrs,rs->mn', EPS4, Fup)
            Xt = np.array([0.0, ct * (R0 * cp - a * sp), ct * (R0 * sp + a * cp), -R0 * st]); Xp = np.array([0.0, st * (-R0 * sp - a * cp), st * (R0 * cp - a * sp), 0.0])
            tot += Xt @ SF @ Xp * wth * (2 * math.pi / nph)
    return tot

# ------------------------------------------------------------------------------------------------ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
    pts = kn_points()
    head('Part 1. Maxwell on F2\'s 10 KN points: d*F = 0 and nabla^a F_ab = 0 at the point (A 2-jets, frame 2-jets), [std] plain derivatives')
    ok1 = ok2 = okS = okB = True; nstar = 0; pf = []
    for (M, a, Q, kap, s, P) in pts:
        e, E, _, data = K14.kn_frame_jet(P['p'], M, a, s, P['r']); A = K14.kn_potential(Q, data)
        dstar, div, star0, F0 = maxwell_point(Gv, S, e, E, A); sd, detok, sstar, Fl0 = std_div(e, A)
        ok1 &= not dstar; ok2 &= all(v == 0 for v in div); okS &= all(v == 0 for v in sd) and detok; okB &= star0 == sstar and bool(star0); nstar += len(star0); pf.append(pfaff(F0))
    chk('bit', ok1, 'd*F = 0 at all %d KN points (all 4 components of the 3-form; bit-rule star on the frame 1-jet, F = dA 1-jet from F2\'s 2-jet potential)' % len(pts))
    chk('bit', ok2, 'nabla^a F_ab = 0 at all %d points (A3 omega, the engine\'s D_covector through g2_hodge.D_two_index, frame_divergence_at0)' % len(pts))
    chk('std', okS, '[std] plain derivatives: det g = -1 as a 1-jet (Kerr-Schild) and d_mu F^{mu nu} = 0 at all %d points (g = e^T eta e, series inverse, no engine)' % len(pts))
    chk('bit==std', okB, 'the engine\'s *F at the point = (1/2) sqrt(-g) eps_{mu nu rho sigma} F^{rho sigma} with eps_0123 = +1 (std), %d nonzero components over the 10 points' % nstar)
    chk('bit', all(v != 0 for v in pf), 'the Pfaffian F_01 F_23 - F_02 F_13 + F_03 F_12 (frame components) is nonzero at all 10 points (E.B != 0: F_ab invertible): %s' % ', '.join(str(x) for x in pf[:3]) + ', ...')
    tick('part 1')

    head('Part 2. E_a(c = 0) = kappa tau_a with B3\'s variational stress (L_A = -(1/2) F^*F), kappa = 4 s/Q^2, no fit, all 16 components')
    okE = True; kaps = set()
    for (M, a, Q, kap, s, P) in pts:
        e, E, _, data = K14.kn_frame_jet(P['p'], M, a, s, P['r']); A = K14.kn_potential(Q, data)
        comp, kt = einstein_tau(Gv, S, e, A, 4 * s / (Q * Q)); okE &= comp == kt and any(comp.values()); kaps.add(4 * s / (Q * Q))
    chk('bit', okE, 'E_a = kappa tau_a on all 16 components at all 10 points with kappa = 4 s/Q^2 in %s (F2\'s s = kappa Q^2/4; B3\'s stress by variation, not the g2_hodge formula)' % sorted(kaps))
    tick('part 2')

    head('Part 3. The Noether chain (frame 3-jets, own KN builder): E_a = kappa tau_a as 1-jets, D E_a = 0, D tau_a = (i_a F)^EL_A, so (i_a F)^d*F = 0; invertible where Pf != 0')
    for (M, a, Q, kap, s, P) in [pts[0], pts[4], pts[8]]:
        e3, E3, A3, d3 = kn_jets(P['p'], M, a, s, P['r'], Q, order=3)
        e2, E2, _, data = K14.kn_frame_jet(P['p'], M, a, s, P['r']); A2 = K14.kn_potential(Q, data)
        same = all(jet(e3[x].get(1 << mu, {}), 4, 2) == e2[x].get(1 << mu, {}) for x in range(4) for mu in range(4)) and all(jet(A3.get(1 << mu, {}), 4, 2) == A2.get(1 << mu, {}) for mu in range(4))
        nc = noether_chain(Gv, S, e3, A3, F(kap)); dM = det4(nc['M'])
        tag = '(M, a, Q, kappa) = (%s, %s, %s, %s), r = %s' % (M, a, Q, kap, P['r'])
        chk('bit', same, '%s: the own 3-jet KN builder truncated at degree 2 equals F2\'s kn_frame_jet and kn_potential (every jet coefficient)' % tag)
        chk('bit', nc['same1'] and nc['nz1'] > 0, '%s: E_a = kappa tau_a as 1-jets (every coefficient of x-degree <= 1; %d nonzero first-order coefficients of E_a)' % (tag, nc['nz1']))
        chk('bit', all(v == 0 for v in nc['DE0']) and nc['lhs'] == nc['rhs'], '%s: D E_a = 0 at the point (T = 0) and B3\'s D tau_a = (i_a F)^EL_A at the point; hence (i_a F)^EL_A = 0 for a = 0..3' % tag)
        chk('bit', dM != 0 and all(v == 0 for v in nc['j']) and all(v == 0 for v in nc['rhs']), '%s: the map J -> ((i_a F)^J)_a has det = %s != 0, so EL_A = -d*F = 0 at the point is forced' % (tag, dM))
    # RN (a = 0): the Pfaffian vanishes
    M, Q, kap = F(3, 2), F(2), 1; s = F(kap) * Q * Q / 4; P = GK.rational_kerr_points(0, [7], K14.ANG[:1])[0]
    e3, E3, A3, d3 = kn_jets(P['p'], M, 0, s, P['r'], Q, order=3); nc = noether_chain(Gv, S, e3, A3, F(kap))
    rk = rank_exact(nc['M']); dM = det4(nc['M'])
    chk('bit', nc['same1'] and dM == 0 and rk == 2 and all(v == 0 for v in nc['DE0']), 'RN (a = 0, M = 3/2, Q = 2, kappa = 1, rho = 7): E_a = kappa tau_a as 1-jets, but det = 0 and rank 2 (F purely electric, Pf = 0): '
        'the Noether identity alone forces only 2 of the 4 components of the current; the implication needs E.B != 0')
    tick('part 3')

    head('Part 4. Controls and the Gauss flux')
    P0 = pts[0]; M, a, Q, kap, s, P = P0; e, E, _, data = K14.kn_frame_jet(P['p'], M, a, s, P['r'])
    _, _, _, data_m = K14.kn_frame_jet(P['p'], M, a, s, P['r'], a_l=-a)
    for name, A in (('A with r^2 instead of r^3 in the numerator', pot_from(data, Q, power=2)), ('A built on the opposite rotation (a -> -a in l of A only)', pot_from(data, Q, l=data_m['l_dn']))):
        dstar, div, _, _ = maxwell_point(Gv, S, e, E, A); comp, kt = einstein_tau(Gv, S, e, A, F(kap))
        chk('ctl', bool(dstar) and any(v != 0 for v in div) and comp != kt, '%s (M, a, Q) = (%s, %s, %s), r = %s: d*F != 0, nabla^a F_ab != 0 and E_a != kappa tau_a (ok)' % (name, M, a, Q, P['r']))
    A = K14.kn_potential(Q, data); comp, kt = einstein_tau(Gv, S, e, A, F(kap), sA=-1)
    chk('ctl', comp != kt, 'the matter action with the wrong sign (+(1/2) F^*F, i.e. Q -> -Q in one of the two factors): E_a != kappa tau_a (ok)')
    eS, ES, _, dS = K14.kn_frame_jet(P['p'], M, a, -s, P['r']); AS = K14.kn_potential(Q, dS); dstar, div, _, _ = maxwell_point(Gv, S, eS, ES, AS); comp, kt = einstein_tau(Gv, S, eS, AS, F(kap))
    chk('ctl', comp != kt and not dstar and all(v == 0 for v in div), 's -> -s in the frame (f = (M r + s) r^2/(..)): E_a != kappa tau_a (ok), while d*F = 0 still holds: Maxwell on this Kerr-Schild family does not fix s')
    eK, EK, _, dK = K14.kn_frame_jet(P['p'], M, a, 0, P['r']); AK = K14.kn_potential(Q, dK); dstar, div, _, _ = maxwell_point(Gv, S, eK, EK, AK)
    chk('bit', not dstar and all(v == 0 for v in div), 'the KN potential also solves Maxwell on the uncharged Kerr frame (s = 0) at this point: d*F = 0 does not read M or s (test field)')
    Am = {m: scale(p, -1) for m, p in K14.kn_potential(Q, data).items()}; dstar, div, _, _ = maxwell_point(Gv, S, e, E, Am); comp, kt = einstein_tau(Gv, S, e, Am, F(kap))
    chk('bit', not dstar and comp == kt, 'Q -> -Q in A alone is a symmetry (d*F linear, tau quadratic in F, s = kappa Q^2/4 even): it cannot serve as a failing control')
    tick('part 4a')
    for (M, a, Q, s, R0) in ((5.0, 1.0, 4.0, 4.0, 9.0), (5.0, 1.0, 4.0, 4.0, 20.0), (3.5, 2.0, 2.0, 1.0, 6.0)):
        fl = kn_flux(M, a, s, Q, R0)
        chk('std', abs(fl + 4 * math.pi * Q) < 1e-6 * 4 * math.pi * Q, '[std floats] Gauss flux of *F through t = 0, r = %g (M, a, Q) = (%g, %g, %g): %.9f = -4 pi Q = %.9f (40 x 48 nodes, five-point differences)' % (R0, M, a, Q, fl, -4 * math.pi * Q))
    tick('part 4')
    finish('F2-M')

if __name__ == '__main__': main()
