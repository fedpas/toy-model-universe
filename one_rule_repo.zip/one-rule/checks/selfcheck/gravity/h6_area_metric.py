#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H6 (test 2).  The area-metric closure of general linear electrodynamics (closure paper sect. V C, pp. 40-42): what exact linear algebra on the
 21 cells can say without the solved closure.
      python3 h6_area_metric.py
 Part A [std]: the induced-geometry blocks (121)-(123) against H2's cell classes (vertex D, edge E, antipodal A on the six plane labels of H1/H2):
   g1^{ab} = -G^{0a0b} (6 cells = 3 D + 3 E), g2_{ab} from the spatial planes (6 = 3 D + 3 E), g3_{ab} from G^{0abc} (9 = 3 A + 6 E);
   eps_{abcd} G^{abcd} = 4 eps_{mkl} G^{0mkl} = 8 (G^{0123} - G^{0213} + G^{0312}) for a pair-symmetric G (eps_{0123} = 1); the trace frame condition
   g1^{ab} g3_{ab} = 0 of (124) is (1/24) eps.G = sqrt(det g1) (exact here); the four frame conditions have rank 4 on the nine
   entries of g3, so 27 - 6 (symmetry) - 4 (frame) = 21 - 4 = 17 = 6 + 6 + 5 configuration variables (125).
 Part B [std]: the principal polynomial (120) on the background G = 2 eta^{a[c} eta^{d]b} + alpha eps^{abcd} (the p. 20 background of Schuller's review Constructive Gravity, arXiv:2003.09726, has
   alpha = -1): eps.G = 24 alpha, and P(k) = P^{ijkl} k_i k_j k_k k_l is a constant times (eta^{ab} k_a k_b)^2 exactly: the quartic is the square of the
   metric's quadratic, its reduced polynomial (repeated factor removed, p. 12) is k^2, and the normalisation P^{0000} = 1 of (46) forces |alpha| = 1,
   i.e. |eps.G| = 24 (LNS-013).  Controls: a G without the pair symmetry; a G with one Weyl-type cell shifted (P is no longer a square); the printed
   prefactor changed.  Nothing here uses the engine: the eight engine faults are invisible to this script (the analogues are the controls)."""
import sys, os, time, itertools, random
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import chk, head, finish
from g2_weyl import PAIRS4, PIDX, SYM21, cell_class

ETA = [1, -1, -1, -1]
def eps4(a, b, c, d):
    p = (a, b, c, d)
    if len(set(p)) < 4: return 0
    s = 1
    for i in range(4):
        for j in range(i + 1, 4):
            if p[i] > p[j]: s = -s
    return s
def eps3(a, b, c): return eps4(0, a + 1, b + 1, c + 1)   # eps_{0 mu kappa lambda} = eps_{mu kappa lambda}, spatial indices 1..3 stored as 0..2

def G_from_cells(S):
    """G^{abcd} from the 21 cells S[(A, B)] (A <= B plane labels): G^{abcd} = sign(ab) sign(cd) S_{AB}, antisymmetric in each pair, pair-symmetric."""
    G = [[[[F(0)] * 4 for _ in range(4)] for _ in range(4)] for _ in range(4)]
    for a in range(4):
        for b in range(4):
            if a == b: continue
            A, sa = (PIDX[(a, b)], 1) if a < b else (PIDX[(b, a)], -1)
            for c in range(4):
                for d in range(4):
                    if c == d: continue
                    B, sb = (PIDX[(c, d)], 1) if c < d else (PIDX[(d, c)], -1)
                    key = (A, B) if A <= B else (B, A)
                    G[a][b][c][d] = sa * sb * S[key]
    return G

def epsG(G): return sum(eps4(a, b, c, d) * G[a][b][c][d] for a in range(4) for b in range(4) for c in range(4) for d in range(4))

def det3(M):
    return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))
def inv3(M):
    d = det3(M); C = [[None] * 3 for _ in range(3)]
    for i in range(3):
        for j in range(3):
            m = [[M[r][c] for c in range(3) if c != j] for r in range(3) if r != i]
            C[j][i] = (m[0][0] * m[1][1] - m[0][1] * m[1][0]) * ((-1) ** (i + j)) / d
    return C
def rank_exact(rows):
    rows = [list(r) for r in rows]; rk = 0; ncol = len(rows[0]) if rows else 0
    for c in range(ncol):
        piv = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if piv is None: continue
        rows[rk], rows[piv] = rows[piv], rows[rk]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c] / rows[rk][c]; rows[i] = [x - f * y for x, y in zip(rows[i], rows[rk])]
        rk += 1
    return rk

def blocks(G, sqrt_det_g1):
    """(121)-(123) in the coordinate frame: g1^{ab} = -G^{0a0b}; g2_{ab} = (1/4)(1/det g1) eps_{amn} eps_{brs} G^{mnrs}; g3_{ab} = (g1^-1)_{am}((1/2)(det g1)^{-1/2} eps_{bkl} G^{0mkl} - delta^m_b)."""
    g1 = [[-G[0][a + 1][0][b + 1] for b in range(3)] for a in range(3)]
    d1 = det3(g1); assert sqrt_det_g1 * sqrt_det_g1 == d1
    g2 = [[F(1, 4) / d1 * sum(eps3(a, m, n) * eps3(b, r, s) * G[m + 1][n + 1][r + 1][s + 1] for m in range(3) for n in range(3) for r in range(3) for s in range(3)) for b in range(3)] for a in range(3)]
    g1i = inv3(g1)
    h = [[F(1, 2) / sqrt_det_g1 * sum(eps3(b, k, l) * G[0][m + 1][k + 1][l + 1] for k in range(3) for l in range(3)) for b in range(3)] for m in range(3)]
    g3 = [[sum(g1i[a][m] * (h[m][b] - (1 if m == b else 0)) for m in range(3)) for b in range(3)] for a in range(3)]
    return g1, g2, g3, h

def P_quartic(G, k):
    """(120): P(k) = -(1/24) ((1/24) eps.G)^{-2} eps_{mnpq} eps_{rstu} G^{mnri} G^{jpsk} G^{lqtu} k_i k_j k_k k_l (the symmetrisation is automatic under k^4)."""
    perms = [(p, eps4(*p)) for p in itertools.permutations(range(4))]
    Gk1 = [[[sum(G[m][n][r][i] * k[i] for i in range(4)) for r in range(4)] for n in range(4)] for m in range(4)]       # G^{mnr.} k
    Gk2 = [[sum(G[j][p][s][kk] * k[j] * k[kk] for j in range(4) for kk in range(4)) for s in range(4)] for p in range(4)]  # k G^{.ps.} k
    Gk3 = [[[sum(G[l][q][t][u] * k[l] for l in range(4)) for u in range(4)] for t in range(4)] for q in range(4)]       # k G^{.qtu}
    tot = F(0)
    for (m, n, p, q), s1 in perms:
        for (r, s, t, u), s2 in perms:
            tot += s1 * s2 * Gk1[m][n][r] * Gk2[p][s] * Gk3[q][t][u]
    eG = epsG(G)
    return -F(1, 24) * tot / ((eG / 24) ** 2)

def eta_kk(k): return sum(ETA[a] * k[a] * k[a] for a in range(4))

def main():
    rng = random.Random(11); t0 = time.time()
    head('H6 test 2, part A: the induced-geometry blocks (121)-(123) against the cell classes [std]')
    cells_g1 = [(PIDX[(0, a)], PIDX[(0, b)]) for a in range(1, 4) for b in range(a, 4)]
    cells_g2 = [(A, B) for (A, B) in SYM21 if 0 not in PAIRS4[A] and 0 not in PAIRS4[B]]
    cells_g3 = [(A, B) for (A, B) in SYM21 if (0 in PAIRS4[A]) != (0 in PAIRS4[B])]
    cnt = lambda cells: {c: sum(1 for x in cells if cell_class(*x) == c) for c in 'DEA'}
    c1, c2, c3 = cnt(cells_g1), cnt(cells_g2), cnt(cells_g3)
    chk('std', len(cells_g1) + len(cells_g2) + len(cells_g3) == 21 and set(cells_g1 + cells_g2 + cells_g3) == set(SYM21), 'the 21 cells split 6 (g1: planes 0a with 0b) + 6 (g2: spatial planes) + 9 (g3: 0a with bc) = %d + %d + %d' % (len(cells_g1), len(cells_g2), len(cells_g3)))
    chk('std', c1 == {'D': 3, 'E': 3, 'A': 0} and c2 == {'D': 3, 'E': 3, 'A': 0} and c3 == {'D': 0, 'E': 6, 'A': 3}, 'classes: g1 = %s, g2 = %s, g3 = %s (3D+3E, 3D+3E, 3A+6E)' % (c1, c2, c3))
    for trial in range(3):
        A = [[F(rng.randint(-2, 2)) for _ in range(3)] for _ in range(3)]
        if det3(A) == 0: A[0][0] += 3
        S = {c: F(rng.randint(-5, 5), rng.choice([1, 2, 3])) for c in SYM21}
        for a in range(1, 4):
            for b in range(a, 4): S[(PIDX[(0, a)], PIDX[(0, b)])] = -sum(A[a - 1][k] * A[b - 1][k] for k in range(3))   # g1 = A A^T: det a square
        G = G_from_cells(S); eG = epsG(G)
        e0 = 4 * sum(eps3(m, k, l) * G[0][m + 1][k + 1][l + 1] for m in range(3) for k in range(3) for l in range(3))
        anti = 8 * (G[0][1][2][3] - G[0][2][1][3] + G[0][3][1][2])
        chk('std', eG == e0 == anti, 'trial %d: eps.G = %s = 4 eps_{mkl} G^{0mkl} = 8 (G^{0123} - G^{0213} + G^{0312}) (only the three antipodal cells enter; LNS-013)' % (trial, eG))
        sd = abs(det3(A))
        g1, g2, g3, h = blocks(G, sd)
        tr = sum(g1[a][b] * g3[a][b] for a in range(3) for b in range(3))
        chk('std', sd * (tr + 3) * 8 == eG, 'trial %d: sqrt(det g1) (g1^{ab} g3_{ab} + 3) = eps.G / 8, so the trace frame condition g1.g3 = 0 of (124) is (1/24) eps.G = sqrt(det g1) (here sqrt(det g1) = %s, eps.G = %s)' % (trial, sd, eG))
        chk('std', all(g1[a][b] == g1[b][a] for a in range(3) for b in range(3)) and all(g2[a][b] == g2[b][a] for a in range(3) for b in range(3)), 'trial %d: g1 and g2 are symmetric automatically (pair symmetry of G): the 6 symmetry conditions of (124) cost nothing beyond the 21' % trial)
        # the four frame conditions as linear conditions on the nine entries of g3 at fixed g1: antisymmetric part (3) and trace (1): rank 4
        rows = []
        for (a, b) in ((0, 1), (0, 2), (1, 2)):
            r = [F(0)] * 9; r[3 * a + b] += 1; r[3 * b + a] -= 1; rows.append(r)
        rows.append([g1[a][b] for a in range(3) for b in range(3)])
        chk('std', rank_exact(rows) == 4, 'trial %d: the four frame conditions g3_{[ab]} = 0, g1^{ab} g3_{ab} = 0 have rank 4 on the 9 entries of g3: 9 - 4 = 5, and 27 - 6 - 4 = 21 - 4 = 17 = 6 + 6 + 5 (125)' % trial)
    # control: without the pair symmetry the position of the index 0 matters
    T = [[[[F(0)] * 4 for _ in range(4)] for _ in range(4)] for _ in range(4)]
    for a in range(4):
        for b in range(a + 1, 4):
            for c in range(4):
                for d in range(c + 1, 4):
                    v = F(rng.randint(-5, 5))
                    T[a][b][c][d] = v; T[b][a][c][d] = -v; T[a][b][d][c] = -v; T[b][a][d][c] = v
    e_full = epsG(T); e_pos0 = 4 * sum(eps3(m, k, l) * T[0][m + 1][k + 1][l + 1] for m in range(3) for k in range(3) for l in range(3))
    chk('ctl', e_full != e_pos0 and any(T[a][b][c][d] != T[c][d][a][b] for a in range(4) for b in range(4) for c in range(4) for d in range(4)), 'control: a 4-tensor antisymmetric in each pair but NOT pair-symmetric: eps.T = %s != 4 eps_{mkl} T^{0mkl} = %s (the factor 4 needs G^{abcd} = G^{cdab})' % (e_full, e_pos0))
    print('  part A: %.1f s' % (time.time() - t0)); t0 = time.time()

    head('H6 test 2, part B: the quartic (120) on G = 2 eta^{a[c} eta^{d]b} + alpha eps^{abcd} [std]')
    def background(alpha):
        G = [[[[F(0)] * 4 for _ in range(4)] for _ in range(4)] for _ in range(4)]
        for a in range(4):
            for b in range(4):
                for c in range(4):
                    for d in range(4):
                        G[a][b][c][d] = F((ETA[a] if a == c else 0) * (ETA[b] if b == d else 0) - (ETA[a] if a == d else 0) * (ETA[b] if b == c else 0)) + alpha * eps4(a, b, c, d)
        return G
    ks = [[F(1), F(0), F(0), F(0)], [F(5), F(3), F(4), F(0)], [F(13), F(3), F(4), F(12)], [F(2), F(1), F(-1), F(3)], [F(1, 2), F(-2), F(3, 5), F(1)], [F(0), F(1), F(2), F(-2)]]
    for alpha in (F(1), F(-1), F(3, 2)):
        G = background(alpha); eG = epsG(G)
        chk('std', eG == 24 * alpha, 'alpha = %s: eps.G = %s = 24 alpha (the pure metric part contributes 0; |eps.G| = 24 iff |alpha| = 1)' % (alpha, eG))
        consts = []
        for k in ks:
            P = P_quartic(G, k); q = eta_kk(k)
            if q != 0: consts.append(P / (q * q))
            else: chk('std', P == 0, 'alpha = %s: null k = %s: P(k) = 0 (a null covector of the metric is null for the quartic)' % (alpha, [str(x) for x in k]))
        chk('std', len(set(consts)) == 1, 'alpha = %s: P(k) / (eta k k)^2 = %s at %d non-null rational k (the quartic is the square of the quadratic times a constant; alpha^-2 = %s)' % (alpha, consts[0], len(consts), 1 / (alpha * alpha)))
        P0 = P_quartic(G, ks[0])
        chk('std', P0 == consts[0], 'alpha = %s: P^{0000} = P(epsilon^0) = %s; the normalisation p = 1 of (46), (98) holds iff this is 1' % (alpha, P0))
    G = background(F(1)); g1, g2, g3, h = blocks(G, F(1))
    chk('std', epsG(G) == 24 and det3(g1) == 1 and all(g3[a][b] == 0 for a in range(3) for b in range(3)), 'alpha = +1: det g1 = 1, (1/24) eps.G = 1 = sqrt(det g1) and g3 = 0: the paper\'s frame condition (124) holds with alpha = +1; the review\'s background (p. 20) has alpha = -1, i.e. eps.G = -24 (orientation convention of eps^{abcd})')
    # controls
    Gp = background(F(1))
    # shift one Weyl-type cell: the symmetric trace-free combination S_{01,01} - S_{02,02} (vertex cells) keeps the pair symmetry
    cells = {c: F(0) for c in SYM21}
    for (A, B) in SYM21:
        a, b = PAIRS4[A]; c, d = PAIRS4[B]
        cells[(A, B)] = Gp[a][b][c][d]
    cells[(0, 0)] += F(1, 3); cells[(1, 1)] -= F(1, 3)
    Gw = G_from_cells(cells)
    consts = []
    for k in ks:
        q = eta_kk(k)
        if q != 0: consts.append(P_quartic(Gw, k) / (q * q))
    chk('ctl', len(set(consts)) > 1, 'control: one Weyl-type shift of the cells (S_0101 - S_0202 by 1/3): P(k)/(eta k k)^2 takes %d different values at %d covectors (no longer a square of the metric form)' % (len(set(consts)), len(consts)))
    nulls = [[F(5), F(3), F(4), F(0)], [F(13), F(3), F(4), F(12)], [F(3), F(1), F(2), F(2)], [F(7), F(2), F(3), F(6)], [F(9), F(4), F(4), F(7)]]
    Pn = [P_quartic(Gw, k) for k in nulls]
    chk('ctl', any(x != 0 for x in Pn), 'control: the same G at five null covectors of eta: P = %s (not all zero: the null cone has moved; at (5,3,4,0) it has not: the shift S_0101 - S_0202 leaves that direction null)' % [str(x) for x in Pn])
    G = background(F(1)); P0 = P_quartic(G, ks[0])
    chk('ctl', -P0 < 0 < P0, 'control: the minus sign of the prefactor of (120) is what gives P(epsilon^0) = +1 > 0; without it P(epsilon^0) = %s < 0, against the sign convention P(x, C_x) > 0 of (31)' % (-P0))
    print('  part B: %.1f s' % (time.time() - t0))
    finish('H6-2')

if __name__ == '__main__': main()
