#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Shared parts of the gravity check scripts of this folder (A3, A4, D1, H3, B1, C1 and the steps that import it).  Exact fractions, standard library for the bit-rule path.

The PROVING path is the bit-rule engine selfcheck/gravity_selfcheck.py (Forms, Lie, Grav: forms are the bit rule with null generators,
bivector and vector tables come from the Clifford product).  The STANDARD path is conventional index calculus (metric, Christoffel,
Riemann, plain linear algebra, numpy) that never touches the engine.  Log lines are labelled
    [bit]       a statement computed with the engine
    [std]       a statement computed with the conventional route
    [bit==std]  the two routes compared
    [ctl]       a control: a wrong version that must fail
The engine is the package's selfcheck/gravity_selfcheck.py, found from this file's own location (the parent of its folder)."""
import sys, os, itertools, random, math
from fractions import Fraction as F

_here = os.path.dirname(os.path.abspath(__file__))
def _find_selfcheck():
    p = os.path.dirname(_here)                                             # selfcheck/ of the package, the parent of selfcheck/gravity/
    if os.path.isfile(os.path.join(p, 'gravity_selfcheck.py')): return p
    raise SystemExit('gravity_selfcheck.py not found in ' + p + ': this file belongs in selfcheck/gravity/ of the package')
sys.path.insert(0, _find_selfcheck())
import gravity_selfcheck as gs
from gravity_selfcheck import Grav, Lie, lorentz, Forms, padd, pder, pscale, bmul, popc

# ------------------------------------------------------------------------------------------------ logging
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

# ------------------------------------------------------------------------------------------------ truncation of the engine's polynomial product
_orig_pmul = gs.pmul
_TR = {'n': None, 'xdeg': None, 'lam': None}
def _pmul(a, b):
    xd, lm, n = _TR['xdeg'], _TR['lam'], _TR['n']
    if xd is None and lm is None: return _orig_pmul(a, b)
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            k = tuple(x + y for x, y in zip(k1, k2))
            if xd is not None and sum(k[:n]) > xd: continue
            if lm is not None and k[n] > lm: continue
            x = r.get(k, 0) + v1 * v2
            if x == 0: r.pop(k, None)
            else: r[k] = x
    return r
gs.pmul = _pmul
class trunc:
    """with trunc(n, xdeg=1, lam=1): polynomial products of the engine drop monomials of x-degree > xdeg and (exponent slot n, a bookkeeping parameter) degree > lam.
    Exact for every coefficient that is kept."""
    def __init__(self, n, xdeg=None, lam='keep'): self.new = {'n': n, 'xdeg': xdeg, 'lam': lam}
    def __enter__(self):
        self.old = dict(_TR); new = dict(self.new)
        if new['lam'] == 'keep': new['lam'] = self.old['lam']
        _TR.update(new)
    def __exit__(self, *a): _TR.update(self.old)
def pm(a, b): return gs.pmul(a, b)

# ------------------------------------------------------------------------------------------------ small polynomial helpers
def const(nv, c): return {(0,) * nv: F(c)} if c != 0 else {}
def var(nv, i): return {tuple(1 if j == i else 0 for j in range(nv)): F(1)}
def at0(p, nv): return p.get((0,) * nv, F(0))
def at_lam(p, n, nv, k):
    """coefficient of x^0 lam^k (the bookkeeping parameter is the exponent slot n)"""
    return p.get((0,) * n + (k,) * (nv - n), F(0))
def lin(*terms):
    r = {}
    for c, p in terms: r = padd(r, p, c)
    return r
def scale(p, c): return {k: v * c for k, v in p.items()} if c != 0 else {}
def deg_part(p, d, n): return {k: v for k, v in p.items() if sum(k[:n]) == d}
def shift_poly(P, p, nv):
    """P(x) re-expanded around the point p: exact polynomial in delta = x - p (p a list of Fractions for the first len(p) variables)"""
    out = {}
    for k, v in P.items():
        term = const(nv, v)
        for i in range(len(p)):
            base = lin((F(1), const(nv, p[i])), (F(1), var(nv, i)))
            for _ in range(k[i]): term = _orig_pmul(term, base)
        for i in range(len(p), nv):                                # bookkeeping slots untouched
            if k[i]: term = _orig_pmul(term, {tuple(k[i] if j == i else 0 for j in range(nv)): F(1)})
        out = padd(out, term)
    return out

# ------------------------------------------------------------------------------------------------ exact linear algebra
def det_inv(Mx):
    n = len(Mx); A = [r[:] + [F(int(i == j)) for j in range(n)] for i, r in enumerate(Mx)]; det = F(1)
    for c in range(n):
        p = next((i for i in range(c, n) if A[i][c] != 0), None)
        if p is None: return F(0), None
        if p != c: A[c], A[p] = A[p], A[c]; det = -det
        det *= A[c][c]; inv = 1 / A[c][c]; A[c] = [x * inv for x in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return det, [r[n:] for r in A]
def solve_exact(rows, rhs):
    m, nvar = len(rows), len(rows[0]); M = [r[:] + [b] for r, b in zip(rows, rhs)]; piv = []; r = 0
    for c in range(nvar):
        p = next((i for i in range(r, m) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(m):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
        if r == m: break
    consistent = all(M[i][nvar] == 0 for i in range(r, m)); w = [F(0)] * nvar
    for i, c in enumerate(piv): w[c] = M[i][nvar]
    return (w if consistent else None), r, nvar, consistent
def rank_exact(rows):
    M = [r[:] for r in rows]; rk = 0; ncols = len(M[0]) if M else 0
    for c in range(ncols):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]
        for i in range(rk + 1, len(M)):
            if M[i][c] != 0:
                f = M[i][c] / M[rk][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        rk += 1
    return rk

# ------------------------------------------------------------------------------------------------ frames
def rand_frame(rng, n, deg=2, coef=3, density=.55, nv=None):
    """a random polynomial coframe e^a = e^a_mu(x) dx^mu with e0 invertible. Returns forms: [ {1<<mu: poly} ]"""
    nv = nv or n
    mons = [ex for ex in itertools.product(range(deg + 1), repeat=n) if 0 < sum(ex) <= deg]
    while True:
        e0 = [[F(rng.randint(-coef, coef)) for _ in range(n)] for _ in range(n)]
        if det_inv(e0)[0] != 0: break
    e = []
    for a in range(n):
        form = {}
        for mu in range(n):
            p = {(0,) * nv: e0[a][mu]} if e0[a][mu] != 0 else {}
            for ex in mons:
                if rng.random() < density:
                    c = F(rng.randint(-coef, coef))
                    if c: p[tuple(ex) + (0,) * (nv - n)] = c
            if p: form[1 << mu] = p
        e.append(form)
    return e
def frame_matrix(e, n): return [[e[a].get(1 << mu, {}) for mu in range(n)] for a in range(n)]
def translate_frame(e, p, nv):
    return [{m: shift_poly(pp, p, nv) for m, pp in form.items()} for form in e]

# matrices of polynomials (used for the inverse frame as a series)
def pmat_mul(A, B, nv):
    r, k, c = len(A), len(B), len(B[0]); out = [[{} for _ in range(c)] for _ in range(r)]
    for i in range(r):
        for j in range(c):
            t = {}
            for l in range(k):
                if A[i][l] and B[l][j]: t = padd(t, pm(A[i][l], B[l][j]))
            out[i][j] = t
    return out
def inverse_series(M, n, nv, deg):
    """M[a][mu] polynomials (an invertible constant term). Returns E[mu][a] with E.M = 1 up to total x-degree deg (Neumann series). Needs trunc(n, xdeg>=deg) active."""
    M0 = [[at0(M[a][mu], nv) for mu in range(n)] for a in range(n)]
    det, M0inv = det_inv(M0); assert det != 0
    E0 = [[const(nv, M0inv[mu][a]) for a in range(n)] for mu in range(n)]
    if deg == 0: return E0, det
    dM = [[padd(M[a][mu], const(nv, M0[a][mu]), -1) for mu in range(n)] for a in range(n)]
    N = pmat_mul(E0, dM, nv); term = E0; E = [[dict(x) for x in row] for row in E0]
    for _ in range(deg + (_TR['lam'] or 0)):                       # x-degree plus the bookkeeping-parameter degree: N has no constant term in (x, lam) together
        term = pmat_mul(N, term, nv); term = [[scale(x, -1) for x in row] for row in term]
        if not any(x for row in term for x in row): break
        E = [[padd(E[i][j], term[i][j]) for j in range(n)] for i in range(n)]
    return E, det

# ------------------------------------------------------------------------------------------------ the torsion map L, read from the engine
def pairs_of(L):
    """for each generator index A of the Lie table: (a, b) with a < b"""
    out = []
    for g in L.gens:
        bits = [i for i in range(L.N) if g >> i & 1]; out.append((bits[0], bits[1]))
    return out
def torsion_L_engine(n, sq):
    """L[(c, d, b)][(A, mu)] with d < b: the coefficient of e^d ^ e^b in T^c = d e^c + h omega^A ^ e^b for the flat frame e = dx and omega^A = dx^mu (engine, bit rule)."""
    Lie_ = Lie(sq); Gv = Grav(n, Lie_); zero = (0,) * n
    e = [{1 << a: {zero: F(1)}} for a in range(n)]; cols = {}
    for A in range(Lie_.G):
        for mu in range(n):
            om = [{} for _ in range(Lie_.G)]; om[A] = {1 << mu: {zero: F(1)}}
            T = Gv.torsion(om, e); col = {}
            for c in range(n):
                for mask, p in T[c].items():
                    v = p.get(zero, 0)
                    if v:
                        bits = [i for i in range(n) if mask >> i & 1]; col[(c, bits[0], bits[1])] = v
            cols[(A, mu)] = col
    rows = {}
    for key, col in cols.items():
        for rk, v in col.items(): rows.setdefault(rk, {})[key] = v
    return Lie_, rows
def torsion_L_std(n, sq):
    """the same matrix from the textbook formula, plain index loops, no Clifford algebra:
    T^c_{db} = (de^c)_{db} + sq_b w^{cb}_d - sq_d w^{cd}_b  (d < b),  w^{ab} antisymmetric, w^{ab}_d the e^d-component of the connection form"""
    pairs = [(a, b) for a in range(n) for b in range(a + 1, n)]; pidx = {p: i for i, p in enumerate(pairs)}
    rows = {}
    for c in range(n):
        for d in range(n):
            for b in range(d + 1, n):
                row = {}
                if b != c:
                    key = (pidx[(min(c, b), max(c, b))], d); s = 1 if c < b else -1; row[key] = row.get(key, 0) + F(sq[b] * s)
                if d != c:
                    key = (pidx[(min(c, d), max(c, d))], b); s = 1 if c < d else -1; row[key] = row.get(key, 0) - F(sq[d] * s)
                row = {k: v for k, v in row.items() if v != 0}
                if row: rows[(c, d, b)] = row
    return rows
def koszul_S(n, sq, Lie_):
    """the closed form: omega^{ab}_c = (1/2) [ sq_b D^a_{bc} + sq_a D^b_{ca} - sq_a sq_b sq_c D^c_{ab} ]  (D^x_{yz} antisymmetric in y, z), the frame
    components of de.  Returns S[(A, c)] = {(c2, d, b): coefficient}, d < b."""
    S = {}
    def put(row, c2, y, z, coef):
        if y == z or coef == 0: return
        if y < z: key = (c2, y, z)
        else: key = (c2, z, y); coef = -coef
        row[key] = row.get(key, 0) + coef
    for A, (a, b) in enumerate(pairs_of(Lie_)):
        for c in range(n):
            row = {}
            put(row, a, b, c, F(sq[b], 2)); put(row, b, c, a, F(sq[a], 2)); put(row, c, a, b, -F(sq[a] * sq[b] * sq[c], 2))
            S[(A, c)] = {k: v for k, v in row.items() if v != 0}
    return S
def sparse_mul(A, B):
    """A[r][k] * B[k][c] for dict-of-dict sparse matrices"""
    out = {}
    for r, row in A.items():
        acc = {}
        for k, v in row.items():
            for c, w in B.get(k, {}).items(): acc[c] = acc.get(c, 0) + v * w
        acc = {c: v for c, v in acc.items() if v != 0}
        if acc: out[r] = acc
    return out
def is_scaled_identity(M, s, keys):
    for r in keys:
        row = M.get(r, {})
        if row.get(r, 0) != s: return False
        if any(c != r and v != 0 for c, v in row.items()): return False
    return True

# ------------------------------------------------------------------------------------------------ the closed-form connection on a frame (bit-rule engine for d, the tables for S)
def anholonomy(Gv, e, nv, deg):
    """frame components D^c_{db}(x) (d < b) of de^c, as polynomials truncated at x-degree deg.  Uses the engine's d, and the inverse frame as a series."""
    n = Gv.n; Fm = Gv.Fm
    with trunc(n, xdeg=deg):
        E, det = inverse_series(frame_matrix(e, n), n, nv, deg)
        Om = {}
        for c in range(n):
            de = Fm.d(e[c])
            for mu in range(n):
                for nu in range(mu + 1, n):
                    p = de.get((1 << mu) | (1 << nu), {}); Om[(c, mu, nu)] = p; Om[(c, nu, mu)] = scale(p, -1)
        D = {}
        for c in range(n):
            for d in range(n):
                for b in range(d + 1, n):
                    t = {}
                    for mu in range(n):
                        for nu in range(n):
                            if mu == nu: continue
                            p = Om[(c, mu, nu)]
                            if not p: continue
                            t = padd(t, pm(pm(E[mu][d], E[nu][b]), p))
                    D[(c, d, b)] = t
    return D, E, det
def omega_closed_form(Gv, e, S, nv, deg, sign=1, Dpre=None):
    """omega^A = sum_c w^A_c e^c with w = sign * S D.  deg = 0: constants (the value at the origin); deg = 1: first-order jet. Returns (om forms, w, D)."""
    n = Gv.n
    D, E, det = Dpre or anholonomy(Gv, e, nv, deg)
    with trunc(n, xdeg=deg):
        w = {}
        for (A, c), row in S.items():
            t = {}
            for key, coef in row.items(): t = padd(t, D[key], coef * sign)
            w[(A, c)] = t
        om = [{} for _ in range(Gv.G)]
        for A in range(Gv.G):
            for mu in range(n):
                t = {}
                for c in range(n):
                    p = w[(A, c)]; q = e[c].get(1 << mu, {})
                    if p and q: t = padd(t, pm(p, q))
                if t: om[A][1 << mu] = t
    return om, w, D

# ------------------------------------------------------------------------------------------------ pointwise solve of T = 0 (today's route; copied from gravity_new_checks.solve_torsion_free for self-containment)
def solve_torsion_free(Gv, e, order):
    n, L, G = Gv.n, Gv.L, Gv.G
    T0 = Gv.torsion([{} for _ in range(G)], e); unknowns = []
    mons = [tuple(0 for _ in range(n))] + ([tuple(1 if j == i else 0 for j in range(n)) for i in range(n)] if order >= 1 else [])
    for A in range(G):
        for mu in range(n):
            for mo in mons: unknowns.append((A, mu, mo))
    eqkeys = {}
    def key(c, mask, mo):
        k = (c, mask, mo)
        if k not in eqkeys: eqkeys[k] = len(eqkeys)
        return eqkeys[k]
    cols = []
    for (A, mu, mo) in unknowns:
        om = [{} for _ in range(G)]; om[A] = {1 << mu: {mo: F(1)}}
        T = Gv.torsion(om, e); col = {}
        for c in range(n):
            for mask, p in T[c].items():
                for ex, v in p.items():
                    if sum(ex) <= order: col[key(c, mask, ex)] = col.get(key(c, mask, ex), 0) + v
        for c in range(n):
            for mask, p in T0[c].items():
                for ex, v in p.items():
                    if sum(ex) <= order: col[key(c, mask, ex)] = col.get(key(c, mask, ex), 0) - v
        cols.append(col)
    rhs = {}
    for c in range(n):
        for mask, p in T0[c].items():
            for ex, v in p.items():
                if sum(ex) <= order: rhs[key(c, mask, ex)] = rhs.get(key(c, mask, ex), 0) - v
    neq, nvar = len(eqkeys), len(unknowns)
    rows = [[F(0)] * nvar for _ in range(neq)]
    for j, col in enumerate(cols):
        for k, v in col.items(): rows[k][j] = F(v)
    b = [F(0)] * neq
    for k, v in rhs.items(): b[k] = F(v)
    w, rank, nv_, cons = solve_exact(rows, b)
    if w is None: return None, rank, nvar, False, neq
    om = [{} for _ in range(G)]
    for val, (A, mu, mo) in zip(w, unknowns):
        if val == 0: continue
        om[A].setdefault(1 << mu, {}); om[A][1 << mu][mo] = om[A][1 << mu].get(mo, 0) + val
    return om, rank, nvar, True, neq
def torsion_zero_at0(Gv, om, e, nv):
    T = Gv.torsion(om, e)
    return all(at0(p, nv) == 0 for c in T for p in c.values())

# ------------------------------------------------------------------------------------------------ STANDARD route: metric, Christoffel, Riemann, Einstein (own tiny polynomial code, no engine)
def sp_mul(a, b, deg, n):
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            k = tuple(x + y for x, y in zip(k1, k2))
            if sum(k[:n]) > deg: continue
            r[k] = r.get(k, 0) + v1 * v2
    return {k: v for k, v in r.items() if v != 0}
def sp_add(a, b, c=1):
    r = dict(a)
    for k, v in b.items():
        x = r.get(k, 0) + c * v
        if x == 0: r.pop(k, None)
        else: r[k] = x
    return r
def sp_der(a, i):
    r = {}
    for k, v in a.items():
        if k[i]:
            kk = list(k); kk[i] -= 1; r[tuple(kk)] = r.get(tuple(kk), 0) + v * k[i]
    return {k: v for k, v in r.items() if v != 0}
def std_metric(e, n, sq, nv, deg=2):
    """g_{mu nu}(x) = sum_a sq_a e^a_mu e^a_nu, truncated at x-degree deg"""
    g = {}
    for mu in range(n):
        for nu in range(n):
            t = {}
            for a in range(n):
                p, q = e[a].get(1 << mu, {}), e[a].get(1 << nu, {})
                if p and q: t = sp_add(t, sp_mul(p, q, deg, n), sq[a])
            g[(mu, nu)] = t
    return g
def std_inverse_metric(g, n, nv, deg=1):
    g0 = [[at0(g[(a, b)], nv) for b in range(n)] for a in range(n)]
    det, g0i = det_inv(g0); assert det != 0
    dg = [[sp_add(g[(a, b)], const(nv, g0[a][b]), -1) for b in range(n)] for a in range(n)]
    C = [[const(nv, g0i[a][b]) for b in range(n)] for a in range(n)]
    N = [[{} for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            t = {}
            for l in range(n):
                if dg[l][j]: t = sp_add(t, scale(dg[l][j], g0i[i][l]))
            N[i][j] = t
    term = C; gi = [[dict(x) for x in row] for row in C]
    for _ in range(deg):
        new = [[{} for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(n):
                t = {}
                for l in range(n):
                    if N[i][l] and term[l][j]: t = sp_add(t, sp_mul(N[i][l], term[l][j], deg, n), -1)
                new[i][j] = t
        term = new; gi = [[sp_add(gi[i][j], term[i][j]) for j in range(n)] for i in range(n)]
    return {(i, j): gi[i][j] for i in range(n) for j in range(n)}, g0, g0i
def std_riemann(g, n, nv, route=1):
    """R^rho_{sigma mu nu} at the origin (MTW sign: R^rho_{sigma mu nu} = d_mu Gamma^rho_{nu sigma} - d_nu Gamma^rho_{mu sigma} + Gamma Gamma - Gamma Gamma).
    route 1: Christoffel symbols as first-order jets and their derivatives.  route 2: second derivatives of the metric,
    R_{rho sigma mu nu} = 1/2 (d_s d_m g_{rn} + d_r d_n g_{sm} - d_s d_n g_{rm} - d_r d_m g_{sn}) + g_{ab}(G^a_{sm} G^b_{rn} - G^a_{sn} G^b_{rm})"""
    gi, g0, g0i = std_inverse_metric(g, n, nv, 1)
    dg = lambda k, a, b: sp_der(g[(a, b)], k)
    Gam = {}
    for lam in range(n):
        for mu in range(n):
            for nu in range(mu, n):
                t = {}
                for s in range(n):
                    br = sp_add(sp_add(dg(mu, s, nu), dg(nu, s, mu)), dg(s, mu, nu), -1)
                    if br and gi[(lam, s)]: t = sp_add(t, sp_mul(gi[(lam, s)], br, 1, n), F(1, 2))
                Gam[(lam, mu, nu)] = t; Gam[(lam, nu, mu)] = t
    G0 = {k: at0(v, nv) for k, v in Gam.items()}
    R = {}
    if route == 1:
        for r in range(n):
            for s in range(n):
                for m in range(n):
                    for v in range(n):
                        t = at0(sp_der(Gam[(r, v, s)], m), nv) - at0(sp_der(Gam[(r, m, s)], v), nv)
                        for l in range(n): t += G0[(r, m, l)] * G0[(l, v, s)] - G0[(r, v, l)] * G0[(l, m, s)]
                        R[(r, s, m, v)] = t
        return R, g0, g0i
    ddg = lambda i, j, a, b: at0(sp_der(sp_der(g[(a, b)], i), j), nv)
    Rl = {}
    for r in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(n):
                    t = F(1, 2) * (ddg(s, m, r, v) + ddg(r, v, s, m) - ddg(s, v, r, m) - ddg(r, m, s, v))
                    for a in range(n):
                        for b in range(n):
                            t += g0[a][b] * (G0[(a, s, m)] * G0[(b, r, v)] - G0[(a, s, v)] * G0[(b, r, m)])
                    Rl[(r, s, m, v)] = t
    for r in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(n): R[(r, s, m, v)] = sum(g0i[r][a] * Rl[(a, s, m, v)] for a in range(n))
    return R, g0, g0i
def std_einstein_mixed(R, g0, g0i, n):
    """Ricci R_{sigma nu} = R^rho_{sigma rho nu}, scalar R = g^{sigma nu} R_{sigma nu}, mixed Einstein tensor G^mu_nu = g^{mu sigma} R_{sigma nu} - (1/2) R delta^mu_nu"""
    ric = [[sum(R[(r, s, r, v)] for r in range(n)) for v in range(n)] for s in range(n)]
    Rs = sum(g0i[s][v] * ric[s][v] for s in range(n) for v in range(n))
    G = [[sum(g0i[m][s] * ric[s][v] for s in range(n)) - (F(1, 2) * Rs if m == v else 0) for v in range(n)] for m in range(n)]
    return G, ric, Rs
def to_frame_mixed(Gmix, e0, E0, n):
    """G^b_a = e^b_mu G^mu_nu E^nu_a   (e0[b][mu], E0[nu][a])"""
    return [[sum(e0[b][m] * Gmix[m][v] * E0[v][a] for m in range(n) for v in range(n)) for a in range(n)] for b in range(n)]

# ------------------------------------------------------------------------------------------------ Einstein-form components and the contraction Theta
def einstein_components(Ea, n, nv):
    """E_a is an (n-1)-form: comp[(a, mu)] = coefficient (at the origin) of dx^{hat mu} = product of all dx^nu (nu != mu, increasing)"""
    full = (1 << n) - 1
    return {(a, mu): at0(Ea[a].get(full ^ (1 << mu), {}), nv) for a in range(n) for mu in range(n)}
def predicted_components(M, e0, E0, det, n, s=-1):
    """E_a = s * M^h_a Theta_h,  Theta_h = iota_{E_h}(e^0 ... e^{n-1}) = det(e) sum_mu (-1)^mu E^mu_h dx^{hat mu}"""
    return {(a, mu): s * det * (-1) ** mu * sum(M[h][a] * E0[mu][h] for h in range(n)) for a in range(n) for mu in range(n)}
def mixed_from_components(comp, e0, det, n, s=-1):
    """invert the line above:  M^b_a = (1/(s det)) sum_mu e^b_mu (-1)^mu comp[(a, mu)]   (the Einstein tensor minus Lambda, read off the engine's E_a)"""
    return [[sum(e0[b][mu] * (-1) ** mu * comp[(a, mu)] for mu in range(n)) / (s * det) for a in range(n)] for b in range(n)]
def E0_of(e, n, nv):
    e0 = [[at0(e[a].get(1 << mu, {}), nv) for mu in range(n)] for a in range(n)]
    det, E0 = det_inv(e0)
    return e0, E0, det

LORENTZ = lambda n: [1] + [-1] * (n - 1)

# ------------------------------------------------------------------------------------------------ Kerr-Schild frames with a radial function given by its 2-jet
def ks_frame_jet(p, rho0, f0, f1, f2, nv=4, fextra=None):
    """coframe e^a = dx^a - f l^a l_mu dx^mu (signature +,-,-,-) around the point p = (x, y, z), rho0 = |p| rational, as exact jets of degree 2 in delta = x - p.
    f(rho) = f0 + f1 (rho - rho0) + f2 (rho - rho0)^2 / 2.  l_mu dx^mu = dt + d rho (l_mu = (1, x/rho)), l^a = (1, -x/rho): null.
    Returns e (forms, 1<<mu keys), E (inverse coframe E[mu][a] = delta + f l^mu l_a, valid because l is null), (l_up, l_dn)."""
    n = 4; X = [None] + [var(nv, i) for i in (1, 2, 3)]
    d2 = lin(*[(F(1), sp_mul(X[i], X[i], 2, n)) for i in (1, 2, 3)])
    u = lin((F(2) / rho0 ** 2, lin(*[(p[i - 1], X[i]) for i in (1, 2, 3)])), (F(1) / rho0 ** 2, d2))
    u2 = sp_mul(u, u, 2, n)
    inv_rho = lin((1 / rho0, const(nv, 1)), (-1 / (2 * rho0), u), (F(3, 8) / rho0, u2))
    dr = lin((rho0 / 2, u), (-rho0 / 8, u2)); dr2 = sp_mul(dr, dr, 2, n)
    f = lin((f0, const(nv, 1)), (f1, dr), (f2 / 2, dr2))
    if fextra: f = lin((F(1), f), (F(1), fextra))                 # an extra polynomial in delta (degree <= 2): f with an angular dependence (control)
    xs = [None] + [lin((F(1), const(nv, p[i - 1])), (F(1), X[i])) for i in (1, 2, 3)]
    nh = [None] + [sp_mul(xs[i], inv_rho, 2, n) for i in (1, 2, 3)]
    l_up = [const(nv, 1)] + [scale(nh[i], -1) for i in (1, 2, 3)]
    l_dn = [const(nv, 1)] + [nh[i] for i in (1, 2, 3)]
    e = []; E = [[None] * 4 for _ in range(4)]
    for a in range(4):
        form = {}
        for mu in range(4):
            fl = sp_mul(sp_mul(f, l_up[a], 2, n), l_dn[mu], 2, n)
            pol = lin((F(1 if a == mu else 0), const(nv, 1)), (F(-1), fl))
            if pol: form[1 << mu] = pol
            fl2 = sp_mul(sp_mul(f, l_up[mu], 2, n), l_dn[a], 2, n)
            E[mu][a] = lin((F(1 if a == mu else 0), const(nv, 1)), (F(1), fl2))
        e.append(form)
    return e, E, (l_up, l_dn)
def sds_jets(M, H2, rho0):
    """2-jet of f = M/rho + (H2/2) rho^2 at rho0 (Schwarzschild-de Sitter for H2 > 0, anti-de Sitter for H2 < 0)"""
    return (M / rho0 + H2 * rho0 ** 2 / 2, -M / rho0 ** 2 + H2 * rho0, 2 * M / rho0 ** 3 + H2)

# ------------------------------------------------------------------------------------------------ the extended algebra (one more generator of square s) and its Killing form
def embed_k(sq_base, s, kappa, seed):
    """so-type algebra with one extra generator of square s: omega on the base bivectors, kappa e^a on B_{a, ext}.  Its curvature (the engine's R of the larger Lie table) is
    (R^{ab} + k kappa^2 e^a ^ e^b , kappa T^a); returns (k, mu) with F^{ab} - R^{ab} = k kappa^2 e^a e^b and F^{a,ext} = mu T^a  (all components, random fields)."""
    n = len(sq_base); rng = random.Random(seed); sq_ext = list(sq_base) + [s]; Lx = Lie(sq_ext); Gx = Grav(n, Lx); Lb = Lie(list(sq_base)); Gl = Grav(n, Lb); Fm = Gx.Fm
    om = [gs.rform(rng, n, 1, 1, .5) for _ in range(Gl.G)]; e = [gs.rform(rng, n, 1, 1, .5) for _ in range(n)]
    A = [{} for _ in range(Lx.G)]
    for A_, g in enumerate(Lb.gens): A[Lx.idx[g]] = om[A_]
    for a in range(n): A[Lx.idx[(1 << a) | (1 << n)]] = Fm.scale(e[a], kappa)
    Fx = Gx.curvature(A); R = Gl.curvature(om); T = Gl.torsion(om, e); ks, mus = set(), set()
    for (a, b) in itertools.combinations(range(n), 2):
        C = Lx.idx[(1 << a) | (1 << b)]; diff = Fm.add(Fx[C], R[Lb.idx[(1 << a) | (1 << b)]], -1); ee = Fm.wedge(e[a], e[b])
        if any(ee.values()):
            m0 = next(m for m, pp in ee.items() if pp); k0 = next(iter(ee[m0])); k = diff.get(m0, {}).get(k0, 0) / ee[m0][k0]
            assert all(not v for v in Fm.add(diff, ee, -k).values()), 'F^{ab} - R^{ab} is not proportional to e^a e^b'; ks.add(k / kappa ** 2)
        else: assert all(not v for v in diff.values())
    for a in range(n):
        C = Lx.idx[(1 << a) | (1 << n)]
        if any(T[a].values()):
            m0 = next(m for m, pp in T[a].items() if pp); k0 = next(iter(T[a][m0])); mu = Fx[C].get(m0, {}).get(k0, 0) / T[a][m0][k0]
            assert all(not v for v in Fm.add(Fx[C], T[a], -mu).values()), 'F^{a,ext} is not proportional to the torsion'; mus.add(mu)
    assert len(ks) == 1 and len(mus) == 1, (ks, mus)
    return next(iter(ks)), next(iter(mus))
def killing_signature(Lie_):
    """(positive, negative, zero) counts of the Killing form tr(ad X ad Y) of the bivector algebra of the Lie table (exact: the form is diagonal in the bivector basis)"""
    G = Lie_.G; ad = [[[F(0)] * G for _ in range(G)] for _ in range(G)]
    for (A, B), (C, c) in Lie_.f.items(): ad[A][C][B] += F(c)
    K = [[sum(ad[A][i][j] * ad[B][j][i] for i in range(G) for j in range(G)) for B in range(G)] for A in range(G)]
    diag = all(K[i][j] == 0 for i in range(G) for j in range(G) if i != j)
    if diag: d = [K[i][i] for i in range(G)]; return (sum(1 for x in d if x > 0), sum(1 for x in d if x < 0), sum(1 for x in d if x == 0)), True
    import numpy as np
    ev = np.linalg.eigvalsh(np.array([[float(x) for x in r] for r in K])); return (int((ev > 1e-9).sum()), int((ev < -1e-9).sum()), int((abs(ev) <= 1e-9).sum())), False
def clifford_square(sq, vec_polys, nvars):
    """(sum_A v_A gamma_A)^2 for generators with squares sq and polynomial coefficients v_A (bit rule product); returns {mask: poly}"""
    out = {}
    for A, pa in vec_polys.items():
        for B, pb in vec_polys.items():
            m, sgn = bmul(1 << A, 1 << B, sq)
            if sgn == 0: continue
            out[m] = padd(out.get(m, {}), _orig_pmul(pa, pb), sgn)
    return {m: p for m, p in out.items() if p}

# ------------------------------------------------------------------------------------------------ engine helpers shared by the step scripts
def engine_om_R(Gv, e, S, n):
    """[bit] omega (A3 closed form, first-order jet) and the engine's curvature R = d omega + 1/4 [omega, omega] (jets, x-degree <= 1)"""
    om = omega_closed_form(Gv, e, S, n, 1)[0]
    with trunc(n, xdeg=1): R = Gv.curvature(om)
    return om, R
def engine_E_from_R(Gv, e, R, n, c):
    """[bit] the components of the Einstein form E_a(c) at the origin of the jets"""
    with trunc(n, xdeg=1): Ea, _ = Gv.einstein(None, e, R, F(c))
    return einstein_components(Ea, n, n)
def Rab_at0(Gv, R, n):
    Rab = {}
    for A, (a, b) in enumerate(pairs_of(Gv.L)):
        for mu in range(n):
            for nu in range(mu + 1, n):
                v = at0(R[A].get((1 << mu) | (1 << nu), {}), n)
                Rab[(a, b, mu, nu)] = v; Rab[(b, a, mu, nu)] = -v; Rab[(a, b, nu, mu)] = -v; Rab[(b, a, nu, mu)] = v
    return Rab
