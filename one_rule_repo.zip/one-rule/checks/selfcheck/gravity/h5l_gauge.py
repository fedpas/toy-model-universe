#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H5L-gauge.  The sign of lam in the so(2,4) connection omega J + e (P + lam K) is invariant under the constant group elements that keep this form; its size is not.   python3 h5l_gauge.py

 The ladder of h5l_conformal.py (J_ab = X_ab, P_a = g_a eps/2, K_a = g_a o/2, D = eps^o/2; eps = g4 + g5, o = (g4 - g5)/2) on the (anti-)de Sitter frames of h5l_frames.py:
 the connection is A = omega J + e^a (P_a + lam K_a) with lam = -H2/2 (the Schouten part f = lam e), flat in so(2,4); lam < 0 is de Sitter (J + (P + lam K) = so(1,4)),
 lam > 0 anti-de Sitter (so(2,3)).  A constant group element g acts by A -> Ad(g) A.
   [bit]  the engine's f table (Conf.br, Ad_exp, curvature6), the bit rule's product (bmul) for the map that a rational O(2,4) matrix induces on the 15 bivectors,
          the frames and omega of h5l_frames.py (engine_data), exact fractions; the Killing signature of the subalgebra spanned by the values of A, exact (congruence).
   [std]  the 6 x 6 so(2,4) matrices of std_gens conjugated by the same rational matrices (exact); scipy expm(sigma D) in floats at sigma = ln 2, ln 3, -ln 2;
          the Killing form of the subalgebra from 6 x 6 matrices alone, signature by numpy eigenvalues.
 (1) the dilatation exp(sigma D), t = e^sigma rational: the weight map (P x t, K / t) is an automorphism of the bracket table and the map induced by the boost of the (g4, g5)
     plane with cosh = (t + 1/t)/2; A -> omega J + (t e)(P + lam t^-2 K): e' = t e, lam' = lam t^-2, same sign.
 (2) the swap of the two null generators (the reflection of R^{2,4} in eps - o; det -1): P <-> K, D -> -D: A -> omega J + (lam e)(P + (1/lam) K): lam' = 1/lam, same sign.
 (3) a constant special conformal element exp(xi K) and a constant translation exp(theta P) leave the form (a D component appears); a Lorentz rotation and a boost keep it with
     lam' = lam; a dilatation with non-constant sigma(x) leaves it (the term -d sigma D); the curvature stays zero in every case (F' = Ad(g) F).
 (4) the invariant: the Killing signature of the 10-dimensional subalgebra spanned by the values of A, (4, 6, 0) for lam < 0 and (6, 4, 0) for lam > 0, is the same for the
     conjugate subalgebras Ad(g) h_lam of every element above, and the Killing form of so(2,4) is Ad-invariant on them: no conjugation takes the one sign to the other.
 Controls: a wrong dilatation weight (+2 on P) and wrong weights on K fail the bracket check and give another ratio; t = 1 is the identity; the swap twice is the identity;
 J + (P - lam K) has the swapped signature; the span of the values of A is 10-dimensional (nothing here is vacuous).
 Scope: two frames (de Sitter H2 = 1/5 at (2,3,6), rho = 7; anti-de Sitter H2 = -1/5 at (1,2,2), rho = 3), frame 3-jets, the connection as a 1-jet at the point;
 t in {2, 3, 1/2, 5/3}; xi, theta rational.  An algebra statement about one Cartan connection: nothing about which sign nature has, nothing about an action."""
import sys; sys.dont_write_bytecode = True
import time
import os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib and the h5l helpers), also under python3 -I
from b1lib import *
import numpy as np
from scipy.linalg import expm
from h5l_conformal import Conf, compose, decompose, curvature6, ftrunc, fzero, feq, Ad_exp, fit_ratio, vadd, vscale, veq, std_gens, mmul, madd, mscal, mcomm, mzero, peval
from h5l_frames import ks_frame_jetK, engine_data, dil, pt0

T0 = time.time()
TS = (F(2), F(3), F(1, 2), F(5, 3))
XI = [F(1, 3), F(-1, 2), F(2), F(1, 5)]
TH = [F(-1), F(1, 2), F(1, 3), F(2)]
FRAMES = (('de Sitter (KS, H2 = 1/5, rho = 7)', (2, 3, 6), 7, F(1, 5)), ('anti-de Sitter (KS, H2 = -1/5, rho = 3)', (1, 2, 2), 3, F(-1, 5)))

# ------------------------------------------------------------------------------------------------ rational O(2,4) matrices and the maps they induce
def eye6(): return [[F(1 if i == j else 0) for j in range(6)] for i in range(6)]
def preserves_eta(S, sq):
    eta = [[F(sq[i] if i == j else 0) for j in range(6)] for i in range(6)]; St = [[S[j][i] for j in range(6)] for i in range(6)]
    return mmul(St, mmul(eta, S)) == eta
def boost45(t):
    """the dilatation as a vector map: the boost of the (g4, g5) plane, eps -> t eps, o -> o / t"""
    c, s = (t + 1 / t) / 2, (t - 1 / t) / 2; S = eye6(); S[4][4] = c; S[5][4] = s; S[4][5] = s; S[5][5] = c; return S
def reflection(u, sq):
    """x -> x - 2 (x.u)/(u.u) u in R^{2,4} (an element of O(2,4) with det -1)"""
    uu = sum(sq[i] * u[i] * u[i] for i in range(6)); S = eye6()
    for Cc in range(6):
        for A in range(6): S[Cc][A] -= 2 * u[Cc] * sq[A] * u[A] / uu
    return S
def lorentz_rot(c, s, i, j):
    S = eye6(); S[i][i] = c; S[j][j] = c; S[i][j] = -s; S[j][i] = s; return S
def lorentz_boost(ch, sh, i, j):
    S = eye6(); S[i][i] = ch; S[j][j] = ch; S[i][j] = sh; S[j][i] = sh; return S
def expm_nilpotent(X, kmax=6):
    """exp of a nilpotent rational matrix by its (terminating) series; asserts termination"""
    N = len(X); out = eye6(); term = eye6(); fact = F(1)
    for k in range(1, kmax + 1):
        term = mmul(term, X); fact *= k
        if all(x == 0 for r in term for x in r): return out
        out = madd(out, mscal(term, 1 / fact))
    raise AssertionError('not nilpotent')
def induced_map(C, S):
    """[bit] the 15 x 15 matrix M of the map on bivectors induced by g_A -> sum_C S[C][A] g_C, computed with the bit rule's product: X_ij = g_i g_j / 2 -> (1/2) sum S[C][i] S[D][j] g_C g_D;
    the scalar part must cancel (S preserves eta); returns M with phi(X_B) = sum_A M[A][B] X_A"""
    sq = C.sq; M = [[F(0)] * C.G for _ in range(C.G)]
    for B, gB in enumerate(C.L.gens):
        i = (gB & -gB).bit_length() - 1; j = gB.bit_length() - 1; scal = F(0)
        for Cc in range(6):
            for Dd in range(6):
                coef = S[Cc][i] * S[Dd][j]
                if coef == 0: continue
                m, sg = bmul(1 << Cc, 1 << Dd, sq)
                if m == 0: scal += coef * sg
                else: M[C.L.idx[m]][B] += coef * sg                       # g_C g_D = 2 X_CD (C < D) with the sign of the bit rule, times the 1/2 of X_ij
        assert scal == 0, 'the vector map does not preserve eta'
    return M
def apply_vec(M, v): return {A: s for A in range(len(M)) for s in [sum(M[A][B] * c for B, c in v.items())] if s != 0}
def apply_forms(C, M, X):
    Fm = C.Gv.Fm; out = [{} for _ in range(C.G)]
    for A in range(C.G):
        for B in range(C.G):
            if M[A][B] != 0 and X[B]: out[A] = Fm.add(out[A], X[B], M[A][B])
    return out
def is_automorphism(C, M):
    """phi([X_A, X_B]) = [phi X_A, phi X_B] for all 15 x 15 basis pairs (engine f table)"""
    phi = lambda v: apply_vec(M, v)
    return all(veq(phi(C.br({A: F(1)}, {B: F(1)})), C.br(phi({A: F(1)}), phi({B: F(1)}))) for A in range(C.G) for B in range(C.G))
def weight_map(C, wJ, wP, wK, wD):
    """the diagonal map on the null basis with the given factors (the dilatation has 1, t, 1/t, 1)"""
    # the null basis is a basis of the 15 X's: M = V W V^-1 with V the basis matrix (columns = basis vectors in X components) and W the diagonal weights
    names = C.basis(); V = [[names[j][1].get(i, F(0)) for j in range(C.G)] for i in range(C.G)]
    det, Vi = det_inv(V); assert det != 0
    W = [[(wJ if names[i][0][0] == 'J' else wP if names[i][0][0] == 'P' else wK if names[i][0][0] == 'K' else wD) if i == j else F(0) for j in range(C.G)] for i in range(C.G)]
    return mmul(V, mmul(W, Vi))
def killing_big(C):
    """the Killing form of so(2,4) in X components from the engine's f table (exact)"""
    ad = [C.ad({A: F(1)}) for A in range(C.G)]
    return [[sum(ad[A][r][s] * ad[B][s][r] for r in range(C.G) for s in range(C.G)) for B in range(C.G)] for A in range(C.G)]

# ------------------------------------------------------------------------------------------------ subalgebras and their Killing signature (exact congruence, and numpy)
def signature_exact(B):
    """(positive, negative, zero) of a symmetric rational matrix by congruence (symmetric Gaussian elimination), exact"""
    n = len(B); M = [r[:] for r in B]; pos = neg = zero = 0
    for i in range(n):
        if M[i][i] == 0:
            j = next((j for j in range(i + 1, n) if M[j][i] != 0), None)
            if j is None: zero += 1; continue
            s = 1 if 2 * M[i][j] + M[j][j] != 0 else -1
            for k in range(n): M[i][k] += s * M[j][k]
            for k in range(n): M[k][i] += s * M[k][j]
        p = M[i][i]
        if p > 0: pos += 1
        else: neg += 1
        for j in range(i + 1, n):
            if M[j][i] != 0:
                f = M[j][i] / p
                for k in range(n): M[j][k] -= f * M[i][k]
                for k in range(n): M[k][j] -= f * M[k][i]
    return (pos, neg, zero)
def sub_killing_engine(C, basis):
    """[bit] the intrinsic Killing form of the subalgebra spanned by `basis` (15-vectors), from the engine's brackets: structure constants by an exact solve (closure asserted)"""
    m = len(basis); rows = [[basis[j].get(i, F(0)) for j in range(m)] for i in range(C.G)]; c = {}
    for i in range(m):
        for j in range(m):
            w, rank, nvar, cons = solve_exact(rows, [C.br(basis[i], basis[j]).get(r, F(0)) for r in range(C.G)]); assert cons and rank == m, 'not a subalgebra'
            c[(i, j)] = w
    K = [[sum(c[(i, k)][l] * c[(j, l)][k] for k in range(m) for l in range(m)) for j in range(m)] for i in range(m)]
    return K
def sub_killing_std(mats):
    """[std] the intrinsic Killing form of the subalgebra spanned by 6 x 6 matrices (no engine): structure constants by an exact solve on the 36 entries"""
    m = len(mats); rows = [[mats[j][r][s] for j in range(m)] for r in range(6) for s in range(6)]; c = {}
    for i in range(m):
        for j in range(m):
            w, rank, nvar, cons = solve_exact(rows, [x for r in mcomm(mats[i], mats[j]) for x in r]); assert cons and rank == m
            c[(i, j)] = w
    return [[sum(c[(i, k)][l] * c[(j, l)][k] for k in range(m) for l in range(m)) for j in range(m)] for i in range(m)]
def sig_numpy(K):
    ev = np.linalg.eigvalsh(np.array([[float(x) for x in r] for r in K])); return (int((ev > 1e-9).sum()), int((ev < -1e-9).sum()), int((abs(ev) <= 1e-9).sum()))
def h_basis(C, lam): return [C.J[pr] for pr in sorted(C.J)] + [vadd(C.P[a], C.K[a], lam) for a in range(4)]
def h_basis_std(Mst, Pm, Km, lam): return [Mst[pr] for pr in sorted(pr for pr in Mst if pr[1] < 4)] + [madd(Pm[a], Km[a], lam) for a in range(4)]
def span_rows(C, A):
    """the 15-vectors of coefficients of the 1-jet connection: one row per (coordinate index, monomial)"""
    keys = sorted(set((m, k) for X in A for m, p in X.items() for k in p))
    return [[A[B].get(m, {}).get(k, F(0)) for B in range(C.G)] for (m, k) in keys]

def read_form(C, Ap):
    """decompose a connection and read e' (P part), lam' (K part / P part, all four a, as 1-jets), the D part and whether J is untouched"""
    Fm = C.Gv.Fm; dec = decompose(C, Ap); ratios = set()
    for a in range(4):
        r = fit_ratio(Fm, dec['K'][a], dec['P'][a]); ratios.add(r)
    return dec, ratios

def main():
    print('H5L-gauge.  sign lam invariant, |lam| a dilatation gauge.  t in %s' % [str(t) for t in TS])
    C = Conf(); Fm = C.Gv.Fm; sq6 = C.sq; Mst, Pm, Km, Dm = std_gens(sq6); Kbig = killing_big(C)
    names = C.basis(); nm = {n_: v for n_, v in names}
    # ---------------------------------------------------------------------------------------- the group elements as rational matrices and the maps they induce
    head('(0) rational elements of O(2,4) and the maps they induce on the 15 bivectors (bit rule product); each is an automorphism of the engine\'s bracket table')
    elems = {}
    for t in TS: elems['dilatation t=%s' % t] = boost45(t)
    u_sw = [F(0)] * 4 + [F(1, 2), F(3, 2)]; u_sw2 = [F(0)] * 4 + [F(3, 2), F(1, 2)]            # eps - o = g4/2 + 3 g5/2 ; eps + o = 3 g4/2 + g5/2
    elems['swap (reflection in eps - o)'] = reflection(u_sw, sq6); elems['reflection in eps + o'] = reflection(u_sw2, sq6)
    elems['rotation (1,2) cos 3/5'] = lorentz_rot(F(3, 5), F(4, 5), 1, 2); elems['boost (0,1) cosh 5/4'] = lorentz_boost(F(5, 4), F(3, 4), 0, 1)
    Kx = mzero(6); Px = mzero(6)
    for a in range(4): Kx = madd(Kx, mscal(Km[a], XI[a])); Px = madd(Px, mscal(Pm[a], TH[a]))
    elems['exp(xi K)'] = expm_nilpotent(Kx); elems['exp(theta P)'] = expm_nilpotent(Px)
    maps = {}
    for name, S in elems.items():
        det = det_inv(S)[0]; ok_eta = preserves_eta(S, sq6); M = induced_map(C, S); aut = is_automorphism(C, M); maps[name] = M
        # [std] the same map by conjugation of the so(2,4) matrices: S M_A S^-1 = sum_B M[B][A] M_B
        Si = det_inv(S)[1]; okS = True
        for A, pr in enumerate(sorted(C.lab, key=lambda pr: C.lab[pr])):
            conj = mmul(S, mmul(Mst[pr], Si)); want = mzero(6)
            for Bb, prB in enumerate(sorted(C.lab, key=lambda pr: C.lab[pr])):
                if M[Bb][A] != 0: want = madd(want, mscal(Mst[prB], M[Bb][A]))
            okS &= (conj == want)
        inv = all(sum(Kbig[r][s] * M[r][A] * M[s][B] for r in range(C.G) for s in range(C.G)) == Kbig[A][B] for A in range(C.G) for B in range(C.G))
        chk('bit', ok_eta and aut and inv, '%s: preserves eta (det %s), the induced map on bivectors is an automorphism of the engine\'s bracket table (225 pairs) and preserves the Killing form (exact)' % (name, det))
        chk('bit==std', okS, '%s: the induced map equals the conjugation S M_AB S^-1 of the so(2,4) matrices (all 15 generators, exact)' % name)
    # the dilatation is the weight map and the matrix exponential
    for t in TS:
        Mw = weight_map(C, F(1), t, 1 / t, F(1)); M = maps['dilatation t=%s' % t]
        chk('bit', Mw == M and is_automorphism(C, Mw), 'dilatation t=%s: the weight map (J x 1, P x t, K x 1/t, D x 1) is the map induced by the boost of the (g4, g5) plane with cosh = (t + 1/t)/2, and an automorphism' % t)
        okw = all(veq(apply_vec(M, nm['P%d' % a]), vscale(nm['P%d' % a], t)) and veq(apply_vec(M, nm['K%d' % a]), vscale(nm['K%d' % a], 1 / t)) for a in range(4)) and veq(apply_vec(M, nm['D']), nm['D']) and all(veq(apply_vec(M, nm[n_]), nm[n_]) for n_ in nm if n_[0] == 'J')
        chk('bit', okw, 'dilatation t=%s: P_a -> t P_a, K_a -> K_a / t, J and D fixed (all 15 basis vectors)' % t)
    D6 = np.array([[float(x) for x in r] for r in Dm]); Pf = [np.array([[float(x) for x in r] for r in Pm[a]]) for a in range(4)]; Kf = [np.array([[float(x) for x in r] for r in Km[a]]) for a in range(4)]
    oks = True
    for sig, t in ((np.log(2.0), 2.0), (np.log(3.0), 3.0), (-np.log(2.0), 0.5)):
        g = expm(sig * D6); gi = expm(-sig * D6)
        oks &= all(np.allclose(g @ Pf[a] @ gi, t * Pf[a]) and np.allclose(g @ Kf[a] @ gi, Kf[a] / t) for a in range(4))
    chk('std', oks, 'scipy expm(sigma D) P expm(-sigma D) = e^sigma P and K -> e^-sigma K at sigma = ln 2, ln 3, -ln 2 (6 x 6 matrices, floats): t = e^sigma')
    # controls on the weights
    for (wP, wK, what) in ((F(4), F(1, 2), 'a wrong weight +2 on P (P x t^2) with K x 1/t'), (F(2), F(1), 'K with weight 0 (K x 1)'), (F(2), F(2), 'K with weight +1 (K x t)')):
        Mw = weight_map(C, F(1), wP, wK, F(1))
        chk('ctl', not is_automorphism(C, Mw), 'control: %s at t = 2 is not an automorphism of the bracket table (fails, ok)' % what)
    chk('ctl', weight_map(C, F(1), F(1), F(1), F(1)) == [[F(1 if i == j else 0) for j in range(C.G)] for i in range(C.G)] and boost45(F(1)) == eye6(), 'control: t = 1 (sigma = 0) is the identity')
    Msw = maps['swap (reflection in eps - o)']
    chk('ctl', mmul(Msw, Msw) == [[F(1 if i == j else 0) for j in range(C.G)] for i in range(C.G)] and Msw != [[F(1 if i == j else 0) for j in range(C.G)] for i in range(C.G)], 'control: the swap composed twice is the identity, the swap itself is not')
    oksw = all(veq(apply_vec(Msw, nm['P%d' % a]), nm['K%d' % a]) and veq(apply_vec(Msw, nm['K%d' % a]), nm['P%d' % a]) for a in range(4)) and veq(apply_vec(Msw, nm['D']), vscale(nm['D'], -1)) and all(veq(apply_vec(Msw, nm[n_]), nm[n_]) for n_ in nm if n_[0] == 'J')
    chk('bit', oksw, 'the swap: P_a <-> K_a, D -> -D, J fixed (the reflection in eps - o exchanges eps and o; with P = g eps/2, K = g o/2 the factor is 1)')
    # exp(xi K): the induced map equals the engine's own series Ad_exp
    y = {}
    for a in range(4): y[C.lab[(a, 4)]] = const(4, XI[a] / 2); y[C.lab[(a, 5)]] = const(4, -XI[a] / 2)
    okK = all(veq(apply_vec(maps['exp(xi K)'], {B: F(1)}), {A: at0(x.get(0, {}), 4) for A, x in enumerate(Ad_exp(C, y, [{0: const(4, 1)} if Bb == B else {} for Bb in range(C.G)])) if at0(x.get(0, {}), 4) != 0}) for B in range(C.G))
    chk('bit', okK, 'exp(xi K): the map induced by the (terminating) matrix exponential equals the engine\'s own series Ad_exp = sum ad_y^k / k! on all 15 basis vectors (both exact)')

    # ---------------------------------------------------------------------------------------- the connection on the (anti-)de Sitter frames
    for (fname, p, rho, H2) in FRAMES:
        lam = -H2 / 2
        head('frame %s: A = omega J + e (P + lam K), lam = -H2/2 = %s (%s)' % (fname, lam, 'de Sitter, J + (P + lam K) = so(1,4)' if lam < 0 else 'anti-de Sitter, so(2,3)'))
        e = ks_frame_jetK(p, rho, 0, H2); d = engine_data(C, e); om1 = [ftrunc(x, 1) for x in d['om']]; e1 = [ftrunc(x, 1) for x in e]
        with trunc(4, xdeg=0): tz = torsion_zero_at0(C.Gl, d['om'], e, 4)
        chk('bit', tz, '%s: precondition T = 0 at the point (A3 omega, the engine\'s torsion with the h table)' % fname)
        chk('bit', all(fit_ratio(Fm, d['f'][a], e1[a]) == lam for a in range(4)), '%s: the Schouten part is f^a = lam e^a with lam = %s as 1-jets (all four a)' % (fname, lam))
        A = compose(C, om1, e1, d['f']); F0 = [pt0(x) for x in curvature6(C, A, 0)]
        chk('bit', all(fzero(x) for x in F0), '%s: F = 0 at the point, all 15 components (flat in so(2,4))' % fname)
        rows = span_rows(C, A); hb = h_basis(C, lam); rk = rank_exact(rows); rk2 = rank_exact(rows + [[v.get(i, F(0)) for i in range(C.G)] for v in hb])
        chk('bit', rk == 10 and rk2 == 10, '%s: the values of A (1-jet, all coordinate directions and monomials) span exactly the 10-dimensional subalgebra h_lam = J + (P + lam K) (rank %d, with h_lam %d)' % (fname, rk, rk2))
        Kh = sub_killing_engine(C, hb); sg = signature_exact(Kh); want = (4, 6, 0) if lam < 0 else (6, 4, 0)
        Ks = sub_killing_std(h_basis_std(Mst, Pm, Km, lam)); sgs = signature_exact(Ks); sgn = sig_numpy(Ks)
        chk('bit', sg == want, '%s: Killing signature of h_lam from the engine\'s brackets (exact congruence) = %s: %s' % (fname, sg, 'so(1,4)' if sg == (4, 6, 0) else 'so(2,3)' if sg == (6, 4, 0) else '?'))
        chk('std', sgs == want and sgn == want, '%s: the same from 6 x 6 matrices alone: exact %s, numpy eigenvalues %s' % (fname, sgs, sgn))
        Kh2 = sub_killing_engine(C, h_basis(C, -lam)); sg2 = signature_exact(Kh2)
        chk('ctl', sg2 == ((6, 4, 0) if lam < 0 else (4, 6, 0)) and sg2 != sg, '%s: control: J + (P - lam K), the other sign, has the swapped signature %s (the signature reads the sign)' % (fname, sg2))
        # (1) the dilatation: three routes
        for t in TS:
            Ad_ = dil(C, A, const(4, t), const(4, 1 / t)); Ab = apply_forms(C, maps['dilatation t=%s' % t], A)
            dec, ratios = read_form(C, Ad_); Fp = [pt0(x) for x in curvature6(C, Ad_, 0)]
            okJ = all(feq(Fm, dec['J'][pr], om1[A4]) for A4, pr in enumerate(C.pairs4)); okP = all(feq(Fm, dec['P'][a], Fm.scale(e1[a], t)) for a in range(4)); okD = fzero(dec['D'])
            chk('bit', all(feq(Fm, x, z) for x, z in zip(Ad_, Ab)) and okJ and okP and okD and ratios == {lam / t ** 2} and all(fzero(x) for x in Fp),
                '%s, t=%s: the weight map (dil of h5l_frames) and the induced map agree; A\' = omega J + e\'(P + lam\' K) with e\' = t e, lam\' = lam / t^2 = %s (same sign as lam = %s), D part 0, F\' = 0' % (fname, t, lam / t ** 2, lam))
        # [std] floats: the matrix connection at the point conjugated by expm(sigma D)
        pt = (F(0),) * 4; Amu = []
        for mu in range(4):
            Mx = mzero(6)
            for Cc, pr in enumerate(sorted(C.lab, key=lambda pr: C.lab[pr])): Mx = madd(Mx, mscal(Mst[pr], peval(A[Cc].get(1 << mu, {}), pt)))
            Amu.append(np.array([[float(x) for x in r] for r in Mx]))
        okf = True; ok_ratio = True
        for sig, t in ((np.log(2.0), 2.0), (np.log(3.0), 3.0), (-np.log(2.0), 0.5)):
            g = expm(sig * D6); gi = expm(-sig * D6)
            for mu in range(4):
                Ap = g @ Amu[mu] @ gi; comp = {pr: Ap[pr[0]][pr[1]] / sq6[pr[1]] for pr in itertools.combinations(range(6), 2)}
                Pc = [(comp[(a, 4)] + comp[(a, 5)]) / 2 for a in range(4)]; Kc = [comp[(a, 4)] - comp[(a, 5)] for a in range(4)]
                e0 = [float(peval(e1[a].get(1 << mu, {}), pt)) for a in range(4)]
                okf &= all(abs(Pc[a] - t * e0[a]) < 1e-9 for a in range(4)); ok_ratio &= all(abs(Kc[a] - float(lam) / t ** 2 * Pc[a]) < 1e-9 for a in range(4))
        chk('std', okf and ok_ratio, '%s: scipy expm(sigma D) conjugating the 6 x 6 connection matrices at the point: P part = e^sigma e, K part = (lam e^-2 sigma) P part, sigma = ln 2, ln 3, -ln 2 (floats, 1e-9)' % fname)
        # control: the wrong weight gives another ratio
        Mw = weight_map(C, F(1), F(4), F(1, 2), F(1)); decw, rw = read_form(C, apply_forms(C, Mw, A))
        chk('ctl', rw == {lam / 8} and rw != {lam / 4}, '%s: control: the wrong weight +2 on P at t = 2 gives the ratio lam / 8 instead of lam / 4 (and is no automorphism)' % fname)
        # (2) the swap and the other reflection
        for name, sign_e in (('swap (reflection in eps - o)', 1), ('reflection in eps + o', -1)):
            Ab = apply_forms(C, maps[name], A); dec, ratios = read_form(C, Ab); Fp = [pt0(x) for x in curvature6(C, Ab, 0)]
            okJ = all(feq(Fm, dec['J'][pr], om1[A4]) for A4, pr in enumerate(C.pairs4)); okP = all(feq(Fm, dec['P'][a], Fm.scale(e1[a], sign_e * lam)) for a in range(4))
            chk('bit', okJ and okP and fzero(dec['D']) and ratios == {1 / lam} and all(fzero(x) for x in Fp), '%s, %s: A\' = omega J + e\'(P + lam\' K) with e\' = %s lam e, lam\' = 1/lam = %s (same sign), D part 0, F\' = 0' % (fname, name, '+' if sign_e > 0 else '-', 1 / lam))
        # (3) Lorentz elements keep the form with lam unchanged; exp(xi K), exp(theta P) leave it
        for name in ('rotation (1,2) cos 3/5', 'boost (0,1) cosh 5/4'):
            Ab = apply_forms(C, maps[name], A); dec, ratios = read_form(C, Ab); Fp = [pt0(x) for x in curvature6(C, Ab, 0)]
            moved = not all(feq(Fm, dec['P'][a], e1[a]) for a in range(4))
            chk('bit', fzero(dec['D']) and ratios == {lam} and moved and all(fzero(x) for x in Fp), '%s, %s: the form is kept with lam\' = lam = %s (e\' = the rotated frame, D part 0, F\' = 0)' % (fname, name, lam))
        for name, src in (('exp(xi K)', 'xi.e'), ('exp(theta P)', 'lam theta.e')):
            Ab = apply_forms(C, maps[name], A); dec, ratios = read_form(C, Ab); Fp = [pt0(x) for x in curvature6(C, Ab, 0)]
            vec = XI if name == 'exp(xi K)' else TH; want = {}
            for a in range(4): want = Fm.add(want, e1[a], vec[a] * sq6[a] * (1 if name == 'exp(xi K)' else lam))
            cD = fit_ratio(Fm, dec['D'], want)
            chk('bit', not fzero(dec['D']) and cD in (F(1), F(-1)) and all(fzero(x) for x in Fp), '%s, %s: the form is left: a D component %s (%s) appears (not of the form omega J + e(P + lam K)); F\' = Ad(g) F = 0 still' % (fname, name, ('%+d x ' % cD if cD is not None else '') + src, 'exact'))
            # the subalgebra spanned by the values of A' is Ad(g) h_lam: same Killing signature, and the big Killing form restricted agrees with the restriction on h_lam
            hb2 = [apply_vec(maps[name], v) for v in hb]; sg3 = signature_exact(sub_killing_engine(C, hb2))
            rows2 = span_rows(C, Ab); rk3 = rank_exact(rows2 + [[v.get(i, F(0)) for i in range(C.G)] for v in hb2])
            chk('bit', sg3 == sg and rk3 == 10 and rank_exact(rows2) == 10, '%s, %s: the values of A\' span Ad(g) h_lam (rank 10) whose Killing signature is %s, the same: no conjugation changes the sign' % (fname, name, sg3))
        for name in ('swap (reflection in eps - o)', 'dilatation t=2', 'boost (0,1) cosh 5/4'):
            hb2 = [apply_vec(maps[name], v) for v in hb]; sg3 = signature_exact(sub_killing_engine(C, hb2))
            chk('bit', sg3 == sg, '%s, %s: Killing signature of Ad(g) h_lam = %s (unchanged)' % (fname, name, sg3))
        # a non-constant dilatation leaves the form: the term -d sigma D
        sigma = lin((F(1, 3), var(4, 0)), (F(-1, 2), var(4, 2)))                       # sigma(x) = x0/3 - x2/2, sigma(0) = 0
        with trunc(4, xdeg=1):
            Om1 = padd(const(4, 1), sigma); Oi = padd(const(4, 1), sigma, -1); dsig = Fm.d({0: sigma})
            An = dil(C, A, Om1, Oi, dsig); decn, rn = read_form(C, An); Fn = [pt0(x) for x in curvature6(C, An, 0)]
        dstd = {1 << mu: q for mu in range(4) for q in [sp_der(sigma, mu)] if q}
        chk('bit', not fzero(decn['D']) and feq(Fm, decn['D'], Fm.scale(dsig, -1)) and all(fzero(x) for x in Fn), '%s: a dilatation with sigma(x) = x0/3 - x2/2: the D part is -d sigma != 0 (engine d), the form is left; F\' = 0 at the point' % fname)
        chk('bit==std', feq(Fm, dsig, dstd), '%s: the engine\'s d sigma equals the plain partial derivatives of sigma' % fname)
    print('\n  summary: the constant elements that keep the form omega J + e(P + lam K) are the Lorentz ones (lam fixed), the dilatation (lam -> lam / t^2) and the two reflections of the null plane (lam -> 1/lam): the sign of lam is invariant, |lam| is not.')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('H5L-gauge')
