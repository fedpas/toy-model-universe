#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Three exact gravity checks on the step-9/10 engine (next to gravity_new_checks.py, which it imports).  python3 gravity_moves.py [1] [2] [3]
 1  an exact gravitational wave: a plane-wave (Kerr-Schild, constant null l) frame; E_a = 0 for the vacuum profiles, nonzero for the others.
 2  the cosmological term: Schwarzschild-de Sitter / anti-de Sitter in Kerr-Schild form on a flat background (f = M/rho + (H2/2) rho^2): E_a(c) = 0 for which c?
 3  the horizon generator N = grad(rho) is a null geodesic for the omega solved from T = 0, and its rate is the surface gravity 1/(4M)."""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # this folder (gravity_new_checks), also under python3 -I
from fractions import Fraction as F
import gravity_new_checks as g
from gravity_new_checks import (solve_torsion_free, torsion_zero_to, metric_from, at0, pmt, psum, trunc, const, var, ks_frame, check, FAILS)
from gravity_selfcheck import Grav, pder, padd, pmul, desitter_embedding

ETA = [1, -1, -1, -1]

def analyse(e, E, cs=(F(0),)):
    """solve T = 0 as a first-order jet, curvature, Einstein form for each c in cs (constant terms), Ricci and Riemann of the metric from Christoffel jets, Kretschmann"""
    n = 4; Gv = Grav(4)
    om, rank, nvar, cons, neq = solve_torsion_free(Gv, e, 1)
    ok_solve = bool(cons and rank == nvar == neq and torsion_zero_to(Gv, om, e, 1))
    R = Gv.curvature(om)
    Ea = {}
    for c in cs:
        E_, _ = Gv.einstein(None, e, R, c)
        Ea[c] = {(a, m): at0(pp, n) for a in range(4) for m, pp in E_[a].items() if at0(pp, n) != 0}
    gm, ec = metric_from(Gv, e, ETA)
    gi = {(la, si): psum(*[(ETA[a], pmt(E[la][a], E[si][a], 2)) for a in range(4)]) for la in range(4) for si in range(4)}
    dg = lambda k, a, b: pder(gm[(a, b)], k)
    Gam = {}
    for la in range(4):
        for mu in range(4):
            for nu in range(4):
                tot = {}
                for si in range(4):
                    tot = padd(tot, psum((F(1, 2), pmt(gi[(la, si)], psum((F(1), dg(mu, si, nu)), (F(1), dg(nu, si, mu)), (F(-1), dg(si, mu, nu))), 1))))
                Gam[(la, mu, nu)] = trunc(tot, 1)
    def riem(rho, sig, mu, nu):
        t0 = at0(psum((F(1), pder(Gam[(rho, nu, sig)], mu)), (F(-1), pder(Gam[(rho, mu, sig)], nu))), n)
        for l in range(4): t0 += at0(Gam[(rho, mu, l)], n) * at0(Gam[(l, nu, sig)], n) - at0(Gam[(rho, nu, l)], n) * at0(Gam[(l, mu, sig)], n)
        return t0
    Rm = {(r_, s_, m_, n_): riem(r_, s_, m_, n_) for r_ in range(4) for s_ in range(4) for m_ in range(4) for n_ in range(4)}
    ric = [[sum(Rm[(r_, s_, r_, n_)] for r_ in range(4)) for n_ in range(4)] for s_ in range(4)]
    def Reng(a, b, mu, nu):
        if a == b or mu == nu: return F(0)
        s = 1; aa, bb = a, b
        if aa > bb: aa, bb = bb, aa; s = -1
        A = Gv.L.idx[(1 << aa) | (1 << bb)]
        m, q = (mu, nu) if mu < nu else (nu, mu); sg = 1 if mu < nu else -1
        return s * sg * at0(R[A].get((1 << m) | (1 << q), {}), n)
    E0 = [[at0(E[mu][a], n) for a in range(4)] for mu in range(4)]; e0 = [[at0(ec[a][mu], n) for mu in range(4)] for a in range(4)]
    match = all(sum(E0[r_][a] * e0[b][s_] * Reng(a, b, m_, n_) * ETA[b] for a in range(4) for b in range(4)) == Rm[(r_, s_, m_, n_)]
                for r_ in range(4) for s_ in range(4) for m_ in range(4) for n_ in range(m_ + 1, 4))
    K = F(0)
    for a in range(4):
        for b in range(4):
            for c_ in range(4):
                for d_ in range(4):
                    Rfr = sum(Reng(a, b, mu, nu) * E0[mu][c_] * E0[nu][d_] for mu in range(4) for nu in range(4))
                    K += ETA[a] * ETA[b] * ETA[c_] * ETA[d_] * Rfr * Rfr
    gi0 = [[at0(gi[(i, j)], n) for j in range(4)] for i in range(4)]
    ricmix = [[sum(gi0[m][s_] * ric[s_][v] for s_ in range(4)) for v in range(4)] for m in range(4)]
    return dict(ok_solve=ok_solve, om=om, Gv=Gv, Ea=Ea, ric_zero=all(ric[i][j] == 0 for i in range(4) for j in range(4)), match=match, K=K,
                riem_nonzero=any(v != 0 for v in Rm.values()), ric=ric, ricmix=ricmix)

# ------------------------------------------------------------------------------------------------ move 1: plane waves
def shift_trunc(P, p, d=2):
    """the polynomial P(x) re-expanded around the point p, as a polynomial in delta = x - p, truncated at degree d"""
    n = 4; pw = []
    for i in range(n):
        base = psum((F(1), const(n, p[i])), (F(1), var(n, i))); cur = const(n, 1); lst = [cur]
        for _ in range(max([k[i] for k in P] + [0])): cur = pmt(cur, base, d); lst.append(cur)
        pw.append(lst)
    out = {}
    for k, v in P.items():
        term = const(n, v)
        for i in range(n): term = pmt(term, pw[i][k[i]], d)
        out = padd(out, term)
    return trunc(out, d)
def gpoly(coeffs):
    """a polynomial in the four global coordinates (t, z, x, y) from {exponent tuple: Fraction}"""
    return {k: F(v) for k, v in coeffs.items() if v != 0}
def pw_frame(fglob, p):
    """e^a = dx^a - f l^a l_mu dx^mu, E^mu_a = delta + f l^mu l_a, l^a = (1, 1, 0, 0) (null), l_mu dx^mu = dt - dz = du; f a global polynomial; jets at p"""
    n = 4; l_up = [1, 1, 0, 0]; l_dn = [1, -1, 0, 0]
    e = []; E = [[None] * 4 for _ in range(4)]
    for a in range(4):
        form = {}
        for mu in range(4):
            glob = psum((F(1 if a == mu else 0), const(n, 1)), (F(-l_up[a] * l_dn[mu]), fglob))
            if glob: form[1 << mu] = shift_trunc(glob, p)
            Eg = psum((F(1 if a == mu else 0), const(n, 1)), (F(l_up[mu] * l_dn[a]), fglob))
            E[mu][a] = shift_trunc(Eg, p)
        e.append(form)
    return e, E
def prof(coef):                                    # h(u), u = t - z, from a list of rational coefficients
    u = psum((F(1), var(4, 0)), (F(-1), var(4, 1))); r = const(4, 0); P = const(4, 1)
    for c in coef: r = padd(r, P, F(c)); P = pmul(P, u)
    return r
def xpoly(i, j, c=1):                              # c x_i x_j  (global)
    return {tuple((1 if k == i else 0) + (1 if k == j else 0) for k in range(4)): F(c)}
def move1():
    print('\nMOVE 1  an exact gravitational wave on the step-9/10 engine')
    rng = random.Random(7); pts = [tuple(F(rng.randint(-6, 6), rng.randint(1, 3)) for _ in range(4)) for _ in range(8)]
    h = prof([1, 2, -1, 3])                        # 1 + 2u - u^2 + 3u^3
    plus = pmul(psum((F(1), xpoly(2, 2)), (F(-1), xpoly(3, 3))), h)         # (x^2 - y^2) h(u): plus polarisation
    cross = pmul(xpoly(2, 3, 2), prof([2, 0, 1]))                          # 2xy (2 + u^2): cross polarisation
    both = padd(plus, cross)
    allz = True; allm = True; nonflat = True; allK = True; solved = True; zero_ev = {}
    for name, fg in (('plus', plus), ('cross', cross), ('plus + cross', both)):
        zz = True
        for p in pts:
            e, E = pw_frame(fg, p); r = analyse(e, E)
            solved &= r['ok_solve']; zz &= (not r['Ea'][F(0)]) and r['ric_zero']; allm &= r['match']; nonflat &= r['riem_nonzero']; allK &= (r['K'] == 0)
        zero_ev[name] = zz; allz &= zz
    check(solved, 'T = 0 solved exactly (square, full rank, torsion zero to first order) at all 3 x 8 points')
    check(allz, 'plus, cross and plus + cross polarisations with a cubic profile h(u): the Einstein form E_a is EXACTLY ZERO (16 components) and the metric\'s Ricci is zero, at 8 random rational points each')
    check(nonflat and allm, 'the curvature is not zero (a wave, not flat space), and the engine\'s R equals the Riemann tensor of the metric exactly at every point')
    check(allK, 'the Kretschmann scalar is exactly 0 at every point (as it must be for a plane wave: all scalar invariants vanish)')
    # controls: not vacuum
    bad1 = pmul(psum((F(1), xpoly(2, 2)), (F(1), xpoly(3, 3))), h)           # (x^2 + y^2) h: Ricci_uu = -2h' ... a null-dust source
    bad2 = pmul(psum((F(1), xpoly(2, 2)), (F(-2), xpoly(3, 3))), h)          # (x^2 - 2y^2) h
    lin = pmul(xpoly(2, 2, 1), h); lin = padd(lin, pmul(xpoly(3, 3, -1), h)); wrong_u = pmul(psum((F(1), xpoly(2, 2)), (F(-1), xpoly(3, 3))), psum((F(1), var(4, 0)), (F(1), var(4, 1))))  # depends on t + z, not on u = t - z
    for name, fg in (('(x^2 + y^2) h(u)', bad1), ('(x^2 - 2 y^2) h(u)', bad2), ('(x^2 - y^2)(t + z): not a function of u', wrong_u)):
        nz = 0
        for p in pts[:4]:
            e, E = pw_frame(fg, p); r = analyse(e, E); nz += bool(r['Ea'][F(0)]) and (not r['ric_zero'])
        check(nz == 4, 'control: f = %s is not vacuum: E_a nonzero and Ricci nonzero at all 4 test points' % name)

# ------------------------------------------------------------------------------------------------ move 2: the cosmological term
def move2():
    print('\nMOVE 2  the cosmological term on Schwarzschild-de Sitter and anti-de Sitter')
    kk = {}
    for s in (-1, 1): kk[s] = desitter_embedding(4, 11 * 4 + s, s)[0]
    print('    engine identity (step 10): extra generator of square s adds k e^a e^b to R^{ab}:  k(s = -1) = %s,  k(s = +1) = %s' % (kk[-1], kk[1]))
    pts = [((3, 4, 12), F(13)), ((2, 6, 9), F(11)), ((F(1), F(2), F(2)), F(3)), ((F(2, 3), F(4, 3), F(4, 3)), F(2))]
    pts = [(tuple(F(x) for x in p), r) for p, r in pts]
    ratios = {}; consistent = True; solved = True; einst = []
    for H2 in (F(1, 50), F(-1, 50), F(1, 20)):
        for M in (F(0), F(1)):
            for p, r in pts:
                e, E, _ = ks_frame(M, p, r, 'sds', H2=H2); res = analyse(e, E, cs=(F(0), F(1)))
                solved &= res['ok_solve']
                E0, E1 = res['Ea'][F(0)], res['Ea'][F(1)]
                keys = set(E0) | set(E1); W = {k: E1.get(k, 0) - E0.get(k, 0) for k in keys}
                k0 = next(k for k in W if W[k] != 0); c0 = -E0.get(k0, F(0)) / W[k0]
                consistent &= all(E0.get(k, 0) + c0 * W[k] == 0 for k in keys)       # E(c0) = 0 for all 16 components
                consistent &= res['ric_zero'] is False or H2 == 0
                ratios.setdefault((H2, M), set()).add(c0 / H2)
                rm = res['ricmix']; lam = rm[0][0]
                einst_ok = all(rm[i][j] == (lam if i == j else 0) for i in range(4) for j in range(4)); einst.append((einst_ok, lam / H2))
    check(solved, 'T = 0 solved exactly at every point (square system, full rank)')
    check(consistent, 'for every frame there is ONE number c0 with E_a(c0) = 0 in all 16 components (E_a is linear in c; the whole 3-form vanishes together)')
    allr = set().union(*ratios.values())
    check(len(allr) == 1, 'c0 / H^2 is the same exact number at all points, for M = 0 and M = 1, for H^2 = 1/50, -1/50, 1/20: %s' % sorted(map(str, allr)))
    r0 = next(iter(allr))
    check(r0 == 1, 'c0 = H^2 (de Sitter, H^2 > 0: c0 > 0 ; anti-de Sitter, H^2 < 0: c0 < 0): the sign and the size of the cosmological term in the engine\'s Einstein form F = R + c e^e, here for a real solution' if r0 == 1 else 'RESULT c0 = %s H^2' % r0)
    check(all(x for x, _ in einst) and {str(v) for _, v in einst} == {'-3'}, 'independent of the Einstein form: the Ricci tensor of the metric (from Christoffel jets, MTW sign of the Riemann tensor) is R^mu_nu = -3 H^2 delta^mu_nu exactly at every point, for M = 0 and M = 1. In the signature (+,-,-,-) the mixed Ricci tensor of de Sitter is negative (it is +3H^2 in (-,+,+,+): the mixed Ricci changes sign with the metric): an Einstein space with Lambda = 3 H^2, de Sitter for H^2 > 0 and anti-de Sitter for H^2 < 0, so c0 = Lambda/3')
    check(kk[-1] == 1 and kk[1] == -1, 'the engine\'s algebraic identity gives k = -s (k = +1 for the de Sitter algebra s = -1, k = -1 for anti-de Sitter s = +1), which is the same sign pattern as c0 = H^2 for H^2 > 0 (de Sitter) and H^2 < 0 (anti-de Sitter): the rule k = -s is borne out by the solution')
    # control: c = -H^2 or c = 0 do not vanish
    e, E, _ = ks_frame(F(1), pts[0][0], pts[0][1], 'sds', H2=F(1, 50)); res = analyse(e, E, cs=(F(0), -F(1, 50), F(1, 50)))
    check(bool(res['Ea'][F(0)]) and bool(res['Ea'][-F(1, 50)]) and not res['Ea'][F(1, 50)], 'control: with c = 0 and with c = -H^2 the Einstein form does not vanish; with c = +H^2 it does')

# ------------------------------------------------------------------------------------------------ move 3: horizon generator
def move3():
    print('\nMOVE 3  the horizon generator and the surface gravity from the solved omega')
    n = 4
    cases = [(F(1), (F(2, 3), F(4, 3), F(4, 3))), (F(1), (F(4, 7), F(6, 7), F(12, 7))), (F(1), (F(2, 9), F(8, 9), F(16, 9))),
             (F(3, 2), (F(1), F(2), F(2))), (F(3, 2), (F(9, 7) * F(2, 3) * 1, F(9, 7), F(18, 7))), (F(3, 2), (F(1, 3), F(4, 3), F(8, 3)))]
    cases[4] = (F(3, 2), (F(3, 7) * 2, F(3, 7) * 3, F(3, 7) * 6))
    off = [(F(1), (F(3), F(4), F(12))), (F(1), (F(1), F(2), F(2))), (F(1), (F(1, 2), F(1), F(1)))]
    def gen(M, p, use='solved'):
        rho0 = (sum(x * x for x in p)) ** F(1, 2) if False else None
        s2 = sum(x * x for x in p); r = F(int(round(float(s2) ** .5))) if False else None
        # exact rational root
        from math import isqrt
        num, den = s2.numerator, s2.denominator; rn, rd = isqrt(num), isqrt(den); assert rn * rn == num and rd * rd == den; rho0 = F(rn, rd)
        e, E, (l_up, l_dn) = ks_frame(M, p, rho0, 'ks')
        Gv = Grav(4); om, rank, nvar, cons, neq = solve_torsion_free(Gv, e, 1)
        okS = bool(cons and rank == nvar == neq and torsion_zero_to(Gv, om, e, 1))
        if use == 'zero': om = [{} for _ in range(Gv.G)]
        if use == 'neg': om = [Gv.Fm.scale(x, F(-1)) for x in om]
        nmu = [{}, l_dn[1], l_dn[2], l_dn[3]]
        Npoly = [ETA[a] * 1 and psum(*[(F(ETA[a]), pmt(E[mu][a], nmu[mu], 2)) for mu in range(4)]) for a in range(4)]
        N0 = [at0(Npoly[a], n) for a in range(4)]
        E0 = [[at0(E[mu][a], n) for a in range(4)] for mu in range(4)]
        Nmu = [sum(E0[mu][a] * N0[a] for a in range(4)) for mu in range(4)]
        w = lambda A, mu: at0(om[A].get(1 << mu, {}), n)
        DN = [F(0)] * 4
        for mu in range(4):
            for a in range(4): DN[a] += Nmu[mu] * at0(pder(Npoly[a], mu), n)
            for (A, b), (c, hval) in Gv.L.h.items(): DN[c] += Nmu[mu] * hval * w(A, mu) * N0[b]
        NN = sum(ETA[a] * N0[a] * N0[a] for a in range(4))
        nz = next(a for a in range(4) if N0[a] != 0); lam = DN[nz] / N0[nz]
        prop = all(DN[a] == lam * N0[a] for a in range(4))
        return dict(okS=okS, NN=NN, lam=lam, prop=prop, rho0=rho0, M=M)
    allS = True; allnull = True; allprop = True; allgrav = True; lams = []
    for M, p in cases:
        r = gen(M, p); allS &= r['okS']; allnull &= (r['rho0'] == 2 * M and r['NN'] == 0); allprop &= r['prop']; allgrav &= (r['lam'] == -M / r['rho0'] ** 2 == -1 / (4 * M)); lams.append(r['lam'])
    check(allS, 'T = 0 solved exactly at all 6 horizon points (3 for M = 1, 3 for M = 3/2)')
    check(allnull, 'on the horizon rho = 2M the generator N = grad(rho) is null (N.N = 0 exactly) and not zero')
    check(allprop, 'D_N N = lambda N exactly (all four components), with D from the solved omega: N is a geodesic direction (null geodesic on the horizon)')
    check(allgrav, 'lambda = -M/rho^2 = -1/(4M) exactly: %s: the surface gravity of Schwarzschild, from the connection solved by the bit rule' % sorted(map(str, set(lams))))
    prop_off = True; lam_off = True
    for M, p in off:
        r = gen(M, p); prop_off &= r['prop']; lam_off &= (r['lam'] == -M / r['rho0'] ** 2) and (r['NN'] == -(1 - 2 * M / r['rho0']))
    check(prop_off and lam_off, 'off the horizon (rho = 13, 3, 3/2 for M = 1) the same relation holds with lambda = -M/rho^2 and N.N = -(1 - 2M/rho) exactly (nonzero there, positive inside): the null character is the horizon\'s')
    z = [gen(M, p, use='zero') for M, p in cases]; ng = [gen(M, p, use='neg') for M, p in cases]
    check(all(c['lam'] == 0 for c in z) and all(c['lam'] != -1 / (4 * c['M']) for c in z), 'control: with omega replaced by 0 the rate is 0 at all six horizon points: the whole surface gravity comes from the connection (the frame components of N are constant along N on the horizon)')
    check(all(c['lam'] == 1 / (4 * c['M']) for c in ng), 'control: with omega replaced by -omega the rate is +1/(4M): the sign is the connection\'s')

if __name__ == '__main__':
    which = sys.argv[1:] or ['1', '2', '3']
    if '1' in which: move1()
    if '2' in which: move2()
    if '3' in which: move3()
    print('\nFAILS:', FAILS if FAILS else 'none')
    sys.exit(1 if FAILS else 0)
