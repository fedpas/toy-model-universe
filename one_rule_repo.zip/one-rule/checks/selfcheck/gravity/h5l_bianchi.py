#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H5L-B: the Bianchi identity of the so(2,4) Cartan curvature (15 components) on 4 coordinates, and the sign of b under e -> Omega e.   python3 h5l_bianchi.py
 Connection A = omega J + e P + b D + f K (h5l_conformal: Conf, compose, decompose, curvature6), F = dA + (1/4) f A A = (W, T^, G, C) with
 W = R - (e^a f^b - e^b f^a), T^ = T + b^e, G = db - eta e^f, C = Df - b^f.
 Part 1 [bit] D_A F = dF + (1/2) f A^F = 0 for arbitrary polynomial fields (A2b strong sampler, three seeds), coefficient fitted; [std] textbook so(p,q) matrices at
        rational points (cyclic d F and [A, F] from matrix-valued A_mu and its derivatives); controls (coefficient f, wrong e f sign, a non-Lie table); so(1,5), so(3,3).
 Part 2 [bit] the component identities (fitted coefficients) on the same random fields: J, P, D, K equations ((2.11a-d) of Andrianopoli, D'Auria, Grosso, Ravera, arXiv:2602.09664); control without the T^ terms.
 Part 3 [bit] torsion-free random frame, b = 0, f = S e with S symmetric (not Schouten): the reduced forms; control S not symmetric.
 Part 4 [bit] frames with f = Schouten (frame 4-jets, A3 omega 3-jet): Schwarzschild, SdS, RN, random; [std] own Christoffel route to second order: d_nabla Weyl =
        dx ^ Cot - Cot ^ dx, d_nabla Cot = Weyl ^ S; [bit==std] the engine's D_L W and D_L C carried to frame indices.
 Part 5 [bit] the sign of b: e' = (1 + lam sig) e, f' = (1 - lam sig) f, b' = b + k lam d sig, omega' = omega: F' - F = lam sig [D, F] iff k = -1.
 Exports (import-safe, no engine object at import): bracket_AF(C, A, X), D_full(C, A, X), comp_terms(C, om, e, f, b, Fx), fit_lin(targets, terms), wdot(L, W, v),
   engine_data_k(C, e, deg), std_route2(e), mat_at(C, A, pt) [std]."""
import sys, os, time, itertools, random, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from fractions import Fraction as F
from h5l_conformal import Conf, compose, decompose, curvature6, fzero, ftrunc, fmul0, so_mat, std_components, peval, mmul, madd, mscal, mcomm, mzero, SQ4, PAIR
import a2b_strong_sampling as A2B

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
MUNU = [(mu, nu) for mu in range(4) for nu in range(mu + 1, 4)]
LMV = [t for t in itertools.combinations(range(4), 3)]
def mask(*ix): return sum(1 << i for i in ix)

# ------------------------------------------------------------------------------------------------ [bit] helpers
def bracket_AF(C, A, X, Gv=None):
    """Q^C = sum f_AB^C A^A ^ X^B (no factor; the engine's f table of C.L or of Gv.L)"""
    Gv = Gv or C.Gv; Fm = Gv.Fm; Q = [{} for _ in range(Gv.G)]
    for (Aa, B), (Cc, f) in Gv.L.f.items():
        if A[Aa] and X[B]: Q[Cc] = Fm.add(Q[Cc], Fm.wedge(A[Aa], X[B]), f)
    return Q
def D_full(C, A, X, Gv=None):
    """the engine's D_bivector with the 15-generator table: dX + (1/2) f A ^ X"""
    return (Gv or C.Gv).D_bivector(A, X)
def wdot(L, W, v, Fm):
    """(W.v)^c = h_{Ab}^c W^A ^ v^b (the engine's h action of a bivector-valued form on a vector-valued form)"""
    out = [{} for _ in range(4)]
    for (Aa, b), (c, h) in L.h.items():
        if W[Aa] and v[b]: out[c] = Fm.add(out[c], Fm.wedge(W[Aa], v[b]), h)
    return out
def ee(Fm, x, y, a, b): return Fm.add(Fm.wedge(x[a], y[b]), Fm.wedge(x[b], y[a]), -1)
def flat_keys(forms):
    out = {}
    for i, X in enumerate(forms):
        for m, p in X.items():
            for k, v in p.items():
                if v != 0: out[(i, m, k)] = v
    return out
def fit_lin(targets, terms):
    """exact c with targets = sum_j c_j terms[j] (lists of forms); None when no such constants"""
    T = flat_keys(targets); Ts = [flat_keys(t) for t in terms]
    keys = sorted(set(T) | set().union(*[set(t) for t in Ts]))
    rows = [[t.get(k, F(0)) for t in Ts] for k in keys]; rhs = [T.get(k, F(0)) for k in keys]
    if not keys: return [F(0)] * len(terms)
    w, rank, nvar, cons = solve_exact(rows, rhs)
    return w if (w is not None and rank == len(terms)) else None
def allzero(forms): return all(fzero(x) for x in forms)
def at_pt(forms, pt=None):
    """0-jet (value at the origin of the jets, or at the rational point pt) of every coefficient: list of {mask: Fraction}"""
    out = []
    for X in forms:
        d = {}
        for m, p in X.items():
            v = at0(p, len(next(iter(p)))) if (pt is None and p) else (peval(p, pt) if p else F(0))
            if v != 0: d[m] = v
        out.append(d)
    return out
def comp_terms(C, om, e, f, b, Fx):
    """the pieces of the component identities: dict with W (frame order), T^, G, Cc, the left sides and the right-side terms"""
    Fm = C.Gv.Fm; Gl = C.Gl; dec = decompose(C, Fx); n = 4
    W = [dec['J'][pr] for pr in C.pairs4]; Th = dec['P']; G = dec['D']; Cc = dec['K']
    b = b or {}
    J_lhs = Gl.D_bivector(om, W)
    J_t1 = [ee(Fm, e, Cc, *pr) for pr in C.pairs4]                                   # e^a C^b - e^b C^a
    J_t2 = [ee(Fm, Th, f, *pr) for pr in C.pairs4]                                   # T^a f^b - T^b f^a
    P_lhs = Gl.D_vector(om, Th)
    P_t = [[Fm.wedge(b, Th[a]) for a in range(n)], wdot(C.Ll, W, e, Fm), [Fm.wedge(G, e[a]) for a in range(n)]]
    D_lhs = [Fm.d(G)]
    eC, Tf = {}, {}
    for a in range(n): eC = Fm.add(eC, Fm.wedge(e[a], Cc[a]), C.eta(a, a)); Tf = Fm.add(Tf, Fm.wedge(Th[a], f[a]), C.eta(a, a))
    D_t = [[eC], [Tf]]
    K_lhs = Gl.D_vector(om, Cc)
    K_t = [[Fm.wedge(b, Cc[a]) for a in range(n)], wdot(C.Ll, W, f, Fm), [Fm.wedge(G, f[a]) for a in range(n)]]
    return dict(W=W, Th=Th, G=G, C=Cc, J=(J_lhs, [J_t1, J_t2]), P=(P_lhs, P_t), D=(D_lhs, D_t), K=(K_lhs, K_t), eC=eC)

# ------------------------------------------------------------------------------------------------ [std] textbook matrices (no Clifford algebra, no engine)
def mat_at(C, A, pt):
    """A_mu, d_l A_mu, d_l d_k A_mu at pt as 6x6 Fraction matrices: A = sum_C A^C M_C with M_C = so_mat of the pair of generator C (X_C = B_C/2, h5l_conformal)"""
    sq = C.sq; N = len(sq); n = 4; Mc = {}
    for (i, j), Cc in C.lab.items(): Mc[Cc] = so_mat(i, j, sq)
    A0 = [mzero(N) for _ in range(n)]; A1 = {(l, mu): mzero(N) for l in range(n) for mu in range(n)}; A2 = {(l, k, mu): mzero(N) for l in range(n) for k in range(n) for mu in range(n)}
    for Cc, X in enumerate(A):
        for m, p in X.items():
            mu = m.bit_length() - 1
            A0[mu] = madd(A0[mu], Mc[Cc], peval(p, pt))
            for l in range(n):
                dp = sp_der(p, l); A1[(l, mu)] = madd(A1[(l, mu)], Mc[Cc], peval(dp, pt))
                for k in range(n): A2[(l, k, mu)] = madd(A2[(l, k, mu)], Mc[Cc], peval(sp_der(dp, k), pt))
    return A0, A1, A2
def std_bianchi_pieces(C, A, pt):
    """[std] cyclic sums d_[l F_mn] and [A_[l, F_mn]] at pt (matrices), F_mn = d_m A_n - d_n A_m + [A_m, A_n]"""
    A0, A1, A2 = mat_at(C, A, pt); n = 4
    Fmn = {(m, v): madd(madd(A1[(m, v)], A1[(v, m)], -1), mcomm(A0[m], A0[v])) for m in range(n) for v in range(n)}
    dF = {(l, m, v): madd(madd(A2[(l, m, v)], A2[(l, v, m)], -1), madd(mcomm(A1[(l, m)], A0[v]), mcomm(A0[m], A1[(l, v)]))) for l in range(n) for m in range(n) for v in range(n)}
    out = {}
    for (l, m, v) in LMV:
        cyc = [(l, m, v), (m, v, l), (v, l, m)]
        dpart = mzero(6); bpart = mzero(6)
        for (x, y, z) in cyc: dpart = madd(dpart, dF[(x, y, z)]); bpart = madd(bpart, mcomm(A0[x], Fmn[(y, z)]))
        out[(l, m, v)] = (dpart, bpart)
    return out

# ------------------------------------------------------------------------------------------------ part 1: the identity for arbitrary fields
SEED_DEG = {101: 2, 102: 1, 103: 1}                                               # polynomial degree of the strong fields per seed
def strong_fields(C, seed, deg=None, R=9):
    deg = deg or SEED_DEG.get(seed, 2)
    rng = random.Random(seed); n = 4
    om = [A2B.s_form(rng, n, 1, deg, R) for _ in range(C.Gl.G)]; e = [A2B.s_form(rng, n, 1, deg, R) for _ in range(n)]
    f = [A2B.s_form(rng, n, 1, deg, R) for _ in range(n)]; b = A2B.s_form(rng, n, 1, deg, R)
    return om, e, f, b
PTS = ((F(1, 2), F(-1, 3), F(2), F(-3, 4)), (F(-1), F(2, 5), F(1, 3), F(1)))
def part1(C, seeds):
    head('Part 1. D_A F = dF + c f A^F = 0 for arbitrary polynomial (omega, e, b, f) (strong sampler, coefficients -9..9, degree 2 (seed 101) or 1 (102, 103)), 15 components, exact')
    Fm = C.Gv.Fm; out = {}
    for seed in seeds:
        om, e, f, b = strong_fields(C, seed); A = compose(C, om, e, f, b); Fx = curvature6(C, A)
        dF = [Fm.d(x) for x in Fx]; Q = bracket_AF(C, A, Fx)
        c = fit_lin(dF, [Q]); nz = sum(1 for x in dF if not fzero(x))
        chk('bit', c is not None and c[0] == F(-1, 2) and nz > 0, 'seed %d: dF = c sum f_AB^C A^A ^ F^B with ONE c = %s on all 15 components (%d nonzero dF components): the Bianchi coefficient is 1/2' % (seed, c[0] if c else None, nz))
        DF = D_full(C, A, Fx)
        chk('bit', allzero(DF), 'seed %d: the engine\'s D_bivector(A, F) = dF + (1/2) f A ^ F = 0 exactly, all 15 3-form components, all orders (polynomial identity)' % seed)
        chk('ctl', not allzero([Fm.add(x, y) for x, y in zip(dF, Q)]), 'seed %d: the covariant derivative with coefficient f (not f/2) does not annihilate F (ok)' % seed)
        Fbad = list(Fx)
        for pr in C.pairs4: Fbad[C.lab[pr]] = Fm.add(Fx[C.lab[pr]], ee(Fm, e, f, *pr), 2)
        chk('ctl', not allzero(D_full(C, A, Fbad)), 'seed %d: the e f term with the wrong sign (W\' = R + (e^a f^b - e^b f^a)) breaks D_A F = 0 (ok)' % seed)
        okS, nzd, nzb = True, 0, 0
        for pt in PTS:
            pieces = std_bianchi_pieces(C, A, pt); dF0 = at_pt(dF, pt); Q0 = at_pt(Q, pt)
            for lmv, (dp, bp) in pieces.items():
                sd = std_components(dp, C.sq); sb = std_components(bp, C.sq)
                if any(sd[pr] + sb[pr] != 0 for pr in sd): okS = False
                for pr, Cc in C.lab.items():
                    if dF0[Cc].get(mask(*lmv), F(0)) != sd[pr] or Q0[Cc].get(mask(*lmv), F(0)) / 2 != sb[pr]: okS = False
                    nzd += sd[pr] != 0; nzb += sb[pr] != 0
        chk('bit==std', okS and nzd > 0 and nzb > 0, 'seed %d: [std] textbook so(2,4) matrices at 2 rational points: cyclic d_[l F_mn] and [A_[l, F_mn]] (matrix A_mu and its first and second '
            'derivatives, no engine) equal the engine\'s dF and (1/2) f A^F (%d and %d nonzero entries); their sum is zero in the matrix route too' % (seed, nzd, nzb))
        out[seed] = dict(om=om, e=e, f=f, b=b, A=A, F=Fx)
    # other pair signatures and a table that is not a Lie algebra
    import a1_lemmas as A1
    om, e, f, b = strong_fields(C, seeds[0])
    for pair, name in (((-1, -1), 'so(1,5)'), ((1, 1), 'so(3,3)')):
        Cw = Conf(SQ4, pair); Aw = compose(Cw, om, e, f, b); Fw = curvature6(Cw, Aw)
        chk('bit', allzero(D_full(Cw, Aw, Fw)) and A1.jacobi_bad(Cw.L) == 0, 'pair %s (%s, no null pair): D_A F = 0 as well (and Jacobi holds): the Bianchi identity is blind to the signature of the pair' % (pair, name))
    Lb = copy.copy(C.L); Lb.f = dict(C.L.f); key = sorted(Lb.f)[5]; Cc, v = Lb.f[key]; Lb.f[key] = (Cc, -v); k2 = (key[1], key[0]); Lb.f[k2] = (Lb.f[k2][0], -Lb.f[k2][1])
    Gb = Grav(4, Lb); A = compose(C, om, e, f, b); Fb = Gb.curvature(A); jb = A1.jacobi_bad(Lb)
    chk('ctl', jb > 0 and not allzero(Gb.D_bivector(A, Fb)), 'a table that is not a Lie algebra (the pair of f entries %s sign-flipped, jacobi_bad = %d): D_A F != 0 (ok): the identity reads Jacobi' % (key, jb))
    tick('part 1')
    return out

# ------------------------------------------------------------------------------------------------ part 2: component identities on the random fields
PRED = dict(J=[F(1), F(-1)], P=[F(-1), F(1), F(1)], D=[F(1), F(-1)], K=[F(1), F(1), F(-1)])
NAMES = dict(J='D_L W^{ab} = c1 (e^a C^b - e^b C^a) + c2 (T^a f^b - T^b f^a)', P='D_L T^a = c1 b^T^a + c2 (W.e)^a + c3 G^e^a',
             D='dG = c1 eta e^a C^b + c2 eta T^a f^b', K='D_L C^a = c1 b^C^a + c2 (W.f)^a + c3 G^f^a')
def part2(C, fields):
    head('Part 2. Components of D_A F = 0 on the random fields (b, T, G != 0): fitted coefficients, compared with the prediction and the paper\'s (2.11a-d)')
    for seed, d in fields.items():
        ct = comp_terms(C, d['om'], d['e'], d['f'], d['b'], d['F'])
        for key in ('J', 'P', 'D', 'K'):
            lhs, terms = ct[key]; w = fit_lin(lhs, terms)
            chk('bit', w == PRED[key], 'seed %d, %s part: %s with (c) = %s (predicted %s)' % (seed, key, NAMES[key], w and [str(x) for x in w], [str(x) for x in PRED[key]]))
        lhs, terms = ct['J']
        chk('ctl', fit_lin(lhs, terms[:1]) is None and not allzero(ct['Th']), 'seed %d: with P-part torsion T^ != 0 the J equation without the T^ f terms has no solution (ok): torsion changes the components as predicted' % seed)
    tick('part 2')

# ------------------------------------------------------------------------------------------------ part 3: torsion-free frame, b = 0, f = S e with S symmetric (not Schouten)
def S_forms(C, e, Sm):
    Fm = C.Gv.Fm; f = []
    for a in range(4):
        form = {}
        for bb in range(4):
            if Sm[(a, bb)]: form = Fm.add(form, fmul0(scale(Sm[(a, bb)], C.eta(a, a)), e[bb]))
        f.append(form)
    return f
def part3(C):
    head('Part 3. Torsion-free random frame (A3 omega 2-jet), b = 0, f^a = S^a_b e^b with a random SYMMETRIC polynomial S (not Schouten): the reduced identities at the point')
    e = rand_frame(random.Random(5), 4, 2, 3); Sk = koszul_S(4, SQ4, C.Ll); om = omega_closed_form(C.Gl, e, Sk, 4, 2)[0]; Fm = C.Gv.Fm
    rng = random.Random(31); Sm = {}
    for a in range(4):
        for bb in range(a, 4):
            Sm[(a, bb)] = {k: F(rng.randint(-3, 3), rng.randint(1, 3)) for k in ((0, 0, 0, 0), (1, 0, 0, 0), (0, 0, 1, 0), (0, 1, 0, 1))}
            Sm[(bb, a)] = Sm[(a, bb)]
    for label, Smat, sym in (('symmetric S', Sm, True), ('S + antisymmetric part', {k: (padd(v, const(4, {(0, 1): 1, (1, 0): -1, (2, 3): 2, (3, 2): -2}.get(k, 0))) if k in ((0, 1), (1, 0), (2, 3), (3, 2)) else v) for k, v in Sm.items()}, False)):
        f = S_forms(C, e, Smat)
        with trunc(4, xdeg=2):
            A = compose(C, om, e, f); Fx = curvature6(C, A)
            ct = comp_terms(C, om, e, f, None, Fx)
        Th0 = at_pt([ftrunc(x, 1, 4) for x in ct['Th']]); T1 = all(fzero(ftrunc(x, 1, 4)) for x in ct['Th'])
        G0 = fzero(ct['G'])
        J0 = at_pt(ct['J'][0]); Jr = at_pt(ct['J'][1][0]); P0 = at_pt(ct['P'][1][1]); D0 = at_pt([ct['eC']]); K0 = at_pt(ct['K'][0]); Kr = at_pt(ct['K'][1][1])
        nzJ = sum(len(x) for x in J0); nzK = sum(len(x) for x in K0)
        if sym:
            chk('bit', T1 and G0, '%s: T^ = T = 0 to first order (A3 omega) and G = -S_ab e^a e^b = 0 identically' % label)
            chk('bit', J0 == Jr and nzJ > 0, '%s: D_L W^{ab} = e^a C^b - e^b C^a at the point (%d nonzero 3-form components)' % (label, nzJ))
            chk('bit', all(not x for x in P0) and all(not x for x in D0), '%s: (W.e)^a = 0 (algebraic Bianchi of W, all 4 x 4 components) and eta_ab e^a C^b = 0 (the Cotton-type 2-form has no totally antisymmetric part) at the point' % label)
            chk('bit', K0 == Kr and nzK > 0, '%s: D_L C^a = (W.f)^a at the point (%d nonzero components; no torsion needed: b = G = 0)' % (label, nzK))
        else:
            chk('ctl', not G0 and (J0 != Jr or any(D0)), '%s: G != 0 and the reduced forms fail (D_L W != e C - e C or e.C != 0) (ok)' % label)
    tick('part 3')

# ------------------------------------------------------------------------------------------------ part 4: frames with f = Schouten (frame 4-jets), [std] second-order Christoffel route
def engine_data_k(C, e, deg=3):
    """[bit] h5l_frames' engine_data with omega a deg-jet: R, frame R^{ab}_{cd}, Schouten S_bd = (1/2)(Ric - Rs eta/6) and f^a = S^a_b e^b as (deg-1)-jets"""
    Gl = C.Gl; Sk = koszul_S(4, SQ4, C.Ll); dR = deg - 1; Fm = Gl.Fm
    om = omega_closed_form(Gl, e, Sk, 4, deg)[0]
    with trunc(4, xdeg=dR):
        R = Gl.curvature(om); E, det = inverse_series(frame_matrix(e, 4), 4, 4, dR); Rup = {}
        for A4, (a, b) in enumerate(C.pairs4):
            for c in range(4):
                for d in range(4):
                    t = {}
                    if c != d:
                        for (mu, nu) in MUNU:
                            p = R[A4].get((1 << mu) | (1 << nu), {})
                            if p: t = padd(t, pm(p, padd(pm(E[mu][c], E[nu][d]), pm(E[nu][c], E[mu][d]), -1)))
                    Rup[(a, b, c, d)] = t; Rup[(b, a, c, d)] = scale(t, -1)
        Ric = {(b, d): scale(lin(*[(F(1), Rup[(a, b, a, d)]) for a in range(4) if a != b]), SQ4[b]) for b in range(4) for d in range(4)}
        Rs = lin(*[(F(SQ4[b]), Ric[(b, b)]) for b in range(4)])
        Sch = {(b, d): lin((F(1, 2), Ric[(b, d)]), (F(-1, 12) * (SQ4[b] if b == d else 0), Rs)) for b in range(4) for d in range(4)}
        f = []
        for a in range(4):
            form = {}
            for b in range(4):
                cf = scale(Sch[(a, b)], SQ4[a])
                if cf: form = Fm.add(form, fmul0(cf, ftrunc(e[b], dR)))
            f.append(ftrunc(form, dR))
    return dict(om=om, R=R, Sch=Sch, f=f)
def std_route2(e, sq=SQ4, n=4):
    """[std] own Christoffel route (metric 4-jet): Gamma 3-jet, Riemann 2-jet, Schouten 2-jet, Weyl 1-jet, Cotton 2-form 1-jet; at the point:
       d_nabla Weyl, dx^Cot - Cot^dx, d_nabla Cot, Weyl^S (all coordinate components)"""
    g = std_metric(e, n, sq, n, 4); gi, g0, g0i = std_inverse_metric(g, n, n, 3)
    dg = {(k, a, b): sp_der(g[(a, b)], k) for k in range(n) for a in range(n) for b in range(n)}
    Gam = {}
    for l in range(n):
        for m in range(n):
            for v in range(m, n):
                t = {}
                for s in range(n):
                    br = sp_add(sp_add(dg[(m, s, v)], dg[(v, s, m)]), dg[(s, m, v)], -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, 3, n), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    Riem = {}
    for r in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(m + 1, n):
                    t = sp_add(sp_der(Gam[(r, v, s)], m), sp_der(Gam[(r, m, s)], v), -1)
                    for l in range(n): t = sp_add(sp_add(t, sp_mul(Gam[(r, m, l)], Gam[(l, v, s)], 2, n)), sp_mul(Gam[(r, v, l)], Gam[(l, m, s)], 2, n), -1)
                    t = {k: c for k, c in t.items() if sum(k) <= 2}; Riem[(r, s, m, v)] = t; Riem[(r, s, v, m)] = scale(t, -1)
            for m in range(n): Riem[(r, s, m, m)] = {}
    Ric = {(s, v): lin(*[(F(1), Riem[(r, s, r, v)]) for r in range(n)]) for s in range(n) for v in range(n)}
    Rs = lin(*[(F(1), sp_mul(gi[(s, v)], Ric[(s, v)], 2, n)) for s in range(n) for v in range(n)])
    Sch = {(m, v): lin((F(1, 2), Ric[(m, v)]), (F(-1, 12), sp_mul(Rs, g[(m, v)], 2, n))) for m in range(n) for v in range(n)}
    Smix = {(r, v): lin(*[(F(1), sp_mul(gi[(r, s)], Sch[(s, v)], 2, n)) for s in range(n)]) for r in range(n) for v in range(n)}
    d1 = lambda p: {k: c for k, c in p.items() if sum(k) <= 1}
    W = {}
    for r in range(n):
        for s in range(n):
            for (m, v) in MUNU:
                t = d1(Riem[(r, s, m, v)])
                if r == m: t = sp_add(t, d1(Sch[(s, v)]), -1)
                if r == v: t = sp_add(t, d1(Sch[(s, m)]))
                t = sp_add(sp_add(t, sp_mul(g[(s, v)], Smix[(r, m)], 1, n), -1), sp_mul(g[(s, m)], Smix[(r, v)], 1, n))
                W[(r, s, m, v)] = t; W[(r, s, v, m)] = scale(t, -1)
            for m in range(n): W[(r, s, m, m)] = {}
    Cot = {}
    for r in range(n):
        for (m, v) in MUNU:
            t = sp_add(sp_der(Smix[(r, v)], m), sp_der(Smix[(r, m)], v), -1)
            for k in range(n): t = sp_add(sp_add(t, sp_mul(Gam[(r, m, k)], Smix[(k, v)], 1, n)), sp_mul(Gam[(r, v, k)], Smix[(k, m)], 1, n), -1)
            t = d1(t); Cot[(r, m, v)] = t; Cot[(r, v, m)] = scale(t, -1)
        for m in range(n): Cot[(r, m, m)] = {}
    a0 = lambda p: at0(p, n); G0 = {k: a0(p) for k, p in Gam.items()}
    W0 = {k: a0(p) for k, p in W.items()}; C0 = {k: a0(p) for k, p in Cot.items()}; S0 = {k: a0(p) for k, p in Smix.items()}
    Clow = {(s, m, v): sum(g0[s][k] * C0[(k, m, v)] for k in range(n)) for s in range(n) for m in range(n) for v in range(n)}
    dW, rW, dC, rC = {}, {}, {}, {}
    for (l, m, v) in LMV:
        cyc = [(l, m, v), (m, v, l), (v, l, m)]
        for r in range(n):
            for s in range(n):
                dW[(r, s, l, m, v)] = sum(a0(sp_der(W[(r, s, y, z)], x)) + sum(G0[(r, x, k)] * W0[(k, s, y, z)] - G0[(k, x, s)] * W0[(r, k, y, z)] for k in range(n)) for (x, y, z) in cyc)
                rW[(r, s, l, m, v)] = sum((Clow[(s, y, z)] if r == x else 0) - g0[s][x] * C0[(r, y, z)] for (x, y, z) in cyc)
            dC[(r, l, m, v)] = sum(a0(sp_der(Cot[(r, y, z)], x)) + sum(G0[(r, x, k)] * C0[(k, y, z)] for k in range(n)) for (x, y, z) in cyc)
            rC[(r, l, m, v)] = sum(sum(W0[(r, s, y, z)] * S0[(s, x)] for s in range(n)) for (x, y, z) in cyc)
    return dict(g0=g0, g0i=g0i, W0=W0, C0=C0, dW=dW, rW=rW, dC=dC, rC=rC, Cot1=Cot)
def part4(C):
    head('Part 4. Frames with f = Schouten, b = 0 (frame 4-jets, A3 omega 3-jet): full D_A F = 0 at the point; D_L W = e^C - e^C and D_L C = W.f; [std] second-order Christoffel route')
    from h5l_frames import ks_frame_jetK
    p7 = (2, 3, 6); Fm = C.Gv.Fm
    frames = [('Schwarzschild M = 1, rho = 7', ks_frame_jetK(p7, 7, 1, order=4), 'C0'), ('SdS M = 1, H2 = 1/5, rho = 7', ks_frame_jetK(p7, 7, 1, F(1, 5), order=4), 'C0'),
              ('RN M = 1, s = 1/2, rho = 7', ks_frame_jetK(p7, 7, 1, 0, F(1, 2), order=4), 'DC0'), ('random frame seed 5', rand_frame(random.Random(5), 4, 2, 3), 'all')]
    for name, e, cz in frames:
        d = engine_data_k(C, e, 3); om2 = [ftrunc(x, 2) for x in d['om']]; e2 = [ftrunc(x, 2) for x in e]
        with trunc(4, xdeg=1):
            A = compose(C, om2, e2, d['f']); Fx = curvature6(C, A)
            DF = D_full(C, A, Fx); ct = comp_terms(C, om2, e2, d['f'], None, Fx)
        chk('bit', all(not x for x in at_pt(DF)), '%s: the full D_A F = 0 at the point (15 x 4 components; jets consistent)' % name)
        J0 = at_pt(ct['J'][0]); Jr = at_pt(ct['J'][1][0]); K0 = at_pt(ct['K'][0]); Kr = at_pt(ct['K'][1][1])
        C1zero = all(fzero(ftrunc(x, 1)) for x in ct['C']); nzJ = sum(len(x) for x in J0); nzK = sum(len(x) for x in K0); nzC = sum(1 for x in at_pt(ct['C']) for v in x.values())
        if cz == 'C0':
            chk('bit', C1zero and nzJ == 0 and nzK == 0, '%s: Cotton 2-form = 0 as a 1-jet, so D_L W = 0 at the point (all 24 components) and D_L C = 0 = W.f' % name)
        else:
            chk('bit', J0 == Jr and nzJ > 0 and nzC > 0, '%s: Cotton != 0 (%d components at the point) and D_L W^{ab} = e^a C^b - e^b C^a != 0 (%d nonzero 3-form components)' % (name, nzC, nzJ))
            if cz == 'DC0':
                chk('bit', K0 == Kr and nzK == 0, '%s: D_L C^a = (W.f)^a holds with BOTH sides zero at the point (finding): the Weyl 2-form and the Schouten '
                    'tensor are diagonal in the same static frame, so W^a_b ^ S^b = 0 and the Cotton 2-form is covariantly closed here' % name)
            else:
                chk('bit', K0 == Kr and nzK > 0, '%s: D_L C^a = (W.f)^a at the point (%d nonzero components)' % (name, nzK))
            chk('ctl', nzJ > 0, '%s: "D_L W = 0" (the vacuum form) fails here (ok)' % name)
        st = std_route2(e)
        chk('std', st['dW'] == st['rW'] and st['dC'] == st['rC'], '%s: [std] Christoffel route: d_nabla Weyl^rho_sigma = dx^rho ^ Cot_sigma - dx_sigma ^ Cot^rho and d_nabla Cot^rho = Weyl^rho_sigma ^ S^sigma (all components; nonzero dW: %d, dC: %d)'
            % (name, sum(1 for v in st['dW'].values() if v), sum(1 for v in st['dC'].values() if v)))
        e0 = [[at0(e[a].get(1 << mu, {}), 4) for mu in range(4)] for a in range(4)]; gi = st['g0i']
        Wfr = lambda a, b, key: sum(e0[a][r] * e0[b][k] * gi[k][s] * key(r, s) for r in range(4) for s in range(4) for k in range(4))
        okW = all(at0(ct['W'][A4].get(mask(*mn), {}), 4) == Wfr(a, b, lambda r, s: st['W0'][(r, s) + mn]) for A4, (a, b) in enumerate(C.pairs4) for mn in MUNU)
        okDW = all(J0[A4].get(mask(*lmv), F(0)) == Wfr(a, b, lambda r, s: st['dW'][(r, s) + lmv]) for A4, (a, b) in enumerate(C.pairs4) for lmv in LMV)
        okDC = all(K0[a].get(mask(*lmv), F(0)) == sum(e0[a][r] * st['dC'][(r,) + lmv] for r in range(4)) for a in range(4) for lmv in LMV)
        chk('bit==std', okW and okDW and okDC, '%s: the engine\'s Lorentz part W^{ab}, D_L W^{ab} and D_L C^a at the point = e^a_rho e^b_kappa g^{kappa sigma} (Weyl, d_nabla Weyl)^rho_sigma and e^a_rho d_nabla Cot^rho of the std route' % name)
    tick('part 4')

# ------------------------------------------------------------------------------------------------ part 5: the sign of b under e -> Omega e
def part5(C, seed=21):
    head('Part 5. The sign of b: e\' = (1 + lam sig) e, f\' = (1 - lam sig) f, omega\' = omega, b\' = b + k lam d sig (first order in lam): F\' - F = lam sig [D, F] iff k = -1')
    rng = random.Random(seed); n = 4; nv = 5; Fm = C.Gv.Fm
    lift = lambda X: {m: {k + (0,): v for k, v in p.items()} for m, p in X.items()}
    om = [lift(A2B.s_form(rng, n, 1, 1, 5)) for _ in range(6)]; e = [lift(A2B.s_form(rng, n, 1, 1, 5)) for _ in range(n)]
    f = [lift(A2B.s_form(rng, n, 1, 1, 5)) for _ in range(n)]; b = lift(A2B.s_form(rng, n, 1, 1, 5)); sig = {k + (0,): v for k, v in A2B.s_poly(rng, n, 2, 5).items()}
    lam = var(nv, 4); ls = pm(lam, sig); dsig = Fm.d({0: sig}); ldsig = Fm.wedge({0: lam}, dsig)
    with trunc(n, lam=1):
        F0 = curvature6(C, compose(C, om, e, f, b))
        e1 = [Fm.add(x, fmul0(ls, x)) for x in e]; f1 = [Fm.add(x, fmul0(ls, x), -1) for x in f]
        Fk = {k: curvature6(C, compose(C, om, e1, f1, Fm.add(b, ldsig, k))) for k in (0, 1)}
        dec = decompose(C, F0); DF = compose(C, [{}] * 6, dec['P'], [Fm.scale(x, -1) for x in dec['K']])      # [D, F] = T^ P - C K
        target = [fmul0(ls, x) for x in DF]
    lhs0 = [Fm.add(x, y, -1) for x, y in zip(Fk[0], F0)]; slope = [Fm.add(x, y, -1) for x, y in zip(Fk[1], Fk[0])]
    k = fit_lin([Fm.add(t, l0, -1) for t, l0 in zip(target, lhs0)], [slope])
    chk('bit', k == [F(-1)], 'the engine (left action A^g = Ad(g) A - dg g^-1, g = exp(sig D), [D, P] = P, [e] = +1): covariance F\' = F + lam sig [D, F] holds for ONE k = %s on all 15 components: '
        'e -> Omega e needs b -> b - d ln Omega, the law (2.9d) T = DV + b^V requires' % (k and k[0]))
    chk('ctl', not allzero([Fm.add(Fm.add(Fk[1][i], F0[i], -1), target[i], -1) for i in range(15)]), 'b -> b + d ln Omega (k = +1, the law of (A.8) read in the variables of (2.9)) breaks covariance (ok)')
    tick('part 5')

def main():
    C = Conf()
    fields = part1(C, (101, 102, 103)); part2(C, fields); part3(C); part4(C); part5(C)
    finish('H5L-B')

if __name__ == '__main__': main()
