#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""D2.  Linearised gravity: the symbol of E^(1) on the frame perturbation.   python3 d2_linearised.py [n ...]   (default 3 4 5)

 Frame e^a = dx^a + lam h^a_mu(x) dx^mu (all n^2 components), signature (+,-,..), c = 0; every product of the engine cut at lam^1 (b1lib.trunc).
 [bit]  M: the map from the second derivatives d_r d_s h^b_nu (one engine run per monomial h^b_nu = x^r x^s) to the components of E_a^(1) at the origin
        (closed-form omega of A3, R = d omega + 1/4 [omega, omega], E_a).  sigma(k) A = M(A k k): the symbol at an integer covector k.
 [std]  textbook linearised Einstein tensor of s_{mu nu} = eta_mm h^m_nu + eta_nn h^n_mu (second derivatives, exact); the Fierz-Pauli symbol in k-space
        (exact and numpy); the de Donder identity G - GF = -(1/2) box (s - (1/2) eta tr s); constraint and Dirac counting.
 Parts: 1 the map M (all k): rank n(n+1)/2, kernel = Lorentz + diffeomorphisms + (Weyl dimension);  2 sigma(k) at null and non-null integer covectors:
        kernel = gauge exactly off the cone, n(n-3)/2 more on it;  3 gauge-fixed symbol, det = (-k^2/2)^{n(n+1)/2} (1 - n/2);  4 polarisation basis at null k
        (exported for D3);  5 a finite local Lorentz map of the flat frame stays pure gauge at lam^2 (imports A5; reads the quadratic term of R).
 Controls: Maxwell-type symbol; Einstein trace coefficient 1; the trace term of the linearised Ricci tensor dropped; non-null covectors; a wrong
 de Donder coefficient; the Cayley series cut at lam^1."""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
from a5_lorentz_covariance import rand_antisym_jet

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
PRIME = 2 ** 31 - 1

# ------------------------------------------------------------------------------------------------ small exact linear algebra
def rank_mod(rows, p=PRIME):
    """rank over Z/p of an integer matrix: a LOWER bound of the rank over Q (equality certifies full rank)"""
    M = np.array([[int(x) % p for x in r] for r in rows], dtype=np.int64); rk = 0          # entries < 2^31: products < 2^62 fit in int64
    for c in range(M.shape[1] if M.size else 0):
        nzr = np.nonzero(M[rk:, c])[0]
        if len(nzr) == 0: continue
        piv = rk + int(nzr[0]); M[[rk, piv]] = M[[piv, rk]]; M[rk] = M[rk] * pow(int(M[rk, c]), p - 2, p) % p
        f = M[:, c].copy(); f[rk] = 0; M = (M - np.outer(f, M[rk]) % p) % p; rk += 1
        if rk == M.shape[0]: break
    return rk
def nullspace(rows, ncols):
    """exact basis of {v : rows v = 0} (reduced row echelon form over Q)"""
    M = [[F(x) for x in r] for r in rows]; piv = []; r = 0
    for c in range(ncols):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
    free = [c for c in range(ncols) if c not in piv]; out = []
    for fc in free:
        v = [F(0)] * ncols; v[fc] = F(1)
        for i, pc in enumerate(piv): v[pc] = -M[i][fc]
        out.append(v)
    return out
def matvec(Mrows, v): return [sum(a * b for a, b in zip(row, v) if a and b) for row in Mrows]

# ------------------------------------------------------------------------------------------------ indices
def a_idx(n): return [(b, nu) for b in range(n) for nu in range(n)]                          # A^b_nu, n^2 components
def q_idx(n): return [(b, nu, r, s) for b in range(n) for nu in range(n) for r in range(n) for s in range(r, n)]   # monomial x^r x^s in h^b_nu
def out_idx(n): return [(a, mu) for a in range(n) for mu in range(n)]                         # component of E_a along dx^{hat mu}
def sym_idx(n): return [(m, k) for m in range(n) for k in range(m, n)]
def weights(k, n):
    """coefficient of x^r x^s (r <= s) in (k.x)^2 / 2"""
    return {(r, s): (k[r] * k[s] if r < s else F(k[r] * k[r], 2)) for r in range(n) for s in range(r, n)}

# ------------------------------------------------------------------------------------------------ [bit] the engine's second-derivative map
def engine_column(Gv, S, n, b, nu, ex, NV):
    """[bit] (lam^0, lam^1) components of E_a at the origin for e^a = dx^a + lam delta^a_b x^ex dx^nu"""
    e = [{1 << a: const(NV, 1)} for a in range(n)]
    e[b][1 << nu] = padd(e[b].get(1 << nu, {}), {tuple(ex) + (1,): F(1)})
    with trunc(n, xdeg=1, lam=1):
        om = omega_closed_form(Gv, e, S, NV, 1)[0]; R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(0))
    full = (1 << n) - 1
    return tuple({(a, mu): at_lam(Ea[a].get(full ^ (1 << mu), {}), n, NV, l) for a in range(n) for mu in range(n)} for l in (0, 1))
def engine_map(n):
    """[bit] M[(a, mu)][(b, nu, r, s)] and the flatness flag (lam^0 part zero in every run)"""
    sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); NV = n + 1
    cols = {}; flat = True
    for (b, nu, r, s) in q_idx(n):
        ex = [0] * n; ex[r] += 1; ex[s] += 1
        c0, c1 = engine_column(Gv, S, n, b, nu, ex, NV); flat &= all(v == 0 for v in c0.values()); cols[(b, nu, r, s)] = c1
    M = {o: {q: cols[q][o] for q in cols if cols[q][o] != 0} for o in out_idx(n)}
    return M, flat, (Gv, S, NV)
def low_order_blind(n, ctx, rng):
    """[bit] constants and first derivatives of h do not enter E^(1)(0)"""
    Gv, S, NV = ctx; ok = True
    for _ in range(3):
        b, nu = rng.randrange(n), rng.randrange(n)
        for ex in [[0] * n] + [[int(i == r) for i in range(n)] for r in range(n)]:
            c0, c1 = engine_column(Gv, S, n, b, nu, ex, NV); ok &= all(v == 0 for v in c1.values()) and all(v == 0 for v in c0.values())
    return ok

# ------------------------------------------------------------------------------------------------ [std] textbook linearised Einstein tensor
def std_G_from_sdd(sdd, n, sq, alpha=F(1, 2), ricci_trace=1):
    """[std] G^mu_nu from sdd[(m, k, a, b)] = d_a d_b s_{mk}: R_{rsmv} = 1/2 (s_{rv,sm} + s_{sm,rv} - s_{rm,sv} - s_{sv,rm}), Ric_{sv} = eta^{rr} R_{rsrv},
    G = Ric - alpha eta R (alpha = 1/2 is Einstein; a control changes it).  ricci_trace = 0 drops the -d_s d_v tr s part of Ric (a control)."""
    dd = lambda i, j, a, b: sdd.get((a, b, i, j), 0)
    Rl = {(r, s, m, v): F(1, 2) * (dd(s, m, r, v) + dd(r, v, s, m) - dd(s, v, r, m) - dd(r, m, s, v)) for r in range(n) for s in range(n) for m in range(n) for v in range(n)}
    ric = [[sum(sq[r] * Rl[(r, s, r, v)] for r in range(n)) for v in range(n)] for s in range(n)]
    if ricci_trace != 1:                                                         # Ric contains -(1/2) d_s d_v tr s; replace its coefficient
        tr = lambda i, j: sum(sq[a] * dd(i, j, a, a) for a in range(n))
        ric = [[ric[s][v] + (1 - ricci_trace) * F(1, 2) * tr(s, v) for v in range(n)] for s in range(n)]
    Rs = sum(sq[s] * ric[s][s] for s in range(n))
    return [[sq[m] * (ric[m][v] - (alpha * sq[m] * Rs if m == v else 0)) for v in range(n)] for m in range(n)]
def comp_from_G(Gmix, n): return {(a, mu): -(-1) ** mu * Gmix[mu][a] for a in range(n) for mu in range(n)}
def std_map(n, sq, **kw):
    """[std] the same map M from the textbook formulas (no engine)"""
    cols = {}
    for (b, nu, r, s) in q_idx(n):
        sdd = {}
        for (m, k, w) in ((b, nu, sq[b]), (nu, b, sq[b])):                        # s_{mk} = eta_mm h^m_k + eta_kk h^k_m: only h^b_nu != 0, so s_{b nu} = s_{nu b} = eta_bb x^r x^s
            for (al, be) in ((r, s), (s, r)): sdd[(m, k, al, be)] = sdd.get((m, k, al, be), 0) + w
        cols[(b, nu, r, s)] = comp_from_G(std_G_from_sdd(sdd, n, sq, **kw), n)
    return {o: {q: cols[q][o] for q in cols if cols[q][o] != 0} for o in out_idx(n)}

# ------------------------------------------------------------------------------------------------ gauge subspaces
def lorentz_q(n, sq):
    """second derivatives of h = eps(x) (eta eps antisymmetric): one vector per pair p < q and monomial (r <= s)"""
    out = []
    for p, q in itertools.combinations(range(n), 2):
        for r in range(n):
            for s in range(r, n): out.append({(p, q, r, s): F(sq[p]), (q, p, r, s): F(-sq[q])})
    return out
def diffeo_q(n):
    """h^b_nu = d_nu xi^b with xi^b a cubic monomial"""
    out = []
    for b in range(n):
        for ex in itertools.combinations_with_replacement(range(n), 3):
            al = [0] * n
            for i in ex: al[i] += 1
            v = {}
            for nu in range(n):
                if al[nu]:
                    rest = list(al); rest[nu] -= 1; idx = [i for i in range(n) for _ in range(rest[i])]
                    key = (b, nu, idx[0], idx[1]); v[key] = v.get(key, 0) + F(al[nu])
            out.append(v)
    return out
def apply_map(M, v): return {o: sum(row.get(q, 0) * x for q, x in v.items()) for o, row in M.items()}
def symbol(M, n, k):
    """sigma(k)[(a, mu)][(b, nu)] = sum_{r <= s} M[(a, mu)][(b, nu, r, s)] w_rs(k)"""
    w = weights(k, n); cols = a_idx(n)
    return [[sum(M[o].get((b, nu, r, s), 0) * w[(r, s)] for r in range(n) for s in range(r, n)) for (b, nu) in cols] for o in out_idx(n)]
def gauge_vectors(n, k, sq):
    """A-vectors (index order a_idx): n(n-1)/2 Lorentz (eta A antisymmetric) and n diffeomorphisms A^b_nu = xi^b k_nu"""
    pos = {x: i for i, x in enumerate(a_idx(n))}; out = []
    for p, q in itertools.combinations(range(n), 2):
        v = [F(0)] * (n * n); v[pos[(p, q)]] = F(sq[p]); v[pos[(q, p)]] = F(-sq[q]); out.append(v)
    for b in range(n):
        v = [F(0)] * (n * n)
        for nu in range(n): v[pos[(b, nu)]] = F(k[nu])
        out.append(v)
    return out

# ------------------------------------------------------------------------------------------------ [std] symbols in k-space
def S_of_A(Avec, n, sq):
    pos = {x: i for i, x in enumerate(a_idx(n))}
    return [[sq[m] * Avec[pos[(m, v)]] + sq[v] * Avec[pos[(v, m)]] for v in range(n)] for m in range(n)]
def fierz_pauli_G(S, k, n, sq, alpha=F(1, 2), ricci_trace=1):
    """[std] G^mu_nu of s = S (k.x)^2/2 from the closed form: Ric = 1/2 (k_m (kS)_v + k_v (kS)_m - k^2 S_mv - k_m k_v tr S), G = Ric - alpha eta R"""
    ku = [sq[m] * k[m] for m in range(n)]; k2 = sum(ku[m] * k[m] for m in range(n)); trS = sum(sq[m] * S[m][m] for m in range(n))
    kS = [sum(ku[r] * S[r][v] for r in range(n)) for v in range(n)]
    ric = [[F(1, 2) * (k[m] * kS[v] + k[v] * kS[m] - k2 * S[m][v] - ricci_trace * k[m] * k[v] * trS) for v in range(n)] for m in range(n)]
    Rs = sum(sq[m] * ric[m][m] for m in range(n))
    return [[sq[m] * (ric[m][v] - (alpha * sq[m] * Rs if m == v else 0)) for v in range(n)] for m in range(n)]
def fp_symbol(n, k, sq, **kw):
    """[std] the Fierz-Pauli symbol composed with A -> S (s = g^(1)), in the engine's output components; columns in a_idx order"""
    cols = []
    for i in range(n * n):
        A = [F(0)] * (n * n); A[i] = F(1); c = comp_from_G(fierz_pauli_G(S_of_A(A, n, sq), k, n, sq, **kw), n); cols.append([c[o] for o in out_idx(n)])
    return [list(r) for r in zip(*cols)]
def maxwell_symbol(n, k, sq):
    """[ctl] one Maxwell field per frame index: (Mx A)^a_mu = k^2 A^a_mu - k_mu k^nu A^a_nu"""
    k2 = sum(sq[m] * k[m] * k[m] for m in range(n)); pos = {x: i for i, x in enumerate(a_idx(n))}; rows = []
    for (a, mu) in a_idx(n):
        row = [F(0)] * (n * n); row[pos[(a, mu)]] += k2
        for nu in range(n): row[pos[(a, nu)]] -= k[mu] * sq[nu] * k[nu]
        rows.append(row)
    return rows
def constraint_rows(n, k, sq):
    """functionals on the output components: symmetry G_{mu a} = G_{a mu} and Bianchi k_mu G^mu_a = 0  (G^mu_a = -(-1)^mu comp[(a, mu)])"""
    pos = {x: i for i, x in enumerate(out_idx(n))}; rows = []
    for a in range(n):
        for mu in range(a + 1, n):
            r = [F(0)] * (n * n); r[pos[(a, mu)]] += -sq[mu] * (-1) ** mu; r[pos[(mu, a)]] -= -sq[a] * (-1) ** a; rows.append(r)
    for a in range(n):
        r = [F(0)] * (n * n)
        for mu in range(n): r[pos[(a, mu)]] += -(-1) ** mu * k[mu]
        rows.append(r)
    return rows

# ------------------------------------------------------------------------------------------------ gauge-fixed symbol and polarisations
def gauge_fixed_columns(M, n, sq, k=None, vcoef=F(1, 2)):
    """for each symmetric input S^(mk) (mu <= kappa) and each second-derivative pattern (r <= s) (k=None), or for s = S (k.x)^2/2 (k given):
    the engine's G_lower = eta G^mu_nu (from M, symmetric gauge A = (1/2) eta S) minus the de Donder term GF, and the textbook -(1/2) box sbar.
    Returns a list of (G - GF, -(1/2) box sbar) pairs of dicts over sym_idx."""
    pats = [((r, s), {(r, s): F(1)}) for r in range(n) for s in range(r, n)] if k is None else [('k', weights(k, n))]
    out = []
    for (m0, k0) in sym_idx(n):
        Sm = [[F(0)] * n for _ in range(n)]; Sm[m0][k0] = Sm[k0][m0] = F(1)
        for _, wts in pats:
            A = {}
            for m in range(n):
                for v in range(n):
                    if Sm[m][v]: A[(m, v)] = F(1, 2) * sq[m] * Sm[m][v]
            vec = {(b, nu, r, s): x * w for (b, nu), x in A.items() for (r, s), w in wts.items()}
            comp = apply_map(M, vec); Gm = [[-(-1) ** mu * comp[(a, mu)] for a in range(n)] for mu in range(n)]
            Gl = [[sq[m] * Gm[m][v] for v in range(n)] for m in range(n)]
            dd = {}                                                                # d_r d_s of s_{mk} = Sm (pattern)
            for (r, s), w in wts.items():
                for (al, be) in ((r, s), (s, r)): dd[(al, be)] = dd.get((al, be), 0) + w
            d2 = lambda i, j: dd.get((i, j), 0)
            trS = sum(sq[a] * Sm[a][a] for a in range(n))
            dV = [[sum(sq[r] * d2(m, r) * Sm[r][v] for r in range(n)) - vcoef * d2(m, v) * trS for v in range(n)] for m in range(n)]   # d_m V_v
            divV = sum(sq[m] * dV[m][m] for m in range(n)); box = sum(sq[a] * d2(a, a) for a in range(n))
            GF = {(m, v): F(1, 2) * (dV[m][v] + dV[v][m] - (sq[m] * divV if m == v else 0)) for (m, v) in sym_idx(n)}
            lhs = {(m, v): Gl[m][v] - GF[(m, v)] for (m, v) in sym_idx(n)}
            rhs = {(m, v): -F(1, 2) * box * (Sm[m][v] - (F(1, 2) * sq[m] * trS if m == v else 0)) for (m, v) in sym_idx(n)}
            out.append((lhs, rhs))
    return out
def polarisation_basis(n, k, sq=None):
    """[std] transverse traceless S at a null covector k with k_0 != 0: S symmetric, S_{0 nu} = 0, k^mu S_{mu nu} = 0, eta^{mu nu} S_{mu nu} = 0.
    Returns a list of (S, A) with A^mu_nu = (1/2) eta^{mu mu} S_{mu nu} (the frame perturbation in the symmetric gauge).  n(n-3)/2 elements."""
    sq = sq or LORENTZ(n); idx = sym_idx(n); pos = {x: i for i, x in enumerate(idx)}; rows = []
    def ent(m, v): return pos[(min(m, v), max(m, v))]
    for v in range(n):
        r = [F(0)] * len(idx); r[ent(0, v)] += 1; rows.append(r)
        r = [F(0)] * len(idx)
        for m in range(n): r[ent(m, v)] += sq[m] * k[m]
        rows.append(r)
    r = [F(0)] * len(idx)
    for m in range(n): r[ent(m, m)] += sq[m]
    rows.append(r); out = []
    for vec in nullspace(rows, len(idx)):
        S = [[vec[ent(m, v)] for v in range(n)] for m in range(n)]
        out.append((S, [[F(1, 2) * sq[m] * S[m][v] for v in range(n)] for m in range(n)]))
    return out

# ------------------------------------------------------------------------------------------------ covectors
def covectors(n, rng):
    sq = LORENTZ(n); k2 = lambda k: sum(sq[i] * k[i] * k[i] for i in range(n))
    null = {3: [(5, 3, 4), (13, 5, 12), (5, -4, 3)], 4: [(5, 3, 4, 0), (3, 1, 2, 2), (7, 2, 3, 6), (9, 4, 4, 7), (1, 0, 0, -1)],
            5: [(5, 4, 2, 2, 1), (3, 2, 2, 1, 0), (1, 0, 0, 0, 1)]}[n]
    non = {3: [(1, 0, 0), (0, 1, 0), (2, 1, 1), (1, 2, 3)], 4: [(1, 0, 0, 0), (0, 0, 1, 0), (2, 1, 1, 1), (1, 2, -1, 3), (3, 3, 1, 0)],
           5: [(1, 0, 0, 0, 0), (3, 1, 1, 1, 1), (1, 2, 0, 1, -1)]}[n]
    null, non = [tuple(F(x) for x in k) for k in null], [tuple(F(x) for x in k) for k in non]
    while sum(1 for k in null) < len(null) + 0 or len(null) < {3: 5, 4: 7, 5: 5}[n]:
        v = [rng.randint(-6, 6) for _ in range(n - 1)]; s = sum(x * x for x in v); r = int(round(s ** .5))
        if s and r * r == s: null.append(tuple(F(x) for x in [rng.choice((-1, 1)) * r] + v))
    while len(non) < {3: 7, 4: 8, 5: 5}[n]:
        k = tuple(F(rng.randint(-5, 5)) for _ in range(n))
        if k2(k) != 0: non.append(k)
    assert all(k2(k) == 0 for k in null) and all(k2(k) != 0 for k in non)
    return null, non, k2

# ------------------------------------------------------------------------------------------------ the run
def run_n(n):
    sq = LORENTZ(n); rng = random.Random(70 + n); Nsym = n * (n + 1) // 2; nL = n * (n - 1) // 2; modes = n * (n - 3) // 2
    head('n = %d  PART 1  the map from the second derivatives of h (%d) to E^(1) (%d components): all covectors at once' % (n, len(q_idx(n)), n * n))
    M, flat, ctx = engine_map(n); tick('n=%d engine map, %d runs' % (n, len(q_idx(n))))
    chk('bit', flat, 'n=%d: the lam^0 part of E_a is zero in all %d runs (flat space is a solution)' % (n, len(q_idx(n))))
    chk('bit', low_order_blind(n, ctx, rng), 'n=%d: constants and first derivatives of h give E^(1)(0) = 0 (3 random (b, nu), all monomials of degree <= 1)' % n)
    Ms = std_map(n, sq)
    chk('bit==std', all(M[o] == Ms[o] for o in M), 'n=%d: the engine\'s map equals the textbook linearised Einstein tensor of s = eta h + h^T eta, every entry (%d x %d), comp = -(-1)^mu G^mu_a' % (n, n * n, len(q_idx(n))))
    rows = [[M[o].get(q, 0) for q in q_idx(n)] for o in out_idx(n)]; rk = rank_exact([r[:] for r in rows])
    chk('bit', rk == Nsym, 'n=%d: exact rank of the map = %d = n(n+1)/2 (the image is the symmetric Einstein tensor)' % (n, rk))
    Lq, Dq = lorentz_q(n, sq), diffeo_q(n)
    chk('bit', all(all(x == 0 for x in apply_map(M, v).values()) for v in Lq), 'n=%d: the map vanishes on all %d Lorentz-type second derivatives (eta-antisymmetric in (b, nu)): E^(1) sees h only through s' % (n, len(Lq)))
    chk('bit', all(all(x == 0 for x in apply_map(M, v).values()) for v in Dq), 'n=%d: the map vanishes on all %d diffeomorphism-type second derivatives d_nu d_r d_s xi^b' % (n, len(Dq)))
    qpos = {q: i for i, q in enumerate(q_idx(n))}; G = [[0] * len(qpos) for _ in Lq + Dq]
    for i, v in enumerate(Lq + Dq):
        for q, x in v.items(): G[i][qpos[q]] = int(x)
    grk = rank_mod(G); weyl = n * (n + 1) * (n + 2) * (n - 3) // 12
    chk('bit', grk == len(Lq) + len(Dq), 'n=%d: the %d + %d gauge vectors are independent (rank mod p = %d: full, hence full over Q)' % (n, len(Lq), len(Dq), grk))
    chk('bit', len(qpos) - rk - grk == weyl, 'n=%d: kernel %d = %d (Lorentz) + %d (diffeo) + %d, and %d = n(n+1)(n+2)(n-3)/12 is the dimension of the Weyl space' % (n, len(qpos) - rk, len(Lq), len(Dq), len(qpos) - rk - grk, weyl))
    tick('n=%d part 1' % n)
    # ---------------------------------------------------------------------------------------------- part 2
    null, non, k2 = covectors(n, rng)
    head('n = %d  PART 2  the symbol sigma(k) on the %d components of e^(1), at %d null and %d non-null integer covectors' % (n, n * n, len(null), len(non)))
    ok = {k_: True for k_ in ('gauge_in_ker', 'gauge_rank', 'rank_non', 'rank_null', 'fp', 'constraints', 'cons_rank', 'numpy')}
    ctl = {k_: [0, 0] for k_ in ('c1 Maxwell-type: extra kernel at null k is n(n-2), not n(n-3)/2', 'c1 Maxwell-type: Lorentz directions not in its kernel',
                                 'c2 trace coefficient 1: differs from the engine', 'c2 trace coefficient 1: Bianchi condition violated',
                                 'c3 Ricci trace term dropped: diffeomorphisms leave the kernel', 'c4 non-null covector: no extra kernel (n(n-3)/2 modes absent)')}
    blind_c2 = True; extra_null = set(); ranks = {}
    for k in null + non:
        isnull = k2(k) == 0; sig = symbol(M, n, k); r = rank_exact([x[:] for x in sig]); ranks[k] = r
        gv = gauge_vectors(n, k, sq); ok['gauge_in_ker'] &= all(all(x == 0 for x in matvec(sig, v)) for v in gv)
        gr = rank_exact([v[:] for v in gv]); ok['gauge_rank'] &= (gr == nL + n)
        extra = n * n - r - gr
        if isnull: ok['rank_null'] &= (r == n); extra_null.add(extra)
        else:
            ok['rank_non'] &= (r == nL); ctl['c4 non-null covector: no extra kernel (n(n-3)/2 modes absent)'][1] += 1
            ctl['c4 non-null covector: no extra kernel (n(n-3)/2 modes absent)'][0] += int(extra == 0)
        ok['fp'] &= (sig == fp_symbol(n, k, sq))
        cr = constraint_rows(n, k, sq); cols = [list(c) for c in zip(*sig)]
        ok['constraints'] &= all(all(x == 0 for x in matvec(cr, c)) for c in cols); ok['cons_rank'] &= rank_exact([x[:] for x in cr]) == nL + n
        fpf = np.array([[float(x) for x in row] for row in fp_symbol(n, k, sq)]); ok['numpy'] &= int(np.linalg.matrix_rank(fpf, tol=1e-9 * max(1.0, np.abs(fpf).max()))) == r
        # controls
        mx = maxwell_symbol(n, k, sq); rmx = rank_exact([x[:] for x in mx]); mxg = [[F(int(i == a) * k[nu]) for (i, nu) in a_idx(n)] for a in range(n)]
        if isnull:
            ctl['c1 Maxwell-type: extra kernel at null k is n(n-2), not n(n-3)/2'][1] += 1
            ctl['c1 Maxwell-type: extra kernel at null k is n(n-2), not n(n-3)/2'][0] += int(n * n - rmx - rank_exact([v[:] for v in mxg]) == n * (n - 2) != modes)
        ctl['c1 Maxwell-type: Lorentz directions not in its kernel'][1] += 1
        ctl['c1 Maxwell-type: Lorentz directions not in its kernel'][0] += int(any(any(x != 0 for x in matvec(mx, v)) for v in gv[:nL]))
        s2 = fp_symbol(n, k, sq, alpha=F(1)); ctl['c2 trace coefficient 1: differs from the engine'][1] += 1; ctl['c2 trace coefficient 1: differs from the engine'][0] += int(s2 != sig)
        ctl['c2 trace coefficient 1: Bianchi condition violated'][1] += 1
        ctl['c2 trace coefficient 1: Bianchi condition violated'][0] += int(any(any(x != 0 for x in matvec(cr[nL:], c)) for c in [list(c) for c in zip(*s2)]))
        blind_c2 &= (rank_exact([x[:] for x in s2]) == r)
        if not isnull:
            s3 = fp_symbol(n, k, sq, ricci_trace=0); ctl['c3 Ricci trace term dropped: diffeomorphisms leave the kernel'][1] += 1
            ctl['c3 Ricci trace term dropped: diffeomorphisms leave the kernel'][0] += int(any(any(x != 0 for x in matvec(s3, v)) for v in gv[nL:]))
    chk('bit', ok['gauge_in_ker'], 'n=%d: at every covector the %d Lorentz directions (eta A antisymmetric) and the %d diffeomorphisms A^b_nu = xi^b k_nu are in the kernel' % (n, nL, n))
    chk('bit', ok['gauge_rank'], 'n=%d: these %d gauge vectors are independent at every covector used' % (n, nL + n))
    chk('bit', ok['rank_non'], 'n=%d: at all %d non-null covectors rank sigma(k) = %d = n(n-1)/2: the kernel is exactly the gauge (ranks %s)' % (n, len(non), nL, sorted(set(ranks[k] for k in non))))
    chk('bit', ok['rank_null'], 'n=%d: at all %d null covectors rank sigma(k) = %d = n (ranks %s)' % (n, len(null), n, sorted(set(ranks[k] for k in null))))
    chk('bit', extra_null == {modes}, 'n=%d: kernel modulo gauge at a null covector = %s, n(n-3)/2 = %d (counted as n^2 - rank - rank(gauge), gauge inside the kernel)' % (n, sorted(extra_null), modes))
    if n == 3: chk('bit', all(ranks[k] == nL for k in null + non), 'n=3: the rank is %d at null and non-null covectors alike: the gauge-invariant symbol does not see the null cone at n = 3 (no modes)' % nL)
    chk('bit', ok['constraints'], 'n=%d: the image satisfies the %d symmetry conditions G_{mu a} = G_{a mu} and the %d Bianchi conditions k_mu G^mu_a = 0' % (n, nL, n))
    chk('bit', ok['cons_rank'] and Nsym - n - n == modes, 'n=%d: the %d conditions are independent; Dirac count n(n+1)/2 - n (gauge) - n (constraints) = %d = the null-cone kernel' % (n, nL + n, Nsym - 2 * n))
    chk('bit==std', ok['fp'], 'n=%d: sigma(k) equals the Fierz-Pauli symbol composed with A -> S = eta A + A^T eta, every entry, every covector (exact)' % n)
    chk('std', ok['numpy'], 'n=%d: numpy SVD ranks of the Fierz-Pauli symbol equal the exact ranks at every covector' % n)
    chk('bit', blind_c2, 'n=%d: FINDING: the wrong Einstein trace coefficient (Ric - eta R) has the SAME rank as the engine at every covector: the count and the cone cannot see it' % n)
    tick('n=%d part 2' % n)
    # ---------------------------------------------------------------------------------------------- part 3
    head('n = %d  PART 3  gauge-fixed symbol on the %d symmetric components (de Donder): G - GF = -(1/2) k^2 (S - (1/2) eta tr S), det = (-k^2/2)^%d (1 - n/2)' % (n, Nsym, Nsym))
    pairs = gauge_fixed_columns(M, n, sq)
    chk('bit==std', all(l == r_ for l, r_ in pairs), 'n=%d: G (engine) - GF = -(1/2) box (s - (1/2) eta tr s) on all %d (input, second-derivative pattern) pairs: an identity for every covector' % (n, len(pairs)))
    okdet = True; nz_off = True
    for k in null + non:
        cols = gauge_fixed_columns(M, n, sq, k=k); Mat = [[c[0][o] for c in cols] for o in sym_idx(n)]
        d = det_inv(Mat)[0]; okdet &= (d == (-k2(k) / 2) ** Nsym * (1 - F(n, 2))); nz_off &= ((d == 0) == (k2(k) == 0))
    chk('bit', okdet, 'n=%d: exact det of the gauge-fixed symbol = (-k^2/2)^%d (1 - n/2) at all %d covectors' % (n, Nsym, len(null) + len(non)))
    chk('bit', nz_off, 'n=%d: it vanishes at every null covector and at no non-null one: characteristic cone = null cone (reduced polynomial k^2, hyperbolic by T18(f))' % n)
    bad = gauge_fixed_columns(M, n, sq, vcoef=F(1)); kx = non[2]; cb = gauge_fixed_columns(M, n, sq, k=kx, vcoef=F(1))
    dbad = det_inv([[c[0][o] for c in cb] for o in sym_idx(n)])[0]
    chk('ctl', not all(l == r_ for l, r_ in bad) and dbad != (-k2(kx) / 2) ** Nsym * (1 - F(n, 2)), 'n=%d: c5 de Donder vector with coefficient 1 instead of 1/2: the identity fails and det at k = %s is %s, not the power of k^2' % (n, [int(x) for x in kx], dbad))
    tick('n=%d part 3' % n)
    # ---------------------------------------------------------------------------------------------- part 4
    head('n = %d  PART 4  polarisations at null covectors (transverse traceless, S_{0 nu} = 0): exported for D3' % n)
    okp = True; okspan = True; okind = True
    for k in null:
        pol = polarisation_basis(n, k, sq); sig = symbol(M, n, k); gv = gauge_vectors(n, k, sq)
        pv = [[A[b][nu] for (b, nu) in a_idx(n)] for (S, A) in pol]
        okp &= len(pol) == modes and all(all(x == 0 for x in matvec(sig, v)) for v in pv)
        rall = rank_exact([v[:] for v in gv + pv]) if pv else rank_exact([v[:] for v in gv])
        okind &= rall == nL + n + modes; okspan &= rall == n * n - rank_exact([x[:] for x in sig])
    chk('bit', okp, 'n=%d: at every null covector the transverse traceless basis has %d elements and lies in the kernel of the engine\'s symbol' % (n, modes))
    chk('bit', okind and okspan, 'n=%d: gauge + polarisations are independent and span the kernel: ker sigma(k) = Lorentz + diffeo + TT at null k' % n)
    if n == 4:
        kd = (F(1), F(-1), F(0), F(0)); pol = polarisation_basis(4, kd)
        print('    D3 export: at k = (1,-1,0,0) (phase t - x^1) the basis is S = %s' % [[[str(x) for x in r] for r in S] for S, _ in pol], flush=True)
    tick('n=%d part 4' % n)
    # ---------------------------------------------------------------------------------------------- part 5
    head('n = %d  PART 5  a finite local Lorentz map of the flat frame stays pure gauge at lam^2 (imports A5; reads the quadratic term of R)' % n)
    Gv, S, NV = ctx; ok5 = True; ctl5 = 0; lamv = var(NV, n); full = (1 << n) - 1
    for t in range({3: 2, 4: 2}.get(n, 1)):
        A_ = rand_antisym_jet(rng, n); X = [[{kk + (0,): v * sq[i] for kk, v in A_[i][j].items()} for j in range(n)] for i in range(n)]
        X2 = [[{} for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for l in range(n):
                    if X[i][l] and X[l][j]: X2[i][j] = sp_add(X2[i][j], sp_mul(X[i][l], X[l][j], 2, n))
        for order in (2, 1):
            e = []
            for a in range(n):
                form = {}
                for b in range(n):
                    p = sp_add(const(NV, 1) if a == b else {}, pm(lamv, X[a][b]) if X[a][b] else {}, 2)
                    if order == 2 and X2[a][b]: p = sp_add(p, pm(pm(lamv, lamv), X2[a][b]), 2)
                    if p: form[1 << b] = p
                e.append(form)
            with trunc(n, xdeg=1, lam=2):
                om = omega_closed_form(Gv, e, S, NV, 1)[0]; R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(0))
            vals = [at_lam(Ea[a].get(full ^ (1 << mu), {}), n, NV, l) for a in range(n) for mu in range(n) for l in (1, 2)]
            if order == 2: ok5 &= all(v == 0 for v in vals)
            else: ctl5 += int(any(v != 0 for v in vals))
    chk('bit', ok5, 'n=%d: e = Lambda dx with Lambda = 1 + 2 lam X + 2 lam^2 X^2 (Cayley transform of lam X(x), X in so(1,n-1), degree 2): E_a = 0 at lam^1 and lam^2' % n)
    chk('ctl', ctl5 == {3: 2, 4: 2}.get(n, 1), 'n=%d: the series cut at lam^1 (Lambda = 1 + 2 lam X, Lorentz only to first order) gives E != 0 at lam^2 in %d of %d samples' % (n, ctl5, {3: 2, 4: 2}.get(n, 1)))
    tick('n=%d part 5' % n)
    return ctl

def main():
    ns = [int(a) for a in sys.argv[1:]] or [3, 4, 5]; allctl = {}
    for n in ns:
        for k, v in run_n(n).items(): allctl[(n, k)] = v
    head('controls of part 2 (a wrong version must fail on every sample where it can be seen)')
    for (n, k), (dif, seen) in allctl.items():
        if k.startswith('c4') and n == 3: chk('ctl', seen > 0 and dif == seen, 'n=3: %s: at n = 3 n(n-3)/2 = 0, so this control cannot separate anything; extra kernel 0 on %d of %d non-null covectors' % (k, dif, seen)); continue
        chk('ctl', dif == seen and seen > 0, 'n=%d: %s: on %d of %d samples' % (n, k, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('D2')
if __name__ == '__main__': main()
