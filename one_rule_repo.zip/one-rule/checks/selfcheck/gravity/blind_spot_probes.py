#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""BLIND-SPOTS.  Three places where a check of the engine cannot see an engine fault, and the reason, checked.   python3 blind_spot_probes.py

 (ii) The Kerr-Schild frames of C2, e^a = dx^a - f l^a l (l = l_mu dx^mu null): the quadratic part Q^{ab} = (1/4) f_{AB}^{ab} omega^A ^ omega^B of the engine's
      curvature lies along l in both pairs of indices, and l is a repeated principal null direction of R; then <R, Q> = <Q, Q> = 0 in the Kretschmann
      contraction, so the engine's Kretschmann scalar cannot see the coefficient of the quadratic term on these frames.
      [bit]  omega = A3 closed form (engine d), Q from the engine's f table, R = d omega + Q (engine), l from the frame data (g2_kerr); the tests: l ^ Q^{ab} = 0
             (to first order), i_l Q^{ab} = 0, l_a Q^{ab} = 0 and l^[a Q^{bc]} = 0 (frame components), R_{abcd} l^a l^c proportional to l_b l_d; l ^ R^{ab} != 0.
      [std]  the Kretschmann scalar by the Christoffel route on the same jets.
      Points: Kerr (M, a) = (5, 3) at 6 points of C2's grid (axis included); Schwarzschild (M = 3/2, a = 0) at 4 points of rho = 3.
      Controls: a 1-form other than l (l with its spatial part reversed); a random polynomial frame with the l of a Kerr point, where none of the tests holds and
      the Kretschmann comparison reads the coefficient of Q.
 (iii) The weak-field frame of D1, e^0 = (1 + lam Phi_t) dt, e^i = (1 - lam Phi_s) dx^i, at lam = 1/7, 1/100, 2/3: the free fall of a particle at rest reads only
      the h entries that act on the time vector; the entry sorted(h)[3] = (A, b) = (gamma_0 gamma_2, gamma_2) acts on a space vector, so a particle at rest never
      reads it and a particle whose velocity has a y component does.
      [bit]  the coordinate acceleration from the engine's omega, h table and inverse frame (d5_perihelion.engine_coord_accel), with the Lie table built in this run.
      [std]  -Gamma^mu_{nu rho} u^nu u^rho of the metric (d5_perihelion.std_coord_accel); the sorted keys of the h table by the commutation rule (no engine).
      Potentials: D1's random cubic potentials (seed 5) with fixed linear parts 2x - 3y + 5z (Phi_t) and x - 2y + 3z (Phi_s), so every gradient component is non-zero.
      Velocities: u = (1, 0, 0, 0) and u = (1, 1/3, -1/4, 1/5) (proportional to a 4-velocity; the identity is quadratic in u); u = (1, 1/3, 0, 1/5) has no y part.
      Controls: the wrong sign (+Gamma u u); the table with that entry removed or sign-changed must fail for the moving particle.
 (iv) The fifth chip of F2 (f2_first_law.fifth_frame, coordinates (v, x, th, ph), e^3 = x^2 sin th dph), at x = 3, 2, 1 on the equator and at x = 3, sin th = 4/5:
      every omega^{a3} is a multiple of e^3, so the products omega^{a3} ^ omega^{b3} that the f entries of the pairs sharing generator 3 multiply vanish, and R is
      the same with and without the sign change of those entries.
      [bit]  the engine's omega and R; R with a copy of the Lie table whose f entries for the pairs sharing generator 3 change sign.
      [std]  the Riemann tensor of the Christoffel route on the same jets, all 256 components; the coframe off the equator (this file's copy of fifth_frame
             with the 2-jet of sin th at th0) equals fifth_frame at sin th0 = 1.
      Kerr-Newman frames (f2_first_law.kn_frame_jet, (M, a, s) = (1, 1/2, 1/8) and (5, 3, 2)): at an equatorial point (z = 0) every omega^{a3} is along e^3 as well
      and R at the point does not change; off the equator (cos th = 3/5) the control: omega^{a3} has parts off e^3 and the changed signs change R.
 Scope: exact fractions at the stated points; it backs no row of the Atlas (the test harness).  Engine faults expected: M1 by the curvature comparisons of (ii) on the
 random frame and of (iv); M3, M4, M5, M7, M8 by the moving particle of (iii); M6 by the Kerr-Newman comparison of (iv); M2 by nothing (no Einstein form is read)."""
import os, sys, random, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import g2_kerr as K
import f2_first_law as F2
from d1_newtonian_limit import frame_num, rand_phi
from d5_perihelion import engine_coord_accel, std_coord_accel

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
SQ = LORENTZ(4)
ANG = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(0), F(1)), (F(1), F(0))), ((F(-5, 13), F(12, 13)), (F(-8, 17), F(15, 17))), ((F(12, 13), F(5, 13)), (F(0), F(1)))]
RS = [F(9), F(1), F(7), F(4), F(1, 2), F(20)]
AXIS = [((F(1), F(0)), (F(1), F(0)))], [((F(-1), F(0)), (F(1), F(0)))]

# ------------------------------------------------------------------------------------------------ shared helpers (exact, at the origin of the jets)
def quad_part(Gv, om):
    """[bit] Q^C = (1/4) f_AB^C omega^A ^ omega^B with the f table of Gv (first-order jets)"""
    Q = [{} for _ in range(Gv.G)]
    with trunc(4, xdeg=1):
        for (A, B), (C, fc) in Gv.L.f.items(): Q[C] = Gv.Fm.add(Q[C], Gv.Fm.wedge(om[A], om[B]), F(fc, 4))
    return Q
def wedge1(Gv, X, Y):
    """X ^ Y to first order in x - p"""
    with trunc(4, xdeg=1): W = Gv.Fm.wedge(X, Y)
    return {m: q for m, q in ((m, {k: v for k, v in p.items() if sum(k) <= 1}) for m, p in W.items()) if q}
def interior0(v, X):
    """i_v X at the point for a 2-form X: components of the 1-form (index j)"""
    out = [F(0)] * 4
    for m, p in X.items():
        i, j = [k for k in range(4) if m >> k & 1]; c = at0(p, 4); out[j] += c * v[i]; out[i] -= c * v[j]
    return out
def parallel(v, w): return all(v[i] * w[j] == v[j] * w[i] for i in range(4) for j in range(4))
def frame_comp(Gv, X, E0):
    """X^{ab}_{cd} at the point in the frame (a, b the bivector pair of the engine, c, d along E_c, E_d)"""
    Rab = Rab_at0(Gv, X, 4)
    return {(a, b, c, d): sum(Rab.get((a, b, m, w), 0) * E0[m][c] * E0[w][d] for m in range(4) for w in range(4))
            for a in range(4) for b in range(4) for c in range(4) for d in range(4)}
def ipK(X, Y): return sum(SQ[k[0]] * SQ[k[1]] * SQ[k[2]] * SQ[k[3]] * X[k] * Y[k] for k in X)
def flipped_lie():
    """a Lie table whose f entries of the pairs of bivectors sharing generator 3 (the last one) change sign"""
    L = Lie(SQ); last = 1 << 3
    for (A, B), (C, f) in list(L.f.items()):
        if L.gens[A] & last and L.gens[B] & last: L.f[(A, B)] = (C, -f)
    return L
def std_point(e):
    """[std] Riemann R^r_{smv}, g0, inverse at the point, by the Christoffel route on the 2-jet of g = e^T eta e"""
    g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); return R1, g0, g0i

# ------------------------------------------------------------------------------------------------ (ii)
def null_tests(Gv, S, e, l_up, l_dn):
    om, R = engine_om_R(Gv, e, S, 4); Q = quad_part(Gv, om); e0, E0, det = E0_of(e, 4, 4)
    lf = {1 << mu: l_dn[mu] for mu in range(4) if l_dn[mu]}
    lu0 = [at0(x, 4) if x else F(0) for x in l_up]; ld0 = [at0(x, 4) if x else F(0) for x in l_dn]
    la = [sum(e0[a][mu] * lu0[mu] for mu in range(4)) for a in range(4)]; la_dn = [SQ[a] * la[a] for a in range(4)]
    Qf, Rf = frame_comp(Gv, Q, E0), frame_comp(Gv, R, E0); rng4 = range(4)
    T = [[sum(SQ[a] * SQ[b] * Rf[(a, b, c, d)] * la[a] * la[c] for a in rng4 for c in rng4) for d in rng4] for b in rng4]
    out = dict(
        lQ=all(not wedge1(Gv, lf, Q[A]) for A in range(Gv.G)),
        iQ=all(all(x == 0 for x in interior0(lu0, Q[A])) for A in range(Gv.G)),
        cQ=all(sum(la_dn[a] * Qf[(a, b, c, d)] for a in rng4) == 0 for b in rng4 for c in rng4 for d in rng4) and
           all(la[a] * Qf[(b, c, x, y)] + la[b] * Qf[(c, a, x, y)] + la[c] * Qf[(a, b, x, y)] == 0 for a, b, c in itertools.combinations(rng4, 3) for x in rng4 for y in rng4),
        lR=any(at0(p, 4) != 0 for A in range(Gv.G) for p in wedge1(Gv, lf, R[A]).values()),
        iR=any(not parallel(interior0(lu0, R[A]), ld0) for A in range(Gv.G)),
        pnd=all(T[b][d] * la_dn[x] * la_dn[y] == T[x][y] * la_dn[b] * la_dn[d] for b in rng4 for d in rng4 for x in rng4 for y in rng4),
        RQ=ipK(Rf, Qf), QQ=ipK(Qf, Qf), Qnz=any(v != 0 for v in Qf.values()),
        Kbit=K.engine_kretschmann(Rab_at0(Gv, R, 4), E0, SQ), Q=Q)
    R1, g0, g0i = std_point(e); out['Kstd'] = K.std_kretschmann(R1, g0, g0i)
    return out

def part_ii(Gv, S):
    head('(ii) C2\'s Kerr-Schild frames: the quadratic part Q = (1/4) f omega omega of the engine\'s R and the null 1-form l; why the Kretschmann contraction cannot see the coefficient of Q')
    grid = K.rational_kerr_points(F(3), RS, ANG) + K.rational_kerr_points(F(3), [F(7)], AXIS[0]) + K.rational_kerr_points(F(3), [F(4)], AXIS[1])
    cases = [('Kerr', F(5), F(3), P) for P in grid[::5]] + [('Schwarzschild', F(3, 2), F(0), P) for P in K.rational_kerr_points(0, [F(3)], ANG)]
    res = []; ctl_other = True
    for (name, M, a, P) in cases:
        e, E, (lu, ld), d = K.kerr_ks_frame_jet(P['p'], M, a, P['r']); r = null_tests(Gv, S, e, lu, ld); res.append(r)
        if name == 'Kerr':
            lo = {1 << mu: (ld[mu] if mu == 0 else scale(ld[mu], -1)) for mu in range(4) if ld[mu]}           # dt - (l_1 dx + l_2 dy + l_3 dz)
            ctl_other &= any(wedge1(Gv, lo, r['Q'][A]) for A in range(Gv.G))
    npt = '%d points (Kerr M = 5, a = 3: 6 points of C2\'s grid, the axis included; Schwarzschild M = 3/2: 4 points of rho = 3)' % len(cases)
    chk('bit', all(r['lQ'] and r['Qnz'] for r in res), '(a) l ^ Q^{ab} = 0 for all six (a, b), to first order in x - p, and Q != 0, at %s' % npt)
    chk('bit', all(r['iQ'] for r in res), '(b) i_l Q^{ab} = 0 with the vector l^mu = eta^{mu nu} l_nu (also g^{mu nu} l_nu): Q^{ab} = l ^ q^{ab} with l . q^{ab} = 0, at the same points')
    chk('bit', all(r['cQ'] for r in res), '(c) in the bivector index as well: l_a Q^{ab}_{cd} = 0 and l^[a Q^{bc]}_{cd} = 0 (frame components, l^a = e^a_mu l^mu, l_a = eta_ab l^b), at the same points')
    chk('bit', all(r['lR'] and r['iR'] for r in res), '(d) R is not of that form: l ^ R^{ab} != 0 and i_l R^{ab} is not along l for some (a, b) at every point, so (a) alone does not make <R, Q> vanish')
    chk('bit', all(r['pnd'] for r in res), '(e) R_{abcd} l^a l^c = lambda l_b l_d at every point (frame components): l is a repeated principal null direction of the engine\'s R')
    chk('bit', all(r['RQ'] == 0 and r['QQ'] == 0 for r in res), '(f) <R, Q> = <Q, Q> = 0 in the Kretschmann contraction at every point (with Q = l ^ X ^ l from (a)-(c), l . l = 0 '
        'gives <Q, Q> = 0 and (e) gives <R, Q> = 0), so K(R + t Q) = K(R) for every t')
    chk('bit==std', all(r['Kbit'] == r['Kstd'] for r in res), 'the engine\'s Kretschmann scalar equals the Christoffel route\'s at the %d points (a comparison that, by (f), passes for any coefficient of Q)' % len(cases))
    chk('ctl', ctl_other, 'a 1-form other than l (dt - l_1 dx - l_2 dy - l_3 dz) in place of l: its wedge with Q is not zero at any of the 6 Kerr points')
    P = grid[0]; e, E, (lu, ld), d = K.kerr_ks_frame_jet(P['p'], F(5), F(3), P['r'])
    rr = [null_tests(Gv, S, rand_frame(random.Random(sd), 4), lu, ld) for sd in (11, 12)]
    chk('ctl', all(not r['lQ'] and not r['iQ'] and not r['cQ'] and not r['pnd'] and r['RQ'] != 0 and r['QQ'] != 0 for r in rr),
        'two random polynomial frames (b1lib.rand_frame, seeds 11, 12; not Kerr-Schild) with the l of the Kerr point %s: (a), (b), (c), (e) all fail and <R, Q> != 0, <Q, Q> != 0' % (pstr(P),))
    chk('bit==std', all(r['Kbit'] == r['Kstd'] for r in rr), 'on those random frames the engine\'s Kretschmann scalar equals the Christoffel route\'s; there <R, Q> != 0, so this comparison reads the coefficient of Q')
    tick('part ii')
def pstr(P): return '(%s)' % ', '.join(str(c) for c in P['p'])

# ------------------------------------------------------------------------------------------------ (iii)
def accel(Gv, S, e, u):
    fr, dEp, _ = engine_coord_accel(Gv, S, e, u); return [x + y for x, y in zip(fr, dEp)]
def lie_with_entry(key, how):
    L = Lie(SQ)
    if key in L.h:
        if how == 'drop': del L.h[key]
        else: c, v = L.h[key]; L.h[key] = (c, -v)
    return L

def part_iii(Gv, S):
    head('(iii) D1\'s weak-field frame: which entries of the h table the free fall of a particle reads (engine acceleration against -Gamma u u)')
    pairs = [(i, j) for i in range(4) for j in range(i + 1, 4)]
    keys = sorted((A, b) for A, (i, j) in enumerate(pairs) for b in (i, j))
    key = keys[3]
    chk('std', key == (1, 2) and pairs[1] == (0, 2), 'the fourth key of the h table in sorted order is (A, b) = (1, 2): the bivector gamma_0 gamma_2 acting on gamma_2, a space vector '
        '(keys by the rule: B_A = gamma_i gamma_j and gamma_b do not commute iff b is i or j; no engine)')
    print('    info: the engine\'s table in this run: sorted(h)[3] = %s -> %s' % ((sorted(Gv.L.h)[3], Gv.L.h[sorted(Gv.L.h)[3]]) if len(Gv.L.h) > 3 else ('-', '-')), flush=True)
    rng = random.Random(5); frames = []
    LIN_T, LIN_S = {(0, 1, 0, 0): F(2), (0, 0, 1, 0): F(-3), (0, 0, 0, 1): F(5)}, {(0, 1, 0, 0): F(1), (0, 0, 1, 0): F(-2), (0, 0, 0, 1): F(3)}
    for lam in (F(1, 7), F(1, 100), F(2, 3)):
        Pt, Ps = rand_phi(rng), rand_phi(rng); Pt.update(LIN_T); Ps.update(LIN_S); frames.append((lam, frame_num(Pt, Ps, lam), Pt, Ps))
    grad_ok = all(at0(sp_der(P_, i), 4) != 0 for (_, _, Pt, Ps) in frames for P_ in (Pt, Ps) for i in (1, 2, 3))
    inv_ok = all(1 + lam * at0(Pt, 4) != 0 and 1 - lam * at0(Ps, 4) != 0 for (lam, _, Pt, Ps) in frames)
    chk('std', grad_ok and inv_ok, 'the three frames (lam = 1/7, 1/100, 2/3; D1\'s random potentials of degree 3, seed 5, with the linear parts 2x - 3y + 5z in Phi_t and x - 2y + 3z in Phi_s) '
        'are invertible at the point and have d_i Phi_t != 0, d_i Phi_s != 0 there for x, y and z, so no comparison below is empty')
    U_REST, U_MOVE, U_NOY = [F(1), F(0), F(0), F(0)], [F(1), F(1, 3), F(-1, 4), F(1, 5)], [F(1), F(1, 3), F(0), F(1, 5)]
    rest = all(accel(Gv, S, e, U_REST) == std_coord_accel(e, U_REST) for (_, e, _, _) in frames)
    move = all(accel(Gv, S, e, U_MOVE) == std_coord_accel(e, U_MOVE) for (_, e, _, _) in frames)
    chk('bit==std', rest, 'particle at rest, u = (1, 0, 0, 0): the engine\'s coordinate acceleration equals -Gamma^mu_{tt}, all four components, at the 3 frames (D1\'s check)')
    chk('bit==std', move, 'moving particle, u = (1, 1/3, -1/4, 1/5): the engine\'s coordinate acceleration equals -Gamma^mu_{nu rho} u^nu u^rho, all four components, at the 3 frames')
    chk('ctl', all(accel(Gv, S, e, u) != [-x for x in std_coord_accel(e, u)] for (_, e, _, _) in frames for u in (U_REST, U_MOVE)),
        'the wrong sign (+Gamma u u) does not match the engine at any frame, at rest or moving')
    Gd, Gs = Grav(4, lie_with_entry(key, 'drop')), Grav(4, lie_with_entry(key, 'flip'))
    blind = all(accel(G_, S, e, u) == accel(Gv, S, e, u) for G_ in (Gd, Gs) for (_, e, _, _) in frames for u in (U_REST, U_NOY))
    chk('bit', blind, 'with the entry (1, 2) removed or its sign changed (in a copy of the table), the acceleration does not change for u = (1, 0, 0, 0) or for u = (1, 1/3, 0, 1/5) '
        '(no y part): a particle at rest, or one without a y velocity, never reads the entry that M3 and M5 change')
    chk('ctl', all(accel(G_, S, e, U_MOVE) != std_coord_accel(e, U_MOVE) for G_ in (Gd, Gs) for (_, e, _, _) in frames),
        'with the entry (1, 2) removed or its sign changed, the moving particle fails -Gamma u u at all 3 frames: the y velocity reads it')
    tick('part iii')

# ------------------------------------------------------------------------------------------------ (iv)
def fifth_frame_off(x0, s0, c0, nv=4):
    """the fifth chip's coframe (as f2_first_law.fifth_frame) with exact 2-jets at (0, x0, th0, 0), sin th0 = s0, cos th0 = c0"""
    x0 = F(x0); dx = var(nv, 1); dth = var(nv, 2); c = x0 + 3; dx2 = sp_mul(dx, dx, 2, nv); o = const(nv, 1)
    T = sp_mul(lin(((x0 - 2) * (x0 + 1), o), (2 * x0 - 1, dx), (F(1), dx2)), lin((1 / c, o), (-1 / c ** 2, dx), (1 / c ** 3, dx2)), 2, nv)
    X2 = lin((x0 * x0, o), (2 * x0, dx), (F(1), dx2)); sth = lin((F(s0), o), (F(c0), dth), (-F(s0) / 2, sp_mul(dth, dth, 2, nv)))
    return [{1: lin((F(1, 2), o), (F(1, 2), T)), 2: o}, {1: lin((F(1, 2), o), (F(-1, 2), T)), 2: const(nv, -1)}, {4: X2}, {8: sp_mul(X2, sth, 2, nv)}]
def a3_study(Gv, Gf, S, e):
    om, R = engine_om_R(Gv, e, S, 4)
    with trunc(4, xdeg=1): Rf = Gf.curvature(om)
    e0, E0, det = E0_of(e, 4, 4); P_ = pairs_of(Gv.L); A3 = [A for A, (a, b) in enumerate(P_) if b == 3]
    off0 = any(sum(at0(om[A].get(1 << mu, {}), 4) * E0[mu][c] for mu in range(4)) != 0 for A in A3 for c in range(3))
    along1 = all(set(om[A]) <= {1 << 3} for A in A3)
    prod0 = all(not wedge1(Gv, om[A], om[B]) for A in A3 for B in A3)
    same0 = all(at0(Rf[A].get(m, {}), 4) == at0(R[A].get(m, {}), 4) for A in range(Gv.G) for m in set(R[A]) | set(Rf[A]))
    same1 = all(Rf[A] == R[A] for A in range(Gv.G))
    R1, g0, g0i = std_point(e); riem = (K.engine_riemann_coord(Rab_at0(Gv, R, 4), e0, E0, SQ) == R1)
    return dict(off0=off0, along1=along1, prod0=prod0, same0=same0, same1=same1, riem=riem)

def part_iv(Gv, S):
    head('(iv) F2\'s fifth chip: every omega^{a3} lies along e^3, so the f entries of the pairs sharing generator 3 multiply zero; Kerr-Newman at and off the equator')
    Gf = Grav(4, flipped_lie())
    nz = lambda X: [{m: q for m, q in ((m, {k: v for k, v in p.items() if v != 0}) for m, p in Xa.items()) if q} for Xa in X]
    chk('std', all(nz(fifth_frame_off(x0, 1, 0)) == nz(F2.fifth_frame(x0)[0]) for x0 in (3, 2, 1)), 'the coframe of this file off the equator (the 2-jet of sin th at th0), '
        'taken at sin th0 = 1, cos th0 = 0, equals f2_first_law.fifth_frame at x = 3, 2, 1: the point sin th = 4/5 below is the same frame off the equator')
    fifth = [a3_study(Gv, Gf, S, F2.fifth_frame(x0)[0]) for x0 in (3, 2, 1)] + [a3_study(Gv, Gf, S, fifth_frame_off(3, F(4, 5), F(3, 5)))]
    where = 'at x = 3, 2, 1 on the equator and at x = 3, sin th = 4/5'
    chk('bit', all(not r['off0'] and r['along1'] for r in fifth), 'fifth chip, %s: each omega^{a3} (a = 0, 1, 2) is a multiple of dph, i.e. of e^3, to first order in the jet' % where)
    chk('bit', all(r['prod0'] for r in fifth), 'fifth chip: omega^{a3} ^ omega^{b3} = 0 for all a, b, to first order, at the 4 points (the products that the f entries of the pairs sharing generator 3 multiply)')
    chk('bit', all(r['same0'] and r['same1'] for r in fifth), 'fifth chip: R with the f entries of the pairs sharing generator 3 sign-changed equals the engine\'s R, every component, to first order, at the 4 points')
    chk('bit==std', all(r['riem'] for r in fifth), 'fifth chip: the engine\'s R^{ab}_{mu nu} equals the Riemann tensor of the Christoffel route, all 256 components, at the 4 points '
        '(a comparison that passes whatever the signs of those f entries)')
    kn = [(F(1), F(1, 2), F(1, 8)), (F(5), F(3), F(2))]
    eq = [a3_study(Gv, Gf, S, F2.kn_frame_jet(P['p'], M, a, s, P['r'])[0]) for (M, a, s) in kn for P in K.rational_kerr_points(a, [F(3)], [((F(0), F(1)), (F(3, 5), F(4, 5)))])]
    offeq = [a3_study(Gv, Gf, S, F2.kn_frame_jet(P['p'], M, a, s, P['r'])[0]) for (M, a, s) in kn for P in K.rational_kerr_points(a, [F(3)], [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5)))])]
    chk('bit', all(not r['off0'] and r['same0'] and not r['same1'] for r in eq), 'Kerr-Newman (M, a, s) = (1, 1/2, 1/8) and (5, 3, 2) at an equatorial point (z = 0, r = 3): every omega^{a3} is along e^3 at '
        'the point and R at the point does not change with the sign-changed entries (only its first-order jet does): an equatorial point does not read these signs either')
    chk('ctl', all(r['off0'] and not r['same0'] for r in offeq), 'Kerr-Newman, the same parameters off the equator (cos th = 3/5, r = 3): some omega^{a3} has parts off e^3 and R at the point changes '
        'with the sign-changed entries (the wrong signs fail)')
    chk('bit==std', all(r['riem'] for r in offeq + eq), 'Kerr-Newman at these 4 points: the engine\'s R^{ab}_{mu nu} equals the Riemann tensor of the Christoffel route, all 256 components '
        '(off the equator this comparison reads the signs of those f entries)')
    tick('part iv')

def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)            # built in this run (an engine fault put into Lie in memory is seen)
    part_ii(Gv, S); part_iii(Gv, S); part_iv(Gv, S)
    finish('BLIND-SPOTS')

if __name__ == '__main__': main()
