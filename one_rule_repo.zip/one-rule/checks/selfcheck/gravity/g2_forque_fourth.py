#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G2-fourth. The tidal forque at the third and fourth order of the body size from the derivatives of the curvature.   python3 g2_forque_fourth.py

A body of mass points m_i at R + eps x_i near a point mass M at the origin (M = 2; R = (3,4,0) and (2,3,6); the bodies of G2); Newton's law
f_i = -M m_i r_i/|r_i|^3 is an input (INP-075).  The force lines summed with exact eps-series (g2_tidal_forque.eps_forque) give the force F^(k) and
the torque tau^(k) about the centre of mass at each order eps^k, k <= 4.  Multipole form:  tau^(k)_a = -eps_abc X_{c b2..bk} M^(k)_{b b2..bk} / (k-1)!,
F^(k)_a = -X_{a b1..bk} M^(k)_{b1..bk} / k!,  with M^(k) the k-th moments of the body and X the tidal tensor E (X_ij = E^i_j) and its derivatives:
the torque at order k reads k - 2 derivatives of E, the force k - 1 (the force at eps^4 reads the third derivative).
[bit]  The Kerr-Schild frame of the point mass as exact 5-jets (h5l_frames.ks_frame_jetK); omega (A3 closed form); R = d omega + 1/4 [omega, omega] (engine);
       the tidal field E^a_c(x) = R^{a0}_{c0}(x) of the observer u = E_0 at rest (frame components, exact 3-jets); three readings of its derivatives:
       (P) partial derivatives in the Kerr-Schild coordinates;  (V) derivatives along the frame vectors E_k, no connection terms;
       (C) covariant derivatives: the engine's D_covector slot by slot (g2_hodge.D_two_index for two indices, D_tensor here for three and four),
           frame components along E_k, symmetrised for the contraction.
       The same with f = lam M/r and every engine product cut at lam^10 (b1lib.trunc): each quantity as an exact polynomial in lam, of degree below the cut.
[std]  The exact Taylor coefficients of Phi = -M/|r| (g2_tidal_forque.phi_taylor), as in G2's multipole route.  The Christoffel route for (C), no engine:
       metric g = eta - 2 f l l, Christoffel symbols, Riemann tensor (MTW sign), E^r_m = R^r_{s m v} U^s U^v with U = E_0, covariant derivatives in
       coordinates, frame components at the point.  The closed forms E_k(E^i_j) = Phi_,ijk + 3 (M/r^2) n_k Phi_,ij and (nabla_n E)^n_n = (1 - M/r) Phi_,rrr.
What the checks state: (P) contracted with the moments gives the summed lines exactly at eps^2, eps^3, eps^4, force and torque (E^i_j(x) = Phi_,ij(x) as
a jet, exactly linear in M).  (C) equals the Christoffel route exactly; its first-order part in M is the Phi derivatives; at M = 2 it is not:
(nabla_k E)^i_j = (1 - M/r) Phi_,ijk exactly (so the force at eps^2 and the torque at eps^3 from nabla E are (1 - M/r) times the summed lines'), and
the symmetrised nabla nabla E and nabla^3 E carry terms of order M^2 to M^4 whose coefficients on the basis Sym(n..), Sym(delta n..), Sym(delta delta n..)
are the table COEF (the same numbers at both points).
Controls: wrong Taylor factors (force 1/6 -> 1/3 and 1/24 -> 1/12, torque 1/2 -> 1 and 1/6 -> 1/3); the repulsive sign; centrally symmetric bodies
(zero at eps^3, not zero at eps^4); the covariant derivative without its connection terms; the Christoffel route without its Christoffel terms.
Scope: a static point mass, the observer at rest in the Kerr-Schild frame, two points, orders eps^2..eps^4, Newton's law by input.
Exports (import-safe): lam_frame(e, KJ), tidal_field(Gv, R, Einv), frame_comp(X, Einv, k), D_tensor(Gv, om, T, r), engine_tidal_derivs(p, rho0, Mc, KJ, lam),
std_tidal_derivs(p, rho0, Mc, KJ, drop_gamma), sym(T, j), nd_basis(n, j), forque_terms(X, body, fF, fT), g2_bodies()."""
import sys, os, time, random, itertools
from math import factorial
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
from fractions import Fraction as F
import g2_tidal_forque as G2T
import g2_hodge as GH
import h5l_frames as HF

SQ = [1, -1, -1, -1]
KJ = 5                                                                           # jet order of the frame: E to degree 3, its third derivative at the point
LAMDEG = 10                                                                      # cut of the bookkeeping parameter (above every degree that occurs)
MC = F(2)
POINTS = [((F(3), F(4), F(0)), F(5)), ((F(2), F(3), F(6)), F(7))]
EPS3 = G2T.EPS3
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
# the order-M^L parts (L >= 2) of the symmetrised covariant derivatives of E in units M^L / r^(L+q+2), on the basis Sym(n^j), Sym(delta n^(j-2)), Sym(delta delta n^(j-4))
# (exact fit at the first point, the same numbers at the second point; checked at both below)
COEF = {2: {2: (225, -189, 18), 3: (-106, 82, -4)}, 3: {2: (-3195, 3462, -711), 3: (3216, -3306, 594), 4: (-918, 846, -96)}}
def nd_basis(n, j):
    """the fully symmetric rank-j arrays built from the unit vector n and delta: Sym(delta^a n^(j-2a)), a = 0..j//2"""
    out = []
    for a in range(j // 2 + 1):
        arr = {}
        for ix in itertools.product(range(3), repeat=j):
            tot = F(0)
            for perm in itertools.permutations(ix):
                v = F(1)
                for t in range(a): v *= (1 if perm[2 * t] == perm[2 * t + 1] else 0)
                for t in range(2 * a, j): v *= n[perm[t]]
                tot += v
            arr[ix] = tot / factorial(j)
        out.append(arr)
    return out

# ------------------------------------------------------------------------------------------------ jets: derivatives at the origin, bookkeeping slot
def _ex(idx, nv, lam=0):
    e = [0] * nv
    for i in idx: e[i + 1] += 1
    if nv == 5: e[4] = lam
    return tuple(e)
def dcoef(p, idx, nv=4, lam=0):
    """partial derivative d_idx (spatial indices 0..2 = x, y, z) at the origin of the jet p (coefficient of lam^lam when nv = 5)"""
    e = _ex(idx, nv, lam); c = p.get(e, F(0))
    for k in e[1:4]: c *= factorial(k)
    return c
def at_pt(p, nv=4, lam=0): return p.get((0, 0, 0, 0) + ((lam,) if nv == 5 else ()), F(0))
def lam_frame(e, KJ):
    """the frame with f -> lam f: e^a = delta^a + lam (e^a - delta^a), lam = exponent slot 4 (nv = 5)"""
    lv = var(5, 4); out = []
    for a, form in enumerate(e):
        new = {}
        for mu in range(4):
            dl = const(5, 1 if a == mu else 0); q = padd(dl, sp_mul(padd(form.get(1 << mu, {}), dl, -1), lv, KJ, 4))
            if q: new[1 << mu] = q
        out.append(new)
    return out

# ------------------------------------------------------------------------------------------------ [bit] the tidal field and its derivatives on the engine
def tidal_field(Gv, R, Einv):
    """E^a_c(x) = R^{a0}_{c0}(x): frame components of the engine's curvature 2-forms for the observer u = E_0 (jets; the active trunc cuts the products)"""
    Et = {}
    for A, (a, b) in enumerate(pairs_of(Gv.L)):
        if a != 0: continue
        for c in range(4):
            t = {}
            for mu in range(4):
                for nu in range(mu + 1, 4):
                    q = R[A].get((1 << mu) | (1 << nu), {})
                    if q: t = padd(t, pm(q, padd(pm(Einv[mu][c], Einv[nu][0]), pm(Einv[nu][c], Einv[mu][0]), -1)))
            if t: Et[(b, c)] = scale(t, -1)                                      # R^{b0} = -R^{0b}
    return Et
def frame_comp(X, Einv, k):
    """X(E_k) = sum_mu X_mu E^mu_k for a 1-form X (jets)"""
    t = {}
    for mu in range(4):
        q = X.get(1 << mu, {})
        if q and Einv[mu][k]: t = padd(t, pm(q, Einv[mu][k]))
    return t
def D_tensor(Gv, om, T, r):
    """D T_{i1..ir} = d T - sum_s omega^b_{i_s} T_{..b..}: the engine's D_covector applied slot by slot to a tensor with r frame indices, all down
    (r = 2 is g2_hodge.D_two_index).  T: {index tuple: polynomial}.  Returns {index tuple: 1-form}."""
    n = Gv.n; Fm = Gv.Fm; Z = lambda p: ({0: p} if p else {})
    out = {ix: Fm.scale(Fm.d(Z(T.get(ix, {}))), -(r - 1)) for ix in itertools.product(range(n), repeat=r)}
    for s in range(r):
        for rest in itertools.product(range(n), repeat=r - 1):
            ixs = [rest[:s] + (a,) + rest[s:] for a in range(n)]
            if not any(T.get(ix) for ix in ixs): continue
            Dc = Gv.D_covector(om, [Z(T.get(ix, {})) for ix in ixs])
            for a, ix in enumerate(ixs): out[ix] = Fm.add(out[ix], Dc[a])
    return {ix: X for ix, X in out.items() if X}
def engine_tidal_derivs(p, rho0, Mc, KJ=KJ, lam=None):
    """[bit] Kerr-Schild frame of mass Mc at p (|p| = rho0 rational) as exact KJ-jets; omega (A3 closed form), R (engine), inverse frame (series);
    E^a_c (jets of degree KJ-2) and its covariant derivatives T[q][(a, c, k1..kq)] = (nabla_kq .. nabla_k1 E)_{ac} (all frame indices down, jets of degree
    KJ-2-q), q = 0..KJ-2.  lam = L: the frame with f -> lam f and every product cut at lam^L (nv = 5).  Also V[(a, c, k)] = E_k(E_ac) (no connection
    terms) and D2 = g2_hodge.D_two_index of E_ac."""
    nv = 4 if lam is None else 5
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    e = HF.ks_frame_jetK(list(p), rho0, M=Mc, order=KJ, nv=nv)
    if lam is not None: e = lam_frame(e, KJ)
    with trunc(4, xdeg=KJ, lam=lam):
        om = omega_closed_form(Gv, e, S, nv, KJ - 1)[0]
        with trunc(4, xdeg=KJ - 1): Einv, det = inverse_series(frame_matrix(e, 4), 4, nv, KJ - 1)
        with trunc(4, xdeg=KJ - 2): R = Gv.curvature(om); Et = tidal_field(Gv, R, Einv)
        El = {(a, c): scale(q, SQ[a]) for (a, c), q in Et.items()}
        T = {0: El}; cur = El
        for q in range(1, KJ - 1):
            with trunc(4, xdeg=KJ - 2 - q):
                DT = D_tensor(Gv, om, cur, q + 1)
                if q == 1:
                    D2 = GH.D_two_index(Gv, om, El, nv); DT1 = DT
                    V = {(a, c, k): frame_comp(Fm.d({0: El[(a, c)]}), Einv, k) for (a, c) in El for k in range(4)}
                cur = {ix + (k,): frame_comp(X, Einv, k) for ix, X in DT.items() for k in range(4)}
                cur = {ix: v for ix, v in cur.items() if v}
            T[q] = cur
    return dict(T=T, Et=Et, V=V, D2=D2, DT1=DT1, nv=nv)

# ------------------------------------------------------------------------------------------------ [std] the Christoffel route (no engine)
def std_tidal_derivs(p, rho0, Mc, KJ=KJ, drop_gamma=False):
    """[std] metric g = eta - 2 f l l (f = Mc/r, l_mu = (1, x/r)) as exact KJ-jets at p; Christoffel symbols; Riemann tensor (MTW sign:
    R^r_{s m v} = d_m G^r_{v s} - d_v G^r_{m s} + G^r_{m l} G^l_{v s} - G^r_{v l} G^l_{m s}); E^r_m = R^r_{s m v} U^s U^v with U = E_0 = d_t + f l^mu d_mu;
    covariant derivatives in coordinates (each new index appended); frame components at the point with the closed-form frame e^a = dx^a - f l^a l:
    X[q][(a, c, k1..kq)] = e^a_r (nabla^q E)^r_{m b1..bq} E^m_c E^b1_k1 .. (first index up).  drop_gamma: the Christoffel terms of nabla left out (control)."""
    n = 4; nv = 4; D = KJ; P = [F(x) for x in p]; rho0 = F(rho0); Mc = F(Mc)
    rinv = GH.rho_pow_jet(P, rho0, -1, D, nv); f = scale(rinv, Mc)
    nh = [sp_mul(lin((F(1), const(nv, P[i])), (F(1), var(nv, i + 1))), rinv, D, n) for i in range(3)]
    l_dn = [const(nv, 1)] + nh; l_up = [const(nv, 1)] + [scale(x, -1) for x in nh]
    g = {(m, v): sp_add(const(nv, SQ[m] if m == v else 0), sp_mul(sp_mul(f, l_dn[m], D, n), l_dn[v], D, n), -2) for m in range(n) for v in range(n)}
    gi, g0, g0i = std_inverse_metric(g, n, nv, D - 1)
    dg = {(k, a, b): sp_der(g[(a, b)], k) for k in range(n) for a in range(n) for b in range(n)}
    Gam = {}
    for l in range(n):
        for m in range(n):
            for v in range(m, n):
                t = {}
                for s in range(n):
                    br = sp_add(sp_add(dg[(m, s, v)], dg[(v, s, m)]), dg[(s, m, v)], -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, D - 1, n), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    Riem = {}
    for r in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(m + 1, n):
                    t = sp_add(sp_der(Gam[(r, v, s)], m), sp_der(Gam[(r, m, s)], v), -1)
                    for l in range(n):
                        t = sp_add(t, sp_mul(Gam[(r, m, l)], Gam[(l, v, s)], D - 2, n)); t = sp_add(t, sp_mul(Gam[(r, v, l)], Gam[(l, m, s)], D - 2, n), -1)
                    t = {k: c for k, c in t.items() if sum(k) <= D - 2}
                    Riem[(r, s, m, v)] = t; Riem[(r, s, v, m)] = scale(t, -1)
    U = [sp_add(const(nv, 1 if mu == 0 else 0), sp_mul(f, l_up[mu], D, n)) for mu in range(n)]
    cur = {}
    for r in range(n):
        for m in range(n):
            t = {}
            for s in range(n):
                for v in range(n):
                    q = Riem.get((r, s, m, v))
                    if q and U[s] and U[v]: t = sp_add(t, sp_mul(sp_mul(q, U[s], D - 2, n), U[v], D - 2, n))
            if t: cur[(r, m)] = t
    f0 = Mc / rho0; nn = [x / rho0 for x in P]; lu = [F(1)] + [-x for x in nn]; ld = [F(1)] + nn
    e0 = [[F(int(a == mu)) - f0 * lu[a] * ld[mu] for mu in range(n)] for a in range(n)]; det, E0 = det_inv(e0)   # E0[mu][a] = E^mu_a
    out = {0: _to_frame({ix: at0(v, nv) for ix, v in cur.items()}, e0, E0)}; deg = D - 2
    for q in range(1, D - 1):
        deg -= 1; new = {}
        for ix in itertools.product(range(n), repeat=q + 1):
            for b in range(n):
                t = {k: c for k, c in sp_der(cur.get(ix, {}), b).items() if sum(k) <= deg}
                if not drop_gamma:
                    for l in range(n):
                        G_, w = Gam[(ix[0], b, l)], cur.get((l,) + ix[1:])
                        if G_ and w: t = sp_add(t, sp_mul(G_, w, deg, n))
                    for j in range(1, len(ix)):
                        for l in range(n):
                            G_, w = Gam[(l, b, ix[j])], cur.get(ix[:j] + (l,) + ix[j + 1:])
                            if G_ and w: t = sp_add(t, sp_mul(G_, w, deg, n), -1)
                if t: new[ix + (b,)] = t
        cur = new; out[q] = _to_frame({ix: at0(v, nv) for ix, v in cur.items()}, e0, E0)
    return out
def _to_frame(Tc, e0, E0):
    """frame components at the point of a coordinate tensor with the first index up and the others down"""
    cur = {ix: v for ix, v in Tc.items() if v != 0}; r = len(next(iter(cur))) if cur else 0
    for s in range(r):
        new = {}
        for ix, v in cur.items():
            for a in range(4):
                c = e0[a][ix[0]] if s == 0 else E0[ix[s]][a]
                if c: k_ = ix[:s] + (a,) + ix[s + 1:]; new[k_] = new.get(k_, 0) + c * v
        cur = {ix: v for ix, v in new.items() if v != 0}
    return cur

# ------------------------------------------------------------------------------------------------ contraction with the moments
def sym(T, j):
    """the fully symmetrised j-index array over x, y, z (T: {index tuple: value})"""
    return {ix: sum(T.get(pi, F(0)) for pi in itertools.permutations(ix)) / factorial(j) for ix in itertools.product(range(3), repeat=j)}
def forque_terms(X, body, fF=None, fT=None):
    """multipole terms from the arrays X[j] (j indices over x, y, z; X[2] = E, X[3] = first derivative, ...), k = 2, 3, 4:
    F^(k)_a = -fF[k] X[k+1]_{a b1..bk} M^(k)_{b1..bk},  tau^(k)_a = -fT[k] eps_abc X[k]_{c b2..bk} M^(k)_{b b2..bk};  default fF[k] = 1/k!, fT[k] = 1/(k-1)!"""
    out = {}
    for k in (2, 3, 4):
        Mk = G2T.moments(body, k); ff = F(1, factorial(k)) if fF is None else fF[k]; ft = F(1, factorial(k - 1)) if fT is None else fT[k]
        Fk = [-ff * sum(X[k + 1].get((a,) + idx, F(0)) * v for idx, v in Mk.items() if v) for a in range(3)]
        tk = [F(0)] * 3
        for (a, b, c), s in EPS3.items(): tk[a] -= ft * s * sum(X[k].get((c,) + idx[1:], F(0)) * v for idx, v in Mk.items() if v and idx[0] == b)
        out[k] = (Fk, tk)
    return out
def g2_bodies():
    """the bodies of G2 at its two points: its seed 201909 replayed (six random lines, then three random centroidal bodies per point), the principal-axis
    bodies (long axis along / across n), the tilted body, the octahedron and the cube.  {point index: [(name, body)]}"""
    rng = random.Random(201909)
    for _ in range(6):
        [F(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(3)]; [F(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(3)]
    def centroidal(pts):
        m = sum(F(a) for a, _ in pts); c = [sum(F(a) * F(x[i]) for a, x in pts) / m for i in range(3)]
        return [(F(a), [F(x[i]) - c[i] for i in range(3)]) for a, x in pts]
    def rand_pts(k): return [(F(rng.randint(1, 3)), [F(rng.randint(-3, 3), rng.randint(1, 2)) for _ in range(3)]) for _ in range(k)]
    ab = [F(3), F(2), F(1)]; ms = [F(1), F(2), F(3)]; out = {}
    for ip, (R, rho) in enumerate(POINTS):
        L = [('random body %d' % (ib + 1), centroidal(rand_pts(rng.randint(4, 5)))) for ib in range(3)]
        if rho == 5: U = [[F(3, 5), F(4, 5), F(0)], [F(-4, 5), F(3, 5), F(0)], [F(0), F(0), F(1)]]
        else: U = [[F(2, 7), F(3, 7), F(6, 7)], [F(3, 7), F(-6, 7), F(2, 7)], [F(6, 7), F(2, 7), F(-3, 7)]]
        for perm, lab in (((0, 1, 2), 'principal axes, long axis along n'), ((1, 0, 2), 'principal axes, long axis across n')):
            body = []
            for k in range(3): u = U[perm[k]]; body += [(ms[k], [ab[k] * c for c in u]), (ms[k], [-ab[k] * c for c in u])]
            L.append((lab, body))
        Ub = [[F(1), F(2), F(2)], [F(2), F(1), F(-2)], [F(2), F(-2), F(1)]]; body = []
        for k in range(3): body += [(ms[k], [ab[k] * c / 3 for c in Ub[k]]), (ms[k], [-ab[k] * c / 3 for c in Ub[k]])]
        L.append(('tilted principal-axis body', body))
        L.append(('octahedron', [(F(2), [F(s) * (i == j) for i in range(3)]) for j in range(3) for s in (1, -1)]))
        L.append(('cube', [(F(1), [F(sx), F(sy), F(sz)]) for sx in (1, -1) for sy in (1, -1) for sz in (1, -1)]))
        out[ip] = L
    return out

def main():
    import d4_deviation as D4
    A = G2T.PG.Alg(3); read = G2T.readoff(A, 1); BOD = g2_bodies(); Mc = MC
    head('0. Orders: the torque at eps^k reads k - 2 derivatives of the tidal tensor E, the force k - 1 (5-jets of the frame reach the force at eps^4)')
    print('    bodies (G2): 3 random centroidal, 2 principal-axis, 1 tilted, octahedron, cube at each point; M = %s; jets of the frame to degree %d; lam cut at %d' % (Mc, KJ, LAMDEG))
    for ip, (R, rho) in enumerate(POINTS):
        Ri = [int(c) for c in R]; n = [c / rho for c in R]
        head('1.%d  R = %s: the engine\'s tidal field and its derivatives' % (ip + 1, Ri))
        en = engine_tidal_derivs(R, rho, Mc); tick('engine, M = 2')
        el = engine_tidal_derivs(R, rho, Mc, lam=LAMDEG); tick('engine, lam polynomial')
        st = std_tidal_derivs(R, rho, Mc); st0 = std_tidal_derivs(R, rho, Mc, drop_gamma=True); tick('Christoffel route')
        Tay = G2T.phi_taylor(list(R), rho, Mc, KJ)
        PHI = {j: {ix: G2T.phi_deriv(Tay, ix) for ix in itertools.product(range(3), repeat=j)} for j in (2, 3, 4, 5)}
        # (P) partial derivatives of the frame components, direct run and lam polynomial
        Et, Etl = en['Et'], el['Et']
        P = {j: {ix: dcoef(Et.get((ix[0] + 1, ix[1] + 1), {}), ix[2:]) for ix in itertools.product(range(3), repeat=j)} for j in (2, 3, 4, 5)}
        Eg2 = D4.tidal_tensor_point_mass(tuple(R), rho, Mc)
        chk('bit', [[P[2][(i, j)] for j in range(3)] for i in range(3)] == [[F(x) for x in r] for r in Eg2], 'E^i_j of the 5-jet run at the point = the tidal tensor of G2 (d4_deviation.tidal_tensor_point_mass): %s' % [[str(P[2][(i, j)]) for j in range(3)] for i in range(3)])
        for j, what in ((2, 'E^i_j = Phi_,ij'), (3, 'd_k E^i_j = Phi_,ijk'), (4, 'd_l d_k E^i_j = Phi_,ijkl'), (5, 'd_m d_l d_k E^i_j = Phi_,ijklm')):
            chk('bit==std', P[j] == PHI[j], 'R = %s: (P) %s, all %d components (coordinate derivatives of the engine\'s frame components; exact Taylor coefficients of Phi = -M/r)' % (Ri, what, 3 ** j))
        lin_only = all(dcoef(q, ix, 5, L) == 0 for q in Etl.values() for ix in [()] + [tuple(c) for d in (1, 2, 3) for c in itertools.combinations_with_replacement(range(3), d)] for L in range(LAMDEG + 1) if L != 1)
        same1 = all(dcoef(Etl.get(key, {}), ix, 5, 1) == dcoef(Et.get(key, {}), ix) for key in set(Et) | set(Etl) for ix in [()] + [tuple(c) for d in (1, 2, 3) for c in itertools.combinations_with_replacement(range(3), d)])
        chk('bit', lin_only and same1, 'R = %s: with f = lam M/r the field E^a_c(x) (its 3-jet) is exactly linear in lam (the lam^0 and lam^2..lam^%d coefficients vanish) and its lam^1 part is the M = 2 field' % (Ri, LAMDEG))
        # (C) covariant derivatives: engine against the Christoffel route
        D2, DT1 = en['D2'], en['DT1']
        chk('bit', all(D2[k] == DT1.get(k, {}) for k in D2) and all(k in D2 for k in DT1), 'R = %s: D_tensor with two slots = g2_hodge.D_two_index on E_ac (all 16 one-forms)' % Ri)
        Cmix = {q: {ix: SQ[ix[0]] * at0(v, 4) for ix, v in en['T'][q].items() if at0(v, 4) != 0} for q in range(KJ - 1)}
        for q in range(KJ - 1):
            same = Cmix[q] == st[q]
            chk('bit==std', same, 'R = %s: %s (all %d frame components, one index up): engine (D_covector, h table) = Christoffel route of g = eta - 2 f l l, exact%s' % (Ri, ['E^a_c', 'nabla E', 'nabla nabla E', 'nabla^3 E'][q], 4 ** (q + 2), '' if q else ' (the field the derivatives act on)'))
        chk('ctl', all(st0[q] != Cmix[q] for q in (1, 2, 3)), 'R = %s: the Christoffel route without its Christoffel terms (partial derivatives of the coordinate components) differs from the engine\'s covariant derivatives at orders 1, 2, 3' % Ri)
        # the relation between (C), (V) and Phi
        Vsp = {(i, c, k): SQ[i + 1] * at0(en['V'].get((i + 1, c + 1, k + 1), {}), 4) for i in range(3) for c in range(3) for k in range(3)}
        Vcl = {(i, c, k): PHI[3][(i, c, k)] + 3 * Mc / rho ** 2 * n[k] * PHI[2][(i, c)] for i in range(3) for c in range(3) for k in range(3)}
        chk('bit==std', Vsp == Vcl, 'R = %s: (V) frame-vector derivative E_k(E^i_j) = Phi_,ijk + 3 (M/r^2) n_k Phi_,ij (closed form: E_k = d_k - f n_k n.grad on static functions), all 27' % Ri)
        Csp = {q: {ix: Cmix[q].get(tuple(c + 1 for c in ix), F(0)) for ix in itertools.product(range(3), repeat=q + 2)} for q in range(KJ - 1)}
        chk('ctl', Csp[1] != Vsp, 'R = %s: the connection terms of (C) are not zero at the point: nabla_k E^i_j - E_k(E^i_j) != 0 (%d of 27 components)' % (Ri, sum(1 for ix in Vsp if Vsp[ix] != Csp[1][ix])))
        rad = sum(n[i] * n[j] * n[k] * Csp[1][(i, j, k)] for i in range(3) for j in range(3) for k in range(3))
        rad_std = sum(n[i] * n[j] * n[k] * st[1].get((i + 1, j + 1, k + 1), F(0)) for i in range(3) for j in range(3) for k in range(3))
        chk('std', rad_std == (1 - Mc / rho) * 6 * Mc / rho ** 4, 'R = %s: Christoffel route (nabla_n E)^n_n = (1 - M/r) Phi_,rrr = (1 - M/r) 6M/r^4 = %s (radial frame vector (1 - f) d_r + f d_t; the connection terms cancel in the eigenbasis)' % (Ri, (1 - Mc / rho) * 6 * Mc / rho ** 4))
        rad_phi = sum(n[i] * n[j] * n[k] * PHI[3][(i, j, k)] for i in range(3) for j in range(3) for k in range(3))
        chk('bit==std', rad == rad_std and rad != rad_phi and rad_phi == 6 * Mc / rho ** 4, 'R = %s: engine (nabla_n E)^n_n = %s = the Christoffel route, not Phi_,rrr = %s' % (Ri, rad, rad_phi))
        sym_ij = all(Csp[1][(i, j, k)] == Csp[1][(j, i, k)] for i in range(3) for j in range(3) for k in range(3))
        asym = max(abs(Csp[1][(i, j, k)] - Csp[1][(k, j, i)]) for i in range(3) for j in range(3) for k in range(3))
        print('    (C) at order 1: symmetric in (i, j): %s; largest |(nabla_k E)^i_j - (nabla_i E)^k_j| = %s (the contraction uses the symmetrised array)' % (sym_ij, asym))
        # lam polynomial of (C)
        Tl = el['T']; Cl = {q: {} for q in range(1, KJ - 1)}
        for q in range(1, KJ - 1):
            for ix, v in Tl[q].items():
                for L in range(LAMDEG + 1):
                    c = at_pt(v, 5, L)
                    if c != 0: Cl[q].setdefault(L, {})[ix] = SQ[ix[0]] * c
        degs = {q: max(Cl[q]) for q in Cl}
        def lsum(q):
            out = {ix: sum(Cl[q][L].get(ix, F(0)) for L in Cl[q]) for ix in set().union(*[set(d) for d in Cl[q].values()])}
            return {ix: v for ix, v in out.items() if v != 0}
        summed = all(lsum(q) == Cmix[q] for q in Cl)
        chk('bit', summed and 0 not in [L for q in Cl for L in Cl[q]], 'R = %s: (C) is a polynomial in lam of degree %s (orders 1, 2, 3; no lam^0 part); the sum of its coefficients is the M = 2 run, every component' % (Ri, [degs[q] for q in (1, 2, 3)]))
        for q in (1, 2, 3):
            c1 = {ix: Cl[q].get(1, {}).get(tuple(c + 1 for c in ix), F(0)) for ix in itertools.product(range(3), repeat=q + 2)}
            chk('bit==std', c1 == P[q + 2], 'R = %s: the lam^1 (first order in M) part of %s equals the Phi derivatives exactly, every spatial component (no symmetrisation needed)' % (Ri, ['', 'nabla E', 'nabla nabla E', 'nabla^3 E'][q]))
        nz2 = [sum(1 for ix in itertools.product(range(1, 4), repeat=q + 2) if Cl[q].get(2, {}).get(ix, 0) != 0) for q in (1, 2, 3)]
        chk('bit', all(x > 0 for x in nz2), 'R = %s: the lam^2 (order M^2) part of the covariant derivatives is not zero: %s spatial components at orders 1, 2, 3' % (Ri, nz2))
        chk('bit==std', Csp[1] == {ix: (1 - Mc / rho) * v for ix, v in PHI[3].items()}, 'R = %s: (C) at first order is (nabla_k E)^i_j = (1 - M/r) Phi_,ijk exactly, all 27 components (frame and connection terms together give the factor 1 - M/r = %s)' % (Ri, 1 - Mc / rho))
        for q in (2, 3):
            B = nd_basis(n, q + 2); okt = sorted(Cl[q]) == [1] + sorted(COEF[q])
            for L, cf in COEF[q].items():
                part = sym({ix: Cl[q].get(L, {}).get(tuple(c + 1 for c in ix), F(0)) for ix in itertools.product(range(3), repeat=q + 2)}, q + 2)
                u = Mc ** L / rho ** (L + q + 2)
                okt &= part == {ix: u * sum(c * b[ix] for c, b in zip(cf, B)) for ix in part}
            chk('bit', okt, 'R = %s: Sym(%s) = %s + sum_L (M^L/r^(L+%d)) [a n^%d + b Sym(delta n^%d) + c Sym(delta delta%s)] with (a, b, c) = %s for L = %s, exactly' % (Ri, ['', '', 'nabla nabla E', 'nabla^3 E'][q], ['', '', 'Phi_,ijkl', 'Phi_,ijklm'][q], q + 2, q + 2, q, '' if q == 2 else ' n', [COEF[q][L] for L in sorted(COEF[q])], sorted(COEF[q])))
        radl = [sum(n[i] * n[j] * n[k] * Cl[1].get(L, {}).get((i + 1, j + 1, k + 1), F(0)) for i in range(3) for j in range(3) for k in range(3)) for L in range(degs[1] + 1)]
        print('    (nabla_n E)^n_n as a polynomial in lam (f = lam M/r): coefficients %s = 6M/r^4 and -6M^2/r^5' % [str(x) for x in radl])
        tick('part 1.%d' % (ip + 1))

        # ==================================================================================== the bodies
        head('2.%d  R = %s: the forque of the bodies from the derivatives of E against the summed force lines' % (ip + 1, Ri))
        XP = {j: P[j] for j in (2, 3, 4, 5)}
        XC = {2: P[2]}; XC1 = {2: P[2]}
        for q in (1, 2, 3):
            XC[q + 2] = sym(Csp[q], q + 2)
            XC1[q + 2] = sym({ix: Cl[q].get(1, {}).get(tuple(c + 1 for c in ix), F(0)) for ix in itertools.product(range(3), repeat=q + 2)}, q + 2)
        ok_std1 = True; wrong = {'F3': True, 'F4': True, 't3': True, 't4': True}; rep = True; fac = True
        for name, body in BOD[ip]:
            Fe, te = G2T.eps_forque(A, R, rho, body, Mc, 1, read); Fs, ts = G2T.std_sums(R, rho, body, Mc)
            ok_std1 &= all(G2T.scoef(Fe[i], k) == G2T.scoef(Fs[i], k) and G2T.scoef(te[i], k) == G2T.scoef(ts[i], k) for i in range(3) for k in range(5))
            lines = {k: ([G2T.scoef(Fe[i], k) for i in range(3)], [G2T.scoef(te[i], k) for i in range(3)]) for k in (2, 3, 4)}
            tP = forque_terms(XP, body); tC = forque_terms(XC, body); tC1 = forque_terms(XC1, body)
            chk('bit', tP[2] == lines[2] and tP[3] == lines[3], '%s: eps^2 and eps^3 (force with d E and d d E, torque with E and d E): the moments contracted with the coordinate derivatives of the engine\'s E = the summed lines, exact' % name)
            chk('bit', tP[4] == lines[4], '%s: eps^4 (force with d d d E and the fourth moments, torque with d d E): contraction = the summed lines, exact' % name)
            chk('bit', tC1 == lines, '%s: the first-order (lam^1) part of the engine\'s covariant derivatives, contracted, = the summed lines at eps^2, eps^3, eps^4' % name)
            fac &= tC[2][0] == [(1 - Mc / rho) * x for x in lines[2][0]] and tC[3][1] == [(1 - Mc / rho) * x for x in lines[3][1]] and tC[2][1] == lines[2][1]
            M3 = G2T.moments(body, 3); central = all(v == 0 for v in M3.values())
            if not central:
                diff = [tC[3][0] != lines[3][0], tC[3][1] != lines[3][1], tC[4][0] != lines[4][0], tC[4][1] != lines[4][1]]
                chk('bit', all(diff), '%s: the contraction with the engine\'s covariant derivatives at M = 2 misses the summed lines at eps^3 and eps^4 (force and torque): the M^2 terms' % name)
                if name == 'random body 1': print('    %s, torque at eps^3: summed lines %s, covariant contraction %s' % (name, [str(x) for x in lines[3][1]], [str(x) for x in tC[3][1]]))
                for k, key in ((3, 'F3'), (4, 'F4')):
                    fF = {2: F(1, 2), 3: F(1, 6), 4: F(1, 24)}; fF[k] = 2 * fF[k]
                    wrong[key] &= forque_terms(XP, body, fF=fF)[k][0] != lines[k][0]
                for k, key in ((3, 't3'), (4, 't4')):
                    fT = {2: F(1), 3: F(1, 2), 4: F(1, 6)}; fT[k] = 2 * fT[k]
                    wrong[key] &= forque_terms(XP, body, fT=fT)[k][1] != lines[k][1]
                tR = forque_terms({j: {ix: -v for ix, v in XP[j].items()} for j in XP}, body)
                rep &= tR[3] != lines[3] and tR[4] != lines[4]
            else:
                zero3 = lines[3] == ([0, 0, 0], [0, 0, 0]) and tP[3] == lines[3]
                chk('bit', zero3, '%s: centrally symmetric (third moments 0): force and torque at eps^3 exactly 0, in the summed lines and in the contraction' % name)
                nz4 = lines[4] != ([0, 0, 0], [0, 0, 0])
                chk('ctl', nz4, '%s: the eps^4 term is not zero (force %s, torque %s), so the zero at eps^3 is not a vacuous zero' % (name, 'not 0' if any(lines[4][0]) else '0', 'not 0' if any(lines[4][1]) else '0'))
                chk('bit', tC[4] != lines[4], '%s: at eps^4 the contraction with the engine\'s covariant derivatives at M = 2 misses the summed lines' % name)
        chk('bit==std', ok_std1, 'R = %s: the summed force lines equal the direct vector sums (G2 std1) for all %d bodies, every coefficient eps^0..eps^4' % (Ri, len(BOD[ip])))
        chk('bit', fac, 'R = %s: with the engine\'s covariant nabla E the force at eps^2 and the torque at eps^3 are exactly (1 - M/r) = %s times those of the summed lines, all %d bodies (the torque at eps^2 reads E itself and agrees)' % (Ri, 1 - Mc / rho, len(BOD[ip])))
        chk('ctl', wrong['F3'], 'R = %s: the wrong Taylor factor 1/3 instead of 1/6 (force at eps^3) misses the summed lines (3 random bodies)' % Ri)
        chk('ctl', wrong['F4'], 'R = %s: the wrong Taylor factor 1/12 instead of 1/24 (force at eps^4) misses the summed lines (3 random bodies)' % Ri)
        chk('ctl', wrong['t3'], 'R = %s: the wrong factor 1 instead of 1/2 (torque at eps^3) misses the summed lines (3 random bodies)' % Ri)
        chk('ctl', wrong['t4'], 'R = %s: the wrong factor 1/3 instead of 1/6 (torque at eps^4) misses the summed lines (3 random bodies)' % Ri)
        chk('ctl', rep, 'R = %s: the derivatives of the tidal tensor with the repulsive sign miss the summed lines at eps^3 and eps^4 (3 random bodies)' % Ri)
        tick('part 2.%d' % (ip + 1))
    finish('G2-fourth')

if __name__ == '__main__': main()
