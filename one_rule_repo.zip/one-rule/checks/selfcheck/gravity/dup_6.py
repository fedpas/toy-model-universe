#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""DUP-6: tidal tensor and electric Weyl part in four places at one Schwarzschild and one SdS point (same Kerr-Schild frame, observer u = E_0):
D4 tidal_tensor / tidal_tensor_point_mass (E^a_c = R^a_bcd u^b u^d), G2 Phi_,ij (phi_taylor/phi_deriv), H1 complex_Q real part (E_ij = C_0i0j of weyl_parts),
H5L J part of the conformal Cartan curvature (full_F, f = Schouten) contracted with D4's formula. Exact; characteristic polynomials compared.
Schouten/Ricci on a random frame: H1 weyl_parts and ricci_rows, A4 b1lib.std_einstein_mixed (Christoffel), H5L engine_data Sch and fit_P.
Controls: D4's swapped-index tidal (swap=True), the Schouten coefficient Rs/4 instead of Rs/6, a different M."""
import os, sys, random
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from duplib import *
import d4_deviation as D4, g2_tidal_forque as G2T, g2_weyl as W, h5l_frames as H5F, h5l_conformal as H5C
SQ = LORENTZ(4)
head('DUP-6 versions'); versions('b1lib', 'd4_deviation', 'g2_tidal_forque', 'g2_weyl', 'h5l_frames', 'h5l_conformal')
Gv, S, _ = W.lorentz_setup(SQ); C6 = H5C.Conf(); u = [F(1), F(0), F(0), F(0)]
blk = lambda A: [[A[i][j] for j in (1, 2, 3)] for i in (1, 2, 3)]
neg = lambda A: [[-x for x in r] for r in A]
p, rho0, M = (F(1), F(2), F(2)), F(3), F(1)
for H2 in (F(0), F(1, 5)):
    head('D6.%s %s M=%s H2=%s at p=(1,2,2), Kerr-Schild frame, u = E_0' % ('a' if H2 == 0 else 'b', 'Schwarzschild' if H2 == 0 else 'Schwarzschild-de Sitter', M, H2))
    e = ks_frame_jet(p, rho0, *sds_jets(M, H2, rho0))[0]
    Ed4 = blk(D4.tidal_tensor(Gv, e, S, u))
    Rl, _, _ = W.engine_frame_riemann(Gv, e, S); Cw, Ric, Rs, tf = W.weyl_parts(Rl, SQ); Q = W.complex_Q(Cw)
    EH1 = [[Q[i][j].re if hasattr(Q[i][j], 're') else Cw[(0, i + 1, 0, j + 1)] for j in range(3)] for i in range(3)]
    EH1c = [[Cw[(0, i + 1, 0, j + 1)] for j in range(3)] for i in range(3)]
    d = H5F.engine_data(C6, e); Jfr = H5F.jfr_at(H5F.full_F(C6, d, e)['J'], d['E0']); EH5 = blk(D4.tidal_from_Rf(Jfr, SQ, u))
    print('  D4 E^i_j (Riemann) =', fmt_mat(Ed4)); print('  H1 C_0i0j (Weyl)    =', fmt_mat(EH1c)); print('  H5L J-part tidal    =', fmt_mat(EH5))
    same('H1 complex_Q real part vs C_0i0j of weyl_parts', mat_cmp(EH1, EH1c), item='D6 tidal')
    same('H5L J-part E^i_j (D4 formula on J^{ab}_{cd}) vs -C_0i0j (H1)', mat_cmp(EH5, neg(EH1c)), item='D6 tidal')
    if H2 == 0:
        T = G2T.phi_taylor([p[0], p[1], p[2]], rho0, M, 3); Phi2 = [[G2T.phi_deriv(T, (i, j)) for j in range(3)] for i in range(3)]
        same('D4 tidal_tensor E^i_j vs G2 Phi_,ij (Phi = -M/rho)', mat_cmp(Ed4, Phi2), item='D6 tidal')
        same('D4 tidal_tensor vs D4 tidal_tensor_point_mass', mat_cmp(Ed4, D4.tidal_tensor_point_mass(p, rho0, M)), item='D6 tidal')
        same('D4 tidal (Riemann) vs -C_0i0j (H1): vacuum, Riemann = Weyl', mat_cmp(Ed4, neg(EH1c)), item='D6 tidal')
        same('D4 tidal vs +C_0i0j (H1): the opposite sign must differ', mat_cmp(Ed4, EH1c), expect=False, item='D6 tidal')
        same('D4 swapped-index tidal (swap=True) vs Phi_,ij', mat_cmp(blk(D4.tidal_from_Rf(D4.frame_Rf(Gv, engine_om_R(Gv, e, S, 4)[1], E0_of(e, 4, 4)[1]), SQ, u, swap=True)), Phi2), expect=False, item='D6 tidal')
        same('G2 Phi_,ij with M + 1 vs D4 (M)', mat_cmp(Ed4, [[G2T.phi_deriv(G2T.phi_taylor([p[0], p[1], p[2]], rho0, M + 1, 3), (i, j)) for j in range(3)] for i in range(3)]), expect=False, item='D6 tidal')
        cps = {'D4': D4.charpoly(Ed4), 'G2': D4.charpoly(Phi2), '-H1': D4.charpoly(neg(EH1c)), 'H5L-J': D4.charpoly(EH5)}
        k = M / rho0 ** 3; target = D4.charpoly([[k, 0, 0], [0, k, 0], [0, 0, -2 * k]])
        chk('cmp', all(c == target for c in cps.values()), 'eigenvalues: D4, G2, -H1, H5L all (M/rho^3)(1, 1, -2) = (%s, %s, %s); H1 C_0i0j itself (-1, -1, 2) M/rho^3 (H1 states double eigenvalue -M/rho^3)' % (k, k, -2 * k))
    else:
        diff = [[Ed4[i][j] - EH5[i][j] for j in range(3)] for i in range(3)]
        chk('cmp', all(diff[i][j] == (-H2 if i == j else 0) for i in range(3) for j in range(3)), 'SdS: D4 tidal (Riemann) - Weyl tidal (H5L J) = %s delta_ij (the Lambda part: -H2 delta, mutual repulsion)' % diff[0][0])
        Ew0 = blk(D4.tidal_tensor(Gv, ks_frame_jet(p, rho0, *sds_jets(M, F(0), rho0))[0], S, u))
        same('SdS Weyl tidal (H5L J) vs Schwarzschild tidal (D4, H2 = 0): the H2 part is pure Ricci', mat_cmp(EH5, Ew0), item='D6 tidal')
    tick('point')
head('D6.c Ricci, scalar, Schouten on a random polynomial frame: H1 (weyl_parts, ricci_rows) vs A4 std (std_einstein_mixed) vs H5L (engine_data Sch, fit_P)')
rng = random.Random(66); e = rand_frame(rng, 4, deg=2, nv=4); e0, E0, det = E0_of(e, 4, 4)
Rl, _, _ = W.engine_frame_riemann(Gv, e, S); _, Ric, Rs, _ = W.weyl_parts(Rl, SQ)
cv = W.cell_vector(Rl); rows = W.ricci_rows(SQ); bd = [(b, d_) for b in range(4) for d_ in range(b, 4)]
same('Ric_bd  H1 ricci_rows . cell_vector vs weyl_parts', (10, sum(1 for k_, r in zip(bd, rows) if sum(x * y for x, y in zip(r, cv)) != Ric[k_]), max(abs(sum(x * y for x, y in zip(r, cv)) - Ric[k_]) for k_, r in zip(bd, rows))), item='D6 Schouten')
chk('cmp', sum(x * y for x, y in zip(W.scalar_row(SQ), cv)) == Rs, 'Rs  H1 scalar_row . cell_vector = weyl_parts Rs = %s' % Rs)
g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); Gm, ric, Rss = std_einstein_mixed(R1, g0, g0i, 4)
rc = (lambda m, v: ric[(m, v)]) if isinstance(ric, dict) else (lambda m, v: ric[m][v])
RicStd = {(a, b): sum(E0[m][a] * E0[v][b] * rc(m, v) for m in range(4) for v in range(4)) for a in range(4) for b in range(4)}
same('Ric_ab (frame, lower)  H1 engine vs A4 std Christoffel', (16, sum(1 for k_ in RicStd if RicStd[k_] != Ric[k_]), max(abs(RicStd[k_] - Ric[k_]) for k_ in RicStd)), item='D6 Schouten')
chk('cmp', Rss == Rs, 'scalar curvature  A4 std = %s, H1 = %s (same sign convention)' % (Rss, Rs))
d = H5F.engine_data(C6, e); Sch = {k_: at0(v, 4) for k_, v in d['Sch'].items()}
P_pred = {(b, d_): (Ric[(b, d_)] - (Rs / 6) * (SQ[b] if b == d_ else 0)) / 2 for b in range(4) for d_ in range(4)}
same('Schouten  H5L engine_data Sch vs (1/2)(Ric - (Rs/6) eta) from H1', (16, sum(1 for k_ in Sch if Sch[k_] != P_pred[k_]), max(abs(Sch[k_] - P_pred[k_]) for k_ in Sch)), item='D6 Schouten')
P_bad = {(b, d_): (Ric[(b, d_)] - (Rs / 4) * (SQ[b] if b == d_ else 0)) / 2 for b in range(4) for d_ in range(4)}
same('Schouten  H5L vs (1/2)(Ric - (Rs/4) eta) (wrong coefficient)', (16, sum(1 for k_ in Sch if Sch[k_] != P_bad[k_]), max(abs(Sch[k_] - P_bad[k_]) for k_ in Sch)), expect=False, item='D6 Schouten')
Pfit, prank = H5F.fit_P(C6, d, e); print('  fit_P rank =', prank)
Pf = (lambda a, b: Pfit[a][b]) if isinstance(Pfit, list) else (lambda a, b: Pfit[(a, b)])
Pl = {(a, b): SQ[a] * Pf(a, b) for a in range(4) for b in range(4)}
same('Schouten  H5L fit_P (trace-free Lorentz part), lowered P_ab = eta_aa P^a_b, vs (1/2)(Ric - (Rs/6) eta)', (16, sum(1 for k_ in Pl if Pl[k_] != P_pred[k_]), max(abs(Pl[k_] - P_pred[k_]) for k_ in Pl)), item='D6 Schouten')
tick('D6.c')
finish('DUP-6')
