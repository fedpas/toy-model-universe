#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""E1-axial.  E1's torsion clause on the axial torsion of the Dirac spin source (E2): the skew-torsion form of Dslash squared.     python3 e1_axial_torsion.py

 Conventions: those of e1_lichnerowicz.py and e2_spin_torsion.py. Cl(1,3), sq = (+,-,-,-), I = gamma_0 gamma_1 gamma_2 gamma_3 (I^2 = -1), eps_0123 = +1.
 omega' = omega_LC (A3, 1-jet) + K*, with E2's axial contorsion K*^{ab} = sum_c K*_c^{ab} e^c, K*_c^{ab} = -(1/4) kappa sq_a sq_b eps_abcd s^d,
 s = psi_D gamma_3 psi_D~ of an even polynomial spinor psi_D (degree 2). Then K_abc = -(kappa/4) eps_abcd s^d is totally antisymmetric,
 T_abc = (kappa/2) eps_abcd s^d = -2 K_abc and |T|^2 = T_abc T^abc = -(3/2) kappa^2 (s.s) >= 0.
 nabla is Levi-Civita; nabla_c s is the LC derivative of s = s^d gamma_d (engine D_vector); gamma^c nabla_c s = div s + curl s.
 Claims checked at the origin of random polynomial frames, n = 4:
  (C) E1's clause Dslash'^2 - nabla'^a nabla'_a = -(1/4) R' - (1/2) gamma^a gamma^b T^c_ab nabla'_c + (1/8) K'_2 + (1/8) K'_4 holds on K*,
      and an exact fit on axial frames alone fixes all four coefficients.
  (R) Term by term on K*: R' = R - |T|^2/4; (1/8) K'_2 = -(kappa/4) I curl s; R'_[0123] = (kappa/8) div s, so (1/8) K'_4 = -(3 kappa/8) (div s) I;
      -(1/2) gamma^a gamma^b T^c_ab nabla'_c = -(kappa/2) I (gamma^c ^ s) nabla_c + (3/16) kappa^2 (s.s);
      nabla'^a nabla'_a = nabla^a nabla_a - (kappa/4) I (gamma^c ^ s) nabla_c - (kappa/8) I curl s + (3/64) kappa^2 (s.s).
  (S) Skew-torsion form: Dslash' = Dslash + (3 kappa/8) I s, and with the Levi-Civita Laplacian
      Dslash'^2 = nabla^a nabla_a - R/4 - (3 kappa/4) I (gamma^c ^ s) nabla_c - (3 kappa/8) I (gamma^c nabla_c s) + (9/64) kappa^2 (s.s),  (9/64) kappa^2 (s.s) = -(3/32) |T|^2.
  (B) D_beta = Dslash + beta I s:  D_beta^2 - nabla'^a nabla'_a = -R/4 + (kappa/4 - 2 beta) I (gamma^c ^ s) nabla_c + (kappa/8 - beta) I curl s - beta (div s) I
      + (beta^2 - 3 kappa^2/64)(s.s); at beta = kappa/8, one third of the torsion term of Dslash', it is of order zero.
 [bit] exact fractions: the engine's omega (A3), torsion, curvature, D_spinor, D_covector and D_vector (h table), through E1's engine_ops and E2's currents.
 [std] numpy only: E1's StdSpin (Dirac matrices, Christoffel symbols, five-point differences) with the contorsion computed at every point from Dirac-matrix
       bilinears (E2's Std: chi = M(psi_D) u, A^d = chibar Gamma^d gamma5 chi, gamma5 = i Gamma^0 Gamma^1 Gamma^2 Gamma^3, upper-index matrices); the same reductions
       in matrices. In matrix form Dslash' is i Gamma^a nabla'_a = i Gamma^a nabla_a + (3 kappa/8) A_d Gamma^d gamma5, the operator of the Hehl-Datta equation
       in its recalled form (source not read).
 Controls: a trace-carrying contorsion (K* plus the vector-current contorsion of E2's mode='vector', pure trace with lambda = -1/4); each clause coefficient
 replaced by a wrong value; the wrong sign of the torsion term of the operator; plain derivatives of the components of s in place of nabla s;
 beta = kappa/4 and 3 kappa/8 without their first-order term; [std] the contorsion of the wrong sign.
 Consistency: kappa = 0 gives E1's torsion-free result. Scope: on a constant frame with a constant psi_D (nabla s = 0) only the first two coefficients are tested.
 Textbook form (recalled, not read): the square of the Dirac operator of a metric connection with totally skew torsion (Bismut; Agricola and Friedrich).
 No published coefficient is compared. Scope: n = 4, (+,-,-,-), classical commuting spinors, the origin of 4 random polynomial frames
 (first-order jets of omega', test spinors of degree 2) and one constant frame; not a proof for all fields."""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import e1_lichnerowicz as E1
import e2_spin_torsion as E2
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N = 4; LOR = [1, -1, -1, -1]; IM = {15: F(1)}; PAIRS = E2.PAIRS
COEF = [F(-1, 4), F(-1, 2), F(1, 8), F(1, 8)]
mv_add, mv_scale, mv_mul, grade, clean = E1.mv_add, E1.mv_scale, E1.mv_mul, E1.grade, E1.clean

def mv_sum(terms):
    out = {}
    for X, c in terms: out = mv_add(out, X, c)
    return out
def form_zero(X): return not any(any(v != 0 for v in p.values()) for p in X.values())
def jet_zero(X, Y, Z, c):
    """X - Y - c Z = 0 for multivector polynomials {mask: poly}"""
    for m in set(X) | set(Y) | set(Z):
        p = padd(padd(X.get(m, {}), Y.get(m, {}), -1), Z.get(m, {}), -c)
        if any(v != 0 for v in p.values()): return False
    return True

# ------------------------------------------------------------------------------------------------ [bit] contorsions as engine 1-forms (call inside trunc)
def axial_K(Gv, e, sv, kap):
    """E2's axial contorsion K^{pq} = sum_c -(1/4) kappa sq_p sq_q eps_pqcd s^d e^c"""
    Fm = Gv.Fm; K = [{} for _ in range(Gv.G)]
    for (p, q) in PAIRS:
        f = {}
        for c in E2.comp4(p, q):
            d = E2.comp4(p, q, c)[0]
            if sv[d]: f = Fm.add(f, Fm.wedge({0: sv[d]}, e[c]), F(-1, 4) * kap * LOR[p] * LOR[q] * E2.perm([p, q, c, d]))
        K[Gv.L.idx[(1 << p) | (1 << q)]] = f
    return K
def trace_K(Gv, e, jv, kap, lam):
    """[ctl] the vector-current contorsion (pure trace): K^{pq}(E_c) = lam kappa (delta_pc j^q - delta_qc j^p), i.e. K^{pq} = lam kappa (j^q e^p - j^p e^q)"""
    Fm = Gv.Fm; K = [{} for _ in range(Gv.G)]
    for (p, q) in PAIRS:
        f = {}
        if jv[q]: f = Fm.add(f, Fm.wedge({0: jv[q]}, e[p]), lam * kap)
        if jv[p]: f = Fm.add(f, Fm.wedge({0: jv[p]}, e[q]), -lam * kap)
        K[Gv.L.idx[(1 << p) | (1 << q)]] = f
    return K
def om_sum(Gv, om, *Ks):
    out = [dict(x) for x in om]
    for K in Ks:
        for A in range(Gv.G): out[A] = Gv.Fm.add(out[A], K[A])
    return out
def torsion_closed(Gv, e, sv, kap):
    """E2's closed form T^a = (kappa/2) sq_a sum_{p<q} eps_apqd s^d e^p ^ e^q"""
    Fm = Gv.Fm; Tc = []
    for a in range(N):
        f = {}
        for (p, q) in PAIRS:
            if a in (p, q): continue
            d = E2.comp4(a, p, q)[0]
            if sv[d]: f = Fm.add(f, Fm.wedge({0: sv[d]}, Fm.wedge(e[p], e[q])), F(1, 2) * kap * LOR[a] * E2.perm([a, p, q, d]))
        Tc.append(f)
    return Tc
def lambda_vector_mode(rng, draws=2):
    """[bit] E2's stationary contorsion with the vector-current bilinear (mode='vector') at constant frames: the single lambda with K^{pq}(E_c) = lam kappa (delta_pc j^q - delta_qc j^p)"""
    Gv = Grav(N, Lie(LOR)); lams = []; ok = True
    for i in range(draws):
        A, det, inv = E2.rand_matrix(rng); psi0 = E2.rand_even(rng); kap = [F(2, 5), F(3)][i % 2]
        k, rk, cons = E2.stationary_K(Gv, A, psi0, kap, F(7, 4), mode='vector')
        _, j, _, _ = E2.currents({S: E2.cp(v, N) for S, v in psi0.items()}, LOR, N); jv = [E2.v0(p, N) for p in E2.vec(j)]
        lam = None
        for Ai, (p, q) in enumerate(PAIRS):
            for c in range(N):
                v = sum((k[Ai][mu] * inv[mu][c] for mu in range(N)), F(0)); base = kap * ((jv[q] if p == c else 0) - (jv[p] if q == c else 0))
                if base == 0: ok &= (v == 0); continue
                if lam is None: lam = v / base
                ok &= (v == lam * base)
        ok &= (rk == 24 and cons and lam is not None); lams.append(lam)
    return lams[0], ok and len(set(lams)) == 1, lams

# ------------------------------------------------------------------------------------------------ [bit] pointwise pieces at the origin
def nabla_vec(Gv, om, sv, E0, plain=False):
    """(nabla_c s)^d at the origin = E_c -| (D s)^d with the engine's D_vector; plain=True: [ctl] E_c(s^d), the connection term dropped"""
    with trunc(N, xdeg=0):
        X = [({0: p} if p else {}) for p in sv]
        Ds = [Gv.Fm.d(x) for x in X] if plain else Gv.D_vector(om, X)
    return [[sum((at0(Ds[d].get(1 << mu, {}), N) * E0[mu][c] for mu in range(N)), F(0)) for d in range(N)] for c in range(N)]
def vgrad(ns):
    """gamma^c nabla_c s = sum_cd sq_c (nabla_c s)^d gamma_c gamma_d: grade 0 = div s, grade 2 = curl s"""
    out = {}
    for c in range(N):
        for d in range(N):
            if ns[c][d]: m, sg = bmul(1 << c, 1 << d, LOR); out[m] = out.get(m, 0) + LOR[c] * sg * ns[c][d]
    return clean(out)
def wedge_cs(c, s0):
    """gamma^c ^ s"""
    out = {}
    for d in range(N):
        if d != c and s0[d]: m, sg = bmul(1 << c, 1 << d, LOR); out[m] = out.get(m, 0) + LOR[c] * sg * s0[d]
    return clean(out)
def first_order(s0, nab0):
    """sum_c I (gamma^c ^ s) nabla_c psi at the origin"""
    out = {}
    for c in range(N): out = mv_add(out, mv_mul(mv_mul(IM, wedge_cs(c, s0), LOR), nab0[c], LOR))
    return out
def Tf_at0(T, E0): return {(c, a, b): E1.form2_on(T[c], E0, N, a, b) for c in range(N) for a in range(N) for b in range(N)}
def T_sq(Tf): return sum((LOR[a] * LOR[b] * LOR[c] * Tf[(a, b, c)] ** 2 for a in range(N) for b in range(N) for c in range(N)), F(0))
def curv_pieces(Gv, om, E0):
    """R', the Clifford contraction K' and its parts, Ricci, R'_[0123] at the origin"""
    with trunc(N, xdeg=0): R2 = Gv.curvature(om)
    Rf = E1.curv_frame(Gv, R2, E0, N); K = E1.clifford_contraction(Rf, N, LOR)
    return dict(R=E1.scalar_R(Rf, N), K2=grade(K, 2), K4=grade(K, 4), K0=grade(K, 0), ric=E1.ricci(Rf, N, LOR), A4=E1.antisym4(Rf, LOR))
def clause_terms(cp_, Tf, ops):
    psi0 = ops['psi0']
    return [mv_scale(psi0, cp_['R']), E1.tT_term(Tf, ops['nab0'], N, LOR), mv_mul(cp_['K2'], psi0, LOR), mv_mul(cp_['K4'], psi0, LOR)]
def dbeta_sq(Gv, omp, E, PhiK, IsPsi, Is0, boff):
    """(Dslash' + boff I s)^2 psi at the origin, from the 1-jet of Dslash' psi + boff I s psi"""
    Phi = {}
    for m in set(PhiK) | set(IsPsi):
        p = padd(PhiK.get(m, {}), IsPsi.get(m, {}), boff)
        if any(v != 0 for v in p.values()): Phi[m] = p
    D2 = E1.at0_sp(E1.slash(E1.nabla_jet(Gv, omp, E, Phi, N, 0), N, LOR, LOR), N)
    return mv_add(D2, mv_mul(Is0, E1.at0_sp(Phi, N), LOR), boff)
def rand_even_poly(rng, deg=2, dens=.5):
    while True:
        psi = {S: p for S, p in ((S, E1.nz_poly(gs.rpoly(rng, N, deg, dens))) for S in E2.EVEN) if p}
        if len(psi) >= 5: return psi

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
class StdAxial(E1.StdSpin):
    """[std] E1's StdSpin with the axial contorsion computed at each point from Dirac-matrix bilinears: K^{ab}(E_c) = -(1/4) kappa eta^aa eta^bb eps_abcd A^d"""
    def __init__(self, e, psi, psiD, kap, st2, sign=1.0):
        E1.StdSpin.__init__(self, e, psi, N, LOR, st2.G)
        self.st2 = st2; self.kap = sign * float(kap); self.pD = [(st2.BL[S], E1.pfun(p, N)) for S, p in psiD.items()]
    def A_at(self, x):
        chi = sum(f(x) * B for (B, f) in self.pD) @ self.st2.u
        return self.st2.bil(chi)['A']
    def Kmat(self, x):
        s = self.A_at(x); e = self.emat(x); out = np.zeros((N, N, N))
        for a, b, c in itertools.permutations(range(N), 3):
            d = [y for y in range(N) if y not in (a, b, c)][0]
            k = -0.25 * self.kap * LOR[a] * LOR[b] * E2.perm([a, b, c, d]) * s[d]   # K^{ab}(E_c)
            out[:, a, b] += k * e[c, :] * LOR[b]                                   # omega_mu^a_b += K^{ab}(E_c) e^c_mu eta_bb
        return out
def std_frame(e, psi, psiD, kap, st2, self_test):
    """[std] every matrix-side quantity of one frame"""
    G = st2.G; I4 = np.eye(4); MI = G[0] @ G[1] @ G[2] @ G[3]; x0 = np.zeros(N); k = float(kap)
    sa = StdAxial(e, psi, psiD, kap, st2); sd = sa.at_origin(); sL = E1.StdSpin(e, psi, N, LOR, G); sdL = sL.at_origin()
    s = sa.A_at(x0); S = sum(s[d] * G[d] for d in range(N)); AA = float(sum(LOR[d] * s[d] ** 2 for d in range(N)))
    E = sL.Emat(x0); omL = sL.omega(x0); dA = [sa.d1(sa.A_at, x0, m) for m in range(N)]
    ns = [[sum(E[mu, c] * (dA[mu][d] + sum(omL[mu, d, f] * s[f] for f in range(N))) for mu in range(N)) for d in range(N)] for c in range(N)]
    V = sum(LOR[c] * ns[c][d] * (G[c] @ G[d]) for c in range(N) for d in range(N))
    P0 = sdL['Psi0']; nbL = sdL['nb0']
    FO = sum(MI @ (LOR[c] * G[c] @ S - s[c] * I4) @ nbL[c] for c in range(N))
    pred6 = sdL['Lap'] - 0.25 * sdL['Rs'] * P0 - 0.75 * k * FO - 0.375 * k * MI @ V @ P0 + (9 / 64) * k * k * AA * P0
    sl = lambda nb: sum(LOR[b] * G[b] @ nb[b] for b in range(N))
    out = dict(sd=sd, s=s, AA=AA, e6=E1.relerr(sd['D2'], pred6), e6a=E1.relerr(sl(sd['nb0']) - sl(nbL), 0.375 * k * MI @ S @ P0),
               eR=abs((sd['Rs'] - sdL['Rs']) - 0.375 * k * k * AA) / max(1.0, abs(sd['Rs'])), eC=E1.relerr(sd['D2'] - sd['Lap'], sd['pred']))
    Tl = np.array([[[LOR[a] * sd['Tf'][a, b, c] for c in range(N)] for b in range(N)] for a in range(N)])
    Tp = np.zeros((N, N, N))
    for a, b, c in itertools.permutations(range(N), 3): Tp[a, b, c] = 0.5 * k * E2.perm([a, b, c, [y for y in range(N) if y not in (a, b, c)][0]]) * s[[y for y in range(N) if y not in (a, b, c)][0]]
    out['eT'] = E1.relerr(Tl, Tp); out['eTanti'] = E1.relerr(Tl + np.transpose(Tl, (1, 0, 2)), 0 * Tl) + E1.relerr(Tl + np.transpose(Tl, (0, 2, 1)), 0 * Tl)
    if self_test:                                                                  # Hehl-Datta form: i Gamma^a nabla'_a chi = i Gamma^a nabla_a chi + (3 kappa/8) A_d Gamma^d gamma5 chi
        chi = P0 @ st2.u; lhs = 1j * (sl(sd['nb0']) @ st2.u); rhs = 1j * (sl(nbL) @ st2.u) + 0.375 * k * sum(LOR[d] * s[d] * st2.Gup[d] @ st2.g5 for d in range(N)) @ chi
        out['eHD'] = E1.relerr(lhs, rhs)
    sw = StdAxial(e, psi, psiD, kap, st2, sign=-1.0).at_origin()                   # [ctl] contorsion of the wrong sign
    out['w6a'] = E1.relerr(sl(sw['nb0']) - sl(nbL), 0.375 * k * MI @ S @ P0)
    out['w6'] = E1.relerr(sw['D2'], pred6)
    return out

# ------------------------------------------------------------------------------------------------ one axial frame
def axial_frame(seed, kap, st2, lam, self_test=False, mixed=False, zero=False, sizes=None):
    d = E1.lc_setup(N, LOR, seed); Gv, e, E, E0, om = d['Gv'], d['e'], d['E'], d['E0'], d['om']; Fm = Gv.Fm
    psiD = rand_even_poly(random.Random(seed + 9000))
    if self_test: d['psi'] = psiD
    psi = d['psi']; r = {}
    with trunc(N, xdeg=1):
        s, j, _, _ = E2.currents(psiD, LOR, N); sv = E2.vec(s); jv = E2.vec(j)
        Kst = axial_K(Gv, e, sv, kap); omp = om_sum(Gv, om, Kst)
        T0l = Gv.torsion(om, e); Tp = Gv.torsion(omp, e); Tc = torsion_closed(Gv, e, sv, kap)
        r['T_closed'] = all(form_zero(t) for t in T0l) and all(form_zero(Fm.add(Tp[c], Tc[c], -1)) for c in range(N))
    s0 = [at0(p, N) for p in sv]; ss0 = sum((LOR[x] * s0[x] ** 2 for x in range(N)), F(0)); Is0 = mv_mul(IM, {1 << x: s0[x] for x in range(N) if s0[x]}, LOR)
    Tf = Tf_at0(Tp, E0); Tl = {(a, b, c): LOR[a] * Tf[(a, b, c)] for a in range(N) for b in range(N) for c in range(N)}
    anti, tr = E2.antisym_report(Tl); r['T_anti'] = anti and all(x == 0 for x in tr)
    ops0 = E1.engine_ops(d); ops = E1.engine_ops(d, om=omp); psi0 = ops['psi0']
    cL = curv_pieces(Gv, om, E0); cK = curv_pieces(Gv, omp, E0); R = cL['R']
    terms = clause_terms(cK, Tf, ops); res = mv_add(ops['D2'], ops['Lap'], -1)
    r['res'], r['terms'] = res, terms
    r['clause'] = (res == mv_sum(list(zip(terms, COEF))))
    r['nonzero'] = all(bool(t) for t in terms)
    r['wrong'] = [res != mv_sum(list(zip(terms, [(-c if i == w else c) for i, c in enumerate(COEF)]))) for w in range(4)]
    ns = nabla_vec(Gv, om, sv, E0); V = vgrad(ns); div = V.get(0, F(0)); curl = grade(V, 2); Icurl = mv_mul(IM, curl, LOR); IV = mv_mul(IM, V, LOR)
    FO = first_order(s0, ops0['nab0']); Lap = ops0['Lap']; T2 = T_sq(Tf)
    # (R) term by term
    r['P1'] = (cK['R'] - R == F(3, 8) * kap ** 2 * ss0) and (T2 == -F(3, 2) * kap ** 2 * ss0) and (cK['R'] - R == -T2 / 4)
    ricd = all(cK['ric'][(b, dd)] - cK['ric'][(dd, b)] == -kap / 2 * sum((E2.perm([a, b, dd, f]) * LOR[a] * ns[a][f] for a in range(N) for f in range(N)), F(0)) for b in range(N) for dd in range(N))
    r['P2'] = ricd and cK['K2'] == mv_scale(Icurl, -2 * kap)
    r['P3'] = (cK['A4'] == kap / 8 * div) and cK['K4'] == clean({15: -3 * kap * div})
    r['P4'] = mv_scale(terms[1], F(-1, 2)) == mv_sum([(FO, -kap / 2), (psi0, F(3, 16) * kap ** 2 * ss0)])
    pred5 = mv_sum([(Lap, 1), (FO, -kap / 4), (mv_mul(Icurl, psi0, LOR), -kap / 8), (psi0, F(3, 64) * kap ** 2 * ss0)])
    r['P5'] = (ops['Lap'] == pred5)
    pred6 = mv_sum([(Lap, 1), (psi0, -R / 4), (FO, -3 * kap / 4), (mv_mul(IV, psi0, LOR), -3 * kap / 8), (psi0, F(9, 64) * kap ** 2 * ss0)])
    r['P6'] = (ops['D2'] == pred6) and (F(9, 64) * kap ** 2 * ss0 == -F(3, 32) * T2)
    # plain derivatives in place of nabla s: [ctl]
    Vp = vgrad(nabla_vec(Gv, om, sv, E0, plain=True)); r['plain'] = (cK['K2'] != mv_scale(mv_mul(IM, grade(Vp, 2), LOR), -2 * kap)) and (cK['A4'] != kap / 8 * Vp.get(0, F(0)))
    # (S) operator, 1-jets; (B) beta family
    with trunc(N, xdeg=1):
        PhiL = E1.slash(E1.nabla_jet(Gv, om, E, psi, N, 1), N, LOR, LOR); PhiK = E1.slash(E1.nabla_jet(Gv, omp, E, psi, N, 1), N, LOR, LOR)
        IsPsi = E2.mvp_mul(E2.mvp_mul(E2.mvp_const(IM, N), {1 << x: sv[x] for x in range(N) if sv[x]}, LOR), psi, LOR)
    r['P6a'] = jet_zero(PhiK, PhiL, IsPsi, F(3, 8) * kap); r['P6a_wrong'] = not jet_zero(PhiK, PhiL, IsPsi, -F(3, 8) * kap)
    Ipsi = mv_mul(IM, psi0, LOR); Icp = mv_mul(Icurl, psi0, LOR); r['beta'] = True; r['beta_ctl'] = []
    for beta in (kap / 8, kap / 4, 3 * kap / 8):
        Db = mv_add(dbeta_sq(Gv, omp, E, PhiK, IsPsi, Is0, beta - 3 * kap / 8), ops['Lap'], -1)
        zero_order = mv_sum([(psi0, -R / 4), (Icp, kap / 8 - beta), (Ipsi, -beta * div), (psi0, (beta ** 2 - 3 * kap ** 2 / 64) * ss0)])
        r['beta'] &= (Db == mv_add(zero_order, FO, kap / 4 - 2 * beta))
        if beta == kap / 8: r['third'] = (Db == mv_sum([(psi0, -R / 4), (Ipsi, -kap / 8 * div), (psi0, -kap ** 2 / 32 * ss0)]))
        else: r['beta_ctl'].append(Db != zero_order)
    r['D3eq'] = (dbeta_sq(Gv, omp, E, PhiK, IsPsi, Is0, F(0)) == ops['D2'])
    if mixed:                                                                      # [ctl] K* plus the vector-current (trace) contorsion
        with trunc(N, xdeg=1): ompm = om_sum(Gv, om, Kst, trace_K(Gv, e, jv, kap, lam)); Tm = Gv.torsion(ompm, e)
        opm = E1.engine_ops(d, om=ompm); cM = curv_pieces(Gv, ompm, E0); Tfm = Tf_at0(Tm, E0)
        resm = mv_add(opm['D2'], opm['Lap'], -1); r['mix_clause'] = (resm == mv_sum(list(zip(clause_terms(cM, Tfm, opm), COEF))))
        r['mix_P1'] = (cM['R'] - R != F(3, 8) * kap ** 2 * ss0); r['mix_P5'] = (opm['Lap'] != pred5); r['mix_P6'] = (opm['D2'] != pred6)
    if zero:                                                                       # kappa = 0: omega' = omega_LC
        with trunc(N, xdeg=1): om0 = om_sum(Gv, om, axial_K(Gv, e, sv, F(0)))
        op0 = E1.engine_ops(d, om=om0); c0 = curv_pieces(Gv, om0, E0)
        r['zero'] = (mv_add(op0['D2'], op0['Lap'], -1) == mv_scale(op0['psi0'], -c0['R'] / 4)) and op0['D2'] == ops0['D2'] and c0['R'] == R
    if sizes is not None and not sizes: sizes.append('    frame %d: kappa = %s, R = %s, R\' = %s, s.s = %s, |T|^2 = %s, div s = %s, components of K\'_2: %d' % (seed, kap, R, cK['R'], ss0, T2, div, len(cK['K2'])))
    r['std'] = std_frame(e, psi, psiD, kap, st2, self_test)
    G = st2.G; BL = E1.blades(G); sd = r['std']['sd']
    r['bs_D2'] = E1.relerr(E1.to_mat(BL, ops['D2']), sd['D2']); r['bs_Lap'] = E1.relerr(E1.to_mat(BL, ops['Lap']), sd['Lap'])
    r['bs_T'] = E1.relerr(np.array([[[float(Tf[(c, a, b)]) for b in range(N)] for a in range(N)] for c in range(N)]), sd['Tf'])
    r['bs_R'] = abs(float(cK['R']) - sd['Rs']) / max(1.0, abs(sd['Rs'])); r['bs_s'] = E1.relerr(np.array([float(x) for x in s0]), r['std']['s'])
    return r

# ------------------------------------------------------------------------------------------------ constant frame, constant psi_D (E2's S2/S3 setting)
def const_frame_scope(rng):
    Gv = Grav(N, Lie(LOR)); A, det, inv = E2.rand_matrix(rng); e = E2.const_frame(A, N); kap = F(2)
    E = [[const(N, inv[mu][a]) for a in range(N)] for mu in range(N)]
    psi = {S: p for S, p in ((S, E1.nz_poly(gs.rpoly(rng, N, 2, .5))) for S in range(16)) if p}
    psiD = E2.rand_even(rng); s, _, _, _ = E2.currents({S: E2.cp(v, N) for S, v in psiD.items()}, LOR, N); sv = E2.vec(s)
    s0 = [at0(p, N) for p in sv]; ss0 = sum((LOR[x] * s0[x] ** 2 for x in range(N)), F(0))
    with trunc(N, xdeg=1): K = axial_K(Gv, e, sv, kap); T = Gv.torsion(K, e)
    d = dict(Gv=Gv, e=e, E=E, E0=inv, om=[{} for _ in range(Gv.G)], psi=psi, n=N, sq=LOR)
    ops = E1.engine_ops(d, om=K); cK = curv_pieces(Gv, K, inv); Tf = Tf_at0(T, inv)
    terms = clause_terms(cK, Tf, ops); res = mv_add(ops['D2'], ops['Lap'], -1)
    w, rank, cons = E1.fit([(res, terms)], 4)
    return dict(R=(cK['R'] == F(3, 8) * kap ** 2 * ss0 and ss0 != 0), K24=(not cK['K2'] and not cK['K4']), clause=(res == mv_sum(list(zip(terms, COEF)))),
                fit=(cons and rank == 2 and w[0] == F(-1, 4) and w[1] == F(-1, 2)), rank=rank)

# ------------------------------------------------------------------------------------------------ main
def main():
    st2 = E2.Std(); rng = random.Random(5150)
    head('E1-axial part V: the vector-current contorsion of E2 (mode=\'vector\') at constant frames, for the trace control')
    lam, okl, lams = lambda_vector_mode(rng)
    chk('bit', okl and lam == F(-1, 4), "E2's stationary contorsion with the vector-current bilinear is pure trace, K^{pq}(E_c) = lambda kappa (delta_pc j^q - delta_qc j^p), with one lambda = %s on 2 draws" % lam)
    tick('part V')
    head('E1-axial part A: omega\' = omega_LC + K* (E2\'s axial contorsion) on random polynomial frames (degree 2), n = 4, (+,-,-,-), the origin')
    cases = [(701, F(1), False, True, True), (702, F(2, 5), False, True, False), (703, F(3), False, False, False), (704, F(3, 7), True, False, False)]
    rs = []; sizes = []
    for seed, kap, self_test, mixed, zero in cases:
        rs.append(axial_frame(seed, kap, st2, lam, self_test, mixed, zero, sizes)); tick('frame %d' % seed)
    print(sizes[0]); k = len(rs); fit3 = [r for r, c in zip(rs, cases) if not c[2]]
    al = lambda key: all(r[key] for r in rs)
    chk('bit', al('T_closed') and al('T_anti'), 'the A3 omega is torsion-free and the engine torsion of omega_LC + K* equals E2\'s closed form T^a = (kappa/2) sq_a eps s e e to first order; T_abc totally antisymmetric, no trace (%d frames)' % k)
    chk('bit', al('clause'), "E1's clause with the fixed coefficients (-1/4, -1/2, 1/8, 1/8) holds exactly on all %d axial frames (the fourth with the test field psi_D itself)" % k)
    chk('bit', al('nonzero'), "the four terms R' psi, gamma^a gamma^b T^c_ab nabla'_c psi, K'_2 psi and K'_4 psi are all non-zero on every axial frame")
    w, rank, cons = E1.fit([(r['res'], r['terms']) for r in fit3], 4)
    chk('bit', cons and rank == 4 and w == COEF, 'exact fit on the %d axial frames alone (generic test spinors): unique coefficients %s, rank %d: the axial data fix all four' % (len(fit3), [str(x) for x in w] if w else 'none', rank))
    chk('bit', al('P1'), "R' = R - |T|^2/4 = R + (3/8) kappa^2 (s.s), with |T|^2 = T_abc T^abc = -(3/2) kappa^2 (s.s) from the engine torsion (%d frames)" % k)
    chk('bit', al('P2'), "Ric'_bd - Ric'_db = -(kappa/2) eps_abdf nabla^a s^f, so (1/8) K'_2 = -(kappa/4) I curl s (nabla s from the engine's D_vector with omega_LC)")
    chk('bit', al('P3'), "R'_[0123] = (kappa/8) div s, so (1/8) K'_4 = -(3 kappa/8) (div s) I")
    chk('bit', al('P4'), "-(1/2) gamma^a gamma^b T^c_ab nabla'_c psi = -(kappa/2) I (gamma^c ^ s) nabla_c psi + (3/16) kappa^2 (s.s) psi (nabla: Levi-Civita)")
    chk('bit', al('P5'), "nabla'^a nabla'_a psi = nabla^a nabla_a psi - (kappa/4) I (gamma^c ^ s) nabla_c psi - (kappa/8) I (curl s) psi + (3/64) kappa^2 (s.s) psi (the frame-index term does not see K*)")
    chk('bit', al('P6a'), "Dslash' psi = Dslash psi + (3 kappa/8) I s psi as first-order jets (I s psi with s and psi as polynomials)")
    chk('bit', al('P6'), "skew-torsion form with the Levi-Civita Laplacian: Dslash'^2 psi = nabla^a nabla_a psi - (R/4) psi - (3 kappa/4) I (gamma^c ^ s) nabla_c psi - (3 kappa/8) I (gamma^c nabla_c s) psi + (9/64) kappa^2 (s.s) psi, and (9/64) kappa^2 (s.s) = -(3/32) |T|^2")
    chk('bit', al('beta') and al('D3eq'), "D_beta = Dslash + beta I s: D_beta^2 psi - nabla'^a nabla'_a psi = [-R/4 + (kappa/4 - 2 beta) I (gamma^c ^ s) nabla_c + (kappa/8 - beta) I curl s - beta (div s) I + (beta^2 - 3 kappa^2/64)(s.s)] psi at beta = kappa/8, kappa/4, 3 kappa/8; D_{3 kappa/8} = Dslash'")
    chk('bit', al('third'), "one third of the torsion term, beta = kappa/8: D_beta^2 psi - nabla'^a nabla'_a psi = [-R/4 - (kappa/8)(div s) I - (kappa^2/32)(s.s)] psi, an operator of order zero")
    for wi, lab in enumerate(['+1/4 for R\'', '+1/2 for the T nabla\' term', '-1/8 for K\'_2', '-1/8 for K\'_4']):
        chk('ctl', all(r['wrong'][wi] for r in rs), "wrong clause coefficient (%s) fails on %d of %d axial frames" % (lab, sum(int(r['wrong'][wi]) for r in rs), k))
    chk('ctl', al('P6a_wrong'), 'the wrong sign of the torsion term, Dslash - (3 kappa/8) I s, is not Dslash\' (%d of %d frames)' % (sum(int(r['P6a_wrong']) for r in rs), k))
    chk('ctl', al('plain'), 'plain derivatives of the components E_c(s^d) in place of nabla_c s: the K\'_2 and K\'_4 predictions fail (%d of %d frames)' % (sum(int(r['plain']) for r in rs), k))
    chk('ctl', all(all(r['beta_ctl']) for r in rs), 'beta = kappa/4 and 3 kappa/8: the zero-order part alone does not give D_beta^2 - nabla\'^a nabla\'_a (a first-order term remains), %d of %d cases' % (sum(sum(int(x) for x in r['beta_ctl']) for r in rs), 2 * k))
    mx = [r for r in rs if 'mix_clause' in r]
    chk('bit', all(r['mix_clause'] for r in mx), "K* plus the vector-current (trace) contorsion: E1's clause still holds exactly (%d frames): the clause is general" % len(mx))
    chk('ctl', all(r['mix_P1'] for r in mx), "with the trace part, R' - R is not -|K_[abc]|^2 = (3/8) kappa^2 (s.s) (%d of %d frames)" % (sum(int(r['mix_P1']) for r in mx), len(mx)))
    chk('ctl', all(r['mix_P5'] for r in mx), "with the trace part, the frame-index term sees K and the Laplacian reduction fails (%d of %d frames)" % (sum(int(r['mix_P5']) for r in mx), len(mx)))
    chk('ctl', all(r['mix_P6'] for r in mx), "with the trace part, the skew-torsion form of Dslash'^2 fails (%d of %d frames)" % (sum(int(r['mix_P6']) for r in mx), len(mx)))
    z = [r for r in rs if 'zero' in r]
    chk('bit', all(r['zero'] for r in z), "kappa = 0: omega' = omega_LC, Dslash'^2 - nabla'^a nabla'_a = -R/4 (E1's torsion-free result), %d frame" % len(z))
    tick('part A')
    head('E1-axial part C: a constant frame with a constant psi_D (E2\'s S2/S3 setting), omega\' = K*')
    cs = const_frame_scope(rng)
    chk('bit', cs['R'] and cs['K24'] and cs['clause'] and cs['fit'], "scope: nabla s = 0 there, so R' = (3/8) kappa^2 (s.s), K'_2 = 0 and K'_4 = 0; the clause holds and an exact fit has rank %d: only -1/4 and -1/2 are tested by constant axial fields" % cs['rank'])
    tick('part C')
    head('E1-axial part S: numpy route (Dirac matrices, Christoffel symbols, contorsion from chibar Gamma gamma5 chi at every point), the same frames')
    sds = [r['std'] for r in rs]; mx_ = lambda key: max(sd[key] for sd in sds if key in sd)
    chk('std', mx_('eT') < 1e-9 and mx_('eTanti') < 1e-9, 'std torsion of the contorsion: T_abc totally antisymmetric and = (kappa/2) eps_abcd A^d (rel. %.1e)' % mx_('eT'))
    chk('std', mx_('eR') < 1e-6, "std R' - R = (3/8) kappa^2 (A.A) (finite differences, rel. %.1e)" % mx_('eR'))
    chk('std', mx_('e6a') < 1e-6, 'std: Gamma^a nabla\'_a Psi = Gamma^a nabla_a Psi + (3 kappa/8) M(I) S Psi at the origin (rel. %.1e)' % mx_('e6a'))
    chk('std', mx_('eHD') < 1e-6, 'std, test field = psi_D: i Gamma^a nabla\'_a chi = i Gamma^a nabla_a chi + (3 kappa/8) A_d Gamma^d gamma5 chi (rel. %.1e): the Hehl-Datta operator in its recalled form' % mx_('eHD'))
    chk('std', mx_('eC') < 1e-6, "std: E1's matrix clause Dslash'^2 - nabla'^a nabla'_a = (1/8) R'^cd_ab gamma^a gamma^b gamma_c gamma_d - (1/2) gamma^a gamma^b T^c_ab nabla'_c with the axial contorsion (rel. %.1e)" % mx_('eC'))
    chk('std', mx_('e6') < 1e-6, 'std: the skew-torsion form with the Levi-Civita Laplacian, nabla_c S by differences plus the std spin connection (rel. %.1e)' % mx_('e6'))
    chk('ctl', min(sd['w6a'] for sd in sds) > 1e-3 and min(sd['w6'] for sd in sds) > 1e-3, '[std] contorsion of the wrong sign: the operator and the squared form both fail (rel. defects >= %.2f, %.2f)' % (min(sd['w6a'] for sd in sds), min(sd['w6'] for sd in sds)))
    chk('bit==std', max(r['bs_D2'] for r in rs) < 1e-6, "engine Dslash'(Dslash' psi)(0) = std (rel. %.1e)" % max(r['bs_D2'] for r in rs))
    chk('bit==std', max(r['bs_Lap'] for r in rs) < 1e-6, "engine nabla'^a nabla'_a psi(0) = std (rel. %.1e)" % max(r['bs_Lap'] for r in rs))
    chk('bit==std', max(r['bs_T'] for r in rs) < 1e-9 and max(r['bs_R'] for r in rs) < 1e-6, "engine T^c_ab and R' = std (rel. %.1e, %.1e)" % (max(r['bs_T'] for r in rs), max(r['bs_R'] for r in rs)))
    chk('bit==std', max(r['bs_s'] for r in rs) < 1e-12, 'engine s(0) = psi_D gamma_3 psi_D~ equals chibar Gamma^d gamma5 chi, chi = M(psi_D) u (E2\'s dictionary; rel. %.1e)' % max(r['bs_s'] for r in rs))
    tick('part S')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('E1-axial')

if __name__ == '__main__': main()
