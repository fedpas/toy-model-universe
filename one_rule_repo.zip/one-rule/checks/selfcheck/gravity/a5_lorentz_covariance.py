#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A5.  Local Lorentz covariance of the Einstein form with a NON-constant Lambda(x).   python3 a5_lorentz_covariance.py [n ...]   (default 3 4 5)

 Claim.  e' = Lambda e with Lambda(x) in O(1, n-1) and omega' = the engine's own closed-form connection of e' (A3, recomputed from e'):
           W' = Lambda W Lambda^{-1} - dLambda Lambda^{-1}      (W^c_b = h_{Ab}^c omega^A, the matrix the engine's D_vector uses)
           R'^{bc} = Lambda^b_d Lambda^c_f R^{df}           E_a(e') = det(Lambda) (Lambda^{-1})^b_a E_b(e)     (c = 0 and c = 1/3)
         and the coordinate tensor G - Lambda_n delta read off E (A4: E_a = -M^b_a Theta_b) is the same for e and e'.
 [bit]  engine: closed-form omega (b1lib), R = d omega + 1/4 [omega, omega], E_a, D_vector; rotor jets U gamma_b U~ by the bit rule (bmul).
 [std]  own polynomial code: Lambda^T eta Lambda = eta, metric of e' = metric of e, Christoffel symbols -> spin connection (tetrad postulate)
        and the textbook gauge law with the ordinary derivative of the jets; numpy: permutation-symbol identity, five-point finite differences.
 Jets: frames and Lambda are exact 2-jets at the origin (E at a point needs the 2-jet of the frame); a 3-jet run shows nothing changes.
 Controls: old omega with the rotated frame; a Euclidean rotation; det -1 without its sign; Lambda cut to its 1-jet; the connection law without
 its inhomogeneous term; the vector law instead of the covector law."""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
from a4_einstein_tensor import numeric_einstein

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ [std] jets of matrices (own code: sp_mul / sp_add / sp_der)
def jtrunc(p, deg, n): return {k: v for k, v in p.items() if sum(k[:n]) <= deg}
def peq(p, q): return all(v == 0 for v in sp_add(p, q, -1).values())
def jmat_mul(A, B, n, deg):
    out = [[{} for _ in range(len(B[0]))] for _ in range(len(A))]
    for i in range(len(A)):
        for j in range(len(B[0])):
            t = {}
            for l in range(len(B)):
                if A[i][l] and B[l][j]: t = sp_add(t, sp_mul(A[i][l], B[l][j], deg, n))
            out[i][j] = t
    return out
def jmat_add(A, B, c=1): return [[sp_add(a, b, c) for a, b in zip(ra, rb)] for ra, rb in zip(A, B)]
def jmat_id(n, nv): return [[const(nv, 1) if i == j else {} for j in range(n)] for i in range(n)]
def jmat_at0(A, nv): return [[at0(x, nv) for x in row] for row in A]
def jmat_inv(M, n, nv, deg):
    """inverse of a matrix of polynomials with an invertible constant part, as a jet of x-degree deg (Neumann series, exact for the kept terms)"""
    M0 = jmat_at0(M, nv); det, M0i = det_inv(M0); assert det != 0
    C = [[const(nv, M0i[i][j]) for j in range(n)] for i in range(n)]
    N = jmat_mul(C, jmat_add(M, [[const(nv, M0[i][j]) for j in range(n)] for i in range(n)], -1), n, deg)
    out = [[dict(x) for x in row] for row in C]; term = C
    for _ in range(deg):
        term = [[scale(x, -1) for x in row] for row in jmat_mul(N, term, n, deg)]; out = jmat_add(out, term)
    return out
def lorentz_inv(L, sq, n):
    """(Lambda^{-1})^d_b = eta_dd Lambda^b_d eta_bb (valid where Lambda^T eta Lambda = eta)"""
    return [[scale(L[b][d], sq[d] * sq[b]) for b in range(n)] for d in range(n)]
def lorentz_defect(L, sq, n, deg):
    """the entries (b, c) where Lambda^T eta Lambda - eta is not zero up to x-degree deg"""
    bad = []
    for b in range(n):
        for c in range(n):
            t = const(n, -sq[b]) if b == c else {}
            for a in range(n):
                if L[a][b] and L[a][c]: t = sp_add(t, sp_mul(L[a][b], L[a][c], deg, n), sq[a])
            if any(v != 0 for v in t.values()): bad.append((b, c))
    return bad

# ------------------------------------------------------------------------------------------------ local Lorentz maps as jets
def rand_antisym_jet(rng, n, deg=2, coef=2, density=.6):
    mons = [ex for ex in itertools.product(range(deg + 1), repeat=n) if sum(ex) <= deg]
    A = [[{} for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            p = {}
            for ex in mons:
                if rng.random() < density:
                    v = F(rng.randint(-coef, coef), rng.randint(1, 3))
                    if v: p[ex] = v
            A[i][j] = p; A[j][i] = scale(p, -1)
    return A
def cayley_jet(X, n, deg):
    """[std] (1 + X)(1 - X)^{-1} as a jet of x-degree deg"""
    I = jmat_id(n, n)
    return jmat_mul(jmat_add(I, X), jmat_inv(jmat_add(I, X, -1), n, n, deg), n, deg)
def rand_lorentz_jet(rng, n, sq, deg=2, euclid=False):
    """Cayley transform of a random polynomial matrix X(x) = eta A(x) (A antisymmetric, degree 2, X(0) != 0): Lambda^T eta Lambda = eta.
    euclid=True: X = A (an ordinary rotation, NOT Lorentz; a control).  Returns (Lambda jet, X)."""
    while True:
        A = rand_antisym_jet(rng, n)
        X = A if euclid else [[scale(A[i][j], sq[i]) for j in range(n)] for i in range(n)]
        X0 = jmat_at0(X, n)
        if any(X0[i][j] for i in range(n) for j in range(n)) and det_inv([[F(int(i == j)) - X0[i][j] for j in range(n)] for i in range(n)])[0] != 0:
            return cayley_jet(X, n, deg), X
def mv_mul(X, Y, sq, n, deg):
    """bit-rule product of multivectors {blade mask: polynomial}, coefficients cut at x-degree deg"""
    out = {}
    for m1, p1 in X.items():
        for m2, p2 in Y.items():
            m, s = bmul(m1, m2, sq)
            if s == 0: continue
            q = sp_add(out.get(m, {}), sp_mul(p1, p2, deg, n), s)
            if q: out[m] = q
            else: out.pop(m, None)
    return out
def rotor_lambda_jet(betas, n, sq, deg=2):
    """[bit] Lambda^a_b gamma_a = U gamma_b U~ / (U U~),  U = prod_k (1 + beta_k(x) gamma_a gamma_b) over the planes (a, b) in betas (bit-rule products).
    Returns (Lambda jet, grades_ok, N0): grades_ok says U U~ is a pure scalar and every U gamma_b U~ a pure vector; N0 = (U U~)(0)."""
    one = const(n, 1); U = {0: one}; Ut = {0: one}
    for (a, b), beta in betas: U = mv_mul(U, {0: one, (1 << a) | (1 << b): beta}, sq, n, deg)
    for (a, b), beta in reversed(betas): Ut = mv_mul(Ut, {0: one, (1 << a) | (1 << b): scale(beta, -1)}, sq, n, deg)
    N = mv_mul(U, Ut, sq, n, deg); ok = set(N) <= {0}; N0 = at0(N.get(0, {}), n)
    D = sp_add(N.get(0, {}), const(n, N0), -1); invN = const(n, 1 / N0); term = const(n, 1 / N0)
    for _ in range(deg): term = scale(sp_mul(term, D, deg, n), -1 / N0); invN = sp_add(invN, term)
    L = [[{} for _ in range(n)] for _ in range(n)]
    for b in range(n):
        V = mv_mul(mv_mul(U, {1 << b: one}, sq, n, deg), Ut, sq, n, deg); ok &= all(popc(m) == 1 for m in V)
        for a in range(n):
            if V.get(1 << a): L[a][b] = sp_mul(V[1 << a], invN, deg, n)
    return L, ok, N0
def rand_betas(rng, n, deg=2, pt=False):
    mons = [ex for ex in itertools.product(range(deg + 1), repeat=n) if 0 < sum(ex) <= deg]; out = []
    for (a, b) in itertools.combinations(range(n), 2):
        b0 = F(rng.randint(-2, 2), 5) if a == 0 else F(rng.randint(-3, 3), 4)
        if pt and (a, b) == (0, 1): b0 = F(3, 2)                                   # |beta(0)| > 1 in a boost plane: U U~ < 0
        p = {(0,) * n: b0} if b0 else {}
        for ex in mons:
            if rng.random() < .4:
                v = F(rng.randint(-2, 2), rng.randint(1, 4))
                if v: p[ex] = v
        out.append(((a, b), p))
    return out
def rotate_frame(L, e, n, deg):
    """e'^a = Lambda^a_b e^b, coefficients cut at x-degree deg"""
    out = []
    for a in range(n):
        form = {}
        for mu in range(n):
            t = {}
            for b in range(n):
                p = e[b].get(1 << mu, {})
                if L[a][b] and p: t = sp_add(t, sp_mul(L[a][b], p, deg, n))
            if t: form[1 << mu] = t
        out.append(form)
    return out
def nonconstant(L, n): return tuple(any(deg_part(x, d, n) for row in L for x in row) for d in (1, 2))

# ------------------------------------------------------------------------------------------------ engine and standard connection
def engine_W(Gv, om, n, nv=None):
    """[bit] the connection matrix of the engine's covariant derivative: W[c][b] = (D_vector X)^c for the constant unit vector X = gamma_b (a 1-form)"""
    nv = nv or n; W = [[None] * n for _ in range(n)]
    for b in range(n):
        DX = Gv.D_vector(om, [({0: {(0,) * nv: F(1)}} if i == b else {}) for i in range(n)])
        for c in range(n): W[c][b] = DX[c]
    return W
def std_spin_connection(e, n, sq):
    """[std] omega_mu^a_b = (Gamma^l_{mu nu} e^a_l - d_mu e^a_nu) E^nu_b as first-order jets (tetrad postulate; Christoffel symbols of g = e^T eta e).
    Returns om[a][b][mu] (polynomials of x-degree <= 1).  Never touches the engine."""
    g = std_metric(e, n, sq, n, 2); gi, g0, g0i = std_inverse_metric(g, n, n, 1); Gam = {}
    for l in range(n):
        for m in range(n):
            for v in range(n):
                t = {}
                for s in range(n):
                    br = sp_add(sp_add(sp_der(g[(s, v)], m), sp_der(g[(s, m)], v)), sp_der(g[(m, v)], s), -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, 1, n), F(1, 2))
                Gam[(l, m, v)] = t
    em = [[jtrunc(e[a].get(1 << mu, {}), 2, n) for mu in range(n)] for a in range(n)]
    Einv = jmat_inv(em, n, n, 1); om = [[[{} for _ in range(n)] for _ in range(n)] for _ in range(n)]
    for a in range(n):
        for mu in range(n):
            row = []
            for v in range(n):
                t = scale(sp_der(em[a][v], mu), -1)
                for l in range(n):
                    if Gam[(l, mu, v)] and em[a][l]: t = sp_add(t, sp_mul(Gam[(l, mu, v)], em[a][l], 1, n))
                row.append(jtrunc(t, 1, n))
            for b in range(n):
                t = {}
                for v in range(n):
                    if row[v] and Einv[v][b]: t = sp_add(t, sp_mul(row[v], Einv[v][b], 1, n))
                om[a][b][mu] = t
    return om
def transformed_connection(L, om, sq, n, inhom=True):
    """[std] the textbook gauge law  Lambda om Lambda^{-1} - dLambda Lambda^{-1}  (ordinary derivative of the jets), first-order jets; inhom=False drops the
    second term (a control)"""
    Li = lorentz_inv(L, sq, n); out = [[[{} for _ in range(n)] for _ in range(n)] for _ in range(n)]
    for mu in range(n):
        T1 = jmat_mul(jmat_mul(L, [[om[a][b][mu] for b in range(n)] for a in range(n)], n, 1), Li, n, 1)
        if inhom: T1 = jmat_add(T1, jmat_mul([[sp_der(L[a][b], mu) for b in range(n)] for a in range(n)], Li, n, 1), -1)
        for a in range(n):
            for b in range(n): out[a][b][mu] = T1[a][b]
    return out
def W_matches(W, om, n):
    return all(peq(jtrunc(W[a][b].get(1 << mu, {}), 1, n), om[a][b][mu]) for a in range(n) for b in range(n) for mu in range(n))
def om_matches(o1, o2, n): return all(peq(o1[a][b][mu], o2[a][b][mu]) for a in range(n) for b in range(n) for mu in range(n))
def E_law(comp, L0, n, sq, with_det=True, vector=False):
    """predicted components of E(Lambda e) from those of E(e): det(Lambda0) (Lambda0^{-1})^b_a E_b  (vector=True: the wrong law Lambda0^a_b E_b)"""
    det = det_inv(L0)[0] if with_det else 1
    Li0 = [[sq[d] * L0[b][d] * sq[b] for b in range(n)] for d in range(n)]
    if vector: return {(a, mu): det * sum(L0[a][b] * comp[(b, mu)] for b in range(n)) for a in range(n) for mu in range(n)}
    return {(a, mu): det * sum(Li0[b][a] * comp[(b, mu)] for b in range(n)) for a in range(n) for mu in range(n)}
def R_law(Rab, L0, n):
    return {(b, c, mu, nu): sum(L0[b][d] * L0[c][f] * Rab.get((d, f, mu, nu), 0) for d in range(n) for f in range(n))
            for b in range(n) for c in range(n) for mu in range(n) for nu in range(n) if b != c and mu != nu}
def coord_tensor(comp, e, n):
    """the coordinate mixed tensor M^mu_nu = E^mu_b M^b_a e^a_nu with M^b_a read off E_a = -M^b_a Theta_b (A4)"""
    e0, E0, det = E0_of(e, n, n); M = mixed_from_components(comp, e0, det, n, s=-1)
    return [[sum(E0[m][b] * M[b][a] * e0[a][v] for a in range(n) for b in range(n)) for v in range(n)] for m in range(n)]
def engine_all(Gv, e, S, n, cs):
    """[bit] omega (closed form), R, W (through D_vector), R^{ab}_{mu nu}(0), E components for each c"""
    om, R = engine_om_R(Gv, e, S, n)
    return dict(om=om, R=R, W=engine_W(Gv, om, n), Rab=Rab_at0(Gv, R, n), comp={c: engine_E_from_R(Gv, e, R, n, c) for c in cs})
def perm_sgn(p):
    s = 1; p = list(p)
    for i in range(len(p)):
        while p[i] != i: j = p[i]; p[i], p[j] = p[j], p[i]; s = -s
    return s
def eps_identity_ok(L0, n):
    """[std] numpy: eps_{a1..an} L^a1_b1 .. L^an_bn = det(L) eps_{b1..bn}  (the reason for the factor det(Lambda))"""
    E = np.zeros((n,) * n)
    for p in itertools.permutations(range(n)): E[p] = perm_sgn(p)
    Lf = np.array([[float(x) for x in r] for r in L0]); let = 'abcdefgh'[:n]; out = 'ijklmnop'[:n]
    lhs = np.einsum(let + ',' + ','.join(let[i] + out[i] for i in range(n)) + '->' + out, E, *([Lf] * n))
    scale = max(1.0, float(np.max(np.abs(Lf)))) ** n                                       # float error model: products of n entries
    return np.allclose(lhs / scale, np.linalg.det(Lf) * E / scale, atol=1e-12)

# ------------------------------------------------------------------------------------------------ the run
def run_n(n, nframes, seed):
    head('n = %d: %d random polynomial frames (degree 2), non-constant Lambda(x) as 2-jets, c in {0, 1/3}' % (n, nframes))
    sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); cs = [F(0), F(1, 3)]
    Lam = lambda c: c * F((n - 1) * (n - 2), 2); rng = random.Random(seed)
    ok = {k: True for k in ('lorentz', 'nonconst', 'rotor_grades', 'pt_rotor', 'eps', 'metric', 'Wlaw', 'stdlaw', 'Rlaw', 'Elaw', 'coord', 'coord_std', 'numeric', 'jet3', 'nonvac')}
    ctl = {k: [0, 0] for k in ('c1 old omega with the rotated frame', 'c2 Euclidean rotation', 'c3 det -1 without det(Lambda)', 'c4 Lambda cut to its 1-jet',
                               'c5 connection law without -dLambda Lambda^{-1}', 'c6 vector law instead of covector law')}
    comps_seen = set(); nlam = 0; numerr = 0.0
    for fr in range(nframes):
        e = rand_frame(rng, n, deg=2, coef=2, density=.5)
        base = engine_all(Gv, e, S, n, cs); oms = std_spin_connection(e, n, sq)
        g = std_metric(e, n, sq, n, 2); R1, g0, g0i = std_riemann(g, n, n, 1); Gm = std_einstein_mixed(R1, g0, g0i, n)[0]
        ok['nonvac'] &= any(base['comp'][F(0)][k] != 0 for k in base['comp'][F(0)])
        L1, X1 = rand_lorentz_jet(rng, n, sq)
        P = [[F(0)] * n for _ in range(n)]
        lams = [('Cayley', L1), ('rotor', rotor_lambda_jet(rand_betas(rng, n), n, sq)), ('rotor with U U~ < 0', rotor_lambda_jet(rand_betas(rng, n, pt=True), n, sq))]
        for nm, dg in (('P Cayley', [1, -1] + [1] * (n - 2)), ('T Cayley', [-1, 1] + [1] * (n - 2)), ('PT Cayley', [-1, -1] + [1] * (n - 2))):
            lams.append((nm, [[scale(L1[a][b], dg[a]) for b in range(n)] for a in range(n)]))
        for nm, L in lams:
            if isinstance(L, tuple):                                                              # a rotor: (Lambda, grades_ok, N0)
                L, gok, N0 = L; ok['rotor_grades'] &= gok
                if nm.endswith('< 0'): ok['pt_rotor'] &= (N0 < 0 and at0(L[0][0], n) < 0)
                else: ok['pt_rotor'] &= (N0 > 0 and at0(L[0][0], n) > 0)
            nlam += 1; L0 = jmat_at0(L, n); d0 = det_inv(L0)[0]
            ok['lorentz'] &= (lorentz_defect(L, sq, n, 2) == [] and d0 in (1, -1)); ok['nonconst'] &= all(nonconstant(L, n))
            comps_seen.add((int(d0), 1 if L0[0][0] > 0 else -1)); ok['eps'] &= eps_identity_ok(L0, n)
            e2 = rotate_frame(L, e, n, 2)
            g2 = std_metric(e2, n, sq, n, 2); ok['metric'] &= all(peq(g2[k], g[k]) for k in g)
            rot = engine_all(Gv, e2, S, n, cs); law = transformed_connection(L, oms, sq, n)
            ok['Wlaw'] &= W_matches(rot['W'], law, n)
            ok['stdlaw'] &= om_matches(std_spin_connection(e2, n, sq), law, n)
            ctl['c5 connection law without -dLambda Lambda^{-1}'][1] += 1
            ctl['c5 connection law without -dLambda Lambda^{-1}'][0] += int(not W_matches(rot['W'], transformed_connection(L, oms, sq, n, inhom=False), n))
            pr = R_law(base['Rab'], L0, n); ok['Rlaw'] &= all(rot['Rab'].get(k, 0) == v for k, v in pr.items())
            M0 = coord_tensor(base['comp'][F(0)], e, n)
            for c in cs:
                ok['Elaw'] &= (rot['comp'][c] == E_law(base['comp'][c], L0, n, sq))
                Mc = coord_tensor(rot['comp'][c], e2, n); ok['coord'] &= (Mc == coord_tensor(base['comp'][c], e, n))
                ok['coord_std'] &= all(Mc[m][v] == Gm[m][v] - (Lam(c) if m == v else 0) for m in range(n) for v in range(n))
                if any(L0[a][b] != [[sq[d] * L0[bb][d] * sq[bb] for bb in range(n)] for d in range(n)][b][a] for a in range(n) for b in range(n)):
                    ctl['c6 vector law instead of covector law'][1] += 1
                    ctl['c6 vector law instead of covector law'][0] += int(rot['comp'][c] != E_law(base['comp'][c], L0, n, sq, vector=True))
                if d0 == -1:
                    ctl['c3 det -1 without det(Lambda)'][1] += 1
                    ctl['c3 det -1 without det(Lambda)'][0] += int(rot['comp'][c] != E_law(base['comp'][c], L0, n, sq, with_det=False))
                old = engine_E_from_R(Gv, e2, base['R'], n, c)
                ctl['c1 old omega with the rotated frame'][1] += 1; ctl['c1 old omega with the rotated frame'][0] += int(old != E_law(base['comp'][c], L0, n, sq))
            if nm == 'Cayley':
                big = max(abs(v) for row in L for x in row for v in x.values())
                print('    frame %d, Cayley Lambda: largest |coefficient| of the 2-jet = %.3g, of Lambda(0) = %.3g' % (fr, float(big), float(max(abs(x) for r in L0 for x in r))), flush=True)
            if nm == 'rotor':                                                                     # float route on the rotor (|beta_boost(0)| <= 2/5: well conditioned)
                Gnum = numeric_einstein(e2, n, sq); Gex = np.array([[float(x) for x in r] for r in Gm])
                err = float(np.max(np.abs(Gnum - Gex)) / max(1.0, np.max(np.abs(Gex)))); numerr = max(numerr, err); ok['numeric'] &= err < 1e-5
                if fr == 0: print('    frame 0, rotor Lambda: det Lambda(0) = %s, Lambda^0_0(0) = %s, E_0 along dx^1..dx^{n-1} = %s -> %s' % (d0, L0[0][0], base['comp'][F(0)][(0, 0)], rot['comp'][F(0)][(0, 0)]), flush=True)
        # per-frame extras: the 3-jet, the 1-jet control, the Euclidean control
        L1_3 = cayley_jet(X1, n, 3); r3 = engine_all(Gv, rotate_frame(L1_3, e, n, 3), S, n, cs)
        ok['jet3'] &= all(r3['comp'][c] == E_law(base['comp'][c], jmat_at0(L1, n), n, sq) for c in cs) and lorentz_defect(L1_3, sq, n, 3) == []
        L1j = [[jtrunc(x, 1, n) for x in row] for row in L1]; r1 = engine_all(Gv, rotate_frame(L1j, e, n, 2), S, n, cs)
        for c in cs:
            ctl['c4 Lambda cut to its 1-jet'][1] += 1; ctl['c4 Lambda cut to its 1-jet'][0] += int(r1['comp'][c] != E_law(base['comp'][c], jmat_at0(L1, n), n, sq))
        LE, _ = rand_lorentz_jet(rng, n, sq, euclid=True); rE = engine_all(Gv, rotate_frame(LE, e, n, 2), S, n, cs)
        for c in cs:
            ctl['c2 Euclidean rotation'][1] += 1; ctl['c2 Euclidean rotation'][0] += int(rE['comp'][c] != E_law(base['comp'][c], jmat_at0(LE, n), n, sq))
    chk('std', ok['lorentz'], 'n=%d: every Lambda (%d: Cayley, two rotors, P/T/PT times Cayley) satisfies Lambda^T eta Lambda = eta exactly as a 2-jet, det Lambda(0) = +-1' % (n, nlam))
    chk('std', ok['nonconst'], 'n=%d: every Lambda has non-zero first AND second derivatives at the point (not a constant map in disguise)' % n)
    chk('bit', ok['rotor_grades'], 'n=%d: rotor jets by the bit rule: U U~ is a pure scalar and every U gamma_b U~ a pure vector (all grades read)' % n)
    chk('bit', ok['pt_rotor'], 'n=%d: U U~ > 0 gives Lambda^0_0(0) > 0; one boost factor with |beta(0)| > 1 gives U U~ < 0 and Lambda^0_0(0) < 0 at det +1 (time orientation reversed)' % n)
    chk('bit', comps_seen == {(1, 1), (1, -1), (-1, 1), (-1, -1)}, 'n=%d: all four components of O(1,n-1) sampled (det, sign Lambda^0_0) = %s' % (n, sorted(comps_seen)))
    chk('std', ok['eps'], 'n=%d: numpy: eps_{a..} Lambda^a_b .. = det(Lambda) eps_{b..} for every Lambda(0) (the factor det(Lambda) in the law)' % n)
    chk('std', ok['metric'], 'n=%d: the metric of Lambda e equals the metric of e as exact 2-jets, every Lambda' % n)
    chk('std', ok['stdlaw'], 'n=%d: [std alone] the Christoffel spin connection of Lambda e equals Lambda omega Lambda^{-1} - dLambda Lambda^{-1} of e (first-order jets)' % n)
    chk('bit==std', ok['Wlaw'], 'n=%d: the engine\'s connection of Lambda e (closed form recomputed from Lambda e, read through D_vector) equals Lambda omega_std Lambda^{-1} - dLambda Lambda^{-1}, every entry of the first-order jet, every Lambda' % n)
    chk('bit', ok['Rlaw'], 'n=%d: the engine\'s curvature of Lambda e at the point: R\'^{bc}_{mu nu} = Lambda^b_d Lambda^c_f R^{df}_{mu nu}, every component, every Lambda' % n)
    chk('bit', ok['nonvac'], 'n=%d: E(e) is not zero for the frames used (the laws below are not met by zeros)' % n)
    chk('bit', ok['Elaw'], 'n=%d: E_a(Lambda e) = det(Lambda) (Lambda^{-1})^b_a E_b(e), every component, every Lambda (all four components), c = 0 and 1/3' % n)
    chk('bit', ok['coord'], 'n=%d: the coordinate tensor G - Lambda_n delta read off E is the same for e and Lambda e (also for det -1: the sign of E and of Theta cancel)' % n)
    chk('bit==std', ok['coord_std'], 'n=%d: and it equals the standard Einstein tensor of the common metric minus Lambda_n delta (imports A4)' % n)
    chk('std', ok['numeric'], 'n=%d: numpy five-point finite differences of the metric of the rotor-rotated frame (float route) give the same Einstein tensor (worst relative error %.2g)' % (n, numerr))
    chk('bit', ok['jet3'], 'n=%d: Lambda as a 3-jet and the frame kept to degree 3 give the same E at the point: the 2-jet is enough' % n)
    return ctl

def main():
    ns = [int(a) for a in sys.argv[1:]] or [3, 4, 5]; allctl = {}
    for n in ns:
        for k, v in run_n(n, {3: 3, 4: 3}.get(n, 1), 500 + n).items(): allctl[(n, k)] = v
        tick('n=%d' % n)
    head('controls (a wrong version must differ from the engine on every sample where it can be seen)')
    for (n, k), (dif, seen) in allctl.items():
        chk('ctl', dif == seen and seen > 0, 'n=%d: %s: differs on %d of %d samples' % (n, k, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('A5')
if __name__ == '__main__': main()
