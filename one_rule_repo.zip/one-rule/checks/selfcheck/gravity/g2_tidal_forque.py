#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G2. Tidal forque.   python3 g2_tidal_forque.py

A body of mass points m_i at r_i = R + eps x_i near a point mass M at the origin; Newton's law f_i = -M m_i r_i/|r_i|^3 is an input (INP-075).
[bit]  the Atlas's force lines (pgadyn_selfcheck R(3,0,1): L(p, f) = join(point(p), dual(f.e)), the representation of `gravity`/`hooke`), summed with
       exact eps-series coefficients (through eps^4), moved to the c.o.m. by the translation motor, read off as force and torque.
       The tidal tensor E^i_j from the curvature engine: d4_deviation.tidal_tensor_point_mass (Kerr-Schild frame, observer at rest).
[std]  std1: the direct vector sums sum f_i, sum (r_i - R) x f_i (no PGA).  std2: the exact Taylor coefficients of Phi = -M/|r| at R contracted with the
       body's moments; closed forms of Phi_ij, Phi_ijk; the textbook gravity-gradient torque 3 (M/rho^3) n x (I n).
Exports (import-safe): line(A, p, f), readoff(A), eps_forque(A, R, rho, body, Mc, K), std_sums(R, rho, body, Mc, K), phi_taylor(R, rho, Mc, D),
phi_deriv(T, idx), moments(body, k), multipole(T, body, K), torque_from_E(E, S), gg_torque(Mc, rho, n, S)."""
import sys, os, time, random, itertools
from math import factorial
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); SELFCHECK = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import b1lib
from b1lib import head, chk, finish
from fractions import Fraction as F
sys.path.insert(0, SELFCHECK)
import pgadyn_selfcheck as PG
sys.path.pop(0)

KORD = 4
PG.K = KORD                                                       # eps-series length (pgadyn's Ser reads the module global)
Ser = PG.Ser
EPS3 = {(0, 1, 2): 1, (1, 2, 0): 1, (2, 0, 1): 1, (0, 2, 1): -1, (2, 1, 0): -1, (1, 0, 2): -1}
def cross(u, v): return [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
def scoef(x, k): return x.c[k] if isinstance(x, Ser) else (F(x) if k == 0 else F(0))

# ------------------------------------------------------------------------------------------------ the force line and its read-off
def line(A, p, f, sgn=1):
    """force f at point p as a line of R(3,0,1): sgn * join(point(p), dual(f.e))  (sgn fixed by the dynamics check)"""
    ideal = A.dual(sum((A.e(i + 1).scale(f[i]) for i in range(3)), A.zero()))
    L = A.join(A.point(p), ideal); return L if sgn == 1 else L.scale(sgn)
def readoff(A, sgn=1):
    """calibrated linear read-off: bivector -> (force f, torque about the origin tau), from L(0, e_b) and L(e_a, e_b) - L(0, e_b) (tau = e_a x e_b)"""
    masks = A.biv(); cols = []
    E3 = [[F(int(i == j)) for j in range(3)] for i in range(3)]; z = [F(0)] * 3
    for b in range(3): cols.append(line(A, z, E3[b], sgn))
    for c in range(3):
        a, b = [(1, 2), (2, 0), (0, 1)][c]; cols.append(line(A, E3[a], E3[b], sgn) - line(A, z, E3[b], sgn))
    C = [[col.get(m) for col in cols] for m in masks]; Ci = PG_inverse(C)
    def read(X):
        v = [X.get(m) for m in masks]; out = []
        for i in range(6):
            acc = None
            for j in range(6):
                if Ci[i][j] and v[j] != 0:
                    t = v[j] * Ci[i][j] if isinstance(v[j], Ser) else F(v[j]) * Ci[i][j]
                    acc = t if acc is None else acc + t
            out.append(acc if acc is not None else F(0))
        return out[:3], out[3:]
    return read
def PG_inverse(M):
    n = len(M); A_ = [[F(x) for x in r] + [F(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(i for i in range(c, n) if A_[i][c] != 0); A_[c], A_[p] = A_[p], A_[c]; pv = A_[c][c]; A_[c] = [x / pv for x in A_[c]]
        for i in range(n):
            if i != c and A_[i][c] != 0: fct = A_[i][c]; A_[i] = [x - fct * y for x, y in zip(A_[i], A_[c])]
    return [r[n:] for r in A_]

# ------------------------------------------------------------------------------------------------ exact eps-series of Newton's forces
def binom(a, k):
    r = F(1)
    for j in range(k): r = r * (a - j) / (j + 1)
    return r
def inv_r3(R, rho, x):
    """|R + eps x|^-3 as an exact eps-series (rho = |R| rational)"""
    u = Ser([F(0), 2 * sum(F(R[i]) * x[i] for i in range(3)) / rho ** 2, sum(F(c) * c for c in x) / rho ** 2] + [F(0)] * (KORD - 2))
    out = Ser.const(0); term = Ser.const(1)
    for k in range(KORD + 1): out = out + term * binom(F(-3, 2), k); term = term * u
    return out * (F(1) / rho ** 3)
def newton_forces(R, rho, body, Mc):
    """[(position series, force series)] for every point: r = R + eps x, f = -Mc m r |r|^-3"""
    out = []
    for m, x in body:
        r = [Ser([F(R[i]), F(x[i])] + [F(0)] * (KORD - 1)) for i in range(3)]; g = inv_r3(R, rho, x) * (-F(Mc) * F(m))
        out.append((r, [ri * g for ri in r]))
    return out
def eps_forque(A, R, rho, body, Mc, sgn, read):
    """[bit] sum of the force lines, moved to R by T = trans(-R), read off: (F, tau about R) as eps-series"""
    tot = A.zero()
    for r, f in newton_forces(R, rho, body, Mc): tot = tot + line(A, r, f, sgn)
    T = A.trans([-F(c) for c in R]); return read(A.sand(T, tot))
def std_sums(R, rho, body, Mc):
    """[std1] plain vector sums: F = sum f_i, tau = sum (r_i - R) x f_i"""
    Ft = [Ser.const(0) for _ in range(3)]; tt = [Ser.const(0) for _ in range(3)]
    for (m, x), (r, f) in zip(body, newton_forces(R, rho, body, Mc)):
        d = [Ser([F(0), F(x[i])] + [F(0)] * (KORD - 1)) for i in range(3)]
        Ft = [Ft[i] + f[i] for i in range(3)]; cr = [d[1] * f[2] - d[2] * f[1], d[2] * f[0] - d[0] * f[2], d[0] * f[1] - d[1] * f[0]]
        tt = [tt[i] + cr[i] for i in range(3)]
    return Ft, tt

# ------------------------------------------------------------------------------------------------ [std2] multipole: exact Taylor coefficients of Phi at R
def pmul(P, Q, D):
    r = {}
    for a, x in P.items():
        for b, y in Q.items():
            e = tuple(i + j for i, j in zip(a, b))
            if sum(e) <= D: r[e] = r.get(e, 0) + x * y
    return {k: v for k, v in r.items() if v}
def phi_taylor(R, rho, Mc, D):
    """Phi(R + h) = -Mc/|R + h| = -(Mc/rho) (1 + w)^(-1/2), w = (2 R.h + h^2)/rho^2, as an exact polynomial in h through degree D"""
    w = {}
    for i in range(3):
        e = [0, 0, 0]; e[i] = 1; w[tuple(e)] = 2 * F(R[i]) / rho ** 2
        e2 = [0, 0, 0]; e2[i] = 2; w[tuple(e2)] = w.get(tuple(e2), 0) + F(1) / rho ** 2
    out = {}; term = {(0, 0, 0): F(1)}
    for k in range(D + 1):
        c = binom(F(-1, 2), k)
        for e, v in term.items(): out[e] = out.get(e, 0) + c * v
        term = pmul(term, w, D)
    return {e: -F(Mc) / rho * v for e, v in out.items() if v}
def phi_deriv(T, idx):
    """Phi_{,i1 i2 ..} at R from the Taylor polynomial"""
    e = [0, 0, 0]
    for i in idx: e[i] += 1
    return T.get(tuple(e), F(0)) * factorial(e[0]) * factorial(e[1]) * factorial(e[2])
def moments(body, k):
    return {idx: sum(F(m) * eval_prod(x, idx) for m, x in body) for idx in itertools.product(range(3), repeat=k)}
def eval_prod(x, idx):
    r = F(1)
    for i in idx: r *= F(x[i])
    return r
def multipole(T, body, K):
    """[std2] F^(k)_a = -(1/k!) Phi_{,a b..} M^(k)_{b..};  tau^(k)_a = -eps_abc (1/(k-1)!) Phi_{,c b2..bk} M^(k)_{b b2..bk}"""
    Fk, tk = [], []
    for k in range(K + 1):
        Mk = moments(body, k)
        Fk.append([-sum(phi_deriv(T, (a,) + idx) * v for idx, v in Mk.items()) / factorial(k) for a in range(3)])
        if k == 0: tk.append([F(0)] * 3); continue
        ta = [F(0)] * 3
        for (a, b, c), s in EPS3.items():
            ta[a] -= s * sum(phi_deriv(T, (c,) + idx[1:]) * v for idx, v in Mk.items() if idx[0] == b) / factorial(k - 1)
        tk.append(ta)
    return Fk, tk
def torque_from_E(E, S):
    """tau_a = -eps_abc E_cl S_bl  (the order-eps^2 torque from a tidal tensor E and second moments S)"""
    t = [F(0)] * 3
    for (a, b, c), s in EPS3.items(): t[a] -= s * sum(E[c][l] * S[b][l] for l in range(3))
    return t
def gg_torque(Mc, rho, n, S):
    """textbook gravity-gradient torque 3 (M/rho^3) n x (I n), I = tr(S) 1 - S"""
    tr = S[0][0] + S[1][1] + S[2][2]; I = [[(tr if i == j else 0) - S[i][j] for j in range(3)] for i in range(3)]
    In = [sum(I[i][j] * n[j] for j in range(3)) for i in range(3)]; return [3 * F(Mc) / rho ** 3 * c for c in cross(n, In)]

def main():
    import d4_deviation as D4
    T0 = time.time(); A = PG.Alg(3); Mc = F(2); rng = random.Random(201909)
    def tl(s): print('  [time] %s: %.1f s' % (s, time.time() - T0), flush=True)
    # ======================================================================================== 0. conventions of the force line
    head('0. The force line of the Atlas (pgadyn R(3,0,1)): orientation, read-off, translation')
    f0 = [F(2), F(-1), F(3)]; L0 = line(A, [F(0)] * 3, f0); c1 = PG.unit_c(A)
    S = PG.picard(A, [A.one(), A.zero()], PG.field_of(A, c1, force=lambda M_, B_: PG.lift(L0)), order=3)
    P = S[0] * PG.lift(A.point([0, 0, 0])) * S[0].rev(); pos = A.pos(P)
    acc = [2 * pos[i].c[2] for i in range(3)]
    sgn = 1 if acc == f0 else (-1 if acc == [-x for x in f0] else 0)
    chk('bit', sgn != 0, 'a unit-mass body at rest under the line join(point(0), dual(f.e)) accelerates along %s f (pgadyn flow, exact): the forque of f at p is %s join(point(p), dual(f.e))' % ('+' if sgn == 1 else '-', '+' if sgn == 1 else '-'))
    gs = [s for s in (1, -1) if all(PG.gravity(A, A.one(), F(3), j) == line(A, [F(0)] * 3, [F(3) * s * (i == j - 1) for i in range(3)], sgn) for j in (1, 2, 3))]
    chk('bit', len(gs) == 1, 'pgadyn.gravity(A, 1, g, j) = the forque of the force %s g e_j through the body origin (the page\'s weight line)' % ('+' if gs and gs[0] == 1 else '-'))
    read = readoff(A, sgn); ok = okT = True; R = [F(3), F(4), F(0)]
    for _ in range(6):
        p = [F(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(3)]; f = [F(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(3)]
        ok &= read(line(A, p, f, sgn)) == (f, cross(p, f))
        okT &= A.sand(A.trans([-c for c in R]), line(A, p, f, sgn)) == line(A, [p[i] - R[i] for i in range(3)], f, sgn)
    chk('bit', ok, 'read-off: the line of f at p reads (force f, torque about the origin p x f), 6 random (p, f)')
    chk('bit', okT, 'the translation motor trans(-R) maps the line of f at p to the line of f at p - R (torque about R)')
    tl('part 0')

    # ======================================================================================== 1. the tidal tensor: engine (D4) and Phi
    head('1. Tidal tensor: curvature engine (D4, Kerr-Schild frame at rest) and Phi_,ij')
    POINTS = [([F(3), F(4), F(0)], F(5)), ([F(2), F(3), F(6)], F(7))]; ETAB = {}
    for R, rho in POINTS:
        T = phi_taylor(R, rho, Mc, KORD + 1); n = [c / rho for c in R]
        Eeng = D4.tidal_tensor_point_mass(tuple(R), rho, Mc); ETAB[tuple(R)] = (T, Eeng)
        Phi2 = [[phi_deriv(T, (i, j)) for j in range(3)] for i in range(3)]
        chk('std', Phi2 == [[Mc / rho ** 3 * ((i == j) - 3 * n[i] * n[j]) for j in range(3)] for i in range(3)], 'R = %s: Taylor Phi_,ij = (M/rho^3)(delta - 3 n n) (closed form)' % [int(c) for c in R])
        chk('std', all(phi_deriv(T, (a, b, c)) == Mc * (-3 * ((a == b) * R[c] + (a == c) * R[b] + (b == c) * R[a]) / rho ** 5 + 15 * R[a] * R[b] * R[c] / rho ** 7)
                       for a in range(3) for b in range(3) for c in range(3)), 'R = %s: Taylor Phi_,ijk = closed form M(-3(d_ij x_k + ..)/rho^5 + 15 x_i x_j x_k/rho^7)' % [int(c) for c in R])
        chk('bit==std', [[F(x) for x in r] for r in Eeng] == Phi2, 'R = %s: engine tidal tensor E^i_j (frame at rest) = Phi_,ij exactly: %s' % ([int(c) for c in R], [[str(x) for x in r] for r in Eeng]))
        chk('bit', sum(Eeng[i][i] for i in range(3)) == 0, 'R = %s: tr E = 0 (vacuum)' % [int(c) for c in R])
    tl('part 1')

    # ======================================================================================== 2. bodies: engine sum vs std1 vs std2, orders 0..4
    head('2. Bodies: force lines summed (engine) = vector sums (std1) = multipole (std2), orders eps^0..eps^%d' % KORD)
    def centroidal(pts):
        m = sum(F(a) for a, _ in pts); c = [sum(F(a) * F(x[i]) for a, x in pts) / m for i in range(3)]
        return [(F(a), [F(x[i]) - c[i] for i in range(3)]) for a, x in pts]
    def rand_pts(k): return [(F(rng.randint(1, 3)), [F(rng.randint(-3, 3), rng.randint(1, 2)) for _ in range(3)]) for _ in range(k)]
    def run_body(tag, R, rho, body, expect=None):
        T, Eeng = ETAB[tuple(R)]; n = [c / rho for c in R]
        Fe, te = eps_forque(A, R, rho, body, Mc, sgn, read); Fs, ts = std_sums(R, rho, body, Mc); Fm, tm = multipole(T, body, KORD)
        ok1 = all(scoef(Fe[i], k) == scoef(Fs[i], k) and scoef(te[i], k) == scoef(ts[i], k) for i in range(3) for k in range(KORD + 1))
        ok2 = all(scoef(Fe[i], k) == Fm[k][i] and scoef(te[i], k) == tm[k][i] for i in range(3) for k in range(KORD + 1))
        chk('bit==std', ok1, '%s: engine force and torque = direct vector sums (std1), every coefficient eps^0..eps^%d' % (tag, KORD))
        chk('bit==std', ok2, '%s: engine = multipole formula with exact Phi derivatives (std2), eps^0..eps^%d' % (tag, KORD))
        S2 = moments(body, 2); Sm = [[S2[(i, j)] for j in range(3)] for i in range(3)]; t2 = [scoef(te[i], 2) for i in range(3)]
        return dict(Fe=Fe, te=te, S=Sm, t2=t2, T=T, E=Eeng, n=n, m=sum(F(a) for a, _ in body))
    for R, rho in POINTS:
        for ib in range(3):
            body = centroidal(rand_pts(rng.randint(4, 5))); tag = 'R = %s, random centroidal body %d' % ([int(c) for c in R], ib + 1)
            d = run_body(tag, R, rho, body); T, E, n, Sm, t2, m = d['T'], d['E'], d['n'], d['S'], d['t2'], d['m']
            g = [-phi_deriv(T, (a,)) for a in range(3)]
            chk('bit', [scoef(d['Fe'][i], 0) for i in range(3)] == [m * x for x in g] and all(scoef(d['te'][i], 0) == 0 for i in range(3)),
                '%s: order 0 = the weight m g(R) through the c.o.m. (torque 0), g = -grad Phi = -M R/rho^3' % tag)
            chk('bit', all(scoef(d['Fe'][i], 1) == 0 and scoef(d['te'][i], 1) == 0 for i in range(3)), '%s: order 1 vanishes (sum m x = 0)' % tag)
            chk('bit', t2 == torque_from_E([[F(x) for x in r] for r in E], Sm), '%s: order-2 torque = -eps_abc E_cl S_bl with the CURVATURE ENGINE\'s E (steps 9-12 -> 14-16)' % tag)
            chk('bit', [scoef(d['Fe'][l], 2) for l in range(3)] == [-sum(phi_deriv(T, (l, j, k)) * Sm[j][k] for j in range(3) for k in range(3)) / 2 for l in range(3)],
                '%s: order-2 force = -(1/2) Phi_,ljk S_jk (minus sign)' % tag)
            chk('bit==std', t2 == gg_torque(Mc, rho, n, Sm), '%s: order-2 torque = textbook 3 (M/rho^3) n x (I n), I = tr(S) 1 - S (the trace part drops out)' % tag)
            wrong3 = torque_from_E([[Mc / rho ** 3 * ((i == j) - n[i] * n[j]) for j in range(3)] for i in range(3)], Sm)
            chk('ctl', t2 != wrong3, '%s: factor 3 -> 1 in (delta - 3 n n) does not reproduce the torque' % tag)
            flip = torque_from_E([[-F(x) for x in r] for r in E], Sm)
            chk('ctl', t2 != flip and flip == [-x for x in t2], '%s: the tidal tensor with the repulsive sign gives minus the torque' % tag)
        # principal axes along / across n: torque free
        if rho == 5: U = [[F(3, 5), F(4, 5), F(0)], [F(-4, 5), F(3, 5), F(0)], [F(0), F(0), F(1)]]
        else: U = [[F(2, 7), F(3, 7), F(6, 7)], [F(3, 7), F(-6, 7), F(2, 7)], [F(6, 7), F(2, 7), F(-3, 7)]]
        for perm, lab in (((0, 1, 2), 'long axis along n'), ((1, 0, 2), 'long axis across n')):
            ab = [F(3), F(2), F(1)]; ms = [F(1), F(2), F(3)]; body = []
            for k in range(3):
                u = U[perm[k]]; body += [(ms[k], [ab[k] * c for c in u]), (ms[k], [-ab[k] * c for c in u])]
            d = run_body('R = %s, principal-axis body (%s)' % ([int(c) for c in R], lab), R, rho, body)
            chk('bit', d['t2'] == [0, 0, 0], 'R = %s, principal axes of the body along/across n (%s): order-2 torque exactly 0 (equilibrium)' % ([int(c) for c in R], lab))
        Ub = [[F(1), F(2), F(2)], [F(2), F(1), F(-2)], [F(2), F(-2), F(1)]]
        body = []
        for k in range(3): body += [(ms[k], [ab[k] * c / 3 for c in Ub[k]]), (ms[k], [-ab[k] * c / 3 for c in Ub[k]])]
        d = run_body('R = %s, tilted principal-axis body' % [int(c) for c in R], R, rho, body)
        chk('ctl', d['t2'] != [0, 0, 0], 'R = %s, the same body with axes tilted (not along/across n): order-2 torque != 0' % [int(c) for c in R])
    tl('part 2')

    # ======================================================================================== 3. spherical bodies, offset c.o.m.
    head('3. Controls: spherical bodies, an offset centre of mass')
    R, rho = POINTS[0]; T, E = ETAB[tuple(R)]
    octa = [(F(2), [F(s) * (i == j) for i in range(3)]) for j in range(3) for s in (1, -1)]
    cube = [(F(1), [F(sx), F(sy), F(sz)]) for sx in (1, -1) for sy in (1, -1) for sz in (1, -1)]
    for nm, body in (('octahedron', octa), ('cube', cube)):
        d = run_body('R = (3,4,0), %s' % nm, R, rho, body)
        S = d['S']; iso = all(S[i][j] == (S[0][0] if i == j else 0) for i in range(3) for j in range(3))
        t3 = [scoef(d['te'][i], 3) for i in range(3)]; t4 = [scoef(d['te'][i], 4) for i in range(3)]
        chk('bit', iso and d['t2'] == [0, 0, 0] and t3 == [0, 0, 0], '%s: S = (s/3) delta, engine torque exactly 0 at eps^2 and eps^3' % nm)
        print('    %s: torque at eps^4 = %s' % (nm, [str(x) for x in t4]))
        if nm == 'octahedron': chk('bit', t4 != [0, 0, 0], 'octahedron at R = (3,4,0): torque at eps^4 != 0 (hexadecapole): spherical only to quadrupole order')
    body = [(F(a), x) for a, x in rand_pts(4)]; D = [sum(a * x[i] for a, x in body) for i in range(3)]
    if D == [0, 0, 0]: body[0] = (body[0][0], [body[0][1][0] + 1, body[0][1][1], body[0][1][2]]); D = [sum(a * x[i] for a, x in body) for i in range(3)]
    Fe, te = eps_forque(A, R, rho, body, Mc, sgn, read); g = [-phi_deriv(T, (a,)) for a in range(3)]
    t1 = [scoef(te[i], 1) for i in range(3)]; F1 = [scoef(Fe[i], 1) for i in range(3)]
    chk('ctl', t1 != [0, 0, 0], 'offset c.o.m. (sum m x = %s): the order-1 torque about R does not vanish' % [str(x) for x in D])
    chk('bit', t1 == cross(D, g) and F1 == [-sum(F(E[i][j]) * D[j] for j in range(3)) for i in range(3)],
        'offset c.o.m.: order-1 torque = D x g(R) (the weight at the shifted c.o.m.), order-1 force = -E D')
    tl('part 3')
    finish('G2')

if __name__ == '__main__': main()
