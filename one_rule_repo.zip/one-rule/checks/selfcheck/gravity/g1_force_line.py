#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G1-force. Force lines in the elliptic, Euclidean and hyperbolic algebras: the join weight, three force laws, the std torque, the hung body.
    python3 g1_force_line.py [--fault FK|FS|FP]

The algebra is G1's Cl_kappa^3 (forque_selfcheck.Alg(3, 1, kappa), e0^2 = kappa; kappa = +1 elliptic, 0 Euclid, -1 hyperbolic), points are
trivectors X = w O + x I, normalised when w^2 + kappa |x|^2 = 1 (S^3: a unit vector of R^4; H^3: one sheet of w^2 - |x|^2 = 1), and the
std 4-vector of a point is v = (w / kappa, x) in R^eta, eta = diag(kappa, 1, 1, 1) (G1's dictionary).  A force law is an input: nothing here
says which law a curved space has.
[bit]  (1) the weight of the join of two normalised points: (L L~)_0 = sin^2 d, |p - c|^2, sinh^2 d (cos d = p.c in R^4, cosh d = w w' - x.x').
       (2) three laws as lines through the point P toward the centre C: the join law w L (magnitude w sin_k d), the join over the cube of its
           norm mu L / |L|^3 (mu / sin_k^2 d), the constant weight g L / |L|; along a geodesic the engine's |L(t)| is sin_k(t0 + t) as an exact
           series, so the magnitudes are dV/dt for V = -(w / kappa) cos_k d (-w cos d, +w cosh d), -mu cot_k d, g d (Euclid: w d^2 / 2, -mu / d, g d).
       (3) the forque of a body (the sum of the weighted lines) read through the dictionary star(F) <-> eta T eta equals the std torque of the
           top with a fixed point, T = sum (v F^T - F v^T), with the law's force vector F; one sign c for all laws and bodies; the body-frame
           forque from the pulled-back centre is the pullback of the world forque (unit motors with rational rotor and transvection angles).
       (4) the hung body: a weight line of constant weight m g through the centre toward a down point, a zero-length spring (the join law)
           from a vertex to an anchor on the same geodesic; the rest state is exact iff k sin d_s = m g, k d_s = m g, k sinh d_s = m g;
           the vertex is read from the sign bits of the body-frame weight line (E11's rule), the complement vertex balances too.
[std]  the geodesic formulas (cos_k, sin_k of sums), the R^4 / R^{3,1} torque, the rank of 4-vectors; Euclid: force and moment (f, q x f).
[ctl]  the wrong power mu L / |L|^2; the Euclidean anchor rule at kappa = +-1; the anchor moved sideways or in height; a bit flipped; the
       dictionary sign flipped; the S^3 bound m g <= k; a non-unit motor; E11 itself at kappa = 0 with pgadyn_selfcheck's own functions.
--fault FK: e0^2 flipped in the engine;  FS: every law line reversed (toward the point);  FP: the Kepler law with the wrong power."""
import sys, os, time, random, math
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import b1lib
from b1lib import head, chk, finish
from fractions import Fraction as F
from g1_clkappa import *

ARGS = sys.argv[1:]
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
NAME = {1: 'elliptic', 0: 'Euclid', -1: 'hyperbolic'}
KAPPAS = (1, 0, -1)
LAWS = ('join', 'kepler', 'const')
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)
def eng_alg(k): return alg(-k if FAULT == 'FK' else k)

# ---------------------------------------------------------------------------------------------------------- exact helpers
def fsqrt(x):
    """the exact square root of a non-negative rational square, else None"""
    x = F(x)
    if x < 0: return None
    n, d = x.numerator, x.denominator; rn, rd = math.isqrt(n), math.isqrt(d)
    return F(rn, rd) if rn * rn == n and rd * rd == d else None
def tri(A, w, x): return A.O.scale(F(w)) + A.vec([F(c) for c in x]) * A.I
def tcoords(A, X): return trivector_coords(A, X)
def nsq(kappa, w, x): return F(w) ** 2 + kappa * sum(F(c) ** 2 for c in x)
def stdvec(kappa, w, x): return [F(w) / kappa] + [F(c) for c in x]
def edot(kappa, u, v): return kappa * u[0] * v[0] + sum(u[i] * v[i] for i in (1, 2, 3))
def cosk(kappa, u, v): return kappa * edot(kappa, u, v)                      # cos d (S^3), cosh d (H^3) of two normalised std vectors
def sin2k(kappa, u, v): return kappa * (1 - cosk(kappa, u, v) ** 2)         # sin^2 d, sinh^2 d
def csk_sum(kappa, a, b):
    """(cos_k, sin_k) of a sum from the pairs a, b: cos_k(a+b) = c_a c_b - kappa s_a s_b, sin_k(a+b) = s_a c_b + c_a s_b"""
    return (a[0] * b[0] - kappa * a[1] * b[1], a[1] * b[0] + a[0] * b[1])
def rand_cs(kappa, rng):
    """a rational (cos_k, sin_k) pair of a random angle: ((1-t^2, 2t)/(1+t^2)), (1, t), ((1+t^2, 2t)/(1-t^2)), 0 < t < 1"""
    t = F(rng.randint(1, 4), rng.randint(5, 9))
    if kappa == 1: return ((1 - t * t) / (1 + t * t), 2 * t / (1 + t * t))
    if kappa == -1: return ((1 + t * t) / (1 - t * t), 2 * t / (1 - t * t))
    return (F(1), t)
def rand_unit3(rng, lim=7):
    while True:
        a = [rng.randint(-lim, lim) for _ in range(3)]; q = sum(c * c for c in a); e = math.isqrt(q)
        if q and e * e == q: return [F(c, e) for c in a]
def rand_npoint(kappa, rng, lim=6):
    """a random normalised point (w, x) with rational entries, w > 0 (Euclid: w = 1, random x)"""
    if kappa == 0: return (F(1), [F(rng.randint(-6, 6), rng.randint(1, 3)) for _ in range(3)])
    while True:
        a = [rng.randint(-lim, lim) for _ in range(4)]
        if a[0] <= 0: continue
        q = a[0] ** 2 + kappa * (a[1] ** 2 + a[2] ** 2 + a[3] ** 2)
        if q <= 0: continue
        e = math.isqrt(q)
        if e * e == q: return (F(a[0], e), [F(a[1], e), F(a[2], e), F(a[3], e)])
def geo(A, kappa, u, cs):
    """the normalised point at signed distance t from O along the unit chart direction u: cos_k t O + sin_k t (u I)"""
    return tri(A, cs[0], [cs[1] * c for c in u])
def geo_std(kappa, u, cs): return stdvec(kappa, cs[0], [cs[1] * c for c in u])
def rotor_plane(A, a, b, c, s): return A.one().scale(c) - A.E('%d%d' % (a, b)).scale(s)    # exp(-phi e_ab): (c, s) = (cos, sin) or (cosh, sinh)
def rand_motor_k(A, kappa, rng):
    """a unit motor of the kappa algebra: two spatial rotors and one transvection in a plane e_0k, all with rational angles"""
    i, j = sorted(rng.sample([1, 2, 3], 2)); M = rotor_plane(A, i, j, *rand_cs(1, rng))
    M = M * rotor_plane(A, 0, rng.randint(1, 3), *rand_cs(kappa, rng))
    i, j = sorted(rng.sample([1, 2, 3], 2)); return M * rotor_plane(A, i, j, *rand_cs(1, rng))
def motor_matrix(A, M):
    """Lam[i][j] = coefficient of e_i in M e_j M~ (the std matrix of the motor)"""
    return [[(M * A.g(j) * M.rev()).d.get(1 << i, F(0)) for j in range(4)] for i in range(4)]
def pull(A, M, X): return M.rev() * X * M                   # world -> body frame
def push(A, M, X): return M * X * M.rev()                   # body -> world frame
def rank3x4(rows):
    R = [r[:] for r in rows]; rk = 0
    for c in range(4):
        p = next((i for i in range(rk, len(R)) if R[i][c] != 0), None)
        if p is None: continue
        R[rk], R[p] = R[p], R[rk]
        for i in range(len(R)):
            if i != rk and R[i][c] != 0: f = R[i][c] / R[rk][c]; R[i] = [x - f * y for x, y in zip(R[i], R[rk])]
        rk += 1
    return rk

# ---------------------------------------------------------------------------------------------------------- the lines and the laws
def jw2(A, L):
    """(the join weight squared, the line is simple): (L L~)_0 and whether L L~ has no grade-4 part"""
    LL = L * L.rev(); return LL.scalar(), LL.grade(4).is_zero()
def law_line(A, kind, P, C, w):
    """the force line of the law through the point P toward the centre C with weight w (the join is oriented from P to C)"""
    L = A.join(C, P) if FAULT == 'FS' else A.join(P, C); w = F(w)
    if kind == 'join': return L.scale(w)
    n = fsqrt(jw2(A, L)[0])
    if n is None or n == 0: raise ValueError('the join weight is not a rational square: choose other points')
    if kind == 'kepler': return L.scale(w / n ** (2 if FAULT == 'FP' else 3))
    if kind == 'const': return L.scale(w / n)
    if kind == 'wrong': return L.scale(w / n ** 2)
    raise ValueError(kind)
def law_factor(kind, s):
    """the std magnitude factor of the law at sin_k d = s (times the weight w): w s, w / s^2, w, w / s"""
    if kind == 'join': return F(1)
    return {'kepler': 1 / s ** 3, 'const': 1 / s, 'wrong': 1 / s ** 2}[kind]
def body_forque(A, kind, pts, C, ws):
    tot = A.zero()
    for P, w in zip(pts, ws): tot = tot + law_line(A, kind, P, C, w)
    return tot
def std_torque(kappa, vs, cv, kind, ws):
    """[std] T = sum w_i f_i (v_i c^T - c v_i^T), f_i the law factor at sin_k d_i: the torque of the force w f c at v_i on the top with a fixed point"""
    T = [[F(0)] * 4 for _ in range(4)]
    for v, w in zip(vs, ws):
        s = fsqrt(sin2k(kappa, v, cv))
        if s is None or (s == 0 and kind != 'join'): raise ValueError('sin_k^2 d is not a positive rational square: the points are off the quadric')
        f = F(w) * law_factor(kind, s)
        for a in range(4):
            for b in range(4): T[a][b] += f * (v[a] * cv[b] - cv[a] * v[b])
    return T
def K_of(A, L):
    K = [[F(0)] * 4 for _ in range(4)]
    for a in range(4):
        for b in range(a + 1, 4): K[a][b] = L.d.get((1 << a) | (1 << b), F(0)); K[b][a] = -K[a][b]
    return K
def eta_conj(kappa, T): eta = [F(kappa), F(1), F(1), F(1)]; return [[eta[a] * T[a][b] * eta[b] for b in range(4)] for a in range(4)]
def ratio_set(X, Y):
    """the set of ratios X_ab / Y_ab over the entries where either is non-zero ('inf' when Y = 0)"""
    r = set()
    for a in range(4):
        for b in range(4):
            if X[a][b] or Y[a][b]: r.add(X[a][b] / Y[a][b] if Y[a][b] else 'inf')
    return r
def cross(u, v): return [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
def std_wrench(pts, c, kind, ws):
    """[std] Euclid: total force f = sum w_i f_i (c - q_i) and moment tau = sum q_i x f_i about the origin"""
    ft = [F(0)] * 3; tau = [F(0)] * 3
    for q, w in zip(pts, ws):
        d = [c[i] - q[i] for i in range(3)]; s = fsqrt(sum(x * x for x in d)); f = [F(w) * law_factor(kind, s) * x for x in d]
        ft = [a + b for a, b in zip(ft, f)]; tau = [a + b for a, b in zip(tau, cross(q, f))]
    return ft, tau
EUC_MASKS = [(0b1100, 1), (0b1010, -1), (0b0110, 1)]         # e23, e31 = -e13, e12: the line through the origin in the direction e_k
IDL_MASKS = [(0b0011, 1), (0b0101, 1), (0b1001, 1)]          # e01, e02, e03

# ---------------------------------------------------------------------------------------------------------- scalar series (lists of Fractions)
def s_der(a): return [k * a[k] for k in range(1, len(a))] + [F(0)]
def s_inv(a):
    N = len(a) - 1; r = [F(0)] * (N + 1); r[0] = 1 / a[0]
    for k in range(1, N + 1): r[k] = -sum(a[j] * r[k - j] for j in range(1, k + 1)) / a[0]
    return r
def s_sqrt(a):
    """the series square root with a rational square as leading term"""
    N = len(a) - 1; r0 = fsqrt(a[0])
    if r0 is None or r0 == 0: raise ValueError('leading term not a positive rational square')
    r = [F(0)] * (N + 1); r[0] = r0
    for k in range(1, N + 1): r[k] = (a[k] - sum(r[j] * r[k - j] for j in range(1, k))) / (2 * r0)
    return r
def cs_series(kappa, cs0, N):
    """(cos_k(t0 + t), sin_k(t0 + t)) as series in t, from the rational pair (cos_k t0, sin_k t0)"""
    c = [F(0)] * (N + 1); s = [F(0)] * (N + 1)
    for n in range(N + 1):
        if n % 2 == 0: c[n] = F((-kappa) ** (n // 2), math.factorial(n))
        else: s[n] = F((-kappa) ** (n // 2), math.factorial(n))
    c0, s0 = cs0
    return s_sub(s_scale(c, c0), s_scale(s, kappa * s0)), s_add(s_scale(c, s0), s_scale(s, c0))
def ser_scal(S, a):
    """a multivector series times a scalar series"""
    N = len(S.c); z = S.c[0].scale(0); out = [z for _ in range(N)]
    for i in range(N):
        if not S.c[i].d: continue
        for j in range(N - i):
            if a[j]: out[i + j] = out[i + j] + S.c[i].scale(a[j])
    return Ser(out)
def ser_jw2(A, L):
    """(L L~)_0 of a bivector series, as a scalar series (and the grade-4 part as a series)"""
    LL = L * L.rev(); return [c.scalar() for c in LL.c], LL.map(lambda X: X.grade(4))

# ---------------------------------------------------------------------------------------------------------- the hung body
def hang_config(A, kappa, M, u, cs_rho, cs_g, cs_s, mg, k, flip_bits=0, complement=False):
    """World: centre C_w = M O M~, down point c_g,w = M X(-d_g) M~, anchor a_w = M X(rho + d_s) M~ on the geodesic of O with chart direction u.
    Body frame: the bits are read from the pulled-back weight line, the chart edge lengths are s_i = 2 tan_k(rho) |u_i|, the vertex is
    point((b_i - 1/2) s_i) normalised.  Returns a dict with the world and body data and the two forques."""
    O = A.O; Cw = push(A, M, O); cgw = push(A, M, geo(A, kappa, u, (cs_g[0], -cs_g[1])))
    aw = push(A, M, geo(A, kappa, u, csk_sum(kappa, cs_rho, cs_s)))
    cgb = pull(A, M, cgw); wg, xg = tcoords(A, cgb)[0], tcoords(A, cgb)[1:]          # the pulled-back down point
    qg = [c / wg for c in xg]; ng = fsqrt(sum(c * c for c in qg))                      # chart coordinates; |q| = tan_k d_g must be rational
    if ng is None or ng == 0: raise ValueError('the pulled-back down point has no rational chart distance: the motor is not a unit')
    ub = [-c / ng for c in qg]                                                           # the unit chart direction "up" in the body frame
    Fg_b = law_line(A, 'const', O, cgb, mg)                                             # the body-frame weight line
    comps = [sg * Fg_b.d.get(m, F(0)) for m, sg in EUC_MASKS]                           # its three Euclidean components (e23, e31, e12)
    bits = [1 if x < 0 else 0 for x in comps]                                           # the weight line points down: bit set when up is positive
    if complement: bits = [1 - b for b in bits]
    bits = [b ^ ((flip_bits >> i) & 1) for i, b in enumerate(bits)]
    tan_rho = cs_rho[1] / cs_rho[0]; sz = [2 * tan_rho * abs(c) for c in ub]
    qv = [(F(b) - F(1, 2)) * s for b, s in zip(bits, sz)]
    nv = fsqrt(nsq(kappa, 1, qv))
    if nv is None or nv == 0: raise ValueError('the vertex has no rational normalisation')
    Pb = A.point(qv).scale(1 / nv); Pw = push(A, M, Pb)
    ab = pull(A, M, aw); Fs_b = law_line(A, 'join', Pb, ab, k)
    return dict(Cw=Cw, cgw=cgw, aw=aw, cgb=cgb, ub=ub, comps=comps, bits=bits, sz=sz, qv=qv, Pb=Pb, Pw=Pw, ab=ab, Fg_b=Fg_b, Fs_b=Fs_b, nv=nv)

# ============================================================================================================ main
def main():
    rng = random.Random(20261009)
    head('G1-force: force lines in Cl_kappa^3 (kappa = +1, 0, -1): the join weight, three laws, the std torque, the hung body' + (' [fault %s]' % FAULT if FAULT else ''))
    N = 6
    # ------------------------------------------------------------------------------------------ (1) the join weight
    head('(1) the join weight of two normalised points: (L L~)_0 = sin^2 d, |p - c|^2, sinh^2 d; L L~ has no grade-4 part')
    for kappa in KAPPAS:
        A = eng_alg(kappa); ok = simple = norm = True; n = 0
        for _ in range(6):
            wp, xp = rand_npoint(kappa, rng); wc, xc = rand_npoint(kappa, rng)
            P, C = tri(A, wp, xp), tri(A, wc, xc)
            norm &= nsq(kappa, wp, xp) == 1 and nsq(kappa, wc, xc) == 1 and P * P == A.one().scale(-1) and C * C == A.one().scale(-1)
            w2, sm = jw2(A, A.join(P, C))
            if kappa == 0: s2 = sum((a - b) ** 2 for a, b in zip(xp, xc))
            else: s2 = sin2k(kappa, stdvec(kappa, wp, xp), stdvec(kappa, wc, xc))
            ok &= w2 == s2; simple &= sm; n += 1
        chk('bit', norm, '%s: the %d random points are normalised (w^2 + kappa|x|^2 = 1 and X^2 = -1)' % (NAME[kappa], 2 * n))
        chk('bit==std', ok, '%s: (L L~)_0 of the join of %d random pairs = %s computed in R^4 / R^{3,1} without a Clifford product' % (NAME[kappa], n, {1: 'sin^2 d = 1 - (p.c)^2', 0: '|p - c|^2', -1: 'sinh^2 d = (w w\' - x.x\')^2 - 1'}[kappa]))
        chk('bit', simple, '%s: L L~ is a scalar (no grade-4 part): the join of two points is a simple bivector' % NAME[kappa])
    tline('(1)')
    # ------------------------------------------------------------------------------------------ (2) the laws along a geodesic
    head('(2) the three laws along a geodesic: |L(t)| = sin_k(t0 + t) as a series; magnitudes = dV/dt for V = -(w/kappa) cos_k, -mu cot_k, g t')
    for kappa in KAPPAS:
        A = eng_alg(kappa); u = rand_unit3(rng); cs0 = rand_cs(kappa, rng)
        c_ser, s_ser = cs_series(kappa, cs0, N)
        X = Ser([A.O.scale(c_ser[n]) + A.vec([s_ser[n] * c for c in u]) * A.I for n in range(N + 1)])     # X(t0 + t) as a series of trivectors
        L = ser_bilin(A.join, X, Ser.const(A.O, N)) if FAULT != 'FS' else ser_bilin(A.join, Ser.const(A.O, N), X)
        w2, g4 = ser_jw2(A, L)
        chk('bit==std', w2 == s_mul(s_ser, s_ser) and all(not c.d for c in g4.c), '%s: (L L~)_0 of join(X(t), O) along the geodesic = sin_k^2(t0 + t) through t^%d (simple at every order)' % (NAME[kappa], N))
        mag = s_sqrt(w2)                                                                                        # |L(t)| = sin_k(t0 + t)
        w, mu, g = F(3), F(5, 2), F(7, 3)
        V = {'join': s_scale(c_ser, F(-w, kappa)) if kappa else s_scale(s_mul(s_ser, s_ser), w / 2), 'kepler': s_scale(s_mul(c_ser, s_inv(s_ser)), -mu), 'const': [F(0), g] + [F(0)] * (N - 1)}
        mags = {'join': s_scale(mag, w), 'kepler': s_scale(s_mul(s_inv(mag), s_inv(mag)), mu), 'const': s_const(g, N)}     # w |L|, mu / |L|^2, g
        if FAULT == 'FP': mags['kepler'] = s_scale(s_inv(mag), mu)                                                          # the wrong power: mu / |L|
        for kind in LAWS:
            chk('bit==std', s_der(V[kind])[:N] == mags[kind][:N], '%s: the %s law has magnitude %s = dV/dt, V = %s, through t^%d' % (NAME[kappa], kind,
                {'join': 'w sin_k d', 'kepler': 'mu / sin_k^2 d', 'const': 'g'}[kind], {'join': {1: '-w cos d', -1: '+w cosh d', 0: 'w d^2 / 2'}[kappa], 'kepler': '-mu cot_k d' if kappa else '-mu / d', 'const': 'g d'}[kind], N - 1))
        wrong = s_scale(s_inv(mag), mu)
        chk('ctl', s_der(V['kepler'])[:N] != wrong[:N] and s_der(V['join'])[:N] != wrong[:N], '%s: the wrong power mu L / |L|^2 (magnitude mu / sin_k d) is neither dV/dt of -mu cot_k d nor of the join potential' % NAME[kappa])
    tline('(2)')
    # ------------------------------------------------------------------------------------------ (3) the std torque and the frames
    head('(3) the forque of a body = the std torque of the top with a fixed point: K(star(F)) = c eta T eta, one c; Euclid: (f, q x f); frames')
    CSET = set()
    for kappa in KAPPAS:
        A = eng_alg(kappa)
        for trial in range(3):
            # points on geodesics through the centre O with rational (cos_k, sin_k): every sin_k d_i is rational, so all four laws are exact;
            # trial 0 in the body frame (centre O), trials 1, 2 pushed to the world by a unit motor (a generic centre)
            npts = rng.randint(2, 4); us = [rand_unit3(rng) for _ in range(npts)]; css = [rand_cs(kappa, rng) for _ in range(npts)]; ws = [F(rng.randint(1, 3)) for _ in range(npts)]
            M = rand_motor_k(A, kappa, rng) if trial else A.one()
            Ps = [push(A, M, geo(A, kappa, u, cs)) for u, cs in zip(us, css)]; C = push(A, M, A.O)
            cc = [tcoords(A, X) for X in Ps]; cC = tcoords(A, C)
            kinds = LAWS + ('wrong',)
            for kind in kinds:
                Fe = body_forque(A, kind, Ps, C, ws)
                if kappa != 0:
                    vs = [stdvec(kappa, c[0], c[1:]) for c in cc]; cv = stdvec(kappa, cC[0], cC[1:])
                    X = K_of(A, A.star(Fe))
                    try: Y = eta_conj(kappa, std_torque(kappa, vs, cv, kind, ws)); rs = ratio_set(X, Y)
                    except ValueError as e: Y = None; rs = {str(e)}                                           # no std torque: the check below fails
                    CSET |= rs
                    chk('bit==std', rs == {F(1)}, '%s body %d (%d points, %s), %s law: K(star(F_eng)) = c eta T_std eta with c = %s (expected +1, G1\'s momentum dictionary); both sides non-zero' % (NAME[kappa], trial, npts, 'body frame' if trial == 0 else 'world frame', kind, sorted(map(str, rs))))
                    if trial == 0 and kind == 'join':
                        Yneg = [[-y for y in r] for r in Y] if Y is not None else None
                        chk('ctl', Yneg is not None and ratio_set(X, Yneg) != {F(1)}, '%s: the dictionary with the sign c flipped fails' % NAME[kappa])
                else:
                    ft, tau = std_wrench([c[1:] for c in cc], cC[1:], kind, ws)
                    fe = [sg * Fe.d.get(m, F(0)) for m, sg in EUC_MASKS]; te = [sg * Fe.d.get(m, F(0)) for m, sg in IDL_MASKS]
                    chk('bit==std', fe == ft and te == tau and any(ft) and (any(tau) or trial == 0) and all(c[0] == 1 for c in cc), 'Euclid body %d (%d points, %s), %s law: the line reads (f, q x f) = (force, moment): f on (e23, e31, e12), q x f on (e01, e02, e03)' % (trial, npts, 'body frame' if trial == 0 else 'world frame', kind))
            # frames: the body-frame forque from the pulled-back centre is the pullback of the world forque
            M2 = rand_motor_k(A, kappa, rng)
            chk('bit', M2 * M2.rev() == A.one(), '%s body %d: the random motor is a unit (M M~ = 1); matrix det = %s' % (NAME[kappa], trial, charpoly(motor_matrix(A, M2))[-1]))
            okf = True
            for kind in kinds:
                Fw = body_forque(A, kind, [push(A, M2, P) for P in Ps], push(A, M2, C), ws)
                okf &= pull(A, M2, Fw) == body_forque(A, kind, Ps, pull(A, M2, push(A, M2, C)), ws)
            chk('bit', okf, '%s body %d: M~ F_w M = F_b built from M~ C_w M for the laws %s (the join and |L| are covariant under the unit motor)' % (NAME[kappa], trial, list(kinds)))
            if kappa != 0 and trial == 0:
                Mbad = A.trans([F(1, 2), F(0), F(1, 3)]); Cw = Mbad * C * Mbad.rev(); Fw = body_forque(A, 'join', [Mbad * P * Mbad.rev() for P in Ps], Cw, ws)
                chk('ctl', Mbad * Mbad.rev() != A.one() and Mbad.rev() * Fw * Mbad != body_forque(A, 'join', Ps, Mbad.rev() * Cw * Mbad, ws), '%s: the Euclidean translation 1 - eps t/2 is not a unit here and breaks the covariance' % NAME[kappa])
    print('  dictionary: K(star(F)) = c eta T eta with c in', sorted(map(str, CSET)))
    tline('(3)')
    # ------------------------------------------------------------------------------------------ (4) the hung body
    head('(4) the hung body: k sin_k d_s = m g, the vertex from the sign bits of the body-frame weight line, the complement balances')
    m, g = F(3, 2), F(2); mg = m * g                                          # E11's mass and g
    for kappa in KAPPAS:
        A = eng_alg(kappa)
        kk = {1: F(5), 0: F(3), -1: F(4)}[kappa]                                # k: sin d_s = 3/5 (cos 4/5), d_s = 1 (E11), sinh d_s = 3/4 (cosh 5/4)
        cs_s = {1: (F(4, 5), F(3, 5)), 0: (F(1), mg / kk), -1: (F(5, 4), F(3, 4))}[kappa]
        for trial in range(2):
            M = rand_motor_k(A, kappa, rng); cs_rho = rand_cs(kappa, rng); cs_g = rand_cs(kappa, rng)
            while True:
                u = rand_unit3(rng)
                if sum(1 for c in u if c) >= 2: break                                                                    # a generic vertical (not along a body axis)
            tag = '%s trial %d' % (NAME[kappa], trial)
            try: H = hang_config(A, kappa, M, u, cs_rho, cs_g, cs_s, mg, kk)
            except ValueError as e:
                chk('bit', False, '%s: the hung configuration cannot be built (%s)' % (tag, e)); continue
            chk('bit', H['nv'] == 1 / cs_rho[0] and H['qv'] == [cs_rho[1] / cs_rho[0] * c for c in u] and H['ub'] == u,
                '%s: bits %s from the body-frame weight line, chart edges s_i = 2 tan_k(rho) |u_i|: the vertex is the chart point tan_k(rho) u (distance rho straight above the centre)' % (tag, H['bits']))
            Lw = A.join(H['Cw'], H['cgw'])
            vC, vg, vP = [tcoords(A, X) for X in (H['Cw'], H['cgw'], H['Pw'])]
            if kappa != 0: rk = rank3x4([stdvec(kappa, c[0], c[1:]) for c in (vC, vg, vP)])
            else: rk = rank3x4([[F(0)] + [vg[i] - vC[i] for i in (1, 2, 3)], [F(0)] + [vP[i] - vC[i] for i in (1, 2, 3)]])     # the two chords from the centre
            chk('bit', A.join(Lw, H['Pw']).is_zero(), '%s: the world vertex lies on the world weight line (join(line, point) = 0)' % tag)
            chk('std', rk == (2 if kappa != 0 else 1), '%s: the std vectors of the centre, the down point and the vertex span a 2-plane (rank %d; Euclid: the two chords are parallel)' % (tag, rk))
            tot = H['Fg_b'] + H['Fs_b']
            chk('bit', tot.is_zero() and not H['Fg_b'].is_zero(), '%s: weight m g = %s through the centre + spring k = %s at the vertex with the anchor at d_s above it (%s = %s): the total body-frame forque is 0' % (tag, mg, kk, {1: 'sin d_s', 0: 'd_s', -1: 'sinh d_s'}[kappa], cs_s[1]))
            # the std route: the geodesic formulas in R^4 / R^{3,1} (Euclid: chords)
            if kappa != 0:
                vO = stdvec(kappa, 1, [0, 0, 0]); vcg = geo_std(kappa, u, (cs_g[0], -cs_g[1])); vPb = geo_std(kappa, u, cs_rho); vab = geo_std(kappa, u, csk_sum(kappa, cs_rho, cs_s))
                Tg = std_torque(kappa, [vO], vcg, 'const', [mg]); Ts = std_torque(kappa, [vPb], vab, 'join', [kk])
                chk('std', all(Tg[a][b] + Ts[a][b] == 0 for a in range(4) for b in range(4)) and any(Tg[a][b] for a in range(4) for b in range(4)), '%s: the std torques of the two forces cancel in R^{%s}' % (tag, '4' if kappa == 1 else '3,1'))
            # controls
            abE = A.point([q + mg / kk * c for q, c in zip(H['qv'], u)])                                              # the weight-1 chart point m g / k above the vertex
            chk('ctl', (H['Fg_b'] + law_line(A, 'join', H['Pb'], abE, kk)).is_zero() == (kappa == 0), '%s: the Euclidean rule (the anchor m g / k above the vertex in the chart) %s' % (tag, 'balances (kappa = 0)' if kappa == 0 else 'leaves a non-zero forque'))
            Hc = hang_config(A, kappa, M, u, cs_rho, cs_g, cs_s, mg, kk, complement=True)
            abc = pull(A, M, push(A, M, geo(A, kappa, u, csk_sum(kappa, (cs_rho[0], -cs_rho[1]), cs_s))))           # the anchor at d_s above the complement vertex
            chk('bit', Hc['qv'] == [-q for q in H['qv']] and (Hc['Fg_b'] + law_line(A, 'join', Hc['Pb'], abc, kk)).is_zero(), '%s: the complement vertex (straight below the centre) balances too, with the anchor at d_s above it' % tag)
            Hf = hang_config(A, kappa, M, u, cs_rho, cs_g, cs_s, mg, kk, flip_bits=1 << min(i for i in range(3) if u[i]))       # a bit with a non-zero edge
            chk('ctl', not A.join(Lw, Hf['Pw']).is_zero() and not (Hf['Fg_b'] + Hf['Fs_b']).is_zero(), '%s: one bit flipped: the vertex is off the weight line and the forques do not cancel' % tag)
            cs_h = csk_sum(kappa, cs_s, rand_cs(kappa, rng)); ah = pull(A, M, push(A, M, geo(A, kappa, u, csk_sum(kappa, cs_rho, cs_h))))
            perp = [u[1], -u[0], F(0)] if (u[0] or u[1]) else [F(0), u[2], -u[1]]
            qa = tcoords(A, H['ab']); qa = [c / qa[0] for c in qa[1:]]; qside = [q + F(1, 3) * p for q, p in zip(qa, perp)]; nside = fsqrt(nsq(kappa, 1, qside))
            aside = A.point(qside).scale(1 / nside) if nside else A.point(qside)                                       # weight-1 if not normalisable: still a point off the line
            chk('ctl', not (H['Fg_b'] + law_line(A, 'join', H['Pb'], ah, kk)).is_zero() and not (H['Fg_b'] + law_line(A, 'join', H['Pb'], aside, kk)).is_zero(), '%s: the anchor higher or moved sideways breaks the balance' % tag)
            if kappa == 1 and trial == 0:
                a2 = pull(A, M, push(A, M, geo(A, kappa, u, csk_sum(kappa, cs_rho, (-cs_s[0], cs_s[1])))))
                chk('bit', (H['Fg_b'] + law_line(A, 'join', H['Pb'], a2, kk)).is_zero(), '%s: the second anchor at pi - d_s (beyond the quarter circle) balances too' % tag)
                apol = pull(A, M, push(A, M, geo(A, kappa, u, csk_sum(kappa, cs_rho, (F(0), F(1))))))
                chk('bit', (H['Fg_b'] + law_line(A, 'join', H['Pb'], apol, mg)).is_zero(), '%s: at the bound m g = k the anchor is the polar point of the vertex (d_s = pi/2) and balances' % tag)
                bad = True
                for t in (F(1, 7), F(1, 3), F(1, 2), F(2, 3), F(5, 6), F(9, 10)):
                    cs = ((1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)); at = pull(A, M, push(A, M, geo(A, kappa, u, csk_sum(kappa, cs_rho, cs))))
                    bad &= not (H['Fg_b'] + law_line(A, 'join', H['Pb'], at, mg * F(4, 5))).is_zero()
                bad &= not (H['Fg_b'] + law_line(A, 'join', H['Pb'], apol, mg * F(4, 5))).is_zero()
                chk('ctl', bad, '%s: with m g > k (k = 4 m g / 5) no anchor on the geodesic balances (7 angles, the polar point included; |F_s| = k sin d_s <= k < m g)' % tag)
    # E11 itself at kappa = 0, with pgadyn_selfcheck's own functions (its R(3,0,1), rotor, hooke, gravity)
    sys.path.insert(0, os.path.dirname(HERE)); import pgadyn_selfcheck as PG; sys.path.pop(0)
    A3 = PG.Alg(3); j = 2; okE = okH = True; n_used = 0
    for ri in range(4):
        R = PG.rotor(A3, ri); fcol = [A3.q(A3.sand(R, A3.dual(A3.e(i + 1))), j) for i in range(3)]
        if any(f == 0 for f in fcol): continue
        M = A3.trans([F(1, 3), F(-2, 5), F(1, 7)]) * R
        Gl = PG.gravity(A3, M, g, j).scale(m)
        bits = [1 if f > 0 else 0 for f in fcol]; sz = [2 * abs(f) for f in fcol]
        pb = A3.point([(F(b) - F(1, 2)) * s for b, s in zip(bits, sz)]); xv = A3.pos(A3.sand(M, pb)); xc = A3.pos(A3.sand(M, A3.point([0, 0, 0])))
        anchor = [xv[i] + (mg / F(3) if i == j - 1 else 0) for i in range(3)]
        okE &= (PG.hooke(A3, M, F(3), pb, A3.point(anchor)) + Gl).d == {} and [xv[i] - xc[i] for i in range(3)] == [F(int(i == j - 1)) for i in range(3)]
        okH &= (PG.hooke(A3, M, F(3), pb, A3.point([anchor[i] + (F(1, 3) if i == j - 1 else 0) for i in range(3)])) + Gl).d != {}
        n_used += 1
    chk('ctl', okE and okH and n_used >= 3, 'Euclid, E11 with pgadyn_selfcheck\'s own functions (%d rotors, k = 3, m = 3/2, g = 2): the sign-bit vertex (bit i set when f_i2 > 0) is straight above the centre, the anchor at m g / k balances exactly, a higher anchor does not' % n_used)
    tline('(4)')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('G1-force' + ('-' + FAULT if FAULT else ''))
