#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G3 helpers: the planets table of the page, the Atlas force law, integrators, Kepler tools, the Horizons observer-table reader.
Nothing here calls the gravity engine. Floating point (numpy, scipy) for the [std] routes; Fraction / Decimal for the exact routes.
Units: km, s, kg; G in km^3 kg^-1 s^-2 (the page: 6.6723e-11 * 1e-9)."""
import sys, os, re, math, datetime
sys.dont_write_bytecode = True            # never write bytecode next to the Atlas package
import numpy as np
from fractions import Fraction as Fr
from decimal import Decimal, getcontext
from scipy.integrate import solve_ivp

HERE = os.path.dirname(os.path.abspath(__file__))
G2 = HERE                                     # this folder, selfcheck/gravity/ of the package
SELFCHECK = os.path.dirname(HERE)             # the package's selfcheck/ (pgadyn_selfcheck.py)
HZ = os.path.join(HERE, 'data', 'horizons')   # the Horizons observer tables (copies; README.md)
NODE_RUN = os.path.join(HERE, 'g3_pgaEngine_run.mjs')

AU_KM = 149597870.700          # Horizons header
C_KMS = 299792.458             # Horizons header
DAY = 86400.0
TT_MINUS_UTC = 69.184          # s, 2026 (37 s leap seconds + 32.184 s)
OBLIQ_ARCSEC = 84381.448       # IAU 1976 obliquity used by Horizons for the ecliptic of J2000
NAMES = ['Sun', 'Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter']
G_ATLAS = 6.6723e-11 * 1e-9    # the same floating product as PLANET_G in pgaEngine.js

# ------------------------------------------------------------------------------ the page table (read from the Atlas module, no bytecode written)
_PG = None
def atlas_module():
    global _PG
    if _PG is None:
        import importlib.util
        p = os.path.join(SELFCHECK, 'pgadyn_selfcheck.py')
        spec = importlib.util.spec_from_file_location('pgadyn_selfcheck_g3', p)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); _PG = mod
    return _PG

def table_arrays():
    T = atlas_module().PLANETS
    m = np.array([float(T[k][0]) for k in NAMES])
    x = np.array([[float(c) for c in T[k][1]] for k in NAMES])
    v = np.array([[float(c) for c in T[k][2]] for k in NAMES])
    return m, x, v

def table_decimal():
    T = atlas_module().PLANETS
    m = [Decimal(T[k][0]) for k in NAMES]
    x = [[Decimal(c) for c in T[k][1]] for k in NAMES]
    v = [[Decimal(c) for c in T[k][2]] for k in NAMES]
    return m, x, v

# ------------------------------------------------------------------------------ the force law of the page, in float64
def acc(x, mu, power=3.0, twist=0.0, reaction=True):
    """a_i = sum_j mu_j (x_j - x_i)/d_ij^power  (mu_j = G m_j); power = 3 is the inverse square. twist: perpendicular part (the Atlas's N1 control).
    reaction=False: body j feels nothing from i for i < j (a control that must break the momentum)."""
    r = x[None, :, :] - x[:, None, :]
    d2 = (r * r).sum(-1); np.fill_diagonal(d2, 1.0)
    inv = d2 ** (-0.5 * power); np.fill_diagonal(inv, 0.0)
    w = inv * mu[None, :]
    if not reaction: w = np.triu(w)
    a = (w[:, :, None] * r).sum(1)
    if twist:
        perp = np.stack([-r[..., 1], r[..., 0], np.zeros_like(r[..., 0])], -1)
        a = a + twist * (w[:, :, None] * perp).sum(1)
    return a

def invariants(x, v, m, G, power=3.0):
    """P, L (3 components), K, U_p (matching potential, U_3 = -G m m/d), COM position, total mass"""
    P = (m[:, None] * v).sum(0)
    L = (m[:, None] * np.cross(x, v)).sum(0)
    K = 0.5 * (m * (v * v).sum(1)).sum()
    iu = np.triu_indices(len(m), 1)
    d = np.sqrt(((x[:, None, :] - x[None, :, :]) ** 2).sum(-1))[iu]
    mm = (m[:, None] * m[None, :])[iu]
    U = -(G * mm * d ** (2.0 - power) / (power - 2.0)).sum()
    UN = -(G * mm / d).sum()
    R = (m[:, None] * x).sum(0) / m.sum()
    return dict(P=P, L=L, K=K, U=U, UN=UN, E=K + U, EN=K + UN, R=R, M=m.sum())

def rk4_step(x, v, mu, h, power=3.0):
    """classical RK4 exactly as rk4Bodies in pgaEngine.js (k1x = v, k2x = v2, ...)"""
    a1 = acc(x, mu, power)
    x2 = x + (h / 2) * v;  v2 = v + (h / 2) * a1;  a2 = acc(x2, mu, power)
    x3 = x + (h / 2) * v2; v3 = v + (h / 2) * a2;  a3 = acc(x3, mu, power)
    x4 = x + h * v3;       v4 = v + h * a3;        a4 = acc(x4, mu, power)
    xn = x + h / 6 * (v + 2 * v2 + 2 * v3 + v4)
    vn = v + h / 6 * (a1 + 2 * a2 + 2 * a3 + a4)
    return xn, vn

def flow(x0, v0, t_end, mu, power=3.0, rtol=1e-13, atol_x=1e-9, atol_v=1e-15, events=None, dense=False, t_eval=None, t0=0.0):
    n = len(x0)
    def rhs(t, y):
        xx = y[:3 * n].reshape(n, 3)
        return np.concatenate([y[3 * n:], acc(xx, mu, power).ravel()])
    y0 = np.concatenate([np.asarray(x0, float).ravel(), np.asarray(v0, float).ravel()])
    atol = np.concatenate([np.full(3 * n, atol_x), np.full(3 * n, atol_v)])
    return solve_ivp(rhs, (t0, t_end), y0, method='DOP853', rtol=rtol, atol=atol, events=events, dense_output=dense, t_eval=t_eval)

# ------------------------------------------------------------------------------ two-body tools
def kepler_elements(r0, v0, mu):
    r0 = np.asarray(r0, float); v0 = np.asarray(v0, float)
    r = np.linalg.norm(r0); a = 1.0 / (2.0 / r - (v0 @ v0) / mu)
    h = np.cross(r0, v0); e_vec = np.cross(v0, h) / mu - r0 / r
    return dict(r=r, a=a, e=np.linalg.norm(e_vec), h=h, evec=e_vec, T=2 * math.pi * math.sqrt(a ** 3 / mu), n=math.sqrt(mu / a ** 3))

def kepler_propagate(r0, v0, mu, t):
    """textbook route: Kepler's equation E - e sin E = M and the Lagrange f, g functions (elliptic orbit); no differential equation is integrated"""
    r0 = np.asarray(r0, float); v0 = np.asarray(v0, float)
    r = np.linalg.norm(r0); a = 1.0 / (2.0 / r - (v0 @ v0) / mu); n = math.sqrt(mu / a ** 3)
    ecE = (r0 @ v0) / math.sqrt(mu * a); eCE = 1.0 - r / a            # e sin E0, e cos E0
    E0 = math.atan2(ecE, eCE); e = math.hypot(ecE, eCE)
    M = E0 - e * math.sin(E0) + n * t
    E = M + e * math.sin(M)
    for _ in range(200):
        f = E - e * math.sin(E) - M; dE = -f / (1 - e * math.cos(E)); E += dE
        if abs(dE) < 1e-15 * max(1.0, abs(E)): break
    dE = E - E0
    fF = 1 - a / r * (1 - math.cos(dE)); gG = t - (dE - math.sin(dE)) / n
    pos = fF * r0 + gG * v0; rn = np.linalg.norm(pos)
    fd = -math.sqrt(mu * a) / (rn * r) * math.sin(dE); gd = 1 - a / rn * (1 - math.cos(dE))
    return pos, fd * r0 + gd * v0

# ------------------------------------------------------------------------------ Horizons files (observer tables and headers)
MON = {'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6, 'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12}
def read_hz(name):
    """rows between $$SOE and $$EOE: exact (Fraction) and float R.A./DEC in degrees, delta in au (as printed), plus the elongation columns"""
    txt = open(os.path.join(HZ, name + '.txt'), encoding='utf-8', errors='replace').read()
    hdr, rest = txt.split('$$SOE', 1); body = rest.split('$$EOE', 1)[0]
    rows = []
    for line in body.splitlines():
        t = line.split()
        if len(t) < 15: continue
        y, mo, d = t[0].split('-'); hh, mm = t[1].split(':')
        ra = 15 * (Fr(t[2]) + Fr(t[3]) / 60 + Fr(t[4]) / 3600)
        sg = -1 if t[5].startswith('-') else 1
        dec = sg * (abs(Fr(t[5])) + Fr(t[6]) / 60 + Fr(t[7]) / 3600)
        rows.append(dict(date=datetime.date(int(y), MON[mo], int(d)), hh=int(hh), mm=int(mm), ra_x=ra, dec_x=dec, delta_x=Fr(t[10]),
                         ra=float(ra), dec=float(dec), delta=float(Fr(t[10])), deldot=float(t[11]), sot=float(t[12]), sto=float(t[14]), raw=line.strip()))
    return hdr, rows

def hz_header(name):
    hdr, _ = read_hz(name)
    out = {}
    def grab(key, pat):
        mt = re.search(pat, hdr)
        if mt: out[key] = mt.group(1)
    if name == 'sun':
        grab('GM', r'GM, km\^3/s\^2\s*=\s*([0-9.]+)')
    elif name == 'mercury':
        grab('GM', r'GM \(km\^3/s\^2\)\s*=\s*([0-9.]+)'); grab('ratio', r'Mass ratio \(Sun/plnt\)\s*=\s*([0-9.]+)'); grab('T_sid_d', r'Sidereal orb\. per\.\s*=\s*([0-9.]+)\s*d\b')
    elif name == 'venus':
        grab('GM', r'GM \(km\^3/s\^2\)\s*=\s*([0-9.]+)'); grab('ratio', r'Mass ratio \(Sun/Venus\)\s*=\s*([0-9.]+)'); grab('T_sid_d', r'Sidereal orb\. per\., d\s*=\s*([0-9.]+)')
    return out

def days_between(d0, d1): return (d1 - d0).days

# ------------------------------------------------------------------------------ frames and angles
def rot_ecl_to_eq(eps_arcsec=OBLIQ_ARCSEC):
    e = math.radians(eps_arcsec / 3600.0); c, s = math.cos(e), math.sin(e)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])           # v_eq = R v_ecl

def ra_dec_deg(vec):
    x, y, z = vec; ra = math.degrees(math.atan2(y, x)) % 360.0
    return ra, math.degrees(math.atan2(z, math.hypot(x, y)))

def sep_arcsec(ra1, de1, ra2, de2):
    """great-circle separation by the haversine formula, degrees in, arcsec out"""
    r1, d1, r2, d2 = map(math.radians, (ra1, de1, ra2, de2))
    h = math.sin((d2 - d1) / 2) ** 2 + math.cos(d1) * math.cos(d2) * math.sin((r2 - r1) / 2) ** 2
    return math.degrees(2 * math.asin(min(1.0, math.sqrt(h)))) * 3600.0
