#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""g2_kerr: Kerr in Kerr-Schild form as exact 2-jets at rational points (shared helper, step C2).

 Conventions (the same as b1lib.ks_frame_jet of C1; do not change them)
  n = 4, coordinates x^0..x^3 = (t, x, y, z). A polynomial is a dict {exponent tuple of nv = 4 slots: Fraction}; slot 0 (t) is unused (static
  fields), slots 1..3 hold delta = x - p. Every jet is exact up to total degree 2 in delta (products truncated with b1lib.sp_mul(., ., 2, 4)).
  Signature (+,-,-,-), SQ = [1, -1, -1, -1]. Coframe e^a = dx^a - f l^a l_mu dx^mu, so g = e^T eta e = eta - 2 f l l when l is null.
    r(x, y, z): the positive root of P(r) = r^4 - (x^2 + y^2 + z^2 - a^2) r^2 - a^2 z^2   (a = 0: r = rho = |x|)
    f = M r^3 / (r^4 + a^2 z^2)                                                          (a = 0: f = M/rho, the C1 class)
    l_mu dx^mu = dt + ((r x + a y) dx + (r y - a x) dy)/(r^2 + a^2) + z dz / r,  l^a = eta^{ab} l_b = (1, -l_1, -l_2, -l_3)
  Orientation: with a > 0 the hole turns in the +phi sense about +z, d_phi = x d_y - y d_x, Omega_H = +a/(r+^2 + a^2) (fixed by the null check).
  The sign of a is invisible to the field equation: r and f are even in a, so a -> -a in l alone is Kerr with spin -a (E_a = 0; C2 checks this).
  Chart: l^mu is future-directed and ingoing, so this is the advanced (ingoing) Kerr-Schild chart; it is regular on the FUTURE horizon.
  Rational points: x = sin th (r cos ph - a sin ph), y = sin th (r sin ph + a cos ph), z = r cos th, with Pythagorean (cos, sin) pairs and r rational.
  Jets of r: chord iteration s <- s - P(r0 + s)/P'(r0) on truncated series (one order per step), P'(r0) = 2 (r0^4 + a^2 z0^2)/r0 != 0 off r = 0;
  the 2-jet of P(r0 + s) is then checked to vanish (so s is THE 2-jet of the root). Reciprocals by the geometric series.
 This module builds no engine object (no Lie, no Grav) at import: an engine fault put into memory after the import reaches every check.

 Exports
  rational_kerr_points(a, rs, trig_pairs)            -> list of dicts {p, r, cth, sth, cph, sph}
  kerr_ks_frame_jet(p, M, a, r0=None, nv=4, a_l=None, den_k=1, Mf=None, retarded=False)
                                                     -> (e, E, (l_up, l_dn), data): same structure as b1lib.ks_frame_jet, plus data
                                                        {'r', 'f' (jets), 'r0', 'cth' = z0/r0, 'resP' (2-jet of P(r), empty)}
  d_t(p, nv=4), d_phi(p, nv=4), killing_chi(p, Omega, nv=4)   coordinate components (jets) of d_t, x d_y - y d_x, d_t + Omega d_phi
  kerr_horizon_data(M, a)                            -> RECALLED Boyer-Lindquist numbers {rp, rm, Omega_p, Omega_m, kappa_p, kappa_m} (exact)
  kretschmann_closed(M, a, r, z)                     -> RECALLED closed form of R_abcd R^abcd
  std_christoffel0(g, n=4, nv=4), std_nabla_vv(g, v_up, n=4, nv=4), std_kretschmann(R1, g0, g0i, n=4)     [std] (no engine)
  engine_vector_at0(e, v_up, n=4), engine_nabla_vv(Gv, om, e, v_up, n=4), engine_riemann_coord(Rab, e0, E0, sq, n=4),
  engine_kretschmann(Rab, E0, sq, n=4), frame_norm_bit(va, sq)                                              [bit] (engine passed in)
  null_rotation(e, p, sq, n=4)                       -> (discriminant, Omega) of |d_t + Omega d_phi|^2 at p (double root on a horizon)
  kerr_float(x, y, z, M, a), float_metric(X, M, a)   floats for the [std] numeric route (never uses the jets)"""
import os, sys, math
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import (const, var, at0, lin, scale, sp_mul, sp_add, sp_der, det_inv, trunc, clifford_square)

NV = 4
def _jm(a, b): return sp_mul(a, b, 2, 4)
def _clean(p): return {k: v for k, v in p.items() if v != 0}

def rat_sqrt(q):
    """exact square root of a non-negative Fraction, or None"""
    q = F(q)
    if q < 0: return None
    n, d = q.numerator, q.denominator; rn, rd = math.isqrt(n), math.isqrt(d)
    return F(rn, rd) if rn * rn == n and rd * rd == d else None

def kerr_P(r, p, a):
    x, y, z = p; return r ** 4 - (x * x + y * y + z * z - a * a) * r * r - a * a * z * z

# ------------------------------------------------------------------------------------------------ rational points
PYTH = [(F(3, 5), F(4, 5)), (F(4, 5), F(3, 5)), (F(5, 13), F(12, 13)), (F(12, 13), F(5, 13)), (F(8, 17), F(15, 17)), (F(7, 25), F(24, 25))]
def rational_kerr_points(a, rs, trig_pairs):
    """x = sin th (r cos ph - a sin ph), y = sin th (r sin ph + a cos ph), z = r cos th: rational, with r(x, y, z) = r exactly.
    trig_pairs: list of ((cos th, sin th), (cos ph, sin ph)), each a rational point of the unit circle. The ring (r = 0) is excluded."""
    a = F(a); out = []
    for r in rs:
        r = F(r)
        if r <= 0: raise ValueError('r must be positive (the Kerr-Schild branch r > 0); r = %s' % r)
        for (ct, st), (cp, sp) in trig_pairs:
            ct, st, cp, sp = F(ct), F(st), F(cp), F(sp)
            assert ct * ct + st * st == 1 and cp * cp + sp * sp == 1, 'not a point of the unit circle'
            p = (st * (r * cp - a * sp), st * (r * sp + a * cp), r * ct)
            assert kerr_P(r, p, a) == 0
            out.append(dict(p=p, r=r, cth=ct, sth=st, cph=cp, sph=sp))
    return out

# ------------------------------------------------------------------------------------------------ series helpers (exact, degree 2)
def recip2(A, nv=NV):
    """1/A as a 2-jet (A has a non-zero constant term)"""
    A0 = at0(A, nv); assert A0 != 0
    B = scale(lin((F(1), A), (F(-1), const(nv, A0))), -1 / A0); t = const(nv, 1 / A0); res = dict(t)
    for _ in range(2):
        t = _jm(t, B); res = sp_add(res, t)
    return res

def kerr_r_jet(p, r0, a, nv=NV):
    """2-jet of r(x) at p (r(p) = r0) by the chord iteration; returns (r jet, 2-jet of P(r), which must be empty)"""
    a = F(a); X = [None] + [lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))) for i in (1, 2, 3)]
    rho2 = lin(*[(F(1), _jm(X[i], X[i])) for i in (1, 2, 3)]); Z2 = _jm(X[3], X[3])
    Pp = 4 * r0 ** 3 - 2 * (sum(c * c for c in p) - a * a) * r0
    assert Pp == 2 * (r0 ** 4 + a * a * p[2] ** 2) / r0 and Pp != 0
    coef = lin((F(1), rho2), (-a * a, const(nv, 1)))
    def Pof(s):
        r = lin((F(1), const(nv, r0)), (F(1), s)); r2 = _jm(r, r)
        return lin((F(1), _jm(r2, r2)), (F(-1), _jm(coef, r2)), (-a * a, Z2))
    s = {}
    for _ in range(3): s = lin((F(1), s), (-1 / Pp, Pof(s)))
    return lin((F(1), const(nv, r0)), (F(1), s)), _clean(Pof(s))

# ------------------------------------------------------------------------------------------------ the frame
def kerr_ks_frame_jet(p, M, a, r0=None, nv=NV, a_l=None, den_k=1, Mf=None, retarded=False):
    """coframe e^a = dx^a - f l^a l_mu dx^mu of Kerr in Kerr-Schild form around p = (x, y, z), exact 2-jets in delta = x - p (same structure as
    b1lib.ks_frame_jet: e as forms {1<<mu: poly}, E[mu][a] = delta + f l^mu l_a (the inverse when l is null), (l_up, l_dn)), plus a data dict.
    Controls: a_l = the a used in l only (default a); den_k: f = Mf r^3/(r^4 + den_k a^2 z^2) (default 1); Mf: the M used in f (default M).
    retarded=True: l_mu = (1, -l_1, -l_2, -l_3), the time reverse t -> -t (outgoing congruence; a vacuum with the spin reversed, regular on the past horizon)."""
    p = tuple(F(c) for c in p); a = F(a); a_l = a if a_l is None else F(a_l); Mf = F(M) if Mf is None else F(Mf)
    if r0 is None:
        if a == 0: r0 = rat_sqrt(sum(c * c for c in p))
        else:
            b = sum(c * c for c in p) - a * a; sq_ = rat_sqrt(b * b + 4 * a * a * p[2] ** 2); r0 = rat_sqrt((b + sq_) / 2) if sq_ is not None else None
        if r0 is None: raise ValueError('r(p) is not rational at %s: use rational_kerr_points' % (p,))
    r0 = F(r0); assert r0 > 0 and kerr_P(r0, p, a) == 0
    X = [None] + [lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))) for i in (1, 2, 3)]
    r, resP = kerr_r_jet(p, r0, a, nv)
    r2 = _jm(r, r); r3 = _jm(r2, r); r4 = _jm(r2, r2)
    f = scale(_jm(r3, recip2(lin((F(1), r4), (den_k * a * a, _jm(X[3], X[3]))), nv)), Mf)
    invA = recip2(lin((F(1), r2), (a_l * a_l, const(nv, 1))), nv); invr = recip2(r, nv)
    l1 = _jm(lin((F(1), _jm(r, X[1])), (a_l, X[2])), invA)
    l2 = _jm(lin((F(1), _jm(r, X[2])), (-a_l, X[1])), invA)
    l3 = _jm(X[3], invr)
    if retarded: l1, l2, l3 = scale(l1, -1), scale(l2, -1), scale(l3, -1)
    l_dn = [const(nv, 1), l1, l2, l3]; l_up = [const(nv, 1)] + [scale(q, -1) for q in (l1, l2, l3)]
    e = []; E = [[None] * 4 for _ in range(4)]
    for A in range(4):
        form = {}
        for mu in range(4):
            fl = _jm(_jm(f, l_up[A]), l_dn[mu])
            pol = lin((F(1 if A == mu else 0), const(nv, 1)), (F(-1), fl))
            if pol: form[1 << mu] = pol
            fl2 = _jm(_jm(f, l_up[mu]), l_dn[A])
            E[mu][A] = lin((F(1 if A == mu else 0), const(nv, 1)), (F(1), fl2))
        e.append(form)
    data = dict(r=r, f=f, r0=r0, cth=p[2] / r0, resP=resP, p=p, M=F(M), a=a, a_l=a_l, den_k=den_k, retarded=retarded)
    return e, E, (l_up, l_dn), data

# ------------------------------------------------------------------------------------------------ Killing fields (coordinate components as jets)
def d_t(p, nv=NV): return [const(nv, 1), {}, {}, {}]
def d_phi(p, nv=NV):
    """x d_y - y d_x at p + delta"""
    p = tuple(F(c) for c in p)
    return [{}, lin((-p[1], const(nv, 1)), (F(-1), var(nv, 2))), lin((p[0], const(nv, 1)), (F(1), var(nv, 1))), {}]
def killing_chi(p, Omega, nv=NV):
    t, ph = d_t(p, nv), d_phi(p, nv); return [lin((F(1), t[m]), (F(Omega), ph[m])) for m in range(4)]

# ------------------------------------------------------------------------------------------------ recalled numbers (Boyer-Lindquist; labelled RECALLED wherever used)
def kerr_horizon_data(M, a):
    """RECALLED: r+- = M +- sqrt(M^2 - a^2), Omega+- = a/(r+-^2 + a^2), kappa+- = (r+- - r-+)/(2 (r+-^2 + a^2)) = (r+- - M)/(r+-^2 + a^2). Exact (rational root needed)."""
    M, a = F(M), F(a); s = rat_sqrt(M * M - a * a)
    if s is None: raise ValueError('M^2 - a^2 is not the square of a rational')
    rp, rm = M + s, M - s
    return dict(rp=rp, rm=rm, Omega_p=a / (rp * rp + a * a), Omega_m=a / (rm * rm + a * a) if rm != 0 or a != 0 else None,
                kappa_p=(rp - rm) / (2 * (rp * rp + a * a)), kappa_m=(rm - rp) / (2 * (rm * rm + a * a)) if rm != 0 or a != 0 else None)
def kretschmann_closed(M, a, r, z, c16=16):
    """RECALLED: K = 48 M^2 (r^2 - a^2 C^2)((r^2 + a^2 C^2)^2 - 16 r^2 a^2 C^2)/(r^2 + a^2 C^2)^6, C = cos th = z/r (c16: control coefficient)"""
    M, a, r, z = F(M), F(a), F(r), F(z); C2 = (z / r) ** 2; s = r * r + a * a * C2
    return 48 * M * M * (r * r - a * a * C2) * (s * s - c16 * r * r * a * a * C2) / s ** 6

# ------------------------------------------------------------------------------------------------ [std] routes (no engine)
def std_christoffel0(g, n=4, nv=NV):
    """Gamma^l_{mv} at delta = 0 from the jet of g (dict (mu, nu) -> poly); returns (Gamma dict, g0, g0i)"""
    g0 = [[at0(g[(a, b)], nv) for b in range(n)] for a in range(n)]; det, g0i = det_inv(g0); assert det != 0
    dg = lambda k, a, b: at0(sp_der(g[(a, b)], k), nv); G = {}
    for l in range(n):
        for m in range(n):
            for v in range(n): G[(l, m, v)] = sum(g0i[l][s] * F(1, 2) * (dg(m, s, v) + dg(v, s, m) - dg(s, m, v)) for s in range(n))
    return G, g0, g0i
def std_nabla_vv(g, v_up, n=4, nv=NV):
    """[std] (nabla_v v)^mu at delta = 0 = v^nu d_nu v^mu + Gamma^mu_{nu lam} v^nu v^lam (coordinates)"""
    G, g0, g0i = std_christoffel0(g, n, nv); v0 = [at0(q, nv) for q in v_up]
    return [sum(v0[nu] * at0(sp_der(v_up[mu], nu), nv) for nu in range(n)) + sum(G[(mu, nu, la)] * v0[nu] * v0[la] for nu in range(n) for la in range(n))
            for mu in range(n)]
def std_kretschmann(R1, g0, g0i, n=4):
    """[std] R_{rsmv} R^{rsmv} from R^r_{smv} (b1lib.std_riemann)"""
    T = dict(R1)
    for slot in (1, 2, 3):                                   # raise s, m, v
        U = {}
        for k in T:
            idx = list(k); acc = F(0)
            for b in range(n):
                kk = list(k); kk[slot] = b; acc += g0i[k[slot]][b] * T[tuple(kk)]
            U[k] = acc
        T = U
    return sum(g0[r][a] * R1[(a, s, m, v)] * T[(r, s, m, v)] for r in range(n) for a in range(n) for s in range(n) for m in range(n) for v in range(n))

# ------------------------------------------------------------------------------------------------ [bit] helpers (the engine object is passed in; nothing is cached)
def engine_vector_at0(e, v_up, n=4):
    """frame components v^a = i_v e^a as 2-jets (interior product of the coframe with the coordinate vector v)"""
    va = []
    for A in range(n):
        t = {}
        for mu in range(n):
            q = e[A].get(1 << mu, {})
            if q and v_up[mu]: t = sp_add(t, sp_mul(q, v_up[mu], 2, n))
        va.append(t)
    return va
def engine_nabla_vv(Gv, om, e, v_up, n=4):
    """[bit] frame components at delta = 0 of v^a and of nabla_v v = i_v (D v), (D v)^a = d v^a + h_Ab^a omega^A v^b (engine Grav.D_vector, the engine's d)"""
    va = engine_vector_at0(e, v_up, n); X = [({0: q} if q else {}) for q in va]
    with trunc(n, xdeg=1): DX = Gv.D_vector(om, X)
    v0 = [at0(q, n) for q in v_up]
    return [at0(q, n) for q in va], [sum(at0(DX[A].get(1 << mu, {}), n) * v0[mu] for mu in range(n)) for A in range(n)]
def engine_riemann_coord(Rab, e0, E0, sq, n=4):
    """R^r_{smv} = E^r_a R^{ab}_{mv} eta_bb e^b_s from the engine's R^{ab}_{mu nu} (A4 identification)"""
    return {(r, s, m, v): sum(E0[r][A] * e0[b][s] * sq[b] * Rab.get((A, b, m, v), 0) for A in range(n) for b in range(n))
            for r in range(n) for s in range(n) for m in range(n) for v in range(n)}
def engine_kretschmann(Rab, E0, sq, n=4):
    """[bit] sum sq_a sq_b sq_c sq_d (R^{ab}_{cd})^2, R^{ab}_{cd} = R^{ab}_{mu nu} E^mu_c E^nu_d (frame components of the engine's curvature)"""
    K = F(0)
    for A in range(n):
        for b in range(n):
            if A == b: continue
            for c in range(n):
                for d in range(n):
                    if c == d: continue
                    v = sum(Rab.get((A, b, m, w), 0) * E0[m][c] * E0[w][d] for m in range(n) for w in range(n))
                    K += sq[A] * sq[b] * sq[c] * sq[d] * v * v
    return K
def frame_norm_bit(va, sq):
    """eta_ab v^a v^b as the scalar part of the bit-rule square (sum v^a gamma_a)^2 (constants)"""
    out = clifford_square(sq, {A: ({(0,) * 4: F(v)} if v else {}) for A, v in enumerate(va)}, 4)
    return out.get(0, {}).get((0,) * 4, F(0))
def null_rotation(e, p, sq, n=4):
    """with t^a = i_{d_t} e^a, f^a = i_{d_phi} e^a at p: the discriminant <t,f>^2 - <t,t><f,f> and the root Omega = -<t,f>/<f,f> of |d_t + Omega d_phi|^2
    (a double root on a Killing horizon; None off the axis condition <f,f> = 0)"""
    t = [at0(q, n) for q in engine_vector_at0(e, d_t(p), n)]; ph = [at0(q, n) for q in engine_vector_at0(e, d_phi(p), n)]
    ip = lambda u, w: sum(sq[A] * u[A] * w[A] for A in range(n))
    tt, tf, ff = ip(t, t), ip(t, ph), ip(ph, ph)
    return tf * tf - tt * ff, (-tf / ff if ff != 0 else None)

# ------------------------------------------------------------------------------------------------ floats for the numeric [std] route (never uses the jets)
def kerr_float(x, y, z, M, a):
    """(r, f, l_mu) in floats from the closed forms (positive root r^2 = ((rho^2 - a^2) + sqrt((rho^2 - a^2)^2 + 4 a^2 z^2))/2)"""
    M, a = float(M), float(a); b = x * x + y * y + z * z - a * a; r = math.sqrt((b + math.sqrt(b * b + 4 * a * a * z * z)) / 2)
    f = M * r ** 3 / (r ** 4 + a * a * z * z); A = r * r + a * a
    return r, f, (1.0, (r * x + a * y) / A, (r * y - a * x) / A, z / r)
def float_metric(X, M, a):
    """g_{mu nu} = sum_a sq_a e^a_mu e^a_nu with e^a_mu = delta - f l^a l_mu, at X = (t, x, y, z) (numpy array)"""
    import numpy as np
    r, f, l = kerr_float(X[1], X[2], X[3], M, a); ld = np.array(l); lu = np.array([l[0], -l[1], -l[2], -l[3]])
    e = np.eye(4) - f * np.outer(lu, ld); eta = np.diag([1.0, -1.0, -1.0, -1.0])
    return e.T @ eta @ e
