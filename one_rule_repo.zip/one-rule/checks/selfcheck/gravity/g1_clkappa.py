#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G1 helpers: rigid bodies in Cl_kappa^3 on the Atlas forque engine, Gunn's compact system, and [std] tops with matrices.

Engine: forque_selfcheck.Alg(d, sp=1, eps_sq=kappa): sq = [kappa, 1, .., 1] = Gunn's Cl_kappa^d (e0^2 = kappa, space +1; Atlas s = -kappa).
Points: Alg.point(q) = O + q I = e123 + q1 e032 + q2 e013 + q3 e021 (weight 1 for every kappa); X^2 = -(1 + kappa |q|^2).
Normalisation chosen: a mass mu at the kappa-normalised point X/||X|| (||X||^2 = 1 + kappa |q|^2) is the engine body point X with mass
mu / (1 + kappa |q|^2) (I_def is quadratic in X): exact, no square roots.  kappa = -1 needs proper points |q| < 1.
Gunn's basis (thesis (9.19)): e01 e02 e03 e12 e31 e23 with e31 = e3 e1 (= - mask 0b1010).
[std] (no Clifford product): vectors v = R I^-1 = (w/kappa, x, y, z) in R^{eta}, eta = diag(kappa, 1, 1, 1); top with a fixed point
  L_b = J Om^T - Om J, L_b' = -Om L_b - L_b Om^T, Lam' = Lam Om, J = sum mu v v^T;  Om^(ab)[b][a] = eta_a, Om^(ab)[a][b] = -eta_b (textbook v.(a^b));
  kappa = 0: Newton-Euler (I_c w' = (I_c w) x w, Rot' = Rot [w]x, c.o.m. uniform), w0 = (B23, -B13, B12), origin velocity (B01, B02, B03).
Import-safe: loads the read-only forque engine without writing bytecode; no differential-form engine object."""
import sys, os
from fractions import Fraction as F
sys.dont_write_bytecode = True
_HERE = os.path.dirname(os.path.abspath(__file__)); _SELFCHECK = os.path.dirname(_HERE)
sys.path.insert(0, _SELFCHECK)
import forque_selfcheck as FQ
sys.path.pop(0)

MV, Alg, Body, Ser, picard, inverse = FQ.MV, FQ.Alg, FQ.Body, FQ.Ser, FQ.picard, FQ.inverse
GB3 = [(0b0011, 1), (0b0101, 1), (0b1001, 1), (0b0110, 1), (0b1010, -1), (0b1100, 1)]   # e01 e02 e03 e12 e31 e23
GB2 = [(0b011, 1), (0b101, 1), (0b110, 1)]                                               # e01 e02 e12 (2D)
PAIRS4 = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]                                # engine masks e_a e_b, a < b

def alg(kappa, d=3): return Alg(d, sp=1, eps_sq=kappa)
def qnorm2(kappa, q): return 1 + kappa * sum(F(x) * F(x) for x in q)
def engine_pts(kappa, pts):
    """[(mu, q)] masses mu at the kappa-normalised points -> [(mass for the weight-1 engine point, q)]"""
    out = []
    for mu, q in pts:
        n2 = qnorm2(kappa, q)
        if n2 <= 0: raise ValueError('improper point for kappa = %s: %s' % (kappa, q))
        out.append((F(mu) / n2, [F(x) for x in q]))
    return out
def body_n(A, kappa, pts): return Body(A, engine_pts(kappa, pts))
def gvec(A, w, basis=GB3): return MV(A.sq, {m: F(s) * F(c) for (m, s), c in zip(basis, w) if c})
def gread(X, basis=GB3): return [s * X.d.get(m, F(0)) for m, s in basis]
def unit(i, n=6): return [F(int(j == i)) for j in range(n)]
def pair(A, X, Y):
    """the join pairing of two bivectors (metric-free): a scalar"""
    J = A.join(X, Y); assert set(J.d) <= {0}, 'join of two bivectors is not a scalar'; return J.scalar()
def mat_vec(M, v): return [sum(M[i][j] * v[j] for j in range(len(v))) for i in range(len(M))]
def mat_mul(X, Y): return [[sum(X[i][k] * Y[k][j] for k in range(len(Y))) for j in range(len(Y[0]))] for i in range(len(X))]

# ---------------------------------------------------------------------------------------------------------- Gunn's inertia matrix (9.19)
def gunn_919_point(k, w, x, y, z):
    """the matrix in (9.19) for one particle, without the leading 2 and the mass (my reading of the text file; rows/cols e01 e02 e03 e12 e31 e23)"""
    return [[w*w + k*x*x, k*x*y, k*x*z, -w*y, w*z, 0], [k*x*y, w*w + k*y*y, k*y*z, w*x, 0, -w*z], [k*x*z, k*y*z, w*w + k*z*z, 0, -w*x, w*y],
            [-w*y, w*x, 0, x*x + y*y, -y*z, -x*z], [w*z, 0, -w*x, -y*z, x*x + z*z, -x*y], [0, -w*z, w*y, -x*z, -x*y, y*y + z*z]]
def gunn_919(kappa, pts):
    """sum_i mu_i M_i at the kappa-normalised points (quadratic: = sum (mu/||X||^2) M(1, q)); WITHOUT the 2 of (9.19)"""
    S = [[F(0)] * 6 for _ in range(6)]
    for me, q in engine_pts(kappa, pts):
        Mi = gunn_919_point(F(kappa), F(1), *q)
        for i in range(6):
            for j in range(6): S[i][j] += me * Mi[i][j]
    return S
def sigma_engine(A, Imap, basis=GB3):
    """Sigma_ab = b_a v A(b_b) (join pairing with the Atlas inertia map)"""
    n = len(basis); return [[pair(A, gvec(A, unit(a, n), basis), Imap(gvec(A, unit(b, n), basis))) for b in range(n)] for a in range(n)]
def gunn_maps(A, G, basis=GB3):
    """Gunn's A_G as a map from its bilinear matrix G (A_G(b_a, b_b) = G_ab) by (9.18): -b_a v A_G(Om) = (G w)_a.  Returns (AG, AGinv)."""
    n = len(basis); K = [[pair(A, gvec(A, unit(a, n), basis), gvec(A, unit(b, n), basis)) for b in range(n)] for a in range(n)]
    Ki, Gi = inverse(K), inverse(G)
    def AG(Om): return gvec(A, [-x for x in mat_vec(Ki, mat_vec(G, gread(Om, basis)))], basis)
    def AGinv(P): return gvec(A, [-x for x in mat_vec(Gi, mat_vec(K, gread(P, basis)))], basis)
    return AG, AGinv
def linear_map(A, images, basis_masks):
    """a linear bivector map given by images of the basis masks (MV in any algebra; coefficients copied by mask) and its inverse"""
    dv = basis_masks; mat = [[images[b].d.get(o, F(0)) for b in basis_masks] for o in dv]; mi = inverse(mat)
    def Imap(B): return MV(A.sq, {o: sum(mat[i][j] * B.d.get(b, F(0)) for j, b in enumerate(basis_masks)) for i, o in enumerate(dv)})
    def Iinv(P): return MV(A.sq, {b: sum(mi[i][j] * P.d.get(o, F(0)) for j, o in enumerate(dv)) for i, b in enumerate(basis_masks)})
    return Imap, Iinv
def gunn_915(A, R, Om, Xi, m=1):
    """(9.15)  -(m/2) ((R v 2(Om x R)) I) v (R v 2(Xi x R))"""
    L1 = A.join(R, A.comm(Om, R).scale(2)); L2 = A.join(R, A.comm(Xi, R).scale(2)); return -F(m, 2) * A.join(L1 * A.I, L2).scalar()
def gunn_98(A, R, Om, m=1):
    """(9.8)  -Om v Pi with Pi = 2 m R v (Om x R)  (9.3)"""
    return -A.join(Om, A.join(R, A.comm(Om, R)).scale(2 * m)).scalar()

# ---------------------------------------------------------------------------------------------------------- series helpers
def szero(A): return A.zero()
def ser_bilin(f, X, Y):
    """sum_{i+j=k} f(X_i, Y_j) for a bilinear f on multivectors"""
    N = len(X.c); z = X.c[0].scale(0); out = []
    for k in range(N):
        acc = z
        for i in range(k + 1):
            if X.c[i].d and Y.c[k - i].d: acc = acc + f(X.c[i], Y.c[k - i])
        out.append(acc)
    return Ser(out)
def ser_const(X, N): return Ser.const(X, N)
def ser_is_const(S, n): return all(not c.d for c in S.c[1:n + 1])
def ser_eq(a, b, n): return all(x == y for x, y in zip(a.c[:n + 1], b.c[:n + 1]))
def bad_comm(A, pair_masks=(0b0110, 0b1100)):
    """[fault FC] the commutator with the sign of one bivector pair flipped in the product table (both orders)"""
    pa = set(pair_masks)
    def prod(X, Y):
        r = {}
        for ma, ca in X.d.items():
            for mb, cb in Y.d.items():
                m, s = FQ.bmul(ma, mb, X.sq)
                if {ma, mb} == pa: s = -s
                if s: r[m] = r.get(m, 0) + s * ca * cb
        return MV(X.sq, r)
    return lambda X, Y: (prod(X, Y) - prod(Y, X)).scale(F(1, 2))

# ---------------------------------------------------------------------------------------------------------- the two flows
def engine_flow(A, Imap, Iinv, B0, N, M0=None, comm=None, sign=1):
    """[bit] EQN-019 with F = 0: M' = -(1/2) M B, B' = A^-1(sign * B x A(B)).  Exact Taylor series through t^N."""
    comm = comm or A.comm
    def f(S):
        M, B = S; P = B.map(Imap)
        return [(M * B).scale(F(-1, 2)), ser_bilin(comm, B, P).map(Iinv).scale(sign)]
    return picard(f, [M0 or A.one(), B0], N)
def gunn_flow(A, AG, AGinv, Om0, N, g0=None):
    """Gunn (9.26)-(9.27): g' = g Om, Om' = 2 A_G^-1(A_G(Om) x Om)"""
    def f(S):
        g, Om = S
        return [g * Om, ser_bilin(A.comm, Om.map(AG), Om).map(AGinv).scale(2)]
    return picard(f, [g0 or A.one(), Om0], N)
def integrals(A, Imap, M, B):
    """(Pi_s = M A(B) M~, E = (1/2) B v A(B), C2 = <P P>_0, C4 = <P P>_4) as series"""
    P = B.map(Imap); PP = P * P
    return M * P * M.rev(), ser_bilin(A.join, B, P).scale(F(1, 2)), PP.map(lambda X: X.grade(0)), PP.map(lambda X: X.grade(4))
def world_points(A, M, epts):
    N = len(M.c) - 1; return [M * Ser.const(A.point(q), N) * M.rev() for _, q in epts]
def point_momentum(A, M, epts):
    """sum m_e R v R' over the engine points (= sum mu R^ v R^' for the normalised points); valid through t^(N-1)"""
    tot = None
    for (me, q), R in zip(epts, world_points(A, M, epts)):
        J = ser_bilin(A.join, R, R.d_dt()).scale(me); tot = J if tot is None else tot + J
    return tot
def trivector_coords(A, R):
    """R = w O + sum x_k (e_k I)  ->  (w, x1, x2, x3); the basis of Alg.point"""
    T = [A.O] + [A.vec([int(i == k) for i in range(A.d)]) * A.I for k in range(A.d)]
    out = []
    for Tk in T:
        (m, s), = Tk.d.items(); out.append(R.d.get(m, F(0)) / s)
    return out
def vector_matrix_series(A, M):
    """[bit] Lam_eng[i][j](t) = coefficient of e_i in M e_j M~ (series lists)"""
    N = len(M.c) - 1; out = [[None] * A.n for _ in range(A.n)]
    for j in range(A.n):
        S = M * Ser.const(A.g(j), N) * M.rev()
        for i in range(A.n): out[i][j] = [c.d.get(1 << i, F(0)) for c in S.c]
    return out

# ---------------------------------------------------------------------------------------------------------- [std] exact series of matrices (no Clifford product)
def s_zero(N): return [F(0)] * (N + 1)
def s_const(c, N): r = s_zero(N); r[0] = F(c); return r
def s_add(a, b): return [x + y for x, y in zip(a, b)]
def s_sub(a, b): return [x - y for x, y in zip(a, b)]
def s_scale(a, k): return [x * k for x in a]
def s_mul(a, b):
    N = len(a) - 1; r = [F(0)] * (N + 1)
    for i, x in enumerate(a):
        if x:
            for j in range(N + 1 - i):
                if b[j]: r[i + j] += x * b[j]
    return r
def s_int(a, c0): return [F(c0)] + [a[k - 1] / k for k in range(1, len(a))]
def sm_mul(X, Y):
    N = len(X[0][0]) - 1
    out = []
    for i in range(len(X)):
        row = []
        for j in range(len(Y[0])):
            acc = s_zero(N)
            for k in range(len(Y)): acc = s_add(acc, s_mul(X[i][k], Y[k][j]))
            row.append(acc)
        out.append(row)
    return out
def sm_T(X): return [[X[j][i] for j in range(len(X))] for i in range(len(X[0]))]
def sm_add(X, Y): return [[s_add(a, b) for a, b in zip(r1, r2)] for r1, r2 in zip(X, Y)]
def sm_scale(X, k): return [[s_scale(a, k) for a in r] for r in X]
def sm_constmat(Mc, N): return [[s_const(x, N) for x in r] for r in Mc]
def om_basis(eta):
    """Om^(ab) for the engine bivector e_a e_b (a < b): Om e_j = eta_ja e_b - eta_jb e_a"""
    out = []
    for a, b in PAIRS4:
        Om = [[F(0)] * 4 for _ in range(4)]; Om[b][a] += eta[a]; Om[a][b] -= eta[b]; out.append(Om)
    return out
def std_top(kappa, epts, Bcoef, N, eta=None):
    """[std] top with a fixed point in R^eta (eta = diag(kappa,1,1,1) unless given): returns (Lam series 4x4, B series [6], J, L_b(0)).
    epts: engine points [(m_e, q)]; v' = (1/kappa, q); Bcoef: engine bivector coefficients on PAIRS4 (engine masks)."""
    eta = eta or [F(kappa), F(1), F(1), F(1)]
    vs = [(me, [F(1) / F(kappa)] + list(q)) for me, q in epts]
    J = [[sum(me * v[i] * v[j] for me, v in vs) for j in range(4)] for i in range(4)]
    OB = om_basis(eta)
    def Lb_of(Om): return [[sum(J[i][k] * Om[j][k] - Om[i][k] * J[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
    Phi = [[Lb_of(OB[c])[a][b] for c in range(6)] for (a, b) in PAIRS4]; Pi = inverse(Phi)
    def f(S):
        Lam, Bs = S
        Om = [[s_zero(N) for _ in range(4)] for _ in range(4)]
        for c in range(6):
            for i in range(4):
                for j in range(4):
                    if OB[c][i][j]: Om[i][j] = s_add(Om[i][j], s_scale(Bs[c], OB[c][i][j]))
        L = [[s_zero(N) for _ in range(4)] for _ in range(4)]
        for c in range(6):
            Lc = Lb_of(OB[c])
            for i in range(4):
                for j in range(4):
                    if Lc[i][j]: L[i][j] = s_add(L[i][j], s_scale(Bs[c], Lc[i][j]))
        Ld = sm_scale(sm_add(sm_mul(Om, L), sm_mul(L, sm_T(Om))), -1)
        up = [Ld[a][b] for a, b in PAIRS4]
        dB = [[sum((Pi[r][c] * up[c][k] for c in range(6)), F(0)) for k in range(N + 1)] for r in range(6)]
        return [sm_mul(Lam, Om), dB]
    Lam0 = [[F(int(i == j)) for j in range(4)] for i in range(4)]
    S = [sm_constmat(Lam0, N), [s_const(b, N) for b in Bcoef]]
    for _ in range(N + 1):
        dL, dB = f(S)
        S = [[[s_int(dL[i][j], Lam0[i][j]) for j in range(4)] for i in range(4)], [s_int(dB[r], Bcoef[r]) for r in range(6)]]
    return S[0], S[1], J, vs
def std_newton_euler(epts, Bcoef, N):
    """[std] kappa = 0: textbook rigid body.  Returns world point series [(x(t), y(t), z(t))] and w(t) (3 series)."""
    m = sum(me for me, _ in epts); c = [sum(me * q[i] for me, q in epts) / m for i in range(3)]
    rs = [[q[i] - c[i] for i in range(3)] for _, q in epts]
    Ic = [[sum(me * ((sum(x * x for x in r) if i == j else 0) - r[i] * r[j]) for (me, _), r in zip(epts, rs)) for j in range(3)] for i in range(3)]
    Ici = inverse(Ic)
    B = dict(zip(PAIRS4, Bcoef)); b = [B[(0, 1)], B[(0, 2)], B[(0, 3)]]; w0 = [B[(2, 3)], -B[(1, 3)], B[(1, 2)]]
    cross = lambda u, v: [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
    vc = [b[i] + cross(w0, c)[i] for i in range(3)]
    def f(S):
        Rot, w = S
        Iw = [[sum(s_mul(s_const(Ic[i][j], N), w[j])[k] for j in range(3)) for k in range(N + 1)] for i in range(3)]
        cr = [s_sub(s_mul(Iw[1], w[2]), s_mul(Iw[2], w[1])), s_sub(s_mul(Iw[2], w[0]), s_mul(Iw[0], w[2])), s_sub(s_mul(Iw[0], w[1]), s_mul(Iw[1], w[0]))]
        dw = [[sum(Ici[i][j] * cr[j][k] for j in range(3)) for k in range(N + 1)] for i in range(3)]
        Z = s_zero(N); W = [[Z, s_scale(w[2], -1), w[1]], [w[2], Z, s_scale(w[0], -1)], [s_scale(w[1], -1), w[0], Z]]
        return [sm_mul(Rot, W), dw]
    R0 = [[F(int(i == j)) for j in range(3)] for i in range(3)]
    S = [sm_constmat(R0, N), [s_const(x, N) for x in w0]]
    for _ in range(N + 1):
        dR, dw = f(S); S = [[[s_int(dR[i][j], R0[i][j]) for j in range(3)] for i in range(3)], [s_int(dw[i], w0[i]) for i in range(3)]]
    Rot, w = S; out = []
    for r in rs:
        pt = []
        for i in range(3):
            s = s_const(c[i], N); s[1] += vc[i]
            for j in range(3): s = s_add(s, s_scale(Rot[i][j], r[j]))
            pt.append(s)
        out.append(pt)
    return out, w
def charpoly(Mx):
    """Faddeev-LeVerrier: coefficients [1, c1, ..., cn] of det(lambda - M), exact"""
    n = len(Mx); I = [[F(int(i == j)) for j in range(n)] for i in range(n)]; Mk = [r[:] for r in I]; cs = [F(1)]; AM = None
    for k in range(1, n + 1):
        AM = mat_mul(Mx, Mk); ck = -sum(AM[i][i] for i in range(n)) / k; cs.append(ck)
        Mk = [[AM[i][j] + (ck if i == j else 0) for j in range(n)] for i in range(n)]
    return cs
