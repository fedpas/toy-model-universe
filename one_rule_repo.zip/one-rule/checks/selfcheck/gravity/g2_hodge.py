#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""g2_hodge: frame components of forms, the Hodge star in a frame (bit rule and textbook), Maxwell and scalar-field stress (bit rule and components),
the covariant derivative of two-index frame components with the engine's omega.  Shared helper (step C3).
   python3 g2_hodge.py      runs the self-test (exact)

Conventions: n = len(sq), eta_aa = sq[a] (Lorentz (+,-,-,-) by default); a form is {coordinate mask: polynomial};
a frame is a list of n 1-forms e[a]; the inverse frame E[mu][a] (polynomials) has sum_mu e^a_mu E^mu_b = delta^a_b.
 Frame components   X = sum_I X_I e^I (I increasing frame masks),  X_I = sum_J X_J det(E[J][I]).
 Hodge star         bit rule: *(e^I) = rev(e_I) e_{01..n-1} (Clifford product, squares sq);  textbook: *(e^I) = (prod_{i in I} eta^ii) sgn(I, I^c) e^{I^c},  eps_{01..n-1} = +1.
 Maxwell stress     (space-time algebra form, imported: the Atlas builds none)  T(a) = -(1/2) F a F,  F = sum_{a<b} F^{ab} gamma_a gamma_b,  F^{ab} = eta^aa eta^bb F_ab,
                    T(gamma_a) = sum_b T^b_a gamma_b;  components (signature +,-,-,-):  T^a_b = -F^{ac} F_{bc} + (1/4) delta^a_b F_{cd} F^{cd},  T^0_0 = (E^2 + B^2)/2.
 Scalar stress      T(a) = (1/2) (grad phi) a (grad phi) + (1/2) m^2 phi^2 a;   T^a_b = d^a phi d_b phi - delta^a_b ((1/2) d^c phi d_c phi - (1/2) m^2 phi^2).
 Stress forms       T_a = sum_b T^b_a Theta_b,  Theta_b = iota_{E_b} vol = (-1)^b e^0 ^ .. (no e^b) .. ^ e^{n-1}   (A4: E_a = -(G^b_a - Lambda delta^b_a) Theta_b;  D1: E_a + kappa T_a = 0).
 Matrices T[up][down]: T[b][a] = T^b_a.
No engine object is built at import time: an engine fault is put into the engine classes in memory, so build Forms / Lie / Grav inside your run."""
import os, sys, itertools, random
from fractions import Fraction as F
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _here)
import b1lib
from b1lib import gs, bmul, popc, padd, const, var, at0, scale, lin, pm, sp_mul

LOR = lambda n: [1] + [-1] * (n - 1)
def masks(n, k): return [m for m in range(1 << n) if popc(m) == k]
def bits(m): return [i for i in range(m.bit_length()) if m >> i & 1]
def perm_sign(seq):
    seq = list(seq); s = 1
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]: s = -s
    return s

# ------------------------------------------------------------------------------------------------ Hodge star on basis masks
def star_bit(I, sq):
    """[bit] *(e^I) = rev(e_I) e_N : returns (mask, sign)"""
    N = (1 << len(sq)) - 1; J, s = bmul(I, N, sq); return J, s * gs.rsign(popc(I))
def star_std(I, sq):
    """[std] textbook: (prod_{i in I} eta^ii) sgn(I, I^c), eps_{0..n-1} = +1"""
    n = len(sq); Ic = [i for i in range(n) if not I >> i & 1]; s = perm_sign(bits(I) + Ic)
    for i in bits(I): s *= sq[i]
    return ((1 << n) - 1) ^ I, s
def star_comps(comp, sq, route='bit'):
    """frame components {mask: polynomial or number} -> components of the dual"""
    st = star_bit if route == 'bit' else star_std; out = {}
    for I, p in comp.items():
        J, s = st(I, sq)
        if isinstance(p, dict): out[J] = padd(out.get(J, {}), p, s)
        else: out[J] = out.get(J, 0) + s * p
    return out

# ------------------------------------------------------------------------------------------------ frame components of forms and back
def frame_components(X, E, n):
    """X (coordinate masks) -> {frame mask I: polynomial}, X_I = sum_J X_J det(E[J][I]).  Products go through b1lib.pm, so an active b1lib.trunc applies."""
    out = {}
    for J, p in X.items():
        if not p: continue
        k = popc(J); Jb = bits(J)
        if k == 0: out[0] = padd(out.get(0, {}), p); continue
        for I in masks(n, k):
            Ib = bits(I); tot = {}
            for perm in itertools.permutations(range(k)):
                t = p
                for i in range(k):
                    q = E[Jb[i]][Ib[perm[i]]]
                    if not q: t = {}; break
                    t = pm(t, q)
                if t: tot = padd(tot, t, perm_sign(perm))
            if tot: out[I] = padd(out.get(I, {}), tot)
    return {I: q for I, q in out.items() if q}
def e_wedge(e, Fm, I, nv):
    """e^I = e^{i1} ^ e^{i2} ^ ... (increasing), engine wedge"""
    out = {0: const(nv, 1)}
    for a in bits(I): out = Fm.wedge(out, e[a])
    return out
def form_from_frame(comp, e, Fm, nv):
    out = {}
    for I, p in comp.items():
        if p: out = Fm.add(out, Fm.wedge({0: p}, e_wedge(e, Fm, I, nv)))
    return out
def hodge_form(X, e, E, Fm, sq, nv, route='bit'):
    """*X for a coordinate form X on the frame e (inverse E): frame components, star, rebuilt with the engine wedge of the frame 1-forms"""
    return form_from_frame(star_comps(frame_components(X, E, len(sq)), sq, route), e, Fm, nv)
def vol_form(e, Fm, nv): return e_wedge(e, Fm, (1 << len(e)) - 1, nv)
def theta_forms(e, Fm, nv):
    """Theta_b = iota_{E_b} (e^0 ^ ... ^ e^{n-1}) = (-1)^b e^0 ^ .. (no e^b) .. ^ e^{n-1}"""
    n = len(e); return [Fm.scale(e_wedge(e, Fm, ((1 << n) - 1) ^ (1 << b), nv), (-1) ** b) for b in range(n)]
def stress_forms(Tmix, theta, Fm):
    """T_a = sum_b T^b_a Theta_b  (Tmix[b][a] = T^b_a, numbers)"""
    n = len(theta); out = []
    for a in range(n):
        tot = {}
        for b in range(n):
            if Tmix[b][a] != 0: tot = Fm.add(tot, theta[b], Tmix[b][a])
        out.append(tot)
    return out

# ------------------------------------------------------------------------------------------------ multivectors (numbers) and the stresses
def gp(A, B, sq):
    R = {}
    for a, x in A.items():
        for b, y in B.items():
            m, s = bmul(a, b, sq)
            if s: R[m] = R.get(m, 0) + s * x * y
    return {m: v for m, v in R.items() if v != 0}
def bivector(Fl, sq, ident='upper'):
    """Fl[(a, b)] (a < b): lower frame components -> {mask: coefficient} = sum_{a<b} F^{ab} gamma_a gamma_b.  ident='lower' (a control): sum F_ab gamma_a gamma_b"""
    out = {}
    for (a, b), v in Fl.items():
        if v == 0: continue
        c = v * (sq[a] * sq[b] if ident == 'upper' else 1); m, s = bmul(1 << a, 1 << b, sq)
        out[m] = out.get(m, 0) + s * c
    return out
def maxwell_T_bit(Fmv, sq, sign=F(-1, 2)):
    """[bit] T^b_a = coefficient of gamma_b in sign * F gamma_a F  (sign = -1/2: the stress; +1/2: the wrong-sign control)"""
    n = len(sq); T = [[F(0)] * n for _ in range(n)]
    for a in range(n):
        Ta = gp(gp(Fmv, {1 << a: F(1)}, sq), Fmv, sq)
        assert all(popc(m) == 1 for m in Ta), 'F a F is a vector'
        for b in range(n): T[b][a] = sign * Ta.get(1 << b, 0)
    return T
def maxwell_T_std(Fl, sq):
    """[std] T^a_b = -F^{ac} F_{bc} + (1/4) delta^a_b F_{cd} F^{cd} from lower components Fl[(a, b)], a < b (plain index loops)"""
    n = len(sq); L = [[F(0)] * n for _ in range(n)]
    for (a, b), v in Fl.items(): L[a][b] = F(v); L[b][a] = -F(v)
    U = [[sq[a] * sq[b] * L[a][b] for b in range(n)] for a in range(n)]
    F2 = sum(L[c][d] * U[c][d] for c in range(n) for d in range(n))
    return [[-sum(U[a][c] * L[b][c] for c in range(n)) + (F2 / 4 if a == b else 0) for b in range(n)] for a in range(n)]
def scalar_T_bit(dphi, phi, m2, sq, half=F(1, 2)):
    """[bit] T(gamma_a) = half (grad phi) gamma_a (grad phi) + (1/2) m^2 phi^2 gamma_a, grad phi = sum_a eta^aa d_a phi gamma_a  (half != 1/2: a control)"""
    n = len(sq); g = {1 << a: sq[a] * F(dphi[a]) for a in range(n) if dphi[a] != 0}; T = [[F(0)] * n for _ in range(n)]
    for a in range(n):
        Ta = gp(gp(g, {1 << a: F(1)}, sq), g, sq)
        for b in range(n): T[b][a] = half * Ta.get(1 << b, 0) + (F(1, 2) * m2 * phi * phi if a == b else 0)
    return T
def scalar_T_std(dphi, phi, m2, sq):
    """[std] T^a_b = d^a phi d_b phi - delta^a_b ((1/2) d^c phi d_c phi - (1/2) m^2 phi^2)"""
    n = len(sq); up = [sq[a] * F(dphi[a]) for a in range(n)]; kin = sum(up[c] * dphi[c] for c in range(n))
    return [[up[a] * dphi[b] - ((kin - m2 * phi * phi) / 2 if a == b else 0) for b in range(n)] for a in range(n)]
def contract_NN(Tmix, N, sq):
    """T_ab N^a N^b = sum_{a,b} eta_aa T^a_b N^a N^b"""
    n = len(sq); return sum(sq[a] * Tmix[a][b] * N[a] * N[b] for a in range(n) for b in range(n))

# ------------------------------------------------------------------------------------------------ covariant derivative of two-index frame components (engine omega, h table)
def D_two_index(Gv, om, Fab, nv):
    """D F_ab = d F_ab - omega^c_a F_cb - omega^c_b F_ac through the engine's D_covector (reads the h table).  Fab[(a, b)]: polynomials for all a != b.  Returns {(a, b): 1-form}"""
    n = Gv.n; Z = lambda p: ({0: p} if p else {})
    cols = {b: Gv.D_covector(om, [Z(Fab.get((a, b), {})) for a in range(n)]) for b in range(n)}
    rows = {a: Gv.D_covector(om, [Z(Fab.get((a, b), {})) for b in range(n)]) for a in range(n)}
    out = {}
    for a in range(n):
        for b in range(n): out[(a, b)] = Gv.Fm.add(Gv.Fm.add(cols[b][a], rows[a][b]), Gv.Fm.d(Z(Fab.get((a, b), {}))), -1)
    return out
def frame_derivative_at0(one_form, E, n, nv):
    """frame components X_c = sum_mu X_mu E^mu_c of a 1-form, at the origin of the jets"""
    return [sum(at0(one_form.get(1 << mu, {}), nv) * at0(E[mu][c], nv) for mu in range(n)) for c in range(n)]
def frame_divergence_at0(DF, E, sq, nv):
    """nabla^a F_ab = sum_a eta^aa (D F_ab)(E_a) at the origin, for each b"""
    n = len(sq); return [sum(sq[a] * frame_derivative_at0(DF[(a, b)], E, n, nv)[a] for a in range(n)) for b in range(n)]

# ------------------------------------------------------------------------------------------------ jets of rho^k at a rational point
def rho_pow_jet(p, rho0, k, order, nv=4, slots=(1, 2, 3)):
    """rho^k around the spatial point p (rho0 = |p| rational), exact up to total degree `order` in delta: rho0^k (1 + u)^(k/2), u = (2 p.delta + |delta|^2)/rho0^2"""
    X = [var(nv, i) for i in slots]; rho0 = F(rho0)
    u = lin((F(2) / rho0 ** 2, lin(*[(F(p[j]), X[j]) for j in range(len(slots))])), (F(1) / rho0 ** 2, lin(*[(F(1), sp_mul(X[j], X[j], order, nv)) for j in range(len(slots))])))
    al = F(k, 2); coef = F(1); term = const(nv, 1); out = const(nv, 1)
    for j in range(1, order + 1):
        coef = coef * (al - j + 1) / j; term = sp_mul(term, u, order, nv); out = padd(out, term, coef)
    return scale(out, rho0 ** k)

# ------------------------------------------------------------------------------------------------ self-test (call with b1lib.chk)
def selftest(chk, seed=5, nrand=8):
    sq = LOR(4); n = 4; N = 15; Fm = gs.Forms(n); rng = random.Random(seed); one = const(n, 1)
    rnd = lambda: F(rng.randint(-9, 9), rng.randint(1, 6))
    chk('bit==std', all(star_bit(I, sq) == star_std(I, sq) for I in range(16)), 'Hodge star: bit rule rev(e_I) e_0123 = textbook (prod eta^ii) sgn(I, I^c) e^{I^c} on all 16 basis masks (eps_0123 = +1)')
    ss = {}
    for I in range(16):
        J, s1 = star_bit(I, sq); K, s2 = star_bit(J, sq); ss.setdefault(popc(I), set()).add((K == I) * s1 * s2)
    chk('bit', ss == {0: {-1}, 1: {1}, 2: {-1}, 3: {1}, 4: {-1}}, '** = -1 on 0-, 2-, 4-forms and +1 on 1-, 3-forms (Lorentz signature): %s' % {k: sorted(v) for k, v in ss.items()})
    ssE = {}
    for I in range(16):
        J, s1 = star_bit(I, [1, 1, 1, 1]); K, s2 = star_bit(J, [1, 1, 1, 1]); ssE.setdefault(popc(I), set()).add(s1 * s2)
    chk('ctl', ssE[2] != {-1}, 'control: the same bit rule with Euclidean squares gives ** = %s on 2-forms (not -1)' % sorted(ssE[2]))
    ok = True
    for k in range(5):
        for I in masks(n, k):
            for J in masks(n, k):
                Js, s = star_bit(J, sq); w = Fm.wedge({I: one}, {Js: scale(one, s)}); inner = 1
                for i in bits(I): inner *= sq[i]
                ok &= (w == ({N: const(n, inner)} if I == J else {}))
    chk('bit', ok, 'alpha ^ *beta = <alpha, beta> vol on all pairs of basis forms of equal degree (engine wedge; <e^I, e^I> = prod eta^ii)')
    eps = lambda idx: perm_sign(idx) if len(set(idx)) == 4 else 0
    ok_c = True; ok_t = True
    for _ in range(nrand):
        Fl = {(a, b): rnd() for a in range(4) for b in range(a + 1, 4)}
        st = star_comps({(1 << a) | (1 << b): v for (a, b), v in Fl.items()}, sq)
        for (a, b) in Fl:
            want = sum(eps([a, b, c, d]) * sq[c] * sq[d] * Fl[(c, d)] for (c, d) in Fl)
            ok_c &= (st.get((1 << a) | (1 << b), 0) == want)
    epsup = lambda idx: eps(idx) * sq[idx[0]] * sq[idx[1]] * sq[idx[2]] * sq[idx[3]]
    for c, d, e_, f_ in itertools.product(range(4), repeat=4):
        lhs = sum(eps([a, b, c, d]) * epsup([a, b, e_, f_]) for a in range(4) for b in range(4))
        ok_t &= (lhs == -2 * ((c == e_) * (d == f_) - (c == f_) * (d == e_)))
    chk('std', ok_c and ok_t, 'frame-index identities: (*F)_ab = (1/2) eps_abcd F^cd for %d random F, and eps_abcd eps^abef = -2 (delta^e_c delta^f_d - delta^f_c delta^e_d) (Lorentz: eps^0123 = -1)' % nrand)
    ok_s = True; ok_p = True; ok_ctl_id = False; ok_ctl_sg = True
    for _ in range(nrand):
        Fl = {(a, b): rnd() for a in range(4) for b in range(a + 1, 4)}
        Tb = maxwell_T_bit(bivector(Fl, sq), sq); Ts = maxwell_T_std(Fl, sq); ok_s &= (Tb == Ts)
        E2 = sum(Fl[(0, i)] ** 2 for i in (1, 2, 3)); B2 = sum(Fl[(i, j)] ** 2 for i in (1, 2, 3) for j in (1, 2, 3) if i < j)
        ok_p &= (Tb[0][0] == (E2 + B2) / 2 and sum(Tb[a][a] for a in range(4)) == 0 and all(sq[a] * Tb[a][b] == sq[b] * Tb[b][a] for a in range(4) for b in range(4)))
        ok_ctl_id |= (maxwell_T_bit(bivector(Fl, sq, 'lower'), sq) != Ts)
        ok_ctl_sg &= (maxwell_T_bit(bivector(Fl, sq), sq, F(1, 2))[0][0] < 0)
    chk('bit==std', ok_s, 'Maxwell stress: -1/2 F gamma_a F (bit rule) = -F^{ac} F_{bc} + 1/4 delta F^2 (components), all 16 entries, %d random F with electric and magnetic parts' % nrand)
    chk('bit', ok_p, 'the stress is symmetric (T_ab = T_ba), traceless, and T^0_0 = (E^2 + B^2)/2 > 0 on every sample')
    chk('ctl', ok_ctl_id, 'control: the bivector built from lower components on the lower basis (sum F_ab gamma_a gamma_b) gives a different stress (the Poynting part changes sign)')
    chk('ctl', ok_ctl_sg, 'control: +1/2 F a F gives a negative energy density T^0_0 on every sample')
    ok_sc = True; ok_sp = True; ok_sh = False
    for _ in range(nrand):
        dphi = [rnd() for _ in range(4)]; phi = rnd(); m2 = abs(rnd())
        Tb = scalar_T_bit(dphi, phi, m2, sq); Ts = scalar_T_std(dphi, phi, m2, sq); ok_sc &= (Tb == Ts)
        ok_sp &= (Tb[0][0] == (sum(x * x for x in dphi) + m2 * phi * phi) / 2)
        ok_sh |= (scalar_T_bit(dphi, phi, m2, sq, F(1)) != Ts)
    chk('bit==std', ok_sc, 'scalar stress: 1/2 (grad phi) gamma_a (grad phi) + 1/2 m^2 phi^2 gamma_a = d^a phi d_b phi - delta (1/2 (d phi)^2 - 1/2 m^2 phi^2), %d random samples' % nrand)
    chk('bit', ok_sp, 'scalar energy density T^0_0 = (sum_a (d_a phi)^2 + m^2 phi^2)/2 >= 0')
    chk('ctl', ok_sh, 'control: the scalar stress without the factor 1/2 in front of (grad phi) a (grad phi) differs from the component formula')
    p = (F(2), F(3), F(6)); r0 = F(7)
    rm = rho_pow_jet(p, r0, -1, 3); rp = rho_pow_jet(p, r0, 1, 3); r2 = rho_pow_jet(p, r0, 2, 3)
    rho2 = lin((r0 ** 2, one), *[(2 * p[j], var(n, j + 1)) for j in range(3)], *[(F(1), sp_mul(var(n, j + 1), var(n, j + 1), 3, n)) for j in range(3)])
    chk('std', sp_mul(rm, rp, 3, n) == one and r2 == rho2 and sp_mul(rp, rp, 3, n) == rho2, 'jets: rho^-1 rho^1 = 1 and (rho^1)^2 = rho^2 = |p + delta|^2 exactly to degree 3 at p = (2, 3, 6)')

if __name__ == '__main__':
    from b1lib import chk, head, finish
    head('g2_hodge self-test'); selftest(chk); finish('g2_hodge')
