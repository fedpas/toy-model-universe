#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A1. Reduction lemmas: the finite hypotheses of the lemma chain checked exhaustively, the identities as a regression guard.
   python3 a1_lemmas.py [--quick]        (--quick: n <= 6 for the exhaustive algebra parts, n <= 4 for the field identities)
 Part 1  [std] word rule for the sign of the bit-rule product == engine bmul, all pairs n <= 8 (Lorentz), all sq in {-1,0,1}^n, n <= 4   (L1)
 Part 2  [bit] associativity on all triples of masks (numpy), n <= 8 Lorentz, all sq at n <= 5, other patterns; graded commutativity (L2, L3); [ctl] one sign flipped
 Part 3  [bit] the Lie tables: Jacobi of f, the representation property, the derivation lemma, tracelessness, epsilon invariance (L4, L7); [ctl] flips, non-zero trace
 Part 4  [bit] d d = 0 and the graded Leibniz rule on monomial forms; [bit==std] engine d == textbook d (L5); [ctl] wrong Leibniz sign, d from the right
 Part 5  [bit] the engine's identities (regression guard) and the D E_a derivation chain step by step; [ctl] 1/3 and 1/2 in R, wrong sign in D(e...e)"""
import sys, os, time, itertools, random
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1'); os.environ.setdefault('OMP_NUM_THREADS', '1')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
from fractions import Fraction as F

QUICK = '--quick' in sys.argv
def T0(): return time.time()
def tline(part, t): print('  time %s: %.1f s' % (part, time.time() - t), flush=True)
def patterns(n): return [list(p) for p in itertools.product((-1, 0, 1), repeat=n)]
def lor(n): return [1] + [-1] * (n - 1)

# ------------------------------------------------------------------------------------------------ Part 1: the sign of the product (L1)
def std_sign(a, b, sq):
    """[std] word rule: concatenate the sorted generator words of a and b, bubble-sort by adjacent swaps (a swap of two different generators gives -1),
    contract two equal neighbours to the square sq_i.  No bit arithmetic, no crossing count."""
    word = [i for i in range(len(sq)) if a >> i & 1] + [i for i in range(len(sq)) if b >> i & 1]; s = 1; changed = True
    while changed:
        changed = False
        for k in range(len(word) - 1):
            if word[k] > word[k + 1]: word[k], word[k + 1] = word[k + 1], word[k]; s = -s; changed = True
            elif word[k] == word[k + 1]: s *= sq[word[k]]; del word[k:k + 2]; changed = True; break
    return sum(1 << i for i in word), s
def closed_sign(a, b, sq):
    """L1 as a formula: (-1)^cross(a,b) prod_{i in a&b} sq_i, cross = #{(i, j): i in a, j in b, i > j}"""
    cross = sum(1 for i in range(len(sq)) for j in range(len(sq)) if (a >> i & 1) and (b >> j & 1) and i > j); s = (-1) ** cross
    for i in range(len(sq)):
        if (a & b) >> i & 1: s *= sq[i]
    return a ^ b, s
def part1():
    head('Part 1 [L1] the sign of the bit-rule product: word rule [std] == engine bmul == closed formula'); t = T0()
    for n in range(1, 9):
        if QUICK and n > 6: break
        sq = lor(n); N = 1 << n; bad = sum(1 for a in range(N) for b in range(N) if bmul(a, b, sq) != std_sign(a, b, sq))
        chk('bit==std', bad == 0, 'n = %d Lorentz: engine bmul == word rule on all %d pairs of masks' % (n, N * N))
    for n in range(1, 5):
        pats = patterns(n); N = 1 << n
        bad = sum(1 for sq in pats for a in range(N) for b in range(N) if bmul(a, b, sq) != std_sign(a, b, sq))
        bad2 = sum(1 for sq in pats for a in range(N) for b in range(N) if bmul(a, b, sq) != closed_sign(a, b, sq))
        chk('bit==std', bad == 0, 'n = %d, all %d sign patterns in {-1,0,1}^n: engine == word rule on all pairs' % (n, len(pats)))
        chk('bit', bad2 == 0, 'n = %d, all sign patterns: engine == closed formula (-1)^cross prod sq' % n)
    tline('part 1', t)

# ------------------------------------------------------------------------------------------------ Part 2: associativity and graded commutativity (L2, L3)
def sign_table(n, sq):
    N = 1 << n; S = np.zeros((N, N), dtype=np.int8); X = np.zeros((N, N), dtype=np.int64)
    for a in range(N):
        for b in range(N): m, s = bmul(a, b, sq); S[a, b] = s; X[a, b] = m
    return S, X
def assoc_bad(S, X):
    """number of triples (a, b, c) with (ab)c != a(bc): sign and mask"""
    L = S[:, :, None].astype(np.int16) * S[X, :]; R = S[None, :, :].astype(np.int16) * S[:, X]
    return int(np.count_nonzero(L != R)) + int(np.count_nonzero(X[X, :] != X[:, X]))
def part2():
    head('Part 2 [L2, L3] associativity on all triples of masks; graded commutativity on disjoint masks'); t = T0()
    for n in range(1, 9):
        if QUICK and n > 6: break
        S, X = sign_table(n, lor(n)); N = 1 << n
        chk('bit', assoc_bad(S, X) == 0, 'n = %d Lorentz: (ab)c == a(bc) on all %d triples' % (n, N ** 3))
    for n in range(1, 6):
        pats = patterns(n); bad = 0
        for sq in pats:
            S, X = sign_table(n, sq); bad += assoc_bad(S, X)
        chk('bit', bad == 0, 'n = %d, all %d sign patterns in {-1,0,1}^n: associative on all triples' % (n, len(pats)))
    others = {'euclid': lambda n: [1] * n, 'anti-euclid': lambda n: [-1] * n, 'split': lambda n: [1, -1] * (n // 2) + [1] * (n % 2),
              'one null (last)': lambda n: lor(n)[:-1] + [0], 'one null (first)': lambda n: [0] + lor(n)[1:]}
    for name, fn in others.items():
        for n in (6, 7):
            if QUICK and n > 6: break
            S, X = sign_table(n, fn(n)); chk('bit', assoc_bad(S, X) == 0, 'n = %d, sq = %s: associative on all triples' % (n, name))
    # graded commutativity on disjoint masks (null and Lorentz squares; disjoint masks never see a square)
    for n in range(1, 9):
        sq0 = [0] * n; sq = lor(n); N = 1 << n; bad = 0
        for a in range(N):
            for b in range(N):
                if a & b: continue
                for s_ in (sq0, sq):
                    m1, s1 = bmul(a, b, s_); m2, s2 = bmul(b, a, s_)
                    if s1 != (-1) ** (popc(a) * popc(b)) * s2: bad += 1
        chk('bit', bad == 0, 'n = %d: ab = (-1)^(|a||b|) ba on all disjoint pairs (null and Lorentz squares)' % n)
    # control: one sign flipped in the table breaks associativity (n = 3, every single flip of an off-diagonal non-zero entry)
    S, X = sign_table(3, lor(3)); flips_seen = 0; flips = 0
    for a in range(1, 8):
        for b in range(1, 8):
            S2 = S.copy(); S2[a, b] = -S2[a, b]; flips += 1
            if assoc_bad(S2, X) > 0: flips_seen += 1
    chk('ctl', flips_seen == flips, 'n = 3: every one of the %d single sign flips (a, b != 0) breaks associativity (%d seen)' % (flips, flips_seen))
    tline('part 2', t)

# ------------------------------------------------------------------------------------------------ Part 3: the tables (L4, L7)
def jacobi_bad(L_):
    bad = 0
    for A in range(L_.G):
        for B in range(L_.G):
            for C in range(L_.G):
                tot = {}
                for (X, Y, Z) in ((A, B, C), (B, C, A), (C, A, B)):
                    if (X, Y) in L_.f:
                        D, f1 = L_.f[(X, Y)]
                        if (D, Z) in L_.f: E, f2 = L_.f[(D, Z)]; tot[E] = tot.get(E, 0) + f1 * f2
                if any(v != 0 for v in tot.values()): bad += 1
    return bad
def rep_bad(L_):
    """f_AB^C h_Cb^d == 2 (h_Bb^c h_Ac^d - h_Ab^c h_Bc^d): the vector table is a representation of the bivector table"""
    bad = 0
    for A in range(L_.G):
        for B in range(L_.G):
            for b in range(L_.N):
                lhs = {}; rhs = {}
                if (A, B) in L_.f:
                    C, f = L_.f[(A, B)]
                    if (C, b) in L_.h: d, h = L_.h[(C, b)]; lhs[d] = lhs.get(d, 0) + f * h
                if (B, b) in L_.h:
                    c, h1 = L_.h[(B, b)]
                    if (A, c) in L_.h: d, h2 = L_.h[(A, c)]; rhs[d] = rhs.get(d, 0) + 2 * h1 * h2
                if (A, b) in L_.h:
                    c, h1 = L_.h[(A, b)]
                    if (B, c) in L_.h: d, h2 = L_.h[(B, c)]; rhs[d] = rhs.get(d, 0) - 2 * h1 * h2
                if any(lhs.get(k, 0) != rhs.get(k, 0) for k in set(lhs) | set(rhs)): bad += 1
    return bad
def deriv_bad(L_):
    """(1/2) f_AB^C B_C (table) == (1/2)[B_A, gamma_b gamma_c] (Clifford product) == h_Ab^d gamma_d gamma_c + h_Ac^d gamma_b gamma_d, B_B = gamma_b gamma_c"""
    bad = 0; sq = L_.sq
    for A, gA in enumerate(L_.gens):
        for B, gB in enumerate(L_.gens):
            b, c = [i for i in range(L_.N) if gB >> i & 1]
            tab = {}
            if (A, B) in L_.f: C, f = L_.f[(A, B)]; tab[L_.gens[C]] = F(f, 2)
            m1, s1 = bmul(gA, gB, sq); m2, s2 = bmul(gB, gA, sq); cl = {m1: F(s1 - s2, 2)} if s1 != s2 else {}
            rhs = {}
            if (A, b) in L_.h:
                d, h = L_.h[(A, b)]; m, s = bmul(1 << d, 1 << c, sq)
                if s: rhs[m] = rhs.get(m, 0) + h * s
            if (A, c) in L_.h:
                d, h = L_.h[(A, c)]; m, s = bmul(1 << b, 1 << d, sq)
                if s: rhs[m] = rhs.get(m, 0) + h * s
            rhs = {k: v for k, v in rhs.items() if v}
            if tab != cl or cl != rhs: bad += 1
    return bad
def eps_sign(seq):
    s = 1
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] == seq[j]: return 0
            if seq[i] > seq[j]: s = -s
    return s
def eps_action(M, idx, n):
    """sum over the n slots of (M acting on that slot): sum_s sum_j M[j][i_s] eps(i_1 .. j .. i_n)"""
    tot = 0
    for s in range(n):
        for j in range(n):
            m = M[j][idx[s]]
            if m: seq = list(idx); seq[s] = j; tot += m * eps_sign(seq)
    return tot
def h_matrix(L_, A):
    M = [[0] * L_.N for _ in range(L_.N)]
    for (A_, b), (c, h) in L_.h.items():
        if A_ == A: M[c][b] = h
    return M
def part3():
    head('Part 3 [L4, L7] the Lie tables: Jacobi, representation property, derivation lemma, tracelessness, epsilon invariance'); t = T0()
    pats_by_n = {n: patterns(n) for n in range(2, 5)}
    for n in range(2, 9):
        if QUICK and n > 6: break
        L_ = Lie(lor(n))
        chk('bit', jacobi_bad(L_) == 0, 'n = %d Lorentz: Jacobi for f on all %d triples of bivector labels' % (n, L_.G ** 3))
        chk('bit', rep_bad(L_) == 0, 'n = %d Lorentz: representation property f h = 2(hh - hh) on all (A, B, b)' % n)
        chk('bit', deriv_bad(L_) == 0, 'n = %d Lorentz: derivation lemma (1/2)[B_A, gamma_b gamma_c] = h gamma gamma + gamma h gamma, table == Clifford == h-form' % n)
        chk('bit', all(c != b for (A, b), (c, h) in L_.h.items()), 'n = %d Lorentz: tracelessness, no h entry maps gamma_b to itself' % n)
    for n in range(2, 5):
        bad = [0, 0, 0]
        for sq in pats_by_n[n]:
            L_ = Lie(sq); bad[0] += jacobi_bad(L_); bad[1] += rep_bad(L_); bad[2] += deriv_bad(L_)
        chk('bit', bad == [0, 0, 0], 'n = %d, all %d sign patterns: Jacobi, representation property, derivation lemma' % (n, len(pats_by_n[n])))
    for name, fn in {'euclid': lambda n: [1] * n, 'split': lambda n: [1, -1] * (n // 2) + [1] * (n % 2), 'one null': lambda n: lor(n)[:-1] + [0]}.items():
        for n in (5, 6, 7, 8):
            if QUICK and n > 6: break
            L_ = Lie(fn(n)); chk('bit', jacobi_bad(L_) + rep_bad(L_) + deriv_bad(L_) == 0, 'n = %d, sq = %s: Jacobi, representation, derivation lemma' % (n, name))
    # epsilon invariance under the vector representation of every bivector (L7)
    rng = random.Random(7)
    for n in range(2, 9):
        if QUICK and n > 6: break
        L_ = Lie(lor(n)); mats = [h_matrix(L_, A) for A in range(L_.G)]
        if n <= 5: tuples = list(itertools.product(range(n), repeat=n)); what = 'all %d index tuples' % len(tuples)
        elif n == 6: tuples = list(itertools.permutations(range(n))); what = 'all %d permutations' % len(tuples)
        else: tuples = [tuple(rng.sample(range(n), n)) for _ in range(60)]; what = '60 random permutations'
        bad = sum(1 for M in mats for idx in tuples if eps_action(M, idx, n) != 0)
        chk('bit', bad == 0, 'n = %d: sum over slots of (h_A acting on epsilon) = 0 for every bivector A, %s' % (n, what))
    # [std] the general identity sum_slots (M . eps) = tr(M) eps for any matrix, and the control tr != 0
    for n in range(2, 6):
        M = [[rng.randint(-3, 3) for _ in range(n)] for _ in range(n)]; tr = sum(M[i][i] for i in range(n))
        tuples = list(itertools.product(range(n), repeat=n)) if n <= 4 else [tuple(rng.randrange(n) for _ in range(n)) for _ in range(300)]
        bad = sum(1 for idx in tuples if eps_action(M, idx, n) != tr * eps_sign(idx))
        chk('std', bad == 0, 'n = %d: sum over slots of (M acting on epsilon) == tr(M) epsilon for a random integer matrix (tr = %d)' % (n, tr))
        I = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        chk('ctl', eps_action(I, tuple(range(n)), n) == n != 0, 'n = %d: a matrix with non-zero trace (identity) does not leave epsilon invariant (sum = n)' % n)
    # controls: one f entry flipped (one ordered pair) breaks Jacobi; one h entry flipped breaks representation property and derivation lemma
    for n in (3, 4):
        L_ = Lie(lor(n)); (A, B) = sorted(L_.f)[0]; C, f = L_.f[(A, B)]; L_.f[(A, B)] = (C, -f)
        chk('ctl', jacobi_bad(L_) > 0, 'n = %d: one f entry flipped (ordered pair %s only) breaks Jacobi' % (n, (A, B)))
        L_ = Lie(lor(n)); k = sorted(L_.h)[3]; c, h = L_.h[k]; L_.h[k] = (c, -h)
        chk('ctl', rep_bad(L_) > 0 and deriv_bad(L_) > 0, 'n = %d: one h entry flipped (%s) breaks the representation property and the derivation lemma' % (n, k))
    tline('part 3', t)

# ------------------------------------------------------------------------------------------------ Part 4: d (L5)
def std_d(X, n):
    """[std] textbook d(f dx^I) = sum_mu (d_mu f) dx^mu ^ dx^I, with dx^mu ^ dx^I = (-1)^{#(i in I: i < mu)} dx^{I + mu}"""
    r = {}
    for mask, p in X.items():
        for mu in range(n):
            if mask >> mu & 1: continue
            dp = pder(p, mu)
            if not dp: continue
            s = -1 if popc(mask & ((1 << mu) - 1)) % 2 else 1; m = mask | (1 << mu); x = padd(r.get(m, {}), dp, s)
            if x: r[m] = x
            else: r.pop(m, None)
    return r
def d_right(Fm, X):
    """a wrong d: dx^mu multiplied from the right"""
    r = {}
    for a, p in X.items():
        for mu in range(Fm.n):
            dp = pder(p, mu)
            if not dp: continue
            m, s = bmul(a, 1 << mu, Fm.sq0)
            if s == 0: continue
            x = padd(r.get(m, {}), dp, s)
            if x: r[m] = x
            else: r.pop(m, None)
    return r
def monomial_forms(n, deg):
    mons = [ex for ex in itertools.product(range(deg + 1), repeat=n) if sum(ex) <= deg]
    return [(mask, {mask: {ex: F(1)}}) for mask in range(1 << n) for ex in mons]
def leibniz_bad(Fm, forms, dfun, sign=True):
    bad = 0
    for (ma, X) in forms:
        p = popc(ma)
        for (mb, Y) in forms:
            lhs = dfun(Fm.wedge(X, Y)); rhs = Fm.add(Fm.wedge(dfun(X), Y), Fm.wedge(X, dfun(Y)), (-1) ** p if sign else 1)
            if not gs.Gr_eq(lhs, rhs): bad += 1
    return bad
def part4():
    head('Part 4 [L5] d d = 0, graded Leibniz, engine d == textbook d'); t = T0()
    for n, deg in ((1, 4), (2, 3), (3, 3), (4, 3)):
        Fm = Forms(n); forms = monomial_forms(n, deg)
        chk('bit', all(not Fm.d(Fm.d(X)) for _, X in forms), 'n = %d: d d = 0 on all %d monomial forms x^alpha dx^I, |alpha| <= %d (d is linear: exhaustive to that degree)' % (n, len(forms), deg))
        chk('bit==std', all(gs.Gr_eq(Fm.d(X), std_d(X, n)) for _, X in forms), 'n = %d: engine d == textbook d on the same monomial forms' % n)
    for n, deg in ((2, 3), (3, 2), (4, 1)):
        Fm = Forms(n); forms = monomial_forms(n, deg)
        chk('bit', leibniz_bad(Fm, forms, Fm.d) == 0, 'n = %d: d(X Y) = dX Y + (-1)^p X dY on all %d pairs of monomial forms up to degree %d (bilinear: exhaustive to that degree)' % (n, len(forms) ** 2, deg))
    rng = random.Random(11)
    for n in (4, 5):
        Fm = Forms(n); bad = 0
        for _ in range(6):
            X = gs.rform(rng, n, rng.randint(0, n - 1), 2, .7); Y = gs.rform(rng, n, rng.randint(0, n - 1), 2, .7); p = max(popc(m) for m in X) if X else 0
            if any(popc(m) != p for m in X): continue
            if not gs.Gr_eq(Fm.d(Fm.wedge(X, Y)), Fm.add(Fm.wedge(Fm.d(X), Y), Fm.wedge(X, Fm.d(Y)), (-1) ** p)): bad += 1
            if Fm.d(Fm.d(X)) or Fm.d(Fm.d(Y)): bad += 1
            if not gs.Gr_eq(Fm.d(X), std_d(X, n)) or not gs.Gr_eq(Fm.d(Y), std_d(Y, n)): bad += 1
        chk('bit==std', bad == 0, 'n = %d: Leibniz, d d = 0 and engine d == textbook d on random forms with quadratic coefficients' % n)
    # mixed partials commute (the [std] fact behind d d = 0)
    bad = 0
    for _ in range(20):
        n = rng.randint(2, 5); p = gs.rpoly(rng, n, 3, .7); i, j = rng.randrange(n), rng.randrange(n)
        if pder(pder(p, i), j) != pder(pder(p, j), i): bad += 1
    chk('std', bad == 0, 'mixed partial derivatives of random polynomials commute (20 random cases, n = 2..5)')
    # controls
    Fm = Forms(3); forms = monomial_forms(3, 1)
    chk('ctl', leibniz_bad(Fm, forms, Fm.d, sign=False) > 0, 'n = 3: the Leibniz rule without the sign (-1)^p fails on some monomial pair')
    chk('ctl', leibniz_bad(Fm, forms, lambda X: d_right(Fm, X)) > 0, 'n = 3: a d with dx^mu on the right fails the graded Leibniz rule on some pair')
    chk('ctl', any(not gs.Gr_eq(d_right(Fm, X), std_d(X, 3)) for _, X in forms), 'n = 3: the d from the right differs from the textbook d')
    tline('part 4', t)

# ------------------------------------------------------------------------------------------------ Part 5: the identities and the D E_a chain
def my_curvature(Gv, om, q):
    Fm = Gv.Fm; R = [Fm.d(om[C]) for C in range(Gv.G)]
    for (A, B), (C, f) in Gv.L.f.items(): R[C] = Fm.add(R[C], Fm.wedge(om[A], om[B]), f * q)
    return R
def fields(n, seed, density=.5):
    rng = random.Random(seed); Gv = Grav(n)
    return Gv, [gs.rform(rng, n, 1, 1, density) for _ in range(Gv.G)], [gs.rform(rng, n, 1, 1, density) for _ in range(n)]
def de_chain(n, seed, c, tsign=lambda j: (-1) ** j):
    """the derivation of D E_a, step by step, on random fields.  Returns dict of booleans."""
    Gv, om, e = fields(n, seed); Fm, L_ = Gv.Fm, Gv.L; out = {}
    R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, c); DE = Gv.D_covector(om, E)
    pairs = list(itertools.combinations(range(n), 2)); lab = lambda b, cc: L_.idx[(1 << b) | (1 << cc)]
    Flist = [{} for _ in range(Gv.G)]
    for (b, cc) in pairs: Flist[lab(b, cc)] = F_[(b, cc)]
    DF = Gv.D_bivector(om, Flist)
    def assemble(DFuse):
        res = []
        for a in range(n):
            tot = {}
            for (b, cc) in pairs:
                if a in (b, cc): continue
                rest = [x for x in range(n) if x not in (a, b, cc)]; s = Gv.eps([a, b, cc] + rest)
                form = DFuse[(b, cc)]
                for d in rest: form = Fm.wedge(form, e[d])
                tot = Fm.add(tot, form, s)
                for j in range(len(rest)):
                    form = F_[(b, cc)]
                    for jj, d in enumerate(rest): form = Fm.wedge(form, T[d] if jj == j else e[d])
                    tot = Fm.add(tot, form, s * tsign(j))
            res.append(tot)
        return res
    out['i_epsilon_step'] = gs.lst_eq(DE, assemble({p: DF[lab(*p)] for p in pairs}))                       # (DE)_a = sum eps [DF e.. + F D(e..e)]
    out['ii_DR'] = all(gs.eqz(x) for x in Gv.D_bivector(om, R))                                                 # D R = 0
    Dee = Gv.D_bivector(om, [Fm.wedge(e[b], e[cc]) for (b, cc) in pairs])                                   # L.gens is in the order of combinations(range(n), 2)
    TeeT = {(b, cc): Fm.add(Fm.wedge(T[b], e[cc]), Fm.wedge(e[b], T[cc]), -1) for (b, cc) in pairs}
    out['ii_Dee'] = all(gs.Gr_eq(Dee[lab(b, cc)], TeeT[(b, cc)]) for (b, cc) in pairs)                         # D(e^b e^c) = T^b e^c - e^b T^c
    out['ii_DF'] = all(gs.Gr_eq(DF[lab(b, cc)], Fm.scale(TeeT[(b, cc)], c)) for (b, cc) in pairs)             # D F = c (T e - e T)
    rhs = Gv.einstein_rhs(e, T, R, c, F_)
    out['iii_rhs'] = gs.lst_eq(assemble({p: Fm.scale(TeeT[p], c) for p in pairs}), rhs)                        # assembled == engine's einstein_rhs
    out['DE_eq_rhs'] = gs.lst_eq(DE, rhs)
    return out
def part5():
    head('Part 5 the identities as a regression guard, and the D E_a chain step by step'); t = T0()
    ns = (2, 3, 4) if QUICK else (2, 3, 4, 5)
    for n in ns:
        for seed in ((31 * n,) if n == 5 else (31 * n, 101 + n)):
            try: ok = bool(gs.identities(n, seed)); msg = ''
            except AssertionError as ex: ok = False; msg = ' (%s)' % (ex,)
            chk('bit', ok, 'n = %d seed %d: engine identities (second Bianchi, first Bianchi, covariance, spinor commutator)%s' % (n, seed, msg))
    cases = [(3, 0), (3, 1), (4, 0), (4, 1)] + ([] if QUICK else [(5, 0), (5, 1)])
    for (n, c) in cases:
        try: ok = bool(gs.einstein_identities(n, 17 * n + c, F(c))); msg = ''
        except AssertionError as ex: ok = False; msg = ' (%s)' % (ex,)
        chk('bit', ok, 'n = %d c = %d: engine einstein_identities (D E_a = torsion terms)%s' % (n, c, msg))
    # D D X = (1/2)[R, X] for a vector-valued 1-form (X = e) and for a bivector-valued 0-form (X = lambda): the engine's first Bianchi and covariance are these
    for n in (3, 4):
        Gv, om, e = fields(n, 5 * n); Fm, L_ = Gv.Fm, Gv.L; R = Gv.curvature(om)
        DDe = Gv.D_vector(om, Gv.D_vector(om, e)); want = [{} for _ in range(n)]
        for (A, b), (cc, h) in L_.h.items(): want[cc] = Fm.add(want[cc], Fm.wedge(R[A], e[b]), h)
        chk('bit', gs.lst_eq(DDe, want), 'n = %d: D D e = (1/2)[R, e] (= h R^A e^b) on a random field, with R from the engine' % n)
        R3 = my_curvature(Gv, om, F(1, 3)); want3 = [{} for _ in range(n)]
        for (A, b), (cc, h) in L_.h.items(): want3[cc] = Fm.add(want3[cc], Fm.wedge(R3[A], e[b]), h)
        chk('ctl', not gs.lst_eq(DDe, want3), 'n = %d: with 1/3 instead of 1/4 in R the first Bianchi identity fails' % n)
    for n in (3, 4):
        Gv, om, e = fields(n, 9 * n)
        for q, lab_ in ((F(1, 4), 'bit'), (F(1, 3), 'ctl'), (F(1, 2), 'ctl')):
            Rq = my_curvature(Gv, om, q); zero = all(gs.eqz(x) for x in Gv.D_bivector(om, Rq))
            if lab_ == 'bit': chk('bit', zero and gs.lst_eq(Rq, Gv.curvature(om)), 'n = %d: D R = 0 with the coefficient 1/4 (my curvature == engine curvature)' % n)
            else: chk('ctl', not zero, 'n = %d: D R != 0 with the coefficient %s instead of 1/4' % (n, q))
    for (n, c) in ([(3, 0), (3, 1), (4, 0), (4, 1)] + ([] if QUICK else [(5, 1)])):
        out = de_chain(n, 23 * n + c, F(c))
        for k, v in out.items(): chk('bit', v, 'n = %d c = %d: D E_a chain step %s' % (n, c, k))
    # controls on the sign (-1)^j of the torsion slot in D(e^{d1} ... e^{dk}), k = n - 3: at n = 4 there is one slot (j = 0 only), so only an overall
    # flip is visible there; the alternation is first probed at n = 5 (two slots)
    out = de_chain(4, 99, F(1), tsign=lambda j: -(-1) ** j)
    chk('ctl', not out['i_epsilon_step'] and not out['iii_rhs'], 'n = 4: the chain with the torsion term flipped, -(-1)^j, fails')
    out = de_chain(4, 99, F(1), tsign=lambda j: 1)
    chk('bit', out['i_epsilon_step'] and out['iii_rhs'], 'n = 4: with (+1)^j in place of (-1)^j nothing changes (one slot: the alternation is not probed at n = 4)')
    if not QUICK:
        out = de_chain(5, 98, F(1), tsign=lambda j: 1)
        chk('ctl', not out['i_epsilon_step'] and not out['iii_rhs'], 'n = 5: the chain with (+1)^j instead of (-1)^j in D(e...e) fails (two slots)')
        out = de_chain(5, 98, F(1), tsign=lambda j: -(-1) ** j)
        chk('ctl', not out['i_epsilon_step'] and not out['iii_rhs'], 'n = 5: the chain with -(-1)^j fails')
    tline('part 5', t)

if __name__ == '__main__':
    print('A1 reduction lemmas%s' % (' (--quick)' if QUICK else '')); t_all = T0()
    part1(); part2(); part3(); part4(); part5()
    tline('total', t_all); finish('A1')
