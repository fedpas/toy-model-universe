#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A5-strong.  Local Lorentz covariance of the Einstein form for every map type of a5_lorentz_covariance.py on strong random data, with a failure bound
 per map type and n.

   python3 a5_strong_maps.py [n ...] [--R=5000]      (default n = 3 4; the calibration runs with n = 3)

 Statement: e' = Lambda e with Lambda(x) in O(1, n-1) a 2-jet of each type below, omega' the engine's closed-form connection of e' (A3, recomputed):
   E_a(e') = det(Lambda) (Lambda^-1)^b_a E_b(e) (c = 0 and 1/3);  R'^{bc} = Lambda^b_d Lambda^c_f R^{df} at the point;
   W(e') = Lambda W Lambda^-1 - dLambda Lambda^-1 (W^c_b = h_Ab^c omega^A, read through D_vector; first-order jets);
   the coordinate tensor G - Lambda_n delta read off E (A4) is the same for e and e'.
 Data: every sampled coefficient uniform on a set of 2R + 1 values (R = 5000: point mass p = 1/10001):
   frame e       a2b_strong_sampling.s_frame: x-degree 2, integers in {-R..R}, det e(0) != 0 by rejection;
   Cayley        X = eta A, A = s_antisym (x-degree 2), redrawn until X(0) != 0 and det(1 - X(0)) != 0; Lambda = (1 + X)(1 - X)^-1 (A5's cayley_jet);
   rotor         U = prod over the n(n-1)/2 planes (1 + beta_k gamma_a gamma_b), Lambda gamma_b = U gamma_b U~ / (U U~) by the bit rule (A5's
                 rotor_lambda_jet); beta_k of x-degree 2, integer coefficients in {-R..R}, except the constant of a boost plane (0, b): k/(R+1),
                 |k| <= R, so |beta(0)| < 1 and U U~(0) > 0;
   rotor U U~ < 0  the same with the constant of the plane (0, 1) from the 2R + 1 integers 2 <= |j|, -(R+1) <= j <= R+2: U U~(0) < 0, det +1;
   P, T, PT      diag(1,-1,1..), diag(-1,1,..), diag(-1,-1,1..) times the Cayley map and times the rotor map.
 Bound: a false law whose residual is a non-zero polynomial of degree <= D in the sampled coefficients (denominators cleared) passes one frame with
   probability <= D p / (1 - r p) (Schwartz-Zippel, recalled: only the size 2R + 1 of each value set enters), three frames <= its cube.
   Counts (A2, a2b_strong_sampling): det(e0)^4 E(e) has degree 5n - 3 in the 2-jet of e, det(e0)^4 R(0) degree 4n, det(e0)^3 times the 1-jet of omega
   degree 3n; det Lambda(0) = +-1 and det(Lambda e)(0) = +-det e(0), so the frame denominators agree on both sides.  The 2-jet coefficients of Lambda e:
   Cayley (3n + 1)/det(1 - X0)^3 (a2b); rotor: a plane map has entries (degree 2 in beta_k)/(1 -+ beta_k^2) and its j-th derivative (degree j + 2)/
   (1 -+ beta_k^2)^(j+1), so over N0^3 (N0 = (U U~)(0)) every coefficient has degree <= 6 in each plane's coefficients and 1 in e: 3n(n - 1) + 1.
   So D = (5n - 3) q (E law), 4n q (R law), 3n q (connection law) with q = 3n + 1 (Cayley types) or 3n(n - 1) + 1 (rotor types); reflections add
   nothing; r = 2n + 1 (Cayley: the frame and det(1 - X0)) or n (rotor: the frame only).  The coordinate tensor is read linearly and invertibly from
   E at the point (E_a = -M^b_a Theta_b, Theta_b a basis), so its equality is equivalent to the E law there and carries the E-law bound.
 [bit]  A5's engine route unchanged (engine_all: A3 closed form, R = d omega + 1/4 [omega, omega], E_a, D_vector); rotor jets by the bit rule.
 [std]  A5's own polynomial code: Lambda^T eta Lambda = eta as 2-jets; the metric of Lambda e equals the metric of e; the Christoffel spin connection of
        Lambda e equals the textbook gauge law of that of e; the permutation-symbol identity eps L..L = det(L) eps (exact fractions, Leibniz formula: strong
        Lambda(0) is badly conditioned in floats); A4's standard Einstein tensor.  Not here: A5's float route (numeric_einstein).
 Controls (A5's, counted per map type where visible): old omega with the rotated frame; a Euclidean rotation; det -1 without det(Lambda); Lambda cut to
   its 1-jet; the connection law without -dLambda Lambda^-1; the vector law in place of the covector law.  Calibration at n = 3: the vector law and the
   connection law without its inhomogeneous term on 20 strong frames, one Cayley and one rotor map each.
 Scope: n = 3, 4 (three frames each, one frame per seed, all nine map types on it), origin of the jets, exact fractions, fixed seeds.  The bound is a
   statement about the sampling; a pass adds no physics."""
import sys, os, time, itertools, random, functools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
from fractions import Fraction as F
from decimal import Decimal, Context, ROUND_CEILING
import a5_lorentz_covariance as A5
import a2b_strong_sampling as AB

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
ARGV = sys.argv[1:]
RR = next((int(a.split('=', 1)[1]) for a in ARGV if a.startswith('--R=')), 5000)
NS = [int(a) for a in ARGV if a.isdigit()] or [3, 4]
NFR = 3                                                                        # frames (seeds) per n
TYPES = ['Cayley', 'rotor', 'rotor U U~ < 0', 'P x Cayley', 'T x Cayley', 'PT x Cayley', 'P x rotor', 'T x rotor', 'PT x rotor']
REFL = {'P': lambda n: [1, -1] + [1] * (n - 2), 'T': lambda n: [-1, 1] + [1] * (n - 2), 'PT': lambda n: [-1, -1] + [1] * (n - 2)}

# ------------------------------------------------------------------------------------------------ degrees and the bound
def family(t): return 'Cayley' if 'Cayley' in t else 'rotor'
def q_of(fam, n): return 3 * n + 1 if fam == 'Cayley' else 3 * n * (n - 1) + 1
def D_of(fam, n, law): return {'E': 5 * n - 3, 'R': 4 * n, 'W': 3 * n}[law] * q_of(fam, n)
def r_of(fam, n): return 2 * n + 1 if fam == 'Cayley' else n
def bound(D, R, r): p = F(1, 2 * R + 1); return D * p / (1 - r * p)
def up(x, d=3):
    """the Fraction x printed with d significant digits, never below its exact value"""
    return '%.*e' % (d - 1, float(Context(prec=d, rounding=ROUND_CEILING).divide(Decimal(x.numerator), Decimal(x.denominator))))
BOUND = {}                                                                     # (type, n, law, R) -> dict(D, r, N)
LAWS = {'E': 'E law and coordinate tensor', 'R': 'R law', 'W': 'connection law'}

# ------------------------------------------------------------------------------------------------ strong maps
def s_cayley(rng, n, sq, R, euclid=False):
    """Cayley transform of X = eta A (euclid: X = A, an ordinary rotation, a control), A a strong antisymmetric 2-jet; redrawn until X(0) != 0 and
    det(1 - X(0)) != 0 (the rule of a2b_strong_sampling.a5_case).  Returns (Lambda jet, X)."""
    while True:
        A = AB.s_antisym(rng, n, 2, R); X = A if euclid else [[scale(A[i][j], sq[i]) for j in range(n)] for i in range(n)]; X0 = A5.jmat_at0(X, n)
        if any(X0[i][j] for i in range(n) for j in range(n)) and det_inv([[F(int(i == j)) - X0[i][j] for j in range(n)] for i in range(n)])[0] != 0:
            return A5.cayley_jet(X, n, 2), X
def big_values(R): return [F(j) for j in range(-(R + 1), R + 3) if abs(j) >= 2]          # 2R + 1 values with |beta(0)| > 1
def s_betas(rng, n, R, pt=False, deg=2):
    """beta_k(x) of x-degree deg for every plane (a, b): integer coefficients in {-R..R} (a2b's s_poly); the constant of a boost plane (0, b) from
    {k/(R+1): |k| <= R} (U U~ > 0); pt: the constant of the plane (0, 1) from big_values(R) (U U~ < 0).  Every value set has 2R + 1 elements."""
    out = []; z = (0,) * n
    for (a, b) in itertools.combinations(range(n), 2):
        p = dict(AB.s_poly(rng, n, deg, R))
        if a == 0:
            c0 = rng.choice(big_values(R)) if (pt and b == 1) else F(rng.randint(-R, R), R + 1); p.pop(z, None)
            if c0: p[z] = c0
        out.append(((a, b), p))
    return out
def eps_exact(L0, n):
    """[std] exact fractions, no engine: sum_a eps_{a1..an} L^a1_b1 .. L^an_bn = det(L) eps_{b1..bn} for every permutation b (det by the Leibniz formula;
    for repeated b both sides vanish by antisymmetry).  Returns (holds, det)."""
    perms = list(itertools.permutations(range(n))); sg = {p: A5.perm_sgn(p) for p in perms}
    prod = lambda xs: functools.reduce(lambda u, v: u * v, xs, F(1))
    det = sum(sg[p] * prod(L0[p[i]][i] for i in range(n)) for p in perms)
    return all(sum(sg[a] * prod(L0[a[i]][b[i]] for i in range(n)) for a in perms) == det * sg[b] for b in perms), det

# ------------------------------------------------------------------------------------------------ one n
def run_n(n, R, N=NFR):
    sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); cs = [F(0), F(1, 3)]; Lam = lambda c: c * F((n - 1) * (n - 2), 2)
    head('n = %d: %d strong frames (x-degree 2, coefficients uniform in -%d..%d), nine map types on each (2-jets), c in {0, 1/3}' % (n, N, R, R))
    st = {k: True for k in ('lorentz', 'nonconst', 'eps', 'metric', 'stdlaw', 'grades', 'orient', 'nonvac', 'jet3')}
    law = {t: dict(E=0, R=0, W=0, coord=0, coord_std=0) for t in TYPES}; ctl = {}; comps = set()
    def cnt(t, name, differs): d = ctl.setdefault((t, name), [0, 0]); d[0] += int(differs); d[1] += 1
    for seed in AB.seeds_for('A5S', n, N, R % 7):
        t1 = time.time(); rng = random.Random(seed); e = AB.s_frame(rng, n, 2, R)
        base = A5.engine_all(Gv, e, S, n, cs); oms = A5.std_spin_connection(e, n, sq)
        g = std_metric(e, n, sq, n, 2); R1, g0, g0i = std_riemann(g, n, n, 1); Gm = std_einstein_mixed(R1, g0, g0i, n)[0]
        st['nonvac'] &= any(v != 0 for v in base['comp'][F(0)].values())
        LC, XC = s_cayley(rng, n, sq, R)
        LU, gU, NU = A5.rotor_lambda_jet(s_betas(rng, n, R), n, sq); LV, gV, NV = A5.rotor_lambda_jet(s_betas(rng, n, R, pt=True), n, sq)
        st['grades'] &= gU and gV; st['orient'] &= NU > 0 and at0(LU[0][0], n) > 0 and NV < 0 and at0(LV[0][0], n) < 0
        maps = {'Cayley': LC, 'rotor': LU, 'rotor U U~ < 0': LV}
        for rn in ('P', 'T', 'PT'):
            dg = REFL[rn](n)
            for bn in ('Cayley', 'rotor'): maps['%s x %s' % (rn, bn)] = [[scale(maps[bn][a][b], dg[a]) for b in range(n)] for a in range(n)]
        for t in TYPES:
            L = maps[t]; L0 = A5.jmat_at0(L, n); d0 = det_inv(L0)[0]; Li0 = [[sq[d] * L0[b][d] * sq[b] for b in range(n)] for d in range(n)]
            st['lorentz'] &= A5.lorentz_defect(L, sq, n, 2) == [] and d0 in (1, -1); st['nonconst'] &= all(A5.nonconstant(L, n))
            comps.add((int(d0), 1 if L0[0][0] > 0 else -1)); okeps, dl = eps_exact(L0, n); st['eps'] &= okeps and dl == d0
            e2 = A5.rotate_frame(L, e, n, 2); g2 = std_metric(e2, n, sq, n, 2); st['metric'] &= all(A5.peq(g2[k], g[k]) for k in g)
            rot = A5.engine_all(Gv, e2, S, n, cs); gl = A5.transformed_connection(L, oms, sq, n)
            law[t]['W'] += A5.W_matches(rot['W'], gl, n); st['stdlaw'] &= A5.om_matches(A5.std_spin_connection(e2, n, sq), gl, n)
            cnt(t, 'c5 connection law without -dLambda Lambda^-1', not A5.W_matches(rot['W'], A5.transformed_connection(L, oms, sq, n, inhom=False), n))
            pr = A5.R_law(base['Rab'], L0, n); law[t]['R'] += all(rot['Rab'].get(k, 0) == v for k, v in pr.items())
            okE = okC = okS = True
            for c in cs:
                okE &= rot['comp'][c] == A5.E_law(base['comp'][c], L0, n, sq)
                Mc = A5.coord_tensor(rot['comp'][c], e2, n); okC &= Mc == A5.coord_tensor(base['comp'][c], e, n)
                okS &= all(Mc[m][v] == Gm[m][v] - (Lam(c) if m == v else 0) for m in range(n) for v in range(n))
                if any(L0[a][b] != Li0[b][a] for a in range(n) for b in range(n)):
                    cnt(t, 'c6 vector law in place of the covector law', rot['comp'][c] != A5.E_law(base['comp'][c], L0, n, sq, vector=True))
                if d0 == -1: cnt(t, 'c3 det -1 without det(Lambda)', rot['comp'][c] != A5.E_law(base['comp'][c], L0, n, sq, with_det=False))
                cnt(t, 'c1 old omega with the rotated frame', A5.engine_E_from_R(Gv, e2, base['R'], n, c) != A5.E_law(base['comp'][c], L0, n, sq))
            law[t]['E'] += okE; law[t]['coord'] += okC; law[t]['coord_std'] += okS
        L3 = A5.cayley_jet(XC, n, 3); r3 = A5.engine_all(Gv, A5.rotate_frame(L3, e, n, 3), S, n, cs)
        st['jet3'] &= all(r3['comp'][c] == A5.E_law(base['comp'][c], A5.jmat_at0(LC, n), n, sq) for c in cs) and A5.lorentz_defect(L3, sq, n, 3) == []
        for t in ('Cayley', 'rotor', 'rotor U U~ < 0'):
            L1j = [[A5.jtrunc(x, 1, n) for x in row] for row in maps[t]]; r1 = A5.engine_all(Gv, A5.rotate_frame(L1j, e, n, 2), S, n, cs)
            for c in cs: cnt(t, 'c4 Lambda cut to its 1-jet', r1['comp'][c] != A5.E_law(base['comp'][c], A5.jmat_at0(maps[t], n), n, sq))
        LE = s_cayley(rng, n, sq, R, euclid=True)[0]; rE = A5.engine_all(Gv, A5.rotate_frame(LE, e, n, 2), S, n, cs)
        for c in cs: cnt('Euclidean Cayley', 'c2 a Euclidean rotation', rE['comp'][c] != A5.E_law(base['comp'][c], A5.jmat_at0(LE, n), n, sq))
        dig = max(len(str(abs(x.denominator))) for row in A5.jmat_at0(LU, n) for x in row)
        print('    n = %d seed %d: frame, nine maps and the extras in %.1f s; rotor: U U~(0) = %s, %s; Lambda(0) denominators up to %d digits'
              % (n, seed, time.time() - t1, '+' if NU > 0 else '-', '-' if NV < 0 else '+', dig), flush=True)
    nl = len(TYPES) * N
    chk('std', st['lorentz'], 'n=%d: every Lambda (%d: nine types on %d frames) satisfies Lambda^T eta Lambda = eta exactly as a 2-jet, det Lambda(0) = +-1' % (n, nl, N))
    chk('std', st['nonconst'], 'n=%d: every Lambda has non-zero first AND second derivatives at the point' % n)
    chk('std', st['eps'], 'n=%d: exact: eps_{a..} Lambda^a_b .. = det(Lambda) eps_{b..} for every Lambda(0), det by the Leibniz formula = det by elimination' % n)
    chk('std', st['metric'], 'n=%d: the metric of Lambda e equals the metric of e as exact 2-jets, every Lambda' % n)
    chk('std', st['stdlaw'], 'n=%d: [std alone] the Christoffel spin connection of Lambda e equals Lambda omega Lambda^-1 - dLambda Lambda^-1 of e (first-order jets), every Lambda' % n)
    chk('bit', st['grades'], 'n=%d: rotor jets by the bit rule: U U~ is a pure scalar and every U gamma_b U~ a pure vector (both rotors, every frame)' % n)
    chk('bit', st['orient'], 'n=%d: U U~(0) > 0 gives Lambda^0_0(0) > 0; the boost constant |beta(0)| > 1 gives U U~(0) < 0 and Lambda^0_0(0) < 0 at det +1 (every frame)' % n)
    chk('bit', comps == {(1, 1), (1, -1), (-1, 1), (-1, -1)}, 'n=%d: all four components of O(1,n-1) sampled (det, sign Lambda^0_0) = %s' % (n, sorted(comps)))
    chk('bit', st['nonvac'], 'n=%d: E(e) is not zero for the frames used' % n)
    for t in TYPES:
        w = law[t]; fam = family(t)
        chk('bit', w['E'] == N and w['coord'] == N and w['R'] == N, 'n=%d %s: E_a(Lambda e) = det(Lambda) (Lambda^-1)^b_a E_b(e) at c = 0 and 1/3, R\'^{bc} = Lambda Lambda R and the coordinate tensor unchanged, on %d of %d frames' % (n, t, min(w['E'], w['coord'], w['R']), N))
        chk('bit==std', w['W'] == N and w['coord_std'] == N, 'n=%d %s: engine connection of Lambda e = Lambda omega_std Lambda^-1 - dLambda Lambda^-1 (every entry of the 1-jet) and coordinate tensor = standard G - Lambda_n delta, on %d of %d frames' % (n, t, min(w['W'], w['coord_std']), N))
        for lw in ('E', 'R', 'W'):
            BOUND[(t, n, lw, R)] = dict(D=D_of(fam, n, lw), r=r_of(fam, n), N=min(w['E'], w['coord']) if lw == 'E' else w[lw])
    chk('bit', st['jet3'], 'n=%d: the Cayley map as a 3-jet and the frame kept to degree 3 give the same E at the point: the 2-jet is enough' % n)
    for (t, name), (dif, seen) in sorted(ctl.items()):
        chk('ctl', dif == seen and seen > 0, 'n=%d %s: %s: differs on %d of %d samples' % (n, t, name, dif, seen))
    tick('n = %d' % n)

# ------------------------------------------------------------------------------------------------ calibration
def part_calib(R, N=20):
    n = 3; sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); cs = [F(0), F(1, 3)]
    head('Calibration [ctl] n = 3: %d strong frames, a Cayley and a rotor map on each: the vector law and the connection law without its inhomogeneous term '
         'must fail on every frame (where the vector law differs from the covector law at the point)' % N)
    miss = {}; seen = {}; true_fail = 0
    for seed in AB.seeds_for('A5S-CAL', n, N, R % 7):
        rng = random.Random(seed); e = AB.s_frame(rng, n, 2, R); base = A5.engine_all(Gv, e, S, n, cs); oms = A5.std_spin_connection(e, n, sq)
        LC = s_cayley(rng, n, sq, R)[0]; LU = A5.rotor_lambda_jet(s_betas(rng, n, R), n, sq)[0]
        for t, L in (('Cayley', LC), ('rotor', LU)):
            L0 = A5.jmat_at0(L, n); rot = A5.engine_all(Gv, A5.rotate_frame(L, e, n, 2), S, n, cs); Li0 = [[sq[d] * L0[b][d] * sq[b] for b in range(n)] for d in range(n)]
            true_fail += not all(rot['comp'][c] == A5.E_law(base['comp'][c], L0, n, sq) for c in cs) or not A5.W_matches(rot['W'], A5.transformed_connection(L, oms, sq, n), n)
            if any(L0[a][b] != Li0[b][a] for a in range(n) for b in range(n)):
                k = (t, 'the vector law', 'E'); seen[k] = seen.get(k, 0) + 1; miss[k] = miss.get(k, 0) + all(rot['comp'][c] == A5.E_law(base['comp'][c], L0, n, sq, vector=True) for c in cs)
            k = (t, 'the connection law without -dLambda Lambda^-1', 'W'); seen[k] = seen.get(k, 0) + 1
            miss[k] = miss.get(k, 0) + A5.W_matches(rot['W'], A5.transformed_connection(L, oms, sq, n, inhom=False), n)
    chk('bit', true_fail == 0, 'the true laws (E law at c = 0 and 1/3, connection law) hold on all %d frames for both maps' % N)
    for k in sorted(seen):
        t, name, lw = k; b = bound(D_of(t, n, lw), R, r_of(t, n))
        chk('ctl', seen[k] >= N - 2 and miss[k] == 0, 'n = 3 %s: %s is caught on every one of %d frames (missed %d; bound per frame %s)' % (t, name, seen[k], miss[k], up(b)))
    tick('calibration')

# ------------------------------------------------------------------------------------------------ the bound table
def part_table(R, ns):
    head('Bound table (R = %d, p = 1/%d): per frame D p / (1 - r p) and combined over the N frames that passed, per map type, law and n (exact; '
         'the printed values are not below the exact ones)' % (R, 2 * R + 1))
    print('  %-16s %2s %-28s %5s %3s %2s %10s %10s' % ('map type', 'n', 'law', 'D', 'r', 'N', 'per frame', 'combined'))
    worst = {}
    for (t, n, lw, R_), d in sorted(BOUND.items(), key=lambda kv: (kv[0][1], TYPES.index(kv[0][0]), kv[0][2])):
        b = bound(d['D'], R_, d['r']); cb = b ** d['N'] if d['N'] else F(1)
        print('  %-16s %2d %-28s %5d %3d %2d %10s %10s' % (t, n, LAWS[lw], d['D'], d['r'], d['N'], up(b), up(cb) if d['N'] else 'none'))
        key = (family(t), n); worst[key] = max(worst.get(key, F(0)), cb)
    chk('bit', all(d['N'] == NFR for d in BOUND.values()), 'every law passed on all %d frames for every map type and n' % NFR)
    chk('bit', all(bound(d['D'], k[3], d['r']) < 1 for k, d in BOUND.items()), 'every per-frame bound is below 1 at R = %d' % R)
    for n in ns:
        for fam in ('Cayley', 'rotor'):
            want = bound(D_of(fam, n, 'E'), R, r_of(fam, n)) ** NFR
            chk('bit', worst.get((fam, n)) == want, 'n = %d, %s maps (with P, T, PT%s): a false law would pass all %d frames with probability at most %s (the E law: D = %d, r = %d)'
                % (n, fam, ', and U U~ of either sign' if fam == 'rotor' else '', NFR, up(want), D_of(fam, n, 'E'), r_of(fam, n)))
    for n in (3, 4):                                                           # the same counts at R = 500 and R = 50 (no run: arithmetic only)
        print('  n = %d at R = 500: Cayley %s, rotor %s per frame; at R = 50: Cayley %s, rotor %s (above 1: no bound)' % (n, up(bound(D_of('Cayley', n, 'E'), 500, r_of('Cayley', n))),
              up(bound(D_of('rotor', n, 'E'), 500, r_of('rotor', n))), up(bound(D_of('Cayley', n, 'E'), 50, r_of('Cayley', n))), up(bound(D_of('rotor', n, 'E'), 50, r_of('rotor', n)))))

def main():
    print('A5-strong: n = %s, R = %d (p = 1/%d), %d frames per n' % (NS, RR, 2 * RR + 1, NFR))
    for n in NS: run_n(n, RR)
    if 3 in NS: part_calib(RR)
    part_table(RR, NS)
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('A5-strong')

if __name__ == '__main__': main()
