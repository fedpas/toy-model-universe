#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G3V.  The planets example of the page against 30 JPL Horizons VECTOR tables (DE441) at two epochs, 16 Jan 2018 and 9 Oct 2026.
        python3 -B g3_vectors_compare.py        (from selfcheck/gravity/; under a minute on the machine of the shipped log, well under 3 GB)

 Data classes: DC1 = the page table (PLANETS of pgadyn_selfcheck.py: the Sun and five planets at 16 Jan 2018 00:00 TDB; kg, km, km/s);
               DC3 = the 30 vector tables of data/horizons_vectors/ (JPL Horizons geometric states relative to the Solar System Barycentre, centre ephemeris
               DE441, ecliptic of J2000 with the IAU76 obliquity 84381.448 arcsec, km and km/s, TDB, one row a day; the target source of the Mars, Jupiter,
               Saturn, Uranus and Neptune centre files is a satellite ephemeris, printed by V0): planet centres, the Earth-Moon barycentre (EMB), the Moon
               and the four outer system barycentres, from JD 2458134.5 and from JD 2461322.5;
               DC2 = the three Horizons observer tables of data/horizons/ (section VX only).
 Tags: [bit] the page's own integrator rk4Bodies of pgaEngine.js, run unchanged under node by g3_pgaEngine_run.mjs, or the Atlas's own numbers;
       [std] routes that never touch the Atlas (the tables, scipy DOP853, recalled textbook formulas, linear algebra); [bit==std] the two compared;
       [ctl] a wrong version that must fail (the line is ok when it does fail).
 Sections: V0 the files; V1 relations between the files; V2 the page table against its source; V3 the page's integrator against DOP853;
           V4 31-day windows from the JPL state of either epoch, a ladder of models M0..M5; V5 8.7 years, 16 Jan 2018 to the rows of 9 Oct 2026;
           V6 controls; VX the vector tables against the observer tables; VL the advance of Mercury's perihelion from the 1PN term of the model.
 Angle: every direction error is HELIOCENTRIC, the angle at the Sun between the model's and the row's Sun-to-body vectors, maximum over the 31 rows of
           9 Oct to 8 Nov 2026; M0..M4 run through the page's rk4Bodies at a 1-hour step (the widget's default step is 4 hours; V3 compares the two).
 Check ids: <section>-<n> (V2-3, VX-1, ...), printed at the start of each check line and used as keys in logs/g3_vectors_compare.numbers.json.
 Flagged constants: PUBLISHED = a published value, not derived here (the source is named next to it); MEMORY = a textbook value recalled, not derived
           here. The models use the GM values of the file headers for the Sun, Mercury, Venus, the Earth, the Moon and Mars, and PUBLISHED system GMs
           for Jupiter, Saturn, Uranus and Neptune (the files do not carry them); section V1 derives the four from the barycentre identity as a check.
 Thresholds: each check states its threshold and, in a comment next to it, the reason (an interpolation error, a step order, the size of an effect).
 Scope: a Newtonian flow of six to ten point masses, with the Sun's first post-Newtonian term as a recalled textbook [std] addition (the formula is
        recalled, not read from a text; not an Atlas result), against the rows of one ephemeris at stated levels. It is not an ephemeris and not a test of
        general relativity. The 31-day windows resolve the Sun's GM, the Earth row, Jupiter and Saturn; Uranus, Neptune and the coefficients of the 1PN
        term are resolved only by the 8.7-year run (V5, with the controls of V6)."""
import sys, os, re, time, json, math, subprocess
sys.dont_write_bytecode = True                  # never write bytecode next to the Atlas package
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from b1lib import head, chk, finish
import numpy as np
from decimal import Decimal
from scipy.integrate import solve_ivp
import g3_lib as lib

T_ALL = time.time()
NUM = {}                                        # every headline number; written to logs/g3_vectors_compare.numbers.json
OUT = os.path.join(HERE, 'logs', 'g3_vectors_compare.numbers.json')
VD = os.path.join(HERE, 'data', 'horizons_vectors')
AU, C, DAY = lib.AU_KM, lib.C_KMS, 86400.0
ARCSEC = 180.0 / math.pi * 3600.0
R_EQ = lib.rot_ecl_to_eq()                      # ecliptic of J2000 -> ICRF equatorial (rotation about x by 84381.448 arcsec)
JD0 = {2018: Decimal('2458134.5'), 2026: Decimal('2461322.5')}
NDAYS = 3188                                    # JD 2461322.5 - JD 2458134.5
HZ_DATE = {2018: '2018-Jan-16', 2026: '2026-Oct-09'}
STOP = {(2018, 32): '2018-Feb-16', (2018, 2): '2018-Jan-17', (2018, 3): '2018-Jan-18', (2026, 31): '2026-Nov-08'}
PLAN = ['sun', 'mercury', 'venus', 'earth', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune']
BARY = ['jupiter_bary', 'saturn_bary', 'uranus_bary', 'neptune_bary']
KEYS = PLAN + ['emb', 'moon'] + BARY
SIX = ['sun', 'mercury', 'venus', 'earth', 'mars', 'jupiter']          # the bodies of the page table, in its order
TARGET = {'sun': ('Sun', 10), 'mercury': ('Mercury', 199), 'venus': ('Venus', 299), 'earth': ('Earth', 399), 'mars': ('Mars', 499), 'jupiter': ('Jupiter', 599),
          'saturn': ('Saturn', 699), 'uranus': ('Uranus', 799), 'neptune': ('Neptune', 899), 'emb': ('Earth-Moon Barycenter', 3), 'moon': ('Moon', 301),
          'jupiter_bary': ('Jupiter Barycenter', 5), 'saturn_bary': ('Saturn Barycenter', 6), 'uranus_bary': ('Uranus Barycenter', 7), 'neptune_bary': ('Neptune Barycenter', 8)}
SHORT = {'sun': 'Sun', 'mercury': 'Mer', 'venus': 'Ven', 'earth': 'Ear', 'emb': 'EMB', 'moon': 'Moon', 'mars': 'Mar', 'jupiter': 'Jup', 'saturn': 'Sat', 'uranus': 'Ura',
         'neptune': 'Nep', 'jupiter_bary': 'JupB', 'saturn_bary': 'SatB', 'uranus_bary': 'UraB', 'neptune_bary': 'NepB', 'earth*': 'Ear*'}
def nrows(year, key): return 31 if year == 2026 else (2 if key == 'moon' else 3 if key in BARY else 32)

# ------------------------------------------------------------------------------------------------- flagged constants
# PUBLISHED, not derived here: planetary system GMs of DE440 in km^3/s^2, JPL Solar System Dynamics "Astrodynamic Parameters" page
# (ssd.jpl.nasa.gov/astro_par.html; DE441 is fit with the constants of DE440). The vector files carry no GM for the four system barycentres.
PUB_GM = {'jupiter_bary': 126712764.100000, 'saturn_bary': 37940584.841800, 'uranus_bary': 5794556.400000, 'neptune_bary': 6836527.100580}
PUB_GM_PLUTO = 975.5                            # PUBLISHED (same page): Pluto system; sizes the unlisted bodies only
PUB_GM_EARTH, PUB_GM_MOON = 398600.435507, 4902.800118    # PUBLISHED (same page): compared with the Moon/Earth ratio fitted in V1 only
# PUBLISHED satellite GMs (km^3/s^2), JPL SSD "Planetary Satellite Physical Parameters" (ssd.jpl.nasa.gov/sats/phys_par); MEMORY: the semi-major axes (km).
# Used only to size the reflex of a planet centre about its system barycentre (V0, V1); every satellite eccentricity is below 0.03 (MEMORY).
SATS = {'jupiter': [(5959.91547, 421800.0), (3202.71210, 671100.0), (9887.83275, 1070400.0), (7179.28340, 1882700.0)],
        'saturn': [(8978.13710, 1221870.0), (153.94175, 527070.0), (120.51511, 3560840.0), (73.11607, 377420.0), (41.21353, 294670.0), (7.21037, 238040.0), (2.50349, 185540.0)],
        'uranus': [(4.3, 129900.0), (83.5, 190900.0), (85.1, 266000.0), (226.9, 436300.0), (205.3, 583500.0)],
        'neptune': [(1428.49546, 354760.0)]}
# PUBLISHED: Phobos and Deimos, GM 0.0007087 and 0.0000962 km^3/s^2 (same JPL page); semi-major axis 9378 and 23459 km, period 0.31891 and 1.26244 d
# (NASA NSSDC Mars fact sheet); eccentricities below 0.02 (MEMORY). The Mars file is the planet centre, which moves about the Mars system barycentre.
MARS_SATS = [(0.0007087, 9378.0, 0.31891), (0.0000962, 23459.0, 1.26244)]

# ------------------------------------------------------------------------------------------------- the vector files
NUMRE = r'([-+]?\d\.\d+E[-+]\d+)'
def read_vec(year, key):
    p = os.path.join(VD, 'vec_%d_%s.txt' % (year, key))
    raw = open(p, encoding='ascii').read()
    hdr, rest = raw.split('$$SOE', 1); body, foot = rest.split('$$EOE', 1)
    ln = [l for l in body.splitlines() if l.strip()]
    if len(ln) % 4: raise SystemExit('a row of %s is not four lines' % p)
    jd, dates, X, V, L = [], [], [], [], []
    grab = lambda line, keys: [float(re.search(r'\b%s\s*=\s*%s' % (k, NUMRE), line).group(1)) for k in keys]
    for i in range(0, len(ln), 4):
        a, b = ln[i].split('=', 1); jd.append(Decimal(a.strip())); dates.append(b.strip())
        X.append(grab(ln[i + 1], ('X', 'Y', 'Z'))); V.append(grab(ln[i + 2], ('VX', 'VY', 'VZ'))); L.append(grab(ln[i + 3], ('LT', 'RG', 'RR')))
    L = np.array(L)
    return dict(raw=raw, hdr=hdr, foot=foot, jd=jd, dates=dates, x=np.array(X), v=np.array(V), lt=L[:, 0], rg=L[:, 1], rr=L[:, 2])

def hdr_gm(hdr):
    m = re.search(r'\bGM,? ?\(?km\^3/s\^2\)?\s*=\s*([0-9.]+)', hdr)
    return Decimal(m.group(1)) if m else None

ROWS = {(y, k): read_vec(y, k) for y in (2018, 2026) for k in KEYS}
X_ = lambda y, k: ROWS[(y, k)]['x']
V_ = lambda y, k: ROWS[(y, k)]['v']

def ulp16(a):
    """one unit in the 16th significant digit of the largest |entry| (the tables print 16 significant digits)"""
    m = float(np.abs(a).max()); return 10.0 ** (math.floor(math.log10(m)) - 15) if m > 0 else 0.0

def ang(a, b):
    """angle between vectors (last axis), arcsec"""
    a = np.asarray(a, float); b = np.asarray(b, float)
    return np.degrees(np.arctan2(np.linalg.norm(np.cross(a, b), axis=-1), (a * b).sum(-1))) * 3600.0

def ck(cid, tag, cond, msg, num=None):
    """a check line with its id; num (optional) is stored under the id"""
    if num is not None: NUM.setdefault('checks', {})[cid] = num
    return chk(tag, bool(cond), cid + '  ' + msg)

def tlog(label, t0): print('  [time] %s %.1f s' % (label, time.time() - t0), flush=True)
def sdiv(a, b):
    """a / b, infinite for b = 0 (a wrong input then fails its check instead of ending the run with a ZeroDivisionError)"""
    return a / b if b != 0 else float('inf')
LIMIT_S = 300.0                                 # wall-clock limit of one DOP853 run (the longest run takes about 10 s): a collision or a wrong state stops with a message

# ------------------------------------------------------------------------------------------------- the two integrators
def page_rk4(x0, v0, mass, G, h, days):
    """[bit] the page's own rk4Bodies (pgaEngine.js, unchanged) under node: one output a day, days + 1 outputs (day 0 included)"""
    per = int(round(DAY / h)); assert abs(per * h - DAY) < 1e-9
    inp = json.dumps(dict(x=np.asarray(x0, float).tolist(), v=np.asarray(v0, float).tolist(), mass=[float(q) for q in mass], G=float(G), h=float(h), steps=int(days * per), every=per))
    pr = subprocess.run(['node', lib.NODE_RUN], input=inp, capture_output=True, text=True, timeout=900)
    if pr.returncode != 0: raise SystemExit('node failed: ' + pr.stderr[-400:])
    js = json.loads(pr.stdout)
    return np.array(js['x']), np.array(js['v'])

def rhs_factory(mu, power=3.0, pn=False, coef=(4.0, 4.0)):
    """Newtonian point masses (the force law of the page) plus, when pn, the Sun's first post-Newtonian term on every other body [std]:
       a_i += mu_S/(c^2 d^3) [ (c1 mu_S/d - v^2) r + c2 (r.v) v ],  r, v of body i relative to the Sun (body 0), d = |r|, (c1, c2) = coef = (4, 4)
       (recalled textbook form, harmonic gauge, beta = gamma = 1; the formula is recalled, not read from a text). A run that lasts longer than LIMIT_S stops."""
    n = len(mu); mu = np.asarray(mu, float); c1, c2 = coef; t_start = time.time()
    def rhs(t, y):
        if time.time() - t_start > LIMIT_S: raise SystemExit('a DOP853 run lasts longer than %.0f s: stopped (a wrong state or a collision ends here, not in a hang)' % LIMIT_S)
        x = y[:3 * n].reshape(n, 3); v = y[3 * n:].reshape(n, 3)
        a = lib.acc(x, mu, power)
        if pn:
            r = x[1:] - x[0]; w = v[1:] - v[0]; d = np.sqrt((r * r).sum(1)); k = mu[0] / (C * C * d ** 3)
            a[1:] += k[:, None] * ((c1 * mu[0] / d - (w * w).sum(1))[:, None] * r + c2 * (r * w).sum(1)[:, None] * w)
        return np.concatenate([y[3 * n:], a.ravel()])
    return rhs

def dop(x0, v0, mu, t_eval, power=3.0, pn=False, rtol=1e-12, coef=(4.0, 4.0)):
    """[std] scipy DOP853; returns positions and velocities (len(t_eval), n, 3) at the requested times (s from the start)"""
    n = len(mu); y0 = np.concatenate([np.asarray(x0, float).ravel(), np.asarray(v0, float).ravel()])
    atol = np.concatenate([np.full(3 * n, 1e-9), np.full(3 * n, 1e-15)])
    s = solve_ivp(rhs_factory(mu, power, pn, coef), (0.0, float(t_eval[-1])), y0, method='DOP853', rtol=rtol, atol=atol, t_eval=np.asarray(t_eval, float))
    if not s.success: raise SystemExit('DOP853 failed: ' + s.message)
    return s.y[:3 * n].T.reshape(-1, n, 3), s.y[3 * n:].T.reshape(-1, n, 3)

# ------------------------------------------------------------------------------------------------- the models
M_PAGE, X_PAGE, V_PAGE = lib.table_arrays()     # the page table: masses (kg), positions (km), velocities (km/s) in the order SIX
MPAGE = dict(zip(SIX, M_PAGE))
GMH = {}                                        # GM of the file headers (planet only for the planets with satellites), km^3/s^2
def mu_of(keys, kind):
    if kind == 'page': return np.array([lib.G_ATLAS * MPAGE[k] for k in keys])
    out = []
    for k in keys:
        if k == 'emb': out.append(GMH['earth'] + GMH['moon'])
        elif k in BARY: out.append(PUB_GM[k])
        else: out.append(GMH[k])
    return np.array(out)
RUNG = {'M0': (SIX, 'page'), 'M1': (SIX, 'page'), 'M2': (SIX, 'hdr'), 'M3': (['sun', 'mercury', 'venus', 'emb', 'mars', 'jupiter'], 'hdr'),
        'M4': (['sun', 'mercury', 'venus', 'emb', 'mars'] + BARY, 'hdr'), 'M5': (['sun', 'mercury', 'venus', 'emb', 'mars'] + BARY, 'hdr'),
        'M5b': (['sun', 'mercury', 'venus', 'earth', 'moon', 'mars'] + BARY, 'hdr')}
def jpl_state(year, keys): return np.array([X_(year, k)[0] for k in keys]), np.array([V_(year, k)[0] for k in keys])

def page_state(keys, T=None):
    """the page table for the bodies it has; the Earth-Moon barycentre and the Jupiter system barycentre as the page row plus the offset of the files at
       16 Jan 2018 (kinematic); Saturn, Uranus, Neptune from the files. T given: the page rows are moved by -T (the common translation of V2)."""
    xs, vs = [], []
    for k in keys:
        if k in SIX: x, v = X_PAGE[SIX.index(k)].copy(), V_PAGE[SIX.index(k)].copy()
        elif k == 'emb': x, v = X_PAGE[3] + X_(2018, 'emb')[0] - X_(2018, 'earth')[0], V_PAGE[3] + V_(2018, 'emb')[0] - V_(2018, 'earth')[0]
        elif k == 'jupiter_bary': x, v = X_PAGE[5] + X_(2018, k)[0] - X_(2018, 'jupiter')[0], V_PAGE[5] + V_(2018, k)[0] - V_(2018, 'jupiter')[0]
        else: x, v = X_(2018, k)[0].copy(), V_(2018, k)[0].copy()
        if T is not None and k not in ('saturn_bary', 'uranus_bary', 'neptune_bary'): x = x - T
        xs.append(x); vs.append(v)
    return np.array(xs), np.array(vs)

def errors(X, keys, year, pairs, extra=None):
    """X (nt, n, 3) model positions; pairs = [(output index, row index)]; per body: max and median |dr| (km) over the rows that exist, and the
       heliocentric direction error (arcsec) against the rows. extra: {name: (nt, 3) model positions compared with the rows of name[:-1]} (the Earth row via the Moon file)"""
    res = {}; isun = keys.index('sun')
    items = [(k, X[:, j]) for j, k in enumerate(keys)] + (list(extra.items()) if extra else [])
    for k, Xk in items:
        rk = k.rstrip('*'); sel = [(o, r) for o, r in pairs if r < nrows(year, rk)]
        if not sel: continue
        d = np.array([np.linalg.norm(Xk[o] - X_(year, rk)[r]) for o, r in sel])
        e = dict(max_km=float(d.max()), med_km=float(np.median(d)), n=len(sel))
        if rk != 'sun':
            a = np.array([ang(Xk[o] - X[o, isun], X_(year, rk)[r] - X_(year, 'sun')[r]) for o, r in sel])
            e.update(dir_max_as=float(a.max()), dir_med_as=float(np.median(a)))
        res[k] = e
    return res

def show(label, res):
    print('  %-30s |dr| km max/med: %s' % (label, '  '.join('%s %.3g/%.3g' % (SHORT[k], r['max_km'], r['med_km']) for k, r in res.items())))
    print('  %-30s helio. direction arcsec max/med: %s' % ('', '  '.join('%s %.3g/%.3g' % (SHORT[k], r['dir_max_as'], r['dir_med_as']) for k, r in res.items() if 'dir_max_as' in r)))

def emb_of(X, keys):
    """the model's Earth-Moon barycentre (header GMs) from separate Earth and Moon"""
    iE, iM = keys.index('earth'), keys.index('moon'); mE, mM = GMH['earth'], GMH['moon']
    return (mE * X[:, iE] + mM * X[:, iM]) / (mE + mM)

# =================================================================================================================== V0
def section_v0():
    head('V0  THE FILES: 30 Horizons vector tables (headers, rows, the redundant columns, the velocity columns against the position columns)')
    t0 = time.time(); bad = []; src = {}
    for (y, k), R in ROWS.items():
        n = nrows(y, k); h = R['hdr']; f = R['raw']
        need = ['Target body name: %s (%d)' % TARGET[k], 'Center body name: Solar System Barycenter (0)', 'Center-site name: BODY CENTER',
                'Start time      : A.D. %s 00:00:00.0000 TDB' % HZ_DATE[y], 'Stop  time      : A.D. %s 00:00:00.0000 TDB' % STOP[(y, n)], 'Step-size       : 1440 minutes',
                'Output units    : KM-S', 'Output type     : GEOMETRIC cartesian states', 'Output format   : 3 (position, velocity, LT, range, range-rate)',
                'Reference frame : Ecliptic of J2000.0']
        miss = [s for s in need if s not in h]
        if 'IAU76 obliquity of 84381.448 arcseconds' not in f: miss.append('obliquity line')
        mc = re.search(r'Center body name: Solar System Barycenter \(0\)\s*\{source: ([^}]+)\}', h); ms = re.search(r'Target body name: [^{]*\{source: ([^}]+)\}', h)
        if not mc or mc.group(1) != 'DE441': miss.append('centre source')
        src[k] = ms.group(1) if ms else '?'
        if miss: bad.append('%d %s: %s' % (y, k, miss))
    ck('V0-1', 'std', not bad, 'the 30 headers: target name and id, centre = Solar System Barycenter (source DE441), BODY CENTER, ecliptic of J2000.0 with the IAU76 obliquity 84381.448", '
       'KM-S, GEOMETRIC cartesian states, step 1440 minutes, start 00:00 TDB of %s / %s and the stop of each file%s' % (HZ_DATE[2018], HZ_DATE[2026], (': ' + '; '.join(bad)) if bad else ''))
    print('  target sources: ' + ', '.join('%s %s' % (SHORT[k], src[k]) for k in KEYS))
    NUM['V0'] = dict(target_source=src)
    # rows, JD spacing
    bad = []
    for (y, k), R in ROWS.items():
        n = nrows(y, k); jd = R['jd']
        if len(jd) != n or jd[0] != JD0[y] or any(jd[i] - jd[0] != i for i in range(n)) or R['dates'][0] != 'A.D. %s 00:00:00.0000 TDB' % HZ_DATE[y] or not all(d.endswith('00:00:00.0000 TDB') for d in R['dates']):
            bad.append('%d %s' % (y, k))
    cnt = {y: sorted(set((k, len(ROWS[(y, k)]['jd'])) for k in KEYS), key=lambda q: KEYS.index(q[0])) for y in (2018, 2026)}
    ck('V0-2', 'std', not bad, 'rows: 2018 bodies, EMB 32 rows from JD 2458134.5, Moon 2, system barycentres 3; 2026 every file 31 rows from JD 2461322.5; JD steps exactly 1 day '
       '(read as decimals), every row at 00:00:00.0000 TDB%s' % ((': ' + ', '.join(bad)) if bad else ''))
    NUM['V0']['rows'] = {str(y): {k: c for k, c in cnt[y]} for y in cnt}
    # redundant columns
    eg = el = er = 0.0
    for R in ROWS.values():
        rn = np.linalg.norm(R['x'], axis=1); vn = np.linalg.norm(R['v'], axis=1)
        eg = max(eg, float((np.abs(R['rg'] / rn - 1)).max())); el = max(el, float(np.abs(R['lt'] * C / R['rg'] - 1).max()))
        er = max(er, float((np.abs(R['rr'] - (R['x'] * R['v']).sum(1) / rn) / vn).max()))
    # thresholds: the columns print 16 significant digits, so the rebuilt values carry relative rounding of a few 1e-16
    ck('V0-3', 'std', eg < 1e-13, 'RG = |r| in all 30 files: largest relative difference %.1e (threshold 1e-13: rounding of 16-digit columns)' % eg, eg)
    ck('V0-4', 'std', el < 1e-13, 'LT = RG/c with c = 299792.458 km/s: largest relative difference %.1e (threshold 1e-13)' % el, el)
    ck('V0-5', 'std', er < 1e-13, 'RR = r.v/|r|: largest difference %.1e |v| (threshold 1e-13 |v|)' % er, er)
    # header GM, the same in both copies
    gms = {}; same = True
    for k in ('sun', 'mercury', 'venus', 'earth', 'moon', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'):
        a, b = hdr_gm(ROWS[(2018, k)]['hdr']), hdr_gm(ROWS[(2026, k)]['hdr']); same &= (a is not None and a == b); gms[k] = a
    nogm = [k for k in KEYS if k not in gms and hdr_gm(ROWS[(2018, k)]['hdr']) is not None]
    for k, g in gms.items(): GMH[k] = float(g)
    ck('V0-6', 'std', same and not nogm, 'header GM (km^3/s^2), the same in the 2018 and 2026 copies: ' + ', '.join('%s %s' % (SHORT[k], gms[k]) for k in gms) +
       '; planet-only values for the planets with satellites; the EMB file and the four system-barycentre files carry none', {k: str(g) for k, g in gms.items()})
    NUM['V0']['header_GM'] = {k: str(g) for k, g in gms.items()}
    m = re.search(r'Earth/Moon mass ratio\s*=\s*([0-9.]+)', ROWS[(2018, 'moon')]['hdr']); NUM['V0']['header_earth_moon_ratio'] = m.group(1) if m else None
    # the copies: contact lines replaced
    okc = all(R['foot'].count('[postal address removed in this copy]') == 2 and R['foot'].count('[e-mail removed in this copy]') == 1 and chr(64) not in R['raw'] for R in ROWS.values())
    ck('V0-7', 'std', okc, 'every copy holds, after $$EOE, the placeholders of the two postal lines and of the e-mail line, and no at-sign anywhere')
    tlog('V0 headers and columns', t0)

    # -------------------------------------------------- the velocity columns against the position columns
    # The test: the 7-point central difference of the daily positions, v6_k = sum_j c_j x_(k+j)/h, c = (-1, 9, -45, 0, 45, -9, 1)/60, is exact for polynomials
    # of degree 6; its error is -h^6 x^(7)/140 + ...  Rather than bound x^(7) by hand, the same stencil is applied to a [std] DOP853 flow of the ten bodies
    # (Sun, Mercury, Venus, Earth, Moon, Mars, the four system barycentres; header and published GM; the Sun's 1PN term) started from row 0 and sampled at
    # the same times: that is the predicted interpolation error e_model. Threshold: |e_data - e_model| <= 1e-3 max|e_model| (the flow follows the rows to a
    # relative 1e-5 over 31 days, so its 7th derivative is right to far better than 1e-3) + the rounding floor (110/60)/h ulp_x + ulp_v + the representation floor below.
    t0 = time.time()
    keys10, _ = RUNG['M5b']; mu10 = mu_of(keys10, 'hdr'); FL = {}
    for y in (2018, 2026):
        x0, v0 = jpl_state(y, keys10); n = 32 if y == 2018 else 31
        X, V = dop(x0, v0, mu10, np.arange(n) * DAY, pn=True); FL[y] = (X, V)
    tlog('V0 two 31-day flows of ten bodies (DOP853)', t0)
    C6 = np.array([-1.0, 9.0, -45.0, 0.0, 45.0, -9.0, 1.0]) / 60.0; GAIN = float(np.abs(C6).sum())
    def st_err(Xa, Va): return np.array([(C6[:, None] * Xa[k - 3:k + 4]).sum(0) / DAY - Va[k] for k in range(3, len(Xa) - 3)])
    def model_traj(y, k):
        X, V = FL[y]
        if k == 'emb':
            mE, mM = GMH['earth'], GMH['moon']; iE, iM = keys10.index('earth'), keys10.index('moon')
            return (mE * X[:, iE] + mM * X[:, iM]) / (mE + mM), (mE * V[:, iE] + mM * V[:, iM]) / (mE + mM)
        kk = {'jupiter': 'jupiter_bary', 'saturn': 'saturn_bary', 'uranus': 'uranus_bary', 'neptune': 'neptune_bary'}.get(k, k)
        j = keys10.index(kk); return X[:, j], V[:, j]
    # Representation floor: the rows are evaluated from DE441's
    # piecewise Chebyshev polynomials (32-day records; the Sun, Venus and the EMB in 16-day pieces, Mercury in 8-day, the Moon in 4-day pieces: MEMORY of the
    # JPL ephemeris layout). Where two pieces meet, the derivatives above the first jump by an amount set by the fit tolerance, which the files do not state, and
    # the 6-day stencil straddles such points. The floor is therefore set by what the test must see: 1e-9 |v|, a thousandth of the 1e-6 of the control V6-9.
    resA = {}; NUM['V0']['velocity'] = {}; strict = {}
    def test_a(y, k, Vdata=None):
        Xd = X_(y, k); Vd = V_(y, k) if Vdata is None else Vdata
        Xm, Vm = model_traj(y, k); n = len(Xd)
        ed = st_err(Xd, Vd); em = st_err(Xm[:n], Vm[:n]); d = np.abs(ed - em).max(1)
        tol0 = 1e-3 * float(np.abs(em).max()) + GAIN / DAY * ulp16(Xd) + ulp16(Vd)
        tol = tol0 + 1e-9 * float(np.linalg.norm(Vd, axis=1).max())
        return float(d.max()), tol, float(np.abs(ed).max()), float(np.abs(em).max()), tol0, 3 + int(d.argmax())
    groupA = {2018: ['sun', 'mercury', 'venus', 'earth', 'emb'], 2026: ['sun', 'mercury', 'venus', 'earth', 'emb', 'moon'] + BARY}
    okA = True; lines = []
    for y in (2018, 2026):
        for k in groupA[y]:
            dev, tol, ed, em, tol0, row = test_a(y, k); resA[(y, k)] = (dev, tol); okA &= dev <= tol; strict[(y, k)] = (dev / tol0, row)
            NUM['V0']['velocity']['%d_%s' % (y, k)] = dict(e_data_max=ed, e_model_max=em, dev=dev, tol=tol, tol_rounding_only=tol0, row_of_max=row)
            lines.append('%d %s %.1e/%.1e' % (y, SHORT[k], dev, tol))
    print('  resolved motion, |e_data - e_model| / threshold (km/s): ' + ', '.join(lines))
    nodes = {y: [r for r in range(32) if (JD0[y] + r - Decimal('2287184.5')) % 16 == 0] for y in (2018, 2026)}     # 16-day grid of the records (MEMORY: DE440/DE441 begin at JD 2287184.5 modulo 32 days)
    over = [(y, k, s, r) for (y, k), (s, r) in strict.items() if s > 1.0]
    print('  without the representation floor (rounding of the digits only) the deviation exceeds the floor for %s; the largest at rows %s; the 16-day nodes are rows %s (2018) and %s (2026)' %
          (', '.join('%d %s x%.0f' % (y, SHORT[k], s) for y, k, s, r in over), ', '.join('%d %s %d' % (y, SHORT[k], r) for y, k, s, r in over), nodes[2018], nodes[2026]))
    NUM['V0']['velocity_rounding_only'] = {'%d_%s' % (y, k): dict(ratio=s, row=r) for (y, k), (s, r) in strict.items()}; NUM['V0']['nodes_16d'] = {str(y): nodes[y] for y in nodes}
    worst = max(resA.items(), key=lambda q: q[1][0] / q[1][1])
    ck('V0-8', 'std', okA, 'velocity columns = derivative of the position columns for the bodies the daily rows resolve (Sun, Mercury, Venus, Earth, EMB; 2026 also the Moon and the four '
       'system barycentres): the 6th-order difference minus the printed velocity equals the predicted interpolation error to within 1e-3 of it + the rounding of the digits + 1e-9 |v| '
       '(largest ratio %.2f, %d %s; Mercury\'s interpolation error itself reaches %.1e km/s, the Moon\'s %.1e km/s)' % (worst[1][0] / worst[1][1], worst[0][0], SHORT[worst[0][1]],
       NUM['V0']['velocity']['2026_mercury']['e_data_max'], NUM['V0']['velocity']['2026_moon']['e_data_max']), dict(worst_ratio=worst[1][0] / worst[1][1]))
    # planet centres: the daily rows do not resolve the satellite-driven motion of a planet centre about its system barycentre (Phobos 0.32 d, Io 1.77 d,
    # Enceladus..Rhea 1.4..4.5 d, Miranda..Umbriel 1.4..4.1 d, Triton 5.9 d). Bound: a wobble w with |w| <= A_x and |w'| <= A_v changes the stencil result by at most
    # (110/60) A_x/h + A_v. J, S, U, N: A_x, A_v measured from the 2026 files (centre minus barycentre, after removing a straight line: the slow offset is exact
    # for the stencil) and used at both epochs (the satellite systems are the same); Mars: PUBLISHED Phobos, Deimos values, factor 1.02 for the eccentricities.
    t = np.arange(31) * DAY; bounds = {}
    for p in ('jupiter', 'saturn', 'uranus', 'neptune'):
        dx = X_(2026, p) - X_(2026, p + '_bary'); dv = V_(2026, p) - V_(2026, p + '_bary')
        A = np.stack([np.ones(31), t], 1); coef = np.linalg.lstsq(A, dx, rcond=None)[0]; w = dx - A @ coef
        bounds[p] = GAIN / DAY * float(np.linalg.norm(w, axis=1).max()) + float(np.linalg.norm(dv - coef[1], axis=1).max())
    ax = sum(gm / GMH['mars'] * a * 1.02 for gm, a, P in MARS_SATS); av = sum(gm / GMH['mars'] * 2 * math.pi * a / (P * DAY) * 1.02 for gm, a, P in MARS_SATS)
    bounds['mars'] = GAIN / DAY * ax + av
    okB = True; lines = []
    for y in (2018, 2026):
        for k in ('mars', 'jupiter', 'saturn', 'uranus', 'neptune'):
            Xd, Vd = X_(y, k), V_(y, k); Xm, Vm = model_traj(y, k); n = len(Xd)
            ed = st_err(Xd, Vd); em = st_err(Xm[:n], Vm[:n]); dev = float(np.abs(ed - em).max())
            tol = bounds[k] + 1e-3 * float(np.abs(em).max()) + GAIN / DAY * ulp16(Xd) + ulp16(Vd); okB &= dev <= tol
            NUM['V0']['velocity']['%d_%s' % (y, k)] = dict(dev=dev, tol=tol, reflex_bound=bounds[k]); lines.append('%d %s %.1e/%.1e' % (y, SHORT[k], dev, tol))
    print('  planet centres, |e_data - e_model(smooth)| / satellite bound (km/s): ' + ', '.join(lines) + '  (the Mars bound rests on the recalled orbits of Phobos and Deimos and has the smallest margin of the five)')
    ck('V0-9', 'std', okB, 'planet centres (Mars, Jupiter, Saturn, Uranus, Neptune, both epochs): the difference stays within the satellite-reflex bound (a weaker test: the rows '
       'sample the satellites below their periods); bounds %s km/s' % ', '.join('%s %.1e' % (SHORT[k], bounds[k]) for k in ('mars', 'jupiter', 'saturn', 'uranus', 'neptune')))
    # the short files (2018 Moon: 2 rows; 2018 barycentres: 3 rows): the trapezoid residual tau = x1 - x0 - (h/2)(v0 + v1) against the same residual of the flow.
    # threshold 0.05 km: the flow's own error after one day (the largest omitted force, the Earth's J2 on the Moon, about 1.2e-12 km/s^2, gives 5e-3 km and
    # 1e-7 km/s, i.e. 1e-2 km in tau), times 5; a velocity error dv shows as (h/2) dv, i.e. dv above 1.2e-6 km/s is seen.
    okC = True; lines = []
    for k in ['moon'] + BARY:
        Xd, Vd = X_(2018, k), V_(2018, k); Xm, Vm = model_traj(2018, k); n = len(Xd)
        td = np.array([Xd[i + 1] - Xd[i] - DAY / 2 * (Vd[i] + Vd[i + 1]) for i in range(n - 1)]); tm = np.array([Xm[i + 1] - Xm[i] - DAY / 2 * (Vm[i] + Vm[i + 1]) for i in range(n - 1)])
        dev = float(np.abs(td - tm).max()); okC &= dev < 0.05; lines.append('%s %.1e' % (SHORT[k], dev)); NUM['V0']['velocity']['2018_%s_trapezoid_km' % k] = dev
    ck('V0-10', 'std', okC, 'the short 2018 files (Moon 2 rows, barycentres 3 rows): x1 - x0 - (h/2)(v0 + v1) equals that of the flow to %s km (threshold 0.05 km)' % ', '.join(lines))
    tlog('V0 velocity tests', t0)
    return test_a

# =================================================================================================================== V1
def section_v1():
    head('V1  RELATIONS BETWEEN THE FILES: the Earth-Moon barycentre, the Earth row, planet centres and system barycentres, the barycentre identity')
    out = {}
    # (a) r_E - r_EMB = -lambda (r_M - r_E), lambda = mu_M/(mu_E + mu_M)
    lam = {}
    for y in (2018, 2026):
        n = nrows(y, 'moon'); a = (X_(y, 'earth')[:n] - X_(y, 'emb')[:n]).ravel(); b = -(X_(y, 'moon')[:n] - X_(y, 'earth')[:n]).ravel()
        l = float(a @ b / (b @ b)); res = a - l * b; rms = math.sqrt(float((res ** 2).mean()))
        av = (V_(y, 'earth')[:n] - V_(y, 'emb')[:n]).ravel(); bv = -(V_(y, 'moon')[:n] - V_(y, 'earth')[:n]).ravel(); lv = float(av @ bv / (bv @ bv))
        lam[y] = l; muM = sdiv(l, 1 - l) * GMH['earth']
        out[str(y)] = dict(lam=l, lam_vel=lv, rms_km=rms, mu_moon=muM, rel_header=muM / GMH['moon'] - 1, emrat=sdiv(1 - l, l), rows=n)
        # thresholds: rms below 1e-6 km (the positions carry about 1e-7 km of rounding); mu_M within 1e-7 of the header GM (5 x the header's 1-sigma 0.0001 km^3/s^2 = 2e-8)
        ck('V1-%d' % (1 if y == 2018 else 2), 'std', rms < 1e-6 and abs(muM / GMH['moon'] - 1) < 1e-7,
           '%d (%d rows): r_E - r_EMB = -lambda (r_M - r_E) with lambda = %.13e (rms residual %.1e km; from the velocities %.13e); mu_M = lambda mu_E/(1 - lambda) = %.6f km^3/s^2 '
           'with the header mu_E, header mu_M %.6f: %+.2e (threshold 1e-7); Earth/Moon mass ratio %.10f (header %s)' % (y, n, l, rms, lv, muM, GMH['moon'], muM / GMH['moon'] - 1, sdiv(1 - l, l), NUM['V0']['header_earth_moon_ratio']))
    ck('V1-3', 'std', abs(sdiv(lam[2018], lam[2026]) - 1) < 1e-9, 'lambda is the same constant at both epochs: %.2e relative (threshold 1e-9; the fit resolves about 1e-11). PUBLISHED DE440 GM_E/GM_M = %.10f, '
       'fitted %.10f, header %s: the files follow the ephemeris\'s own ratio, which the header GM of the Moon differs from by %.2e' % (abs(sdiv(lam[2018], lam[2026]) - 1), PUB_GM_EARTH / PUB_GM_MOON,
       sdiv(1 - lam[2026], lam[2026]), NUM['V0']['header_earth_moon_ratio'], out['2026']['rel_header']), abs(sdiv(lam[2018], lam[2026]) - 1))
    # (b) the Earth centre minus the EMB at 16 Jan 2018: what the page's Earth row carries that a barycentre would not
    dr = X_(2018, 'earth')[0] - X_(2018, 'emb')[0]; dv = (V_(2018, 'earth')[0] - V_(2018, 'emb')[0]) * 1000.0
    rE = X_PAGE[3] - X_PAGE[0]; vE = V_PAGE[3] - V_PAGE[0]; rh = rE / np.linalg.norm(rE); nh = np.cross(rE, vE); nh /= np.linalg.norm(nh); th = np.cross(nh, rh)
    fr = (-dv) @ np.stack([th, rh, nh], 1)
    rm = X_(2018, 'moon')[0] - X_(2018, 'earth')[0]; vm = (V_(2018, 'moon')[0] - V_(2018, 'earth')[0]) * 1000.0
    e1 = abs(np.linalg.norm(dr) - lam[2018] * np.linalg.norm(rm)); e2 = abs(np.linalg.norm(dv) - lam[2018] * np.linalg.norm(vm))
    # thresholds: 1e-5 km (V1-1 fits the vector identity to an rms below 1e-6 km: ten times that) and 1e-8 m/s (lambda is fixed to 1e-11, |dv| = 11.8 m/s: 1e-10 m/s)
    ck('V1-4', 'std', e1 < 1e-5 and e2 < 1e-8, 'the Earth centre minus the EMB at 16 Jan 2018 (rows): position (%+.2f, %+.2f, %+.2f) km, |dr| = %.2f km = lambda x the Earth-Moon distance %.1f km '
       '(difference %.1e km, threshold 1e-5 km); velocity (%+.3f, %+.3f, %+.3f) m/s, |dv| = %.3f m/s = lambda x the relative velocity %.1f m/s (difference %.1e m/s, threshold 1e-8 m/s). '
       'Seen from the centre, the barycentre moves by (along-track, radial, normal) = (%+.3f, %+.3f, %+.3f) m/s relative to the Earth\'s heliocentric orbit' %
       (tuple(dr) + (np.linalg.norm(dr), np.linalg.norm(rm), e1) + tuple(dv) + (np.linalg.norm(dv), np.linalg.norm(vm), e2) + tuple(fr)), dict(dr_km=dr.tolist(), dv_ms=dv.tolist(), pos_diff_km=float(e1), vel_diff_ms=float(e2)))
    out['earth_minus_emb_2018'] = dict(dr_km=dr.tolist(), dr_norm_km=float(np.linalg.norm(dr)), dv_ms=dv.tolist(), dv_norm_ms=float(np.linalg.norm(dv)), emb_minus_earth_frame_ms=fr.tolist())
    # (c) planet centres against system barycentres; the reflex scale sum (GM_s/GM_sys) a_s from PUBLISHED satellite GMs and MEMORY semi-major axes
    offs = {}
    for p in ('jupiter', 'saturn', 'uranus', 'neptune'):
        scale = sum(gm * a for gm, a in SATS[p]) / PUB_GM[p + '_bary']
        o = {}
        for y in (2018, 2026):
            n = nrows(y, p + '_bary'); d = np.linalg.norm(X_(y, p)[:n] - X_(y, p + '_bary')[:n], axis=1); w = np.linalg.norm(V_(y, p)[:n] - V_(y, p + '_bary')[:n], axis=1) * 1000
            o[str(y)] = dict(min_km=float(d.min()), max_km=float(d.max()), max_dv_ms=float(w.max()), rows=n)
        offs[p] = dict(o, reflex_scale_km=scale)
        print('  %-8s centre - system barycentre: 2018 (3 rows) %.1f..%.1f km, |dv| <= %.3f m/s; 2026 (31 rows) %.1f..%.1f km, |dv| <= %.3f m/s; satellite reflex scale sum (GM_s/GM) a_s = %.1f km' %
              (p.capitalize(), o['2018']['min_km'], o['2018']['max_km'], o['2018']['max_dv_ms'], o['2026']['min_km'], o['2026']['max_km'], o['2026']['max_dv_ms'], scale))
    # threshold: the centre of a planet stays within the satellites' reflex, sum (GM_s/GM) a_s (1 + e), e < 0.03; checked for Jupiter and Saturn
    okJS = all(offs[p][y]['max_km'] <= 1.03 * offs[p]['reflex_scale_km'] for p in ('jupiter', 'saturn') for y in ('2018', '2026'))
    ck('V1-5', 'std', okJS, 'Jupiter and Saturn: the centre file stays within the satellites\' reflex about the system barycentre (max %.1f km <= %.1f km; %.1f km <= %.1f km): the offsets are the '
       'Galilean moons and Titan' % (max(offs['jupiter'][y]['max_km'] for y in ('2018', '2026')), 1.03 * offs['jupiter']['reflex_scale_km'], max(offs['saturn'][y]['max_km'] for y in ('2018', '2026')), 1.03 * offs['saturn']['reflex_scale_km']))
    print('  NOT EXPLAINED here: the Uranus centre file sits %.0f..%.0f km (2018) and %.0f..%.0f km (2026) from the Uranus barycentre file, the Neptune centre %.0f..%.0f km and %.0f..%.0f km from its '
          'barycentre, against satellite reflexes of %.0f km and %.0f km; the velocity offsets (%.2f, %.2f m/s) are of the satellites\' size. The centre files come from satellite ephemerides '
          '(%s, %s), the barycentre files from DE441; the models below use the barycentre files.' % (offs['uranus']['2018']['min_km'], offs['uranus']['2018']['max_km'], offs['uranus']['2026']['min_km'],
          offs['uranus']['2026']['max_km'], offs['neptune']['2018']['min_km'], offs['neptune']['2018']['max_km'], offs['neptune']['2026']['min_km'], offs['neptune']['2026']['max_km'],
          offs['uranus']['reflex_scale_km'], offs['neptune']['reflex_scale_km'], offs['uranus']['2026']['max_dv_ms'], offs['neptune']['2026']['max_dv_ms'], NUM['V0']['target_source']['uranus'], NUM['V0']['target_source']['neptune']))
    out['centre_minus_bary'] = offs
    # (d) the barycentre identity sum mu_k r_k = 0 over the Sun, Mercury, Venus, the Earth-Moon system, Mars and the four outer systems
    inner = ['sun', 'mercury', 'venus', 'emb', 'mars']; mu_in = mu_of(inner, 'hdr'); MT = float(mu_in.sum() + sum(PUB_GM.values()))
    def dip(y, r, kind, drop=None):
        g = X_ if kind == 'x' else V_
        s = sum(mu_in[i] * g(y, k)[r] for i, k in enumerate(inner)) + sum(PUB_GM[b] * g(y, b)[r] for b in BARY if b != drop)
        return s / MT
    R = {y: np.array([dip(y, r, 'x') for r in range(nrows(y, 'jupiter_bary'))]) for y in (2018, 2026)}
    Rv = {y: np.array([dip(y, r, 'v') for r in range(nrows(y, 'jupiter_bary'))]) for y in (2018, 2026)}
    Rn = {y: float(np.linalg.norm(R[y], axis=1).max()) for y in R}
    # threshold 300 km: the unlisted bodies of DE441 (Pluto system 975.5 x 34 au / sum GM = 37 km; the large trans-Neptunian objects, Eris alone about 120 km
    # (GM about 1100 km^3/s^2 at 96 au, MEMORY); the asteroids below 1 km) cannot move the barycentre of the listed bodies further than about 250 km
    # threshold 0.1 mm/s for the velocity identity: the unlisted bodies' velocity dipole (Pluto 975.5 x 4.7 km/s and Eris about 1100 x 3.4 km/s over sum GM, MEMORY speeds) is 0.03..0.06 mm/s;
    # a Jupiter GM off by 1e-4 moves the velocity identity to about 1 mm/s while the position identity (300 km) still passes
    Rvn = {y: float(np.linalg.norm(Rv[y], axis=1).max()) * 1e6 for y in Rv}
    ck('V1-6', 'std', max(Rn.values()) < 300.0 and max(Rvn.values()) < 0.1, 'barycentre identity with the PUBLISHED outer-system GMs: |sum mu_k r_k|/sum mu = %.1f km (2018) and %.1f km (2026) (threshold 300 km: the '
       'unlisted bodies); the velocity identity %.4f and %.4f mm/s (threshold 0.1 mm/s). Vectors (km): 2018 (%+.1f, %+.1f, %+.1f), 2026 (%+.1f, %+.1f, %+.1f)' % (Rn[2018], Rn[2026], Rvn[2018],
       Rvn[2026], *R[2018][0], *R[2026][0]), dict(R2018_km=R[2018][0].tolist(), R2026_km=R[2026][0].tolist(), Rv2018_mms=Rvn[2018], Rv2026_mms=Rvn[2026]))
    out['ssb_R_km'] = {str(y): R[y][0].tolist() for y in R}; out['ssb_R_norm_km'] = {str(y): Rn[y] for y in Rn}; out['ssb_Rv_mms'] = {str(y): (Rv[y][0] * 1e6).tolist() for y in Rv}
    RnN = float(np.linalg.norm(np.array([dip(2026, r, 'x', drop='neptune_bary') for r in range(31)]), axis=1).max())
    ck('V1-7', 'ctl', RnN > 1e4, 'control: the identity without the Neptune system leaves %.3g km (must exceed 1e4 km): the identity sees each outer system' % RnN, RnN)
    # fits of the four outer system GMs; unknowns q_k = GM_k / PUBLISHED_k
    def system(parts, wx=None, wv=None):
        A, b = [], []
        for (y, rows, kind) in parts:
            g = X_ if kind == 'x' else V_; w = 1.0 if wx is None else (wx if kind == 'x' else wv)
            for r in rows:
                A.append(np.stack([PUB_GM[k] * g(y, k)[r] for k in BARY], 1) / w); b.append(-sum(mu_in[i] * g(y, k)[r] for i, k in enumerate(inner)) / w)
        return np.vstack(A), np.concatenate(b)
    def fit(parts, wx=None, wv=None):
        A, b = system(parts, wx, wv); q, *_ = np.linalg.lstsq(A, b, rcond=None); s = np.linalg.svd(A, compute_uv=False); r = A @ q - b; r1 = A @ np.ones(4) - b
        return q, float(s[0] / s[-1]), math.sqrt(float((r ** 2).mean())), math.sqrt(float((r1 ** 2).mean()))
    fits = {}
    q, cond, rr, r1 = fit([(2026, range(31), 'x')]); fits['2026_x'] = dict(q=q.tolist(), cond=cond, rms_km=rr / MT, rms_pub_km=r1 / MT)
    print('  fit, 2026 positions only (93 equations, 4 unknowns): condition number %.3g; GM/PUBLISHED - 1 = %s; rms residual %.2f km (with the published values %.2f km). The four columns hardly change in '
          '31 days: ill-conditioned, the fit trades the outer GMs against the unlisted dipole' % (cond, ' '.join('%+.1e' % (v - 1) for v in q), rr / MT, r1 / MT))
    # weights: the size of the unlisted dipole, D = 250 km and Dv = 8e-8 km/s (Pluto 975.5 x 6 km/s and Eris about 1100 x 3.5 km/s, divided by sum GM; MEMORY speeds)
    D, Dv = 250.0 * MT, 8e-8 * MT
    q, cond, rr, r1 = fit([(2026, range(31), 'x'), (2026, range(31), 'v')], D, Dv); fits['2026_xv'] = dict(q=q.tolist(), cond=cond)
    print('  fit, 2026 positions and velocities (the identity and its time derivative), weighted by D = 250 km, Dv = 8e-8 km/s: condition number %.3g; GM/PUBLISHED - 1 = %s' % (cond, ' '.join('%+.1e' % (v - 1) for v in q)))
    q, cond, rr, r1 = fit([(2018, range(3), 'x'), (2026, range(31), 'x'), (2018, range(3), 'v'), (2026, range(31), 'v')], D, Dv); fits['both_xv'] = dict(q=q.tolist(), cond=cond, rms_w=rr, rms_w_pub=r1)
    term = {k: min(PUB_GM[k] * float(np.linalg.norm(X_(y, k)[r])) for y in (2018, 2026) for r in range(nrows(y, k))) / MT for k in BARY}
    lim = {k: 1.5 * 250.0 / term[k] for k in BARY}        # threshold: 1.5 x the unlisted dipole over the body's own term in the identity
    ck('V1-8', 'std', all(abs(q[i] - 1) < lim[k] for i, k in enumerate(BARY)), 'the four outer system GMs from the identity alone (positions and velocities, 2018 and 2026 rows, weighted): '
       'condition number %.3g; GM/PUBLISHED - 1 = %s (thresholds %s: 1.5 x 250 km over each system\'s own term %s km)' % (cond, ', '.join('%s %+.1e' % (SHORT[k], q[i] - 1) for i, k in enumerate(BARY)),
       ', '.join('%.0e' % lim[k] for k in BARY), ', '.join('%.2e' % term[k] for k in BARY)), dict(q_minus_1=(q - 1).tolist(), cond=cond))
    print('  decision: the models use the PUBLISHED values (flagged); the fitted set agrees with them within the unlisted-body limit and is run once as an alternative in V5')
    out['fits'] = fits; out['fit_q'] = q.tolist(); NUM['V1'] = out
    return lam, R, q

# =================================================================================================================== V2
def section_v2(R18):
    head('V2  THE PAGE TABLE AGAINST ITS SOURCE: the six rows of PLANETS against the first rows of 16 Jan 2018 (same epoch, same frame)')
    out = {}
    dx = np.array([X_PAGE[i] - X_(2018, k)[0] for i, k in enumerate(SIX)]); dv = np.array([V_PAGE[i] - V_(2018, k)[0] for i, k in enumerate(SIX)])
    for i, k in enumerate(SIX):
        print('  %-8s page - row: dr = (%+9.3f, %+9.3f, %+9.3f) km |dr| %8.3f km   dv = (%+8.4f, %+8.4f, %+8.4f) mm/s |dv| %.4f mm/s' % ((k.capitalize(),) + tuple(dx[i]) + (np.linalg.norm(dx[i]),) + tuple(dv[i] * 1e6) + (np.linalg.norm(dv[i]) * 1e6,)))
    out['raw_dr_km'] = {k: dx[i].tolist() for i, k in enumerate(SIX)}; out['raw_dv_mms'] = {k: (dv[i] * 1e6).tolist() for i, k in enumerate(SIX)}
    inner = [0, 1, 2, 3, 4]; T = dx[inner].mean(0); res = dx[inner] - T; T6 = dx.mean(0)
    rmax = float(np.linalg.norm(res, axis=1).max()); vmax = float(np.linalg.norm(dv[inner], axis=1).max()) * 1e6
    # thresholds 1 km and 1 mm/s: 1 km is 0.02 s of Mercury's motion and 0.0014 arcsec at 1 au; reading the rows as UT (69.184 s) moves Mercury by 3300 km,
    # the EMB instead of the Earth centre is 4900 km away, the equatorial frame 6e7 km: any of these would fail by a factor of thousands
    ck('V2-1', 'bit==std', rmax < 1.0 and vmax < 1.0, 'the five inner rows (Sun, Mercury, Venus, Earth, Mars) are the JPL rows moved by one common translation T = (%+.3f, %+.3f, %+.3f) km, |T| = %.3f km: '
       'after T the rows differ by at most %.3f km, and the velocities by at most %.4f mm/s without any shift (thresholds 1 km, 1 mm/s): same epoch (00:00 TDB), same frame, '
       'body centres (the Earth row is the Earth centre)' % (tuple(T) + (np.linalg.norm(T), rmax, vmax)), dict(T_km=T.tolist(), T_norm_km=float(np.linalg.norm(T)), resid_max_km=rmax, dv_max_mms=vmax))
    for i in inner: print('     %-8s residual after T: (%+.3f, %+.3f, %+.3f) km' % ((SIX[i].capitalize(),) + tuple(res[i])))
    print('  all six rows: mean translation (%+.3f, %+.3f, %+.3f) km; Jupiter after T: (%+.3f, %+.3f, %+.3f) km, |%.3f| km' % (tuple(T6) + tuple(dx[5] - T) + (np.linalg.norm(dx[5] - T),)))
    out['T_km'] = T.tolist(); out['T_norm_km'] = float(np.linalg.norm(T)); out['resid_after_T_km'] = {SIX[i]: res[i].tolist() for i in inner}; out['jupiter_after_T_km'] = (dx[5] - T).tolist()
    # heliocentric differences
    hel = {}
    for i, k in enumerate(SIX[1:], 1):
        hp, hj = X_PAGE[i] - X_PAGE[0], X_(2018, k)[0] - X_(2018, 'sun')[0]; hv = (V_PAGE[i] - V_PAGE[0]) - (V_(2018, k)[0] - V_(2018, 'sun')[0])
        hel[k] = dict(dr_km=float(np.linalg.norm(hp - hj)), dv_mms=float(np.linalg.norm(hv) * 1e6), dir_as=float(ang(hp, hj)))
    print('  heliocentric page - row: ' + '; '.join('%s |dr| %.3f km, |dv| %.4f mm/s, direction %.4f arcsec' % (SHORT[k], hel[k]['dr_km'], hel[k]['dv_mms'], hel[k]['dir_as']) for k in hel))
    out['helio'] = hel
    # the common shift does not enter the force law (differences only): the page's integrator from the table and from the table - T (V5 runs M2') differ by T
    # Jupiter: centre or system barycentre?
    dvc = float(np.linalg.norm(dv[5]) * 1e6); dvb = float(np.linalg.norm(V_PAGE[5] - V_(2018, 'jupiter_bary')[0]) * 1e6); dxb = float(np.linalg.norm(X_PAGE[5] - X_(2018, 'jupiter_bary')[0]))
    # thresholds: the Galilean moons move the centre against the barycentre by 1..2 m/s, so 1 mm/s against the centre and 100 mm/s against the barycentre separate the two
    ck('V2-2', 'bit==std', dvc < 1.0 and dvb > 100.0, 'the Jupiter row is the planet centre: its velocity differs from the centre row by %.3f mm/s and from the system barycentre by %.1f mm/s (thresholds 1 and 100 mm/s); '
       'its position, after T, is %.1f km from the centre row (%.1f km from the barycentre row before T): NOT EXPLAINED here' % (dvc, dvb, np.linalg.norm(dx[5] - T), dxb), dict(dv_centre_mms=dvc, dv_bary_mms=dvb, dr_after_T_km=float(np.linalg.norm(dx[5] - T))))
    # masses: page G m against the header GM
    rel = {k: lib.G_ATLAS * MPAGE[k] / GMH[k] - 1 for k in SIX}
    relJs = lib.G_ATLAS * MPAGE['jupiter'] / PUB_GM['jupiter_bary'] - 1; relEM = lib.G_ATLAS * MPAGE['earth'] / (GMH['earth'] + GMH['moon']) - 1
    # thresholds: the page's G (6.6723e-11) is 3.0e-4 below the CODATA 2018 value 6.67430e-11 (MEMORY), the masses print 5 or 6 digits: the Sun in (-3e-4, -1.5e-4)
    # (as g3_nbody P1), every body within 1e-3
    ck('V2-3', 'bit==std', -3e-4 < rel['sun'] < -1.5e-4 and all(abs(v) < 1e-3 for v in rel.values()), 'page masses x PLANET_G against the header GM (planet only): ' +
       ', '.join('%s %+.2e' % (SHORT[k], rel[k]) for k in SIX) + ' (Sun in (-3e-4, -1.5e-4), all within 1e-3); the Jupiter mass against the PUBLISHED system GM %+.2e; the Earth mass against the '
       'Earth-Moon GM %+.2e (the page has no Moon)' % (relJs, relEM), dict(rel=rel, jupiter_vs_system=relJs, earth_vs_earth_moon=relEM))
    out['mass_rel'] = rel; out['mass_rel_jupiter_system'] = relJs; out['mass_rel_earth_moon'] = relEM
    # the figures the pages quote (rigidCopy, inputsData, plainStepsCopy, mapCopy, the persona, the release notes): the thresholds are the rounding windows of the quoted digits,
    # so a change of the table or of the comparison that moved a quoted digit fails here instead of staying unnoticed in the pages (audit AU-P-10)
    nT, nJ = float(np.linalg.norm(T)), float(np.linalg.norm(dx[5] - T))
    ck('V2-4', 'bit==std', abs(nT - 116.6) < 0.05 and abs(nJ - 41.5) < 0.05 and abs(rmax - 0.16) < 0.005 and abs(vmax - 0.14) < 0.005 and round(-rel['sun'] * 1e4, 1) == 2.3
       and round(-rel['earth'] * 1e4, 1) == 3.0 and round(-rel['jupiter'] * 1e4, 1) == 3.0 and round(rel['mercury'] * 1e6) == 3,
       'the figures the pages quote: common translation %.3f km (quoted 116.6), the Jupiter row a further %.3f km (41.5), residuals of the inner rows %.3f km and %.4f mm/s (0.16, 0.14); '
       'G m x PLANET_G against the header GM: Sun %+.2e (quoted -2.3e-4), Earth %+.2e and Jupiter %+.2e (-3.0e-4), Mercury %+.1e (+3e-6); each within the rounding window of the quoted digits' %
       (nT, nJ, rmax, vmax, rel['sun'], rel['earth'], rel['jupiter'], rel['mercury']),
       dict(T_norm_km=nT, jupiter_after_T_km=nJ, resid_max_km=rmax, dv_max_mms=vmax, mass_rel={k: rel[k] for k in ('sun', 'earth', 'jupiter', 'mercury')}))
    # the common translation and the barycentre identity: T + R (2018)
    S = T + R18; lon = math.degrees(math.atan2(-S[1], -S[0])) % 360.0; lat = math.degrees(math.asin(-S[2] / np.linalg.norm(S)))
    MT = float(mu_of(['sun', 'mercury', 'venus', 'emb', 'mars'], 'hdr').sum() + sum(PUB_GM.values())); pl = PUB_GM_PLUTO * 33.5 * AU / MT
    print('  T + R(2018) = (%+.2f, %+.2f, %+.2f) km, |T + R| = %.2f km; -(T + R) points to ecliptic longitude %.1f deg, latitude %+.1f deg (R: the barycentre identity residual of V1-6).' % (tuple(S) + (np.linalg.norm(S), lon, lat)))
    print('  HYPOTHESIS, not a finding (flagged inputs): Pluto\'s term in the identity is %.1f km (PUBLISHED system GM 975.5; distance 33.5 au near ecliptic longitude 290 deg, latitude about 0 deg in Jan 2018: MEMORY).'
          ' T = -R - (Pluto)/sum GM would follow if the page table\'s origin were the barycentre of the bodies of DE441 other than the trans-Neptunian objects beyond Pluto, i.e. a table taken from an'
          ' ephemeris without them; the page does not name its ephemeris and the files hold no Pluto rows, so this stays a hypothesis. It would be tested by a Horizons vector table of the'
          ' Pluto system barycentre for 16 Jan 2018, which makes the Pluto term a computed quantity, or by the six states of an earlier ephemeris version at that date.' % pl)
    out['T_plus_R_km'] = S.tolist(); out['T_plus_R_norm_km'] = float(np.linalg.norm(S)); out['T_plus_R_away_from_lon_lat_deg'] = [lon, lat]; out['pluto_term_km_memory'] = pl
    print('  explained: the epoch, the frame and the centre of the table (V2-1), the Earth row as the Earth centre (V2-1, V1-4), the Jupiter row as the planet centre (V2-2), the masses (V2-3).')
    print('  not explained: the %.1f km of the Jupiter row; the sub-km residuals of the inner rows and the velocity differences of %.2f..%.2f mm/s (two ephemeris versions would differ by such amounts; '
          'which version the page used is not stated); the origin shift T (a hypothesis above).' % (np.linalg.norm(dx[5] - T), np.linalg.norm(dv, axis=1).min() * 1e6, np.linalg.norm(dv, axis=1).max() * 1e6))
    NUM['V2'] = out
    return T

# =================================================================================================================== V3
def section_v3():
    head('V3  THE PAGE\'S INTEGRATOR AGAINST DOP853 on the page\'s own problem (page table, page masses, PLANET_G, six bodies), 31 days and 8.7 years')
    t0 = time.time(); days = NDAYS + 30; out = {}
    js = {}
    for h in (14400.0, 7200.0, 3600.0):
        t1 = time.time(); js[h] = page_rk4(X_PAGE, V_PAGE, M_PAGE, lib.G_ATLAS, h, days); out['node_s_%d' % int(h)] = time.time() - t1
    ck('V3-1', 'bit', all(js[h][0].shape == (days + 1, 6, 3) for h in js), 'the page\'s rk4Bodies ran under node at h = 4 h, 2 h, 1 h over %d days (%d, %d, %d steps), one output a day' % (days, days * 6, days * 12, days * 24))
    print('  [time] node runs %.1f, %.1f, %.1f s' % (out['node_s_14400'], out['node_s_7200'], out['node_s_3600']))
    sel = list(range(32)) + list(range(NDAYS, days + 1)); tt = np.array(sel, float) * DAY; mu = lib.G_ATLAS * M_PAGE
    t1 = time.time(); D12, _ = dop(X_PAGE, V_PAGE, mu, tt, rtol=1e-12); D13, _ = dop(X_PAGE, V_PAGE, mu, tt, rtol=1e-13); DR, _ = dop(X_PAGE, V_PAGE, mu, tt, rtol=3e-14)
    tlog('V3 DOP853 rtol 1e-12, 1e-13, 3e-14', t1)
    w18, w26 = slice(0, 32), slice(32, 32 + 31)
    def dif(A, B, w): return np.linalg.norm(A[w] - B[w], axis=2).max(0)
    dd = dif(D13, DR, w26); d12 = dif(D12, DR, w26)
    # threshold 1 km: the reference (rtol 3e-14, close to the smallest scipy accepts) must be far better than the RK4 at 1 h that it judges
    ck('V3-2', 'std', dd.max() < 1.0, 'DOP853 rtol 1e-13 against rtol 3e-14 after 8.7 years: largest position difference %.2e km (%s) (threshold 1 km); rtol 1e-12 against 3e-14: %.2e km' %
       (dd.max(), SHORT[SIX[int(dd.argmax())]], d12.max()), dict(d13=float(dd.max()), d12=float(d12.max())))
    e = {}
    for h in js:
        X = js[h][0][sel]; e[h] = dict(d31=dif(X, DR, w18), d87=dif(X, DR, w26))
        out['rk4_%d' % int(h)] = dict(max31_km={k: float(e[h]['d31'][i]) for i, k in enumerate(SIX)}, max87_km={k: float(e[h]['d87'][i]) for i, k in enumerate(SIX)})
        print('  RK4 h = %5.0f s against DOP853 3e-14: 31 days %s km | 8.7 years %s km' % (h, ' '.join('%s %.2e' % (SHORT[k], e[h]['d31'][i]) for i, k in enumerate(SIX)), ' '.join('%s %.2e' % (SHORT[k], e[h]['d87'][i]) for i, k in enumerate(SIX))))
    # thresholds: 1 km over 31 days at 4 h; 100 km over 8.7 years at 4 h (61 km for Mercury in the shipped log of g3_horizons_compare E4); 1 km at 1 h (61 km / 4^4 = 0.24 km)
    ck('V3-3', 'bit==std', e[14400.0]['d31'].max() < 1.0, 'the page\'s RK4 at the widget\'s default step (4 h) stays within %.2e km of DOP853 over 31 days (threshold 1 km)' % e[14400.0]['d31'].max(), float(e[14400.0]['d31'].max()))
    ck('V3-4', 'bit==std', e[14400.0]['d87'].max() < 100.0 and e[3600.0]['d87'].max() < 1.0, 'after 8.7 years: RK4 4 h within %.3g km of DOP853 (threshold 100 km), RK4 1 h within %.3g km (threshold 1 km); worst body Mercury' %
       (e[14400.0]['d87'].max(), e[3600.0]['d87'].max()), dict(h4=float(e[14400.0]['d87'].max()), h1=float(e[3600.0]['d87'].max())))
    # the order, without a reference: (x_4h - x_2h)/(x_2h - x_1h) -> 2^p, Mercury, median over the rows of the window
    def order(w):
        a = np.linalg.norm(js[14400.0][0][sel][w] - js[7200.0][0][sel][w], axis=2)[1:, 1]; b = np.linalg.norm(js[7200.0][0][sel][w] - js[3600.0][0][sel][w], axis=2)[1:, 1]
        return float(np.log2(np.median(a / b)))
    p31, p87 = order(w18), order(w26); pref = float(np.log2(e[14400.0]['d87'][1] / e[3600.0]['d87'][1]) / 2.0)
    # threshold: classical RK4 is 4th order; at these steps (0.012 rad of Mercury's orbit per 4 h step) the next term is ~1 %; the global error over 31 days
    # (a third of Mercury's orbit) is the accumulated local error, 4th order
    ck('V3-5', 'bit==std', 3.8 < p31 < 4.2, 'convergence order of the page\'s RK4 in the step over the 31-day window, Mercury: log2 of (x_4h - x_2h)/(x_2h - x_1h) = %.3f (no reference needed); threshold 3.8 < p < 4.2' % p31, p31)
    # threshold: after 8.7 years the error is a h^4 (periodic) + b h^5 t^2: the page's RK4 makes the energy, hence
    # the mean motion, drift at a rate ~ h^5 (g3_nbody P2 measures the exponent 5.00), and the drift of the phase grows as t^2; so 4 < p < 5
    ck('V3-6', 'bit==std', 4.0 < p87 < 5.0, 'after 8.7 years the same ratio gives p = %.3f (against DOP853, 4 h to 1 h: %.3f): between 4 (the periodic error) and 5 (the secular energy drift, rate ~ h^5, phase ~ h^5 t^2); '
       'threshold 4 < p < 5' % (p87, pref), dict(p87=p87, p_vs_dop=pref))
    out['order_p31'] = p31; out['order_p87'] = p87; out['order_p87_vs_dop'] = pref; NUM['V3'] = out
    tlog('V3', t0)
    return js

# =================================================================================================================== the ladder runs
def ladder_runs(js, T):
    """8.7-year runs from 16 Jan 2018 (daily outputs), the 2026 windows, and the page-table variants. Returns dict of model positions"""
    t0 = time.time(); days = NDAYS + 30; RUN = {}
    sel = list(range(32)) + list(range(NDAYS, days + 1)); tt = np.array(sel, float) * DAY
    RUN['M0_4h'] = (js[14400.0][0][sel], SIX); RUN['M0'] = (js[3600.0][0][sel], SIX)
    for r in ('M1', 'M2', 'M3', 'M4'):
        keys, kind = RUNG[r]; x0, v0 = jpl_state(2018, keys)
        if kind == 'page': X, V = page_rk4(x0, v0, [MPAGE[k] for k in keys], lib.G_ATLAS, 3600.0, days)
        else: X, V = page_rk4(x0, v0, mu_of(keys, 'hdr'), 1.0, 3600.0, days)
        RUN[r] = (X[sel], keys)
    tlog('ladder M1..M4 from 16 Jan 2018 through the page\'s RK4 (1 h), 8.7 years each', t0)
    t1 = time.time()
    for r, pn in (('M4d', False), ('M5', True)):
        keys, _ = RUNG['M5']; x0, v0 = jpl_state(2018, keys); RUN[r] = (dop(x0, v0, mu_of(keys, 'hdr'), tt, pn=pn)[0], keys)
    keys, _ = RUNG['M5b']; x0, v0 = jpl_state(2018, keys); RUN['M5b'] = (dop(x0, v0, mu_of(keys, 'hdr'), tt, pn=True)[0], keys)
    tlog('M4, M5, M5b by DOP853, 8.7 years each', t1)
    # the 2026 windows
    t1 = time.time(); tw = np.arange(31) * DAY
    for r in ('M1', 'M2', 'M3', 'M4'):
        keys, kind = RUNG[r]; x0, v0 = jpl_state(2026, keys)
        X, V = page_rk4(x0, v0, [MPAGE[k] for k in keys] if kind == 'page' else mu_of(keys, 'hdr'), lib.G_ATLAS if kind == 'page' else 1.0, 3600.0, 30); RUN[r + '_26'] = (X, keys)
    for r, pn, kk in (('M4d_26', False, 'M5'), ('M5_26', True, 'M5'), ('M5b_26', True, 'M5b')):
        keys, _ = RUNG[kk]; x0, v0 = jpl_state(2026, keys); RUN[r] = (dop(x0, v0, mu_of(keys, 'hdr'), tw, pn=pn)[0], keys)
    tlog('the 2026 windows (M1..M4 page RK4, M4, M5, M5b DOP853)', t1)
    # the page table itself
    t1 = time.time()
    for r, Tm in (("M2p", T), ("M2p_u", None), ("M3p", T), ("M4p", T)):
        keys, _ = RUNG[r[:2]]; x0, v0 = page_state(keys, Tm); X, V = page_rk4(x0, v0, mu_of(keys, 'hdr'), 1.0, 3600.0, days); RUN[r] = (X[sel], keys)
    for r, Tm in (("M5p", T), ("M5p_u", None)):
        keys, _ = RUNG['M5']; x0, v0 = page_state(keys, Tm); RUN[r] = (dop(x0, v0, mu_of(keys, 'hdr'), tt, pn=True)[0], keys)
    tlog('the page table: M2..M4 (page RK4) and M5 (DOP853), 8.7 years each', t1)
    return RUN

# =================================================================================================================== V4
def section_v4(RUN, lam):
    head('V4  31-DAY WINDOWS FROM THE JPL STATE OF EACH EPOCH: the ladder M0..M5 against the rows (max/median |dr| in km, heliocentric direction in arcsec)')
    print('  M0 the page as it stands (page table, page masses and G, six bodies, Earth row = Earth centre; 16 Jan 2018 only); M1 = M0 from the JPL state; M2 = M1 with the header GM of every body (page engine,'
          ' G = 1, masses = GM); M3 = M2 with the Earth-Moon system at the EMB (mu_E + mu_M); M4 = M3 with Jupiter, Saturn, Uranus, Neptune at their system barycentres (PUBLISHED system GMs); M5 = M4 with the Sun\'s'
          ' 1PN term [std, DOP853; recalled textbook term, not an Atlas result]; M5b = M5 with the Earth and the Moon as two bodies [std]. M0..M4 run through the page\'s RK4 at 1 h; M0 also at the default 4 h.\n'
          '  Over 31 days the windows resolve the Sun\'s GM, the Earth row, Jupiter and Saturn; Uranus, Neptune and the coefficients of the 1PN term are resolved only by the 8.7-year run (V5, controls V6-11).')
    out = {}
    pairs18 = [(i, i) for i in range(32)]; pairs18x = [(i, i) for i in range(1, 32)]; pairs26 = [(i, i) for i in range(1, 31)]
    res = {2018: {}, 2026: {}}
    for r in ('M0_4h', 'M0', 'M1', 'M2', 'M3', 'M4', 'M4d', 'M5', 'M5b'):
        X, keys = RUN[r]; ex = {'emb': emb_of(X, keys)} if r == 'M5b' else None
        res[2018][r] = errors(X, keys, 2018, pairs18 if r.startswith('M0') else pairs18x, ex); show('2018 ' + r + ('' if r != 'M4d' else ' (M4 by DOP853)'), res[2018][r])
    lamf = lam[2026] / (1 - lam[2026])
    for r in ('M1', 'M2', 'M3', 'M4', 'M4d', 'M5', 'M5b'):
        X, keys = RUN[r + '_26']; ex = None
        if 'emb' in keys:
            emb = X[:, keys.index('emb')]; ex = {'earth*': emb - lamf * (X_(2026, 'moon')[:len(emb)] - X_(2026, 'emb')[:len(emb)])}
        if r == 'M5b': ex = {'emb': emb_of(X, keys)}
        res[2026][r] = errors(X, keys, 2026, pairs26, ex); show('2026 ' + r + ('' if r != 'M4d' else ' (M4 by DOP853)'), res[2026][r])
    print('  (Ear* = the model EMB moved to the Earth centre with the Moon vector of the 2026 Moon file, kinematically: r_E = r_EMB - lambda/(1 - lambda) (r_M - r_EMB)_rows)')
    NUM['V4'] = {str(y): res[y] for y in res}
    # [bit==std] the page engine and DOP853 on the same model M4
    for y, a, b in ((2018, 'M4', 'M4d'), (2026, 'M4_26', 'M4d_26')):
        Xa, _ = RUN[a]; Xb, _ = RUN[b]; n = 32 if y == 2018 else 31; d = float(np.linalg.norm(Xa[:n] - Xb[:n], axis=2).max())
        # threshold 0.1 km: RK4 at 1 h is 0.24 km off after 8.7 years for Mercury (V3), so far less over 31 days
        ck('V4-%d' % (1 if y == 2018 else 2), 'bit==std', d < 0.1, '%d window, model M4: the page\'s RK4 (1 h) and DOP853 agree to %.2e km for every body over 31 days (threshold 0.1 km)' % (y, d), d)
    # M5 against the rows: threshold 5 km for every modelled body. Largest omitted effect over 31 days: the Earth-Moon pair's quadrupole in the Sun's field
    # (3/4 mu_S lambda(1 - lambda) rho^2 / R^4 = 3.5e-13 km/s^2 on the EMB, 1.3 km in 31 days); asteroids, Pluto, solar J2 below 0.01 km each
    for y in (2018, 2026):
        m = max(v['max_km'] for k, v in res[y]['M5'].items()); wk = max(res[y]['M5'].items(), key=lambda q: q[1]['max_km'])[0]
        ck('V4-%d' % (3 if y == 2018 else 4), 'std', m < 5.0, '%d window, M5: every modelled body within %.3f km of its rows over 31 days (worst %s; threshold 5 km); heliocentric directions within %.4f arcsec' %
           (y, m, SHORT[wk], max(v.get('dir_max_as', 0.0) for v in res[y]['M5'].values())), dict(max_km=m, worst=wk))
    # which rung removes which error (factors pre-declared from the size of each effect)
    def mx(y, r, k, f='max_km'): return res[y][r][k][f]
    for y in (2018, 2026):
        n = 5 if y == 2018 else 7
        f2 = mx(y, 'M1', 'mercury') / mx(y, 'M2', 'mercury'); f3 = mx(y, 'M2', 'earth') / mx(y, 'M3', 'emb'); f4 = mx(y, 'M3', 'sun') / mx(y, 'M4', 'sun'); f5 = mx(y, 'M4d', 'mercury') / mx(y, 'M5', 'mercury')
        # factors: GM of the Sun 2.3e-4 low gives 3e4 km on Mercury in 31 days against 70 km left (x 400); the Earth centre's 11.8 m/s gives 3e4 km against 70 km (x 400);
        # Saturn's pull on the inner system, 66 km in 31 days, against < 5 km (x 10); the Sun's 1PN term on Mercury 5..18 km in 31 days against < 2 km (x 3)
        ck('V4-%d' % n, 'bit==std', f2 > 10 and f3 > 10 and f4 > 10, '%d: M1 -> M2 (header GM) cuts Mercury\'s error %.3g -> %.3g km (x %.0f); M2 -> M3 (EMB) cuts the Earth\'s %.3g -> %.3g km (x %.0f); M3 -> M4 (outer systems) cuts '
           'the Sun\'s barycentric error %.3g -> %.3g km (x %.0f) (each threshold x 10)' % (y, mx(y, 'M1', 'mercury'), mx(y, 'M2', 'mercury'), f2, mx(y, 'M2', 'earth'), mx(y, 'M3', 'emb'), f3, mx(y, 'M3', 'sun'), mx(y, 'M4', 'sun'), f4), dict(f2=f2, f3=f3, f4=f4))
        ck('V4-%d' % (n + 1), 'std', f5 > 3, '%d: M4 -> M5 (the Sun\'s 1PN term) cuts Mercury\'s error %.3g -> %.3g km (x %.1f; threshold x 3)' % (y, mx(y, 'M4d', 'mercury'), mx(y, 'M5', 'mercury'), f5), f5)
    m0 = res[2018]['M0']; d0 = float(np.linalg.norm(RUN['M0'][0][0, 1] - X_(2018, 'mercury')[0]))
    print('  2018, M0 against M1: the page table starts %.1f km from the rows (the common translation T) and reaches %.3g km for Mercury in 31 days; M1 from the JPL state reaches %.3g km: the masses'
          ' and G, not the table, make the 31-day error' % (d0, m0['mercury']['max_km'], res[2018]['M1']['mercury']['max_km']))
    return res

# =================================================================================================================== V5
def section_v5(RUN, lam, T):
    head('V5  8.7 YEARS: from the state of 16 Jan 2018 to the 31 rows of 9 Oct 2026 (the same ladder; the Earth row of 2026 from the EMB and the 2026 Moon file, kinematically)')
    out = {}; pairs = [(32 + i, i) for i in range(31)]; lamf = lam[2026] / (1 - lam[2026]); res = {}
    def earth_star(X, keys):
        if 'emb' in keys: e = X[:, keys.index('emb')]
        elif 'moon' in keys: e = emb_of(X, keys)
        else: return None
        Y = e.copy(); Y[32:] = e[32:] - lamf * (X_(2026, 'moon') - X_(2026, 'emb')); return Y
    for r in ('M0_4h', 'M0', 'M1', 'M2', 'M3', 'M4', 'M4d', 'M5', 'M5b', 'M2p', 'M2p_u', 'M3p', 'M4p', 'M5p', 'M5p_u'):
        X, keys = RUN[r]; ex = {}
        es = earth_star(X, keys)
        if es is not None: ex['earth*'] = es
        if r == 'M5b': ex['emb'] = emb_of(X, keys)
        res[r] = errors(X, keys, 2026, pairs, ex)
        lab = {'M4d': 'M4 (DOP853)', 'M2p': 'M2 from the page table - T', 'M2p_u': 'M2 from the page table as printed', 'M3p': 'M3 from the page table - T', 'M4p': 'M4 from the page table - T',
               'M5p': 'M5 from the page table - T', 'M5p_u': 'M5 from the page table as printed', 'M0_4h': 'M0 at the default 4 h'}.get(r, r)
        show(lab, res[r])
    NUM['V5'] = res
    m5 = res['M5']; d = {k: m5[k]['dir_max_as'] for k in m5 if 'dir_max_as' in m5[k]}
    # thresholds (8.7 years): Mercury, Venus, Mars, the outer barycentres < 1 arcsec (the 1PN effect, about 4 arcsec for Mercury, is in the model; the rest
    # (asteroids, Pluto, solar J2, Lense-Thirring) is below 0.05 arcsec); the EMB < 3 arcsec (the Earth-Moon pair's quadrupole, omitted by a point-mass EMB: the
    # pair's mean motion is faster than the point mass's by 2 x 5.9e-8, 1.4 arcsec in 8.7 years); the Sun < 20 km (Pluto's pull and the drift of the listed bodies' barycentre, 2..3 km)
    okd = all(d[k] < 1.0 for k in ('mercury', 'venus', 'mars') + tuple(BARY)) and d['emb'] < 3.0 and m5['sun']['max_km'] < 20.0
    ck('V5-1', 'std', okd, 'M5 after 8.7 years: heliocentric direction errors (max over the 31 rows) %s arcsec (Mercury, Venus, Mars, outer systems < 1"; EMB < 3"); the Sun within %.2f km (< 20 km)' %
       (', '.join('%s %.2g' % (SHORT[k], d[k]) for k in d), m5['sun']['max_km']), dict(dir_max_as=d, sun_km=m5['sun']['max_km']))
    db = res['M5b']['emb']['dir_max_as']
    # threshold 0.5 arcsec: with the Earth and the Moon as two bodies the pair's quadrupole is in the model; what remains (lunar figure, tides, the Earth's J2) acts on the EMB at 1e-2 of it
    ck('V5-2', 'std', db < 0.5, 'M5b (the Earth and the Moon as two bodies): the EMB direction error falls from %.3g to %.2g arcsec (threshold 0.5"): the point-mass EMB, not the Sun\'s 1PN term, limits the Earth in M5' % (d['emb'], db), db)
    print('  the EMB in M4 (%.3g") and in M5 (%.3g"): with the pair as one point mass the EMB misses the quadrupole of the Earth-Moon pair in the Sun\'s field, an inward 3/4 lambda (1 - lambda) (rho/R)^2 = 5.9e-8 '
          'of the Sun\'s pull (vis-viva estimate: the point-mass model\'s mean motion is 2 x 5.9e-8 too slow, 1.4" in 8.7 years); the Sun\'s 1PN term is outward, 3 v^2/c^2 = 3.0e-8; without both (M4) the two partly cancel, with the 1PN term alone (M5) '
          'the quadrupole shows' % (res['M4d']['emb']['dir_max_as'], d['emb']))
    es = res['M5']['earth*']['dir_max_as']
    ck('V5-3', 'std', es < 3.0, 'the Earth row of 9 Oct 2026 from M5\'s EMB and the Moon vector of the 2026 Moon file (kinematic, lambda of V1): direction error %.3f arcsec, %.1f km (threshold 3", as the EMB)' % (es, res['M5']['earth*']['max_km']), es)
    # rung factors over 8.7 years
    f2 = min(res['M1'][k]['dir_med_as'] / res['M2'][k]['dir_med_as'] for k in ('mercury', 'venus')); f3 = res['M2']['earth']['dir_med_as'] / res['M3']['emb']['dir_med_as']
    f4 = res['M3']['sun']['max_km'] / res['M4']['sun']['max_km']; f5 = res['M4d']['mercury']['dir_max_as'] / m5['mercury']['dir_max_as']
    # factors: the page's G and masses cost Mercury and Venus degrees against arcseconds left (x 1000); the Earth centre costs degrees (x 1000); without Saturn,
    # Uranus, Neptune the Sun is 1e5 km off against < 20 km (x 1e4); the 1PN term on Mercury, about 4 arcsec, against < 1 arcsec (x 3)
    ck('V5-4', 'bit==std', f2 > 100 and f3 > 100 and f4 > 100, 'which rung removes which error (medians of the direction errors): M1 -> M2 header GM: Mercury %.0f" -> %.2f", Venus %.0f" -> %.2f" (x %.0f at least); M2 -> M3 EMB: '
       'Earth %.0f" -> %.2f" (x %.0f); M3 -> M4 outer systems: Sun %.3g km -> %.3g km (x %.0f); thresholds x 100' % (res['M1']['mercury']['dir_med_as'], res['M2']['mercury']['dir_med_as'], res['M1']['venus']['dir_med_as'],
       res['M2']['venus']['dir_med_as'], f2, res['M2']['earth']['dir_med_as'], res['M3']['emb']['dir_med_as'], f3, res['M3']['sun']['max_km'], res['M4']['sun']['max_km'], f4), dict(f2=f2, f3=f3, f4=f4))
    ck('V5-5', 'std', f5 > 3, 'M4 -> M5 (the Sun\'s 1PN term): Mercury %.3f" -> %.3f" (x %.1f; threshold x 3)' % (res['M4d']['mercury']['dir_max_as'], m5['mercury']['dir_max_as'], f5), f5)
    # [bit==std] page engine against DOP853 on M4 over 8.7 years: threshold 1 km (V3: 0.24 km expected at 1 h)
    dd = float(np.linalg.norm(RUN['M4'][0][32:] - RUN['M4d'][0][32:], axis=2).max())
    ck('V5-6', 'bit==std', dd < 1.0, 'model M4 over 8.7 years: the page\'s RK4 (1 h) and DOP853 agree to %.3f km at the 2026 rows (threshold 1 km)' % dd, dd)
    # the page table itself: translation invariance and the comparison with the JPL-state run
    Xs, _ = RUN['M2p']; Xu, _ = RUN['M2p_u']; ti = float(np.abs(Xu - Xs - T[None, None, :]).max())
    # threshold 1e-2 km: the dynamics depends on differences only; what remains is rounding of 1e9 km coordinates (1e-7 km) grown over 77000 steps: 9e-3 km if the rounding errors add up,
    # 3e-5 km if they random-walk; 1e-2 km is above the additive bound and 1e4 below the shift T
    ck('V5-7', 'bit', ti < 1e-2, 'the page\'s RK4 from the page table and from the page table - T: positions differ by exactly T to %.1e km at every output day over 8.7 years (threshold 1e-2 km): the force law depends on differences only, so a common shift is a constant offset of every barycentric position' % ti, ti)
    hdiff = {}
    for k in ('mercury', 'venus', 'emb', 'mars'):
        a, b = RUN['M5p'], RUN['M5']; ia, ib = a[1].index(k), b[1].index(k)
        hdiff[k] = float(ang(a[0][32:, ia] - a[0][32:, 0], b[0][32:, ib] - b[0][32:, 0]).max())
    # threshold 1 arcsec: the page rows differ from the JPL rows by up to 0.18 km and 0.12 mm/s (V2); for Mercury 0.12 mm/s changes the mean motion by 7.5e-9 (0.35" in 8.7 years)
    ck('V5-8', 'std', max(hdiff.values()) < 1.0, 'M5 from the page table (moved by -T) against M5 from the JPL state, after 8.7 years: heliocentric directions differ by %s arcsec (threshold 1"); as printed (no shift) the '
       'barycentric errors carry the constant %.1f km of T: Sun %.1f km against %.1f km' % (', '.join('%s %.2g' % (SHORT[k], v) for k, v in hdiff.items()), np.linalg.norm(T), res['M5p_u']['sun']['max_km'], res['M5p']['sun']['max_km']), hdiff)
    # the tight line, at the level of the omitted physics: thresholds 0.05" for Mercury, Venus and Mars (the omitted asteroids, Pluto, solar J2 and Lense-Thirring each act below it: Mars 0.05" is 55 km,
    # Mercury 14 km) and 0.02" for the outer systems (Pluto's pull on Neptune, a = 975.5/(1.5e9 km)^2 = 4e-16 km/s^2, moves it 15 km in 8.7 years; 0.02" is 72 km at Jupiter, 440 km at Neptune); the
    # 1" line above is the bound of the physics, this one guards the measured level: the coefficient of the 1PN term moves Mercury by 0.7" (V6-11)
    okt = all(d[k] < 0.05 for k in ('mercury', 'venus', 'mars')) and all(d[k] < 0.02 for k in BARY)
    ck('V5-11', 'std', okt, 'M5 after 8.7 years at the level of the omitted physics: Mercury %.4f", Venus %.5f", Mars %.4f" (thresholds 0.05"), outer systems %s" (thresholds 0.02")' %
       (d['mercury'], d['venus'], d['mars'], ', '.join('%s %.2g' % (SHORT[k], d[k]) for k in BARY)), dict(dir_max_as={k: d[k] for k in ('mercury', 'venus', 'mars') + tuple(BARY)}))
    # the figures the pages quote for the RK4 from the JPL state (M4, 1-hour step): Mercury 7.8 arcsec and 1.5 arcsec or less for Venus, the EMB and Mars; the thresholds are the rounding windows of the quoted digits (audit AU-P-10)
    q4 = {k: res['M4'][k]['dir_max_as'] for k in ('mercury', 'venus', 'emb', 'mars')}
    ck('V5-12', 'std', abs(q4['mercury'] - 7.8) < 0.05 and max(q4[k] for k in ('venus', 'emb', 'mars')) <= 1.5,
       'the figures the pages quote for M4 (the page\'s RK4 at a 1-hour step from the JPL state, the headers\' GM, the EMB, the outer systems): Mercury %.2f" (quoted 7.8", window 0.05"), '
       'Venus %.2f", the EMB %.2f", Mars %.2f" (quoted: 1.5" or less)' % (q4['mercury'], q4['venus'], q4['emb'], q4['mars']), q4)
    # the same for the page's own G and masses (M0, 1-hour step: degrees for Mercury, Venus and the Earth, 2.5e3 and 111 arcsec for Mars and Jupiter, up to 7.3 degrees in all) and for Mercury with the 1PN term (0.003 arcsec)
    q0 = {k: res['M0'][k]['dir_max_as'] for k in ('mercury', 'venus', 'earth', 'mars', 'jupiter')}
    ck('V5-13', 'std', round(q0['mercury'] / 3600.0, 1) == 7.3 and max(q0.values()) == q0['mercury'] and all(q0[k] > 3600.0 for k in ('mercury', 'venus', 'earth')) and round(q0['mars'], -2) == 2500
       and round(q0['mars'] / 3600.0, 1) == 0.7 and round(q0['jupiter']) == 111 and round(d['mercury'], 3) == 0.003,
       'the figures the pages quote for M0 (the page\'s own G and masses, 8.7 years): Mercury %.2f" = %.2f deg (largest of the five, quoted 7.3 deg), Venus %.0f" and the Earth %.0f" (more than 1 deg), Mars %.0f" = %.2f deg '
       '(quoted 2.5e3", 0.7 deg), Jupiter %.1f" (quoted 111"); M5 Mercury %.4f" (quoted 0.003"); each within the rounding window of the quoted digits' %
       (q0['mercury'], q0['mercury'] / 3600.0, q0['venus'], q0['earth'], q0['mars'], q0['mars'] / 3600.0, q0['jupiter'], d['mercury']), dict(M0_dir_max_as=q0, M5_mercury_as=d['mercury']))
    out.update(page_vs_jpl_dir_as=hdiff, translation_invariance_km=ti)
    print('  the ladder after 8.7 years (max over the 31 rows; Sun: barycentric |dr| in km; planets: heliocentric direction in arcsec; Earth: the centre in M0..M2, the EMB from M3 on):')
    for r in ('M0', 'M1', 'M2', 'M3', 'M4d', 'M5', 'M5b'):
        rr = res[r]; ek = 'emb' if 'emb' in rr else 'earth'
        print('    %-4s Sun %10.3g km   Mercury %10.3g"   Venus %10.3g"   %-5s %10.3g"   Mars %10.3g"   Jupiter %10.3g"' % ('M4' if r == 'M4d' else r, rr['sun']['max_km'], rr['mercury']['dir_max_as'], rr['venus']['dir_max_as'],
              'EMB' if ek == 'emb' else 'Earth', rr[ek]['dir_max_as'], rr['mars']['dir_max_as'], rr['jupiter_bary' if 'jupiter_bary' in rr else 'jupiter']['dir_max_as']))
    NUM['V5_extra'] = out
    return res

def section_v5_sens(RUN, q_fit):
    head('V5  sensitivity of the headline numbers to the PUBLISHED outer-system GMs (+1e-3 each, one at a time) and to the GMs fitted in V1')
    t0 = time.time(); keys, _ = RUNG['M5']; days = NDAYS + 30; sel = list(range(32)) + list(range(NDAYS, days + 1)); tt = np.array(sel, float) * DAY; pairs = [(32 + i, i) for i in range(31)]
    x0, v0 = jpl_state(2018, keys); base = errors(RUN['M5'][0], keys, 2026, pairs)
    def delta(resb): return {k: (abs(resb[k]['max_km'] - base[k]['max_km']), abs(resb[k].get('dir_max_as', 0.0) - base[k].get('dir_max_as', 0.0))) for k in base}
    sens = {}
    for i, b in enumerate(BARY):
        mu = mu_of(keys, 'hdr'); mu[keys.index(b)] *= 1.001; sens[b] = delta(errors(dop(x0, v0, mu, tt, pn=True)[0], keys, 2026, pairs))
    mu = mu_of(keys, 'hdr')
    for i, b in enumerate(BARY): mu[keys.index(b)] = PUB_GM[b] * q_fit[i]
    dfit = delta(errors(dop(x0, v0, mu, tt, pn=True)[0], keys, 2026, pairs))
    for b in BARY: print('  +1e-3 on %-4s: change of the M5 headline numbers |dr| km / direction arcsec: %s' % (SHORT[b], '  '.join('%s %.3g/%.4f' % (SHORT[k], v[0], v[1]) for k, v in sens[b].items())))
    print('  the fitted GMs of V1-8 instead of the published:      %s' % '  '.join('%s %.3g/%.4f' % (SHORT[k], v[0], v[1]) for k, v in dfit.items()))
    # the outer systems' own directions: a GM change d mu_k moves the system's heliocentric mean motion, at the same initial state, by about 2 d mu_k/(mu_S + mu_k)
    # (vis-viva for a near-circular orbit), so its direction after t by 2 x 1e-3 mu_k/(mu_S + mu_k) n t: the number below is that estimate
    pred = {}
    for b in BARY:
        el = lib.kepler_elements(X_(2018, b)[0] - X_(2018, 'sun')[0], V_(2018, b)[0] - V_(2018, 'sun')[0], GMH['sun'] + PUB_GM[b])
        pred[b] = 2e-3 * PUB_GM[b] / (GMH['sun'] + PUB_GM[b]) * el['n'] * (NDAYS + 15) * DAY * ARCSEC
    print('  own direction of each outer system for +1e-3 on its GM: measured %s; mean-motion estimate %s arcsec. Against these sensitivities the M5 direction errors of the outer systems (%s arcsec) '
          'leave room for a GM error of about %s (relative) at most' % (', '.join('%s %.3f' % (SHORT[b], sens[b][b][1]) for b in BARY), ', '.join('%s %.3f' % (SHORT[b], pred[b]) for b in BARY),
          ', '.join('%s %.4f' % (SHORT[b], base[b]['dir_max_as']) for b in BARY), ', '.join('%s %.0e' % (SHORT[b], sdiv(1e-3 * base[b]['dir_max_as'], sens[b][b][1])) for b in BARY)))
    inner = ('mercury', 'venus', 'emb', 'mars'); summ = {k: sum(sens[b][k][1] for b in BARY) for k in base if k != 'sun'}; tfit = max(v[1] for v in dfit.values())
    print('  summed over the four (+1e-3 each): %s arcsec. For the inner planets the Jupiter line dominates: the change is 1e-3 of Jupiter\'s pull on their 8.7-year motion' %
          ', '.join('%s %.4f' % (SHORT[k], v) for k, v in summ.items()))
    # threshold 0.1 arcsec (a tenth of the 1-arcsec thresholds of V5-1): the GMs derived from the files alone (V1-8) must give the same headlines as the published ones
    ck('V5-9', 'std', tfit < 0.1, 'with the outer-system GMs fitted from the files (V1-8) instead of the PUBLISHED values every headline direction of M5 changes by at most %.4f arcsec (threshold 0.1")' % tfit, tfit)
    lim = {'mercury': 1.0, 'venus': 1.0, 'emb': 3.0, 'mars': 1.0}
    worst = {k: base[k]['dir_max_as'] + summ[k] for k in inner}
    # the V5-1 verdicts of the inner planets must not rest on the flagged constants: headline + the summed change for +1e-3 on every outer GM stays below the V5-1 threshold
    ck('V5-10', 'std', all(worst[k] < lim[k] for k in inner), 'the V5-1 verdicts of the inner planets hold with every flagged outer-system GM off by 1e-3: headline + summed change %s arcsec, below the thresholds 1", 1", 3", 1"; '
       'the outer systems\' own directions are not robust in this sense (Jupiter %.2f" per 1e-3): their 8.7-year agreement bounds the GM errors instead, as printed above' %
       (', '.join('%s %.3f' % (SHORT[k], worst[k]) for k in inner), sens['jupiter_bary']['jupiter_bary'][1]), dict(worst=worst, summed=summ))
    NUM['V5_sensitivity'] = dict(per_gm={b: {k: list(v) for k, v in sens[b].items()} for b in BARY}, summed_dir_as=summ, fitted={k: list(v) for k, v in dfit.items()}, own_pred_as=pred)
    tlog('sensitivity runs', t0)

# =================================================================================================================== V6
def section_v6(RUN, test_a, T, res4, res5):
    head('V6  CONTROLS: wrong versions that must fail (each with the measured effect and the threshold it exceeds)')
    t0 = time.time(); keys, _ = RUNG['M5']; tw = np.arange(31) * DAY; pairs26 = [(i, i) for i in range(1, 31)]; x26, v26 = jpl_state(2026, keys); mu = mu_of(keys, 'hdr')
    out = {}
    # exponent 2.9 and 3.1, G rescaled so that the force at 1 au is unchanged (as g3_nbody P4); threshold 1e4 km: the force on Mercury changes by 9..10 %
    for p in (2.9, 3.1):
        r = errors(dop(x26, v26, mu * AU ** (p - 3.0), tw, power=p, pn=True)[0], keys, 2026, pairs26)['mercury']['max_km']; out['exponent_%.1f' % p] = r
        ck('V6-%d' % (1 if p == 2.9 else 2), 'ctl', r > 1e4, 'force ~ d^-%.1f (G rescaled at 1 au), M5, 2026 window: Mercury\'s error %.3g km in 31 days (must exceed 1e4 km; M5 itself %.3g km)' % (p - 1, r, res4[2026]['M5']['mercury']['max_km']), r)
    # the page's G and masses where the header GM is right, 8.7 years; threshold 1000 arcsec: 2 x 2.3e-4 x n t is 21000" for Mercury, 8400" Venus, 5200" Earth
    k18, _ = RUNG['M5']; x18, v18 = jpl_state(2018, k18); days = NDAYS + 30; sel = list(range(32)) + list(range(NDAYS, days + 1)); tt = np.array(sel, float) * DAY; pairs87 = [(32 + i, i) for i in range(31)]
    mup = mu_of(k18, 'hdr').copy()
    for i, k in enumerate(k18):
        if k in SIX: mup[i] = lib.G_ATLAS * MPAGE[k]
        elif k == 'emb': mup[i] = lib.G_ATLAS * MPAGE['earth'] + GMH['moon']
        elif k == 'jupiter_bary': mup[i] = lib.G_ATLAS * MPAGE['jupiter'] + (PUB_GM['jupiter_bary'] - GMH['jupiter'])
    r = errors(dop(x18, v18, mup, tt, pn=True)[0], k18, 2026, pairs87); dd = {k: r[k]['dir_max_as'] for k in ('mercury', 'venus', 'emb')}; out['page_G'] = dd
    ck('V6-3', 'ctl', min(dd.values()) > 1000.0, 'the page\'s G and masses in M5 (8.7 years): direction errors Mercury %.0f", Venus %.0f", EMB %.0f" (must exceed 1000"; M5 itself %.2g", %.2g", %.2g")' %
       (dd['mercury'], dd['venus'], dd['emb'], res5['M5']['mercury']['dir_max_as'], res5['M5']['venus']['dir_max_as'], res5['M5']['emb']['dir_max_as']), dd)
    # time scale: the rows read as UT, i.e. the model taken 69.184 s later; threshold 1000 km: Mercury moves 39..59 km/s x 69.184 s = 2700..4100 km
    r = errors(dop(x26, v26, mu, tw + lib.TT_MINUS_UTC, pn=True)[0], keys, 2026, pairs26)['mercury']['max_km']; out['time_scale'] = r
    ck('V6-4', 'ctl', r > 1000.0, 'time scale shifted by 69.184 s (UT read as TDB), M5, 2026 window: Mercury\'s error %.0f km (must exceed 1000 km)' % r, r)
    # frame read as equatorial: the 2018 rows taken as equatorial and turned to the ecliptic, against the page table; threshold 1e5 km (the obliquity turns 1 au by 6e7 km)
    Rt = R_EQ.T; dx = np.array([X_PAGE[i] - Rt @ X_(2018, k)[0] for i, k in enumerate(SIX[:5])]); fr = float(np.linalg.norm(dx - dx.mean(0), axis=1).max()); out['frame'] = fr
    ck('V6-5', 'ctl', fr > 1e5, 'frame read as equatorial: the 2018 rows turned by the obliquity no longer match the page table: inner residual after the best translation %.3g km (must exceed 1e5 km; V2-1: below 1 km)' % fr, fr)
    # the Earth centre instead of the EMB in M5; thresholds 5000 km in 31 days (11.8 m/s x 31 d = 3e4 km) and 1000" in 8.7 years (8e-4 in a: 13500")
    ke = [k if k != 'emb' else 'earth' for k in k18]; xe, ve = jpl_state(2018, ke); Xe = dop(xe, ve, mu_of(k18, 'hdr'), tt, pn=True)[0]
    r31 = errors(Xe, k18, 2018, [(i, i) for i in range(1, 32)])['emb']['max_km']; r87 = errors(Xe, k18, 2026, pairs87)['emb']['dir_max_as']; out['earth_centre'] = dict(km31=r31, dir87=r87)
    ck('V6-6', 'ctl', r31 > 5000.0 and r87 > 1000.0, 'the Earth centre where the EMB belongs (M5): EMB error %.3g km after 31 days (must exceed 5000 km) and %.0f" after 8.7 years (must exceed 1000")' % (r31, r87), dict(km31=r31, dir87=r87))
    # the outer planets removed (Saturn, Uranus, Neptune): thresholds 20 km for the Sun in 31 days (Saturn alone: 66 km) and 1e4 km after 8.7 years (Saturn's reflex: 4e5 km)
    ko = [k for k in keys if k not in ('saturn_bary', 'uranus_bary', 'neptune_bary')]; xo, vo = jpl_state(2026, ko); r31 = errors(dop(xo, vo, mu_of(ko, 'hdr'), tw, pn=True)[0], ko, 2026, pairs26)['sun']['max_km']
    xo, vo = jpl_state(2018, ko); r87 = errors(dop(xo, vo, mu_of(ko, 'hdr'), tt, pn=True)[0], ko, 2026, pairs87)['sun']['max_km']; out['outer_removed'] = dict(km31=r31, km87=r87)
    ck('V6-7', 'ctl', r31 > 20.0 and r87 > 1e4, 'Saturn, Uranus and Neptune removed from M5: the Sun is %.3g km off after 31 days (must exceed 20 km) and %.3g km after 8.7 years (must exceed 1e4 km)' % (r31, r87), dict(km31=r31, km87=r87))
    # the Sun's 1PN term removed (= M4): threshold 1 arcsec for Mercury after 8.7 years, the one M5 has to meet in V5-1
    r = res5['M4d']['mercury']['dir_max_as']; out['no_1pn'] = r
    ck('V6-8', 'ctl', r > 1.0, 'the Sun\'s 1PN term removed (M4, DOP853): Mercury\'s direction error after 8.7 years %.3f" (must exceed 1"; M5 %.3f")' % (r, res5['M5']['mercury']['dir_max_as']), r)
    # a velocity column perturbed by 1e-6: Mercury, 2026, VX x (1 + 1e-6)
    Vp = V_(2026, 'mercury').copy(); Vp[:, 0] *= 1.0 + 1e-6; dev, tol = test_a(2026, 'mercury', Vp)[:2]; out['velocity_column'] = dict(dev=dev, tol=tol)
    ck('V6-9', 'ctl', dev > tol, 'Mercury\'s VX column x (1 + 1e-6) (2026): the V0-8 velocity test fails, deviation %.2e km/s against its threshold %.2e km/s' % (dev, tol), dict(dev=dev, tol=tol))
    xp, vp = x26.copy(), v26.copy(); vp[keys.index('mercury'), 0] *= 1.0 + 1e-6; r = errors(dop(xp, vp, mu, tw, pn=True)[0], keys, 2026, pairs26)['mercury']['max_km']; out['velocity_dyn_km'] = r
    ck('V6-10', 'ctl', r > 5.0, 'the same perturbation in the initial state of M5 (2026): Mercury\'s 31-day error %.3g km (must exceed the 5 km of V4-4)' % r, r)
    # the coefficients of the 1PN term: 3 instead of 4 in the radial part (c1) or in the (r.v) v part (c2), 8.7 years from 16 Jan 2018; threshold 0.05" (the tight line V5-11) for Mercury
    cc = {}
    for nm, cf in (('c1_3', (3.0, 4.0)), ('c2_3', (4.0, 3.0))):
        cc[nm] = errors(dop(x18, v18, mu_of(k18, 'hdr'), tt, pn=True, coef=cf)[0], k18, 2026, pairs87)['mercury']['dir_max_as']
    out['pn_coef_mercury_as'] = cc
    ck('V6-11', 'ctl', min(cc.values()) > 0.05, 'the coefficient of the Sun\'s 1PN term 3 instead of 4, in the radial part and in the (r.v) v part (8.7 years): Mercury\'s direction error %.3f" and %.3f" (must exceed 0.05"; M5 itself %.4f")' %
       (cc['c1_3'], cc['c2_3'], res5['M5']['mercury']['dir_max_as']), cc)
    NUM['V6'] = out
    tlog('V6', t0)

# =================================================================================================================== VX
def section_vx():
    head('VX  THE VECTOR TABLES AGAINST THE OBSERVER TABLES (9 Oct - 8 Nov 2026): geocentric astrometric R.A., DEC and delta of the Sun, Mercury and Venus rebuilt from the vectors')
    print('  rows of the observer tables at 00:00 UT = 00:01:09.184 TDB (TT - UTC = 69.184 s; TDB - TT below 1.7 ms); vectors moved from 00:00 TDB by a Taylor step with the printed velocity and'
          ' the point-mass acceleration (and, for Mercury and Venus, the Sun\'s jerk); light time iterated; no aberration, no deflection; ecliptic -> ICRF by the 84381.448" rotation')
    t0 = time.time(); bods = ['sun', 'mercury', 'venus', 'earth', 'moon', 'mars'] + BARY; mu = dict(zip(bods, mu_of(bods, 'hdr')))
    TB = {nm: lib.read_hz(nm)[1] for nm in ('sun', 'mercury', 'venus')}
    def acc(k, b):
        x = X_(2026, b)[k]; return sum(mu[j] * (X_(2026, j)[k] - x) / np.linalg.norm(X_(2026, j)[k] - x) ** 3 for j in bods if j != b)
    def jerk(k, b):
        if b == 'sun': return np.zeros(3)
        r = X_(2026, b)[k] - X_(2026, 'sun')[k]; w = V_(2026, b)[k] - V_(2026, 'sun')[k]; d = np.linalg.norm(r)
        return -mu['sun'] * (w / d ** 3 - 3 * (r @ w) * r / d ** 5)
    A = {(k, b): acc(k, b) for k in range(31) for b in ('sun', 'mercury', 'venus', 'earth')}; Jk = {(k, b): jerk(k, b) for k in range(31) for b in ('sun', 'mercury', 'venus', 'earth')}
    def pos(k, b, dt): return X_(2026, b)[k] + V_(2026, b)[k] * dt + 0.5 * A[(k, b)] * dt * dt + Jk[(k, b)] * dt ** 3 / 6.0
    def run(shift=lib.TT_MINUS_UTC, R=R_EQ, tdb=False):
        res = {}
        for nm in ('sun', 'mercury', 'venus'):
            sep, dde = [], []
            for k in range(31):
                s = shift
                if tdb:                                   # TDB - TT, leading term 0.001657 sin g, g = 357.53 + 0.98560028 (JD - 2451545) deg (textbook, MEMORY)
                    g = math.radians(357.53 + 0.98560028 * (float(JD0[2026]) + k - 2451545.0)); s += 0.001657 * math.sin(g)
                xe = pos(k, 'earth', s); tau = 0.0
                for _ in range(10):
                    rho = pos(k, nm, s - tau) - xe; tn = float(np.linalg.norm(rho)) / C
                    if abs(tn - tau) < 1e-12: tau = tn; break
                    tau = tn
                rho = pos(k, nm, s - tau) - xe; ra, de = lib.ra_dec_deg(R @ rho); row = TB[nm][k]
                sep.append(lib.sep_arcsec(ra, de, row['ra'], row['dec'])); dde.append(float(np.linalg.norm(rho)) / AU - row['delta'])
            res[nm] = dict(sep_max=float(max(sep)), sep_med=float(np.median(sep)), ddelta_max_au=float(np.abs(dde).max()))
        return res
    base = run(); tdb = run(tdb=True)
    for nm in base: print('  %-8s separation max %.3f" median %.3f"; |d delta| max %.2e au (with the textbook TDB - TT term %.2e au)' % (nm.capitalize(), base[nm]['sep_max'], base[nm]['sep_med'], base[nm]['ddelta_max_au'], tdb[nm]['ddelta_max_au']))
    sm = max(v['sep_max'] for v in base.values()); dm = max(v['ddelta_max_au'] for v in base.values())
    # thresholds: 0.3 arcsec (R.A. printed to 0.01 s = 0.15", DEC to 0.1": half units 0.075", 0.05"; the omitted solar deflection below 0.02" at these elongations);
    # 1e-9 au for delta (TDB - TT up to 1.7 ms times a range rate up to 30 km/s: 3.4e-10 au; the gravitational delay of light below 1e-11 au)
    ck('VX-1', 'std', sm < 0.3 and dm < 1e-9, 'the two data classes are one ephemeris: the 93 rows of the observer tables follow from the vector tables to %.3f arcsec (threshold 0.3") and %.1e au in delta (threshold 1e-9 au)' % (sm, dm), dict(sep_max_as=sm, ddelta_max_au=dm))
    c1 = run(shift=0.0); c2 = run(R=np.eye(3)); s1 = max(v['sep_max'] for v in c1.values()); s2 = max(v['sep_max'] for v in c2.values())
    # control thresholds: 1" (the Sun moves 0.042"/s along the ecliptic: 2.9" in 69 s) and 3600" (the obliquity)
    ck('VX-2', 'ctl', s1 > 1.0, 'control: UT read as TDB (no 69.184 s): separation up to %.2f" (must exceed 1")' % s1, s1)
    ck('VX-3', 'ctl', s2 > 3600.0, 'control: the ecliptic vectors read as equatorial (no rotation): separation up to %.0f" (must exceed 3600")' % s2, s2)
    NUM['VX'] = dict(base=base, tdb_tt=tdb, ctl_ut=s1, ctl_frame=s2)
    tlog('VX', t0)

# =================================================================================================================== VL
def section_vl():
    head('VL  THE ATLAS LINK: the advance of Mercury\'s perihelion produced by the 1PN term of the model (rhs_factory, the term of M5), Sun and Mercury alone, against 6 pi mu_S/(c^2 a (1 - e^2)) per orbit')
    t0 = time.time(); muS = GMH['sun']; mu2 = np.array([GMH['sun'], GMH['mercury']]); muT = muS + GMH['mercury']
    r0 = X_(2018, 'mercury')[0] - X_(2018, 'sun')[0]; w0 = V_(2018, 'mercury')[0] - V_(2018, 'sun')[0]; el = lib.kepler_elements(r0, w0, muT)
    u = r0 / np.linalg.norm(r0); hh = np.cross(r0, w0); hh /= np.linalg.norm(hh); ww = np.cross(hh, u); norb = 20
    # the two bodies in their barycentric frame; the same rhs as every other run of the script (rhs_factory), so that a fault in the term shows here
    x2 = np.array([-mu2[1] / muT * r0, mu2[0] / muT * r0]); v2 = np.array([-mu2[1] / muT * w0, mu2[0] / muT * w0])
    def run(pn, coef=(4.0, 4.0)):
        f = rhs_factory(mu2, 3.0, pn, coef)
        def peri(t, y): return (y[3:6] - y[0:3]) @ (y[9:12] - y[6:9])
        peri.direction = 1.0
        s = solve_ivp(f, (0.0, (norb + 1.2) * el['T']), np.concatenate([x2.ravel(), v2.ravel()]), method='DOP853', rtol=1e-13, atol=np.concatenate([np.full(6, 1e-9), np.full(6, 1e-15)]), events=peri)
        th = np.unwrap([math.atan2((y[3:6] - y[0:3]) @ ww, (y[3:6] - y[0:3]) @ u) for y in s.y_events[0]])
        return np.diff(th)
    adv = run(True); adv0 = run(False); pred = 6 * math.pi * muS / (C * C * el['a'] * (1 - el['e'] ** 2))
    m = float(np.mean(adv)); cy = 36525.0 * DAY / el['T'] * ARCSEC
    # thresholds: 1e-5 relative (the event times are located to about 1e-12 rad of an advance of 5e-7 rad, a noise of about 2e-6 in the ratio; the O((mu/c^2 p)^2) terms are 1e-7 relative); the Newtonian control below 1e-9 rad per orbit
    ck('VL-1', 'std', abs(m / pred - 1) < 1e-5, 'advance per orbit from the flow of the model\'s own 1PN term (two bodies) %.6e rad (%d perihelia, spread %.1e) = %.4f arcsec per century; 6 pi mu/(c^2 a (1 - e^2)) = %.6e rad with the osculating a = %.6f au, e = %.6f of 16 Jan 2018: '
       'ratio - 1 = %+.2e (threshold 1e-5). d5_perihelion.py reaches the same 6 pi M/p from the Atlas\'s Schwarzschild-frame geodesics; here the term is the recalled textbook 1PN term, which is all that is claimed' %
       (m, len(adv) + 1, float(np.std(adv)), m * cy, pred, el['a'] / AU, el['e'], m / pred - 1), dict(adv_rad=m, pred_rad=pred, ratio_minus_1=m / pred - 1, arcsec_per_century=m * cy))
    ck('VL-2', 'ctl', abs(float(np.mean(adv0))) < 1e-9, 'control: without the 1PN term the same run closes: %.1e rad per orbit (threshold 1e-9 against %.1e)' % (float(np.mean(adv0)), pred), float(np.mean(adv0)))
    # control: a wrong coefficient (3 instead of 4) in either part of the term must move the advance by more than 1e-3 of the prediction (a hundred times the threshold of VL-1)
    dev = {nm: abs(float(np.mean(run(True, cf))) / pred - 1) for nm, cf in (('c1_3', (3.0, 4.0)), ('c2_3', (4.0, 3.0)))}
    ck('VL-3', 'ctl', min(dev.values()) > 1e-3, 'control: the coefficient 3 instead of 4 in the radial part or in the (r.v) v part of the term changes the advance by %.2e and %.2e of the prediction (must exceed 1e-3)' %
       (dev['c1_3'], dev['c2_3']), dev)
    NUM['VL'] = dict(adv_rad=m, pred_rad=pred, arcsec_per_century=m * cy, newton_rad=float(np.mean(adv0)), coef3_dev=dev)
    tlog('VL', t0)

# =================================================================================================================== main
def main():
    print('G3V  the planets example of the page against 30 JPL Horizons vector tables (DE441): 16 Jan 2018 (JD 2458134.5) and 9 Oct 2026 (JD 2461322.5), %d days apart' % NDAYS)
    test_a = section_v0()
    lam, R, q = section_v1()
    T = section_v2(R[2018][0])
    js = section_v3()
    head('the ladder runs (page RK4 under node and DOP853), shared by V4, V5 and V6')
    RUN = ladder_runs(js, T)
    res4 = section_v4(RUN, lam)
    res5 = section_v5(RUN, lam, T)
    section_v5_sens(RUN, q)
    section_v6(RUN, test_a, T, res4, res5)
    section_vx()
    section_vl()
    NUM['seconds'] = time.time() - T_ALL
    os.makedirs(os.path.dirname(OUT), exist_ok=True); json.dump(NUM, open(OUT, 'w'), indent=1, default=float)
    print('\n  [time] total %.0f s; numbers written to logs/g3_vectors_compare.numbers.json' % (time.time() - T_ALL))
    finish('G3V')

if __name__ == '__main__':
    main()
