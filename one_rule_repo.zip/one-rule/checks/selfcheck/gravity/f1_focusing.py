#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F1.  Focusing along null generators.   python3 f1_focusing.py
 Background  RN in the radial Kerr-Schild frame of C3 (advanced chart, f = M/rho - s/rho^2), omega from A3, R_ab from E_a through A4 (c = 0), the Maxwell stress of C3;
             one twisting congruence: Kerr's l from C2 (g2_kerr).  n = 4, signature (+,-,-,-), exact.
 Engine      B^a_c = (D N)^a (E_c), D N = d N + omega N (Grav.D_vector, h table); theta = tr B; a = B N; screen: K null with K.N = 1, P = 1 - N K - K N, Bhat = P B P,
             sigma = sym(Bhat) - theta P/2, w = antisym(Bhat); d theta/d lambda = (d theta)(N) with the engine's d; Ric(N, N) = G_NN - (1/2)(N.N) G^c_c from E_a (A4).
 Claims      l = d_t - d_rho: theta = -2/rho, sigma = w = a = R_ll = 0, d theta/d lambda = -2/rho^2.  Killing xi = d_t: B_(ab) = 0; on rho = r_h: xi null, theta = sigma = w = 0,
             R_xi xi = 0, nabla_xi xi = kappa xi, kappa = (1/2) dg_tt/drho.  Raychaudhuri d theta/d lambda = alpha theta^2 + beta sigma^2 + gamma w^2 + delta R_NN with fitted
             (alpha, beta, gamma, delta) = (-1/2, -1, 1, -1).  Any vector field: N(theta) = nabla.a - tr B^2 - Ric(N, N).  Null energy: Ric(N, N) = kappa T_NN >= 0.
 [std]       Christoffel route for nabla N and for G (C1's std_G); closed forms.   [ctl] non-null N, xi off the horizon, torsion, flipped stress, theta^2 coefficient -1/3, omega = 0."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import c3_rn as C3                # frame_at, rn_jets, maxwell_on_frame, einstein_on_frame, christoffel_std (no engine object at import)
import c1_birkhoff as C1          # std_G only
import g2_kerr as GK              # kerr_ks_frame_jet, rational_kerr_points, PYTH (no engine object at import)

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
SQ = LORENTZ(4); POINTS = C3.POINTS
def dot(u, v): return sum(SQ[a] * u[a] * v[a] for a in range(4))
def lowv(v): return [SQ[a] * v[a] for a in range(4)]
def mat(A, B): return [[sum(A[i][k] * B[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def zjet(p): return {0: p} if p else {}
def at0m(B): return [[at0(B[a][c], 4) for c in range(4)] for a in range(4)]

# ------------------------------------------------------------------------------------------------ engine side
def B_jet(Gv, om, N, E, deg):
    """[bit] B^a_c(x) = (D N)^a (E_c) as jets of x-degree <= deg (N: frame components, polynomials)"""
    with trunc(4, xdeg=deg):
        DN = Gv.D_vector(om, [zjet(p) for p in N])
        return [[lin(*[(F(1), pm(DN[a][1 << mu], E[mu][c])) for mu in range(4) if DN[a].get(1 << mu)]) for c in range(4)] for a in range(4)]
def aux_null(N):
    c = F(1) / (2 * N[0] ** 2); return [c * N[0]] + [-c * N[i] for i in (1, 2, 3)]
def screen(B0, N0, K=None):
    """theta, sigma^2, w^2 of Bhat = P B P (P = 1 - N K - K N, K null, K.N = 1), and P"""
    K = K or aux_null(N0); Nl, Kl = lowv(N0), lowv(K)
    P = [[F(int(a == b)) - N0[a] * Kl[b] - K[a] * Nl[b] for b in range(4)] for a in range(4)]
    Bh = mat(mat(P, B0), P); th = sum(Bh[a][a] for a in range(4))
    Bl = [[SQ[a] * Bh[a][b] for b in range(4)] for a in range(4)]; Pl = [[SQ[a] * P[a][b] for b in range(4)] for a in range(4)]
    sg = [[(Bl[a][b] + Bl[b][a]) / 2 - th * Pl[a][b] / 2 for b in range(4)] for a in range(4)]; tw = [[(Bl[a][b] - Bl[b][a]) / 2 for b in range(4)] for a in range(4)]
    return th, sum(SQ[a] * SQ[b] * sg[a][b] ** 2 for a in range(4) for b in range(4)), sum(SQ[a] * SQ[b] * tw[a][b] ** 2 for a in range(4) for b in range(4)), P
def other_K(N0, K, P, r):
    w = [sum(P[a][b] * r[b] for b in range(4)) for a in range(4)]; c = -dot(w, w) / 2; return [K[a] + w[a] + c * N0[a] for a in range(4)]
def ricci_NN(Gm, N): return H.contract_NN(Gm, N, SQ) - dot(N, N) * sum(Gm[a][a] for a in range(4)) / 2
def engine_G(Gv, S, e, om=None):
    """[bit] omega and the mixed Einstein tensor G^b_a (frame) read from E_a(c = 0) (A4)"""
    if om is None: om, comp = C3.einstein_on_frame(Gv, S, e)
    else:
        with trunc(4, xdeg=1): R = Gv.curvature(om)
        comp = engine_E_from_R(Gv, e, R, 4, 0)
    e0, E0, det = E0_of(e, 4, 4); return om, mixed_from_components(comp, e0, det, 4, s=-1)
def evaluate(Gv, om, E, N, Gm):
    """[bit] at the point: B, theta, d theta/d lambda (engine d), the acceleration a = B N and nabla.a, tr B^2, Ric(N, N)"""
    B = B_jet(Gv, om, N, E, 1); B0 = at0m(B); N0 = [at0(p, 4) for p in N]
    th_j = lin(*[(F(1), B[a][a]) for a in range(4)]); dth_f = Gv.Fm.d(zjet(th_j))
    Nco = [sum(at0(E[mu][a], 4) * N0[a] for a in range(4)) for mu in range(4)]
    dth = sum(at0(dth_f.get(1 << mu, {}), 4) * Nco[mu] for mu in range(4))
    with trunc(4, xdeg=1): acc = [lin(*[(F(1), pm(B[a][b], N[b])) for b in range(4)]) for a in range(4)]
    Ba = at0m(B_jet(Gv, om, acc, E, 0))
    return dict(B0=B0, N0=N0, theta=sum(B0[a][a] for a in range(4)), dth=dth, acc0=[at0(p, 4) for p in acc], diva=sum(Ba[a][a] for a in range(4)),
                trB2=sum(B0[a][c] * B0[c][a] for a in range(4) for c in range(4)), RNN=ricci_NN(Gm, N0))

# ------------------------------------------------------------------------------------------------ standard side
def std_B(e, E, N):
    """[std] nabla_c N^a = e^a_nu (d_mu N^nu + Gamma^nu_{mu lambda} N^lambda) E^mu_c at the point (Christoffel symbols of g = e^T eta e)"""
    g = std_metric(e, 4, SQ, 4, 2); Gam = C3.christoffel_std(g, 4, 4)
    with trunc(4, xdeg=2): Nco = [lin(*[(F(1), pm(E[mu][a], N[a])) for a in range(4)]) for mu in range(4)]
    N0c = [at0(p, 4) for p in Nco]; e0, E0, det = E0_of(e, 4, 4)
    nab = [[at0(pder(Nco[v], m), 4) + sum(Gam[(v, m, l)] * N0c[l] for l in range(4)) for v in range(4)] for m in range(4)]
    return [[sum(e0[a][v] * nab[m][v] * E0[m][c] for m in range(4) for v in range(4)) for c in range(4)] for a in range(4)]
def std_G_frame(p, rho0, M, s, e):
    e0, E0, det = E0_of(e, 4, 4); return to_frame_mixed(C1.std_G(p, rho0, C3.rn_jets(M, s, rho0)), e0, E0, 4)
def eikonal_N(e, E, nfr, X2):
    """[std construction] S with dS(p) = n_a e^a(p) (n a null frame covector), second derivatives X2 + a correction, third derivatives solved, so that
    g^{mu nu} dS dS = 0 to x-degree 2; returns the frame components N^a = eta^aa E^nu_a d_nu S (jets of degree 2) and the residual g(dS, dS)"""
    with trunc(4, xdeg=2): gi = [[lin(*[(F(SQ[a]), pm(E[m][a], E[v][a])) for a in range(4)]) for v in range(4)] for m in range(4)]
    R4 = range(4); G0 = [[at0(gi[m][v], 4) for v in R4] for m in R4]
    G1 = [[[at0(pder(gi[m][v], r), 4) for v in R4] for m in R4] for r in R4]
    G2 = [[[[at0(pder(pder(gi[m][v], r), s_), 4) for v in R4] for m in R4] for s_ in R4] for r in R4]
    e0 = [[at0(e[a].get(1 << mu, {}), 4) for mu in R4] for a in R4]
    S1 = [sum(nfr[a] * e0[a][mu] for a in R4) for mu in R4]; N0 = [sum(G0[v][m] * S1[m] for m in R4) for v in R4]; assert sum(N0[v] * S1[v] for v in R4) == 0
    k = [F(1) / N0[0], F(0), F(0), F(0)]
    r1 = [sum(G1[r][m][v] * S1[m] * S1[v] for m in R4 for v in R4) for r in R4]
    z = [-r1[r] / 2 - sum(N0[v] * X2[v][r] for v in R4) for r in R4]; Nz = sum(N0[v] * z[v] for v in R4); y = [z[r] - Nz / 2 * k[r] for r in R4]
    S2 = [[X2[m][v] + k[m] * y[v] + y[m] * k[v] for v in R4] for m in R4]
    W = [[F(1, 2) * sum(G2[r][s_][m][v] * S1[m] * S1[v] for m in R4 for v in R4) + sum((G1[r][m][v] * S2[v][s_] + G1[s_][m][v] * S2[v][r]) * S1[m] for m in R4 for v in R4)
          + sum(G0[m][v] * S2[m][r] * S2[v][s_] for m in R4 for v in R4) for s_ in R4] for r in R4]
    w = [sum(N0[r] * W[r][s_] for r in R4) for s_ in R4]; Ny = -sum(N0[s_] * w[s_] for s_ in R4) / 3; y3 = [(-w[s_] - k[s_] * Ny) / 2 for s_ in R4]
    Y = [[-W[r][s_] - k[r] * y3[s_] - y3[r] * k[s_] for s_ in R4] for r in R4]
    S = {}
    for m in R4:
        S = padd(S, scale(var(4, m), S1[m]))
        for v in R4:
            S = padd(S, scale(sp_mul(var(4, m), var(4, v), 3, 4), S2[m][v] / 2))
            for u in R4: S = padd(S, scale(sp_mul(sp_mul(var(4, m), var(4, v), 3, 4), var(4, u), 3, 4), (k[m] * Y[v][u] + k[v] * Y[m][u] + k[u] * Y[m][v]) / 6))
    dS = [pder(S, m) for m in R4]
    with trunc(4, xdeg=2):
        N2 = lin(*[(F(1), pm(pm(gi[m][v], dS[m]), dS[v])) for m in R4 for v in R4])
        Nfr = [lin(*[(F(SQ[a]), pm(E[v][a], dS[v])) for v in R4]) for a in R4]
    return Nfr, N2
def gauss_solve(A, b):
    n = len(A); M = [list(A[i]) + [b[i]] for i in range(n)]
    for c in range(n):
        p = next(i for i in range(c, n) if M[i][c] != 0); M[c], M[p] = M[p], M[c]; piv = M[c][c]; M[c] = [x / piv for x in M[c]]
        for i in range(n):
            if i != c and M[i][c] != 0: f = M[i][c]; M[i] = [M[i][j] - f * M[c][j] for j in range(n + 1)]
    return [M[i][n] for i in range(n)]
UNITS = [(1, 2, 2, 3), (2, 3, 6, 7), (1, 4, 8, 9), (4, 4, 7, 9), (2, -6, 9, 11), (-6, 6, 7, 11), (3, 4, -12, 13), (-2, -3, 6, 7)]
def null_from(u): return [F(1)] + [F(u[i], u[3]) for i in range(3)]

def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); rng = random.Random(23); rows = []
    rnd = lambda: F(rng.randint(-6, 6), rng.randint(1, 4))
    # ================================================================================== 1. the principal null direction l of RN
    head('1. l = d_t - d_rho on RN (the gradient of v = t + rho): expansion, shear, twist, acceleration, Raychaudhuri (7 points x 2 (M, s))')
    ok_cl = True; ok_bs = True; ok_K = True; ok_om0 = False; ok_m4 = True; RNdata = {}
    for (M, s) in ((F(1), F(1, 2)), (F(3, 2), F(2))):
        for (p, rho0) in POINTS:
            pt, e, E = C3.frame_at(p, rho0, M, s); _, _, (lu, ld) = ks_frame_jet(pt, F(rho0), *C3.rn_jets(M, s, rho0))
            om, Gm = engine_G(Gv, S, e); RNdata[(M, s, p)] = (pt, e, E, om, Gm)
            d = evaluate(Gv, om, E, lu, Gm); th, s2, w2, P = screen(d['B0'], d['N0']); r = F(rho0)
            ok_cl &= (th == d['theta'] == -2 / r and s2 == 0 and w2 == 0 and d['acc0'] == [0] * 4 and d['diva'] == 0 and d['RNN'] == 0 and d['dth'] == -2 / r ** 2)
            ok_bs &= (d['B0'] == std_B(e, E, lu)); ok_m4 &= (d['theta'] < 0)
            K2 = other_K(d['N0'], aux_null(d['N0']), P, [rnd() for _ in range(4)]); ok_K &= (screen(d['B0'], d['N0'], K2)[:3] == (th, s2, w2))
            B00 = at0m(B_jet(Gv, [{} for _ in range(Gv.G)], lu, E, 0)); ok_om0 |= (B00 != d['B0'])
            rows.append(('RN l', [th ** 2, s2, w2, d['RNN']], d['dth']))
    chk('bit', ok_cl, 'theta = -2/rho, sigma^2 = 0, w^2 = 0, a = nabla_l l = 0, nabla.a = 0, R_ll = 0 and d theta/d lambda = -2/rho^2 exactly, 14 (point, (M, s)) pairs')
    chk('bit==std', ok_bs, 'B^a_c = nabla_c l^a: engine (D_vector, omega of A3) = Christoffel route, all 16 entries, 14 pairs')
    chk('std', ok_m4, 'the sign of theta is fixed by the [std] side: theta < 0, the ingoing congruence converges (the engine alone is blind to (d, omega) -> (-d, -omega))')
    chk('bit', ok_K, 'theta, sigma^2, w^2 do not depend on the auxiliary null vector K (a second K = K + w - (w.w/2) N with a random screen vector w)')
    chk('ctl', ok_om0, 'control omega = 0: B != the engine B (the connection carries the expansion)')
    tick('part 1')

    # ================================================================================== 2. Killing horizons
    head('2. the Killing vector xi = d_t: Killing equation everywhere; on horizons (g_tt = 0 at rational rho): null, theta = sigma = w = 0, R_xi xi = 0, nabla_xi xi = kappa xi')
    HOR = [((1, 2, 2), 3, F(2), F(3, 2), F(1, 9)), ((F(2, 3), F(1, 3), F(2, 3)), 1, F(2), F(3, 2), F(-1)), ((2, 3, 6), 7, F(5), F(21, 2), F(2, 49)),
           ((1, 2, 2), 3, F(5), F(21, 2), F(-2, 9)), ((2, -1, 2), 3, F(3), F(9, 2), F(0)), ((1, 2, 2), 3, F(3, 2), F(0), F(1, 6))]
    ok_k = True; ok_h = True; ok_kap = True; ok_kapstd = True; ok_bsx = True; kaps = []
    for (p, rho0, M, s, kap) in HOR:
        pt, e, E = C3.frame_at(p, rho0, M, s); om, Gm = engine_G(Gv, S, e); xi = [e[a].get(1, {}) for a in range(4)]
        B0 = at0m(B_jet(Gv, om, xi, E, 0)); x0 = [at0(q, 4) for q in xi]; Bl = [[SQ[a] * B0[a][c] for c in range(4)] for a in range(4)]
        ok_k &= all(Bl[a][c] + Bl[c][a] == 0 for a in range(4) for c in range(4))
        th, s2, w2, _ = screen(B0, x0); acc = [sum(B0[a][b] * x0[b] for b in range(4)) for a in range(4)]
        ok_h &= (dot(x0, x0) == 0 and th == 0 and s2 == 0 and w2 == 0 and ricci_NN(Gm, x0) == 0)
        kk = next(acc[a] / x0[a] for a in range(4) if x0[a] != 0); ok_kap &= (acc == [kk * x for x in x0] and kk == kap); kaps.append(kk)
        r = F(rho0); ok_kapstd &= (kap == M / r ** 2 - 2 * s / r ** 3 and 1 - 2 * M / r + 2 * s / r ** 2 == 0); ok_bsx &= (B0 == std_B(e, E, xi))
    chk('bit', ok_k, 'Killing equation nabla_(a xi_b) = 0 for xi = d_t at the 6 horizon points (engine)')
    chk('bit', ok_h, 'on the horizon: xi.xi = 0, theta = sigma^2 = w^2 = 0 for the generator, and R_ab xi^a xi^b = 0 (from E_a, A4)')
    chk('bit', ok_kap, 'nabla_xi xi = kappa xi on the horizon with kappa = %s at (r+, r-) = (3, 1) [r+, r-], (7, 3) [r+, r-], extremal 3, Schwarzschild 3' % ', '.join(str(k) for k in kaps))
    chk('std', ok_kapstd, 'kappa = (1/2) d g_tt/d rho = M/r^2 - 2s/r^3 at g_tt(r) = 0 (closed form; advanced chart, future horizon: + kappa)')
    chk('bit==std', ok_bsx, 'B = nabla xi: engine = Christoffel route at the 6 horizon points')
    ok_off = True
    for (M, s, p), (pt, e, E, om, Gm) in list(RNdata.items())[:7]:
        xi0 = [at0(e[a].get(1, {}), 4) for a in range(4)]; B0 = at0m(B_jet(Gv, om, [e[a].get(1, {}) for a in range(4)], E, 0)); Bl = [[SQ[a] * B0[a][c] for c in range(4)] for a in range(4)]
        ok_k &= all(Bl[a][c] + Bl[c][a] == 0 for a in range(4) for c in range(4)); ok_off &= (dot(xi0, xi0) != 0 and ricci_NN(Gm, xi0) != 0)
    chk('bit', ok_k, 'the Killing equation also holds at the 7 points off the horizon')
    chk('ctl', ok_off, 'control xi off the horizon (7 points, s = 1/2): xi.xi != 0 and R_xi xi != 0: a non-null vector breaks R_NN = 0')
    tick('part 2')

    # ================================================================================== 3. gradient (eikonal) congruences with shear and R_NN != 0
    head('3. gradient congruences N = grad S, S eikonal to third order: geodesic at the point, sheared, R_NN != 0')
    DIRS = [null_from(u) for u in ((1, 2, 2, 3), (2, -3, 6, 7), (-4, 4, 7, 9))]
    ok_con = True; ok_bs3 = True; ok_geo = True; nz_s = False; nz_r = False; ok_K3 = True
    for (p, rho0) in POINTS[:3]:
        pt, e, E, om, Gm = RNdata[(F(1), F(1, 2), p)]
        for nd in DIRS[:2]:
            nfr = lowv(nd); X2 = [[F(0)] * 4 for _ in range(4)]
            for i in range(4):
                for j in range(i, 4): X2[i][j] = X2[j][i] = rnd()
            N, N2 = eikonal_N(e, E, nfr, X2); ok_con &= (N2 == {})
            d = evaluate(Gv, om, E, N, Gm); th, s2, w2, P = screen(d['B0'], d['N0'])
            ok_geo &= (d['acc0'] == [0] * 4 and d['diva'] == 0 and w2 == 0 and th == d['theta']); nz_s |= (s2 != 0); nz_r |= (d['RNN'] != 0)
            ok_bs3 &= (d['B0'] == std_B(e, E, N)); K2 = other_K(d['N0'], aux_null(d['N0']), P, [rnd() for _ in range(4)]); ok_K3 &= (screen(d['B0'], d['N0'], K2)[:3] == (th, s2, w2))
            rows.append(('eikonal', [th ** 2, s2, w2, d['RNN']], d['dth']))
    chk('std', ok_con, 'construction: g^{mu nu} d_mu S d_nu S = 0 on every coefficient of x-degree <= 2 (6 congruences: 3 points x 2 directions, random second derivatives)')
    chk('bit', ok_geo and nz_s and nz_r, 'engine: a = 0 and nabla.a = 0 at the point (geodesic), twist w^2 = 0 (a gradient), theta = tr B, and some sigma^2 != 0, some R_NN != 0')
    chk('bit==std', ok_bs3, 'B = nabla N: engine = Christoffel route, 6 congruences')
    chk('bit', ok_K3, 'theta, sigma^2, w^2 independent of the auxiliary null vector, 6 congruences')
    tick('part 3')

    # ================================================================================== 4. a twisting congruence: Kerr's principal null direction (C2's frame)
    head('4. Kerr (M = 1, a = 1/2) principal null direction l from g2_kerr: twist != 0, vacuum')
    ok_kv = True; ok_bs4 = True; nz_w = False; nk = 0
    kp = GK.rational_kerr_points(F(1, 2), [F(3), F(5)], [(GK.PYTH[0], GK.PYTH[1]), (GK.PYTH[2], GK.PYTH[3])])
    for it in kp[:3]:
        p = tuple(it['p']) if isinstance(it, dict) else tuple(it[0]); r0k = it.get('r') if isinstance(it, dict) else None
        e, E, (lu, ld), _ = GK.kerr_ks_frame_jet(p, F(1), F(1, 2), r0=r0k); om, Gm = engine_G(Gv, S, e)
        d = evaluate(Gv, om, E, lu, Gm); th, s2, w2, _ = screen(d['B0'], d['N0']); nk += 1
        ok_kv &= (d['acc0'] == [0] * 4 and d['diva'] == 0 and d['RNN'] == 0 and all(x == 0 for r_ in Gm for x in r_) and s2 == 0); nz_w |= (w2 != 0)
        ok_bs4 &= (d['B0'] == std_B(e, E, lu)); rows.append(('Kerr l', [th ** 2, s2, w2, d['RNN']], d['dth']))
    chk('bit', ok_kv and nz_w, 'Kerr l at %d rational points: geodesic and affine (a = 0, nabla.a = 0), shear-free (sigma^2 = 0), vacuum (G = 0, R_ll = 0), twist w^2 != 0' % nk)
    chk('bit==std', ok_bs4, 'B = nabla l: engine = Christoffel route on the Kerr frame')
    tick('part 4')

    # ================================================================================== 5. Raychaudhuri: fit the coefficients exactly
    head('5. d theta/d lambda = alpha theta^2 + beta sigma^2 + gamma w^2 + delta R_NN: fit on 4 rows, verify on all %d rows' % len(rows))
    chosen = []
    for i, (_, r_, _) in enumerate(rows):
        if rank_exact([rows[j][1] for j in chosen] + [r_]) > len(chosen): chosen.append(i)
        if len(chosen) == 4: break
    coef = gauss_solve([rows[i][1] for i in chosen], [rows[i][2] for i in chosen]) if len(chosen) == 4 else None
    print('    rows used for the fit: %s; coefficients (alpha, beta, gamma, delta) = %s' % ([rows[i][0] for i in chosen], coef))
    ok_all = coef is not None and all(sum(c * x for c, x in zip(coef, r_)) == rhs for (_, r_, rhs) in rows)
    chk('bit', ok_all, 'one set of coefficients fits all %d rows (RN l, eikonal congruences, Kerr l)' % len(rows))
    chk('bit', coef == [F(-1, 2), F(-1), F(1), F(-1)], 'the coefficients are (-1/2, -1, +1, -1): d theta/d lambda = -theta^2/2 - sigma^2 + w^2 - R_ab N^a N^b')
    chk('ctl', not all(F(-1, 3) * r_[0] - r_[1] + r_[2] - r_[3] == rhs for (_, r_, rhs) in rows), 'control: the coefficient -1/3 on theta^2 (the timelike value) fails')
    tick('part 5')

    # ================================================================================== 6. the unprojected identity for any vector field, and the torsion control
    head('6. N(theta) = nabla.a - tr B^2 - Ric(N, N) for random polynomial vector fields (no null, no geodesic assumption); a frame with torsion breaks it')
    ok_id = True; ok_tor = True; ok_nn = True; nid = 0
    for (p, rho0) in POINTS[:3]:
        pt, e, E, om, Gm = RNdata[(F(1), F(1, 2), p)]
        for _ in range(2):
            N = [padd(gs.rpoly(rng, 4, 2, .5), const(4, c0)) for c0 in (F(3), F(1, 2), F(-1, 3), F(1, 4))]; d = evaluate(Gv, om, E, N, Gm); nid += 1
            ok_id &= (d['dth'] == d['diva'] - d['trB2'] - d['RNN']); ok_nn &= (dot(d['N0'], d['N0']) != 0)
        omt = [Gv.Fm.add(om[A], {1 << mu: const(4, rnd()) for mu in range(4)}) for A in range(Gv.G)]
        _, Gmt = engine_G(Gv, S, e, om=omt); _, _, (lu, ld) = ks_frame_jet(pt, F(rho0), *C3.rn_jets(F(1), F(1, 2), rho0)); dt_ = evaluate(Gv, omt, E, lu, Gmt)
        ok_tor &= (dt_['dth'] != dt_['diva'] - dt_['trB2'] - dt_['RNN'])
    chk('bit', ok_id and ok_nn, 'N(theta) = nabla.a - tr B^2 - Ric(N, N) exactly for %d random vector fields (non-null, non-geodesic) at 3 points: the Ricci identity behind Raychaudhuri' % nid)
    chk('ctl', ok_tor, 'control: omega + a random constant contorsion (torsion != 0): the identity fails for l at 3 points')
    rows_t = []
    for (p, rho0) in POINTS[:2]:
        pt, e, E, om, Gm = RNdata[(F(1), F(1, 2), p)]; _, _, (lu, ld) = ks_frame_jet(pt, F(rho0), *C3.rn_jets(F(1), F(1, 2), rho0))
        Nt = [lu[0]] + [scale(lu[i], F(2, 3)) for i in (1, 2, 3)]; d = evaluate(Gv, om, E, Nt, Gm); th, s2, w2, _ = screen(d['B0'], d['N0'])
        rows_t.append(d['dth'] == -th ** 2 / 2 - s2 + w2 - d['RNN'])
    chk('ctl', not all(rows_t), 'control: the timelike field (1, -(2/3) xhat): the projected form -theta^2/2 - sigma^2 + w^2 - R_NN fails')
    tick('part 6')

    # ================================================================================== 7. null energy of the Maxwell source and focusing
    head('7. Ric(N, N) = kappa T_NN >= 0 for random rational null N at the 7 points (Maxwell stress of C3, RN with s = 1/2, Q = 1, kappa = 4 s/Q^2 = 2)')
    M, s, Q = F(1), F(1, 2), F(1); kap = 4 * s / Q ** 2
    ok_e = True; ok_cf = True; ok_pos = True; ok_rad = True; ok_std = True; ok_sg = True; ok_sp = True; nN = 0
    for (p, rho0) in POINTS:
        pt, e, E, om, Gm = RNdata[(M, s, p)]; mx = C3.maxwell_on_frame(Gv, pt, rho0, e, E, Q); Tm = mx['Tm']
        Tf = H.maxwell_T_bit(H.bivector(mx['Fl0'], SQ), SQ, F(1, 2)); Gstd = std_G_frame(p, rho0, M, s, e); r = F(rho0); xh = [F(x) / r for x in p]
        for u in UNITS:
            for sgn in (1, -1):
                N = null_from(u); N = [N[0]] + [sgn * x for x in N[1:]]; nN += 1
                RN_, TN = ricci_NN(Gm, N), H.contract_NN(Tm, N, SQ); perp2 = sum(x * x for x in N[1:]) - sum(N[1 + i] * xh[i] for i in range(3)) ** 2
                ok_e &= (RN_ == kap * TN); ok_cf &= (TN == Q ** 2 / r ** 4 * perp2); ok_pos &= (TN >= 0 and RN_ >= 0); ok_std &= (ricci_NN(Gstd, N) == RN_)
                ok_sg &= (perp2 == 0 or H.contract_NN(Tf, N, SQ) < 0)
        for sgn in (1, -1):
            Nr = [F(1)] + [sgn * x for x in xh]; ok_rad &= (H.contract_NN(Tm, Nr, SQ) == 0 and ricci_NN(Gm, Nr) == 0)
        Ns = [F(0)] + xh; ok_sp &= (H.contract_NN(Tm, Ns, SQ) < 0 and ricci_NN(Gm, Ns) < 0)
    chk('bit', ok_e, 'Ric(N, N) (engine, E_a through A4) = kappa T_NN (bit-rule stress) with kappa = 4 s/Q^2, %d null vectors at 7 points' % nN)
    chk('std', ok_cf, 'T_NN = (Q^2/rho^4) |N_perp|^2 (closed form; N_perp the frame components orthogonal to xhat)')
    chk('bit', ok_pos and ok_rad, 'T_NN >= 0 and R_NN >= 0 for every null N (focusing: d theta/d lambda <= -theta^2/2 - sigma^2 for twist-free congruences); both are 0 exactly on the two radial null directions (1, +-xhat)')
    chk('bit==std', ok_std, 'Ric(N, N) from the engine = from the Christoffel-route Einstein tensor (C1 std_G), all null vectors and points')
    chk('ctl', ok_sg, 'control: the stress +1/2 F a F gives T_NN < 0 for every non-radial null N')
    chk('ctl', ok_sp, 'control: the spacelike radial vector (0, xhat): T_NN < 0 and R_NN < 0 (a non-null vector breaks the sign statement)')
    tick('part 7')
    finish('F1')

if __name__ == '__main__': main()
