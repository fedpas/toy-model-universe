#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""duplib: comparison helpers of dup_6.py. Imports the step modules of this folder read-only; never edits them; writes no bytecode."""
import os, sys, time, importlib
sys.dont_write_bytecode = True                       # never write __pycache__ next to the step modules
HERE = os.path.dirname(os.path.abspath(__file__))
G2 = HERE
sys.path.insert(0, G2)
from b1lib import *                                  # engine helpers (chk, head, finish, F, ...)
from fractions import Fraction as F
T0 = time.time()
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
def versions(*names):
    """log each module's file and modification time, so a comparison is tied to a version"""
    for nm in names:
        m = sys.modules.get(nm) or importlib.import_module(nm)
        print('  module %-22s %s  mtime %s' % (nm, os.path.relpath(m.__file__, G2), time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(m.__file__)))), flush=True)
def tdeg(p, deg=None, ns=4):
    return {k: F(v) for k, v in p.items() if v != 0 and (deg is None or sum(k[:ns]) <= deg)}
def poly_cmp(p, q, deg=None, ns=4):
    """(number of coefficients compared, number differing, max |difference|)"""
    a, b = tdeg(p, deg, ns), tdeg(q, deg, ns); keys = set(a) | set(b)
    d = [abs(a.get(k, F(0)) - b.get(k, F(0))) for k in keys]; nd = sum(1 for x in d if x != 0)
    return len(keys), nd, (max(d) if d else F(0))
def acc(tot, r): return (tot[0] + r[0], tot[1] + r[1], max(tot[2], r[2]))
def frame_cmp(e1, e2, deg=None, n=4, ns=4):
    tot = (0, 0, F(0))
    for a in range(n):
        for mu in range(n): tot = acc(tot, poly_cmp(e1[a].get(1 << mu, {}), e2[a].get(1 << mu, {}), deg, ns))
    return tot
def E_cmp(E1, E2, deg=None, n=4, ns=4):
    tot = (0, 0, F(0))
    for mu in range(n):
        for a in range(n): tot = acc(tot, poly_cmp(E1[mu][a] or {}, E2[mu][a] or {}, deg, ns))
    return tot
def form_cmp(X, Y, deg=None, ns=4):
    tot = (0, 0, F(0))
    for m in set(X) | set(Y): tot = acc(tot, poly_cmp(X.get(m, {}), Y.get(m, {}), deg, ns))
    return tot
def mat_cmp(A, B):
    """numbers: (entries, differing, max |diff|)"""
    d = [abs(F(A[i][j]) - F(B[i][j])) for i in range(len(A)) for j in range(len(A[0]))]
    return len(d), sum(1 for x in d if x != 0), max(d)
ROWS = []
def same(label, r, expect=True, item=''):
    """r = (compared, differing, max|diff|): a comparison (expect=True: identical) or a control (expect=False: must differ)"""
    ok = (r[1] == 0 and r[0] > 0) if expect else (r[1] > 0)
    chk('cmp' if expect else 'ctl', ok, '%s: %d coefficients compared, %d differ, max |diff| = %s' % (label, r[0], r[1], r[2]))
    ROWS.append((item, label, r, expect, ok)); return ok
def fmt_mat(Mx): return '[' + '; '.join(' '.join(str(x) for x in row) for row in Mx) + ']'
def sum_r(rs):
    rs = list(rs); return (sum(r[0] for r in rs), sum(r[1] for r in rs), max([r[2] for r in rs] or [F(0)]))
