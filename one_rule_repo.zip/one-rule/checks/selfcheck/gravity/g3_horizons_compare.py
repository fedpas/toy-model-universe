#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G3, part P5.  The page table of 16 Jan 2018 propagated with the Atlas force law to 9 Oct - 8 Nov 2026 and compared with three JPL Horizons
OBSERVER tables (geocentric astrometric R.A., DEC, delta of the Sun, Mercury, Venus; 31 daily rows).   python3 g3_horizons_compare.py

 Data classes: DC1 = the page table (PLANETS of pgadyn_selfcheck.py); DC2 = the three Horizons observer tables.  DC2 is not the source of DC1.
 Tags: [bit] the Atlas's own numbers / code; [std] a route that never touches the model (the Horizons tables, textbook geometry, independent integrations);
       [bit==std] compared; [ctl] a wrong version that must fail.
 Conventions: table epoch 16 Jan 2018 00:00 TDB; table frame = barycentric ecliptic J2000 (to be tested); rows are UTC and sit at TDB = UTC + 69.184 s;
 astrometric = light time only (iterated), no aberration, no deflection."""
import sys, os, time, json, math, subprocess, datetime
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from b1lib import head, chk, finish
import numpy as np
from fractions import Fraction as Fr
import g3_lib as lib

NUM = {}
OUT = os.path.join(lib.G2, 'logs', 'g3_horizons_compare.numbers.json')
AU, C = lib.AU_KM, lib.C_KMS
R_EQ = lib.rot_ecl_to_eq()
EPOCH, D0 = datetime.date(2018, 1, 16), datetime.date(2026, 10, 9)
NDAYS = lib.days_between(EPOCH, D0)
NROW = 31
BODIES = ['Sun', 'Mercury', 'Venus']
IDX = {'Sun': 0, 'Mercury': 1, 'Venus': 2, 'Earth': 3}
SHIFT = lib.TT_MINUS_UTC

def t_rows(shift=SHIFT, day_shift=0.0): return (NDAYS + np.arange(NROW) - day_shift) * 86400.0 + shift

# ------------------------------------------------------------------------------------------------- model variants
def mu_A(m): return lib.G_ATLAS * m
def mu_B(m, G_other=lib.G_ATLAS):
    mu = G_other * m; mu[0] = float(Fr(lib.hz_header('sun')['GM'])); mu[1] = float(Fr(lib.hz_header('mercury')['GM'])); mu[2] = float(Fr(lib.hz_header('venus')['GM'])); return mu

def propagate(mu, x, v, t_end, power=3.0, rtol=1e-12):
    return lib.flow(x, v, t_end, mu, power, rtol=rtol, dense=True)

# ------------------------------------------------------------------------------------------------- geometry
def model_geo(sol, tgt, t, R, light=True, obs_off=None):
    """astrometric geocentric R.A., DEC (deg), delta (au) and the light time (s): tau = |r_T(t - tau) - r_obs(t)|/c, iterated"""
    xe = sol.sol(t)[9:12].copy()
    if obs_off is not None: xe = xe + obs_off(t)
    tau = 0.0
    for _ in range(20):
        yt = sol.sol(t - tau) if light else sol.sol(t)
        rho = yt[3 * tgt:3 * tgt + 3] - xe; tn = float(np.linalg.norm(rho)) / C if light else 0.0
        done = abs(tn - tau) < 1e-11; tau = tn
        if done or not light: break
    yt = sol.sol(t - tau) if light else sol.sol(t); rho = yt[3 * tgt:3 * tgt + 3] - xe
    ra, de = lib.ra_dec_deg(R @ rho)
    return ra, de, float(np.linalg.norm(rho)) / AU, tau

def geo_all(sol, tr, R=R_EQ, light=True, obs_off=None):
    out = {}
    for nm in BODIES:
        o = [model_geo(sol, IDX[nm], t, R, light, obs_off) for t in tr]
        out[nm] = dict(ra=np.array([a[0] for a in o]), dec=np.array([a[1] for a in o]), delta=np.array([a[2] for a in o]), tau=np.array([a[3] for a in o]))
    return out

def wrap180(a): return (np.asarray(a) + 180.0) % 360.0 - 180.0

def compare(mod, rows_by):
    out = {}
    for nm in BODIES:
        rw = rows_by[nm]; ra = np.array([r['ra'] for r in rw]); de = np.array([r['dec'] for r in rw]); dl = np.array([r['delta'] for r in rw])
        dra = wrap180(mod[nm]['ra'] - ra) * np.cos(np.radians(de)); dde = mod[nm]['dec'] - de
        sep = np.array([lib.sep_arcsec(mod[nm]['ra'][k], mod[nm]['dec'][k], ra[k], de[k]) for k in range(len(ra))])
        out[nm] = dict(dra=dra, ddec=dde, sep=sep, ddelta=mod[nm]['delta'] - dl, rel=(mod[nm]['delta'] - dl) / dl)
    return out

def stat(a): a = np.abs(np.asarray(a)); return float(a.max()), float(np.median(a))

def show(label, cmp):
    for nm in BODIES:
        c = cmp[nm]; s = stat(c['sep']); r = stat(c['dra']); d = stat(c['ddec']); dl = stat(c['ddelta']); rl = stat(c['rel'])
        print('  %-30s %-8s sep max %11.2f\" med %11.2f\" | dRA cos(dec) max %10.6f med %10.6f deg | dDEC max %10.6f med %10.6f deg | d(delta) max %.3e med %.3e au (rel max %.2e)' % (label, nm, s[0], s[1], r[0], r[1], d[0], d[1], dl[0], dl[1], rl[0]))

def summary_dict(cmp): return {nm: dict(sep_max=stat(cmp[nm]['sep'])[0], sep_med=stat(cmp[nm]['sep'])[1], dra_max_deg=stat(cmp[nm]['dra'])[0], dra_med_deg=stat(cmp[nm]['dra'])[1], ddec_max_deg=stat(cmp[nm]['ddec'])[0], ddec_med_deg=stat(cmp[nm]['ddec'])[1], ddelta_max_au=stat(cmp[nm]['ddelta'])[0], ddelta_med_au=stat(cmp[nm]['ddelta'])[1], rel_max=stat(cmp[nm]['rel'])[0]) for nm in BODIES}

def obs_vectors(rows):
    ra = np.radians([r['ra'] for r in rows]); de = np.radians([r['dec'] for r in rows]); d = np.array([r['delta'] for r in rows]) * AU
    return np.stack([d * np.cos(de) * np.cos(ra), d * np.cos(de) * np.sin(ra), d * np.sin(de)], 1)

def ang_arcsec(a, b):
    cr = np.linalg.norm(np.cross(a, b), axis=1); dt = (a * b).sum(1); return np.degrees(np.arctan2(cr, dt)) * 3600.0

def htest(sol, tr, G, R=R_EQ):
    """Earth-independent test: heliocentric vectors built from the three observer tables (target minus Sun, both with their light time) against the model's"""
    tauS = np.linalg.norm(G['Sun'], axis=1) / C
    Ho = {'Earth': -G['Sun'], 'Mercury': G['Mercury'] - G['Sun'], 'Venus': G['Venus'] - G['Sun']}
    Hm = {nm: np.zeros((NROW, 3)) for nm in Ho}
    for k, t in enumerate(tr):
        rS = sol.sol(t - tauS[k])[0:3]; Hm['Earth'][k] = R @ (sol.sol(t)[9:12] - rS)
        for nm in ('Mercury', 'Venus'):
            tau = np.linalg.norm(G[nm][k]) / C; rX = sol.sol(t - tau)[3 * IDX[nm]:3 * IDX[nm] + 3]; Hm[nm][k] = R @ (rX - rS)
    res = {}
    for nm in Ho:
        ho = Ho[nm]; d = Hm[nm] - ho; rh = ho / np.linalg.norm(ho, axis=1)[:, None]; n = np.cross(ho[0], ho[-1]); n /= np.linalg.norm(n); th = np.cross(n[None, :], rh)
        res[nm] = dict(hm=Hm[nm], ang=ang_arcsec(Hm[nm], ho), rad=(d * rh).sum(1), along=(d * th).sum(1), normal=(d * n[None, :]).sum(1), dist=np.linalg.norm(d, axis=1), rdist=np.linalg.norm(ho, axis=1) / AU)
    return res

def show_h(label, hres):
    for nm in ('Earth', 'Mercury', 'Venus'):
        h = hres[nm]
        print('  %-26s %-8s helio. direction error max %11.2f\" med %11.2f\" (%.4f deg) | km: radial %10.3e along-track %10.3e normal %10.3e (max abs), |error| max %.3e  (r = %.3f..%.3f au)' % (label, nm, h['ang'].max(), np.median(h['ang']), h['ang'].max() / 3600.0, np.abs(h['rad']).max(), np.abs(h['along']).max(), np.abs(h['normal']).max(), h['dist'].max(), h['rdist'].min(), h['rdist'].max()))

def sun_resid(sol, tr, rows_sun, R=R_EQ, obs_off=None):
    o = [model_geo(sol, 0, t, R, True, obs_off) for t in tr]; out = []
    for k, (ra, de, dl, tau) in enumerate(o):
        out += [wrap180(ra - rows_sun[k]['ra']) * math.cos(math.radians(rows_sun[k]['dec'])) * 3600.0, (de - rows_sun[k]['dec']) * 3600.0]
    return np.array(out)

# ------------------------------------------------------------------------------------------------- the lunar variant (memory inputs, flagged)
MU_MOON = 7.342e22 / (5.97219e24 + 7.342e22)       # Moon/(Earth+Moon) with the Atlas's masses (moon_rows: 7.342E22)
D_MOON, V_MOON = 405000.0, 0.97                    # km, km/s near apogee of 14 Jan 2018 (memory, +-5 %)
NEWMOON_LAG_H = 26.2                               # new moon 17 Jan 2018 about 02:17 UTC, epoch 16 Jan 2018 00:00 (memory, unverified)
N_MOON = 2 * math.pi / (27.321661 * 86400.0)
def moon_variant(m, x, v, D_MOON=D_MOON, V_MOON=V_MOON, lag_h=NEWMOON_LAG_H):
    rE = x[3] - x[0]; lamE = math.atan2(rE[1], rE[0]); elong = math.radians(360.0 / 29.530589 * lag_h / 24.0); lamM = lamE + math.pi - elong
    rm = D_MOON * np.array([math.cos(lamM), math.sin(lamM), 0.0]); vm = V_MOON * np.array([-math.sin(lamM), math.cos(lamM), 0.0])
    x2, v2 = x.copy(), v.copy(); x2[3] = x[3] + MU_MOON * rm; v2[3] = v[3] + MU_MOON * vm
    def off(t): return -MU_MOON * D_MOON * np.array([math.cos(lamM + N_MOON * t), math.sin(lamM + N_MOON * t), 0.0])
    return x2, v2, off, dict(lamM_deg=math.degrees(lamM), elong_deg=math.degrees(elong), dv_centre_minus_emb=(-MU_MOON * vm), dx_centre_minus_emb=(-MU_MOON * rm))

OUTER = {'Saturn': (3.7931e7, 9.55), 'Uranus': (5.794e6, 19.19), 'Neptune': (6.835e6, 30.07)}   # GM km^3/s^2, a au: textbook values from memory, 3 digits; used only to size an effect
def with_outer(mu, x, v, phases):
    xs, vs, ms = [x], [v], [mu]; GMs = mu[0]
    for (nm, (gm, a)), ph in zip(OUTER.items(), phases):
        r = np.array([math.cos(ph), math.sin(ph), 0.0]) * a * AU; w = math.sqrt(GMs / (a * AU)) * np.array([-math.sin(ph), math.cos(ph), 0.0])
        xs.append((x[0] + r)[None, :]); vs.append((v[0] + w)[None, :]); ms.append(np.array([gm]))
    return np.vstack(xs), np.vstack(vs), np.concatenate(ms)

# ------------------------------------------------------------------------------------------------- the run
def main():
    T_all = time.time()
    m, x, v = lib.table_arrays()
    TB = {nm.capitalize(): lib.read_hz(nm)[1] for nm in ('sun', 'mercury', 'venus')}
    G = {nm: obs_vectors(TB[nm]) for nm in BODIES}
    tr = t_rows(); t_end = tr[-1] + 100.0
    print('G3  part P5.  Elapsed from 16 Jan 2018 to 9 Oct 2026: %d days; rows at TDB = UTC + %.3f s; first row t = %.3f s, last %.3f s' % (NDAYS, SHIFT, tr[0], tr[-1]))

    # ---------------------------------------------------------------------------------------- E0 data, frame, dates
    head('E0  the data and the geometry (before any comparison)')
    ok_n = all(len(TB[nm]) == NROW for nm in BODIES); dates = [r['date'] for r in TB['Sun']]
    ok_d = all(dates[k] == D0 + datetime.timedelta(days=k) for k in range(NROW)) and all([r['date'] for r in TB[nm]] == dates for nm in BODIES)
    chk('std', ok_n and ok_d, '31 rows in each table, daily from %s to %s, same dates in all three, all at 00:00 UT' % (dates[0], dates[-1]))
    chk('bit==std', NDAYS == 8 * 365 + 2 + 266 == 3188, 'days from 2018-01-16 to 2026-10-09 by datetime = %d = 8 x 365 + 2 leap days (2020, 2024) + 266' % NDAYS)
    mx = 0.0
    for nm in BODIES:
        for r in TB[nm]:
            t = r['raw'].split(); ra = 15 * (float(t[2]) + float(t[3]) / 60 + float(t[4]) / 3600); sg = -1 if t[5].startswith('-') else 1; de = sg * (abs(float(t[5])) + float(t[6]) / 60 + float(t[7]) / 3600)
            mx = max(mx, abs(ra - r['ra']), abs(de - r['dec']), abs(float(t[10]) - r['delta']) * 1e3)
    chk('bit==std', mx < 1e-12, 'exact Fraction parse of the 93 rows (HMS, DMS, delta) equals an independent float parse to %.1e' % mx)
    ra_p, de_p = lib.ra_dec_deg(R_EQ @ np.array([0.0, 0.0, 1.0])); eps_deg = lib.OBLIQ_ARCSEC / 3600.0
    chk('std', abs(ra_p - 270.0) < 1e-9 and abs(de_p - (90.0 - eps_deg)) < 1e-9, 'the ecliptic pole maps to R.A. %.9f deg, DEC %.9f deg (textbook: 270, 90 - %.6f)' % (ra_p, de_p, eps_deg))
    beta = []
    for r in TB['Sun']:
        u = np.array([math.cos(math.radians(r['dec'])) * math.cos(math.radians(r['ra'])), math.cos(math.radians(r['dec'])) * math.sin(math.radians(r['ra'])), math.sin(math.radians(r['dec']))]); e = R_EQ.T @ u; beta.append(math.degrees(math.asin(e[2])))
    chk('std', max(abs(b) for b in beta) < 0.01, 'the Sun table itself, rotated to the ecliptic of J2000: |ecliptic latitude| max %.5f deg over the 31 rows (< 0.01); read as equatorial it would be up to %.1f deg' % (max(abs(b) for b in beta), max(abs(r['dec']) for r in TB['Sun'])))
    NUM['sun_ecl_lat_max_deg'] = max(abs(b) for b in beta)
    hs = {nm: np.linalg.norm(G[nm] - G['Sun'], axis=1) / AU for nm in ('Mercury', 'Venus')}
    chk('std', 0.3075 * 0.99 < hs['Mercury'].min() and hs['Mercury'].max() < 0.4667 * 1.01 and 0.7184 * 0.995 < hs['Venus'].min() and hs['Venus'].max() < 0.7282 * 1.005, 'heliocentric distances rebuilt from the three tables stay inside the Kepler bounds a(1 -+ e): Mercury %.4f..%.4f au (0.3075..0.4667), Venus %.4f..%.4f au (0.7184..0.7282)' % (hs['Mercury'].min(), hs['Mercury'].max(), hs['Venus'].min(), hs['Venus'].max()))

    # ---------------------------------------------------------------------------------------- variants A and B
    head('E1  propagation of the page table and comparison with the three Horizons tables (geocentric astrometric R.A., DEC in deg, delta in au)')
    t1 = time.time(); muA = mu_A(m); muB = mu_B(m); muB2 = mu_B(m, G_other=6.67430e-20)
    solA = propagate(muA, x, v, t_end); print('  [time] one DOP853 propagation (rtol 1e-12): %.1f s, %d steps' % (time.time() - t1, len(solA.t) - 1))
    solB = propagate(muB, x, v, t_end); solB2 = propagate(muB2, x, v, t_end)
    cA = compare(geo_all(solA, tr), TB); cB = compare(geo_all(solB, tr), TB); cB2 = compare(geo_all(solB2, tr), TB)
    show('A: Atlas G and masses', cA); show('B: header GM (Sun, Merc, Venus)', cB); show('B2: B, G=6.6743e-11 for E, M, J', cB2)
    NUM['A'] = summary_dict(cA); NUM['B'] = summary_dict(cB); NUM['B2'] = summary_dict(cB2)
    hA = htest(solA, tr, G); hB = htest(solB, tr, G); show_h('A', hA); show_h('B', hB)
    NUM['hA'] = {nm: dict(ang_max=float(hA[nm]['ang'].max()), ang_med=float(np.median(hA[nm]['ang'])), along_max_km=float(np.abs(hA[nm]['along']).max()), rad_max_km=float(np.abs(hA[nm]['rad']).max()), normal_max_km=float(np.abs(hA[nm]['normal']).max())) for nm in hA}
    NUM['hB'] = {nm: dict(ang_max=float(hB[nm]['ang'].max()), ang_med=float(np.median(hB[nm]['ang'])), along_max_km=float(np.abs(hB[nm]['along']).max()), rad_max_km=float(np.abs(hB[nm]['rad']).max()), normal_max_km=float(np.abs(hB[nm]['normal']).max())) for nm in hB}
    # hypotheses H_G (variant A lags as predicted), pre-declared
    pred = {'Mercury': 6.0, 'Venus': 2.3}
    ok = all(abs(np.median(hA[nm]['ang']) / 3600.0 / pred[nm] - 1) < 0.25 for nm in pred)
    chk('std', ok, 'H_G: in variant A the heliocentric direction errors of Mercury, Venus (median, deg) are %.2f, %.2f; predicted 6.0, 2.3 within 25 %%' % (np.median(hA['Mercury']['ang']) / 3600.0, np.median(hA['Venus']['ang']) / 3600.0))
    chk('std', all(stat(cA[nm]['sep'])[0] > 3600.0 for nm in BODIES), 'variant A: geocentric separation exceeds 1 deg for all three bodies (max %s deg)' % ', '.join('%.2f' % (stat(cA[nm]['sep'])[0] / 3600.0) for nm in BODIES))
    chk('std', all(np.median(hB[nm]['ang']) < np.median(hA[nm]['ang']) / 10.0 for nm in ('Mercury', 'Venus')), 'variant B (header GM) shrinks the heliocentric direction errors of Mercury and Venus by more than 10x: Mercury %.0f\" -> %.0f\", Venus %.0f\" -> %.0f\" (medians)' % (np.median(hA['Mercury']['ang']), np.median(hB['Mercury']['ang']), np.median(hA['Venus']['ang']), np.median(hB['Venus']['ang'])))
    sB = stat(cB['Sun']['sep'])[0] / 3600.0
    chk('std', 3.0 < sB < 4.6, 'H_EMB (first part): variant B, Sun direction error max %.3f deg, predicted 3.8 +- 0.8 deg if the table\'s Earth is the Earth centre (below 0.05 deg if it were the barycentre)' % sB)
    chk('std', max(np.median(hB[nm]['ang']) for nm in ('Mercury', 'Venus')) / 3600.0 < 0.05, 'H_EMB (second part): variant B heliocentric direction errors of Mercury and Venus below 0.05 deg (medians %.4f, %.4f deg)' % (np.median(hB['Mercury']['ang']) / 3600.0, np.median(hB['Venus']['ang']) / 3600.0))
    dB2 = max(abs(NUM['B2'][nm]['sep_max'] - NUM['B'][nm]['sep_max']) for nm in BODIES)
    print('  sensitivity to G of Earth, Mars, Jupiter (6.6723e-11 -> 6.6743e-11): largest change of a body\'s max separation %.2f arcsec' % dB2)
    NUM['dG_other_arcsec'] = dB2
    # time conventions on the Earth-independent test (no fit involved): epoch 00:00 TDB with UTC rows (baseline) against epoch and rows in one scale
    h0 = htest(solB, t_rows(shift=0.0), G); show_h('B, shift 0 (same scale)', h0)
    NUM['hB_shift0'] = {nm: dict(ang_max=float(h0[nm]['ang'].max()), ang_med=float(np.median(h0[nm]['ang'])), along_max_km=float(np.abs(h0[nm]['along']).max())) for nm in h0}
    pref = {nm: float(np.median(h0[nm]['ang'])) / float(np.median(hB[nm]['ang'])) for nm in ('Mercury', 'Venus')}
    print('  median heliocentric error with shift 0 / with +69.184 s: Mercury %.2f, Venus %.2f  (a 69 s shift moves Mercury %.0f km = %.1f arcsec at 0.39 au, Venus %.0f km)' % (pref['Mercury'], pref['Venus'], 47.9 * 69.184, 47.9 * 69.184 / (0.387 * AU) * 206265, 35.0 * 69.184))
    chk('std', max(np.median(h0[nm]['ang']) for nm in ('Mercury', 'Venus')) / 3600.0 < 0.05, 'the time-scale convention (69.184 s) changes the heliocentric errors of Mercury, Venus by factors %.2f, %.2f only; both conventions stay below 0.05 deg' % (pref['Mercury'], pref['Venus']))
    # sensitivity to the printed digits of the table (relative 1e-15 on every x, v) and to the masses of Earth, Mars, Jupiter (relative 1e-3)
    rg = np.random.RandomState(7); xp = x * (1 + 1e-15 * rg.uniform(-1, 1, x.shape)); vp = v * (1 + 1e-15 * rg.uniform(-1, 1, v.shape)); sP = propagate(muB, xp, vp, t_end); hP = htest(sP, tr, G)
    dpert = max(float(ang_arcsec(hP[nm]['hm'], hB[nm]['hm']).max()) for nm in ('Earth', 'Mercury', 'Venus'))
    muP = muB.copy(); muP[3:] = muP[3:] * (1 + 1e-3 * np.array([1.0, -1.0, 1.0])); sM_ = propagate(muP, x, v, t_end); hM_ = htest(sM_, tr, G)
    dmass = max(float(ang_arcsec(hM_[nm]['hm'], hB[nm]['hm']).max()) for nm in ('Earth', 'Mercury', 'Venus'))
    print('  sensitivity: every x, v of the table changed by a random relative 1e-15 (the last printed digit): heliocentric directions change by at most %.2e arcsec;  masses of Earth, Mars, Jupiter changed by 1e-3: at most %.2e arcsec' % (dpert, dmass))
    NUM['sens_digits_arcsec'] = dpert; NUM['sens_mass1e-3_arcsec'] = dmass
    chk('std', dpert < 0.1 and dmass < 1.0, 'the table\'s digits (%.1e arcsec) and the printed precision of the masses of Earth, Mars, Jupiter (%.1e arcsec for a 1e-3 change) are not what limits the comparison' % (dpert, dmass))

    # ---------------------------------------------------------------------------------------- the Earth: fit of an along-track velocity offset to the SUN table only
    head('E2  the Earth: the table\'s Earth as the Earth centre. One 3-parameter fit (velocity offset of the Earth, m/s), to the Sun table only; Mercury and Venus are then held out')
    t1 = time.time()
    def resid(dv):
        vv = v.copy(); vv[3] = vv[3] + np.asarray(dv) / 1000.0; return sun_resid(propagate(muB, x, vv, t_end, rtol=1e-11), tr, TB['Sun'])
    dv = np.zeros(3); r0 = resid(dv); print('  start: Sun residual rms %.1f arcsec' % math.sqrt((r0 ** 2).mean()))
    for it in range(3):
        J = np.zeros((len(r0), 3))
        for c in range(3):
            d = dv.copy(); d[c] += 0.5; J[:, c] = (resid(d) - r0) / 0.5
        step = np.linalg.lstsq(J, -r0, rcond=None)[0]; dv = dv + step; r0 = resid(dv)
        print('  Gauss-Newton %d: dv = (%+.3f, %+.3f, %+.3f) m/s (ecliptic x, y, z), Sun residual rms %.2f arcsec' % (it + 1, dv[0], dv[1], dv[2], math.sqrt((r0 ** 2).mean())))
    rE = x[3] - x[0]; vE = v[3] - v[0]; rh = rE / np.linalg.norm(rE); nh = np.cross(rE, vE); nh /= np.linalg.norm(nh); th = np.cross(nh, rh)
    comp = (float(dv @ th), float(dv @ rh), float(dv @ nh))
    x2, v2, off, info = moon_variant(m, x, v); dvm = info['dv_centre_minus_emb'] * 1000.0; compm = (float(dvm @ th), float(dvm @ rh), float(dvm @ nh))
    print('  fitted offset in the Earth\'s heliocentric frame (along-track, radial, normal): (%+.2f, %+.2f, %+.2f) m/s; |dv| = %.2f m/s.   (time %.0f s)' % (comp[0], comp[1], comp[2], np.linalg.norm(dv), time.time() - t1))
    dvm = -dvm; compm = tuple(-c_ for c_ in compm)          # the correction to ADD to the Earth centre's velocity to reach the barycentre: + mu_Moon v_Moon
    print('  Moon-based prediction of the same correction (barycentre minus Earth centre), memory inputs (new moon 17 Jan 2018 ~02:17 UTC, D = %.0f km, v = %.2f km/s, Moon %.1f deg west of the Sun): velocity (%+.2f, %+.2f, %+.2f) m/s, position offset %.0f km (sunward)' % (D_MOON, V_MOON, info['elong_deg'], compm[0], compm[1], compm[2], np.linalg.norm(info['dx_centre_minus_emb'])))
    muE = muB[0] + muB[3]
    def a_helio(xE, vE): r_ = xE - x[0]; w_ = vE - v[0]; return 1.0 / (2.0 / np.linalg.norm(r_) - (w_ @ w_) / muE)
    vfit_ = v.copy(); vfit_[3] = vfit_[3] + dv / 1000.0
    a0_, aF_, aM_ = a_helio(x[3], v[3]), a_helio(x[3], vfit_[3]), a_helio(x2[3], v2[3]); daF, daM = aF_ / a0_ - 1, aM_ / a0_ - 1
    print('  semi-major axis of the Earth (header GM_Sun + G m_Earth): table state %.6f au; with the fitted velocity offset %.6f au (delta a/a = %+.3e); with the Moon-based barycentre state %.6f au (delta a/a = %+.3e, of which the 4.9e3 km position offset gives %+.1e); STD_A of the Atlas 1.000003 au' % (a0_ / AU, aF_ / AU, daF, aM_ / AU, daM, daM - (a_helio(x[3], v2[3]) / a0_ - 1)))
    NUM['earth_a_AU'] = dict(table=a0_ / AU, fit=aF_ / AU, moon=aM_ / AU, da_fit=daF, da_moon=daM)
    chk('std', abs(daM / daF - 1) < 0.10, 'the fitted velocity offset and the Moon-based barycentre correction (velocity AND position) change the Earth\'s semi-major axis by the same relative amount: %+.3e (fit) and %+.3e (Moon of memory), within %.1f %%' % (daF, daM, 100 * abs(daM / daF - 1)))
    NUM['fit_dv_ms'] = list(map(float, dv)); NUM['fit_dv_frame_ms'] = list(comp); NUM['moon_dv_frame_ms'] = list(compm)
    vfit = v.copy(); vfit[3] = vfit[3] + dv / 1000.0; solF = propagate(muB, x, vfit, t_end); cF = compare(geo_all(solF, tr), TB); hF = htest(solF, tr, G)
    show('B + Earth dv (fit to Sun)', cF); show_h('B + Earth dv', hF); NUM['F'] = summary_dict(cF)
    chk('std', -16.0 < comp[0] < -8.0, 'H_EMB (third part): the fitted along-track velocity offset of the Earth is %+.2f m/s (pre-declared -12 +- 4 m/s)' % comp[0])
    chk('std', stat(cF['Sun']['sep'])[0] < 180.0, 'H_EMB (fourth part): after the fit the Sun direction error is at most %.1f arcsec (< 0.05 deg = 180 arcsec); fitted to this table, so this is a fit and not a test' % stat(cF['Sun']['sep'])[0])
    hold = [stat(cF[nm]['sep'])[0] for nm in ('Mercury', 'Venus')]; before = [stat(cB[nm]['sep'])[0] for nm in ('Mercury', 'Venus')]
    chk('std', all(h < b / 20.0 for h, b in zip(hold, before)), 'held-out tables: the Earth correction fitted to the Sun table alone reduces the geocentric separation of Mercury %.0f\" -> %.0f\" and of Venus %.0f\" -> %.0f\" (max over 31 days) by more than a factor 20' % (before[0], hold[0], before[1], hold[1]))
    # the same without any fit: Earth state replaced by the Earth-Moon barycentre from the Moon of memory, observer displaced by the circular Moon
    muM = muB.copy(); muM[3] = lib.G_ATLAS * (m[3] + 7.342e22); solM = propagate(muM, x2, v2, t_end); cM = compare(geo_all(solM, tr, obs_off=off), TB); show('B + Moon of memory (no fit)', cM); NUM['M'] = summary_dict(cM)
    chk('std', all(stat(cM[nm]['sep'])[0] < stat(cB[nm]['sep'])[0] / 10.0 for nm in BODIES), 'no fit, only the Moon of memory (barycentre as the model body, geocentre displaced by the circular Moon): the max separation falls by more than 10x for all three bodies (Sun %.0f\" -> %.0f\", Mercury %.0f\" -> %.0f\", Venus %.0f\" -> %.0f\")' % tuple(v_ for nm in BODIES for v_ in (stat(cB[nm]['sep'])[0], stat(cM[nm]['sep'])[0])))
    # how much do the memory inputs matter? (D +-5 %, v +-5 %, new-moon lag +-2 h), one propagation each
    sw = {}
    for lab, kw in (('D -5%', dict(D_MOON=0.95 * D_MOON)), ('D +5%', dict(D_MOON=1.05 * D_MOON)), ('v -5%', dict(V_MOON=0.95 * V_MOON)), ('v +5%', dict(V_MOON=1.05 * V_MOON)), ('lag -2 h', dict(lag_h=NEWMOON_LAG_H - 2.0)), ('lag +2 h', dict(lag_h=NEWMOON_LAG_H + 2.0))):
        xq, vq, offq, _ = moon_variant(m, x, v, **kw); sq_ = propagate(muM, xq, vq, t_end, rtol=1e-11); cq = compare(geo_all(sq_, tr, obs_off=offq), TB); sw[lab] = [stat(cq[nm]['sep'])[0] for nm in BODIES]
    print('  Moon inputs varied (max separation Sun, Mercury, Venus, arcsec): ' + '; '.join('%s: %s' % (k_, ', '.join('%.0f' % q for q in v_)) for k_, v_ in sw.items()))
    NUM['moon_input_sweep_arcsec'] = sw
    chk('std', max(v_[0] for v_ in sw.values()) < stat(cB['Sun']['sep'])[0] / 10.0, 'the memory inputs are not tuned: with D, v, lag each varied by 5 %% / 2 h the Sun direction error stays between %.0f\" and %.0f\", always more than 10x below the %.0f\" of the table\'s Earth read as the centre (the 92\" of the central values is partly luck)' % (min(v_[0] for v_ in sw.values()), max(v_[0] for v_ in sw.values()), stat(cB['Sun']['sep'])[0]))

    # ---------------------------------------------------------------------------------------- outer planets, Jupiter, time conventions
    head('E3  what is missing from the model, and the sensitivity to the time convention')
    t1 = time.time(); rng = np.random.RandomState(20261009); gB = geo_all(solB, tr); effG = []; effH = []
    for tri in rng.uniform(0, 2 * math.pi, (6, 3)):
        xo, vo, mo = with_outer(muB, x, v, tri); so = propagate(mo, xo, vo, t_end, rtol=1e-11); gs = geo_all(so, tr); ho = htest(so, tr, G)
        effG.append([max(lib.sep_arcsec(gs[nm]['ra'][k], gs[nm]['dec'][k], gB[nm]['ra'][k], gB[nm]['dec'][k]) for k in range(NROW)) for nm in BODIES])
        effH.append([float(ang_arcsec(ho[nm]['hm'], hB[nm]['hm']).max()) for nm in ('Earth', 'Mercury', 'Venus')])
    eff = np.array(effG); effH = np.array(effH)
    print('  Saturn, Uranus, Neptune added (circular, coplanar, textbook GM and a, 6 random phase triplets): geocentric direction of Sun, Mercury, Venus changes by at most %s arcsec; heliocentric direction of Earth, Mercury, Venus by at most %s arcsec  (%.0f s)' % (', '.join('%.1f' % eff[:, j].max() for j in range(3)), ', '.join('%.1f' % effH[:, j].max() for j in range(3)), time.time() - t1))
    NUM['outer_scan_geo_arcsec'] = [float(eff[:, j].max()) for j in range(3)]; NUM['outer_scan_helio_arcsec'] = [float(effH[:, j].max()) for j in range(3)]
    chk('std', eff[:, 0].max() < 60.0 and effH[:, 1].max() < 30.0 and effH[:, 2].max() < 30.0, 'H_out: the missing outer planets change the Sun direction by at most %.1f\" (pre-declared < 60\") and the Mercury, Venus heliocentric directions by %.1f\", %.1f\" (< 30\")' % (eff[:, 0].max(), effH[:, 1].max(), effH[:, 2].max()))
    muJ = muB.copy(); muJ[5] = 0.0; sJ = propagate(muJ, x, v, t_end, rtol=1e-11); gJ = geo_all(sJ, tr); dJ = max(lib.sep_arcsec(gJ['Sun']['ra'][k], gJ['Sun']['dec'][k], gB['Sun']['ra'][k], gB['Sun']['dec'][k]) for k in range(NROW))
    print('  Jupiter removed from the model: the Sun direction changes by %.0f arcsec' % dJ); NUM['jupiter_removed_sun_arcsec'] = dJ
    chk('ctl', dJ > 2.0 * eff[:, 0].max(), 'control: removing Jupiter (GM 3.3x Saturn\'s) moves the Sun direction by %.0f\" which is more than twice the outer-planet effect %.1f\"' % (dJ, eff[:, 0].max()))
    # time conventions, on variant B + Earth dv (the best model), Sun and Mercury, Venus
    for lab, kw in (('table epoch and rows in the same scale (shift 0, = 00:00 UT)', dict(shift=0.0)), ('epoch +1 day', dict(day_shift=1.0)), ('epoch -1 day', dict(day_shift=-1.0))):
        c = compare(geo_all(solF, t_rows(**kw)), TB); show('F, ' + lab, c); NUM['time_' + lab] = summary_dict(c)
    # ---------------------------------------------------------------------------------------- integrators and light time
    head('E4  independent routes: the page\'s own RK4 (JavaScript) against DOP853; the light time by a second method')
    inp = json.dumps(dict(x=x.tolist(), v=v.tolist(), mass=(muB / lib.G_ATLAS).tolist(), G=lib.G_ATLAS, h=14400.0, steps=(NDAYS + NROW) * 6, every=6))
    t1 = time.time(); pr = subprocess.run(['node', lib.NODE_RUN], input=inp, capture_output=True, text=True, timeout=600); js = json.loads(pr.stdout)
    chk('bit', pr.returncode == 0 and len(js['x']) == (NDAYS + NROW) + 1, 'the page\'s rk4Bodies (h = 14400 s) ran %d steps under node (%.1f s), daily output' % ((NDAYS + NROW) * 6, time.time() - t1))
    dm = np.zeros(6)
    for dd in range(NDAYS, NDAYS + NROW):
        xs = np.array(js['x'][dd]); y = solB.sol(dd * 86400.0)[:18].reshape(6, 3); dm = np.maximum(dm, np.linalg.norm(xs - y, axis=1))
    NUM['js_rk4_vs_dop_km'] = dict(zip(lib.NAMES, map(float, dm)))
    print('  page RK4 (4 h) vs DOP853, positions at the 31 midnights of the table, max over days (km): ' + ', '.join('%s %.2e' % (n, d) for n, d in zip(lib.NAMES, dm)) + '   (1 au at 1 arcsec = %.0f km)' % (AU * math.pi / 180 / 3600))
    chk('bit==std', dm.max() < AU * math.pi / 180 / 3600 * 60, 'the page\'s RK4 at its default step keeps every body within %.2e km of DOP853 after 8.7 years (60 arcsec at 1 au = %.1e km)' % (dm.max(), AU * math.pi / 180 / 3600 * 60))
    worst = 0.0; worst_pos = 0.0
    for k in (0, 15, 30):
        t = tr[k]
        for nm in BODIES:
            ra, de, dl, tau = model_geo(solB, IDX[nm], t, R_EQ)
            xe = solB.sol(t)[9:12]; tau2 = 300.0
            for _ in range(8):                    # Newton on f(tau) = |r_T(t - tau) - r_E(t)| - c tau with the target re-integrated from the state at t (no dense output)
                y0 = solB.sol(t); s = lib.flow(y0[:18].reshape(6, 3), y0[18:].reshape(6, 3), -tau2, muB, rtol=1e-13, t0=0.0)
                yt = s.y[:, -1]; rt = yt[3 * IDX[nm]:3 * IDX[nm] + 3]; vt = yt[18 + 3 * IDX[nm]:18 + 3 * IDX[nm] + 3]; rho = rt - xe; f = np.linalg.norm(rho) - C * tau2; fp = -(rho / np.linalg.norm(rho)) @ vt - C
                dn = -f / fp; tau2 += dn
                if abs(dn) < 1e-9: break
            worst = max(worst, abs(tau2 - tau)); worst_pos = max(worst_pos, np.linalg.norm(rt - solB.sol(t - tau)[3 * IDX[nm]:3 * IDX[nm] + 3]))
    chk('bit==std', worst < 1e-6 and worst_pos < 1.0, 'light time: fixed-point iteration on the dense output vs Newton iteration with the target re-integrated backwards: tau differs by %.1e s, retarded positions by %.1e km (3 dates, 3 bodies)' % (worst, worst_pos))
    NUM['lighttime_two_routes'] = dict(dtau_s=worst, dpos_km=worst_pos)

    # ---------------------------------------------------------------------------------------- synthetic table: plumbing and controls
    head('E5  plumbing and sensitivity on a SYNTHETIC table (the model\'s own output, in Horizons precision): what each ingredient would change')
    base = geo_all(solB, tr); rows_syn = {}
    for nm in BODIES:
        rows_syn[nm] = [dict(ra=round(base[nm]['ra'][k] * 240 * 100) / 100 / 240, dec=round(base[nm]['dec'][k] * 3600 * 10) / 10 / 3600, delta=round(base[nm]['delta'][k] * 1e14) / 1e14) for k in range(NROW)]
    c0 = compare(base, rows_syn); mra = max(stat(c0[nm]['dra'])[0] for nm in BODIES) * 3600; mde = max(stat(c0[nm]['ddec'])[0] for nm in BODIES) * 3600; mdl = max(stat(c0[nm]['ddelta'])[0] for nm in BODIES)
    chk('bit==std', mra < 0.08 and mde < 0.06 and mdl < 1e-13, 'plumbing: the model compared with itself rounded to the table format (RA 0.01 s, DEC 0.1\", delta 14 decimals): residuals %.3f\" in RA cos(dec), %.3f\" in DEC, %.1e au in delta' % (mra, mde, mdl))
    NUM['plumbing'] = dict(ra_arcsec=mra, dec_arcsec=mde, delta_au=mdl)
    def sepmax(c): return max(stat(c[nm]['sep'])[0] for nm in BODIES)
    Gs = {nm: obs_vectors(rows_syn[nm]) for nm in BODIES}; hS = htest(solB, tr, Gs); hSA = htest(solA, tr, Gs); hS0 = htest(solB, t_rows(shift=0.0), Gs); hSd = htest(solB, t_rows(day_shift=1.0), Gs)
    chk('bit==std', max(hS[nm]['ang'].max() for nm in ('Earth', 'Mercury', 'Venus')) < 0.5, 'plumbing of the Earth-independent test: model vs the same model rebuilt from the rounded synthetic tables: heliocentric direction error at most %.3f arcsec for Earth, Mercury, Venus (< 0.5)' % max(hS[nm]['ang'].max() for nm in ('Earth', 'Mercury', 'Venus')))
    NUM['htest_plumbing_arcsec'] = float(max(hS[nm]['ang'].max() for nm in ('Earth', 'Mercury', 'Venus')))
    chk('ctl', min(np.median(hSA[nm]['ang']) for nm in ('Mercury', 'Venus')) > 1000.0, 'control on the Earth-independent test: variant A against the synthetic table gives medians %.0f\", %.0f\" for Mercury, Venus (> 1000\")' % (np.median(hSA['Mercury']['ang']), np.median(hSA['Venus']['ang'])))
    chk('ctl', np.median(hS0['Mercury']['ang']) > 3.0 and np.median(hSd['Mercury']['ang']) > 1000.0, 'control on the Earth-independent test: ignoring the 69.184 s gives a Mercury median error of %.1f\" (> 3\") and a one-day epoch shift %.0f\" (> 1000\"): the test sees both' % (np.median(hS0['Mercury']['ang']), np.median(hSd['Mercury']['ang'])))
    ctl = {}
    ctl['no light time'] = sepmax(compare(geo_all(solB, tr, light=False), rows_syn))
    ctl['ignore the 69.184 s'] = sepmax(compare(geo_all(solB, t_rows(shift=0.0)), rows_syn))
    ctl['epoch +1 day'] = sepmax(compare(geo_all(solB, t_rows(day_shift=1.0)), rows_syn))
    ctl['frame read as equatorial'] = sepmax(compare(geo_all(solB, tr, R=np.eye(3)), rows_syn))
    ctl['obliquity wrong by 60 arcsec'] = sepmax(compare(geo_all(solB, tr, R=lib.rot_ecl_to_eq(lib.OBLIQ_ARCSEC + 60.0)), rows_syn))
    ctl['variant A (G, masses)'] = sepmax(compare(geo_all(solA, tr), rows_syn))
    ctl['Jupiter removed'] = sepmax(compare(geo_all(sJ, tr), rows_syn))
    mu29 = muB * AU ** (2.9 - 3.0)
    s29 = propagate(mu29, x, v, t_end, power=2.9, rtol=1e-11); ctl['force exponent 2.9'] = sepmax(compare(geo_all(s29, tr), rows_syn))
    lim = {'no light time': 5.0, 'ignore the 69.184 s': 1.0, 'epoch +1 day': 3600.0, 'frame read as equatorial': 3600.0, 'obliquity wrong by 60 arcsec': 30.0, 'variant A (G, masses)': 3600.0, 'Jupiter removed': 60.0, 'force exponent 2.9': 3600.0}
    for k_, v_ in ctl.items():
        chk('ctl', v_ > lim[k_], 'control on the synthetic table: %s -> max separation %.2f arcsec (must exceed %.0f\")' % (k_, v_, lim[k_]))
    NUM['controls_synthetic_arcsec'] = ctl
    print('  [time] total %.0f s' % (time.time() - T_all))

    os.makedirs(os.path.dirname(OUT), exist_ok=True); json.dump(NUM, open(OUT, 'w'), indent=1, default=float)
    finish('G3')

if __name__ == '__main__':
    main()
