#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""C3.  Reissner-Nordstrom with the Atlas's Maxwell.   python3 c3_rn.py
 Frame   radial Kerr-Schild e^a = dx^a - f l^a l_mu dx^mu (b1lib.ks_frame_jet, exact 2-jets), f = M/rho - s/rho^2, g_tt = 1 - 2M/rho + 2s/rho^2, signature (+,-,-,-).
 Field   A = (Q/rho) l_mu dx^mu = (Q/rho) dt + Q x_i/rho^2 dx^i (the second term is the pure gauge d(Q ln rho), kept on purpose), exact 3-jets at rational points; F = dA (engine d).
 Stress  T(a) = -1/2 F a F (bit rule, g2_hodge; the Atlas builds no Maxwell stress), T_a = T^b_a Theta_b.
 Claim   E_a(c = 0) = lambda T_a with ONE constant for all components, points and (M, s, Q): lambda = -4 s/Q^2, so E_a + kappa T_a = 0 (D1) iff s = kappa Q^2/4.
         dF = 0 and d*F = 0 on the curved frame (bit-rule Hodge star in the frame), and nabla^a F_ab = 0 with the engine's omega (h table).
 [std]   Christoffel route (C1's std_G, exact) with the coordinate stress; floats with closed-form g, A and finite differences; the Gauss flux of *F.
 [ctl]   A = (Q/rho^2) l; the stress with flipped sign; a vacuum frame (s = 0) with A != 0; omega = 0 in the covariant route."""
import os, sys, time, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import g2_hodge as H
import c1_birkhoff as C1          # only std_G / closed_form / POINTS (no engine object of C1 is used: it would escape an engine fault put in memory)
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
SQ = LORENTZ(4)
POINTS = C1.POINTS
SAMPLES = [(F(1), F(1, 2), F(1)), (F(3, 2), F(2), F(3)), (F(-1, 3), F(5, 7), F(2, 3)), (F(2), F(3, 4), F(-1))]      # (M, s, Q)

def rn_jets(M, s, rho0):
    r = F(rho0); return (M / r - s / r ** 2, -M / r ** 2 + 2 * s / r ** 3, 2 * M / r ** 3 - 6 * s / r ** 4)
def coulomb_A(p, rho0, Q, power=1, order=3, nv=4):
    """A = Q rho^-power (dt + x_i/rho dx^i) as exact jets of degree `order` around p"""
    rp = H.rho_pow_jet(p, rho0, -power, order, nv); rp1 = H.rho_pow_jet(p, rho0, -power - 1, order, nv); A = {1: scale(rp, Q)}
    for i in (1, 2, 3):
        xi = lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))); A[1 << i] = scale(sp_mul(xi, rp1, order, nv), Q)
    return A
def frame_at(p, rho0, M, s):
    pt = tuple(F(x) for x in p); e, E, _ = ks_frame_jet(pt, F(rho0), *rn_jets(M, s, rho0)); return pt, e, E
def maxwell_on_frame(Gv, pt, rho0, e, E, Q, power=1, sign=F(-1, 2)):
    """[bit] F = dA (engine d), frame components (jets to degree 2), the stress T^b_a at the point, the stress forms T_a, their components at the point"""
    A = coulomb_A(pt, F(rho0), Q, power)
    with trunc(4, xdeg=2): Fc = Gv.Fm.d(A); Fab = H.frame_components(Fc, E, 4)
    Fl0 = {(a, b): at0(Fab.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)}
    Tm = H.maxwell_T_bit(H.bivector(Fl0, SQ), SQ, sign)
    with trunc(4, xdeg=1): Ta = H.stress_forms(Tm, H.theta_forms(e, Gv.Fm, 4), Gv.Fm)
    return dict(A=A, Fc=Fc, Fab=Fab, Fl0=Fl0, Tm=Tm, compT=einstein_components(Ta, 4, 4))
def einstein_on_frame(Gv, S, e):
    """[bit] omega (A3 closed form, first-order jet) and the components of E_a(c = 0) at the point"""
    om, R = engine_om_R(Gv, e, S, 4); return om, engine_E_from_R(Gv, e, R, 4, 0)
def christoffel_std(g, n, nv):
    """[std] Gamma^l_{mv} at the origin of the metric jets g[(a, b)]: 1/2 g^{ls} (d_m g_sv + d_v g_sm - d_s g_mv)"""
    g0 = [[at0(g[(a, b)], nv) for b in range(n)] for a in range(n)]; det, g0i = det_inv(g0); assert det != 0
    dg = lambda k, a, b: at0(pder(g[(a, b)], k), nv)
    return {(l, m, v): sum(F(1, 2) * g0i[l][s_] * (dg(m, s_, v) + dg(v, s_, m) - dg(s_, m, v)) for s_ in range(n)) for l in range(n) for m in range(n) for v in range(n)}
def to_coord(Mfr, e0, E0): return [[sum(E0[m][b] * Mfr[b][a] * e0[a][v] for b in range(4) for a in range(4)) for v in range(4)] for m in range(4)]
def std_maxwell(A, pt, rho0, f0):
    """[std] F_{mu nu} = d_mu A_nu - d_nu A_mu at the point (plain derivatives of the jets); g = eta - 2 f l l, inverse eta + 2 f l^ l^ (closed form, checked); T^mu_nu"""
    dA = lambda mu, nu: at0(pder(A.get(1 << nu, {}), mu), 4); rho0 = F(rho0)
    Fco = [[dA(m, v) - dA(v, m) for v in range(4)] for m in range(4)]
    ld = [F(1)] + [F(x) / rho0 for x in pt]; lu = [F(1)] + [-F(x) / rho0 for x in pt]
    g = [[SQ[m] * (m == v) - 2 * f0 * ld[m] * ld[v] for v in range(4)] for m in range(4)]
    gi = [[SQ[m] * (m == v) + 2 * f0 * lu[m] * lu[v] for v in range(4)] for m in range(4)]
    assert all(sum(g[m][k] * gi[k][v] for k in range(4)) == (m == v) for m in range(4) for v in range(4))
    Fup = [[sum(gi[m][a] * gi[v][b] * Fco[a][b] for a in range(4) for b in range(4)) for v in range(4)] for m in range(4)]
    F2 = sum(Fco[a][b] * Fup[a][b] for a in range(4) for b in range(4))
    return Fco, [[-sum(Fup[m][a] * Fco[v][a] for a in range(4)) + (F2 / 4 if m == v else 0) for v in range(4)] for m in range(4)]

# ------------------------------------------------------------------------------------------------ floats (closed forms, finite differences): never touch the engine or the jets
ETA = np.diag([1.0, -1.0, -1.0, -1.0])
def num_metric(x, M, s):
    r = np.linalg.norm(x[1:]); f = M / r - s / r ** 2; l = np.concatenate([[1.0], x[1:] / r]); return ETA - 2 * f * np.outer(l, l)
def num_A(x, Q, power=1):
    r = np.linalg.norm(x[1:]); return Q * r ** (-power) * np.concatenate([[1.0], x[1:] / r])
def d5(fun, x, k, h):
    e = np.zeros(4); e[k] = h; return (-fun(x + 2 * e) + 8 * fun(x + e) - 8 * fun(x - e) + fun(x - 2 * e)) / (12 * h)
def num_christoffel(x, M, s, h):
    gi = np.linalg.inv(num_metric(x, M, s)); D = np.array([d5(lambda y: num_metric(y, M, s), x, k, h) for k in range(4)])
    return 0.5 * (np.einsum('lq,mqn->lmn', gi, D) + np.einsum('lq,nqm->lmn', gi, D) - np.einsum('lq,qmn->lmn', gi, D))
def num_einstein(x, M, s, h=1e-3):
    Gam = num_christoffel(x, M, s, h); dG = np.array([d5(lambda y: num_christoffel(y, M, s, h), x, k, h) for k in range(4)])
    R = np.einsum('mrvs->rsmv', dG) - np.einsum('vrms->rsmv', dG) + np.einsum('rml,lvs->rsmv', Gam, Gam) - np.einsum('rvl,lms->rsmv', Gam, Gam)
    Ric = np.einsum('rsrv->sv', R); gi = np.linalg.inv(num_metric(x, M, s)); return gi @ Ric - 0.5 * np.einsum('sv,sv', gi, Ric) * np.eye(4)
def num_maxwell(x, M, s, Q, power=1, h=1e-3):
    dA = np.array([d5(lambda y: num_A(y, Q, power), x, k, h) for k in range(4)]); Fco = dA - dA.T
    gi = np.linalg.inv(num_metric(x, M, s)); Fup = gi @ Fco @ gi.T; return -Fup @ Fco.T + 0.25 * np.sum(Fco * Fup) * np.eye(4), Fup
EPS4 = np.zeros((4, 4, 4, 4))
for _p in __import__('itertools').permutations(range(4)): EPS4[_p] = H.perm_sign(_p)
def num_flux(R0, M, s, Q, nth=60, nph=120):
    """[std] integral of *F over the sphere rho = R0, t = 0, orientation (theta, phi) (outward normal): (*F)_{mu nu} = 1/2 sqrt|g| eps_{mu nu rho sigma} F^{rho sigma}"""
    tot = 0.0; dth = math.pi / nth; dph = 2 * math.pi / nph
    for i in range(nth):
        th = (i + 0.5) * dth
        for j in range(nph):
            ph = (j + 0.5) * dph; xh = np.array([math.sin(th) * math.cos(ph), math.sin(th) * math.sin(ph), math.cos(th)]); x = np.concatenate([[0.0], R0 * xh])
            _, Fup = num_maxwell(x, M, s, Q, h=1e-4); sg = math.sqrt(abs(np.linalg.det(num_metric(x, M, s))))
            SF = 0.5 * sg * np.einsum('mnrs,rs->mn', EPS4, Fup)
            xt = np.concatenate([[0.0], R0 * np.array([math.cos(th) * math.cos(ph), math.cos(th) * math.sin(ph), -math.sin(th)])])
            xp = np.concatenate([[0.0], R0 * np.array([-math.sin(th) * math.sin(ph), math.sin(th) * math.cos(ph), 0.0])])
            tot += xt @ SF @ xp * dth * dph
    return tot

def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    head('0. the helper g2_hodge: Hodge star in the frame algebra, Maxwell and scalar stress (exact algebra)')
    H.selftest(chk); tick('part 0')

    # ================================================================================== 1. F = dA on the curved frame
    head('1. F = dA (engine d) on the RN Kerr-Schild frame: dF = 0, frame components, f-independence, [std] derivatives')
    ok_dd = True; ok_fc = True; ok_find = True; ok_bs = True; DATA = {}
    for si, (M, s, Q) in enumerate(SAMPLES):
        for pi_, (p, rho0) in enumerate(POINTS):
            pt, e, E = frame_at(p, rho0, M, s); mx = maxwell_on_frame(Gv, pt, rho0, e, E, Q); DATA[(si, pi_)] = dict(pt=pt, e=e, E=E, **mx)
            ok_dd &= not any(Fm.d(mx['Fc']).values())
            r = F(rho0); ok_fc &= all(mx['Fl0'][(0, i)] == Q * pt[i - 1] / r ** 3 for i in (1, 2, 3)) and all(mx['Fl0'][(i, j)] == 0 for i in (1, 2, 3) for j in (1, 2, 3) if i < j)
            if si < 2:
                _, e0f, E0f = frame_at(p, rho0, F(0), F(0)); mx0 = maxwell_on_frame(Gv, pt, rho0, e0f, E0f, Q); ok_find &= (mx0['Fab'] == mx['Fab'])
            f0 = rn_jets(M, s, rho0)[0]; Fco, _ = std_maxwell(mx['A'], pt, rho0, f0)
            ok_bs &= all(at0(mx['Fc'].get((1 << m) | (1 << v), {}), 4) == Fco[m][v] for m in range(4) for v in range(m + 1, 4))
    chk('bit', ok_dd, 'dF = 0 for F = dA on the whole jet (engine d), %d (sample, point) pairs' % len(DATA))
    chk('bit', ok_fc, 'frame components at the point: F_0i = Q x_i/rho^3 = (Q/rho^2) xhat_i, F_ij = 0 (a radial electric field in the frame), all pairs')
    chk('bit', ok_find, 'the frame components F_ab (jets to degree 2) are the same for f = M/rho - s/rho^2 and for f = 0: the frame Coulomb field does not see f (7 points, 2 samples)')
    chk('bit==std', ok_bs, 'the engine\'s F = dA at the point = d_mu A_nu - d_nu A_mu from plain derivatives of the same jets (all 6 coordinate components, all pairs)')
    tick('part 1')

    # ================================================================================== 2. E_a = lambda T_a
    head('2. the engine\'s Einstein form against the Maxwell stress: E_a(c=0) = lambda T_a with one constant')
    for key, d in DATA.items(): d['om'], d['compE'] = einstein_on_frame(Gv, S, d['e'])
    tick('engine E_a on %d frames' % len(DATA))
    d00 = DATA[(0, 0)]; kk = next(k for k in sorted(d00['compT']) if d00['compT'][k] != 0); lam0 = d00['compE'][kk] / d00['compT'][kk]
    M0, s0, Q0 = SAMPLES[0]; kfit = lam0 * Q0 ** 2 / s0
    print('    fit on sample 0, point 0, component %s: lambda = %s, so lambda = k s/Q^2 with k = %s' % (kk, lam0, kfit))
    ok_v = True; nz = True; nver = 0
    for (si, pi_), d in DATA.items():
        M, s, Q = SAMPLES[si]; lam = kfit * s / Q ** 2
        ok_v &= all(d['compE'][k] == lam * d['compT'][k] for k in d['compT']); nver += 16
        nz &= any(v != 0 for v in d['compE'].values()) and any(v != 0 for v in d['compT'].values())
    chk('bit', ok_v and nz, 'E_a(c=0) = (k s/Q^2) T_a on every component: %d components (%d samples (M, s, Q) x %d points; the fit used one), E and T non-zero everywhere' % (nver, len(SAMPLES), len(POINTS)))
    chk('bit', kfit == -4, 'the constant is k = %s (predicted -4): E_a(c=0) = -(4 s/Q^2) T_a, independent of M (M varies over the samples)' % kfit)
    ok_k = True
    for kap in (F(1), F(3, 2), F(2, 7)):
        Q = F(2, 3); s = kap * Q ** 2 / 4
        for (p, rho0) in POINTS[:2]:
            pt, e, E = frame_at(p, rho0, F(1), s); mx = maxwell_on_frame(Gv, pt, rho0, e, E, Q); _, cE = einstein_on_frame(Gv, S, e)
            ok_k &= all(cE[k] + kap * mx['compT'][k] == 0 for k in cE) and any(cE.values())
    chk('bit', ok_k, 'with s = kappa Q^2/4 (kappa = 1, 3/2, 2/7; Q = 2/3; M = 1): E_a + kappa T_a = 0 exactly, all components, 2 points each (D1\'s form of the field equation)')
    ok_sg = all(d['Tm'][0][0] > 0 for d in DATA.values()) and all(-(kfit * s / Q ** 2) > 0 for (M, s, Q) in SAMPLES)
    chk('bit', ok_sg, 'sign: T^0_0 = Q^2/(2 rho^4) > 0 at every point (energy density of -1/2 F a F), and kappa = -lambda = 4 s/Q^2 > 0 for every sample (s > 0): attraction needs s > 0')
    # controls
    ok_w = True; dw = {}
    for pi_, (p, rho0) in enumerate(POINTS):
        d = DATA[(0, pi_)]; dw[pi_] = maxwell_on_frame(Gv, d['pt'], rho0, d['e'], d['E'], Q0, power=2)
    kw = next(k for k in sorted(dw[0]['compT']) if dw[0]['compT'][k] != 0); lw = DATA[(0, 0)]['compE'][kw] / dw[0]['compT'][kw]
    fails_w = [pi_ for pi_ in range(1, len(POINTS)) if not all(DATA[(0, pi_)]['compE'][k] == lw * dw[pi_]['compT'][k] for k in dw[pi_]['compT'])]
    chk('ctl', len(fails_w) == len(POINTS) - 1, 'control A = (Q/rho^2) l: the constant fitted at point 0 (%s) fails at %d of the other %d points (the stress falls as rho^-6, E_a as rho^-4)' % (lw, len(fails_w), len(POINTS) - 1))
    ok_f = True
    for (si, pi_), d in list(DATA.items())[:7]:
        M, s, Q = SAMPLES[si]; mxf = maxwell_on_frame(Gv, d['pt'], POINTS[pi_][1], d['e'], d['E'], Q, sign=F(1, 2))
        kf = next(k for k in sorted(mxf['compT']) if mxf['compT'][k] != 0); kap_f = -(d['compE'][kf] / mxf['compT'][kf]); ok_f &= (kap_f < 0)
    chk('ctl', ok_f, 'control +1/2 F a F: the fitted kappa = -E/T is negative at every point (s > 0): the wrong-sign stress contradicts attraction (kappa > 0, D1)')
    ok_vac = True
    for (p, rho0) in POINTS[:3]:
        pt, e, E = frame_at(p, rho0, F(1), F(0)); mx = maxwell_on_frame(Gv, pt, rho0, e, E, Q0); _, cE = einstein_on_frame(Gv, S, e)
        ok_vac &= (not any(cE.values())) and any(mx['compT'].values()) and not all(cE[k] == lam0 * mx['compT'][k] for k in cE)
    chk('ctl', ok_vac, 'control vacuum frame (s = 0, M = 1) with A != 0: E_a = 0 but T_a != 0 at 3 points, so E_a = lambda T_a fails for the fitted lambda (and for every lambda != 0)')
    tick('part 2')

    # ================================================================================== 3. the standard route
    head('3. [std] Christoffel route, coordinate Maxwell stress, closed form, floats')
    ok_s = True; ok_bsT = True; ok_bsG = True; ok_cf = True
    for (si, pi_), d in DATA.items():
        M, s, Q = SAMPLES[si]; p, rho0 = POINTS[pi_]; r = F(rho0); jets = rn_jets(M, s, rho0)
        Gs = C1.std_G(p, rho0, jets); _, Ts = std_maxwell(d['A'], d['pt'], rho0, jets[0])
        ok_s &= all(Gs[m][v] == 4 * s / Q ** 2 * Ts[m][v] for m in range(4) for v in range(4))
        e0, E0, det = E0_of(d['e'], 4, 4); ok_bsT &= (to_coord(d['Tm'], e0, E0) == Ts)
        Mfr = mixed_from_components(d['compE'], e0, det, 4, s=-1); ok_bsG &= (to_coord(Mfr, e0, E0) == Gs)
        xh = [F(x) / r for x in p]; v = (F(p[1]), -F(p[0]), F(0)) if (p[0] or p[1]) else (F(0), F(p[2]), -F(p[1]))
        for (Mx, val) in ((Gs, 2 * s / r ** 4), (Ts, Q ** 2 / (2 * r ** 4))):
            rad = [sum(Mx[1 + i][1 + j] * xh[j] for j in range(3)) for i in range(3)]; tan = [sum(Mx[1 + i][1 + j] * v[j] for j in range(3)) for i in range(3)]
            ok_cf &= (Mx[0][0] == val and rad == [val * x for x in xh] and tan == [-val * x for x in v] and all(Mx[0][1 + i] == 0 and Mx[1 + i][0] == 0 for i in range(3)))
    chk('std', ok_s, 'Christoffel route: G^mu_nu = (4 s/Q^2) T^mu_nu with T^mu_nu = -F^{mu a} F_{nu a} + 1/4 delta F^2 in coordinates, all 16 components, %d pairs' % len(DATA))
    chk('bit==std', ok_bsT, 'the bit-rule stress -1/2 F gamma_a F in the frame, carried to coordinates (E^mu_b T^b_a e^a_nu), = the coordinate stress of the Christoffel route, all pairs')
    chk('bit==std', ok_bsG, 'the engine\'s E_a read as a mixed tensor (A4) = the Christoffel-route G^mu_nu, all pairs (C1 consistency on these samples)')
    chk('std', ok_cf, 'closed form (Atlas signature, mixed): G^t_t = G^r_r = -G^tan = 2 s/rho^4 and T^t_t = T^r_r = -T^tan = Q^2/(2 rho^4), G^t_i = G^i_t = T^t_i = T^i_t = 0, all pairs')
    errs = []
    for (M, s, Q) in SAMPLES[:2]:
        for (p, rho0) in POINTS[:3]:
            x = np.array([0.0] + [float(c) for c in p]); Gn = num_einstein(x, float(M), float(s)); Tn, _ = num_maxwell(x, float(M), float(s), float(Q))
            errs.append(np.max(np.abs(Gn - 4 * float(s) / float(Q) ** 2 * Tn)) / np.max(np.abs(Gn)))
    chk('std', max(errs) < 1e-6, 'floats (closed-form g and A, five-point differences, numpy): max |G - (4s/Q^2) T| / max |G| = %.1e at 3 points x 2 samples' % max(errs))
    fl = num_flux(3.0, 1.0, 0.5, 1.0); fl2 = num_flux(7.0, 1.5, 2.0, 3.0)
    chk('std', abs(fl + 4 * math.pi) < 1e-3 * 4 * math.pi and abs(fl2 + 12 * math.pi) < 1e-3 * 12 * math.pi, 'Gauss: the flux of *F through the sphere rho = 3 (Q = 1) is %.5f and through rho = 7 (Q = 3) is %.5f = -4 pi Q (outward orientation, eps_0123 = +1): the source charge of grad F = J is 4 pi Q' % (fl, fl2))
    tick('part 3')

    # ================================================================================== 4. Maxwell's equations on the curved frame
    head('4. d*F = 0 on the curved frame: form route (bit-rule star in the frame), covariant route (engine omega), [std] d_mu(sqrt|g| F^{mu nu}) = 0')
    def dstar(e, E, Fc):
        with trunc(4, xdeg=2): SF = H.hodge_form(Fc, e, E, Fm, SQ, 4); dSF = Fm.d(SF)
        return SF, dSF
    low = lambda X: all(not {k: v for k, v in p.items() if sum(k[:4]) <= 1} for p in X.values())
    ok_ds = True; ok_sf = True; ok_cov = True; ok_om0 = False; ok_std = True; ok_det = True; nds = 0
    for (si, pi_), d in DATA.items():
        if si > 1: continue
        M, s, Q = SAMPLES[si]; p, rho0 = POINTS[pi_]
        SF, dSF = dstar(d['e'], d['E'], d['Fc']); ok_ds &= low(dSF) and any(SF.values()); nds += 1
        _, e0f, E0f = frame_at(p, rho0, F(0), F(0)); SF0, _ = dstar(e0f, E0f, d['Fc']); ok_sf &= (SF == SF0)
        Fab = {}
        for a in range(4):
            for b in range(4):
                if a != b: Fab[(a, b)] = d['Fab'].get((1 << a) | (1 << b), {}) if a < b else scale(d['Fab'].get((1 << b) | (1 << a), {}), -1)
        with trunc(4, xdeg=1):
            DF = H.D_two_index(Gv, d['om'], Fab, 4); DF0 = H.D_two_index(Gv, [{} for _ in range(Gv.G)], Fab, 4)
        ok_cov &= (H.frame_divergence_at0(DF, d['E'], SQ, 4) == [0, 0, 0, 0]); ok_om0 |= (H.frame_divergence_at0(DF0, d['E'], SQ, 4) != [0, 0, 0, 0])
        g = std_metric(d['e'], 4, SQ, 4, 2)
        with trunc(4, xdeg=2):
            det = {}
            for perm in __import__('itertools').permutations(range(4)):
                t = const(4, H.perm_sign(perm))
                for i in range(4): t = sp_mul(t, g[(i, perm[i])], 2, 4)
                det = padd(det, t)
        ok_det &= (det == const(4, -1))
        gi, _, _ = std_inverse_metric(g, 4, 4, 1); A = d['A']
        Fj = {(a, b): padd(pder(A.get(1 << b, {}), a), pder(A.get(1 << a, {}), b), -1) for a in range(4) for b in range(4)}
        Fup = {(m, v): lin(*[(F(1), sp_mul(sp_mul(gi[(m, a)], gi[(v, b)], 1, 4), Fj[(a, b)], 1, 4)) for a in range(4) for b in range(4)]) for m in range(4) for v in range(4)}
        ok_std &= all(sum(at0(pder(Fup[(m, v)], m), 4) for m in range(4)) == 0 for v in range(4))
    chk('bit', ok_ds, 'form route: d(*F) = 0 on every coefficient of x-degree <= 1 around %d (sample, point) pairs (*F exact to degree 2: 3-jets of A, 2-jets of the frame)' % nds)
    chk('bit', ok_sf, '*F (a coordinate 2-form, jets to degree 2) is the same on the RN frame and on f = 0: the Coulomb field and its dual do not see f in this class')
    chk('bit', ok_cov, 'covariant route: nabla^a F_ab = 0 (b = 0..3) at every pair, with D F_ab = d F_ab - omega^c_a F_cb - omega^c_b F_ac from the engine\'s omega (A3) and h table')
    chk('ctl', ok_om0, 'control omega = 0 in the covariant route: nabla^a F_ab != 0 at some pair (the connection terms carry f)')
    chk('std', ok_det and ok_std, 'det g = -1 exactly (jets to degree 2), so sqrt|g| = 1, and d_mu F^{mu nu} = 0 at every pair (F^{mu nu} from the Neumann-series inverse metric)')
    ok_wd = True; ok_wc = True
    for pi_ in range(3):
        d = DATA[(0, pi_)]; _, dSF = dstar(d['e'], d['E'], dw[pi_]['Fc']); ok_wd &= not low(dSF)
        Fab = {}
        for a in range(4):
            for b in range(4):
                if a != b: Fab[(a, b)] = dw[pi_]['Fab'].get((1 << a) | (1 << b), {}) if a < b else scale(dw[pi_]['Fab'].get((1 << b) | (1 << a), {}), -1)
        with trunc(4, xdeg=1): DF = H.D_two_index(Gv, d['om'], Fab, 4)
        ok_wc &= (H.frame_divergence_at0(DF, d['E'], SQ, 4) != [0, 0, 0, 0])
    chk('ctl', ok_wd and ok_wc, 'control A = (Q/rho^2) l: d(*F) != 0 and nabla^a F_ab != 0 at 3 points (not a solution of the vacuum Maxwell equations)')
    tick('part 4')

    # ================================================================================== 5. the dual field (magnetic RN) and duality rotations
    head('5. the dual field *F (a magnetic monopole: F_ij != 0 in the frame) and the dyonic field 3/5 F + 4/5 *F')
    ok_mag = True; ok_mc = True; ok_Td = True; ok_dy = True; ok_ddy = True
    for pi_ in range(len(POINTS)):
        d = DATA[(0, pi_)]; Mab = H.star_comps(d['Fab'], SQ)
        Ml0 = {(a, b): at0(Mab.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)}
        ok_mag &= all(Ml0[(0, i)] == 0 for i in (1, 2, 3)) and any(Ml0[(i, j)] != 0 for i in (1, 2, 3) for j in (1, 2, 3) if i < j)
        full = {}
        for a in range(4):
            for b in range(4):
                if a != b: full[(a, b)] = Mab.get((1 << a) | (1 << b), {}) if a < b else scale(Mab.get((1 << b) | (1 << a), {}), -1)
        with trunc(4, xdeg=1): DM = H.D_two_index(Gv, d['om'], full, 4)
        ok_mc &= (H.frame_divergence_at0(DM, d['E'], SQ, 4) == [0, 0, 0, 0])
        ok_Td &= (H.maxwell_T_bit(H.bivector(Ml0, SQ), SQ) == d['Tm'])
        Dl0 = {k: F(3, 5) * d['Fl0'][k] + F(4, 5) * Ml0[k] for k in Ml0}; Tdy = H.maxwell_T_bit(H.bivector(Dl0, SQ), SQ); ok_dy &= (Tdy == d['Tm'])
        with trunc(4, xdeg=1): Tdf = H.stress_forms(Tdy, H.theta_forms(d['e'], Fm, 4), Fm)
        cT = einstein_components(Tdf, 4, 4); M, s, Q = SAMPLES[0]; ok_ddy &= all(d['compE'][k] == -4 * s / Q ** 2 * cT[k] for k in cT)
    # full covariant derivative nabla_c X_ab (64 frame components) against the Christoffel route, X = F and X = *F
    ok_nab = True; nn = 0; ok_nab_mag_nz = False
    for pi_ in range(len(POINTS)):
        d = DATA[(0, pi_)]; g = std_metric(d['e'], 4, SQ, 4, 2); Gam = christoffel_std(g, 4, 4); gi, _, _ = std_inverse_metric(g, 4, 4, 1); A = d['A']
        Fj = {(a, b): padd(pder(A.get(1 << b, {}), a), pder(A.get(1 << a, {}), b), -1) for a in range(4) for b in range(4)}
        Fup = {(m, v): lin(*[(F(1), sp_mul(sp_mul(gi[(m, a)], gi[(v, b)], 1, 4), Fj[(a, b)], 1, 4)) for a in range(4) for b in range(4)]) for m in range(4) for v in range(4)}
        eps = lambda idx: H.perm_sign(idx) if len(set(idx)) == 4 else 0
        Sj = {(m, v): lin(*[(F(eps([m, v, r, s_]), 2), Fup[(r, s_)]) for r in range(4) for s_ in range(4) if eps([m, v, r, s_])]) for m in range(4) for v in range(4)}
        E0 = [[at0(d['E'][mu][a], 4) for a in range(4)] for mu in range(4)]
        Mab = H.star_comps(d['Fab'], SQ)
        for (Xj, Xfr) in ((Fj, d['Fab']), (Sj, Mab)):
            nab = {(m, v, r): at0(pder(Xj[(v, r)], m), 4) - sum(Gam[(l, m, v)] * at0(Xj[(l, r)], 4) + Gam[(l, m, r)] * at0(Xj[(v, l)], 4) for l in range(4)) for m in range(4) for v in range(4) for r in range(4)}
            full = {}
            for a in range(4):
                for b in range(4):
                    if a != b: full[(a, b)] = Xfr.get((1 << a) | (1 << b), {}) if a < b else scale(Xfr.get((1 << b) | (1 << a), {}), -1)
            with trunc(4, xdeg=1): DX = H.D_two_index(Gv, d['om'], full, 4)
            for a in range(4):
                for b in range(4):
                    if a == b: continue
                    bitc = H.frame_derivative_at0(DX[(a, b)], d['E'], 4, 4)
                    for c in range(4):
                        stdc = sum(E0[m][c] * E0[v][a] * E0[r][b] * nab[(m, v, r)] for m in range(4) for v in range(4) for r in range(4)); ok_nab &= (bitc[c] == stdc); nn += 1
                        if Xfr is Mab and a == 0 and c != 0 and stdc != 0: ok_nab_mag_nz = True
    chk('bit==std', ok_nab, 'nabla_c X_ab: the engine (D F_ab from omega and the h table) = the Christoffel route (d_mu X_nu rho - Gamma X - Gamma X in coordinates, then frame components), %d components, X = F and X = *F (textbook coordinate star), 7 points' % nn)
    chk('bit', ok_nab_mag_nz, 'the comparison is not empty where omega^b_0 acts: some nabla_k (*F)_0j (k spatial) is non-zero')
    chk('bit', ok_mag, 'the frame components of *F at the point are purely spatial (F_0i = 0, some F_ij != 0): the dual of the Coulomb field is a magnetic monopole field, 7 points')
    chk('bit', ok_mc, 'covariant route on the dual field: nabla^a (*F)_ab = 0 at 7 points (here the connection entries omega^b_0 multiply non-zero F_ij)')
    chk('bit', ok_Td and ok_dy, 'duality: the stress of *F and of 3/5 F + 4/5 *F equals the stress of F at 7 points (-1/2 F a F is invariant under F -> F exp(I alpha))')
    chk('bit', ok_ddy, 'so the dyonic field (Q_e, Q_m) = (3Q/5, 4Q/5) on the same frame obeys E_a(c=0) = -(4 s/(Q_e^2 + Q_m^2)) T_a, all components, 7 points: s = kappa (Q_e^2 + Q_m^2)/4')
    tick('part 5')
    finish('C3')

if __name__ == '__main__': main()
