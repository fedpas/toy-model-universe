#!/bin/bash
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# run_all.sh: run the gravity check scripts of this folder one at a time, in dependency order (the long n = 5 sampling run of A2b last). Never stops on a failure.
#   bash run_all.sh              every row of the table below
#   bash run_all.sh NAME ...     only the named rows (NAME as in the first column: a1_lemmas, a2b_strong_sampling_n5, ...)
# Environment: PYTHON (python3), TIMEOUT (900 s per script), MEMKB (3000000 kB, ulimit -v), NICE (10).
# Writes logs/<NAME>.log (stdout and stderr of the script) and logs/SUMMARY.txt: one line per row that has run (exit code, wall seconds, number of ok and FAIL lines,
# last line of the log). A row run again replaces its own line, so two calls with different rows can run side by side. Exit code 124 is a timeout (TIMEOUT in the table).
# Python runs with -B: no __pycache__ is written. The three G3 scripts also write logs/g3_nbody.numbers.json, logs/g3_horizons_compare.numbers.json and logs/g3_vectors_compare.numbers.json.
cd "$(dirname "$0")" || exit 2
PYTHON=${PYTHON:-python3}; TIMEOUT=${TIMEOUT:-900}; MEMKB=${MEMKB:-3000000}; NICE=${NICE:-10}; OUT=logs
export PYTHONDONTWRITEBYTECODE=1
mkdir -p "$OUT"
ROWS=(
  "a3_closed_form|a3_closed_form.py"
  "a4_einstein_tensor|a4_einstein_tensor.py"
  "d1_newtonian_limit|d1_newtonian_limit.py"
  "h3_sign_chain|h3_sign_chain.py"
  "h3_pseudoscalar|h3_pseudoscalar.py"
  "b1_first_variation|b1_first_variation.py"
  "c1_birkhoff|c1_birkhoff.py"
  "gravity_new_checks|gravity_new_checks.py"
  "gravity_moves|gravity_moves.py"
  "forque_gunn_check|forque_gunn_check.py"
  "g2_forms_calc|g2_forms_calc.py"
  "a1_lemmas|a1_lemmas.py"
  "a2_sampling|a2_sampling.py"
  "a2b_strong_sampling|a2b_strong_sampling.py"
  "a5_lorentz_covariance|a5_lorentz_covariance.py"
  "a6_topological|a6_topological.py"
  "b2_noether|b2_noether.py"
  "b2_strong|b2_strong.py"
  "b3_matter|b3_matter.py"
  "b3c4_scalar_frw|b3c4_scalar_frw.py"
  "g2_kerr|g2_kerr.py"
  "c2_kerr|c2_kerr.py"
  "c3_rn|c3_rn.py"
  "c4_frw|c4_frw.py"
  "d2_linearised|d2_linearised.py"
  "d3_helicity|d3_helicity.py"
  "d4_deviation|d4_deviation.py"
  "d5_perihelion|d5_perihelion.py"
  "e1_lichnerowicz|e1_lichnerowicz.py"
  "e2_spin_torsion|e2_spin_torsion.py"
  "e1_axial_torsion|e1_axial_torsion.py"
  "e2s4_dirac_stress|e2s4_dirac_stress.py"
  "e2s4_spin_fluid|e2s4_spin_fluid.py"
  "f1_focusing|f1_focusing.py"
  "f2_first_law|f2_first_law.py"
  "f2_kn_maxwell|f2_kn_maxwell.py"
  "f3_killing|f3_killing.py"
  "f3_kerr|f3_kerr.py"
  "f3_horizons|f3_horizons.py"
  "f3_reduced_potential|f3_reduced_potential.py"
  "f4_komar|f4_komar.py"
  "g1_clkappa|g1_clkappa.py"
  "g1_free_top|g1_free_top.py"
  "g2_tidal_forque|g2_tidal_forque.py"
  "g2_forque_fourth|g2_forque_fourth.py"
  "g3_nbody|g3_nbody.py"
  "g3_horizons_compare|g3_horizons_compare.py"
  "g3_vectors_compare|g3_vectors_compare.py"
  "g4_multibody|g4_multibody.py"
  "g2_weyl|g2_weyl.py"
  "h1_petrov|h1_petrov.py"
  "h1_duality_rotation|h1_duality_rotation.py"
  "h2_simplicity|h2_simplicity.py"
  "h4_kaluza_klein|h4_kaluza_klein.py"
  "h4_cosmological|h4_cosmological.py"
  "h5l_conformal|h5l_conformal.py"
  "h5l_frames|h5l_frames.py"
  "h5l_bianchi|h5l_bianchi.py"
  "h5l_gauge|h5l_gauge.py"
  "h5s_conformal|h5s_conformal.py"
  "h6_area_metric|h6_area_metric.py"
  "h6_closure_kg|h6_closure_kg.py"
  "h6_count|h6_count.py"
  "l2_closure_frw|l2_closure_frw.py"
  "l3_cartan_weyl|l3_cartan_weyl.py"
  "l3_cartan_weyl_flipped|l3_cartan_weyl_flipped.py"
  "l4_mm_limit|l4_mm_limit.py"
  "dup_6|dup_6.py"
  "a2b_strong_sampling_n5|a2b_strong_sampling.py --n5"
)
TO=""; command -v timeout >/dev/null 2>&1 && TO="timeout $TIMEOUT"
[ -n "$TO" ] || echo "[run_all] no timeout command here: the scripts run without the $TIMEOUT s limit" >&2
VERS=$($PYTHON -c 'import sys, numpy, scipy; print("python %s, numpy %s, scipy %s" % (sys.version.split()[0], numpy.__version__, scipy.__version__))' 2>&1 | tail -1)
FMT='%-24s %-7s %6s %5s %5s  %s\n'
row_line() {   # name rc sec: the summary line of one row, counted from its log
  local log="$OUT/$1.log" rc=$2 ok fl last
  [ "$rc" = 124 ] && rc=TIMEOUT
  ok=$(grep -cE '^[[:space:]]*ok\b' "$log"); fl=$(grep -cE '^[[:space:]]*FAIL\b' "$log")
  last=$(grep -vE '^[[:space:]]*$' "$log" | tail -1 | cut -c1-70); [ -n "$last" ] || last='(no output)'
  printf "$FMT" "$1" "$rc" "$3" "$ok" "$fl" "$last"
}
update_summary() {   # name rc sec: (re)write the line of this row in SUMMARY.txt, keep the lines of the other rows, rows in table order
  local name=$1 tries=0 tmp="$OUT/.SUMMARY.$$" row n line
  until mkdir "$OUT/.summary.lock" 2>/dev/null; do tries=$((tries + 1)); [ $tries -gt 120 ] && break; sleep 1; done
  {
    printf '# %s; seconds are wall-clock seconds of the run on this machine\n' "$VERS"
    printf "$FMT" name rc sec ok FAIL 'last line'
    for row in "${ROWS[@]}"; do
      n=${row%%|*}
      if [ "$n" = "$name" ]; then row_line "$name" "$2" "$3"
      else line=$(grep -E "^$n " "$OUT/SUMMARY.txt" 2>/dev/null | head -1); [ -n "$line" ] && printf '%s\n' "$line"; fi
    done
  } > "$tmp"
  mv "$tmp" "$OUT/SUMMARY.txt"; rmdir "$OUT/.summary.lock" 2>/dev/null
}
trap 'rm -f "$OUT/.SUMMARY.$$"' EXIT
for row in "${ROWS[@]}"; do
  name=${row%%|*}; cmd=${row#*|}
  if [ $# -gt 0 ]; then
    want=0; for a in "$@"; do [ "$a" = "$name" ] && want=1; done
    [ $want = 1 ] || continue
  fi
  echo "[run_all] $name: $PYTHON -B $cmd" >&2
  t0=$(date +%s)
  ( ulimit -v "$MEMKB" 2>/dev/null; $TO nice -n "$NICE" $PYTHON -B $cmd ) > "$OUT/$name.log" 2>&1
  rc=$?; t1=$(date +%s)
  update_summary "$name" "$rc" $((t1 - t0))
done
cat "$OUT/SUMMARY.txt"
awk '!/^#/ && $1 != "name" { n++; s += $3; o += $4; f += $5; if ($2 != "0") b++ } END { printf "%d rows, %d ok, %d FAIL, %d rows with a non-zero exit code, %d s in all\n", n, o, f, b, s }' "$OUT/SUMMARY.txt"
