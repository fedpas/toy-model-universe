#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G1-forced. The top forced by force lines in the elliptic, Euclidean and hyperbolic algebras, and the stability of the hung body.
    python3 g1_forced_top.py [--quick] [--n N] [--fault FK|FS|FP|FC]

The laws, points, motors and the hung configuration are those of g1_force_line (force laws as inputs; nothing says which law a curved space has).
[bit]  the engine flow M' = -M B/2, B' = A^-1(B x A(B) + F_b(M)) with F_b(M) the sum of the law lines through the body points toward the
       pulled-back world centre M~ C_w M (the normalised laws through an exact series square root of the join weight), exact series through
       t^N; the energy (1/2) B v A(B) + sum V(d_i(t)) with V = -(w/kappa) cos_k d, -mu cot_k d, g d (Euclid: w d^2/2, -mu/d, g d) is constant.
[std]  kappa = +-1: the top with a fixed point in R^4 / R^{3,1} with the torque T = sum (v F^T - F v^T) of the law's force vector (c_b = eta Lam^T eta c_w),
       L_b' = -Om L_b - L_b Om^T + T, Lam' = Lam Om; kappa = 0: Newton-Euler with the forces (m x_c'' = sum F, I_c w' = (I_c w) x w + sum r x F_b).
[bit==std]  the motor sandwich on vectors = Lam(t) and B(t) = B_std(t) through t^N (kappa = +-1); world points and w(t) = Newton-Euler (kappa = 0);
       at the rest states of the hung body (upper vertex; complement; the second anchor pi - d_s on S^3) the characteristic polynomial of the
       linearised engine flow (xi' = B, B' = A^-1 DF(xi), M = M_eq exp(-xi/2)) equals that of the Lagrangian small oscillations
       (Mass xi'' = -H xi, H the exact Hessian of the potentials at the rest state, 2-jets) exactly; the roots l^2 are reported.
[ctl]  the forque with the wrong sign; the Euclidean (chart) force law in the kappa flow; the Euclidean inertia in the kappa flow (G1's ctl-E);
       zero force recovers the free flow; the wrong power breaks the energy; the complement vertex and the pi - d_s anchor are unstable.
--fault FK: e0^2 flipped in the engine;  FS: every law line reversed;  FP: the Kepler law with the wrong power;  FC: the commutator sign of (e12, e23)."""
import sys, os, time, random, math
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import b1lib
from b1lib import head, chk, finish
from fractions import Fraction as F
import numpy as np
from g1_clkappa import *
import g1_force_line as FL
from g1_force_line import (fsqrt, tri, tcoords, nsq, stdvec, edot, cosk, sin2k, csk_sum, rand_cs, rand_unit3, rand_npoint, geo, geo_std,
                           rand_motor_k, motor_matrix, pull, push, jw2, law_line, law_factor, s_der, s_inv, s_sqrt, ser_scal, ser_jw2, hang_config, NAME, LAWS)

ARGS = sys.argv[1:]
QUICK = '--quick' in ARGS
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS else None
FL.FAULT = FAULT if FAULT in ('FK', 'FS', 'FP') else None
N = int(ARGS[ARGS.index('--n') + 1]) if '--n' in ARGS else (3 if QUICK else 6)
KAPPAS = (1, 0, -1)
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)
def eng_alg(k): return alg(-k if FAULT == 'FK' else k)
def eng_comm(A): return bad_comm(A) if FAULT == 'FC' else A.comm
def bcoef(B): return [B.d.get((1 << a) | (1 << b), F(0)) for a, b in PAIRS4]
def ser_list_eq(a, b, n): return all(x == y for x, y in zip(a[:n + 1], b[:n + 1]))
ETA = lambda k: [F(k), F(1), F(1), F(1)]
def s_sum(terms, N):
    acc = s_zero(N)
    for t in terms: acc = s_add(acc, t)
    return acc

# ---------------------------------------------------------------------------------------------------------- [bit] the forced engine flow
def law_series(A, kind, P, Cb, w, N):
    """the law line through the constant point P toward the moving centre Cb (a series): w L, w L / |L|^3, w L / |L|, (wrong: w L / |L|^2)"""
    L = ser_bilin(A.join, Cb, Ser.const(P, N)) if FL.FAULT == 'FS' else ser_bilin(A.join, Ser.const(P, N), Cb)
    if kind == 'join': return L.scale(F(w))
    n = s_sqrt(ser_jw2(A, L)[0]); ni = s_inv(n)
    p = {'kepler': 2 if FL.FAULT == 'FP' else 3, 'const': 1, 'wrong': 2}[kind]; fac = ni
    for _ in range(p - 1): fac = s_mul(fac, ni)
    return ser_scal(L, fac).scale(F(w))
def forced_engine_flow(A, body, forces, M0, B0, N, comm=None, fsign=1, euclid_law=None):
    """forces: [(kind, P_b, C_w, w)]: P_b a normalised body point, C_w the world centre.  euclid_law: a function M -> forque series used instead (control)."""
    comm = comm or A.comm
    def Fb(M):
        if euclid_law is not None: return euclid_law(M).scale(fsign)
        tot = Ser.const(A.zero(), N)
        for kind, P, Cw, w in forces: tot = tot + law_series(A, kind, P, M.rev() * Ser.const(Cw, N) * M, w, N)
        return tot.scale(fsign)
    def f(S):
        M, B = S; P = B.map(body.I)
        return [(M * B).scale(F(-1, 2)), (ser_bilin(comm, B, P) + Fb(M)).map(body.Iinv)]
    return picard(f, [M0, B0], N)
def energy_series(A, kappa, body, forces, M, B, N):
    """[bit] T + V along the flow: T = (1/2) B v A(B); V from the moving world points: cos_k d = -(X C)_0, sin_k d = sqrt((L L~)_0)"""
    T = [c.scalar() for c in ser_bilin(A.join, B, B.map(body.I)).scale(F(1, 2)).c]
    V = [F(0)] * (N + 1)
    for kind, P, Cw, w in forces:
        X = M * Ser.const(P, N) * M.rev(); w = F(w)
        L = ser_bilin(A.join, X, Ser.const(Cw, N)); w2 = ser_jw2(A, L)[0]; s = s_sqrt(w2) if kind != 'join' else None
        if kappa != 0:
            y = [-(c * Cw).scalar() for c in X.c]                                                   # cos_k d(t)
            if kind == 'join': Vk = s_scale(y, F(-w, kappa))
            elif kind == 'kepler': Vk = s_scale(s_mul(y, s_inv(s)), -w)
            elif kind == 'const': Vk = s_scale(s_int(s_mul(s_der(y), s_inv(s)), 0), F(-w, kappa))     # d' = -y' / (kappa sin_k d); the constant d(0) drops
            else: raise ValueError(kind)
        else:
            if kind == 'join': Vk = s_scale(w2, w / 2)
            elif kind == 'kepler': Vk = s_scale(s_inv(s), -w)
            elif kind == 'const': Vk = s_scale(s, w)
            else: raise ValueError(kind)
        V = s_add(V, Vk)
    return s_add(T, V)

# ---------------------------------------------------------------------------------------------------------- [std] the forced top in R^4 / R^{3,1} (no Clifford product)
def std_top_forced(kappa, epts, Bcoef, N, forces, Lam0=None):
    """as g1_clkappa.std_top with the torque T_b = sum w f (v c_b^T - c_b v^T) added, c_b = eta Lam^T eta c_w; forces: [(kind, v_b, c_w, w)] (std 4-vectors)"""
    eta = ETA(kappa); vs = [(me, [F(1) / F(kappa)] + list(q)) for me, q in epts]
    J = [[sum(me * v[i] * v[j] for me, v in vs) for j in range(4)] for i in range(4)]
    OB = om_basis(eta)
    def Lb_of(Om): return [[sum(J[i][k] * Om[j][k] - Om[i][k] * J[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
    Phi = [[Lb_of(OB[c])[a][b] for c in range(6)] for (a, b) in PAIRS4]; Pi = inverse(Phi)
    def f(S):
        Lam, Bs = S
        Om = [[s_zero(N) for _ in range(4)] for _ in range(4)]; L = [[s_zero(N) for _ in range(4)] for _ in range(4)]
        for c in range(6):
            Lc = Lb_of(OB[c])
            for i in range(4):
                for j in range(4):
                    if OB[c][i][j]: Om[i][j] = s_add(Om[i][j], s_scale(Bs[c], OB[c][i][j]))
                    if Lc[i][j]: L[i][j] = s_add(L[i][j], s_scale(Bs[c], Lc[i][j]))
        Ld = sm_scale(sm_add(sm_mul(Om, L), sm_mul(L, sm_T(Om))), -1)
        for kind, vb, cw, w in forces:
            cb = [s_scale(s_sum((s_scale(Lam[k][a], eta[k] * cw[k]) for k in range(4)), N), eta[a]) for a in range(4)]     # eta Lam^T eta c_w
            if kind == 'join': fac = s_const(1, N)
            else:
                y = s_scale(s_sum((s_scale(cb[a], eta[a] * vb[a]) for a in range(4)), N), kappa)                        # cos_k d(t)
                s = s_sqrt(s_scale(s_sub(s_const(1, N), s_mul(y, y)), kappa)); si = s_inv(s)
                fac = {'kepler': s_mul(si, s_mul(si, si)), 'const': si, 'wrong': s_mul(si, si)}[kind]
            for a in range(4):
                for b in range(4):
                    Ld[a][b] = s_add(Ld[a][b], s_scale(s_mul(fac, s_sub(s_scale(cb[b], vb[a]), s_scale(cb[a], vb[b]))), F(w)))
        up = [Ld[a][b] for a, b in PAIRS4]
        dB = [[sum((Pi[r][c] * up[c][k] for c in range(6)), F(0)) for k in range(N + 1)] for r in range(6)]
        return [sm_mul(Lam, Om), dB]
    Lam0 = Lam0 or [[F(int(i == j)) for j in range(4)] for i in range(4)]
    S = [sm_constmat(Lam0, N), [s_const(b, N) for b in Bcoef]]
    for _ in range(N + 1):
        dL, dB = f(S)
        S = [[[s_int(dL[i][j], Lam0[i][j]) for j in range(4)] for i in range(4)], [s_int(dB[r], Bcoef[r]) for r in range(6)]]
    return S[0], S[1], J, vs
def std_ne_forced(epts, Bcoef, N, forces):
    """[std] kappa = 0: Newton-Euler with forces; forces: [(kind, q_b (chart point of the body), c_w (3-vector), w)]; body at M0 = 1.
    Returns the world point series of the body points and w(t)."""
    m = sum(me for me, _ in epts); c = [sum(me * q[i] for me, q in epts) / m for i in range(3)]
    rs = [[q[i] - c[i] for i in range(3)] for _, q in epts]
    Ic = [[sum(me * ((sum(x * x for x in r) if i == j else 0) - r[i] * r[j]) for (me, _), r in zip(epts, rs)) for j in range(3)] for i in range(3)]
    Ici = inverse(Ic)
    Bd = dict(zip(PAIRS4, Bcoef)); b = [Bd[(0, 1)], Bd[(0, 2)], Bd[(0, 3)]]; w0 = [Bd[(2, 3)], -Bd[(1, 3)], Bd[(1, 2)]]
    cross = lambda u, v: [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
    vc0 = [b[i] + cross(w0, c)[i] for i in range(3)]
    def s3_cross(u, v): return [s_sub(s_mul(u[1], v[2]), s_mul(u[2], v[1])), s_sub(s_mul(u[2], v[0]), s_mul(u[0], v[2])), s_sub(s_mul(u[0], v[1]), s_mul(u[1], v[0]))]
    def f(S):
        Rot, w, xc, vc = S
        Iw = [[sum(s_mul(s_const(Ic[i][j], N), w[j])[k] for j in range(3)) for k in range(N + 1)] for i in range(3)]
        tq = s3_cross(Iw, w); ftot = [s_zero(N) for _ in range(3)]
        for kind, qb, cw, wt in forces:
            rb = [qb[i] - c[i] for i in range(3)]
            x = [s_add(xc[i], s_sum((s_scale(Rot[i][j], rb[j]) for j in range(3)), N)) for i in range(3)]        # the world point
            d = [s_sub(s_const(cw[i], N), x[i]) for i in range(3)]
            if kind == 'join': fac = s_const(wt, N)
            else:
                s = s_sqrt(s_sum((s_mul(di, di) for di in d), N)); si = s_inv(s)
                fac = s_scale({'kepler': s_mul(si, s_mul(si, si)), 'const': si, 'wrong': s_mul(si, si)}[kind], wt)
            Fw = [s_mul(fac, di) for di in d]; ftot = [s_add(a, b_) for a, b_ in zip(ftot, Fw)]
            Fb = [s_sum((s_mul(Rot[j][i], Fw[j]) for j in range(3)), N) for i in range(3)]                       # Rot^T F_w
            tq = [s_add(a, b_) for a, b_ in zip(tq, s3_cross([s_const(x_, N) for x_ in rb], Fb))]
        dw = [[sum(Ici[i][j] * tq[j][k] for j in range(3)) for k in range(N + 1)] for i in range(3)]
        Z = s_zero(N); W = [[Z, s_scale(w[2], -1), w[1]], [w[2], Z, s_scale(w[0], -1)], [s_scale(w[1], -1), w[0], Z]]
        return [sm_mul(Rot, W), dw, vc, [s_scale(fi, 1 / m) for fi in ftot]]
    R0 = [[F(int(i == j)) for j in range(3)] for i in range(3)]
    S = [sm_constmat(R0, N), [s_const(x, N) for x in w0], [s_const(x, N) for x in c], [s_const(x, N) for x in vc0]]
    for _ in range(N + 1):
        dR, dw, dx, dv = f(S)
        S = [[[s_int(dR[i][j], R0[i][j]) for j in range(3)] for i in range(3)], [s_int(dw[i], w0[i]) for i in range(3)], [s_int(dx[i], c[i]) for i in range(3)], [s_int(dv[i], vc0[i]) for i in range(3)]]
    Rot, w, xc, vc = S; out = []
    for r in rs: out.append([s_add(xc[i], s_sum((s_scale(Rot[i][j], r[j]) for j in range(3)), N)) for i in range(3)])
    return out, w

# ---------------------------------------------------------------------------------------------------------- the linearised flows at a rest state
def dlaw(A, kind, L, dL, w):
    """the first-order change of the law line w L / |L|^p (p = 0, 3, 1) when L changes by dL (|L| rational)"""
    w = F(w)
    if kind == 'join': return dL.scale(w)
    n2 = jw2(A, L)[0]; dn2 = 2 * (dL * L.rev()).scalar(); n = fsqrt(n2)
    p = {'kepler': 2 if FL.FAULT == 'FP' else 3, 'const': 1, 'wrong': 2}[kind]
    return (dL.scale(1 / n ** p) - L.scale(p * dn2 / (2 * n ** (p + 2)))).scale(w)
def engine_linearised(A, body, forces):
    """G = A^-1 DF in the bivector basis (6x6): xi' = B, B' = G xi at the rest state; forces: [(kind, P_b, C_b (pulled back), w)] in the body frame"""
    bv = A.bivectors(); cols = []
    for xi_m in bv:
        xi = MV(A.sq, {xi_m: F(1)}); dF = A.zero()
        for kind, P, Cb, w in forces:
            dC = A.comm(xi, Cb)                                                                    # d/d eps of (1 + eps xi/2) C (1 - eps xi/2)
            L = A.join(Cb, P) if FL.FAULT == 'FS' else A.join(P, Cb); dL = A.join(dC, P) if FL.FAULT == 'FS' else A.join(P, dC)
            dF = dF + dlaw(A, kind, L, dL, w)
        cols.append(body.Iinv(dF))
    return [[cols[j].d.get(bv[i], F(0)) for j in range(6)] for i in range(6)]
class Jet:
    """a 2-jet in n variables: value, gradient, Hessian (exact)"""
    __slots__ = ('c', 'g', 'H')
    def __init__(self, c, g, H): self.c, self.g, self.H = c, g, H
    @staticmethod
    def const(c, n): return Jet(F(c), [F(0)] * n, [[F(0)] * n for _ in range(n)])
    @staticmethod
    def var(i, n): g = [F(0)] * n; g[i] = F(1); return Jet(F(0), g, [[F(0)] * n for _ in range(n)])
    def __add__(self, o): return Jet(self.c + o.c, [a + b for a, b in zip(self.g, o.g)], [[a + b for a, b in zip(r1, r2)] for r1, r2 in zip(self.H, o.H)])
    def __sub__(self, o): return self + o.scale(-1)
    def scale(self, k): k = F(k); return Jet(self.c * k, [a * k for a in self.g], [[a * k for a in r] for r in self.H])
    def __mul__(self, o):
        n = len(self.g)
        return Jet(self.c * o.c, [self.c * o.g[i] + o.c * self.g[i] for i in range(n)],
                   [[self.c * o.H[i][j] + o.c * self.H[i][j] + self.g[i] * o.g[j] + o.g[i] * self.g[j] for j in range(n)] for i in range(n)])
    def func(self, f0, f1, f2):
        """f(self) for a scalar function with f(c) = f0, f'(c) = f1, f''(c) = f2"""
        n = len(self.g); return Jet(F(f0), [f1 * a for a in self.g], [[f1 * self.H[i][j] + f2 * self.g[i] * self.g[j] for j in range(n)] for i in range(n)])
def pot_derivs(kappa, kind, y, w):
    """(V, dV/dy, d2V/dy2) at y = cos_k d for kappa != 0: V = -(w/kappa) y, -w y / s, w d (s = sin_k d); kappa = 0: y = |r|^2: w y / 2, -w / sqrt y, w sqrt y"""
    w = F(w)
    if kappa != 0:
        s = fsqrt(kappa * (1 - y * y))
        if kind == 'join': return (-w / kappa * y, -w / kappa, F(0))
        if kind == 'kepler': return (-w * y / s, -w * kappa / s ** 3, -3 * w * y / s ** 5)
        if kind == 'const': return (F(0), -w * kappa / s, -w * y / s ** 3)                        # V = w d + const: the constant drops
    else:
        r = fsqrt(y)
        if kind == 'join': return (w * y / 2, w / 2, F(0))
        if kind == 'kepler': return (-w / r, w / (2 * r ** 3), -3 * w / (4 * r ** 5))
        if kind == 'const': return (w * r, w / (2 * r), -w / (4 * r ** 3))
        if kind == 'uniform': return None
    raise ValueError(kind)
def std_linearised(kappa, pts, forces, euclid=None):
    """[std] Lagrangian small oscillations at the rest state.  kappa != 0: Lam = Lam_eq exp(Xi), Mass_ab = sum mu <OB_a v, OB_b v>_eta, H = Hessian of
    sum w V(cos_k d(exp(Xi) v_P, c_b)); pts: [(mu, v)] std 4-vectors (body frame), forces: [(kind, v_P, c_b, w)].  kappa = 0: coordinates (dx_c, theta),
    Mass = diag(m, m, m) + I_c, V(x_c + R_eq (1 + [th] + [th]^2/2) r_P); euclid = (R_eq, x_c_eq); forces: [(kind, r_P, c_w, w)], 'uniform': c_w the down unit vector.
    Returns the 6x6 matrix -Mass^-1 H (its eigenvalues are l^2)."""
    n = 6
    if kappa != 0:
        eta = ETA(kappa); OB = om_basis(eta)
        Mass = [[sum(mu * edot(kappa, mat_vec(OB[a], v), mat_vec(OB[b], v)) for mu, v in pts) for b in range(n)] for a in range(n)]
        Vj = Jet.const(0, n)
        for kind, vP, cb, w in forces:
            # y(Xi) = kappa <(1 + Xi + Xi^2/2) v_P, c_b>: a quadratic polynomial in the 6 coordinates
            y0 = cosk(kappa, vP, cb); g = [kappa * edot(kappa, mat_vec(OB[a], vP), cb) for a in range(n)]
            H = [[kappa * (edot(kappa, mat_vec(OB[a], mat_vec(OB[b], vP)), cb) + edot(kappa, mat_vec(OB[b], mat_vec(OB[a], vP)), cb)) / 2 for b in range(n)] for a in range(n)]
            yj = Jet(y0, g, H); f0, f1, f2 = pot_derivs(kappa, kind, y0, w); Vj = Vj + yj.func(f0, f1, f2)
    else:
        Req, xeq = euclid; m = sum(mu for mu, _ in pts)
        Ic = [[sum(mu * ((sum(x * x for x in r) if i == j else 0) - r[i] * r[j]) for mu, r in pts) for j in range(3)] for i in range(3)]
        Mass = [[F(0)] * 6 for _ in range(6)]
        for i in range(3):
            Mass[i][i] = m
            for j in range(3): Mass[3 + i][3 + j] = Ic[i][j]
        X = [Jet.var(i, n) for i in range(3)]; th = [Jet.var(3 + i, n) for i in range(3)]
        def cross_j(u, v): return [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
        Vj = Jet.const(0, n)
        for kind, rP, cw, w in forces:
            rj = [Jet.const(x, n) for x in rP]; t1 = cross_j(th, rj); t2 = cross_j(th, t1)
            rb = [rj[i] + t1[i] + t2[i].scale(F(1, 2)) for i in range(3)]                                              # (1 + [th] + [th]^2/2) r_P
            xw = [Jet.const(xeq[i], n) + X[i] + sum((rb[j].scale(Req[i][j]) for j in range(3)), Jet.const(0, n)) for i in range(3)]
            if kind == 'uniform': Vj = Vj + sum((xw[i].scale(-F(w) * cw[i]) for i in range(3)), Jet.const(0, n)); continue
            d = [Jet.const(cw[i], n) - xw[i] for i in range(3)]; y = sum((di * di for di in d), Jet.const(0, n))
            f0, f1, f2 = pot_derivs(0, kind, y.c, w); Vj = Vj + y.func(f0, f1, f2)
    Mi = inverse(Mass); H = Vj.H
    return [[-sum(Mi[i][k] * H[k][j] for k in range(n)) for j in range(n)] for i in range(n)], Vj.g
def roots_of(cp):
    """the roots of the monic polynomial with exact coefficients cp = [1, c1, ..., cn] (numpy), as (real, imag) rounded"""
    r = np.roots([float(c) for c in cp]); return sorted((round(float(z.real), 6), round(float(z.imag), 6)) for z in r)
def stable_from_roots(rt, tol=1e-9):
    """all l^2 real and <= 0 (one zero allowed): the linearised motion is bounded; any l^2 > 0 or complex: unstable"""
    return all(abs(im) < tol and re <= tol for re, im in rt)

# ============================================================================================================ main
def main():
    rng = random.Random(20261010)
    head('G1-forced: the top forced by force lines in Cl_kappa^3, kappa = +1, 0, -1, and the stability of the hung body (series through t^%d)%s' % (N, ' [fault %s]' % FAULT if FAULT else ''))
    # ------------------------------------------------------------------------------------------ (1) forced flows
    head('(1) forced flows: engine = [std] top with the torque (kappa = +-1) / Newton-Euler with the forces (kappa = 0), the three laws')
    for kappa in KAPPAS:
        A = eng_alg(kappa)
        for trial in range(1 if QUICK else 2):
            # a random body of points on geodesics through O with rational (cos_k, sin_k): rational distances to the centre O
            npts = rng.randint(3, 4); us = [rand_unit3(rng) for _ in range(npts)]; css = [rand_cs(kappa, rng) for _ in range(npts)]; mus = [F(rng.randint(1, 3)) for _ in range(npts)]
            qs = [[cs[1] / cs[0] * c for c in u] for u, cs in zip(us, css)]                                  # chart points tan_k(d) u
            epts = engine_pts(kappa, list(zip(mus, qs))); body = Body(A, epts)
            Pn = [geo(A, kappa, u, cs) for u, cs in zip(us, css)]                                               # the normalised body points
            B0 = MV(A.sq, {m_: F(rng.choice([-2, -1, 1, 2]), rng.randint(1, 3)) for m_ in A.bivectors()})
            M0 = rand_motor_k(A, kappa, rng) if kappa != 0 else A.one()
            Cw0 = push(A, M0, A.O)                                                                              # the centre at the body origin at t = 0
            Cj = tri(A, *rand_npoint(kappa, rng))                                                               # a random centre for the join law
            tag = '%s body %d (%d points)' % (NAME[kappa], trial, npts)
            for kind in LAWS:
                C = Cj if kind == 'join' else Cw0
                forces = [(kind, P, C, mu) for P, mu in zip(Pn, mus)]
                t1 = time.time(); M, B = forced_engine_flow(A, body, forces, M0, B0, N, comm=eng_comm(A))
                E = energy_series(A, kappa, body, forces, M, B, N)
                chk('bit', all(x == 0 for x in E[1:N]) and E[0] != 0, '%s, %s law: T + V constant through t^%d (T = B v A(B) / 2, V = %s)' % (tag, kind,
                    N - 1, {'join': '-(w/kappa) cos_k d' if kappa else 'w d^2 / 2', 'kepler': '-mu cot_k d' if kappa else '-mu / d', 'const': 'g d'}[kind]))
                if kappa != 0:
                    cc = tcoords(A, C); cw = stdvec(kappa, cc[0], cc[1:])
                    fstd = [(kind, stdvec(kappa, tcoords(A, P)[0], tcoords(A, P)[1:]), cw, mu) for P, mu in zip(Pn, mus)]
                    try: Lam, Bs, J, vs = std_top_forced(kappa, epts, bcoef(B0), N, fstd, Lam0=motor_matrix(A, M0))
                    except ValueError as e:
                        chk('bit==std', False, '%s, %s law: the std top cannot be built from the engine\'s points (%s): the points are off the quadric' % (tag, kind, e)); continue
                    Le = vector_matrix_series(A, M)
                    okL = all(ser_list_eq(Le[i][j], Lam[i][j], N) for i in range(4) for j in range(4)); okB = all(ser_list_eq([c.d.get((1 << a) | (1 << b), F(0)) for c in B.c], Bs[r], N) for r, (a, b) in enumerate(PAIRS4))
                    chk('bit==std', okL and okB, '%s, %s law: motor sandwich on vectors = Lam(t) and B(t) = [std] top with a fixed point in R^{%s} with the torque, through t^%d' % (tag, kind, '4' if kappa == 1 else '3,1', N))
                    if kind == 'join' and trial == 0:
                        Mw, Bw = forced_engine_flow(A, body, forces, M0, B0, N, comm=eng_comm(A), fsign=-1); Lw = vector_matrix_series(A, Mw)
                        chk('ctl', not all(ser_list_eq(Lw[i][j], Lam[i][j], N) for i in range(4) for j in range(4)), '%s: the forque with the wrong sign does not give the std flow' % tag)
                        A0 = alg(0); bE = Body(A0, [(mu, q) for mu, q in zip(mus, qs)])
                        IE, IEi = linear_map(A, {mm: bE.I(MV(A0.sq, {mm: F(1)})) for mm in A.bivectors()}, A.bivectors())
                        class BE: pass
                        bE2 = BE(); bE2.I = IE; bE2.Iinv = IEi
                        Me, Be = forced_engine_flow(A, bE2, forces, M0, B0, N, comm=eng_comm(A)); Lme = vector_matrix_series(A, Me)
                        chk('ctl', not all(ser_list_eq(Lme[i][j], Lam[i][j], N) for i in range(4) for j in range(4)), '%s: the Euclidean inertia of the same points in the kappa flow does not give the std flow' % tag)
                        # the Euclidean (chart) force law: the join of the weight-1 chart points (the kappa normalisation of the points dropped)
                        def euclid_forque(Ms):
                            tot = Ser.const(A.zero(), N)
                            for P, mu in zip(Pn, mus):
                                cP = tcoords(A, P); P1 = A.point([x / cP[0] for x in cP[1:]])
                                Cb = Ms.rev() * Ser.const(C, N) * Ms; wC = [tcoords(A, c_)[0] for c_ in Cb.c]
                                tot = tot + ser_scal(ser_bilin(A.join, Ser.const(P1, N), Cb), s_inv(wC)).scale(mu)
                            return tot
                        Mu, Bu = forced_engine_flow(A, body, forces, M0, B0, N, comm=eng_comm(A), euclid_law=euclid_forque); Lu = vector_matrix_series(A, Mu)
                        chk('ctl', not all(ser_list_eq(Lu[i][j], Lam[i][j], N) for i in range(4) for j in range(4)), '%s: the Euclidean chart law (the kappa = 0 join of the chart points) in the kappa flow does not give the std flow' % tag)
                else:
                    cc = tcoords(A, C); fstd = [(kind, q, cc[1:], mu) for q, mu in zip(qs, mus)]
                    pts_std, wstd = std_ne_forced(epts, bcoef(B0), N, fstd); okp = True
                    for Rw, ps in zip(world_points(A, M, epts), pts_std):
                        wc = [trivector_coords(A, c) for c in Rw.c]; okp &= [c[0] for c in wc] == [F(1)] + [F(0)] * N
                        for i in range(3): okp &= [c[i + 1] for c in wc] == ps[i]
                    wB = [[c.d.get(0b1100, F(0)) for c in B.c], [-c.d.get(0b1010, F(0)) for c in B.c], [c.d.get(0b0110, F(0)) for c in B.c]]
                    chk('bit==std', okp and all(ser_list_eq(wB[i], wstd[i], N) for i in range(3)), '%s, %s law: world points and (B23, -B13, B12) = textbook Newton-Euler with the forces through t^%d' % (tag, kind, N))
                if kind == 'kepler':
                    Mq, Bq = forced_engine_flow(A, body, [('wrong', P, C, mu) for P, mu in zip(Pn, mus)], M0, B0, N, comm=eng_comm(A))
                    Eq = energy_series(A, kappa, body, [('kepler', P, C, mu) for P, mu in zip(Pn, mus)], Mq, Bq, N)
                    chk('ctl', not all(x == 0 for x in Eq[1:N]), '%s: with the wrong power mu L / |L|^2 the energy T + V_kepler is not constant' % tag)
            Mf, Bf = forced_engine_flow(A, body, [], M0, B0, N, comm=eng_comm(A)); Mg, Bg = engine_flow(A, body.I, body.Iinv, B0, N, M0=M0, comm=eng_comm(A))
            chk('ctl', ser_eq(Mf, Mg, N) and ser_eq(Bf, Bg, N), '%s: with no force the forced flow is the free flow of the top (same series)' % tag)
            print('    (%s: %.1f s)' % (tag, time.time() - t1), flush=True)
    tline('(1)')
    # ------------------------------------------------------------------------------------------ (2) stability of the hung body
    head('(2) stability of the hung cube: the linearised engine flow and the Lagrangian small oscillations have the same characteristic polynomial; roots l^2')
    m, g = F(3, 2), F(2); mg = m * g
    for kappa in KAPPAS:
        A = eng_alg(kappa)
        kk = {1: F(5), 0: F(3), -1: F(4)}[kappa]; cs_s = {1: (F(4, 5), F(3, 5)), 0: (F(1), mg / kk), -1: (F(5, 4), F(3, 4))}[kappa]
        M = rand_motor_k(A, kappa, rng); cs_rho = rand_cs(kappa, rng); cs_g = rand_cs(kappa, rng)
        while True:
            u = rand_unit3(rng)
            if all(c != 0 for c in u): break
        H = hang_config(A, kappa, M, u, cs_rho, cs_g, cs_s, mg, kk)
        sz = H['sz']; n2 = nsq(kappa, 1, H['qv']); mu = m / 8
        verts = [[(F(v >> i & 1) - F(1, 2)) * sz[i] for i in range(3)] for v in range(8)]                       # the cube-like body in the chart
        epts = engine_pts(kappa, [(mu, q) for q in verts]); body = Body(A, epts)
        cases = [('hung', cs_rho, csk_sum(kappa, cs_rho, cs_s), False), ('complement', (cs_rho[0], -cs_rho[1]), csk_sum(kappa, (cs_rho[0], -cs_rho[1]), cs_s), True)]
        if kappa == 1: cases.append(('second anchor pi - d_s', cs_rho, csk_sum(kappa, cs_rho, (-cs_s[0], cs_s[1])), False))
        for name, cs_v, cs_a, comp in cases:
            Pb = geo(A, kappa, u, cs_v); ab = geo(A, kappa, u, cs_a); cgb = geo(A, kappa, u, (cs_g[0], -cs_g[1]))
            chk('bit', Pb == (hang_config(A, kappa, M, u, cs_rho, cs_g, cs_s, mg, kk, complement=comp)['Pb']) and (law_line(A, 'const', A.O, cgb, mg) + law_line(A, 'join', Pb, ab, kk)).is_zero(),
                '%s, %s: the vertex is the sign-bit vertex of the cube (bits %s) and the forques cancel (rest state)' % (NAME[kappa], name, [1 - b for b in H['bits']] if comp else H['bits']))
            forces = [('const', A.O, cgb, mg), ('join', Pb, ab, kk)]
            G = engine_linearised(A, body, forces); cpe = charpoly(G)
            if kappa != 0:
                pts = [(mu, stdvec(kappa, 1 / fsqrt(n2), [x / fsqrt(n2) for x in q])) for q in verts]
                fstd = [('const', stdvec(kappa, 1, [0, 0, 0]), geo_std(kappa, u, (cs_g[0], -cs_g[1])), mg), ('join', geo_std(kappa, u, cs_v), geo_std(kappa, u, cs_a), kk)]
                Gs, grad = std_linearised(kappa, pts, fstd)
            else:
                Lam = motor_matrix(A, M); Req = [[Lam[i][j] for j in (1, 2, 3)] for i in (1, 2, 3)]; xO = tcoords(A, push(A, M, A.O))[1:]
                xg = tcoords(A, push(A, M, cgb))[1:]; xa = tcoords(A, push(A, M, ab))[1:]; qP = tcoords(A, Pb)[1:]
                chk('bit', [sum(Req[i][j] * qP[j] for j in range(3)) + xO[i] for i in range(3)] == tcoords(A, push(A, M, Pb))[1:], 'Euclid: the motor matrix gives the world vertex x_O + R q_P')
                pts = [(mu, q) for q in verts]; fstd = [('const', [F(0)] * 3, xg, mg), ('join', qP, xa, kk)]
                Gs, grad = std_linearised(0, pts, fstd, euclid=(Req, xO))
            cps = charpoly(Gs)
            chk('std', all(x == 0 for x in grad), '%s, %s: the gradient of the potential vanishes at the rest state (std)' % (NAME[kappa], name))
            chk('bit==std', cpe == cps, '%s, %s: the characteristic polynomial of the linearised engine flow (A^-1 DF) = that of -Mass^-1 H of the Lagrangian, exactly' % (NAME[kappa], name))
            rt = roots_of(cpe); st = stable_from_roots(rt)
            print('    %s, %s: polynomial in l^2: %s' % (NAME[kappa], name, [str(c) for c in cpe]))
            print('    %s, %s: roots l^2 = %s' % (NAME[kappa], name, ['%g%s' % (re, '' if im == 0 else '%+gi' % im) for re, im in rt]))
            lam_s = -kk * csk_sum(kappa, cs_a, (cs_v[0], -cs_v[1]))[0] / m        # -k cos_k(d_s) / m with d_s the vertex-anchor distance: the spring mode of a point mass
            at_s = sum(c * lam_s ** (6 - i) for i, c in enumerate(cpe))
            if name == 'hung':
                chk('bit', st and cpe[-1] == 0 and any(re < 0 for re, im in rt), '%s, hung vertex: all l^2 real and <= 0 (one zero: the turn about the vertical line), the rest state is linearly stable' % NAME[kappa])
                if kappa == 0: chk('bit', at_s == 0, 'Euclid, hung vertex: l^2 = -k / m = %s is an exact root (the spring mode of a point mass decouples)' % lam_s)
                else: print('    %s, hung: -k cos_k(d_s) / m = %s is %san exact root (the spring mode does not decouple from the body here)' % (NAME[kappa], lam_s, '' if at_s == 0 else 'not '))
            else:
                chk('ctl', not st, '%s, %s: some l^2 > 0 or complex: the rest state is linearly unstable' % (NAME[kappa], name))
        if kappa == 0:
            # E11's uniform gravity (the ideal down point): the same cube, the weight line m g join(O, g I) with g the pulled-back down direction
            gdir = [-c for c in u]; gI = A.vec(gdir) * A.I
            Pb = geo(A, 0, u, cs_rho); ab = geo(A, 0, u, csk_sum(0, cs_rho, cs_s))
            forces = [('join', A.O, gI, mg), ('join', Pb, ab, kk)]
            chk('bit', (law_line(A, 'join', A.O, gI, mg) + law_line(A, 'join', Pb, ab, kk)).is_zero(), 'Euclid, uniform gravity (E11): the weight line through the centre toward the ideal down point and the spring cancel')
            G = engine_linearised(A, body, forces); cpe = charpoly(G)
            Lam = motor_matrix(A, M); Req = [[Lam[i][j] for j in (1, 2, 3)] for i in (1, 2, 3)]; xO = tcoords(A, push(A, M, A.O))[1:]
            gw = [sum(Req[i][j] * gdir[j] for j in range(3)) for i in range(3)]; xa = tcoords(A, push(A, M, ab))[1:]; qP = tcoords(A, Pb)[1:]
            Gs, grad = std_linearised(0, [(mu, q) for q in verts], [('uniform', [F(0)] * 3, gw, mg), ('join', qP, xa, kk)], euclid=(Req, xO))
            cps = charpoly(Gs); rt = roots_of(cpe)
            chk('bit==std', cpe == cps and all(x == 0 for x in grad), 'Euclid, uniform gravity: the characteristic polynomials agree exactly and the gradient vanishes')
            print('    Euclid, uniform gravity, hung: polynomial in l^2: %s; roots l^2 = %s' % ([str(c) for c in cpe], ['%g%s' % (re, '' if im == 0 else '%+gi' % im) for re, im in rt]))
            chk('bit', stable_from_roots(rt) and cpe[-1] == 0, 'Euclid, uniform gravity, hung vertex: all l^2 real and <= 0 with one zero: linearly stable (E11\'s rest state)')
    tline('(2)')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('G1-forced' + ('-' + FAULT if FAULT else '') + ('-quick' if QUICK else ''))
