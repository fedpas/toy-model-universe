#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H3.  The sign chain: one convention, seven places.   python3 h3_sign_chain.py

 The extra generator of the extended algebra squares to s.  Run in BOTH conventions for the squares of space ("ours": space -1, time +1; "flipped": space +1, time -1),
 with r = s / (square of space) the square of the extra generator measured against space (r = +1: it squares like space).
   (1) k = -s       the curvature of the extended algebra is (R^{ab} + k kappa^2 e^a e^b, kappa T^a).   [bit] the engine's Lie table + curvature;  [std] the same algebra in plain so(p,q) matrices.
   (2) c = k kappa^2 and the Einstein form E_a(c) of a Schwarzschild-(anti-)de Sitter frame: which frame is a solution.   [bit] the engine on Kerr-Schild 2-jets;  [std] Christoffel route.
   (3) the free-fall acceleration of a particle at rest.   [bit] omega from A3 and the h table;  [std] -Gamma^i_tt / g_tt.
   (4) the bivector (extra, space) squares to -r and (extra, time) to +r.   [bit] the bit rule's own product;  [std] gamma matrices.
   (5) the 3D Euclid base: the extended connection is flat on the conformal frame 2 dp / (c_F + p^2) iff s matches the sign of its curvature.   [bit] the engine's R;  [std] Christoffel.
   (6) c_F = -2 mu E is the curvature of the Fock momentum space; so the sign of E fixes s.   (the atlas's Kepler/Fock claims are not re-run here: this is the curvature of the metric.)
   (7) the mass shell of the fibre: E^2 = |p|^2 + r m^2.   [bit] square of a 5-vector;  [std] gamma matrices and the d'Alembertian with a fifth coordinate.
 Controls: the label of 'ours' used in the flipped convention (must give the wrong geometry), a wrong sign of k, a wrong s for the Fock space."""
import time
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

RES = {}          # results collected for the summary: RES[(conv, s)][key]
CONV = {'ours': dict(name='ours (space squares -1, time +1)', lor=[1, -1, -1, -1], euc=[-1, -1, -1], sp=-1),
        'flip': dict(name='flipped (space squares +1, time -1)', lor=[-1, 1, 1, 1], euc=[1, 1, 1], sp=1)}
SS = (-1, 0, 1)
KAPPA = F(1, 2); K2 = KAPPA ** 2
def rr(conv, s): return F(s, CONV[conv]['sp'])                       # r = s / (square of space)

# ------------------------------------------------------------------------------------------------ [std] the same algebra in plain matrices
def std_lie_table(sq_ext):
    """so(p,q) (or its contraction when a square is 0) in matrices: (L_AB)^C_D = delta^C_A eta_BD - delta^C_B eta_AD, A < B, acting on R^N.
    Returns f[(A, B)] = (C, c) with [2 L_A, 2 L_B] = c (2 L_C): the same normalisation as the engine's [B_A, B_B] = c B_C with B = gamma_a gamma_b = 2 L."""
    N = len(sq_ext); pairs = [(i, j) for i in range(N) for j in range(i + 1, N)]; P = len(pairs); mats = []
    for (a, b) in pairs:
        M = [[F(0)] * N for _ in range(N)]; M[a][b] += F(sq_ext[b]); M[b][a] -= F(sq_ext[a]); mats.append(M)
    cols = [[x for row in M for x in row] for M in mats]; rows = [[cols[C][i] for C in range(P)] for i in range(N * N)]
    def comm(A, B):
        AB = [[sum(A[i][k] * B[k][j] for k in range(N)) for j in range(N)] for i in range(N)]
        BA = [[sum(B[i][k] * A[k][j] for k in range(N)) for j in range(N)] for i in range(N)]
        return [AB[i][j] - BA[i][j] for i in range(N) for j in range(N)]
    f = {}
    for A in range(P):
        for B in range(P):
            w, rank, nvar, cons = solve_exact(rows, comm(mats[A], mats[B])); assert cons and rank == P
            nz = [(C, x) for C, x in enumerate(w) if x != 0]; assert len(nz) <= 1
            if nz: f[(A, B)] = (nz[0][0], 2 * nz[0][1])
    return f
def std_killing(f, P):
    ad = np.zeros((P, P, P))
    for (A, B), (C, c) in f.items(): ad[A][C][B] += float(c)
    K = np.array([[np.trace(ad[A] @ ad[B]) for B in range(P)] for A in range(P)]); ev = np.linalg.eigvalsh(K)
    return (int((ev > 1e-9).sum()), int((ev < -1e-9).sum()), int((abs(ev) <= 1e-9).sum()))
def so_counts(sq_ext):
    """closed form from standard Lie theory: so(p,q) has (p q, C(p,2) + C(q,2), 0) for the Killing form; a null direction adds the translations to the zero count"""
    p = sum(1 for x in sq_ext if x > 0); q = sum(1 for x in sq_ext if x < 0); z = sum(1 for x in sq_ext if x == 0)
    return (p * q, p * (p - 1) // 2 + q * (q - 1) // 2, z * (p + q))

# ------------------------------------------------------------------------------------------------ [std] gamma matrices (numpy)
def gammas_lorentz_ext(sq_base, s):
    """complex matrices with g_a g_b + g_b g_a = 2 sq_a delta_ab for the 4 base generators of signature (+,-,-,-) or (-,+,+,+) and one extra generator of square s (s = 0: nilpotent in 8 x 8)"""
    I2 = np.eye(2); Z2 = np.zeros((2, 2)); sx = np.array([[0, 1], [1, 0]], dtype=complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], dtype=complex)
    g0 = np.block([[I2, Z2], [Z2, -I2]]).astype(complex); gs_ = [np.block([[Z2, sg], [-sg, Z2]]) for sg in (sx, sy, sz)]
    g5 = 1j * g0 @ gs_[0] @ gs_[1] @ gs_[2]                                  # squares to +1, anticommutes with all four
    base = [g0] + gs_
    if sq_base[0] == -1: base = [1j * g for g in base]                       # flip all squares: (+,-,-,-) -> (-,+,+,+)
    if s == 1: ext = g5; mats = base
    elif s == -1: ext = 1j * g5; mats = base
    else:
        N = np.array([[0, 1], [0, 0]], dtype=complex); mats = [np.kron(np.eye(2), g) for g in base]; ext = np.kron(N, g5)
    return mats + [ext]
def check_gammas(mats, sq):
    ok = True
    for i in range(len(mats)):
        for j in range(len(mats)):
            ac = mats[i] @ mats[j] + mats[j] @ mats[i]
            ok &= bool(np.allclose(ac, (2 * sq[i]) * np.eye(len(ac)) if i == j else 0))
    return ok

# ------------------------------------------------------------------------------------------------ Kerr-Schild: free fall
def christoffel_at0(g, n, nv):
    g0 = [[at0(g[(a, b)], nv) for b in range(n)] for a in range(n)]; det, g0i = det_inv(g0); assert det != 0
    dg = lambda k, a, b: at0(sp_der(g[(a, b)], k), nv); G = {}
    for l in range(n):
        for m in range(n):
            for v in range(n): G[(l, m, v)] = sum(g0i[l][s_] * F(1, 2) * (dg(m, s_, v) + dg(v, s_, m) - dg(s_, m, v)) for s_ in range(n))
    return G, g0
def engine_accel(Gv, om, e, E0, n):
    """[bit] coordinate acceleration d^2 x^i/d tau^2 (i = 1..3) of the particle at rest (dx/dt = 0): geodesic in the frame, du^c/dtau = - h_{Ab}^c omega^A_t e^b_t (u^t)^2, (u^t)^2 = sq_0 / g_tt (g(u,u) = square of time),
    d^2x^i/dtau^2 = E^i_c du^c/dtau (the frame does not depend on t); E0 = inverse frame at the point"""
    sq = Gv.L.sq; et = [at0(e[b].get(1, {}), n) for b in range(n)]; omt = [at0(om[A].get(1, {}), n) for A in range(Gv.G)]
    du = [F(0)] * n
    for (A, b), (c, h) in Gv.L.h.items(): du[c] -= h * omt[A] * et[b]
    gtt = sum(sq[b] * et[b] ** 2 for b in range(n))
    return [sum(E0[i][c] * du[c] for c in range(n)) * sq[0] / gtt for i in range(1, n)]

def engine_om_R(Gv, e, S, n):
    """[bit] omega (A3 closed form, first-order jet) and the engine's curvature R = d omega + 1/4 [omega, omega] (jets, x-degree <= 1)"""
    om = omega_closed_form(Gv, e, S, n, 1)[0]
    with trunc(n, xdeg=1): R = Gv.curvature(om)
    return om, R
def engine_E_from_R(Gv, e, R, n, c):
    with trunc(n, xdeg=1): Ea, _ = Gv.einstein(None, e, R, F(c))
    return einstein_components(Ea, n, n)
def Rab_at0(Gv, R, n):
    Rab = {}
    for A, (a, b) in enumerate(pairs_of(Gv.L)):
        for mu in range(n):
            for nu in range(mu + 1, n):
                v = at0(R[A].get((1 << mu) | (1 << nu), {}), n)
                Rab[(a, b, mu, nu)] = v; Rab[(b, a, mu, nu)] = -v; Rab[(a, b, nu, mu)] = -v; Rab[(b, a, nu, mu)] = v
    return Rab

def conformal_frame_jet(p, cF):
    """e^a = Omega dp^a with Omega = 2 / (cF + |p|^2): exact 2-jet at p (nv = n = 3), and the inverse coframe E = (1/Omega) delta as a jet"""
    n = 3; nv = 3; X = [var(nv, i) for i in range(3)]; den = cF + sum(x * x for x in p); assert den != 0
    d2 = lin(*[(F(1), sp_mul(X[i], X[i], 2, n)) for i in range(3)])
    u = lin((F(2) / den, lin(*[(p[i], X[i]) for i in range(3)])), (F(1) / den, d2)); u2 = sp_mul(u, u, 2, n)
    Om = lin((F(2) / den, const(nv, 1)), (F(-2) / den, u), (F(2) / den, u2))
    return [{1 << a: Om} for a in range(3)]



def ks_part():
    # ================================================================================== (2) and (3)
    head('(2) Schwarzschild-(anti-)de Sitter frames f = M/rho + (H2/2) rho^2: for which H2 is E_a(c) = 0, c = k kappa^2 = -s kappa^2;   (3) the free fall of a particle at rest')
    pts = [((F(1), F(2), F(2)), F(3)), ((F(2), F(3), F(6)), F(7)), ((F(-4), F(4), F(7)), F(9))]; Ms = [F(0), F(1, 3), F(2)]; H2s = [K2, -K2, F(0)]
    for cv, dat in CONV.items():
        sq = dat['lor']; Lie_ = Lie(sq); Gv = Grav(4, Lie_); S = koszul_S(4, sq, Lie_)
        zero_all = {(s, H2): True for s in SS for H2 in H2s}; match_std = True; accel_ok = True; accel_std_ok = True; nfr = 0; G_const = set(); Rroute = True
        for H2 in H2s:
            for (pt, rho0) in pts:
                for M in Ms:
                    f0, f1, f2 = sds_jets(M, H2, rho0); e, _E, _l = ks_frame_jet(pt, rho0, f0, f1, f2); nfr += 1
                    e0, E0, det = E0_of(e, 4, 4); om, R = engine_om_R(Gv, e, S, 4)
                    g = std_metric(e, 4, sq, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, 4); Gfr = to_frame_mixed(Gm, e0, E0, 4)
                    Rab = Rab_at0(Gv, R, 4)
                    for r_ in range(4):
                        for s_ in range(4):
                            for m in range(4):
                                for v in range(m + 1, 4):
                                    Rroute &= (sum(E0[r_][a] * e0[b][s_] * sq[b] * Rab.get((a, b, m, v), 0) for a in range(4) for b in range(4)) == R1[(r_, s_, m, v)])
                    if M == 0:
                        diag = set(Gm[i][i] for i in range(4)); off = set(Gm[i][j] for i in range(4) for j in range(4) if i != j)
                        G_const.add((tuple(sorted(diag)), tuple(sorted(off)), H2))
                    for s in SS:
                        c = RES[(cv, s)]['k_Lorentz'] * K2; comp = engine_E_from_R(Gv, e, R, 4, c)
                        if any(v_ != 0 for v_ in comp.values()): zero_all[(s, H2)] = False
                        M_ = [[Gfr[h][a] - (3 * c if h == a else 0) for a in range(4)] for h in range(4)]
                        match_std &= (comp == predicted_components(M_, e0, E0, det, 4, s=-1))
                    # (3) free fall
                    acc = engine_accel(Gv, om, e, E0, 4); want = [f1 * pt[i] / rho0 for i in range(3)]
                    accel_ok &= (acc == want)
                    Gam, g0_ = christoffel_at0(g, 4, 4); gtt = g0_[0][0]
                    acc_std = [-Gam[(i, 0, 0)] * sq[0] / gtt for i in (1, 2, 3)]
                    accel_std_ok &= (acc_std == want)
        chk('bit==std', Rroute, '%s: the engine\'s curvature (omega from A3) equals the Riemann tensor of the metric e^T eta e, every component, %d Kerr-Schild frames' % (cv, nfr))
        chk('bit==std', match_std, '%s: E_a(c) of the engine equals -(G^h_a - 3 c delta^h_a) Theta_h with G the Einstein tensor of the metric (Christoffel route), all 16 components, all %d frames and the three c = -s kappa^2 (A4 carried to Kerr-Schild frames; in the flipped convention too)' % (cv, nfr))
        # the pattern of zeros
        for s in SS:
            zs = [H2 for H2 in H2s if zero_all[(s, H2)]]
            r = rr(cv, s)
            chk('bit', zs == [r * K2], '%s, s=%+d (r=%s), c = k kappa^2 = %s: E_a(c) = 0 (all components, all radii, M = 0, 1/3, 2) for H2 in %s; expected exactly H2 = r kappa^2 = %s' % (cv, s, r, RES[(cv, s)]['k_Lorentz'] * K2, [str(z) for z in zs], r * K2))
            RES.setdefault((cv, s), {})['H2'] = zs[0] if zs else None
        # the Einstein tensor of the exact solutions: G = 3 H2 sigma_t delta
        sig_t = dat['lor'][0]
        okG = all(d_ == (3 * H2 * sig_t,) * 4 or (len(set(d_)) == 1 and d_[0] == 3 * H2 * sig_t) for (d_, o_, H2) in G_const) and all(o_ == (0,) or o_ == () for (d_, o_, H2) in G_const)
        chk('std', okG, '%s: for M = 0 the mixed Einstein tensor of the metric is G^mu_nu = %s H2 delta^mu_nu (std route, exact): dS has %s' % (cv, 3 * sig_t, 'G = +3 H2' if sig_t == 1 else 'G = -3 H2 in this signature'))
        chk('bit', accel_ok, '%s: the free-fall acceleration from the engine (omega, h table) is f\'(rho) x_hat at every radius, M and H2: d2x/dtau2 = (-M/rho^2 + H2 rho) x_hat  (%d frames, exact)' % (cv, nfr))
        chk('std', accel_std_ok, '%s: the same from the Christoffel symbol, -Gamma^i_tt g(u,u) / g_tt = f\'(rho) x_hat (%d frames)' % (cv, nfr))
        for s in SS:
            r = rr(cv, s); RES[(cv, s)]['oscillator'] = r * K2          # coefficient of +rho in the acceleration (at M = 0): H2
    # controls
    head('(2c) controls')
    for cv, dat in CONV.items():
        sq = dat['lor']; Lie_ = Lie(sq); Gv = Grav(4, Lie_); S = koszul_S(4, sq, Lie_); pt, rho0 = pts[0]
        wrong = 0; tot = 0
        for s in (-1, 1):
            r = rr(cv, s)
            for (cname, c) in (('opposite sign of k', +s * K2), ('kappa doubled in c', -s * 4 * K2), ('c = 0', F(0))):
                f0, f1, f2 = sds_jets(F(1, 3), r * K2, rho0); e, _E, _l = ks_frame_jet(pt, rho0, f0, f1, f2); om, R = engine_om_R(Gv, e, S, 4)
                comp = engine_E_from_R(Gv, e, R, 4, c); tot += 1; wrong += int(any(v_ != 0 for v_ in comp.values()))
        chk('ctl', wrong == tot, '%s: with the solution frame H2 = r kappa^2 and a wrong c (opposite sign of k, kappa doubled, c = 0) the engine\'s E_a is non-zero in %d of %d cases' % (cv, wrong, tot))
    # the mixed convention
    ok_ = RES[('ours', -1)]['H2'] == K2 and RES[('flip', -1)]['H2'] == -K2 and RES[('ours', 1)]['H2'] == -K2 and RES[('flip', 1)]['H2'] == K2
    chk('ctl', ok_, 'mixed convention: the rule "s = -1 gives de Sitter (H2 = +kappa^2)" holds with space squaring -1 and FAILS with space squaring +1, where s = -1 gives H2 = %s (anti-de Sitter); k = -s is the same in both' % RES[('flip', -1)]['H2'])
    tick('parts 2, 3')

def euclid_part():
    # ================================================================================== (5) and (6)
    head('(5), (6) the 3D Euclid base: conformal frame e^a = 2 dp^a / (c_F + |p|^2), c_F = -2 mu E (Fock/PGA momentum space); flatness of the extended connection R^{ab} + k kappa^2 e^a e^b')
    cFs = [F(2), F(0), F(-2)]; pts3 = [(F(1), F(2), F(3)), (F(-1), F(0), F(2)), (F(1, 2), F(1, 3), F(-1))]
    for cv, dat in CONV.items():
        sq3 = dat['euc']; L3 = Lie(sq3); G3 = Grav(3, L3); S3 = koszul_S(3, sq3, L3); sp = dat['sp']
        for cF in cFs:
            Kstd_all = set(); Keng_all = set(); route_ok = True; flat = {s: True for s in SS}
            kap2 = abs(cF) if cF != 0 else K2
            for p in pts3:
                e = conformal_frame_jet(p, cF); e0, E0, det = E0_of(e, 3, 3)
                gpos = std_metric(e, 3, [1, 1, 1], 3, 2); R1, g0, g0i = std_riemann(gpos, 3, 3, 1); R2, _, _ = std_riemann(gpos, 3, 3, 2); _G, _ric, Rs = std_einstein_mixed(R1, g0, g0i, 3)
                route_ok &= (R1 == R2); Kstd_all.add(Rs / 6)
                om, R = engine_om_R(G3, e, S3, 3); Rab = Rab_at0(G3, R, 3)
                for r_ in range(3):
                    for s_ in range(3):
                        for m in range(3):
                            for v in range(m + 1, 3):
                                route_ok &= (sum(E0[r_][a] * e0[b][s_] * sq3[b] * Rab.get((a, b, m, v), 0) for a in range(3) for b in range(3)) == R1[(r_, s_, m, v)])
                lam = set()
                for a in range(3):
                    for b in range(a + 1, 3):
                        for m in range(3):
                            for v in range(m + 1, 3):
                                w = e0[a][m] * e0[b][v] - e0[a][v] * e0[b][m]
                                if w != 0: lam.add(Rab[(a, b, m, v)] / w)
                                else: assert Rab[(a, b, m, v)] == 0
                assert len(lam) == 1, lam; Keng_all.add(next(iter(lam)) * sp)
                for s in SS:
                    c = RES[(cv, s)]['k_Euclid'] * kap2
                    for a in range(3):
                        for b in range(a + 1, 3):
                            for m in range(3):
                                for v in range(m + 1, 3):
                                    if Rab[(a, b, m, v)] + c * (e0[a][m] * e0[b][v] - e0[a][v] * e0[b][m]) != 0: flat[s] = False
            chk('std', Kstd_all == {cF}, '%s, c_F = %s: the metric 4|dp|^2/(c_F + |p|^2)^2 has constant scalar curvature / 6 = K = %s at all sample points (Christoffel route; second route agrees)' % (cv, cF, sorted(map(str, Kstd_all))))
            chk('bit==std', route_ok and Keng_all == {cF}, '%s, c_F = %s: the engine\'s curvature equals the metric\'s Riemann tensor (all components), and R^{ab} = (K / square of space) e^a e^b with K = %s' % (cv, cF, sorted(map(str, Keng_all))))
            fl = [s for s in SS if flat[s]]; r_expect = (1 if cF > 0 else -1 if cF < 0 else 0)
            chk('bit', len(fl) == 1 and rr(cv, fl[0]) == r_expect, '%s, c_F = %s (E %s 0 for mu > 0): the extended connection R^{ab} + k kappa^2 e^a e^b with kappa^2 = %s is flat for s = %s only (r = %s = sign K)' % (cv, cF, '<' if cF > 0 else '>' if cF < 0 else '=', kap2, fl, [str(rr(cv, x)) for x in fl]))
            if len(fl) == 1:
                s_fl = fl[0]; RES.setdefault((cv, s_fl), {})['K'] = cF / kap2 if cF != 0 else F(0)
                RES[(cv, s_fl)]['E_sign'] = -1 if cF > 0 else 1 if cF < 0 else 0
    # controls: wrong s for the Fock space is not flat (done in the scan); wrong sign of K with the same s
    head('(5c) controls')
    for cv, dat in CONV.items():
        sq3 = dat['euc']; L3 = Lie(sq3); G3 = Grav(3, L3); S3 = koszul_S(3, sq3, L3); p = pts3[0]; cF = F(2)
        e = conformal_frame_jet(p, cF); e0, E0, det = E0_of(e, 3, 3); om, R = engine_om_R(G3, e, S3, 3); Rab = Rab_at0(G3, R, 3)
        bad = 0; tot = 0
        for s in SS:
            for kap2 in (F(2), F(1), F(3)):
                c = -s * kap2; zero = all(Rab[(a, b, m, v)] + c * (e0[a][m] * e0[b][v] - e0[a][v] * e0[b][m]) == 0 for a in range(3) for b in range(a + 1, 3) for m in range(3) for v in range(m + 1, 3))
                if not (s == [x for x in SS if rr(cv, x) == 1][0] and kap2 == F(2)): tot += 1; bad += int(not zero)
        chk('ctl', bad == tot, '%s, c_F = 2: all %d other pairs (s, kappa^2) give a non-flat extended connection (only the right s with kappa^2 = |c_F| is flat)' % (cv, tot))
    tick('parts 5, 6')

def summary():
    head('SUMMARY  (every entry below was computed above; r = s / square of space; the bivector entries are (extra, space)^2 and (extra, time)^2)')
    for cv, dat in CONV.items():
        print('  convention %s' % dat['name'])
        for s in SS:
            d = RES[(cv, s)]; r = rr(cv, s)
            print('    s=%+d  r=%+d  k=%+d  c=k kappa^2=%5s  Killing(n=4 + extra)=%s  frame H2/kappa^2=%+d  K(Fock, n=3)/kappa^2=%+d  sign E=%+d  (ext,space)^2=%+d  (ext,time)^2=%+d  shell E^2=|p|^2+(%+d) m^2' % (
                s, r, d['k_Lorentz'], d['k_Lorentz'] * K2, d['killing_Lorentz'], d['H2'] / K2, d['K'], d['E_sign'], d['biv_space'], d['biv_time'], d['shell']))
    head('what the two conventions share (as a function of r) and what they do not')
    for r in (F(1), F(0), F(-1)):
        rows = [(cv, s, RES[(cv, s)]) for cv in CONV for s in SS if rr(cv, s) == r]
        assert len(rows) == 2
        for key in ('killing_Lorentz', 'killing_Euclid', 'H2', 'K', 'E_sign', 'biv_space', 'biv_time', 'shell'):
            vals = set(d[key] for _, _, d in rows)
            chk('bit', len(vals) == 1, 'r=%+d: both conventions give the same %s = %s (ours s=%+d, flipped s=%+d)' % (r, key, sorted(map(str, vals))[0], rows[0][1], rows[1][1]))
        if r != 0:
            chk('bit', rows[0][1] == -rows[1][1], 'r=%+d: the label s differs between the conventions (s = %+d against %+d): "s" is not the invariant, r is' % (r, rows[0][1], rows[1][1]))
    d_ = {r: RES[next((cv, s) for cv in ('ours',) for s in SS if rr(cv, s) == r)] for r in (F(1), F(0), F(-1))}
    chk('bit', all(d_[r]['H2'] / K2 == r and d_[r]['K'] == r and d_[r]['E_sign'] == -r and d_[r]['biv_space'] == -r and d_[r]['biv_time'] == r and d_[r]['shell'] == r for r in d_),
        'as functions of r: frame H2/kappa^2 = r, Fock K/kappa^2 = r, sign E = -r, (extra,space)^2 = -r, (extra,time)^2 = +r, mass shell E^2 = |p|^2 + r m^2')
    chk('bit', all(RES[(cv, s)]['H2'] / K2 == (-s if cv == 'ours' else s) for cv in CONV for s in SS), 'in terms of the label s: ours H2 = -s kappa^2 (oscillator term of the acceleration -s kappa^2 rho), flipped H2 = +s kappa^2 (+s kappa^2 rho); k = -s in both')
    head('"bound" is not a common correlate')
    kepler_bound = {r: d_[r]['E_sign'] < 0 for r in d_}; trap_bound = {r: d_[r]['H2'] < 0 for r in d_}
    chk('bit', kepler_bound == {F(1): True, F(0): False, F(-1): False} and trap_bound == {F(1): False, F(0): False, F(-1): True},
        'the Kepler orbit is bound (E < 0) at r = +1 only; the oscillator term of the free fall is attractive (a harmonic trap, anti-de Sitter) at r = -1 only: the two "bound" cases sit at opposite r')
    print('\n  chain: the invariant of the seven places is the sign of the curvature K = r kappa^2 (the sign of the extra generator\'s square against the square of space); k = -s is a statement about the algebra in the label s.')

def main():
    print('H3.  the sign chain.  kappa = %s' % KAPPA)
    # ================================================================================== (1) k = -s
    head('(1) k = -s in the curvature of the extended algebra; the Lie table of the engine is the table of so(p,q) in plain matrices')
    kt = {}; table1 = {}
    for cv, dat in CONV.items():
        for tag, base in (('Lorentz n=4', dat['lor']), ('Euclid n=3', dat['euc'])):
            ks = []
            for s in SS:
                sqx = list(base) + [s]; Lx = Lie(sqx); fstd = std_lie_table(sqx)
                same = ({k: (c, F(v)) for k, (c, v) in Lx.f.items()} == {k: (c, F(v)) for k, (c, v) in fstd.items()})
                chk('bit==std', same, '%s, %s, s=%+d: the engine\'s structure constants [B_A, B_B] (bit rule, Clifford product) equal those of the matrix algebra (%d x %d pairs)' % (cv, tag, s, Lx.G, Lx.G))
                k_b, mu_b = embed_k(base, s, KAPPA, 7 + s)
                # k from the matrix table: coefficient of B_ab in [B_aE,B_bE] and [B_bE,B_aE] (the quadratic term (1/4) f omega omega with omega^{aE} = kappa e^a)
                nb = len(base); iA = Lx.idx[(1 << 0) | (1 << nb)]; iB = Lx.idx[(1 << 1) | (1 << nb)]
                fa, fb = fstd.get((iA, iB)), fstd.get((iB, iA)); k_s = F((fa[1] if fa else 0) - (fb[1] if fb else 0), 4)
                chk('bit', k_b == -s and mu_b == KAPPA, '%s, %s, s=%+d: engine curvature of the extended connection: k = %s, torsion coefficient mu = %s (expected -s = %d, kappa = %s)' % (cv, tag, s, k_b, mu_b, -s, KAPPA))
                chk('std', k_s == -s, '%s, %s, s=%+d: from the matrix commutator [L_aE, L_bE] = -eta_EE L_ab: k = %s' % (cv, tag, s, k_s))
                ks.append(k_b); kt[(cv, tag, s)] = k_b; RES.setdefault((cv, s), {})['k_' + tag.split()[0]] = k_b
            chk('bit', ks == [1, 0, -1], '%s, %s: k over s = -1, 0, +1 is %s: k = -s in both conventions (it does not depend on the square of space)' % (cv, tag, [str(x) for x in ks]))
    tick('part 1')

    head('(1a) flipping the sign of every square flips every structure constant of the bivector algebra and of the vector action (B -> -B), so the Killing signature is unchanged')
    for tag, base in (('Lorentz n=4', CONV['ours']['lor']), ('Euclid n=3', CONV['ours']['euc'])):
        for s in SS:
            sqx = list(base) + [s]; A1 = Lie(sqx); A2 = Lie([-x for x in sqx])
            fl_ = ({k: (c, -v) for k, (c, v) in A1.f.items()} == {k: (c, v) for k, (c, v) in A2.f.items()}) and ({k: (c, -v) for k, (c, v) in A1.h.items()} == {k: (c, v) for k, (c, v) in A2.h.items()})
            chk('bit', fl_ and killing_signature(A1)[0] == killing_signature(A2)[0], '%s, s=%+d: Lie(squares) and Lie(-squares): every f and every h changes sign, same Killing signature %s' % (tag, s, killing_signature(A1)[0]))
    head('(1b) the Killing signatures of the extended algebras (positive, negative, zero)')
    killing = {}
    for cv, dat in CONV.items():
        for tag, base in (('Lorentz n=4', dat['lor']), ('Euclid n=3', dat['euc'])):
            for s in SS:
                sqx = list(base) + [s]; Lx = Lie(sqx); kb, diag = killing_signature(Lx); fstd = std_lie_table(sqx); ks_ = std_killing(fstd, Lx.G); kc = so_counts(sqx)
                killing[(cv, tag, s)] = kb; RES.setdefault((cv, s), {})['killing_' + tag.split()[0]] = kb
                chk('bit==std', kb == ks_ == kc, '%s, %s, s=%+d: Killing signature %s (engine, exact) = %s (numpy eigenvalues of the matrix algebra) = %s (so(p,q) formula)' % (cv, tag, s, kb, ks_, kc))
    tick('part 1b')

    # ================================================================================== (4) bivector squares
    head('(4) the bivector of the extra generator with a space generator squares to -r, with the time generator to +r (r = s / square of space)')
    for cv, dat in CONV.items():
        for s in SS:
            r = rr(cv, s); sqx = list(dat['lor']) + [s]; E_ = 4
            sp_ = [bmul((1 << E_) | (1 << i), (1 << E_) | (1 << i), sqx) for i in (1, 2, 3)]
            tm_ = bmul((1 << E_) | 1, (1 << E_) | 1, sqx)
            ok_b = all(m == 0 and sg == -r for m, sg in sp_) and tm_[0] == 0 and tm_[1] == r
            mats = gammas_lorentz_ext(dat['lor'], s); ok_g = check_gammas(mats, sqx)
            Id = np.eye(len(mats[0])); sq_std = [(mats[E_] @ mats[i]) @ (mats[E_] @ mats[i]) for i in (1, 2, 3)]; tq_std = (mats[E_] @ mats[0]) @ (mats[E_] @ mats[0])
            ok_s = all(np.allclose(x, -float(r) * Id) for x in sq_std) and np.allclose(tq_std, float(r) * Id)
            RES.setdefault((cv, s), {}).update(biv_space=sp_[0][1], biv_time=tm_[1])
            chk('bit', ok_b, '%s, s=%+d (r=%s): (gamma_E gamma_i)^2 = %s for the three space generators, (gamma_E gamma_0)^2 = %s' % (cv, s, r, sorted(set(str(sg) for m, sg in sp_)), tm_[1]))
            chk('std', ok_g and ok_s, '%s, s=%+d: complex gamma matrices (%d x %d) with the right squares give (g_E g_i)^2 = %s, (g_E g_0)^2 = %s' % (cv, s, len(mats[0]), len(mats[0]), sorted(set(round(float(x[0, 0].real), 12) for x in sq_std)), round(float(tq_std[0, 0].real), 12)))
    tick('part 4')

    # ================================================================================== (7) the mass shell
    head('(7) the mass shell of the fibre: the 5-vector (E, p, m) is null iff E^2 = |p|^2 + r m^2')
    rng = random.Random(5)
    for cv, dat in CONV.items():
        for s in SS:
            r = rr(cv, s); sqx = list(dat['lor']) + [s]
            vec = {A: var(5, A) for A in range(5)}; sqr = clifford_square(sqx, vec, 5)
            assert set(sqr) <= {0}
            poly = sqr.get(0, {}); cE = poly.get(tuple(2 if j == 0 else 0 for j in range(5)), 0); cm = poly.get(tuple(2 if j == 4 else 0 for j in range(5)), 0)
            cp = [poly.get(tuple(2 if j == i else 0 for j in range(5)), 0) for i in (1, 2, 3)]
            # poly = cE E^2 + sum cp_i p_i^2 + cm m^2 = 0   ->   E^2 = -(cp.p^2 + cm m^2)/cE, with cp = -cE (spatial block)
            RES.setdefault((cv, s), {})['shell'] = -cm / cE
            shell_b = (cE == dat['lor'][0] and all(x == dat['lor'][1] for x in cp) and -cm / cE == r)
            chk('bit', shell_b and cm == s, '%s, s=%+d: (E gamma_0 + p.gamma + m gamma_E)^2 has coefficients (E^2, p_i^2, m^2) = (%s, %s, %s): null iff E^2 = |p|^2 + (%s) m^2, and r = %s' % (cv, s, cE, cp[0], cm, -cm / cE, r))
            mats = gammas_lorentz_ext(dat['lor'], s); Evv = rng.uniform(-2, 2); pp = np.array([rng.uniform(-2, 2) for _ in range(3)]); mm = rng.uniform(-2, 2)
            V = Evv * mats[0] + sum(pp[i - 1] * mats[i] for i in (1, 2, 3)) + mm * mats[4]
            val = V @ V; want = (dat['lor'][0] * Evv ** 2 + dat['lor'][1] * float(pp @ pp) + s * mm ** 2) * np.eye(len(V))
            # [std] the d'Alembertian with a fifth coordinate: wave exp(i(k.x)) is annihilated iff the dispersion holds; five-point second differences
            sgn = list(dat['lor']) + [s]; k = [Evv, pp[0], pp[1], pp[2], mm]
            def phase(x): return math.cos(sum(k[j] * x[j] for j in range(5)))
            h_ = 1e-2; x0 = [0.3, -0.2, 0.5, 0.1, 0.4]; box = 0.0
            for j in range(5):
                def sh(d): y = list(x0); y[j] += d; return phase(y)
                d2 = (-sh(2 * h_) + 16 * sh(h_) - 30 * sh(0) + 16 * sh(-h_) - sh(-2 * h_)) / (12 * h_ * h_); box += sgn[j] * d2
            symb = -sum(sgn[j] * k[j] ** 2 for j in range(5)) * phase(x0)
            chk('std', np.allclose(val, want) and abs(box - symb) < 1e-6, '%s, s=%+d: gamma-matrix square = (%s E^2 + %s |p|^2 + %s m^2) 1, and the d\'Alembertian (with the sign %s on the fifth derivative) of a plane wave gives -(sum eta_j k_j^2) cos (finite differences, error %.1e)' % (cv, s, dat['lor'][0], dat['lor'][1], s, s, abs(box - symb)))
    tick('part 7')
    ks_part()
    euclid_part()
    summary()
    return None

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('H3')
