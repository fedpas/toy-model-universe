#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""D5: perihelion advance from the step-12 metric.      python3 d5_perihelion.py [--engine-only]

 Part 1 [bit==std], exact Fractions: at 30 states taken from the integrator (rational points with rational radius), the engine's coordinate acceleration
        a^mu = (d_nu E^mu_c) u^nu u^c + E^mu_c du^c/dtau,  du^c/dtau = - h_{Ab}^c omega^A_mu u^mu u^b  (omega: A3 closed form; h: the engine's table)
        equals -Gamma^mu_{nu rho} u^nu u^rho of the metric e^T eta e, and the integrator's closed-form right-hand side equals it to rounding.
        Controls: omega with the opposite sign, the d E term left out, the frame of a wrong f.
 Part 2 [std] floats: geodesics of the radial Kerr-Schild metric f = M/rho (M = 1, plane z = 0), DOP853 rtol 1e-13 atol 1e-15, periastron events;
        advance per orbit / (6 pi M/p) -> 1 with the O(M/p) coefficient read from the data;  [std2] quadrature that never integrates the ODE.
 Part 3 [ctl] the Newtonian orbit closes; the PPN isotropic family gives (2 + 2 gamma - beta)/3 (recalled formula); f = M/rho + M^2/rho^2 changes the advance.
 Part 4 Schwarzschild-(anti-)de Sitter f = M/rho + (H2/2) rho^2: the H2 slope of the advance (fit), its sign, the Newtonian Kepler + oscillator slope (Bertrand).
 --engine-only runs Part 1 alone (Parts 2-4 never touch the engine).
 Scope: n = 4, plane orbits, geometric units M = 1; consistency with a textbook formula, no statement about any measurement."""
import sys, os, time, math, decimal
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from h3_sign_chain import christoffel_at0
import numpy as np
from scipy.integrate import solve_ivp, quad

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
Dec = decimal.Decimal
decimal.getcontext().prec = 60
TWO_PI = 2 * math.pi
RTOL, ATOL = 1e-13, 1e-15
SQ = [1, -1, -1, -1]
PS = (100, 200, 400, 800, 1600); ES = (0.1, 0.3, 0.6); NORB = 4

# ------------------------------------------------------------------------------------------------ [bit] and [std] exact accelerations at a rational state
def rational_state(st):
    """float state (x, y, u^t, v^x, v^y) -> rational point (x, y, 0) with rational radius r (x, y = r (1 - t^2, 2t)/(1 + t^2), t = tan(phi/2)),
    and the coordinate 4-velocity (u^t, v^x, v^y, 0); every number is the exact Fraction of a float"""
    x, y, ut, vx, vy = [float(v) for v in st]
    r = F(math.hypot(x, y)); t = F(math.tan(math.atan2(y, x) / 2)); den = 1 + t * t
    return (r * (1 - t * t) / den, r * 2 * t / den, F(0)), r, [F(ut), F(vx), F(vy), F(0)]

def ks_jets(kind, rho0):
    """2-jet (f, f', f'') at rho0, M = 1: 'schw' f = 1/rho; 'wrong' f = 1/rho + 1/rho^2 (control)"""
    if kind == 'schw': return sds_jets(F(1), F(0), rho0)
    return (1 / rho0 + 1 / rho0 ** 2, -1 / rho0 ** 2 - 2 / rho0 ** 3, 2 / rho0 ** 3 + 6 / rho0 ** 4)

def engine_coord_accel(Gv, S, e, u, sign=1, pre=None):
    """[bit] coordinate acceleration of the geodesic with coordinate 4-velocity u (Fractions) at the origin of the jets of the frame e:
       a^mu = E^mu_c du^c/dtau + (d_nu E^mu_c) u^nu u^c,  du^c/dtau = - h_{Ab}^c omega^A_mu u^mu u^b,  u^b = e^b_mu u^mu.
    omega = sign * (A3 closed form, engine's d), h = the engine's table, E = inverse frame jet.  Returns (frame part, dE part, pre) with pre reusable."""
    n = 4
    D_, E_, det = pre or anholonomy(Gv, e, n, 1)
    om = omega_closed_form(Gv, e, S, n, 1, sign=sign, Dpre=(D_, E_, det))[0]
    ev = [[at0(e[c].get(1 << mu, {}), n) for mu in range(n)] for c in range(n)]
    uf = [sum(ev[c][mu] * u[mu] for mu in range(n)) for c in range(n)]
    omu = [sum(at0(om[A].get(1 << mu, {}), n) * u[mu] for mu in range(n)) for A in range(Gv.G)]
    du = [F(0)] * n
    for (A, b), (c, h) in Gv.L.h.items(): du[c] -= h * omu[A] * uf[b]
    frame = [sum(at0(E_[mu][c], n) * du[c] for c in range(n)) for mu in range(n)]
    dEp = [sum(at0(sp_der(E_[mu][c], nu), n) * u[nu] * uf[c] for nu in range(n) for c in range(n)) for mu in range(n)]
    return frame, dEp, (D_, E_, det)

def std_coord_accel(e, u):
    """[std] -Gamma^mu_{nu rho} u^nu u^rho of g = e^T eta e (b1lib.std_metric, h3_sign_chain.christoffel_at0); never the engine"""
    g = std_metric(e, 4, SQ, 4, 1); Gam, g0 = christoffel_at0(g, 4, 4)
    return [-sum(Gam[(mu, nu, rh)] * u[nu] * u[rh] for nu in range(4) for rh in range(4)) for mu in range(4)]

# ------------------------------------------------------------------------------------------------ float right-hand sides (state x, y, u^t, v^x, v^y; plane z = 0)
def ks_rhs(f, fp):
    """[std] Kerr-Schild chart, g = eta - 2 f(rho) l l, l_mu = (1, x/rho), closed form derived from Gamma by hand (checked exactly in Part 1):
       a^t = Q,  a^i = (s^2 f' - Q) n_i,  s = u^t + n.v,  Q = 2 (s f' n.v + f (v^2 - (n.v)^2)/rho + s^2 f f')"""
    def rhs(tau, y):
        x, yy, ut, vx, vy = y.tolist()
        r = math.hypot(x, yy); nx = x / r; ny = yy / r
        nv = nx * vx + ny * vy; s = ut + nv; f0 = f(r); f1 = fp(r)
        Q = 2.0 * (s * f1 * nv + f0 * (vx * vx + vy * vy - nv * nv) / r + s * s * f0 * f1)
        ar = s * s * f1 - Q
        return [vx, vy, Q, ar * nx, ar * ny]
    return rhs
def iso_rhs(beta, gamma, M=1.0):
    """[std] g = A dt^2 - B (dx^2 + dy^2 + dz^2), A = 1 - 2M/r + 2 beta M^2/r^2, B = 1 + 2 gamma M/r (PPN isotropic family); from the Lagrangian A t'^2 - B v^2"""
    def rhs(tau, y):
        x, yy, ut, vx, vy = y.tolist()
        r = math.hypot(x, yy); nx = x / r; ny = yy / r; nv = nx * vx + ny * vy; v2 = vx * vx + vy * vy
        A = 1 - 2 * M / r + 2 * beta * M * M / (r * r); Ap = 2 * M / (r * r) - 4 * beta * M * M / r ** 3
        B = 1 + 2 * gamma * M / r; Bp = -2 * gamma * M / (r * r); cr = Ap * ut * ut - Bp * v2
        return [vx, vy, -(Ap / A) * nv * ut, -(cr * nx + 2 * Bp * nv * vx) / (2 * B), -(cr * ny + 2 * Bp * nv * vy) / (2 * B)]
    return rhs
def newton_rhs(H2=0.0, M=1.0):
    """Newton's equation d^2x/dt^2 = -M x/r^3 + H2 x (Kepler plus an isotropic oscillator term); u^t is a dummy"""
    def rhs(t, y):
        x, yy, ut, vx, vy = y.tolist(); k = -M / math.hypot(x, yy) ** 3 + H2
        return [vx, vy, 0.0, k * x, k * yy]
    return rhs

class Model:
    """a static spherical orbit problem in the plane z = 0:
       'ks'     Kerr-Schild f = M/rho + c2 M^2/rho^2 + (H2/2) rho^2   (= (1 - 2f) dt_s^2 - drho^2/(1 - 2f) - rho^2 dOmega^2 after t -> t + T(rho))
       'iso'    PPN isotropic (beta, gamma)
       'newton' -M x/r^3 + H2 x
    Orbit labelled by its turning points u1 = (1 + e)/p, u2 = (1 - e)/p (u = 1/r).  V(u) = E2 a(u) - L2 b(u) + c(u) is B_r (dr/dtau)^2, zero at u1, u2."""
    def __init__(self, kind, name, M=1.0, c2=0.0, H2=0.0, beta=1.0, gamma=1.0):
        self.kind, self.name, self.M = kind, name, M
        self.DM, self.Dc2, self.DH2, self.Dbeta, self.Dgamma = (Dec(v) for v in (M, c2, H2, beta, gamma))
        if kind == 'ks':
            self.f = lambda r: M / r + c2 * M * M / (r * r) + 0.5 * H2 * r * r
            self.fp = lambda r: -M / (r * r) - 2 * c2 * M * M / r ** 3 + H2 * r
            self.rhs = ks_rhs(self.f, self.fp)
        elif kind == 'iso': self.rhs = iso_rhs(beta, gamma, M)
        else: self.rhs = newton_rhs(H2, M)
    def A(self, u):
        if self.kind == 'ks': return 1 - 2 * self.DM * u - 2 * self.Dc2 * self.DM ** 2 * u * u - self.DH2 / (u * u)
        return 1 - 2 * self.DM * u + 2 * self.Dbeta * self.DM ** 2 * u * u
    def B(self, u): return 1 + 2 * self.Dgamma * self.DM * u
    def abc(self, u):
        if self.kind == 'ks': return 1 / self.A(u), u * u, Dec(-1)
        if self.kind == 'iso': return 1 / self.A(u), u * u / self.B(u), Dec(-1)
        return Dec(1), u * u, 2 * self.DM * u + self.DH2 / (u * u)
    def pref(self, u, L):
        """dphi/dchi = pref / sqrt(W), W = V / ((u1 - u)(u - u2))"""
        if self.kind == 'ks': return L / self.A(u).sqrt()
        if self.kind == 'iso': return L / self.B(u).sqrt()
        return L
    def EL(self, p, e):
        De, Dp = Dec(e), Dec(p); u1, u2 = (1 + De) / Dp, (1 - De) / Dp
        a1, b1, c1 = self.abc(u1); a2, b2, c2 = self.abc(u2); det = a2 * b1 - a1 * b2
        return (c1 * b2 - b1 * c2) / det, (a2 * c1 - a1 * c2) / det, u1, u2
    def ic(self, p, e):
        """state at apastron (r_a, 0), velocity (0, v_y), counter-clockwise"""
        E2, L2, u1, u2 = self.EL(p, e); L = L2.sqrt()
        if self.kind == 'ks': ut, vy = E2.sqrt() / self.A(u2), L * u2
        elif self.kind == 'iso': ut, vy = E2.sqrt() / self.A(u2), L * u2 / self.B(u2)
        else: ut, vy = Dec(1), L * u2
        return np.array([float(1 / u2), 0.0, float(ut), 0.0, float(vy)])
    def quad_advance(self, p, e):
        """[std2] advance per orbit = 2 int_0^pi (dphi/dchi - 1) dchi, u = (1 + e cos chi)/p; the integrand in 60-digit Decimal (no cancellation)"""
        E2, L2, u1, u2 = self.EL(p, e); L = L2.sqrt(); De, Dp = Dec(e), Dec(p); k2 = (De / Dp) ** 2
        def g(chi):
            c = Dec(math.cos(chi)); u = (1 + De * c) / Dp; a, b, cc = self.abc(u)
            W = (E2 * a - L2 * b + cc) / (k2 * (1 - c) * (1 + c))
            return float(self.pref(u, L) / W.sqrt() - 1)
        val, err = quad(g, 0, math.pi, epsabs=1e-17, epsrel=1e-13, limit=200)
        return 2 * val

def schw_quad(p, e, M=1.0):
    """[std2] Schwarzschild: (du/dphi)^2 = 2M u^3 - u^2 + 2M u/L^2 + (E^2 - 1)/L^2 = 2M (u1 - u)(u - u2)(u3 - u), u3 = 1/(2M) - u1 - u2;
    with u = (1 + e cos chi)/p:  advance = 2 int_0^pi ([1 - (2M/p)(3 + e cos chi)]^(-1/2) - 1) dchi"""
    eps = 2 * M / p
    g = lambda chi: math.expm1(-0.5 * math.log1p(-eps * (3 + e * math.cos(chi))))
    return 2 * quad(g, 0, math.pi, epsabs=1e-17, epsrel=1e-13, limit=200)[0]

def ev_peri(t, y): return y[0] * y[3] + y[1] * y[4]
ev_peri.direction = 1
def orbit_advance(model, p, e, norb=NORB):
    """[std] integrate from apastron for norb + 1 periastra (events d(r^2)/dtau = 0 upward); advance_k = phi_{k+1} - phi_k - 2 pi"""
    y0 = model.ic(p, e); a = p / (1 - e * e); T = TWO_PI * a ** 1.5 / math.sqrt(model.M)
    sol = solve_ivp(model.rhs, (0, (norb + 0.9) * T), y0, method='DOP853', rtol=RTOL, atol=ATOL, events=ev_peri)
    ye = sol.y_events[0][:norb + 1]
    if len(ye) < norb + 1: raise RuntimeError('%s p=%s e=%s: only %d periastra' % (model.name, p, e, len(ye)))
    ph = [math.atan2(s[1], s[0]) for s in ye]
    adv = [((ph[k + 1] - ph[k] + math.pi) % TWO_PI) - math.pi for k in range(norb)]
    drift = 0.0
    if model.kind == 'ks':
        for s in ye:
            r = math.hypot(s[0], s[1]); nv = (s[0] * s[3] + s[1] * s[4]) / r; sl = s[2] + nv
            drift = max(drift, abs(s[2] ** 2 - s[3] ** 2 - s[4] ** 2 - 2 * model.f(r) * sl * sl - 1))
    return dict(adv=adv, mean=sum(adv) / norb, spread=max(adv) - min(adv), nfev=sol.nfev, drift=drift)

def sample_states(model, p, e, k):
    y0 = model.ic(p, e); a = p / (1 - e * e); T = TWO_PI * a ** 1.5
    sol = solve_ivp(model.rhs, (0, T), y0, method='DOP853', rtol=RTOL, atol=ATOL, dense_output=True)
    return [sol.sol(T * j / k) for j in range(k)]

# ------------------------------------------------------------------------------------------------ Part 1
def part1():
    head('(1) [bit==std] the engine\'s geodesic (frame, h table, A3 omega) against the Christoffel acceleration, exact, at 30 integrator states')
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); schw = Model('ks', 'Schwarzschild (KS)')
    states = [(100, 0.6, s) for s in sample_states(schw, 100, 0.6, 15)] + [(10, 0.4, s) for s in sample_states(schw, 10, 0.4, 15)]
    eq = 0; zpl = True; maxrel = 0.0; sgn_fail = 0; nmov = 0; dE_fail = 0; nw = 0; w_fail = 0; maxden = 0
    for i, (p, e, st) in enumerate(states):
        pt, rho0, u = rational_state(st); maxden = max(maxden, max(x.denominator.bit_length() for x in pt))
        e_, _E, _l = ks_frame_jet(pt, rho0, *ks_jets('schw', rho0))
        fr, dEp, pre = engine_coord_accel(Gv, S, e_, u)
        a_bit = [x + y for x, y in zip(fr, dEp)]; a_std = std_coord_accel(e_, u)
        eq += (a_bit == a_std); zpl &= (a_bit[3] == 0)
        fl = schw.rhs(0.0, np.array([float(pt[0]), float(pt[1]), float(u[0]), float(u[1]), float(u[2])]))
        ex = [float(a_std[k]) for k in range(3)]; sc = max(abs(v) for v in ex)
        maxrel = max(maxrel, max(abs(fl[2 + k] - ex[k]) for k in range(3)) / sc)
        frm, dEm, _ = engine_coord_accel(Gv, S, e_, u, sign=-1, pre=pre)
        sgn_fail += ([x + y for x, y in zip(frm, dEm)] != a_std)
        if u[1] != 0 or u[2] != 0: nmov += 1; dE_fail += (fr != a_std)
        if i % 5 == 0:
            ew, _, _ = ks_frame_jet(pt, rho0, *ks_jets('wrong', rho0)); frw, dEw, _ = engine_coord_accel(Gv, S, ew, u); nw += 1
            w_fail += ([x + y for x, y in zip(frw, dEw)] != a_std)
    N = len(states)
    print('    states: 15 on (p, e) = (100, 0.6) and 15 on (10, 0.4), one Kepler period each; rational points up to %d-bit denominators' % maxden)
    chk('bit==std', eq == N, 'the engine\'s coordinate acceleration (du^c/dtau = -h omega(u) u from the A3 closed form, plus (dE) u u) equals -Gamma(u, u) of e^T eta e '
        'exactly, all 4 components, at %d of %d states' % (eq, N))
    chk('bit', zpl, 'plane motion: the engine\'s z-acceleration is exactly 0 at all %d states' % N)
    chk('std', maxrel < 1e-12, 'the integrator\'s closed-form right-hand side (Kerr-Schild chart) equals the exact Christoffel acceleration at the same states: max relative difference %.1e (< 1e-12)' % maxrel)
    chk('ctl', sgn_fail == N, 'omega with the opposite sign (closed form times -1): the acceleration differs from Christoffel at %d of %d states (the sign of omega is fixed here, by [std])' % (sgn_fail, N))
    chk('ctl', dE_fail == nmov and nmov == N, 'the d E term left out (frame part alone): differs from Christoffel at %d of %d moving states' % (dE_fail, nmov))
    chk('ctl', w_fail == nw, 'engine on the frame of f = M/rho + M^2/rho^2 against Christoffel of f = M/rho: differs at %d of %d states' % (w_fail, nw))
    tick('part 1')

# ------------------------------------------------------------------------------------------------ Part 2
def fit_intercept(xs, ys, deg=2):
    c = np.polyfit(np.array(xs), np.array(ys), deg); return c[-1], c[-2]
def part2():
    head('(2) [std] geodesics of the step-12 metric (Kerr-Schild chart, f = M/rho, M = 1), DOP853 rtol 1e-13, %d orbits; [std2] quadrature' % NORB)
    schw = Model('ks', 'Schwarzschild (KS)'); tab = {}; worst = 0.0; worst_gen = 0.0; band = True; drift = 0.0; nfev = 0
    print('      e      p   advance/orbit (ODE mean)   spread    quadrature              rel.diff   R = adv/(6 pi M/p)   (R-1) p/M')
    for e in ES:
        for p in PS:
            o = orbit_advance(schw, p, e); q = schw_quad(p, e); qg = schw.quad_advance(p, e)
            rel = abs(o['mean'] - q) / q; worst = max(worst, rel); worst_gen = max(worst_gen, abs(qg - q) / q)
            R = o['mean'] / (6 * math.pi / p); band &= (1 < R < 1 + 6.0 / p); drift = max(drift, o['drift']); nfev += o['nfev']
            tab[(e, p)] = dict(o=o, q=q, R=R, Rq=q / (6 * math.pi / p))
            print('    %4.1f %6d   %.15e  %.1e  %.15e  %.1e   %.12f   %.6f' % (e, p, o['mean'], o['spread'], q, rel, R, (R - 1) * p))
    print('    right-hand side evaluations: %d; max |g(u,u) - 1| at the periastra: %.1e' % (nfev, drift))
    chk('std2', worst < 1e-8, 'integrator against the quadrature (independent of the ODE): max relative difference %.1e over 15 (p, e) (tolerance 1e-8)' % worst)
    chk('std2', worst_gen < 1e-12, 'the general static quadrature (Decimal integrand) equals the analytic Schwarzschild one: max relative difference %.1e (< 1e-12)' % worst_gen)
    chk('std', band, 'advance/(6 pi M/p) lies in (1, 1 + 6 M/p) at all 15 grid points: it tends to 1 as M/p -> 0')
    for e in ES:
        xs = [1.0 / p for p in PS]; c1, c2 = fit_intercept(xs, [(tab[(e, p)]['R'] - 1) * p for p in PS]); c1q, c2q = fit_intercept(xs, [(tab[(e, p)]['Rq'] - 1) * p for p in PS])
        pred1, pred2 = 4.5 + e * e / 4, 22.5 + 3.75 * e * e
        chk('std', abs(c1 - pred1) < 0.01, 'e = %.1f: (R - 1) p/M fitted (quadratic in M/p, 5 p) has intercept c1 = %.6f; series of the quadrature 9/2 + e^2/4 = %.6f (|diff| %.1e < 0.01); '
            'slope c2 = %.3f against 45/2 + 15 e^2/4 = %.4f (info); the same fit on the quadrature values: c1 = %.6f' % (e, c1, pred1, abs(c1 - pred1), c2, pred2, c1q))
    tick('part 2')
    return tab

# ------------------------------------------------------------------------------------------------ Part 3
def part3(tab):
    head('(3) controls: Newton closes; PPN family (recalled factor (2 + 2 gamma - beta)/3); a wrong coefficient in f')
    newt = Model('newton', 'Newton'); nmax = 0.0; nres = {}
    for p in (100, 400, 1600):
        o = orbit_advance(newt, p, 0.3); nres[p] = o; nmax = max(nmax, abs(o['mean']), max(abs(a) for a in o['adv']))
        print('    Newton p = %4d, e = 0.3: advances %s' % (p, ' '.join('%.1e' % a for a in o['adv'])))
    chk('ctl', nmax < 1e-9, 'the Newtonian orbit (same integrator, same events) closes: |advance| <= %.1e rad per orbit (< 1e-9), against 6 pi M/p >= %.1e' % (nmax, 6 * math.pi / 1600))
    xs = [1.0 / p for p in PS]; worstq = 0.0
    for (beta, gamma) in ((1, 1), (1, 0), (0, 1), (0, 0)):
        m = Model('iso', 'PPN(%d,%d)' % (beta, gamma), beta=beta, gamma=gamma); Rs = []
        for p in PS:
            o = orbit_advance(m, p, 0.3); q = m.quad_advance(p, 0.3); worstq = max(worstq, abs(o['mean'] - q) / abs(q)); Rs.append(o['mean'] / (6 * math.pi / p))
        c0, c1 = fit_intercept(xs, Rs); want = F(2 + 2 * gamma - beta, 3)
        print('    PPN (beta, gamma) = (%d, %d): R at p = 100..1600: %s' % (beta, gamma, ' '.join('%.6f' % r for r in Rs)))
        chk('std' if (beta, gamma) == (1, 1) else 'ctl', abs(c0 - float(want)) < 1e-3, 'PPN isotropic (beta, gamma) = (%d, %d)%s: fitted R(M/p -> 0) = %.6f, recalled factor (2 + 2 gamma - beta)/3 = %s (|diff| %.1e < 1e-3)'
            % (beta, gamma, ' [only g_tt changed]' if (beta, gamma) == (0, 0) else '', c0, want, abs(c0 - float(want))))
    wr = Model('ks', 'KS f = M/rho + M^2/rho^2', c2=1.0); Rw = []; sep = True
    for p in PS:
        o = orbit_advance(wr, p, 0.3); q = wr.quad_advance(p, 0.3); worstq = max(worstq, abs(o['mean'] - q) / abs(q)); Rw.append(o['mean'] / (6 * math.pi / p))
        s = tab[(0.3, p)]['o']; sep &= abs(o['mean'] - s['mean']) > 1e3 * max(o['spread'], s['spread'], 1e-15)
    c0w, _ = fit_intercept(xs, Rw)
    print('    KS with f = M/rho + M^2/rho^2: R at p = 100..1600: %s' % ' '.join('%.6f' % r for r in Rw))
    chk('ctl', sep, 'f = M/rho + M^2/rho^2 (wrong coefficient): the advance differs from Schwarzschild\'s by more than 1e3 times the spread over orbits at every p (e = 0.3)')
    chk('ctl', abs(c0w - 4.0 / 3) < 1e-3, 'f = M/rho + M^2/rho^2: fitted R(M/p -> 0) = %.6f, predicted 4/3 (areal-gauge PPN beta = 0, gamma = 1) (|diff| %.1e < 1e-3)' % (c0w, abs(c0w - 4.0 / 3)))
    chk('std2', worstq < 1e-8, 'integrator against the general quadrature for the 20 PPN runs and the 5 wrong-f runs: max relative difference %.1e (< 1e-8)' % worstq)
    tick('part 3')
    return nres

# ------------------------------------------------------------------------------------------------ Part 4
def part4(tab, nres):
    p, e, h0 = 400, 0.3, 1e-11; hs = [-2 * h0, -h0, h0, 2 * h0]
    head('(4) Schwarzschild-(anti-)de Sitter, f = M/rho + (H2/2) rho^2, p = %d, e = %.1f, H2 = %s: the H2 slope of the advance (fit)' % (p, e, ', '.join('%.0e' % h for h in hs)))
    base = tab[(e, p)]['o']['mean']; baseq = Model('ks', 'S').quad_advance(p, e); baseN = nres[p]['mean']
    di, dq, dn = [], [], []
    for h in hs:
        m = Model('ks', 'SdS', H2=h); di.append(orbit_advance(m, p, e)['mean'] - base); dq.append(m.quad_advance(p, e) - baseq)
        dn.append(orbit_advance(Model('newton', 'Kepler+osc', H2=h), p, e)['mean'] - baseN)
    X = np.array([[h, h * h] for h in hs])
    k1 = np.linalg.lstsq(X, np.array(di), rcond=None)[0][0]; k1q = np.linalg.lstsq(X, np.array(dq), rcond=None)[0][0]; k1n = np.linalg.lstsq(X, np.array(dn), rcond=None)[0][0]
    k1n_pred = 3 * math.pi * p ** 3 / (1 - e * e) ** 2.5
    print('    advance - advance(H2 = 0), integrator: %s' % ' '.join('%+.6e' % d for d in di))
    print('    fitted slopes d(advance)/d(H2): geodesic %.8e, quadrature %.8e, Newtonian Kepler + oscillator %.8e; series 3 pi p^3/(M (1-e^2)^(5/2)) = %.8e' % (k1, k1q, k1n, k1n_pred))
    print('    in units of a^3 sqrt(1 - e^2)/M: geodesic %.6f, Newtonian %.6f (series: 3 pi = %.6f)' % tuple(k / ((p / (1 - e * e)) ** 3 * math.sqrt(1 - e * e)) for k in (k1, k1n, k1n_pred)))
    chk('std', k1 > 0 and di[2] > 0 and di[3] > 0 and di[0] < 0 and di[1] < 0, 'sign: de Sitter (H2 > 0, the Atlas convention of H3) advances the periastron, anti-de Sitter (H2 < 0) makes it regress')
    chk('std2', abs(k1 / k1q - 1) < 1e-4, 'the geodesic slope from the integrator equals the quadrature\'s: |ratio - 1| = %.1e (< 1e-4)' % abs(k1 / k1q - 1))
    chk('std', abs(k1n / k1n_pred - 1) < 1e-4, 'Newtonian Kepler + oscillator: fitted slope = 3 pi p^3/(M (1 - e^2)^(5/2)) (series of the quadrature): |ratio - 1| = %.1e (< 1e-4)' % abs(k1n / k1n_pred - 1))
    chk('std', abs(k1 / k1n_pred - 1) < 0.1, 'the SdS geodesic slope is the Newtonian one up to O(M/p): ratio %.6f (|ratio - 1| < 0.1 at M/p = %.4f)' % (k1 / k1n_pred, 1.0 / p))
    print('    Bertrand: Kepler alone closes (part 3), Kepler + oscillator precesses at Newtonian order (slope above): SdS has both terms and must precess.')
    gm, am, em, Pd = 1476.625, 5.7909e10, 0.20563, 87.969       # recalled: GM_sun/c^2 [m], Mercury a [m], e, period [days]
    print('  info [recalled constants, arithmetic of the formula only] 6 pi GM/(c^2 a (1 - e^2)) for Mercury\'s recalled elements: %.3e rad per orbit, %.2f arcsec per century'
          % (6 * math.pi * gm / (am * (1 - em * em)), 6 * math.pi * gm / (am * (1 - em * em)) * 36525 / Pd * 206264.806))
    tick('part 4')

def main():
    print('D5: perihelion advance from the step-12 metric (radial Kerr-Schild frame, f = M/rho, signature +,-,-,-), n = 4, plane orbits, M = 1')
    part1()
    if '--engine-only' not in sys.argv:
        tab = part2(); nres = part3(tab); part4(tab, nres)
    finish('D5')

if __name__ == '__main__': main()
