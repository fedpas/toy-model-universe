#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""D3. Helicity 2 of the exact plane wave.   python3 d3_helicity.py

Coordinates (t, z, x, y) = x^0..x^3 (the order of gravity_moves.pw_frame), u = t - z, l^a = (1, 1, 0, 0) null, l_mu dx^mu = du.
Kerr-Schild plane-wave frame e^a = dx^a - H l^a du (metric eta - 2 H du du, signature +,-,-,-).  Profiles H = a(u)(x^2 - y^2) + 2 b(u) x y.
A rotation of the transverse plane by theta (rational: t = tan(theta/2), c = (1-t^2)/(1+t^2), s = 2t/(1+t^2)) acts on a configuration by
  coordinates X = R(theta) x  and the rotor 1 + t e2e3 on the frame index  (= the plane-wave frame of the rotated profile H o R^-1).
Measured: the transverse curvature matrix W_ij = R^{0i}_{0j} (frame components, i, j = 2, 3) and its pair P(W) = (W_22, W_23).
Exact Fractions on the engine path (selfcheck/gravity_selfcheck.py through b1lib); the [std] route is Christoffel calculus on the metric."""
import sys, os, time, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from fractions import Fraction as F

SQ = [1, -1, -1, -1]
L_UP = [1, 1, 0, 0]; L_DN = [1, -1, 0, 0]
B23 = (1 << 2) | (1 << 3)
# polarisation basis (export): plus and cross as trace-free symmetric 2x2 matrices on (x, y) = frame indices (2, 3)
POL_BASIS = {'plus': [[F(1), F(0)], [F(0), F(-1)]], 'cross': [[F(0), F(1)], [F(1), F(0)]]}

# ------------------------------------------------------------------------------------------------ plain polynomial helpers (4 variables, no truncation)
def mul(a, b):
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            k = tuple(x + y for x, y in zip(k1, k2)); r[k] = r.get(k, 0) + v1 * v2
    return {k: v for k, v in r.items() if v != 0}
def U(): return lin((F(1), var(4, 0)), (F(-1), var(4, 1)))
def prof(coefs):
    """sum_k coefs[k] u^k, u = t - z"""
    r = {}; P = const(4, 1); u = U()
    for c in coefs: r = padd(r, P, F(c)); P = mul(P, u)
    return r
def xy(i, j, c=1):
    return {tuple((1 if k == i else 0) + (1 if k == j else 0) for k in range(4)): F(c)}
def plus_profile(a): return mul(lin((F(1), xy(2, 2)), (F(-1), xy(3, 3))), a)
def cross_profile(b): return mul(xy(2, 3, 2), b)
def peq(a, b): return {k: v for k, v in a.items() if v} == {k: v for k, v in b.items() if v}
def feq(X, Y): return all(peq(X.get(m, {}), Y.get(m, {})) for m in set(X) | set(Y))

def rot_poly(P, c, s):
    """P(t, z, x, y) -> P(t, z, c X + s Y, -s X + c Y) = (P o R(theta)^-1)(X): the profile of the configuration rotated by +theta"""
    X = lin((F(c), var(4, 2)), (F(s), var(4, 3))); Y = lin((F(-s), var(4, 2)), (F(c), var(4, 3))); out = {}
    for k, v in P.items():
        term = {(k[0], k[1], 0, 0): v}
        for _ in range(k[2]): term = mul(term, X)
        for _ in range(k[3]): term = mul(term, Y)
        out = padd(out, term)
    return out
def rot_point(p, c, s): return (p[0], p[1], c * p[2] - s * p[3], s * p[2] + c * p[3])
def pythag(t): t = F(t); return (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)
def rot2(c, s): return [[c, -s], [s, c]]
def mat_mul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def mat_T(A): return [list(r) for r in zip(*A)]
def rot_k(c, s, k):
    """R(k theta) from (c, s) = (cos theta, sin theta), exact (complex power)"""
    re, im = F(1), F(0); cc, ss = (c, s) if k >= 0 else (c, -s)
    for _ in range(abs(k)): re, im = re * cc - im * ss, re * ss + im * cc
    return rot2(re, im)

# ------------------------------------------------------------------------------------------------ frames
def pw_frame_global(H):
    """[export] e^a = dx^a - H l^a l_mu dx^mu as global polynomial 1-forms {1<<mu: poly}"""
    e = []
    for a in range(4):
        form = {}
        for mu in range(4):
            p = lin((F(1 if a == mu else 0), const(4, 1)), (F(-L_UP[a] * L_DN[mu]), H))
            if p: form[1 << mu] = p
        e.append(form)
    return e
def pull_rot(forms, c, s):
    """1-forms re-expressed in X = R(theta) x:  coefficients P(R^-1 X) and dx = c dX + s dY, dy = -s dX + c dY"""
    Rinv = {0: {0: F(1)}, 1: {1: F(1)}, 2: {2: F(c), 3: F(s)}, 3: {2: F(-s), 3: F(c)}}; out = []
    for form in forms:
        new = {}
        for m, p in form.items():
            mu = m.bit_length() - 1; pr = rot_poly(p, c, s)
            for nu, co in Rinv[mu].items():
                if co: new[1 << nu] = padd(new.get(1 << nu, {}), pr, co)
        out.append({k: v for k, v in new.items() if v})
    return out
def frame_rotate(Lam, e):
    """e'^a = Lam^a_b e^b"""
    out = []
    for a in range(4):
        new = {}
        for b in range(4):
            if Lam[a][b] == 0: continue
            for m, p in e[b].items(): new[m] = padd(new.get(m, {}), p, Lam[a][b])
        out.append({k: v for k, v in new.items() if v})
    return out
def jets_at(forms, p, deg=2):
    out = []
    for form in forms:
        new = {}
        for m, pp in form.items():
            q = {k: v for k, v in shift_poly(pp, list(p), 4).items() if sum(k) <= deg}
            if q: new[m] = q
        out.append(new)
    return out

# ------------------------------------------------------------------------------------------------ bit-rule multivectors (rotor)
def mv_mul(A, B, sq=SQ):
    out = {}
    for ma, va in A.items():
        for mb, vb in B.items():
            m, sg = bmul(ma, mb, sq)
            if sg: out[m] = out.get(m, 0) + sg * va * vb
    return {k: v for k, v in out.items() if v != 0}
def mv_rev(A): return {m: v * gs.rsign(popc(m)) for m, v in A.items()}
def mv_comm(A, B): r = mv_mul(A, B); [r.__setitem__(m, r.get(m, 0) - v) for m, v in mv_mul(B, A).items()]; return {k: v for k, v in r.items() if v != 0}
def rotor_matrix(t, sq=SQ):
    """[export] the matrix Lam[c][b] of v -> R v R~ / (R R~), R = 1 + t e2e3 (bit rule), and R R~ (must be the scalar 1 + t^2)"""
    R = {0: F(1), B23: F(t)}; Rr = mv_rev(R); N = mv_mul(R, Rr)
    Lam = [[F(0)] * 4 for _ in range(4)]
    for b in range(4):
        img = mv_mul(mv_mul(R, {1 << b: F(1)}), Rr)
        for m, v in img.items():
            assert popc(m) == 1, 'sandwich is not a vector'
            Lam[m.bit_length() - 1][b] = v / N[0]
    return Lam, N

# ------------------------------------------------------------------------------------------------ engine reading of a wave frame at a point
def frame_R(Gv, R, E0):
    """R^{ab}_{cd} = R^{ab}(E_c, E_d) at the point (engine 2-forms, frame vectors E0[mu][c])"""
    Rab = Rab_at0(Gv, R, 4); out = {}
    for a in range(4):
        for b in range(4):
            if a == b: continue
            for c in range(4):
                for d in range(4):
                    if c == d: continue
                    out[(a, b, c, d)] = sum(Rab.get((a, b, m, v), 0) * E0[m][c] * E0[v][d] for m in range(4) for v in range(4) if m != v)
    return out
def transverse_W(Rf):
    """[export] W_ij = R^{0i}_{0j}, i, j = 2, 3 (frame components)"""
    return [[Rf[(0, i, 0, j)] for j in (2, 3)] for i in (2, 3)]
def pol(W): return (W[0][0], W[0][1])
def engine_wave(Gv, S, e_glob, p):
    """[bit] jets at p, omega (A3 closed form), R, E_a, torsion (engine h table), frame components of R"""
    e = jets_at(e_glob, p, 2)
    om, R = engine_om_R(Gv, e, S, 4)
    comp = engine_E_from_R(Gv, e, R, 4, 0)
    with trunc(4, xdeg=1):
        T = Gv.torsion(om, e); du = {1: const(4, 1), 2: const(4, -1)}
        null_om = all(all(all(v == 0 for v in pp.values()) for pp in Gv.Fm.wedge(om[A], du).values()) for A in range(Gv.G))
    tors0 = all(all(v == 0 for v in pp.values()) for c in T for pp in c.values())
    e0, E0, det = E0_of(e, 4, 4)
    Rf = frame_R(Gv, R, E0)
    return dict(E_zero=all(v == 0 for v in comp.values()), tors0=tors0, null_om=null_om, Rf=Rf, W=transverse_W(Rf), om=om, e0=e0, E0=E0)

# ------------------------------------------------------------------------------------------------ [std] route: metric, Christoffel, Riemann (no engine)
def std_wave(H, p):
    g = {}
    for m in range(4):
        for v in range(4):
            glob = lin((F(SQ[m] if m == v else 0), const(4, 1)), (F(-2 * L_DN[m] * L_DN[v]), H))
            g[(m, v)] = {k: x for k, x in shift_poly(glob, list(p), 4).items() if sum(k) <= 2}
    Rm, g0, g0i = std_riemann(g, 4, 4, 1)
    H0 = at0(shift_poly(H, list(p), 4), 4)
    e0 = [[F(1 if a == m else 0) - H0 * L_UP[a] * L_DN[m] for m in range(4)] for a in range(4)]       # textbook Kerr-Schild coframe and its inverse
    E0 = [[F(1 if a == m else 0) + H0 * L_UP[m] * L_DN[a] for a in range(4)] for m in range(4)]
    Rf = {}
    for a in range(4):
        for b in range(4):
            if a == b: continue
            for c in range(4):
                for d in range(4):
                    if c == d: continue
                    Rf[(a, b, c, d)] = SQ[b] * sum(e0[a][r] * Rm[(r, s_, m, v)] * E0[s_][b] * E0[m][c] * E0[v][d]
                                                    for r in range(4) for s_ in range(4) for m in range(4) for v in range(4) if Rm[(r, s_, m, v)])
    hess = [[at0(shift_poly(sp_der(sp_der(H, i), j), list(p), 4), 4) for j in (2, 3)] for i in (2, 3)]
    return Rf, hess

def main():
    head('D3.  helicity 2 of the exact plane wave; the rotation is the compact generator e2e3 of the stabiliser of the null vector (NUL-004).  n = 4, exact')
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    A23 = Lie_.idx[B23]
    # ============================================================================== (1) the stabiliser of l and its compact generator
    t0 = time.time(); head('(1) the stabiliser of the null vector l = e0 + e1 (bit rule and the engine tables)')
    l = {1: F(1), 2: F(1)}
    rows = [[F(0)] * Lie_.G for _ in range(4)]                       # (1/2)[B_A, l] by the bit rule
    for A, g in enumerate(Lie_.gens):
        for m, v in mv_comm({g: F(1)}, l).items(): rows[m.bit_length() - 1][A] += v / 2
    rows_h = [[F(0)] * Lie_.G for _ in range(4)]                     # the same from the engine's h table
    for (A, b), (c, hv) in Lie_.h.items():
        if l.get(1 << b): rows_h[c][A] += hv * l[1 << b]
    chk('bit==std', rows == rows_h, 'the map B -> (1/2)[B, l] from the bit-rule product equals the one read from the engine\'s h table (4 x 6 matrix)')
    rk = rank_exact(rows); chk('bit', rk == 3, 'the stabiliser {B : [B, l] = 0} has dimension 6 - rank = %d (expected 3)' % (Lie_.G - rk))
    le2 = mv_mul(l, {4: F(1)}); le3 = mv_mul(l, {8: F(1)}); e23 = {B23: F(1)}
    chk('bit', all(not mv_comm(X, l) for X in (le2, le3, e23)), 'l e2, l e3 and e2e3 commute with l (they span the stabiliser)')
    sqs = [mv_mul(X, X) for X in (e23, le2, le3)]
    chk('bit', sqs[0] == {0: F(-1)} and not sqs[1] and not sqs[2], 'e2e3 squares to -1 (compact: a rotation), l e2 and l e3 square to 0 (null translations): iso(2)')
    def vec_of(X): v = [F(0)] * Lie_.G; [v.__setitem__(Lie_.idx[m], c) for m, c in X.items()]; return v
    def bracket_f(x, y):
        out = [F(0)] * Lie_.G
        for (A, B), (C, f) in Lie_.f.items():
            if x[A] and y[B]: out[C] += x[A] * y[B] * f
        return out
    br_ok = True; br = {}
    for nx, X in (('e2e3', e23), ('l e2', le2), ('l e3', le3)):
        for ny, Y in (('e2e3', e23), ('l e2', le2), ('l e3', le3)):
            bb = vec_of(mv_comm(X, Y)); br_ok &= (bb == bracket_f(vec_of(X), vec_of(Y))); br[(nx, ny)] = bb
    chk('bit==std', br_ok, 'the brackets of the three stabiliser elements read from the engine\'s f table equal the bit-rule commutators')
    k2 = br[('e2e3', 'l e2')]; k3 = br[('e2e3', 'l e3')]; v2 = vec_of(le2); v3 = vec_of(le3)
    r2 = next((k2[i] / v3[i] for i in range(Lie_.G) if v3[i]), None); r3 = next((k3[i] / v2[i] for i in range(Lie_.G) if v2[i]), None)
    chk('bit', all(k2[i] == r2 * v3[i] for i in range(Lie_.G)) and all(k3[i] == r3 * v2[i] for i in range(Lie_.G)) and not any(br[('l e2', 'l e3')]),
        'iso(2): [e2e3, l e2] = %s l e3, [e2e3, l e3] = %s l e2, [l e2, l e3] = 0' % (r2, r3))
    print('    time (1): %.1f s' % (time.time() - t0))
    # ============================================================================== (2) the rotor and the h-table generator
    t0 = time.time(); head('(2) the rotor 1 + t e2e3 (bit-rule sandwich) = exp(theta J) with J the e2e3 rows of the engine\'s h table = the rotation R(theta) of (x, y)')
    J = [[F(0)] * 4 for _ in range(4)]
    for (A, b), (c, hv) in Lie_.h.items():
        if A == A23: J[c][b] += hv
    J2 = mat_mul(J, J); TS = [F(1, 2), F(1, 3), F(2, 3), F(-1, 4)]; rot_ok = True; exp_ok = True; norm_ok = True; LAM = {}
    for t in TS:
        c, s = pythag(t); Lam, N = rotor_matrix(t); LAM[t] = Lam
        norm_ok &= (N == {0: 1 + F(t) ** 2})
        want = [[F(1), 0, 0, 0], [0, F(1), 0, 0], [0, 0, c, -s], [0, 0, s, c]]
        rot_ok &= (Lam == want)
        exp_ok &= (Lam == [[F(int(i == j)) + s * J[i][j] + (1 - c) * J2[i][j] for j in range(4)] for i in range(4)])
    chk('bit', norm_ok, 'R R~ = 1 + t^2 (a scalar) for t = %s' % [str(x) for x in TS])
    chk('bit', rot_ok, 'the sandwich R v R~/(R R~) fixes e0, e1 and rotates (e2, e3) by +theta: e2 -> c e2 + s e3, e3 -> -s e2 + c e3, c = (1-t^2)/(1+t^2), s = 2t/(1+t^2)')
    chk('bit', exp_ok, 'it equals exp(theta J) = 1 + s J + (1 - c) J^2 with J read from the engine\'s h table (e2e3 rows): bit rule vs. matrix')
    print('    time (2): %.1f s' % (time.time() - t0))
    # ============================================================================== (3) the rotated frame
    t0 = time.time(); head('(3) coordinates rotated (X = R x) and the rotor on the frame index give the plane-wave frame of the rotated profile H o R^-1')
    a_u = prof([1, 2, -1, 3]); b_u = prof([2, 0, 1]); Hp = plus_profile(a_u); Hc = cross_profile(b_u); Hs = padd(Hp, Hc)
    fr_ok = True; nr_differs = True
    for t in TS:
        c, s = pythag(t)
        for H in (Hp, Hc, Hs):
            e_rot = frame_rotate(LAM[t], pull_rot(pw_frame_global(H), c, s)); e_new = pw_frame_global(rot_poly(H, c, s))
            fr_ok &= all(feq(x, y) for x, y in zip(e_rot, e_new))
            nr_differs &= not all(feq(x, y) for x, y in zip(pull_rot(pw_frame_global(H), c, s), e_new))
    chk('bit', fr_ok, 'Lambda(theta) . (frame in rotated coordinates) = pw_frame(H o R^-1): all 16 coefficient polynomials, plus / cross / sum, 4 angles (global, exact)')
    chk('ctl', nr_differs, 'control: without the rotor on the frame index (coordinates rotated only) the frame is NOT the rotated-profile frame')
    hp_rot = rot_poly(Hp, *pythag(F(1, 2))); want = lin((F(-7, 25), plus_profile(a_u)), (F(24, 25), cross_profile(a_u)))
    chk('bit', peq(hp_rot, want), 'the plus profile rotated by theta (t = 1/2: cos 2theta = -7/25, sin 2theta = 24/25) is cos 2theta (plus) + sin 2theta (cross) with the same a(u): (a, b) -> R(2 theta)(a, b) at the profile level')
    print('    time (3): %.1f s' % (time.time() - t0))
    # ============================================================================== (4) engine curvature at rational points, weight 2
    t0 = time.time(); head('(4) engine curvature (omega = A3 closed form) of the original and rotated waves at rational points p and p\' = R p')
    PTS = [(F(1, 2), F(-1, 3), F(2), F(-3, 2)), (F(-2), F(1, 5), F(-1, 3), F(5, 4)), (F(3, 4), F(2), F(1), F(1, 2))]
    allE = True; allT = True; sym_tf = True; Wcov = True; fullcov = True; w2 = True; wrong = {k: True for k in (0, 1, -1, -2, 3)}; Tok = True; nonflat = True
    std_ok = True; text_ok = True; nst = 0; TT = {}; allnull = True
    def Rf_cov(Rf, Lam, Rf2):
        Li = det_inv(Lam)[1]                                   # lower indices transform with the inverse
        for a, b, c, d in Rf2:
            v = sum(Lam[a][a1] * Lam[b][b1] * Rf.get((a1, b1, c1, d1), 0) * Li[c1][c] * Li[d1][d]
                    for a1 in range(4) for b1 in range(4) for c1 in range(4) for d1 in range(4) if Lam[a][a1] and Lam[b][b1] and Li[c1][c] and Li[d1][d])
            if v != Rf2[(a, b, c, d)]: return False
        return True
    for ip, p in enumerate(PTS):
        base = {}
        for name, H in (('plus', Hp), ('cross', Hc), ('sum', Hs)):
            r = engine_wave(Gv, S, pw_frame_global(H), p); base[name] = r
            allE &= r['E_zero']; allT &= r['tors0']; allnull &= r['null_om']; W = r['W']; nonflat &= any(W[i][j] != 0 for i in range(2) for j in range(2))
            sym_tf &= (W[0][1] == W[1][0] and W[0][0] + W[1][1] == 0)
            if ip < 2 or name == 'sum':
                Rs, hess = std_wave(H, p); nst += 1
                std_ok &= all(Rs[k] == r['Rf'][k] for k in Rs)
                text_ok &= (W == [[-hess[i][j] for j in range(2)] for i in range(2)])
        for t in TS + [F(7, 4), F(1, 13)]:
            c, s = pythag(t); Lam = rotor_matrix(t)[0]; pq = rot_point(p, c, s); rotd = {}
            for name, H in (('plus', Hp), ('cross', Hc), ('sum', Hs)):
                if name == 'sum' and t not in TS: continue
                r = engine_wave(Gv, S, pw_frame_global(rot_poly(H, c, s)), pq); rotd[name] = r
                allE &= r['E_zero']; allT &= r['tors0']
                Wo = base[name]['W']; Wn = r['W']; R2 = rot2(c, s)
                Wcov &= (Wn == mat_mul(mat_mul(R2, Wo), mat_T(R2)))
                if name == 'sum' and ip == 0: fullcov &= Rf_cov(base[name]['Rf'], Lam, r['Rf'])
                P0, P1 = pol(Wo), pol(Wn)
                w2 &= (list(P1) == [sum(rot_k(c, s, 2)[i][j] * P0[j] for j in range(2)) for i in range(2)])
                for k in wrong: wrong[k] &= (list(P1) != [sum(rot_k(c, s, k)[i][j] * P0[j] for j in range(2)) for i in range(2)])
            B0 = [[pol(base['plus']['W'])[i], pol(base['cross']['W'])[i]] for i in range(2)]
            B1 = [[pol(rotd['plus']['W'])[i], pol(rotd['cross']['W'])[i]] for i in range(2)]
            T_ = mat_mul(B1, det_inv(B0)[1]); TT[(ip, t)] = T_; Tok &= (T_ == rot_k(c, s, 2))
    chk('bit', allE, 'E_a = 0 (16 components) for plus, cross and sum, original and rotated, at %d points and 6 angles: every configuration is vacuum' % len(PTS))
    chk('bit', allT, 'the closed-form omega is torsion-free under the engine\'s h table (T = 0 to first order) at every point (A3 re-read on these frames)')
    chk('bit', allnull, 'every omega^A of the wave is proportional to du (omega^A ^ du = 0 to first order, base frames, 3 points): omega ^ omega = 0, so R = d omega and the quadratic term of R is never read here')
    chk('bit', nonflat and sym_tf, 'W_ij = R^{0i}_{0j} (i, j = 2, 3) is non-zero, symmetric and trace-free at every point (the vacuum wave lives in the trace-free part)')
    chk('bit', Wcov, 'W\'(p\') = R(theta) W(p) R(theta)^T exactly, plus / cross at 3 points and 6 angles, sum at 3 points and 4 angles')
    chk('bit', fullcov, 'the whole frame tensor transforms: R\'^{ab}_{cd}(p\') = Lam Lam R(p) Lam^-1 Lam^-1 (all components, sum profile, point 1, 4 angles)')
    chk('bit', w2, 'weight 2: P(W\') = R(2 theta) P(W) with P(W) = (W_22, W_23), every profile, point and angle')
    for k in wrong: chk('ctl', wrong[k], 'control: the gravitational pair does NOT turn by %s theta (weight %d excluded at every angle)' % (k, k))
    chk('bit', Tok, 'T(theta), read from the engine on the (plus, cross) basis, equals R(2 theta) at every point and angle')
    comp_ok = True
    for (t1, t2, t12) in ((F(1, 2), F(2, 3), F(7, 4)), (F(1, 3), F(-1, 4), F(1, 13))):
        c1, s1 = pythag(t1); c2, s2 = pythag(t2); c12, s12 = pythag(t12)
        comp_ok &= (c12 == c1 * c2 - s1 * s2 and s12 == s1 * c2 + c1 * s2)
        comp_ok &= all(peq(rot_poly(rot_poly(H, c1, s1), c2, s2), rot_poly(H, c12, s12)) for H in (Hp, Hc))
        comp_ok &= (rotor_matrix(t12)[0] == mat_mul(rotor_matrix(t2)[0], rotor_matrix(t1)[0]))
        for ip in range(len(PTS)): comp_ok &= (TT[(ip, t12)] == mat_mul(TT[(ip, t2)], TT[(ip, t1)]))
    chk('bit', comp_ok, 'representation: T(theta1 + theta2) = T(theta2) T(theta1) for (t1, t2) = (1/2, 2/3) and (1/3, -1/4) (composed t = 7/4, 1/13), at 3 points; the profile rotated twice equals the profile rotated by the composed angle; the rotors compose')
    chk('bit==std', std_ok, 'the engine\'s frame tensor R^{ab}_{cd} equals the Riemann tensor of g = eta - 2 H l l from Christoffel symbols (b1lib.std_riemann, MTW sign), all components, %d point-profile pairs' % nst)
    chk('std', text_ok, 'textbook closed form: W = -Hess_perp(H) at every point, so W = -2 [[a, b], [b, -a]] for H = a (x^2 - y^2) + 2 b x y')
    print('    time (4): %.1f s' % (time.time() - t0))
    # ============================================================================== (5) controls: frame index not rotated; Maxwell; scalar; null dust
    t0 = time.time(); head('(5) controls: the frame index not rotated (weight 0); a Maxwell plane wave (weight 1); a scalar wave (weight 0); null dust (pure trace)')
    p = PTS[0]; t = F(1, 2); c, s = pythag(t); pq = rot_point(p, c, s)
    r0 = engine_wave(Gv, S, pw_frame_global(Hs), p); rnr = engine_wave(Gv, S, pull_rot(pw_frame_global(Hs), c, s), pq)
    chk('bit', rnr['Rf'] == r0['Rf'], 'coordinates rotated, frame index NOT rotated: every frame component of R at p\' equals the one at p (a change of chart alone does not move frame components)')
    chk('ctl', list(pol(rnr['W'])) != [sum(rot_k(c, s, 2)[i][j] * pol(r0['W'])[j] for j in range(2)) for i in range(2)],
        'control: so without the rotor the pair does not turn by 2 theta (weight 0): the weight is the response to the rotor e2e3 on the frame index')
    # Maxwell
    f_u = prof([0, 1, 3, -2]); alpha, beta = F(2, 3), F(-5, 4)
    A = {1 << 2: mul(f_u, const(4, alpha)), 1 << 3: mul(f_u, const(4, beta))}
    dA = Fm.d(A)
    Fstd = {}
    for m in range(4):
        for v in range(m + 1, 4):
            q = padd(sp_der(A.get(1 << v, {}), m), sp_der(A.get(1 << m, {}), v), -1)
            if q: Fstd[(1 << m) | (1 << v)] = q
    chk('bit==std', feq(dA, Fstd), 'the engine\'s d of A = f(u)(alpha dx + beta dy) equals F_{mu nu} = d_mu A_nu - d_nu A_mu by plain differentiation (sign-sensitive)')
    def maxwell_div(H, Fd):
        gi = {}
        for m in range(4):
            for v in range(4): gi[(m, v)] = lin((F(SQ[m] if m == v else 0), const(4, 1)), (F(2 * L_UP[m] * L_UP[v]), H))
        Fl = {}
        for m in range(4):
            for v in range(4):
                if m == v: continue
                k = (1 << min(m, v)) | (1 << max(m, v)); Fl[(m, v)] = scale(Fd.get(k, {}), 1 if m < v else -1)
        ok = True
        for nu in range(4):
            div = {}
            for mu in range(4):
                Fup = {}
                for a_ in range(4):
                    for b_ in range(4):
                        if a_ != b_ and Fl[(a_, b_)] and gi[(mu, a_)] and gi[(nu, b_)]: Fup = padd(Fup, mul(mul(gi[(mu, a_)], gi[(nu, b_)]), Fl[(a_, b_)]))
                div = padd(div, sp_der(Fup, mu))
            ok &= not div
        return ok
    mx_ok = True; mx_w1 = True; mx_w2 = True; sc_w0 = True
    phi = prof([1, -2, 0, 1])
    for H0, (pp, tt) in itertools.product((Hp, Hs), ((PTS[0], F(1, 2)), (PTS[1], F(2, 3)), (PTS[2], F(-1, 4)))):
        c, s = pythag(tt); pq = rot_point(pp, c, s); H1 = rot_poly(H0, c, s)
        Arot = pull_rot([A], c, s)[0]
        mx_ok &= maxwell_div(H0, dA) and maxwell_div(H1, Fm.d(Arot))
        def Fpair(H, Aform, q):
            e = jets_at(pw_frame_global(H), q, 1); E0 = E0_of(e, 4, 4)[1]; Fd = Fm.d(Aform)
            val = lambda k: at0(shift_poly(Fd.get(k, {}), list(q), 4), 4)
            Fab = lambda a, b: sum(val((1 << m) | (1 << v)) * (E0[m][a] * E0[v][b] - E0[v][a] * E0[m][b]) for m in range(4) for v in range(m + 1, 4))
            return (Fab(0, 2), Fab(0, 3))
        P0 = Fpair(H0, A, pp); P1 = Fpair(H1, Arot, pq)
        mx_w1 &= (list(P1) == [sum(rot_k(c, s, 1)[i][j] * P0[j] for j in range(2)) for i in range(2)]) and any(P0)
        mx_w2 &= (list(P1) != [sum(rot_k(c, s, 2)[i][j] * P0[j] for j in range(2)) for i in range(2)])
        def dphi(H, q):
            e = jets_at(pw_frame_global(H), q, 1); E0 = E0_of(e, 4, 4)[1]
            g = [at0(shift_poly(sp_der(phi, m), list(q), 4), 4) for m in range(4)]
            return [sum(E0[m][a] * g[m] for m in range(4)) for a in range(4)]
        sc_w0 &= (dphi(H0, pp) == dphi(H1, pq)) and peq(rot_poly(phi, c, s), phi)
    box = {}
    for m in range(4):
        for v in range(4):
            gmv = lin((F(SQ[m] if m == v else 0), const(4, 1)), (F(2 * L_UP[m] * L_UP[v]), Hs))
            box = padd(box, sp_der(mul(gmv, sp_der(phi, v)), m))
    chk('std', mx_ok, 'Maxwell\'s equations d_mu(g^{mu a} g^{nu b} F_ab) = 0 hold exactly (sqrt(-g) = 1, g^-1 = eta^-1 + 2 H l l) for the original and the rotated configuration: a Maxwell plane wave on the gravitational wave')
    chk('bit', mx_w1, 'Maxwell: the frame pair (F_02, F_03) turns by theta (weight 1), 3 points / angles, on the plus and on the sum background')
    chk('ctl', mx_w2, 'control: the Maxwell pair does NOT turn by 2 theta')
    chk('std', not box, 'scalar wave phi = f(u): box phi = d_mu(g^{mu nu} d_nu phi) = 0 exactly on the wave background')
    chk('bit', sc_w0, 'scalar: phi o R^-1 = phi and the frame components of d phi at p\' equal those at p: weight 0')
    Hd = mul(lin((F(1), xy(2, 2)), (F(1), xy(3, 3))), a_u); rd = engine_wave(Gv, S, pw_frame_global(Hd), PTS[1])
    c, s = pythag(F(2, 3)); rd1 = engine_wave(Gv, S, pw_frame_global(rot_poly(Hd, c, s)), rot_point(PTS[1], c, s)); Wd = rd['W']
    chk('ctl', not rd['E_zero'], 'control: the profile (x^2 + y^2) a(u) is NOT vacuum (E_a != 0): null dust')
    chk('bit', Wd[0][1] == 0 and Wd[0][0] == Wd[1][1] != 0 and rd1['W'] == Wd and peq(rot_poly(Hd, c, s), Hd), 'its W is pure trace and does not turn (weight 0): the weight-2 part is exactly the trace-free (vacuum) part')
    print('    time (5): %.1f s' % (time.time() - t0))
    head('export: polarisation basis plus = [[1, 0], [0, -1]], cross = [[0, 1], [1, 0]] (frame indices 2, 3); W = -2 (a plus + b cross) for H = a (x^2 - y^2) + 2 b x y; weights: gravity 2, Maxwell 1, scalar 0')
    finish('D3')

if __name__ == '__main__': main()
