#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H5L-B-Kerr: the Bianchi identity of the so(2,4) Cartan curvature on Kerr and Kerr-Newman frames, exact 4-jets at rational points.   python3 h5l_bianchi_kerr.py
 Frames: e^a = dx^a - f l^a l_mu dx^mu with f = (M r - s) r^2/(r^4 + a^2 z^2) and l the Kerr congruence (the conventions of g2_kerr and f2_first_law.kn_frame_jet),
        here as exact jets of degree 4 in delta = x - p: the root r(x, y, z) by the chord iteration to degree 4, reciprocals by the geometric series.
 Chain: frame 4-jet -> omega 3-jet (A3's closed form) -> R 2-jet -> Schouten and f = S e 2-jets -> F = (W, T^, G, C) 1-jet -> D_A F at the point.
 [bit]  the engine's Einstein form E_a = 0 as a 2-jet on Kerr (Ricci and its first and second derivatives vanish at the point); the Schouten tensor zero as a 2-jet
        on Kerr, not on Kerr-Newman; the full D_A F = dF + (1/2) f A ^ F = 0 at the point (15 x 4 components) with f = Schouten, b = 0 (h5l_bianchi's machinery);
        the components D_L W^{ab} = e^a C^b - e^b C^a and D_L C^a = (W.f)^a at the point (W the Weyl 2-form, C the Cotton 2-form); on Kerr both sides zero with
        W != 0; on Kerr-Newman both nonzero, and W.f zero or not per point.
 [std]  the 4-jet of P(r) is empty, l is null and e.E = 1 as 4-jets, the 4-jets truncated to degree 2 equal g2_kerr.kerr_ks_frame_jet and f2_first_law.kn_frame_jet,
        the a = 0 members equal h5l_frames.ks_frame_jetK (a different series route); an own Christoffel route (metric 4-jet, Gamma 3-jet, Riemann and Ricci 2-jets);
        h5l_bianchi.std_route2 (Weyl 1-jet, Cotton 2-form 1-jet): d_nabla Weyl = dx ^ Cot - Cot ^ dx and d_nabla Cot = Weyl ^ S at the point.
 [bit==std] W^{ab}, D_L W^{ab}, D_L C^a at the point carried to frame indices; the Schouten 2-jet carried to frame indices.
 Controls: the vacuum form "D_L W = 0" fails on Kerr-Newman; a wrong denominator of f (den_k = 2) gives E_a != 0 and a Cotton 2-form != 0; the 4-jet truncated to
        degree 3 fed to the same chain gives E_a != 0 and Schouten != 0 at degree 2 (D_A F = 0 at the point survives any truncation: it is an identity of the table
        for any polynomial A, not a test of the jets); f with an antisymmetric part added to S gives G != 0 and breaks the reduced D and K forms, not the J form.
 Scope: n = 4, (+,-,-,-), the so(2,4) table of the pair (+1, -1), exact Fractions, rational points of the advanced Kerr-Schild chart (r > 0, off the ring),
        Kerr (M, a) = (5, 3) on the axis, on the equator and generic, Kerr-Newman (M, a, s) = (5, 1, 4) and (7/2, 2, 1), the a = 0 members at (2, 3, 6); local;
        nothing about nature.
 Exports (import-safe, no engine object at import): kerr_ks_frame_jetK(p, M, a, order, s, ...), kerr_r_jetK(p, r0, a, order), recipK(A, order), std_ricci_jet(e, deg),
        cartan_run(C, e, E, want_E)."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from fractions import Fraction as F
from h5l_conformal import Conf, compose, curvature6, fzero, ftrunc, fmul0, SQ4
from h5l_bianchi import engine_data_k, D_full, comp_terms, std_route2, at_pt, MUNU, LMV, mask
import g2_kerr as GK

NV = 4
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def clean(p): return {k: v for k, v in p.items() if v != 0}

# ------------------------------------------------------------------------------------------------ exact jets of any order (same conventions as g2_kerr)
def recipK(A, order, nv=NV):
    """1/A as a jet of degree `order` (A with a non-zero constant term): geometric series"""
    A0 = at0(A, nv); assert A0 != 0
    B = scale(lin((F(1), A), (F(-1), const(nv, A0))), -1 / A0); t = const(nv, 1 / A0); res = dict(t)
    for _ in range(order): t = sp_mul(t, B, order, nv); res = sp_add(res, t)
    return res
def kerr_r_jetK(p, r0, a, order, nv=NV):
    """jet of degree `order` of r(x) at p (r(p) = r0) by the chord iteration s <- s - P(r0 + s)/P'(r0), one order per step; returns (r jet, jet of P(r), which must be empty)"""
    a = F(a); mul = lambda u, w: sp_mul(u, w, order, nv)
    X = [None] + [lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))) for i in (1, 2, 3)]
    rho2 = lin(*[(F(1), mul(X[i], X[i])) for i in (1, 2, 3)]); Z2 = mul(X[3], X[3])
    Pp = 4 * r0 ** 3 - 2 * (sum(c * c for c in p) - a * a) * r0
    assert Pp == 2 * (r0 ** 4 + a * a * p[2] ** 2) / r0 and Pp != 0
    coef = lin((F(1), rho2), (-a * a, const(nv, 1)))
    def Pof(s):
        r = lin((F(1), const(nv, r0)), (F(1), s)); r2 = mul(r, r)
        return lin((F(1), mul(r2, r2)), (F(-1), mul(coef, r2)), (-a * a, Z2))
    s = {}
    for _ in range(order + 1): s = lin((F(1), s), (-1 / Pp, Pof(s)))
    return lin((F(1), const(nv, r0)), (F(1), s)), clean(Pof(s))
def kerr_ks_frame_jetK(p, M, a, order=4, s=0, r0=None, nv=NV, a_l=None, den_k=1, Mf=None, retarded=False):
    """coframe e^a = dx^a - f l^a l_mu dx^mu of Kerr-Newman (Kerr: s = 0) in Kerr-Schild form around p = (x, y, z), exact jets of degree `order` in delta = x - p;
    f = (Mf r - s) r^2/(r^4 + den_k a^2 z^2), l_mu dx^mu = dt + ((r x + a_l y) dx + (r y - a_l x) dy)/(r^2 + a_l^2) + z dz/r, l^a = eta^{ab} l_b.
    Controls: a_l (the a used in l only; default a), den_k (default 1), Mf (default M); retarded: l_i -> -l_i.
    Returns (e, E, (l_up, l_dn), data) like g2_kerr.kerr_ks_frame_jet: e as forms {1<<mu: poly}, E[mu][a] = delta + f l^mu l_a (the inverse when l is null,
    a_l^2 = a^2; a Neumann series otherwise), data {'r', 'f', 'r0', 'resP' (jet of P(r)), ...}."""
    p = tuple(F(c) for c in p); M, a, s, den_k = F(M), F(a), F(s), F(den_k); a_l = a if a_l is None else F(a_l); Mf = M if Mf is None else F(Mf)
    if r0 is None:
        b = sum(c * c for c in p) - a * a; sq_ = GK.rat_sqrt(b * b + 4 * a * a * p[2] ** 2); r0 = GK.rat_sqrt((b + sq_) / 2) if sq_ is not None else None
        if r0 is None: raise ValueError('r(p) is not rational at %s: use g2_kerr.rational_kerr_points' % (p,))
    r0 = F(r0); assert r0 > 0 and GK.kerr_P(r0, p, a) == 0
    mul = lambda u, w: sp_mul(u, w, order, nv)
    X = [None] + [lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))) for i in (1, 2, 3)]
    r, resP = kerr_r_jetK(p, r0, a, order, nv)
    r2 = mul(r, r); r3 = mul(r2, r); r4 = mul(r2, r2); Z2 = mul(X[3], X[3])
    f = mul(lin((Mf, r3), (-s, r2)), recipK(lin((F(1), r4), (den_k * a * a, Z2)), order, nv))
    invA = recipK(lin((F(1), r2), (a_l * a_l, const(nv, 1))), order, nv); invr = recipK(r, order, nv)
    l1 = mul(lin((F(1), mul(r, X[1])), (a_l, X[2])), invA); l2 = mul(lin((F(1), mul(r, X[2])), (-a_l, X[1])), invA); l3 = mul(X[3], invr)
    if retarded: l1, l2, l3 = scale(l1, -1), scale(l2, -1), scale(l3, -1)
    l_dn = [const(nv, 1), l1, l2, l3]; l_up = [const(nv, 1)] + [scale(q, -1) for q in (l1, l2, l3)]
    e = []; E = [[None] * 4 for _ in range(4)]
    for A_ in range(4):
        form = {}
        for mu in range(4):
            pol = lin((F(1 if A_ == mu else 0), const(nv, 1)), (F(-1), mul(mul(f, l_up[A_]), l_dn[mu])))
            if pol: form[1 << mu] = pol
            E[mu][A_] = lin((F(1 if A_ == mu else 0), const(nv, 1)), (F(1), mul(mul(f, l_up[mu]), l_dn[A_])))
        e.append(form)
    if a_l * a_l != a * a:
        with trunc(4, xdeg=order): E, _ = inverse_series(frame_matrix(e, 4), 4, nv, order)
    data = dict(r=r, f=f, r0=r0, cth=p[2] / r0, resP=resP, p=p, M=M, a=a, s=s, a_l=a_l, den_k=den_k, Mf=Mf, retarded=retarded, order=order, l_up=l_up, l_dn=l_dn)
    return e, E, (l_up, l_dn), data
def null_norm(l_up, l_dn, order, nv=NV):
    """eta^{ab} l_a l_b = l^mu l_mu as a jet (must be empty for the Kerr congruence)"""
    return clean(lin(*[(F(1), sp_mul(l_up[mu], l_dn[mu], order, nv)) for mu in range(4)]))
def frame_inverse_residual(e, E, order, nv=NV):
    """sum_mu e^a_mu E^mu_b - delta^a_b as jets: the list of non-empty residuals"""
    out = []
    for a in range(4):
        for b in range(4):
            t = lin(*[(F(1), sp_mul(e[a].get(1 << mu, {}), E[mu][b], order, nv)) for mu in range(4)])
            t = clean(lin((F(1), t), (F(-1 if a == b else 0), const(nv, 1))))
            if t: out.append((a, b))
    return out
def forms_equal(e1, e2, deg, nv=NV):
    """two coframes (lists of {mask: poly}) equal as deg-jets"""
    for a in range(4):
        for mu in range(4):
            p, q = ftrunc({1: e1[a].get(1 << mu, {})}, deg).get(1, {}), ftrunc({1: e2[a].get(1 << mu, {})}, deg).get(1, {})
            if clean(sp_add(p, q, -1)): return False
    return True

# ------------------------------------------------------------------------------------------------ [std] own Christoffel route as jets (no engine)
def std_ricci_jet(e, sq=SQ4, n=4, deg=2):
    """metric (deg+2)-jet, inverse metric (deg+1)-jet, Gamma (deg+1)-jet, Riemann R^r_{smv}, Ricci R_{sv} = R^r_{srv}, scalar curvature and Schouten
    S_{mv} = (1/2) R_{mv} - (1/12) R g_{mv} as deg-jets (coordinate components, polynomials in delta)"""
    g = std_metric(e, n, sq, n, deg + 2); gi, g0, g0i = std_inverse_metric(g, n, n, deg + 1)
    dg = {(k, a, b): sp_der(g[(a, b)], k) for k in range(n) for a in range(n) for b in range(n)}
    Gam = {}
    for l in range(n):
        for m in range(n):
            for v in range(m, n):
                t = {}
                for s_ in range(n):
                    br = sp_add(sp_add(dg[(m, s_, v)], dg[(v, s_, m)]), dg[(s_, m, v)], -1)
                    if br and gi[(l, s_)]: t = sp_add(t, sp_mul(gi[(l, s_)], br, deg + 1, n), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    Riem = {}
    for r in range(n):
        for s_ in range(n):
            for m in range(n):
                for v in range(m + 1, n):
                    t = sp_add(sp_der(Gam[(r, v, s_)], m), sp_der(Gam[(r, m, s_)], v), -1)
                    for l in range(n): t = sp_add(sp_add(t, sp_mul(Gam[(r, m, l)], Gam[(l, v, s_)], deg, n)), sp_mul(Gam[(r, v, l)], Gam[(l, m, s_)], deg, n), -1)
                    t = {k: c for k, c in t.items() if sum(k) <= deg}; Riem[(r, s_, m, v)] = t; Riem[(r, s_, v, m)] = scale(t, -1)
            for m in range(n): Riem[(r, s_, m, m)] = {}
    Ric = {(s_, v): lin(*[(F(1), Riem[(r, s_, r, v)]) for r in range(n)]) for s_ in range(n) for v in range(n)}
    Rs = lin(*[(F(1), sp_mul(gi[(s_, v)], Ric[(s_, v)], deg, n)) for s_ in range(n) for v in range(n)])
    Sch = {(m, v): lin((F(1, 2), Ric[(m, v)]), (F(-1, 12), sp_mul(Rs, g[(m, v)], deg, n))) for m in range(n) for v in range(n)}
    return dict(Ric=Ric, Rs=Rs, Sch=Sch, g=g, gi=gi)
def to_frame_jet(T, E, deg, n=4, nv=NV):
    """T_{mu nu} (coordinate, polynomials) -> T_ab = E^mu_a E^nu_b T_{mu nu} as deg-jets"""
    out = {}
    for a in range(n):
        for b in range(n):
            t = {}
            for mu in range(n):
                for nu in range(n):
                    if T[(mu, nu)] and E[mu][a] and E[nu][b]: t = sp_add(t, sp_mul(sp_mul(E[mu][a], E[nu][b], deg, n), T[(mu, nu)], deg, n))
            out[(a, b)] = clean(t)
    return out

# ------------------------------------------------------------------------------------------------ [bit] the chain on one frame (h5l_bianchi part 4's machinery)
def cartan_run(C, e, want_E=True):
    """engine data of h5l_bianchi.engine_data_k (omega 3-jet, R, Schouten and f 2-jets), then at the point: the full D_A F, the J and K component pieces,
    the counts, and (want_E) the engine's Einstein form E_a as a 2-jet.  Returns a dict."""
    d = engine_data_k(C, e, 3); Gl = C.Gl; out = dict(d=d)
    if want_E:
        with trunc(4, xdeg=2): Ea, _ = Gl.einstein(None, e, d['R'], 0)
        out['Ea'] = Ea; out['Ea_zero'] = all(not clean(p) for X in Ea for p in X.values()); out['Ea_pt_zero'] = all(not x for x in at_pt(Ea))
        out['Ea1_zero'] = all(fzero(ftrunc(X, 1)) for X in Ea)
    out['S_zero'] = all(not clean(p) for p in d['Sch'].values()); out['f_zero'] = all(fzero(x) for x in d['f'])
    om2 = [ftrunc(x, 2) for x in d['om']]; e2 = [ftrunc(x, 2) for x in e]; out['om2'] = om2; out['e2'] = e2
    with trunc(4, xdeg=1):
        A = compose(C, om2, e2, d['f']); Fx = curvature6(C, A)
        DF = D_full(C, A, Fx); ct = comp_terms(C, om2, e2, d['f'], None, Fx)
    out['DF0_zero'] = all(not x for x in at_pt(DF)); out['ct'] = ct
    out['J0'] = at_pt(ct['J'][0]); out['Jr'] = at_pt(ct['J'][1][0]); out['K0'] = at_pt(ct['K'][0]); out['Kr'] = at_pt(ct['K'][1][1])
    out['T1_zero'] = all(fzero(ftrunc(x, 1)) for x in ct['Th']); out['G_zero'] = fzero(ct['G'])
    out['C1_zero'] = all(fzero(ftrunc(x, 1)) for x in ct['C'])
    out['nzJ'] = sum(len(x) for x in out['J0']); out['nzK'] = sum(len(x) for x in out['K0']); out['nzKr'] = sum(len(x) for x in out['Kr'])
    out['nzC'] = sum(len(x) for x in at_pt(ct['C'])); out['nzW'] = sum(len(x) for x in at_pt(ct['W']))
    return out
def std_compare(C, e, run):
    """[std] std_route2 on the frame and [bit==std] W, D_L W, D_L C at the point carried to frame indices (as h5l_bianchi part 4)"""
    st = std_route2(e); ct = run['ct']; J0, K0 = run['J0'], run['K0']
    e0 = [[at0(e[a].get(1 << mu, {}), 4) for mu in range(4)] for a in range(4)]; gi = st['g0i']
    Wfr = lambda a, b, key: sum(e0[a][r] * e0[b][k] * gi[k][s] * key(r, s) for r in range(4) for s in range(4) for k in range(4))
    okW = all(at0(ct['W'][A4].get(mask(*mn), {}), 4) == Wfr(a, b, lambda r, s: st['W0'][(r, s) + mn]) for A4, (a, b) in enumerate(C.pairs4) for mn in MUNU)
    okDW = all(J0[A4].get(mask(*lmv), F(0)) == Wfr(a, b, lambda r, s: st['dW'][(r, s) + lmv]) for A4, (a, b) in enumerate(C.pairs4) for lmv in LMV)
    okDC = all(K0[a].get(mask(*lmv), F(0)) == sum(e0[a][r] * st['dC'][(r,) + lmv] for r in range(4)) for a in range(4) for lmv in LMV)
    return dict(st=st, okW=okW, okDW=okDW, okDC=okDC, nzdW=sum(1 for v in st['dW'].values() if v), nzdC=sum(1 for v in st['dC'].values() if v),
                ident=(st['dW'] == st['rW'] and st['dC'] == st['rC']))

# ------------------------------------------------------------------------------------------------ the points
def kpoint(a, r, ct, st, cp, sp):
    """the rational point x = sin th (r cos ph - a sin ph), y = sin th (r sin ph + a cos ph), z = r cos th (g2_kerr.rational_kerr_points)"""
    return GK.rational_kerr_points(a, [r], [((ct, st), (cp, sp))])[0]
M5, A3 = F(5), F(3)
KERR_PTS = [('axis (0, 0, 7), r = 7', kpoint(A3, 7, 1, 0, 1, 0)), ('equator r = 9, (cos ph, sin ph) = (4/5, 3/5)', kpoint(A3, 9, 0, 1, F(4, 5), F(3, 5))),
            ('generic r = 20, (cos th, sin th) = (3/5, 4/5), (cos ph, sin ph) = (4/5, 3/5)', kpoint(A3, 20, F(3, 5), F(4, 5), F(4, 5), F(3, 5)))]
KN_LIST = [('(M, a, s) = (5, 1, 4), generic r = 20, (3/5, 4/5), (4/5, 3/5)', M5, F(1), F(4), kpoint(F(1), 20, F(3, 5), F(4, 5), F(4, 5), F(3, 5))),
           ('(M, a, s) = (5, 1, 4), equator r = 20, (4/5, 3/5)', M5, F(1), F(4), kpoint(F(1), 20, 0, 1, F(4, 5), F(3, 5))),
           ('(M, a, s) = (7/2, 2, 1), axis (0, 0, 4), r = 4', F(7, 2), F(2), F(1), kpoint(F(2), 4, 1, 0, 1, 0)),
           ('(M, a, s) = (7/2, 2, 1), equator r = 5, (4/5, 3/5)', F(7, 2), F(2), F(1), kpoint(F(2), 5, 0, 1, F(4, 5), F(3, 5)))]
MORE_KERR = [('(5, 3) r = 1 (the inner horizon), (3/5, 4/5), (4/5, 3/5)', M5, A3, kpoint(A3, 1, F(3, 5), F(4, 5), F(4, 5), F(3, 5))),
             ('(5, 3) r = 4, (-5/13, 12/13), (-8/17, 15/17)', M5, A3, kpoint(A3, 4, F(-5, 13), F(12, 13), F(-8, 17), F(15, 17))),
             ('(5, 3) r = 1/2 (inside r-), (12/13, 5/13), (0, 1)', M5, A3, kpoint(A3, F(1, 2), F(12, 13), F(5, 13), 0, 1)),
             ('(5, 3) axis (0, 0, -4)', M5, A3, kpoint(A3, 4, -1, 0, 1, 0)),
             ('(1, 1/2) r = 2, (3/5, 4/5), (4/5, 3/5)', F(1), F(1, 2), kpoint(F(1, 2), 2, F(3, 5), F(4, 5), F(4, 5), F(3, 5))),
             ('(3/2, 2) r = 1 (a > M, no horizon), (5/13, 12/13), (3/5, 4/5)', F(3, 2), F(2), kpoint(F(2), 1, F(5, 13), F(12, 13), F(3, 5), F(4, 5)))]
def pstr(P): return '(%s)' % ', '.join(str(c) for c in P['p'])
def weyl_pseudo_invariant(st, n=4):
    """[std] the two quadratic invariants of the Weyl tensor at the point from std_route2's W^r_{smv} and g0: I1 = W_{rsmv} W^{rsmv},
    I2 = W_{rsmv} [m v p q] W^{rs pq} / 2 (the contraction with the dual; sqrt(-g) = 1 on these frames, so [m v p q] is the Levi-Civita tensor up to sign);
    I2 = 0 iff the Weyl tensor has no magnetic part relative to its electric part (Im Psi_2^2 = 0 for type D)"""
    from g2_hodge import perm_sign
    g0, gi, W0 = st['g0'], st['g0i'], st['W0']; R4 = range(n)
    Wd = {(r, s_, m, v): sum(g0[r][k] * W0[(k, s_, m, v)] for k in R4) for r in R4 for s_ in R4 for m in R4 for v in R4}
    def raise_all(T):
        out = {}
        for (r, s_, m, v) in T:
            out[(r, s_, m, v)] = sum(gi[r][a] * gi[s_][b] * gi[m][c] * gi[v][d] * T[(a, b, c, d)] for a in R4 for b in R4 for c in R4 for d in R4 if T[(a, b, c, d)])
        return out
    Wu = raise_all(Wd)
    I1 = sum(Wd[k] * Wu[k] for k in Wd)
    I2 = F(1, 2) * sum(Wd[(r, s_, m, v)] * perm_sign((m, v, p, q)) * Wu[(r, s_, p, q)] for (r, s_, m, v) in Wd if Wd[(r, s_, m, v)]
                       for p in R4 for q in R4 if len({m, v, p, q}) == 4)
    return I1, I2

def main():
    C = Conf(); Fm = C.Gv.Fm
    import f2_first_law as F2
    from h5l_frames import ks_frame_jetK
    # ============================================================================== part 1: the jets
    head('Part 1. Exact 4-jets of the Kerr-Schild frames at rational points (chord iteration to degree 4): the root, null l, the inverse frame, the match with the 2-jet helpers')
    frames = {}
    for name, P in KERR_PTS: frames['Kerr ' + name] = kerr_ks_frame_jetK(P['p'], M5, A3, 4, 0, P['r'])
    for name, M, a, s, P in KN_LIST: frames['Kerr-Newman ' + name] = kerr_ks_frame_jetK(P['p'], M, a, 4, s, P['r'])
    P0 = KERR_PTS[0][1]
    frames['Kerr axis, a -> -a in l alone'] = kerr_ks_frame_jetK(P0['p'], M5, A3, 4, 0, P0['r'], a_l=-A3)
    frames['Kerr axis, wrong denominator den_k = 2'] = kerr_ks_frame_jetK(P0['p'], M5, A3, 4, 0, P0['r'], den_k=2)
    p7 = (2, 3, 6)
    frames['Schwarzschild M = 1 at (2, 3, 6)'] = kerr_ks_frame_jetK(p7, 1, 0, 4, 0)
    frames['RN M = 1, s = 1/2 at (2, 3, 6)'] = kerr_ks_frame_jetK(p7, 1, 0, 4, F(1, 2))
    okP = all(fr[3]['resP'] == {} for fr in frames.values()); okN = all(null_norm(fr[2][0], fr[2][1], 4) == {} for fr in frames.values())
    okI = all(frame_inverse_residual(fr[0], fr[1], 4) == [] for fr in frames.values())
    chk('std', okP, 'the 4-jet of P(r) = r^4 - (rho^2 - a^2) r^2 - a^2 z^2 is empty at every point (%d frames; chord iteration, 5 steps, pivot P\'(r0) = 2 (r0^4 + a^2 z0^2)/r0): r is THE 4-jet of the root' % len(frames))
    chk('std', okN, 'l is null as a 4-jet on every frame (eta^{ab} l_a l_b = 0 to degree 4), also with a -> -a in l alone')
    chk('std', okI, 'e^a_mu E^mu_b = delta^a_b as 4-jets on every frame (E = delta + f l l is the exact inverse to degree 4)')
    ok2 = True
    for name, P in KERR_PTS: ok2 &= forms_equal(frames['Kerr ' + name][0], GK.kerr_ks_frame_jet(P['p'], M5, A3, P['r'])[0], 2)
    ok2 &= forms_equal(frames['Kerr axis, a -> -a in l alone'][0], GK.kerr_ks_frame_jet(P0['p'], M5, A3, P0['r'], a_l=-A3)[0], 2)
    ok2 &= forms_equal(frames['Kerr axis, wrong denominator den_k = 2'][0], GK.kerr_ks_frame_jet(P0['p'], M5, A3, P0['r'], den_k=2)[0], 2)
    chk('std', ok2, 'the Kerr 4-jets truncated to degree 2 equal g2_kerr.kerr_ks_frame_jet exactly (3 points, the a_l and den_k variants included)')
    ok2 = all(forms_equal(frames['Kerr-Newman ' + name][0], F2.kn_frame_jet(P['p'], M, a, s, P['r'])[0], 2) for name, M, a, s, P in KN_LIST)
    chk('std', ok2, 'the Kerr-Newman 4-jets truncated to degree 2 equal f2_first_law.kn_frame_jet exactly (%d points)' % len(KN_LIST))
    okS = forms_equal(frames['Schwarzschild M = 1 at (2, 3, 6)'][0], ks_frame_jetK(p7, 7, 1, order=4), 4)
    okR = forms_equal(frames['RN M = 1, s = 1/2 at (2, 3, 6)'][0], ks_frame_jetK(p7, 7, 1, 0, F(1, 2), order=4), 4)
    chk('std', okS and okR, 'a = 0: the 4-jets of f = M/r - s/r^2 on l = (1, x/r) equal h5l_frames.ks_frame_jetK (rho-power series, a different route) exactly to degree 4: Schwarzschild M = 1 and RN M = 1, s = 1/2 at (2, 3, 6)')
    tick('part 1')
    # ============================================================================== part 2: Kerr
    head('Part 2. Kerr (M, a) = (5, 3): E_a = 0 and the Schouten tensor = 0 as 2-jets, the Cartan curvature (W, 0, 0, 0), D_A F = 0 and D_L W = 0 at the point; [std] Ricci 2-jet = 0')
    runs = {}
    for name, P in KERR_PTS:
        key = 'Kerr ' + name; e, E, l, data = frames[key]; run = cartan_run(C, e, True); runs[key] = run
        chk('bit', run['Ea_zero'], '%s: the engine\'s Einstein form E_a = 0 as a 2-jet (all 4 x 4 components, every monomial to degree 2: Ricci and its first and second derivatives vanish at the point)' % key)
        chk('bit', run['S_zero'] and run['f_zero'], '%s: the Schouten tensor is zero as a 2-jet (16 frame components), so f = S e = 0' % key)
        chk('bit', run['T1_zero'] and run['G_zero'] and run['C1_zero'] and run['nzW'] > 0, '%s: F = (W, 0, 0, 0): T^ = 0 to first order, G = 0, the Cotton 2-form C = 0 as a 1-jet, W != 0 (%d components at the point)' % (key, run['nzW']))
        chk('bit', run['DF0_zero'], '%s: the full D_A F = 0 at the point (15 x 4 components; an identity of the table, here on the Kerr fields)' % key)
        chk('bit', run['nzJ'] == 0 and run['nzK'] == 0 and run['nzKr'] == 0, '%s: D_L W = 0 at the point (all 24 components; the vacuum Bianchi identity of the Weyl 2-form) and D_L C = 0 = W.f' % key)
        sr = std_ricci_jet(e, deg=2)
        chk('std', all(not clean(p) for p in sr['Ric'].values()), '%s: [std] Christoffel route (metric 4-jet, Gamma 3-jet, Riemann 2-jet): Ricci = 0 as a 2-jet, all 16 coordinate components' % key)
        sc = std_compare(C, e, run)
        chk('std', sc['ident'] and sc['nzdW'] == 0 and sc['nzdC'] == 0, '%s: [std] d_nabla Weyl = dx ^ Cot - Cot ^ dx and d_nabla Cot = Weyl ^ S at the point, both sides zero (Cot = 0)' % key)
        chk('bit==std', sc['okW'] and sc['okDW'] and sc['okDC'], '%s: the engine\'s W^{ab} (nonzero), D_L W^{ab} and D_L C^a at the point = e^a_rho e^b_kappa g^{kappa sigma} (Weyl, d_nabla Weyl)^rho_sigma and e^a_rho d_nabla Cot^rho of the std route' % key)
        tick(key)
    key = 'Kerr axis, a -> -a in l alone'; e = frames[key][0]; run = cartan_run(C, e, True); runs[key] = run
    chk('bit', run['Ea_zero'] and run['S_zero'] and run['DF0_zero'] and run['nzJ'] == 0 and run['nzK'] == 0 and run['nzW'] > 0,
        '%s (Kerr with spin -a; r and f even in a): E_a = 0 and Schouten = 0 as 2-jets, D_A F = 0, D_L W = 0 at the point, W != 0: the sign of a is invisible to the vacuum statements' % key)
    okJ = okE = okS = okB = okR = True; nW = []
    for name, M, a, P in MORE_KERR:
        e, E, l, data = kerr_ks_frame_jetK(P['p'], M, a, 4, 0, P['r']); run = cartan_run(C, e, True); sr = std_ricci_jet(e, deg=2)
        okJ &= data['resP'] == {} and null_norm(l[0], l[1], 4) == {} and frame_inverse_residual(e, E, 4) == []
        okE &= run['Ea_zero']; okS &= run['S_zero'] and run['f_zero'] and run['C1_zero']; okB &= run['DF0_zero'] and run['nzJ'] == 0 and run['nzK'] == 0 and run['nzW'] > 0
        okR &= all(not clean(p) for p in sr['Ric'].values()); nW.append(run['nzW'])
    more = '; '.join(name for name, M, a, P in MORE_KERR)
    chk('std', okJ, '%d more Kerr points, (M, a) = %s: the 4-jet of P(r) is empty, l is null and e.E = 1 as 4-jets' % (len(MORE_KERR), more))
    chk('bit', okE, 'at these %d points: E_a = 0 as a 2-jet (Ricci and its first and second derivatives vanish; the inner horizon, inside r-, the south axis, a < M and a > M members included)' % len(MORE_KERR))
    chk('bit', okS and okB, 'at these %d points: Schouten = 0 as a 2-jet, Cotton = 0 as a 1-jet, D_A F = 0, D_L W = 0 at the point, W != 0 (%s components)' % (len(MORE_KERR), ', '.join(map(str, nW))))
    chk('std', okR, 'at these %d points: [std] Christoffel route: Ricci = 0 as a 2-jet' % len(MORE_KERR))
    tick('part 2')
    # ============================================================================== part 3: Kerr-Newman
    head('Part 3. Kerr-Newman (a != 0, s != 0): Schouten != 0, Cotton != 0, D_L W^{ab} = e^a C^b - e^b C^a and D_L C^a = (W.f)^a at the point; [std] second-order Christoffel route')
    inv = {}
    for name, M, a, s, P in KN_LIST:
        key = 'Kerr-Newman ' + name; e, E, l, data = frames[key]; run = cartan_run(C, e, False); runs[key] = run
        sr = std_ricci_jet(e, deg=2)
        chk('bit', not run['S_zero'] and run['T1_zero'] and run['G_zero'] and run['nzW'] > 0, '%s: the Schouten tensor is not zero (as a 2-jet), T^ = 0 to first order, G = 0: F = (W, 0, 0, C)' % key)
        chk('std', (not all(not clean(p) for p in sr['Ric'].values())) and clean(sr['Rs']) == {}, '%s: [std] Ricci != 0 and the scalar curvature = 0 as a 2-jet (the Maxwell stress is trace-free), so S = Ric/2' % key)
        Sfr = to_frame_jet(sr['Sch'], E, 2)
        chk('bit==std', all(clean(sp_add(run['d']['Sch'][(a_, b_)], Sfr[(a_, b_)], -1)) == {} for a_ in range(4) for b_ in range(4)),
            '%s: the engine\'s Schouten tensor S_ab as a 2-jet (16 frame components) = E^mu_a E^nu_b S_{mu nu} of the std route' % key)
        chk('bit', run['DF0_zero'], '%s: the full D_A F = 0 at the point (15 x 4 components; an identity of the table, here on the Kerr-Newman fields)' % key)
        chk('bit', run['J0'] == run['Jr'] and run['nzJ'] > 0 and run['nzC'] > 0, '%s: Cotton != 0 (%d components at the point) and D_L W^{ab} = e^a C^b - e^b C^a != 0 (%d nonzero 3-form components)' % (key, run['nzC'], run['nzJ']))
        chk('bit', run['K0'] == run['Kr'], '%s: D_L C^a = (W.f)^a at the point, %s' % (key, 'both sides NONZERO (%d components): the Cotton 2-form is not covariantly closed here' % run['nzK'] if run['nzK'] else 'both sides ZERO (the Weyl 2-form has no part that the Schouten tensor reads here)'))
        chk('ctl', run['nzJ'] > 0, '%s: "D_L W = 0" (the vacuum form) fails here (ok)' % key)
        sc = std_compare(C, e, run)
        chk('std', sc['ident'], '%s: [std] Christoffel route: d_nabla Weyl^rho_sigma = dx^rho ^ Cot_sigma - dx_sigma ^ Cot^rho and d_nabla Cot^rho = Weyl^rho_sigma ^ S^sigma (all components; nonzero dW: %d, dC: %d)' % (key, sc['nzdW'], sc['nzdC']))
        chk('bit==std', sc['okW'] and sc['okDW'] and sc['okDC'], '%s: the engine\'s W^{ab}, D_L W^{ab} and D_L C^a at the point = e^a_rho e^b_kappa g^{kappa sigma} (Weyl, d_nabla Weyl)^rho_sigma and e^a_rho d_nabla Cot^rho of the std route' % key)
        I1, I2 = weyl_pseudo_invariant(sc['st']); inv[key] = (I1, I2, sc['nzdC'])
        tick(key)
    chk('std', all((I2 == 0) == (nzK == 0) for I1, I2, nzK in inv.values()) and all(I1 != 0 for I1, I2, nzK in inv.values()) and len({nzK == 0 for I1, I2, nzK in inv.values()}) == 2,
        'at the %d Kerr-Newman points: d_nabla Cot = Weyl ^ S vanishes exactly where the pseudoscalar Weyl invariant W_{rsmv} (*W)^{rsmv} vanishes (the equatorial points: no magnetic part), '
        'and is nonzero where it does not (the generic and axis points); the scalar invariant W_{rsmv} W^{rsmv} != 0 everywhere; I2 = %s' % (len(inv), ', '.join(str(I2) for I1, I2, nzK in inv.values())))
    tick('part 3')
    # ============================================================================== part 4: controls
    head('Part 4. Controls: a wrong f, the 4-jet truncated to degree 3, an antisymmetric part added to S')
    key = 'Kerr axis, wrong denominator den_k = 2'; e = frames[key][0]; run = cartan_run(C, e, True)
    chk('ctl', not run['Ea_pt_zero'] and run['nzC'] > 0, '%s (f = M r^3/(r^4 + 2 a^2 z^2), not vacuum): E_a != 0 at the point and the Cotton 2-form != 0 at the point (%d components) (ok)' % (key, run['nzC']))
    e3 = [ftrunc(x, 3) for x in frames['Kerr ' + KERR_PTS[0][0]][0]]; run = cartan_run(C, e3, True)
    chk('ctl', (not run['Ea_zero']) and not run['S_zero'], 'the Kerr 4-jet (axis point) truncated to degree 3 and fed to the same chain: E_a != 0 and the Schouten tensor != 0 at degree 2 (ok): the vacuum statements at degree 2 read the degree-4 part of the frame')
    chk('bit', run['Ea1_zero'] and run['DF0_zero'], 'the same truncated frame: E_a = 0 as a 1-jet (the 3-jet carries the vacuum statement to first order) and D_A F = 0 at the point still holds: that line is an identity of the table for any polynomial A, not a test of the jets')
    key = 'Kerr-Newman ' + KN_LIST[0][0]; e, E, l, data = frames[key]; run = runs[key]; d = run['d']; om2, e2 = run['om2'], run['e2']
    Aanti = {(0, 1): F(1, 3), (1, 0): F(-1, 3), (2, 3): F(1, 2), (3, 2): F(-1, 2)}
    fbad = [d['f'][a_] for a_ in range(4)]
    for (a_, b_), v in Aanti.items(): fbad[a_] = Fm.add(fbad[a_], fmul0(const(4, v * SQ4[a_]), e2[b_]))
    with trunc(4, xdeg=1):
        A = compose(C, om2, e2, fbad); Fx = curvature6(C, A); DFb = D_full(C, A, Fx); ctb = comp_terms(C, om2, e2, fbad, None, Fx)
    J0b = at_pt(ctb['J'][0]); Jrb = at_pt(ctb['J'][1][0]); K0b = at_pt(ctb['K'][0]); Krb = at_pt(ctb['K'][1][1]); eC0 = at_pt([ctb['eC']])
    chk('ctl', (not fzero(ctb['G'])) and any(eC0) and K0b != Krb, '%s with f = (S + antisymmetric) e: G != 0, eta_ab e^a C^b != 0 and D_L C != W.f at the point (the G f term) (ok): the reduced D and K forms need S symmetric' % key)
    chk('bit', J0b == Jrb and all(not x for x in at_pt(DFb)), 'the same f: D_L W^{ab} = e^a C^b - e^b C^a still holds at the point (the J equation has no G term) and D_A F = 0 (an identity for any A)')
    tick('part 4')
    # ============================================================================== part 5: the a = 0 members
    head('Part 5. The a = 0 members at (2, 3, 6), rho = 7: Schwarzschild M = 1 and RN M = 1, s = 1/2 on the Kerr-Newman jets (the radial class numbers)')
    key = 'Schwarzschild M = 1 at (2, 3, 6)'; run = cartan_run(C, frames[key][0], True)
    chk('bit', run['Ea_zero'] and run['S_zero'] and run['DF0_zero'] and run['C1_zero'] and run['nzJ'] == 0 and run['nzK'] == 0 and run['nzW'] > 0,
        '%s: E_a = 0 and Schouten = 0 as 2-jets, D_A F = 0, Cotton = 0 as a 1-jet, D_L W = 0 and D_L C = 0 = W.f at the point, W != 0' % key)
    key = 'RN M = 1, s = 1/2 at (2, 3, 6)'; run = cartan_run(C, frames[key][0], False)
    chk('bit', run['DF0_zero'] and run['J0'] == run['Jr'] and run['nzC'] == 18 and run['nzJ'] == 18 and run['K0'] == run['Kr'] and run['nzK'] == 0,
        '%s: D_A F = 0, Cotton != 0 (%d components), D_L W^{ab} = e^a C^b - e^b C^a != 0 (%d), D_L C^a = (W.f)^a with both sides zero (the static-frame coincidence)' % (key, run['nzC'], run['nzJ']))
    tick('part 5')
    finish('H5L-B-Kerr')

if __name__ == '__main__': main()
