#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H1-rotation: the duality rotation of the curvature table and the Einstein form.   python3 h1_duality_rotation.py

 The duality rotation multiplies the bivector values of the curvature 2-form on the right by e^{tI}, I = gamma_0123 (in Lorentz signature the
 electric-magnetic duality rotation; on the six plane labels it is the complex structure J of h1_petrov.py, I B_A = s_A B_J(A)).  It acts on the upper
 pair of R^{ab}_{cd}:  R_t = cos t R + sin t J R.  Statements:
   (1) the Weyl part turns by a phase: Q(W_t) = e^{-it} Q(W) for Q = E + iB (h1_petrov.py's Q); the Petrov type is unchanged;
   (2) for ANY table X of bivector-valued 2-forms, E_a[J X] = -eta_aa X^a_b ^ e^b (the cyclic 3-form); on F = R + c e^a e^b of a torsion-free frame it vanishes
       (the first Bianchi identity), so E_a[F_t] = cos t E_a(c) and E_a(c)[R_t] = cos t E_a(0) + (E_a(c) - E_a(0)): the Einstein form is not covariant,
       and a quarter turn gives E_a = 0 on every frame;
   (3) R_t is a curvature table (pair symmetric, first Bianchi) only where R is pure Weyl: J turns the trace-free Ricci piece pair-antisymmetric and the scalar
       piece (Rs/12) e^a e^b into (Rs/12) eps_abcd (epsilon trace of R_t: sin t Rs/4); the Ricci contraction of R_t is cos t Ric;
   (4) the two-sided map S -> S(J., J.) of h1_petrov.py (act_J) is an involution of curvature tables, not a rotation: cos t R + sin t act_J R multiplies Q by
       cos t - sin t and takes the Einstein tensor G = S_tf - (Rs/4) delta to (cos t + sin t) S_tf - (cos t - sin t)(Rs/4) delta.
 [bit]  omega = A3 closed form, R = the engine's curvature at the origin of exact 2-jets; the rotation by the bit rule's product B_A I; Grav.einstein on the
        rotated list of 2-forms; frame components, the Weyl projection, Q and the Petrov type in exact Q(i) (g2_weyl.py).
 [std]  numpy: the Riemann tensor of the metric e^T eta e by the Christoffel route (exact, then floats), the textbook left dual (1/2) eps^{ab}_{ef} X^{ef}_{cd}
        with eps_0123 = +1, the rotated plain 6x6 table, the textbook Ricci and Einstein contraction, E_a = -(G - 3c delta) Theta_h (the form of A4);
        Q of the rotated Weyl tensor by weyl_float.
 Controls: t = 0 is the identity; the quarter turn on type D maps Q to -iQ (E - iB to i(E - iB)); the complement with the Levi-Civita sign and no eta signs
 (g2_weyl.wrong_J_levi) gives a different E_a wherever the curvature has a magnetic cell; invariance E_a[R_t] = E_a[R] fails off vacuum; the two-sided map
 has no phase; the textbook dual with eps_0123 = -1 is -J.
 Scope: n = 4, squares (+,-,-,-), one rational point on each of eight frames (Schwarzschild, Schwarzschild-de Sitter, de Sitter, Reissner-Nordstrom, Kerr,
 a plane wave, FRW, a random frame), six rational (cos t, sin t); linear algebra on the curvature table at a point, nothing about field equations."""
import os, sys, time, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
from g2_weyl import (duality_J, wrong_J_levi, act_J, J_matrix, J_square, cell_vector, tensor_of_cells, eps_row, weyl_parts, std_frame_riemann, complex_Q,
                     petrov, QI, all_traces_zero, weyl_float, frw_frame, pw_frame, pw_global, random_rational_point, PAIRS4, PIDX, PS4, EPS3)
from l3_cartan_weyl import frame_comps, weyl36, lowered_full, P36, lin36, EE, K36, eq36, is0
from h5l_frames import ks_frame_jetK
import g2_kerr as GK
import numpy as np

SQ = [1, -1, -1, -1]
TS = [(F(1), F(0)), (F(3, 5), F(4, 5)), (F(0), F(1)), (F(-5, 13), F(12, 13)), (F(4, 5), F(-3, 5)), (F(-1), F(0))]     # (cos t, sin t), exact
CS = [F(0), F(1, 3)]
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def fmt_t(ct, st): return '(%s, %s)' % (ct, st)

# ------------------------------------------------------------------------------------------------ [bit] the rotation by the bit rule
def right_I(L):
    """[bit] B_A I = s_A B_J(A), I = gamma_0123, from the bit rule's product: list of (J(A), s_A)"""
    out = []
    for g in L.gens:
        m, s = bmul(g, PS4, L.sq); out.append((L.idx[m], s))
    return out
def rot_list(Fm, X, J, ct, st):
    """[bit] X e^{tI}: the bivector values sum_A X^A B_A times (cos t + sin t I), X a list of six 2-forms"""
    out = [Fm.scale(X[A], ct) for A in range(6)]
    if st != 0:
        for A, (B, s) in enumerate(J): out[B] = Fm.add(out[B], X[A], st * s)
    return out
def rot36(X, J, ct, st):
    """the same rotation on 36 frame components X^{ab}_{cd} (upper pair = bivector value)"""
    out = {k: ct * X[k] for k in K36}
    for A, (B, s) in enumerate(J):
        for cd in PAIRS4: out[PAIRS4[B] + cd] += st * s * X[PAIRS4[A] + cd]
    return out
def comps36(X, E0): return {PAIRS4[A] + cd: v for A in range(6) for cd, v in frame_comps(X[A], E0).items()}
def E_of(Gv, e, X, c=0):
    """[bit] components of the engine's Einstein form E_a = sum eps (X^{bc} + c e^b e^c) e^d at the origin"""
    with trunc(4, xdeg=1): Ea, _ = Gv.einstein(None, e, X, F(c))
    return einstein_components(Ea, 4, 4)
def F_list(Gv, e, R, c):
    Fm = Gv.Fm
    with trunc(4, xdeg=1): return [Fm.add(R[A], Fm.wedge(e[a], e[b]), c) if c else R[A] for A, (a, b) in enumerate(PAIRS4)]
def cyclic3(Gv, e, X, labels=None):
    """[bit] the 3-forms X^a_b ^ e^b = sum_b eta_bb X^{ab} ^ e^b (X^{ba} = -X^{ab}); only the labels given (default all); components at the origin"""
    Fm = Gv.Fm; out = []
    with trunc(4, xdeg=1):
        for a in range(4):
            tot = {}
            for b in range(4):
                A = PIDX[(min(a, b), max(a, b))] if a != b else None
                if A is not None and (labels is None or A in labels): tot = Fm.add(tot, Fm.wedge(X[A], e[b]), (1 if a < b else -1) * SQ[b])
            out.append(tot)
    return einstein_components(out, 4, 4)
def list_of36(Gv, e, X36):
    """the 2-forms X^{ab} = sum_{c<d} X^{ab}_{cd} e^c ^ e^d (exact at the origin), as a list over the six labels"""
    Fm = Gv.Fm; out = []
    with trunc(4, xdeg=1):
        ee = {cd: Fm.wedge(e[cd[0]], e[cd[1]]) for cd in PAIRS4}
        for ab in PAIRS4:
            tot = {}
            for cd in PAIRS4:
                if X36[ab + cd]: tot = Fm.add(tot, ee[cd], X36[ab + cd])
            out.append(tot)
    return out
def rand_table(rng):
    """six constant 2-forms with random rational coefficients: a table that is not a curvature"""
    out = []
    for A in range(6):
        X = {}
        for (m, n) in PAIRS4:
            v = F(rng.randint(-6, 6), rng.randint(1, 4))
            if v: X[(1 << m) | (1 << n)] = const(4, v)
        out.append(X)
    return out
ALL4 = list(itertools.product(range(4), repeat=4))
def pair_sym(T): return all(T[(a, b, c, d)] == T[(c, d, a, b)] for (a, b, c, d) in ALL4)
def pair_anti(T): return all(T[(a, b, c, d)] == -T[(c, d, a, b)] for (a, b, c, d) in ALL4)
def cyc0(T): return all(T[(a, b, c, d)] + T[(a, c, d, b)] + T[(a, d, b, c)] == 0 for (a, b, c, d) in ALL4)
def eps_tr(T): return T[(0, 1, 2, 3)] - T[(0, 2, 1, 3)] + T[(0, 3, 1, 2)]
def perm_sign(p):
    s = 1
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i] > p[j]: s = -s
    return s
def total_anti(T, val):
    """T_abcd = val * (sign of the permutation) for distinct indices, 0 otherwise"""
    return all(T[k] == (val * perm_sign(k) if len(set(k)) == 4 else 0) for k in ALL4)
def ricci_low(T): return {(b, d): sum(SQ[a] * T[(a, b, a, d)] for a in range(4)) for b in range(4) for d in range(4)}

# ------------------------------------------------------------------------------------------------ [std] numpy: textbook dual and contraction (never the engine)
ETA = np.diag([float(x) for x in SQ]); ETAI = np.linalg.inv(ETA)
def eps_lower(sign=1):
    E = np.zeros((4, 4, 4, 4))
    for p in itertools.permutations(range(4)): E[p] = sign * perm_sign(p)
    return E
EPSMIX = np.einsum('ax,by,xycd->abcd', ETAI, ETAI, eps_lower(1))             # eps^{ab}_{cd} with eps_0123 = +1
DDm = np.einsum('ac,bd->abcd', np.eye(4), np.eye(4)) - np.einsum('ad,bc->abcd', np.eye(4), np.eye(4))
def std_dual(Xm, epsmix=EPSMIX): return 0.5 * np.einsum('abef,efcd->abcd', epsmix, Xm)
def mixed_np(Rl): return np.array([[[[float(SQ[a] * SQ[b] * Rl[(a, b, c, d)]) for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)])
def std_E(Xm, fr):
    """[std] E_a = -(G^h_a) Theta_h with G the textbook Einstein contraction of the mixed table X^{ab}_{cd} (Ric^b_d = X^{ab}_{ad})"""
    Ric = np.einsum('abad->bd', Xm); Rs = np.trace(Ric); G = Ric - 0.5 * Rs * np.eye(4)
    return predicted_components(G.tolist(), fr['e0f'], fr['E0f'], fr['detf'], 4, s=-1)
def std_Q(Cl):
    """[std] Q = E + iB of a lowered float Weyl table (own index loops)"""
    eps = np.zeros((3, 3, 3))
    for (i, j, k), s in EPS3.items(): eps[i - 1, j - 1, k - 1] = s
    return Cl[0, 1:, 0, 1:] + 1j * 0.5 * np.einsum('ikl,jkl->ij', eps, Cl[0, 1:, 1:, 1:])

# ------------------------------------------------------------------------------------------------ frames (h1_petrov.py's points where it has them)
def frames():
    out = [('Schwarzschild M = 1, p = (1, 2, 2)', ks_frame_jetK((1, 2, 2), 3, 1, 0, 0, order=2), 'D', None),
           ('SdS M = 1, H2 = 1/5, p = (2, 3, 6)', ks_frame_jetK((2, 3, 6), 7, 1, F(1, 5), 0, order=2), 'D', F(1, 5)),
           ('de Sitter H2 = 1/5, p = (1, 2, 2)', ks_frame_jetK((1, 2, 2), 3, 0, F(1, 5), 0, order=2), 'O', F(1, 5)),
           ('Reissner-Nordstrom M = 1, charge term 1/2, p = (2, 3, 6)', ks_frame_jetK((2, 3, 6), 7, 1, 0, F(1, 2), order=2), 'D', None)]
    d = GK.rational_kerr_points(F(1, 2), [F(3)], [((F(3, 5), F(4, 5)), (F(1), F(0)))])[0]
    out.append(('Kerr M = 1, a = 1/2, r = %s, cos th = %s' % (d['r'], d['cth']), GK.kerr_ks_frame_jet(d['p'], 1, F(1, 2), d['r'])[0], 'D', None))
    p = random_rational_point(random.Random(11))
    out.append(('plane wave h = (1, 2, -1, 3) at (%s)' % ', '.join(str(x) for x in p), pw_frame(pw_global((1, 2, -1, 3), ()), p), 'N', None))
    out.append(('FRW a = 1 + t + t^2 at t = 0', frw_frame((1, 1, 1)), 'O', None))
    out.append(('random polynomial frame (seed 5)', rand_frame(random.Random(5), 4, deg=2, coef=2, density=.5), 'I', None))
    return out

# ------------------------------------------------------------------------------------------------ one frame
def run_frame(Gv, S, J, Jw, name, e, expect, H2, rng):
    Fm = Gv.Fm; om, R = engine_om_R(Gv, e, S, 4)
    with trunc(4, xdeg=0): tz = torsion_zero_at0(Gv, om, e, 4)
    e0, E0, det = E0_of(e, 4, 4); R36 = comps36(R, E0); Rl = lowered_full(R36)
    wb = weyl36(Rl); W, P, Rs = wb['W'], wb['P'], wb['Rs']; Ppc = P36(P); Spc = lin36((Rs / 12, EE)); Wl = lowered_full(W)
    fr = dict(e0f=[[float(x) for x in r] for r in e0], E0f=[[float(x) for x in r] for r in E0], detf=float(det))
    chk('bit', tz and eq36(R36, lin36((1, W), (1, Ppc), (1, Spc))) and all(v == 0 for v in cyclic3(Gv, e, R).values()),
        '%s: precondition: T = 0 at the point; R = W + (e^a P^b - e^b P^a) + (Rs/12) e^a e^b (36 components); the cyclic 3-form R^a_b ^ e^b = 0 '
        '(first Bianchi, by the engine\'s wedge)' % name)
    Rstd = std_frame_riemann(e, 4, SQ); Rm = mixed_np(Rstd)
    chk('bit==std', Rstd == Rl, '%s: the engine\'s frame Riemann equals the Christoffel route of the metric exactly (256 components)' % name)
    # ---- (2) E_a of J X for any table, and the rule in t
    X = rand_table(rng); EX = E_of(Gv, e, rot_list(Fm, X, J, F(0), F(1))); cX = cyclic3(Gv, e, X)
    chk('bit', EX == {(a, mu): -SQ[a] * v for (a, mu), v in cX.items()} and any(v != 0 for v in cX.values()),
        '%s: for a random table X (not a curvature) E_a[J X] = -eta_aa X^a_b ^ e^b exactly, 16 components (non-zero)' % name)
    Ec = {c: E_of(Gv, e, R, c) for c in CS + ([H2] if H2 is not None and H2 not in CS else [])}
    ruleR, ruleF, errR, errF, inv_fail, inv_tot = True, True, 0.0, 0.0, 0, 0
    sc = max([1.0] + [abs(float(v)) for E_ in Ec.values() for v in E_.values()])
    for (ct, st) in TS:
        Rt = rot_list(Fm, R, J, ct, st)
        for c in Ec:
            Et = E_of(Gv, e, Rt, c); want = {k: ct * Ec[F(0)][k] + (Ec[c][k] - Ec[F(0)][k]) for k in Et}; ruleR &= (Et == want)
            EF = E_of(Gv, e, rot_list(Fm, F_list(Gv, e, R, c), J, ct, st), 0); ruleF &= (EF == {k: ct * Ec[c][k] for k in EF})
            if ct != 1 and any(v != 0 for v in Ec[F(0)].values()): inv_tot += 1; inv_fail += int(Et != Ec[c])
            Xs = float(ct) * Rm + float(st) * std_dual(Rm) + float(c) * DDm; Es = std_E(Xs, fr)
            Fs = Rm + float(c) * DDm; EsF = std_E(float(ct) * Fs + float(st) * std_dual(Fs), fr)
            errR = max(errR, max(abs(float(Et[k]) - Es[k]) for k in Et)); errF = max(errF, max(abs(float(EF[k]) - EsF[k]) for k in EF))
    chk('bit', ruleR and ruleF, '%s: E_a(c)[R e^{tI}] = cos t E_a(0) + (E_a(c) - E_a(0)) and E_a[F(c) e^{tI}] = cos t E_a(c), 16 components exactly, c in {%s}, '
        '(cos t, sin t) in %s' % (name, ', '.join(str(c) for c in Ec), ', '.join(fmt_t(*t) for t in TS)))
    chk('bit==std', errR <= 1e-9 * sc and errF <= 1e-9 * sc, '%s: the engine\'s E_a of the rotated R and F equals -(G - 3c delta) Theta of the textbook dual and '
        'contraction in floats: max |diff| %.1e and %.1e (scale %.1e)' % (name, errR, errF, sc))
    chk('std', np.max(np.abs(np.einsum('abad->bd', std_dual(Rm)))) <= 1e-12 * max(1.0, np.max(np.abs(Rm))),
        '%s: the float route alone: the textbook dual of the Christoffel Riemann tensor has zero Ricci contraction' % name)
    if inv_tot: chk('ctl', inv_fail == inv_tot, '%s: invariance E_a[R_t] = E_a[R] fails at every t with cos t != 1 and every c (%d of %d cases) (ok)' % (name, inv_fail, inv_tot))
    # ---- (1) the Weyl part turns by a phase
    Q0 = complex_Q(Wl); typ0, I20, I30, info0 = petrov(Q0); wok = qok = tok = True; qerr = 0.0
    Cf, Qf, _, _ = weyl_float(Rstd, SQ); Cm = np.einsum('ax,by,xycd->abcd', ETAI, ETAI, Cf)
    for (ct, st) in TS:
        Tl = lowered_full(rot36(W, J, ct, st)); wok &= pair_sym(Tl) and all_traces_zero(Tl, SQ) and cyc0(Tl)
        Qt = complex_Q(Tl); ph = QI(ct, -st); qok &= all(Qt[i][j] == ph * Q0[i][j] for i in range(3) for j in range(3))
        typ, I2, I3, info = petrov(Qt); tok &= (typ == typ0 == expect) and ('double' not in info0 or info['double'] == ph * info0['double'])
        Ct = np.einsum('ax,by,xycd->abcd', ETA, ETA, float(ct) * Cm + float(st) * std_dual(Cm))
        qerr = max(qerr, float(np.max(np.abs(std_Q(Ct) - complex(float(ct), -float(st)) * Qf))))
    chk('bit', wok and qok and tok, '%s: W_t = cos t W + sin t J W is a Weyl tensor (pair symmetric, all traces 0, first Bianchi) and Q(W_t) = (cos t - i sin t) Q(W) '
        'exactly; Petrov type %s kept%s' % (name, typ0, (', double eigenvalue %s -> (cos t - i sin t) x it' % info0['double']) if 'double' in info0 else ''))
    chk('std', qerr <= 1e-9 * max(1.0, float(np.max(np.abs(Qf)))), '%s: the float route alone (textbook dual of the Christoffel Weyl tensor): Q_t = e^{-it} Q to %.1e' % (name, qerr))
    if typ0 == 'D':
        QJ = complex_Q(lowered_full(rot36(W, J, F(0), F(1))))
        chk('ctl', all(QJ[i][j] == QI(0, -1) * Q0[i][j] and QJ[i][j].conj() == QI(0, 1) * Q0[i][j].conj() for i in range(3) for j in range(3)),
            '%s: the quarter turn maps Q = E + iB to -iQ and E - iB to i(E - iB) (double eigenvalue %s -> %s)' % (name, info0['double'], QI(0, -1) * info0['double']))
    # ---- (3) what the rotation does to the Ricci and scalar pieces
    JP = lowered_full(rot36(Ppc, J, F(0), F(1))); JS = lowered_full(rot36(EE, J, F(0), F(1)))
    zeroP = is0(Ppc)
    chk('bit', pair_anti(JP) and (any(v != 0 for v in JP.values()) != zeroP) and total_anti(JS, 1) and all(v == 0 for v in ricci_low(JP).values())
        and all(v == 0 for v in ricci_low(JS).values()), '%s: J (Ricci piece) is pair-antisymmetric (%s), J (e^a e^b) = eps_abcd (eps_0123 = +1); both have zero '
        'Ricci contraction' % (name, 'zero here' if zeroP else 'non-zero'))
    sym = True; curv = []
    for (ct, st) in TS:
        Lt = lowered_full(rot36(R36, J, ct, st)); Lsym = {k: (Lt[k] + Lt[k[2:] + k[:2]]) / 2 for k in ALL4}
        sym &= all((Lt[k] - Lt[k[2:] + k[:2]]) / 2 == st * JP[k] for k in ALL4) and eps_tr(Lsym) == st * Rs / 4
        sym &= ricci_low(Lt) == {k: ct * v for k, v in wb['Ric'].items()}
        isc = pair_sym(Lt) and cyc0(Lt); curv.append(isc); sym &= (isc == (st == 0 or (zeroP and Rs == 0)))
    chk('bit', sym, '%s: R_t: pair-antisymmetric part = sin t J (Ricci piece), epsilon trace = sin t Rs/4 (Rs = %s), Ricci = cos t Ric; R_t is a curvature table '
        'at %d of %d t (%s)' % (name, Rs, sum(curv), len(curv), 'every t: R is pure Weyl' if all(curv) else 'only sin t = 0'))
    # ---- (4) the two-sided map of h1_petrov.py
    SR = cell_vector(Rl); SA = act_J(SR, J); SW_, SP_, SS_ = cell_vector(Wl), cell_vector(lowered_full(Ppc)), cell_vector(lowered_full(Spc))
    Smix = [[SQ[b] * wb['tf'][(b, d)] for d in range(4)] for b in range(4)]; aok = qa = True
    for (ct, st) in TS:
        T2 = tensor_of_cells([ct * x + st * y for x, y in zip(SR, SA)]); X2 = {k: SQ[k[0]] * SQ[k[1]] * T2[k] for k in K36}
        M = [[(ct + st) * Smix[h][a] - ((ct - st) * Rs / 4 if h == a else 0) for a in range(4)] for h in range(4)]
        aok &= E_of(Gv, e, list_of36(Gv, e, X2)) == predicted_components(M, e0, E0, det, 4, s=-1)
        Q2 = complex_Q(weyl_parts(T2, SQ)[0]); qa &= all(Q2[i][j] == (ct - st) * Q0[i][j] for i in range(3) for j in range(3))
    chk('bit', SA == [p - w - s for p, w, s in zip(SP_, SW_, SS_)] and sum(x * y for x, y in zip(eps_row(), SA)) == 0 and aok and qa,
        '%s: two-sided act_J R = (Ricci piece) - W - (scalar piece), a curvature table (epsilon trace 0); E_a of cos t R + sin t act_J R = -M Theta with '
        'M = (cos t + sin t) S_tf - (cos t - sin t)(Rs/4) delta, and Q -> (cos t - sin t) Q, every t' % name)
    if not qzero_(Q0):
        Qh = complex_Q(weyl_parts(tensor_of_cells(SA), SQ)[0])
        chk('ctl', all(Qh[i][j] == -Q0[i][j] for i in range(3) for j in range(3)) and not all(Qh[i][j] == QI(0, -1) * Q0[i][j] for i in range(3) for j in range(3)),
            '%s: the two-sided map at t = pi/2 gives -Q, not -iQ: no phase (ok)' % name)
    # ---- control: the wrong complement J' (Levi-Civita sign, no eta signs)
    EJw = E_of(Gv, e, rot_list(Fm, R, Jw, F(0), F(1))); sp = {PIDX[(1, 2)], PIDX[(1, 3)], PIDX[(2, 3)]}
    cS = cyclic3(Gv, e, R, sp); mag = any(R36[(0, i, k, l)] != 0 for i in (1, 2, 3) for (k, l) in ((1, 2), (1, 3), (2, 3)))
    differs = any(v != 0 for v in EJw.values())
    chk('ctl', EJw == {(a, mu): 2 * SQ[a] * v for (a, mu), v in cS.items()} and differs == mag,
        '%s: the wrong complement J\' gives E_a[J\'R] = 2 eta_aa (spatial labels of R)^a_b ^ e^b, %s E_a[JR] = 0 (magnetic cells R^{0i}_{kl}: %s)%s'
        % (name, 'not' if differs else 'equal to', 'present' if mag else 'none', ' (ok)' if differs else ''))
    return dict(name=name, typ=typ0, E0=any(v != 0 for v in Ec[F(0)].values()), P=not zeroP, Rs=Rs, curv=all(curv), jw=differs, mag=mag)
def qzero_(Q): return all(x.iszero() for row in Q for x in row)

def main():
    Gv = Grav(4, Lie(list(SQ))); S = koszul_S(4, SQ, Gv.L); L = Gv.L
    head('H1-rotation: the duality rotation R -> R e^{tI} of the curvature table, n = 4, squares (+,-,-,-), exact at one rational point per frame (2-jets)')
    J = right_I(L); Jl, I2, comm, compl = duality_J(SQ); Jw = wrong_J_levi(SQ)
    chk('bit', J == Jl and comm and compl and I2 == -1 and J_square(J) == -1, 'the bit rule: B_A I = I B_A for the six bivectors (right = left multiplication), '
        'the image is the complement plane, I^2 = %s, J^2 = %s' % (I2, J_square(J)))
    Jm = J_matrix(J); D = [[EPSMIX[c, d, a, b] for (a, b) in PAIRS4] for (c, d) in PAIRS4]
    chk('bit==std', all(float(Jm[i][j]) == D[i][j] for i in range(6) for j in range(6)), 'the bit rule\'s I on the six labels equals the textbook left dual '
        '(1/2) eps^{cd}_{ab} with eps_0123 = +1 (6 x 6, exact integers): the convention under which the two routes are compared')
    Dm = np.einsum('ax,by,xycd->abcd', ETAI, ETAI, eps_lower(-1))
    chk('ctl', all(float(Jm[i][j]) == -Dm[PAIRS4[i] + PAIRS4[j]] for i in range(6) for j in range(6)), 'with eps_0123 = -1 the textbook dual is -J: the identification '
        'fixes the orientation (ok)')
    rng = random.Random(17); res = []; ident = True
    for (name, e, expect, H2) in frames():
        head(name)
        om, R = engine_om_R(Gv, e, S, 4); R0 = rot_list(Gv.Fm, R, J, F(1), F(0)); ident &= (R0 == R) and E_of(Gv, e, R0, F(1, 3)) == E_of(Gv, e, R, F(1, 3))
        res.append(run_frame(Gv, S, J, Jw, name, e, expect, H2, rng)); tick(name.split(' ')[0])
    head('Summary')
    chk('ctl', ident, 't = 0: the rotation is the identity on the engine\'s R and on E_a, every frame')
    for r in res:
        print('    %-58s type %s  E_a(0) %-8s  trace-free Ricci %-8s  Rs = %-8s  R_t a curvature table: %-14s  J\' differs: %s' % (r['name'][:58], r['typ'],
              'non-zero' if r['E0'] else 'zero', 'non-zero' if r['P'] else 'zero', r['Rs'], 'every t' if r['curv'] else 'sin t = 0 only', 'yes' if r['jw'] else 'no'))
    nE = sum(1 for r in res if r['E0'])
    chk('bit', nE >= 5 and all(r['curv'] == (not r['P'] and r['Rs'] == 0) for r in res),
        'E_a is not duality invariant on the %d frames with E_a(0) != 0 (it scales by cos t), and the rotated table is a curvature table for every t exactly on '
        'the frames where R is pure Weyl (%s)' % (nE, ', '.join(r['name'].split(' ')[0] for r in res if r['curv'])))
    chk('ctl', sum(1 for r in res if r['jw']) >= 3 and all(r['jw'] for r in res if r['typ'] in ('N', 'I')), 'the wrong complement J\' changes E_a on %d of %d frames '
        '(every frame with a magnetic cell, among them the plane wave and the random frame) (ok)' % (sum(1 for r in res if r['jw']), len(res)))
    finish('H1-rotation')

if __name__ == '__main__': main()
