#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""D-PROBE.  The sign of the engine's exterior derivative, read directly.   python3 d_probe.py

 Why a script needs it: the pair (d, omega) -> (-d, -omega) leaves R = d omega + (1/4) f omega omega and the Einstein form E_a unchanged (the closed-form
 omega changes sign with d), so the checks of a script that reads only R and E_a cannot tell d from -d.  d_sign_probe() reads d itself.
   [bit]  the engine's Forms.d (the module gravity_selfcheck that b1lib loads) on functions and 1-forms with polynomial coefficients;
   [std]  partial derivatives on the exponent tuples of the same polynomials, by a few lines of this file (never the engine); the basis 2-form of the pair
          mu < nu is dx^mu ^ dx^nu, and dx^nu ^ dx^mu = -dx^mu ^ dx^nu;
   [bit==std]  d x^mu = dx^mu;  d f = sum_mu (d_mu f) dx^mu;  d(f dx^nu) = sum_mu (d_mu f) dx^mu ^ dx^nu (every nu);
               d A = sum_{mu < nu} (d_mu A_nu - d_nu A_mu) dx^mu ^ dx^nu for a 1-form A;
   [ctl]  the same comparisons with the wrong sign (-d_mu f) and with the wrong orientation of the pair (+1 on the mask for mu > nu) must fail.
 Data: n = 3 and n = 4; every monomial of total degree <= D present, its coefficient an integer uniform in -50..50, D = 2 and D = 3 (fixed seeds); a [std]
 line states that every partial derivative of the test data is non-zero, so a sign error changes every compared component and cannot pass by coincidence.
 Cost: well under a second.  Seven check lines.
 Use in another script of this folder, after its first heading:  from d_probe import d_sign_probe; d_sign_probe()
 (where that heading runs inside a loop, once before the loop:  d_sign_probe('<heading>')).
 (prints its check lines with b1lib.chk, returns them as strings, and changes no state of the caller: own random generators, no truncation).
 Engine faults: d -> -d (M4) fails six of the seven lines (all but the data line); the other seven faults change R, E_a or the Lie tables, which this file never reads."""
import os, sys, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
import b1lib
from b1lib import chk, head, finish
from fractions import Fraction as F

SEEDS = {3: (7301, 7302, 7303), 4: (7401, 7402, 7403)}                          # (f of degree 2, f of degree 3, the 1-form A of degree 2)

def _poly(rng, n, deg):
    """every monomial of total degree <= deg, coefficient uniform in -50..50 (a zero is left out)"""
    out = {}
    for e in itertools.product(range(deg + 1), repeat=n):
        if sum(e) <= deg:
            c = rng.randint(-50, 50)
            if c: out[e] = F(c)
    return out
def _pd(p, i):
    """[std] partial derivative d/dx^i on exponent tuples"""
    out = {}
    for k, v in p.items():
        if k[i]:
            kk = k[:i] + (k[i] - 1,) + k[i + 1:]; out[kk] = out.get(kk, 0) + v * k[i]
    return {k: v for k, v in out.items() if v != 0}
def _add(a, b, c=1):
    out = dict(a)
    for k, v in b.items(): out[k] = out.get(k, 0) + c * v
    return {k: v for k, v in out.items() if v != 0}
def _clean(X): return {m: p for m, p in X.items() if p}
def _same(X, Y): return _clean(X) == _clean(Y)
def _std_d1(n, f, sgn=1):
    """[std] d f = sum_mu (d_mu f) dx^mu, as {mask: poly}; sgn = -1 gives the wrong sign"""
    return _clean({1 << mu: {k: sgn * v for k, v in _pd(f, mu).items()} for mu in range(n)})
def _std_d2(n, comps, sgn=1, orient=True):
    """[std] d of the 1-form sum_nu comps[nu] dx^nu: the mask {mu, nu} collects (d_mu A_nu) with + for mu < nu and - for mu > nu;
       sgn = -1 the wrong sign, orient = False the wrong orientation (+ for every pair)"""
    out = {}
    for nu, A in comps.items():
        for mu in range(n):
            if mu == nu: continue
            s = sgn * (1 if (mu < nu or not orient) else -1); m = (1 << mu) | (1 << nu)
            out[m] = _add(out.get(m, {}), _pd(A, mu), s)
    return _clean(out)

def d_sign_probe(title=None):
    """[bit==std] the engine's d on functions and 1-forms against plain partial derivatives (n = 3, 4); [ctl] the wrong sign and the wrong orientation fail.
       title: a heading printed first (for a caller whose first heading runs inside a loop). Returns the printed check lines."""
    gs = b1lib.gs; lines = []
    if title: head(title)
    def c(tag, cond, msg):
        chk(tag, cond, msg); lines.append('%s [%s] %s' % ('ok' if cond else 'FAIL', tag, msg))
    ok_x = ok_f = ok_fdx = ok_A = nz = True; ctl_sign = ctl_orient = True; nf = 0
    for n in (3, 4):
        Fm = gs.Forms(n); sf2, sf3, sA = SEEDS[n]
        f2, f3 = _poly(random.Random(sf2), n, 2), _poly(random.Random(sf3), n, 3)
        rA = random.Random(sA); A = {nu: _poly(rA, n, 2) for nu in range(n)}
        nz &= all(_pd(p, mu) for p in [f2, f3] + list(A.values()) for mu in range(n))
        for mu in range(n):                                                         # the coordinate functions x^mu
            xmu = {tuple(1 if j == mu else 0 for j in range(n)): F(1)}
            ok_x &= _same(Fm.d({0: xmu}), {1 << mu: {(0,) * n: F(1)}})
        for f in (f2, f3):                                                          # d f
            bit = Fm.d({0: f}); ok_f &= _same(bit, _std_d1(n, f)); ctl_sign &= not _same(bit, _std_d1(n, f, -1)); nf += 1
        for nu in range(n):                                                         # d (f dx^nu)
            bit = Fm.d({1 << nu: f3})
            ok_fdx &= _same(bit, _std_d2(n, {nu: f3})); ctl_sign &= not _same(bit, _std_d2(n, {nu: f3}, sgn=-1))
            if nu < n - 1: ctl_orient &= not _same(bit, _std_d2(n, {nu: f3}, orient=False))   # (for nu = n - 1 no pair has mu > nu)
        bit = Fm.d(_clean({1 << nu: A[nu] for nu in range(n)}))                    # d A, a full 1-form
        ok_A &= _same(bit, _std_d2(n, A)); ctl_sign &= not _same(bit, _std_d2(n, A, sgn=-1)); ctl_orient &= not _same(bit, _std_d2(n, A, orient=False))
    c('std', nz, 'd-probe data, n = 3 and 4: every partial derivative of the test polynomials (degree 2 and 3, all monomials, coefficients uniform in -50..50, fixed seeds) '
      'is non-zero, so d -> -d changes every component compared below')
    c('bit==std', ok_x, 'd-probe: the engine\'s d of each coordinate function x^mu is dx^mu (n = 3 and 4)')
    c('bit==std', ok_f, 'd-probe: the engine\'s d f equals sum_mu (d_mu f) dx^mu with plain partial derivatives, all components, %d polynomials (n = 3 and 4, degree 2 and 3)' % nf)
    c('bit==std', ok_fdx, 'd-probe: the engine\'s d(f dx^nu) equals sum_mu (d_mu f) dx^mu ^ dx^nu for every nu (degree 3; the pair mu > nu carries -1 on its mask), n = 3 and 4')
    c('bit==std', ok_A, 'd-probe: the engine\'s d A equals sum_{mu<nu} (d_mu A_nu - d_nu A_mu) dx^mu ^ dx^nu for a 1-form A with all components (degree 2), n = 3 and 4')
    c('ctl', ctl_sign, 'd-probe: the wrong sign (-d_mu f in d f, d(f dx^nu) and d A) does not match the engine at any of these fields')
    c('ctl', ctl_orient, 'd-probe: the wrong orientation of the pair (dx^mu ^ dx^nu taken as +1 on the mask for mu > nu) does not match the engine\'s d(f dx^nu) or d A')
    return lines

if __name__ == '__main__':
    head('D-PROBE  the engine\'s exterior derivative against plain partial derivatives (n = 3, 4; exact fractions)')
    d_sign_probe()
    finish('D-PROBE')
