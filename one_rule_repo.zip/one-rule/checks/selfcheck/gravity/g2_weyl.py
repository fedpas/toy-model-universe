#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""g2_weyl: Weyl and Ricci parts of the engine's curvature in frame components, duality on the six bivector labels, the complex 3x3 matrix
Q = E + iB, Petrov invariants and type in exact Q(i) arithmetic; the [std] float route; test frames (flat, FRW, plane wave, boosted frames).

Conventions: n = 4, sq = (+,-,-,-) unless stated; a frame is a list of n 1-forms {1<<mu: poly}; bivector labels A = 0..5 in the order of Lie.gens
((0,1),(0,2),(0,3),(1,2),(1,3),(2,3)).  Fully lowered frame components R_{abcd} = sq_a sq_b R^{ab}_{mu nu} E^mu_c E^nu_d (R^{ab}_{mu nu} the engine's curvature at the origin;
A4: R^rho_{sigma mu nu}(std, MTW) = E^rho_a e^b_sigma eta_bb R^{ab}_{mu nu}).  Ricci Ric_{bd} = eta^{ac} R_{abcd}, scalar Rs = eta^{bd} Ric_{bd}.
The 21 cells = symmetric forms S_{AB} = R_{abcd} on the labels (A = (ab), B = (cd)); first Bianchi (pair-symmetric case) = the epsilon trace S_{01,23} - S_{02,13} + S_{03,12} = 0.
Import: sys.path.insert(0, <this folder>); from g2_weyl import *  (brings b1lib in)."""
import sys, os, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np

PS4 = 0b1111                                                          # the pseudoscalar gamma_0 gamma_1 gamma_2 gamma_3
PAIRS4 = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]             # = pairs_of(Lie(sq)) for n = 4
PIDX = {p: i for i, p in enumerate(PAIRS4)}
SYM21 = [(A, B) for A in range(6) for B in range(A, 6)]               # the 21 cells
SIDX = {c: i for i, c in enumerate(SYM21)}
def cell_class(A, B):
    """'D' diagonal (same plane), 'E' edge (planes sharing one index), 'A' antipodal (disjoint planes)"""
    k = len(set(PAIRS4[A]) & set(PAIRS4[B])); return {2: 'D', 1: 'E', 0: 'A'}[k]
CLASS = {c: cell_class(*c) for c in SYM21}
def pair_sign(a, b):
    """(label, sign) of gamma_a gamma_b as +-B_A, 0 if a == b"""
    if a == b: return None, 0
    return (PIDX[(a, b)], 1) if a < b else (PIDX[(b, a)], -1)

# ------------------------------------------------------------------------------------------------ exact complex rationals Q(i)
class QI:
    __slots__ = ('re', 'im')
    def __init__(self, re=0, im=0): self.re = F(re); self.im = F(im)
    def __add__(self, o): o = qi(o); return QI(self.re + o.re, self.im + o.im)
    __radd__ = __add__
    def __sub__(self, o): o = qi(o); return QI(self.re - o.re, self.im - o.im)
    def __rsub__(self, o): return qi(o) - self
    def __mul__(self, o): o = qi(o); return QI(self.re * o.re - self.im * o.im, self.re * o.im + self.im * o.re)
    __rmul__ = __mul__
    def __neg__(self): return QI(-self.re, -self.im)
    def __truediv__(self, o):
        o = qi(o); d = o.re ** 2 + o.im ** 2; assert d != 0, 'division by zero in Q(i)'
        return QI((self.re * o.re + self.im * o.im) / d, (self.im * o.re - self.re * o.im) / d)
    def __pow__(self, k):
        r = QI(1)
        for _ in range(k): r = r * self
        return r
    def __eq__(self, o):
        if not isinstance(o, (QI, int, F)): return False
        o = qi(o); return self.re == o.re and self.im == o.im
    def __ne__(self, o): return not self.__eq__(o)
    def __hash__(self): return hash((self.re, self.im))
    def iszero(self): return self.re == 0 and self.im == 0
    def conj(self): return QI(self.re, -self.im)
    def cx(self): return complex(float(self.re), float(self.im))
    def __repr__(self):
        if self.im == 0: return str(self.re)
        if self.re == 0: return '%si' % self.im
        return '(%s %s %si)' % (self.re, '+' if self.im > 0 else '-', abs(self.im))
def qi(o): return o if isinstance(o, QI) else QI(o, 0)
def qmul(A, B):
    n = len(A); return [[sum((A[i][k] * B[k][j] for k in range(n)), QI(0)) for j in range(n)] for i in range(n)]
def qtrace(A): return sum((A[i][i] for i in range(len(A))), QI(0))
def qeye(n, lam=1): return [[qi(lam) if i == j else QI(0) for j in range(n)] for i in range(n)]
def qsub(A, B): return [[A[i][j] - B[i][j] for j in range(len(A))] for i in range(len(A))]
def qzero(A): return all(x.iszero() for row in A for x in row)
def qrank(M):
    """rank over Q(i) by elimination"""
    M = [row[:] for row in M]; rk = 0; ncol = len(M[0]) if M else 0
    for c in range(ncol):
        p = next((i for i in range(rk, len(M)) if not M[i][c].iszero()), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]
        for i in range(rk + 1, len(M)):
            if not M[i][c].iszero():
                f = M[i][c] / M[rk][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        rk += 1
    return rk

# ------------------------------------------------------------------------------------------------ duality on the six labels (the pseudoscalar of the bit rule)
def duality_J(sq):
    """J[A] = (B, s) with I B_A = s B_B, I = gamma_0..gamma_3 (bmul of the bit rule); returns (J, I^2, I commutes with every bivector, every image is the complement plane)"""
    Lie_ = Lie(sq); J = []; comm = True; compl = True
    for A, g in enumerate(Lie_.gens):
        m, s = bmul(PS4, g, sq); m2, s2 = bmul(g, PS4, sq); comm &= (m == m2 and s == s2)
        compl &= (m == PS4 ^ g); J.append((Lie_.idx[m], s))
    return J, bmul(PS4, PS4, sq)[1], comm, compl
def wrong_J_levi(sq):
    """[ctl] the complement permutation with the Levi-Civita sign eps(a, b, c, d) and WITHOUT the eta-lowering signs"""
    J = []
    for A, (a, b) in enumerate(PAIRS4):
        c, d = [x for x in range(4) if x not in (a, b)]
        J.append((PIDX[(c, d)], gs.Grav(4).eps([a, b, c, d])))
    return J
def J_square(J):
    """J^2 as a scalar if it is one (every label goes back to itself with the same sign), else None"""
    vals = set()
    for A in range(6):
        B, s = J[A]; C, t = J[B]
        if C != A: return None
        vals.add(s * t)
    return vals.pop() if len(vals) == 1 else None
def J_matrix(J):
    """6x6 matrix of J on labels: (J v)_B = sum_A J_BA v_A"""
    M = [[F(0)] * 6 for _ in range(6)]
    for A, (B, s) in enumerate(J): M[B][A] = F(s)
    return M
def act_J(Svec, J):
    """S -> S(J., J.):  out_{AB} = s_A s_B S_{J(A) J(B)}   (21-vectors over the cells)"""
    out = [F(0)] * 21
    for i, (A, B) in enumerate(SYM21):
        jA, sA = J[A]; jB, sB = J[B]
        out[i] = sA * sB * Svec[SIDX[(min(jA, jB), max(jA, jB))]]
    return out
def J21_matrix(J):
    """21x21 matrix of the action act_J (columns = images of the unit cells)"""
    cols = []
    for i in range(21):
        v = [F(0)] * 21; v[i] = F(1); cols.append(act_J(v, J))
    return [[cols[j][i] for j in range(21)] for i in range(21)]
def mat_sub_scalar(M, lam): return [[M[i][j] - (lam if i == j else 0) for j in range(len(M))] for i in range(len(M))]
def mat_rows(M): return [row[:] for row in M]

# the maps on the 21 cells (own index loops, textbook definitions)
def unit_cell(i):
    v = [F(0)] * 21; v[i] = F(1); return v
def S_entry(Svec, a, b, c, d):
    """R_{abcd} from the cell vector"""
    A, s1 = pair_sign(a, b); B, s2 = pair_sign(c, d)
    if s1 == 0 or s2 == 0: return F(0)
    return s1 * s2 * Svec[SIDX[(min(A, B), max(A, B))]]
def ricci_rows(sq):
    """10 rows (b <= d): Ric_{bd} = sum_a sq_a R_{abad} as linear forms on the 21 cells"""
    rows = []
    for b in range(4):
        for d in range(b, 4):
            row = []
            for i in range(21):
                v = unit_cell(i); row.append(sum(sq[a] * S_entry(v, a, b, a, d) for a in range(4)))
            rows.append(row)
    return rows
def scalar_row(sq):
    rows = ricci_rows(sq); out = [F(0)] * 21; k = 0
    for b in range(4):
        for d in range(b, 4):
            if b == d: out = [x + sq[b] * y for x, y in zip(out, rows[k])]
            k += 1
    return out
def eps_row():
    """the epsilon trace S_{01,23} - S_{02,13} + S_{03,12} (first Bianchi for a pair-symmetric form)"""
    out = [F(0)] * 21
    for (a, b, c, d), s in (((0, 1, 2, 3), 1), ((0, 2, 1, 3), -1), ((0, 3, 1, 2), 1)):
        out[SIDX[(PIDX[(a, b)], PIDX[(c, d)])]] = F(s)
    return out
def class_rows(cls):
    """constraint rows that kill every cell NOT in the class (so the solution space is the span of the class's cells)"""
    return [unit_cell(i) for i, c in enumerate(SYM21) if CLASS[c] != cls]
def dim_of(*row_groups):
    """dimension of the subspace of the 21 cut out by all the constraint rows given"""
    rows = [r for g in row_groups for r in g]
    return 21 - (rank_exact(rows) if rows else 0)
def metric_cell_vector(sq):
    """the bivector metric as a symmetric form: g_{AB} = sq_a sq_b on the diagonal cells"""
    v = [F(0)] * 21
    for A, (a, b) in enumerate(PAIRS4): v[SIDX[(A, A)]] = F(sq[a] * sq[b])
    return v

# ------------------------------------------------------------------------------------------------ curvature in frame components, Weyl projection, Q = E + iB, Petrov
def engine_frame_riemann(Gv, e, S, n=4, om=None):
    """[bit] fully lowered frame components R_{abcd} at the origin of the jets: omega = A3 closed form (1-jet), R = engine curvature.  Returns (Rl, om, R)"""
    if om is None: om, R = engine_om_R(Gv, e, S, n)
    else:
        with trunc(n, xdeg=1): R = Gv.curvature(om)
    sq = Gv.L.sq; e0, E0, det = E0_of(e, n, n); Rl = {}
    Rab = {}
    for A, (a, b) in enumerate(pairs_of(Gv.L)):
        for mu in range(n):
            for nu in range(n):
                v = at0(R[A].get((1 << mu) | (1 << nu), {}), n) if mu < nu else (-at0(R[A].get((1 << nu) | (1 << mu), {}), n) if mu > nu else F(0))
                Rab[(a, b, mu, nu)] = v; Rab[(b, a, mu, nu)] = -v
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    Rl[(a, b, c, d)] = F(0) if a == b else sq[a] * sq[b] * sum(Rab[(a, b, mu, nu)] * E0[mu][c] * E0[nu][d] for mu in range(n) for nu in range(n))
    return Rl, om, R
def std_frame_riemann(e, n=4, sq=None, nv=None):
    """[std] the same R_{abcd} from the metric g = e^T eta e by the Christoffel route (b1lib.std_riemann, exact; never the engine)"""
    sq = sq or LORENTZ(n); nv = nv or n
    g = std_metric(e, n, sq, nv, 2); R1, g0, g0i = std_riemann(g, n, nv, 1); e0, E0, det = E0_of(e, n, nv)
    rg = range(n)
    T1 = {(a, s, m, v): sum(e0[a][r] * R1[(r, s, m, v)] for r in rg) for a in rg for s in rg for m in rg for v in rg}
    T2 = {(a, b, m, v): sum(E0[s][b] * T1[(a, s, m, v)] for s in rg) for a in rg for b in rg for m in rg for v in rg}
    T3 = {(a, b, c, v): sum(E0[m][c] * T2[(a, b, m, v)] for m in rg) for a in rg for b in rg for c in rg for v in rg}
    return {(a, b, c, d): sq[a] * sum(E0[v][d] * T3[(a, b, c, v)] for v in rg) for a in rg for b in rg for c in rg for d in rg}
def weyl_parts(Rl, sq, n=4, coef=None):
    """standard projection.  Returns (C_{abcd}, Ric_{bd}, Rs, trace-free Ricci).  coef = (1/(n-2), 1/((n-1)(n-2))) by default; a wrong pair is a control."""
    c1, c2 = coef or (F(1, n - 2), F(1, (n - 1) * (n - 2)))
    eta = lambda a, b: sq[a] if a == b else 0
    Ric = {(b, d): sum(sq[a] * Rl[(a, b, a, d)] for a in range(n)) for b in range(n) for d in range(n)}
    Rs = sum(sq[b] * Ric[(b, b)] for b in range(n))
    C = {}
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    C[(a, b, c, d)] = (Rl[(a, b, c, d)] - c1 * (eta(a, c) * Ric[(b, d)] - eta(a, d) * Ric[(b, c)] - eta(b, c) * Ric[(a, d)] + eta(b, d) * Ric[(a, c)])
                                       + c2 * Rs * (eta(a, c) * eta(b, d) - eta(a, d) * eta(b, c)))
    tf = {(b, d): Ric[(b, d)] - Rs * F(eta(b, d), n) for b in range(n) for d in range(n)}
    return C, Ric, Rs, tf
def all_traces_zero(T, sq, n=4):
    """eta^{xy} T_{..x..y..} for every pair of slots of a 4-index tensor"""
    for (i, j) in itertools.combinations(range(4), 2):
        for rest in itertools.product(range(n), repeat=2):
            tot = F(0)
            for x in range(n):
                idx = [None] * 4; idx[i] = x; idx[j] = x; k = 0
                for p in range(4):
                    if idx[p] is None: idx[p] = rest[k]; k += 1
                tot += sq[x] * T[tuple(idx)]
            if tot != 0: return False
    return True
def pair_symmetric(Rl, n=4): return all(Rl[(a, b, c, d)] == Rl[(c, d, a, b)] for a in range(n) for b in range(n) for c in range(n) for d in range(n))
def cell_vector(T):
    """the 21-vector S_{AB} = T_{abcd} (a < b, c < d) of a pair-symmetric 4-index tensor"""
    return [T[PAIRS4[A] + PAIRS4[B]] for (A, B) in SYM21]
def tensor_of_cells(Svec, n=4):
    return {(a, b, c, d): S_entry(Svec, a, b, c, d) for a in range(n) for b in range(n) for c in range(n) for d in range(n)}
EPS3 = {}
for p in itertools.permutations((1, 2, 3)): EPS3[p] = gs.Grav(4).eps([0] + list(p))
def complex_Q(C, bfac=F(1, 2)):
    """Q = E + iB, E_ij = C_{0i0j}, B_ij = bfac * sum_kl eps_ikl C_{0jkl} (i, j = 1..3); bfac = 1/2 is the standard, another value is a control"""
    Q = [[None] * 3 for _ in range(3)]
    for i in (1, 2, 3):
        for j in (1, 2, 3):
            E = C[(0, i, 0, j)]; B = bfac * sum(EPS3[(i, k, l)] * C[(0, j, k, l)] for k in (1, 2, 3) for l in (1, 2, 3) if len({i, k, l}) == 3)
            Q[i - 1][j - 1] = QI(E, B)
    return Q
def q_symmetric(Q): return all(Q[i][j] == Q[j][i] for i in range(3) for j in range(3))
def petrov(Q):
    """exact Petrov type from the Jordan structure of Q over Q(i).  Returns (type, I2 = tr Q^2, I3 = tr Q^3, info dict)"""
    if qzero(Q): return 'O', QI(0), QI(0), {}
    Q2 = qmul(Q, Q); I2 = qtrace(Q2); Q3 = qmul(Q2, Q); I3 = qtrace(Q3)
    if I2.iszero() and I3.iszero():                                   # nilpotent
        return ('N' if qzero(Q2) else 'III'), I2, I3, {'nilpotent': True}
    if I2 ** 3 == I3 ** 2 * 6:                                           # degenerate: a double eigenvalue r = -I3/I2, simple -2r
        r = -I3 / I2; rk = qrank(qsub(Q, qeye(3, r)))
        return ('D' if rk == 1 else 'II'), I2, I3, {'double': r, 'simple': -2 * r, 'rank_Q_minus_r': rk}
    return 'I', I2, I3, {}
def petrov_float(Q, tol=1e-8):
    """[std] numerical type decision: invariants, the discriminant and SVD ranks with a tolerance relative to the scale of Q"""
    Q = np.asarray(Q, dtype=complex); s = np.linalg.norm(Q)
    if s < tol: return 'O', 0j, 0j
    I2 = np.trace(Q @ Q); I3 = np.trace(Q @ Q @ Q)
    if abs(I2) < tol * s ** 2 and abs(I3) < tol * s ** 3:
        return ('N' if np.linalg.norm(Q @ Q) < tol * s ** 2 else 'III'), I2, I3
    disc = I2 ** 3 - 6 * I3 ** 2
    if abs(disc) < tol * max(abs(I2) ** 3, abs(I3) ** 2):
        r = -I3 / I2; sv = np.linalg.svd(Q - r * np.eye(3), compute_uv=False); rk = int((sv > tol * s).sum())
        return ('D' if rk == 1 else 'II'), I2, I3
    return 'I', I2, I3
def weyl_float(Rl, sq, n=4):
    """[std] numpy: the Weyl tensor and Q from a float 4-index array (own loops, independent of weyl_parts)"""
    R = np.array([[[[float(Rl[(a, b, c, d)]) for d in range(n)] for c in range(n)] for b in range(n)] for a in range(n)])
    eta = np.diag([float(x) for x in sq]); etai = np.linalg.inv(eta)
    Ric = np.einsum('ac,abcd->bd', etai, R); Rs = np.einsum('bd,bd->', etai, Ric)
    C = (R - (np.einsum('ac,bd->abcd', eta, Ric) - np.einsum('ad,bc->abcd', eta, Ric) - np.einsum('bc,ad->abcd', eta, Ric) + np.einsum('bd,ac->abcd', eta, Ric)) / (n - 2)
         + Rs * (np.einsum('ac,bd->abcd', eta, eta) - np.einsum('ad,bc->abcd', eta, eta)) / ((n - 1) * (n - 2)))
    eps = np.zeros((3, 3, 3))
    for (i, j, k), s in EPS3.items(): eps[i - 1, j - 1, k - 1] = s
    E = C[0, 1:, 0, 1:]; B = 0.5 * np.einsum('ikl,jkl->ij', eps, C[0, 1:, 1:, 1:])
    return C, E + 1j * B, Ric, Rs

# ------------------------------------------------------------------------------------------------ test frames (n = 4, polynomials in 4 variables)
def jet(P, n=4, deg=2): return {k: v for k, v in P.items() if sum(k[:n]) <= deg}
def flat_frame(n=4): return [{1 << a: const(n, 1)} for a in range(n)]
def frw_frame(acoef, nv=4):
    """e^0 = dt, e^i = a(t) dx^i with a(t) = sum_k acoef[k] t^k (t = x^0); spatially flat FRW, conformally flat"""
    a = {}
    for k, c in enumerate(acoef):
        if c: a[(k,) + (0,) * (nv - 1)] = F(c)
    return [{1: const(nv, 1)}] + [{1 << i: dict(a)} for i in (1, 2, 3)]
def pw_global(hcoef, kcoef=()):
    """f = (x^2 - y^2) h(u) + 2 x y k(u), u = t - z with (t, z, x, y) = (x^0, x^1, x^2, x^3): the plane-wave profile of gravity_moves.py"""
    nv = 4; u = lin((F(1), var(nv, 0)), (F(-1), var(nv, 1)))
    def prof(coef):
        r = {}; P = const(nv, 1)
        for c in coef: r = padd(r, P, F(c)); P = gs.pmul(P, u)
        return r
    x, y = var(nv, 2), var(nv, 3)
    plus = gs.pmul(padd(gs.pmul(x, x), gs.pmul(y, y), -1), prof(hcoef))
    cross = gs.pmul(scale(gs.pmul(x, y), 2), prof(kcoef)) if kcoef else {}
    return padd(plus, cross)
def pw_frame(fglob, p, deg=2):
    """e^a = dx^a - f l^a l_mu dx^mu with l^a = (1, 1, 0, 0), l_mu = (1, -1, 0, 0) (null); the 2-jet at the point p (4 rationals)"""
    nv = 4; l_up = [1, 1, 0, 0]; l_dn = [1, -1, 0, 0]; e = []
    for a in range(4):
        form = {}
        for mu in range(4):
            pol = lin((F(1 if a == mu else 0), const(nv, 1)), (F(-l_up[a] * l_dn[mu]), fglob))
            if pol: form[1 << mu] = jet(shift_poly(pol, list(p), nv), 4, deg)
        e.append(form)
    return e
def transform_frame(e, Lam, n=4):
    """e'^a = sum_b Lam[a][b] e^b with a constant matrix (a Lorentz matrix gives another orthonormal frame of the same metric)"""
    out = []
    for a in range(n):
        form = {}
        for b in range(n):
            if Lam[a][b] == 0: continue
            for m, p in e[b].items(): form[m] = padd(form.get(m, {}), p, Lam[a][b])
        out.append({m: p for m, p in form.items() if p})
    return out
def rational_lorentz(sq, kind='boost'):
    """exact Lorentz matrices for sq = (+,-,-,-): a boost (cosh, sinh) = (5/4, 3/4) in the 0-1 plane times a rotation (3/5, 4/5) in the 2-3 plane, or a rotation only"""
    B = [[F(5, 4), F(3, 4), 0, 0], [F(3, 4), F(5, 4), 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
    Rm = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, F(3, 5), F(4, 5)], [0, 0, F(-4, 5), F(3, 5)]]
    R2 = [[1, 0, 0, 0], [0, F(3, 5), F(4, 5), 0], [0, F(-4, 5), F(3, 5), 0], [0, 0, 0, 1]]
    def mm(X, Y): return [[sum(X[i][k] * Y[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
    L = mm(mm(R2, B), Rm) if kind == 'boost' else mm(R2, Rm)
    eta = [[sq[i] if i == j else 0 for j in range(4)] for i in range(4)]
    assert mm(mm([[L[j][i] for j in range(4)] for i in range(4)], eta), L) == eta, 'not a Lorentz matrix for this sq'
    return L
def random_rational_point(rng, den=3, lim=4): return [F(rng.randint(-lim, lim), rng.randint(1, den)) for _ in range(4)]
def lorentz_setup(sq=None, n=4):
    """(Gv, S, sq) for a sign pattern"""
    sq = sq or LORENTZ(n); Lie_ = Lie(sq); return Grav(n, Lie_), koszul_S(n, sq, Lie_), sq
def fmt_qi(z): return repr(z)
