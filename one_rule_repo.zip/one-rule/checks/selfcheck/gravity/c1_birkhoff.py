#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""C1.  Birkhoff in the radial Kerr-Schild class.   python3 c1_birkhoff.py

 Class.  coframe e^a = dx^a - f(rho) l^a l_mu dx^mu, l_mu dx^mu = dt + d rho (null), signature (+,-,-,-), f any function of rho = |x|.
 Claim.  With omega from A3 (the closed form), the engine's Einstein form E_a(c) = -(G - 3c delta)^h_a Theta_h and the mixed Einstein tensor in the coordinates (t, x, y, z) is, for ANY 2-jet (f0, f1, f2) of f at rho0,
            G^t_t = 2 (f0 + rho0 f1) / rho0^2 = 2 (rho f)' / rho^2,         G^t_i = 0,
            G^i_j = (2 f0 / rho0^2) xhat_i xhat_j + (2 f1 / rho0) delta_ij + f2 (delta_ij - xhat_i xhat_j),
        radial eigenvalue 2 (rho f)'/rho^2 (= G^t_t), tangential eigenvalue (rho f)''/rho.  It is LINEAR in the jet: the coefficients are read exactly at several radii and directions.
        E_a(c) = 0 is therefore   2 (rho f)'/rho^2 = 3 c   (radial)   and   (rho f)''/rho = 3 c   (tangential, the derivative of the radial one),  so  (rho f)' = (3/2) c rho^2
        and f = M/rho + (c/2) rho^2: Schwarzschild, Schwarzschild-de Sitter, anti-de Sitter with the engine's own Einstein form.
 [bit]  the engine (Forms, Lie, Grav; omega closed form; E_a) on exact 2-jets of the frame at rational points with rational |p|.
 [std]  Christoffel route: metric g = e^T eta e, Riemann by two routes, mixed Einstein tensor (exact).
 Controls: an angular dependence of f, f = M/rho^2, a wrong c, a wrong coefficient in the closed form."""
import time
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

SQ = LORENTZ(4); Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
POINTS = [((1, 2, 2), 3), ((2, 3, 6), 7), ((4, 4, 7), 9), ((6, 6, 7), 11), ((3, 4, 12), 13), ((-2, 6, 3), 7), ((1, -4, 8), 9)]

def frame(p, rho0, jets, fextra=None):
    pt = tuple(F(x) for x in p); e, _E, _l = ks_frame_jet(pt, F(rho0), *jets, fextra=fextra); return e
def engine_M(p, rho0, jets, c, fextra=None):
    """[bit] coordinate mixed tensor M^mu_nu = (G - 3c delta)^mu_nu read from the engine's E_a(c) components, E_a = -(M^h_a) Theta_h (frame components, then to coordinates)"""
    e = frame(p, rho0, jets, fextra); e0, E0, det = E0_of(e, 4, 4)
    om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, c); Mfr = mixed_from_components(comp, e0, det, 4, s=-1)
    Mco = [[sum(E0[m][b] * Mfr[b][a] * e0[a][n_] for b in range(4) for a in range(4)) for n_ in range(4)] for m in range(4)]
    return Mco, comp
def std_G(p, rho0, jets, fextra=None, both=False):
    """[std] coordinate mixed Einstein tensor G^mu_nu of g = e^T eta e (Christoffel route; both=True also compares the second-derivative route)"""
    e = frame(p, rho0, jets, fextra); g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, 4)
    if both:
        R2, _, _ = std_riemann(g, 4, 4, 2); Gm2, _, _ = std_einstein_mixed(R2, g0, g0i, 4); assert Gm2 == Gm
    return Gm
def closed_form(p, rho0, jets, tt_coef=2):
    """the claimed mixed tensor G^mu_nu in (t, x, y, z)"""
    f0, f1, f2 = jets; rho0 = F(rho0); xh = [F(x) / rho0 for x in p]; G = [[F(0)] * 4 for _ in range(4)]
    G[0][0] = tt_coef * (f0 + rho0 * f1) / rho0 ** 2
    for i in range(3):
        for j in range(3):
            G[1 + i][1 + j] = 2 * f0 / rho0 ** 2 * xh[i] * xh[j] + 2 * f1 / rho0 * (1 if i == j else 0) + f2 * ((1 if i == j else 0) - xh[i] * xh[j])
    return G
def sub_c(M, c): return [[M[i][j] + (3 * c if i == j else 0) for j in range(4)] for i in range(4)]
def rjets(rng): return (F(rng.randint(-9, 9), rng.randint(1, 9)), F(rng.randint(-9, 9), rng.randint(1, 9)), F(rng.randint(-9, 9), rng.randint(1, 9)))

def main():
    rng = random.Random(11)
    # ================================================================================== 1. the closed form on arbitrary jets
    head('1. the mixed Einstein tensor of a radial Kerr-Schild frame is linear in the 2-jet of f, with the coefficients above (exact, arbitrary jets)')
    ok_bit = True; ok_std = True; ok_bs = True; ok_c = True; n_t = 0; nonzero = True
    for (p, rho0) in POINTS:
        for k in range(4):
            jets = rjets(rng) if k else (F(1), F(0), F(0))
            cf = closed_form(p, rho0, jets); Mb, _ = engine_M(p, rho0, jets, F(0)); Gs = std_G(p, rho0, jets, both=(k == 1)); n_t += 1
            ok_bit &= (Mb == cf); ok_std &= (Gs == cf); ok_bs &= (Mb == Gs); nonzero &= any(x != 0 for r in cf for x in r)
            for c in (F(1, 3), F(-2, 5)):
                Mc, _ = engine_M(p, rho0, jets, c); ok_c &= (sub_c(Mc, c) == cf)
    chk('bit==std', ok_bit and ok_std and ok_bs, 'engine (omega from A3, E_a, frame components -> coordinates) = Christoffel route (two Riemann routes on part of the samples) = the closed form above, all 16 components, %d (point, jet) samples at 7 radii/directions, c = 0' % n_t)
    chk('bit', ok_c and nonzero, 'with c = 1/3 and c = -2/5 the engine\'s tensor is G - 3c delta with the same G (the cosmological term enters only as -3c delta^mu_nu); the samples are not vacuum (G is non-zero)')
    # linearity in the jet read off a basis
    basis = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]; lin_ok = True
    for (p, rho0) in POINTS:
        Bs = [engine_M(p, rho0, b, F(0))[0] for b in basis]
        for _ in range(3):
            jets = rjets(rng); Mx, _ = engine_M(p, rho0, jets, F(0))
            lin_ok &= all(Mx[i][j] == sum(jets[k] * Bs[k][i][j] for k in range(3)) for i in range(4) for j in range(4))
    chk('bit', lin_ok, 'M(f0, f1, f2) = f0 M(1,0,0) + f1 M(0,1,0) + f2 M(0,0,1) exactly at every point (the quadratic terms in f of the frame cancel in the mixed Einstein tensor)')
    tick('part 1')

    # ================================================================================== 2. radial and tangential eigenvalues
    head('2. radial equation 2 (rho f)\'/rho^2 = 3c and tangential equation (rho f)\'\'/rho = 3c; the tangential one follows from the radial one')
    ok_rad = True; ok_tan = True; ok_tt = True
    for (p, rho0) in POINTS:
        rho = F(rho0); xh = [F(x) / rho for x in p]; v = (F(p[1]), -F(p[0]), F(0)) if (p[0] or p[1]) else (F(0), F(p[2]), -F(p[1]))
        jets = rjets(rng); G, _ = engine_M(p, rho0, jets, F(0)); f0, f1, f2 = jets
        Gx = [sum(G[1 + i][1 + j] * xh[j] for j in range(3)) for i in range(3)]; lam_r = 2 * (f0 + rho * f1) / rho ** 2
        ok_rad &= all(Gx[i] == lam_r * xh[i] for i in range(3)) and G[0][0] == lam_r
        Gv_ = [sum(G[1 + i][1 + j] * v[j] for j in range(3)) for i in range(3)]; lam_t = (2 * f1 + rho * f2) / rho
        ok_tan &= all(Gv_[i] == lam_t * v[i] for i in range(3))
        ok_tt &= all(G[0][1 + i] == 0 and G[1 + i][0] == 0 for i in range(3))
    chk('bit', ok_rad and ok_tt, 'radial eigenvalue = G^t_t = 2 (f0 + rho0 f1)/rho0^2 = 2 (rho f)\'/rho^2, and the (t, x) cross components vanish (7 radii/directions, random jets)')
    chk('bit', ok_tan, 'the tangential eigenvalue (every vector orthogonal to x) is (2 f1 + rho0 f2)/rho0 = (rho f)\'\'/rho')
    # Bianchi in the power basis: for f = rho^k, P_tt = 2 (k+1) rho^(k-2), P_tan = k (k+1) rho^(k-2) = (k/2) P_tt  (tangential = P_tt + (rho/2) P_tt')
    ok_b = True
    for (p, rho0) in POINTS:
        rho = F(rho0); v = (F(p[1]), -F(p[0]), F(0)) if (p[0] or p[1]) else (F(0), F(p[2]), -F(p[1]))
        for k in range(-3, 4):
            jets = (rho ** k, k * rho ** (k - 1), k * (k - 1) * rho ** (k - 2)); G, _ = engine_M(p, rho0, jets, F(0))
            Ptt = G[0][0]; Gv_ = [sum(G[1 + i][1 + j] * v[j] for j in range(3)) for i in range(3)]; Ptan = Gv_[0] / v[0] if v[0] != 0 else Gv_[1] / v[1]
            ok_b &= (Ptt == 2 * (k + 1) * rho ** (k - 2) and Ptan == k * (k + 1) * rho ** (k - 2) and Ptan == F(k, 2) * Ptt)
    chk('bit', ok_b, 'f = rho^k, k = -3..3, at 7 radii: P_tt = 2 (k+1) rho^(k-2), P_tan = k (k+1) rho^(k-2) = (k/2) P_tt exactly: the tangential equation is P_tt + (rho/2) P_tt\', so it is the derivative of the radial one (the Bianchi identity of this class)')
    tick('part 2')

    # ================================================================================== 3. the Laurent ansatz and its null space
    head('3. f = sum_{k=-3}^{3} a_k rho^k and the unknown c: the null space of E_a(c) = 0 over 7 radii/directions, all 16 components')
    cols = {}
    for k in range(-3, 4):
        rowsk = []
        for (p, rho0) in POINTS:
            rho = F(rho0); jets = (rho ** k, k * rho ** (k - 1), k * (k - 1) * rho ** (k - 2)); G, _ = engine_M(p, rho0, jets, F(0))
            rowsk += [G[i][j] for i in range(4) for j in range(4)]
        cols[k] = rowsk
    colc = []
    for (p, rho0) in POINTS:
        Gc, _ = engine_M(p, rho0, (F(0), F(0), F(0)), F(1)); colc += [Gc[i][j] for i in range(4) for j in range(4)]
    names = ['a_%d' % k for k in range(-3, 4)] + ['c']; columns = [cols[k] for k in range(-3, 4)] + [colc]
    rows = [list(r) for r in zip(*columns)]
    rank, nullb = gs.rank_and_null(rows, 8)
    chk('bit', len(nullb) == 2 and rank == 6, 'the linear system E_a(c) = 0 in the 8 unknowns (a_-3 .. a_3, c) has rank %d and a null space of dimension %d (expected 2)' % (rank, len(nullb)))
    v1 = [F(0)] * 8; v1[-3 + 3 + 2] = F(1)                           # a_-1 = 1  (index of a_-1 is 2)
    v2 = [F(0)] * 8; v2[5] = F(1, 2); v2[7] = F(1)                    # a_2 = 1/2, c = 1
    in_null = lambda v: all(sum(r[j] * v[j] for j in range(8)) == 0 for r in rows)
    chk('bit', in_null(v1) and in_null(v2), 'M/rho (a_-1 = 1, c = 0) and (c/2) rho^2 (a_2 = 1/2, c = 1) are in the null space: Schwarzschild and Schwarzschild-(anti-)de Sitter are derived in this class')
    # span equality: every null vector is a combination of v1, v2
    def in_span(w):
        a, b = w[2], w[5] * 2
        return all(w[j] == a * v1[j] + b * v2[j] for j in range(8))
    chk('bit', all(in_span(w) for w in nullb), 'the null space is exactly span{M/rho, (c/2) rho^2}: no other Laurent term (k = -3..3) and no other c: the extra solutions are absent')
    # standard route
    colsS = {}
    for k in range(-3, 4):
        rr_ = []
        for (p, rho0) in POINTS:
            rho = F(rho0); jets = (rho ** k, k * rho ** (k - 1), k * (k - 1) * rho ** (k - 2)); Gs = std_G(p, rho0, jets); rr_ += [Gs[i][j] for i in range(4) for j in range(4)]
        colsS[k] = rr_
    colcS = []
    for (p, rho0) in POINTS: colcS += [(-3 if i == j else 0) for i in range(4) for j in range(4)]
    rowsS = [list(r) for r in zip(*([colsS[k] for k in range(-3, 4)] + [colcS]))]
    rankS, nullS = gs.rank_and_null(rowsS, 8)
    chk('bit==std', rows == rowsS and rankS == rank, 'the same linear system built from the Christoffel-route Einstein tensor G - 3c delta is identical to the engine\'s (all %d x 8 entries) and has the same rank and null space' % len(rows))
    tick('part 3')

    # ================================================================================== 4. the reduction to (rho f)' = (3/2) c rho^2 and its integration
    head('4. the radial equation as an ODE: (rho f)\' = (3/2) c rho^2, general solution M/rho + (c/2) rho^2')
    ok_sol = True; ok_nosol = True; samples = 0
    for (p, rho0) in POINTS:
        rho = F(rho0)
        for M in (F(1, 3), F(-2), F(5, 7)):
            for c in (F(0), F(1, 4), F(-1, 3)):
                jets = (M / rho + c / 2 * rho ** 2, -M / rho ** 2 + c * rho, 2 * M / rho ** 3 + c); Mx, comp = engine_M(p, rho0, jets, c)
                ok_sol &= all(v == 0 for v in comp.values()); samples += 1
    chk('bit', ok_sol, 'E_a(c) = 0, all 16 components, for f = M/rho + (c/2) rho^2 with M in {1/3, -2, 5/7} and c in {0, 1/4, -1/3}: %d samples (M free: the integration constant of the ODE)' % samples)
    tick('part 4')

    # ================================================================================== 5. controls
    head('5. controls: a wrong version must fail')
    cnt = {'angular dependence of f': [0, 0], 'f = M/rho^2 (wrong power), c = 0': [0, 0], 'solution with a wrong c': [0, 0], 'closed form with tt coefficient 1 instead of 2': [0, 0],
           'closed form with the tangential coefficient swapped': [0, 0]}
    X = {i: var(4, i) for i in (1, 2, 3)}
    for (p, rho0) in POINTS[:4]:
        rho = F(rho0); M = F(1, 3); c = F(1, 4)
        jets = (M / rho + c / 2 * rho ** 2, -M / rho ** 2 + c * rho, 2 * M / rho ** 3 + c)
        # a solution of the radial equation plus a linear angular term f -> f + a (x - p_x)/rho0^2 (+ a quadratic term)
        fx = lin((F(1, 10), X[1]), (F(1, 20), sp_mul(X[2], X[3], 2, 4)))
        Mx, comp = engine_M(p, rho0, jets, c, fextra=fx); cnt['angular dependence of f'][1] += 1; cnt['angular dependence of f'][0] += int(any(v != 0 for v in comp.values()))
        Gc = sub_c(Mx, c); cf = closed_form(p, rho0, jets); cnt['angular dependence of f'][1] += 1; cnt['angular dependence of f'][0] += int(Gc != cf)
        jets2 = (M / rho ** 2, -2 * M / rho ** 3, 6 * M / rho ** 4); _, comp2 = engine_M(p, rho0, jets2, F(0)); cnt['f = M/rho^2 (wrong power), c = 0'][1] += 1; cnt['f = M/rho^2 (wrong power), c = 0'][0] += int(any(v != 0 for v in comp2.values()))
        for cw in (F(1, 3), F(0), F(-1, 4)):
            _, comp3 = engine_M(p, rho0, jets, cw); cnt['solution with a wrong c'][1] += 1; cnt['solution with a wrong c'][0] += int(any(v != 0 for v in comp3.values()))
        jr = rjets(rng); Mq, _ = engine_M(p, rho0, jr, F(0))
        cnt['closed form with tt coefficient 1 instead of 2'][1] += 1; cnt['closed form with tt coefficient 1 instead of 2'][0] += int(Mq != closed_form(p, rho0, jr, tt_coef=1))
        cs = closed_form(p, rho0, (jr[0], jr[2], jr[1])); cnt['closed form with the tangential coefficient swapped'][1] += 1; cnt['closed form with the tangential coefficient swapped'][0] += int(Mq != cs)
    for name, (dif, seen) in cnt.items():
        chk('ctl', dif == seen and seen > 0, '"%s": the engine\'s result differs from the (wrong) prediction on %d of %d samples' % (name, dif, seen))
    tick('part 5')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('C1')
if __name__ == '__main__': main()
