#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""D1.  The Newtonian limit with all three equations, on the bit-rule engine.   python3 d1_newtonian_limit.py

 Frame  e^0 = (1 + lam Phi_t(x)) dt,  e^i = (1 - lam Phi_s(x)) dx^i   (signature +,-,-,-), lam a bookkeeping parameter: every product of the engine is cut at lam^1 (exact for the kept terms).
 [bit]  omega = closed form (A3), R = d omega + (1/4)[omega, omega], E_a (the engine), read at the origin at order lam^1; the free-fall acceleration from the engine's own covariant
        derivative D_vector, du^c/dtau = - h_{Ab}^c omega^A(xdot) u^b, for the particle at rest, u = (1,0,0,0).
 [std]  linearised Riemann/Einstein tensor and linearised geodesic (textbook weak-field formulas from h = d g/d lam), and the exact nonlinear Einstein tensor and Christoffel symbols at small numeric lam.
 The three jobs:  (a) 00: E_0 = -2 (nabla^2 Phi_s) Theta_0 (Poisson);  (b) space: only Phi_t - Phi_s enters, the map from its Hessian to the equations has rank 6, so Phi_t = Phi_s;
                  (c) geodesic: d2x/dt2 = -grad Phi_t.   Then Newton's law of step 16 (a = G sum m_j (p_j - x)/d_j^3) and kappa = 8 pi G."""
import time
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
from a3_closed_form import christoffel0
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
n = 4; NV = 5; SQ = LORENTZ(4)
Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)
LAMV = var(NV, 4)
full = (1 << n) - 1

def lift(p): return {k + (0,): v for k, v in p.items()}                       # polynomial in 4 slots -> 5 slots
def rand_phi(rng, deg=3, coef=3, density=.6):
    d = {}
    for ex in itertools.product(range(deg + 1), repeat=3):
        if sum(ex) <= deg and rng.random() < density: d[(0,) + ex] = F(rng.randint(-coef, coef))
    return d or {(0, 0, 0, 0): F(1)}
def mono(ex): return {(0,) + tuple(ex): F(1)}                                 # x^a y^b z^c as a 4-slot polynomial
def d2(p, i, j): return at0(sp_der(sp_der(p, i), j), 4)
def d1(p, i): return at0(sp_der(p, i), 4)

def frame_lam(Phit, Phis):
    """first-order machinery: forms with an extra exponent slot for lam"""
    one = const(NV, 1)
    e = [{1 << 0: lin((F(1), one), (F(1), pm(LAMV, lift(Phit))))}]
    for i in (1, 2, 3): e.append({1 << i: lin((F(1), one), (F(-1), pm(LAMV, lift(Phis))))})
    return e
def frame_num(Phit, Phis, lam):
    one = const(4, 1)
    e = [{1: lin((F(1), one), (lam, Phit))}]
    for i in (1, 2, 3): e.append({1 << i: lin((F(1), one), (-lam, Phis))})
    return e

def engine_first_order(Phit, Phis, c=0):
    e = frame_lam(Phit, Phis)
    with trunc(n, xdeg=1, lam=1):
        om, w, D = omega_closed_form(Gv, e, S, NV, 1)
        R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(c))
    comp = {k: {l: at_lam(Ea[k[0]].get(full ^ (1 << k[1]), {}), n, NV, l) for l in (0, 1)} for k in [(a, mu) for a in range(n) for mu in range(n)]}
    return e, om, comp
def accel_engine(om, e, lam_order=1):
    """[bit] du^c/dtau for u = (1,0,0,0) at the origin: - sum over (A, b=0) in h of h * omega^A_t * E^t_0   (order lam^lam_order)"""
    with trunc(n, xdeg=1, lam=1):
        E, det = inverse_series(frame_matrix(e, n), n, NV, 1)
        acc = [{} for _ in range(n)]
        for (A, b), (cc, hv) in Gv.L.h.items():
            if b != 0: continue
            w_t = om[A].get(1 << 0, {})
            if w_t: acc[cc] = padd(acc[cc], pm(w_t, E[0][0]), -hv)
    return [at_lam(acc[c_], n, NV, lam_order) for c_ in range(n)]

# ---------------------------------------------------------------------------------------------- [std] weak-field formulas
def hmunu(Phit, Phis):
    """h = d g / d lam at lam = 0:  h_00 = 2 Phi_t, h_ii = +2 Phi_s  (since g_ii = -(1 - lam Phi_s)^2)"""
    h = {(m, v): {} for m in range(n) for v in range(n)}
    h[(0, 0)] = scale(Phit, 2)
    for i in (1, 2, 3): h[(i, i)] = scale(Phis, 2)
    return h
def linear_einstein(Phit, Phis):
    """[std] linearised Riemann R_{rho sigma mu nu} = 1/2 (d_s d_m h_{rn} + d_r d_n h_{sm} - d_s d_n h_{rm} - d_r d_m h_{sn}), Ricci, scalar and G^mu_nu with eta = diag(1,-1,-1,-1); at the origin"""
    h = hmunu(Phit, Phis); eta = SQ
    dd = lambda i, j, a, b: d2(h[(a, b)], i, j) if h[(a, b)] else F(0)
    Rl = {}
    for r in range(n):
        for s_ in range(n):
            for m in range(n):
                for v in range(n): Rl[(r, s_, m, v)] = F(1, 2) * (dd(s_, m, r, v) + dd(r, v, s_, m) - dd(s_, v, r, m) - dd(r, m, s_, v))
    ric = [[sum(eta[r] * Rl[(r, s_, r, v)] for r in range(n)) for v in range(n)] for s_ in range(n)]
    Rs = sum(eta[s_] * ric[s_][s_] for s_ in range(n))
    G_low = [[ric[s_][v] - (F(1, 2) * eta[s_] * Rs if s_ == v else 0) for v in range(n)] for s_ in range(n)]
    return [[eta[m] * G_low[m][v] for v in range(n)] for m in range(n)]          # G^mu_nu
def linear_accel(Phit, Phis):
    """[std] linearised geodesic: d2x^i/dt2 = - Gamma^i_{00},  Gamma^l_{mn} = 1/2 eta^{ll} (d_m h_{ln} + d_n h_{lm} - d_l h_{mn})"""
    h = hmunu(Phit, Phis); out = []
    for i in range(1, n):
        g = F(1, 2) * SQ[i] * (d1(h[(i, 0)], 0) * 2 - d1(h[(0, 0)], i)) if h[(i, 0)] else F(1, 2) * SQ[i] * (-d1(h[(0, 0)], i))
        out.append(-g)
    return out
def predicted_comp1(Gmix):
    """E_a = -G^h_a Theta_h with Theta_h^(0) = (-1)^h dx^{hat h} (flat frame):  comp[(a, mu)] = -(-1)^mu G^mu_a"""
    return {(a, mu): -(-1) ** mu * Gmix[mu][a] for a in range(n) for mu in range(n)}

def run():
    rng = random.Random(2026)
    # ------------------------------------------------------------------------------------------ part 1
    head('PART 1  order lam^1: the engine\'s Einstein form against the linearised Einstein tensor (textbook weak-field), complete basis and random fields')
    monos = [ex for ex in itertools.product(range(4), repeat=3) if sum(ex) <= 3]
    ok_basis = True; ok_zero0 = True; lap_ok = True; flux_zero = True; cnt = 0
    spatial_rows = {}
    for which in ('Phi_t', 'Phi_s'):
        for ex in monos:
            Pt = mono(ex) if which == 'Phi_t' else {}; Ps = mono(ex) if which == 'Phi_s' else {}
            e, om, comp = engine_first_order(Pt, Ps)
            Gm = linear_einstein(Pt, Ps); pred = predicted_comp1(Gm)
            ok_basis &= all(comp[k][1] == pred[k] for k in comp); ok_zero0 &= all(comp[k][0] == 0 for k in comp); cnt += 1
            lap_s = sum(d2(Ps, i, i) for i in (1, 2, 3)) if Ps else F(0)
            lap_ok &= (comp[(0, 0)][1] == -2 * lap_s)
            flux_zero &= all(comp[(0, mu)][1] == 0 for mu in (1, 2, 3)) and all(comp[(a, 0)][1] == 0 for a in (1, 2, 3))
            if which == 'Phi_t' and sum(ex) == 2: spatial_rows[ex] = {(a, mu): comp[(a, mu)][1] for a in (1, 2, 3) for mu in (1, 2, 3)}
    chk('bit==std', ok_basis, 'complete basis: Phi_t or Phi_s each equal to one monomial x^a y^b z^c of degree <= 3 (%d engine runs): the order-lam^1 coefficient of every component of E_a equals -G^mu_a (-1)^mu of the linearised Einstein tensor, exactly' % cnt)
    chk('bit', ok_zero0, 'the order-lam^0 part of E_a is zero (flat space is a solution)')
    chk('bit', True, 'E_a is linear in (Phi_t, Phi_s) at this order by construction (products cut at lam^1), so the basis result holds for every polynomial pair of degree <= 3: no sampling')
    rngp = random.Random(5); okr = True
    for t in range(6):
        Pt, Ps = rand_phi(rngp), rand_phi(rngp); e, om, comp = engine_first_order(Pt, Ps); pred = predicted_comp1(linear_einstein(Pt, Ps)); okr &= all(comp[k][1] == pred[k] for k in comp)
    chk('bit==std', okr, '6 random polynomial pairs (degree 3, random rational coefficients, constants included): same equality')
    tick('part 1')
    # ------------------------------------------------------------------------------------------ part 2: the three jobs
    head('PART 2  the three jobs of the three groups of equations')
    chk('bit', lap_ok, '(a) the 00 equation: the component of E_0 along dx^1 dx^2 dx^3 is exactly -2 (nabla^2 Phi_s)(0), whatever Phi_t is (all %d basis fields): E_0 = -2 nabla^2 Phi_s Theta_0' % cnt)
    chk('bit', flux_zero, 'the equations with one time index (energy flux, momentum density) vanish for static fields, all %d basis fields' % cnt)
    # (b) the spatial equations: only Delta = Phi_t - Phi_s, Hessian map of rank 6
    okD = True
    for t in range(4):
        Pt, Ps, psi = rand_phi(rngp), rand_phi(rngp), rand_phi(rngp)
        _, _, c1 = engine_first_order(Pt, Ps); _, _, c2 = engine_first_order(lin((1, Pt), (1, psi)), lin((1, Ps), (1, psi)))
        okD &= all(c1[(a, mu)][1] == c2[(a, mu)][1] for a in (1, 2, 3) for mu in (1, 2, 3))
    chk('bit', okD, '(b) the space equations (a, mu = 1..3) do not change when the same function is added to Phi_t and Phi_s: they depend on Phi_t - Phi_s only')
    pairs6 = [(1, 1), (2, 2), (3, 3), (1, 2), (1, 3), (2, 3)]; Mrows = []
    for (i, j) in pairs6:
        ex = [0, 0, 0]; ex[i - 1] += 1; ex[j - 1] += 1; row = spatial_rows[tuple(ex)]
        Mrows.append([row[(a, mu)] for a in (1, 2, 3) for mu in (1, 2, 3)])
    Mcols = [list(col) for col in zip(*Mrows)]
    rk = rank_exact([r[:] for r in Mrows])
    chk('bit', rk == 6, '(b) the map from the 6 second derivatives of Phi_t - Phi_s to the 9 space equations, read from the engine, has exact rank %d (= 6): all second derivatives of Phi_t - Phi_s are forced to vanish; with decay at infinity Phi_t = Phi_s' % rk)
    # the explicit form of the space equations: comp[(i, j)] = kappa_s (-1)^j (d_i d_j Delta - delta_ij nabla^2 Delta)  with Delta = Phi_t - Phi_s
    ks = set(); okform = True
    for (ex, row) in spatial_rows.items():
        Pt = mono(ex); lapD = sum(d2(Pt, i, i) for i in (1, 2, 3))
        for a in (1, 2, 3):
            for mu in (1, 2, 3):
                form = (-1) ** mu * (d2(Pt, a, mu) - (lapD if a == mu else 0))
                if form != 0: ks.add(row[(a, mu)] / form)
                else: okform &= (row[(a, mu)] == 0)
    chk('bit', okform and len(ks) == 1, '(b) explicit form read from the engine: E_i along dx^{hat j} = %s (-1)^j (d_i d_j - delta_ij nabla^2)(Phi_t - Phi_s)  (one constant for all i, j and all Hessian directions)' % sorted(map(str, ks)))
    # (c) the geodesic
    okA = True; okA0 = True; cnt2 = 0
    for ex in monos:
        Pt = mono(ex); e, om, comp = engine_first_order(Pt, {})
        acc = accel_engine(om, e); want = [-d1(Pt, i) for i in (1, 2, 3)]; std_ = linear_accel(Pt, {})
        okA &= ([acc[i] for i in (1, 2, 3)] == want) and (want == std_); okA0 &= (acc[0] == 0); cnt2 += 1
    chk('bit==std', okA, '(c) free fall of a particle at rest from the engine\'s covariant derivative: du^i/dtau = -d_i Phi_t exactly at order lam^1 for every monomial Phi_t of degree <= 3 (%d fields); the linearised geodesic -Gamma^i_00 gives the same' % cnt2)
    chk('bit', okA0, 'du^0/dtau = 0 (no change of the time component)')
    okS = True
    for ex in monos:
        Ps = mono(ex); e, om, comp = engine_first_order({}, Ps); acc = accel_engine(om, e); okS &= all(acc[i] == 0 for i in range(n))
    chk('bit', okS, 'Phi_s alone produces no acceleration of a particle at rest (all %d monomials): the force law is read from Phi_t, the source from Phi_s' % len(monos))
    tick('part 2')
    # ------------------------------------------------------------------------------------------ part 3: nonlinear exact vs std
    head('PART 3  exact nonlinear check at numeric lam: engine acceleration = -Gamma^i_00 (exact fractions), and the O(lam^2) remainder of E_0')
    okN = True
    for lam in (F(1, 7), F(1, 100), F(2, 3)):
        Pt, Ps = rand_phi(rngp), rand_phi(rngp)
        # the potentials must keep the frame invertible at the origin; the constants 1 + lam Phi are non-zero for these lam
        e = frame_num(Pt, Ps, lam); e0, E0, det = E0_of(e, n, 4)
        om, w, D = omega_closed_form(Gv, e, S, 4, 1)
        acc = [F(0)] * n
        for (A, b), (cc, hv) in Gv.L.h.items():
            if b == 0: acc[cc] += -hv * at0(om[A].get(1, {}), 4) * E0[0][0]
        xdd = [sum(E0[i][j] * acc[j] for j in range(n)) / E0[0][0] ** 2 for i in (1, 2, 3)]
        g = std_metric(e, n, SQ, 4, 2); Gam = christoffel0(g, n, 4)
        okN &= (xdd == [-Gam[(i, 0, 0)] for i in (1, 2, 3)])
    chk('bit==std', okN, 'at lam = 1/7, 1/100, 2/3 (exact, no expansion): d2x^i/dt2 from the engine\'s omega and inverse frame equals -Gamma^i_{tt} of the metric, exactly')
    Pt, Ps = rand_phi(random.Random(9)), rand_phi(random.Random(10)); _, _, c1 = engine_first_order(Pt, Ps)
    rem = {}
    for lam in (F(1, 1000), F(1, 10000)):
        e = frame_num(Pt, Ps, lam); om, w, D = omega_closed_form(Gv, e, S, 4, 1)
        with trunc(n, xdeg=1): R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(0))
        cmp_ = einstein_components(Ea, n, 4); rem[lam] = {k: (cmp_[k] / lam - c1[k][1]) / lam for k in cmp_}
    k0 = (0, 0); r3, r4 = rem[F(1, 1000)][k0], rem[F(1, 10000)][k0]
    chk('bit', all(c1[k][0] == 0 for k in c1) and r4 != 0 and abs(float(r3 / r4) - 1) < 5e-2,
        'exact E_0 at lam = 1e-3 and 1e-4 minus the first-order coefficient, divided by lam: %.4g and %.4g (a constant: the remainder is O(lam^2), so the first-order coefficient is the lam -> 0 limit)' % (float(r3), float(r4)))
    tick('part 3')
    # ------------------------------------------------------------------------------------------ part 4: sources, Newton's law of step 16, kappa
    head('PART 4  sources: point masses (Newton\'s law of step 16) and a uniform ball (kappa = 8 pi G)')
    def inv_dist(q, d):
        u = lin((F(2) / d ** 2, lin(*[(F(q[i - 1]), mono([1 if k == i - 1 else 0 for k in range(3)])) for i in (1, 2, 3)])), (F(1) / d ** 2, lin(*[(F(1), mono([2 if k == i - 1 else 0 for k in range(3)])) for i in (1, 2, 3)])))
        u2 = sp_mul(u, u, 2, 4); ser = lin((F(1), const(4, 1)), (F(-1, 2), u), (F(3, 8), u2))
        return {k: v / d for k, v in sp_mul(ser, const(4, 1), 2, 4).items() if sum(k[:4]) <= 2}
    G_ = F(3, 2); masses = [((3, 4, 12), 13, F(2)), ((-2, 6, -9), 11, F(3))]
    Phi = {}
    for P, d, m in masses:
        q = [-x for x in P]; Phi = padd(Phi, inv_dist(q, F(d)), -G_ * m)
    e, om, comp = engine_first_order(Phi, Phi); acc = accel_engine(om, e)
    want = [sum(G_ * m * F(P[i]) / F(d) ** 3 for P, d, m in masses) for i in range(3)]                    # step 16:  a_i = G sum m_j (p_j - x)/d_j^3 at x = 0
    chk('bit==std', [acc[1], acc[2], acc[3]] == want, 'two point masses (G = 3/2, m = 2 and 3, distances 13 and 11 as in the integer-separation bodies of step 16): the engine\'s acceleration equals Newton\'s a = G sum m_j (p_j - x)/d_j^3 exactly: %s' % [str(x) for x in want])
    chk('bit', all(comp[k][1] == 0 for k in comp), 'vacuum there: every component of E_a at order lam^1 is zero for Phi_t = Phi_s = -G sum m_j / |x - p_j| (the potential is harmonic, nabla^2 Phi = 0 exactly in the Taylor jet)')
    # the same with Phi_t != Phi_s (control, below)
    q_ = F(3)                                                                                              # kappa * rho
    Pball = lin((q_ / 12, mono([2, 0, 0])), (q_ / 12, mono([0, 2, 0])), (q_ / 12, mono([0, 0, 2])))
    x0 = [F(1), F(2), F(-1)]                                                                               # base point inside the ball (centre = origin of the potential)
    Pb4 = shift_poly(Pball, [F(0)] + x0, 4)
    e, om, comp = engine_first_order(Pb4, Pb4); acc = accel_engine(om, e)
    chk('bit', comp[(0, 0)][1] == -q_ and all(comp[k][1] == 0 for k in comp if k != (0, 0)), 'uniform ball, Phi_t = Phi_s = (q/12) r^2 with q = kappa rho = 3: E_0 = -q Theta_0 = -kappa rho Theta_0 and no other component; the space equations are satisfied by Phi_t = Phi_s')
    chk('bit==std', [acc[1], acc[2], acc[3]] == [-q_ / 6 * x for x in x0], 'the acceleration inside the ball is -(kappa rho / 6) x = %s; Newton\'s shell theorem gives G m(r)/r^2 = (4 pi G rho / 3) r, so kappa = 8 pi G (E_a + kappa T_a = 0 with T_0 = rho Theta_0): Poisson calibrates kappa' % [str(-q_ / 6 * x) for x in x0])
    tick('part 4')
    # ------------------------------------------------------------------------------------------ part 5: controls
    head('PART 5  controls')
    e, om, comp_same = engine_first_order(Phi, Phi)
    e, om, comp_two = engine_first_order(scale(Phi, 2), Phi)
    chk('ctl', comp_two[(0, 0)][1] == comp_same[(0, 0)][1] == 0 and any(comp_two[(a, mu)][1] != 0 for a in (1, 2, 3) for mu in (1, 2, 3)),
        'Phi_t = 2 Phi_s (harmonic Phi_s): the 00 equation is still satisfied, the space equations are not (non-zero): the 00 equation alone cannot tell the Newtonian relation')
    e, om, comp_neg = engine_first_order(scale(Phi, -1), Phi); acc_neg = accel_engine(om, e); e, om, comp_pos = engine_first_order(Phi, Phi); acc_pos = accel_engine(om, e)
    chk('ctl', comp_neg[(0, 0)][1] == comp_pos[(0, 0)][1] and [acc_neg[i] for i in (1, 2, 3)] == [-acc_pos[i] for i in (1, 2, 3)] and any(comp_neg[(a, mu)][1] != 0 for a in (1, 2, 3) for mu in (1, 2, 3)),
        'Phi_t -> -Phi_t: the 00 equation is unchanged, the acceleration flips sign (repulsion), and the space equations are violated: attraction goes with Phi_t = +Phi_s')
    Pneg = scale(Pb4, F(-1)); e, om, comp = engine_first_order(Pneg, Pneg); accn = accel_engine(om, e)
    chk('ctl', comp[(0, 0)][1] == q_ and [accn[1], accn[2], accn[3]] == [q_ / 6 * x for x in x0], 'source of the other sign (kappa rho = -3, i.e. kappa < 0 for positive rho): E_0 = +3 Theta_0 and the acceleration is +(1/2) x, outward: repulsion. The sign of the source is an input; kappa > 0 is attraction')
    e, om, comp = engine_first_order(Phi, Phi); acc0 = accel_engine([{} for _ in range(Gv.G)], e)
    chk('ctl', any(acc_pos[i] != 0 for i in (1, 2, 3)) and acc0 == [F(0)] * n, 'omega -> 0 gives no acceleration while the same frame has Phi_t != 0: the force is carried by the connection')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('D1')
if __name__ == '__main__': run()
