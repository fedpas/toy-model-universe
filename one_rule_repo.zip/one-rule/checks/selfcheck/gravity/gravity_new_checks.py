#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""It finds the engine selfcheck/gravity_selfcheck.py from its own location (the parent of its folder).  python3 gravity_new_checks.py [1] [2]
Two exact checks on the gravity steps (exact fractions, standard library only).
 Check 2: solve the torsion-free condition T = 0 for omega, pointwise, with the step-9 engine (forms = bit rule with null generators), n = 3, 4, 5:
          the system is square and has full rank (the solution is unique), and the solution reproduces the Levi-Civita connection of the metric g = e^T eta e.
 Check 1: the step-10 Einstein form E_a on the Kerr-Schild frame of step 12 (Schwarzschild), exact at rational points, inside, on and outside r = 2M:
          omega is solved from T = 0 as a first-order jet, R = d omega + (1/4)[omega, omega], E_a = sum eps F^{bc} e^d.  Controls: other shears, a charge term."""
import sys, itertools, random, os
from fractions import Fraction as F
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(_here))                     # selfcheck/ of the package, the parent of this folder
import gravity_selfcheck as gs
from gravity_selfcheck import Grav, Lie, lorentz, padd, pmul, pder, bmul

FAILS = []
def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond: FAILS.append(msg)

# ---------------------------------------------------------------- exact linear algebra
def solve_exact(rows, rhs):
    """rows: list of lists (Fractions); solve rows*w = rhs exactly. returns (w or None, rank, n_unknowns, consistent)"""
    m, nvar = len(rows), len(rows[0])
    M = [r[:] + [b] for r, b in zip(rows, rhs)]; piv = []; r = 0
    for c in range(nvar):
        p = next((i for i in range(r, m) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(m):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
        if r == m: break
    consistent = all(M[i][nvar] == 0 for i in range(r, m))
    w = [F(0)] * nvar
    for i, c in enumerate(piv): w[c] = M[i][nvar]
    return (w if consistent else None), r, nvar, consistent
def det_inv(Mx):
    n = len(Mx); A = [r[:] + [F(int(i == j)) for j in range(n)] for i, r in enumerate(Mx)]; det = F(1)
    for c in range(n):
        p = next((i for i in range(c, n) if A[i][c] != 0), None)
        if p is None: return F(0), None
        if p != c: A[c], A[p] = A[p], A[c]; det = -det
        det *= A[c][c]; inv = 1 / A[c][c]; A[c] = [x * inv for x in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return det, [r[n:] for r in A]

# ---------------------------------------------------------------- polynomial jets
def trunc(p, d): return {k: v for k, v in p.items() if sum(k) <= d}
def ftrunc(X, d):
    r = {}
    for m, p in X.items():
        t = trunc(p, d)
        if t: r[m] = t
    return r
def pmt(a, b, d): return trunc(pmul(a, b), d)
def const(n, c): return {(0,) * n: F(c)} if c != 0 else {}
def var(n, i): return {tuple(1 if j == i else 0 for j in range(n)): F(1)}
def psum(*ps):
    r = {}
    for c, p in ps: r = padd(r, p, c)
    return r
def at0(p, n): return p.get((0,) * n, F(0))

# ---------------------------------------------------------------- the torsion-free solve (pointwise or as a jet of given order)
def solve_torsion_free(Gv, e, order):
    """unknown omega^A_mu(x) = polynomial of degree <= order; equations: the coefficients of T^c of degree <= order vanish.  Returns (omega forms, rank, unknowns, consistent)"""
    n, L, Fm = Gv.n, Gv.L, Gv.Fm; G = Gv.G
    zero_om = [{} for _ in range(G)]
    T0 = Gv.torsion(zero_om, e)
    unknowns = []                                                       # (A, mu, monomial exponent)
    mons = [tuple(0 for _ in range(n))] + ([tuple(1 if j == i else 0 for j in range(n)) for i in range(n)] if order >= 1 else [])
    for A in range(G):
        for mu in range(n):
            for mo in mons: unknowns.append((A, mu, mo))
    eqkeys = {}
    def key(c, mask, mo):
        k = (c, mask, mo)
        if k not in eqkeys: eqkeys[k] = len(eqkeys)
        return eqkeys[k]
    cols = []
    for (A, mu, mo) in unknowns:
        om = [{} for _ in range(G)]; om[A] = {1 << mu: {mo: F(1)}}
        T = Gv.torsion(om, e); col = {}
        for c in range(n):
            for mask, p in T[c].items():
                for ex, v in p.items():
                    if sum(ex) <= order: col[key(c, mask, ex)] = col.get(key(c, mask, ex), 0) + v
        # subtract the omega-independent part
        for c in range(n):
            for mask, p in T0[c].items():
                for ex, v in p.items():
                    if sum(ex) <= order: col[key(c, mask, ex)] = col.get(key(c, mask, ex), 0) - v
        cols.append(col)
    rhs = {}
    for c in range(n):
        for mask, p in T0[c].items():
            for ex, v in p.items():
                if sum(ex) <= order: rhs[key(c, mask, ex)] = rhs.get(key(c, mask, ex), 0) - v
    neq = len(eqkeys); nvar = len(unknowns)
    rows = [[F(0)] * nvar for _ in range(neq)]
    for j, col in enumerate(cols):
        for k, v in col.items(): rows[k][j] = F(v)
    b = [F(0)] * neq
    for k, v in rhs.items(): b[k] = F(v)
    w, rank, nv, cons = solve_exact(rows, b)
    if w is None: return None, rank, nvar, False, neq
    om = [{} for _ in range(G)]
    for val, (A, mu, mo) in zip(w, unknowns):
        if val == 0: continue
        om[A].setdefault(1 << mu, {}); om[A][1 << mu][mo] = om[A][1 << mu].get(mo, 0) + val
    return om, rank, nvar, True, neq

def torsion_zero_to(Gv, om, e, order):
    T = Gv.torsion(om, e)
    return all(not v for c in T for p in c.values() for ex, v in p.items() if sum(ex) <= order)

# ---------------------------------------------------------------- Christoffel of the metric g = e^T eta e, exact from jets
def metric_from(Gv, e, eta):
    n = Gv.n; g = {}
    ec = [[e[a].get(1 << mu, {}) for mu in range(n)] for a in range(n)]
    for mu in range(n):
        for nu in range(n):
            g[(mu, nu)] = psum(*[(eta[a], pmul(ec[a][mu], ec[a][nu])) for a in range(n)])
    return g, ec
def omega_to_gamma_at0(Gv, om, ec, E0):
    """Gamma^lam_{mu nu} = E^lam_a (d_mu e^a_nu + omega^a_{b mu} e^b_nu)  at the origin; E0[lam][a] = inverse of e0"""
    n, L = Gv.n, Gv.L
    w = lambda A, mu: at0(om[A].get(1 << mu, {}), n)
    Gam = {}
    for lam in range(n):
        for mu in range(n):
            for nu in range(n):
                tot = F(0)
                for a in range(n):
                    t = pder(ec[a][nu], mu); t = at0(t, n)
                    for (A, b), (c, h) in L.h.items():
                        if c == a: t += h * w(A, mu) * at0(ec[b][nu], n)
                    tot += E0[lam][a] * t
                Gam[(lam, mu, nu)] = tot
    return Gam
def gamma_lc_at0(g, n, g0inv):
    Gam = {}
    dg = lambda k, a, b: at0(pder(g[(a, b)], k), n)
    for lam in range(n):
        for mu in range(n):
            for nu in range(n):
                Gam[(lam, mu, nu)] = sum(F(1, 2) * g0inv[lam][s] * (dg(mu, s, nu) + dg(nu, s, mu) - dg(s, mu, nu)) for s in range(n))
    return Gam

# ================================================================= CHECK 2: pointwise solve, random tetrads
def check2():
    print('\nCHECK 2  T = 0 solved for omega, exact, pointwise: unique, and equal to the Levi-Civita connection')
    for n in (3, 4, 5):
        rng = random.Random(100 + n); Gv = Grav(n); eta = [1] + [-1] * (n - 1)
        for trial in range(2):
            while True:
                e0 = [[F(rng.randint(-3, 3)) for _ in range(n)] for _ in range(n)]
                if det_inv(e0)[0] != 0: break
            e = []
            for a in range(n):
                form = {}
                for mu in range(n):
                    p = {(0,) * n: e0[a][mu]}
                    for k in range(n):
                        c = F(rng.randint(-3, 3))
                        if c: p[tuple(1 if j == k else 0 for j in range(n))] = c
                    p = {k: v for k, v in p.items() if v != 0}
                    if p: form[1 << mu] = p
                e.append(form)
            om, rank, nvar, cons, neq = solve_torsion_free(Gv, e, 0)
            check(cons and rank == nvar == neq, 'n=%d trial %d: %d equations, %d unknowns, rank %d: the system is square, solvable and has a UNIQUE solution' % (n, trial, neq, nvar, rank))
            check(torsion_zero_to(Gv, om, e, 0), 'n=%d trial %d: the engine\'s own torsion operator gives T = 0 at the point with that omega' % (n, trial))
            g, ec = metric_from(Gv, e, eta)
            _, E0 = det_inv([[at0(ec[a][mu], n) for mu in range(n)] for a in range(n)])      # E0[mu][a]
            _, g0inv = det_inv([[at0(g[(a, b)], n) for b in range(n)] for a in range(n)])
            Gw = omega_to_gamma_at0(Gv, om, ec, E0); Gl = gamma_lc_at0(g, n, g0inv)
            check(Gw == Gl, 'n=%d trial %d: Gamma from omega (tetrad postulate) = Levi-Civita Gamma of the metric e^T eta e, all %d components equal exactly' % (n, trial, n ** 3))
            # controls: a perturbed omega fails torsion and Levi-Civita
            bad = [dict(x) for x in om]
            A0 = next(A for A in range(Gv.G) if om[A] or True); bad[A0] = dict(bad[A0]); bad[A0][1] = padd(bad[A0].get(1, {}), {(0,) * n: F(1)})
            check(not torsion_zero_to(Gv, bad, e, 0) and omega_to_gamma_at0(Gv, bad, ec, E0) != Gl, 'n=%d trial %d (control): adding 1 to one component of omega breaks T = 0 and the match with Levi-Civita' % (n, trial))

# ================================================================= CHECK 1: Kerr-Schild frame of step 12
def ks_frame(M, p, rho0, f_kind='ks', Q2=F(0), H2=F(0)):
    """coframe e^a = dx^a - f l^a l_mu dx^mu on the jet (order 2) around the point p = (x,y,z) with rho0 = |p| rational. f_kind: 'ks' f=M/rho; 'bad' f = M/rho^2 * rho0 (wrong power); 'rn' f = M/rho - Q2/(2 rho^2)"""
    n = 4; X = [var(n, i) for i in range(4)]
    d2 = psum(*[(F(1), pmul(X[i], X[i])) for i in (1, 2, 3)])
    u = psum((F(2) / rho0 ** 2, psum(*[(p[i - 1], X[i]) for i in (1, 2, 3)])), (F(1) / rho0 ** 2, d2))
    u2 = pmt(u, u, 2)
    inv_rho = psum((1 / rho0, const(n, 1)), (-1 / (2 * rho0), u), (F(3, 8) / rho0, u2)); inv_rho = trunc(inv_rho, 2)
    xs = [None] + [psum((F(1), const(n, p[i - 1])), (F(1), X[i])) for i in (1, 2, 3)]
    nh = [None] + [pmt(xs[i], inv_rho, 2) for i in (1, 2, 3)]
    l_up = [const(n, 1)] + [{k: -v for k, v in nh[i].items()} for i in (1, 2, 3)]
    l_dn = [const(n, 1)] + [nh[i] for i in (1, 2, 3)]
    ir2 = pmt(inv_rho, inv_rho, 2)
    if f_kind == 'ks': f = psum((M, inv_rho))
    elif f_kind == 'bad': f = psum((M * rho0, ir2))
    elif f_kind == 'rn': f = psum((M, inv_rho), (-Q2 / 2, ir2))
    elif f_kind == 'q': f = psum((-Q2 / 2, ir2))
    elif f_kind == 'sds':                       # Schwarzschild-de Sitter in Kerr-Schild form on a flat background: f = M/rho + (H2/2) rho^2
        rho2 = psum((F(1), const(n, rho0 ** 2)), (F(2), psum(*[(p[i - 1], X[i]) for i in (1, 2, 3)])), (F(1), d2))
        f = psum((M, inv_rho), (H2 / 2, rho2))
    e = []
    for a in range(4):
        form = {}
        for mu in range(4):
            fl = pmt(pmt(f, l_up[a], 2), l_dn[mu], 2)
            pol = psum((F(1 if a == mu else 0), const(n, 1)), (F(-1), fl))
            if pol: form[1 << mu] = pol
        e.append(form)
    # inverse coframe E^mu_a = delta + f l^mu l_a  (valid because l is null)
    E = [[psum((F(1 if a == mu else 0), const(n, 1)), (F(1), pmt(pmt(f, l_up[mu], 2), l_dn[a], 2))) for a in range(4)] for mu in range(4)]
    return e, E, (l_up, l_dn)

def curvature_checks(label, M, p, rho0, f_kind='ks', Q2=F(0), expect_vacuum=True, verbose=True):
    n = 4; Gv = Grav(4); eta = [1, -1, -1, -1]
    e, E, _ = ks_frame(M, p, rho0, f_kind, Q2)
    om, rank, nvar, cons, neq = solve_torsion_free(Gv, e, 1)
    ok_solve = cons and rank == nvar == neq and torsion_zero_to(Gv, om, e, 1)
    R = Gv.curvature(om)
    Ea, _F = Gv.einstein(None, e, R, 0)
    Evals = {(a, m): at0(pp, n) for a in range(4) for m, pp in Ea[a].items() if at0(pp, n) != 0}
    # metric, Christoffel jets, Riemann from the metric (independent of omega)
    g, ec = metric_from(Gv, e, eta)
    gi = {}
    for la in range(4):
        for si in range(4):
            gi[(la, si)] = psum(*[(eta[a], pmt(E[la][a], E[si][a], 2)) for a in range(4)])
    dg = lambda k, a, b: pder(g[(a, b)], k)
    Gam = {}
    for la in range(4):
        for mu in range(4):
            for nu in range(4):
                tot = {}
                for si in range(4):
                    s = psum((F(1, 2), pmt(gi[(la, si)], psum((F(1), dg(mu, si, nu)), (F(1), dg(nu, si, mu)), (F(-1), dg(si, mu, nu))), 1)))
                    tot = padd(tot, s)
                Gam[(la, mu, nu)] = trunc(tot, 1)
    def riem(rho, sig, mu, nu):                                           # R^rho_{sigma mu nu}
        t = psum((F(1), pder(Gam[(rho, nu, sig)], mu)), (F(-1), pder(Gam[(rho, mu, sig)], nu)))
        t0 = at0(t, n)
        for l in range(4): t0 += at0(Gam[(rho, mu, l)], n) * at0(Gam[(l, nu, sig)], n) - at0(Gam[(rho, nu, l)], n) * at0(Gam[(l, mu, sig)], n)
        return t0
    Rm = {(r_, s_, m_, n_): riem(r_, s_, m_, n_) for r_ in range(4) for s_ in range(4) for m_ in range(4) for n_ in range(4)}
    ric = [[sum(Rm[(r_, s_, r_, n_)] for r_ in range(4)) for n_ in range(4)] for s_ in range(4)]
    # the engine's curvature in coordinate components: R^rho_{sigma mu nu} = E^rho_a e^b_sigma R^a_b,mu nu,  R^a_b = R^{ac} eta_cb
    def Reng(a, b, mu, nu):                                                # R^{ab}_{mu nu}
        if a == b: return F(0)
        s = 1
        aa, bb = a, b
        if aa > bb: aa, bb = bb, aa; s = -1
        A = Gv.L.idx[(1 << aa) | (1 << bb)]
        if mu == nu: return F(0)
        m, q = (mu, nu) if mu < nu else (nu, mu); sg = 1 if mu < nu else -1
        return s * sg * at0(R[A].get((1 << m) | (1 << q), {}), n)
    match = True
    E0 = [[at0(E[mu][a], n) for a in range(4)] for mu in range(4)]; e0 = [[at0(ec[a][mu], n) for mu in range(4)] for a in range(4)]
    for r_ in range(4):
        for s_ in range(4):
            for m_ in range(4):
                for n_ in range(m_ + 1, 4):
                    v = sum(E0[r_][a] * e0[b][s_] * Reng(a, b, m_, n_) * eta[b] for a in range(4) for b in range(4))
                    if v != Rm[(r_, s_, m_, n_)]: match = False
    # Kretschmann from the engine: K = sum eta_a eta_b eta_c eta_d (R^{ab}_{cd})^2 with frame components
    K = F(0)
    for a in range(4):
        for b in range(4):
            for c in range(4):
                for d in range(4):
                    Rfr = sum(Reng(a, b, mu, nu) * E0[mu][c] * E0[nu][d] for mu in range(4) for nu in range(4))
                    K += eta[a] * eta[b] * eta[c] * eta[d] * Rfr * Rfr
    ricnz = any(ric[i][j] != 0 for i in range(4) for j in range(4))
    gi0 = [[at0(gi[(i, j)], n) for j in range(4)] for i in range(4)]
    ricmix = [[sum(gi0[m][s_] * ric[s_][v] for s_ in range(4)) for v in range(4)] for m in range(4)]       # R^mu_nu
    Mf = [[eta[a] * sum(E0[s_][a] * E0[v][b] * ric[s_][v] for s_ in range(4) for v in range(4)) for b in range(4)] for a in range(4)]   # R^a_b in the frame
    def mm(X, Y): return [[sum(X[i][k] * Y[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
    M2 = mm(Mf, Mf); M3 = mm(M2, Mf); M4 = mm(M3, Mf); tr = lambda X: sum(X[i][i] for i in range(4))
    traces = (tr(Mf), tr(M2), tr(M3), tr(M4))
    if verbose: print('    %s: solve %s (rank %d of %d); E_a nonzero components: %d; Ricci nonzero: %s; engine R == Riemann of the metric: %s; K = %s' % (label, ok_solve, rank, nvar, len(Evals), ricnz, match, K))
    return dict(ok_solve=ok_solve, E_zero=(len(Evals) == 0), ric_zero=(not ricnz), match=match, K=K, Evals=Evals, ricmix=ricmix, traces=traces)

def check1():
    print('\nCHECK 1  Einstein form E_a on the Kerr-Schild (Schwarzschild) frame of step 12, exact at rational points')
    pts = [((3, 4, 12), F(13)), ((2, 6, 9), F(11)), ((F(1), F(2), F(2)), F(3)), ((F(1, 2), F(1), F(1)), F(3, 2)), ((F(2, 7), F(3, 7), F(6, 7)), F(1)), ((F(2, 3), F(4, 3), F(4, 3)), F(2))]
    pts = [(tuple(F(x) for x in p), r) for p, r in pts]
    for M in (F(1), F(3, 2)):
        allz = True; allm = True; allK = True; allsolve = True
        for p, r in pts:
            res = curvature_checks('M=%s p=%s rho=%s' % (M, tuple(str(x) for x in p), r), M, p, r)
            allsolve &= res['ok_solve']; allz &= res['E_zero'] and res['ric_zero']; allm &= res['match']; allK &= (res['K'] == 48 * M * M / r ** 6)
        where = 'rho = 13, 11, 3 (outside), 3/2 and 1 (inside the horizon), 2 (on the horizon r = 2M for M = 1)' if M == 1 else 'the same six points (r = 2M is then a different place)'
        check(allsolve, 'M=%s: T = 0 solved exactly as a first-order jet at all six points (square system, full rank, torsion zero to first order)' % M)
        check(allz, 'M=%s: the Einstein form E_a of the bit-rule curvature is EXACTLY ZERO (all 16 components) and the Ricci tensor of the metric is exactly zero at the six points: %s' % (M, where))
        check(allm, 'M=%s: the engine\'s curvature R = d omega + (1/4)[omega, omega] equals the Riemann tensor of the metric (from Christoffel jets), every component, exactly' % M)
        check(allK, 'M=%s: Kretschmann scalar from the engine curvature = 48 M^2 / rho^6 EXACTLY at the six points (step 12 had it to 1e-5 by finite differences)' % M)
    print('  controls')
    p, r = pts[0]
    res = curvature_checks('control wrong power f = M rho0/rho^2', F(1), p, r, 'bad')
    check(not res['E_zero'] and not res['ric_zero'], 'control: the shear with the wrong radial power is not vacuum: E_a nonzero (%d components) and Ricci nonzero' % len(res['Evals']))
    r1 = curvature_checks('charge only f = -Q2/(2 rho^2), Q2=1', F(0), p, r, 'q', F(1)); r2 = curvature_checks('charge only f = -Q2/(2 rho^2), Q2=2', F(0), p, r, 'q', F(2))
    r3 = curvature_checks('mass + charge', F(1), p, r, 'rn', F(1))
    check(not r1['E_zero'] and not r1['ric_zero'], 'control: a charge term alone (Reissner-Nordstrom function f = -Q^2/(2 rho^2)) gives E_a nonzero (%d components) and Ricci nonzero' % len(r1['Evals']))
    check(all(2 * r1['ricmix'][i][j] == r2['ricmix'][i][j] for i in range(4) for j in range(4)) and all(r3['ricmix'][i][j] == r1['ricmix'][i][j] for i in range(4) for j in range(4)),
          'control: the mixed Ricci tensor R^mu_nu is linear in the Kerr-Schild function (doubling Q^2 doubles it; adding the mass term M/rho changes nothing): the known Kerr-Schild property, exact')
    q = F(1) / r ** 4
    check(r1['traces'] == (0, 4 * q * q, 0, 4 * q ** 4) and r3['traces'] == (0, 4 * q * q, 0, 4 * q ** 4),
          'control: for the charged function the Ricci tensor in the frame has trace 0 and power traces (0, 4q^2, 0, 4q^4), q = Q^2/rho^4: eigenvalues (q, q, -q, -q), the Maxwell stress structure of Reissner-Nordstrom, exactly')
    # Einstein form with a cosmological term on the same frame is not zero (c != 0): E_a(c) - E_a(0) = c * (e e e terms) nonzero
    n = 4; Gv = Grav(4); e, E, _ = ks_frame(F(1), p, r); om, *_ = solve_torsion_free(Gv, e, 1); R = Gv.curvature(om)
    Ec, _ = Gv.einstein(None, e, R, F(1, 3))
    nzc = sum(1 for a in range(4) for m, pp in Ec[a].items() if at0(pp, n) != 0)
    check(nzc > 0, 'control: with a cosmological term c = 1/3 the same frame is not a solution (E_a nonzero, %d components): the test sees the term' % nzc)

if __name__ == '__main__':
    which = sys.argv[1:] or ['2', '1']
    if '2' in which: check2()
    if '1' in which: check1()
    print('\nFAILS:', FAILS if FAILS else 'none')
    sys.exit(1 if FAILS else 0)
