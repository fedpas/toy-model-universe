#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H4-cosmological.  Kaluza-Klein at n = 5 with a cosmological term: two generators, two signs.   python3 h4_cosmological.py

 Frame as in h4_kaluza_klein: squares sq = (1, -1, -1, -1, eps), coordinates (x^0..x^3, y), e^a = e4^a(x) (a = 0..3), e^4 = phi(x)(dy + A(x)),
 nothing depends on y.  The Einstein form carries the cosmological term: E_a(c) with F^{bc} = R^{bc} + c e^b e^c, c != 0 of both signs.
 X^h_a(c) is read off E_a(c) = -X^h_a Theta_h (the reading of A4 and H4).
 [bit]  omega = closed form, R = d omega + 1/4 [omega, omega], E_a(c) of the engine at n = 5 (one connection, every c);
        the curvature of the algebra with one more generator of square s on the base (1, -1, -1, -1, eps): k with F^{ab} = R^{ab} + k kappa^2 e^a e^b (b1lib.embed_k).
 [std]  (i)  5D: G5 of g5 = e^T diag(sq) e by the Christoffel route; X(c) = G5 - 6c delta (6 = C(4, 2), the count of pairs in the c-term of E_a).
        (ii) 4D only (no 5D object, no engine): G4, R4, the Maxwell stress T, the Hessian and gradient of phi, the Maxwell divergence (h4_kaluza_klein.std4_pieces).
        (iii) the matrix algebra so(p, q) of the six generators (h3_sign_chain.std_lie_table) for k.
 Claim (coefficients FITTED exactly over random frames and several c, then verified on fresh frames):
   4D block  X^b_a = G4^b_a + eps (phi^2/2) T^b_a - (1/phi)(nabla^b nabla_a phi - delta^b_a box phi) - 6c delta^b_a
   44        X^4_4 = -R4/2 + (3/8) eps phi^2 F2 - 6c;      mixed block: as at c = 0 (no c)
   identity  X^4_4 - (1/2) sum_a X^a_a = -(3/2)(box phi/phi - (eps/4) phi^2 F2 - 4c), so E_a(c) = 0 gives box phi = 4c phi + (eps/4) phi^3 F2
   k = -s on the base (1, -1, -1, -1, eps) for both eps, so c = -s kappa^2 at n = 5 as at n = 4.
 Reading: in the 4D block E_a(c) = 0 is G4 = Lambda_4 delta - eps (phi^2/2) T + scalar terms with Lambda_4 = 6c: the cosmological sign follows c, hence the
   square s of the sixth generator, and does not see eps; the Maxwell sign follows eps and does not see c.  Two generators, two independent signs.
 Controls: c = 0 gives the table of h4_kaluza_klein; a wrong eps in the e^4 part of the connection (its F-terms collapse to (eps/8) F2 delta: the traceless
   stress is gone, not flipped); wrong powers of phi; a Lambda term that follows eps,
   the opposite sign, the n = 4 value 3c, no Lambda term; the 44 slot without -6c; a Maxwell coefficient that depends on c; the opposite Maxwell sign;
   the scalar identity with 2c or -4c; the pp-wave, Reissner-Nordstrom and Schwarzschild-(anti-)de Sitter with a flat fibre as 5D solutions at c != 0; k = +s.
 Scope: values at the origin of polynomial frames (2-jets), n = 5, both eps, c in {0, 1/3, -1/2, 2} and a fresh c = -5/7; field equations only, no action."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib and the sibling steps), also under python3 -I
from b1lib import *
import h4_kaluza_klein as h4
from h4_kaluza_klein import N4, N5, ETA4, SQ5, kk_frame, std_G5, std4_pieces, rand_poly4, flat_constF, rn_frame, ppwave, blk, fit, fmt, lift, trunc_deg
from h3_sign_chain import std_lie_table

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
CS = [F(0), F(1, 3), F(-1, 2), F(2)]                 # the c values of the fits: zero and both signs
CFRESH = F(-5, 7)                                     # a c not used in any fit
KAPPA = F(1, 2); K2 = KAPPA ** 2
CTL = {}
def ctl_add(name, wrong, right, applicable=True):
    c = CTL.setdefault(name, [0, 0])
    if applicable: c[1] += 1; c[0] += int(wrong != right)
def delta(a, b): return 1 if a == b else 0

# ------------------------------------------------------------------------------------------------ [bit] and [std] at n = 5 with c
def engine_X(e, eps, cs):
    """[bit] X^h_a(c) (list [b][a], frame components) read off the engine's E_a(c) through E_a(c) = -X^h_a Theta_h, for every c in cs from one connection and one curvature;
    also omega, R and the Grav object"""
    sq = SQ5(eps); Lie_ = Lie(sq); Gv = Grav(N5, Lie_); S = koszul_S(N5, sq, Lie_)
    om, R = engine_om_R(Gv, e, S, N5)
    e0, E0, det = E0_of(e, N5, N5)
    X = {c: mixed_from_components(engine_E_from_R(Gv, e, R, N5, c), e0, det, N5, s=-1) for c in cs}
    return X, om, R, Gv
def X_of_R(Gv, e, R, c):
    """[bit] X(c) from a given curvature (used for the wrong connection of the control)"""
    e0, E0, det = E0_of(e, N5, N5)
    return mixed_from_components(engine_E_from_R(Gv, e, R, N5, c), e0, det, N5, s=-1)
def std_X(e, eps, c):
    """[std] G5 of g5 by the Christoffel route minus 6c delta, frame components"""
    G5 = std_G5(e, eps)
    return [[G5[b][a] - 6 * c * delta(a, b) for a in range(N5)] for b in range(N5)]
def predict_X(P, eps, c, kL=F(-6), Lpow=0, Leps=False, k44L=F(-6), **kw):
    """the reduction formula with the cosmological term (defaults = the claim); the keywords build the wrong versions used as controls:
    kL the coefficient of c delta in the 4D block, Lpow its power of phi, Leps whether it carries eps, k44L the coefficient of c in the 44 slot; **kw go to h4_kaluza_klein.predict_G5"""
    M = h4.predict_G5(P, eps, **kw); p = P['phi0']; lam = kL * c * p ** Lpow * (eps if Leps else 1)
    for a in range(N4): M[a][a] += lam
    M[N4][N4] += k44L * c
    return M
def torsion_is_zero(Gv, om, e):
    """[bit] the torsion d e^c + h omega^A e^b of the connection, every coefficient through x-degree 1 (reads the h table)"""
    with trunc(N5, xdeg=1): T = Gv.torsion(om, e)
    return all(v == 0 for t in T for p in t.values() for v in p.values())
def omega_fibre_flipped(om, Gv, A):
    """the wrong connection of the control: the e^4 part of omega^{ab} (a, b < 4) with the opposite sign: omega^{ab} - 2 Y (dy + A), Y the dy coefficient of omega^{ab}"""
    Fm = Gv.Fm; dyA = {1 << N4: const(N5, 1)}
    for mu in range(N4):
        p = lift(trunc_deg(A[mu], 2))
        if p: dyA[1 << mu] = p
    om_w = [dict(x) for x in om]
    with trunc(N5, xdeg=1):
        for A_, (a, b) in enumerate(pairs_of(Gv.L)):
            if b == N4: continue
            Y = om[A_].get(1 << N4, {})
            if Y: om_w[A_] = Fm.add(om[A_], Fm.wedge({0: Y}, dyA), -2)
    return om_w
def fibre_part_ok(om, Gv, P, eps):
    """[bit==std] the dy coefficient of omega^{ab} (a, b < 4) at the origin is -(eps/2) phi^2 F^{ab} (F^{ab} = eta^aa eta^bb F_ab from the 4D route)"""
    ok = True; p = P['phi0']
    for A_, (a, b) in enumerate(pairs_of(Gv.L)):
        if b == N4: continue
        ok &= at0(om[A_].get(1 << N4, {}), N5) == -F(eps, 2) * p * p * ETA4[a] * ETA4[b] * P['Ffr'][a][b]
    return ok

# ------------------------------------------------------------------------------------------------ exact fits
BX = ['G4', 'S', 'phi S', 'phi^2 S', 'delta F2', 'phi delta F2', 'phi^2 delta F2', 'Hess/phi', 'delta box/phi', 'grad grad/phi^2', 'delta |grad|^2/phi^2',
      'c delta', 'c phi delta', 'c phi^2 delta', 'c delta/phi', 'c phi^2 S', 'c phi^2 delta F2', 'c Hess/phi', 'c delta box/phi']
B44 = ['R4', 'F2', 'phi^2 F2', 'box/phi', '|grad|^2/phi^2', 'c', 'c phi^2', 'c/phi']
def rows_X4(P, X, c):
    """the 4D block of X(c) over the basis BX (the four coefficients: 4D Einstein, Maxwell, scalar, Lambda, with their powers of phi and the cross terms with c)"""
    p = P['phi0']; rows, rhs = [], []
    for b in range(N4):
        for a in range(N4):
            d = delta(a, b); S = P['S'][b][a]; H = P['H'][b][a]; F2 = P['F2']
            rows.append([P['G4'][b][a], S, p * S, p * p * S, d * F2, d * p * F2, d * p * p * F2, H / p, d * P['box'] / p, P['P'][b][a] / p ** 2, d * P['grad2'] / p ** 2,
                         c * d, c * p * d, c * p * p * d, c * d / p, c * p * p * S, c * d * p * p * F2, c * H / p, c * d * P['box'] / p])
            rhs.append(X[b][a])
    return rows, rhs
def rows_X44(P, X, c):
    p = P['phi0']; return [[P['R4'], P['F2'], p * p * P['F2'], P['box'] / p, P['grad2'] / p ** 2, c, c * p * p, c / p]], [X[N4][N4]]
def rows_4d(P, X):
    """h4_kaluza_klein's 4D-block rows (X - G4 over its basis B4) with one more column, delta: at fixed c its coefficient is the Lambda term"""
    r, h = h4.rows_4(P, X); rows = []; k = 0
    for b in range(N4):
        for a in range(N4): rows.append(r[k] + [F(delta(a, b))]); k += 1
    return rows, h

# ------------------------------------------------------------------------------------------------ special frames
def sds_frame(M, H2, pt=(F(1), F(2), F(2)), rho0=F(3)):
    """Kerr-Schild frame of C1 with f = M/rho + (H2/2) rho^2 (Schwarzschild-de Sitter for H2 > 0, anti-de Sitter for H2 < 0), 2-jets at pt"""
    f0, f1, f2 = sds_jets(M, H2, rho0); e4, _, _ = ks_frame_jet(pt, rho0, f0, f1, f2, nv=N4)
    return e4
def ratios(X, P, c):
    """the F-terms of the 4D block as multiples of T: the set of (X^b_a - G4^b_a + 6c delta)/T^b_a over T != 0, and whether the rest vanishes"""
    D = [[X[b][a] - P['G4'][b][a] + 6 * c * delta(a, b) for a in range(N4)] for b in range(N4)]
    rat = set(D[b][a] / P['T'][b][a] for b in range(N4) for a in range(N4) if P['T'][b][a] != 0)
    zer = all(D[b][a] == 0 for b in range(N4) for a in range(N4) if P['T'][b][a] == 0)
    return rat, zer

# ------------------------------------------------------------------------------------------------ one sign of eps
def run_eps(eps):
    head('eps = %+d  (sq = %s; the fibre squares like %s)' % (eps, SQ5(eps), 'space' if eps == -1 else 'time'))
    P0ok = True; nP0 = 0; conn_ok = True; nconn = 0; out = {}
    def frame(e4, A, phi, std5=True):
        nonlocal P0ok, nP0, conn_ok, nconn
        e = kk_frame(e4, A, phi); X, om, R, Gv = engine_X(e, eps, CS)
        if std5:
            for c in CS: P0ok &= (X[c] == std_X(e, eps, c)); nP0 += 1
        P = std4_pieces(e4, A, phi); conn_ok &= fibre_part_ok(om, Gv, P, eps); nconn += 1
        return e, P, X, om, R, Gv
    rng = random.Random(4100 + eps)
    # (a) phi = 1
    e4 = rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng) for _ in range(N4)]; phi = const(N4, 1)
    e, P, X, om, R, Gv = frame(e4, A, phi)
    G5h, _, _ = h4.engine_G5(e, eps)
    chk('bit', X[F(0)] == G5h, 'eps=%+d, phi = 1: X(0) read off E_a(0) equals the G5 of h4_kaluza_klein.engine_G5 in all 25 components (c = 0 is the reduction without cosmological term)' % eps)
    rr = {c: ratios(X[c], P, c) for c in CS}
    print('    phi = 1 frame: F2 = %s, T^0_0 = %s, G4^0_0 = %s;  X^0_0(c) = %s' % (P['F2'], P['T'][0][0], P['G4'][0][0], ', '.join('%s at c=%s' % (X[c][0][0], c) for c in CS)), flush=True)
    chk('bit==std', all(rr[c][0] == {F(eps, 2)} and rr[c][1] for c in CS),
        'eps=%+d, phi = 1: (X(c) - G4 + 6c delta)^b_a / T^b_a is the single value eps/2 = %s on every component with T != 0, for all c in %s (the Maxwell term does not see c)' % (eps, F(eps, 2), [str(c) for c in CS]))
    chk('bit', all(all(X[c][b][a] - X[F(0)][b][a] == -6 * c * delta(a, b) for a in range(N5) for b in range(N5)) for c in CS),
        'eps=%+d, phi = 1: X(c) - X(0) = -6c delta on all 25 components (4D block and fibre slot alike; the mixed block has no c)' % eps)
    frames = [(e, A, P, X, om, Gv)]
    # (b) constant phi != 1
    for p0 in (F(2), F(1, 3)):
        e4 = rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng) for _ in range(N4)]; phi = const(N4, p0)
        e, P, X, om, R, Gv = frame(e4, A, phi)
        chk('bit==std', all(X[c] == predict_X(P, eps, c) for c in CS),
            'eps=%+d, phi = %s (constant): X(c) = G4 + eps (phi^2/2) T - 6c delta in the 4D block, 44 and mixed slots as predicted, all c' % (eps, p0))
        frames.append((e, A, P, X, om, Gv))
    tick('eps=%+d: phi = 1 and constant phi' % eps)
    # (c) non-constant phi, then the exact fits over all frames and all c
    for p0 in (F(1), F(2), F(1, 2), F(3, 2)):
        e4 = rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng) for _ in range(N4)]; phi = rand_poly4(rng, 2, 1, .5, c0=p0)
        e, P, X, om, R, Gv = frame(e4, A, phi)
        frames.append((e, A, P, X, om, Gv))
    rows, rhs = [], []
    for e, A, P, X, om, Gv in frames:
        for c in CS: r, h = rows_X4(P, X[c], c); rows += r; rhs += h
    wX, rkX, nvX, consX = fit(rows, rhs)
    expX = [1, 0, 0, F(-eps, 2), 0, 0, F(eps, 8), -1, 1, 0, 0, -6, 0, 0, 0, 0, 0, 0, 0]
    print('    4D-block fit over %d frames x %d values of c (%d equations), basis %s:\n      coefficients %s' % (len(frames), len(CS), len(rows), BX, fmt(wX)), flush=True)
    chk('bit==std', consX and rkX == nvX and wX == expX,
        'eps=%+d: 4D block, exact fit: consistent, unique (rank %d of %d): G4: 1; Lambda term: -6 on c delta, 0 on c phi delta, c phi^2 delta, c delta/phi; Maxwell: -eps phi^2/2 on S, eps phi^2/8 on delta F2; scalar: -1 Hess/phi, +1 delta box/phi; no cross term c F, c Hess, c box' % (eps, rkX, nvX))
    out['wX'] = wX
    percs = {}
    for c in CS:
        rows, rhs = [], []
        for e, A, P, X, om, Gv in frames: r, h = rows_4d(P, X[c]); rows += r; rhs += h
        w, rk, nv, cons = fit(rows, rhs); percs[c] = (w, rk, nv, cons)
    print('    per-c fits (X - G4 over %s + [delta]):\n      ' % h4.B4 + '\n      '.join('c = %4s: %s' % (c, fmt(percs[c][0])) for c in CS), flush=True)
    chk('bit==std', all(percs[c][3] and percs[c][1] == percs[c][2] and percs[c][0] == [0, 0, F(-eps, 2), 0, 0, F(eps, 8), -1, 1, 0, 0, -6 * c] for c in CS),
        'eps=%+d: at each fixed c the delta coefficient of the 4D block is -6c (%s) and the other ten coefficients are those of c = 0, the table of h4_kaluza_klein' % (eps, ', '.join('%s -> %s' % (c, percs[c][0][10] if percs[c][0] else None) for c in CS)))
    out['lam'] = {c: (percs[c][0][10] if percs[c][0] else None) for c in CS}; out['maxw'] = {c: (percs[c][0][2] if percs[c][0] else None) for c in CS}
    rows, rhs = [], []
    for e, A, P, X, om, Gv in frames:
        for c in CS: r, h = rows_X44(P, X[c], c); rows += r; rhs += h
    w44, rk44, nv44, cons44 = fit(rows, rhs)
    print('    44 fit, basis %s: %s' % (B44, fmt(w44)), flush=True)
    chk('bit==std', cons44 and rk44 == nv44 and w44 == [F(-1, 2), 0, F(3 * eps, 8), 0, 0, -6, 0, 0],
        'eps=%+d: X^4_4 exact fit (rank %d of %d): -R4/2 + (3/8) eps phi^2 F2 - 6c; no box phi, (grad phi)^2, c phi^2 or c/phi term' % (eps, rk44, nv44))
    mix_ok = all(blk(X[c], 'mixed') == blk(X[F(0)], 'mixed') == blk(h4.predict_G5(P, eps), 'mixed') for e, A, P, X, om, Gv in frames for c in CS)
    chk('bit==std', mix_ok, 'eps=%+d: the mixed block of X(c) is the mixed block of X(0), = -(1/2) phi^-2 nabla_c(phi^3 F^c_a) and eps eta^aa times it, for all c and all %d frames' % (eps, len(frames)))
    id_ok = all(X[c][N4][N4] - sum(X[c][a][a] for a in range(N4)) / 2 == F(-3, 2) * (P['box'] / P['phi0'] - F(eps, 4) * P['phi0'] ** 2 * P['F2'] - 4 * c) for e, A, P, X, om, Gv in frames for c in CS)
    chk('bit==std', id_ok, 'eps=%+d: X^4_4 - (1/2) sum_a X^a_a = -(3/2)(box phi/phi - (eps/4) phi^2 F2 - 4c) on all frames and c: E_a(c) = 0 gives box phi = 4c phi + (eps/4) phi^3 F2, so a constant radius needs F2 = -16 eps c/phi^2' % eps)
    for e, A, P, X, om, Gv in frames:
        for c in CS:
            lhs = X[c][N4][N4] - sum(X[c][a][a] for a in range(N4)) / 2; base = P['box'] / P['phi0'] - F(eps, 4) * P['phi0'] ** 2 * P['F2']
            ctl_add('scalar identity with 2c in place of 4c', F(-3, 2) * (base - 2 * c), lhs, c != 0)
            ctl_add('scalar identity with -4c in place of 4c', F(-3, 2) * (base + 4 * c), lhs, c != 0)
    tick('eps=%+d: non-constant phi, fits' % eps)
    # (d) a fresh frame and a fresh c, then the controls on every frame
    rng2 = random.Random(5200 + eps)
    e4 = rand_frame(rng2, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng2) for _ in range(N4)]; phi = rand_poly4(rng2, 2, 1, .5, c0=F(5, 4))
    e = kk_frame(e4, A, phi); Xf, omf, Rf, Gvf = engine_X(e, eps, [CFRESH]); P = std4_pieces(e4, A, phi)
    chk('bit==std', Xf[CFRESH] == predict_X(P, eps, CFRESH) and Xf[CFRESH] == std_X(e, eps, CFRESH),
        'eps=%+d: fresh frame (seed not in the fit, phi(0) = 5/4, non-constant) at the fresh c = %s: the formula equals the engine in all 25 components, and so does the Christoffel route' % (eps, CFRESH))
    frames.append((e, A, P, {CFRESH: Xf[CFRESH]}, omf, Gvf))
    for e, A, P, X, om, Gv in frames:
        p = P['phi0']; Fn = P['F2'] != 0 or any(P['S'][b][a] for b in range(N4) for a in range(N4))
        for c, Xc in X.items():
            if c == 0: continue
            ctl_add('Lambda term following eps: -6 eps c delta (equal to the engine at eps = +1, seen at eps = -1)', predict_X(P, eps, c, Leps=True), Xc, eps == -1)
            ctl_add('Lambda term following eps: +6 eps c delta (equal to the engine at eps = -1, seen at eps = +1)', predict_X(P, eps, c, kL=F(6), Leps=True), Xc, eps == 1)
            ctl_add('Lambda term with the opposite sign: +6c delta', predict_X(P, eps, c, kL=F(6)), Xc)
            ctl_add('Lambda term with the n = 4 value: -3c delta', predict_X(P, eps, c, kL=F(-3)), Xc)
            ctl_add('no Lambda term (the c = 0 formula at c != 0)', predict_X(P, eps, c, kL=F(0), k44L=F(0)), Xc)
            ctl_add('Lambda term with phi^1: -6c phi delta', predict_X(P, eps, c, Lpow=1), Xc, p != 1)
            ctl_add('Lambda term with phi^2: -6c phi^2 delta', predict_X(P, eps, c, Lpow=2), Xc, p != 1)
            ctl_add('44 slot without the -6c', predict_X(P, eps, c, k44L=F(0)), Xc)
            ctl_add('Maxwell coefficient depending on c: eps (phi^2/2)(1 + c) T', predict_X(P, eps, c, kT=F(eps) * p ** 2 * (1 + c) / 2), Xc, Fn)
            ctl_add('opposite Maxwell sign at c != 0: G4 - eps (phi^2/2) T - 6c delta', predict_X(P, eps, c, kT=F(-eps) * p ** 2 / 2), Xc, Fn)
            ctl_add('phi^1 instead of phi^2 in the Maxwell terms at c != 0', predict_X(P, eps, c, phipow=1), Xc, Fn and p != 1)
    tick('eps=%+d: fresh frame, controls' % eps)
    # (e) the wrong eps in the connection: the e^4 part of omega^{ab} flipped
    chk('bit==std', conn_ok, 'eps=%+d: the dy coefficient of the engine\'s omega^{ab} (a, b < 4) is -(eps/2) phi^2 F^{ab} on all %d frames (the e^4 part of the connection is -(eps/2) phi F^{ab} e^4)' % (eps, nconn))
    wrong = 0; seen = 0; tors_ok = True; rows, rhs = [], []; w44ok = True
    for e, A, P, X, om, Gv in frames[:1] + frames[3:4]:
        om_w = omega_fibre_flipped(om, Gv, A)
        with trunc(N5, xdeg=1): R_w = Gv.curvature(om_w)
        tors_ok &= torsion_is_zero(Gv, om, e) and not torsion_is_zero(Gv, om_w, e)
        for c in (F(0), F(1, 3)):
            X_w = X_of_R(Gv, e, R_w, c); seen += 1; wrong += int(X_w != X[c])
    for Fl in ({(0, 1): 3}, {(1, 2): -2}, {(0, 1): 1, (1, 3): 2}, {(0, 2): 1, (1, 2): 3, (0, 3): -2}):
        e4, A = flat_constF(Fl); e = kk_frame(e4, A, const(N4, 1)); P = std4_pieces(e4, A, const(N4, 1))
        X, om, R, Gv = engine_X(e, eps, [F(0), F(1, 3)]); om_w = omega_fibre_flipped(om, Gv, A)
        with trunc(N5, xdeg=1): R_w = Gv.curvature(om_w)
        tors_ok &= torsion_is_zero(Gv, om, e) and not torsion_is_zero(Gv, om_w, e)
        for c in (F(0), F(1, 3)):
            X_w = X_of_R(Gv, e, R_w, c); seen += 1; wrong += int(X_w != X[c])
            if c == 0:
                for b in range(N4):
                    for a in range(N4): rows.append([P['S'][b][a], delta(a, b) * P['F2']]); rhs.append(X_w[b][a])
                w44ok &= X_w[N4][N4] == -F(eps, 8) * P['F2'] and not any(blk(X_w, 'mixed'))
    ww, rkw, nvw, consw = fit(rows, rhs)
    chk('bit', tors_ok, 'eps=%+d: the closed-form connection has zero torsion through x-degree 1 and the connection with the flipped e^4 part has torsion != 0 (6 frames)' % eps)
    chk('ctl', wrong == seen and seen > 0, '"wrong eps in the connection: the e^4 part of omega^{ab} flipped" differs from the engine on %d of %d samples (c = 0 and c != 0)' % (wrong, seen))
    chk('bit', consw and rkw == nvw and ww == [0, F(eps, 8)] and w44ok,
        'eps=%+d: with the flipped e^4 part, on 4 flat frames with constant F (phi = 1, G4 = 0) the F-terms of the 4D block fit exactly to %s over [S, F2 delta]: the traceless part -(eps/2) S of the stress eps T/2 is gone and its trace part (eps/8) F2 delta stays; the 44 slot is -(eps/8) F2 in place of (3/8) eps F2, mixed 0' % (eps, fmt(ww)))
    out['ww'] = ww
    tick('eps=%+d: wrong connection' % eps)
    # (f) special frames at every c: flat with constant F, pp-wave, Reissner-Nordstrom, Schwarzschild-(anti-)de Sitter with a flat fibre
    kap = {}
    for name, Fl, T00 in (('pure electric E_x = 3', {(0, 1): 3}, F(9, 2)), ('pure magnetic B_z = 2', {(1, 2): -2}, F(2))):
        e4, A = flat_constF(Fl); P = std4_pieces(e4, A, const(N4, 1)); e = kk_frame(e4, A, const(N4, 1)); X, om, R, Gv = engine_X(e, eps, CS)
        chk('std', P['T'][0][0] == T00 and P['G4'] == [[0] * N4 for _ in range(N4)], 'eps=%+d, %s: T^0_0 = %s > 0 (positive energy), G4 = 0' % (eps, name, T00))
        kap[name] = set(-(X[c][0][0] + 6 * c) / T00 for c in CS)
        chk('bit', all(X[c][0][0] == F(eps) * T00 / 2 - 6 * c for c in CS) and all(X[c][b][a] - X[F(0)][b][a] == -6 * c * delta(a, b) for c in CS for a in range(N5) for b in range(N5)),
            'eps=%+d, %s: X^0_0(c) = eps T^0_0/2 - 6c for all c (%s): the Maxwell part is eps T^0_0/2 at every c, kappa_eff = %s; the cosmological part is -6c delta at this eps' % (eps, name, ', '.join('%s at c=%s' % (X[c][0][0], c) for c in CS), sorted(map(str, kap[name]))))
    e4, A = ppwave(eps); P = std4_pieces(e4, A, const(N4, 1)); e = kk_frame(e4, A, const(N4, 1)); X, om, R, Gv = engine_X(e, eps, CS)
    chk('bit', all(X[c] == [[-6 * c * delta(a, b) for a in range(N5)] for b in range(N5)] for c in CS),
        'eps=%+d, pp-wave with a null field, phi = 1: X(c) = -6c delta for all c: a 5D solution at c = 0 only (E_a(c) = 6c Theta_a there)' % eps)
    for c in CS: ctl_add('pp-wave with phi = 1 as a 5D solution at c != 0', [[F(0)] * N5 for _ in range(N5)], X[c], c != 0)
    e4, A, q, rho0 = rn_frame(eps); P = std4_pieces(e4, A, const(N4, 1)); e = kk_frame(e4, A, const(N4, 1)); X, om, R, Gv = engine_X(e, eps, CS)
    v44 = F(-3 * eps) * q ** 2 / rho0 ** 4
    chk('bit', all(blk(X[c], '4D') == [[-6 * c * delta(a, b) for a in range(N4)] for b in range(N4)] and not any(blk(X[c], 'mixed')) and X[c][N4][N4] == v44 - 6 * c for c in CS),
        'eps=%+d, %s with phi = 1: 4D block -6c delta, mixed 0, X^4_4 = -3 eps q^2/rho^4 - 6c for all c: the 44 slot vanishes only at c = -eps q^2/(2 rho^4) and the 4D block only at c = 0, no 5D solution for any c' % (eps, 'Reissner-Nordstrom' if eps == -1 else 'its twin'))
    for c in CS: ctl_add('Reissner-Nordstrom (or its twin) with phi = 1 as a 5D solution at c != 0', [[F(0)] * N5 for _ in range(N5)], X[c], c != 0)
    sds_ok = True; sds_std = True; nsds = 0; A0 = [{} for _ in range(N4)]
    for c in (F(1, 3), F(-1, 2)):
        for H2 in (2 * c, c):
            e4 = sds_frame(F(1, 3), H2); P = std4_pieces(e4, A0, const(N4, 1)); e = kk_frame(e4, A0, const(N4, 1)); X, om, R, Gv = engine_X(e, eps, [c]); nsds += 1
            sds_std &= P['G4'] == [[3 * H2 * delta(a, b) for a in range(N4)] for b in range(N4)] and P['R4'] == -12 * H2 and P['F2'] == 0
            z4 = all(x == 0 for row in blk(X[c], '4D') for x in row); z44 = X[c][N4][N4] == 0
            sds_ok &= (z4 == (H2 == 2 * c)) and (z44 == (H2 == c)) and not any(blk(X[c], 'mixed'))
            ctl_add('Schwarzschild-(anti-)de Sitter with a flat fibre as a 5D solution at c != 0', [[F(0)] * N5 for _ in range(N5)], X[c])
    chk('std', sds_std, 'eps=%+d: Schwarzschild-(anti-)de Sitter f = M/rho + (H2/2) rho^2 (M = 1/3) at |p| = 3: G4 = 3 H2 delta, R4 = -12 H2 (Christoffel route), %d frames' % (eps, nsds))
    chk('bit', sds_ok, 'eps=%+d: with a flat fibre (phi = 1, A = 0) the 4D block of X(c) vanishes iff H2 = 2c and the fibre slot iff H2 = c (c = 1/3, -1/2): no c != 0 makes the product a 5D solution; a constant radius with c != 0 needs flux' % eps)
    chk('bit==std', P0ok, 'eps=%+d: (P0) E_a(c) = -(G5^h_a - 6c delta^h_a) Theta_h with G5 the Einstein tensor of g5 by the Christoffel route, all 25 components, %d (frame, c) pairs: the engine\'s c is Lambda_5/6 at n = 5' % (eps, nP0))
    tick('eps=%+d: special frames' % eps)
    out['kap'] = kap
    return out

# ------------------------------------------------------------------------------------------------ the sixth generator: k = -s on the 5-generator base
def sixth_generator():
    head('the sixth generator: the algebra of six generators (1, -1, -1, -1, eps, s); the curvature of the extended connection is (R^{ab} + k kappa^2 e^a e^b, kappa T^a)')
    ks = {}
    for eps in (-1, 1):
        for s in (-1, 0, 1):
            sqx = SQ5(eps) + [s]; Lx = Lie(sqx); fstd = std_lie_table(sqx)
            same = ({k: (c, F(v)) for k, (c, v) in Lx.f.items()} == {k: (c, F(v)) for k, (c, v) in fstd.items()})
            chk('bit==std', same, 'eps=%+d, s=%+d: the engine\'s structure constants of the %d bivectors equal those of the matrix algebra so(p, q) (%d x %d pairs)' % (eps, s, Lx.G, Lx.G, Lx.G))
            try: k_b, mu_b = embed_k(SQ5(eps), s, KAPPA, 7 + s)
            except AssertionError as ex: k_b, mu_b = None, str(ex)
            iA = Lx.idx[(1 << 0) | (1 << N5)]; iB = Lx.idx[(1 << 1) | (1 << N5)]
            fa, fb = fstd.get((iA, iB)), fstd.get((iB, iA)); k_s = F((fa[1] if fa else 0) - (fb[1] if fb else 0), 4)
            chk('bit', k_b == -s and mu_b == KAPPA, 'eps=%+d, s=%+d: engine curvature of the extended connection on the 5-generator base: k = %s, torsion coefficient mu = %s (expected -s = %d, kappa = %s)' % (eps, s, k_b, mu_b, -s, KAPPA))
            chk('std', k_s == -s, 'eps=%+d, s=%+d: from the matrix commutator [L_aE, L_bE] = -eta_EE L_ab: k = %s' % (eps, s, k_s))
            ctl_add('k = +s (wrong sign of k)', F(s), k_b, s != 0)
            ks[(eps, s)] = k_b
    chk('bit', all(ks[(eps, s)] == -s for eps in (-1, 1) for s in (-1, 0, 1)), 'k = -s for both eps: the sign of c = k kappa^2 follows the square of the sixth generator and does not see the square of the fibre generator')
    tick('sixth generator')
    return ks

def main():
    head('H4-cosmological  Kaluza-Klein at n = 5 with the cosmological term c in E_a(c): e^a = e4^a(x), e^4 = phi(x)(dy + A(x)), fibre generator of square eps; exact, at the origin of polynomial 2-jets')
    res = {eps: run_eps(eps) for eps in (-1, 1)}
    ks = sixth_generator()
    head('two signs')
    lam = {eps: res[eps]['wX'][11] if res[eps]['wX'] else None for eps in res}
    chk('bit', lam[-1] is not None and lam[-1] == lam[1] == -6, 'the coefficient of c delta in the 4D block is %s at eps = -1 and %s at eps = +1: Lambda_4 = 6c at both eps; the cosmological sign does not see the fibre square' % (lam[-1], lam[1]))
    chk('bit', all(res[eps]['lam'][c] == -6 * c for eps in res for c in CS), 'at each fixed c the Lambda term of the 4D block is -6c for both eps: ' + '; '.join('c=%s: %s' % (c, [str(res[eps]['lam'][c]) for eps in (-1, 1)]) for c in CS))
    wXok = all(res[eps]['wX'] for eps in res)
    chk('bit', all(res[eps]['maxw'][c] == F(-eps, 2) for eps in res for c in CS) and wXok and res[-1]['wX'][15] == res[1]['wX'][15] == 0,
        'the coefficient of phi^2 S is -eps/2 at every c (%s at eps = -1, %s at eps = +1) and the cross term c phi^2 S is 0: the Maxwell sign follows eps and does not see c' % (sorted(set(map(str, res[-1]['maxw'].values()))), sorted(set(map(str, res[1]['maxw'].values())))))
    chk('bit', wXok and res[-1]['wX'][7:11] == res[1]['wX'][7:11] == [-1, 1, 0, 0] and res[-1]['wX'][17:] == res[1]['wX'][17:] == [0, 0], 'the scalar terms (-1 Hess/phi, +1 delta box/phi, no (grad phi)^2) are the same at both eps and carry no c')
    kp = {eps: set().union(*res[eps]['kap'].values()) for eps in res}
    chk('bit', kp[-1] == {F(1, 2)} and kp[1] == {F(-1, 2)}, 'kappa_eff = -eps/2 at phi = 1 for every c: %s at eps = -1 (positive energy), %s at eps = +1 (a ghost); c does not enter' % (sorted(map(str, kp[-1])), sorted(map(str, kp[1]))))
    pairs = {}
    for s in (-1, 1):
        for eps in (-1, 1):
            Lam4 = 6 * (ks[(eps, s)] if ks[(eps, s)] is not None else 0) * K2; keff = -F(eps) / 2
            pairs[(s, eps)] = (1 if Lam4 > 0 else -1 if Lam4 < 0 else 0, 1 if keff > 0 else -1)
            print('    sixth generator s=%+d, fibre eps=%+d:  Lambda_4 = 6 k kappa^2 = %5s (%s),  kappa_eff = %4s (%s)' % (s, eps, Lam4, 'de Sitter' if Lam4 > 0 else 'anti-de Sitter', keff, 'positive energy' if keff > 0 else 'ghost'), flush=True)
    chk('bit', set(pairs.values()) == {(1, 1), (1, -1), (-1, 1), (-1, -1)} and all(pairs[(s, eps)] == (-s, -eps) for s in (-1, 1) for eps in (-1, 1)),
        'all four sign pairs occur: sign Lambda_4 = -s (the sixth generator), sign kappa_eff = -eps (the fifth); a generator that squares like space gives de Sitter and gives positive Maxwell energy, and nothing in the reduction ties the two')
    chk('bit', res[-1]['ww'] == [0, F(-1, 8)] and res[1]['ww'] == [0, F(1, 8)],
        'a wrong eps in the e^4 part of the connection does not give the opposite Maxwell sign: the F-terms of the 4D block become (eps/8) F2 delta with no S term, at both eps; the stress eps T/2 needs the e^4 part of omega^{ab} and the commutator [B_a4, B_b4] with the same eps')
    head('controls (a wrong version must differ from the engine on every sample where it can be seen)')
    for name, (dif, seen) in CTL.items():
        chk('ctl', dif == seen and seen > 0, '"%s" differs from the engine on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('H4-cosmological')
if __name__ == '__main__': main()
