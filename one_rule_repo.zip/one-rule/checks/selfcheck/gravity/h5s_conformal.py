#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H5 (S part).  Conformal scaling e -> Omega e: the Weyl part of the engine's curvature scales by Omega^-2 in frame components (the Weyl 2-form is invariant), the
 Petrov type is conformally invariant, the Ricci part obeys the inhomogeneous law (Wald D.8, recalled), constant Omega gives the homogeneous law for both, and the null cone
 is the conformal class.      python3 h5s_conformal.py
 [bit]  omega' = A3's closed form of Omega e (exact 2-jets at the point), R' = engine curvature, Weyl / Ricci parts by g2_weyl.weyl_parts, Q and type in Q(i).
 [std]  the Riemann tensor of g' = Omega^2 g by the Christoffel route (exact), the Christoffel symbols of g for nabla nabla ln Omega, the metric at the point.
 Controls: Omega^-1 instead of Omega^-2; the Ricci part is not homogeneous for non-constant Omega; the coefficient (n-1) instead of (n-2) in the inhomogeneous law."""
import time, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from g2_weyl import *

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def ks(pt, rho, M, H2): return ks_frame_jet(pt, rho, *sds_jets(M, H2, rho))[0]

def rescale(e, Om, n=4):
    """e' = Omega e as exact 2-jets (products truncated at x-degree 2: exact for the curvature at the origin)"""
    out = []
    for form in e:
        f2 = {}
        for m, p in form.items():
            q = jet(pm(Om, p), n, 2)
            if q: f2[m] = q
        out.append(f2)
    return out
def poly4(terms):
    """{(exponents): coefficient} from a list of (coefficient, exponent tuple)"""
    return {tuple(ex): F(c) for c, ex in terms if c}
OMEGA_A = poly4([(2, (0, 0, 0, 0)), (1, (1, 0, 0, 0)), (2, (0, 1, 0, 0)), (-1, (0, 0, 1, 0)), (1, (1, 1, 0, 0)), (1, (0, 0, 2, 0)), (-1, (1, 0, 0, 1)), (F(1, 2), (0, 0, 0, 1))])
OMEGA_B = poly4([(F(3, 2), (0, 0, 0, 0)), (-1, (1, 0, 0, 0)), (1, (0, 0, 1, 0)), (2, (0, 0, 0, 1)), (1, (2, 0, 0, 0)), (-1, (0, 1, 1, 0)), (1, (0, 0, 1, 1)), (F(1, 3), (0, 1, 0, 0))])
OMEGA_C = poly4([(F(3, 2), (0, 0, 0, 0))])                                   # constant

def christoffel0(g, n=4, nv=4):
    """[std] Gamma^l_{mu nu} at the origin from the metric jet (own loops)"""
    gi, g0, g0i = std_inverse_metric(g, n, nv, 0); dg = lambda k, a, b: at0(sp_der(g[(a, b)], k), nv)
    return {(l, m, v): sum(F(1, 2) * g0i[l][s] * (dg(m, s, v) + dg(v, s, m) - dg(s, m, v)) for s in range(n)) for l in range(n) for m in range(n) for v in range(n)}, g0, g0i
def coord_ricci(Ric, e0, n=4): return [[sum(Ric[(b, d)] * e0[b][mu] * e0[d][nu] for b in range(n) for d in range(n)) for nu in range(n)] for mu in range(n)]
def weyl_2form(C, e0, sq, n=4):
    """coordinate components C^{ab}_{mu nu} = sq_a sq_b C_{abcd} e^c_mu e^d_nu"""
    return {(a, b, mu, nu): sq[a] * sq[b] * sum(C[(a, b, c, d)] * e0[c][mu] * e0[d][nu] for c in range(n) for d in range(n)) for a in range(n) for b in range(n) for mu in range(n) for nu in range(n)}

def run_frame(name, e, Om, Gv, S, sq, expect, constant=False):
    n = 4; Om0 = at0(Om, n); k = Om0 ** -2
    Rl, om, R = engine_frame_riemann(Gv, e, S); C, Ric, Rs, tf = weyl_parts(Rl, sq)
    e2 = rescale(e, Om); Rl2, om2, R2 = engine_frame_riemann(Gv, e2, S); C2, Ric2, Rs2, tf2 = weyl_parts(Rl2, sq)
    with trunc(n, xdeg=0): tz = torsion_zero_at0(Gv, om2, e2, n)
    e0 = E0_of(e, n, n)[0]; e20 = E0_of(e2, n, n)[0]; nzW = any(v != 0 for v in C.values())
    chk('bit', tz and pair_symmetric(Rl2), '%s: T = 0 at the point for Omega e (A3) and pair symmetry of R\'' % name)
    chk('bit', all(C2[key] == k * C[key] for key in C), '%s: Weyl\'_{abcd} = Omega0^-2 Weyl_{abcd} in frame components, Omega0 = %s%s' % (name, Om0, '' if nzW else ' (both zero: conformally flat stays conformally flat)'))
    chk('bit', weyl_2form(C2, e20, sq) == weyl_2form(C, e0, sq), '%s: the Weyl 2-form C^{ab} = (1/2) C^{ab}_{cd} e^c e^d has the same coordinate components (invariant)' % name)
    Q, Q2 = complex_Q(C), complex_Q(C2); t, I2, I3, _ = petrov(Q); t2, I22, I32, _ = petrov(Q2)
    chk('bit', t == expect and t2 == t and I22 == I2 * k ** 2 and I32 == I3 * k ** 3, '%s: Petrov type %s unchanged; I2, I3 scale by Omega0^-4, Omega0^-6' % (name, t))
    hom_ric = all(tf2[key] == k * tf[key] for key in tf) and Rs2 == k * Rs
    if constant:
        chk('bit', hom_ric, '%s: constant Omega: trace-free Ricci and scalar also scale by Omega^-2 (homogeneous law for both parts)' % name)
    else:
        chk('ctl', not hom_ric, '%s: non-constant Omega: the Ricci part does NOT scale by Omega0^-2 (trace-free %s, scalar %s): ok = the control fails the homogeneous law' % (name, 'differs' if any(tf2[key] != k * tf[key] for key in tf) else 'same', 'differs' if Rs2 != k * Rs else 'same'))
        # Wald D.8 in coordinate components, w = ln Omega  [std: Christoffel symbols of g]
        g = std_metric(e, n, sq, n, 2); Gam, g0, g0i = christoffel0(g)
        dOm = [at0(sp_der(Om, mu), n) for mu in range(n)]; ddOm = [[at0(sp_der(sp_der(Om, mu), nu), n) for nu in range(n)] for mu in range(n)]
        dw = [x / Om0 for x in dOm]; ddw = [[ddOm[m][v] / Om0 - dOm[m] * dOm[v] / Om0 ** 2 for v in range(n)] for m in range(n)]
        nn = [[ddw[m][v] - sum(Gam[(l, m, v)] * dw[l] for l in range(n)) for v in range(n)] for m in range(n)]
        box = sum(g0i[m][v] * nn[m][v] for m in range(n) for v in range(n)); grad2 = sum(g0i[m][v] * dw[m] * dw[v] for m in range(n) for v in range(n))
        Rc, Rc2 = coord_ricci(Ric, e0), coord_ricci(Ric2, e20)
        rhs = lambda cf: [[Rc[m][v] - cf * nn[m][v] - g0[m][v] * box + cf * dw[m] * dw[v] - cf * g0[m][v] * grad2 for v in range(n)] for m in range(n)]
        chk('bit==std', Rc2 == rhs(2), '%s: Ric\'_{mu nu} = Ric - 2 nabla nabla w - g box w + 2 dw dw - 2 g |dw|^2 (w = ln Omega; Wald D.8, n = 4) exact, Ric and Ric\' from the engine, nabla from the Christoffel symbols of g' % name)
        chk('ctl', Rc2 != rhs(3), '%s: the same law with coefficient 3 = n - 1 fails (ok)' % name)
        if nzW: chk('ctl', not all(C2[key] == C[key] / Om0 for key in C), '%s: Omega0^-1 instead of Omega0^-2 fails for the Weyl part (ok)' % name)
    # [std] the Weyl law from the metric alone
    Cs = weyl_parts(std_frame_riemann(e, n, sq), sq)[0]; Cs2 = weyl_parts(std_frame_riemann(e2, n, sq), sq)[0]
    chk('bit==std', Cs2 == C2 and Cs == C and all(Cs2[key] == k * Cs[key] for key in Cs), '%s: Christoffel route on g and Omega^2 g: same Weyl tensors as the engine and the same Omega0^-2 law' % name)
    return dict(C=C, C2=C2, Om0=Om0, e0=e0, e20=e20)

def null_cone(name, e, Om, sq):
    n = 4; Om0 = at0(Om, n); e2 = rescale(e, Om); e0, E0, det = E0_of(e, n, n); e20 = E0_of(e2, n, n)[0]
    g0 = [[sum(sq[a] * e0[a][m] * e0[a][v] for a in range(n)) for v in range(n)] for m in range(n)]
    g20 = [[sum(sq[a] * e20[a][m] * e20[a][v] for a in range(n)) for v in range(n)] for m in range(n)]
    q = lambda g, v: sum(g[m][k] * v[m] * v[k] for m in range(n) for k in range(n))
    rng = random.Random(17); vs = [[F(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(n)] for _ in range(4)]
    ok = all(g20[m][v] == Om0 ** 2 * g0[m][v] for m in range(n) for v in range(n)) and all(q(g20, v) == Om0 ** 2 * q(g, v) for v in vs for g in (g0,))
    nulls = [[E0[m][a] for m in range(n)] for a in range(1)]                                   # placeholder shape
    nulls = []
    for na in ((1, 1, 0, 0), (5, 3, 4, 0), (13, 3, 4, 12)):
        v = [sum(E0[m][a] * na[a] for a in range(n)) for m in range(n)]; nulls.append(v)
    ok2 = all(q(g0, v) == 0 and q(g20, v) == 0 for v in nulls)
    chk('std', ok and ok2, '%s: g\' = Omega0^2 g at the point (exact), g\'(v, v) = Omega0^2 g(v, v) on random rational v, three null vectors of g are null for g\': the null cone is the conformal class' % name)

def main():
    head('H5S  e -> Omega e on random, Schwarzschild, FRW, plane-wave and flat frames (Lorentz (+,-,-,-), exact 2-jets at the point)')
    Gv, S, sq = lorentz_setup(); rng = random.Random(21)
    frames = []
    for k in range(3): frames.append(('random frame %d' % k, rand_frame(rng, 4, deg=2, coef=2, density=.5), 'I', OMEGA_A if k % 2 == 0 else OMEGA_B))
    frames.append(('Schwarzschild M = 1, rho = 7', ks((F(2), F(3), F(6)), F(7), F(1), F(0)), 'D', OMEGA_A))
    frames.append(('Schwarzschild M = 1, rho = 3', ks((F(1), F(2), F(2)), F(3), F(1), F(0)), 'D', OMEGA_B))
    frames.append(('SdS M = 1, H2 = 1/5, rho = 7', ks((F(2), F(3), F(6)), F(7), F(1), F(1, 5)), 'D', OMEGA_B))
    frames.append(('FRW a = 1 + t + t^2', frw_frame((1, 1, 1)), 'O', OMEGA_A))
    frames.append(('plane wave', pw_frame(pw_global((1, 2, -1, 3), (2, 0, 1)), random_rational_point(rng)), 'N', OMEGA_B))
    frames.append(('flat', flat_frame(), 'O', OMEGA_A))
    for name, e, typ, Om in frames:
        run_frame(name, e, Om, Gv, S, sq, typ); tick(name)
    head('constant Omega = 3/2: the homogeneous law for both parts')
    for name, e, typ, Om in (frames[0], frames[3], frames[6]): run_frame(name + ' (constant Omega)', e, OMEGA_C, Gv, S, sq, typ, constant=True)
    tick('constant Omega')
    head('the null cone [std]')
    for name, e, typ, Om in (frames[1], frames[3], frames[7]): null_cone(name, e, Om, sq)
    tick('null cone')
    finish('H5S')
if __name__ == '__main__': main()
