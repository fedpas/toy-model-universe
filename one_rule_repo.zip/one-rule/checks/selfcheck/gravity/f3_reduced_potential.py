#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F3-reduced.  The null-surface paper's reduced potential T = S + M_phi^2/Phi on the Kerr-Schild frame (M = 5, a = 3): its zero set, and what half its
 gradient gives on the horizons.   python3 f3_reduced_potential.py

 Object   Hsu, Barker, Hobson, Lasenby (null surfaces), Eq. (24): T = S + M_phi^2/Phi for ds^2 = S dt^2 + 2 M_phi dt dphi - R dr^2 - Theta dth^2 - Phi dphi^2.
          Read here from the Killing fields xi = d_t and psi = x d_y - y d_x (t and phi are Killing coordinates of both the Boyer-Lindquist and the Kerr-Schild
          chart): S = <xi, xi>, M_phi = <xi, psi>, Phi = -<psi, psi>, so T = <xi, xi> - <xi, psi>^2/<psi, psi> = |xi + w psi|^2 with w = -<xi, psi>/<psi, psi>.
          On the axis (psi = 0) T is the limit <xi, xi>: M_phi and Phi vanish there with their first derivatives (checked on the jets).
 Frame    C2's coframe (g2_kerr.kerr_ks_frame_jet), exact 2-jets at rational points x = sin th (r cos ph - a sin ph), y = sin th (r sin ph + a cos ph), z = r cos th:
          the horizons r = 9 and r = 1 (six angles each, the axis included) and r = 20, 10, 19/2, 7, 4, 2, 1/2, 1/5 (equator and generic angles).
 [bit]    frame components of xi and psi (interior products with the coframe jets), inner products as bit-rule squares (polarisation), T as an exact 2-jet,
          dT by the engine's d; kH and Omega_H by C2/F2's route (double root of |d_t + Omega d_phi|^2, nabla_chi chi = kH chi with the A3 omega);
          chi_flat = sum_a sq_a chi^a e^a; g^-1(dr, dr) from the inverse frame and a bit-rule square.
 [std]    the metric matrix g = e^T eta e (plain polynomials): T from its (t, phi) block, d_mu T by derivatives of the jets; the Christoffel route for
          nabla_chi chi; the recalled Boyer-Lindquist closed form T = Delta Sigma/A (Sigma = r^2 + a^2 cos^2 th, Delta = r^2 - 2Mr + a^2,
          A = (r^2 + a^2)^2 - Delta a^2 sin^2 th) and its r-derivative; floats from the closed-form metric (g2_kerr.float_metric): T, five-point differences
          along r, a sign-change scan of T along r in (0, 30] at seven angles, the ergosurface, and the paper's EF-like coordinate dr~ = sqrt(T R) dr near r = 9.
 Results  T = 0 exactly on r = 9 and r = 1 and at no other checked point; A = (r^2 + a^2) Sigma + 2 M r a^2 sin^2 th > 0 for r > 0, so on the chart T = 0
          only where Delta = 0.  On the horizons (1/2) dT = -kH chi_flat (all four components).  The literal recipe (1/2) d_r T at fixed angles is
          kH Sigma/(r^2 + a^2): kH on the axis only.  (1/2) dT/dr~ = kH at every angle, with g^rr = -Delta/Sigma and T R = Sigma^2/A.
 [ctl]    g_tt = 0 (the ergosurface r = 10 on the equator) is not a zero of T; the closed form of another member ((M, a) = (5, 4), (6, 3)) and the (5, 4) frame;
          (1/2) dT = +kH chi_flat; kH of the other horizon; Omega of the other horizon in chi.
 Scope    the paper's recipe applied to this frame (M = 5, a = 3, the Kerr-Schild chart r > 0) at points; not the paper's general statement.
 Exports  reduced_T_jets(e, p), dT_engine(Gv, Tj), chi_flat(e, ca), closed_T(M, a, r, c2), closed_dT_dr(M, a, r, c2)"""
import sys, os, time, math
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from b1lib import *
import numpy as np
import g2_kerr as K
from f2_first_law import prop

NV = 4; SQ = LORENTZ(4); T0 = time.time()
M0, A0 = F(5), F(3)
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
ANG = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(0), F(1)), (F(1), F(0))), ((F(-5, 13), F(12, 13)), (F(-8, 17), F(15, 17))), ((F(12, 13), F(5, 13)), (F(0), F(1))),
       ((F(8, 17), F(15, 17)), (F(3, 5), F(-4, 5)))]
AXIS = [((F(1), F(0)), (F(1), F(0))), ((F(-1), F(0)), (F(1), F(0)))]
EQ = [((F(0), F(1)), (F(1), F(0))), ((F(0), F(1)), (F(3, 5), F(4, 5)))]
def tdeg(p, d=2): return {k: v for k, v in p.items() if sum(k) <= d and v != 0}
def lin1(p, i): return p.get(tuple(1 if j == i else 0 for j in range(NV)), F(0))

# ------------------------------------------------------------------------------------------------ [bit] the reduced potential from the frame
def _sq(vs):
    """scalar part of the bit-rule square (sum v^A gamma_A)^2 for jets v^A, truncated at degree 2"""
    return tdeg(clifford_square(SQ, {A: q for A, q in enumerate(vs) if q}, NV).get(0, {}))
def reduced_T_jets(e, p):
    """frame components of xi = d_t and psi = x d_y - y d_x (2-jets) and the jets tt = <xi,xi>, tf = <xi,psi>, ff = <psi,psi> (bit-rule squares, polarisation);
    T = tt - tf^2/ff as a 2-jet when ff(p) != 0, else None (the axis)"""
    xa = K.engine_vector_at0(e, K.d_t(p)); pa = K.engine_vector_at0(e, K.d_phi(p))
    tt, ff = _sq(xa), _sq(pa); tf = tdeg(scale(lin((F(1), _sq([padd(x, y) for x, y in zip(xa, pa)])), (F(-1), tt), (F(-1), ff)), F(1, 2)))
    Tj = tdeg(lin((F(1), tt), (F(-1), K._jm(K._jm(tf, tf), K.recip2(ff))))) if at0(ff, NV) != 0 else None
    return dict(tt=tt, tf=tf, ff=ff, T=Tj, xa=xa, pa=pa)
def dT_engine(Gv, Tj):
    """[bit] (d T)_mu at the point with the engine's d"""
    d = Gv.Fm.d({0: Tj}); return [at0(d.get(1 << mu, {}), NV) for mu in range(NV)]
def chi_flat(e, ca):
    """chi_mu = sum_a sq_a chi^a e^a_mu at the point (frame values)"""
    return [sum(SQ[A] * ca[A] * at0(e[A].get(1 << mu, {}), NV) for A in range(NV)) for mu in range(NV)]

# ------------------------------------------------------------------------------------------------ [std] metric matrix, closed forms, floats
def std_T(e, p):
    """[std] (S, M_phi, Phi, T) jets from the metric matrix g = e^T eta e (plain polynomials, no engine); T None on the axis"""
    g = std_metric(e, 4, SQ, 4, 2); ps = K.d_phi(p)
    S = tdeg(g[(0, 0)]); Mp = {}; Ph = {}
    for n in range(4):
        if ps[n]: Mp = sp_add(Mp, sp_mul(g[(0, n)], ps[n], 2, NV))
        for m in range(4):
            if ps[m] and ps[n]: Ph = sp_add(Ph, sp_mul(sp_mul(g[(m, n)], ps[m], 2, NV), ps[n], 2, NV), -1)
    Mp, Ph = tdeg(Mp), tdeg(Ph)
    Tj = tdeg(lin((F(1), S), (F(1), K._jm(K._jm(Mp, Mp), K.recip2(Ph))))) if at0(Ph, NV) != 0 else None
    return dict(S=S, M=Mp, Phi=Ph, T=Tj, g=g)
def closed_T(M, a, r, c2):
    """RECALLED Boyer-Lindquist: T = Delta Sigma/A at (r, cos^2 th = c2) (exact)"""
    Sig = r * r + a * a * c2; Dl = r * r - 2 * M * r + a * a; A = (r * r + a * a) ** 2 - Dl * a * a * (1 - c2); return Dl * Sig / A
def closed_dT_dr(M, a, r, c2):
    """d/dr of Delta Sigma/A at fixed th (exact)"""
    Sig = r * r + a * a * c2; Dl = r * r - 2 * M * r + a * a; A = (r * r + a * a) ** 2 - Dl * a * a * (1 - c2)
    dDl = 2 * r - 2 * M; dSig = 2 * r; dA = 4 * r * (r * r + a * a) - dDl * a * a * (1 - c2)
    return (dDl * Sig + Dl * dSig) / A - Dl * Sig * dA / A ** 2
def float_T(r, th, ph, M=5.0, a=3.0):
    """[std] floats: T = g_tt - g_tphi^2/g_phiphi from the closed-form Kerr-Schild metric (no jets), at (r, th, ph)"""
    X = np.array([0.0, math.sin(th) * (r * math.cos(ph) - a * math.sin(ph)), math.sin(th) * (r * math.sin(ph) + a * math.cos(ph)), r * math.cos(th)])
    g = K.float_metric(X, M, a); ps = np.array([0.0, -X[2], X[1], 0.0]); S = g[0, 0]; Mp = g[0] @ ps; Ph = -(ps @ g @ ps)
    return S + Mp * Mp / Ph, S, g, X
def closed_T_float(r, th, M=5.0, a=3.0):
    Sig = r * r + a * a * math.cos(th) ** 2; Dl = r * r - 2 * M * r + a * a; A = (r * r + a * a) ** 2 - Dl * a * a * math.sin(th) ** 2; return Dl * Sig / A

CT = {}
def ctl(name, wrong): k = CT.setdefault(name, [0, 0]); k[1] += 1; k[0] += int(bool(wrong))
CTL_NAMES = ['the static potential g_tt in place of T: its zero set contains the ergosurface (r = 10, equator), where T != 0', '(1/2) dT = +kH chi_flat (the sign flipped)',
             'kH of the other horizon (r+ and r- swapped)', 'Omega of the other horizon in chi']     # registered first: a control that is never reached prints as a failure

def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # per run (an engine fault put into Lie in memory is seen)
    CT.clear(); [CT.setdefault(n, [0, 0]) for n in CTL_NAMES]
    hd = K.kerr_horizon_data(M0, A0); rp, rm = hd['rp'], hd['rm']
    head('0. the numbers of the statement: Kerr (M, a) = (5, 3), r+- = %s, %s; recalled kH = (r+- - r-+)/(2 (r+-^2 + a^2)) = %s, %s' % (rp, rm, hd['kappa_p'], hd['kappa_m']))
    chk('std', (rp, rm, hd['kappa_p'], hd['kappa_m']) == (9, 1, F(2, 45), F(-2, 5)), 'r+ = 9, r- = 1, kH = 2/45 and -2/5 (the values the statement quotes)')

    head('1. T on the chart: [bit] bit-rule squares of the frame components; [std] metric matrix and the closed form Delta Sigma/A')
    RSOFF = [F(20), F(7), F(4), F(2), F(1, 2), F(1, 5)]
    pts = [(P, 'off') for P in K.rational_kerr_points(A0, RSOFF, ANG[:3])] + [(P, 'off') for P in K.rational_kerr_points(A0, [F(10), F(19, 2)], EQ)]
    pts += [(P, 'hor') for P in K.rational_kerr_points(A0, [rp, rm], ANG)] + [(P, 'axis') for P in K.rational_kerr_points(A0, [rp, rm, F(4), F(20)], AXIS)]
    vals = {}; ok_eq = True; ok_cf = True; ok_ax = True; zeros = []; nonzero_off = True; okA = True; erg = []
    for P, kind in pts:
        e = K.kerr_ks_frame_jet(P['p'], M0, A0, P['r'])[0]; B = reduced_T_jets(e, P['p']); Z = std_T(e, P['p']); r, c2 = P['r'], P['cth'] ** 2
        if kind == 'axis':
            ok_ax &= all(at0(q, NV) == 0 and all(lin1(q, i) == 0 for i in range(NV)) for q in (B['tf'], B['ff'], Z['M'], Z['Phi'])) and tdeg(B['tt'], 1) == tdeg(Z['S'], 1)
            Tv = at0(B['tt'], NV)
        else:
            ok_eq &= B['T'] is not None and Z['T'] is not None and tdeg(B['T'], 1) == tdeg(Z['T'], 1)
            Tv = at0(B['T'], NV)
        ok_cf &= Tv == closed_T(M0, A0, r, c2); vals[(r, P['cth'], P['sph'])] = Tv
        Sig = r * r + A0 * A0 * c2; okA &= (r * r + A0 * A0) ** 2 - (r * r - 2 * M0 * r + A0 * A0) * A0 * A0 * (1 - c2) == (r * r + A0 * A0) * Sig + 2 * M0 * r * A0 * A0 * (1 - c2) > 0
        if Tv == 0: zeros.append(r)
        if r not in (rp, rm): nonzero_off &= Tv != 0
        if r == 10 and c2 == 0: erg.append((at0(B['tt'], NV), Tv))
        if r == F(19, 2) and c2 == 0: erg.append((at0(B['tt'], NV), Tv))
    chk('bit==std', ok_eq, 'T = <xi,xi> - <xi,psi>^2/<psi,psi> from bit-rule squares of the frame components equals the (t, phi)-block value S + M_phi^2/Phi of the metric matrix, value and first derivatives, at %d points off the axis' % sum(1 for _, k in pts if k != 'axis'))
    chk('bit==std', ok_ax, 'on the axis (%d points, r = 9, 1, 4, 20, both poles): M_phi and Phi vanish with their first derivatives on both routes, so T and dT there are those of S = <xi, xi>' % sum(1 for _, k in pts if k == 'axis'))
    chk('bit==std', ok_cf, 'T = Delta Sigma/A (recalled Boyer-Lindquist closed form) exactly at all %d points (r = 20, 10, 19/2, 9, 7, 4, 2, 1, 1/2, 1/5; equator, axis and generic angles)' % len(pts))
    chk('std', okA, 'A = (r^2 + a^2)^2 - Delta a^2 sin^2 th = (r^2 + a^2) Sigma + 2 M r a^2 sin^2 th > 0 at every point (an identity; positive for every r > 0): on the chart T = 0 exactly where Delta = 0')
    chk('bit', set(zeros) == {rp, rm} and nonzero_off and len(zeros) == sum(1 for P, k in pts if P['r'] in (rp, rm)), 'zero set: T = 0 at all %d points of r = 9 and r = 1 (axis included) and T != 0 at all %d other points: T vanishes on the two horizons and nowhere else among the checked points' % (
        len(zeros), sum(1 for P, k in pts if P['r'] not in (rp, rm))))
    chk('bit', len(erg) == 4 and all(s == 0 and t == F(9, 118) for s, t in erg[:2]) and all(s < 0 < t for s, t in erg[2:]),
        'ergosurface r = 10 on the equator (2 points): g_tt = <xi, xi> = 0 while T = %s; ergoregion r = 19/2 on the equator: g_tt = %s < 0 < T = %s' % (erg[0][1], erg[2][0], erg[2][1]))
    for s, t in erg[:2]: ctl('the static potential g_tt in place of T: its zero set contains the ergosurface (r = 10, equator), where T != 0', s == 0 and t != 0)
    ring = [(r, closed_T(M0, A0, r, F(0))) for r in (F(1, 10), F(1, 100), F(1, 1000))]
    chk('std', all(0 < t < r / (2 * M0) for r, t in ring), 'off the chart: on the equator T = Delta r/(r^3 + r a^2 + 2 M a^2) -> 0 as r -> 0 (the ring singularity, not a point of the chart): T = %s' % ', '.join('%s at r = %s' % (t, r) for r, t in ring))
    tick('part 1')

    head('2. the gradient on the horizons: the chart-free form (1/2) dT = -kH chi_flat, and the literal recipe (1/2) d_r T')
    ok_cov = True; ok_std = True; ok_bs = True; lit = []; ok_lit_cf = True; ok_rt = True; ok_grr = True; nh = 0
    for rh, k_other, Om_other in ((rp, hd['kappa_m'], hd['Omega_m']), (rm, hd['kappa_p'], hd['Omega_p'])):
        for P in K.rational_kerr_points(A0, [rh], ANG + AXIS):
            nh += 1; e, E, _, data = K.kerr_ks_frame_jet(P['p'], M0, A0, rh); B = reduced_T_jets(e, P['p']); Z = std_T(e, P['p'])
            disc, Om = K.null_rotation(e, P['p'], SQ); Om = Om if Om is not None else (hd['Omega_p'] if rh == rp else hd['Omega_m'])   # on the axis d_phi = 0: any Omega
            chi = K.killing_chi(P['p'], Om); om = omega_closed_form(Gv, e, S, NV, 0)[0]; ca, nab = K.engine_nabla_vv(Gv, om, e, chi); kH = prop(ca, nab)
            Tj = B['T'] if B['T'] is not None else B['tt']; dT = dT_engine(Gv, Tj); cf = chi_flat(e, ca)
            good = kH is not None and all(dT[m] == -2 * kH * cf[m] for m in range(4)) and any(cf)
            ok_cov &= good
            g = Z['g']; g0 = [[at0(g[(m, n)], NV) for n in range(4)] for m in range(4)]; c0 = [at0(q, NV) for q in chi]; cf_s = [sum(g0[m][n] * c0[n] for n in range(4)) for m in range(4)]
            TjS = Z['T'] if Z['T'] is not None else Z['S']; dTs = [lin1(TjS, m) for m in range(4)]; kS = prop(c0, K.std_nabla_vv(g, chi))
            ok_std &= kS is not None and all(dTs[m] == -2 * kS * cf_s[m] for m in range(4))
            ok_bs &= dT == dTs and cf == cf_s and kH == kS
            dr = [P['sth'] * P['cph'], P['sth'] * P['sph'], P['cth']]; half_dr = sum(dT[i] * dr[i - 1] for i in (1, 2, 3)) / 2
            Sig = rh * rh + A0 * A0 * P['cth'] ** 2
            ok_lit_cf &= kH is not None and half_dr == kH * Sig / (rh * rh + A0 * A0) == closed_dT_dr(M0, A0, rh, P['cth'] ** 2) / 2
            lit.append((rh, P['cth'], half_dr, kH, P['sth'] == 0))
            grad_r = [lin1(data['r'], m) for m in range(4)]; dra = [sum(at0(E[m][A], NV) * grad_r[m] for m in range(4)) for A in range(4)]
            grr = K.frame_norm_bit(dra, SQ); ok_grr &= grr == 0
            ok_rt &= kH is not None and half_dr * (rh * rh + A0 * A0) / Sig == kH
            if kH is not None and any(cf):
                ctl('(1/2) dT = +kH chi_flat (the sign flipped)', any(dT[m] != 2 * kH * cf[m] for m in range(4)))
                ctl('kH of the other horizon (r+ and r- swapped)', any(dT[m] != -2 * k_other * cf[m] for m in range(4)))
                ca_w = [at0(q, NV) for q in K.engine_vector_at0(e, K.killing_chi(P['p'], Om_other))]
                if P['sth'] != 0: ctl('Omega of the other horizon in chi', any(dT[m] != -2 * kH * c for m, c in enumerate(chi_flat(e, ca_w))))
    chk('bit', ok_cov, '(1/2) dT = -kH chi_flat, all four components, at %d points of r = 9 and r = 1 (axis included): dT from the engine\'s d, kH from nabla_chi chi = kH chi with the engine\'s omega (kH = 2/45 and -2/5), chi_flat from the frame' % nh)
    chk('std', ok_std, 'the same identity on the Christoffel route (dT from the metric-matrix jets, nabla_chi chi by Christoffel symbols) at the %d points' % nh)
    chk('bit==std', ok_bs, 'dT, chi_flat and kH equal on both routes at the %d points' % nh)
    chk('bit==std', ok_lit_cf, 'the literal recipe: (1/2) d_r T at fixed angles (engine\'s d, chain rule) = kH Sigma/(r_h^2 + a^2) = (1/2) d_r (Delta Sigma/A) (closed form) at the %d points' % nh)
    axis_ok = [x for x in lit if x[4]]; off_ax = [x for x in lit if not x[4]]
    chk('bit', all(h == k for _, _, h, k, _ in axis_ok) and all(h != k for _, _, h, k, _ in off_ax) and len(axis_ok) == 4,
        'so (1/2) d_r T = kH only on the axis (4 of 4 pole points: %s) and differs from kH at all %d points off the axis (%s)' % (
            ', '.join(sorted({str(h) for _, _, h, _, _ in axis_ok})), len(off_ax), ', '.join('%s at r = %s, cos th = %s' % (h, r, c) for r, c, h, _, _ in off_ax[:5]) + ', ...'))
    chk('bit', ok_grr, 'g^-1(dr, dr) = 0 at the %d horizon points (frame components of dr by the inverse frame, bit-rule square): dr is null there (the paper\'s g^rr = 0 holds on these horizons)' % nh)
    chk('bit', ok_rt, 'the paper\'s EF-like coordinate of the reduced line element T dt^2 - R dr^2 (our reading of its Sec. II.C with II.A): dr~ = sqrt(T R) dr, sqrt(T R) = Sigma/(r_h^2 + a^2) on the horizon (part 3): (1/2) dT/dr~ = kH at all %d points' % nh)
    tick('part 2')

    head('3. g^rr = -Delta/Sigma and T R = Sigma^2/A off the horizons (R = -1/g^rr, the paper\'s radial function): exact at points')
    ok3 = True; n3 = 0
    for P in K.rational_kerr_points(A0, [F(20), F(7), F(4), F(1, 2)], ANG[:3]):
        e, E, _, data = K.kerr_ks_frame_jet(P['p'], M0, A0, P['r']); B = reduced_T_jets(e, P['p']); r, c2 = P['r'], P['cth'] ** 2
        grad_r = [lin1(data['r'], m) for m in range(4)]; dra = [sum(at0(E[m][A], NV) * grad_r[m] for m in range(4)) for A in range(4)]; grr = K.frame_norm_bit(dra, SQ)
        Sig = r * r + A0 * A0 * c2; Dl = r * r - 2 * M0 * r + A0 * A0; A = (r * r + A0 * A0) ** 2 - Dl * A0 * A0 * (1 - c2)
        ok3 &= grr == -Dl / Sig and -at0(B['T'], NV) / grr == Sig * Sig / A; n3 += 1
    chk('bit==std', ok3, 'g^-1(dr, dr) = -Delta/Sigma and T R = -T/g^rr = Sigma^2/A at %d points (r = 20, 7, 4, 1/2): the factor sqrt(T R) is regular across the horizons, Sigma/sqrt(A) -> Sigma/(r_h^2 + a^2)' % n3)
    tick('part 3')

    head('4. [std] floats from the closed-form metric (no jets): T, d_r T, the zero set along r at seven angles, the ergosurface, dT/dr~ near r = 9')
    worst = 0.0
    for r, th, ph in ((9.0, 0.3, 0.2), (1.0, 1.1, 2.0), (4.0, 0.8, 1.0), (20.0, 1.4, -0.7), (0.5, 1.2, 0.4)):
        t, _, _, _ = float_T(r, th, ph); worst = max(worst, abs(t - closed_T_float(r, th)))
    h = 1e-3; th0 = math.acos(0.6); fd = (-float_T(9 + 2 * h, th0, 0.3)[0] + 8 * float_T(9 + h, th0, 0.3)[0] - 8 * float_T(9 - h, th0, 0.3)[0] + float_T(9 - 2 * h, th0, 0.3)[0]) / (12 * h)
    chk('std', worst < 1e-12 and abs(fd / 2 - 26 / 625) < 1e-9, 'floats: T from the closed-form metric = Delta Sigma/A at 5 points (largest difference %.1e); (1/2) d_r T at r = 9, cos th = 0.6 by five-point differences = %.12f (exact 26/625 = %.12f, not 2/45 = %.12f)' % (worst, fd / 2, 26 / 625, 2 / 45))
    roots_all = []; erg_ok = True
    for th in (0.05, 0.3, 0.7, 1.0, 1.3, 1.55, math.pi / 2):
        rr = np.linspace(0.01, 30.0, 6000); vals_ = [float_T(r, th, 0.4)[0] for r in rr]; rts = []
        for i in range(len(rr) - 1):
            if vals_[i] == 0 or vals_[i] * vals_[i + 1] < 0:
                lo, hi = rr[i], rr[i + 1]
                for _ in range(60):
                    mid = (lo + hi) / 2
                    if float_T(lo, th, 0.4)[0] * float_T(mid, th, 0.4)[0] <= 0: hi = mid
                    else: lo = mid
                rts.append((lo + hi) / 2)
        roots_all.append(rts)
        rE = 5 + math.sqrt(25 - 9 * math.cos(th) ** 2); a1 = float_T(rE - 1e-6, th, 0.4); a2 = float_T(rE + 1e-6, th, 0.4)
        erg_ok &= a1[1] < 0 < a2[1] and a1[0] > 0 and a2[0] > 0
    chk('std', all(len(rts) == 2 and abs(rts[0] - 1) < 1e-9 and abs(rts[1] - 9) < 1e-9 for rts in roots_all),
        'floats: T changes sign along r in (0.01, 30] (6000 nodes, bisection) exactly twice at each of 7 angles (th = 0.05 ... pi/2), at r = 1 and r = 9 (largest deviation %.1e)' % max(abs(x - y) for rts in roots_all for x, y in zip(rts, (1, 9))))
    chk('std', erg_ok, 'floats: across the ergosurface r_E = M + sqrt(M^2 - a^2 cos^2 th) g_tt changes sign while T stays positive, at the same 7 angles')
    eps = 1e-5; r1 = 9 + eps; t1, _, g1, X1 = float_T(r1, th0, 0.3)
    dT = (float_T(r1 + 1e-7, th0, 0.3)[0] - float_T(r1 - 1e-7, th0, 0.3)[0]) / 2e-7
    x_, y_, z_ = X1[1:]; den = r1 ** 4 + 9.0 * z_ * z_; gr = np.array([0.0, r1 ** 3 * x_ / den, r1 ** 3 * y_ / den, r1 * z_ * (r1 * r1 + 9.0) / den])     # d r from P(r) = 0 (closed form)
    grr = gr @ np.linalg.inv(g1) @ gr; Rr = -1 / grr; kfl = 0.5 * dT / math.sqrt(t1 * Rr)
    chk('std', abs(kfl - 2 / 45) < 1e-4, 'floats: (1/2) dT/dr~ with dr~ = sqrt(T R) dr, R = -1/g^rr (g^rr from the inverse closed-form metric and the closed-form gradient of r(x, y, z)), at r = 9 + 1e-5, cos th = 0.6: %.7f against kH = 2/45 = %.7f' % (kfl, 2 / 45))
    tick('part 4')

    head('5. controls: another member; the gradient sign and the swap of the horizons (counted above)')
    difc = 0; nc = 0
    for (Mw, aw) in ((F(5), F(4)), (F(6), F(3))):
        for (r, c, s), v in vals.items():
            nc += 1; difc += int(closed_T(Mw, aw, r, c * c) != v)
    chk('ctl', difc == nc, 'the closed form Delta Sigma/A of another member, (M, a) = (5, 4) and (6, 3), differs from the frame\'s T at %d of %d (point, member) samples' % (difc, nc))
    nz = 0; nn = 0
    for P in K.rational_kerr_points(F(4), [rp, rm], ANG[:2]):
        e = K.kerr_ks_frame_jet(P['p'], M0, F(4), P['r'])[0]; B = reduced_T_jets(e, P['p']); nn += 1; nz += int(at0(B['T'], NV) != 0)
    chk('ctl', nz == nn, 'the frame of another member, (M, a) = (5, 4) (horizons 8 and 2): T != 0 at r = 9 and r = 1 at %d of %d points' % (nz, nn))
    for name, (dif, seen) in CT.items(): chk('ctl', dif == seen and seen > 0, '%s: fails on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F3-reduced')

if __name__ == '__main__': main()
