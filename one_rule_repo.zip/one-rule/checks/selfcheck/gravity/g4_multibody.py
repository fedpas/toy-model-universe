#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G4: Li and Ding, Sci China Tech Sci 69(10) 2020303 (2026), constrained multibody dynamics in PGA, against step 14's body (forque_selfcheck).
 Exact Fractions and exact truncated power series in t; n = 3: Cl(3,0,1) as the bit rule of forque_selfcheck.Alg(3) (e0 = bit 0, e0^2 = 0).
 The differential-form engine (gravity_selfcheck) is NOT read by this step.
   python3 g4_multibody.py                        all parts (a)-(d) and the series flows (f)
   python3 g4_multibody.py --quick                parts a (one case), c (two-body chain) and the double pendulum of d
   python3 g4_multibody.py --fault G1a|G1b|G2|G3  own faults: e0^2 = +1 / -1; sign of e12 e23 and e23 e12; factor 1/2 of Omega = -B/2 dropped
 Conventions (checked in the run): the paper's motor N (X = N~ X0 N, V = 2 N~ N', x = half commutator) is M~ of the Atlas;
 a joint motor is exp(q/2 L0) = c + s L0 for a unit line L0 = u I3 - e0 (r^u) I3 (right-handed rotation by q about u through r; (c, s) the rational
 half-angle pair) or 1 + (q/2) e0 u (translation by +q u); the pairing (w ^ L)* is the e0123 coefficient; gravity V0' = -a_g with a_g = e0 g
 (g the gravitational acceleration vector), or the weight lines sum m P v (g I) as an external wrench (ours).
 Import-safe: importing builds only the algebra (no fault unless run as a script with --fault)."""
import sys, os, time, random
sys.dont_write_bytecode = True
from fractions import Fraction as F
HERE = os.path.dirname(os.path.abspath(__file__)); SELFCHECK = os.path.dirname(HERE)
for _p in (HERE, SELFCHECK):
    if _p not in sys.path: sys.path.insert(0, _p)
from b1lib import head, chk, finish
import forque_selfcheck as fq

_ARGS = sys.argv[1:] if __name__ == '__main__' else []
FAULT = _ARGS[_ARGS.index('--fault') + 1] if '--fault' in _ARGS else None
QUICK = '--quick' in _ARGS
EPS_SQ = {'G1a': 1, 'G1b': -1}.get(FAULT, 0)
HALF = F(1) if FAULT == 'G3' else F(1, 2)          # the factor of Omega = -B/2 (Atlas M' = -1/2 M B; paper N' = 1/2 N V)
if FAULT == 'G2':
    _bm0 = fq.bmul
    def _bm(a, b, sq):
        m, s = _bm0(a, b, sq)
        return (m, -s) if (a, b) in ((6, 12), (12, 6)) else (m, s)
    fq.bmul = _bm

# ================================================================== truncated power series (a commutative ring the MV class accepts)
class TS:
    """truncated power series in t with Fraction coefficients, order TS.N"""
    __slots__ = ('c',)
    N = 6
    def __init__(s, c): s.c = c
    @staticmethod
    def const(x): return TS([F(x)] + [F(0)] * TS.N)
    @staticmethod
    def poly(cs): cs = [F(x) for x in cs][:TS.N + 1]; return TS(cs + [F(0)] * (TS.N + 1 - len(cs)))
    def __add__(s, o):
        if isinstance(o, TS): return TS([a + b for a, b in zip(s.c, o.c)])
        c = list(s.c); c[0] = c[0] + o; return TS(c)
    __radd__ = __add__
    def __neg__(s): return TS([-a for a in s.c])
    def __sub__(s, o): return s + (-o)
    def __rsub__(s, o): return (-s) + o
    def __mul__(s, o):
        if isinstance(o, TS):
            n = len(s.c); r = [F(0)] * n; oc = o.c
            for i, a in enumerate(s.c):
                if a:
                    for j in range(n - i):
                        b = oc[j]
                        if b: r[i + j] += a * b
            return TS(r)
        return TS([a * o for a in s.c])
    __rmul__ = __mul__
    def inv(s):
        a0 = s.c[0]; n = len(s.c); r = [F(0)] * n; r[0] = 1 / a0
        for k in range(1, n): r[k] = -sum((s.c[j] * r[k - j] for j in range(1, k + 1)), F(0)) / a0
        return TS(r)
    def __truediv__(s, o): return s * o.inv() if isinstance(o, TS) else TS([a / o for a in s.c])
    def __rtruediv__(s, o): return s.inv() * o
    def __bool__(s): return any(s.c)
    def __eq__(s, o): return s.c == o.c if isinstance(o, TS) else (s.c[0] == o and not any(s.c[1:]))
    def __hash__(s): return hash(tuple(s.c))
    def d(s): return TS([s.c[k + 1] * (k + 1) for k in range(len(s.c) - 1)] + [F(0)])
    def integ(s, x0=0): return TS([F(x0)] + [s.c[k - 1] / k for k in range(1, len(s.c))])
def ts(x): return x if isinstance(x, TS) else TS.const(x)
def co(x, k=0): return x.c[k] if isinstance(x, TS) else (F(x) if k == 0 else F(0))
def nz0(x): return co(x, 0) != 0

# ================================================================== the algebra (the Atlas's own bit rule) and the paper's entities
A = fq.Alg(3, 1, EPS_SQ)
ONE, ZERO, O3, PS, E0 = A.one(), A.zero(), A.O, A.I, A.eps
BIV = A.bivectors()
def MVd(d): return fq.MV(A.sq, d)
def blade(m): return MVd({m: F(1)})
def gmask(g, euclid=False): return [m for m in range(16) if bin(m).count('1') == g and not (euclid and m & 1)]
def vec3(x): return A.vec([F(v) for v in x])
def PT(x): return A.point([F(v) for v in x])                                     # P = I3 - e0 x I3 (paper eq. 4), = O + x I
def LINE(r, u): return vec3(u) * O3 - (E0 * vec3(r).wedge(vec3(u))) * O3          # L = u I3 - e0 (r ^ u) I3 (paper eq. 3)
def DIRL(u): return vec3(u) * O3                                                  # direction part u I3
def PLANE(n, delta): return vec3(n) - E0.scale(F(delta))                          # p = n - delta e0 (paper eq. 2)
def TGEN(u): return E0 * vec3(u)                                                  # translation generator: exp(q/2 e0 u) moves by +q u
def cx(X, Y): return A.comm(X, Y)                                                 # X x Y = (1/2)(XY - YX), paper eq. (9)
def euc(X): return MVd({m: c for m, c in X.d.items() if not m & 1})               # direction part (drop the e0 components)
def dot(X, Y):
    r = ZERO
    for gx in X.grades():
        Xg = X.grade(gx)
        for gy in Y.grades(): r = r + (Xg * Y.grade(gy)).grade(abs(gx - gy))
    return r
OPS = {'^': lambda X, Y: X.wedge(Y), 'v': lambda X, Y: A.join(X, Y), 'x': cx, '.': dot}
def pair(w, L): return w.wedge(L).d.get(15, F(0))                                 # (w ^ L)*, I = e0123 (paper eqs. 16-17)
_IVM = []
for _j in (1, 2, 3):
    (_m, _c), = (A.g(_j) * PS).d.items(); _IVM.append((_m, _c))
def ivec(X): return [X.d.get(m, F(0)) / c for m, c in _IVM]                      # u with u I = X (an ideal point)
def pvec(P): return ivec(P - O3)                                                  # position of a normalised point
def sum_mv(xs):
    r = ZERO
    for x in xs: r = r + x
    return r
# series of multivectors (MV with TS coefficients)
def mv_ts(X): return MVd({m: TS.const(c) for m, c in X.d.items()})
def mv_d(X): return MVd({m: ts(c).d() for m, c in X.d.items()})
def mv_integ(dX, X0):
    keys = set(dX.d) | set(X0.d)
    return MVd({m: ts(dX.d.get(m, F(0))).integ(co(X0.d.get(m, F(0)))) for m in keys})
def mv_c(X, k=0): return MVd({m: co(c, k) for m, c in X.d.items()})
def mv_eq(X, Y, upto, masks=None):
    keys = set(X.d) | set(Y.d)
    if masks is not None: keys &= set(masks)
    return all(co(X.d.get(m, F(0)), k) == co(Y.d.get(m, F(0)), k) for m in keys for k in range(upto + 1))
def mv_zero(X, upto, masks=None): return mv_eq(X, ZERO, upto, masks)

# ================================================================== rational data
def half_angle(tau): tau = F(tau); d = 1 + tau * tau; return ((1 - tau * tau) / d, 2 * tau / d)
UV = {'x': (1, 0, 0), 'y': (0, 1, 0), 'z': (0, 0, 1),
      'a': (F(1, 3), F(2, 3), F(2, 3)), 'b': (F(2, 3), F(1, 3), F(-2, 3)), 'c': (F(2, 3), F(-2, 3), F(1, 3)),
      'p': (F(2, 7), F(3, 7), F(6, 7)), 'q': (F(3, 7), F(-6, 7), F(2, 7)), 'r': (F(6, 7), F(2, 7), F(-3, 7))}
def rq(rng, lo=-3, hi=3): return F(rng.randint(lo, hi), rng.choice((1, 2, 3)))
def rqn(rng): return F(rng.choice((-3, -2, -1, 1, 2, 3)), rng.choice((1, 2, 3)))

# ================================================================== plain vectors and matrices (the [std] route uses only these)
def v_add(a, b): return [x + y for x, y in zip(a, b)]
def v_sub(a, b): return [x - y for x, y in zip(a, b)]
def v_sc(k, a): return [k * x for x in a]
def v_dot(a, b): return sum((x * y for x, y in zip(a, b)), F(0))
def v_cross(a, b): return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
def m_vec(M, v): return [v_dot(r, v) for r in M]
def m_mul(P, Q): return [[sum((P[i][k] * Q[k][j] for k in range(3)), F(0)) for j in range(3)] for i in range(3)]
def m_T(M): return [list(r) for r in zip(*M)]
EYE = [[F(int(i == j)) for j in range(3)] for i in range(3)]
def rodrigues(u, c, s):
    """rotation by q about the unit axis u, cos(q/2) = c, sin(q/2) = s (Rodrigues)"""
    cq, sq_ = c * c - s * s, 2 * c * s
    Kx = [[F(0), -u[2], u[1]], [u[2], F(0), -u[0]], [-u[1], u[0], F(0)]]; K2 = m_mul(Kx, Kx)
    return [[EYE[i][j] + sq_ * Kx[i][j] + (1 - cq) * K2[i][j] for j in range(3)] for i in range(3)]
def det3(a, b, c): return v_dot(a, v_cross(b, c))
def perp(u):
    u = [F(x) for x in u]; e = min(range(3), key=lambda c: abs(u[c])); w1 = v_cross(u, [F(int(c == e)) for c in range(3)]); return w1, v_cross(u, w1)
def rand_pts(rng, center, k=4):
    while True:
        pts = [(F(rng.randint(1, 3)), [F(c) + F(rng.randint(-4, 4), rng.choice((1, 2))) for c in center]) for _ in range(k)]
        x = [p for _, p in pts]
        if det3(v_sub(x[1], x[0]), v_sub(x[2], x[0]), v_sub(x[3], x[0])) != 0: return pts

# ================================================================== exact linear algebra (Fractions or series)
def solve(Mt, b):
    n = len(Mt); R = [list(Mt[i]) + [b[i]] for i in range(n)]
    for c in range(n):
        p = next((r for r in range(c, n) if nz0(R[r][c])), None)
        if p is None: raise ZeroDivisionError('singular system (column %d)' % c)
        R[c], R[p] = R[p], R[c]; iv = 1 / R[c][c]; R[c] = [x * iv for x in R[c]]
        for r in range(n):
            if r != c and R[r][c]:
                f = R[r][c]; R[r] = [x - f * y for x, y in zip(R[r], R[c])]
    return [R[r][n] for r in range(n)]
def indep(rows):
    """indices of a maximal independent subset of the rows (greedy, exact; for series the constant terms decide)"""
    basis = []; keep = []
    for idx, r in enumerate(rows):
        v = [co(x, 0) for x in r]
        for piv, b in basis:
            if v[piv]: f = v[piv]; v = [x - f * y for x, y in zip(v, b)]
        nzp = next((t for t, x in enumerate(v) if x), None)
        if nzp is None: continue
        iv = 1 / v[nzp]; v = [x * iv for x in v]
        basis = [(p_, [x - b_[nzp] * y for x, y in zip(b_, v)]) for p_, b_ in basis]
        basis.append((nzp, v)); keep.append(idx)
    return keep
def nullspace(rows, n):
    R = [list(r) for r in rows]; piv = []; rr = 0
    for c in range(n):
        p = next((i for i in range(rr, len(R)) if R[i][c] != 0), None)
        if p is None: continue
        R[rr], R[p] = R[p], R[rr]; iv = 1 / R[rr][c]; R[rr] = [x * iv for x in R[rr]]
        for i in range(len(R)):
            if i != rr and R[i][c] != 0: f = R[i][c]; R[i] = [x - f * y for x, y in zip(R[i], R[rr])]
        piv.append(c); rr += 1
    out = []
    for fc in [c for c in range(n) if c not in piv]:
        v = [F(0)] * n; v[fc] = F(1)
        for i, pc in enumerate(piv): v[pc] = -R[i][fc]
        out.append(v)
    return out

# ================================================================== the paper's multibody layer (Algorithms 1-3, eqs. 14-28), ring-generic
class Jt:
    """one joint axis i: parent body p(i) (0 = base), kind 'R' (revolute, unit line through a along u) or 'P' (prismatic along u);
    pts = the zero-configuration mass points (m, x) of the body it carries ([] = massless link)"""
    def __init__(s, parent, kind, a, u, pts=None):
        s.parent, s.kind = parent, kind; s.a = [F(x) for x in a]; s.u = [F(x) for x in u]
        s.pts = [(F(m), [F(x) for x in p]) for m, p in (pts or [])]
        s.L0 = LINE(s.a, s.u) if kind == 'R' else TGEN(s.u)
def gen_motor(kind, G, st): return (ONE.scale(st[0]) + G.scale(st[1])) if kind == 'R' else (ONE + G.scale(st * F(1, 2)))
def jmotor(j, st): return gen_motor(j.kind, j.L0, st)
def motors(model, st): return [None] + [jmotor(model[i - 1], st[i]) for i in range(1, len(model) + 1)]
def path(model, i):
    out = []
    while i > 0: out.append(i); i = model[i - 1].parent
    return out
def pga_kin(model, E, qd):
    """Algorithm 1 pass 1 (lines 4-8 without gravity) and eq. (22): motors, current axes L_i, V_i, L_i' = L_i x V_p(i), W_i"""
    n = len(model); Mo = [ONE] + [None] * n; V = [ZERO] + [None] * n; W = [ZERO] + [None] * n; L = [None] * (n + 1); Ld = [None] * (n + 1)
    for i in range(1, n + 1):
        p = model[i - 1].parent
        Mo[i] = E[i] * Mo[p]
        L[i] = Mo[p].rev() * model[i - 1].L0 * Mo[p]
        V[i] = V[p] + L[i].scale(qd[i])
        Ld[i] = cx(L[i], V[p])
        W[i] = W[p] + Ld[i].scale(qd[i])
    return dict(Mo=Mo, L=L, V=V, Ld=Ld, W=W)
def sand(K, i, X0): return K['Mo'][i].rev() * X0 * K['Mo'][i] if i else X0
class Inertia:
    def __init__(s, imgs): s.imgs = imgs
    def __call__(s, Y):
        r = ZERO
        for b, c in Y.d.items():
            if b in s.imgs: r = r + s.imgs[b].scale(c)
        return r
    def __add__(s, o): return Inertia({b: s.imgs[b] + o.imgs[b] for b in BIV})
def inertia_points(pts):
    """I(.) = sum m P v (P x .), the paper's definition (p. 5) with the CURRENT points"""
    return Inertia({b: sum_mv([A.join(P, cx(P, blade(b))).scale(m) for m, P in pts]) for b in BIV})
def inertia_dict(N, Ab):
    """the dictionary I(X) = N~ A(N X N~) N (Atlas M = N~), A = step 14's body-frame inertia"""
    Nr = N.rev(); return Inertia({b: Nr * Ab(N * blade(b) * Nr) * N for b in BIV})
def body_A(j, nonrigid=0):
    if not hasattr(j, '_body'): j._body = fq.Body(A, j.pts)
    bd = j._body
    def Ab(Y): return bd.I(MVd({m: c for m, c in Y.d.items() if m in bd._img}))
    if not nonrigid: return Ab
    wts = [(3, F(1))] if nonrigid == 1 else [(3, F(1)), (5, F(2)), (9, F(3))]          # [ctl] anisotropic mass along e01 (1) or e01, e02, e03 with weights 1, 2, 3 (3)
    sts = [(A.star(blade(m)), m, w) for m, w in wts]; mass = bd.m
    return lambda Y: Ab(Y) + sum_mv([sb.scale(mass * w * Y.d.get(m, F(0))) for sb, m, w in sts])
def alg1(model, E, qd, ag=None, wfn=None, imode='points', gsign=-1):
    """Algorithm 1 (p. 6) as printed; extension (ours): external wrenches wfn(K, P) -> {i: w_ext}, w_i = I(V'bias) + I(V) x V - w_ext"""
    n = len(model); K = pga_kin(model, E, qd); P = {}; Ii = {}
    for i in range(1, n + 1):
        j = model[i - 1]; N = K['Mo'][i]; Nr = N.rev()
        P[i] = [(m, Nr * PT(x) * N) for m, x in j.pts]
        if not j.pts: Ii[i] = Inertia({b: ZERO for b in BIV})
        elif imode == 'points': Ii[i] = inertia_points(P[i])
        elif imode == 'body': Ab = body_A(j); Ii[i] = Inertia({b: Ab(blade(b)) for b in BIV})        # [ctl] body frame, not moved
        else: Ii[i] = inertia_dict(N, body_A(j, {'nonrigid1': 1, 'nonrigid3': 3}.get(imode, 0)))
    Vd0 = ZERO if ag is None else ag.scale(gsign)
    wx = wfn(K, P) if wfn else {}
    w = {}
    for i in range(1, n + 1):
        Vi = K['V'][i]; w[i] = Ii[i](Vd0 + K['W'][i]) + cx(Ii[i](Vi), Vi)
        if i in wx: w[i] = w[i] - wx[i]
    Mm = [[F(0)] * n for _ in range(n)]; tb = [F(0)] * n; Ic = dict(Ii); wc = dict(w)
    for i in range(n, 0, -1):
        Li = K['L'][i]; mi = Ic[i](Li)
        Mm[i - 1][i - 1] = pair(mi, Li); tb[i - 1] = pair(wc[i], Li)
        j = i
        while model[j - 1].parent > 0:
            j = model[j - 1].parent; v = pair(mi, K['L'][j]); Mm[j - 1][i - 1] = v; Mm[i - 1][j - 1] = v
        p = model[i - 1].parent
        if p > 0: Ic[p] = Ic[p] + Ic[i]; wc[p] = wc[p] + wc[i]
    return dict(M=Mm, tb=tb, K=K, P=P, I=Ii)
def forward(D, tau, cons=None):
    """eq. (28): [[M, K^T], [K, 0]] [q''; -lambda] = [tau - tau_bias; k] (k_s = 0 at an exact state); without K: Algorithm 1 line 29"""
    n = len(D['M']); rhs = [(tau[i] if tau else F(0)) - D['tb'][i] for i in range(n)]
    if not cons: return solve(D['M'], rhs), []
    Kr, kr = cons; m = len(Kr)
    big = [list(D['M'][i]) + [Kr[r][i] for r in range(m)] for i in range(n)] + [list(Kr[r]) + [F(0)] * m for r in range(m)]
    sol = solve(big, rhs + list(kr)); return sol[:n], [-x for x in sol[n:]]
def cterms(model, K, sp, cross=2, rel=False):
    """Algorithms 2-3: Phi = X o Y, the K columns (X x L_a) o Y and X o (Y x L_a), and k of eq. (27) with the cross-term coefficient 'cross'"""
    op = OPS[sp['op']]; i, j = sp['i'], sp['j']
    Xt, Yt = sand(K, i, sp['X0']), sand(K, j, sp['Y0'])
    if sp.get('dir'): Xt, Yt = euc(Xt), euc(Yt)
    Vi, Wi = (K['V'][i], K['W'][i]) if i else (ZERO, ZERO)
    Vj, Wj = (K['V'][j], K['W'][j]) if j else (ZERO, ZERO)
    k = -(op(cx(Xt, Wi) + cx(cx(Xt, Vi), Vi), Yt) + op(Xt, cx(Yt, Wj) + cx(cx(Yt, Vj), Vj)) + op(cx(Xt, Vi), cx(Yt, Vj)).scale(cross))
    pi, pj = path(model, i), path(model, j)
    if rel: cm = set(pi) & set(pj); pi = [a for a in pi if a not in cm]; pj = [a for a in pj if a not in cm]
    cols = {}
    for a in pi: cols[a] = cols.get(a, ZERO) + op(cx(Xt, K['L'][a]), Yt)
    for a in pj: cols[a] = cols.get(a, ZERO) + op(Xt, cx(Yt, K['L'][a]))
    return dict(Phi=op(Xt, Yt), cols=cols, k=k, X=Xt, Y=Yt)
def assemble(model, K, specs, cross=2, rel=False, keep=None):
    """stack the scalar components (sp['masks']) of every residual; keep a maximal independent set of K rows (the paper's unstated rule)"""
    n = len(model); rows = []
    for sp in specs:
        T = cterms(model, K, sp, cross, rel)
        for m in sp['masks']:
            rows.append(([T['cols'][a].d.get(m, F(0)) if a in T['cols'] else F(0) for a in range(1, n + 1)], T['k'].d.get(m, F(0)), T['Phi'].d.get(m, F(0))))
    if keep is None: keep = indep([r[0] for r in rows])
    return [rows[i][0] for i in keep], [rows[i][1] for i in keep], rows, keep
def run_pga(model, st, qd, tau=None, g=None, gmode='base', gsign=-1, imode='points', specs=None, cross=2, rel=False, springs=None, keep=None):
    """accelerations (and positions, velocities) of every mass point by Algorithm 1 (+ eq. 28 when specs are given); exact"""
    n = len(model); E = motors(model, st)
    ag = (E0 * vec3(g)) if (g is not None and gmode == 'base') else None
    def wfn(K, P):
        out = {}
        if g is not None and gmode == 'lines':
            gI = vec3(g) * PS
            for i, pl in P.items():
                for m, X in pl: out[i] = out.get(i, ZERO) + A.join(X, gI).scale(m)
        for (i1, x1, i2, x2, kk) in springs or []:
            X1, X2 = sand(K, i1, PT(x1)), sand(K, i2, PT(x2))
            out[i1] = out.get(i1, ZERO) + A.join(X1, X2).scale(kk); out[i2] = out.get(i2, ZERO) + A.join(X2, X1).scale(kk)
        return out
    D = alg1(model, E, qd, ag, wfn, imode, gsign); K = D['K']; cons = None; rows = None
    if specs: Kr, kr, rows, keep = assemble(model, K, specs, cross, rel, keep); cons = (Kr, kr)
    qdd, lam = forward(D, [tau[i] if tau else F(0) for i in range(1, n + 1)], cons)
    pos, vel, acc = {}, {}, {}
    for i in range(1, n + 1):
        if not model[i - 1].pts: continue
        Vi = K['V'][i]; Vd = K['W'][i]
        for a in path(model, i): Vd = Vd + K['L'][a].scale(qdd[a - 1])
        for k, (m, X) in enumerate(D['P'][i]):
            XV = cx(X, Vi); pos[(i, k)] = pvec(X); vel[(i, k)] = ivec(XV); acc[(i, k)] = ivec(cx(X, Vd) + cx(XV, Vi))
    return dict(D=D, K=K, qdd=qdd, lam=lam, pos=pos, vel=vel, acc=acc, rows=rows, keep=keep)

# ================================================================== [std]: mass points, Cartesian joint constraints, KKT (never touches PGA)
def std_kin(model, st, qd):
    T = {0: (EYE, [F(0)] * 3)}; tw = {0: ([F(0)] * 3, [F(0)] * 3)}
    for i in range(1, len(model) + 1):
        j = model[i - 1]; Rp, tp = T[j.parent]; om_p, v_p = tw[j.parent]; w = m_vec(Rp, j.u)
        if j.kind == 'R':
            c, s = st[i]; Rj = rodrigues(j.u, c, s); tj = v_sub(j.a, m_vec(Rj, j.a)); ap = v_add(m_vec(Rp, j.a), tp)
            tw[i] = (v_add(om_p, v_sc(qd[i], w)), v_sub(v_p, v_sc(qd[i], v_cross(w, ap))))
        else:
            Rj = EYE; tj = v_sc(st[i], j.u); tw[i] = (om_p, v_add(v_p, v_sc(qd[i], w)))
        T[i] = (m_mul(Rp, Rj), v_add(m_vec(Rp, tj), tp))
    return T, tw
class StdSys:
    def __init__(s, model, st, qd):
        s.model = model; s.T, s.tw = std_kin(model, st, qd); s.gidx = {}; s.r = []; s.v = []; s.m = []
        for i, j in enumerate(model, 1):
            R, t = s.T[i]; om, v0 = s.tw[i]
            for k, (m, x0) in enumerate(j.pts):
                x = v_add(m_vec(R, x0), t); s.gidx[(i, k)] = len(s.r); s.r.append(x); s.v.append(v_add(v_cross(om, x), v0)); s.m.append(m)
        s.cons = []; s.forces = [[F(0)] * 3 for _ in s.r]
        for i, j in enumerate(model, 1):                                          # rigid bodies: |r_a - r_b|^2 = const
            ks = [s.gidx[(i, k)] for k in range(len(j.pts))]
            for a in range(len(ks)):
                for b in range(a + 1, len(ks)):
                    dd = ({ks[a]: F(1), ks[b]: F(-1)}, [F(0)] * 3); x0 = v_sub(j.pts[a][1], j.pts[b][1])
                    s.cons.append(('dot', dd, dd, v_dot(x0, x0)))
    def _bary(s, i, x, w):
        ks = [s.gidx[(i, k)] for k in range(4)]
        al = solve([[s.r[k][c] for k in ks] for c in range(3)] + [[F(1)] * 4], list(x) + [F(w)])
        return {k: a for k, a in zip(ks, al) if a}
    def fpt(s, i, x0):                                                            # a body-fixed point: affine combination of the body's points
        x0 = [F(v) for v in x0]
        if i == 0: return ({}, x0)
        R, t = s.T[i]; return (s._bary(i, v_add(m_vec(R, x0), t), 1), [F(0)] * 3)
    def fdir(s, i, d0):                                                           # a body-fixed direction: weights summing to zero
        d0 = [F(v) for v in d0]
        if i == 0: return ({}, d0)
        return (s._bary(i, m_vec(s.T[i][0], d0), 0), [F(0)] * 3)
    def fval(s, f):
        r = list(f[1])
        for k, a in f[0].items(): r = v_add(r, v_sc(a, s.r[k]))
        return r
    def fvel(s, f):
        r = [F(0)] * 3
        for k, a in f[0].items(): r = v_add(r, v_sc(a, s.v[k]))
        return r
    @staticmethod
    def fdiff(f, g):
        cf = dict(f[0])
        for k, a in g[0].items(): cf[k] = cf.get(k, F(0)) - a
        return ({k: a for k, a in cf.items() if a}, v_sub(f[1], g[1]))
    def coincide(s, f, g):
        d = s.fdiff(f, g)
        for c in range(3): s.cons.append(('lin', d, [F(int(c == e)) for e in range(3)], F(0)))
    def add_joint(s, kind, *a):
        if kind == 'R':                                                           # coincident axis point + axis of the parent normal to two child directions
            bp, bc, a0, u = a; w1, w2 = perp(u); s.coincide(s.fpt(bp, a0), s.fpt(bc, a0)); up = s.fdir(bp, u)
            s.cons += [('dot', up, s.fdir(bc, w1), F(0)), ('dot', up, s.fdir(bc, w2), F(0))]
        elif kind == 'P':                                                         # parallel axes (2), no rotation about them (1), on the axis (2)
            bp, bc, a0, u = a; w1, w2 = perp(u); uc = s.fdir(bc, u); w1p, w2p = s.fdir(bp, w1), s.fdir(bp, w2)
            dd = s.fdiff(s.fpt(bc, a0), s.fpt(bp, a0))
            s.cons += [('dot', uc, w1p, F(0)), ('dot', uc, w2p, F(0)), ('dot', s.fdir(bc, w1), w2p, F(0)), ('dot', dd, w1p, F(0)), ('dot', dd, w2p, F(0))]
        elif kind == 'U':
            bp, bc, a0, u, w = a; s.coincide(s.fpt(bp, a0), s.fpt(bc, a0)); s.cons.append(('dot', s.fdir(bp, u), s.fdir(bc, w), F(0)))
        elif kind == 'S':
            bp, bc, a0 = a; s.coincide(s.fpt(bp, a0), s.fpt(bc, a0))
        elif kind == 'cutS':                                                      # x2 = None: the point of b2 now at the place of x1 of b1
            b1, b2, x1, x2 = a; f1 = s.fpt(b1, x1)
            if x2 is None: R, t = s.T[b2]; x2 = m_vec(m_T(R), v_sub(s.fval(f1), t))
            s.cut_y0 = x2; s.coincide(f1, s.fpt(b2, x2))
        elif kind == 'plane':                                                     # n . x = delta; delta = None: the plane through the point now
            b, x, n, dl = a; f = s.fpt(b, x); n = [F(v) for v in n]
            s.cons.append(('lin', f, n, v_dot(n, s.fval(f)) if dl is None else F(dl)))
    def gravity(s, g):
        for k in range(len(s.r)): s.forces[k] = v_add(s.forces[k], v_sc(s.m[k], [F(x) for x in g]))
    def point_force(s, f, Fv):
        for k, a in f[0].items(): s.forces[k] = v_add(s.forces[k], v_sc(a, Fv))
    def couple(s, i, Tv):                                                         # a pure torque Tv on body i as three point forces (least norm)
        if i == 0 or not s.model[i - 1].pts: return
        k1, k2, k3 = [s.gidx[(i, k)] for k in range(3)]; d1, d2 = v_sub(s.r[k1], s.r[k3]), v_sub(s.r[k2], s.r[k3])
        Cm = lambda d: [[F(0), -d[2], d[1]], [d[2], F(0), -d[0]], [-d[1], d[0], F(0)]]
        A6 = [Cm(d1)[r] + Cm(d2)[r] for r in range(3)]; G = [[v_dot(A6[a], A6[b]) for b in range(3)] for a in range(3)]
        y = solve(G, list(Tv)); f6 = [sum((A6[r][c] * y[r] for r in range(3)), F(0)) for c in range(6)]
        f1, f2 = f6[:3], f6[3:]
        for k, fv in ((k1, f1), (k2, f2), (k3, v_sc(-1, v_add(f1, f2)))): s.forces[k] = v_add(s.forces[k], fv)
    def jac(s):
        N3 = 3 * len(s.r); rows, gam, res = [], [], []
        for con in s.cons:
            J = [F(0)] * N3
            if con[0] == 'lin':
                _, f, nv, tgt = con
                for k, a in f[0].items():
                    for c in range(3): J[3 * k + c] += a * nv[c]
                rows.append(J); gam.append(F(0)); res.append(v_dot(nv, s.fval(f)) - tgt)
            else:
                _, f, g, tgt = con; fv, gv = s.fval(f), s.fval(g)
                for k, a in f[0].items():
                    for c in range(3): J[3 * k + c] += a * gv[c]
                for k, a in g[0].items():
                    for c in range(3): J[3 * k + c] += a * fv[c]
                rows.append(J); gam.append(2 * v_dot(s.fvel(f), s.fvel(g))); res.append(v_dot(fv, gv) - tgt)
        return rows, gam, res
    def accelerations(s):
        """KKT [M J^T; J 0][a; -lambda] = [f; -(J' v)] after removing dependent rows (Schur complement on lambda)"""
        rows, gam, res = s.jac(); keep = indep(rows); Jr = [rows[i] for i in keep]; gr = [gam[i] for i in keep]
        nc = 3 * len(s.r); minv = [1 / s.m[c // 3] for c in range(nc)]; fl = [x for fv in s.forces for x in fv]
        Sm = [[sum((Ja[c] * minv[c] * Jb[c] for c in range(nc) if Ja[c] and Jb[c]), F(0)) for Jb in Jr] for Ja in Jr]
        rhs = [-g_ - sum((Ja[c] * minv[c] * fl[c] for c in range(nc) if Ja[c]), F(0)) for Ja, g_ in zip(Jr, gr)]
        lam = solve(Sm, rhs)
        a = [minv[c] * (fl[c] + sum((Jr[r][c] * lam[r] for r in range(len(Jr)) if Jr[r][c]), F(0))) for c in range(nc)]
        s.rank = len(keep); s.dofs = nc - len(keep); s.res = res
        s.Jv = [sum((J[c] * s.v[c // 3][c % 3] for c in range(nc) if J[c]), F(0)) for J in rows]
        return [a[3 * k: 3 * k + 3] for k in range(len(s.r))]
def run_std(model, st, qd, stdj, tau=None, g=None, springs=None):
    S = StdSys(model, st, qd)
    for jj in stdj: S.add_joint(*jj)
    if g is not None: S.gravity(g)
    for i, j in enumerate(model, 1):
        ti = tau[i] if tau else 0
        if not ti: continue
        w = m_vec(S.T[j.parent][0], j.u)
        if j.kind == 'R': S.couple(i, v_sc(ti, w)); S.couple(j.parent, v_sc(-ti, w))
        else: S.point_force(S.fpt(i, j.a), v_sc(ti, w)); S.point_force(S.fpt(j.parent, j.a), v_sc(-ti, w))
    for (i1, x1, i2, x2, kk) in springs or []:
        f1, f2 = S.fpt(i1, x1), S.fpt(i2, x2); p1, p2 = S.fval(f1), S.fval(f2)
        S.point_force(f1, v_sc(kk, v_sub(p2, p1))); S.point_force(f2, v_sc(kk, v_sub(p1, p2)))
    acc = S.accelerations()
    return dict(S=S, acc={key: acc[S.gidx[key]] for key in S.gidx}, pos={key: S.r[S.gidx[key]] for key in S.gidx}, vel={key: S.v[S.gidx[key]] for key in S.gidx})

# ================================================================== motions as exact series
def rand_Vt(rng, deg=2): return MVd({b: TS.poly([rq(rng) for _ in range(deg + 1)]) for b in BIV})
def motor_curve(N0, Vt):
    """N' = (1/2) N V (paper: V = 2 N~ N'), Picard, exact through order TS.N"""
    X = mv_ts(N0)
    for _ in range(TS.N + 1): X = mv_integ((X * Vt).scale(HALF), N0)
    return X
def half_angle_series(c0, s0, qd):
    c, s = TS.const(c0), TS.const(s0)
    for _ in range(TS.N + 1): c, s = (-(HALF * qd * s)).integ(c0), (HALF * qd * c).integ(s0)
    return c, s
def flow(model, st0, qd0, rhs, iters):
    """exact series solution of a joint-space ODE (Picard): R joints carry (c, s, q'), P joints (q, q')"""
    n = len(model); S = {}
    for i in range(1, n + 1):
        S[i] = [TS.const(st0[i][0]), TS.const(st0[i][1]), TS.const(qd0[i])] if model[i - 1].kind == 'R' else [TS.const(st0[i]), TS.const(qd0[i])]
    def unpack(S): return ([None] + [(S[i][0], S[i][1]) if model[i - 1].kind == 'R' else S[i][0] for i in range(1, n + 1)], [None] + [S[i][-1] for i in range(1, n + 1)])
    for _ in range(iters):
        stt, qd = unpack(S); qdd = [ts(x) for x in rhs(stt, qd)]; new = {}
        for i in range(1, n + 1):
            if model[i - 1].kind == 'R':
                c, s, w = S[i]; new[i] = [(-(HALF * w * s)).integ(st0[i][0]), (HALF * w * c).integ(st0[i][1]), qdd[i - 1].integ(qd0[i])]
            else:
                q, w = S[i]; new[i] = [w.integ(st0[i]), qdd[i - 1].integ(qd0[i])]
        S = new
    return unpack(S), S
def energy(model, stt, qd, g, gsign=1):
    """E = (1/2) sum V_i v I_i(V_i) (FRQ-002's join pairing) - sum m g.p (ours); also the top-blade form (1/2)(I(V) ^ V)*"""
    K = pga_kin(model, motors(model, stt), qd); T = F(0); T2 = F(0); U = F(0)
    for i, j in enumerate(model, 1):
        if not j.pts: continue
        N = K['Mo'][i]; Nr = N.rev(); pts = [(m, Nr * PT(x) * N) for m, x in j.pts]; Ii = inertia_points(pts); Vi = K['V'][i]
        T = T + A.join(Vi, Ii(Vi)).scalar() * F(1, 2); T2 = T2 + pair(Ii(Vi), Vi) * F(1, 2)
        for m, X in pts: U = U - gsign * m * v_dot([F(x) for x in g], pvec(X))
    return T + U, T, T2, K

# ================================================================== (a) the single body
def part_a():
    head('(a) single body: eq. (13) w = I(V\') + I(V) x V in the inertial frame against step 14, exact series')
    Ns = 6; Sr = fq.Ser; o = Ns - 3; R = {}
    def add(k, v): R.setdefault(k, []).append(v)
    for kind in (('gravity',) if QUICK else ('free', 'gravity', 'hooke')):
        for seed in (1, 2):
            rng = random.Random(100 + seed); body = fq.generic_body(A, rng, 4); M0 = A.rand_motor(rng); B0 = A.rand_bivector_nz(rng)
            gI = vec3([0, -1, 0]) * PS; Cb = A.point(body.c); Aw = A.point([F(1), F(2), F(0)]); Pb = body.X[0]; kk = F(3)
            def Fb(S):
                M = S[0]
                if kind == 'free': return Sr.const(ZERO, Ns)
                if kind == 'gravity': return fq.bil_ser(A.join, Sr.const(Cb, Ns), M.rev() * Sr.const(gI, Ns) * M).scale(body.m)
                return fq.bil_ser(A.join, Sr.const(Pb, Ns), M.rev() * Sr.const(Aw, Ns) * M).scale(kk)
            def atlas_flow(bracket):                                          # step 14: M' = -1/2 M B, B' = A^-1(F + B x A(B)); bracket 2 = [ctl] doubled
                def f(S):
                    M, B = S; IB = fq.lin_ser(body.I, B)
                    return [(M * B).scale(-HALF), fq.lin_ser(body.Iinv, fq.comm_ser(A, B, IB).scale(bracket) + Fb(S))]
                return fq.picard(f, [M0, B0], Ns)
            def eq13(M, B, naive=False):
                """the paper's quantities from the Atlas motor: N = M~ (naive: N = M); returns V, I(.), lhs of (13), w"""
                Nn = M if naive else M.rev(); V = (Nn.rev() * Nn.d_dt()).scale(2)
                Xs = [Nn.rev() * Sr.const(X, Ns) * Nn for X in body.X]
                def It(Y):
                    tot = Sr.const(ZERO, Ns)
                    for (m, _), X in zip(body.pts, Xs): tot = tot + fq.bil_ser(A.join, X, fq.comm_ser(A, X, Y)).scale(m)
                    return tot
                if kind == 'free': wp = Sr.const(ZERO, Ns)
                elif kind == 'gravity': wp = sum((fq.bil_ser(A.join, X, Sr.const(gI, Ns)).scale(m) for (m, _), X in zip(body.pts, Xs)), Sr.const(ZERO, Ns))
                else: wp = fq.bil_ser(A.join, Xs[0], Sr.const(Aw, Ns)).scale(kk)
                return V, It, It(V.d_dt()) + fq.comm_ser(A, It(V), V), wp
            M, B = atlas_flow(1); V, It, lhs, wp = eq13(M, B); Fw = M * Fb([M, B]) * M.rev(); IV = It(V)
            add('a1', all(c.grades() <= {2} for c in V.c[:o]) and fq.ser_equal(V, M * B * M.rev(), o))
            add('a2', fq.ser_equal(IV, M * fq.lin_ser(body.I, B) * M.rev(), o))
            add('a3', fq.ser_equal(V.d_dt(), M * B.d_dt() * M.rev(), o))
            add('a4', fq.ser_equal(lhs, Fw, o)); add('a5', fq.ser_equal(wp, Fw, o))
            add('a6', any(not c.is_zero() for c in fq.comm_ser(A, IV, V).c[:o]) and (kind == 'free' or any(not c.is_zero() for c in Fw.c[:o])))
            add('ac1', not fq.ser_equal(It(V.d_dt()) - fq.comm_ser(A, IV, V), Fw, o))
            add('ac2', not fq.ser_equal(It(B.d_dt()) + fq.comm_ser(A, It(B), B), Fw, o))
            Vb = M.rev() * B * M; add('ac3', not fq.ser_equal(It(Vb.d_dt()) + fq.comm_ser(A, It(Vb), Vb), Fw, o))
            if kind != 'free': add('ac4', not fq.ser_equal(lhs, M.rev() * Fb([M, B]) * M, o))
            M2, B2 = atlas_flow(2); _, _, lhs2, wp2 = eq13(M2, B2); add('ac5', not fq.ser_equal(lhs2, wp2, o))
            Vn, _, lhsn, wpn = eq13(M, B, naive=True); add('a6n', fq.ser_equal(Vn, B.scale(-1), o)); add('ac6', not fq.ser_equal(lhsn, wpn, o))
            AB = body.I(B0); add('a7', (B0 * AB - AB * B0).scale(F(1, 2)) == cx(B0, AB) and cx(B0, AB) != (B0 * AB - AB * B0))
    n = len(R['a1'])
    chk('bit', all(R['a1']), "(a1) N = M~: V = 2 N~ N' is a bivector and equals M B M~ along step 14's flow (%d flows, series order %d)" % (n, o))
    chk('bit', all(R['a2']), '(a2) I(V) = sum m P v (P x V) with the moving points P = N~ P0 N equals M A(B) M~ (%d flows)' % n)
    chk('bit', all(R['a3']), "(a3) V' = M B' M~ (%d flows)" % n)
    chk('bit', all(R['a4']), "(a4) eq. (13): I(V') + I(V) x V = w with w = M F M~, F = step 14's forque (free, weight line, Hooke line to a world point; %d flows)" % n)
    chk('bit', all(R['a5']), '(a5) w = M F M~ equals the force lines of the points: sum m P v (g I) for the weight, k P v A_w for the spring (%d flows)' % n)
    chk('bit', all(R['a6']), '(a6) not vacuous: I(V) x V and w are nonzero along every flow')
    chk('bit', all(R['a7']), "(a7) (1/2)(B A(B) - A(B) B) = B x A(B): EQN-019's [.,.] is the plain commutator (x = half of it)")
    chk('bit', all(R['a6n']), "(a6n) reading the paper's motor as the Atlas M gives V = 2 M~ M' = -B")
    for key, what in (('ac1', 'sign of I(V) x V reversed'), ('ac2', 'body velocity B in place of V'), ('ac3', 'V = M~ B M (other sandwich)'),
                      ('ac4', 'w = M~ F M'), ('ac5', 'bracket doubled in the Atlas flow (1/2[B, A(B)] read as the full commutator)'), ('ac6', "paper's motor read as the Atlas M")):
        chk('ctl', all(R[key]), '(%s) eq. (13) fails with %s (%d of %d)' % (key, what, sum(R[key]), len(R[key])))
    if QUICK: return
    mats = []; sym = True
    for s_ in range(24):
        rng = random.Random(500 + s_); bd = fq.generic_body(A, rng, rng.randint(1, 5)); mats.append([x for row in bd.matrix() for x in row])
        sym &= all(pair(bd.I(blade(a)), blade(b)) == pair(bd.I(blade(b)), blade(a)) for a in BIV for b in BIV)
    rk = len(indep(mats))
    chk('bit', rk == 10 and sym, '(a8) ours: the rigid inertias {sum m P P^T} span %d dimensions (expected 10) of the 21 symmetric maps on bivectors; each is symmetric in the pairing (24 random bodies)' % rk)

# ================================================================== (b) joints as incidences
def part_b():
    head('(b) joints as incidences (Table 3, p. 9): along joint motions (exact series), ranks and kernels of the linearised residuals')
    TS.N = 6; rng = random.Random(7)
    J0 = [F(1, 2), F(-1), F(3, 2)]; u, w, v = UV['a'], UV['b'], UV['c']; d = [F(1, 3), F(2, 3), F(0)]
    P0 = PT(J0); Lu, Lw = LINE(J0, u), LINE(J0, w); pl = PLANE(u, v_dot([F(x) for x in u], J0)); g2, g2e = gmask(2), gmask(2, True)
    CAT = [('revolute', [('R', Lu)], [('v', P0, P0, False, g2), ('x', Lu, Lu, True, g2e)], 5, [3, 5], ('R', LINE(v_add(J0, d), u)), 'paper'),
           ('prismatic', [('P', TGEN(u))], [('x', Lu, Lu, False, g2), ('x', Lw, Lw, True, g2e)], 5, [4, 5], ('R', Lu), 'paper'),
           ('spherical', [('R', Lu), ('R', Lw), ('R', LINE(J0, v))], [('v', P0, P0, False, g2)], 3, [3], ('P', TGEN(w)), 'paper'),
           ('universal', [('R', Lu), ('R', Lw)], [('v', P0, P0, False, g2), ('.', Lu, Lw, True, [0])], 4, [3, 4], ('R', LINE(J0, v)), 'paper'),
           ('cylindrical', [('R', Lu), ('P', TGEN(u))], [('x', Lu, Lu, False, g2)], 4, [4], ('R', Lw), 'ours'),
           ('planar', [('P', TGEN(w)), ('P', TGEN(v)), ('R', Lu)], [('^', pl, pl, False, g2)], 3, [3], ('R', Lw), 'ours')]
    def jseries(kind, rng):
        if kind == 'R': c0, s0 = half_angle(rq(rng)); return half_angle_series(c0, s0, TS.poly([rqn(rng), rq(rng)]))
        return TS.poly([rq(rng), rqn(rng), rq(rng)])
    def phis(Np, Nc, rels, Y0override=None):
        out = []
        for idx, (op, X0, Y0, dr, ms) in enumerate(rels):
            if Y0override is not None and idx == 0: Y0 = Y0override
            X, Y = Np.rev() * X0 * Np, Nc.rev() * Y0 * Nc
            if dr: X, Y = euc(X), euc(Y)
            out.append((OPS[op](X, Y), ms))
        return out
    for name, gens, rels, rk, incr_exp, wrong, who in CAT:
        Np = motor_curve(A.rand_motor(rng), rand_Vt(rng)); Nc = Np
        for kind, G in gens: Nc = gen_motor(kind, G, jseries(kind, rng)) * Nc
        hold = all(mv_zero(Ph, TS.N, ms) for Ph, ms in phis(Np, Nc, rels))
        Nw = gen_motor(wrong[0], wrong[1], jseries(wrong[0], rng)) * Nc                     # applied first to the child's features
        bad = not all(mv_zero(Ph, TS.N, ms) for Ph, ms in phis(Np, Nw, rels))
        Y0d = A.sand(A.trans(d), rels[0][2]); disp = not mv_zero(phis(Np, Nc, rels, Y0d)[0][0], 0, rels[0][4])
        tag = '' if who == 'paper' else ' [ours: not in the paper]'
        chk('bit', hold, '(b1) %s%s: the Table-3 relations vanish identically along a motion generated by its %d axis(es), parent on a random motor curve (series order %d)' % (name, tag, len(gens), TS.N))
        chk('ctl', bad, '(bc1) %s: one generator outside the joint violates them' % name)
        chk('ctl', disp, '(bc2) %s: a child feature displaced at t = 0 violates them at t = 0' % name)
        Np0 = A.rand_motor(rng); Nk = Np0; Gc = []
        for kind, G in gens:
            Gc.append(Nk.rev() * G * Nk); Nk = gen_motor(kind, G, half_angle(rqn(rng)) if kind == 'R' else rqn(rng)) * Nk
        rows = []; incr = []; kern = True
        for op, X0, Y0, dr, ms in rels:
            X, Y = Np0.rev() * X0 * Np0, Nk.rev() * Y0 * Nk
            if dr: X, Y = euc(X), euc(Y)
            cols = [OPS[op](X, cx(Y, blade(b))) for b in BIV]
            for m in ms: rows.append([c.d.get(m, F(0)) for c in cols])
            incr.append(len(indep(rows)))
            kern &= all(not any(OPS[op](X, cx(Y, G)).d.get(m, F(0)) for m in ms) for G in Gc)
        rank = len(indep(rows)); grank = len(indep([[G.d.get(b, F(0)) for b in BIV] for G in Gc]))
        chk('bit', rank == rk and incr == incr_exp and kern and rank + grank == 6,
            '(b2) %s%s: the linearised residual has rank %d (relation by relation %s; expected %d, %s) and its kernel is exactly the span of the %d current joint axes' % (name, tag, rank, incr, rk, incr_exp, grank))

# ================================================================== (c) the differentiation chain
def part_c():
    head('(c) the differentiation chain (19)-(27): exact derivatives of Phi = X o Y along exact-series motions')
    TS.N = 6; rng = random.Random(11); Nn = TS.N
    Vi, Vj = rand_Vt(rng), rand_Vt(rng); Ni, Nj = motor_curve(A.rand_motor(rng), Vi), motor_curve(A.rand_motor(rng), Vj)
    Vid, Vjd = mv_d(Vi), mv_d(Vj); Bi, Bj = Ni * Vi * Ni.rev(), Nj * Vj * Nj.rev()
    P1, P2 = PT([1, 2, -1]), PT([0, -1, 2]); pl1, pl2 = PLANE(UV['c'], F(1, 2)), PLANE(UV['q'], -1)
    L1, L2 = LINE([1, 0, 2], UV['a']), LINE([0, 1, -1], UV['p'])
    PAIRS = [('point-point v', 'v', P1, P2, False), ('point-plane ^', '^', P1, pl1, False), ('point-line v', 'v', P1, L2, False),
             ('line-plane ^', '^', L1, pl1, False), ('plane-plane ^', '^', pl1, pl2, False), ('plane-plane .', '.', pl1, pl2, False),
             ('line-line x', 'x', L1, L2, False), ('line-line .', '.', L1, L2, False), ('direction x (L^ x L^)', 'x', L1, L2, True), ('direction . (L^ . L^)', '.', L1, L2, True)]
    R = {}
    def add(k, v): R.setdefault(k, []).append(v)
    for name, ops, X0, Y0, dr in PAIRS:
        op = OPS[ops]; X, Y = Ni.rev() * X0 * Ni, Nj.rev() * Y0 * Nj
        if dr: X, Y = euc(X), euc(Y)
        ms = gmask(0) + gmask(1) + gmask(2) + gmask(3) + gmask(4)
        if dr: ms = [m for m in ms if not m & 1]
        Phi = op(X, Y); d1 = mv_d(Phi); d2 = mv_d(d1)
        def f2(V1, V2, V1d, V2d, cross):
            return op(cx(X, V1d) + cx(cx(X, V1), V1), Y) + op(X, cx(Y, V2d) + cx(cx(Y, V2), V2)) + op(cx(X, V1), cx(Y, V2)).scale(cross)
        f1 = op(cx(X, Vi), Y) + op(X, cx(Y, Vj)); cr = op(cx(X, Vi), cx(Y, Vj))
        add('c1', mv_eq(d1, f1, Nn - 1, ms)); add('c2', mv_eq(d2, f2(Vi, Vj, Vid, Vjd, 2), Nn - 2, ms))
        add('c3', not mv_zero(cr, 0, ms))
        add('cc1', not mv_eq(d2, f2(Vi, Vj, Vid, Vjd, -2), Nn - 2, ms)); add('cc2', not mv_eq(d2, f2(Vi, Vj, Vid, Vjd, 1), Nn - 2, ms))
        add('cc3', not mv_eq(d2, f2(Bi, Bj, mv_d(Bi), mv_d(Bj), 2), Nn - 2, ms))
        if dr and ops == 'x': add('c4', mv_zero(d1, Nn - 1, [m for m in range(16) if m & 1]) and not mv_zero(f1, 0, [m for m in range(16) if m & 1]))
    np_ = len(PAIRS)
    chk('bit', all(R['c1']), "(c1) Phi' = (X x V_i) o Y + X o (Y x V_j) for all %d relation types (o = v, ^, x, .), as series through order %d" % (np_, Nn - 1))
    chk('bit', all(R['c2']), "(c2) Phi'' = (X x V_i' + X x V_i x V_i) o Y + X o (Y x V_j' + Y x V_j x V_j) + 2 (X x V_i) o (Y x V_j) for all %d, through order %d" % (np_, Nn - 2))
    chk('bit', all(R['c3']), '(c3) not vacuous: the cross term (X x V_i) o (Y x V_j) is nonzero at t = 0 for every relation')
    chk('bit', all(R['c4']), '(c4) direction parts L^ = u I3: the chain holds on the Euclidean components only; the formula has nonzero e0 components where Phi has none (they must be dropped)')
    chk('ctl', all(R['cc1']), '(cc1) cross term with the sign reversed (-2): Phi\'\' differs (%d of %d)' % (sum(R['cc1']), np_))
    chk('ctl', all(R['cc2']), '(cc2) the factor 2 of the cross term dropped: Phi\'\' differs (%d of %d)' % (sum(R['cc2']), np_))
    chk('ctl', all(R['cc3']), '(cc3) body-frame velocities B = N V N~ in place of V: Phi\'\' differs (%d of %d)' % (sum(R['cc3']), np_))
    if QUICK: return
    # trees: (14), (15), Algorithm 1 line 7, (22), Algorithms 2-3
    T4 = [Jt(0, 'R', (0, 0, 0), UV['z']), Jt(1, 'R', (1, 0, -1), UV['a']), Jt(2, 'P', (0, 0, 0), UV['b']), Jt(1, 'R', (-1, 1, -1), UV['p']), Jt(0, 'R', (0, 2, 0), UV['q'])]
    n = len(T4); qd0 = [None] + [rqn(rng) for _ in T4]; qdd0 = [None] + [rqn(rng) for _ in T4]; st = [None]; qdt = [None]
    for i, j in enumerate(T4, 1):
        qq = TS.poly([qd0[i], qdd0[i]]); qdt.append(qq)
        st.append(half_angle_series(*half_angle(rq(rng)), qq) if j.kind == 'R' else TS.poly([rq(rng), qd0[i], qdd0[i] / 2]))
    K = pga_kin(T4, motors(T4, st), qdt)
    ok14 = ok7 = ok15 = ok22 = True
    for i in range(1, n + 1):
        p = T4[i - 1].parent; Mo = K['Mo'][i]; Vr = (Mo.rev() * mv_d(Mo)).scale(2)
        ok14 &= mv_eq(Vr, K['V'][i], Nn - 1); ok7 &= mv_eq(mv_d(K['L'][i]), cx(K['L'][i], K['V'][p]), Nn - 1)
        ok15 &= mv_eq(mv_d(K['V'][i]), mv_d(K['V'][p]) + K['L'][i].scale(qdt[i].d()) + K['Ld'][i].scale(qdt[i]), Nn - 2)
        ok22 &= mv_c(mv_d(K['V'][i])) == mv_c(K['W'][i]) + sum_mv([mv_c(K['L'][a]).scale(qdd0[a]) for a in path(T4, i)])
    chk('bit', ok14, "(c5) eq. (14) on a 5-joint tree with a prismatic joint: V_i = 2 N~_i N_i' = V_p(i) + L_i q_i' (series through order %d)" % (Nn - 1))
    chk('bit', ok7, "(c6) Algorithm 1 line 7: L_i' = L_i x V_p(i) (series)")
    chk('bit', ok15, "(c7) eq. (15): V_i' = V_p(i)' + L_i q_i'' + L_i' q_i' (series)")
    chk('bit', ok22, "(c8) eq. (22): V_i' = sum over the path of L_k q_k'' + W_i at t = 0")
    def at0(sp, cross=2, rel=False):
        T = cterms(T4, K, sp, cross, rel)
        Kq = sum_mv([mv_c(c).scale(qdd0[a]) for a, c in T['cols'].items()]); Kv = sum_mv([mv_c(c).scale(qd0[a]) for a, c in T['cols'].items()])
        return T, mv_c(T['Phi'], 1), mv_c(T['Phi'], 2).scale(2), Kv, Kq - mv_c(T['k'])
    env = [dict(op='^', X0=PT([2, 1, -1]), i=3, Y0=pl1, j=0), dict(op='v', X0=PT([2, 1, -1]), i=3, Y0=L2, j=0), dict(op='x', X0=LINE([1, 1, 0], UV['b']), i=3, Y0=L2, j=0),
           dict(op='.', X0=LINE([1, 1, 0], UV['b']), i=3, Y0=L2, j=0), dict(op='.', X0=PLANE(UV['r'], 1), i=3, Y0=pl2, j=0)]
    e1 = e2 = True
    for sp in env: _, p1, p2, Kv, Kqk = at0(sp); e1 &= p1 == Kv; e2 &= p2 == Kqk
    chk('bit', e1, "(c9) environmental, Algorithm 2: Phi'(0) = K q' for o = ^, v, x, . (point-plane, point-line, line-line x2, plane-plane)")
    chk('bit', e2, "(c10) environmental, eqs. (21)-(22): Phi''(0) = K q'' - k with k = -(X x W + X x V x V) o Y_d (5 relation types)")
    cut = [dict(op='v', X0=PT([2, 1, -1]), i=3, Y0=PT([-1, 2, 0]), j=4), dict(op='x', X0=LINE([1, 1, 0], UV['b']), i=3, Y0=LINE([0, 0, 1], UV['c']), j=4),
           dict(op='.', X0=LINE([1, 1, 0], UV['b']), i=3, Y0=LINE([0, 0, 1], UV['c']), j=4)]
    c11 = cc4 = cc5 = True
    for sp in cut:
        _, _, p2, _, Kqk = at0(sp); c11 &= p2 == Kqk; cc4 &= p2 != at0(sp, -2)[4]; cc5 &= p2 != at0(sp, 1)[4]
    chk('bit', c11, "(c11) cut joint, eqs. (26)-(27) with the full paths: Phi''(0) = K q'' - k including -2 (X x V_i) o (Y x V_j) (point-point v, line-line x and .)")
    chk('ctl', cc4, '(cc4) cut joint with the cross term reversed: Phi\'\'(0) differs (3 of 3)')
    chk('ctl', cc5, '(cc5) cut joint with the factor 2 dropped: Phi\'\'(0) differs (3 of 3)')
    sp = cut[0]; T, _, p2, _, Kqk = at0(sp); _, _, _, _, Kqk_rel = at0(sp, rel=True); Phi0 = mv_c(T['Phi'])
    chk('ctl', not Phi0.is_zero() and Kqk_rel != p2, '(cc6) Algorithm 3 relative path (common ancestor body 1) with Phi != 0: K_rel q\'\' - k differs from Phi\'\'(0)')
    chk('bit', p2 - Kqk_rel == cx(Phi0, mv_c(K['L'][1])).scale(qdd0[1]), '(c12) ... and the difference is exactly (Phi x L_1) q_1\'\', the term of the common joint')
    Y0z = mv_c(K['Mo'][4]) * mv_c(T['X']) * mv_c(K['Mo'][4]).rev(); spz = dict(sp, Y0=Y0z)
    Tz, _, p2z, _, Kz = at0(spz); _, _, _, _, Kz_rel = at0(spz, rel=True)
    chk('bit', mv_c(Tz['Phi']).is_zero() and Kz == p2z and Kz_rel == p2z, "(c13) with Phi(0) = 0 (Y0 placed at X's current point) the relative-path K is exact")
    sps = cut[2]; Ts, _, p2s, _, _ = at0(sps); _, _, _, _, Ks_rel = at0(sps, rel=True)
    chk('bit', not mv_c(Ts['Phi']).is_zero() and Ks_rel == p2s, '(c14) a scalar residual (line-line .) with Phi != 0: the relative-path K is exact (scalars commute with L_1)')
    spb = dict(op='v', X0=PT([2, 1, -1]), i=3, Y0=PT([0, 2, 1]), j=5); Tb, _, p2b, _, Kb = at0(spb); _, _, _, _, Kb_rel = at0(spb, rel=True)
    chk('bit', not mv_c(Tb['Phi']).is_zero() and Kb == p2b and Kb_rel == p2b, '(c15) common ancestor = the base: relative and full paths coincide and are exact with Phi != 0')

# ================================================================== (d) multipliers and Algorithm 1 against [std]
def same(a, b): return a.keys() == b.keys() and all(a[k] == b[k] for k in a)
def part_d():
    head('(d) eq. (28) and Algorithm 1 against mass points with Cartesian joint constraints (KKT), exact, random rational states')
    rng = random.Random(23); g = [F(1, 2), F(-1), F(-10)]
    J1 = Jt(0, 'R', (0, 0, 0), UV['a'], rand_pts(rng, (1, -1, -1))); J2 = Jt(1, 'R', (1, -1, -2), UV['p'], rand_pts(rng, (2, 0, -3)))
    mA = [J1, J2]; sA = [('R', 0, 1, J1.a, J1.u), ('R', 1, 2, J2.a, J2.u)]
    Ja, Jb, Jc = Jt(1, 'R', J2.a, UV['p']), Jt(2, 'R', J2.a, UV['q']), Jt(3, 'R', J2.a, UV['r'], [(m, x) for m, x in J2.pts])
    mAc = [J1, Ja, Jb, Jc]; specAc = [dict(op='x', X0=DIRL(UV['p']), i=1, Y0=DIRL(UV['p']), j=4, dir=True, masks=gmask(2, True))]
    xe = [3, 0, -4]; nE = UV['c']; spring = [(1, [1, -2, 0], 2, [2, 1, -3], F(3))]
    R = {}
    def add(k, v): R.setdefault(k, []).append(v)
    def common(tag, Pg, Sg, dofs):
        add('d1', same(Pg['pos'], Sg['pos'])); add('d2', same(Pg['vel'], Sg['vel']))
        add('d3', all(x == 0 for x in Sg['S'].res) and all(x == 0 for x in Sg['S'].Jv) and Sg['S'].dofs == dofs)
        add('d4', same(Pg['acc'], Sg['acc'])); add('d4_' + tag, same(Pg['acc'], Sg['acc']))
        M_ = Pg['D']['M']; add('d7', all(M_[a][b] == M_[b][a] for a in range(len(M_)) for b in range(len(M_))) and all(M_[a][a] > 0 for a in range(len(M_)) if any(M_[a])))
        if Pg['rows']: add('d8', all(sum((r[0][a] * Pg['qdd'][a] for a in range(len(Pg['qdd']))), F(0)) - r[1] == 0 for r in Pg['rows'])); add('d8n', (len(Pg['rows']), len(Pg['keep'])))
    for trial in range(1 if QUICK else 2):
        stA = [None, half_angle(rq(rng)), half_angle(rq(rng))]; qdA = [None, rqn(rng), rqn(rng)]; tau = [None, rq(rng), rq(rng)]
        PA = run_pga(mA, stA, qdA, tau, g); SA = run_std(mA, stA, qdA, sA, tau, g); common('A', PA, SA, 2)
        add('d5', same(run_pga(mA, stA, qdA, tau, g, gmode='lines')['acc'], SA['acc']) and run_pga(mA, stA, qdA, tau, g, gmode='lines')['qdd'] == PA['qdd'])
        add('d6', all(inertia_points(PA['D']['P'][i]).imgs == inertia_dict(PA['K']['Mo'][i], body_A(mA[i - 1])).imgs for i in (1, 2))
            and same(run_pga(mA, stA, qdA, tau, g, imode='dict')['acc'], SA['acc']))
        Eg, T, T2, _ = energy(mA, stA, qdA, g); Tstd = sum((m * v_dot(SA['vel'][(i, k)], SA['vel'][(i, k)]) for i in (1, 2) for k, (m, _) in enumerate(mA[i - 1].pts)), F(0)) / 2
        add('d9', T == Tstd and T2 == Tstd and T > 0)
        add('dc1', not same(run_pga(mA, stA, qdA, tau, g, gsign=1)['acc'], SA['acc']))
        add('dc2', not same(run_pga(mA, stA, qdA, tau, g, imode='body')['acc'], SA['acc']))
        add('dc3', not same(run_pga(mA, stA, qdA, tau, g, imode='nonrigid3')['acc'], SA['acc']))
        add('i_e01', (not same(run_pga(mA, stA, qdA, tau, g, imode='nonrigid1')['acc'], SA['acc']), stA[1:]))
        add('dc4', not same(run_pga(mA, stA, qdA, [None, -tau[1], -tau[2]], g)['acc'], SA['acc']))
        SH = run_std(mA, stA, qdA, sA, tau, g, spring); add('d10', same(run_pga(mA, stA, qdA, tau, g, springs=spring)['acc'], SH['acc']) and not same(SH['acc'], SA['acc']))
        add('dc8', not same(run_pga(mA, stA, qdA, tau, g, springs=[(1, spring[0][1], 2, spring[0][3], -spring[0][4])])['acc'], SH['acc']))
        if QUICK: continue
        # the double pendulum with its hinge as a spherical joint (three axes) plus the cut constraint 'line parallelism' (eq. 28)
        stAc = [None, stA[1], stA[2], (F(1), F(0)), (F(1), F(0))]; qdAc = [None, qdA[1], qdA[2], F(0), F(0)]
        PAc = run_pga(mAc, stAc, qdAc, [None, tau[1], tau[2], F(0), F(0)], g, specs=specAc)
        add('d11', all(PAc['acc'][(4, k)] == PA['acc'][(2, k)] == SA['acc'][(2, k)] and PAc['acc'][(1, k)] == PA['acc'][(1, k)] for k in range(4)) and len(PAc['keep']) == 2)
        TAc = cterms(mAc, PAc['K'], specAc[0]); crAc = cx(cx(TAc['X'], PAc['K']['V'][1]), cx(TAc['Y'], PAc['K']['V'][4]))
        add('d13', euc(crAc).is_zero() and all(run_pga(mAc, stAc, qdAc, [None, tau[1], tau[2], F(0), F(0)], g, specs=specAc, cross=cr)['acc'] == PAc['acc'] for cr in (-2, 1)))
        # environmental: the end point of the double pendulum on a fixed plane (Algorithm 2, eq. 28)
        K0 = pga_kin(mA, motors(mA, stA), [None, F(0), F(0)]); dl = v_dot([F(x) for x in nE], pvec(sand(K0, 2, PT(xe))))
        specE = [dict(op='^', X0=PT(xe), i=2, Y0=PLANE(nE, dl), j=0, masks=[15])]
        Kr, _, _, _ = assemble(mA, K0, specE); ns = nullspace(Kr, 2); qdE = [None] + v_sc(rqn(rng), ns[0])
        PE = run_pga(mA, stA, qdE, tau, g, specs=specE); SE = run_std(mA, stA, qdE, sA + [('plane', 2, xe, nE, None)], tau, g); common('E', PE, SE, 1)
        # chain R-P-R
        K1 = Jt(0, 'R', (0, 0, 0), UV['z'], rand_pts(rng, (1, 0, -1))); K2 = Jt(1, 'P', (1, 0, -1), UV['b'], rand_pts(rng, (2, 1, -2)))
        K3 = Jt(2, 'R', (2, 1, -2), UV['q'], rand_pts(rng, (3, 1, -3))); mB = [K1, K2, K3]
        sB = [('R', 0, 1, K1.a, K1.u), ('P', 1, 2, K2.a, K2.u), ('R', 2, 3, K3.a, K3.u)]
        stB = [None, half_angle(rq(rng)), rq(rng), half_angle(rq(rng))]; qdB = [None, rqn(rng), rqn(rng), rqn(rng)]; tauB = [None, rq(rng), rqn(rng), rq(rng)]
        common('B', run_pga(mB, stB, qdB, tauB, g), run_std(mB, stB, qdB, sB, tauB, g), 3)
        add('d5', same(run_pga(mB, stB, qdB, tauB, g, gmode='lines')['acc'], run_std(mB, stB, qdB, sB, tauB, g)['acc']))
        # three-body tree: R from the base, a universal joint (2 axes) and a spherical joint (3 axes) through massless links
        JU, JS = (1, 1, -2), (-1, 1, -2)
        C = [Jt(0, 'R', (0, 0, 0), UV['z'], rand_pts(rng, (0, 1, -1))), Jt(1, 'R', JU, UV['a']), Jt(2, 'R', JU, UV['b'], rand_pts(rng, (2, 1, -3))),
             Jt(1, 'R', JS, UV['p']), Jt(4, 'R', JS, UV['q']), Jt(5, 'R', JS, UV['r'], rand_pts(rng, (-2, 1, -3)))]
        sC = [('R', 0, 1, C[0].a, C[0].u), ('U', 1, 3, JU, UV['a'], UV['b']), ('S', 1, 6, JS)]
        stC = [None] + [half_angle(rq(rng)) for _ in C]; qdC = [None] + [rqn(rng) for _ in C]; tauC = [None, rq(rng), F(0), F(0), F(0), F(0), F(0)]
        common('C', run_pga(C, stC, qdC, tauC, g), run_std(C, stC, qdC, sC, tauC, g), 6)
        # the same tree closed by a cut spherical joint between bodies 3 and 6 (eq. 28 with the full-path K, Algorithm 3)
        KC = pga_kin(C, motors(C, stC), [None] + [F(0)] * 6); x3 = [2, 2, -3]; Xn = sand(KC, 3, PT(x3)); Y0 = KC['Mo'][6] * Xn * KC['Mo'][6].rev()
        specD = [dict(op='v', X0=PT(x3), i=3, Y0=Y0, j=6, masks=gmask(2))]
        Kr, _, _, _ = assemble(C, KC, specD); ns = nullspace(Kr, 6); cf = [rqn(rng) for _ in ns]
        qdD = [None] + [sum((c * v[a] for c, v in zip(cf, ns)), F(0)) for a in range(6)]
        PD = run_pga(C, stC, qdD, tauC, g, specs=specD); SD = run_std(C, stC, qdD, sC + [('cutS', 3, 6, x3, None)], tauC, g); common('D', PD, SD, 3)
        add('d12', Y0 == PT(SD['S'].cut_y0) and same(run_pga(C, stC, qdD, tauC, g, specs=specD, rel=True)['acc'], SD['acc']) and len(ns) == 3)
        TD = cterms(C, PD['K'], specD[0]); crD = A.join(cx(TD['X'], PD['K']['V'][3]), cx(TD['Y'], PD['K']['V'][6]))
        add('d13', crD.is_zero() and all(same(run_pga(C, stC, qdD, tauC, g, specs=specD, cross=cr)['acc'], SD['acc']) for cr in (-2, 1)))
        # the universal joint as a spherical joint (3 axes a, b, c) + the cut constraint 'line perpendicularity' L^a . L^b = 0 (Table 3; one scalar row)
        a_, b_, c_ = UV['a'], UV['b'], UV['c']
        mUb = [C[0], Jt(1, 'R', JU, a_), Jt(2, 'R', JU, b_, C[2].pts)]; mUc = [C[0], Jt(1, 'R', JU, a_), Jt(2, 'R', JU, b_), Jt(3, 'R', JU, c_, C[2].pts)]
        sUb = [('R', 0, 1, C[0].a, C[0].u), ('U', 1, 3, JU, a_, b_)]; specU = [dict(op='.', X0=DIRL(a_), i=1, Y0=DIRL(b_), j=4, dir=True, masks=[0])]
        stU = stC[:4]; qdU = qdC[:4]; tauU = tauC[:4]; stUc = stU + [(F(1), F(0))]; qdUc = qdU + [F(0)]; tauUc = tauU + [F(0)]
        PUb = run_pga(mUb, stU, qdU, tauU, g); SUb = run_std(mUb, stU, qdU, sUb, tauU, g); common('U', PUb, SUb, 3)
        PUc = run_pga(mUc, stUc, qdUc, tauUc, g, specs=specU)
        TU = cterms(mUc, PUc['K'], specU[0]); crU = dot(cx(TU['X'], PUc['K']['V'][1]), cx(TU['Y'], PUc['K']['V'][4]))
        def u_same(P_): return all(P_['acc'][(4, k)] == SUb['acc'][(3, k)] and P_['acc'][(1, k)] == SUb['acc'][(1, k)] for k in range(4))
        add('d14', u_same(PUc) and not crU.is_zero())
        add('dc5', not u_same(run_pga(mUc, stUc, qdUc, tauUc, g, specs=specU, cross=-2)))
        add('dc6', not u_same(run_pga(mUc, stUc, qdUc, tauUc, g, specs=specU, cross=1)))
        specX = [dict(specD[0], Y0=A.sand(A.trans([F(1, 5), 0, 0]), Y0))]
        add('dc7', not same(run_pga(C, stC, qdD, tauC, g, specs=specX)['acc'], SD['acc']))
    nt = len(R['d4'])
    sysn = 'double pendulum' if QUICK else '6 systems x 2 states: double pendulum, its end point on a plane, chain R-P-R, three-body tree (R, U, S), the tree closed by a cut S joint, R + U'
    chk('bit==std', all(R['d1']), '(d1) positions of every mass point: motors exp(q/2 L) against Rodrigues (%d system-states; %s)' % (nt, sysn))
    chk('bit==std', all(R['d2']), '(d2) velocities of every mass point: X x V_i against the twists (%d)' % nt)
    chk('std', all(R['d3']), '(d3) the [std] states satisfy every Cartesian constraint at position and velocity level, and the dof count of each system is the joint count (%d)' % nt)
    chk('bit==std', all(R['d4']), '(d4) accelerations of ALL mass points: Algorithm 1 (gravity as base acceleration V0\' = -a_g, joint torques) and eq. (28) equal the KKT route exactly (%d)' % nt)
    for t_ in ('A', 'E', 'B', 'C', 'D', 'U'):
        if 'd4_' + t_ in R: chk('bit==std', all(R['d4_' + t_]), '(d4%s) ... %s' % (t_, {'A': 'double pendulum, two skew hinges, torques, gravity', 'E': 'end point on a plane: Algorithm 2 + eq. (28), 1 dof',
            'B': 'chain R-P-R, prismatic force', 'C': 'tree R + U(2 axes) + S(3 axes), 6 dof', 'D': 'tree closed by a cut spherical joint, full-path K, 3 dof', 'U': 'R + U(2 axes), 3 dof'}[t_]))
    chk('bit==std', all(R['d5']), '(d5) gravity as weight lines sum m P v (g I) (external wrench, ours) gives the same q\'\' as the base acceleration and the [std] accelerations')
    chk('bit', all(R['d6']), '(d6) the inertia moved by the dictionary I(X) = N~ A(N X N~) N equals the definition with the current points (Algorithm 1 needs the current pose)')
    chk('bit', all(R['d7']), '(d7) the CRBA matrix of Algorithm 1 is symmetric with a positive diagonal')
    if 'd8' in R: chk('bit', all(R['d8']), '(d8) every residual component, also the dropped redundant ones, has Phi\'\' = 0 under eq. (28)')
    chk('bit==std', all(R['d9']), '(d9) ours: (1/2) sum V v I(V) and (1/2) sum (I(V) ^ V)* both equal (1/2) sum m |x\'|^2 of the points (FRQ-002\'s pairing in the multibody layer)')
    chk('bit==std', all(R['d10']), '(d10) ours: a Hooke line k P1 v P2 between the two bodies (external wrenches) equals the Cartesian spring k (p2 - p1) on the two points')
    if 'd11' in R: chk('bit==std', all(R['d11']), '(d11) the hinge as a spherical joint + the cut constraint L^ x L^ = 0 (2 of 3 components kept) gives the accelerations of the built-in hinge (PGA and [std])')
    if 'd13' in R: chk('bit', all(R['d13']), "(d13) at velocity-consistent states of the coincidence relations (cut P1 v P2 = 0; L^1 x L^2 = 0) the cross term of (27) is exactly 0, so q'' does not change when it is reversed or its 2 dropped: there the plan's control is blind (%d states)" % len(R['d13']))
    if 'd14' in R: chk('bit==std', all(R['d14']), "(d14) the universal joint as a spherical joint + the cut L^a . L^b = 0 (one row) gives the accelerations of the built-in universal joint ([std]); its cross term is nonzero")
    if 'i_e01' in R: print('  info: the anisotropic mass along e01 alone changes q\'\' in %d of %d states; states (c, s): %s' % (sum(1 for x, _ in R['i_e01'] if x), len(R['i_e01']), [st for x, st in R['i_e01'] if not x]), flush=True)
    if 'd12' in R: chk('bit==std', all(R['d12']), '(d12) closed tree: the PGA and [std] preimages of the cut point agree; with Phi = 0 the relative-path K of Algorithm 3 gives the same accelerations; 3 free rates')
    for key, what in (('dc1', 'gravity upward (V0\' = +a_g)'), ('dc2', 'the body-frame (unmoved) inertia in the inertial-frame Algorithm 1'), ('dc3', 'a non-rigid inertia (translational masses m, 2m, 3m along e01, e02, e03)'),
                      ('dc4', 'the sign of the joint torques flipped (the pairing (w ^ L)* reversed)'), ('dc8', 'the spring line reversed'), ('dc5', 'universal joint as S + cut perpendicularity: cross term of (27) reversed'),
                      ('dc6', 'universal joint as S + cut perpendicularity: factor 2 of the cross term dropped'), ('dc7', 'cut point displaced by 1/5 at t = 0 (joint violated)')):
        if key in R: chk('ctl', all(R[key]), '(%s) %s: the accelerations differ from [std] (%d of %d)' % (key, what, sum(R[key]), len(R[key])))

# ================================================================== (f) series flows: the relations and the energy along the motion
def part_f():
    head('(f) exact-series flows: the double pendulum (Algorithm 1) and the same pendulum as S joint + cut parallelism (eq. 28)')
    rng = random.Random(23); g = [F(1, 2), F(-1), F(-10)]
    J1 = Jt(0, 'R', (0, 0, 0), UV['a'], rand_pts(rng, (1, -1, -1))); J2 = Jt(1, 'R', (1, -1, -2), UV['p'], rand_pts(rng, (2, 0, -3)))
    mA = [J1, J2]; Ja, Jb, Jc = Jt(1, 'R', J2.a, UV['p']), Jt(2, 'R', J2.a, UV['q']), Jt(3, 'R', J2.a, UV['r'], [(m, x) for m, x in J2.pts])
    mAc = [J1, Ja, Jb, Jc]; specAc = [dict(op='x', X0=DIRL(UV['p']), i=1, Y0=DIRL(UV['p']), j=4, dir=True, masks=gmask(2, True))]
    ag = E0 * vec3(g); st0 = [None, half_angle(F(1, 2)), half_angle(F(-1, 3))]; qd0 = [None, F(1), F(-2)]
    st0c = [None, st0[1], st0[2], (F(1), F(0)), (F(1), F(0))]; qd0c = [None, qd0[1], qd0[2], F(0), F(0)]
    keep = assemble(mAc, pga_kin(mAc, motors(mAc, st0c), qd0c), specAc)[3]
    def rhsA(stt, qd): return forward(alg1(mA, motors(mA, stt), qd, ag), None)[0]
    def rhsAc(cross):
        def f(stt, qd):
            D = alg1(mAc, motors(mAc, stt), qd, ag); Kr, kr, _, _ = assemble(mAc, D['K'], specAc, cross, False, keep); return forward(D, None, (Kr, kr))[0]
        return f
    Nf = 3 if QUICK else 5; TS.N = Nf
    (sA, qA), _ = flow(mA, st0, qd0, rhsA, Nf + 2); EA, _, _, KA = energy(mA, sA, qA, g); EAbad = energy(mA, sA, qA, g, gsign=-1)[0]
    chk('bit', all(c == 0 for c in EA.c[1:Nf + 1]), "(f1) double pendulum with gravity (Algorithm 1): E = (1/2) sum V v I(V) - sum m g.p is constant through order %d (ours)" % Nf)
    chk('ctl', any(c != 0 for c in EAbad.c[1:Nf + 1]), '(fc1) with the potential of the opposite sign E is not constant')
    (sC, qC), SC = flow(mAc, st0c, qd0c, rhsAc(2), Nf + 2); EC, _, _, KC = energy(mAc, sC, qC, g)
    Phi = cx(euc(sand(KC, 1, DIRL(UV['p']))), euc(sand(KC, 4, DIRL(UV['p'])))); Pc = A.join(sand(KC, 1, PT(J2.a)), sand(KC, 4, PT(J2.a)))
    chk('bit', mv_zero(Phi, Nf) and mv_zero(Pc, Nf), '(f2) S joint + cut parallelism under eq. (28): both Table-3 revolute relations (P1 v P2 = 0, L^1 x L^2 = 0, all 3 components) vanish along the flow through order %d' % Nf)
    posA = [pvec(sand(KA, 2, PT(x))) for _, x in J2.pts]; posC = [pvec(sand(KC, 4, PT(x))) for _, x in J2.pts]
    chk('bit', all(all(a.c[:Nf + 1] == b.c[:Nf + 1] for a, b in zip(pa, pc)) for pa, pc in zip(posA, posC)), '(f3) ... and its points move exactly as the built-in hinge through order %d' % Nf)
    chk('bit', all(c == 0 for c in EC.c[1:Nf + 1]), '(f4) ... and its energy is constant through order %d: the multipliers do no work (ours)' % Nf)
    chk('bit', all(not SC[i][1] and SC[i][0] == 1 and not SC[i][2] for i in (3, 4)), '(f5) ... the two extra spherical coordinates stay exactly zero')
    (sX, qX), SX = flow(mAc, st0c, qd0c, rhsAc(-2), Nf + 2)
    chk('bit', all(all(a.c == b.c for a, b in zip(SX[i], SC[i])) for i in SC), "(f6) with the cross term of (27) reversed the parallelism flow is IDENTICAL through order %d: on the manifold the cross term vanishes, so that control is blind for coincidence relations" % Nf)
    a_, b_, c_ = UV['a'], UV['b'], UV['c']; JU = (1, 1, -2); B1 = Jt(0, 'R', (0, 0, 0), UV['z'], rand_pts(rng, (0, 1, -1))); B2pts = rand_pts(rng, (2, 1, -3))
    mUb = [B1, Jt(1, 'R', JU, a_), Jt(2, 'R', JU, b_, B2pts)]; mUc = [B1, Jt(1, 'R', JU, a_), Jt(2, 'R', JU, b_), Jt(3, 'R', JU, c_, B2pts)]
    specU = [dict(op='.', X0=DIRL(a_), i=1, Y0=DIRL(b_), j=4, dir=True, masks=[0])]
    stU = [None, half_angle(F(1, 3)), half_angle(F(-1, 2)), half_angle(F(2, 5))]; qdU = [None, F(1), F(1, 2), F(-1)]; stUc = stU + [(F(1), F(0))]; qdUc = qdU + [F(0)]
    keepU = assemble(mUc, pga_kin(mUc, motors(mUc, stUc), qdUc), specU)[3]
    def rhsU(stt, qd): return forward(alg1(mUb, motors(mUb, stt), qd, ag), None)[0]
    def rhsUc(cross):
        def f(stt, qd):
            D = alg1(mUc, motors(mUc, stt), qd, ag); Kr, kr, _, _ = assemble(mUc, D['K'], specU, cross, False, keepU); return forward(D, None, (Kr, kr))[0]
        return f
    (sU, qU), _ = flow(mUb, stU, qdU, rhsU, Nf + 2); KU = pga_kin(mUb, motors(mUb, sU), qU)
    (sV, qV), _ = flow(mUc, stUc, qdUc, rhsUc(2), Nf + 2); EV, _, _, KV = energy(mUc, sV, qV, g)
    PhiU = dot(euc(sand(KV, 1, DIRL(a_))), euc(sand(KV, 4, DIRL(b_))))
    posU = [pvec(sand(KU, 3, PT(x))) for _, x in B2pts]; posV = [pvec(sand(KV, 4, PT(x))) for _, x in B2pts]
    chk('bit', mv_zero(PhiU, Nf) and all(all(a.c[:Nf + 1] == b.c[:Nf + 1] for a, b in zip(pa, pc)) for pa, pc in zip(posU, posV)) and all(c == 0 for c in EV.c[1:Nf + 1]),
        '(f7) universal joint as S + cut L^a . L^b = 0 under eq. (28): the relation vanishes along the flow, the points move as the built-in universal joint, E is constant (through order %d)' % Nf)
    TS.N = 3; (sX, qX), _ = flow(mUc, stUc, qdUc, rhsUc(-2), 5); KX = pga_kin(mUc, motors(mUc, sX), qX)
    PhiX = dot(euc(sand(KX, 1, DIRL(a_))), euc(sand(KX, 4, DIRL(b_))))
    chk('ctl', not mv_zero(PhiX, 3), "(fc2) the same with the cross term of (27) reversed: the perpendicularity drifts (series order 3)")

def main():
    print('G4 multibody: fault = %s, quick = %s, HALF = %s, e0^2 = %s' % (FAULT, QUICK, HALF, EPS_SQ), flush=True)
    parts = [('a', part_a), ('b', part_b), ('c', part_c), ('d', part_d), ('f', part_f)]
    if QUICK: parts = [('a', part_a), ('c', part_c), ('d', part_d)]
    t0 = time.time()
    for name, fn in parts:
        t = time.time()
        try: fn()
        except Exception as ex:
            chk('bit', False, '(%s) part stopped on an exception: %s: %s' % (name, type(ex).__name__, str(ex)[:150]))
        print('  time part %s: %.1f s' % (name, time.time() - t), flush=True)
    print('  time total: %.1f s' % (time.time() - t0), flush=True)
    finish('G4')

if __name__ == '__main__': main()
