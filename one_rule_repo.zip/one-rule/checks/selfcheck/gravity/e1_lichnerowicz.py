#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""E1.  Lichnerowicz on the bit rule: the square of the Dirac operator in a curved frame.     python3 e1_lichnerowicz.py [--quick]

 Conventions (engine): Cl(1,3), sq = (+,-,-,-); B_ab = gamma_a gamma_b (a < b); Omega = sum_{a<b} omega^{ab} B_ab, omega^a_b = omega^{ab} eta_bb, T = de + omega e.
 Spinor = the algebra itself as a left module (2^n real components); D psi = d psi + (1/2) Omega psi (Grav.D_spinor); nabla_a = E_a -| D (E: dual frame as a series).
 Dslash = gamma^a nabla_a with gamma^a = sq_a gamma_a acting on the left (the Atlas's grad, without J).
 Laplacian nabla^a nabla_a psi = eta^{ab} (nabla^2 psi)(E_a, E_b),  (nabla^2 psi)(E_a, E_b) = E_a -| [ D(nabla_b psi) - omega^c_b nabla_c psi ]:
   D acting on the spinor-valued 1-form nabla psi; the frame-index term is read from Grav.D_covector (the h table).
 R^{cd}_{ab} := R^{cd}(E_a, E_b) (engine curvature on frame vectors), R := sum_ab R^{ab}_{ab} (= scalar curvature of g = e^T eta e, MTW sign; A4).
 Claims checked (exact fractions, at the origin of random polynomial frames, 2-jets; polynomial spinors of degree 2):
  (P) K := sum R^{cd}_{ab} gamma^a gamma^b gamma_c gamma_d = -2R + 4 sum_{a<d} (Ric_ad - Ric_da) gamma^a gamma^d + 24 det(eta) R_[0123] gamma_0123;
      torsion-free engine curvature: pair symmetry and the first Bianchi identity remove the last two, K = -2R.
  (O) torsion-free: Dslash^2 psi = nabla^a nabla_a psi - (R/4) psi;  with J = gamma_2 gamma_1 on the right: ((Dslash .) J)^2 = -Dslash^2.
  (T) omega' = omega + contorsion: Dslash'^2 - nabla'^a nabla'_a = -(R'/4) - (1/2) gamma^a gamma^b T^c_ab nabla'_c + (1/8) (K'_2 + K'_4), K'_2 and K'_4 in terms of DT.
 [std] numpy only: Dirac matrices (2x2 for n = 3), Christoffel symbols of g (analytic d g of the polynomial frame), d E = -E (de) E, spin connection
       omega_mu^a_b = e^a_nu (d_mu E^nu_b + Gamma^nu_{mu lam} E^lam_b); Dslash applied twice and the curvature by five-point differences of these fields; exact std scalar curvature from b1lib.std_riemann.
 Controls: c = -1/2, c = +1/4; no frame-index term; frozen dual frame; Euclidean contraction on the Lorentz frame; tensors without Bianchi; torsion; std spin connection of the wrong sign."""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
QUICK = '--quick' in sys.argv
LOR = [1, -1, -1, -1]

# ------------------------------------------------------------------------------------------------ small exact helpers (multivectors / spinors as {mask: value})
def clean(X): return {k: v for k, v in X.items() if v != 0}
def nz_poly(p): return {k: v for k, v in p.items() if v != 0}
def perm_sign(p):
    s = 1
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i] > p[j]: s = -s
    return s
def detq(sq):
    r = 1
    for s in sq: r *= s
    return r
def mv_add(X, Y, c=1):
    r = dict(X)
    for k, v in Y.items(): r[k] = r.get(k, 0) + c * v
    return clean(r)
def mv_scale(X, c): return clean({k: v * c for k, v in X.items()})
def mv_mul(A, X, sq):
    """(constant multivector A) (constant spinor X), bit-rule product"""
    out = {}
    for m1, a in A.items():
        for m2, x in X.items():
            m, s = bmul(m1, m2, sq); out[m] = out.get(m, 0) + s * a * x
    return clean(out)
def grade(X, g): return {m: v for m, v in X.items() if popc(m) == g}
def det3(M): return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))

# ------------------------------------------------------------------------------------------------ forms on frame vectors at the origin
def form2_on(form, E0, n, a, b):
    """a 2-form (engine dict) evaluated at the origin on (E_a, E_b)"""
    t = F(0)
    for mu in range(n):
        for nu in range(mu + 1, n):
            p = form.get((1 << mu) | (1 << nu))
            if p:
                v = at0(p, n)
                if v: t += v * (E0[mu][a] * E0[nu][b] - E0[nu][a] * E0[mu][b])
    return t
def form3_on(form, E0, n, a, b, c):
    """a 3-form evaluated at the origin on (E_a, E_b, E_c)"""
    t = F(0)
    for (mu, nu, la) in itertools.combinations(range(n), 3):
        p = form.get((1 << mu) | (1 << nu) | (1 << la))
        if p:
            v = at0(p, n)
            if v: t += v * det3([[E0[r][a], E0[r][b], E0[r][c]] for r in (mu, nu, la)])
    return t
def curv_frame(Gv, R, E0, n):
    """[bit] Rf[(c, d, a, b)] = R^{cd}(E_a, E_b) at the origin, all index orders"""
    Rf = {}
    for A, (c, d) in enumerate(pairs_of(Gv.L)):
        for a in range(n):
            for b in range(a + 1, n):
                v = form2_on(R[A], E0, n, a, b)
                if v: Rf[(c, d, a, b)] = v; Rf[(d, c, a, b)] = -v; Rf[(c, d, b, a)] = -v; Rf[(d, c, b, a)] = v
    return Rf
def scalar_R(Rf, n): return sum((Rf.get((a, b, a, b), 0) for a in range(n) for b in range(n)), F(0))
def ricci(Rf, n, sq):
    """Ric_bd = sum_a R^a_{b, ad} = sum_a sq_b R^{ab}(E_a, E_d)  (MTW: R_{mu nu} = R^rho_{mu rho nu})"""
    return {(b, d): sum((sq[b] * Rf.get((a, b, a, d), 0) for a in range(n)), F(0)) for b in range(n) for d in range(n)}
def lowered(Rf, sq): return {(p, q, r, s): sq[p] * sq[q] * v for (p, q, r, s), v in Rf.items()}
def antisym4(Rf, sq):
    """R_[0123] with R_pqrs = sq_p sq_q R^{pq}(E_r, E_s)  (n = 4)"""
    return sum((perm_sign(p) * sq[p[0]] * sq[p[1]] * Rf.get(p, 0) for p in itertools.permutations(range(4))), F(0)) / 24
def antipodal(Rf, sq):
    Rl = lowered(Rf, sq); return Rl.get((0, 1, 2, 3), 0) + Rl.get((0, 2, 3, 1), 0) + Rl.get((0, 3, 1, 2), 0)
def pair_symmetric(Rf, n, sq):
    Rl = lowered(Rf, sq); return all(Rl.get((p, q, r, s), 0) == Rl.get((r, s, p, q), 0) for (p, q, r, s) in itertools.product(range(n), repeat=4))
def clifford_contraction(Rf, n, sq):
    """[bit] K = sum_{abcd} R^{cd}_{ab} gamma^a gamma^b gamma_c gamma_d  (bit-rule products, gamma^a = sq_a gamma_a)"""
    K = {}
    for (c, d, a, b), v in Rf.items():
        if not v: continue
        m, s1 = bmul(1 << a, 1 << b, sq); m, s2 = bmul(m, 1 << c, sq); m, s3 = bmul(m, 1 << d, sq)
        K[m] = K.get(m, 0) + v * sq[a] * sq[b] * s1 * s2 * s3
    return clean(K)
def K2_pred(ric, n, sq):
    """4 sum_{a<d} (Ric_ad - Ric_da) gamma^a gamma^d"""
    out = {}
    for a in range(n):
        for d in range(a + 1, n):
            v = 4 * (ric[(a, d)] - ric[(d, a)]) * sq[a] * sq[d]
            if v: out[(1 << a) | (1 << d)] = v
    return out

# ------------------------------------------------------------------------------------------------ [bit] spinor calculus on jets
def nabla_jet(Gv, om, E, X, n, deg):
    """[bit] nabla_b X = E_b -| D X for a spinor field X = {S: poly}: list over b of {S: poly}, truncated at x-degree deg"""
    with trunc(n, xdeg=deg):
        DX = Gv.D_spinor(om, {S: {0: p} for S, p in X.items() if p})
        out = []
        for b in range(n):
            ob = {}
            for S, form in DX.items():
                t = {}
                for mu in range(n):
                    q = form.get(1 << mu); Eb = E[mu][b]
                    if q and Eb: t = padd(t, pm(Eb, q))
                if t: ob[S] = t
            out.append(ob)
    return out
def slash(nab, n, sq, rs):
    """sum_b rs_b gamma_b nab[b]  (rs = sq: gamma^b; rs = 1: the Euclidean contraction, a control)"""
    out = {}
    for b in range(n):
        for S, p in nab[b].items():
            m, s = bmul(1 << b, S, sq); out[m] = padd(out.get(m, {}), p, s * rs[b])
    return {m: p for m, p in out.items() if p}
def at0_sp(X, n): return clean({S: at0(p, n) for S, p in X.items()})
def second_cov(Gv, om, E0, nab1, n, frame_term=True):
    """[bit] (nabla^2 psi)(E_a, E_b) at the origin = E_a -| [ D_spinor(nabla_b psi) - omega^c_b nabla_c psi ]; the frame-index term from D_covector (h table)"""
    Fm = Gv.Fm
    with trunc(n, xdeg=0):
        Dn = [Gv.D_spinor(om, {S: {0: p} for S, p in nab1[b].items()}) for b in range(n)]
        Fr = [{} for _ in range(n)]
        if frame_term:
            for S in set().union(*[set(x) for x in nab1]):
                X = [({0: nab1[b][S]} if S in nab1[b] else {}) for b in range(n)]
                DX = Gv.D_covector(om, X)
                for b in range(n):
                    f = Fm.add(DX[b], Fm.d(X[b]), -1)
                    if any(f.values()): Fr[b][S] = f
    N2 = {}
    for a in range(n):
        for b in range(n):
            val = {}
            for src in (Dn[b], Fr[b]):
                for S, form in src.items():
                    v = sum((at0(form.get(1 << mu, {}), n) * E0[mu][a] for mu in range(n)), F(0))
                    if v: val[S] = val.get(S, 0) + v
            N2[(a, b)] = clean(val)
    return N2
def gg_contract(N2, n, sq, rs):
    out = {}
    for a in range(n):
        for b in range(n):
            m1, s1 = bmul(1 << a, 1 << b, sq)
            for S, v in N2[(a, b)].items():
                m, s = bmul(m1, S, sq); out[m] = out.get(m, 0) + rs[a] * rs[b] * s1 * s * v
    return clean(out)
def lap_contract(N2, n, rs):
    out = {}
    for a in range(n):
        for S, v in N2[(a, a)].items(): out[S] = out.get(S, 0) + rs[a] * v
    return clean(out)
def rmulJ(X, sq):
    """X J with J = gamma_2 gamma_1 (the Atlas's complex structure, right multiplication)"""
    Jm, Js = bmul(1 << 2, 1 << 1, sq); out = {}
    for S, p in X.items():
        m, s = bmul(S, Jm, sq); out[m] = padd(out.get(m, {}), p, s * Js)
    return {m: p for m, p in out.items() if p}
def tT_term(Tf, nab0, n, sq):
    """sum_{abc} gamma^a gamma^b T^c_ab nabla_c psi (at the origin)"""
    out = {}
    for a in range(n):
        for b in range(n):
            if a == b: continue
            m1, s1 = bmul(1 << a, 1 << b, sq)
            for c in range(n):
                t = Tf.get((c, a, b), 0)
                if not t: continue
                for S, v in nab0[c].items():
                    m, s = bmul(m1, S, sq); out[m] = out.get(m, 0) + sq[a] * sq[b] * s1 * s * t * v
    return clean(out)

def lc_setup(n, sq, seed, coef=2, density=.5):
    """random polynomial coframe (degree 2), A3 closed-form omega (1-jet), dual frame series (1-jet), random spinor of degree 2"""
    rng = random.Random(seed); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_)
    e = rand_frame(rng, n, deg=2, coef=coef, density=density)
    Dp = anholonomy(Gv, e, n, 1); om = omega_closed_form(Gv, e, S, n, 1, Dpre=Dp)[0]
    e0, E0, det = E0_of(e, n, n)
    psi = {}
    for S_ in range(1 << n):
        p = nz_poly(gs.rpoly(rng, n, 2, .5))
        if p: psi[S_] = p
    return dict(Gv=Gv, e=e, E=Dp[1], e0=e0, E0=E0, det=det, om=om, psi=psi, n=n, sq=list(sq))
def engine_ops(d, om=None, rs=None, frozen=False, want_J=False):
    """[bit] nabla_b psi (1-jet), literal Dslash(Dslash psi), (nabla^2 psi)(E_a, E_b), the Laplacian, sum gamma^a gamma^b nabla^2_ab psi, all at the origin"""
    Gv, n, sq, E, E0, psi = d['Gv'], d['n'], d['sq'], d['E'], d['E0'], d['psi']
    om = d['om'] if om is None else om; rs = rs or sq
    Eu = [[const(n, E0[mu][a]) for a in range(n)] for mu in range(n)] if frozen else E
    nab1 = nabla_jet(Gv, om, Eu, psi, n, 1)
    Phi = slash(nab1, n, sq, rs)
    D2 = at0_sp(slash(nabla_jet(Gv, om, Eu, Phi, n, 0), n, sq, rs), n)
    N2 = second_cov(Gv, om, E0, nab1, n)
    out = dict(nab1=nab1, nab0=[at0_sp(x, n) for x in nab1], D2=D2, N2=N2, Lap=lap_contract(N2, n, rs), GG=gg_contract(N2, n, sq, rs), psi0=at0_sp(psi, n))
    if want_J:
        PhiJ = rmulJ(Phi, sq); out['D2J'] = at0_sp(rmulJ(slash(nabla_jet(Gv, om, Eu, PhiJ, n, 0), n, sq, rs), sq), n)
    return out
def fit(samples, k):
    """exact fit res = sum_i x_i t_i over all components of all samples; returns (x, rank, consistent)"""
    rows, rhs = [], []
    for res, ts in samples:
        for S in sorted(set(res).union(*[set(t) for t in ts])):
            rows.append([t.get(S, F(0)) for t in ts]); rhs.append(res.get(S, F(0)))
    w, rank, nvar, cons = solve_exact(rows, rhs)
    return w, rank, cons

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
S0 = np.eye(2, dtype=complex); SX = np.array([[0, 1], [1, 0]], complex); SY = np.array([[0, -1j], [1j, 0]]); SZ = np.array([[1, 0], [0, -1]], complex)
def gammas(sq):
    """[std] gamma matrices with gamma_a gamma_b + gamma_b gamma_a = 2 sq_a delta_ab: Dirac matrices (n = 4), (s3, i s1, i s2) for n = 3; a factor i flips a square"""
    n = len(sq)
    if n == 4: base = [np.block([[S0, 0 * S0], [0 * S0, -S0]])] + [np.block([[0 * S0, s], [-s, 0 * S0]]) for s in (SX, SY, SZ)]; bsq = [1, -1, -1, -1]
    else: base = [SZ, 1j * SX, 1j * SY]; bsq = [1, -1, -1]
    return [B if sq[a] == bsq[a] else 1j * B for a, B in enumerate(base)]
def blades(G):
    n = len(G); out = []
    for mask in range(1 << n):
        M = np.eye(G[0].shape[0], dtype=complex)
        for i in range(n):
            if mask >> i & 1: M = M @ G[i]                    # increasing index order
        out.append(M)
    return out
def to_mat(BL, X): return sum((float(v) * BL[S] for S, v in X.items()), 0 * BL[0])
def relerr(A, B): return float(np.max(np.abs(np.asarray(A) - np.asarray(B))) / max(1.0, float(np.max(np.abs(np.asarray(B))))))
def pfun(p, n):
    if not p: return lambda x: 0.0
    K = np.array([list(k[:n]) for k in p], dtype=float); v = np.array([float(c) for c in p.values()])
    return lambda x: float(np.prod(np.power(x, K), axis=1) @ v)
def lsq_c(Y, X):
    c = float(np.vdot(X, Y).real / np.vdot(X, X).real); return c, float(np.linalg.norm(Y - c * X) / max(1e-300, np.linalg.norm(Y)))
class StdSpin:
    """[std] numpy: metric g = e^T eta e, Christoffel symbols, spin connection, Dirac matrices; five-point differences for second derivatives; optional contorsion Kp {(a, b): 1-form}"""
    def __init__(self, e, psi, n, sq, G, Kp=None, spin_sign=1.0, h=1e-3):
        self.n, self.sq, self.G, self.h, self.ss = n, list(sq), G, h, spin_sign
        self.eta = np.diag(np.array(sq, dtype=float))
        self.ep = [[pfun(e[a].get(1 << mu, {}), n) for mu in range(n)] for a in range(n)]
        self.dep = [[[pfun(sp_der(e[a].get(1 << mu, {}), k), n) for mu in range(n)] for a in range(n)] for k in range(n)]
        BL = blades(G); self.ps = [(BL[S], pfun(p, n), [pfun(sp_der(p, k), n) for k in range(n)]) for S, p in psi.items()]
        self.Kf = None if Kp is None else {ab: [pfun(form.get(1 << mu, {}), n) for mu in range(n)] for ab, form in Kp.items()}
        self.GG = [[G[a] @ G[b] for b in range(n)] for a in range(n)]
    def emat(self, x): return np.array([[f(x) for f in row] for row in self.ep])
    def demat(self, x): return np.array([[[f(x) for f in row] for row in self.dep[k]] for k in range(self.n)])   # de[k, a, mu] = d_k e^a_mu (analytic)
    def Emat(self, x): return np.linalg.inv(self.emat(x))                       # E[mu, a]
    def gmet(self, x): e = self.emat(x); return e.T @ self.eta @ e
    def d1(self, f, x, k):
        dx = np.zeros(self.n); dx[k] = self.h
        return (-f(x + 2 * dx) + 8 * f(x + dx) - 8 * f(x - dx) + f(x - 2 * dx)) / (12 * self.h)
    def christoffel(self, x, e=None, de=None):                                   # Gam[l, m, n] = Gamma^l_{mn};  d g = de^T eta e + e^T eta de (analytic)
        e = self.emat(x) if e is None else e; de = self.demat(x) if de is None else de
        gi = np.linalg.inv(e.T @ self.eta @ e); dg = np.array([de[k].T @ self.eta @ e + e.T @ self.eta @ de[k] for k in range(self.n)])
        return 0.5 * (np.einsum('ls,msn->lmn', gi, dg) + np.einsum('ls,nsm->lmn', gi, dg) - np.einsum('ls,smn->lmn', gi, dg))
    def Kmat(self, x):
        n = self.n; out = np.zeros((n, n, n))
        if self.Kf is None: return out
        for (a, b), fs in self.Kf.items():
            for mu in range(n):
                v = fs[mu](x); out[mu, a, b] += v * self.sq[b]; out[mu, b, a] -= v * self.sq[a]
        return out
    def omega(self, x):                                                          # om[mu, a, b] = omega_mu^a_b = e^a_nu (d_mu E^nu_b + Gamma^nu_{mu lam} E^lam_b) (+ K)
        e = self.emat(x); E = np.linalg.inv(e); de = self.demat(x); Gam = self.christoffel(x, e, de)
        dE = np.array([-E @ de[k] @ E for k in range(self.n)])                  # d_k E = -E (d_k e) E  (analytic)
        return np.einsum('an,mnb->mab', e, dE) + np.einsum('an,nml,lb->mab', e, Gam, E) + self.Kmat(x)
    def spinconn(self, om):                                                      # A_mu = (1/4) omega_mu^{ab} gamma_a gamma_b
        n = self.n
        return [self.ss * 0.25 * sum(om[mu, a, b] * self.sq[b] * self.GG[a][b] for a in range(n) for b in range(n)) for mu in range(n)]
    def Psi(self, x): return sum(f(x) * B for (B, f, df) in self.ps)
    def dPsi(self, x): return [sum(df[k](x) * B for (B, f, df) in self.ps) for k in range(self.n)]
    def nabla(self, x):
        n = self.n; E = self.Emat(x); A = self.spinconn(self.omega(x)); P = self.Psi(x); dP = self.dPsi(x)
        cov = [dP[mu] + A[mu] @ P for mu in range(n)]
        return np.array([sum(E[mu, b] * cov[mu] for mu in range(n)) for b in range(n)])
    def slash(self, x):
        nb = self.nabla(x); return sum(self.sq[b] * self.G[b] @ nb[b] for b in range(self.n))
    def at_origin(self):
        n, G, sq = self.n, self.G, self.sq; x0 = np.zeros(n); E = self.Emat(x0); e = self.emat(x0); om = self.omega(x0); A = self.spinconn(om)
        nb0 = self.nabla(x0); dnb = [self.d1(self.nabla, x0, k) for k in range(n)]
        oma = np.einsum('ma,mcb->acb', E, om)                                     # omega^c_b(E_a)
        N2 = [[sum(E[mu, a] * (dnb[mu][b] + A[mu] @ nb0[b]) for mu in range(n)) - sum(oma[a, c, b] * nb0[c] for c in range(n)) for b in range(n)] for a in range(n)]
        Lap = sum(sq[a] * N2[a][a] for a in range(n))
        sl0 = sum(sq[b] * G[b] @ nb0[b] for b in range(n)); dsl = [self.d1(self.slash, x0, k) for k in range(n)]
        D2 = sum(sq[a] * G[a] @ sum(E[mu, a] * (dsl[mu] + A[mu] @ sl0) for mu in range(n)) for a in range(n))
        dom = np.array([self.d1(self.omega, x0, k) for k in range(n)])          # dom[k, mu, a, b] = d_k omega_mu^a_b
        Rc = dom - np.einsum('nmab->mnab', dom) + np.einsum('mac,ncb->mnab', om, om) - np.einsum('nac,mcb->mnab', om, om)
        Rf = np.einsum('mnab,mc,nd->abcd', Rc * np.array(sq, dtype=float)[None, None, None, :], E, E)      # R^{ab}(E_c, E_d)
        Rs = float(np.einsum('abab->', Rf))
        de = np.array([[[self.dep[k][a][mu](x0) for mu in range(n)] for a in range(n)] for k in range(n)])   # de[k, a, mu]
        Tc = np.einsum('mcn->cmn', de) - np.einsum('ncm->cmn', de) + np.einsum('mcb,bn->cmn', om, e) - np.einsum('ncb,bm->cmn', om, e)
        Tf = np.einsum('cmn,ma,nb->cab', Tc, E, E)                                 # T^c(E_a, E_b)
        P0 = self.Psi(x0); Gu = [sq[a] * G[a] for a in range(n)]
        K = sum(Rf[c, d, a, b] * (Gu[a] @ Gu[b] @ G[c] @ G[d]) for a, b, c, d in itertools.product(range(n), repeat=4))
        TT = sum(Tf[c, a, b] * (Gu[a] @ Gu[b] @ nb0[c]) for a, b, c in itertools.product(range(n), repeat=3))
        return dict(om0=om, nb0=nb0, Lap=Lap, D2=D2, Rf=Rf, Rs=Rs, Tf=Tf, Psi0=P0, pred=0.125 * K @ P0 - 0.5 * TT)

# ------------------------------------------------------------------------------------------------ part P: pointwise algebra of the contraction
def kn_tensor(rng, n, k=2, coef=3):
    """an algebraic curvature tensor (lower indices): sum of Kulkarni-Nomizu squares S_ac S_bd - S_ad S_bc of random symmetric integer matrices"""
    Ss = []
    for _ in range(k):
        S = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i, n): S[i][j] = S[j][i] = rng.randint(-coef, coef)
        Ss.append(S)
    return clean({(a, b, c, d): F(sum(S[a][c] * S[b][d] - S[a][d] * S[b][c] for S in Ss)) for a, b, c, d in itertools.product(range(n), repeat=4)})
def pairsym_tensor(rng, n, coef=3):
    """antisymmetric in each pair, symmetric under pair exchange, no Bianchi identity imposed (random symmetric matrix on the pairs)"""
    pairs = list(itertools.combinations(range(n), 2)); Mx = {}
    for i in range(len(pairs)):
        for j in range(i, len(pairs)): Mx[(i, j)] = Mx[(j, i)] = rng.randint(-coef, coef)
    Xl = {}
    for i, (a, b) in enumerate(pairs):
        for j, (c, d) in enumerate(pairs):
            v = F(Mx[(i, j)])
            if v:
                for (p, q, s1) in ((a, b, 1), (b, a, -1)):
                    for (r, s, s2) in ((c, d, 1), (d, c, -1)): Xl[(p, q, r, s)] = s1 * s2 * v
    return Xl
def eps_tensor(t): return {p: F(t * perm_sign(p)) for p in itertools.permutations(range(4))}
def to_Rf(Xl, sq): return clean({(c, d, a, b): sq[c] * sq[d] * v for (c, d, a, b), v in Xl.items()})
def std_K(Xl, sq, G):
    """[std] sum X_cdab gamma^a gamma^b gamma^c gamma^d with matrices (X lower indices, first pair = the Lie pair)"""
    Gu = [sq[a] * G[a] for a in range(len(sq))]
    return sum((float(v) * (Gu[a] @ Gu[b] @ Gu[c] @ Gu[d]) for (c, d, a, b), v in Xl.items()), 0 * G[0])
def std_scalar_and_alt(Xl, sq):
    """[std] R(X) = sum sq_a sq_b X_abab and X_[0123], plain python"""
    R = sum(float(sq[a] * sq[b] * Xl.get((a, b, a, b), 0)) for a in range(4) for b in range(4))
    A = sum(perm_sign(p) * float(Xl.get(p, 0)) for p in itertools.permutations(range(4))) / 24
    return R, A
def cyclic_ok(Xl, n):
    """the first Bianchi identity X_abcd + X_acdb + X_adbc = 0 for every index quadruple (plain index loops)"""
    return all(Xl.get((a, b, c, d), 0) + Xl.get((a, c, d, b), 0) + Xl.get((a, d, b, c), 0) == 0 for a, b, c, d in itertools.product(range(n), repeat=4))
def part_P(seeds):
    n, sq = 4, LOR; G = gammas(sq); BL = blades(G); g5 = G[0] @ G[1] @ G[2] @ G[3]; I4 = np.eye(4)
    ok_kn = ok_ps = ok_eps = ok_ant = ok_iff = True; ctl_ps = ctl_eps = nviol = nchance = 0; e_std = e_bs = 0.0; sizes = []
    for seed in seeds:
        rng = random.Random(seed); draws = [('kn', kn_tensor(rng, n)), ('eps', eps_tensor(rng.choice([-3, -2, -1, 1, 2, 3])))]
        for _ in range(20):                                                        # pair-symmetric draws until one violates the first Bianchi identity
            Xl = pairsym_tensor(rng, n); draws.append(('ps', Xl))
            if not cyclic_ok(Xl, n): break
        for kind, Xl in draws:
            Rf = to_Rf(Xl, sq); K = clifford_contraction(Rf, n, sq); R = scalar_R(Rf, n); A = antisym4(Rf, sq)
            Rst, Ast = std_scalar_and_alt(Xl, sq); Ks = std_K(Xl, sq, G)
            e_std = max(e_std, relerr(Ks, -2 * Rst * I4 + 24 * detq(sq) * Ast * g5)); e_bs = max(e_bs, relerr(to_mat(BL, K), Ks))
            if kind == 'kn': ok_kn &= (K == clean({0: -2 * R})) and A == 0 and antipodal(Rf, sq) == 0 and cyclic_ok(Xl, n); continue
            ok = grade(K, 0) == clean({0: -2 * R}) and grade(K, 2) == {} and K.get(15, 0) == 24 * detq(sq) * A and set(K) <= {0, 15}
            ok_ant &= (A == antipodal(Rf, sq) / 3); cyc = cyclic_ok(Xl, n); ok_iff &= (cyc == (set(K) <= {0}) == (A == 0))
            if kind == 'ps':
                ok_ps &= ok
                if cyc: nchance += 1
                else: nviol += 1; ctl_ps += int(K.get(15, 0) != 0); sizes.append(('pair-symmetric, no Bianchi', R, A, K.get(15, 0)))
            else: ok_eps &= ok and R == 0; ctl_eps += int(K.get(15, 0) != 0); sizes.append(('t eps', R, A, K.get(15, 0)))
    ns = len(seeds)
    for lab, R, A, k4 in sizes[:2]: print('    example (%s): R = %s, X_[0123] = %s, 4-vector part of K = %s gamma_0123' % (lab, R, A, k4))
    print('    pair-symmetric random draws: %d violate the first Bianchi identity, %d satisfy it by chance (X_[0123] = 0)' % (nviol, nchance))
    chk('bit', ok_kn, 'algebraic curvature tensors (Kulkarni-Nomizu squares, %d samples): K = sum R^cd_ab gamma^a gamma^b gamma_c gamma_d = -2R exactly, R_[0123] = 0, antipodal-cell sum R_0123 + R_0231 + R_0312 = 0' % ns)
    chk('bit', ok_ps and ok_eps, 'pair-symmetric tensors (%d draws) and t*epsilon (%d): K_0 = -2R, K_2 = 0, K_4 = 24 det(eta) X_[0123] gamma_0123 = -24 X_[0123] gamma_0123, nothing else' % (nviol + nchance, ns))
    chk('bit', ok_ant and ok_iff, 'pair-symmetric: X_[0123] = (1/3)(X_0123 + X_0231 + X_0312) (the 4-vector part is -8 x the sum over the three antipodal cells), and K is a scalar <=> X_[0123] = 0 <=> the cyclic (first Bianchi) sums vanish')
    chk('ctl', nviol >= ns and ctl_ps == nviol and ctl_eps == ns, 'without the first Bianchi identity the contraction is NOT a scalar: 4-vector part non-zero on %d of %d Bianchi-violating pair-symmetric draws and %d of %d epsilon samples' % (ctl_ps, nviol, ctl_eps, ns))
    chk('std', e_std < 1e-9, 'Dirac matrices: sum X gamma^a gamma^b gamma^c gamma^d = -2R 1 + 24 det(eta) X_[0123] gamma_0 gamma_1 gamma_2 gamma_3 for all %d tensors (max rel. error %.1e)' % (3 * ns, e_std))
    chk('bit==std', e_bs < 1e-9, 'the bit-rule contraction mapped to matrices (blade = product of gamma matrices in increasing order) equals the matrix contraction (max rel. error %.1e)' % e_bs)

# ------------------------------------------------------------------------------------------------ part O: torsion-free frames
def lc_part(n, sq, seeds, name, full=True, controls=True, std_on=True):
    G = gammas(sq); BL = blades(G)
    st = dict(T0=True, Rstd=True, Rein=True, Kscal=True, R4=True, pair=True, O1=True, J=True, nonvac=True, psi0=True)
    er = dict(om=0.0, nab=0.0, D2=0.0, Lap=0.0, Rfl=0.0, stdres=0.0, gam=0.0); cstd = []; samples = []; s_nf, s_fz, s_eu = [], [], []; ctl_c = {'-1/2': [0, 0], '+1/4': [0, 0]}; ctl_ss = None
    for i, seed in enumerate(seeds):
        d = lc_setup(n, sq, seed); Gv, e, E0, om = d['Gv'], d['e'], d['E0'], d['om']
        with trunc(n, xdeg=1): T = Gv.torsion(om, e)
        st['T0'] &= all(all(not p for p in f.values()) for f in T)
        with trunc(n, xdeg=0): R0 = Gv.curvature(om)
        Rf = curv_frame(Gv, R0, E0, n); R = scalar_R(Rf, n); st['nonvac'] &= (R != 0)
        g = std_metric(e, n, sq, n, 2); R1, g0, g0i = std_riemann(g, n, n, 1); _, _, Rs = std_einstein_mixed(R1, g0, g0i, n)
        st['Rstd'] &= (R == Rs)
        if full:
            comp = engine_E_from_R(Gv, e, R0, n, 0); M = mixed_from_components(comp, d['e0'], d['det'], n, s=-1)
            st['Rein'] &= (sum((M[a][a] for a in range(n)), F(0)) == (1 - F(n, 2)) * R)
        K = clifford_contraction(Rf, n, sq); st['Kscal'] &= (K == clean({0: -2 * R})); st['pair'] &= pair_symmetric(Rf, n, sq)
        if n == 4: st['R4'] &= (antisym4(Rf, sq) == 0 and antipodal(Rf, sq) == 0)
        ops = engine_ops(d, want_J=full); psi0 = ops['psi0']; st['psi0'] &= bool(psi0)
        res = mv_add(ops['D2'], ops['Lap'], -1); base = mv_scale(psi0, R); samples.append((res, [base]))
        st['O1'] &= (ops['D2'] == ops['GG'])
        if full: st['J'] &= (ops['D2J'] == mv_scale(ops['D2'], -1))
        if i == 0: print('    %s, first frame: det e = %s, R = %s; components of psi(0): %d, of Dslash^2 psi(0): %d' % (name, d['det'], R, len(psi0), len(ops['D2'])), flush=True)
        if controls:
            for lab, c in (('-1/2', F(-1, 2)), ('+1/4', F(1, 4))): ctl_c[lab][1] += 1; ctl_c[lab][0] += int(res != mv_scale(base, c))
            N2nf = second_cov(Gv, om, E0, ops['nab1'], n, frame_term=False); s_nf.append((mv_add(ops['D2'], lap_contract(N2nf, n, sq), -1), [base]))
            fz = engine_ops(d, frozen=True); s_fz.append((mv_add(fz['D2'], fz['Lap'], -1), [base]))
            eu = engine_ops(d, rs=[1] * n); s_eu.append((mv_add(eu['D2'], eu['Lap'], -1), [base]))
        if std_on:
            for a in range(n):
                for b in range(n): er['gam'] = max(er['gam'], relerr(G[a] @ G[b] + G[b] @ G[a], 2 * (sq[a] if a == b else 0) * np.eye(G[0].shape[0])))
            sd = StdSpin(e, d['psi'], n, sq, G).at_origin()
            om_eng = np.zeros((n, n, n))
            for A, (a, b) in enumerate(pairs_of(Gv.L)):
                for mu in range(n): v = float(at0(om[A].get(1 << mu, {}), n)); om_eng[mu, a, b] = v; om_eng[mu, b, a] = -v
            er['om'] = max(er['om'], relerr(om_eng, sd['om0'] * np.array(sq, dtype=float)[None, None, :]))
            er['nab'] = max(er['nab'], max(relerr(to_mat(BL, ops['nab0'][b]), sd['nb0'][b]) for b in range(n)))
            er['D2'] = max(er['D2'], relerr(to_mat(BL, ops['D2']), sd['D2'])); er['Lap'] = max(er['Lap'], relerr(to_mat(BL, ops['Lap']), sd['Lap']))
            er['Rfl'] = max(er['Rfl'], abs(sd['Rs'] - float(Rs)) / max(1.0, abs(float(Rs))))
            c, rr = lsq_c(sd['D2'] - sd['Lap'], sd['Rs'] * sd['Psi0']); cstd.append(c); er['stdres'] = max(er['stdres'], rr)
            if controls and i == 0:
                sw = StdSpin(e, d['psi'], n, sq, G, spin_sign=-1.0).at_origin(); ctl_ss = lsq_c(sw['D2'] - sw['Lap'], sw['Rs'] * sw['Psi0'])[1]
    k = len(seeds)
    chk('bit', st['T0'], '%s: the A3 omega is torsion-free as a 1-jet on all %d frames (the hypothesis; reads the h table)' % (name, k))
    chk('bit==std', st['Rstd'] and st['nonvac'], '%s: R = sum_ab R^ab(E_a, E_b) from the engine equals the exact std scalar curvature of g = e^T eta e (Christoffel route), non-zero, %d frames' % (name, k))
    if full: chk('bit', st['Rein'], '%s: the same R from the trace of the Einstein form E_a (A4 reading): sum_a G^a_a = (1 - n/2) R, %d frames' % (name, k))
    chk('bit', st['Kscal'] and st['pair'] and st['R4'], '%s: engine curvature, pointwise: pair symmetric%s, and the Clifford contraction is the scalar -2R exactly, %d frames' % (name, ', R_[0123] = 0 and antipodal-cell sum = 0 (first Bianchi)' if n == 4 else '', k))
    chk('bit', st['O1'], '%s: literal Dslash(Dslash psi) = sum_ab gamma^a gamma^b (nabla^2 psi)(E_a, E_b) at the origin (gamma covariantly constant; frame-index term from the h table)' % name)
    w, rank, cons = fit(samples, 1)
    chk('bit', st['psi0'] and cons and rank == 1 and w[0] == F(-1, 4), '%s: Dslash^2 psi - nabla^a nabla_a psi = c R psi, exact fit over all %d components x %d frames: single value c = %s (predicted -1/4)' % (name, 1 << n, k, w[0] if w else 'none'))
    if full: chk('bit', st['J'], '%s: with J = gamma_2 gamma_1 on the right (the Atlas operator psi -> (Dslash psi) J): its square is -Dslash^2 = -nabla^a nabla_a + R/4, exact' % name)
    if std_on:
        chk('std', er['gam'] < 1e-12 and er['Rfl'] < 1e-6, '%s: matrices satisfy the Clifford relations of sq = %s; the scalar curvature of the std spin connection (finite differences) equals the exact Christoffel one (rel. %.1e)' % (name, sq, er['Rfl']))
        chk('std', er['stdres'] < 1e-6 and max(abs(c + 0.25) for c in cstd) < 1e-6, '%s: std route alone: Dslash^2 Psi - nabla^a nabla_a Psi = c R Psi with c = %s (least squares, rel. residual %.1e)' % (name, ', '.join('%.8f' % c for c in cstd), er['stdres']))
        chk('bit==std', er['om'] < 1e-6 and er['nab'] < 1e-6, '%s: first order: engine omega^{ab}_mu = std omega_mu^a_b eta_bb, engine nabla_b psi(0) = std nabla_b Psi(0) as matrices (rel. %.1e, %.1e)' % (name, er['om'], er['nab']))
        chk('bit==std', er['D2'] < 1e-6, '%s: second order: engine literal Dslash(Dslash psi)(0) = std (Dirac matrices, Christoffel) (rel. %.1e)' % (name, er['D2']))
        chk('bit==std', er['Lap'] < 1e-6, '%s: second order: engine Laplacian nabla^a nabla_a psi(0) = std (rel. %.1e)' % (name, er['Lap']))
    if controls:
        for lab, (dif, seen) in ctl_c.items(): chk('ctl', dif == seen and seen > 0, '%s: coefficient %s instead of -1/4 fails on %d of %d frames' % (name, lab, dif, seen))
        for lab, ss in (('Laplacian without the frame-index term -omega^c_b nabla_c', s_nf), ('frozen dual frame (E at the point inside nabla_b psi)', s_fz), ('Euclidean contraction on the Lorentz frame (gamma^a := gamma_a, delta^ab)', s_eu)):
            w2, rk2, cons2 = fit(ss, 1); chk('ctl', not cons2, '%s: %s: no c fits (exact fit inconsistent)' % (name, lab))
        if ctl_ss is not None: chk('ctl', ctl_ss > 1e-3, '%s: [std] spin connection with the wrong sign, -(1/4) omega gamma gamma: Dslash^2 - Laplacian is not a multiple of R Psi (rel. residual %.2f)' % (name, ctl_ss))
    return w[0] if w else None

# ------------------------------------------------------------------------------------------------ part T: torsion
def rand_contorsion(rng, n, density=.6):
    Kp = {}
    for a in range(n):
        for b in range(a + 1, n):
            form = {}
            for mu in range(n):
                if rng.random() < density:
                    p = nz_poly(gs.rpoly(rng, n, 1, .7))
                    if p: form[1 << mu] = p
            Kp[(a, b)] = form
    return Kp
def part_T(seeds_fit, seeds_ver, std_on=True):
    n, sq = 4, LOR; G = gammas(sq); BL = blades(G); dq = detq(sq)
    st = dict(Tnz=True, K0=True, K2=True, K4=True, ricDT=True, W4=True, ver=True, DTform=True, K2nz=0, K4nz=0, tf=0)
    er = dict(D2=0.0, Lap=0.0, Tf=0.0, frm=0.0); fit_s, brief_s = [], []; sizes = []
    for seed in seeds_fit + seeds_ver:
        d = lc_setup(n, sq, seed); Gv, e, E0, Fm = d['Gv'], d['e'], d['E0'], d['Gv'].Fm
        Kp = rand_contorsion(random.Random(seed + 7000), n)
        om2 = [dict(x) for x in d['om']]
        for (a, b), form in Kp.items(): A = Gv.L.idx[(1 << a) | (1 << b)]; om2[A] = Fm.add(om2[A], form)
        with trunc(n, xdeg=1): T = Gv.torsion(om2, e)
        with trunc(n, xdeg=0):
            R2 = Gv.curvature(om2); DT = Gv.D_vector(om2, T); W = {}
            for c in range(n): W = Fm.add(W, Fm.wedge(e[c], DT[c]), sq[c])
        Rf2 = curv_frame(Gv, R2, E0, n); Rsc = scalar_R(Rf2, n); K = clifford_contraction(Rf2, n, sq); K0, K2, K4 = grade(K, 0), grade(K, 2), grade(K, 4)
        Tf = {(c, a, b): form2_on(T[c], E0, n, a, b) for c in range(n) for a in range(n) for b in range(n)}
        ric = ricci(Rf2, n, sq); A4 = antisym4(Rf2, sq); w4 = at0(W.get(15, {}), n) / d['det']
        st['Tnz'] &= any(v != 0 for v in Tf.values()); st['K0'] &= (K0 == clean({0: -2 * Rsc})); st['K2'] &= (K2 == K2_pred(ric, n, sq)); st['K4'] &= (K4 == clean({15: 24 * dq * A4}))
        rDT = {(a, b): sum((form3_on(DT[c], E0, n, a, c, b) for c in range(n)), F(0)) for a in range(n) for b in range(n)}
        st['ricDT'] &= all(ric[(a, b)] - ric[(b, a)] == rDT[(a, b)] for a in range(n) for b in range(n)); st['W4'] &= (w4 == 12 * A4)
        st['K2nz'] += int(bool(K2)); st['K4nz'] += int(bool(K4)); sizes.append((max([abs(v) for v in K2.values()] or [0]), K4.get(15, 0), Rsc))
        ops = engine_ops(d, om=om2); psi0 = ops['psi0']; res = mv_add(ops['D2'], ops['Lap'], -1)
        t0 = mv_scale(psi0, Rsc); tT = tT_term(Tf, ops['nab0'], n, sq); t2 = mv_mul(K2, psi0, sq); t4 = mv_mul(K4, psi0, sq)
        st['tf'] += int(res != mv_scale(t0, F(-1, 4)))
        if seed in seeds_fit: fit_s.append((res, [t0, tT, t2, t4])); brief_s.append((res, [t0, tT, t4]))
        else:
            pred = mv_add(mv_add(mv_scale(t0, F(-1, 4)), mv_scale(tT, F(-1, 2))), mv_add(mv_scale(t2, F(1, 8)), mv_scale(t4, F(1, 8))))
            st['ver'] &= (res == pred)
            m2 = {}
            for a in range(n):
                for b in range(a + 1, n):
                    v = F(1, 2) * rDT[(a, b)] * sq[a] * sq[b]
                    if v: m2[(1 << a) | (1 << b)] = v
            t2DT = mv_mul(m2, psi0, sq); t4DT = mv_mul(clean({15: F(dq, 4) * w4}), psi0, sq)
            st['DTform'] &= (res == mv_add(mv_add(mv_scale(t0, F(-1, 4)), mv_scale(tT, F(-1, 2))), mv_add(t2DT, t4DT)))
        if std_on:
            sd = StdSpin(e, d['psi'], n, sq, G, Kp=Kp).at_origin()
            er['D2'] = max(er['D2'], relerr(to_mat(BL, ops['D2']), sd['D2'])); er['Lap'] = max(er['Lap'], relerr(to_mat(BL, ops['Lap']), sd['Lap']))
            Tfe = np.array([[[float(Tf[(c, a, b)]) for b in range(n)] for a in range(n)] for c in range(n)]); er['Tf'] = max(er['Tf'], relerr(Tfe, sd['Tf']))
            er['frm'] = max(er['frm'], relerr(sd['D2'] - sd['Lap'], sd['pred']))
    for (k2, k4, r) in sizes[:2]: print("    example: R' = %s, largest |coefficient| of K'_2 = %s, 4-vector coefficient of K' = %s" % (r, k2, k4), flush=True)
    kk = len(seeds_fit) + len(seeds_ver)
    chk('bit', st['Tnz'], 'omega\' = omega + random contorsion (polynomial, degree <= 1): the torsion T = D e is non-zero on all %d frames' % kk)
    chk('bit', st['K0'] and st['K2'] and st['K4'], "with torsion the contraction K' still splits as -2R' + 4 sum_{a<d}(Ric'_ad - Ric'_da) gamma^a gamma^d + 24 det(eta) R'_[0123] gamma_0123, exact (%d frames)" % kk)
    chk('ctl', st['K2nz'] == kk and st['K4nz'] == kk, "with torsion the 2-vector part (non-symmetric Ricci) is non-zero on %d of %d frames and the 4-vector part (R'_[0123] != 0) on %d of %d" % (st['K2nz'], kk, st['K4nz'], kk))
    chk('bit', st['ricDT'] and st['W4'], "both parts are DT terms (first Bianchi with torsion, D T = R e): Ric'_ad - Ric'_da = sum_c DT^c(E_a, E_c, E_d), and (sum_c eta_cc e^c ^ DT^c)(E_0..E_3) = 12 R'_[0123]")
    chk('ctl', st['tf'] == kk, "the torsion-free formula Dslash'^2 - nabla'^a nabla'_a = -(R'/4) fails on %d of %d frames with torsion" % (st['tf'], kk))
    w, rank, cons = fit(fit_s, 4)
    chk('bit', cons and rank == 4 and w == [F(-1, 4), F(-1, 2), F(1, 8), F(1, 8)], "exact fit of Dslash'^2 psi - nabla'^a nabla'_a psi on (R' psi, gamma^a gamma^b T^c_ab nabla'_c psi, K'_2 psi, K'_4 psi), %d frames: unique coefficients %s (predicted -1/4, -1/2, 1/8, 1/8)" % (len(seeds_fit), [str(x) for x in w] if w else 'none'))
    wb, rkb, consb = fit(brief_s, 3)
    chk('bit', not consb, "the pieces alone (R' psi, the T nabla term, the 4-vector term) do NOT fit: the 2-vector term from the non-symmetric Ricci part is needed (fit inconsistent)")
    chk('bit', st['ver'] and st['DTform'], "fresh frames (%d): residual = -(R'/4) psi - (1/2) gamma^a gamma^b T^c_ab nabla'_c psi + (1/2) sum_{a<d} [sum_c DT^c(E_a,E_c,E_d)] gamma^a gamma^d psi + (det eta / 4) (eta_cc e^c DT^c)_0123 gamma_0123 psi, exact" % len(seeds_ver))
    if std_on:
        chk('std', er['frm'] < 1e-6, "std route with the same contorsion: Dslash'^2 - nabla'^a nabla'_a = (1/8) R'^cd_ab gamma^a gamma^b gamma_c gamma_d - (1/2) gamma^a gamma^b T^c_ab nabla'_c (Dirac matrices; rel. %.1e)" % er['frm'])
        chk('bit==std', er['D2'] < 1e-6, "with torsion: engine literal Dslash'(Dslash' psi)(0) = std with the same contorsion (rel. %.1e)" % er['D2'])
        chk('bit==std', er['Lap'] < 1e-6 and er['Tf'] < 1e-6, "with torsion: engine Laplacian' psi(0) and T^c_ab = std (rel. %.1e, %.1e)" % (er['Lap'], er['Tf']))

# ------------------------------------------------------------------------------------------------ main
def main():
    head('E1 part P: the Clifford contraction of curvature-like tensors, pointwise (n = 4, sq = (+,-,-,-)); bit rule, and Dirac matrices for [std]')
    part_P([11, 12] if QUICK else [11, 12, 13]); tick('part P')
    head('E1 part O: torsion-free random polynomial frames (degree 2), n = 4, (+,-,-,-), the origin; spinors = polynomials of degree 2 in all 16 components')
    lc_part(4, LOR, [401, 402] if QUICK else [401, 402, 403], 'n=4 Lorentz', full=True, controls=True); tick('part O')
    head('E1 part T: torsion: omega\' = omega + random contorsion, every object built from omega\'')
    part_T([501, 502] if QUICK else [501, 502, 503], [504] if QUICK else [504, 505]); tick('part T')
    head('E1 part S: other sign patterns, each computed consistently (omega, R and the contraction from the same sq), and n = 3')
    cE = lc_part(4, [1, 1, 1, 1], [601], 'n=4 (+,+,+,+)', full=False, controls=False)
    cN = lc_part(4, [-1, -1, -1, -1], [602], 'n=4 (-,-,-,-)', full=False, controls=False)
    d = lc_setup(4, [-1, -1, -1, -1], 602); e = d['e']
    Rm = std_einstein_mixed(*std_riemann(std_metric(e, 4, [-1] * 4, 4, 2), 4, 4, 1), 4)[2]; Rp = std_einstein_mixed(*std_riemann(std_metric(e, 4, [1] * 4, 4, 2), 4, 4, 1), 4)[2]
    chk('std', Rm == -Rp and Rp != 0, 'Lawson-Michelsohn reading: for eta = -delta the metric is -e^T e and R_eta = -R(e^T e) (%s = -(%s)), so Dslash^2 = nabla^a nabla_a - R_eta/4 is D^2 = nabla*nabla + R_g/4' % (Rm, Rp))
    chk('bit', cE == cN == F(-1, 4), 'the sign of c does not flip when the signature is changed consistently: c = %s for (+,+,+,+) and %s for (-,-,-,-), relative to R of e^T eta e' % (cE, cN))
    lc_part(3, [1, -1, -1], [301, 302], 'n=3 (+,-,-)', full=True, controls=False); tick('part S')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('E1')

if __name__ == '__main__': main()
