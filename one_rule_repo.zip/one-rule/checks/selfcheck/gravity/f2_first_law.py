#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F2.  Classical first law and Smarr among the engine's kH, Omega_H, Phi_H and the metric parameters (no radiation, no temperature).   python3 f2_first_law.py

 Naming: kH = surface gravity; kappa = the Atlas's coupling 8 pi G (D1), an input; Q = Coulomb coefficient of A (A_t = Q/rho at a = 0; source charge q = 4 pi Q, C3).
 Family  Kerr-Newman in Kerr-Schild form on the Kerr l (C2's g2_kerr): e^a = dx^a - f l^a l, f = (M r - s) r^2/(r^4 + a^2 z^2), s = kappa Q^2/4 (C3), A = (Q r^3/(r^4 + a^2 z^2)) l.
         s = 0: Kerr (= g2_kerr.kerr_ks_frame_jet exactly); a = 0: RN f = M/rho - s/rho^2 (= b1lib.ks_frame_jet with C3's jets exactly); exact 2-jets at rational points.
 Engine  kH: nabla_chi chi = kH chi (A3 closed-form omega at the point, Grav.D_vector; C2's recipe), chi = d_t + Omega d_phi, advanced chart (future horizon).
         Omega_H: double root of |d_t + Omega d_phi|^2 on the horizon (frame data).  Abar = A/(4 pi): induced 2-metric of t = const, r = r_h from the frame value
         (bit-rule squares), det(-h) = Abar^2 sin^2 th at the points.  Phi_H: RN, frame component F_0i xhat_i of the engine's F = dA along a ray (value and 2-jet = Q/rho^2),
         integral from r_h to infinity; KN, gauge value chi.A on the horizon (A -> 0 at infinity) with i_chi F = -d(chi.A) at the points.
 Closed  r_h = M +- sqrt(M^2 - a^2 - 2s) and Abar = r_h^2 + a^2, J = M a (RECALLED Komar/ADM value): exact dual numbers give dM, dAbar, dJ, dQ along rational directions.
 Fit     dM = alpha kH dAbar + beta Omega dJ + gamma Phi dQ and M = alpha' kH Abar + beta' Omega J + gamma' Phi Q: constants solved from three rows, checked on all rows.
 [std]   Christoffel route for nabla_chi chi (g2_kerr.std_nabla_vv); recalled Boyer-Lindquist kH, Omega, Phi; recalled Christodoulou-Ruffini mass formula
         M^2 = (Abar + Qg^2)^2/(4 Abar) + J^2/Abar (Qg^2 = 2s) and its exact partial derivatives; Christoffel route of the Einstein tensor for the fifth chip.
 Stretch Kerr-Newman: E_a = lambda T_a (T(a) = -1/2 F a F, C3's stress) with one lambda before any KN row enters the first law.
 Fifth   T = (x-2)(x+1)/(x+3), areal radius x^2 (null_selfcheck EF chart): kH = (1/2) T'(2) = 3/10 (the Atlas's recipe), engine E_a on its frame, effective stress G/kappa.
 Exports (import-safe, no engine object at import): kn_frame_jet, kn_potential, coulomb_A3, area_density, horizon_numbers, ray_jet, Du, family_closed, cr_partials,
         maxwell_stress_comp, fifth_frame, MEMBERS."""
import sys, os, time, itertools
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from b1lib import *
import g2_kerr as K
import g2_hodge as H

NV = 4; SQ = LORENTZ(4); T0 = time.time()
_jm = K._jm
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ frames and fields (exact 2-jets)
def kn_frame_jet(p, M, a, s=0, r0=None, nv=NV, retarded=False, tfac=None, a_l=None):
    """coframe e^a = dx^a - f l^a l_mu dx^mu, f = (M r - s) r^2/(r^4 + a^2 z^2), l the Kerr l (parameter a_l, default a); exact 2-jets in delta = x - p.
    tfac: f -> f (1 + tfac t) (control: time-dependent mass); retarded: l_i -> -l_i (time reverse). E = inverse frame (delta + f l^mu l_a when l is null, else Neumann series).
    Returns (e, E, (l_up, l_dn), data) like g2_kerr.kerr_ks_frame_jet."""
    p = tuple(F(c) for c in p); M, a, s = F(M), F(a), F(s); a_l = a if a_l is None else F(a_l)
    if r0 is None:
        b = sum(c * c for c in p) - a * a; sq_ = K.rat_sqrt(b * b + 4 * a * a * p[2] ** 2); r0 = K.rat_sqrt((b + sq_) / 2) if sq_ is not None else None
        if r0 is None: raise ValueError('r(p) not rational')
    r0 = F(r0); assert r0 > 0 and K.kerr_P(r0, p, a) == 0
    X = [None] + [lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))) for i in (1, 2, 3)]
    r, resP = K.kerr_r_jet(p, r0, a, nv); assert not resP
    r2 = _jm(r, r); r3 = _jm(r2, r); r4 = _jm(r2, r2)
    f = _jm(lin((M, r3), (-s, r2)), K.recip2(lin((F(1), r4), (a * a, _jm(X[3], X[3]))), nv))
    if tfac: f = _jm(f, lin((F(1), const(nv, 1)), (F(tfac), var(nv, 0))))
    invA = K.recip2(lin((F(1), r2), (a_l * a_l, const(nv, 1))), nv); invr = K.recip2(r, nv)
    l1 = _jm(lin((F(1), _jm(r, X[1])), (a_l, X[2])), invA); l2 = _jm(lin((F(1), _jm(r, X[2])), (-a_l, X[1])), invA); l3 = _jm(X[3], invr)
    if retarded: l1, l2, l3 = scale(l1, -1), scale(l2, -1), scale(l3, -1)
    l_dn = [const(nv, 1), l1, l2, l3]; l_up = [const(nv, 1)] + [scale(q, -1) for q in (l1, l2, l3)]
    e = []; E = [[None] * 4 for _ in range(4)]
    for A_ in range(4):
        form = {}
        for mu in range(4):
            pol = lin((F(1 if A_ == mu else 0), const(nv, 1)), (F(-1), _jm(_jm(f, l_up[A_]), l_dn[mu])))
            if pol: form[1 << mu] = pol
            E[mu][A_] = lin((F(1 if A_ == mu else 0), const(nv, 1)), (F(1), _jm(_jm(f, l_up[mu]), l_dn[A_])))
        e.append(form)
    if a_l != a:
        Mx = [[e[A_].get(1 << mu, {}) for mu in range(4)] for A_ in range(4)]
        with trunc(4, xdeg=2): E, _ = inverse_series(Mx, 4, nv, 2)
    return e, E, (l_up, l_dn), dict(r=r, f=f, r0=r0, p=p, M=M, a=a, s=s, a_l=a_l, retarded=retarded, l_dn=l_dn)

def kn_potential(Q, data, nv=NV):
    """A = (Q r^3/(r^4 + a^2 z^2)) l_mu dx^mu (2-jets); a = 0: (Q/rho) l, C3's potential"""
    r, a, p = data['r'], data['a'], data['p']; z = lin((F(1), const(nv, p[2])), (F(1), var(nv, 3))); r2 = _jm(r, r)
    h = scale(_jm(_jm(r2, r), K.recip2(lin((F(1), _jm(r2, r2)), (a * a, _jm(z, z))), nv)), F(Q))
    return {1 << mu: q for mu in range(4) for q in [_jm(h, data['l_dn'][mu])] if q}

def coulomb_A3(p, rho0, Q, nv=NV):
    """A = Q/rho (dt + x_i/rho dx^i) as exact 3-jets (same as c3_rn.coulomb_A, power 1)"""
    rp = H.rho_pow_jet(p, rho0, -1, 3, nv); rp1 = H.rho_pow_jet(p, rho0, -2, 3, nv); A = {1: scale(rp, F(Q))}
    for i in (1, 2, 3):
        xi = lin((F(1), const(nv, p[i - 1])), (F(1), var(nv, i))); A[1 << i] = scale(sp_mul(xi, rp1, 3, nv), F(Q))
    return A

def area_density(e, P, a, sq=SQ):
    """det(-h) of the induced 2-metric of t = const, r = P['r'] in the coordinates (th, ph) of x = sin th (r cos ph - a sin ph), y = sin th (r sin ph + a cos ph),
    z = r cos th, from the frame value at the point: h_AB = eta(e(d_A), e(d_B)) by bit-rule squares (polarisation)"""
    r, a = F(P['r']), F(a); ct, st, cp, sp = P['cth'], P['sth'], P['cph'], P['sph']
    dth = [F(0), ct * (r * cp - a * sp), ct * (r * sp + a * cp), -r * st]; dph = [F(0), st * (-r * sp - a * cp), st * (r * cp - a * sp), F(0)]
    e0 = [[at0(e[A_].get(1 << mu, {}), NV) for mu in range(4)] for A_ in range(4)]
    u = [sum(e0[A_][mu] * dth[mu] for mu in range(4)) for A_ in range(4)]; v = [sum(e0[A_][mu] * dph[mu] for mu in range(4)) for A_ in range(4)]
    nb = lambda w: K.frame_norm_bit(w, sq)
    huu, hvv = nb(u), nb(v); huv = (nb([x + y for x, y in zip(u, v)]) - huu - hvv) / 2
    return huu * hvv - huv * huv

def prop(u, w):
    """w = k u for one k (u not zero): k, else None"""
    i = next((j for j in range(len(u)) if u[j] != 0), None)
    if i is None: return None
    k = w[i] / u[i]; return k if all(w[j] == k * u[j] for j in range(len(u))) else None
def to_coord(E0, v): return [sum(E0[m][A_] * v[A_] for A_ in range(4)) for m in range(4)]
def lin1(p, i): return p.get(tuple(1 if j == i else 0 for j in range(NV)), F(0))
def one(S_):
    """the unique element of a set, else None"""
    return next(iter(S_)) if len(S_) == 1 else None

def ray_jet(P_, u, deg=2):
    """substitute delta = lam u into a jet: coefficients of lam^0..lam^deg"""
    out = [F(0)] * (deg + 1)
    for k, c in P_.items():
        if k[0] or sum(k) > deg: continue
        t = c
        for i in (1, 2, 3): t *= u[i - 1] ** k[i]
        out[sum(k)] += t
    return out

def horizon_numbers(Gv, S, M, a, s, rh, angs, Q=0, std=True, retarded=False, ray=False):
    """[bit] at the points of r = rh: Omega (double root), chi null, kH (nabla_chi chi = kH chi), det(-h), Phi (RN: ray route; KN: gauge value and i_chi F = -d(chi.A));
    [std] Christoffel route of nabla_chi chi. Sets of values (one element each when the zeroth law holds at these points)."""
    out = dict(kH=set(), Om=set(), null=set(), disc=set(), area=set(), phi=set(), exact=True, std=True, ray=True, n=0)
    for P in K.rational_kerr_points(a, [rh], angs):
        out['n'] += 1; p = P['p']
        e, E, (lu, ld), data = kn_frame_jet(p, M, a, s, r0=rh, retarded=retarded)
        disc, Om = K.null_rotation(e, p, SQ); out['disc'].add(disc); out['Om'].add(Om)
        chi = K.killing_chi(p, Om if Om is not None else 0)
        om = omega_closed_form(Gv, e, S, NV, 0)[0]; ca, nab = K.engine_nabla_vv(Gv, om, e, chi)
        out['null'].add(K.frame_norm_bit(ca, SQ)); out['kH'].add(prop(ca, nab))
        if std:
            e0, E0, det = E0_of(e, 4, 4); g = std_metric(e, 4, SQ, 4, 2); out['std'] &= to_coord(E0, nab) == K.std_nabla_vv(g, chi)
        dA = area_density(e, P, a); out['area'].add(K.rat_sqrt(dA / P['sth'] ** 2) if P['sth'] != 0 else None)       # Abar = sqrt(det(-h))/sin th
        if Q and a == 0 and ray:                                                  # RN: F_0i xhat_i along the ray, 2-jet, and Phi = r_h * value (integral of c/rho^2)
            u = [c / rh for c in p]; A3 = coulomb_A3(p, rh, Q)
            with trunc(4, xdeg=2): Fc = Gv.Fm.d(A3); Fab = H.frame_components(Fc, E, 4)
            Er = {}
            for i in (1, 2, 3): Er = sp_add(Er, Fab.get(1 | (1 << i), {}), u[i - 1])
            rj = ray_jet(Er, u); out['ray'] &= rj == [F(Q) / rh ** 2, -2 * F(Q) / rh ** 3, 3 * F(Q) / rh ** 4]
            A2 = kn_potential(Q, data); chiA0 = sum(at0(chi[mu], NV) * at0(A2.get(1 << mu, {}), NV) for mu in range(4))
            out['ray'] &= chiA0 == rj[0] * rh                                       # the gauge value chi.A (A_t -> 0 at infinity) = the integral
            out['phi'].add(rj[0] * rh)
        elif Q:                                                                   # KN: gauge value chi.A and exactness i_chi F = -d(chi.A) at the point
            A = kn_potential(Q, data); chiA = {}
            for mu in range(4):
                if chi[mu] and A.get(1 << mu): chiA = sp_add(chiA, sp_mul(chi[mu], A[1 << mu], 1, NV))
            out['phi'].add(at0(chiA, NV))
            with trunc(4, xdeg=1): Fc = Gv.Fm.d(A)
            c0 = [at0(q, NV) for q in chi]; iF = [F(0)] * 4
            for m, q in Fc.items():
                mu, nu = [b for b in range(4) if m >> b & 1]; v0 = at0(q, NV)
                iF[nu] += c0[mu] * v0; iF[mu] -= c0[nu] * v0
            out['exact'] &= all(iF[nu] + lin1(chiA, nu) == 0 for nu in range(4)) and any(iF)
    return out

# ------------------------------------------------------------------------------------------------ exact dual numbers and the family closed forms
class Du:
    """v + d eps (eps^2 = 0), Fractions"""
    __slots__ = ('v', 'd')
    def __init__(s, v, d=0): s.v = F(v); s.d = F(d)
    @staticmethod
    def c(o): return o if isinstance(o, Du) else Du(o)
    def __add__(s, o): o = Du.c(o); return Du(s.v + o.v, s.d + o.d)
    __radd__ = __add__
    def __sub__(s, o): o = Du.c(o); return Du(s.v - o.v, s.d - o.d)
    def __rsub__(s, o): return Du.c(o) - s
    def __neg__(s): return Du(-s.v, -s.d)
    def __mul__(s, o): o = Du.c(o); return Du(s.v * o.v, s.v * o.d + s.d * o.v)
    __rmul__ = __mul__
    def __truediv__(s, o): o = Du.c(o); return Du(s.v / o.v, (s.d * o.v - s.v * o.d) / (o.v * o.v))
    def __rtruediv__(s, o): return Du.c(o) / s
    def sqrt(s):
        r = K.rat_sqrt(s.v)
        if r is None: raise ValueError('not a rational square: %s' % s.v)
        if r == 0:
            if s.d != 0: raise ValueError('sqrt at 0 along a direction that leaves the extremal set')
            return Du(0, 0)
        return Du(r, s.d / (2 * r))

def family_closed(kappa, M, a, Q, dirn=(0, 0, 0), branch=1):
    """closed forms of the Kerr-Newman family (kappa fixed): r_h = M + branch sqrt(M^2 - a^2 - 2s), s = kappa Q^2/4, Abar = r_h^2 + a^2, J = M a (recalled),
    and the recalled Boyer-Lindquist kH = branch sqrt(.)/Abar, Omega = a/Abar, Phi = Q r_h/Abar; values and derivatives along dirn = (dM, da, dQ)"""
    Md, ad, Qd = Du(M, dirn[0]), Du(a, dirn[1]), Du(Q, dirn[2]); s = F(kappa) * Qd * Qd / 4
    rt = (Md * Md - ad * ad - 2 * s).sqrt(); rh = Md + branch * rt; Ab = rh * rh + ad * ad
    return dict(M=Md, a=ad, Q=Qd, s=s, rh=rh, Abar=Ab, J=Md * ad, kH=branch * rt / Ab, Om=ad / Ab, Phi=Qd * rh / Ab)

def cr_partials(kappa, Abar, J, Q, M):
    """[std] RECALLED Christodoulou-Ruffini M^2 = (Abar + Qg^2)^2/(4 Abar) + J^2/Abar, Qg^2 = kappa Q^2/2: (M^2 from the formula, dM/dAbar, dM/dJ, dM/dQ) at fixed others"""
    Qg2 = F(kappa) * Q * Q / 2; M2 = (Abar + Qg2) ** 2 / (4 * Abar) + J * J / Abar
    dA = ((Abar + Qg2) * (Abar - Qg2) / (4 * Abar ** 2) - J * J / Abar ** 2) / (2 * M)
    return M2, dA, J / (Abar * M), ((Abar + Qg2) / (2 * Abar)) * F(kappa) * Q / (2 * M)

def maxwell_stress_comp(Gv, e, E, A, sign=F(-1, 2)):
    """[bit] components of the stress forms T_a = T^b_a Theta_b at the point, T(a) = sign F a F with F = dA (engine d), as in c3_rn.maxwell_on_frame"""
    with trunc(4, xdeg=1): Fc = Gv.Fm.d(A); Fab = H.frame_components(Fc, E, 4)
    Fl0 = {(a, b): at0(Fab.get((1 << a) | (1 << b), {}), 4) for a in range(4) for b in range(a + 1, 4)}
    Tm = H.maxwell_T_bit(H.bivector(Fl0, SQ), SQ, sign)
    with trunc(4, xdeg=1): Ta = H.stress_forms(Tm, H.theta_forms(e, Gv.Fm, 4), Gv.Fm)
    return einstein_components(Ta, 4, 4), Fl0

def fifth_frame(x0, nv=NV):
    """the fifth chip, ds^2 = T dv^2 + 2 dv dx - x^4 dOmega^2, T = (x-2)(x+1)/(x+3): coframe e^0 = ((1+T)/2) dv + dx, e^1 = ((1-T)/2) dv - dx, e^2 = x^2 dth,
    e^3 = x^2 sin th dph; coordinates (v, x, th, ph), exact 2-jets at (0, x0, pi/2, 0); returns (e, T jet)"""
    x0 = F(x0); dx = var(nv, 1); dth = var(nv, 2); c = x0 + 3; dx2 = sp_mul(dx, dx, 2, nv); o = const(nv, 1)
    T = sp_mul(lin(((x0 - 2) * (x0 + 1), o), (2 * x0 - 1, dx), (F(1), dx2)), lin((1 / c, o), (-1 / c ** 2, dx), (1 / c ** 3, dx2)), 2, nv)
    X2 = lin((x0 * x0, o), (2 * x0, dx), (F(1), dx2)); sth = lin((F(1), o), (F(-1, 2), sp_mul(dth, dth, 2, nv)))
    return [{1: lin((F(1, 2), o), (F(1, 2), T)), 2: o}, {1: lin((F(1, 2), o), (F(-1, 2), T)), 2: const(nv, -1)}, {4: X2}, {8: sp_mul(X2, sth, 2, nv)}], T

ANG = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(5, 13), F(12, 13)), (F(3, 5), F(4, 5)))]
# (family, kappa, M, a, Q, directions (dM, da, dQ)); r_h are rational for all of them
D2 = [(1, 0, 0), (0, 1, 0), (F(2, 3), F(-5, 7), 0)]; DQ = [(1, 0, 0), (0, 0, 1), (F(2, 3), 0, F(-5, 7))]; D3 = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (F(1, 2), F(-2, 3), F(3, 7))]
MEMBERS = [('Schwarzschild', 1, F(3, 2), 0, 0, [(1, 0, 0), (F(-2, 3), 0, 0)]), ('Schwarzschild', 1, F(1), 0, 0, [(1, 0, 0)]), ('Schwarzschild', 1, F(5, 2), 0, 0, [(1, 0, 0)]),
           ('RN', 1, F(3, 2), 0, F(2), DQ), ('RN', 1, F(3), 0, F(4), DQ), ('RN', 1, F(9, 2), 0, F(4), DQ), ('RN', 4, F(3, 2), 0, F(1), DQ), ('RN', 2, F(5, 2), 0, F(3, 2), DQ),
           ('extremal RN', 2, F(1), 0, F(1), [(1, 0, 1)]), ('extremal RN', 2, F(2), 0, F(2), [(F(1, 2), 0, F(1, 2))]),
           ('Kerr', 1, F(5), F(3), 0, D2), ('Kerr', 1, F(5), F(4), 0, D2), ('Kerr', 1, F(5, 2), F(2), 0, D2), ('Kerr', 1, F(13, 2), F(6), 0, D2),
           ('Kerr-Newman', 1, F(5), F(1), F(4), D3), ('Kerr-Newman', 1, F(7, 2), F(2), F(2), D3), ('Kerr-Newman', 1, F(15, 2), F(2), F(8), D3)]

# ------------------------------------------------------------------------------------------------ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # built per run (an engine fault put into Lie in memory is seen)
    rn_j = lambda M, s, r: (M / r - s / r ** 2, -M / r ** 2 + 2 * s / r ** 3, 2 * M / r ** 3 - 6 * s / r ** 4)

    head('0. the frame builder against C2 and C1/C3 (exact jets)')
    ok = True; n0 = 0
    for P in K.rational_kerr_points(3, [9, 4], ANG):
        e1, E1, _, _ = kn_frame_jet(P['p'], 5, 3, 0, P['r']); e2, E2, _, _ = K.kerr_ks_frame_jet(P['p'], 5, 3, P['r']); ok &= e1 == e2 and E1 == E2; n0 += 1
    for P in K.rational_kerr_points(0, [2, 7], ANG):
        e1, E1, _, _ = kn_frame_jet(P['p'], F(3, 2), 0, 1, P['r']); e2, E2, _ = ks_frame_jet(P['p'], P['r'], *rn_j(F(3, 2), F(1), P['r'])); ok &= e1 == e2 and E1 == E2; n0 += 1
    chk('bit', ok, 'kn_frame_jet(s = 0) = g2_kerr.kerr_ks_frame_jet (M = 5, a = 3) and kn_frame_jet(a = 0) = b1lib.ks_frame_jet with f = M/rho - s/rho^2 (M = 3/2, s = 1): every jet of e and E, %d points' % n0)
    tick('part 0')

    head('1. Kerr-Newman stretch first: E_a = lambda T_a with ONE lambda (T(a) = -1/2 F a F, A = (Q r^3/(r^4 + a^2 z^2)) l), before any KN row enters the first law')
    kn_ok = True; lams = {}
    for (M, a, Q, kap, rs) in ((F(5), F(1), F(4), 1, [9, 20, 4, F(1, 2)]), (F(7, 2), F(2), F(2), 1, [6, 3]), (F(5), F(1), F(2), 4, [9])):
        s = F(kap) * Q * Q / 4
        for i, P in enumerate(K.rational_kerr_points(a, rs, ANG[:1]) if len(rs) > 2 else K.rational_kerr_points(a, rs, ANG)):
            e, E, _, data = kn_frame_jet(P['p'], M, a, s, P['r']); om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0)
            cT, Fl0 = maxwell_stress_comp(Gv, e, E, kn_potential(Q, data))
            k0 = next((k for k in sorted(cT) if cT[k] != 0), None); lam = comp[k0] / cT[k0] if k0 is not None else None
            good = lam is not None and all(comp[k] == lam * cT[k] for k in comp) and any(comp.values())
            lams.setdefault((M, a, Q, kap), set()).add(lam if good else 'not proportional'); kn_ok &= good
    for key, L in lams.items():
        M, a, Q, kap = key
        chk('bit', L == {-4 * (F(kap) * Q * Q / 4) / (Q * Q)}, 'KN (M, a, Q) = (%s, %s, %s), s = kappa Q^2/4 with kappa = %s: E_a = lambda T_a on all 16 components with ONE lambda = %s = -4 s/Q^2 = -kappa at every point (r = 9, 20, 4, 1/2 or 6, 3)' % (M, a, Q, kap, ', '.join(map(str, L))))
    kn_ok &= all(L == {-F(k[3])} for k, L in lams.items())
    print('    Kerr-Newman stretch: %s' % ('PASSES: the KN members enter the first law below' if kn_ok else 'FAILS: KN dropped'))
    tick('part 1')

    head('2. engine numbers on every horizon of every member: kH, Omega_H, Abar = A/(4 pi), Phi_H; [std] Christoffel route, recalled closed forms, Christodoulou-Ruffini')
    H_ = {}
    for (fam, kap, M, a, Q, dirs) in MEMBERS:
        if fam == 'Kerr-Newman' and not kn_ok: continue
        s = F(kap) * Q * Q / 4
        for br in ((1,) if fam in ('Schwarzschild', 'extremal RN') else (1, -1)):
            cf = family_closed(kap, M, a, Q, (0, 0, 0), br); rh = cf['rh'].v
            out = horizon_numbers(Gv, S, M, a, s, rh, ANG, Q=Q, ray=True)
            kH, Om, Ab, Phi = one(out['kH']), one(out['Om']), one(out['area']), (one(out['phi']) if Q else F(0))
            H_[(fam, kap, M, a, Q, br)] = dict(kH=kH, Om=Om, Abar=Ab, Phi=Phi, cf=cf, dirs=dirs, out=out)
            tag = '%s kappa=%s (M, a, Q) = (%s, %s, %s) %s horizon r = %s' % (fam, kap, M, a, Q, 'outer' if br == 1 else 'inner', rh)
            chk('bit', out['null'] == {0} and out['disc'] == {0} and kH is not None and Om is not None and Ab is not None and (Phi is not None) and out['exact'] and out['ray'],
                '%s: chi = d_t + Omega d_phi null at %d points, ONE kH = %s, Omega = %s (double root), det(-h)/sin^2 th = Abar^2 with Abar = %s, Phi = %s%s' % (
                    tag, out['n'], kH, Om, ', '.join(map(str, out['area'])), Phi, '' if not Q else (' (ray: F_0i xhat_i = Q/rho^2 to 2nd order; integral to infinity = gauge value chi.A)' if a == 0 else ' (chi.A, and i_chi F = -d(chi.A) at the points)')))
            M2, dA, dJ, dQ = cr_partials(kap, Ab, M * a, Q, M) if (Ab and kH is not None) else (None, None, None, None)
            chk('bit==std', out['std'] and (kH, Om, Ab, Phi) == (cf['kH'].v, cf['Om'].v, cf['Abar'].v, cf['Phi'].v) and M2 == M * M and kH == 2 * dA and Om == dJ and Phi * F(kap) == 2 * dQ,
                '%s: nabla_chi chi = Christoffel route; = recalled closed forms (kH, Omega, Abar, Phi) = (%s, %s, %s, %s); Christodoulou-Ruffini: M^2 = %s, kH = 2 dM/dAbar, Omega = dM/dJ, (kappa/2) Phi = dM/dQ' % (
                    tag, cf['kH'].v, cf['Om'].v, cf['Abar'].v, cf['Phi'].v, M2))
    def kv(fam, kap, M, a, Q, br): return H_.get((fam, kap, F(M), F(a), F(Q), br), {}).get('kH')
    chk('bit', (kv('Kerr', 1, 5, 3, 0, 1), kv('Kerr', 1, 5, 3, 0, -1), kv('Schwarzschild', 1, F(3, 2), 0, 0, 1)) == (F(2, 45), F(-2, 5), F(1, 6)),
        'C2\'s numbers reproduced by this recipe: Kerr (5, 3): kH = 2/45 (r = 9), -2/5 (r = 1); a = 0, M = 3/2: kH = 1/6')
    chk('bit', (kv('Schwarzschild', 1, F(3, 2), 0, 0, 1), kv('RN', 1, F(3, 2), 0, 2, 1), kv('RN', 1, F(3, 2), 0, 2, -1), kv('extremal RN', 2, 1, 0, 1, 1)) == (F(1, 6), F(1, 8), F(-1, 2), F(0)),
        'the Atlas\'s first four chips from the engine (advanced Kerr-Schild chart, future sign): kH = 1/6, 1/8, -1/2, 0 (Schwarzschild r_S = 3; RN r+ = 2, r- = 1; extremal RN M = 1)')
    head('2b. the area: off the horizon the density is not Abar^2 sin^2 th; [std] float quadrature of sqrt(det(-h)) over the whole cross-section')
    for (M, a, s) in ((F(5), F(3), F(0)), (F(5), F(1), F(4))):
        offs = K.rational_kerr_points(a, [20, 4], ANG); ok_c = True; ok_w = True
        for P in offs:
            e = kn_frame_jet(P['p'], M, a, s, P['r'])[0]; dA = area_density(e, P, a); r, st2 = P['r'], P['sth'] ** 2; Sig = r * r + a * a * P['cth'] ** 2
            ok_c &= dA == (r * r + a * a) * Sig * st2 + 2 * (M * r - s) * a * a * st2 * st2; ok_w &= dA != (r * r + a * a) ** 2 * st2
        chk('bit==std', ok_c, '(M, a, s) = (%s, %s, %s), r = 20 and 4 (off the horizons): det(-h) = (r^2 + a^2) Sigma sin^2 + 2 (M r - s) a^2 sin^4 (derived closed form, = (r^2 + a^2)^2 sin^2 only where Delta = 0), %d points' % (M, a, s, len(offs)))
        chk('ctl', ok_w, '(M, a, s) = (%s, %s, %s): the horizon formula (r^2 + a^2)^2 sin^2 th used off the horizon (r = 20, 4) fails at %d of %d points' % (M, a, s, len(offs), len(offs)))
        rh = M + K.rat_sqrt(M * M - a * a - 2 * s)                                   # outer horizon (Delta = r^2 - 2 M r + a^2 + 2 s = 0)
        import numpy as np
        xg, wg = np.polynomial.legendre.leggauss(40); php = np.linspace(0, 2 * np.pi, 48, endpoint=False); tot = 0.0
        for ct, w in zip(xg, wg):
            st = (1 - ct * ct) ** 0.5
            for ph in php:
                X = np.array([0.0, st * (float(rh) * np.cos(ph) - float(a) * np.sin(ph)), st * (float(rh) * np.sin(ph) + float(a) * np.cos(ph)), float(rh) * ct])
                b = X[1] ** 2 + X[2] ** 2 + X[3] ** 2 - float(a) ** 2; r = ((b + (b * b + 4 * float(a) ** 2 * X[3] ** 2) ** 0.5) / 2) ** 0.5
                f = (float(M) * r - float(s)) * r * r / (r ** 4 + float(a) ** 2 * X[3] ** 2); Aa = r * r + float(a) ** 2
                l = np.array([1.0, (r * X[1] + float(a) * X[2]) / Aa, (r * X[2] - float(a) * X[1]) / Aa, X[3] / r])
                g = np.diag([1.0, -1, -1, -1]) - 2 * f * np.outer(l, l)
                dth = np.array([0, ct * (r * np.cos(ph) - float(a) * np.sin(ph)), ct * (r * np.sin(ph) + float(a) * np.cos(ph)), -r * st]) / st     # d/d(cos th) = -(1/sin th) d/d th
                dph = np.array([0, st * (-r * np.sin(ph) - float(a) * np.cos(ph)), st * (r * np.cos(ph) - float(a) * np.sin(ph)), 0])
                h = np.array([[dth @ g @ dth, dth @ g @ dph], [dph @ g @ dth, dph @ g @ dph]])
                tot += w * (2 * np.pi / len(php)) * abs(np.linalg.det(h)) ** 0.5
        Ab = float(rh * rh + a * a)
        chk('std', abs(tot / (4 * np.pi) - Ab) < 1e-9 * Ab, '(M, a, s) = (%s, %s, %s), r+ = %s: float quadrature (40 x 48 nodes, closed-form g, no jets) of the cross-section area / (4 pi) = %.12f, Abar = %s' % (M, a, s, rh, tot / (4 * np.pi), rh * rh + a * a))
    tick('part 2')

    head('3. the first law dM = alpha kH dAbar + beta Omega dJ + gamma Phi dQ: constants FITTED from three rows, then every row (members x directions x horizons)')
    rows = []
    for key, h in H_.items():
        fam, kap, M, a, Q, br = key
        for d in h['dirs']:
            cf = family_closed(kap, M, a, Q, d, br)
            rows.append(dict(key=key, d=d, kap=F(kap), kH=h['kH'], Om=h['Om'], Phi=h['Phi'], Abar=h['Abar'], dM=cf['M'].d, dA=cf['Abar'].d, dJ=cf['J'].d, dQ=cf['Q'].d, da=cf['a'].d,
                             M=M, J=M * a, Q=Q, a=a))
    def R_(r, kH=None, Om=None, Phi=None, dJ=None, dA=None): return [(r['kH'] if kH is None else kH) * (r['dA'] if dA is None else dA), (r['Om'] if Om is None else Om) * (r['dJ'] if dJ is None else dJ), (r['Phi'] if Phi is None else Phi) * r['dQ']]
    def pick(fam, M, a, Q, br, d, kap=1): return next(r for r in rows if r['key'] == (fam, kap, F(M), F(a), F(Q), br) and r['d'] == d)
    try:
        fit_rows = [pick('Kerr', 5, 3, 0, 1, D2[0]), pick('Kerr', 5, 3, 0, 1, D2[1]), pick('RN', F(3, 2), 0, 2, 1, DQ[1])]
        det, inv = det_inv([R_(r) for r in fit_rows]); coef = [sum(inv[i][j] * fit_rows[j]['dM'] for j in range(3)) for i in range(3)] if det else None
    except Exception as ex: coef = None; print('    fit failed: %s' % ex)
    chk('bit', coef == [F(1, 2), F(1), F(1, 2)], 'fit (Kerr (5, 3) outer, dM and da; RN (3/2, Q = 2) outer, dQ; kappa = 1): (alpha, beta, gamma) = (%s); predicted (1/2, 1, 1/2) = (1/(8 pi) per unit area, 1, kappa/2)' % (', '.join(map(str, coef)) if coef else None))
    al, be, ga1 = coef if coef else (None, None, None)
    def resid(r, g, **kw):
        try: return r['dM'] - sum(c * t for c, t in zip((al, be, g), R_(r, **kw)))
        except TypeError: return None
    gam = {}
    for kap in sorted({r['kap'] for r in rows}):
        rk = [r for r in rows if r['kap'] == kap]; g = ga1 if kap == 1 else None
        if g is None:
            r0 = next((r for r in rk if r['Phi'] and r['dQ']), None)
            try: g = (r0['dM'] - al * r0['kH'] * r0['dA'] - be * r0['Om'] * r0['dJ']) / (r0['Phi'] * r0['dQ'])
            except Exception: g = None
        gam[kap] = g; ok = [resid(r, g) == 0 for r in rk]
        chk('bit', all(ok) and g == kap / 2, 'kappa = %s: gamma = %s = kappa/2; the first law holds on %d of %d rows (%s)' % (kap, g, sum(ok), len(ok), ', '.join(sorted({'%s %s' % (r['key'][0], 'outer' if r['key'][5] == 1 else 'inner') for r in rk}))))
    for fam in ('Schwarzschild', 'RN', 'extremal RN', 'Kerr', 'Kerr-Newman'):
        rf = [r for r in rows if r['key'][0] == fam]
        if not rf: continue
        chk('bit', all(resid(r, gam.get(r['kap'])) == 0 for r in rf), '%s: dM = (1/2) kH dAbar + Omega dJ + (kappa/2) Phi dQ on all %d rows (%d members x directions, outer%s)' % (
            fam, len(rf), len({r['key'] for r in rf}), ' and inner' if any(r['key'][5] == -1 for r in rf) else ''))
    ext = [r for r in rows if r['key'][0] == 'extremal RN']
    def safe(fn):
        try: return fn()
        except TypeError: return False
    chk('bit', all(safe(lambda: r['kH'] == 0 and r['dM'] == gam.get(r['kap']) * r['Phi'] * r['dQ'] and r['dM'] != 0) for r in ext), 'extremal RN (kappa = 2, M = Q = 1 and 2): kH = 0 from the engine, dM = (kappa/2) Phi dQ along the extremal curve r+ = r- (%d rows)' % len(ext))
    tick('part 3')

    head('4. Smarr M = alpha\' kH Abar + beta\' Omega J + gamma\' Phi Q: fitted from three members, checked on every member and horizon (Euler weights 2, 2, 1)')
    keys = list(H_)
    def SR(k, kH=None, Om=None, J=None): h = H_[k]; fam, kap, M, a, Q, br = k; return [(h['kH'] if kH is None else kH) * h['Abar'], (h['Om'] if Om is None else Om) * (M * a if J is None else J), h['Phi'] * Q]
    try:
        ks = [('Kerr', 1, F(5), F(3), F(0), 1), ('Kerr', 1, F(5), F(3), F(0), -1), ('RN', 1, F(3, 2), F(0), F(2), 1)]
        det, inv = det_inv([SR(k) for k in ks]); sc = [sum(inv[i][j] * ks[j][2] for j in range(3)) for i in range(3)] if det else None
    except Exception as ex: sc = None; print('    Smarr fit failed: %s' % ex)
    chk('bit', sc is not None and coef is not None and sc == [2 * coef[0], 2 * coef[1], coef[2]], 'Smarr fit (Kerr (5, 3) outer and inner, RN (3/2, 2) outer): (alpha\', beta\', gamma\') = (%s) = (2 alpha, 2 beta, gamma) = Euler scaling of the first law' % (', '.join(map(str, sc)) if sc else None))
    def sres(k, g, **kw):
        try: return k[2] - sum(c * t for c, t in zip((2 * al, 2 * be, g), SR(k, **kw)))
        except TypeError: return None
    sm = [sres(k, gam.get(F(k[1]))) == 0 for k in keys]
    chk('bit', all(sm), 'Smarr M = kH Abar + 2 Omega J + (kappa/2) Phi Q (G = 1: M = kH A/(4 pi) + 2 Omega J + Phi q) on %d of %d (member, horizon) pairs, signed kH on the inner horizons, kH = 0 extremal' % (sum(sm), len(sm)))
    tick('part 4')

    head('5. controls (a wrong version must fail on every row where it can be seen)')
    CT = {}
    def ctl(name, wrong): k = CT.setdefault(name, [0, 0]); k[1] += 1; k[0] += int(bool(wrong))
    for r in rows:
        g = gam.get(r['kap'])
        if r['kH'] and r['dA']: ctl('2 kH in the first law', resid(r, g, kH=2 * r['kH']) != 0); ctl('kH/2 in the first law', resid(r, g, kH=r['kH'] / 2) != 0)
        if r['Phi'] and r['dQ']: ctl('Phi -> -Phi in the first law', resid(r, g, Phi=-r['Phi']) != 0)
        if r['a'] and r['da'] != r['dJ']: ctl('J = a (M dropped) in the first law', resid(r, g, dJ=r['da']) != 0)        # seen only where d(a) != d(M a)
        fam, kap, M, a, Q, br = r['key']; other = H_.get((fam, kap, M, a, Q, -br))
        if br == 1 and other and r['dA']: ctl('outer area with the inner kH', resid(r, g, kH=other['kH']) != 0)
        if br == 1 and other and a and r['dJ']: ctl('Omega of the inner horizon with the outer area', resid(r, g, Om=other['Om']) != 0)
    for k in keys:
        fam, kap, M, a, Q, br = k; g = gam.get(F(kap))
        if H_[k]['kH']: ctl('2 kH in Smarr', sres(k, g, kH=2 * H_[k]['kH']) != 0); ctl('kH/2 in Smarr', sres(k, g, kH=H_[k]['kH'] / 2) != 0)
        try:
            if al * SR(k)[0] + be * SR(k)[1] != 0: ctl('Smarr with the first-law weights (alpha, beta, gamma)', k[2] != sum(c * t for c, t in zip((al, be, g), SR(k))))   # extremal: kH = Omega = 0, not seen
        except TypeError: ctl('Smarr with the first-law weights (alpha, beta, gamma)', False)
        if a and M != 1: ctl('J = a (M dropped) in Smarr', sres(k, g, J=a) != 0)
    for (fam, kap, M, a, Q) in (('Kerr', 1, F(5), F(3), F(0)), ('RN', 1, F(3, 2), F(0), F(2)), ('Schwarzschild', 1, F(3, 2), F(0), F(0))):
        k = (fam, kap, M, a, Q, 1); h = H_[k]; s = F(kap) * Q * Q / 4
        out = horizon_numbers(Gv, S, M, a, s, h['cf']['rh'].v, ANG[:1], Q=0, std=False, retarded=True); kr = one(out['kH'])
        print('    retarded (time-reversed) frame, %s: Omega = %s, chi null: %s, nabla_chi chi = %s chi (past horizon)' % (fam, one(out['Om']), out['null'] == {0}, kr))
        for r in rows:
            if r['key'] == k and r['dA']:
                try: ctl('retarded chart: its kH (= -kH) with the future sign', kr is not None and kr == -h['kH'] and resid(r, gam[r['kap']], kH=kr) != 0)
                except TypeError: ctl('retarded chart: its kH (= -kH) with the future sign', False)
    for name, (dif, seen) in CT.items(): chk('ctl', dif == seen and seen > 0, '%s: fails on %d of %d rows' % (name, dif, seen))
    tick('part 5')

    head('6. the fifth chip T = (x-2)(x+1)/(x+3), areal radius x^2: no first law; kH as the Atlas computes it; the stress its frame needs (G/kappa)')
    Td = Du(2, 1); Tv = (Td - 2) * (Td + 1) / (Td + 3)
    chk('std', Tv.v == 0 and Tv.d / 2 == F(3, 10), 'kH = (1/2) T\'(2) = %s (the Atlas\'s recipe in the EF chart, exact dual number; null_selfcheck S12.1)' % (Tv.d / 2))
    for x0 in (F(3), F(2), F(1)):
        e, T = fifth_frame(x0); om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0); e0, E0, det = E0_of(e, 4, 4)
        Gfr = mixed_from_components(comp, e0, det, 4, -1)
        g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, 4); Gfs = to_frame_mixed(Gm, e0, E0, 4)
        Gc = [[sum(E0[m][b] * Gfr[b][c] * e0[c][v] for b in range(4) for c in range(4)) for v in range(4)] for m in range(4)]
        Tx = at0(T, NV); Tp = lin1(T, 1); pred = -(8 * x0 ** 2 * Tx + 2 * x0 ** 3 * Tp - 1) / x0 ** 4
        Gkk = sum(g0[1][sg] * Gc[sg][1] for sg in range(4)); k2 = [F(2), -Tx, F(0), F(0)]; Gk2 = sum(g0[m][sg] * Gc[sg][v] * k2[m] * k2[v] for m in range(4) for sg in range(4) for v in range(4))
        chk('bit==std', Gfr == Gfs and Gc[1][0] == 0 and Gc[0][0] == pred and Gkk == ric[1][1] == -4 / x0 ** 2,
            'x = %s (T = %s): engine G^b_a = Christoffel route (16 frame components); G^x_v = 0; G^v_v = %s = -(8x^2 T + 2x^3 T\' - 1)/x^4, so the energy density is G^v_v/kappa = %s/kappa%s; null energy along k = d_x: G_kk = R_kk = %s = -2 r\'\'/r < 0, along 2 d_v - T d_x: %s' % (
                x0, Tx, Gc[0][0], Gc[0][0], ' (static region)' if Tx > 0 else (' (horizon)' if Tx == 0 else ' (T < 0)'), Gkk, Gk2))
        if x0 == 2:
            ca, nab = K.engine_nabla_vv(Gv, omega_closed_form(Gv, e, S, NV, 0)[0], e, [const(NV, 1), {}, {}, {}])
            chk('bit', K.frame_norm_bit(ca, SQ) == 0 and prop(ca, nab) == F(-3, 10), 'x = 2: chi = d_v null and nabla_chi chi = %s chi from the engine\'s omega on this frame: the Atlas\'s 3/10 with the retarded-chart sign (-kH)' % prop(ca, nab))
    tick('part 6')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F2')

if __name__ == '__main__': main()
