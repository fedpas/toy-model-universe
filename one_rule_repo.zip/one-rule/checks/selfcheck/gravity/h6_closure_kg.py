#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H6 (test 1).  The Klein-Gordon closure of Duell, Schuller, Stritzelberger, Wolz (arXiv:1611.08878v3) in EXACT arithmetic.
      python3 h6_closure_kg.py [--seed S] [--points P]
 Input (103): p^{ab} = ghat^{ab}, E^A_mu = phi^A_{,mu}, F^A_mu^c = 2 I^A_{mu a} I^{ca}_B phi^B, M = 0; deg P = 2; intertwiners obeying (101)
 (the rational choice I^{ab}_A = 1 on both orderings of the pair A, I^A_{ab} = 1/2 off the diagonal; (102) is "rarely needed explicitly").
 Unknowns: C[phi] (a function of the 2-jet of the six configuration variables phi^A = independent components of the inverse 3-metric),
 C_AB(phi) (a function of phi); C_A = 0, C with three or more indices = 0.  Printed solution (104)-(105):
    C = -(1/2 kappa) w (R[ghat] - 2 Lambda),   C_AB = (1/8 kappa) w I^{ab}_A I^{mn}_B (ghat_am ghat_bn - ghat_ab ghat_mn),   w = (-det ghat^{..})^{-1/2},
 R[ghat] the Ricci scalar of the (negative-definite) 3-metric ghat_ab = inverse of ghat^{ab}, usual sign (R = +6 on the unit 3-sphere).
 Closure equations (pages 47-48 of the paper, landscape) that are not identically zero for this input:
 (C1), (C3), (C4), (C8_2), (C8_3), (C10_2).  Derivative convention (75): sums over ordered index tuples with C_{:A}^{ab} symmetric
 (C_{:A}^{12} = (1/2) dC/du_12); the K = 0 term of (C8_N) read as -C_{:A}^{(b1..b_{N-1}|} F^A_mu^{|bN)}.
 Method: exact forward-mode automatic differentiation on the jet coordinates (a truncated algebra: constants, first order in the 24 variables
 (phi, d phi), first order in the 18 second-jet variables, and the mixed block (second jet) x (phi, d phi) needed by the total derivative in (C4)).
 C is linear in the second jets, so no third jets enter.  Everything is Fractions; the base point has -det ghat a perfect square so that w is rational.
 Tags: [std] an exact evaluation of the paper's printed equations (plain index calculus, no bit rule anywhere); [ctl] a wrong version that must fail.
 The engine (gravity_selfcheck) is never used: the eight engine faults M1..M8 cannot be seen by this script; the analogues are the controls.
 Part 2: closed/open FRW (k = +1, -1) per unit comoving volume: the Lagrangian from (104)-(105) via (92), (87) and from (106) with the usual 4D R, exact."""
import sys, os, time, itertools, random, math
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import chk, head, finish

# ------------------------------------------------------------------------------------------------ exact truncated algebra (forward AD)
def _acc(d, k, v):
    x = d.get(k, 0) + v
    if x == 0: d.pop(k, None)
    else: d[k] = x

class J:
    """c + sum_i gx_i x_i + sum_j gu_j u_j + sum_{j,i} H_ji u_j x_i   with x_i x_k = 0 and u_j u_k = 0 (exact in Fractions).
    x: the 24 variables (phi^A, phi^A_{,a}), u: the 18 second-jet variables phi^A_{,ab} (a <= b).  gx = first derivatives, gu = first
    derivatives in the second jets, H = the mixed second derivatives d^2/(du_j dx_i)."""
    __slots__ = ('c', 'gx', 'gu', 'H')
    def __init__(self, c=0, gx=None, gu=None, H=None):
        self.c = F(c); self.gx = gx if gx else {}; self.gu = gu if gu else {}; self.H = H if H else {}
    @staticmethod
    def lift(x): return x if isinstance(x, J) else J(x)
    def __add__(self, o):
        o = J.lift(o); r = J(self.c + o.c, dict(self.gx), dict(self.gu), dict(self.H))
        for k, v in o.gx.items(): _acc(r.gx, k, v)
        for k, v in o.gu.items(): _acc(r.gu, k, v)
        for k, v in o.H.items(): _acc(r.H, k, v)
        return r
    __radd__ = __add__
    def __neg__(self): return J(-self.c, {k: -v for k, v in self.gx.items()}, {k: -v for k, v in self.gu.items()}, {k: -v for k, v in self.H.items()})
    def __sub__(self, o): return self + (-J.lift(o))
    def __rsub__(self, o): return J.lift(o) + (-self)
    def __mul__(self, o):
        if not isinstance(o, J):
            o = F(o)
            if o == 0: return J(0)
            return J(self.c * o, {k: v * o for k, v in self.gx.items()}, {k: v * o for k, v in self.gu.items()}, {k: v * o for k, v in self.H.items()})
        a, b = self, o; r = J(a.c * b.c)
        if b.c != 0:
            for k, v in a.gx.items(): _acc(r.gx, k, v * b.c)
            for k, v in a.gu.items(): _acc(r.gu, k, v * b.c)
            for k, v in a.H.items(): _acc(r.H, k, v * b.c)
        if a.c != 0:
            for k, v in b.gx.items(): _acc(r.gx, k, v * a.c)
            for k, v in b.gu.items(): _acc(r.gu, k, v * a.c)
            for k, v in b.H.items(): _acc(r.H, k, v * a.c)
        if a.gu and b.gx:
            for j, vj in a.gu.items():
                for i, vi in b.gx.items(): _acc(r.H, (j, i), vj * vi)
        if b.gu and a.gx:
            for j, vj in b.gu.items():
                for i, vi in a.gx.items(): _acc(r.H, (j, i), vj * vi)
        return r
    __rmul__ = __mul__
    def inv(self):
        """1/(c + e) = (1/c)(1 - e/c + e^2/c^2), e^2 = 2 gu (x) gx (only the mixed block survives), e^3 = 0."""
        c = self.c; ic = 1 / c; ic2 = ic * ic; ic3 = ic2 * ic
        r = J(ic, {k: -v * ic2 for k, v in self.gx.items()}, {k: -v * ic2 for k, v in self.gu.items()}, {k: -v * ic2 for k, v in self.H.items()})
        for j, vj in self.gu.items():
            for i, vi in self.gx.items(): _acc(r.H, (j, i), 2 * vj * vi * ic3)
        return r
    def __truediv__(self, o): return self * o.inv() if isinstance(o, J) else self * (1 / F(o))
    def __rtruediv__(self, o): return J.lift(o) * self.inv()
    def powm12(self, root):
        """(c + e)^(-1/2) = root (1 - e/(2c) + (3/8) e^2/c^2) with root^2 c = 1 (root supplied, checked)."""
        c = self.c; assert root * root * c == 1, 'base value is not a perfect square'
        f1 = -root / (2 * c); f2 = F(3, 4) * root / (c * c)
        r = J(root, {k: v * f1 for k, v in self.gx.items()}, {k: v * f1 for k, v in self.gu.items()}, {k: v * f1 for k, v in self.H.items()})
        for j, vj in self.gu.items():
            for i, vi in self.gx.items(): _acc(r.H, (j, i), f2 * vj * vi)
        return r

def val(x): return x.c if isinstance(x, J) else F(x)

# ------------------------------------------------------------------------------------------------ plain index calculus (works on Fractions or J)
def det_leibniz(M):
    n = len(M); s = 0
    for perm in itertools.permutations(range(n)):
        sgn = 1
        for i in range(n):
            for j in range(i + 1, n):
                if perm[i] > perm[j]: sgn = -sgn
        t = M[0][perm[0]]
        for i in range(1, n): t = t * M[i][perm[i]]
        s = s + t * sgn
    return s
def mat_inv(M):
    n = len(M); d = det_leibniz(M); di = (d.inv() if isinstance(d, J) else 1 / d)
    out = [[None] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            minor = [[M[r][c] for c in range(n) if c != j] for r in range(n) if r != i]
            cof = det_leibniz(minor) if n > 1 else F(1)
            out[j][i] = cof * di * ((-1) ** (i + j))
    return out

def ricci_scalar(Gi, dGi, ddGi, n):
    """R = G^{ab} R_ab, R_ab = d_c Gam^c_ab - d_b Gam^c_ac + Gam^c_cd Gam^d_ab - Gam^c_bd Gam^d_ac, Gam from the metric g = inverse of G
    (the usual sign: R = +6 on the unit 3-sphere).  Input: the 2-jet of the CONTRAVARIANT metric at the point: Gi[a][b], dGi[a][b][c] = d_c G^{ab},
    ddGi[a][b][c][d] = d_c d_d G^{ab}.  Returns (R, g)."""
    rg = range(n); g = mat_inv(Gi)
    dg = [[[sum((g[a][m] * dGi[m][k][c] * g[k][b] for m in rg for k in rg), J(0) if isinstance(Gi[0][0], J) else F(0)) * (-1)
            for c in rg] for b in rg] for a in rg]
    ddg = [[[[sum((dg[a][m][d] * dGi[m][k][c] * g[k][b] + g[a][m] * ddGi[m][k][c][d] * g[k][b] + g[a][m] * dGi[m][k][c] * dg[k][b][d]
                   for m in rg for k in rg), F(0)) * (-1) for d in rg] for c in rg] for b in rg] for a in rg]
    Gam = [[[sum((Gi[c][d] * (dg[d][b][a] + dg[d][a][b] - dg[a][b][d]) for d in rg), F(0)) * F(1, 2) for b in rg] for a in rg] for c in rg]
    dGam = [[[[sum((dGi[c][d][e] * (dg[d][b][a] + dg[d][a][b] - dg[a][b][d]) + Gi[c][d] * (ddg[d][b][a][e] + ddg[d][a][b][e] - ddg[a][b][d][e])
                    for d in rg), F(0)) * F(1, 2) for e in rg] for b in rg] for a in rg] for c in rg]
    Ric = [[sum((dGam[c][a][b][c] - dGam[c][a][c][b] for c in rg), F(0)) +
            sum((Gam[c][c][d] * Gam[d][a][b] - Gam[c][b][d] * Gam[d][a][c] for c in rg for d in rg), F(0)) for b in rg] for a in rg]
    R = sum((Gi[a][b] * Ric[a][b] for a in rg for b in rg), F(0))
    return R, g

# ------------------------------------------------------------------------------------------------ the KG sector: variables, intertwiners, input coefficients
PAIRS = [(0, 0), (0, 1), (0, 2), (1, 1), (1, 2), (2, 2)]
def pidx(a, b): return PAIRS.index((a, b) if a <= b else (b, a))
R3 = range(3)
def xvar_phi(A): return A                      # phi^A
def xvar_d(A, a): return 6 + 3 * A + a         # phi^A_{,a}
def uvar(A, a, b): return 6 * A + pidx(a, b)   # phi^A_{,ab}, a <= b

def I_up(a, b, A): return F(1) if pidx(a, b) == A else F(0)          # I^{ab}_A: 1 on both orderings of the pair A
def I_dn(A, a, b):                                                     # I^A_{ab}: 1 on the diagonal, 1/2 off it
    if pidx(a, b) != A: return F(0)
    return F(1) if a == b else F(1, 2)

def rand_point(rng):
    """ghat^{ab}(0) = -(A A^T) (negative definite, -det a square), random rational first and second jets."""
    while True:
        A = [[F(rng.randint(-2, 2)) for _ in R3] for _ in R3]
        dA = det_leibniz(A)
        if dA != 0: break
    g0 = [-sum(A[a][k] * A[b][k] for k in R3) for (a, b) in PAIRS]
    den = rng.choice([1, 2, 3])
    g1 = [[F(rng.randint(-3, 3), den) for _ in R3] for _ in range(6)]
    g2 = [[F(rng.randint(-3, 3), den) for _ in range(6)] for _ in range(6)]
    return dict(g0=g0, g1=g1, g2=g2, root=1 / abs(dA))

def jet_numbers(pt):
    """ghat^{ab}, d_c ghat^{ab}, d_c d_d ghat^{ab} as J numbers (value + the formal jet variable)."""
    Gi = [[J(pt['g0'][pidx(a, b)], {xvar_phi(pidx(a, b)): F(1)}) for b in R3] for a in R3]
    dGi = [[[J(pt['g1'][pidx(a, b)][c], {xvar_d(pidx(a, b), c): F(1)}) for c in R3] for b in R3] for a in R3]
    ddGi = [[[[J(pt['g2'][pidx(a, b)][pidx(c, d)], None, {uvar(pidx(a, b), c, d): F(1)}) for d in R3] for c in R3] for b in R3] for a in R3]
    return Gi, dGi, ddGi

def heavy(pt):
    """One AD pass: R, w, w R (J numbers with all blocks), ghat_ab and w as J over phi only for C_AB."""
    Gi, dGi, ddGi = jet_numbers(pt)
    R, g = ricci_scalar(Gi, dGi, ddGi, 3)
    negdet = -det_leibniz(Gi)
    w = negdet.powm12(pt['root'])
    return dict(R=R, w=w, wR=w * R, g=g, Gi=Gi)

# ------------------------------------------------------------------------------------------------ the unknowns and the equations at the point
def build_C(hv, cR, cV, extra=None, wpow=1):
    """C = cR * (w R) + cV * w^wpow + extra (extra: a J number, e.g. w R^2 or a non-covariant term)."""
    C = hv['wR'] * cR
    wv = hv['w'] if wpow == 1 else hv['w'] * hv['w']
    C = C + wv * cV
    if extra is not None: C = C + extra
    return C

def build_CAB(hv, cK, lam=F(1)):
    """C_AB = cK * w * sum_{(ab) in A} sum_{(mn) in B} (ghat_am ghat_bn - lam ghat_ab ghat_mn)  [the I^{ab}_A of the rational intertwiners]."""
    g, w = hv['g'], hv['w']
    def ords(A):
        a, b = PAIRS[A]; return [(a, b)] if a == b else [(a, b), (b, a)]
    CAB = [[None] * 6 for _ in range(6)]
    for A in range(6):
        for B in range(6):
            s = J(0)
            for (a, b) in ords(A):
                for (m, n) in ords(B):
                    s = s + g[a][m] * g[b][n] - g[a][b] * g[m][n] * lam
            CAB[A][B] = w * s * cK
    return CAB

class Derivs:
    """The derivatives of C and C_AB with respect to the jet coordinates at the point, in the paper's convention (75)."""
    def __init__(self, C, CAB, pt, half=True):
        self.pt = pt; self.C = C.c
        self.C0 = [C.gx.get(xvar_phi(A), F(0)) for A in range(6)]
        self.C1 = [[C.gx.get(xvar_d(A, a), F(0)) for a in R3] for A in range(6)]
        conv = lambda a, b: (F(1, 2) if (a != b and half) else F(1))
        self.C2 = [[[C.gu.get(uvar(A, a, b), F(0)) * conv(a, b) for b in R3] for a in R3] for A in range(6)]
        # total derivative D_c C_{:B}^{a m} = sum_i d(C_{:B}^{am})/dx_i * d_c x_i
        self.DC2 = [[[[None] * 3 for _ in R3] for _ in R3] for _ in range(6)]
        for B in range(6):
            for a in R3:
                for m in R3:
                    j = uvar(B, a, m); cv = conv(a, m)
                    for c in R3:
                        s = F(0)
                        for A in range(6):
                            s += C.H.get((j, xvar_phi(A)), F(0)) * pt['g1'][A][c]
                            for b in R3: s += C.H.get((j, xvar_d(A, b)), F(0)) * pt['g2'][A][pidx(b, c)]
                        self.DC2[B][a][m][c] = s * cv
        self.CAB = [[CAB[A][B].c for B in range(6)] for A in range(6)]
        self.CABd = [[[CAB[A][B].gx.get(xvar_phi(D), F(0)) for D in range(6)] for B in range(6)] for A in range(6)]
    def Cd(self, A, idx):
        """C_{:A}^{idx} for a tuple idx of 0, 1 or 2 indices; zero for three or more (no third-jet dependence)."""
        k = len(idx)
        if k == 0: return self.C0[A]
        if k == 1: return self.C1[A][idx[0]]
        if k == 2: return self.C2[A][idx[0]][idx[1]]
        return F(0)

class Inputs:
    """The input coefficients (103) and their jet derivatives at the point, with a sign switch on p."""
    def __init__(self, pt, psign=1):
        g0, g1, g2 = pt['g0'], pt['g1'], pt['g2']
        self.p = [[g0[pidx(m, n)] * psign for n in R3] for m in R3]
        self.dp = [[[g1[pidx(m, n)][c] * psign for c in R3] for n in R3] for m in R3]
        self.E = [[g1[A][m] for m in R3] for A in range(6)]
        self.dE = [[[g2[A][pidx(m, a)] for a in R3] for m in R3] for A in range(6)]
        # F^A_mu^c = 2 sum_a I^A_{mu a} ghat^{ca};  F_{,d} = 2 sum_a I^A_{mu a} ghat^{ca}_{,d};  F_{,de};  F_{:B} = 2 sum_a I^A_{mu a} I^{ca}_B
        self.Fv = [[[2 * sum(I_dn(A, m, a) * g0[pidx(c, a)] for a in R3) for c in R3] for m in R3] for A in range(6)]
        self.dF = [[[[2 * sum(I_dn(A, m, a) * g1[pidx(c, a)][d] for a in R3) for d in R3] for c in R3] for m in R3] for A in range(6)]
        self.ddF = [[[[[2 * sum(I_dn(A, m, a) * g2[pidx(c, a)][pidx(d, e)] for a in R3) for e in R3] for d in R3] for c in R3] for m in R3] for A in range(6)]
        self.FB = [[[[2 * sum(I_dn(A, m, a) * I_up(c, a, B) for a in R3) for B in range(6)] for c in R3] for m in R3] for A in range(6)]
    def Fder(self, A, m, c, dummies):
        k = len(dummies)
        if k == 0: return self.Fv[A][m][c]
        if k == 1: return self.dF[A][m][c][dummies[0]]
        if k == 2: return self.ddF[A][m][c][dummies[0]][dummies[1]]
        return F(0)   # F is linear in phi: a third derivative is a third jet, never multiplied by a non-zero C here

def sym_CF(D, inp, A, m, K, free):
    """C_{:A}^{(a1..aK | free[:-1] ...)} F^A_m^{| last)}_{,a1..aK}: the total symmetrisation over the K dummies and the free indices, one index on F's
    upper slot, the rest on C, the derivative indices of F being the dummies (the literal reading of the brackets on pp. 47-48)."""
    tot = F(0); nfree = len(free)
    for dummies in itertools.product(R3, repeat=K):
        L = list(dummies) + list(free)
        for perm in itertools.permutations(range(len(L))):
            P = [L[i] for i in perm]
            tot += D.Cd(A, tuple(P[:-1])) * inp.Fder(A, m, P[-1], dummies)
    return tot / math.factorial(K + nfree)

def binom(n, k): return F(math.comb(n, k))

def equations(D, inp, drop_c8_k0=False):
    """Returns {name: (max |residual|, max |term| scale, number of components)} for the six equations.  deg P = 2."""
    out = {}
    def rec(name, vals, scales):
        out[name] = (max(abs(v) for v in vals), max(scales) if scales else F(0), len(vals))
    # (C1): 0 = -C d^c_m + sum_K (K+1) C_{:A}^{c a1..aK}(E^A_{m,a1..aK} + F^A_m^{a_{K+1}}_{,a1..a_{K+1}}) - sum_K (K+1) C_{:A}^{(a1..aK|} F^A_m^{|c)}_{,a1..aK}
    vals, sc = [], []
    for m in R3:
        for c in R3:
            terms = [-D.C * (1 if c == m else 0)]
            for A in range(6):
                terms.append(D.C1[A][c] * (inp.E[A][m] + sum(inp.dF[A][m][a][a] for a in R3)))                                   # K = 0
                terms.append(2 * sum(D.C2[A][c][a] * (inp.dE[A][m][a] + sum(inp.ddF[A][m][b][a][b] for b in R3)) for a in R3))  # K = 1
                for K in (0, 1, 2): terms.append(-(K + 1) * sym_CF(D, inp, A, m, K, (c,)))
            vals.append(sum(terms)); sc.append(max(abs(t) for t in terms))
    rec('C1', vals, sc)
    # (C3): 0 = 2 (deg P - 1) p^{(m|r} C_AB F^A_r^{|n)} - C_{:B}^{mn}      (the M terms vanish; K >= 1 needs three upper indices on C)
    vals, sc = [], []
    for B in range(6):
        for (m, n) in PAIRS:
            t1 = sum(inp.p[m][r] * D.CAB[A][B] * inp.Fv[A][r][n] + inp.p[n][r] * D.CAB[A][B] * inp.Fv[A][r][m] for A in range(6) for r in R3)  # 2 * sym
            t2 = -D.C2[B][m][n]
            vals.append(t1 + t2); sc.append(max(abs(t1), abs(t2)))
    rec('C3', vals, sc)
    # (C4): 0 = 2 (deg P - 1) C_AB (p^{mn} E^A_n - p^{mn}_{,c} F^A_n^c) - [C_{:B}^m - 2 d_a C_{:B}^{am}]
    vals, sc = [], []
    for B in range(6):
        for m in R3:
            t1 = 2 * sum(D.CAB[A][B] * (sum(inp.p[m][n] * inp.E[A][n] for n in R3) - sum(inp.dp[m][n][c] * inp.Fv[A][n][c] for n in R3 for c in R3)) for A in range(6))
            t2 = -D.C1[B][m]; t3 = 2 * sum(D.DC2[B][a][m][a] for a in R3)
            vals.append(t1 + t2 + t3); sc.append(max(abs(t1), abs(t2), abs(t3)))
    rec('C4', vals, sc)
    # (C8_N), N = 2, 3: 0 = sum_K binom(K+N, K) [ C_{:A}^{b1..bN a1..aK}(E^A_{m,a1..aK} + F^A_m^{a_{K+1}}_{,a1..a_{K+1}}) - C_{:A}^{(b1..bN a1..a_{K-1}|} F^A_m^{|aK)}_{,a1..aK} ]
    for N in (2, 3):
        vals, sc = [], []
        for m in R3:
            for free in itertools.combinations_with_replacement(R3, N):
                terms = []
                for A in range(6):
                    for K in range(0, 3):
                        if N + K == 2:   # the first term needs C with N + K upper indices: only N = 2, K = 0 is non-zero
                            terms.append(binom(K + N, K) * D.Cd(A, free) * (inp.E[A][m] + sum(inp.dF[A][m][a][a] for a in R3)))
                        if K == 0 and drop_c8_k0: continue
                        if N + K - 1 <= 2: terms.append(-binom(K + N, K) * sym_CF(D, inp, A, m, K, free))
                vals.append(sum(terms, F(0))); sc.append(max([abs(t) for t in terms] + [F(0)]))
        rec('C8_%d' % N, vals, sc)
    # (C10_2): 0 = -C_{B1B2} d^c_m - 2 C_{A(B1} F^A_{|m|}^c_{:B2)} - C_{B1B2:A} F^A_m^c   (the jet derivatives of C_AB vanish)
    vals, sc = [], []
    for (B1, B2) in itertools.combinations_with_replacement(range(6), 2):
        for m in R3:
            for c in R3:
                t1 = -D.CAB[B1][B2] * (1 if c == m else 0)
                t2 = -sum(D.CAB[A][B1] * inp.FB[A][m][c][B2] + D.CAB[A][B2] * inp.FB[A][m][c][B1] for A in range(6))
                t3 = -sum(D.CABd[B1][B2][A] * inp.Fv[A][m][c] for A in range(6))
                vals.append(t1 + t2 + t3); sc.append(max(abs(t1), abs(t2), abs(t3)))
    rec('C10_2', vals, sc)
    return out

def c14_antisym(inp):
    """(C14_2): the antisymmetric part of p^{r mu} F^A_r^nu must vanish for the equation to be identically zero."""
    return max(abs(sum(inp.p[r][m] * inp.Fv[A][r][n] - inp.p[r][n] * inp.Fv[A][r][m] for r in R3)) for A in range(6) for m in R3 for n in R3)

def report(name, res, expect_zero=True):
    bad = sorted(k for k, (r, s, n) in res.items() if r != 0)
    return bad

# ------------------------------------------------------------------------------------------------ part 2: FRW
def frw_jets_3d(a0, k):
    """Inverse 3-metric of the spatial slice -a^2 gamma, gamma the unit S^3 (k = 1) or H^3 (k = -1) in stereographic coordinates
    gamma = 4 delta/(1 + k |y|^2)^2: at y = 0 the 2-jet is rational: ghat = -(1/4a^2)(1 + 2k|y|^2 + ..) delta."""
    Gi = [[F(-1, 4) / (a0 * a0) * (1 if a == b else 0) for b in R3] for a in R3]
    dGi = [[[F(0) for _ in R3] for _ in R3] for _ in R3]
    ddGi = [[[[(-F(k) / (a0 * a0) if (a == b and c == d) else F(0)) for d in R3] for c in R3] for b in R3] for a in R3]
    return Gi, dGi, ddGi

def frw_L1(a0, a1, N, kappa, Lam, k):
    """N (C + C_AB K^A K^B) per unit comoving volume (divide by sqrt(det gamma) = 8 at y = 0), from (104)-(105), (92), (87) with zero shift."""
    Gi, dGi, ddGi = frw_jets_3d(a0, k)
    R, g = ricci_scalar(Gi, dGi, ddGi, 3)
    w = F(8) * a0 ** 3  # (-det ghat)^{-1/2} = (4 a^2)^{3/2} = 8 a^3 for a > 0
    C = -F(1, 2) / kappa * w * (R - 2 * Lam)
    # K^{ab} = (1/N) d_t ghat^{ab} = (1/N) 2 adot a^{-3} gamma^{ab}, gamma^{ab}(0) = delta/4
    Kab = [[(2 * a1 / (a0 ** 3) / N * F(1, 4) if a == b else F(0)) for b in R3] for a in R3]
    kin = F(1, 8) / kappa * w * sum((g[a][m] * g[b][n] - g[a][b] * g[m][n]) * Kab[a][b] * Kab[m][n] for a in R3 for b in R3 for m in R3 for n in R3)
    return (N * (C + kin)) / 8, R

def frw_L2(a0, a1, a2, N, kappa, Lam, k):
    """(1/2 kappa) sqrt(-det G) (R4 + 2 Lambda) per unit comoving volume for ds^2 = N^2 dt^2 - a(t)^2 gamma, usual 4D R (mainly minus)."""
    n = 4; r4 = range(4)
    # G^{tt} = 1/N^2; G^{ab} = -(1/4)(a^-2)(1 + 2 k |y|^2) delta ; a^-2 jets: value a0^-2, d_t = -2 a1/a0^3, d_t^2 = 6 a1^2/a0^4 - 2 a2/a0^3
    ia2 = [1 / (a0 * a0), -2 * a1 / a0 ** 3, 6 * a1 * a1 / a0 ** 4 - 2 * a2 / a0 ** 3]
    Gi = [[F(0)] * 4 for _ in r4]; Gi[0][0] = 1 / (N * N)
    for a in range(1, 4): Gi[a][a] = -F(1, 4) * ia2[0]
    dGi = [[[F(0) for _ in r4] for _ in r4] for _ in r4]
    for a in range(1, 4): dGi[a][a][0] = -F(1, 4) * ia2[1]
    ddGi = [[[[F(0) for _ in r4] for _ in r4] for _ in r4] for _ in r4]
    for a in range(1, 4):
        ddGi[a][a][0][0] = -F(1, 4) * ia2[2]
        for c in range(1, 4): ddGi[a][a][c][c] += -F(1, 4) * ia2[0] * 4 * k
    R4, g = ricci_scalar(Gi, dGi, ddGi, 4)
    sqrtdet = N * a0 ** 3 * 8     # sqrt(-det G) = N a^3 sqrt(det gamma), sqrt(det gamma) = 8 at y = 0
    return F(1, 2) / kappa * sqrtdet * (R4 + 2 * Lam) / 8, R4

# ================================================================================================ main
def main():
    argv = sys.argv[1:]; seed = 7; npts = 3
    if '--seed' in argv: seed = int(argv[argv.index('--seed') + 1])
    if '--points' in argv: npts = int(argv[argv.index('--points') + 1])
    rng = random.Random(seed)
    head('H6 part 0: the Ricci routine [std] (plain index calculus)')
    t0 = time.time()
    Gi, dGi, ddGi = frw_jets_3d(F(1), 1); Gi = [[-x for x in row] for row in Gi]; ddGi = [[[[-x for x in r] for r in rr] for rr in rrr] for rrr in ddGi]
    R, _ = ricci_scalar(Gi, dGi, ddGi, 3)
    chk('std', R == 6, 'unit 3-sphere (positive-definite 4 delta/(1+|y|^2)^2, stereographic jets at y = 0): R = %s (textbook 6)' % R)
    for a0, k in ((F(2), 1), (F(3, 2), -1)):
        R, _ = ricci_scalar(*frw_jets_3d(a0, k), 3)
        chk('std', R == -6 * k / (a0 * a0), 'spatial metric -a^2 gamma_k, a = %s, k = %d: R[ghat] = %s = -6k/a^2 (negative definite: the sign flips)' % (a0, k, R))
    H = F(3, 5)   # closed de Sitter slicing a = cosh(H t)/H: a(0) = 1/H, adot = 0, addot = H
    L2, R4 = frw_L2(1 / H, F(0), H, F(1), F(1), F(0), 1)
    chk('std', R4 == -12 * H * H, 'closed de Sitter jets (a = cosh(Ht)/H, H = %s): usual 4D R = %s = -12 H^2 (mainly minus; the Atlas convention of A4/H3, c = H^2)' % (H, R4))
    print('  part 0: %.1f s' % (time.time() - t0))

    head('H6 part 1: the six non-trivial closure equations on the printed solution (104)-(105), exact, %d random jet points [std]' % npts)
    summary = []
    for ip in range(npts):
        t0 = time.time(); pt = rand_point(rng); hv = heavy(pt); th = time.time() - t0
        inp = Inputs(pt)
        print('  point %d: ghat(0) = %s, -det = %s, first jets den %s; AD pass %.1f s' % (ip, [str(x) for x in pt['g0']], 1 / pt['root'] ** 2, pt['g1'][0][0].denominator, th))
        chk('std', c14_antisym(inp) == 0, 'point %d: (C14_2) is identically zero: p^{r m} F^A_r^n is symmetric in (m, n)' % ip)
        for (kappa, Lam, tag) in ((F(7, 3), F(-5, 11), 'kappa = 7/3, Lambda = -5/11'), (F(-2), F(4, 3), 'kappa = -2, Lambda = 4/3'), (F(1), F(0), 'kappa = 1, Lambda = 0 (Einstein part alone)')):
            C = build_C(hv, -F(1, 2) / kappa, Lam / kappa); CAB = build_CAB(hv, F(1, 8) / kappa)
            res = equations(Derivs(C, CAB, pt), inp)
            bad = report('sol', res)
            chk('std', not bad, 'point %d, %s: (C1) %d, (C3) %d, (C4) %d, (C8_2) %d, (C8_3) %d, (C10_2) %d components all exactly 0%s' %
                (ip, tag, res['C1'][2], res['C3'][2], res['C4'][2], res['C8_2'][2], res['C8_3'][2], res['C10_2'][2], '' if not bad else '; FAILING: ' + ', '.join('%s (max |res| = %.3g, scale %.3g)' % (b, float(res[b][0]), float(res[b][1])) for b in bad)))
        # S2: the pure volume term alone
        for Lk in (F(3, 7), F(-5, 2)):
            C = build_C(hv, F(0), Lk); CAB = build_CAB(hv, F(0))
            res = equations(Derivs(C, CAB, pt), inp); bad = report('vol', res)
            chk('std', not bad, 'point %d: pure volume term C = (Lambda/kappa) w with Lambda/kappa = %s, C_AB = 0: all six equations exactly 0 (the cosmological term is a free solution)%s' % (ip, Lk, '' if not bad else '; FAILING ' + ','.join(bad)))
        summary.append((pt, hv, inp))
        print('  point %d done: %.1f s' % (ip, time.time() - t0))

    head('H6 part 1b: controls [ctl] (each line is ok when the wrong version FAILS); which equations fail is printed')
    pt, hv, inp = summary[0]; kappa, Lam = F(7, 3), F(-5, 11)
    def run(C, CAB, inp_=inp, half=True, drop=False):
        res = equations(Derivs(C, CAB, pt, half=half), inp_, drop_c8_k0=drop); bad = report('ctl', res)
        return bad, res
    def ctl(name, bad, res, expect):
        chk('ctl', len(bad) > 0, '%s: failing = {%s} (predicted {%s})' % (name, ', '.join('%s rel %.2g' % (b, float(res[b][0] / res[b][1]) if res[b][1] else 0) for b in bad), ', '.join(expect)))
    C_ok = build_C(hv, -F(1, 2) / kappa, Lam / kappa); CAB_ok = build_CAB(hv, F(1, 8) / kappa)
    bad, res = run(build_C(hv, +F(1, 2) / kappa, Lam / kappa), CAB_ok); ctl('R -> -R in (104)', bad, res, ['C3', 'C4'])
    bad, res = run(C_ok, CAB_ok, Inputs(pt, psign=-1)); ctl('p -> -p (the sign convention (31))', bad, res, ['C3', 'C4'])
    bad, res = run(C_ok, build_CAB(hv, F(1, 4) / kappa)); ctl('C_AB coefficient 1/(4 kappa) instead of 1/(8 kappa)', bad, res, ['C3', 'C4'])
    bad, res = run(C_ok, build_CAB(hv, F(1, 8) / kappa, lam=F(1, 2))); ctl('DeWitt coefficient 1/2 instead of 1 in C_AB', bad, res, ['C3', 'C4'])
    bad, res = run(build_C(hv, F(0), Lam / kappa, wpow=2), build_CAB(hv, F(0))); ctl('volume term alone with weight w^2 instead of w', bad, res, ['C1'])
    bad, res = run(C_ok, CAB_ok, half=False); ctl('derivative convention without the 1/2 on off-diagonal second jets', bad, res, ['C1', 'C3', 'C4', 'C8_2', 'C8_3'])
    bad, res = run(C_ok, CAB_ok, drop=True); ctl('the K = 0 term of (C8_N) dropped ((C8_3) has only that term, so it becomes empty)', bad, res, ['C8_2'])
    wRR = hv['wR'] * hv['R']
    bad, res = run(build_C(hv, F(0), F(0), extra=wRR), build_CAB(hv, F(0)))
    ctl('covariant non-solution C = w R^2, C_AB = 0: the covariance identities hold, the dynamics fail', bad, res, ['C3', 'C4'])
    chk('ctl', all(res[q][0] == 0 for q in ('C1', 'C8_2', 'C8_3', 'C10_2')), 'for C = w R^2: (C1), (C8_2), (C8_3), (C10_2) are exactly 0 (they are the covariance identities of a weight-1 density)')
    nonc = hv['w'] * (hv['Gi'][0][0] + hv['Gi'][1][1] + hv['Gi'][2][2])
    bad, res = run(build_C(hv, -F(1, 2) / kappa, Lam / kappa, extra=nonc), CAB_ok); ctl('non-covariant term w (ghat^11 + ghat^22 + ghat^33) added to C', bad, res, ['C1'])
    # R -> -R: record that the covariance identities survive
    bad, res = run(build_C(hv, +F(1, 2) / kappa, Lam / kappa), CAB_ok)
    chk('std', all(res[q][0] == 0 for q in ('C1', 'C8_2', 'C8_3', 'C10_2')) and res['C3'][0] != 0 and res['C4'][0] != 0,
        'R -> -R: exactly (C3) and (C4) fail, the covariance identities (C1), (C8_2), (C8_3), (C10_2) stay 0 (relative sizes C3 %.2g, C4 %.2g)' % (float(res['C3'][0] / res['C3'][1]), float(res['C4'][0] / res['C4'][1])))

    head('H6 part 2: FRW per unit comoving volume, exact [std]; the two printed forms (104)-(105) and (106)')
    for (a0, a1, a2, N, kappa, Lam, k) in ((F(2), F(1, 2), F(-3, 4), F(7, 4), F(7, 3), F(-5, 11), 1), (F(3, 2), F(-2, 3), F(1, 5), F(1, 3), F(-2), F(4, 3), -1), (F(1), F(1), F(1), F(1), F(1), F(2), 1)):
        L1, R3d = frw_L1(a0, a1, N, kappa, Lam, k)
        pred1 = (N * (3 * k * a0 + Lam * a0 ** 3) - 3 * a0 * a1 * a1 / N) / kappa
        chk('std', L1 == pred1, 'k = %d, a = %s, adot = %s, N = %s, kappa = %s, Lambda = %s: L from (104)-(105) = %s = (1/kappa)[N(3k a + Lambda a^3) - 3 a adot^2/N]' % (k, a0, a1, N, kappa, Lam, L1))
        L2, R4 = frw_L2(a0, a1, a2, N, kappa, Lam, k)
        pred2 = (-3 * a0 * a0 * a2 / N - 3 * a0 * a1 * a1 / N - 3 * k * a0 * N + Lam * N * a0 ** 3) / kappa
        chk('std', L2 == pred2, '  L from (106), usual 4D R, addot = %s: = %s = (1/kappa)[-3 a^2 addot/N - 3 a adot^2/N - 3k a N + Lambda N a^3]; after the by-parts (3/(kappa N)) d(a^2 adot)/dt: (1/kappa)[3 a adot^2/N - 3k a N + Lambda N a^3]' % (a2, L2))
    # the constraints: dL/dN = 0 at N = 1.  L1 = N c1 + c2/N: c1 = c2.  Pick adot and a, solve Lambda.
    for k in (1, -1):
        a0, a1 = F(2), (F(1, 2) if k == 1 else F(3, 2))
        Lam1 = -3 * (a1 * a1 + k) / (a0 * a0)        # from adot^2 + k = -(Lambda/3) a^2
        c1 = lambda Lam: (3 * k * a0 + Lam * a0 ** 3); c2 = lambda Lam: -3 * a0 * a1 * a1
        chk('std', c1(Lam1) - c2(Lam1) == 0 and c1(-Lam1) - c2(-Lam1) != 0, 'k = %d: the (104)-(105) constraint dL1/dN = 0 holds at Lambda = %s and fails at Lambda = %s: adot^2 + k = -(Lambda/3) a^2' % (k, Lam1, -Lam1))
        c1b = lambda Lam: (-3 * k * a0 + Lam * a0 ** 3); c2b = lambda Lam: 3 * a0 * a1 * a1
        chk('std', c1b(-Lam1) - c2b(-Lam1) == 0 and c1b(Lam1) - c2b(Lam1) != 0, 'k = %d: the (106) constraint dL2/dN = 0 holds at Lambda = %s and fails at Lambda = %s: adot^2 + k = +(Lambda/3) a^2' % (k, -Lam1, Lam1))
    # de Sitter: closed slicing a = cosh(Ht)/H satisfies adot^2 + 1 = H^2 a^2 (exact at t = 0 and by cosh^2 - sinh^2 = 1): (106) side Lambda = 3 H^2 > 0, (104) side Lambda = -3 H^2
    H = F(3, 5); a0, a1 = 1 / H, F(0)
    chk('std', a1 * a1 + 1 == (3 * H * H) / 3 * a0 * a0, 'de Sitter closed slicing at t = 0 (a = 1/H, adot = 0): adot^2 + 1 = (Lambda/3) a^2 with Lambda = 3 H^2 = 3c of the Atlas: the (106) reading; the (104)-(105) reading needs Lambda = -3 H^2')
    chk('ctl', not (a1 * a1 + 1 == -(3 * H * H) / 3 * a0 * a0), 'the same de Sitter jets do not satisfy the (104)-(105) constraint with Lambda = +3 H^2 (the sign is the whole difference)')
    finish('H6')

if __name__ == '__main__': main()
