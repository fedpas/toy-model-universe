#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H1.  The bivector table in Lorentz signature: duality as a complex structure on the six plane labels, the 21 cells as 12 + 9, the Weyl part as a complex symmetric
 trace-free 3x3 matrix, Petrov types of the known solutions.      python3 h1_petrov.py
 [bit]  I = gamma_0123 by bmul (all 16 sign patterns); the 21-cell split by exact linear algebra on the table J; the engine's curvature (A3 closed-form omega, R = d omega +
        (1/4)[omega, omega]) in frame components, the standard Weyl projection, Q = E + iB in Q(i), the type from the Jordan structure of Q.
 [std]  the Riemann tensor of g = e^T eta e by the Christoffel route (exact), the Weyl tensor and Q in numpy floats by separate index loops, a numerical type (SVD ranks).
 Controls: random frames are type I; Euclidean patterns have J^2 = +1 and a real 5 + 5 + 9 + 1 + 1 split; the Levi-Civita complement without the eta signs is not a complex
 structure and does not make the Weyl part odd; a wrong Ricci coefficient is not trace-free; B without the 1/2 gives invariants that depend on the frame."""
import time, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from g2_weyl import *

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def dot(u, v): return sum(x * y for x, y in zip(u, v))
def ks(pt, rho, M, H2): return ks_frame_jet(pt, rho, *sds_jets(M, H2, rho))[0]

def part1():
    head('PART 1  duality on the six plane labels: I = gamma_0 gamma_1 gamma_2 gamma_3 times a bivector, all 16 sign patterns at n = 4 [bit]')
    allok = True
    for sq in itertools.product((1, -1), repeat=4):
        J, I2, comm, compl = duality_J(list(sq)); j2 = J_square(J); prod = sq[0] * sq[1] * sq[2] * sq[3]
        allok &= comm and compl and I2 == prod and j2 == I2
    chk('bit', allok, 'all 16 patterns: I commutes with every bivector, I B_A = +-B_(complement), I^2 = prod(sq) and J^2 = I^2 on the six labels')
    for sq, want in ((LORENTZ(4), -1), ([-1, 1, 1, 1], -1), ([1, 1, 1, 1], 1), ([-1, -1, -1, -1], 1), ([1, 1, -1, -1], 1)):
        J, I2, _, _ = duality_J(sq)
        chk('bit', J_square(J) == want, 'sq = %s: J^2 = %+d  (%s)' % (sq, J_square(J), 'a complex structure' if want == -1 else 'real eigenspaces, no complex structure'))
    J, _, _, _ = duality_J(LORENTZ(4))
    print('    (+,-,-,-): ' + ', '.join('I B_%d%d = %s B_%d%d' % (PAIRS4[A] + (('+' if s > 0 else '-'),) + PAIRS4[B]) for A, (B, s) in enumerate(J)))
    Jw = wrong_J_levi(LORENTZ(4))
    chk('ctl', J_square(Jw) == 1, 'wrong duality (complement with the Levi-Civita sign, no eta lowering): J^2 = +1 in Lorentz signature, so it fails J^2 = -1 (ok = it fails)')
    tick('part 1')

def block_rows(PL, PR):
    """rows of the linear conditions PL^T S PR = 0 on the 21 cells (PL, PR 6x6)"""
    rows = []
    for A in range(6):
        for C in range(6):
            row = [F(0)] * 21
            for B in range(6):
                for D in range(6):
                    c = PL[B][A] * PR[D][C]
                    if c: row[SIDX[(min(B, D), max(B, D))]] += c
            if any(row): rows.append(row)
    return rows

def part2():
    head('PART 2  the 21 cells under duality: dimensions by exact linear algebra on the table J (the Ricci contraction and the epsilon trace by their textbook definitions)')
    ric0 = None
    for sq in (LORENTZ(4), [-1, 1, 1, 1]):
        J = duality_J(sq)[0]; M = J21_matrix(J); ev = mat_sub_scalar(M, 1); od = mat_sub_scalar(M, -1)
        ric = ricci_rows(sq); eps = [eps_row()]; sc = [scalar_row(sq)]; g = metric_cell_vector(sq)
        chk('bit', (dim_of(ev), dim_of(od)) == (9, 12), 'sq = %s: J-even (Hermitian) 9 + J-odd (complex symmetric) 12 = 21' % sq)
        chk('bit', dim_of(eps) == 20 and dim_of(ric, eps) == 10, '  first Bianchi (epsilon trace) is one condition: 21 -> 20; the Weyl space W = ker(Ricci) in it has dimension 10')
        chk('bit', act_J(eps_row(), J) == [-x for x in eps_row()] and act_J(g, J) == [-x for x in g], '  the epsilon form and the bivector metric are both J-odd')
        chk('bit', dim_of(ric, eps, od) == 10 and dim_of(od, eps) == 11, '  W lies in the J-odd 12; the J-odd part of the Bianchi 20 is 11 = W (10) + the scalar (1)')
        chk('bit', dim_of(ev, eps) == 9 and dim_of(ev, ric) == 0 and dim_of(ev, sc) == 9, '  the J-even 9 satisfies Bianchi, the Ricci contraction is injective on it and its scalar is zero: it is the trace-free Ricci part')
        chk('bit', dot(ric[0], g) != 0 and dim_of(od, eps, ric) == 10, '  the metric form is not in W (its Ricci is not zero): odd & Bianchi = W + <g>, so 12 = 10 (Weyl) + 1 (scalar) + 1 (epsilon)')
        # cell classes against the duality split (used again by H2)
        tab = {}
        for cls in 'DEA':
            for nm, rows in (('H', ev), ('C', od)): tab[(cls, nm)] = dim_of(class_rows(cls), rows)
        chk('bit', tab == {('D', 'H'): 3, ('D', 'C'): 3, ('E', 'H'): 6, ('E', 'C'): 6, ('A', 'H'): 0, ('A', 'C'): 3},
            '  cell classes D (6), E (12), A (3) against Hermitian H (9) / complex symmetric C (12): D = 3 + 3, E = 6 + 6, A = 0 + 3  found %s' % {k[0] + k[1]: v for k, v in tab.items()})
    for sq in ([1, 1, 1, 1], [-1, -1, -1, -1]):
        J = duality_J(sq)[0]; M6 = J_matrix(J); M = J21_matrix(J); ev = mat_sub_scalar(M, 1); od = mat_sub_scalar(M, -1)
        dp = 6 - rank_exact(mat_sub_scalar(M6, 1)); dm = 6 - rank_exact(mat_sub_scalar(M6, -1))
        chk('bit', (dp, dm) == (3, 3) and (dim_of(ev), dim_of(od)) == (12, 9), 'sq = %s: J has real eigenspaces 3 + 3 (self-dual, anti-self-dual); the 21 split J-even 12 + J-odd 9' % sq)
        Pp = [[(F(1 if i == j else 0) + M6[i][j]) / 2 for j in range(6)] for i in range(6)]; Pm = [[(F(1 if i == j else 0) - M6[i][j]) / 2 for j in range(6)] for i in range(6)]
        Spp = block_rows(Pm, [[F(1 if i == j else 0) for j in range(6)] for i in range(6)])      # S^2(Lambda+): P-^T S = 0
        Smm = block_rows(Pp, [[F(1 if i == j else 0) for j in range(6)] for i in range(6)])      # S^2(Lambda-)
        Smix = block_rows(Pp, Pp) + block_rows(Pm, Pm)                                             # Lambda+ (x) Lambda-
        ric = ricci_rows(sq); eps = [eps_row()]; sc = [scalar_row(sq)]
        chk('bit', (dim_of(Spp), dim_of(Smm), dim_of(Smix)) == (6, 6, 9), '  J-even 12 = S^2(Lambda+) 6 + S^2(Lambda-) 6; J-odd 9 = Lambda+ (x) Lambda-')
        chk('bit', dim_of(Spp, sc) == 5 and dim_of(Smm, sc) == 5 and dim_of(Spp, eps) == 5 and dim_of(Smm, eps) == 5 and dim_of(Smix, eps) == 9 and dim_of(Smix, sc) == 9,
            '  the trace and the epsilon trace each cut one dimension from S^2(Lambda+) and from S^2(Lambda-), none from the 9: 5 + 1 + 5 + 1 + 9')
        chk('bit', dim_of(ev, eps) == 11 and dim_of(ev, eps, sc) == 10 and dim_of(ric, eps) == 10 and dim_of(ric, eps, Spp) == 5 and dim_of(ric, eps, Smm) == 5 and dim_of(od, ric) == 0,
            '  Bianchi removes the difference of the two traces (12 -> 11); W = 5 + 5 real (self-dual + anti-self-dual Weyl); Ricci injective on the 9: 5 + 5 + 9 + 1 (+1 removed)')
    Jw = wrong_J_levi(LORENTZ(4)); M = J21_matrix(Jw); ric = ricci_rows(LORENTZ(4)); eps = [eps_row()]
    chk('ctl', dim_of(ric, eps, mat_sub_scalar(M, -1)) < 10, 'wrong duality in Lorentz signature: the Weyl space is not J\'-odd (dim W & odd\' = %d < 10): ok = the wrong structure fails' % dim_of(ric, eps, mat_sub_scalar(M, -1)))
    tick('part 2')

def parts_of(Rl, sq, n=4):
    """(Weyl, trace-free-Ricci part, scalar part) as 4-index tensors, and the check that they add up to R"""
    C, Ric, Rs, tf = weyl_parts(Rl, sq, n); eta = lambda a, b: sq[a] if a == b else 0; c1, c2 = F(1, n - 2), F(1, (n - 1) * (n - 2))
    P = {(a, b, c, d): c1 * (eta(a, c) * tf[(b, d)] - eta(a, d) * tf[(b, c)] - eta(b, c) * tf[(a, d)] + eta(b, d) * tf[(a, c)]) for a in range(n) for b in range(n) for c in range(n) for d in range(n)}
    Sc = {(a, b, c, d): Rs * F(1, n * (n - 1)) * (eta(a, c) * eta(b, d) - eta(a, d) * eta(b, c)) for a in range(n) for b in range(n) for c in range(n) for d in range(n)}
    adds = all(C[k] + P[k] + Sc[k] == Rl[k] for k in Rl)
    return C, P, Sc, Ric, Rs, tf, adds

def analyse(name, e, Gv, S, sq, J, expect, std=True, quiet=False):
    """[bit] frame curvature, parts, parities, Q, type; [std] the same from the metric; returns a dict"""
    Rl, om, R = engine_frame_riemann(Gv, e, S, 4)
    with trunc(4, xdeg=0): tz = torsion_zero_at0(Gv, om, e, 4)
    C, P, Sc, Ric, Rs, tf, adds = parts_of(Rl, sq)
    SW, SE, SR = cell_vector(C), cell_vector(P), cell_vector(Sc)
    Q = complex_Q(C); typ, I2, I3, info = petrov(Q)
    ok_pre = tz and pair_symmetric(Rl) and dot(eps_row(), cell_vector(Rl)) == 0
    ok_w = all_traces_zero(C, sq) and adds
    ok_par = act_J(SW, J) == [-x for x in SW] and act_J(SE, J) == SE and act_J(SR, J) == [-x for x in SR]
    ok_q = q_symmetric(Q) and qtrace(Q).iszero()
    if not quiet:
        chk('bit', ok_pre, '%s: T = 0 at the point (A3), pair symmetry, epsilon trace 0 (first Bianchi)' % name)
        chk('bit', ok_w and ok_par, '%s: Weyl part trace-free on all six contractions, R = Weyl + trace-free Ricci + scalar; Weyl odd, trace-free Ricci even, scalar odd under J' % name)
    chk('bit', ok_q and typ == expect, '%s: Q = E + iB symmetric trace-free; Petrov type %s (expected %s); I2 = tr Q^2 = %s, I3 = tr Q^3 = %s%s' % (name, typ, expect, I2, I3, ('; eigenvalues %s, %s (double), rank(Q - r) = %d' % (info['simple'], info['double'], info['rank_Q_minus_r'])) if 'double' in info else ''))
    out = dict(Rl=Rl, C=C, Ric=Ric, Rs=Rs, tf=tf, Q=Q, typ=typ, I2=I2, I3=I3, info=info, om=om, SW=SW)
    if std:
        Rs_ = std_frame_riemann(e, 4, sq); Cf, Qf, Ricf, Rsf = weyl_float(Rs_, sq); tf_, I2f, I3f = petrov_float(Qf)
        same = (Rs_ == Rl)
        close = abs(I2f - I2.cx()) <= 1e-9 * max(1.0, abs(I2f)) and abs(I3f - I3.cx()) <= 1e-9 * max(1.0, abs(I3f))
        chk('bit==std', same and close and tf_ == typ, '%s: frame Riemann equals the Christoffel route exactly; float Weyl/Q: invariants agree to 1e-9 and the numerical type is %s' % (name, tf_))
        out['std'] = (Rs_, Qf)
    return out

def part3():
    head('PART 3  Weyl part, Q = E + iB and Petrov type of the engine\'s curvature on the known frames (Lorentz (+,-,-,-), exact at rational points) [bit], against the metric [std]')
    Gv, S, sq = lorentz_setup(); J = duality_J(sq)[0]; res = {}
    res['flat'] = analyse('flat e = dx', flat_frame(), Gv, S, sq, J, 'O')
    tick('flat')
    pts = [((F(1), F(2), F(2)), F(3)), ((F(2), F(3), F(6)), F(7)), ((F(-4), F(4), F(7)), F(9)), ((F(2), F(6), F(9)), F(11))]
    schw = {}; signs = set(); vac = True
    for (pt, rho) in pts:
        for M in (F(1), F(1, 3)):
            if M != 1 and rho != 7: continue
            e = ks(pt, rho, M, F(0)); r = analyse('Schwarzschild M = %s at %s (rho = %s)' % (M, tuple(str(x) for x in pt), rho), e, Gv, S, sq, J, 'D')
            schw[(M, rho)] = r; vac &= all(v == 0 for v in r['Ric'].values())
            if 'double' in r['info']:
                d = r['info']['double']; u = M / rho ** 3
                if d == QI(u): signs.add(+1)
                elif d == QI(-u): signs.add(-1)
                else: signs.add(0)
    chk('bit', vac, 'Schwarzschild: Ricci = 0 exactly at every point (vacuum)')
    chk('bit', signs in ({1}, {-1}), 'Schwarzschild: the double eigenvalue of Q is s M/rho^3 and the simple one -2 s M/rho^3 with one sign s = %s for all points and masses (pattern (-2, 1, 1) M/r^3 of LAB-006 up to the overall sign)' % signs)
    tick('Schwarzschild')
    for H2, nm in ((F(1, 5), 'SdS'), (F(-1, 5), 'SAdS')):
        for (pt, rho) in pts[:2]:
            e = ks(pt, rho, F(1), H2); r = analyse('%s M = 1, H2 = %s at rho = %s' % (nm, H2, rho), e, Gv, S, sq, J, 'D')
            s0 = schw[(F(1), rho)]
            chk('bit', (r['I2'], r['I3']) == (s0['I2'], s0['I3']) and r['info'].get('double') == s0['info'].get('double'), '  %s: invariants and eigenvalues equal to Schwarzschild\'s at the same (M, rho): the cosmological term is not in the Weyl part' % nm)
            chk('bit', all(v == 0 for v in r['tf'].values()) and r['Rs'] != 0, '  %s: Ricci part is pure trace (trace-free Ricci = 0, scalar = %s)' % (nm, r['Rs']))
    for H2, nm in ((F(1, 5), 'de Sitter'), (F(-1, 5), 'anti-de Sitter')):
        e = ks(pts[0][0], pts[0][1], F(0), H2); r = analyse('%s (M = 0, H2 = %s)' % (nm, H2), e, Gv, S, sq, J, 'O')
        chk('bit', all(v == 0 for v in r['C'].values()) and all(v == 0 for v in r['tf'].values()) and r['Rs'] != 0, '  %s: Weyl = 0, trace-free Ricci = 0, scalar = %s' % (nm, r['Rs']))
    tick('SdS, dS')
    for acoef, nm in (((1, 1, 1), "a = 1 + t + t^2"), ((1, 2, 1), 'a = (1 + t)^2')):
        e = frw_frame(acoef); r = analyse('FRW %s at t = 0' % nm, e, Gv, S, sq, J, 'O')
        chk('bit', all(v == 0 for v in r['C'].values()) and any(v != 0 for v in r['tf'].values()), '  FRW: Weyl = 0 with a non-zero trace-free Ricci (conformally flat, not Einstein)')
        e2 = translate_frame(e, [F(1, 2), F(0), F(0), F(0)], 4); r2 = analyse('FRW %s at t = 1/2' % nm, e2, Gv, S, sq, J, 'O')
    tick('FRW')
    rng = random.Random(11); ricz = True
    for k, (hc, kc) in enumerate(((( 1, 2, -1, 3), ()), ((0, 1), (2, 0, 1)), ((1, 2, -1, 3), (2, 0, 1)))):
        p = random_rational_point(rng); e = pw_frame(pw_global(hc, kc), p)
        r = analyse('plane wave h = %s, k = %s at %s' % (hc, kc, tuple(str(x) for x in p)), e, Gv, S, sq, J, 'N'); ricz &= all(v == 0 for v in r['Ric'].values())
    chk('bit', ricz, 'plane waves: Ricci = 0 exactly (vacuum pp-waves)')
    tick('plane waves')
    rng = random.Random(5); n_I = 0; n_tot = 0; rres = []
    for k in range(6):
        e = rand_frame(rng, 4, deg=2, coef=2, density=.5)
        if k >= 4: e = translate_frame(e, random_rational_point(rng, 2, 2), 4)
        r = analyse('random polynomial frame %d%s' % (k, ' translated to a random rational point' if k >= 4 else ''), e, Gv, S, sq, J, 'I', quiet=(k > 0)); n_tot += 1; n_I += (r['typ'] == 'I'); rres.append((e, r))
    chk('ctl', n_I == n_tot, 'random frames: %d of %d are type I (none degenerate)' % (n_I, n_tot))
    tick('random frames')
    # Lorentz invariance of the invariants and the control on the B factor
    L = rational_lorentz(sq, 'boost'); inv_ok = True; ctl_bad = False
    for nm, e, r in (('Schwarzschild', ks(pts[1][0], pts[1][1], F(1), F(0)), schw[(F(1), F(7))]), ('random frame 0', rres[0][0], rres[0][1])):
        e2 = transform_frame(e, L); Rl2, _, _ = engine_frame_riemann(Gv, e2, S, 4); C2 = weyl_parts(Rl2, sq)[0]
        t2, I22, I32, _ = petrov(complex_Q(C2)); inv_ok &= (t2, I22, I32) == (r['typ'], r['I2'], r['I3'])
        tw, I2w, I3w, _ = petrov(complex_Q(C2, bfac=F(1))); tw0, I2w0, I3w0, _ = petrov(complex_Q(r['C'], bfac=F(1))); ctl_bad |= (I2w, I3w) != (I2w0, I3w0)
    chk('bit', inv_ok, 'boosted and rotated frame (cosh, sinh) = (5/4, 3/4), (cos, sin) = (3/5, 4/5): Petrov invariants and type unchanged (Schwarzschild, random frame)')
    chk('ctl', ctl_bad, 'B without the 1/2: the "invariants" change under the boost (ok = the wrong Q is not Lorentz-invariant)')
    Cw = weyl_parts(rres[0][1]['Rl'], sq, 4, coef=(F(1, 3), F(1, 6)))[0]
    chk('ctl', not all_traces_zero(Cw, sq), 'wrong Ricci coefficient 1/(n-1) in the projection: not trace-free (ok = it fails)')
    # Kerr, with the helper g2_kerr.py
    kerr = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'g2_kerr.py')
    if os.path.exists(kerr):
        import g2_kerr as GK
        M, a = F(1), F(1, 2); found = set(); vac = True
        for d in GK.rational_kerr_points(a, [F(3), F(5, 2)], [((F(3, 5), F(4, 5)), (F(1), F(0))), ((F(5, 13), F(12, 13)), (F(3, 5), F(4, 5)))]):
            e = GK.kerr_ks_frame_jet(d['p'], M, a, d['r'])[0]
            r = analyse('Kerr M = %s, a = %s at r = %s, cos th = %s' % (M, a, d['r'], d['cth']), e, Gv, S, sq, J, 'D'); vac &= all(v == 0 for v in r['Ric'].values())
            psi2 = -QI(M) / QI(d['r'], -a * d['cth']) ** 3; dbl = r['info'].get('double')
            found.add('Psi2' if dbl == psi2 else ('conj(Psi2)' if dbl == psi2.conj() else ('-Psi2' if dbl == -psi2 else ('-conj(Psi2)' if dbl == -psi2.conj() else 'other'))))
        chk('bit', vac and len(found) == 1 and 'other' not in found, 'Kerr: Ricci = 0 and the double eigenvalue of Q equals %s with Psi2 = -M/(r - i a cos th)^3 (recalled) at every point, one convention' % found)
    else: print('    Kerr: g2_kerr.py is not in this folder; the Petrov type of Kerr is not checked', flush=True)
    tick('invariance, controls')
    return res

def part4():
    head('PART 4  Euclidean pattern (+,+,+,+): the Weyl part of a random Riemannian frame is J-even and splits into real self-dual + anti-self-dual blocks [bit, ctl]')
    sq = [1, 1, 1, 1]; Gv, S, _ = lorentz_setup(sq); J = duality_J(sq)[0]; M6 = J_matrix(J)
    Pp = [[(F(1 if i == j else 0) + M6[i][j]) / 2 for j in range(6)] for i in range(6)]; Pm = [[(F(1 if i == j else 0) - M6[i][j]) / 2 for j in range(6)] for i in range(6)]
    def blocks(Svec):
        Sm = [[Svec[SIDX[(min(A, B), max(A, B))]] for B in range(6)] for A in range(6)]
        def tsp(X, Y, Z): return [[sum(X[k][i] * Y[k][l] * Z[l][j] for k in range(6) for l in range(6)) for j in range(6)] for i in range(6)]
        return tsp(Pp, Sm, Pp), tsp(Pm, Sm, Pm), tsp(Pp, Sm, Pm)
    rng = random.Random(3); ok = True; nz = True
    for k in range(2):
        e = rand_frame(rng, 4, deg=2, coef=2, density=.5); Rl, om, R = engine_frame_riemann(Gv, e, S, 4)
        C, P, Sc, Ric, Rs, tf, adds = parts_of(Rl, sq); SW, SE = cell_vector(C), cell_vector(P)
        ok &= pair_symmetric(Rl) and adds and all_traces_zero(C, sq) and act_J(SW, J) == SW and act_J(SE, J) == [-x for x in SE]
        Wpp, Wmm, Wpm = blocks(SW); Epp, Emm, Epm = blocks(SE)
        ok &= all(x == 0 for row in Wpm for x in row) and all(x == 0 for row in Epp for x in row) and all(x == 0 for row in Emm for x in row)
        nz &= any(x != 0 for row in Wpp for x in row) and any(x != 0 for row in Wmm for x in row) and any(x != 0 for row in Epm for x in row)
    chk('ctl', ok and nz, 'Euclid: Weyl J-even with zero mixed block and non-zero (++) and (--) blocks (the real 5 + 5); trace-free Ricci J-odd, purely mixed (the 9): the split is real, no complex structure')
    tick('part 4')

if __name__ == '__main__':
    part1(); part2(); part3(); part4(); finish('H1')
