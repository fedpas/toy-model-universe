#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""E2S4-fluid.  The spin contact term of a spinor in the FRW frame of C4: off the Dirac shell and on it.     python3 e2s4_spin_fluid.py

 Conventions of e2_spin_torsion.py and e2s4_dirac_stress.py: Cl(1,3), sq = (+,-,-,-), the Atlas Dirac line (psi even), L_tot = L_EC - kappa L_D, T = -tau,
 omega* = omega_LC (A3) + K* (E2's axial contorsion), s = psi gamma_3 psi~, s.s = -rho^2, X_a = E_a - kappa tau_a. Lowered frame components at the origin;
 a perfect fluid at rest in E_0 has T_00 = rho, T_ij = p delta_ij, T_0i = 0.
 Frame: C4's frw_frame, k = 0, cosmic time, a(t) a cubic polynomial (3 draws). Spinors: even, homogeneous (polynomials in t only), degree 2;
 d_0 psi(0) solved from the Dirac equation at the point (E2S4's onshell_psi, rank 8), on the torsionful shell (omega*) and on the free shell (omega_LC).
 Claims checked:
  (off) sym[X(omega*) - X(omega_LC)]_ab = -(3/16) kappa^2 (s.s) eta_ab for any spinor: the contact stress is T^c = -(3 kappa/16)(s.s) eta,
        rho_c = (3 kappa/16) rho^2 and p_c = -rho_c (p/rho = -1), homogeneous or not.
  (on)  free shell, homogeneous: T = -tau_(ab)(omega_LC) is diagonal with rho = m <psi psi~>, p = 0.
        torsionful shell, homogeneous: the effective source T^eff = -[tau_(ab)(omega_LC) + (3 kappa/16)(s.s) eta] (E2S4's Hehl-Datta form) is a perfect fluid
        in E_0, and its contact part Delta = T^eff - T^free (same psi(0)) is (3 kappa/16) rho^2 diag(1, 1, 1, 1): a stiff fluid, p = rho >= 0.
  (split) For a non-homogeneous spinor the total source is not a perfect fluid at rest in E_0 (the test is: diagonal with T_11 = T_22 = T_33; a fluid moving relative to E_0
        is not excluded), while Delta keeps the same stiff diagonal form (only d_0 psi changes).
 [bit] exact fractions: E2S4's dirac_stress, frame_eq, onshell_psi, kstar_forms; A3's omega; C4's frame.
 [std] numpy only: Dirac matrices (E2's Std), the Christoffel spin connection of the FRW frame (E1's StdSpin), d_t chi solved from
       i Gamma^a nabla_a chi = m chi - (3 kappa/8) A_d Gamma^d gamma5 chi (or the free equation), and the textbook symmetric stress
       Re(chibar i Gamma_(a nabla_b) chi) - eta_ab L_eff with L_eff = Re(chibar i Gamma^a nabla_a chi) - m chibar chi + (3 kappa/16)(A.A).
 Controls: the non-homogeneous spinor (total source not a perfect fluid at rest in E_0); the wrong sign of the contact coupling (rho_c changes sign); no field equation
 (d_0 psi left random: Delta is not stiff); a wrong contact coefficient (3/8) in the Hehl-Datta identity.
 Scope: n = 4, (+,-,-,-), classical commuting spinors, k = 0, the point t = 0, x = 0 of 3 FRW frames; no series in t, no solution of the coupled
 Einstein-Dirac equations, nothing about four-fermion physics. The spin-fluid cosmology literature is not read."""
import sys, os, time, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import e2_spin_torsion as E2
import e2s4_dirac_stress as S4
import c4_frw as C4
import e1_lichnerowicz as E1
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N = 4; NV = S4.NV; LOR = [1, -1, -1, -1]; EVEN = E2.EVEN; C316 = F(3, 16)
def sym(M): return [[(M[a][b] + M[b][a]) / 2 for b in range(N)] for a in range(N)]
def eta(a, b): return LOR[a] if a == b else 0
def is_fluid(T): return all(T[a][b] == 0 for a in range(N) for b in range(N) if a != b) and T[1][1] == T[2][2] == T[3][3]
def mon(k): return tuple(k) + (0,) * (NV - len(k))

def rand_spinor(rng, homogeneous=True):
    """[bit input] even psi, polynomials of degree 2 in t (slot 0); homogeneous=False adds random linear terms in x^1, x^2, x^3"""
    while True:
        psi = {}
        for S in EVEN:
            p = {mon((k,)): F(rng.randint(-3, 3)) for k in range(3)}
            if not homogeneous:
                for i in (1, 2, 3): p[mon(tuple(1 if j == i else 0 for j in range(4)))] = F(rng.randint(-3, 3))
            p = {kk: v for kk, v in p.items() if v != 0}
            if p: psi[S] = p
        if len(psi) >= 5: return psi
def scalars(psi):
    """s.s and <psi psi~> at the origin (E2's currents)"""
    s, j, pp, _ = E2.currents({S: {k: v for k, v in p.items() if sum(k[:N]) == 0} for S, p in psi.items()}, LOR, NV)
    sv = [S4.v0(p) for p in E2.vec(s)]
    return sum((LOR[d] * sv[d] ** 2 for d in range(N)), F(0)), S4.v0(pp.get(0, {}))

def frame_draw(rng):
    acoef = [F(rng.randint(2, 5), 2), F(rng.randint(-4, 4), 3), F(rng.randint(-3, 3), 5), F(rng.randint(-2, 2), 7)]
    Gv = Grav(N, Lie(LOR)); e = C4.frw_frame(acoef, k=0, nv=NV)
    Sk = koszul_S(N, LOR, Gv.L); oml = omega_closed_form(Gv, e, Sk, NV, 1, Dpre=anholonomy(Gv, e, NV, 1))[0]
    return Gv, e, oml, acoef
def omega_star(Gv, oml, e, psi, kap):
    K, _ = S4.kstar_forms(Gv, e, psi, kap); return [Gv.Fm.add(oml[A], K[A]) for A in range(Gv.G)]
def T_source(Gv, e, oml, psi, m, kap, contact):
    """lowered T_ab = -[tau_(ab)(omega_LC) + contact (s.s) eta_ab] at the origin (contact = 3 kappa/16: E2S4's effective source; 0: the free source)"""
    _, tl = S4.frame_eq(Gv, e, oml, psi, m, 0); ts = sym(tl); ss, _ = scalars(psi)
    return [[-(ts[a][b] + contact * ss * eta(a, b)) for b in range(N)] for a in range(N)]

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
def std_source(e, psi, m, kap, st2, c_eq, c_L):
    """[std] chi = M(psi) u at the origin; d_t chi solved from i Gamma^a nabla_a chi = m chi - c_eq A_d Gamma^d gamma5 chi; T_ab = Re chibar i Gamma_(a nabla_b) chi - eta_ab L_eff,
       L_eff = Re chibar i Gamma^a nabla_a chi - m chibar chi + c_L (A.A); lowered, as a 4x4 array"""
    G, Gup, g5, u, BL = st2.G, st2.Gup, st2.g5, st2.u, st2.BL
    sS = E1.StdSpin(e, {}, N, LOR, G); x0 = np.zeros(N); E = sS.Emat(x0); A_ = sS.spinconn(sS.omega(x0))
    coef = lambda S, k: float(psi.get(S, {}).get(mon(k), 0))
    chi = sum(coef(S, (0,)) * BL[S] for S in psi) @ u
    dchi = [sum(coef(S, tuple(1 if j == mu else 0 for j in range(4))) * BL[S] for S in psi) @ u for mu in range(N)]
    Av = st2.bil(chi)['A']; Al = [LOR[d] * Av[d] for d in range(N)]; AA = float(sum(LOR[d] * Av[d] ** 2 for d in range(N)))
    def nab(y):                                                                    # frame derivatives nabla_a chi with d_0 chi = y
        dc = [y] + dchi[1:]; cov = [dc[mu] + A_[mu] @ chi for mu in range(N)]
        return [sum(E[mu, a] * cov[mu] for mu in range(N)) for a in range(N)]
    rhs = m * chi - c_eq * sum(Al[d] * Gup[d] @ g5 for d in range(N)) @ chi
    lin = lambda y: 1j * sum(Gup[a] @ nab(y)[a] for a in range(N))
    b0 = lin(np.zeros(4, complex)); M = np.column_stack([lin(np.eye(4)[k].astype(complex)) - b0 for k in range(4)])
    y = np.linalg.solve(M, rhs - b0); nb = nab(y); bar = st2.bar(chi)
    Leff = float((bar @ (1j * sum(Gup[a] @ nb[a] for a in range(N)))).real) - m * float((bar @ chi).real) + c_L * AA
    T = np.array([[0.5 * float((bar @ (1j * G[a] @ nb[b])).real + (bar @ (1j * G[b] @ nb[a])).real) - (LOR[a] if a == b else 0) * Leff for b in range(N)] for a in range(N)])
    return T, -AA, float((bar @ chi).real)

# ------------------------------------------------------------------------------------------------ main
def main():
    rng = random.Random(3141); st2 = E2.Std(); kaps = [F(1), F(2, 5), F(3)]; ms = [F(7, 4), F(1, 3), F(2)]
    st = dict(tf=True, off=True, off_nh=True, hd=True, hd_wrong=True, free=True, eff=True, delta=True, dnh=True, nh_ctl=True, wrong=True, nofe=True,
              e_free=0.0, e_eff=0.0, std_free=True, std_delta=0.0, std_fluid=True)
    head('E2S4-fluid: C4 FRW frames (k = 0, a(t) cubic), the origin; homogeneous even spinors; torsionful and free Dirac shells')
    for draw in range(3):
        Gv, e, oml, acoef = frame_draw(rng); kap, m = kaps[draw], ms[draw]; Fm = Gv.Fm
        with trunc(N, xdeg=1): T0l = Gv.torsion(oml, e)
        st['tf'] &= all(v == 0 for x in T0l for q in x.values() for k, v in q.items() if sum(k[:N]) <= 1)
        psi = rand_spinor(rng); psinh = rand_spinor(rng, homogeneous=False); ss, alpha = scalars(psi)
        # (off) the contact stress without the field equation
        for ps, key in ((psi, 'off'), (psinh, 'off_nh')):
            oms = omega_star(Gv, oml, e, ps, kap); s2, _ = scalars(ps)
            Es, ts = S4.frame_eq(Gv, e, oms, ps, m, 0); El, tl = S4.frame_eq(Gv, e, oml, ps, m, 0)
            D = sym([[(Es[a][b] - kap * ts[a][b]) - (El[a][b] - kap * tl[a][b]) for b in range(N)] for a in range(N)])
            st[key] &= all(D[a][b] == -C316 * kap ** 2 * s2 * eta(a, b) for a in range(N) for b in range(N)) and s2 != 0
        # (on) torsionful and free shells, the same psi(0)
        pon, rk1, _ = S4.onshell_psi(Gv, e, omega_star(Gv, oml, e, psi, kap), psi, m); pfr, rk2, _ = S4.onshell_psi(Gv, e, oml, psi, m)
        oms = omega_star(Gv, oml, e, pon, kap); Es, ts = S4.frame_eq(Gv, e, oms, pon, m, 0); El, tl = S4.frame_eq(Gv, e, oml, pon, m, 0); tls = sym(tl)
        X = [[Es[a][b] - kap * ts[a][b] for b in range(N)] for a in range(N)]
        st['hd'] &= rk1 == 8 and rk2 == 8 and all(X[a][b] == El[a][b] - kap * (tls[a][b] + C316 * kap * ss * eta(a, b)) for a in range(N) for b in range(N))
        st['hd_wrong'] &= not all(X[a][b] == El[a][b] - kap * (tls[a][b] + F(3, 8) * kap * ss * eta(a, b)) for a in range(N) for b in range(N))
        Tfr = T_source(Gv, e, oml, pfr, m, kap, 0); Tef = T_source(Gv, e, oml, pon, m, kap, C316 * kap)
        st['free'] &= is_fluid(Tfr) and Tfr[0][0] == m * alpha and Tfr[1][1] == 0
        st['eff'] &= is_fluid(Tef)
        Dl = [[Tef[a][b] - Tfr[a][b] for b in range(N)] for a in range(N)]; rc = -C316 * kap * ss
        st['delta'] &= all(Dl[a][b] == (rc if a == b else 0) for a in range(N) for b in range(N)) and rc > 0
        if draw == 0: print('    draw 0: a(t) coefficients %s, kappa = %s, m = %s, s.s = %s, <psi psi~> = %s; free: rho = %s, p = %s; torsionful shell: rho = %s, p = %s; contact part rho_c = p_c = %s'
                            % ([str(x) for x in acoef], kap, m, ss, alpha, Tfr[0][0], Tfr[1][1], Tef[0][0], Tef[1][1], rc))
        # wrong sign of the contact coupling (lambda = +kappa): contorsion -K*, contact term -(3 kappa/16)(s.s) eta
        pw, _, _ = S4.onshell_psi(Gv, e, omega_star(Gv, oml, e, psi, -kap), psi, m); Tw = T_source(Gv, e, oml, pw, m, kap, -C316 * kap)
        st['wrong'] &= (Tw[0][0] - Tfr[0][0] == -rc) and (Tw[1][1] - Tfr[1][1] == -rc)
        # no field equation: d_0 psi left at its random value
        Tn = T_source(Gv, e, oml, psi, m, kap, C316 * kap); Tn0 = T_source(Gv, e, oml, psi, m, kap, 0)
        st['nofe'] &= not (Tn[0][0] - Tn0[0][0] == Tn[1][1] - Tn0[1][1])
        # non-homogeneous spinor
        pnh, _, _ = S4.onshell_psi(Gv, e, omega_star(Gv, oml, e, psinh, kap), psinh, m); pnf, _, _ = S4.onshell_psi(Gv, e, oml, psinh, m); snh, _ = scalars(psinh)
        Tnh = T_source(Gv, e, oml, pnh, m, kap, C316 * kap); Tnf = T_source(Gv, e, oml, pnf, m, kap, 0)
        st['nh_ctl'] &= not is_fluid(Tnh)
        st['dnh'] &= all(Tnh[a][b] - Tnf[a][b] == (-C316 * kap * snh if a == b else 0) for a in range(N) for b in range(N))
        # [std]
        for pp_, c_eq, c_L, Tb, key in ((pfr, 0.0, 0.0, Tfr, 'e_free'), (pon, 0.375 * float(kap), 0.1875 * float(kap), Tef, 'e_eff')):
            Ts, sss, cc = std_source(e, pp_, float(m), float(kap), st2, c_eq, c_L)
            st[key] = max(st[key], float(np.max(np.abs(Ts - np.array([[float(x) for x in r] for r in Tb])))) / max(1.0, float(np.max(np.abs(Ts)))))
            if key == 'e_free': Tsf = Ts; st['std_free'] &= abs(Ts[0, 0] - float(m) * cc) < 1e-9 * (1 + abs(Ts[0, 0])) and abs(Ts[1, 1]) < 1e-9 * (1 + abs(Ts[0, 0]))
            else:
                Dstd = Ts - Tsf; rcs = 0.1875 * float(kap) * sss
                st['std_delta'] = max(st['std_delta'], float(np.max(np.abs(Dstd - rcs * np.eye(4)))) / max(1.0, abs(rcs)))
                st['std_fluid'] &= float(np.max(np.abs(Ts - np.diag(np.diag(Ts))))) < 1e-9 * (1 + abs(Ts[0, 0])) and abs(Ts[1, 1] - Ts[2, 2]) + abs(Ts[2, 2] - Ts[3, 3]) < 1e-9 * (1 + abs(Ts[0, 0]))
        tick('draw %d' % draw)
    chk('bit', st['tf'], 'omega_LC (A3, x-degree 1) is torsion-free to first order on the 3 FRW frames (precondition)')
    chk('bit', st['off'] and st['off_nh'], 'off the Dirac shell: sym[X(omega*) - X(omega_LC)]_ab = -(3/16) kappa^2 (s.s) eta_ab for homogeneous and non-homogeneous spinors: the contact stress is T^c = -(3 kappa/16)(s.s) eta, rho_c = (3 kappa/16) rho^2, p_c = -rho_c (p/rho = -1)')
    chk('bit', st['hd'], "torsionful shell (d_0 psi solved, rank 8; free shell also rank 8): E2S4's identity X(omega*) = E(omega_LC) - kappa [tau_(ab)(omega_LC) + (3 kappa/16)(s.s) eta] holds on the FRW frames")
    chk('ctl', st['hd_wrong'], 'the same identity with the contact coefficient 3/8: fails')
    chk('bit', st['free'], 'free shell, homogeneous spinor: T = -tau_(ab)(omega_LC) is diagonal and isotropic with rho = m <psi psi~> and p = 0 at the point (3 frames)')
    chk('bit', st['eff'], 'torsionful shell, homogeneous spinor: the effective source T^eff = -[tau_(ab)(omega_LC) + (3 kappa/16)(s.s) eta] is a perfect fluid at rest in E_0 (diagonal, isotropic)')
    chk('bit', st['delta'], 'its contact part Delta = T^eff - T^free (same psi(0)) is (3 kappa/16) rho^2 diag(1, 1, 1, 1): a stiff fluid, p_c = rho_c = -(3 kappa/16)(s.s) > 0 (3 frames, kappa = 1, 2/5, 3)')
    chk('ctl', st['wrong'], 'wrong sign of the contact coupling (contorsion -K*, contact term -(3 kappa/16)(s.s) eta): rho_c and p_c change sign')
    chk('ctl', st['nofe'], 'without the field equation (d_0 psi left random) the contact part is not stiff: Delta_00 != Delta_11')
    chk('ctl', st['nh_ctl'], 'a non-homogeneous spinor (linear terms in x): the total on-shell source is not a perfect fluid at rest in E_0 (the test, diagonal with T_11 = T_22 = T_33, fails)')
    chk('bit', st['dnh'], 'finding: for that non-homogeneous spinor the contact part Delta is still (3 kappa/16) rho^2 diag(1, 1, 1, 1): only d_0 psi changes between the two shells, so Delta is stiff in the frame of the solve')
    chk('std', st['std_free'] and st['std_fluid'], 'std (Dirac matrices, Christoffel spin connection, d_t chi solved from the textbook equations): free rho = m chibar chi, p = 0; Hehl-Datta shell: source diagonal and isotropic')
    chk('std', st['std_delta'] < 1e-9, 'std: contact part T^eff - T^free = (3 kappa/16)(-A.A) diag(1, 1, 1, 1) (rel. %.1e)' % st['std_delta'])
    chk('bit==std', st['e_free'] < 1e-9 and st['e_eff'] < 1e-9, 'engine sources on both shells = std (rel. %.1e, %.1e)' % (st['e_free'], st['e_eff']))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('E2S4-fluid')

if __name__ == '__main__': main()
