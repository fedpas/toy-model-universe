#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""D4. Geodesic deviation as a dynamical statement.   python3 d4_deviation.py

Schwarzschild in Kerr-Schild form (b1lib.ks_frame_jet: e^a = dx^a - f l^a l_mu dx^mu, f = M/rho, coordinates (t, x, y, z), 2-jets at a rational point).
[bit]  omega = A3 closed form, R = d omega + 1/4 [omega, omega] (engine).  A family of geodesics of the frame's geodesic equation
         dx^mu/dtau = E^mu_a u^a,   du^c/dtau = - h_{Ab}^c omega^A(dx/dtau) u^b          (the form of h3_sign_chain.engine_accel)
       is built as exact Taylor series in tau (to tau^2, exact with 2-jets of the frame and the 1-jet of omega) and to first order in s (Picard iteration on truncated polynomials), x(0, s) = p + s xi0, u(0, s) = u0 + s eta0.
       Relative acceleration A^a = D^2 xi^a/dtau^2 at tau = 0, D xi^a = d xi^a/dtau + Omega^a_b(u) xi^b, Omega^a_b = h_{Ab}^a omega^A, xi^a = e^a_mu d_s x^mu.
       Compared with -R(xi, u) u (h table route) and with -E xi, E^a_c = R^a_{bcd} u^b u^d (bivector components and eta).
[std]  Riemann from Christoffel symbols (exact, b1lib.std_riemann) and a numerical integration (scipy DOP853) of nearby geodesics of the closed-form metric.
Convention found: E^a_c = R^a_{bcd} u^b u^d (mixed) is the same in both sign conventions; relative acceleration = -E xi; for an observer at rest in the frame
E^i_j = R^i_{0j0} = d_i d_j Phi, Phi = -M/rho."""
import sys, os, time, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from fractions import Fraction as F
import numpy as np

CONV = {'ours (+,-,-,-)': [1, -1, -1, -1], 'flip (-,+,+,+)': [-1, 1, 1, 1]}
K = 2                                                         # tau-degree of the series (tau^2 is all the acceleration at tau = 0 needs)

# ------------------------------------------------------------------------------------------------ (tau, s) polynomials truncated at tau^K and s^1
def tp_add(a, b, c=1):
    r = dict(a)
    for k, v in b.items():
        x = r.get(k, 0) + c * v
        if x == 0: r.pop(k, None)
        else: r[k] = x
    return r
def tp_mul(a, b):
    r = {}
    for (i1, j1), v1 in a.items():
        for (i2, j2), v2 in b.items():
            i, j = i1 + i2, j1 + j2
            if i > K or j > 1: continue
            r[(i, j)] = r.get((i, j), 0) + v1 * v2
    return {k: v for k, v in r.items() if v != 0}
def tp_sum(it):
    r = {}
    for x in it: r = tp_add(r, x)
    return r
def tp_int(a): return {(i + 1, j): v / (i + 1) for (i, j), v in a.items() if i + 1 <= K}
def tp_der(a): return {(i - 1, j): v * i for (i, j), v in a.items() if i > 0}
def tp_c(v): return {(0, 0): F(v)} if v else {}
def tp_s(v): return {(0, 1): F(v)} if v else {}
def s0(a): return {(i, 0): v for (i, j), v in a.items() if j == 0}
def s1(a): return {(i, 0): v for (i, j), v in a.items() if j == 1}
def at00(a): return a.get((0, 0), F(0))
def powers(d): return [[tp_c(1), d[m], tp_mul(d[m], d[m])] for m in range(4)]
def subst(P, pw):
    out = {}
    for k, v in P.items():
        assert max(k) <= 2
        term = {(0, 0): v}
        for m in range(4):
            if k[m]: term = tp_mul(term, pw[m][k[m]])
        out = tp_add(out, term)
    return out

# ------------------------------------------------------------------------------------------------ engine set-up at a point
def ks_setup(Gv, S, p, rho0, M):
    """[bit] frame 2-jets, inverse frame 2-jet (series), omega 1-jet (A3 closed form) and R at the point (engine)"""
    f0, f1, f2 = sds_jets(F(M), F(0), F(rho0)); e = ks_frame_jet(tuple(F(x) for x in p), F(rho0), f0, f1, f2)[0]
    with trunc(4, xdeg=2): Ej, det = inverse_series(frame_matrix(e, 4), 4, 4, 2)
    om, R = engine_om_R(Gv, e, S, 4)
    e0, E0, det0 = E0_of(e, 4, 4)
    hl = [(A, b, c, hv) for (A, b), (c, hv) in Gv.L.h.items()]
    R0 = [{(m, v): at0(R[A].get((1 << m) | (1 << v), {}), 4) for m in range(4) for v in range(m + 1, 4)} for A in range(Gv.G)]
    return dict(Gv=Gv, e=e, ej=[[e[a].get(1 << m, {}) for m in range(4)] for a in range(4)], Ej=Ej, om=om,
                omj=[[om[A].get(1 << m, {}) for m in range(4)] for A in range(Gv.G)], R=R, R0=R0, hl=hl, e0=e0, E0=E0, sq=Gv.L.sq, p=p, rho0=F(rho0), M=F(M))

def family(st, xi0c, u0, eta0, sg=1, zero_om=False):
    """[bit] the geodesic family as (tau, s) series; sg = -1 flips omega in the geodesic equation (control)"""
    G = st['Gv'].G; Ej, omj, hl = st['Ej'], st['omj'], st['hl']
    d = [tp_s(xi0c[m]) for m in range(4)]; uinit = [tp_add(tp_c(u0[a]), tp_s(eta0[a])) for a in range(4)]; u = [dict(x) for x in uinit]
    for _ in range(K + 1):
        pw = powers(d)
        xd = [tp_sum(tp_mul(subst(Ej[m][a], pw), u[a]) for a in range(4) if Ej[m][a] and u[a]) for m in range(4)]
        ud = [{} for _ in range(4)]
        if not zero_om:
            omx = [tp_sum(tp_mul(subst(omj[A][m], pw), xd[m]) for m in range(4) if omj[A][m] and xd[m]) for A in range(G)]
            for (A, b, c, hv) in hl:
                if omx[A] and u[b]: ud[c] = tp_add(ud[c], tp_mul(omx[A], u[b]), -sg * hv)
        d = [tp_add(tp_s(xi0c[m]), tp_int(xd[m])) for m in range(4)]
        u = [tp_add(uinit[a], tp_int(ud[a])) for a in range(4)]
    return d, u

def rel_acc(st, d, sgD=1, zero_om=False):
    """[bit] A^a = D^2 xi^a/dtau^2 at tau = 0 (frame components, connection terms included); also D xi/dtau at 0 and the coordinate series of xi"""
    G = st['Gv'].G; ej, omj, hl = st['ej'], st['omj'], st['hl']
    x = [s0(d[m]) for m in range(4)]; xi = [s1(d[m]) for m in range(4)]; pw = powers(x)
    xif = [tp_sum(tp_mul(subst(ej[a][m], pw), xi[m]) for m in range(4) if ej[a][m] and xi[m]) for a in range(4)]
    xd = [tp_der(x[m]) for m in range(4)]
    Om = [[{} for _ in range(4)] for _ in range(4)]
    if not zero_om:
        omx = [tp_sum(tp_mul(subst(omj[A][m], pw), xd[m]) for m in range(4) if omj[A][m] and xd[m]) for A in range(G)]
        for (A, b, c, hv) in hl: Om[c][b] = tp_add(Om[c][b], omx[A], sgD * hv)
    V = [tp_add(tp_der(xif[a]), tp_sum(tp_mul(Om[a][b], xif[b]) for b in range(4))) for a in range(4)]
    Acc = [tp_add(tp_der(V[a]), tp_sum(tp_mul(Om[a][b], V[b]) for b in range(4))) for a in range(4)]
    return [at00(Acc[a]) for a in range(4)], [at00(V[a]) for a in range(4)], xi

def predict_h(st, xi0c, xd0, u0):
    """[bit] -R(xi, u) u through the h table: P^c = - h_{Ab}^c R^A(xi, xdot) u^b"""
    P = [F(0)] * 4
    for (A, b, c, hv) in st['hl']:
        if not u0[b]: continue
        r = sum(val * (xi0c[m] * xd0[v] - xi0c[v] * xd0[m]) for (m, v), val in st['R0'][A].items() if val)
        P[c] -= hv * r * u0[b]
    return P

def frame_Rf(Gv, R, E0):
    """[bit] R^{ab}_{cd} = R^{ab}(E_c, E_d) at the point (bivector components of the engine's curvature)"""
    Rab = Rab_at0(Gv, R, 4); out = {}
    for a in range(4):
        for b in range(4):
            if a == b: continue
            for c in range(4):
                for d in range(4):
                    out[(a, b, c, d)] = sum(Rab.get((a, b, m, v), 0) * E0[m][c] * E0[v][d] for m in range(4) for v in range(4) if m != v)
    return out
def tidal_from_Rf(Rf, sq, u, swap=False):
    """E^a_c = R^a_{bcd} u^b u^d with R^a_{bcd} = R^{ab}_{cd} eta_bb   (swap=True: the wrong order R^a_{bdc}, a control)"""
    return [[sum(sq[b] * Rf.get((a, b, d, c) if swap else (a, b, c, d), 0) * u[b] * u[d] for b in range(4) for d in range(4) if b != a) for c in range(4)] for a in range(4)]
def tidal_tensor(Gv, e, S, u):
    """[export] tidal tensor of the engine at the point of the frame jets e (2-jets, the A3 closed form for omega):
    E^a_c = R^a_{bcd} u^b u^d (frame components, one index up, one down; the same in both sign conventions); relative acceleration of nearby geodesics
    D^2 xi^a/dtau^2 = -E^a_c xi^c.  For the observer at rest in the Kerr-Schild frame E^i_j = d_i d_j Phi (Phi = -M/rho).  Returns 4 x 4 Fractions."""
    om, R = engine_om_R(Gv, e, S, 4); e0, E0, det = E0_of(e, 4, 4)
    return tidal_from_Rf(frame_Rf(Gv, R, E0), Gv.L.sq, u)
def tidal_tensor_point_mass(p, rho0, M, sq=(1, -1, -1, -1)):
    """[export] 3 x 3 block E^i_j (i, j = x, y, z) of tidal_tensor for the observer u = (1, 0, 0, 0) at rest in the Kerr-Schild frame of mass M at p, |p| = rho0 rational;
    equals (M/rho0^3)(delta_ij - 3 n_i n_j), n = p/rho0 (checked in D4)."""
    Lie_ = Lie(list(sq)); Gv = Grav(4, Lie_); S = koszul_S(4, list(sq), Lie_)
    f0, f1, f2 = sds_jets(F(M), F(0), F(rho0)); e = ks_frame_jet(tuple(F(x) for x in p), F(rho0), f0, f1, f2)[0]
    Et = tidal_tensor(Gv, e, S, [1, 0, 0, 0]); return [[Et[i][j] for j in (1, 2, 3)] for i in (1, 2, 3)]

def charpoly(A):
    n = len(A); I = [[F(int(i == j)) for j in range(n)] for i in range(n)]; c = [F(1)]; Mk = [[F(0)] * n for _ in range(n)]
    for k in range(1, n + 1):
        Mk = [[sum(A[i][l] * (Mk[l][j] + c[-1] * I[l][j]) for l in range(n)) for j in range(n)] for i in range(n)]
        c.append(-sum(Mk[i][i] for i in range(n)) / k)
    return c

# ------------------------------------------------------------------------------------------------ [std] numerical route (numpy / scipy, no engine)
ETA = np.diag([1., -1., -1., -1.])
def ks_num(M, x):
    X = np.asarray(x[1:], float); r = np.sqrt(X @ X); n = X / r; f = M / r
    ld = np.concatenate(([1.], n)); lu = np.concatenate(([1.], -n))
    dg = np.zeros((4, 4, 4))
    for k in range(1, 4):
        df = -M * X[k - 1] / r ** 3; dl = np.zeros(4); dl[1:] = (np.eye(3)[k - 1] - n * n[k - 1]) / r
        dg[k] = -2 * (df * np.outer(ld, ld) + f * (np.outer(dl, ld) + np.outer(ld, dl)))
    gi = np.linalg.inv(ETA - 2 * f * np.outer(ld, ld))
    Gam = 0.5 * (np.einsum('ls,msn->lmn', gi, dg) + np.einsum('ls,nsm->lmn', gi, dg) - np.einsum('ls,smn->lmn', gi, dg))
    return Gam, np.eye(4) - f * np.outer(lu, ld), np.eye(4) + f * np.outer(lu, ld)      # Gamma^l_mn, e^a_mu, E^mu_a
def num_dGam(M, x, h=1e-5):
    return np.array([(ks_num(M, x + h * np.eye(4)[r])[0] - ks_num(M, x - h * np.eye(4)[r])[0]) / (2 * h) for r in range(4)])
def num_riem(M, x):
    G = ks_num(M, x)[0]; dG = num_dGam(M, x)
    return (np.einsum('mrns->rsmn', dG) - np.einsum('nrms->rsmn', dG) + np.einsum('rml,lns->rsmn', G, G) - np.einsum('rnl,lms->rsmn', G, G))
def num_acc(M, x, v): return -np.einsum('lmn,m,n->l', ks_num(M, x)[0], v, v)
def std_D2xi(M, x, v, xi, xid, xidd):
    G = ks_num(M, x)[0]; dG = num_dGam(M, x); a = -np.einsum('lmn,m,n->l', G, v, v)
    return (xidd + np.einsum('rlmn,r,m,n->l', dG, v, v, xi) + np.einsum('lmn,m,n->l', G, a, xi) + 2 * np.einsum('lmn,m,n->l', G, v, xid)
            + np.einsum('lmn,m,n->l', G, v, np.einsum('nrs,r,s->n', G, v, xi)))
def std_case(M, p, u0, xi0f, tau1=0.2, hs=1e-4):
    """[std] three geodesics (s = 0, +-hs) of the closed-form metric; returns the frame components of D^2 xi at tau = 0, the Jacobi residual at tau1 and xi(tau) at 0.1, 0.2"""
    from scipy.integrate import solve_ivp
    x0 = np.array([0.] + [float(c) for c in p]); u0 = np.array([float(c) for c in u0])
    e_, E_ = ks_num(M, x0)[1:]; xi0 = E_ @ np.array([float(c) for c in xi0f])
    st = {}
    for s in (0., hs, -hs):
        xs = x0 + s * xi0; vs = ks_num(M, xs)[2] @ u0; st[s] = (xs, vs)
    v = st[0.][1]; xid = (st[hs][1] - st[-hs][1]) / (2 * hs); xidd = (num_acc(M, *st[hs]) - num_acc(M, *st[-hs])) / (2 * hs)
    A0 = e_ @ std_D2xi(M, x0, v, xi0, xid, xidd)
    rhs = lambda t, y: np.concatenate((y[4:], num_acc(M, y[:4], y[4:])))
    sol = {s: solve_ivp(rhs, (0., tau1), np.concatenate(st[s]), method='DOP853', rtol=1e-12, atol=1e-13, t_eval=[0.1, tau1]) for s in st}
    Y = {s: sol[s].y for s in sol}
    xs = {s: Y[s][:4, -1] for s in Y}; vs = {s: Y[s][4:, -1] for s in Y}
    xi1 = (xs[hs] - xs[-hs]) / (2 * hs); xid1 = (vs[hs] - vs[-hs]) / (2 * hs); xidd1 = (num_acc(M, xs[hs], vs[hs]) - num_acc(M, xs[-hs], vs[-hs])) / (2 * hs)
    D2 = std_D2xi(M, xs[0.], vs[0.], xi1, xid1, xidd1); J = -np.einsum('lsmn,s,m,n->l', num_riem(M, xs[0.]), vs[0.], xi1, vs[0.])
    xit = {tt: (Y[hs][:4, k] - Y[-hs][:4, k]) / (2 * hs) for k, tt in enumerate((0.1, tau1))}
    return A0, np.max(np.abs(D2 - J)) / max(np.max(np.abs(J)), 1e-300), xit

def main():
    head('D4.  geodesic deviation on the step-9/10 engine: D^2 xi/dtau^2 = -R(xi, u) u as a dynamical statement; the point mass (-2, 1, 1) M/rho^3.  n = 4, exact')
    PTS = [((1, 2, 2), 3), ((2, 3, 6), 7), ((4, 4, 7), 9)]
    MS = [F(1), F(-1, 2)]
    def observers(n): return {'rest': [F(1), F(0), F(0), F(0)], 'radial boost': [F(5, 4)] + [F(3, 4) * c for c in n],
                              'non-radial': [F(5, 4), F(1, 2), F(1, 4), F(-1, 2)], 'null': [F(1), F(3, 5), F(4, 5), F(0)]}
    def seps(p, n):
        t1 = [F(p[1]), F(-p[0]), F(0)]; t2 = [F(p[0] * p[2]), F(p[1] * p[2]), F(-(p[0] ** 2 + p[1] ** 2))]
        return {'radial': [F(0)] + list(n), 'transverse 1': [F(0)] + t1, 'transverse 2': [F(0)] + t2, 'generic': [F(1, 3), F(1, 2), F(-1), F(1, 4)]}
    ZERO = [F(0)] * 4; ETA0 = [F(1, 5), F(-1, 3), F(1, 2), F(1, 7)]
    RES = {}; ST = {}
    # ============================================================================== (1) the identity, both conventions, all observers and separations
    for cname, sq in CONV.items():
        t0 = time.time(); head('(1) %s: the relative acceleration of the Taylor-series geodesics equals -R(xi, u) u (exact)' % cname)
        Lie_ = Lie(sq); Gv = Grav(4, Lie_); S = koszul_S(4, sq, Lie_)
        ok_h = ok_eta = ok_sym = ok_std2 = True; ncase = 0; rest_ok = True; rest_dyn = True; radial_poly = True; nonrad_differs = True; up_sign = True; down_sign = True
        for (p, rho0), M in itertools.product(PTS, MS):
            st = ks_setup(Gv, S, p, rho0, M); ST[(cname, p, M)] = st
            n = [F(c, rho0) for c in p]; m = M / F(rho0) ** 3
            g = std_metric(st['e'], 4, sq, 4, 2); R1 = std_riemann(g, 4, 4, 1)[0]
            Rf = frame_Rf(Gv, st['R'], st['E0'])
            for oname, u0 in observers(n).items():
                Et = tidal_from_Rf(Rf, sq, u0)
                for xname, xf in list(seps(p, n).items()) + ([('generic + relative velocity', None)] if oname == 'non-radial' else []):
                    eta0 = ETA0 if xf is None else ZERO; xf = xf or seps(p, n)['generic']
                    xi0c = [sum(st['E0'][mu][a] * xf[a] for a in range(4)) for mu in range(4)]
                    d, u = family(st, xi0c, u0, eta0); A, V0, xi_ser = rel_acc(st, d); ncase += 1
                    xd0 = [sum(st['E0'][mu][a] * u0[a] for a in range(4)) for mu in range(4)]
                    P = predict_h(st, xi0c, xd0, u0); Pe = [-sum(Et[a][c] * xf[c] for c in range(4)) for a in range(4)]
                    ok_h &= (A == P); ok_eta &= (A == Pe)
                    Om_xi = [[F(0)] * 4 for _ in range(4)]
                    for (B, b, c, hv) in st['hl']: Om_xi[c][b] += hv * sum(at0(st['omj'][B][mu], 4) * xi0c[mu] for mu in range(4))
                    ok_sym &= (V0 == [eta0[a] + sum(Om_xi[a][b] * u0[b] for b in range(4)) for a in range(4)])
                    Ac = [-sum(R1[(r, s_, mu, v)] * xd0[s_] * xi0c[mu] * xd0[v] for s_ in range(4) for mu in range(4) for v in range(4)) for r in range(4)]
                    ok_std2 &= (A == [sum(st['e0'][a][r] * Ac[r] for r in range(4)) for a in range(4)])
                    RES[(cname, p, M, oname, xname)] = (A, xi0c, xi_ser)
                    if oname == 'rest':
                        if xname == 'radial': rest_dyn &= (A == [0] + [2 * m * c for c in n])
                        if xname.startswith('transverse'): rest_dyn &= (A == [-m * c for c in xf])
                if oname == 'rest':
                    Es = [[Et[i][j] for j in (1, 2, 3)] for i in (1, 2, 3)]
                    rest_ok &= (Es == [[m * (int(i == j) - 3 * n[i] * n[j]) for j in range(3)] for i in range(3)])
                    up_sign &= all(Rf[(i, 0, j, 0)] == sq[0] * Et[i][j] for i in (1, 2, 3) for j in (1, 2, 3))
                    down_sign &= all(sq[i] * sq[0] * Rf[(i, 0, j, 0)] == sq[i] * Et[i][j] for i in (1, 2, 3) for j in (1, 2, 3))
                cp = charpoly(Et)
                if oname in ('rest', 'radial boost'): radial_poly &= (cp == [1, 0, -3 * m * m, 2 * m ** 3, 0])
                if oname == 'non-radial': nonrad_differs &= (cp != [1, 0, -3 * m * m, 2 * m ** 3, 0])
        chk('bit', ok_h, '%s: A = D^2 xi/dtau^2 (Taylor-series geodesics, connection terms included) equals -R(xi, u) u = -h_{Ab}^c R^A(xi, u) u^b exactly: %d cases (3 non-radial points, M = 1 and -1/2, observers at rest / radially boosted / non-radial / null, 4 separations, one with an initial relative velocity)' % (cname, ncase))
        chk('bit', ok_eta, '%s: the same A equals -E xi with E^a_c = R^a_{bcd} u^b u^d read from the bivector components R^{ab}(E_c, E_d) and eta (two readings of the engine\'s curvature agree)' % cname)
        chk('bit', ok_sym, '%s: torsion-free symmetry along the family: D xi/dtau = D_xi u = eta0 + Omega(xi) u at tau = 0, every case' % cname)
        chk('bit==std', ok_std2, '%s: A equals -R^rho_{sigma mu nu} xdot^sigma xi^mu xdot^nu with the Riemann tensor of g = e^T eta e from Christoffel symbols (b1lib.std_riemann), frame components, every case' % cname)
        chk('bit', rest_ok, '%s: observer at rest in the frame: E^i_j = R^i_{0j0} = (M/rho^3)(delta_ij - 3 n_i n_j) = d_i d_j Phi with Phi = -M/rho, exactly, at every point and mass (n = p/rho)' % cname)
        chk('bit', rest_dyn, '%s: as dynamics: a radial separation accelerates by +2M/rho^3 xi (stretch), a transverse one by -M/rho^3 xi (squeeze): eigenvalues (-2, 1, 1) M/rho^3 of E, read off the Taylor-series geodesics' % cname)
        chk('bit', radial_poly, '%s: observer at rest and radially boosted (5/4, 3/4 n): det(lambda - E(u)) = lambda^4 - 3 m^2 lambda^2 + 2 m^3 lambda, m = M/rho^3: the pattern (0; -2, 1, 1) m does not change under a radial boost' % cname)
        chk('bit', nonrad_differs, '%s: the non-radial observer (5/4, 1/2, 1/4, -1/2) has a different characteristic polynomial (the tidal pattern depends on the observer; the identity does not)' % cname)
        chk('bit', up_sign and down_sign, '%s: sign convention: R^{i0}_{j0} (both up) = %s E^i_j and R_{i0j0} (both down) = %s E^i_j' % (cname, '+' if sq[0] == 1 else '-', '-' if sq[1] == -1 else '+'))
        print('    time (1, %s): %.1f s' % (cname, time.time() - t0))
    cn = list(CONV)
    chk('bit', all(RES[(cn[0],) + k[1:]][0] == RES[k][0] for k in RES if k[0] == cn[1]), 'the relative accelerations are identical in the two sign conventions (every case): the dynamical statement does not depend on the convention')
    # ============================================================================== (2) controls
    t0 = time.time(); head('(2) controls: omega -> 0; wrong index orders; -omega in the geodesic equation only; -omega everywhere in the dynamics; the Newtonian sign')
    sq = CONV[cn[0]]; c_om0 = c_om0b = c_idx1 = c_idx2 = c_flip = c_flipall = c_newt = True; torsion_dev = 0; nctl = 0
    for (p, rho0), M in itertools.product(PTS, MS):
        st = ST[(cn[0], p, M)]; n = [F(c, rho0) for c in p]; m = M / F(rho0) ** 3; Rf = frame_Rf(st['Gv'], st['R'], st['E0']); u0 = [F(1), F(0), F(0), F(0)]
        Et = tidal_from_Rf(Rf, sq, u0); Ew2 = tidal_from_Rf(Rf, sq, u0, swap=True)
        for xname, xf in seps(p, n).items():
            A, xi0c, _ = RES[(cn[0], p, M, 'rest', xname)]; nctl += 1
            d0, _ = family(st, xi0c, u0, ZERO, zero_om=True); A0 = rel_acc(st, d0, zero_om=True)[0]
            c_om0 &= (A0 != A); torsion_dev += any(A0)
            c_om0b &= any(A)                                                     # the omega = 0 prediction (R = 0, no deviation) misses a non-zero deviation
            c_idx1 &= (A != [-sum(Rf.get((a, c, 0, 0), 0) * xf[c] for c in range(4)) for a in range(4)])
            c_idx2 &= (A != [-sum(Ew2[a][c] * xf[c] for c in range(4)) for a in range(4)])
            xd0 = [sum(st['E0'][mu][a] * u0[a] for a in range(4)) for mu in range(4)]; P = predict_h(st, xi0c, xd0, u0)
            df, _ = family(st, xi0c, u0, ZERO, sg=-1); c_flip &= (rel_acc(st, df)[0] != P)
            c_flipall &= (rel_acc(st, df, sgD=-1)[0] != P)
        c_newt &= ([[Et[i][j] for j in (1, 2, 3)] for i in (1, 2, 3)] != [[-m * (int(i == j) - 3 * n[i] * n[j]) for j in range(3)] for i in range(3)])
    chk('ctl', c_om0, 'control omega -> 0: the omega = 0 autoparallels (fixed frame components) do not reproduce the deviation in any of %d cases; their relative acceleration is non-zero in %d of them although the curvature of omega = 0 is zero (the omega = 0 connection has torsion: the identity needs T = 0)' % (nctl, torsion_dev))
    chk('ctl', c_om0b, 'control omega -> 0: "no deviation" (the prediction of R = 0) is wrong for the true geodesics in every case: the deviation comes from omega')
    chk('ctl', c_idx1, 'control: the wrong index order R^{ij}_{00} (identically 0) does not give the relative acceleration')
    chk('ctl', c_idx2, 'control: the wrong index order R^a_{bdc} u^b u^d (= -E) does not give it')
    chk('ctl', c_flip, 'control: -omega in the geodesic equation only (D and R kept): the identity fails in every case')
    chk('ctl', c_flipall, 'control: -omega in the geodesic equation and in D (R kept): the identity fails in every case (the in-script twin of M4 / M7)')
    chk('ctl', c_newt, 'control: E = -d_i d_j Phi (the other sign of the Newtonian limit) fails at every point and mass')
    Gv = ST[(cn[0], PTS[0][0], MS[0])]['Gv']; S = koszul_S(4, sq, Gv.L); rels = {}
    for Mw in (F(1, 1000), F(1, 10000)):
        st = ks_setup(Gv, S, PTS[0][0], PTS[0][1], Mw); n = [F(c, 3) for c in PTS[0][0]]; worst = 0.0
        for xname, xf in list(seps(PTS[0][0], n).items())[:3]:
            u0 = [F(1), F(0), F(0), F(0)]; xi0c = [sum(st['E0'][mu][a] * xf[a] for a in range(4)) for mu in range(4)]
            A = rel_acc(st, family(st, xi0c, u0, ZERO)[0])[0]; Af = rel_acc(st, family(st, xi0c, u0, ZERO, sg=-1)[0])[0]
            worst = max(worst, float(max(abs(x + y) for x, y in zip(A, Af)) / max(abs(x) for x in A)))
        rels[Mw] = worst
    r1, r2 = rels[F(1, 1000)], rels[F(1, 10000)]
    chk('bit', r1 < 0.01 and 5 < r1 / r2 < 20, 'weak field (rho = 3, observer at rest, radial and transverse separations): with -omega in the geodesic equation only, A_flip = -A + O(M^2): max |A_flip + A|/|A| = %.2e at M = 1/1000 and %.2e at M = 1/10000: the deviation reverses its sign at the Newtonian order (the sign of omega seen in a second-order quantity)' % (r1, r2))
    stz = ks_setup(Gv, S, PTS[1][0], PTS[1][1], 0); u0 = [F(5, 4), F(1, 2), F(1, 4), F(-1, 2)]; xf = [F(1, 3), F(1, 2), F(-1), F(1, 4)]
    xi0c = [sum(stz['E0'][mu][a] * xf[a] for a in range(4)) for mu in range(4)]
    chk('bit', rel_acc(stz, family(stz, xi0c, u0, ETA0)[0])[0] == ZERO, 'M = 0 (flat frame, omega = 0, R = 0): the relative acceleration is exactly 0 (moving observer, generic separation, initial relative velocity)')
    print('    time (2): %.1f s' % (time.time() - t0))
    # ============================================================================== (3) numerical integration [std]
    t0 = time.time(); head('(3) [std] numerical geodesics of the closed-form Kerr-Schild metric (scipy DOP853, rtol 1e-12), difference quotient in s (1e-4), standard covariant derivative')
    err0 = 0.0; errJ = 0.0; ratios = []; nstd = 0
    for (p, rho0) in PTS:
        n = [F(c, rho0) for c in p]
        for oname in ('rest', 'non-radial', 'null'):
            for xname in ('radial', 'generic'):
                A, xi0c, xi_ser = RES[(cn[0], p, F(1), oname, xname)]
                A0, rJ, xit = std_case(1.0, p, observers(n)[oname], seps(p, n)[xname]); nstd += 1
                Af = np.array([float(x) for x in A]); err0 = max(err0, np.max(np.abs(A0 - Af)) / np.max(np.abs(Af))); errJ = max(errJ, rJ)
                coef = [[float(xi_ser[m].get((k, 0), 0)) for k in range(3)] for m in range(4)]
                res = {tt: np.max(np.abs(xit[tt] - np.array([c[0] + c[1] * tt + c[2] * tt * tt for c in coef]))) for tt in xit}
                ratios.append(res[0.2] / res[0.1])
    chk('bit==std', err0 < 1e-6, 'at tau = 0 the numerical relative acceleration (difference quotient of the geodesic equation of the closed-form metric, standard covariant second derivative, frame components) equals the engine\'s exact A: max relative difference %.1e over %d cases (M = 1, observers at rest / non-radial / null)' % (err0, nstd))
    chk('std', errJ < 1e-5, 'after integrating to tau = 0.2 the [std] Jacobi identity D^2 xi = -R(xi, u) u holds along the numerical geodesics (numerical Riemann from Christoffel symbols): max relative residual %.1e' % errJ)
    chk('bit==std', all(6 < r < 10 for r in ratios), 'the engine\'s Taylor polynomial of xi^mu(tau) (degree 2, exact) differs from the integrated separation by O(tau^3): residual ratio between tau = 0.2 and 0.1 in [%.2f, %.2f] (8 for a cubic remainder; 4 would mean a wrong acceleration)' % (min(ratios), max(ratios)))
    print('    time (3): %.1f s' % (time.time() - t0))
    head('export: tidal_tensor(Gv, e, S, u) -> E^a_c = R^a_{bcd} u^b u^d (mixed, convention-independent; relative acceleration -E xi); tidal_tensor_point_mass(p, rho0, M) -> (M/rho^3)(delta - 3 n n) for the observer at rest in the frame')
    Ex = tidal_tensor_point_mass((1, 2, 2), 3, 1)
    chk('bit', Ex == [[F(1, 27) * (int(i == j) - 3 * F((1, 2, 2)[i] * (1, 2, 2)[j], 9)) for j in range(3)] for i in range(3)], 'export check: tidal_tensor_point_mass((1, 2, 2), 3, 1) = (1/27)(delta - 3 n n) with n = (1, 2, 2)/3')
    finish('D4')

if __name__ == '__main__': main()
