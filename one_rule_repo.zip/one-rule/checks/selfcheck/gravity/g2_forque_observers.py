#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""G2-observers. The covariant derivatives of the tidal tensor for other observers: whose factor is 1 - M/r.   python3 g2_forque_observers.py

The tidal field E'_ab = R(E'_a, u, E'_b, u) of an observer field u near a static point mass M (Phi = -M/r), and its covariant derivatives
nabla E', nabla nabla E', nabla^3 E', for observers built as local Lorentz boosts Lambda(x) of the Kerr-Schild frame e^a = dx^a - f l^a l_mu dx^mu
(f = M/r, l = dt + dr): the Kerr-Schild observer U = E_0 itself (the identity boost), the static observer d_t/sqrt(1 - 2M/r), the radial free fall
from rest at infinity (u^t = (1 - 2f sqrt(2f))/(1 - 2f), u^i = -sqrt(2f) n^i), the radial geodesic momentarily at rest in the Kerr-Schild frame
(released from rest at r_0 = 2r/(2 - M/r)), a transverse boost of speed 3/5 along a unit field m(x) orthogonal to n, and, as a control, the static
observer's boost with the wrong sign of the velocity.  The points R = (3,4,0) and (2,3,6) with 2M/r = 9/25 at both (sqrt(2M/r) = 3/5 and
sqrt(1 - 2M/r) = 4/5 rational: every velocity and Lorentz factor is rational at the point and an exact jet around it).
[bit]  Kerr-Schild coframe as exact 5-jets; the boost rotor U = 1 + beta(x) gamma_0 d(x) (d = n or m) multiplied by the bit rule, Lambda^a_b gamma_a =
       U gamma_b U~/(U U~); e' = Lambda e; omega (A3 closed form) recomputed from e'; R = d omega + 1/4 [omega, omega]; the tidal field E'^a_c(x) =
       R^{a0}_{c0}(x) of the boosted frame (3-jets); (C) its covariant derivatives by the engine's D_covector slot by slot (D_tensor), frame components
       along E'_k; (P) the coordinate derivatives of E'^i_j(x); (V) the derivatives along E'_k without connection terms.  The other reading at the
       Kerr-Schild observer: (nabla^q R)(., u, ., u) with u = E_0 held fixed, the engine's covariant derivative of the four-index curvature contracted
       after differentiating.  The bookkeeping run f -> lam^2 f with every product cut at lam^9: the lam^2 part is first order in M, lam^4 second, ...
[std]  Lambda^T eta Lambda = eta and Lambda = (gamma, -gamma v d; -gamma v d, delta + (gamma - 1) d d) with plain jets; the observers' coordinate
       4-velocities (closed forms above); the Christoffel route of g = eta - 2 f l l (Christoffel symbols, Riemann tensor, covariant derivatives in
       coordinates, E^r_m = R^r_{s m v} u^s u^v, frame components with the boosted frame at the point); the exact Taylor coefficients of Phi;
       the closed form (nabla_k E')^i_j = Ecal(u) Phi_,ijk with Ecal(u) = g(u, d_t) the observer's energy per unit mass.
What the checks state: for every radial observer E'^i_j(x) = Phi_,ij(x) as a jet (the boost in the (E_0, E_n) plane leaves the type D curvature
unchanged), so the coordinate derivatives are Phi's to every order and do not depend on the observer; the engine's covariant derivatives equal the
Christoffel route for every observer; at first order (nabla_k E')^i_j = Ecal(u) Phi_,ijk exactly: 1 - M/r for the Kerr-Schild observer and for the
geodesic momentarily at rest in that frame, sqrt(1 - 2M/r) for the static observer, 1 for the free fall from rest at infinity (its spatial slices are
flat: nabla E' = dE' exactly, the connection terms vanish in the spatial components); the second and third derivatives carry terms beyond first
order in M for every observer (listed as exact fits on the basis Sym(n^j), Sym(delta n^(j-2)), Sym(delta delta n^(j-4)) from the lam run); the
transverse boost changes E' itself; the two readings of the covariant derivative agree on the spatial components at first order and differ beyond.
The bodies of G2 (16) contracted with the derivatives: the force at eps^2 and the torque at eps^3 are Ecal(u) times the summed force lines'
(exactly the lines for the free fall); the force at eps^3 and the eps^4 terms miss the lines for every observer.
Controls: wrong Taylor factors; the repulsive sign; the wrong-sign boost changes the factor; the partial derivative instead of the covariant one;
the Christoffel route without its Christoffel terms; the identity boost reproduces the Kerr-Schild results; centrally symmetric bodies (eps^3 zero,
eps^4 not); the reading identity without its nabla u terms; the rotor with 2 beta is not the intended observer.
Scope: a static point mass, two points with 2M/r = 9/25, frame 5-jets, orders eps^2..eps^4, Newton's law by input (INP-075), the sign of the
source fixed by attraction.  No equation of motion of an extended body in general relativity is claimed.
Command line: python3 g2_forque_observers.py [NPOINTS]; the optional integer runs the first NPOINTS points only (1: the first point, without the
checks that the fits made there hold at the second; the engine-fault table is run that way to keep it short).
Exports (import-safe): pow_jet, binom_jet, ks_base, build_observer, boost_lambda, engine_derivs, engine_reading2, std_geometry, std_derivs, fit_basis."""
import sys, os, time, itertools
from math import factorial, isqrt
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
from fractions import Fraction as F
import g2_tidal_forque as G2T
import g2_hodge as GH
import g2_forque_fourth as GF
from g2_forque_fourth import D_tensor, tidal_field, frame_comp, sym, nd_basis, forque_terms, g2_bodies, dcoef, at_pt, COEF

SQ = [1, -1, -1, -1]
KJ = 5                                                                           # jet order of the frame: E' to degree 3, nabla^3 E' at the point
LAMCUT = 9                                                                       # cut of the bookkeeping parameter (f -> lam^2 f)
Q2 = F(9, 25)                                                                    # 2M/r at both points
POINTS = [((F(3), F(4), F(0)), F(5), (F(0), F(0), F(1))), ((F(2), F(3), F(6)), F(7), (F(3, 7), F(-6, 7), F(2, 7)))]   # (R, |R|, e for the transverse boost)
OBS = [('ks', 'Kerr-Schild observer (identity boost)'), ('a', 'static observer'), ('b', 'free fall from rest at infinity'),
       ('c', 'geodesic momentarily at rest in the Kerr-Schild frame'), ('d', 'transverse boost, speed 3/5'), ('w', 'static boost with the wrong sign of v (control)')]
RADIAL = ('ks', 'a', 'b', 'c', 'w'); LAMRUN = ('ks', 'a', 'b', 'd')
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
EPS3 = G2T.EPS3

# ------------------------------------------------------------------------------------------------ jets with rational square roots
def rat_sqrt(q):
    q = F(q); a, b = isqrt(q.numerator), isqrt(q.denominator)
    if a * a != q.numerator or b * b != q.denominator: raise ValueError('not a rational square: %s' % q)
    return F(a, b)
def binom_jet(u, al, nv, mul):
    """(1 + u)^al for a jet u without constant term: sum_k binom(al, k) u^k (the product mul cuts the degrees, so the sum ends)"""
    out = const(nv, 1); term = const(nv, 1); coef = F(1); k = 0
    while True:
        k += 1; coef = coef * (al - k + 1) / k; term = mul(term, u)
        if not term: return out
        out = padd(out, term, coef)
def pow_jet(w, al, nv, mul):
    """w^al for a jet w whose constant term w0 has a rational w0^al (al = +-1/2 needs a rational square root)"""
    w0 = at0(w, nv); al = F(al)
    r0 = (rat_sqrt(w0) if al.denominator == 2 else w0) ** (al.numerator if al.denominator == 2 else al)
    u = scale(padd(w, const(nv, w0), -1), 1 / w0)
    return scale(binom_jet(u, al, nv, mul), r0)
def jet_cut(p, deg): return {k: v for k, v in p.items() if sum(k[:4]) <= deg}
def om_cut(om, deg): return [{m: q for m, p in form.items() for q in [jet_cut(p, deg)] if q} for form in om]

# ------------------------------------------------------------------------------------------------ the Kerr-Schild data and the observers (jets)
def ks_base(p, rho0, Mc, nv, lam):
    """f, n, l, g = eta - 2 f l l, U = E_0 and the coframe e^a = dx^a - f l^a l_mu dx^mu as exact KJ-jets at p (|p| = rho0); with lam: f -> lam^2 f
    (slot 4 = lam, products cut by the active trunc).  Products through b1lib.pm."""
    p = [F(x) for x in p]; rho0 = F(rho0)
    rinv = GH.rho_pow_jet(p, rho0, -1, KJ, nv); fx = scale(rinv, F(Mc))
    lam2 = pm(var(nv, 4), var(nv, 4)) if lam is not None else const(nv, 1); lam1 = var(nv, 4) if lam is not None else const(nv, 1)
    f = pm(fx, lam2) if lam is not None else fx
    nh = [pm(lin((F(1), const(nv, p[i])), (F(1), var(nv, i + 1))), rinv) for i in range(3)]
    l_up = [const(nv, 1)] + [scale(x, -1) for x in nh]; l_dn = [const(nv, 1)] + nh
    g = {(m, v): padd(const(nv, SQ[m] if m == v else 0), pm(pm(f, l_dn[m]), l_dn[v]), -2) for m in range(4) for v in range(4)}
    U = [padd(const(nv, 1 if mu == 0 else 0), pm(f, l_up[mu])) for mu in range(4)]
    e = []
    for a in range(4):
        form = {}
        for mu in range(4):
            pol = padd(const(nv, 1 if a == mu else 0), pm(pm(f, l_up[a]), l_dn[mu]), -1)
            if pol: form[1 << mu] = pol
        e.append(form)
    return dict(f=f, fx=fx, nh=nh, l_up=l_up, l_dn=l_dn, g=g, U=U, e=e, nv=nv, lam=lam, lam1=lam1, Mc=F(Mc), rho0=rho0, f0=F(Mc) / rho0)
def observer_velocity(key, B, evec):
    """[std] the coordinate 4-velocity u^mu(x) of the observer as jets (closed forms in the Kerr-Schild chart), and the boost direction field d (n or m)"""
    nv, f, nh, U, mul = B['nv'], B['f'], B['nh'], B['U'], pm
    one = const(nv, 1); fx = B['fx']
    if key == 'ks': return list(U), nh
    if key == 'a':
        ut = pow_jet(padd(one, f, -2), F(-1, 2), nv, mul); return [ut, {}, {}, {}], nh
    if key == 'b':
        s = mul(pow_jet(scale(fx, 2), F(1, 2), nv, mul), B['lam1'])                            # sqrt(2f) (with lam: lam sqrt(2 f))
        inv = pow_jet(padd(one, f, -2), -1, nv, mul); ut = mul(padd(one, mul(f, s), -2), inv)
        return [ut] + [scale(mul(s, nh[i]), -1) for i in range(3)], nh
    if key == 'c':
        E0 = 1 - B['f0']; w = pow_jet(padd(scale(f, 2), const(nv, E0 * E0 - 1)), F(1, 2), nv, mul)
        inv = pow_jet(padd(one, f, -2), -1, nv, mul); ut = mul(padd(const(nv, E0), mul(f, w), -2), inv)
        return [ut] + [scale(mul(w, nh[i]), -1) for i in range(3)], nh
    if key == 'd':
        gam, v = F(5, 4), F(3, 5); en = lin(*[(F(evec[i]), nh[i]) for i in range(3)])
        Ninv = pow_jet(padd(one, mul(en, en), -1), F(-1, 2), nv, mul)
        m = [mul(padd(const(nv, evec[i]), mul(en, nh[i]), -1), Ninv) for i in range(3)]
        return [scale(U[0], gam)] + [scale(padd(U[i + 1], m[i], v), gam) for i in range(3)], m
    if key == 'w':                                                                               # gamma (U - v E_n), v = f/(1 - f): the wrong sign
        inv1 = pow_jet(padd(one, f, -1), -1, nv, mul); v = mul(f, inv1); gam = mul(padd(one, f, -1), pow_jet(padd(one, f, -2), F(-1, 2), nv, mul))
        En = [mul(f, B['l_up'][mu]) for mu in range(4)]
        for i in range(3): En[i + 1] = padd(En[i + 1], nh[i])
        return [mul(gam, padd(U[mu], mul(v, En[mu]), -1)) for mu in range(4)], nh
def mv_mul(X, Y):
    """bit-rule product of multivectors {blade mask: jet} (coefficients through b1lib.pm: the active trunc cuts the products)"""
    out = {}
    for m1, p1 in X.items():
        for m2, p2 in Y.items():
            m, s = bmul(m1, m2, SQ)
            if s == 0: continue
            q = padd(out.get(m, {}), pm(p1, p2), s)
            if q: out[m] = q
            else: out.pop(m, None)
    return out
def boost_lambda(beta, dvec, nv):
    """[bit] Lambda^a_b gamma_a = U gamma_b U~ / (U U~), U = 1 + beta(x) gamma_0 (d^i(x) gamma_i), by the bit rule.  Returns (Lambda jets, grades ok)"""
    one = const(nv, 1); Ur = {0: one}; Ut = {0: one}
    for i in range(3):
        c = pm(beta, dvec[i])
        if c: Ur[1 | (1 << (i + 1))] = c; Ut[1 | (1 << (i + 1))] = scale(c, -1)
    N = mv_mul(Ur, Ut); ok = set(N) <= {0}; invN = pow_jet(N[0], -1, nv, pm)
    L = [[{} for _ in range(4)] for _ in range(4)]
    for b in range(4):
        V = mv_mul(mv_mul(Ur, {1 << b: one}), Ut); ok &= all(popc(m) == 1 for m in V)
        for a in range(4):
            if V.get(1 << a): L[a][b] = pm(V[1 << a], invN)
    return L, ok
def rotate(L, e):
    """e'^a = Lambda^a_b e^b"""
    out = []
    for a in range(4):
        form = {}
        for mu in range(4):
            t = {}
            for b in range(4):
                p = e[b].get(1 << mu, {})
                if L[a][b] and p: t = padd(t, pm(L[a][b], p))
            if t: form[1 << mu] = t
        out.append(form)
    return out
def build_observer(key, B, evec, beta_scale=1):
    """the observer: u (jets), d, gamma = g(U, u), gamma v = -g(E_d, u), beta = gamma v/(1 + gamma), Lambda by the rotor [bit] and the matrix form [std],
    the boosted coframe e' = Lambda e, and Ecal = g(u, d_t) at the point (the energy per unit mass).  beta_scale != 1: a wrong rotor (control)."""
    nv, g, U, f = B['nv'], B['g'], B['U'], B['f']; one = const(nv, 1)
    u, d = observer_velocity(key, B, evec)
    Ed = [lin(*[(F(1), pm(d[i], pm(f, pm(B['l_up'][mu], B['l_dn'][i + 1])))) for i in range(3)]) for mu in range(4)]   # d^i E_i = d^i (delta^mu_i + f l^mu l_i)
    for i in range(3): Ed[i + 1] = padd(Ed[i + 1], d[i])
    gam = lin(*[(F(1), pm(g[(m, v)], pm(U[m], u[v]))) for m in range(4) for v in range(4)])
    gv = scale(lin(*[(F(1), pm(g[(m, v)], pm(Ed[m], u[v]))) for m in range(4) for v in range(4)]), -1)
    beta = scale(pm(gv, pow_jet(padd(one, gam), -1, nv, pm)), beta_scale)
    Lb, grades = boost_lambda(beta, d, nv)
    Ls = [[{} for _ in range(4)] for _ in range(4)]; Ls[0][0] = gam
    for i in range(3):
        Ls[0][i + 1] = scale(pm(gv, d[i]), -1); Ls[i + 1][0] = Ls[0][i + 1]
        for j in range(3): Ls[i + 1][j + 1] = padd(const(nv, 1 if i == j else 0), pm(padd(gam, one, -1), pm(d[i], d[j])))
    Ecal = sum(at0(g[(0, m)], nv) * at0(u[m], nv) for m in range(4))
    return dict(key=key, u=u, d=d, gam=gam, gv=gv, beta=beta, Lb=Lb, Ls=Ls, grades=grades, e=rotate(Lb, B['e']), Ecal=Ecal,
                gam0=at0(gam, nv), v0=(at0(gv, nv) / at0(gam, nv)), d0=[at0(x, nv) for x in d])
def lorentz_ok(L, nv):
    """[std] Lambda^T eta Lambda = eta as jets (plain products)"""
    for b in range(4):
        for c in range(4):
            t = const(nv, -SQ[b]) if b == c else {}
            for a in range(4):
                if L[a][b] and L[a][c]: t = padd(t, sp_mul(L[a][b], L[a][c], KJ, 4), SQ[a])
            if any(v != 0 for v in t.values()): return False
    return True

# ------------------------------------------------------------------------------------------------ [bit] the engine on a coframe
def engine_derivs(e, nv, lam=None):
    """omega (A3 closed form), R (engine), inverse coframe (series), the tidal field E'^a_c (3-jets) and T[q][(a, c, k1..kq)] = (nabla_kq .. nabla_k1 E')_ac
    (all frame indices down, jets of degree KJ-2-q), V[(a, c, k)] = E'_k(E'_ac).  lam = L: products cut at lam^L (slot 4)."""
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    with trunc(4, xdeg=KJ, lam=lam):
        om = omega_closed_form(Gv, e, S, nv, KJ - 1)[0]
        with trunc(4, xdeg=KJ - 1): Einv, det = inverse_series(frame_matrix(e, 4), 4, nv, KJ - 1)
        with trunc(4, xdeg=KJ - 2): R = Gv.curvature(om); Et = tidal_field(Gv, R, Einv)
        El = {(a, c): scale(q, SQ[a]) for (a, c), q in Et.items()}
        T = {0: El}; cur = El; V = None
        for q in range(1, KJ - 1):
            deg = KJ - 2 - q
            with trunc(4, xdeg=deg):
                DT = D_tensor(Gv, om_cut(om, deg), cur, q + 1)
                if q == 1: V = {(a, c, k): frame_comp(Fm.d({0: El[(a, c)]}), Einv, k) for (a, c) in El for k in range(4)}
                cur = {ix + (k,): frame_comp(X, Einv, k) for ix, X in DT.items() for k in range(4)}
                cur = {ix: v for ix, v in cur.items() if v}
            T[q] = cur
    return dict(T=T, Et=Et, V=V, om=om, R=R, Einv=Einv, Gv=Gv, nv=nv, lam=lam)
def engine_reading2(dat, maxq):
    """the other reading: W[q][(a, c, k1..kq)] = (nabla_kq .. nabla_k1 R)_{a 0 c 0}: the engine's covariant derivative of the four-index curvature
    (frame components, all down), contracted with E_0 after differentiating.  Also returns the omega^b_0 1-forms (nabla E_0 = omega^b_0 E_b)."""
    Gv, om, R, Einv, nv, lam = dat['Gv'], dat['om'], dat['R'], dat['Einv'], dat['nv'], dat['lam']
    with trunc(4, xdeg=KJ, lam=lam):
        with trunc(4, xdeg=KJ - 2):
            Rl = {}
            for A, (a, b) in enumerate(pairs_of(Gv.L)):
                for c in range(4):
                    for d in range(c + 1, 4):
                        t = {}
                        for mu in range(4):
                            for nu in range(mu + 1, 4):
                                q = R[A].get((1 << mu) | (1 << nu), {})
                                if q: t = padd(t, pm(q, padd(pm(Einv[mu][c], Einv[nu][d]), pm(Einv[nu][c], Einv[mu][d]), -1)))
                        if t:
                            t = scale(t, SQ[a] * SQ[b]); Rl[(a, b, c, d)] = t; Rl[(b, a, c, d)] = scale(t, -1); Rl[(a, b, d, c)] = scale(t, -1); Rl[(b, a, d, c)] = t
        out = {0: Rl}; cur = Rl
        for q in range(1, maxq + 1):
            deg = KJ - 2 - q
            with trunc(4, xdeg=deg):
                DT = D_tensor(Gv, om_cut(om, deg), cur, q + 3)
                cur = {ix + (k,): frame_comp(X, Einv, k) for ix, X in DT.items() for k in range(4)}
                cur = {ix: v for ix, v in cur.items() if v}
            out[q] = cur
        om0 = [{} for _ in range(4)]
        for (A, a), (b, h) in Gv.L.h.items():
            if a == 0: om0[b] = Gv.Fm.add(om0[b], om[A], h)
    W = {q: {(ix[0], ix[2]) + ix[4:]: v for ix, v in out[q].items() if ix[1] == 0 and ix[3] == 0} for q in out}
    return W, out, om0

# ------------------------------------------------------------------------------------------------ [std] the Christoffel route (no engine)
def std_geometry(p, rho0, Mc):
    """metric g = eta - 2 f l l as exact KJ-jets at p, Christoffel symbols and the Riemann tensor (MTW sign) as jets"""
    n = 4; nv = 4; D = KJ; P = [F(x) for x in p]; rho0 = F(rho0); Mc = F(Mc)
    rinv = GH.rho_pow_jet(P, rho0, -1, D, nv); f = scale(rinv, Mc)
    nh = [sp_mul(lin((F(1), const(nv, P[i])), (F(1), var(nv, i + 1))), rinv, D, n) for i in range(3)]
    l_dn = [const(nv, 1)] + nh
    g = {(m, v): sp_add(const(nv, SQ[m] if m == v else 0), sp_mul(sp_mul(f, l_dn[m], D, n), l_dn[v], D, n), -2) for m in range(n) for v in range(n)}
    gi, g0, g0i = std_inverse_metric(g, n, nv, D - 1)
    dg = {(k, a, b): sp_der(g[(a, b)], k) for k in range(n) for a in range(n) for b in range(n)}
    Gam = {}
    for l in range(n):
        for m in range(n):
            for v in range(m, n):
                t = {}
                for s in range(n):
                    br = sp_add(sp_add(dg[(m, s, v)], dg[(v, s, m)]), dg[(s, m, v)], -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, D - 1, n), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    Riem = {}
    for r in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(m + 1, n):
                    t = sp_add(sp_der(Gam[(r, v, s)], m), sp_der(Gam[(r, m, s)], v), -1)
                    for l in range(n):
                        t = sp_add(t, sp_mul(Gam[(r, m, l)], Gam[(l, v, s)], D - 2, n)); t = sp_add(t, sp_mul(Gam[(r, v, l)], Gam[(l, m, s)], D - 2, n), -1)
                    t = {k: c for k, c in t.items() if sum(k) <= D - 2}
                    Riem[(r, s, m, v)] = t; Riem[(r, s, v, m)] = scale(t, -1)
    f0 = Mc / rho0; nn = [x / rho0 for x in P]; lu = [F(1)] + [-x for x in nn]; ld = [F(1)] + nn
    e0 = [[F(int(a == mu)) - f0 * lu[a] * ld[mu] for mu in range(n)] for a in range(n)]
    return dict(Gam=Gam, Riem=Riem, g=g, e0=e0, f=f)
def std_derivs(geo, u, e0, drop_gamma=False):
    """E^r_m = R^r_{s m v} u^s u^v and its covariant derivatives in coordinates (each new index appended), frame components at the point with the
    coframe e0[a][mu] (first index up): X[q][(a, c, k1..kq)].  drop_gamma: the Christoffel terms left out (control)."""
    n = 4; nv = 4; D = KJ; Gam, Riem = geo['Gam'], geo['Riem']; det, E0 = det_inv(e0)
    cur = {}
    for r in range(n):
        for m in range(n):
            t = {}
            for s in range(n):
                for v in range(n):
                    q = Riem.get((r, s, m, v))
                    if q and u[s] and u[v]: t = sp_add(t, sp_mul(sp_mul(q, u[s], D - 2, n), u[v], D - 2, n))
            if t: cur[(r, m)] = t
    out = {0: GF._to_frame({ix: at0(v, nv) for ix, v in cur.items()}, e0, E0)}; deg = D - 2
    for q in range(1, D - 1):
        deg -= 1; new = {}
        for ix in itertools.product(range(n), repeat=q + 1):
            for b in range(n):
                t = {k: c for k, c in sp_der(cur.get(ix, {}), b).items() if sum(k) <= deg}
                if not drop_gamma:
                    for l in range(n):
                        G_, w = Gam[(ix[0], b, l)], cur.get((l,) + ix[1:])
                        if G_ and w: t = sp_add(t, sp_mul(G_, w, deg, n))
                    for j in range(1, len(ix)):
                        for l in range(n):
                            G_, w = Gam[(l, b, ix[j])], cur.get(ix[:j] + (l,) + ix[j + 1:])
                            if G_ and w: t = sp_add(t, sp_mul(G_, w, deg, n), -1)
                if t: new[ix + (b,)] = t
        cur = new; out[q] = GF._to_frame({ix: at0(v, nv) for ix, v in cur.items()}, e0, E0)
    return out

# ------------------------------------------------------------------------------------------------ reading the tensors
def spatial(Tq, q, nv=4, L=None):
    """the spatial frame components with the first index raised: {(i, j, k..): value} at the point (coefficient of lam^L when L is given)"""
    get = (lambda v: at0(v, nv)) if L is None else (lambda v: at_pt(v, 5, L))
    return {ix: -get(Tq.get(tuple(c + 1 for c in ix), {})) for ix in itertools.product(range(3), repeat=q + 2)}
def mixed_at(Tq, nv=4):
    return {ix: SQ[ix[0]] * at0(v, nv) for ix, v in Tq.items() if at0(v, nv) != 0}
def fit_basis(part, n, j, unit):
    """exact fit of a symmetric rank-j array on Sym(delta^a n^(j-2a)) in the given unit: the coefficients, or None if no exact fit exists"""
    B = nd_basis(n, j); keys = sorted(part)
    w, rank, nvar, cons = solve_exact([[b[ix] * unit for b in B] for ix in keys], [part[ix] for ix in keys])
    return tuple(w) if cons else None
def lam_parts(T, q):
    """{lam degree: {index: coefficient}} of the engine tensor T[q] (lam run), all frame components, first index raised"""
    out = {}
    for ix, v in T[q].items():
        for L in range(LAMCUT + 1):
            c = at_pt(v, 5, L)
            if c != 0: out.setdefault(L, {})[ix] = SQ[ix[0]] * c
    return out

def main():
    import d4_deviation as D4
    A = G2T.PG.Alg(3); read = G2T.readoff(A, 1); BOD = g2_bodies(); FIT = {}; FIT2 = {}; TABLE = {}
    npts = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else len(POINTS); npts = max(1, min(npts, len(POINTS)))
    head('0. Observers as local boosts Lambda(x) of the Kerr-Schild frame; 2M/r = 9/25 at both points; frame jets to degree %d; bookkeeping f -> lam^2 f cut at lam^%d; points run: %d of %d' % (KJ, LAMCUT, npts, len(POINTS)))
    for ip, (R, rho, evec) in enumerate(POINTS[:npts]):
        Ri = [int(c) for c in R]; n = [c / rho for c in R]; Mc = Q2 * rho / 2; f0 = Mc / rho
        head('1.%d  R = %s, M = %s (M/r = %s): the observers, the engine, the Christoffel route, the closed forms' % (ip + 1, Ri, Mc, f0))
        with trunc(4, xdeg=KJ): B = ks_base(R, rho, Mc, 4, None)
        with trunc(4, xdeg=KJ, lam=LAMCUT): BL = ks_base(R, rho, Mc, 5, LAMCUT)
        import h5l_frames as HF
        eH = HF.ks_frame_jetK(list(R), rho, M=Mc, order=KJ)
        chk('bit', all(B['e'][a].get(1 << mu, {}) == eH[a].get(1 << mu, {}) for a in range(4) for mu in range(4)), 'R = %s: the coframe built here equals h5l_frames.ks_frame_jetK (5-jets)' % Ri)
        geo = std_geometry(R, rho, Mc); Tay = G2T.phi_taylor(list(R), rho, Mc, KJ)
        PHI = {j: {ix: G2T.phi_deriv(Tay, ix) for ix in itertools.product(range(3), repeat=j)} for j in (2, 3, 4, 5)}
        Eg2 = [[F(x) for x in r] for r in D4.tidal_tensor_point_mass(tuple(R), rho, Mc)]
        chk('bit==std', PHI[2] == {(i, j): Eg2[i][j] for i in range(3) for j in range(3)}, 'R = %s: Phi_,ij of the Taylor coefficients = the engine\'s tidal tensor at the point (d4_deviation.tidal_tensor_point_mass) at M = %s' % (Ri, Mc))
        lines = {}
        for name, body in BOD[ip]:
            Fe, te = G2T.eps_forque(A, R, rho, body, Mc, 1, read)
            lines[name] = {k: ([G2T.scoef(Fe[i], k) for i in range(3)], [G2T.scoef(te[i], k) for i in range(3)]) for k in (2, 3, 4)}
        tick('geometry, lines')
        RES = {}
        for key, label in OBS:
            with trunc(4, xdeg=KJ): ob = build_observer(key, B, evec)
            u0 = [at0(x, 4) for x in ob['u']]
            print('    %s: u = %s, gamma = %s, v = %s, d = %s, Ecal = g(u, d_t) = %s' % (label, [str(x) for x in u0], ob['gam0'], ob['v0'], [str(x) for x in ob['d0']], ob['Ecal']))
            chk('std', lorentz_ok(ob['Ls'], 4) and sum(at0(B['g'][(m, v)], 4) * u0[m] * u0[v] for m in range(4) for v in range(4)) == 1, '%s: Lambda^T eta Lambda = eta as exact 5-jets (matrix form) and g(u, u) = 1 at the point' % label)
            chk('bit==std', ob['grades'] and all(ob['Lb'][a][b] == ob['Ls'][a][b] for a in range(4) for b in range(4)), '%s: the rotor Lambda (bit rule: U U~ a scalar, U gamma_b U~ vectors) = the matrix form (gamma, -gamma v d; -gamma v d, delta + (gamma - 1) d d), every entry as a jet' % label)
            en = engine_derivs(ob['e'], 4); tick('%s: engine' % key)
            chk('bit==std', all(jet_cut(en['Einv'][mu][0], KJ - 1) == jet_cut(ob['u'][mu], KJ - 1) for mu in range(4)), '%s: the frame vector E\'_0 of the boosted coframe (inverse series) = the observer\'s coordinate 4-velocity, as 4-jets' % label)
            Et = en['Et']
            P = {j: {ix: dcoef(Et.get((ix[0] + 1, ix[1] + 1), {}), ix[2:]) for ix in itertools.product(range(3), repeat=j)} for j in (2, 3, 4, 5)}
            tz = all(not Et.get((a, c)) for a in range(4) for c in range(4) if a == 0 or c == 0)
            if key in RADIAL:
                chk('bit==std', tz and all(P[j] == PHI[j] for j in (2, 3, 4, 5)), '%s: (P) E\'^i_j(x) = Phi_,ij(x) as a 3-jet (E\'_0b = 0): the coordinate derivatives d E\', d d E\', d d d E\' are Phi\'s (9 + 27 + 81 + 243 components)' % label)
            else:
                dE = {ix: P[2][ix] - PHI[2][ix] for ix in P[2]}; m0 = ob['d0']
                basis = [{ix: F(int(ix[0] == ix[1])) for ix in dE}, {ix: n[ix[0]] * n[ix[1]] for ix in dE}, {ix: m0[ix[0]] * m0[ix[1]] for ix in dE}, {ix: n[ix[0]] * m0[ix[1]] + m0[ix[0]] * n[ix[1]] for ix in dE}]
                w, rank, nvar, cons = solve_exact([[b[ix] for b in basis] for ix in sorted(dE)], [dE[ix] for ix in sorted(dE)])
                cf = [str(x / (Mc / rho ** 3)) for x in w] if w else ['?'] * 4
                chk('bit', tz and dE != {ix: 0 for ix in dE} and cons, '%s: E\'^i_j differs from Phi_,ij: E\' - Phi_,ij = (M/r^3) [%s delta + %s n n + %s m m + %s (n m + m n)] (units M/r^3; tr = %s; the coordinate derivatives differ as well: %s)' %
                    (label, cf[0], cf[1], cf[2], cf[3], str(sum(dE[(i, i)] for i in range(3)) / (Mc / rho ** 3)), all(P[j] != PHI[j] for j in (3, 4, 5))))
            # the Christoffel route for this observer
            L0 = [[at0(ob['Ls'][a][b], 4) for b in range(4)] for a in range(4)]
            e0b = [[sum(L0[a][b] * geo['e0'][b][mu] for b in range(4)) for mu in range(4)] for a in range(4)]
            st = std_derivs(geo, ob['u'], e0b); st0 = std_derivs(geo, ob['u'], e0b, drop_gamma=True); tick('%s: Christoffel route' % key)
            Cmix = {q: mixed_at(en['T'][q]) for q in range(KJ - 1)}
            chk('bit==std', all(Cmix[q] == st[q] for q in range(KJ - 1)), '%s: E\', nabla E\', nabla nabla E\', nabla^3 E\' (16, 64, 256, 1024 frame components, first index up): engine = Christoffel route with the observer\'s 4-velocity and the boosted frame, exact' % label)
            chk('ctl', all(st0[q] != Cmix[q] for q in (1, 2, 3)), '%s: the Christoffel route without its Christoffel terms differs at orders 1, 2, 3' % label)
            Csp = {q: spatial(en['T'][q], q) for q in range(1, KJ - 1)}
            Vsp = {(i, c, k): -at0(en['V'].get((i + 1, c + 1, k + 1), {}), 4) for i in range(3) for c in range(3) for k in range(3)}
            Vall = {ix: SQ[ix[0]] * at0(v, 4) for ix, v in en['V'].items() if at0(v, 4) != 0}
            ndiff = sum(1 for ix in Vsp if Vsp[ix] != Csp[1][ix])
            chk('ctl', Vall != Cmix[1], '%s: the derivative along the frame vectors without connection terms differs from nabla E\' on the 64 components (spatial components that differ: %d of 27)' % (label, ndiff))
            if key in RADIAL:
                okH = Csp[1] == {ix: ob['Ecal'] * v for ix, v in PHI[3].items()}
                chk('bit==std', okH, '%s: (nabla_k E\')^i_j = Ecal Phi_,ijk exactly, all 27 spatial components, Ecal = g(u, d_t) = %s' % (label, ob['Ecal']))
                TABLE[(key, ip, 1)] = (ob['Ecal'], okH)
                if key == 'b': chk('bit', ndiff == 0 and okH, '%s: the connection terms vanish in the spatial components of nabla E\' (flat spatial slices): nabla E\' = dE\' = Phi_,ijk exactly' % label)
                if key == 'ks': chk('ctl', ob['Ecal'] == 1 - f0 and okH, '%s: the identity boost reproduces the factor 1 - M/r = %s' % (label, 1 - f0))
                if key == 'w':
                    chk('ctl', ob['Ecal'] not in (1 - f0, rat_sqrt(1 - 2 * f0)) and Csp[1] != {ix: rat_sqrt(1 - 2 * f0) * v for ix, v in PHI[3].items()}, '%s: the wrong sign of v changes the first-order factor: %s instead of the static sqrt(1 - 2M/r) = %s' % (label, ob['Ecal'], rat_sqrt(1 - 2 * f0)))
                nz = [sum(1 for ix in Csp[q] if Csp[q][ix] != PHI[q + 2][ix]) for q in (2, 3)]
                chk('bit', all(x > 0 for x in nz), '%s: nabla nabla E\' and nabla^3 E\' are not Phi\'s derivatives (%s spatial components differ): terms beyond first order in M' % (label, nz))
            RES[key] = dict(ob=ob, en=en, P=P, Csp=Csp, st=st)
            # the bookkeeping run
            if key in LAMRUN:
                with trunc(4, xdeg=KJ, lam=LAMCUT): obl = build_observer(key, BL, evec)
                enl = engine_derivs(obl['e'], 5, LAMCUT); tick('%s: engine, lam' % key)
                Etl = enl['Et']; degsE = sorted({L for q in Etl.values() for L in range(LAMCUT + 1) for ix in [()] + [tuple(c) for dd in (1, 2, 3) for c in itertools.combinations_with_replacement(range(3), dd)] if dcoef(q, ix, 5, L) != 0})
                same2 = all(dcoef(Etl.get(k, {}), ix, 5, 2) == dcoef(Et.get(k, {}), ix) for k in set(Et) | set(Etl) for ix in [()] + [tuple(c) for dd in (1, 2, 3) for c in itertools.combinations_with_replacement(range(3), dd)])
                chk('bit', degsE == [2] and same2, '%s: with f -> lam^2 f the field E\'^a_c(x) (3-jet) is exactly lam^2 times the M run: linear in M' % label)
                Cl = {q: lam_parts(enl['T'], q) for q in (1, 2, 3)}; degsall = {q: sorted(Cl[q]) for q in Cl}
                degs = {q: sorted({L for L in Cl[q] if any(all(c > 0 for c in ix) and v != 0 for ix, v in Cl[q][L].items())}) for q in Cl}
                print('    %s: lam-degrees present in nabla E\', nabla nabla E\', nabla^3 E\': spatial components %s, all components %s (lam^2 = M^1)' % (label, [degs[q] for q in (1, 2, 3)], [degsall[q] for q in (1, 2, 3)]))
                if key in RADIAL:
                    chk('bit==std', all(spatial(enl['T'][q], q, 5, 2) == PHI[q + 2] for q in (1, 2, 3)) and all(0 not in degs[q] and 1 not in degs[q] for q in degs), '%s: the lam^2 part (first order in M) of nabla E\', nabla nabla E\', nabla^3 E\' is Phi\'s derivatives exactly, every spatial component; no lam^0, lam^1 parts' % label)
                if key in ('ks', 'b', 'd'):
                    summed = all({ix: v for ix, v in {ix: sum(Cl[q][L].get(ix, F(0)) for L in Cl[q]) for ix in set().union(*[set(dd) for dd in Cl[q].values()])}.items() if v != 0} == Cmix[q] for q in (1, 2, 3))
                    chk('bit', summed and max(max(degsall[q]) for q in degsall) < LAMCUT, '%s: the lam polynomial ends below the cut (highest degree %d, all components) and the sum of its coefficients is the M run, every component' % (label, max(max(degsall[q]) for q in degsall)))
                if key == 'ks':
                    chk('bit', degs == {1: [2, 4], 2: [2, 4, 6], 3: [2, 4, 6, 8]}, '%s: lam-degrees [2, 4], [2, 4, 6], [2, 4, 6, 8]: polynomials in M of degree 2, 3, 4 at orders 1, 2, 3' % label)
                    okt = True
                    for q in (2, 3):
                        for Lc, cf in COEF[q].items():
                            part = sym(spatial(enl['T'][q], q, 5, 2 * Lc), q + 2); Bq = nd_basis(n, q + 2); uq = Mc ** Lc / rho ** (Lc + q + 2)
                            okt &= part == {ix: uq * sum(c * b[ix] for c, b in zip(cf, Bq)) for ix in part}
                    chk('bit', okt, '%s: the table COEF of g2_forque_fourth (M^2, M^3 parts of Sym nabla nabla E, M^2..M^4 of Sym nabla^3 E on the n/delta basis) holds exactly at M = %s' % (label, Mc))
                if key == 'a':
                    chk('bit', degs[1] == [2, 4, 6, 8] and degs[3] == [2, 4, 6, 8] and degs[2] == [2, 4] and degsall[2] == [2, 4, 6, 8], '%s: the series in M does not end for nabla E\' and nabla^3 E\' (even lam-degrees up to the cut: sqrt(1 - 2M/r) in the frame), while the spatial components of nabla nabla E\' are a polynomial of degree 2 in M (lam-degrees [2, 4]; its time components carry the series)' % label)
                if key == 'b':
                    chk('bit', degs == {1: [2], 2: [2, 4], 3: [2, 4]}, '%s: lam-degrees [2], [2, 4], [2, 4]: nabla E\' is first order in M only; nabla nabla E\' and nabla^3 E\' carry M^2 terms only (no M^3, M^4, no half-integer powers)' % label)
                if key == 'd':
                    print('    %s: lam-degrees of E\' itself: %s' % (label, degsE))
                # the fits on the n/delta basis beyond first order (symmetrised spatial parts); fitted at the first point, checked at the second
                for q in (1, 2, 3):
                    for L in degs[q]:
                        if L == 2 or L % 2 == 1 or key == 'd': continue
                        Lc = L // 2; part = sym(spatial(enl['T'][q], q, 5, L), q + 2); unit = Mc ** Lc / rho ** (Lc + q + 2)
                        w = fit_basis(part, n, q + 2, unit)
                        if ip == 0:
                            FIT[(key, q, L)] = w
                            if key != 'ks': print('    %s: Sym(%s), order M^%d, in units M^%d/r^%d on (n^%d, delta n^%d%s): %s' % (label, ['', 'nabla E\'', 'nabla nabla E\'', 'nabla^3 E\''][q], Lc, Lc, Lc + q + 2, q + 2, q, ', delta delta' + (' n' if q == 3 else '') if q >= 2 else '', [str(x) for x in w] if w else 'no exact fit'))
                        else: FIT2[(key, q, L)] = (w == FIT.get((key, q, L)), w)
                TABLE[(key, ip, 'degs')] = degs
        if ip == 0:
            chk('bit', all(FIT[('a', q, 4)] == FIT[('ks', q, 4)] for q in (1, 2, 3)) and all(FIT[('b', q, 4)] != FIT[('ks', q, 4)] for q in (2, 3)) and FIT[('a', 2, 4)] == tuple(F(x) for x in COEF[2][2]),
                'R = %s: the M^2 parts of Sym nabla E\', Sym nabla nabla E\', Sym nabla^3 E\' coincide for the static and the Kerr-Schild observer (the two differ from order M^3 on); the free fall\'s M^2 parts differ from theirs' % Ri)
        if ip == 1:
            okf = all(v[0] for v in FIT2.values()); nf = sum(1 for k in FIT2 if FIT[k] is not None)
            chk('bit', okf and all(FIT[k] is not None for k in FIT2), 'R = %s: the %d basis fits of the M^2.. parts made at the first point (static, free fall, Kerr-Schild) hold exactly here (same coefficients; 2M/r the same, n different)' % (Ri, nf))
        # ==================================================================================== the other reading at the Kerr-Schild observer
        head('2.%d  R = %s: the other reading at the Kerr-Schild observer, (nabla^q R)(., u, ., u) with u = E_0 held fixed' % (ip + 1, Ri))
        en = RES['ks']['en']; W, full, om0 = engine_reading2(en, 3); tick('reading 2 (exact)')
        T = en['T']; E1 = {ix: at0(v, 4) for ix, v in T[0].items()}
        chk('bit', {ix: at0(v, 4) for ix, v in W[0].items() if at0(v, 4) != 0} == {ix: v for ix, v in E1.items() if v != 0}, 'R = %s: R_{a0c0} of the four-index frame components = E_ac of the two-index route (16)' % Ri)
        Einv = en['Einv']; Gv = en['Gv']
        omk = {(b, k): at0(frame_comp(om0[b], Einv, k), 4) for b in range(4) for k in range(4)}                      # omega^b_0(E_k): nabla_k E_0 = omega^b_0(E_k) E_b
        acc = [omk[(b, 0)] for b in range(4)]; theta = [[omk[(b, k)] for k in range(1, 4)] for b in range(1, 4)]
        print('    nabla_u E_0 = acceleration %s (frame components; radial part %s, M/r^2 = %s); nabla_k E_0, spatial part (expansion tensor): %s' % ([str(x) for x in acc], sum(n[i] * acc[i + 1] for i in range(3)), Mc / rho ** 2, [[str(x) for x in r] for r in theta]))
        R0 = {ix: at0(v, 4) for ix, v in full[0].items()}
        pred = {}
        for (a, c, k) in itertools.product(range(4), repeat=3):
            s = at0(T[1].get((a, c, k), {}), 4) - sum(omk[(e, k)] * (R0.get((a, e, c, 0), F(0)) + R0.get((a, 0, c, e), F(0))) for e in range(4))
            if s != 0: pred[(a, c, k)] = s
        W1 = {ix: at0(v, 4) for ix, v in W[1].items() if at0(v, 4) != 0}
        chk('bit', W1 == pred, 'R = %s: (nabla_k R)_{a0c0} = (nabla_k E)_ac - omega^e_0(E_k) (R_aec0 + R_a0ce) on all 64 components: the two readings differ by R(., nabla_k u, ., u) + R(., u, ., nabla_k u)' % Ri)
        chk('ctl', W1 != {ix: v for ix, v in {ix: at0(T[1].get(ix, {}), 4) for ix in itertools.product(range(4), repeat=3)}.items() if v != 0}, 'R = %s: without the nabla u terms the identity fails (the readings differ in the time components)' % Ri)
        Wsp = {q: {ix: -at0(W[q].get(tuple(c + 1 for c in ix), {}), 4) for ix in itertools.product(range(3), repeat=q + 2)} for q in (1, 2, 3)}
        Csp = RES['ks']['Csp']
        chk('bit', Wsp[1] == Csp[1], 'R = %s: at the first derivative the two readings agree on all 27 spatial components (the magnetic part of R vanishes for a radial observer): both are (1 - M/r) Phi_,ijk' % Ri)
        nd = [sum(1 for ix in Wsp[q] if Wsp[q][ix] != Csp[q][ix]) for q in (2, 3)]
        chk('bit', all(x > 0 for x in nd), 'R = %s: at the second and third derivative the readings differ in the spatial components (%s of 81, 243)' % (Ri, nd))
        if ip == 0:
            with trunc(4, xdeg=KJ, lam=LAMCUT): obl = build_observer('ks', BL, evec)
            enl = engine_derivs(obl['e'], 5, LAMCUT); WL, fullL, _ = engine_reading2(enl, 3); tick('reading 2 (lam)')
            Wl = {q: {} for q in (1, 2, 3)}
            for q in (1, 2, 3):
                for ix, v in WL[q].items():
                    for L in range(LAMCUT + 1):
                        c = at_pt(v, 5, L)
                        if c != 0: Wl[q].setdefault(L, {})[ix] = SQ[ix[0]] * c
            Cl = {q: lam_parts(enl['T'], q) for q in (1, 2, 3)}
            low = {}
            for q in (2, 3):
                for L in sorted(set(Wl[q]) | set(Cl[q])):
                    d1 = {ix: Wl[q].get(L, {}).get(tuple(c + 1 for c in ix), F(0)) - Cl[q].get(L, {}).get(tuple(c + 1 for c in ix), F(0)) for ix in itertools.product(range(3), repeat=q + 2)}
                    if any(v != 0 for v in d1.values()): low.setdefault(q, []).append(L)
            print('    lam-degrees of reading 2: %s; lam-degrees where the spatial parts of the two readings differ: %s' % ([sorted(Wl[q]) for q in (1, 2, 3)], low))
            chk('bit', all(spatial(WL[q], q, 5, 2) == PHI[q + 2] for q in (1, 2, 3)), 'R = %s: the lam^2 part of reading 2 is Phi\'s derivatives at orders 1, 2, 3 (first order in M: both readings are Newton\'s)' % Ri)
            chk('bit', low == {2: [6], 3: [6, 8]}, 'R = %s: the spatial parts of the two readings differ at lam-degree 6 (order M^3) at the second derivative and at lam-degrees 6, 8 (M^3, M^4) at the third: not below' % Ri)
            for q in (2, 3):
                for L in sorted(Wl[q]):
                    if L == 2: continue
                    Lc = L // 2; part = sym({ix: Wl[q][L].get(tuple(c + 1 for c in ix), F(0)) for ix in itertools.product(range(3), repeat=q + 2)}, q + 2)
                    w = fit_basis(part, n, q + 2, Mc ** Lc / rho ** (Lc + q + 2)); FIT[('r2', q, L)] = w
                    print('    reading 2: Sym(%s), order M^%d, units M^%d/r^%d: %s' % (['', '', 'nabla nabla R', 'nabla^3 R'][q], Lc, Lc, Lc + q + 2, [str(x) for x in w] if w else 'no exact fit'))
        else:
            okr = True
            for q in (2, 3):
                part = sym(Wsp[q], q + 2); tot = {ix: PHI[q + 2][ix] for ix in part}; Bq = nd_basis(n, q + 2)
                for (kk, qq, L), w in FIT.items():
                    if kk == 'r2' and qq == q:
                        Lc = L // 2; uq = Mc ** Lc / rho ** (Lc + q + 2)
                        for ix in tot: tot[ix] += uq * sum(c * b[ix] for c, b in zip(w, Bq))
                okr &= sym({ix: tot[ix] for ix in tot}, q + 2) == part
            chk('bit', okr, 'R = %s: the basis fits of reading 2 made at the first point (M^2.. parts of Sym nabla nabla R, Sym nabla^3 R) hold exactly here' % Ri)
        # ==================================================================================== the bodies
        head('3.%d  R = %s: the bodies (G2\'s 8) contracted with the derivatives of each observer, against the summed force lines' % (ip + 1, Ri))
        okstd = True
        for name, body in BOD[ip]:
            Fs, ts = G2T.std_sums(R, rho, body, Mc)
            okstd &= all(G2T.scoef(Fs[i], k) == lines[name][k][0][i] and G2T.scoef(ts[i], k) == lines[name][k][1][i] for i in range(3) for k in (2, 3, 4))
        chk('bit==std', okstd, 'R = %s: the summed force lines at M = %s equal the direct vector sums (G2 std1), eps^2..eps^4, all 8 bodies' % (Ri, Mc))
        XP = {j: PHI[j] for j in (2, 3, 4, 5)}
        wrong = {'F3': True, 'F4': True, 't3': True, 't4': True}; rep = True
        for name, body in BOD[ip]:
            if all(v == 0 for v in G2T.moments(body, 3).values()): continue
            for k, kk in ((3, 'F3'), (4, 'F4')):
                fF = {2: F(1, 2), 3: F(1, 6), 4: F(1, 24)}; fF[k] = 2 * fF[k]; wrong[kk] &= forque_terms(XP, body, fF=fF)[k][0] != lines[name][k][0]
            for k, kk in ((3, 't3'), (4, 't4')):
                fT = {2: F(1), 3: F(1, 2), 4: F(1, 6)}; fT[k] = 2 * fT[k]; wrong[kk] &= forque_terms(XP, body, fT=fT)[k][1] != lines[name][k][1]
            tR = forque_terms({j: {ix: -v for ix, v in XP[j].items()} for j in XP}, body); rep &= tR[3] != lines[name][3] and tR[4] != lines[name][4]
        chk('ctl', all(wrong.values()), 'R = %s: the wrong Taylor factors (force 1/6 -> 1/3, 1/24 -> 1/12; torque 1/2 -> 1, 1/6 -> 1/3) miss the summed lines (3 random bodies)' % Ri)
        chk('ctl', rep, 'R = %s: the repulsive sign misses the summed lines at eps^3 and eps^4 (3 random bodies)' % Ri)
        for key, label in OBS:
            P, Csp, ob = RES[key]['P'], RES[key]['Csp'], RES[key]['ob']; Ec = ob['Ecal']
            XC = {2: P[2]}
            for q in (1, 2, 3): XC[q + 2] = sym(Csp[q], q + 2)
            okP = okE = True; miss = True; zero3 = True; nz4 = True; miss4 = True; nrand = nsym = 0
            for name, body in BOD[ip]:
                ln = lines[name]; tP = forque_terms({j: P[j] for j in (2, 3, 4, 5)}, body); tC = forque_terms(XC, body)
                okP &= tP[2] == ln[2] and tP[3] == ln[3] and tP[4] == ln[4]
                okE &= tC[2][0] == [Ec * x for x in ln[2][0]] and tC[3][1] == [Ec * x for x in ln[3][1]]
                if all(v == 0 for v in G2T.moments(body, 3).values()):
                    nsym += 1; zero3 &= ln[3] == ([0, 0, 0], [0, 0, 0]) and tC[3] == ln[3]; nz4 &= ln[4] != ([0, 0, 0], [0, 0, 0]); miss4 &= tC[4] != ln[4]
                else:
                    nrand += 1; miss &= tC[3][0] != ln[3][0] and tC[4][0] != ln[4][0] and tC[4][1] != ln[4][1]
            if key in RADIAL:
                chk('bit', okP, '%s: (P) the coordinate derivatives of E\', contracted with the moments, = the summed lines at eps^2, eps^3, eps^4 (force and torque), all 8 bodies' % label)
                chk('bit', okE, '%s: with nabla E\' the force at eps^2 and the torque at eps^3 are Ecal = %s times the summed lines\', all 8 bodies%s' % (label, Ec, ' (exactly the lines)' if Ec == 1 else ''))
                chk('bit', miss, '%s: the force at eps^3 (nabla nabla E\') and the force and torque at eps^4 (nabla^3 E\', nabla nabla E\') miss the summed lines, %d random bodies' % (label, nrand))
                chk('bit', zero3, '%s: centrally symmetric bodies (%d): force and torque at eps^3 exactly 0, lines and contraction' % (label, nsym))
                if key == 'ks': chk('ctl', nz4 and miss4, '%s: their eps^4 term is not zero in the lines (not a vacuous zero) and the contraction with nabla^3 E\', nabla nabla E\' misses it' % label)
            else:
                chk('bit', not okP and not okE and all(forque_terms(XC, body)[2][1] != lines[name][2][1] for name, body in BOD[ip] if name.startswith('random')), '%s: E\' is not Phi_,ij: the torque at eps^2 from E\' misses the summed lines (3 random bodies), and so do the higher orders' % label)
        tick('bodies %d' % (ip + 1))
    # ==================================================================================== the table
    head('4. Table: observer x order; the factor at first order in M; the orders in M beyond the first (lam run; the second point confirms the fits)')
    print('    %-58s %-28s %-24s %-24s %s' % ('observer', 'nabla E\' = Ecal Phi_,ijk', 'orders in nabla nabla E\'', 'orders in nabla^3 E\'', 'Ecal at ' + ', '.join(str(tuple(int(c) for c in R)) for R, _, _ in POINTS[:npts])))
    for key, label in OBS:
        if key not in RADIAL: print('    %-58s %s' % (label, 'E\' itself is not Phi_,ij (linear in M); no factor')); continue
        ok1 = all(TABLE[(key, ip, 1)][1] for ip in range(npts)); Es = [str(TABLE[(key, ip, 1)][0]) for ip in range(npts)]
        yes = 'yes, all 27, %s' % ('both points' if npts == 2 else 'first point')
        if key in LAMRUN:
            dg = TABLE[(key, 0, 'degs')]; fmt = lambda q: ('M^' + ', M^'.join(str(F(L, 2)) for L in dg[q] if L != 2) if len(dg[q]) > 1 else 'none') + (' (cut)' if max(dg[q]) >= LAMCUT - 1 else '')
            print('    %-58s %-28s %-24s %-24s %s' % (label, yes if ok1 else 'NO', fmt(2), fmt(3), ', '.join(Es)))
        else: print('    %-58s %-28s %-24s %-24s %s' % (label, yes if ok1 else 'NO', 'not separated', 'not separated', ', '.join(Es)))
    print('    Answer: no observer run reproduces Newton\'s lines beyond the first covariant derivative; the free fall from rest at infinity reproduces them exactly at the first (force at eps^2, torque at eps^3).')
    finish('G2-observers')

if __name__ == '__main__': main()
