#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""B1.  The first variation of the Einstein-Cartan action, as an exact identity.   python3 b1_first_variation.py [n ...]

 Action (engine objects only):   L = sum_{a<b} eps(a, b, rest) R^{ab} ^ e^{rest}  +  lam_n c vol(e),     lam_n = (n-1)(n-2)/2,   vol(e) = e^0 ^ ... ^ e^{n-1},
     R = d omega + (1/4)[omega, omega] and eps = the sign of the null (bit-rule) product.
 Claim.  For ANY frame e and connection omega (no torsion condition) and any variations de, dom:
     d L  =  de^a ^ E_a(c)  +  sum_{a<b} dom^{ab} ^ Theta_ab  +  d( sum_{a<b} dom^{ab} ^ Y_ab )
     Y_ab = eps(a,b,rest) e^{rest},    Theta_ab = D Y_ab = sum_j (-1)^j eps(a,b,rest) e^{r_1} ... T^{r_j} ... e^{r_{n-2}},    E_a(c) = the engine's Einstein form.
 [bit]  the first variation is the coefficient of eps^1 of L(e + eps de, omega + eps dom), a polynomial of degree <= n in eps: Lagrange interpolation on the nodes 0..n+1 with exact
        weights (the coefficient of eps^(n+1) must vanish).  Everything is the engine's forms with exact polynomial coefficients: the identity holds as a polynomial identity.
 [std]  the same identity at a point in numpy: antisymmetric component arrays, Levi-Civita sums, textbook R^{ab} = d omega^{ab} + omega^{ac} eta_cc omega^{cb}, five-point stencils for d.
 Also: injectivity of T -> Theta (exact rank), and the MacDowell-Mansouri form (n = 4) with the coefficients found by a fit.
 Controls: sign of the total-derivative term, Theta without the (-1)^j, wrong cosmological coefficient, a fixed background vector in L, wrong c in E."""
import time, math
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ [bit] the engine's objects
def wedge_list(Fm, forms):
    r = forms[0]
    for f in forms[1:]: r = Fm.wedge(r, f)
    return r
def lag_EC(Gv, e, om, c, lam=None, bg=False):
    """L = sum_{a<b} eps(a,b,rest) R^{ab} e^{rest} + lam c vol(e);  bg=True replaces the last e^{n-1} by the fixed dx^{n-1} (control: a background vector)"""
    n = Gv.n; Fm = Gv.Fm; Lie_ = Gv.L; R = Gv.curvature(om); tot = {}
    ee = list(e)
    if bg: ee[n - 1] = {1 << (n - 1): {(0,) * n: F(1)}}
    for (a, b) in itertools.combinations(range(n), 2):
        rest = [x for x in range(n) if x not in (a, b)]; sg = Gv.eps([a, b] + rest)
        form = R[Lie_.idx[(1 << a) | (1 << b)]]
        for d in rest: form = Fm.wedge(form, ee[d])
        tot = Fm.add(tot, form, sg)
    lam = F((n - 1) * (n - 2), 2) if lam is None else F(lam)
    return Fm.add(tot, wedge_list(Fm, ee), lam * c)
def Y_forms(Gv, e):
    n = Gv.n; Fm = Gv.Fm; Y = {}
    for (a, b) in itertools.combinations(range(n), 2):
        rest = [x for x in range(n) if x not in (a, b)]; sg = Gv.eps([a, b] + rest)
        Y[(a, b)] = Fm.scale(wedge_list(Fm, [e[d] for d in rest]) if rest else {0: {(0,) * n: F(1)}}, sg)
    return Y
def Theta_forms(Gv, e, T, signs=True):
    """Theta_ab = D Y_ab = sum_j (-1)^j eps(a,b,rest) e^{r_1} ... T^{r_j} ... e^{r_{n-2}}   (signs=False drops the (-1)^j: a control)"""
    n = Gv.n; Fm = Gv.Fm; Th = {}
    for (a, b) in itertools.combinations(range(n), 2):
        rest = [x for x in range(n) if x not in (a, b)]; sg = Gv.eps([a, b] + rest); tot = {}
        for j in range(len(rest)):
            form = wedge_list(Fm, [T[d] if jj == j else e[d] for jj, d in enumerate(rest)])
            tot = Fm.add(tot, form, sg * ((-1) ** j if signs else 1))
        Th[(a, b)] = tot
    return Th
def rhs_pieces(Gv, e, om, de, dom, c, signs=True, ctheta=1):
    """(e-part, omega-part, total derivative) of the right-hand side"""
    n = Gv.n; Fm = Gv.Fm; Lie_ = Gv.L; R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, F(c))
    ep = {}
    for a in range(n): ep = Fm.add(ep, Fm.wedge(de[a], E[a]))
    Y = Y_forms(Gv, e); Th = Theta_forms(Gv, e, T, signs); op = {}; th = {}
    for (a, b) in itertools.combinations(range(n), 2):
        A = Lie_.idx[(1 << a) | (1 << b)]
        op = Fm.add(op, Fm.wedge(dom[A], Th[(a, b)])); th = Fm.add(th, Fm.wedge(dom[A], Y[(a, b)]))
    return ep, op, Fm.scale(Fm.d(th), ctheta)
def vander_weights(m):
    V = [[F(x) ** k for k in range(m)] for x in range(m)]; det, Vi = det_inv(V); assert det != 0
    return Vi
def first_variation(Gv, Lfun, e, om, de, dom):
    """coefficient of eps^1 and of eps^(n+1) of L(e + eps de, om + eps dom) from the values at eps = 0 .. n+1"""
    n = Gv.n; Fm = Gv.Fm; m = n + 2; Vi = vander_weights(m); first = {}; top = {}
    for j in range(m):
        e_t = [Fm.add(e[a], de[a], j) for a in range(n)]; om_t = [Fm.add(om[A], dom[A], j) for A in range(Gv.G)]
        Lt = Lfun(e_t, om_t); first = Fm.add(first, Lt, Vi[1][j]); top = Fm.add(top, Lt, Vi[m - 1][j])
    return first, top
def is_zero(Fm, X, Y=None):
    D = X if Y is None else Fm.add(X, Y, -1)
    return all(not p for p in D.values())
def rand_fields(Gv, rng, density=.5):
    n = Gv.n
    return ([gs.rform(rng, n, 1, 1, density) for _ in range(n)], [gs.rform(rng, n, 1, 1, density) for _ in range(Gv.G)])

# ------------------------------------------------------------------------------------------------ [std] numpy components
def perm_sign(p):
    sg = 1
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i] > p[j]: sg = -sg
    return sg
def mono_entries(forms, n):
    """1-forms with polynomial coefficients -> [(a, mu, K (m x n), v (m))] for evaluation in floats"""
    out = []
    for a, form in enumerate(forms):
        for mask, poly in form.items():
            mu = mask.bit_length() - 1
            if poly:
                K = np.array([list(k[:n]) for k in poly], dtype=float).reshape(len(poly), n); v = np.array([float(c) for c in poly.values()]); out.append((a, mu, K, v))
    return out

class Std:
    """plain tensor calculus: components in numpy, Levi-Civita arrays, textbook curvature and torsion, five-point stencils for derivatives (exact for polynomials of degree <= 4)"""
    def __init__(self, n, sq, e, om, de, dom, c):
        self.n = n; self.sq = np.array(sq, dtype=float); self.c = c; self.pairs = list(itertools.combinations(range(n), 2))
        self.eps = np.zeros((n,) * n)
        for p in itertools.permutations(range(n)): self.eps[p] = perm_sign(p)
        self.sig = [(p, perm_sign(p)) for p in itertools.permutations(range(n))]
        self.e_, self.de_ = mono_entries(e, n), mono_entries(de, n)
        self.om_ = [(A, mu, K, v) for A, mu, K, v in mono_entries(om, n)]; self.dom_ = [(A, mu, K, v) for A, mu, K, v in mono_entries(dom, n)]
    def fields(self, x, t=0.0):
        n = self.n; e = np.zeros((n, n)); om = np.zeros((n, n, n)); dee = np.zeros((n, n)); domm = np.zeros((n, n, n))
        mon = lambda K, v: float(np.prod(np.power(x, K), axis=1) @ v)
        for a, mu, K, v in self.e_: e[a, mu] += mon(K, v)
        for a, mu, K, v in self.de_: dee[a, mu] += mon(K, v)
        for A, mu, K, v in self.om_:
            a, b = self.pairs[A]; w = mon(K, v); om[a, b, mu] += w; om[b, a, mu] -= w
        for A, mu, K, v in self.dom_:
            a, b = self.pairs[A]; w = mon(K, v); domm[a, b, mu] += w; domm[b, a, mu] -= w
        return e + t * dee, om + t * domm, dee, domm
    def grad(self, f, x, h=0.05):
        n = self.n; out = []
        for k in range(n):
            u = np.zeros(n); u[k] = h; out.append((-f(x + 2 * u) + 8 * f(x + u) - 8 * f(x - u) + f(x - 2 * u)) / (12 * h))
        return np.array(out)
    def curv_tors(self, x, t=0.0):
        """textbook R^{ab} = d omega^{ab} + omega^{ac} eta_cc omega^{cb} (R[a,b,mu,nu]) and T^a = d e^a + omega^{ab} eta_bb e^b (T[a,mu,nu])"""
        e, om, _, _ = self.fields(x, t); sq = self.sq
        de = self.grad(lambda y: self.fields(y, t)[0], x); dom = self.grad(lambda y: self.fields(y, t)[1], x)
        R = np.einsum('mabn->abmn', dom) - np.einsum('nabm->abmn', dom) + np.einsum('acm,c,cbn->abmn', om, sq, om) - np.einsum('acn,c,cbm->abmn', om, sq, om)
        T = np.einsum('man->amn', de) - np.einsum('nam->amn', de) + np.einsum('abm,b,bn->amn', om, sq, e) - np.einsum('abn,b,bm->amn', om, sq, e)
        return R, T, e, om
    def _ein(self, ops_idx, sig, arrays):
        pass
    def lagrangian(self, x, t):
        """top-form coefficient of L(e + t de, omega + t dom) = (1/(2 (n-2)!)) eps_{a1..an} R^{a1a2} e^{a3} .. e^{an} + lam c (1/n!) eps e..e"""
        n = self.n; R, T, e, om = self.curv_tors(x, t); L = 'abcdefgh'[:n]; tot = 0.0
        sub = L + ',' + L[:2] + ',' + ','.join(L[k] for k in range(2, n)) + '->'
        for sg_, sgn in self.sig:
            tot += sgn * np.einsum(sub, self.eps, R[:, :, sg_[0], sg_[1]], *[e[:, sg_[k]] for k in range(2, n)])
        return 0.5 * tot / (2 * math.factorial(n - 2)) + (n - 1) * (n - 2) / 2 * self.c * np.linalg.det(e)
    def first_variation(self, x):
        ts = [-3, -2, -1, 0, 1, 2, 3]; wts = [-1 / 60, 9 / 60, -45 / 60, 0, 45 / 60, -9 / 60, 1 / 60]
        return sum(w * self.lagrangian(x, t) for t, w in zip(ts, wts) if w != 0)
    def rhs(self, x):
        """(de^a E_a(c), dom^{ab} Theta_ab summed over a<b, d(dom^{ab} Y_ab)): top-form coefficients, each from the Levi-Civita sums of the textbook formulas"""
        n = self.n; R, T, e, om = self.curv_tors(x); _, _, de_, dom_ = self.fields(x); L = 'abcdefgh'[:n]
        Fm = R + self.c * (np.einsum('bm,cn->bcmn', e, e) - np.einsum('bn,cm->bcmn', e, e))
        k3 = 0.5 / (2 * math.factorial(n - 3)); eterm = 0.0; oterm = 0.0
        sub_e = L + ',' + L[0] + ',' + L[1:3] + ',' + ','.join(L[k] for k in range(3, n)) + '->' if n > 3 else L + ',' + L[0] + ',' + L[1:3] + '->'
        sub_o = L + ',' + L[0:2] + ',' + L[2] + ',' + ','.join(L[k] for k in range(3, n)) + '->' if n > 3 else L + ',' + L[0:2] + ',' + L[2] + '->'
        for sg_, sgn in self.sig:
            eterm += sgn * np.einsum(sub_e, self.eps, de_[:, sg_[0]], Fm[:, :, sg_[1], sg_[2]], *[e[:, sg_[k]] for k in range(3, n)])
            oterm += sgn * np.einsum(sub_o, self.eps, dom_[:, :, sg_[0]], T[:, sg_[1], sg_[2]], *[e[:, sg_[k]] for k in range(3, n)])
        def theta(y):
            e_, _, _, dom__ = self.fields(y); m = n - 1; out = 'ABCDEFGH'[:m]
            sub = L + ',' + L[:2] + out[0] + ',' + ','.join(L[2 + k] + out[1 + k] for k in range(n - 2)) + '->' + out
            Z = np.einsum(sub, self.eps, dom__.transpose(0, 1, 2), *[e_] * (n - 2)) if n > 2 else None
            th = np.zeros_like(Z)
            for sg_, sgn in itertools.islice(((p, perm_sign(p)) for p in itertools.permutations(range(m))), None): th += sgn * np.transpose(Z, sg_)
            return th / (2 * math.factorial(n - 2))
        g = self.grad(theta, x); full = tuple(range(n))
        dth = sum((-1) ** i * g[i][tuple(j for j in full if j != i)] for i in range(n))
        return k3 * eterm, k3 * oterm, dth

def fmt(x): return '%.3e' % x
def pt_eval(poly, x):
    return sum(float(c) * np.prod([x[i] ** k[i] for i in range(len(x))]) for k, c in poly.items())

def run_n(n, cs, seeds):
    sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); Fm = Gv.Fm; full = (1 << n) - 1
    head('n = %d  (Einstein-Cartan with cosmological term, Lorentz frame algebra, random polynomial fields of degree 1, no torsion condition)' % n)
    ctl = {}
    for seed in seeds:
        rng = random.Random(100 * n + seed); e, om = rand_fields(Gv, rng); de, dom = rand_fields(Gv, rng)
        zero_e = [{} for _ in range(n)]; zero_om = [{} for _ in range(Gv.G)]
        for c in cs:
            c = F(c)
            first, top = first_variation(Gv, lambda ee, oo: lag_EC(Gv, ee, oo, c), e, om, de, dom)
            chk('bit', is_zero(Fm, top), 'n=%d seed %d c=%s: L(e + eps de, omega + eps dom) is a polynomial of degree <= n in eps (the eps^(n+1) coefficient vanishes exactly)' % (n, seed, c))
            ep, op, dth = rhs_pieces(Gv, e, om, de, dom, c)
            chk('bit', is_zero(Fm, first, Fm.add(Fm.add(ep, op), dth)) and not is_zero(Fm, first), 'n=%d seed %d c=%s: dL = de^a E_a(c) + dom^{ab} Theta_ab + d(dom^{ab} Y_ab), exact polynomial identity (all coefficients; the variation is not zero)' % (n, seed, c))
            f_e, _ = first_variation(Gv, lambda ee, oo: lag_EC(Gv, ee, oo, c), e, om, de, zero_om)
            ep_e, op_e, dth_e = rhs_pieces(Gv, e, om, de, zero_om, c)
            chk('bit', is_zero(Fm, f_e, ep_e) and is_zero(Fm, op_e) and is_zero(Fm, dth_e), 'n=%d seed %d c=%s: with dom = 0 the variation is de^a E_a(c) alone (algebraic in de: no total derivative)' % (n, seed, c))
            f_o, _ = first_variation(Gv, lambda ee, oo: lag_EC(Gv, ee, oo, c), e, om, zero_e, dom)
            ep_o, op_o, dth_o = rhs_pieces(Gv, e, om, zero_e, dom, c)
            f_o0, _ = first_variation(Gv, lambda ee, oo: lag_EC(Gv, ee, oo, F(0)), e, om, zero_e, dom)
            chk('bit', is_zero(Fm, f_o, Fm.add(op_o, dth_o)) and is_zero(Fm, f_o, f_o0), 'n=%d seed %d c=%s: with de = 0 the variation is dom^{ab} Theta_ab + d(dom^{ab} Y_ab), and it does not depend on c' % (n, seed, c))
            # controls
            k = ctl.setdefault((n, 'sign of the total derivative'), [0, 0]); _, _, dth_bad = rhs_pieces(Gv, e, om, de, dom, c, ctheta=-1); k[1] += 1; k[0] += int(not is_zero(Fm, first, Fm.add(Fm.add(ep, op), dth_bad)))
            k = ctl.setdefault((n, 'Theta without the (-1)^j'), [0, 0])
            if n >= 4:
                _, op_bad, _ = rhs_pieces(Gv, e, om, de, dom, c, signs=False); k[1] += 1; k[0] += int(not is_zero(Fm, first, Fm.add(Fm.add(ep, op_bad), dth)))
            else: ctl.pop((n, 'Theta without the (-1)^j'))
            if c != 0:
                k = ctl.setdefault((n, 'cosmological coefficient n(n-1)/2'), [0, 0]); fb, _ = first_variation(Gv, lambda ee, oo: lag_EC(Gv, ee, oo, c, lam=F(n * (n - 1), 2)), e, om, de, zero_om); k[1] += 1; k[0] += int(not is_zero(Fm, fb, ep_e))
                k = ctl.setdefault((n, 'E_a with 2c'), [0, 0]); Rr = Gv.curvature(om); E2, _ = Gv.einstein(None, e, Rr, 2 * c); ep2 = {}
                for a in range(n): ep2 = Fm.add(ep2, Fm.wedge(de[a], E2[a]))
                k[1] += 1; k[0] += int(not is_zero(Fm, f_e, ep2))
            k = ctl.setdefault((n, 'a fixed background vector in L'), [0, 0]); fb, _ = first_variation(Gv, lambda ee, oo: lag_EC(Gv, ee, oo, c, bg=True), e, om, de, zero_om); k[1] += 1; k[0] += int(not is_zero(Fm, fb, ep_e))
    tick('n=%d identity' % n)
    # injectivity of T -> Theta
    rng = random.Random(7 * n); zero = (0,) * n
    while True:
        e0 = [[F(rng.randint(-3, 3)) for _ in range(n)] for _ in range(n)]
        if det_inv(e0)[0] != 0: break
    ec = [{1 << mu: {zero: e0[a][mu]} for mu in range(n) if e0[a][mu] != 0} for a in range(n)]
    cols = []
    for c_ in range(n):
        for (mu, nu) in itertools.combinations(range(n), 2):
            T = [{} for _ in range(n)]; T[c_] = {(1 << mu) | (1 << nu): {zero: F(1)}}
            Th = Theta_forms(Gv, ec, T); col = []
            for (a, b) in itertools.combinations(range(n), 2):
                for m in range(n):
                    col.append(Th[(a, b)].get(full ^ (1 << m), {}).get(zero, F(0)))
            cols.append(col)
    rows = [list(r) for r in zip(*cols)]; rk = rank_exact(rows)
    chk('bit', rk == len(cols) == len(rows), 'n=%d: the linear map T -> Theta_ab (an e-dependent constant matrix) is square, %d x %d, of exact rank %d: injective, so stationarity in omega is T = 0' % (n, len(rows), len(cols), rk))
    # control for injectivity: with a degenerate frame (a repeated row) the map is not injective
    ec2 = [dict(ec[0])] + [dict(ec[0])] + [dict(x) for x in ec[2:]]
    cols2 = []
    for c_ in range(n):
        for (mu, nu) in itertools.combinations(range(n), 2):
            T = [{} for _ in range(n)]; T[c_] = {(1 << mu) | (1 << nu): {zero: F(1)}}
            Th = Theta_forms(Gv, ec2, T); col = []
            for (a, b) in itertools.combinations(range(n), 2):
                for m in range(n): col.append(Th[(a, b)].get(full ^ (1 << m), {}).get(zero, F(0)))
            cols2.append(col)
    rk2 = rank_exact([list(r) for r in zip(*cols2)]) if n >= 4 else None
    if rk2 is not None: ctl[(n, 'degenerate frame (two equal rows): rank drops')] = [int(rk2 < rk), 1]
    # ---- [std] numpy components, two points
    rng = random.Random(100 * n + seeds[0]); e, om = rand_fields(Gv, rng); de, dom = rand_fields(Gv, rng)
    xs = [np.array([0.3, -0.2, 0.5, 0.1, -0.4][:n]), np.array([-0.5, 0.25, 0.1, -0.3, 0.2][:n])]
    worst_R = 0.0; worst = 0.0; Rb = Gv.curvature(om)
    for c in cs:
        c = F(c); first, _ = first_variation(Gv, lambda ee, oo: lag_EC(Gv, ee, oo, c), e, om, de, dom); ep, op, dth = rhs_pieces(Gv, e, om, de, dom, c)
        S = Std(n, sq, e, om, de, dom, float(c))
        for x in xs:
            Rstd, Tstd, _, _ = S.curv_tors(x)
            for A, (a, b) in enumerate(S.pairs):
                eng = np.zeros((n, n))
                for mask, poly in Rb[A].items():
                    mu, nu = [i for i in range(n) if mask >> i & 1]; w = pt_eval(poly, x); eng[mu, nu] = w; eng[nu, mu] = -w
                worst_R = max(worst_R, float(np.max(np.abs(Rstd[a, b] - eng))) / max(1.0, float(np.max(np.abs(eng)))))
            lhs = S.first_variation(x); e_s, o_s, t_s = S.rhs(x)
            tops = lambda X: pt_eval(X.get(full, {}), x)
            b_lhs, b_e, b_o, b_t = tops(first), tops(ep), tops(op), tops(dth)
            scale_ = max(1.0, abs(b_lhs), abs(b_e), abs(b_o), abs(b_t))
            errs = [abs(lhs - b_lhs), abs(e_s - b_e), abs(o_s - b_o), abs(t_s - b_t), abs(lhs - (e_s + o_s + t_s))]
            worst = max(worst, max(errs) / scale_)
    chk('bit==std', worst_R < 1e-8, 'n=%d: the textbook curvature R^{ab} = d omega^{ab} + omega^{ac} eta_cc omega^{cb} equals the engine\'s R^{ab} (numpy, relative error %s)' % (n, fmt(worst_R)))
    chk('bit==std', worst < 1e-7, 'n=%d: at 2 points x 3 values of c, the numpy components give dL (stencil in eps), de^a E_a, dom Theta, d(dom Y), with lhs = rhs, and each piece equals the engine\'s value at the point (worst relative error %s)' % (n, fmt(worst)))
    tick('n=%d std' % n)
    return ctl

# ------------------------------------------------------------------------------------------------ MacDowell-Mansouri, n = 4
def lag_MM(Gv, e, om, c):
    """4 sum_{a<b, c<d} eps(a,b,c,d) F^{ab} F^{cd} = eps_{abcd} F^{ab} F^{cd} (all indices),  F = R + c e e"""
    n = Gv.n; Fm = Gv.Fm; R = Gv.curvature(om); _, F_ = Gv.einstein(None, e, R, F(c)); tot = {}
    for (a, b) in F_:
        for (cc, d) in F_:
            sg = Gv.eps([a, b, cc, d])
            if sg: tot = Fm.add(tot, Fm.wedge(F_[(a, b)], F_[(cc, d)]), 4 * sg)
    return tot
def mm_pieces(Gv, e, om, de, dom, c):
    n = 4; Fm = Gv.Fm; Lie_ = Gv.L; R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, F(c))
    pe = {}
    for a in range(n): pe = Fm.add(pe, Fm.wedge(de[a], E[a]))
    po = {}; pt = {}
    for (a, b) in itertools.combinations(range(n), 2):
        A = Lie_.idx[(1 << a) | (1 << b)]
        for cc in range(n):
            for d in range(n):
                sg = Gv.eps([a, b, cc, d])
                if sg: po = Fm.add(po, Fm.wedge(Fm.wedge(dom[A], T[cc]), e[d]), 2 * sg)         # eps_{abcd} dom^{ab} T^c e^d over all indices: factor 2 for a <-> b
        for (cc, d) in F_:
            sg = Gv.eps([a, b, cc, d])
            if sg: pt = Fm.add(pt, Fm.wedge(dom[A], F_[(cc, d)]), 4 * sg)                     # eps_{abcd} dom^{ab} F^{cd} over all indices
    return pe, po, Fm.d(pt)
def mm_part(cs, seeds):
    n = 4; sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm
    head('MacDowell-Mansouri form, n = 4:  L = eps_{abcd} F^{ab} ^ F^{cd},  F^{ab} = R^{ab} + c e^a ^ e^b   (coefficients found by an exact fit, then compared with the hand derivation)')
    for seed in seeds:
        rng = random.Random(900 + seed); e, om = rand_fields(Gv, rng); de, dom = rand_fields(Gv, rng)
        for c in cs:
            c = F(c); first, top = first_variation(Gv, lambda ee, oo: lag_MM(Gv, ee, oo, c), e, om, de, dom)
            chk('bit', is_zero(Fm, top), 'MM seed %d c=%s: polynomial of degree <= 4 in eps' % (seed, c))
            pe, po, pt = mm_pieces(Gv, e, om, de, dom, c)
            # fit  first = x pe + y po + z pt  over all polynomial coefficients
            keys = set()
            for X in (first, pe, po, pt):
                for m, p in X.items():
                    for k in p: keys.add((m, k))
            keys = sorted(keys)
            val = lambda X, mk: X.get(mk[0], {}).get(mk[1], F(0))
            rows = [[val(pe, mk), val(po, mk), val(pt, mk)] for mk in keys]; rhs = [val(first, mk) for mk in keys]
            w, rank, nvar, cons = solve_exact(rows, rhs)
            want = [8 * c, 4 * c, F(2)]
            chk('bit', cons and w == want, 'MM seed %d c=%s: dL = x (de^a E_a) + y (eps dom^{ab} T^c e^d) + z d(eps dom^{ab} F^{cd}) holds exactly (%d coefficient equations, rank %d) with (x, y, z) = (%s, %s, %s); hand derivation: (8c, 4c, 2) = (%s, %s, %s)' % (seed, c, len(keys), rank, *(w if w else ['-', '-', '-']), *want))
            if c == 0: chk('bit', cons and w == [0, 0, 2] and not is_zero(Fm, pe) and not is_zero(Fm, po), 'MM c=0: the fit gives (x, y, z) = (0, 0, 2) although the pieces de^a E_a(0) and eps dom T e are not zero themselves: only the total derivative survives, so the omega-equation of eps F F is empty at c = 0')
    # relation to the Einstein-Cartan form:  eps_{abcd} F^{ab} F^{cd} = eps R R + 8 c (L_R + 3 c vol) = L_MM(0) + 8 c L_EC(c)
    rng = random.Random(77); e, om = rand_fields(Gv, rng); c = F(2, 7)
    lhs = Fm.add(lag_MM(Gv, e, om, c), lag_MM(Gv, e, om, F(0)), -1); rhs = Fm.scale(lag_EC(Gv, e, om, c), 8 * c)
    chk('bit', is_zero(Fm, lhs, rhs) and not is_zero(Fm, rhs), 'MM: eps_{abcd} F^{ab} F^{cd} - eps_{abcd} R^{ab} R^{cd} = 8 c (L_R + 3 c vol(e)) exactly, c = %s: the Einstein-Cartan action with lam_4 = 3 is the c-dependent part of the MacDowell-Mansouri action; eps R R is the c-independent part (its variation is a total derivative)' % c)
    chk('ctl', not is_zero(Fm, lhs, Fm.scale(lag_EC(Gv, e, om, c, lam=F(6)), 8 * c)), 'MM control: with lam_4 = 6 instead of 3 the relation fails')
    tick('MM')

def main():
    ns = [int(a) for a in sys.argv[1:]] or [3, 4, 5]
    cs = [F(0), F(1, 3), F(-2, 5)]; allctl = {}
    for n in ns:
        for k, v in run_n(n, cs, seeds=[1, 2] if n < 5 else [1]).items(): allctl[k] = v
    if 4 in ns: mm_part(cs, seeds=[1])
    head('controls (a wrong version must differ on every sample where it can be seen)')
    for (n, name), (dif, seen) in allctl.items():
        chk('ctl', dif == seen and seen > 0, 'n=%d: control "%s": the wrong version fails on %d of %d samples' % (n, name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('B1')
if __name__ == '__main__': main()
