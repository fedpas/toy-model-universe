#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H5 (L part), frames and covariance: the so(2,4) Cartan connection A = omega J + e P + f K (b = 0) on known frames, and its conformal gauge law.
   python3 h5l_frames.py
 [bit]  omega = A3's closed form as a 2-jet (frame 3-jets), the engine's R as a 1-jet, the Schouten tensor S_bd = (1/2)(Ric_bd - Rs eta_bd / 6) as a 1-jet in the frame
        (H1 conventions: Ric_bd = eta^{ac} R_abcd), f^a = S^a_b e^b; the engine curvature of the 6-generator table (h5l_conformal.Conf) at the point (origin of the jets).
        P at the point is FITTED from the requirement that the Lorentz part is trace-free (16 x 16 exact solve, the J part read from 17 engine curvatures).
 [std]  H1's Christoffel route for the Weyl tensor; an own exact Christoffel route to first order (Riemann 1-jet, Schouten, nabla Schouten) for the Cotton 2-form
        K^a_{mu nu} = e^a_rho (nabla_mu S^rho_nu - nabla_nu S^rho_mu); the textbook conformal laws of the Schouten tensor and the Cotton tensor.
 Part 3: frames (flat, de Sitter, anti-de Sitter, FRW, Schwarzschild, SdS, RN, plane wave, Kerr at one point, random): J = Weyl 2-form, P = 0, D = 0, K = Cotton 2-form.
 Part 4: e -> Omega e: A' = Ad(g) A - dg g^-1 with g = exp(xi^a K_a) exp(sigma D), sigma = ln Omega, xi_a = c Omega^-1 d_a sigma (c fitted), F' = Ad(g) F.
 Frames are exact 3-jets at the point (polynomial frames exact; Kerr-Schild frames from rho-power jets, g2_hodge.rho_pow_jet).  Kerr: 2-jets only (no K part)."""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from g2_weyl import *
from h5l_conformal import Conf, compose, decompose, curvature6, ftrunc, fmul0, fzero, ad_forms, Ad_exp, fit_ratio
import g2_hodge as GH
import g2_kerr as GK
from h5s_conformal import weyl_2form, OMEGA_A, OMEGA_B

SQ = [1, -1, -1, -1]
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
MUNU = [(mu, nu) for mu in range(4) for nu in range(mu + 1, 4)]

# ------------------------------------------------------------------------------------------------ frames as exact jets
def ks_frame_jetK(p, rho0, M=0, H2=0, s=0, order=3, nv=4):
    """e^a = dx^a - F l^a l_mu dx^mu, F = M/rho + (H2/2) rho^2 - s/rho^2, l_mu = (1, x/rho), l^a = (1, -x/rho): exact jets of degree `order` at the point p"""
    p = [F(x) for x in p]; rho0 = F(rho0)
    rinv = GH.rho_pow_jet(p, rho0, -1, order, nv); r2 = GH.rho_pow_jet(p, rho0, 2, order, nv); rinv2 = GH.rho_pow_jet(p, rho0, -2, order, nv)
    Fp = lin((F(M), rinv), (F(H2) / 2, r2), (-F(s), rinv2))
    nh = [sp_mul(lin((F(1), const(nv, p[i])), (F(1), var(nv, i + 1))), rinv, order, nv) for i in range(3)]
    l_up = [const(nv, 1)] + [scale(x, -1) for x in nh]; l_dn = [const(nv, 1)] + nh; e = []
    for a in range(4):
        form = {}
        for mu in range(4):
            pol = lin((F(1 if a == mu else 0), const(nv, 1)), (F(-1), sp_mul(sp_mul(Fp, l_up[a], order, nv), l_dn[mu], order, nv)))
            if pol: form[1 << mu] = pol
        e.append(form)
    return e
def f_jets(M, H2, s, r):
    r = F(r); return (M / r + H2 * r ** 2 / 2 - s / r ** 2, -M / r ** 2 + H2 * r + 2 * s / r ** 3, 2 * M / r ** 3 + H2 - 6 * s / r ** 4)
def rescale3(e, Om):
    return [{m: q for m, q in ((m, sp_mul(Om, p, 3, 4)) for m, p in form.items()) if q} for form in e]

# ------------------------------------------------------------------------------------------------ [bit] engine data on a frame
def engine_data(C, e, jet1=True):
    """omega (A3 closed form; a 2-jet if jet1), R, frame components R^{ab}_{cd}, Ric, Rs, Schouten S_bd and f^a = S^a_b e^b as jets of degree dR = 1 (or 0)"""
    Gl = C.Gl; Sk = koszul_S(4, SQ, C.Ll); deg = 2 if jet1 else 1; dR = deg - 1; Fm = Gl.Fm
    om = omega_closed_form(Gl, e, Sk, 4, deg)[0]
    with trunc(4, xdeg=dR):
        R = Gl.curvature(om); E, det = inverse_series(frame_matrix(e, 4), 4, 4, dR); Rup = {}
        for A4, (a, b) in enumerate(C.pairs4):
            for c in range(4):
                for d in range(4):
                    t = {}
                    if c != d:
                        for (mu, nu) in MUNU:
                            p = R[A4].get((1 << mu) | (1 << nu), {})
                            if p: t = padd(t, pm(p, padd(pm(E[mu][c], E[nu][d]), pm(E[nu][c], E[mu][d]), -1)))
                    Rup[(a, b, c, d)] = t; Rup[(b, a, c, d)] = scale(t, -1)
        Ric = {(b, d): scale(lin(*[(F(1), Rup[(a, b, a, d)]) for a in range(4) if a != b]), SQ[b]) for b in range(4) for d in range(4)}
        Rs = lin(*[(F(SQ[b]), Ric[(b, b)]) for b in range(4)])
        Sch = {(b, d): lin((F(1, 2), Ric[(b, d)]), (F(-1, 12) * (SQ[b] if b == d else 0), Rs)) for b in range(4) for d in range(4)}
        f = []
        for a in range(4):
            form = {}
            for b in range(4):
                cf = scale(Sch[(a, b)], SQ[a])
                if cf: form = Fm.add(form, fmul0(cf, ftrunc(e[b], dR)))
            f.append(ftrunc(form, dR))
    e0, E0, det0 = E0_of(e, 4, 4)
    return dict(om=om, R=R, E=E, Rup=Rup, Sch=Sch, f=f, e0=e0, E0=E0, dR=dR)
def pt0(X): return {m: {(0,) * 4: at0(p, 4)} for m, p in X.items() if at0(p, 4) != 0}
def comp2(X): return {(mu, nu): at0(X.get((1 << mu) | (1 << nu), {}), 4) for (mu, nu) in MUNU}
def comp1(X): return {mu: at0(X.get(1 << mu, {}), 4) for mu in range(4)}
def jfr_at(J, E0):
    """frame components J^{ab}_{cd} at the point of the Lorentz part {(a,b): 2-form}"""
    out = {(a, a, c, d): F(0) for a in range(4) for c in range(4) for d in range(4)}
    for (a, b), X in J.items():
        cm = comp2(X)
        for c in range(4):
            for d in range(4):
                v = sum(cm[(mu, nu)] * (E0[mu][c] * E0[nu][d] - E0[nu][c] * E0[mu][d]) for (mu, nu) in MUNU)
                out[(a, b, c, d)] = v; out[(b, a, c, d)] = -v
    return out
def ricci_of(Jfr): return {(b, d): SQ[b] * sum(Jfr[(a, b, a, d)] for a in range(4)) for b in range(4) for d in range(4)}
def full_F(C, d, e, f='S', b=None):
    om1 = [ftrunc(x, 1) for x in d['om']]; e1 = [ftrunc(x, 1) for x in e]
    return decompose(C, curvature6(C, compose(C, om1, e1, d['f'] if f == 'S' else f, b), 0))
def fit_P(C, d, e):
    """[bit] P^a_b at the point from: the Lorentz part of the engine curvature with f^a = P^a_b e^b is trace-free (16 equations, 16 unknowns)"""
    om1 = [ftrunc(x, 1) for x in d['om']]; e1 = [ftrunc(x, 1) for x in e]; E0 = d['E0']
    tr0 = ricci_of(jfr_at(decompose(C, curvature6(C, compose(C, om1, e1), 0))['J'], E0)); cols = []
    for a in range(4):
        for b in range(4):
            fu = [{} for _ in range(4)]; fu[a] = e1[b]
            tr = ricci_of(jfr_at(decompose(C, curvature6(C, compose(C, om1, e1, fu), 0))['J'], E0)); cols.append({k: tr[k] - tr0[k] for k in tr})
    keys = sorted(tr0); rows = [[cols[j][k] for j in range(16)] for k in keys]
    w, rank, nvar, cons = solve_exact(rows, [-tr0[k] for k in keys])
    return ({(a, b): w[4 * a + b] for a in range(4) for b in range(4)} if w else None), rank
def lowered(Jfr): return {k: SQ[k[0]] * SQ[k[1]] * v for k, v in Jfr.items()}
def weyl2_bit(d):
    Rl = {(a, b, c, dd): (SQ[a] * SQ[b] * at0(d['Rup'][(a, b, c, dd)], 4) if a != b else F(0)) for a in range(4) for b in range(4) for c in range(4) for dd in range(4)}
    Cw = weyl_parts(Rl, SQ)[0]; return weyl_2form(Cw, d['e0'], SQ), Rl, Cw

# ------------------------------------------------------------------------------------------------ [std] own Christoffel route to first order (no engine)
def std_route(e, sq=SQ, n=4):
    g = std_metric(e, n, sq, n, 3); gi, g0, g0i = std_inverse_metric(g, n, n, 2)
    dg = {(k, a, b): sp_der(g[(a, b)], k) for k in range(n) for a in range(n) for b in range(n)}
    Gam = {}
    for l in range(n):
        for m in range(n):
            for v in range(m, n):
                t = {}
                for s in range(n):
                    br = sp_add(sp_add(dg[(m, s, v)], dg[(v, s, m)]), dg[(s, m, v)], -1)
                    if br and gi[(l, s)]: t = sp_add(t, sp_mul(gi[(l, s)], br, 2, n), F(1, 2))
                Gam[(l, m, v)] = t; Gam[(l, v, m)] = t
    Riem = {}
    for r in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(n):
                    t = sp_add(sp_der(Gam[(r, v, s)], m), sp_der(Gam[(r, m, s)], v), -1)
                    for l in range(n): t = sp_add(sp_add(t, sp_mul(Gam[(r, m, l)], Gam[(l, v, s)], 1, n)), sp_mul(Gam[(r, v, l)], Gam[(l, m, s)], 1, n), -1)
                    Riem[(r, s, m, v)] = {k: c for k, c in t.items() if sum(k) <= 1}
    Ric = {(s, v): lin(*[(F(1), Riem[(r, s, r, v)]) for r in range(n)]) for s in range(n) for v in range(n)}
    Rs = lin(*[(F(1), sp_mul(gi[(s, v)], Ric[(s, v)], 1, n)) for s in range(n) for v in range(n)])
    Sch = {(m, v): lin((F(1, 2), Ric[(m, v)]), (F(-1, 12), sp_mul(Rs, g[(m, v)], 1, n))) for m in range(n) for v in range(n)}
    G0 = {k: at0(p, n) for k, p in Gam.items()}; S0 = {k: at0(p, n) for k, p in Sch.items()}
    nab = {(l, m, v): at0(sp_der(Sch[(m, v)], l), n) - sum(G0[(k, l, m)] * S0[(k, v)] + G0[(k, l, v)] * S0[(m, k)] for k in range(n)) for l in range(n) for m in range(n) for v in range(n)}
    e0 = [[at0(e[a].get(1 << mu, {}), n) for mu in range(n)] for a in range(n)]
    Cot = {(a, mu, nu): sum(e0[a][r] * g0i[r][s] * (nab[(mu, s, nu)] - nab[(nu, s, mu)]) for r in range(n) for s in range(n)) for a in range(n) for (mu, nu) in MUNU}
    return dict(g0=g0, g0i=g0i, G0=G0, S0=S0, Cot=Cot, e0=e0)

# ------------------------------------------------------------------------------------------------ part 3: frames
def run_frame(C, name, e, expect, kpart=True, controls=False, H2=None):
    d = engine_data(C, e, jet1=kpart); n = 4
    with trunc(4, xdeg=0): tz = torsion_zero_at0(C.Gl, d['om'], e, 4)
    P, rank = fit_P(C, d, e); Sup0 = {(a, b): SQ[a] * at0(d['Sch'][(a, b)], 4) for a in range(4) for b in range(4)}
    chk('bit', tz, '%s: precondition T = 0 at the point (A3 omega, engine torsion with the h table)' % name)
    chk('bit', rank == 16 and P == Sup0, '%s: the trace-free requirement on the Lorentz part fixes P^a_b uniquely (rank 16) and P = Schouten '
        '(1/2)(Ric - Rs eta/6) with the first index raised by eta' % name)
    Fd = full_F(C, d, e) if kpart else full_F(C, d, e, f=[ftrunc(x, 0) for x in d['f']])
    W2, Rl, Cw = weyl2_bit(d); E0 = d['E0']
    okJ = all(comp2(Fd['J'][(a, b)])[mn] == W2[(a, b) + mn] for (a, b) in C.pairs4 for mn in MUNU)
    chk('bit', okJ, '%s: Lorentz part of F = the Weyl 2-form C^{ab} = (1/2) C^{ab}_{cd} e^c e^d of H1\'s projection (weyl_parts), all 36 coordinate components' % name)
    Ws = weyl_2form(weyl_parts(std_frame_riemann(e, 4, SQ), SQ)[0], d['e0'], SQ)
    chk('bit==std', all(comp2(Fd['J'][(a, b)])[mn] == Ws[(a, b) + mn] for (a, b) in C.pairs4 for mn in MUNU), '%s: Lorentz part = the Weyl 2-form of the Christoffel route (H1 std_frame_riemann)' % name)
    zP = all(fzero({m: {k: v for k, v in p.items() if sum(k) == 0} for m, p in x.items()}) for x in Fd['P'])
    zD = all(v == 0 for v in comp2(Fd['D']).values())
    chk('bit', zP and zD, '%s: P part (= T) and D part (= -S_[ac] e^a e^c) are zero at the point' % name)
    Jfr = jfr_at(Fd['J'], E0); Jl = lowered(Jfr); typ, I2, I3, info = petrov(complex_Q(Jl))
    cyc = all(Jl[(a, b, c, dd)] + Jl[(a, c, dd, b)] + Jl[(a, dd, b, c)] == 0 for a in range(4) for b in range(4) for c in range(4) for dd in range(4))
    chk('bit', cyc and pair_symmetric(Jl) and all_traces_zero(Jl, SQ), '%s: the constraints of App. B of arXiv:2602.09664 hold for the Lorentz part: W_a[bcd] = 0 (B.2), W_[ab|cd] pair symmetry (B.4), all traces zero (B.5)' % name)
    if H2 is not None:
        s0 = -F(H2) / 2
        chk('bit', Sup0 == {(a, b): (s0 if a == b else F(0)) for a in range(4) for b in range(4)} and all(comp2(d['R'][C.l4[pr]])[mn] == -F(H2) * comp2(C.Gv.Fm.wedge(ftrunc(e[pr[0]], 0), ftrunc(e[pr[1]], 0)))[mn] for pr in C.pairs4 for mn in MUNU),
            '%s: Einstein space: S^a_b = s0 delta^a_b with s0 = -H2/2 = %s, so A = omega J + e^a (P_a + s0 K_a) and the Lorentz part R - 2 s0 e^a e^b = R + c e^a e^b is the MacDowell-Mansouri '
            'curvature with c = H2 (H3); here R = -H2 e^a e^b at the point' % (name, s0))
    nJ = sum(1 for (a, b) in C.pairs4 for v in comp2(Fd['J'][(a, b)]).values() if v != 0)
    nK = sum(1 for a in range(4) for v in comp2(Fd['K'][a]).values() if v != 0) if kpart else None
    if kpart:
        st = std_route(e)
        okK = all(comp2(Fd['K'][a])[mn] == st['Cot'][(a,) + mn] for a in range(4) for mn in MUNU)
        chk('bit==std', okK, '%s: K part = D f^a = the Cotton 2-form e^a_rho (nabla_mu S^rho_nu - nabla_nu S^rho_mu) of the own Christoffel 1-jet route (all 24 components; %d nonzero)' % (name, nK))
    kz = (nK == 0) if kpart else None
    want_t, want_kz = expect
    chk('bit', typ == want_t and (want_kz is None or kz == want_kz), '%s: Petrov type of the Lorentz part %s (expected %s); nonzero components J %d / 36, K %s / 24, P 0, D 0%s' %
        (name, typ, want_t, nJ, nK if kpart else 'not computed (2-jets)', '; all 15 components of F vanish: flat in the larger algebra' if (nJ == 0 and nK == 0) else ''))
    if controls:
        def trace_free(fl):
            Fc = full_F(C, d, e, f=fl); return all(v == 0 for v in ricci_of(jfr_at(Fc['J'], E0)).values()), Fc
        def f_of(Pm):
            out = []
            for a in range(4):
                form = {}
                for b in range(4):
                    if Pm[(a, b)]: form = C.Gv.Fm.add(form, ftrunc(e[b], 1), Pm[(a, b)])
                out.append(form)
            return out
        PR = {(a, b): F(1, 2) * sum(at0(d['Rup'][(c, a, c, b)], 4) for c in range(4) if c != a) for a in range(4) for b in range(4)}
        Rs0 = sum(SQ[c] * SQ[c] * sum(at0(d['Rup'][(x, c, x, c)], 4) for x in range(4) if x != c) for c in range(4))
        if Rs0 != 0:
            tf1, _ = trace_free(f_of(PR))
            chk('ctl', not tf1, '%s: P = Ric/2 (no trace term, Rs = %s != 0): the Lorentz part is not trace-free (ok)' % (name, Rs0))
        else:
            chk('bit', PR == Sup0, '%s: Rs = 0 here (traceless Maxwell stress), so Ric/2 IS the Schouten tensor: P = Ric/2 is not a wrong version on this frame (no control)' % name)
        tf2, Fc2 = trace_free(f_of({k: -v for k, v in Sup0.items()}))
        chk('ctl', not tf2 and not all(comp2(Fc2['J'][pr])[mn] == W2[pr + mn] for pr in C.pairs4 for mn in MUNU), '%s: P = -Schouten: not trace-free, not Weyl (ok)' % name)
        Pa = {(a, b): Sup0[(a, b)] + SQ[a] * {(0, 1): 1, (1, 0): -1, (2, 3): 2, (3, 2): -2}.get((a, b), 0) for a in range(4) for b in range(4)}
        tf3, Fc3 = trace_free(f_of(Pa))
        chk('ctl', any(v != 0 for v in comp2(Fc3['D']).values()), '%s: P = Schouten + an antisymmetric part: D part != 0 (ok; trace-free: %s)' % (name, tf3))
        rng = random.Random(77); Pr = {(a, b): F(rng.randint(-3, 3), rng.randint(1, 3)) for a in range(4) for b in range(4)}
        tf4, Fc4 = trace_free(f_of(Pr))
        chk('ctl', not tf4 and not all(comp2(Fc4['K'][a])[mn] == st['Cot'][(a,) + mn] for a in range(4) for mn in MUNU), '%s: a random constant P: not trace-free and K != Cotton (ok)' % name)
    return dict(d=d, F=Fd, typ=typ)

def part3(C):
    head('Part 3. Frames: Lorentz part = Weyl 2-form, P = D = 0, K part = Cotton 2-form; conformally flat frames are flat in so(2,4)')
    p7, p3 = (2, 3, 6), (1, 2, 2)
    run_frame(C, 'flat', flat_frame(), ('O', True))
    run_frame(C, 'de Sitter (KS, H2 = 1/5, rho = 7)', ks_frame_jetK(p7, 7, 0, F(1, 5)), ('O', True), H2=F(1, 5))
    run_frame(C, 'anti-de Sitter (KS, H2 = -1/5, rho = 3)', ks_frame_jetK(p3, 3, 0, F(-1, 5)), ('O', True), H2=F(-1, 5))
    run_frame(C, 'FRW a = 1 + t + t^2', frw_frame([1, 1, 1]), ('O', True))
    e_s7 = ks_frame_jetK(p7, 7, 1)
    e2 = ks_frame_jet(tuple(F(x) for x in p7), F(7), *f_jets(1, 0, 0, 7))[0]; e2b = ks_frame_jet(tuple(F(x) for x in p3), F(3), *f_jets(1, F(1, 5), F(1, 2), 3))[0]
    same = all(jet(e_s7[a].get(1 << mu, {}), 4, 2) == e2[a].get(1 << mu, {}) for a in range(4) for mu in range(4))
    same &= all(jet(ks_frame_jetK(p3, 3, 1, F(1, 5), F(1, 2))[a].get(1 << mu, {}), 4, 2) == e2b[a].get(1 << mu, {}) for a in range(4) for mu in range(4))
    chk('bit', same, 'the 3-jet Kerr-Schild frame (rho-power jets) truncated at degree 2 equals b1lib.ks_frame_jet (Schwarzschild rho = 7; M = 1, H2 = 1/5, s = 1/2 at rho = 3)')
    run_frame(C, 'Schwarzschild M = 1, rho = 7', e_s7, ('D', True))
    run_frame(C, 'Schwarzschild M = 1, rho = 3', ks_frame_jetK(p3, 3, 1), ('D', True))
    run_frame(C, 'SdS M = 1, H2 = 1/5, rho = 7', ks_frame_jetK(p7, 7, 1, F(1, 5)), ('D', True))
    run_frame(C, 'RN M = 1, s = 1/2, rho = 7', ks_frame_jetK(p7, 7, 1, 0, F(1, 2)), ('D', False), controls=True)
    run_frame(C, 'RN M = 1, s = 1/2, rho = 3', ks_frame_jetK(p3, 3, 1, 0, F(1, 2)), ('D', False))
    pt = [F(1, 2), F(-1, 3), F(2, 3), F(-3, 2)]
    run_frame(C, 'plane wave h = 1 + 2u - u^2, k = 3 + u', pw_frame(pw_global([1, 2, -1], [3, 1]), pt, deg=3), ('N', True))
    dk = GK.rational_kerr_points(F(1, 2), [F(3)], [((F(3, 5), F(4, 5)), (F(1), F(0)))])[0]
    run_frame(C, 'Kerr M = 1, a = 1/2, r = 3 (2-jets)', GK.kerr_ks_frame_jet(dk['p'], 1, F(1, 2), dk['r'])[0], ('D', None), kpart=False)
    for seed in (5, 6):
        run_frame(C, 'random frame seed %d' % seed, rand_frame(random.Random(seed), 4, 2, 3), ('I', False), controls=(seed == 5))
    tick('part 3')

# ------------------------------------------------------------------------------------------------ part 4: e -> Omega e is a conformal gauge transformation
def jet1_inv(Om):
    O0 = at0(Om, 4); return padd(const(4, 1 / O0), deg_part(Om, 1, 4), -1 / O0 ** 2)
def null_list(k): return [{} for _ in range(k)]
def dil(C, X, Om, Oi, dsig=None):
    """Ad(exp(sigma D)) X (P x Omega, K x Omega^-1), minus dsigma D when dsigma is given"""
    dec = decompose(C, X); Fm = C.Gv.Fm
    P = [fmul0(Om, x) for x in dec['P']]; K = [fmul0(Oi, x) for x in dec['K']]; Dp = dec['D'] if dsig is None else Fm.add(dec['D'], dsig, -1)
    return compose(C, [dec['J'][pr] for pr in C.pairs4], P, K, Dp)
def gauge_A(C, d, e, Om, c_xi, order='KD', quad=True):
    """A^g at the point for g = exp(xi K) exp(sigma D) ('KD') or exp(sigma D) exp(xi K) ('DK'); xi_a = c_xi Omega^-1 d_a sigma; plain derivatives for dsigma, dxi"""
    Fm = C.Gv.Fm
    with trunc(4, xdeg=1):
        Om1 = jet(Om, 4, 1); Oi = jet1_inv(Om); Oi2 = pm(Oi, Oi); dOm = [jet(sp_der(Om, mu), 4, 1) for mu in range(4)]
        dsig = {1 << mu: q for mu in range(4) for q in [pm(dOm[mu], Oi)] if q}
        xi = [scale(pm(Oi2, lin(*[(F(1), pm(d['E'][mu][a], dOm[mu])) for mu in range(4)])), c_xi * SQ[a]) for a in range(4)]
        y = {}
        for a in range(4):
            if xi[a]: y[C.lab[(a, 4)]] = scale(xi[a], F(1, 2)); y[C.lab[(a, 5)]] = scale(xi[a], F(-1, 2))
        dxi = [{1 << mu: q for mu in range(4) for q in [jet(sp_der(xi[a], mu), 4, 0)] if q} for a in range(4)]
        dxiK = compose(C, null_list(6), null_list(4), dxi)
        A = compose(C, [ftrunc(x, 1) for x in d['om']], [ftrunc(x, 1) for x in e], d['f'])
        adK = (lambda X: Ad_exp(C, y, X)) if quad else (lambda X: [Fm.add(X[i], t) for i, t in enumerate(ad_forms(C, y, X))])
        if order == 'KD':
            A1 = dil(C, A, Om1, Oi, dsig); A2 = [Fm.add(x, z, -1) for x, z in zip(adK(A1), dxiK)]
        else:
            A1 = [Fm.add(x, z, -1) for x, z in zip(adK(A), dxiK)]; A2 = dil(C, A1, Om1, Oi, dsig)
    return [pt0(x) for x in A2], dict(xi0=[at0(x, 4) for x in xi], dsig0=[at0(dsig.get(1 << mu, {}), 4) for mu in range(4)])
def A_at0(C, d, e): return [pt0(x) for x in compose(C, [ftrunc(x, 1) for x in d['om']], [ftrunc(x, 1) for x in e], d['f'])]
def run_gauge(C, name, e, Om, controls=False):
    e2 = rescale3(e, Om); d = engine_data(C, e); d2 = engine_data(C, e2); Fm = C.Gv.Fm; O0 = at0(Om, 4)
    with trunc(4, xdeg=0): tz = torsion_zero_at0(C.Gl, d2['om'], e2, 4)
    D0 = decompose(C, gauge_A(C, d, e, Om, F(0))[0])['D']; D1 = decompose(C, gauge_A(C, d, e, Om, F(1))[0])['D']
    cfit = fit_ratio(Fm, Fm.scale(D0, -1), Fm.add(D1, D0, -1))
    Ag, gd = gauge_A(C, d, e, Om, cfit if cfit is not None else F(1)); Ap = A_at0(C, d2, e2)
    chk('bit', tz, '%s: precondition T\' = 0 at the point for Omega e (A3)' % name)
    chk('bit', cfit == 1 and all(Fm.add(x, z, -1) == {} for x, z in zip(Ag, Ap)), '%s, Omega0 = %s: b\' = 0 fixes xi_a = c Omega^-1 d_a sigma with c = %s; then Ad(g) A - dg g^-1 = A\' '
        '(omega\' = A3 of Omega e, e\' = Omega e, f\' = Schouten of Omega e) on all 15 components at the point, g = exp(xi K) exp(sigma D)' % (name, O0, cfit))
    Fa = curvature6(C, compose(C, [ftrunc(x, 1) for x in d['om']], [ftrunc(x, 1) for x in e], d['f']), 0)
    Fb = curvature6(C, compose(C, [ftrunc(x, 1) for x in d2['om']], [ftrunc(x, 1) for x in e2], d2['f']), 0)
    Fa0 = [pt0(x) for x in Fa]; Fb0 = [pt0(x) for x in Fb]
    y0 = {}
    for a in range(4):
        if gd['xi0'][a]: y0[C.lab[(a, 4)]] = const(4, gd['xi0'][a] / 2); y0[C.lab[(a, 5)]] = const(4, -gd['xi0'][a] / 2)
    AdF0 = [pt0(x) for x in Ad_exp(C, y0, dil(C, Fa0, const(4, O0), const(4, 1 / O0)))]
    chk('bit', all(x == z for x, z in zip(Fb0, AdF0)), '%s: F\' = Ad(g) F at the point (all 15 components): the so(2,4) curvature is covariant' % name)
    da, db_ = decompose(C, Fa), decompose(C, Fb)
    Jsame = all(comp2(da['J'][pr]) == comp2(db_['J'][pr]) for pr in C.pairs4)
    E0 = d['E0']; dsb = [sum(E0[mu][b] * gd['dsig0'][mu] for mu in range(4)) for b in range(4)]
    Cab = lambda a, b: (comp2(da['J'][(a, b)]) if a < b else {k: -v for k, v in comp2(da['J'][(b, a)]).items()}) if a != b else {k: F(0) for k in MUNU}
    lhs = {(a,) + mn: O0 * comp2(db_['K'][a])[mn] - comp2(da['K'][a])[mn] for a in range(4) for mn in MUNU}
    rhs = {(a,) + mn: sum(Cab(a, b)[mn] * dsb[b] for b in range(4)) for a in range(4) for mn in MUNU}
    nz = [k for k in rhs if rhs[k] != 0]; mu = lhs[nz[0]] / rhs[nz[0]] if nz else None
    okK = (all(lhs[k] == mu * rhs[k] for k in rhs) if nz else all(v == 0 for v in lhs.values()))
    zPD = all(all(v == 0 for v in comp2(x).values()) for x in db_['P']) and all(v == 0 for v in comp2(db_['D']).values())
    chk('bit', Jsame and okK and zPD, '%s: consequences: Weyl 2-form invariant (Lorentz part of F\' = of F); K\' = Omega^-1 (K + mu C^{ab} d_b sigma) with mu = %s on all 24 components; P\' = D\' = 0' % (name, mu if mu is not None else 'n/a (Weyl = 0 and K = K\' = 0)'))
    # [std] the textbook conformal laws (own Christoffel route on e and on Omega e)
    s1, s2 = std_route(e), std_route(e2); dO = [at0(sp_der(Om, m), 4) for m in range(4)]; ddO = [[at0(sp_der(sp_der(Om, m), v), 4) for v in range(4)] for m in range(4)]
    ds = [x / O0 for x in dO]; dds = [[ddO[m][v] / O0 - dO[m] * dO[v] / O0 ** 2 for v in range(4)] for m in range(4)]
    g0, g0i, G0 = s1['g0'], s1['g0i'], s1['G0']; grad2 = sum(g0i[m][v] * ds[m] * ds[v] for m in range(4) for v in range(4))
    Slaw = {(m, v): s1['S0'][(m, v)] - (dds[m][v] - sum(G0[(l, m, v)] * ds[l] for l in range(4))) + ds[m] * ds[v] - F(1, 2) * g0[m][v] * grad2 for m in range(4) for v in range(4)}
    chk('std', Slaw == s2['S0'], '%s: [std] Schouten law S\'_{mu nu} = S - nabla_mu d_nu sigma + d_mu sigma d_nu sigma - (1/2) g |d sigma|^2 (Christoffel route on g and Omega^2 g)' % name)
    fprime = {(a, v): sum(s2['e0'][a][r] * s2['g0i'][r][s] * s2['S0'][(s, v)] for r in range(4) for s in range(4)) for a in range(4) for v in range(4)}
    chk('bit==std', all(comp1(d2['f'][a])[v] == fprime[(a, v)] for a in range(4) for v in range(4)), '%s: the engine\'s f\'^a = S\'^a_b e\'^b equals e\'^a_rho g\'^{rho sigma} S\'_{sigma nu} dx^nu of the std route' % name)
    Wst = weyl_2form(weyl_parts(std_frame_riemann(e, 4, SQ), SQ)[0], s1['e0'], SQ)
    Wab = lambda a, b, mn: (Wst[(a, b) + mn] if a != b else F(0))
    claw = all(s2['Cot'][(a,) + mn] == (s1['Cot'][(a,) + mn] - sum(Wab(a, b, mn) * dsb[b] for b in range(4))) / O0 for a in range(4) for mn in MUNU)
    chk('std', claw, '%s: [std] Cotton law: K\'^a = Omega^-1 (K^a - C^{ab} d_b sigma) with the std Cotton 2-forms of g and Omega^2 g and the std Weyl 2-form' % name)
    Rsame = all(comp2(d['R'][A4]) == comp2(d2['R'][A4]) for A4 in range(6))
    chk('ctl', not Rsame, '%s: the Ricci part: the Riemann 2-form R^{ab} = Weyl + Ricci part is NOT invariant under e -> Omega e (ok)' % name)
    if controls:
        A2w, _ = gauge_A(C, d, e, Om, F(2)); chk('ctl', any(Fm.add(x, z, -1) != {} for x, z in zip(A2w, Ap)), '%s: c = 2: Ad(g) A - dg g^-1 != A\' (ok)' % name)
        A2o, _ = gauge_A(C, d, e, Om, F(1), order='DK'); chk('ctl', any(Fm.add(x, z, -1) != {} for x, z in zip(A2o, Ap)), '%s: the opposite order exp(sigma D) exp(xi K): != A\' (ok)' % name)
        A2q, _ = gauge_A(C, d, e, Om, F(1), quad=False); chk('ctl', any(Fm.add(x, z, -1) != {} for x, z in zip(A2q, Ap)), '%s: Ad(exp xi K) without the quadratic term: != A\' (ok)' % name)
        chk('ctl', any(x != z for x, z in zip(Fa0, Fb0)), '%s: F\' = F (no gauge transformation) fails (ok)' % name)

def part4(C):
    head('Part 4. e -> Omega e: A\' = Ad(g) A - dg g^-1, g = exp(xi^a K_a) exp(ln Omega D); F\' = Ad(g) F; the Weyl 2-form invariant, the Cotton part shifts by Weyl . d ln Omega')
    run_gauge(C, 'random frame seed 5, Omega_A', rand_frame(random.Random(5), 4, 2, 3), OMEGA_A, controls=True)
    run_gauge(C, 'random frame seed 6, Omega_B', rand_frame(random.Random(6), 4, 2, 3), OMEGA_B)
    run_gauge(C, 'Schwarzschild M = 1, rho = 7, Omega_A', ks_frame_jetK((2, 3, 6), 7, 1), OMEGA_A, controls=True)
    run_gauge(C, 'FRW a = 1 + t + t^2, Omega_B', frw_frame([1, 1, 1]), OMEGA_B)
    tick('part 4')

def main():
    C = Conf(); part3(C); part4(C)
    finish('H5L-frames')

if __name__ == '__main__': main()
