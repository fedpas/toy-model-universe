#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""C2.  Kerr in Kerr-Schild form: the engine's Einstein form vanishes, Ricci = 0, Kretschmann; the horizon numbers from the engine's omega.
    python3 c2_kerr.py

 Frame (g2_kerr.py): e^a = dx^a - f l^a l_mu dx^mu, signature (+,-,-,-), g = eta - 2 f l l, f = M r^3/(r^4 + a^2 z^2),
 l = dt + ((r x + a y) dx + (r y - a x) dy)/(r^2 + a^2) + z dz/r, r the positive root of r^4 - (x^2 + y^2 + z^2 - a^2) r^2 - a^2 z^2 = 0.
 Exact 2-jets at rational points x = sin th (r cos ph - a sin ph), y = sin th (r sin ph + a cos ph), z = r cos th (Pythagorean pairs, r rational);
 every quantity is read at the point (2-jets of the frame suffice: omega(p) needs e to first order, R(p) needs omega to first order, the Christoffel
 route needs g to second order, nabla_chi chi needs omega(p) and chi^a to first order).
 [bit]  omega = A3 closed form, R = d omega + 1/4 [omega, omega], E_a = sum eps F e e (the engine); nabla_chi chi = i_chi (D chi), D = engine D_vector (h table, d).
 [std]  Christoffel route from the jet of g (Ricci, Riemann by two routes, Kretschmann, nabla_chi chi); a float route that never uses the jets (closed-form
        r, f, l in floats, five-point differences); the Boyer-Lindquist numbers kappa, Omega_H as RECALLED values.
 Controls: a in l only (a + 1/7, -a), the denominator of f (2 a^2 z^2, 0), the closed form of K (16 -> 8), M in f (M = 1 against M = 5 in K and the horizon),
 Omega of the wrong sense, chi off the horizon, kappa with a wrong formula."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
import numpy as np
import g2_kerr as K

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

SQ = LORENTZ(4); Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # built here, per run (an engine fault put into Lie in memory is seen)
M0, A0 = F(5), F(3)
RS = [F(9), F(1), F(7), F(4), F(1, 2), F(20)]
ANG = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(0), F(1)), (F(1), F(0))), ((F(-5, 13), F(12, 13)), (F(-8, 17), F(15, 17))), ((F(12, 13), F(5, 13)), (F(0), F(1)))]
AXIS_N = [((F(1), F(0)), (F(1), F(0)))]; AXIS_S = [((F(-1), F(0)), (F(1), F(0)))]
EXTRA = [((F(8, 17), F(15, 17)), (F(3, 5), F(-4, 5)))]

def frame(P, M=M0, a=A0, **kw): return K.kerr_ks_frame_jet(P['p'], M, a, P['r'], **kw)
def engine_point(e, c=0):
    om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, c); return om, R, comp
def std_point(e):
    g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, 4); return g, R1, g0, g0i, ric, Rs
def emax(comp): return max(abs(v) for v in comp.values())
def prop(u, w):
    """w = k u for one k (u not zero): returns k or None"""
    i = next((j for j in range(len(u)) if u[j] != 0), None)
    if i is None: return None
    k = w[i] / u[i]; return k if all(w[j] == k * u[j] for j in range(len(u))) else None
def to_coord(E0, v): return [sum(E0[m][A] * v[A] for A in range(4)) for m in range(4)]
def pstr(P): return '(%s)' % ', '.join(str(c) for c in P['p'])

def main():
    # ================================================================================== 1. E_a = 0
    head('1. [bit] the engine\'s Einstein form E_a(c = 0) on the Kerr-Schild frame (omega = A3 closed form, R = d omega + 1/4 [omega, omega])')
    main_pts = K.rational_kerr_points(A0, RS, ANG) + K.rational_kerr_points(A0, [F(7)], AXIS_N) + K.rational_kerr_points(A0, [F(4)], AXIS_S)
    cache = {}; okP = True; okE = True
    for P in main_pts:
        e, E, l, d = frame(P); om, R, comp = engine_point(e)
        okP &= (d['resP'] == {}); okE &= all(v == 0 for v in comp.values()); cache[P['p']] = (e, om, R, d)
    chk('std', okP, 'the 2-jet of r solves P(r) = r^4 - (rho^2 - a^2) r^2 - a^2 z^2 = 0 to order 2 at every point (chord iteration, pivot P\'(r0) = 2 (r0^4 + a^2 z0^2)/r0)')
    chk('bit', okE, 'E_a(0) = 0 exactly, all 16 components, at %d rational points: M = 5, a = 3, r in {9, 1, 7, 4, 1/2, 20} x 4 (th, ph) (equator included), '
        'and 2 axis points (0, 0, 7), (0, 0, -4)' % len(main_pts))
    others = [(F(1), F(1, 2), K.rational_kerr_points(F(1, 2), [F(2)], ANG[:1]) + K.rational_kerr_points(F(1, 2), [F(3, 2)], ANG[1:2]) + K.rational_kerr_points(F(1, 2), [F(5)], ANG[2:3])),
              (F(3, 2), F(2), K.rational_kerr_points(F(2), [F(1)], ANG[:1]) + K.rational_kerr_points(F(2), [F(5, 2)], ANG[1:2]) + K.rational_kerr_points(F(2), [F(6)], ANG[2:3]))]
    okO = True; ocache = []
    for (M, a, pts) in others:
        for P in pts:
            e, E, l, d = frame(P, M, a); om, R, comp = engine_point(e); okO &= all(v == 0 for v in comp.values()) and d['resP'] == {}; ocache.append((M, a, P, e, R))
    chk('bit', okO, 'E_a(0) = 0 exactly also for (M, a) = (1, 1/2) and (3/2, 2) (a > M: no horizon), 3 points each')
    okc = True
    for P in main_pts[:3]:
        e = cache[P['p']][0]; c = F(1, 5); _, _, comp = engine_point(e, c); e0, E0, det = E0_of(e, 4, 4)
        Mfr = mixed_from_components(comp, e0, det, 4, s=-1); okc &= all(Mfr[b][a] == (-3 * c if a == b else 0) for a in range(4) for b in range(4)) and emax(comp) != 0
    chk('bit', okc, 'with c = 1/5 the engine\'s E_a(c) on the Kerr frame is exactly the cosmological term (G - 3c delta = -3c delta, A4 reading) at 3 points: Kerr is a solution for c = 0 only')
    okM1 = True
    for P in main_pts[:4]:
        e, _, _, _ = frame(P, Mf=F(1)); _, _, comp = engine_point(e); okM1 &= all(v == 0 for v in comp.values())
    chk('bit', okM1, 'the control "M dropped from f" (f = r^3/(r^4 + a^2 z^2)) is NOT a wrong version: E_a = 0 exactly at 4 points (it is Kerr with M = 1; M only scales f). '
        'M is tested in part 5 through K and the horizon')
    tick('part 1')

    # ================================================================================== 2. Christoffel route, Kretschmann, engine curvature = Riemann
    head('2. [std] Ricci = 0 and the Kretschmann scalar from the Christoffel route; [bit==std] the engine\'s curvature equals the Riemann tensor')
    okRic = True; okK = True; nonflat = True; okKb = True; okRiem = True; okR2 = True; nR2 = 0
    for i, P in enumerate(main_pts):
        e, om, R, d = cache[P['p']]; g, R1, g0, g0i, ric, Rs = std_point(e)
        okRic &= all(x == 0 for row in ric for x in row) and Rs == 0
        Kc = K.kretschmann_closed(M0, A0, P['r'], P['p'][2]); Ks = K.std_kretschmann(R1, g0, g0i); okK &= (Ks == Kc); nonflat &= (Kc != 0)
        e0, E0, det = E0_of(e, 4, 4); Rab = Rab_at0(Gv, R, 4); okKb &= (K.engine_kretschmann(Rab, E0, SQ) == Ks)
        okRiem &= (K.engine_riemann_coord(Rab, e0, E0, SQ) == R1)
        if i % 7 == 0: okR2 &= (std_riemann(g, 4, 4, 2)[0] == R1); nR2 += 1
    for (M, a, P, e, R) in ocache:
        g, R1, g0, g0i, ric, Rs = std_point(e); okRic &= all(x == 0 for row in ric for x in row) and Rs == 0
        okK &= (K.std_kretschmann(R1, g0, g0i) == K.kretschmann_closed(M, a, P['r'], P['p'][2]))
    chk('std', okRic, 'Ricci R_{sigma nu} = 0 (all 16) and R = 0 exactly, Christoffel route from the 2-jet of g = e^T eta e, at all %d + 6 points' % len(main_pts))
    chk('std', okK and nonflat, 'Kretschmann R_abcd R^abcd = 48 M^2 (r^2 - a^2 C^2)((r^2 + a^2 C^2)^2 - 16 r^2 a^2 C^2)/(r^2 + a^2 C^2)^6, C = z/r (RECALLED closed form), exactly, '
        'at all %d + 6 points, and it is non-zero at every point (the frame is not flat)' % len(main_pts))
    chk('std', okR2, 'Riemann by the second-derivative route equals the Christoffel route, all 256 components, at %d points' % nR2)
    chk('bit==std', okRiem, 'the engine\'s R^{ab}_{mu nu} (omega from A3) equals the Riemann tensor of g, R^r_{smv} = E^r_a R^{ab}_{mv} eta_bb e^b_s (the A4 identification), all 256 components, %d points' % len(main_pts))
    chk('bit==std', okKb, 'the Kretschmann scalar from the engine\'s curvature (frame components, sum sq_a sq_b sq_c sq_d (R^{ab}_{cd})^2) equals the Christoffel route at %d points' % len(main_pts))
    # why K is a weak witness on these frames: the quadratic part of R is null and orthogonal to R in the Kretschmann contraction
    def frame_comp(Rab, E0):
        return {(A, b, c, d): sum(Rab.get((A, b, m, w), 0) * E0[m][c] * E0[w][d] for m in range(4) for w in range(4)) for A in range(4) for b in range(4) for c in range(4) for d in range(4)}
    ipK = lambda X, Y: sum(SQ[k[0]] * SQ[k[1]] * SQ[k[2]] * SQ[k[3]] * X[k] * Y[k] for k in X)
    okQ = True; nzQ = True; nQ = 0
    for P in main_pts[::5]:
        e, om, R, d = cache[P['p']]; e0, E0, det = E0_of(e, 4, 4); Q = [{} for _ in range(Gv.G)]
        with trunc(4, xdeg=1):
            for (A, B), (C, fc) in Gv.L.f.items(): Q[C] = Gv.Fm.add(Q[C], Gv.Fm.wedge(om[A], om[B]), F(fc, 4))
        Rf = frame_comp(Rab_at0(Gv, R, 4), E0); Qf = frame_comp(Rab_at0(Gv, Q, 4), E0)
        okQ &= (ipK(Rf, Qf) == 0 and ipK(Qf, Qf) == 0); nzQ &= any(v != 0 for v in Qf.values()); nQ += 1
    chk('bit', okQ and nzQ, 'the quadratic part Q = 1/4 f omega^A omega^B of the engine\'s curvature is non-zero at %d points, yet <R, Q> = <Q, Q> = 0 in the Kretschmann contraction: '
        'K(R + t Q) = K(R) for every t, so K cannot see a wrong coefficient of the quadratic term on these frames; the 256-component comparison above can' % nQ)
    # [std] float route: the jets of r, f, l against five-point differences of the closed forms in floats (never uses the jets)
    def fd(fun, x, h=1e-3):
        def d1(fn, x, k):
            dx = np.zeros(3); dx[k] = h; return (-fn(x + 2 * dx) + 8 * fn(x + dx) - 8 * fn(x - dx) + fn(x - 2 * dx)) / (12 * h)
        grad = np.array([d1(fun, x, k) for k in range(3)]); hess = np.array([[d1(lambda y, j=j: d1(fun, y, j), x, k) for j in range(3)] for k in range(3)])
        return fun(x), grad, hess
    worst = 0.0
    for P in [main_pts[0], main_pts[1], main_pts[10], main_pts[-2]]:
        d = cache[P['p']][3]; x0 = np.array([float(c) for c in P['p']])
        e_, E_, (lu, ld), _ = frame(P)
        funs = [('r', lambda y: K.kerr_float(*y, M0, A0)[0], d['r']), ('f', lambda y: K.kerr_float(*y, M0, A0)[1], d['f'])] + \
               [('l%d' % i, (lambda y, i=i: K.kerr_float(*y, M0, A0)[2][i]), ld[i]) for i in (1, 2, 3)]
        for name, fun, jet in funs:
            v, gr, he = fd(fun, x0); scl = max(1.0, abs(v))
            ex_v = float(at0(jet, 4)); ex_g = [float(jet.get(tuple(1 if s == k + 1 else 0 for s in range(4)), 0)) for k in range(3)]
            ex_h = [[float(jet.get(tuple((1 if s == j + 1 else 0) + (1 if s == k + 1 else 0) for s in range(4)), 0)) * (2 if j == k else 1) for j in range(3)] for k in range(3)]
            worst = max(worst, abs(v - ex_v) / scl, max(abs(gr - np.array(ex_g))) / scl, np.max(np.abs(he - np.array(ex_h))) / scl)
    chk('std', worst < 1e-7, 'float route: value, gradient and Hessian of r, f, l_1, l_2, l_3 from the closed forms (five-point differences, h = 1e-3) agree with the exact jets at 4 points '
        '(largest relative difference %.1e)' % worst)
    tick('part 2')

    # ================================================================================== 3. a = 0 is the radial class of C1
    head('3. a = 0 reproduces b1lib.ks_frame_jet (f = M/rho) exactly (frame construction only; no engine object)')
    pts0 = K.rational_kerr_points(0, [F(3), F(7)], ANG); ok0 = True; n0 = 0
    cl = lambda p: {k: v for k, v in p.items() if v != 0}
    for M in (F(5), F(3, 2)):
        for P in pts0:
            r0 = P['r']; e, E, (lu, ld), d = K.kerr_ks_frame_jet(P['p'], M, 0, r0); e2, E2, (lu2, ld2) = ks_frame_jet(P['p'], r0, M / r0, -M / r0 ** 2, 2 * M / r0 ** 3)
            ok0 &= all(cl(e[A].get(1 << m, {})) == cl(e2[A].get(1 << m, {})) and cl(E[m][A]) == cl(E2[m][A]) for A in range(4) for m in range(4))
            ok0 &= all(cl(lu[m]) == cl(lu2[m]) and cl(ld[m]) == cl(ld2[m]) for m in range(4)); n0 += 1
    chk('std', ok0, 'a = 0: every jet coefficient of e, of the inverse frame E and of l equals ks_frame_jet(p, rho0, M/rho0, -M/rho0^2, 2M/rho0^3), %d (point, M) samples, rho0 in {3, 7}' % n0)
    tick('part 3')

    # ================================================================================== 4. horizon numbers from the engine's omega
    head('4. horizon (M = 5, a = 3): chi = d_t + Omega (x d_y - y d_x); nabla_chi chi = i_chi (D chi) with the engine\'s omega and D_vector')
    hd = K.kerr_horizon_data(M0, A0); rp, rm = hd['rp'], hd['rm']
    hor = K.rational_kerr_points(A0, [rp], ANG + EXTRA) + K.rational_kerr_points(A0, [rp], AXIS_N)
    def om_of(P, **kw):
        if not kw and P['p'] in cache: return cache[P['p']][0], cache[P['p']][1]
        e = frame(P, **kw)[0]; return e, engine_point(e)[0]
    roots = set(); discs = set(); norms = set(); kaps = set(); bs_ok = True; fut = True
    for P in hor:
        e, om = om_of(P); disc, Om = K.null_rotation(e, P['p'], SQ); discs.add(disc)
        if Om is not None: roots.add(Om)
    OmH = next(iter(roots)) if len(roots) == 1 else None
    for P in hor:
        e, om = om_of(P); chi = K.killing_chi(P['p'], OmH if OmH is not None else F(0)); ca, nab = K.engine_nabla_vv(Gv, om, e, chi)
        norms.add(K.frame_norm_bit(ca, SQ)); kaps.add(prop(ca, nab))
        e0, E0, det = E0_of(e, 4, 4); g = std_metric(e, 4, SQ, 4, 2); bs_ok &= (to_coord(E0, nab) == K.std_nabla_vv(g, chi))
        gtt_inv = sum(SQ[A] * E0[0][A] ** 2 for A in range(4)); fut &= (gtt_inv > 0 and at0(chi[0], 4) > 0)
    kapH = next(iter(kaps)) if len(kaps) == 1 else None
    print('    Omega roots on r = %s: %s; discriminants %s; |chi|^2 values %s; kappa values %s' % (rp, sorted(str(x) for x in roots), sorted(str(x) for x in discs), sorted(str(x) for x in norms), [str(k) for k in kaps]))
    chk('bit', discs == {0} and OmH == F(1, 30) and len(hor) - 1 == 5, 'on r = 9 the (t, phi) block of the frame metric is degenerate at every point (discriminant 0) and |d_t + Omega d_phi|^2 has the double root '
        'Omega = %s at all 5 points off the axis: the null generator rotates rigidly' % OmH)
    chk('bit', norms == {0}, 'chi = d_t + (1/30) d_phi is null at all %d points of r = 9 (axis included): the bit-rule square of chi^a gamma_a, chi^a = i_chi e^a, is 0' % len(hor))
    chk('bit', kapH == F(2, 45), 'nabla_chi chi = kappa chi, all 4 frame components, with ONE kappa = %s at all %d points of r = 9 (zeroth law, at points)' % (kapH, len(hor)))
    chk('bit==std', hd['kappa_p'] == kapH and hd['Omega_p'] == OmH, 'RECALLED Boyer-Lindquist values kappa = (r+ - r-)/(2 (r+^2 + a^2)) = %s and Omega_H = a/(r+^2 + a^2) = %s equal the engine\'s numbers' % (hd['kappa_p'], hd['Omega_p']))
    chk('bit', fut and kapH is not None and kapH > 0, 'chi^t = 1 and g^tt = sum_a sq_a (E^t_a)^2 > 0 (dt timelike) at every horizon point, so chi is future-directed; kappa > 0: nabla_chi chi = +kappa chi, '
        'the future horizon of the advanced chart (NUL-001\'s sign for its advanced chart)')
    # inner horizon r- = 1, same chart
    inn = K.rational_kerr_points(A0, [rm], ANG); rootsm = set(); kapsm = set(); discm = set()
    for P in inn:
        e, om = om_of(P); disc, Om = K.null_rotation(e, P['p'], SQ); discm.add(disc); rootsm.add(Om)
        chi = K.killing_chi(P['p'], Om); ca, nab = K.engine_nabla_vv(Gv, om, e, chi); kapsm.add(prop(ca, nab)) if K.frame_norm_bit(ca, SQ) == 0 else kapsm.add('not null')
        e0, E0, det = E0_of(e, 4, 4); bs_ok &= (to_coord(E0, nab) == K.std_nabla_vv(std_metric(e, 4, SQ, 4, 2), chi))
    chk('bit', discm == {0} and rootsm == {hd['Omega_m']} and kapsm == {hd['kappa_m']}, 'inner horizon r = 1 (same chart, 4 points): Omega = %s (double root), chi null, nabla_chi chi = kappa chi with kappa = %s '
        '= (r- - r+)/(2 (r-^2 + a^2)) (recalled form)' % (sorted(str(x) for x in rootsm), [str(k) for k in kapsm]))
    # off the horizon (for the [bit==std] comparison and the controls)
    off = K.rational_kerr_points(A0, [F(7), F(20)], [ANG[0], ANG[2]]); off_res = []
    for P in off:
        e, om = om_of(P); chi = K.killing_chi(P['p'], OmH); ca, nab = K.engine_nabla_vv(Gv, om, e, chi)
        e0, E0, det = E0_of(e, 4, 4); bs_ok &= (to_coord(E0, nab) == K.std_nabla_vv(std_metric(e, 4, SQ, 4, 2), chi)); off_res.append((K.frame_norm_bit(ca, SQ), prop(ca, nab)))
    chk('bit==std', bs_ok, 'nabla_chi chi from the engine (frame components -> coordinates) equals v^nu d_nu v^mu + Gamma^mu_{nu lam} v^nu v^lam (Christoffel route), all 4 components, '
        'at %d points (r = 9, 1, 7, 20)' % (len(hor) + len(inn) + len(off)))
    # [std] float route for kappa
    def float_nabla(p, Om, h=1e-3):
        X0 = np.array([0.0] + [float(c) for c in p])
        def dgk(k):
            if k == 0: return np.zeros((4, 4))
            dx = np.zeros(4); dx[k] = h
            return (-K.float_metric(X0 + 2 * dx, M0, A0) + 8 * K.float_metric(X0 + dx, M0, A0) - 8 * K.float_metric(X0 - dx, M0, A0) + K.float_metric(X0 - 2 * dx, M0, A0)) / (12 * h)
        dg = np.array([dgk(k) for k in range(4)]); gi = np.linalg.inv(K.float_metric(X0, M0, A0))
        Gam = 0.5 * (np.einsum('ls,msn->lmn', gi, dg) + np.einsum('ls,nsm->lmn', gi, dg) - np.einsum('ls,smn->lmn', gi, dg))
        Om = float(Om); chi = np.array([1.0, -Om * X0[2], Om * X0[1], 0.0]); dchi = np.zeros((4, 4)); dchi[1, 2] = Om; dchi[2, 1] = -Om     # dchi[nu, mu] = d_nu chi^mu
        nab = chi @ dchi + np.einsum('mnl,n,l->m', Gam, chi, chi); return nab, chi
    fk = []
    for P in hor[:3]:
        nab, chi = float_nabla(P['p'], OmH); k = nab[0] / chi[0]; fk.append((k, float(np.max(np.abs(nab - k * chi)))))
    chk('std', all(abs(k - 2 / 45) < 1e-8 and res < 1e-8 for k, res in fk), 'float route (closed-form metric in floats, five-point differences, no jets): nabla_chi chi = kappa chi with kappa = %s at 3 points of r = 9 (2/45 = %.12f)'
        % (', '.join('%.12f' % k for k, _ in fk), 2 / 45))
    # retarded chart (time reverse): the past horizon
    rkap = set(); rroot = set(); rE = True
    for P in hor[:3]:
        e, om = om_of(P, retarded=True); _, _, comp = engine_point(e); rE &= all(v == 0 for v in comp.values())
        disc, Om = K.null_rotation(e, P['p'], SQ); rroot.add((disc, Om)); chi = K.killing_chi(P['p'], Om); ca, nab = K.engine_nabla_vv(Gv, om, e, chi)
        rkap.add(prop(ca, nab) if K.frame_norm_bit(ca, SQ) == 0 else 'not null')
    chk('bit', rE and rroot == {(0, -F(1, 30))} and rkap == {-F(2, 45)}, 'time-reversed (retarded) Kerr-Schild frame, l = dt - (...): E_a = 0, the double root is Omega = -1/30 (spin reversed) and '
        'nabla_chi chi = -(2/45) chi at 3 points of r = 9: the past horizon, sign -kappa, as NUL-001 says for its retarded chart')
    # a = 0: the Atlas's Schwarzschild r_S = 3 chip
    s_k = set(); s_n = set()
    for P in K.rational_kerr_points(0, [F(3)], ANG):
        e = K.kerr_ks_frame_jet(P['p'], F(3, 2), 0, P['r'])[0]; om = engine_point(e)[0]; xi = K.d_t(P['p']); ca, nab = K.engine_nabla_vv(Gv, om, e, xi)
        s_n.add(K.frame_norm_bit(ca, SQ)); s_k.add(prop(ca, nab))
    chk('bit', s_n == {0} and s_k == {F(1, 6)}, 'a = 0, M = 3/2 (r_S = 3), 4 points of rho = 3: xi = d_t is null and nabla_xi xi = (1/6) xi: NUL-001\'s first chip (computed there in the EF chart '
        'by Christoffel symbols) from the engine\'s omega in the Kerr-Schild chart')
    print('    numbers: Omega_H = %s, kappa(r+ = 9) = %s, kappa(r- = 1) = %s, kappa(Schwarzschild r_S = 3) = 1/6' % (OmH, kapH, hd['kappa_m']))
    tick('part 4')

    # ================================================================================== 5. controls
    head('5. controls: a wrong version must fail')
    ctl_pts = K.rational_kerr_points(A0, [F(9), F(4)], ANG[:3])
    # "a -> -a in l only" is not a wrong version (E_a = 0 at 6 of 6 points):
    # r and f depend on a only through a^2, so a -> -a in l alone is a -> -a everywhere, Kerr with the opposite spin. Checked here as what it is;
    # the sign of a (the sense of rotation) is fixed only by the horizon, and that is the control.
    okm = True; rts = set(); difS = 0
    for P in ctl_pts:
        e = frame(P, a_l=-A0)[0]; okm &= all(v == 0 for v in engine_point(e)[2].values())
    for P in hor[:5]:
        e = frame(P, a_l=-A0)[0]; rts.add(K.null_rotation(e, P['p'], SQ))
        ca = [at0(q, 4) for q in K.engine_vector_at0(e, K.killing_chi(P['p'], F(1, 30)))]; difS += int(K.frame_norm_bit(ca, SQ) != 0)
    chk('bit', okm and rts == {(0, -F(1, 30))}, '"a -> -a in l only" is NOT a wrong version: E_a = 0 exactly at %d points, because r and f are even in a, '
        'so it is Kerr with spin -a; on r = 9 its double root is Omega = -1/30 (5 points): the sign of a is the sense of rotation, a convention the field equation cannot see' % len(ctl_pts))
    chk('ctl', difS == 5, '"a -> -a in l only" against the stated orientation (a > 0 turns in the +phi sense): d_t + (1/30) d_phi is not null on r = 9 for that frame at %d of 5 points' % difS)
    for name, kw in [('a in l only: a_l = a + 1/7', dict(a_l=A0 + F(1, 7))),
                     ('f = M r^3/(r^4 + 2 a^2 z^2)', dict(den_k=2)), ('f = M r^3/r^4 = M/r with the Kerr l and r', dict(den_k=0))]:
        sizes = []
        for P in ctl_pts:
            e = frame(P, **kw)[0]; sizes.append(emax(engine_point(e)[2]))
        chk('ctl', all(s != 0 for s in sizes), '"%s": E_a != 0 at %d of %d points (r = 9, 4; equator included); largest |component| per point from %.3g to %.3g'
            % (name, sum(1 for s in sizes if s != 0), len(sizes), float(min(sizes)), float(max(sizes))))
    nz = [P for P in main_pts if P['p'][2] != 0][:6]; dif = 0
    for P in nz:
        e, om, R, d = cache[P['p']]; g, R1, g0, g0i, ric, Rs = std_point(e); dif += int(K.std_kretschmann(R1, g0, g0i) != K.kretschmann_closed(M0, A0, P['r'], P['p'][2], c16=8))
    chk('ctl', dif == len(nz), '"K closed form with 16 -> 8": differs from the Christoffel-route K at %d of %d points with z != 0 (at z = 0 the term is absent)' % (dif, len(nz)))
    difK = 0; difH = 0; nH = 0
    for P in main_pts[:4]:
        e = frame(P, Mf=F(1))[0]; R = engine_point(e)[1]; e0, E0, det = E0_of(e, 4, 4)
        difK += int(K.engine_kretschmann(Rab_at0(Gv, R, 4), E0, SQ) != K.kretschmann_closed(M0, A0, P['r'], P['p'][2]))
    for P in hor[:5]:
        e = frame(P, Mf=F(1))[0]; ca = [at0(q, 4) for q in K.engine_vector_at0(e, K.killing_chi(P['p'], F(1, 30)))]; difH += int(K.frame_norm_bit(ca, SQ) != 0); nH += 1
    chk('ctl', difK == 4 and difH == nH, '"M dropped from f" (M = 1 in the frame): the engine\'s K differs from the closed form with M = 5 at %d of 4 points, and d_t + (1/30) d_phi is not null '
        'on r = 9 at %d of %d points' % (difK, difH, nH))
    difW = 0; nW = 0
    for P in hor[:5]:
        e, om = om_of(P); ca = [at0(q, 4) for q in K.engine_vector_at0(e, K.killing_chi(P['p'], -F(1, 30)))]; difW += int(K.frame_norm_bit(ca, SQ) != 0); nW += 1
    chk('ctl', difW == nW, '"Omega = -1/30" (wrong sense of rotation): chi is not null at %d of %d points of r = 9' % (difW, nW))
    chk('ctl', all(nr != 0 and k is None for nr, k in off_res), '"chi with Omega_H off the horizon" (r = 7, 20; 4 points): chi is not null and nabla_chi chi is not proportional to chi at every point')
    wrong = {'(r+ - r-)/(r+^2 + a^2)': (rp - rm) / (rp ** 2 + A0 ** 2), '1/(4M) (Schwarzschild)': 1 / (4 * M0), '(r+ - r-)/(2 r+^2) (a dropped)': (rp - rm) / (2 * rp ** 2)}
    chk('ctl', all(v != kapH for v in wrong.values()), 'kappa with a wrong formula differs from the engine\'s 2/45: ' + ', '.join('%s = %s' % (k, v) for k, v in wrong.items()))
    tick('part 5')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('C2')

if __name__ == '__main__': main()
