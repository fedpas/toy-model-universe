#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""E2S4-belinfante.  The Belinfante term of the Dirac field as a separate object: Hilbert stress = canonical stress + (1/2) covariant divergence of the spin.
   python3 e2s4_belinfante.py [--seeds K]

 n = 4, Cl(1,3), sq = (+,-,-,-), the Atlas Dirac line of E2 (psi even, reversion, J = g2 g1 and g0 on the right), L_D as in E2 and E2S4.
 Fields: strong random polynomials (every monomial to x-degree 2, integers in [-9, 9]) for e and psi; omega_LC = A3's closed form (first-order jet).
 Definitions.  delta_e L_D at fixed omega = delta e^a ^ tau_a (canonical stress, E2S4);  delta_omega L_D = delta omega^A ^ S_A (spin, E2).
   With omega = omega_LC(e) the frame variation has the extra piece (delta_e omega_LC)^A ^ S_A, first order in d(delta e); its Euler-Lagrange
   reduction (delta L = delta e^a ^ tau^LC_a + exact) is the Hilbert stress, and B_a = tau^LC_a - tau_a the Belinfante term.
 [bit]  tau^LC_a, tau_a and B_a by the same reduction: 16 constant unit variations (dL/de) and 64 linear ones x^nu dx^mu (dL/d(d_nu e)), then
        tau = dL/de - d_nu dL/d(d_nu e), exact at the origin with first-order jets.  Claims: tau^LC = tau + B (chain rule, off shell); B_ab antisymmetric;
        B_ab = beta (D S)_ab + beta' dual(D S)_ab by an exact fit (predicted (-1/2, 0)); D S_ab = (nabla_c sigma^c_ab) vol on the torsion-free connection
        (h and f tables); off shell tau^LC_ab - tau^LC_ba = (1/2)(B_ab psi).EL / vol; on the Dirac shell tau^LC is symmetric while the canonical
        tau keeps tau_[ab] = (1/2)(D S)_ab (Rosenfeld).
 [std]  numpy only: the Hilbert stress by a numerical functional derivative of det(e) l(e, de, chi, dchi) (Dirac matrices, the Christoffel spin
        connection recomputed from (e, de) inside the density, 4-point stencils in the 16 + 64 entries, central differences in x for the momenta);
        the textbook canonical T and spin current sigma; T_H - T_can = c nabla^c sigma_cab (least squares); T_H symmetric on the engine-solved shell.
 [bit==std] engine tau^LC = numerical functional derivative; engine B = -(T_H - T_can).
 Controls: the opposite sign of B; the canonical stress in place of the Hilbert one on shell; a spinor off shell; a connection with torsion in the
   closed form of B and in the divergence identity; [std] without the Belinfante term.
 Scope: n = 4, (+,-,-,-), classical commuting spinors, the origin of 3 strong random configurations with first-order jets: checks at these points.
 Exports: omega_lc, el_reduce, lower_at0, ds_matrix, dual_of, div_sigma, std_eval, std_dens, std_hilbert, std_can, std_belinfante."""
import sys, os, time, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from b1lib import *
import e2_spin_torsion as E2
import e2s4_dirac_stress as S4
from g2_forms_calc import D_dual_bivector, _der as std_der
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N, NV, FULL = 4, 5, 15
LOR = [1, -1, -1, -1]; PAIRS = E2.PAIRS; EVEN = E2.EVEN
ZK = (0,) * NV
LAMV = {(0, 0, 0, 0, 1): F(1)}
def xlam(nu): return {tuple(1 if i == nu else 0 for i in range(N)) + (1,): F(1)}        # the monomial x^nu lam
def xv(nu): return {tuple(1 if i == nu else 0 for i in range(N)) + (0,): F(1)}          # the monomial x^nu
cst, v0, tp, tf, top0, form0, lamp, is0 = S4.cst, S4.v0, S4.tp, S4.tf, S4.top0, S4.form0, S4.lamp, S4.is0
def sym(M): return [[(M[a][b] + M[b][a]) / 2 for b in range(N)] for a in range(N)]
def asym(M): return [[(M[a][b] - M[b][a]) / 2 for b in range(N)] for a in range(N)]
def mmax(M): return max(abs(x) for r in M for x in r)

# ------------------------------------------------------------------------------------------------ [bit] the torsion-free connection and the Euler-Lagrange reduction of a frame variation
def omega_lc(Gv, e, Sk):
    """A3's closed form omega_LC(e) as a first-order jet (the engine's d, the inverse frame as a series); under trunc(lam=1) it carries the variation of e"""
    return omega_closed_form(Gv, e, Sk, NV, 1, Dpre=anholonomy(Gv, e, NV, 1))[0]
def el_reduce(Gv, e, Lfun):
    """[bit] tau_a (3-forms, values at the origin) with delta int L = int delta e^a ^ tau_a for L = Lfun(ep) depending on ep and d ep (first order):
       the dx^mu-component of tau_a is A^mu_a - sum_nu d_nu B^{nu mu}_a, A^mu_a = lam-part of L(e + lam dx^mu) (16 constant variations),
       B^{nu mu}_a = lam-part of L(e + lam x^nu dx^mu) - x^nu A^mu_a (64 linear variations); everything to x-degree 1, so tau_a(0) is exact"""
    Fm = Gv.Fm; tau = [{} for _ in range(N)]
    for a in range(N):
        for mu in range(N):
            ep = list(e); ep[a] = Fm.add(e[a], {1 << mu: LAMV})
            with trunc(N, xdeg=1, lam=1): A = lamp(Lfun(ep)).get(FULL, {})
            tot = dict(A)
            for nu in range(N):
                ep = list(e); ep[a] = Fm.add(e[a], {1 << mu: xlam(nu)})
                with trunc(N, xdeg=1, lam=1): Bl = lamp(Lfun(ep)).get(FULL, {})
                B = padd(Bl, tp(gs.pmul(xv(nu), A), 1), -1)
                tot = padd(tot, pder(B, nu), -1)
            c = v0(tot)
            if c: tau[a][FULL ^ (1 << mu)] = cst(c * (-1) ** mu)                       # dx^mu ^ dx^(hat mu) = (-1)^mu dx^0123
    return tau
def L_fast(Gv, e, om, psi, m):
    """E2's L_D with d psi taken from the full psi and every other factor from its 1-jet: the same 4-form to x-degree 1 with fewer products"""
    Fm = Gv.Fm; sq = Gv.L.sq; psi1 = {S: tp(p, 1) for S, p in psi.items()}
    Dpsi = {S: Fm.d({0: p}) for S, p in psi.items()}
    for A, g in enumerate(Gv.L.gens):
        for S, p in psi1.items():
            msk, s = bmul(g, S, sq); Dpsi[msk] = Fm.add(Dpsi.get(msk, {}), Fm.wedge(om[A], {0: p}), F(s, 2))
    tot = S4.L_of_D(Gv, e, {k: v for k, v in Dpsi.items() if v}, psi1, E2.theta_forms(Gv, e))
    if m:
        mass = {}
        for S, p in psi1.items(): mass = padd(mass, gs.pmul(p, p), E2.rsg(S) * bmul(S, S, sq)[1])
        tot = Fm.add(tot, Fm.wedge({0: mass}, E2.vol_form(Gv, e)), -F(m))
    return tot
def L_lc(Gv, psi, m, Sk): return lambda ep: L_fast(Gv, ep, omega_lc(Gv, ep, Sk), psi, m)
def L_fixed(Gv, om, psi, m): return lambda ep: L_fast(Gv, ep, om, psi, m)
def L_spin(Gv, S, Sk):
    """the piece (delta_e omega_LC)^A ^ S_A with the spin forms S held fixed: lam-part of sum_A omega_LC(ep)^A ^ S_A"""
    def f(ep):
        om = omega_lc(Gv, ep, Sk); tot = {}
        for A in range(Gv.G): tot = Gv.Fm.add(tot, Gv.Fm.wedge(om[A], S[A]))
        return tot
    return f

# ------------------------------------------------------------------------------------------------ [bit] components at the origin
def lower_at0(Gv, e, X, vol0):
    """X_ab = sq_a X^a_b with X_b = X^a_b Theta_a, i.e. X^a_b = (e^a ^ X_b)/vol at the origin (E2S4's lowering)"""
    Fm = Gv.Fm
    return [[LOR[a] * top0(Fm.wedge(form0(e[a]), form0(X[b]))) / vol0 for b in range(N)] for a in range(N)]
def ds_matrix(lhsB, vol0):
    """(D S)_ab with D S_ab = (D S)_ab vol, antisymmetric extension of the six pair values"""
    M = [[F(0)] * N for _ in range(N)]
    for A, (a, b) in enumerate(PAIRS): M[a][b] = lhsB[A] / vol0; M[b][a] = -M[a][b]
    return M
def dual_of(M):
    """eps-dual: dual_ab = sum_{c<d} eps_abcd sq_c sq_d M_cd"""
    return [[sum((E2.perm([a, b, c, d]) * LOR[c] * LOR[d] * M[c][d] for (c, d) in PAIRS), F(0)) for b in range(N)] for a in range(N)]
def inv1(p):
    """1/p to x-degree 1 (p a polynomial of degree <= 1 with p(0) != 0)"""
    p0 = v0(p); out = {ZK: 1 / p0}
    for k, v in p.items():
        if k != ZK: out[k] = -v / p0 ** 2
    return out
def div_sigma(Gv, om0, e1, S, E0, volp):
    """[bit] nabla_c sigma^c_A at the origin, sigma^c_A = (e^c ^ S_A)/vol as first-order jets; nabla acts on the vector index c with the h table
       and on the lower bivector index A with the f table (as D_dual_bivector does); om0 = the connection at the origin"""
    Fm = Gv.Fm; L = Gv.L; ivol = inv1(tp(volp, 1))
    with trunc(N, xdeg=1):
        sig = [[tp(gs.pmul(Fm.wedge(e1[c], S[A]).get(FULL, {}), ivol), 1) for A in range(Gv.G)] for c in range(N)]
    out = []
    for A in range(Gv.G):
        tot = F(0)
        for c in range(N):
            D1 = Fm.d({0: sig[c][A]}) if sig[c][A] else {}
            for (B, b), (cc, h) in L.h.items():
                if cc == c and sig[b][A]: D1 = Fm.add(D1, Fm.wedge(om0[B], {0: sig[b][A]}), h)
            for (B, A2), (C, f) in L.f.items():
                if A2 == A and sig[c][C]: D1 = Fm.add(D1, Fm.wedge(om0[B], {0: sig[c][C]}), -F(f, 2))
            tot += sum((E0[mu][c] * v0(D1.get(1 << mu, {})) for mu in range(N)), F(0))
        out.append(tot)
    return out

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
def std_eval(st, e, psi, x):
    """e^a_mu, d_k e^a_mu, chi = M(psi) u and d_mu chi at the point x (polynomial fields evaluated in floats)"""
    x = np.asarray(x, float)
    em = np.array([[S4.peval(e[a].get(1 << mu, {}), x) for mu in range(N)] for a in range(N)])
    dem = np.array([[[S4.peval(std_der(e[a].get(1 << mu, {}), k), x) for mu in range(N)] for a in range(N)] for k in range(N)])
    chi = st.chi({S: S4.peval(p, x) for S, p in psi.items()}); dchi = [st.chi({S: S4.peval(std_der(p, mu), x) for S, p in psi.items()}) for mu in range(N)]
    return em, dem, chi, dchi
def std_omega(em, dem, eta):
    """omega_mu^{pq} (both upper, antisymmetric) of the Christoffel spin connection from the frame and its first derivatives:
       omega_mu^a_b = e^a_nu (d_mu E^nu_b + Gamma^nu_{mu lam} E^lam_b), d E = -E (d e) E, Gamma from g = e^T eta e (E1's StdSpin.omega, as a function of (e, de))"""
    E = np.linalg.inv(em); g = em.T @ eta @ em; gi = np.linalg.inv(g)
    dg = np.array([dem[k].T @ eta @ em + em.T @ eta @ dem[k] for k in range(N)])
    Gam = 0.5 * (np.einsum('ls,msn->lmn', gi, dg) + np.einsum('ls,nsm->lmn', gi, dg) - np.einsum('ls,smn->lmn', gi, dg))
    dE = np.array([-E @ dem[k] @ E for k in range(N)])
    omab = np.einsum('an,mnb->mab', em, dE) + np.einsum('an,nml,lb->mab', em, Gam, E)
    return omab * np.diag(eta)[None, None, :]
def std_nabla(st, em, W, chi, dchi):
    E = np.linalg.inv(em)
    return [sum(E[mu, a] * (dchi[mu] + 0.5 * sum(W[mu, p, q] * (st.G[p] @ st.G[q] @ chi) for (p, q) in PAIRS)) for mu in range(N)) for a in range(N)]
def std_dens(st, em, dem, chi, dchi, m):
    """det(e) [Re(chibar i Gamma^a nabla_a chi) - m chibar chi] with the Christoffel spin connection of (e, de): a plain function of 16 + 64 + 8 + 32 numbers"""
    nab = std_nabla(st, em, std_omega(em, dem, st.eta), chi, dchi); bar = st.bar(chi)
    ell = sum((1j * (bar @ st.Gup[c] @ nab[c])).real for c in range(N)) - m * (bar @ chi).real
    return ell * np.linalg.det(em)
def std_hilbert(st, e, psi, m, h=1e-4, hB=1e-2, hx=1e-4):
    """[std] tau^b_a = e^b_mu [dL/de^a_mu - d_nu dL/d(d_nu e^a_mu)] / det at the origin, L = det(e) l, by 4-point stencils (the frame entries and
       their derivatives are independent variables of the density; chi, d chi fixed; the density is linear in de, so its stencil is exact) and
       central differences in x for the momenta"""
    def A_at(x):
        em, dem, chi, dchi = std_eval(st, e, psi, x); A = np.zeros((N, N))
        for a in range(N):
            for mu in range(N):
                def f(t): M = em.copy(); M[a, mu] += t; return std_dens(st, M, dem, chi, dchi, m)
                A[a, mu] = (8 * (f(h) - f(-h)) - (f(2 * h) - f(-2 * h))) / (12 * h)
        return A
    def B_at(x, nu):
        em, dem, chi, dchi = std_eval(st, e, psi, x); B = np.zeros((N, N))
        for a in range(N):
            for mu in range(N):
                def f(t): D = dem.copy(); D[nu, a, mu] += t; return std_dens(st, em, D, chi, dchi, m)
                B[a, mu] = (8 * (f(hB) - f(-hB)) - (f(2 * hB) - f(-2 * hB))) / (12 * hB)
        return B
    x0 = np.zeros(N); A0 = A_at(x0); dB = np.zeros((N, N))
    for nu in range(N):
        ev = np.zeros(N); ev[nu] = 1.0
        p = [B_at(k * hx * ev, nu) for k in (1, -1, 2, -2)]
        dB += (8 * (p[0] - p[1]) - (p[2] - p[3])) / (12 * hx)
    em, dem, chi, dchi = std_eval(st, e, psi, x0); det = np.linalg.det(em); EL = A0 - dB
    return np.array([[sum(em[b, mu] * EL[a, mu] for mu in range(N)) / det for a in range(N)] for b in range(N)]), np.array([[sum(em[b, mu] * A0[a, mu] for mu in range(N)) / det for a in range(N)] for b in range(N)])
def std_can(st, e, psi, m, x):
    """[std] at x: textbook canonical T^b_a = Re (i/2)(chibar Gamma^b nabla_a chi - nabla_a chibar Gamma^b chi) - delta^b_a l, the spin current sigma^c_ab, omega, E"""
    em, dem, chi, dchi = std_eval(st, e, psi, x); W = std_omega(em, dem, st.eta); E = np.linalg.inv(em)
    nab = std_nabla(st, em, W, chi, dchi); bar = st.bar(chi); nbar = [n_.conj() @ st.Gup[0] for n_ in nab]
    ell = sum((1j * (bar @ st.Gup[c] @ nab[c])).real for c in range(N)) - m * (bar @ chi).real
    T = np.array([[(0.5j * (bar @ st.Gup[b] @ nab[a] - nbar[a] @ st.Gup[b] @ chi)).real for a in range(N)] for b in range(N)]) - ell * np.eye(N)
    sg = st.sigma(chi); sig = np.zeros((N, N, N))
    for c in range(N):
        for A, (p, q) in enumerate(PAIRS): sig[c, p, q] = sg[(c, A)]; sig[c, q, p] = -sg[(c, A)]
    return dict(T=T, sig=sig, W=W, E=E, ell=ell)
def std_belinfante(st, e, psi, m, hx=1e-3):
    """[std] V_ab = nabla_c sigma^c_ab at the origin (sigma^c_ab the textbook spin current, nabla with the Christoffel spin connection on all three indices;
       d_mu sigma by central differences)"""
    d0 = std_can(st, e, psi, m, np.zeros(N)); E, W, sig = d0['E'], d0['W'], d0['sig']; dsig = np.zeros((N, N, N, N))
    for mu in range(N):
        ev = np.zeros(N); ev[mu] = 1.0
        p = [std_can(st, e, psi, m, k * hx * ev)['sig'] for k in (1, -1, 2, -2)]
        dsig[mu] = (8 * (p[0] - p[1]) - (p[2] - p[3])) / (12 * hx)
    wl = lambda d, p, q: sum(E[mu, d] * W[mu, p, q] for mu in range(N)) * LOR[q]                  # omega_d^p_q = E^mu_d omega_mu^{pq} eta_qq
    V = np.zeros((N, N))
    for a in range(N):
        for b in range(N):
            V[a, b] = sum(E[mu, c] * dsig[mu, c, a, b] for c in range(N) for mu in range(N)) \
                + sum(wl(c, c, d) * sig[d, a, b] - wl(c, d, a) * sig[c, d, b] - wl(c, d, b) * sig[c, a, d] for c in range(N) for d in range(N))
    return V, d0
def lowered(T): return np.array([[LOR[a] * T[a][b] for b in range(N)] for a in range(N)])
def fl(M): return np.array([[float(x) for x in r] for r in M])
def rel(X, Y): return float(np.max(np.abs(X - Y)) / max(1e-300, float(np.max(np.abs(Y)))))
def rsz(X, Y): return float(np.max(np.abs(X)) / max(1e-300, float(np.max(np.abs(Y)))))

# ------------------------------------------------------------------------------------------------ main
def main():
    K = 3
    if '--seeds' in sys.argv: K = int(sys.argv[sys.argv.index('--seeds') + 1])
    rng = random.Random(7731); Gv = Grav(N, Lie(LOR)); Fm = Gv.Fm; st = E2.Std(); Sk = koszul_S(N, LOR, Gv.L)
    seeds = []
    for k in range(K):
        e, _, psi = S4.strong_fields(rng); m = F(rng.randint(1, 9), rng.randint(1, 4))
        Kc = [{1 << mu: cst(rng.randint(-3, 3)) for mu in range(N)} for _ in range(Gv.G)]
        seeds.append(dict(e=e, psi=psi, m=m, Kc=Kc))

    head('(1) Hilbert and canonical stress by the same Euler-Lagrange reduction (16 constant + 64 linear frame variations); B = tau^LC - tau  [strong fields, x-degree 2, %d seeds]' % K)
    fitB, fitDS, fitDual, std_rows = [], [], [], []
    for k, sd in enumerate(seeds):
        e, psi, m = sd['e'], sd['psi'], sd['m']; e1 = [tf(x, 1) for x in e]
        oml = omega_lc(Gv, e, Sk)
        with trunc(N, xdeg=1): T0l = Gv.torsion(oml, e)
        chk('bit', all(is0(x) for x in T0l), 'seed %d: omega_LC (A3 closed form, 1-jet) is torsion-free to first order (precondition)' % k)
        D = S4.at_point(Gv, e, oml, psi, m); vol0 = D['vol0']
        tH = el_reduce(Gv, e, L_lc(Gv, psi, m, Sk)); tB = el_reduce(Gv, e, L_spin(Gv, D['S'], Sk))
        if k == 0:
            tF = el_reduce(Gv, e, L_fixed(Gv, oml, psi, m))
            chk('bit', all(is0(Fm.add(tF[a], form0(D['tau'][a]), -1)) for a in range(N)), 'seed 0: at fixed omega the 64 linear variations add nothing: the reduction gives E2S4\'s canonical tau_a (no derivative of e in L_D at fixed omega)')
        tl = lower_at0(Gv, e, D['tau'], vol0); tHl = lower_at0(Gv, e, tH, vol0); Bl = lower_at0(Gv, e, tB, vol0)
        chk('bit', all(is0(Fm.add(Fm.add(tH[a], form0(D['tau'][a]), -1), tB[a], -1)) for a in range(N)) and any(tB[a] for a in range(N)),
            'seed %d: tau^LC_a = tau_a + B_a exactly at the origin (B_a the reduction of (delta_e omega_LC)^A ^ S_A; off shell, B != 0)' % k)
        chk('bit', all(x == 0 for r in sym(Bl) for x in r), 'seed %d: B_ab is antisymmetric: the Hilbert stress has the symmetric part of the canonical one, tau^LC_(ab) = tau_(ab)' % k)
        DSm = ds_matrix(D['lhsB'], vol0); dual = dual_of(DSm)
        chk('bit', mmax(DSm) != 0 and mmax(dual) != 0, 'seed %d: (D S)_ab and its eps-dual are non-zero (both basis terms are tested)' % k)
        for a in range(N):
            for b in range(N): fitB.append(Bl[a][b]); fitDS.append(DSm[a][b]); fitDual.append(dual[a][b])
        e0, E0, det = E0_of(e, N, NV); volp = E2.vol_form(Gv, e1).get(FULL, {})
        divs = div_sigma(Gv, [tf(x, 0) for x in oml], e1, D['S'], E0, volp)
        chk('bit', all(divs[A] == DSm[a][b] for A, (a, b) in enumerate(PAIRS)) and any(divs),
            'seed %d: D S_ab = (nabla_c sigma^c_ab) vol: the covariant exterior derivative of the spin 3-form (f table) is the covariant divergence of its frame components (h table) on the torsion-free connection' % k)
        omp = [Fm.add(oml[A], sd['Kc'][A]) for A in range(Gv.G)]; Dp = S4.at_point(Gv, e, omp, psi, m); DSp = ds_matrix(Dp['lhsB'], vol0)
        divp = div_sigma(Gv, [tf(x, 0) for x in omp], e1, Dp['S'], E0, volp)
        chk('ctl', any(divp[A] != DSp[a][b] for A, (a, b) in enumerate(PAIRS)), 'seed %d: with torsion (omega_LC + K, K a random Lorentz-valued 1-form) D S_ab != (nabla_c sigma^c_ab) vol: the torsion term sigma^c D Theta_c remains' % k)
        chk('ctl', any(Bl[a][b] != -DSp[a][b] / 2 for a in range(N) for b in range(N)), 'seed %d: the closed form -(1/2) D S with D built from the torsionful omega_LC + K is not B' % k)
        chk('bit', all(tHl[a][b] - tHl[b][a] == D['pairB'][A] / (2 * vol0) for A, (a, b) in enumerate(PAIRS)) and any(D['pairB']),
            'seed %d: off shell tau^LC_ab - tau^LC_ba = (1/2)(B_ab psi).EL / vol exactly (the Lorentz Noether identity in Hilbert form)' % k)
        chk('ctl', any(tHl[a][b] != tHl[b][a] for a in range(N) for b in range(N)), 'seed %d: off the Dirac shell tau^LC_ab is NOT symmetric (max |tau^LC_ab - tau^LC_ba| = %.4g)' % (k, float(mmax(asym(tHl)))))
        # [std]
        TH, TA = std_hilbert(st, e, psi, float(m)); V, d0 = std_belinfante(st, e, psi, float(m)); Tc = d0['T']
        dT = lowered(-TH) - lowered(Tc); Vl = V                                           # T_H := -(numerical functional derivative): E2S4's frame variation = -T
        sc = float(np.max(np.abs(Tc)))
        chk('std', rsz((dT + dT.T) / 2, dT) < 1e-6 and rsz(dT, Tc) > 1e-3, 'seed %d: [std] T_H - T_can is antisymmetric (|sym|/|T_H - T_can| = %.1e; |T_H - T_can|/|T_can| = %.2g)' % (k, rsz((dT + dT.T) / 2, dT), rsz(dT, Tc)))
        cs = float(np.sum(dT * Vl) / np.sum(Vl * Vl)); res = rel(dT, cs * Vl)
        chk('std', res < 1e-6 and float(np.max(np.abs(Vl))) > 1e-3 * sc, 'seed %d: [std] T_H,ab - T_can,ab = c nabla^c sigma_cab with c = %.9f (residual %.1e; textbook Belinfante combination of the totally antisymmetric spin current)' % (k, cs, res))
        chk('ctl', rel(lowered(-TH), lowered(Tc)) > 1e-3, 'seed %d: [std] without the Belinfante term T_H != T_can (rel %.2g)' % (k, rel(lowered(-TH), lowered(Tc))))
        chk('bit==std', rel(fl([[tHl[a][b] * LOR[a] for b in range(N)] for a in range(N)]), TH) < 1e-6, 'seed %d: engine tau^LC^b_a = [std] numerical functional derivative of det(e) l (rel %.1e)' % (k, rel(fl([[tHl[a][b] * LOR[a] for b in range(N)] for a in range(N)]), TH)))
        chk('bit==std', rel(fl(Bl), -dT) < 1e-6, 'seed %d: engine B_ab = -(T_H - T_can)_ab [std] (rel %.1e)' % (k, rel(fl(Bl), -dT)))
        std_rows.append(cs)
        tick('seed %d off shell' % k)
    w, rank, cons = S4.fit([fitDS, fitDual], fitB)
    chk('bit', cons and rank == 2 and w == [F(-1, 2), 0], 'exact fit over %d seeds x 16 components (rank %d): B_ab = beta (D S)_ab + beta\' dual(D S)_ab with (beta, beta\') = (%s); predicted (-1/2, 0)' % (K, rank, ', '.join(map(str, w)) if w else 'none'))
    chk('ctl', any(b != ds / 2 for b, ds in zip(fitB, fitDS)), 'beta = +1/2 (the opposite sign of the Belinfante term): fails')
    chk('std', all(abs(c - 0.5) < 1e-6 for c in std_rows), '[std] c = +1/2 on every seed: T_H = T_can + (1/2) nabla^c sigma_cab, so with tau = -T the engine beta = -1/2 is the textbook sign')
    tick('fit')

    head('(2) on the Dirac shell (d_0 psi at the origin solved from EL(omega_LC) = 0): the Hilbert stress is symmetric, the canonical one keeps (1/2) D S (Rosenfeld)')
    for k, sd in enumerate(seeds):
        e, psi, m = sd['e'], sd['psi'], sd['m']; oml = omega_lc(Gv, e, Sk)
        pon, rank, cons = S4.onshell_psi(Gv, e, oml, psi, m)
        chk('bit', pon is not None and rank == 8, 'seed %d: the torsion-free Dirac equation fixes d_0 psi at the point (rank %d of 8)' % (k, rank))
        if pon is None: continue
        Don = S4.at_point(Gv, e, oml, pon, m); vol0 = Don['vol0']
        tHon = el_reduce(Gv, e, L_lc(Gv, pon, m, Sk)); tHl = lower_at0(Gv, e, tHon, vol0); tl = lower_at0(Gv, e, Don['tau'], vol0); DSm = ds_matrix(Don['lhsB'], vol0)
        chk('bit', all(v == 0 for v in Don['EL0'].values()) and all(tHl[a][b] == tHl[b][a] for a in range(N) for b in range(N)) and mmax(tHl) != 0,
            'seed %d: on shell tau^LC_ab is symmetric (EL = 0 at the point): the Hilbert stress of the Dirac field' % k)
        chk('bit', all(tl[a][b] - tl[b][a] == DSm[a][b] for a in range(N) for b in range(N)) and mmax(DSm) != 0,
            'seed %d: on shell the canonical tau_[ab] = (1/2)(D S)_ab, non-zero (Rosenfeld: the antisymmetric part of the canonical stress is the spin divergence)' % k)
        chk('ctl', any(tl[a][b] != tl[b][a] for a in range(N) for b in range(N)), 'seed %d: the canonical tau(omega_LC) in place of tau^LC on shell: antisymmetric part non-zero (B omitted; max |tau_ab - tau_ba| = %.4g)' % (k, float(mmax(asym(tl)))))
        chk('bit', all(tHl[a][b] + tHl[b][a] == tl[a][b] + tl[b][a] for a in range(N) for b in range(N)), 'seed %d: on shell tau^LC_(ab) = tau_(ab): the symmetrised canonical stress IS the Hilbert stress' % k)
        TH, _ = std_hilbert(st, e, pon, float(m)); d0 = std_can(st, e, pon, float(m), np.zeros(N)); Th = lowered(-TH); Tcl = lowered(d0['T'])
        chk('std', rsz((Th - Th.T) / 2, Th) < 1e-6 and rsz((Tcl - Tcl.T) / 2, Tcl) > 1e-3 and abs(d0['ell']) < 1e-8 * max(1.0, float(np.max(np.abs(Tcl)))),
            'seed %d: [std] on the engine-solved jets: T_H symmetric (|asym|/|T_H| = %.1e), T_can not (%.2g), l = %.1e' % (k, rsz((Th - Th.T) / 2, Th), rsz((Tcl - Tcl.T) / 2, Tcl), d0['ell']))
        chk('bit==std', rel(fl([[tHl[a][b] * LOR[a] for b in range(N)] for a in range(N)]), TH) < 1e-6, 'seed %d: on shell engine tau^LC = [std] numerical functional derivative (rel %.1e)' % (k, rel(fl([[tHl[a][b] * LOR[a] for b in range(N)] for a in range(N)]), TH)))
        tick('seed %d on shell' % k)
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('E2S4-belinfante')

if __name__ == '__main__': main()
