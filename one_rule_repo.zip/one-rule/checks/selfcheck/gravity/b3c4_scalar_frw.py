#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""B3C4S: Einstein-scalar cosmology as a SOLVED system on the bit-rule engine (series in t; the constraint is propagated).   python3 b3c4_scalar_frw.py

 n = 4, signature (+,-,-,-), polynomials in 5 slots (slot 0 = t - t0, slots 1..3 = x, slot 4 = lam of B3's frame variation).
 Frame (C4): e^0 = dt, e^i = a(t) (1 - k r^2/4) dx^i, a(t) = sum a_j t^j;  phi = phi(t) = sum phi_j t^j;  V = sum vc[j] phi^j.
 [bit] X_a := E_a(c) - kappa tau_a (E_a: A3 omega, engine curvature and Einstein form; tau_a: B3 matter_variation of L_phi = (1/2) dphi ^ *dphi - V vol_e),
       EL_phi = -(d*dphi + V' vol_e) (B3).  Residual series at the spatial origin:  R00 = dx^123-coefficient of X_0 (= -a^3 N^0_0),
       Rii = dx^{hat i}-coefficient of X_i, RKG = dx^0123-coefficient of EL_phi.
 Solver: a_{m+2} from Rii = 0 at order t^m, phi_{m+2} from RKG = 0 at order t^m (affine; slope from a second engine evaluation); the 00 equation is
       imposed only at t = 0.  Truncation: own product filter (t-degree, spatial degree) on top of b1lib.trunc; exact for every kept coefficient.
 [std] the textbook Friedmann-Klein-Gordon recursion on plain rationals (no engine), DOP853 (float).
 Exports (no engine object at import): sbound, tser, frame_phi, engine_eval, residuals, engine_solve, std_eqs, std_solve, constraint_c, V_at,
       fluid_series_forms, std_fluid_solve, series helpers pad/smul/sder/spoly."""
import os, sys, time, random, math
_here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _here)
from b1lib import *
import b1lib
import g2_hodge as H
import b3_matter as B3
import c4_frw as C4

n = 4; NV = 5; SQ = LORENTZ(4); FULL = 15
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ truncation by t-degree and spatial degree (on top of b1lib.trunc)
_SB = {'t': None, 's': None}
def _pmul_sb(a, b):
    tm, sm = _SB['t'], _SB['s']
    if tm is None and sm is None: return b1lib._pmul(a, b)
    TR = b1lib._TR; xd, lm, nn = TR['xdeg'], TR['lam'], TR['n']; r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            if tm is not None and k1[0] + k2[0] > tm: continue
            if sm is not None and k1[1] + k1[2] + k1[3] + k2[1] + k2[2] + k2[3] > sm: continue
            k = tuple(x + y for x, y in zip(k1, k2))
            if xd is not None and sum(k[:nn]) > xd: continue
            if lm is not None and k[nn] > lm: continue
            x = r.get(k, 0) + v1 * v2
            if x == 0: r.pop(k, None)
            else: r[k] = x
    return r
b1lib.gs.pmul = _pmul_sb
class sbound:
    """with sbound(t, s): engine products drop monomials of t-degree > t or spatial degree > s (exact for the kept ones)"""
    def __init__(self, t, s): self.new = {'t': t, 's': s}
    def __enter__(self): self.old = dict(_SB); _SB.update(self.new)
    def __exit__(self, *a): _SB.update(self.old)

# ------------------------------------------------------------------------------------------------ [bit] engine evaluation on a series frame
def tser(p, K): return [p.get((j, 0, 0, 0, 0), F(0)) for j in range(K + 1)]
def frame_phi(ac, pc, k): return C4.frw_frame([F(x) for x in ac], k=k, nv=NV), C4.poly_t([F(x) for x in pc], NV)
def engine_grav(Gv, S, e, c, K, k, sE=0):
    """[bit] A3 omega (t-order K+1, spatial order 1+sE if k != 0) and E_a(c) (t-order K, spatial order sE)"""
    sp = (1 + sE) if k else 0
    with sbound(K + 1, sp): om = omega_closed_form(Gv, e, S, NV, K + 1 + sp)[0]
    with sbound(K, sE), trunc(4, xdeg=K + 1 + sE): R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(c))
    return om, Ea
def engine_matter(Gv, e, phi, vc, K, sk=1):
    Lf = lambda ep, Ep: B3.L_scalar(Gv, ep, Ep, phi, vc, sk, nv=NV)
    with sbound(K, 0): tau = B3.matter_variation(Gv, e, Lf, xdeg=K, nv=NV)
    with sbound(K + 1, 0), trunc(4, xdeg=K + 1):
        E, _ = inverse_series(frame_matrix(e, 4), 4, NV, K + 1); EL = B3.EL_scalar(Gv, e, E, phi, vc, sk, nv=NV)
    return tau, EL
def engine_eval(Gv, S, ac, pc, vc, kap, c, k, K, sk=1, kfac=F(1)):
    """[bit] X_a = E_a(c) - kfac kappa tau_a and EL_phi on the polynomial frame of coefficients ac, field pc, through t-order K at the spatial origin"""
    Fm = Gv.Fm; e, phi = frame_phi(ac, pc, k)
    om, Ea = engine_grav(Gv, S, e, c, K, k); tau, EL = engine_matter(Gv, e, phi, vc, K, sk)
    X = [Fm.add(Ea[a], tau[a], -F(kap) * kfac) for a in range(4)]
    return dict(e=e, phi=phi, om=om, Ea=Ea, tau=tau, EL=EL, X=X, K=K)
def residuals(ev, K=None):
    K = ev['K'] if K is None else K
    comp = {(a, mu): tser(ev['X'][a].get(FULL ^ (1 << mu), {}), K) for a in range(4) for mu in range(4)}
    return comp, tser(ev['EL'].get(FULL, {}), K)
def engine_solve(Gv, S, a01, p01, vc, kap, c, k, N):
    """[bit] a_2..a_N and phi_2..phi_N from Rii (i = 1) and RKG at orders 0..N-2; the 00 equation is not used"""
    ac = [F(x) for x in a01]; pc = [F(x) for x in p01]
    for m in range(N - 1):
        r = []
        for trial in (F(0), F(1)):
            comp, kg = residuals(engine_eval(Gv, S, ac + [trial], pc + [trial], vc, kap, c, k, m))
            r.append((comp[(1, 1)][m], kg[m]))
        sa, sp = r[1][0] - r[0][0], r[1][1] - r[0][1]
        if sa == 0 or sp == 0: raise ValueError('zero slope at order %d' % m)
        ac.append(-r[0][0] / sa); pc.append(-r[0][1] / sp)
    return ac, pc
def fluid_series_forms(Gv, e, rho, p, K):
    """C4's fluid_forms (T_a = T^b_a Theta_b, T^0_0 = rho, T^i_i = -p, u = E_0) with nv = 5 and t-order K (private copy for series)"""
    Fm = Gv.Fm
    with sbound(K, 0), trunc(4, xdeg=K):
        th = H.theta_forms(e, Fm, NV)
        return [Fm.wedge({0: rho}, th[0])] + [Fm.wedge({0: scale(p, -1)}, th[i]) for i in (1, 2, 3)]

# ------------------------------------------------------------------------------------------------ [std] plain series (no engine)
def pad(A, K): return (list(A) + [F(0)] * (K + 1))[:K + 1]
def smul(A, B, K):
    A = pad(A, K); B = pad(B, K); return [sum(A[i] * B[j - i] for i in range(j + 1)) for j in range(K + 1)]
def sder(A, K): A = pad(A, K + 1); return [(j + 1) * A[j + 1] for j in range(K + 1)]
def spoly(vc, P, K):
    out = [F(0)] * (K + 1); pw = pad([F(1)], K)
    for j, cc in enumerate(vc):
        if j: pw = smul(pw, P, K)
        out = [o + cc * w for o, w in zip(out, pw)]
    return out
def dVc(vc): return [j * c for j, c in enumerate(vc)][1:] or [F(0)]
def V_at(vc, x): return sum(c * x ** j for j, c in enumerate(vc))
def constraint_c(a0, a1, p0, p1, vc, kap, k):
    """[std] c such that 3H^2 + 3k/a^2 - 3c = kappa (phi'^2/2 + V) at t = 0"""
    return (3 * (a1 / a0) ** 2 + 3 * F(k) / a0 ** 2 - kap * (p1 ** 2 / 2 + V_at(vc, p0))) / 3
def std_eqs(ac, pc, vc, kap, c, k, K, fr=3):
    """[std, recalled] textbook equations times a^2 (ii, 00) and a (KG) as series to order K:
       ii: 2 a a'' + a'^2 + k - 3c a^2 + kappa a^2 (phi'^2/2 - V);  KG: a phi'' + fr a' phi' + a V'(phi);  00: 3 a'^2 + 3k - 3c a^2 - kappa a^2 (phi'^2/2 + V)"""
    a = pad(ac, K + 2); p = pad(pc, K + 2)
    a1 = sder(a, K + 1); a2 = sder(a1, K); p1 = sder(p, K + 1); p2 = sder(p1, K)
    aa = smul(a, a, K); V = spoly(vc, p, K); Vp = spoly(dVc(vc), p, K); kin = [x / 2 for x in smul(p1, p1, K)]
    one = pad([F(k)], K)
    ii = [2 * x + y + o - 3 * c * z + kap * w for x, y, o, z, w in zip(smul(a, a2, K), smul(a1, a1, K), one, aa, smul(aa, [u - v for u, v in zip(kin, V)], K))]
    kg = [x + fr * y + z for x, y, z in zip(smul(a, p2, K), smul(a1, p1, K), smul(a, Vp, K))]
    c00 = [3 * y + 3 * o - 3 * c * z - kap * w for y, o, z, w in zip(smul(a1, a1, K), one, aa, smul(aa, [u + v for u, v in zip(kin, V)], K))]
    return ii, kg, c00
def std_solve(a01, p01, vc, kap, c, k, N, fr=3):
    """[std] the same order-by-order recursion on plain rationals: a_{m+2} = -ii_m / (2 a0 (m+2)(m+1)), phi_{m+2} = -kg_m / (a0 (m+2)(m+1))"""
    ac = [F(x) for x in a01]; pc = [F(x) for x in p01]
    for m in range(N - 1):
        ii, kg, _ = std_eqs(ac + [F(0)], pc + [F(0)], vc, kap, c, k, m, fr)
        ac.append(-ii[m] / (2 * ac[0] * (m + 2) * (m + 1))); pc.append(-kg[m] / (ac[0] * (m + 2) * (m + 1)))
    return ac, pc
def std_fluid_solve(a01, rho0, w, kap, c, k, N, beta=None):
    """[std] FRW + fluid p = w rho: 2 a a'' + a'^2 + k - 3c a^2 + kappa a^2 w rho = 0 and a rho' + beta a' rho = 0 (beta = 3(1+w) correct)"""
    beta = 3 * (1 + w) if beta is None else beta
    ac = [F(x) for x in a01]; rc = [F(rho0)]
    for m in range(N - 1):
        a = pad(ac + [F(0)], m + 2); a1 = sder(a, m + 1); a2 = sder(a1, m); aa = smul(a, a, m)
        ii = 2 * smul(a, a2, m)[m] + smul(a1, a1, m)[m] + (k if m == 0 else 0) - 3 * c * aa[m] + kap * w * smul(aa, rc, m)[m]
        r = pad(rc + [F(0)], m + 1); cont = smul(a, sder(r, m), m)[m] + beta * smul(a1, r, m)[m]
        ac.append(-ii / (2 * ac[0] * (m + 2) * (m + 1))); rc.append(-cont / (ac[0] * (m + 1)))
    return ac, rc

# ================================================================================================ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    rng = random.Random(22)
    rq = lambda lo=-9, hi=9, d=5: F(rng.randint(lo, hi), rng.randint(1, d))
    Z = lambda L: all(x == 0 for x in L)

    # ------------------------------------------------------------------ 1. the components: fit, not assumed
    head('1. E_a(c) - kappa tau_a and EL_phi on FRW frames with phi(t): exact fit of N^b_a (X_a = -N^b_a Theta_b) and of EL_phi/vol_e at random points (k = 0, +1, -1)')
    r00, ri, rel, b00, bii, bel = [], [], [], [], [], []; ok_off = True
    for i in range(11):
        k = [0, 1, -1][i % 3]
        ac = [F(rng.randint(1, 9), rng.randint(1, 3))] + [rq() for _ in range(3)]; pc = [rq() for _ in range(4)]
        vc = [rq() for _ in range(5)]; kap = F(rng.randint(1, 9), rng.randint(1, 4)); c = rq()
        ev = engine_eval(Gv, S, ac, pc, vc, kap, c, k, 0); comp, kg = residuals(ev, 0)
        e0, E0, det = E0_of(ev['e'], 4, NV); Nm = mixed_from_components({key: v[0] for key, v in comp.items()}, e0, det, 4, s=-1)
        ok_off &= all(Nm[b][a] == 0 for a in range(4) for b in range(4) if a != b) and Nm[1][1] == Nm[2][2] == Nm[3][3]
        Hh = ac[1] / ac[0]; add = 2 * ac[2] / ac[0]; ka = F(k) / ac[0] ** 2; p1 = pc[1]; p2 = 2 * pc[2]; V = V_at(vc, pc[0]); Vp = V_at(dVc(vc), pc[0])
        row = [Hh ** 2, add, ka, c, kap * p1 ** 2, kap * V, kap * p2, kap * Hh * p1]
        r00.append(row); b00.append(Nm[0][0]); ri.append(row); bii.append(Nm[1][1])
        rel.append([p2, Hh * p1, Vp, p1 ** 2, ka * p1, V]); bel.append(kg[0] / ac[0] ** 3)
    f0 = solve_exact(r00, b00); fi = solve_exact(ri, bii); fe = solve_exact(rel, bel)
    s_ = lambda f: [str(x) for x in f[0]] if f[0] else None
    chk('bit', f0[3] and f0[1] == 8 and f0[0] == [3, 0, 3, -3, F(-1, 2), -1, 0, 0], 'N^0_0 = (alpha) . (H^2, a\'\'/a, k/a^2, c, kappa phi\'^2, kappa V, kappa phi\'\', kappa H phi\'): exact fit on 11 points (rank %d): %s, i.e. 3H^2 + 3k/a^2 - 3c = kappa (phi\'^2/2 + V): rho = phi\'^2/2 + V' % (f0[1], s_(f0)))
    chk('bit', fi[3] and fi[1] == 8 and fi[0] == [1, 2, 1, -3, F(1, 2), -1, 0, 0], 'N^i_i fit: %s, i.e. 2a\'\'/a + H^2 + k/a^2 - 3c = -kappa (phi\'^2/2 - V): p = phi\'^2/2 - V' % s_(fi))
    chk('bit', ok_off, 'N^b_a diagonal and isotropic (no off-diagonal component, N^1_1 = N^2_2 = N^3_3) at all 11 points')
    chk('bit', fe[3] and fe[1] == 6 and fe[0] == [-1, -3, -1, 0, 0, 0], 'EL_phi / vol_e = (beta) . (phi\'\', H phi\', V\'(phi), phi\'^2, (k/a^2) phi\', V): %s, i.e. EL_phi = -(phi\'\' + 3H phi\' + V\') vol_e: Klein-Gordon with friction 3H' % s_(fe))
    tick('part 1')

    # ------------------------------------------------------------------ 2. family A (k = 0): the engine solves the evolution system; the constraint is propagated
    N = 12; K = N - 2
    head('2. family A (k = 0, kappa = 1, c = 1/10, V = V0 + phi^2/2 + phi^4/4, a0 = 1, H0 = 1/2, phi0 = 1/2, phi1 = -1/3, V0 from the 00 equation at t = 0): engine series to order N = %d' % N)
    kapA, cA = F(1), F(1, 10); vA = [F(0), F(0), F(1, 2), F(0), F(1, 4)]; a01, p01 = (F(1), F(1, 2)), (F(1, 2), F(-1, 3))
    vA[0] = (3 * a01[1] ** 2 - 3 * cA) / kapA - (p01[1] ** 2 / 2 + V_at(vA, p01[0]))
    acA, pcA = engine_solve(Gv, S, a01, p01, vA, kapA, cA, 0, N); tick('engine solve A')
    evA = engine_eval(Gv, S, acA, pcA, vA, kapA, cA, 0, K); compA, kgA = residuals(evA)
    print('    V0 = %s;  a_j = %s;  phi_j = %s' % (vA[0], [str(x) for x in acA], [str(x) for x in pcA]))
    print('    R00 by order (fresh evaluation): %s' % [str(x) for x in compA[(0, 0)]])
    chk('bit', all(Z(compA[(i, i)]) for i in (1, 2, 3)) and Z(kgA), 'fresh engine evaluation on the solved polynomial frame: the three ii components of E_a - kappa tau_a and EL_phi vanish through order t^%d' % K)
    chk('bit', all(Z(compA[(a, mu)]) for a in range(4) for mu in range(4) if a != mu), 'the 12 off-diagonal components of E_a - kappa tau_a vanish through order t^%d' % K)
    chk('bit', Z(compA[(0, 0)]), 'the 00 component (Friedmann constraint), imposed only at t = 0, vanishes at every order 0..%d: the constraint is propagated' % K)
    asA, psA = std_solve(a01, p01, vA, kapA, cA, 0, N)
    chk('bit==std', asA == acA and psA == pcA, '[std] textbook Friedmann-Klein-Gordon recursion on plain rationals (no engine): a_0..a_%d and phi_0..phi_%d IDENTICAL to the engine-derived ones' % (N, N))
    ii_s, kg_s, c00_s = std_eqs(asA, psA, vA, kapA, cA, 0, K)
    chk('std', Z(ii_s) and Z(kg_s) and Z(c00_s), 'on its own series the textbook 00 equation also holds through t^%d (standard constraint propagation)' % K)
    # D on the solved frame (B2, B3 on shell)
    with sbound(K, 0), trunc(4, xdeg=K + 1): DE = Gv.D_covector(evA['om'], evA['Ea']); Dt = Gv.D_covector(evA['om'], evA['tau'])
    chk('bit', all(Z(tser(DE[a].get(FULL, {}), K - 1)) for a in range(4)) and any(not Z(tser(evA['Ea'][a].get(FULL ^ (1 << a), {}), K)) for a in range(4)), 'D E_a = 0 on the solved series frame through t^%d (B2 on a time-dependent frame; E_a itself non-zero)' % (K - 1))
    chk('bit', all(Z(tser(Dt[a].get(FULL, {}), K - 1)) for a in range(4)), 'D tau_a = 0 on the solved series through t^%d: on shell (EL_phi = 0) the matter Noether identity D tau_a = (i_a dphi) EL_phi gives conservation' % (K - 1))
    # DOP853 sanity
    import numpy as np
    from scipy.integrate import solve_ivp
    vf = [float(x) for x in vA]; kf, cf = float(kapA), float(cA)
    Vf = lambda x: sum(c * x ** j for j, c in enumerate(vf)); Vpf = lambda x: sum(j * c * x ** (j - 1) for j, c in enumerate(vf) if j)
    def rhs(t, y, kk=0):
        a, ad, p, pd = y; Hh = ad / a; pr = pd ** 2 / 2 - Vf(p)
        return [ad, a / 2 * (-kf * pr - Hh ** 2 - kk / a ** 2 + 3 * cf), pd, -3 * Hh * pd - Vpf(p)]
    sol = solve_ivp(rhs, (0, 0.2), [1.0, 0.5, 0.5, -1 / 3], method='DOP853', rtol=1e-13, atol=1e-15, dense_output=True)
    hi_a, hi_p = std_solve(a01, p01, vA, kapA, cA, 0, 20)
    ev_ser = lambda cs, t: sum(float(c) * t ** j for j, c in enumerate(cs))
    dev = max(max(abs(sol.sol(t)[0] - ev_ser(hi_a, t)), abs(sol.sol(t)[2] - ev_ser(hi_p, t))) for t in (0.05, 0.1, 0.2))
    def con(t):
        a, ad, p, pd = sol.sol(t); return 3 * (ad / a) ** 2 - 3 * cf - kf * (pd ** 2 / 2 + Vf(p))
    cmax = max(abs(con(t)) for t in np.linspace(0, 0.2, 21)); d8 = abs(sol.sol(0.1)[0] - ev_ser(acA, 0.1))
    chk('std', dev < 1e-12 and cmax < 1e-11, 'DOP853 (rtol 1e-13) vs the std series to order 20 at t = 0.05, 0.1, 0.2: max deviation %.1e; float constraint |3H^2 - 3c - kappa rho| <= %.1e on [0, 0.2]; (engine series of order %d at t = 0.1: |a - a_num| = %.1e)' % (dev, cmax, N, d8))
    tick('part 2')

    # ------------------------------------------------------------------ 3. violated constraint: propagated as a violation, a^3 N^0_0 constant
    head('3. family A with H0 = 3/5 (the 00 equation violated at t = 0, same V0): the engine evolution propagates the violation')
    a01v = (F(1), F(3, 5)); acV, pcV = engine_solve(Gv, S, a01v, p01, vA, kapA, cA, 0, N)
    evV = engine_eval(Gv, S, acV, pcV, vA, kapA, cA, 0, K); compV, kgV = residuals(evV); R00 = compV[(0, 0)]
    print('    R00 by order: %s' % [str(x) for x in R00])
    pred0 = -(3 * a01v[1] ** 2 - 3 * cA - kapA * (p01[1] ** 2 / 2 + V_at(vA, p01[0])))
    chk('bit', all(Z(compV[(i, i)]) for i in (1, 2, 3)) and Z(kgV) and all(Z(compV[(a, mu)]) for a in range(4) for mu in range(4) if a != mu), 'violated run: ii, KG and off-diagonal components vanish through t^%d (the evolution is solved)' % K)
    chk('ctl', R00[0] != 0 and R00[0] == pred0, 'control: the 00 residual at t^0 is the violation, R00(0) = %s = -(3H0^2 - 3c - kappa rho0)' % R00[0])
    chk('bit', Z(R00[1:]), 'propagation law: R00 (the dx^123 coefficient of E_0 - kappa tau_0 = -a^3 N^0_0) is CONSTANT through t^%d: N^0_0 = N^0_0(0) (a0/a)^3, the violation dilutes like a pressureless density' % K)
    ia3 = [F(1)]
    for _ in range(3):                                            # 1/a^3 as a series (plain)
        inv = [1 / acV[0]]
        for j in range(1, K + 1): inv.append(-sum(acV[i] * inv[j - i] for i in range(1, j + 1)) / acV[0])
        ia3 = smul(ia3, inv, K)
    N00 = [-R00[0] * x for x in ia3]; nz = sum(1 for x in N00 if x != 0)
    print('    N^0_0 = %s . (a0/a)^3 = %s  (non-zero at %d of %d orders)' % (-R00[0], [str(x) for x in N00], nz, K + 1))
    asV, psV = std_solve(a01v, p01, vA, kapA, cA, 0, N); _, _, c00V = std_eqs(asV, psV, vA, kapA, cA, 0, K)
    chk('bit==std', asV == acV and psV == pcV and c00V[0] != 0, '[std] the violated run: engine coefficients identical to the textbook recursion (which never uses the 00 equation either)')
    tick('part 3')

    # ------------------------------------------------------------------ 4. spatial curvature k = +1, -1
    Nk = 10; Kk = Nk - 2
    head('4. k = +1 and k = -1 (isotropic chart, at the spatial origin; omega to spatial degree 1): kappa = 2, V = phi^2/8, a0 = 1, H0 = 1/3, phi0 = 1, phi1 = 1/2, c from the 00 equation; series to order %d' % Nk)
    for k in (1, -1):
        vB = [F(0), F(0), F(1, 8)]; kapB = F(2); a01b, p01b = (F(1), F(1, 3)), (F(1), F(1, 2)); cB = constraint_c(a01b[0], a01b[1], p01b[0], p01b[1], vB, kapB, k)
        acB, pcB = engine_solve(Gv, S, a01b, p01b, vB, kapB, cB, k, Nk)
        evB = engine_eval(Gv, S, acB, pcB, vB, kapB, cB, k, Kk); compB, kgB = residuals(evB)
        asB, psB = std_solve(a01b, p01b, vB, kapB, cB, k, Nk)
        print('    k = %d: c = %s, a_j = %s, R00 = %s' % (k, cB, [str(x) for x in acB], [str(x) for x in compB[(0, 0)]]))
        chk('bit', all(Z(compB[(i, i)]) for i in (1, 2, 3)) and Z(kgB) and all(Z(compB[(a, mu)]) for a in range(4) for mu in range(4) if a != mu) and Z(compB[(0, 0)]),
            'k = %+d: ii, KG and off-diagonal vanish through t^%d and the 00 constraint (imposed at t = 0 only) vanishes at every order 0..%d' % (k, Kk, Kk))
        chk('bit==std', asB == acB and psB == pcB, 'k = %+d: engine coefficients identical to the textbook recursion with the k/a^2 terms (a_0..a_%d, phi_0..phi_%d)' % (k, Nk, Nk))
        if k == 1:
            eB, _ = frame_phi(acB, pcB, 1); omB, EaB = engine_grav(Gv, S, eB, cB, Kk, 1, sE=1)
            with sbound(Kk, 1), trunc(4, xdeg=Kk + 1): DEB = Gv.D_covector(omB, EaB)
            chk('bit', all(Z(tser(DEB[a].get(FULL, {}), Kk - 1)) for a in range(4)), 'k = +1: D E_a = 0 at the spatial origin through t^%d with E_a carried to spatial order 1 (omega to spatial order 2; the rotation part of omega enters)' % (Kk - 1))
    tick('part 4')
    head('4b. three random families (random kappa, quartic V with all five coefficients, k, initial data; c from the 00 equation at t = 0), series to order 8')
    for i in range(3):
        k = [0, 1, -1][i]; kapR = F(rng.randint(1, 9), rng.randint(1, 4)); vR = [rq() for _ in range(5)]
        a01r = (F(rng.randint(1, 9), rng.randint(1, 3)), rq()); p01r = (rq(), rq()); cR = constraint_c(a01r[0], a01r[1], p01r[0], p01r[1], vR, kapR, k)
        acR, pcR = engine_solve(Gv, S, a01r, p01r, vR, kapR, cR, k, 8); compR, kgR = residuals(engine_eval(Gv, S, acR, pcR, vR, kapR, cR, k, 6))
        asR, psR = std_solve(a01r, p01r, vR, kapR, cR, k, 8)
        chk('bit==std', all(Z(v) for v in compR.values()) and Z(kgR) and asR == acR and psR == pcR, 'random family %d (k = %+d, kappa = %s, V coefficients %s, a0 = %s, a1 = %s, phi0 = %s, phi1 = %s, c = %s): all 16 components and KG vanish through t^6 (00 imposed at t = 0 only); coefficients identical to the std recursion' % (i, k, kapR, [str(x) for x in vR], a01r[0], a01r[1], p01r[0], p01r[1], cR))
    tick('part 4b')

    # ------------------------------------------------------------------ 5. exact solutions
    head('5. exact solutions: kinetic domination a = (1+s)^(1/3), phi = ln(1+s) (kappa = 2/3, V = 0, c = 0, about t0 = 1); a constant potential is the cosmological term')
    Ne = 12; Ke = Ne - 2; bino = [F(1)]
    for j in range(1, Ne + 1): bino.append(bino[-1] * (F(1, 3) - j + 1) / j)
    lg = [F(0)] + [F((-1) ** (j + 1), j) for j in range(1, Ne + 1)]
    evK = engine_eval(Gv, S, bino, lg, [], F(2, 3), 0, 0, Ke); compK, kgK = residuals(evK)
    chk('bit', all(Z(v) for v in compK.values()) and Z(kgK), 'kinetic domination: all 16 components of E_a - kappa tau_a and EL_phi vanish through t^%d on the truncated exact series (binom(1/3, j), (-1)^(j+1)/j)' % Ke)
    asK, psK = std_solve((F(1), F(1, 3)), (F(0), F(1)), [], F(2, 3), 0, 0, Ne)
    kin6 = smul([F(2, 3) * x for x in smul(sder(psK, Ne - 1), sder(psK, Ne - 1), Ne - 1)], smul(smul(asK, asK, Ne - 1), smul(smul(asK, asK, Ne - 1), smul(asK, asK, Ne - 1), Ne - 1), Ne - 1), Ne - 1)
    chk('std', asK == bino and psK == lg and kin6 == pad([F(2, 3)], Ne - 1), 'the textbook recursion (no engine) from (a0, H0, phi0, phi1) = (1, 1/3, 0, 1) reproduces the exact Taylor coefficients through order %d, and kappa phi\'^2 a^6 = 2/3 (constant) through order %d' % (Ne, Ne - 1))
    # constant potential: X_a(c) = E_a(c + kappa V0/3)
    Kd = 8; ar = [F(2)] + [rq() for _ in range(Kd + 2)]; V0, cc, kk = F(9, 16), F(1, 16), F(1)
    e, _ = frame_phi(ar, [F(3, 7)], 0)
    om, E1 = engine_grav(Gv, S, e, cc, Kd, 0); _, E2 = engine_grav(Gv, S, e, cc + kk * V0 / 3, Kd, 0); tau, EL = engine_matter(Gv, e, C4.poly_t([F(3, 7)], NV), [V0], Kd)
    X = [Fm.add(E1[a], tau[a], -kk) for a in range(4)]
    chk('bit', all(tser(X[a].get(m, {}), Kd) == tser(E2[a].get(m, {}), Kd) for a in range(4) for m in set(X[a]) | set(E2[a])) and not EL, 'phi = const, V = V0: E_a(c) - kappa tau_a = E_a(c + kappa V0/3) on every component through t^%d (random degree-%d a(t)); EL_phi = 0: a constant potential is the cosmological term, c_eff = c + kappa V0/3' % (Kd, Kd + 2))
    Hd = F(1, 2); ex = [Hd ** j / math.factorial(j) for j in range(Kd + 3)]
    compD, kgD = residuals(engine_eval(Gv, S, ex, [F(3, 7)], [V0], kk, cc, 0, Kd))
    chk('bit', all(Z(v) for v in compD.values()) and Z(kgD), 'de Sitter a = e^{Ht}, H = 1/2: H^2 = c + kappa V0/3 = 1/16 + 3/16 solves the Einstein-scalar system through t^%d (all components)' % Kd)
    Hc = F(1, 4); exb = [Hc ** j / math.factorial(j) for j in range(Kd + 3)]
    compDb, kgDb = residuals(engine_eval(Gv, S, exb, [F(3, 7)], [V0], kk, cc, 0, Kd))
    chk('ctl', compDb[(0, 0)][0] == kk * V0 and not Z(compDb[(1, 1)]), 'control: a = e^{t/4} (H^2 = c, the potential ignored) fails the 00 equation at t^0 by kappa V0 = %s and the ii equation too' % compDb[(0, 0)][0])
    tick('part 5')

    # ------------------------------------------------------------------ 6. controls
    head('6. controls on the family-A solution and on wrong evolutions (std series, engine residuals)')
    evG = engine_eval(Gv, S, acA, pcA, vA, kapA, cA, 0, K, sk=-1); compG, _ = residuals(evG)
    chk('ctl', compG[(0, 0)][0] != 0 and compG[(0, 0)][0] == -kapA * p01[1] ** 2 * acA[0] ** 3, 'ghost: kinetic sign flipped in tau, same data: the 00 equation fails at t^0 by exactly -kappa phi1^2 a0^3 = %s' % compG[(0, 0)][0])
    evH = engine_eval(Gv, S, acA, pcA, vA, kapA, cA, 0, K, kfac=F(1, 2)); compH, _ = residuals(evH)
    rho0 = p01[1] ** 2 / 2 + V_at(vA, p01[0])
    chk('ctl', compH[(0, 0)][0] == -kapA * rho0 / 2 != 0 and not Z(compH[(1, 1)]), 'kappa/2 in tau: the 00 equation fails at t^0 by -kappa rho0/2 = %s and the ii equation fails too' % compH[(0, 0)][0])
    # friction 2H
    acF, pcF = std_solve(a01, p01, vA, kapA, cA, 0, N, fr=2)
    evF = engine_eval(Gv, S, acF, pcF, vA, kapA, cA, 0, K); compF, kgF = residuals(evF); RF = compF[(0, 0)]
    print('    friction 2H: R00 by order: %s' % [str(x) for x in RF])
    firstF = next((j for j, x in enumerate(RF) if x != 0), None)
    chk('ctl', RF[0] == 0 and firstF == 1 and RF[1] == kapA * acF[0] ** 2 * acF[1] * p01[1] ** 2 and all(Z(compF[(i, i)]) for i in (1, 2, 3)) and not Z(kgF),
        'KG with friction 2H (std series; engine residuals): ii holds, the engine\'s KG does not, and the constraint is NOT propagated: R00 = 0 at t^0, first non-zero at t^%s with R00_1 = kappa a0^2 a1 phi1^2 = %s' % (firstF, RF[1] if len(RF) > 1 else None))
    law = lambda R, kg, pc, KK: sder(R, KK - 1) == [-kapA * x for x in smul(sder(pc, KK - 1), kg, KK - 1)]
    chk('bit', law(RF, kgF, pcF, K) and law(R00, kgV, pcV, K) and law(compA[(0, 0)], kgA, pcA, K), 'the propagation law R00\' = -kappa phi\' RKG (D X_0 = -kappa (i_0 dphi) EL_phi with X_i = 0) holds through t^%d on the 2H, violated and family-A series (non-trivially on the 2H one)' % (K - 1))
    with sbound(K, 0), trunc(4, xdeg=K + 1): DX = Gv.D_covector(evF['om'], evF['X'])
    chk('bit==std', tser(DX[0].get(FULL, {}), K - 1) == sder(RF, K - 1) and not Z(sder(RF, K - 1)), '2H series: the engine\'s D X_0 (D_covector, A3 omega) = (plain t-derivative of R00) dx^0123 through t^%d, non-zero' % (K - 1))
    # fluid p = rho/3: right and wrong continuity (C4's control on a series)
    w = F(1, 3); kf_, a01f = F(3), (F(1), F(1, 2)); rho0f = 3 * a01f[1] ** 2 / kf_; Nf = 9; Kf = Nf - 2; outf = {}
    for name, beta in (('right', None), ('wrong', F(3))):
        acf, rcf = std_fluid_solve(a01f, rho0f, w, kf_, F(0), 0, Nf, beta)
        e, _ = frame_phi(acf, [F(0)], 0); om, Ea = engine_grav(Gv, S, e, 0, Kf, 0)
        rho = C4.poly_t(rcf, NV); T = fluid_series_forms(Gv, e, rho, scale(rho, w), Kf)
        Xf = [Fm.add(Ea[a], T[a], kf_) for a in range(4)]
        outf[name] = ({(a, mu): tser(Xf[a].get(FULL ^ (1 << mu), {}), Kf) for a in range(4) for mu in range(4)}, acf, rcf)
    cr, acr, _ = outf['right']; cw, acw, rcw = outf['wrong']
    chk('bit', Z(cr[(0, 0)]) and all(Z(cr[(i, i)]) for i in (1, 2, 3)), 'fluid p = rho/3 (kappa = 3), evolution = ii + continuity rho\' = -4H rho: E_a + kappa T_a = 0, the 00 constraint propagated through t^%d' % Kf)
    chk('ctl', cw[(0, 0)][0] == 0 and cw[(0, 0)][1] == 3 * kf_ * w * acw[0] ** 2 * acw[1] * rho0f != 0 and all(Z(cw[(i, i)]) for i in (1, 2, 3)), 'fluid with the wrong continuity rho\' = -3H rho (C4\'s control): the constraint breaks at t^1 with R00_1 = 3 kappa w a0^2 a1 rho0 = %s' % cw[(0, 0)][1])
    tick('part 6')
    finish('B3C4S')

if __name__ == '__main__': main()
