#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H3-pseudoscalar.  k = I^2: the coefficient of e^a e^b in the curvature of the extended algebra is the square of its pseudoscalar.   python3 h3_pseudoscalar.py

 n base generators (Lorentz type: time squares +1 and space -1, "ours"; or the flipped convention, time -1 and space +1; at n = 3 also the Euclid base of h3_sign_chain.py)
 plus one extra generator of square s in {-1, 0, +1}.  I = gamma_0 gamma_1 ... gamma_{n-1} gamma_E is the pseudoscalar of the N = n + 1 generators;
 k is the coefficient in the curvature (R^{ab} + k kappa^2 e^a e^b, kappa T^a) of the connection omega + kappa e^a B_{a,E}.
   [bit]  I^2 by the bit rule's own product (bmul); k and the torsion coefficient mu from the engine's curvature of the extended Lie table (embed_k of b1lib, the reading of
          h3_sign_chain.py part (1)); the bracket of the engine's table for the pairs (a,E), (b,E).
   [std]  I^2 = (-1)^{N(N-1)/2} prod(squares) by an explicit count of the swaps that sort the word g_0..g_{N-1} g_0..g_{N-1}; the product of N gamma matrices (numpy, complex,
          a Jordan-Wigner construction); k from the commutator [L_aE, L_bE] of plain so(p,q) matrices (std_lie_table of h3_sign_chain.py) and from the gamma-matrix
          commutator [g_a g_E, g_b g_E] = -2 s g_a g_b.
 Statement: at n = 4, I^2 = -s = k in both conventions.  k = -s holds for every n (the bracket does not know n); I^2 = (-1)^{n(n+1)/2} prod(base) s does, so the equality
 k = I^2 is a property of four base generators: it holds at n = 3 and n = 5 in one convention only.
 Controls: n = 2, 3, 5, 6 must give the I^2 that the sign rule predicts and the set of cases with I^2 = k must be exactly the predicted one; a wrong exponent in the sign rule
 and the rule without the reordering sign must each disagree with the bit rule where the count of swaps says so; k = +s must fail at n = 4; the null case s = 0 is not
 vacuous (I is non-zero, nilpotent); a wrong bracket sign must fail.
 Scope: exact fractions; n = 2 to 6 base generators, s = -1, 0, +1, both conventions.  An algebra identity: nothing about which s is realised."""
import sys; sys.dont_write_bytecode = True
import time
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib, h3_sign_chain), also under python3 -I
from b1lib import *
import numpy as np
from h3_sign_chain import std_lie_table, check_gammas, rr

T0 = time.time()
KAPPA = F(1, 2)
SS = (-1, 0, 1)
NS = (2, 3, 4, 5, 6)
def lorentz_base(n, conv): return [1] + [-1] * (n - 1) if conv == 'ours' else [-1] + [1] * (n - 1)
CASES = [(n, cv, lorentz_base(n, cv)) for n in NS for cv in ('ours', 'flip')] + [(3, 'ours-Euclid', [-1, -1, -1]), (3, 'flip-Euclid', [1, 1, 1])]
def pairs(N): return [(i, j) for i in range(N) for j in range(i + 1, N)]

# ------------------------------------------------------------------------------------------------ [bit] the pseudoscalar by the bit rule's product
def bit_pseudoscalar(sq):
    """the blade g_0 g_1 ... g_{N-1} multiplied out left to right with bmul: (mask, sign); and its square (mask 0, the value)"""
    m, sg = 0, 1
    for i in range(len(sq)):
        m, t = bmul(m, 1 << i, sq); sg *= t
    m2, t2 = bmul(m, m, sq)
    assert m2 == 0
    return (m, sg), sg * sg * t2

# ------------------------------------------------------------------------------------------------ [std] the square by sorting the word, and by gamma matrices
def std_sorted_square(sq):
    """I^2 by hand: the word g_0 ... g_{N-1} g_0 ... g_{N-1}, sorted by adjacent swaps of two different generators (each swap a factor -1, anticommuting generators);
    the sorted word is g_0 g_0 g_1 g_1 ... and each g_i g_i is the square sq_i.  Returns (value, number of swaps)."""
    N = len(sq); w = list(range(N)) + list(range(N)); sign = 1; swaps = 0
    changed = True
    while changed:
        changed = False
        for i in range(len(w) - 1):
            if w[i] > w[i + 1]: w[i], w[i + 1] = w[i + 1], w[i]; sign = -sign; swaps += 1; changed = True
    assert w == sorted(w)
    val = F(sign)
    for x in sq: val *= x
    return val, swaps
def jw_gammas(sq):
    """N anticommuting matrices with the squares sq (+1, -1 or 0): the Pauli chain g_{2j} = Z..Z X 1..1, g_{2j+1} = Z..Z Y 1..1 (Z on the qubits before j), times 1j for a
    square -1; one null generator is kron(Nil, g) on a doubled space with Nil = [[0, 1], [0, 0]] (the others kron(1, g)), as h3_sign_chain.py does for s = 0"""
    X = np.array([[0, 1], [1, 0]], dtype=complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.array([[1, 0], [0, -1]], dtype=complex); I2 = np.eye(2, dtype=complex)
    N = len(sq); m = (N + 1) // 2; nulls = [i for i in range(N) if sq[i] == 0]; assert len(nulls) <= 1
    def chain(j, P):
        M = np.array([[1]], dtype=complex)
        for q in range(m): M = np.kron(M, Z if q < j else (P if q == j else I2))
        return M
    out = []
    for i in range(N):
        g = chain(i // 2, X if i % 2 == 0 else Y)
        if sq[i] == -1: g = 1j * g
        if nulls: g = np.kron(np.array([[0, 1], [0, 0]], dtype=complex) if sq[i] == 0 else np.eye(2, dtype=complex), g)
        out.append(g)
    return out
def fit_coefficient(M, B):
    """c with M = c B (Frobenius projection) and whether M = c B holds"""
    nb = (B * B.conj()).sum().real
    c = (M * B.conj()).sum() / nb
    return c, bool(np.allclose(M, c * B))
def std_k_matrix(sqx, n):
    """k from the matrix commutator [L_aE, L_bE] (plain so(p,q) matrices of std_lie_table), read as h3_sign_chain.py reads it: the quadratic term (1/4) f omega omega with omega^{aE} = kappa e^a"""
    fstd = std_lie_table(sqx); P = pairs(len(sqx)); iA = P.index((0, n)); iB = P.index((1, n)); iC = P.index((0, 1))
    fa, fb = fstd.get((iA, iB)), fstd.get((iB, iA))
    assert (fa is None or fa[0] == iC) and (fb is None or fb[0] == iC)
    return F((fa[1] if fa else 0) - (fb[1] if fb else 0), 4)

def main():
    print('H3-pseudoscalar.  k = I^2 ?   kappa = %s;  n = %s base generators plus one of square s in %s;  conventions: ours (time +1, space -1), flip (time -1, space +1), Euclid at n = 3' % (KAPPA, list(NS), list(SS)))
    I2b = {}; I2s = {}; I2g = {}; kb = {}; ks = {}; kg = {}; mub = {}; swaps = {}; blade = {}; nilp = {}; brk_bit = {}; brk_gam = {}; dims = {}
    head('(1) [bit] I^2 by the bit rule, k and mu from the engine\'s curvature (embed_k), the bracket [B_aE, B_bE] of the engine\'s table;  [std] the sorted word, gamma matrices, so(p,q) matrices')
    for (n, cv, base) in CASES:
        N = n + 1
        for s in SS:
            sqx = list(base) + [s]; key = (n, cv, s)
            (m, sg), v = bit_pseudoscalar(sqx); blade[key] = (m, sg); I2b[key] = F(v)
            I2s[key], swaps[key] = std_sorted_square(sqx)
            mats = jw_gammas(sqx); assert check_gammas(mats, sqx), ('gamma matrices', sqx)
            Pm = np.eye(len(mats[0]), dtype=complex)
            for g in mats: Pm = Pm @ g
            c, ok = fit_coefficient(Pm @ Pm, np.eye(len(Pm), dtype=complex)); assert ok and abs(c.imag) < 1e-12; I2g[key] = int(round(c.real)); assert abs(c.real - I2g[key]) < 1e-12
            nilp[key] = (float(np.abs(Pm).max()) > 0.5, bool(np.allclose(Pm @ Pm, 0)))
            kb[key], mub[key] = embed_k(base, s, KAPPA, 7 + s)
            ks[key] = std_k_matrix(sqx, n)
            # the bracket of the pairs (a,E), (b,E): engine table and gamma matrices
            Lx = Lie(sqx); P = pairs(N); okb = True; okg = True; cg = set()
            for (a, b) in pairs(n):
                iA = Lx.idx[(1 << a) | (1 << n)]; iB = Lx.idx[(1 << b) | (1 << n)]; iC = Lx.idx[(1 << a) | (1 << b)]
                f = Lx.f.get((iA, iB)); okb &= ((f is None and s == 0) or (f is not None and f == (iC, -2 * s)))
                BA = mats[a] @ mats[n]; BB = mats[b] @ mats[n]; comm = BA @ BB - BB @ BA
                c2, ok2 = fit_coefficient(comm, mats[a] @ mats[b]); okg &= ok2 and abs(c2.imag) < 1e-12; cg.add(int(round(c2.real)))
            brk_bit[key] = okb; brk_gam[key] = (okg, cg); dims[key] = len(mats[0])
            # [B_aE, B_bE] = c B_ab and [B_bE, B_aE] = -c B_ab: the quadratic term (1/4) f omega omega with omega^{aE} = kappa e^a gives k = (c - (-c)) / 4 = c / 2
            kg[key] = F(next(iter(cg)), 2) if len(cg) == 1 else None

    # ------------------------------------------------------------------------------------------- n = 4: the statement
    head('(2) n = 4 (Lorentz base plus the extra generator): I^2 = k = -s in both conventions')
    for cv in ('ours', 'flip'):
        for s in SS:
            key = (4, cv, s)
            chk('bit', I2b[key] == -s, '%s, s=%+d: the bit rule gives I^2 = %s for the five-generator pseudoscalar (blade mask %s, sign %+d before squaring); expected -s = %+d' % (cv, s, I2b[key], bin(blade[key][0]), blade[key][1], -s))
            chk('bit', kb[key] == -s and mub[key] == KAPPA, '%s, s=%+d: the engine\'s curvature of the extended connection has k = %s and mu = %s (expected k = -s = %+d, mu = kappa = %s)' % (cv, s, kb[key], mub[key], -s, KAPPA))
            chk('bit', I2b[key] == kb[key], '%s, s=%+d: k = I^2 (both %s)' % (cv, s, kb[key]))
            chk('std', I2s[key] == -s and swaps[key] == 10 and I2g[key] == -s, '%s, s=%+d: sorting the word costs %d swaps (N(N-1)/2 = 10), so I^2 = (-1)^10 prod(squares) = %s; the product of the five gamma matrices squares to %+d times the identity' % (cv, s, swaps[key], I2s[key], I2g[key]))
            chk('std', ks[key] == -s and kg[key] == -s, '%s, s=%+d: k from the so(p,q) matrix commutator = %s, from the gamma-matrix bracket [g_a g_E, g_b g_E] = %+d g_a g_b: k = %s' % (cv, s, ks[key], next(iter(brk_gam[key][1])), kg[key]))
            chk('bit==std', I2b[key] == I2s[key] == I2g[key] and kb[key] == ks[key] == kg[key], '%s, s=%+d: I^2 agrees on the three routes (%s) and k agrees on the three routes (%s)' % (cv, s, I2b[key], kb[key]))
    chk('bit', all(I2b[(4, cv, s)] == kb[(4, cv, s)] == -s for cv in ('ours', 'flip') for s in SS), 'n = 4: I^2 = k = -s for s = -1, 0, +1 in both conventions: no replacement of s by r is needed, the pseudoscalar square is a statement in the label s, as k is')
    chk('bit', all(I2b[(4, 'ours', s)] == rr('ours', s) and I2b[(4, 'flip', s)] == -rr('flip', s) for s in SS), 'n = 4, in the label r = s / (square of space) of h3_sign_chain.py: I^2 = r with space squaring -1 and I^2 = -r with space squaring +1 (the same statement as k = -s in both)')
    chk('bit', all(blade[(4, cv, s)][1] != 0 and (nilp[(4, cv, s)][0] and nilp[(4, cv, s)][1]) == (s == 0) for cv in ('ours', 'flip') for s in SS), 'n = 4, s = 0 is not vacuous: the blade I has sign +-1 before squaring and the gamma-matrix product is a non-zero matrix; it is nilpotent exactly at s = 0 (where I^2 = k = 0)')

    # ------------------------------------------------------------------------------------------- the bracket for every n, and the sign rule
    head('(3) k = -s for every n: the bracket [B_aE, B_bE] = -2 s B_ab (engine table, gamma matrices) and the engine\'s curvature; I^2 follows the sign rule (-1)^{n(n+1)/2} prod(base) s instead')
    for (n, cv, base) in CASES:
        okk = all(kb[(n, cv, s)] == -s and mub[(n, cv, s)] == KAPPA and brk_bit[(n, cv, s)] for s in SS)
        chk('bit', okk, 'n=%d %s base %s: the engine\'s table has [B_aE, B_bE] = -2 s B_ab for all a < b and its curvature gives k = -s, mu = kappa, for s = -1, 0, +1 (k = %s)' % (n, cv, base, [str(kb[(n, cv, s)]) for s in SS]))
        oks = all(ks[(n, cv, s)] == -s and kg[(n, cv, s)] == -s and brk_gam[(n, cv, s)][0] for s in SS)
        chk('std', oks, 'n=%d %s: k = -s from the so(p,q) matrices and from the gamma-matrix bracket (%d x %d matrices, %d x %d at s = 0), s = -1, 0, +1' % (n, cv, dims[(n, cv, 1)], dims[(n, cv, 1)], dims[(n, cv, 0)], dims[(n, cv, 0)]))
        prod = F(1)
        for x in base: prod *= x
        pred = {s: F((-1) ** (n * (n + 1) // 2)) * prod * s for s in SS}
        chk('bit==std', all(I2b[(n, cv, s)] == I2s[(n, cv, s)] == I2g[(n, cv, s)] == pred[s] for s in SS) and all(swaps[(n, cv, s)] == (n + 1) * n // 2 for s in SS),
            'n=%d %s: I^2 = %s for s = -1, 0, +1 on all three routes, = (-1)^{n(n+1)/2} prod(base) s with %d swaps' % (n, cv, [str(I2b[(n, cv, s)]) for s in SS], swaps[(n, cv, 1)]))

    # ------------------------------------------------------------------------------------------- controls
    head('(4) controls')
    eq = {(n, cv): all(I2b[(n, cv, s)] == kb[(n, cv, s)] for s in (-1, 1)) for (n, cv, base) in CASES}
    # the rule: I^2 = k iff (-1)^{n(n+1)/2} prod(base) = -1.  Lorentz base with space squaring -1: n = 0, 1 (mod 4); space squaring +1: n = 0, 3 (mod 4); both: n = 0 (mod 4)
    rule = {}
    for (n, cv, base) in CASES:
        prod = F(1)
        for x in base: prod *= x
        rule[(n, cv)] = (F((-1) ** (n * (n + 1) // 2)) * prod == -1)
    expect = {(2, 'ours'): False, (2, 'flip'): False, (3, 'ours'): False, (3, 'flip'): True, (4, 'ours'): True, (4, 'flip'): True, (5, 'ours'): True, (5, 'flip'): False,
              (6, 'ours'): False, (6, 'flip'): False, (3, 'ours-Euclid'): True, (3, 'flip-Euclid'): False}
    holds = sorted(k_ for k_, v_ in eq.items() if v_); fails = sorted(k_ for k_, v_ in eq.items() if not v_)
    chk('ctl', eq == expect == rule, 'I^2 = k (s = +-1) holds exactly for %s and FAILS for %s, as the rule (-1)^{n(n+1)/2} prod(base) = -1 says: the equality is a property of the number of base generators and their squares, k = -s is not; n = 4 holds in both conventions' % (holds, fails))
    chk('ctl', [n for n in NS if rule[(n, 'ours')] and rule[(n, 'flip')]] == [4], 'among n = 2 to 6 the Lorentz base gives I^2 = k in both conventions at n = 4 only (n = 0 mod 4); n = 3 and n = 5 give it in one convention each')
    chk('ctl', all(I2b[(n, cv, s)] == -kb[(n, cv, s)] for (n, cv) in fails for s in (-1, 1)), 'where it fails, I^2 = +s = -k (the other sign), never another value')
    # a wrong sign rule for the product of the squares
    dis1 = set(); dis2 = set()
    for (n, cv, base) in CASES:
        N = n + 1; prod = F(1)
        for x in base: prod *= x
        for s in (-1, 1):
            w1 = F((-1) ** (N * (N + 1) // 2)) * prod * s; w2 = prod * s
            if w1 != I2b[(n, cv, s)]: dis1.add(n)
            if w2 != I2b[(n, cv, s)]: dis2.add(n)
    chk('ctl', dis1 == {2, 4, 6} and dis2 == {2, 5, 6}, 'a wrong sign rule fails: (-1)^{N(N+1)/2} prod(squares) disagrees with the bit rule at n = %s (N odd), prod(squares) without the reordering sign at n = %s (N(N-1)/2 odd); n = 4 is among the first' % (sorted(dis1), sorted(dis2)))
    chk('ctl', all(I2b[(4, cv, s)] != s for cv in ('ours', 'flip') for s in (-1, 1)), 'a wrong sign of k (k = +s) disagrees with I^2 at n = 4, both conventions, s = +-1')
    wrong_ok = True
    for (n, cv, base) in CASES:
        for s in (-1, 1):
            Lx = Lie(base + [s]); f = Lx.f.get((Lx.idx[(1 << 0) | (1 << n)], Lx.idx[(1 << 1) | (1 << n)]))
            wrong_ok &= (f is not None and f != (Lx.idx[3], 2 * s) and f == (Lx.idx[3], -2 * s))
    chk('ctl', wrong_ok, 'a wrong bracket sign (+2 s B_ab) disagrees with the engine\'s table for the pair (0,E), (1,E) in every case with s = +-1 (%d cases)' % (2 * len(CASES)))
    chk('ctl', all(blade[k_][1] != 0 for k_ in blade) and all(nilp[k_] == (True, k_[2] == 0) for k_ in nilp), 'every I is a non-zero blade and a non-zero matrix; the matrix product is nilpotent exactly when s = 0 (%d cases)' % len(nilp))
    # ------------------------------------------------------------------------------------------- the four-generator pseudoscalar as a candidate extra generator
    head('(5) the pseudoscalar of the four base generators, gamma_0123, as the extra generator: it anticommutes with the four and squares to -1 in both conventions, so it realises s = -1 only')
    for cv in ('ours', 'flip'):
        base = lorentz_base(4, cv); m4 = 0b1111
        anti = all(bmul(m4, 1 << a, base)[1] == -bmul(1 << a, m4, base)[1] and bmul(m4, 1 << a, base)[0] == bmul(1 << a, m4, base)[0] for a in range(4))
        sq4 = bmul(m4, m4, base)[1]
        chk('bit', anti and sq4 == -1, '%s: gamma_0123 anticommutes with gamma_0 .. gamma_3 and squares to %+d by the bit rule: inside Cl(1,3) the pseudoscalar is a fifth anticommuting generator with s = -1' % (cv, sq4))
        mats = jw_gammas(base); g5 = mats[0] @ mats[1] @ mats[2] @ mats[3]
        anti_g = all(np.allclose(g5 @ mats[a] + mats[a] @ g5, 0) for a in range(4)); c5, ok5 = fit_coefficient(g5 @ g5, np.eye(len(g5), dtype=complex))
        chk('std', anti_g and ok5 and abs(c5 + 1) < 1e-12, '%s: the product of the four gamma matrices anticommutes with each of them and squares to %+.0f (numpy); a square +1 needs the complex unit (1j gamma_0123), which is not a blade of the real algebra' % (cv, c5.real))
        chk('ctl', sq4 != 1 and not np.allclose(g5 @ g5, np.eye(len(g5))), '%s: the wrong reading "gamma_0123 squares to +1" (the extra generator of s = +1 as the pseudoscalar) fails on both routes' % cv)
    chk('bit', all(bmul(0b1111, 0b1111, lorentz_base(4, cv))[1] == -1 for cv in ('ours', 'flip')) and all(I2b[(4, cv, -1)] == kb[(4, cv, -1)] == 1 for cv in ('ours', 'flip')),
        'with the pseudoscalar as the extra generator the algebra is the s = -1 case (k = +1 in both conventions); s is a free label of a fifth bit in the engine, fixed by the algebra only if the extra generator is taken to be gamma_0123')
    print('\n  summary: I^2 = (-1)^{n(n+1)/2} prod(base) s; k = -s for every n.  Equal at n = 4 in both conventions; at n = 3 and n = 5 in one convention each.')

if __name__ == '__main__':
    main(); print('\nTOTAL %.1f s' % (time.time() - T0)); finish('H3-pseudoscalar')
