#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""C4: FRW with a perfect fluid on the bit-rule engine.   python3 c4_frw.py

 n = 4, signature (+,-,-,-), polynomials in 4 slots (slot 0 = delta = t - t0 or eta - eta0, slots 1..3 = x).  Frames as exact jets of order 3:
   cosmic time  e^0 = dt, e^i = a(t) s(x) dx^i;  conformal time  e^0 = a d eta, e^i = a dx^i;  s(x) = 1 - k r^2/4 (spatial curvature k, isotropic chart; exact to order 3).
 [bit] omega = A3 closed form (x-degree 2), R and E_a(c) to x-degree 1, D E_a and D T_a at the point (engine D_covector);  M^b_a = G^b_a - 3c delta read off E_a = -M^b_a Theta_b.
 Fluid  T_a = T^b_a Theta_b,  T^b_a = (rho + p) u^b u_a - p delta^b_a,  u = E_0 (comoving).  Field equation (D1, B3):  E_a + kappa T_a = 0.
 [std] Christoffel route (b1lib.std_einstein_mixed), the textbook Friedmann pair (recalled), and the exact Christoffel divergence of B3 (std_div_at0).
 Exports (no engine object at import): poly_t, a_series, frw_frame, engine_frw, mixed_at0, fluid_forms, DT_at0, std_fluid_div."""
import os, sys, time, itertools, random
_here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _here)
from b1lib import *
import g2_hodge as H
import b3_matter as B3

n = 4; NV = 4; SQ = LORENTZ(4); FULL = 15
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

def poly_t(coefs, nv=NV): return {(k,) + (0,) * (nv - 1): F(c) for k, c in enumerate(coefs) if c != 0}
def a_series(kind, x0, H_=None, order=3):
    """Taylor coefficients [a0, a1, a2, a3] of a around x0: 'eta' (a = eta), 'eta2' (eta^2), 'etak:m' (eta^m), 'dS_conf' (-1/(H eta)), 'exp' (e^{H t}, x0 = 0)"""
    x0 = F(x0)
    if kind == 'eta': return [x0, F(1), F(0), F(0)]
    if kind == 'eta2': return [x0 ** 2, 2 * x0, F(1), F(0)]
    if kind == 'dS_conf': return [-1 / (H_ * x0) * (-1 / x0) ** k for k in range(order + 1)]
    if kind == 'exp': return [H_ ** k / F(math.factorial(k)) for k in range(order + 1)]
    raise ValueError(kind)
def frw_frame(acoef, conformal=False, k=0, nv=NV):
    a = poly_t(acoef, nv)
    s = const(nv, 1) if k == 0 else lin((F(1), const(nv, 1)), (F(-k, 4), lin(*[(F(1), {tuple(2 if j == i else 0 for j in range(nv)): F(1)}) for i in (1, 2, 3)])))
    e = [{1: a} if conformal else {1: const(nv, 1)}]
    for i in (1, 2, 3): e.append({1 << i: sp_mul(a, s, 20, 4)})
    return e
def engine_frw(Gv, S, e, c, deg_om=2):
    """[bit] omega (A3, x-degree deg_om), R and E_a(c) (x-degree 1)"""
    om = omega_closed_form(Gv, e, S, NV, deg_om)[0]
    with trunc(4, xdeg=1): R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(c))
    return om, R, Ea
def mixed_at0(Ea, e):
    comp = einstein_components(Ea, 4, NV); e0, E0, det = E0_of(e, 4, NV)
    return mixed_from_components(comp, e0, det, 4, s=-1), comp, (e0, E0, det)
def fluid_forms(Gv, e, rho, p):
    """T_a = sum_b T^b_a Theta_b with T^0_0 = rho, T^i_i = -p (polynomials), u = E_0; jets to x-degree 1"""
    Fm = Gv.Fm
    with trunc(4, xdeg=1):
        th = H.theta_forms(e, Fm, NV)
        return [Fm.wedge({0: rho}, th[0])] + [Fm.wedge({0: scale(p, -1)}, th[i]) for i in (1, 2, 3)]
def DT_at0(Gv, om, T): return [at0(X.get(FULL, {}), NV) for X in Gv.D_covector(om, T)]
def std_fluid_div(e, rho, p):
    """[std] nabla_mu T^mu_nu at the origin for T^mu_nu = (rho + p) u^mu u_nu - p delta, u_nu = e^0_nu, u^mu = g^{mu nu} u_nu (plain polynomials, exact)"""
    g = std_metric(e, 4, SQ, NV, 2); gi, g0, g0i = std_inverse_metric(g, 4, NV, 1)
    ud = [e[0].get(1 << nu, {}) for nu in range(4)]; uu = [lin(*[(F(1), sp_mul(gi[(mu, nu)], ud[nu], 1, 4)) for nu in range(4)]) for mu in range(4)]
    rp = padd(rho, p)
    Tj = [[padd(sp_mul(sp_mul(rp, uu[mu], 1, 4), ud[nu], 1, 4), p if mu == nu else {}, -1) for nu in range(4)] for mu in range(4)]
    return B3.std_div_at0(Tj, B3.christoffel0(g, NV), NV)

def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    rng = random.Random(41)
    rq = lambda: F(rng.randint(-9, 9), rng.randint(1, 5))

    # ------------------------------------------------------------------ 1. E_a(c) on FRW: fit in H^2, a''/a, c;  [std]
    head('1. E_a(c) on FRW frames: M^b_a = G^b_a - 3c delta from the engine, exact fit in H^2, a\'\'/a, c (cosmic and conformal time), [std] Christoffel route')
    rows0, rhs0, rowsi, rhsi = [], [], [], []; ok_diag = True; ok_std = True; ok_txt = True; data = []
    for i in range(6):
        ac = [F(rng.randint(1, 9), rng.randint(1, 4))] + [rq() for _ in range(3)]; c = [F(0), F(1, 3), F(-2, 5)][i % 3]
        e = frw_frame(ac); om, R, Ea = engine_frw(Gv, S, e, c, 1); M, comp, (e0, E0, det) = mixed_at0(Ea, e)
        Hh = ac[1] / ac[0]; add = 2 * ac[2] / ac[0]
        rows0.append([Hh ** 2, add, c]); rhs0.append(M[0][0]); rowsi.append([Hh ** 2, add, c]); rhsi.append(M[1][1])
        ok_diag &= all(M[b][a] == 0 for a in range(4) for b in range(4) if a != b) and M[1][1] == M[2][2] == M[3][3]
        g = std_metric(e, 4, SQ, NV, 2); Rr, g0, g0i = std_riemann(g, 4, NV); Gm, _, _ = std_einstein_mixed(Rr, g0, g0i, 4); Gf = to_frame_mixed(Gm, e0, E0, 4)
        ok_std &= all(Gf[b][a] == M[b][a] + (3 * c if a == b else 0) for a in range(4) for b in range(4))
    f0 = solve_exact(rows0, rhs0); fi = solve_exact(rowsi, rhsi)
    chk('bit', f0[3] and f0[0] == [3, 0, -3] and f0[1] == 3, 'cosmic time: M^0_0 = alpha H^2 + beta a\'\'/a + gamma c, exact fit on 6 random cubic a(t) and c in {0, 1/3, -2/5} (rank %d): (alpha, beta, gamma) = %s' % (f0[1], [str(x) for x in f0[0]] if f0[0] else None))
    chk('bit', fi[3] and fi[0] == [1, 2, -3] and fi[1] == 3, 'cosmic time: M^i_i = alpha H^2 + beta a\'\'/a + gamma c: (alpha, beta, gamma) = %s, isotropic (M^1_1 = M^2_2 = M^3_3)' % ([str(x) for x in fi[0]] if fi[0] else None))
    chk('bit', ok_diag, 'no off-diagonal components (M^0_i = M^i_0 = 0, M^i_j = 0 for i != j) on all 6 frames')
    chk('bit==std', ok_std, '[std] Christoffel route (std_einstein_mixed on g = e^T eta e, carried to the frame): G^b_a = M^b_a + 3c delta^b_a, all 16 components, 6 frames')
    ok_txt = True
    for (r, m0, mi) in zip(rows0, rhs0, rhsi):
        Hh2, add, c = r; ok_txt &= (m0 + 3 * c == 3 * Hh2) and (mi + 3 * c == 2 * add + Hh2)
    chk('std', ok_txt, '[std, recalled] textbook pair in (+,-,-,-): G^0_0 = 3 H^2, G^i_i = 2 a\'\'/a + H^2 (mixed components) on the same 6 frames')
    rowsc, rhsc0, rhsci = [], [], []; ok_cstd = True
    for i in range(5):
        ac = [F(rng.randint(1, 9), rng.randint(1, 4))] + [rq() for _ in range(3)]; c = [F(0), F(1, 3), F(-2, 5)][i % 3]
        e = frw_frame(ac, conformal=True); om, R, Ea = engine_frw(Gv, S, e, c, 1); M, comp, (e0, E0, det) = mixed_at0(Ea, e)
        a0, a1, a2 = ac[0], ac[1], 2 * ac[2]
        rowsc.append([a1 ** 2 / a0 ** 4, a2 / a0 ** 3, c]); rhsc0.append(M[0][0]); rhsci.append(M[1][1])
        g = std_metric(e, 4, SQ, NV, 2); Rr, g0, g0i = std_riemann(g, 4, NV); Gm, _, _ = std_einstein_mixed(Rr, g0, g0i, 4); Gf = to_frame_mixed(Gm, e0, E0, 4)
        ok_cstd &= all(Gf[b][a] == M[b][a] + (3 * c if a == b else 0) for a in range(4) for b in range(4))
    fc0 = solve_exact(rowsc, rhsc0); fci = solve_exact(rowsc, rhsci)
    chk('bit', fc0[0] == [3, 0, -3] and fci[0] == [-1, 2, -3], 'conformal time: M^0_0 = (3, 0, -3) . (a\'^2/a^4, a\'\'/a^3, c) = %s and M^i_i = %s . (same), 5 random cubic a(eta): the cosmic pair with H = a\'/a^2' % ([str(x) for x in fc0[0]], [str(x) for x in fci[0]]))
    chk('bit==std', ok_cstd, '[std] Christoffel route on the conformal frames: G^b_a = M^b_a + 3c delta, all components, 5 frames')
    tick('part 1')

    # ------------------------------------------------------------------ 2. the Friedmann pair with one kappa: radiation and dust
    head('2. the Friedmann pair with ONE kappa: E_a + kappa T_a = 0, T = diag(rho, -p, -p, -p): radiation a = eta, dust a = eta^2 (conformal time, c = 0)')
    eta0 = F(2); res2 = {}
    for name, kind, w, m in (('radiation', 'eta', F(1, 3), 4), ('dust', 'eta2', F(0), 3)):
        ac = a_series(kind, eta0); e = frw_frame(ac, conformal=True); om, R, Ea = engine_frw(Gv, S, e, 0, 1); M, comp, (e0, E0, det) = mixed_at0(Ea, e)
        rho = ac[0] ** (-m); p = w * rho
        k00 = M[0][0] / rho; kii = -M[1][1] / p if p != 0 else None
        res2[name] = (ac, e, M, comp, rho, p, k00, kii)
    ac, e, M, comp, rho, p, k00, kii = res2['radiation']
    chk('bit', k00 == kii == 3, 'radiation (a = eta, rho = rho0 a^-4, p = rho/3, rho0 = 1): kappa from the 00 equation = %s, from the ii equation = %s: ONE kappa, kappa rho0 = 3 (H^2 = kappa rho/3 with H = a\'/a^2)' % (k00, kii))
    ac, e, M, comp, rho, p, k00d, _ = res2['dust']
    chk('bit', k00d == 12 and M[1][1] == 0, 'dust (a = eta^2, rho = rho0 a^-3, p = 0): kappa rho0 = %s from the 00 equation and M^i_i = %s (the ii equation holds with p = 0 for every kappa)' % (k00d, M[1][1]))
    ok_forms = True
    for name in ('radiation', 'dust'):
        ac, e, M, comp, rho, p, k00, kii = res2[name]; kap = F(3) if name == 'radiation' else F(12)
        Tm = [[(rho if a == 0 else -p) if a == b else F(0) for a in range(4)] for b in range(4)]
        with trunc(4, xdeg=0): Tf = H.stress_forms(Tm, H.theta_forms(e, Fm, NV), Fm)
        cT = einstein_components(Tf, 4, NV); ok_forms &= all(comp[k] + kap * cT[k] == 0 for k in comp) and any(cT.values())
    chk('bit', ok_forms, 'E_a + kappa T_a = 0 as forms, all 16 components at the point, radiation (kappa = 3) and dust (kappa = 12) with rho0 = 1: the D1 field equation, one kappa for E_0 and E_i')
    ac, e, M, comp, rho, p, k00, kii = res2['radiation']
    chk('ctl', -M[1][1] != 2 * k00 * p, 'control: 2 kappa in the ii equation fails for radiation (kappa p = %s, 2 kappa p = %s)' % (-M[1][1], 2 * k00 * p))
    chk('ctl', -M[1][1] != -k00 * p, 'control: the wrong sign of p (T^i_i = +p) fails for radiation')
    ac, e, M, comp, rho, p, k00d, _ = res2['dust']; pbad = rho / 3
    chk('ctl', -M[1][1] != k00d * pbad, 'control: rho = rho0 a^-3 (the 00 equation holds, kappa rho0 = 12) with p = rho/3: the ii equation fails (needs kappa p = %s, the frame gives %s)' % (k00d * pbad, -M[1][1]))
    tick('part 2')

    # ------------------------------------------------------------------ 3. continuity
    head('3. continuity: D T_a of the comoving fluid (engine D_covector) and D E_a = 0 split into its two pieces')
    rowsF, rhsF = [], []; ok_sp = True; ok_bs = True
    for i in range(5):
        ac = [F(rng.randint(1, 9), rng.randint(1, 4))] + [rq() for _ in range(3)]; e = frw_frame(ac)
        om0 = omega_closed_form(Gv, e, S, NV, 0)[0]
        r = [rq(), rq()]; q = [rq(), rq()]; rho = poly_t(r); p = poly_t(q)
        DT = DT_at0(Gv, om0, fluid_forms(Gv, e, rho, p)); vol0 = ac[0] ** 3; Hh = ac[1] / ac[0]
        rowsF.append([r[1], Hh * (r[0] + q[0])]); rhsF.append(DT[0] / vol0); ok_sp &= DT[1] == DT[2] == DT[3] == 0
        ok_bs &= DT[0] == (r[1] + 3 * Hh * (r[0] + q[0])) * vol0
    fF = solve_exact(rowsF, rhsF)
    chk('bit', fF[0] == [1, 3] and fF[1] == 2, 'comoving fluid on FRW (random cubic a(t), random 1-jets rho(t), p(t)): D T_0 = (alpha rho\' + beta H (rho + p)) vol_e with (alpha, beta) = %s (exact fit, 5 samples)' % ([str(x) for x in fF[0]] if fF[0] else None))
    chk('bit', ok_sp, 'D T_i = 0 (isotropy) on the same samples')
    chk('bit==std', ok_bs, 'D T_0 (engine D_covector, omega from A3) = (rho\' + 3 H (rho + p)) vol_e with rho\' and H = a\'/a from plain derivatives of the jets, 5 samples')
    # Euler with a spatial gradient
    ac = [F(3), F(1, 2), F(-1, 3), F(1, 7)]; e = frw_frame(ac); om0 = omega_closed_form(Gv, e, S, NV, 0)[0]
    rho = lin((F(2), const(NV, 1)), (F(1, 3), var(NV, 0)), (F(5), var(NV, 1)), (F(-2), var(NV, 3))); p = lin((F(1), const(NV, 1)), (F(-1, 2), var(NV, 0)), (F(3), var(NV, 1)), (F(7), var(NV, 2)), (F(-4), var(NV, 3)))
    DT = DT_at0(Gv, om0, fluid_forms(Gv, e, rho, p)); vol0 = ac[0] ** 3; Hh = ac[1] / ac[0]
    ok_eu = DT[0] == (F(1, 3) + 3 * Hh * 3) * vol0 and [DT[i] for i in (1, 2, 3)] == [-(at0(sp_der(p, i), NV) / ac[0]) * vol0 for i in (1, 2, 3)]
    chk('bit==std', ok_eu, 'Euler with gradients rho(t, x), p(t, x): D T_i = -(E_i p) vol_e = -(d_i p / a) vol_e (comoving observers are geodesic, acceleration 0), D T_0 unchanged')
    # general frame: the fluid at rest in a random frame, engine D T_a against the Christoffel divergence
    ok_gen = True; nzg = True
    for seed in (7, 8, 9):
        rr = random.Random(seed); e = rand_frame(rr, 4, 1, coef=9, density=1.0)
        om0 = omega_closed_form(Gv, e, S, NV, 0)[0]; e0, E0, det = E0_of(e, 4, NV)
        rho = lin((F(rr.randint(1, 9)), const(NV, 1)), *[(F(rr.randint(-9, 9)), var(NV, mu)) for mu in range(4)]); p = lin((F(rr.randint(-9, 9)), const(NV, 1)), *[(F(rr.randint(-9, 9)), var(NV, mu)) for mu in range(4)])
        DT = DT_at0(Gv, om0, fluid_forms(Gv, e, rho, p)); div = std_fluid_div(e, rho, p)
        ok_gen &= DT == [det * sum(E0[v][a] * div[v] for v in range(4)) for a in range(4)]; nzg &= any(DT)
    chk('bit==std', ok_gen and nzg, 'general frame (random 1-jet frames, coefficients in -9..9, 3 seeds; fluid at rest in the frame, u = E_0, rho and p random 1-jets): D T_a (engine) = (nabla_b T^b_a) vol_e with nabla_mu T^mu_nu from exact Christoffel symbols')
    # D E_a = 0 with the Friedmann-defined rho, p, and its two pieces
    ok_DE = True; ok_pc = True; nzp = True
    for i in range(4):
        ac = [F(rng.randint(1, 9), rng.randint(1, 4))] + [rq() for _ in range(3)]; c = [F(0), F(1, 3)][i % 2]; e = frw_frame(ac)
        om, R, Ea = engine_frw(Gv, S, e, c, 2); DE = Gv.D_covector(om, Ea); d0 = Fm.d(Ea[0])
        a0, a1, a2, a3 = ac; Hh = a1 / a0; add = 2 * a2 / a0; Hd = add - Hh ** 2; vol0 = a0 ** 3
        krho = 3 * Hh ** 2 - 3 * c; krho_d = 6 * Hh * Hd; kp = -(2 * add + Hh ** 2 - 3 * c)
        DE0 = [at0(X.get(FULL, {}), NV) for X in DE]; dE0 = at0(d0.get(FULL, {}), NV); omp = DE0[0] - dE0
        ok_DE &= DE0 == [0, 0, 0, 0]
        ok_pc &= dE0 == -(krho_d + 3 * Hh * krho) * vol0 and omp == -3 * Hh * kp * vol0; nzp &= dE0 != 0
    chk('bit', ok_DE, 'D E_a = 0 at the point on FRW (random cubic a(t), c in {0, 1/3}; omega to x-degree 2, E_a to x-degree 1): B2\'s identity on a time-dependent frame')
    chk('bit==std', ok_pc and nzp, 'the two pieces of D E_0, with kappa rho := 3H^2 - 3c and kappa p := -(2a\'\'/a + H^2 - 3c) (the Friedmann pair as DEFINITIONS): d E_0 = -kappa (rho\' + 3 H rho) vol_e and -omega^b_0 ^ E_b = -3 kappa H p vol_e, each non-zero; their sum 0 is continuity rho\' + 3 H (rho + p) = 0')
    # w family on a = eta^2 (conformal): rho = eta^-m, p = w rho
    ac = a_series('eta2', eta0); e = frw_frame(ac, conformal=True); om0 = omega_closed_form(Gv, e, S, NV, 0)[0]; ok_w = True; ok_wbad = True; tab = []
    for w, m in ((F(1, 3), 8), (F(0), 6), (F(-1), 0), (F(1, 2), 9)):
        for mm in (m - 1, m, m + 1):
            if mm < 0: continue
            rho = poly_t([eta0 ** (-mm), -mm * eta0 ** (-mm - 1)]); p = scale(rho, w)
            DT = DT_at0(Gv, om0, fluid_forms(Gv, e, rho, p)); zero = all(x == 0 for x in DT)
            if mm == m: ok_w &= zero
            else: ok_wbad &= not zero
            tab.append('w=%s m=%d:%s' % (w, mm, 'zero' if zero else 'nonzero'))
    chk('bit', ok_w, 'p = w rho on a = eta^2: D T_a = 0 exactly for rho = eta^-m with m = 6(1 + w): w = 1/3, 0, -1, 1/2 -> m = 8, 6, 0, 9 (rho ~ a^-3(1+w))')
    chk('ctl', ok_wbad, 'control: the neighbouring exponents m - 1, m + 1 break conservation in every case (%s)' % ', '.join(tab))
    ac, e, M, comp, rho, p, k00d, _ = res2['dust']; om0 = omega_closed_form(Gv, e, S, NV, 0)[0]
    rhoj = poly_t([eta0 ** -6, -6 * eta0 ** -7]); DT = DT_at0(Gv, om0, fluid_forms(Gv, e, rhoj, scale(rhoj, F(1, 3))))
    chk('ctl', DT[0] != 0 and DT[0] == (1 / ac[0]) * (3 * (ac[1] / ac[0]) * eta0 ** -6 / 3) * ac[0] ** 4, 'control: on the dust background rho ~ a^-3 with p = rho/3: D T_0 = (1/a)(3 (a\'/a) p) vol_e != 0 (continuity broken by exactly the pressure term)')
    tick('part 3')

    # ------------------------------------------------------------------ 4. de Sitter: c = H^2 in a time-dependent chart
    head('4. de Sitter: a = e^{Ht} (cosmic, series to order 3) and a = -1/(H eta) (conformal): E_a(c = H^2) = 0; the static chart; c as a fluid')
    Hd = F(1, 5); ok_ds = True; ok_dsbad = True
    for (kind, x0, conf) in (('exp', 0, False), ('dS_conf', -1, True), ('dS_conf', F(-3, 2), True)):
        ac = a_series(kind, x0, Hd); e = frw_frame(ac, conformal=conf)
        om, R, Ea = engine_frw(Gv, S, e, Hd ** 2, 2)
        ok_ds &= all(not any(p_ for p_ in X.values()) for X in Ea)
        _, _, Eb = engine_frw(Gv, S, e, 2 * Hd ** 2, 1); ok_dsbad &= any(at0(p_, NV) != 0 for X in Eb for p_ in X.values())
    chk('bit', ok_ds, 'E_a(c = H^2) = 0 on every coefficient of x-degree <= 1 (H = 1/5): a = e^{Ht} at t = 0 (series to order 3), a = -1/(H eta) at eta = -1 and -3/2 (exact rational jets)')
    chk('ctl', ok_dsbad, 'control: c = 2 H^2 leaves E_a != 0 on the same frames')
    pt = (F(2), F(3), F(6)); r0 = F(7); es, Es, _ = ks_frame_jet(pt, r0, *sds_jets(F(0), Hd ** 2, r0))
    oms, Rs_ = engine_om_R(Gv, es, S, 4); cs = engine_E_from_R(Gv, es, Rs_, 4, Hd ** 2); cs2 = engine_E_from_R(Gv, es, Rs_, 4, 2 * Hd ** 2)
    chk('bit', not any(cs.values()) and any(cs2.values()), 'static chart (radial Kerr-Schild, f = (H^2/2) rho^2, M = 0, point (2, 3, 6)): E_a(c = H^2) = 0 and E_a(2 H^2) != 0: the same c = H^2 in the static and in both cosmological charts')
    ac = [F(2), F(1, 3), F(-1, 2), F(1, 5)]; e = frw_frame(ac); om, R, Ea0 = engine_frw(Gv, S, e, 0, 1); cc = F(2, 7)
    with trunc(4, xdeg=1): Eac, _ = Gv.einstein(None, e, R, cc); th = H.theta_forms(e, Fm, NV)
    chk('bit', all(B3.form_eq_deg(Fm.add(Eac[a], Ea0[a], -1), Fm.scale(th[a], 3 * cc), 1, 4) for a in range(4)), 'E_a(c) - E_a(0) = 3c Theta_a (x-degree <= 1, c = 2/7): the cosmological term is the fluid T^c = (3c/kappa) delta, i.e. rho_c = 3c/kappa, p_c = -rho_c (E_a(0) + kappa T^c_a = E_a(c))')
    tick('part 4')

    # ------------------------------------------------------------------ 5. spatial curvature (isotropic chart)
    head('5. spatially curved FRW, e^i = a(t) (1 - k r^2/4) dx^i (exact to order 3), k = +1 and -1, at the spatial origin')
    rows_k0, rhs_k0, rhs_ki = [], [], []; ok_kstd = True
    for i in range(6):
        ac = [F(rng.randint(1, 9), rng.randint(1, 4))] + [rq() for _ in range(3)]; c = [F(0), F(1, 3), F(-2, 5)][i % 3]; k = [1, -1][i % 2]
        e = frw_frame(ac, k=k); om, R, Ea = engine_frw(Gv, S, e, c, 1); M, comp, (e0, E0, det) = mixed_at0(Ea, e)
        Hh = ac[1] / ac[0]; add = 2 * ac[2] / ac[0]
        rows_k0.append([Hh ** 2, add, F(k) / ac[0] ** 2, c]); rhs_k0.append(M[0][0]); rhs_ki.append(M[1][1])
        g = std_metric(e, 4, SQ, NV, 2); Rr, g0, g0i = std_riemann(g, 4, NV); Gm, _, _ = std_einstein_mixed(Rr, g0, g0i, 4); Gf = to_frame_mixed(Gm, e0, E0, 4)
        ok_kstd &= all(Gf[b][a] == M[b][a] + (3 * c if a == b else 0) for a in range(4) for b in range(4))
    fk0 = solve_exact(rows_k0, rhs_k0); fki = solve_exact(rows_k0, rhs_ki)
    chk('bit', fk0[0] == [3, 0, 3, -3] and fki[0] == [1, 2, 1, -3] and fk0[1] == 4, 'M^0_0 = (3, 0, 3, -3) . (H^2, a\'\'/a, k/a^2, c) = %s and M^i_i = (1, 2, 1, -3) . (same) = %s: H^2 + k/a^2 = kappa rho/3 + c, 2a\'\'/a + H^2 + k/a^2 = -kappa p + 3c' % ([str(x) for x in fk0[0]] if fk0[0] else None, [str(x) for x in fki[0]] if fki[0] else None))
    chk('bit==std', ok_kstd, '[std] Christoffel route on the curved frames: G^b_a = M^b_a + 3c delta, all components, 6 frames')
    tick('part 5')
    finish('C4')

import math
if __name__ == '__main__': main()
