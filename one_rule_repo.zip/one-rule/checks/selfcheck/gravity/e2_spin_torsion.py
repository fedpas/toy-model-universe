#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""E2.  Dirac spin density and spin-torsion on the bit rule (Einstein-Cartan with Dirac matter).     python3 e2_spin_torsion.py

 Conventions: Cl(1,3), sq = (+,-,-,-), B_A = gamma_b gamma_c (b < c, A in the engine's order), D psi = d psi + (1/2) omega^A B_A psi (Grav.D_spinor).
 The Atlas's Dirac line: psi EVEN, reversion psi~, J = gamma_2 gamma_1 on the right, gamma_0 on the right (grad psi J = m psi gamma_0).
   L_D = sum_a < gamma^a (D psi ^ Theta_a) J gamma_0 psi~ >  -  m <psi psi~> vol      (gamma^a = sq_a gamma_a, Theta_a = iota_{E_a} vol: no inverse frame needed)
   s = psi gamma_3 psi~ (axial current), j = psi gamma_0 psi~ (vector current), psi psi~ = alpha + beta I, rho^2 = alpha^2 + beta^2.
   L_tot = L_EC - kappa L_D  (lambda = -kappa: D1's E_a + kappa T_a = 0 with delta_e L_m = -delta e^a ^ T_a; an input fixed by attraction).
 Claims checked (exact Fractions on the engine path):
  S1  delta_omega L_D = delta omega^A ^ S_A (algebraic, polynomial identity); S_A = sum_a sigma^a_A Theta_a with sigma_abc = sq_a sigma^a_bc totally antisymmetric
      = k eps_abcd s^d; S_bc = k1 e_b ^ e_c ^ s_hat; Clifford identity {gamma^a, B_bc} = 2 gamma^a ^ B_bc (six sign patterns); psi J gamma_0 psi~ = I s; Fierz.
  S2  Theta_A(T) = kappa S_A (B1's Theta): unique T, totally antisymmetric, T_abc = t kappa eps_abcd s^d; the same T from the stationary point of the
      engine's L_tot(K) at constant fields (route ii) and as the engine torsion of omega_LC + K* on curved frames (first-order jets at the origin).
  S3  Delta L_tot = L_tot(K*) - L_tot(0) = C kappa^2 (s.s) vol; curved frames: L_tot(omega_LC + K*) - L_tot(omega_LC) - d(K*^A ^ Y_A) = the same at the origin (d-term = 0).
 [std] numpy only: Dirac matrices (E1's gammas), chi = M(psi) u, textbook Re(chibar i Gamma^a nabla_a chi) - m chibar chi, textbook R^ab = d om^ab + om^a_e om^eb,
       L_EC = sum_{a<b} R^ab_ab vol in an orthonormal frame, stationary contorsion by numpy linear algebra.
 Controls: vector-current bilinear; [std] i dropped; Clifford commutator; wrong sign of lambda; Theta without (-1)^j; doubled quadratic term; wrong-sign contorsion.
 Findings (two candidate controls that are not wrong versions): the vector-current contact value equals the axial one (Fierz),
 and K*^A ^ Y_A = 0 identically for the axial contorsion (no exact form is left on curved frames)."""
import sys, os, time, itertools, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from b1lib import *
import b1_first_variation as B1
from e1_lichnerowicz import gammas, blades, to_mat
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
LOR = [1, -1, -1, -1]; N = 4
PAIRS = [(i, j) for i in range(N) for j in range(i + 1, N)]                     # engine generator order: gens = [(1<<i)|(1<<j) for i < j]
EVEN = [m for m in range(16) if popc(m) % 2 == 0]
M2 = [m for m in range(16) if popc(m) == 2]; M3 = [m for m in range(16) if popc(m) == 3]
def rsg(m): k = popc(m); return -1 if (k * (k - 1) // 2) % 2 else 1          # reversion sign of a blade
def Z(nv): return (0,) * nv
def cp(v, nv): return {Z(nv): F(v)} if v != 0 else {}
def v0(p, nv): return p.get(Z(nv), F(0))
def perm(seq):
    if len(set(seq)) < len(seq): return 0
    s = 1
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]: s = -s
    return s
def comp4(*idx): return [x for x in range(N) if x not in idx]

# ------------------------------------------------------------------------------------------------ constant multivectors and multivector fields {mask: poly}
def mv_mul(A, B, sq):
    out = {}
    for m1, a in A.items():
        for m2, b in B.items():
            m, s = bmul(m1, m2, sq); out[m] = out.get(m, 0) + s * a * b
    return {k: v for k, v in out.items() if v != 0}
def mvp_mul(X, Y, sq):
    out = {}
    for m1, p1 in X.items():
        for m2, p2 in Y.items():
            m, s = bmul(m1, m2, sq); out[m] = padd(out.get(m, {}), gs.pmul(p1, p2), s)
    return {m: p for m, p in out.items() if p}
def mvp_const(X, nv): return {m: cp(v, nv) for m, v in X.items() if v != 0}
def mvp_rev(X): return {m: pscale(p, rsg(m)) for m, p in X.items()}
J_MV = mv_mul({4: F(1)}, {2: F(1)}, LOR)                                        # J = gamma_2 gamma_1
G0 = {1: F(1)}; G3 = {8: F(1)}; I_MV = {15: F(1)}
def currents(psi, sq, nv):
    """s = psi g3 psi~, j = psi g0 psi~ (components s^d = coefficient of gamma_d), psi psi~, and psi J g0 psi~"""
    pt = mvp_rev(psi)
    s = mvp_mul(mvp_mul(psi, mvp_const(G3, nv), sq), pt, sq); j = mvp_mul(mvp_mul(psi, mvp_const(G0, nv), sq), pt, sq)
    pp = mvp_mul(psi, pt, sq); R = mvp_mul(mvp_mul(psi, mvp_const(mv_mul(J_MV, G0, sq), nv), sq), pt, sq)
    return s, j, pp, R
def vec(X): return [X.get(1 << d, {}) for d in range(N)]
def dot(u, w, sq, nv):                                                          # sum_d sq_d u^d w^d (polys)
    r = {}
    for d in range(N): r = padd(r, gs.pmul(u[d], w[d]), sq[d])
    return r

# ------------------------------------------------------------------------------------------------ [bit] the Dirac n-form
def theta_forms(Gv, e):
    Fm = Gv.Fm; out = []
    for a in range(N):
        rest = comp4(a); f = e[rest[0]]
        for d in rest[1:]: f = Fm.wedge(f, e[d])
        out.append(Fm.scale(f, Gv.eps([a] + rest)))
    return out
def vol_form(Gv, e):
    f = e[0]
    for d in range(1, N): f = Gv.Fm.wedge(f, e[d])
    return f
def L_dirac(Gv, e, om, psi, m, nv, mode='axial', Th=None):
    """L_D (a 4-form). mode 'vector' = control: right factor gamma_0 psi~ (J dropped: the vector-current bilinear)"""
    Fm = Gv.Fm; sq = Gv.L.sq; Th = Th or theta_forms(Gv, e)
    Dpsi = Gv.D_spinor(om, {S: {0: p} for S, p in psi.items()})
    left = mv_mul(J_MV, G0, sq) if mode == 'axial' else G0
    Rt = mvp_mul(mvp_const(left, nv), mvp_rev(psi), sq); tot = {}
    for a in range(N):
        for S, form in Dpsi.items():
            m1, s1 = bmul(1 << a, S, sq); r = Rt.get(m1)
            if not r: continue
            s2 = bmul(m1, m1, sq)[1]; w = Fm.wedge(form, Th[a])
            if w: tot = Fm.add(tot, Fm.wedge({0: r}, w), sq[a] * s1 * s2)
    if m:
        mass = {}
        for S, p in psi.items(): mass = padd(mass, gs.pmul(p, p), rsg(S) * bmul(S, S, sq)[1])
        tot = Fm.add(tot, Fm.wedge({0: mass}, vol_form(Gv, e)), -F(m))
    return tot
def spin_forms_engine(Gv, e, psi, nv, mode='axial'):
    """S_A read off the engine: L_D(omega = dx^mu B_A) - L_D(0) = dx^mu ^ S_A"""
    Fm = Gv.Fm; Th = theta_forms(Gv, e); zero = [{} for _ in range(Gv.G)]
    L0 = L_dirac(Gv, e, zero, psi, 0, nv, mode, Th); S = []
    for A in range(Gv.G):
        SA = {}
        for mu in range(N):
            om = [{} for _ in range(Gv.G)]; om[A] = {1 << mu: cp(1, nv)}
            p = Fm.add(L_dirac(Gv, e, om, psi, 0, nv, mode, Th), L0, -1).get(15, {})
            if p: SA[15 ^ (1 << mu)] = pscale(p, (-1) ** mu)
        S.append(SA)
    return S
def S_closed(Gv, e, s, k1, nv):
    """S_bc = k1 e_b ^ e_c ^ s_hat,  e_b = sq_b e^b,  s_hat = sum_d sq_d s^d e^d"""
    Fm = Gv.Fm; sq = Gv.L.sq; sh = {}
    for d in range(N):
        if s[d]: sh = Fm.add(sh, Fm.wedge({0: s[d]}, e[d]), sq[d])
    return [Fm.scale(Fm.wedge(Fm.wedge(e[b], e[c]), sh), F(k1) * sq[b] * sq[c]) for (b, c) in PAIRS]
def forms_equal(X, Y, Fm): return not Fm.add(X, Y, -1)
def ratio_fit(Xs, Ys, Fm):
    """the single c with X = c Y for all pairs of forms (None if there is none)"""
    c = None
    for X, Y in zip(Xs, Ys):
        for msk, p in Y.items():
            for k, v in p.items():
                if v != 0: c = X.get(msk, {}).get(k, F(0)) / v; break
            if c is not None: break
        if c is not None: break
    if c is None: return None
    return c if all(forms_equal(X, Gv_scale(Fm, Y, c), Fm) for X, Y in zip(Xs, Ys)) else None
def Gv_scale(Fm, Y, c): return Fm.scale(Y, c)

# ------------------------------------------------------------------------------------------------ constant frames (pointwise algebra)
def rand_matrix(rng, coef=3):
    while True:
        A = [[F(rng.randint(-coef, coef)) for _ in range(N)] for _ in range(N)]
        det, inv = det_inv(A)
        if det != 0: return A, det, inv                                         # inv[mu][a] = E^mu_a
def const_frame(A, nv): return [{1 << mu: cp(A[a][mu], nv) for mu in range(N) if A[a][mu] != 0} for a in range(N)]
def rand_even(rng, coef=3):
    while True:
        p = {S: F(rng.randint(-coef, coef)) for S in EVEN}; p = {S: v for S, v in p.items() if v != 0}
        if len(p) >= 5: return p
def form2_frame(X, E, b, c, nv):
    """X(E_b, E_c) for a constant 2-form"""
    tot = F(0)
    for msk, p in X.items():
        mu, nu = [i for i in range(N) if msk >> i & 1]; v = v0(p, nv)
        tot += v * (E[mu][b] * E[nu][c] - E[nu][b] * E[mu][c])
    return tot
def in_theta_basis(X, Th, nv):
    """c_a with X = sum_a c_a Theta_a (constant 3-forms)"""
    rows = [[v0(Th[a].get(m3, {}), nv) for a in range(N)] for m3 in M3]; rhs = [v0(X.get(m3, {}), nv) for m3 in M3]
    w, rank, nvar, cons = solve_exact(rows, rhs)
    assert rank == N and cons
    return w
def sigma_frame(S, Th, nv): return {(a, A): c for A in range(len(S)) for a, c in enumerate(in_theta_basis(S[A], Th, nv))}
def antisym_report(Tl):
    """Tl[(a,b,c)] all lower: (totally antisymmetric?, trace sum_a sq_a Tl[a,a,c] for c)"""
    ok = all(Tl[(a, b, c)] == -Tl[(b, a, c)] and Tl[(a, b, c)] == -Tl[(a, c, b)] for a in range(N) for b in range(N) for c in range(N))
    tr = [sum((LOR[a] * Tl[(a, a, c)] for a in range(N)), F(0)) for c in range(N)]
    return ok, tr
def lower_sigma(sig):                                                           # sigma_abc = sq_a sigma^a_bc, antisymmetric extension in (b, c)
    Tl = {}
    for a in range(N):
        for b in range(N):
            for c in range(N):
                if b == c: Tl[(a, b, c)] = F(0); continue
                A = PAIRS.index((min(b, c), max(b, c))); sg = 1 if b < c else -1
                Tl[(a, b, c)] = LOR[a] * sg * sig[(a, A)]
    return Tl
def eps_fit(Tl, s):
    """the single k with Tl[a,b,c] = k eps(a,b,c,d) s^d (d the fourth index), or None"""
    k = None
    for (a, b, c), v in Tl.items():
        if len({a, b, c}) < 3: continue
        d = comp4(a, b, c)[0]; den = perm([a, b, c, d]) * s[d]
        if den != 0: k = v / den; break
    if k is None: return None
    for (a, b, c), v in Tl.items():
        pred = F(0) if len({a, b, c}) < 3 else k * perm([a, b, c, comp4(a, b, c)[0]]) * s[comp4(a, b, c)[0]]
        if v != pred: return None
    return k

# ------------------------------------------------------------------------------------------------ S2 route (i): Theta(T) = kappa S  (B1's Theta), and route (ii): stationary K of the engine's L_tot
def solve_route_i(Gv, e, S, kap, nv, signs=True):
    cols = []
    for c in range(N):
        for m2 in M2:
            T = [{} for _ in range(N)]; T[c] = {m2: cp(1, nv)}
            Th = B1.Theta_forms(Gv, e, T, signs)
            cols.append([v0(Th[(a, b)].get(m3, {}), nv) for (a, b) in PAIRS for m3 in M3])
    rows = [[cols[j][i] for j in range(len(cols))] for i in range(len(cols[0]))]
    rhs = [kap * v0(S[A].get(m3, {}), nv) for A in range(len(PAIRS)) for m3 in M3]
    w, rank, nvar, cons = solve_exact(rows, rhs)
    T = [{} for _ in range(N)]; i = 0
    for c in range(N):
        for m2 in M2:
            if w[i] != 0: T[c][m2] = cp(w[i], nv)
            i += 1
    return T, rank, cons
def T_lower(T, E, nv): return {(a, b, c): LOR[a] * form2_frame(T[a], E, b, c, nv) for a in range(N) for b in range(N) for c in range(N)}
def stationary_K(Gv, A, psi0, kap, m, lagEC=None, mode='axial'):
    """[bit] K^A = sum_mu k_{A mu} dx^mu with symbolic k (slots 4..27); L_tot = L_EC(K) - kappa L_D(K) at constant frame and spinor; grad = 0 solved exactly"""
    nv = N + N * len(PAIRS); e = const_frame(A, nv); psi = {S: cp(v, nv) for S, v in psi0.items()}
    K = [{1 << mu: var(nv, N + N * Ai + mu) for mu in range(N)} for Ai in range(len(PAIRS))]
    LEC = (lagEC or B1.lag_EC)(Gv, e, K, 0).get(15, {}); LD = L_dirac(Gv, e, K, psi, m, nv, mode).get(15, {})
    Lt = padd(LEC, LD, -kap); nk = N * len(PAIRS); rows, rhs = [], []
    for i in range(nk):
        g = pder(Lt, N + i); rows.append([g.get(tuple(1 if j == N + jj else 0 for j in range(nv)), F(0)) for jj in range(nk)]); rhs.append(-g.get(Z(nv), F(0)))
    w, rank, nvar, cons = solve_exact(rows, rhs)
    return [[w[N * Ai + mu] for mu in range(N)] for Ai in range(len(PAIRS))], rank, cons
def K_forms(k, nv): return [{1 << mu: cp(k[Ai][mu], nv) for mu in range(N) if k[Ai][mu] != 0} for Ai in range(len(PAIRS))]
def lag_EC_doubled(Gv, e, om, c):
    """[ctl] L_EC with a private curvature whose quadratic term is doubled: R = d om + (1/2)[om, om]"""
    Fm = Gv.Fm; R = [Fm.d(om[C]) for C in range(Gv.G)]
    for (Aa, Bb), (C, f) in Gv.L.f.items(): R[C] = Fm.add(R[C], Fm.wedge(om[Aa], om[Bb]), F(f, 2))
    tot = {}
    for (a, b) in PAIRS:
        rest = comp4(a, b); form = R[Gv.L.idx[(1 << a) | (1 << b)]]
        for d in rest: form = Fm.wedge(form, e[d])
        tot = Fm.add(tot, form, Gv.eps([a, b] + rest))
    return tot
def L_tot_value(Gv, e, om, psi, kap, m, nv, lagEC=None, mode='axial'):
    return Gv.Fm.add((lagEC or B1.lag_EC)(Gv, e, om, 0), L_dirac(Gv, e, om, psi, m, nv, mode), -kap)

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
class Std:
    def __init__(self):
        self.G = gammas(LOR); self.BL = blades(self.G); self.eta = np.diag(np.array(LOR, float))
        self.Gup = [LOR[a] * self.G[a] for a in range(N)]; self.Gdn = list(self.G)
        self.g5 = 1j * self.Gup[0] @ self.Gup[1] @ self.Gup[2] @ self.Gup[3]
        self.Jm = to_mat(self.BL, J_MV); I4 = np.eye(4)
        P = (I4 + self.G[0]) / 2 @ (I4 - 1j * self.Jm) / 2; col = int(np.argmax(np.linalg.norm(P, axis=0)))
        self.u = P[:, col] / np.linalg.norm(P[:, col])
    def chi(self, psi0): return to_mat(self.BL, psi0) @ self.u
    def bar(self, chi): return chi.conj() @ self.Gup[0]
    def bil(self, chi):
        b = self.bar(chi)
        return dict(sig=(b @ chi).real, pi=(b @ (1j * self.g5) @ chi).real, J=np.array([(b @ self.Gup[a] @ chi).real for a in range(N)]),
                    A=np.array([(b @ self.Gup[a] @ self.g5 @ chi).real for a in range(N)]), imag=max(abs((b @ chi).imag), max(abs((b @ self.Gup[a] @ chi).imag) for a in range(N))))
    def sigma(self, chi, with_i=True):
        """sigma^a_bc = dL/dK_a^bc (b < c) of Re(chibar i Gamma^a nabla_a chi), nabla_a = d_a + (1/4) K_a^bc Gamma_b Gamma_c; with_i=False: [ctl] i dropped"""
        b = self.bar(chi); f = 1j if with_i else 1.0
        return {(a, Ai): 0.5 * (f * (b @ self.Gup[a] @ self.Gdn[p] @ self.Gdn[q] @ chi)).real for a in range(N) for Ai, (p, q) in enumerate(PAIRS)}
    def lagrangian(self, chi, dchi, Kf, m):
        """Re(chibar i Gamma^a nabla_a chi) - m chibar chi;  dchi[a] = d_a chi (frame derivative), Kf[a][Ai] = K_a^{bc}"""
        b = self.bar(chi); tot = 0.0
        for a in range(N):
            nab = dchi[a] + sum(0.5 * Kf[a][Ai] * (self.Gdn[p] @ self.Gdn[q] @ chi) for Ai, (p, q) in enumerate(PAIRS))
            tot += (1j * (b @ self.Gup[a] @ nab)).real
        return tot - m * (b @ chi).real
    def LEC(self, Kv):
        """sum_{a<b} R^ab(E_a, E_b) with R^ab = om^a_e ^ om^eb (constant om^ab = K_c^ab theta^c, orthonormal frame)"""
        K = np.zeros((N, N, N))
        for c in range(N):
            for Ai, (p, q) in enumerate(PAIRS): K[c, p, q] = Kv[N * Ai + c]; K[c, q, p] = -Kv[N * Ai + c]
        Kl = np.einsum('cae,e->cae', K, np.diag(self.eta))                      # K_c^a_e = K_c^{ae} eta_ee
        R = np.einsum('cae,deb->abcd', Kl, K) - np.einsum('dae,ceb->abcd', Kl, K)
        return sum(R[p, q, p, q] for (p, q) in PAIRS)
    def Ltot(self, Kv, sig, kap, m, sigmab):
        lin = sum(Kv[N * Ai + c] * sig[(c, Ai)] for c in range(N) for Ai in range(len(PAIRS)))
        return self.LEC(Kv) - kap * (lin - m * sigmab)
    def stationary(self, sig, kap, m, sigmab):
        """L = L0 + g.K + (1/2) K Q K exactly (quadratic + linear): g and Q by polarisation, then Q K = -g"""
        n = N * len(PAIRS); f = lambda K: self.Ltot(K, sig, kap, m, sigmab); E = np.eye(n); L0 = f(np.zeros(n))
        Lp = np.array([f(E[i]) for i in range(n)]); Lm = np.array([f(-E[i]) for i in range(n)])
        g = (Lp - Lm) / 2; Q = np.zeros((n, n))
        for i in range(n):
            Q[i, i] = Lp[i] + Lm[i] - 2 * L0
            for j in range(i + 1, n): Q[i, j] = Q[j, i] = f(E[i] + E[j]) - Lp[i] - Lp[j] + L0
        K = np.linalg.solve(Q, -g)
        return K, f(K) - L0, np.linalg.cond(Q)
    def torsion(self, K):
        T = np.zeros((N, N, N))                                                 # T^a_cd = K_c^a_d - K_d^a_c,  K_c^a_d = K_c^{ad} eta_dd
        Kf = np.zeros((N, N, N))
        for c in range(N):
            for Ai, (p, q) in enumerate(PAIRS): Kf[c, p, q] = K[N * Ai + c]; Kf[c, q, p] = -K[N * Ai + c]
        for a in range(N):
            for c in range(N):
                for d in range(N): T[a, c, d] = Kf[c, a, d] * LOR[d] - Kf[d, a, c] * LOR[c]
        return T
def std_antisym(sig):
    Tl = {(a, b, c): (0.0 if b == c else LOR[a] * (1 if b < c else -1) * sig[(a, PAIRS.index((min(b, c), max(b, c))))]) for a in range(N) for b in range(N) for c in range(N)}
    scale = max(1e-300, max(abs(v) for v in Tl.values()))
    err = max(max(abs(Tl[(a, b, c)] + Tl[(b, a, c)]), abs(Tl[(a, b, c)] + Tl[(a, c, b)])) for a in range(N) for b in range(N) for c in range(N)) / scale
    return Tl, err
def std_eps_fit(Tl, s):
    num = den = 0.0
    for (a, b, c), v in Tl.items():
        if len({a, b, c}) < 3: continue
        d = comp4(a, b, c)[0]; x = perm([a, b, c, d]) * s[d]; num += v * x; den += x * x
    k = num / den; res = max(abs(v - (k * perm([a, b, c, comp4(a, b, c)[0]]) * s[comp4(a, b, c)[0]] if len({a, b, c}) == 3 else 0.0)) for (a, b, c), v in Tl.items())
    return k, res / max(1e-300, max(abs(v) for v in Tl.values()))
def fl(x): return float(x)

# ------------------------------------------------------------------------------------------------ parts
def part_clifford():
    head('S1a  Clifford identity {gamma^a, B_bc} = 2 gamma^a ^ B_bc (vector part cancels), six sign patterns  [bit] bmul, [std] matrices')
    pats = [[1, -1, -1, -1], [-1, 1, 1, 1], [1, 1, 1, 1], [-1, -1, -1, -1], [1, 1, -1, -1], [1, -1, 1, -1]]
    for sq in pats:
        okb = okc = True; oks = True; Gs = gammas(sq); I4 = np.eye(4)
        for a in range(N):
            ga = {1 << a: F(sq[a])}                                             # gamma^a = sq_a gamma_a
            for (b, c) in PAIRS:
                B = {(1 << b) | (1 << c): F(1)}
                ac = {k: v for k, v in [(m, mv_mul(ga, B, sq).get(m, 0) + mv_mul(B, ga, sq).get(m, 0)) for m in range(16)] if v != 0}
                cm = {k: v for k, v in [(m, mv_mul(ga, B, sq).get(m, 0) - mv_mul(B, ga, sq).get(m, 0)) for m in range(16)] if v != 0}
                wedge = {} if a in (b, c) else {k: 2 * v for k, v in mv_mul(mv_mul(ga, {1 << b: F(1)}, sq), {1 << c: F(1)}, sq).items()}
                okb &= (ac == wedge); okc &= (cm != wedge)
                Ga = sq[a] * Gs[a]; Bm = Gs[b] @ Gs[c]
                Wm = np.zeros((4, 4), complex) if a in (b, c) else 2 * Ga @ Gs[b] @ Gs[c]
                oks &= np.allclose(Ga @ Bm + Bm @ Ga, Wm, atol=1e-13)
        chk('bit', okb, 'sq = %s: gamma^a B_bc + B_bc gamma^a = 2 gamma^a ^ B_bc for all 4 x 6 (a, bc)' % sq)
        chk('std', oks, 'sq = %s: the same with 4x4 matrices (E1 gammas, factor i per flipped square)' % sq)
        chk('ctl', okc, 'sq = %s: the commutator in place of the anticommutator is NOT 2 gamma^a ^ B_bc' % sq)
    tick('S1a')

def part_S1(rng, st):
    head('S1b  spin density: delta_omega L_D is algebraic; S_A totally antisymmetric, axial only  (n = 4, (+,-,-,-))')
    Gv = Grav(N, Lie(LOR)); Fm = Gv.Fm; nv = N
    # (1) polynomial identity on a random polynomial frame (degree 1), omega and psi (degree 1)
    e = rand_frame(rng, N, deg=1, coef=2, density=.6)
    psi = {S: p for S, p in ((S, gs.rpoly(rng, N, 1, .7)) for S in EVEN) if p}
    om = [gs.rform(rng, N, 1, 1, .5) for _ in range(Gv.G)]; dom = [gs.rform(rng, N, 1, 1, .5) for _ in range(Gv.G)]
    Sx = spin_forms_engine(Gv, e, psi, nv); tick('S_A field')
    s, j, pp, Rt = currents(psi, LOR, nv); sv = vec(s)
    lhs = Fm.add(L_dirac(Gv, e, [Fm.add(om[A], dom[A]) for A in range(Gv.G)], psi, F(3, 2), nv), L_dirac(Gv, e, om, psi, F(3, 2), nv), -1)
    rhs = {}
    for A in range(Gv.G): rhs = Fm.add(rhs, Fm.wedge(dom[A], Sx[A]))
    chk('bit', forms_equal(lhs, rhs, Fm) and bool(lhs), 'L_D(om + dom) - L_D(om) = sum_A dom^A ^ S_A exactly: no derivative of dom (random polynomial e, om, dom, psi of degree 1; m = 3/2)')
    k1 = ratio_fit(Sx, S_closed(Gv, e, sv, 1, nv), Fm)
    chk('bit', k1 is not None, 'S_bc = k1 e_b ^ e_c ^ s_hat as polynomial 3-forms, one k1 for all six pairs: k1 = %s' % k1)
    chk('bit', bool(Rt) and all(popc(msk) == 3 for msk, p in Rt.items() if p), 'psi J g0 psi~ is a pure trivector (polynomial spinor field)')
    IS = mvp_mul(mvp_const(I_MV, nv), s, LOR)
    chk('bit', all(not padd(Rt.get(msk, {}), IS.get(msk, {}), -1) for msk in set(Rt) | set(IS)), 'psi J g0 psi~ = I (psi g3 psi~) as polynomials: only the axial current enters')
    Sv = spin_forms_engine(Gv, e, psi, nv, mode='vector')
    chk('ctl', ratio_fit(Sv, S_closed(Gv, e, sv, 1, nv), Fm) is None, 'vector-current bilinear (J dropped): its S_A is not k1 e_b e_c s_hat')
    tick('S1 identity')
    # (2) pointwise: constant frames, rational spinors; sigma totally antisymmetric, k; Fierz; [bit==std]
    out = []
    for draw in range(3):
        A, det, E = rand_matrix(rng); e = const_frame(A, nv); psi0 = rand_even(rng); psi = {S: cp(v, nv) for S, v in psi0.items()}
        Th = theta_forms(Gv, e); S = spin_forms_engine(Gv, e, psi, nv); sig = sigma_frame(S, Th, nv); Tl = lower_sigma(sig)
        s, j, pp, Rt = currents(psi, LOR, nv); sv = [v0(p, nv) for p in vec(s)]; jv = [v0(p, nv) for p in vec(j)]
        al, be = v0(pp.get(0, {}), nv), v0(pp.get(15, {}), nv); rho2 = al * al + be * be
        anti, tr = antisym_report(Tl); k = eps_fit(Tl, sv)
        chk('bit', anti and all(x == 0 for x in tr), 'draw %d: sigma_abc = sq_a sigma^a_bc (frame components of the engine S_A) is totally antisymmetric, trace 0' % draw)
        chk('bit', k is not None, 'draw %d: sigma_abc = k eps_abcd s^d with k = %s' % (draw, k))
        ss = sum(LOR[d] * sv[d] ** 2 for d in range(N)); jj = sum(LOR[d] * jv[d] ** 2 for d in range(N)); js = sum(LOR[d] * jv[d] * sv[d] for d in range(N))
        chk('bit', jj == rho2 and ss == -rho2 and js == 0 and set(pp) <= {0, 15}, 'draw %d: Fierz on the bit rule: psi psi~ = %s + %s I, j.j = rho^2 = %s, s.s = -rho^2, j.s = 0' % (draw, al, be, rho2))
        Sv = spin_forms_engine(Gv, e, psi, nv, mode='vector'); sigv = sigma_frame(Sv, Th, nv); antiv, trv = antisym_report(lower_sigma(sigv))
        chk('ctl', (not antiv) and any(x != 0 for x in trv), 'draw %d: vector-current bilinear: sigma not totally antisymmetric, trace %s != 0' % (draw, [str(x) for x in trv]))
        # [std]
        chi = st.chi(psi0); b = st.bil(chi); sgs = st.sigma(chi); Tls, err = std_antisym(sgs); ks, kres = std_eps_fit(Tls, b['A'])
        chk('std', err < 1e-12 and kres < 1e-12, 'draw %d: textbook sigma^a_bc = (1/2) Re(i chibar Gamma^a Gamma_b Gamma_c chi): totally antisymmetric (%.1e), = k_A eps_abcd A^d with k_A = %.12f (residual %.1e; A = chibar Gamma gamma5 chi)' % (draw, err, ks, kres))
        fz = abs(b['J'] @ st.eta @ b['J'] - b['sig'] ** 2 - b['pi'] ** 2) + abs(b['A'] @ st.eta @ b['A'] + b['J'] @ st.eta @ b['J']) + abs(b['J'] @ st.eta @ b['A'])
        chk('std', fz < 1e-9 * (1 + b['sig'] ** 2), 'draw %d: textbook Fierz J.J = sig^2 + pi^2, A.A = -J.J, J.A = 0 (%.1e)' % (draw, fz))
        _, errc = std_antisym(st.sigma(chi, with_i=False))
        chk('ctl', errc > 1e-3, 'draw %d: [std] i dropped (Re chibar Gamma^a Gamma_b Gamma_c chi): not totally antisymmetric (%.2f)' % (draw, errc))
        sA = np.array([fl(x) for x in sv]); sgnA = 1 if sA @ b['A'] >= 0 else -1; sgnpi = 1 if fl(be) * b['pi'] >= 0 else -1
        dic = max(abs(fl(al) - b['sig']), float(np.max(np.abs(np.array([fl(x) for x in jv]) - b['J']))), float(np.max(np.abs(sA - sgnA * b['A']))), abs(fl(be) - sgnpi * b['pi']))
        chk('bit==std', dic < 1e-9 and b['imag'] < 1e-9, 'draw %d: dictionary chi = M(psi) u: <psi psi~> = chibar chi, j^a = chibar Gamma^a chi, s^a = %+d chibar Gamma^a gamma5 chi, beta = %+d chibar i gamma5 chi (%.1e)' % (draw, sgnA, sgnpi, dic))
        dsg = max(abs(fl(sig[(a, Ai)]) - sgs[(a, Ai)]) for a in range(N) for Ai in range(len(PAIRS)))
        chk('bit==std', dsg < 1e-9, 'draw %d: engine sigma^a_bc = textbook sigma^a_bc (%.1e)' % (draw, dsg))
        out.append(dict(k=k, k1=k1, ks=ks, sgnA=sgnA, sgnpi=sgnpi))
    # (3) the full Lagrangian with derivatives: engine (D_spinor with d psi) = textbook, constant frame, psi linear in x, constant random omega
    A, det, E = rand_matrix(rng); e = const_frame(A, nv); psi0 = rand_even(rng); psid = [rand_even(rng) for _ in range(N)]
    psi = {S: padd(cp(psi0.get(S, 0), nv), {tuple(1 if i == mu else 0 for i in range(N)): F(psid[mu][S]) for mu in range(N) if psid[mu].get(S, 0) != 0}) for S in EVEN}
    psi = {S: p for S, p in psi.items() if p}
    kq = [[F(rng.randint(-3, 3), rng.randint(1, 3)) for mu in range(N)] for Ai in range(len(PAIRS))]
    mm = F(5, 3); Lb = v0(L_dirac(Gv, e, K_forms(kq, nv), psi, mm, nv).get(15, {}), nv) / det
    chi = st.chi(psi0); dchi_c = [st.chi(psid[mu]) for mu in range(N)]
    dchi = [sum(fl(E[mu][a]) * dchi_c[mu] for mu in range(N)) for a in range(N)]
    Kf = [[sum(fl(kq[Ai][mu] * E[mu][a]) for mu in range(N)) for Ai in range(len(PAIRS))] for a in range(N)]
    Ls = st.lagrangian(chi, dchi, Kf, fl(mm))
    chk('bit==std', abs(fl(Lb) - Ls) < 1e-9 * (1 + abs(Ls)), 'L_D (engine D_spinor, d psi included) = textbook Re(chibar i Gamma^a nabla_a chi) - m chibar chi: %.12f vs %.12f (k = 1: same normalisation, same energy sign)' % (fl(Lb), Ls))
    tick('S1 pointwise')
    return out

def part_S2S3(rng, st, k_sig):
    head('S2/S3  constant fields: Theta(T) = kappa S (route i), stationary K of the engine L_tot (route ii), contact term; [std] textbook stationary contorsion')
    Gv = Grav(N, Lie(LOR)); Fm = Gv.Fm; nv = N; res = []
    for draw, kap in enumerate([F(1), F(2, 5), F(3)]):
        A, det, E = rand_matrix(rng); e = const_frame(A, nv); psi0 = rand_even(rng); psi = {S: cp(v, nv) for S, v in psi0.items()}; m = F(7, 4)
        S = spin_forms_engine(Gv, e, psi, nv); s, j, pp, _ = currents(psi, LOR, nv); sv = [v0(p, nv) for p in vec(s)]; ss = sum(LOR[d] * sv[d] ** 2 for d in range(N))
        T, rank, cons = solve_route_i(Gv, e, S, kap, nv); Tl = T_lower(T, E, nv); anti, tr = antisym_report(Tl); t = eps_fit(Tl, sv)
        chk('bit', rank == 24 and cons, 'draw %d (kappa = %s): Theta_A(T) = kappa S_A has a unique solution (rank %d of 24)' % (draw, kap, rank))
        chk('bit', anti and all(x == 0 for x in tr) and t is not None, 'draw %d: T_abc = sq_a T^a(E_b, E_c) totally antisymmetric, no trace; T_abc = t eps_abcd s^d with t/kappa = %s' % (draw, (t / kap) if t is not None else None))
        # route (ii)
        kst, rk2, cons2 = stationary_K(Gv, A, psi0, kap, m); Kst = K_forms(kst, nv)
        Teng = Gv.torsion(Kst, e)
        chk('bit', rk2 == 24 and cons2 and all(forms_equal(Teng[c], T[c], Fm) for c in range(N)), 'draw %d: stationary point of the engine L_tot(K) unique (rank %d); its engine torsion (D_vector, h table) = route-(i) T' % (draw, rk2))
        Kf = {(c, Ai): sum((kst[Ai][mu] * E[mu][c] for mu in range(N)), F(0)) for c in range(N) for Ai in range(len(PAIRS))}
        kK = None; okK = True
        for (c, Ai), v in Kf.items():
            p, q = PAIRS[Ai]
            if c in (p, q): okK &= (v == 0); continue
            d = comp4(p, q, c)[0]; base = kap * LOR[p] * LOR[q] * perm([p, q, c, d]) * sv[d]
            if base == 0: okK &= (v == 0); continue
            if kK is None: kK = v / base
            okK &= (v == kK * base)
        chk('bit', okK and kK is not None, 'draw %d: contorsion K*_c^{ab} = k_K kappa sq_a sq_b eps_abcd s^d with k_K = %s' % (draw, kK))
        Lz = v0(L_tot_value(Gv, e, [{} for _ in range(Gv.G)], psi, kap, m, nv).get(15, {}), nv); Ls_ = v0(L_tot_value(Gv, e, Kst, psi, kap, m, nv).get(15, {}), nv)
        dL = Ls_ - Lz; C = dL / (kap ** 2 * ss * det)
        LDdiff = v0(Fm.add(L_dirac(Gv, e, Kst, psi, m, nv), L_dirac(Gv, e, [{} for _ in range(Gv.G)], psi, m, nv), -1).get(15, {}), nv)
        chk('bit', dL == -kap / 2 * LDdiff, 'draw %d: half rule Delta L_tot = -(kappa/2) (L_D(K*) - L_D(0)) exactly' % draw)
        print('    draw %d: contact Delta L_tot = C kappa^2 (s.s) vol with C = %s  (s.s = %s, det e = %s, kappa = %s)' % (draw, C, ss, det, kap))
        # controls
        Tw, _, _ = solve_route_i(Gv, e, S, -kap, nv)
        chk('ctl', all(forms_equal(Tw[c], Fm.scale(T[c], -1), Fm) for c in range(N)) and any(T[c] for c in range(N)), 'draw %d: wrong sign of lambda (+kappa): T flips (T -> -T), so the sign of the torsion follows the sign input' % draw)
        kw, _, _ = stationary_K(Gv, A, psi0, -kap, m); Lw = v0(L_tot_value(Gv, e, K_forms(kw, nv), psi, -kap, m, nv).get(15, {}), nv) - v0(L_tot_value(Gv, e, [{} for _ in range(Gv.G)], psi, -kap, m, nv).get(15, {}), nv)
        eff_ok, eff_w = dL / (-kap), Lw / kap
        chk('ctl', Lw == dL and eff_w == -eff_ok and dL != 0, 'draw %d: wrong sign of lambda: Delta L_tot unchanged (C = %s) but the effective term Delta L_tot / lambda flips sign' % (draw, Lw / (kap ** 2 * ss * det)))
        Tns, rkns, _ = solve_route_i(Gv, e, S, kap, nv, signs=False)
        chk('ctl', not all(forms_equal(Tns[c], Teng[c], Fm) for c in range(N)), 'draw %d: Theta without (-1)^j: its solution (rank %d) differs from the engine torsion of K*' % (draw, rkns))
        kd, rkd, consd = stationary_K(Gv, A, psi0, kap, m, lagEC=lag_EC_doubled); Kd = K_forms(kd, nv)
        Cd = (v0(L_tot_value(Gv, e, Kd, psi, kap, m, nv, lagEC=lag_EC_doubled).get(15, {}), nv) - Lz) / (kap ** 2 * ss * det)
        chk('ctl', Cd != C, 'draw %d: quadratic term of R doubled (private curvature): C = %s instead of %s' % (draw, Cd, C))
        Sv = spin_forms_engine(Gv, e, psi, nv, mode='vector'); Tv, rkv, _ = solve_route_i(Gv, e, Sv, kap, nv); antiv, trv = antisym_report(T_lower(Tv, E, nv))
        chk('ctl', (not antiv) and any(x != 0 for x in trv), 'draw %d: vector-current source: the solved torsion is not totally antisymmetric and has a trace %s' % (draw, [str(x) for x in trv]))
        kv, _, _ = stationary_K(Gv, A, psi0, kap, m, mode='vector'); dLv = v0(L_tot_value(Gv, e, K_forms(kv, nv), psi, kap, m, nv, mode='vector').get(15, {}), nv) - v0(L_tot_value(Gv, e, [{} for _ in range(Gv.G)], psi, kap, m, nv, mode='vector').get(15, {}), nv)
        # "the vector-current contact term is not C kappa^2 (s.s) vol" is not a wrong version: by Fierz (j.j = -s.s) it is the SAME value.
        jj = sum(LOR[d] * v0(vec(j)[d], nv) ** 2 for d in range(N))
        chk('bit', dLv == dL and dLv == F(3, 16) * kap ** 2 * jj * det, 'draw %d: finding: the vector-current source (trace torsion) gives Delta L = (3/16) kappa^2 (j.j) vol, EQUAL to the axial value by Fierz j.j = -s.s: the contact VALUE does not identify the coupling, the torsion form does' % draw)
        chk('ctl', LDdiff != 0 and v0(L_tot_value(Gv, e, [Fm.scale(Kst[Ai], -1) for Ai in range(Gv.G)], psi, kap, m, nv).get(15, {}), nv) - Lz != dL, 'draw %d: contorsion of the wrong sign (-K*): the difference is not the contact term' % draw)
        # [std]
        chi = st.chi(psi0); b = st.bil(chi); sgs = st.sigma(chi)
        Kstd, dLs, cond = st.stationary(sgs, fl(kap), fl(m), b['sig']); Ts = st.torsion(Kstd)
        Tb = np.array([[[fl(form2_frame(T[a], E, p, q, nv)) for q in range(N)] for p in range(N)] for a in range(N)])
        errT = float(np.max(np.abs(Tb - Ts)) / max(1e-300, np.max(np.abs(Ts))))
        chk('bit==std', errT < 1e-8, 'draw %d: textbook stationary contorsion (numpy, Q 24x24, cond %.1e): torsion T^a_bc = engine T (rel %.1e)' % (draw, cond, errT))
        AA = float(b['A'] @ st.eta @ b['A']); Cs = dLs / (fl(kap) ** 2 * AA)
        chk('bit==std', abs(fl(dL / det) - dLs) < 1e-8 * (1 + abs(dLs)) and abs(Cs - fl(C)) < 1e-9, 'draw %d: textbook contact Delta L = %.12f = engine %.12f; textbook C (in A.A) = %.12f' % (draw, dLs, fl(dL / det), Cs))
        res.append(dict(t=t / kap, C=C, kK=kK, Cd=Cd))
    tick('S2/S3 constant fields')
    return res

def part_curved(rng, t, kK, C):
    head('S2/S3  curved frames: omega = omega_LC (A3, 1-jet) + K*(psi(x), e(x)); torsion, omega-equation and contact term at the origin')
    for seed in range(2):
        rr = random.Random(1000 + seed + rng.randint(0, 10 ** 6))
        Gv = Grav(N, Lie(LOR)); Fm = Gv.Fm; nv = N; kap = [F(1), F(3, 7)][seed]; m = F(1, 3)
        e = rand_frame(rr, N, deg=2, coef=2, density=.5)
        Sk = koszul_S(N, LOR, Gv.L); Dp = anholonomy(Gv, e, nv, 1); oml = omega_closed_form(Gv, e, Sk, nv, 1, Dpre=Dp)[0]
        psi = {S: p for S, p in ((S, gs.rpoly(rr, N, 1, .7)) for S in EVEN) if p}
        with trunc(N, xdeg=1):
            s, j, pp, _ = currents(psi, LOR, nv); sv = vec(s); ss = dot(sv, sv, LOR, nv)
            K = []
            for Ai, (p, q) in enumerate(PAIRS):
                f = {}
                for c in comp4(p, q):
                    d = comp4(p, q, c)[0]; f = Fm.add(f, Fm.wedge({0: sv[d]}, e[c]), kK * kap * LOR[p] * LOR[q] * perm([p, q, c, d]))
                K.append(f)
            omp = [Fm.add(oml[A], K[A]) for A in range(Gv.G)]
            Tp = Gv.torsion(omp, e); T0l = Gv.torsion(oml, e)
            Tc = []
            for a in range(N):
                f = {}
                for (p, q) in PAIRS:
                    if a in (p, q): continue
                    d = comp4(a, p, q)[0]; f = Fm.add(f, Fm.wedge({0: sv[d]}, Fm.wedge(e[p], e[q])), t * kap * LOR[a] * perm([a, p, q, d]))
                Tc.append(f)
            j1 = lambda X: {msk: {k: v for k, v in pp_.items() if sum(k[:N]) <= 1} for msk, pp_ in X.items()}
            clean = lambda X: {msk: p_ for msk, p_ in X.items() if p_}
            chk('bit', all(not clean(j1(T0l[c])) for c in range(N)), 'seed %d: A3 omega_LC is torsion-free to first order (engine torsion)' % seed)
            chk('bit', all(not clean(j1(Fm.add(Tp[c], Tc[c], -1))) for c in range(N)), 'seed %d: engine torsion of omega_LC + K* = closed form T^a = (t kappa) sq_a eps s e e, to first order at the origin' % seed)
            Sx = spin_forms_engine(Gv, e, psi, nv); Th = B1.Theta_forms(Gv, e, Tp)
            at0f = lambda X: {msk: v0(p_, nv) for msk, p_ in X.items() if v0(p_, nv) != 0}
            chk('bit', all(not at0f(Fm.add(Th[(p, q)], Sx[Ai], -kap)) for Ai, (p, q) in enumerate(PAIRS)), 'seed %d: omega-equation Theta_A(T(omega)) = kappa S_A holds at the origin (S_A from the engine variation on the curved frame)' % seed)
            Y = B1.Y_forms(Gv, e); KY = {}
            for Ai, (p, q) in enumerate(PAIRS): KY = Fm.add(KY, Fm.wedge(K[Ai], Y[(p, q)]))
            dL = Fm.add(Fm.add(L_tot_value(Gv, e, omp, psi, kap, m, nv), L_tot_value(Gv, e, oml, psi, kap, m, nv), -1), Fm.d(KY), -1)
            vol = vol_form(Gv, e); pred = v0(ss, nv) * v0(vol.get(15, {}), nv) * C * kap ** 2
            chk('bit', v0(dL.get(15, {}), nv) == pred and pred != 0, 'seed %d: L_tot(omega_LC + K*) - L_tot(omega_LC) - d(K*^A ^ Y_A) = C kappa^2 (s.s) vol at the origin (%s)' % (seed, pred))
            # the exact form d(K* Y) vanishes: K*^{ab} lies in span(e^c, e^d) with {c, d} the complement of {a, b}, and Y_ab = +-e^c e^d.
            chk('bit', not clean(KY), 'seed %d: finding: K*^A ^ Y_A = 0 identically for the axial contorsion, so no exact form is left: the contact term is the whole difference' % seed)
            omw = [Fm.add(oml[A], Fm.scale(K[A], -1)) for A in range(Gv.G)]
            dLw = Fm.add(L_tot_value(Gv, e, omw, psi, kap, m, nv), L_tot_value(Gv, e, oml, psi, kap, m, nv), -1)
            chk('ctl', v0(dLw.get(15, {}), nv) != pred, 'seed %d: omega_LC - K* (contorsion of the wrong sign): the difference is not C kappa^2 (s.s) vol (%s)' % (seed, v0(dLw.get(15, {}), nv)))
    tick('curved')

def main():
    rng = random.Random(20261009); st = Std()
    chk('std', np.allclose(st.G[0] @ st.u, st.u) and np.allclose(st.Jm @ st.u, 1j * st.u), '[std] u: gamma_0 u = u, M(J) u = i u (so M(psi J) u = i chi, M(psi gamma_0) u = chi)')
    part_clifford()
    out = part_S1(rng, st)
    ks = set(str(o['k']) for o in out); k1s = set(str(o['k1']) for o in out)
    chk('bit', len(ks) == 1, 'S1: the same k on every draw: sigma_abc = (%s) eps_abcd s^d; S_bc = (%s) e_b ^ e_c ^ s_hat' % (ks, k1s))
    res = part_S2S3(rng, st, out[0]['k'])
    ts = set(r['t'] for r in res); Cs = set(r['C'] for r in res); kKs = set(r['kK'] for r in res)
    chk('bit', len(ts) == 1 and len(Cs) == 1 and len(kKs) == 1, 'S2/S3: one t, one k_K and one C for every draw and kappa: T_abc = (%s) kappa eps_abcd s^d, K*_c^ab = (%s) kappa sq_a sq_b eps s, Delta L_tot = (%s) kappa^2 (s.s) vol' % (ts, kKs, Cs))
    t = res[0]['t']; kK = res[0]['kK']; C = res[0]['C']
    print('    effective Dirac n-form: L_D + Delta L_tot / lambda = L_D + (%s) kappa (s.s) vol, lambda = -kappa;  s.s = -rho^2 <= 0' % (-C))
    print('    recalled, NOT a check: Hehl-Datta / Perez-Rovelli value |L_int| coefficient 3 kappa / 16 = 3 pi G / 2 on A.A')
    part_curved(rng, t, kK, C)
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('E2')

if __name__ == '__main__': main()
