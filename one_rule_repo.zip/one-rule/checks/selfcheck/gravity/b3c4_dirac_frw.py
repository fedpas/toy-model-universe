#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""B3C4-dirac: the coupled Einstein-Dirac system of the torsionful shell in the FRW frame, solved as a series in t on the bit-rule engine.
   python3 b3c4_dirac_frw.py [--quick]

 n = 4, (+,-,-,-), exact fractions; k = 0, cosmic time, e^0 = dt, e^i = a(t) dx^i; a homogeneous even spinor psi(t) (8 components, polynomials in t).
 omega_LC = A3 closed form; K* = E2's axial contorsion from s = psi gamma_3 psi~ (e2s4_dirac_stress.kstar_forms as a series); omega* = omega_LC + K*.
 The system, as the engine states it: (D) EL_S(omega*) = 0 (the Dirac equation of the torsionful shell, E2S4's Euler-Lagrange forms as series) and
 (E) X_a = E_a(c)(omega*) - kappa tau_a(omega*) = 0 (E_a from the engine's curvature of omega*, tau_a = B3's matter variation of E2's Dirac 4-form).
 Solver: psi_{m+1} from (D) at order t^m (8 exact linear equations, rank 8), a_{m+2} from the space component of (E) at order t^m (affine, slope from a
 second evaluation); the 00 equation is imposed at t = 0 only, through the constant c.  A fresh evaluation then reads all 16 components and the 8 EL_S.
 [bit] claims: the 00 component vanishes at every order computed (the constraint is propagated: the Noether chain B2 + E2S4 on this class); the Einstein
       form of omega_LC alone reads a perfect fluid at rest with rho = m <psi psi~> + rho_c, p = rho_c, rho_c = -(3 kappa/16) s.s = (3 kappa/16)(S^2 + P^2)
       at every order (S, P the scalar and pseudoscalar parts of psi psi~; the Fierz identity -s.s = S^2 + P^2 as a series identity); the total continuity
       (m S + rho_c)' + 3H (m S + 2 rho_c) = 0; the exchange identities d(a^3 S)/dt = c1 kappa a^3 P s^0 and d(a^6 rho_c)/dt = c2 kappa m a^6 P s^0 with
       c1 + c2 = 0 (so a^3 S and a^6 rho_c are separately constant exactly when m P s^0 = 0: the rest class psi commuting with gamma_0, or m = 0).
 [std] numpy only: Dirac matrices (E2's Std), the Christoffel spin connection of the FRW frame (E1's StdSpin on the 1-jet at each time), d_t chi solved
       from the Hehl-Datta form i Gamma^a nabla_a chi = m chi - (3 kappa/8) A_d Gamma^d gamma5 chi (the form e2s4_spin_fluid.std_source uses; not derived
       here), the textbook symmetric stress with L_eff = Re chibar i Gamma^a nabla_a chi - m chibar chi + (3 kappa/16)(A.A), a'' = (a/2)(-kappa p - H^2 + 3c),
       DOP853; compared with the engine's series summed at small t (the deviation must be the first dropped term of the series), the rates of a^3 chibar chi
       and a^6 rho_c at t = 0 from the right-hand side, and the float constraint along the solution.
 Controls: the free spinor (omega_LC in both equations: dust, a^3 S constant, no a^-6 term; its series fails the torsionful 00 equation); the contorsion of
       the wrong sign (omega_LC - K* in both equations: the constraint is not propagated); the free Dirac equation on the torsionful frame (not propagated);
       a wrong contact coefficient (3/8); the sign of the contact term read off E(omega_LC) under -K*.
 Scope: k = 0, classical commuting spinors, one time t0 = 0, series to order 9 for the generic data (a to t^9, psi to t^8, residuals through t^7; the
       comparison with DOP853 uses the series truncated one order below, so that the first dropped term is known), order 8 for the free, rest-class and
       massless solves (residuals through t^6); local in t (the coefficients grow by a factor 2 to 3 per order); no k = +-1, no non-homogeneous spinor,
       nothing about four-fermion physics or quantum averages. kappa and the sign of the source are inputs; c is the constant of the 00 equation at t = 0.
 Exports (no engine object at import): connection, kstar, einstein_series, tau_series, EL_series, eval_components, solve_system, mixed_series, bilinears,
       inv_series, std_rhs, std_solve."""
import os, sys, time, random, math
_here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _here)
from b1lib import *
import b3c4_scalar_frw as BS
import c4_frw as C4
import e2_spin_torsion as E2
import e2s4_dirac_stress as S4
import b3_matter as B3
import e1_lichnerowicz as E1
import numpy as np
from scipy.integrate import solve_ivp

n = 4; NV = 5; LOR = [1, -1, -1, -1]; SQ = LOR; FULL = 15; EVEN = E2.EVEN; PAIRS = E2.PAIRS; C316 = F(3, 16)
QUICK = '--quick' in sys.argv
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def mon(j): return (j, 0, 0, 0, 0)
Z = lambda L: all(x == 0 for x in L)

# ------------------------------------------------------------------------------------------------ [bit] engine pieces as series in t
def omega_lc(Gv, S, e, Kom):
    """A3 closed form through t^Kom"""
    with BS.sbound(Kom, 0): return omega_closed_form(Gv, e, S, NV, Kom)[0]
def kstar(Gv, e, psi, kap, Kom):
    """E2's axial contorsion K*^{pq} = -(kappa/4) sq_p sq_q eps(p, q, c, d) s^d e^c through t^Kom (the series version of e2s4_dirac_stress.kstar_forms)"""
    Fm = Gv.Fm
    with BS.sbound(Kom, 0), trunc(4, xdeg=Kom):
        s = E2.vec(E2.currents(psi, LOR, NV)[0]); Kf = []
        for (p, q) in PAIRS:
            f = {}
            for cc in E2.comp4(p, q):
                d = E2.comp4(p, q, cc)[0]
                if s[d]: f = Fm.add(f, Fm.wedge({0: s[d]}, e[cc]), F(-1, 4) * kap * LOR[p] * LOR[q] * E2.perm([p, q, cc, d]))
            Kf.append(f)
    return Kf
def connection(Gv, S, e, psi, kap, Kom, mode):
    """omega through t^Kom: 'lc' (omega_LC), 'star' (omega_LC + K*), 'minus' (omega_LC - K*: the wrong sign)"""
    om = omega_lc(Gv, S, e, Kom)
    if mode == 'lc': return om
    Kf = kstar(Gv, e, psi, kap, Kom)
    return [Gv.Fm.add(om[A], Kf[A], 1 if mode == 'star' else -1) for A in range(Gv.G)]
def einstein_series(Gv, e, om, c, K):
    with BS.sbound(K, 0), trunc(4, xdeg=K + 1):
        R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(c))
    return Ea
def tau_series(Gv, e, om, psi, m, K):
    """tau_a of E2's Dirac 4-form with the connection om, B3's frame variation, through t^K"""
    with BS.sbound(K, 0): return B3.matter_variation(Gv, e, lambda ep, Ep: E2.L_dirac(Gv, ep, om, psi, m, NV), xdeg=K, nv=NV)
def EL_series(Gv, e, om, psi, m, K):
    """EL_S = dL/dpsi_S - d P_S (4-forms) through t^K: E2S4's EL_forms with the series truncation (psi, e through t^(K+1); om through t^K)"""
    Fm = Gv.Fm
    with BS.sbound(K + 1, 0), trunc(4, xdeg=K + 1):
        Th = E2.theta_forms(Gv, e); P = S4.P_forms(Gv, e, psi, Th)
    dL = {}
    for S_ in EVEN:
        ps = dict(psi); ps[S_] = padd(ps.get(S_, {}), S4.LAMV)
        with BS.sbound(K, 0), trunc(4, xdeg=K, lam=1): dL[S_] = S4.lamp(E2.L_dirac(Gv, e, om, ps, m, NV, 'axial', Th))
    with BS.sbound(K, 0), trunc(4, xdeg=K):
        return {S_: Fm.add(dL[S_], Fm.d(P[S_]), -1) for S_ in EVEN}
def components(Gv, Ea, tau, kap, K):
    X = [Gv.Fm.add(Ea[a], tau[a], -F(kap)) for a in range(4)]
    return {(a, mu): BS.tser(X[a].get(FULL ^ (1 << mu), {}), K) for a in range(4) for mu in range(4)}
def eval_components(Gv, S, ac, psi, m, kap, c, K, emode):
    """[bit] the 16 components of X_a = E_a(c)(omega) - kappa tau_a(omega) through t^K (omega of mode emode through t^(K+1))"""
    e = C4.frw_frame([F(x) for x in ac], k=0, nv=NV); om = connection(Gv, S, e, psi, kap, K + 1, emode)
    return components(Gv, einstein_series(Gv, e, om, c, K), tau_series(Gv, e, om, psi, m, K), kap, K)
def el_coeffs(Gv, S, ac, psi, m, kap, K, dmode):
    """[bit] the dx^0123 coefficients of the 8 EL_S through t^K (omega of mode dmode through t^K)"""
    e = C4.frw_frame([F(x) for x in ac], k=0, nv=NV); om = connection(Gv, S, e, psi, kap, K, dmode)
    EL = EL_series(Gv, e, om, psi, m, K)
    return {S_: BS.tser(EL[S_].get(FULL, {}), K) for S_ in EVEN}
def solve_system(Gv, S, a01, psi0, m, kap, N, dmode='star', emode='star', c=None):
    """[bit] a_2..a_N and psi_1..psi_(N-1): psi_{m+1} from the Dirac equation (connection dmode) at order t^m, a_{m+2} from the space component of the
       frame equation (connection emode) at order t^m; c from the 00 component at t = 0 when None. Returns (a coefficients, psi, c, ranks)"""
    ac = [F(x) for x in a01]; psi = {S_: {mon(0): F(v)} for S_, v in psi0.items() if v != 0}; ranks = []; M0 = None
    for mm in range(N - 1):
        el = lambda ps: [el_coeffs(Gv, S, ac + [F(0)], ps, m, kap, mm, dmode)[S_][mm] for S_ in EVEN]
        b = el(psi)
        if M0 is None:                                                      # the principal symbol in psi_{m+1}, read from the engine at order 0 (8 unit evaluations)
            cols = []
            for T_ in EVEN:
                ps = {S_: dict(p) for S_, p in psi.items()}; ps[T_] = padd(ps.get(T_, {}), {mon(1): F(1)}); cols.append([x - y for x, y in zip(el(ps), b)])
            M0 = [[cols[j][i] for j in range(8)] for i in range(8)]
        rows = [[(mm + 1) * x for x in r] for r in M0]                     # at order m the coefficient of psi_{m+1} is (m + 1) times the one of psi_1 at order 0 (only d psi and d P_S carry psi_{m+1} at order m); the fresh evaluation afterwards verifies every order
        w, rank, _, cons = solve_exact(rows, [-x for x in b]); ranks.append(rank)
        if w is None or rank < 8: raise ValueError('Dirac solve at order %d: rank %d' % (mm, rank))
        for j, T_ in enumerate(EVEN):
            if w[j] != 0: psi[T_] = padd(psi.get(T_, {}), {mon(mm + 1): w[j]})
        if mm == 0 and c is None:
            r = [eval_components(Gv, S, ac + [F(0)], psi, m, kap, cc, 0, emode)[(0, 0)][0] for cc in (F(0), F(1))]
            c = -r[0] / (r[1] - r[0])
        r0 = eval_components(Gv, S, ac + [F(0)], psi, m, kap, c, mm, emode)[(1, 1)][mm]
        if mm == 0:                                                          # the slope in a_2 at order 0 (second evaluation); at order m the coefficient of a_{m+2} is (m+2)(m+1)/2 times it (only a'' carries a_{m+2} at order m); the fresh evaluation afterwards verifies every order
            sl0 = eval_components(Gv, S, ac + [F(1)], psi, m, kap, c, 0, emode)[(1, 1)][0] - r0
            if sl0 == 0: raise ValueError('zero slope')
        ac.append(-r0 / (sl0 * (mm + 2) * (mm + 1) / 2))
    return ac, psi, c, ranks

# ------------------------------------------------------------------------------------------------ series helpers (plain lists)
def inv_series(A, K):
    A = BS.pad(A, K); inv = [1 / A[0]]
    for j in range(1, K + 1): inv.append(-sum(A[i] * inv[j - i] for i in range(1, j + 1)) / A[0])
    return inv
def spow(A, k, K):
    out = BS.pad([F(1)], K)
    for _ in range(k): out = BS.smul(out, A, K)
    return out
def mixed_series(comp, ac, K):
    """M^h_a (series) from the engine's component layout on the k = 0 FRW frame: comp[(a, mu)] = -a^3 M^0_a (mu = 0), -(-1)^mu a^2 M^mu_a (mu = i)"""
    ia = inv_series([F(x) for x in ac], K); ia2 = BS.smul(ia, ia, K); ia3 = BS.smul(ia2, ia, K); M = {}
    for h in range(4):
        for a in range(4):
            M[(h, a)] = BS.smul([-x for x in comp[(a, h)]], ia3, K) if h == 0 else BS.smul([-F((-1) ** h) * x for x in comp[(a, h)]], ia2, K)
    return M
def bilinears(psi, K):
    """S = scalar part of psi psi~, P = its pseudoscalar part, s^d (axial current), s.s, all as series through t^K (E2's currents, exact products)"""
    with BS.sbound(K, 0):
        s, j, pp, _ = E2.currents(psi, LOR, NV); sv = E2.vec(s)
    ser = lambda p: BS.tser(p, K)
    svs = [ser(p) for p in sv]; ss = [F(0)] * (K + 1)
    for d in range(4): ss = [x + LOR[d] * y for x, y in zip(ss, BS.smul(svs[d], svs[d], K))]
    return ser(pp.get(0, {})), ser(pp.get(FULL, {})), svs, ss
def fit_one(lhs, rhs, K):
    """c with lhs == c rhs as series through t^K (c from the first non-zero rhs coefficient); (c, ok, trivial)"""
    j = next((i for i, x in enumerate(rhs[:K + 1]) if x != 0), None)
    if j is None: return None, Z(lhs[:K + 1]), True
    c = lhs[j] / rhs[j]; return c, all(x == c * y for x, y in zip(lhs[:K + 1], rhs[:K + 1])), False

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
def std_pieces(st, a, ad, chi, m, kap):
    """at one time: d_t chi from the Hehl-Datta form, rho = T_00, p = T_11 (lowered), bilinears; spin connection from E1's StdSpin on the 1-jet frame"""
    e = [{1: {mon(0): 1.0}}] + [{1 << i: {mon(0): float(a), mon(1): float(ad)}} for i in (1, 2, 3)]
    sS = E1.StdSpin(e, {}, 4, LOR, st.G); x0 = np.zeros(4); E = sS.Emat(x0); A_ = sS.spinconn(sS.omega(x0))
    G, Gup, g5 = st.G, st.Gup, st.g5; bl = st.bil(chi); Av = bl['A']; Al = [LOR[d] * Av[d] for d in range(4)]; AA = float(sum(LOR[d] * Av[d] ** 2 for d in range(4)))
    def nab(y):
        cov = [y + A_[0] @ chi] + [A_[mu] @ chi for mu in (1, 2, 3)]
        return [sum(E[mu, a_] * cov[mu] for mu in range(4)) for a_ in range(4)]
    rhs = m * chi - (3.0 * kap / 8) * sum(Al[d] * Gup[d] @ g5 for d in range(4)) @ chi
    lin = lambda y: 1j * sum(Gup[a_] @ nab(y)[a_] for a_ in range(4))
    b0 = lin(np.zeros(4, complex)); Mx = np.column_stack([lin(np.eye(4)[k].astype(complex)) - b0 for k in range(4)])
    y = np.linalg.solve(Mx, rhs - b0); nb = nab(y); bar = st.bar(chi)
    Leff = float((bar @ (1j * sum(Gup[a_] @ nb[a_] for a_ in range(4)))).real) - m * float((bar @ chi).real) + (3.0 * kap / 16) * AA
    T = lambda a_, b_: 0.5 * float((bar @ (1j * G[a_] @ nb[b_])).real + (bar @ (1j * G[b_] @ nb[a_])).real) - (LOR[a_] if a_ == b_ else 0) * Leff
    return dict(dchi=y, rho=T(0, 0), p=T(1, 1), T01=T(0, 1), T12=T(1, 2), S=float(bl['sig']), P=float(bl['pi']), A0=float(Av[0]), AA=AA)
def std_rhs(t, y, st, m, kap, c):
    a, ad = y[0], y[1]; chi = y[2:6] + 1j * y[6:10]; d = std_pieces(st, a, ad, chi, m, kap)
    add = a / 2 * (-kap * d['p'] - (ad / a) ** 2 + 3 * c)
    return [ad, add] + list(d['dchi'].real) + list(d['dchi'].imag)
def std_solve(st, a01, chi0, m, kap, c, tmax):
    y0 = [float(a01[0]), float(a01[1])] + list(chi0.real) + list(chi0.imag)
    return solve_ivp(std_rhs, (0, tmax), y0, method='DOP853', rtol=1e-12, atol=1e-14, dense_output=True, args=(st, m, kap, c))

# ================================================================================================ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm; st = E2.Std()
    rng = random.Random(71); N = 5 if QUICK else 9; K = N - 2; N3 = 4 if QUICK else 8; NC = 4 if QUICK else 5   # N: the generic data (one order more than the comparison needs); N3: the free, rest-class and massless solves
    kap, m = F(1), F(7, 4); a01 = (F(1), F(1, 2))
    def draw(masks, lo, hi, least, generic=False):
        while True:
            p = {S_: rng.randint(lo, hi) for S_ in masks}
            if sum(1 for v in p.values() if v) < least: continue
            p = {S_: F(v) for S_, v in p.items() if v}
            if not generic: return p
            Sb, Pb, sv, ss = bilinears({S_: {mon(0): v} for S_, v in p.items()}, 0)
            if Pb[0] != 0 and sv[0][0] != 0 and Sb[0] != 0: return p         # generic: P(0), s^0(0), S(0) all non-zero
    psiG = draw(EVEN, -1, 1, 5, generic=True); psiR = draw([0, 6, 10, 12], -2, 2, 3)
    pstr = lambda p: '{' + ', '.join('%d: %s' % (S_, p[S_]) for S_ in sorted(p)) + '}'
    ev16 = lambda comp: all(Z(v) for v in comp.values())
    offd = lambda comp: all(Z(comp[(a, mu)]) for a in range(4) for mu in range(4) if a != mu)

    # ------------------------------------------------------------------ 1. the generic data: the series, the constraint propagated
    head('1. generic homogeneous spinor psi(0) = %s, m = %s, kappa = %s, a0 = %s, H0 = %s: the Einstein-Dirac series of the torsionful shell to order %d' % (pstr(psiG), m, kap, a01[0], a01[1], N))
    ac, psi, c, ranks = solve_system(Gv, S, a01, psiG, m, kap, N); tick('solve generic (N = %d)' % N)
    print('    c = %s;  a_j = %s;  ranks of the Dirac solves %s' % (c, [str(x) for x in ac], ranks))
    comp = eval_components(Gv, S, ac, psi, m, kap, c, K, 'star'); EL = el_coeffs(Gv, S, ac, psi, m, kap, K, 'star')
    print('    R00 by order (fresh evaluation): %s' % [str(x) for x in comp[(0, 0)]])
    chk('bit', all(r == 8 for r in ranks), 'the Dirac equation of the torsionful shell fixes psi_{m+1} at every order (rank 8 of 8, orders 0..%d)' % (N - 2))
    chk('bit', all(Z(comp[(i, i)]) for i in (1, 2, 3)) and all(Z(v) for v in EL.values()), 'fresh evaluation: the three space components of E_a(omega*) - kappa tau_a(omega*) and the 8 Euler-Lagrange forms vanish through t^%d' % K)
    chk('bit', offd(comp), 'the 12 off-diagonal components vanish through t^%d' % K)
    chk('bit', Z(comp[(0, 0)]), 'the 00 component (Friedmann constraint), imposed at t = 0 only through c = %s, vanishes at every order 0..%d: the constraint is propagated' % (c, K))
    # claim B: the Einstein form of omega_LC alone reads the fluid; the spinor bilinears as series
    e = C4.frw_frame(ac, k=0, nv=NV); M = mixed_series(components(Gv, einstein_series(Gv, e, omega_lc(Gv, S, e, K + 1), c, K), [{} for _ in range(4)], 0, K), ac, K)
    Sb, Pb, sv, ss = bilinears(psi, K); SP2 = [x + y for x, y in zip(BS.smul(Sb, Sb, K), BS.smul(Pb, Pb, K))]
    rho_c = [-C316 * kap * x for x in ss]; rho = [m * x + y for x, y in zip(Sb, rho_c)]
    chk('bit', all(Z(M[(h, a)]) for h in range(4) for a in range(4) if h != a) and M[(1, 1)] == M[(2, 2)] == M[(3, 3)], 'the Einstein form of omega_LC on the solved series is a perfect fluid at rest: M^b_a = G^b_a - 3c delta diagonal and isotropic through t^%d' % K)
    chk('bit', [-x for x in ss] == SP2 and not Z(SP2), 'Fierz: -s.s = S^2 + P^2 as a series identity through t^%d (S, P the scalar and pseudoscalar parts of psi psi~)' % K)
    chk('bit', M[(0, 0)] == [kap * x for x in rho] and M[(1, 1)] == [-kap * x for x in rho_c] and not Z(rho_c),
        'M^0_0 = kappa (m S + rho_c) and M^i_i = -kappa rho_c with rho_c = -(3 kappa/16) s.s through t^%d: the source is dust (m <psi psi~>) plus the stiff contact fluid p_c = rho_c at every order (rho_c(0) = %s)' % (K, rho_c[0]))
    chk('ctl', not (M[(1, 1)] == [-F(3, 8) * kap * kap * x for x in ss]), 'the contact coefficient 3/8 in place of 3/16: fails')
    # claim C: continuity; claim D: the two parts separately
    a_ = BS.pad(ac, K); ad = BS.sder(a_, K - 1); cont = [x + 3 * y for x, y in zip(BS.smul(a_, BS.sder(rho, K - 1), K - 1), BS.smul(ad, [m * x + 2 * y for x, y in zip(Sb, rho_c)], K - 1))]
    chk('bit', Z(cont), 'total continuity a (m S + rho_c)\' + 3 a\' (m S + 2 rho_c) = 0 through t^%d (dust + stiff, one conservation law)' % (K - 1))
    a3 = spow(a_, 3, K); a6 = spow(a_, 6, K); Ps0 = BS.smul(Pb, sv[0], K)
    dA3 = BS.sder(BS.smul(a3, Sb, K), K - 1); r1 = BS.smul([kap * x for x in a3], Ps0, K)
    dA6 = BS.sder(BS.smul(a6, rho_c, K), K - 1); r2 = BS.smul([kap * m * x for x in a6], Ps0, K)
    c1, ok1, triv1 = fit_one(dA3, r1, K - 1); c2, ok2, triv2 = fit_one(dA6, r2, K - 1)
    print('    d(a^3 S)/dt by order: %s;  d(a^6 rho_c)/dt: %s;  P(0) = %s, s^0(0) = %s' % ([str(x) for x in dA3], [str(x) for x in dA6], Pb[0], sv[0][0]))
    chk('bit', not triv1 and ok1 and c1 != 0 and not Z(dA3), 'generic data: a^3 S is NOT constant: d(a^3 S)/dt = c1 kappa a^3 P s^0 exactly through t^%d with c1 = %s (P s^0 != 0: the mass term rotates S into P)' % (K - 1, c1))
    chk('bit', not triv2 and ok2 and c2 == -c1 and not Z(dA6), 'generic data: a^6 rho_c is NOT constant: d(a^6 rho_c)/dt = c2 kappa m a^6 P s^0 through t^%d with c2 = -c1 = %s: the two parts exchange energy, only the total is conserved' % (K - 1, c2))
    tick('part 1')

    # ------------------------------------------------------------------ 2. [std] DOP853 on the textbook system
    head('2. [std] Dirac matrices, Christoffel spin connection, Hehl-Datta equation, textbook stress, DOP853; against the engine series summed at small t')
    chi0 = st.chi({S_: float(v) for S_, v in psiG.items()}); d0 = std_pieces(st, float(a01[0]), float(a01[1]), chi0, float(m), float(kap))
    c_std = float(a01[1] / a01[0]) ** 2 - float(kap) * d0['rho'] / 3
    chk('bit==std', abs(c_std - float(c)) < 1e-12 * (1 + abs(c_std)), 'the constant of the 00 equation at t = 0 from the textbook stress, c_std = H0^2 - kappa T_00(0)/3 = %.15g, equals the engine\'s c = %.15g' % (c_std, float(c)))
    chk('std', abs(d0['T01']) < 1e-12 and abs(d0['T12']) < 1e-12 and abs(d0['rho'] - (float(m) * d0['S'] + 0.1875 * float(kap) * (-d0['AA']))) < 1e-12 and abs(d0['p'] - 0.1875 * float(kap) * (-d0['AA'])) < 1e-12,
        'textbook stress at t = 0: T_01 = T_12 = 0, T_00 = m chibar chi + (3 kappa/16)(-A.A), T_11 = (3 kappa/16)(-A.A)')
    chi1 = st.chi({S_: float(psi[S_].get(mon(1), 0)) for S_ in psi}); a2s = float(a01[0]) / 2 * (-float(kap) * d0['p'] - float(a01[1] / a01[0]) ** 2 + 3 * float(c))
    chk('bit==std', float(np.max(np.abs(chi1 - d0['dchi']))) < 1e-12 * (1 + float(np.max(np.abs(chi1)))) and abs(2 * float(ac[2]) - a2s) < 1e-12 * (1 + abs(a2s)),
        'at t = 0: the engine\'s psi_1 maps by E2\'s dictionary to d_t chi of the Hehl-Datta equation (%.1e), and 2 a_2 = a\'\' of the textbook space equation (%.1e)' % (float(np.max(np.abs(chi1 - d0['dchi']))), abs(2 * float(ac[2]) - a2s)))
    sgP = -1 if abs(float(Pb[0]) + d0['P']) < 1e-12 else (1 if abs(float(Pb[0]) - d0['P']) < 1e-12 else 0)
    chk('bit==std', sgP != 0 and abs(float(Sb[0]) - d0['S']) < 1e-12 and abs(float(sv[0][0]) - d0['A0']) < 1e-12, 'dictionary at t = 0: <psi psi~> = chibar chi, s^0 = A^0 and the pseudoscalar part of psi psi~ = (%d) chibar i gamma5 chi' % sgP)
    sol = std_solve(st, a01, chi0, float(m), float(kap), float(c), 0.2)
    # the series summed at small t, truncated one order below what the solve gives (a to t^(N-1), psi and the bilinears to t^(N-2)), so that the first
    # dropped terms a_N t^N, psi_(N-1) t^(N-1), q_(N-1) t^(N-1) are known exactly: the deviation from DOP853 must BE that term (truncation), with a
    # relative remainder that shrinks with t; a wrong coefficient at a lower order would add delta t^j and the remainder would grow as t shrinks.
    # The coefficients grow by about a factor 2 to 3 per order (the series are local in t), so the dropped term, not the last kept one, is the estimate.
    Mq = N - 2; SbQ, PbQ, svQ, ssQ = bilinears(psi, N - 1); SP2Q = [x + y for x, y in zip(BS.smul(SbQ, SbQ, N - 1), BS.smul(PbQ, PbQ, N - 1))]
    ser = lambda cs, t, M: sum(float(x) * t ** j for j, x in enumerate(cs[:M + 1]))
    psi_at = lambda t, M: {S_: sum(float(v) * t ** key[0] for key, v in p.items() if key[0] <= M) for S_, p in psi.items()}
    chiD = st.chi({S_: float(psi[S_].get(mon(N - 1), 0)) for S_ in psi})
    print('    growth of the coefficients: max|psi_j| = %s;  |a_j| = %s' % (['%.3g' % max(abs(float(psi[S_].get(mon(j), 0))) for S_ in psi) for j in range(N)], ['%.3g' % abs(float(x)) for x in ac]))
    names = ('a', 'chi', 'chibar chi', 'A^0', '-A.A'); agree = True; rem = {}
    for t in (0.01, 0.02, 0.04, 0.08):
        y = sol.sol(t); chi = y[2:6] + 1j * y[6:10]; bl = st.bil(chi); AA = -float(sum(LOR[d] * bl['A'][d] ** 2 for d in range(4)))
        val = (y[0], chi, bl['sig'], bl['A'][0], AA)
        D = (y[0] - ser(ac, t, N - 1), chi - st.chi(psi_at(t, Mq)), bl['sig'] - ser(SbQ, t, Mq), bl['A'][0] - ser(svQ[0], t, Mq), AA - ser(SP2Q, t, Mq))
        drop = (float(ac[N]) * t ** N, chiD * t ** (N - 1), float(SbQ[N - 1]) * t ** (N - 1), float(svQ[0][N - 1]) * t ** (N - 1), float(SP2Q[N - 1]) * t ** (N - 1))
        nrm = lambda v: float(np.max(np.abs(v)))
        agree = agree and all(nrm(D[i]) <= 1e-9 * (1 + nrm(val[i])) + 2 * nrm(drop[i]) for i in range(5))
        rem[t] = [nrm(D[i] - drop[i]) / nrm(drop[i]) for i in range(5)]
        print('    t = %s: |DOP853 - series| = %s;  first dropped terms = %s;  |D - dropped| / |dropped| = %s' % (t, ', '.join('%.1e' % nrm(x) for x in D), ', '.join('%.1e' % nrm(x) for x in drop), ', '.join('%.3f' % x for x in rem[t])))
    chk('bit==std', agree, 'engine series (a to order %d, psi and the bilinears to order %d) summed at t = 0.01, 0.02, 0.04, 0.08 against DOP853 (rtol 1e-12): a, chi (E2\'s dictionary), chibar chi, A^0 and -A.A agree within 1e-9 (1 + |value|) + 2 |first dropped term|' % (N - 1, Mq))
    pairs = [(0, 0.04, 0.08)] + [(i, 0.02, 0.04) for i in (1, 2, 3, 4)]                                     # a at the larger pair: at t <= 0.02 its dropped term a_N t^N sits at the roundoff floor
    trunc_ok = all(rem[t2][i] < 0.25 and rem[t1][i] < rem[t2][i] for i, t1, t2 in pairs)
    if QUICK: print('    (quick mode: the series is too short for the 25 percent bound on the remainder; the ratios above are information only, not a check)')
    else: chk('bit==std', trunc_ok, 'the deviation IS the first dropped term: |D - dropped| / |dropped| < 0.25 and smaller at the smaller t (t = 0.02 and 0.04 for chi and the bilinears, 0.04 and 0.08 for a): truncation, no difference between the engine series and the textbook system to this order')
    def con(t):
        y = sol.sol(t); d = std_pieces(st, y[0], y[1], y[2:6] + 1j * y[6:10], float(m), float(kap)); return 3 * (y[1] / y[0]) ** 2 - 3 * float(c) - float(kap) * d['rho'], d, y
    cmax = max(abs(con(t)[0]) for t in np.linspace(0, 0.2, 11))
    chk('std', cmax < 1e-9, 'DOP853 keeps the constraint |3H^2 - 3c - kappa T_00| <= %.1e on [0, 0.2] with the textbook stress of the Hehl-Datta solution' % cmax)
    # the rates at t = 0 from the right-hand side itself (no finite difference in t): d(bilinear)/dt by a central difference in chi along d_t chi, exact for
    # the quadratic forms chibar chi and A^d; d(A.A)/dt = 2 A.dA
    eps = 1e-3; bp = st.bil(chi0 + eps * d0['dchi']); bm = st.bil(chi0 - eps * d0['dchi'])
    dS0 = (bp['sig'] - bm['sig']) / (2 * eps); dA = [(bp['A'][d] - bm['A'][d]) / (2 * eps) for d in range(4)]; Av0 = st.bil(chi0)['A']; dAA = 2 * sum(LOR[d] * Av0[d] * dA[d] for d in range(4))
    a0f, a1f = float(a01[0]), float(a01[1]); dS2 = 3 * a0f ** 2 * a1f * d0['S'] + a0f ** 3 * dS0; dC2 = 6 * a0f ** 5 * a1f * 0.1875 * float(kap) * (-d0['AA']) + a0f ** 6 * 0.1875 * float(kap) * (-dAA)
    pr1 = float(c1) * float(kap) * d0['A0'] * sgP * d0['P']; pr2 = float(c2) * float(kap) * float(m) * d0['A0'] * sgP * d0['P']
    chk('bit==std', abs(dS2 - float(dA3[0])) < 1e-9 * (1 + abs(dS2)) and abs(dC2 - float(dA6[0])) < 1e-9 * (1 + abs(dC2)) and abs(dS2 - pr1) < 1e-9 * (1 + abs(pr1)) and abs(dC2 - pr2) < 1e-9 * (1 + abs(pr2)) and pr1 != 0,
        'the rates at t = 0 from the Hehl-Datta right-hand side, d(a^3 chibar chi)/dt = %.10g and d(a^6 rho_c)/dt = %.10g, equal the engine\'s series coefficients %s and %s, and the exchange rule with the dictionary\'s sign of P: c1 kappa a^3 (%d chibar i gamma5 chi) A^0 = %.6g, c2 kappa m a^6 (%d chibar i gamma5 chi) A^0 = %.6g' % (dS2, dC2, dA3[0], dA6[0], sgP, pr1, sgP, pr2))
    tick('part 2')

    # ------------------------------------------------------------------ 3. the free spinor (omega_LC in both equations) and the two wrong systems
    head('3. controls: the free spinor; the contorsion of the wrong sign; the free Dirac equation on the torsionful frame')
    K = N3 - 2                                                              # parts 3 and 4 solve to order N3
    acF, psiF, cF, _ = solve_system(Gv, S, a01, psiG, m, kap, N3, 'lc', 'lc'); tick('solve free')
    compF = eval_components(Gv, S, acF, psiF, m, kap, cF, K, 'lc'); ELF = el_coeffs(Gv, S, acF, psiF, m, kap, K, 'lc')
    eF = C4.frw_frame(acF, k=0, nv=NV); MF = mixed_series(components(Gv, einstein_series(Gv, eF, omega_lc(Gv, S, eF, K + 1), cF, K), [{} for _ in range(4)], 0, K), acF, K)
    SbF, PbF, svF, ssF = bilinears(psiF, K); aF = BS.pad(acF, K)
    print('    free system: off-diagonal components (a, mu) non-zero: %s' % [(a, mu) for a in range(4) for mu in range(4) if a != mu and not Z(compF[(a, mu)])])
    chk('bit', all(Z(compF[(a, a)]) for a in range(4)) and all(Z(v) for v in ELF.values()), 'free system (omega_LC in the Dirac and in the frame equation): the 8 EL_S and the 4 diagonal components of E - kappa tau vanish through t^%d, the 00 constraint propagated (c = %s)' % (K, cF))
    asym = all(F((-1) ** i) * compF[(j, i)][l] == -F((-1) ** j) * compF[(i, j)][l] for i in (1, 2, 3) for j in (1, 2, 3) if i != j for l in range(K + 1))
    chk('bit', not offd(compF) and asym and all(Z(compF[(0, i)]) and Z(compF[(i, 0)]) for i in (1, 2, 3)), 'free system: the space-space off-diagonal part of E - kappa tau is non-zero and antisymmetric (the canonical Dirac stress is not symmetric: its antisymmetric part is the spin divergence, E2S4); the 0i parts vanish')
    chk('bit', MF[(0, 0)] == [kap * m * x for x in SbF] and Z(MF[(1, 1)]) and Z(BS.sder(BS.smul(spow(aF, 3, K), SbF, K), K - 1)), 'free spinor: rho = m S, p = 0 (dust) and a^3 S constant through t^%d; no a^-6 term' % K)
    SP2F = [x + y for x, y in zip(BS.smul(SbF, SbF, K), BS.smul(PbF, PbF, K))]; dF = BS.sder(BS.smul(spow(aF, 6, K), SP2F, K), K - 1); cF1, okF, trF = fit_one(dF, BS.smul([m * x for x in spow(aF, 6, K)], BS.smul(PbF, svF[0], K), K), K - 1)
    chk('bit', not trF and okF and cF1 == F(16, 3) * c2, 'free spinor: d(a^6 (S^2 + P^2))/dt = %s m a^6 P s^0 through t^%d, the same rate as with the contact term ((16/3) c2 = %s): the free zitterbewegung; the kappa terms cancel in this rate' % (cF1, K - 1, F(16, 3) * c2))
    compFs = eval_components(Gv, S, acF, psiF, m, kap, cF, 1, 'star')
    chk('ctl', compFs[(0, 0)][0] == -C316 * kap * kap * acF[0] ** 3 * ssF[0] != 0, 'the free series on the torsionful frame equation fails the 00 equation at t^0 by a0^3 kappa rho_c(0) = -(3/16) kappa^2 a0^3 s.s(0) = %s' % compFs[(0, 0)][0])
    for name, dm, em in (('contorsion of the wrong sign (omega_LC - K* in both equations)', 'minus', 'minus'), ('free Dirac equation on the torsionful frame (omega* in the frame equation, omega_LC in the Dirac equation)', 'lc', 'star')):
        acW, psiW, cW, _ = solve_system(Gv, S, a01, psiG, m, kap, NC, dm, em); compW = eval_components(Gv, S, acW, psiW, m, kap, cW, NC - 2, em); R00 = compW[(0, 0)]
        first = next((j for j, x in enumerate(R00) if x != 0), None)
        print('    %s: R00 by order %s; R11 %s; R22 %s; off-diagonal non-zero %s' % (name.split(' (')[0], [str(x) for x in R00], [str(x) for x in compW[(1, 1)]], [str(x) for x in compW[(2, 2)]], [(a, mu) for a in range(4) for mu in range(4) if a != mu and not Z(compW[(a, mu)])]))
        chk('ctl', Z(compW[(1, 1)]) and R00[0] == 0 and first is not None, '%s: the space equation used by the solver holds through t^%d but the 00 constraint is NOT propagated (first non-zero at t^%s); other space components non-zero: %s' % (name, NC - 2, first, not Z(compW[(2, 2)])))
    eW = C4.frw_frame(acW, k=0, nv=NV)
    acM, psiM, cM, _ = solve_system(Gv, S, a01, psiG, m, kap, 2, 'minus', 'minus'); eM = C4.frw_frame(acM, k=0, nv=NV)
    MM = mixed_series(components(Gv, einstein_series(Gv, eM, omega_lc(Gv, S, eM, 1), cM, 0), [{} for _ in range(4)], 0, 0), acM, 0); SbM, _, _, ssM = bilinears(psiM, 0)
    chk('ctl', MM[(1, 1)][0] != C316 * kap * kap * ssM[0] and MM[(0, 0)][0] != kap * (m * SbM[0] - C316 * kap * ssM[0]), 'wrong sign of the contorsion: the Einstein form of omega_LC does not read rho = m S + rho_c, p = rho_c at t = 0: M^0_0(0) = %s against %s, M^1_1(0) = %s against %s' % (MM[(0, 0)][0], kap * (m * SbM[0] - C316 * kap * ssM[0]), MM[(1, 1)][0], C316 * kap * kap * ssM[0]))
    tick('part 3')

    # ------------------------------------------------------------------ 4. the rest class and the massless spinor: both parts conserved separately
    head('4. the rest class (psi(0) in span{1, e12, e13, e23}, commuting with gamma_0) and the massless generic spinor: a^3 S and a^6 rho_c')
    for name, p0, mm_ in (('rest class, m = %s' % m, psiR, m), ('massless generic, m = 0', psiG, F(0))):
        acX, psiX, cX, _ = solve_system(Gv, S, a01, p0, mm_, kap, N3); tick('solve ' + name.split(',')[0])
        compX = eval_components(Gv, S, acX, psiX, mm_, kap, cX, K, 'star'); ELX = el_coeffs(Gv, S, acX, psiX, mm_, kap, K, 'star')
        SbX, PbX, svX, ssX = bilinears(psiX, K); aX = BS.pad(acX, K); rcX = [-C316 * kap * x for x in ssX]
        dA3X = BS.sder(BS.smul(spow(aX, 3, K), SbX, K), K - 1); dA6X = BS.sder(BS.smul(spow(aX, 6, K), rcX, K), K - 1)
        chk('bit', ev16(compX) and all(Z(v) for v in ELX.values()), '%s, psi(0) = %s: solved through t^%d, all 16 components and the 8 EL_S vanish, the 00 constraint propagated (c = %s)' % (name, pstr(p0), K, cX))
        if mm_ != 0:
            inclass = all(S_ in (0, 6, 10, 12) for S_ in psiX)
            chk('bit', inclass and Z(PbX) and Z(svX[0]) and Z(dA3X) and Z(dA6X) and not Z(rcX), 'rest class: psi(t) stays in span{1, e12, e13, e23}, P = s^0 = 0 at every order, and a^3 S and a^6 rho_c are both constant through t^%d: dust + stiff fluid, separately conserved' % K)
        else:
            chk('bit', Z(dA6X) and not Z(rcX) and not Z(dA3X), 'm = 0: a^6 rho_c constant through t^%d (the source is the stiff fluid alone, rho = p = rho_c); a^3 S is not constant (S still rotates into P), which is harmless as m S = 0' % K)
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('B3C4-dirac')

if __name__ == '__main__': main()
