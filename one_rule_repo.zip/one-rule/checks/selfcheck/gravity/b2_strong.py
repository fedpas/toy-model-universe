#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""B2-strong.  The Noether identities of b2_noether.py on strong random fields, with a stated failure bound.   python3 b2_strong.py [n ...]   (default 3 4)

 Statement: the identities of b2_noether.py hold on fields whose every jet coefficient is an integer uniform in {-50..50} (point mass p = 1/101):
   Lorentz: dL = 0 along de^c = -h_Ab^c lam^A e^b, dom = D lam; B1's three pieces sum to zero; Theta = D Y; (D Theta)_ab = e_a ^ E_b - e_b ^ E_a;
            at zero torsion e_a ^ E_b - e_b ^ E_a = 0 (A3 closed-form omega, value at the origin);
   diffeomorphisms: (i) dL along (L_xi e, L_xi om) = d(i_xi L); (ii) L_xi e = D xi + i_xi T - h (i_xi om) e, L_xi om = i_xi R + D(i_xi om);
            J: i_xi L = xi^a E_a + (i_xi R^A) Y_A;  N: xi^a (D E)_a = (i_xi T^b) ^ E_b + (i_xi R^A) ^ Theta_A = xi^a einstein_rhs_a;  the frame form (xi = d_mu).
 Bound: a false version whose residual is a non-zero polynomial of degree <= D in the sampled coefficients passes one field with probability <= D p / (1 - r p)
   (Schwartz-Zippel; r = degree of a rejected polynomial, here det e(0) for frames), N independent fields <= that to the N-th power.
 [bit]  b2_noether.lorentz_part and diffeo_part run UNCHANGED.  Their draws (the engine's rform and rpoly, B2's rand_vec for xi and rand_frame) are replaced in
        memory by the strong sampler of a2b_strong_sampling (s_poly, s_form, s_frame).  Lorentz: six fields per n, three at c = 0 and three at c = 1/3 (dL = 0 by the
        first variation on all six at n = 3, on two at n = 4); diffeomorphisms:
        three fields per n, each at c = 0 and 1/3 (every identity is affine in c).  The zero-torsion check of lorentz_part reads one frame per n: it is repeated
        here with the same engine calls on three frames per n, c = 0 and 1/3, R = 50 and 500.  The quadratic part runs diffeo_part on e, omega of x-degree 2.
 Degree check: (a) along a random line t -> b + t a of strong fields, the exact degree in t of every term of every identity (finite differences) is at most
        its count D, and D is reached; (b) the order of the jets that each identity reads from each field (perturbation by a homogeneous polynomial of x-degree j)
        against the x-degree of the sampled field: a field of lower x-degree leaves part of the identity untested.
 [std]  the law of the replaced draws (P(coefficient = 0) = 1/101 within 4 sigma, constant term 1 with probability 1/101: no fallback constant);
        B2's numpy route (std_part: textbook curvature and torsion, nine-point stencils) on strong fields, compared with the engine [bit==std].
 Controls: N with the sign of the torsion term flipped, N without the curvature term, the frame form with the torsion sign flipped, the Lorentz identity with the
        sign of D Theta flipped: each fails on every field; B2's own controls on the strong fields; B2's own draws are far from the law above; the naive
        derivative xi^r d_r e in place of L_xi e agrees with it for a constant xi, which the jet check flags; a calibration on 50 fields at n = 3.
 Scope: n = 3, 4 (the quadratic part and the jet orders at n = 3), exact fractions, fixed seeds.  The bound is a statement about the sampling; a pass adds no physics."""
import sys, os, time, random, itertools, math, contextlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from b1lib import *
from fractions import Fraction as F
import b1_first_variation as B1
import b2_noether as B2
import a2b_strong_sampling as AB
from g2_forms_calc import interior, lie, frame_comps, D_dual_bivector, coord_vec, form_eq

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
R50, R500 = 50, 500
CS = [F(0), F(1, 3)]
LTRAIN, LFRESH = [1, 2], [3, 4, 5, 6]                                          # Lorentz: seeds of lorentz_part; c = CS[seed % 2]
DSEEDS = [1, 2, 3]                                                             # diffeomorphisms: seeds of diffeo_part, each at both c
BOUND = {}                                                                     # (identity, n, R) -> dict(D, r, N)
def note(name, n, D, N, R=R50, r=0): BOUND[(name, n, R)] = dict(D=D, r=r, N=N)
def zero(n): return (0,) * n
def xdeg_of(n): return 2 if n < 4 else 1                                       # B2's x-degree of lam and xi

# ------------------------------------------------------------------------------------------------ the strong draws, in memory
@contextlib.contextmanager
def strong_draws(R=R50, xdeg=None):
    """B2's draws replaced: the engine's rform / rpoly (as a2b_strong_sampling.strong_engine_sampler does), B2's rand_vec (xi) and rand_frame (the zero-torsion
    frame); xdeg: forms of this x-degree in place of the affine ones"""
    old = (gs.rform, gs.rpoly, B2.rand_vec, B2.rand_frame)
    gs.rform = lambda rng, n, degree, deg=1, density=.6: AB.s_form(rng, n, degree, max(deg, xdeg or 0), R)
    gs.rpoly = lambda rng, n, deg, density: AB.s_poly(rng, n, deg, R)
    B2.rand_vec = lambda rng, n, deg=1, density=.6, nv=None: [AB.s_poly(rng, n, deg, R, nv) for _ in range(n)]
    B2.rand_frame = lambda rng, n, deg=2, coef=3, density=.55, nv=None: AB.s_frame(rng, n, deg, R)
    try: yield
    finally: gs.rform, gs.rpoly, B2.rand_vec, B2.rand_frame = old

def b2_controls(label):
    """B2's own controls (b2_noether.CTL), counted on the strong fields of the last part"""
    for (n, name), (dif, seen) in sorted(B2.CTL.items(), key=str):
        chk('ctl', dif == seen and seen > 0, 'n=%d %s: %s: the wrong version fails on %d of %d strong samples' % (n, label, name, dif, seen))
    B2.CTL.clear()

# ------------------------------------------------------------------------------------------------ [std] the law of the draws
def n_mons(n, d): return sum(1 for ex in itertools.product(range(d + 1), repeat=n) if sum(ex) <= d)
def draw_stats(n, K, strong):
    Gv = Grav(n, Lie(LORENTZ(n))); xd = xdeg_of(n); slots = zeros = cst = ones = 0; det_ok = True
    with (strong_draws() if strong else contextlib.nullcontext()):
        for k in range(K):
            rng = random.Random(1000 * n + k)
            e, om = B1.rand_fields(Gv, rng); lam = [gs.rpoly(rng, n, xd, .5) for _ in range(Gv.G)]; xi = B2.rand_vec(rng, n, xd)
            polys = [(X.get(1 << mu, {}), 1) for X in e + om for mu in range(n)] + [(p, xd) for p in lam + xi]
            if strong:
                fr = B2.rand_frame(rng, n, deg=2); polys += [(fr[a].get(1 << mu, {}), 2) for a in range(n) for mu in range(n)]
                det_ok &= det_inv([[at0(fr[a].get(1 << mu, {}), n) for mu in range(n)] for a in range(n)])[0] != 0
            for p, d in polys:
                m = n_mons(n, d); slots += m; zeros += m - len(p); cst += 1; ones += int(p.get(zero(n), 0) == 1)
    return zeros / slots, ones / cst, slots, cst, det_ok
def part_sampler(ns):
    head('Sampler [std]: the draws of lorentz_part, diffeo_part and std_part (B1.rand_fields, lam, xi, the zero-torsion frame), replaced in memory')
    p = 1 / 101; sd = lambda m: 4 * math.sqrt(p * (1 - p) / m)
    for n in ns:
        z, o, s, c, det_ok = draw_stats(n, 60, True)
        chk('std', abs(z - p) < sd(s) and abs(o - p) < sd(c) and det_ok, 'n=%d: P(coefficient = 0) = %.5f over %d coefficients and P(constant term = 1) = %.5f over %d polynomials, against 1/101 = %.5f (4 sigma %.5f, %.5f): every jet coefficient drawn uniformly, no fallback constant; every frame has det e(0) != 0' % (n, z, s, o, c, p, sd(s), sd(c)))
        zw, ow, sw, cw, _ = draw_stats(n, 60, False)
        chk('ctl', abs(zw - p) > 10 * sd(sw), 'n=%d: without the replacement (B2\'s own draws: a coefficient present with probability 1/2, integers in -3..3) P(coefficient = 0) = %.3f: far from 1/101, so the replacement is in effect where it is used' % (n, zw))

# ------------------------------------------------------------------------------------------------ Lorentz: B2's lorentz_part, unchanged, on strong fields
def lorentz_fields(n, seed):
    """the draws of lorentz_part for this seed (same rng calls)"""
    sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); rng = random.Random(500 * n + seed); e, om = B1.rand_fields(Gv, rng)
    lam = [{0: gs.rpoly(rng, n, 2 if n < 4 else 1, .5)} for _ in range(Gv.G)]
    return Gv, sq, e, om, lam
def lorentz_sides(Gv, sq, e, om, c):
    Fm = Gv.Fm; P = pairs_of(Gv.L); R = Gv.curvature(om); T = Gv.torsion(om, e); E, _ = Gv.einstein(None, e, R, c)
    DTh = D_dual_bivector(Gv, om, B2.by_A(Gv, B1.Theta_forms(Gv, e, T)))
    X = [Fm.add(Fm.wedge(Fm.scale(e[a], sq[a]), E[b]), Fm.wedge(Fm.scale(e[b], sq[b]), E[a]), -1) for (a, b) in P]
    return DTh, X
def part_lorentz(n):
    before = len(FAILS)
    with strong_draws():
        B2.lorentz_part(n, CS, train=LTRAIN, verify=LFRESH)
        head('n = %d  Lorentz identity recomputed on the same strong fields (same rng calls): the true sign holds, a flipped sign fails' % n)
        good = bad = tot = 0
        for seed in LTRAIN + LFRESH:
                c = CS[seed % len(CS)]; Gv, sq, e, om, lam = lorentz_fields(n, seed); DTh, X = lorentz_sides(Gv, sq, e, om, c); Fm = Gv.Fm; tot += 1
                good += all(form_eq(DTh[A], X[A]) for A in range(Gv.G)); bad += not all(form_eq(Fm.scale(DTh[A], -1), X[A]) for A in range(Gv.G))
        chk('bit', good == tot, 'n=%d: (D Theta)_ab = e_a ^ E_b - e_b ^ E_a on all %d fields (three at c = 0, three at c = 1/3)' % (n, tot))
        chk('ctl', bad == tot, 'n=%d: with the sign of D Theta flipped (a wrong sign of the torsion side) the identity fails on %d of %d fields' % (n, bad, tot))
    ok = len(FAILS) == before
    if n == 3: note('Lorentz dL = 0 (first variation)', n, n + 1, 3 if ok else 0)
    else: print('  (n = %d: dL = 0 by the direct first variation on the two train fields, one per c; Lorentz invariance is bounded through B1\'s formula (bounded by a2b_strong_sampling) and the pieces below)' % n)
    note('Lorentz: B1 pieces sum to zero', n, n + 1, 3 if ok else 0)
    note('Theta = D Y, D D Y = -(1/2) f R Y', n, n, 6 if ok else 0)
    note('(D Theta)_ab = e_a E_b - e_b E_a', n, n, 3 if ok else 0)
    tick('n=%d Lorentz' % n)

# ------------------------------------------------------------------------------------------------ zero torsion: lorentz_part's check, three frames per n
def sym_case(n, seed, R):
    """lorentz_part's zero-torsion lines with a strong frame: torsion zero at the origin, e_a E_b - e_b E_a = 0 there, E != 0; control: omega shifted"""
    sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm; P = pairs_of(Gv.L); rng = random.Random(seed); e = AB.s_frame(rng, n, 2, R)
    S = koszul_S(n, sq, Gv.L); om, Rr = engine_om_R(Gv, e, S, n); out = {}
    anti = lambda E: [Fm.add(Fm.wedge(Fm.scale(e[a], sq[a]), E[b]), Fm.wedge(Fm.scale(e[b], sq[b]), E[a]), -1) for (a, b) in P]
    for c in CS:
        with trunc(n, xdeg=1): E, _ = Gv.einstein(None, e, Rr, c)
        with trunc(n, xdeg=0):
            T = Gv.torsion(om, e); A0 = anti(E); omb = [Fm.add(om[A], {1 << (A % n): {zero(n): F(1)}}) for A in range(Gv.G)]; Rb = Gv.curvature(omb)
            Eb, _ = Gv.einstein(None, e, Rb, c); Ab = anti(Eb)
        t0 = all(at0(p, n) == 0 for x in T for p in x.values()); a0 = all(at0(p, n) == 0 for x in A0 for p in x.values())
        nzE = any(at0(p, n) != 0 for x in E for p in x.values()); ctl = any(at0(p, n) != 0 for x in Ab for p in x.values())
        out[c] = (t0 and a0 and nzE, ctl)
    return out
def part_sym(n):
    head('n = %d  zero torsion (lorentz_part\'s lines, same engine calls): e_a ^ E_b - e_b ^ E_a = 0 at the origin of three strong frames (x-degree 2), c = 0 and 1/3' % n)
    for R in (R50, R500):
        good = 0
        for k in range(3):
            seed = 90000 + 1000 * n + 10 * R + k; out = sym_case(n, seed, R); ok = all(v[0] for v in out.values()); good += ok
            chk('bit', ok, 'n=%d R=%d frame %d: torsion of the closed-form omega 0 at the origin, the antisymmetric part 0 at c = 0 and 1/3, E != 0' % (n, R, k + 1))
            chk('ctl', all(v[1] for v in out.values()), 'n=%d R=%d frame %d: omega shifted by a constant (torsion at the origin): the antisymmetric part is not 0, c = 0 and 1/3' % (n, R, k + 1))
        note('zero torsion: E symmetric (c = 0 part; c-part degree n)', n, 5 * n - 2, good if good == 3 else 0, R, r=n)
    tick('n=%d zero torsion' % n)

# ------------------------------------------------------------------------------------------------ diffeomorphisms: B2's diffeo_part, unchanged, on strong fields
def diffeo_fields(n, seed):
    """the draws of diffeo_part for this seed (same rng calls)"""
    sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); rng = random.Random(700 * n + seed); e, om = B1.rand_fields(Gv, rng); xi = B2.rand_vec(rng, n, xdeg_of(n))
    return Gv, sq, e, om, xi
def noether_sides(Gv, e, om, xi, c):
    Fm = Gv.Fm; n = Gv.n; R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, c)
    xa = frame_comps(Gv, xi, e); DE = Gv.D_covector(om, E); Th = B2.by_A(Gv, B1.Theta_forms(Gv, e, T)); lhs = {}
    for a in range(n): lhs = Fm.add(lhs, B2.pf(Fm, xa[a], DE[a]))
    Tt = B2.wsum(Fm, [(interior(Gv, xi, T[b]), E[b]) for b in range(n)]); Rt = B2.wsum(Fm, [(interior(Gv, xi, R[A]), Th[A]) for A in range(Gv.G)])
    return lhs, Tt, Rt, (R, T, E, F_, DE, Th)
def frame_form(Gv, e, om, c, parts):
    """xi = d_mu, mu = 0..n-1: (i_mu T^b) E_b + (i_mu R^A) Theta_A = e^a_mu einstein_rhs_a = e^a_mu (D E)_a; and the same with the torsion term's sign flipped"""
    R, T, E, F_, DE, Th = parts; Fm = Gv.Fm; n = Gv.n; rhsE = Gv.einstein_rhs(e, T, R, c, F_); ok = True; flip_fails = False
    for mu in range(n):
        v = coord_vec(n, mu); a1 = B2.wsum(Fm, [(interior(Gv, v, T[b]), E[b]) for b in range(n)]); a2 = B2.wsum(Fm, [(interior(Gv, v, R[A]), Th[A]) for A in range(Gv.G)])
        r1 = {}; l1 = {}
        for a in range(n): r1 = Fm.add(r1, B2.pf(Fm, e[a].get(1 << mu, {}), rhsE[a])); l1 = Fm.add(l1, B2.pf(Fm, e[a].get(1 << mu, {}), DE[a]))
        ok &= form_eq(Fm.add(a1, a2), r1) and form_eq(l1, r1); flip_fails |= not form_eq(Fm.add(a2, a1, -1), l1)
    return ok, flip_fails
def naive_lie(Gv, xi, X):
    """xi^r d_r X (plain derivatives of the coefficients; no d xi term): the naive derivative, a wrong L_xi unless xi is constant"""
    out = {}
    for m, p in X.items():
        q = {}
        for r in range(Gv.n): q = padd(q, gs.pmul(xi[r], pder(p, r)))
        if q: out[m] = q
    return out
def part_diffeo(n, quad=False, seeds=DSEEDS):
    before = len(FAILS); xd = xdeg_of(n); tag = ' (e, omega of x-degree 2)' if quad else ''
    with strong_draws(xdeg=2 if quad else None):
        B2.diffeo_part(n, CS, seeds=list(seeds), fit_seeds=list(seeds), xdeg=xd)
        head('n = %d  diffeomorphism identity recomputed on the same strong fields%s: N and the frame form on every field; wrong versions fail' % (n, tag))
        cnt = dict(N=0, frame=0, flipN=0, dropR=0, flipF=0, naive=0, const=0); tot = 0
        for seed in seeds:
            for c in CS:
                Gv, sq, e, om, xi = diffeo_fields(n, seed); Fm = Gv.Fm; tot += 1
                lhs, Tt, Rt, parts = noether_sides(Gv, e, om, xi, c)
                cnt['N'] += form_eq(lhs, Fm.add(Tt, Rt)); cnt['flipN'] += not form_eq(lhs, Fm.add(Rt, Tt, -1)); cnt['dropR'] += not form_eq(lhs, Tt)
                fo, ff = frame_form(Gv, e, om, c, parts); cnt['frame'] += fo; cnt['flipF'] += ff
                if n > 3: cnt['naive'] += 1; cnt['const'] += 1; continue           # the naive-derivative control runs at n = 3
                cnt['naive'] += any(not form_eq(lie(Gv, xi, x), naive_lie(Gv, xi, x)) for x in e)
                xi0 = [{zero(n): p[zero(n)]} if p.get(zero(n)) else {} for p in xi]
                cnt['const'] += all(form_eq(lie(Gv, xi0, x), naive_lie(Gv, xi0, x)) for x in e)
        chk('bit', cnt['N'] == tot and cnt['frame'] == tot, 'n=%d%s: N holds and the frame form holds for every mu on all %d (field, c) samples (%d fields, c = 0 and 1/3)' % (n, tag, tot, len(seeds)))
        chk('ctl', cnt['flipN'] == tot, 'n=%d%s: N with the sign of the torsion term (i_xi T^b) E_b flipped fails on %d of %d samples' % (n, tag, cnt['flipN'], tot))
        chk('ctl', cnt['dropR'] == tot, 'n=%d%s: N without the curvature term (i_xi R^A) Theta_A fails on %d of %d samples' % (n, tag, cnt['dropR'], tot))
        chk('ctl', cnt['flipF'] == tot, 'n=%d%s: the frame form with the torsion sign flipped fails on %d of %d samples' % (n, tag, cnt['flipF'], tot))
        if n == 3: chk('ctl', cnt['naive'] == tot, 'n=%d%s: the naive derivative xi^r d_r e^a in place of L_xi e^a differs on %d of %d samples (xi of x-degree %d)' % (n, tag, cnt['naive'], tot, xd))
        if n == 3: chk('bit==std', cnt['const'] == tot, 'n=%d%s: for xi cut to its constant part (x-degree 0) L_xi e^a (the engine\'s d and i_xi) equals the naive xi^r d_r e^a (plain derivatives) on %d of %d samples: a constant xi does not see the d xi term' % (n, tag, cnt['const'], tot))
    ok = len(FAILS) == before; N = len(seeds) if ok else 0
    if quad:
        note('(i) and the chain on e, omega of x-degree 2 (reach the 2-jet of omega)', n, n + 1, N); note('N on e, omega of x-degree 2', n, n + 2, N)
    else:
        note('(i) dL along L_xi = d(i_xi L) (affine omega only)', n, n + 1, N); note('(ii) split of L_xi', n, 3, N); note('J', n, n + 1, N)
        note('N, N = xi^a einstein_rhs_a, the chain', n, n + 2, N); note('frame form (xi = d_mu)', n, n + 1, N)
    tick('n=%d diffeomorphisms%s' % (n, tag))

# ------------------------------------------------------------------------------------------------ degree check (a): degree in the sampled coefficients along a line
def diffeo_terms(Gv, f, c, fv=True):
    e, om, xi = f['e'], f['om'], f['xi']; Fm = Gv.Fm; n = Gv.n
    lhs, Tt, Rt, (R, T, E, F_, DE, Th) = noether_sides(Gv, e, om, xi, c); xa = frame_comps(Gv, xi, e); rhsE = Gv.einstein_rhs(e, T, R, c, F_); xr = {}; xE = {}
    for a in range(n): xr = Fm.add(xr, B2.pf(Fm, xa[a], rhsE[a])); xE = Fm.add(xE, B2.pf(Fm, xa[a], E[a]))
    Lf = lambda ee, oo: B1.lag_EC(Gv, ee, oo, c); iL = interior(Gv, xi, Lf(e, om))
    iR = [interior(Gv, xi, x) for x in R]; iT = [interior(Gv, xi, x) for x in T]; Y = B2.by_A(Gv, B1.Y_forms(Gv, e)); RY = B2.wsum(Fm, [(iR[A], Y[A]) for A in range(Gv.G)])
    Le = [lie(Gv, xi, x) for x in e]; Lom = [lie(Gv, xi, x) for x in om]; Xv = [{0: p} if p else {} for p in xa]; Dxi = Gv.D_vector(om, Xv)
    lam = [interior(Gv, xi, x) for x in om]; rot, _ = B2.lorentz_var(Gv, e, om, lam); Dlam = Gv.D_bivector(om, lam)
    t = {'N': {'xi^a (D E)_a': ([lhs], n + 2), '(i_xi T^b) E_b': ([Tt], n + 2), '(i_xi R^A) Theta_A': ([Rt], n + 2), 'xi^a einstein_rhs_a': ([xr], n + 2)},
         'J': {'i_xi L': ([iL], n + 1), 'xi^a E_a': ([xE], n + 1), '(i_xi R^A) Y_A': ([RY], n + 1)},
         '(ii)': {'L_xi e': (Le, 2), 'D xi^a': (Dxi, 3), 'i_xi T': (iT, 3), 'rotation term': (rot, 3), 'L_xi om': (Lom, 2), 'i_xi R': (iR, 3), 'D(i_xi om)': (Dlam, 3)}}
    if fv:
        first, _ = B1.first_variation(Gv, Lf, e, om, Le, Lom); t['(i)'] = {'first variation along L_xi': ([first], n + 1), 'd(i_xi L)': ([Fm.d(iL)], n + 1)}
    return t
def lorentz_terms(Gv, f, c, fv=True):
    e, om, lam = f['e'], f['om'], f['lam']; n = Gv.n; sq = LORENTZ(n)
    de, dom = B2.lorentz_var(Gv, e, om, lam); ep, op, dth = B1.rhs_pieces(Gv, e, om, de, dom, c); DTh, X = lorentz_sides(Gv, sq, e, om, c)
    T = Gv.torsion(om, e); Th = B2.by_A(Gv, B1.Theta_forms(Gv, e, T)); DY = D_dual_bivector(Gv, om, B2.by_A(Gv, B1.Y_forms(Gv, e)))
    return {'Lorentz pieces': {'de^a E_a': ([ep], n + 1), 'dom Theta': ([op], n + 1), 'd(dom Y)': ([dth], n)},
            '(D Theta) = e E - e E': {'(D Theta)_ab': (DTh, n), 'e_a E_b - e_b E_a': (X, n)},
            'Theta = D Y': {'Theta_A': (Th, n - 1), '(D Y)_A': (DY, n - 1)}}
IDENT_D = lambda n: {'N': n + 2, 'J': n + 1, '(ii)': 3, '(i)': n + 1, 'Lorentz pieces': n + 1, '(D Theta) = e E - e E': n, 'Theta = D Y': n - 1}
KINDS = {'e': 'form1', 'om': 'form1', 'xi': 'vec', 'lam': 'form0'}
def draw(rng, n, names, xd_forms=1):
    G = Grav(n).G; xd = xdeg_of(n); out = {}
    if 'e' in names: out['e'] = [AB.s_form(rng, n, 1, xd_forms, R50) for _ in range(n)]
    if 'om' in names: out['om'] = [AB.s_form(rng, n, 1, xd_forms, R50) for _ in range(G)]
    if 'xi' in names: out['xi'] = [AB.s_poly(rng, n, xd, R50) for _ in range(n)]
    if 'lam' in names: out['lam'] = [{0: AB.s_poly(rng, n, xd, R50)} for _ in range(G)]
    return out
def comb(Fm, b, a, t):
    return {k: ([padd(x, y, t) for x, y in zip(b[k], a[k])] if KINDS[k] == 'vec' else [Fm.add(x, y, t) for x, y in zip(b[k], a[k])]) for k in b}
def fd_degree(vals):
    """exact degree of a sequence of polynomial values at t = 0..T (finite differences); T means 'T or more'"""
    deg = -1
    for key in set().union(*vals):
        seq = [v.get(key, F(0)) for v in vals]; k = 0; last = -1
        while any(seq): last = k; seq = [seq[i + 1] - seq[i] for i in range(len(seq) - 1)]; k += 1
        deg = max(deg, last)
    return deg
def flat(forms): return {(i, m, k): v for i, X in enumerate(forms) for m, p in X.items() for k, v in p.items()}
def part_lines(ns):
    head('Degree check (a) [bit]: exact degree in t of every term along a random line t -> b + t a of strong fields (t = 0..D+1): each term within its count D, and D reached ((i) at n = 3)')
    for n in ns:
        Gv = Grav(n, Lie(LORENTZ(n))); Fm = Gv.Fm; D_ = IDENT_D(n)
        for names, fn, seed in ((('e', 'om', 'xi'), diffeo_terms, 71), (('e', 'om', 'lam'), lorentz_terms, 72)):
            rng = random.Random(1000 * n + seed); a = draw(rng, n, names); b = draw(rng, n, names); Tmax = max(D_.values()) + 1; vals = {}; counts = {}
            for t in range(Tmax + 1):
                for I, d in fn(Gv, comb(Fm, b, a, t), F(1, 3), fv=(n == 3)).items():
                    for nm, (forms, cnt) in d.items(): vals.setdefault((I, nm), []).append(flat(forms)); counts[(I, nm)] = cnt
            meas = {k: fd_degree(v) for k, v in vals.items()}
            for I in sorted({k[0] for k in meas}):
                ks = sorted(k for k in meas if k[0] == I); top = max(meas[k] for k in ks)
                chk('bit', all(0 <= meas[k] <= counts[k] for k in ks) and top == D_[I], 'n=%d %s: degrees %s against counts %s; D = %d is reached and not exceeded' % (n, I, ', '.join('%s %d' % (k[1], meas[k]) for k in ks), ', '.join(str(counts[k]) for k in ks), D_[I]))
        tick('n=%d degree lines' % n)
    for n in ns:                                                                # the zero-torsion part: det(e(0))^4 (e_a ^ E_b)(0) along a line of frames
        sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm; P = pairs_of(Gv.L); S = koszul_S(n, sq, Gv.L); D = 5 * n - 2; rng = random.Random(77000 + n)
        while True:
            a = AB.s_frame(rng, n, 2, R50); b = AB.s_frame(rng, n, 2, R50); line = [[Fm.add(x, y, t) for x, y in zip(b, a)] for t in range(D + 2)]
            dets = [det_inv([[at0(fr[i].get(1 << mu, {}), n) for mu in range(n)] for i in range(n)])[0] for fr in line]
            if all(d != 0 for d in dets): break
        vals = []
        for fr, dt in zip(line, dets):
            om, Rr = engine_om_R(Gv, fr, S, n)
            with trunc(n, xdeg=1): E, _ = Gv.einstein(None, fr, Rr, F(0))
            with trunc(n, xdeg=0): X = [Fm.wedge(Fm.scale(fr[i], sq[i]), E[j]) for (i, j) in P]
            vals.append({(k, m): at0(p, n) * dt ** 4 for k, Xk in enumerate(X) for m, p in Xk.items()})
        d = fd_degree(vals)
        chk('bit', d == D, 'n=%d zero torsion: det(e(0))^4 (e_a ^ E_b)(0) at c = 0 is a polynomial of degree %d along a line of frames (t = 0..%d): the count 5n - 2 = %d is reached and not exceeded' % (n, d, D + 1, D))
    tick('degree lines')

# ------------------------------------------------------------------------------------------------ degree check (b): the jets each identity reads, against the x-degree of the draws
PRED = {'N': {'xi': 0, 'e': 1, 'om': 1}, 'J': {'xi': 0, 'e': 0, 'om': 1}, '(ii)': {'xi': 1, 'e': 1, 'om': 1}, '(i)': {'xi': 1, 'e': 1, 'om': 2},
        'Lorentz pieces': {'lam': 1, 'e': 1, 'om': 1}, '(D Theta) = e E - e E': {'e': 0, 'om': 1}, 'Theta = D Y': {'e': 1, 'om': 0}}
def bump(rng, f, name, j, n):
    hp = lambda: {ex: F(rng.choice((-1, 1)) * rng.randint(1, 50)) for ex in itertools.product(range(j + 1), repeat=n) if sum(ex) == j}
    g = dict(f); X = f[name]; kind = KINDS[name]
    if kind == 'vec': g[name] = [padd(p, hp()) for p in X]
    elif kind == 'form0': g[name] = [{0: padd(x.get(0, {}), hp())} for x in X]
    else: g[name] = [dict(list(x.items()) + [(1 << mu, padd(x.get(1 << mu, {}), hp())) for mu in range(n)]) for x in X]
    return g
def at_origin(forms, n): return {(i, m): at0(p, n) for i, X in enumerate(forms) for m, p in X.items()}
def jet_reads(n, fn, f, seed, jmax=3):
    Gv = Grav(n, Lie(LORENTZ(n))); c = F(1, 3); base = {(I, t): at_origin(v[0], n) for I, d in fn(Gv, f, c).items() for t, v in d.items()}; rng = random.Random(seed); reads = {}
    for name in f:
        for j in range((jmax if name == 'om' else jmax - 1) + 1):
            for I, d in fn(Gv, bump(rng, f, name, j, n), c).items():
                for t, v in d.items():
                    o = at_origin(v[0], n); b0 = base[(I, t)]
                    if any(o.get(k, 0) != b0.get(k, 0) for k in set(o) | set(b0)): reads[(I, name)] = max(reads.get((I, name), -1), j)
    return reads
DIFF_IDS = ['N', 'J', '(ii)', '(i)']; LOR_IDS = ['Lorentz pieces', '(D Theta) = e E - e E', 'Theta = D Y']
def part_jets(n=3):
    head('Degree check (b) [bit]: the order of the jets each identity reads at a point (perturbation by a homogeneous polynomial of x-degree j = 0..3 for omega, 0..2 for the others), n = %d, against the x-degree of the draws' % n)
    xd = xdeg_of(n); sampled = {'e': 1, 'om': 1, 'xi': xd, 'lam': xd}; reach = {}; got_all = {}
    for names, fn, ids, seed in ((('e', 'om', 'xi'), diffeo_terms, DIFF_IDS, 81), (('e', 'om', 'lam'), lorentz_terms, LOR_IDS, 82)):
        f = draw(random.Random(2000 + seed), n, names); reads = jet_reads(n, fn, f, seed)
        for I in ids:
            got = {x: reads.get((I, x), -1) for x in names}; want = {x: PRED[I].get(x, -1) for x in names}; got_all[I] = got; reach[I] = all(got[x] <= sampled[x] for x in names)
            chk('bit', got == want, 'n=%d %s reads the jets of order %s (count: %s; -1: not read); B2\'s draws have x-degree %s: %s' % (n, I, got, want, {x: sampled[x] for x in names}, 'reached' if reach[I] else 'NOT reached (part of the identity is untested on these draws)'))
    chk('bit', [I for I in reach if not reach[I]] == ['(i)'], 'n=%d: only (i) (and the chain, which contains d(i_xi L)) reads a jet the affine draws do not reach, the 2-jet of omega; the part on e, omega of x-degree 2 reaches it' % n)
    chk('ctl', got_all['(ii)']['xi'] >= 1 and got_all['(i)']['xi'] >= 1, 'n=%d: a field of too low degree is recognised: (ii) and (i) read the %d-jet of xi, so a constant xi (x-degree 0) does not reach them (on a constant xi, L_xi e equals the naive derivative: see the diffeomorphism parts)' % (n, got_all['(ii)']['xi']))
    tick('jet orders n=%d' % n)

# ------------------------------------------------------------------------------------------------ calibration
def part_calib(N=50):
    n = 3; head('Calibration [ctl] n = 3: N with the torsion sign flipped and N without the curvature term (degree n + 2 = 5) on %d strong fields, c alternating 0, 1/3: misses <= 5/101 per field' % N)
    tf = mf = md = 0
    with strong_draws():
        for k in range(N):
            rng = random.Random(4242 + k); Gv = Grav(n, Lie(LORENTZ(n))); e, om = B1.rand_fields(Gv, rng); xi = B2.rand_vec(rng, n, 2); Fm = Gv.Fm
            lhs, Tt, Rt, _ = noether_sides(Gv, e, om, xi, CS[k % 2]); tf += not form_eq(lhs, Fm.add(Tt, Rt)); mf += form_eq(lhs, Fm.add(Rt, Tt, -1)); md += form_eq(lhs, Tt)
    chk('bit', tf == 0, 'the true N holds on all %d fields' % N)
    chk('ctl', mf / N <= 5 / 101 and md / N <= 5 / 101, 'missed %d and %d of %d <= 5/101 = 0.0495 per field' % (mf, md, N))
    chk('ctl', mf == 0 and md == 0, 'both false versions are caught on every one of the %d fields' % N)

# ------------------------------------------------------------------------------------------------ the bound table
def part_table():
    head('Bound table: per field D p / (1 - r p), p = 1/(2R+1), and combined over the N independent fields that passed (exact; printed as decimals)')
    print('  %-66s %2s %4s %4s %2s %2s %11s %11s' % ('identity', 'n', 'D', 'R', 'r', 'N', 'per field', 'combined'))
    worst = {}
    for (name, n, R), d in sorted(BOUND.items(), key=lambda kv: (kv[0][1], kv[0][0], kv[0][2])):
        p = F(1, 2 * R + 1); b = d['D'] * p / (1 - d['r'] * p); comb_ = b ** d['N'] if d['N'] else None
        print('  %-66s %2d %4d %4d %2d %2d %11.3e %11s' % (name, n, d['D'], R, d['r'], d['N'], float(b), ('%.3e' % float(comb_)) if comb_ is not None else 'none'))
        grp = 'zero torsion R=%d' % R if name.startswith('zero torsion') else 'fields'
        worst[grp] = max(worst.get(grp, F(0)), comb_ if comb_ is not None else F(1))
    chk('bit', all(d['N'] >= 3 for d in BOUND.values()), 'every identity passed on at least three independent strong fields (frames)')
    from decimal import Decimal, Context, ROUND_CEILING
    def up(x, d=4):
        """the Fraction x rounded UP to d significant digits, printed as %e: a bound printed as 'at most' must not be rounded down (audit AU-G3-05)"""
        return '%.*e' % (d - 1, float(Context(prec=d, rounding=ROUND_CEILING).divide(Decimal(x.numerator), Decimal(x.denominator))))
    bf, b5, b50 = worst.get('fields', F(1)), worst.get('zero torsion R=500', F(1)), worst.get('zero torsion R=50', F(1))
    chk('bit', bf <= F(21, 100000), 'every field identity of B2 at these n: combined false-pass probability at most %s <= 2.1e-4 (the largest is N at n = 4: (6/101)^3)' % up(bf))
    chk('bit', b5 <= F(6, 10 ** 6) and b50 < F(7, 1000), 'zero torsion: at most %s with R = 500 and %s with R = 50 (degree 5n - 2 after det(e(0))^4, rejection r = n)' % (up(b5), up(b50)))
    # the bounds the pages quote (conventionsCopy: at most 2.1e-4 for the identities and below 5.9e-6 at zero torsion; the README: 6.4e-3 at R = 50), pinned exactly
    chk('bit', bf == F(6, 101) ** 3 and b5 == F(18, 997) ** 3 and b50 == F(18, 97) ** 3, 'the bounds the pages quote, exactly: identities (6/101)^3 < %s (quoted: at most 2.1e-4), zero torsion (18/997)^3 < %s with R = 500 (quoted: below 5.9e-6) '
        'and (18/97)^3 < %s with R = 50 (quoted 6.4e-3); the values are rounded up' % (up(bf), up(b5), up(b50)))

def main():
    ns = [int(a) for a in sys.argv[1:] if a.isdigit()] or [3, 4]
    B2.CTL.clear(); BOUND.clear()
    part_sampler(ns)
    for n in ns:
        part_lorentz(n); b2_controls('Lorentz'); part_sym(n)
        part_diffeo(n); b2_controls('diffeomorphisms')
        with strong_draws(): B2.std_part(n, F(1, 3))
    if 3 in ns: part_diffeo(3, quad=True); b2_controls('diffeomorphisms, x-degree 2')
    part_lines(ns)
    if 3 in ns: part_jets(3); part_calib(50)
    part_table()
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('B2-strong')

if __name__ == '__main__': main()
