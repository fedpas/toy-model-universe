#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H2.  Simplicity as pair classes: for a tetrad the 6x6 table e^I ^ e^J (I, J plane labels) vanishes on the 18 diagonal and edge cells and sits on the 3 antipodal cells with the
 signs of the complement pairing; the 20 constraints have Jacobian rank 20 at a tetrad; the cell classes against the duality split of H1 (intersection table).
      python3 h2_simplicity.py
 [bit]  the engine's wedge (the null bit rule) on random polynomial coframes, exact polynomials (every point at once); the Jacobian by exact fractions at rational points;
        the intersection table by exact linear algebra on the 21 cells with H1's duality table J.
 [std]  the same 21 numbers from the determinant formula c_IJ = eps(I, J) det(e) (textbook: e^a e^b e^c e^d = eps_abcd det(e) dx^0123) and Levi-Civita sums in numpy.
 Controls: six random 2-forms (all 21 cells non-zero); a tetrad with one 2-form replaced (exactly the six touching cells fail); a degenerate configuration has lower Jacobian rank.
 The Plebanski theorem (the constraints force +-e ^ e or +-*(e ^ e)) is quoted, not checked."""
import time, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from g2_weyl import *

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
TOP = 0b1111
SIGN_A = {(PIDX[(0, 1)], PIDX[(2, 3)]): 1, (PIDX[(0, 2)], PIDX[(1, 3)]): -1, (PIDX[(0, 3)], PIDX[(1, 2)]): 1}      # eps(a, b, c, d) of the complement pairing

def tetrad_2forms(Fm, e): return [Fm.wedge(e[a], e[b]) for (a, b) in PAIRS4]
def wedge_table(Fm, B):
    """c_IJ (I <= J): the polynomial coefficient of dx^0123 in B^I ^ B^J"""
    return {(I, J): Fm.wedge(B[I], B[J]).get(TOP, {}) for (I, J) in SYM21}
def vol_poly(Fm, e):
    w = e[0]
    for a in (1, 2, 3): w = Fm.wedge(w, e[a])
    return w.get(TOP, {})
def det_poly(e, n=4):
    """[std] det(e^a_mu) as a polynomial by the Leibniz formula with its own permutation signs"""
    M = frame_matrix(e, n); tot = {}
    for perm in itertools.permutations(range(n)):
        s = 1
        for i in range(n):
            for j in range(i + 1, n):
                if perm[i] > perm[j]: s = -s
        term = const(n, s)
        for a in range(n):
            p = M[a][perm[a]]
            if not p: term = {}; break
            term = gs.pmul(term, p)
        tot = padd(tot, term)
    return tot

def pattern_ok(table, vol):
    """(18 cells zero, antipodal cells = sign * vol, the list of cells that fail)"""
    bad = []
    for (I, J), p in table.items():
        want = scale(vol, SIGN_A[(I, J)]) if (I, J) in SIGN_A else {}
        if p != want: bad.append((I, J))
    return not bad, bad

def part1():
    head('PART 1  tetrad 2-forms e^I = e^a ^ e^b: the 21 wedge numbers as exact polynomials on random coframes [bit], against det(e) [std]')
    Gv, S, sq = lorentz_setup(); Fm = Gv.Fm; rng = random.Random(8); allok = True; allstd = True; nfr = 0
    for k in range(6):
        e = rand_frame(rng, 4, deg=(2 if k < 2 else 1), coef=2, density=.4)
        if k >= 4: e = translate_frame(e, random_rational_point(rng, 3, 3), 4)
        B = tetrad_2forms(Fm, e); tab = wedge_table(Fm, B); vol = vol_poly(Fm, e); ok, bad = pattern_ok(tab, vol); allok &= ok and bool(vol); nfr += 1
        allstd &= (vol == det_poly(e)) and all(tab[(I, J)] == scale(det_poly(e), SIGN_A.get((I, J), 0)) for (I, J) in SYM21)
        if k == 0:
            print('    frame 0: non-zero cells = %s; vol = e^0 e^1 e^2 e^3 has %d monomials' % (sorted((PAIRS4[I], PAIRS4[J], 'sign %+d' % SIGN_A[(I, J)]) for (I, J) in tab if tab[(I, J)]), len(vol)))
    chk('bit', allok, '%d random polynomial coframes (2 translated to random rational points): the 6 diagonal and 12 edge cells vanish identically; the 3 antipodal cells are (+, -, +) vol(e), the Levi-Civita signs of the complement pairing' % nfr)
    chk('bit==std', allstd, 'vol(e) equals det(e) by the Leibniz formula and every antipodal cell equals eps(I, J) det(e)')
    chk('bit', 21 - 18 == 3 and 3 - 2 == 1 and 36 - 16 == 20 == 18 + 2 == 21 - 1, 'counts: 21 cells - 18 zero = 3 antipodal, minus 2 equalities = 1 (the volume); 36 components - 16 (a tetrad) = 20 = 18 + 2 = 21 - 1')
    # controls
    rng = random.Random(9); nz = True; touched_ok = True
    for k in range(3):
        Bq = [{(1 << m) | (1 << v): {(0, 0, 0, 0): F(rng.choice([x for x in range(-20, 21) if x]), rng.randint(1, 5))} for m in range(4) for v in range(m + 1, 4)} for _ in range(6)]
        tab = wedge_table(Fm, Bq); nz &= all(p for p in tab.values())
        e = rand_frame(rng, 4, deg=1, coef=3, density=.6); B = tetrad_2forms(Fm, e); B[0] = Bq[0]; tab = wedge_table(Fm, B); vol = vol_poly(Fm, e); ok, bad = pattern_ok(tab, vol)
        touched_ok &= (set(bad) == {(I, J) for (I, J) in SYM21 if 0 in (I, J)})
    chk('ctl', nz, 'six random constant 2-forms (rational coefficients): all 21 wedge numbers are non-zero (3 trials)')
    chk('ctl', touched_ok, 'a tetrad with e^{01} replaced by a random 2-form: exactly the 6 cells touching the label 01 (diagonal, 4 edges, 1 antipodal) violate the pattern, the other 15 hold')
    tick('part 1')

def jacobian(Fm, B0):
    """rows: the 21 functions c_IJ (I <= J) of six constant 2-forms; columns: the 36 components B^K_{mu nu} (mu < nu). Exact, at the point B0 (constants)."""
    comps = [(K, (1 << m) | (1 << v)) for K in range(6) for m in range(4) for v in range(m + 1, 4)]; one = {(0, 0, 0, 0): F(1)}
    rows = []
    for (I, J) in SYM21:
        row = []
        for (K, mask) in comps:
            d = F(0); U = {mask: one}
            if K == I: d += Fm.wedge(U, B0[J]).get(TOP, {}).get((0, 0, 0, 0), F(0))
            if K == J: d += Fm.wedge(B0[I], U).get(TOP, {}).get((0, 0, 0, 0), F(0))
            row.append(d)
        rows.append(row)
    return rows
def part2():
    head('PART 2  the Jacobian of the 20 constraints on the 36 components of six 2-forms at a tetrad point [bit, exact]')
    Gv, S, sq = lorentz_setup(); Fm = Gv.Fm; rng = random.Random(10); r20 = set(); r21 = set(); npts = 0
    iA = [SIDX[c] for c in ((PIDX[(0, 1)], PIDX[(2, 3)]), (PIDX[(0, 2)], PIDX[(1, 3)]), (PIDX[(0, 3)], PIDX[(1, 2)]))]
    for k in range(5):
        e = rand_frame(rng, 4, deg=2, coef=3, density=.6); p = random_rational_point(rng, 3, 3) if k >= 2 else [F(0)] * 4
        e = translate_frame(e, p, 4) if k >= 2 else e
        B0 = [{m: {(0, 0, 0, 0): at0(q, 4)} for m, q in Fm.wedge(e[a], e[b]).items() if at0(q, 4) != 0} for (a, b) in PAIRS4]
        Jm = jacobian(Fm, B0); r21.add(rank_exact(Jm))
        rows20 = [Jm[i] for i in range(21) if i not in iA] + [[x + y for x, y in zip(Jm[iA[0]], Jm[iA[1]])], [x - y for x, y in zip(Jm[iA[0]], Jm[iA[2]])]]
        r20.add(rank_exact(rows20)); npts += 1
    chk('bit', r20 == {20} and r21 == {21}, '%d random rational tetrads (3 at random rational points): the 20 constraint functions (18 vanishings + c_01,23 + c_02,13 and c_01,23 - c_03,12) have Jacobian rank 20; all 21 cell functions have rank 21' % npts)
    print('    so near a tetrad the constraint set is a smooth manifold of dimension 36 - 20 = 16 = the number of tetrad components; that EVERY non-degenerate solution is +-e^e or +-*(e^e) is the Plebanski theorem: quoted, not checked', flush=True)
    one = {(0, 0, 0, 0): F(1)}; Bdeg = [{0b0011: one, 0b1100: one} for _ in range(6)]
    Jd = jacobian(Fm, Bdeg); rows20 = [Jd[i] for i in range(21) if i not in iA] + [[x + y for x, y in zip(Jd[iA[0]], Jd[iA[1]])], [x - y for x, y in zip(Jd[iA[0]], Jd[iA[2]])]]
    chk('ctl', rank_exact(rows20) < 20, 'a degenerate configuration (six copies of one 2-form): Jacobian rank %d < 20 (ok: the count is not automatic)' % rank_exact(rows20))
    tick('part 2')

def part3():
    head('PART 3  dictionary: cell classes D (6), E (12), A (3) against the duality pieces of H1 (exact linear algebra on the 21 cells), with and without the first Bianchi condition')
    for sq, label in ((LORENTZ(4), 'Lorentz (+,-,-,-)'), ([1, 1, 1, 1], 'Euclid (+,+,+,+)')):
        J = duality_J(sq)[0]; M = J21_matrix(J); ev = mat_sub_scalar(M, 1); od = mat_sub_scalar(M, -1); ric = ricci_rows(sq); eps = [eps_row()]
        g = metric_cell_vector(sq); ep = eps_row()
        def span_rows(v):                                   # constraints cutting out the line <v>: all 21-vectors u with u = t v  <=>  u orthogonal-complement rows
            # rows: for a basis of the annihilator of v (20 rows); use elimination: pick a pivot i0 with v[i0] != 0, rows u_i - (v_i / v_i0) u_i0
            i0 = next(i for i in range(21) if v[i] != 0); rows = []
            for i in range(21):
                if i == i0: continue
                r = [F(0)] * 21; r[i] = F(1); r[i0] = -v[i] / v[i0]; rows.append(r)
            return rows
        pieces = {'even': ev, 'odd': od, 'W': ric + eps, 'g': span_rows(g), 'eps': span_rows(ep)}
        names = ['even', 'odd', 'W', 'g', 'eps']; tab = {}; tabB = {}
        for pn in names:
            for cls in 'DEA':
                tab[(pn, cls)] = dim_of(class_rows(cls), pieces[pn]); tabB[(pn, cls)] = dim_of(class_rows(cls), pieces[pn], eps)
        print('    %s: dim(class & piece)                    D   E   A | sum | dim(piece)      and with the Bianchi condition:  D   E   A | sum' % label)
        for pn in names:
            d = dim_of(pieces[pn]); dB = dim_of(pieces[pn], eps)
            print('      %-5s %26s %3d %3d %3d | %3d | %3d %41s %3d %3d %3d | %3d (piece & Bianchi = %d)' % (pn, '', tab[(pn, 'D')], tab[(pn, 'E')], tab[(pn, 'A')], sum(tab[(pn, c)] for c in 'DEA'), d, '', tabB[(pn, 'D')], tabB[(pn, 'E')], tabB[(pn, 'A')], sum(tabB[(pn, c)] for c in 'DEA'), dB), flush=True)
        compat = all(sum(tab[(pn, c)] for c in 'DEA') == dim_of(pieces[pn]) for pn in names) and all(sum(tabB[(pn, c)] for c in 'DEA') == dim_of(pieces[pn], eps) for pn in names)
        chk('bit', compat, '%s: every piece (J-even, J-odd, Weyl, scalar, epsilon) is the direct sum of its intersections with the three cell classes, with and without Bianchi: the two splits have a common refinement in one frame' % label)
        if sq == LORENTZ(4):
            want = {('even', 'D'): 3, ('even', 'E'): 6, ('even', 'A'): 0, ('odd', 'D'): 3, ('odd', 'E'): 6, ('odd', 'A'): 3, ('W', 'D'): 2, ('W', 'E'): 6, ('W', 'A'): 2, ('g', 'D'): 1, ('g', 'E'): 0, ('g', 'A'): 0, ('eps', 'D'): 0, ('eps', 'E'): 0, ('eps', 'A'): 1}
            chk('bit', tab == want, '  Lorentz table as predicted: Hermitian 9 = 3 + 6 + 0, complex symmetric 12 = 3 + 6 + 3 (the antipodal cells are all J-odd), Weyl 10 = 2 + 6 + 2, scalar in D, epsilon in A')
            chk('bit', tabB[('odd', 'A')] == 2 and tabB[('W', 'A')] == 2 and all(tabB[k] == tab[k] for k in tab if k[1] != 'A' or k[0] in ('even', 'g')), '  with Bianchi only the antipodal class changes: A = 2 (both Weyl), the epsilon cell is the one removed')
            dD = dim_of(class_rows('D'), eps); dE = dim_of(class_rows('E'), eps); dA = dim_of(class_rows('A'), eps)
            chk('bit', (dD, dE, dA) == (6, 12, 2), '  the common refinement: D (6) = Weyl 2 + Ricci 3 + scalar 1, E (12) = Weyl 6 + Ricci 6, A (3) = Weyl 2 + epsilon 1 (removed by Bianchi: 6 + 12 + 2 = 20)')
        else:
            chk('bit', tab[('even', 'A')] == 3 and tab[('odd', 'A')] == 0, '  Euclid: the antipodal cells are all J-EVEN (J^2 = +1): the parity of the antipodal class follows the sign of I^2')
    tick('part 3')

if __name__ == '__main__':
    part1(); part2(); part3(); finish('H2')
