#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F4-KN.  Komar integrals and Smarr from the integral side on more Kerr-Newman frames, extremal Kerr and extremal Kerr-Newman included; F2's first law and Smarr there.   python3 f4_komar_kn.py

 Statement  xi = d_t, psi = x d_y - y d_x, chi = xi + Omega_H psi; M_K(R) = (1/8 pi) Int *d xi^b and J_K(R) = -(1/16 pi) Int *d psi^b over t = const, r = R (f4_komar's convention:
            eps_0123 = +1, the sphere oriented by (theta, phi), Komar's factor -1/2 recalled).  On every horizon (*d chi^b)(d_th, d_ph) = 2 kH Abar sin th, so
            M_K(r_h) = kH Abar + 2 Omega_H J_K(r_h) (extremal: kH = 0 and M_K(r_h) = 2 Omega_H J_K(r_h)), and with Smarr M - M_K(r_h) - 2 Omega_H (M a - J_K(r_h)) = (kappa/2) Phi_H Q.
            Extremal Kerr (M = a): Omega_H = 1/(2M), M_K = M, J_K = M a, so M = 2 Omega_H M a exactly.  On Kerr-Newman J_K(r_h) < M a, so the horizon form
            kH Abar + 2 Omega_H M a fails there (extremal members too); it holds on Kerr.
 Members    f3_kn_horizons.MEMBERS: (M, a, Q, kappa) = (15/2, 2, 8, 1), (3, 2, 2, 2), (3/2, 3/10, 1, 4), (19, 18, 6, 2), (841/280, 1, 4, 1); extremal (3, 1, 4, 1), (5, 3, 4, 2),
            (9/4, 7/4, 1, 4); extremal Kerr (1, 1, 0) and Kerr (841/840, 1, 0); f4_komar's (5, 1, 4, 1) as the reproduced row.  Frames f2_first_law.kn_frame_jet (s = kappa Q^2/4),
            exact 2-jets at four rational angles on each sphere: the horizons and one sphere outside (R = 20, or 2 r+ when r+ >= 10).
 [bit]      the integrands from the engine's d and the bit-rule star (f4_komar.komar_point); kH, Omega_H, Abar, Phi_H from F2's horizon_numbers; d*d v^b = -2 v^a E_a (the
            engine's Einstein form) = 2 kappa v^a T_a (T(a) = -1/2 F a F) at one point per member.  F2's first law dM = (1/2) kH dAbar + Omega_H dJ + (kappa/2) Phi_H dQ and
            Smarr M = kH Abar + 2 Omega_H M a + (kappa/2) Phi_H Q with F2's constants (not refitted) and the closed-form differentials of f2_first_law.family_closed.
 [std]      f4_komar's closed forms I_xi_exact, I_psi_exact (exact), MK_closed, JK_closed; komar_float (closed-form Kerr-Schild metric, complex-step derivatives, Gauss-Legendre
            at the two orders of f4_komar.orders) and bl_quad (96 nodes); the plain-polynomial route f4_komar.std_point (d*d v^b, the integrand, d_mu (d v^b)^{mu nu} = -2 R^nu_mu v^mu).
 Extremal   F2's member list has extremal Reissner-Nordstrom only: the first law runs here on extremal Kerr and Kerr-Newman along directions tangent to the extremal set
            (M^2 = a^2 + 2s), where kH dAbar = 0.  Along directions that leave the set the area term has a finite limit (ours, derived from the closed forms):
            (1/2) kH dAbar -> M (M dM - a da - (kappa Q/2) dQ)/(M^2 + a^2), and with it the first law holds at the extremal members: the first law at kH = 0 is that limit.
 [ctl]      the ghost-coupled twin (s -> -s); the Killing field d_t + (1/10) d_phi; the normalisations -1/(8 pi) and +1/(8 pi) for J; a shifted sphere; the horizon form
            kH Abar + 2 Omega_H M a on Kerr-Newman; Smarr from the integral side with gamma = kappa; 4 quadrature nodes; the horizon identity off the horizon; 2 kH in Smarr;
            Smarr without the Omega_H term at the extremal horizons; the area term set to 0 along directions that leave the extremal set.
 Scope      integrands exact at rational points, integrals in floats (the two-order error is printed); n = 4; no area theorem, no temperature, no Kerr-de Sitter.
 Exports    NEW, EXT_DIRS, D2, D3, ANGS, r_out(m), kn_sphere(M, a, s, R, angs=ANGS), sphere(Gv, m, R, Om=None, s=None), komar_pair(m, R), area_limit(M, a, Q, kappa, dirn)"""
import os, sys, time, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib and the step modules), also under python3 -I
from b1lib import *
import numpy as np
import g2_kerr as K
import f2_first_law as F2
import f4_komar as F4
from f3_kn_horizons import MEMBERS, member

NV = 4; SQ = LORENTZ(4); PI = math.pi; T0 = time.time()
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
def one(S_): return next(iter(S_)) if len(S_) == 1 else None
def rel(x, y): return abs(x - y) / max(1.0, abs(y))
def fz(x): return 0.0 if abs(x) < 5e-11 else x                            # printing only: a float residual below the stated tolerance prints as 0
ANGS = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(3, 5), F(4, 5)), (F(-5, 13), F(12, 13))), ((F(-5, 13), F(12, 13)), (F(3, 5), F(-4, 5))), ((F(7, 25), F(24, 25)), (F(1), F(0)))]   # f4_komar's angles
NEW = ['K3', 'K4', 'K5', 'K6', 'KNe', 'X1', 'X2', 'X3', 'XK', 'KE']
EXT_DIRS = {'X1': [(1, 3, 0), (2, 0, 3)], 'X2': [(3, 5, 0), (4, 0, 5)], 'X3': [(7, 9, 0), (8, 0, 9)], 'XK': [(1, 1, 0)]}     # tangent to M^2 = a^2 + kappa Q^2/2
LEAVE = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
D2 = [(1, 0, 0), (0, 1, 0), (F(2, 3), F(-5, 7), 0)]; D3 = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (F(1, 2), F(-2, 3), F(3, 7))]     # the directions (dM, da, dQ) of f2_first_law

def r_out(m): rp = m['hor'][0][1]; return F(20) if rp < 10 else 2 * rp
def kn_sphere(M, a, s, R, angs=ANGS):
    """(P, e, E, data) at the rational points of r = R (F2's kn_frame_jet, exact 2-jets)"""
    out = []
    for P in K.rational_kerr_points(a, [R], angs):
        e, E, _, data = F2.kn_frame_jet(P['p'], M, a, s, r0=R); out.append((P, e, E, data))
    return out
def sphere(Gv, m, R, Om=None, s=None):
    """[bit] the integrands (*d v^b)(d_th, d_ph) of xi, psi (and chi = xi + Om psi) at the points of r = R; s overrides the member's s (the twin control)"""
    recs = []
    for (P, e, E, data) in kn_sphere(m['M'], m['a'], m['s'] if s is None else s, R):
        p = P['p']; r = dict(P=P, e=e, E=E, data=data, xi=F4.komar_point(Gv, e, E, K.d_t(p), P, m['a'])['I'], psi=F4.komar_point(Gv, e, E, K.d_phi(p), P, m['a'])['I'])
        if Om is not None: r['chi'] = F4.komar_point(Gv, e, E, K.killing_chi(p, Om), P, m['a'])['I']
        recs.append(r)
    return recs
def komar_pair(m, R):
    """[std] floats: M_K, J_K at the two orders of f4_komar.orders (largest difference err), F4's closed forms, the 96-node rule of the closed-form integrand"""
    M, a, s = m['M'], m['a'], m['s']; n1, n2 = F4.orders(R, a)
    Mk = [F4.komar_float(M, a, s, R, 'xi', nu=n) / (8 * PI) for n in (n1, n2)]; Jk = [-F4.komar_float(M, a, s, R, 'psi', nu=n) / (16 * PI) for n in (n1, n2)]
    return dict(MK=Mk[1], JK=Jk[1], err=max(abs(Mk[0] - Mk[1]), abs(Jk[0] - Jk[1])), MKc=F4.MK_closed(M, a, s, R), JKc=F4.JK_closed(M, a, s, R), bq=F4.bl_quad(M, a, s, R, 96), n=(n1, n2))
def area_limit(M, a, Q, kap, dirn):
    """ours: the limit at the extremal set of (1/2) kH dAbar along dirn = (dM, da, dQ): M (M dM - a da - (kappa Q/2) dQ)/(M^2 + a^2)"""
    M, a, Q = F(M), F(a), F(Q); dM, da, dQ = (F(x) for x in dirn); return M * (M * dM - a * da - F(kap) * Q * dQ / 2) / (M * M + a * a)

CT = {}
def ctl(name, wrong): k = CT.setdefault(name, [0, 0]); k[1] += 1; k[0] += int(bool(wrong))
C_TWIN = 'the ghost-coupled twin (s -> -s) on K4, r = 4: the integrand of *d xi^b differs from the member\'s, and *d chi^b (the member\'s Omega_H) is not 2 kH Abar sin th'
C_WKF = 'the Killing field d_t + (1/10) d_phi on K4, R = 20: the engine integrand differs from I_xi at the 4 points, and its integral is M_K - J_K/5, not M_K'
C_NORM = 'the normalisations -1/(8 pi) for M and +1/(8 pi) for J on XK: they give -M and -2 M a'
C_SHIFT = 'a shifted sphere: K4 M_K(20) differs from M_K(4) (the charge term), while XK M_K(20) = M_K(1)'
C_HFORM = 'the horizon form kH Abar + 2 Omega_H M a (J = M a) in place of M_K(r_h) on the new Kerr-Newman horizons, extremal included'
C_GAM = 'Smarr from the integral side with gamma = kappa in place of kappa/2 on the new charged horizons'
C_LOW = '4 nodes in cos theta on XK, r = 1: M_K is not M'
C_OFFH = 'the pointwise horizon identity off the horizon (K4, R = 20, chi with Omega_H of r+ = 4)'
C_2K = '2 kH in place of kH in Smarr (new horizons with kH != 0)'
C_NOOM = 'Smarr without the 2 Omega_H J term on the extremal horizons'
C_AREA0 = 'the area term set to 0 at the extremal members along directions that leave the extremal set'
CTL_NAMES = [C_TWIN, C_WKF, C_NORM, C_SHIFT, C_HFORM, C_GAM, C_LOW, C_OFFH, C_2K, C_NOOM, C_AREA0]

# ------------------------------------------------------------------------------------------------ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # built per run: an engine fault put into memory is seen
    CT.clear(); [CT.setdefault(n, [0, 0]) for n in CTL_NAMES]
    MS = {mid: member(mid) for mid in ['K1'] + NEW}; REC = {}; QK = {}; HN = {}
    head('F4-KN  Komar integrals from the engine\'s d and bit-rule star on more Kerr-Newman frames; Smarr from the integral side; F2\'s first law and Smarr on the same members')

    head('0. f4_komar\'s member (5, 1, 4, 1) reproduced on its outer horizon r = 9')
    m = MS['K1']; recs = sphere(Gv, m, F(9)); q = komar_pair(m, F(9))
    ok = all(r['xi'] == F4.I_xi_exact(m['M'], m['a'], m['s'], 9, r['P']['cth'], r['P']['sth']) and r['psi'] == F4.I_psi_exact(m['M'], m['a'], m['s'], 9, r['P']['cth'], r['P']['sth']) for r in recs)
    chk('bit==std', ok and abs(q['MK'] - 4.1074621167) < 1e-9 and abs(q['JK'] - 4.4059467858) < 1e-9 and q['err'] < 1e-9, 'K1 (5, 1, 4, 1), r = 9: integrands = I_xi, I_psi exactly at %d points; [floats] (M_K, J_K) = (%.10f, %.10f): f4_komar\'s numbers (4.1074621167, 4.4059467858)' % (len(recs), q['MK'], q['JK']))
    tick('part 0')

    head('1. integrands exact at four rational points of every sphere, integrals in floats (two orders), closed forms')
    for mid in NEW:
        m = MS[mid]; radii = [rh for (br, rh, c) in m['hor']] + [r_out(m)]
        for (br, rh, c) in m['hor']:
            hn = F2.horizon_numbers(Gv, S, m['M'], m['a'], m['s'], rh, ANGS, Q=m['Q'], std=False)
            HN[(mid, rh)] = dict(kH=one(hn['kH']), Om=one(hn['Om']), Ab=one(hn['area']), Phi=(one(hn['phi']) if m['Q'] else F(0)), ok=hn['null'] == {0} and hn['disc'] == {0} and hn['exact'], br=br, cf=c)
        okx = okp = okf = True; npt = 0; worst = 0.0
        for R in radii:
            recs = sphere(Gv, m, R, HN.get((mid, R), {}).get('Om')); REC[(mid, R)] = recs; npt += len(recs)
            okx &= all(r['xi'] == F4.I_xi_exact(m['M'], m['a'], m['s'], R, r['P']['cth'], r['P']['sth']) for r in recs)
            okp &= all(r['psi'] == F4.I_psi_exact(m['M'], m['a'], m['s'], R, r['P']['cth'], r['P']['sth']) for r in recs)
            ct, st, cp, sp = [np.array([float(r['P'][k]) for r in recs]) for k in ('cth', 'sth', 'cph', 'sph')]
            for kind in ('xi', 'psi'):
                for r, x in zip(recs, F4.integrand_float(m['M'], m['a'], m['s'], R, ct, st, cp, sp, kind)): d = rel(x, float(r[kind])); worst = max(worst, d); okf &= d < 1e-10
            QK[(mid, R)] = komar_pair(m, R)
        chk('bit==std', okx and okp and okf, '%s (%s, %s, %s, %s): the engine integrands of *d xi^b and *d psi^b = f4_komar\'s closed forms I_xi, I_psi EXACTLY at %d points on r = %s; = the float route (largest relative difference %.1e)' % (
            mid, m['M'], m['a'], m['Q'], m['kap'], npt, ', '.join(map(str, radii)), worst))
        rows = [(R, QK[(mid, R)]) for R in radii]
        ok = all(abs(q['MK'] - q['MKc']) < 1e-10 and abs(q['JK'] - q['JKc']) < 1e-10 and q['err'] < 1e-9 and max(abs(q['bq'][0] - q['MK']), abs(q['bq'][1] - q['JK'])) < 1e-9 for R, q in rows)
        chk('std', ok, '%s: [floats] (M_K, J_K) = %s = MK_closed, JK_closed (orders %s; largest |difference of two orders| %.1e; the 96-node rule agrees)' % (
            mid, '; '.join('(%.10f, %.10f) at R = %s' % (q['MK'], q['JK'], R) for R, q in rows), ', '.join('%d/%d' % q['n'] for R, q in rows), max(q['err'] for R, q in rows)))
    tick('part 1')

    head('2. horizons: (*d chi^b)(d_th, d_ph) = 2 kH Abar sin th pointwise; M_K(r_h) = kH Abar + 2 Omega_H J_K(r_h); Smarr from the integral side')
    rows = []
    for (mid, rh), h in HN.items():
        m = MS[mid]; recs = REC[(mid, rh)]; good = h['ok'] and None not in (h['kH'], h['Om'], h['Ab'], h['Phi'])
        ok = good and all(r['chi'] == 2 * h['kH'] * h['Ab'] * r['P']['sth'] and r['chi'] == r['xi'] + h['Om'] * r['psi'] for r in recs)
        chk('bit', ok, '%s, %s r = %s: (*d chi^b)(d_th, d_ph) = 2 kH Abar sin th exactly at %d points, chi = d_t + Omega_H d_phi with F2\'s kH = %s, Omega_H = %s, Abar = %s: (1/8 pi) Int *d chi^b = kH Abar = %s' % (
            mid, 'extremal' if m['ext'] else ('outer' if h['br'] == 1 else 'inner'), rh, len(recs), h['kH'], h['Om'], h['Ab'], h['kH'] * h['Ab'] if good else None))
        if not good: continue
        q = QK[(mid, rh)]; Om = float(h['Om']); Ma = float(m['M'] * m['a'])
        rows.append(dict(mid=mid, rh=rh, ext=m['ext'], Q=m['Q'], lhs=q['MK'] - 2 * Om * q['JK'], kA=h['kH'] * h['Ab'], sm=float(m['M']) - q['MK'] - 2 * Om * (Ma - q['JK']),
                         rhs=float(F(m['kap'], 2) * h['Phi'] * m['Q']), hform=q['MK'] - float(h['kH'] * h['Ab'] + 2 * h['Om'] * m['M'] * m['a']), dJ=2 * Om * (Ma - q['JK'])))
    chk('bit==std', len(rows) == 16 and all(abs(r['lhs'] - float(r['kA'])) < 1e-10 for r in rows), '[floats] M_K(r_h) - 2 Omega_H J_K(r_h) = the engine\'s kH Abar on all %d new horizons: %s' % (
        len(rows), '; '.join('%s r = %s: %.10f = %s' % (r['mid'], r['rh'], fz(r['lhs']), r['kA']) for r in rows)))
    ext = [r for r in rows if r['ext']]
    chk('bit==std', len(ext) == 4 and all(r['kA'] == 0 and abs(r['lhs']) < 1e-10 for r in ext), 'extremal horizons (kH = 0): M_K(r_h) = 2 Omega_H J_K(r_h): %s' % '; '.join('%s: M_K = %.10f, 2 Omega_H J_K = %.10f' % (
        r['mid'], QK[(r['mid'], r['rh'])]['MK'], QK[(r['mid'], r['rh'])]['MK'] - r['lhs']) for r in ext))
    chk('bit==std', len(rows) == 16 and all(abs(r['sm'] - r['rhs']) < 1e-10 for r in rows), 'Smarr from the integral side: M - M_K(r_h) - 2 Omega_H (M a - J_K(r_h)) = (kappa/2) Phi_H Q (F2\'s Phi_H) on all %d new horizons: %s' % (
        len(rows), '; '.join('%s r = %s: %.10f = %.10f' % (r['mid'], r['rh'], fz(r['sm']), fz(r['rhs'])) for r in rows)))
    m = MS['XK']; h = HN[('XK', F(1))]; qx = [QK[('XK', R)] for R in (F(1), F(20))]
    chk('bit', h['Om'] == 1 / (2 * m['M']) and h['kH'] == 0 and (F4.MK_closed(m['M'], m['a'], 0, 1), F4.JK_closed(m['M'], m['a'], 0, 1)) == (1.0, 1.0) and all(abs(q['MK'] - 1) < 1e-10 and abs(q['JK'] - 1) < 1e-10 for q in qx)
        and m['M'] == h['kH'] * h['Ab'] + 2 * h['Om'] * m['M'] * m['a'], 'extremal Kerr M = a = 1: the engine\'s Omega_H = %s = 1/(2M), kH = %s; M_K = M and J_K = M a (q = 0: the closed forms, and [floats] (M_K, J_K) = (%.12f, %.12f) at r = 1 and (%.12f, %.12f) at r = 20); '
        'so M_K(r_h) = 2 Omega_H J_K(r_h) reads M = 2 Omega_H M a = %s exactly' % (h['Om'], h['kH'], qx[0]['MK'], qx[0]['JK'], qx[1]['MK'], qx[1]['JK'], 2 * h['Om'] * m['M'] * m['a']))
    kn = [r for r in rows if r['Q'] != 0]; kerr = [r for r in rows if r['Q'] == 0]
    for r in kn: ctl(C_HFORM, abs(r['hform']) > 1e-4 and abs(r['hform'] + r['dJ']) < 1e-10 and r['dJ'] > 1e-4); ctl(C_GAM, abs(r['sm'] - 2 * r['rhs']) > 1e-4)
    chk('bit==std', len(kn) == 13 and len(kerr) == 3 and all(abs(r['hform']) < 1e-10 for r in kerr) and all(abs(r['hform'] + r['dJ']) < 1e-10 for r in kn), 'the horizon form M_K(r_h) = kH Abar + 2 Omega_H M a holds on the Kerr horizons (XK, KE) and differs on '
        'every new Kerr-Newman horizon by -2 Omega_H (M a - J_K(r_h)): %s' % ', '.join('%.6f (%s r = %s)' % (r['hform'], r['mid'], r['rh']) for r in kn))
    tick('part 2')

    head('3. F2\'s Smarr and first law on the new members (engine kH, Omega_H, Abar, Phi_H; F2\'s constants, not refitted); the extremal members and the limit kH -> 0')
    oks = True; smr = []
    for (mid, rh), h in HN.items():
        m = MS[mid]; M, a, Q, kap = m['M'], m['a'], m['Q'], m['kap']; good = h['ok'] and None not in (h['kH'], h['Om'], h['Ab'], h['Phi'])
        c = h['cf']; oks &= good and (h['kH'], h['Om'], h['Ab'], h['Phi']) == (c['kH'].v, c['Om'].v, c['Abar'].v, c['Phi'].v) and M == h['kH'] * h['Ab'] + 2 * h['Om'] * M * a + F(kap, 2) * h['Phi'] * Q
        smr.append('%s r = %s' % (mid, rh))
        if good and h['kH'] != 0: ctl(C_2K, M != 2 * h['kH'] * h['Ab'] + 2 * h['Om'] * M * a + F(kap, 2) * h['Phi'] * Q)
        if good and m['ext']: ctl(C_NOOM, M != h['kH'] * h['Ab'] + F(kap, 2) * h['Phi'] * Q)
    chk('bit', oks and len(smr) == 16, 'Smarr M = kH Abar + 2 Omega_H M a + (kappa/2) Phi_H Q exactly on %d new horizons (%s), with the engine\'s kH, Omega_H, Abar and Phi_H (= the recalled closed forms of family_closed; '
        'Phi_H the gauge value chi.A with i_chi F = -d(chi.A) at the points)' % (len(smr), ', '.join(smr)))
    fl = {}; okf = True
    for (mid, rh), h in HN.items():
        m = MS[mid]; M, a, Q, kap = m['M'], m['a'], m['Q'], m['kap']; dirs = EXT_DIRS.get(mid) or (D2 if Q == 0 else D3)
        for d in dirs:
            try:
                c = F2.family_closed(kap, M, a, Q, d, h['br']); res = c['M'].d - F(1, 2) * h['kH'] * c['Abar'].d - h['Om'] * c['J'].d - F(kap, 2) * h['Phi'] * c['Q'].d
                good = res == 0 and (not m['ext'] or (c['kH'].v == 0 and c['Abar'].d != 0))
            except (ValueError, TypeError): good = False
            okf &= good; fl[m['ext']] = fl.get(m['ext'], 0) + 1
    chk('bit', okf, 'first law dM = (1/2) kH dAbar + Omega_H dJ + (kappa/2) Phi_H dQ exactly on %d rows of the non-extremal new members (f2_first_law\'s directions D3, D2; outer and inner) and on %d rows of the extremal ones '
        'along directions tangent to M^2 = a^2 + 2s (%s), where kH = 0 while dAbar != 0: dM = Omega_H dJ + (kappa/2) Phi_H dQ' % (fl.get(False, 0), fl.get(True, 0), '; '.join('%s %s' % (k, v) for k, v in EXT_DIRS.items())))
    okl = True; vals = []
    for mid in ('KNe', 'KE'):
        m = MS[mid]; (br, rh, c) = m['hor'][0]; h = HN[(mid, rh)]; cd = F2.family_closed(m['kap'], m['M'], m['a'], m['Q'], (1, 0, 0), 1)
        term = F(1, 2) * h['kH'] * cd['Abar'].d if h['kH'] is not None else None; okl &= term == rh * (m['d'] + m['M']) / (rh * rh + m['a'] ** 2); vals.append('%s: %s' % (mid, term))
    seq = []
    for (a, s, kap, Q, Mx) in ((F(1), F(0), 1, F(0), 'XK'), (F(1), F(4), 1, F(4), 'X1')):
        cx = (a * a + 2 * s) ** 1; c0 = K.rat_sqrt(cx); lim = area_limit(c0, a, Q, kap, (1, 0, 0)); vv = []
        for u in (F(21, 20), F(201, 200), F(2001, 2000)):
            Mu = c0 * (u + 1 / u) / 2; cu = F2.family_closed(kap, Mu, a, Q, (1, 0, 0), 1); vv.append(F(1, 2) * cu['kH'].v * cu['Abar'].d)
        okl &= all(abs(v - lim) > abs(w - lim) for v, w in zip(vv, vv[1:])) and abs(vv[-1] - lim) < F(1, 1000); seq.append('%s: %s -> %s' % (Mx, ', '.join('%.6f' % float(v) for v in vv), lim))
    chk('std', okl, 'the area term near extremality (ours, from the closed forms): along dM, (1/2) kH dAbar = r+ (d + M)/Abar exactly with the engine\'s kH (%s), and on members approaching XK and X1 (r+- = c u, c/u, u -> 1) '
        'it tends to M^2/(M^2 + a^2), not to 0 (%s)' % ('; '.join(vals), '; '.join(seq)))
    okx = True; nx = 0
    for mid in ('X1', 'X2', 'X3', 'XK'):
        m = MS[mid]; (br, rh, c) = m['hor'][0]; h = HN[(mid, rh)]; M, a, Q, kap = m['M'], m['a'], m['Q'], m['kap']
        for d in (LEAVE if Q else LEAVE[:2]):
            dM, da, dQ = (F(x) for x in d); dJ = M * da + a * dM; nx += 1
            if None in (h['Om'], h['Phi']): okx = False; ctl(C_AREA0, False); continue
            okx &= dM - area_limit(M, a, Q, kap, d) - h['Om'] * dJ - F(kap, 2) * h['Phi'] * dQ == 0; ctl(C_AREA0, dM - h['Om'] * dJ - F(kap, 2) * h['Phi'] * dQ != 0)
    chk('bit', okx, 'at the extremal members, with the limit of the area term, the first law holds along the directions that leave the extremal set too (%d rows: dM, da, dQ; the engine\'s Omega_H and Phi_H): '
        'the first law at kH = 0 is the limit of the non-extremal one' % nx)
    tick('part 3')

    head('4. the local form: d*d v^b = -2 v^a E_a = 2 kappa v^a T_a at one outer-horizon point of each new member; the plain-polynomial route')
    okE = okS = True; nz = 0; nE = 0; nc = 0; okV = True
    for mid in NEW:
        m = MS[mid]; r0 = REC[(mid, m['hor'][0][1])][0]; e, E, P = r0['e'], r0['E'], r0['P']; p = P['p']
        comp = engine_E_from_R(Gv, e, engine_om_R(Gv, e, S, 4)[1], 4, 0); Ta = F2.maxwell_stress_comp(Gv, e, E, F2.kn_potential(m['Q'], r0['data']))[0] if m['Q'] else None
        rc = F4.std_ricci(e)
        for v_up in (K.d_t(p), K.d_phi(p)):
            kp = F4.komar_point(Gv, e, E, v_up, P, m['a'], dd=True); dd = kp['dd']; sd = F4.std_point(e, v_up, P, m['a'], rc); nE += 1; nc += bool(m['Q']); nz += bool(dd) and bool(m['Q'])
            okS &= sd['dd'] == dd and sd['det_ok'] and sd['I'] == kp['I'] and sd['div'] == sd['m2ric']
            if m['Q']: okE &= dd == F4.three_form(kp['va'], comp, -2) and dd == F4.three_form(kp['va'], Ta, 2 * F(m['kap'])) and bool(dd)
            else: okV &= not dd and not F4.three_form(kp['va'], comp, -2)
    chk('bit', okE and okV, 'd*d v^b = -2 v^a E_a (the engine\'s Einstein form) = 2 kappa v^a T_a for v = xi, psi on the 8 charged members (non-zero at %d of %d (point, field) pairs), and d*d v^b = 0 = -2 v^a E_a on XK and KE' % (nz, nc))
    chk('bit==std', okS, 'plain-polynomial route (f4_komar.std_point) at the same %d (point, field) pairs: d*d v^b and the integrand equal the engine\'s exactly, det g = -1, d_mu (d v^b)^{mu nu} = -2 R^nu_mu v^mu (Christoffel route of Ricci)' % nE)
    tick('part 4')

    head('5. controls (a wrong version must fail)')
    m = MS['K4']; s = m['s']; h = HN[('K4', F(4))]; tw = sphere(Gv, m, F(4), h['Om'], s=-s); hk = None not in (h['kH'], h['Ab'], h['Om'])      # a control a fault makes unreachable counts as not failing
    for r, r0 in zip(tw, REC[('K4', F(4))]): ctl(C_TWIN, hk and r['xi'] != r0['xi'] and r['chi'] != 2 * h['kH'] * h['Ab'] * r['P']['sth'])
    q4 = QK[('K4', F(20))]; wr = F4.komar_float(m['M'], m['a'], s, 20, 'chi', nu=48, Om=0.1) / (8 * PI)
    for r in REC[('K4', F(20))]:
        wi = F4.komar_point(Gv, r['e'], r['E'], K.killing_chi(r['P']['p'], F(1, 10)), r['P'], m['a'])['I']; ctl(C_WKF, wi != F4.I_xi_exact(m['M'], m['a'], s, 20, r['P']['cth'], r['P']['sth']))
        ctl(C_OFFH, hk and F4.komar_point(Gv, r['e'], r['E'], K.killing_chi(r['P']['p'], h['Om']), r['P'], m['a'])['I'] != 2 * h['kH'] * h['Ab'] * r['P']['sth'])
    print('    K4, R = 20: (1/8 pi) Int *d(xi + psi/10)^b = %.10f = M_K - J_K/5 = %.10f' % (wr, q4['MK'] - q4['JK'] / 5))
    ctl(C_WKF, abs(wr - (q4['MK'] - q4['JK'] / 5)) < 1e-9 and abs(wr - q4['MK']) > 1e-3)
    qx = QK[('XK', F(1))]; ctl(C_NORM, abs(-qx['MK'] - 1) > 1); ctl(C_NORM, abs(-2 * qx['JK'] - 1) > 1)
    ctl(C_SHIFT, abs(QK[('K4', F(20))]['MK'] - QK[('K4', F(4))]['MK']) > 1e-3 and abs(QK[('XK', F(20))]['MK'] - QK[('XK', F(1))]['MK']) < 1e-10)
    low = F4.komar_float(1, 1, 0, 1, 'xi', nu=4) / (8 * PI); ctl(C_LOW, abs(low - 1) > 1e-6)
    print('    XK, r = 1: 4 nodes give M_K = %.10f (error %.1e); %d nodes %.12f' % (low, abs(low - 1), qx['n'][1], qx['MK']))
    for name, (dif, seen) in CT.items(): chk('ctl', dif == seen and seen > 0, '%s: fails on %d of %d samples' % (name, dif, seen))
    tick('part 5')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F4-KN')

if __name__ == '__main__': main()
