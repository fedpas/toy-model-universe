#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F4-komar.  Komar mass and angular momentum from the engine's own forms on the Kerr-Schild frames.   python3 f4_komar.py

 Statement  xi = d_t and psi = x d_y - y d_x (the Killing fields of the family); v^b = g(v, .) is the 1-form of a vector v (frame: v^b = eta_aa v^a e^a, v^a = e^a(v)).
            M_K(R) = (1/8 pi) Int_S *d xi^b and J_K(R) = -(1/16 pi) Int_S *d psi^b over the sphere S: t = const, r = R.
            Vacuum (Schwarzschild, Kerr): M_K = M and J_K = M a on every sphere, inside the horizons too.  With a Maxwell field both depend on R.
 Convention the Hodge star of g2_hodge (bit rule *(e^I) = rev(e_I) e_0123; eps_0123 = +1 for (t, x, y, z)); S is oriented by (theta, phi) of
            x = sin th (R cos ph - a sin ph), y = sin th (R sin ph + a cos ph), z = R cos th.  The sign +1/(8 pi) is fixed by Schwarzschild (M = 1), the orientation by the
            Coulomb flux Int *F = -4 pi Q of A = (Q/rho) l (F2-M's convention); the ratio -1/2 of the two normalisations is Komar's (recalled), and J = M a then follows.
 Frames     F2's kn_frame_jet: e^a = dx^a - f l^a l, f = (M r - s) r^2/(r^4 + a^2 z^2), s = kappa Q^2/4 (geometric charge squared q = 2s), A = (Q r^3/(r^4 + a^2 z^2)) l;
            exact 2-jets at rational points of the spheres (g2_kerr.rational_kerr_points); advanced chart: t = const, r = r_h is a cross-section of the future horizon.
 [bit]      v^b from the frame (engine wedge), d v^b (engine d), *d v^b (g2_hodge.hodge_form, route 'bit'), its value on (d_theta, d_phi) at the point: the integrand, exact.
            d*d v^b at the point (a 3-form) against -2 v^a E_a (E_a the engine's Einstein form, A3 omega) and 2 kappa v^a T_a (T(a) = -1/2 F a F, F = dA with the engine's d).
            d xi^b = 2 nabla xi with nabla xi from the engine's omega and h table (f3_killing.wald_engine).  Horizons: kH, Omega_H, Abar = A/(4 pi), Phi_H from F2's
            horizon_numbers; pointwise (*d chi^b)(d_th, d_ph) = 2 kH Abar sin th with chi = xi + Omega_H psi.
 [std]      (a) floats, no engine: the closed-form Kerr-Schild metric, v_mu = g_{mu nu} v^nu, derivatives by complex step, g^-1 and det g by numpy,
                *X_{ab} = (1/2) sqrt|g| eps_{ab mu nu} X^{mu nu} pulled back to (theta, phi), Gauss-Legendre in cos theta times uniform nodes in phi, two orders.
            (b) Boyer-Lindquist (the metric is recalled; the rest is derived here): the integrand per d theta d phi
                I_xi = (R^2 + a^2) sin th (2 R m - 2 M Sig)/Sig^2,   I_psi = -a sin^3 th (2 R m/Sig - (R^2 + a^2) W),
                m = 2 M R - q, Sig = R^2 + a^2 cos^2 th, W = (2 M Sig - 2 R m)/Sig^2 (rational at rational angles: compared EXACTLY with [bit]), and its integrals
                M_K(R) = M - (q/2R) (1 + ((R^2 + a^2)/(a R)) arctan(a/R)),   J_K(R) = M a - (q/4a) ((a^2 - R^2)/R + ((R^2 + a^2)^2/(a R^2)) arctan(a/R))
                (a = 0: M - q/R and 0), also by a one-dimensional Gauss-Legendre rule.
            (c) plain polynomials at the points (no engine): g = e^T eta e, d v^b, *d v^b and d*d v^b; the Christoffel route of nabla xi (f3_killing.wald_std) and of the
                Ricci tensor (b1lib.std_riemann): d_mu(sqrt(-g) (d v^b)^{mu nu}) = -2 sqrt(-g) R^nu_mu v^mu.
 Horizon    M_K(r_h) - 2 Omega_H J_K(r_h) = kH Abar; with F2's Smarr M = kH Abar + 2 Omega_H J + (kappa/2) Phi_H Q this reads
            M - M_K(r_h) - 2 Omega_H (M a - J_K(r_h)) = (kappa/2) Phi_H Q (Reissner-Nordstrom: M - M_K(r_h) = (kappa/2) Phi_H Q = 2s/r_h, exact).
            On Kerr-Newman J_K(r_h) < M a (the field outside the horizon carries angular momentum): there M_K(r_h) = kH Abar + 2 Omega_H J_K(r_h), not kH Abar + 2 Omega_H M a.
 [ctl]      the ghost-coupled twin of H4 (f = M/rho + s/rho^2); a time-dependent mass M(1 + t/7) (F2's tfac); spheres at shifted R; the Killing field d_t + (1/10) d_phi;
            the normalisations -1/(8 pi) for M and +1/(8 pi) for J; the charge term s/R; Smarr from the integral side with gamma = kappa; the horizon form
            kH Abar + 2 Omega_H M a on Kerr-Newman; the horizon identity off the horizon; a wrong potential (r^2 numerator) in the Coulomb flux; a low quadrature order.
 Scope      values at rational points, integrals over the spheres r = R in floats (the quadrature error is stated); Schwarzschild M = 1, Kerr (5, 3),
            Reissner-Nordstrom (M, Q, kappa) = (3/2, 2, 1) and the extremal (1, 1, 2), Kerr-Newman (M, a, Q, kappa) = (5, 1, 4, 1) and (7/2, 2, 2, 1).  No area theorem, no temperature.
 Exports    tangents(P, a), pull(X0, Tth, Tph), flat_form(e, v_up, Fm), komar_point(Gv, e, E, v_up, P, a, dd=False), std_ricci(e), std_point(e, v_up, P, a, rc=None),
            integrand_float(M, a, s, R, ct, st, cp, sp, kind, Om=0.0, tfac=0.0, Q=1.0), komar_float(M, a, s, R, kind, nu=32, nph=8, **kw),
            three_form(va, comp, c), orders(R, a), MK_closed(M, a, s, R), JK_closed(M, a, s, R), bl_quad(M, a, s, R, n=64), I_xi_exact(M, a, s, R, ct, st),
            I_psi_exact(M, a, s, R, ct, st)."""
import os, sys, time, math, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib and the step modules), also under python3 -I
from b1lib import *
import numpy as np
import g2_kerr as K
import g2_hodge as H
import f2_first_law as F2
import f3_killing as F3

NV = 4; SQ = LORENTZ(4); FULL = 15
T0 = time.time()
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
def one(S_): return next(iter(S_)) if len(S_) == 1 else None
PI = math.pi

# ------------------------------------------------------------------------------------------------ [bit] the integrand at a rational point
def tangents(P, a):
    """d/d theta and d/d phi of x = sin th (r cos ph - a sin ph), y = sin th (r sin ph + a cos ph), z = r cos th at the point P (exact)"""
    r, a = F(P['r']), F(a); ct, st, cp, sp = P['cth'], P['sth'], P['cph'], P['sph']
    return ([F(0), ct * (r * cp - a * sp), ct * (r * sp + a * cp), -r * st], [F(0), st * (-r * sp - a * cp), st * (r * cp - a * sp), F(0)])
def pull(X0, Tth, Tph):
    """X(T_th, T_ph) for a 2-form X0 = {mask mu<nu: value} at the point"""
    tot = F(0)
    for m, v in X0.items():
        if v:
            mu, nu = [b for b in range(4) if m >> b & 1]; tot += v * (Tth[mu] * Tph[nu] - Tth[nu] * Tph[mu])
    return tot
def flat_form(e, v_up, Fm):
    """[bit] v^b = sum_a eta_aa v^a e^a (engine wedge of 0-forms with the frame 1-forms), v^a = e^a(v) as 2-jets; returns (v^b, v^a at the point)"""
    va = K.engine_vector_at0(e, v_up); out = {}
    with trunc(4, xdeg=2):
        for A_ in range(4):
            if va[A_]: out = Fm.add(out, Fm.wedge({0: scale(va[A_], SQ[A_])}, e[A_]))
    return out, [at0(q, NV) for q in va]
def komar_point(Gv, e, E, v_up, P, a, dd=False):
    """[bit] d v^b (1-jet), *d v^b (bit-rule star, 1-jet), the integrand (*d v^b)(T_th, T_ph) at the point, and with dd: d*d v^b at the point (3-form)"""
    Fm = Gv.Fm; vb, va0 = flat_form(e, v_up, Fm)
    with trunc(4, xdeg=1):
        dv = Fm.d(vb); sv = H.hodge_form(dv, e, E, Fm, SQ, NV, route='bit')
    X0 = {m: at0(p, NV) for m, p in sv.items()}
    out = dict(I=pull(X0, *tangents(P, a)), dv=dv, va=va0, star0={m: v for m, v in X0.items() if v != 0})
    if dd: out['dd'] = {m: at0(p, NV) for m, p in Fm.d(sv).items() if at0(p, NV) != 0}
    return out
def three_form(va, comp, c):
    """the 3-form c * v^a X_a at the point from components comp[(a, mu)] (coefficient of dx^{hat mu}): {mask: value}"""
    out = {}
    for mu in range(4):
        v = c * sum(va[a] * comp[(a, mu)] for a in range(4))
        if v != 0: out[FULL ^ (1 << mu)] = v
    return out

# ------------------------------------------------------------------------------------------------ [std] (c): plain polynomials at the point (no engine)
def std_ricci(e):
    """[std] Ricci R_{s v} at the point by the Christoffel route (b1lib.std_riemann) and g^-1 at the point"""
    g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1)
    return [[sum(R1[(r, s, r, v)] for r in range(4)) for v in range(4)] for s in range(4)], g0i
def std_point(e, v_up, P, a, rc=None):
    """[std] g = e^T eta e (2-jet), v_mu = g_{mu nu} v^nu, X = d v^b (1-jet), X^{mu nu} with the series inverse, det g = -1 as a 1-jet, *X_{ab} = (1/2) eps_{ab mu nu} X^{mu nu} (1-jet),
    the integrand at the point, d*X at the point, d_mu X^{mu nu} at the point and (rc = std_ricci(e)) -2 R^nu_mu v^mu from the Christoffel route"""
    n = 4; g = std_metric(e, n, SQ, n, 2); gi, g0, g0i = std_inverse_metric(g, n, n, 1)
    vl = [lin(*[(F(1), sp_mul(g[(m, k)], v_up[k], 2, n)) for k in range(n) if v_up[k] and g[(m, k)]]) for m in range(n)]
    Xl = {(m, k): {kk: c for kk, c in sp_add(sp_der(vl[k], m), sp_der(vl[m], k), -1).items() if sum(kk[:n]) <= 1} for m in range(n) for k in range(n)}
    Xu = {(m, k): lin(*[(F(1), sp_mul(sp_mul(gi[(m, al)], gi[(k, be)], 1, n), Xl[(al, be)], 1, n)) for al in range(n) for be in range(n) if Xl[(al, be)]]) for m in range(n) for k in range(n)}
    detg = {}
    for pm_ in itertools.permutations(range(n)):
        t = const(n, H.perm_sign(pm_))
        for i in range(n): t = sp_mul(t, g[(i, pm_[i])], 1, n)
        detg = sp_add(detg, t)
    st = {}
    for (al, be) in itertools.combinations(range(n), 2):
        st[(al, be)] = lin(*[(F(H.perm_sign((al, be, m, k)), 2), Xu[(m, k)]) for m in range(n) for k in range(n) if len({al, be, m, k}) == 4 and Xu[(m, k)]])
    star0 = {(1 << al) | (1 << be): at0(q, n) for (al, be), q in st.items() if at0(q, n) != 0}
    d1 = lambda q, i: at0(sp_der(q, i), n)
    dd = {}
    for (x, y, z) in itertools.combinations(range(n), 3):
        v = d1(st[(y, z)], x) - d1(st[(x, z)], y) + d1(st[(x, y)], z)
        if v != 0: dd[(1 << x) | (1 << y) | (1 << z)] = v
    div = [sum(d1(Xu[(m, k)], m) for m in range(n)) for k in range(n)]
    out = dict(I=pull(star0, *tangents(P, a)), star0=star0, dd=dd, div=div, det_ok=(detg == const(n, -1)), dv0={(1 << m) | (1 << k): at0(Xl[(m, k)], n) for (m, k) in itertools.combinations(range(n), 2) if at0(Xl[(m, k)], n) != 0})
    if rc:
        ric, g0i = rc; v0 = [at0(q, n) for q in v_up]
        out['m2ric'] = [-2 * sum(g0i[k][s] * ric[s][m] * v0[m] for s in range(n) for m in range(n)) for k in range(n)]
    return out

# ------------------------------------------------------------------------------------------------ [std] (a): floats, closed-form Kerr-Schild metric, complex-step derivatives
EPS4 = np.zeros((4, 4, 4, 4))
for _p in itertools.permutations(range(4)): EPS4[_p] = H.perm_sign(_p)
ETA = np.diag([1.0, -1.0, -1.0, -1.0])
def _ks(X, M, a, s, tfac):
    t, x, y, z = X[..., 0], X[..., 1], X[..., 2], X[..., 3]
    b = x * x + y * y + z * z - a * a; r = np.sqrt((b + np.sqrt(b * b + 4 * a * a * z * z)) / 2)
    f = (M * r - s) * r * r / (r ** 4 + a * a * z * z) * (1 + tfac * t); A2 = r * r + a * a
    l = np.stack([np.ones_like(x), (r * x + a * y) / A2, (r * y - a * x) / A2, z / r], -1)
    return r, f, l
def _metric(X, M, a, s, tfac):
    r, f, l = _ks(X, M, a, s, tfac); return ETA - 2 * f[..., None, None] * l[..., :, None] * l[..., None, :]
def _oneform(X, M, a, s, kind, Om, tfac, Q):
    """v_mu = g_{mu nu} v^nu for v = xi, psi, chi = xi + Om psi; or F2's potential A = Q r^3/(r^4 + a^2 z^2) l ('A') and the wrong 'A2' (r^2 numerator)"""
    if kind in ('A', 'A2'):
        r, f, l = _ks(X, M, a, s, tfac); z = X[..., 3]
        h = Q * (r ** 3 if kind == 'A' else r ** 2) / (r ** 4 + a * a * z * z); return h[..., None] * l
    z0 = np.zeros_like(X[..., 0]); o = np.ones_like(X[..., 0])
    v = {'xi': (o, z0, z0, z0), 'psi': (z0, -X[..., 2], X[..., 1], z0), 'chi': (o, -Om * X[..., 2], Om * X[..., 1], z0)}[kind]
    return np.einsum('...mn,...n->...m', _metric(X, M, a, s, tfac), np.stack(v, -1))
def integrand_float(M, a, s, R, ct, st, cp, sp, kind, Om=0.0, tfac=0.0, Q=1.0):
    """[std] (*d w)(d_th, d_ph) at the angles (arrays): w = v^b or A from the closed forms; d_mu w_nu by complex step (h = 1e-30)"""
    M, a, s, R, Om, tfac, Q = (float(x) for x in (M, a, s, R, Om, tfac, Q)); ct, st, cp, sp = (np.asarray(x, dtype=float) for x in (ct, st, cp, sp))
    zz = np.zeros_like(ct)
    X = np.stack([zz, st * (R * cp - a * sp), st * (R * sp + a * cp), R * ct], -1)
    Tth = np.stack([zz, ct * (R * cp - a * sp), ct * (R * sp + a * cp), -R * st], -1); Tph = np.stack([zz, st * (-R * sp - a * cp), st * (R * cp - a * sp), zz], -1)
    D = np.zeros(X.shape + (4,)); h = 1e-30
    for mu in range(4):
        Xc = X.astype(complex); Xc[..., mu] += 1j * h; D[..., mu, :] = _oneform(Xc, M, a, s, kind, Om, tfac, Q).imag / h
    Xl = D - np.swapaxes(D, -1, -2); g = _metric(X, M, a, s, tfac); gi = np.linalg.inv(g); sg = np.sqrt(np.abs(np.linalg.det(g)))
    Xu = np.einsum('...ma,...ab,...nb->...mn', gi, Xl, gi); St = 0.5 * sg[..., None, None] * np.einsum('abmn,...mn->...ab', EPS4, Xu)
    return np.einsum('...a,...ab,...b->...', Tth, St, Tph)
def komar_float(M, a, s, R, kind, nu=32, nph=8, **kw):
    """[std] Int_S *d w over theta in (0, pi), phi in (0, 2 pi): Gauss-Legendre with nu nodes in cos theta (weight / sin theta), nph uniform nodes in phi"""
    u, w = np.polynomial.legendre.leggauss(nu); st1 = np.sqrt(1 - u * u); ph = 2 * PI * np.arange(nph) / nph
    CT = np.repeat(u, nph); ST = np.repeat(st1, nph); W = np.repeat(w / st1, nph) * (2 * PI / nph); CP = np.tile(np.cos(ph), nu); SP = np.tile(np.sin(ph), nu)
    return float(np.sum(W * integrand_float(M, a, s, R, CT, ST, CP, SP, kind, **kw)))

# ------------------------------------------------------------------------------------------------ [std] (b): Boyer-Lindquist closed forms (derived here from the recalled metric)
def I_xi_exact(M, a, s, R, ct, st):
    M, a, s, R = (F(x) for x in (M, a, s, R)); m = 2 * M * R - 2 * s; Sig = R * R + a * a * ct * ct
    return (R * R + a * a) * st * (2 * R * m - 2 * M * Sig) / Sig ** 2
def I_psi_exact(M, a, s, R, ct, st):
    M, a, s, R = (F(x) for x in (M, a, s, R)); m = 2 * M * R - 2 * s; Sig = R * R + a * a * ct * ct; W = (2 * M * Sig - 2 * R * m) / Sig ** 2
    return -a * st ** 3 * (2 * R * m / Sig - (R * R + a * a) * W)
def MK_closed(M, a, s, R):
    M, a, s, R = (float(x) for x in (M, a, s, R)); q = 2 * s
    return M - q / R if a == 0 else M - q / (2 * R) * (1 + (R * R + a * a) / (a * R) * math.atan(a / R))
def JK_closed(M, a, s, R):
    M, a, s, R = (float(x) for x in (M, a, s, R)); q = 2 * s
    return 0.0 if a == 0 else M * a - q / (4 * a) * ((a * a - R * R) / R + (R * R + a * a) ** 2 / (a * R * R) * math.atan(a / R))
def bl_quad(M, a, s, R, n=64):
    """the same integrals by an n-node Gauss-Legendre rule in cos theta of the closed-form integrand (phi integral = 2 pi)"""
    M, a, s, R = (float(x) for x in (M, a, s, R)); u, w = np.polynomial.legendre.leggauss(n); m = 2 * M * R - 2 * s; Sig = R * R + a * a * u * u
    W = (2 * M * Sig - 2 * R * m) / Sig ** 2
    return float(np.sum(w * (R * R + a * a) * (2 * R * m - 2 * M * Sig) / Sig ** 2)) / 4, float(np.sum(w * a * (1 - u * u) * (2 * R * m / Sig - (R * R + a * a) * W))) / 8

# ------------------------------------------------------------------------------------------------ members, spheres, points
MEMB = {'Schwarzschild': (F(1), F(0), F(0), 1), 'Kerr': (F(5), F(3), F(0), 1), 'RN': (F(3, 2), F(0), F(2), 1), 'ERN': (F(1), F(0), F(1), 2), 'KN1': (F(5), F(1), F(4), 1), 'KN2': (F(7, 2), F(2), F(2), 1)}
LABEL = {'Schwarzschild': 'Schwarzschild M = 1', 'Kerr': 'Kerr (M, a) = (5, 3)', 'RN': 'Reissner-Nordstrom (M, Q, kappa) = (3/2, 2, 1)', 'ERN': 'extremal Reissner-Nordstrom (M, Q, kappa) = (1, 1, 2)',
         'KN1': 'Kerr-Newman (M, a, Q, kappa) = (5, 1, 4, 1)', 'KN2': 'Kerr-Newman (M, a, Q, kappa) = (7/2, 2, 2, 1)'}
RADII = {'Schwarzschild': [F(1, 2), F(1), F(2), F(3), F(5), F(20)], 'Kerr': [F(1, 2), F(1), F(4), F(9), F(20)], 'RN': [F(1), F(3, 2), F(2), F(7), F(20)], 'ERN': [F(1), F(3)],
         'KN1': [F(1), F(4), F(9), F(20)], 'KN2': [F(1), F(6), F(20)]}
HOR = {'Schwarzschild': [F(2)], 'Kerr': [F(9), F(1)], 'RN': [F(2), F(1)], 'ERN': [F(1)], 'KN1': [F(9), F(1)], 'KN2': [F(6), F(1)]}
ANGS = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(3, 5), F(4, 5)), (F(-5, 13), F(12, 13))), ((F(-5, 13), F(12, 13)), (F(3, 5), F(-4, 5))), ((F(7, 25), F(24, 25)), (F(1), F(0)))]
def s_of(Q, kap): return F(kap) * F(Q) ** 2 / 4
def sphere_points(M, a, s, R, angs=ANGS, tfac=None):
    out = []
    for P in K.rational_kerr_points(a, [R], angs):
        e, E, _, data = F2.kn_frame_jet(P['p'], M, a, s, r0=R, tfac=tfac); out.append((P, e, E, data))
    return out
def floats_at(pts):
    return [np.array([float(P[k]) for (P, *_r) in pts]) for k in ('cth', 'sth', 'cph', 'sph')]
def orders(R, a):
    """two Gauss-Legendre orders for the sphere r = R: the integrand has poles at cos th = +-i R/a, so n1 ~ 20/ln(R/a + sqrt(1 + R^2/a^2)) (error ~ e^-40), n2 = 2 n1"""
    if a == 0: return 16, 32
    x = float(R) / float(a); n1 = max(24, int(20 / math.log(x + math.sqrt(1 + x * x))) + 1); return n1, 2 * n1
def rel(x, y): return abs(x - y) / max(1.0, abs(y))
def fmt(x): return '%.12f' % x

# ------------------------------------------------------------------------------------------------ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # built per run: an engine fault put into memory is seen
    head('F4-komar  Komar mass and angular momentum: the engine\'s d and Hodge star on the Kerr-Schild frames, values at rational points [bit], quadrature in floats [std]')
    REC = {}                      # (name, R) -> list of point records
    def run_sphere(name, R, heavy=1, tfac=None, s_override=None):
        M, a, Q, kap = MEMB[name]; s = s_of(Q, kap) if s_override is None else s_override; recs = []
        for i, (P, e, E, data) in enumerate(sphere_points(M, a, s, R, tfac=tfac)):
            p = P['p']; r = dict(P=P, xi=komar_point(Gv, e, E, K.d_t(p), P, a, dd=i < heavy), psi=komar_point(Gv, e, E, K.d_phi(p), P, a, dd=i < heavy), e=e, E=E, data=data)
            if i < heavy:
                comp = engine_E_from_R(Gv, e, engine_om_R(Gv, e, S, 4)[1], 4, 0); r['Ea'] = comp
                if Q: r['Ta'] = F2.maxwell_stress_comp(Gv, e, E, F2.kn_potential(Q, data))[0]
                rc = std_ricci(e); r['std_xi'] = std_point(e, K.d_t(p), P, a, rc); r['std_psi'] = std_point(e, K.d_phi(p), P, a, rc)
            recs.append(r)
        return recs

    # ---------------------------------------------------------------------------------------- 0
    head('0. conventions and the quadrature on known answers (Coulomb flux, Schwarzschild)')
    M, a, Q, kap = MEMB['Schwarzschild']; cs = {}
    for R in RADII['Schwarzschild']:
        REC[('Schwarzschild', R)] = run_sphere('Schwarzschild', R); cs[R] = {r['xi']['I'] / r['P']['sth'] for r in REC[('Schwarzschild', R)]}
    chk('bit', all(v == {2 * M} for v in cs.values()), 'Schwarzschild M = 1: the engine integrand (*d xi^b)(d_th, d_ph) = 2 M sin th = +2 sin th exactly at %d points on each of the spheres R = %s (inside, on and outside r = 2): '
        'so (1/8 pi) Int *d xi^b = +M, the sign of the mass normalisation is +1/(8 pi) in this convention' % (len(ANGS), ', '.join(map(str, RADII['Schwarzschild']))))
    RN = MEMB['RN']; sRN = s_of(RN[2], RN[3]); okC = True; vals = set()
    for (P, e, E, data) in sphere_points(RN[0], 0, sRN, F(7)):
        A = F2.kn_potential(RN[2], data)
        with trunc(4, xdeg=1): Fc = Gv.Fm.d(A); sF = H.hodge_form(Fc, e, E, Gv.Fm, SQ, NV, route='bit')
        c = pull({m: at0(q, NV) for m, q in sF.items()}, *tangents(P, 0)) / P['sth']; vals.add(c)
    chk('bit', vals == {-RN[2]}, 'Coulomb: on the Reissner-Nordstrom frame (M, Q, s) = (3/2, 2, 1), R = 7, the engine\'s (*dA)(d_th, d_ph) = -Q sin th exactly at %d points (A = (Q/rho) l, F2): Int *F = -4 pi Q, F2-M\'s orientation' % len(ANGS))
    for (MM, aa, ss, QQ, Rs, lab) in ((0, 0, 0, 2.0, (1.0, 3.0, 20.0), 'flat space'), (5, 1, 4, 4.0, (1.5, 9.0, 20.0), 'Kerr-Newman (5, 1, Q = 4, s = 4)')):
        res = [(R, komar_float(MM, aa, ss, R, 'A', nu=24, Q=QQ), komar_float(MM, aa, ss, R, 'A', nu=48, Q=QQ)) for R in Rs]
        chk('std', all(rel(I2, -4 * PI * QQ) < 1e-11 and abs(I1 - I2) < 1e-9 for (R, I1, I2) in res), '[floats] Coulomb flux of *dA through r = R in %s, Q = %g: %s = -4 pi Q = %.9f (24 and 48 nodes in cos theta, 8 in phi; largest |difference of the two orders| %.1e)' % (
            lab, QQ, ', '.join('%.9f (R = %g)' % (I2, R) for (R, I1, I2) in res), -4 * PI * QQ, max(abs(I1 - I2) for (R, I1, I2) in res)))
    wrong = [komar_float(5, 1, 4, R, 'A2', nu=48, Q=4.0) for R in (1.5, 9.0, 20.0)]
    chk('ctl', all(rel(x, -16 * PI) > 1e-3 for x in wrong) and abs(wrong[0] - wrong[2]) > 1e-3, 'control: the wrong potential (r^2 in place of r^3, F2-M\'s control) gives fluxes %s, not -4 pi Q and not the same on every sphere' % ', '.join('%.6f' % x for x in wrong))
    res = [(R, komar_float(1, 0, 0, R, 'xi', nu=16), komar_float(1, 0, 0, R, 'xi', nu=32)) for R in (0.5, 2.0, 5.0, 20.0)]
    chk('std', all(abs(I2 / (8 * PI) - 1) < 1e-12 and abs(I1 - I2) < 1e-10 for (R, I1, I2) in res), '[floats] Schwarzschild M = 1: (1/8 pi) Int *d xi^b = %s at R = 0.5, 2, 5, 20 (16 and 32 nodes; largest |difference| %.1e)' % (
        ', '.join(fmt(I2 / (8 * PI)) for (R, I1, I2) in res), max(abs(I1 - I2) / (8 * PI) for (R, I1, I2) in res)))
    chk('ctl', all(abs(-I2 / (8 * PI) - 1) > 1 for (R, I1, I2) in res), 'control: the normalisation -1/(8 pi) gives -M = %s on the same spheres (the sign is a convention; +1/(8 pi) here)' % fmt(-res[0][2] / (8 * PI)))
    tick('part 0')

    # ---------------------------------------------------------------------------------------- 1
    head('1. vacuum: Schwarzschild and Kerr (5, 3); integrands exact at the points, integrals by quadrature on every sphere')
    for name in ('Kerr',):
        for R in RADII[name]: REC[(name, R)] = run_sphere(name, R)
    for name in ('Schwarzschild', 'Kerr'):
        M, a, Q, kap = MEMB[name]; s = F(0); okx = okp = oka = okf = True; npt = 0; worst = 0.0
        for R in RADII[name]:
            recs = REC[(name, R)]; npt += len(recs)
            okx &= all(r['xi']['I'] == I_xi_exact(M, a, s, R, r['P']['cth'], r['P']['sth']) for r in recs)
            okp &= all(r['psi']['I'] == I_psi_exact(M, a, s, R, r['P']['cth'], r['P']['sth']) for r in recs)
            oka &= recs[0]['xi']['I'] == recs[1]['xi']['I'] and recs[0]['psi']['I'] == recs[1]['psi']['I']
            pts = [(r['P'],) for r in recs]; ct, st, cp, sp = floats_at(pts)
            for kind in ('xi', 'psi'):
                fl = integrand_float(M, a, s, R, ct, st, cp, sp, kind)
                for r, x in zip(recs, fl): d = rel(x, float(r[kind]['I'])); worst = max(worst, d); okf &= d < 1e-10
        chk('bit==std', okx and okp, '%s: the engine integrands of *d xi^b and *d psi^b equal the Boyer-Lindquist closed forms I_xi, I_psi EXACTLY at %d points on the spheres R = %s' % (LABEL[name], npt, ', '.join(map(str, RADII[name]))))
        chk('bit', oka, '%s: axisymmetry at the points: the two points with cos th = 3/5 and different phi give the same integrand (both fields, every sphere)' % LABEL[name])
        chk('bit==std', okf, '%s: engine integrand = [floats] closed-form Kerr-Schild metric with complex-step derivatives at the same %d x 2 angles (largest relative difference %.1e)' % (LABEL[name], npt, worst))
        okd = True; okE = True; okS = True; okW = True; okR = True; nW = 0
        for R in RADII[name]:
            r0 = REC[(name, R)][0]; p = r0['P']['p']
            for k in ('xi', 'psi'):
                dd = r0[k]['dd']; sd = r0['std_' + k]
                okd &= not dd; okE &= not three_form(r0[k]['va'], r0['Ea'], -2)
                okS &= sd['dd'] == dd and sd['det_ok'] and sd['I'] == r0[k]['I'] and sd['star0'] == r0[k]['star0'] and all(v == 0 for v in sd['div'])
                if 'm2ric' in sd: okR &= all(v == 0 for v in sd['m2ric'])
            e0, E0, det = E0_of(r0['e'], 4, 4)
            for k, xi in (('xi', K.d_t(p)), ('psi', K.d_phi(p))):
                W = F3.wald_engine(Gv, r0['e'], E0, xi, S); Ws = F3.wald_std(r0['e'], xi)
                with trunc(4, xdeg=0): fc = H.frame_components(r0[k]['dv'], r0['E'], 4)
                dva = {(A_, B_): at0(fc.get((1 << A_) | (1 << B_), {}), NV) for (A_, B_) in itertools.combinations(range(4), 2)}
                okW &= all(dva[(A_, B_)] == W['nab'][A_][B_] - W['nab'][B_][A_] for (A_, B_) in dva) and any(dva.values()) and all(v == 0 for row in W['K'] for v in row)
                okW &= all(at0(r0[k]['dv'].get((1 << m) | (1 << n_), {}), NV) == Ws['nab'][m][n_] - Ws['nab'][n_][m] for (m, n_) in itertools.combinations(range(4), 2)); nW += 1
        chk('bit', okd and okE, '%s: d*d xi^b = 0 and d*d psi^b = 0 at the points (one per sphere): the integrand is closed in vacuum; and -2 v^a E_a = 0 with the engine\'s Einstein form there' % LABEL[name])
        chk('bit==std', okS and okR, '%s: plain-polynomial route at the same points: *d v^b, the integrand and d*d v^b equal the engine\'s exactly; det g = -1 as a 1-jet; d_mu (d v^b)^{mu nu} = 0 = -2 R^nu_mu v^mu (Christoffel route)' % LABEL[name])
        chk('bit==std', okW, '%s: d v^b = 2 nabla v at %d (point, field) pairs: frame components of the engine\'s d xi^b = nabla_a xi_b - nabla_b xi_a with nabla from the engine\'s omega and h table (Killing: nabla_(a xi_b) = 0), and = the Christoffel route' % (LABEL[name], nW))
    QK = {}
    for name in ('Schwarzschild', 'Kerr'):
        M, a, Q, kap = MEMB[name]; rows = []
        for R in RADII[name]:
            n1, n2 = orders(R, a)
            Ix1, Ix2 = komar_float(M, a, 0, R, 'xi', nu=n1), komar_float(M, a, 0, R, 'xi', nu=n2); Ip1, Ip2 = komar_float(M, a, 0, R, 'psi', nu=n1), komar_float(M, a, 0, R, 'psi', nu=n2)
            QK[(name, R)] = (Ix2 / (8 * PI), -Ip2 / (16 * PI)); rows.append((R, n1, n2, Ix2 / (8 * PI), -Ip2 / (16 * PI), max(abs(Ix1 - Ix2) / (8 * PI), abs(Ip1 - Ip2) / (16 * PI))))
        ok = all(abs(m_ - float(M)) < 1e-10 and abs(j_ - float(M * a)) < 1e-10 and er < 1e-9 for (R, n1, n2, m_, j_, er) in rows)
        chk('std', ok, '%s: [floats] M_K = (1/8 pi) Int *d xi^b and J_K = -(1/16 pi) Int *d psi^b on r = R: %s; M = %s, M a = %s (orders %s; largest |difference of two orders| %.1e)' % (
            LABEL[name], '; '.join('R = %s: (%.12f, %.12f)' % (R, m_, j_) for (R, n1, n2, m_, j_, er) in rows), M, M * a, ', '.join('%d/%d' % (r[1], r[2]) for r in rows), max(r[5] for r in rows)))
    M, a = MEMB['Kerr'][:2]
    ok = all(abs(MK_closed(M, a, 0, R) - 5) < 1e-12 and abs(JK_closed(M, a, 0, R) - 15) < 1e-12 and max(abs(x - y) for x, y in zip(bl_quad(M, a, 0, R, 96), (5, 15))) < 1e-9 for R in RADII['Kerr'])
    chk('std', ok, 'Kerr (5, 3): the Boyer-Lindquist closed forms give M_K = 5 and J_K = M a = 15 at every R (q = 0), and so does a 96-node Gauss-Legendre rule of the closed-form integrand')
    low = komar_float(M, a, 0, F(1), 'xi', nu=4) / (8 * PI)
    chk('ctl', abs(low - 5) > 1e-3 and abs(QK[('Kerr', F(1))][0] - 5) < 1e-10, 'control: 4 nodes in cos theta on Kerr r = 1 give M_K = %.6f (error %.1e), %d nodes %.12f: the error estimate from two orders is real' % (low, abs(low - 5), orders(1, 3)[1], QK[('Kerr', F(1))][0]))
    tick('part 1')

    # ---------------------------------------------------------------------------------------- 2
    head('2. with a Maxwell field: Reissner-Nordstrom and Kerr-Newman; d*d v^b = -2 v^a E_a = 2 kappa v^a T_a; the integrals depend on R')
    for name in ('RN', 'ERN', 'KN1', 'KN2'):
        for R in RADII[name]: REC[(name, R)] = run_sphere(name, R, heavy=2)
    for name in ('RN', 'ERN', 'KN1', 'KN2'):
        M, a, Q, kap = MEMB[name]; s = s_of(Q, kap); okx = okp = okf = True; npt = 0; worst = 0.0
        for R in RADII[name]:
            recs = REC[(name, R)]; npt += len(recs)
            okx &= all(r['xi']['I'] == I_xi_exact(M, a, s, R, r['P']['cth'], r['P']['sth']) for r in recs)
            okp &= all(r['psi']['I'] == I_psi_exact(M, a, s, R, r['P']['cth'], r['P']['sth']) for r in recs)
            ct, st, cp, sp = floats_at([(r['P'],) for r in recs])
            for kind in ('xi', 'psi'):
                fl = integrand_float(M, a, s, R, ct, st, cp, sp, kind)
                for r, x in zip(recs, fl): d = rel(x, float(r[kind]['I'])); worst = max(worst, d); okf &= d < 1e-10
        chk('bit==std', okx and okp and okf, '%s: engine integrands of *d xi^b and *d psi^b = closed forms I_xi, I_psi (q = 2s = %s) EXACTLY at %d points on R = %s, and = the float route (largest relative difference %.1e)' % (
            LABEL[name], 2 * s, npt, ', '.join(map(str, RADII[name])), worst))
        okE = okT = okS = okR = True; nz = 0; nE = 0
        for R in RADII[name]:
            for r in REC[(name, R)][:2]:
                for k in ('xi', 'psi'):
                    dd = r[k]['dd']; nE += 1; nz += bool(dd)
                    okE &= dd == three_form(r[k]['va'], r['Ea'], -2)
                    okT &= dd == three_form(r[k]['va'], r['Ta'], 2 * F(kap))
                    sd = r['std_' + k]; okS &= sd['dd'] == dd and sd['det_ok'] and sd['I'] == r[k]['I']
                    if 'm2ric' in sd: okR &= sd['div'] == sd['m2ric'] and any(sd['div'])
        chk('bit', okE and nz > 0, '%s: d*d v^b = -2 v^a E_a (engine Einstein form, c = 0) for v = xi and psi at %d (point, field) pairs, all 4 components; non-zero at %d of them' % (LABEL[name], nE, nz))
        chk('bit', okT, '%s: d*d v^b = 2 kappa v^a T_a with T(a) = -1/2 F a F, F = dA (engine d, F2\'s stress forms): the local form of the charge term' % LABEL[name])
        chk('bit==std', okS and okR, '%s: plain-polynomial route: d*d v^b and the integrand equal the engine\'s exactly; d_mu (d v^b)^{mu nu} = -2 R^nu_mu v^mu (Christoffel route of Ricci), non-zero' % LABEL[name])
    CR = {}
    for name in ('RN', 'ERN'):
        M, a, Q, kap = MEMB[name]; s = s_of(Q, kap); CR[name] = cc = {}
        for R in RADII[name]: cc[R] = {r['xi']['I'] / r['P']['sth'] for r in REC[(name, R)]}
        chk('bit', all(v == {2 * M - 4 * s / R} for R, v in cc.items()), '%s: the integrand is c sin th with ONE c = 2M - 4s/R at the %d points of each sphere (c = %s for R = %s): M_K(R) = c/2 = M - 2s/R exactly' % (
            LABEL[name], len(ANGS), ', '.join(str(one(v)) for v in cc.values()), ', '.join(map(str, RADII[name]))))
    cR = CR['RN']; QC = {}
    for name in ('RN', 'ERN', 'KN1', 'KN2'):
        M, a, Q, kap = MEMB[name]; s = s_of(Q, kap); rows = []
        for R in RADII[name]:
            n1, n2 = orders(R, a); Ix1, Ix2 = komar_float(M, a, s, R, 'xi', nu=n1), komar_float(M, a, s, R, 'xi', nu=n2); Ip1, Ip2 = komar_float(M, a, s, R, 'psi', nu=n1), komar_float(M, a, s, R, 'psi', nu=n2)
            mk, jk = Ix2 / (8 * PI), -Ip2 / (16 * PI); QC[(name, R)] = (mk, jk); bq = bl_quad(M, a, s, R, 96)
            rows.append((R, mk, jk, MK_closed(M, a, s, R), JK_closed(M, a, s, R), max(abs(Ix1 - Ix2) / (8 * PI), abs(Ip1 - Ip2) / (16 * PI)), max(abs(bq[0] - mk), abs(bq[1] - jk))))
        ok = all(abs(mk - mc) < 1e-10 and abs(jk - jc) < 1e-10 and er < 1e-9 and eb < 1e-9 for (R, mk, jk, mc, jc, er, eb) in rows)
        chk('std', ok, '%s: [floats] (M_K, J_K) on r = R: %s = the closed forms (largest |difference of two orders| %.1e; 96-node rule of the closed-form integrand agrees to %.1e)' % (
            LABEL[name], '; '.join('R = %s: (%.10f, %.10f)' % (R, mk, jk) for (R, mk, jk, mc, jc, er, eb) in rows), max(r[5] for r in rows), max(r[6] for r in rows)))
    far = [(name, MK_closed(*[MEMB[name][0], MEMB[name][1], s_of(*MEMB[name][2:]), 10 ** 6]), JK_closed(*[MEMB[name][0], MEMB[name][1], s_of(*MEMB[name][2:]), 10 ** 6])) for name in ('RN', 'ERN', 'KN1', 'KN2')]
    chk('std', all(abs(mk - float(MEMB[n_][0])) < 1e-4 and abs(jk - float(MEMB[n_][0] * MEMB[n_][1])) < 1e-4 for (n_, mk, jk) in far), 'charged members: M_K -> M and J_K -> M a at large R (R = 10^6: %s)' % '; '.join('(%.7f, %.7f)' % (mk, jk) for (n_, mk, jk) in far))
    tick('part 2')

    # ---------------------------------------------------------------------------------------- 3
    head('3. horizons: pointwise (*d chi^b)(d_th, d_ph) = 2 kH Abar sin th with F2\'s engine numbers; M_K - 2 Omega_H J_K = kH Abar; Smarr from the integral side')
    HN = {}
    for name in ('Schwarzschild', 'Kerr', 'RN', 'ERN', 'KN1', 'KN2'):
        M, a, Q, kap = MEMB[name]; s = s_of(Q, kap)
        for rh in HOR[name]:
            out = F2.horizon_numbers(Gv, S, M, a, s, rh, ANGS, Q=Q, std=False)
            kH, Om, Ab = one(out['kH']), one(out['Om']), one(out['area']); Phi = one(out['phi']) if Q else F(0)
            vals = set(); vx = True
            for r in REC[(name, rh)]:
                P = r['P']; p = P['p']
                if None in (kH, Om, Ab): vals.add(None); continue
                c = komar_point(Gv, r['e'], r['E'], K.killing_chi(p, Om), P, a)['I']
                vals.add(c / P['sth']); vx &= c == r['xi']['I'] + Om * r['psi']['I']
            HN[(name, rh)] = dict(kH=kH, Om=Om, Ab=Ab, Phi=Phi, c=one(vals))
            tgt = 2 * kH * Ab if None not in (kH, Ab) else 'none'
            chk('bit', kH is not None and vals == {tgt} and vx, '%s, horizon r = %s: (*d chi^b)(d_th, d_ph) = 2 kH Abar sin th exactly at %d points, chi = d_t + Omega_H d_phi, with the engine\'s kH = %s, Omega_H = %s, Abar = %s (F2\'s recipe): (1/8 pi) Int *d chi^b = kH Abar = %s' % (
                LABEL[name], rh, len(ANGS), kH, Om, Ab, (kH * Ab) if kH is not None and Ab is not None else None))
    rows = []
    for (name, rh), h in HN.items():
        M, a, Q, kap = MEMB[name]; s = s_of(Q, kap)
        if None in (h['kH'], h['Om'], h['Ab'], h['Phi']): rows.append((name, rh, None, None, None, None)); continue
        mk, jk = (QK.get((name, rh)) or QC.get((name, rh)))
        lhs = mk - 2 * float(h['Om']) * jk; sm = float(M) - mk - 2 * float(h['Om']) * (float(M * a) - jk); rhs = float(F(kap) / 2 * h['Phi'] * Q)
        rows.append((name, rh, lhs, h['kH'] * h['Ab'], sm, rhs))
    ok = all(r[2] is not None and abs(r[2] - float(r[3])) < 1e-10 for r in rows)
    chk('bit==std', ok, '[floats] M_K(r_h) - 2 Omega_H J_K(r_h) = the engine\'s kH Abar on all %d horizons (outer and inner, signed kH): %s' % (len(rows), '; '.join('%s r = %s: %.10f = %s' % (n_, rh, l_, r3) for (n_, rh, l_, r3, sm, rhs) in rows if l_ is not None)))
    chk('bit==std', all(r[4] is not None and abs(r[4] - r[5]) < 1e-10 for r in rows), 'Smarr from the integral side ([floats] M_K, J_K; the engine\'s Omega_H, Phi_H): M - M_K(r_h) - 2 Omega_H (M a - J_K(r_h)) = (kappa/2) Phi_H Q on all %d horizons (F2\'s Phi_H): %s' % (len(rows), '; '.join(
        '%s r = %s: %.10f = %.10f' % (n_, rh, sm, rhs) for (n_, rh, l_, r3, sm, rhs) in rows if sm is not None)))
    okx = True; ex = []
    for name in ('RN', 'ERN'):
        M, a, Q, kap = MEMB[name]; s = s_of(Q, kap)
        for rh in HOR[name]:
            h = HN[(name, rh)]; cc = one(CR[name][rh]); ok1 = cc is not None and None not in (h['kH'], h['Ab'], h['Phi']) and cc / 2 == h['kH'] * h['Ab'] and M - cc / 2 == F(kap) / 2 * h['Phi'] * Q == 2 * s / rh
            okx &= ok1; ex.append('%s r = %s: (%s, %s)' % ('extremal' if name == 'ERN' else name, rh, cc / 2 if cc is not None else None, M - cc / 2 if cc is not None else None))
    chk('bit', okx, 'Reissner-Nordstrom, exact: M_K(r_h) = c/2 = kH Abar and M - M_K(r_h) = (kappa/2) Phi_H Q = 2s/r_h; (M_K, M - M_K) = %s: on the extremal horizon (kH = 0) the whole mass is the charge term; F2\'s weights (1, kappa/2) from the integral side' % '; '.join(ex))
    brief = []
    for (name, rh), h in HN.items():
        M, a, Q, kap = MEMB[name]
        if None in (h['kH'], h['Om'], h['Ab']): continue
        mk, jk = (QK.get((name, rh)) or QC.get((name, rh))); brief.append((name, rh, mk - float(h['kH'] * h['Ab'] + 2 * h['Om'] * M * a), 2 * float(h['Om']) * (float(M * a) - jk), float(h['Om'])))
    vac = [b for b in brief if b[0] in ('Schwarzschild', 'Kerr', 'RN', 'ERN')]; kn = [b for b in brief if b[0] in ('KN1', 'KN2')]
    chk('bit==std', all(abs(b[2]) < 1e-10 for b in vac) and all(abs(b[2] + b[3]) < 1e-10 and abs(b[2]) > 1e-4 and b[4] > 0 and b[3] > 1e-4 for b in kn),
        'the horizon form M_K(r_h) = kH Abar + 2 Omega_H M a holds on Schwarzschild, Kerr and Reissner-Nordstrom (extremal too) but NOT on Kerr-Newman: there M_K(r_h) - kH Abar - 2 Omega_H M a = -2 Omega_H (M a - J_K(r_h)) = %s, so J_K(r_h) < M a on each of them (Omega_H > 0; the field outside the horizon carries angular momentum)' % (
            ', '.join('%.10f (%s r = %s)' % (b[2], b[0], b[1]) for b in kn)))
    tick('part 3')

    # ---------------------------------------------------------------------------------------- 4
    head('4. controls (a wrong version must fail)')
    M, a, Q, kap = MEMB['RN']; s = s_of(Q, kap); twin = {}; okT = True
    for R in (F(3), F(7), F(20)):
        recs = run_sphere('RN', R, heavy=1, s_override=-s); twin[R] = {r['xi']['I'] / r['P']['sth'] for r in recs}
        r0 = recs[0]; okT &= r0['xi']['dd'] == three_form(r0['xi']['va'], r0['Ea'], -2) and r0['xi']['dd'] != three_form(r0['xi']['va'], r0['Ta'], 2 * F(kap)) and bool(r0['xi']['dd'])
    chk('ctl', all(v == {2 * M + 4 * s / R} and v != {2 * M - 4 * s / R} for R, v in twin.items()), 'control, the ghost-coupled twin of H4 (f = M/rho + s/rho^2, the charge term with the opposite sign): c = 2M + 4s/R = %s, so M_K(R) = M + 2s/R, other numbers than M - 2s/R' % (
        ', '.join(str(one(v)) for v in twin.values())))
    chk('ctl', okT, 'control, the twin: d*d xi^b = -2 xi^a E_a still holds (a kinematic identity), but d*d xi^b = 2 kappa xi^a T_a fails (its matter enters with the opposite sign)')
    tf = {}
    for R in (F(3), F(20)):
        tf[R] = {r['xi']['I'] / r['P']['sth'] for r in run_sphere('Schwarzschild', R, heavy=0, tfac=F(1, 7))}
    tfl = [komar_float(1, 0, 0, R, 'xi', nu=32, tfac=1 / 7) / (8 * PI) for R in (3.0, 20.0)]
    chk('ctl', all(len(v) == 1 for v in tf.values()) and len({one(v) for v in tf.values()}) == 2 and one(tf[F(3)]) == 2 * (1 + F(3, 7)) and abs(tfl[0] - 10 / 7) < 1e-10 and abs(tfl[1] - 27 / 7) < 1e-10,
        'control, a time-dependent mass M(1 + t/7) (F2\'s tfac), t = 0: the d_t integrand is %s sin th on R = 3 and 20: the integral %.10f, %.10f = M (1 + R/7) changes with R, no vacuum constancy' % (
            ', '.join(str(one(v)) for v in tf.values()), tfl[0], tfl[1]))
    c1, c2 = one(cR[F(2)]), one(cR[F(20)])
    chk('ctl', c1 is not None and c2 is not None and (c2 - c1) / 2 == 2 * s * (1 / F(2) - 1 / F(20)) != 0 and all(v == {2} for v in cs.values()),
        'control, shifted sphere: Schwarzschild M_K is the same at R = 1/2 .. 20 (section 0) while Reissner-Nordstrom M_K(20) - M_K(2) = %s = 2s (1/2 - 1/20) exactly: the charge term' % ((c2 - c1) / 2 if c1 is not None and c2 is not None else None))
    M, a = MEMB['Kerr'][:2]; wr = komar_float(M, a, 0, 20, 'chi', nu=48, Om=0.1) / (8 * PI); okw = True
    for r in REC[('Kerr', F(20))]:
        okw &= komar_point(Gv, r['e'], r['E'], K.killing_chi(r['P']['p'], F(1, 10)), r['P'], a)['I'] != I_xi_exact(M, a, 0, 20, r['P']['cth'], r['P']['sth'])
    chk('ctl', abs(wr - (5 - 15 / 5)) < 1e-10 and okw, 'control, the Killing field d_t + (1/10) d_phi on Kerr (5, 3), R = 20: (1/8 pi) Int = %.10f = M - J/5 = 2, not M = 5; the engine integrand differs from I_xi at all %d points' % (wr, len(ANGS)))
    jw = QK[('Kerr', F(20))][1] * (-2)
    chk('ctl', abs(jw - (-30)) < 1e-9, 'control, J with the mass normalisation +1/(8 pi): %.10f = -2 M a, not M a (Komar\'s factor -1/2 between the two integrals)' % jw)
    M, a, Q, kap = MEMB['RN']; s = s_of(Q, kap)
    chk('ctl', all(abs(QC[('RN', R)][0] - float(M - s / R)) > 1e-3 for R in RADII['RN']), 'control, the charge term s/R in place of 2s/R: M - s/R misses the Reissner-Nordstrom M_K(R) on every sphere')
    okg = all(abs(r[4] - 2 * r[5]) > 1e-4 for r in rows if r[5] is not None and abs(r[5]) > 1e-12)
    chk('ctl', okg and any(r[5] is not None and abs(r[5]) > 1e-12 for r in rows), 'control, Smarr from the integral side with gamma = kappa in place of kappa/2: fails on every charged horizon')
    okoff = True
    M, a = MEMB['Kerr'][:2]; h = HN[('Kerr', F(9))]
    for r in (REC[('Kerr', F(20))] if None not in (h['kH'], h['Om'], h['Ab']) else []):
        c = komar_point(Gv, r['e'], r['E'], K.killing_chi(r['P']['p'], h['Om']), r['P'], a)['I']; okoff &= c != 2 * h['kH'] * h['Ab'] * r['P']['sth']
    chk('ctl', okoff and None not in (h['kH'], h['Om'], h['Ab']), 'control, the horizon identity off the horizon: on Kerr r = 20 the chi integrand (Omega_H = 1/30) is not 2 kH Abar sin th at any of the %d points' % len(ANGS))
    tick('part 4')
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F4-komar')

if __name__ == '__main__': main()
