#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A6. Topological companions as exact forms.  Exact fractions on the engine path, numpy floats on the standard path.
   python3 a6_topological.py
 Engine language: omega^A (A = pair a<b) bivector-valued 1-forms, R = d omega + (1/4) Q with Q^C = f_AB^C omega^A ^ omega^B, T^c = d e^c + h_Ab^c omega^A ^ e^b.
 Parts  1 Chern-Simons in the Lie language (f table): Euler and Pontryagin, cubic coefficient found by an exact fit
        2 the space of all k(R, R) that are d of a 3-form k(omega, d omega) + m(omega, Q): its dimension
        3 the textbook formula with the engine's vector matrices (h table)
        4 [std] numpy: so(1,3) matrices, textbook R, tr(R R), 8 Pf(R), Chern-Simons with 2/3, d by 7-point stencils; [bit==std] values at points
        5 Nieh-Yan  6 Holst (identity; T = 0 by A3's closed form; contorsion)  7 MacDowell-Mansouri expansion  8 other dimensions (n = 5, n = 2)"""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
import numpy as np
import b1lib
from b1lib import (chk, head, finish, gs, Grav, Lie, trunc, at0, solve_exact, rank_exact, pairs_of, koszul_S, omega_closed_form, engine_om_R,
                   rand_frame, translate_frame, E0_of, std_metric, std_riemann, std_einstein_mixed)
from b1_first_variation import lag_MM, lag_EC, wedge_list

def LOR(n): return [1] + [-1] * (n - 1)
DEG = {1: 2, 2: 1}                                                                                   # polynomial degree of the random fields per seed
def tick(t0, part): print('  time %s: %.1f s' % (part, time.time() - t0), flush=True)

# ------------------------------------------------------------------------------------------------ random data (plain dicts, shared by both routes)
def rand_poly(rng, nv, deg, density=.5, coef=3):
    p = {}
    for ex in itertools.product(range(deg + 1), repeat=nv):
        if sum(ex) <= deg and rng.random() < density:
            c = rng.randint(-coef, coef)
            if c: p[ex] = F(c)
    return p
def rand_conn_data(rng, n, deg=2, density=.5):
    """omega^{ab}_mu(x) for a < b:  {(a, b): [polynomial for mu = 0..n-1]}"""
    return {(a, b): [rand_poly(rng, n, deg, density) for _ in range(n)] for (a, b) in itertools.combinations(range(n), 2)}
def rand_frame_data(rng, n, deg=2, density=.5):
    """e^a_mu(x): [[polynomial]] (no invertibility needed for the form identities)"""
    return [[rand_poly(rng, n, deg, density) for _ in range(n)] for _ in range(n)]
def eng_conn(Gv, W):
    om = [{} for _ in range(Gv.G)]
    for (a, b), comps in W.items(): om[Gv.L.idx[(1 << a) | (1 << b)]] = {1 << mu: dict(p) for mu, p in enumerate(comps) if p}
    return om
def eng_frame(E): return [{1 << mu: dict(p) for mu, p in enumerate(row) if p} for row in E]

# ------------------------------------------------------------------------------------------------ [bit] engine-side constructions (exported)
def Qforms(Gv, om):
    """[bit] Q^C = f_AB^C omega^A ^ omega^B over ordered pairs (the engine's f table), so that the engine's R = d omega + (1/4) Q"""
    Fm = Gv.Fm; Q = [{} for _ in range(Gv.G)]
    for (A, B), (C, f) in Gv.L.f.items():
        if om[A] and om[B]: Q[C] = Fm.add(Q[C], Fm.wedge(om[A], om[B]), f)
    return Q
def kform(Gv, kind):
    """symmetric bilinear forms on the bivector labels, {(A, B): coefficient}, k(X, Y) = sum k_AB X^A ^ Y^B:
       'P'    R^{ab} R_{ab} over all a, b = 2 sum_A sq_a sq_b X^A Y^A  (Pontryagin; = -tr in the vector representation)
       'E'    eps_{abcd} X^{ab} Y^{cd} over all indices = 4 sum_{A,B} eps(a,b,c,d) X^A Y^B  (Euler; n = 4 only)
       'Eucl' sum X^{ab} Y^{ab} without eta (a control: not invariant under so(1,3))"""
    sq = Gv.L.sq; P = pairs_of(Gv.L); k = {}
    for A, (a, b) in enumerate(P):
        if kind == 'P': k[(A, A)] = F(2 * sq[a] * sq[b])
        elif kind == 'Eucl': k[(A, A)] = F(2)
        elif kind == 'E':
            for B, (c, d) in enumerate(P):
                s = Gv.eps([a, b, c, d]) if len({a, b, c, d}) == 4 else 0
                if s: k[(A, B)] = F(4 * s)
    return k
def kpair(Gv, k, X, Y):
    """[bit] sum_{A,B} k_AB X^A ^ Y^B"""
    Fm = Gv.Fm; tot = {}
    for (A, B), c in k.items():
        if X[A] and Y[B]: tot = Fm.add(tot, Fm.wedge(X[A], Y[B]), c)
    return tot
def cs_form(Gv, k, om, x=F(1, 6), a=1, Q=None):
    """[bit] Chern-Simons 3-form k(omega, a d omega + x Q).  For an invariant k, d of it is k(R, R) exactly at a = 1, x = 1/6 (= textbook 2/3 times the engine's 1/4)"""
    Fm = Gv.Fm; Q = Q if Q is not None else Qforms(Gv, om)
    inner = [Fm.add(Fm.scale(Fm.d(om[B]), a), Q[B], x) for B in range(Gv.G)]
    return kpair(Gv, k, om, inner)
class Pieces:
    """pair products for one connection: RR[(A,B)] = R^A ^ R^B (A <= B), dWdW[(A,B)] = d(omega^A ^ d omega^B), dWQ[(A,B)] = d(omega^A ^ Q^B) (ordered pairs)"""
    def __init__(self, Gv, om):
        Fm = Gv.Fm; G = Gv.G; self.Gv = Gv; self.om = om
        self.R = Gv.curvature(om); self.Q = Qforms(Gv, om); dom = [Fm.d(w) for w in om]
        self.RR = {(A, B): Fm.wedge(self.R[A], self.R[B]) for A in range(G) for B in range(A, G)}
        self.dWdW = {(A, B): Fm.d(Fm.wedge(om[A], dom[B])) for A in range(G) for B in range(G)}
        self.WQ = {(A, B): Fm.wedge(om[A], self.Q[B]) for A in range(G) for B in range(G)}; self.dWQ = {key: Fm.d(X) for key, X in self.WQ.items()}
    def comb(self, k, which):
        Fm = self.Gv.Fm; tot = {}
        for (A, B), c in k.items():
            X = self.RR[(min(A, B), max(A, B))] if which == 'RR' else {'WdW': self.dWdW, 'WQ': self.dWQ, 'WQ3': self.WQ}[which][(A, B)]
            tot = Fm.add(tot, X, c)
        return tot
def vec_rep(Gv, X):
    """[bit] vector-representation matrix of a bivector-valued form from the engine's h table: M[c][b] = sum_A h_Ab^c X^A"""
    n = Gv.n; Fm = Gv.Fm; M = [[{} for _ in range(n)] for _ in range(n)]
    for (A, b), (c, h) in Gv.L.h.items():
        if X[A]: M[c][b] = Fm.add(M[c][b], X[A], h)
    return M
def mat_wedge(Fm, M1, M2):
    n = len(M1); out = [[{} for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            t = {}
            for l in range(n):
                if M1[i][l] and M2[l][j]: t = Fm.add(t, Fm.wedge(M1[i][l], M2[l][j]))
            out[i][j] = t
    return out
def trace_wedge(Fm, M1, M2):
    """tr(M1 ^ M2) = sum_{a,b} M1[a][b] ^ M2[b][a]"""
    t = {}
    for i in range(len(M1)):
        for l in range(len(M1)):
            if M1[i][l] and M2[l][i]: t = Fm.add(t, Fm.wedge(M1[i][l], M2[l][i]))
    return t
def eps_pairs(Gv, X, Y):
    """eps_{abcd} X^{ab} ^ Y^{cd} over all indices for antisymmetric matrices of forms (upper indices), n = 4: 4 sum over a<b, c<d"""
    Fm = Gv.Fm; t = {}
    for (a, b) in itertools.combinations(range(4), 2):
        for (c, d) in itertools.combinations(range(4), 2):
            s = Gv.eps([a, b, c, d]) if len({a, b, c, d}) == 4 else 0
            if s and X[a][b] and Y[c][d]: t = Fm.add(t, Fm.wedge(X[a][b], Y[c][d]), 4 * s)
    return t
def mat_trace(Fm, M):
    t = {}
    for i in range(len(M)): t = Fm.add(t, M[i][i])
    return t
def holst(Gv, e, R, eta=True):
    """[bit] e^a ^ e^b ^ R_ab over all a, b = 2 sum_{a<b} sq_a sq_b e^a ^ e^b ^ R^{ab}   (eta=False: Euclidean contraction, a control)"""
    Fm = Gv.Fm; sq = Gv.L.sq; tot = {}
    for A, (a, b) in enumerate(pairs_of(Gv.L)):
        if R[A]: tot = Fm.add(tot, Fm.wedge(Fm.wedge(e[a], e[b]), R[A]), 2 * (sq[a] * sq[b] if eta else 1))
    return tot
def nieh_yan_pieces(Gv, e, om, eta=True):
    """[bit] (e^a ^ T_a, T^a ^ T_a, e^a ^ e^b ^ R_ab, R, T): the engine's torsion and curvature, indices lowered with eta = sq (eta=False: no eta, a control)"""
    Fm = Gv.Fm; sq = Gv.L.sq if eta else [1] * Gv.n; R = Gv.curvature(om); T = Gv.torsion(om, e); eT = {}; TT = {}
    for a in range(Gv.n):
        eT = Fm.add(eT, Fm.wedge(e[a], T[a]), sq[a]); TT = Fm.add(TT, Fm.wedge(T[a], T[a]), sq[a])
    return eT, TT, holst(Gv, e, R, eta), R, T
def eps_R_ee(Gv, e, R):
    """[bit] eps_{abcd} R^{ab} ^ e^c ^ e^d over all indices (n = 4) = 4 sum_{A, c<d} eps(a,b,c,d) R^A e^c e^d  (= the dual of the Holst term, eps e e R)"""
    Fm = Gv.Fm; tot = {}
    for A, (a, b) in enumerate(pairs_of(Gv.L)):
        for (c, d) in itertools.combinations(range(Gv.n), 2):
            s = Gv.eps([a, b, c, d]) if len({a, b, c, d}) == 4 else 0
            if s and R[A]: tot = Fm.add(tot, Fm.wedge(R[A], Fm.wedge(e[c], e[d])), 4 * s)
    return tot

# ------------------------------------------------------------------------------------------------ exact linear algebra on form coefficients
def coef_rows(target, pieces):
    keys = sorted({(m, k) for X in [target] + list(pieces) for m, p in X.items() for k in p})
    v = lambda X, m, k: X.get(m, {}).get(k, F(0))
    return [[v(P, m, kk) for P in pieces] for (m, kk) in keys], [v(target, m, kk) for (m, kk) in keys]
def fit(target, pieces):
    """exact least-squares-free fit target = sum w_i pieces_i over every polynomial coefficient: (w or None, rank, nvar, consistent)"""
    rows, rhs = coef_rows(target, pieces)
    return solve_exact(rows, rhs) if rows else ([F(0)] * len(pieces), 0, len(pieces), True)
def eqf(Fm, X, Y): return all(not p for p in Fm.add(X, Y, -1).values())
def iszero(X): return all(not p for p in X.values())
def ranks_split(rows, split):
    """exact Gaussian elimination column by column: (rank of the first `split` columns, rank of all columns)"""
    M = [r[:] for r in rows if any(r)]; rk = 0; r1 = None; nc = len(rows[0]) if rows else 0
    for c in range(nc):
        if c == split: r1 = rk
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; piv = M[rk]; inv = 1 / piv[c]
        for i in range(rk + 1, len(M)):
            if M[i][c] != 0:
                f = M[i][c] * inv; M[i] = M[i][:c] + [x - f * y for x, y in zip(M[i][c:], piv[c:])]
        rk += 1
    return (rk if r1 is None else r1), rk
P_MOD = 2147483647
def nullity_mod_p(cols):
    """nullity of the coefficient matrix of the forms in cols, computed modulo the prime 2^31 - 1 (an upper bound of the rational nullity)"""
    keys = sorted({(m, k) for X in cols for m, p in X.items() for k in p}); idx = {key: i for i, key in enumerate(keys)}
    M = np.zeros((len(keys), len(cols)), dtype=np.int64)
    for j, X in enumerate(cols):
        for m, p in X.items():
            for k, v in p.items(): M[idx[(m, k)], j] = (v.numerator % P_MOD) * pow(v.denominator % P_MOD, P_MOD - 2, P_MOD) % P_MOD
    r = 0
    for c in range(M.shape[1]):
        nz = np.nonzero(M[r:, c])[0]
        if len(nz) == 0: continue
        p = r + int(nz[0])
        if p != r: M[[r, p]] = M[[p, r]]
        M[r] = (M[r] * pow(int(M[r, c]), P_MOD - 2, P_MOD)) % P_MOD
        f = M[r + 1:, c].copy(); M[r + 1:] = (M[r + 1:] - (f[:, None] * M[r][None, :]) % P_MOD) % P_MOD
        r += 1
        if r == M.shape[0]: break
    return M.shape[1] - r
def fmt(w): return 'None' if w is None else '(' + ', '.join(str(x) for x in w) + ')'

# ------------------------------------------------------------------------------------------------ [std] numpy route: never touches the engine (exported)
ETA4 = np.array([1., -1., -1., -1.])
def levi(n):
    L = np.zeros((n,) * n)
    for p in itertools.permutations(range(n)):
        s = 1
        for i in range(n):
            for j in range(i + 1, n):
                if p[i] > p[j]: s = -s
        L[p] = s
    return L
LC4 = levi(4)
class NPoly:
    """a polynomial dict {exponents: Fraction} evaluated in floats, with its gradient (own code)"""
    def __init__(self, p, n):
        keys = list(p); self.n = n
        self.E = np.array([k[:n] for k in keys], dtype=float).reshape(len(keys), n); self.c = np.array([float(p[k]) for k in keys])
    def val(self, x): return float(self.c @ np.prod(np.power(x[None, :], self.E), axis=1)) if len(self.c) else 0.0
    def grad(self, x):
        g = np.zeros(self.n)
        for mu in range(self.n):
            m = self.E[:, mu] > 0
            if not m.any(): continue
            E2 = self.E[m].copy(); E2[:, mu] -= 1
            g[mu] = float((self.c[m] * self.E[m, mu]) @ np.prod(np.power(x[None, :], E2), axis=1))
        return g
class StdFields:
    """[std] so(1,3) matrices from the raw data: Om[mu]^a_b = omega^{ab}_mu eta_bb; textbook R_{mu nu} = d_mu Om_nu - d_nu Om_mu + [Om_mu, Om_nu]; T = de + Om e"""
    def __init__(self, W, E=None, n=4):
        self.n = n; self.W = {ab: [NPoly(p, n) for p in comps] for ab, comps in W.items()}
        self.E = [[NPoly(p, n) for p in row] for row in E] if E is not None else None
    def conn(self, x):
        n = self.n; Wv = np.zeros((n, n, n)); dW = np.zeros((n, n, n, n))                 # Wv[a,b,mu], dW[a,b,nu,mu] = d_nu omega^{ab}_mu
        for (a, b), comps in self.W.items():
            for mu, P in enumerate(comps):
                v = P.val(x); g = P.grad(x); Wv[a, b, mu] = v; Wv[b, a, mu] = -v; dW[a, b, :, mu] = g; dW[b, a, :, mu] = -g
        Om = np.einsum('abm,b->mab', Wv, ETA4); dOm = np.einsum('abnm,b->nmab', dW, ETA4)  # Om[mu], dOm[nu][mu] = d_nu Om_mu
        return Om, dOm
    def curv(self, Om, dOm):
        n = self.n; Rm = np.zeros((n, n, n, n))
        for m in range(n):
            for v in range(n): Rm[m, v] = dOm[m, v] - dOm[v, m] + Om[m] @ Om[v] - Om[v] @ Om[m]
        return Rm                                                                            # Rm[mu, nu] = (R_{mu nu})^a_b
    def frame(self, x):
        n = self.n; e = np.zeros((n, n)); de = np.zeros((n, n, n))                           # e[a, mu], de[nu, a, mu]
        for a in range(n):
            for mu in range(n): e[a, mu] = self.E[a][mu].val(x); de[:, a, mu] = self.E[a][mu].grad(x)
        return e, de
def std_pont(Rm): return 0.25 * np.einsum('mnrs,mnab,rsba->', LC4, Rm, Rm)                     # tr(R ^ R), coefficient of dx^0123
def std_Rup(Rm): return np.einsum('mnab,b->abmn', Rm, ETA4)                                  # R^{ab}_{mu nu}
def std_euler_pf(Rm):
    U = std_Rup(Rm); w = lambda X, Y: 0.25 * np.einsum('mnrs,mn,rs->', LC4, X, Y)
    return 8 * (w(U[0, 1], U[2, 3]) - w(U[0, 2], U[1, 3]) + w(U[0, 3], U[1, 2]))           # 8 Pf(R^{..})
def std_euler_eps(Rm): U = std_Rup(Rm); return 0.25 * np.einsum('mnrs,abcd,abmn,cdrs->', LC4, LC4, U, U)
TRIPLES = list(itertools.combinations(range(4), 3))
def std_cs_tr(Om, dOm, coef):
    """tr(omega ^ d omega + coef omega^3): coefficients on dx^{mu nu rho}, mu < nu < rho"""
    dw = lambda v, r: dOm[v, r] - dOm[r, v]; out = {}
    for (m, v, r) in TRIPLES:
        out[(m, v, r)] = (np.trace(Om[m] @ dw(v, r)) - np.trace(Om[v] @ dw(m, r)) + np.trace(Om[r] @ dw(m, v))
                          + coef * 3 * (np.trace(Om[m] @ Om[v] @ Om[r]) - np.trace(Om[m] @ Om[r] @ Om[v])))
    return out
def std_cs_euler(Om, dOm, coef):
    """eps_{abcd} omega^{ab} ^ (d omega^{cd} + coef (omega ^ omega)^{cd}) on dx^{mu nu rho}"""
    up = lambda M: M * ETA4[None, :]; Wup = [up(Om[m]) for m in range(4)]
    beta = lambda v, r: up(dOm[v, r] - dOm[r, v] + coef * (Om[v] @ Om[r] - Om[r] @ Om[v]))
    c = lambda X, Y: np.einsum('abcd,ab,cd->', LC4, X, Y); out = {}
    for (m, v, r) in TRIPLES: out[(m, v, r)] = c(Wup[m], beta(v, r)) - c(Wup[v], beta(m, r)) + c(Wup[r], beta(m, v))
    return out
STENCIL7 = [(-3, -1.), (-2, 9.), (-1, -45.), (1, 45.), (2, -9.), (3, 1.)]                    # f'(0) = sum w f(k h) / (60 h): exact for degree <= 6
def std_d3(Cfun, x, h=0.2):
    """d of a 3-form given pointwise (dict of sorted triples): coefficient of dx^0123 = d0 C123 - d1 C023 + d2 C013 - d3 C012"""
    tot = 0.0
    for s, tri, sg in ((0, (1, 2, 3), 1), (1, (0, 2, 3), -1), (2, (0, 1, 3), 1), (3, (0, 1, 2), -1)):
        der = 0.0
        for k, w in STENCIL7:
            xx = x.copy(); xx[s] += k * h; der += w * Cfun(xx)[tri]
        tot += sg * der / (60 * h)
    return tot
def std_ny(SF, x):
    """(e^a ^ T_a 3-form, T^a ^ T_a, e^a ^ e^b ^ R_ab) at x, textbook T = de + Om e"""
    Om, dOm = SF.conn(x); Rm = SF.curv(Om, dOm); e, de = SF.frame(x); n = 4
    T = np.zeros((n, n, n))
    for m in range(n):
        for v in range(n): T[:, m, v] = de[m, :, v] - de[v, :, m] + Om[m] @ e[:, v] - Om[v] @ e[:, m]
    eT = {(m, v, r): float(np.sum(ETA4 * (e[:, m] * T[:, v, r] - e[:, v] * T[:, m, r] + e[:, r] * T[:, m, v]))) for (m, v, r) in TRIPLES}
    TT = 0.25 * np.einsum('mnrs,a,amn,ars->', LC4, ETA4, T, T)
    EE = np.einsum('am,bn->abmn', e, e); EE = EE - EE.transpose(0, 1, 3, 2)
    eeR = 0.25 * np.einsum('mnrs,a,abmn,rsab->', LC4, ETA4, EE, Rm)
    return eT, TT, eeR, T
def ev(p, x):
    return float(sum(float(c) * np.prod([x[i] ** k for i, k in enumerate(ex)]) for ex, c in p.items()))
def close(a, b, scale): return abs(a - b) <= 1e-9 * max(1.0, scale)
PTS = [np.array(v) for v in ((0.3, -0.2, 0.5, 0.1), (-0.4, 0.25, 0.15, -0.35), (0.1, 0.45, -0.3, 0.2))]

# ================================================================================================ part 1: Chern-Simons, Lie language
def part1():
    t0 = time.time(); n = 4; Gv = Grav(n, Lie(LOR(n))); Fm = Gv.Fm
    head('1. Chern-Simons forms in the engine (f table), n = 4: k(R, R) = d k(omega, a d omega + x Q), Q = f omega omega (R = d omega + Q/4); random omega (seed 1 degree 2, seed 2 degree 1), no torsion condition')
    out = {}
    for seed in (1, 2):
        rng = random.Random(600 + seed); W = rand_conn_data(rng, n, DEG[seed]); om = eng_conn(Gv, W); pc = Pieces(Gv, om); out[seed] = (W, om, pc)
        for kind, name in (('E', 'Euler eps_{abcd} R^{ab} R^{cd}'), ('P', 'Pontryagin R^{ab} R_{ab}')):
            k = kform(Gv, kind); tgt = pc.comb(k, 'RR'); w, rk, nv, cons = fit(tgt, [pc.comb(k, 'WdW'), pc.comb(k, 'WQ')])
            chk('bit', cons and rk == 2 and w == [1, F(1, 6)], 'seed %d %s: exact fit (a, x) = %s, rank %d of 2 (predicted (1, 1/6) = textbook 2/3 times the engine 1/4)' % (seed, name, fmt(w), rk))
            cs = cs_form(Gv, k, om, F(1, 6), Q=pc.Q); dcs = Fm.d(cs)
            chk('bit', not iszero(tgt) and eqf(Fm, dcs, tgt), 'seed %d %s = d CS exactly (CS assembled as a 3-form, the engine d applied; %d monomials in the 4-form)' % (seed, name, sum(len(p) for p in tgt.values())))
            chk('ctl', not eqf(Fm, Fm.d(cs_form(Gv, k, om, F(1, 8), Q=pc.Q)), tgt), 'seed %d %s: cubic coefficient 1/8 (textbook 2/3 -> 1/2) is not exact' % (seed, name))
            chk('bit', iszero(kpair(Gv, k, pc.Q, pc.Q)), 'seed %d %s: the quartic term k(Q, Q) vanishes (no quartic term in CS)' % (seed, name))
        kE = kform(Gv, 'Eucl'); w, rk, nv, cons = fit(pc.comb(kE, 'RR'), [pc.comb(kE, 'WdW'), pc.comb(kE, 'WQ')])
        chk('ctl', not cons, 'seed %d Euclidean contraction sum R^{ab} R^{ab} on the Lorentz algebra: no (a, x) makes it exact (fit inconsistent: %s)' % (seed, not cons))
        chk('ctl', not iszero(kpair(Gv, kE, pc.Q, pc.Q)), 'seed %d Euclidean contraction: quartic term k(Q, Q) is not zero' % seed)
    tick(t0, 'part 1'); return Gv, out

# ================================================================================================ part 2: the space of exact k(R,R)
def kvec(Gv, k):
    v = []
    for A in range(Gv.G):
        for B in range(A, Gv.G): v.append(k.get((A, B), F(0)))
    return v
def kspace_cols(Gv, pcs):
    """columns for unknowns (k_AB, m_AB), A <= B, symmetric; each column is the stack over the connections of k(R,R) - d k(omega, d omega) resp. - d m(omega, Q)"""
    G = Gv.G; Fm = Gv.Fm; kc = []; mc = []
    for A in range(G):
        for B in range(A, G):
            kb = {(A, B): F(1), (B, A): F(1)} if A < B else {(A, A): F(1)}
            kcol = {}; mcol = {}
            for i, pc in enumerate(pcs):                     # stack: shift the mask by the connection index so the rows stay apart
                a = Fm.add(pc.comb(kb, 'RR'), pc.comb(kb, 'WdW'), -1); b = Fm.scale(pc.comb(kb, 'WQ'), -1)
                for m, p in a.items(): kcol[(i, m)] = p
                for m, p in b.items(): mcol[(i, m)] = p
            kc.append(kcol); mc.append(mcol)
    return kc + mc
def residual(cols, v):
    tot = {}
    for c, X in zip(v, cols):
        if c == 0: continue
        for m, p in X.items(): tot[m] = b1lib.lin((1, tot.get(m, {})), (c, p))
    return {m: p for m, p in tot.items() if p}
def part2(Gv, data):
    t0 = time.time(); Fm = Gv.Fm; pc = data[1][2]; G = Gv.G
    head('2. All symmetric (k, m) with k(R,R) = d[k(omega, d omega) + m(omega, Q)] (21 + 21 unknowns), seed 1 (degree 2): exact ranks')
    cols = kspace_cols(Gv, [pc]); kc, mc = cols[:len(cols) // 2], cols[len(cols) // 2:]
    keys = sorted({(m, k) for X in cols for m, p in X.items() for k in p})
    rows = [[X.get(m, {}).get(kk, F(0)) for X in mc + kc] for (m, kk) in keys]                     # m-columns first: one elimination gives both ranks
    rm, rall = ranks_split(rows, len(mc)); nul_all = len(cols) - rall; nul_m = len(mc) - rm
    m3 = []
    for A in range(G):
        for B in range(A, G):
            kb = {(A, B): F(1), (B, A): F(1)} if A < B else {(A, A): F(1)}; m3.append(pc.comb(kb, 'WQ3'))
    k3 = sorted({(m, k) for X in m3 for m, p in X.items() for k in p}); r3 = ranks_split([[X.get(m, {}).get(kk, F(0)) for X in m3] for (m, kk) in k3], len(m3))[1]
    vP = kvec(Gv, kform(Gv, 'P')); vE = kvec(Gv, kform(Gv, 'E')); vU = kvec(Gv, kform(Gv, 'Eucl'))
    sixth = lambda v: v + [x / 6 for x in v]
    inP = not residual(cols, sixth(vP)); inE = not residual(cols, sixth(vE)); indep = rank_exact([vP, vE]) == 2
    chk('bit', nul_all - nul_m == 2 and inP and inE and indep,
        'nullity of (k, m) = %d (rank %d, %d rows); with k = 0 alone: %d; so the k-part is %d-dimensional, and (k_P, k_P/6), (k_E, k_E/6) are null vectors (%s, %s): k-part = span(Pontryagin, Euler)' % (nul_all, rall, len(rows), nul_m, nul_all - nul_m, inP, inE))
    chk('bit', nul_m == len(m3) - r3, 'the %d directions with k = 0 are m with m(omega, Q) = 0 identically (nullity of the undifferentiated 3-forms m(omega, Q) is also %d); so m = k/6 up to a cubic term that vanishes' % (nul_m, len(m3) - r3))
    chk('ctl', bool(residual(cols, sixth(vU))) and rank_exact([vP, vE, vU]) == 3, 'the Euclidean contraction: (k_Eucl, k_Eucl/6) is not a null vector and k_Eucl is not in span(k_P, k_E), so no m makes it exact')
    tick(t0, 'part 2')

# ================================================================================================ part 3: the textbook formula with the engine's vector matrices (h table)
def part3(Gv, data):
    t0 = time.time(); Fm = Gv.Fm; n = 4; sq = Gv.L.sq
    head('3. Textbook formula with the engine vector matrices omega^c_b = h_Ab^c omega^A, R^c_b = h_Ab^c R^A: tr(R R) = d tr(z omega d omega + y omega^3); eps R R = d eps omega (z d omega + y omega omega)')
    for seed in (1, 2):
        W, om, pc = data[seed]; Wv = vec_rep(Gv, om); Rv = vec_rep(Gv, pc.R); dWv = [[Fm.d(x) for x in row] for row in Wv]
        WW = mat_wedge(Fm, Wv, Wv); tgt = trace_wedge(Fm, Rv, Rv)
        p1 = Fm.d(trace_wedge(Fm, Wv, dWv)); p3 = Fm.d(trace_wedge(Fm, WW, Wv))
        w, rk, nv, cons = fit(tgt, [p1, p3])
        chk('bit', cons and rk == 2 and w == [1, F(2, 3)], 'seed %d tr(R ^ R): exact fit (z, y) = %s (predicted (1, 2/3))' % (seed, fmt(w)))
        chk('ctl', not eqf(Fm, Fm.add(p1, p3, F(1, 2)), tgt), 'seed %d tr: y = 1/2 is not exact' % seed)
        chk('bit', eqf(Fm, tgt, Fm.scale(pc.comb(kform(Gv, 'P'), 'RR'), -1)), 'seed %d tr(R ^ R) [h table] = - R^{ab} R_{ab} [f table]' % seed)
        up = lambda M: [[Fm.scale(M[a][b], sq[b]) for b in range(n)] for a in range(n)]            # raise the second index with eta
        Wu, WWu, Ru = up(Wv), up(WW), up(Rv); dWu = [[Fm.d(x) for x in row] for row in Wu]
        tE = eps_pairs(Gv, Ru, Ru); q1 = eps_pairs(Gv, Wu, dWu); q3 = eps_pairs(Gv, Wu, WWu)
        w, rk, nv, cons = fit(tE, [Fm.d(q1), Fm.d(q3)])
        chk('bit', cons and rk == 2 and w == [1, F(2, 3)], 'seed %d eps R R: exact fit (z, y) = %s (predicted (1, 2/3))' % (seed, fmt(w)))
        chk('bit', eqf(Fm, tE, pc.comb(kform(Gv, 'E'), 'RR')), 'seed %d eps R R [h table] = eps R R [f table]' % seed)
    tick(t0, 'part 3')

# ================================================================================================ part 4: [std] numpy, and [bit==std] at points
def part4(Gv, data):
    t0 = time.time(); Fm = Gv.Fm
    head('4. [std] numpy so(1,3) matrices (no engine): d tr(omega d omega + 2/3 omega^3) = tr(R R), d eps omega(d omega + 2/3 omega omega) = 8 Pf(R), 7-point stencils; [bit==std] at 3 points')
    for seed in (1, 2):
        W, om, pc = data[seed]; SF = StdFields(W); kP, kE = kform(Gv, 'P'), kform(Gv, 'E')
        csP = cs_form(Gv, kP, om, F(1, 6), Q=pc.Q); csE = cs_form(Gv, kE, om, F(1, 6), Q=pc.Q); rrP = pc.comb(kP, 'RR'); rrE = pc.comb(kE, 'RR')
        okP = okE = okPf = ctlP = ctlE = okR = okV = okC = ctlS = True; worst = 0.0
        for x in PTS:
            Om, dOm = SF.conn(x); Rm = SF.curv(Om, dOm); P = std_pont(Rm); Eu = std_euler_pf(Rm); sc = max(abs(P), abs(Eu), 1.0)
            dP = std_d3(lambda xx: std_cs_tr(*SF.conn(xx), 2. / 3), x); dE = std_d3(lambda xx: std_cs_euler(*SF.conn(xx), 2. / 3), x)
            okP &= close(dP, P, sc); okE &= close(dE, Eu, sc); okPf &= close(Eu, std_euler_eps(Rm), sc); worst = max(worst, abs(dP - P) / sc, abs(dE - Eu) / sc)
            ctlP &= not close(std_d3(lambda xx: std_cs_tr(*SF.conn(xx), .5), x), P, sc); ctlE &= not close(std_d3(lambda xx: std_cs_euler(*SF.conn(xx), .5), x), Eu, sc)
            U = std_Rup(Rm)
            for A, (a, b) in enumerate(pairs_of(Gv.L)):
                for (m, v) in itertools.combinations(range(4), 2): okR &= close(ev(pc.R[A].get((1 << m) | (1 << v), {}), x), U[a, b, m, v], np.abs(U).max())
            okV &= close(ev(rrP.get(15, {}), x), -P, sc) and close(ev(rrE.get(15, {}), x), Eu, sc); ctlS &= not close(ev(rrP.get(15, {}), x), P, sc)
            cP = std_cs_tr(Om, dOm, 2. / 3); cE = std_cs_euler(Om, dOm, 2. / 3); s3 = max(1.0, max(abs(v) for v in list(cP.values()) + list(cE.values())))
            for tri in TRIPLES:
                msk = sum(1 << i for i in tri); okC &= close(ev(csP.get(msk, {}), x), -cP[tri], s3) and close(ev(csE.get(msk, {}), x), cE[tri], s3)
        chk('std', okP and okE, 'seed %d: d CS_tr(2/3) = tr(R ^ R) and d CS_eps(2/3) = 8 Pf(R) at 3 points (worst relative difference %.1e)' % (seed, worst))
        chk('std', okPf, 'seed %d: 8 Pf(R^{..}) = eps_{abcd} R^{ab} R^{cd} at 3 points' % seed)
        chk('ctl', ctlP and ctlE, 'seed %d [std]: coefficient 1/2 instead of 2/3 fails both at every point' % seed)
        chk('bit==std', okR, 'seed %d: engine R^{ab}_{mu nu} = textbook R = d omega + omega omega (matrices, eta) at 3 points, all 36 components' % seed)
        chk('bit==std', okV, 'seed %d: engine R^{ab} R_{ab} = - tr(R ^ R)_std and engine eps R R = 8 Pf_std at 3 points' % seed)
        chk('bit==std', okC, 'seed %d: engine CS_P (x = 1/6) = - CS_tr,std (2/3) and engine CS_E (1/6) = CS_eps,std (2/3), all 4 components at 3 points' % seed)
        chk('ctl', ctlS, 'seed %d: engine R^{ab} R_{ab} against + tr(R ^ R)_std (sign flipped) fails' % seed)
    tick(t0, 'part 4')

# ================================================================================================ part 5: Nieh-Yan
def part5():
    t0 = time.time(); n = 4; Gv = Grav(n, Lie(LOR(n))); Fm = Gv.Fm
    head('5. Nieh-Yan, n = 4: d(e^a ^ T_a) = T^a ^ T_a - e^a ^ e^b ^ R_ab for random (e, omega) (seed 1 degree 2, seed 2 degree 1; no condition on e or T)')
    keep = {}
    for seed in (1, 2):
        rng = random.Random(700 + seed); W = rand_conn_data(rng, n, DEG[seed]); E = rand_frame_data(rng, n, DEG[seed]); om = eng_conn(Gv, W); e = eng_frame(E)
        eT, TT, eeR, R, T = nieh_yan_pieces(Gv, e, om); deT = Fm.d(eT); keep[seed] = (W, E, om, e, eT, TT, eeR, R, T)
        chk('bit', not iszero(TT) and not iszero(eeR) and eqf(Fm, deT, Fm.add(TT, eeR, -1)), 'seed %d: d(e^a T_a) = T^a T_a - e^a e^b R_ab exactly (T != 0, Holst != 0)' % seed)
        w, rk, nv, cons = fit(deT, [TT, eeR])
        chk('bit', cons and rk == 2 and w == [1, -1], 'seed %d: exact fit of the coefficients (T T, e e R) = %s (predicted (1, -1))' % (seed, fmt(w)))
        chk('ctl', not eqf(Fm, deT, Fm.add(TT, eeR, F(-1, 2))) and not eqf(Fm, deT, Fm.add(Fm.scale(TT, 2), eeR, -1)), 'seed %d: missing factor (- 1/2 e e R, or 2 T T) fails' % seed)
        eTu, TTu, eeRu, _, _ = nieh_yan_pieces(Gv, e, om, eta=False); w, rk, nv, cons = fit(Fm.d(eTu), [TTu, eeRu])
        chk('ctl', not cons, 'seed %d: Euclidean contractions (e^a T^a, T^a T^a, e^a e^b R^{ab}) on the Lorentz frame: no coefficients make it exact' % seed)
        SF = StdFields(W, E); okS = okB = True; worst = 0.0
        for x in PTS:
            seT, sTT, seeR, sT = std_ny(SF, x); d = std_d3(lambda xx: std_ny(SF, xx)[0], x); sc = max(1.0, abs(sTT), abs(seeR))
            okS &= close(d, sTT - seeR, sc); worst = max(worst, abs(d - sTT + seeR) / sc)
            okB &= close(ev(TT.get(15, {}), x), sTT, sc) and close(ev(eeR.get(15, {}), x), seeR, sc)
            s3 = max(1.0, max(abs(v) for v in seT.values()))
            for tri in TRIPLES: okB &= close(ev(eT.get(sum(1 << i for i in tri), {}), x), seT[tri], s3)
            for a in range(n):
                for (m, v) in itertools.combinations(range(4), 2): okB &= close(ev(T[a].get((1 << m) | (1 << v), {}), x), sT[a, m, v], np.abs(sT).max())
        chk('std', okS, 'seed %d [std]: textbook T = de + omega e, d(e^a T_a) (7-point stencil) = T^a T_a - e^a e^b R_ab at 3 points (worst %.1e)' % (seed, worst))
        chk('bit==std', okB, 'seed %d: engine T^a, e^a T_a, T^a T_a, e^a e^b R_ab = textbook values at 3 points' % seed)
    tick(t0, 'part 5'); return Gv, keep

# ================================================================================================ part 6: Holst
def part6(Gv, keep):
    t0 = time.time(); n = 4; Fm = Gv.Fm; sq = Gv.L.sq; S = koszul_S(n, sq, Gv.L)
    head('6. Holst term e^a ^ e^b ^ R_ab: (i) = e_a ^ (D T)^a for any (e, omega); (ii) zero at T = 0 (A3 closed form, first-order jets, random frames, at the origin and at a rational point); controls with torsion')
    for seed, (W, E, om, e, eT, TT, eeR, R, T) in keep.items():
        DT = Gv.D_vector(om, T); rhs = {}
        for c in range(n): rhs = Fm.add(rhs, Fm.wedge(e[c], DT[c]), sq[c])
        chk('bit', not iszero(eeR) and eqf(Fm, eeR, rhs), 'seed %d: e^a e^b R_ab = e_a D T^a exactly (first Bianchi D T = R e; T != 0 here)' % seed)
    rng = random.Random(800); cases = 0; okT = okH = okDual = okStd = okLink = True; ctlK = ctlS = True; dual_vals = []
    for fr in range(3):
        e0f = rand_frame(rng, n, deg=2, coef=2, density=.5)
        for pt in (None, [F(rng.randint(-3, 3), rng.randint(2, 5)) for _ in range(n)]):
            e = e0f if pt is None else translate_frame(e0f, pt, n)
            om, R = engine_om_R(Gv, e, S, n)
            with trunc(n, xdeg=1):
                T = Gv.torsion(om, e); H = holst(Gv, e, R); dual = eps_R_ee(Gv, e, R); Ea, _ = Gv.einstein(None, e, R, 0)
                eE = {}
                for a in range(n): eE = Fm.add(eE, Fm.wedge(e[a], Ea[a]))
            okT &= all(not p for c in T for p in c.values()); okH &= at0(H.get(15, {}), n) == 0
            dv = at0(dual.get(15, {}), n); okDual &= dv != 0; dual_vals.append(dv)
            okLink &= 2 * at0(eE.get(15, {}), n) == dv
            g = std_metric(e, n, sq, n, 2); Rr, g0, g0i = std_riemann(g, n, n, 1); Gm, ric, Rs = std_einstein_mixed(Rr, g0, g0i, n)
            Rl = {(k_, l, m, v): sum(g0[k_][r] * Rr[(r, l, m, v)] for r in range(n)) for k_ in range(n) for l in range(n) for m in range(n) for v in range(n)}
            hs = sum(int(LC4[p]) * Rl[p] for p in itertools.permutations(range(n)))
            okStd &= hs == 0; det = E0_of(e, n, n)[2]; okStd_d = (dv == 2 * Rs * det); okLink &= okStd_d
            K = [{1 << mu: {(0,) * n: F(rng.randint(-2, 2))} for mu in range(n) if rng.random() < .6} for _ in range(Gv.G)]
            omK = [Fm.add(om[A], K[A]) for A in range(Gv.G)]
            with trunc(n, xdeg=1): TK = Gv.torsion(omK, e); HK = holst(Gv, e, Gv.curvature(omK))
            ctlK &= any(at0(p, n) != 0 for c in TK for p in c.values()) and at0(HK.get(15, {}), n) != 0
            omS = omega_closed_form(Gv, e, S, n, 1, -1)[0]
            with trunc(n, xdeg=1): TS = Gv.torsion(omS, e); HS = holst(Gv, e, Gv.curvature(omS))
            ctlS &= any(at0(p, n) != 0 for c in TS for p in c.values()) and at0(HS.get(15, {}), n) != 0
            cases += 1
    chk('bit', okT, '%d cases (3 frames x origin and a rational point): T(omega_closed_form) = 0 through first order (every coefficient of the 1-jet)' % cases)
    chk('bit', okH, '%d cases: Holst e^a e^b R_ab = 0 at the point (T = 0)' % cases)
    chk('std', okStd, '%d cases [std]: eps^{klmn} R_{klmn} = 0 for the Riemann tensor of g = e^T eta e (Christoffel route, exact fractions)' % cases)
    chk('bit', okDual, '%d cases: the dual eps_{abcd} e^a e^b R^{cd} is NOT zero at T = 0 (values %s)' % (cases, ', '.join(str(v) for v in dual_vals[:3])))
    chk('bit==std', okLink, '%d cases: eps_{abcd} e^a e^b R^{cd} = 2 e^a ^ E_a(0) [engine E_a] = 2 R_s vol(e) [std scalar curvature, MTW sign] at the point' % cases)
    chk('ctl', ctlK, '%d cases: omega + random constant contorsion: T != 0 and Holst != 0 at the point' % cases)
    chk('ctl', ctlS, '%d cases: closed form with the wrong sign: T != 0 and Holst != 0 at the point' % cases)
    tick(t0, 'part 6')

# ================================================================================================ part 7: MacDowell-Mansouri expansion
def part7():
    t0 = time.time(); n = 4; Gv = Grav(n, Lie(LOR(n))); Fm = Gv.Fm
    head('7. MacDowell-Mansouri at n = 4: eps F F (B1 lag_MM) = eps R R + 2c eps R e e + c^2 eps e e e e as 4-forms; eps R R = d CS_E; random (e, omega) of degree 1')
    for seed in (1, 2):
        rng = random.Random(900 + seed); om = eng_conn(Gv, rand_conn_data(rng, n, 1)); e = eng_frame(rand_frame_data(rng, n, 1))
        R = Gv.curvature(om); kE = kform(Gv, 'E'); eRR = kpair(Gv, kE, R, R); eRee = eps_R_ee(Gv, e, R)
        e4 = {}
        for p in itertools.permutations(range(n)): e4 = Fm.add(e4, wedge_list(Fm, [e[i] for i in p]), Gv.eps(list(p)))
        vol = wedge_list(Fm, e); LR = lag_EC(Gv, e, om, 0); Ea, _ = Gv.einstein(None, e, R, 0); eE = {}
        for a in range(n): eE = Fm.add(eE, Fm.wedge(e[a], Ea[a]))
        chk('bit', eqf(Fm, e4, Fm.scale(vol, 24)) and eqf(Fm, eRee, Fm.scale(LR, 4)) and eqf(Fm, eE, Fm.scale(eRee, F(1, 2))),
            'seed %d: eps e e e e = 24 vol(e); eps R e e = 4 L_R (B1 lag_EC); e^a ^ E_a(0) (engine E_a) = (1/2) eps R e e' % seed)
        dcs = Fm.d(cs_form(Gv, kE, om, F(1, 6)))
        chk('bit', eqf(Fm, dcs, eRR), 'seed %d: eps R R = d CS_E (x = 1/6) on this connection' % seed)
        ok = okc = ok2 = ctl2 = True
        for c in (F(1), F(-2, 3), F(5, 7)):
            L = lag_MM(Gv, e, om, c)
            ok &= eqf(Fm, L, Fm.add(Fm.add(eRR, eRee, 2 * c), e4, c * c)); okc &= not eqf(Fm, L, Fm.add(Fm.add(eRR, eRee, c), e4, c * c))
            ok2 &= eqf(Fm, Fm.add(L, dcs, -1), Fm.add(Fm.scale(LR, 8 * c), vol, 24 * c * c)); ctl2 &= not eqf(Fm, Fm.add(L, dcs, -1), Fm.add(Fm.scale(LR, 8 * c), vol, 12 * c * c))
        chk('bit', ok, 'seed %d: eps F F = eps R R + 2c eps R e e + c^2 eps e e e e, c = 1, -2/3, 5/7 (quadratic in c: three values fix it)' % seed)
        chk('bit', ok2, 'seed %d: eps F F - d CS_E = 8c L_R + 24 c^2 vol(e), c = 1, -2/3, 5/7' % seed)
        chk('ctl', okc and ctl2, 'seed %d: cross term c instead of 2c fails; 12 c^2 vol instead of 24 c^2 vol fails' % seed)
    tick(t0, 'part 7')

# ================================================================================================ part 8: other dimensions
def part8():
    t0 = time.time()
    head('8. Other dimensions: the 4-form identities at n = 5 (degree-1 fields); the space of exact k(R,R) at n = 5; Euler at n = 2')
    n = 5; Gv = Grav(n, Lie(LOR(n))); Fm = Gv.Fm; rng = random.Random(1000)
    W = rand_conn_data(rng, n, 1, .4); om = eng_conn(Gv, W); e = eng_frame(rand_frame_data(rng, n, 1, .4)); pc = Pieces(Gv, om); kP = kform(Gv, 'P')
    tgt = pc.comb(kP, 'RR'); w, rk, nv, cons = fit(tgt, [pc.comb(kP, 'WdW'), pc.comb(kP, 'WQ')])
    chk('bit', cons and rk == 2 and w == [1, F(1, 6)] and eqf(Fm, Fm.d(cs_form(Gv, kP, om, F(1, 6), Q=pc.Q)), tgt), 'n = 5: R^{ab} R_{ab} = d CS_P, fit (a, x) = %s, 5 components of the 4-form' % fmt(w))
    cols = kspace_cols(Gv, [pc]); nul = nullity_mod_p(cols); vP = kvec(Gv, kP); inP = not residual(cols, vP + [x / 6 for x in vP])
    chk('bit', nul == 1 and inP, 'n = 5: nullity of (k, m) is %d (mod 2^31-1, an upper bound) and (k_P, k_P/6) is an exact null vector -> exactly 1: no Euler-type bilinear form (110 unknowns)' % nul)
    eT, TT, eeR, R, T = nieh_yan_pieces(Gv, e, om); DT = Gv.D_vector(om, T); rhs = {}
    for c in range(n): rhs = Fm.add(rhs, Fm.wedge(e[c], DT[c]), Gv.L.sq[c])
    chk('bit', not iszero(TT) and eqf(Fm, Fm.d(eT), Fm.add(TT, eeR, -1)) and eqf(Fm, eeR, rhs), 'n = 5: Nieh-Yan d(e^a T_a) = T^a T_a - e^a e^b R_ab and Holst e^a e^b R_ab = e_a D T^a hold as 4-form identities (not top forms)')
    n2 = 2; G2 = Grav(n2, Lie(LOR(n2))); Fm2 = G2.Fm; om2 = eng_conn(G2, rand_conn_data(random.Random(1001), n2, 3)); R2 = G2.curvature(om2)
    chk('bit', not G2.L.f and eqf(Fm2, Fm2.scale(R2[0], 2), Fm2.d(Fm2.scale(om2[0], 2))) and not iszero(R2[0]), 'n = 2: so(1,1) has no structure constants; eps_{ab} R^{ab} = 2 R^{01} = d(2 omega^{01}) (degree-3 omega)')
    tick(t0, 'part 8')

def main():
    T0 = time.time()
    Gv, data = part1(); part2(Gv, data); part3(Gv, data); part4(Gv, data)
    Gv5, keep = part5(); part6(Gv5, keep); part7(); part8()
    print('\ntotal time: %.1f s' % (time.time() - T0)); finish('A6')

if __name__ == '__main__': main()
