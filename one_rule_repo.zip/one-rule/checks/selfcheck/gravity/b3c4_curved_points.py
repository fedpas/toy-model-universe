#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""B3C4-curved: the solved Einstein-scalar cosmology away from the spatial origin of the isotropic chart, and an exponential potential.
   python3 b3c4_curved_points.py

 n = 4, (+,-,-,-), exact fractions, polynomials in 5 slots (slot 0 = t - t0, slots 1..3 = delta = x - x0, slot 4 = lam of the frame variation).
 Frame e^0 = dt, e^i = a(t) f(x) dx^i with f = 1/(1 + k r^2/4) (k = 0, +1, -1), phi = phi(t), V a polynomial.
 (A) The series a(t), phi(t) solved at the spatial origin (b3c4_scalar_frw.engine_solve: space equation and Klein-Gordon at orders 0..N-2, the 00
     equation imposed at t = 0 through c) satisfy the engine's equations at rational points x0 != 0 of the chart when the frame about x0 carries
     the EXACT Taylor jet of f (spatial order 2; order 3 where D E_a is taken): the 16 components of X_a = E_a(c) - kappa tau_a and EL_phi vanish
     through t^(N-2), the 00 component included.  k = 0 is the trivial case (f = 1).
 (B) The exponential potential V = V0 exp(-lam phi), as its Taylor polynomial in phi cut at degree N, has the power-law solution a = t^p,
     phi = (2/lam) ln t about t0 = 1; p and V0 are derived in the script from the three equations (no engine), and the engine's series from
     (a0, a1, phi0, phi1) = (1, p, 0, 2/lam) equals the Taylor series of that closed form.
 [bit] the engine: A3 omega (rotation part non-zero at x0), curvature, Einstein form, B3 matter variation and Euler-Lagrange form, D_covector.
 [std] own polynomial Christoffel route at x0 (metric, inverse by a Neumann series, Christoffel symbols, Riemann, Ricci, mixed Einstein tensor
       as series in t; no engine), the textbook Friedmann-Klein-Gordon recursion of b3c4_scalar_frw, the closed form of (B).
 Controls: the truncated polynomial frame 1 - k r^2/4 at x0 (non-zero residual: the exact jet is needed), the frame of the other k with the same
       series, the wrong sign of the potential, a wrong exponent p.
 Scope: k = 0, +1, -1; two rational points per k (one with all three coordinates non-zero and k r^2 of order one); series to order 10 (residuals
       through t^8); local in t (no convergence radius, no late-time statement); kappa and the sign of the source are inputs, c is the
       convention-bound constant of the 00 equation.
 Exports (no engine object at import): pm2, u_poly, f_jet, fpoly_jet, frame_at, engine_eval_at, std_G_series, std_N_series, exp_scaling, binom_series."""
import os, sys, time, random, math
_here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _here)
from b1lib import *
import b3c4_scalar_frw as BS
import c4_frw as C4

n = 4; NV = 5; SQ = LORENTZ(4); FULL = 15
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ plain polynomials with separate bounds (no engine)
def pm2(a, b, Kt, Ks):
    """product of 5-slot polynomials keeping t-degree <= Kt and spatial degree <= Ks (exact for the kept monomials)"""
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            if k1[0] + k2[0] > Kt or k1[1] + k1[2] + k1[3] + k2[1] + k2[2] + k2[3] > Ks: continue
            k = tuple(x + y for x, y in zip(k1, k2)); x = r.get(k, 0) + v1 * v2
            if x == 0: r.pop(k, None)
            else: r[k] = x
    return r
def u_poly(x0):
    """2 x0.delta + |delta|^2 (so that r^2 = r0^2 + u about x0)"""
    u = {}
    for i in (1, 2, 3):
        u = padd(u, var(NV, i), 2 * F(x0[i - 1])); u = padd(u, pm2(var(NV, i), var(NV, i), 0, 2))
    return u
def f_jet(x0, k, Ks):
    """exact Taylor jet of f = 1/(1 + k r^2/4) about x0 to spatial order Ks: f = sum_j (-1)^j u^j / g0^(j+1), g0 = 1 + k r0^2/4, u = k (2 x0.delta + |delta|^2)/4"""
    g0 = 1 + F(k) * sum(F(v) ** 2 for v in x0) / 4; u = scale(u_poly(x0), F(k, 4))
    f = const(NV, 1 / g0); pw = const(NV, 1)
    for j in range(1, Ks + 1):
        pw = pm2(pw, u, 0, Ks); f = padd(f, pw, F((-1) ** j) / g0 ** (j + 1))
    return f
def fpoly_jet(x0, k):
    """the truncated polynomial 1 - k r^2/4 re-expanded about x0 (exact polynomial; the frame of c4_frw away from the origin)"""
    return padd(const(NV, 1 - F(k) * sum(F(v) ** 2 for v in x0) / 4), u_poly(x0), -F(k, 4))
def frame_at(ac, k, x0, Ks, fp=None):
    """e^0 = dt, e^i = a(t) f dx^i with f the exact jet about x0 (or the polynomial fp)"""
    a = C4.poly_t([F(x) for x in ac], NV); f = f_jet(x0, k, Ks) if fp is None else fp
    return [{1: const(NV, 1)}] + [{1 << i: pm2(a, f, 10 ** 6, Ks)} for i in (1, 2, 3)]
def engine_eval_at(Gv, S, ac, pc, vc, kap, c, k, K, x0, Ks=2, fp=None, sE=0):
    """[bit] X_a = E_a(c) - kappa tau_a and EL_phi at x0 through t-order K (omega to spatial order 1 + sE, E_a to spatial order sE)"""
    Fm = Gv.Fm; e = frame_at(ac, k, x0, Ks, fp); phi = C4.poly_t([F(x) for x in pc], NV)
    om, Ea = BS.engine_grav(Gv, S, e, c, K, k, sE); tau, EL = BS.engine_matter(Gv, e, phi, vc, K)
    X = [Fm.add(Ea[a], tau[a], -F(kap)) for a in range(4)]
    return dict(e=e, phi=phi, om=om, Ea=Ea, tau=tau, EL=EL, X=X, K=K)

# ------------------------------------------------------------------------------------------------ [std] Christoffel route at x0 as series in t (no engine)
def std_G_series(ac, f, K, Ks=2):
    """mixed Einstein tensor G^mu_nu at delta = 0 as series in t through t^K for g = diag(1, -a^2 f^2, -a^2 f^2, -a^2 f^2) (plain polynomials):
       metric exact through t^(K+2) and spatial order Ks; Christoffel symbols; R^r_{smv} = d_m Gam^r_{vs} - d_v Gam^r_{ms} + Gam Gam - Gam Gam; Ricci; scalar"""
    Kt = K + 2; a = C4.poly_t([F(x) for x in ac], NV); af2 = pm2(pm2(a, f, Kt, Ks), pm2(a, f, Kt, Ks), Kt, Ks)
    c0 = at0(af2, NV); w = scale(padd(af2, const(NV, c0), -1), 1 / c0); inv = const(NV, 1); pw = const(NV, 1)
    for j in range(1, Kt + Ks + 1):
        pw = pm2(pw, w, Kt, Ks)
        if not pw: break
        inv = padd(inv, pw, F((-1) ** j))
    inv = scale(inv, 1 / c0)
    g = {(0, 0): const(NV, 1)}; gi = {(0, 0): const(NV, 1)}
    for i in (1, 2, 3): g[(i, i)] = scale(af2, -1); gi[(i, i)] = scale(inv, -1)
    G_ = lambda m_, n_: g.get((m_, n_), {})
    Gam = {}
    for l in range(4):
        for m_ in range(4):
            for n_ in range(4):
                t = padd(padd(sp_der(G_(l, n_), m_), sp_der(G_(l, m_), n_)), sp_der(G_(m_, n_), l), -1)
                Gam[(l, m_, n_)] = scale(pm2(gi[(l, l)], t, Kt, Ks), F(1, 2)) if t else {}
    at_x0 = lambda p: BS.tser({(key[0], 0, 0, 0, 0): v for key, v in p.items() if key[1] == key[2] == key[3] == 0}, K)
    ric = {}
    for s in range(4):
        for v in range(4):
            t = {}
            for r in range(4):
                t = padd(t, sp_der(Gam[(r, v, s)], r)); t = padd(t, sp_der(Gam[(r, r, s)], v), -1)
                for l in range(4):
                    if Gam[(r, r, l)] and Gam[(l, v, s)]: t = padd(t, pm2(Gam[(r, r, l)], Gam[(l, v, s)], Kt, Ks))
                    if Gam[(r, v, l)] and Gam[(l, r, s)]: t = padd(t, pm2(Gam[(r, v, l)], Gam[(l, r, s)], Kt, Ks), -1)
            ric[(s, v)] = at_x0(t)
    gi0 = {key: at_x0(p) for key, p in gi.items()}
    Rs = [F(0)] * (K + 1)
    for s in range(4): Rs = [x + y for x, y in zip(Rs, BS.smul(gi0[(s, s)], ric[(s, s)], K))]
    G = {}
    for m_ in range(4):
        for v in range(4):
            t = BS.smul(gi0[(m_, m_)], ric[(m_, v)], K)
            if m_ == v: t = [x - y / 2 for x, y in zip(t, Rs)]
            G[(m_, v)] = t
    return G
def std_N_series(ac, pc, vc, kap, c, k, x0, K):
    """[std] N^b_a = G^b_a - 3c delta - kappa T^b_a at x0 as series through t^K, T = diag(rho, -p, -p, -p), rho = phi'^2/2 + V, p = phi'^2/2 - V"""
    G = std_G_series(ac, f_jet(x0, k, 2), K)
    p1 = BS.sder(BS.pad([F(x) for x in pc], K + 2), K + 1); kin = [x / 2 for x in BS.smul(p1, p1, K)]; V = BS.spoly([F(x) for x in vc], BS.pad([F(x) for x in pc], K + 1), K)
    rho = [x + y for x, y in zip(kin, V)]; pr = [x - y for x, y in zip(kin, V)]
    N = {}
    for b in range(4):
        for a in range(4):
            t = list(G[(b, a)])
            if a == b:
                t[0] -= 3 * F(c); T = rho if a == 0 else [-x for x in pr]
                t = [x - F(kap) * y for x, y in zip(t, T)]
            N[(b, a)] = t
    return N
def comp_from_N(N, ac, f0, K):
    """the engine's component layout from N: comp[(a, mu)] = -det (-1)^mu N^mu_a E^mu_mu with det = a^3 f0^3, E = diag(1, 1/(a f0), ...)"""
    a = BS.pad([F(x) for x in ac], K); a2 = BS.smul(a, a, K); a3 = BS.smul(a2, a, K); out = {}
    for a_ in range(4):
        for mu in range(4):
            fac = [-F(f0) ** 3 * x for x in a3] if mu == 0 else [-F((-1) ** mu) * F(f0) ** 2 * x for x in a2]
            out[(a_, mu)] = BS.smul(fac, N[(mu, a_)], K)
    return out

# ------------------------------------------------------------------------------------------------ [std] the exponential potential: the power-law solution derived from the equations
def exp_scaling(kap, lam):
    """a = t^p, phi = (2/lam) ln t + phi_c, V = V0 exp(-lam phi) = W t^-2 (c = 0, k = 0): W(p) from Klein-Gordon at order t^-2, p from the Friedmann
       equation as a quadratic in p (constant term 0: p = 0 is the trivial root), the ii equation checked at p.  phi_c = 0 so that V0 = W."""
    kap, lam = F(kap), F(lam)
    W = [-2 / lam ** 2, 6 / lam ** 2]                                           # KG: -2/lam + 6p/lam - lam W = 0  ->  W = W[0] + W[1] p
    q = [-kap * (2 / lam ** 2 + W[0]), -kap * W[1], F(3)]                       # Friedmann: 3p^2 - kap (2/lam^2 + W(p)) = q[0] + q[1] p + q[2] p^2 = 0
    p = -q[1] / q[2]; V0 = W[0] + W[1] * p
    ii = 2 * p * (p - 1) + p * p + kap * (2 / lam ** 2 - V0)                    # ii: 2a''/a + H^2 + kappa (phi'^2/2 - V) = 0 at order t^-2
    return p, V0, q[0], ii
def binom_series(p, N):
    out = [F(1)]
    for j in range(1, N + 1): out.append(out[-1] * (F(p) - j + 1) / j)
    return out
def exp_vc(V0, lam, N): return [F(V0) * (-F(lam)) ** j / math.factorial(j) for j in range(N + 1)]

# ================================================================================================ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    rng = random.Random(9)
    rq = lambda lo=-9, hi=9, d=5: F(rng.randint(lo, hi), rng.randint(1, d))
    Z = lambda L: all(x == 0 for x in L)
    allz = lambda comp, kg: all(Z(v) for v in comp.values()) and Z(kg)
    PTS = {1: [(F(1), F(1, 2), F(2)), (F(0), F(0), F(1, 2))], -1: [(F(1, 2), F(1, 3), F(1)), (F(0), F(1, 2), F(0))]}
    fval = lambda x0, k: 1 / (1 + F(k) * sum(v * v for v in x0) / 4)

    # ------------------------------------------------------------------ 1. the components at x0: fit (not assumed) and the Christoffel route
    head('1. E_a(c) - kappa tau_a at points x0 != 0 of the isotropic chart (exact f-jet): exact fit of N^b_a at 10 random configurations (k = +1, -1), [std] Christoffel route as series in t')
    r00, ri, b00, bii = [], [], [], []; ok_off = True; ok_bs = True; nz = True
    for i in range(10):
        k = [1, -1][i % 2]; x0 = PTS[k][(i // 2) % 2]
        ac = [F(rng.randint(1, 9), rng.randint(1, 3))] + [rq() for _ in range(3)]; pc = [rq() for _ in range(4)]
        vc = [rq() for _ in range(5)]; kap = F(rng.randint(1, 9), rng.randint(1, 4)); c = rq()
        ev = engine_eval_at(Gv, S, ac, pc, vc, kap, c, k, 0, x0); comp, kg = BS.residuals(ev, 0)
        e0, E0, det = E0_of(ev['e'], 4, NV); Nm = mixed_from_components({key: v[0] for key, v in comp.items()}, e0, det, 4, s=-1)
        ok_off &= all(Nm[b][a] == 0 for a in range(4) for b in range(4) if a != b) and Nm[1][1] == Nm[2][2] == Nm[3][3]
        Hh = ac[1] / ac[0]; add = 2 * ac[2] / ac[0]; ka = F(k) / ac[0] ** 2; p1 = pc[1]; p2 = 2 * pc[2]; V = BS.V_at(vc, pc[0])
        row = [Hh ** 2, add, ka, c, kap * p1 ** 2, kap * V, kap * p2, kap * Hh * p1]
        r00.append(row); b00.append(Nm[0][0]); ri.append(row); bii.append(Nm[1][1])
        # [bit==std] as series through t^3 (a non-solution: every component non-zero)
        K3 = 3; ev3 = engine_eval_at(Gv, S, ac + [F(0)] * 2, pc, vc, kap, c, k, K3, x0); comp3, _ = BS.residuals(ev3)
        pred = comp_from_N(std_N_series(ac + [F(0)] * 2, pc, vc, kap, c, k, x0, K3), ac, fval(x0, k), K3)
        ok_bs &= all(comp3[key] == pred[key] for key in comp3); nz &= any(not Z(comp3[(a, a)]) for a in range(4))
    f0 = solve_exact(r00, b00); fi = solve_exact(ri, bii); s_ = lambda f: [str(x) for x in f[0]] if f[0] else None
    chk('bit', f0[3] and f0[1] == 8 and f0[0] == [3, 0, 3, -3, F(-1, 2), -1, 0, 0], 'at x0 != 0: N^0_0 = (alpha) . (H^2, a\'\'/a, k/a^2, c, kappa phi\'^2, kappa V, kappa phi\'\', kappa H phi\'), exact fit on 10 configurations (rank %d): %s: the Friedmann constraint with the same k as at the origin' % (f0[1], s_(f0)))
    chk('bit', fi[3] and fi[1] == 8 and fi[0] == [1, 2, 1, -3, F(1, 2), -1, 0, 0], 'at x0 != 0: N^i_i fit: %s (the space equation with the same k)' % s_(fi))
    chk('bit', ok_off, 'N^b_a diagonal and isotropic at x0 (no off-diagonal component, N^1_1 = N^2_2 = N^3_3), 10 configurations')
    chk('bit==std', ok_bs and nz, 'own Christoffel route at x0 (metric diag(1, -a^2 f^2, ...) from the same jets, Christoffel symbols, Riemann, mixed Einstein tensor as series in t): all 16 components of E_a - kappa tau_a agree through t^3 on the 10 non-solutions (non-zero)')
    tick('part 1')

    # ------------------------------------------------------------------ 2. the solved series of the origin, evaluated at x0 (k = +1, -1)
    Nk = 10; Kk = Nk - 2
    head('2. the series solved at the spatial origin (kappa = 2, V = phi^2/8, a0 = 1, H0 = 1/3, phi0 = 1, phi1 = 1/2, c from the 00 equation; order %d) evaluated at x0 != 0 with the exact f-jet' % Nk)
    vB = [F(0), F(0), F(1, 8)]; kapB = F(2); a01b, p01b = (F(1), F(1, 3)), (F(1), F(1, 2)); sol = {}
    for k in (1, -1):
        cB = BS.constraint_c(a01b[0], a01b[1], p01b[0], p01b[1], vB, kapB, k)
        acB, pcB = BS.engine_solve(Gv, S, a01b, p01b, vB, kapB, cB, k, Nk); asB, psB = BS.std_solve(a01b, p01b, vB, kapB, cB, k, Nk)
        sol[k] = (cB, acB, pcB)
        chk('bit==std', asB == acB and psB == pcB, 'k = %+d: the engine series of the origin equals the textbook recursion (a_0..a_%d, phi_0..phi_%d), c = %s' % (k, Nk, Nk, cB))
        for x0 in PTS[k]:
            ev = engine_eval_at(Gv, S, acB, pcB, vB, kapB, cB, k, Kk, x0); comp, kg = BS.residuals(ev)
            r0 = sum(v * v for v in x0)
            chk('bit', allz(comp, kg), 'k = %+d, x0 = (%s), r0^2 = %s, f(x0) = %s: all 16 components of E_a - kappa tau_a and EL_phi vanish through t^%d (the 00 component included) with the series of the origin' % (k, ', '.join(str(v) for v in x0), r0, fval(x0, k), Kk))
            Ns = std_N_series(acB, pcB, vB, kapB, cB, k, x0, Kk)
            chk('std', all(Z(v) for v in Ns.values()), 'Christoffel route at the same x0 on the textbook series: G^b_a - 3c delta - kappa T^b_a = 0 through t^%d' % Kk)
            tick('k = %+d point' % k)
    # k = 0: the frame does not depend on x
    cA = F(1, 10); vA = [F(0), F(0), F(1, 2), F(0), F(1, 4)]; a01, p01 = (F(1), F(1, 2)), (F(1, 2), F(-1, 3))
    vA[0] = (3 * a01[1] ** 2 - 3 * cA) - (p01[1] ** 2 / 2 + BS.V_at(vA, p01[0]))
    acA, pcA = BS.engine_solve(Gv, S, a01, p01, vA, F(1), cA, 0, Nk)
    x0 = PTS[1][0]; ev0 = engine_eval_at(Gv, S, acA, pcA, vA, F(1), cA, 0, Kk, x0); comp0, kg0 = BS.residuals(ev0)
    evO = BS.engine_eval(Gv, S, acA, pcA, vA, F(1), cA, 0, Kk); compO, kgO = BS.residuals(evO)
    chk('bit', allz(comp0, kg0) and comp0 == compO and kg0 == kgO, 'k = 0 at x0 = (%s): the residuals are those of the origin (f = 1, the frame does not depend on x) and vanish through t^%d' % (', '.join(str(v) for v in x0), Kk))
    tick('part 2')

    # ------------------------------------------------------------------ 3. controls at x0
    head('3. controls at x0: the truncated polynomial frame 1 - k r^2/4 (not vacuous), the frame of the other k')
    for k in (1, -1):
        cB, acB, pcB = sol[k]
        for x0 in PTS[k]:
            fp = fpoly_jet(x0, k); evp = engine_eval_at(Gv, S, acB, pcB, vB, kapB, cB, k, 2, x0, fp=fp); compp, kgp = BS.residuals(evp)
            r0 = sum(v * v for v in x0); fpv = 1 - F(k) * r0 / 4
            pred = -(acB[0] / 2) * (6 * k + F(k) ** 2 * r0 / (2 * fpv) - 6 * k * fpv ** 3)
            chk('ctl', compp[(0, 0)][0] != 0 and not Z(compp[(1, 1)]), 'k = %+d, x0 = (%s): the polynomial frame 1 - k r^2/4 at x0 fails: R00 = %s at t^0, the space equation fails too (so the exact jet is what passes)' % (k, ', '.join(str(v) for v in x0), compp[(0, 0)][0]))
            chk('bit==std', compp[(0, 0)][0] == pred, '[recalled] the engine\'s R00 at t^0 equals -(a0/2)(6k + k^2 r0^2/(2 f_p) - 6k f_p^3), f_p = 1 - k r0^2/4, from G^0_0 = 3H^2 + R3[h]/(2a^2) and the Ricci scalar of the conformally flat 3-metric f_p^2 delta: %s' % pred)
    cm, acm, pcm = sol[-1]; x0 = PTS[1][0]; f0 = fval(x0, 1)
    evw = engine_eval_at(Gv, S, acm, pcm, vB, kapB, cm, 1, 2, x0); compw, _ = BS.residuals(evw)
    chk('ctl', compw[(0, 0)][0] == -6 * acm[0] * f0 ** 3 != 0 and not Z(compw[(1, 1)]), 'the k = +1 frame at x0 = (%s) with the series solved for k = -1: R00 = -6 a0 f0^3 = %s at t^0 (N^0_0 shifts by 6/a0^2), the space equation fails too' % (', '.join(str(v) for v in x0), compw[(0, 0)][0]))
    tick('part 3')

    # ------------------------------------------------------------------ 4. D E_a at x0 (k = +1): B2 with the rotation part of omega at the point
    KD = 5
    head('4. D E_a = 0 at x0 for k = +1 (E_a to spatial order 1, omega to spatial order 2, f-jet to order 3), t-order %d' % KD)
    cB, acB, pcB = sol[1]; x0 = PTS[1][0]
    e3 = frame_at(acB, 1, x0, 3); omD, EaD = BS.engine_grav(Gv, S, e3, cB, KD, 1, sE=1)
    with BS.sbound(KD, 1), trunc(4, xdeg=KD + 1): DE = Gv.D_covector(omD, EaD)
    rot = any(at0(omD[A].get(1 << mu, {}), NV) != 0 for A, (p, q) in enumerate(pairs_of(Lie_)) if p > 0 for mu in range(4))
    chk('bit', rot and all(Z(BS.tser(DE[a].get(FULL, {}), KD - 1)) for a in range(4)) and any(not Z(BS.tser(EaD[a].get(FULL ^ (1 << a), {}), KD)) for a in range(4)),
        'k = +1, x0 = (%s): the rotation part of omega is non-zero at x0 and D E_a = 0 through t^%d (E_a non-zero)' % (', '.join(str(v) for v in x0), KD - 1))
    tick('part 4')

    # ------------------------------------------------------------------ 5. the exponential potential: the power-law solution about t0 = 1
    Ne = 10; Ke = Ne - 2
    head('5. V = V0 exp(-lam phi) (Taylor polynomial in phi of degree %d): a = t^p, phi = (2/lam) ln t about t0 = 1, k = 0, c = 0; p and V0 derived from the equations' % Ne)
    for (kap, lam) in ((F(1), F(1)), (F(2), F(3))):
        p, V0, q0, ii = exp_scaling(kap, lam)
        chk('std', q0 == 0 and ii == 0 and p == 2 * kap / lam ** 2 and V0 > 0, 'kappa = %s, lam = %s: Klein-Gordon gives W = (6p - 2)/lam^2, the Friedmann equation is a quadratic in p with constant term %s (roots 0 and p), p = %s, V0 = %s > 0, and the space equation holds at that p' % (kap, lam, q0, p, V0))
        vce = exp_vc(V0, lam, Ne); ac = binom_series(p, Ne); pc = [F(0)] + [2 / lam * F((-1) ** (j + 1), j) for j in range(1, Ne + 1)]
        ii_s, kg_s, c00_s = BS.std_eqs(ac, pc, vce, kap, F(0), 0, Ke)
        chk('std', Z(ii_s) and Z(kg_s) and Z(c00_s), 'the Taylor series of the closed form (binom(p, j), (2/lam)(-1)^(j+1)/j) satisfies the textbook ii, Klein-Gordon and 00 equations through t^%d with the cut potential' % Ke)
        evE = BS.engine_eval(Gv, S, ac, pc, vce, kap, F(0), 0, Ke); compE, kgE = BS.residuals(evE)
        chk('bit', allz(compE, kgE), 'kappa = %s, lam = %s: all 16 components of E_a - kappa tau_a and EL_phi vanish through t^%d on the closed-form series' % (kap, lam, Ke))
        acS, pcS = BS.engine_solve(Gv, S, (F(1), p), (F(0), 2 / lam), vce, kap, F(0), 0, Ne); asS, psS = BS.std_solve((F(1), p), (F(0), 2 / lam), vce, kap, F(0), 0, Ne)
        chk('bit==std', acS == ac and pcS == pc and asS == ac and psS == pc, 'the engine series from (1, p, 0, 2/lam) and the textbook recursion both equal the closed-form coefficients through order %d (a = %s...)' % (Ne, ', '.join(str(x) for x in ac[:4])))
        # controls: wrong sign of the potential; wrong exponent
        evS = BS.engine_eval(Gv, S, ac, pc, [-x for x in vce], kap, F(0), 0, 2); compS, kgS = BS.residuals(evS)
        chk('ctl', compS[(0, 0)][0] == -2 * kap * V0 != 0 and not Z(compS[(1, 1)]) and not Z(kgS), 'wrong sign of the potential (V -> -V): the 00 equation fails at t^0 by -2 kappa V0 = %s, the space and Klein-Gordon equations fail too' % compS[(0, 0)][0])
        pw = p + 1; acW = binom_series(pw, Ne)
        evW = BS.engine_eval(Gv, S, acW, pc, vce, kap, F(0), 0, 2); compW, _ = BS.residuals(evW)
        asW, _ = BS.std_solve((F(1), pw), (F(0), 2 / lam), vce, kap, F(0), 0, Ne)
        chk('ctl', compW[(0, 0)][0] == -3 * (pw ** 2 - p ** 2) != 0 and asW != acW, 'wrong exponent p + 1 = %s: the 00 equation fails at t^0 by -3(p\'^2 - p^2) = %s, and the recursion from (1, p\', 0, 2/lam) does not give binom(p\', j)' % (pw, compW[(0, 0)][0]))
        tick('exp (%s, %s)' % (kap, lam))
    finish('B3C4-curved')

if __name__ == '__main__': main()
