#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F3-KN.  F = nabla_a chi_b nabla^a chi^b = -2 kH^2 on the horizons of Kerr-Newman (a != 0, Q != 0), extremal Kerr-Newman and extremal Kerr.   python3 f3_kn_horizons.py

 Statement  On a Killing horizon (chi Killing, null on the surface and normal to it), with kH defined by nabla_chi chi = kH chi, F equals -2 kH^2.  It is a kinematic identity
            (recalled textbook fact, Wald, General Relativity): the Killing equation and the null normal, no field equation.  On the horizon chi ^ nabla chi = 0 (twist zero), so
            nabla chi = chi ^ u with u_a = n^b nabla_b chi_a (any n with n.chi = 1), chi.u = -kH, and F = 2 (chi.chi)(u.u) - 2 (chi.u)^2 = -2 kH^2 (ours, checked at the points).
 Frames     f2_first_law.kn_frame_jet: e^a = dx^a - f l^a l, f = (M r - s) r^2/(r^4 + a^2 z^2), s = kappa Q^2/4 (kappa the coupling input; only s enters the frame); advanced chart.
            Members (M, a, Q, kappa): (5, 1, 4, 1), (7/2, 2, 2, 1), (15/2, 2, 8, 1), (3, 2, 2, 2), (3/2, 3/10, 1, 4), (19, 18, 6, 2) (nearly extremal), (841/280, 1, 4, 1)
            (just off the extremal (3, 1, 4, 1): same a and s); extremal (3, 1, 4, 1), (5, 3, 4, 2), (9/4, 7/4, 1, 4) (M^2 = a^2 + 2s: the double root r_h = M of
            Delta = r^2 - 2 M r + a^2 + 2s, the closed form behind f2_first_law.family_closed); extremal Kerr (1, 1, 0) and Kerr (841/840, 1, 0) just off it.
            Four rational points per horizon (g2_kerr.rational_kerr_points: two generic angles, the equator, the pole), exact 2-jets.
 [bit]      chi = d_t + Omega_H d_phi (g2_kerr.killing_chi) with Omega_H the double root of |d_t + Omega d_phi|^2 (g2_kerr.null_rotation, frame data) at the off-axis points;
            f3_horizons.horizon_data: kH from nabla_chi chi = kH chi (A3 closed-form omega, Grav.D_vector), nabla chi, F, chi^2, |d chi^2|^2 from f3_killing.wald_engine;
            the twist w (f3_kerr.twist_frame), the second invariant P = (1/2) eps^abcd nabla_a chi_b nabla_c chi_d (eps_0123 = +1), nabla chi = chi ^ u; F2's horizon_numbers.
 [std]      Christoffel route of g = e^T eta e (f3_horizons.std_data: nabla_m chi_n, F, kH; f3_kerr.twist_std; P with det g = -1); recalled Boyer-Lindquist values:
            kH = +-sqrt(M^2 - a^2 - 2s)/(r_h^2 + a^2), Omega_H = a/(r_h^2 + a^2) (f2_first_law.family_closed; for Kerr also g2_kerr.kerr_horizon_data).
 Limits     a = 0 through the same code reproduces the Reissner-Nordstrom rows of f3_horizons (point by point against f3_horizons.rn_frame and horizon_data); Q = 0 reproduces
            the Kerr numbers of f3_kerr (point by point against its construction: g2_kerr.kerr_ks_frame_jet, f3_killing.fields, wald_engine).
 Context    which frame each member is (field equations, not the identity): E_a = lambda T_a with one lambda = -kappa (Maxwell stress of A = (Q r^3/(r^4 + a^2 z^2)) l) on the
            charged members, E_a = 0 on the Kerr ones, at one horizon point each.
 [ctl]      omega -> -omega (d kept) at the non-degenerate and at the extremal horizon points; the wrong generator d_t + (9/10) Omega_H d_phi; F = -2 kH in place of -2 kH^2;
            the other horizon's kH; 8 points off the horizons per member; the members just off extremality against the extremal ones.
 Scope      values at rational points, n = 4; no area law, no temperature, no Kerr-de Sitter.
 Exports    MEMBERS, member(mid), horizon_points(M, a, s, rh, angs=ANG), point_data(Gv, S, e, chi, std=True), pseudo(nab), chi_wedge(W), ANG"""
import sys, os, time, itertools
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from b1lib import *
import g2_kerr as K
import f3_killing as F3
import f3_horizons as FH
import f3_kerr as FK
from f2_first_law import kn_frame_jet, kn_potential, horizon_numbers, family_closed, maxwell_stress_comp

NV = 4; SQ = LORENTZ(4); T0 = time.time()
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
def one(S_): return next(iter(S_)) if len(S_) == 1 else None
ANG = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(5, 13), F(12, 13)), (F(3, 5), F(4, 5))), ((F(0), F(1)), (F(1), F(0))), ((F(1), F(0)), (F(1), F(0)))]   # generic, generic, equator, pole
PERM = [(p, (-1) ** sum(1 for i in range(4) for j in range(i + 1, 4) if p[i] > p[j])) for p in itertools.permutations(range(4))]

# ------------------------------------------------------------------------------------------------ members
MEMBERS = [('K1', F(5), F(1), F(4), 1, 'the frame of f3_kerr, F2 and F4'), ('K2', F(7, 2), F(2), F(2), 1, 'F2 and F4'), ('K3', F(15, 2), F(2), F(8), 1, 'F2'),
           ('K4', F(3), F(2), F(2), 2, 'kappa = 2'), ('K5', F(3, 2), F(3, 10), F(1), 4, 'kappa = 4, a/M = 1/5'),
           ('K6', F(19), F(18), F(6), 2, 'nearly extremal, sqrt(M^2 - a^2 - 2s)/M = 1/19'), ('KNe', F(841, 280), F(1), F(4), 1, 'just off the extremal X1 (same a and s)'),
           ('X1', F(3), F(1), F(4), 1, 'extremal'), ('X2', F(5), F(3), F(4), 2, 'extremal'), ('X3', F(9, 4), F(7, 4), F(1), 4, 'extremal'),
           ('XK', F(1), F(1), F(0), 1, 'extremal Kerr, a = M'), ('KE', F(841, 840), F(1), F(0), 1, 'Kerr just off XK')]
def member(mid):
    """dict(id, M, a, Q, kappa, s, d = sqrt(M^2 - a^2 - 2s), ext, horizons [(branch, r_h, closed dict)]) from the recalled closed forms of family_closed"""
    _, M, a, Q, kap, note = next(m for m in MEMBERS if m[0] == mid); s = F(kap) * Q * Q / 4; d = K.rat_sqrt(M * M - a * a - 2 * s)
    hs = [(br, family_closed(kap, M, a, Q, (0, 0, 0), br)) for br in ((1,) if d == 0 else (1, -1))]
    return dict(id=mid, M=M, a=a, Q=Q, kap=kap, s=s, d=d, ext=d == 0, note=note, hor=[(br, c['rh'].v, c) for br, c in hs])
def label(m): return '%s (M, a, Q, kappa) = (%s, %s, %s, %s), s = %s' % (m['id'], m['M'], m['a'], m['Q'], m['kap'], m['s'])

# ------------------------------------------------------------------------------------------------ one point, both routes
def pseudo(nab):
    """P = (1/2) eps^abcd X_ab X_cd for a 4x4 array X of lower components, eps^0123 = -1 (eps_0123 = +1, signature (+,-,-,-); in coordinates det g = -1 is required)"""
    return -sum(sg * nab[a][b] * nab[c][d] for (a, b, c, d), sg in PERM) / 2
def chi_wedge(W):
    """nabla chi = chi ^ u: u_a = n^b nabla_b chi_a with n = e_c / chi_c (first c with chi_c != 0, so n.chi = 1); returns dict(u, ok = (nabla_b chi_a == chi_b u_a - u_b chi_a), cu = chi.u, uu = u.u)"""
    nab = W['nab']; xl = [SQ[a] * W['xa'][a] for a in range(NV)]; c = next((i for i in range(NV) if xl[i] != 0), None)
    if c is None: return None
    u = [nab[c][a] / xl[c] for a in range(NV)]
    return dict(u=u, ok=all(nab[b][a] == xl[b] * u[a] - u[b] * xl[a] for a in range(NV) for b in range(NV)), cu=sum(SQ[a] * xl[a] * u[a] for a in range(NV)), uu=sum(SQ[a] * u[a] ** 2 for a in range(NV)))
def point_data(Gv, S, e, chi, std=True):
    """[bit] f3_horizons.horizon_data plus twist, P and the wedge form; [std] f3_horizons.std_data plus twist and P (coordinates)"""
    W = FH.horizon_data(Gv, S, e, chi); W['w'], W['ww'] = FK.twist_frame(W); W['P'] = pseudo(W['nab']); W['wedge'] = chi_wedge(W)
    if not std: return W, None
    Z = FH.std_data(e, chi); Z['ww'], Z['detg'] = FK.twist_std(Z, chi); Z['P'] = pseudo(Z['nab']); return W, Z
def horizon_points(M, a, s, rh, angs=ANG):
    """frames at the rational points of r = rh and the set of (discriminant, Omega) of |d_t + Omega d_phi|^2 at the off-axis points (one double root on a Killing horizon)"""
    pts = [(P,) + tuple(kn_frame_jet(P['p'], M, a, s, r0=rh)) for P in K.rational_kerr_points(a, [rh], angs)]
    return pts, {K.null_rotation(q[1], q[0]['p'], SQ) for q in pts if q[0]['sth'] != 0}

CT = {}
def ctl(name, wrong): k = CT.setdefault(name, [0, 0]); k[1] += 1; k[0] += int(bool(wrong))
C_FLIP = 'omega -> -omega (d kept) in F and kH: F = -2 kH^2 fails at the non-degenerate horizon points'
C_FLIPX = 'omega -> -omega (d kept) at the extremal horizon points: the flipped F is not -2 kH^2 (or nabla_chi chi is not proportional to chi)'
C_WGEN = 'the wrong generator d_t + (9/10) Omega_H d_phi at the off-axis points of the rotating horizons: not null, and F = -2 kH^2 fails (for its own kH and for the true one)'
C_LIN = 'F = -2 kH in place of -2 kH^2 (points with kH not 0 or 1)'
C_OTHER = 'the other horizon\'s kH of the same member in place of kH'
C_OFF = 'off the horizons (8 points per member): F(chi) differs from -2 kH^2 for the generator of every horizon of the member, and nabla_chi chi is not proportional to chi'
C_NEAR = 'just off extremality (KNe against X1, KE against XK): the extremal values kH = 0, F = 0 fail on the near member\'s horizons, and its kH fails on the extremal horizon'
CTL_NAMES = [C_FLIP, C_FLIPX, C_WGEN, C_LIN, C_OTHER, C_OFF, C_NEAR]     # registered first: a control that is never reached prints as a failure

def run_horizon(Gv, S, m, br, rh, cf, other_kH=None):
    """one horizon of member m: the identity at the four points on both routes, F2's bookkeeping, the closed forms; returns dict(kH, Om, F, nz)"""
    M, a, s = m['M'], m['a'], m['s']; tag = '%s, %s horizon r = %s' % (m['id'], 'extremal (double root)' if m['ext'] else ('outer' if br == 1 else 'inner'), rh)
    pts, roots = horizon_points(M, a, s, rh); Om = one({o for (dsc, o) in roots}); disc_ok = {dsc for (dsc, o) in roots} == {0}
    ks, Fs, nz, uus = set(), set(), [], set(); ok_id = ok_bs = True
    for (P, e, E, lul, data) in pts:
        chi = K.killing_chi(P['p'], Om if Om is not None else 0); W, Z = point_data(Gv, S, e, chi); cw = W['wedge']
        ks.add(W['kH']); Fs.add(W['F']); nz.append((P['cth'], sum(1 for row in W['nab'] for x in row if x != 0)))
        ok_id &= (W['null'] == 0 and W['N'] == 0 and W['dN2'] == 0 and all(x == 0 for row in W['K'] for x in row) and not any(W['w']) and W['P'] == 0
                  and cw is not None and cw['ok'] and W['kH'] is not None and cw['cu'] == -W['kH'] and W['F'] == -2 * W['kH'] ** 2)
        ok_bs &= W['nab_c'] == Z['nab'] and W['F'] == Z['F'] and W['kH'] == Z['kH'] and W['ww'] == Z['ww'] == 0 and Z['detg'] == -1 and W['P'] == Z['P']
        if P['sth'] != 0 and cw is not None: uus.add(cw['uu'])
        if W['kH'] is not None and W['kH'] != 0:
            Wm = FH.horizon_data(Gv, S, e, chi, om_sign=-1); ctl(C_FLIP, Wm['kH'] is None or Wm['F'] != -2 * Wm['kH'] ** 2)
            if W['kH'] != 1: ctl(C_LIN, W['F'] != -2 * W['kH'])
            if other_kH is not None: ctl(C_OTHER, W['F'] != -2 * other_kH ** 2)
        elif W['kH'] == 0:
            Wm = FH.horizon_data(Gv, S, e, chi, om_sign=-1); ctl(C_FLIPX, Wm['kH'] is None or Wm['F'] != -2 * Wm['kH'] ** 2)
            print('    %s, cos th = %s: omega -> -omega at an extremal point: kH = %s, F = %s' % (tag, P['cth'], Wm['kH'], Wm['F']))
        if P['sth'] != 0 and Om:                    # the wrong generator differs from chi by (1/10) Omega_H psi: not seeable on the axis (psi = 0) nor where Omega_H = 0 (a = 0)
            Ww = FH.horizon_data(Gv, S, e, K.killing_chi(P['p'], F(9, 10) * Om)); kt = W['kH'] if W['kH'] is not None else F(0)
            ctl(C_WGEN, Ww['N'] != 0 and Ww['F'] != -2 * kt ** 2 and (Ww['kH'] is None or Ww['F'] != -2 * Ww['kH'] ** 2))
    kH = one(ks)
    chk('bit', ok_id and disc_ok and Om is not None and kH is not None, '%s: at %d points (pole and equator included) chi = d_t + Omega_H d_phi, ONE Omega_H = %s (double root at the off-axis points), is null and Killing, '
        '|d chi^2|^2 = 0, twist w = 0, P = 0, nabla chi = chi ^ u with chi.u = -kH; ONE kH = %s and F = %s = -2 kH^2' % (tag, len(pts), Om, kH, ', '.join(sorted(str(x) for x in Fs))))
    hn = horizon_numbers(Gv, S, M, a, s, rh, ANG[:2], std=False)
    chk('bit', hn['kH'] == {kH} and hn['Om'] == {Om} and hn['null'] == {0} and kH is not None, '%s: f2_first_law.horizon_numbers (F2\'s bookkeeping, two points) gives the same kH = %s and Omega_H = %s' % (
        tag, ', '.join(str(x) for x in hn['kH']), ', '.join(str(x) for x in hn['Om'])))
    chk('bit==std', ok_bs and kH == cf['kH'].v and Om == cf['Om'].v, '%s: nabla_m chi_n (engine omega) = Christoffel route (16 entries), F, kH, w.w = 0 and P equal on both routes (det g = -1); '
        '= the recalled Boyer-Lindquist kH = %s, Omega_H = a/(r_h^2 + a^2) = %s' % (tag, cf['kH'].v, cf['Om'].v))
    if m['ext']:
        off = [n for (c, n) in nz if c not in (1, -1)]; pole = [n for (c, n) in nz if c in (1, -1)]
        chk('bit', kH == 0 and Fs == {0} and all(n > 0 for n in off) and pole == [0] and uus and all(x < 0 for x in uus),
            '%s: kH = 0 and F = 0 at every point, but nabla chi != 0 at the %d off-axis points (%s of 16 frame components non-zero): nabla chi = chi ^ u with chi.u = 0 and u spacelike '
            '(u.u = %s): a null 2-form (F = 0 and P = 0); at the pole nabla chi = 0 (all 16)' % (tag, len(off), ', '.join(map(str, off)), ', '.join(sorted(str(x) for x in uus))))
    return dict(kH=kH, Om=Om, F=one(Fs), tag=tag)

def run_off(Gv, S, m, gens, radii):
    """8 points off the horizons (radii x two generic angles): F of each horizon generator differs from its -2 kH^2; [bit] F = [std] F for the first generator"""
    M, a, s = m['M'], m['a'], m['s']; ok = True; n = 0; shown = []
    for P in K.rational_kerr_points(a, radii, ANG[:2]):
        e = kn_frame_jet(P['p'], M, a, s, r0=P['r'])[0]; n += 1
        for i, (Om, kH) in enumerate(gens):
            W, Z = point_data(Gv, S, e, K.killing_chi(P['p'], Om), std=(i == 0))
            ctl(C_OFF, W['F'] != -2 * kH ** 2 and W['kH'] is None)
            if i == 0: ok &= W['nab_c'] == Z['nab'] and W['F'] == Z['F'] and all(x == 0 for row in W['K'] for x in row); shown.append(W['F'])
    chk('bit==std', ok and n == 8, '%s, off the horizons (r = %s, two angles each: %d points): chi of the outer horizon is Killing, F (engine omega) = F (Christoffel), e.g. F = %s at r = %s' % (
        m['id'], ', '.join(map(str, radii)), n, shown[0], radii[0]))

# ------------------------------------------------------------------------------------------------ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # per run (an engine fault put into Lie in memory is seen)
    CT.clear(); [CT.setdefault(n, [0, 0]) for n in CTL_NAMES]
    MS = {m[0]: member(m[0]) for m in MEMBERS}; H = {}
    head('0. the members: Delta = r^2 - 2 M r + a^2 + 2s, r_h = M +- sqrt(M^2 - a^2 - 2s) (f2_first_law.family_closed, recalled), s = kappa Q^2/4')
    for m in MS.values():
        dl = lambda r: r * r - 2 * m['M'] * r + m['a'] ** 2 + 2 * m['s']
        ok = m['d'] is not None and all(dl(rh) == 0 for (br, rh, c) in m['hor']) and (not m['ext'] or (len(m['hor']) == 1 and 2 * m['hor'][0][1] - 2 * m['M'] == 0))
        chk('std', ok, '%s (%s): Delta(r_h) = 0 at r_h = %s%s' % (label(m), m['note'], ' and '.join(str(rh) for (br, rh, c) in m['hor']),
            ', a double root (Delta\'(r_h) = 2 r_h - 2M = 0): extremal' if m['ext'] else ' (sqrt(M^2 - a^2 - 2s) = %s)' % m['d']))
    tick('part 0')

    head('1. Kerr-Newman with a != 0 and Q != 0 and Kerr just off extremality: outer and inner horizons, four points each')
    for mid in ('K1', 'K2', 'K3', 'K4', 'K5', 'K6', 'KNe', 'KE'):
        m = MS[mid]; kc = {rh: c['kH'].v for (br, rh, c) in m['hor']}
        for (br, rh, c) in m['hor']:
            H[(mid, rh)] = run_horizon(Gv, S, m, br, rh, c, other_kH=next(k for r_, k in kc.items() if r_ != rh))
    tick('part 1')

    head('2. extremal Kerr-Newman (the double root of Delta) and extremal Kerr (a = M): kH = 0, F = 0, and nabla chi')
    for mid in ('X1', 'X2', 'X3', 'XK'):
        m = MS[mid]; (br, rh, c), = m['hor']; H[(mid, rh)] = run_horizon(Gv, S, m, br, rh, c)
    m = MS['XK']; kd = K.kerr_horizon_data(m['M'], m['a']); h = H[('XK', F(1))]
    chk('std', (kd['rp'], kd['rm'], kd['kappa_p'], kd['Omega_p']) == (1, 1, 0, F(1, 2)) and h['Om'] == 1 / (2 * m['M']) and h['kH'] == 0,
        'extremal Kerr (M = a = 1): g2_kerr.kerr_horizon_data (recalled) gives r+ = r- = %s, kappa = %s, Omega = %s; the engine\'s Omega_H = %s = 1/(2M) and kH = %s' % (kd['rp'], kd['kappa_p'], kd['Omega_p'], h['Om'], h['kH']))
    m = MS['KE']; kd = K.kerr_horizon_data(m['M'], m['a'])
    chk('std', (H[('KE', kd['rp'])]['kH'], H[('KE', kd['rm'])]['kH'], H[('KE', kd['rp'])]['Om'], H[('KE', kd['rm'])]['Om']) == (kd['kappa_p'], kd['kappa_m'], kd['Omega_p'], kd['Omega_m']),
        'Kerr (841/840, 1): g2_kerr.kerr_horizon_data (recalled) r+- = %s, %s, kappa = %s, %s, Omega = %s, %s = the engine\'s values' % (kd['rp'], kd['rm'], kd['kappa_p'], kd['kappa_m'], kd['Omega_p'], kd['Omega_m']))
    for near, ext in (('KNe', 'X1'), ('KE', 'XK')):
        he = H[(ext, MS[ext]['hor'][0][1])]
        for (br, rh, c) in MS[near]['hor']:
            hn = H[(near, rh)]; ctl(C_NEAR, hn['kH'] is not None and hn['kH'] != 0 and hn['F'] is not None and hn['F'] != 0)
            ctl(C_NEAR, hn['kH'] is not None and he['F'] is not None and he['F'] != -2 * hn['kH'] ** 2)
    chk('bit', all(H[(n_, rh)]['kH'] not in (None, 0) for n_ in ('KNe', 'KE') for (br, rh, c) in MS[n_]['hor']) and all(H[(x, MS[x]['hor'][0][1])]['F'] == 0 for x in ('X1', 'XK')),
        'just off extremality the identity is not degenerate: KNe kH = %s, %s (F = %s, %s) against X1 kH = 0; KE kH = %s, %s against XK kH = 0' % tuple(
            [H[('KNe', rh)]['kH'] for (b, rh, c) in MS['KNe']['hor']] + [H[('KNe', rh)]['F'] for (b, rh, c) in MS['KNe']['hor']] + [H[('KE', rh)]['kH'] for (b, rh, c) in MS['KE']['hor']]))
    tick('part 2')

    head('3. off the horizons: 8 points per member (between the horizons, inside r-, outside; two generic angles)')
    for m in MS.values():
        rs = [rh for (br, rh, c) in m['hor']]; gens = [(H[(m['id'], rh)]['Om'], H[(m['id'], rh)]['kH']) for rh in rs]
        if None in [x for g in gens for x in g]: chk('bit==std', False, '%s: off-horizon run skipped (no Omega_H or kH)' % m['id']); continue
        radii = [m['M'] / 2, 3 * m['M'] / 2, 2 * m['M'], 3 * m['M']] if m['ext'] else [(rs[0] + rs[1]) / 2, rs[1] / 2, 3 * rs[0] / 2, 2 * rs[0]]
        run_off(Gv, S, m, gens, radii)
    tick('part 3')

    head('4. limits: a = 0 reproduces the Reissner-Nordstrom rows of f3_horizons, Q = 0 the Kerr rows of f3_kerr (same code path as above)')
    M, s = F(3, 2), F(1); okp = True; vals = []
    for rh, kexp, Fexp in ((F(2), F(1, 8), F(-1, 32)), (F(1), F(-1, 2), F(-1, 2))):
        m = dict(id='RN', M=M, a=F(0), s=s, ext=False); cf = family_closed(1, M, 0, F(2), (0, 0, 0), 1 if rh == 2 else -1)
        h = run_horizon(Gv, S, m, 1 if rh == 2 else -1, rh, cf); vals.append((rh, h['kH'], h['F']))
        okp &= (h['kH'], h['F'], h['Om']) == (kexp, Fexp, 0) and h['kH'] == FH.T_static('RN', (M, s), rh)[1] / 2
        for P in K.rational_kerr_points(0, [rh], ANG):
            e1 = kn_frame_jet(P['p'], M, 0, s, r0=rh)[0]; e2 = FH.rn_frame(P['p'], M, s, rh)[0]
            W1, _ = point_data(Gv, S, e1, K.killing_chi(P['p'], h['Om'] if h['Om'] is not None else 0), std=False); W2 = FH.horizon_data(Gv, S, e2, [const(NV, 1), {}, {}, {}])
            okp &= W1['nab'] == W2['nab'] and (W1['kH'], W1['F']) == (W2['kH'], W2['F'])
    chk('bit', okp, 'a = 0, (M, s) = (3/2, 1): %s: the RN rows of f3_horizons (kH = 1/8, -1/2; F = -1/32, -1/2; kH = (1/2) T\'(r_h)), and at each of the 8 points the same 16 entries of nabla xi, kH and F as '
        'f3_horizons.rn_frame with horizon_data (Omega_H = 0, chi = d_t)' % '; '.join('r = %s: kH = %s, F = %s' % v for v in vals))
    okk = True; vals = []
    for (M, a, rh, exp) in ((F(5), F(3), F(9), (F(2, 45), F(-8, 2025))), (F(5), F(3), F(1), (F(-2, 5), F(-8, 25))), (F(5), F(4), F(8), (F(3, 80), F(-9, 3200))), (F(5), F(4), F(2), (None, None))):
        kd = K.kerr_horizon_data(M, a); br = 1 if rh == kd['rp'] else -1; m = dict(id='Kerr (%s, %s)' % (M, a), M=M, a=a, s=F(0), ext=False)
        h = run_horizon(Gv, S, m, br, rh, family_closed(1, M, a, 0, (0, 0, 0), br)); vals.append((M, a, rh, h['kH'], h['F']))
        okk &= (h['kH'], h['Om']) == ((kd['kappa_p'], kd['Omega_p']) if br == 1 else (kd['kappa_m'], kd['Omega_m'])) and (exp[0] is None or (h['kH'], h['F']) == exp)
        for P in K.rational_kerr_points(a, [rh], ANG[:2]):
            e1 = kn_frame_jet(P['p'], M, a, 0, r0=rh)[0]; e2, E2, _, _ = K.kerr_ks_frame_jet(P['p'], M, a, rh); e0, E0, det = E0_of(e2, 4, 4); V = F3.fields(P['p'])
            W1, _ = point_data(Gv, S, e1, K.killing_chi(P['p'], h['Om']), std=False); W2 = F3.wald_engine(Gv, e2, E0, F3.vsum((1, V['d_t']), (h['Om'], V['rot_z'])), S)
            okk &= e1 == e2 and W1['nab'] == W2['nab'] and W1['F'] == W2['F']
    chk('bit', okk, 'Q = 0: %s: f3_kerr\'s numbers (kH = 2/45, -2/5 on (5, 3); 3/80 on (5, 4) r+; F = -2 kH^2), = g2_kerr.kerr_horizon_data (recalled); at two points of each horizon '
        'kn_frame_jet(s = 0) = g2_kerr.kerr_ks_frame_jet and the 16 entries of nabla chi and F equal f3_kerr\'s construction (f3_killing.fields, wald_engine)' % '; '.join('(%s, %s) r = %s: kH = %s, F = %s' % v for v in vals))
    h = H[('K1', F(9))]
    chk('bit', (h['Om'], h['kH'], h['F']) == (F(1, 82), F(2, 41), F(-8, 1681)), 'K1 outer horizon = the Kerr-Newman frame of f3_kerr: Omega_H = %s, kH = %s, F = %s (f3_kerr: 1/82, 2/41, -2 kH^2)' % (h['Om'], h['kH'], h['F']))
    tick('part 4')

    head('5. context: which frame each member is (field equations, not the identity), one outer-horizon point each')
    okc = True; lams = []; okv = True
    for m in MS.values():
        rh = m['hor'][0][1]; P = K.rational_kerr_points(m['a'], [rh], ANG[:1])[0]; e, E, _, data = kn_frame_jet(P['p'], m['M'], m['a'], m['s'], r0=rh)
        om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0)
        if m['Q'] == 0: okv &= not any(comp.values()); continue
        cT, _ = maxwell_stress_comp(Gv, e, E, kn_potential(m['Q'], data)); k0 = next((k for k in sorted(cT) if cT[k] != 0), None); lam = comp[k0] / cT[k0] if k0 is not None else None
        okc &= lam == -m['kap'] and all(comp[k] == lam * cT[k] for k in comp) and any(comp.values()); lams.append('%s: %s' % (m['id'], lam))
    chk('bit', okc, 'charged members: E_a = lambda T_a on all 16 components with ONE lambda = -kappa (%s): Kerr-Newman frames with the Maxwell stress of A = (Q r^3/(r^4 + a^2 z^2)) l' % ', '.join(lams))
    chk('bit', okv, 'XK and KE: E_a = 0 (all 16 components) at a horizon point: vacuum; the identity above used no field equation')
    tick('part 5')

    head('controls (a wrong version must fail on every sample where it can be seen)')
    for name, (dif, seen) in CT.items(): chk('ctl', dif == seen and seen > 0, '%s: fails on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F3-KN')

if __name__ == '__main__': main()
