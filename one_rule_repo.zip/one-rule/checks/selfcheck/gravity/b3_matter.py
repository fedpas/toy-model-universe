#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""B3: one matter action end to end (scalar field, then Maxwell) on the bit-rule engine.   python3 b3_matter.py

 n = 4, signature (+,-,-,-), polynomials in 5 slots: x^0..x^3 and slot 4 = lam (bookkeeping parameter of the first variation, b1lib.trunc lam = 1).
 Matter 4-forms (bit-rule star of g2_hodge, vol_e = e^0 e^1 e^2 e^3):  L_phi = s_k (1/2) dphi ^ *dphi - V(phi) vol_e,   L_A = s_A (-1/2) F ^ *F,  F = dA.
 Stress by variation:  e -> e + lam h  (16 unit h's),  delta L = h^a ^ tau_a,  tau_a = tau^b_a Theta_b.
 Euler-Lagrange forms: delta_phi L = delta phi EL_phi + d(..),  EL_phi = -(s_k d*dphi + V' vol_e);   delta_A L = delta A ^ EL_A + d(..),  EL_A = -s_A d*F.
 [std] numpy complex-step T_{mu nu} = (2/sqrt(-g)) d(sqrt(-g) l)/d g^{mu nu};  exact Christoffel divergence nabla_mu T^mu_nu.
 Exports (no engine object at import): poly_V, dV, strong_poly, strong_frame, L_scalar, L_maxwell, matter_variation, tau_mixed_at0, EL_scalar, EL_maxwell,
   noether_at0, std_T_cs, std_scalar_Tmix_jet, std_maxwell_Tmix_jet, std_div_at0, lam_part, lift, lift_form."""
import os, sys, time, itertools, random
_here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _here)
from b1lib import *
import g2_hodge as H
import g2_forms_calc as FC
import numpy as np

n = 4; NV = 5; SQ = LORENTZ(4); FULL = 15
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ small helpers
def lift(p, nv=NV): return {k + (0,) * (nv - len(k)): v for k, v in p.items()}
def lift_form(X, nv=NV): return {m: lift(p, nv) for m, p in X.items() if p}
def lam_part(p, nn=n, k=1):
    """coefficient of lam^k (slot nn) as a polynomial with lam exponent 0"""
    return {key[:nn] + (0,) + key[nn + 1:]: v for key, v in p.items() if key[nn] == k}
LAMV = {(0, 0, 0, 0, 1): F(1)}
def poly_V(phi, vc, nv=NV, mul=None):
    """V(phi) = sum_k vc[k] phi^k (engine product pm, truncation-aware; mul = sp-style product for the [std] route)"""
    mul = mul or pm; out = {}; pw = const(nv, 1)
    for k, c in enumerate(vc):
        if k: pw = mul(pw, phi)
        if c: out = padd(out, pw, c)
    return out
def dV(vc): return [k * c for k, c in enumerate(vc)][1:] or [F(0)]
def V_num(x, vc): return sum(c * x ** k for k, c in enumerate(vc))
def strong_poly(rng, deg, lo=-9, hi=9, nv=NV, slots=4):
    """strong sampler: every monomial of x-degree <= deg present, integer coefficient uniform in [lo, hi] (density 1)"""
    return {ex + (0,) * (nv - slots): F(rng.randint(lo, hi)) for ex in itertools.product(range(deg + 1), repeat=slots) if sum(ex) <= deg}
def strong_frame(rng, deg=1, nv=NV):
    """e^a_mu(x): constant part invertible, every monomial up to deg, coefficients uniform in [-9, 9]"""
    while True:
        e = [{1 << mu: {k: v for k, v in strong_poly(rng, deg, nv=nv).items() if v != 0} for mu in range(n)} for _ in range(n)]
        e0 = [[at0(e[a].get(1 << mu, {}), nv) for mu in range(n)] for a in range(n)]
        if det_inv(e0)[0] != 0: return [{m: p for m, p in f.items() if p} for f in e]

# ------------------------------------------------------------------------------------------------ the matter 4-forms (engine: wedge, d, star by the bit rule)
def L_scalar(Gv, e, E, phi, vc, sk=1, sq=SQ, vol=None, nv=NV):
    Fm = Gv.Fm; dphi = Fm.d({0: phi}) if phi else {}
    L = Fm.scale(Fm.wedge(dphi, H.hodge_form(dphi, e, E, Fm, sq, nv)), F(sk, 2))
    Vp = poly_V(phi, vc, nv)
    if Vp: L = Fm.add(L, Fm.wedge({0: Vp}, H.vol_form(e, Fm, nv) if vol is None else vol), -1)
    return L
def L_maxwell(Gv, e, E, Fc, sA=1, sq=SQ, nv=NV):
    Fm = Gv.Fm; return Fm.scale(Fm.wedge(Fc, H.hodge_form(Fc, e, E, Fm, sq, nv)), F(-sA, 2))
def EL_scalar(Gv, e, E, phi, vc, sk=1, sq=SQ, vol=None, nv=NV, vfac=1):
    Fm = Gv.Fm; dphi = Fm.d({0: phi}); out = Fm.scale(Fm.d(H.hodge_form(dphi, e, E, Fm, sq, nv)), sk)
    Vp = poly_V(phi, dV(vc), nv)
    if Vp: out = Fm.add(out, Fm.wedge({0: Vp}, H.vol_form(e, Fm, nv) if vol is None else vol), vfac)
    return Fm.scale(out, -1)
def EL_maxwell(Gv, e, E, Fc, sA=1, sq=SQ, nv=NV):
    Fm = Gv.Fm; return Fm.scale(Fm.d(H.hodge_form(Fc, e, E, Fm, sq, nv)), -sA)

# ------------------------------------------------------------------------------------------------ the first variation in the frame
def _inv(ep, xdeg, nv):
    E1, _ = inverse_series(frame_matrix(ep, n), n, nv, max(xdeg, 1))       # deg >= 1: inverse_series returns the bare constant inverse at deg 0 (no lam term)
    return E1
def matter_variation(Gv, e, Lfun, xdeg=0, h=None, nv=NV):
    """[bit] tau_a from delta L = h^a ^ tau_a, Lfun(ep, Ep) -> 4-form for the frame ep and its inverse Ep.  h = None: the 16 unit variations h^a = dx^mu
    (constant), tau_a returned as 3-forms (jets to x-degree xdeg).  h = list of n 1-forms: returns delta L itself (4-form jet), for the pointwise check."""
    Fm = Gv.Fm
    if h is not None:
        ep = [Fm.add(e[a], Fm.wedge({0: LAMV}, h[a])) for a in range(n)]
        with trunc(n, xdeg=xdeg, lam=1): L = Lfun(ep, _inv(ep, xdeg, nv))
        return {m: q for m, q in ((m, lam_part(p)) for m, p in L.items()) if q}
    tau = [{} for _ in range(n)]
    for a in range(n):
        for mu in range(n):
            ep = list(e); ep[a] = Fm.add(e[a], {1 << mu: LAMV})
            with trunc(n, xdeg=xdeg, lam=1): L = Lfun(ep, _inv(ep, xdeg, nv))
            c = lam_part(L.get(FULL, {}))
            if c: tau[a][FULL ^ (1 << mu)] = scale(c, (-1) ** mu)            # dx^mu ^ dx^(hat mu) = (-1)^mu dx^0123
    return tau
def tau_mixed_at0(tau, e, nv=NV):
    """tau_a = tau^b_a Theta_b at the origin: (tau^b_a matrix [b][a], components)"""
    comp = einstein_components(tau, n, nv); e0, E0, det = E0_of(e, n, nv)
    return mixed_from_components(comp, e0, det, n, s=1), comp

# ------------------------------------------------------------------------------------------------ the Noether identity at the point
def noether_at0(Gv, om0, e, field, kind, vc=None, sk=1, sA=1, vol=None, vfac=1, nv=NV, tau=None):
    """[bit] (D tau_a, rhs_a) at the origin (coefficients of dx^0123): rhs = (i_a dphi) EL_phi (scalar) or (i_a F) ^ EL_A (Maxwell); om0 = omega at the origin (A3)"""
    Fm = Gv.Fm
    if kind == 'phi':
        Lf = lambda ep, Ep: L_scalar(Gv, ep, Ep, field, vc, sk, vol=vol)
        src = Fm.d({0: field})
    else:
        src = Fm.d(field); Lf = lambda ep, Ep: L_maxwell(Gv, ep, Ep, src, sA)
    if tau is None: tau = matter_variation(Gv, e, Lf, xdeg=1, nv=nv)
    Dt = Gv.D_covector(om0, tau)
    with trunc(n, xdeg=1):
        E, _ = inverse_series(frame_matrix(e, n), n, nv, 1)
        EL = EL_scalar(Gv, e, E, field, vc, sk, vol=vol, vfac=vfac) if kind == 'phi' else EL_maxwell(Gv, e, E, src, sA)
    EL0 = {m: const(nv, at0(p, nv)) for m, p in EL.items() if at0(p, nv) != 0}
    lhs, rhs = [], []
    for a in range(n):
        xi = [E[mu][a] for mu in range(n)]; ia = FC.interior(Gv, xi, src)
        ia0 = {m: const(nv, at0(p, nv)) for m, p in ia.items() if at0(p, nv) != 0}
        lhs.append(at0(Dt[a].get(FULL, {}), nv)); rhs.append(at0(Fm.wedge(ia0, EL0).get(FULL, {}), nv))
    return lhs, rhs, tau, EL0

# ------------------------------------------------------------------------------------------------ [std] routes (no engine code: plain polynomials, numpy)
def std_T_cs(Gi0, ell, hh=1e-30):
    """[std] T_{mu nu} = (2/sqrt(-g)) d(sqrt(-g) l)/d g^{mu nu}, complex step in each of the 16 entries of g^{mu nu} (ell(G) analytic); returns lower T"""
    G0 = np.array(Gi0, dtype=complex); sg = 1 / np.sqrt(-np.linalg.det(G0.real)); T = np.zeros((4, 4))
    for mu in range(4):
        for nu in range(4):
            G = G0.copy(); G[mu, nu] += 1j * hh; f = ell(G) / np.sqrt(-np.linalg.det(G)); T[mu, nu] = 2 * f.imag / hh / sg
    return T
def std_scalar_Tmix_jet(gi, phi, vc, sk=1, nv=NV):
    """[std] T^mu_nu = s_k g^{mu a} d_a phi d_nu phi - delta (s_k/2 g^{ab} d_a phi d_b phi - V) as 1-jets (plain derivatives)"""
    dp = [sp_der(phi, mu) for mu in range(4)]
    up = [lin(*[(F(1), sp_mul(gi[(mu, al)], dp[al], 1, 4)) for al in range(4)]) for mu in range(4)]
    kin = lin(*[(F(1), sp_mul(up[mu], dp[mu], 1, 4)) for mu in range(4)])
    ell = lin((F(sk, 2), kin), (F(-1), {k: v for k, v in poly_V(phi, vc, nv, mul=lambda a, b: sp_mul(a, b, 1, 4)).items()}))
    return [[lin((F(sk), sp_mul(up[mu], dp[nu], 1, 4)), (F(-1) if mu == nu else F(0), ell)) for nu in range(4)] for mu in range(4)]
def std_F(A):
    return [[padd(sp_der(A.get(1 << nu, {}), mu), sp_der(A.get(1 << mu, {}), nu), -1) for nu in range(4)] for mu in range(4)]
def std_maxwell_Tmix_jet(gi, A, sA=1):
    """[std] T^mu_nu = -s_A F^{mu a} F_{nu a} + (s_A/4) delta F_ab F^ab as 1-jets, F_mn = d_m A_n - d_n A_m"""
    Fl = std_F(A)
    Fu = [[lin(*[(F(1), sp_mul(sp_mul(gi[(mu, al)], gi[(nu, be)], 1, 4), Fl[al][be], 1, 4)) for al in range(4) for be in range(4)]) for nu in range(4)] for mu in range(4)]
    F2 = lin(*[(F(1), sp_mul(Fl[a][b], Fu[a][b], 1, 4)) for a in range(4) for b in range(4)])
    return [[lin(*([(F(-sA), sp_mul(Fu[mu][al], Fl[nu][al], 1, 4)) for al in range(4)] + ([(F(sA, 4), F2)] if mu == nu else []))) for nu in range(4)] for mu in range(4)], Fl, Fu
def christoffel0(g, nv=NV):
    g0 = [[at0(g[(a, b)], nv) for b in range(4)] for a in range(4)]; det, g0i = det_inv(g0)
    dg = lambda k, a, b: at0(sp_der(g[(a, b)], k), nv)
    return {(l, m, v): sum(F(1, 2) * g0i[l][s_] * (dg(m, s_, v) + dg(v, s_, m) - dg(s_, m, v)) for s_ in range(4)) for l in range(4) for m in range(4) for v in range(4)}
def std_div_at0(Tj, Gam, nv=NV):
    """[std] nabla_mu T^mu_nu at the origin (Christoffel symbols Gam[(l, m, v)] = Gamma^l_{mv})"""
    out = []
    for nu in range(4):
        t = sum(at0(sp_der(Tj[mu][nu], mu), nv) for mu in range(4))
        t += sum(Gam[(mu, mu, l)] * at0(Tj[l][nu], nv) for mu in range(4) for l in range(4))
        t -= sum(Gam[(l, mu, nu)] * at0(Tj[mu][l], nv) for mu in range(4) for l in range(4))
        out.append(t)
    return out
def std_frame_mixed(Tmix, e0, E0): return [[sum(e0[b][m] * Tmix[m][v] * E0[v][a] for m in range(4) for v in range(4)) for a in range(4)] for b in range(4)]

# ================================================================================================ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_); Fm = Gv.Fm
    rng = random.Random(20261009)
    VQ = lambda m2, g4: [F(0), F(0), F(m2, 2), F(0), F(g4, 4)]                  # V = m^2 phi^2/2 + g phi^4/4

    # ------------------------------------------------------------------ 1. the 4-forms
    head('1. matter 4-forms with the bit-rule star: dphi ^ *dphi = eta^ab phi_a phi_b vol_e, F ^ *F = (B^2 - E^2) vol_e (random frames, at the point)')
    ok1 = True; ok2 = True
    for _ in range(6):
        e = strong_frame(rng, 0); e0, E0, det = E0_of(e, 4, NV)
        dp = [F(rng.randint(-9, 9)) for _ in range(4)]; phi = lin(*[(dp[mu], var(NV, mu)) for mu in range(4)])
        Ac = {1 << nu: lin(*[(F(rng.randint(-9, 9)), var(NV, mu)) for mu in range(4)]) for nu in range(4)}
        with trunc(4, xdeg=0):
            E = _inv(e, 0, NV); dphi = Fm.d({0: phi}); k1 = Fm.wedge(dphi, H.hodge_form(dphi, e, E, Fm, SQ, NV)); vol = H.vol_form(e, Fm, NV)
            Fc = Fm.d(Ac); k2 = Fm.wedge(Fc, H.hodge_form(Fc, e, E, Fm, SQ, NV)); Fab = H.frame_components(Fc, E, 4)
        pa = [sum(E0[mu][a] * dp[mu] for mu in range(4)) for a in range(4)]
        ok1 &= at0(k1.get(FULL, {}), NV) == (pa[0] ** 2 - sum(x * x for x in pa[1:])) * at0(vol[FULL], NV)
        Fl = {(a, b): at0(Fab.get((1 << a) | (1 << b), {}), NV) for a in range(4) for b in range(a + 1, 4)}
        E2 = sum(Fl[(0, i)] ** 2 for i in (1, 2, 3)); B2 = sum(v ** 2 for (a, b), v in Fl.items() if a > 0)
        ok2 &= at0(k2.get(FULL, {}), NV) == (B2 - E2) * at0(vol[FULL], NV) and E2 != 0
    chk('bit', ok1, 'dphi ^ *dphi = (phi_0^2 - phi_1^2 - phi_2^2 - phi_3^2) vol_e (frame components phi_a = E_a(phi)), 6 random frames: L_phi = ((1/2) eta^ab phi_a phi_b - V) vol_e')
    chk('bit', ok2, 'F ^ *F = (|B|^2 - |E|^2) vol_e (E_i = F_0i, B from F_ij in the frame), 6 random frames: L_A = -(1/2) F ^ *F = (1/2)(E^2 - B^2) vol_e, the (+,-,-,-) textbook sign')
    tick('part 1')

    # ------------------------------------------------------------------ 2. stress by variation, lambda, [std]
    head('2. stress by variation: delta L = h^a ^ tau_a (16 unit h), tau^b_a = lambda T^b_a (g2_hodge stress), [std] complex-step T_mu nu')
    samples = []
    for i in range(6):
        e = strong_frame(rng, 1); phi = strong_poly(rng, 2); A = {1 << nu: strong_poly(rng, 2) for nu in range(4)}
        vc = VQ(rng.randint(0, 9), rng.randint(0, 9)) if i % 2 else [F(rng.randint(-9, 9)) for _ in range(5)]   # general quartic V on even samples
        samples.append((e, phi, A, vc))
    lam_s, lam_m = set(), set(); ok_cs = True; worst = 0.0; rows = []
    for (e, phi, A, vc) in samples:
        e0, E0, det = E0_of(e, 4, NV); Fc = Fm.d(A)
        ts = matter_variation(Gv, e, lambda ep, Ep: L_scalar(Gv, ep, Ep, phi, vc)); tm = matter_variation(Gv, e, lambda ep, Ep: L_maxwell(Gv, ep, Ep, Fc))
        Ts_, _ = tau_mixed_at0(ts, e); Tm_, _ = tau_mixed_at0(tm, e)
        dp = [at0(sp_der(phi, mu), NV) for mu in range(4)]; pa = [sum(E0[mu][a] * dp[mu] for mu in range(4)) for a in range(4)]; p0 = at0(phi, NV)
        Th = H.scalar_T_bit(pa, p0, 0, SQ); Vv = V_num(p0, vc); Th = [[Th[b][a] + (Vv if a == b else 0) for a in range(4)] for b in range(4)]
        with trunc(4, xdeg=0): Fab = H.frame_components(Fc, _inv(e, 0, NV), 4)
        Fl = {(a, b): at0(Fab.get((1 << a) | (1 << b), {}), NV) for a in range(4) for b in range(a + 1, 4)}
        Tmh = H.maxwell_T_bit(H.bivector(Fl, SQ), SQ)
        for Tv, Tt, st in ((Ts_, Th, lam_s), (Tm_, Tmh, lam_m)):
            for a in range(4):
                for b in range(4):
                    if Tt[b][a] != 0: st.add(Tv[b][a] / Tt[b][a])
                    elif Tv[b][a] != 0: st.add(None)
        rows.append((e, phi, A, vc, Ts_, Tm_, Th, Tmh, Fl, pa))
        # [std] complex step on the coordinate Lagrangians
        g0 = [[sum(SQ[a] * e0[a][m] * e0[a][v] for a in range(4)) for v in range(4)] for m in range(4)]; _, gi0 = det_inv(g0)
        Gi = np.array([[float(x) for x in r] for r in gi0]); dpf = np.array([float(x) for x in dp]); Vf = float(Vv)
        Fco = np.array([[float(at0(Fc.get((1 << min(m, v)) | (1 << max(m, v)), {}), NV)) * (1 if m < v else -1) if m != v else 0.0 for v in range(4)] for m in range(4)])
        Tlow_s = std_T_cs(Gi, lambda G: 0.5 * dpf @ G @ dpf - Vf); Tlow_m = std_T_cs(Gi, lambda G: -0.25 * np.einsum('ma,nb,mn,ab->', G, G, Fco, Fco))
        e0f = np.array([[float(x) for x in r] for r in e0]); E0f = np.array([[float(x) for x in r] for r in E0])
        for Tlow, Tv in ((Tlow_s, Ts_), (Tlow_m, Tm_)):
            Tfr = e0f @ (Gi @ Tlow) @ E0f; ref = np.array([[float(-Tv[b][a]) for a in range(4)] for b in range(4)])
            err = np.max(np.abs(Tfr - ref)) / max(1.0, np.max(np.abs(ref))); worst = max(worst, err); ok_cs &= err < 1e-9
    chk('bit', lam_s == {F(-1)}, 'scalar: tau^b_a = lambda T^b_a with ONE lambda on all 16 components of 6 samples (strong random frames and jets, V = m^2 phi^2/2 + g phi^4/4 or a general quartic): lambda = %s' % sorted(lam_s, key=str))
    chk('bit', lam_m == {F(-1)}, 'Maxwell: tau^b_a = lambda T^b_a with T(a) = -1/2 F a F (C3\'s stress, g2_hodge) on all 16 components of 6 samples: lambda = %s (the same lambda as the scalar)' % sorted(lam_m, key=str))
    chk('bit==std', ok_cs, '[std] T_mu nu = (2/sqrt(-g)) d(sqrt(-g) l)/d g^{mu nu} (numpy complex step on the coordinate Lagrangian, 16 entries), carried to the frame, equals -tau^b_a for both fields, 6 samples: worst relative deviation %.1e' % worst)
    ok_sym = all(all(SQ[a] * Ts_[a][b] == SQ[b] * Ts_[b][a] and SQ[a] * Tm_[a][b] == SQ[b] * Tm_[b][a] for a in range(4) for b in range(4)) for (_, _, _, _, Ts_, Tm_, _, _, _, _) in rows)
    chk('bit', ok_sym, 'tau_ab = eta_bb tau^b_a ... is symmetric for both fields on every sample (the variational stress is symmetric without any Lorentz argument, the Lagrangian is Lorentz invariant)')
    # pointwise: an x-dependent h gives no total derivative
    e, phi, A, vc = samples[1]; Fc = Fm.d(A); okp = True
    for Lf in (lambda ep, Ep: L_scalar(Gv, ep, Ep, phi, vc), lambda ep, Ep: L_maxwell(Gv, ep, Ep, Fc)):
        h = [{1 << mu: strong_poly(rng, 1) for mu in range(4)} for _ in range(4)]
        dL = matter_variation(Gv, e, Lf, xdeg=1, h=h); tau = matter_variation(Gv, e, Lf, xdeg=1)
        with trunc(4, xdeg=1): pred = Gv.wedge_sum([(1, h[a], tau[a]) for a in range(4)])
        okp &= form_eq_deg(dL, pred, 1) and any(dL.values())
    chk('bit', okp, 'pointwise: for an x-dependent variation h (random degree-1 coefficients) delta L = h^a ^ tau_a on every coefficient of x-degree <= 1, both fields (no total derivative: L_m is algebraic in e)')
    # controls of part 2
    e, phi, A, vc, Ts_, Tm_, Th, Tmh, Fl, pa = rows[1]
    tE = matter_variation(Gv, e, lambda ep, Ep: L_scalar(Gv, ep, Ep, phi, vc, sq=[1, 1, 1, 1])); TE, _ = tau_mixed_at0(tE, e)
    ratios = set(TE[b][a] / Th[b][a] for a in range(4) for b in range(4) if Th[b][a] != 0) | set('x' for a in range(4) for b in range(4) if Th[b][a] == 0 and TE[b][a] != 0)
    chk('ctl', len(ratios) > 1, 'control: Euclidean squares in the star give a variational stress that is not lambda T (Lorentz) for any single lambda (%d different ratios)' % len(ratios))
    T_noV = H.scalar_T_bit(pa, at0(phi, NV), 0, SQ)
    chk('ctl', any(T_noV[b][a] != -Ts_[b][a] for a in range(4) for b in range(4)), 'control: the stress without the -V delta term (V = %s at the point) differs from -tau' % V_num(at0(phi, NV), vc))
    tick('part 2')

    # ------------------------------------------------------------------ 3. coupling and matter equations
    head('3. coupling: L_grav = (1/2) R_s vol_e; S = L_grav(c) + beta L_m gives E_a + beta tau_a = 0, so beta = -kappa; matter Euler-Lagrange forms (exact jets)')
    e4 = rand_frame(random.Random(3), 4, 2)
    om4, R4 = engine_om_R(Gv, e4, S, 4)
    with trunc(4, xdeg=0):
        Lg = {}
        for (a, b) in itertools.combinations(range(4), 2):
            rest = [x for x in range(4) if x not in (a, b)]; t = Fm.wedge(Fm.wedge(R4[Lie_.idx[(1 << a) | (1 << b)]], e4[rest[0]]), e4[rest[1]])
            Lg = Fm.add(Lg, t, Gv.eps([a, b] + rest))
    g4 = std_metric(e4, 4, SQ, 4); Rr, g0, g0i = std_riemann(g4, 4, 4); _, _, Rs = std_einstein_mixed(Rr, g0, g0i, 4); _, _, det4 = E0_of(e4, 4, 4)
    kfit = at0(Lg.get(FULL, {}), 4) / (Rs * det4)
    chk('bit==std', kfit == F(1, 2) and Rs != 0, 'L_grav(c=0) = sum_{a<b} eps R^{ab} e e = k R_s vol_e with k = %s (R_s = %s from the [std] Christoffel route, random degree-2 frame): L_grav = (1/2) R_s vol_e' % (kfit, Rs))
    print('    coupling: delta_e (L_grav(c) + beta L_m) = h^a ^ (E_a + beta tau_a) (B1 + part 2); with tau_a = -T_a, D1\'s E_a + kappa T_a = 0 is beta = -kappa: S = L_grav(c) - kappa L_m')
    # matter variations as exact jets on a random frame (x-degree <= 1 compared; E to x-degree 2)
    rng3 = random.Random(77); e = strong_frame(rng3, 2); phi = strong_poly(rng3, 3); dphi_v = strong_poly(rng3, 2); vc = [F(rng3.randint(-9, 9)) for _ in range(5)]
    A = {1 << nu: strong_poly(rng3, 3) for nu in range(4)}; dA = {1 << nu: strong_poly(rng3, 2) for nu in range(4)}
    with trunc(4, xdeg=2, lam=1):
        E = _inv(e, 2, NV)
        L = L_scalar(Gv, e, E, padd(phi, pm(LAMV, dphi_v)), vc); EL = EL_scalar(Gv, e, E, phi, vc); st = H.hodge_form(Fm.d({0: phi}), e, E, Fm, SQ, NV)
        Fc = Fm.d(A); FcV = Fm.d(Fm.add(A, Fm.wedge({0: LAMV}, dA))); LA = L_maxwell(Gv, e, E, FcV); ELA = EL_maxwell(Gv, e, E, Fc); stF = H.hodge_form(Fc, e, E, Fm, SQ, NV)
    L1 = {m: lam_part(p) for m, p in L.items()}; rhs = Fm.add(Fm.wedge({0: dphi_v}, EL), Fm.d(Fm.wedge({0: dphi_v}, st)))
    chk('bit', form_eq_deg(L1, rhs, 1) and any(L1.values()), 'scalar: delta_phi L_phi = delta phi EL_phi + d(delta phi *dphi) on every coefficient of x-degree <= 1, EL_phi = -(d*dphi + V\' vol_e) (random frame of degree 2, phi of degree 3, general quartic V)')
    LA1 = {m: lam_part(p) for m, p in LA.items()}; rhsA = Fm.add(Fm.scale(Fm.d(Fm.wedge(dA, stF)), -1), Fm.wedge(dA, ELA))
    chk('bit', form_eq_deg(LA1, rhsA, 1) and any(LA1.values()), 'Maxwell: delta_A L_A = -d(delta A ^ *F) + delta A ^ EL_A, EL_A = -d*F, on every coefficient of x-degree <= 1: the field equation is d*F = 0')
    rhs_bad = Fm.add(Fm.wedge({0: dphi_v}, EL), Fm.d(Fm.wedge({0: dphi_v}, st)), -1)
    chk('ctl', not form_eq_deg(L1, rhs_bad, 1), 'control: the total derivative with the wrong sign (-d(delta phi *dphi)) fails')
    # [std] box_g phi
    g = std_metric(e, 4, SQ, NV, 2); gi, g0, g0i = std_inverse_metric(g, 4, NV, 1); Gam = christoffel0(g); e0, E0, det = E0_of(e, 4, NV)
    d1p = [at0(sp_der(phi, m), NV) for m in range(4)]; d2p = [[at0(sp_der(sp_der(phi, m), v), NV) for v in range(4)] for m in range(4)]
    box = sum(g0i[m][v] * (d2p[m][v] - sum(Gam[(l, m, v)] * d1p[l] for l in range(4))) for m in range(4) for v in range(4))
    Vp0 = V_num(at0(phi, NV), dV(vc))
    chk('bit==std', at0(EL.get(FULL, {}), NV) == -(box + Vp0) * det, 'EL_phi at the point = -(box_g phi + V\') vol_e with box_g phi = g^{mn}(d_m d_n phi - Gamma^l_mn d_l phi) from Christoffel symbols [std] (d*dphi = (box_g phi) vol_e)')
    tick('part 3')

    # ------------------------------------------------------------------ 4. Noether identity (off shell), strong sampler
    head('4. Noether identity off shell: D tau_a = alpha (i_a dphi) EL_phi and D tau_a = alpha\' (i_a F) ^ EL_A (strong sampler: coefficients uniform in [-9, 9], density 1, 3 seeds)')
    alpha_s, alpha_m = set(), set(); ok_std = True; nz = True; ok_stdid = True; NS = []
    for seed in (101, 202, 303):
        rr = random.Random(seed); e = strong_frame(rr, 1); phi = strong_poly(rr, 2); A = {1 << nu: strong_poly(rr, 2) for nu in range(4)}
        vc = [F(rr.randint(-9, 9)) for _ in range(5)]
        om0 = omega_closed_form(Gv, e, S, NV, 0)[0]
        ls, rs, tau_s, ELs = noether_at0(Gv, om0, e, phi, 'phi', vc); lm, rm, tau_m, ELm = noether_at0(Gv, om0, e, A, 'A')
        NS.append((seed, e, phi, A, vc, om0, ls, rs, lm, rm, tau_s))
        for a in range(4):
            if rs[a] != 0: alpha_s.add(ls[a] / rs[a])
            elif ls[a] != 0: alpha_s.add(None)
            if rm[a] != 0: alpha_m.add(lm[a] / rm[a])
            elif lm[a] != 0: alpha_m.add(None)
        nz &= any(ls) and any(lm)
        # [std]: D tau_a = -(nabla_b T^b_a) vol_e,  nabla_mu T^mu_nu by exact Christoffel symbols
        g = std_metric(e, 4, SQ, NV, 2); gi, g0, g0i = std_inverse_metric(g, 4, NV, 1); Gam = christoffel0(g); e0, E0, det = E0_of(e, 4, NV)
        Tj = std_scalar_Tmix_jet(gi, phi, vc); div_s = std_div_at0(Tj, Gam)
        TjA, Fl, Fu = std_maxwell_Tmix_jet(gi, A); div_m = std_div_at0(TjA, Gam)
        pred_s = [-det * sum(E0[v][a] * div_s[v] for v in range(4)) for a in range(4)]; pred_m = [-det * sum(E0[v][a] * div_m[v] for v in range(4)) for a in range(4)]
        ok_std &= (pred_s == ls) and (pred_m == lm)
        d1p = [at0(sp_der(phi, m), NV) for m in range(4)]; d2p = [[at0(sp_der(sp_der(phi, m), v), NV) for v in range(4)] for m in range(4)]
        box = sum(g0i[m][v] * (d2p[m][v] - sum(Gam[(l, m, v)] * d1p[l] for l in range(4))) for m in range(4) for v in range(4)); Vp0 = V_num(at0(phi, NV), dV(vc))
        divF = [sum(at0(sp_der(Fu[m][al], m), NV) for m in range(4)) + sum(Gam[(m, m, l)] * at0(Fu[l][al], NV) for m in range(4) for l in range(4)) for al in range(4)]
        ok_stdid &= all(div_s[v] == (box + Vp0) * d1p[v] for v in range(4)) and all(div_m[v] == -sum(divF[al] * at0(Fl[v][al], NV) for al in range(4)) for v in range(4))
    chk('bit', alpha_s == {F(1)} and nz, 'scalar: D tau_a = alpha (i_a dphi) EL_phi at the point, all a, 3 seeds (frame 1-jet, phi 2-jet, general quartic V; omega from A3): alpha = %s' % sorted(alpha_s, key=str))
    chk('bit', alpha_m == {F(1)} and nz, 'Maxwell: D tau_a = alpha\' (i_a F) ^ EL_A, EL_A = -d*F, F = dA, all a, 3 seeds (A 2-jet): alpha\' = %s' % sorted(alpha_m, key=str))
    chk('bit==std', ok_std, '[std] the engine\'s D tau_a (D_covector, h table) = -(nabla_b T^b_a) vol_e with nabla_mu T^mu_nu from exact Christoffel symbols and plain derivatives, both fields, all a, 3 seeds')
    chk('std', ok_stdid, '[std] nabla_mu T^mu_nu = (box phi + V\') d_nu phi and nabla_mu T^mu_nu = -(nabla_m F^{m a}) F_{nu a} (Christoffel route, the textbook form of the same identities), 3 seeds')
    # on shell at the point: choose the x0^2 coefficient of phi so that EL_phi = 0 there
    seed, e, phi, A, vc, om0, ls, rs, lm, rm, _ = NS[0]; key = (2, 0, 0, 0, 0)
    E = None
    def EL0_of(ph):
        with trunc(4, xdeg=1): EE = _inv(e, 1, NV); X = EL_scalar(Gv, e, EE, ph, vc)
        return at0(X.get(FULL, {}), NV)
    b0 = EL0_of(padd(phi, {key: -phi.get(key, F(0))})); b1 = EL0_of(padd(padd(phi, {key: -phi.get(key, F(0))}), {key: F(1)}))
    cstar = -b0 / (b1 - b0); phi_on = padd(padd(phi, {key: -phi.get(key, F(0))}), {key: cstar})
    l_on, r_on, _, ELon = noether_at0(Gv, om0, e, phi_on, 'phi', vc)
    chk('bit', not any(ELon.values()) and all(x == 0 for x in l_on) and any(ls), 'on shell at the point: with the x0^2 coefficient of phi set to %s, EL_phi = 0 there and D tau_a = 0 for every a exactly (off shell D tau_a = %s): conservation and the matter equation go together' % (cstar, [str(x) for x in ls]))
    # Maxwell on shell: solve d*F = 0 at the point for four second-derivative coefficients of A
    keys = [(1 << 0, (0, 2, 0, 0, 0)), (1 << 1, (2, 0, 0, 0, 0)), (1 << 2, (2, 0, 0, 0, 0)), (1 << 3, (2, 0, 0, 0, 0))]
    def setA(vals):
        B = {m: dict(p) for m, p in A.items()}
        for (m, k), v in zip(keys, vals): B[m][k] = v
        return {m: {k: v for k, v in p.items() if v != 0} for m, p in B.items()}
    def ELA0(vals):
        with trunc(4, xdeg=1): EE = _inv(e, 1, NV); X = EL_maxwell(Gv, e, EE, Fm.d(setA(vals)))
        return [at0(X.get(FULL ^ (1 << mu), {}), NV) for mu in range(4)]
    base = ELA0([F(0)] * 4); cols = [[x - y for x, y in zip(ELA0([F(int(i == j)) for i in range(4)]), base)] for j in range(4)]
    sol = solve_exact([[cols[j][i] for j in range(4)] for i in range(4)], [-x for x in base])[0]
    okA = False
    if sol is not None:
        lA, rA, _, ELA_on = noether_at0(Gv, om0, e, setA(sol), 'A'); okA = not any(ELA_on.values()) and all(x == 0 for x in lA) and any(lm)
    chk('bit', okA, 'Maxwell on shell at the point (four second-derivative coefficients of A solved so that d*F = 0 there): D tau_a = 0 for every a exactly')
    # controls of part 4
    ok_vol = True; ok_v2 = True; ok_om = True
    for (seed, e, phi, A, vc, om0, ls, rs, lm, rm, tau_s) in NS:
        vol0 = {FULL: const(NV, 1)}
        lv, rv, _, _ = noether_at0(Gv, om0, e, phi, 'phi', vc, vol=vol0)
        with trunc(4, xdeg=1): EE = _inv(e, 1, NV)
        ia = [at0(FC.interior(Gv, [EE[mu][a] for mu in range(4)], Fm.d({0: phi})).get(0, {}), NV) for a in range(4)]
        pred = [V_num(at0(phi, NV), dV(vc)) * ia[a] for a in range(4)]
        ok_vol &= [x - y for x, y in zip(lv, rv)] == pred and any(pred)
        l2, r2, _, _ = noether_at0(Gv, om0, e, phi, 'phi', vc, vfac=2, tau=tau_s); ok_v2 &= any(x != y for x, y in zip(l2, r2))
        lz, rz, _, _ = noether_at0(Gv, [{} for _ in range(Gv.G)], e, phi, 'phi', vc, tau=tau_s); ok_om &= any(x != y for x, y in zip(lz, rz))
    chk('ctl', ok_vol, 'control: fixed coordinate volume dx^0123 in the V term (not diffeomorphism invariant): the Noether identity fails by exactly (i_a dV) dx^0123 = V\'(phi) phi_a dx^0123, all a, 3 seeds')
    chk('ctl', ok_v2, 'control: EL_phi with 2 V\' in place of V\': D tau_a != (i_a dphi) EL, 3 seeds')
    chk('ctl', ok_om, 'control: omega = 0 in D (the frame is not flat): the identity fails, 3 seeds')
    tick('part 4')

    # ------------------------------------------------------------------ 5. sign chain
    head('5. sign chain: T^0_0 = -tau^0_0 >= 0 (physical signs), D1 ball: attraction; flipped kinetic sign: negative energy, repulsion')
    rng5 = random.Random(55); ok_pos = True; ok_mpos = True; ok_ghost = True; ok_mghost = True; nstat = 0; rho_static = None; rho_ghost = None
    for i in range(24):
        e = strong_frame(rng5, 0); static = i % 2 == 0
        dp = [F(0) if (static and mu == 0) else F(rng5.randint(-9, 9)) for mu in range(4)]; p0 = F(rng5.randint(-9, 9))
        phi = lin((p0, const(NV, 1)), *[(dp[mu], var(NV, mu)) for mu in range(4)]); vc = VQ(rng5.randint(0, 9), rng5.randint(0, 9))
        A = {1 << nu: lin(*[(F(rng5.randint(-9, 9)), var(NV, mu)) for mu in range(4)]) for nu in range(4)}; Fc = Fm.d(A)
        Ts_, _ = tau_mixed_at0(matter_variation(Gv, e, lambda ep, Ep: L_scalar(Gv, ep, Ep, phi, vc)), e)
        Tm_, _ = tau_mixed_at0(matter_variation(Gv, e, lambda ep, Ep: L_maxwell(Gv, ep, Ep, Fc)), e)
        e0, E0, det = E0_of(e, 4, NV); pa = [sum(E0[mu][a] * dp[mu] for mu in range(4)) for a in range(4)]
        ok_pos &= -Ts_[0][0] == sum(x * x for x in pa) / 2 + V_num(p0, vc) and -Ts_[0][0] >= 0
        ok_mpos &= -Tm_[0][0] > 0
        nstat += static
        if i < 12:
            Tg, _ = tau_mixed_at0(matter_variation(Gv, e, lambda ep, Ep: L_scalar(Gv, ep, Ep, phi, [F(0)], sk=-1)), e)
            ok_ghost &= -Tg[0][0] == -sum(x * x for x in pa) / 2 and -Tg[0][0] < 0
            Tmg, _ = tau_mixed_at0(matter_variation(Gv, e, lambda ep, Ep: L_maxwell(Gv, ep, Ep, Fc, sA=-1)), e)
            ok_mghost &= -Tmg[0][0] < 0
        if i == 0:
            rho_static = -Ts_[0][0]; rho_ghost = -Tg[0][0]
    chk('bit', ok_pos, 'scalar energy density T^0_0 = -tau^0_0 = (1/2) sum_a phi_a^2 + V >= 0 exactly on 24 samples (%d static: d_t phi = 0; random frames; V = m^2 phi^2/2 + g phi^4/4, m^2, g in 0..9)' % nstat)
    chk('bit', ok_mpos, 'Maxwell energy density T^0_0 = -tau^0_0 > 0 on the same 24 frames (random F)')
    chk('ctl', ok_ghost, 'control: flipped kinetic sign (L = -(1/2) dphi ^ *dphi, V = 0): T^0_0 = -(1/2) sum phi_a^2 < 0 on 12 samples')
    chk('ctl', ok_mghost, 'control: flipped Maxwell sign (+(1/2) F ^ *F): T^0_0 < 0 on 12 samples')
    import d1_newtonian_limit as D1                                            # only its pure helpers (frame_lam, mono); its own engine objects are not used
    def ball(q, xc):
        P = {}
        for i in range(3):
            ex2 = [0, 0, 0]; ex2[i] = 2; ex1 = [0, 0, 0]; ex1[i] = 1
            P = padd(P, D1.mono(tuple(ex2)), q / 12); P = padd(P, D1.mono(tuple(ex1)), -2 * xc[i] * q / 12)
        return padd(P, D1.mono((0, 0, 0)), q / 12 * sum(c * c for c in xc))
    def engine_ball(q, xc):
        e = D1.frame_lam(ball(q, xc), ball(q, xc))
        with trunc(4, xdeg=1, lam=1):
            om = omega_closed_form(Gv, e, S, NV, 1)[0]; R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(0))
            E, _ = inverse_series(frame_matrix(e, 4), 4, NV, 1); acc = [{} for _ in range(4)]
            for (Aa, b), (cc, hv) in Gv.L.h.items():
                if b == 0 and om[Aa].get(1, {}): acc[cc] = padd(acc[cc], pm(om[Aa][1], E[0][0]), -hv)
        comp = {(a, mu): at_lam(Ea[a].get(FULL ^ (1 << mu), {}), 4, NV, 1) for a in range(4) for mu in range(4)}
        return comp, [at_lam(acc[c_], 4, NV, 1) for c_ in range(4)]
    xc = (F(1), F(2), F(-1)); kap = F(1)
    res = {}
    for name, rho in (('physical', rho_static), ('ghost', rho_ghost)):
        q = kap * rho; comp, acc = engine_ball(q, xc); res[name] = (rho, comp, acc)
    rp, cp, ap = res['physical']; rg, cg, ag = res['ghost']
    okE = all(cp[k] == (-kap * rp if k == (0, 0) else 0) for k in cp) and all(cg[k] == (-kap * rg if k == (0, 0) else 0) for k in cg)
    chk('bit', okE, 'D1 ball with the density of sample 0 (rho = %s, ghost rho = %s, kappa = 1): the engine\'s E_0 = -kappa rho Theta_0 and no other component at order lam: E_a + kappa T_a = 0 with T_0 = rho Theta_0' % (rp, rg))
    dotp = sum(ap[i + 1] * xc[i] for i in range(3)); dotg = sum(ag[i + 1] * xc[i] for i in range(3))
    chk('bit', ap[1:] == [kap * rp / 6 * c for c in xc] and dotp > 0, 'physical sign: the free-fall acceleration of a particle at rest at the origin (engine omega, D_vector entries) is (kappa rho/6) x_c, toward the centre x_c = %s: a . x_c = %s > 0 (attraction)' % ([str(c) for c in xc], dotp))
    chk('ctl', dotg < 0, 'control (ghost): with the flipped kinetic sign rho < 0 and the acceleration points away from the centre: a . x_c = %s < 0 (repulsion)' % dotg)
    tick('part 5')

    # ------------------------------------------------------------------ 6. Maxwell on Reissner-Nordstrom with the variational stress
    head('6. Reissner-Nordstrom (C3\'s frames and points): E_a = kappa tau_a with kappa = 4 s/Q^2, tau from the variation (no refit)')
    import c3_rn
    ok_rn = True; ok_bad = True; npair = 0
    for si, (M, s, Q) in enumerate(c3_rn.SAMPLES):
        for pi_, (p, rho0) in enumerate(c3_rn.POINTS):
            pt, e4_, E4_ = c3_rn.frame_at(p, rho0, M, s); A4 = c3_rn.coulomb_A(pt, F(rho0), Q, 1)
            _, compE = c3_rn.einstein_on_frame(Gv, S, e4_)
            e5 = [lift_form(x) for x in e4_]; Fc = lift_form(Fm.d(A4))
            tau = matter_variation(Gv, e5, lambda ep, Ep: L_maxwell(Gv, ep, Ep, Fc)); compT = einstein_components(tau, 4, NV)
            kap = 4 * s / Q ** 2; npair += 1
            ok_rn &= all(compE[k] == kap * compT[k] for k in compE) and any(compT.values())
            ok_bad &= any(compE[k] + kap * compT[k] != 0 for k in compE)
    chk('bit', ok_rn, 'E_a(c=0) = kappa tau_a, kappa = 4 s/Q^2, on all 16 components at %d (sample, point) pairs of C3 (4 samples (M, s, Q) x 7 points), tau from the variation of -(1/2) F ^ *F: the RN relation s = kappa Q^2/4 with a derived stress' % npair)
    chk('ctl', ok_bad, 'control: the wrong relative sign of the action (beta = +kappa, field equation E_a + kappa tau_a = 0) fails at every pair')
    tick('part 6')
    finish('B3')

def form_eq_deg(X, Y, deg, nn=n):
    """X == Y on every coefficient of x-degree <= deg"""
    for m in set(X) | set(Y):
        a = {k: v for k, v in X.get(m, {}).items() if sum(k[:nn]) <= deg}; b = {k: v for k, v in Y.get(m, {}).items() if sum(k[:nn]) <= deg}
        if a != b: return False
    return True

if __name__ == '__main__': main()
