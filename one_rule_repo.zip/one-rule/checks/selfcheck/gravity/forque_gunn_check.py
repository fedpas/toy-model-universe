#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Free-top equations of three PGA sources against the step-14 code (exact fractions, power series in t).
 A  Gunn, 'Projective geometric algebra: a new framework for doing euclidean geometry' (arXiv 1901.05873v2), p. 12, eqs (1)-(2):   g' = g Omega,   Omega' = 2 A^-1 (A(Omega) x Omega),   x = <.>_2.
    Against step 14 (May the Forque Be with You):   M' = -(1/2) M B,   B' = I^-1 (B x I[B]).   The map: B = -2 Omega, M = g.
 B  the counts on p. 12: even subalgebra 8, bivectors 6, g g~ = 1 has 2 conditions (solution space 6 + 6 = 12, integration space 8 + 6 = 14); normalising g.
 D  Li and Ding (Sci. China Tech. Sci. 2026, 69(10)), eqs (7)-(13), in the inertial frame:  X = N~ X0 N,  V = 2 N~ N',  w = I(V') + I(V) x V,  I(.) = sum m P v (P x .)."""
import os, sys, random
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))   # selfcheck/ of the package, the parent of this folder
import forque_selfcheck as fq
from forque_selfcheck import Alg, MV, Ser, picard, bil_ser, lin_ser, comm_ser, ser_equal, ser_vanish, generic_body
FAILS = []
def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond: FAILS.append(msg)
def cross2(X, Y): return (X * Y).grade(2)                      # Omega x Sigma := <Omega Sigma>_2   (Gunn p. 11)
N = 7

def part_A():
    print('\nA  Gunn eqs (1)-(2) against step 14')
    A = Alg(3); rng = random.Random(3)
    ok = all(cross2(X, Y) == A.comm(X, Y) for X, Y in ((A.rand_bivector(rng), A.rand_bivector(rng)) for _ in range(20)))
    check(ok, 'the product <Omega Sigma>_2 of two bivectors equals the commutator (1/2)(Omega Sigma - Sigma Omega) of step 14, 20 random pairs, exactly')
    same = []; neg = []
    for seed in (1, 2, 3):
        rng = random.Random(seed); body = generic_body(A, rng, 4); M0 = A.rand_motor(rng); B0 = A.rand_bivector_nz(rng)
        def fP(S):
            M, B = S; return [(M * B).scale(F(-1, 2)), lin_ser(body.Iinv, comm_ser(A, B, lin_ser(body.I, B)))]
        M, B = picard(fP, [M0, B0], N)
        def fG(S, sign=1):
            g, Om = S; AOm = lin_ser(body.I, Om); return [g * Om, lin_ser(body.Iinv, bil_ser(cross2, AOm, Om)).scale(2 * sign)]
        g, Om = picard(fG, [M0, B0.scale(F(-1, 2))], N)
        same.append(ser_equal(g, M, N - 1) and ser_equal(Om.scale(-2), B, N - 1))
        gn, Omn = picard(lambda S: fG(S, -1), [M0, B0.scale(F(-1, 2))], N)
        neg.append(not ser_equal(Omn.scale(-2), B, N - 1))
        nontriv = any(not c.is_zero() for c in B.d_dt().c[:N - 2])
    check(all(same), "with g = M and Omega = -B/2 the two systems give the same motor and the same velocity as exact series through order %d (3 random bodies of 4 mass points): Gunn's free top IS step 14's free top" % (N - 1))
    check(nontriv, 'the test is not vacuous: the body-frame velocity B changes with time (a tumbling body)')
    check(all(neg), 'control: with the sign of the commutator term reversed, Gunn\'s equation gives a different flow (3 of 3)')

def part_B():
    print('\nB  the counts on p. 12 of the overview')
    A = Alg(3); ev = [m for m in range(16) if bin(m).count('1') % 2 == 0]
    check(len(ev) == 8 and len(A.bivectors()) == 6, 'even subalgebra of Cl(3,0,1): 8 components; bivectors: 6')
    cols = [(MV(A.sq, {m: F(1)}) + MV(A.sq, {m: F(1)}).rev()) for m in ev]; masks = sorted({k for c in cols for k in c.d})
    rk = fq.rank([[c.d.get(k, F(0)) for c in cols] for k in masks]) if masks else 0
    check(rk == 2, 'the map delta -> delta + delta~ (the derivative of g g~ at g = 1) has rank %d: g g~ = 1 is 2 conditions, so the motors form a 6-dimensional set; solution space 6 + 6 = 12, integration space 8 + 6 = 14' % rk)
    rng = random.Random(5); okg = True
    for _ in range(10):
        gg = MV(A.sq, {m: F(rng.randint(-3, 3)) for m in ev}); p = gg * gg.rev(); okg &= p.grades() <= {0, 4}
    check(okg, 'g g~ of a random even element has only grades 0 and 4 (a + b I): exactly the two conditions')
    # normalisation: pythagorean quadruple (s, b12, b23, b31) with s^2 + b12^2 + b23^2 + b31^2 a perfect square
    good = 0; tot = 0
    for (s, x, y, z, lam) in ((1, 2, 2, 0, 3), (2, 3, 6, 0, 7), (1, 4, 8, 0, 9), (4, 4, 7, 0, 9), (2, 6, 9, 0, 11)):
        for ideal in ((F(1), F(2), F(-1), F(3), F(1, 2)), (F(0), F(1), F(1), F(1), F(-2))):
            gg = MV(A.sq, {0: F(s), A.E('12').d and next(iter(A.E('12').d)): F(x), next(iter(A.E('23').d)): F(y), next(iter(A.E('31').d)): F(z) * 1})
            gg = gg + MV(A.sq, {next(iter(A.E('01').d)): ideal[1], next(iter(A.E('02').d)): ideal[2], next(iter(A.E('03').d)): ideal[3], A.full: ideal[4]})
            p = gg * gg.rev(); a = p.scalar(); b = p.d.get(A.full, F(0))
            assert a == lam * lam, (a, lam)
            sroot = MV(A.sq, {0: F(1, lam), A.full: -b / (2 * a * lam)})
            g2 = gg * sroot; tot += 1; good += (g2 * g2.rev() == A.one())
    check(good == tot, "normalising: g' = g (a + bI)^(-1/2), with (a + bI)^(-1/2) = a^(-1/2)(1 - (b/2a) I), gives g' g'~ = 1 exactly (%d of %d random even elements): the 'normalise g to return to the solution space' of p. 12" % (good, tot))

def part_D():
    print('\nD  Li and Ding, inertial-frame form  w = I(V\') + I(V) x V')
    A = Alg(3); allv = []; allfree = []; allgrav = []; negs = []; mom = []; nonv = []; wrongframe = []
    for kind in ('free', 'gravity'):
        for seed in (1, 2):
            rng = random.Random(seed); body = generic_body(A, rng, 4); M0 = A.rand_motor(rng); B0 = A.rand_bivector_nz(rng)
            gvec = A.vec([F(0), F(-1), F(0)]); gI = gvec * A.I; Cb = A.point(body.c)
            def Fb(S):
                if kind == 'free': return Ser.const(A.zero(), N)
                gb = S[0].rev() * Ser.const(gI, N) * S[0]; return bil_ser(A.join, Ser.const(Cb, N), gb).scale(body.m)
            def f(S):
                M, B = S; IB = lin_ser(body.I, B); rhs = comm_ser(A, B, IB) + Fb(S)
                return [(M * B).scale(F(-1, 2)), lin_ser(body.Iinv, rhs)]
            M, B = picard(f, [M0, B0], N)
            Nser = M.rev(); Ntil = M; V = (Ntil * Nser.d_dt()).scale(2)             # Li and Ding: N = M~ (X = N~ X0 N = M X0 M~), V = 2 N~ N'
            allv.append(all(c.grades() <= {2} for c in V.c[:N - 1]) and ser_equal(V, M * B * M.rev(), N - 2))
            Xs = [M * Ser.const(X, N) * M.rev() for X in body.X]
            def It(Y):
                tot = Ser.const(A.zero(), N)
                for (m, _), X in zip(body.pts, Xs): tot = tot + bil_ser(A.join, X, comm_ser(A, X, Y)).scale(m)
                return tot
            IV = It(V); lhs = It(V.d_dt()) + comm_ser(A, IV, V)
            if kind == 'free': w = Ser.const(A.zero(), N)
            else:
                w = Ser.const(A.zero(), N)
                for (m, _), X in zip(body.pts, Xs): w = w + bil_ser(A.join, X, Ser.const(gI, N)).scale(m)
            ok = ser_equal(lhs, w, N - 3); (allfree if kind == 'free' else allgrav).append(ok)
            mom.append(ser_equal(IV, M * lin_ser(body.I, B) * M.rev(), N - 3))
            bad = It(V.d_dt()) - comm_ser(A, IV, V); negs.append(not ser_equal(bad, w, N - 3))
            nonv.append(any(not c.is_zero() for c in comm_ser(A, IV, V).c[:N - 3]) and (kind == 'free' or any(not c.is_zero() for c in w.c[:N - 3])))
            bodyv = It(B.d_dt()) + comm_ser(A, It(B), B); wrongframe.append(not ser_equal(bodyv, w, N - 3))        # the same formula with the body velocity B in place of V
    check(all(allv), "V = 2 N~ N' (N = M~, the motor of the paper's X = N~ X0 N) is a bivector and equals M B M~, the body velocity carried to the inertial frame (4 cases, exact series)")
    check(all(mom), 'I(V) with the moving inertia operator (points X_i(t) = M X_i0 M~) equals the momentum M I_b[B] M~ of step 14')
    check(all(allfree), "free body: I(V') + I(V) x V = 0 exactly (series, 2 bodies): their eq. (13) holds on step 14's free flow")
    check(all(allgrav), 'body in a uniform field: I(V\') + I(V) x V = w with w = sum m_i X_i v (g I), the weight forque, exactly (series, 2 bodies)')
    check(all(nonv), 'the test is not vacuous: I(V) x V is nonzero along the flow in all 4 cases, and w is nonzero in the field cases')
    check(all(negs), 'control: with the sign of the I(V) x V term reversed, eq. (13) fails (4 of 4)')
    check(all(wrongframe), 'control: the same formula with the body-frame velocity B in place of the inertial-frame V fails (4 of 4): the paper\'s equation is the inertial-frame one')

if __name__ == '__main__':
    which = sys.argv[1:] or ['A', 'B', 'D']
    if 'A' in which: part_A()
    if 'B' in which: part_B()
    if 'D' in which: part_D()
    print('\nFAILS:', FAILS if FAILS else 'none'); sys.exit(1 if FAILS else 0)
