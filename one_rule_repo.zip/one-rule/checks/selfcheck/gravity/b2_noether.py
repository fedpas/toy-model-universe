#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""B2.  Noether identities of the Einstein-Cartan action, read off B1's first-variation formula.   python3 b2_noether.py [n ...]   (default 3 4 5; MM part when 4 is in the list)

 B1:  dL = de^a ^ E_a(c) + dom^A ^ Theta_A + d(dom^A ^ Y_A)   (A = pair a<b, Y_A = eps(a,b,rest) e^rest, Theta_A = D Y_A), any e, omega (torsion allowed).
 Lorentz:  de^c = -h_Ab^c lam^A e^b, dom = D lam  (the engine's local Lorentz variation) gives dL = 0, hence (fitted, then verified on fresh seeds)
           (D Theta)_ab = alpha e_a ^ E_b + beta e_b ^ E_a,  e_a = sq_a e^a,  D on a lower bivector index (g2_forms_calc.D_dual_bivector).
 Diffeomorphisms (L_xi = d i_xi + i_xi d, g2_forms_calc):  (i) dL along (L_xi e, L_xi om) = d(i_xi L);  (ii) L_xi e^a = D xi^a + i_xi T^a - h (i_xi om) e,  L_xi om = i_xi R + D(i_xi om);
           (iii) J: i_xi L = xi^a E_a + (i_xi R^A) ^ Y_A;   N: xi^a (D E)_a = (i_xi T^b) ^ E_b + (i_xi R^A) ^ Theta_A  (coefficients fitted), and N's right side = xi^a einstein_rhs_a (step 10).
 [std]  plain-polynomial component formulas (Lie derivative, textbook Lorentz variation) compared exactly; numpy (B1's Std + antisymmetric arrays, five-point stencils) at points.
 Controls: a fixed background vector, the rotation term dropped, the right contraction, Euclidean signs, dom = -D lam, N without one of its terms."""
import sys, os, time, math, itertools, random
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from b1lib import *
import b1_first_variation as B1
import g2_forms_calc as FC
from g2_forms_calc import interior, lie, frame_comps, D_dual_bivector, rand_vec, coord_vec, form_eq, lie_std
import numpy as np

T0 = time.time()
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
def nz(X): return any(p for p in X.values())
def pf(Fm, p, X): return Fm.wedge({0: p}, X) if p else {}
def wsum(Fm, pairs):
    r = {}
    for X, Y in pairs: r = Fm.add(r, Fm.wedge(X, Y))
    return r
def lin_forms(Fm, terms):
    r = {}
    for c, X in terms: r = Fm.add(r, X, c)
    return r
def add_rows(rows, rhs, basis, target):
    keys = set()
    for X in basis + [target]:
        for m, p in X.items():
            for k in p: keys.add((m, k))
    for (m, k) in sorted(keys):
        rows.append([X.get(m, {}).get(k, F(0)) for X in basis]); rhs.append(target.get(m, {}).get(k, F(0)))
CTL = {}
def ctl(key, wrong_fails):
    k = CTL.setdefault(key, [0, 0]); k[1] += 1; k[0] += int(bool(wrong_fails))

def lorentz_var(Gv, e, om, lam, sign_om=1, htab=None):
    """the engine's local Lorentz variation: de^c = -h_Ab^c lam^A e^b, dom = D lam (sign_om = -1: a control; htab: another h table, a control)"""
    Fm = Gv.Fm; de = [{} for _ in range(Gv.n)]
    for (A, b), (c, h) in (htab or Gv.L.h).items(): de[c] = Fm.add(de[c], Fm.wedge(lam[A], e[b]), -h)
    dom = Gv.D_bivector(om, lam)
    return de, ([Fm.scale(x, sign_om) for x in dom] if sign_om != 1 else dom)
def by_A(Gv, d): return [d[p] for p in pairs_of(Gv.L)]

# ------------------------------------------------------------------------------------------------ [std] exact plain-polynomial textbook Lorentz variation
def std_lorentz_var(n, sq, e, om, lam_text):
    """de^a = l^a_b e^b = l^{ab} sq_b e^b,  dom^{ab} = -(d l^{ab} + om^a_c l^{cb} + om^b_c l^{ac}),  om^a_c = om^{ac} sq_c;  l antisymmetric polynomials (index pairs a<b)"""
    P = [(a, b) for a in range(n) for b in range(a + 1, n)]; pidx = {p: i for i, p in enumerate(P)}
    def l(a, b):
        if a == b: return {}
        return lam_text[pidx[(a, b)]] if a < b else {k: -v for k, v in lam_text[pidx[(b, a)]].items()}
    def w(a, b, mu):                                           # om^{ab}_mu
        if a == b: return {}
        p = om[pidx[(min(a, b), max(a, b))]].get(1 << mu, {})
        return p if a < b else {k: -v for k, v in p.items()}
    de = []
    for a in range(n):
        form = {}
        for mu in range(n):
            t = {}
            for b in range(n): t = FC._add(t, FC._mul(l(a, b), e[b].get(1 << mu, {})), sq[b])
            if t: form[1 << mu] = t
        de.append(form)
    dom = []
    for (a, b) in P:
        form = {}
        for mu in range(n):
            t = FC._der(l(a, b), mu)
            for c in range(n):
                t = FC._add(t, FC._mul(w(a, c, mu), l(c, b)), sq[c]); t = FC._add(t, FC._mul(w(b, c, mu), l(a, c)), sq[c])
            t = {k: -v for k, v in t.items()}
            if t: form[1 << mu] = t
        dom.append(form)
    return de, dom

class Std9(B1.Std):
    """B1's Std with a nine-point central stencil (exact for polynomials of degree <= 8; B1's five-point stencil is exact to degree 4 only)"""
    W9 = [(1, 4. / 5), (2, -1. / 5), (3, 4. / 105), (4, -1. / 280)]
    def grad(self, f, x, h=0.05):
        out = []
        for k in range(self.n):
            u = np.zeros(self.n); u[k] = h; out.append(sum(w * (f(x + j * u) - f(x - j * u)) for j, w in self.W9) / h)
        return np.array(out)

# ------------------------------------------------------------------------------------------------ [std] numpy antisymmetric arrays (components A_{m1..mp}, form = (1/p!) A dx..dx)
def np_alt(X, degs):
    out = np.zeros_like(X)
    for perm in itertools.permutations(range(X.ndim)): out += B1.perm_sign(perm) * np.transpose(X, perm)
    return out / float(np.prod([math.factorial(d) for d in degs]))
def np_wedge(A, B): return np_alt(np.multiply.outer(A, B), (A.ndim, B.ndim))
def np_einstein(S, y, c):
    R, T, e, om = S.curv_tors(y); n = S.n; out = []
    for a in range(n):
        tot = np.zeros((n,) * (n - 1))
        for b, cc in itertools.combinations(range(n), 2):
            if a in (b, cc): continue
            rest = [d for d in range(n) if d not in (a, b, cc)]; form = R[b, cc] + c * (np.outer(e[b], e[cc]) - np.outer(e[cc], e[b]))
            for d in rest: form = np_wedge(form, e[d])
            tot = tot + B1.perm_sign([a, b, cc] + rest) * form
        out.append(tot)
    return np.stack(out)
def np_Y(S, y):
    e = S.fields(y)[0]; n = S.n; Y = np.zeros((n, n) + (n,) * (n - 2))
    for a, b in itertools.combinations(range(n), 2):
        rest = [d for d in range(n) if d not in (a, b)]; form = e[rest[0]]
        for d in rest[1:]: form = np_wedge(form, e[d])
        sg = B1.perm_sign([a, b] + rest); Y[a, b] = sg * form; Y[b, a] = -sg * form
    return Y
def np_noether(S, x, xv, c):
    """[std] top coefficients of  xi^a (D E)_a  and of  (i_xi T^b) E_b + (i_xi R^ab) Theta_ab (a<b),  Theta = textbook D Y (stencils), D E_a = d E_a - om^b_a E_b"""
    R, T, e, om = S.curv_tors(x); n = S.n; sq = S.sq; top = tuple(range(n))
    E = np_einstein(S, x, c); G = S.grad(lambda y: np_einstein(S, y, c), x)
    xa = e @ xv; lhs = 0.0
    for a in range(n):
        DEa = np_alt(G[:, a], (1, n - 1))
        for b in range(n): DEa = DEa - np_wedge(om[b, a] * sq[a], E[b])
        lhs += xa[a] * DEa[top]
    Y = np_Y(S, x); GY = S.grad(lambda y: np_Y(S, y), x); rhsT = 0.0; rhsR = 0.0
    for b in range(n): rhsT += np_wedge(xv @ T[b], E[b])[top]
    for a, b in itertools.combinations(range(n), 2):
        Th = np_alt(GY[:, a, b], (1, n - 2))
        for cc in range(n): Th = Th - np_wedge(om[cc, a] * sq[a], Y[cc, b]) - np_wedge(om[cc, b] * sq[b], Y[a, cc])
        rhsR += np_wedge(xv @ R[a, b], Th)[top]
    return lhs, rhsT, rhsR

# ------------------------------------------------------------------------------------------------ 1. Lorentz Noether identity
def lorentz_part(n, cs, train, verify):
    sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm; P = pairs_of(Gv.L); eu = Lie([1] * n)
    head('n = %d  Lorentz Noether identity (random polynomial e, omega of degree 1 WITH torsion; lam^A polynomials of degree %d; train seeds %s, fresh seeds %s)' % (n, 2 if n < 4 else 1, train, verify))
    rows, rhs = [], []; keep = {}
    for seed in train + verify:
        rng = random.Random(500 * n + seed); e, om = B1.rand_fields(Gv, rng); lam = [{0: gs.rpoly(rng, n, 2 if n < 4 else 1, .5)} for _ in range(Gv.G)]
        c = cs[seed % len(cs)]; R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, c)
        Lf = lambda ee, oo: B1.lag_EC(Gv, ee, oo, c)
        de, dom = lorentz_var(Gv, e, om, lam); ep, op, dth = B1.rhs_pieces(Gv, e, om, de, dom, c)
        fv_here = (seed in train and n < 5) or n == 3
        first, top = B1.first_variation(Gv, Lf, e, om, de, dom) if fv_here else ({}, {})
        chk('bit', not nz(first) and not nz(top) and nz(ep) and nz(op) and not nz(Fm.add(Fm.add(ep, op), dth)), 'n=%d seed %d c=%s: local Lorentz variation (de^c = -h lam^A e^b, dom = D lam): %sB1\'s three pieces sum to zero, de^a E_a and dom Theta are not zero themselves' % (n, seed, c, 'dL = 0 exactly (first variation, every coefficient); ' if fv_here else '(first variation not computed here; ' + ('cost at n = 5' if n == 5 else 'fresh seed') + ') '))
        if seed == train[0] and n < 5:
          de2, dom2 = lorentz_var(Gv, e, om, lam, sign_om=-1); ctl((n, 'Lorentz variation with dom = -D lam: dL != 0'), nz(B1.first_variation(Gv, Lf, e, om, de2, dom2)[0]))
          bgL = lambda ee, oo: B1.lag_EC(Gv, ee, oo, c, bg=True); ctl((n, 'L with a fixed background vector is not Lorentz invariant: dL != 0'), nz(B1.first_variation(Gv, bgL, e, om, de, dom)[0]))
        if n == 3 and seed == train[0]:
            sdn, sdo = std_lorentz_var(n, sq, e, om, [{k: -v for k, v in lam[A][0].items()} for A in range(Gv.G)])
            chk('bit==std', all(form_eq(de[a], sdn[a]) for a in range(n)) and all(form_eq(dom[A], sdo[A]) for A in range(Gv.G)), 'n=%d: the engine\'s (de, dom) = (-h lam e, D lam) equals, exactly, the textbook l^a_b e^b and -(d l + om l - l om) with l^{ab} = -lam^A (plain polynomials, no engine)' % n)
        Y = by_A(Gv, B1.Y_forms(Gv, e)); Th = by_A(Gv, B1.Theta_forms(Gv, e, T)); DY = D_dual_bivector(Gv, om, Y)
        want = [{} for _ in range(Gv.G)]
        for (A, B), (C, f) in Gv.L.f.items(): want[B] = Fm.add(want[B], Fm.wedge(R[A], Y[C]), -F(f, 2))
        chk('bit', all(form_eq(DY[A], Th[A]) for A in range(Gv.G)) and all(form_eq(D_dual_bivector(Gv, om, DY)[B], want[B]) for B in range(Gv.G)), 'n=%d seed %d: Theta_A = (D Y)_A with D on the lower index, (D Y)_B = d Y_B - (1/2) f_AB^C om^A Y_C; and D D Y_B = -(1/2) f_AB^C R^A Y_C (Ricci identity of the dual action)' % (n, seed))
        DTh = D_dual_bivector(Gv, om, Th)
        X1 = [Fm.wedge(Fm.scale(e[a], sq[a]), E[b]) for (a, b) in P]; X2 = [Fm.wedge(Fm.scale(e[b], sq[b]), E[a]) for (a, b) in P]
        keep[seed] = (DTh, X1, X2, e, E)
        if seed in train:
            for A in range(Gv.G): add_rows(rows, rhs, [X1[A], X2[A]], DTh[A])
    w, rank, nvar, cons = solve_exact(rows, rhs)
    chk('bit', cons and rank == 2 and w == [1, -1], 'n=%d: exact fit on the train seeds (%d coefficient equations, rank %d): (D Theta)_ab = alpha e_a ^ E_b + beta e_b ^ E_a with (alpha, beta) = (%s, %s); predicted (1, -1)' % (n, len(rows), rank, *(w or ['-', '-'])))
    for seed in verify:
        DTh, X1, X2, e, E = keep[seed]
        chk('bit', all(form_eq(DTh[A], Fm.add(X1[A], X2[A], -1)) and nz(DTh[A]) for A in range(Gv.G)), 'n=%d fresh seed %d: (D Theta)_ab = e_a ^ E_b - e_b ^ E_a exactly, every pair, every coefficient (not zero)' % (n, seed))
        Xe = [Fm.add(Fm.wedge(e[a], E[b]), Fm.wedge(e[b], E[a]), -1) for (a, b) in P]
        ctl((n, 'Euclidean lowering e_a = e^a in the Lorentz identity'), not all(form_eq(DTh[A], Xe[A]) for A in range(Gv.G)))
        ctl((n, 'flipped coefficients (alpha, beta) = (-1, 1)'), not all(form_eq(DTh[A], Fm.add(X2[A], X1[A], -1)) for A in range(Gv.G)))
    # zero torsion (A3 closed form, first-order jets at the origin): the antisymmetric part vanishes
    rng = random.Random(77 + n); e = rand_frame(rng, n, deg=2); S = koszul_S(n, sq, Gv.L); om, R = engine_om_R(Gv, e, S, n); c = F(1, 3)
    with trunc(n, xdeg=1): E, _ = Gv.einstein(None, e, R, c)
    with trunc(n, xdeg=0):
        T = Gv.torsion(om, e); anti = [Fm.add(Fm.wedge(Fm.scale(e[a], sq[a]), E[b]), Fm.wedge(Fm.scale(e[b], sq[b]), E[a]), -1) for (a, b) in P]
        omb = [Fm.add(om[A], {1 << (A % n): {(0,) * n: F(1)}}) for A in range(Gv.G)]; Rb = Gv.curvature(omb)
    t0 = all(at0(p, n) == 0 for x in T for p in x.values()); a0 = all(at0(p, n) == 0 for x in anti for p in x.values())
    with trunc(n, xdeg=0):
        Eb, _ = Gv.einstein(None, e, Rb, c); antib = [Fm.add(Fm.wedge(Fm.scale(e[a], sq[a]), Eb[b]), Fm.wedge(Fm.scale(e[b], sq[b]), Eb[a]), -1) for (a, b) in P]
    chk('bit', t0 and a0 and any(at0(p, n) != 0 for x in E for p in x.values()), 'n=%d: at zero torsion (random frame of degree 2, A3 closed-form omega, value at the origin) e_a ^ E_b - e_b ^ E_a = 0 for every pair: the Einstein form is symmetric' % n)
    ctl((n, 'constant shift of omega (torsion at the origin): the antisymmetric part is not zero'), any(at0(p, n) != 0 for x in antib for p in x.values()))
    tick('n=%d Lorentz' % n)

# ------------------------------------------------------------------------------------------------ 2. diffeomorphism Noether identity
def diffeo_part(n, cs, seeds, fit_seeds, xdeg):
    sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm; eu = Lie([1] * n); full = (1 << n) - 1; zero = (0,) * n
    head('n = %d  diffeomorphism Noether identity (random e, omega of degree 1 with torsion; random polynomial xi of degree %d; c in %s)' % (n, xdeg, [str(c) for c in cs]))
    rows, rhs = [], []
    for seed in seeds:
        for c in cs:
            rng = random.Random(700 * n + seed); e, om = B1.rand_fields(Gv, rng); xi = rand_vec(rng, n, xdeg)
            R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, c)
            Lf = lambda ee, oo: B1.lag_EC(Gv, ee, oo, c); L0 = Lf(e, om); iL = interior(Gv, xi, L0)
            Le = [lie(Gv, xi, x) for x in e]; Lom = [lie(Gv, xi, x) for x in om]
            first, top = B1.first_variation(Gv, Lf, e, om, Le, Lom); ep, op, dth = B1.rhs_pieces(Gv, e, om, Le, Lom, c)
            chk('bit', not nz(top) and nz(first) and form_eq(first, Fm.d(iL)) and form_eq(first, lie(Gv, xi, L0)) and form_eq(first, Fm.add(Fm.add(ep, op), dth)), 'n=%d seed %d c=%s: (i) the first variation of L along (L_xi e, L_xi om) equals L_xi L = d(i_xi L) exactly (no background); B1\'s three pieces reproduce it' % (n, seed, c))
            # (ii) decompositions
            xa = frame_comps(Gv, xi, e); Xv = [{0: p} if p else {} for p in xa]; Dxi = Gv.D_vector(om, Xv)
            iT = [interior(Gv, xi, x) for x in T]; iR = [interior(Gv, xi, x) for x in R]; lam = [interior(Gv, xi, x) for x in om]
            rot, _ = lorentz_var(Gv, e, om, lam); Dlam = Gv.D_bivector(om, lam)
            chk('bit', all(form_eq(Le[a], lin_forms(Fm, [(1, Dxi[a]), (1, iT[a]), (1, rot[a])])) for a in range(n)) and all(form_eq(Lom[A], Fm.add(iR[A], Dlam[A])) for A in range(Gv.G)), 'n=%d seed %d c=%s: (ii) L_xi e^a = D xi^a + i_xi T^a - h_Ab^a (i_xi om^A) e^b and L_xi om = i_xi R + D(i_xi om): L_xi is the Lorentz variation with lam = i_xi om plus a covariant translation' % (n, seed, c))
            ctl((n, 'L_xi e without the rotation term -(i_xi om) e'), not all(form_eq(Le[a], Fm.add(Dxi[a], iT[a])) for a in range(n)))
            rot_eu, _ = lorentz_var(Gv, e, om, lam, htab=eu.h)
            ctl((n, 'rotation term with the Euclidean h table'), not all(form_eq(Le[a], lin_forms(Fm, [(1, Dxi[a]), (1, iT[a]), (1, rot_eu[a])])) for a in range(n)))
            # (iii) J and N
            Y = by_A(Gv, B1.Y_forms(Gv, e)); Th = by_A(Gv, B1.Theta_forms(Gv, e, T))
            xE = {}
            for a in range(n): xE = Fm.add(xE, pf(Fm, xa[a], E[a]))
            RY = wsum(Fm, [(iR[A], Y[A]) for A in range(Gv.G)])
            chk('bit', form_eq(iL, Fm.add(xE, RY)) and nz(RY), 'n=%d seed %d c=%s: J (coefficient of d xi): i_xi L = xi^a E_a + (i_xi R^A) ^ Y_A exactly' % (n, seed, c))
            iLr = interior(Gv, xi, L0, -1); RYr = wsum(Fm, [(interior(Gv, xi, R[A], -1), Y[A]) for A in range(Gv.G)])
            ctl((n, 'right contraction (-1)^(p-1) i_xi in J'), not form_eq(iLr, Fm.add(xE, RYr)))
            DE = Gv.D_covector(om, E); lhsN = {}
            for a in range(n): lhsN = Fm.add(lhsN, pf(Fm, xa[a], DE[a]))
            Tt = wsum(Fm, [(iT[b], E[b]) for b in range(n)]); Rt = wsum(Fm, [(iR[A], Th[A]) for A in range(Gv.G)])
            rhsE = Gv.einstein_rhs(e, T, R, c, F_); xr = {}
            for a in range(n): xr = Fm.add(xr, pf(Fm, xa[a], rhsE[a]))
            chk('bit', form_eq(lhsN, Fm.add(Tt, Rt)) and form_eq(Fm.add(Tt, Rt), xr) and nz(Tt) and nz(Rt), 'n=%d seed %d c=%s: N: xi^a (D E)_a = (i_xi T^b) ^ E_b + (i_xi R^A) ^ Theta_A exactly, and this equals xi^a einstein_rhs_a (the torsion terms of step 10)%s' % (n, seed, c, '; here both sides are 0 and the T- and R-terms cancel each other' if not nz(lhsN) else ''))
            if n == 3 and c == 0: chk('bit', not nz(lhsN) and form_eq(Tt, Fm.scale(Rt, -1)), 'n=3 seed %d c=0: the R-terms cancel the T-terms exactly ((i_xi T) E = -(i_xi R) Theta: i_xi of a 4-form is 0 in 3D), so D E_a = 0' % seed)
            ctl((n, 'N without the R-term (i_xi R) Theta'), not form_eq(lhsN, Tt)); ctl((n, 'N without the T-term (i_xi T) E'), not form_eq(lhsN, Rt))
            NTr = wsum(Fm, [(interior(Gv, xi, T[b], -1), E[b]) for b in range(n)]); NRr = wsum(Fm, [(interior(Gv, xi, R[A], -1), Th[A]) for A in range(Gv.G)])
            if nz(lhsN): ctl((n, 'right contraction in N'), not form_eq(lhsN, Fm.add(NTr, NRr)))
            if seed == seeds[0]:
                ok = True
                for mu in range(n):
                    v = coord_vec(n, mu); a1 = wsum(Fm, [(interior(Gv, v, T[b]), E[b]) for b in range(n)]); a2 = wsum(Fm, [(interior(Gv, v, R[A]), Th[A]) for A in range(Gv.G)])
                    r1 = {}; l1 = {}
                    for a in range(n): r1 = Fm.add(r1, pf(Fm, e[a].get(1 << mu, {}), rhsE[a])); l1 = Fm.add(l1, pf(Fm, e[a].get(1 << mu, {}), DE[a]))
                    ok &= form_eq(Fm.add(a1, a2), r1) and form_eq(l1, r1)
                chk('bit', ok, 'n=%d seed %d c=%s: frame form with xi = d_mu (mu = 0..%d): (i_mu T^b) E_b + (i_mu R^A) Theta_A = e^a_mu einstein_rhs_a = e^a_mu (D E)_a; e invertible, so D E_a = (i_a T^b) E_b + (i_a R^A) Theta_A' % (n, seed, c, n - 1))
            # the chain: d(i_xi L) = d(xi^a E_a + (i_xi R) Y) - xi^a D E_a + (i_xi T) E + (i_xi R) Theta, Lorentz part = 0
            epl, opl, dtl = B1.rhs_pieces(Gv, e, om, rot, Dlam, c)
            chain = lin_forms(Fm, [(1, Fm.d(Fm.add(xE, RY))), (-1, lhsN), (1, Tt), (1, Rt)])
            chk('bit', not nz(Fm.add(Fm.add(epl, opl), dtl)) and form_eq(first, chain), 'n=%d seed %d c=%s: the chain: B1 along the Lorentz part (lam = i_xi om) is 0, and d(i_xi L) = d(xi^a E_a + (i_xi R^A) Y_A) - xi^a D E_a + (i_xi T^b) E_b + (i_xi R^A) Theta_A' % (n, seed, c))
            if seed in fit_seeds: add_rows(rows, rhs, [Tt, Rt], lhsN)
            # control (a): a fixed background vector b = dx^(n-1) in place of e^(n-1)
            if c == cs[-1] and seed == seeds[0] and n < 5:
                b = {1 << (n - 1): {zero: F(1)}}; et = list(e[:n - 1]) + [b]; Lb = lambda ee, oo: B1.lag_EC(Gv, list(ee[:n - 1]) + [b], oo, c)
                fb, _ = B1.first_variation(Gv, Lb, e, om, Le, Lom); Lb0 = Lb(e, om); diL = Fm.d(interior(Gv, xi, Lb0))
                ctl((n, 'background vector: the first variation along L_xi is not d(i_xi L)'), not form_eq(fb, diL))
                Lxb = lie(Gv, xi, b); expl = Fm.add(B1.lag_EC(Gv, list(e[:n - 1]) + [Fm.add(b, Lxb)], om, c), Lb0, -1)
                chk('bit', form_eq(Fm.add(fb, expl), diL) and nz(expl), 'n=%d seed %d c=%s: background control, by how much: the deficit d(i_xi L) - dL equals exactly the explicit-dependence term L(b + L_xi b) - L(b) (L is linear in b)' % (n, seed, c))
                Rt_ = Gv.curvature(om); Tt_ = Gv.torsion(om, et); Et, _ = Gv.einstein(None, et, Rt_, c); Ebg = list(Et[:n - 1]) + [{}]
                Thb = by_A(Gv, B1.Theta_forms(Gv, et, Tt_)); Ybg = by_A(Gv, B1.Y_forms(Gv, et))
                r2 = random.Random(9 * n + seed); dd, dw = B1.rand_fields(Gv, r2); fv, _ = B1.first_variation(Gv, Lb, e, om, dd, dw)
                pr = lin_forms(Fm, [(1, wsum(Fm, [(dd[a], Ebg[a]) for a in range(n)])), (1, wsum(Fm, [(dw[A], Thb[A]) for A in range(Gv.G)])), (1, Fm.d(wsum(Fm, [(dw[A], Ybg[A]) for A in range(Gv.G)])))])
                chk('bit', form_eq(fv, pr), 'n=%d seed %d: the background Lagrangian\'s own Euler-Lagrange forms (E^bg_a = E_a(e~) for a < n-1, E^bg_(n-1) = 0, Theta(e~), Y(e~), e~ = e with e^(n-1) -> dx^(n-1)) reproduce B1\'s first_variation of it' % (n, seed))
                DEb = Gv.D_covector(om, Ebg); lb = {}
                for a in range(n): lb = Fm.add(lb, pf(Fm, xa[a], DEb[a]))
                rb = Fm.add(wsum(Fm, [(iT[q], Ebg[q]) for q in range(n)]), wsum(Fm, [(iR[A], Thb[A]) for A in range(Gv.G)]))
                ctl((n, 'background vector: N fails for (E^bg, Theta^bg)'), not form_eq(lb, rb))
                xt = frame_comps(Gv, xi, et); DEt = Gv.D_covector(om, Et); Pn = [{} for _ in range(n)]; Pn[n - 1] = Et[n - 1]; DP = Gv.D_covector(om, Pn); itn = interior(Gv, xi, Tt_[n - 1])
                pred = Fm.add(pf(Fm, padd(xa[n - 1], xt[n - 1], -1), DEt[n - 1]), Fm.wedge(itn, Et[n - 1]))
                for a in range(n): pred = Fm.add(pred, pf(Fm, xa[a], DP[a]), -1)
                for q in range(n - 1): pred = Fm.add(pred, Fm.wedge(interior(Gv, xi, Fm.add(T[q], Tt_[q], -1)), Ebg[q]), -1)
                chk('bit', form_eq(Fm.add(lb, rb, -1), pred) and nz(pred), 'n=%d seed %d: background control, by how much: N^bg fails exactly by the background slot\'s terms (xi^(n-1) - i_xi b) D E~_(n-1) - xi^a (D P)_a + (i_xi T~^(n-1)) E~_(n-1) - i_xi(T^q - T~^q) E~_q (q < n-1; D e^q - D e~^q = om^q_(n-1) (e^(n-1) - b)), P = E~_(n-1) in slot n-1' % (n, seed))
    w, rank, nvar, cons = solve_exact(rows, rhs)
    want = [1, 1]
    chk('bit', cons and w == want and rank == 2, 'n=%d: exact fit on seeds %s (%d coefficient equations, rank %d): xi^a D E_a = alpha (i_xi T^b) E_b + beta (i_xi R^A) Theta_A with (alpha, beta) = (%s, %s); predicted (1, 1)' % (n, fit_seeds, len(rows), rank, *(w or ['-', '-'])))
    tick('n=%d diffeo' % n)

# ------------------------------------------------------------------------------------------------ 3. MacDowell-Mansouri (n = 4), B1's (x, y, z) = (8c, 4c, 2)
def mm_part(cs, seed=1):
    n = 4; sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm; P = pairs_of(Gv.L)
    head('MacDowell-Mansouri form, n = 4: L = eps F F; E^MM = 8c E, Theta^MM_ab = 8c sum_{c,d} eps_abcd T^c e^d, Y^MM_ab = 8 sum_{c<d} eps_abcd F^cd  (from B1\'s fit)')
    for c in cs:
        rng = random.Random(800 + seed); e, om = B1.rand_fields(Gv, rng); xi = rand_vec(rng, n, 1)
        R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, c)
        Lf = lambda ee, oo: B1.lag_MM(Gv, ee, oo, c); L0 = Lf(e, om); Le = [lie(Gv, xi, x) for x in e]; Lom = [lie(Gv, xi, x) for x in om]
        first, top = B1.first_variation(Gv, Lf, e, om, Le, Lom)
        YM = []; TM = []
        for (a, b) in P:
            y = {}; t = {}
            for (cc, d) in F_:
                sg = Gv.eps([a, b, cc, d])
                if sg: y = Fm.add(y, F_[(cc, d)], 8 * sg)
            for cc in range(n):
                for d in range(n):
                    sg = Gv.eps([a, b, cc, d])
                    if sg: t = Fm.add(t, Fm.wedge(T[cc], e[d]), 8 * c * sg)
            YM.append(y); TM.append(t)
        EM = [Fm.scale(x, 8 * c) for x in E]; xa = frame_comps(Gv, xi, e); iR = [interior(Gv, xi, x) for x in R]; iT = [interior(Gv, xi, x) for x in T]
        pieces = lin_forms(Fm, [(1, wsum(Fm, [(Le[a], EM[a]) for a in range(n)])), (1, wsum(Fm, [(Lom[A], TM[A]) for A in range(Gv.G)])), (1, Fm.d(wsum(Fm, [(Lom[A], YM[A]) for A in range(Gv.G)])))])
        chk('bit', not nz(top) and nz(first) and form_eq(first, Fm.d(interior(Gv, xi, L0))) and form_eq(first, pieces), 'MM c=%s: (i) dL along (L_xi e, L_xi om) = d(i_xi L) exactly, and B1\'s MM pieces reproduce it' % c)
        chk('bit', all(form_eq(D_dual_bivector(Gv, om, YM)[A], TM[A]) for A in range(Gv.G)), 'MM c=%s: Theta^MM = D Y^MM (lower-index D): B1\'s fitted (y, z) = (4c, 2) are consistent with Theta = D Y' % c)
        xE = {}; lhsN = {}; DE = Gv.D_covector(om, EM)
        for a in range(n): xE = Fm.add(xE, pf(Fm, xa[a], EM[a])); lhsN = Fm.add(lhsN, pf(Fm, xa[a], DE[a]))
        RY = wsum(Fm, [(iR[A], YM[A]) for A in range(Gv.G)]); rN = Fm.add(wsum(Fm, [(iT[b], EM[b]) for b in range(n)]), wsum(Fm, [(iR[A], TM[A]) for A in range(Gv.G)]))
        chk('bit', form_eq(interior(Gv, xi, L0), Fm.add(xE, RY)) and nz(RY) and form_eq(lhsN, rN), 'MM c=%s: J: i_xi L = xi^a E^MM_a + (i_xi R^A) Y^MM_A, and N: xi^a D E^MM_a = (i_xi T^b) E^MM_b + (i_xi R^A) Theta^MM_A (%s)' % (c, 'both sides 0 at c = 0: E^MM = Theta^MM = 0; J is the whole content' if c == 0 else '8c times the Einstein-Cartan identity'))
    tick('MM')

# ------------------------------------------------------------------------------------------------ 4. [std] numpy at points
def std_part(n, c):
    sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm; full = (1 << n) - 1
    head('n = %d  [std] numpy route at two points (B1\'s Std with nine-point stencils: textbook curvature and torsion, Levi-Civita sums; antisymmetric arrays), c = %s' % (n, c))
    rng = random.Random(700 * n + 1); e, om = B1.rand_fields(Gv, rng); xi = rand_vec(rng, n, 2 if n < 5 else 1)
    xs = [np.array([0.3, -0.2, 0.5, 0.1, -0.4][:n]), np.array([-0.5, 0.25, 0.1, -0.3, 0.2][:n])]
    Les = [lie_std(xi, x, n) for x in e]; Loms = [lie_std(xi, x, n) for x in om]
    chk('bit==std', all(form_eq(Les[a], lie(Gv, xi, e[a])) for a in range(n)) and all(form_eq(Loms[A], lie(Gv, xi, om[A])) for A in range(Gv.G)), 'n=%d: the engine\'s L_xi e, L_xi om (Cartan, bit-rule interior and d) equal the component formula xi^r d_r A_mu + A_r d_mu xi^r exactly' % n)
    S = Std9(n, sq, e, om, Les, Loms, float(c)); Lf = lambda ee, oo: B1.lag_EC(Gv, ee, oo, c); L0 = Lf(e, om); diL = Fm.d(interior(Gv, xi, L0))
    R = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, R, c); xa = frame_comps(Gv, xi, e); DE = Gv.D_covector(om, E)
    lhsN = {}
    for a in range(n): lhsN = Fm.add(lhsN, pf(Fm, xa[a], DE[a]))
    Th = by_A(Gv, B1.Theta_forms(Gv, e, T)); iT = [interior(Gv, xi, x) for x in T]; iR = [interior(Gv, xi, x) for x in R]
    Tt = wsum(Fm, [(iT[b], E[b]) for b in range(n)]); Rt = wsum(Fm, [(iR[A], Th[A]) for A in range(Gv.G)])
    w1 = w2 = w3 = 0.0
    for x in xs:
        xv = np.array([B1.pt_eval(p, x) if p else 0.0 for p in xi])
        fv = S.first_variation(x); G = S.grad(lambda y: S.lagrangian(y, 0.0) * np.array([B1.pt_eval(p, y) if p else 0.0 for p in xi]), x); div = float(np.trace(G))
        es, os_, ts = S.rhs(x); eng = B1.pt_eval(diL.get(full, {}), x); sc = max(1.0, abs(fv), abs(div), abs(es), abs(os_), abs(ts))
        w1 = max(w1, abs(fv - div) / sc, abs(fv - eng) / sc, abs(es + os_ + ts - div) / sc)
        l, rT, rR = np_noether(S, x, xv, float(c)); el, eT, eR = (B1.pt_eval(X.get(full, {}), x) for X in (lhsN, Tt, Rt)); sc = max(1.0, abs(l), abs(rT), abs(rR))
        w2 = max(w2, abs(l - (rT + rR)) / sc, abs(l - el) / sc, abs(rT - eT) / sc, abs(rR - eR) / sc)
    chk('bit==std', w1 < 1e-7, 'n=%d: [std] diffeomorphism invariance at 2 points: the numpy first variation of L along the component-formula L_xi e, L_xi om equals d_mu(xi^mu L) (stencils), equals the engine\'s d(i_xi L), and Std.rhs pieces sum to it (worst relative error %.2e)' % (n, w1))
    chk('bit==std', w2 < 1e-7, 'n=%d: [std] N at 2 points: textbook xi^a (dE_a - om^b_a E_b) = (i_xi T^b) E_b + (i_xi R^ab) Theta_ab with Theta = textbook D Y (stencils), and each of the three numbers equals the engine\'s (worst relative error %.2e)' % (n, w2))
    rng = random.Random(500 * n + 1); e, om = B1.rand_fields(Gv, rng); lam = [{0: gs.rpoly(rng, n, 2, .5)} for _ in range(Gv.G)]
    sde, sdo = std_lorentz_var(n, sq, e, om, [{k: -v for k, v in lam[A][0].items()} for A in range(Gv.G)]); de, dom = lorentz_var(Gv, e, om, lam)
    S2 = Std9(n, sq, e, om, sde, sdo, float(c))
    for x in xs:
        fv = S2.first_variation(x); es, os_, ts = S2.rhs(x); sc = max(1.0, abs(es), abs(os_), abs(ts)); w3 = max(w3, abs(fv) / sc, abs(es + os_ + ts) / sc)
    chk('bit==std', w3 < 1e-7 and all(form_eq(de[a], sde[a]) for a in range(n)) and all(form_eq(dom[A], sdo[A]) for A in range(Gv.G)), 'n=%d: [std] textbook Lorentz variation de = l e, dom = -D l (l = -lam) equals the engine\'s exactly, and the numpy first variation and the sum of Std.rhs pieces vanish at 2 points (worst relative %.2e)' % (n, w3))
    tick('n=%d std' % n)

def main():
    ns = [int(a) for a in sys.argv[1:]] or [3, 4, 5]; cs = [F(0), F(1, 3), F(-2, 5)]
    head('helper g2_forms_calc: exact self-tests (part of B2)')
    for n in ns[:2]: FC.self_test(n, 1)
    for n in ns:
        lorentz_part(n, cs, train=[1, 2] if n < 5 else [1], verify=[3, 4] if n < 5 else [2])
        diffeo_part(n, cs if n < 5 else [F(1, 3)], seeds=[1, 2] if n < 5 else [1], fit_seeds=[1, 2] if n < 5 else [1], xdeg=2 if n < 4 else 1)
    if 4 in ns: mm_part([F(1, 3), F(0)])
    for n in [m for m in ns if m <= 4]: std_part(n, F(1, 3))
    head('controls (a wrong version must fail on every sample where it can be seen)')
    for (n, name), (dif, seen) in CTL.items(): chk('ctl', dif == seen and seen > 0, 'n=%d: %s: the wrong version fails on %d of %d samples' % (n, name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('B2')
if __name__ == '__main__': main()
