#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""L3-flipped: the curvature F(c) = R + c e^a^e^b against the Weyl 2-form W with space squaring +1.   python3 l3_cartan_weyl_flipped.py

 Statement.  With the squares (-1, +1, +1, +1) (space +1, time -1) and the same 21 frames as l3_cartan_weyl.py (the same coframes, eta -> -eta: the metric
 of each frame is -g, the device of h3_sign_chain.py parts (2) and (3)), the identity holds at the c that h3_sign_chain.py fixes, c = k kappa^2 with
 k = -s and H2 = r kappa^2, r = s / (square of space):  c = (square of time) x H2, so c = -H2 here.  F(-H2) = W on Schwarzschild-(anti-)de Sitter, F(-H2) = 0
 on (anti-)de Sitter, F(0) = W on Kerr; E_a(c) = 0 <=> F(c) = W on 96 (frame, c) pairs; F(c) - W = (e^a P^b - e^b P^a) + (c + Rs/12) e^a e^b with P and Rs
 of this convention; Reissner-Nordstrom is never W.  The five-generator block needs s = +sign H2 (r = sign H2 as with space squaring -1).
 Across the conventions, on every frame: F_flip(c) = -F_ours(-c), W_flip = -W_ours, E_flip(c) = -E_ours(-c).
 [bit]  the engine with Lie((-1,1,1,1)) and its Koszul table: omega = A3 closed form, R, F(c) and E_a(c) from Grav.einstein at the origin of exact 2-jets;
        W by H1's projection with these squares; H1's duality J; the Petrov type; the five-generator curvature in Lie((-1,1,1,1,s)).
 [std]  (i) the Christoffel route on the same jets with eta = diag(-1,1,1,1) (exact); (ii) an own numpy route from the closed-form metric -g (Kerr: C2's float
        metric, sign flipped): Christoffel symbols and Riemann by 4th-order central differences, closed-form frame, Weyl projection with eta = diag(-1,1,1,1).
 Controls: the sign of c of the other convention (c = +H2) and c = -H2/2 fail; the square s of the other convention in the five-generator block fails;
 Reissner-Nordstrom has no c with F(c) = W; the Euclidean-squares duality on Kerr; delta traces on the lowered tensor.  Cross-check: the functions of this
 file with the squares (+1,-1,-1,-1) equal those of l3_cartan_weyl.py on all 21 frames and reproduce the numbers it prints for one frame.
 Scope: n = 4, 2-jets at one rational point per frame, 21 frames, both conventions for the square of space; nothing about which convention nature uses."""
import sys, os, time, itertools, random, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)                                                     # this folder (b1lib), also under python3 -I
from b1lib import *
from g2_weyl import engine_frame_riemann, std_frame_riemann, weyl_parts, duality_J, act_J, cell_vector, metric_cell_vector, complex_Q, petrov
import l3_cartan_weyl as L3
from l3_cartan_weyl import (engine_F, EE, K36, P36, lin36, is0, eq36, nnz, fit36, link_pred, alphas, _d4, _christ, ks_float_fns, kerr_float_fns,
                            SDS, SCHW, DS, RN, KERR, ANG, EXT, cs_of)
from h5l_frames import ks_frame_jetK
import g2_kerr as GK
import numpy as np

SQ_OURS = [1, -1, -1, -1]; SQ_FLIP = [-1, 1, 1, 1]
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
def fmtc(cs): return ', '.join(str(c) for c in cs)
# numbers that l3_cartan_weyl.py prints for SdS M = 1, H2 = 1/5, p = (2, 3, 6), rho = 7 (squares (+,-,-,-)), and its truth table
SHIPPED = dict(cs=[F(-2, 7), F(-1, 5), F(0), F(1, 10), F(1, 5), F(1, 3)], alphas=[F(-17, 35), F(-2, 5), F(-1, 5), F(-1, 10), F(0), F(2, 15)],
               double=F(-1, 343), nnz=18, table=(15, 81, 0))

# ------------------------------------------------------------------------------------------------ the parts of l3_cartan_weyl.py that read the squares, with sq a parameter
def weyl36s(Rl, sq):
    """H1's projection with the squares sq: W^{ab}_{cd} (36), R^{ab}_{cd} (36), Ric_bd, Rs, trace-free Ricci, P^a_b = (1/2) sq_a tf_ab"""
    C, Ric, Rs, tf = weyl_parts(Rl, sq)
    return dict(W={k: sq[k[0]] * sq[k[1]] * C[k] for k in K36}, R={k: sq[k[0]] * sq[k[1]] * Rl[k] for k in K36}, Ric=Ric, Rs=Rs, tf=tf,
                P=[[F(1, 2) * sq[a] * tf[(a, b)] for b in range(4)] for a in range(4)])
def lowered_s(X36, sq):
    T = {k: F(0) for k in itertools.product(range(4), repeat=4)}
    for (a, b, c, d), v in X36.items():
        w = sq[a] * sq[b] * v; T[(a, b, c, d)] = w; T[(b, a, c, d)] = -w; T[(a, b, d, c)] = -w; T[(b, a, d, c)] = w
    return T
def jparts_s(X36, J, sq):
    """(J-even part, J-odd part) of the 21-cell vector of the lowered X (H1: S -> S(J., J.))"""
    S = cell_vector(lowered_s(X36, sq)); JS = act_J(S, J)
    return [(s + j) / 2 for s, j in zip(S, JS)], [(s - j) / 2 for s, j in zip(S, JS)]
def ext_blocks_s(e, om, s, kappa, sq, n=4):
    """[bit] curvature of A = omega + kappa e^a B_{a,ext} in the algebra of squares (sq, s): (Lorentz block 36, translation block) at the point"""
    sq_ext = list(sq) + [s]; Lx = Lie(sq_ext); Gx = Grav(n, Lx); Lb = Lie(list(sq)); Fm = Gx.Fm
    A = [{} for _ in range(Lx.G)]
    for A_, g in enumerate(Lb.gens): A[Lx.idx[g]] = om[A_]
    for a in range(n): A[Lx.idx[(1 << a) | (1 << n)]] = Fm.scale(e[a], F(kappa))
    with trunc(n, xdeg=1): Fx = Gx.curvature(A)
    e0, E0, det = E0_of(e, n, n)
    Lor = {(a, b) + cd: v for (a, b) in L3.PAIRS for cd, v in L3.frame_comps(Fx[Lx.idx[(1 << a) | (1 << b)]], E0).items()}
    Tr = {(a,) + cd: v for a in range(n) for cd, v in L3.frame_comps(Fx[Lx.idx[(1 << a) | (1 << n)]], E0).items()}
    return Lor, Tr
def std_float_s(gfun, efun, X, h, sq):
    """[std] floats: R^{ab}_{cd} and the Weyl C^{ab}_{cd} with eta = diag(sq); Riemann R^r_{smv} = d_m G^r_{vs} - d_v G^r_{ms} + G G - G G of the metric gfun"""
    ETA = np.diag([float(x) for x in sq]); ETAI = np.linalg.inv(ETA)
    G0 = _christ(gfun, X, h); dG = np.array([_d4(lambda Y: _christ(gfun, Y, h), X, k, h) for k in range(4)])
    Riem = (np.einsum('mrvs->rsmv', dG) - np.einsum('vrms->rsmv', dG) + np.einsum('rml,lvs->rsmv', G0, G0) - np.einsum('rvl,lms->rsmv', G0, G0))
    e0 = efun(X); E0 = np.linalg.inv(e0)
    Rl = np.einsum('ax,xr,rsmv,sb,mc,vd->abcd', ETA, e0, Riem, E0, E0, E0)
    Ric = np.einsum('ac,abcd->bd', ETAI, Rl); Rs = np.einsum('bd,bd->', ETAI, Ric)
    C = (Rl - 0.5 * (np.einsum('ac,bd->abcd', ETA, Ric) - np.einsum('ad,bc->abcd', ETA, Ric) - np.einsum('bc,ad->abcd', ETA, Ric) + np.einsum('bd,ac->abcd', ETA, Ric))
         + Rs / 6.0 * (np.einsum('ac,bd->abcd', ETA, ETA) - np.einsum('ad,bc->abcd', ETA, ETA)))
    up = lambda T: np.einsum('ax,by,xycd->abcd', ETAI, ETAI, T)
    Ru, Cu = up(Rl), up(C)
    return dict(R={k: Ru[k] for k in K36}, C={k: Cu[k] for k in K36}, Rs=Rs)

class Conv:
    """one convention: the engine with these squares, its Koszul table, H1's duality J, and the sign rules of h3_sign_chain.py"""
    def __init__(self, name, sq):
        self.name, self.sq = name, list(sq); self.Gv = Grav(4, Lie(list(sq))); self.S = koszul_S(4, list(sq), self.Gv.L)
        self.J = duality_J(list(sq))[0]; self.st, self.sp = sq[0], sq[1]
    def cfix(self, H2): return self.st * F(H2)                     # c = k kappa^2 = -s kappa^2, H2 = r kappa^2, r = s/sp:  c = -sp H2 = (square of time) H2
    def sext(self, H2): return (1 if H2 > 0 else -1) * self.sp      # s = r sp with r = sign H2
    def mirror(self, cs): return sorted(set(self.st * F(c) for c in cs))

# ------------------------------------------------------------------------------------------------ frames
def ks_fr_s(cv, kind, M, H2, q, p, rho, cs):
    p = tuple(F(x) for x in p); X = np.array([0.0] + [float(x) for x in p]); g, ef = ks_float_fns(M, H2, q); s0 = cv.st
    name = '%s M = %s, H2 = %s%s, p = (%s), rho = %s' % (kind, M, H2, (', charge term %s' % q) if q else '', ', '.join(str(x) for x in p), rho)
    return dict(name=name, kind=kind, M=F(M), H2=F(H2), q=F(q), e=ks_frame_jetK(p, rho, M, H2, q, order=2), cs=cs, flt=((lambda Y: s0 * g(Y)), ef, X, 1e-3 * rho))

def analyse_s(cv, fr):
    """the checks every frame gets (l3_cartan_weyl.analyse with the squares of the convention)"""
    sq, Gv, S, J = cv.sq, cv.Gv, cv.S, cv.J; name, e, cs = fr['name'], fr['e'], fr['cs']
    d = engine_F(Gv, e, S, cs)
    with trunc(4, xdeg=0): tz = torsion_zero_at0(Gv, d['om'], e, 4)
    chk('bit', tz, '%s: precondition T = 0 at the point (A3 omega with the squares %s; the engine torsion reads the h table)' % (name, sq))
    wb = weyl36s(engine_frame_riemann(Gv, e, S, 4, om=d['om'])[0], sq); ws = weyl36s(std_frame_riemann(e, 4, sq), sq)
    chk('bit==std', all(eq36(d['F'][c], lin36((1, ws['R']), (c, EE))) for c in cs),
        '%s: the engine F(c) = R_std + c e^e exactly (Christoffel route, eta = diag%s), all 36 components, c in {%s}' % (name, tuple(sq), fmtc(cs)))
    chk('bit==std', eq36(wb['W'], ws['W']), '%s: W from the engine R = W from the Christoffel route (H1 projection), 36 components, %d nonzero' % (name, nnz(wb['W'])))
    if fr.get('flt'):
        gfun, efun, X, h = fr['flt']; sf = std_float_s(gfun, efun, X, h, sq)
        sc = max(abs(float(v)) for c in cs for v in d['F'][c].values()) or 1.0
        err = max(abs(float(d['F'][c][k]) - (sf['R'][k] + float(c) * float(EE[k]))) for c in cs for k in K36)
        errW = max(abs(float(wb['W'][k]) - sf['C'][k]) for k in K36)
        chk('bit==std', err <= 1e-6 * sc and errW <= 1e-6 * sc, '%s: engine F(c) = R + c delta and W = C of the own float route from the metric -g (finite '
            'differences, no jets): max |diff| %.1e and %.1e (scale %.1e)' % (name, err, errW, sc))
        fr['sf'] = sf; fr['sc'] = sc
    P = wb['P']; trfree = all(v == 0 for v in wb['tf'].values())
    Ez = {c: all(v == 0 for v in d['E'][c].values()) for c in cs}; FW = {c: eq36(d['F'][c], wb['W']) for c in cs}
    Mx = {c: mixed_from_components(d['E'][c], d['e0'], d['det'], 4) for c in cs}
    chk('bit', all(Ez[c] == FW[c] for c in cs), '%s: E_a(c) = 0 <=> F(c) = W for each c (both true exactly at c in {%s})' % (name, fmtc([c for c in cs if FW[c]])))
    chk('bit', all(link_pred(d['F'][c], wb['W'], Mx[c]) for c in cs), '%s: F(c) - W = (1/2)(e^a M^b - e^b M^a) - (tr M/3) e^a e^b, M = G - 3c delta read from '
        'the engine E_a(c) (A4), all 36 components, every c' % name)
    jok = True
    for c in cs:
        ev, od = jparts_s(d['F'][c], J, sq); evP, odP = jparts_s(P36(P), J, sq); al = c + wb['Rs'] / 12
        ev2, od2 = jparts_s(lin36((1, d['F'][c]), (-1, wb['W']), (-1, P36(P))), J, sq)
        jok &= ev == evP and all(x == 0 for x in odP) and all(x == 0 for x in ev2) and od2 == [al * x for x in metric_cell_vector(sq)]
    chk('bit', jok, '%s: duality (H1 J, these squares): J-even part of F(c) = the trace-free Ricci piece e^a P^b - e^b P^a (%s), J-odd part of F(c) - W = '
        '(c + Rs/12) x bivector metric, every c' % (name, 'zero: Einstein' if trfree else 'non-zero'))
    return dict(d=d, wb=wb, ws=ws, P=P, Rs=wb['Rs'], trfree=trfree, Ez=Ez, FW=FW, M=Mx)

# ------------------------------------------------------------------------------------------------ the parts of l3_cartan_weyl.py in the convention cv
def part_sds(cv, JE):
    head('Part 1. Schwarzschild-(anti-)de Sitter (M != 0): F(c) = W exactly at c = (square of time) H2 = %s; F(c) - W = alpha e^a e^b with alpha fitted'
         % ('H2' if cv.st == 1 else '-H2'))
    out = []
    for (M, H2, p, rho) in SDS + SCHW:
        cs = cv.mirror(cs_of(H2)) if H2 != 0 else cv.mirror([F(0), F(1, 5), F(1, 3), F(-2, 7)])
        fr = ks_fr_s(cv, 'SdS' if H2 > 0 else ('SAdS' if H2 < 0 else 'Schwarzschild'), M, H2, 0, p, rho, cs)
        r = analyse_s(cv, fr); d, W = r['d'], r['wb']['W']; out.append((fr, r)); c0 = cv.cfix(H2)
        chk('bit', eq36(d['F'][c0], W) and nnz(W) > 0, '%s: F(c = %s) = W, all 36 frame components exactly (%d nonzero)' % (fr['name'], c0, nnz(W)))
        chk('std', eq36(lin36((1, r['ws']['R']), (c0, EE)), r['ws']['W']), '%s: the Christoffel route alone (exact): R_std + (%s) e^e = W_std' % (fr['name'], c0))
        sf, sc = fr['sf'], fr['sc']
        chk('std', max(abs(sf['R'][k] + float(c0) * float(EE[k]) - sf['C'][k]) for k in K36) <= 1e-6 * sc, '%s: the float route alone: R + (%s) delta = C to 1e-6 of '
            'the scale' % (fr['name'], c0))
        al = alphas(r, fr['cs'])
        chk('bit', all(al[c] == c - c0 for c in fr['cs']), '%s: fitted alpha(c) = c - (%s) for c in {%s} (alphas %s)' % (fr['name'], c0, fmtc(fr['cs']), fmtc([al[c] for c in fr['cs']])))
        typ, I2, I3, info = petrov(complex_Q(lowered_s(d['F'][c0], cv.sq)))
        chk('bit', typ == 'D' and info.get('double') == -cv.st * M / F(rho) ** 3, '%s: F(%s) read as a curvature table has Petrov type %s, double eigenvalue %s '
            '= %sM/rho^3' % (fr['name'], c0, typ, info.get('double'), '-' if cv.st == 1 else '+'))
        if H2 != 0:
            chk('ctl', not eq36(d['F'][c0 / 2], W) and not eq36(d['F'][-c0], W), '%s: wrong c = %s and c = %s (the sign of the other convention): F != W (ok)'
                % (fr['name'], c0 / 2, -c0))
        evE, odE = jparts_s(d['F'][c0], JE, cv.sq); Wl = lowered_s(W, cv.sq)
        mag0 = all(Wl[(0, i, j, k)] == 0 for i in (1, 2, 3) for (j, k) in ((1, 2), (1, 3), (2, 3)))
        chk('bit', mag0 and all(x == 0 for x in evE), '%s: the magnetic cells W_0ijk vanish in the Kerr-Schild frame, so the Euclidean-squares duality J_E gives '
            'the same even/odd split here: J_E-even part of F(c0) = 0' % fr['name'])
        Rl_raw = {k: F(0) for k in itertools.product(range(4), repeat=4)}
        for (a, b, c, dd), v in r['wb']['R'].items():
            Rl_raw[(a, b, c, dd)] = v; Rl_raw[(b, a, c, dd)] = -v; Rl_raw[(a, b, dd, c)] = -v; Rl_raw[(b, a, dd, c)] = v
        WE = {k: v for k, v in weyl_parts(Rl_raw, [1, 1, 1, 1])[0].items() if k in EE}
        chk('bit', eq36(d['F'][c0], WE), '%s: the projection of the MIXED components R^{ab}_{cd} with delta traces is W = F(c0) exactly' % fr['name'])
        WEl = weyl_parts(lowered_s(r['wb']['R'], cv.sq), [1, 1, 1, 1])[0]
        chk('ctl', not eq36(d['F'][c0], {k: cv.sq[k[0]] * cv.sq[k[1]] * WEl[k] for k in K36}), '%s: delta traces on the LOWERED R_abcd, raised back: not F(c0) (ok)' % fr['name'])
    tick('part 1'); return out

def part_ds(cv):
    head('Part 2. de Sitter and anti-de Sitter (M = 0): F(c0) = 0 (Cartan-flat), c0 = (square of time) H2; F(c) = alpha e^a e^b with alpha fitted')
    out = []
    for (M, H2, p, rho) in DS:
        fr = ks_fr_s(cv, 'dS' if H2 > 0 else 'AdS', M, H2, 0, p, rho, cv.mirror(cs_of(H2))); r = analyse_s(cv, fr); d = r['d']; out.append((fr, r)); c0 = cv.cfix(H2)
        chk('bit', is0(d['F'][c0]) and is0(r['wb']['W']), '%s: F(c = %s) = 0, all 36 components, and W = 0: flat in the Cartan sense' % (fr['name'], c0))
        chk('std', is0(lin36((1, r['ws']['R']), (c0, EE))) and max(abs(fr['sf']['R'][k] + float(c0) * float(EE[k])) for k in K36) <= 1e-6 * fr['sc'],
            '%s: the Christoffel route alone: R_std = -(%s) e^e exactly; float route: R + (%s) delta = 0 to 1e-6' % (fr['name'], c0, c0))
        al = {c: (fit36(d['F'][c], [EE])[0] or [None])[0] for c in fr['cs']}
        chk('bit', all(al[c] == c - c0 for c in fr['cs']), '%s: F(c) = alpha e^a e^b exactly with fitted alpha = c - (%s) for c in {%s} (alphas %s)'
            % (fr['name'], c0, fmtc(fr['cs']), fmtc([al[c] for c in fr['cs']])))
        chk('ctl', not is0(d['F'][-c0]), '%s: the sign of the other convention, c = %s, is not flat (F = %s e^e) (ok)' % (fr['name'], -c0, al[-c0]))
    tick('part 2'); return out

def part_nonE(cv, JE):
    head('Part 3. Reissner-Nordstrom (also with H2), Kerr (M = 5, a = 3) and random frames: F(c) - W = beta (e^a P^b - e^b P^a) + alpha e^a e^b')
    out = []
    for (M, H2, q, p, rho) in RN:
        fr = ks_fr_s(cv, 'RN', M, H2, q, p, rho, cv.mirror(sorted(set([F(0), H2, F(1, 3), F(-2, 7)])))); out.append((fr, analyse_s(cv, fr)))
    dks = []
    for (rr, ia) in KERR: dks += GK.rational_kerr_points(F(3), [rr], [ANG[ia]])
    for dk in dks:
        X = np.array([0.0] + [float(x) for x in dk['p']]); g, ef = kerr_float_fns(5, 3); s0 = cv.st
        fr = dict(name='Kerr M = 5, a = 3, r = %s, cos th = %s' % (dk['r'], dk['cth']), kind='Kerr', M=F(5), H2=F(0), cs=cv.mirror([F(0), F(1, 3), F(-2, 7)]),
                  e=GK.kerr_ks_frame_jet(dk['p'], 5, 3, dk['r'])[0], flt=((lambda Y, g=g, s0=s0: s0 * g(Y)), ef, X, 1e-3 * math.sqrt(float(sum(x * x for x in dk['p'])))))
        out.append((fr, analyse_s(cv, fr)))
    for seed in (5, 6):
        fr = dict(name='random frame seed %d' % seed, kind='rand', H2=None, cs=cv.mirror([F(0), F(1, 3), F(-2, 7)]), e=rand_frame(random.Random(seed), 4, 2, 3))
        out.append((fr, analyse_s(cv, fr)))
    for fr, r in out:
        d, W, P, Rs, cs = r['d'], r['wb']['W'], r['P'], r['Rs'], fr['cs']
        if fr['kind'] == 'Kerr':
            al = alphas(r, cs)
            chk('bit', r['trfree'] and Rs == 0 and eq36(d['F'][F(0)], W) and nnz(W) > 0 and all(al[c] == c for c in cs),
                '%s: Ricci flat; F(0) = R = W (36 components, %d nonzero); F(c) - W = c e^e (fitted alphas %s)' % (fr['name'], nnz(W), fmtc([al[c] for c in cs])))
            typ, I2, I3, info = petrov(complex_Q(lowered_s(d['F'][F(0)], cv.sq)))
            chk('bit', typ == 'D', '%s: F(0) has Petrov type %s' % (fr['name'], typ))
            sf, sc = fr['sf'], fr['sc']
            chk('std', max(abs(sf['R'][k] - sf['C'][k]) for k in K36) <= 1e-6 * sc, '%s: the float route alone: R = C (Ricci flat) to 1e-6 of the scale' % fr['name'])
            evE, odE = jparts_s(d['F'][F(0)], JE, cv.sq)
            chk('ctl', any(x != 0 for x in evE), '%s: Euclidean squares in the duality J: the J_E-even part of F(0) = W is NOT zero although Ricci = 0 (ok)' % fr['name'])
            continue
        if fr['kind'] == 'rand':
            evE, odE = jparts_s(d['F'][F(0)], JE, cv.sq)
            chk('ctl', evE != jparts_s(P36(P), cv.J, cv.sq)[0], '%s: Euclidean squares in the duality J: the J_E-even part of F(0) is not the trace-free Ricci piece (ok)' % fr['name'])
        fits = {c: fit36(lin36((1, d['F'][c]), (-1, W)), [P36(P), EE]) for c in cs}
        okfit = all(w is not None and rk == 2 and w[0] == 1 and w[1] == c + Rs / 12 for c, (w, rk) in fits.items())
        extra = (' Rs = %s = -12 (%s): the Maxwell part is traceless' % (Rs, cv.cfix(fr['H2']))) if fr['kind'] == 'RN' else (' Rs = %s' % Rs)
        chk('bit', (not r['trfree']) and okfit, '%s: trace-free Ricci != 0; fit (rank 2) beta = 1, alpha = c + Rs/12 for c in {%s} (alphas %s);%s'
            % (fr['name'], fmtc(cs), fmtc([(fits[c][0][1] if fits[c][0] else None) for c in cs]), extra))
        if fr['kind'] == 'RN': chk('bit', Rs == -12 * cv.cfix(fr['H2']), '%s: Rs = -12 x (square of time) x H2 = %s exactly (the charge term adds no trace)' % (fr['name'], Rs))
        ws = r['ws']
        chk('std', all(eq36(lin36((1, ws['R']), (c, EE), (-1, ws['W'])), lin36((1, P36(ws['P'])), (c + ws['Rs'] / 12, EE))) for c in cs),
            '%s: the Christoffel route alone: R_std + c e^e - W_std = (e^a P^b - e^b P^a)_std + (c + Rs_std/12) e^e, every c' % fr['name'])
        chk('ctl', all(fit36(lin36((1, d['F'][c]), (-1, W)), [EE])[0] is None for c in cs) and not any(r['FW'].values()),
            '%s: "F(c) - W = alpha e^a e^b" has NO solution alpha for any tested c (c = 0%s included): no c makes F(c) = W on a non-Einstein frame (ok)'
            % (fr['name'], (', c = %s' % cv.cfix(fr['H2'])) if fr.get('H2') else ''))
    tick('part 3'); return out

def part_ext(cv, frames):
    head('Part 4. The five-generator curvature in Lie(%s + [s]) (k = -s): with s = sign(H2) x (square of space), kappa^2 = |H2|, its Lorentz block is F(c0) = W '
         'and its translation block kappa T = 0' % (tuple(cv.sq),))
    for fr, r in frames:
        H2 = fr['H2']
        if H2 not in EXT: continue
        s, kappa = cv.sext(H2), EXT[H2][1]; c0 = cv.cfix(H2); Lor, Tr = ext_blocks_s(fr['e'], r['d']['om'], s, kappa, cv.sq)
        chk('bit', eq36(Lor, r['d']['F'][c0]) and eq36(Lor, r['wb']['W']) and all(v == 0 for v in Tr.values()),
            '%s: s = %+d, kappa = %s (c = -s kappa^2 = %s): Lorentz block = F(c0) = W (%s), translation block = 0, r = s/(square of space) = %+d'
            % (fr['name'], s, kappa, -s * kappa ** 2, 'zero' if is0(Lor) else '%d nonzero' % nnz(Lor), s * cv.sp))
        LorW, _ = ext_blocks_s(fr['e'], r['d']['om'], -s, kappa, cv.sq)
        chk('ctl', not eq36(LorW, r['wb']['W']) and eq36(LorW, r['d']['F'][-c0]), '%s: the square of the other convention, s = %+d, gives F(%s), not W (ok)' % (fr['name'], -s, -c0))
    tick('part 4')

def part_link(cv, allfr):
    head('Part 5. The Einstein form: E_a(c) = 0 <=> F(c) = W; F(c) - W written through M = G - 3c delta')
    for fr, r in allfr:
        if r['trfree']: continue
        okf, bad1, bad2, c0 = True, False, False, []
        for c in fr['cs']:
            M = r['M'][c]; trM = sum(M[a][a] for a in range(4)); tgt = lin36((1, r['d']['F'][c]), (-1, r['wb']['W']))
            if trM != 0:
                w, rk = fit36(tgt, [P36(M), lin36((trM, EE))]); okf &= w is not None and rk == 2 and w == [F(1, 2), F(-1, 3)]
                bad1 |= link_pred(r['d']['F'][c], r['wb']['W'], M, F(1, 2), F(-1, 4))
            else:
                c0.append(c); w, rk = fit36(tgt, [P36(M)]); okf &= w is not None and rk == 1 and w == [F(1, 2)]
            bad2 |= link_pred(r['d']['F'][c], r['wb']['W'], M, F(-1, 2), F(-1, 3))
        chk('bit', okf, '%s: fit of F(c) - W = beta (e^a M^b - e^b M^a) + gamma tr(M) e^a e^b over 36 components: beta = 1/2, gamma = -1/3 (rank 2) at every c with '
            'tr M != 0; beta = 1/2 alone (rank 1) where tr M = 0 (%s)' % (fr['name'], ('c = ' + fmtc(c0)) if c0 else 'none tested'))
        chk('ctl', not bad1 and not bad2, '%s: (beta, gamma) = (1/2, -1/4) at the c with tr M != 0 and (-1/2, -1/3) at every c fail (ok)' % fr['name'])
    rows = [(fr['name'], c, r['Ez'][c], r['FW'][c]) for fr, r in allfr for c in fr['cs']]
    tt = sum(1 for x in rows if x[2] and x[3]); ff = sum(1 for x in rows if not x[2] and not x[3]); mixed = len(rows) - tt - ff
    print('  truth table over %d (frame, c) pairs: E_a(c) = 0 and F(c) = W: %d; both false: %d; mixed: %d' % (len(rows), tt, ff, mixed))
    for fr, r in allfr:
        tr = [c for c in fr['cs'] if r['FW'][c]]; print('    %-62s F(c) = W and E_a(c) = 0 exactly at c in {%s}' % (fr['name'][:62], fmtc(tr)))
    want = all((r['FW'][c] == (fr['kind'] in ('SdS', 'SAdS', 'Schwarzschild', 'dS', 'AdS', 'Kerr') and c == cv.cfix(fr['H2']))) for fr, r in allfr for c in fr['cs'])
    chk('bit', mixed == 0 and want and (tt, ff, mixed) == SHIPPED['table'], 'E_a(c) = 0 <=> F(c) = W on all %d (frame, c) pairs; true exactly for the Einstein frames at '
        'c = (square of time) H2 (%d pairs), false on RN, random frames and every other c (%d / %d / %d, as with space squaring -1)' % (len(rows), tt, tt, ff, mixed))
    tick('part 5'); return (tt, ff, mixed)

def part_cross(flip, ours, allfr):
    head('Part 6. The two conventions on the same 21 frames; the functions of this file against l3_cartan_weyl.py with the squares (+,-,-,-)')
    fork = okF = okW = okE = okP = okJ = True; shipped = None; tt = ff = 0
    for fr, r in allfr:
        cs_o = [-c for c in fr['cs']]; do = engine_F(ours.Gv, fr['e'], ours.S, cs_o)
        Rl_o = engine_frame_riemann(ours.Gv, fr['e'], ours.S, 4, om=do['om'])[0]; wo = L3.weyl36(Rl_o); wf = weyl36s(Rl_o, SQ_OURS)
        fork &= (wf == wo) and all(lowered_s(do['F'][c], SQ_OURS) == L3.lowered_full(do['F'][c]) and jparts_s(do['F'][c], ours.J, SQ_OURS) == L3.jparts(do['F'][c], ours.J)
                                   for c in cs_o)
        if fr['kind'] in ('SdS', 'SAdS', 'dS', 'AdS') and fr['H2'] in EXT:
            so, ko = EXT[fr['H2']]; fork &= ext_blocks_s(fr['e'], do['om'], so, ko, SQ_OURS) == L3.ext_blocks(fr['e'], do['om'], so, ko)
        if fr.get('flt'):
            g, ef = kerr_float_fns(5, 3) if fr['kind'] == 'Kerr' else ks_float_fns(fr['M'], fr['H2'], fr['q'])
            X, h = fr['flt'][2], fr['flt'][3]; a1 = L3.std_float(g, ef, X, h); a2 = std_float_s(g, ef, X, h, SQ_OURS)
            fork &= max(abs(a1[key][k] - a2[key][k]) for key in ('R', 'C') for k in K36) <= 1e-12 * max(1.0, max(abs(a1['R'][k]) for k in K36))
        okF &= all(eq36(r['d']['F'][c], lin36((-1, do['F'][-c]))) for c in fr['cs'])
        okW &= eq36(r['wb']['W'], lin36((-1, wo['W'])))
        okE &= all(r['d']['E'][c] == {k: -v for k, v in do['E'][-c].items()} for c in fr['cs'])
        okP &= r['wb']['P'] == [[-x for x in row] for row in wo['P']] and r['wb']['Rs'] == -wo['Rs'] and r['wb']['tf'] == wo['tf']
        for c in cs_o:
            ez = all(v == 0 for v in do['E'][c].values()); fw = eq36(do['F'][c], wo['W']); tt += int(ez and fw); ff += int(not ez and not fw)
        if fr['name'].startswith('SdS M = 1, H2 = 1/5, p = (2, 3, 6)'):
            al = [(fit36(lin36((1, do['F'][c]), (-1, wo['W'])), [EE])[0] or [None])[0] for c in SHIPPED['cs']]
            info = petrov(complex_Q(L3.lowered_full(do['F'][F(1, 5)])))[3]
            shipped = (sorted(cs_o) == SHIPPED['cs'] and al == SHIPPED['alphas'] and info.get('double') == SHIPPED['double'] and nnz(wo['W']) == SHIPPED['nnz'], al, info.get('double'))
    okJ = flip.J == ours.J
    chk('ctl', fork, 'the functions of this file with the squares (+,-,-,-) equal those of l3_cartan_weyl.py (weyl36, lowered_full, jparts, ext_blocks, std_float) '
        'on all %d frames, every c' % len(allfr))
    chk('ctl', shipped is not None and shipped[0] and (tt, ff, sum(len(fr['cs']) for fr, r in allfr) - tt - ff) == SHIPPED['table'],
        'squares (+,-,-,-) on SdS M = 1, H2 = 1/5, p = (2, 3, 6): alphas %s, double eigenvalue %s, %d nonzero W components, and the truth table %d / %d over the '
        'mirrored c: the numbers l3_cartan_weyl.py prints' % (fmtc(shipped[1]) if shipped else None, shipped[2] if shipped else None, SHIPPED['nnz'], tt, ff))
    chk('bit', okF and okW and okE and okP, 'on all %d frames: F_flip(c) = -F_ours(-c) (36 components), W_flip = -W_ours, E_flip(c) = -E_ours(-c) (16 components), '
        'P_flip = -P_ours, Rs_flip = -Rs_ours, trace-free Ricci the same (exact)' % len(allfr))
    chk('bit', okJ, 'H1\'s duality J of the squares (-1,1,1,1) is the same signed table as that of (1,-1,-1,-1) (each sign is a product of two squares)')
    tick('part 6')

def main():
    flip = Conv('flipped', SQ_FLIP); ours = Conv('ours', SQ_OURS); JE = duality_J([1, 1, 1, 1])[0]
    head('L3-flipped: the curvature F(c) = R + c e^a e^b against the Weyl 2-form; n = 4, squares %s (space +1, time -1), exact at rational points (2-jets); '
         'duality I^2 = %s' % (tuple(SQ_FLIP), duality_J(SQ_FLIP)[1]))
    s1 = part_sds(flip, JE); s2 = part_ds(flip); s3 = part_nonE(flip, JE)
    part_ext(flip, s1 + s2); part_link(flip, s1 + s2 + s3); part_cross(flip, ours, s1 + s2 + s3)
    head('Summary: with space squaring -1 the identity holds at c = +H2 with s = -sign H2; with space squaring +1 at c = -H2 with s = +sign H2; in both r = s/(square of '
         'space) = sign H2 and c = (square of time) H2')
    finish('L3-flipped')

if __name__ == '__main__': main()
