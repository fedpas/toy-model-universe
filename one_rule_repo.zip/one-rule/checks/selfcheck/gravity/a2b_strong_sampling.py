#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A2b. Strong random sampling with a stated failure bound, for every identity shipped as "checked on random polynomial fields / frames".

   python3 a2b_strong_sampling.py [PART[:n1,n2][@N] ...] [--quick]
   PARTs: sampler degree I14 I5 dS dSsym EG A1 A3 A3LC A4 B1 MM A5 calib table      (no PART: the main set at n <= 4; n = 5 is a separate call)
   --quick: n = 3 (and a few n = 4) with fewer calibration seeds.

 Sampler: every jet coefficient present, integer, uniform in {-R..R} (R = 50: point mass p = 1/101), no forced zeros, no component
 drops, no fallback constant; frames with det e(0) != 0 by rejection. Bound: a false identity with residual Q != 0 of total degree <= D in the sampled
 coefficients (denominators cleared) passes one run with probability <= D p / (1 - r p) (r = degree of the rejected polynomial), N runs <= (that)^N.
 The bound is the result; a pass adds no physics."""
import sys, os, time, itertools, random, math, contextlib
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from b1lib import *
from fractions import Fraction as F

ARGS = [a for a in sys.argv[1:] if not a.startswith('--')]
QUICK = '--quick' in sys.argv
R50 = 50
REG = {}                                                                   # (identity, n) -> dict(D, R, rej, N, src)
def T0(): return time.time()
def tline(part, t): print('  time %s: %.1f s' % (part, time.time() - t), flush=True)
def seeds_for(tag, n, N, extra=0):
    base = sum((i + 1) * ord(ch) for i, ch in enumerate(tag))                # deterministic, distinct per identity
    return [100000 * base + 1000 * n + 10 * extra + k for k in range(1, N + 1)]
def reg(name, n, D, R, rej, npass, src):
    k = (name, n, R); d = REG.setdefault(k, dict(D=D, R=R, rej=rej, N=0, src=src)); d['N'] += npass
def safe(fn, *a, **kw):
    try: return fn(*a, **kw), None
    except Exception as ex: return None, '%s: %s' % (type(ex).__name__, str(ex)[:80])

# ------------------------------------------------------------------------------------------------ the strong sampler
def s_poly(rng, n, deg, R, nv=None):
    """every monomial of degree <= deg, coefficient uniform in {-R..R}; a zero coefficient is left out of the dict (same law: zero == absent)"""
    nv = nv or n; out = {}
    for ex in itertools.product(range(deg + 1), repeat=n):
        if sum(ex) <= deg:
            c = rng.randint(-R, R)
            if c: out[tuple(ex) + (0,) * (nv - n)] = F(c)
    return out
def s_form(rng, n, degree, deg, R):
    out = {}
    for idx in itertools.combinations(range(n), degree):
        p = s_poly(rng, n, deg, R)
        if p: out[sum(1 << i for i in idx)] = p
    return out
def s_frame(rng, n, deg, R):
    while True:
        rows = [[s_poly(rng, n, deg, R) for mu in range(n)] for a in range(n)]
        if det_inv([[at0(rows[a][mu], n) for mu in range(n)] for a in range(n)])[0] != 0:
            return [{1 << mu: rows[a][mu] for mu in range(n) if rows[a][mu]} for a in range(n)]
def s_antisym(rng, n, deg, R):
    A = [[{} for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n): p = s_poly(rng, n, deg, R); A[i][j] = p; A[j][i] = scale(p, -1)
    return A
@contextlib.contextmanager
def strong_engine_sampler(R):
    """the engine's rform / rpoly replaced by the strong sampler, so that the SHIPPED check functions run unchanged on strong fields"""
    o1, o2 = gs.rform, gs.rpoly
    gs.rform = lambda rng, n, degree, deg=1, density=.6: s_form(rng, n, degree, deg, R)
    gs.rpoly = lambda rng, n, deg, density: s_poly(rng, n, deg, R)
    try: yield
    finally: gs.rform, gs.rpoly = o1, o2
def fields(rng, n, G, R): return [s_form(rng, n, 1, 1, R) for _ in range(G)], [s_form(rng, n, 1, 1, R) for _ in range(n)]
def allz(forms): return all(gs.eqz(x) for x in forms)

# ------------------------------------------------------------------------------------------------ sampler check and tight case
def part_sampler():
    head('Sampler [std]: A2 my_poly(R = 50, density 1) and my s_poly have point mass 1/101 per coefficient; the constant is not forced'); t = T0()
    import a2_sampling as A2
    rng = random.Random(11); n = 3; tot = z = one = cst = 0; z2 = tot2 = one2 = 0
    for _ in range(3000):
        q = A2.my_poly(rng, n, 2, 50, 1.0); tot += len(q); z += sum(1 for v in q.values() if v == 0); cst += 1; one += (q.get((0,) * n) == 1)
        assert len(q) == 10                                                      # density 1: every monomial present
        r = s_poly(rng, n, 2, 50); tot2 += 10; z2 += 10 - len(r); one2 += (r.get((0,) * n, 0) == 1)
    p = 1 / 101; sd = lambda m: 4 * math.sqrt(p * (1 - p) / m)
    chk('std', abs(z / tot - p) < sd(tot) and abs(z2 / tot2 - p) < sd(tot2), 'P(coefficient = 0): my_poly %.5f, s_poly %.5f vs 1/101 = %.5f (+-%.5f): every monomial present (len 10 at degree 2, n = 3)' % (z / tot, z2 / tot2, p, sd(tot)))
    chk('std', abs(one / cst - p) < sd(cst) and abs(one2 / cst - p) < sd(cst), 'P(constant term = 1): my_poly %.4f, s_poly %.4f vs 1/101 (the engine rpoly fallback "constant 1" does not exist here)' % (one / cst, one2 / cst))
    rng = random.Random(97); M = 101; S2 = 20000; hits = sum(1 for _ in range(S2) if rng.randrange(M) < 3); b = 3 / M; s = 4 * math.sqrt(b * (1 - b) / S2)
    chk('std', abs(hits / S2 - b) < s, 'tight case Q = x(x-1)(x-2), x uniform on 101 values: zero rate %.4f vs D p = 3/101 = %.4f (+-%.4f): the bound is attained' % (hits / S2, b, s))
    tline('sampler', t)

def line_degree(n, G, build, tmax, seed):
    """exact degree of a residual along a random line t -> b + t a in the space of (omega, e) 1-jets: finite differences of the values at t = 0..tmax
       (= the total degree of the residual, generically; a lower bound on it always)"""
    rng = random.Random(seed); a = fields(rng, n, G, R50); b = fields(rng, n, G, R50); Fm = Grav(n).Fm; vals = []
    for t in range(tmax + 1):
        om = [Fm.add(x, y, t) for x, y in zip(b[0], a[0])]; e = [Fm.add(x, y, t) for x, y in zip(b[1], a[1])]
        vals.append({(i, m, k): v for i, X in enumerate(build(om, e)) for m, p in X.items() for k, v in p.items()})
    deg = -1
    for key in set().union(*vals):
        seq = [v.get(key, F(0)) for v in vals]; k = 0
        while any(seq): last = k; seq = [seq[i + 1] - seq[i] for i in range(len(seq) - 1)]; k += 1
        if any(v.get(key, 0) for v in vals): deg = max(deg, last)
    return deg
def part_degree():
    head('Degree [bit]: degrees of false residuals (D is an upper bound; it is attained by some false version, not by every one)'); t = T0()
    import a2_sampling as A2
    n = 3; Gv = Grav(n); al = A2.Alloc(n, Gv.G * n * (n + 1)); om = [al.form(1) for _ in range(Gv.G)]
    dg = lambda res: sorted(set(sum(k[n:]) for X in res for p in X.values() for k in p))
    d13 = dg(A2.residual_DR(Gv, om, F(1, 3))); dfl = dg(A2.residual_DR(Gv, om, F(1, 4), A2.flipped_f(Gv.L)))
    chk('bit', d13 == [2] and dfl == [2], 'n = 3, symbolic: D R with 1/3 in R has degrees %s, with one f entry flipped %s: the cubic part f f omega omega omega vanishes because every bracket [B1,B2] = a B3 (cyclic) of a 3-dimensional algebra satisfies Jacobi, so at n = 3 every f-or-coefficient false version of D R = 0 has degree 2 < D = 3' % (d13, dfl))
    n = 4; Gv = Grav(n); L_ = Gv.L; f2 = dict(L_.f); k0 = sorted(f2)[0]; C, v = f2[k0]; f2[k0] = (C, 2 * v); k1 = (k0[1], k0[0]); C1, v1 = f2[k1]; f2[k1] = (C1, 2 * v1)
    r3 = random.Random(3); jac = A2.residual_DR(Gv, [s_form(r3, n, 1, 0, R50) for _ in range(Gv.G)], F(1, 4), f2)
    d1 = line_degree(n, Gv.G, lambda om, e: A2.residual_DR(Gv, om, F(1, 4), f2), 4, 71)
    d0 = line_degree(n, Gv.G, lambda om, e: A2.residual_DR(Gv, om, F(1, 3)), 4, 72)
    chk('bit', d1 == 3 and d0 == 2 and not allz(jac), 'n = 4, along a random line: D R with one structure constant doubled (both orders; Jacobi broken, the residual is non-zero already on constant omega) has degree %d = D = 3 (attained); with 1/3 in R degree %d' % (d1, d0))
    def i5_false(om, e):
        Gv4 = Grav(n); Fm = Gv4.Fm; Rr = Gv4.curvature(om); T = Gv4.torsion(om, e); E, F_ = Gv4.einstein(None, e, Rr, F(1)); Eb = [dict(x) for x in E]
        for a in range(n):
            if a in (0, 2): continue
            rest = [x for x in range(n) if x not in (a, 0, 2)]; sgn = Gv4.eps([a, 0, 2] + rest); form = F_[(0, 2)]
            for d in rest: form = Fm.wedge(form, e[d])
            Eb[a] = Fm.add(Eb[a], form, -sgn)
        return [Fm.add(x, y, -1) for x, y in zip(Gv4.D_covector(om, Eb), Gv4.einstein_rhs(e, T, Rr, F(1), F_))]
    d5 = line_degree(n, Gv.G, i5_false, 5, 73)
    chk('bit', d5 == n, 'n = 4, along a random line: D E_a with the pair (0,2) left out of E (fault M2 written out), c = 1, has degree %d = D = n (attained)' % d5)
    tline('degree', t)

# ------------------------------------------------------------------------------------------------ I1-I4 (gravity_selfcheck.identities, one identity per line)
def i14_case(n, seed, R):
    rng = random.Random(seed); Gv = Grav(n); Fm = Gv.Fm; L = Gv.L; G = Gv.G
    om, e = fields(rng, n, G, R); lam = [{0: s_poly(rng, n, 2, R)} for _ in range(G)]
    ev = [S for S in range(1 << n) if popc(S) % 2 == 0]; psi = {S: {0: s_poly(rng, n, 2, R)} for S in ev}
    Rr = Gv.curvature(om); T = Gv.torsion(om, e); out = {}
    out['I1 second Bianchi D R = 0'] = allz(Gv.D_bivector(om, Rr))
    DT = Gv.D_vector(om, T); rhs = gs.zero_list(n)
    for (A, b), (c, h) in L.h.items(): rhs[c] = Fm.add(rhs[c], Fm.wedge(Rr[A], e[b]), h)
    out['I2 first Bianchi D T = R e'] = gs.lst_eq(DT, rhs)
    dom = Gv.D_bivector(om, lam); de = gs.zero_list(n)
    for (A, b), (c, h) in L.h.items(): de[c] = Fm.add(de[c], Fm.wedge(lam[A], e[b]), -h)
    dT = [Fm.d(de[c]) for c in range(n)]
    for (A, b), (c, h) in L.h.items(): dT[c] = Fm.add(dT[c], Fm.add(Fm.wedge(dom[A], e[b]), Fm.wedge(om[A], de[b])), h)
    wantT = gs.zero_list(n)
    for (A, b), (c, h) in L.h.items(): wantT[c] = Fm.add(wantT[c], Fm.wedge(lam[A], T[b]), -h)
    out['I3a torsion covariance delta T = -[lambda, T]/2'] = gs.lst_eq(dT, wantT)
    dR = [Fm.d(dom[C]) for C in range(G)]
    for (A, B), (C, f) in L.f.items(): dR[C] = Fm.add(dR[C], Fm.add(Fm.wedge(dom[A], om[B]), Fm.wedge(om[A], dom[B])), F(f, 4))
    wantR = gs.zero_list(G)
    for (A, B), (C, f) in L.f.items(): wantR[C] = Fm.add(wantR[C], Fm.wedge(Rr[A], lam[B]), F(f, 2))
    out['I3b curvature covariance delta R = [R, lambda]/2'] = gs.lst_eq(dR, wantR)
    DD = Gv.D_spinor(om, Gv.D_spinor(om, psi)); want = {}
    for A, g in enumerate(L.gens):
        for S, p in psi.items():
            m, s = bmul(g, S, L.sq); want[m] = Fm.add(want.get(m, {}), Fm.wedge(Rr[A], p), F(s, 2))
    want = {m: x for m, x in want.items() if x}
    out['I4 spinor D D psi = R psi / 2'] = all(gs.Gr_eq(DD.get(m, {}), want.get(m, {})) for m in set(DD) | set(want))
    terms = {'I1': [Fm.d(x) for x in Rr], 'I2': DT, 'I3a': dT, 'I3b': dR, 'I4': [x for x in want.values()]}
    trivial = sorted(k for k, v in terms.items() if allz(v))                  # identities whose terms all vanish: 0 = 0 on every field
    return out, trivial
def part_I14(ns, N):
    head('I1-I4 [bit] (gravity_selfcheck.identities): strong sampler, %d independent seeds per n, one line per identity; and the shipped function, unchanged, on the same sampler' % N)
    for n in ns:
        t = T0(); npass = {}
        for seed in seeds_for('I14', n, N):
            r, err = safe(i14_case, n, seed, R50)
            if err: chk('bit', False, 'n = %d seed %d: exception %s' % (n, seed, err)); continue
            out, trivial = r; expect = ['I1', 'I2', 'I3b'] if n == 2 else []
            for k, v in out.items():
                chk('bit', v, 'n = %d seed %d: %s, residual exactly zero%s' % (n, seed, k, ' (0 = 0 here: nothing tested)' if k.split(' ')[0] in trivial else ''))
                if k.split(' ')[0] not in trivial: npass[k] = npass.get(k, 0) + int(v)
            chk('bit', trivial == expect, 'n = %d seed %d: identities that are 0 = 0 on every field: %s (expected %s: at n = 2 D R and D T are 3-forms, and so(1,1) is abelian)' % (n, seed, trivial or 'none', expect or 'none'))
            with strong_engine_sampler(R50): ok, err = safe(gs.identities, n, seed)
            chk('bit', ok is not None, 'n = %d seed %d: the shipped gravity_selfcheck.identities(n, seed), unchanged, passes on the strong sampler%s' % (n, seed, (' (' + err + ')') if err else ''))
        for k, v in npass.items(): reg(k.split(' ')[0], n, 3, R50, 0, v, 'A2')
        tline('I1-I4 n = %d' % n, t)

# ------------------------------------------------------------------------------------------------ I5 (einstein_identities)
def i5_case(n, c, seed, R):
    rng = random.Random(seed); Gv = Grav(n); om, e = fields(rng, n, Gv.G, R)
    Rr = Gv.curvature(om); T = Gv.torsion(om, e); E, F_ = Gv.einstein(None, e, Rr, c); DE = Gv.D_covector(om, E); rhs = Gv.einstein_rhs(e, T, Rr, c, F_)
    ok = gs.lst_eq(DE, rhs)
    if n == 3 and c == 0: ok = ok and allz(DE)
    return ok, (not allz(rhs)) if (n > 3 or c != 0) else (not allz(E))
def part_I5(cases, N):
    head('I5 [bit] D E_a = torsion terms (einstein_identities): strong sampler, %d seeds per (n, c); both sides are linear in c, so c = 0 and c = 1 cover every c' % N)
    for (n, c) in cases:
        t = T0(); np_ = 0
        for seed in seeds_for('I5', n, N, c):
            r, err = safe(i5_case, n, F(c), seed, R50)
            ok = r is not None and r[0]; np_ += int(ok)
            chk('bit', ok, 'n = %d c = %d seed %d: D E_a = torsion terms, exactly%s%s' % (n, c, seed, ' (and D E_a = 0 identically at n = 3, c = 0)' if (n == 3 and c == 0) else '', (' ' + err) if err else ''))
            if r: chk('bit', r[1], 'n = %d c = %d seed %d: the torsion terms (or E itself at n = 3, c = 0) are non-zero' % (n, c, seed))
            with strong_engine_sampler(R50): ok2, err = safe(gs.einstein_identities, n, seed, F(c))
            chk('bit', ok2 is not None, 'n = %d c = %d seed %d: the shipped einstein_identities, unchanged, passes on the strong sampler%s' % (n, c, seed, (' (' + err + ')') if err else ''))
        reg('I5 c=%d' % c, n, n, R50, 0, np_, 'A2')
        tline('I5 n = %d c = %d' % (n, c), t)

# ------------------------------------------------------------------------------------------------ de Sitter / anti-de Sitter embedding
def ds_residual(n, s, om, e, k, mu):
    sq_ext = [1] + [-1] * (n - 1) + [s]; Lx = Lie(sq_ext); Gx = Grav(n, Lx); Gl = Grav(n); Fm = Gx.Fm; L = Gl.L
    A = [{} for _ in range(Lx.G)]
    for A_, g in enumerate(L.gens): A[Lx.idx[g]] = om[A_]
    for a in range(n): A[Lx.idx[(1 << a) | (1 << n)]] = e[a]
    Fx = Gx.curvature(A); Rr = Gl.curvature(om); T = Gl.torsion(om, e); res = []
    for (a, b) in itertools.combinations(range(n), 2):
        res.append(Fm.add(Fm.add(Fx[Lx.idx[(1 << a) | (1 << b)]], Rr[L.idx[(1 << a) | (1 << b)]], -1), Fm.wedge(e[a], e[b]), -k))
    for a in range(n): res.append(Fm.add(Fx[Lx.idx[(1 << a) | (1 << n)]], T[a], -mu))
    return res
KMU = {}
def shipped_kmu(n, s):
    """(k, mu) of the shipped build() run (engine sampler, seed 11 n + s); on an exception (a fault) the expected (-s, 1) and the error"""
    if (n, s) not in KMU:
        r, err = safe(gs.desitter_embedding, n, 11 * n + s, s); KMU[(n, s)] = (r[0], r[1], None) if r else (F(-s), F(1), err)
    return KMU[(n, s)]
def part_dS(ns, N):
    head('dS embedding [bit]: F^{ab} = R^{ab} + k e^a e^b and F^{an} = mu T^a with k, mu FIXED (the shipped values), strong sampler, %d seeds per (n, s)' % N)
    for n in ns:
        for s in (-1, 1):
            t = T0(); k, mu, err0 = shipped_kmu(n, s)
            chk('bit', err0 is None and k == -s and mu == 1, 'n = %d s = %+d: the shipped build() values k = %s, mu = %s (k = -s, mu = 1 with kappa = 1)%s' % (n, s, k, mu, (' ' + err0) if err0 else ''))
            np_ = 0
            for seed in seeds_for('dS', n, N, s + 1):
                rng = random.Random(seed); om, e = fields(rng, n, n * (n - 1) // 2, R50)
                r, err = safe(ds_residual, n, s, om, e, k, mu); ok = r is not None and allz(r); np_ += int(ok)
                chk('bit', ok, 'n = %d s = %+d seed %d: both residuals exactly zero%s' % (n, s, seed, (' ' + err) if err else ''))
                r2, _ = safe(ds_residual, n, s, om, e, -k, mu)
                chk('ctl', r2 is not None and not allz(r2), 'n = %d s = %+d seed %d: with -k (the other sign of the cosmological term) the residual is non-zero' % (n, s, seed))
                with strong_engine_sampler(R50): kk, err = safe(gs.desitter_embedding, n, seed, s)
                chk('bit', kk == (k, mu), 'n = %d s = %+d seed %d: the shipped desitter_embedding (ratio form), unchanged, on the strong sampler returns (k, mu) = %s%s' % (n, s, seed, kk, (' ' + err) if err else ''))
            reg('dS s=%+d' % s, n, 2, R50, 0, np_, 'A2')
            tline('dS n = %d s = %+d' % (n, s), t)
def part_dSsym(ns):
    head('dS embedding [bit], exact: symbolic 1-jets (every coefficient a variable), so the identity holds as a polynomial identity (supersedes sampling)')
    import a2_sampling as A2
    for n in ns:
        t = T0(); G = n * (n - 1) // 2
        for s in (-1, 1):
            al = A2.Alloc(n, G * n * (n + 1) + n * n * (n + 1)); om = [al.form(1) for _ in range(G)]; e = [al.form(1) for _ in range(n)]
            k, mu, _ = shipped_kmu(n, s); r, err = safe(ds_residual, n, s, om, e, k, mu)
            chk('bit', r is not None and allz(r), 'n = %d s = %+d: F = R + k e e and F^{an} = mu T as polynomial identities in the %d jet coefficients of (omega, e)%s' % (n, s, al.k, (' ' + err) if err else ''))
            r2, _ = safe(ds_residual, n, s, om, e, -k, mu); degs = [sum(kk[n:]) for X in (r2 or []) for p in X.values() for kk in p]
            chk('ctl', r2 is not None and not allz(r2) and max(degs) == 2, 'n = %d s = %+d: with -k the expansion is a non-zero polynomial of degree %s (= D = 2)' % (n, s, max(degs) if degs else '-'))
        tline('dS symbolic n = %d' % n, t)

# ------------------------------------------------------------------------------------------------ E = r G at e = dx (einstein_is_einstein_tensor)
def eg_parts(n, Rv):
    Gv = Grav(n); Fm = Gv.Fm; L = Gv.L; zero = (0,) * n; e = [{1 << a: {zero: F(1)}} for a in range(n)]; P = list(itertools.combinations(range(n), 2))
    R = [{} for _ in range(Gv.G)]
    for (b, c) in P:
        for (d, f) in P:
            if Rv.get((b, c, d, f)): R[L.idx[(1 << b) | (1 << c)]][(1 << d) | (1 << f)] = {zero: Rv[(b, c, d, f)]}
    E, _ = Gv.einstein(None, e, R, 0); full = (1 << n) - 1; comp = {}
    for a in range(n):
        for mu in range(n):
            mask = full ^ (1 << mu); _, sg = bmul(1 << mu, mask, Fm.sq0); comp[(a, mu)] = F(E[a].get(mask, {}).get(zero, 0)) * sg
    ric = {(b, ee): sum(Rv.get((b, c, c, ee), 0) for c in range(n) if c != b) for b in range(n) for ee in range(n)}
    Ssc = sum(ric[(b, b)] for b in range(n)); G_ = {(b, ee): ric[(b, ee)] - (F(1, 2) * Ssc if b == ee else 0) for b in range(n) for ee in range(n)}
    return comp, G_, ric
def full_R(vals):
    Rv = {}
    for (b, c, d, f), v in vals.items(): Rv[(b, c, d, f)] = v; Rv[(c, b, d, f)] = -v; Rv[(b, c, f, d)] = -v; Rv[(c, b, f, d)] = v
    return Rv
def eg_ok(n, Rv, r, use='G'):
    comp, G_, ric = eg_parts(n, Rv); M = G_ if use == 'G' else ric
    return all(comp[(a, mu)] == r * M[(mu, a)] for a in range(n) for mu in range(n)), any(G_.values())
def part_EG(ns, N):
    head('E = r G at e = dx [bit] (einstein_is_einstein_tensor): linear in R (D = 1); strong R (uniform in {-50..50}) at %d seeds, and a complete basis of R (exact: supersedes sampling)' % N)
    for n in ns:
        t = T0(); rr, err = safe(gs.einstein_is_einstein_tensor, n, 5 * n); r = F(rr) if rr is not None else F(-1); P = list(itertools.combinations(range(n), 2)); np_ = 0
        chk('bit', rr is not None, 'n = %d: the shipped einstein_is_einstein_tensor(n, 5n) returns a single ratio r = %s%s' % (n, rr, (' ' + err) if err else ''))
        for seed in seeds_for('EG', n, N):
            rng = random.Random(seed); Rv = full_R({(b, c, d, f): F(rng.randint(-R50, R50)) for (b, c) in P for (d, f) in P})
            ok, nz = eg_ok(n, Rv, r); np_ += int(ok and nz)
            chk('bit', ok and nz, 'n = %d seed %d: E_a = r G^mu_a in all %d components with the shipped ratio r = %s; G != 0' % (n, seed, n * n, r))
            chk('ctl', not eg_ok(n, Rv, -r)[0] and not eg_ok(n, Rv, r, 'Ric')[0], 'n = %d seed %d: with -r, and with the Ricci tensor in place of the Einstein tensor, the match fails' % (n, seed))
        reg('EG', n, 1, R50, 0, np_, 'derived')
        allb = all(eg_ok(n, full_R({(b, c, d, f): F(1)}), r)[0] for (b, c) in P for (d, f) in P)
        chk('bit', allb, 'n = %d: E = r G on each of the %d basis elements R^{bc}_{df} = 1: by linearity E = r G for every R (exact, any R)' % (n, len(P) ** 2))
        tline('EG n = %d' % n, t)

# ------------------------------------------------------------------------------------------------ A1 chain (a1_lemmas.de_chain with strong fields)
def part_A1(cases, N):
    head('A1 chain [bit] (a1_lemmas.de_chain: the D E_a derivation step by step) with strong fields, %d seeds per (n, c); D = max(3, n) (derived)' % N)
    import a1_lemmas as A1
    def strong_fields(n, seed, density=.5):
        rng = random.Random(seed); Gv = Grav(n); om, e = fields(rng, n, Gv.G, R50); return Gv, om, e
    orig = A1.fields; A1.fields = strong_fields
    try:
        for (n, c) in cases:
            t = T0(); np_ = 0
            for seed in seeds_for('A1', n, N, c):
                out, err = safe(A1.de_chain, n, seed, F(c)); ok = out is not None and all(out.values()); np_ += int(ok)
                chk('bit', ok, 'n = %d c = %d seed %d: every step of the chain holds exactly (%s)%s' % (n, c, seed, ', '.join(sorted(out)) if out else '-', (' ' + err) if err else ''))
            reg('A1 chain c=%d' % c, n, max(3, n), R50, 0, np_, 'derived')
            tline('A1 n = %d c = %d' % (n, c), t)
        if any(n >= 4 for n, _ in cases):
            out, _ = safe(A1.de_chain, 4, seeds_for('A1ctl', 4, 1)[0], F(1), tsign=lambda j: -(-1) ** j)
            chk('ctl', out is not None and not out['i_epsilon_step'] and not out['iii_rhs'], 'n = 4: the chain with the torsion slot sign flipped fails on a strong field')
    finally: A1.fields = orig

# ------------------------------------------------------------------------------------------------ A3: T(omega(e)) = 0 and omega = Levi-Civita
def part_A3(ns, N, R=R50):
    head('A3 [bit] T(omega_closed_form(e)) = 0 at the origin of strong random frames (degree 2), %d seeds per n; D = 2n + 1 after det(e)^2 (derived), rejection det e(0) != 0' % N)
    for n in ns:
        t = T0(); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); np_ = 0
        k0 = sorted(S)[0]; kk = sorted(S[k0])[0]; Sbad = {k: dict(v) for k, v in S.items()}; Sbad[k0][kk] = -Sbad[k0][kk]
        for seed in seeds_for('A3', n, N, R % 7):
            rng = random.Random(seed); e = s_frame(rng, n, 2, R)
            om, w, D = omega_closed_form(Gv, e, S, n, 0); ok = torsion_zero_at0(Gv, om, e, n) and any(v != 0 for v in w.values()); np_ += int(ok)
            chk('bit', ok, 'n = %d R = %d seed %d: the engine torsion of the closed-form omega is exactly zero at the origin, omega != 0' % (n, R, seed))
            chk('ctl', not torsion_zero_at0(Gv, omega_closed_form(Gv, e, Sbad, n, 0)[0], e, n), 'n = %d seed %d: with one entry of S negated the torsion is not zero' % (n, seed))
        reg('A3 T=0', n, 2 * n + 1, R, n, np_, 'derived')
        tline('A3 n = %d R = %d' % (n, R), t)
def part_A3LC(ns, N, R=R50):
    head('A3 [bit==std] the closed-form omega equals the Levi-Civita connection from Christoffel symbols (tetrad postulate), strong frames, %d seeds; D = 3n (derived)' % N)
    import a3_closed_form as A3m
    for n in ns:
        t = T0(); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); np_ = 0
        for seed in seeds_for('A3LC', n, N, R % 7):
            rng = random.Random(seed); e = s_frame(rng, n, 2, R); e0, E0, det = E0_of(e, n, n)
            g = std_metric(e, n, sq, n, 2); Gam = A3m.christoffel0(g, n, n)
            de0 = {(a, mu, nu): at0(sp_der(e[a].get(1 << nu, {}), mu), n) for a in range(n) for mu in range(n) for nu in range(n)}
            om, w, D = omega_closed_form(Gv, e, S, n, 0); ok = True; bad = True
            for A, (a, b) in enumerate(pairs_of(Lie_)):
                for mu in range(n):
                    wab = sum((sum(Gam[(l, mu, nu)] * e0[a][l] for l in range(n)) - de0[(a, mu, nu)]) * E0[nu][b] for nu in range(n)) * sq[b]
                    ok &= (wab == at0(om[A].get(1 << mu, {}), n)); bad &= (-wab == at0(om[A].get(1 << mu, {}), n))
            np_ += int(ok)
            chk('bit==std', ok, 'n = %d seed %d: omega (closed form, engine d) == Levi-Civita (Christoffel, plain derivatives), all %d components' % (n, seed, Gv.G * n))
            chk('ctl', not bad, 'n = %d seed %d: -omega (the sign that d -> -d would give) does not match' % (n, seed))
        reg('A3 omega=LC', n, 3 * n, R, n, np_, 'derived')
        tline('A3LC n = %d' % n, t)

# ------------------------------------------------------------------------------------------------ A4: E_a = -(G - Lambda) Theta for any frame
def part_A4(ns, N, R=R50):
    head('A4 [bit==std] E_a(c) = -(G^h_a - Lambda_n delta^h_a) Theta_h, strong random frames (degree 2), c = 0 and 1/3 (linear in c), %d seed(s) per n; D = 8n - 3 (A2) and n - 1 for the c-part' % N)
    import a4_einstein_tensor as A4m
    for n in ns:
        t = T0(); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); np_ = 0
        for seed in seeds_for('A4', n, N, R % 7):
            t1 = T0(); rng = random.Random(seed); e = s_frame(rng, n, 2, R); e0, E0, det = E0_of(e, n, n)
            g = std_metric(e, n, sq, n, 2); R1, g0, g0i = std_riemann(g, n, n, 1); Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, n); Gfr = to_frame_mixed(Gm, e0, E0, n)
            ricfr = to_frame_mixed([[sum(g0i[m][s_] * ric[s_][v] for s_ in range(n)) for v in range(n)] for m in range(n)], e0, E0, n)
            om = omega_closed_form(Gv, e, S, n, 1)[0]; ok = True; ctl = True
            for c in (F(0), F(1, 3)):
                comp = A4m.engine_E(Gv, e, S, n, c, om)[0]; Lam = c * F((n - 1) * (n - 2), 2)
                pred = predicted_components([[Gfr[h][a] - (Lam if h == a else 0) for a in range(n)] for h in range(n)], e0, E0, det, n, s=-1)
                ok &= all(comp.get(k, 0) == pred.get(k, 0) for k in set(comp) | set(pred))
                bad = predicted_components([[ricfr[h][a] - (Rs if h == a else 0) - (Lam if h == a else 0) for a in range(n)] for h in range(n)], e0, E0, det, n, s=-1)
                ctl &= any(comp.get(k, 0) != bad.get(k, 0) for k in set(comp) | set(bad))
            nonvac = any(Gfr[b][a] != 0 for a in range(n) for b in range(n)); np_ += int(ok and nonvac)
            chk('bit==std', ok and nonvac, 'n = %d R = %d seed %d: engine E_a == -(G - Lambda_n) Theta (Christoffel route) in all %d components at c = 0 and 1/3; G != 0 (%.1f s)' % (n, R, seed, n * n, time.time() - t1))
            chk('ctl', ctl, 'n = %d seed %d: with trace coefficient 1 instead of 1/2 the prediction differs from the engine' % (n, seed))
        reg('A4', n, 8 * n - 3, R, n, np_, 'A2+c-part derived')
        tline('A4 n = %d R = %d' % (n, R), t)

# ------------------------------------------------------------------------------------------------ B1: first variation, Einstein-Cartan and MacDowell-Mansouri
def part_B1(ns, N):
    head('B1 [bit] dL = de^a E_a(c) + dom Theta + d(dom Y) on strong random fields (e, omega, de, dom of degree 1), c = 0 and 1/3 (linear in c), %d seed(s) per n; D = n (A2)' % N)
    import b1_first_variation as B1m
    for n in ns:
        t = T0(); sq = LORENTZ(n); Gv = Grav(n, Lie(sq)); Fm = Gv.Fm; np_ = 0
        for seed in seeds_for('B1', n, N):
            rng = random.Random(seed); om, e = fields(rng, n, Gv.G, R50); dom, de = fields(rng, n, Gv.G, R50); ok = True; ctl = True
            for c in (F(0), F(1, 3)):
                first, top = B1m.first_variation(Gv, lambda ee, oo: B1m.lag_EC(Gv, ee, oo, c), e, om, de, dom)
                ep, op, dth = B1m.rhs_pieces(Gv, e, om, de, dom, c)
                ok &= B1m.is_zero(Fm, top) and B1m.is_zero(Fm, first, Fm.add(Fm.add(ep, op), dth)) and not B1m.is_zero(Fm, first)
                _, _, dbad = B1m.rhs_pieces(Gv, e, om, de, dom, c, ctheta=-1); ctl &= not B1m.is_zero(Fm, first, Fm.add(Fm.add(ep, op), dbad))
            np_ += int(ok)
            chk('bit', ok, 'n = %d seed %d: first variation == the three pieces exactly, eps^(n+1) coefficient zero, variation non-zero, c = 0 and 1/3' % (n, seed))
            chk('ctl', ctl, 'n = %d seed %d: with the sign of the total derivative flipped the identity fails' % (n, seed))
        reg('B1 EC', n, n, R50, 0, np_, 'A2')
        tline('B1 n = %d' % n, t)
def part_MM(N):
    head('B1 MacDowell-Mansouri [bit] n = 4: dL_MM = 8c (de^a E_a) + 4c (eps dom T e) + 2 d(eps dom F) with these FIXED coefficients, strong fields, %d seeds; D = 4 (A2)' % N)
    import b1_first_variation as B1m
    t = T0(); n = 4; Gv = Grav(n, Lie(LORENTZ(n))); Fm = Gv.Fm; np_ = 0
    for seed in seeds_for('MM', n, N):
        rng = random.Random(seed); om, e = fields(rng, n, Gv.G, R50); dom, de = fields(rng, n, Gv.G, R50); ok = True; ctl = True
        for c in (F(0), F(1, 3)):
            first, top = B1m.first_variation(Gv, lambda ee, oo: B1m.lag_MM(Gv, ee, oo, c), e, om, de, dom); pe, po, pt = B1m.mm_pieces(Gv, e, om, de, dom, c)
            want = Fm.add(Fm.add(Fm.scale(pe, 8 * c), Fm.scale(po, 4 * c)), Fm.scale(pt, 2)); ok &= B1m.is_zero(Fm, top) and B1m.is_zero(Fm, first, want) and not B1m.is_zero(Fm, first)
            ctl &= not B1m.is_zero(Fm, first, Fm.add(Fm.add(Fm.scale(pe, 8 * c), Fm.scale(po, 4 * c)), Fm.scale(pt, 1)))
        np_ += int(ok)
        chk('bit', ok, 'MM n = 4 seed %d: exact with (x, y, z) = (8c, 4c, 2) at c = 0 and 1/3' % seed)
        chk('ctl', ctl, 'MM n = 4 seed %d: with z = 1 instead of 2 the identity fails' % seed)
    reg('B1 MM', 4, 4, R50, 0, np_, 'A2'); tline('MM', t)

# ------------------------------------------------------------------------------------------------ A5: Lorentz covariance of E_a (Cayley transform), R = 500
def a5_case(n, seed, R):
    import a5_lorentz_covariance as A5m
    rng = random.Random(seed); sq = LORENTZ(n); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_); cs = [F(0), F(1, 3)]
    e = s_frame(rng, n, 2, R)
    while True:
        A = s_antisym(rng, n, 2, R); X = [[scale(A[i][j], sq[i]) for j in range(n)] for i in range(n)]; X0 = A5m.jmat_at0(X, n)
        if any(X0[i][j] for i in range(n) for j in range(n)) and det_inv([[F(int(i == j)) - X0[i][j] for j in range(n)] for i in range(n)])[0] != 0: break
    L = A5m.cayley_jet(X, n, 2); L0 = A5m.jmat_at0(L, n); lor = A5m.lorentz_defect(L, sq, n, 2) == [] and det_inv(L0)[0] == 1
    base = A5m.engine_all(Gv, e, S, n, cs); rot = A5m.engine_all(Gv, A5m.rotate_frame(L, e, n, 2), S, n, cs)
    ok = all(rot['comp'][c] == A5m.E_law(base['comp'][c], L0, n, sq) for c in cs)
    ctl = any(rot['comp'][c] != A5m.E_law(base['comp'][c], L0, n, sq, vector=True) for c in cs)
    return lor, ok, ctl
def part_A5(ns, N, R, register=True):
    D = lambda n: (5 * n - 3) * (3 * n + 1)
    head('A5 [bit] E_a(Lambda e) = det(Lambda) (Lambda^-1)^b_a E_b(e), Lambda = Cayley transform of a strong antisymmetric 2-jet, R = %d, %d seed(s); D = (5n-3)(3n+1) (derived)' % (R, N))
    for n in ns:
        t = T0(); np_ = 0
        for seed in seeds_for('A5', n, N, R % 7):
            t1 = T0(); r, err = safe(a5_case, n, seed, R)
            lor, ok, ctl = r if r else (False, False, False); np_ += int(lor and ok)
            chk('bit', lor and ok, 'n = %d R = %d seed %d: Lambda is Lorentz to second order with det 1, and the covector law holds in every component at c = 0 and 1/3 (%.1f s)%s' % (n, R, seed, time.time() - t1, (' ' + err) if err else ''))
            chk('ctl', ctl, 'n = %d R = %d seed %d: the vector law Lambda E (instead of det(Lambda) Lambda^-T E) fails' % (n, R, seed))
        if register: reg('A5 (R=%d)' % R, n, D(n), R, 2 * n + 1, np_, 'derived')
        else: print('  (R = %d: a detection / cost probe, not entered in the bound table: D p = %d/%d > 1)' % (R, D(n), 2 * R + 1))
        tline('A5 n = %d R = %d' % (n, R), t)

# ------------------------------------------------------------------------------------------------ calibration and the fault M6
def m6():
    """fault M6, in memory only: the structure constants f of every pair of bivectors sharing the LAST generator change sign; returns the undo"""
    orig = gs.Lie.__init__
    def init(self, sq):
        orig(self, sq); last = 1 << (self.N - 1)
        for (A, B), (C, f) in list(self.f.items()):
            if self.gens[A] & last and self.gens[B] & last: self.f[(A, B)] = (C, -f)
    gs.Lie.__init__ = init
    return lambda: setattr(gs.Lie, '__init__', orig)
@contextlib.contextmanager
def small_integer_sampler():
    """the small-integer sampler of gravity_selfcheck.py for the calls inside, in memory only: sform (every coefficient, integers in -50..50) replaced by
    rform with density 1/2 (a coefficient present with probability 1/2, integers in -3..3; a component present with probability 9/10)"""
    o = gs.sform
    gs.sform = lambda rng, n, degree, deg=1: gs.rform(rng, n, degree, deg, .5)
    try: yield
    finally: gs.sform = o
def part_calib(N):
    import a2_sampling as A2
    head('Calibration [ctl][std] n = 3, strong sampler, %d seeds per false version: misses must be <= the bound 3/101 per seed (and are expected to be 0)' % N); t = T0()
    n = 3; Gv = Grav(n); L_ = Gv.L; f_flip = A2.flipped_f(L_); h_flip = A2.flipped_h(L_)
    falses = {'R with 1/3': lambda om, e: A2.residual_DR(Gv, om, F(1, 3)), 'R with 1/2 (= M1)': lambda om, e: A2.residual_DR(Gv, om, F(1, 2)),
              'one f entry flipped (D R = 0)': lambda om, e: A2.residual_DR(Gv, om, F(1, 4), f_flip), 'one h entry flipped (D T = R e)': lambda om, e: A2.residual_DT(Gv, om, e, h_flip)}
    miss = {k: 0 for k in falses}; true_fail = 0; rng = random.Random(4242)
    for s in range(N):
        om, e = fields(rng, n, Gv.G, R50)
        if not A2.allzero(A2.residual_DR(Gv, om)) or not A2.allzero(A2.residual_DT(Gv, om, e)): true_fail += 1
        for k, fn in falses.items(): miss[k] += int(A2.allzero(fn(om, e)))
    chk('bit', true_fail == 0, 'the true identities (engine f, h, 1/4) pass all %d seeds' % N)
    for k, m in miss.items():
        chk('ctl', m / N <= 3 / 101, 'false identity "%s": missed %d of %d <= bound 3/101 = 0.0297 per seed' % (k, m, N))
        chk('std', m == 0, 'false identity "%s": caught at every one of the %d seeds' % (k, N))
    tline('calibration', t); t = T0()
    head('Fault M6 (the structure constants f of the pairs of bivectors that share the last generator, sign flipped in memory by m6 above), D E_a at n = 3, c = 0: '
         'one small-integer field lets it pass, the strong sampler catches it')
    undo = m6()
    try:
        with small_integer_sampler(): ok, err = safe(gs.einstein_identities, 3, 51, F(0))
        chk('std', ok is not None, 'reproduced: under M6 one run of einstein_identities(3, seed 51, c = 0) on the small-integer sampler rform of gravity_selfcheck.py '
            '(one seed, integers in -3..3, each coefficient present with probability 1/2) passes: one such field does not see the fault')
        sd = gs.seeds(17 * 3); caught = 0
        for seed in sd:
            r, err = safe(gs.einstein_identities, 3, seed, F(0)); caught += int(r is None and (err or '').startswith("AssertionError: ('D E_a = torsion terms'"))
        chk('ctl', caught == len(sd), 'under M6: the shipped einstein_identities(3, seed, c = 0) on its strong sampler (every coefficient, integers in -50..50) stops on the '
            'assertion "D E_a = torsion terms" at seeds %s (the seeds of the package run): missed %d of %d' % (', '.join(str(s) for s in sd), len(sd) - caught, len(sd)))
        for seed in seeds_for('I5', 3, 3, 0):
            r, err = safe(i5_case, 3, F(0), seed, R50)
            chk('ctl', r is not None and not r[0], 'under M6: the strong sampler catches it at seed %d (the same seeds as the I5 runs)' % seed)
        m = 0; rng = random.Random(5151)
        for s in range(N):
            r, err = safe(i5_case, 3, F(0), rng.randrange(10 ** 9), R50); m += int(r is not None and r[0])
        chk('ctl', m / N <= 3 / 101, 'under M6: missed %d of %d strong seeds <= bound n/101 = 3/101' % (m, N))
    finally: undo()
    tline('fault M6', t)

# ------------------------------------------------------------------------------------------------ the bound table
def part_table():
    head('Table [std]: per-run bound D p / (1 - r p) and combined bound over the N passing independent seeds of THIS run (exact, printed as decimals)')
    print('  %-34s %3s %-22s %4s %8s %3s %12s %12s' % ('identity', 'n', 'D (source)', 'R', 'p', 'r', 'bound/run', 'combined'))
    for (name, n, _R), d in sorted(REG.items(), key=lambda kv: kv[0]):
        p = F(1, 2 * d['R'] + 1); b = d['D'] * p / (1 - d['rej'] * p); comb = b ** d['N'] if d['N'] else None
        print('  %-34s %3d %-22s %4d %8s %3d %12.3e %12s   N = %d' % (name, n, '%d (%s)' % (d['D'], d['src']), d['R'], '1/%d' % (2 * d['R'] + 1), d['rej'], float(b), ('%.3e' % float(comb)) if comb is not None else '-', d['N']))
    chk('std', all(d['D'] * F(1, 2 * d['R'] + 1) / (1 - d['rej'] * F(1, 2 * d['R'] + 1)) < 1 for d in REG.values()), 'every per-run bound in this table is below 1')

# ------------------------------------------------------------------------------------------------ driver
MAIN = ['sampler', 'degree', 'I14:2,3,4', 'I5', 'dS:3,4', 'dSsym:3,4', 'EG:3,4,5', 'A1:3,4', 'A3:2,3,4,5,6', 'A3:5,6#500', 'A3LC:3,4', 'A4:3,4', 'A4:3,4#500',
        'B1:3,4', 'MM', 'A5:3,4', 'A5r50', 'calib', 'table']
N5 = ['I14:5', 'I5:5', 'A1:5', 'A3LC:5', 'A4:5', 'A4:5#500', 'B1:5', 'table']                       # the n = 5 call (python3 ... --n5)
QUICKSET = ['sampler', 'I14:3', 'I5q', 'dS:3', 'EG:3', 'A1:3', 'A3:3', 'A3LC:3', 'A4:3@1', 'B1:3@1', 'A5:3@1', 'calib', 'table']
def parse(a):
    N = None; R = None
    if '#' in a: a, R = a.split('#'); R = int(R)
    if '@' in a: a, N = a.split('@'); N = int(N)
    ns = None
    if ':' in a: a, s = a.split(':'); ns = [int(x) for x in s.split(',')]
    return a, ns, N, R
if __name__ == '__main__':
    parts = ARGS or (QUICKSET if QUICK else (N5 if '--n5' in sys.argv else MAIN)); t_all = T0()
    print('A2b strong sampling: parts %s%s' % (' '.join(parts), ' (--quick)' if QUICK else ''))
    for a in parts:
        name, ns, N, RR = parse(a); N3 = N or 3; RR = RR or R50
        if name == 'sampler': part_sampler()
        elif name == 'degree': part_degree()
        elif name == 'I14': part_I14(ns or [2, 3, 4], N3)
        elif name == 'I5': part_I5([(n, c) for n in (ns or [3, 4]) for c in (0, 1)], N3)
        elif name == 'I5q': part_I5([(3, 0), (3, 1)], N3)
        elif name == 'dS': part_dS(ns or [3, 4], N3)
        elif name == 'dSsym': part_dSsym(ns or [3, 4])
        elif name == 'EG': part_EG(ns or [3, 4, 5], N3)
        elif name == 'A1': part_A1([(n, c) for n in (ns or [3, 4]) for c in (0, 1)], N3)
        elif name == 'A3': part_A3(ns or [2, 3, 4, 5, 6], N3, RR)
        elif name == 'A3LC': part_A3LC(ns or [3, 4], N3, RR)
        elif name == 'A4': part_A4(ns or [3, 4], N3, RR)
        elif name == 'B1': part_B1(ns or [3, 4], N3)
        elif name == 'MM': part_MM(N3)
        elif name == 'A5': part_A5(ns or [3], N3, 500 if not QUICK else R50, register=not QUICK)
        elif name == 'A5r50': part_A5(ns or [3], N or 1, R50, register=False)
        elif name == 'calib': part_calib(10 if QUICK else 50)
        elif name == 'table': part_table()
        else: raise SystemExit('unknown part ' + a)
    tline('total', t_all); finish('A2b')
