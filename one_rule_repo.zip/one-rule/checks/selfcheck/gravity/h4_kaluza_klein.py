#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H4.  Kaluza-Klein at n = 5: fibre generator of square eps, fields independent of the fifth coordinate.   python3 h4_kaluza_klein.py

 Frame algebra squares sq = (1, -1, -1, -1, eps); coordinates (x^0..x^3, y); coframe e^a = e4^a(x) (a = 0..3), e^4 = phi(x) (dy + A(x)).
 [bit]  omega = A3 closed form, R = d omega + 1/4 [omega, omega], E_a (c = 0) of the engine; G5^b_a read off E_a = -G5^h_a Theta_h (A4).
 [std]  (i)  5D: g5 = e^T eta e, Christoffel route (b1lib.std_riemann), frame mixed Einstein tensor.
        (ii) 4D only (no 5D object, no engine): g4 = e4^T eta4 e4 and its Einstein tensor, F = dA, the Maxwell stress
             T^b_a = -F^bc F_ac + (1/4) delta F2 (positive energy in +,-,-,-), the Hessian and gradient of phi, the Maxwell divergence; values at the origin.
 Claim (coefficients FITTED exactly over all components and frames, then verified on fresh frames):
   4D block  G5^b_a = G4^b_a + eps (phi^2/2) T^b_a - (1/phi)(nabla^b nabla_a phi - delta^b_a box phi)
   44        G5^4_4 = -R4/2 + (3/8) eps phi^2 F2
   mixed     G5^4_a = -(1/2) phi nabla_c F^c_a - (3/2) d_c phi F^c_a,      G5^a_4 = eps eta^aa G5^4_a
 Reading: 5D vacuum gives the Maxwell field the coupling kappa_eff = -eps phi^2/2 in D1's E_a + kappa T_a = 0: positive energy iff eps = -1.
 Controls: both eps; wrong sign, power of phi, trace term, 44 coefficient, scalar terms; e^4 = phi(dy - A); Reissner-Nordstrom (not a 5D vacuum);
 a null plane wave (a 5D vacuum); F = 0 (pure 4D Einstein).  Scope: values at the origin of polynomial frames (2-jets), n = 5, both eps."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N4, N5 = 4, 5
ETA4 = [1, -1, -1, -1]
def SQ5(eps): return [1, -1, -1, -1, eps]
CTL = {}
def ctl_add(name, wrong, right, applicable=True):
    c = CTL.setdefault(name, [0, 0])
    if applicable: c[1] += 1; c[0] += int(wrong != right)

# ------------------------------------------------------------------------------------------------ polynomials in (x^0..x^3) and the 5D frame
def lift(p): return {k + (0,): v for k, v in p.items()}
def trunc_deg(p, d): return {k: v for k, v in p.items() if sum(k[:N4]) <= d}
def rand_poly4(rng, deg=2, coef=2, density=.5, c0=None):
    """random polynomial in x^0..x^3 (4 slots); c0 fixes the constant term"""
    p = {}
    for ex in itertools.product(range(deg + 1), repeat=N4):
        if sum(ex) > deg: continue
        if sum(ex) == 0 and c0 is not None:
            if c0 != 0: p[ex] = F(c0)
            continue
        if rng.random() < density:
            c = F(rng.randint(-coef, coef))
            if c: p[ex] = c
    return p
def kk_frame(e4, A, phi, sgnA=1):
    """5D coframe (5 slots): e^a = e4^a (a < 4), e^4 = phi (dy + sgnA A_mu dx^mu); every coefficient truncated at x-degree 2 (the curvature at the origin reads the 2-jet only)"""
    e = [{m: lift(trunc_deg(p, 2)) for m, p in e4[a].items() if trunc_deg(p, 2)} for a in range(N4)]
    f4 = {}
    for mu in range(N4):
        p = trunc_deg(sp_mul(phi, A[mu], 2, N4), 2)
        if p: f4[1 << mu] = lift(scale(p, sgnA))
    f4[1 << N4] = lift(trunc_deg(phi, 2))
    e.append(f4)
    return e

# ------------------------------------------------------------------------------------------------ [bit] and [std] 5D
def engine_G5(e, eps):
    """[bit] G5^b_a (list [b][a], frame components) read off the engine's E_a (c = 0) via E_a = -G5^h_a Theta_h; also omega (A3 closed form) and Grav"""
    sq = SQ5(eps); Lie_ = Lie(sq); Gv = Grav(N5, Lie_); S = koszul_S(N5, sq, Lie_)
    om = omega_closed_form(Gv, e, S, N5, 1)[0]
    with trunc(N5, xdeg=1):
        R = Gv.curvature(om); Ea, _ = Gv.einstein(None, e, R, F(0))
    comp = einstein_components(Ea, N5, N5)
    e0, E0, det = E0_of(e, N5, N5)
    return mixed_from_components(comp, e0, det, N5, s=-1), om, Gv
def std_G5(e, eps):
    """[std] G5^b_a of g5 = e^T diag(sq) e by the Christoffel route (no engine), frame components"""
    g = std_metric(e, N5, SQ5(eps), N5, 2)
    R1, g0, g0i = std_riemann(g, N5, N5, 1)
    Gm, _, _ = std_einstein_mixed(R1, g0, g0i, N5)
    e0, E0, det = E0_of(e, N5, N5)
    return to_frame_mixed(Gm, e0, E0, N5)

# ------------------------------------------------------------------------------------------------ [std] 4D pieces (no 5D object)
def std4_pieces(e4, A, phi):
    """[std] 4D quantities at the origin from e4, A, phi only; tensors as frame components w.r.t. e4(0) (mixed: [b][a] = X^b_a)."""
    n = N4; R = range(n)
    g = std_metric(e4, n, ETA4, n, 2)
    R1, g0, g0i = std_riemann(g, n, n, 1)
    Gm, _, R4 = std_einstein_mixed(R1, g0, g0i, n)
    e0, E0, det = E0_of(e4, n, n)
    dg = {(k, a, b): at0(sp_der(g[(a, b)], k), n) for k in R for a in R for b in R}
    Gam = [[[F(1, 2) * sum(g0i[l][s] * (dg[(m, s, v)] + dg[(v, s, m)] - dg[(s, m, v)]) for s in R) for v in R] for m in R] for l in R]
    Fp = {(m, v): sp_add(sp_der(A[v], m), sp_der(A[m], v), -1) for m in R for v in R}               # F_mv = d_m A_v - d_v A_m
    F0 = [[at0(Fp[(m, v)], n) for v in R] for m in R]
    dF = [[[at0(sp_der(Fp[(m, v)], k), n) for v in R] for m in R] for k in R]
    p0 = at0(phi, n); dp = [at0(sp_der(phi, k), n) for k in R]
    ddp = [[at0(sp_der(sp_der(phi, k), l), n) for l in R] for k in R]
    Fmix = [[sum(g0i[m][s] * F0[s][v] for s in R) for v in R] for m in R]                            # F^m_v
    FUU = [[sum(Fmix[m][t] * g0i[t][v] for t in R) for v in R] for m in R]                            # F^{mv}
    F2 = sum(F0[m][v] * FUU[m][v] for m in R for v in R)
    S = [[sum(FUU[m][l] * F0[v][l] for l in R) for v in R] for m in R]                                # S^m_v = F^{ml} F_{vl}
    T = [[-S[m][v] + (F2 / 4 if m == v else 0) for v in R] for m in R]
    Hs = [[ddp[m][v] - sum(Gam[l][m][v] * dp[l] for l in R) for v in R] for m in R]                  # nabla_m nabla_v phi
    H = [[sum(g0i[m][s] * Hs[s][v] for s in R) for v in R] for m in R]
    P = [[sum(g0i[m][s] * dp[s] for s in R) * dp[v] for v in R] for m in R]
    dgi = [[[-sum(g0i[m][p_] * dg[(k, p_, q)] * g0i[q][s] for p_ in R for q in R) for s in R] for m in R] for k in R]
    dFmix = [[[sum(dgi[k][m][s] * F0[s][v] + g0i[m][s] * dF[k][s][v] for s in R) for v in R] for m in R] for k in R]
    div = [sum(dFmix[m][m][v] for m in R) + sum(Gam[m][m][l] * Fmix[l][v] for m in R for l in R) - sum(Gam[l][m][v] * Fmix[m][l] for m in R for l in R) for v in R]
    gF = [sum(dp[m] * Fmix[m][v] for m in R) for v in R]
    fr = lambda X: to_frame_mixed(X, e0, E0, n)
    cov = lambda w: [sum(w[v] * E0[v][a] for v in R) for a in R]
    Ffr = [[sum(E0[m][a] * E0[v][b] * F0[m][v] for m in R for v in R) for b in R] for a in R]          # F_ab
    dual = sum(perm_sign(q) * F0[q[0]][q[1]] * F0[q[2]][q[3]] for q in itertools.permutations(R))   # eps^{mnab} F_mn F_ab (F ^ F)
    return dict(G4=fr(Gm), R4=R4, T=fr(T), S=fr(S), F2=F2, H=fr(H), box=sum(H[m][m] for m in R), P=fr(P), grad2=sum(P[m][m] for m in R),
                div=cov(div), gF=cov(gF), phi0=p0, Ffr=Ffr, dual=dual, e0=e0)
def perm_sign(q):
    s = 1; q = list(q)
    for i in range(len(q)):
        for j in range(i + 1, len(q)):
            if q[i] > q[j]: s = -s
    return s

def predict_G5(P, eps, kT=None, ktr=F(1, 4), kH=F(-1), kB=F(1), k44R=F(-1, 2), k44F=None, m1=F(-1, 2), m2=F(-3, 2), phipow=2):
    """the reduction formula (defaults = the claim); the keyword arguments build the wrong versions used as controls"""
    p = P['phi0']
    kT = F(eps) * p ** phipow / 2 if kT is None else kT
    k44F = F(3, 8) * eps * p ** phipow if k44F is None else k44F
    M = [[F(0)] * N5 for _ in range(N5)]
    for b in range(N4):
        for a in range(N4):
            Tba = -P['S'][b][a] + (ktr * P['F2'] if a == b else 0)
            M[b][a] = P['G4'][b][a] + kT * Tba + (kH * P['H'][b][a] + (kB * P['box'] if a == b else 0)) / p
        M[N4][b] = m1 * p * P['div'][b] + m2 * P['gF'][b]
        M[b][N4] = eps * ETA4[b] * M[N4][b]
    M[N4][N4] = k44R * P['R4'] + k44F * P['F2']
    return M

# ------------------------------------------------------------------------------------------------ exact fits
B4 = ['S', 'phi S', 'phi^2 S', 'delta F2', 'phi delta F2', 'phi^2 delta F2', 'Hess/phi', 'delta box/phi', 'grad grad/phi^2', 'delta |grad|^2/phi^2']
B44 = ['R4', 'F2', 'phi^2 F2', 'box/phi', '|grad|^2/phi^2']
BM = ['div F', 'phi div F', 'phi^2 div F', 'grad phi.F', 'phi grad phi.F']
def rows_4(P, G5):
    p = P['phi0']; rows, rhs = [], []
    for b in range(N4):
        for a in range(N4):
            d = 1 if a == b else 0; S = P['S'][b][a]
            rows.append([S, p * S, p * p * S, d * P['F2'], d * p * P['F2'], d * p * p * P['F2'], P['H'][b][a] / p, d * P['box'] / p, P['P'][b][a] / p ** 2, d * P['grad2'] / p ** 2])
            rhs.append(G5[b][a] - P['G4'][b][a])
    return rows, rhs
def rows_44(P, G5):
    p = P['phi0']; return [[P['R4'], P['F2'], p * p * P['F2'], P['box'] / p, P['grad2'] / p ** 2]], [G5[N4][N4]]
def rows_m(P, G5, up):
    p = P['phi0']; rows, rhs = [], []
    for a in range(N4):
        s = ETA4[a] if up else 1
        rows.append([s * P['div'][a], s * p * P['div'][a], s * p * p * P['div'][a], s * P['gF'][a], s * p * P['gF'][a]])
        rhs.append(G5[a][N4] if up else G5[N4][a])
    return rows, rhs
def fit(rows, rhs):
    """exact least-structure solve: (solution or None, rank, number of unknowns, consistent)"""
    w, rank, nvar, cons = solve_exact(rows, rhs)
    return w, rank, nvar, cons
def fmt(v): return '[' + ', '.join(str(x) for x in v) + ']' if v is not None else 'None'

# ------------------------------------------------------------------------------------------------ special frames
def flat_constF(Fl):
    """e4 = dx, A_v = (1/2) F_mv x^m: constant F with the given lower components F_mv (m < v)"""
    e4 = [{1 << a: const(N4, 1)} for a in range(N4)]; A = [{} for _ in range(N4)]
    for (m, v), val in Fl.items():
        A[v] = sp_add(A[v], scale(var(N4, m), F(val) / 2)); A[m] = sp_add(A[m], scale(var(N4, v), -F(val) / 2))
    return e4, A
def rn_frame(eps, M=F(1), q=F(1, 2), p=(F(1), F(2), F(2)), rho0=F(3)):
    """Kerr-Schild frame of C1 (b1lib.ks_frame_jet) with f = M/rho + eps q^2/(2 rho^2) (eps = -1: Reissner-Nordstrom) and A = (2q/rho) dt, 2-jets at p"""
    f0 = M / rho0 + eps * q ** 2 / (2 * rho0 ** 2); f1 = -M / rho0 ** 2 - eps * q ** 2 / rho0 ** 3; f2 = 2 * M / rho0 ** 3 + 3 * eps * q ** 2 / rho0 ** 4
    e4, _, _ = ks_frame_jet(p, rho0, f0, f1, f2, nv=N4)
    X = [var(N4, i) for i in (1, 2, 3)]
    d2 = lin(*[(F(1), sp_mul(X[i], X[i], 2, N4)) for i in range(3)])
    u = lin((F(2) / rho0 ** 2, lin(*[(p[i], X[i]) for i in range(3)])), (F(1) / rho0 ** 2, d2))
    inv_rho = lin((1 / rho0, const(N4, 1)), (-1 / (2 * rho0), u), (F(3, 8) / rho0, sp_mul(u, u, 2, N4)))
    return e4, [scale(inv_rho, 2 * q), {}, {}, {}], q, rho0
def ppwave(eps, b=(1, 2), pt=(F(1, 2), F(1), F(-1), F(1, 3))):
    """pp-wave g4 = eta - H k k (k = du, u = t - z) with A = (b1 x + b2 y)(1 + u) du (null F) and H = (eps/4)(1 + u)^2 |b|^2 (x^2 + y^2); 2-jets at pt"""
    t, x, y, z = [var(N4, i) for i in range(N4)]
    f = sp_add(const(N4, 1), sp_add(t, z, -1))
    H = scale(sp_mul(sp_mul(f, f, 9, N4), sp_add(sp_mul(x, x, 9, N4), sp_mul(y, y, 9, N4)), 9, N4), F(eps * (b[0] ** 2 + b[1] ** 2), 4))
    k_dn, k_up = [1, 0, 0, -1], [1, 0, 0, 1]
    e4 = []
    for a in range(N4):
        form = {}
        for mu in range(N4):
            pol = const(N4, 1) if a == mu else {}
            if k_up[a] and k_dn[mu]: pol = sp_add(pol, scale(H, F(-k_up[a] * k_dn[mu], 2)))
            if pol: form[1 << mu] = pol
        e4.append(form)
    a0 = sp_mul(sp_add(scale(x, b[0]), scale(y, b[1])), f, 9, N4)
    A = [a0, {}, {}, scale(a0, -1)]
    e4 = [{m: trunc_deg(pp, 2) for m, pp in form.items() if trunc_deg(pp, 2)} for form in translate_frame(e4, list(pt), N4)]
    return e4, [trunc_deg(shift_poly(pp, list(pt), N4), 2) for pp in A]

def omega_fibre_ok(om, Gv, P, eps):
    """[bit==std] at phi = 1: omega^{a4} = -(1/2) F^a_c e^c (no dy part) and the dy part of omega^{ab} is -(eps/2) F^{ab}"""
    Fud = [[ETA4[a] * P['Ffr'][a][c] for c in range(N4)] for a in range(N4)]
    ok = True
    for A_, (a, b) in enumerate(pairs_of(Gv.L)):
        val = lambda mu: at0(om[A_].get(1 << mu, {}), N5)
        if b == N4:
            ok &= all(val(mu) == -F(1, 2) * sum(Fud[a][c] * P['e0'][c][mu] for c in range(N4)) for mu in range(N4)) and val(N4) == 0
        else:
            ok &= val(N4) == -F(eps, 2) * ETA4[a] * ETA4[b] * P['Ffr'][a][b]
    return ok

# ------------------------------------------------------------------------------------------------ one sign of eps
def blk(M, which):
    if which == '4D': return [[M[b][a] for a in range(N4)] for b in range(N4)]
    if which == 'mixed': return [M[N4][a] for a in range(N4)] + [M[a][N4] for a in range(N4)]
    return M[N4][N4]
def run_eps(eps):
    head('eps = %+d  (sq = %s; %s)' % (eps, SQ5(eps), 'the fibre squares like space' if eps == -1 else 'the fibre squares like time'))
    P0ok = True; nP0 = 0; out = {}
    def frame(e4, A, phi, sgnA=1, std5=True):
        nonlocal P0ok, nP0
        e = kk_frame(e4, A, phi, sgnA); G5, om, Gv = engine_G5(e, eps)
        if std5: P0ok &= (G5 == std_G5(e, eps)); nP0 += 1
        return G5, om, Gv
    rng = random.Random(4100 + eps)
    # (a) phi = 1
    e4 = rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng) for _ in range(N4)]; phi = const(N4, 1)
    P = std4_pieces(e4, A, phi); G5, om, Gv = frame(e4, A, phi)
    D = [[G5[b][a] - P['G4'][b][a] for a in range(N4)] for b in range(N4)]
    rat = set(D[b][a] / P['T'][b][a] for b in range(N4) for a in range(N4) if P['T'][b][a] != 0)
    zer = all(D[b][a] == 0 for b in range(N4) for a in range(N4) if P['T'][b][a] == 0)
    nT = sum(1 for b in range(N4) for a in range(N4) if P['T'][b][a] != 0)
    print('    phi = 1 frame: F2 = %s, T^0_0 = %s, G4^0_0 = %s, G5^0_0 = %s' % (P['F2'], P['T'][0][0], P['G4'][0][0], G5[0][0]), flush=True)
    chk('bit==std', rat == {F(eps, 2)} and zer, 'eps=%+d, phi = 1: (G5 - G4)^b_a / T^b_a takes the single value %s on all %d components with T != 0 (and G5 = G4 where T = 0); predicted eps/2 = %s' % (eps, sorted(map(str, rat)), nT, F(eps, 2)))
    chk('bit==std', blk(G5, '44') == -P['R4'] / 2 + F(3 * eps, 8) * P['F2'] and blk(G5, 'mixed') == blk(predict_G5(P, eps), 'mixed'),
        'eps=%+d, phi = 1: G5^4_4 = -R4/2 + (3/8) eps F2 (= %s) and the mixed block = -(1/2) div F (G5^4_a), -(eps/2) eta^aa div F (G5^a_4)' % (eps, G5[N4][N4]))
    chk('bit==std', omega_fibre_ok(om, Gv, P, eps), 'eps=%+d, phi = 1: the engine\'s connection on the fibre bivectors: omega^{a4} = -(1/2) F^a_c e^c (eps-free), and omega^{ab}(d_y) = -(eps/2) F^{ab}: F sits in B_{a4}, eps enters through [B_a4, B_b4]' % eps)
    frames = [(P, G5)]
    # (b) constant phi != 1
    for p0 in (F(2), F(1, 3)):
        e4 = rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng) for _ in range(N4)]; phi = const(N4, p0)
        P = std4_pieces(e4, A, phi); G5, _, _ = frame(e4, A, phi)
        D = [[G5[b][a] - P['G4'][b][a] for a in range(N4)] for b in range(N4)]
        rat = set(D[b][a] / P['T'][b][a] for b in range(N4) for a in range(N4) if P['T'][b][a] != 0)
        zer = all(D[b][a] == 0 for b in range(N4) for a in range(N4) if P['T'][b][a] == 0)
        chk('bit==std', rat == {F(eps) * p0 ** 2 / 2} and zer and G5 == predict_G5(P, eps),
            'eps=%+d, phi = %s (constant): (G5 - G4)/T = %s = eps phi^2/2 on every component; 44 and mixed blocks as predicted' % (eps, p0, sorted(map(str, rat))))
        frames.append((P, G5))
    tick('eps=%+d: phi = 1 and constant phi' % eps)
    # (c) non-constant phi: exact fit over all frames
    fit_frames = []
    for p0 in (F(1), F(2), F(1, 2), F(3, 2)):
        e4 = rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng) for _ in range(N4)]; phi = rand_poly4(rng, 2, 1, .5, c0=p0)
        P = std4_pieces(e4, A, phi); G5, _, _ = frame(e4, A, phi)
        frames.append((P, G5)); fit_frames.append((e4, A, phi, P, G5))
    rows, rhs = [], []
    for P, G5 in frames: r, h = rows_4(P, G5); rows += r; rhs += h
    w4, rk4, nv4, cons4 = fit(rows, rhs)
    exp4 = [0, 0, F(-eps, 2), 0, 0, F(eps, 8), -1, 1, 0, 0]
    print('    4D-block fit over %d frames (%d equations), basis %s:\n      coefficients %s' % (len(frames), len(rows), B4, fmt(w4)), flush=True)
    chk('bit==std', cons4 and rk4 == nv4 and w4 == exp4, 'eps=%+d: 4D block, exact fit: consistent, unique (rank %d of %d), = (S: -eps phi^2/2, delta F2: eps phi^2/8, Hess/phi: -1, delta box/phi: +1, no phi^0, phi^1, (grad phi)^2 terms)' % (eps, rk4, nv4))
    rows, rhs = [], []
    for P, G5 in frames: r, h = rows_44(P, G5); rows += r; rhs += h
    w44, rk44, nv44, cons44 = fit(rows, rhs)
    print('    44 fit, basis %s: %s' % (B44, fmt(w44)), flush=True)
    chk('bit==std', cons44 and rk44 == nv44 and w44 == [F(-1, 2), 0, F(3 * eps, 8), 0, 0], 'eps=%+d: G5^4_4 exact fit (%d frames, rank %d of %d): -R4/2 + (3/8) eps phi^2 F2, no box phi or (grad phi)^2 term' % (eps, len(frames), rk44, nv44))
    wm = {}
    for up in (False, True):
        rows, rhs = [], []
        for P, G5 in frames: r, h = rows_m(P, G5, up); rows += r; rhs += h
        wm[up] = fit(rows, rhs)
    print('    mixed fits, basis %s: G5^4_a %s;  eta^aa G5^a_4 %s' % (BM, fmt(wm[False][0]), fmt(wm[True][0])), flush=True)
    chk('bit==std', all(wm[u][3] and wm[u][1] == wm[u][2] for u in wm) and wm[False][0] == [0, F(-1, 2), 0, F(-3, 2), 0] and wm[True][0] == [0, F(-eps, 2), 0, F(-3 * eps, 2), 0],
        'eps=%+d: mixed block, exact fits: G5^4_a = -(1/2) phi^-2 nabla_c(phi^3 F^c_a) (eps-free), G5^a_4 = eps eta^aa G5^4_a' % eps)
    tr_ok = all(G5[N4][N4] - sum(G5[a][a] for a in range(N4)) / 2 == F(-3, 2) * (P['box'] / P['phi0'] - F(eps, 4) * P['phi0'] ** 2 * P['F2']) for P, G5 in frames)
    chk('bit==std', tr_ok, 'eps=%+d: G5^4_4 - (1/2) sum_a G5^a_a = -(3/2)(box phi/phi - (eps/4) phi^2 F2) on all %d frames: in 5D vacuum box phi = (eps/4) phi^3 F2, so constant phi needs F2 = 0' % (eps, len(frames)))
    tick('eps=%+d: non-constant phi, fits' % eps)
    # (d) a fresh frame (not used in the fit) and the controls on all frames
    rng2 = random.Random(5200 + eps)
    e4 = rand_frame(rng2, N4, deg=2, coef=2, density=.5, nv=N4); A = [rand_poly4(rng2) for _ in range(N4)]; phi = rand_poly4(rng2, 2, 1, .5, c0=F(5, 4))
    P = std4_pieces(e4, A, phi); G5, _, _ = frame(e4, A, phi)
    chk('bit==std', G5 == predict_G5(P, eps), 'eps=%+d: fresh frame (seed not in the fit, phi(0) = 5/4, non-constant): the reduction formula equals the engine in all 25 components' % eps)
    frames.append((P, G5))
    for P, G5 in frames:
        p, Fn = P['phi0'], P['F2'] != 0 or any(P['S'][b][a] for b in range(N4) for a in range(N4))
        ctl_add('opposite Maxwell sign: G4 - eps (phi^2/2) T', predict_G5(P, eps, kT=F(-eps) * p ** 2 / 2), G5, Fn)
        if eps == 1: ctl_add('sign not following eps: the eps = -1 formula used at eps = +1', predict_G5(P, -1), G5, Fn)
        ctl_add('phi^1 instead of phi^2 in the Maxwell and F2 terms', predict_G5(P, eps, phipow=1), G5, Fn and p != 1)
        ctl_add('trace term 1/2 instead of 1/4 in T', predict_G5(P, eps, ktr=F(1, 2)), G5, P['F2'] != 0)
        ctl_add('G5^4_4 without the F2 term', predict_G5(P, eps, k44F=F(0)), G5, P['F2'] != 0)
        ctl_add('G5^4_4 with 1/8 instead of 3/8', predict_G5(P, eps, k44F=F(eps, 8) * p ** 2), G5, P['F2'] != 0)
        ctl_add('Hessian term dropped', predict_G5(P, eps, kH=F(0)), G5, P['grad2'] != 0 or P['box'] != 0)
        ctl_add('Hessian term with the opposite sign', predict_G5(P, eps, kH=F(1), kB=F(-1)), G5, P['grad2'] != 0 or P['box'] != 0)
        ctl_add('mixed block phi^-1 nabla(phi^2 F) instead of phi^-2 nabla(phi^3 F)', predict_G5(P, eps, m2=F(-1)), G5, any(P['gF']))
    # (e) the sign convention of A: e^4 = phi (dy - A)
    e4, A, phi, P, G5 = fit_frames[1]
    G5m, _, _ = frame(e4, A, phi, sgnA=-1, std5=False)
    chk('bit', blk(G5m, '4D') == blk(G5, '4D') and blk(G5m, '44') == blk(G5, '44') and blk(G5m, 'mixed') == [-x for x in blk(G5, 'mixed')],
        'eps=%+d: e^4 = phi(dy - A): the 4D block and G5^4_4 are unchanged (T is even in F), the mixed block changes sign' % eps)
    ctl_add('e^4 = phi(dy - A) read with the +A mixed block', blk(predict_G5(P, eps), 'mixed'), blk(G5m, 'mixed'))
    # (f) F = 0 (pure gauge A = d lambda): pure 4D Einstein
    lam = rand_poly4(rng2, 3, 2, .4); e4 = rand_frame(rng2, N4, deg=2, coef=2, density=.5, nv=N4); A = [sp_der(lam, mu) for mu in range(N4)]; phi = const(N4, 1)
    P = std4_pieces(e4, A, phi); G5, _, _ = frame(e4, A, phi)
    chk('bit==std', P['F2'] == 0 and all(x == 0 for row in P['Ffr'] for x in row) and any(A) and blk(G5, '4D') == P['G4'] and G5[N4][N4] == -P['R4'] / 2 and not any(blk(G5, 'mixed')),
        'eps=%+d: F = 0 (A = d lambda, non-zero, phi = 1): G5^b_a = G4^b_a, G5^4_4 = -R4/2 (= %s), mixed block zero: pure 4D Einstein' % (eps, G5[N4][N4]))
    tick('eps=%+d: fresh frame, -A, F = 0' % eps)
    # (g) the energy test: flat e4 = dx, constant F, phi = 1
    kap = {}
    for name, Fl, T00 in (('pure electric E_x = 3', {(0, 1): 3}, F(9, 2)), ('pure magnetic B_z = 2', {(1, 2): -2}, F(2))):
        e4, A = flat_constF(Fl); P = std4_pieces(e4, A, const(N4, 1)); G5, _, _ = frame(e4, A, const(N4, 1))
        chk('std', P['T'][0][0] == T00 and P['G4'] == [[0] * N4 for _ in range(N4)], 'eps=%+d, %s: T^0_0 = %s = (E^2 + B^2)/2 > 0 (the stress used here has positive energy), G4 = 0' % (eps, name, P['T'][0][0]))
        kap[name] = -(G5[0][0] - P['G4'][0][0]) / P['T'][0][0]
        chk('bit', G5[0][0] == F(eps) * T00 / 2 and kap[name] == F(-eps, 2),
            'eps=%+d, %s: engine G5^0_0 = %s = eps T^0_0/2; the Maxwell part of E_0 is kappa_eff T^0_0 Theta_0 with kappa_eff = %s (%s)' % (eps, name, G5[0][0], kap[name], 'positive: attractive, positive energy' if kap[name] > 0 else 'NEGATIVE: a ghost'))
    # (h) null plane wave with phi = 1: a 5D vacuum
    e4, A = ppwave(eps); P = std4_pieces(e4, A, const(N4, 1)); G5, _, _ = frame(e4, A, const(N4, 1))
    tnz = any(P['T'][b][a] for b in range(N4) for a in range(N4))
    chk('std', P['F2'] == 0 and P['dual'] == 0 and tnz and P['G4'] == [[F(-eps, 2) * P['T'][b][a] for a in range(N4)] for b in range(N4)],
        'eps=%+d, pp-wave with a null field (at a shifted point): F2 = 0, F ^ F = 0, T != 0, and G4 = -(eps/2) T (4D Einstein-Maxwell with kappa_eff = -eps/2)' % eps)
    chk('bit', all(x == 0 for row in G5 for x in row), 'eps=%+d, pp-wave, phi = 1: all 25 components of G5 vanish: a 5D vacuum with constant radius (F2 = 0)' % eps)
    # (i) Reissner-Nordstrom (eps = -1) and its ghost-coupled twin (eps = +1), phi = 1
    e4, A, q, rho0 = rn_frame(eps); P = std4_pieces(e4, A, const(N4, 1)); G5, _, _ = frame(e4, A, const(N4, 1))
    chk('std', P['R4'] == 0 and P['F2'] == -8 * q ** 2 / rho0 ** 4 and not any(P['div']) and P['G4'] == [[F(-eps, 2) * P['T'][b][a] for a in range(N4)] for b in range(N4)],
        'eps=%+d, Kerr-Schild f = M/rho %s q^2/(2 rho^2), A = (2q/rho) dt at |p| = %s: R4 = 0, F2 = -8 q^2/rho^4, div F = 0, G4 = -(eps/2) T (4D Einstein-Maxwell holds)' % (eps, '-' if eps == -1 else '+', rho0))
    v44 = F(-3 * eps) * q ** 2 / rho0 ** 4
    chk('bit', all(x == 0 for row in blk(G5, '4D') for x in row) and not any(blk(G5, 'mixed')) and G5[N4][N4] == v44 and v44 != 0,
        'eps=%+d, %s with phi = 1: the 4D and mixed blocks of G5 vanish but G5^4_4 = %s = -3 eps q^2/rho^4 != 0: not a 5D vacuum' % (eps, 'Reissner-Nordstrom' if eps == -1 else 'its ghost-coupled twin', G5[N4][N4]))
    ctl_add('Reissner-Nordstrom (or its twin) with phi = 1 is a 5D vacuum', [[F(0)] * N5 for _ in range(N5)], G5)
    chk('bit==std', P0ok, 'eps=%+d: (P0) the engine\'s E_a = -G5^h_a Theta_h with G5 the Einstein tensor of g5 by the Christoffel route, all 25 components, %d frames%s' % (eps, nP0, ' (signature (2,3): new; A4 had the Lorentz signs only)' if eps == 1 else ''))
    tick('eps=%+d: energy test, pp-wave, Reissner-Nordstrom' % eps)
    out.update(w4=w4, w44=w44, wm=wm[False][0], kap=kap)
    return out

def main():
    head('H4  Kaluza-Klein at n = 5: e^a = e4^a(x), e^4 = phi(x)(dy + A(x)), fibre generator of square eps; values at the origin of polynomial 2-jets, exact')
    res = {eps: run_eps(eps) for eps in (-1, 1)}
    head('the sign follows eps')
    kT = {eps: res[eps]['w4'][2] if res[eps]['w4'] else None for eps in res}
    chk('bit', kT[-1] is not None and kT[1] == -kT[-1] and kT[-1] == F(1, 2), 'the coefficient of phi^2 S^b_a in G5 - G4 is %s at eps = -1 and %s at eps = +1: the Maxwell stress enters as eps (phi^2/2) T' % (kT[-1], kT[1]))
    sc = {eps: res[eps]['w4'][6:] if res[eps]['w4'] else None for eps in res}
    chk('bit', sc[-1] is not None and sc[-1] == sc[1] and res[-1]['wm'] == res[1]['wm'], 'the scalar terms (%s) and G5^4_a do not depend on eps; no (grad phi)^2 term appears in the 5D equations' % fmt(sc[-1]))
    kp = {eps: set(res[eps]['kap'].values()) for eps in res}
    chk('bit', kp[-1] == {F(1, 2)} and kp[1] == {F(-1, 2)}, 'kappa_eff = -eps phi^2/2 at phi = 1: %s for eps = -1 (fibre like space: positive energy, attractive), %s for eps = +1 (fibre like time: ghost)' % (sorted(map(str, kp[-1])), sorted(map(str, kp[1]))))
    head('controls (a wrong version must differ from the engine on every sample where it can be seen)')
    for name, (dif, seen) in CTL.items():
        chk('ctl', dif == seen and seen > 0, '"%s" differs from the engine on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('H4')
if __name__ == '__main__': main()
