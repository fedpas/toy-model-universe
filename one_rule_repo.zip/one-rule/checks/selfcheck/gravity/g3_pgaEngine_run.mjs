// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// G3: run the PAGE'S OWN integrator (rk4Bodies, energyBodies of pgaEngine.js, imported unchanged) on a state given on stdin.
// stdin  : JSON { x: [[..]], v: [[..]], mass: [..], G: number, h: number, steps: int, every: int }
// stdout : JSON { k: [step numbers], x: [...], v: [...], E: [...], K: [...], U: [...], Lz: [...], P: [...] }  (every `every` steps, including step 0)
import { rk4Bodies, energyBodies } from '../../pgaEngine.js';
import fs from 'node:fs';
const inp = JSON.parse(fs.readFileSync(0, 'utf8'));
let st = { x: inp.x, v: inp.v };
const out = { k: [], x: [], v: [], E: [], K: [], U: [], Lz: [], P: [] };
const rec = (k) => {
  const e = energyBodies(st, inp.mass, inp.G);
  out.k.push(k); out.x.push(st.x); out.v.push(st.v); out.E.push(e.E); out.K.push(e.K); out.U.push(e.U); out.Lz.push(e.Lz); out.P.push(e.P);
};
rec(0);
for (let k = 1; k <= inp.steps; k++) { st = rk4Bodies(st, inp.mass, inp.G, inp.h); if (k % inp.every === 0) rec(k); }
process.stdout.write(JSON.stringify(out));
