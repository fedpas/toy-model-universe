#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""E2-S4.  Dirac stress by variation, the Lorentz and diffeomorphism Noether identities with spin, the trace identity, and the chain with B2.
   python3 e2s4_dirac_stress.py [--seeds K]

 n = 4, Cl(1,3), sq = (+,-,-,-); polynomials in 5 slots (x^0..x^3, slot 4 = lam, the bookkeeping parameter of first variations).
 Atlas Dirac line (E2): L_D = sum_a <g^a (D psi ^ Th_a) J g0 psi~> - m <psi psi~> vol,  Th_a = i_{E_a} vol,  D psi = d psi + (1/2) om^A B_A psi.
 Definitions:  delta_e L_D = delta e^a ^ tau_a (B3 matter_variation);  delta_om L_D = delta om^A ^ S_A (E2 spin_forms_engine);
   delta_psi L_D = sum_S delta psi_S EL_S + d(sum_S delta psi_S P_S),  P_S = dL/d(d psi_S),  EL_S = dL/dpsi_S - d P_S;  (X).EL = sum_S X_S EL_S.
 Fields: strong random polynomials (B3 sampler, all monomials to x-degree 2, integers in [-9, 9]) for e, om (any Lorentz connection: torsion != 0) and psi.
   Products truncated at x-degree 1 (b1lib.trunc): every identity is checked at the origin, with exact 1-jets of tau, S, E_a, Theta_A.
 Claims:  (a) tau^b_a = -T^b_a (textbook canonical stress), tau_a = i_a L_D - (i_a D psi).P;  (b) D S_ab = c1 (e_a tau_b - e_b tau_a) + c2 (B_ab psi).EL;
   (c) D tau_a = al (i_a T^b) tau_b + be (i_a R^A) S_A + d1 (i_a D psi).EL;  (d) tau^a_a vol = t2 psi.EL + t1 m <psi psi~> vol;
   (e) with B2: D(Theta - k S)_ab - (e_a X_b - e_b X_a) and D X_a - (i_a T) X - (i_a R) Y (X = E - k tau, Y = Theta - k S) are pure matter-EL terms.
   Stretch: omega* = omega_LC + K* (E2): sym[X(omega*) - X(omega_LC)] = -(3/16) k^2 (s.s) eta; on shell X(omega*) = E(omega_LC) - k [tau_(ab)(omega_LC) + (3k/16)(s.s) eta].
   Finding: (B_ab psi).EL is the same for omega* and omega_LC.
 [std] numpy only (E1 Dirac matrices, E2 dictionary chi = M(psi) u): canonical stress, a numerical frame variation of det(e) l, on-shell
   textbook identities with central differences (3-forms as vector densities).
 Exports (no engine object at import): L_of_D, P_forms, dL_dpsi, EL_forms, dirac_stress, lorentz_defect, at_point, onshell_psi, strong_fields,
   std_at, std_tau_var, std_onshell."""
import sys, os, time, itertools, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from b1lib import *
import b1_first_variation as B1
import e2_spin_torsion as E2
import b3_matter as B3
from g2_forms_calc import interior, D_dual_bivector, _der as std_der
from b2_noether import lorentz_var, by_A
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N, NV, FULL = 4, 5, 15
LOR = [1, -1, -1, -1]
PAIRS = E2.PAIRS; EVEN = E2.EVEN
ZK = (0,) * NV
LAMV = {(0, 0, 0, 0, 1): F(1)}
K0 = (1, 0, 0, 0, 0)                                                            # the monomial x^0 (its coefficient = d_0 psi at the origin)
def cst(v): return {ZK: F(v)} if v != 0 else {}
def v0(p): return p.get(ZK, F(0))
def nz(p): return {k: v for k, v in p.items() if v != 0}
def tp(p, d): return {k: v for k, v in p.items() if sum(k[:N]) <= d}
def tf(X, d): return {m: q for m, q in ((m, tp(p, d)) for m, p in X.items()) if q}
def top0(X): return v0(X.get(FULL, {}))
def form0(X): return {m: cst(v0(p)) for m, p in X.items() if v0(p) != 0}
def lamp(X): return {m: q for m, q in ((m, B3.lam_part(p)) for m, p in X.items()) if q}
def is0(X): return not any(p for p in X.values())

# ------------------------------------------------------------------------------------------------ fields
def strong_fields(rng, deg=2):
    """[bit input] e (det e(0) != 0), om (6 bivector 1-forms), psi (8 even components): every monomial to x-degree deg, integers in [-9, 9]"""
    e = B3.strong_frame(rng, deg=deg)
    om = [{1 << mu: q for mu in range(N) for q in [nz(B3.strong_poly(rng, deg))] if q} for _ in range(len(PAIRS))]
    psi = {S: q for S in EVEN for q in [nz(B3.strong_poly(rng, deg))] if q}
    return e, om, psi

# ------------------------------------------------------------------------------------------------ [bit] pieces of the Dirac 4-form
def L_of_D(Gv, e, Dpsi, psi, Th, mode='axial'):
    """sum_a <g^a (Dpsi ^ Th_a) J g0 psi~> for a GIVEN spinor-valued 1-form Dpsi (E2.L_dirac's loop with D psi supplied; checked = L_dirac + m-term)"""
    Fm = Gv.Fm; sq = Gv.L.sq
    left = E2.mv_mul(E2.J_MV, E2.G0, sq) if mode == 'axial' else E2.G0
    Rt = E2.mvp_mul(E2.mvp_const(left, NV), E2.mvp_rev(psi), sq); tot = {}
    for a in range(N):
        for S, form in Dpsi.items():
            m1, s1 = bmul(1 << a, S, sq); r = Rt.get(m1)
            if not r: continue
            s2 = bmul(m1, m1, sq)[1]; w = Fm.wedge(form, Th[a])
            if w: tot = Fm.add(tot, Fm.wedge({0: r}, w), sq[a] * s1 * s2)
    return tot
def P_forms(Gv, e, psi, Th, mode='axial'):
    """P_S = dL_D/d(d psi_S) (3-forms): L_of_D(D psi = dx^mu g_S) = dx^mu ^ P_S"""
    P = {}
    for S in EVEN:
        X = {}
        for mu in range(N):
            c = L_of_D(Gv, e, {S: {1 << mu: cst(1)}}, psi, Th, mode).get(FULL, {})
            if c: X[FULL ^ (1 << mu)] = pscale(c, (-1) ** mu)
        P[S] = X
    return P
def dL_dpsi(Gv, e, om, psi, m, Th, mode='axial'):
    """dL_D/dpsi_S at fixed d psi: lam-part of L_D(psi + lam g_S) (the engine's d does not act on slot 4)"""
    out = {}
    for S in EVEN:
        ps = dict(psi); ps[S] = padd(ps.get(S, {}), LAMV)
        with trunc(N, xdeg=1, lam=1): out[S] = lamp(E2.L_dirac(Gv, e, om, ps, m, NV, mode, Th))
    return out
def EL_forms(Gv, e, om, psi, m, mode='axial'):
    """EL_S = dL/dpsi_S - d P_S (4-forms; exact at the origin when e, psi carry their 1-jets and om its value)"""
    Fm = Gv.Fm; Th = E2.theta_forms(Gv, e)
    P = P_forms(Gv, e, psi, Th, mode); dL = dL_dpsi(Gv, e, om, psi, m, Th, mode)
    return {S: Fm.add(dL[S], Fm.d(P[S]), -1) for S in EVEN}, P
def dirac_stress(Gv, e, om, psi, m, mode='axial', sq_alg=None):
    """[bit] tau_a (3-forms to x-degree 1) from B3.matter_variation (16 unit frame variations; L_D needs no inverse frame)"""
    return B3.matter_variation(Gv, e, lambda ep, Ep: E2.L_dirac(Gv, ep, om, psi, m, NV, mode), xdeg=1)
def spinor_rot(Gv, lam, psi, sign):
    """sign (1/2) lam^A B_A psi (left multiplication; lam: list of 0-forms)"""
    sq = Gv.L.sq; out = {}
    for A, g in enumerate(Gv.L.gens):
        for S, p in psi.items():
            msk, s = bmul(g, S, sq); out[msk] = padd(out.get(msk, {}), gs.pmul(lam[A].get(0, {}), p), F(sign * s, 2))
    return {k: v for k, v in out.items() if v}
def lorentz_defect(Gv, e, om, psi, m, lam, spin_sign=-1, sign_om=1, mode='axial'):
    """lam-linear part of L_D(e + de, om + dom, psi + dpsi): B2's (de, dom) = (-h lam e, sign_om D lam), dpsi = spin_sign (1/2) lam B psi"""
    Fm = Gv.Fm; de, dom = lorentz_var(Gv, e, om, lam, sign_om=sign_om); dpsi = spinor_rot(Gv, lam, psi, spin_sign)
    ep = [Fm.add(e[a], Fm.wedge({0: LAMV}, de[a])) for a in range(N)]
    op = [Fm.add(om[A], Fm.wedge({0: LAMV}, dom[A])) for A in range(Gv.G)]
    pp = {S: q for S in set(psi) | set(dpsi) for q in [padd(psi.get(S, {}), gs.pmul(LAMV, dpsi.get(S, {})))] if q}
    with trunc(N, xdeg=1, lam=1): return lamp(E2.L_dirac(Gv, ep, op, pp, m, NV, mode))

# ------------------------------------------------------------------------------------------------ [bit] everything at the origin
def at_point(Gv, e, om, psi, m, mode='axial', kap=None, c=None, want_canon=False):
    """returns a dict of exact values at the origin: tau^b_a, the (b), (c), (d), (e) left and right sides, EL(0), pairings"""
    Fm = Gv.Fm; sq = Gv.L.sq
    e1 = [tf(x, 1) for x in e]; om1 = [tf(x, 1) for x in om]; om0 = [tf(x, 0) for x in om]; psi1 = {S: tp(p, 1) for S, p in psi.items()}
    tau = dirac_stress(Gv, e1, om1, psi, m, mode)
    e0, E0, det = E0_of(e, N, NV)
    out = dict(tau=tau)
    with trunc(N, xdeg=1):
        S = E2.spin_forms_engine(Gv, e1, psi1, NV, mode)
        EL, P = EL_forms(Gv, e1, om0, psi1, m, mode)
        Th = E2.theta_forms(Gv, e1); vol = E2.vol_form(Gv, e1)
        L = E2.L_dirac(Gv, e1, om1, psi, m, NV, mode, Th)
        Dpsi = Gv.D_spinor(om1, {S_: {0: p} for S_, p in psi.items()})
        T = Gv.torsion(om1, e); R = Gv.curvature(om)
        DS = D_dual_bivector(Gv, om0, S); Dt = Gv.D_covector(om0, tau)
        if want_canon:                                                         # (a) canonical form on the 1-jet: tau_a = i_a L - (i_a D psi).P
            Es, _ = inverse_series(frame_matrix(e1, N), N, NV, 1); canon = []
            for a in range(N):
                xi = [Es[mu][a] for mu in range(N)]; X = interior(Gv, xi, L)
                for S_ in EVEN:
                    iD = interior(Gv, xi, Dpsi.get(S_, {})).get(0, {})
                    if iD: X = Fm.add(X, Fm.wedge({0: iD}, P[S_]), -1)
                canon.append(X)
            out['canon'] = canon
            psiP = {}
            for S_, p in psi1.items(): psiP = Fm.add(psiP, Fm.wedge({0: p}, P[S_]))
            out['psiP'] = psiP
            out['Lcheck'] = Fm.add(Fm.add(L_of_D(Gv, e1, Dpsi, psi, Th, mode), L, -1), Fm.wedge({0: E2.currents(psi, sq, NV)[2].get(0, {})}, vol), -F(m))
        if kap is not None:
            Ein = Gv.einstein(om1, e1, R, c)[0]; ThEC = by_A(Gv, B1.Theta_forms(Gv, e1, T))
            X = [Fm.add(Ein[a], tau[a], -kap) for a in range(N)]; Y = [Fm.add(ThEC[A], S[A], -kap) for A in range(Gv.G)]
            DY = D_dual_bivector(Gv, om0, Y); DX = Gv.D_covector(om0, X)
    psi0 = {S_: v0(p) for S_, p in psi.items() if v0(p) != 0}
    EL0 = {S_: top0(EL[S_]) for S_ in EVEN}
    def pair(Xmv): return sum((Xmv.get(S_, F(0)) * EL0[S_] for S_ in EVEN), F(0))
    Bpsi = [E2.mv_mul({g: F(1)}, psi0, sq) for g in Gv.L.gens]; psiB = [E2.mv_mul(psi0, {g: F(1)}, sq) for g in Gv.L.gens]
    iDpsi = [{S_: sum((E0[mu][a] * v0(Dpsi.get(S_, {}).get(1 << mu, {})) for mu in range(N)), F(0)) for S_ in EVEN} for a in range(N)]
    f0 = lambda X: form0(X); eL = [Fm.scale(f0(e[a]), sq[a]) for a in range(N)]
    w0 = lambda X, Y: top0(Fm.wedge(f0(X), f0(Y)))
    xi0 = [[cst(E0[mu][a]) for mu in range(N)] for a in range(N)]
    out.update(EL0=EL0, psi0=psi0, det=det, E0=E0, vol0=top0(vol), L0=top0(L), S=S, T=T, R=R,
               pairB=[pair(x) for x in Bpsi], pairBr=[pair(x) for x in psiB], pairD=[pair(x) for x in iDpsi], pairpsi=pair(psi0),
               mass=sum((v * v * E2.rsg(S_) * bmul(S_, S_, sq)[1] for S_, v in psi0.items()), F(0)),
               lhsB=[top0(DS[A]) for A in range(Gv.G)], r1=[w0(eL[a], tau[b]) - w0(eL[b], tau[a]) for (a, b) in PAIRS],
               lhsC=[top0(Dt[a]) for a in range(N)],
               tT=[sum((top0(Fm.wedge(interior(Gv, xi0[a], f0(T[b])), f0(tau[b]))) for b in range(N)), F(0)) for a in range(N)],
               tR=[sum((top0(Fm.wedge(interior(Gv, xi0[a], f0(R[A])), f0(S[A]))) for A in range(Gv.G)), F(0)) for a in range(N)],
               trace=sum((w0(e[a], tau[a]) for a in range(N)), F(0)),
               taumix=[[w0(e[b], tau[a]) / top0(vol) for a in range(N)] for b in range(N)])
    if kap is not None:
        out['e1res'] = [top0(DY[A]) - (w0(eL[a], X[b]) - w0(eL[b], X[a])) for A, (a, b) in enumerate(PAIRS)]
        out['e2res'] = [top0(DX[a]) - sum((top0(Fm.wedge(interior(Gv, xi0[a], f0(T[b])), f0(X[b]))) for b in range(N)), F(0))
                        - sum((top0(Fm.wedge(interior(Gv, xi0[a], f0(R[A])), f0(Y[A]))) for A in range(Gv.G)), F(0)) for a in range(N)]
    return out

def onshell_psi(Gv, e, om, psi, m, mode='axial'):
    """[bit] the 8 coefficients of x^0 in psi (d_0 psi at the origin) solved from EL_S(0) = 0 (affine in them): (psi_on, rank, consistent)"""
    e1 = [tf(x, 1) for x in e]; om0 = [tf(x, 0) for x in om]
    base = {S: {k: v for k, v in p.items() if k != K0} for S, p in psi.items()}
    def EL0(ps):
        with trunc(N, xdeg=1): EL, _ = EL_forms(Gv, e1, om0, {S: tp(p, 1) for S, p in ps.items()}, m, mode)
        return [top0(EL[S]) for S in EVEN]
    b = EL0(base); cols = []
    for T_ in EVEN:
        ps = dict(base); ps[T_] = padd(ps.get(T_, {}), {K0: F(1)}); cols.append([x - y for x, y in zip(EL0(ps), b)])
    rows = [[cols[j][i] for j in range(len(EVEN))] for i in range(len(EVEN))]
    w, rank, nvar, cons = solve_exact(rows, [-x for x in b])
    if w is None or rank < len(EVEN): return None, rank, cons
    on = dict(base)
    for j, T_ in enumerate(EVEN):
        if w[j] != 0: on[T_] = padd(on.get(T_, {}), {K0: w[j]})
    return {S: p for S, p in on.items() if p}, rank, cons

def fit(cols, rhs):
    rows = [list(r) for r in zip(*cols)]; w, rank, nvar, cons = solve_exact(rows, rhs)
    return w, rank, cons

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
def peval(p, x): return float(sum(float(c) * np.prod([x[i] ** k[i] for i in range(N)]) for k, c in p.items() if k[N] == 0))
def std_at(st, fields, m, x, sq=LOR):
    """textbook quantities at the point x: e, E = e^-1, det, om^{pq}_mu, chi, nab_a chi, l, canonical T[b][a], sigma[(c, A)]"""
    e, om, psi = fields; x = np.asarray(x, float)
    em = np.array([[peval(e[a].get(1 << mu, {}), x) for mu in range(N)] for a in range(N)]); E = np.linalg.inv(em); det = np.linalg.det(em)
    W = np.zeros((N, N, N))
    for A, (p, q) in enumerate(PAIRS):
        for mu in range(N): v = peval(om[A].get(1 << mu, {}), x); W[mu, p, q] = v; W[mu, q, p] = -v
    chi = st.chi({S: peval(p, x) for S, p in psi.items()}); dchi = [st.chi({S: peval(std_der(p, mu), x) for S, p in psi.items()}) for mu in range(N)]
    G, Gup = st.G, st.Gup
    nab = [sum(E[mu, a] * (dchi[mu] + 0.5 * sum(W[mu, p, q] * (G[p] @ G[q] @ chi) for (p, q) in PAIRS)) for mu in range(N)) for a in range(N)]
    bar = st.bar(chi); nbar = [n_.conj() @ Gup[0] for n_ in nab]
    ell = sum((1j * (bar @ Gup[c] @ nab[c])).real for c in range(N)) - m * (bar @ chi).real
    Tz = np.array([[(0.5j * (bar @ Gup[b] @ nab[a] - nbar[a] @ Gup[b] @ chi)) for a in range(N)] for b in range(N)])
    T = Tz.real - ell * np.eye(N)
    sig = st.sigma(chi)
    return dict(em=em, E=E, det=det, W=W, chi=chi, ell=ell, T=T, Timag=float(np.max(np.abs(Tz.imag))), sig=sig, chibarchi=(bar @ chi).real, dchi=dchi)
def std_tau_var(st, fields, m):
    """[std] tau^b_a = e^b_mu d(det(e) l)/d e^a_mu / det(e) at the origin, numerical (4-point stencil) in the 16 frame entries; chi, d chi, om_mu fixed"""
    d0 = std_at(st, fields, m, np.zeros(N)); chi, dchi, W, G, Gup = d0['chi'], d0['dchi'], d0['W'], st.G, st.Gup; bar = st.bar(chi)
    co = [dchi[mu] + 0.5 * sum(W[mu, p, q] * (G[p] @ G[q] @ chi) for (p, q) in PAIRS) for mu in range(N)]
    def dens(em):
        E = np.linalg.inv(em); nab = [sum(E[mu, a] * co[mu] for mu in range(N)) for a in range(N)]
        return (sum((1j * (bar @ Gup[c] @ nab[c])).real for c in range(N)) - m * (bar @ chi).real) * np.linalg.det(em)
    em0 = d0['em']; D = np.zeros((N, N)); h = 1e-4
    for a in range(N):
        for mu in range(N):
            def f(t): M = em0.copy(); M[a, mu] += t; return dens(M)
            D[a, mu] = (8 * (f(h) - f(-h)) - (f(2 * h) - f(-2 * h))) / (12 * h)
    return np.array([[sum(em0[b, mu] * D[a, mu] for mu in range(N)) / d0['det'] for a in range(N)] for b in range(N)])
def std_onshell(st, fields, m, sq=LOR, h=1e-3):
    """[std] on the given (on-shell) jets: l(0), T^a_a - m chibar chi, and the residuals of (b) D S_ab = (tau_ab - tau_ba) det and
       (c) D tau_a = (i_a T^b) tau_b + (i_a R^A) S_A, with 3-forms as vector densities y^mu = det E^mu_c X^c, d = divergence (central differences)"""
    e, om, psi = fields; eta = np.array(sq, float)
    def Y(x):
        d = std_at(st, fields, m, x); E, det = d['E'], d['det']; tau = -d['T']
        yS = np.array([[det * sum(E[mu, c] * d['sig'][(c, A)] for c in range(N)) for mu in range(N)] for A in range(len(PAIRS))])
        yT = np.array([[det * sum(E[mu, b] * tau[b, a] for b in range(N)) for mu in range(N)] for a in range(N)])
        return yS, yT, d
    yS0, yT0, d0 = Y(np.zeros(N)); divS = np.zeros(len(PAIRS)); divT = np.zeros(N)
    for mu in range(N):
        ev = np.zeros(N); ev[mu] = 1.0
        pS = [Y(k * h * ev) for k in (1, -1, 2, -2)]
        dS = (8 * (pS[0][0] - pS[1][0]) - (pS[2][0] - pS[3][0])) / (12 * h); dT = (8 * (pS[0][1] - pS[1][1]) - (pS[2][1] - pS[3][1])) / (12 * h)
        divS += dS[:, mu]; divT += dT[:, mu]
    W, E, em, det = d0['W'], d0['E'], d0['em'], d0['det']; tau = -d0['T']
    wl = lambda mu, c, a: W[mu, c, a] * eta[a]                                  # om^c_a = om^{ca} eta_aa
    Sfull = np.zeros((N, N, N))
    for A, (p, q) in enumerate(PAIRS): Sfull[p, q] = yS0[A]; Sfull[q, p] = -yS0[A]
    resB, scB = [], []
    for A, (a, b) in enumerate(PAIRS):
        lhs = divS[A] - sum(wl(mu, c, a) * Sfull[c, b, mu] + wl(mu, c, b) * Sfull[a, c, mu] for c in range(N) for mu in range(N))
        rhs = det * (eta[a] * tau[a, b] - eta[b] * tau[b, a]); resB.append(lhs - rhs); scB.append(max(abs(lhs), abs(rhs), abs(divS[A])))
    de = np.array([[[peval(std_der(e[b].get(1 << nu, {}), mu), np.zeros(N)) for mu in range(N)] for nu in range(N)] for b in range(N)])   # de[b, nu, mu] = d_mu e^b_nu
    dW = np.zeros((N, N, N, N))                                                 # dW[mu, nu, p, q] = d_mu om^{pq}_nu
    for A, (p, q) in enumerate(PAIRS):
        for nu in range(N):
            for mu in range(N): v = peval(std_der(om[A].get(1 << nu, {}), mu), np.zeros(N)); dW[mu, nu, p, q] = v; dW[mu, nu, q, p] = -v
    Tt = np.array([[[de[b, nu, mu] - de[b, mu, nu] + sum(wl(mu, b, c) * em[c, nu] - wl(nu, b, c) * em[c, mu] for c in range(N)) for nu in range(N)] for mu in range(N)] for b in range(N)])
    Rt = np.array([[[[dW[mu, nu, p, q] - dW[nu, mu, p, q] + sum(eta[dd] * (W[mu, p, dd] * W[nu, dd, q] - W[nu, p, dd] * W[mu, dd, q]) for dd in range(N))
                      for nu in range(N)] for mu in range(N)] for q in range(N)] for p in range(N)])
    resC, scC = [], []
    for a in range(N):
        lhs = divT[a] - sum(wl(mu, b, a) * yT0[b, mu] for b in range(N) for mu in range(N))
        iT = sum(E[mu, a] * Tt[b, mu, nu] * yT0[b, nu] for b in range(N) for mu in range(N) for nu in range(N))
        iR = sum(E[mu, a] * Rt[p, q, mu, nu] * yS0[A, nu] for A, (p, q) in enumerate(PAIRS) for mu in range(N) for nu in range(N))
        resC.append(lhs - iT - iR); scC.append(max(abs(lhs), abs(iT), abs(iR), abs(divT[a])))
    return dict(ell=d0['ell'], trace=float(np.trace(d0['T'])), mcc=m * d0['chibarchi'], resB=max(abs(r) for r in resB) / max(scB), resC=max(abs(r) for r in resC) / max(scC),
                Timag=d0['Timag'])

# ------------------------------------------------------------------------------------------------ stretch: torsion eliminated (Hehl-Datta form of the frame equation at a point)
def kstar_forms(Gv, e, psi, kap):
    """E2's closed-form contorsion K*^{pq} = -(kappa/4) sq_p sq_q sum_c eps(p,q,c,d) s^d e^c (1-forms to x-degree 1), and s^d"""
    Fm = Gv.Fm
    with trunc(N, xdeg=1):
        s = E2.vec(E2.currents(psi, LOR, NV)[0]); K = []
        for (p, q) in PAIRS:
            f = {}
            for cc in E2.comp4(p, q):
                d = E2.comp4(p, q, cc)[0]
                if s[d]: f = Fm.add(f, Fm.wedge({0: s[d]}, e[cc]), F(-1, 4) * kap * LOR[p] * LOR[q] * E2.perm([p, q, cc, d]))
            K.append(f)
    return K, s
def frame_eq(Gv, e, om, psi, m, c):
    """lowered frame components at the origin: (E_ab, tau_ab) with E_ab = sq_a E^a_b (E_b = E^a_b Th_a, Einstein form with c), tau likewise"""
    Fm = Gv.Fm; e1 = [tf(x, 1) for x in e]; tau = dirac_stress(Gv, e1, [tf(x, 1) for x in om], psi, m)
    with trunc(N, xdeg=1): R = Gv.curvature(om); Ein = Gv.einstein(om, e1, R, c)[0]; vol = top0(E2.vol_form(Gv, e1))
    low = lambda X: [[LOR[a] * top0(Fm.wedge(form0(e[a]), form0(X[b]))) / vol for b in range(N)] for a in range(N)]
    return low(Ein), low(tau)
def part_stretch(Gv, rng):
    head('stretch: torsion eliminated, omega* = omega_LC (A3 1-jet) + K* (E2 closed form); the frame equation in Hehl-Datta form at the point  [1 curved configuration]')
    Fm = Gv.Fm; e, _, psi = strong_fields(rng); m = F(rng.randint(1, 9), rng.randint(1, 4)); kap = F(rng.randint(1, 9), rng.randint(1, 5)); c = F(rng.randint(-5, 5), rng.randint(1, 7))
    Sk = koszul_S(N, LOR, Gv.L); oml = omega_closed_form(Gv, e, Sk, NV, 1, Dpre=anholonomy(Gv, e, NV, 1))[0]
    e1 = [tf(x, 1) for x in e]; sym = lambda M: [[(M[a][b] + M[b][a]) / 2 for b in range(N)] for a in range(N)]
    with trunc(N, xdeg=1): T0l = Gv.torsion(oml, e)
    chk('bit', all(is0(x) for x in T0l), 'omega_LC (A3 closed form, 1-jet) is torsion-free to first order on this frame (precondition)')
    def build(ps):
        K, s = kstar_forms(Gv, e, ps, kap); oms = [Fm.add(oml[A], K[A]) for A in range(Gv.G)]
        ss = sum((LOR[d] * v0(s[d]) ** 2 for d in range(N)), F(0)); return oms, ss
    oms, ss = build(psi)
    with trunc(N, xdeg=1):
        T = Gv.torsion(oms, e); ThEC = by_A(Gv, B1.Theta_forms(Gv, e1, T)); S = E2.spin_forms_engine(Gv, e1, {S_: tp(p, 1) for S_, p in psi.items()}, NV)
    chk('bit', all(is0(Fm.add(ThEC[A], S[A], -kap)) for A in range(Gv.G)), 'Y_A = Theta_A(T(omega*)) - kappa S_A = 0 as 3-forms to first order (the omega-equation holds near the point, not only at it)')
    Es, ts = frame_eq(Gv, e, oms, psi, m, c); El, tl = frame_eq(Gv, e, oml, psi, m, c)
    D = [[(Es[a][b] - kap * ts[a][b]) - (El[a][b] - kap * tl[a][b]) for b in range(N)] for a in range(N)]; Ds = sym(D)
    ct = F(-3, 16) * kap ** 2 * ss
    chk('bit', all(Ds[a][b] == (ct * LOR[a] if a == b else 0) for a in range(N) for b in range(N)) and ct != 0,
        'off shell: sym[X(omega*) - X(omega_LC)]_ab = -(3/16) kappa^2 (s.s) eta_ab exactly (X_a = E_a - kappa tau_a): the contact stress, and the spin-connection (Belinfante) term has no symmetric part')
    chk('ctl', not all(Ds[a][b] == (-ct * LOR[a] if a == b else 0) for a in range(N) for b in range(N)), 'contact coefficient +3/16: fails')
    Xoff = [[Es[a][b] - kap * ts[a][b] for b in range(N)] for a in range(N)]
    chk('ctl', any(Xoff[a][b] != Xoff[b][a] for a in range(N) for b in range(N)), 'off the Dirac shell X_ab(omega*) is NOT symmetric')
    def lproj(om_, ps):
        with trunc(N, xdeg=1): EL, _ = EL_forms(Gv, e1, [tf(x, 0) for x in om_], {S_: tp(p, 1) for S_, p in ps.items()}, m)
        p0 = {S_: v0(p) for S_, p in ps.items() if v0(p) != 0}; EL0 = [top0(EL[S_]) for S_ in EVEN]
        return [sum((E2.mv_mul({g: F(1)}, p0, LOR).get(S_, F(0)) * EL0[i] for i, S_ in enumerate(EVEN)), F(0)) for g in Gv.L.gens], EL0
    pS, ELs = lproj(oms, psi); pL, ELl = lproj(oml, psi)
    # "psi on the torsion-free Dirac shell: X(omega*) not symmetric" is not a wrong version; the reason is this finding:
    chk('bit', pS == pL and any(pS) and ELs != ELl, 'finding: the 6 Lorentz projections (B_ab psi).EL are EQUAL for omega* and omega_LC although EL itself differs (K* exerts no torque on the spin s that builds it); so the torsion-free Dirac shell also makes X(omega*) symmetric')
    pon, rank, _ = onshell_psi(Gv, e, oms, psi, m)
    chk('bit', pon is not None and rank == 8, 'the torsionful Dirac equation EL(omega*)(0) = 0 fixes d_0 psi (rank %d)' % rank)
    oms, ss = build(pon); ct = F(-3, 16) * kap ** 2 * ss
    Es, ts = frame_eq(Gv, e, oms, pon, m, c); El, tl = frame_eq(Gv, e, oml, pon, m, c)
    X = [[Es[a][b] - kap * ts[a][b] for b in range(N)] for a in range(N)]; tls = sym(tl)
    chk('bit', all(X[a][b] == X[b][a] for a in range(N) for b in range(N)) and any(tl[a][b] != tl[b][a] for a in range(N) for b in range(N)),
        'on the torsionful Dirac shell: X_ab(omega*) is symmetric (its antisymmetric part is (kappa/2)(B psi).EL by (e) with Y = 0), although tau(omega_LC) is not')
    chk('bit', all(X[a][b] == El[a][b] - kap * tls[a][b] + (ct * LOR[a] if a == b else 0) for a in range(N) for b in range(N)),
        'Hehl-Datta form at the point: E_ab(omega*) - kappa tau_ab(omega*) = E_ab(omega_LC) - kappa [tau_(ab)(omega_LC) + (3 kappa/16)(s.s) eta_ab] exactly (kappa = %s, s.s = %s)' % (kap, ss))
    chk('ctl', not all(X[a][b] == El[a][b] - kap * tl[a][b] + (ct * LOR[a] if a == b else 0) for a in range(N) for b in range(N)),
        'the same with the canonical (non-symmetrised) tau(omega_LC) in place of tau_(ab): fails')
    tick('stretch')

# ------------------------------------------------------------------------------------------------ main
def main():
    K = 3
    if '--seeds' in sys.argv: K = int(sys.argv[sys.argv.index('--seeds') + 1])
    rng = random.Random(20261009 + 421); Gv = Grav(N, Lie(LOR)); Fm = Gv.Fm; st = E2.Std()
    seeds = []
    for k in range(K):
        fields = strong_fields(rng); m = F(rng.randint(1, 9), rng.randint(1, 4)); kap = F(rng.randint(1, 9), rng.randint(1, 5)); c = F(rng.randint(-5, 5), rng.randint(1, 7))
        lam = [{0: nz(B3.strong_poly(rng, 2))} for _ in range(Gv.G)]
        seeds.append(dict(fields=fields, m=m, kap=kap, c=c, lam=lam))

    head('(a) Dirac stress by variation of the frame: tau_a = tau^b_a Th_b; canonical form; textbook canonical stress  [strong fields, x-degree 2, 3 seeds]')
    offs = []
    for k, sd in enumerate(seeds):
        e, om, psi = sd['fields']; m = sd['m']
        D = at_point(Gv, e, om, psi, m, kap=sd['kap'], c=sd['c'], want_canon=True); offs.append(D)
        if k == 0: chk('bit', is0(D['Lcheck']) , 'L_of_D(D psi) - m <psi psi~> vol = E2.L_dirac exactly on the 1-jet (the split Lagrangian used for P_S is E2\'s)')
        chk('bit', all(is0(Fm.add(D['tau'][a], D['canon'][a], -1)) for a in range(N)) and not is0(D['tau'][0]),
            'seed %d: tau_a = i_{E_a} L_D - (i_{E_a} D psi).P exactly as 3-forms on the 1-jet (canonical form = frame variation)' % k)
        chk('bit', is0(D['psiP']), 'seed %d: psi.P = sum_S psi_S P_S = 0 identically on the 1-jet (axial line: <g^a psi J g0 psi~> = <g^a I s> = 0)' % k)
        tb = np.array([[float(D['taumix'][b][a]) for a in range(N)] for b in range(N)])
        d0 = std_at(st, sd['fields'], float(m), np.zeros(N)); Ts = d0['T']; tv = std_tau_var(st, sd['fields'], float(m))
        sc = float(np.max(np.abs(Ts))); cT = float(np.sum(tb * Ts) / np.sum(Ts * Ts))
        chk('std', float(np.max(np.abs(tv + Ts))) < 1e-7 * sc and d0['Timag'] < 1e-9 * sc, 'seed %d: [std] numerical frame variation of det(e) l(e) = -T(canonical) (rel %.1e; Im T %.1e)' % (k, np.max(np.abs(tv + Ts)) / sc, d0['Timag'] / sc))
        chk('bit==std', float(np.max(np.abs(tb + Ts))) < 1e-9 * sc, 'seed %d: tau^b_a (engine) = c_T T^b_a (textbook canonical) with c_T = %.12f (residual %.1e)' % (k, cT, np.max(np.abs(tb + Ts)) / sc))
        chk('bit==std', float(np.max(np.abs(tb - tv))) < 1e-7 * sc, 'seed %d: tau^b_a (engine) = [std] numerical frame variation (rel %.1e)' % (k, np.max(np.abs(tb - tv)) / sc))
        tl = [[LOR[a] * D['taumix'][a][b] for b in range(N)] for a in range(N)]; asym = max(abs(tl[a][b] - tl[b][a]) for a in range(N) for b in range(N))
        chk('bit', asym != 0, 'seed %d: tau_ab = sq_a tau^a_b is NOT symmetric (max |tau_ab - tau_ba| = %.4g, max |tau_ab| = %.4g)' % (k, float(asym), float(max(abs(x) for r in tl for x in r))))
        chk('ctl', float(np.max(np.abs(tb - Ts))) > 1e-3 * sc, 'seed %d: c_T = +1 (tau = +T) fails' % k)
    e, om, psi = seeds[0]['fields']; GvE = Grav(N, Lie([1, 1, 1, 1]))
    tE = dirac_stress(GvE, [tf(x, 1) for x in e], [tf(x, 1) for x in om], psi, seeds[0]['m'])
    with trunc(N, xdeg=1): volE = top0(E2.vol_form(GvE, [tf(x, 1) for x in e]))
    tEm = np.array([[float(top0(Fm.wedge(form0(e[b]), form0(tE[a]))) / volE) for a in range(N)] for b in range(N)]); Ts0 = std_at(st, seeds[0]['fields'], float(seeds[0]['m']), np.zeros(N))['T']
    chk('ctl', float(np.max(np.abs(tEm + Ts0))) > 1e-3 * float(np.max(np.abs(Ts0))), 'Euclidean squares (Dirac 4-form built in Cl(4,0) on the same jets): its tau is not -T(textbook, Lorentzian)')
    tick('(a)')

    head('(b) local Lorentz: exact invariance of L_D, then D S_ab = c1 (e_a ^ tau_b - e_b ^ tau_a) + c2 (B_ab psi).EL  (D on the lower bivector index)')
    for k, sd in enumerate(seeds):
        e, om, psi = sd['fields']; m = sd['m']; e1 = [tf(x, 1) for x in e]; om1 = [tf(x, 1) for x in om]
        dl = lorentz_defect(Gv, e1, om1, psi, m, sd['lam'])
        chk('bit', is0(dl), 'seed %d: L_D(e - h lam e, om + D lam, psi - (1/2) lam B psi) - L_D = 0 at first order exactly (1-jet; lam of x-degree 2): no exact form' % k)
        if k == 0:
            chk('ctl', not is0(lorentz_defect(Gv, e1, om1, psi, m, sd['lam'], spin_sign=+1)), 'wrong sign of the spinor rotation (dpsi = +(1/2) lam B psi): delta L_D != 0')
            chk('ctl', not is0(lorentz_defect(Gv, e1, om1, psi, m, sd['lam'], sign_om=-1)), 'dom = -D lam with the right spinor rotation: delta L_D != 0')
    lhs = [x for D in offs for x in D['lhsB']]; r1 = [x for D in offs for x in D['r1']]; r2 = [x for D in offs for x in D['pairB']]; r2r = [x for D in offs for x in D['pairBr']]
    w, rank, cons = fit([r1, r2], lhs)
    chk('bit', cons and rank == 2 and w == [1, F(-1, 2)], 'off shell, exact fit over %d seeds x 6 pairs (rank %d): (c1, c2) = (%s); predicted (1, -1/2)' % (len(seeds), rank, ', '.join(map(str, w)) if w else 'none'))
    sz = max(abs(x) for x in r2) / max(abs(x) for x in lhs)
    chk('ctl', any(a != b for a, b in zip(lhs, r1)), 'Dirac equation not imposed and the EL term dropped: D S_ab != e_a tau_b - e_b tau_a off shell (max |(1/2)(B psi).EL| / max |D S| = %.3g)' % (float(sz) / 2))
    chk('ctl', fit([r1, r2r], lhs)[0] is None, 'right multiplication (psi B_ab).EL in place of (B_ab psi).EL: no exact fit')
    chk('ctl', any(a != b + c_ / 2 for a, b, c_ in zip(lhs, r1, r2)), 'c2 = +1/2 (the sign of the spinor rotation flipped in the identity): fails')
    tick('(b)')

    head('(c) diffeomorphism: D tau_a = al (i_a T^b) ^ tau_b + be (i_a R^A) ^ S_A + d1 (i_a D psi).EL  (D on the covector index; torsion != 0)')
    lhs = [x for D in offs for x in D['lhsC']]; cT_ = [x for D in offs for x in D['tT']]; cR = [x for D in offs for x in D['tR']]; cD = [x for D in offs for x in D['pairD']]
    w, rank, cons = fit([cT_, cR, cD], lhs)
    chk('bit', cons and rank == 3 and w == [1, 1, 1], 'off shell, exact fit over %d seeds x 4 components (rank %d): (al, be, d1) = (%s); predicted (1, 1, 1)' % (len(seeds), rank, ', '.join(map(str, w)) if w else 'none'))
    chk('bit', all(x != 0 for x in cT_) and all(x != 0 for x in cR), 'every torsion term (i_a T^b) tau_b and curvature term (i_a R^A) S_A is non-zero (both are tested)')
    chk('ctl', fit([cR, cD], lhs)[0] is None, 'without the torsion term: no exact fit')
    chk('ctl', any(a != t + r - d for a, t, r, d in zip(lhs, cT_, cR, cD)), 'd1 = -1: fails')
    chk('ctl', any(a != t + r for a, t, r in zip(lhs, cT_, cR)), 'EL term dropped off shell: fails (max |(i_a D psi).EL| / max |D tau| = %.3g)' % float(max(abs(x) for x in cD) / max(abs(x) for x in lhs)))
    tick('(c)')

    head('(d) trace: tau^a_a vol = t2 psi.EL + t1 m <psi psi~> vol, off shell')
    lhs = [D['trace'] for D in offs]; c1_ = [D['pairpsi'] for D in offs]; c2_ = [sd['m'] * D['mass'] * D['vol0'] for sd, D in zip(seeds, offs)]
    w, rank, cons = fit([c1_, c2_], lhs)
    chk('bit', cons and rank == 2 and w == [F(3, 2), -1], 'exact fit over %d seeds (rank %d): (t2, t1) = (%s); predicted (3/2, -1); so tau^a_a = 3 l - m <psi psi~> with L_D = l vol' % (len(seeds), rank, ', '.join(map(str, w)) if w else 'none'))
    chk('bit', all(D['pairpsi'] == 2 * D['L0'] for D in offs), 'psi.EL = 2 L_D at the origin (Euler homogeneity, psi.P = 0)')
    chk('ctl', any(a != F(3, 2) * b + c_ for a, b, c_ in zip(lhs, c1_, c2_)), 't1 = +1: fails')
    tick('(d)')

    head('(e) chain with B2 (L_tot = L_EC(c) - kappa L_D): X_a = E_a - kappa tau_a, Y_A = Theta_A - kappa S_A; only matter-EL terms remain')
    for k, (sd, D) in enumerate(zip(seeds, offs)):
        kap = sd['kap']
        ok1 = all(r == kap / 2 * p for r, p in zip(D['e1res'], D['pairB'])) and any(D['pairB'])
        ok2 = all(r == -kap * p for r, p in zip(D['e2res'], D['pairD'])) and any(D['pairD'])
        chk('bit', ok1, 'seed %d (kappa = %s, c = %s): D Y_ab - (e_a X_b - e_b X_a) = +(kappa/2)(B_ab psi).EL exactly (gravity part EL-free, B2)' % (k, kap, sd['c']))
        chk('bit', ok2, 'seed %d: D X_a - (i_a T^b) X_b - (i_a R^A) Y_A = -kappa (i_a D psi).EL exactly' % k)
    tick('(e)')

    head('on shell: d_0 psi at the origin solved from EL_S(0) = 0 (8 exact linear equations); identities without EL terms; [std] textbook checks')
    for k, sd in enumerate(seeds):
        e, om, psi = sd['fields']; m = sd['m']
        pon, rank, cons = onshell_psi(Gv, e, om, psi, m)
        chk('bit', pon is not None and rank == 8, 'seed %d: the principal symbol in d_0 psi has rank %d of 8 (the Dirac equation fixes d_0 psi at the point)' % (k, rank))
        if pon is None: continue
        D = at_point(Gv, e, om, pon, m, kap=sd['kap'], c=sd['c'])
        chk('bit', all(v == 0 for v in D['EL0'].values()) and D['L0'] == 0, 'seed %d: EL_S(0) = 0 for all 8 S, and L_D(0) = 0 on shell' % k)
        chk('bit', D['lhsB'] == D['r1'] and any(D['r1']), 'seed %d: on shell D S_ab = e_a ^ tau_b - e_b ^ tau_a = (tau_ab - tau_ba) vol, non-zero: the antisymmetric stress is the spin divergence' % k)
        chk('bit', all(a == t + r for a, t, r in zip(D['lhsC'], D['tT'], D['tR'])), 'seed %d: on shell D tau_a = (i_a T^b) ^ tau_b + (i_a R^A) ^ S_A exactly' % k)
        chk('bit', D['trace'] == -m * D['mass'] * D['vol0'], 'seed %d: on shell tau^a_a = -m <psi psi~> (m = %s, <psi psi~> = %s)' % (k, m, D['mass']))
        chk('bit', not any(D['e1res']) and not any(D['e2res']), 'seed %d: on shell both combined identities of L_tot close with no remainder (gravity B2 + matter)' % k)
        so = std_onshell(st, (e, om, pon), float(m)); scl = max(1.0, abs(so['mcc']))
        chk('std', abs(so['ell']) < 1e-8 * scl and abs(so['trace'] - so['mcc']) < 1e-8 * scl, 'seed %d: [std] on the engine-solved jets: textbook l = %.1e, T^a_a - m chibar chi = %.1e' % (k, so['ell'], so['trace'] - so['mcc']))
        chk('std', so['resB'] < 1e-7 and so['resC'] < 1e-7, 'seed %d: [std] textbook on-shell identities by central differences: (b) rel %.1e, (c) rel %.1e' % (k, so['resB'], so['resC']))
        if k == 0:
            off_so = std_onshell(st, (e, om, psi), float(m))
            chk('ctl', off_so['resB'] > 1e-4 or off_so['resC'] > 1e-4, '[std] the same textbook identities on the OFF-shell jets fail (b) rel %.2g, (c) rel %.2g' % (off_so['resB'], off_so['resC']))
            p0, r0, _ = onshell_psi(Gv, e, om, psi, F(0)); D0 = at_point(Gv, e, om, p0, F(0))
            chk('bit', r0 == 8 and D0['trace'] == 0 and not all(v == 0 for v in D0['taumix'][0]), 'm = 0 on shell: tau^a_a = 0 (traceless), tau != 0')
    tick('on shell')

    head('controls with the vector-current Lagrangian (E2 mode vector: J dropped): Noether identities still hold, the axial structure does not')
    e, om, psi = seeds[0]['fields']; m = seeds[0]['m']
    Dv = at_point(Gv, e, om, psi, m, mode='vector', want_canon=True)
    chk('bit', Dv['lhsB'] == [a - b / 2 for a, b in zip(Dv['r1'], Dv['pairB'])] and Dv['lhsC'] == [t + r + d for t, r, d in zip(Dv['tT'], Dv['tR'], Dv['pairD'])],
        'finding: the vector-current 4-form satisfies (b) and (c) with the same constants (1, -1/2) and (1, 1, 1) (every invariant 4-form does)')
    _, rv, _ = onshell_psi(Gv, e, om, psi, m, mode='vector')
    chk('ctl', rv < 8, 'vector-current 4-form: its principal symbol in d_0 psi has rank %d < 8 (the kinetic term is (1/2) d j^a ^ Th_a + om-terms)' % rv)
    chk('ctl', not is0(Dv['psiP']) and Dv['trace'] != F(3, 2) * Dv['pairpsi'] - m * Dv['mass'] * Dv['vol0'], 'vector-current 4-form: psi.P != 0 and the off-shell trace law (3/2, -1) fails')
    tick('vector')
    part_stretch(Gv, rng)
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('E2S4')

if __name__ == '__main__': main()
