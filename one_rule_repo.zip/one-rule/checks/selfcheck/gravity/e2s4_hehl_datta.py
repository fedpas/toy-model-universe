#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""E2S4-HD.  The Hehl-Datta equation in closed form: the Dirac Euler-Lagrange form on the torsionful connection omega* = omega_LC + K* equals, off shell,
   the torsion-free form plus a cubic term in the axial current, with the coefficient fixed by an exact fit.      python3 e2s4_hehl_datta.py [--draws K]

 n = 4, Cl(1,3), sq = (+,-,-,-), the Atlas Dirac line of E2; L_D, EL_S = dL/dpsi_S - d P_S and the strong random fields of E2S4; omega_LC = A3's closed
 form (first-order jet); K* = E2's stationary contorsion K*_c^{ab} = -(1/4) kappa sq_a sq_b eps_abcd s^d built from s = psi g3 psi~ of the same psi,
 held fixed as a connection when psi is varied (the omega-variation vanishes at the stationary point).
 [bit]  (1) EL_S(omega*) - EL_S(omega_LC) = c1 kappa G_S with G_S = d[(s.s) vol]/dpsi_S, c1 by an exact fit over the draws (predicted 3/16): the Dirac
        equation of omega* is the stationarity of L_eff = L_D(omega_LC) + (3 kappa/16)(s.s) vol; exact at the origin and as first-order jets.
        (2) Dictionary: EL_S = 2 nrm(S) Phi_S with Phi(psi) = sum_a g^a (D psi ^ Th_a) J g0 - m psi vol (L_D = <Phi psi~>_0), nrm(S) = <g_S g_S~>_0.
        (3) Operator form: Phi(omega*) - Phi(omega_LC) = c2 kappa (I s psi) J g0 vol with c2 = 3/8 = 2 c1, and (I s psi) J g0 = s psi g3,
        G_S = 4 nrm(S) (s psi g3)_S vol: the cubic coefficient of the equation is twice the contact coefficient of the action.
        (4) The contact coefficient read from the engine's L_tot on the same frames: L_tot(omega*) - L_tot(omega_LC) = -c1 kappa^2 (s.s) vol.
        (5) A trace (vector-current) contorsion drops out of the Euler-Lagrange form (K_t^A ^ S_A = 0) although it changes the operator.
 [std]  numpy only: the density det(e)[Re(chibar i Gamma^a nabla'_a chi) - m chibar chi] with the Christoffel spin connection of the frame plus
        (1/4) K*_a^{bc} Gamma_b Gamma_c, K* from the bilinears A^d = chibar Gamma^d gamma5 chi of the unperturbed field, varied numerically with respect
        to chibar (functional derivatives in the 8 real components, momenta differentiated in x by central differences): EL_std = (i Gamma^a nabla_a - m) chi
        + c A_d Gamma^d gamma5 chi with c by least squares (predicted 3 kappa/8).  [bit==std] M(Phi(omega*)/vol) u = EL_std / det(e).
 Controls: the closed form without the cubic term; the opposite sign; the contact coefficient doubled (3 kappa/8 in L_eff); a trace contorsion in
   place of the axial one; [std] without the contorsion and with the opposite sign.
 Scope: n = 4, (+,-,-,-), classical commuting spinors, the origin of 3 strong random configurations with first-order jets: checks at these points.
 Exports: contact_EL, phi_forms, nrm, cubic_forms, omega_star, std_EL, std_closed."""
import sys, os, time, random, itertools
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from b1lib import *
import e2_spin_torsion as E2
import e2s4_dirac_stress as S4
import e1_axial_torsion as E1A
from e1_lichnerowicz import to_mat
from e2s4_belinfante import omega_lc, std_eval, std_omega, std_nabla
import numpy as np

T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)
N, NV, FULL = 4, 5, 15
LOR = [1, -1, -1, -1]; PAIRS = E2.PAIRS; EVEN = E2.EVEN
LAMV = {(0, 0, 0, 0, 1): F(1)}
cst, v0, tp, tf, top0, form0, lamp, is0 = S4.cst, S4.v0, S4.tp, S4.tf, S4.top0, S4.form0, S4.lamp, S4.is0
def nrm(S): return E2.rsg(S) * bmul(S, S, LOR)[1]                                  # <g_S g_S~>_0 = product of the squares of the generators in S
def omega_star(Gv, oml, e, psi, kap):
    K, s = S4.kstar_forms(Gv, e, psi, kap); return [Gv.Fm.add(oml[A], K[A]) for A in range(Gv.G)], s

# ------------------------------------------------------------------------------------------------ [bit] the pieces
def contact_EL(Gv, e1, psi1, deg=0):
    """G_S = d[(s.s) vol]/dpsi_S: the lam-part of (s.s)(psi + lam g_S) vol, as polynomials to x-degree deg (exact there)"""
    Fm = Gv.Fm; out = {}
    with trunc(N, xdeg=deg, lam=1):
        vol = E2.vol_form(Gv, e1)
        for S in EVEN:
            ps = dict(psi1); ps[S] = padd(ps.get(S, {}), LAMV)
            s = E2.vec(E2.currents(ps, LOR, NV)[0]); ss = E2.dot(s, s, LOR, NV)
            out[S] = lamp(Fm.wedge({0: ss}, vol)).get(FULL, {})
    return out
def phi_forms(Gv, e1, om, psi, m):
    """Phi(psi) = sum_a g^a (D psi ^ Th_a) J g0 - m psi vol as {S: 4-form}: the Dirac operator in the Atlas form, L_D = <Phi psi~>_0 (E2's L_dirac loop
       without the final pairing); exact to x-degree 1 when psi carries its 2-jet and om its 1-jet"""
    Fm = Gv.Fm; sq = Gv.L.sq; out = {}
    with trunc(N, xdeg=1):
        Th = E2.theta_forms(Gv, e1); vol = E2.vol_form(Gv, e1); right = E2.mv_mul(E2.J_MV, E2.G0, sq)
        Dpsi = Gv.D_spinor(om, {S: {0: p} for S, p in psi.items()})
        for a in range(N):
            ga = {1 << a: F(sq[a])}
            for S, form in Dpsi.items():
                M = E2.mv_mul(E2.mv_mul(ga, {S: F(1)}, sq), right, sq); w = Fm.wedge(form, Th[a])
                for msk, c in M.items(): out[msk] = Fm.add(out.get(msk, {}), w, c)
        for S, p in psi.items(): out[S] = Fm.add(out.get(S, {}), Fm.wedge({0: tp(p, 1)}, vol), -F(m))
    return {k: v for k, v in out.items() if v}
def cubic_forms(Gv, e1, psi1, s):
    """(I s psi) J g0 vol and s psi g3 vol as {S: 4-form} to x-degree 1 (s: the list of the four components of the axial current)"""
    Fm = Gv.Fm; sq = Gv.L.sq
    with trunc(N, xdeg=1):
        vol = E2.vol_form(Gv, e1); sv = {1 << d: p for d, p in enumerate(s) if p}
        X1 = E2.mvp_mul(E2.mvp_mul(E2.mvp_mul(E2.mvp_const(E2.I_MV, NV), sv, sq), psi1, sq), E2.mvp_const(E2.mv_mul(E2.J_MV, E2.G0, sq), NV), sq)
        X2 = E2.mvp_mul(E2.mvp_mul(sv, psi1, sq), E2.mvp_const(E2.G3, NV), sq)
        return {S: Fm.wedge({0: p}, vol) for S, p in X1.items() if p}, {S: Fm.wedge({0: p}, vol) for S, p in X2.items() if p}
def el_at0(Gv, e1, om, psi1, m):
    with trunc(N, xdeg=1): EL, P = S4.EL_forms(Gv, e1, [tf(x, 0) for x in om], psi1, m)
    return {S: top0(EL[S]) for S in EVEN}
def fit1(cols, rhs):
    """the single c with rhs = c * cols (exact): (c, rank, consistent)"""
    w, rank, cons = S4.fit([cols], rhs); return (w[0] if w else None), rank, cons

# ------------------------------------------------------------------------------------------------ [std] numpy route (never calls the engine)
def std_closed(st, e, psi, m, kap, x0):
    """(i Gamma^a nabla_a - m) chi and A_d Gamma^d gamma5 chi at x0 (nabla = Christoffel spin connection), and chi, det"""
    em, dem, chi, dchi = std_eval(st, e, psi, x0); W = std_omega(em, dem, st.eta); nab = std_nabla(st, em, W, chi, dchi)
    free = 1j * sum(st.Gup[a] @ nab[a] for a in range(N)) - m * chi; A = st.bil(chi)['A']
    cub = sum(LOR[d] * A[d] * st.Gup[d] @ st.g5 for d in range(N)) @ chi
    return free, cub, chi, np.linalg.det(em)
def std_EL(st, e, psi, m, kap, cub=1.0, h=1e-3, hx=1e-4):
    """[std] Gamma^0 (1/2)(dL/du + i dL/dv) / det(e) at the origin, u + i v = chi, dL/du the full functional derivative (dL/du - d_mu dL/d(d_mu u), the momenta
       by central differences in x) of the density det(e)[Re(chibar i Gamma^a nabla'_a chi) - m chibar chi], nabla' = Christoffel spin connection +
       (1/4) cub K*_a^{bc} Gamma_b Gamma_c with K* from A^d = chibar Gamma^d gamma5 chi of the UNPERTURBED field (cub = 0, -1: controls)"""
    kf = float(kap) * cub
    def background(x):                                                                             # everything that depends on x alone
        em, dem, chi0, dchi0 = std_eval(st, e, psi, x); W = std_omega(em, dem, st.eta); A = st.bil(chi0)['A']
        for a, b, c in itertools.permutations(range(N), 3):                                        # K^{ab}(E_c) = -(1/4) kappa eta^aa eta^bb eps_abcd A^d, K_mu^{ab} = K^{ab}(E_c) e^c_mu
            d = [y for y in range(N) if y not in (a, b, c)][0]
            W[:, a, b] += -0.25 * kf * LOR[a] * LOR[b] * E2.perm([a, b, c, d]) * A[d] * em[c, :]
        return em, W, np.linalg.det(em), np.concatenate([chi0.real, chi0.imag]), np.array([np.concatenate([d.real, d.imag]) for d in dchi0])
    def dens(bg, uv, duv):                                                                         # the density as a function of the 8 + 32 real variables
        em, W, det = bg[0], bg[1], bg[2]; chi = uv[:4] + 1j * uv[4:]; dchi = [duv[mu, :4] + 1j * duv[mu, 4:] for mu in range(N)]
        nab = std_nabla(st, em, W, chi, dchi); bar = st.bar(chi)
        return (sum((1j * (bar @ st.Gup[c] @ nab[c])).real for c in range(N)) - m * (bar @ chi).real) * det
    def mom(x):                                                                                   # dL/d(d_mu uv_i) at x: [mu, i]
        bg = background(x); uv, duv = bg[3], bg[4]; P = np.zeros((N, 8))
        for mu in range(N):
            for i in range(8):
                def f(t): D = duv.copy(); D[mu, i] += t; return dens(bg, uv, D)
                P[mu, i] = (8 * (f(h) - f(-h)) - (f(2 * h) - f(-2 * h))) / (12 * h)
        return P
    x0 = np.zeros(N); bg0 = background(x0); uv, duv = bg0[3], bg0[4]; g = np.zeros(8)
    for i in range(8):
        def f(t): U = uv.copy(); U[i] += t; return dens(bg0, U, duv)
        g[i] = (8 * (f(h) - f(-h)) - (f(2 * h) - f(-2 * h))) / (12 * h)
    dP = np.zeros(8)
    for mu in range(N):
        ev = np.zeros(N); ev[mu] = 1.0; p = [mom(k * hx * ev)[mu] for k in (1, -1, 2, -2)]
        dP += (8 * (p[0] - p[1]) - (p[2] - p[3])) / (12 * hx)
    dl = g - dP
    return st.Gup[0] @ (0.5 * (dl[:4] + 1j * dl[4:])) / bg0[2]
def lsq(Y, X):
    c = float(np.vdot(X, Y).real / np.vdot(X, X).real); return c, float(np.linalg.norm(Y - c * X) / max(1e-300, np.linalg.norm(Y)))

# ------------------------------------------------------------------------------------------------ main
def main():
    K = 3
    if '--draws' in sys.argv: K = int(sys.argv[sys.argv.index('--draws') + 1])
    rng = random.Random(7732); Gv = Grav(N, Lie(LOR)); Fm = Gv.Fm; st = E2.Std(); Sk = koszul_S(N, LOR, Gv.L)
    head('(1) EL(omega*) off shell against the closed form EL(omega_LC) + c1 kappa d[(s.s) vol]/dpsi  [strong random e, psi; omega* = omega_LC + K*(psi); %d draws]' % K)
    colG, rhs, colC, rhsC, rows = [], [], [], [], []
    for k in range(K):
        e, _, psi = S4.strong_fields(rng); m = F(rng.randint(1, 9), rng.randint(1, 4)); kap = F(rng.randint(1, 9), rng.randint(1, 5))
        e1 = [tf(x, 1) for x in e]; psi1 = {S: tp(p, 1) for S, p in psi.items()}; oml = omega_lc(Gv, e, Sk); oms, s = omega_star(Gv, oml, e, psi, kap)
        with trunc(N, xdeg=1):
            T0l = Gv.torsion(oml, e); Ts = Gv.torsion(oms, e); Tc = E1A.torsion_closed(Gv, e1, s, kap); vol0 = top0(E2.vol_form(Gv, e1))
            ss = sum((LOR[d] * v0(s[d]) ** 2 for d in range(N)), F(0))
        chk('bit', all(is0(x) for x in T0l) and all(is0(Fm.add(tf(Ts[a], 1), tf(Tc[a], 1), -1)) for a in range(N)) and any(Tc),
            'draw %d (kappa = %s, m = %s): omega_LC is torsion-free and the engine torsion of omega* is E2\'s axial closed form, to first order (precondition)' % (k, kap, m))
        ELs = el_at0(Gv, e1, oms, psi1, m); ELl = el_at0(Gv, e1, oml, psi1, m); G0 = contact_EL(Gv, e1, psi1, 0)
        d = [ELs[S] - ELl[S] for S in EVEN]; g = [kap * v0(G0[S]) for S in EVEN]
        chk('bit', any(d) and any(g), 'draw %d: EL(omega*) != EL(omega_LC) off shell and G != 0 (the cubic term is present and tested)' % k)
        colG += g; rhs += d
        # jets: the difference of dL/dpsi (the d P parts cancel) against c1 kappa G as first-order jets
        with trunc(N, xdeg=1): Th = E2.theta_forms(Gv, e1)
        dLs = S4.dL_dpsi(Gv, e1, [tf(x, 1) for x in oms], psi, m, Th); dLl = S4.dL_dpsi(Gv, e1, [tf(x, 1) for x in oml], psi, m, Th); G1 = contact_EL(Gv, e1, psi1, 1)
        diff1 = {S: padd(dLs[S].get(FULL, {}), dLl[S].get(FULL, {}), -1) for S in EVEN}
        rows.append(dict(diff1=diff1, G1=G1, kap=kap, ss=ss, vol0=vol0, e1=e1, psi1=psi1, psi=psi, e=e, m=m, oml=oml, oms=oms, s=s, ELs=ELs, ELl=ELl, G0=G0))
        # dictionary and operator form
        Ps = phi_forms(Gv, e1, oms, psi, m); Pl = phi_forms(Gv, e1, oml, psi, m)
        chk('bit', all(ELs[S] == 2 * nrm(S) * top0(Ps.get(S, {})) for S in EVEN) and all(ELl[S] == 2 * nrm(S) * top0(Pl.get(S, {})) for S in EVEN),
            'draw %d: dictionary EL_S = 2 nrm(S) Phi_S at the origin for omega_LC and omega* (Phi = (D psi) J g0 vol-contracted - m psi vol; nrm(S) = <g_S g_S~>_0)' % k)
        L0 = top0(E2.L_dirac(Gv, e1, [tf(x, 1) for x in oml], psi, m, NV))
        chk('bit', sum((nrm(S) * top0(Pl.get(S, {})) * v0(psi1.get(S, {})) for S in EVEN), F(0)) == L0 and L0 != 0, 'draw %d: L_D = <Phi psi~>_0 at the origin (the pairing behind the dictionary)' % k)
        X1, X2 = cubic_forms(Gv, e1, psi1, s)
        chk('bit', all(is0(Fm.add(X1.get(S, {}), X2.get(S, {}), -1)) for S in set(X1) | set(X2)) and bool(X1), 'draw %d: (I s psi) J g0 = s psi g3 as 1-jets (I anticommutes with s, I J g0 = -g3)' % k)
        chk('bit', all(v0(G0[S]) == 4 * nrm(S) * top0(X2.get(S, {})) for S in EVEN), 'draw %d: G_S = d(s.s vol)/dpsi_S = 4 nrm(S) (s psi g3)_S vol at the origin' % k)
        for S in set(Ps) | set(Pl) | set(X1):
            dP = Fm.add(Ps.get(S, {}), Pl.get(S, {}), -1).get(FULL, {}); xx = X1.get(S, {}).get(FULL, {})
            for key in set(dP) | set(xx): colC.append(kap * xx.get(key, F(0))); rhsC.append(dP.get(key, F(0)))
        # (4) the contact coefficient from the engine's L_tot on the same frame
        with trunc(N, xdeg=1):
            dLt = top0(Fm.add(E2.L_tot_value(Gv, e1, oms, psi, kap, m, NV), E2.L_tot_value(Gv, e1, oml, psi, kap, m, NV), -1))
        rows[-1]['C'] = dLt / (kap ** 2 * ss * vol0)
        chk('bit', rows[-1]['C'] == F(-3, 16), 'draw %d: L_tot(omega*) - L_tot(omega_LC) = C kappa^2 (s.s) vol at the origin with C = %s (E2\'s contact term on this frame; reads the curvature)' % (k, rows[-1]['C']))
        # (5) a trace contorsion
        with trunc(N, xdeg=1):
            jv = E2.vec(E2.currents(psi1, LOR, NV)[1]); Kt = E1A.trace_K(Gv, e1, jv, kap, F(-1, 4)); omt = [Fm.add(oml[A], Kt[A]) for A in range(Gv.G)]
            KS = {}; Sx = E2.spin_forms_engine(Gv, e1, psi1, NV)
            for A in range(Gv.G): KS = Fm.add(KS, Fm.wedge(Kt[A], Sx[A]))
        ELt = el_at0(Gv, e1, omt, psi1, m); Pt = phi_forms(Gv, e1, omt, psi, m)
        chk('bit', all(ELt[S] == ELl[S] for S in EVEN) and is0(KS) and any(Kt[A] for A in range(Gv.G)) and any(not is0(Fm.add(Pt.get(S, {}), Pl.get(S, {}), -1)) for S in set(Pt) | set(Pl)),
            'draw %d: finding: a trace contorsion (E2\'s vector-current K, lambda = -1/4) leaves EL unchanged (K_t^A ^ S_A = 0 identically) although it changes the operator Phi' % k)
        chk('ctl', any(ELt[S] - ELl[S] != F(3, 16) * kap * v0(G0[S]) for S in EVEN), 'draw %d: the closed form with the cubic term fails for the trace contorsion (its cubic term is absent)' % k)
        tick('draw %d' % k)
    c1, rank, cons = fit1(colG, rhs)
    chk('bit', cons and rank == 1 and c1 == F(3, 16), 'exact fit over %d draws x 8 components (rank %d): EL_S(omega*) - EL_S(omega_LC) = c1 kappa G_S with c1 = %s; predicted 3/16 = E2\'s contact coefficient' % (K, rank, c1))
    chk('bit', all(all(not padd(r['diff1'][S], tp(pscale(r['G1'][S], F(3, 16) * r['kap']), 1), -1) for S in EVEN) for r in rows) and any(any(sum(k_[:N]) == 1 for k_ in r['diff1'][S]) for r in rows for S in EVEN),
        'the same as first-order jets on every draw: dL/dpsi_S(omega*) - dL/dpsi_S(omega_LC) = (3/16) kappa G_S to x-degree 1 (the x-linear coefficients are non-zero and tested)')
    c2, rank2, cons2 = fit1(colC, rhsC)
    chk('bit', cons2 and rank2 == 1 and c2 == F(3, 8), 'operator form, exact fit over the 1-jets of all draws (rank %d): Phi(omega*) - Phi(omega_LC) = c2 kappa (I s psi) J g0 vol with c2 = %s; predicted 3/8 = 2 c1' % (rank2, c2))
    chk('bit', all(r['C'] == -c1 for r in rows), 'c1 = -C on every draw: the cubic term of the Dirac equation is the psi-derivative of the contact term of the effective action L_D(omega_LC) - C kappa (s.s) vol')
    chk('ctl', any(d != 0 for d in rhs), 'closed form without the cubic term (EL(omega*) = EL(omega_LC)): fails off shell')
    chk('ctl', any(d != -F(3, 16) * g for d, g in zip(rhs, colG)), 'opposite sign of the cubic term: fails')
    chk('ctl', any(d != F(3, 8) * g for d, g in zip(rhs, colG)), 'contact coefficient doubled (L_eff with 3 kappa/8 in place of 3 kappa/16): fails')
    tick('fits')

    head('(2) [std] numpy: the Euler-Lagrange form of the textbook density with K* substituted, by numerical variation in chibar; [bit==std]')
    for k, r in enumerate(rows):
        e, psi, m, kap = r['e'], r['psi'], float(r['m']), r['kap']; x0 = np.zeros(N)
        ELn = std_EL(st, e, psi, m, kap); free, cub, chi, det = std_closed(st, e, psi, m, kap, x0)
        cs, res = lsq(ELn - free, cub); scl = float(np.linalg.norm(free))
        chk('std', res < 1e-6 and abs(cs / float(kap) - 0.375) < 1e-6 and float(np.linalg.norm(cub)) > 1e-3 * scl,
            'draw %d: [std] EL_std = (i Gamma^a nabla_a - m) chi + c A_d Gamma^d gamma5 chi with c/kappa = %.9f (residual %.1e); predicted 3/8' % (k, cs / float(kap), res))
        chk('ctl', float(np.linalg.norm(ELn - free)) > 1e-3 * scl, 'draw %d: [std] without the cubic term the residual is %.2g of |EL|' % (k, float(np.linalg.norm(ELn - free)) / scl))
        chk('ctl', float(np.linalg.norm(ELn - free + 0.375 * float(kap) * cub)) > 1e-3 * scl, 'draw %d: [std] the opposite sign of the cubic term fails (%.2g)' % (k, float(np.linalg.norm(ELn - free + 0.375 * float(kap) * cub)) / scl))
        ELw = std_EL(st, e, psi, m, kap, cub=-1.0); cw, resw = lsq(ELw - free, cub)
        chk('ctl', resw < 1e-6 and abs(cw / float(kap) + 0.375) < 1e-6, 'draw %d: [std] K* of the opposite sign gives c/kappa = %.6f: the sign of the cubic term follows the sign of the contorsion' % (k, cw / float(kap)))
        EL0 = std_EL(st, e, psi, m, kap, cub=0.0)
        chk('std', float(np.linalg.norm(EL0 - free)) < 1e-7 * scl, 'draw %d: [std] without the contorsion the numerical variation gives (i Gamma^a nabla_a - m) chi (rel %.1e)' % (k, float(np.linalg.norm(EL0 - free)) / scl))
        Ps = phi_forms(Gv, r['e1'], r['oms'], psi, r['m']); Pl = phi_forms(Gv, r['e1'], r['oml'], psi, r['m'])
        mv = lambda P: to_mat(st.BL, {S: top0(X) / r['vol0'] for S, X in P.items() if top0(X) != 0}) @ st.u
        cb, rb = lsq(ELn, mv(Ps)); cl, rl = lsq(free, mv(Pl))
        chk('bit==std', rb < 1e-7 and abs(cb - 1) < 1e-7 and rl < 1e-9 and abs(cl - 1) < 1e-9, 'draw %d: M(Phi(omega*)(0)/vol) u = EL_std (factor %.9f, rel %.1e); M(Phi(omega_LC)/vol) u = (i Gamma^a nabla_a - m) chi (factor %.9f, rel %.1e)' % (k, cb, rb, cl, rl))
        tick('std draw %d' % k)
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('E2S4-HD')

if __name__ == '__main__': main()
