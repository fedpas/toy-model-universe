#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F3-horizons.  F = nabla_a chi_b nabla^a chi^b = -2 kH^2 on the horizons of Reissner-Nordstrom, Schwarzschild-de Sitter and the fifth chip.   python3 f3_horizons.py

 Statement  On a Killing horizon (chi Killing, null on the surface and normal to it), with kH defined by nabla_chi chi = kH chi, the invariant F equals -2 kH^2.
            It is a kinematic identity (recalled textbook fact, Wald, General Relativity): it uses the Killing equation and the null normal, no field equation.
 Frames     RN: f2_first_law.kn_frame_jet with a = 0 (f = M/rho - s/rho^2), (M, s) = (3/2, 1), (2, 3/2), (5, 21/2) (horizons 2 and 1, 3 and 1, 7 and 3) and the
            extremal (1, 1/2), (3, 9/2).  SdS: b1lib.ks_frame_jet with sds_jets (f = M/rho + H2 rho^2/2), horizons rho1 < rho2 rational: H2 = 1/(rho1^2 + rho1 rho2 +
            rho2^2), M = H2 rho1 rho2 (rho1 + rho2)/2, members (1, 2), (2, 5) and the degenerate rho1 = rho2 = 3 (H2 = 1/27, M = 1); the frame equals
            h5l_frames.ks_frame_jetK (checked).  Fifth chip: f2_first_law.fifth_frame (T = (x-2)(x+1)/(x+3), chart (v, x, th, ph)), horizon x = 2.
            Exact 2-jets at rational points of the horizon spheres (four angles, the axis included) and at points off the horizons.
 [bit]      kH from nabla_chi chi = kH chi (A3 closed-form omega, Grav.D_vector, g2_kerr.engine_nabla_vv: F2's route; for RN also f2_first_law.horizon_numbers);
            F, the Killing residual, xi^2 and |d xi^2|^2 from f3_killing.wald_engine (nabla xi read from the engine's omega); then F == -2 kH^2.
 [std]      Christoffel route of g = e^T eta e: f3_killing.wald_std (nabla_m xi_n, F) and g2_kerr.std_nabla_vv (nabla_chi chi); closed forms derived for the static
            class T dv^2 -+ 2 dv dx - r^2 dOmega^2: kH = (1/2) T'(r_h) (RN: M/r^2 - 2s/r^3, recalled Boyer-Lindquist values of f2_first_law.family_closed;
            SdS: M/rho^2 - H2 rho for d_t with g_tt -> 1 - 2M/rho - H2 rho^2, no rescaling) and F = -(1/2) T'^2 at every point.
 Context    which frame each member is (field equations, not the identity): RN E_a = lambda T_a with one lambda = -4s/Q^2 (Q = 1, Maxwell stress of
            A = (Q/rho) l); SdS: the engine's mixed Einstein tensor equals the Christoffel one and is 3 H2 times the identity; the fifth chip: it is neither.
 [ctl]      off the horizons (F != -2 kH^2 for both kH of the member, nabla_xi xi not proportional to xi); omega -> -omega in F and kH; kH/2; the other horizon's
            kH; the transposed contraction nabla_a xi_b nabla^b xi^a; the SdS closed form with the sign of the H2 term flipped.
 Scope      points on the horizons and near them, n = 4; no area law, no temperature.
 Exports    horizon_data(Gv, S, e, xi, om_sign=1), std_data(e, xi), sds_member(rho1, rho2), sds_frame(p, rho0, M, H2), rn_frame(p, M, s, r0), T_static(kind, pars, r)"""
import sys, os, time
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from b1lib import *
import g2_kerr as K
import f3_killing as F3
from f2_first_law import kn_frame_jet, kn_potential, horizon_numbers, fifth_frame, family_closed, maxwell_stress_comp, prop, Du
import h5l_frames as H5

NV = 4; SQ = LORENTZ(4); T0 = time.time()
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
ANG = [((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))), ((F(5, 13), F(12, 13)), (F(3, 5), F(4, 5))), ((F(0), F(1)), (F(1), F(0))), ((F(1), F(0)), (F(1), F(0)))]
D_T = [const(NV, 1), {}, {}, {}]                                   # d_t (d_v on the fifth chip) as coordinate components

# ------------------------------------------------------------------------------------------------ members and closed forms
def sds_member(rho1, rho2):
    """SdS with rational horizons rho1 <= rho2 (third root -(rho1 + rho2)): (M, H2)"""
    rho1, rho2 = F(rho1), F(rho2); H2 = 1 / (rho1 ** 2 + rho1 * rho2 + rho2 ** 2); return H2 * rho1 * rho2 * (rho1 + rho2) / 2, H2
def T_static(kind, pars, r):
    """g_tt = T(r) and T'(r) of the static class (exact): RN T = 1 - 2M/r + 2s/r^2, SdS T = 1 - 2M/r - H2 r^2, fifth T = (x-2)(x+1)/(x+3)"""
    r = F(r)
    if kind == 'RN': M, s = pars; return 1 - 2 * M / r + 2 * s / r ** 2, 2 * M / r ** 2 - 4 * s / r ** 3
    if kind == 'SdS': M, H2 = pars; return 1 - 2 * M / r - H2 * r * r, 2 * M / r ** 2 - 2 * H2 * r
    Td = (Du(r, 1) - 2) * (Du(r, 1) + 1) / (Du(r, 1) + 3); return Td.v, Td.d
def rn_frame(p, M, s, r0):
    e, E, _, data = kn_frame_jet(p, M, 0, s, r0=r0); return e, E, data
def sds_frame(p, rho0, M, H2):
    rho0 = F(rho0); e, E, _ = ks_frame_jet([F(c) for c in p], rho0, *sds_jets(F(M), F(H2), rho0), nv=NV); return e, E

# ------------------------------------------------------------------------------------------------ the two routes at one point
def horizon_data(Gv, S, e, xi, om_sign=1):
    """[bit] at the origin of the jets: wald_engine's dict (nab, K, F, N, dN2, xa) and kH from nabla_xi xi = kH xi (None if not proportional); om_sign = -1: omega -> -omega in both"""
    e0, E0, det = E0_of(e, 4, 4); W = F3.wald_engine(Gv, e, E0, xi, S, om_sign=om_sign)
    om = omega_closed_form(Gv, e, S, NV, 0, sign=om_sign)[0]; ca, nab = K.engine_nabla_vv(Gv, om, e, xi)
    W['kH'] = prop(ca, nab); W['null'] = K.frame_norm_bit(ca, SQ); W['nabla_vv'] = nab
    W['nab_c'] = [[sum(e0[a][m] * e0[b][n] * W['nab'][a][b] for a in range(NV) for b in range(NV)) for n in range(NV)] for m in range(NV)]
    W['FT'] = sum(SQ[a] * SQ[b] * W['nab'][a][b] * W['nab'][b][a] for a in range(NV) for b in range(NV))
    return W
def std_data(e, xi):
    """[std] Christoffel route: wald_std's dict plus kH from (nabla_xi xi)^mu = kH xi^mu in coordinates"""
    Z = F3.wald_std(e, xi); g = std_metric(e, 4, SQ, 4, 2); ns = K.std_nabla_vv(g, xi); Z['kH'] = prop([at0(q, NV) for q in xi], ns); return Z

CT = {}
def ctl(name, wrong): k = CT.setdefault(name, [0, 0]); k[1] += 1; k[0] += int(bool(wrong))
CTL_NAMES = ['kH/2 in place of kH', 'the transposed contraction nabla_a xi_b nabla^b xi^a in place of F',
             'omega -> -omega (d kept) in F and kH: F = -2 kH^2 fails at the non-degenerate horizon points', 'the other horizon\'s kH of the same member in place of kH',
             'omega -> -omega (d kept) at the degenerate points (kH = 0, nabla xi = 0): the flipped F is not -2 kH^2',
             'off the horizons: F differs from -2 kH^2 for every kH of the member, and nabla_xi xi is not proportional to xi (no kH there)',
             'SdS closed form with the sign of the H2 term flipped (M/rho^2 + H2 rho) against the engine\'s kH']     # registered first: a control that is never reached prints as a failure

def run_horizon(Gv, S, tag, frames, kH_closed, Tp, other_kH=None, f2_kH=None):
    """frames: list of (label, e) at the points of one horizon; kH_closed = (1/2) T'(r_h) (signed, advanced chart); Tp = T'(r_h)"""
    ks, Fs, ok_k, ok_bs, ok_std, ok_null, ok_K, ok_w = set(), set(), True, True, True, True, True, True; degenerate = kH_closed == 0; zero_nab = True
    for lab, e in frames:
        W = horizon_data(Gv, S, e, D_T); Z = std_data(e, D_T)
        ks.add(W['kH']); Fs.add(W['F'])
        ok_null &= W['null'] == 0 and W['N'] == 0; ok_K &= all(x == 0 for row in W['K'] for x in row); ok_w &= W['dN2'] == 0 == 2 * W['N'] * W['F']
        ok_k &= W['kH'] is not None and W['F'] == -2 * W['kH'] ** 2
        ok_std &= Z['kH'] is not None and Z['F'] == -2 * Z['kH'] ** 2 and Z['kH'] == kH_closed and Z['F'] == -Tp * Tp / 2
        ok_bs &= W['nab_c'] == Z['nab'] and W['F'] == Z['F'] and W['kH'] == Z['kH']
        zero_nab &= all(x == 0 for row in W['nab'] for x in row)
        if W['kH'] is not None and W['kH'] != 0:
            ctl('kH/2 in place of kH', W['F'] != -2 * (W['kH'] / 2) ** 2)
            ctl('the transposed contraction nabla_a xi_b nabla^b xi^a in place of F', W['FT'] != -2 * W['kH'] ** 2)
            Wm = horizon_data(Gv, S, e, D_T, om_sign=-1)
            ctl('omega -> -omega (d kept) in F and kH: F = -2 kH^2 fails at the non-degenerate horizon points', Wm['kH'] is None or Wm['F'] != -2 * Wm['kH'] ** 2)
            if other_kH is not None: ctl('the other horizon\'s kH of the same member in place of kH', W['F'] != -2 * other_kH ** 2)
        else:
            Wm = horizon_data(Gv, S, e, D_T, om_sign=-1)
            ctl('omega -> -omega (d kept) at the degenerate points (kH = 0, nabla xi = 0): the flipped F is not -2 kH^2', Wm['kH'] is None or Wm['F'] != -2 * Wm['kH'] ** 2)
            print('    %s, %s: omega -> -omega at a degenerate point: kH = %s, F = %s' % (tag, lab, Wm['kH'], Wm['F']))
    kH = next(iter(ks)) if len(ks) == 1 else None
    chk('bit', ok_null and ok_K and ok_w and kH is not None and ok_k, '%s: at %d points chi = d_t is null, Killing (nabla_(a xi_b) = 0 exactly), |d xi^2|^2 = 0 = 2 xi^2 F; ONE kH = %s and F = %s = -2 kH^2' % (
        tag, len(frames), kH, ', '.join(sorted(str(x) for x in Fs))))
    if f2_kH is not None: chk('bit', f2_kH == {kH}, '%s: f2_first_law.horizon_numbers (F2\'s bookkeeping) gives the same kH = %s' % (tag, ', '.join(str(x) for x in f2_kH)))
    chk('bit==std', ok_bs and ok_std, '%s: nabla_m xi_n (engine omega) = Christoffel route (16 entries), F and kH equal on both routes; [std] kH = (1/2) T\'(r_h) = %s (closed form), F = -(1/2) T\'^2 = %s = -2 kH^2' % (
        tag, kH_closed, -Tp * Tp / 2))
    if degenerate:
        chk('bit', kH == 0 and Fs == {0} and zero_nab, '%s (degenerate, T\'(r_h) = 0): kH = 0 and F = 0 at every point, because nabla_a xi_b = 0 there (all 16 frame components): the identity holds as 0 = 0' % tag)
    return kH

def run_off(Gv, S, tag, frames, kHs, Tps):
    """off the horizon: F = -(1/2) T'^2 on both routes, F != -2 kH^2 for each horizon kH of the member, nabla_xi xi not proportional to xi"""
    ok = True
    for (lab, e), Tp in zip(frames, Tps):
        W = horizon_data(Gv, S, e, D_T); Z = std_data(e, D_T)
        ok &= W['F'] == Z['F'] == -Tp * Tp / 2 and W['N'] != 0
        ctl('off the horizons: F differs from -2 kH^2 for every kH of the member, and nabla_xi xi is not proportional to xi (no kH there)', all(W['F'] != -2 * k * k for k in kHs) and W['kH'] is None)
        print('    %s, %s: xi^2 = %s, F = %s (horizon values -2 kH^2: %s)' % (tag, lab, W['N'], W['F'], ', '.join(str(-2 * k * k) for k in kHs)))
    chk('bit==std', ok, '%s off the horizons (%d points): F (engine omega) = F (Christoffel) = -(1/2) T\'(r)^2 (closed form) with xi^2 != 0' % (tag, len(frames)))

# ------------------------------------------------------------------------------------------------ the run
def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # per run (an engine fault put into Lie in memory is seen)
    CT.clear(); [CT.setdefault(n, [0, 0]) for n in CTL_NAMES]
    head('1. Reissner-Nordstrom (Kerr-Newman frame with a = 0): outer, inner and extremal horizons')
    RN = [(F(3, 2), F(1), (F(2), F(1))), (F(2), F(3, 2), (F(3), F(1))), (F(5), F(21, 2), (F(7), F(3)))]
    for M, s, (rp, rm) in RN:
        kc = {}
        for rh in (rp, rm):
            T, Tp = T_static('RN', (M, s), rh); assert T == 0
            cf = family_closed(4 * s, M, 0, 1, (0, 0, 0), 1 if rh == rp else -1); kc[rh] = (Tp / 2, cf['kH'].v)
        chk('std', all(a == b for a, b in kc.values()), 'RN (M, s) = (%s, %s): (1/2) T\'(r_h) = %s and %s equal the recalled Boyer-Lindquist kH of family_closed (kappa = 4s, Q = 1)' % (M, s, kc[rp][0], kc[rm][0]))
        for rh, other in ((rp, rm), (rm, rp)):
            frames = [('cos th = %s' % P['cth'], rn_frame(P['p'], M, s, rh)[0]) for P in K.rational_kerr_points(0, [rh], ANG)]
            hn = horizon_numbers(Gv, S, M, 0, s, rh, ANG[:2], std=False)
            run_horizon(Gv, S, 'RN (M, s) = (%s, %s), %s horizon r = %s' % (M, s, 'outer' if rh == rp else 'inner', rh), frames, kc[rh][0], T_static('RN', (M, s), rh)[1], other_kH=kc[other][0], f2_kH=hn['kH'])
        offs = [F(3) * rp / 2, (rp + rm) / 2]
        run_off(Gv, S, 'RN (M, s) = (%s, %s)' % (M, s), [('r = %s' % P['r'], rn_frame(P['p'], M, s, P['r'])[0]) for P in K.rational_kerr_points(0, offs, ANG[:1])], [kc[rp][0], kc[rm][0]], [T_static('RN', (M, s), r)[1] for r in offs])
    for M, s in ((F(1), F(1, 2)), (F(3), F(9, 2))):
        T, Tp = T_static('RN', (M, s), M); assert T == 0 and Tp == 0
        frames = [('cos th = %s' % P['cth'], rn_frame(P['p'], M, s, M)[0]) for P in K.rational_kerr_points(0, [M], ANG)]
        hn = horizon_numbers(Gv, S, M, 0, s, M, ANG[:2], std=False)
        run_horizon(Gv, S, 'extremal RN (M, s) = (%s, %s), r = %s' % (M, s, M), frames, F(0), Tp, f2_kH=hn['kH'])
    head('   context: E_a = lambda T_a with one lambda = -4 s/Q^2 (Q = 1, A = (Q/rho) l, Maxwell stress), one point of each member (field equations, not the identity)')
    okc = True; lams = []
    for M, s, rh in [(m, s_, r[0]) for m, s_, r in RN] + [(F(1), F(1, 2), F(1)), (F(3), F(9, 2), F(3))]:
        P = K.rational_kerr_points(0, [rh], ANG[:1])[0]; e, E, data = rn_frame(P['p'], M, s, rh)
        om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0); cT, _ = maxwell_stress_comp(Gv, e, E, kn_potential(1, data))
        k0 = next((k for k in sorted(cT) if cT[k] != 0), None); lam = comp[k0] / cT[k0] if k0 is not None else None
        okc &= lam == -4 * s and all(comp[k] == lam * cT[k] for k in comp) and any(comp.values()); lams.append(lam)
    chk('bit', okc, 'RN members (5, at an outer or extremal horizon point): E_a = lambda T_a on all 16 components with lambda = %s = -4 s/Q^2' % ', '.join(map(str, lams)))
    tick('part 1')

    head('2. Schwarzschild-de Sitter: black-hole and cosmological horizons, and a degenerate one (rho1 = rho2)')
    ok_fr = True; nfr = 0
    for (r1, r2) in ((1, 2), (2, 5), (3, 3)):
        M, H2 = sds_member(r1, r2)
        for P in K.rational_kerr_points(0, [F(r1), F(r2)], ANG[:2]):
            e, E = sds_frame(P['p'], P['r'], M, H2); eK = H5.ks_frame_jetK(P['p'], P['r'], M=M, H2=H2, order=2)
            cl = lambda X: {m: {k: v for k, v in q.items() if v != 0} for m, q in X.items() if any(v != 0 for v in q.values())}
            ok_fr &= all(cl(e[a]) == cl(eK[a]) for a in range(4)); nfr += 1
    chk('bit', ok_fr, 'frame builders: b1lib.ks_frame_jet with sds_jets equals h5l_frames.ks_frame_jetK (order 2), every jet coefficient of e, %d points' % nfr)
    for (r1, r2) in ((1, 2), (2, 5)):
        M, H2 = sds_member(r1, r2); kc = {}
        for rh in (F(r1), F(r2)):
            T, Tp = T_static('SdS', (M, H2), rh); assert T == 0; kc[rh] = Tp / 2
        r1, r2 = F(r1), F(r2)
        cl1 = (H2 / (2 * r1)) * (r2 - r1) * (2 * r1 + r2); cl2 = -(H2 / (2 * r2)) * (r2 - r1) * (r1 + 2 * r2)
        chk('std', (kc[r1], kc[r2]) == (cl1, cl2) and cl1 == M / r1 ** 2 - H2 * r1, 'SdS (M, H2) = (%s, %s): horizons %s and %s; kH = (1/2) T\' = M/rho^2 - H2 rho = %s and %s (derived closed form: (H2/2 rho1)(rho2 - rho1)(2 rho1 + rho2) and minus (H2/2 rho2)(rho2 - rho1)(rho1 + 2 rho2))' % (M, H2, r1, r2, cl1, cl2))
        wrongk = {rh: M / rh ** 2 + H2 * rh for rh in (r1, r2)}
        for rh, other in ((r1, r2), (r2, r1)):
            frames = [('cos th = %s' % P['cth'], sds_frame(P['p'], rh, M, H2)[0]) for P in K.rational_kerr_points(0, [rh], ANG)]
            kH = run_horizon(Gv, S, 'SdS (rho1, rho2) = (%s, %s), %s horizon rho = %s' % (r1, r2, 'black-hole' if rh == r1 else 'cosmological', rh), frames, kc[rh], T_static('SdS', (M, H2), rh)[1], other_kH=kc[other])
            ctl('SdS closed form with the sign of the H2 term flipped (M/rho^2 + H2 rho) against the engine\'s kH', kH is None or wrongk[rh] != kH)
        offs = [(r1 + r2) / 2, r1 / 2, 2 * r2]
        run_off(Gv, S, 'SdS (rho1, rho2) = (%s, %s)' % (r1, r2), [('rho = %s' % P['r'], sds_frame(P['p'], P['r'], M, H2)[0]) for P in K.rational_kerr_points(0, offs, ANG[1:2])], [kc[r1], kc[r2]], [T_static('SdS', (M, H2), r)[1] for r in offs])
    M, H2 = sds_member(3, 3); T, Tp = T_static('SdS', (M, H2), 3); assert T == 0 and Tp == 0 and (M, H2) == (1, F(1, 27))
    run_horizon(Gv, S, 'degenerate SdS (M, H2) = (1, 1/27), double root rho = 3', [('cos th = %s' % P['cth'], sds_frame(P['p'], 3, M, H2)[0]) for P in K.rational_kerr_points(0, [3], ANG)], F(0), Tp)
    head('   context: the engine\'s mixed Einstein tensor on the SdS frames (one horizon point of each member) equals the Christoffel route and is 3 H2 times the identity')
    okG = True; vals = []
    for (r1, r2) in ((1, 2), (2, 5), (3, 3)):
        M, H2 = sds_member(r1, r2); P = K.rational_kerr_points(0, [F(r1)], ANG[:1])[0]; e, E = sds_frame(P['p'], P['r'], M, H2)
        om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0); e0, E0, det = E0_of(e, 4, 4); Gfr = mixed_from_components(comp, e0, det, 4, -1)
        g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, 4); Gfs = to_frame_mixed(Gm, e0, E0, 4)
        okG &= Gfr == Gfs and all(Gfr[b][a] == (3 * H2 if a == b else 0) for a in range(4) for b in range(4)); vals.append(Gfr[0][0])
    chk('bit==std', okG, 'SdS members (1, 2), (2, 5), (3, 3): G^b_a (engine) = G^b_a (Christoffel) = 3 H2 delta^b_a with 3 H2 = %s: the frames are vacua with a cosmological term' % ', '.join(map(str, vals)))
    tick('part 2')

    head('3. the fifth chip T = (x-2)(x+1)/(x+3), areal radius x^2, retarded chart: it solves no field equation of the Atlas with a stated source')
    T, Tp = T_static('fifth', None, 2); assert T == 0 and Tp == F(3, 5)
    e, Tj = fifth_frame(F(2)); W = horizon_data(Gv, S, e, D_T); Z = std_data(e, D_T)
    chk('bit', W['null'] == 0 and W['N'] == 0 and all(x == 0 for row in W['K'] for x in row) and W['kH'] == F(-3, 10) and W['F'] == -2 * W['kH'] ** 2 == F(-9, 50),
        'x = 2: chi = d_v null and Killing (nabla_(a xi_b) = 0 exactly); nabla_chi chi = %s chi (the retarded-chart sign of kH = 3/10); F = %s = -2 kH^2' % (W['kH'], W['F']))
    chk('bit==std', W['nab_c'] == Z['nab'] and W['F'] == Z['F'] and W['kH'] == Z['kH'] == -Tp / 2 and Z['F'] == -Tp * Tp / 2,
        'x = 2: nabla_m xi_n (engine omega) = Christoffel route (16 entries); F = -(1/2) T\'(2)^2 = %s and kH = -(1/2) T\'(2) = %s on both routes (T\'(2) = 3/5)' % (Z['F'], Z['kH']))
    if W['kH'] is not None: ctl('kH/2 in place of kH', W['F'] != -2 * (W['kH'] / 2) ** 2); ctl('the transposed contraction nabla_a xi_b nabla^b xi^a in place of F', W['FT'] != -2 * W['kH'] ** 2)
    Wm = horizon_data(Gv, S, e, D_T, om_sign=-1); ctl('omega -> -omega (d kept) in F and kH: F = -2 kH^2 fails at the non-degenerate horizon points', Wm['kH'] is None or Wm['F'] != -2 * Wm['kH'] ** 2)
    om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0); e0, E0, det = E0_of(e, 4, 4); Gfr = mixed_from_components(comp, e0, det, 4, -1)
    g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1); Gm, ric, Rs = std_einstein_mixed(R1, g0, g0i, 4); Gfs = to_frame_mixed(Gm, e0, E0, 4)
    diag = [Gfr[a][a] for a in range(4)]
    chk('bit==std', Gfr == Gfs and len(set(diag)) > 1, 'context, x = 2: G^b_a (engine) = Christoffel route and its diagonal %s is not a multiple of the identity: no vacuum and no cosmological term; the identity above used none' % ', '.join(map(str, diag)))
    offs = [F(3), F(1)]; fr = [('x = %s' % x0, fifth_frame(x0)[0]) for x0 in offs]
    run_off(Gv, S, 'fifth chip', fr, [F(3, 10)], [T_static('fifth', None, x0)[1] for x0 in offs])
    tick('part 3')

    head('controls (a wrong version must fail on every sample where it can be seen)')
    for name, (dif, seen) in CT.items(): chk('ctl', dif == seen and seen > 0, '%s: fails on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F3-horizons')

if __name__ == '__main__': main()
