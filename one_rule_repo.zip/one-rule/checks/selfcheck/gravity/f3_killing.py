#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F3.  Killing vectors on the bit-rule frames (static Schwarzschild and Schwarzschild-de Sitter) and Wald's identity of T18(c) from the solved omega.   python3 f3_killing.py

 Frames: radial Kerr-Schild class e^a = dx^a - f l^a l (b1lib.ks_frame_jet): exact 2-jets in delta = x - p at rational points p (|p| rational), coordinates (t, x, y, z), t = 0 at p.
 L_xi e (g2_forms_calc.lie: the engine's d and the bit-rule interior) with xi of degree <= 1: exact to degree 1 in delta; only degrees 0 and 1 are compared.
 Killing:  L_xi e^a = lam^a_b e^b, lam = (L_xi e) E, lam_ab = sq_a lam^a_b antisymmetric  <=>  L_xi g = 0.   [std] L_xi g from the metric components (plain polynomials).
 Wald (T18(c)):  g^{-1}(d xi^2, d xi^2) = 2 xi^2 F,  F = nabla_a xi_b nabla^a xi^b, for a hypersurface-orthogonal Killing field.  [bit] nabla xi from D xi^a = d xi^a + h om xi with the
 A3 closed-form omega (value at p);  [std] Christoffel symbols of g = e^T eta e.  Frame jets are arguments: any frame given as 1-jets (Wald) or 2-jets (L_xi e to first order) plugs in."""
import sys, os, time, itertools
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from b1lib import *
import g2_forms_calc as FC
from g2_forms_calc import lie, frame_comps, interior

T0 = time.time(); NV = 4; SQ = LORENTZ(4)
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
def tdeg(p, d): return {k: v for k, v in p.items() if sum(k) <= d}
def cpoly(c): return {(0,) * NV: F(c)} if c != 0 else {}
def dvar(i): return {tuple(1 if j == i else 0 for j in range(NV)): F(1)}
def lin1(p, i): return p.get(tuple(1 if j == i else 0 for j in range(NV)), F(0))       # d_i of p at delta = 0
def coordp(p, i): return dvar(0) if i == 0 else padd(cpoly(p[i - 1]), dvar(i))         # the coordinate x^i as a polynomial in delta (t = 0 at p)
def neg(q): return {k: -v for k, v in q.items()}
def vsum(*terms):
    out = [{} for _ in range(NV)]
    for c, v in terms: out = [padd(out[m], v[m], c) for m in range(NV)]
    return out
def fields(p):
    X = [coordp(p, i) for i in range(NV)]
    return {'d_t': [cpoly(1), {}, {}, {}], 'rot_z': [{}, neg(X[2]), X[1], {}], 'rot_x': [{}, {}, neg(X[3]), X[2]], 'rot_y': [{}, X[3], {}, neg(X[1])],
            'boost_x': [X[1], X[0], {}, {}], 'dilation': [X[0], X[1], X[2], X[3]]}

# ------------------------------------------------------------------------------------------------ engine route
def lie_frame(Gv, e, E, xi, deg=1):
    """[bit] L_xi e^a (forms truncated at degree deg) and lam^a_b = (L_xi e^a)_mu E^mu_b (degree <= deg); E = inverse-frame jets E[mu][a]"""
    Le = [{m: tdeg(q, deg) for m, q in lie(Gv, xi, e[a]).items() if tdeg(q, deg)} for a in range(NV)]
    lam = [[{} for _ in range(NV)] for _ in range(NV)]
    for a in range(NV):
        for b in range(NV):
            t = {}
            for mu in range(NV):
                q = Le[a].get(1 << mu, {})
                if q and E[mu][b]: t = padd(t, sp_mul(q, E[mu][b], deg, NV))
            lam[a][b] = t
    return Le, lam
def lam_sym(lam): return [[padd(scale(lam[a][b], SQ[a]), scale(lam[b][a], SQ[b])) for b in range(NV)] for a in range(NV)]
def all_zero(M): return all(not q for row in M for q in row)
def wald_engine(Gv, e, E0, xi, S, om_sign=1):
    """[bit] nabla_b xi_a = sq_a (D xi^a)_b at p (om: A3 closed form, value at p, times om_sign), Killing residual K_ab, F, xi^2, |d xi^2|^2 (frame contractions with sq)"""
    om = omega_closed_form(Gv, e, S, NV, 0, sign=om_sign)[0]; Fm = Gv.Fm
    xa = frame_comps(Gv, xi, e); Dx = Gv.D_vector(om, [{0: q} if q else {} for q in xa])
    nab = [[sum((at0(Dx[a].get(1 << mu, {}), NV) * E0[mu][b] for mu in range(NV)), F(0)) * SQ[a] for a in range(NV)] for b in range(NV)]   # nab[b][a] = nabla_b xi_a
    K = [[nab[a][b] + nab[b][a] for b in range(NV)] for a in range(NV)]
    Fv = sum(SQ[a] * SQ[b] * nab[a][b] ** 2 for a in range(NV) for b in range(NV))
    N = {}
    for a in range(NV): N = padd(N, sp_mul(xa[a], xa[a], 1, NV), SQ[a])
    dN = Fm.d({0: N}); dNa = [sum((at0(dN.get(1 << mu, {}), NV) * E0[mu][a] for mu in range(NV)), F(0)) for a in range(NV)]
    return dict(nab=nab, K=K, F=Fv, N=at0(N, NV), dN2=sum(SQ[a] * dNa[a] ** 2 for a in range(NV)), xa=[at0(q, NV) for q in xa])

# ------------------------------------------------------------------------------------------------ [std] metric route (plain polynomials, no engine)
def lie_g_std(g, xi, deg=1):
    """(L_xi g)_mn = xi^r d_r g_mn + g_rn d_m xi^r + g_mr d_n xi^r, truncated at degree deg"""
    out = {}
    for m in range(NV):
        for n in range(NV):
            t = {}
            for r in range(NV):
                t = FC._add(t, FC._mul(xi[r], FC._der(g[(m, n)], r))); t = FC._add(t, FC._mul(g[(r, n)], FC._der(xi[r], m))); t = FC._add(t, FC._mul(g[(m, r)], FC._der(xi[r], n)))
            out[(m, n)] = tdeg(t, deg)
    return out
def wald_std(e, xi):
    """[std] Christoffel route at p: nabla_m xi_n = d_m xi_n - Gamma^l_mn xi_l, Killing residual, F = g^ma g^nb nabla_m xi_n nabla_a xi_b, xi^2, g^mn d_m xi^2 d_n xi^2"""
    g = std_metric(e, NV, SQ, NV, deg=2); g0 = [[at0(g[(m, n)], NV) for n in range(NV)] for m in range(NV)]; det, gi = det_inv(g0)
    dg = [[[lin1(g[(a, b)], k) for b in range(NV)] for a in range(NV)] for k in range(NV)]
    Gam = [[[sum(gi[l][s] * (dg[m][s][n] + dg[n][s][m] - dg[s][m][n]) for s in range(NV)) / 2 for n in range(NV)] for m in range(NV)] for l in range(NV)]
    xl = [tdeg(sum_poly([FC._mul(g[(n, m)], xi[m]) for m in range(NV)]), 1) for n in range(NV)]
    nab = [[lin1(xl[n], m) - sum(Gam[l][m][n] * at0(xl[l], NV) for l in range(NV)) for n in range(NV)] for m in range(NV)]
    K = [[nab[m][n] + nab[n][m] for n in range(NV)] for m in range(NV)]
    Fv = sum(gi[m][a] * gi[n][b] * nab[m][n] * nab[a][b] for m in range(NV) for n in range(NV) for a in range(NV) for b in range(NV))
    N = tdeg(sum_poly([FC._mul(xi[m], xl[m]) for m in range(NV)]), 1); dN = [lin1(N, m) for m in range(NV)]
    return dict(nab=nab, K=K, F=Fv, N=at0(N, NV), dN2=sum(gi[m][n] * dN[m] * dN[n] for m in range(NV) for n in range(NV)), g0=g0)
def sum_poly(ps):
    t = {}
    for q in ps: t = FC._add(t, q)
    return t

# ------------------------------------------------------------------------------------------------ checks
CTL = {}
def ctl(key, wrong_fails):
    k = CTL.setdefault(key, [0, 0]); k[1] += 1; k[0] += int(bool(wrong_fails))
def frame_at(p, rho0, jets, fextra=None):
    e, E, _ = ks_frame_jet(p, rho0, *jets, nv=NV, fextra=fextra)
    return e, E, [[at0(E[mu][a], NV) for a in range(NV)] for mu in range(NV)], [[at0(e[a].get(1 << mu, {}), NV) for mu in range(NV)] for a in range(NV)]
def run_point(Gv, S, name, M, H2, rho0, u, wald=True):
    p = [rho0 * x for x in u]; jets = sds_jets(F(M), F(H2), F(rho0)); e, E, E0, e0 = frame_at(p, rho0, jets); V = fields(p)
    g = std_metric(e, NV, SQ, NV, deg=2); g00 = 1 - 2 * jets[0]
    tag = '%s M=%s H2=%s rho0=%s p=(%s)' % (name, M, H2, rho0, ', '.join(str(x) for x in p))
    head('%s   [g_tt = 1 - 2f = %s: %s]' % (tag, g00, 'static region' if g00 > 0 else ('horizon' if g00 == 0 else 'xi = d_t spacelike (inside a horizon)')))
    Le, lam = lie_frame(Gv, e, E, V['d_t'])
    chk('bit', all(not x for x in Le), '%s: L_xi e^a = 0 for xi = d_t (value and first derivatives at p)' % tag)
    for rn in ('rot_z', 'rot_x', 'rot_y'):
        xi = V[rn]; Le, lam = lie_frame(Gv, e, E, xi); Lam = [[lin1(xi[a], b) for b in range(NV)] for a in range(NV)]           # [std] L_xi dx^a = d xi^a = Lam^a_b dx^b
        cons = all(form_eq_deg(Le[a], sum_forms([(lam[a][b], e[b]) for b in range(NV)]), 1) for a in range(NV))
        const_ok = all(set(lam[a][b]) <= {(0,) * NV} for a in range(NV) for b in range(NV)) and all(at0(lam[a][b], NV) == Lam[a][b] for a in range(NV) for b in range(NV))
        chk('bit', all_zero(lam_sym(lam)) and cons and any(lam[a][b] for a in range(NV) for b in range(NV)), '%s: %s: L_xi e^a = lam^a_b e^b with lam_ab + lam_ba = 0 to first order (L_xi g = 0)' % (tag, rn))
        chk('bit==std', const_ok and all(not q for q in lie_g_std(g, xi).values()), '%s: %s: lam is constant and equals the textbook rotation generator d_b xi^a; [std] L_xi g = 0 from the metric components to first order' % (tag, rn))
    for bn in ('boost_x', 'dilation'):
        xi = V[bn]; Le, lam = lie_frame(Gv, e, E, xi); Lg = lie_g_std(g, xi); sy = lam_sym(lam)
        pred = [[sum((at0(sy[a][b], NV) * e0[a][m] * e0[b][n] for a in range(NV) for b in range(NV)), F(0)) for n in range(NV)] for m in range(NV)]
        ctl(('%s is not Killing: lam not antisymmetric' % bn,), not all_zero(sy))
        chk('bit==std', all(pred[m][n] == at0(Lg[(m, n)], NV) for m in range(NV) for n in range(NV)) and any(pred[m][n] for m in range(NV) for n in range(NV)), '%s: %s (not Killing): (lam_ab + lam_ba) e^a_m e^b_n equals the [std] (L_xi g)_mn at p, not zero' % (tag, bn))
    et, Et, _, _ = frame_at(p, rho0, jets, fextra={(1, 0, 0, 0): F(M) / (7 * rho0)})
    ctl(('d_t on a frame with a time-dependent mass M(1 + t/7)',), any(lie_frame(Gv, et, Et, V['d_t'])[0]))
    if not wald: return
    for kn in ('d_t', 'rot_z'):
        xi = V[kn]; W = wald_engine(Gv, e, E0, xi, S); Z = wald_std(e, xi)
        chk('bit', all(x == 0 for row in W['K'] for x in row) and any(x for row in W['nab'] for x in row), '%s: %s: Killing equation nabla_(a xi_b) = 0 exactly at p, nabla xi from D xi^a = d xi^a + h om xi with the A3 closed-form omega' % (tag, kn))
        chk('bit', W['dN2'] == 2 * W['N'] * W['F'], '%s: %s: Wald T18(c): g^-1(d xi^2, d xi^2) = %s = 2 xi^2 F = 2 (%s)(%s)%s' % (tag, kn, W['dN2'], W['N'], W['F'], ' (on the horizon: both sides 0, the level set xi^2 = 0 is null)' if W['N'] == 0 else ''))
        nab_c = [[sum(e0[a][m] * e0[b][n] * W['nab'][a][b] for a in range(NV) for b in range(NV)) for n in range(NV)] for m in range(NV)]
        chk('bit==std', nab_c == Z['nab'] and all(x == 0 for row in Z['K'] for x in row) and (Z['F'], Z['N'], Z['dN2']) == (W['F'], W['N'], W['dN2']), '%s: %s: e^a_m e^b_n nabla_a xi_b (engine omega) = nabla_m xi_n (Christoffel), all 16 entries; F, xi^2, |d xi^2|^2 equal on both routes' % (tag, kn))
        Wm = wald_engine(Gv, e, E0, xi, S, om_sign=-1)
        ctl(('omega -> -omega (d kept): Killing equation fails',), any(x != 0 for row in Wm['K'] for x in row))
        if W['N'] != 0:
            FT = sum(SQ[a] * SQ[b] * W['nab'][a][b] * W['nab'][b][a] for a in range(NV) for b in range(NV)); FE = sum(W['nab'][a][b] ** 2 for a in range(NV) for b in range(NV))
            ctl(('F with the transposed contraction nabla_a xi_b nabla^b xi^a',), W['dN2'] != 2 * W['N'] * FT); ctl(('F with the Euclidean contraction (no eta)',), W['dN2'] != 2 * W['N'] * FE)
        jw = sds_jets(F(M) + F(1, 5), F(H2), F(rho0)); ew, Ew, E0w, _ = frame_at(p, rho0, jw); Ww = wald_engine(Gv, ew, E0w, xi, S)
        ctl(('xi^2 from a wrong M (M + 1/5) in one place',), Ww['dN2'] != 2 * Ww['N'] * W['F'])
    for bn in ('boost_x', 'dilation'):
        W = wald_engine(Gv, e, E0, V[bn], S); ctl(('%s: Killing equation through omega fails' % bn,), any(x != 0 for row in W['K'] for x in row))
    xi = vsum((1, V['d_t']), (F(1, 3), V['rot_z'])); W = wald_engine(Gv, e, E0, xi, S); Z = wald_std(e, xi)
    chk('bit', all(x == 0 for row in W['K'] for x in row) and all(x == 0 for row in Z['K'] for x in row), '%s: d_t + (1/3)(x d_y - y d_x) is Killing (engine and Christoffel)' % tag)
    ctl(('Killing but not hypersurface-orthogonal (d_t + rot_z/3): Wald\'s identity fails',), W['dN2'] != 2 * W['N'] * W['F'])
def form_eq_deg(X, Y, d):
    return all(tdeg(X.get(k, {}), d) == tdeg(Y.get(k, {}), d) for k in set(X) | set(Y))
def sum_forms(terms):
    out = {}
    for q, X in terms:
        for m, x in X.items():
            if q and x: out[m] = padd(out.get(m, {}), sp_mul(q, x, 1, NV))
    return {m: x for m, x in out.items() if x}

def main():
    Gv = Grav(4, Lie(SQ)); S = koszul_S(4, SQ, Gv.L); u1 = (F(1, 3), F(2, 3), F(2, 3)); u2 = (F(2, 7), F(3, 7), F(6, 7))
    for rho0, u in ((F(3), u1), (F(5, 2), u2), (F(2), u1), (F(3, 2), u2)): run_point(Gv, S, 'Schwarzschild', 1, 0, rho0, u)
    tick('Schwarzschild')
    for rho0, u in ((F(1), u2), (F(3), u1), (F(9), u2)): run_point(Gv, S, 'SdS', 1, F(1, 50), rho0, u)
    tick('SdS')
    head('kinematic: Wald\'s identity does not test the field equations (f = M/rho + rho/5 is not a solution)')
    rho0 = F(3); p = [rho0 * x for x in u1]; jets = (F(1) / rho0 + rho0 / 5, -F(1) / rho0 ** 2 + F(1, 5), 2 / rho0 ** 3); e, E, E0, e0 = frame_at(p, rho0, jets)
    W = wald_engine(Gv, e, E0, fields(p)['d_t'], S)
    chk('bit', all(x == 0 for row in W['K'] for x in row) and W['dN2'] == 2 * W['N'] * W['F'], 'f = M/rho + rho/5 (not Schwarzschild, not SdS) at rho0 = 3: d_t Killing and Wald\'s identity hold as well (%s = 2 (%s)(%s))' % (W['dN2'], W['N'], W['F']))
    head('controls (a wrong version must fail on every sample where it can be seen)')
    for (name,), (dif, seen) in CTL.items(): chk('ctl', dif == seen and seen > 0, '%s: the wrong version fails on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F3')
if __name__ == '__main__': main()
