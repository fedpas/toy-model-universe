#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""F3-Kerr.  Killing fields on the Kerr-Schild frame and Wald's identity with its twist term, nabla xi read from the engine's omega.   python3 f3_kerr.py

 Frame   C2's Kerr-Schild coframe (g2_kerr.kerr_ks_frame_jet), M = 5, a = 3, exact 2-jets at rational points: r = 9 (outer horizon), 20, 7 (outside), 4 (between), 1 (inner
         horizon), 1/2 (inside r-), off and on the axis.  Vector fields from f3_killing.fields (d_t, rot_z = x d_y - y d_x, boost_x, dilation); chi = d_t + Omega rot_z.
 Killing L_xi e^a = lam^a_b e^b, lam = (L_xi e) E, lam_ab + lam_ba = 0 (f3_killing.lie_frame: engine d, bit-rule interior); [std] L_xi g from the metric components.
         nabla_(a xi_b) = 0 with nabla xi = D xi^a = d xi^a + h om xi (A3 closed-form omega at the point, f3_killing.wald_engine); [std] Christoffel route (wald_std).
 Wald    D = g^-1(d xi^2, d xi^2) - 2 xi^2 F, F = nabla_a xi_b nabla^a xi^b.  Twist w_a = eps_abcd xi^b nabla^c xi^d (frame, eps_0123 = +1), w.w = eta^ab w_a w_b;
         [std] the same in coordinates, eps_mnrs = sqrt(-g) [mnrs] (w.w carries the factor -det g, so no square root is taken).  The defect D is FITTED against
         w.w and w.w/xi^2 from two points and checked at every point.  Horizon: F = -2 kH^2 for chi (both horizons, a = 0 limit, a second member).
 [ctl]   omega -> -omega; boost and dilation; a time-dependent mass M(1 + t/7) (f2_first_law.kn_frame_jet, tfac); chi with Omega = 1/31 on r = 9; the transposed
         contraction; the twist term with coefficient 1/2 and the candidate w.w/xi^2.  Kinematic (expected NOT to fail): a_l != a in l, and f with a charge term."""
import sys, os, time, itertools
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from b1lib import *
import g2_kerr as K
import f3_killing as F3
from f3_killing import fields, lie_frame, lam_sym, all_zero, wald_engine, wald_std, lie_g_std, vsum, form_eq_deg, sum_forms
from f2_first_law import kn_frame_jet, prop

NV = 4; SQ = LORENTZ(4); T0 = time.time()
M0, A0 = F(5), F(3)
def tick(s): print('    (%s: %.1f s)' % (s, time.time() - T0), flush=True)
def lin1(p, i): return p.get(tuple(1 if j == i else 0 for j in range(NV)), F(0))
def psign(seq):
    s = 1; seq = list(seq)
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]: s = -s
    return s
PERMS = [(p, psign(p)) for p in itertools.permutations(range(4))]

def twist_frame(W):
    """[bit] w_a = eps_abcd xi^b nabla^c xi^d from wald_engine's nab[c][d] = nabla_c xi_d and xi^a; returns (w, w.w)"""
    up = [[SQ[c] * SQ[d] * W['nab'][c][d] for d in range(4)] for c in range(4)]; x = W['xa']; w = [F(0)] * 4
    for (a, b, c, d), sg in PERMS: w[a] += sg * x[b] * up[c][d]
    return w, sum(SQ[a] * w[a] * w[a] for a in range(4))
def twist_std(Z, xi):
    """[std] coordinates: w_m = sqrt(-g) [mnrs] xi^n nabla^r xi^s; w.w = (-det g) g^mn W_m W_n with W the symbol contraction (exact, no square root)"""
    det, gi = det_inv(Z['g0']); x = [at0(q, NV) for q in xi]; nab = Z['nab']
    up = [[sum(gi[r][a] * gi[s][b] * nab[a][b] for a in range(4) for b in range(4)) for s in range(4)] for r in range(4)]; w = [F(0)] * 4
    for (m, n, r, s), sg in PERMS: w[m] += sg * x[n] * up[r][s]
    return -det * sum(gi[m][n] * w[m] * w[n] for m in range(4) for n in range(4)), det

ANGA = ((F(3, 5), F(4, 5)), (F(4, 5), F(3, 5))); ANGB = ((F(5, 13), F(12, 13)), (F(3, 5), F(4, 5))); EQ = ((F(0), F(1)), (F(1), F(0))); AXIS = ((F(1), F(0)), (F(1), F(0)))
PLAN = [(F(9), [ANGA, ANGB, EQ, AXIS]), (F(20), [ANGA, AXIS]), (F(7), [ANGB, EQ]), (F(4), [ANGA, AXIS]), (F(1, 2), [ANGB, EQ]), (F(1), [ANGA, ANGB, AXIS])]

def main():
    Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)          # per run (an engine fault put into Lie in memory is seen)
    CT = {}
    def ctl(name, wrong): k = CT.setdefault(name, [0, 0]); k[1] += 1; k[0] += int(bool(wrong))
    samples = []; hor = {}; npts = 0
    for r, angs in PLAN:
        for P in K.rational_kerr_points(A0, [r], angs):
            npts += 1; p = P['p']; e, E, _, _ = K.kerr_ks_frame_jet(p, M0, A0, r); e0, E0, det = E0_of(e, 4, 4); V = fields(p); g = std_metric(e, NV, SQ, NV, deg=2)
            where = 'r = %s, cos th = %s%s' % (r, P['cth'], ' (axis)' if P['sth'] == 0 else (' (equator)' if P['cth'] == 0 else ''))
            head('Kerr M = 5, a = 3 at %s, p = (%s)' % (where, ', '.join(map(str, p))))
            # ---------------------------------------------------------------- 1. Lie derivative of the frame
            Le, lam = lie_frame(Gv, e, E, V['d_t'])
            chk('bit', all(not x for x in Le), '%s: L_xi e^a = 0 for xi = d_t (value and first derivatives)' % where)
            Om = F(3, 10) if r == 1 else F(1, 30); chi = vsum((1, V['d_t']), (Om, V['rot_z']))
            for nm, xi, fac in (('rot_z', V['rot_z'], 1), ('chi = d_t + %s rot_z' % Om, chi, Om)):
                Le, lam = lie_frame(Gv, e, E, xi); Lam = [[lin1(V['rot_z'][a], b) for b in range(NV)] for a in range(NV)]
                cons = all(form_eq_deg(Le[a], sum_forms([(lam[a][b], e[b]) for b in range(NV)]), 1) for a in range(NV))
                const_ok = all(set(lam[a][b]) <= {(0,) * NV} for a in range(NV) for b in range(NV)) and all(at0(lam[a][b], NV) == fac * Lam[a][b] for a in range(NV) for b in range(NV))
                chk('bit', all_zero(lam_sym(lam)) and cons and any(lam[a][b] for a in range(NV) for b in range(NV)), '%s: %s: L_xi e^a = lam^a_b e^b, lam_ab + lam_ba = 0 to first order' % (where, nm))
                chk('bit==std', const_ok and all(not q for q in lie_g_std(g, xi).values()), '%s: %s: lam constant = %s x the textbook generator d_b (rot_z)^a; [std] L_xi g = 0 from the metric components' % (where, nm, fac))
            if npts <= 6:
                for bn in ('boost_x', 'dilation'):
                    xi = V[bn]; Le, lam = lie_frame(Gv, e, E, xi); sy = lam_sym(lam); Lg = lie_g_std(g, xi)
                    pred = [[sum((at0(sy[a][b], NV) * e0[a][m] * e0[b][n] for a in range(NV) for b in range(NV)), F(0)) for n in range(NV)] for m in range(NV)]
                    ctl('%s is not Killing: lam not antisymmetric, and (lam_ab + lam_ba) e e = [std] L_xi g != 0' % bn, not all_zero(sy) and all(pred[m][n] == at0(Lg[(m, n)], NV) for m in range(NV) for n in range(NV)))
                    ctl('%s: the Killing equation through omega fails' % bn, any(x != 0 for row in wald_engine(Gv, e, E0, xi, S)['K'] for x in row))
                et, Et, _, _ = kn_frame_jet(p, M0, A0, 0, r, tfac=F(1, 7))
                ctl('d_t on a frame with a time-dependent mass M(1 + t/7): L_xi e != 0', any(lie_frame(Gv, et, Et, V['d_t'])[0]))
            # ---------------------------------------------------------------- 2. Killing equation through omega, 3. Wald's identity and the twist
            for nm, xi in (('d_t', V['d_t']), ('rot_z', V['rot_z']), ('chi', chi)):
                W = wald_engine(Gv, e, E0, xi, S); Z = wald_std(e, xi)
                chk('bit', all(x == 0 for row in W['K'] for x in row) and any(x for row in W['nab'] for x in row), '%s: %s: Killing equation nabla_(a xi_b) = 0 exactly, nabla xi from the engine\'s omega (A3 closed form) and D_vector' % (where, nm))
                nab_c = [[sum(e0[a][m] * e0[b][n] * W['nab'][a][b] for a in range(NV) for b in range(NV)) for n in range(NV)] for m in range(NV)]
                w, ww = twist_frame(W); wws, dg = twist_std(Z, xi); D = W['dN2'] - 2 * W['N'] * W['F']
                chk('bit==std', nab_c == Z['nab'] and (Z['F'], Z['N'], Z['dN2']) == (W['F'], W['N'], W['dN2']) and ww == wws and dg == -1,
                    '%s: %s: nabla_m xi_n (engine omega) = Christoffel route, all 16; F = %s, xi^2 = %s, |d xi^2|^2 = %s, w.w = %s on both routes (det g = -1)' % (where, nm, W['F'], W['N'], W['dN2'], ww))
                if any(W['xa']): ctl('omega -> -omega (d kept): the Killing equation fails (where xi(p) != 0; on the axis rot_z(p) = 0 and omega drops out)', any(x != 0 for row in wald_engine(Gv, e, E0, xi, S, om_sign=-1)['K'] for x in row))
                FT = sum(SQ[a] * SQ[b] * W['nab'][a][b] * W['nab'][b][a] for a in range(NV) for b in range(NV))
                if W['N'] != 0: ctl('the transposed contraction nabla_a xi_b nabla^b xi^a in place of F: the identity with the twist fails', W['dN2'] - 2 * W['N'] * FT != ww)
                if nm != 'rot_z': samples.append(dict(where=where, r=r, nm=nm, N=W['N'], F=W['F'], dN2=W['dN2'], D=D, ww=ww, axis=P['sth'] == 0))
                print('    %s: %s: xi^2 = %s, F = %s, |d xi^2|^2 = %s, 2 xi^2 F = %s, defect D = %s, w.w = %s' % (where, nm, W['N'], W['F'], W['dN2'], 2 * W['N'] * W['F'], D, ww))
                if nm == 'chi' and r in (9, 1): hor.setdefault(r, []).append((W['N'], W['dN2'], W['F'], ww))
            if r == 9 and P['sth'] != 0:
                xw = vsum((1, V['d_t']), (F(1, 31), V['rot_z'])); Ww = wald_engine(Gv, e, E0, xw, S); _, www = twist_frame(Ww)
                ctl('chi with Omega = 1/31 on r = 9: not null, and the T18(c) form (no twist) fails', Ww['N'] != 0 and Ww['dN2'] != 2 * Ww['N'] * Ww['F'])
    tick('parts 1-3 at %d points' % npts)

    head('3. the defect of Wald\'s identity: FIT D = c1 w.w + c2 w.w/xi^2 from two points, then every sample (d_t and chi at all points)')
    fs = [s for s in samples if s['N'] != 0 and s['ww'] != 0]
    try:
        s1 = fs[0]; s2 = next(s for s in fs if s['N'] != s1['N'] and (s1['ww'] * s['ww'] / s['N'] - s['ww'] * s1['ww'] / s1['N']) != 0)
        det, inv = det_inv([[s1['ww'], s1['ww'] / s1['N']], [s2['ww'], s2['ww'] / s2['N']]]); c1, c2 = [inv[i][0] * s1['D'] + inv[i][1] * s2['D'] for i in range(2)]
    except Exception as ex: c1 = c2 = None; print('    fit failed: %s' % ex)
    chk('bit', (c1, c2) == (1, 0), 'fit from (%s, %s) and (%s, %s): (c1, c2) = (%s, %s): the defect is w.w with coefficient 1, the candidate w.w/xi^2 gets 0' % (s1['where'], s1['nm'], s2['where'], s2['nm'], c1, c2) if c1 is not None else 'fit failed')
    allok = all(s['D'] == s['ww'] for s in samples)
    chk('bit', allok and c1 == 1, 'g^-1(d xi^2, d xi^2) = 2 xi^2 F + w.w at all %d samples (d_t and chi at %d points: horizons, outside, between, inside, axis)' % (len(samples), npts))
    dts = [s for s in samples if s['nm'] == 'd_t']; poles = [s for s in dts if s['axis'] and s['r'] in (9, 1)]; rest = [s for s in dts if s not in poles]
    chk('bit', all(s['D'] != 0 and s['ww'] != 0 for s in rest), 'the T18(c) form (no twist) FAILS for Kerr\'s d_t at %d of %d points: every point off the horizons and every horizon point off the axis, the axis points r = 20 and 4 included (w.w != 0 there)' % (len(rest), len(dts)))
    chk('bit', len(poles) == 2 and all(s['N'] == 0 and s['dN2'] == 0 and s['ww'] == 0 and s['F'] != 0 for s in poles), 'at the 2 poles of the horizons (r = 9 and r = 1 on the axis) d_t is null, |d(xi^2)|^2 = 0 and w.w = 0: both sides vanish (F = %s there; the ergosurface touches the horizon at the poles)' % ', '.join(str(s['F']) for s in poles))
    for s in samples:
        if s['N'] != 0 and s['ww'] != 0: ctl('the twist term with coefficient 1/2', s['D'] != s['ww'] / 2); ctl('the candidate w.w/xi^2 alone', s['D'] != s['ww'] / s['N'])
    tick('part 3')

    head('4. the horizon: chi null, w = 0, F = -2 kH^2 (kH from C2 / F2: the engine\'s values)')
    for r, kH in ((F(9), F(2, 45)), (F(1), F(-2, 5))):
        L = hor.get(r, [])
        chk('bit', L and all(N == 0 and dN2 == 0 and ww == 0 and Fv == -2 * kH * kH for (N, dN2, Fv, ww) in L), 'Kerr (5, 3), r = %s, chi = d_t + %s rot_z at %d points (axis included): xi^2 = 0, |d xi^2|^2 = 0, w.w = 0 and F = %s = -2 kH^2 with kH = %s' % (
            r, F(1, 30) if r == 9 else F(3, 10), len(L), ', '.join(sorted({str(x[2]) for x in L})), kH))
    for (M, a, s, rh, Om, kH, nm) in ((F(3, 2), F(0), F(0), F(3), F(0), F(1, 6), 'a = 0 (Schwarzschild r_S = 3)'), (F(5), F(4), F(0), F(8), F(1, 20), F(3, 80), 'Kerr (5, 4), r+ = 8'),
                                       (F(5), F(1), F(4), F(9), F(1, 82), F(2, 41), 'Kerr-Newman frame (5, 1, s = 4), r+ = 9')):
        vals = set(); ok = True
        for P in K.rational_kerr_points(a, [rh], [ANGA, ANGB]):
            e, E, _, _ = kn_frame_jet(P['p'], M, a, s, rh); e0, E0, det = E0_of(e, 4, 4); V = fields(P['p']); xi = vsum((1, V['d_t']), (Om, V['rot_z']))
            W = wald_engine(Gv, e, E0, xi, S); _, ww = twist_frame(W); vals.add(W['F']); ok &= W['N'] == 0 and ww == 0 and all(x == 0 for row in W['K'] for x in row)
        chk('bit', ok and vals == {-2 * kH * kH}, '%s: chi = d_t + %s rot_z Killing, null, w = 0, F = %s = -2 kH^2 (kH = %s)%s' % (nm, Om, ', '.join(map(str, vals)), kH, ' = -1/(8 M^2)' if a == 0 else ''))
    tick('part 4')

    head('5. kinematic: frames that are not vacuum Kerr keep d_t and rot_z as Killing fields (the Killing part does not test the field equations)')
    for (lbl, kw) in (('a_l = a + 1/7 in l (not Kerr: E_a != 0, C2\'s control)', dict(a_l=A0 + F(1, 7))), ('f = (M r - s) r^2/(r^4 + a^2 z^2), s = 2, on the Kerr l (a charge term)', dict(s=F(2)))):
        ok = True; okw = True; n = 0
        for P in K.rational_kerr_points(A0, [F(9), F(4)], [ANGA]):
            e, E, _, _ = kn_frame_jet(P['p'], M0, A0, kw.get('s', 0), P['r'], a_l=kw.get('a_l')); e0, E0, det = E0_of(e, 4, 4); V = fields(P['p']); n += 1
            ok &= all(not x for x in lie_frame(Gv, e, E, V['d_t'])[0]) and all_zero(lam_sym(lie_frame(Gv, e, E, V['rot_z'])[1]))
            for xi in (V['d_t'], V['rot_z']):
                W = wald_engine(Gv, e, E0, xi, S); _, ww = twist_frame(W); ok &= all(x == 0 for row in W['K'] for x in row); okw &= W['dN2'] - 2 * W['N'] * W['F'] == ww
        chk('bit', ok and okw, '%s: d_t and rot_z are Killing (L_xi e, and nabla_(a xi_b) = 0 through omega) and |d xi^2|^2 = 2 xi^2 F + w.w at %d points' % (lbl, n))
    tick('part 5')

    head('controls (a wrong version must fail on every sample where it can be seen)')
    for name, (dif, seen) in CT.items(): chk('ctl', dif == seen and seen > 0, '%s: fails on %d of %d samples' % (name, dif, seen))
    print('\nTOTAL %.1f s' % (time.time() - T0)); finish('F3K')

if __name__ == '__main__': main()
