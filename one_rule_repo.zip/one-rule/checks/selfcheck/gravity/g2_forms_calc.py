#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Shared helper (step B2): interior product, Lie derivative and Lie bracket on the engine's forms.   python3 g2_forms_calc.py [n ...]

 A form is the engine's {coordinate mask: polynomial}; a vector field xi is a list of n polynomials xi^mu (same exponent tuples, nv >= n slots).
   interior(Gv, xi, X)      i_xi X, the LEFT contraction, sign from the bit rule:  i_mu dx^m = s dx^(m - mu)  where  dx^mu ^ dx^(m - mu) = s dx^m   (s = bmul sign)
   lie(Gv, xi, X)           L_xi X = d(i_xi X) + i_xi(d X)   (Cartan; the engine's d)
   vec_bracket(xi, eta, n)  [xi, eta]^mu = xi^nu d_nu eta^mu - eta^nu d_nu xi^mu
   lie_std(xi, X, n)        [std] the component formula (L_xi A)_{m1..mp} = xi^r d_r A_{m1..mp} + sum_k A_{m1..r..mp} d_{mk} xi^r, plain polynomial calculus (no engine code)
   frame_comps(Gv, xi, e)   xi^a = i_xi e^a (0-forms -> polynomials)
   D_dual_bivector(Gv, om, Y)   (D Y)_B = d Y_B - (1/2) f_AB^C om^A ^ Y_C  (lower bivector index: the dual of the engine's D_bivector)
   rand_vec, coord_vec, self_test(n, seed)
 Everything exact (Fractions).  Under an engine fault put in memory the functions follow the patched engine: interior reads only bmul; lie reads Forms.d."""
import sys, os, itertools, random
_G2 = os.path.dirname(os.path.abspath(__file__))
if _G2 not in sys.path: sys.path.insert(0, _G2)
import b1lib
from b1lib import gs, F, padd, bmul, popc, chk, head, finish

# ------------------------------------------------------------------------------------------------ engine route
def interior(Gv, xi, X, conv=1):
    """i_xi X (left contraction).  conv=-1: the right contraction (-1)^(p-1) i_xi (a control, the wrong convention)."""
    n = Gv.n; sq0 = [0] * n; out = {}
    for m, p in X.items():
        if not p or m == 0: continue
        for mu in range(n):
            if not (m >> mu & 1) or not xi[mu]: continue
            rest = m ^ (1 << mu); _, s = bmul(1 << mu, rest, sq0)
            if conv == -1: s *= (-1) ** (popc(m) - 1)
            x = padd(out.get(rest, {}), gs.pmul(xi[mu], p), s)
            if x: out[rest] = x
            else: out.pop(rest, None)
    return out
def lie(Gv, xi, X, conv=1):
    Fm = Gv.Fm
    return Fm.add(Fm.d(interior(Gv, xi, X, conv)), interior(Gv, xi, Fm.d(X), conv))
def lie_list(Gv, xi, Xs, conv=1): return [lie(Gv, xi, X, conv) for X in Xs]
def interior_list(Gv, xi, Xs, conv=1): return [interior(Gv, xi, X, conv) for X in Xs]
def frame_comps(Gv, xi, e):
    """xi^a = i_xi e^a as polynomials"""
    return [interior(Gv, xi, e[a]).get(0, {}) for a in range(Gv.n)]
def D_dual_bivector(Gv, om, Y):
    """(D Y)_B = d Y_B - (1/2) f_AB^C om^A ^ Y_C : covariant derivative on a LOWER bivector index (pairs with the engine's D_bivector: d(X^C Y_C) = DX^C Y_C +- X^C DY_C)"""
    Fm = Gv.Fm; out = [Fm.d(Y[B]) for B in range(Gv.G)]
    for (A, B), (C, f) in Gv.L.f.items(): out[B] = Fm.add(out[B], Fm.wedge(om[A], Y[C]), -F(f, 2))
    return out

# ------------------------------------------------------------------------------------------------ plain polynomial calculus ([std]: no engine code)
def _mul(a, b):
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            k = tuple(x + y for x, y in zip(k1, k2)); x = r.get(k, 0) + v1 * v2
            if x == 0: r.pop(k, None)
            else: r[k] = x
    return r
def _add(a, b, c=1):
    r = dict(a)
    for k, v in b.items():
        x = r.get(k, 0) + c * v
        if x == 0: r.pop(k, None)
        else: r[k] = x
    return r
def _der(a, i):
    r = {}
    for k, v in a.items():
        if k[i]:
            kk = list(k); kk[i] -= 1; kk = tuple(kk); r[kk] = r.get(kk, 0) + v * k[i]
    return {k: v for k, v in r.items() if v != 0}
def _comp(X, idx):
    """component A_{idx} of the form X (antisymmetric; X stores the increasing-index coefficient under its mask)"""
    if len(set(idx)) < len(idx): return {}
    s = 1
    for i in range(len(idx)):
        for j in range(i + 1, len(idx)):
            if idx[i] > idx[j]: s = -s
    m = sum(1 << i for i in idx); p = X.get(m, {})
    return p if s == 1 else {k: -v for k, v in p.items()}
def lie_std(xi, X, n):
    """[std] (L_xi A)_{m1..mp} = xi^r d_r A_{m1..mp} + sum_k A_{m1..r..mp} d_{mk} xi^r  for a homogeneous p-form X (component formula)"""
    degs = {popc(m) for m, p in X.items() if p}
    if not degs: return {}
    assert len(degs) == 1, 'homogeneous forms only'; p = degs.pop(); out = {}
    for idx in itertools.combinations(range(n), p):
        t = {}
        for r in range(n):
            if xi[r]: t = _add(t, _mul(xi[r], _der(_comp(X, idx), r)))
            for k in range(p):
                dxi = _der(xi[r], idx[k])
                if dxi:
                    j = list(idx); j[k] = r; t = _add(t, _mul(_comp(X, tuple(j)), dxi))
        if t: out[sum(1 << i for i in idx)] = t
    return out
def vec_bracket(xi, eta, n):
    """[xi, eta]^mu = xi^nu d_nu eta^mu - eta^nu d_nu xi^mu"""
    out = []
    for mu in range(n):
        t = {}
        for nu in range(n):
            if xi[nu]: t = _add(t, _mul(xi[nu], _der(eta[mu], nu)))
            if eta[nu]: t = _add(t, _mul(eta[nu], _der(xi[mu], nu)), -1)
        out.append(t)
    return out

# ------------------------------------------------------------------------------------------------ fields
def rand_vec(rng, n, deg=1, density=.6, nv=None):
    nv = nv or n; mons = [e for e in itertools.product(range(deg + 1), repeat=n) if sum(e) <= deg]; out = []
    for _ in range(n):
        p = {}
        for ex in mons:
            if rng.random() < density:
                c = F(rng.randint(-3, 3))
                if c: p[tuple(ex) + (0,) * (nv - n)] = c
        out.append(p)
    if not any(out): out[0] = {(0,) * nv: F(1)}
    return out
def coord_vec(n, mu, nv=None):
    nv = nv or n; return [{(0,) * nv: F(1)} if k == mu else {} for k in range(n)]
def rand_form(rng, n, p, deg=1, density=.6): return gs.rform(rng, n, p, deg, density)
def form_eq(X, Y):
    return all(X.get(k, {}) == Y.get(k, {}) for k in set(X) | set(Y))

# ------------------------------------------------------------------------------------------------ exact self-tests
def self_test(n, seed, deg_xi=2):
    """exact identities on random polynomial forms and vector fields (engine route), the [std] component formula, and two controls"""
    rng = random.Random(1000 * n + seed); Gv = gs.Grav(n); Fm = Gv.Fm
    xi, eta = rand_vec(rng, n, deg_xi), rand_vec(rng, n, deg_xi)
    forms = {p: rand_form(rng, n, p, 2) for p in range(0, n + 1)}
    al, al2, be = rand_form(rng, n, 1, 2), rand_form(rng, n, 1, 2), rand_form(rng, n, 2, 2)
    tag = 'n=%d seed %d' % (n, seed)
    ok = True
    for (A, p) in ((al, 1), (be, 2), (forms[3] if n >= 3 else al, 3 if n >= 3 else 1)):
        for (B, q) in ((al2, 1), (be, 2)):
            if p + q > n: continue
            lhs = interior(Gv, xi, Fm.wedge(A, B)); rhs = Fm.add(Fm.wedge(interior(Gv, xi, A), B), Fm.wedge(A, interior(Gv, xi, B)), (-1) ** p)
            ok &= form_eq(lhs, rhs) and bool(lhs)
    chk('bit', ok, '%s: i_xi is a graded antiderivation, i(A ^ B) = (iA) ^ B + (-1)^p A ^ (iB), degrees (p, q) up to (3, 2), polynomial xi of degree %d' % (tag, deg_xi))
    chk('bit', all(not any(interior(Gv, xi, interior(Gv, xi, forms[p])).values()) for p in range(2, n + 1)), '%s: i_xi i_xi = 0 on forms of degree 2..n' % tag)
    ok = True
    for (A, B) in ((al, al2), (al, be), (forms[0], be)):
        lhs = lie(Gv, xi, Fm.wedge(A, B)); rhs = Fm.add(Fm.wedge(lie(Gv, xi, A), B), Fm.wedge(A, lie(Gv, xi, B)))
        ok &= form_eq(lhs, rhs) and bool(lhs)
    chk('bit', ok, '%s: L_xi is a derivation of the wedge (degree 0 with 2, 1 with 1, 1 with 2)' % tag)
    chk('bit', all(form_eq(lie(Gv, xi, Fm.d(forms[p])), Fm.d(lie(Gv, xi, forms[p]))) for p in range(0, n)), '%s: [L_xi, d] = 0 on forms of degree 0..n-1' % tag)
    br = vec_bracket(xi, eta, n)
    ok = all(form_eq(Fm.add(lie(Gv, xi, interior(Gv, eta, forms[p])), interior(Gv, eta, lie(Gv, xi, forms[p])), -1), interior(Gv, br, forms[p])) for p in range(1, n + 1))
    chk('bit', ok and any(br), '%s: [L_xi, i_eta] = i_[xi, eta] on forms of degree 1..n' % tag)
    f0 = forms[0]; df = Fm.d(f0); dirv = lambda v, g: interior(Gv, v, Fm.d(g))
    lhs = Fm.add(dirv(xi, dirv(eta, f0)), dirv(eta, dirv(xi, f0)), -1); chk('bit', form_eq(lhs, interior(Gv, br, df)), '%s: xi(eta f) - eta(xi f) = [xi, eta] f (vec_bracket against the engine\'s d and i)' % tag)
    ok = all(form_eq(lie(Gv, xi, forms[p]), lie_std(xi, forms[p], n)) for p in range(1, n + 1))
    chk('bit==std', ok, '%s: L_xi = d i_xi + i_xi d (engine) equals the component formula xi^r d_r A + A_{..r..} d xi^r (plain polynomials) on forms of degree 1..n' % tag)
    chk('ctl', not form_eq(lie(Gv, xi, al, conv=-1), lie_std(xi, al, n)), '%s: control: with the right contraction (-1)^(p-1) i_xi, Cartan\'s formula no longer gives the component formula on 1-forms' % tag)
    if n >= 3:
        lhs = interior(Gv, xi, Fm.wedge(al, be), -1); rhs = Fm.add(Fm.wedge(interior(Gv, xi, al, -1), be), Fm.wedge(al, interior(Gv, xi, be, -1)), -1)
        chk('ctl', not form_eq(lhs, rhs), '%s: control: the right contraction is not a left antiderivation (1-form ^ 2-form)' % tag)
    if n >= 3: chk('ctl', not form_eq(Fm.d(interior(Gv, xi, be)), lie_std(xi, be, n)), '%s: control: d i_xi alone (no i_xi d) differs from the component formula on 2-forms' % tag)

if __name__ == '__main__':
    import time; t0 = time.time()
    for n in [int(a) for a in sys.argv[1:]] or [3, 4, 5]:
        head('g2_forms_calc self-test, n = %d (random polynomial forms of degree 2, vector fields of degree 2)' % n)
        for seed in (1, 2): self_test(n, seed)
        print('    (n=%d: %.1f s)' % (n, time.time() - t0), flush=True)
    finish('g2_forms_calc')
