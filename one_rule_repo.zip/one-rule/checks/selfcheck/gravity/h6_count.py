#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H6-count.  The 17 canonical variables of the area-metric closure (closure paper (121)-(125)) against the 9 + 12 split of duality, at one point.
   python3 h6_count.py

 The 17: the induced geometry of an area metric G in the foliation frame, g1^{ab} = -G^{0a0b}, g2 (spatial planes), g3 (G^{0abc}) (h6_area_metric.blocks),
   with the four frame conditions g1^{ab} g3_{ab} = 0 and g3_{[ab]} = 0 (124): a 17-dimensional surface in the 21 cells.  Linear algebra at the point
   G0 = 2 eta^{a[c} eta^{d]b} + eps^{abcd} (alpha = +1, the background of h6_area_metric part B): its tangent space T, by exact dual numbers through blocks;
   and the images of the 17 coordinate directions (dg1: 6, dg2: 6, dg3 symmetric and trace-free: 5) under the inverse of the block map.
 The split: S -> S(J., J.) on the 21 cells (lowered indices, as in g2_weyl), an involution with eigenspaces H9 (+1: trace-free Ricci type) and
   C12 (-1: Weyl 10 + scalar 1 + eps 1).  G is lowered with eta before the comparison; the same counts with upper indices are checked.
 [bit]  J from the bit rule (g2_weyl.duality_J: I B_A = s B_B, I the pseudoscalar), its 21 x 21 action (J21_matrix), H1's Ricci, scalar and eps rows.
 [std]  the textbook Hodge star (*B)_{ab} = (1/2) eps_ab^cd B_cd with eta (plain matrices, no engine); the pieces from the Kulkarni-Nomizu product
        P o eta (trace-free P: 9; P = eta: 1), the eps cell vector, and the Weyl space (all own traces zero); the frame conditions and blocks (h6_area_metric).
 Counted: dim(T cap H9), dim(T cap C12), the projections; T against Weyl, trace-free Ricci, scalar, eps; the three blocks; the four conormals.
 Controls: a random 17-dimensional subspace and a wrong selection of 17 coordinate cells give other counts; the complement map without the eta signs
   (g2_weyl.wrong_J_levi) does not give the Ricci split.  No closure equation is solved; nothing about the integration constants of the closure."""
import sys, os, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))                 # this folder (b1lib), also under python3 -I
from fractions import Fraction as F
from b1lib import chk, head, finish
from g2_weyl import PAIRS4, PIDX, SYM21, SIDX, CLASS, duality_J, J21_matrix, ricci_rows, scalar_row, eps_row, wrong_J_levi
from h6_area_metric import G_from_cells, epsG, blocks, det3, eps4

SQ = [1, -1, -1, -1]

# ------------------------------------------------------------------------------------------------ exact linear algebra
def rref(rows):
    M = [list(r) for r in rows]; piv = []; r = 0; ncol = len(M[0]) if M else 0
    for c in range(ncol):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / F(M[r][c]); M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(c); r += 1
        if r == len(M): break
    return M[:r], piv
def rank(vecs): return len(rref(vecs)[0]) if vecs else 0
def nullspace(rows, ncol):
    R, piv = rref(rows); out = []
    for fc in [c for c in range(ncol) if c not in piv]:
        v = [F(0)] * ncol; v[fc] = F(1)
        for i, pc in enumerate(piv): v[pc] = -R[i][fc]
        out.append(v)
    return out
def inter(U, V): return len(U) + len(V) - rank(U + V)                          # U, V: bases
def matvec(M, v): return [sum(M[i][j] * v[j] for j in range(len(v))) for i in range(len(M))]
def solve(M, b):
    R, piv = rref([row + [bb] for row, bb in zip(M, b)]); assert piv == list(range(len(M[0]))); return [R[i][-1] for i in range(len(M[0]))]
def coords(basis, v):
    """coefficients of v in a basis of the whole space (list of 21 vectors)"""
    return solve([[basis[j][i] for j in range(len(basis))] for i in range(len(v))], v)

# ------------------------------------------------------------------------------------------------ exact dual numbers a + b eps (eps^2 = 0)
class Du:
    __slots__ = ('a', 'b')
    def __init__(self, a, b=0): self.a = F(a); self.b = F(b)
    @staticmethod
    def of(x): return x if isinstance(x, Du) else Du(x)
    def __add__(s, o): o = Du.of(o); return Du(s.a + o.a, s.b + o.b)
    __radd__ = __add__
    def __sub__(s, o): o = Du.of(o); return Du(s.a - o.a, s.b - o.b)
    def __rsub__(s, o): return Du.of(o) - s
    def __mul__(s, o): o = Du.of(o); return Du(s.a * o.a, s.a * o.b + s.b * o.a)
    __rmul__ = __mul__
    def __truediv__(s, o): o = Du.of(o); return Du(s.a / o.a, (s.b * o.a - s.a * o.b) / (o.a * o.a))
    def __rtruediv__(s, o): return Du.of(o) / s
    def __neg__(s): return Du(-s.a, -s.b)
    def __eq__(s, o): o = Du.of(o); return s.a == o.a and s.b == o.b
    __hash__ = None
def eps_part(x): return Du.of(x).b
def val_part(x): return Du.of(x).a

# ------------------------------------------------------------------------------------------------ the point, the blocks, the frame conditions
def labels(i): A, B = SYM21[i]; return PAIRS4[A], PAIRS4[B]
SIGMA = [SQ[a] * SQ[b] * SQ[c] * SQ[d] for (a, b), (c, d) in map(labels, range(21))]   # upper cell -> lowered cell
def low(u): return [s * x for s, x in zip(SIGMA, u)]
def background(alpha=1):
    """upper cells of 2 eta^{a[c} eta^{d]b} + alpha eps^{abcd} (eps^{0123} = +1 as a symbol, as in h6_area_metric part B)"""
    u = []
    for (a, b), (c, d) in map(labels, range(21)):
        u.append(F(SQ[a] * SQ[b]) if (a, b) == (c, d) else (F(alpha * eps4(a, b, c, d)) if not set((a, b)) & set((c, d)) else F(0)))
    return u
def at(u, i=None):
    """the blocks at the upper cells u, perturbed by eps in cell i: (g1, g2, g3) as dual numbers; sqrt(det g1) exact to first order (det g1 = 1 at G0)"""
    S = {SYM21[k]: (Du(u[k], 1 if k == i else 0)) for k in range(21)}; G = G_from_cells(S)
    d1 = Du.of(det3([[-G[0][a + 1][0][b + 1] for b in range(3)] for a in range(3)]))
    assert d1.a == 1, 'det g1 is 1 at the point used'
    g1, g2, g3, _ = blocks(G, Du(1, d1.b / 2)); return g1, g2, g3, G
def frame(g1, g3):
    return [sum(g1[a][b] * g3[a][b] for a in range(3) for b in range(3))] + [g3[a][b] - g3[b][a] for a, b in ((0, 1), (0, 2), (1, 2))]
UPPER3 = [(a, b) for a in range(3) for b in range(a, 3)]
def block_coords(g1, g2, g3): return [g1[a][b] for a, b in UPPER3] + [g2[a][b] for a, b in UPPER3] + [g3[a][b] for a in range(3) for b in range(3)]

# ------------------------------------------------------------------------------------------------ the split: [bit] bit-rule duality, [std] Hodge star and Kulkarni-Nomizu
def cells_to_mat(v):
    S = [[F(0)] * 6 for _ in range(6)]
    for i, (A, B) in enumerate(SYM21): S[A][B] = v[i]; S[B][A] = v[i]
    return S
def mat_to_cells(S): return [S[A][B] for (A, B) in SYM21]
def hodge_std():
    """(*B)_A = sum_C M_AC B_C on lowered bivector components: (*B)_{ab} = (1/2) eps_{ab}^{cd} B_{cd}, eps_{0123} = 1, indices raised with eta"""
    return [[F(eps4(a, b, c, d) * SQ[c] * SQ[d]) for (c, d) in PAIRS4] for (a, b) in PAIRS4]
def iota_from(M):
    """21 x 21 matrix of S -> M^T S M on cell vectors"""
    cols = []
    for i in range(21):
        e = [F(0)] * 21; e[i] = F(1); S = cells_to_mat(e)
        cols.append(mat_to_cells([[sum(M[k][A] * S[k][l] * M[l][B] for k in range(6) for l in range(6)) for B in range(6)] for A in range(6)]))
    return [[cols[j][i] for j in range(21)] for i in range(21)]
def eig(Mx, lam): return nullspace([[Mx[i][j] - (lam if i == j else 0) for j in range(21)] for i in range(21)], 21)
def S_low(v, a, b, c, d):
    if a == b or c == d: return F(0)
    A, s1 = (PIDX[(a, b)], 1) if a < b else (PIDX[(b, a)], -1); B, s2 = (PIDX[(c, d)], 1) if c < d else (PIDX[(d, c)], -1)
    return s1 * s2 * v[SIDX[(min(A, B), max(A, B))]]
def kn(P):
    """(P o eta)_{abcd} = P_ac eta_bd + P_bd eta_ac - P_ad eta_bc - P_bc eta_ad, as a lowered cell vector"""
    eta = lambda x, y: SQ[x] if x == y else 0
    return [P[a][c] * eta(b, d) + P[b][d] * eta(a, c) - P[a][d] * eta(b, c) - P[b][c] * eta(a, d) for (a, b), (c, d) in map(labels, range(21))]
def pieces_std():
    sym = lambda i, j: [[F(1) if (x, y) in ((i, j), (j, i)) else F(0) for y in range(4)] for x in range(4)]
    diag = lambda p: [[F(p[x]) if x == y else F(0) for y in range(4)] for x in range(4)]
    tf = [sym(i, j) for i in range(4) for j in range(i + 1, 4)] + [diag(p) for p in ((1, 1, 0, 0), (1, 0, 1, 0), (1, 0, 0, 1))]
    Ric = [kn(P) for P in tf]; Scal = [kn(diag(SQ))]
    Eps = [[F(eps4(a, b, c, d)) if not set((a, b)) & set((c, d)) else F(0) for (a, b), (c, d) in map(labels, range(21))]]
    rows = [[sum(SQ[a] * S_low(e, a, b, a, d) for a in range(4)) for e in ([F(int(k == i)) for k in range(21)] for i in range(21))] for b in range(4) for d in range(b, 4)]
    rows.append([F(eps4(a, b, c, d)) if not set((a, b)) & set((c, d)) else F(0) for (a, b), (c, d) in map(labels, range(21))])
    W = nullspace(rows, 21)
    return W, Ric, Scal, Eps

# ------------------------------------------------------------------------------------------------ main
def counts(T, H9, C12, Iota, W, Ric, Scal, Eps):
    """intersections with and projections onto the pieces of the split (H9 + C12; and W + Ric + Scal + Eps)"""
    P = W + Ric + Scal + Eps; parts = {'W': (0, 10), 'Ric': (10, 19), 'Scal': (19, 20), 'Eps': (20, 21)}; cs = [coords(P, v) for v in T]
    proj = {k: rank([c[s:e] for c in cs]) for k, (s, e) in parts.items()}
    pi9 = rank([[(x + y) / 2 for x, y in zip(v, matvec(Iota, v))] for v in T]); pi12 = rank([[(x - y) / 2 for x, y in zip(v, matvec(Iota, v))] for v in T])
    return dict(H9=inter(T, H9), C12=inter(T, C12), pi9=pi9, pi12=pi12, W=inter(T, W), Ric=inter(T, Ric), Scal=inter(T, Scal), Eps=inter(T, Eps),
                SE=inter(T, Scal + Eps), pW=proj['W'], pRic=proj['Ric'], pScal=proj['Scal'], pEps=proj['Eps'])
def fmt(c): return 'T cap H9 %(H9)d, T cap C12 %(C12)d, onto H9 %(pi9)d, onto C12 %(pi12)d; T cap Weyl %(W)d, cap Ric %(Ric)d, cap scalar %(Scal)d, cap eps %(Eps)d, cap (scalar + eps) %(SE)d; onto Weyl %(pW)d, Ric %(pRic)d, scalar %(pScal)d, eps %(pEps)d' % c

def main():
    head('The point and the 17 [std] (h6_area_metric.blocks, exact dual numbers): G0 = 2 eta^{a[c} eta^{d]b} + eps^{abcd}')
    u0 = background(1); g1, g2, g3, G = at(u0)
    fr0 = [val_part(x) for x in frame(g1, g3)]
    chk('std', epsG([[[[val_part(x) for x in z] for z in y] for y in w] for w in G]) == 24 and all(val_part(g1[a][b]) == (a == b) for a in range(3) for b in range(3))
        and all(val_part(g3[a][b]) == 0 for a in range(3) for b in range(3)) and fr0 == [0, 0, 0, 0], 'G0: eps.G = 24, g1 = identity, g3 = 0, the four frame conditions hold: G0 lies on the 17-dimensional surface')
    Jac = [[eps_part(f) for f in frame(*at(u0, i)[0:3:2])] for i in range(21)]; Jac = [[Jac[i][k] for i in range(21)] for k in range(4)]
    Tup = nullspace(Jac, 21)
    chk('std', rank(Jac) == 4 and len(Tup) == 17, 'the four frame conditions have an exact Jacobian of rank %d on the 21 cells at G0; T = its kernel, dim %d' % (rank(Jac), len(Tup)))
    Jb = [[eps_part(x) for x in block_coords(*at(u0, i)[0:3])] for i in range(21)]; Jb = [[Jb[i][k] for i in range(21)] for k in range(21)]
    sym3 = [(a, b) for a in range(3) for b in range(a, 3)]
    d3 = [[(a == 0) - (a == 1) if a == b else 0 for b in range(3)] for a in range(3)], [[(a == 1) - (a == 2) if a == b else 0 for b in range(3)] for a in range(3)]
    dirs = {'g1': [], 'g2': [], 'g3': []}
    for k in range(6): v = [F(0)] * 21; v[k] = F(1); dirs['g1'].append(v)
    for k in range(6): v = [F(0)] * 21; v[6 + k] = F(1); dirs['g2'].append(v)
    for M in list(d3) + [[[1 if {x, y} == {a, b} else 0 for y in range(3)] for x in range(3)] for a, b in ((0, 1), (0, 2), (1, 2))]:
        dirs['g3'].append([F(0)] * 12 + [F(M[x][y]) for x in range(3) for y in range(3)])
    img = {k: [solve(Jb, v) for v in vs] for k, vs in dirs.items()}; allimg = img['g1'] + img['g2'] + img['g3']
    chk('std', rank(Jb) == 21 and rank(allimg) == 17 and rank(allimg + Tup) == 17, 'the block map (121)-(123) is invertible at G0 (rank %d); the images of the 17 coordinate directions (dg1 6, dg2 6, dg3 symmetric trace-free 5) have rank %d and span T' % (rank(Jb), rank(allimg)))
    T = [low(v) for v in Tup]; IMG = {k: [low(v) for v in vs] for k, vs in img.items()}

    head('The split of duality: [bit] the bit rule, [std] the Hodge star and the Ricci decomposition')
    J, I2, comm, compl = duality_J(SQ); Ib = J21_matrix(J); Is = iota_from(hodge_std())
    H9, C12 = eig(Ib, 1), eig(Ib, -1); H9s, C12s = eig(Is, 1), eig(Is, -1)
    sq21 = [[sum(Ib[i][k] * Ib[k][j] for k in range(21)) for j in range(21)] for i in range(21)]
    chk('bit', I2 == -1 and comm and compl and all(sq21[i][j] == (i == j) for i in range(21) for j in range(21)) and (len(H9), len(C12)) == (9, 12), 'the pseudoscalar squares to %d, commutes with the bivectors and maps each plane to its complement; S -> S(J., J.) is an involution with eigenspaces of dimension %d (+1) and %d (-1)' % (I2, len(H9), len(C12)))
    W, Ric, Scal, Eps = pieces_std()
    chk('std', (len(W), rank(Ric), rank(Scal + Eps)) == (10, 9, 2) and rank(W + Ric + Scal + Eps) == 21 and (len(H9s), len(C12s)) == (9, 12), 'textbook pieces: Weyl %d (Ricci and eps traces zero), trace-free Ricci %d (P o eta), scalar + eps %d, together 21; the Hodge star gives the same 9 + 12' % (len(W), rank(Ric), rank(Scal + Eps)))
    chk('bit==std', inter(H9, H9s) == 9 and inter(C12, C12s) == 12 and inter(H9, Ric) == 9 and inter(C12, W + Scal + Eps) == 12, 'the bit-rule split equals the Hodge-star split, H9 = the trace-free Ricci space and C12 = Weyl + scalar + eps, as subspaces of the 21 cells')
    rB = ricci_rows(SQ) + [scalar_row(SQ), eps_row()]
    chk('bit==std', all(sum(r[i] * w[i] for i in range(21)) == 0 for r in rB for w in W) and rank(rB) == 11, 'H1\'s Ricci, scalar and eps rows (g2_weyl) vanish on the textbook Weyl space and have rank 11')

    head('The count: T (the 17 at G0) against the split')
    c = counts(T, H9, C12, Ib, W, Ric, Scal, Eps); print('  ' + fmt(c))
    chk('bit', (c['H9'], c['C12'], c['pi9'], c['pi12']) == (5, 11, 6, 12), 'T against H9 + C12: dim(T cap H9) = %d, dim(T cap C12) = %d (sum %d of 17); projections %d onto H9, %d onto C12: the 17 do NOT decompose along the 9 + 12 split, by one direction' % (c['H9'], c['C12'], c['H9'] + c['C12'], c['pi9'], c['pi12']))
    chk('bit', (c['W'], c['Ric'], c['SE'], c['Scal'], c['Eps'], c['pRic']) == (10, 5, 1, 0, 0, 6), 'T contains all 10 Weyl-like directions, 5 of the 9 trace-free-Ricci-like ones and one combination of scalar and eps (neither alone); the 17th direction projects onto Ricci, scalar and eps together (projections: Ricci %d, scalar %d, eps %d)' % (c['pRic'], c['pScal'], c['pEps']))
    H9u, C12u = eig(Is, 1), eig(Is, -1)                                        # the Hodge star acting on the upper form directly: G -> G(*., *.)
    chk('std', (inter(Tup, H9u), inter(Tup, C12u)) == (c['H9'], c['C12']), 'the same count when the Hodge star acts on the upper cells of G directly (no lowering): T cap H9 %d, T cap C12 %d' % (inter(Tup, H9u), inter(Tup, C12u)))

    head('The three blocks of the 17 (images of dg1, dg2, dg3 symmetric trace-free) against the pieces')
    out = {}
    for k in ('g1', 'g2', 'g3'):
        cb = counts(IMG[k], H9, C12, Ib, W, Ric, Scal, Eps); out[k] = cb; print('  %s (%d): %s' % (k, len(IMG[k]), fmt(cb)))
    chk('bit', out['g3']['W'] == 5 and out['g3']['pRic'] == 0, 'the dg3 block (5) lies in the Weyl space: the magnetic type part of the mixed block')
    chk('bit', all(out[k]['pW'] == 5 and out[k]['W'] < 6 and out[k]['pRic'] > 0 for k in ('g1', 'g2')), 'the dg1 and dg2 blocks (6 each) are not pure: each projects onto 5 Weyl directions and onto Ricci (%d, %d) and contains %d, %d Weyl directions' % (out['g1']['pRic'], out['g2']['pRic'], out['g1']['W'], out['g2']['W']))

    head('The four frame conditions (conormals at G0) against the pieces and the cells')
    Jlow = [[SIGMA[i] * r[i] for i in range(21)] for r in Jac]
    see = lambda r, X: any(sum(r[i] * x[i] for i in range(21)) != 0 for x in X)
    names = ['trace g1^{ab} g3_{ab}', 'g3_[12]', 'g3_[13]', 'g3_[23]']
    for r, nm in zip(Jlow, names):
        cl = sorted(set(('g1' if (A[0] == 0 and B[0] == 0) else 'g3' if (A[0] == 0) != (B[0] == 0) else 'g2') + ':' + CLASS[SYM21[i]] for i in range(21) if r[i] != 0 for A, B in [labels(i)]))
        print('  %-22s sees Weyl %s, Ricci %s, scalar %s, eps %s; cells %s' % (nm, see(r, W), see(r, Ric), see(r, Scal), see(r, Eps), cl))
    tr = Jlow[0]; anti = Jlow[1:]
    ep_g1 = lambda r: all(r[i] == 0 or CLASS[SYM21[i]] == 'A' or (labels(i)[0][0] == 0 and labels(i)[1][0] == 0) for i in range(21))
    chk('bit', not see(tr, W) and see(tr, Ric) and see(tr, Scal) and see(tr, Eps) and ep_g1(tr), 'the trace frame condition touches only the eps (antipodal) cells and the g1 cells, sees Ricci, scalar and eps, not Weyl: it is the one that is neither in H9 nor in C12')
    chk('bit', all(see(r, Ric) and not see(r, W) and not see(r, Scal) and not see(r, Eps) and not ep_g1(r) for r in anti), 'the three conditions g3_[ab] = 0 are trace-free-Ricci-like (they see only the Ricci space) and touch mixed-block edge cells, not eps or g1: the description "eps/g1-only" holds for one of the four conditions')

    head('Controls [ctl]')
    rng = random.Random(16); R17 = [[F(rng.randint(-9, 9)) for _ in range(21)] for _ in range(17)]
    cr = counts(R17, H9, C12, Ib, W, Ric, Scal, Eps)
    chk('ctl', rank(R17) == 17 and (cr['H9'], cr['C12']) == (5, 8) and (cr['H9'], cr['C12'], cr['W']) != (c['H9'], c['C12'], c['W']), 'a random 17-dimensional subspace: T cap H9 %d, T cap C12 %d, Weyl %d (the generic count): different from the 17 of the closure' % (cr['H9'], cr['C12'], cr['W']))
    drop = [i for i in range(21) if CLASS[SYM21[i]] == 'A'] + [SIDX[(0, 0)]]
    sel = [low([F(int(k == i)) for k in range(21)]) for i in range(21) if i not in drop]; cw = counts(sel, H9, C12, Ib, W, Ric, Scal, Eps)
    chk('ctl', len(sel) == 17 and (cw['H9'], cw['C12'], cw['W']) != (c['H9'], c['C12'], c['W']), 'a wrong selection, the 17 coordinate cells left after dropping the three antipodal cells and the g1 cell (01,01): T cap H9 %d, T cap C12 %d, Weyl %d: different' % (cw['H9'], cw['C12'], cw['W']))
    Iw = J21_matrix(wrong_J_levi(SQ)); Hw = eig(Iw, 1)
    chk('ctl', inter(Hw, Ric) < 9, 'the complement map without the eta signs (g2_weyl.wrong_J_levi): its +1 eigenspace (dim %d) is not the trace-free Ricci space (common dimension %d)' % (len(Hw), inter(Hw, Ric)))
    finish('H6-count')

if __name__ == '__main__': main()
