#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""H5 (L part), algebra and decomposition: so(2,4) from the null pair, built with the engine, and the curvature of the larger algebra on 4 coordinates.
   python3 h5l_conformal.py
 Six generators, squares sq6 = (+1,-1,-1,-1 | +1,-1): the frame (+,-,-,-) and the hyperbolic pair g4 (+1), g5 (-1).  Null pair (the Atlas's, projective_selfcheck.py
 with e_m = g4, e_p = g5): eps = g4 + g5, o = (g4 - g5)/2, {eps, o} = 2.  The engine's connection components multiply X_A = B_A / 2 (then Grav.curvature is the
 Yang-Mills curvature F = dA + (1/2)[A, A] with [X_A, X_B] = (1/2) f_AB^C X_C).  Basis used here:
   J_ab = X_ab = (1/2) g_a g_b,   P_a = (1/2) g_a eps = X_a4 + X_a5,   K_a = (1/2) g_a o = (X_a4 - X_a5)/2,   D = (1/2) eps^o = -X_45.
 Connection A = omega^{ab} J_ab + e^a P_a + b D + f^a K_a (compose / decompose below), curvature by Grav(4, Lie(sq6)).curvature (the desitter_embedding pattern;
 Grav.D_vector / D_covector cannot take 6 generators on 4 coordinates, they index vectors by the coordinate count).
 [bit]  the engine's f and h tables, its curvature, torsion and D_vector.   [std] textbook so(p,q) matrices (M_AB)^C_D = delta^C_A eta_BD - delta^C_B eta_AD, the
 matrix curvature dA + A A at a point with plain derivatives (no Clifford algebra, no engine).
 Part 1: brackets, Jacobi, dimension 15 = 6 + 4 + 4 + 1, the D-grading 4 + 7 + 4, Killing form, the dictionary so(2,4) = so(4,2), controls (+1,+1), (-1,-1), Euclid.
 Part 2: F = (R + c (e^a f^b - e^b f^a)) J + (T + b e) P + (db + c eta e f) D + (D f - b f) K for random polynomial fields, c fitted; bit==std matrix route.
 Exports (import-safe, no engine object at import): Conf, compose, decompose, curvature6, form helpers, so_mat, std_conn_matrices, std_F_at, adm, Ad_exp, ..."""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b1lib import *
from fractions import Fraction as F

SQ4 = [1, -1, -1, -1]
PAIR = (1, -1)
T0 = time.time()
def tick(label): print('    (%s: %.1f s)' % (label, time.time() - T0), flush=True)

# ------------------------------------------------------------------------------------------------ the algebra with the null pair (engine tables)
class Conf:
    """6 generators = frame (n = 4) + pair; the engine's Lie table of all 15 bivectors and the null-pair basis as 15-vectors {label: Fraction} in X components"""
    def __init__(self, frame=SQ4, pair=PAIR):
        self.frame = list(frame); self.pair = tuple(pair); self.sq = list(frame) + list(pair); self.n = len(frame); n = self.n
        self.L = Lie(self.sq); self.G = self.L.G; self.Gv = Grav(n, self.L)
        self.Ll = Lie(self.frame); self.Gl = Grav(n, self.Ll)                     # the frame (Lorentz) algebra on its own
        self.lab = {}
        for a in range(n + 2):
            for b in range(a + 1, n + 2): self.lab[(a, b)] = self.L.idx[(1 << a) | (1 << b)]
        self.l4 = {pr: self.Ll.idx[(1 << pr[0]) | (1 << pr[1])] for pr in itertools.combinations(range(n), 2)}
        self.pairs4 = pairs_of(self.Ll)
        lb = self.lab; p4, p5 = n, n + 1
        self.J = {pr: {lb[pr]: F(1)} for pr in itertools.combinations(range(n), 2)}
        self.P = [{lb[(a, p4)]: F(1), lb[(a, p5)]: F(1)} for a in range(n)]
        self.K = [{lb[(a, p4)]: F(1, 2), lb[(a, p5)]: F(-1, 2)} for a in range(n)]
        self.D = {lb[(p4, p5)]: F(-1)}
    def eta(self, a, b): return self.frame[a] if a == b else 0
    def Jab(self, a, b):
        """J_ab for any a, b (J_ba = -J_ab, J_aa = 0)"""
        if a == b: return {}
        return dict(self.J[(a, b)]) if a < b else vscale(self.J[(b, a)], -1)
    def br(self, y, z):
        """[Y, Z] = (1/2) f_AB^C y^A z^B X_C (constant coefficients)"""
        out = {}
        for (A, B), (C, f) in self.L.f.items():
            if A in y and B in z: out[C] = out.get(C, 0) + F(f, 2) * y[A] * z[B]
        return {k: v for k, v in out.items() if v != 0}
    def basis(self):
        """the 15 null-pair basis vectors with names"""
        out = [('J%d%d' % pr, self.J[pr]) for pr in sorted(self.J)] + [('P%d' % a, self.P[a]) for a in range(self.n)]
        out += [('K%d' % a, self.K[a]) for a in range(self.n)] + [('D', self.D)]
        return out
    def ad(self, y):
        """15x15 matrix of ad Y in X components: (ad Y)[C][B]"""
        M = [[F(0)] * self.G for _ in range(self.G)]
        for (A, B), (C, f) in self.L.f.items():
            if A in y: M[C][B] += F(f, 2) * y[A]
        return M

def vadd(x, y, c=1):
    r = dict(x)
    for k, v in y.items():
        s = r.get(k, 0) + c * v
        if s == 0: r.pop(k, None)
        else: r[k] = s
    return r
def vscale(x, c): return {k: v * c for k, v in x.items()} if c != 0 else {}
def vlin(*terms):
    r = {}
    for c, x in terms: r = vadd(r, x, c)
    return r
def veq(x, y): return vadd(x, y, -1) == {}

# ------------------------------------------------------------------------------------------------ forms (engine Forms) helpers
def fzero(X): return all(not p for p in X.values())
def feq(Fm, X, Y): return fzero(Fm.add(X, Y, -1))
def fmul0(p, X):
    """0-form polynomial p times a form X"""
    out = {}
    for m, q in X.items():
        r = pm(p, q)
        if r: out[m] = r
    return out
def ftrunc(X, deg, n=4):
    out = {}
    for m, p in X.items():
        q = {k: v for k, v in p.items() if sum(k[:n]) <= deg}
        if q: out[m] = q
    return out

def compose(C, om, e, f=None, b=None):
    """A = omega^{ab} J_ab + e^a P_a + b D + f^a K_a as the engine's 15 components (forms).  om in the order of the frame Lie table (C.Ll.gens)."""
    Fm = C.Gv.Fm; n = C.n; A = [{} for _ in range(C.G)]
    for A4, (a, bb) in enumerate(C.pairs4): A[C.lab[(a, bb)]] = dict(om[A4]) if om[A4] else {}
    for a in range(n):
        fa = f[a] if f else {}
        A[C.lab[(a, n)]] = Fm.add(e[a], fa, F(1, 2)); A[C.lab[(a, n + 1)]] = Fm.add(e[a], fa, F(-1, 2))
    if b: A[C.lab[(n, n + 1)]] = Fm.scale(b, -1)
    return A
def decompose(C, X):
    """15 engine components (forms of any degree) -> dict(J = {(a,b): form}, P = [forms], K = [forms], D = form)"""
    Fm = C.Gv.Fm; n = C.n
    J = {pr: X[C.lab[pr]] for pr in itertools.combinations(range(n), 2)}
    P = [Fm.scale(Fm.add(X[C.lab[(a, n)]], X[C.lab[(a, n + 1)]]), F(1, 2)) for a in range(n)]
    K = [Fm.add(X[C.lab[(a, n)]], X[C.lab[(a, n + 1)]], -1) for a in range(n)]
    return dict(J=J, P=P, K=K, D=Fm.scale(X[C.lab[(n, n + 1)]], -1))
def curvature6(C, A, xdeg=None):
    """[bit] F = dA + (1/4) f A A with the 6-generator table on 4 coordinates (engine); xdeg truncates the polynomial products"""
    if xdeg is None: return C.Gv.curvature(A)
    with trunc(C.n, xdeg=xdeg): return C.Gv.curvature(A)
def ad_forms(C, y, X):
    """[Y, X] for Y with 0-form (polynomial) coefficients y {label: poly} and X a list of 15 forms (engine f table)"""
    Fm = C.Gv.Fm; out = [{} for _ in range(C.G)]
    for (A, B), (Cc, f) in C.L.f.items():
        if A in y and X[B]: out[Cc] = Fm.add(out[Cc], fmul0(y[A], X[B]), F(f, 2))
    return out
def Ad_exp(C, y, X, maxk=6):
    """Ad(exp Y) X = sum_k ad_Y^k X / k! for a nilpotent ad_Y (asserted: the series stops)"""
    Fm = C.Gv.Fm; out = [dict(x) for x in X]; term = X; fact = F(1)
    for k in range(1, maxk + 1):
        term = ad_forms(C, y, term)
        if all(fzero(t) for t in term): return out
        fact *= k; out = [Fm.add(out[i], term[i], 1 / fact) for i in range(C.G)]
    raise AssertionError('ad Y is not nilpotent to order %d' % maxk)

# ------------------------------------------------------------------------------------------------ [std] textbook so(p,q) matrices (no Clifford algebra, no engine)
def so_mat(A, B, sq):
    """(M_AB)^C_D = delta^C_A eta_BD - delta^C_B eta_AD"""
    N = len(sq); M = [[F(0)] * N for _ in range(N)]
    for D_ in range(N):
        if B == D_: M[A][D_] += sq[B]
        if A == D_: M[B][D_] -= sq[A]
    return M
def mmul(X, Y): return [[sum(X[i][k] * Y[k][j] for k in range(len(Y))) for j in range(len(Y[0]))] for i in range(len(X))]
def madd(X, Y, c=1): return [[X[i][j] + c * Y[i][j] for j in range(len(X[0]))] for i in range(len(X))]
def mscal(X, c): return [[c * x for x in r] for r in X]
def mcomm(X, Y): return madd(mmul(X, Y), mmul(Y, X), -1)
def mzero(N): return [[F(0)] * N for _ in range(N)]
def std_gens(sq):
    """textbook generators by pair (A, B), A < B, and the null-pair combinations built from them (frame n = len(sq) - 2)"""
    N = len(sq); n = N - 2; M = {pr: so_mat(pr[0], pr[1], sq) for pr in itertools.combinations(range(N), 2)}
    P = [madd(M[(a, n)], M[(a, n + 1)]) for a in range(n)]
    K = [mscal(madd(M[(a, n)], M[(a, n + 1)], -1), F(1, 2)) for a in range(n)]
    D = mscal(M[(n, n + 1)], -1)
    return M, P, K, D
def std_components(Mx, sq):
    """read the coefficients x^{AB} (A < B) of a matrix sum_AB x^{AB} M_AB (entry (A, B) of M_AB is eta_BB, of every other generator 0)"""
    N = len(sq); return {pr: Mx[pr[0]][pr[1]] / sq[pr[1]] for pr in itertools.combinations(range(N), 2)}
def peval(p, pt):
    tot = F(0)
    for k, v in p.items():
        t = v
        for i, x in enumerate(pt): t *= x ** k[i] if k[i] else 1
        tot += t
    return tot
def std_conn_matrices(sq, om_c, e, f, b, pairs4):
    """[std] the matrix-valued connection A_mu(x) = sum omega^{ab}_mu M_ab + e^a_mu P_a + f^a_mu K_a + b_mu D as a function returning (A_mu(pt), d_nu A_mu(pt))"""
    M, P, K, D = std_gens(sq); N = len(sq); n = N - 2
    terms = []                                                            # (form, matrix)
    for A4, pr in enumerate(pairs4): terms.append((om_c[A4], M[pr]))
    for a in range(n): terms.append((e[a], P[a])); terms.append((f[a] if f else {}, K[a]))
    terms.append((b or {}, D))
    def at(pt):
        Amu = [mzero(N) for _ in range(n)]; dA = {(nu, mu): mzero(N) for nu in range(n) for mu in range(n)}
        for form, Mt in terms:
            for mask, p in form.items():
                mu = mask.bit_length() - 1
                Amu[mu] = madd(Amu[mu], Mt, peval(p, pt))
                for nu in range(n): dA[(nu, mu)] = madd(dA[(nu, mu)], Mt, peval(sp_der(p, nu), pt))
        return Amu, dA
    return at
def std_F_at(sq, conn_at, pt):
    """[std] F_{mu nu} = d_mu A_nu - d_nu A_mu + [A_mu, A_nu] at pt, read as X-components {(A,B): {(mu,nu): value}} (mu < nu)"""
    N = len(sq); n = N - 2; Amu, dA = conn_at(pt); out = {}
    for mu in range(n):
        for nu in range(mu + 1, n):
            Fmn = madd(madd(dA[(mu, nu)], dA[(nu, mu)], -1), mcomm(Amu[mu], Amu[nu]))
            for pr, v in std_components(Fmn, sq).items(): out.setdefault(pr, {})[(mu, nu)] = v
    return out

# ------------------------------------------------------------------------------------------------ part 1: the algebra
def part1():
    head('Part 1. The algebra: 6 generators (+,-,-,-,+,-), the null pair eps = g4 + g5, o = (g4 - g5)/2, basis J (6), P (4), K (4), D (1)')
    C = Conf(); n = 4; eta = C.eta; sq6 = C.sq
    names = C.basis(); vecs = [v for _, v in names]
    rows = [[v.get(Cc, F(0)) for Cc in range(C.G)] for v in vecs]
    chk('bit', rank_exact(rows) == 15 and len(C.J) == 6 and len(C.P) == 4 and len(C.K) == 4, 'the 15 vectors J_ab, P_a, K_a, D are a basis of the 15 bivectors: 15 = 6 + 4 + 4 + 1 (rank 15)')
    ok = all(veq(C.br(C.D, C.P[a]), C.P[a]) and veq(C.br(C.D, C.K[a]), vscale(C.K[a], -1)) for a in range(n))
    chk('bit', ok, '[D, P_a] = +P_a and [D, K_a] = -K_a for a = 0..3 (engine f table)')
    chk('bit', all(C.br(C.P[a], C.P[b]) == {} and C.br(C.K[a], C.K[b]) == {} for a in range(n) for b in range(n)), '[P_a, P_b] = 0 and [K_a, K_b] = 0 (all 16 + 16 pairs): eps and o are null')
    c00 = C.br(C.P[0], C.K[0]); cfit = c00.get(C.lab[(4, 5)], F(0)) / (C.D[C.lab[(4, 5)]] * eta(0, 0))
    good = all(veq(C.br(C.P[a], C.K[b]), vscale(vadd(vscale(C.D, eta(a, b)), C.Jab(a, b)), cfit)) for a in range(n) for b in range(n))
    chk('bit', cfit == -1 and good, '[P_a, K_b] = c (eta_ab D + J_ab) for all 16 (a, b), c fitted on [P_0, K_0] = %s' % cfit)
    chk('ctl', not all(veq(C.br(C.P[a], C.K[b]), vadd(vscale(C.D, eta(a, b)), C.Jab(a, b))) for a in range(n) for b in range(n)), 'the opposite sign [P_a, K_b] = +(eta_ab D + J_ab) fails (ok)')
    # the Lorentz action on P and K is the vector action of the frame algebra's h table
    okh = True
    for A4, (a, b) in enumerate(C.pairs4):
        for c in range(n):
            wantP, wantK = {}, {}
            for (AA, cc), (d, h) in C.Ll.h.items():
                if AA == A4 and cc == c: wantP = vadd(wantP, C.P[d], h); wantK = vadd(wantK, C.K[d], h)
            Jv = C.J[(a, b)]
            if not (veq(C.br(Jv, C.P[c]), wantP) and veq(C.br(Jv, C.K[c]), wantK)): okh = False
    chk('bit', okh, '[J_ab, P_c] = h_{(ab)c}^d P_d and [J_ab, K_c] = h_{(ab)c}^d K_d: the 6-generator f table carries the vector action of the h table of Lie(+,-,-,-)')
    chk('bit', all(C.br(C.J[pr], C.D) == {} for pr in C.J), '[J_ab, D] = 0 (the dilatation commutes with the Lorentz algebra)')
    import a1_lemmas as A1
    chk('bit', A1.jacobi_bad(C.L) == 0, 'Jacobi identity of the 15-bivector table (A1 jacobi_bad = 0)')
    # the D-grading
    adD = C.ad(C.D)
    def apply(M, v): return {Cc: sum(M[Cc][B] * v.get(B, 0) for B in range(C.G)) for Cc in range(C.G) if sum(M[Cc][B] * v.get(B, 0) for B in range(C.G)) != 0}
    mult = {}
    for lam in (1, 0, -1):
        Mx = [[adD[i][j] - (lam if i == j else 0) for j in range(C.G)] for i in range(C.G)]; mult[lam] = C.G - rank_exact(Mx)
    eig_ok = all(veq(apply(adD, C.P[a]), C.P[a]) and veq(apply(adD, C.K[a]), vscale(C.K[a], -1)) for a in range(n)) and all(apply(adD, C.J[pr]) == {} for pr in C.J) and apply(adD, C.D) == {}
    chk('bit', eig_ok and mult == {1: 4, 0: 7, -1: 4}, 'ad D: eigenvalue +1 on P (4), 0 on J + D (7), -1 on K (4): the real 3-grading 4 + 7 + 4 (multiplicities %s)' % mult)
    # Killing form in the X basis [bit] vs textbook matrices [std]
    labs = sorted(C.lab, key=lambda pr: C.lab[pr]); adX = [C.ad({C.lab[pr]: F(1)}) for pr in labs]
    Kb = [[sum(adX[i][r][s] * adX[j][s][r] for r in range(C.G) for s in range(C.G)) for j in range(C.G)] for i in range(C.G)]
    Mstd, Pm, Km, Dm = std_gens(sq6)
    def std_ad(i):
        cols = []
        for j in range(C.G):
            comp = std_components(mcomm(Mstd[labs[i]], Mstd[labs[j]]), sq6); cols.append([comp[pr] for pr in labs])
        return [[cols[j][r] for j in range(C.G)] for r in range(C.G)]
    adS = [std_ad(i) for i in range(C.G)]
    Ks = [[sum(adS[i][r][s] * adS[j][s][r] for r in range(C.G) for s in range(C.G)) for j in range(C.G)] for i in range(C.G)]
    tr4 = [[4 * sum(mmul(Mstd[labs[i]], Mstd[labs[j]])[k][k] for k in range(6)) for j in range(C.G)] for i in range(C.G)]
    diag = [Kb[i][i] for i in range(C.G)]; sig = (sum(1 for x in diag if x > 0), sum(1 for x in diag if x < 0))
    offd = all(Kb[i][j] == 0 for i in range(C.G) for j in range(C.G) if i != j)
    chk('bit==std', Kb == Ks == tr4 and offd and sig == (8, 7), 'Killing form tr(ad ad) from the engine f = from textbook matrices = 4 tr(M M) (N - 2 = 4), diagonal, signature (+8, -7): so(2,4)')
    # the Killing form in the null basis: the P-K pairing is off-diagonal; ratios of the quadratic form on F = W J + T P + C K + G D
    Bk = lambda y, z: sum(y[A] * z[B] * Kb[A][B] for A in y for B in z)
    kJ = Bk(C.J[(0, 1)], C.J[(0, 1)]) / (eta(0, 0) * eta(1, 1)); kPK = Bk(C.P[0], C.K[0]) / eta(0, 0); kD = Bk(C.D, C.D)
    okB = all(Bk(C.P[a], C.P[b]) == 0 and Bk(C.K[a], C.K[b]) == 0 and Bk(C.P[a], C.K[b]) == kPK * eta(a, b) and Bk(C.P[a], C.D) == 0 and Bk(C.K[a], C.D) == 0 for a in range(n) for b in range(n))
    okB &= all(Bk(C.J[p1], C.J[p2]) == (kJ * eta(p1[0], p1[0]) * eta(p1[1], p1[1]) if p1 == p2 else 0) and Bk(C.J[p1], C.D) == 0 and all(Bk(C.J[p1], C.P[a]) == 0 == Bk(C.J[p1], C.K[a]) for a in range(n)) for p1 in C.J for p2 in C.J)
    rW, rTC, rG = kJ / 2, 2 * kPK, kD                                   # coefficients of W^{ab} W_ab (full sum), T^a C_a, G G in B(F, F)
    chk('bit', okB and (rW / rG * -4, rTC / rG * -4) == (2, 8), 'Killing form in the null basis: B(P, P) = B(K, K) = 0, B(P_a, K_b) = %s eta_ab (off-diagonal P-K pairing), B(J_ab, J_ab) = %s eta_aa eta_bb, B(D, D) = %s; '
        'on F = W J + T P + C K + G D: W.W : T.C : G.G = %s : %s : %s = 2 : 8 : -4 (the ratio of (5.1)-(5.2) of arXiv:2602.09664)' % (kPK, kJ, kD, rW, rTC, rG))
    bstd = all(mcomm(Mstd[labs[i]], Mstd[labs[j]]) == (lambda fc: (mscal(Mstd[labs[fc[0]]], F(fc[1], 2)) if fc else mzero(6)))(C.L.f.get((i, j))) for i in range(C.G) for j in range(C.G))
    chk('bit==std', bstd, 'every bracket [M_A, M_B] of the textbook matrices = (1/2) f_AB^C M_C with the engine f: X_A = B_A/2 acts on vectors as (M_AB)^C_D = delta^C_A eta_BD - delta^C_B eta_AD')
    e6 = [F(0)] * 4 + [F(1), F(1)]; o6 = [F(0)] * 4 + [F(1, 2), F(-1, 2)]; dot = lambda u, v: sum(sq6[i] * u[i] * v[i] for i in range(6))
    okstd = dot(e6, e6) == 0 and dot(o6, o6) == 0 and dot(e6, o6) == 1
    okstd &= all(mcomm(Dm, Pm[a]) == Pm[a] and mcomm(Dm, Km[a]) == mscal(Km[a], -1) for a in range(n))
    okstd &= all(mcomm(Pm[a], Pm[b]) == mzero(6) and mcomm(Km[a], Km[b]) == mzero(6) for a in range(n) for b in range(n))
    Jm = lambda a, b: mzero(6) if a == b else (Mstd[(a, b)] if a < b else mscal(Mstd[(b, a)], -1))
    okstd &= all(mcomm(Pm[a], Km[b]) == mscal(madd(mscal(Dm, eta(a, b)), Jm(a, b)), -1) for a in range(n) for b in range(n))
    chk('std', okstd, '[std] matrices: eps.eps = o.o = 0, eps.o = 1 in R^{2,4}; [D, P] = P, [D, K] = -K, [P, P] = [K, K] = 0, [P_a, K_b] = -(eta_ab D + J_ab)')
    # the dictionary to ATL-014: so(2,4) here, so(4,2) there
    Cm = Lie([-s for s in sq6])
    flip = set(C.L.f) == set(Cm.f) and all(Cm.f[k] == (C.L.f[k][0], -C.L.f[k][1]) for k in C.L.f)
    npos = sum(1 for s in sq6 if s > 0); nneg = 6 - npos
    chk('bit', flip and killing_signature(Cm)[0] == killing_signature(C.L)[0] and (npos, nneg) == (2, 4) and gs.cell(2, 4) == 'M4(H)' and gs.cell(4, 2) == 'M8(R)',
        'dictionary: (+,-,-,-,+,-) has two +1 and four -1: Cl(2,4) = %s (engine cell), the Atlas ATL-014 pattern four +1, two -1: Cl(4,2) = %s; the f tables of sq and -sq differ by an overall sign, '
        'so B -> -B is an isomorphism so(2,4) = so(4,2) (Killing signatures equal)' % (gs.cell(2, 4), gs.cell(4, 2)))
    # controls: no null pair
    for pair, name, want in (((1, 1), 'so(3,3)', (9, 6)), ((-1, -1), 'so(1,5)', (5, 10))):
        Cw = Conf(SQ4, pair); bad_pp = any(Cw.br(Cw.P[a], Cw.P[b]) != {} for a in range(n) for b in range(n))
        bad_grade = not all(veq(Cw.br(Cw.D, Cw.P[a]), Cw.P[a]) for a in range(n))
        adw = Cw.ad(Cw.D); adw2 = mmul(adw, adw); mixed = [Cw.lab[(a, 4)] for a in range(n)] + [Cw.lab[(a, 5)] for a in range(n)]
        neg = all(adw2[i][i] < 0 for i in mixed) and all(adw2[i][j] == 0 for i in mixed for j in range(Cw.G) if j != i)
        sw = killing_signature(Cw.L)[0][:2]
        chk('ctl', bad_pp and bad_grade and neg and sw == want, 'pair %s (no null pair): [P, P] != 0, [D, P] != P, (ad X_45)^2 = negative scalar on the 8 mixed bivectors (no real grading); Killing (+%d, -%d) = %s (ok)' % (pair, sw[0], sw[1], name))
    # the de Sitter / anti-de Sitter ladder inside so(2,4): J + (P + lam K) closes
    for lam in (F(-1, 10), F(1, 10)):
        Pi = [vadd(C.P[a], C.K[a], lam) for a in range(n)]
        okc = all(veq(C.br(Pi[a], Pi[b]), vscale(C.Jab(a, b), -2 * lam)) for a in range(n) for b in range(n))
        v = [F(0)] * 4 + [1 + lam / 2, 1 - lam / 2]; v2 = sum(sq6[i] * v[i] * v[i] for i in range(6))
        okv = all(veq(Pi[a], {C.lab[(a, 4)]: v[4] / 2 * 2, C.lab[(a, 5)]: v[5] / 2 * 2}) for a in range(n))
        chk('bit', okc and okv and v2 == 2 * lam, '[P_a + lam K_a, P_b + lam K_b] = -2 lam J_ab (lam = %s): J + (P + lam K) is the algebra of ONE extra generator v = (1 + lam/2) g4 + (1 - lam/2) g5 '
            '(P_a + lam K_a = g_a v / 2) with v^2 = 2 lam = %s: %s inside so(2,4) (the ladder of EQN-015 / MAP-023)' % (lam, v2, 'de Sitter so(1,4), s = -1' if lam < 0 else 'anti-de Sitter so(2,3), s = +1'))
    # Euclid frame with the pair: so(5,1)
    Ce = Conf([1, 1, 1, 1], PAIR); etae = Ce.eta
    oke = all(veq(Ce.br(Ce.D, Ce.P[a]), Ce.P[a]) and veq(Ce.br(Ce.D, Ce.K[a]), vscale(Ce.K[a], -1)) for a in range(n))
    oke &= all(veq(Ce.br(Ce.P[a], Ce.K[b]), vscale(vadd(vscale(Ce.D, etae(a, b)), Ce.Jab(a, b)), -1)) for a in range(n) for b in range(n))
    oke &= all(Ce.br(Ce.P[a], Ce.P[b]) == {} and Ce.br(Ce.K[a], Ce.K[b]) == {} for a in range(n) for b in range(n))
    chk('bit', oke and killing_signature(Ce.L)[0][:2] == (5, 10) and A1.jacobi_bad(Ce.L) == 0, 'Euclid frame (+,+,+,+) with the null pair: so(5,1) = so(1,5) (Killing +5, -10), the same brackets with delta_ab: the Euclidean conformal algebra')
    tick('part 1')
    return C

# ------------------------------------------------------------------------------------------------ part 2: the decomposition identity on random fields
def fit_ratio(Fm, X, Y):
    """the constant c with X = c Y (None if Y = 0 or no such constant)"""
    for m, p in Y.items():
        for k, v in p.items():
            if v != 0:
                c = X.get(m, {}).get(k, F(0)) / v
                return c if feq(Fm, X, Fm.scale(Y, c)) else None
    return None if not fzero(X) else F(0)
def ee_wedge(C, e, f, a, b):
    Fm = C.Gv.Fm; return Fm.add(Fm.wedge(e[a], f[b]), Fm.wedge(e[b], f[a]), -1)
def identity_run(C, seed, label, std_points=((0, 0, 0, 0),)):
    rng = random.Random(seed); n = C.n; Fm = C.Gv.Fm
    om = [gs.rform(rng, n, 1, 1, .5) for _ in range(C.Gl.G)]; e = [gs.rform(rng, n, 1, 1, .5) for _ in range(n)]
    f = [gs.rform(rng, n, 1, 1, .5) for _ in range(n)]; b = gs.rform(rng, n, 1, 1, .5)
    A = compose(C, om, e, f, b); Fx = curvature6(C, A); dec = decompose(C, Fx)
    R = C.Gl.curvature(om); T = C.Gl.torsion(om, e); Df = C.Gl.D_vector(om, f)
    cs = set(); okJ = True
    for (a, bb), X in dec['J'].items():
        c = fit_ratio(Fm, Fm.add(X, R[C.l4[(a, bb)]], -1), ee_wedge(C, e, f, a, bb))
        if c is None: okJ = False
        else: cs.add(c)
    chk('bit', okJ and cs == {F(-1)}, '%s: Lorentz part F^{ab} = R^{ab} + c (e^a f^b - e^b f^a), all 6 components exactly, c = %s' % (label, sorted(cs)))
    mus = set(); okP = True
    for a in range(n):
        mu = fit_ratio(Fm, Fm.add(dec['P'][a], T[a], -1), Fm.wedge(b, e[a]))
        if mu is None: okP = False
        else: mus.add(mu)
    chk('bit', okP and mus == {F(1)}, '%s: P part = T^a + mu b^e^a with T the engine torsion (h table), mu = %s' % (label, sorted(mus)))
    nus = set(); okK = True
    for a in range(n):
        nu = fit_ratio(Fm, Fm.add(dec['K'][a], Df[a], -1), Fm.wedge(b, f[a]))
        if nu is None: okK = False
        else: nus.add(nu)
    chk('bit', okK and nus == {F(-1)}, '%s: K part = D f^a + nu b^f^a with D f the engine D_vector (h table), nu = %s' % (label, sorted(nus)))
    ef = {}
    for a in range(n): ef = Fm.add(ef, Fm.wedge(e[a], f[a]), C.eta(a, a))
    cD = fit_ratio(Fm, Fm.add(dec['D'], Fm.d(b), -1), ef)
    chk('bit', cD == -1, '%s: D part = db + c\' eta_ab e^a f^b, c\' = %s (= c)' % (label, cD))
    chk('ctl', not all(feq(Fm, X, Fm.add(R[C.l4[pr]], ee_wedge(C, e, f, *pr), 1)) for pr, X in dec['J'].items()), '%s: c = +1 in the Lorentz part fails (ok)' % label)
    # [std] the matrix route at the given points
    conn = std_conn_matrices(C.sq, om, e, f, b, C.pairs4); okS = True
    for pt in std_points:
        pt = tuple(F(x) for x in pt); Fs = std_F_at(C.sq, conn, pt)
        for pr, Cc in C.lab.items():
            for (mu, nu), v in Fs[pr].items():
                if peval(Fx[Cc].get((1 << mu) | (1 << nu), {}), pt) != v: okS = False
    chk('bit==std', okS, '%s: the engine curvature of the 6-generator table = the textbook matrix curvature dA + A A (so(p,q) generators, plain derivatives) at %d point(s), all 15 x 6 components' % (label, len(std_points)))
    return dict(om=om, e=e, f=f, b=b, F=Fx)

def part2():
    head('Part 2. The curvature of the larger algebra decomposes: F = (R + c e^f) J + (T + b e) P + (db + c eta e f) D + (Df - b f) K  (random polynomial fields, exact)')
    C = Conf()
    for seed in (11, 12):
        identity_run(C, seed, 'Lorentz seed %d' % seed, std_points=((0, 0, 0, 0), (F(1, 2), F(-1, 3), F(2), F(-3, 4))))
    Ce = Conf([1, 1, 1, 1], PAIR)
    identity_run(Ce, 13, 'Euclid so(5,1) seed 13')
    tick('part 2')

def main():
    part1(); part2()
    finish('H5L-conformal')

if __name__ == '__main__': main()
