#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild pgadyn.json (exact) and the three modules the page imports from it (run from anywhere)
set -e
cd "$(dirname "$0")"
last() { n=$1; shift; out=$("$@") || { printf '%s\n' "$out" >&2; echo "regen: failed: $*" >&2; exit 1; }; printf '%s\n' "$out" | tail -"$n"; }   # run a command, stop on its failure (a pipe into tail would hide it), print its last lines
last 2 python3 pgadyn_selfcheck.py --write pgadyn.json
last 1 python3 pgadyn_selfcheck.py --compare pgadyn.json
cd ..
python3 - <<'PY'
import json
JS_HEADER = '// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n// Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)\n'
d=json.load(open('selfcheck/pgadyn.json'))
open('pgadynData.js','w').write(JS_HEADER+'export default '+json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n')
open('ganjaFixtureData.js','w').write(JS_HEADER+'export default '+json.dumps(json.load(open('selfcheck/ganja_fixture.json')),separators=(',',':'))+';\n')
open('pgadynSelfcheckSource.js','w').write('export const PGA_PY = '+json.dumps(open('selfcheck/pgadyn_selfcheck.py').read(),ensure_ascii=False)+';\n')
PY
echo "regen_pgadyn: done"
