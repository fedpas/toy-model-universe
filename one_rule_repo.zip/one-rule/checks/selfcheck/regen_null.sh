#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild null.json (exact) and the two modules the page imports from it
# Run from anywhere; every path is inside the package; stops at the first error (set -e), and a failing check of the stored json is an error.
set -e
cd "$(dirname "$0")"
last() { n=$1; shift; out=$("$@") || { printf '%s\n' "$out" >&2; echo "regen: failed: $*" >&2; exit 1; }; printf '%s\n' "$out" | tail -"$n"; }   # run a command, stop on its failure (a pipe into tail would hide it), print its last lines
# null_selfcheck.py writes its json BEFORE it counts the passing checks (and exits 1 after), so it writes into a new file, and that file replaces null.json only when both runs passed:
# a failing check leaves the stored null.json (and the modules below) as they were.
NEW=null.json.new
trap 'rm -f "$NEW"' EXIT
last 2 python3 null_selfcheck.py --write "$NEW"
last 1 python3 null_selfcheck.py --compare "$NEW"
mv "$NEW" null.json
cd ..
python3 - <<'PY'
import json
JS_HEADER = '// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n// Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)\n'
d=json.load(open('selfcheck/null.json'))
open('nullData.js','w').write(JS_HEADER+'export default '+json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n')
open('nullSelfcheckSource.js','w').write('export const NULL_PY = '+json.dumps(open('selfcheck/null_selfcheck.py').read(),ensure_ascii=False)+';\n')
PY
echo "regen_null: done"
