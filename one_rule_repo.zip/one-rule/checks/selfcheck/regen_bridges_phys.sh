#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild selfcheck/bridges/bridges_phys.json, the log of the physics bridge scripts (phy_, str_, sol_, xph_, fk_, mjp_ of selfcheck/bridges/, see its README.md):
# every script runs once, one at a time on one core, and the json holds each printed line (id, script, kind check or info, text, ok), the processor
# seconds each script took (user + system time of the run, rounded to 0.1 s; the only part of the json that changes from run to run), the modules
# each script imports, and the counts.
# Run from anywhere; every path is inside the package; stops at the first error (set -e): a script that exits non-zero, a FAIL line, a line that is
# neither a check line nor the verdict, or a verdict that does not count the lines leaves the stored json as it was.
set -e
cd "$(dirname "$0")/bridges"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1   # one core; no __pycache__ next to the scripts
python3 -I - <<'PY'
import ast, json, os, re, resource, subprocess, sys
# the scripts in the order they run; phy_bitrule.py is the engine five phy_ scripts import (no check of its own)
SCRIPTS = ['phy_cell_vs_signature.py', 'phy_horizon_little_group.py', 'phy_dirac.py', 'phy_trio.py', 'phy_staggered.py', 'phy_coupled_action.py',
           'str_clock.py', 'str_spinors.py', 'str_dualities.py', 'str_lattices.py', 'str_syk.py', 'str_null.py', 'str_extra.py',
           'sol_fk_clock.py', 'sol_furey_fk.py', 'sol_null_bands.py', 'sol_maxwell_media.py', 'sol_lattice_springs.py', 'sol_point_groups.py',
           'sol_abs_tenfold.py', 'sol_kitaev_lieb.py', 'sol_hubbard_cube.py', 'xph_clock_crosscheck.py', 'xph_null_join.py', 'fk_junction.py',
           'mjp_fock.py', 'mjp_charges.py', 'mjp_action.py', 'mjp_time.py', 'mjp_clock.py', 'mjp_ladder.py']
PREFIXES = ['phy', 'str', 'sol', 'xph', 'fk', 'mjp']   # the families, in the order of the scripts
LIBS = {'phy_bitrule'}
family = sorted(f for f in os.listdir('.') if re.match(r'(' + '|'.join(PREFIXES) + r')_\w+\.py$', f) and f[:-3] not in LIBS)
if sorted(SCRIPTS) != family: sys.exit('regen_bridges_phys: the list of scripts differs from the folder: ' + ' '.join(sorted(set(SCRIPTS) ^ set(family))))
def imports(f):
    out = set()
    for node in ast.walk(ast.parse(open(f, encoding='utf-8').read())):
        if isinstance(node, ast.Import): out |= {a.name.split('.')[0] for a in node.names}
        elif isinstance(node, ast.ImportFrom): out.add(node.module.split('.')[0])
    return sorted(out)
LINE = re.compile(r'^(ok   |FAIL |info )(bd·(?:' + '|'.join(PREFIXES) + r')·\d+[a-z]?)  (.+)$')
rows, scripts = [], []
for f in SCRIPTS:
    imp = imports(f); std = all(m in sys.stdlib_module_names for m in imp)
    cpu = lambda: (lambda u: u.ru_utime + u.ru_stime)(resource.getrusage(resource.RUSAGE_CHILDREN))
    t0 = cpu(); r = subprocess.run([sys.executable] + (['-I'] if std else []) + [f], capture_output=True, text=True); dt = round(cpu() - t0, 1)
    if r.returncode != 0: sys.exit(f'regen_bridges_phys: {f} exits {r.returncode}\n{r.stdout[-2000:]}{r.stderr[-2000:]}')
    lines = [l for l in r.stdout.split('\n') if l.strip()]
    mine = []
    for l in lines[:-1]:
        m = LINE.match(l)
        if not m or m.group(1) == 'FAIL ': sys.exit(f'regen_bridges_phys: {f} prints a line that is not an ok or info line: {l[:200]}')
        mine.append({'id': m.group(2), 'script': f, 'kind': 'info' if m.group(1) == 'info ' else 'check', 'text': m.group(3), 'ok': True, 'seconds': dt})
    n = sum(r_['kind'] == 'check' for r_ in mine)
    if lines[-1] != f'{n}/{n} bridge checks hold.  ALL BRIDGE CHECKS PASS': sys.exit(f'regen_bridges_phys: {f}: the verdict line is not "{n}/{n} bridge checks hold.  ALL BRIDGE CHECKS PASS": {lines[-1]}')
    rows += mine
    scripts.append({'script': f, 'checks': n, 'info': len(mine) - n, 'seconds': dt, 'imports': imp, 'isolated': std})
    print(f'{f}: {n} checks, {len(mine) - n} info, {dt} s')
ids = [r_['id'] for r_ in rows]
if len(ids) != len(set(ids)): sys.exit('regen_bridges_phys: an id is printed twice: ' + ' '.join(sorted({i for i in ids if ids.count(i) > 1})))
d = {'rows': rows, 'scripts': scripts,
     'summary': {'scripts': len(scripts), 'checks': sum(s['checks'] for s in scripts), 'info': sum(s['info'] for s in scripts), 'ok': sum(r_['kind'] == 'check' and r_['ok'] for r_ in rows), 'seconds': round(sum(s['seconds'] for s in scripts), 1)}}
open('bridges_phys.json.new', 'w', encoding='utf-8').write(json.dumps(d, ensure_ascii=False, indent=1) + '\n')
os.replace('bridges_phys.json.new', 'bridges_phys.json')
print(f"regen_bridges_phys: {d['summary']['scripts']} scripts, {d['summary']['checks']} checks, {d['summary']['info']} info lines, {d['summary']['seconds']} s: done")
PY
