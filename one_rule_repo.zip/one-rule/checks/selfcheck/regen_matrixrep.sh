#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild matrixrep.json (exact, standard library, ~8 s) and the two modules the app imports from it (run from anywhere)
set -e
cd "$(dirname "$0")"
last() { n=$1; shift; out=$("$@") || { printf '%s\n' "$out" >&2; echo "regen: failed: $*" >&2; exit 1; }; printf '%s\n' "$out" | tail -"$n"; }   # run a command, stop on its failure (a pipe into tail would hide it), print its last lines
last 1 python3 matrixrep_check.py --write matrixrep.json
cd ..
python3 - <<'PY'
import json
JS_HEADER = '// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n// Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)\n'
d=json.load(open('selfcheck/matrixrep.json')); d.pop('fixtures')          # the fixtures stay in the json (tests); the app does not need them
open('matrixrepData.js','w').write(JS_HEADER+'export default '+json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':'))+';\n')
open('matrixrepSelfcheckSource.js','w').write('export const MATRIXREP_PY = '+json.dumps(open('selfcheck/matrixrep_check.py').read(),ensure_ascii=False)+';\n')
PY
echo "regen_matrixrep: done"
