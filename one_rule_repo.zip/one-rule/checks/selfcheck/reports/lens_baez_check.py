#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The pictures of the Baez chapter (step 19 of the lenses page), checked exactly: every number the widgets BW1-BW7 show as "stored" is rebuilt here
with integers and fractions (Python standard library only), and the browser engine baezEngine.js is tested against the JSON this script writes.

  python3 lens_baez_check.py                    run the checks (one line per check, a count at the end, exit 1 on a failure)
  python3 lens_baez_check.py --write f.json     also write the widget data
  python3 lens_baez_check.py --compare f.json   also check that the data equals the file

Check ids (namespaced bzw. on the page; the report's own script is baez_check.py, ids baez.H1a ...):
  P1  the 32 five-bit labels (bits 0,1 weak, bits 2,3,4 colour): parity, (weak, colour) counts, the six classes of the 16 even labels with sizes 1,3,6,2,1,3,
      Y = a/2 - b/3, Q = (first weak bit) - b/3, Peirce values 1 - d(x,S)/4, the anomaly sums, the complement mask 11111 flips Y and Q   (BW1)
  P1b the five-mode Fock operators on the labels: pair creation, moves, pair annihilation shift the number of set bits by +2, 0, -2 (10 + 25 + 10 = 45,
      independent); for every even S the values 1 - d(x,S)/4 on the 16 even labels have the counts 1, 10, 5 of the grade-1 roots of E6 (baez.E2a)
  P2  the 27 split by the Casimir classes of two su(3) + su(2): the gauge-group paper's (from the explicit action of its Lemma 4, by exact weight
      branching; equal to the numerical output of baez.S2) and the E7 paper's (from the E8 roots); sums 2+4+3+6+12 = 27 = 3+6+0+12+6   (BW2)
  P2b the stabiliser dimensions inside f4 that baez.O3e computes numerically (52, 28, 16, 36, 18, 12), stored, with their hand-checkable sums
  P3  the E8 ladder: D8 u (D8 + 1/2) has 240 roots; deleting alpha_8 ... alpha_4: 240, 126, 72, 40, 20, 8 roots, grade-1 sizes 56, 27, 16, 10, 6;
      the first step 5-graded, the others 3-graded   (BW3)
  P3b the grade-1 pieces under the su(3) + su(2) of the E7 paper (nodes alpha_1, alpha_3; alpha_2), nested 6 < 10 < 16 < 27 (as baez.S1)
  P3c the common-neighbour chain of mutually adjacent E8 roots: 240, 56, 27, 16, 10, 6, 3 (as fibre.G8b)
  P4  Kepler: for eps = +1, 0, -1 the Killing signatures (0,6,0), (0,3,3), (3,3,0) of the bivectors of the squares (+1,+1,+1,eps), the squares of the
      six moves e_j e_k (turn -1, slide 0, stretch +1); the shells n^2 and 2 n^2   (BW4)
  P4b the brackets [L,L] = L, [L,M] = M, [M,M] = eps L, and for eps = +1 the halves A, B = (L +- M)/2 commute (as baez.K1b, K1c)
  P5  the empty ring: Eisenstein rings 0..7 hold 1, 6, 0, 6, 6, 0, 0, 12 points; the 126 shadows of E7 fall 30/90/6 on rings 0/1/3; the Madelung
      order closes the rows at 2, 10, 18, 36, 54, 86, 118   (BW6, BW7)
Nothing here is a statement about nature: counts, branchings and brackets of finite structures, for the embeddings the papers use."""
import argparse, itertools, json, sys
from fractions import Fraction as Fr
from collections import Counter

N_OK = N_BAD = 0
def chk(cid, cond, msg):
    global N_OK, N_BAD
    if cond: N_OK += 1
    else: N_BAD += 1
    print(('ok   ' if cond else 'FAIL ') + cid + ': ' + msg)
pc = lambda x: bin(x).count('1')
S = lambda q: str(Fr(q))                                                   # exact rational as text: '1/6', '-2/3', '0'

# ---------------------------------------------------------------- the bit rule (the same as labelsEngine.bladeMul)
def reorder(a, b):                                                         # (-1)^#{(i in a, j in b): j < i}
    s, x = 0, a >> 1
    while x: s += pc(x & b); x >>= 1
    return -1 if s & 1 else 1
def blade_mul(a, b, sq):
    s, c, i = reorder(a, b), a & b, 0
    while c:
        if c & 1: s *= sq[i]
        c >>= 1; i += 1
    return a ^ b, s
def mv_mul(x, y, sq):
    out = {}
    for a, u in x.items():
        for b, v in y.items():
            c, s = blade_mul(a, b, sq)
            if s: out[c] = out.get(c, 0) + s * u * v
    return {k: v for k, v in out.items() if v != 0}
def mv_add(x, y, f=1):
    out = dict(x)
    for k, v in y.items(): out[k] = out.get(k, 0) + f * v
    return {k: v for k, v in out.items() if v != 0}
def mv_scale(x, f): return {k: f * v for k, v in x.items() if f * v != 0}
def comm(x, y, sq): return mv_add(mv_mul(x, y, sq), mv_mul(y, x, sq), -1)

# ---------------------------------------------------------------- exact linear algebra
def charpoly(M):                                                           # Faddeev-LeVerrier, exact: coefficients c_n = 1, ..., c_0 of det(t - M)
    n = len(M); I = [[Fr(int(i == j)) for j in range(n)] for i in range(n)]
    mm = lambda A, B: [[sum(A[i][k] * B[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
    c = [Fr(0)] * (n + 1); c[n] = Fr(1); Mk = [[Fr(0)] * n for _ in range(n)]
    for k in range(1, n + 1):
        Mk = mm(M, Mk); Mk = [[Mk[i][j] + c[n - k + 1] * I[i][j] for j in range(n)] for i in range(n)]
        c[n - k] = -sum(mm(M, Mk)[i][i] for i in range(n)) / k
    return c
def inertia(M):                                                            # (positive, negative, zero) eigenvalue counts of a real symmetric matrix, exactly:
    c = charpoly([[Fr(v) for v in r] for r in M]); n = len(M)              # all roots are real, so Descartes' rule of signs counts them exactly
    z = next(k for k in range(n + 1) if c[k] != 0)
    sgn = lambda seq: sum(1 for u, v in zip(seq, seq[1:]) if u * v < 0)
    nz = [v for v in c[z:] if v != 0]; nneg = [v * (-1) ** k for k, v in enumerate(c) if k >= z and v != 0]
    return sgn(nz), sgn(nneg), z
def rank(rows):
    R = [[Fr(v) for v in r] for r in rows]; rk, col, m = 0, 0, len(R[0]) if R else 0
    while rk < len(R) and col < m:
        p = next((i for i in range(rk, len(R)) if R[i][col] != 0), None)
        if p is None: col += 1; continue
        R[rk], R[p] = R[p], R[rk]
        for i in range(len(R)):
            if i != rk and R[i][col] != 0:
                f = R[i][col] / R[rk][col]; R[i] = [u - f * w for u, w in zip(R[i], R[rk])]
        rk += 1; col += 1
    return rk

# ================================================================ E8 in doubled integer coordinates (inner product = dot / 4), Bourbaki simple roots
ROOTS = sorted({tuple(v) for i, j in itertools.combinations(range(8), 2) for si in (2, -2) for sj in (2, -2)
                for v in [[si if t == i else sj if t == j else 0 for t in range(8)]]} |
               {s for s in itertools.product((1, -1), repeat=8) if sum(1 for u in s if u < 0) % 2 == 0}, reverse=True)
SIMPLE = [(1, -1, -1, -1, -1, -1, -1, 1), (2, 2, 0, 0, 0, 0, 0, 0), (-2, 2, 0, 0, 0, 0, 0, 0), (0, -2, 2, 0, 0, 0, 0, 0), (0, 0, -2, 2, 0, 0, 0, 0),
          (0, 0, 0, -2, 2, 0, 0, 0), (0, 0, 0, 0, -2, 2, 0, 0), (0, 0, 0, 0, 0, -2, 2, 0)]
ip = lambda u, v: sum(a * b for a, b in zip(u, v)) // 4
CARTAN = [[ip(u, v) for v in SIMPLE] for u in SIMPLE]
def inverse(M):
    n = len(M); A = [[Fr(v) for v in r] + [Fr(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[p] = A[p], A[c]; A[c] = [v / A[c][c] for v in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0: f = A[i][c]; A[i] = [u - f * w for u, w in zip(A[i], A[c])]
    return [r[n:] for r in A]
CINV = inverse(CARTAN)
def coef(r):                                                               # r = sum c_i alpha_i, c = C^-1 (<r, alpha_j>)
    d = [ip(r, a) for a in SIMPLE]; c = [sum(CINV[i][j] * d[j] for j in range(8)) for i in range(8)]
    assert all(x.denominator == 1 for x in c); return tuple(int(x) for x in c)
COEF = {r: coef(r) for r in ROOTS}
levi = lambda n: [r for r in ROOTS if all(COEF[r][m] == 0 for m in range(n, 8))]          # the roots in the span of alpha_1 .. alpha_n
g1 = lambda n: [r for r in levi(n) if COEF[r][n - 1] == 1]                                # grade +1 for the coefficient of alpha_n

# ================================================================ P1: five-bit labels and one generation (baez.H1a-H2d)
a_of = lambda x: pc(x & 3); b_of = lambda x: pc(x >> 2)
Yf = lambda x: Fr(a_of(x), 2) - Fr(b_of(x), 3)
Qf = lambda x: (x & 1) - Fr(b_of(x), 3)
T3f = lambda x: Fr((x & 1) - ((x >> 1) & 1), 2)
peirce = lambda x, s: 1 - Fr(pc(x ^ s), 4)
S_WEAK = 0b00011
PAPER = {(Fr(1, 2), Fr(1)): ('e-bar_R', 1, Fr(1)), (Fr(1), Fr(1, 2)): ('nu-bar_R', 1, Fr(0)), (Fr(1, 2), Fr(1, 2)): ('q_L', 6, Fr(1, 6)),
         (Fr(0), Fr(1, 2)): ('d-bar_R', 3, Fr(1, 3)), (Fr(1, 2), Fr(0)): ('u-bar_R', 3, Fr(-2, 3)), (Fr(0), Fr(0)): ('l_L', 2, Fr(-1, 2))}   # eqs. (69), (76)
def part_p1():
    lab = range(32); even = [x for x in lab if pc(x) % 2 == 0]
    grading = [sum(1 for x in lab if pc(x) == k) for k in range(6)]
    cls = {}
    for x in even: cls.setdefault((a_of(x), b_of(x)), []).append(x)
    order = sorted(cls)
    pieces = {}
    for k in order:
        pairs = {(peirce(x, 0), peirce(x, S_WEAK)) for x in cls[k]}; pieces[k] = PAPER.get(pairs.pop()) if len(pairs) == 1 else None
    ok = grading == [1, 5, 10, 10, 5, 1] and len(even) == 16 and [len(cls[k]) for k in order] == [1, 3, 6, 2, 1, 3] and order == [(0, 0), (0, 2), (1, 1), (1, 3), (2, 0), (2, 2)]
    ok &= all(pieces[k] is not None and pieces[k][1] == len(cls[k]) and all(Yf(x) == pieces[k][2] for x in cls[k]) for k in order)
    ok &= {pieces[k][0] for k in order} == {v[0] for v in PAPER.values()}
    ok &= all(Qf(x) == T3f(x) + Yf(x) for x in lab)
    sums = dict(Y=sum(Yf(x) for x in even), Q=sum(Qf(x) for x in even), Y3=sum(Yf(x) ** 3 for x in even),
                Y_doublets=sum(Yf(x) for x in even if a_of(x) == 1), Y_triplets=sum(Yf(x) for x in even if b_of(x) in (1, 2)))
    ok &= all(v == 0 for v in sums.values())
    flip = all((x ^ 31) ^ 31 == x and pc(x ^ 31) % 2 != pc(x) % 2 and a_of(x ^ 31) == 2 - a_of(x) and b_of(x ^ 31) == 3 - b_of(x)
               and Yf(x ^ 31) == -Yf(x) and Qf(x ^ 31) == -Qf(x) for x in lab)
    ok &= flip
    qsets = {pieces[k][0]: sorted({Qf(x) for x in cls[k]}) for k in order}
    ok &= qsets == {'e-bar_R': [1], 'nu-bar_R': [0], 'q_L': [Fr(-1, 3), Fr(2, 3)], 'd-bar_R': [Fr(1, 3)], 'u-bar_R': [Fr(-2, 3)], 'l_L': [-1, 0]}
    chk('P1', ok, 'the 32 five-bit labels (bits 0,1 weak, 2,3,4 colour) graded 1, 5, 10, 10, 5, 1; the 16 even labels by (weak bits a, colour bits b) = '
        + ', '.join(f'({a},{b}) {len(cls[(a, b)])} {pieces[(a, b)][0]}' for a, b in order) + ': sizes 1, 3, 6, 2, 1, 3, each class one Peirce pair (1 - d(x,vacuum)/4, 1 - d(x,weak pair)/4) '
        'of the paper\'s eq. (69) with its hypercharge; Y = a/2 - b/3, Q = (first weak bit) - b/3 = T3 + Y on all 32; sums over the 16: '
        + ', '.join(f'{k} {S(v)}' for k, v in sums.items()) + '; XOR 11111 swaps even and odd, a -> 2 - a, b -> 3 - b, and flips Y and Q on all 32 labels')
    labels = [dict(x=x, a=a_of(x), b=b_of(x), N=pc(x), even=pc(x) % 2 == 0, Y=S(Yf(x)), Q=S(Qf(x)), T3=S(T3f(x)),
                   l1=S(peirce(x, 0)) if pc(x) % 2 == 0 else None, l2=S(peirce(x, S_WEAK)) if pc(x) % 2 == 0 else None,
                   piece=pieces[(a_of(x), b_of(x))][0] if pc(x) % 2 == 0 else None) for x in lab]
    classes = [dict(a=a, b=b, n=len(cls[(a, b)]), piece=pieces[(a, b)][0], Y=S(pieces[(a, b)][2]), Q=[S(q) for q in qsets[pieces[(a, b)][0]]],
                    l1=S(peirce(cls[(a, b)][0], 0)), l2=S(peirce(cls[(a, b)][0], S_WEAK)), labels=cls[(a, b)]) for a, b in order]
    # P1b: the Fock operators (Jordan-Wigner sign) and the number of set bits
    def op(seq):                                                          # seq of ('c'|'a', i), applied right to left
        out = {}
        for x in lab:
            y, s = x, 1
            for kind, i in reversed(seq):
                if ((y >> i) & 1) == (kind == 'c'): s = 0; break
                s *= (-1) ** pc(y & ((1 << i) - 1)); y ^= 1 << i
            if s: out[x] = (y, s)
        return out
    ops = [(2, op([('c', i), ('c', j)])) for i, j in itertools.combinations(range(5), 2)] + [(0, op([('c', i), ('a', j)])) for i in range(5) for j in range(5)] \
        + [(-2, op([('a', i), ('a', j)])) for i, j in itertools.combinations(range(5), 2)]
    deg_ok = all(m and all(pc(y) - pc(x) == d for x, (y, s) in m.items()) for d, m in ops)
    vec = lambda m: [m[x][1] if x in m and m[x][0] == y else 0 for x in lab for y in lab]
    rk = rank([vec(m) for _, m in ops])
    adn = Counter(d for d, _ in ops)
    roots16 = g1(6)
    pe_lab = {s: Counter(peirce(x, s) for x in even) for s in even}
    pe_root = {tuple(sorted(Counter(ip(g, b) for g in roots16).items())) for b in roots16}
    ok2 = deg_ok and rk == 45 and adn == Counter({2: 10, 0: 25, -2: 10}) and all(c == Counter({1: 1, Fr(1, 2): 10, 0: 5}) for c in pe_lab.values()) \
        and pe_root == {((0, 5), (1, 10), (2, 1))} and len(roots16) == 16
    chk('P1b', ok2, 'Fock operators on the 32 labels (Jordan-Wigner sign): pair creation a_i+ a_j+ (10), moves a_i+ a_j (25), pair annihilation a_i a_j (10) change the number of '
        f'set bits by exactly +2, 0, -2: ad N degrees 10 + 25 + 10, rank {rk} = 45 = dim so(10); for every even label S the values 1 - d(x,S)/4 on the 16 even labels are 1, 1/2, 0 '
        'with counts 1, 10, 5, the counts of <gamma,beta>/2 on the 16 grade-1 roots of E6 for every beta (baez.E2a)')
    return dict(grading=grading, sizes=[len(cls[k]) for k in order], labels=labels, classes=classes, sums={k: S(v) for k, v in sums.items()}, adN={str(k): adn[k] for k in (2, 0, -2)})

# ================================================================ P3: the ladder, its grade-1 pieces under su(3) + su(2), the link chain
SU3W = {'1': [(0, 0)], '3': [(1, 0), (-1, 1), (0, -1)], '3b': [(0, 1), (1, -1), (-1, 0)]}
SU2W = {'1': [0], '2': [1, -1]}
def dec_sm(rs):                                                            # highest-weight peeling of Dynkin labels (alpha_1, alpha_3 | alpha_2), as baez.S1
    pool = Counter((ip(r, SIMPLE[0]), ip(r, SIMPLE[2]), ip(r, SIMPLE[1])) for r in rs); out = Counter(); rais = [(2, -1, 0), (-1, 2, 0), (0, 0, 2)]
    while pool:
        w = sorted(w for w in pool if all(tuple(u + v for u, v in zip(w, r)) not in pool for r in rais))[0]
        s3 = {(0, 0): '1', (1, 0): '3', (0, 1): '3b'}.get(w[:2]); s2 = {0: '1', 1: '2'}.get(w[2])
        if s3 is None or s2 is None: return None
        for a in SU3W[s3]:
            for b in SU2W[s2]:
                t = (a[0], a[1], b)
                if pool[t] <= 0: return None
                pool[t] -= 1
                if pool[t] == 0: del pool[t]
        out[(s3, s2)] += 1
    return out
DIMSM = lambda k: {'1': 1, '3': 3, '3b': 3}[k[0]] * {'1': 1, '2': 2}[k[1]]
def part_p3():
    sizes = [len(levi(n)) for n in (8, 7, 6, 5, 4, 3)]; dims = [n + s for n, s in zip((8, 7, 6, 5, 4, 3), sizes)]; gs = [len(g1(n)) for n in (8, 7, 6, 5, 4)]
    grades = {n: Counter(COEF[r][n - 1] for r in levi(n)) for n in (8, 7, 6, 5, 4)}
    graded = [len(grades[n]) for n in (8, 7, 6, 5, 4)]
    ok = len(ROOTS) == 240 and sum(1 for r in ROOTS if max(map(abs, r)) == 2) == 112 and all(sum(v * v for v in r) == 8 for r in ROOTS)
    ok &= all(all(c >= 0 for c in COEF[r]) or all(c <= 0 for c in COEF[r]) for r in ROOTS) and sum(1 for r in ROOTS if sum(COEF[r]) > 0) == 120
    ok &= sizes == [240, 126, 72, 40, 20, 8] and dims == [248, 133, 78, 45, 24, 11] and gs == [56, 27, 16, 10, 6] and graded == [5, 3, 3, 3, 3]
    ok &= grades[8] == Counter({-2: 1, -1: 56, 0: 126, 1: 56, 2: 1}) and all(len(levi(n)) == len(levi(n - 1)) + 2 * len(g1(n)) for n in (7, 6, 5, 4))
    chk('P3', ok, 'E8 = D8 u (D8 + 1/2): 112 + 128 = 240 roots of squared length 2, every root a non-negative or non-positive integer combination of the Bourbaki simple roots (120 positive); '
        f'deleting alpha_8, alpha_7, ...: roots {sizes}, dimensions {dims}, grade-1 sizes {gs}; the step from E8 has grades -2..2 with 1, 56, 126, 56, 1 roots (5-graded: 240 = 126 + 2 x 56 + 2), '
        'the others grades -1..1 (3-graded: 126 = 72 + 2 x 27, 72 = 40 + 2 x 16, 40 = 20 + 2 x 10, 20 = 8 + 2 x 6)')
    dec = {n: dec_sm(g1(n)) for n in (4, 5, 6, 7)}
    exp = {4: {('3', '2'): 1}, 5: {('3', '2'): 1, ('3b', '1'): 1, ('1', '1'): 1}, 6: {('3', '2'): 1, ('3b', '1'): 2, ('1', '2'): 1, ('1', '1'): 2},
           7: {('3', '2'): 1, ('3b', '1'): 3, ('3', '1'): 1, ('1', '2'): 3, ('1', '1'): 3}}
    ok = all(dec[n] is not None and dict(dec[n]) == exp[n] and sum(DIMSM(k) * m for k, m in dec[n].items()) == len(g1(n)) for n in exp)
    ok &= all(all(dec[n][k] >= m for k, m in dec[n - 1].items()) for n in (5, 6, 7))
    chk('P3b', ok, 'under su(3) (alpha_1, alpha_3) + su(2) (alpha_2) of the E7 paper the grade-1 pieces split as 6 = (3,2); 10 = (3,2) + (3b,1) + (1,1); 16 = (3,2) + 2 (3b,1) + (1,2) + 2 (1,1); '
        '27 = (3,2) + 3 (3b,1) + (3,1) + 3 (1,2) + 3 (1,1), each containing the previous one (the same peeling as baez.S1; 3 and 3b depend on a sign convention for the weights)')
    nb = {r: {s for s in ROOTS if ip(r, s) == 1} for r in ROOTS}
    level, chain, sizes_l = set(ROOTS), [], [240]
    while len(level) > 3:
        r = max(level); chain.append(r); level = level & nb[r]; sizes_l.append(len(level))
    first = {len(nb[r]) for r in ROOTS}; second = {len(nb[chain[0]] & nb[s]) for s in nb[chain[0]]}
    chk('P3c', sizes_l == [240, 56, 27, 16, 10, 6, 3] and first == {56} and second == {27},
        f'a chain of mutually adjacent E8 roots (inner product 1): common neighbours {sizes_l} (every first root has 56 neighbours and, for the first root chosen, every second root leaves 27): '
        'the same numbers as the grade-1 sizes 56, 27, 16, 10, 6 (as fibre.G8b; deeper choices: one chain)')
    return dict(roots=len(ROOTS), sizes=sizes, dims=dims, g1=gs, graded=graded, grades8={str(k): grades[8][k] for k in sorted(grades[8])}, links=sizes_l,
                dec={str(n): [dict(su3=k[0], su2=k[1], m=dec[n][k], dim=DIMSM(k)) for k in sorted(dec[n])] for n in (4, 5, 6, 7)})

# ================================================================ P2: the 27 under two su(3) + su(2)
CAS3 = {'1': Fr(0), '3': Fr(4, 9), '3b': Fr(4, 9)}; CAS2 = {1: Fr(0), 2: Fr(3, 8), 3: Fr(1)}     # Casimirs normalised to 1 on the adjoint
CLASSES = [(Fr(0), Fr(0)), (Fr(0), Fr(3, 8)), (Fr(0), Fr(1)), (Fr(4, 9), Fr(0)), (Fr(4, 9), Fr(3, 8))]   # singlet, weak doublet, weak triplet, colour triplet, colour triplet + doublet
S2_STORED = {(Fr(0), Fr(0)): 2, (Fr(0), Fr(3, 8)): 4, (Fr(0), Fr(1)): 3, (Fr(4, 9), Fr(0)): 6, (Fr(4, 9), Fr(3, 8)): 12}  # numerical output of baez_check.py S2
def su2_peel(t3s):                                                         # doubled T3 values -> list of su(2) dimensions
    pool, out = Counter(t3s), []
    while pool:
        top = max(pool); out.append(top + 1)
        for m in range(top, -top - 1, -2):
            pool[m] -= 1
            if pool[m] == 0: del pool[m]
            if pool[m] < 0: raise ValueError
    return out
def f4_side():                                                             # Lemma 4: 27 (x) C = (1,1) + (1,8) + (3,3b) + (3b,3) of SU(3)_colour x SU(3)_g, su(2) + u(1) inside SU(3)_g on e1, e2
    w3 = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]; w3b = [tuple(-v for v in w) for w in w3]
    w8 = [tuple(a - b for a, b in zip(u, v)) for u in w3 for v in w3 if u != v] + [(0, 0, 0)] * 2
    out = Counter()
    for col, wg in (('1', [(0, 0, 0)]), ('1', w8), ('3', w3b), ('3b', w3)):
        for d in su2_peel([w[0] - w[1] for w in wg]):
            out[(CAS3[col], CAS2[d])] += {'1': 1, '3': 3, '3b': 3}[col] * d
    return out
def part_p2():
    f4 = f4_side(); dec = {n: dec_sm(g1(n)) for n in (6, 7)}
    def tab(d):                                                            # states per Casimir class of a decomposition {(su3, su2): multiplicity}
        c = Counter()
        for k, m in d.items(): c[(CAS3[k[0]], CAS2[int(k[1])])] += m * DIMSM(k)
        return [c[k] for k in CLASSES]
    e7, e16 = tab(dec[7]), tab(dec[6]); e11 = [u - v for u, v in zip(e7, e16)]; f = [f4[k] for k in CLASSES]
    ok = f == [S2_STORED[k] for k in CLASSES] == [2, 4, 3, 6, 12] and e7 == [3, 6, 0, 12, 6] and sum(f) == 27 == sum(e7) and f != e7
    ok &= e16 == [2, 2, 0, 6, 6] and e11 == [1, 4, 0, 6, 0] and sum(e16) == 16 and sum(e11) == 11
    chk('P2', ok, f'the 27 by Casimir class (singlet, weak doublet, weak triplet, colour triplet, colour triplet with weak doublet): gauge-group paper {f} (exact weight branching of the action in its Lemma 4; '
        f'equal to the numerical output of baez.S2), E7 paper {e7} (from the E8 roots); 2+4+3+6+12 = 27 = 3+6+0+12+6: different tables, so the two subalgebras are not conjugate in e6; '
        f'inside the E7 paper\'s 27 the 16 of one generation is {e16} and the 11 further states {e11}. Lie algebras, regular embeddings only')
    stab = dict(f4=52, frame=28, B=16, A=36, X=18, SM=12)                  # numerical output of baez_check.py O3e (stored)
    c2 = lambda n: n * (n - 1) // 2
    chk('P2b', stab['frame'] == c2(8) and stab['B'] == 8 + 8 and stab['A'] == c2(9) and stab['X'] == c2(3) + c2(6) and stab['SM'] == 8 + 3 + 1 and stab['f4'] == 52 and stab['X'] != stab['A'],
        'stored dimensions of the stabilisers inside f4 (52), computed numerically by baez.O3e: Jordan frame 28 = dim so(8), B = h3(C) 16 = 8 + 8, A = h2(O) 36 = dim spin(9), '
        'X = h2(C) 18 = dim so(3) + dim so(6) (18, not 36), X with B 12 = 8 + 3 + 1')
    return dict(classes=[[S(a), S(b)] for a, b in CLASSES], f4=f, e7=e7, e7_16=e16, e7_11=e11, stab=stab)

# ================================================================ P4: Kepler, the trio of the fourth square
def part_p4():
    res, okb = {}, True
    for eps in (1, 0, -1):
        sq = (1, 1, 1, eps)
        L = [{0b0110: Fr(-1, 2)}, {0b0101: Fr(1, 2)}, {0b0011: Fr(-1, 2)}]; M = [{0b1001: Fr(-1, 2)}, {0b1010: Fr(-1, 2)}, {0b1100: Fr(-1, 2)}]
        for j, k in ((0, 1), (1, 2), (2, 0)):
            l = 3 - j - k
            okb &= comm(L[j], L[k], sq) == L[l] and comm(L[j], M[k], sq) == M[l] and comm(M[j], M[k], sq) == mv_scale(L[l], eps)
        basis = L + M
        def co(x):
            out = []
            for b in basis:
                (m, v), = b.items(); out.append(Fr(x.get(m, 0)) / v)
            assert sum(1 for b in basis for m in x if m in b) == len(x); return out
        ad = [[co(comm(x, y, sq)) for y in basis] for x in basis]           # ad[a][b] = coordinates of [x_a, x_b]: column b of ad(x_a)
        adm = [[[ad[a][b][i] for b in range(6)] for i in range(6)] for a in range(6)]
        kill = [[sum(adm[a][i][k] * adm[b][k][i] for i in range(6) for k in range(6)) for b in range(6)] for a in range(6)]
        moves = [blade_mul(m, m, sq)[1] for m in (0b0011, 0b0101, 0b0110, 0b1001, 0b1010, 0b1100)]
        res[eps] = dict(killing=list(inertia(kill)), squares=moves, turn=moves.count(-1), slide=moves.count(0), stretch=moves.count(1))
        if eps == 1:
            A = [mv_scale(mv_add(L[i], M[i]), Fr(1, 2)) for i in range(3)]; B = [mv_scale(mv_add(L[i], M[i], -1), Fr(1, 2)) for i in range(3)]
            okb &= all(comm(A[j], A[k], sq) == A[3 - j - k] and comm(B[j], B[k], sq) == B[3 - j - k] for j, k in ((0, 1), (1, 2), (2, 0))) and all(comm(a, b, sq) == {} for a in A for b in B)
    shells = [sum(2 * l + 1 for l in range(n)) for n in range(1, 8)]; spin = [n * (n + 1) + n * (n - 1) for n in range(1, 8)]
    ok = res[1]['killing'] == [0, 6, 0] and res[0]['killing'] == [0, 3, 3] and res[-1]['killing'] == [3, 3, 0]
    ok &= [(res[e]['turn'], res[e]['slide'], res[e]['stretch']) for e in (1, 0, -1)] == [(6, 0, 0), (3, 3, 0), (3, 0, 3)]
    ok &= shells == [n * n for n in range(1, 8)] and spin == [2, 8, 18, 32, 50, 72, 98] == [2 * n * n for n in range(1, 8)]
    chk('P4', ok, 'bivectors L = -e_j e_k / 2, M = -e_k e_4 / 2 of the squares (+1, +1, +1, eps): Killing form (positive, negative, zero) = ' + ', '.join(f'eps {e:+d}: {tuple(res[e]["killing"])}' for e in (1, 0, -1))
        + ' (so(4), e(3), so(3,1)); the six moves e_j e_k square to -1 (turn), 0 (slide), +1 (stretch): ' + ', '.join(f'eps {e:+d}: {res[e]["turn"]} turn, {res[e]["slide"]} slide, {res[e]["stretch"]} stretch' for e in (1, 0, -1))
        + f'; shells n^2 = {shells} (sum of 2l + 1, l < n), with spin 2 n^2 = n(n+1) + n(n-1) = {spin}')
    chk('P4b', okb, '[L_j, L_k] = L_l, [L_j, M_k] = M_l, [M_j, M_k] = eps L_l for eps = +1, 0, -1 (exact, bit rule), and for eps = +1 the halves A = (L + M)/2, B = (L - M)/2 close into two commuting so(3) (as baez.K1b, K1c)')
    return dict(eps={str(e): res[e] for e in (1, 0, -1)}, shells=shells, shells_spin=spin)

# ================================================================ P5: the empty ring and the Madelung order
def part_p5():
    rings = [sum(1 for x in range(-12, 13) for y in range(-12, 13) if x * x - x * y + y * y == n) for n in range(8)]
    e7 = levi(7); a6, a7 = SIMPLE[5], SIMPLE[6]
    sh = Counter((ip(r, a6), ip(r, a7)) for r in e7)                       # the shadow on P = span(alpha_6, alpha_7) is a w_6 + b w_7 (fundamental weights), N = a^2 + ab + b^2
    N = lambda ab: ab[0] ** 2 + ab[0] * ab[1] + ab[1] ** 2
    by = Counter(); [by.update({N(k): v}) for k, v in sh.items()]
    a2 = {r for r in e7 if all(ip(r, SIMPLE[i]) == 0 for i in range(4))}
    at3 = {r for r in e7 if N((ip(r, a6), ip(r, a7))) == 3}
    sub = sorted((n + l, n, l) for n in range(1, 9) for l in range(n))[:19]
    cum = list(itertools.accumulate(2 * (2 * l + 1) for _, n, l in sub))
    closings = [c for c, nxt in zip(cum, sub[1:] + [(0, 0, 0)]) if nxt[2] == 0]
    periods = [b - a for a, b in zip([0] + closings, closings)]
    ok = rings == [1, 6, 0, 6, 6, 0, 0, 12] and len(e7) == 126 and by == Counter({0: 30, 1: 90, 3: 6}) and a2 == at3 and len(a2) == 6
    ok &= sorted(v for k, v in sh.items() if N(k) == 1) == [15] * 6 and cum[-1] == 118
    ok &= closings == [2, 10, 18, 36, 54, 86, 118] and periods == [2, 8, 8, 18, 18, 32, 32] == [2 * m * m for m in (1, 2, 2, 3, 3, 4, 4)]
    chk('P5', ok, f'Eisenstein rings N = x^2 - xy + y^2 = 0..7 hold {rings} points (nothing on ring 2); the 126 roots of E7 shadow on the plane of alpha_6, alpha_7 to rings 0, 1, 3 with '
        f'{by[0]}, {by[1]}, {by[3]} roots (15 on each of the six points of ring 1; the 6 on ring 3 are the roots orthogonal to alpha_1..alpha_4); Madelung order (n + l, then n): '
        f'rows close at {closings}, periods {periods} = 2 m^2')
    return dict(rings=rings, shadows={str(k): by[k] for k in sorted(by)}, points=[dict(a=a, b=b, n=v) for (a, b), v in sorted(sh.items())],
                madelung=dict(sub=[[n, l] for _, n, l in sub], cum=cum, closings=closings, periods=periods))

def run():
    d = {}
    for k, f in (('P1', part_p1), ('P2', part_p2), ('P3', part_p3), ('P4', part_p4), ('P5', part_p5)): d[k] = f()
    return json.loads(json.dumps(d))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--write'); ap.add_argument('--compare'); a = ap.parse_args()
    data = run()
    print(f'\n{N_OK} checks ok, {N_BAD} failed')
    if a.write and not N_BAD: json.dump(data, open(a.write, 'w'), indent=1, ensure_ascii=False); open(a.write, 'a').write('\n'); print('wrote', a.write)
    if a.compare:
        same = json.load(open(a.compare)) == data
        print('stored data == rebuilt data' if same else 'FAIL the stored data differs from the rebuilt data'); N_BAD += 0 if same else 1
    sys.exit(0 if N_BAD == 0 else 1)
