#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""lens_sch_check.py: the exact checks behind the widgets of the Schuller chapter (step 20 of the lenses page, SchullerWidgets.jsx).
Each check recomputes, from the bit rule e_a e_b = s(a,b) e_(a xor b) and plain integer or rational arithmetic, the numbers a widget shows; the widget
computes the same numbers in the browser (schullerEngine.js) and shows them beside the stored ones written here (lens_sch_check.json).
  scw·P1   hyperbolicity map (r = 0, n = 2..9) and det(P - m) = (m^2 - Q)^(2^(n-1)) on the regular module (r = 0, n <= 5)        widget SW4, SW1
  scw·P1b  an extra generator of square -1, 0, +1: (P + m f)^2 = Q + eps m^2, null momenta invisible in the determinant          widget SW4
  scw·P1c  one table, three squares (n = 2, 3, every choice of squares): wedge, Clifford, ranks of e_F and of the top pairing  widget SW2
  scw·P2   Floquet: SL(2,Z) exactly (band, edge, gap by the sign of X^2; M = +-I has X = 0); the Kronig-Penney fixture (numerical)  widget SW5
  scw·P3   outside and inside at n = 8: the commutant of Cl(0,k) in M_16 (256 unknowns, exact elimination), dimensions, centres, types   widget SW3
  scw·P3b  left and right actions for every (p,q,r) with n <= 4: L, R, R' as integer matrices, exact ranks                    widget SW3
  scw·P4   seats (the Fock space of three modes) and three magnets (Stern-Gerlach in Cl(3,0))                                   widget SW6, SW7
  scw·P4b  two qubits: the 16 blades of Cl(4,0) are the 16 Pauli strings up to a phase; 6 square to +1                         widget SW6
Python 3 standard library only (fractions). Deterministic. Writes nothing unless asked.
  python3 lens_sch_check.py                    run the checks (one line per check, a total; exit 1 on a failure)
  python3 lens_sch_check.py --write f.json     also write the fixture the widgets embed
  python3 lens_sch_check.py --compare f.json   also check that the fixture equals what the checks compute"""
import argparse, itertools, json, math, sys
from fractions import Fraction as Fr

N_OK = N_BAD = 0
def chk(cid, cond, msg):
    global N_OK, N_BAD
    N_OK += bool(cond); N_BAD += not cond
    print(('ok   ' if cond else 'FAIL ') + 'scw·' + cid + ': ' + msg)

# ---------------------------------------------------------------- the bit rule (blades are bit masks; squares sq[i] in {+1, -1, 0})
pc = lambda x: bin(x).count('1')
def reorder(a, b):
    s, x = 0, a >> 1
    while x: s += pc(x & b); x >>= 1
    return -1 if s & 1 else 1
def bmul(a, b, sq):
    s, c, i = reorder(a, b), a & b, 0
    while c:
        if c & 1: s *= sq[i]
        c >>= 1; i += 1
    return s, a ^ b
sig = lambda p, q, r=0: [1] * p + [-1] * q + [0] * r
TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']          # the textbook mod-8 table, used only to name a class
def mv_mul(x, y, sq):
    o = {}
    for a, u in x.items():
        for b, v in y.items():
            s, c = bmul(a, b, sq)
            if s: o[c] = o.get(c, 0) + s * u * v
    return {k: v for k, v in o.items() if v}
def left_matrix(x, sq):                                     # the regular module: column c is x e_c
    N = 1 << len(sq); M = [[0] * N for _ in range(N)]
    for c in range(N):
        for a, u in x.items():
            s, d = bmul(a, c, sq)
            if s: M[d][c] += s * u
    return M
def bareiss_det(M):                                         # exact integer determinant, fraction-free
    M = [r[:] for r in M]; n = len(M); sgn, prev = 1, 1
    for k in range(n - 1):
        if M[k][k] == 0:
            sw = next((i for i in range(k + 1, n) if M[i][k]), None)
            if sw is None: return 0
            M[k], M[sw] = M[sw], M[k]; sgn = -sgn
        for i in range(k + 1, n):
            for j in range(k + 1, n): M[i][j] = (M[i][j] * M[k][k] - M[i][k] * M[k][j]) // prev
        prev = M[k][k]
    return sgn * M[n - 1][n - 1]
def rank_q(rows):                                           # exact rank of a list of rational vectors
    rows = [[Fr(v) for v in r] for r in rows if any(r)]; rk = 0; ncol = len(rows[0]) if rows else 0
    for c in range(ncol):
        piv = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if piv is None: continue
        rows[rk], rows[piv] = rows[piv], rows[rk]; p = rows[rk][c]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c] / p; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        rk += 1
    return rk

# ================================================================ scw.P1 hyperbolicity map and the symbol determinant (Thm T18(f), Thm T16)
def lorentzian(k, d): return k == 1 or d == 1
def kind(k, d): return 'hyperbolic' if lorentzian(k, d) else ('elliptic' if min(k, d) == 0 else 'ultrahyperbolic')
def Mh(S, h):                                               # q -> B(q,h)^2 - P(h)P(q) as a matrix: (Sh)(Sh)^T - P(h) S
    Sh = [S[i] * h[i] for i in range(len(h))]; Ph = sum(S[i] * h[i] * h[i] for i in range(len(h)))
    return [[Sh[i] * Sh[j] - (Ph * S[i] if i == j else 0) for j in range(len(h))] for i in range(len(h))], Ph
def is_psd(A):                                              # exact: fraction-free symmetric elimination, a zero pivot needs a zero row
    A = [r[:] for r in A]; idx = list(range(len(A)))
    while idx:
        p = next((i for i in idx if A[i][i] != 0), None)
        if p is None: return all(A[i][j] == 0 for i in idx for j in idx)
        if A[p][p] < 0: return False
        for i in idx:
            if A[i][i] == 0 and any(A[i][j] for j in idx): return False
        rest = [i for i in idx if i != p]
        A = [[(A[i][j] * A[p][p] - A[i][p] * A[p][j]) if i in rest and j in rest else A[i][j] for j in range(len(A))] for i in range(len(A))]
        idx = rest
    return True
def witness(S, h, Ph):                                      # an explicit q with B(q,h)^2 - P(h)P(q) < 0 when the cell is not Lorentzian
    sgn = 1 if Ph > 0 else -1; I = [i for i in range(len(S)) if S[i] == sgn]
    if len(I) < 2: return None
    i, j = I[0], I[1]; q = [0] * len(S)
    if h[i] == 0 and h[j] == 0: q[i] = 1
    else: q[i], q[j] = h[j], -h[i]
    B = sum(S[t] * q[t] * h[t] for t in range(len(S))); Pq = sum(S[t] * q[t] * q[t] for t in range(len(S)))
    return q if B * B - Ph * Pq < 0 else None
def p1(data):
    cells, ok_cert, ok_wit, nh = {}, True, True, 0
    for n in range(2, 10):
        for d in range(n + 1):
            k = n - d; S = sig(k, d); cells[f'{k},{d}'] = kind(k, d)
            if lorentzian(k, d):
                t = 0 if k == 1 else n - 1; h = [0] * n; h[t] = 1; M, Ph = Mh(S, h); nh += 1
                ok_cert &= Ph != 0 and all(M[i][j] == 0 for i in range(n) for j in range(n) if i != j) and all(M[i][i] >= 0 for i in range(n))
            else:
                for h in itertools.product((-1, 0, 1), repeat=n):
                    M, Ph = Mh(S, h)
                    if Ph != 0 and witness(S, h, Ph) is None: ok_wit = False
    chk('P1', ok_cert and ok_wit and nh == 15 and cells['2,2'] == 'ultrahyperbolic' and all(cells[f'{n - 2},2'] != 'hyperbolic' for n in range(4, 10)),
        f'hyperbolicity map, r = 0, n = 2..9 ({len(cells)} cells): {nh} hyperbolic, exactly the Lorentzian ones (one plus or one minus switch); each has the certificate h = e_t '
        '(the odd generator): q -> B(q,h)^2 - P(h)P(q) is a diagonal matrix with entries 0 and 1, positive semidefinite; for every other cell and every h in {-1,0,1}^n with '
        'P(h) != 0 an explicit integer q gives B(q,h)^2 - P(h)P(q) < 0 (the witness of the proof of Thm T18(f)); the first ultrahyperbolic cell is Cl(2,2)')
    tl_ok = True; tl = {}
    for n in range(2, 6):
        for d in range(n + 1):
            k = n - d; S = sig(k, d); hyp = 0; tot = 0
            for h in itertools.product((-1, 0, 1), repeat=n):
                M, Ph = Mh(S, h)
                if Ph == 0: continue
                tot += 1; good = is_psd(M); hyp += good
                timelike = (Ph > 0) == (k == 1) if n > 2 else True
                tl_ok &= good == (lorentzian(k, d) and timelike)
            tl[f'{k},{d}'] = [hyp, tot]
    data['p1'] = {'cells': cells, 'grid': tl}
    chk('P1', tl_ok, 'for every r = 0 cell with n = 2..5 and every h in {-1,0,1}^n with P(h) != 0, h is a hyperbolic direction (the matrix above is positive semidefinite, exact '
        'elimination) exactly when the cell is Lorentzian and h is timelike (every non-null h at n = 2): hyperbolic / non-null directions ' + ', '.join(f'({c}) {v[0]}/{v[1]}' for c, v in tl.items() if v[0]))
    det_ok, samples, cnt = True, {}, 0
    for n in range(1, 6):
        for d in range(n + 1):
            k = n - d; S = sig(k, d)
            moms = [[((i * 7 + j * 3) % 5) - 2 for i in range(n)] for j in range(3)] + [default_mom(n)]
            for j, mom in enumerate(moms):
                for m in ((0, 1, 3) if j < 3 else (DEFAULT_M,)):
                    x = {1 << i: mom[i] for i in range(n) if mom[i]}; x[0] = x.get(0, 0) - m
                    Q = sum(S[i] * mom[i] ** 2 for i in range(n)); dt = bareiss_det(left_matrix(x, S)); cnt += 1
                    det_ok &= dt == (m * m - Q) ** (2 ** (n - 1))
                    if j == 3: samples[f'{k},{d}'] = {'mom': mom, 'm': m, 'Q': Q, 'det': str(dt), 'exp': 2 ** (n - 1)}
    data['p1']['det'] = samples
    chk('P1', det_ok, f'det(P - m) on the regular module of Cl(k,d) (2^n x 2^n integer matrix, Bareiss, exact) equals (m^2 - Q)^(2^(n-1)) with Q = P^2 = sum eps_i k_i^2, for all 20 '
        f'cells with n = 1..5 and r = 0 ({cnt} integer samples, the widget default included): the reduced principal polynomial is m^2 - Q (Thm T16)')
DEFAULT_M = 3
def default_mom(n): return [1, 2, 0, 1, 1][:n]

def p1b(data):
    ok_sq, ok_det, rows = True, True, {}
    for n in range(1, 5):
        for d in range(n + 1):
            k = n - d
            for eps in (-1, 0, 1):
                S = sig(k, d) + [eps]
                for j in range(3):
                    mom = [((i * 5 + j * 2) % 7) - 3 for i in range(n)]; m = j + 1
                    x = {1 << i: mom[i] for i in range(n) if mom[i]}; x[1 << n] = m
                    Q = sum(S[i] * mom[i] ** 2 for i in range(n)); sq = mv_mul(x, x, S)
                    ok_sq &= sq == ({0: Q + eps * m * m} if Q + eps * m * m else {})
                    ok_det &= bareiss_det(left_matrix(x, S)) == (Q + eps * m * m) ** (2 ** n)
    for eps in (-1, 0, 1):                                   # base Cl(1,3) (time squares +1): the shell of a momentum m along the extra direction
        S = sig(1, 3) + [eps]; E, p, m = {-1: (5, 3, 4), 0: (3, 3, 7), 1: (4, 5, 3)}[eps]
        x = {1: E, 2: p, 16: m}; tot = (1 + (eps == 1), 3 + (eps == -1), int(eps == 0))
        rows[str(eps)] = {'total': list(tot), 'shell_zero': mv_mul(x, x, S) == {}, 'kind': kind(tot[0], tot[1]) if tot[2] == 0 else 'null',
                          'E': E, 'p': p, 'm': m}
    data['p1b'] = rows
    chk('P1b', ok_sq and ok_det and all(r['shell_zero'] for r in rows.values()) and [rows[e]['kind'] for e in ('-1', '0', '1')] == ['hyperbolic', 'null', 'ultrahyperbolic'],
        'an extra generator f of square eps added to every r = 0 cell with n <= 4: (P + m f)^2 = Q + eps m^2 exactly (bit rule) and det(P + m f) on the regular module = (Q + eps m^2)^(2^n): '
        'for eps = 0 the momentum m never enters (null momenta are invisible, Thm T16); on the base Cl(1,3) the shell is E^2 = |p|^2 - eps m^2 (zeros at (5;3;4), (3;3;7), (4;5;3)): '
        'eps = -1 total Cl(1,4) Lorentzian (a mass), eps = 0 total Cl(1,3,1), eps = +1 total Cl(2,3) not hyperbolic')

def p1c(data):
    out, ok = {}, True
    for n in (2, 3):
        N = 1 << n; F = N - 1
        for sq in itertools.product((1, -1, 0), repeat=n):
            sq = list(sq); T = {(a, b): bmul(a, b, sq) for a in range(N) for b in range(N)}
            assoc = all(mv_mul(mv_mul({a: 1}, {b: 1}, sq), {c: 1}, sq) == mv_mul({a: 1}, mv_mul({b: 1}, {c: 1}, sq), sq) for a in range(N) for b in range(N) for c in range(N))
            gens = [left_matrix({1 << i: 1}, sq) for i in range(n)]
            mm = lambda A, B: [[sum(A[i][t] * B[t][j] for t in range(N)) for j in range(N)] for i in range(N)]
            cliff = all(mm(gens[i], gens[j]) == [[(2 * sq[i] if i == j and r == c else 0) - mm(gens[j], gens[i])[r][c] for c in range(N)] for r in range(N)] for i in range(n) for j in range(n))
            if not any(sq):                                   # the wedge: concatenate the sorted index lists, count inversions; 0 when they share an index
                def wedge(a, b):
                    if a & b: return 0
                    la = [i for i in range(n) if a >> i & 1]; lb = [i for i in range(n) if b >> i & 1]
                    return -1 if sum(1 for x in la for y in lb if x > y) & 1 else 1
                assoc &= all(T[(a, b)][0] == wedge(a, b) for a in range(N) for b in range(N)) and all(T[(a, b)][0] == (-1) ** (pc(a) * pc(b)) * T[(b, a)][0] for a in range(N) for b in range(N))
            nz = sum(1 for s in sq if s)
            row = {'zeros': sum(1 for v in T.values() if v[0] == 0), 'minus': sum(1 for v in T.values() if v[0] == -1), 'eF_sq': T[(F, F)][0],
                   'eF_rank': sum(1 for a in range(N) if T[(F, a)][0]), 'pair': sum(1 for (a, b), v in T.items() if v[0] and v[1] == F)}
            ok &= assoc and cliff and row['eF_rank'] == 2 ** nz and row['pair'] == N and all(T[(a, a ^ F)][0] for a in range(N)) and (row['eF_sq'] == 0) == (nz < n)
            out[','.join(str(s) for s in sq)] = row
    data['p1c'] = out
    chk('P1c', ok, f'one table, three squares: for every choice of squares in {{+1,-1,0}} on 2 and 3 switches ({len(out)} tables) the bit-rule product is associative and the generators '
        'satisfy e_i e_j + e_j e_i = 2 eps_i delta_ij; with all squares 0 it is the wedge of the index lists with the sign (-1)^(|a||b|) of graded commutativity; '
        'multiplication by the top blade e_F reaches 2^(p+q) labels (all of them only when r = 0, then e_F^2 = +-1, else e_F^2 = 0), and the top pairing (coefficient of e_F in e_a e_b) '
        'is non-zero exactly for b = a xor F: rank 2^n for every choice (Thm T3)')

# ================================================================ scw.P2 Floquet: SL(2,Z) exactly, and the Kronig-Penney fixture (numerical)
def matmul2(A, B): return [[A[0][0] * B[0][0] + A[0][1] * B[1][0], A[0][0] * B[0][1] + A[0][1] * B[1][1]], [A[1][0] * B[0][0] + A[1][1] * B[1][0], A[1][0] * B[0][1] + A[1][1] * B[1][1]]]
def sl2_class(M):                                           # multivector coordinates in Cl(2,0) = M_2(R): e1 = diag(1,-1), e2 = [[0,1],[1,0]], e12 = [[0,1],[-1,0]]
    a, b, c, d = M[0][0], M[0][1], M[1][0], M[1][1]
    g, x1, x2, x12 = Fr(a + d, 2), Fr(a - d, 2), Fr(b + c, 2), Fr(b - c, 2)
    X2 = x1 * x1 + x2 * x2 - x12 * x12; Xzero = x1 == x2 == x12 == 0
    cls = 'band' if X2 < 0 else 'gap' if X2 > 0 else ('scalar' if Xzero else 'edge')
    return cls, X2, g
PRESETS = {'T': [[1, 1], [0, 1]], 'S': [[0, -1], [1, 0]], 'ST': [[0, -1], [1, 1]], 'cat': [[2, 1], [1, 1]], 'minusT': [[-1, 1], [0, -1]], 'I': [[1, 0], [0, 1]], 'minusI': [[-1, 0], [0, -1]]}
def trace_seq(M, NN=8):
    P, out = [[1, 0], [0, 1]], []
    for _ in range(NN): P = matmul2(P, M); out.append(P[0][0] + P[1][1])
    return out
def half_trace_comb(E, g, l):                               # Dirac comb: kick [[1,0],[g,1]] times free flight of length l (V = 0)
    if E > 1e-12: k = math.sqrt(E); return math.cos(k * l) + g / (2 * k) * math.sin(k * l)
    if E < -1e-12: q = math.sqrt(-E); return math.cosh(q * l) + g / (2 * q) * math.sinh(q * l)
    return 1 + g * l / 2
def half_trace_steps(E, cell):                              # piecewise constant potential: product of the pieces (2x2), half its trace
    M = [[1.0, 0.0], [0.0, 1.0]]
    for (l, V) in cell:
        kap = E - V
        if kap > 1e-14: k = math.sqrt(kap); P = [[math.cos(k * l), math.sin(k * l) / k], [-k * math.sin(k * l), math.cos(k * l)]]
        elif kap < -1e-14: q = math.sqrt(-kap); P = [[math.cosh(q * l), math.sinh(q * l) / q], [q * math.sinh(q * l), math.cosh(q * l)]]
        else: P = [[1.0, l], [0.0, 1.0]]
        M = matmul2(P, M)
    return (M[0][0] + M[1][1]) / 2
def edges(f, lo, hi, steps):                                # band edges: |f| <= 1 changes along a grid, then 80 bisections
    out, h = [], (hi - lo) / steps; prev = abs(f(lo)) <= 1
    for i in range(1, steps + 1):
        e0, e1 = lo + (i - 1) * h, lo + i * h; cur = abs(f(e1)) <= 1
        if cur != prev:
            a, b = e0, e1
            for _ in range(80):
                mid = (a + b) / 2
                if (abs(f(mid)) <= 1) == prev: a = mid
                else: b = mid
            out.append(round((a + b) / 2, 9))
        prev = cur
    return out
G5_CELL = [(0.8, 0.0), (0.5, 5.0)]
COMB_G = [x / 2 for x in range(-8, 9)]; COMB_L = [0.5 + x / 4 for x in range(7)]; COMB_E = (-20.0, 60.0, 16000)
def p2(data):
    counts, ok_cls, ok_tr, ok_grow = {'band': 0, 'edge': 0, 'scalar': 0, 'gap': 0}, True, True, True
    for a, b, c, d in itertools.product(range(-3, 4), repeat=4):
        if a * d - b * c != 1: continue
        M = [[a, b], [c, d]]; cls, X2, g = sl2_class(M); counts[cls] += 1; t = a + d
        ok_cls &= X2 == g * g - 1 and (cls == 'band') == (abs(t) < 2) and (cls == 'gap') == (abs(t) > 2) and (cls in ('edge', 'scalar')) == (abs(t) == 2) and (cls == 'scalar') == (M in ([[1, 0], [0, 1]], [[-1, 0], [0, -1]]))
        s, s0, s1 = trace_seq(M), 2, t; cheb = []
        for _ in range(8): cheb.append(s1); s0, s1 = s1, t * s1 - s0
        ok_tr &= s == cheb
        P12 = M
        for _ in range(11): P12 = matmul2(P12, M)
        if cls == 'band': ok_grow &= P12 == [[1, 0], [0, 1]]
        elif cls == 'scalar': ok_grow &= P12 == [[1, 0], [0, 1]]
        elif cls == 'edge':
            e = 1 if t == 2 else -1; Pn = [[1, 0], [0, 1]]
            for N in range(1, 9):
                Pn = matmul2(Pn, M); ok_grow &= all(e ** N * Pn[i][j] - (i == j) == N * (e * M[i][j] - (i == j)) for i in range(2) for j in range(2))
        else: ok_grow &= all(abs(s[i + 1]) > abs(s[i]) for i in range(7))
    pres = {}
    for name, M in PRESETS.items():
        cls, X2, g = sl2_class(M); pres[name] = {'M': M, 'class': cls, 'X2': str(X2), 'half_trace': str(g), 'traces': trace_seq(M, 6)}
    chk('P2', ok_cls and ok_tr and ok_grow and counts['scalar'] == 2,
        f'every M in SL(2,Z) with entries in [-3,3] ({sum(counts.values())} matrices), as a multivector g + X of Cl(2,0) with exact halves: X^2 = g^2 - 1 is a scalar; band X^2 < 0 '
        f'({counts["band"]}, M^12 = I: bounded), gap X^2 > 0 ({counts["gap"]}, |tr M^N| grows), edge X^2 = 0 with X != 0 ({counts["edge"]}, M^N = +-(I + N(+-M - I)): linear growth); '
        f'M = +-I ({counts["scalar"]}) has X^2 = 0 AND X = 0 with bounded powers: not an edge (Thm T19(1) needs X != 0); tr M^N = 2 T_N(tr M / 2) for N <= 8')
    g5 = edges(lambda E: half_trace_steps(E, G5_CELL), 0.05, 90.0, 18000)
    comb = [{'g': g, 'l': l, 'edges': edges(lambda E: half_trace_comb(E, g, l), *COMB_E)} for g in COMB_G for l in COMB_L]
    ok_comb = all(abs(abs(half_trace_comb(e, c['g'], c['l'])) - 1) < 1e-6 for c in comb for e in c['edges'])
    free = next(c for c in comb if c['g'] == 0 and c['l'] == 1)
    kick_ok = True                                          # the kick [[1,0],[g,1]] = 1 + (g/2)(e2 - e12) in the coordinates above: X = (g/2)(e2 - e12)
    for g in (-2.0, 1.5): X = {2: g / 2, 3: -g / 2}; kick_ok &= mv_mul(X, X, [1, 1]) == {} and any(X.values())
    data['p2'] = {'counts': counts, 'presets': pres, 'g5_cell': G5_CELL, 'g5_edges': g5, 'comb': comb, 'comb_E': list(COMB_E)}
    chk('P2', len(g5) == 7 and ok_comb and kick_ok and len(free['edges']) == 1 and abs(free['edges'][0]) < 1e-6,
        f'fixture of the Kronig-Penney mode (numerical, floating point): the two-step potential of fibre G5e (width 0.8 at V = 0, 0.5 at V = 5) has 7 band edges in (0, 90] '
        f'({", ".join(f"{e:.4f}" for e in g5)}); the Dirac comb (kick g, spacing l) at all {len(comb)} slider positions g = -4..4, l = 0.5..2, E in [-20, 60]: '
        'at every stored edge |tr M|/2 = 1 to 1e-6; with g = 0 the only edge is E = 0 (the free line: where cos kl = +-1 the matrix is +-I, X = 0, no gap opens); '
        'a kick [[1,0],[g,1]] = 1 + (g/2)(e2 - e12) has X^2 = 0 with X != 0: the null piece')

# ================================================================ scw·P3 outside and inside at n = 8 (fibre G3), scw·P3b left and right (fibre G1, G2)
# A monomial matrix (a signed permutation, or a matrix with at most one non-zero entry per column) is the tuple of its columns (row, sign); sign 0: a zero column.
def mono(M): return tuple(next(((i, M[i][j]) for i in range(len(M)) if M[i][j]), (-1, 0)) for j in range(len(M)))
def mmul(A, B): return tuple((-1, 0) if s == 0 or A[r][1] == 0 else (A[r][0], s * A[r][1]) for (r, s) in B)
def mid(N, s=1): return tuple((j, s) if s else (-1, 0) for j in range(N))
def mneg(A): return tuple((r, -s) if s else (r, s) for (r, s) in A)
def prod(ms, N=16):
    P = mid(N)
    for M in ms: P = mmul(P, M)
    return P
def gammas():                                               # the same search as fibre_check.py G3: the first 8 mutually anticommuting kron words with M^2 = -1
    base = [[[1, 0], [0, 1]], [[0, 1], [1, 0]], [[1, 0], [0, -1]], [[0, 1], [-1, 0]]]; cands = []
    kron = lambda A, B: [[A[i // len(B)][j // len(B)] * B[i % len(B)][j % len(B)] for j in range(len(A) * len(B))] for i in range(len(A) * len(B))]
    for w in itertools.product(range(4), repeat=4):
        M = [[1]]
        for i in w: M = kron(M, base[i])
        M = mono(M)
        if mmul(M, M) == mid(16, -1): cands.append((list(w), M))
    def search(cur, start):
        if len(cur) == 8: return cur
        for i in range(start, len(cands)):
            if all(mmul(cands[i][1], g[1]) == mneg(mmul(g[1], cands[i][1])) for g in cur):
                r = search(cur + [cands[i]], i + 1)
                if r: return r
        return None
    return search([], 0)
def commutant_dim(mats, N=16):                              # exact: X M = M X for every M, N*N unknowns, sparse rational elimination
    piv = {}
    for M in mats:
        inv = {r: (t, s) for t, (r, s) in enumerate(M) if s}
        for i in range(N):
            for j in range(N):                              # (X M - M X)_ij = s_j X[i, r_j] - s_t X[t, j]  (column j of M is (r_j, s_j); column t of M has its entry in row i)
                row = {}; r_j, s_j = M[j]
                if s_j: row[i * N + r_j] = row.get(i * N + r_j, 0) + s_j
                if i in inv: t, s_t = inv[i]; row[t * N + j] = row.get(t * N + j, 0) - s_t
                row = {k: Fr(v) for k, v in row.items() if v}
                while row:
                    c = min(row)
                    if c not in piv: piv[c] = {k: v / row[c] for k, v in row.items()}; break
                    f = row[c]
                    for k, v in piv[c].items():
                        row[k] = row.get(k, 0) - f * v
                        if row[k] == 0: del row[k]
    return N * N - len(piv)
def mono_rank(mats):                                        # exact rank: monomials with different patterns have disjoint supports; within a pattern, the rank of the sign vectors
    groups = {}
    for M in mats:
        if any(s for r, s in M): groups.setdefault(tuple(r for r, s in M), []).append([s for r, s in M])
    return sum(rank_q(v) for v in groups.values())
def p3(data):
    G = gammas(); gm = [g[1] for g in G]; rows = []; ok = True
    for k in range(9):
        base = [prod([gm[i] for i in range(k) if a >> i & 1]) for a in range(1 << k)]
        dimB = mono_rank(base); dimC = commutant_dim(gm[:k]) if k else 256
        om = prod(gm[:k]); m = 8 - k
        if k % 2 == 0: fg = [mmul(om, g) for g in gm[k:]]
        else: fg = [mmul(gm[i], gm[j]) for i in range(k, 8) for j in range(i + 1, 8)] + [om]
        comm = all(mmul(f, b) == mmul(b, f) for f in fg for b in gm[:k])
        grp = {mid(16)}; frontier = [mid(16)]
        while frontier:                                     # the group the fibre generators generate (signed permutation matrices), then its span
            new = []
            for X in frontier:
                for f in fg:
                    Y = mmul(X, f)
                    if Y not in grp: grp.add(Y); new.append(Y)
            frontier = new
        dimF = mono_rank(list(grp)); dimBB = commutant_dim(fg) if fg else 256
        bitc = sum(1 for a in range(256) if all(bmul(a, 1 << i, sig(0, 8))[0] == bmul(1 << i, a, sig(0, 8))[0] for i in range(k)))
        ctr = sum(1 for a in range(1 << k) if all(bmul(a, 1 << i, sig(0, k))[0] == bmul(1 << i, a, sig(0, k))[0] for i in range(k)))
        btype = TYPES[(-k) % 8]
        if k % 2 == 0:
            hs = mmul(fg[0], fg[0])[0][1] if fg else None
            ftype = 'R' if m == 0 else TYPES[(m if hs == 1 else -m) % 8]; fdesc = 'R' if m == 0 else (f'Cl({m},0)' if hs == 1 else f'Cl(0,{m})')
        else:
            w2 = mmul(om, om)[0][1]; inner = TYPES[(-(m - 1)) % 8]
            ftype = ('C' if inner in ('R', 'H') else '?') if w2 == -1 else inner + '2'; fdesc = f'Cl(0,{m - 1}) x ' + ('C' if w2 == -1 else 'R2')
        rows.append({'k': k, 'outside': 2 ** k, 'inside': 2 ** (8 - k), 'base_dim': dimB, 'fibre_dim': dimC, 'fibre_dim_bitrule': bitc, 'fibre_span': dimF, 'double_dim': dimBB,
                     'centre': ctr, 'base_type': btype, 'fibre_type': ftype, 'fibre': fdesc})
        ok &= comm and dimB == 2 ** k and dimC == bitc == dimF == 2 ** (8 - k) and dimBB == 2 ** k and ctr == (1 if k % 2 == 0 else 2) and ftype == btype
    data['p3'] = {'gamma_words': [g[0] for g in G], 'rows': rows}
    chk('P3', ok and [r['fibre_type'] for r in rows] == ['R', 'C', 'H', 'H2', 'H', 'C', 'R', 'R2', 'R'],
        'n = 8 kept fixed: eight anticommuting integer 16x16 matrices with gamma^2 = -1 (the search of fibre G3); for k = 0..8 the base Cl(0,k) has dimension 2^k (exact rank), its commutant '
        'in M_16 has dimension ' + ', '.join(str(r['fibre_dim']) for r in rows) + ' = 2^(8-k) by exact elimination of the 256 unknowns (and by the bit rule: blades commuting with e_1..e_k), '
        'the explicit fibre generators (omega_k gamma_j for k even; gamma_i gamma_j and omega_k for k odd) commute with the base and span it, its commutant is the base again (2^k), '
        'the centre has dimension 1 (k even) or 2 (k odd), and the fibre types R, C, H, H2, H, C, R, R2, R equal the base types of the clock: 2^k x 2^(8-k) = 256 every time')
    out = {}; ok = True
    for n in range(1, 5):
        for p in range(n + 1):
            for q in range(n + 1 - p):
                r = n - p - q; S = sig(p, q, r); N = 1 << n
                L = [mono(left_matrix({1 << i: 1}, S)) for i in range(n)]
                R = [tuple((bmul(x, 1 << i, S)[1], bmul(x, 1 << i, S)[0]) if bmul(x, 1 << i, S)[0] else (-1, 0) for x in range(N)) for i in range(n)]
                Rt = [tuple((c, s * (-1 if pc(x) & 1 else 1)) if s else (-1, 0) for x, (c, s) in enumerate(R[i])) for i in range(n)]
                ok &= all(mmul(L[i], R[j]) == mmul(R[j], L[i]) and mmul(L[i], Rt[j]) == mneg(mmul(Rt[j], L[i])) for i in range(n) for j in range(n))
                ok &= all(mmul(L[i], L[i]) == mid(N, S[i]) and mmul(R[i], R[i]) == mid(N, S[i]) and mmul(Rt[i], Rt[i]) == mid(N, -S[i]) for i in range(n))
                pairs = lambda A, B: [prod([A[i] for i in range(n) if a >> i & 1] + [B[i] for i in range(n) if b >> i & 1], N) for a in range(N) for b in range(N)]
                rLRt, rLR = mono_rank(pairs(L, Rt)), mono_rank(pairs(L, R))
                same = [i for i in range(n) if Rt[i] == L[i]]
                ctr = sum(1 for a in range(N) if all(bmul(a, 1 << i, S) == bmul(1 << i, a, S) for i in range(n)))
                if r == 0: ok &= rLRt == 4 ** n and rLR * ctr == 4 ** n and same == []
                else: ok &= rLRt < 4 ** n and same == [i for i in range(n) if S[i] == 0]
                out[f'{p},{q},{r}'] = {'rank_LRt': rLRt, 'rank_LR': rLR, 'centre': ctr, 'Rt_eq_L': same}
    data['p3b'] = out
    chk('P3b', ok, f'left and right for all {len(out)} signatures (p,q,r) with n = 1..4, integer 2^n x 2^n matrices: L_i and R_j commute, L_i and the twisted R\'_j anticommute, '
        'L_i^2 = R_i^2 = eps_i, R\'_i^2 = -eps_i; for r = 0 the 4^n products L_a R\'_b have exact rank 4^n (they span End(A): Cl(n,n), the mirror pair) and the products L_a R_b have '
        'rank 4^n / dim(centre); with a null generator R\'_i = L_i exactly for the null i and the rank drops below 4^n')

# ================================================================ scw.P4 seats and magnets, scw.P4b Pauli strings
def dmul(A, B): n = len(A); return [[sum(A[i][t] * B[t][j] for t in range(n) if A[i][t]) for j in range(n)] for i in range(n)]
def p4(data):
    n, N = 3, 8; S0 = [0] * n
    eps = [left_matrix({1 << k: 1}, S0) for k in range(n)]; iot = [[list(r) for r in zip(*e)] for e in eps]
    Z = [[0] * N for _ in range(N)]; Id = [[int(a == b) for b in range(N)] for a in range(N)]
    add = lambda A, B: [[A[i][j] + B[i][j] for j in range(N)] for i in range(N)]; sub = lambda A, B: [[A[i][j] - B[i][j] for j in range(N)] for i in range(N)]
    ok = all(dmul(e, e) == Z for e in eps) and all(add(dmul(eps[k], iot[l]), dmul(iot[l], eps[k])) == (Id if k == l else Z) for k in range(n) for l in range(n))
    ok &= all(dmul(add(eps[k], iot[k]), add(eps[k], iot[k])) == Id and dmul(sub(eps[k], iot[k]), sub(eps[k], iot[k])) == [[-v for v in r] for r in Id] for k in range(n))
    Nop = [[0] * N for _ in range(N)]
    for k in range(n): Nop = add(Nop, dmul(eps[k], iot[k]))
    ok &= Nop == [[pc(a) if a == b else 0 for b in range(N)] for a in range(N)]
    by_n = [sum(1 for a in range(N) if pc(a) == j) for j in range(n + 1)]
    put = {}
    for a in range(N):
        for k in range(n):
            col = [eps[k][r][a] for r in range(N)]; nzr = [r for r in range(N) if col[r]]
            put[f'{a},{k}'] = [nzr[0], col[nzr[0]]] if nzr else None
    ok &= all((put[f'{a},{k}'] is None) == bool(a >> k & 1) for a in range(N) for k in range(n))
    S3 = sig(3, 0); DIRS = {'z': 4, 'x': 1, 'y': 2}           # up-down = e3, left-right = e1, front-back = e2
    def proj(dname):
        s = -1 if dname[0] == '-' else 1; return {0: Fr(1, 2), DIRS[dname[-1]]: Fr(s, 2)}
    names = ['z', '-z', 'x', '-x', 'y', '-y']
    pass_p = {f'{u}>{v}': str(mv_mul(proj(v), proj(u), S3).get(0, 0) / Fr(1, 2)) for u in names for v in names}
    ok &= all(pass_p[f'{u}>{v}'] == ('1' if u == v else '0' if u[-1] == v[-1] else '1/2') for u in names for v in names)
    PzPx, PxPz = mv_mul(proj('z'), proj('x'), S3), mv_mul(proj('x'), proj('z'), S3)
    ok &= PzPx != PxPz and mv_mul({4: 1}, {1: 1}, S3) == {5: -1} and mv_mul({1: 1}, {4: 1}, S3) == {5: 1}
    seq = [pass_p['z>z'], pass_p['z>x'], pass_p['x>z']]
    data['p4'] = {'by_number': by_n, 'put': put, 'pass': pass_p, 'sequence': seq}
    chk('P4', ok and by_n == [1, 3, 3, 1] and seq == ['1', '1/2', '1/2'],
        'three seats: the Fock space of three modes is the 8 labels, 1, 3, 3, 1 by number of particles (N = sum eps_k iota_k is the popcount); putting a particle into a full seat gives 0 '
        '(eps_k^2 = 0, Pauli), {eps_k, iota_l} = delta_kl, and eps_k +- iota_k square to +1 and -1: eps_k is half the sum of a plus and a minus switch, a paired zero whose partner iota_k takes the '
        'particle out; three magnets in Cl(3,0) with projectors (1 + e)/2: same direction 1, sideways 1/2, opposite 0; the sequence z, z / z, x / x, z passes 1, 1/2, 1/2; P_z P_x != P_x P_z because e3 e1 = -e1 e3')
    P = {'I': [[1, 0], [0, 1]], 'X': [[0, 1], [1, 0]], 'Y': [[0, -1j], [1j, 0]], 'Z': [[1, 0], [0, -1]]}
    def k2(A, B): return [[A[i // 2][j // 2] * B[i % 2][j % 2] for j in range(4)] for i in range(4)]
    def m4(A, B): return [[sum(A[i][t] * B[t][j] for t in range(4)) for j in range(4)] for i in range(4)]
    gam = [k2(P['X'], P['I']), k2(P['Y'], P['I']), k2(P['Z'], P['X']), k2(P['Z'], P['Y'])]   # Jordan-Wigner Majoranas of two qubits
    strings = {s1 + s2: k2(P[s1], P[s2]) for s1 in 'IXYZ' for s2 in 'IXYZ'}; table = {}; ok = True
    for a in range(16):
        M = [[complex(int(i == j)) for j in range(4)] for i in range(4)]
        for i in range(4):
            if a >> i & 1: M = m4(M, gam[i])
        hit = [(s, ph) for s, Pm in strings.items() for ph in (1, 1j, -1, -1j) if all(M[i][j] == ph * Pm[i][j] for i in range(4) for j in range(4))]
        sq = bmul(a, a, [1, 1, 1, 1])[0]; herm = all(M[i][j] == M[j][i].conjugate() for i in range(4) for j in range(4))
        ok &= len(hit) == 1 and (sq == 1) == herm
        table[str(a)] = {'pauli': hit[0][0] if hit else '?', 'phase': {1: '1', 1j: 'i', -1: '-1', -1j: '-i'}[hit[0][1]] if hit else '?', 'square': sq}
    data['p4b'] = table
    chk('P4b', ok and len({t['pauli'] for t in table.values()}) == 16 and sum(t['square'] == 1 for t in table.values()) == 6,
        'two qubits: the 16 blades of Cl(4,0) built from the Jordan-Wigner Majoranas XI, YI, ZX, ZY are the 16 Pauli strings, each up to a phase in {1, i, -1, -i}, all distinct; '
        'a blade squares to +1 exactly when it is Hermitian: 6 of 16')

def run():
    data = {'script': 'selfcheck/reports/lens_sch_check.py', 'default': {'mom': default_mom(5), 'm': DEFAULT_M}}
    p1(data); p1b(data); p1c(data); p2(data); p3(data); p4(data)
    return json.loads(json.dumps(data))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--write'); ap.add_argument('--compare'); a = ap.parse_args()
    data = run()
    if a.write: json.dump(data, open(a.write, 'w'), indent=1, ensure_ascii=False); print('wrote', a.write)
    if a.compare:
        same = json.load(open(a.compare)) == data; chk('fixture', same, 'the stored fixture ' + a.compare + (' equals' if same else ' DIFFERS from') + ' what the checks compute')
    print(f'\nlens_sch_check: {N_OK} ok, {N_BAD} failed')
    sys.exit(1 if N_BAD else 0)
