// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Benchmark of the label claims of step 16 (G1-G4 of pgadyn_selfcheck.py are exact; this file times them).  node bench_labels.mjs [--quick] [--write bench_labels.json]
// Method: for every n the variants are first checked to give the same answers; then each is timed in batches (a batch lasts at least 60 ms), 7 batches, and the median batch is reported
// with the fastest and slowest batch. Nothing here is exact and nothing is a claim about other machines.
import os from 'node:os';
import fs from 'node:fs';
// Written: { machine, rows (vertices, contact, outline), product (n = 2..12), alloc (allocation of 8 to 64 doubles, plain Array against Float64Array, with the page's own allocation kernel) }.
// selfcheck/regen_bench.sh runs this and then regenerates benchData.js, the README tables (bench_tables.mjs) and label_bench.html.
import { runBench, checkAll, timeIt, allocKernels, ALLOC_SIZES } from '../benchKernels.js';
import { PRODUCT_NS, productCheck, productSetup, productVariants } from '../productKernels.js';
const quick = process.argv.includes('--quick'), wi = process.argv.indexOf('--write');
const now = () => Number(process.hrtime.bigint()) / 1e6;
const fmt = r => r ? (r.med >= 1e7 ? (r.med / 1e6).toFixed(1) + ' ms' : r.med >= 1e4 ? (r.med / 1e3).toFixed(1) + ' us' : r.med.toFixed(0) + ' ns') : '-';
const ratio = (a, b) => a && b ? (a.med / b.med).toFixed(2) + 'x' : '-';
const spread = r => r ? ((r.max - r.min) / r.med * 100).toFixed(0) + '%' : '-';
const info = { node: process.version, platform: `${os.platform()} ${os.arch()}`, cpu: os.cpus()[0].model, cores: os.cpus().length, date: new Date().toISOString().slice(0, 10), minMs: quick ? 20 : 60, reps: quick ? 5 : 7 };
console.log(`node ${info.node} on ${info.platform}, ${info.cpu} (${info.cores} cores); batches >= ${info.minMs} ms, ${info.reps} batches, median reported\n`);
const rows = runBench({ now, minMs: info.minMs, reps: info.reps });
const line = (h, f) => { console.log(h.padEnd(34) + rows.map(r => f(r).padStart(11)).join('')); };
line('n', r => String(r.n)); line('sandwiches direct / frame', r => `${r.sandwichesDirect}/${r.sandwichesFrame}`);
console.log('\n(1) the 2^n world vertices from a motor');
line('direct (2^n sandwiches)', r => fmt(r.ns.direct)); line('frame (n+1 sandwiches + adds)', r => fmt(r.ns.frame)); line('  direct / frame', r => ratio(r.ns.direct, r.ns.frame)); line('frame, then n^2 flops a vertex', r => fmt(r.ns.matrix)); line('  matrix / frame', r => ratio(r.ns.matrix, r.ns.frame)); line('table step alone: doubling', r => fmt(r.ns.doubling)); line('table step alone: n^2 a vertex', r => fmt(r.ns.matrixGiven)); line('  n^2 / doubling', r => ratio(r.ns.matrixGiven, r.ns.doubling)); line('frame with mirrored odd half', r => fmt(r.ns.mirror)); line('  frame / mirror', r => ratio(r.ns.frame, r.ns.mirror)); line('  spread of the frame batches', r => spread(r.ns.frame));
console.log('\n(2) the deepest vertex under a plane');
line('scan of a given table (2^n dots)', r => fmt(r.ns.scan)); line('n sign bits of a given frame', r => fmt(r.ns.bits)); line('  scan / bits', r => ratio(r.ns.scan, r.ns.bits));
line('build table, then scan', r => fmt(r.ns.scanBuilt)); line('build frame, then bits', r => fmt(r.ns.bitsBuilt)); line('  scan+build / bits+build', r => ratio(r.ns.scanBuilt, r.ns.bitsBuilt));
console.log('\n(3) the flat outline (2n vertices)');
line('hull of the 2^n projected points', r => fmt(r.ns.hull)); line('zonogon from n projected edges', r => fmt(r.ns.zono)); line('  hull / zonogon', r => ratio(r.ns.hull, r.ns.zono));
line('table + project + hull', r => fmt(r.ns.hullBuilt)); line('frame + project + zonogon', r => fmt(r.ns.zonoBuilt)); line('  hull+build / zonogon+build', r => ratio(r.ns.hullBuilt, r.ns.zonoBuilt));
// (5, timed before the product so that its large tables do not sit in the heap) allocation of one multivector: the kernel of the page's Allocation scenario (benchKernels.js, allocKernels)
const arows = [];
for (const k of ALLOC_SIZES) { const ak = allocKernels(k), ns = {}; for (const name of ['plain', 'f64']) { const r = timeIt(ak[name], now, info.minMs, info.reps); ns[name] = { med: r.med * 1e6, min: r.min * 1e6, max: r.max * 1e6 }; } arows.push({ doubles: k, ns }); }
// (4) the dense product of two multivectors of Cl(k,k): the bit rule against the matrix route (productKernels.js; selfcheck/matrixrep_check.py proves the representation exactly)
const prows = [];
for (const n of PRODUCT_NS.filter(n => n <= 12)) {
  if (!productCheck(n).ok) throw new Error('the product variants disagree at n = ' + n);
  const fns = productVariants(productSetup(n)), ns = {};
  for (const [name, fn] of Object.entries(fns)) { const r = timeIt(fn, now, info.minMs, info.reps); ns[name] = { med: r.med * 1e6, min: r.min * 1e6, max: r.max * 1e6 }; }
  prows.push({ n, terms: Math.pow(4, n), mults: Math.pow(8, n / 2), ns });
}
const pline = (h, f) => { console.log(h.padEnd(34) + prows.map(r => f(r).padStart(11)).join('')); };
console.log('\n(4) the dense product of two multivectors of Cl(k,k), n = 2k');
pline('n', r => String(r.n)); pline('bit rule (4^n terms)', r => fmt(r.ns.bitRule)); pline('bit rule, sign table given', r => fmt(r.ns.signTable)); pline('matrix product alone (8^k mults)', r => fmt(r.ns.matmulGiven));
pline('matrix route, whole (7 allocations)', r => fmt(r.ns.matrixRoute)); pline('  sign table / matrix route', r => ratio(r.ns.signTable, r.ns.matrixRoute)); pline('  bit rule / matrix route', r => ratio(r.ns.bitRule, r.ns.matrixRoute)); pline('  spread of the matrix route', r => spread(r.ns.matrixRoute));
pline('matrix route, buffers once', r => fmt(r.ns.matrixRouteReuse)); pline('sign table, output once', r => fmt(r.ns.signTableReuse)); pline('  the two, buffers once', r => ratio(r.ns.signTableReuse, r.ns.matrixRouteReuse)); pline('the route\'s 7 allocations alone', r => fmt(r.ns.routeAllocs)); pline('  allocations / route', r => ratio(r.ns.routeAllocs, r.ns.matrixRoute));
pline('period 8: 16 x 16 blocks over Cl(n-8)', r => fmt(r.ns.period8)); pline('  sign table / period 8', r => ratio(r.ns.signTable, r.ns.period8));
console.log('\n(5) allocation of one multivector');
for (const a of arows) console.log(`${(a.doubles + ' doubles').padEnd(12)} plain Array ${fmt(a.ns.plain).padStart(9)}   Float64Array ${fmt(a.ns.f64).padStart(9)}   Float64Array / plain ${ratio(a.ns.f64, a.ns.plain)}`);
if (wi > 0) { fs.writeFileSync(process.argv[wi + 1], JSON.stringify({ machine: info, rows, product: prows, alloc: arows }, null, 1)); console.log('\nwrote', process.argv[wi + 1]); }
