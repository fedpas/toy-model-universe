#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Chapter script 1: are the labels -1, +1, 0 (and the q of Cl(p,q)) real?  Walk up from Cl(0) = R, one generator at a time.
Needs numpy (only for the matrix-exponential checks of section 9).  Everything else is exact integer/rational arithmetic.
  python3 labels_check.py            run every check, print the tables, end with ALL LABELS CHECKS PASS
The textbook mod-8 table (TYPES) is used only to COMPARE with what the invariants give, never as an input."""
import sys, math, random, cmath, itertools
from fractions import Fraction
from bitcliff import *
import numpy as np

def head(s): print('\n== ' + s)

# ------------------------------------------------------------------------------------------------ invariants -> Wedderburn type
def wedderburn(D, zdim, Np, Nm):
    """semisimple real algebra of dimension D with centre of dimension zdim; Np/Nm = number of basis blades squaring to +1/-1.
    The trace form Tr(L_xy) is diagonal on blades with entries 2^n * (blade square), so (Np, Nm) is its signature.
    M_k(R): d = k ; M_k(H): d = -2k ; M_k(C): d = 0 ; two copies: d doubles.  (checked against dimensions)"""
    d = Np - Nm
    if zdim == 1:
        if d > 0:
            assert d * d == D, (D, d); return ('R', d, 1)
        assert d < 0 and (-d) % 2 == 0 and 4 * (d // 2) ** 2 == D, (D, d); return ('H', -d // 2, 1)
    assert zdim == 2
    if d == 0:
        k = round(math.sqrt(D / 2)); assert 2 * k * k == D; return ('C', k, 1)
    if d > 0:
        assert d % 2 == 0 and 2 * (d // 2) ** 2 == D, (D, d); return ('R', d // 2, 2)
    assert (-d) % 4 == 0 and 8 * (d // 4) ** 2 == D, (D, d); return ('H', -d // 4, 2)

def tname(t):
    K, k, m = t
    return f'M{k}({K})' + ('^2' if m == 2 else '') if k > 1 else (K if m == 1 else K + '+' + K)

def type_full(p, q):
    """type of Cl(p,q) from invariants only"""
    A = Alg(sig(p, q)); n = p + q
    Z = len(A.center_blades())
    return wedderburn(2 ** n, Z, *A.counts()[:2])

def type_even(p, q):
    """type of the even subalgebra Cl0(p,q) from invariants only (n >= 1)"""
    A = Alg(sig(p, q)); n = p + q
    ev = [a for a in range(A.N) if pc(a) % 2 == 0]
    gens = [(1 << i) | (1 << j) for i in range(n) for j in range(i + 1, n)]
    Z = [c for c in ev if all(A.comm_sign(c, g) == 1 for g in gens)] if n >= 2 else ev
    Np = sum(1 for a in ev if A.sq(a) == 1); Nm = sum(1 for a in ev if A.sq(a) == -1)
    return wedderburn(len(ev), len(Z), Np, Nm)

def expected(K, D):
    return {'R': ('R', round(math.sqrt(D)), 1), 'R2': ('R', round(math.sqrt(D / 2)), 2), 'C': ('C', round(math.sqrt(D / 2)), 1),
            'H': ('H', round(math.sqrt(D / 4)), 1), 'H2': ('H', round(math.sqrt(D / 8)), 2)}[K]

# ------------------------------------------------------------------------------------------------ 1. the engine itself
head('1. engine: the bit rule is associative for every sign pattern, degenerate ones included')
for e in [sig(3, 0), sig(0, 3), sig(2, 2), sig(1, 3), sig(3, 0, 1), sig(2, 1, 1), sig(1, 1, 2), sig(0, 0, 3), sig(4, 2)]:
    assert associativity_check(Alg(e), trials=25), e
print('   associative on 9 sign patterns (random multivectors): OK')

# ------------------------------------------------------------------------------------------------ 2. n = 0 and n = 1
head('2. n = 0 and n = 1: the first labels')
A0 = Alg(())
assert A0.N == 1 and A0.mul({0: 1}, {0: 1}) == {0: 1}
print('   Cl(0) = R: one blade (the empty address), no generator, no sign, nothing to label.')
# one generator, x^2 = c in {-1, 0, +1}.  Classify the 2-dim algebra R[x]/(x^2 - c) by what its elements can do.
def one_gen_profile(c):
    zd = idem = nil = 0
    for a in range(-4, 5):
        for b in range(-4, 5):
            if (a, b) == (0, 0): continue
            n2 = a * a + c * b * b                                      # (a + b x)(a - b x) = a^2 - c b^2 with x^2 = c  ->  use c as +1/-1/0
    # direct: (a+bx)(a'+b'x) = (aa' + c bb') + (ab' + a'b) x
    mul = lambda u, v: (u[0] * v[0] + c * u[1] * v[1], u[0] * v[1] + u[1] * v[0])
    idems = [(a / 2, b / 2) for a in range(-4, 5) for b in range(-4, 5) if (a, b) not in ((0, 0), (2, 0)) and mul((a / 2, b / 2), (a / 2, b / 2)) == (a / 2, b / 2)]
    nils = [(a, b) for a in range(-4, 5) for b in range(-4, 5) if (a, b) != (0, 0) and mul((a, b), (a, b)) == (0, 0)]
    zds = [(a, b) for a in range(-4, 5) for b in range(-4, 5) if (a, b) != (0, 0) and any(mul((a, b), (a2, b2)) == (0, 0) for a2 in range(-4, 5) for b2 in range(-4, 5) if (a2, b2) != (0, 0))]
    return len(idems), len(nils), len(zds)
prof = {c: one_gen_profile(c) for c in (-1, 1, 0)}
print('   x^2 = -1 : (idempotents, nilpotents, zero-divisors) =', prof[-1], ' -> a field, the complex numbers')
print('   x^2 = +1 : (idempotents, nilpotents, zero-divisors) =', prof[1], ' -> R + R, two idempotents (1 +- x)/2')
print('   x^2 =  0 : (idempotents, nilpotents, zero-divisors) =', prof[0], ' -> dual numbers, a nilpotent, no idempotent')
assert prof[-1] == (0, 0, 0) and prof[1][0] == 2 and prof[1][1] == 0 and prof[0][0] == 0 and prof[0][1] > 0
print('   three different 2-dim algebras, and exactly three: x -> t x rescales c by t^2, so only the sign of c survives (c in {-,0,+}).')
# in the bit rule the sign coefficients must be +-1 (basis elements are units of a twisted group algebra)
A1p, A1m, A1z = Alg((1,)), Alg((-1,)), Alg((0,))
inv = lambda A: A.blade_mul(1, 1)[0] != 0
assert inv(A1p) and inv(A1m) and not inv(A1z)
print('   bit rule: s(1,1) = +-1 makes e1 invertible; a 0 there makes e1 a nilpotent, not a unit: a null generator is NOT a +-1 cocycle value (the same formula with a 0 is still associative, but the blades then form a monoid with a zero, not a group; it is a contraction / quotient).')
assert type_full(1, 0)[:3] == ('R', 1, 2) and type_full(0, 1) == ('C', 1, 1)
print('   Cl(1,0) =', tname(type_full(1, 0)), '(R + R);  Cl(0,1) =', tname(type_full(0, 1)), '(C).  At n = 1 there is no pair of anticommuting blades, so no nilpotent lives inside either.')

# ------------------------------------------------------------------------------------------------ 3. n = 2: the three labels inside Cl(2,0)
head('3. n = 2: all three labels appear inside the ALL-POSITIVE cell Cl(2,0) = M_2(R)')
A = Alg(sig(2, 0))
M = {0: np.eye(2, dtype=int), 1: np.array([[1, 0], [0, -1]]), 2: np.array([[0, 1], [1, 0]])}
M[3] = M[1] @ M[2]
assert (M[3] == np.array([[0, 1], [-1, 0]])).all()
for a in range(4):
    for b in range(4):
        s, c = A.blade_mul(a, b)
        assert (M[a] @ M[b] == s * M[c]).all()
assert abs(np.linalg.det(np.array([M[a].flatten() for a in range(4)], dtype=float))) > 0.5
print('   e1 = [[1,0],[0,-1]], e2 = [[0,1],[1,0]], e12 = e1 e2 = [[0,1],[-1,0]]: the bit rule is reproduced and the 4 matrices span M_2(R): Cl(2,0) = M_2(R).')
cls = {'elliptic (X^2 < 0)': 0, 'hyperbolic (X^2 > 0)': 0, 'parabolic (X^2 = 0, X != 0)': 0}
for a, b, c in itertools.product(range(-6, 7), repeat=3):
    if (a, b, c) == (0, 0, 0): continue
    X = a * M[1] + b * M[2] + c * M[3]
    Qv = a * a + b * b - c * c
    assert (X @ X == Qv * M[0]).all()                       # X^2 = (a^2 + b^2 - c^2) * 1, exactly
    det = round(np.linalg.det(X.astype(float)))
    assert det == -Qv
    cls['elliptic (X^2 < 0)' if Qv < 0 else 'hyperbolic (X^2 > 0)' if Qv > 0 else 'parabolic (X^2 = 0, X != 0)'] += 1
print('   X = a e1 + b e2 + c e12 (traceless part, 3-dim):  X^2 = (a^2 + b^2 - c^2) 1  exactly, det X = -(a^2 + b^2 - c^2).  Counts on the grid [-6,6]^3:')
for k, v in cls.items(): print('      %-30s %5d' % (k, v))
assert all(v > 0 for v in cls.values())
print('   So the traceless part is a 3-dim space with a quadratic form of signature (2,1) (Minkowski R^{2,1}); the three labels are its three causal types:')
print('      timelike (X^2 = -1) -> rotation / oscillator ;  spacelike (X^2 = +1) -> boost / inverted oscillator ;  lightlike (X^2 = 0) -> translation / free motion.')
# the flows: exp(tX) by series, exact closed forms
def expm_series(X, t, terms=60):
    S = np.eye(2); T = np.eye(2)
    for k in range(1, terms):
        T = T @ (t * X) / k; S = S + T
    return S
for (a, b, c), kind in [((0, 0, 1), 'rot'), ((1, 0, 0), 'boost'), ((0, 1, 1), 'null')]:
    X = a * M[1] + b * M[2] + c * M[3]; Qv = a * a + b * b - c * c; t = 0.7
    E = expm_series(X.astype(float), t)
    want = (math.cos(t) * np.eye(2) + math.sin(t) * X) if Qv < 0 else (math.cosh(t) * np.eye(2) + math.sinh(t) * X) if Qv > 0 else (np.eye(2) + t * X)
    assert np.allclose(E, want, atol=1e-12)
print('   exp(tX) = cos t + X sin t  /  cosh t + X sinh t  /  1 + t X   for the three representatives (tolerance 1e-12).')
# the spring: [[0,1],[-k,0]] is the generator of  x'' = -k x ; its square is -k.  Where does it sit in the (2,1) space?
for k in (Fraction(3), Fraction(-2), Fraction(0), Fraction(1, 2)):
    b_, c_ = (1 - k) / 2, (1 + k) / 2
    Q_ = b_ * b_ - c_ * c_
    assert Q_ == -k
    Xs = [[b_ * 0 + c_ * 0, b_ + c_], [b_ - c_, 0]]               # a=0: [[0, b+c],[b-c, 0]] = [[0,1],[-k,0]]
    assert Xs == [[0, 1], [-k, 0]]
print('   spring x\'\' = -k x : [[0,1],[-k,0]] = ((1-k)/2) e2 + ((1+k)/2) e12, Minkowski norm -k.  The sign of the spring IS the causal type of the generator (k>0 oscillator, k<0 inverted, k=0 free).')
for (p, q) in [(1, 1), (0, 2)]:
    T = [ (a_, b_, c_) for a_, b_, c_ in itertools.product(range(-3, 4), repeat=3) if (a_, b_, c_) != (0, 0, 0)]
    B = Alg(sig(p, q)); sqs = set()
    for a_, b_, c_ in T:
        X = {1: a_, 2: b_, 3: c_}; XX = B.mul(X, X); assert set(XX) <= {0}
        sqs.add((XX.get(0, 0) > 0) - (XX.get(0, 0) < 0))
    print(f'   Cl({p},{q}) traceless part: signs of X^2 that occur = {sorted(sqs)}', '(all three: M_2(R) again)' if len(sqs) == 3 else '(only -1: su(2), no boost, no null: the quaternions)')
    assert (len(sqs) == 3) == (type_full(p, q)[0] == 'R')

# ------------------------------------------------------------------------------------------------ 4. even subalgebras
head('4. the negative cells are even subalgebras of the positive ones (explicit maps, every generator pair, n <= 8)')
def even_iso(p, q, r):
    A = Alg(sig(p, q)); n = p + q
    eps = A.eps; rest = [j for j in range(n) if j != r]
    eps2 = tuple(-eps[r] * eps[j] for j in rest)
    B = Alg(eps2)
    f = {}
    for idx, j in enumerate(rest):
        f[idx] = A.mul({1 << r: 1}, {1 << j: 1})                # f_j = e_r e_j
    # relations: f_i^2 = eps2_i, f_i f_j = -f_j f_i
    for i in f:
        assert A.mul(f[i], f[i]) == ({0: eps2[i]} if eps2[i] else {})
        for j in f:
            if i < j: assert A.add(A.mul(f[i], f[j]), A.mul(f[j], f[i])) == {}
    def phi(S):
        out = {0: 1}
        for i in range(n - 1):
            if S >> i & 1: out = A.mul(out, f[i])
        return out
    img = {S: phi(S) for S in range(B.N)}
    images = set()
    for S, v in img.items():
        assert len(v) == 1; (m, c), = v.items(); assert pc(m) % 2 == 0 and abs(c) == 1; images.add(m)
    assert len(images) == B.N == 2 ** (n - 1)                    # bijection onto the even blades
    for S in range(B.N):
        for T in range(B.N):
            s, U = B.blade_mul(S, T)
            assert A.mul(img[S], img[T]) == A.scal(img[U], s)
    return Alg(eps2).eps
cnt = 0
for n in range(1, 9):
    for p in range(n + 1):
        q = n - p
        if p >= 1: e1 = even_iso(p, q, 0); assert e1.count(1) == q and e1.count(-1) == p - 1; cnt += 1       # Cl0(p,q) = Cl(q, p-1)
        if q >= 1: e2 = even_iso(p, q, p); assert e2.count(1) == p and e2.count(-1) == q - 1; cnt += 1       # Cl0(p,q) = Cl(p, q-1)
print(f'   {cnt} explicit isomorphisms checked: Cl0(p,q) = Cl(q, p-1) (reference generator positive) and Cl0(p,q) = Cl(p, q-1) (reference negative).')
print('   in particular Cl(0,m) = Cl0(m+1, 0): the whole negative family is the rotor (even) algebra of the positive family one dimension up:')
print('      C = Cl0(2,0), H = Cl0(3,0), H+H = Cl0(4,0), M_2(H) = Cl0(5,0), M_4(C) = Cl0(6,0), M_8(R) = Cl0(7,0), M_8(R)^2 = Cl0(8,0), M_16(R) = Cl0(9,0)')
for m in range(0, 9):
    assert type_full(0, m) == type_even(m + 1, 0), m
print('   (types agree for m = 0..8 by invariants as well)')

# ------------------------------------------------------------------------------------------------ 5. classification from invariants, all cells n <= 10
head('5. every Cl(p,q), n <= 10, classified from (dimension, centre, blade-square counts) and compared with the textbook mod-8 table')
rows = {}
for n in range(0, 11):
    for p in range(n + 1):
        q = n - p; t = type_full(p, q)
        assert t == expected(TYPES[(p - q) % 8], 2 ** n), (p, q, t)
        rows[(p, q)] = t
print('   66 cells: invariants == textbook table (types AND matrix sizes).  Classes by s = p - q mod 8 :')
for s in range(8):
    ex = [(p, n - p) for n in range(0, 9) for p in range(n + 1) if (2 * p - n) % 8 == s][:4]
    print('     s = %d : %-4s  e.g. %s' % (s, TYPES[s], ', '.join(f'Cl{c}={tname(rows[c])}' for c in ex[:3])))

# ------------------------------------------------------------------------------------------------ 6. ungraded vs graded
head('6. ungraded algebra has 5 types; the graded algebra (algebra + its even part) has 8 classes: the Z_8 clock is the GRADING')
graded = {}
for (p, q), t in rows.items():
    n = p + q
    if n == 0: continue
    graded[(p, q)] = (n, tname(t), tname(type_even(p, q)))
byclass = {}
for (p, q), g in graded.items():
    byclass.setdefault(g, set()).add((p - q) % 8)
assert all(len(v) == 1 for v in byclass.values())               # (n, type of A, type of A0) determines s mod 8
byUn = {}
for (p, q), g in graded.items():
    byUn.setdefault((g[0], g[1]), set()).add((p - q) % 8)
n_graded = len({(p - q) % 8 for (p, q) in graded}); n_un = len({(t[0], t[2]) for t in rows.values()})
print(f'   (n, type of A, type of A0) determines s mod 8 for all cells n=1..10: {len(byclass)} triples, each belongs to one s class.')
print(f'   ungraded Morita types: {n_un}  (R, R+R, C, H, H+H);   graded classes: {n_graded}  (s mod 8).')
for s in range(8):
    ex = next((p, n - p) for n in range(2, 9) for p in range(n + 1) if (2 * p - n) % 8 == s and n >= 2)
    print('     s = %d  A = %-8s  A0 = %-8s  (n=%d, e.g. Cl%s)' % (s, tname(rows[ex]), tname(type_even(*ex)), sum(ex), ex))
for c1, c2 in [((2, 0), (1, 1)), ((3, 1), (2, 2)), ((4, 0), (1, 3))]:
    assert rows[c1] == rows[c2] and type_even(*c1) != type_even(*c2), (c1, c2)
    print('     same algebra, different grading:  Cl%s = Cl%s = %s,  but Cl0%s = %s  vs  Cl0%s = %s' % (c1, c2, tname(rows[c1]), c1, tname(type_even(*c1)), c2, tname(type_even(*c2))))

# ------------------------------------------------------------------------------------------------ 7. the real label: a quadratic form over F_2 on the addresses
head('7. the sign data is ONE quadratic form Q over F_2 on the n address bits; (p,q) is only a presentation of it')
def Qform(p, q):
    A = Alg(sig(p, q)); return A, [1 if A.sq(a) == -1 else 0 for a in range(A.N)]
for n in range(0, 9):
    for p in range(n + 1):
        A, Q = Qform(p, n - p)
        for a in range(A.N):
            for b in range(0, A.N, 1 if n <= 6 else 5):
                assert Q[a ^ b] == (Q[a] + Q[b] + (0 if a == 0 or b == 0 else (1 - A.comm_sign(a, b)) // 2)) % 2
print('   for every cell n <= 8:  Q(a) = [e_a^2 = -1]  satisfies  Q(a+b) = Q(a) + Q(b) + B(a,b)  with B(a,b) = the COMMUTATION bit of e_a, e_b:')
print('   a genuine quadratic form over F_2 whose polarization is the commutation sign.  Both are bits indexed by addresses: the bit rule, nothing added.')
def classify_form(p, q):
    A, Q = Qform(p, q); n = p + q
    zeros = sum(1 for a in range(A.N) if Q[a] == 0)
    rad = [a for a in range(A.N) if all(A.comm_sign(a, 1 << i) == 1 for i in range(n))]
    if n % 2 == 0:
        assert rad == [0] or n == 0
        arf = 0 if zeros == 2 ** (n - 1) + 2 ** (n // 2 - 1) else 1
        if n: assert zeros == 2 ** (n - 1) + (-1) ** arf * 2 ** (n // 2 - 1)
        return ('even', arf)
    beta = [a for a in rad if a][0]
    if Q[beta]: return ('odd', 'C')
    # Q descends to V/<beta>: Arf of the quotient
    quot = {}
    for a in range(A.N): quot.setdefault(min(a, a ^ beta), Q[a])
    z = sum(1 for v in quot.values() if v == 0); m = (n - 1)
    arf = 0 if z == 2 ** (m - 1) + 2 ** (m // 2 - 1) else 1
    return ('odd', 'R2' if arf == 0 else 'H2')
for n in range(1, 9):
    for p in range(n + 1):
        f = classify_form(p, n - p); K = TYPES[(2 * p - n) % 8]
        assert (f == ('even', 0) and K == 'R') or (f == ('even', 1) and K == 'H') or (f[0] == 'odd' and f[1] == K), (p, n - p, f, K)
print('   the ALGEBRA TYPE is read off Q alone:  even n : Arf = 0 <-> R, Arf = 1 <-> H ;  odd n : the radical (pseudoscalar) is a square -1 <-> C, else the Arf of the quotient gives R+R or H+H.  (n <= 8, all cells)')
print('   number of presentations (p,q) of each form class, by n:')
for n in range(2, 9):
    c = {}
    for p in range(n + 1): c.setdefault(tuple(classify_form(p, n - p)), []).append((p, n - p))
    print('     n = %d : ' % n + ' ; '.join(f'{k[1] if k[0]=="odd" else ("+" if k[1]==0 else "-")}: {len(v)} cells' for k, v in sorted(c.items(), key=str)))

# ------------------------------------------------------------------------------------------------ 8. only positive generators: the positive family runs the whole clock, negative squares are 'vector times i'
head('8. only positive generators: every Cl(p,q) lives inside Cl(n+2, 0), a negative generator is (positive vector) x (the rotation unit of two extra positive directions)')
def embed_in_positive(p, q):
    A = Alg(sig(p, q)); n = p + q; Big = Alg(sig(n + 2, 0))
    P = Big.mul({1 << n: 1}, {1 << (n + 1): 1})                  # the bivector e_{n+1} e_{n+2}, P^2 = -1
    assert Big.mul(P, P) == {0: -1}
    gen = []
    for j in range(n):
        gen.append({1 << j: 1} if A.eps[j] == 1 else Big.mul({1 << j: 1}, P))
    for i in range(n):
        assert Big.mul(gen[i], gen[i]) == {0: A.eps[i]}
        for j in range(i + 1, n): assert Big.add(Big.mul(gen[i], gen[j]), Big.mul(gen[j], gen[i])) == {}
    img = {}
    for S in range(A.N):
        out = {0: 1}
        for i in range(n):
            if S >> i & 1: out = Big.mul(out, gen[i])
        img[S] = out
    masks = {list(v)[0] for v in img.values()}
    assert all(len(v) == 1 for v in img.values()) and len(masks) == A.N       # distinct blades: injective
    for S in range(A.N):
        for T in range(A.N):
            s, U = A.blade_mul(S, T); assert Big.mul(img[S], img[T]) == Big.scal(img[U], s)
    for S in range(A.N):                                          # graded: odd stays odd
        assert pc(S) % 2 == pc(list(img[S])[0]) % 2
cnt = 0
for n in range(1, 7):
    for p in range(n + 1): embed_in_positive(p, n - p); cnt += 1
print(f'   {cnt} cells (n <= 6) embedded as GRADED subalgebras of Cl(n+2,0):  e_j -> e_j (positive),  e_j -> e_j e_(n+1) e_(n+2) (negative).')
print('   The negative generator is a TRIVECTOR: a positive vector times P = e_(n+1)e_(n+2), the rotation bivector, P^2 = -1, which commutes with everything inside.')
print('   So "-1" never has to be postulated: it is the square of a rotation plane of two positive directions.  (The mirror embedding into Cl(0,n+2) works the same way.)')
print('   The positive family alone runs the whole clock:')
for n in range(0, 9):
    t = rows[(n, 0)]; tm = rows[(0, n)]
    print('     n = %d : Cl(%d,0) = %-9s   Cl(0,%d) = %-9s = Cl0(%d,0)' % (n, n, tname(t), n, tname(tm), n + 1))
# grade clock of blade squares in Cl(n,0)
print('   squares of grade-k blades in Cl(n,0): (-1)^(k(k-1)/2) = +,+,-,-,+,+,-,- ... ; number of i-like blades (square -1) in Cl(n,0):', [sum(math.comb(n, k) for k in range(n + 1) if (k * (k - 1) // 2) % 2) for n in range(0, 9)])
for n in range(0, 9):
    assert Alg(sig(n, 0)).counts()[1] == sum(math.comb(n, k) for k in range(n + 1) if (k * (k - 1) // 2) % 2)

# ------------------------------------------------------------------------------------------------ 9. where '0' comes from, and where the three-way sorting stops
head('9. the label 0: not a bit-rule value, but present inside every cell with n >= 2 as sums of two anticommuting blades of opposite sign')
def nilpotent_pairs(p, q):
    A = Alg(sig(p, q)); n = p + q; out = []
    for a in range(1, A.N):
        for b in range(a + 1, A.N):
            if A.comm_sign(a, b) == -1 and A.sq(a) == -A.sq(b):
                x = {a: 1, b: 1}; assert A.mul(x, x) == {}; out.append((a, b))
    return out
for cell in [(1, 0), (0, 1), (2, 0), (1, 1), (0, 2), (3, 0), (0, 3)]:
    print(f'   Cl{cell}: pairs (e_a, e_b) anticommuting with opposite squares, so (e_a + e_b)^2 = 0 :', len(nilpotent_pairs(*cell)))
assert len(nilpotent_pairs(1, 0)) == len(nilpotent_pairs(0, 1)) == 0 and len(nilpotent_pairs(2, 0)) == 2 and len(nilpotent_pairs(0, 2)) == 0
print('   Cl(2,0): e1 + e12 and e2 + e12 (and sign variants) are nilpotent, because e1^2 = +1 and e12^2 = -1 anticommute.  Cl(0,2) = H has none (a division algebra).')
print('   A null GENERATOR (Cl(p,q,r), r > 0) is a different thing: non-semisimple, Cl(p,q) (x) Lambda(R^r); it is a contraction of Cl(p+1,q) / Cl(p,q+1), not a cocycle.')
# degenerate: radical dimension
for (p, q, r) in [(1, 0, 1), (2, 0, 1), (1, 1, 1), (0, 0, 2), (3, 0, 1)]:
    A = Alg(sig(p, q, r)); n = p + q + r
    rad = [a for a in range(A.N) if any(A.eps[i] == 0 and (a >> i & 1) for i in range(n))]
    assert len(rad) == 2 ** n - 2 ** (p + q)
print('   degenerate cells: the span of blades that contain a null index is an ideal of dimension 2^n - 2^(p+q) (checked for 5 cells); the quotient is Cl(p,q).')

head('10. where "square -1/+1/0 sorts the motions" stops being exhaustive: bivectors with non-scalar square, and the invariant decomposition')
def bivectors(n): return [a for a in range(1 << n) if pc(a) == 2]
def scalar_square_bivectors(p, q, r=0, trials=3000, seed=2):
    A = Alg(sig(p, q, r)); n = p + q + r; bv = bivectors(n); rng = random.Random(seed); bad = 0
    for _ in range(trials):
        B = {a: rng.randint(-3, 3) for a in bv}; B = {k: v for k, v in B.items() if v}
        if not B: continue
        BB = A.mul(B, B)
        if any(k != 0 for k in BB): bad += 1
    return bad
for cell in [(3, 0), (2, 1), (1, 2), (0, 3), (2, 0, 1)]:
    assert scalar_square_bivectors(*cell) == 0
print('   n = 3 (and the 3-dim PGA cell Cl(2,0,1)): the square of EVERY bivector is a scalar (3000 random integer bivectors each): the three-way sorting is exhaustive.')
# the two readings of 'squares 0': module reading exp(tB) x0 = x0 + tB x0 (exact), sandwich reading on VECTORS: a null rotation, orbit quadratic in t
A21 = Alg(sig(2, 1)); B21 = {3: 1, 5: 1}                              # e12 + e13 in Cl(2,1): e12^2 = -1, e13^2 = +1
assert A21.mul(B21, B21) == {} or all(v == 0 for v in A21.mul(B21, B21).values())
def ad21(v): return A21.add(A21.mul(B21, v), A21.mul(v, B21), -1)    # [B, v]
v0 = {2: 1, 4: -1}                                                    # e2 - e3
a1 = ad21(v0); a2 = ad21(a1); a3 = ad21(a2)
assert any(abs(c) > 0 for c in a1.values()) and any(abs(c) > 0 for c in a2.values()) and all(abs(c) == 0 for c in a3.values())
print('   n = 3, Cl(2,1): B = e12 + e13 has B^2 = 0 (null, non-degenerate cell), but the SANDWICH action on vectors has ad_B^2 != 0, ad_B^3 = 0:')
print('   the orbit of e2 - e3 is quadratic in t (a null rotation, not a straight-line translation). exp(tB) = 1 + tB is exact on the algebra (module reading); on vectors the 0 class is a null rotation, and it is a translation only in the conformal / PGA picture.')
for cell in [(4, 0), (3, 1), (2, 2), (1, 3), (0, 4), (3, 0, 1)]:
    A = Alg(sig(*cell)); B = {3: 1, 12: 1}; BB = A.mul(B, B)
    print(f'   n = 4, Cl{cell}:  (e12 + e34)^2 =', {k: v for k, v in sorted(BB.items())}, ' -> non-scalar part' if any(k for k in BB) else '')
    assert scalar_square_bivectors(*cell, trials=300) > 0
print('   from n = 4 on, in EVERY signature, B^2 = (scalar) + (4-vector): two numbers, so a bivector has two invariants and the single label -1/+1/0 is no longer enough.')

head('11. invariant decomposition (Roelfs - De Keninck): B = b1 + b2, commuting simple bivectors, b_i^2 = lambda_i, lambda roots of  l^2 - (B.B) l + (1/4)(B^w B)^2 = 0')
def expm_c(Mx, terms=80):
    nrm = max(1, np.abs(Mx).sum(axis=0).max()); s = int(math.ceil(math.log2(nrm))) + 1
    Y = Mx / (2 ** s); S = np.eye(len(Mx), dtype=complex); T = np.eye(len(Mx), dtype=complex)
    for k in range(1, terms): T = T @ Y / k; S = S + T
    for _ in range(s): S = S @ S
    return S
def to_vec(A, x): v = np.zeros(A.N, dtype=complex); [v.__setitem__(k, c) for k, c in x.items()]; return v
def regular_np(A, x):
    Mx = np.zeros((A.N, A.N), dtype=complex)
    for a, ca in x.items():
        for b in range(A.N):
            s, c = A.blade_mul(a, b)
            if s: Mx[c, b] += s * ca
    return Mx
def clean(x, tol=1e-9): return {k: v for k, v in x.items() if abs(v) > tol}
stats = {}
for cell in [(4, 0), (3, 1), (2, 2), (1, 3), (0, 4), (3, 0, 1)]:
    A = Alg(sig(*cell)); rng = random.Random(5); tested = 0; cplx = 0; real = 0; skipped = 0
    for _ in range(80):
        B = clean({a: rng.randint(-3, 3) for a in bivectors(4)})
        if not B: continue
        BB = A.mul(B, B); S = BB.get(0, 0); P4 = BB.get(15, 0); assert set(BB) <= {0, 15}
        e15sq = A.sq(15); Pn2 = P4 * P4 * e15sq                  # P^2 (a scalar)
        disc = (S * S - 4 * (Pn2 / 4) * 1)                       # S^2 - 4 * (1/4) P^2 = (B.B)^2 - (B^w B)^2
        lam1 = (S + cmath.sqrt(S * S - Pn2)) / 2; lam2 = (S - cmath.sqrt(S * S - Pn2)) / 2
        den = S * S - Pn2
        if abs(den) < 1e-9 or abs(lam1 - lam2) < 1e-9: skipped += 1; continue
        P = {15: P4} if P4 else {}
        Binv = A.mul(B, A.add({0: S}, P, -1)); Binv = A.scal(Binv, 1 / den)
        assert clean(A.add(A.mul(B, Binv), {0: 1}, -1)) == {}
        b1 = A.mul(A.add({0: lam1}, P, 0.5), Binv); b1 = clean(b1); b2 = clean(A.add(B, b1, -1))
        assert set(k for k in b1) <= set(bivectors(4)) and set(k for k in b2) <= set(bivectors(4)), (cell, b1)
        assert clean(A.add(A.mul(b1, b2), A.mul(b2, b1), -1)) == {}
        s1 = clean(A.mul(b1, b1)); s2 = clean(A.mul(b2, b2))
        assert set(s1) <= {0} and set(s2) <= {0} and abs(s1.get(0, 0) - lam1) < 1e-8 and abs(s2.get(0, 0) - lam2) < 1e-8
        # e^B = e^{b1} e^{b2}, with e^b = cosh(sqrt(l)) + b sinh(sqrt(l))/sqrt(l)
        def ex(b, lam):
            z = cmath.sqrt(lam); c = cmath.cosh(z); sc = cmath.sinh(z) / z if abs(z) > 1e-12 else 1
            return A.add({0: c}, b, sc)
        lhs = expm_c(regular_np(A, B)); rhs = regular_np(A, A.mul(ex(b1, lam1), ex(b2, lam2)))
        assert np.allclose(lhs, rhs, atol=1e-7), cell
        tested += 1
        if abs(lam1.imag) > 1e-9: cplx += 1
        else: real += 1
    stats[cell] = (tested, real, cplx, skipped)
    print(f'   Cl{cell}: {tested:3d} random bivectors decomposed, e^B = e^b1 e^b2 verified;  real lambda: {real:3d}   complex lambda: {cplx:3d}   (skipped, lambda1 = lambda2 or B not invertible: {skipped})')
assert stats[(2, 2)][2] > 0 and stats[(4, 0)][2] == 0 and stats[(3, 1)][2] == 0 and stats[(0, 4)][2] == 0 and stats[(1, 3)][2] == 0 and stats[(3, 0, 1)][2] == 0
print('   complex lambda (loxodromic, the Riesz "counter-example") occurs in Cl(2,2) = M_4(R) ONLY (in n = 4): there the pair b1, b2 are complex-conjugate bivectors, not real ones.')
print('   So in the cell that the project\'s Genesis ladder uses at n = 4 (two Witt pairs, Cl(2,2)) a real bivector can have complex roots: the complex numbers re-enter as the SPLITTING FIELD of a real bivector\'s characteristic polynomial.')

# ------------------------------------------------------------------------------------------------ summary
head('FINDINGS (all by the checks above)')
for line in [
 'F1  C is real: C = Cl(0,1) = Cl0(2,0) (the rotation algebra of the plane, built from two POSITIVE directions); nothing non-real is used.',
 'F2  H = Cl(0,2) = Cl0(3,0); the whole negative family Cl(0,m) = Cl0(m+1,0): negative cells are the rotor algebras of the positive ones.',
 'F3  every Cl(p,q) embeds, graded, in Cl(n+2,0): a negative generator is (positive vector) x (rotation bivector of two extra positive directions). "Only Cl(p)" is a consistent foundation.',
 'F4  but the roots of -1 cannot be dropped: Cl(n,0) already contains C(n,2) rotation bivectors, and its centre is C for n = 3, 7 (mod 8).  They are consequences, not postulates.',
 'F5  -1, +1, 0 are the three sign classes of ONE real number: for a generator X of a flow, X^2 = c.  Inside Cl(2,0) = M_2(R) they are the timelike / spacelike / lightlike vectors of the 3-dim traceless part (signature (2,1)); the spring constant is minus the norm.',
 'F6  the label 0 is NOT a +-1 value of the bit rule (a twisted group algebra has unit coefficients; with a 0 the formula stays associative but the blades form a monoid, not a group): nilpotents are born at n = 2 as e_a + e_b; a null GENERATOR is a contraction (non-semisimple, Cl(p,q) (x) Lambda).',
 'F7  ungraded algebra: 5 Morita types, determined by the F_2 quadratic form Q(a) = [e_a^2 = -1] (Arf at even n, radical at odd n). graded algebra: 8 classes = (type of A, type of A0) = p - q mod 8.  The Z_8 clock is the GRADING.',
 'F8  the sorting -1/+1/0 is exhaustive for n <= 3 (every bivector squares to a scalar) and for SIMPLE blades in every n; from n = 4 a bivector has two invariants, and at n = 4 its roots are complex only in Cl(2,2).',
]: print('  ' + line)
print('\nALL LABELS CHECKS PASS')
