#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""A small deterministic Schreier-Sims for permutation groups (pure Python), because no GAP/sympy is installed here.
Permutations are tuples p with p[i] = image of point i; mul(p, q) means 'first p, then q'.
  BSGS(gens, deg)  -> .order(), .contains(g), .random_element(), .base, .orbits
  derived_order(G) -> order of the derived subgroup (normal closure of the generators' commutators)
  normal_closure_order(G, elements) -> order of the normal closure in G of the given elements"""
import random

def ident(deg): return tuple(range(deg))
def mul(p, q): return tuple(q[x] for x in p)
def inv(p):
    r = [0] * len(p)
    for i, x in enumerate(p): r[x] = i
    return tuple(r)
def comm(p, q): return mul(mul(inv(p), inv(q)), mul(p, q))        # p^-1 q^-1 p q
def conj(g, h): return mul(mul(inv(h), g), h)                       # h^-1 g h

class BSGS:
    def __init__(self, gens, deg):
        self.deg = deg; self.id = ident(deg)
        self.base = []; self.strong = []; self.orb = []; self.orbinv = []
        for g in gens:
            r, j = self.sift(g)
            if r != self.id: self._add(r, j)
        self._complete()
    # ------------------------------------------------------------------
    def _level_gens(self, i):
        b = self.base[:i]
        return [g for g in self.strong if all(g[x] == x for x in b)]
    def _orbit(self, i):
        pt = self.base[i]; gs = self._level_gens(i)
        orb = {pt: self.id}; q = [pt]
        for x in q:
            for g in gs:
                y = g[x]
                if y not in orb:
                    orb[y] = mul(orb[x], g); q.append(y)
        self.orb[i] = orb; self.orbinv[i] = {y: inv(u) for y, u in orb.items()}
    def sift(self, g, start=0):
        for i in range(start, len(self.base)):
            y = g[self.base[i]]
            if y not in self.orb[i]: return g, i
            g = mul(g, self.orbinv[i][y])
        return g, len(self.base)
    def _add(self, r, j):
        self.strong.append(r)
        if j == len(self.base):
            pt = next(x for x in range(self.deg) if r[x] != x)
            self.base.append(pt); self.orb.append(None); self.orbinv.append(None)
        for i in range(j + 1): self._orbit(i)
    def _complete(self):
        i = len(self.base) - 1
        while i >= 0:
            bad = False
            gs = self._level_gens(i)
            for y, u in list(self.orb[i].items()):
                for s in gs:
                    h = mul(mul(u, s), self.orbinv[i][s[y]])
                    r, j = self.sift(h, i + 1)
                    if r != self.id:
                        self._add(r, j); i = j; bad = True; break
                if bad: break
            if not bad: i -= 1
    # ------------------------------------------------------------------
    def order(self):
        o = 1
        for orb in self.orb: o *= len(orb)
        return o
    def contains(self, g):
        return self.sift(g)[0] == self.id
    def random_element(self, rng=random):
        g = self.id
        for i in range(len(self.base)):
            y = rng.choice(list(self.orb[i].keys()))
            g = mul(self.orb[i][y], g) if False else mul(g, self.orb[i][y])
        return g

def closure_order(gens, deg): return BSGS(gens, deg).order() if gens else 1

def normal_closure_gens(G, elts):
    """generators of the normal closure of `elts` in the group G (a BSGS): add conjugates until stable"""
    gens = [e for e in elts if e != G.id]
    if not gens: return []
    H = BSGS(gens, G.deg)
    changed = True
    while changed:
        changed = False
        for h in list(G.strong):
            for e in list(gens):
                c = conj(e, h)
                if not H.contains(c):
                    gens.append(c); H = BSGS(gens, G.deg); changed = True
    return gens

def normal_closure_order(G, elts):
    gens = normal_closure_gens(G, elts)
    return BSGS(gens, G.deg).order() if gens else 1

def derived_order(G, gens):
    """order of [G,G]: normal closure in G of the commutators of the generating set"""
    cs = [comm(a, b) for i, a in enumerate(gens) for b in gens[i + 1:]]
    return normal_closure_order(G, cs)

def element_order(g):
    o = 1; x = g; idt = ident(len(g))
    while x != idt:
        x = mul(x, g); o += 1
    return o

if __name__ == '__main__':
    import itertools, math
    def sym(n):
        a = tuple([1, 0] + list(range(2, n))); b = tuple(list(range(1, n)) + [0]); return [a, b]
    for n in range(2, 8):
        assert BSGS(sym(n), n).order() == math.factorial(n)
    S5 = BSGS(sym(5), 5)
    A5gens = [(1, 2, 0, 3, 4), (0, 1, 3, 4, 2)]
    A5 = BSGS(A5gens, 5); assert A5.order() == 60
    assert derived_order(A5, A5gens) == 60 and derived_order(S5, sym(5)) == 60
    assert normal_closure_order(A5, [(1, 0, 3, 2, 4)]) == 60                     # A5 is simple: the closure of a double transposition is A5
    # Rubik's cube corner group (7! * 3^6 * 8!/?): use M12 as a test: order 95040 acting on 12 points
    m12a = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 11)                                  # 11-cycle
    m12b = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)
    print('permgroup self-test OK')
