#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Task 2 script: finite groups seen through the cascade.  Pure Python (+numpy for one Leech check).  Exact.
   python3 groups_check.py [A B C D E F]      (default: all parts)
 A  address form Q(a)=[e_a^2=-1], O(Q) for every Z8 class, n<=8, against brute force and closed formulas; clock = Gauss-sum phase (A5)
 B  Weyl groups W(E_n), n=3..8, reduced mod 2, against O(Q_{Cl(n,0)});  roots <-> blades with square -1
 C  simplex lens: Pin lifts of S_m (binary tetrahedral / icosahedral)
 D  Golay code from the n=3 cube (Turyn), M24, the n=24 form, Leech minimal vectors, Monster 2-part
 E  primes: where each prime first enters the cascade (n = ord_p(2)) and the table of first appearances
 F  Klein correspondence: the n=4 bivector invariant B^B is the Pfaffian; over F_2 it turns GL(4,2) into Omega+_6(2) (A8)
Everything printed is computed here unless it is marked STANDARD (an input quoted from the literature)."""
import sys, os, math, itertools, random, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bitcliff import Alg, sig, pc, TYPES
from permgroup import BSGS, mul, inv, ident, comm, derived_order, normal_closure_order, element_order

T0 = time.time()
def stamp(): return '[%5.1fs]' % (time.time() - T0)
FAILS = []
def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond: FAILS.append(msg)
def head(s): print('\n' + '=' * 78 + '\n' + s + '\n' + '=' * 78)

# ---------------------------------------------------------------- forms on F_2^n
def Qtab_cell(p, q):
    """Q(a) = 1 iff the blade e_a squares to -1 in Cl(p,q), computed with the bit-rule engine (not from a formula)"""
    A = Alg(sig(p, q))
    return [1 if A.sq(a) == -1 else 0 for a in range(A.N)]
def Qtab_Cln0(n):                      # closed form for Cl(n,0): (-1)^{k(k-1)/2}
    return [(pc(a) * (pc(a) - 1) // 2) & 1 for a in range(1 << n)]
def Bof(Q): return lambda a, b: Q[a ^ b] ^ Q[a] ^ Q[b]
def invariants(Q, n):
    """complete invariant of a quadratic form over F_2 (classification theorem): (n, dim rad, Q|rad != 0, #singular)"""
    N = 1 << n; B = Bof(Q)
    rad = [a for a in range(N) if all(B(a, 1 << i) == 0 for i in range(n))]
    return (n, len(rad).bit_length() - 1, int(any(Q[a] for a in rad)), sum(1 for a in range(N) if Q[a] == 0))
def zclass(inv_):
    n, rd, qr, sing = inv_
    if n % 2 == 0:
        assert rd == 0
        h = 2 ** (n // 2 - 1) if n >= 2 else 0.5
        if n == 0: return 'R'
        return 'R' if sing == 2 ** (n - 1) + h else 'H' if sing == 2 ** (n - 1) - h else '??'
    assert rd == 1
    if qr: return 'C'
    h = 2 ** ((n - 1) // 2)
    return 'R2' if sing == 2 ** (n - 1) + h else 'H2' if sing == 2 ** (n - 1) - h else '??'

def sp_order(m): return 2 ** (m * m) * math.prod(4 ** i - 1 for i in range(1, m + 1))
def o_order(m, eps): return 2 * 2 ** (m * (m - 1)) * (2 ** m - eps) * math.prod(4 ** i - 1 for i in range(1, m))
def oq_formula(n, cls):
    """|O(V,Q)| for the five classes (closed formulas; STANDARD)"""
    if n == 0: return 1
    if cls in ('R', 'H'): return o_order(n // 2, 1 if cls == 'R' else -1)
    if cls == 'C': return sp_order((n - 1) // 2)
    return 2 ** (n - 1) * o_order((n - 1) // 2, 1 if cls == 'R2' else -1) if n > 1 else 1

def count_isometries(Q, n):
    """|O(Q)| by exhaustive depth-first search over images of the basis (n <= 6)"""
    N = 1 << n; B = Bof(Q)
    Bt = [[B(a, b) for b in range(N)] for a in range(N)]
    cand = [[v for v in range(1, N) if Q[v] == Q[1 << i]] for i in range(n)]
    imgs = []; cnt = [0]
    def rec(i, span):
        if i == n: cnt[0] += 1; return
        for v in cand[i]:
            if v in span: continue
            if all(Bt[v][imgs[j]] == Bt[1 << i][1 << j] for j in range(i)):
                imgs.append(v); rec(i + 1, span | {s ^ v for s in span}); imgs.pop()
    rec(0, {0})
    return cnt[0]

def find_isometry(Q1, Q2, n, maxnodes=2_000_000):
    """a linear isometry (V,Q1)->(V,Q2) as the list of images of the basis vectors, or None; second value: search was exhaustive"""
    N = 1 << n; B2 = Bof(Q2); B1 = Bof(Q1)
    cand = [[v for v in range(1, N) if Q2[v] == Q1[1 << i]] for i in range(n)]
    imgs = []; nodes = [0]
    def rec(i, span):
        if i == n: return True
        for v in cand[i]:
            nodes[0] += 1
            if nodes[0] > maxnodes: return None
            if v in span: continue
            if all(B2(v, imgs[j]) == B1(1 << i, 1 << j) for j in range(i)):
                imgs.append(v)
                r = rec(i + 1, span | {s ^ v for s in span})
                if r is True: return True
                if r is None: return None
                imgs.pop()
        return False
    r = rec(0, {0})
    if r is True: return list(imgs), True
    return None, (r is False)
def apply_lin(imgs, x):
    y = 0
    for i, v in enumerate(imgs):
        if (x >> i) & 1: y ^= v
    return y
def is_isometry(imgs, Q1, Q2, n):
    return all(Q2[apply_lin(imgs, x)] == Q1[x] for x in range(1 << n)) and len({apply_lin(imgs, x) for x in range(1 << n)}) == 1 << n

def isometry_group(Q, n, quiet=True):
    """BSGS of O(Q), acting on the nonsingular vectors (all vectors if they do not span); generators: transvections
       t_v(x)=x+B(x,v)v (v nonsingular) and, for a singular radical, the radical translations x -> x+f(x)r"""
    N = 1 << n; B = Bof(Q)
    ns = [v for v in range(1, N) if Q[v]]
    span = {0}
    for v in ns: span |= {s ^ v for s in span}
    pts = ns if len(span) == N else list(range(1, N))
    idx = {v: i for i, v in enumerate(pts)}
    gens = []
    for v in ns:
        gens.append(tuple(idx[x ^ v] if B(x, v) else idx[x] for x in pts))
    rad = [a for a in range(1, N) if all(B(a, 1 << i) == 0 for i in range(n))]
    for r in rad:
        if Q[r] == 0:                                   # singular radical vector r: translations by f(x) r with f(r)=0
            for j in range(1, n):
                gens.append(tuple(idx[x ^ r] if (((x >> j) ^ x) & 1) else idx[x] for x in pts))   # f = x_j + x_0 (f(r)=0 for r = all ones)
    return reduce_gens(gens, len(pts), seed=7)

def reduce_gens(gens, deg, seed=7):
    """greedy small generating subset; returns (BSGS, chosen, deg)"""
    gens = list(gens); rnd = random.Random(seed); rnd.shuffle(gens)
    chosen = []; H = None
    for g in gens:
        if H is None or not H.contains(g):
            chosen.append(g); H = BSGS(chosen, deg)
    if H is None: H = BSGS([], deg)
    return H, chosen, deg

KNOWN_SIMPLE = {60: 'A5=L2(4)=L2(5)', 168: 'L3(2)=L2(7)', 360: 'A6', 504: 'L2(8)', 2520: 'A7', 20160: 'A8=L4(2)',
                25920: 'U4(2)=S4(3)', 1451520: 'S6(2)', 174182400: 'O8+(2)', 197406720: 'O8-(2)', 6048: 'U3(3)', 5616: 'L3(3)',
                244823040: 'M24', 7920: 'M11', 95040: 'M12', 443520: 'M22', 10200960: 'L5(2)', 20158709760: 'L6(2)'}
def derived_chain(H, gens, maxlen=4, budget=None):
    """orders of G > G' > G'' ... (stops at perfect or trivial)"""
    out = [H.order()]; cur_gens = gens; cur = H
    for _ in range(maxlen):
        # derived subgroup = normal closure (in the CURRENT group) of commutators of its generators
        cs = [comm(a, b) for i, a in enumerate(cur_gens) for b in cur_gens[i + 1:]]
        from permgroup import normal_closure_gens
        ng = normal_closure_gens(cur, cs)
        if not ng: out.append(1); break
        nxt, ng2, _ = reduce_gens(ng, cur.deg); out.append(nxt.order())
        if out[-1] == out[-2]: break
        cur, cur_gens = nxt, ng2
    return out

# expected outcome of A3 (the order of the perfect core is COMPUTED; the names are the STANDARD identification by order)
EXPECT_CORE = {(4, 'H'): 60, (5, 'C'): 360, (5, 'H2'): 960, (6, 'H'): 25920, (6, 'R'): 20160, (7, 'C'): 1451520, (7, 'H2'): 1658880, (7, 'R2'): 1290240}
EXPECT_NAME = {(4, 'H'): 'A5=L2(4)=L2(5)', (5, 'C'): 'A6', (5, 'H2'): '2^4 : A5=L2(4)=L2(5)', (6, 'H'): 'U4(2)=S4(3)', (6, 'R'): 'A8=L4(2)',
               (7, 'C'): 'S6(2)', (7, 'H2'): '2^6 : U4(2)=S4(3)', (7, 'R2'): '2^6 : A8=L4(2)'}
EXPECT_SOLV = {(1, 'C'), (1, 'R2'), (2, 'H'), (2, 'R'), (3, 'C'), (3, 'H2'), (3, 'R2'), (4, 'R'), (5, 'R2')}

# ================================================================== A
def part_A():
    head('A.  Address form Q(a)=[e_a^2=-1] on F_2^n,  O(Q),  against the Z8 clock')
    # A1: Q is a quadratic form whose polar form is the commutation bit; and the classification matches the textbook table
    print('A1  Q is quadratic with polar form = commutation bit; class (R,R2,C,H,H2) from the F_2-invariants vs the textbook mod-8 table')
    bad = 0; nc = 0
    for n in range(0, 11):
        for p in range(n + 1):
            q = n - p
            Q = Qtab_cell(p, q)
            if n <= 7:
                for a in range(1 << n):
                    for b in range(1 << n):
                        if Q[a ^ b] ^ Q[a] ^ Q[b] != ((pc(a) * pc(b) - pc(a & b)) & 1): bad += 1
            cls = zclass(invariants(Q, n)); nc += 1
            if cls != TYPES[(p - q) % 8]: bad += 1; print('   mismatch', p, q, cls, TYPES[(p - q) % 8])
    check(bad == 0, 'all %d cells n<=10: quadratic form property (n<=7) and F_2-class == mod-8 table' % nc)
    # A2: the five classes, the number of presentations (p,q) of each, and the group O(Q)
    print('\nA2  |O(Q)|: brute force (n<=6), transvection group (SS), closed formula  [class from representative cell]')
    print('   n  cell  class  Wedderburn      |O(Q)| brute   |SS group|    formula       index   composition (by order)')
    reps = {}
    for n in range(1, 9):
        for p in range(n + 1):
            cls = zclass(invariants(Qtab_cell(p, n - p), n))
            reps.setdefault((n, cls), (p, n - p))
    rows = []
    for (n, cls), (p, q) in sorted(reps.items()):
        Q = Qtab_cell(p, q)
        brute = count_isometries(Q, n) if n <= 6 else None
        H, ch, deg = isometry_group(Q, n)
        form = oq_formula(n, cls)
        ssn = H.order()
        wed = {'R': 'M_k(R)', 'R2': 'M_k(R)+M_k(R)', 'C': 'M_k(C)', 'H': 'M_k(H)', 'H2': 'M_k(H)+M_k(H)'}[cls]
        idx = form // ssn if ssn else 0
        print('  %2d (%d,%d) %-3s    %-14s %-14s %-13d %-13d %s   [%.0fs]' % (n, p, q, cls, wed, ('%d' % brute) if brute is not None else '-', ssn, form,
              ('1' if idx == 1 else 'index %d' % idx), time.time() - T0))
        ok = (ssn == form) if n != 4 or cls != 'R' else (ssn * 2 == form or ssn == form)
        if brute is not None: check(brute == form, 'n=%d %s: brute force |O(Q)| == closed formula (%d)' % (n, cls, form))
        exc = (cls == 'R' and n == 4) or (cls == 'R2' and n == 5)      # O4+(2) (alone, or as the quotient of the split n=5 cell) is not generated by transvections
        check(ssn == form or (exc and form == 2 * ssn), 'n=%d %s: transvection(+translation) group order == formula%s' % (n, cls, '' if ssn == form else ' (index %d: the known exception O4+(2) is not generated by transvections)' % idx))
        rows.append((n, cls, (p, q), form, ssn, H, ch))
    # A3: derived subgroups (simple core), identified by order (STANDARD list)
    print('\nA3  derived chain of O(Q) (computed by Schreier-Sims normal closures, n<=7) and the simple core identified by order')
    for (n, cls, cell, form, ssn, H, ch) in rows:
        if n > 7: continue
        chain = derived_chain(H, ch)
        core = chain[-1]
        if cls in ('R2', 'H2') and core > 1 and core % 2 ** (n - 1) == 0:
            lab = '2^%d : %s' % (n - 1, KNOWN_SIMPLE.get(core // 2 ** (n - 1), '|%d|' % (core // 2 ** (n - 1))))
        else:
            lab = KNOWN_SIMPLE.get(core, 'solvable' if core == 1 else '|core|=%d' % core)
        note = '' if ssn == form else '   (chain of the subgroup generated by transvections and radical translations, index %d in O(Q); the full O(Q) has order %d)' % (form // ssn, form)
        print('  n=%d %-3s cell%s |O|=%d  chain %s  perfect core: %s%s' % (n, cls, cell, form, chain, lab, note))
        key_ = (n, cls)
        if key_ in EXPECT_CORE:
            check(core == EXPECT_CORE[key_] and lab == EXPECT_NAME[key_], 'n=%d %s: perfect core has order %d and is %s' % (n, cls, EXPECT_CORE[key_], EXPECT_NAME[key_]))
        else:
            check(core == 1 and key_ in EXPECT_SOLV, 'n=%d %s: derived series reaches 1 (solvable)' % (n, cls))
    # A4: radical / pseudoscalar facts used in the text
    print('\nA4  blade groups G_{p,q}={+-e_a}: centre and type, from the commutation structure')
    for cls, (p, q) in [('R', (2, 0)), ('H', (0, 2)), ('C', (3, 0)), ('R2', (1, 0)), ('H2', (0, 3)), ('R', (8, 0)), ('H', (4, 0)), ('C', (7, 0))]:
        n = p + q; Q = Qtab_cell(p, q); B = Bof(Q)
        rad = [a for a in range(1 << n) if all(B(a, 1 << i) == 0 for i in range(n))]
        cen = 2 * len(rad)
        print('  Cl(%d,%d) class %-3s: |G|=%d, centre of G has order %d%s' % (p, q, cls, 2 ** (n + 1), cen,
              '  (Z2: extraspecial 2^{1+%d}%s)' % (n, '+' if cls == 'R' else '-') if cen == 2 else
              ('  (Z4 = {+-1,+-w}, w^2=-1: 4o2^{1+%d})' % (n - 1) if cls == 'C' else '  (Z2xZ2: w^2=+1)')))
    # A5: the clock is the phase of the Gauss sum  sum_a i^(pos(a)-neg(a)) = (1+i)^p (1-i)^q = 2^(n/2) exp(i pi (p-q)/4)
    print('\nA5  the Z8 clock as the phase of the Gauss sum over the blade addresses (exact in Z[i]; every cell n<=8, plus n=9..12)')
    import cmath
    badg = 0; ncell = 0
    for n in range(0, 13):
        for p in range(n + 1):
            q = n - p; ncell += 1
            re = im = 0; ip = [(1, 0), (0, 1), (-1, 0), (0, -1)]
            for a in range(1 << n):
                k = (pc(a & ((1 << p) - 1)) - pc(a >> p)) % 4
                re += ip[k][0]; im += ip[k][1]
            gr, gi = 1, 0                                    # (1+i)^p (1-i)^q in Z[i]
            for _ in range(p): gr, gi = gr - gi, gr + gi
            for _ in range(q): gr, gi = gr + gi, gi - gr
            z = complex(re, im); target = 2 ** (n / 2) * cmath.exp(1j * math.pi * (p - q) / 4)
            if (re, im) != (gr, gi) or abs(z - target) > 1e-6 * max(1.0, abs(target)): badg += 1
    check(badg == 0, 'Gauss sum sum_a i^(pos(a)-neg(a)) = (1+i)^p(1-i)^q = 2^(n/2) e^(i pi (p-q)/4): %d cells n<=12, phase = the clock c=p-q mod 8' % ncell)
    return rows

# ================================================================== B
def En_adj(n):
    """Gosset series T_{2,3,n-3}: E3=A2+A1, E4=A4, E5=D5, E6, E7, E8 (n>=9: affine E8, E10, ...)"""
    adj = [0] * n
    def edge(i, j): adj[i] |= 1 << j; adj[j] |= 1 << i
    if n == 3: edge(0, 1)
    else:
        edge(0, 1); edge(0, 2); edge(2, 3)
        prev = 0
        for k in range(4, n): edge(prev, k); prev = k
    return adj
def An_adj(n):
    adj = [0] * n
    for i in range(n - 1): adj[i] |= 1 << (i + 1); adj[i + 1] |= 1 << i
    return adj
def Q_from_adj(adj, n):
    """q(x)=x.x/2 mod 2 of the root lattice with Dynkin adjacency adj, x in root-basis coordinates: sum x_i + sum_edges x_i x_j"""
    out = []
    for x in range(1 << n):
        v = pc(x)
        for i in range(n):
            if (x >> i) & 1: v += pc(x & adj[i] & ~((1 << (i + 1)) - 1))
        out.append(v & 1)
    return out
def roots_and_weyl(adj, n):
    C = [[2 if i == j else (-1 if (adj[i] >> j) & 1 else 0) for j in range(n)] for i in range(n)]
    simple = [tuple(1 if k == i else 0 for k in range(n)) for i in range(n)]
    def refl(i, x):
        c = sum(x[j] * C[j][i] for j in range(n))
        return tuple(x[k] - (c if k == i else 0) for k in range(n))
    roots = set(simple); frontier = list(simple)
    while frontier:
        nxt = []
        for r in frontier:
            for i in range(n):
                s = refl(i, r)
                if s not in roots: roots.add(s); nxt.append(s)
        frontier = nxt
    rl = sorted(roots); ri = {r: i for i, r in enumerate(rl)}
    gens = [tuple(ri[refl(i, r)] for r in rl) for i in range(n)]
    return C, rl, gens

def part_B():
    head('B.  W(E_n) reduced mod 2, against O(Q) of the bit-rule address form of Cl(n,0)')
    print('   n  type  #roots  |W| (SS, integral)   image mod 2   kernel   |O(Q_Cl(n,0))|   root classes / q=1 vectors   N-(Cl(n,0))  isometry?')
    names = {3: 'A2+A1', 4: 'A4', 5: 'D5', 6: 'E6', 7: 'E7', 8: 'E8'}
    known_W = {3: 12, 4: 120, 5: 1920, 6: 51840, 7: 2903040, 8: 696729600}
    KERNEL = {3: 2, 4: 1, 5: 1, 6: 1, 7: 2, 8: 2}      # n=3: the reflection of the A1 summand; n=7,8: {+-1}
    for n in range(3, 9):
        adj = En_adj(n)
        C, rl, wg = roots_and_weyl(adj, n)
        W = BSGS(wg, len(rl))
        qE = Q_from_adj(adj, n); QC = Qtab_Cln0(n)
        # mod-2 action of the simple reflections on F_2^n: the transvections t_i(x)=x+B(x,a_i)a_i
        N = 1 << n
        def t(i):
            return tuple((x ^ (1 << i)) if (pc(x & adj[i]) & 1) else x for x in range(N))
        Wm = BSGS([t(i) for i in range(n)], N)
        # roots mod 2
        cls = {sum((r[k] & 1) << k for k in range(n)) for r in rl}
        ns = {x for x in range(1, N) if qE[x]}
        isq = all(qE[c] == 1 for c in cls)
        # explicit isometry (V,qE) -> (V,Q_Cl(n,0))
        imgs, exh = find_isometry(qE, QC, n)
        okiso = imgs is not None and is_isometry(imgs, qE, QC, n)
        nm = QC.count(1)
        rad_extra = len(ns) - len(cls)
        print('  %2d %-6s %4d   %-18d  %-12d %-7d  %-14d  %d / %d (+%d radical)    %-5d       %s' % (
            n, names[n], len(rl), W.order(), Wm.order(), W.order() // Wm.order(), oq_formula(n, zclass(invariants(QC, n))), len(cls), len(ns), rad_extra, nm,
            'yes' if okiso else 'NO'))
        check(W.order() == known_W[n], 'n=%d |W(%s)| = %d' % (n, names[n], known_W[n]))
        check(W.order() % Wm.order() == 0 and W.order() // Wm.order() == KERNEL[n], 'n=%d kernel of W(%s) -> GL(n,2) has order %d' % (n, names[n], KERNEL[n]))
        check(isq, 'n=%d every root reduces to a nonsingular vector' % n)
        check(len(rl) // 2 + (1 if n == 7 else 0) == nm, 'n=%d  (#positive roots) (+1 pseudoscalar at n=7) == #blades of Cl(n,0) with square -1 (=%d)' % (n, nm))
        check(okiso, 'n=%d explicit isometry E_n/2E_n -> address form of Cl(n,0) found and verified on all 2^n vectors' % n)
        check(invariants(qE, n) == invariants(QC, n), 'n=%d complete invariants equal' % n)
        check(Wm.order() == oq_formula(n, zclass(invariants(QC, n))), 'n=%d image of W(E_n) in GL(n,2) has exactly the order of O(Q) of class %s (%d)' % (n, zclass(invariants(QC, n)), Wm.order()))
        if n == 8 and imgs:
            print('     E8 simple roots as blades of Cl(8,0) with square -1 (image of each simple root):')
            for i in range(n):
                a = imgs[i]
                print('       alpha_%d -> e_{%s}  (grade %d)' % (i + 1, ''.join(str(j + 1) for j in range(n) if (a >> j) & 1), pc(a)))
    # which cells (p,q) share the E_n form?  (A_n shown for contrast)
    print('\nB2  which cells Cl(p,q) have the same address form as E_n/2E_n (and as A_n/2A_n, for contrast)')
    for n in range(3, 17):
        cellsE = []; cellsA = []
        iE = invariants(Q_from_adj(En_adj(n), n), n); iA = invariants(Q_from_adj(An_adj(n), n), n)
        for p in range(n + 1):
            cls = TYPES[(p - (n - p)) % 8]      # the Z8 table equals the F_2 class (checked in A1 for n<=10)
            c0 = zclass(iE); cA = zclass(iA)
            if cls == c0: cellsE.append((p, n - p))
            if cls == cA: cellsA.append((p, n - p))
        QCn = Qtab_Cln0(n)
        same = invariants(QCn, n) == iE
        print('  n=%2d  E_n class %-3s  equals Cl(n,0) class: %-5s | cells with the E_n class: %s' % (n, zclass(iE), same, '(n,0)' if (n, 0) in cellsE else '(n,0) NOT among them'))
        if n <= 16: check(same, 'n=%d: E_n (Gosset/Kac-Moody series T_{2,3,n-3}) mod 2 has the form class of Cl(n,0)' % n)
    print('  A_n/2A_n has the class of Cl(n,0) exactly for n =', [n for n in range(2, 17) if invariants(Q_from_adj(An_adj(n), n), n) == invariants(Qtab_Cln0(n), n)])
    print('  Cl(0,n) (the negative family) has the E_n class exactly for n =', [n for n in range(3, 17) if invariants([((pc(a)*(pc(a)+1))//2) & 1 for a in range(1 << n)], n) == invariants(Q_from_adj(En_adj(n), n), n)])
    print('\nB3  the simplex lens: A_n/2A_n (path graph; W(A_n)=S_{n+1}) against the NEGATIVE family Cl(0,n)=Cl^0(n+1,0)')
    print('   n  class   S_{n+1} image in O(Q) (SS)   |O(Q)|     kernel of S_{n+1} -> GL(n,2)')
    for n in range(2, 17):
        QN = [((pc(a) * (pc(a) + 1)) // 2) & 1 for a in range(1 << n)]
        iA = invariants(Q_from_adj(An_adj(n), n), n)
        same = iA == invariants(QN, n)
        check(same, 'n=%d: A_n/2A_n has the address form class of Cl(0,n) (%s)' % (n, zclass(iA)))
        if n <= 8:
            adj = An_adj(n); N = 1 << n
            tt = [tuple((x ^ (1 << i)) if (pc(x & adj[i]) & 1) else x for x in range(N)) for i in range(n)]
            Wm = BSGS(tt, N); on = oq_formula(n, zclass(iA))
            print('  %2d  %-3s     %-26d %-11d %d' % (n, zclass(iA), Wm.order(), on, math.factorial(n + 1) // Wm.order()))
            check(Wm.order() <= on and on % Wm.order() == 0, 'n=%d: image of S_{n+1} lies in O(Q) (order divides)' % n)
            # the identity behind it: phi(x) = (+) over x_i of (e_i + e_{i+1}) maps F_2^n onto the even-weight vectors of F_2^{n+1};
            # it carries the address form of A_n/2A_n to the address form of Cl(0,n+1) restricted to the even-weight code, and the
            # transvection t_i to the swap of coordinates i, i+1.  So S_{n+1} acts by permuting the n+1 points.
            def phi(x):
                y = 0
                for i in range(n):
                    if (x >> i) & 1: y ^= (3 << i)
                return y
            QA = Q_from_adj(adj, n)
            Qn1 = [((pc(a) * (pc(a) + 1)) // 2) & 1 for a in range(1 << (n + 1))]
            even = {a for a in range(1 << (n + 1)) if pc(a) % 2 == 0}
            def swap(y, i):
                bi, bj = (y >> i) & 1, (y >> (i + 1)) & 1
                return (y & ~(3 << i)) | (bj << i) | (bi << (i + 1))
            img = {phi(x) for x in range(1 << n)}
            ok_bij = img == even and len(img) == 1 << n
            ok_q = all(QA[x] == Qn1[phi(x)] for x in range(1 << n))
            ok_sw = all(phi(tt[i][x]) == swap(phi(x), i) for i in range(n) for x in range(1 << n))
            check(ok_bij and ok_q and ok_sw, 'n=%d: A_n/2A_n = even-weight code of F_2^%d, form = Cl(0,%d) address form restricted to it, t_i = swap of points i,i+1 (S_%d permutes the points)' % (n, n + 1, n + 1, n + 1))
    print('  (E_n <-> positive family Cl(n,0) for all n<=16;  A_n <-> negative family Cl(0,n) for all n<=16: the two series are mirror images n -> -n on the Z8 clock)')

# ================================================================== C
def part_C():
    head('C.  Simplex lens: the Pin lift of S_m = W(A_{m-1}) inside Cl(m,0);  binary polyhedral groups')
    from fractions import Fraction
    for m in range(3, 8):
        A = Alg(sig(m, 0))
        def vec(i, j):  # e_i - e_j  (square 2)
            return {1 << i: Fraction(1), 1 << j: Fraction(-1)}
        def pairprod(a, b):
            return {k: v / 2 for k, v in A.mul(vec(*a), vec(*b)).items()}
        adj_pairs = [((i, i + 1), (i + 1, i + 2)) for i in range(m - 2)]
        gens = [pairprod(*p) for p in adj_pairs]
        one = {0: Fraction(1)}
        key = lambda x: tuple(sorted(x.items()))
        seen = {key(one): one}; frontier = [one]
        while frontier:
            nxt = []
            for x in frontier:
                for g in gens:
                    y = A.mul(x, g)
                    k = key(y)
                    if k not in seen: seen[k] = y; nxt.append(y)
            frontier = nxt
            if len(seen) > 6000: break
        order = len(seen)
        minus1 = key({0: Fraction(-1)}) in seen
        # even subgroup G+ of Pin: order m! ; quotient by +-1 = A_m of order m!/2
        # disjoint transposition lifts: (w12 w34 /2)^2 = -1
        ok = True
        if m >= 4:
            x = pairprod((0, 1), (2, 3)); ok = A.mul(x, x) == {0: Fraction(-1)}
        # centre of the group generated
        ks = list(seen.values())
        if order <= 720:
            cen = [x for x in ks if all(A.mul(x, g) == A.mul(g, x) for g in gens)]
        else: cen = None
        print('  m=%d (A_%d simplex, %d vertices): |G+| = %d (m! = %d), -1 in G+: %s, centre %s, (lifted disjoint transpositions)^2 = -1: %s' % (
            m, m - 1, m, order, math.factorial(m), minus1, ('order %d' % len(cen)) if cen is not None else '-', ok if m >= 4 else 'n/a'))
        if m == 3:
            check(order == 3 and not minus1, 'm=3 the chosen lift of A3 (one adjacent product) = Z3 splits (Schur multiplier of A3 is trivial): order 3, -1 not in it')
            # full preimage of A3 in Pin: all products +-(v_a v_b)/2 of two transposition lifts, both signs of each lift
            allg = []
            for a in itertools.combinations(range(3), 2):
                for b in itertools.combinations(range(3), 2):
                    if a != b:
                        pr = pairprod(a, b); allg.append(pr); allg.append({k: -v for k, v in pr.items()})
            seen3 = {key(one): one}; fr3 = [one]
            while fr3:
                nx3 = []
                for x in fr3:
                    for g in allg:
                        y = A.mul(x, g); k = key(y)
                        if k not in seen3: seen3[k] = y; nx3.append(y)
                fr3 = nx3
            check(len(seen3) == 6 and key({0: Fraction(-1)}) in seen3, 'm=3 the full preimage of A3 (all products of two transposition lifts, both signs) has order 6 and contains -1: Z6 = Z3 x Z2, a trivial (split) double cover')
        else:
            check(order == math.factorial(m), 'm=%d the even part of the Pin lift has order m! = 2*|A_m| (a non-split double cover of A_m)' % m)
            check(minus1, 'm=%d -1 lies in the lifted group, so it is a genuine double cover' % m)
        if m == 5:
            # perfect? commutator subgroup of G+ is all of G+  (=> G+ = SL(2,5), the binary icosahedral group)
            rev = lambda x: {k: (-v if (pc(k) * (pc(k) - 1) // 2) & 1 else v) for k, v in x.items()}
            comms = set()
            for g in ks:
                for h in ks[:40]:
                    c = A.mul(A.mul(g, h), A.mul(rev(g), rev(h)))
                    comms.add(key(c))
            cg = [dict(k) for k in comms]
            S = {key(one): one}; fr = [one]
            while fr:
                nx = []
                for x in fr:
                    for g in cg:
                        y = A.mul(x, g); k = key(y)
                        if k not in S: S[k] = y; nx.append(y)
                fr = nx
                if len(S) > 200: break
            check(len(S) == 120 and order == 120 and len(cen) == 2, 'm=5 G+ is perfect of order 120 with centre {+-1}: the binary icosahedral group 2.A5 = SL(2,5)')
        if m == 4:
            check(order == 24 and len(cen) == 2, 'm=4 G+ has order 24, centre {+-1}: the binary tetrahedral group 2.A4 = SL(2,3)')
    # the odd part: the lift of a transposition is the unit vector (e_i - e_j)/sqrt2, whose square is the sign of the cell.
    # Cl(m,0) -> t^2 = +1 and (t t')^2 = -1 for disjoint t, t'  (one of Schur's two double covers of S_m: s^2 = 1, (s s')^2 = z);  Cl(0,m) -> t^2 = -1, (t t')^2 = -1  (the other: s^2 = z)
    for (p, q) in [(5, 0), (0, 5)]:
        A = Alg(sig(p, q)); v = {1: Fraction(1), 2: Fraction(-1)}; w = {4: Fraction(1), 8: Fraction(-1)}
        t2 = A.mul(v, v).get(0, 0) / 2; vw = A.mul(v, w); tt2 = A.mul(vw, vw).get(0, 0) / 4
        check(t2 == (1 if p else -1) and tt2 == -1, 'Cl(%d,%d): transposition lift squares to %+d, a product of two disjoint lifts squares to %+d  (%s of S_m)' % (p, q, t2, tt2, "cover with involution lifts (s^2 = 1)" if p else "cover with order-4 lifts (s^2 = z)"))

# ================================================================== D
def span_words(rows):
    S = {0}
    for r in rows: S |= {s ^ r for s in S}
    return S
def weight_enum(words, n=None):
    d = {}
    for w in words:
        k = pc(w); d[k] = d.get(k, 0) + 1
    return dict(sorted(d.items()))
def part_D():
    head('D.  The n=3 cube -> Hamming [8,4,4] -> Golay [24,12,8] -> M24 -> Leech;  the n=24 address form;  Monster 2-part')
    # D1  the cube of Cl(3,0): addresses F_2^3, affine functions = Reed-Muller RM(1,3) = extended Hamming
    pts = list(range(8))
    rows = [0xFF] + [sum(1 << x for x in pts if (x >> k) & 1) for k in range(3)]
    Hc = span_words(rows)
    print('D1  extended Hamming code from the 8 cube addresses (affine functions):', 'weights', weight_enum(Hc))
    check(weight_enum(Hc) == {0: 1, 4: 14, 8: 1}, 'RM(1,3) is [8,4,4] with weights 0^1 4^14 8^1 (14 affine planes of the cube)')
    # automorphism group by brute force over S_8
    cnt = 0
    for perm in itertools.permutations(range(8)):
        if all(sum(((r >> i) & 1) << perm[i] for i in range(8)) in Hc for r in rows): cnt += 1
    check(cnt == 1344, '|Aut(extended Hamming)| = 1344 = 2^3 * |L3(2)| (brute force over all 40320 permutations): got %d' % cnt)
    # D2  Turyn: (a+x, b+x, a+b+x), a,b in H, x in H'
    rnd = random.Random(1)
    while True:
        perm = list(range(8)); rnd.shuffle(perm)
        Hp = {sum(((w >> i) & 1) << perm[i] for i in range(8)) for w in Hc}
        if Hc & Hp == {0, 0xFF}: break
    G = set()
    for a in Hc:
        for b in Hc:
            for x in Hp:
                G.add((a ^ x) | ((b ^ x) << 8) | ((a ^ b ^ x) << 16))
    we = weight_enum(G)
    print('D2  Turyn construction from two copies of the n=3 cube code: |C| = %d, weights %s' % (len(G), we))
    check(len(G) == 4096 and we == {0: 1, 8: 759, 12: 2576, 16: 759, 24: 1}, 'Turyn code is the Golay code [24,12,8]: 759 octads, 2576 dodecads')
    # D3  Golay code is totally singular for Q_{Cl(24,0)}  (doubly even + self-orthogonal)
    Gw = sorted(G)
    dbl = all(pc(w) % 4 == 0 for w in Gw)
    basis = []
    sp = {0}
    for w in Gw:
        if w not in sp: basis.append(w); sp |= {s ^ w for s in sp}
    selforth = all(pc(a & b) % 2 == 0 for a in basis for b in basis)
    check(len(basis) == 12 and dbl and selforth, 'D3 every codeword has weight = 0 mod 4 and the code is self-orthogonal: e_c (c in C) are 4096 commuting involutions of Cl(24,0)')
    Q24 = lambda a: (pc(a) * (pc(a) - 1) // 2) & 1
    # count singular vectors of Cl(24,0): number of even-weight/odd... closed form via generating function
    sing24 = sum(math.comb(24, k) for k in range(25) if ((k * (k - 1) // 2) & 1) == 0)
    check(sing24 == 2 ** 23 + 2 ** 11, 'n=24: Cl(24,0) address form has %d singular vectors = 2^23+2^11: type +, class R, Witt index 12 -> the Golay code is a MAXIMAL totally singular subspace' % sing24)
    # D4  M24 from PSL(2,23)+delta, acting on the QR code
    P = 23; INF = 23
    qr = {(x * x) % P for x in range(1, P)}
    def pm(f): return tuple(f(x) for x in range(24))
    inv_ = lambda x: pow(x, -1, P)
    alpha = pm(lambda x: INF if x == INF else (x + 1) % P)
    beta = pm(lambda x: INF if x == INF else (2 * x) % P)
    gamma = pm(lambda x: 0 if x == INF else (INF if x == 0 else (-inv_(x)) % P))
    L = BSGS([alpha, beta, gamma], 24)
    check(L.order() == 6072, 'D4 <x+1, 2x, -1/x> = PSL(2,23) of order 6072 on the 24 points of the projective line')
    # code: cyclic Golay [23,12,7] extended
    gp = [0, 2, 4, 5, 6, 10, 11]
    def cyc(support, s): return sum(1 << ((i + s) % 23) for i in support)
    def ext(w): return w | ((pc(w) & 1) << 23)
    results = {}
    for name, supp in (('g', gp), ('g-reversed', [(11 - i) for i in gp])):
        rowsq = [ext(cyc(supp, s)) for s in range(12)]
        Cq = span_words(rowsq)
        results[name] = (rowsq, Cq)
    print('   cyclic [23,12] + parity: weights', weight_enum(results['g'][1]))
    check(weight_enum(results['g'][1]) == we, 'the extended cyclic (quadratic-residue) code has the same weight enumerator as the Turyn code (equivalent by uniqueness of [24,12,8], STANDARD)')
    def pmask(perm, w): return sum(((w >> i) & 1) << perm[i] for i in range(24))
    found = None
    for dname, dfun in (('x^3/9 on Q, 9x^3 on N', lambda x: (INF if x == INF else 0 if x == 0 else (pow(x, 3, P) * inv_(9)) % P if x in qr else (9 * pow(x, 3, P)) % P)),
                        ('9x^3 on Q, x^3/9 on N', lambda x: (INF if x == INF else 0 if x == 0 else (9 * pow(x, 3, P)) % P if x in qr else (pow(x, 3, P) * inv_(9)) % P))):
        delta = pm(dfun)
        if sorted(delta) != list(range(24)): continue
        for cname, (rowsq, Cq) in results.items():
            if all(pmask(g, r) in Cq for g in (alpha, beta, gamma, delta) for r in rowsq):
                found = (dname, cname, delta, Cq); break
        if found: break
    check(found is not None, 'D4 PSL(2,23) and delta preserve the code (variant: %s on code %s)' % ((found[0], found[1]) if found else ('-', '-')))
    if found:
        dname, cname, delta, Cq = found
        M = BSGS([alpha, beta, gamma, delta], 24)
        check(M.order() == 244823040, 'D4 <PSL(2,23), delta> has order 244823040 = |M24| = 2^10 3^3 5 7 11 23: got %d' % M.order())
        sizes = [len(o) for o in M.orb]
        print('   orbit sizes along the base:', sizes[:7], '(5-transitive iff the first five are 24,23,22,21,20)')
        check(sizes[:5] == [24, 23, 22, 21, 20], 'M24 is 5-transitive (stabiliser chain 24,23,22,21,20)')
        # octads: orbit of one octad
        octads = [w for w in Cq if pc(w) == 8]
        o0 = octads[0]; orb = {o0}; fr = [o0]
        while fr:
            nx = []
            for w in fr:
                for g in (alpha, beta, gamma, delta):
                    y = pmask(g, w)
                    if y not in orb: orb.add(y); nx.append(y)
            fr = nx
        check(len(orb) == 759 == len(octads), 'M24 is transitive on the 759 octads')
        # simplicity: the normal closure of one non-identity element is everything; derived group is everything
        from permgroup import normal_closure_gens
        ng = normal_closure_gens(M, [alpha])
        NC = BSGS(ng, 24).order()
        check(NC == 244823040, 'normal closure of one element (x->x+1) is all of M24 (evidence of simplicity; with perfect order this is the standard proof route)')
        # octad stabiliser 2^4:A8
        o0 = octads[0]
        pts8 = [i for i in range(24) if (o0 >> i) & 1]
        check(M.order() // 759 == 322560 == 16 * 20160, 'octad stabiliser has order 322560 = 2^4 * |A8| (A8 = L4(2) = Omega^+_6(2): the n=4 GL(4,2) and the n=6 R-class O(Q) meet here)')
    # D5  Leech minimal vectors from the Golay code, and the kissing numbers (numpy)
    import numpy as np
    cw = np.array([[(w >> i) & 1 for i in range(24)] for w in Gw], dtype=np.int8)
    vecs = []
    # shape (+-4,+-4,0^22)
    for i in range(24):
        for j in range(i + 1, 24):
            for si in (4, -4):
                for sj in (4, -4):
                    v = np.zeros(24, dtype=np.int16); v[i] = si; v[j] = sj; vecs.append(v)
    shape_a = len(vecs)
    # shape (+-2^8,0^16): octads, even number of minus signs
    for w in Gw:
        if pc(w) == 8:
            idx = [i for i in range(24) if (w >> i) & 1]
            for signs in range(256):
                if bin(signs).count('1') % 2 == 0:
                    v = np.zeros(24, dtype=np.int16)
                    for t, i in enumerate(idx): v[i] = -2 if (signs >> t) & 1 else 2
                    vecs.append(v)
    shape_b = len(vecs) - shape_a
    # shape (-+3, +-1^23): signs +-1 following a codeword, the 3 at position j with the opposite sign
    cwsign = 1 - 2 * cw.astype(np.int16)                      # +1 / -1
    for j in range(24):
        V = cwsign.copy(); V[:, j] = V[:, j] * (-3)
        vecs.extend(list(V))
    shape_c = len(vecs) - shape_a - shape_b
    X = np.array(vecs, dtype=np.int16)
    norms = (X.astype(np.int32) ** 2).sum(axis=1)
    print('D5  Leech minimal vectors from the Turyn-Golay code: shapes %d + %d + %d = %d' % (shape_a, shape_b, shape_c, len(X)))
    check(len(X) == 196560 and (norms == 32).all(), 'D5 196560 vectors, all of norm 32 (= 4 after scaling by 1/sqrt 8)')
    ip = X.astype(np.int32) @ X[0].astype(np.int32)
    vals, cnts = np.unique(ip, return_counts=True)
    dist = {int(v) // 8: int(c) for v, c in zip(vals, cnts) if int(v) % 8 == 0}
    check(len(dist) == len(vals), 'all inner products are multiples of 8 (integral lattice after scaling)')
    exp = {4: 1, 2: 4600, 1: 47104, 0: 93150, -1: 47104, -2: 4600, -4: 1}
    print('   inner-product distribution seen from one minimal vector (scaled):', dict(sorted(dist.items())))
    check(dist == exp, 'D5 inner products {4:1, 2:4600, 1:47104, 0:93150, -1:47104, -2:4600, -4:1}: the Leech kissing configuration')
    # D6  Leech/2Leech has the form class of Cl(24,0)  (STANDARD class sizes) and Monster / Conway arithmetic
    t = {'0': 1, 'type2': 196560 // 2, 'type3': 16773120 // 2, 'type4': 398034000 // 48}
    tot = sum(t.values())
    check(tot == 2 ** 24, 'D6 Lambda/2Lambda classes 1 + 98280 + 8386560 + 8292375 = 2^24 (STANDARD class sizes 196560, 16773120, 398034000)')
    nons = t['type3']; sing = tot - nons
    check(sing == 2 ** 23 + 2 ** 11, 'D6 q(x)=x.x/2 mod 2 on Lambda/2Lambda is nonsingular only on type 3: #singular = 2^23+2^11 = that of Cl(24,0) (same F_2 class, type +)')
    co1 = 2 ** 21 * 3 ** 9 * 5 ** 4 * 7 ** 2 * 11 * 13 * 23
    check(co1 == 4157776806543360000, 'D6 |Co1| = 2^21 3^9 5^4 7^2 11 13 23 = 4157776806543360000 (STANDARD)')
    monster = 2 ** 46 * 3 ** 20 * 5 ** 9 * 7 ** 6 * 11 ** 2 * 13 ** 3 * 17 * 19 * 23 * 29 * 31 * 41 * 47 * 59 * 71
    check(monster == 808017424794512875886459904961710757005754368000000000, 'D6 |Monster| = 2^46 3^20 5^9 7^6 11^2 13^3 17 19 23 29 31 41 47 59 71 = 8.08e53 (STANDARD)')
    check(2 ** 25 * 2 ** 21 == 2 ** 46 and 2 ** 25 == 2 ** (24 + 1), 'D6 2-part: |blade group of Cl(24,0)| = 2^(1+24) times |Co1|_2 = 2^21 gives 2^46 = |Monster|_2')
    print('   (that the Monster contains 2^{1+24}.Co1 and that Co1 = Co0/{+-1} acts on Lambda/2Lambda by isometries of q is STANDARD, not derived here)')

# ================================================================== E
def factor(m):
    f = {}; d = 2
    while d * d <= m:
        while m % d == 0: f[d] = f.get(d, 0) + 1; m //= d
        d += 1
    if m > 1: f[m] = f.get(m, 0) + 1
    return f
def ord2(p):
    d = 1; x = 2 % p
    while x != 1: x = (x * 2) % p; d += 1
    return d
def part_E():
    head('E.  Primes: |GL(n,2)| = 2^{n(n-1)/2} prod (2^i - 1);  a prime p first divides it at n = ord_p(2)')
    print('   n : primes entering at n (primitive divisors of 2^n-1), n<=24')
    table = {}
    for n in range(2, 25):
        table[n] = sorted(p for p in factor(2 ** n - 1) if ord2(p) == n)
        print('   %2d: %s' % (n, table[n]))
    mp = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 41, 47, 59, 71]
    ordp = {p: ord2(p) for p in mp}
    print('   the 15 primes dividing |Monster| (2 and):  p -> n=ord_p(2):', ordp)
    check(all(pow(2, ordp[p], p) == 1 and all(pow(2, d, p) != 1 for d in range(1, ordp[p])) for p in ordp), 'ord_p(2) values verified by direct power computation')
    check(ordp[59] == 58 and ordp[71] == 35 and ordp[47] == 23 and ordp[41] == 20, 'the last Monster prime (59) enters at n=58; 71 at n=35; 47 at n=23; 41 at n=20 (arithmetic fact about |GL(n,2)|, not about the Monster)')
    check(table[6] == [], 'n=6 is the Zsigmondy exception: 2^6-1 = 3^2 * 7 has no new prime')
    check(all(table[n] for n in range(2, 25) if n != 6), 'every other n in 2..24 brings at least one new prime')

# ================================================================== F
def part_F():
    head('F.  Klein correspondence: <B^2>_4 of a bivector at n=4 is the Pfaffian; over F_2 the bivector space is the 6-bit R-class form and GL(4,2) = A8 acts on it as Omega+_6(2)')
    from fractions import Fraction
    pairs = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    idx = {pr: i for i, pr in enumerate(pairs)}
    # F1  exact over Z, every signature at n=4: the 4-vector part of B^2 is 2*Pf(B) e_1234 (disjoint indices: no sign eps enters)
    for (p, q) in [(4, 0), (3, 1), (2, 2), (1, 3), (0, 4)]:
        A = Alg(sig(p, q)); rnd = random.Random(5 + p); ok = True
        for _ in range(60):
            Bc = {pr: rnd.randint(-6, 6) for pr in pairs}
            B = {(1 << a) | (1 << b): Fraction(c) for (a, b), c in Bc.items() if c}
            sq = A.mul(B, B)
            pf = Bc[(0, 1)] * Bc[(2, 3)] - Bc[(0, 2)] * Bc[(1, 3)] + Bc[(0, 3)] * Bc[(1, 2)]
            ok = ok and sq.get(15, 0) == 2 * pf and all(pc(k) in (0, 4) for k in sq)    # B^2 lives on grades 0 and 4 only
        check(ok, 'Cl(%d,%d): <B^2>_4 = 2 Pf(B) e_1234 and B^2 has only grades 0 and 4 (60 random integer bivectors)' % (p, q))
    # F2  over F_2: bivectors of F_2^4 = 6 bits, q(B) = Pf(B)
    def wedge(u, v):
        w = 0
        for (a, b) in pairs:
            c = (((u >> a) & 1) & ((v >> b) & 1)) ^ (((u >> b) & 1) & ((v >> a) & 1))
            if c: w |= 1 << idx[(a, b)]
        return w
    def Pf(w):
        g = lambda a, b: (w >> idx[(a, b)]) & 1
        return (g(0, 1) & g(2, 3)) ^ (g(0, 2) & g(1, 3)) ^ (g(0, 3) & g(1, 2))
    Qk = [Pf(w) for w in range(64)]
    inv6 = invariants(Qk, 6)
    check(inv6 == invariants(Qtab_cell(0, 6), 6) and zclass(inv6) == 'R', 'the bivector form q = Pf on F_2^6 has the complete invariants of the n=6 R-class address form (class R, %d singular vectors incl. 0)' % inv6[3])
    simple = {wedge(u, v) for u in range(16) for v in range(16)} - {0}
    sing = {w for w in range(1, 64) if Qk[w] == 0}
    check(simple == sing and len(simple) == 35, 'simple (decomposable) bivectors = the 35 nonzero singular vectors = the 35 lines of PG(3,2); the other %d are non-simple (Pf = 1): the Plucker relation B^B = 0' % (63 - len(simple)))
    f, g_, ok_ = None, None, None
    # GL(4,2) from elementary maps e_i -> e_i + e_j, acting on bivectors by the 2x2 minors
    def induced(imgs):
        # basis bivector e_ab -> wedge(imgs[a], imgs[b]); extend linearly to 6 bits
        im = [wedge(imgs[a], imgs[b]) for (a, b) in pairs]
        out = []
        for w in range(1, 64):
            y = 0
            for i in range(6):
                if (w >> i) & 1: y ^= im[i]
            out.append(y)
        return im
    gl_gens = []
    for i in range(4):
        for j in range(4):
            if i != j:
                imgs = [1 << k for k in range(4)]; imgs[i] ^= 1 << j; gl_gens.append(imgs)
    # order of GL(4,2) on the 15 nonzero vectors
    perms4 = [tuple(apply_lin(im, x) - 1 for x in range(1, 16)) for im in gl_gens]
    G4 = BSGS(perms4, 15)
    check(G4.order() == 20160, '|GL(4,2)| = 20160 (Schreier-Sims on the 15 nonzero vectors)')
    ims6 = [induced(im) for im in gl_gens]
    check(all(is_isometry(im6, Qk, Qk, 6) for im6 in ims6), 'GL(4,2) acts on the bivector space by isometries of q = Pf (every generator checked on all 64 vectors)')
    ns = [v for v in range(1, 64) if Qk[v]]; nidx = {v: i for i, v in enumerate(ns)}
    perms6 = [tuple(nidx[apply_lin(im6, v)] for v in ns) for im6 in ims6]
    Gim = BSGS(perms6, len(ns))
    H, chosen, deg = isometry_group(Qk, 6)
    check(len(ns) == 28 and Gim.order() == 20160 and H.order() == 40320 == oq_formula(6, 'R'), 'image of GL(4,2) has order 20160 (faithful); O(q) has order 40320 = |O+_6(2)| = |S8|; the 28 nonsingular vectors are acted on')
    check(all(H.contains(p) for p in perms6), 'the image lies inside O(q) (same points, same indexing)')
    check(derived_order(H, chosen) == 20160, 'the derived subgroup of O(q) has order 20160 = the image: GL(4,2) = A8 = Omega+_6(2), index 2 in O+_6(2) = S8')
    print('   so at n=4 the invariant that makes a bivector non-simple (Step 1) is the same Pfaffian that identifies A8 = L4(2) with the 6-bit R-class core (cascade table, rows n = 4 and n = 6).')

if __name__ == '__main__':
    parts = sys.argv[1:] or list('ABCDEF')
    for p in parts:
        {'A': part_A, 'B': part_B, 'C': part_C, 'D': part_D, 'E': part_E, 'F': part_F}[p]()
        print(stamp(), 'part', p, 'done')
    print('\n' + ('ALL GROUP CHECKS PASS' if not FAILS else 'FAILURES: %d' % len(FAILS)))
    for f in FAILS: print('  FAIL', f)
