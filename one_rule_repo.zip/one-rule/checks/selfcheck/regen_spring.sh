#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild spring.json (exact) and the two modules the page imports from it
# Run from anywhere; every path is inside the package; stops at the first error (set -e), and a failing check of the stored json is an error.
set -e
cd "$(dirname "$0")"
last() { n=$1; shift; out=$("$@") || { printf '%s\n' "$out" >&2; echo "regen: failed: $*" >&2; exit 1; }; printf '%s\n' "$out" | tail -"$n"; }   # run a command, stop on its failure (a pipe into tail would hide it), print its last lines
last 2 python3 spring_selfcheck.py --write spring.json
last 1 python3 spring_selfcheck.py --compare spring.json
cd ..
python3 - <<'PY'
import json
JS_HEADER = '// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n// Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)\n'
d=json.load(open('selfcheck/spring.json'))
open('springData.js','w').write(JS_HEADER+'export default '+json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n')
open('springSelfcheckSource.js','w').write('export const SPR_PY = '+json.dumps(open('selfcheck/spring_selfcheck.py').read(),ensure_ascii=False)+';\n')
PY
echo "regen_spring: done"
