#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild spin.json (exact) and the two modules the page imports from it
# Run from anywhere; every path is inside the package; stops at the first error (set -e), and a failing check of the stored json is an error.
set -e
cd "$(dirname "$0")"
last() { n=$1; shift; out=$("$@") || { printf '%s\n' "$out" >&2; echo "regen: failed: $*" >&2; exit 1; }; printf '%s\n' "$out" | tail -"$n"; }   # run a command, stop on its failure (a pipe into tail would hide it), print its last lines
last 2 python3 spin_selfcheck.py --write spin.json
last 1 python3 spin_selfcheck.py --compare spin.json
cd ..
python3 - <<'PY'
import json
JS_HEADER = '// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n// Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)\n'
d=json.load(open('selfcheck/spin.json')); m=d.pop('matrix')
open('spinData.js','w').write(JS_HEADER+'export default '+json.dumps({'sp':d,'spm':m},ensure_ascii=False,separators=(',',':'))+'\n')
open('spinSelfcheckSource.js','w').write('export const SP_PY = '+json.dumps(open('selfcheck/spin_selfcheck.py').read(),ensure_ascii=False)+';\n')
PY
echo "regen_spin: done"
