#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild schullerSelfcheckSource.js: the three check scripts of step 20 (the Schuller chapter of the lenses page) as strings, byte for byte, for its download buttons
# Run from anywhere; every path is inside the package; deterministic and re-runnable. Each script is run first and must pass (needs python3 and numpy):
# a failing script stops the run (set -e) and leaves the module as it was.
set -e
cd "$(dirname "$0")/reports"
last() { n=$1; shift; out=$("$@") || { printf '%s\n' "$out" >&2; echo "regen: failed: $*" >&2; exit 1; }; printf '%s\n' "$out" | tail -"$n"; }   # run a command, stop on its failure (a pipe into tail would hide it), print its last lines
last 1 python3 fibre_check.py
last 1 python3 bridge_check.py
last 1 python3 bridge_check_qm.py
cd ../..
python3 - <<'PY'
import json
names = [('FIBRE_CHECK_PY', 'selfcheck/reports/fibre_check.py'), ('BRIDGE_CHECK_PY', 'selfcheck/reports/bridge_check.py'), ('QM_CHECK_PY', 'selfcheck/reports/bridge_check_qm.py')]
out = ''.join('export const %s = %s;\n' % (k, json.dumps(open(f, encoding='utf-8').read(), ensure_ascii=False)) for k, f in names)
open('schullerSelfcheckSource.js', 'w', encoding='utf-8').write(out)
PY
echo "regen_lens_schuller: done"
