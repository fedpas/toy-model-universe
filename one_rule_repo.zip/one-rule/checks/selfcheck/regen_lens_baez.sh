#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild baezSelfcheckSource.js, the mirror of the report script the Baez chapter (step 19) offers for download: export const BAEZ_CHECK_PY = "<the file as a JSON string>";
# Deterministic and re-runnable: the mirror equals selfcheck/reports/baez_check.py byte for byte (test_lens_baez.mjs and test_license.mjs check it).
# The script itself is not run here (it needs numpy, networkx and scipy and takes about two minutes): run it with  cd selfcheck/reports && python3 baez_check.py
set -e
cd "$(dirname "$0")/.."
python3 - <<'PY'
import json
src = open('selfcheck/reports/baez_check.py', encoding='utf-8').read()
open('baezSelfcheckSource.js', 'w', encoding='utf-8').write('export const BAEZ_CHECK_PY = ' + json.dumps(src, ensure_ascii=False) + ';\n')
PY
echo "regen_lens_baez: done"
