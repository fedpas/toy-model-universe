#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Fibre and base in the bit rule.  Questions asked: is "locally base (x) fibre" the bit rule's label concatenation?  Are base and fibre the left and right
action of an algebra on itself?  If the total dimension is kept at 8 and the base is stepped down, does the fibre fill up?  Is the band structure of the quantum notes' chapter 20 the
atlas's trio -1, 0, +1?  Is the "24 = 3 x 8" a triality that appears at several n?  Every statement is computed here; readings are tagged in the messages and in the report.
Python standard library + numpy.   Run: python3 fibre_check.py
Shipped in the webapp package as selfcheck/reports/fibre_check.py: needs bitcliff.py at <package>/selfcheck/steps15_17 (default: the package two levels up from this script; override with the environment variable ATLAS_PKG). Python dependencies: numpy (and the standard library). Writes nothing."""
import os, sys, math, random, itertools
from fractions import Fraction as Fr
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..'))      # the webapp package: two levels up from selfcheck/reports/
sys.path.insert(0, os.path.join(PKG, 'selfcheck', 'steps15_17'))
from bitcliff import Alg, sig, pc, reorder_sign, TYPES

N_OK = N_BAD = 0
def chk(cid, cond, msg=''):
    global N_OK, N_BAD
    if cond: N_OK += 1
    else: N_BAD += 1
    print(('ok   ' if cond else 'FAIL ') + cid + (': ' + msg if msg else ''))

# =====================================================================================================================================================
# G1. Locally a product.  Base Cl(1,3) (generators 0..3), fibre Cl(0,3) (generators 4..6): the total algebra Cl(1,6).  A blade of the total is (base label | fibre label).
#     The fibre's even part commutes with the whole base; the fibre's bivectors close into so(3) and commute with the Lorentz bivectors of the base.
# =====================================================================================================================================================
base, fib = sig(1, 3), sig(0, 3); nb, nf = len(base), len(fib)
TOT = Alg(base + fib); AB = Alg(base); AF = Alg(fib)
ok = True
for a in range(AB.N):
    for b in range(AF.N):
        for c in range(AB.N):
            for d in range(AF.N):
                s1, m1 = AB.blade_mul(a, c); s2, m2 = AF.blade_mul(b, d)
                want = ((-1) ** (pc(b) * pc(c))) * s1 * s2, m1 | (m2 << nb)
                if TOT.blade_mul(a | (b << nb), c | (d << nb)) != want: ok = False
chk('G1a', ok, 'base Cl(1,3), fibre Cl(0,3): the product of two total blades is the concatenation of labels (base | fibre) with the sign (-1)^(|b||c|) times the two factor signs: locally the total algebra is base (x)^ fibre = Cl(1,6)')
def comm_zero(x, y): return not TOT.add(TOT.mul(x, y), TOT.mul(y, x), -1)
def anti_zero(x, y): return not TOT.add(TOT.mul(x, y), TOT.mul(y, x), 1)
fb_biv = [(1 << (nb + i)) | (1 << (nb + j)) for i in range(nf) for j in range(i + 1, nf)]
base_gens = [1 << i for i in range(nb)]; base_biv = [(1 << i) | (1 << j) for i in range(nb) for j in range(i + 1, nb)]
ok1 = all(comm_zero({B: Fr(1)}, {g: Fr(1)}) for B in fb_biv for g in base_gens)
ok2 = all(comm_zero({B: Fr(1)}, {C: Fr(1)}) for B in fb_biv for C in base_biv)
ok3 = all(anti_zero({1 << (nb + i): Fr(1)}, {g: Fr(1)}) for i in range(nf) for g in base_gens)
chk('G1b', ok1 and ok2 and ok3, f'the {len(fb_biv)} fibre bivectors commute with all {nb} base generators and with the {len(base_biv)} Lorentz bivectors, while a single fibre generator anticommutes with every base generator: the fibre group (even versors) commutes with the base frame group: Spin(base) x Spin(fibre)')
def closes(blist, al):
    for x in blist:
        for y in blist:
            c = al.add(al.mul({x: Fr(1)}, {y: Fr(1)}), al.mul({y: Fr(1)}, {x: Fr(1)}), -1)
            if any(pc(k) != 2 for k in c): return False
    return True
fjac = True
for x, y, z in itertools.product(fb_biv, repeat=3):
    X, Y, Z = {x: Fr(1)}, {y: Fr(1)}, {z: Fr(1)}
    c = lambda P, Q: TOT.add(TOT.mul(P, Q), TOT.mul(Q, P), -1)
    j = TOT.add(TOT.add(c(X, c(Y, Z)), c(Y, c(Z, X))), c(Z, c(X, Y)))
    if j: fjac = False
chk('G1c', closes(fb_biv, TOT) and fjac, 'the fibre bivectors close under the commutator and satisfy Jacobi: so(3) = su(2), the gauge algebra of step 7, living entirely in the fibre')

# =====================================================================================================================================================
# G2. Base and fibre as the left and right action of an algebra on itself.  A = Cl(p,q) with basis the 2^n blades.  L_i = left multiplication by e_i, R_j = right multiplication (they commute),
#     R'_j = (-1)^|x| x e_j (the right action with the grading twist).  Facts: (a) L_i^2 = R_j^2 = eps_i and [L,R]=0; the span of all L_a R_b has dimension 4^n / dim Z(A);
#     (b) R'_j anticommutes with all L_i and R'_j^2 = -eps_j: the 2n operators L_i, R'_j satisfy the bit rule of Cl(n,n) = signature of A followed by its MIRROR, and span End(A) = M_{2^n}(R).
# =====================================================================================================================================================
def regmats(eps):
    al = Alg(eps); n = al.n; D = al.N
    L, R, Rt = [], [], []
    for i in range(n):
        Li = np.zeros((D, D)); Ri = np.zeros((D, D)); Rti = np.zeros((D, D))
        for x in range(D):
            s, c = al.blade_mul(1 << i, x); Li[c, x] = s
            s, c = al.blade_mul(x, 1 << i); Ri[c, x] = s; Rti[c, x] = s * (-1 if pc(x) & 1 else 1)
        L.append(Li); R.append(Ri); Rt.append(Rti)
    return al, L, R, Rt
def blademat(gens, a, D):
    M = np.eye(D)
    for i, g in enumerate(gens):
        if a >> i & 1: M = M @ g
    return M
def center_dim(al):
    n = al.n; cnt = 0
    for a in range(al.N):
        if all(al.blade_mul(a, 1 << i) == al.blade_mul(1 << i, a) for i in range(n)): cnt += 1
    return cnt
rows_a = []; ok_a = ok_b = True; nsig = 0; worst = ''
for n in range(1, 6):
    for p in range(n + 1):
        q = n - p; eps = sig(p, q); al, L, R, Rt = regmats(eps); D = al.N; nsig += 1
        a1 = all(np.allclose(L[i] @ R[j], R[j] @ L[i]) for i in range(n) for j in range(n)) and all(np.allclose(L[i] @ L[i], eps[i] * np.eye(D)) and np.allclose(R[i] @ R[i], eps[i] * np.eye(D)) for i in range(n))
        span = np.array([(blademat(L, a, D) @ blademat(R, b, D)).flatten() for a in range(D) for b in range(D)])
        rk = np.linalg.matrix_rank(span); zd = center_dim(al)
        ok_a &= a1 and rk * zd == D * D
        if not (a1 and rk * zd == D * D): worst = f'Cl({p},{q}) rank {rk} centre {zd}'
        rows_a.append((p, q, rk, zd))
        gens = L + Rt; eps2 = tuple(eps) + tuple(-e for e in eps)
        anti = all(np.allclose(L[i] @ Rt[j] + Rt[j] @ L[i], 0) for i in range(n) for j in range(n))
        sq = all(np.allclose(Rt[j] @ Rt[j], -eps[j] * np.eye(D)) for j in range(n))
        al2 = Alg(eps2); mats = [blademat(gens, a, D) for a in range(al2.N)]
        pairs = [(a, b) for a in range(al2.N) for b in range(al2.N)]
        if len(pairs) > 900: pairs = random.Random(2).sample(pairs, 900)
        okbit = all(np.allclose(mats[a] @ mats[b], al2.blade_mul(a, b)[0] * mats[a ^ b]) for a, b in pairs)
        rk2 = np.linalg.matrix_rank(np.array([m.flatten() for m in mats]))
        ok_b &= anti and sq and okbit and rk2 == D * D
chk('G2a', ok_a, f'all {nsig} signatures with n = 1..5: L_i, R_j commute, square to eps_i, and the span of all L_a R_b has dimension 4^n / dim Z(A) (n even: centre {{1}}, full End(A); n odd: the pseudoscalar is central, so left and right overlap through it: base and fibre are not independent) {worst}')
chk('G2b', ok_b, f'all {nsig} signatures with n = 1..5: with the grading twist R\'_j anticommutes with every L_i and squares to -eps_j; the 2n operators obey the bit rule of Cl(n,n) with signature (eps | -eps): A acts on itself through A (x)^ mirror(A) = Cl(n,n) = M_(2^n)(R), faithfully and onto End(A)')
# the mirror has clock minus c, so base and fibre clocks add to 0 mod 8: the End class
ok = True
for n in range(0, 13):
    for p in range(n + 1):
        q = n - p
        ok &= ((p - q) + (q - p)) % 8 == 0 and TYPES[((p + q) - (q + p)) % 8] == 'R'
chk('G2c', ok, 'for every Cl(p,q), n <= 12: the clocks of an algebra and its mirror add to 0 mod 8 and the graded product Cl(p,q) (x)^ Cl(q,p) = Cl(n,n) has type R (matrix algebra over R): the right action is the Brauer-Wall inverse of the left')
# Furey / lectures: Cl(1,3) acting on itself: fibre side is Cl(3,1)
al13, L13, R13, Rt13 = regmats(sig(1, 3))
ok = all(np.allclose(Rt13[j] @ Rt13[j], -sig(1, 3)[j] * np.eye(16)) for j in range(4)) and [int(-e) for e in sig(1, 3)] == [-1, 1, 1, 1]
chk('G2d', ok, 'n = 4: Cl(1,3) acts on itself (16-dim) by left multiplication; its twisted right multiplication squares to (-1,+1,+1,+1): the fibre side is Cl(3,1), the signature the quantum notes print for the Dirac algebra; together Cl(4,4) = M_16(R) = End(V), isomorphic as algebras to the End(V) of the Furey page (generators not matched, not a Lorentz frame)')

# =====================================================================================================================================================
# G3. "n = 8 fixed, step the base down": the total is Cl(0,8) = M_16(R) acting on V = R^16 (explicit real 16x16 matrices).  Base = the first k generators, fibre = their commutant in End(V).
#     Claim: dim commutant = 2^(8-k) (the fibre fills up as the base shrinks), double commutant = base (2^k), centres agree, and the types of the commutants run through the clock.
# =====================================================================================================================================================
I2 = np.eye(2); SX = np.array([[0, 1], [1, 0.]]); SZ = np.array([[1, 0], [0, -1.]]); EE = np.array([[0, 1], [-1, 0.]])
base4 = [I2, SX, SZ, EE]
cands = []
for t in itertools.product(range(4), repeat=4):
    M = np.eye(1)
    for i in t: M = np.kron(M, base4[i])
    if np.allclose(M @ M, -np.eye(16)): cands.append(M)
def search(cur, start):
    if len(cur) == 8: return cur
    for i in range(start, len(cands)):
        if all(np.allclose(cands[i] @ g + g @ cands[i], 0) for g in cur):
            r = search(cur + [cands[i]], i + 1)
            if r: return r
    return None
G8 = search([], 0)
assert G8 is not None
chk('G3a', all(np.allclose(g @ g, -np.eye(16)) for g in G8) and all(np.allclose(G8[i] @ G8[j] + G8[j] @ G8[i], 0) for i in range(8) for j in range(i)), 'eight real 16x16 matrices with gamma^2 = -1, pairwise anticommuting: Cl(0,8) = M_16(R) acts on V = R^16 (Furey\'s V)')
def alg_span(gens, n):
    mats = []
    for a in range(1 << n):
        M = np.eye(16)
        for i in range(n):
            if a >> i & 1: M = M @ gens[i]
        mats.append(M.flatten())
    return np.array(mats)
def commutant_basis(mlist):
    # X with X M = M X for each M in mlist: nullspace of the stacked linear maps X -> XM - MX on the 256 unknowns.
    # row-major vec: vec(X M - M X) = (I (x) M^T - M (x) I) vec(X).  Accumulate K^T K (256 x 256) and take its null space.
    G = np.zeros((256, 256))
    for M in mlist:
        K = np.kron(np.eye(16), M.T) - np.kron(M, np.eye(16))
        G += K.T @ K
    w, v = np.linalg.eigh(G)
    return v[:, w < 1e-9].T
ok_dim = ok_dd = ok_ctr = True; table = []
for k in range(0, 9):
    gens = G8[:k]
    Bm = alg_span(gens, k); dimB = np.linalg.matrix_rank(Bm) if k else 1
    if k == 0:
        null = np.eye(256)
    else:
        null = commutant_basis(gens)
    dimC = null.shape[0]
    Cmats = [v.reshape(16, 16) for v in null]
    # double commutant
    if dimC == 256: dimBB = 1
    else:
        nullC = commutant_basis(Cmats)
        dimBB = nullC.shape[0]
    # centre of B = B cap C: dimension of intersection
    if k:
        both = np.vstack([Bm[:dimB] if False else Bm, null])
        rB = dimB; rC = dimC; rBC = np.linalg.matrix_rank(np.vstack([Bm, null]))
        zdim = rB + rC - rBC
    else:
        zdim = 1
    table.append((k, dimB, dimC, dimBB, zdim))
    ok_dim &= dimB == 2 ** k and dimC == 2 ** (8 - k)
    ok_dd &= dimBB == 2 ** k if k else True
chk('G3b', ok_dim, 'base = the algebra of the first k gamma (dimension 2^k), fibre = its commutant in End(R^16): dimensions ' + ', '.join(f'k={k}: {c}' for k, b, c, d, z in table) + ' = 2^(8-k): the base shrinks by 2 and the fibre doubles at every step; the product of the two dimensions stays 2^8')
chk('G3c', ok_dd, 'double commutant: the commutant of the fibre is the base again (dimensions ' + ', '.join(str(d) for k, b, c, d, z in table) + '): the split is a genuine pair, not a one-sided truncation')
cz = {k: z for k, b, c, d, z in table}
want_ctr = {0: 1, 1: 2, 2: 1, 3: 2, 4: 1, 5: 2, 6: 1, 7: 2, 8: 1}
chk('G3d', cz == want_ctr, 'centre of base = centre of fibre = their intersection, dimension ' + ', '.join(f'k={k}: {cz[k]}' for k in range(9)) + ': 1 for k even, 2 for k odd (the pseudoscalar of the base): by the double-centraliser theorem fibre and base have the same Brauer class, so the fibre types run R, C, H, H2, H, C, R, R2, R as k = 0..8, the clock of Cl(0,k) itself (standard theorem; the dimensions and centres are computed here)')


# G3e. The fibre built by hand: the commutant of the first k gamma is generated by explicit elements (omega_k = product of the first k gamma):
#      k even: h_j = omega_k gamma_j (j > k), they commute with the base, anticommute among themselves, and square to -omega_k^2 = -(-1)^(k/2):  fibre = Cl(0,8-k) (k = 0 mod 4) or Cl(8-k,0) (k = 2 mod 4)
#      k odd:  the even products gamma_i gamma_j (i,j > k) together with the central omega_k (omega_k^2 = (-1)^(k(k+1)/2)):  fibre = Cl(0,7-k) (x) Z(omega_k)
#      Their span has dimension 2^(8-k) = the commutant, so it IS the commutant; the type then comes from the atlas's clock.
def prod(mats):
    M = np.eye(16)
    for m in mats: M = M @ m
    return M
ftypes = {}; ok_gen = True; detail = []
for k in range(9):
    base_g, ferm = G8[:k], G8[k:]; om = prod(base_g); m = 8 - k
    if k % 2 == 0:
        hs = [om @ g for g in ferm]
        comm = all(np.allclose(h @ b, b @ h) for h in hs for b in base_g)
        anti = all(np.allclose(hs[i] @ hs[j] + hs[j] @ hs[i], 0) for i in range(len(hs)) for j in range(i))
        sqv = {round(float((h @ h)[0, 0])) for h in hs}
        sgn = sqv.pop() if hs else None
        span = [prod([hs[i] for i in range(len(hs)) if a >> i & 1]).flatten() for a in range(1 << len(hs))]
        dimF = np.linalg.matrix_rank(np.array(span))
        if m == 0: ftype = 'R'
        else:
            p_, q_ = (m, 0) if sgn == 1 else (0, m)
            ftype = TYPES[(p_ - q_) % 8]
        ok_gen &= comm and anti and len(sqv) == 0 and dimF == 2 ** m and sgn in (None, 1, -1)
        detail.append((k, f'Cl({m},0)' if sgn == 1 else (f'Cl(0,{m})' if m else 'R'), ftype))
    else:
        ev = []
        for a in range(1 << m):
            if bin(a).count('1') % 2 == 0:
                ev.append(prod([ferm[i] for i in range(m) if a >> i & 1]).flatten())
        wsq = round(float((om @ om)[0, 0]))
        comm = all(np.allclose(np.array(e).reshape(16, 16) @ b, b @ np.array(e).reshape(16, 16)) for e in ev for b in base_g) and all(np.allclose(om @ b, b @ om) for b in base_g)
        span = ev + [(om @ np.array(e).reshape(16, 16)).flatten() for e in ev]
        dimF = np.linalg.matrix_rank(np.array(span))
        # even subalgebra of Cl(0,m) = Cl(0,m-1); tensor with the centre: omega^2 = -1 -> C, +1 -> R^2
        inner = TYPES[(-(m - 1)) % 8]
        ftype = ('C' if inner in ('R', 'H') else None) if wsq == -1 else inner + '2'
        ok_gen &= comm and dimF == 2 ** m and wsq == (-1) ** (k * (k + 1) // 2)
        detail.append((k, f'Cl(0,{m-1}) (x) ' + ('C' if wsq == -1 else 'R2'), ftype))
    ftypes[k] = ftype
want = ['R', 'C', 'H', 'H2', 'H', 'C', 'R', 'R2', 'R']
btypes = [TYPES[(-k) % 8] for k in range(9)]
chk('G3e', ok_gen and [ftypes[k] for k in range(9)] == want and btypes == want, 'explicit fibre generators commute with the base and span exactly the commutant (dimension 2^(8-k)); fibre = ' + ', '.join(f'k={k}: {d}={t}' for k, d, t in detail) + '; the base Cl(0,k) has the same type sequence ' + ','.join(btypes) + ': base and fibre carry the same division algebra at every step (double-centraliser, computed)')

# =====================================================================================================================================================
# G4. A momentum along an extra (fibre) direction enters as a mass (Kaluza-Klein; reading the mass as coming from the fibre is ours).  The Dirac-type operator on base x fibre is P_tot = P_base + m f with f a fibre generator.  The mass shell P_tot^2 = 0 reads E^2 = |p|^2 - eps_f m^2.
#     With eps_f = -1 (f squares like a space direction) this is E^2 = |p|^2 + m^2; with eps_f = +1 it is tachyonic.  At n = 4 the fibre direction is the pseudoscalar of the base itself.
# =====================================================================================================================================================
rng = random.Random(41)
def vec(al, comp): return {1 << i: Fr(c) for i, c in enumerate(comp) if c != 0}
def sq_scalar(al, x):
    y = al.mul(x, x)
    return y.get(0, Fr(0)), {k: v for k, v in y.items() if k != 0}
ok = True
A13 = Alg(sig(1, 3)); om13 = {15: Fr(1)}
ok &= A13.sq(15) == -1
ok &= all(anti_zero_al(A13, om13, {1 << i: Fr(1)}) for i in range(4)) if False else True
def anti_al(al, x, y): return not al.add(al.mul(x, y), al.mul(y, x), 1)
ok &= all(anti_al(A13, om13, {1 << i: Fr(1)}) for i in range(4))
for _ in range(60):
    E, p1, p2, p3, m = [Fr(rng.randint(-5, 5)) for _ in range(5)]
    P = vec(A13, [E, p1, p2, p3]); Pm = A13.add(P, A13.scal(om13, m), 1)
    s, rest = sq_scalar(A13, Pm)
    ok &= (s == E * E - p1 * p1 - p2 * p2 - p3 * p3 - m * m) and not rest
chk('G4a', ok, 'Cl(1,3), P = E e0 + p.e, pseudoscalar w = e0123 squares -1 and anticommutes with every generator: (P + m w)^2 = E^2 - |p|^2 - m^2 exactly (60 random integer samples): the mass term is a fibre direction squaring -1, and at n = 4 it already lives inside the algebra as the pseudoscalar')
A31 = Alg(sig(3, 1)); ok = A31.sq(15) == -1 and all(anti_al(A31, {15: Fr(1)}, {1 << i: Fr(1)}) for i in range(4))
for _ in range(60):
    e0, p1, p2, p3, m = [Fr(rng.randint(-5, 5)) for _ in range(5)]
    # Cl(3,1): the first three generators square +1 (space), the last squares -1 (time), the notes' convention
    P = vec(A31, [p1, p2, p3, e0]); Pm = A31.add(P, A31.scal({15: Fr(1)}, m), 1)
    s, rest = sq_scalar(A31, Pm)
    ok &= (s == p1 * p1 + p2 * p2 + p3 * p3 - e0 * e0 - m * m) and not rest
# Klein-Gordon factorisation in the notes' convention, exact: the real operator gamma.d - m of Cl(3,1) already has the physical shell.
# On a plane wave d -> i k the symbol of the real operator is i P_k - m, so (iP_k - m)(-iP_k - m) = P_k^2 + m^2 = s_k + m^2 (s_k = |k|^2 - w^2, the scalar square of P_k = k.e + w e_t);
# the printed form i gamma.d - m has the symbol -P_k - m, so (-P_k - m)(-P_k + m) = P_k^2 - m^2 = s_k - m^2.
for a_, m_, w_ in [(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (20, 21, 29)]:      # w^2 = a^2 + m^2
    Pk = vec(A31, [Fr(a_), Fr(0), Fr(0), Fr(w_)]); sk, rk = sq_scalar(A31, Pk)
    real_val = sk + m_ * m_; printed_val = sk - m_ * m_
    ok &= (not rk) and sk == a_ * a_ - w_ * w_ and real_val == 0 and printed_val == -2 * m_ * m_ != 0
chk('G4b', ok, 'the same in the notes\' convention Cl(3,1) (time squares -1): (P + m w)^2 = |p|^2 - E^2 - m^2, i.e. the shell E^2 = |p|^2 - m^2: a real mass term from the pseudoscalar has the wrong sign here. The physical sign E^2 = |p|^2 + m^2 does not need a central i: the real operator gamma.d - m of Cl(3,1) has it, since (gamma.d - m)(gamma.d + m) = |d|^2 - d_t^2 - m^2 is minus the Klein-Gordon operator, and on a plane wave the i is the Fourier i of d -> i p, not an element of the algebra (exact, five Pythagorean shells: the real symbol vanishes, the printed i gamma.d - m has value -2 m^2). The printed (i gamma.d - m) belongs to Cl(1,3), time squares +1: with the eta of the notes it is a mismatch of conventions, not a problem of the cell.')
A14 = Alg(sig(1, 4)); w5 = {31: Fr(1)}; e4 = {16: Fr(1)}
cen = A14.sq(31) == 1 and all(not A14.add(A14.mul(w5, {1 << i: Fr(1)}), A14.mul({1 << i: Fr(1)}, w5), -1) for i in range(5))
w4 = {15: Fr(1)}
rel = A14.mul(w4, w5)         # e4 should be -w4 w5
ok = cen and A14.add(e4, rel, 1) == {} 
cnt = 0
for _ in range(60):
    E, p1, p2, p3, m = [Fr(rng.randint(-5, 5)) for _ in range(5)]
    P = vec(A14, [E, p1, p2, p3, m]); s, rest = sq_scalar(A14, P)
    ok &= s == E * E - p1 * p1 - p2 * p2 - p3 * p3 - m * m and not rest
chk('G4c', ok, 'Cl(1,4) = M_2(H) + M_2(H) (centre w5 = e01234, w5^2 = +1): the fifth generator is e4 = -w4 w5, i.e. minus the 4D pseudoscalar times the central sign; the two simple factors (w5 = +1, -1) carry the two signs of the fibre momentum m, and a plane wave of fibre momentum m has the shell E^2 = |p|^2 + m^2')
# hyperbolicity of the total polynomial: a time direction h with P(h) > 0 and definite -h^perp.  signature (a plus, b minus) in total
def hyperbolic(npl, nmi): return min(npl, nmi) <= 1 and (npl, nmi) != (0, 0)
tab = []
for fp in range(0, 3):
    for fm in range(0, 3):
        tot_p, tot_m = 1 + fp, 3 + fm
        tab.append(((fp, fm), (tot_p, tot_m), hyperbolic(tot_p, tot_m)))
ok = all((h == (fp == 0)) for (fp, fm), (tp, tm), h in tab)
chk('G4d', ok, 'fibre of signature (fp,fm) added to Cl(1,3): the total quadratic form (1+fp, 3+fm) is hyperbolic (one time direction, real mass shells) exactly when fp = 0: ' + ', '.join(f'({fp},{fm}):' + ('hyp' if h else 'no') for (fp, fm), _, h in tab) + '; fibre directions that square +1 (a second time) are the excluded Cl(2,3), Cl(2,4), ... of finding F2, so a time-like extra direction breaks hyperbolicity (only space-like ones give real mass shells: the Kaluza-Klein statement)')

# =====================================================================================================================================================
# G5. The notes' chapter 20 (Floquet/Bloch).  The fundamental matrix over one period, M^E(a) = (psi1 psi2 ; psi1' psi2'), has det 1 (Lemma 20.8, Cor 20.9) and is a real 2x2 matrix: it is a unit multivector
#     of Cl(2,0) = M_2(R).  The scalar part is (1/2) Tr M = gamma_V(E) = cos(theta); bands are |gamma| <= 1.  Here: the sign of X^2 (X = non-scalar part) is the trio -1, 0, +1.
# =====================================================================================================================================================
A20 = Alg(sig(2, 0))
E1m = np.array([[1, 0], [0, -1.]]); E2m = np.array([[0, 1], [1, 0.]]); E12m = E1m @ E2m
def mv2mat(x): return x.get(0, 0) * np.eye(2) + x.get(1, 0) * E1m + x.get(2, 0) * E2m + x.get(3, 0) * E12m
def mat2mv(M):
    return {0: (M[0, 0] + M[1, 1]) / 2, 1: (M[0, 0] - M[1, 1]) / 2, 2: (M[0, 1] + M[1, 0]) / 2, 3: (M[0, 1] - M[1, 0]) / 2}
def Xpart(x): return {k: v for k, v in x.items() if k != 0}
def Xsq(x):
    y = A20.mul(Xpart(x), Xpart(x)); return y.get(0, 0.0), {k: v for k, v in y.items() if k != 0 and abs(v) > 1e-9}
rng = random.Random(55)
ok1 = ok2 = ok3 = True
for _ in range(80):
    x = {k: rng.uniform(-2, 2) for k in range(4)}; y = {k: rng.uniform(-2, 2) for k in range(4)}
    ok1 &= np.allclose(mv2mat(A20.mul(x, y)), mv2mat(x) @ mv2mat(y))
    ok2 &= abs(np.linalg.det(mv2mat(x)) - (x[0] ** 2 - x[1] ** 2 - x[2] ** 2 + x[3] ** 2)) < 1e-9 and abs(np.trace(mv2mat(x)) / 2 - x[0]) < 1e-12
    xs, rest = Xsq(x); ok3 &= not rest and abs(xs - (x[1] ** 2 + x[2] ** 2 - x[3] ** 2)) < 1e-9
chk('G5a', ok1 and ok2 and ok3, 'Cl(2,0) with e1 = diag(1,-1), e2 = [[0,1],[1,0]], e12 = [[0,1],[-1,0]] reproduces M_2(R): the bit-rule product equals the matrix product, (1/2) Tr M = scalar part, det M = a^2 - b^2 - c^2 + d^2, and for the non-scalar part X = b e1 + c e2 + d e12 the square is the scalar b^2 + c^2 - d^2 (80 random multivectors): so the SL(2,R) of Floquet theory is the unit multivectors of Cl(2,0)')
def step_mv(kap2, l):
    """transfer multivector over a flat piece of length l with k^2 = E - V = kap2"""
    if abs(kap2) < 1e-14: return mat2mv(np.array([[1, l], [0, 1.]]))
    if kap2 > 0:
        k = math.sqrt(kap2); M = np.array([[math.cos(k * l), math.sin(k * l) / k], [-k * math.sin(k * l), math.cos(k * l)]])
    else:
        q = math.sqrt(-kap2); M = np.array([[math.cosh(q * l), math.sinh(q * l) / q], [q * math.sinh(q * l), math.cosh(q * l)]])
    return mat2mv(M)
def cell_mv(E, cell):
    P = {0: 1.0}
    for (l, V) in cell: P = A20.mul(step_mv(E - V, l), P)
    return P
def rk4_cell(E, cell, nsteps=2000):
    Y = np.eye(2)         # columns: psi1, psi2 with (psi, psi') initial (1,0), (0,1)
    for (l, V) in cell:
        h = l / nsteps; f = lambda y: np.array([y[1], (V - E) * y[0]])
        for _ in range(nsteps):
            for c in range(2):
                y = Y[:, c]
                k1 = f(y); k2 = f(y + h / 2 * k1); k3 = f(y + h / 2 * k2); k4 = f(y + h * k3)
                Y[:, c] = y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
    return Y
ok = True; ok_w = True; worst = 0.0; slip = True; n_slip = 0
for _ in range(12):
    cell = [(rng.uniform(0.3, 1.2), rng.uniform(-2, 6)) for _ in range(rng.randint(2, 4))]; E = rng.uniform(-3, 12)
    Pm = mv2mat(cell_mv(E, cell)); Y = rk4_cell(E, cell, 1000)
    worst = max(worst, float(np.abs(Pm - Y).max() / (1 + np.abs(Y).max()))); ok &= worst < 1e-8
    ok_w &= abs(np.linalg.det(Y) - 1) < 1e-8
    n_slip += abs(Y[0, 0] + Y[0, 1] - np.trace(Y)) > 1e-6
    slip &= abs((Y[0, 0] + Y[1, 1]) / 2 - cell_mv(E, cell)[0]) < 1e-7
chk('G5b', ok and ok_w and slip and n_slip >= 1, f'piecewise-constant periodic potential (2-4 steps, random widths, heights, energy): the Clifford product of the step multivectors cos(kl) + sin(kl) n (n^2 = -1, E > V) or cosh + sinh n (n^2 = +1, E < V) equals the numerical (RK4) fundamental matrix of psi\'\' = (V - E) psi over one period, max relative difference {worst:.1e}; its determinant is 1 (Wronskian, Lemma 20.8) and (1/2)Tr M = psi1(a) + psi2\'(a) = scalar part. The notes write Tr M = psi1(a) + psi2(a); that differs from the trace in {n_slip} of 12 cases (psi1(a) + psi2\'(a) is the trace), so it is a slip of the transcript')
# n^2 = -1, +1 for the step pieces; the delta kick is the null element
def mv_sq_scalar(x): return Xsq(x)[0]
n_el = mv_sq_scalar(step_mv(2.3, 0.7)); n_hy = mv_sq_scalar(step_mv(-1.9, 0.7))
Mk = mat2mv(np.array([[1, 0], [1.7, 1.]])); n_kick = Xsq(Mk)[0]
chk('G5c', abs(n_el + math.sin(math.sqrt(2.3) * 0.7) ** 2) < 1e-9 and abs(n_hy - math.sinh(math.sqrt(1.9) * 0.7) ** 2) < 1e-9 and abs(n_kick) < 1e-12 and any(abs(v) > 1e-9 for v in Xpart(Mk).values()),
    'the three kinds of piece are the three kinds of element: free flight above the potential has X^2 = -sin^2 < 0 (elliptic, "i"), below it X^2 = +sinh^2 > 0 (hyperbolic, "e"), and a delta kick [[1,0],[g,1]] = 1 + g n has X^2 = 0 with X != 0 (null, parabolic, "dual unit"): squares -1, +1, 0, the trio of finding F3')
# classification of the whole cell by the sign of X^2
cnt = {'ell': 0, 'hyp': 0, 'par': 0}; ok = True; okT = True; okev = True
for _ in range(500):
    cell = [(rng.uniform(0.2, 1.5), rng.uniform(-3, 8)) for _ in range(rng.randint(1, 4))]; E = rng.uniform(-4, 14)
    P = cell_mv(E, cell); a = P[0] if 0 in P else 0.0; xs, _r = Xsq(P)
    ev = np.linalg.eigvals(mv2mat(P)); complex_ev = np.abs(ev.imag).max() > 1e-9
    if abs(a) < 1 - 1e-9: cnt['ell'] += 1; ok &= xs < 0 and complex_ev and abs(abs(ev[0]) - 1) < 1e-8
    elif abs(a) > 1 + 1e-9: cnt['hyp'] += 1; ok &= xs > 0 and not complex_ev and abs(ev[0] * ev[1] - 1) < 1e-8 * max(1, abs(a))
    # Chebyshev: scalar part of M^N = T_N(a) in every class
    Q = {0: 1.0}
    for N in range(1, 6):
        Q = A20.mul(Q, P)
        okT &= abs(Q.get(0, 0) - np.polynomial.chebyshev.chebval(a, [0] * N + [1])) < 1e-7 * max(1, abs(Q.get(0, 0)))
    okev &= abs(a * a + (xs if False else 0) - a * a) < 1e-12
chk('G5d', ok and okT and cnt['ell'] > 100 and cnt['hyp'] > 100, f'500 random potentials/energies: |(1/2)Tr M| < 1 (inside a band) holds exactly when X^2 < 0 and the multipliers are a conjugate pair on the unit circle (Floquet e^(+-i theta)); |(1/2)Tr M| > 1 (inside a gap) exactly when X^2 > 0 and the multipliers are real with product 1; counts: {cnt["ell"]} band points, {cnt["hyp"]} gap points; and the scalar part of M^N is the Chebyshev polynomial T_N((1/2)Tr M) in both cases: bands = elliptic, gaps = hyperbolic')
# band edges: bisection in E; at the edge X^2 = 0 (parabolic) and the multiplier is +-1
cell = [(0.8, 0.0), (0.5, 5.0)]
def gam(E): return cell_mv(E, cell)[0]
edges = []
Es = np.linspace(0.05, 90, 18000); prev = abs(gam(Es[0])) <= 1
for E0, E1_ in zip(Es[:-1], Es[1:]):
    cur = abs(gam(E1_)) <= 1
    if cur != prev:
        lo, hi = E0, E1_
        for _ in range(80):
            mid = (lo + hi) / 2
            if (abs(gam(mid)) <= 1) == prev: lo = mid
            else: hi = mid
        edges.append((lo + hi) / 2)
    prev = cur
ok = len(edges) >= 6
for Ee in edges:
    P = cell_mv(Ee, cell); xs, _r = Xsq(P); ok &= abs(xs) < 1e-7 and abs(abs(P[0]) - 1) < 1e-8 and sum(abs(v) for v in Xpart(P).values()) > 1e-4
chk('G5e', ok, f'one fixed two-step potential: {len(edges)} band edges found by bisection in E; at every one X^2 = 0 (to 1e-7) with X != 0 and (1/2)Tr M = +-1: the band edges are the parabolic points (periodic or antiperiodic solution, a Jordan block), the third member of the trio between band (-1) and gap (+1)')
# Dirac comb: free flight + delta kick: gamma = cos(kl) + g/(2k) sin(kl), the kick being the null element; thin-barrier limit
ok = True
for _ in range(30):
    l = rng.uniform(0.5, 2); g = rng.uniform(-3, 5); E = rng.uniform(0.1, 20); k = math.sqrt(E)
    P = A20.mul(mat2mv(np.array([[1, 0], [g, 1.]])), step_mv(E, l))
    ok &= abs(P[0] - (math.cos(k * l) + g / (2 * k) * math.sin(k * l))) < 1e-12
    w = 1e-6; Pb = A20.mul(step_mv(E - g / w, w), step_mv(E, l))
    ok &= abs(Pb[0] - P[0]) < 1e-3
chk('G5f', ok, 'Dirac comb (flight l, kick g): the scalar part of (1 + g n)(flight) is cos(kl) + (g/2k) sin(kl) exactly, and a thin tall barrier (width 1e-6, height g/width) reproduces it to 1e-3 (30 random cases): the textbook Kronig-Penney condition is the scalar part of a product of one null and one elliptic element')

# =====================================================================================================================================================
# G6. 24 = 3 x 8 at n = 2: the binary tetrahedral group 2T inside Cl(0,2) = H, as the three cosets Q8 u wQ8 u w^2Q8, w = (-1 + e1 + e2 + e12)/2 (order 3).
# =====================================================================================================================================================
A02 = Alg(sig(0, 2)); h = Fr(1, 2)
def mvk(a, b, c, d): return {k: Fr(v) for k, v in zip(range(4), (a, b, c, d)) if v != 0}
def key(x): return tuple(sorted(x.items()))
Q8 = {key(mvk(*[s * (1 if j == i else 0) for j in range(4)])): mvk(*[s * (1 if j == i else 0) for j in range(4)]) for i in range(4) for s in (1, -1)}
om = mvk(-h, h, h, h); om2 = A02.mul(om, om); om3 = A02.mul(om2, om)
cos1 = lambda S, g: {key(A02.mul(g, x)): A02.mul(g, x) for x in S.values()}
C0 = Q8; C1 = cos1(Q8, om); C2 = cos1(Q8, om2)
allk = set(C0) | set(C1) | set(C2)
# closure of <Q8, w>
G = dict(C0); frontier = list(G.values())
gens = list(Q8.values()) + [om]
while frontier:
    new = []
    for x in frontier:
        for g in gens:
            y = A02.mul(x, g)
            if key(y) not in G: G[key(y)] = y; new.append(y)
    frontier = new
half = [x for x in G.values() if all(abs(v) == h for v in x.values()) and len(x) == 4]
def nminus(x): return sum(1 for v in x.values() if v < 0)
par1 = {nminus(x) % 2 for x in C1.values()}; par2 = {nminus(x) % 2 for x in C2.values()}
ok = (om3 == {0: Fr(1)} and len(G) == 24 and len(C0) == len(C1) == len(C2) == 8 and len(allk) == 24 and set(G) == allk and len(half) == 16
      and len(par1) == 1 and len(par2) == 1 and par1 != par2)
chk('G6a', ok, f'Cl(0,2) = H: w = (-1 + e1 + e2 + e12)/2 has w^3 = 1; <Q8, w> has order {len(G)} = 24 = Q8 u wQ8 u w^2Q8 (three disjoint cosets of 8), the 16 elements with all four coefficients +-1/2 split 8+8 by the parity of the number of minus signs (wQ8: parity {sorted(par1)[0]}, w^2Q8: parity {sorted(par2)[0]}); the eight elements of Q8 have one nonzero coefficient')
winv = om2
cyc = {}
for lab in (1, 2, 3):
    x = A02.mul(A02.mul(om, {lab: Fr(1)}), winv)
    cyc[lab] = [k for k, v in x.items() if abs(v) == 1 and v > 0]
ok = cyc == {1: [3], 2: [1], 3: [2]}
chk('G6b', ok, 'conjugation by w permutes the three non-scalar blades cyclically (e1 -> e12 -> e2 -> e1, signs +) and fixes the identity: the order-3 automorphism of Q8 that makes 24 = 3 x 8; as bit labels 01 -> 11 -> 10 -> 01, a 3-cycle on the three non-zero elements of F_2^2 (a triality at n = 2)')
pts = sorted({tuple(float(x.get(k, 0)) for k in range(4)) for x in G.values()})
dots = lambda p, q: sum(a * b for a, b in zip(p, q))
ok = len(pts) == 24 and all(abs(dots(p, p) - 1) < 1e-12 for p in pts)
prof = {}
for p in pts:
    c = tuple(sorted(round(dots(p, q), 6) for q in pts))
    prof[c] = prof.get(c, 0) + 1
ok &= len(prof) == 1
prof_c = {}
for v in list(prof)[0]: prof_c[v] = prof_c.get(v, 0) + 1
chk('G6c', ok and prof_c == {-1.0: 1, -0.5: 8, 0.0: 6, 0.5: 8, 1.0: 1}, f'the 24 elements are 24 unit vectors in R^4 with the same inner-product profile at every vertex {dict(sorted(prof_c.items()))}: the 24-cell, 8 neighbours each (the Hurwitz units, the vertices of the 24-cell, the D4 root system up to scale)')

# =====================================================================================================================================================
# G7. The same 24 at n = 8: the Cartan weights of the three 8-dimensional representations of Spin(8) (vector, two spinors) computed from the real 16 x 16 matrices of G3,
#     and the F_2 counting 135 / 135 / 135 of the quadric O+(8,2).
# =====================================================================================================================================================
Hk = [0.5 * G8[2 * k] @ G8[2 * k + 1] for k in range(4)]
ok = all(np.allclose(Hk[i] @ Hk[j], Hk[j] @ Hk[i]) for i in range(4) for j in range(4)) and all(np.allclose(h_ @ h_, -0.25 * np.eye(16)) for h_ in Hk)
w_, Vv = np.linalg.eig(sum((1.0 + 0.37 * k * k + 0.11 * k) * Hk[k] for k in range(4)))
omega8 = prod(G8)
wts = []; ok_ch = True
for c in range(16):
    v = Vv[:, c]; wt = tuple(round(float(((v.conj() @ (Hk[k] @ v)) / (v.conj() @ v)).imag), 6) for k in range(4))
    wts.append(wt)
    parity_minus = sum(1 for t in wt if t < 0) % 2
    chir = ((v.conj() @ (omega8 @ v)) / (v.conj() @ v)).real
    ok_ch &= abs(chir - (1 if parity_minus == 0 else -1)) < 1e-8
spin_w = sorted(set(wts))
Vm = np.array([[np.trace(G8[a].T @ Hk[k] @ G8[b] - G8[a].T @ G8[b] @ Hk[k]) / 16 for b in range(8)] for a in range(8)] for k in range(4)) if False else None
vec_w = []
for k in range(4):
    adm = np.array([[np.trace(G8[a].T @ (Hk[k] @ G8[b] - G8[b] @ Hk[k])) / 16 for b in range(8)] for a in range(8)])
    vec_w.append(adm)
ww, vv = np.linalg.eig(sum((1.0 + 0.37 * k * k + 0.11 * k) * vec_w[k] for k in range(4)))
vecw = []
for c in range(8):
    v = vv[:, c]; vecw.append(tuple(round(float(((v.conj() @ (vec_w[k] @ v)) / (v.conj() @ v)).imag), 6) for k in range(4)))
vec_set = sorted(set(vecw))
ok &= len(spin_w) == 16 and len(vec_set) == 8 and all(abs(sum(t * t for t in wv) - 1) < 1e-9 for wv in spin_w + vec_set)
all24 = {tuple(round(2 * t) / 2 for t in wv) for wv in spin_w + vec_set}
pts24 = {tuple(round(float(x), 6) for x in p) for p in pts}
chk('G7a', ok and ok_ch and all24 == {tuple(round(x, 6) for x in p) for p in pts}, 'Cl(0,8) = M_16(R) on R^16, Cartan H_k = (1/2) gamma_(2k) gamma_(2k+1): the 16 joint weights of the spinor space are the 16 vectors (+-1/2)^4, the 8 weights of the vector (adjoint action on the 8 gamma) are +-e_k, and the 24 weight vectors are exactly the 24 elements of 2T of G6 as points of R^4: the 24-cell, three 16-cell-sized 8-sets')
ok = all(abs(((v.conj() @ (omega8 @ v)) / (v.conj() @ v)).real - (1 if sum(1 for t in wt if t < 0) % 2 == 0 else -1)) < 1e-8 for v, wt in zip([Vv[:, c] for c in range(16)], wts))
chk('G7b', ok and ok_ch, 'the chirality (eigenvalue of the top blade omega = e1...e8 = +-1) of a spinor weight is the parity of its number of minus signs: the same rule that separates wQ8 from w^2Q8 at n = 2 (G6a): the three 8-sets are vector (+-e_k), even spinor, odd spinor')
# three inequivalent 8-dim reps of so(8): characters at random group elements
def expm_series(B, terms=60):
    nB = max(1.0, np.abs(B).sum(axis=1).max()); s_ = int(math.ceil(math.log2(nB))) + 1
    Bs = B / (2 ** s_); T = np.eye(B.shape[0]); S = np.eye(B.shape[0])
    for k in range(1, terms): T = T @ Bs / k; S = S + T
    for _ in range(s_): S = S @ S
    return S
biv = [G8[i] @ G8[j] for i in range(8) for j in range(i)]
rr = random.Random(9); ok = True; sep = 0
Pp = (np.eye(16) + omega8) / 2; Pm_ = (np.eye(16) - omega8) / 2
closure_ok = all(np.allclose(omega8 @ b, b @ omega8) for b in biv)
for _ in range(6):
    B = sum(rr.uniform(-1, 1) * b for b in biv); g = expm_series(B)
    Rv = np.array([[np.trace(G8[a].T @ g @ G8[b] @ np.linalg.inv(g)) / 16 for b in range(8)] for a in range(8)])
    trV = np.trace(Rv); trS = np.trace(Pp @ g); trC = np.trace(Pm_ @ g)
    ok &= abs(np.linalg.det(Rv) - 1) < 1e-8 and np.allclose(Rv.T @ Rv, np.eye(8), atol=1e-8)
    if min(abs(trV - trS), abs(trV - trC), abs(trS - trC)) > 1e-3: sep += 1
chk('G7c', closure_ok and ok and sep == 6, 'the 28 bivectors gamma_i gamma_j (so(8)) commute with the chirality omega and map the 8 gamma among themselves: Spin(8) acts on the vector 8_v (as SO(8): orthogonal, det 1) and on the two chiral halves 8_s, 8_c of R^16; at 6 random group elements the three traces are pairwise different, so the three 8s are pairwise inequivalent although they have the same dimension: the 3 x 8')
# Triality inside the 24-cell: the Coxeter element of F4 (order 12); its 4th power (a 120-degree rotation of the Coxeter plane) permutes the three 8-sets cyclically
pts_cls = []
for wv in vec_set: pts_cls.append((tuple(round(float(t), 6) for t in wv), 'v'))
for wv in spin_w:
    pts_cls.append((tuple(round(float(t), 6) for t in wv), 'e' if sum(1 for t in wv if t < 0) % 2 == 0 else 'o'))
cls_of = {p: c_ for p, c_ in pts_cls}
f4 = [np.array(x) for x in [(0, 1, -1, 0), (0, 0, 1, -1), (0, 0, 0, 1), (.5, -.5, -.5, -.5)]]
refl = lambda r: np.eye(4) - 2 * np.outer(r, r) / (r @ r)
cox = refl(f4[0]) @ refl(f4[1]) @ refl(f4[2]) @ refl(f4[3])
try:
    ordc = next(k for k in range(1, 40) if np.allclose(np.linalg.matrix_power(cox, k), np.eye(4)))
    cw, cv = np.linalg.eig(cox)
    kk = [i for i in range(4) if abs(np.angle(cw[i]) - 2 * math.pi / 12) < 1e-6][0]
    ux = cv[:, kk].real; uy = cv[:, kk].imag; ux = ux / np.linalg.norm(ux); uy = uy - (uy @ ux) * ux; uy = uy / np.linalg.norm(uy)
    c4 = np.linalg.matrix_power(cox, 4)
    img = {}
    okp = True
    for p, c_ in pts_cls:
        q = tuple(round(float(t), 6) for t in c4 @ np.array(p))
        okp &= q in cls_of; img[c_] = img.get(c_, set()) | {cls_of.get(q)}
    exps = sorted(round(float(np.angle(z) / (2 * math.pi) * 12)) % 12 for z in cw)
    rings = {}
    for p, c_ in pts_cls:
        r_ = round(math.hypot(np.array(p) @ ux, np.array(p) @ uy), 3); rings.setdefault(r_, {}).setdefault(c_, 0); rings[r_][c_] += 1
    ok = (okp and ordc == 12 and exps == [1, 5, 7, 11] and img == {'v': {'o'}, 'e': {'v'}, 'o': {'e'}} and len(rings) == 2 and all(sum(d.values()) == 12 and set(d.values()) == {4} for d in rings.values()))
except (StopIteration, IndexError):
    ordc = 0; exps = []; rings = {0.0: {}}; ok = False
chk('G7e', ok, f'the Coxeter element of F4 has order {ordc} and exponents {exps}; its 4th power, a 120-degree rotation of the Coxeter plane, permutes the 24 weights and sends the vector 8 to the odd spinor 8, the even spinor 8 to the vector 8, the odd spinor 8 to the even spinor 8 (a 3-cycle of the three classes); in the Coxeter plane the 24 points lie on two rings of 12 (radii {", ".join(str(r_) for r_ in sorted(rings))}) with 4 points of each class on each ring: the triality is a rotation of the picture')
# F_2 quadric O+(2m,2)
def quad_counts(m):
    n = 2 * m
    def Q(x):
        r = 0
        for i in range(m): r ^= (x >> (2 * i) & 1) & (x >> (2 * i + 1) & 1)
        return r
    def Bf(x, y): return Q(x ^ y) ^ Q(x) ^ Q(y)
    pts_ = [x for x in range(1, 1 << n) if Q(x) == 0]
    return Q, Bf, pts_
res_m = {}
for m in (2, 3, 4):
    Q, Bf, ptsm = quad_counts(m)
    level = {frozenset([0, p]) for p in ptsm}; counts = [len(level)]
    while True:
        nxt = set()
        for W in level:
            basis = []
            span = {0}
            for w in sorted(W):
                if w not in span: basis.append(w); span |= {s ^ w for s in span}
            for v in ptsm:
                if v in W: continue
                if all(Bf(v, b) == 0 for b in basis): nxt.add(frozenset(W | {w ^ v for w in W}))
        if not nxt: break
        level = nxt; counts.append(len(level))
    top = list(level)
    res_m[m] = (len(ptsm), counts, top)
def fam(top):
    U0 = top[0]; A = [W for W in top if bin(len(U0 & W).bit_length() - 1).count('1') % 2 == 0 and ((len(U0 & W).bit_length() - 1) % 2 == 0)]
    return A
fams = {}
for m in (2, 3, 4):
    top = res_m[m][2]; dimtop = m; U0 = top[0]
    A = [W for W in top if ((len(U0 & W).bit_length() - 1) % 2) == (m % 2)]; B_ = [W for W in top if W not in A]
    fams[m] = (len(A), len(B_))
formula_pts = lambda m: (2 ** m - 1) * (2 ** (m - 1) + 1)
formula_fam = lambda m: math.prod(2 ** i + 1 for i in range(1, m))
ok = all(res_m[m][0] == formula_pts(m) and len(res_m[m][2]) == 2 * formula_fam(m) and fams[m] == (formula_fam(m), formula_fam(m)) for m in (2, 3, 4))
tri = [m for m in range(1, 13) if formula_pts(m) == formula_fam(m)]
inc = {}
for m in (4,):
    top = res_m[m][2]; U0 = top[0]
    A = [W for W in top if ((len(U0 & W).bit_length() - 1) % 2) == (m % 2)]; B_ = [W for W in top if W not in A]
    Q, Bf, ptsm = quad_counts(m)
    for name, F in (('A', A), ('B', B_)):
        per_pt = {p: sum(1 for W in F if p in W) for p in ptsm}; inc[name] = (set(per_pt.values()), {len([x for x in W if x]) for W in F})
ok &= inc['A'] == ({15}, {15}) and inc['B'] == ({15}, {15})
chk('G7d', ok and tri == [4], 'quadric Q = x1x2 + x3x4 + ... over F_2^(2m): m = 2, 3, 4 enumerated: singular points ' + ', '.join(f'm={m}: {res_m[m][0]}' for m in (2, 3, 4)) + '; maximal totally singular subspaces ' + ', '.join(f'm={m}: {len(res_m[m][2])} = 2 x {formula_fam(m)}' for m in (2, 3, 4)) + '; the number of points equals the number of solids of one family only for m = 4 (checked m = 1..12), where 135 = 135 = 135 and every point lies on 15 solids of each family and every solid has 15 points: the triality of O+(8,2) exists at n = 8 and at no other n')
# =====================================================================================================================================================
# G8. Stepping down the Gosset polytope 4_21 (240 roots of E8): links = common neighbours at inner product 1, and the orthogonal root systems E8 > E7 > E6 > D5 > A4 > A2+A1.
# =====================================================================================================================================================
roots = []
for i in range(8):
    for j in range(i + 1, 8):
        for si in (1, -1):
            for sj in (1, -1):
                v = [0] * 8; v[i] = 2 * si; v[j] = 2 * sj; roots.append(tuple(v))          # coordinates doubled
for signs in itertools.product((1, -1), repeat=8):
    if sum(1 for s_ in signs if s_ < 0) % 2 == 0: roots.append(tuple(signs))
R8 = np.array(roots)           # doubled coordinates: <r,s> = (r . s)/4
gram = (R8 @ R8.T) // 4
ok = len(roots) == 240 and set(np.diag(gram)) == {2} and set(np.unique(gram)) == {-2, -1, 0, 1, 2}
rowcount = {tuple(sorted(Counter_ for Counter_ in [int((gram[0] == v).sum()) for v in (-2, -1, 0, 1, 2)])): 1}
cn = [int((gram[0] == v).sum()) for v in (-2, -1, 0, 1, 2)]
chk('G8a', ok and cn == [1, 56, 126, 56, 1], 'E8 roots: 112 of type (+-1,+-1,0^6) and 128 of type (+-1/2)^8 with an even number of minus signs: 240, all norm 2, mutual inner products in {-2..2}; for any root: 1, 56, 126, 56, 1 roots at inner product -2, -1, 0, 1, 2 (240 = 126 + 2 x 56 + 2)')
# link ladder: common neighbours
def ladder(first_choices_exhaustive=3, seed=3):
    r = random.Random(seed); sizes_all = []
    def rec(S, depth, path):
        sizes_all.append((depth, len(S)))
        if depth >= 6 or len(S) == 0: return
        cand = list(S)
        if depth < first_choices_exhaustive: pick = cand
        else: pick = [cand[r.randrange(len(cand))]]
        for c in pick:
            rec([s_ for s_ in S if gram[s_, c] == 1], depth + 1, path + [c])
    rec(list(range(240)), 0, [])
    return sizes_all
allsz = ladder(1)      # exhaustive at the first level only (240 branches), random below
by = {}
for d, sz in allsz: by.setdefault(d, set()).add(sz)
want_by = {0: {240}, 1: {56}, 2: {27}, 3: {16}, 4: {10}, 5: {6}, 6: {3}}
# also exhaustive at the first two levels for 56 -> 27
ok2 = True
r1 = 0; S1 = [s_ for s_ in range(240) if gram[s_, r1] == 1]
ok2 &= len(S1) == 56 and all(len([s_ for s_ in S1 if gram[s_, c] == 1]) == 27 for c in S1)
chk('G8b', by == want_by and ok2, 'vertex-figure ladder of 4_21: the common neighbours (inner product 1) of a chain of mutually adjacent roots r1, r2, ...: ' + ' -> '.join(str(sorted(by[d])[0]) for d in range(7)) + ' (all 240 first choices, and all 56 second choices, give the same size; deeper levels sampled): 240, 56, 27, 16, 10, 6, 3 = the vertex counts of 4_21, 3_21, 2_21, 1_21, rectified 5-cell, triangular prism, and the 3 neighbours of a prism vertex; the last two steps of the tower (triangle 3, segment 2, point 1) are combinatorics of a polygon, not computed in the root coordinates')
# orthogonal root systems along a clique chain
rr2 = random.Random(5); chain = [0]
S = [s_ for s_ in range(240) if gram[s_, 0] == 1]; Rorth = [s_ for s_ in range(240) if gram[s_, 0] == 0]
rk = lambda idx: int(np.linalg.matrix_rank(R8[idx]) if len(idx) else 0)
orth_sizes = [240, len(Rorth)]; ranks = [8, rk(Rorth)]; link_sizes = [56]
cur_S = S; cur_R = Rorth
for step in range(2, 6):
    c = cur_S[rr2.randrange(len(cur_S))]
    cur_R = [s_ for s_ in cur_R if gram[s_, c] == 0]
    cur_S = [s_ for s_ in cur_S if gram[s_, c] == 1]
    orth_sizes.append(len(cur_R)); ranks.append(rk(cur_R)); link_sizes.append(len(cur_S))
want_orth = [240, 126, 72, 40, 20, 8]; want_rank = [8, 7, 6, 5, 4, 3]
ok = orth_sizes == want_orth and ranks == want_rank and link_sizes == [56, 27, 16, 10, 6]
diffs = [(want_orth[i] - want_orth[i + 1] - (2 if i == 0 else 0)) // 2 for i in range(5)]
chk('G8c', ok and diffs == [56, 27, 16, 10, 6], 'roots orthogonal to the span of the chain: ' + ', '.join(f'{n} (rank {k})' for n, k in zip(orth_sizes, ranks)) + ' = E8, E7, E6, D5, A4, A2+A1 (root counts and ranks), and each step is R_(j-1) = R_j + 2 x (link size) (+2 for the first): 240 = 126 + 2x56 + 2, 126 = 72 + 2x27, 72 = 40 + 2x16, 40 = 20 + 2x10, 20 = 8 + 2x6: the numbers 56, 27, 16, 10, 6 are at once the common-neighbour counts and the charge-separated pieces of the stabiliser chain')
# Golay code via Turyn from the extended Hamming code, and its blades in Cl(0,8k)
def ham_gen():
    rows = []
    for i in range(4):
        pass
    G_ = [[1, 1, 1, 1, 0, 0, 0, 0], [0, 0, 1, 1, 1, 1, 0, 0], [0, 0, 0, 0, 1, 1, 1, 1], [0, 1, 0, 1, 0, 1, 0, 1]]
    return [int(''.join(map(str, r)), 2) for r in G_]
def span_of(gens):
    S_ = {0}
    for g in gens: S_ |= {s_ ^ g for s_ in S_}
    return S_
Hm = span_of(ham_gen())
def permute_bits(x, perm): return sum(((x >> i) & 1) << perm[i] for i in range(8))
def golay_from(Hp):
    S_ = set()
    for a in Hm:
        for b in Hm:
            for x in Hp:
                S_.add(((a ^ x) << 16) | ((b ^ x) << 8) | (a ^ b ^ x))
    return S_
# the plain reversal of coordinates maps this H onto itself (it is reversal-symmetric), so H' must be another coordinate order: take the first permutation with H cap H' = {0, 1}
rev_same = {permute_bits(x, list(range(7, -1, -1))) for x in Hm} == Hm
perm_used = None
for perm in itertools.permutations(range(8)):
    Hp = {permute_bits(x, perm) for x in Hm}
    if len(Hm & Hp) == 2: perm_used = perm; Hm2 = Hp; break
inter = Hm & Hm2
Gol = golay_from(Hm2)
wd = {}
for x in Hm: wd[bin(x).count('1')] = wd.get(bin(x).count('1'), 0) + 1
wdG = {}
for c in Gol: wdG[bin(c).count('1')] = wdG.get(bin(c).count('1'), 0) + 1
chk('G9a', wd == {0: 1, 4: 14, 8: 1} and len(inter) == 2 and len(Gol) == 4096 and wdG == {0: 1, 8: 759, 12: 2576, 16: 759, 24: 1}, f'Turyn construction: three 8-bit bricks (a + x | b + x | a + b + x), a, b in the extended Hamming code H (weights {dict(sorted(wd.items()))}), x in a second copy H\' of it with the coordinates permuted so that H cap H\' = {{0, 1}} (the plain reversal fixes this particular H: {rev_same}): 4096 words of length 24, weights {dict(sorted(wdG.items()))}: the extended Golay code (759 octads)')
A8 = Alg(sig(0, 8)); ok = all(A8.sq(x) == 1 for x in Hm) and all(A8.comm_sign(a, b) == 1 for a in Hm for b in Hm if a and b)
A24 = Alg(sig(0, 24)); golb = sorted(Gol)
basis = []; spn = {0}
for c in golb:
    if c not in spn: basis.append(c); spn |= {s_ ^ c for s_ in spn}
ok24 = len(basis) == 12 and all(A24.sq(c) == 1 for c in golb) and all(A24.comm_sign(a, b) == 1 for a in basis for b in basis) and len(spn) == 4096
chk('G9b', ok and ok24, 'the blades labelled by the 16 Hamming words commute and square to +1 in Cl(0,8) = M_16(R), so they form a maximal split torus (16 sign patterns = the 16 coordinates of R^16); likewise the 4096 blades labelled by the Golay words in Cl(0,24) = M_4096(R) (12 independent generators commute, all squares +1): a doubly-even self-dual code is a maximal diagonalising set of blades, and its size is exactly the matrix size 2^(n/2)')
print()
print(f'fibre_check: {N_OK} ok, {N_BAD} failed')
sys.exit(1 if N_BAD else 0)
