#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Builds ../html/schuller_bridge_report.html: one self-contained page (inline CSS, SVG and a little JS, no external request).
Every number in it is read from logs/*.log (the checks) or computed from matrix_data.py (the matrix) or from the atlas engine (bitcliff); none is typed by hand,
except the sabotage counts of the first two scripts, which are recorded by hand in MUTANTS below (recorded by hand when run; not automated); the third script's sabotages are automated (mutate_fibre.py, logs/mutation_fibre.log).
Run: python3 build_report.py   (after python3 bridge_check.py > logs/bridge_check_final.log ; python3 bridge_check_qm.py > logs/bridge_check_qm_final.log ; python3 fibre_check.py > logs/fibre_check_final.log ; python3 mutate_fibre.py > logs/mutation_fibre.log)"""
import os, sys, re, math, html, itertools, datetime
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..'))      # the package this folder ships in: two levels up from reports/schuller/
sys.path.insert(0, os.path.join(PKG, 'selfcheck', 'steps15_17'))
from bitcliff import Alg, sig, pc, TYPES
sys.path.insert(0, HERE)
import matrix_data as MD
import fibre_section as FS
import status_chips as SC

E = html.escape
MUTANTS = {'bridge_check.py (by hand)': (6, 6), 'bridge_check_qm.py, Q5–Q12 (by hand)': (10, 10)}      # recorded by hand when run; not automated
TODAY = '7 October 2026'

# ------------------------------------------------------------------ the checks (from the logs)
def read_log(name):
    ok, bad, ids = 0, 0, []
    for line in open(os.path.join(HERE, 'logs', name), encoding='utf-8'):
        m = re.match(r'(ok  |FAIL) (\S+?):', line)
        if m:
            if m.group(1).startswith('ok'): ok += 1
            else: bad += 1
            ids.append(m.group(2))
    return ok, bad, ids
okA, badA, idsA = read_log('bridge_check_final.log')
okQ, badQ, idsQ = read_log('bridge_check_qm_final.log')
okG, badG, idsG = read_log('fibre_check_final.log')
TOTAL_OK, TOTAL_BAD = okA + okQ + okG, badA + badQ + badG
_m = re.search(r'mutants caught: (\d+) of (\d+)', open(os.path.join(HERE, 'logs', 'mutation_fibre.log'), encoding='utf-8').read())
MUTANTS['fibre_check.py and A6 of bridge_check.py (automated)'] = (int(_m.group(1)), int(_m.group(2)))
assert TOTAL_BAD == 0, 'a check fails: fix it before building the report'
def block(idl, pred): return sum(1 for i in idl if pred(i))
BLOCKS = [
    ('A', 'Wedge and Clifford: one table; Hodge star in the non-degenerate cells, the complement duality with a null generator', block(idsA, lambda i: i.startswith('A')), 'bridge_check.py'),
    ('B', 'Hyperbolicity filter, admissible cells, Dirac symbol, two metrics', block(idsA, lambda i: i.startswith('B')), 'bridge_check.py'),
    ('C', 'Deformation algebra: Witt ⊗ A_ε, Jacobi', block(idsA, lambda i: i.startswith('C')), 'bridge_check.py'),
    ('D', 'Area metric: octahedron, density, so(4) content', block(idsA, lambda i: i.startswith('D')), 'bridge_check.py'),
    ('E', 'Spin group, SL(2,ℂ) address, Casimir', block(idsA, lambda i: i.startswith('E')), 'bridge_check.py'),
    ('F', 'Dimension bookkeeping', block(idsA, lambda i: i.startswith('F')), 'bridge_check.py'),
    ('Q1–Q4', 'Pauli strings, Casimir by grade, graded tensor product, ℍ⊗ℍ (written from the contents list)', block(idsQ, lambda i: re.match(r'Q[1-4](?![0-9])', i)), 'bridge_check_qm.py'),
    ('Q5–Q7', 'Fock space Λ(ℝⁿ): Cl(n,n), Pauli exclusion, number operator (his §14.4, §21.4)', block(idsQ, lambda i: re.match(r'Q[5-7]', i)), 'bridge_check_qm.py'),
    ('Q8–Q9', 'Pauli spin algebra, Casimir 3/4; total spin and his Clebsch–Gordan formulas (§13, §15)', block(idsQ, lambda i: re.match(r'Q[89]', i)), 'bridge_check_qm.py'),
    ('Q10–Q12', 'Entanglement quadric; Dirac sign convention; Stern–Gerlach (§14.6, §21.3, §1)', block(idsQ, lambda i: re.match(r'Q1[0-2]', i)), 'bridge_check_qm.py'),
    ('G1–G2', 'Locally a product (label concatenation); left and right action = base and mirror fibre, Cl(n,n)', block(idsG, lambda i: re.match(r'G[12]', i)), 'fibre_check.py'),
    ('G3', 'n = 8 fixed: base 2^k, fibre 2^(8−k), explicit fibre generators, types follow the clock', block(idsG, lambda i: re.match(r'G3', i)), 'fibre_check.py'),
    ('G4', 'An extra direction’s momentum as a mass (Kaluza–Klein); pseudoscalar mass term; hyperbolic filter; the Dirac sign located', block(idsG, lambda i: re.match(r'G4', i)), 'fibre_check.py'),
    ('G5', 'Floquet/Bloch (his ch. 20): Cl(2,0) transfer matrix, bands = elliptic, edges = parabolic with X ≠ 0, gaps = hyperbolic', block(idsG, lambda i: re.match(r'G5', i)), 'fibre_check.py'),
    ('G6–G7', 'The 24 = 3 × 8: binary tetrahedral group, Spin(8) weights, Coxeter triality, quadric counts over F₂', block(idsG, lambda i: re.match(r'G[67]', i)), 'fibre_check.py'),
    ('G8–G9', 'E₈ roots: Gosset link ladder and orthogonal root systems; Hamming and Golay codes as diagonalising blades', block(idsG, lambda i: re.match(r'G[89]', i)), 'fibre_check.py'),
]
assert sum(b[2] for b in BLOCKS) == TOTAL_OK, (sum(b[2] for b in BLOCKS), TOTAL_OK)
MUT_OK = sum(a for a, b in MUTANTS.values()); MUT_ALL = sum(b for a, b in MUTANTS.values())
MUT_AUTO = MUTANTS['fibre_check.py and A6 of bridge_check.py (automated)'][1]; MUT_HAND = MUT_ALL - MUT_AUTO
assert MUT_OK == MUT_ALL, 'a sabotage was missed'
MUT_HAND_A, MUT_HAND_B = MUTANTS['bridge_check.py (by hand)'][1], MUTANTS['bridge_check_qm.py, Q5–Q12 (by hand)'][1]
_named = set(re.findall(r",\s*'([A-Z]\d+[a-z]?)'\)\s*,?\s*(?:#.*)?$", open(os.path.join(HERE, 'mutate_fibre.py'), encoding='utf-8').read(), re.M))      # the checks that a mutant of mutate_fibre.py names
NFIBNAMED = len(_named & set(idsG)); assert NFIBNAMED == len(_named) and 'A6' in open(os.path.join(HERE, 'mutate_fibre.py'), encoding='utf-8').read()

# ------------------------------------------------------------------ the matrix
ST = MD.stats()
ROWS, COLS = MD.ROWS, MD.COLS
GRADE_WORD = {'E': 'exact', 'S': 'structural', 'A': 'analogy'}
GRADE_LONG = {'E': 'Exact: the same object or identity; a check computes it',
              'S': 'Structural: the same structure in another generality, or a standard fact the atlas uses',
              'A': 'Analogy: a reading we propose (ours); nothing computes that it is the same'}
best = ST['best']; nrows = ST['n']; ncells = ST['total_cells']; cellg = ST['cellg']
SRC_NAME = {'L': 'Lectures on the Geometric Anatomy of Theoretical Physics (2013/14)', 'C': 'Gravitational closure of matter field equations, and the review “Constructive Gravity”', 'Q': 'Lectures on Quantum Theory (2015), read in part'}
SRC_N = {s: sum(1 for r in ROWS if r[1] == s) for s in 'LCQ'}
GAP_ROWS = [r for r in ROWS if not r[3]]

def tip(*lines): return E('\n'.join(lines), quote=True)

def matrix_html():
    keys = [c[0] for c in COLS]
    bands = [('pages 1–2', 2), ('step 1', 1), ('pages 4–5', 2), ('steps 2–16', 15), ('page 7', 1), ('step 17', 1)]
    out = ['<div class="mxwrap" role="group" aria-label="Translation matrix, rows are objects in Schuller\'s work, columns are atlas pages and steps"><div class="mx">']
    out.append('<div class="mx-corner"></div>')
    for name, span in bands:
        out.append(f'<div class="mx-band" style="grid-column: span {span}">{name}</div>')
    out.append('<div class="mx-corner2">row</div>')
    for k, short, long_, page in COLS:
        out.append(f'<div class="mx-ch" title="{E(long_)}"><span>{E(short)}</span></div>')
    cur = None
    for rid, src, title, cells in ROWS:
        if src != cur:
            cur = src
            out.append(f'<div class="mx-grp" style="grid-column: 1 / -1">{E(SRC_NAME[src])} <b>· {SRC_N[src]} rows</b></div>')
        gap = not cells
        lab = f'<span class="rid">{rid}</span> {E(title)}'
        if gap: lab = '<span class="pill gap">gap</span> ' + lab
        out.append(f'<div class="rl{" gaprow" if gap else ""}" title="{E(title)}">{lab}</div>')
        for k, short, long_, page in COLS:
            if k in cells:
                g, note = cells[k]
                t = tip(f'{rid}  {title}', f'× {long_} ({page})', f'{GRADE_WORD[g].capitalize()} ({g})', note)
                out.append(f'<div class="c g-{g}" tabindex="0" data-tip="{t}" aria-label="{E(rid)} by {E(short)}: {GRADE_WORD[g]}">{g}</div>')
            else:
                out.append('<div class="c z"></div>')
    out.append('</div></div>')
    # table view
    rows = []
    for rid, src, title, cells in ROWS:
        if not cells:
            rows.append(f'<tr><td>{rid}</td><td>{E(title)}</td><td colspan="3"><i>gap: no counterpart in the atlas</i></td></tr>')
        for k, short, long_, page in COLS:
            if k in cells:
                g, note = cells[k]
                rows.append(f'<tr><td>{rid}</td><td>{E(title)}</td><td>{E(long_)}</td><td>{g} {GRADE_WORD[g]}</td><td>{E(note)}</td></tr>')
    out.append('<details class="tv"><summary>Table view of the same matrix (%d filled cells and %d gap rows)</summary><div class="tvscroll"><table><thead><tr><th>Row</th><th>Object in his work</th><th>Atlas column</th><th>Grade</th><th>What matches</th></tr></thead><tbody>%s</tbody></table></div></details>' % (ncells, len(GAP_ROWS), ''.join(rows)))
    return '\n'.join(out)

def coverage_svg():
    # (a) rows by best grade, per source: stacked horizontal bars (viewBox ~ the width it is shown at, so text stays 12 px)
    W, H = 500, 150; x0, scale = 112, 17
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Rows by best grade for each source" class="chart">']
    y = 10
    for s_ in 'LCQ':
        lab = {'L': 'Geometric Anatomy', 'C': 'Closure and review', 'Q': 'Quantum Theory'}[s_]
        parts.append(f'<text x="0" y="{y + 14}" class="t">{lab}</text><text x="0" y="{y + 28}" class="t2">{SRC_N[s_]} rows</text>')
        x = x0; summ = []
        for g in ('E', 'S', 'A', 'gap'):
            n = ST['bysrc'][s_].get(g, 0)
            if not n: continue
            w = n * scale
            cls = f'sv-{g}' if g != 'gap' else 'sv-gap'
            tipt = f'{lab}: {n} rows, best grade {GRADE_WORD.get(g, "none (gap)")}'
            parts.append(f'<rect x="{x + 1}" y="{y}" width="{w - 2}" height="30" rx="3" class="{cls}" data-tip="{E(tipt, quote=True)}" tabindex="0"/>')
            txt = (g if g != 'gap' else '–') + ('' if w < 30 else f' {n}')
            parts.append(f'<text x="{x + w / 2}" y="{y + 20}" text-anchor="middle" class="bar-{g}">{txt}</text>')
            summ.append(f'{g if g != "gap" else "gap"} {n}')
            x += w
        y += 44
    parts.append('</svg>')
    leg = '<div class="legend"><span><i class="sw g-E">E</i> exact</span><span><i class="sw g-S">S</i> structural</span><span><i class="sw g-A">A</i> analogy</span><span><i class="sw gapsw">–</i> gap (no counterpart)</span></div>'
    # (b) cells per atlas column
    cnt = {k: sum(ST['col'][k].values()) for k, *_ in COLS}
    order = sorted(cnt, key=lambda k: (-cnt[k], [c[0] for c in COLS].index(k)))
    bh = 18; H2 = bh * len(order) + 8; xl = 78; sc = 22
    p2 = [f'<svg viewBox="0 0 440 {H2}" role="img" aria-label="Filled cells per atlas column" class="chart">']
    long_of = {c[0]: c[2] for c in COLS}
    for i, k in enumerate(order):
        y = 3 + i * bh
        short = [c[1] for c in COLS if c[0] == k][0]
        p2.append(f'<text x="{xl - 8}" y="{y + 12}" text-anchor="end" class="t">{E(short)}</text>')
        x = xl
        for g in ('E', 'S', 'A'):
            n = ST['col'][k].get(g, 0)
            if not n: continue
            w = n * sc / 2
            p2.append(f'<rect x="{x + 1}" y="{y}" width="{max(w - 2, 2)}" height="14" rx="2" class="sv-{g}" data-tip="{E(f"{long_of[k]}: {n} {GRADE_WORD[g]} cell(s)", quote=True)}" tabindex="0"/>')
            x += w
        p2.append(f'<text x="{x + 5}" y="{y + 12}" class="t2">{cnt[k]}</text>')
    p2.append('</svg>')
    return '<div class="figcols"><div><div class="figtitle">Rows by their best grade</div>' + ''.join(parts) + leg + '</div><div><div class="figtitle">Filled cells per atlas column</div>' + ''.join(p2) + '<div class="cap2">Bar length = number of cells, split by grade. The atlas pages touched most are the cells atlas, the spin step, Maxwell, the commutators and Dirac: the places where the atlas is closest to the algebra both courses use.</div></div></div>'

def signtables_html():
    names = ['1', 'e₁', 'e₂', 'e₁₂']
    out = []
    for title, eps in [('ε = (0, 0): exterior algebra Λ(ℝ²), Cl(0,0,2)', sig(0, 0, 2)), ('ε = (+1, +1): Cl(2,0)', sig(2, 0)), ('ε = (−1, −1): Cl(0,2) = ℍ', sig(0, 2))]:
        al = Alg(eps)
        t = ['<table class="st"><thead><tr><th></th>' + ''.join(f'<th>{n}</th>' for n in names) + '</tr></thead><tbody>']
        for a in range(4):
            t.append(f'<tr><th>{names[a]}</th>')
            for b in range(4):
                s, c = al.blade_mul(a, b)
                if s == 0: t.append('<td class="zero">0</td>')
                else: t.append(f'<td class="{"neg" if s < 0 else "pos"}" data-tip="{E(names[a] + " · " + names[b] + " = " + ("−" if s < 0 else "+") + names[c], quote=True)}" tabindex="0">{"−" if s < 0 else "+"}{names[c]}</td>')
            t.append('</tr>')
        t.append('</tbody></table>')
        out.append(f'<div class="stbox"><div class="stt">{title}</div>{"".join(t)}</div>')
    return '<div class="stgrid">' + ''.join(out) + '</div>'

def kd_grid_svg():
    cell = 46; ox, oy = 62, 40
    nmax = 7
    parts = [f'<svg viewBox="0 0 {ox + 7 * cell + 20} {oy + 7 * cell + 34}" role="img" aria-label="Wave type of the quadratic form of Cl(k,d), for k+d up to 7" class="chart">']
    parts.append(f'<text x="{ox + 3.5 * cell}" y="14" text-anchor="middle" class="t2">d = number of generators squaring to −1</text>')
    parts.append(f'<text x="14" y="{oy + 3.5 * cell}" text-anchor="middle" class="t2" transform="rotate(-90 14 {oy + 3.5 * cell})">k = number squaring to +1</text>')
    for d in range(7): parts.append(f'<text x="{ox + d * cell + cell / 2}" y="{oy - 6}" text-anchor="middle" class="t">{d}</text>')
    for k in range(7): parts.append(f'<text x="{ox - 8}" y="{oy + k * cell + cell / 2 + 4}" text-anchor="end" class="t">{k}</text>')
    for k in range(7):
        for d in range(7):
            n = k + d
            if n < 2 or n > nmax: continue
            m = min(k, d); typ = TYPES[(k - d) % 8].replace('2', '²')
            wt = 'elliptic' if m == 0 else ('hyperbolic' if m == 1 else 'ultrahyperbolic')
            letter = {'elliptic': 'e', 'hyperbolic': 'H', 'ultrahyperbolic': 'u'}[wt]
            cls = 'kd-h' if m == 1 else 'kd-o'
            x = ox + d * cell; y = oy + k * cell
            t = tip(f'Cl({k},{d}), n = {n}', f'cell [{n},{k - d}], clock {(k - d) % 8}, type {typ}', f'wave type: {wt}', 'admitted by hyperbolicity' if m == 1 else 'excluded by hyperbolicity')
            extra = ''
            if (k, d) == (2, 2): extra = f'<rect x="{x + 2}" y="{y + 2}" width="{cell - 4}" height="{cell - 4}" rx="4" class="kd-ring"/>'
            parts.append(f'<g data-tip="{t}" tabindex="0"><rect x="{x + 1}" y="{y + 1}" width="{cell - 2}" height="{cell - 2}" rx="4" class="{cls}"/>{extra}<text x="{x + cell / 2}" y="{y + cell / 2 + 5}" text-anchor="middle" class="{"kd-hl" if m == 1 else "kd-ol"}">{letter}</text></g>')
            if (k, d) in ((1, 3), (3, 1)):
                parts.append(f'<text x="{x + cell - 7}" y="{y + 12}" text-anchor="end" class="star">★</text>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span><i class="sw kd-h">H</i> hyperbolic: min(k,d) = 1, admitted</span><span><i class="sw kd-o">e</i> elliptic (min 0)</span><span><i class="sw kd-o">u</i> ultrahyperbolic (min ≥ 2)</span>'
           '<span><i class="sw ring">◻</i> Cl(2,2): the first ultrahyperbolic cell</span><span>★ Dirac: the notes’ Cl(3,1) and the atlas’s Cl(1,3)</span></div>')
    return '<div class="figcenter">' + ''.join(parts) + leg + '</div>'

def octa_svg():
    S = 120; cx, cy = 210, 175; yaw, pit = 0.62, 0.42
    def proj(x, y, z):
        c, s = math.cos(yaw), math.sin(yaw); x1 = c * x + s * z; z1 = -s * x + c * z
        c2, s2 = math.cos(pit), math.sin(pit); y1 = c2 * y - s2 * z1; z2 = s2 * y + c2 * z1
        return cx + S * x1, cy - S * y1, z2
    V = {'e12': (1, 0, 0), 'e34': (-1, 0, 0), 'e13': (0, 1, 0), 'e24': (0, -1, 0), 'e14': (0, 0, 1), 'e23': (0, 0, -1)}
    P = {k: proj(*v) for k, v in V.items()}
    anti = {('e12', 'e34'), ('e13', 'e24'), ('e14', 'e23')}
    names = list(V)
    edges = [(a, b) for a, b in itertools.combinations(names, 2) if (a, b) not in anti and (b, a) not in anti]
    assert len(edges) == 12
    parts = ['<svg viewBox="0 0 420 350" role="img" aria-label="The six coordinate planes of four-dimensional space as the vertices of an octahedron" class="chart">']
    for a, b in edges:
        d = (P[a][2] + P[b][2]) / 2
        parts.append(f'<line x1="{P[a][0]:.1f}" y1="{P[a][1]:.1f}" x2="{P[b][0]:.1f}" y2="{P[b][1]:.1f}" class="oc-edge" style="opacity:{0.9 if d > -0.05 else 0.4}" data-tip="{E(a + " and " + b + " share one index: an adjacent pair (12 of them)", quote=True)}"/>')
    ax = [(('e12', 'e34'), '(+)', 'G₁₂,₃₄'), (('e13', 'e24'), '(−)', 'G₁₃,₂₄'), (('e14', 'e23'), '(+)', 'G₁₄,₂₃')]
    for (a, b), sgn, comp in ax:
        parts.append(f'<line x1="{P[a][0]:.1f}" y1="{P[a][1]:.1f}" x2="{P[b][0]:.1f}" y2="{P[b][1]:.1f}" class="oc-axis" data-tip="{E(f"{a} and {b} are disjoint planes: they commute; the component {comp} enters ε·G with sign {sgn[1]}", quote=True)}"/>')
    for k in names:
        x, y, z = P[k]
        parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="17" class="oc-v" data-tip="{E(k + ": a coordinate plane; its pair with itself is a diagonal component G_" + k[1:] + "," + k[1:], quote=True)}" tabindex="0"/><text x="{x:.1f}" y="{y + 4:.1f}" text-anchor="middle" class="oc-l">{k}</text>')
    # axis annotations
    parts.append('<text x="12" y="22" class="t2">three axes, signs in ε·G:</text>')
    for i, ((a, b), sgn, comp) in enumerate(ax):
        parts.append(f'<text x="12" y="{40 + 16 * i}" class="t">{comp} {sgn}</text>')
    parts.append('</svg>')
    return ''.join(parts)

def clock_svg():
    cx, cy, R, r = 260, 200, 112, 62
    parts = ['<svg viewBox="-80 0 680 400" role="img" aria-label="The eight-fold clock of real Clifford algebras with the cells that appear in the lectures" class="chart">']
    for c in range(8):
        a0 = -math.pi / 2 + c * math.pi / 4 - math.pi / 8; a1 = a0 + math.pi / 4
        x0, y0, x1, y1 = cx + R * math.cos(a0), cy + R * math.sin(a0), cx + R * math.cos(a1), cy + R * math.sin(a1)
        x2, y2, x3, y3 = cx + r * math.cos(a1), cy + r * math.sin(a1), cx + r * math.cos(a0), cy + r * math.sin(a0)
        parts.append(f'<path d="M{x0:.1f},{y0:.1f} A{R},{R} 0 0 1 {x1:.1f},{y1:.1f} L{x2:.1f},{y2:.1f} A{r},{r} 0 0 0 {x3:.1f},{y3:.1f} Z" class="ck-sec"/>')
        am = (a0 + a1) / 2; rm = (R + r) / 2
        t = TYPES[c].replace('2', '²')
        parts.append(f'<text x="{cx + rm * math.cos(am):.1f}" y="{cy + rm * math.sin(am) + 2:.1f}" text-anchor="middle" class="ck-t">{t}</text><text x="{cx + rm * math.cos(am):.1f}" y="{cy + rm * math.sin(am) + 15:.1f}" text-anchor="middle" class="t2">c={c}</text>')
    marks = [
        (0, 'Cl(n,n) = M₂ⁿ(ℝ): Fock cells', 'and Cl(0,8) = End(V) = M₁₆(ℝ)', 'E'),
        (2, 'Cl(3,1) = M₄(ℝ)', 'the notes’ Dirac signs', 'E'),
        (3, 'Cl(3,0) = M₂(ℂ)', 'Pauli spin algebra', 'E'),
        (6, 'Cl(1,3) = M₂(ℍ)', 'atlas’s Dirac; SU(2) in Cl(0,2)', 'E'),
        (7, 'Cl(1,2) = Cl⁰(1,3) = M₂(ℂ)', 'SL(2,ℂ), spin group', 'E'),
    ]
    for c, l1, l2, g in marks:
        am = -math.pi / 2 + c * math.pi / 4
        px, py = cx + (R + 14) * math.cos(am), cy + (R + 14) * math.sin(am)
        lx, ly = cx + (R + 34) * math.cos(am), cy + (R + 34) * math.sin(am)
        anchor = 'start' if math.cos(am) > 0.2 else ('end' if math.cos(am) < -0.2 else 'middle')
        dx = 6 if anchor == 'start' else (-6 if anchor == 'end' else 0)
        parts.append(f'<line x1="{cx + R * math.cos(am):.1f}" y1="{cy + R * math.sin(am):.1f}" x2="{px:.1f}" y2="{py:.1f}" class="ck-ln"/><circle cx="{px:.1f}" cy="{py:.1f}" r="5" class="sv-E"/>')
        yy = ly + (6 if math.sin(am) > 0.5 else (-14 if math.sin(am) < -0.5 else 0))
        parts.append(f'<text x="{lx + dx:.1f}" y="{yy:.1f}" text-anchor="{anchor}" class="t ckb">{E(l1)}</text><text x="{lx + dx:.1f}" y="{yy + 16:.1f}" text-anchor="{anchor}" class="t2 ckb2">{E(l2)}</text>')
    parts.append(f'<text x="{cx}" y="{cy - 4}" text-anchor="middle" class="t2">c = p − q</text><text x="{cx}" y="{cy + 12}" text-anchor="middle" class="t2">mod 8</text>')
    parts.append('</svg>')
    return ''.join(parts)

def cube_svg():
    S = 92; ox, oy = 70, 190
    def P(b): return ox + S * ((b & 1) + 0.55 * ((b >> 2) & 1)), oy - S * (((b >> 1) & 1) + 0.38 * ((b >> 2) & 1))
    parts = ['<svg viewBox="0 0 330 250" role="img" aria-label="The eight bit labels of three fermionic modes as the vertices of a cube, shaded by particle number" class="chart">']
    for a in range(8):
        for k in range(3):
            b = a ^ (1 << k)
            if a < b: parts.append(f'<line x1="{P(a)[0]:.1f}" y1="{P(a)[1]:.1f}" x2="{P(b)[0]:.1f}" y2="{P(b)[1]:.1f}" class="oc-edge" style="opacity:0.8"/>')
    for a in range(8):
        n = pc(a); x, y = P(a); cls = ['cb-0', 'sv-A', 'sv-S', 'sv-E'][n]; ink = ['bar-0', 'bar-A', 'bar-S', 'bar-E'][n]
        lab = format(a, '03b')
        parts.append(f'<g data-tip="{E(f"occupation pattern {lab} (bits k3 k2 k1): N = {n} particle(s)", quote=True)}" tabindex="0"><circle cx="{x:.1f}" cy="{y:.1f}" r="16" class="{cls}"/><text x="{x:.1f}" y="{y + 5:.1f}" text-anchor="middle" class="{ink}">{n}</text><text x="{x:.1f}" y="{y + 30:.1f}" text-anchor="middle" class="t2">{lab}</text></g>')
    parts.append('</svg>')
    leg = '<div class="legend"><span>Number inside = N = popcount of the label = grade</span><span>N = 0, 1, 2, 3 holds 1, 3, 3, 1 states</span></div>'
    return '<div class="figcenter">' + ''.join(parts) + leg + '</div>'

def pauli_grid():
    I2 = np.eye(2, dtype=complex); X = np.array([[0, 1], [1, 0]], dtype=complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1., -1]).astype(complex)
    P = {'I': I2, 'X': X, 'Y': Y, 'Z': Z}
    def kron(*ms):
        o = np.eye(1, dtype=complex)
        for m in ms: o = np.kron(o, m)
        return o
    gs = []
    for k in range(2):
        for Pm in (X, Y): gs.append(kron(*([Z] * k + [Pm] + [I2] * (2 - k - 1))))
    al = Alg(sig(4, 0)); cell = {}
    for a in range(16):
        M = np.eye(4, dtype=complex)
        for i in range(4):
            if a >> i & 1: M = M @ gs[i]
        for s in itertools.product('IXYZ', repeat=2):
            Pm = kron(*[P[c] for c in s]); ph = np.trace(Pm.conj().T @ M) / 4
            if abs(abs(ph) - 1) < 1e-9 and np.allclose(M, ph * Pm): cell[s] = (a, ph, al.sq(a))
    assert len(cell) == 16
    herm = sum(1 for v in cell.values() if v[2] == 1)
    out = ['<div class="pg"><div class="pgh"></div>' + ''.join(f'<div class="pgh">{c}</div>' for c in 'IXYZ')]
    for r in 'IXYZ':
        out.append(f'<div class="pgh">{r}</div>')
        for c in 'IXYZ':
            a, ph, sq = cell[(r, c)]
            idx = ''.join(str(i + 1) for i in range(4) if a >> i & 1) or '∅'
            phs = {1: '+1', -1: '−1', 1j: '+i', -1j: '−i'}[complex(round(ph.real), round(ph.imag)) if abs(ph.imag) > 0.5 else round(ph.real)]
            t = tip(f'Pauli string {r}{c}', f'blade e_{idx}' if idx != '∅' else 'the scalar 1', f'matrix = {phs} × {r}{c}', f'blade squares to {"+1: Hermitian" if sq == 1 else "−1: anti-Hermitian"}')
            out.append(f'<div class="pgc {"herm" if sq == 1 else "anti"}" tabindex="0" data-tip="{t}"><b>{r}{c}</b><small>e<sub>{idx}</sub></small></div>')
    out.append('</div>')
    return ''.join(out), herm

def pipeline_html():
    cols = [
        ('Matter action', 'S[A; G)', 'Steps 4, 7, 8: Dirac, Yang–Mills, charged matter, each a polynomial in the rule', 'S', ''),
        ('Principal polynomial', 'highest-order symbol, reduced (§II.C after eq. 18)', 'The 8×8 Dirac symbol has |det| = (p²)⁴; reduced polynomial p²', 'E', 'B4'),
        ('Three conditions', 'hyperbolic, dual hyperbolic, energy-distinguishing', 'First condition, quadratic P: E (T18 (f)): the Lorentzian cells Cl(1,d) and Cl(k,1) pass, one class in two conventions; Cl(2,2) is the first ultrahyperbolic cell. Third condition (energy-distinguishing): a gap', 'E', 'B1–B3'),
        ('Observers', 'cones, Legendre map, particle actions', 'Charges tab: u·u conserved; raindrop observers (step 12)', 'S', ''),
        ('Foliation', 'lapse, shift, induced geometry', 'Painlevé–Gullstrand slicing, unit lapse and a shift (step 12)', 'S', ''),
        ('Deformation algebra', 'eqs. (48)–(50), structure functions', 'Frozen flat 1+1 model: Witt ⊗ A_ε, ε = −1, 0, +1', 'S', 'C1–C6'),
        ('Closure equations', 'linear PDEs → Einstein–Hilbert, (κ, Λ)', 'The atlas starts from the Einstein form (step 10); Λ’s sign read as −s·κ² (ours; neither confirmed nor refuted by his equations). The derivation is not rebuilt', 'A', 'C7, C8'),
    ]
    out = ['<div class="pipe">']
    for i, (a, b, c, g, ids) in enumerate(cols):
        out.append(f'<div class="pcol"><div class="pt"><span class="pn">{i + 1}</span><b>{E(a)}</b><small>{E(b)}</small></div>'
                   f'<div class="pg-g g-{g}" title="{GRADE_WORD[g]}">{g}</div>'
                   f'<div class="pa">{E(c)}{(" <span class=ids>" + ids + "</span>") if ids else ""}</div></div>')
    out.append('</div>')
    out.append('<div class="legend"><span>top: Schuller’s step · middle: grade of the link · bottom: what the atlas has there (check ids in grey)</span></div>')
    return ''.join(out)

def chip(kind): return SC.chip(kind)      # a status is an icon chip: the word is its aria-label and title, never visible

CHECKS_TABLE = ''.join(f'<tr><td><b>{E(b[0])}</b></td><td>{E(b[1])}</td><td class="num">{b[2]}</td><td>{E(b[3])}</td></tr>' for b in BLOCKS)
MUT_TABLE = ''.join(f'<tr><td>{E(k)}</td><td class="num">{a} of {b}</td></tr>' for k, (a, b) in MUTANTS.items())
SIGNS = signtables_html()
KD = kd_grid_svg()
OCTA = octa_svg()
CLOCK = clock_svg()
CUBE = cube_svg()
PGRID, NHERM = pauli_grid()
PIPE = pipeline_html()
MATRIX = matrix_html()
COVER = coverage_svg()

bestE, bestS, bestA, bestG = best.get('E', 0), best.get('S', 0), best.get('A', 0), best.get('gap', 0)
assert bestE + bestS + bestA + bestG == nrows

CSS = r'''
:root{--bg:#fcfcfb;--surf:#ffffff;--ink:#1a1a19;--ink2:#46463f;--muted:#6b6b64;--line:#e3e2dc;--line2:#c9c8c0;--tint:#f3f2ee;
 --e:#184f95;--s:#3987e5;--a:#86b6ef;--e-ink:#ffffff;--s-ink:#0b0b0b;--a-ink:#0b0b0b;--acc:#184f95;
 --chk:#34d399;--std:#60a5fa;--ours:#fbbf24;--open:#f87171;--shadow:0 1px 2px rgba(0,0,0,.06),0 4px 14px rgba(0,0,0,.05)}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#1a1a19;--surf:#232322;--ink:#f1f0ec;--ink2:#cfcec7;--muted:#9a998f;--line:#35352f;--line2:#4a4a43;--tint:#2a2a28;
 --e:#9ec5f4;--s:#3987e5;--a:#184f95;--e-ink:#0b0b0b;--s-ink:#0b0b0b;--a-ink:#ffffff;--acc:#9ec5f4;--shadow:0 1px 2px rgba(0,0,0,.4)}}
:root[data-theme="dark"]{--bg:#1a1a19;--surf:#232322;--ink:#f1f0ec;--ink2:#cfcec7;--muted:#9a998f;--line:#35352f;--line2:#4a4a43;--tint:#2a2a28;
 --e:#9ec5f4;--s:#3987e5;--a:#184f95;--e-ink:#0b0b0b;--s-ink:#0b0b0b;--a-ink:#ffffff;--acc:#9ec5f4;--shadow:0 1px 2px rgba(0,0,0,.4)}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;-webkit-text-size-adjust:100%}
a{color:var(--acc)}
.wrap{max-width:1080px;margin:0 auto;padding:0 16px}
header.hero{padding:34px 0 8px}
.kick{display:inline-block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);border:1px solid var(--line2);border-radius:999px;padding:3px 10px}
h1{font-size:clamp(28px,5vw,44px);line-height:1.1;margin:12px 0 8px;letter-spacing:-.01em}
.sub{color:var(--ink2);max-width:760px;margin:0 0 18px;font-size:17px}
.notice{background:var(--tint);border:1px solid var(--line2);border-left:4px solid var(--ours);border-radius:8px;padding:10px 14px;margin:14px 0;font-size:14.5px}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}
.kpi{background:var(--surf);border:1px solid var(--line);border-radius:12px;padding:12px 14px;box-shadow:var(--shadow)}
.kpi b{display:block;font-size:30px;line-height:1.1;letter-spacing:-.01em}.kpi span{font-size:13px;color:var(--muted)}
nav.toc{position:sticky;top:0;z-index:5;background:color-mix(in srgb,var(--bg) 92%,transparent);backdrop-filter:blur(6px);border-bottom:1px solid var(--line);margin:14px 0 0}
nav.toc .wrap{display:flex;flex-wrap:wrap;gap:4px 14px;padding-top:8px;padding-bottom:8px;font-size:13.5px;align-items:center}
nav.toc a{text-decoration:none;color:var(--ink2)}nav.toc a:hover{color:var(--acc);text-decoration:underline}
nav.toc button{margin-left:auto;font:inherit;font-size:12.5px;border:1px solid var(--line2);background:var(--surf);color:var(--ink2);border-radius:999px;padding:3px 10px;cursor:pointer}
section{padding:26px 0 6px}
h2{font-size:24px;margin:0 0 6px;letter-spacing:-.005em}h2 small{font-weight:400;color:var(--muted);font-size:14px;margin-left:8px}
h3{font-size:17px;margin:0 0 4px}
p{margin:8px 0}.lead{font-size:17px;color:var(--ink2);max-width:820px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}.grid2>*,.grid3>*,.fbody>*,.figcols>*{min-width:0}.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.card{background:var(--surf);border:1px solid var(--line);border-radius:12px;padding:14px 16px;box-shadow:var(--shadow)}
.card p{font-size:15px}
.pill{font-size:10.5px;text-transform:uppercase;letter-spacing:.05em;border:1px solid var(--line2);border-radius:4px;padding:0 5px;margin-right:4px;color:var(--ink2)}
.pill.gap{border-color:var(--open)}
.finding{margin:16px 0;background:var(--surf);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);overflow:hidden}
.fhead{padding:14px 18px 6px;border-bottom:1px solid var(--line)}.fhead .fid{display:inline-block;background:var(--e);color:var(--e-ink);font-weight:700;border-radius:6px;padding:0 8px;margin-right:8px;font-size:14px}
.fhead h3{display:inline;font-size:19px}.fhead .chips{margin:8px 0 6px}
.fbody{display:grid;grid-template-columns:1.1fr 1fr;gap:18px;padding:12px 18px 16px;align-items:start}
.fbody.one{grid-template-columns:1fr}
.fbody p,.fbody li{font-size:15px}.fbody ul{margin:6px 0;padding-left:20px}
.not{color:var(--ink2);border-left:3px solid var(--line2);padding-left:10px;font-size:14px}
.ids{font-size:11.5px;color:var(--muted);font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
.fig{margin:0}.fig figcaption{font-size:13px;color:var(--muted);margin-top:6px}
.figtitle{font-weight:600;font-size:14px;margin-bottom:4px}
svg.chart{width:100%;height:auto;display:block}
svg .t{fill:var(--ink);font:12px system-ui,sans-serif}svg .t2{fill:var(--muted);font:11px system-ui,sans-serif}
.sv-E{fill:var(--e)}.sv-S{fill:var(--s)}.sv-A{fill:var(--a)}.sv-gap{fill:var(--bg);stroke:var(--line2);stroke-dasharray:4 3}
svg .bar-E{fill:var(--e-ink);font:600 12px system-ui}svg .bar-S{fill:var(--s-ink);font:600 12px system-ui}svg .bar-A{fill:var(--a-ink);font:600 12px system-ui}svg .bar-gap{fill:var(--muted);font:600 12px system-ui}svg .bar-0{fill:var(--ink);font:600 12px system-ui}
.cb-0{fill:var(--surf);stroke:var(--ink2);stroke-width:1.5}
svg rect[data-tip]:hover,svg g[data-tip]:hover rect,svg rect[tabindex]:focus{stroke:var(--ink);stroke-width:1.5}
.g-E{background:var(--e);color:var(--e-ink)}.g-S{background:var(--s);color:var(--s-ink)}.g-A{background:var(--a);color:var(--a-ink)}
.legend{display:flex;flex-wrap:wrap;gap:6px 16px;font-size:12.5px;color:var(--ink2);margin:8px 0 2px;align-items:center}
.legend .sw{display:inline-block;min-width:22px;height:20px;line-height:20px;text-align:center;border-radius:4px;font-style:normal;font-weight:700;font-size:12px;margin-right:5px;vertical-align:middle;padding:0 4px}
.gapsw{border:1px dashed var(--line2);color:var(--muted)}
.figcols{display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start}
.cap2{font-size:12.5px;color:var(--muted)}
.figcenter{max-width:540px;margin:0 auto}
/* pipeline */
.pipe{display:grid;grid-template-columns:repeat(7,1fr);gap:8px}
.pcol{display:flex;flex-direction:column;align-items:stretch;gap:6px}
.pt{background:var(--tint);border:1px solid var(--line);border-radius:10px;padding:8px 8px 8px;min-height:132px;font-size:12.5px;line-height:1.3}
.pt b{display:block;font-size:13.5px;margin:3px 0}.pt small{color:var(--muted);font-size:11.5px}
.pn{display:inline-block;width:20px;height:20px;line-height:20px;text-align:center;border-radius:50%;background:var(--ink);color:var(--bg);font-size:11px;font-weight:700}
.pg-g{align-self:center;width:34px;height:26px;line-height:26px;text-align:center;border-radius:6px;font-weight:700;position:relative}
.pg-g::before{content:"";position:absolute;left:50%;top:-8px;height:8px;border-left:2px solid var(--line2)}
.pa{background:var(--surf);border:1px solid var(--line);border-radius:10px;padding:8px;font-size:12.5px;line-height:1.35;flex:1}
/* matrix */
.mxwrap{overflow-x:auto;border:1px solid var(--line);border-radius:12px;background:var(--surf);padding:8px 8px 10px;max-width:100%}
.mx{display:grid;grid-template-columns:310px repeat(22,26px);column-gap:2px;row-gap:2px;width:max-content;align-items:stretch}
.mx-band{font-size:11px;color:var(--muted);text-align:center;border-bottom:2px solid var(--line2);padding-bottom:2px}
.mx-corner{grid-column:1}.mx-corner2{font-size:11px;color:var(--muted);align-self:end;padding-left:4px}
.mx-ch{height:62px;position:relative;font-size:11px;color:var(--ink2)}
.mx-ch span{position:absolute;left:50%;bottom:2px;transform:translateX(-50%) rotate(-60deg);transform-origin:left bottom;white-space:nowrap;margin-left:-4px}
.mx-grp{font-size:12.5px;font-weight:600;background:var(--tint);border-radius:6px;padding:3px 8px;margin-top:8px;position:sticky;left:0;width:min(100%,900px)}
.rl{font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:22px;line-height:22px;position:sticky;left:0;background:var(--surf);z-index:1;padding-right:6px;color:var(--ink2)}
.rl .rid{display:inline-block;min-width:26px;font-weight:700;color:var(--ink)}.gaprow{color:var(--ink)}
.c{height:22px;line-height:22px;text-align:center;border-radius:4px;font-size:11.5px;font-weight:700;cursor:default}
.c.z{background:var(--tint)}
.c[tabindex]:hover,.c[tabindex]:focus{outline:2px solid var(--ink);outline-offset:0}
.tv{margin-top:10px}.tv summary{cursor:pointer;font-size:14px;color:var(--ink2)}
.tvscroll{max-height:420px;overflow:auto;border:1px solid var(--line);border-radius:8px;margin-top:6px}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:5px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{background:var(--tint);position:sticky;top:0}
td.num{text-align:right;font-variant-numeric:tabular-nums}
/* sign tables */
.stgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.stbox .stt{font-size:12px;color:var(--ink2);margin-bottom:3px;min-height:34px}
table.st{font-size:12.5px;table-layout:fixed}table.st th,table.st td{text-align:center;padding:3px 2px;border:1px solid var(--line)}
table.st td.neg{background:var(--a);color:var(--a-ink);font-weight:700}table.st td.pos{background:var(--surf)}table.st td.zero{background:var(--tint);color:var(--muted)}
/* kd grid */
.kd-h{fill:var(--e)}.kd-o{fill:var(--tint);stroke:var(--line2)}.kd-hl{fill:var(--e-ink);font:700 15px system-ui}.kd-ol{fill:var(--muted);font:600 14px system-ui}.kd-ring{fill:none;stroke:var(--ink);stroke-width:2;stroke-dasharray:4 3}.star{fill:var(--ours);font-size:13px}
.legend .sw.kd-h{background:var(--e);color:var(--e-ink)}.legend .sw.kd-o{background:var(--tint);color:var(--muted);border:1px solid var(--line2)}.legend .sw.ring{border:2px dashed var(--ink);color:var(--ink)}
/* octahedron, clock */
.oc-edge{stroke:var(--line2);stroke-width:1.5}.oc-axis{stroke:var(--ink);stroke-width:2;stroke-dasharray:6 4}.oc-v{fill:var(--s)}.oc-l{fill:var(--s-ink);font:700 11px system-ui}
.ckb{font-size:15px!important}.ckb2{font-size:13px!important}.ck-sec{fill:var(--tint);stroke:var(--line2)}.ck-t{fill:var(--ink);font:700 17px system-ui}.ck-ln{stroke:var(--line2)}
/* pauli grid */
.pg{display:grid;grid-template-columns:28px repeat(4,1fr);gap:3px;max-width:380px;margin:0 auto}
.pgh{text-align:center;font-weight:700;font-size:13px;color:var(--ink2);align-self:center}
.pgc{border-radius:6px;padding:4px 2px;text-align:center;font-size:12.5px;line-height:1.2;border:1.5px solid var(--e)}
.pgc.herm{background:var(--s);color:var(--s-ink)}.pgc.anti{background:var(--surf);color:var(--ink)}
.pgc small{display:block;font-size:10.5px;opacity:.85}
/* lists */
.lens{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
.lens .card h3{font-size:15.5px}.lens .card p{margin:3px 0;font-size:14px}
.todo li{margin:4px 0}ul.tight{margin:6px 0;padding-left:20px}ul.tight li{margin:3px 0;font-size:15px}
.spec{border:1px dashed var(--line2);border-radius:12px;padding:12px 16px;background:var(--surf)}
pre{background:var(--tint);border:1px solid var(--line);border-radius:8px;padding:10px 12px;overflow:auto;font-size:12.5px}
code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.92em}
footer{padding:30px 0 50px;color:var(--muted);font-size:13px}
#tip{position:fixed;z-index:50;pointer-events:none;background:var(--ink);color:var(--bg);border-radius:8px;padding:7px 10px;font-size:12.5px;line-height:1.35;max-width:340px;white-space:pre-line;box-shadow:0 6px 24px rgba(0,0,0,.25);opacity:0;transition:opacity .08s}
#tip.on{opacity:1}
/* fibre and base */
.ds-b{fill:var(--e)}.ds-f{fill:var(--s)}svg .ds-bt{fill:var(--e-ink);font:600 12px system-ui}svg .ds-ft{fill:var(--s-ink);font:600 12px system-ui}
.bd-shade{fill:var(--s);opacity:.22}.bd-shade:hover,.bd-shade:focus{opacity:.38;outline:none}.bd-curve{fill:none;stroke:var(--e);stroke-width:2}.bd-ref{stroke:var(--line2);stroke-dasharray:4 3}.bd-ax{stroke:var(--ink2);stroke-width:1}
.bd-edge{fill:var(--ours);stroke:var(--ink);stroke-width:1.2}.bd-edge:hover,.bd-edge:focus{stroke-width:2.5;outline:none}
.c24-edge{stroke:var(--line2);stroke-width:1}.c24-v{fill:var(--e);stroke:var(--surf);stroke-width:1.5}.c24-e{fill:var(--s);stroke:var(--ink);stroke-width:1}.c24-o{fill:var(--ours);stroke:var(--ink);stroke-width:1}
.c24-v:hover,.c24-e:hover,.c24-o:hover,.c24-v:focus,.c24-e:focus,.c24-o:focus{stroke:var(--ink);stroke-width:2.5;outline:none}
svg.fx .t{font:13px system-ui,sans-serif}svg.fx .t2{font:12.5px system-ui,sans-serif}svg.fx .ds-bt,svg.fx .ds-ft{font:600 13px system-ui}
table.gs{font-size:12.5px}table.gs td,table.gs th{padding:4px 7px}table.gs tr.hl td{background:var(--tint);font-weight:700}
.gs-n{display:inline-block;min-width:34px;font-variant-numeric:tabular-nums;font-weight:600}.gs-bar{display:inline-block;height:9px;border-radius:3px;background:var(--s);vertical-align:middle}.gs-bar2{background:var(--e)}
.aa{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:6px}.aa>div{border:1px solid var(--line2);border-radius:10px;padding:8px 10px;text-align:center;font-size:13px;line-height:1.35;background:var(--tint)}
.aa>.aa-x,.aa>.aa-eq{border:0;background:none;font-size:20px;padding:0 2px}.aa span{color:var(--ink2);font-size:12.5px}
@media (max-width:860px){nav.toc{position:static}.kpis{grid-template-columns:repeat(2,1fr)}.fbody,.grid2,.lens,.figcols{grid-template-columns:1fr}.pipe{grid-template-columns:1fr}.pt{min-height:0}.pg-g{align-self:flex-start}.grid3{grid-template-columns:1fr}.stgrid{grid-template-columns:1fr}}
@media (max-width:480px){h2{font-size:21px}.kpi b{font-size:24px}.mx{grid-template-columns:200px repeat(22,26px)}}
''' + SC.CSS

JS = r'''
(function(){
 var tip=document.getElementById('tip');
 function show(el,x,y){var t=el.getAttribute('data-tip');if(!t)return;tip.textContent=t;tip.classList.add('on');var w=tip.offsetWidth,h=tip.offsetHeight;var nx=Math.min(x+14,window.innerWidth-w-8),ny=y+16;if(ny+h>window.innerHeight-8)ny=y-h-12;tip.style.left=Math.max(8,nx)+'px';tip.style.top=Math.max(8,ny)+'px';}
 function hide(){tip.classList.remove('on');}
 document.addEventListener('mouseover',function(e){var el=e.target.closest('[data-tip]');if(el)show(el,e.clientX,e.clientY);else hide();});
 document.addEventListener('mousemove',function(e){var el=e.target.closest('[data-tip]');if(el&&tip.classList.contains('on'))show(el,e.clientX,e.clientY);});
 document.addEventListener('focusin',function(e){var el=e.target.closest('[data-tip]');if(el){var r=el.getBoundingClientRect();show(el,r.left+r.width/2,r.bottom);}});
 document.addEventListener('focusout',hide);document.addEventListener('scroll',hide,true);document.addEventListener('keydown',function(e){if(e.key==='Escape')hide();});
 var b=document.getElementById('themebtn');
 if(b){var modes=['auto','light','dark'],i=0;b.addEventListener('click',function(){i=(i+1)%3;var m=modes[i];if(m==='auto')document.documentElement.removeAttribute('data-theme');else document.documentElement.setAttribute('data-theme',m);b.textContent='theme: '+m;});}
})();
'''

def finding(fid, title, chips, left, right='', one=False):
    cls = 'fbody one' if (one or not right) else 'fbody'
    ch = ''.join(chip(c) for c in chips)
    return (f'<article class="finding" id="{fid.lower()}"><div class="fhead"><span class="fid">{fid}</span><h3>{title}</h3><div class="chips">{ch}</div></div>'
            f'<div class="{cls}"><div>{left}</div>{("<div>" + right + "</div>") if right else ""}</div></article>')

F1 = finding('F1', 'Wedge and Clifford share one multiplication table', ['checked', 'standard'],
 '<p>In the bit rule the product of two blades is <code>e<sub>a</sub> e<sub>b</sub> = s(a,b) e<sub>a⊕b</sub></code>. The sign is the reorder sign times the product of the squares of the generators the two blades share. Set every square to 0 and this is the exterior algebra of his chapter 12 (his theorem 12.8 sign included). Set them to ±1 and it is Cl(p,q). The labels, the XOR and the reorder sign never change: only one factor does.</p>'
 '<p>His Hodge star is multiplication by the pseudoscalar, which on labels is XOR with 11…1, and the square of the pseudoscalar is the sign of the form: in the non-degenerate cells (A5: Cl(1,3), Cl(4,0), Cl(2,2), Cl(3,1)). With a null generator the top blade is nilpotent, so multiplication by it kills every label with a null bit and is not a metric Hodge star; the complement map XOR with 11…1 is then the Frobenius duality of the top-blade form, non-degenerate for every signature (A6; category report N3; proved for all n in T3).</p>'
 '<p class="not">What this is not: a new theorem (Clifford algebra as the deformed wedge is classical). The geometry lecture notes go from forms and the Hodge star (ch. 12) to SL(2,ℂ) (ch. 15) without naming a Clifford algebra (a text search of the four documents finds the word nowhere); that a Clifford chapter would fit between them is our reading.</p>'
 '<p class="ids">checks A1–A6: Grassmann = Cl(0,0,n) for n ≤ 6; the product formula in every signature n ≤ 6; Hodge = multiplication by the pseudoscalar = XOR 1…1 and I² in four non-degenerate cells (A5); the nilpotent top blade and the complement duality with a null generator (A6).</p>',
 '<div class="figtitle">The same four labels, three choices of squares (n = 2)</div>' + SIGNS + '<figcaption>Each table is the product of the row blade by the column blade. Shaded = sign −. Grey 0 = the null squares of the exterior algebra kill the product. Hover a cell for the full product.</figcaption>')

F2 = finding('F2', 'Hyperbolicity filters the cells: only the Lorentzian ones pass', ['checked', 'standard'],
 '<p>Take the quadratic form of a cell Cl(k,d) as a principal polynomial P(k) = Σ ε<sub>i</sub>k<sub>i</sub>². A direction h is hyperbolic when the quadratic polynomial q ↦ B(q,h)² − P(h)P(q) is non-negative: that happens exactly when the signature is (1, n−1) or (n−1, 1). So elliptic cells (min(k,d) = 0) and ultrahyperbolic cells (min ≥ 2) fail. The admitted cells are Cl(1,d) and Cl(k,1), found by direct search for every (k,d) with n = 2…7: one Lorentzian class in two conventions, P ↔ −P. P cannot tell the two apart; the algebras can: Cl(1,3) = M₂(ℍ), Cl(3,1) = M₄(ℝ). Cl(2,2) is the first ultrahyperbolic cell. Domain: quadratic P without null generators (r = 0); a non-degenerate quadratic P is hyperbolic iff it is Lorentzian (T18 (f)). With r ≥ 1 null generators a hyperbolic direction exists iff k = 1 or d = 1, and never a strict one: every null covector gives a double root (bd·geo·8, every r with n ≤ 6; bd·xck·5, the smallest case Cl(1,1,1)).</p>'
 '<p>The Dirac field passes through the same filter: the real 8×8 symbol has |det| = (p²)⁴, so the reduced polynomial (closure paper §II.C after eq. 18: drop repeated factors) is p². Two metrics G, H give the symmetrised product (G·k)(H·k), his bimetric polynomial.</p>'
 '<p class="not">Standard: that the filter returns the Lorentzian signature is his own conclusion for the metric case. What the atlas adds is only the phrasing as a map of cells, and that the Maxwell page’s wave-type table is this filter (checks B1–B3).</p>'
 '<p class="ids">checks B1–B5; bridge checks (selfcheck/bridges/) bd·geo·8, bd·xck·5.</p>',
 '<div class="figtitle">Wave type of Cl(k,d), n = k + d from 2 to 7</div>' + KD + '<figcaption>Hover or focus a cell for its address [R,C], clock and type. Letters carry the class as well as the colour.</figcaption>')

F3 = finding('F3', 'One trio, four places: −1, 0, +1', ['checked', 'standard', 'ours'],
 '<p>His hypersurface deformation algebra (48)–(50) has structure <em>functions</em>. In a frozen model (flat 1+1, a constant c = (deg P − 1)p<sup>11</sup>, a lapse of weight −1) it becomes Witt ⊗ A<sub>ε</sub>, where A<sub>ε</sub> = ℝ[h]/(h² = ε) is the one-generator Clifford algebra: Cl(0,1) = ℂ for ε = −1, Cl(0,0,1) = dual numbers for ε = 0, Cl(1,0) = split-complex for ε = +1. Witt ⊗ A<sub>ε</sub> is a Lie algebra by construction: A<sub>ε</sub> is commutative, so the cyclic sum of the double brackets is the Jacobi sum of Witt times the symmetric product uvw; the Jacobi identity recomputed for all modes |j| ≤ 3 (C1) is a regression test, and the content is the reduction itself (C2–C6). For ε = +1 the algebra is Witt ⊕ Witt (E<sub>±</sub> = (D ± H)/2), with the central term Vir ⊕ Vir, two commuting Virasoro algebras (bd·str·14, bd·phy·13). For ε = 0 it is BMS₃, with [M,M] = 0 and central charges (c<sub>L</sub>, c<sub>M</sub>) (bd·str·14), isomorphic to the 2d Galilean conformal algebra (Bagchi, arXiv:1006.3354); BMS is the conformal extension of the Carroll group (Duval, Gibbons, Horvathy, arXiv:1402.5894), so in 2d “Carroll” and “Galilei” are one algebra. For ε = −1 it is Witt ⊗ ℂ (calling it Euclidean is ours).</p>'
 '<p>The same trio {−1, 0, +1} is already in the atlas in four places (table). Putting them side by side is our reading; each column is computed in its own check.</p>'
 '<p class="not">Limits: this is the frozen model, not his algebra, which has phase-space-dependent structure functions. We also found that with a <em>scalar</em> lapse and a constant structure function Jacobi fails (residual 36): that is why (48) needs a structure function. The identification “Lorentz = ε = +1” by light-cone splitting, with the two Virasoro copies as the left and right movers of a closed string (a textbook picture; pointer, source unread), is ours, and so is the name Euclid for ε = −1: this is the frozen 1+1 model, not his (48)–(50), and whether those have such a family for d &gt; 1 is open (P3).</p>'
 '<p class="ids">checks C1–C6; bridge checks (selfcheck/bridges/) bd·str·14, bd·phy·13.</p>',
 '<div class="figtitle">The unit square u² picks the geometry</div>'
 '<table class="trio"><thead><tr><th></th><th>−1</th><th>0</th><th>+1</th></tr></thead><tbody>'
 '<tr><th>flow of a bivector (steps 1, 15)</th><td>cos t: rotation</td><td>1 + tB: a line</td><td>cosh t: boost</td></tr>'
 '<tr><th>A<sub>ε</sub> in the frozen algebra</th><td>ℂ → Witt ⊗ ℂ</td><td>dual → BMS₃ = GCA₂</td><td>split → Witt ⊕ Witt</td></tr>'
 '<tr><th>extra generator s, Lorentz base (step 11)</th><td>de Sitter</td><td>Poincaré</td><td>anti-de Sitter</td></tr>'
 '<tr><th>tube algebra Cl(T,−1,−1) (step 13)</th><td>so(3)</td><td>iso(2)</td><td>so(1,2)</td></tr>'
 '<tr><th>signature of the plane (names ours)</th><td>Euclid</td><td>Carroll-like</td><td>light cone</td></tr>'
 '</tbody></table><figcaption>Columns are the sign of the square. In the atlas the tags are checked (each row) and ours (reading them as one trio).</figcaption>')

F4 = finding('F4', 'The area metric is an octahedron: 6 + 12 + 3 = 21', ['checked', 'standard', 'open'],
 '<p>General linear electrodynamics with a constitutive law from a Lagrangian has the area metric G<sup>abcd</sup>: 21 independent components, the symmetric pairs of the six coordinate planes of a 4-space. A general local linear medium has 36, 20 principal, 15 skewon and 1 axion (Jancewicz, arXiv:0807.2989), and the axion part does not enter the wave operator (bd·sol·14). Put the planes e<sub>12</sub> … e<sub>34</sub> on the vertices of an octahedron. The 6 vertices are a plane paired with itself, the 12 edges are two planes sharing one index, the 3 antipodal pairs are disjoint planes, which commute.</p>'
 '<p>His density needs ε<sup>ijkl</sup>G<sub>ijkl</sub> = 8 (G<sub>01,23</sub> − G<sub>02,13</sub> + G<sub>03,12</sub>): it touches the three antipodal axes only. The η∧η part of his background G = 2η<sup>a[c</sup>η<sup>d]b</sup> − ε<sup>abcd</sup> contributes 0, so |ε·G| = 24 comes from the −ε term. One Bianchi condition removes this single combination: 21 − 1 = 20 = Ricci 10 + Weyl 10, the same 20 as the atlas’s n²(n²−1)/12 at n = 4 (standard counting: D3 evaluates this arithmetic and builds no space of curvature tensors). Under so(4) the 21 split as 5 + 5 + 9 + 1 + 1 (the two 5s are the self-dual and anti-self-dual Weyl parts). This is a Euclidean so(4) count, while his area metrics are Lorentzian: under so(1,3) the two Weyl 5s are complex conjugates of each other and do not split over ℝ (standard). The 6 + 12 + 3 split itself depends on the chosen frame of ℝ⁴.</p>'
 '<p class="not">Open: whether the eleven or more integration constants of his closure of general linear electrodynamics organise along this 6 + 12 + 3 split. We have not tried; it is a question, not a result.</p>'
 '<p class="ids">checks D1–D8; bridge check (selfcheck/bridges/) bd·sol·14.</p>',
 '<div class="figtitle">The six coordinate planes of ℝ⁴</div>' + OCTA + '<figcaption>Solid grey edges: adjacent planes (12). Dashed axes: commuting disjoint pairs (3), labelled with their sign in ε·G. Hover for the pair.</figcaption>')

F5 = finding('F5', 'Where SL(2,ℂ) lives, and the 3/4 of both lecture courses', ['checked', 'standard'],
 '<p>The even part of Cl(1,3) is Cl(1,2) ≅ M₂(ℂ), the cell [3,−1] at clock 7, type ℂ. Its centre is {1, e<sub>1234</sub>} with e<sub>1234</sub>² = −1, and the unit even versors are generated by the six bivectors: that is SL(2,ℂ), the spin group of his chapter 15, with an address on the atlas. SU(2) sits in Cl(0,2) = ℍ at [2,−2]. Cl(1,3) itself is at [4,−2], clock 6, type ℍ.</p>'
 '<p>The Casimir of the spin representation, Σ<sub>a&lt;b</sub>(e<sup>ab</sup>/2)(e<sub>ab</sub>/2) with the indices raised, equals −C(n,2)/4 in every signature without null generators (r = 0; E4). At n = 3 it is −3/4; minus it is the 3/4 = dim 𝔤 / dim V of the geometry lecture notes (Example 17.13), and the quantum notes’ Ω = ΣS<sub>i</sub>² = j(j+1) = 3/4 at j = ½ with the Pauli spin algebra S<sub>i</sub> = σ<sub>i</sub>/2 (Example 13.6, Proposition 13.9). In the bit rule S<sub>i</sub> = e<sub>i</sub>/2 in Cl(3,0) with e<sub>123</sub> playing the part of i: Cl(3,0) = M₂(ℂ).</p>'
 '<p class="ids">checks E1–E5, Q8a–c.</p>',
 '<div class="figtitle">The eight-fold clock and the cells in the lectures</div>' + CLOCK + '<figcaption>c = p − q mod 8; sector letters are the standard type table. The dots are cells that appear in the lecture notes; every one is computed.</figcaption>')

F6 = finding('F6', 'Matter first, gravity second: where the atlas starts', ['checked', 'ours', 'open'],
 '<p>His pipeline (Fig. 1) derives gravity from matter: the matter action gives a principal polynomial, three conditions filter it, observers and a foliation give the induced geometry, and the closure of the deformation algebra gives linear PDEs whose solution, for Klein–Gordon or the standard model, is Einstein–Hilbert with two integration constants (κ, Λ). The atlas runs the other way: its steps 9 and 10 take the tetrad, the curvature and the Einstein form as given and check them (exact for n = 3, 4, 5, polynomial fields, one chart).</p>'
 '<p>So the overlap is the front (step 2 structural, steps 4 and 6 exact for the first condition; the third condition is a gap) and a frozen caricature of the middle (step 9: structural). The back half, the closure equations and the action principle, is not rebuilt and the atlas has no action principle. One reading connects the ends: the sign class of Λ is read as −s·κ², with s the square of the extra generator of step 11. That is ours, and neither confirmed nor refuted by his equations.</p>'
 '<p class="not">We read his closure paper only in parts (§II.C, §III.B, §V.A–B, the abstract and contents) and the review for its framing. We did not re-derive any closure equation.</p>',
 '<div class="figtitle">See Fig. 1 above</div><p style="font-size:14px;color:var(--ink2)">Grades along his pipeline: S, E, E, S, S, S, A (as in Fig. 1). The grade falls as one moves from the algebraic front (what a quadratic form allows) to the global back (what dynamics closes): a measure of where a fibre-level, finite-combinatorics atlas can follow.</p>')

F7 = finding('F7', 'The label set is the Fock basis: the quantum notes in the bit rule', ['checked', 'ours', 'standard'],
 '<p>The notes’ fermionic Fock space ∧F = ℂ ⊕ H ⊕ (H∧H) ⊕ … (§21.4) is the exterior algebra Λ(H); on n modes it has 2ⁿ basis states: the n-bit labels. Wedge ε<sub>k</sub> and its transpose, the interior product ι<sub>k</sub>, satisfy ε<sub>k</sub>² = 0, which is his Pauli exclusion (Remark 14.17, ψ∧ψ = 0), and {ε<sub>k</sub>, ι<sub>l</sub>} = δ<sub>kl</sub>. The null squares are the Grassmann algebra; the operators ε<sub>k</sub> ± ι<sub>k</sub> square to ±1 and generate Cl(n,n) = M<sub>2ⁿ</sub>(ℝ), the Fock cell of the atlas, acting on those 2ⁿ states (checked for n = 1, 2, 3 with every product in the bit rule).</p>'
 '<p>The number operator N = Σ<sub>k</sub> (1 − e<sub>k,n+k</sub>)/2 is a sum of idempotents; on a state it returns the popcount of the label, and N = j has C(n,j) states: the grade. Our reading: a bit label is an occupation pattern, and the complement map (XOR with 11…1, which on these all-null labels is the Frobenius duality of the top-blade form and not a metric Hodge star, since the top blade is nilpotent: A6) is particle–hole conjugation. N qubits are the same rule with a Jordan–Wigner map: the 4<sup>N</sup> Pauli strings are the blades up to a phase, and the blade squares to +1 exactly when it is Hermitian (6 of the 16 at N = 2).</p>'
 '<p class="not">Gaps and flags. His symmetric Fock space and the oscillator [a₋, a₊] = 1 have no finite counterpart: the trace of a commutator is 0, the trace of 1 is n. Entanglement (§14.6): for real amplitudes the product states (simple tensors) are the null cone of det on M₂(ℝ), signature (2,2); over ℂ the condition is det = 0 on M₂(ℂ). The identification is standard; reading the (2,2) as the atlas’s first ultrahyperbolic cell Cl(2,2) is ours (analogy).</p>'
 '<p class="ids">checks Q1, Q5–Q7, Q10a–b.</p>',
 '<div class="figtitle">Three fermionic modes: the labels are the cube</div>' + CUBE +
 f'<div class="figtitle" style="margin-top:12px">Two qubits: the 16 blades are the 16 Pauli strings</div>{PGRID}<div class="legend" style="justify-content:center"><span><i class="sw g-S">▪</i> blade squares to +1 (Hermitian): {NHERM}</span><span><i class="sw" style="border:1.5px solid var(--e)">▫</i> squares to −1: {16 - NHERM}</span></div><figcaption>Each cell: the Pauli string (first qubit, second qubit) and the blade e<sub>…</sub> of the four Majorana generators it comes from.</figcaption>')

F8 = finding('F8', 'Spin and total spin, read off the grades', ['checked', 'standard'],
 '<p>The grade reading follows the text of the quantum notes. Under J<sub>i</sub> = e<sub>jk</sub>/2 the four grades of Cl(3,0) carry Casimir 0, 2, 2, 0: a singlet (scalar and e<sub>123</sub>) and a triplet (vectors and bivectors), which is his ½ ⊗ ½ = 0 ⊕ 1 (§15.7). His Clebsch–Gordan formulas of §15.6 (amplitudes √(j<sub>A</sub>/(j<sub>A</sub>+j<sub>B</sub>)) and −√(j<sub>B</sub>/(j<sub>A</sub>+j<sub>B</sub>)) at j = j<sub>A</sub>+j<sub>B</sub>−1) are reproduced numerically for five pairs (j<sub>A</sub>, j<sub>B</sub>): a test of the text, not of the atlas. The ladder derivation of §13.2 gives j(j+1) with 2j+1 states; the atlas supplies the j = ½ and adjoint pieces only.</p>'
 '<p>Stern–Gerlach (§1.1): in Cl(3,0) the projectors are (1 ± e<sub>i</sub>)/2; z → z gives 100%, z → x gives 50%, and a further z gives 50%, as in his figures, because e<sub>3</sub> and e<sub>1</sub> anticommute (Axioms 3 and 5).</p>'
 '<p class="ids">checks Q2, Q8, Q9a–b, Q12.</p>', '')

F9 = finding('F9', 'A sign to check: the Dirac equation as printed in the notes', ['checked', 'open'],
 '<p>The notes (§21.3, footnote 54) write (iγ<sup>μ</sup>∂<sub>μ</sub> − m)Ψ = 0 with {γ<sup>μ</sup>, γ<sup>ν</sup>} = 2η<sup>μν</sup> and η = diag(−1, 1, 1, 1). Then γ⁰ squares to −1 and the three γ<sup>a</sup> to +1: in the atlas’s convention that is Cl(3,1) = M₄(ℝ) (clock 2). The determinant of the plane-wave symbol vanishes at E² = |p|² − m², the wrong sign for a mass (checked numerically at one momentum with an explicit 4×4 representation that also satisfies the bit rule of Cl(3,1)). Flip the squares and the cell is Cl(1,3) = M₂(ℍ) (clock 6), the atlas’s choice, and the zero is at E² = |p|² + m². The two cells have the same complexification M₄(ℂ), which is why a four-component complex spinor looks the same in both.</p>'
 '<p>The notes’ own Klein–Gordon equation (□ + m²)φ = 0 has the right sign, so the two sections use different conventions. The notes are a student transcription, not endorsed by the lecturer; the video may differ. We flag it as a place where the atlas, which draws the sign choice as a choice of cell, makes the sign visible. This makes the row “mirror reading Cl(q,p) = the sign convention P → −P” a computed instance, not an analogy.</p>'
 '<p>Dropping the i gives the real (Majorana) operator γ<sup>μ</sup>∂<sub>μ</sub> − m of Cl(3,1), whose plane-wave symbol vanishes at E² = |p|² + m² (check G4b, exact). So this is a mismatch of conventions, not a problem of the cell. The physical sign does not need an i from the complex structure of the wave function (see F12).</p>'
 '<p class="ids">checks Q11a–c.</p>', '')

LENSES = [
 ('1 · Forms: wedge versus Clifford', 'kept', 'Same labels and XOR, only the squares differ. Multiplication by the pseudoscalar, his Hodge star, is XOR with 11…1 when no generator is null; with a null generator the complement map is a Frobenius duality, not a Hodge star.', 'A1–A6'),
 ('2 · Matter conditions as a filter on cells', 'kept', 'Hyperbolicity admits Cl(1,d) and Cl(k,1); Dirac symbol and bimetric product computed.', 'B1–B5'),
 ('3 · The deformation algebra as a family', 'partly', 'Witt ⊗ A_ε works in a frozen 1+1 model. Not his structure-function algebra; a scalar lapse fails Jacobi.', 'C1–C6'),
 ('4 · The area metric as a shape', 'kept', 'The octahedron 6 + 12 + 3, the density on the three axes, 20 = 10 + 10, so(4) content.', 'D1–D8'),
 ('5 · Spin group and Casimir', 'kept', 'SL(2,ℂ) at [3,−1]; Casimir −C(n,2)/4 with indices raised (no null generator); Pauli algebra = Cl(3,0).', 'E1–E5, Q8'),
 ('6 · Fock space and the Pauli group', 'kept', 'Λ(H) = labels; Cl(n,n) acts on it; N = popcount; Pauli strings = blades.', 'Q1, Q5–Q7'),
 ('7 · Topology and bundles', 'deadend', 'Chapters 3–6 and 19–20 of the geometry lectures need global structure. The atlas is a fibre-level, finite machine; the row stays a gap.', 'rows L4, L3'),
 ('8 · Rebuilding the closure equations', 'deadend', 'Not attempted. Needs an action principle and PDEs on a manifold; the atlas has neither.', 'rows C7, C12'),
 ('9 · The real Clifford group and lattices', 'recalled', 'Recalled, not verified: the real Clifford group of m qubits as 2^{1+2m}.O⁺(2m,2) (Nebe–Rains–Sloane); the fetched abstract only said “extraspecial group extended by an orthogonal group”. Computed: W(E₈) reduced mod 2 is onto O⁺(8,2), with kernel {±1}, the centre (atlas step 17; bd·en·2, bd·en·3).', 'bd·en·2, bd·en·3'),
]
CHIPLAB = {'kept': 'kept', 'partly': 'partly', 'deadend': 'dead end', 'recalled': 'recalled'}
LENS_HTML = ''.join(f'<div class="card"><h3>{E(t)}</h3><p>{SC.verdict(c, CHIPLAB[c])} <span class="ids">{E(ids)}</span></p><p>{E(txt)}</p></div>' for t, c, txt, ids in LENSES)

TEMPLATE = r'''<!doctype html>
<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 -->
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Schuller–Atlas Translation Matrix</title>
<meta name="description" content="Preliminary results: a graded translation matrix between Schuller's lectures and papers and the Cascade Atlas, with computed checks, findings, honest gaps and open questions.">
<style>%%CSS%%</style>
</head>
<body>
<header class="hero"><div class="wrap">
 <span class="kick">Schuller lens · %%TODAY%%</span>
 <h1>Schuller and the atlas: a translation matrix</h1>
 <p class="sub">What the three documents and the quantum lecture notes say, laid against the atlas’s rule, cells and 17 steps: where they are the same object, where only the same structure, where we only have a reading, and where the atlas has nothing.</p>
 <div class="notice"><b>Preliminary.</b> Read in part: the geometry lectures in targeted chapters, the closure paper in parts, the quantum notes in chapters 1, 12.4, 13–15, 16.2–16.3, 17 (in part), 19.4, 20 and 21. Nothing here is a result about nature. Tags are the atlas’s: %%CHIPS%% Grades E, S, A are explained under Fig. 2.</div>
 <div class="kpis">
  <div class="kpi"><b>%%NOK%%</b><span>checks pass, %%NBAD%% fail (%%NA%% geometry, %%NQ%% quantum, %%NG%% fibre and base)</span></div>
  <div class="kpi"><b>%%MUTOK%% of %%MUTALL%%</b><span>deliberate sabotages of the checks were caught</span></div>
  <div class="kpi"><b>%%NROWS%% × 22</b><span>rows of his work × atlas columns, %%NCELLS%% filled cells</span></div>
  <div class="kpi"><b>%%NGAP%%</b><span>rows with no counterpart: the honest gaps</span></div>
 </div>
 <p class="lead"><b>In one paragraph.</b> His constructive-gravity programme and the atlas meet at one place: a quadratic form on a vector space and the algebra it generates. He uses the form (the principal polynomial) to decide which geometries are physical and then derives gravity; the atlas takes the form as given and builds every object from one sign rule. Of the %%NROWS%% things his documents discuss, %%BE%% have an exact counterpart that we compute (exact: the same algebraic identity, pointwise, in one chart), %%BS%% a structural one, %%BA%% an analogy and %%BG%% none. The best-supported links: wedge and Clifford are one table (F1); hyperbolicity admits only the Lorentzian cells, one class in two conventions (F2); the trio −1, 0, +1 appears in four places (F3), and the Floquet bands follow the textbook elliptic/parabolic/hyperbolic split of SL(2,ℝ) (F13; grouping them with the trio is ours); the area metric is an octahedron (F4); and the quantum notes’ Fock space is the atlas’s label set (F7). One flag for the notes: the Dirac signs as printed (F9). F10–F15 test the fibre-and-base picture: base and fibre as the left and right action of an algebra on itself (F10), the n = 8 descent in which the fibre fills as 2<sup>8−k</sup> (F11), a momentum along an extra space-like direction entering as a mass (F12, Kaluza–Klein), the band structure of his chapter 20 computed as that split (F13), the 24 as three 8s (F14) and the E₈ ladder (F15).</p>
</div></header>

<nav class="toc"><div class="wrap">
 <a href="#obj">Objectives</a><a href="#how">How I explored</a><a href="#fig1">Fig. 1 pipeline</a><a href="#fig2">Fig. 2 matrix</a><a href="#findings">Findings</a><a href="#fibre">Fibre &amp; base</a><a href="#limits">Limits</a><a href="#persp">Perspectives</a><a href="#qm">Quantum plan</a><a href="#horizon">Horizon</a><a href="#checks">Checks</a><a href="#src">Sources</a>
 <button id="themebtn" type="button" aria-label="Switch colour theme">theme: auto</button>
</div></nav>

<main class="wrap">

<section id="obj"><h2>Definite objectives <small>what the request reduced to</small></h2>
 <div class="grid3">
  <div class="card"><h3>1 · The matrix</h3><p>Rows: the objects in his documents. Columns: the 22 pages and steps of the atlas. Each filled cell is graded exact, structural or analogy; an empty row says the atlas has nothing there.</p></div>
  <div class="card"><h3>2 · Tested links</h3><p>Every link we call exact is computed in a script, not argued by resemblance. A sabotage of a check (a changed sign, a wrong formula) must be caught; the section Checks says which checks have one.</p></div>
  <div class="card"><h3>3 · Perspectives</h3><p>A short list of questions the atlas’s view might raise for a reader of the lectures, each tagged ours or open, none presented as a fact about nature.</p></div>
 </div>
 <p>Ground rules kept: start from zero and explore the views before ranking them; no change to the web app; the genesis wording is untouched; the researcher’s own words are quoted, not paraphrased into claims.</p>
</section>

<section id="how"><h2>How I explored <small>nine views, before choosing</small></h2>
 <div class="lens">%%LENSES%%</div>
</section>

<section id="fig1"><h2>Fig. 1 · His pipeline against the atlas <small>grade falls from algebra to dynamics</small></h2>
 <p class="lead">Schuller’s chain, left to right, and what the atlas has at each link. The first three links are about what a quadratic form allows; the last four are about dynamics on a manifold.</p>
 %%PIPE%%
</section>

<section id="fig2"><h2>Fig. 2 · The translation matrix <small>%%NROWS%% rows × 22 columns</small></h2>
 <p class="lead">Each row is an object in his work (L: geometry lectures, C: closure paper and review, M: quantum lectures). Each column is an atlas page or step. Hover or focus a cell for what matches. A row without cells is a gap.</p>
 <div class="legend"><span><i class="sw g-E">E</i> exact: same object or identity, computed</span><span><i class="sw g-S">S</i> structural: same structure, other generality, or a standard fact</span><span><i class="sw g-A">A</i> analogy: our reading, not computed as the same</span><span><i class="sw gapsw">–</i> no cell: nothing in the atlas</span></div>
 %%MATRIX%%
 <h3 style="margin-top:18px">Fig. 3 · Coverage</h3>
 %%COVER%%
 <p>Reading it: the geometry lectures are covered best (the atlas is made of the same algebra), the closure paper mostly structurally (it is the dynamics side), and the quantum notes exactly where they are finite-dimensional algebra (spin, tensor products, Fock space) and not at all where they are analysis (chapters 2–11 and the operator theory of 18–20: not read, and nothing in the atlas would match them). The periodic-potential row (M11) has cells: the one-period matrix is a Cl(2,0) multivector (F13). The gaps are: topological manifolds and bundles (L4), canonical quantisability and the energy-distinguishing condition (C12), functional analysis and the spectral theorem (M2), measurement and mixed states (M10).</p>
</section>

<section id="findings"><h2>Findings <small>each with its tags and check ids</small></h2>
%%FINDINGS%%
</section>

<section id="fibre"><h2>Fibre and base: stepping down <small>F10–F15</small></h2>
%%FIBRE_INTRO%%
%%FINDINGS2%%
%%FIBRE_TAIL%%
</section>

<section id="limits"><h2>Dead ends and honest limits</h2>
 <div class="grid2">
  <div class="card"><h3>What the atlas cannot reach</h3><ul class="tight">
   <li><b>Global structure.</b> Topology, bundles, connections as sections over a manifold: the atlas is pointwise algebra and finite combinatorics. Fields are polynomials in one chart.</li>
   <li><b>An action principle.</b> No Lagrangian, no variation, so no closure equations.</li>
   <li><b>Analysis.</b> Banach spaces, measure theory, the spectral theorem, self-adjointness, rigged Hilbert space, bosonic Fock space and the oscillator ladder [a₋,a₊] = 1: infinite dimension. Chapter 20 is reached only through its one-period matrix (F13).</li>
  </ul></div>
  <div class="card"><h3>What I did not do or verify</h3><ul class="tight">
   <li>The closure paper was read only in parts; the geometry lectures in targeted chapters (12.2, 17.2, 15, 14); the quantum notes in chapters 1, 12.4, 13–15, 16.2–16.3, 17.3, 17.5, 19.4, 20 and 21.</li>
   <li>The deformation algebra is a frozen flat 1+1 model with a weight −1 lapse, not his structure-function algebra.</li>
   <li>“Witt-torus axes = stabiliser basis” and “End(V) = M₁₆(ℝ) as four-qubit real operators” are our readings; the second is only the algebra identity Cl(0,8) = Cl(4,4) = M₁₆(ℝ).</li>
   <li>The real Clifford group statement is recalled, not verified. Λ ↔ s and Lorentz ↔ ε = +1 are ours.</li>
   <li>Sabotage: %%MUTHAND%% of the %%MUTALL%% are recorded by hand, without a script (geometry side and Q5–Q12); the %%MUTAUTO%% on the fibre-and-base checks and on A6 are automated (<code>mutate_fibre.py</code>). The other checks have no sabotage run.</li>
   <li>The commutant, the mirror and the Gosset layers are exact algebra and combinatorics; calling any of them a gauge group, a generation or a mass is a reading. Standard theorems used from memory, not fetched from a source: Brauer–Wall, double centraliser, Floquet, Gosset polytopes, Turyn’s construction, W(F₄) = W(D₄) ⋊ S₃ (all recalled).</li>
   <li>Layout was checked by screenshot at 1100 and 375 px, light and dark, with no page overflow. The matrix has hover tooltips and a table view; the other figures have tooltips and carry their data in captions. SVG text shrinks on a phone (the matrix scrolls sideways instead).</li>
  </ul></div>
 </div>
</section>

<section id="persp"><h2>Perspectives <small>all ours or open; offered, not claimed</small></h2>
 <div class="grid2">
  <div class="card"><h3>P1 · A Clifford chapter between 12 and 15 %%C_OURS%%</h3><p>The lectures go from forms (ch. 12) to Lie groups, SL(2,ℂ) (ch. 15) and Casimir (ch. 17) without naming a Clifford algebra. The bit rule would fit between them in one table (F1) and puts SL(2,ℂ) at a computed address (F5); that this is a missing step is our reading. His closure paper then uses the Dirac algebra γ<sup>(a</sup>γ<sup>b)</sup> = G<sup>ab</sup> in one sentence; that sentence is the bit rule’s diagonal.</p></div>
  <div class="card"><h3>P2 · Matter conditions as a map of cells %%C_CHK%% %%C_OURS%%</h3><p>The first matter condition for quadratic P is the (k,d) grid of Fig. in F2: the Lorentzian cells pass, one class in two conventions, and Cl(2,2) is the first ultrahyperbolic cell. For real amplitudes, product states are the null cone of det on M₂(ℝ), signature (2,2); over ℂ the condition is det = 0 on M₂(ℂ) (F7). The link to hyperbolicity is ours. Whether the second and third conditions carve the same map for non-quadratic P is a question for his side.</p></div>
  <div class="card"><h3>P3 · The deformation algebra in more dimensions %%C_OPEN%%</h3><p>In the frozen 1+1 model the algebra is Witt ⊗ A<sub>ε</sub>, where ε is the sign class of the constant c = (deg P − 1)p<sup>11</sup> (the checks use c = −1, 0, +1; the algebra only sees its sign). In 1+1 both deformations are functions on a line; for d &gt; 1, Witt ⊗ A<sub>ε</sub> is not literal. Is there a family in the sign ε with Euclidean, Carroll-type and Lorentzian members (F3: in 1+1 the three members are Witt ⊗ ℂ, BMS₃ = GCA₂ and Witt ⊕ Witt; the names Euclidean and Lorentzian are ours)? Open; not computed beyond 1+1.</p></div>
  <div class="card"><h3>P4 · The area-metric constants and the octahedron %%C_OPEN%%</h3><p>Do the eleven or more constants of the closure of general linear electrodynamics organise along 6 + 12 + 3 (a split that depends on the frame), or along the so(4) pieces 5 + 5 + 9 + 1 + 1 (a Euclidean count; F4), or along the Lorentzian so(1,3) pieces? A check of whether the closure equations respect that split would say.</p></div>
  <div class="card"><h3>P5 · One object for Grassmann and Fock %%C_STD%%</h3><p>His geometry course builds Λ(V) as forms (ch. 12) and his quantum course builds ∧F as the fermionic Fock space (§21.4); they are the same exterior algebra, with bit label = occupation pattern (F7). The Pauli exclusion principle of §14.4 is e² = 0 in the all-null rule.</p></div>
  <div class="card"><h3>P6 · Closure with spinorial matter %%C_OPEN%%</h3><p>His paper treats Dirac matter only through its principal tensor. A closure that keeps the tetrad and the spinor would need the structure the atlas has at fibre level (steps 4, 5, 9, 12). Open, and beyond what we can test.</p></div>
  <div class="card"><h3>P7 · A convention flag %%C_CHK%%</h3><p>Dirac signs in the quantum notes (F9). Settled in the algebra (a mismatch of conventions, G4b); the video or the source of the notes would only show whether the printed form is the lecturer’s or the transcript’s, before the atlas’s Cl(1,3) and the notes’ Cl(3,1) are compared in print.</p></div>
  <div class="card"><h3>P9 · A Clifford home for the Floquet classes %%C_CHK%% %%C_OURS%%</h3><p>The one-period matrix of chapter 20 is a unit multivector of Cl(2,0); band, edge and gap are the sign of X² (F13). The same three classes sort the elements of SL(2,ℝ) and the pieces of the frozen deformation algebra (F3). Worth a look at the original lectures for the trace written ψ₁ + ψ₂ in the notes.</p></div>
  <div class="card"><h3>P10 · Base and fibre as left and right %%C_OURS%%</h3><p>His geometry course builds bundles globally (ch. 6 and after). A local algebraic counterpart is the pair of left and right actions of one algebra: the plain right action is a commuting fibre of the same type, the twisted one the mirror (F10, F11). Whether a global version exists is what row L4 leaves open.</p></div>
  <div class="card"><h3>P8 · Λ and the extra generator %%C_OURS%%</h3><p>The sign of Λ in his closure of Klein–Gordon (κ, Λ as integration constants) and the atlas’s s ∈ {0, −1, +1} (flat, de Sitter, anti-de Sitter): read as Λ ~ −s·κ². Ours; neither confirmed nor refuted by his equations.</p></div>
 </div>
</section>

<section id="qm"><h2>Integrating the quantum lectures <small>status and plan</small></h2>
 <div class="grid2">
  <div class="card"><h3>Read so far (%%NQCH%% chapters, in part)</h3><ul class="tight">
   <li>1: desiderata, five axioms, Stern–Gerlach</li><li>12.4: position, momentum, angular momentum</li><li>13: spin, Casimir, ladder operators</li><li>14: tensor products, symmetric and antisymmetric, entanglement</li><li>15: total spin, Clebsch–Gordan</li><li>16.2–16.3: oscillator ladder operators (to the first facts)</li><li>17.3, 17.5: measurement and mixed states (read, not yet encoded)</li><li>19.4 and 20: Fourier and the Schrödinger operator in part; periodic potentials, Floquet matrix and bands (F13)</li><li>21: Schrödinger, Klein–Gordon, Dirac, Fock space</li></ul>
   <p><b>Not read:</b> 2–11 (Banach, Hilbert, measure, spectral theorem), 12.1–12.3, rest of 16, the rest of 17–19 (measurement details, Fourier, Schrödinger operator). The notes are a student transcript; the full lectures are online and their last chapters are the ones to translate next.</p></div>
  <div class="card"><h3>Next, in order</h3><ol class="todo">
   <li>Chapter 17: mixed states as (1 + v)/2 in Cl(3,0) (the Bloch ball) and the probability rule as a trace (read, not yet encoded).</li>
   <li>Chapters 8–11 for the finite shadow of the spectral theorem: Hermitian blades, spectra ±1, projectors (1 ± e)/2.</li>
   <li>Chapter 16 in full, to state exactly what the fermionic oscillator shares with the bosonic ladder.</li>
   <li>The Dirac signs (F9): settled in the algebra; only the comparison with the lecture video remains, and it is optional.</li>
   <li>A single combined matrix with the geometry and quantum rows reordered along his pipeline.</li></ol></div>
 </div>
</section>

<section id="horizon"><h2>Horizon <small>speculation, no claims</small></h2>
 <div class="spec"><p>Three thoughts, kept as questions. (1) The “24” and the three 8-cubes: F14 computes the three 8s at n = 2 (the binary tetrahedral group), at n = 8 (the weights of 8<sub>v</sub>, 8<sub>s</sub>, 8<sub>c</sub>, with the triality as a 120° rotation) and at n = 24 (the Golay code from three 8-bit bricks). A cyclic order of three has no starting point, so a literal “before, now, after” needs one extra choice; whether the three 8s of Spin(8) and the three bricks of the Golay code are the same triple is open. (2) In his pipeline the energy cone has an inside, a boundary and an outside: timelike, null, spacelike. In the atlas the same split is the sign trio −1, 0, +1 (F3), also band, edge and gap of a periodic potential (F13). (3) Stepping down from the largest dimension and keeping the 8 fixed makes the fibre fill with the same layer sizes in two independent places, the commutants of F11 and the E₈ root ladder of F15; whether the layers are the fibre representations at each step of the atlas’s gauge steps is a question for later, and nothing here tests it.</p></div>
</section>



<section id="checks"><h2>Checks <small>%%NOK%% pass, %%NBAD%% fail</small></h2>
 <div class="grid2">
  <div class="card"><div style="overflow-x:auto"><table><thead><tr><th>Block</th><th>What it tests</th><th class="num">Checks</th><th>Script</th></tr></thead><tbody>%%CHECKS%%<tr><td></td><td><b>Total</b></td><td class="num"><b>%%NOK%%</b></td><td></td></tr></tbody></table></div></div>
  <div class="card"><h3>Sabotage test</h3><p>Deliberate changes to the checks: one place is changed in a copy of a script (a flipped sign, a swapped formula, a wrong count) and the named check must fail. %%MUTALL%% changes, all caught: %%MUTHANDA%% on the geometry side and %%MUTHANDB%% on Q5–Q12 are recorded by hand, without a script; %%MUTAUTO%% are automated (<code>mutate_fibre.py</code>), on %%NFIBNAMED%% of the %%NG%% fibre-and-base checks and on A6. The other checks have no sabotage run: at most %%MUTALL%% of the %%NOK%% checks have one.</p><table><tbody>%%MUTS%%</tbody></table>
   <h3 style="margin-top:12px">Rerun</h3><pre>cd reports/schuller
python3 bridge_check.py &gt; logs/bridge_check_final.log         # geometry side
python3 bridge_check_qm.py &gt; logs/bridge_check_qm_final.log   # quantum side
python3 fibre_check.py &gt; logs/fibre_check_final.log           # fibre and base
python3 mutate_fibre.py &gt; logs/mutation_fibre.log             # automated sabotage of the fibre checks
python3 build_report.py       # this page, into ../html/</pre><p style="font-size:13px;color:var(--muted)">Needs the atlas package this folder ships in (two folders up; or set <code>ATLAS_PKG</code>), Python 3 and numpy. Every number on this page is read from those logs or from the matrix data or computed in <code>fibre_section.py</code> from the same definitions, except the first two sabotage counts.</p></div>
 </div>
</section>

<section id="src"><h2>Sources</h2>
 <ul class="tight">
  <li>F. P. Schuller, <i>Lectures on the Geometric Anatomy of Theoretical Physics</i>, FAU Erlangen-Nürnberg 2013/14; notes by S. Rea, updated 25 October 2017. (Attached; read in targeted chapters.)</li>
  <li>M. Düll, F. P. Schuller, N. Stritzelberger, F. Wolz, <i>Gravitational closure of matter field equations</i>, <a href="https://arxiv.org/abs/1611.08878">arXiv:1611.08878</a> v3, 2018. (Attached; read in parts.)</li>
  <li>F. P. Schuller, <i>Constructive Gravity: Foundations and Applications</i>, rapporteur article, 15th Marcel Grossmann Meeting, <a href="https://arxiv.org/abs/2003.09726">arXiv:2003.09726</a>, 2020. (Attached.)</li>
  <li>F. P. Schuller, <i>Lectures on Quantum Theory</i>, FAU 2015; notes by S. Rea and R. Dadhley, 31 January 2019, 207 pp. (Attached; read in part. The notes state they are not endorsed by the lecturer.)</li>
  <li>M. Bojowald, E. I. Duque, A. Shah, <i>Hypersurface deformations</i>, <a href="https://arxiv.org/abs/2410.18807">arXiv:2410.18807</a>. (Consulted for the form of the deformation algebra; abstract level.)</li>
  <li>G. Nebe, E. M. Rains, N. J. A. Sloane, <a href="https://arxiv.org/abs/math/0001038">arXiv:math/0001038</a>, on Barnes–Wall lattices and Clifford groups. (Abstract only; the Clifford-group statement in lens 9 is recalled, not verified.)</li>
  <li>Standard theorems used in F10–F15 from memory, not fetched from a source (recalled): the Brauer–Wall group of Clifford algebras, the double-centraliser theorem, Floquet theory, the Gosset polytopes 4<sub>21</sub> and their vertex figures, Turyn’s construction of the Golay code, W(F<sub>4</sub>) = W(D<sub>4</sub>) ⋊ S<sub>3</sub>.</li>
  <li>The atlas package (steps 1–17, ledger, <code>bitcliff.py</code>).</li>
 </ul>
</section>
</main>
<footer><div class="wrap">Cascade Atlas · preliminary report, %%TODAY%% · generated by <code>build_report.py</code> from the logs and the matrix data. Not a theory of nature: a set of checks and readings.</div></footer>
<div id="tip" role="tooltip"></div>
<script>%%JS%%</script>
</body></html>
'''

FINDINGS = ''.join([F1, F2, F3, F4, F5, F6, F7, F8, F9])
_g5e = int(re.search(r'G5e: one fixed two-step potential: (\d+) band edges', open(os.path.join(HERE, 'logs', 'fibre_check_final.log'), encoding='utf-8').read()).group(1))
FIB = FS.build(finding, chip, E, tip, TYPES, okG, MUT_AUTO, _g5e)
CHIPS = SC.legend(['checked', 'standard', 'ours', 'open'], {'standard': 'textbook, used as is'})
nqch = 10
out = TEMPLATE
rep = {
 '%%CSS%%': CSS, '%%JS%%': JS, '%%TODAY%%': TODAY, '%%CHIPS%%': CHIPS, '%%NOK%%': str(TOTAL_OK), '%%NBAD%%': str(TOTAL_BAD), '%%NA%%': str(okA), '%%NQ%%': str(okQ),
 '%%MUTOK%%': str(MUT_OK), '%%MUTALL%%': str(MUT_ALL), '%%MUTHAND%%': str(MUT_HAND), '%%MUTHANDA%%': str(MUT_HAND_A), '%%MUTHANDB%%': str(MUT_HAND_B), '%%NFIBNAMED%%': str(NFIBNAMED), '%%MUTAUTO%%': str(MUT_AUTO), '%%NROWS%%': str(nrows), '%%NCELLS%%': str(ncells), '%%NGAP%%': str(len(GAP_ROWS)),
 '%%BE%%': str(bestE), '%%BS%%': str(bestS), '%%BA%%': str(bestA), '%%BG%%': str(bestG),
 '%%LENSES%%': LENS_HTML, '%%PIPE%%': PIPE, '%%MATRIX%%': MATRIX, '%%COVER%%': COVER, '%%FINDINGS%%': FINDINGS,
 '%%CHECKS%%': CHECKS_TABLE, '%%MUTS%%': MUT_TABLE, '%%NQCH%%': str(nqch), '%%NG%%': str(okG), '%%FIBRE_INTRO%%': FIB['INTRO'], '%%FINDINGS2%%': FIB['FINDINGS2'], '%%FIBRE_TAIL%%': FIB['TAIL'],
 '%%C_OURS%%': chip('ours'), '%%C_CHK%%': chip('checked'), '%%C_OPEN%%': chip('open'), '%%C_STD%%': chip('standard'),
}
for k, v in rep.items(): out = out.replace(k, v)
assert out.count('<body>') == 1; out = out.replace('<body>', '<body>\n' + SC.SPRITE, 1)      # the five icons, once
assert '%%' not in out, re.findall(r'%%\w+%%', out)
assert not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', out, flags=re.S)), 'an e-mail address is in the page'
path = os.path.join(HERE, '..', 'html', 'schuller_bridge_report.html'); os.makedirs(os.path.dirname(path), exist_ok=True)   # the shipped page lives in reports/html/
open(path, 'w', encoding='utf-8').write(out)
print('wrote', path, len(out), 'bytes;', f'checks {TOTAL_OK}, rows {nrows}, cells {ncells}, best E/S/A/gap {bestE}/{bestS}/{bestA}/{bestG}')
