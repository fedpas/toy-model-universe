# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""SVG drawings of the Furey report.  Every number drawn is computed here from the octonion product of model.py (the explicit model of the 2026 paper, a byte-identical copy of the atlas's file)
or read from furey_papers.json (the data that furey_papers_check.py writes with --write and the test compares with --compare); none is typed by hand except the sizes of the two boards,
which the builder asserts against the lines of logs/furey_construction_check.log (B5, B6)."""
import html, os, json, sys
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
from model import omul, E as UNITS
E = html.escape

def tip(*lines):
    return E('\n'.join(lines), quote=True)

DATA = json.load(open(os.path.join(HERE, 'furey_papers.json'), encoding='utf-8'))
TYPES = ['Q_L', 'u_R', 'd_R', 'L', 'e_R', 'nu_R']
TYPE_TEXT = {'Q_L': 'left-handed quark doublet Q_L (3,2,+1/6)', 'u_R': 'u_R (3,1,+2/3)', 'd_R': 'd_R (3,1,−1/3)', 'L': 'left-handed lepton doublet L (1,2,−1/2)',
             'e_R': 'e_R (1,1,−1)', 'nu_R': 'ν_R (1,1,0)'}
SM_IRREP = {'Q_L': '(3,2,+1/6)', 'u_R': '(3,1,+2/3)', 'd_R': '(3,1,-1/3)', 'L': '(1,2,-1/2)', 'e_R': '(1,1,-1)', 'nu_R': '(1,1,0)'}
CONJ_IRREP = {'Q_L': '(3b,2,-1/6)', 'u_R': '(3b,1,-2/3)', 'd_R': '(3b,1,+1/3)', 'L': '(1,2,+1/2)', 'e_R': '(1,1,+1)', 'nu_R': '(1,1,0)'}

def cell_type(irrep):
    """which of the six Standard Model types a cell's irrep is, and whether it is the particle's irrep or its conjugate (nu_R is its own conjugate)"""
    for t in TYPES:
        if irrep == SM_IRREP[t]: return t, 'particle'
        if irrep == CONJ_IRREP[t]: return t, 'conjugate'
    raise AssertionError(irrep)

def pretty(s):
    """(3b,2,-1/6) -> (3̄, 2, −1/6): a colour bar over the 3 and a real minus sign"""
    return s.replace('3b', '3̄').replace('-', '−')

def greek(s):
    """the ASCII names of the figure (nu_e, tau, mu) in Greek letters, a dagger for a trailing +"""
    s = s.replace('nu_', 'ν_').replace('tau', 'τ').replace('mu', 'μ')
    return s[:-1] + '†' if s.endswith('+') else s

def sub_html(s):
    """plain text with _X turned into a subscript, for the HTML of legends and tables"""
    import re
    return re.sub(r'_([A-Za-z0-9]+)', r'<sub>\1</sub>', E(s))

def svg_label(s):
    """greek(s) with the subscripts _X set as small lowered tspans (the baseline is restored after each)"""
    import re
    out, lowered = [], False
    for tok in re.split(r'(_[A-Za-zμτ0-9]+)', greek(s)):
        if not tok: continue
        if tok.startswith('_'):
            out.append(f'<tspan dy="3" font-size="10">{E(tok[1:])}</tspan>'); lowered = True
        elif lowered:
            out.append(f'<tspan dy="-3">{E(tok)}</tspan>'); lowered = False
        else:
            out.append(E(tok))
    return ''.join(out)

# first generation of the board: the cells of the figure that carry the six irreps of the first family (the others carry b_R, h, the third lepton doublet, tau_R and their daggers)
FIRST_GEN_BASES = {'(u,d)_L', 'u_R', 'd_R', '(nu_e,e)_L', 'e_R', 'nu_eR'}
def first_generation(cell):
    base = cell['labels'][0].rstrip('+')
    return base in FIRST_GEN_BASES

# ---------------------------------------------------------------------------------------------------------------------------------------------------
# Drawing 1: the octonion table as XOR labels with a sign
# ---------------------------------------------------------------------------------------------------------------------------------------------------
def octonion_table():
    """signs s(a,b) in e_a e_b = s(a,b) e_(a xor b), computed from the explicit product of model.py"""
    S = {}
    for a in range(8):
        for b in range(8):
            p = omul(UNITS[a], UNITS[b]); nz = np.nonzero(np.abs(p) > 1e-12)[0]
            assert len(nz) == 1 and nz[0] == a ^ b and abs(abs(p[nz[0]]) - 1) < 1e-12
            S[(a, b)] = int(round(p[nz[0]]))
    return S

def lines_of_fano():
    return sorted({tuple(sorted((a, b, a ^ b))) for a in range(1, 8) for b in range(1, 8) if a != b})

def assoc_example():
    """the first ordered triple of distinct imaginary units off a line, with (xy)z and x(yz): they are equal and opposite"""
    lines = set(lines_of_fano())
    for x in range(1, 8):
        for y in range(1, 8):
            for z in range(1, 8):
                if len({x, y, z}) == 3 and tuple(sorted((x, y, z))) not in lines:
                    l = omul(omul(UNITS[x], UNITS[y]), UNITS[z]); r = omul(UNITS[x], omul(UNITS[y], UNITS[z]))
                    assert np.allclose(l, -r)
                    k = int(np.nonzero(np.abs(l) > 1e-12)[0][0]); assert k == x ^ y ^ z
                    return (x, y, z), int(round(l[k])), int(round(r[k])), k
    raise AssertionError

def octonion_figure():
    S = octonion_table()
    cw, ch, x0, y0 = 52, 40, 64, 52
    W, H = x0 + 8 * cw + 8, y0 + 8 * ch + 26
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The octonion product table: the product of the units a and b is plus or minus the unit a XOR b; 64 cells coloured by the sign" class="chart fv">']
    parts.append(f'<text x="{x0 + 4 * cw}" y="16" text-anchor="middle" class="fv-x">second factor b</text>')
    parts.append(f'<text x="14" y="{y0 + 4 * ch}" text-anchor="middle" class="fv-x" transform="rotate(-90 14 {y0 + 4 * ch})">first factor a</text>')
    for k in range(8):
        parts.append(f'<text x="{x0 + k * cw + cw / 2}" y="{y0 - 10}" text-anchor="middle" class="fv-h">{k}</text>')
        parts.append(f'<text x="{x0 - 12}" y="{y0 + k * ch + ch / 2 + 5}" text-anchor="end" class="fv-h">{k}</text>')
    for a in range(8):
        for b in range(8):
            s = S[(a, b)]
            cls = 'fv-pos' if s > 0 else 'fv-neg'
            sym = '+' if s > 0 else '−'
            t = tip(f'e{a} · e{b} = {sym}e{a ^ b}', f'labels {a:03b} XOR {b:03b} = {a ^ b:03b}', 'check B1')
            parts.append(f'<g class="{cls}" data-tip="{t}" tabindex="0"><rect x="{x0 + b * cw + 1}" y="{y0 + a * ch + 1}" width="{cw - 2}" height="{ch - 2}" rx="5"/>'
                         f'<text x="{x0 + b * cw + cw / 2}" y="{y0 + a * ch + ch / 2 + 5}" text-anchor="middle" class="fv-n">{sym}{a ^ b}</text></g>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span><i class="sw fv-swpos">+</i> product is +e<sub>a⊕b</sub></span><span><i class="sw fv-swneg">−</i> product is −e<sub>a⊕b</sub></span>'
           '<span>cell = the label a XOR b with its sign; the first row and column are the unit 1</span></div>')
    return ''.join(parts) + leg

# ---------------------------------------------------------------------------------------------------------------------------------------------------
# Drawing 2: the dimension ladders of Roadmap I and the intersections of Roadmap III
# ---------------------------------------------------------------------------------------------------------------------------------------------------
REFL = {'O': 'L_e7 (𝕆)', 'Or': 'R_e7 (second 𝕆 reflection)', 'H': 'L_ε3 (ℍ)', 'C': 'complex conjugation (ℂ)'}
REFL_SHORT = {'O': 'O', 'Or': "O′", 'H': 'H', 'C': 'C'}
PS_NAMES = {'Spin(10)': 'Spin(10)', 'Pati-Salam': 'Pati–Salam', 'Left-Right': 'Left–Right', 'UBZ+ = u(3)+u(1)+u(1)': 'u(3)+u(1)+u(1)', 'UB+ = u(3)+u(1)': 'u(3)+u(1)',
            'SU(5)': 'SU(5)', 'Standard Model (->O)': 'su(3)+su(2)+u(1)', 'UBZ = su(3)+u(1)+u(1)': 'su(3)+u(1)+u(1)', 'UB = su(3)+u(1)': 'su(3)+u(1)'}

def ladders_figure():
    R = DATA['roadmap']
    groups = [('Spin(10) line', 'R7', [(PS_NAMES[s['name']], s['dim'], s['reflections']) for s in R['spin10_line']]),
              ('SU(5) line', 'R8', [(PS_NAMES[s['name']], s['dim'], s['reflections']) for s in R['su5_line']]),
              ('Intersections', 'R9', [('spinor intersection', R['intersections']['vector_spinor'], []), ('three-way with 𝕆', R['intersections']['three_way_O'], ['O']),
                                       ('five-way with 𝕆, ℍ, ℂ', R['intersections']['five_way_O_H_C'], ['O', 'H', 'C']), ('four-way without 𝕆', R['intersections']['four_way_no_O'], ['H', 'C'])])]
    W, H = 800, 330
    base, top = 262, 62                                  # baseline and the height of the largest bar
    scale = (base - top) / 45.0
    bw, gap = 42, 10
    xs, x = [], 24
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Dimensions of the symmetry algebras along the two ladders of reflections and the intersections of Roadmap III" class="chart fv">']
    for gname, cid, items in groups:
        gx = x
        for i, (nm, d, refl) in enumerate(items):
            bx = x + i * (bw + gap)
            hh = d * scale
            rtxt = ', '.join(REFL[r] for r in refl) if refl else 'none'
            if gname == 'Intersections':
                t = tip(f'{nm}: dimension {d}', 'Roadmap III: the generators that annihilate the vacuum from the left, intersected with the spinor actions of the listed reflections: ' + rtxt, f'check {cid} (R10 for the single constraint)')
            else:
                t = tip(f'{nm}: dimension {d}', f'reflections switched on: {rtxt}', f'check {cid}')
            parts.append(f'<g class="fv-bar" data-tip="{t}" tabindex="0"><rect x="{bx}" y="{base - hh}" width="{bw}" height="{hh}" rx="4"/>'
                         f'<text x="{bx + bw / 2}" y="{base - hh - 6}" text-anchor="middle" class="fv-n">{d}</text></g>')
            parts.append(f'<text x="{bx + bw / 2}" y="{base + 15}" text-anchor="middle" class="fv-s">{" ".join(REFL_SHORT[r] for r in refl) if refl else "–"}</text>')
        gw = len(items) * (bw + gap) - gap
        parts.append(f'<text x="{gx + gw / 2}" y="{base + 40}" text-anchor="middle" class="fv-h2">{E(gname)}</text>')
        parts.append(f'<text x="{gx + gw / 2}" y="{base + 56}" text-anchor="middle" class="fv-s">{"checks " + cid}</text>')
        names = ' · '.join(nm for nm, _, _ in items)
        xs.append((gx, gw, names))
        x += len(items) * (bw + gap) + 30
    parts.append(f'<line x1="14" y1="{base}" x2="{W - 10}" y2="{base}" class="fv-ax"/>')
    parts.append(f'<text x="14" y="18" class="fv-s">real dimension of the algebra</text>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span>letters under a bar: the reflections switched on (O = L<sub>e7</sub>, O′ = R<sub>e7</sub>, H = L<sub>ε3</sub>, C = complex conjugation; – = none)</span>'
           '<span>bars of the first line: Spin(10), Pati–Salam, Left–Right, u(3)+u(1)+u(1), u(3)+u(1); of the second: SU(5), su(3)+su(2)+u(1), su(3)+u(1)+u(1), su(3)+u(1)</span></div>')
    return ''.join(parts) + leg

# ---------------------------------------------------------------------------------------------------------------------------------------------------
# Drawing 3: the two boards of Peirce blocks
# ---------------------------------------------------------------------------------------------------------------------------------------------------
REAL_BLOCKS = [('O1', 2), ('O2', 6), ('H', 4), ('C', 2), ('e7R', 1), ('R', 1)]
CX_BLOCKS = [('O1', 1), ('O2', 3), ('H', 2), ('C', 1), ('last', 1)]
def boards_figure():
    blocks = DATA['fig1']['blocks']
    assert [b['name'] for b in blocks] == ['O1', 'O2', 'H', 'C', 'last']
    def irrep_text(b):
        return f'({b["colour"].replace("3b", "3̄")}, {b["isospin"]}, Y = {b["y"]})'
    W, H = 800, 376
    side = 290
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The real 16 by 16 board with diagonal blocks of sizes 2, 6, 4, 2, 1, 1 and the complex 8 by 8 board with diagonal blocks 1, 3, 2, 1, 1" class="chart fv">']
    def board(x0, y0, sizes, unit, title, cx):
        parts.append(f'<text x="{x0 + side / 2}" y="{y0 - 18}" text-anchor="middle" class="fv-h2">End<tspan dy="3" font-size="10">{"ℂ" if cx else "ℝ"}</tspan><tspan dy="-3">(V): {title}</tspan></text>')
        parts.append(f'<rect x="{x0}" y="{y0}" width="{side}" height="{side}" class="fv-board"/>')
        pos = 0
        for i, (nm, n) in enumerate(sizes):
            glued = (not cx) and nm in ('e7R', 'R')
            cls = 'fv-blk glued' if (glued or (cx and nm == 'last')) else 'fv-blk'
            if cx:
                lines = [f'block {nm}: size {n} (complex)', f'irrep (colour, isospin, hypercharge) {irrep_text(blocks[i])}', 'checks B6, F2']
            elif glued:
                lines = [f'block {nm}: size {n} (real)', 'ω exchanges this block with the other rank-1 block: together they are one complex block of size 1', 'checks B5, B6']
            else:
                lines = [f'block {nm}: size {n} (real)', 'the complex structure ω commutes with this block', 'checks B5, B6']
            parts.append(f'<g class="{cls}" data-tip="{tip(*lines)}" tabindex="0"><rect x="{x0 + pos * unit}" y="{y0 + pos * unit}" width="{n * unit}" height="{n * unit}"/></g>')
            parts.append(f'<text x="{x0 + (pos + n / 2) * unit}" y="{y0 - 3 if i % 2 == 0 else y0 + side + 14}" text-anchor="middle" class="fv-s">{E(nm)} · {n}</text>')
            pos += n
        assert pos * unit == side
    board(30, 56, REAL_BLOCKS, side / 16, 'real 16 × 16', False)
    board(450, 56, CX_BLOCKS, side / 8, 'complex 8 × 8', True)
    parts.append('</svg>')
    leg = ('<div class="legend"><span><i class="sw fv-swblk">■</i> block on the diagonal (size shown above or below)</span><span><i class="sw fv-swglue">■</i> the two rank-1 blocks that ω exchanges, one block on the complex board</span>'
           '<span>the rest of each square is the off-diagonal part: 194 real (left) and 48 complex (right) dimensions</span></div>')
    return ''.join(parts) + leg

# ---------------------------------------------------------------------------------------------------------------------------------------------------
# Drawing 4: the board of Fig. 1 of the 2026 paper
# ---------------------------------------------------------------------------------------------------------------------------------------------------
def board_figure():
    cells = {(c['row'], c['col']): c for c in DATA['fig1']['cells']}
    blocks = DATA['fig1']['blocks']
    cw, ch, x0, y0 = 144, 76, 82, 64
    W, H = x0 + 5 * cw + 8, y0 + 5 * ch + 8
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The 5 by 5 board of Fig. 1 of the nested-embeddings paper: 20 off-diagonal cells coloured by the Standard Model type of their irrep, the diagonal holding the gauge bosons" class="chart fv">']
    def bl(b): return f'({b["colour"].replace("3b", "3̄")},{b["isospin"]},{b["y"]})'
    parts.append(f'<text x="{x0 + 2.5 * cw}" y="14" text-anchor="middle" class="fv-x">to the block of the column</text>')
    parts.append(f'<text x="12" y="{y0 + 2.5 * ch}" text-anchor="middle" class="fv-x" transform="rotate(-90 12 {y0 + 2.5 * ch})">from the block of the row</text>')
    for k, b in enumerate(blocks):
        parts.append(f'<text x="{x0 + k * cw + cw / 2}" y="{y0 - 22}" text-anchor="middle" class="fv-h">{k}</text><text x="{x0 + k * cw + cw / 2}" y="{y0 - 8}" text-anchor="middle" class="fv-s">{E(bl(b))}</text>')
        parts.append(f'<text x="{x0 - 8}" y="{y0 + k * ch + ch / 2 - 2}" text-anchor="end" class="fv-h">{k}</text><text x="{x0 - 8}" y="{y0 + k * ch + ch / 2 + 12}" text-anchor="end" class="fv-s">{E(bl(b))}</text>')
    for r in range(5):
        for c in range(5):
            x, y = x0 + c * cw, y0 + r * ch
            if r == c:
                parts.append(f'<g class="fv-gauge" data-tip="{tip(f"diagonal cell {r}: gauge bosons of the block", DATA["fig1"]["diagonal"][r], "not tested: the labels of the diagonal are the paper")}" tabindex="0">'
                             f'<rect x="{x + 1}" y="{y + 1}" width="{cw - 2}" height="{ch - 2}" rx="6"/><text x="{x + cw / 2}" y="{y + ch / 2 + 4}" text-anchor="middle" class="fv-s">gauge</text></g>')
                continue
            cell = cells[(r, c)]
            t, orient = cell_type(cell['irrep'])
            ti = TYPES.index(t)
            first = first_generation(cell)
            dag = cell['dagger']
            q = ', '.join(f'{k.replace("-", "−")} × {v}' for k, v in sorted(cell['charges'].items(), key=lambda kv: Fr(kv[0])))
            lines = [f'cell ({r}, {c}): from block {r} to block {c}', f'irrep {pretty(cell["irrep"])}: {TYPE_TEXT[t]}' + (' (its conjugate)' if orient == 'conjugate' and t != 'nu_R' else ''),
                     'labels in the figure: ' + ' / '.join(greek(l) for l in cell['labels']), 'electric charges of the components: ' + q,
                     'part of the first generation' if first else 'beyond the first generation (b_R, h, the third lepton doublet, τ_R)', 'checks F1, F4']
            cls = f'fv-cell ft{ti}' + ('' if first else ' beyond')
            l1, l2 = cell['labels']
            parts.append(f'<g class="{cls}" data-tip="{tip(*lines)}" tabindex="0"><rect x="{x + 1}" y="{y + 1}" width="{cw - 2}" height="{ch - 2}" rx="6"/>'
                         f'<text x="{x + cw / 2}" y="{y + 26}" text-anchor="middle" class="fv-n2">{svg_label(l1)}</text><text x="{x + cw / 2}" y="{y + 45}" text-anchor="middle" class="fv-n2">{svg_label(l2)}</text>'
                         f'<text x="{x + cw / 2}" y="{y + 64}" text-anchor="middle" class="fv-s">{E(pretty(cell["irrep"]))}</text></g>')
    parts.append('</svg>')
    leg = '<div class="legend">' + ''.join(f'<span><i class="sw ftsw{i}">{i + 1}</i> {sub_html(TYPE_TEXT[t])}</span>' for i, t in enumerate(TYPES)) + \
          '<span><i class="sw fv-swbeyond">–</i> dashed outline: beyond the first generation</span></div>'
    return ''.join(parts) + leg

def type_counts():
    """cells by Standard Model type, a particle cell and a conjugate cell each counted once (check C1)"""
    n = {t: 0 for t in TYPES}
    for c in DATA['fig1']['cells']: n[cell_type(c['irrep'])[0]] += 1
    return n

# ---------------------------------------------------------------------------------------------------------------------------------------------------
# Drawing 5: how many complete sets fit in a given complex dimension
# ---------------------------------------------------------------------------------------------------------------------------------------------------
def room_figure():
    byd = DATA['room']['by_dimension']
    dims = sorted(int(k) for k in byd)
    W, H = 760, 330
    x0, x1, y0, y1 = 70, 740, 24, 262
    bw = (x1 - x0) / len(dims)
    top = 4
    sc = (y1 - y0) / top
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The largest number of complete Standard Model sets held by any admissible block structure of complex dimension 8 to 14" class="chart fv">']
    for v in range(0, top + 1):
        y = y1 - v * sc
        parts.append(f'<line x1="{x0}" y1="{y}" x2="{x1}" y2="{y}" class="fv-ax"/><text x="{x0 - 8}" y="{y + 4}" text-anchor="end" class="fv-s">{v}</text>')
    parts.append(f'<line x1="{x0}" y1="{y1 - 3 * sc}" x2="{x1}" y2="{y1 - 3 * sc}" class="fv-hz"/><text x="{x0 + 6}" y="{y1 - 3 * sc - 6}" text-anchor="start" class="fv-s">three sets</text>')
    parts.append(f'<text x="14" y="{(y0 + y1) / 2}" text-anchor="middle" class="fv-x" transform="rotate(-90 14 {(y0 + y1) / 2})">most complete sets in one structure</text>')
    for i, d in enumerate(dims):
        rec = byd[str(d)]
        sets = rec['max_S'] // 2
        hist = {int(k) // 2: v for k, v in rec['histogram_of_S'].items()}
        hist_txt = ', '.join(f'{k} sets: {v:,}' for k, v in sorted(hist.items()))
        ex = ', '.join(pretty(e) for e in rec['example_with_max'])
        t = tip(f'complex dimension {d}: {rec["structures"]:,} admissible block structures', f'at most {sets} complete set{"s" if sets != 1 else ""} in one structure', 'structures by sets held: ' + hist_txt,
                'a structure that reaches the best: ' + ex, 'checks N1, N2')
        bx = x0 + i * bw + 12
        cls = 'fv-bar three' if sets >= 3 else 'fv-bar'
        parts.append(f'<g class="{cls}" data-tip="{t}" tabindex="0"><rect x="{bx}" y="{y1 - sets * sc}" width="{bw - 24}" height="{sets * sc}" rx="4"/>'
                     f'<text x="{bx + (bw - 24) / 2}" y="{y1 - sets * sc - 6}" text-anchor="middle" class="fv-n">{sets}</text></g>')
        parts.append(f'<text x="{bx + (bw - 24) / 2}" y="{y1 + 16}" text-anchor="middle" class="fv-h">{d}</text>')
        parts.append(f'<text x="{bx + (bw - 24) / 2}" y="{y1 + 31}" text-anchor="middle" class="fv-s">{rec["structures"]:,}</text>')
    parts.append(f'<text x="{x0 - 8}" y="{y1 + 16}" text-anchor="end" class="fv-s">dim</text><text x="{x0 - 8}" y="{y1 + 31}" text-anchor="end" class="fv-s">structures</text>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span>bar: the most complete sets held by the linear off-diagonal cells of any admissible structure (a field and its conjugate counted once)</span>'
           '<span>the paper\'s structure has dimension 8 and holds 1</span></div>')
    return ''.join(parts) + leg
