# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The text of the Furey report: the six papers, findings, dictionary rows, inputs, limits, sources.  Plain data; build_report_furey.py puts it on the page and test_report_furey.py
pins it against logs/furey_papers_check.log and logs/furey_construction_check.log (every check id named here exists, every id of the logs is named, the numbers equal the logs).
A status tag is one of standard (a textbook statement or the paper's own statement, used as is), checked (a script in this folder recomputed it), ours (our reading), open (not settled),
input (a choice or datum the physics page needs that the algebra does not supply: the complex structure, the partition of the axes, the labels of a figure, the family of structures searched).
The words %%FIG_...%%, %%TAB_...%% and %%ASSOC%% are replaced by drawings, tables and the associator example, all computed by the builder."""

TITLE = 'Furey and the division algebras: a lens report'
H1 = 'The division algebras and the Standard Model in the bit rule'
SUB = ('What the papers of Furey on the Standard Model and the division algebras state, what was rebuilt from the octonion table and counted, how the explicit sixteen-dimensional model of the 2026 paper reads '
       'in the atlas\'s one rule (labels, XOR and a sign), and which choices the construction makes that the rule does not.')
NOTICE = ('<b>Preliminary.</b> This is Calibration 2 (Furey) of the atlas in its long form. A calibration is a run on something whose answer is known, to show which inputs the method needs; it is not a test of a new theory. '
          'Here the known answers are the numbers the papers state; the inputs are listed in the section Inputs. A statement tagged checked is recomputed by a script in this folder: the dimensions, spectra and counts of the '
          'Roadmap and Trialities papers, the explicit sixteen-dimensional model of the 2026 paper, and the labels of its Fig. 1 against the gauge quantum numbers of its cells. '
          'The counts are about colour, isospin and hypercharge only. Nothing here is a result about nature, and nothing says that a cell, a block or a product of irreps is a particle.')

LEAD = ('Furey\'s program writes the particles and gauge groups of the Standard Model with the four division algebras ℝ, ℂ, ℍ and 𝕆. This report follows it through six papers, from the Roadmap of December 2023 '
        'to the nested-embeddings paper of July 2026, and does three things. It rebuilds, from the octonion multiplication table, the explicit algebra of the Roadmap, Trialities and the 2026 paper, and recomputes every number it quotes: '
        'one generation as a 16-dimensional left-handed space inside 32 complex dimensions, the two ladders 45 → 21 → 15 → 11 → 10 and 24 → 12 → 10 → 9, the 14 derivations of 𝕆, the Peirce blocks (2, 6, 4, 2, 1, 1) and (1, 3, 2, 1, 1), '
        'the ten edges between the five blocks, and the 20 cells of the paper\'s Fig. 1 (42 checks in all). '
        'It reads the model in the bit rule: the octonion table is the XOR rule with a sign that does not associate, End<sub>ℝ</sub>(V) is the cell of 8-bit labels Cl(0,8), the sixteen axes of V carry the extended Hamming code, '
        'and the complex structure ω is one blade of grade 6. And it counts: with one label per cell Fig. 1 holds one complete Standard Model set and 8 complex dimensions beyond it; with every cell doubled it holds two, '
        'and the irreps of Q<sub>L</sub>, u<sub>R</sub> and ν<sub>R</sub> lack a third copy; three complete sets first fit at dimension 14 among the block structures searched. '
        'What the rule does not supply: the complex structure, the partition of the axes into blocks, the hypercharges, the labels of the figure, and the family of structures searched. Those are the inputs; the section Inputs lists each with the check that shows what depends on it.')

# the six papers: (id, name, title, authors, reference, date, what it builds, what is rebuilt here, check ids, chips)
PAPERS = [
 ('r1', 'Roadmap I', 'An Algebraic Roadmap of Particle Theories, Part I: General construction', 'N. Furey', 'arXiv:2312.12377', 'December 2023',
  'One generation of the Standard Model as a 16-dimensional left-handed space of Spin(10), written with the ladder operators of ℂ⊗ℍ⊗𝕆 (32 complex dimensions); a network of nine models from Spin(10) down to the post-Higgs Standard Model, '
  'the steps being reflections through ℝ, ℂ, ℍ and 𝕆; a quaternionic reflection that separates W<sup>±</sup> from Z<sup>0</sup>.',
  'From the octonion multiplication table up: the ten gamma matrices, the vacuum, the 16-dimensional left-handed space, the 45 generators of spin(10), the 24 of su(5), and the dimension ladders 45 → 21 → 15 → 11 → 10 and 24 → 12 → 10 → 9.',
  'A1–A5, R1–R8', ['standard', 'checked']),
 ('r2', 'Roadmap II', 'An Algebraic Roadmap of Particle Theories, Part II: Theoretical checkpoints', 'N. Furey', 'arXiv:2312.12799', 'December 2023',
  'Five checkpoints for an algebraic model (Coleman–Mandula, fermion doubling, chirality, no low-energy B−L gauge symmetry, three generations); the model of Part I passes the first four and has yet to cross the fifth; an appearance of spacetime symmetries.',
  'The chirality element is −R<sub>ε3</sub>; the left-handed projector has rank 16 of 32; on the 16 states Y, Q and B−L take the Standard Model values with zero trace and zero sum of cubes. The checkpoint of Coleman–Mandula is not tested.',
  'A5, R3, R11', ['standard', 'checked', 'open']),
 ('r3', 'Roadmap III', 'An Algebraic Roadmap of Particle Theories, Part III: Intersections', 'N. Furey', 'arXiv:2312.14207', 'December 2023',
  'A direct route from Spin(10) to the Standard Model by one algebraic constraint: three so(10) actions agreeing on a fixed space of multivector fermions, like so(8) → g<sub>2</sub> in octonionic triality; a five-way intersection with ℍ and ℂ gives su(3)⊕u(1)<sub>Q</sub>, the unbroken symmetries after the Higgs.',
  'The intersection dimensions 24 (spinor), 12 (three-way), 9 (five-way) and 9 (four-way without 𝕆), and the 12 solutions of the single constraint.',
  'R9, R10', ['standard', 'checked']),
 ('tri', 'Trialities', 'Three Generations and a Trio of Trialities', 'N. Furey and M. J. Hughes', 'arXiv:2409.17948', 'September 2024',
  'The Standard Model algebra inside tri(ℂ)⊕tri(ℍ)⊕tri(𝕆) acting on the triple (Ψ<sup>+</sup>, Ψ<sup>−</sup>, V); Ψ<sup>+</sup> and Ψ<sup>−</sup> give two generations; after a Cartan factorization V gives a third and also holds the Higgs representation; e<sub>7</sub> and e<sub>8</sub> appear through Freudenthal–Tits dimension counts.',
  'The 14 derivations of 𝕆, the Standard Model action on Ψ<sup>+</sup>, Ψ<sup>−</sup> and V with their hypercharge spectra, Cartan\'s triality principle, and 133 = 9 + 28 + 96, 248 = 28 + 28 + 192. The Cartan factorization itself is not rebuilt.',
  'T1–T5', ['standard', 'checked', 'open']),
 ('sup', 'Superalgebra', 'A Superalgebra Within: representations of lightest Standard Model particles form a ℤ<sub>2</sub><sup>5</sup>-graded algebra', 'N. Furey', 'arXiv:2505.07923', 'May 2025',
  'The decomposition of the hermitian 16 × 16 matrices into Standard Model representations, with the gauge bosons and three generations of fermions apart from the top-quark representations, as a superalgebra. Its decomposition is the Fig. 1 that the 2026 paper reproduces.',
  'This paper has not been read. Its figure is checked as printed in the 2026 paper: all 20 off-diagonal cells (F1–F4).',
  'F1–F4', ['checked', 'open']),
 ('nest', 'Nested embeddings', 'Standard Model Symmetries and the Nested Embeddings of ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆', 'N. Furey', 'arXiv:2607.18450', 'July 2026',
  'The Standard Model\'s su(3)⊕su(2)⊕u(1) and su(3)⊕u(1)<sub>Q</sub> from the module 𝕆⊕ℍ⊕ℂ⊕ℝ over its own multiplication algebra, with Y and Q as simple sums of projectors; an embedding into a 16-dimensional V with End<sub>ℝ</sub>(V) ≅ Cl(0,8) of 256 real dimensions; '
  'Fig. 1 with three generations apart from the top-quark representations.',
  'An explicit V built from the octonion table; the Peirce blocks (2, 6, 4, 2, 1, 1) and (1, 3, 2, 1, 1); Tr Y = Tr Q = 3; the ten edges; the 20 cells of Fig. 1; the counting of complete sets; the composite irreps; the room search; '
  'the sixteen axes and the partition of them into blocks.',
  'A1–A5, B1–B12, F1–F4, C1–C2, P1, N1–N2', ['standard', 'checked', 'input']),
]

# status tags: chips in the finding head
# finding: (id, title, chips, left, right, ids)
FINDINGS = [
 ('S1', 'One generation in 32 complex dimensions (Roadmap I and II)', ['standard', 'checked', 'ours', 'input'],
  '<p>The space of the Roadmap is ℂ⊗ℍ⊗𝕆, of 4 × 8 = 32 complex dimensions, acted on by the left and right multiplications of its factors. Built from the octonion table, the units square to −1 and e<sub>1</sub>e<sub>2</sub> = e<sub>3</sub> in the quaternions; '
  'the Roadmap\'s formula R<sub>e7</sub> = ½(−L<sub>e7</sub> + L<sub>e1</sub>L<sub>e3</sub> + L<sub>e2</sub>L<sub>e6</sub> + L<sub>e4</sub>L<sub>e5</sub>) holds, and L<sub>e7</sub> = L<sub>e1</sub>L<sub>e2</sub>⋯L<sub>e6</sub> (A1–A3). '
  'The ten matrices Γ<sub>p</sub> of Roadmap I eq. (25) satisfy {Γ<sub>p</sub>, Γ<sub>q</sub>} = −2δ<sub>pq</sub>: they generate Cl(0,10) on 32 complex dimensions (A4). '
  'Five ladder pairs satisfy the canonical anticommutation relations (R1) and fix a vacuum projector of rank 1 (R2). The left-handed projector P<sub>L</sub> has rank 16 and contains the vacuum (R3): one generation. '
  'The 45 left-multiplication generators and the 45 Dirac bivectors act identically on it (rank 45 each, rank of the union 45), and they close under the commutator: spin(10) in its left-multiplication form (R4, R5). '
  'The condition ⟨0|ℓ = 0 leaves 24 dimensions, su(5) (R6). The chirality element Γ<sub>1</sub>⋯Γ<sub>10</sub> is −R<sub>ε3</sub>, a right multiplication by a quaternion unit (A5).</p>'
  '<p>On the 16 states, hypercharge Y takes the values +1/6 (6 states), −2/3 (3), +1/3 (3), −1/2 (2), +1 (1) and 0 (1), the Standard Model values of Q<sub>L</sub>, u<sup>c</sup>, d<sup>c</sup>, L, e<sup>c</sup>, ν<sup>c</sup>; '
  'Q and B−L take the expected values, and the trace and the sum of cubes of each of Y, Q and B−L over the 16 states are 0 (R11).</p>',
  '<p><b>Standard</b> (Roadmap I and II). <b>Checked</b> as stated, in numpy with tolerances of 1e-9 and better.</p>'
  '<p><b>Ours</b> (a reading in the bit rule). Ten generators that square to −1 and anticommute are the cell Cl(0,10); its 1024 blades are the 10-bit labels, and the 45 bivectors are the 45 labels with two bits set. '
  'The check A4 asserts the anticommutation; the labelling is the rule\'s.</p>'
  '<p class="not"><b>Input.</b> Which ten of the left and right multiplications play the Γ<sub>p</sub>, and which elements are the ladder operators and the vacuum: the paper\'s choice (Inputs, I1). '
  'The algebra offers many sets of ten anticommuting generators.</p>',
  'A1–A5, R1–R6, R11'),

 ('S2', 'The two ladders of reflections and the intersections of Part III', ['standard', 'checked', 'input'],
  '<p>Four reflections act as conjugations: by L<sub>e7</sub> (𝕆), by R<sub>e7</sub> (the second octonionic reflection), by L<sub>ε3</sub> (ℍ) and complex conjugation (ℂ). Requiring invariance under them in turn cuts the 45 generators down. '
  'Along the Spin(10) line of Roadmap I, Fig. 4: 45 → 21 (Pati–Salam, su(4)+su(2)+su(2)) → 15 (Left–Right) → 11 (u(3)+u(1)+u(1)) → 10 (u(3)+u(1)); the second octonionic reflection alone already gives 15 (R7). '
  'Along the SU(5) line, Fig. 5: 24 → 12 (su(3)+su(2)+u(1)) → 10 (with the quaternionic reflection) → 9 (with complex conjugation); the second octonionic reflection alone also gives 12, '
  'and the first octonionic reflection with complex conjugation, without the quaternionic one, already gives 9 (R8).</p>'
  '<p>Roadmap III replaces the ladder by intersections: the spinor intersection has dimension 24 (su(5)); the three-way intersection with the octonionic spinor 12 (su(3)+su(2)+u(1)); the five-way intersection with the quaternionic and complex spinors 9 (su(3)+u(1)<sub>Q</sub>); '
  'the four-way intersection without the octonionic one is also 9 (R9). The single constraint with a free scalar has 12 solutions, all with the scalar equal to 0 (R10).</p>',
  '%%FIG_LADDERS%%'
  '<p><b>Standard</b> and <b>checked</b>: every dimension of both lines and of the intersections.</p>'
  '<p class="not"><b>Input.</b> Which reflections are switched on and in which order is the paper\'s choice (I5). The numbers are dimensions of subalgebras of spin(10) on the 16-dimensional space; they are not statements about energies or scales.</p>',
  'R7–R10'),

 ('S3', 'The five checkpoints of Roadmap II', ['standard', 'checked', 'open'],
  '<p>Roadmap II lists five checkpoints for an algebraic model: ⟨1⟩ heed or evade the Coleman–Mandula theorem, ⟨2⟩ solve fermion doubling, ⟨3⟩ explain chirality without an ad hoc projection, ⟨4⟩ exclude a low-energy B−L gauge symmetry, ⟨5⟩ explain three generations. '
  'It reports ⟨1⟩ to ⟨4⟩ passed and ⟨5⟩ not yet crossed.</p>'
  '<p>What can be tested inside the algebra: ⟨2⟩ the space has 32 complex dimensions and the left-handed projector has rank 16 (R3); ⟨3⟩ the chirality element Γ<sub>1</sub>⋯Γ<sub>10</sub> equals −R<sub>ε3</sub>, a right multiplication (A5); '
  '⟨4⟩ at the level of dimension only: the direct route of Roadmap III leaves 12 dimensions (R9), the dimension of su(3)⊕su(2)⊕u(1), and on the 16 states Y, Q and B−L have zero trace and zero sum of cubes (R11).</p>',
  '<p><b>Standard</b>: the five checkpoints and the paper\'s verdicts. <b>Checked</b>: the items above.</p>'
  '<p class="not"><b>Not tested.</b> ⟨1⟩ needs the spacetime side of the model, which is not built here. That B−L is not among the surviving generators of the 12-dimensional algebra is the paper\'s statement, not rebuilt. '
  '⟨5⟩ is the subject of S9 to S13.</p>',
  'A5, R3, R9, R11'),

 ('S4', 'Trialities: the Standard Model inside tri(ℂ)⊕tri(ℍ)⊕tri(𝕆)', ['standard', 'checked', 'open'],
  '<p>Furey and Hughes place su(3)⊕su(2)⊕u(1) inside tri(ℂ)⊕tri(ℍ)⊕tri(𝕆) acting on the triple (Ψ<sup>+</sup>, Ψ<sup>−</sup>, V), each a copy of ℂ⊗ℍ⊗𝕆 of 32 real dimensions. '
  'The 14 operators of eq. (24) are linearly independent derivations of 𝕆 (the algebra g<sub>2</sub>); the first 8 fix e<sub>7</sub> (su(3)), the last 6 move it (T1). '
  'On Ψ<sup>+</sup>, Ψ<sup>−</sup> and V, su(3) closes with rank 8 on all three, su(2) closes with rank 3 on Ψ<sup>−</sup> and V and acts as zero on Ψ<sup>+</sup>, su(3) and su(2) commute, and Y commutes with both (T2). '
  'Hypercharge spectra: Ψ<sup>+</sup> holds the right-handed weak singlets (|Y| = 0, 1/3, 2/3, 1) of two generations and their conjugates, Ψ<sup>−</sup> the left-handed doublets (|Y| = 1/6, 1/2); '
  'V has |Y| = 1/6, 1/2, 5/6, with the irreps (3,2,1/6), (3,2,−5/6) and (1,2,±1/2) of eq. (46) (T3). '
  'Cartan\'s triality principle δ<sub>V</sub>(XY) = (δ<sub>+</sub>X)Y + X(δ<sub>−</sub>Y) holds for 20 random elements, with error below 1e-10 (T4). '
  'The dimension counts of the Freudenthal–Tits forms are dim e<sub>7</sub> = 9 + 28 + 96 = 133 and dim e<sub>8</sub> = 28 + 28 + 192 = 248 (T5).</p>',
  '<p><b>Standard</b> (Furey and Hughes). <b>Checked</b> as stated; T5 is arithmetic only: that the sums are the dimensions of e<sub>7</sub> and e<sub>8</sub> is the paper\'s statement, and no e<sub>7</sub> or e<sub>8</sub> is built.</p>'
  '<p class="not"><b>Open.</b> The Cartan factorization that recasts V as a product of spinor and conjugate-spinor representations, and the third generation it supplies, are not rebuilt. '
  'The e<sub>7</sub> of the dimension count is not compared with any e<sub>7</sub> in which three generations appear in other work; only the dimension is common.</p>',
  'T1–T5'),

 ('S5', 'The octonion table is the XOR rule with a sign that does not associate', ['standard', 'checked', 'ours'],
  '<p>The explicit model of the 2026 paper builds the octonions by Cayley–Dickson from the quaternions, and the indices 0 to 7 are 3-bit labels. In it the seven imaginary units square to −1 and the product of the units a and b is plus or minus the unit a ⊕ b (XOR of the labels), '
  'for all 64 pairs (Drawing 1; B1). The 7 lines {a, b, a ⊕ b} of imaginary units close like quaternion triples.</p>'
  '<p>What sets the octonions apart is the sign. The ordered triples of three distinct imaginary units that are not on a line anti-associate, (xy)z = −x(yz): there are 168 of them, and every triple on a line or with a repeated unit associates (B1). '
  'Example: (e<sub>%%AX%%</sub>e<sub>%%AY%%</sub>)e<sub>%%AZ%%</sub> = %%AL%%e<sub>%%AK%%</sub> and e<sub>%%AX%%</sub>(e<sub>%%AY%%</sub>e<sub>%%AZ%%</sub>) = %%AR%%e<sub>%%AK%%</sub>.</p>',
  '%%FIG_OCT%%'
  '<p><b>Standard</b>: the octonion product. <b>Checked</b> (B1, computed from the product of the explicit model, independently of the scripts the wrapper runs): all 64 products and the 168 triples.</p>'
  '<p><b>Ours</b> (a reading). The labels 0 to 7 are the bits of the rule and the product is the rule\'s XOR with a sign. The sign is not the sign of any Clifford cell: the products of a Clifford cell associate, these do not on 168 triples. '
  'So the octonions are the 8 labels of the rule with a sign that fails to associate exactly there.</p>',
  'B1'),

 ('S6', 'The sixteen axes, the Hamming code and the complex structure', ['standard', 'checked', 'ours', 'input'],
  '<p>The model\'s space is V = 𝕆 ⊕ 𝕆′ of 16 real dimensions. The eight generators of Cl(0,8) on V (seven built from the left multiplications by the imaginary units, one from the identity, all off the diagonal of the two copies) square to −1 and anticommute (B2). '
  'So End<sub>ℝ</sub>(V) = M<sub>16</sub>(ℝ) = Cl(0,8) has the 256 blades of an 8-bit label, and all 65,536 products of blades are plus or minus the blade of the XOR of the labels (B2).</p>'
  '<p>The seven blades g<sub>a</sub>g<sub>b</sub>g<sub>c</sub>g<sub>8</sub> over the Fano lines commute, square to +1 and are diagonal in the standard basis: their 16 joint eigenspaces are the coordinate axes of V (B3). '
  'The faces of the axes form the extended Hamming code, with 1 word of weight 0, 14 of weight 4 and 1 of weight 8, and every 3 of the 8 points lie on exactly one word of weight 4, the Steiner system S(3,4,8) (B3). '
  'The complex structure ω = L<sub>e7</sub> on both copies is a single blade of grade 6, the face {0, 1, 3, 4, 5, 6} with label 123 = 01111011; it squares to −1, and the blades that commute with it number 128 (B4).</p>',
  '<p><b>Standard</b>: End<sub>ℝ</sub>(V) ≅ Cl(0,8). <b>Checked</b>: B2 to B4.</p>'
  '<p><b>Ours</b> (a reading). End<sub>ℝ</sub>(V) is the cell of 8-bit labels; the axes of V are its diagonal part and carry the code. The reading adds no check beyond B2 to B4.</p>'
  '<p class="not"><b>Input.</b> The complex structure ω. The rule offers many elements that square to −1; ω = L<sub>e7</sub> is the paper\'s choice, and it is one blade of grade 6 in this labelling (Inputs, I2).</p>',
  'B2–B4'),

 ('S7', 'The Peirce blocks of End(V)', ['standard', 'checked', 'input'],
  '<p>With (L<sub>e7</sub>R<sub>e7</sub>)² = +1 the projectors ½(1 ∓ L<sub>e7</sub>R<sub>e7</sub>) and the projectors onto the quaternion, complex, e<sub>7</sub>ℝ and real parts are orthogonal idempotents with sum 1 and real ranks (2, 6, 4, 2, 1, 1): '
  'diagonal Σn² = 62, off the diagonal 256 − 62 = 194 (B5).</p>'
  '<p>ω commutes with the first four blocks and exchanges the last two rank-1 blocks, so End<sub>ℂ</sub>(V) = M<sub>8</sub>(ℂ) has block sizes (1, 3, 2, 1, 1): diagonal 16, off the diagonal 48 (complex), total 64. '
  'The centralizer dimensions are (32, 20, 8, 2, 1), and the gauge algebra of the paper has real dimension 31 = 20 + 8 + 2 + 1; Tr<sub>ℂ</sub> Y = 3 (B6).</p>'
  '%%FIG_BOARDS%%',
  '<p><b>Standard</b> (the paper\'s blocks). <b>Checked</b> in the explicit model: B5 and B6. The fusion of the two rank-1 blocks is computed from ω.</p>'
  '<p class="not"><b>Input.</b> ω (I2) decides which blocks fuse; the partition of the axes into blocks is a further input (I3, S14).</p>',
  'B5, B6'),

 ('S8', 'Hypercharge and electric charge as sums of projectors', ['standard', 'checked', 'input'],
  '<p>On the eight complex dimensions of V, Y = ⅓P<sub>𝕆₂</sub> + ½P<sub>ℍ</sub> + P<sub>ℂ</sub> and Q = ⅓P<sub>𝕆₂</sub> + P<sub>ℍ₂</sub> + P<sub>ℂ</sub>, where P<sub>ℍ₂</sub> projects onto the second component of the doublet block. '
  'The blocks of sizes (1, 3, 2, 1, 1) carry the hypercharges y = (0, 1/3, 1/2, 1, 0), and every block obeys the Standard Model relation 6Y = −2a − 3b (mod 6) for its triality a and isospin class b (F2). '
  'Tr Y = Tr Q = 3 over the 8 complex dimensions, so Y<sub>0</sub> = Y − 3/8 and Q<sub>0</sub> = Q − 3/8 are traceless (the paper\'s eqs. 44 and 45; F3). The trace Tr<sub>ℂ</sub> Y = 3 is also asserted in the explicit model (B6).</p>'
  '<p>3/8 = Tr<sub>ℂ</sub> Y / dim<sub>ℂ</sub> V is the shift that makes Y and Q traceless. This report makes no statement about a weak mixing angle.</p>',
  '<p><b>Standard</b> (the paper\'s formulas). <b>Checked</b>: F2, F3 and B6.</p>'
  '<p class="not"><b>Input.</b> The hypercharges of the blocks are the paper\'s assignment (I3). F2 shows that the assignment is consistent with the Standard Model relation; it does not force it.</p>',
  'F2, F3, B6'),

 ('S9', 'Ten edges, ten irreps: one generation and eight complex dimensions more', ['checked', 'ours', 'input', 'open'],
  '<p>Between the five blocks of sizes (1, 3, 2, 1, 1) there are ten edges. The edge between blocks i and j has capacity 2n<sub>i</sub>n<sub>j</sub> complex dimensions in both directions; the ten capacities sum to 48, the largest being 2·3·2 = 12, and one direction carries 24 (B7). '
  'Under the commutator action ad<sub>Y</sub> acts on each Peirce piece as y<sub>i</sub> − y<sub>j</sub> (B7). The edge from block i to block j carries the irrep block(j) ⊗ conjugate block(i).</p>'
  '<p>Six edges carry Q<sub>L</sub> (3,2,+1/6), u<sub>R</sub> (3,1,+2/3), d<sub>R</sub> (3,1,−1/3), L (1,2,−1/2), e<sub>R</sub> (1,1,−1) and ν<sub>R</sub> (1,1,0), of complex dimensions 6, 3, 3, 2, 1, 1: 16 in all, one generation. '
  'The four others hold 8 more, 3 + 2 + 1 + 2, so one direction carries 24 (B8). Counted by irrep, the ten edges hold Q<sub>L</sub> once, u<sub>R</sub> once, the triplet (3,1,−1/3) twice, the doublet (1,2,∓1/2) three times, the charged singlet (1,1,∓1) twice and (1,1,0) once.</p>'
  '%%TAB_EDGES%%',
  '<p><b>Checked</b>: B7, B8 and, for the labels of the table, F1.</p>'
  '<p><b>Ours</b> (a reading). The count "one generation and 8 more" is a count of irreps by type; B8 counts the irreps and F1 matches them to the labels of the figure.</p>'
  '<p class="not"><b>Input.</b> Several edges carry the same irrep (three doublets, two triplets, two charged singlets). The gauge numbers cannot say which edge is which particle: the labels of Fig. 1 do (I4).</p>'
  '<p class="not"><b>Open.</b> Whether the 8 complex dimensions beyond one generation are physical states is a question for the model, not for the counting.</p>',
  'B7, B8, F1'),

 ('S10', 'The board of Fig. 1 of the 2026 paper', ['standard', 'checked', 'input'],
  '<p>Fig. 1 of the paper arranges the hermitian 16 × 16 matrices as a 5 × 5 board: gauge bosons on the diagonal and, in each of the 20 off-diagonal cells, two labels (the top and the bottom row of the cell). '
  'A cell (row, column) is the operator from the block of its row to the block of its column, so its irrep is block(column) ⊗ conjugate block(row). '
  'All 20 cells match: both labels of every cell, daggers included, are exactly the irrep (colour, isospin, Y) of the Peirce edge from the row to the column, with the block sizes 1, 3, 2, 1, 1 and Y = 0, 1/3, 1/2, 1, 0 (F1). '
  'The electric charges of the components of each cell, computed from Q = ⅓P<sub>𝕆₂</sub> + P<sub>ℍ₂</sub> + P<sub>ℂ</sub>, are the charges of the particles the figure names: up-type 2/3, down-type −1/3, neutrinos 0, charged leptons −1, '
  '+1 and 0 for the doublet h, and the negatives in the dagger cells (F4).</p>'
  '<p>The cells (1,2), (1,3), (1,4), (0,2), (0,3), (0,4) and their transposes carry Q<sub>L</sub> = (u, d), u<sub>R</sub>, d<sub>R</sub>, L = (ν<sub>e</sub>, e), e<sub>R</sub>, ν<sub>eR</sub>; '
  'the cells (0,1), (2,3), (2,4), (3,4) and their transposes carry b<sub>R</sub>, h, the doublet (ν<sub>τ</sub>, τ) and τ<sub>R</sub>.</p>'
  '%%FIG_BOARD%%',
  '<p><b>Standard</b>: the figure and its labels are the paper\'s. <b>Checked</b>: F1 and F4, the gauge quantum numbers of all 20 cells.</p>'
  '<p class="not"><b>Input.</b> The labels themselves: which cell is which particle, with which handedness and generation (I4). The checks compare colour, isospin, hypercharge and electric charge; they cannot tell which of equal irreps is which.</p>'
  '<p class="not">Not said: that the cells are particle states. The board is a bookkeeping of irreps. The figure originates in a paper that has not been read (Limits).</p>',
  'F1, F4'),

 ('S11', 'Counting complete sets: two conventions, kept apart', ['checked', 'ours', 'open'],
  '<p>A complete set is the six irreps Q<sub>L</sub>, u<sub>R</sub>, d<sub>R</sub>, L, e<sub>R</sub>, ν<sub>R</sub>, of 16 complex dimensions. The board can be counted in two ways.</p>'
  '<p><b>One label per cell</b> (on-shell, End<sub>ℂ</sub>(V) = M<sub>8</sub>(ℂ)). The 20 cells hold 2 Q<sub>L</sub>, 2 u<sub>R</sub>, 4 d<sub>R</sub>, 6 L, 4 e<sub>R</sub> and 2 ν<sub>R</sub>, a field and its conjugate each counted once (by the irrep of the cell, so b<sub>R</sub> counts as d<sub>R</sub>, and h and (ν<sub>τ</sub>, τ) as L). '
  'A complete set is a cell and its transpose, so there is one complete set, and 8 complex dimensions beyond it: b<sub>R</sub>, τ<sub>R</sub> and two doublets (C1).</p>'
  '<p><b>Every cell doubled</b> (the hermitian 16 × 16 form of Fig. 1). There are two complete sets, and exactly the irreps of Q<sub>L</sub>, u<sub>R</sub> and ν<sub>R</sub> lack a third copy (the top-quark irreps and a third right-handed neutrino); d<sub>R</sub>, L and e<sub>R</sub> have enough (C2).</p>'
  '<p>A third count runs over all of End<sub>ℝ</sub>(V), 256 real dimensions = 128 + 128: the linear operators, 64 complex = 16 (diagonal) + 48 (off the diagonal, all of Standard Model type, exotic content 0), and the antilinear operators, 64 complex, of which 32 carry exotic charges (B11).</p>'
  '%%TAB_COUNTS%%',
  '<p><b>Checked</b>: C1, C2 and B11.</p>'
  '<p><b>Ours</b> (a reading). The paper presents Fig. 1 as three generations apart from the representations that involve the top quark. In these counts that reads: two complete sets, plus the d<sub>R</sub>, L and e<sub>R</sub> of a third. '
  'The third copy of ν<sub>R</sub> is also absent, which the presentation does not mention.</p>'
  '<p class="not"><b>Open.</b> What the doubling means: with one label per cell the board holds one complete set, doubled it holds two. Whether the second label is a second generation, a conjugate, or the hermitian form\'s own redundancy is not decided by the counting.</p>',
  'C1, C2, B11'),

 ('S12', 'The missing irreps as products of the extra ones', ['checked', 'open'],
  '<p>Three irreps are missing for a third complete set: those of Q<sub>L</sub>, u<sub>R</sub> and ν<sub>R</sub>. Each is a product of irreps that the board has: '
  'b<sub>R</sub> ⊗ h contains (3,2,+1/6), the irrep of Q<sub>L</sub>; b<sub>R</sub> ⊗ τ<sub>R</sub><sup>†</sup> contains (3,1,+2/3), the irrep of u<sub>R</sub>; '
  'h ⊗ the lepton doublet (ν<sub>τ</sub>, τ)<sub>L</sub> contains (1,1,0), the irrep of ν<sub>R</sub> (P1).</p>'
  '<p>First pair: colour 3 ⊗ 1 = 3, isospin 1 ⊗ 2 = 2, hypercharge −1/3 + 1/2 = +1/6. Second pair: colour 3, isospin 1, hypercharge −1/3 + 1 = +2/3. '
  'Third pair: colour 1, isospin 2 ⊗ 2 = 1 ⊕ 3, hypercharge 1/2 − 1/2 = 0, so (1,1,0) comes with an isospin-triplet partner (1,3,0).</p>',
  '<p><b>Checked</b> (P1): each product contains the target irrep.</p>'
  '<p class="not"><b>Open.</b> These are tensor products of irreps, so they show that the quantum numbers can be recovered, nothing more. Whether the products are physical states, and with which dynamics, is not computed. '
  'Whether the recombination of b′<sub>R</sub>, h′ and τ′<sub>R</sub> in the 2026 paper and the Cartan factorization of the 2024 paper (S4) are two views of one mechanism is not decided; a comparison would need the explicit factorization of V.</p>',
  'P1'),

 ('S13', 'Room: how many complete sets fit in a given dimension', ['checked', 'ours', 'input'],
  '<p>Take all admissible block structures of complex dimension d: blocks of size 1, 2, 3 and 3̄ with Standard Model hypercharges |y| ≤ 2. The linear off-diagonal cells hold complete sets, a field and its conjugate counted together. '
  'At d = 8 there are 5,582 structures and none holds more than one set; the paper\'s holds one. Up to dimension 10 at most one set fits, from 11 to 13 at most two, and three sets (S = 6) appear first at dimension 14 (N2). '
  'The fast counter used equals the direct decomposition of <code>threegen_selfcheck.py</code> on the paper\'s frame and on 300 random structures (N1).</p>'
  '<p>A different count includes the antilinear operators and counts the irrep itself, not its conjugate. With it the number of complete generations is 1 in the paper\'s frame and 1 in its conjugate, and over all 5,582 admissible structures of dimension 8 it is at most 2 '
  '(histogram 0: 5,463, 1: 103, 2: 16): no structure gives 3 (B12). The two counts answer different questions and are not compared with each other.</p>'
  '%%FIG_ROOM%%',
  '<p><b>Checked</b>: N1, N2 and B12.</p>'
  '<p><b>Ours</b> (a reading and a choice). The family of structures searched is ours, not the paper\'s (I7); the convention of the count is a further choice (I6).</p>'
  '<p class="not"><b>Not said.</b> This is a statement about gauge quantum numbers in a family of block structures. It does not say that three generations of nature must come from a bigger block.</p>',
  'N1, N2, B12'),

 ('S14', 'What the construction chooses: the partition of the axes and the ℤ₂ question', ['checked', 'input', 'open'],
  '<p>Every block projector is a sum of axes (blade grades 0, 4, 8); the Cayley–Dickson flag is a nested affine flag of axes, and the 6-block is not affine. '
  'Of 18,480 independent commuting grade-4 quadruples, 616 diagonalize all the block projectors: the partition of the 16 axes into blocks is input of the construction, not forced by the Witt pairing (B9).</p>'
  '<p>The alternative complex structure ω′ = −R<sub>e7</sub> also commutes with the blocks. It differs from ω by a diagonal sign matrix, ω′ = ωD, with D = −1 on exactly the four axes 0, 3, 8, 11, '
  'while a torus generator (a Fano-line blade) has eight −1 signs: no single torus element relates ω and ω′ (B10).</p>',
  '<p><b>Checked</b>: B9 and B10.</p>'
  '<p class="not"><b>Input.</b> The partition (I3) and the choice between ω and ω′ (I2).</p>'
  '<p class="not"><b>Open.</b> The ℤ<sub>2</sub> parallel, the left-right swap seen as a gauge element, is not established here. Whether another way exists to see the swap as a gauge element is not decided.</p>',
  'B9, B10'),
]

# dictionary rows: (object, in the bit rule, tags, check ids)
DICT = [
 ('The units of 𝕆, e<sub>0</sub> to e<sub>7</sub>', 'The 8 labels 0 to 7 (3 bits); e<sub>a</sub>e<sub>b</sub> = ±e<sub>a⊕b</sub>, with a sign that fails to associate on 168 ordered triples', 'checked · ours', 'B1'),
 ('The 7 lines of the Fano plane', 'The triples {a, b, a⊕b} of non-zero labels: the triples on which the sign associates', 'checked', 'B1'),
 ('The octonion and quaternion units of the Roadmap', 'The Roadmap\'s own multiplication table, with its own numbering of the units (eq. 22); the explicit model of the 2026 paper, with the 3-bit labels, is read in B1', 'standard · checked', 'A1–A3'),
 ('The ten matrices Γ<sub>p</sub> of Cl(0,10)', 'Ten generators that square to −1 and anticommute: the 10-bit cell; the 45 bivectors are the labels with two bits set', 'standard · checked · ours', 'A4, R4, R5'),
 ('The chirality element Γ<sub>1</sub>⋯Γ<sub>10</sub>', 'The label with all ten bits set (the volume element), equal to −R<sub>ε3</sub>', 'checked · ours', 'A5'),
 ('Ladder operators, vacuum, P<sub>L</sub>', 'Canonical anticommutation pairs built from the generators; the vacuum is a projector of rank 1, P<sub>L</sub> of rank 16', 'standard · checked · input', 'R1–R3'),
 ('spin(10) and su(5) on Ψ<sub>L</sub>', 'The 45 bivector labels acting on the 16-dimensional space; su(5) as the 24 generators that annihilate the vacuum', 'checked', 'R4–R6'),
 ('The four reflections', 'Conjugation by L<sub>e7</sub>, R<sub>e7</sub>, L<sub>ε3</sub> and by complex conjugation; each cuts the 45 generators to a subalgebra', 'standard · checked · input', 'R7–R10'),
 ('Hypercharge, electric charge, B−L on the 16 states', 'Elements of the algebra with the spectra of the Standard Model values; trace and sum of cubes are 0', 'checked', 'R11'),
 ('The derivations of 𝕆 (g<sub>2</sub>), triality maps', 'Fourteen operators on the 8 labels; eight fix e<sub>7</sub>, six move it', 'standard · checked', 'T1–T4'),
 ('V = 𝕆 ⊕ 𝕆′ and End<sub>ℝ</sub>(V)', 'The cell Cl(0,8) of 8-bit labels: 256 blades, products ± the blade of the XOR of the labels', 'standard · checked · ours', 'B2'),
 ('The 16 axes of V', 'The 16 joint eigenspaces of the seven Fano-line blades; their faces are the words of the extended Hamming code (S(3,4,8))', 'checked · ours', 'B3'),
 ('The complex structure ω = L<sub>e7</sub>', 'One blade of grade 6, label 123; 128 blades commute with it', 'checked · input', 'B4, B10'),
 ('The Peirce blocks (2, 6, 4, 2, 1, 1) and (1, 3, 2, 1, 1)', 'Sums of axes: projectors of blade grades 0, 4, 8; the partition of the axes is input', 'checked · input', 'B5, B6, B9'),
 ('Y and Q', 'Short sums of block projectors with the hypercharges y = (0, 1/3, 1/2, 1, 0); Tr Y = Tr Q = 3', 'standard · checked · input', 'F2, F3, B6'),
 ('The ten edges', 'The off-diagonal Peirce pieces; capacity 2n<sub>i</sub>n<sub>j</sub>; irrep block(j) ⊗ conjugate block(i)', 'checked', 'B7, B8'),
 ('The cells of Fig. 1', 'The same ten edges in both directions; the labels are the paper\'s, the gauge numbers are compared', 'standard · checked · input', 'F1, F4'),
 ('A complete set', 'The six irreps Q<sub>L</sub>, u<sub>R</sub>, d<sub>R</sub>, L, e<sub>R</sub>, ν<sub>R</sub>; counted by cells, by cells doubled, or over End<sub>ℝ</sub>(V)', 'checked · ours · input', 'C1, C2, B11, B12'),
 ('The composite irreps', 'Tensor products of the irreps of two cells', 'checked · open', 'P1'),
 ('The room of a block structure', 'Complete sets of all admissible structures of a given dimension', 'checked · ours · input', 'N1, N2'),
]

INPUTS = [  # (id, what the physics page needs, what the algebra does supply, checks)
 ('I1', 'The ten matrices Γ<sub>p</sub>, the ladder operators and the left-handed projector of the Roadmap',
  'Many sets of ten anticommuting generators that square to −1 (the cell Cl(0,10)); the paper\'s choice (eq. 25) is used', 'A4, A5, R1–R3'),
 ('I2', 'A complex structure on V: ω = L<sub>e7</sub> on both copies',
  'Many elements that square to −1. ω is one blade of grade 6, 128 blades commute with it, and ω′ = −R<sub>e7</sub> also commutes with the blocks (ω′ = ωD, D = −1 on four axes)', 'B4, B10'),
 ('I3', 'The partition of the 16 axes into blocks (2, 6, 4, 2, 1, 1) and the hypercharges y = (0, 1/3, 1/2, 1, 0)',
  'The axes and the Hamming code. Of 18,480 independent commuting quadruples 616 diagonalize the block projectors, so the partition is not forced; the hypercharges obey 6Y = −2a − 3b (mod 6), a consistency condition', 'B9, F2, F3'),
 ('I4', 'The labels of Fig. 1: which cell is which particle, with which handedness and generation',
  'The gauge numbers (colour, isospin, hypercharge, electric charge) of each edge; three doublets, two triplets and two charged singlets share their irreps and are not told apart by them', 'F1, F4, B8'),
 ('I5', 'Which reflections are switched on and in which order (the ladders of the Roadmap), and the vacuum',
  'The dimension of the subalgebra left by each choice', 'R7–R10'),
 ('I6', 'What counts as a complete set: the sector (linear off-diagonal only, or with the antilinear operators), a field and its conjugate once or twice, one label or both labels per cell',
  'The counts of each convention; they differ because the conventions differ', 'C1, C2, N2, B11, B12'),
 ('I7', 'The family of block structures searched: sizes 1, 2, 3, 3̄ and Standard Model hypercharges |y| ≤ 2',
  'A finite list: 5,582 structures at dimension 8, at most 2 complete generations in each', 'N1, N2, B12'),
]

LIMITS_REACH = [
 '<b>Dynamics.</b> The checks are about algebra and gauge quantum numbers. No Lagrangian, equation of motion or spacetime side is built; the checkpoint of Coleman–Mandula is not tested (S3).',
 '<b>The Cartan factorization of Trialities.</b> The factorization of V into spinor and conjugate-spinor representations, and the third generation it supplies, are not rebuilt (S4).',
 '<b>The physical status of the cells.</b> That a cell, the 8 complex dimensions beyond one generation, or a product of irreps is a particle state is not tested (S9 to S12).',
 '<b>Masses, couplings, mixing.</b> Not touched. A count of irreps says nothing about them.',
 '<b>Three generations.</b> The counts show what the board holds as irreps and how much room a block structure needs; they do not decide whether the model explains three generations.',
]
LIMITS_DONE = [
 '<b>The superalgebra paper has not been read.</b> Its figure is taken as printed in the 2026 paper, and only the gauge quantum numbers of its cells are checked (S10). The ℤ<sub>2</sub><sup>5</sup>-grading and the Jordan-algebra structure are not touched.',
 'Equation and figure numbers are those of the arXiv copies named in the header of <code>furey_papers_check.py</code>: the copy of Roadmap I of December 2024, the copies of Roadmap II and III of December 2023, of Trialities of October 2024 and of the nested-embeddings paper of August 2026. Another copy may number differently.',
 'The numerical checks use floating point with the tolerances their lines state (1e-9 to 1e-10); the counts of irreps use exact fractions and integers.',
 'The three scripts that build the explicit model (<code>run_all.py</code>, <code>dictionary_selfcheck.py</code>, <code>threegen_selfcheck.py</code>) assert their own results; the wrapper <code>furey_construction_check.py</code> requires each to pass and reads the data they write. Only B1 is computed in the wrapper, from the product of <code>model.py</code>.',
 'The counts of S11 and S13 use different conventions (I6) and different sectors; each is stated with its check id and none is compared with another.',
 'The scripts were written by the same authors as the atlas: independent here means that the wrapper and the mutation script test the scripts against changed lines, not that someone else wrote them.',
]

SOURCES = [
 'N. Furey, <i>An Algebraic Roadmap of Particle Theories, Part I: General construction</i>, <a href="https://arxiv.org/abs/2312.12377">arXiv:2312.12377</a> (December 2023): the explicit algebra, eqs. (22) and (25), Figs. 4 and 5.',
 'N. Furey, <i>An Algebraic Roadmap of Particle Theories, Part II: Theoretical checkpoints</i>, <a href="https://arxiv.org/abs/2312.12799">arXiv:2312.12799</a> (December 2023): the five checkpoints.',
 'N. Furey, <i>An Algebraic Roadmap of Particle Theories, Part III: Intersections</i>, <a href="https://arxiv.org/abs/2312.14207">arXiv:2312.14207</a> (December 2023): the intersections and the single constraint.',
 'N. Furey and M. J. Hughes, <i>Three Generations and a Trio of Trialities</i>, <a href="https://arxiv.org/abs/2409.17948">arXiv:2409.17948</a> (September 2024): eqs. (24) and (46), the Freudenthal–Tits counts.',
 'N. Furey, <i>A Superalgebra Within: representations of lightest Standard Model particles form a ℤ<sub>2</sub><sup>5</sup>-graded algebra</i>, <a href="https://arxiv.org/abs/2505.07923">arXiv:2505.07923</a> (May 2025): not read; its figure as reproduced in the 2026 paper.',
 'N. Furey, <i>Standard Model Symmetries and the Nested Embeddings of ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆</i>, <a href="https://arxiv.org/abs/2607.18450">arXiv:2607.18450</a> (July 2026): the blocks, the edges, eqs. (44) and (45), Fig. 1.',
 'The atlas package: Calibration 2 (Furey); <code>selfcheck/furey_papers_check.py</code>, <code>threegen_selfcheck.py</code>, <code>dictionary_selfcheck.py</code> with <code>model.py</code> and <code>run_all.py</code> (copied here byte for byte).',
]

CHECK_BLOCKS = [  # (first letter of the id, what it tests, script)
 ('A', 'The explicit algebra of Roadmap I: octonion and quaternion units, R<sub>e7</sub> and L<sub>e7</sub>, the ten Γ matrices, the chirality element', 'furey_papers_check.py'),
 ('R', 'Roadmap I to III: ladder operators, vacuum, P<sub>L</sub>, the 45 generators, su(5), the two ladders, the intersections, Y, Q and B−L', 'furey_papers_check.py'),
 ('T', 'Trialities: the 14 derivations, the Standard Model action, the hypercharge spectra, the triality principle, the dimension counts', 'furey_papers_check.py'),
 ('F', 'Fig. 1 of the 2026 paper against the ten Peirce edges: every label, the relation 6Y = −2a − 3b, the traces, the electric charges', 'furey_papers_check.py'),
 ('C', 'Counting complete sets on the board, one label per cell and doubled', 'furey_papers_check.py'),
 ('P', 'The irreps Fig. 1 lacks, as products of irreps it has', 'furey_papers_check.py'),
 ('N', 'Room: complete sets in all admissible block structures of dimension 8 to 14', 'furey_papers_check.py'),
 ('B', 'The explicit model of the 2026 paper: the octonion table as XOR with a sign, Cl(0,8), the axes and the code, ω, the blocks, the edges, the partition, the sectors, the search', 'furey_construction_check.py'),
]
