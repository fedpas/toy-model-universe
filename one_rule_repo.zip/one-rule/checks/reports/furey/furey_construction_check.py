#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The explicit 16-dimensional model of Furey's nested-embeddings paper, run and read: this wrapper runs the three scripts of the atlas that build it (run_all.py with model.py,
dictionary_selfcheck.py, threegen_selfcheck.py; byte-identical copies in this folder) in a temporary folder, requires each to pass its own assertions, reads the data they write and prints one
line `ok   B<n>: <statement>` per statement of the report that rests on them (FAIL if the script fails or the number differs).  numpy only.   Run: python3 furey_construction_check.py"""
import os, sys, json, subprocess, tempfile, shutil, itertools
HERE = os.path.dirname(os.path.abspath(__file__))
NOK = NBAD = 0
def check(i, text, cond):
    global NOK, NBAD
    if cond: NOK += 1
    else: NBAD += 1
    print(('ok   ' if cond else 'FAIL ') + 'B%d: %s' % (i, text))

def run(td, script, *args):
    r = subprocess.run([sys.executable, script, *args], cwd=td, capture_output=True, text=True, timeout=900)
    return r.returncode == 0, r.stdout
with tempfile.TemporaryDirectory() as td:
    for f in ('model.py', 'run_all.py', 'dictionary_selfcheck.py', 'threegen_selfcheck.py'): shutil.copy(os.path.join(HERE, f), td)
    ok_run, out_run = run(td, 'run_all.py'); ok_run = ok_run and 'ALL FUREY CHECKS PASS' in out_run
    ok_dic, out_dic = run(td, 'dictionary_selfcheck.py', '--write', 'dictionary.json'); ok_dic = ok_dic and 'ALL DICTIONARY CHECKS PASS' in out_dic
    ok_thr, out_thr = run(td, 'threegen_selfcheck.py', '--write', 'threegen.json'); ok_thr = ok_thr and 'ALL THREE-GENERATION CHECKS PASS' in out_thr
    R = json.load(open(os.path.join(td, 'furey_results.json'))) if ok_run else {}
    D = json.load(open(os.path.join(td, 'dictionary.json'))) if ok_dic else {}
    T = json.load(open(os.path.join(td, 'threegen.json'))) if ok_thr else {}

# ---- B1: the octonion table is the XOR rule with a sign (independent of the scripts above; model.py is only the product)
sys.path.insert(0, HERE)
import numpy as np
from model import omul, E
signs = {}
good = True
for a in range(8):
    for b in range(8):
        p = omul(E[a], E[b]); nz = np.nonzero(np.abs(p) > 1e-12)[0]
        good &= len(nz) == 1 and nz[0] == a ^ b and abs(abs(p[nz[0]]) - 1) < 1e-12
        signs[(a, b)] = int(round(p[nz[0]])) if len(nz) == 1 else 0
lines = sorted({tuple(sorted((a, b, a ^ b))) for a in range(1, 8) for b in range(1, 8) if a != b})
assoc = lambda x, y, z: omul(omul(E[x], E[y]), E[z]) - omul(E[x], omul(E[y], E[z]))
na = 0; line_ok = True
for x, y, z in itertools.product(range(1, 8), repeat=3):
    d = assoc(x, y, z); on_line = len({x, y, z}) < 3 or tuple(sorted((x, y, z))) in lines
    if on_line: line_ok &= bool(np.allclose(d, 0))
    else:
        na += 1
        line_ok &= bool(np.allclose(omul(omul(E[x], E[y]), E[z]), -omul(E[x], omul(E[y], E[z]))))
squares = all(np.allclose(omul(E[a], E[a]), -E[0]) for a in range(1, 8))
check(1, 'in the explicit model (Cayley–Dickson indices 0 to 7 are 3-bit labels) the seven imaginary units square to -1 and the product of the units a and b is plus or minus the unit a XOR b, for all 64 pairs; the 7 lines {a, b, a XOR b} of imaginary units close; '
         'the %d ordered triples of three distinct imaginary units off a line anti-associate, (xy)z = -x(yz), and every triple on a line or with a repeated unit associates' % na, good and squares and len(lines) == 7 and na == 168 and line_ok)

# ---- B2, B3, B4: the dictionary script (Cl(0,8) blades as 8-bit labels, the Hamming code of the axes, omega)
check(2, 'the 8 generators of Cl(0,8) on V = O + O\' (16 real dimensions) square to -1 and anticommute, and the 256 blades, labelled by 8-bit masks, multiply as plus or minus the blade of the XOR of the labels '
         '(all 65,536 products; dictionary_selfcheck.py passes)', ok_dic and D['cube8']['vertices'] == 256 and D['cube8']['edges'] == 1024)
check(3, 'the seven Fano-line blades times the eighth generator commute, square to +1 and are diagonal in the standard basis (run_all.py, 16 joint eigenspaces = the axes of V); '
         'their faces form the extended Hamming code, weights 0 (1 word), 4 (14 words), 8 (1 word), and every 3 of the 8 points lie on exactly one word of weight 4 (Steiner system S(3,4,8))',
      ok_run and ok_dic and R['witt']['fano_lines'] == 7 and R['witt']['line_blades_square_plus1'] and R['witt']['commute'] and R['witt']['diagonal_in_standard_basis'] and R['witt']['axes'] == 16
      and D['code']['weights'] == {'0': 1, '4': 14, '8': 1} and D['code']['steiner_S348'] is True)
check(4, 'omega = L_e7 on both copies is a single blade of grade 6 (face {0,1,3,4,5,6}, label 123 = 01111011), omega squares to -1 and the blades that commute with it number 128',
      ok_run and ok_dic and R['witt']['omega_is_single_grade_blade'] == 6 and D['omega']['face'] == [0, 1, 3, 4, 5, 6] and D['omega']['N'] == 123 and D['omega']['linear_faces'] == 128)

# ---- B5 to B8: blocks, centralizers, edges (run_all.py)
check(5, 'real Peirce blocks of End_R(V): the projectors (1 -+ L_e7 R_e7)/2, H, C, e7 R, R are orthogonal idempotents with sum 1 and real ranks (2, 6, 4, 2, 1, 1): diagonal 62, off the diagonal 194, total 256',
      ok_run and R['real_blocks'] == [2, 6, 4, 2, 1, 1] and R['real_diag'] == 62 and R['real_off'] == 194 and R['real_diag'] + R['real_off'] == 256)
check(6, 'omega commutes with the first four real blocks and exchanges the last two rank-1 blocks, so End_C(V) = M8(C) has block sizes (1, 3, 2, 1, 1): diagonal 16, off the diagonal 48 (complex), total 64; '
         'centralizer dimensions (32, 20, 8, 2, 1) and the gauge algebra of the paper has real dimension 31 = 20 + 8 + 2 + 1; Tr_C Y = 3',
      ok_run and R['blocks_commuting_with_omega'] == {'O1': True, 'O2': True, 'H': True, 'C': True, 'e7R': False, 'R': False} and R['complex_blocks'] == [1, 3, 2, 1, 1]
      and (R['complex_diag'], R['complex_off']) == (16, 48) and R['centralizers'] == {'O_L': 32, 'O_L_and_R': 20, 'H': 8, 'C': 2, 'R': 1} and R['delta_SM_real_dim'] == 31)
check(7, 'the ten edges between the five blocks have capacities 2 n_i n_j summing to 48 (largest 2*3*2 = 12), one direction 24; ad_Y acts on each Peirce piece as y_i - y_j (asserted in run_all.py)',
      ok_run and len(R['edges']) == 10 and sum(e['capacity_C'] for e in R['edges']) == 48 and max(e['capacity_C'] for e in R['edges']) == 12 and sum(e['one_way_C'] for e in R['edges']) == 24)
check(8, 'six edges carry Q_L (3,2,+1/6), u_R (3,1,+2/3), d_R (3,1,-1/3), L (1,2,-1/2), e_R (1,1,-1), nu_R (1,1,0) of complex dimensions 6, 3, 3, 2, 1, 1 = 16; the four others hold 8 more: 3 + 2 + 1 + 2 = 24 in all',
      ok_run and [m['dim_C'] for m in R['sm_matches']] == [6, 3, 3, 2, 1, 1] and R['sm_generation_dim'] == 16 and R['extras_dim'] == 8 and [x['dim_C'] for x in R['extras']] == [3, 2, 1, 2])

# ---- B9, B10: the axes, the Witt torus and the Z2 question (run_all.py)
W = R.get('witt', {})
check(9, 'every block projector is a sum of axes (blade grades 0, 4, 8), the Cayley-Dickson flag is a nested affine flag of axes, the 6-block is not affine; of 18480 independent commuting grade-4 quadruples, '
         '616 diagonalize all the block projectors: the partition of the 16 axes into blocks is input of the construction, not forced',
      ok_run and W['projector_grades'] == [0, 4, 8] and W['cayley_dickson_flag_affine'] == [True] * 4 and W['block_is_affine']['O2'] is False
      and W['independent_commuting_grade4_quadruples'] == 18480 and W['diagonalising_all_block_projectors'] == 616)
check(10, 'omega\' = -R_e7 is also a complex structure commuting with the blocks; omega\' = omega D with D = -1 on exactly the four axes 0, 3, 8, 11, while a torus generator has eight -1 signs: no single torus element relates omega and omega\'',
      ok_run and R['omega_alt_minus_R_works'] is True and R['omega_prime_over_omega_minus_axes'] == [0, 3, 8, 11] and len(R['omega_prime_over_omega_minus_axes']) == 4)

# ---- B11, B12: the sectors and the exhaustive search of threegen_selfcheck.py
check(11, 'End_R(V) has 256 real dimensions = 128 + 128: linear operators 64 complex = 16 (diagonal) + 48 (off the diagonal, all of Standard Model type, exotic content 0); antilinear operators 64 complex, of which 32 carry exotic charges',
      ok_thr and T['dimensions'] == {'antilinear_complex': 64, 'antilinear_complex_check': 64, 'diagonal_complex': 16, 'linear_complex': 64, 'linear_off_diagonal_complex': 48, 'real_total': 256}
      and T['exotic'] == {'antilinear': 32, 'linear_off_diagonal': 0})
sa = T.get('search_all', {})
check(12, 'the number of complete generations (the smallest multiplicity of the six irreps Q_L, u_R, d_R, L, e_R, nu_R in the linear off-diagonal and the antilinear operators of End_R(V)) is 1 in the paper\'s frame and 1 in its conjugate; '
          'over all %s admissible block structures of complex dimension 8 (blocks of size 1, 2, 3 and 3-bar, Standard Model hypercharges) it is at most 2 (histogram 0: 5463, 1: 103, 2: 16): no structure gives 3' % ('5,582'),
      ok_thr and T['generations'] == {'furey_frame': 1, 'furey_frame_conjugate': 1} and sa['admissible_W'] == 5582 and sa['max_generations'] == 2 and sa['histogram'] == {'0': 5463, '1': 103, '2': 16}
      and T['search_peirce_frame']['assignments'] == 4000 and max(int(k) for k in T['search_peirce_frame']['histogram']) == 2)
print('\nchecks: %d ok, %d failed' % (NOK, NBAD)); sys.exit(1 if NBAD else 0)
