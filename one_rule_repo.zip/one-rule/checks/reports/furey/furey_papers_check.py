#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Furey's papers, rebuilt and counted: the exact checks behind the Furey page.   numpy for parts A, R and T; the rest is standard library.
  python3 furey_papers_check.py                       run all checks (about 15 seconds)
  python3 furey_papers_check.py --write f.json        also write the data the page reads (furey_papers.json)
  python3 furey_papers_check.py --compare f.json      assert that the stored data equals the rebuilt data

Papers (arXiv stamps as printed on the copies we read):
  Roadmap I   N. Furey, An Algebraic Roadmap of Particle Theories, Part I: General construction, arXiv:2312.12377 (v1 Dec 2023, v2 19 Dec 2024)
  Roadmap II  ... Part II: Theoretical checkpoints, arXiv:2312.12799 v1, 20 Dec 2023
  Roadmap III ... Part III: Intersections, arXiv:2312.14207 v1, 21 Dec 2023
  Trialities  N. Furey, M.J. Hughes, Three Generations and a Trio of Trialities, arXiv:2409.17948 v2, 9 Oct 2024
  Nested      N. Furey, Standard Model Symmetries and the Nested Embeddings of R, C, H, O, arXiv:2607.18450 v2, 31 Aug 2026 (the page of the atlas)
Parts
  A  the explicit algebra of Roadmap I (octonions, quaternions, left and right multiplications on C x H x O, 32 complex dimensions)
  R  Roadmap I-III: the ladder operators and the vacuum, the 45 generators of spin(10) in left-multiplication form, the multivector condition,
     the division-algebraic reflections as conjugations, the dimension ladders of Figures 4 and 5, the intersections of Part III, Y, Q and B-L on Psi_L
  T  Trialities: the 14 derivations of O, the Standard Model action on H x O, the hypercharge spectra of Psi+, Psi-, V, Cartan's triality principle
  F  Fig. 1 of the nested-embeddings paper against the ten Peirce edges: every label of every off-diagonal cell, daggers included
  C  counting: how many complete Standard Model sets the cells of Fig. 1 hold, on-shell (one label per cell) and with every cell doubled
  P  the irreps that Fig. 1 lacks (those of the top quark and nu_tau,R), as products of irreps it has
  N  room: how many complete sets 8, 9, ..., 14 complex dimensions of admissible blocks can hold (same blocks and rules as threegen_selfcheck.py)"""
import argparse, itertools, json, os, sys
from fractions import Fraction as F
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import threegen_selfcheck as tg
from threegen_selfcheck import FUREY_W, SM, dual, dim, tensor, fmt, admissible_blocks

OK = []
def ok(name):
    OK.append(name); print('ok  ', name)
def rat(x, den=6):
    fr = F(round(x * den), den); assert abs(x - float(fr)) < 1e-8, x; return fr
def fr_s(x): return str(x)
def spec_s(c): return {str(k): v for k, v in sorted(c.items())}

D = {}

# =========================================================================== A: the explicit algebra
import numpy as np
trip = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
fo = np.zeros((8, 8, 8))
for (i, j, k) in trip:
    for (a, b, c) in [(i, j, k), (j, k, i), (k, i, j)]:
        fo[a, b, c] = 1; fo[b, a, c] = -1
def omul(i, j):
    if i == 0: return 1, j
    if j == 0: return 1, i
    if i == j: return -1, 0
    for k in range(1, 8):
        if fo[i, j, k] != 0: return int(fo[i, j, k]), k
LO = np.zeros((8, 8, 8)); RO = np.zeros((8, 8, 8))
for a in range(8):
    for j in range(8):
        s, k = omul(a, j); LO[a][k, j] = s
        s, k = omul(j, a); RO[a][k, j] = s
def qmul(i, j):
    if i == 0: return 1, j
    if j == 0: return 1, i
    if i == j: return -1, 0
    k = 6 - i - j; return int(round(np.linalg.det(np.eye(3)[[i - 1, j - 1, k - 1]]))), k
LH = np.zeros((4, 4, 4)); RH = np.zeros((4, 4, 4))
for a in range(4):
    for j in range(4):
        s, k = qmul(a, j); LH[a][k, j] = s
        s, k = qmul(j, a); RH[a][k, j] = s
I4, I8 = np.eye(4), np.eye(8)
Le = lambda a: np.kron(I4, LO[a]).astype(complex)
Re = lambda a: np.kron(I4, RO[a]).astype(complex)
Le_ = lambda m: np.kron(LH[m], I8).astype(complex)
Re_ = lambda m: np.kron(RH[m], I8).astype(complex)
ID = np.eye(32, dtype=complex); i_ = 1j * ID
dag = lambda M: M.conj().T
assert all(np.allclose(LO[a] @ LO[a], -np.eye(8)) for a in range(1, 8)) and np.allclose(LH[1] @ LH[2], LH[3]); ok('A1 octonion and quaternion units square to -1, e1 e2 = e3')
assert np.allclose(0.5 * (-LO[7] + LO[1] @ LO[3] + LO[2] @ LO[6] + LO[4] @ LO[5]), RO[7]); ok('A2 Roadmap I eq. (22): R_e7 = 1/2(-L_e7 + L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5)')
assert np.allclose(LO[7], LO[1] @ LO[2] @ LO[3] @ LO[4] @ LO[5] @ LO[6]); ok('A3 L_e7 = L_e1 L_e2 ... L_e6 (the volume element of Cl(0,6) is the seventh unit)')
G = {}
for j in range(1, 7): G[j] = i_ @ Le(j) @ Le(7) @ Re_(1)
for m in range(1, 4): G[m + 6] = Le(7) @ Le_(m) @ Re_(1)
G[10] = Re_(2)
assert all(np.allclose(G[p] @ G[q] + G[q] @ G[p], -2 * (p == q) * ID) for p in G for q in G); ok('A4 ten Gamma matrices of eq. (25): {G_p, G_q} = -2 delta_pq (Cl(0,10) on 32 complex dimensions)')
G11 = ID.copy()
for p in range(1, 11): G11 = G11 @ G[p]
assert np.allclose(G11, -Re_(3)); ok('A5 the chirality element G1...G10 is -R_eps3')

# =========================================================================== R: Roadmap I-III
adag = {1: .5 * (G[5] + 1j * G[4]), 2: .5 * (G[3] + 1j * G[1]), 3: .5 * (G[6] + 1j * G[2]), 4: .5 * (G[8] + 1j * G[7]), 5: .5 * (G[10] + 1j * G[9])}
alow = {1: .5 * (-G[5] + 1j * G[4]), 2: .5 * (-G[3] + 1j * G[1]), 3: .5 * (-G[6] + 1j * G[2]), 4: .5 * (-G[8] + 1j * G[7]), 5: .5 * (-G[10] + 1j * G[9])}
assert all(np.allclose(dag(alow[c]), adag[c]) for c in range(1, 6))
assert all(np.allclose(alow[c] @ adag[d] + adag[d] @ alow[c], (c == d) * ID) for c in range(1, 6) for d in range(1, 6))
assert all(np.allclose(alow[c] @ alow[d] + alow[d] @ alow[c], 0) for c in range(1, 6) for d in range(1, 6)); ok('R1 five ladder pairs: a_c^dagger = (a_c)^*, CAR {a_c, a_d^dagger} = delta, {a, a} = 0 (Roadmap I eqs. 28-31)')
Om = ID.copy()
for c in range(1, 6): Om = Om @ alow[c]
v = dag(Om) @ Om
assert np.allclose(v, dag(v)) and np.allclose(v @ v, v) and np.linalg.matrix_rank(v) == 1
vac = np.linalg.eigh(v)[1][:, -1]; ok('R2 the vacuum |0> = projector of rank 1 (Omega^dagger Omega)')
PL = .5 * (ID + 1j * G11)
assert np.allclose(PL @ PL, PL) and np.linalg.matrix_rank(PL) == 16 and np.allclose(PL @ vac, vac); ok('R3 P_L is a projector of rank 16 (one generation, left-handed) and contains the vacuum')
basis = []
for a in range(1, 8):
    for b in range(a + 1, 8): basis.append(Le(a) @ Le(b))
for m in range(1, 4):
    for n in range(m + 1, 4): basis.append(Le_(m) @ Le_(n))
for m in range(1, 4):
    for a in range(1, 8): basis.append(1j * Le_(m) @ Le(a))
assert len(basis) == 45
dirac = [G[p] @ G[q] for p in range(1, 11) for q in range(p + 1, 11)]
rank_of = lambda rows: np.linalg.matrix_rank(rows, tol=1e-9)
vecs = lambda mats: np.array([(M @ PL).ravel() for M in mats])
VL, VD = vecs(basis), vecs(dirac)
assert rank_of(VL) == rank_of(VD) == rank_of(np.vstack([VL, VD])) == 45; ok('R4 the 45 left-multiplication generators and the 45 Dirac bivectors act identically on Psi_L (rank 45 each, rank of the union 45)')
def closes(mats, P):
    V = np.array([(M @ P).ravel() for M in mats]); r0 = rank_of(V)
    ext = [((A @ B - B @ A) @ P).ravel()[None, :] for A in mats for B in mats]
    return rank_of(np.vstack([V] + ext)) == r0
assert closes(basis, PL); ok('R5 the 45 generators close under the commutator on Psi_L: spin(10) in its left-multiplication form')
def nullspace_real(cols):
    M = np.array(cols).T; Mr = np.vstack([M.real, M.imag]); u, s, vt = np.linalg.svd(Mr); rank = int((s > 1e-9).sum()); return vt[rank:]
bra0 = vac.conj()
# the multivector condition  <0| l = 0
N_d = nullspace_real([bra0 @ dirac[k] for k in range(45)]); N_L = nullspace_real([bra0 @ basis[k] for k in range(45)])
assert N_d.shape[0] == 24 and N_L.shape[0] == 24; ok('R6 multivector condition <0| l = 0 on spin(10): 24 dimensions (su(5)), in Dirac form and in left-multiplication form')
# the four reflections as conjugations
Le7i = np.linalg.inv(Le(7)); Re7i = np.linalg.inv(Re(7)); L3 = Le_(3); L3i = np.linalg.inv(L3)
refl = {'O': lambda M: Le(7) @ M @ Le7i, 'Or': lambda M: Re(7) @ M @ Re7i, 'H': lambda M: L3 @ M @ L3i, 'C': lambda M: M.conj()}
cond = {k: (lambda M, f=f: M - f(M)) for k, f in refl.items()}
def dim_of(keys, gens=None):
    gens = gens if gens is not None else [np.eye(45)[k] for k in range(45)]
    mats = [sum(c * B for c, B in zip(g, basis)) for g in gens]
    cols = [np.concatenate([(cond[k](M) @ PL).ravel() for k in keys]) if keys else np.zeros(1) for M in mats]
    A = np.array(cols).T; Ar = np.vstack([A.real, A.imag]); s = np.linalg.svd(Ar, compute_uv=False); rank = int((s > 1e-9).sum()); return len(gens) - rank
line1 = [('Spin(10)', [], 45), ('Pati-Salam', ['O'], 21), ('Left-Right', ['O', 'Or'], 15), ('UBZ+ = u(3)+u(1)+u(1)', ['O', 'Or', 'H'], 11), ('UB+ = u(3)+u(1)', ['O', 'Or', 'H', 'C'], 10)]
for nm, keys, want in line1: assert dim_of(keys) == want, (nm, dim_of(keys), want)
assert dim_of(['Or']) == 15 and dim_of(['O', 'Or', 'C']) == 12; ok('R7 Roadmap I Fig. 4, Spin(10) line: 45 -> 21 (Pati-Salam, su(4)+su(2)+su(2)) -> 15 (Left-Right) -> 11 (u(3)+u(1)+u(1)) -> 10 (u(3)+u(1)); the second octonionic reflection alone already gives 15')
# SU(5) line: express the 24 elements in the L-form
M = np.array([(B @ PL).ravel() for B in basis]).T; Mr = np.vstack([M.real, M.imag]); su5_L = []
for r in N_d:
    E = sum(c * Dm for c, Dm in zip(r, dirac)); t = (E @ PL).ravel(); tr = np.concatenate([t.real, t.imag]); x = np.linalg.lstsq(Mr, tr, rcond=None)[0]; assert np.allclose(Mr @ x, tr); su5_L.append(x)
line2 = [('SU(5)', [], 24), ('Standard Model (->O)', ['O'], 12), ('UBZ = su(3)+u(1)+u(1)', ['O', 'H'], 10), ('UB = su(3)+u(1)', ['O', 'H', 'C'], 9)]
for nm, keys, want in line2: assert dim_of(keys, su5_L) == want, (nm, dim_of(keys, su5_L), want)
assert dim_of(['Or'], su5_L) == 12 and dim_of(['O', 'C'], su5_L) == 9; ok('R8 Roadmap I Fig. 5, SU(5) line: 24 -> 12 (su(3)+su(2)+u(1)), either octonionic reflection -> 10 (quaternionic) -> 9 (complex); complex conjugation bypasses 12 -> 9')
# Part III: intersections.  [l, Psi_L] = l Psi_L  <=>  <0| l = 0 ; the further spinor actions are the reflections
Ls = 45
def dimsol(keys, vacuum=True):
    cols = []
    for k in range(Ls):
        B = basis[k]; parts = [bra0 @ B] if vacuum else []
        for key in keys: parts.append((cond[key](B) @ PL).ravel())
        cols.append(np.concatenate(parts))
    return Ls - nullspace_real(cols).shape[0] if False else nullspace_real(cols).shape[0]
inter = {'vector_spinor': dimsol([]), 'three_way_O': dimsol(['O']), 'five_way_O_H_C': dimsol(['O', 'H', 'C']), 'four_way_no_O': dimsol(['H', 'C'])}
assert inter == {'vector_spinor': 24, 'three_way_O': 12, 'five_way_O_H_C': 9, 'four_way_no_O': 9}, inter
ok('R9 Roadmap III: V = spinor intersection 24 (su(5)); three-way with the octonionic spinor 12 (su(3)+su(2)+u(1)); five-way with the quaternionic and complex spinors 9 (su(3)+u(1)_Q); four-way without the octonionic one also 9')
cols = []
for k in range(Ls):
    B = basis[k]; half = .5 * (B - refl['O'](B)); cols.append(np.concatenate([bra0 @ B, (half @ PL).ravel()]))
cols_c = [np.concatenate([bra0, PL.ravel()]), np.concatenate([1j * bra0, 1j * PL.ravel()])]
Nsc = nullspace_real(cols + [-c for c in cols_c]); assert Nsc.shape[0] == 12 and np.abs(Nsc[:, Ls:]).max() < 1e-8
ok('R10 Roadmap III single constraint with a free scalar: 12 solutions, all with c = 0 (su(3)+su(2)+u(1))')
L = lambda a, b: Le(a) @ Le(b)
sstar = .5 * (ID - 1j * Le(7))
iBL = (L(1, 3) + L(2, 6) + L(4, 5)) / 3
iY = (L(1, 3) + L(2, 6) + L(4, 5)) / 6 - 0.5 * Le_(3) @ sstar
iQ = (L(1, 3) + L(2, 6) + L(4, 5)) / 6 - 0.5 * Le_(3)
u_, s_, vt_ = np.linalg.svd(PL); BPL = u_[:, :16]
def spec(Mx, den=6):
    Rm = BPL.conj().T @ (-1j * Mx) @ BPL; assert np.allclose(Rm, Rm.conj().T)
    return Counter(rat(float(x), den) for x in np.linalg.eigvalsh(Rm))
SPEC = {'Y': spec(iY), 'Q': spec(iQ), 'B-L': spec(iBL)}
expectY = {F(-2, 3): 3, F(-1, 2): 2, F(0): 1, F(1, 6): 6, F(1, 3): 3, F(1): 1}
expectQ = {F(-1): 1, F(-2, 3): 3, F(-1, 3): 3, F(0): 2, F(1, 3): 3, F(2, 3): 3, F(1): 1}
expectBL = {F(-1): 2, F(-1, 3): 6, F(1, 3): 6, F(1): 2}
assert dict(SPEC['Y']) == expectY and dict(SPEC['Q']) == expectQ and dict(SPEC['B-L']) == expectBL
sums = {n: {'trace': fr_s(sum(k * m for k, m in c.items())), 'cubes': fr_s(sum(k ** 3 * m for k, m in c.items()))} for n, c in SPEC.items()}
assert all(s['trace'] == '0' and s['cubes'] == '0' for s in sums.values())
ok('R11 on Psi_L (16 states): Y takes the Standard Model values of Q_L, u^c, d^c, L, e^c, nu^c; Q and B-L as expected; trace and sum of cubes are 0 for all three (anomaly-free)')
D['roadmap'] = {
    'multivector': {'spin10': 45, 'su5': 24},
    'spin10_line': [{'name': n, 'reflections': k, 'dim': w} for n, k, w in line1],
    'su5_line': [{'name': n, 'reflections': k, 'dim': w} for n, k, w in line2],
    'bypass': {'LR_direct_from_second_octonionic_reflection': 15, 'LR_to_u3_by_complex_conjugation_without_H': 12, 'SM_to_UB_by_complex_conjugation': 9},
    'intersections': inter,
    'single_constraint': {'solutions': 12, 'free_scalar_zero': True},
    'spectra_on_PsiL': {n: spec_s(c) for n, c in SPEC.items()}, 'sums_on_PsiL': sums,
}

# =========================================================================== T: Trialities
Lij = lambda i, j: LO[i] @ LO[j]; s3 = np.sqrt(3)
der = [.5 * (Lij(3, 4) - Lij(1, 5)), .5 * (Lij(1, 4) + Lij(3, 5)), .5 * (Lij(1, 3) - Lij(4, 5)), -.5 * (Lij(2, 5) + Lij(4, 6)),
       .5 * (Lij(2, 4) - Lij(5, 6)), -.5 * (Lij(1, 6) + Lij(2, 3)), .5 * (Lij(1, 2) + Lij(3, 6)), -(1 / (2 * s3)) * (Lij(1, 3) + Lij(4, 5) - 2 * Lij(2, 6)),
       (1 / (2 * s3)) * (Lij(1, 5) + Lij(3, 4) + 2 * Lij(2, 7)), (1 / (2 * s3)) * (-Lij(1, 4) + Lij(3, 5) - 2 * Lij(6, 7)),
       (1 / (2 * s3)) * (Lij(4, 6) - Lij(2, 5) + 2 * Lij(1, 7)), (1 / (2 * s3)) * (Lij(2, 4) + Lij(5, 6) - 2 * Lij(3, 7)),
       (1 / (2 * s3)) * (-Lij(1, 6) + Lij(2, 3) + 2 * Lij(4, 7)), (1 / (2 * s3)) * (Lij(1, 2) - Lij(3, 6) - 2 * Lij(5, 7))]
mul_o = lambda x, y: sum(x[a] * (LO[a] @ y) for a in range(8))
rng = np.random.default_rng(1)
def is_der(Dm):
    for _ in range(5):
        x, y = rng.normal(size=8), rng.normal(size=8)
        if not np.allclose(Dm @ mul_o(x, y), mul_o(Dm @ x, y) + mul_o(x, Dm @ y)): return False
    return True
assert all(is_der(Dm) for Dm in der) and np.linalg.matrix_rank(np.array([Dm.ravel() for Dm in der])) == 14
assert all(np.allclose(Dm @ np.eye(8)[7], 0) for Dm in der[:8]) and all(not np.allclose(Dm @ np.eye(8)[7], 0) for Dm in der[8:])
ok('T1 the 14 operators of Trialities eq. (24) are linearly independent derivations of O (g2); the first 8 fix e7 (su(3)), the last 6 move it')
LHv = lambda v: sum(v[m - 1] * LH[m] for m in (1, 2, 3)); RHv = lambda v: sum(v[m - 1] * RH[m] for m in (1, 2, 3))
LOv = lambda v: sum(v[j - 1] * LO[j] for j in range(1, 8)); ROv = lambda v: sum(v[j - 1] * RO[j] for j in range(1, 8))
def dH_(kind, a, b, r):
    dH = LHv(r) - RHv(r)
    return {'V': dH + LHv(a) + RHv(b), '+': dH + LHv(a) + RHv(a - b), '-': dH + LHv(b - a) + RHv(b)}[kind]
def dO_(kind, al, be, dO):
    return {'V': dO + LOv(al) + ROv(be), '+': dO + LOv(al) + ROv(al - be), '-': dO + LOv(be - al) + ROv(be)}[kind]
act = lambda kind, a, b, r, al, be, dO: np.kron(dH_(kind, a, b, r), I8) + np.kron(I4, dO_(kind, al, be, dO))
z3, z7, Z8 = np.zeros(3), np.zeros(7), np.zeros((8, 8)); e3 = np.array([0, 0, 1.]); e7v = np.zeros(7); e7v[6] = 1
gsu3 = [{k: act(k, z3, z3, z3, z7, z7, der[j]) for k in '+-V'} for j in range(8)]
def g_su2(m):
    r = np.zeros(3); r[m - 1] = 1.0; return {k: act(k, -r, -2 * r, r, z7, z7, Z8) for k in '+-V'}
gsu2 = [g_su2(m) for m in (1, 2, 3)]
gY = {k: act(k, -(1 / 3) * e3, -(1 / 6) * e3, -(1 / 6) * e3, (1 / 6) * e7v, -(1 / 6) * e7v, Z8) for k in '+-V'}
cm = lambda A, B: A @ B - B @ A
RANK2 = {}
for k in '+-V':
    assert all(np.allclose(cm(gsu3[i][k], gsu2[j][k]), 0) for i in range(8) for j in range(3))
    assert all(np.allclose(cm(gY[k], g[k]), 0) for g in gsu3 + gsu2)
    span = np.array([g[k].ravel() for g in gsu2]); r0 = int(np.linalg.matrix_rank(span)); RANK2[k] = r0
    assert r0 == {'+': 0, '-': 3, 'V': 3}[k] and np.linalg.matrix_rank(np.vstack([span] + [cm(gsu2[a][k], gsu2[b][k]).ravel()[None, :] for a in range(3) for b in range(3)])) == r0
    span3 = np.array([g[k].ravel() for g in gsu3]); assert np.linalg.matrix_rank(span3) == 8
    assert np.linalg.matrix_rank(np.vstack([span3] + [cm(gsu3[a][k], gsu3[b][k]).ravel()[None, :] for a in range(8) for b in range(8)])) == 8
ok('T2 the Standard Model action inside tri(H)+tri(O), on Psi+, Psi-, V (32 real dimensions each): su(3) closes (rank 8) on all three, su(2) closes (rank 3) on Psi- and V and acts as zero on Psi+, su(3) and su(2) commute, and Y commutes with both')
def yspec(k):
    w = np.linalg.eigvals(gY[k]); assert np.abs(w.real).max() < 1e-9
    return Counter(rat(float(x), 6) for x in w.imag)
YS = {k: yspec(k) for k in '+-V'}
absy = {k: Counter() for k in '+-V'}
for k in '+-V':
    for y, m in YS[k].items():
        if y >= 0: absy[k][y] += m if y != 0 else m
assert dict(YS['+']) == {F(-1): 2, F(-2, 3): 6, F(-1, 3): 6, F(0): 4, F(1, 3): 6, F(2, 3): 6, F(1): 2}
assert dict(YS['-']) == {F(-1, 2): 4, F(-1, 6): 12, F(1, 6): 12, F(1, 2): 4}
assert dict(YS['V']) == {F(-5, 6): 6, F(-1, 2): 4, F(-1, 6): 6, F(1, 6): 6, F(1, 2): 4, F(5, 6): 6}
ok('T3 hypercharge spectra: Psi+ = right-handed weak singlets (|Y| 0, 1/3, 2/3, 1) of two generations and conjugates; Psi- = left-handed doublets (|Y| 1/6, 1/2) of two generations and conjugates; V has |Y| = 1/6, 1/2, 5/6, the irreps (3,2,1/6), (3,2,-5/6), (1,2,+-1/2) of eq. (46)')
rng = np.random.default_rng(7)
def Lmat(x):
    Mx = np.zeros((32, 32))
    for h in range(4):
        for o in range(8): Mx += x[h * 8 + o] * np.kron(LH[h], LO[o])
    return Mx
prod = lambda x, y: Lmat(x) @ y
err = 0.0
for _ in range(20):
    a, b, r = rng.normal(size=3), rng.normal(size=3), rng.normal(size=3); al, be = rng.normal(size=7), rng.normal(size=7)
    dOm = sum(c * Dm for c, Dm in zip(rng.normal(size=14), der)); X, Yv = rng.normal(size=32), rng.normal(size=32)
    dV, dp, dm = (act(k, a, b, r, al, be, dOm) for k in 'V+-')
    err = max(err, float(np.abs(dV @ prod(X, Yv) - (prod(dp @ X, Yv) + prod(X, dm @ Yv))).max()))
assert err < 1e-10; ok('T4 Cartan triality principle on H x O: delta_V(X Y) = (delta_+ X) Y + X (delta_- Y) for 20 random elements of tri(H)+tri(O) (error below 1e-10)')
tri_dims = {'R': 0, 'C': 2, 'H': 9, 'O': 28}
assert tri_dims['H'] + tri_dims['O'] + 3 * 32 == 133 and tri_dims['O'] + tri_dims['O'] + 3 * 64 == 248 and sum(tri_dims.values()) == 39
ok('T5 dimension arithmetic of the Freudenthal-Tits forms: dim e7 = tri(H) + tri(O) + 3 H x O = 9 + 28 + 96 = 133; dim e8 = tri(O) + tri(O) + 3 O x O = 28 + 28 + 192 = 248')
D['trialities'] = {
    'g2': {'derivations': 14, 'fix_e7': 8, 'move_e7': 6}, 'rank_su2': RANK2, 'rank_su3': 8,
    'spectra': {k: {'y': spec_s(YS[k])} for k in '+-V'},
    'cartan_principle_error_below': '1e-10',
    'tri_dims': tri_dims, 'e7': 133, 'e8': 248,
}

# =========================================================================== F: Fig. 1 against the ten edges
W = FUREY_W
BLOCK = ['O1', 'O2', 'H', 'C', 'last']
# the particle names of Fig. 1 and the irrep each names (colour, isospin dimension, hypercharge); a dagger is the conjugate irrep
NAME = {'b_R': ('3', 1, F(-1, 3)), '(nu_e,e)_L': ('1', 2, F(-1, 2)), '(nu_mu,mu)_L': ('1', 2, F(-1, 2)), '(u,d)_L': ('3', 2, F(1, 6)), '(c,s)_L': ('3', 2, F(1, 6)),
        'e_R': ('1', 1, F(-1)), 'mu_R': ('1', 1, F(-1)), 'nu_eR': ('1', 1, F(0)), 'nu_muR': ('1', 1, F(0)), 'u_R': ('3', 1, F(2, 3)), 'c_R': ('3', 1, F(2, 3)),
        'd_R': ('3', 1, F(-1, 3)), 's_R': ('3', 1, F(-1, 3)), 'h': ('1', 2, F(1, 2)), '(nu_tau,tau)_L': ('1', 2, F(-1, 2)), 'tau_R': ('1', 1, F(-1))}
NAME = {k: (v[0], int(v[1]), v[2]) for k, v in NAME.items()}
# (row, column) of Fig. 1 -> the labels written in the cell, top to bottom (a trailing + means dagger)
FIG1 = {(0, 1): ['b_R+', 'b_R+'], (0, 2): ['(nu_e,e)_L+', '(nu_mu,mu)_L+'], (0, 3): ['e_R+', 'mu_R+'], (0, 4): ['nu_eR+', 'nu_muR+'],
        (1, 0): ['b_R', 'b_R'], (1, 2): ['(u,d)_L', '(c,s)_L'], (1, 3): ['u_R', 'c_R'], (1, 4): ['d_R', 's_R'],
        (2, 0): ['(nu_e,e)_L', '(nu_mu,mu)_L'], (2, 1): ['(u,d)_L+', '(c,s)_L+'], (2, 3): ['h', 'h'], (2, 4): ['(nu_tau,tau)_L', '(nu_tau,tau)_L'],
        (3, 0): ['e_R', 'mu_R'], (3, 1): ['u_R+', 'c_R+'], (3, 2): ['h+', 'h+'], (3, 4): ['tau_R', 'tau_R'],
        (4, 0): ['nu_eR', 'nu_muR'], (4, 1): ['d_R+', 's_R+'], (4, 2): ['(nu_tau,tau)_L+', '(nu_tau,tau)_L+'], (4, 3): ['tau_R+', 'tau_R+']}
def irrep_of(label):
    dg = label.endswith('+'); r = NAME[label.rstrip('+')]; return dual(r) if dg else r
cells = []
for (row, col), labels in sorted(FIG1.items()):
    # the matrix of Fig. 1: a cell is the operator from the block of its row to the block of its column, so its charge is y_column - y_row
    comp = tensor(W[col], dual(W[row])); assert len(comp) == 1; c = comp[0]
    for lb in labels: assert irrep_of(lb) == c, (row, col, lb, fmt(irrep_of(lb)), fmt(c))
    cells.append({'row': row, 'col': col, 'labels': labels, 'irrep': fmt(c), 'dagger': labels[0].endswith('+')})
assert len(cells) == 20
ok('F1 all 20 off-diagonal cells of Fig. 1: every label (both rows of every cell, daggers included) is exactly the irrep (colour, isospin, Y) of the Peirce edge row -> column, with the blocks of the page: 1, 3, 2, 1, 1 and Y = 0, 1/3, 1/2, 1, 0')
assert all(sm and True for sm in [tg.sm_ok(b) for b in W]); ok('F2 every block obeys the Standard Model relation 6Y = -2a - 3b (mod 6)')
# electric charge, her eq. (4): Q = 1/3 P_O2 + P_H2 + P_C, the doublet block carrying the charges 0 and 1 on its two components
QCOMP = [[F(0)], [F(1, 3)] * 3, [F(0), F(1)], [F(1)], [F(0)]]
YBLK = [b[2] for b in W]; DIMS = [dim(b) for b in W]
assert sum(y * d for y, d in zip(YBLK, DIMS)) == 3 and sum(sum(q) for q in QCOMP) == 3 and sum(DIMS) == 8
ok('F3 Tr Y = Tr Q = 3 over the 8 complex dimensions of V: Y0 = Y - 3/8 and Q0 = Q - 3/8 are traceless (her eqs. 44, 45)')
PCHG = {'Q_L': {F(2, 3): 3, F(-1, 3): 3}, 'u_R': {F(2, 3): 3}, 'd_R': {F(-1, 3): 3}, 'L': {F(0): 1, F(-1): 1}, 'e_R': {F(-1): 1}, 'nu_R': {F(0): 1}, 'h': {F(1): 1, F(0): 1}}
def qset(row, col): return Counter(qt - qs for qt in QCOMP[col] for qs in QCOMP[row])
for c in cells:
    row, col = c['row'], c['col']; qs = qset(row, col); lb = c['labels'][0]; base = lb.rstrip('+'); nm = {'(u,d)_L': 'Q_L', '(c,s)_L': 'Q_L', 'u_R': 'u_R', 'c_R': 'u_R', 'd_R': 'd_R', 's_R': 'd_R', 'b_R': 'd_R', '(nu_e,e)_L': 'L', '(nu_mu,mu)_L': 'L', '(nu_tau,tau)_L': 'L', 'e_R': 'e_R', 'mu_R': 'e_R', 'tau_R': 'e_R', 'nu_eR': 'nu_R', 'nu_muR': 'nu_R', 'h': 'h'}[base]
    want = Counter(PCHG[nm]) if not lb.endswith('+') else Counter({-q: m for q, m in PCHG[nm].items()})
    assert qs == want, (row, col, lb, dict(qs), dict(want)); c['charges'] = spec_s(qs)
ok('F4 electric charges of the 20 cells from Q = 1/3 P_O2 + P_H2 + P_C: every cell carries exactly the charges of the particles Fig. 1 names (up 2/3 and down -1/3 quarks, neutrinos 0, charged leptons -1, the doublet h with +1 and 0), negated in the dagger cells')
D['fig1'] = {'blocks': [{'name': BLOCK[i], 'colour': b[0], 'isospin': b[1], 'y': fr_s(b[2])} for i, b in enumerate(W)], 'convention': 'a cell (row, column) is the operator from the block of its row to the block of its column; its irrep is block(column) x conjugate block(row)',
             'cells': cells, 'matched': 20, 'of': 20,
             'diagonal': ['p^l sigma, B sigma', 'p^q sigma, G Lambda sigma, B sigma', 'p^a sigma, W tau sigma', 'p^abar sigma, B sigma', 'p^abar sigma, B sigma']}

# =========================================================================== C: counting
TYPES = list(SM.keys())
def kind(c):                       # which of the six Standard Model types (up to conjugation) is this irrep, or None
    for n, r in SM.items():
        if c == r: return n, 'particle'
        if c == dual(r): return n, 'conjugate'
    return None
cnt_exact = {n: 0 for n in TYPES}; cnt_conj = {n: 0 for n in TYPES}
for row, col in FIG1:
    comp = tensor(W[col], dual(W[row]))[0]; k = kind(comp); assert k
    if k[1] == 'particle': cnt_exact[k[0]] += 1
    else: cnt_conj[k[0]] += 1
cells_by_type = {n: cnt_exact[n] + cnt_conj[n] for n in TYPES}
# nu_R (1,1,0) is its own conjugate: kind() calls it 'particle' in both orientations
assert cells_by_type == {'Q_L': 2, 'u_R': 2, 'd_R': 4, 'L': 6, 'e_R': 4, 'nu_R': 2}, cells_by_type
sets_on = {n: cells_by_type[n] // 2 for n in TYPES}
assert sets_on == {'Q_L': 1, 'u_R': 1, 'd_R': 2, 'L': 3, 'e_R': 2, 'nu_R': 1} and min(sets_on.values()) == 1
surplus = {n: sets_on[n] - 1 for n in TYPES}
assert surplus == {'Q_L': 0, 'u_R': 0, 'd_R': 1, 'L': 2, 'e_R': 1, 'nu_R': 0} and sum(tg.SM_DIM[n] * surplus[n] for n in TYPES) == 8
ok('C1 one label per cell (on-shell, End_C(V) = M8(C)): the 20 cells hold 2 Q_L, 2 u_R, 4 d_R, 6 L, 4 e_R, 2 nu_R (a field and its conjugate each count once): one complete set, and 8 complex dimensions beyond it (b_R, tau_R, 2 doublets)')
sets_off = {n: 2 * sets_on[n] for n in TYPES}
assert min(sets_off.values()) == 2 and {n: 3 - sets_off[n] for n in TYPES if sets_off[n] < 3} == {'Q_L': 1, 'u_R': 1, 'nu_R': 1}
ok('C2 every cell doubled (the hermitian 16 x 16 form of Fig. 1): two complete sets, and exactly the irreps of Q_L, u_R and nu_R lack a third copy (the top quark irreps, and the third right-handed neutrino); d_R, L and e_R have enough')
exact_sets = {n: cnt_exact[n] for n in TYPES}
D['counting'] = {'cells_by_type': cells_by_type, 'sets_on_shell': sets_on, 'surplus_on_shell': surplus, 'sets_doubled': sets_off,
                 'complete_sets_on_shell': 1, 'complete_sets_doubled': 2, 'missing_for_three_doubled': {'Q_L': 1, 'u_R': 1, 'nu_R': 1},
                 'surplus_dimension_C': 8, 'sm_dim': tg.SM_DIM, 'exact_copies_on_shell': {n: cnt_exact[n] for n in TYPES}}

# =========================================================================== P: the irreps Fig. 1 lacks, as products of the ones it has
def has(prod_list, target): return target in prod_list
bR, hh, tauR, nuL = ('3', 1, F(-1, 3)), ('1', 2, F(1, 2)), ('1', 1, F(-1)), ('1', 2, F(-1, 2))
prods = [
    {'a': 'b_R', 'b': 'h', 'target': 'Q_L', 'result': tensor(bR, hh), 'want': SM['Q_L']},
    {'a': 'b_R', 'b': 'tau_R+', 'target': 'u_R', 'result': tensor(bR, dual(tauR)), 'want': SM['u_R']},
    {'a': 'h', 'b': '(nu_tau,tau)_L', 'target': 'nu_R', 'result': tensor(hh, nuL), 'want': SM['nu_R']},
]
for p in prods: assert p['want'] in p['result'], p
ok('P1 b_R x h contains (3,2,+1/6) = Q_L; b_R x tau_R^dagger contains (3,1,+2/3) = u_R; h x (nu_tau,tau)_L contains (1,1,0) = nu_R: the irreps missing from Fig. 1 are products of the extra ones')
D['composites'] = [{'a': p['a'], 'b': p['b'], 'target': p['target'], 'result': [fmt(x) for x in p['result']]} for p in prods]
D['composites_note'] = 'quantum numbers only: the products are tensor products of the Standard Model irreps of the cells; no dynamics is claimed'

# =========================================================================== N: room
sing, dbl, tri, trb = admissible_blocks(); pool = [b for b in sing + dbl + tri + trb]
K = len(pool)
VV = np.zeros((K, K, 6), dtype=np.int64)
for a in range(K):            # source block a, target block b: operator a -> b = b (x) a*
    for b in range(K):
        for c in tensor(pool[b], dual(pool[a])):
            for t, (n, r) in enumerate(SM.items()):
                if c == r or (c == dual(r) and dual(r) != r): VV[a, b, t] += 1
def sets_of(counts):
    n = np.array(counts); Mm = np.outer(n, n) - np.diag(n); s = np.einsum('ab,abk->k', Mm, VV); return int(s.min())
dimsK = np.array([dim(b) for b in pool])
def room(Nd):
    hist = Counter(); best = [0, None]
    def rec(i, left, cnt):
        if left == 0:
            s = sets_of(cnt); hist[s] += 1
            if s > best[0]: best[0], best[1] = s, list(cnt)
            return
        if i == K: return
        d = dimsK[i]
        if d <= left:
            cnt[i] += 1; rec(i, left - d, cnt); cnt[i] -= 1
        rec(i + 1, left, cnt)
    rec(0, Nd, [0] * K); return hist, best
rooms = {}
for Nd in range(8, 15):
    h, best = room(Nd); rooms[Nd] = {'structures': sum(h.values()), 'histogram_of_S': {str(k): v for k, v in sorted(h.items())}, 'max_S': max(h)}
    ex = [fmt(pool[i]) for i in range(K) for _ in range(best[1][i])] if best[1] else []
    rooms[Nd]['example_with_max'] = ex
assert rooms[8]['structures'] == 5582 and rooms[8]['histogram_of_S'] == {'0': 5566, '2': 16}
# cross-check against the direct computation on her frame and on random structures of dimension 8, 9
def S_direct(Wl):
    lin, anti = tg.sectors(Wl, off_diagonal=True)
    return min(tg.mult(lin, r) + (tg.mult(lin, dual(r)) if dual(r) != r else 0) for r in SM.values())
cnt_her = [0] * K
for b in FUREY_W: cnt_her[pool.index(b)] += 1
assert S_direct(FUREY_W) == sets_of(cnt_her) == 2
import random
rr = random.Random(5)
for _ in range(300):
    Nd = rr.choice([8, 9, 10]); left = Nd; cur = []
    while left:
        cand = [b for b in pool if dim(b) <= left]; b = rr.choice(cand); cur.append(b); left -= dim(b)
    cnt = [0] * K
    for b in cur: cnt[pool.index(b)] += 1
    assert S_direct(cur) == sets_of(cnt)
ok('N1 the fast counter equals the direct decomposition of threegen_selfcheck.py on her frame and on 300 random structures; 5,582 admissible structures at dimension 8')
maxS = {Nd: rooms[Nd]['max_S'] for Nd in rooms}
assert maxS == {8: 2, 9: 2, 10: 2, 11: 4, 12: 4, 13: 4, 14: 8}, maxS
assert rooms[14]['histogram_of_S'].get('6') == 18 and rooms[14]['histogram_of_S'].get('8') == 8 and all('6' not in rooms[n]['histogram_of_S'] for n in range(8, 14))
ok('N2 complete sets (a field and its conjugate each counted once, linear off-diagonal cells, admissible blocks of size 1, 2, 3 with Standard Model hypercharges |y| <= 2): at most 1 set up to dimension 10, 2 sets at 11 to 13, and three sets (S = 6) appear first at dimension 14')
D['room'] = {'rule': 'S = the smallest number of cells of any one of the six Standard Model types (a type and its conjugate count together) over the linear off-diagonal cells; complete sets = S / 2; blocks of size 1, 2, 3 and 3-bar with Standard Model hypercharges |y| <= 2',
             'her_frame': {'dimension': 8, 'S': 2, 'sets': 1}, 'by_dimension': {str(k): v for k, v in rooms.items()}, 'first_dimension_with_three_sets': 14}

# =========================================================================== write / compare
def dump(x): return json.dumps(x, indent=1, sort_keys=True, ensure_ascii=False)
if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--write'); ap.add_argument('--compare'); a = ap.parse_args()
    D['checks'] = [n.split(' ', 1) for n in OK]    # [id, what it asserts]: the page lists them
    txt = dump(D)
    if a.write: open(a.write, 'w', encoding='utf8').write(txt)
    if a.compare:
        assert json.loads(txt) == json.load(open(a.compare, encoding='utf8')), 'stored data differs from the rebuilt data'; print('stored data == rebuilt data')
    print('ALL FUREY-PAPER CHECKS PASS (%d checks)' % len(OK))
