#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Automated sabotage test for the checks of this folder.  Each mutant changes one line of a temporary copy (a wrong sign, count, hypercharge, label or constant) and must make the NAMED check fail.
  group P  furey_papers_check.py: its checks stop at the first false assertion, so a mutant is caught when the run ends with an AssertionError and the ids printed before it are exactly the ids
           that come before the named one (the named id is the first one missing; a syntax error or an import error does not count);
  group W  furey_construction_check.py and the scripts it runs (run_all.py, model.py, dictionary_selfcheck.py, threegen_selfcheck.py): the wrapper prints FAIL for the named id.
The five scripts that are copies of the atlas's own (furey_papers_check.py, threegen_selfcheck.py, dictionary_selfcheck.py, model.py, run_all.py) are changed only in the temporary copies.
Run: python3 mutate_furey.py   (about 8 minutes; one line per mutant, then "mutants caught: N of M")"""
import os, sys, subprocess, tempfile, re, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
FILES = ['furey_papers_check.py', 'furey_construction_check.py', 'threegen_selfcheck.py', 'dictionary_selfcheck.py', 'model.py', 'run_all.py']
SRC = {f: open(os.path.join(HERE, f), encoding='utf-8').read() for f in FILES}
LOG = open(os.path.join(HERE, 'logs', 'furey_papers_check.log'), encoding='utf-8').read()
IDS = re.findall(r'^ok   ([A-Z]\d+) ', LOG, re.M)
assert len(IDS) == 30

MP = [  # (name, old, new, id of the check that must fail): group P, furey_papers_check.py
 ('P1  A1: the quaternion product e1 e2 claimed to be -e3', "np.allclose(LH[1] @ LH[2], LH[3])", "np.allclose(LH[1] @ LH[2], -LH[3])", 'A1'),
 ('P2  A2: a sign flipped in the formula for R_e7 (eq. 22)', "LO[1] @ LO[3] + LO[2] @ LO[6]", "LO[1] @ LO[3] - LO[2] @ LO[6]", 'A2'),
 ('P3  A3: the volume element of Cl(0,6) built from L_e1 ... L_e5 and L_e5', "LO[1] @ LO[2] @ LO[3] @ LO[4] @ LO[5] @ LO[6])", "LO[1] @ LO[2] @ LO[3] @ LO[4] @ LO[5] @ LO[5])", 'A3'),
 ('P4  A4: the tenth Gamma matrix built from a left instead of a right multiplication', "G[10] = Re_(2)", "G[10] = Le_(2)", 'A4'),
 ('P5  A5: the chirality element claimed to be +R_eps3', "assert np.allclose(G11, -Re_(3))", "assert np.allclose(G11, Re_(3))", 'A5'),
 ('P6  R1: a ladder operator with the wrong sign of its first term (a is not the conjugate of a-dagger)', "alow = {1: .5 * (-G[5] + 1j * G[4])", "alow = {1: .5 * (G[5] + 1j * G[4])", 'R1'),
 ('P7  R3: the left-handed projector claimed to have rank 15', "np.linalg.matrix_rank(PL) == 16", "np.linalg.matrix_rank(PL) == 15", 'R3'),
 ('P8  R4: the union of the two sets of generators claimed to have rank 44', "rank_of(np.vstack([VL, VD])) == 45", "rank_of(np.vstack([VL, VD])) == 44", 'R4'),
 ('P9  R6: the multivector condition claimed to leave 25 dimensions', "assert N_d.shape[0] == 24 and N_L.shape[0] == 24", "assert N_d.shape[0] == 25 and N_L.shape[0] == 25", 'R6'),
 ('P10 R7: the Pati-Salam step claimed to leave 22 dimensions', "('Pati-Salam', ['O'], 21)", "('Pati-Salam', ['O'], 22)", 'R7'),
 ('P11 R8: the Standard Model step of the SU(5) line claimed to leave 13 dimensions', "('Standard Model (->O)', ['O'], 12)", "('Standard Model (->O)', ['O'], 13)", 'R8'),
 ('P12 R9: the five-way intersection claimed to have dimension 10', "'five_way_O_H_C': 9, 'four_way_no_O': 9}", "'five_way_O_H_C': 10, 'four_way_no_O': 9}", 'R9'),
 ('P13 R10: the single constraint claimed to have 13 solutions', "Nsc.shape[0] == 12 and", "Nsc.shape[0] == 13 and", 'R10'),
 ('P14 R11: the hypercharge multiplicity of the doublet claimed to be 3', "expectY = {F(-2, 3): 3, F(-1, 2): 2,", "expectY = {F(-2, 3): 3, F(-1, 2): 3,", 'R11'),
 ('P15 T1: the 14 derivations claimed to have rank 13', "for Dm in der])) == 14", "for Dm in der])) == 13", 'T1'),
 ('P16 T2: su(2) claimed to act non-trivially on Psi+', "r0 == {'+': 0, '-': 3, 'V': 3}[k]", "r0 == {'+': 3, '-': 3, 'V': 3}[k]", 'T2'),
 ('P17 T3: the multiplicity of |Y| = 1/6 on Psi- claimed to be 11 per sign', "{F(-1, 2): 4, F(-1, 6): 12,", "{F(-1, 2): 4, F(-1, 6): 11,", 'T3'),
 ('P18 T4: the triality identity claimed to hold with error below 0', "assert err < 1e-10; ok('T4", "assert err < 0; ok('T4", 'T4'),
 ('P19 T5: the dimension of tri(H) claimed to be 8', "tri_dims = {'R': 0, 'C': 2, 'H': 9, 'O': 28}", "tri_dims = {'R': 0, 'C': 2, 'H': 8, 'O': 28}", 'T5'),
 ('P20 F1: a dagger dropped from one label of Fig. 1', "(0, 1): ['b_R+', 'b_R+']", "(0, 1): ['b_R+', 'b_R']", 'F1'),
 ('P21 F2: every block claimed to violate 6Y = -2a - 3b (mod 6)', "assert all(sm and True for sm in", "assert all((not sm) and True for sm in", 'F2'),
 ('P22 F3: the trace of Y claimed to be 4', "sum(y * d for y, d in zip(YBLK, DIMS)) == 3", "sum(y * d for y, d in zip(YBLK, DIMS)) == 4", 'F3'),
 ('P23 F4: the charges of a lepton doublet claimed to be 0 and -1 twice', "'L': {F(0): 1, F(-1): 1}, 'e_R'", "'L': {F(0): 1, F(-1): 2}, 'e_R'", 'F4'),
 ('P24 C1: the board claimed to hold 5 lepton doublets', "'d_R': 4, 'L': 6, 'e_R': 4, 'nu_R': 2}, cells_by_type", "'d_R': 4, 'L': 5, 'e_R': 4, 'nu_R': 2}, cells_by_type", 'C1'),
 ('P25 C2: the doubled board claimed to hold 3 complete sets', "assert min(sets_off.values()) == 2", "assert min(sets_off.values()) == 3", 'C2'),
 ('P26 P1: the product b_R x h claimed to contain the irrep of u_R', "'result': tensor(bR, hh), 'want': SM['Q_L']}", "'result': tensor(bR, hh), 'want': SM['u_R']}", 'P1'),
 ('P27 N1: the fast counter claimed to give 3 sets on her frame', "assert S_direct(FUREY_W) == sets_of(cnt_her) == 2", "assert S_direct(FUREY_W) == sets_of(cnt_her) == 3", 'N1'),
 ('P28 N2: the best structure at dimension 14 claimed to hold 3 sets (S = 6) instead of 4', "11: 4, 12: 4, 13: 4, 14: 8}", "11: 4, 12: 4, 13: 4, 14: 6}", 'N2'),
]
MW = [  # (name, file, old, new, id of the wrapper check that must print FAIL): group W
 ('W1  B1: the number of anti-associating triples claimed to be 167', 'furey_construction_check.py', "and na == 168", "and na == 167", 'B1'),
 ('W2  B4: the label of omega claimed to be 124', 'furey_construction_check.py', "D['omega']['N'] == 123", "D['omega']['N'] == 124", 'B4'),
 ('W3  B5: the real ranks claimed to be (2, 6, 4, 2, 2, 1)', 'furey_construction_check.py', "R['real_blocks'] == [2, 6, 4, 2, 1, 1]", "R['real_blocks'] == [2, 6, 4, 2, 2, 1]", 'B5'),
 ('W4  B7: the total capacity of the edges claimed to be 49', 'furey_construction_check.py', "sum(e['capacity_C'] for e in R['edges']) == 48", "sum(e['capacity_C'] for e in R['edges']) == 49", 'B7'),
 ('W5  B9: the number of diagonalising quadruples claimed to be 617', 'furey_construction_check.py', "W['diagonalising_all_block_projectors'] == 616", "W['diagonalising_all_block_projectors'] == 617", 'B9'),
 ('W6  B12: the best number of generations claimed to be 3', 'furey_construction_check.py', "sa['max_generations'] == 2", "sa['max_generations'] == 3", 'B12'),
 ('W7  run_all: the second projector of the first Peirce pair equal to the first', 'run_all.py', "PO1=(I8-LR)/2; PO2=(I8+LR)/2", "PO1=(I8-LR)/2; PO2=(I8-LR)/2", 'B5'),
 ('W8  run_all: the quaternion block of the real model with three axes instead of four', 'run_all.py', "proj(0*I8,(4,5,6,7))),('C'", "proj(0*I8,(4,5,6))),('C'", 'B5'),
 ('W9  run_all: the hypercharge of the colour triplet block 2/3 instead of 1/3', 'run_all.py', "yv=[F(0),F(1,3),F(1,2),F(1),F(0)]", "yv=[F(0),F(2,3),F(1,2),F(1),F(0)]", 'B8'),
 ('W10 run_all: the axes where omega-prime and omega differ in sign claimed to be 0, 3, 8, 12', 'run_all.py', "==[0,3,8,11]", "==[0,3,8,12]", 'B10'),
 ('W11 run_all: the independent quadruples counted with a span of 8 instead of 16', 'run_all.py', "if len(span)==16:", "if len(span)==8:", 'B9'),
 ('W12 model: the Cayley-Dickson product with the wrong sign (not the octonions)', 'model.py', "qmul(a,c)-qmul(qconj(d),b)", "qmul(a,c)+qmul(qconj(d),b)", 'B1'),
 ('W13 dictionary: the commuting blades of omega claimed to number 127', 'dictionary_selfcheck.py', "assert len(comm)==128", "assert len(comm)==127", 'B4'),
 ('W14 dictionary: a product of blades claimed to be only +blade of the XOR', 'dictionary_selfcheck.py', "assert np.allclose(M,B[U]) or np.allclose(M,-B[U])", "assert np.allclose(M,B[U])", 'B2'),
 ('W15 threegen: the hypercharge of Q_L claimed to be 1/3', 'threegen_selfcheck.py', "SM = {'Q_L': ('3', 2, F(1, 6))", "SM = {'Q_L': ('3', 2, F(1, 3))", 'B11'),
 ('W16 threegen: the colour triplets without the hypercharge 5/3', 'threegen_selfcheck.py', "tri = [('3', 1, F(k, 3)) for k in range(-6, 7)", "tri = [('3', 1, F(k, 3)) for k in range(-6, 5)", 'B12'),
]

def tail_ids(out):
    return re.findall(r'^ok   ([A-Z]\d+) ', out, re.M)
caught = 0; lines = []
for name, old, new, cid in MP:
    src = SRC['furey_papers_check.py']
    if src.count(old) != 1:
        lines.append(f'ERROR {name}: pattern found {src.count(old)} times'); continue
    with tempfile.TemporaryDirectory() as td:
        shutil.copy(os.path.join(HERE, 'threegen_selfcheck.py'), td)
        open(os.path.join(td, 'furey_papers_check.py'), 'w', encoding='utf-8').write(src.replace(old, new))
        r = subprocess.run([sys.executable, os.path.join(td, 'furey_papers_check.py')], capture_output=True, text=True, timeout=900, cwd=td)
    got = tail_ids(r.stdout); want = IDS[:IDS.index(cid)]
    hit = r.returncode != 0 and 'AssertionError' in r.stderr and got == want
    caught += hit
    lines.append(f"{'caught' if hit else 'MISSED'}  {name}  -> first missing id: {(IDS[len(got)] if len(got) < len(IDS) else '-')}")
for name, target, old, new, cid in MW:
    src = SRC[target]
    if src.count(old) != 1:
        lines.append(f'ERROR {name}: pattern found {src.count(old)} times'); continue
    with tempfile.TemporaryDirectory() as td:
        for f in FILES:
            if f != 'furey_papers_check.py': open(os.path.join(td, f), 'w', encoding='utf-8').write(src.replace(old, new) if f == target else SRC[f])
        r = subprocess.run([sys.executable, os.path.join(td, 'furey_construction_check.py')], capture_output=True, text=True, timeout=900, cwd=td)
    failed = re.findall(r'^FAIL (B\d+):', r.stdout, re.M)
    hit = r.returncode != 0 and cid in failed
    caught += hit
    lines.append(f"{'caught' if hit else 'MISSED'}  {name}  -> failing: {','.join(failed) or '-'}")
for l in lines: print(l)
total = len(MP) + len(MW)
print(f'mutants caught: {caught} of {total}')
sys.exit(0 if caught == total else 1)
