#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Tests that ../html/furey_report.html agrees with its sources and behaves in a browser: every headline number equals the logs; every check id the page names exists and every id of the logs
is named; each finding tagged checked names a check; the numbers in the text equal the lines of the logs they come from; fresh runs of the two check scripts give the logs; the five copied scripts
and the data file are byte-identical to the atlas's; the octonion table of the page is recomputed here by a separate Cayley-Dickson product; no external request, no address, no history wording,
the forbidden sentences are nowhere on the page.  Run after build_report_furey.py: python3 test_report_furey.py   (REPORT_NO_BROWSER=1 skips the browser tests, which are then reported as skipped and not counted)"""
import os, re, sys, html, json, subprocess, filecmp, itertools
HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..'))
import no_history as NH
import status_check as SK
import content_furey as C
import figs_furey as FG
PKG = os.path.abspath(os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..')))
PAGE = os.path.join(HERE, '..', 'html', 'furey_report.html')
page = open(PAGE, encoding='utf-8').read()
strip = lambda t: re.sub(r'<style.*?</style>|<script.*?</script>', '', t, flags=re.S)
plain = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', strip(page))))
tips = ' '.join(html.unescape(t) for t in re.findall(r'data-tip="([^"]*)"', page))
ok = bad = 0
def chk(name, cond, msg=''):
    global ok, bad
    if cond: ok += 1
    else: bad += 1
    print(('ok   ' if cond else 'FAIL ') + name + (': ' + msg if (msg and not cond) else ''))

LOG1 = open(os.path.join('logs', 'furey_papers_check.log'), encoding='utf-8').read()
LOG2 = open(os.path.join('logs', 'furey_construction_check.log'), encoding='utf-8').read()
MUT = open(os.path.join('logs', 'mutate_furey.log'), encoding='utf-8').read()
LINES = {}; IDS = []
for l in (LOG1 + LOG2).splitlines():
    m = re.match(r'ok\s+([A-Z]\d+):?\s+(.*)', l)
    if m: IDS.append(m.group(1)); LINES[m.group(1)] = m.group(2)
nlog = len(IDS)

# ---- the headline numbers = the logs
chk('T1 both logs pass all: 30 + 12 ok lines, ids distinct, no FAIL', nlog == len(set(IDS)) == 42 and 'FAIL' not in LOG1 + LOG2 and 'ALL FUREY-PAPER CHECKS PASS (30 checks)' in LOG1 and 'checks: 12 ok, 0 failed' in LOG2, str(nlog))
def kpi(label):
    m = re.search(r'<div class="kpi"><b>([^<]+)</b><span>%s' % re.escape(label), page); return m.group(1) if m else None
chk('T2 headline: 42 checks pass, 0 fail; the summary paragraph says 42', kpi('checks pass') == str(nlog) and f'{nlog} pass, 0 fail' in plain and f'({nlog} checks in all)' in plain, str(kpi('checks pass')))
mm = re.search(r'mutants caught: (\d+) of (\d+)', MUT)
chk('T3 sabotage: the log says all caught, the page says so, one line per mutant, 44 mutants', bool(mm) and mm.group(1) == mm.group(2) == '44' and kpi('deliberate sabotages') == f'{mm.group(1)} of {mm.group(2)}'
    and len(re.findall(r'^caught', MUT, re.M)) == int(mm.group(2)) and 'MISSED' not in MUT and 'ERROR' not in MUT, str(mm.groups() if mm else None))
blocks = re.findall(r'<tr><td><b>([A-Z])</b></td><td>[^|]*?</td><td class="num">(\d+)</td>', page)
chk('T4 eight blocks A, R, T, F, C, P, N, B; each count equals the logs; the total is the headline', [b for b, _ in blocks] == list('ARTFCPNB') and all(int(n) == sum(1 for i in IDS if i[0] == b) for b, n in blocks)
    and sum(int(n) for _, n in blocks) == nlog and f'<td class="num"><b>{nlog}</b></td>' in page, str(blocks))
chk('T5 14 findings S1-S14, 7 inputs, 6 papers, 20 dictionary rows on the page; the headline numbers say so', all(f'id="s{i}"' in page for i in range(1, 15)) and kpi('findings, each') == '14' and kpi('inputs the construction') == '7'
    and len(C.FINDINGS) == 14 and len(C.INPUTS) == 7 and len(C.PAPERS) == 6 and len(C.DICT) == 20 and all(f'id="paper-{p[0]}"' in page for p in C.PAPERS))

# ---- check ids: every id the page names exists, every id of the logs is named by a finding
def expand(spec):
    out = []
    for tok in [t.strip() for t in spec.split(',') if t.strip()]:
        m = re.fullmatch(r'([A-Z]\d+)(?:–([A-Z]\d+))?', tok)
        if not m: return None
        a, b = m.group(1), m.group(2) or m.group(1)
        if a not in IDS or b not in IDS or IDS.index(a) > IDS.index(b): return None
        out += IDS[IDS.index(a):IDS.index(b) + 1]
    return out
spec_lists = [f[5] for f in C.FINDINGS] + [d[3] for d in C.DICT] + [d[3] for d in C.INPUTS] + [p[8] for p in C.PAPERS]
chk('T6 every id list (findings, dictionary, inputs, papers) is well formed and names existing ids', all(expand(s) for s in spec_lists), str([s for s in spec_lists if not expand(s)]))
cited = set()
for f in C.FINDINGS: cited |= set(expand(f[5]) or [])
chk('T7 every id of the logs is named by a finding', cited == set(IDS), str(sorted(set(IDS) - cited)))
inline = set(m.group(1) for m in re.finditer(r'(?<![\w.])([ARTFCPNB]\d{1,2})(?![\w])', plain + ' ' + tips))
chk('T8 every id named in the running text and in the tooltips (B1, R7, ...) exists in the logs', len(inline) >= 35 and inline <= set(IDS), str(sorted(inline - set(IDS))))
tags_ok = {'standard', 'checked', 'ours', 'open', 'input'}
fin = {}
for m in re.finditer(r'<article class="finding" id="(s\d+)">.*?class="chips">(.*?)</div>.*?<p class="ids">checks ([^<]*)\.</p>', page, re.S):
    fin[m.group(1)] = (set(SK.kinds(m.group(2))), m.group(3))
chk('T9 each finding has tags from the five, and every finding tagged checked names at least one check (rule X3)', len(fin) == 14 and all(t <= tags_ok and t for t, _ in fin.values())
    and all(('checked' not in t) or (expand(s) and len(expand(s)) >= 1) for t, s in fin.values()), str(fin))
chk('T10 the dictionary has 20 rows, each with tags and checks; tags are from the five; each row shows its tags as icon chips, in the order of the content', len(C.DICT) == 20 and all(set(re.split(r' · ', d[2])) <= tags_ok for d in C.DICT) 
    and [SK.kinds(r) for r in re.findall(r'<tr>(.*?)</tr>', page.split('id="dict"')[1].split('</section>')[0], re.S)[1:]] == [d[2].split(' · ') for d in C.DICT]
    and all(re.search(r'<td class="ids">%s</td>' % re.escape(d[3]), page) for d in C.DICT))
chk('T11 the inputs I1-I7 are all on the page, each with checks', all(f'<td><b>I{i}</b></td>' in page for i in range(1, 8)) and [d[0] for d in C.INPUTS] == ['I%d' % i for i in range(1, 8)])

# ---- the numbers in the text = the lines of the logs they come from
def digits(s): return sorted(re.findall(r'\d+', re.sub(r'(?<=\d),(?=\d{3}\b)', '', s)))
PINS = [
 ('45 → 21 (Pati–Salam, su(4)+su(2)+su(2)) → 15 (Left–Right) → 11 (u(3)+u(1)+u(1)) → 10 (u(3)+u(1))', 'R7', '45 -> 21 (Pati-Salam, su(4)+su(2)+su(2)) -> 15 (Left-Right) -> 11 (u(3)+u(1)+u(1)) -> 10 (u(3)+u(1))'),
 ('24 → 12 (su(3)+su(2)+u(1)) → 10', 'R8', '24 -> 12 (su(3)+su(2)+u(1)), either octonionic reflection -> 10'),
 ('rank 45 each, rank of the union 45', 'R4', 'rank 45 each, rank of the union 45'),
 ('24 dimensions, su(5)', 'R6', '24 dimensions (su(5))'),
 ('has dimension 24 (su(5))', 'R9', 'spinor intersection 24 (su(5))'),
 ('the octonionic spinor 12 (su(3)+su(2)+u(1))', 'R9', 'the octonionic spinor 12 (su(3)+su(2)+u(1))'),
 ('12 solutions, all with the scalar equal to 0', 'R10', '12 solutions, all with c = 0'),
 ('20 random elements', 'T4', '20 random elements'), ('9 + 28 + 96 = 133', 'T5', '9 + 28 + 96 = 133'), ('28 + 28 + 192 = 248', 'T5', '28 + 28 + 192 = 248'),
 ('for all 64 pairs', 'B1', 'for all 64 pairs'), ('there are 168 of them', 'B1', 'the 168 ordered triples'), ('all 65,536 products', 'B2', 'all 65,536 products'),
 ('1 word of weight 0, 14 of weight 4 and 1 of weight 8', 'B3', 'weights 0 (1 word), 4 (14 words), 8 (1 word)'), ('label 123 = 01111011', 'B4', 'label 123 = 01111011'),
 ('number 128', 'B4', 'number 128'), ('real ranks (2, 6, 4, 2, 1, 1)', 'B5', 'real ranks (2, 6, 4, 2, 1, 1)'), ('= 62', 'B5', 'diagonal 62'), ('= 194', 'B5', 'off the diagonal 194'),
 ('block sizes (1, 3, 2, 1, 1): diagonal 16, off the diagonal 48 (complex), total 64', 'B6', 'block sizes (1, 3, 2, 1, 1): diagonal 16, off the diagonal 48 (complex), total 64'),
 ('(32, 20, 8, 2, 1)', 'B6', '(32, 20, 8, 2, 1)'), ('31 = 20 + 8 + 2 + 1', 'B6', '31 = 20 + 8 + 2 + 1'), ('sum to 48', 'B7', 'summing to 48'), ('2·3·2 = 12', 'B7', '2*3*2 = 12'), ('one direction carries 24', 'B7', 'one direction 24'),
 ('of complex dimensions 6, 3, 3, 2, 1, 1: 16 in all', 'B8', 'complex dimensions 6, 3, 3, 2, 1, 1 = 16'), ('3 + 2 + 1 + 2', 'B8', '3 + 2 + 1 + 2'),
 ('Of 18,480 independent commuting grade-4 quadruples, 616 diagonalize', 'B9', 'of 18480 independent commuting grade-4 quadruples, 616 diagonalize'), ('the four axes 0, 3, 8, 11', 'B10', 'the four axes 0, 3, 8, 11'),
 ('256 real dimensions = 128 + 128', 'B11', '256 real dimensions = 128 + 128'), ('16 (diagonal) + 48 (off the diagonal', 'B11', '16 (diagonal) + 48 (off the diagonal'), ('32 carry exotic charges', 'B11', 'of which 32 carry exotic charges'),
 ('(histogram 0: 5,463, 1: 103, 2: 16)', 'B12', '(histogram 0: 5463, 1: 103, 2: 16)'), ('5,582 admissible', 'B12', '5,582 admissible'), ('300 random structures', 'N1', '300 random structures'),
 ('three sets (S = 6) appear first at dimension 14', 'N2', 'three sets (S = 6) appear first at dimension 14'), ('Tr Y = Tr Q = 3', 'F3', 'Tr Y = Tr Q = 3'), ('6Y = −2a − 3b (mod 6)', 'F2', '6Y = -2a - 3b (mod 6)'),
 ('1, 3, 2, 1, 1 and Y = 0, 1/3, 1/2, 1, 0', 'F1', '1, 3, 2, 1, 1 and Y = 0, 1/3, 1/2, 1, 0'), ('(3,2,+1/6)', 'P1', '(3,2,+1/6)'), ('(3,1,+2/3)', 'P1', '(3,1,+2/3)'), ('(1,1,0)', 'P1', '(1,1,0)')]
bad_pins = [p for p in PINS if p[0] not in plain or p[2] not in LINES[p[1]] or digits(p[0]) != digits(p[2])]
chk('T12 the numbers in the text are those of the log lines they cite (%d pins)' % len(PINS), not bad_pins, str(bad_pins))
CN = FG.DATA['counting']
rows = re.findall(r'<tr><td>([^<]*(?:<sub>[^<]*</sub>[^<]*)*)</td><td>\([^<]*\)</td><td class="num">(\d+)</td><td class="num">(\d+)</td><td class="num">(\d+)</td><td class="num">(\d+)</td></tr>', page)
want = [(CN['cells_by_type'][t], CN['sets_on_shell'][t], CN['sets_doubled'][t], CN['missing_for_three_doubled'].get(t, 0)) for t in FG.TYPES]
c1 = LINES['C1']; c2 = LINES['C2']
chk('T13 the table of cells and sets by type: (2,1,2,1) (2,1,2,1) (4,2,4,0) (6,3,6,0) (4,2,4,0) (2,1,2,1); equal the data file; C1 and C2 say the same',
    [tuple(int(x) for x in r[1:]) for r in rows] == want == [(2, 1, 2, 1), (2, 1, 2, 1), (4, 2, 4, 0), (6, 3, 6, 0), (4, 2, 4, 0), (2, 1, 2, 1)]
    and 'the 20 cells hold 2 Q_L, 2 u_R, 4 d_R, 6 L, 4 e_R, 2 nu_R' in c1 and 'two complete sets' in c2 and 'Q_L, u_R and nu_R lack a third copy' in c2 and len(rows) == 6, str(rows))

# ---- the octonion table, recomputed here by a separate Cayley-Dickson product (pure Python)
def conj(x): return [x[0]] + [-v for v in x[1:]]
def cd(x, y):
    n = len(x)
    if n == 1: return [x[0] * y[0]]
    h = n // 2; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    p, q, r, s = cd(a, c), cd(conj(d), b), cd(d, a), cd(b, conj(c))
    return [u - v for u, v in zip(p, q)] + [u + v for u, v in zip(r, s)]
U = [[1 if i == k else 0 for i in range(8)] for k in range(8)]
sign = {}
good = True
for a in range(8):
    for b in range(8):
        pr = cd(U[a], U[b]); nz = [i for i, v in enumerate(pr) if v]
        good &= len(nz) == 1 and nz[0] == a ^ b and abs(pr[nz[0]]) == 1; sign[(a, b)] = pr[nz[0]]
lines7 = {tuple(sorted((a, b, a ^ b))) for a in range(1, 8) for b in range(1, 8) if a != b}
anti = 0; assoc_ok = True
for x, y, z in itertools.product(range(1, 8), repeat=3):
    l, r = cd(cd(U[x], U[y]), U[z]), cd(U[x], cd(U[y], U[z]))
    if len({x, y, z}) == 3 and tuple(sorted((x, y, z))) not in lines7: anti += (l == [-v for v in r] and l != r)
    else: assoc_ok &= l == r
neg = sum(1 for v in sign.values() if v < 0)
ex = cd(cd(U[1], U[2]), U[4]), cd(U[1], cd(U[2], U[4]))
chk('T14 the octonion table of the page, recomputed by a separate product: all 64 products are +-e(a xor b); 7 lines; 168 anti-associating triples; the rest associate; the example (e1e2)e4 = +e7, e1(e2e4) = -e7',
    good and len(lines7) == 7 and anti == 168 and assoc_ok and ex[0][7] == 1 and ex[1][7] == -1 and all(sign[(a, a)] == -1 for a in range(1, 8))
    and '(e<sub>1</sub>e<sub>2</sub>)e<sub>4</sub> = +e<sub>7</sub>' in page and 'e<sub>1</sub>(e<sub>2</sub>e<sub>4</sub>) = −e<sub>7</sub>' in page, f'{good} {anti} {assoc_ok}')
chk('T15 the sign table drawn on the page equals it: %d cells with a plus, %d with a minus' % (64 - neg, neg), len(re.findall(r'<g class="fv-pos"', page)) == 64 - neg and len(re.findall(r'<g class="fv-neg"', page)) == neg
    and all(f'e{a} · e{b} = {"+" if sign[(a, b)] > 0 else "−"}e{a ^ b}' in tips for a in range(8) for b in range(8)))

# ---- fresh runs, the copied scripts, the data file
env = dict(os.environ)
f1 = subprocess.run([sys.executable, 'furey_papers_check.py', '--compare', 'furey_papers.json'], capture_output=True, text=True, env=env).stdout
chk('T16 a fresh run of furey_papers_check.py gives the log, and its data equal the stored data (--compare furey_papers.json)', 'stored data == rebuilt data' in f1 and f1.replace('stored data == rebuilt data\n', '').strip() == LOG1.strip(), 'differs')
f2 = subprocess.run([sys.executable, 'furey_construction_check.py'], capture_output=True, text=True, env=env).stdout
chk('T17 a fresh run of furey_construction_check.py gives the log', f2.strip() == LOG2.strip(), 'differs')
MIRROR = [('furey_papers_check.py', 'selfcheck'), ('threegen_selfcheck.py', 'selfcheck'), ('dictionary_selfcheck.py', 'selfcheck'), ('furey_papers.json', 'selfcheck'), ('model.py', ''), ('run_all.py', '')]
if os.path.isdir(os.path.join(PKG, 'selfcheck')):
    bad_m = [f for f, d in MIRROR if not os.path.exists(os.path.join(PKG, d, f)) or not filecmp.cmp(os.path.join(HERE, f), os.path.join(PKG, d, f), shallow=False)]
    chk('T18 the five scripts and the data file are byte-identical to the atlas\'s copies (selfcheck/ and the package root)', not bad_m, str(bad_m))
else:
    print('skip T18: the atlas package is not beside this folder (set ATLAS_PKG)')
chk('T19 the files of this folder: the scripts, their logs, the builder, the content, the figures, the mutation script, the README', all(os.path.exists(f) for f in ('furey_papers_check.py', 'furey_construction_check.py', 'threegen_selfcheck.py',
    'dictionary_selfcheck.py', 'model.py', 'run_all.py', 'furey_papers.json', 'mutate_furey.py', 'build_report_furey.py', 'content_furey.py', 'figs_furey.py', 'README_furey.md', 'report_style.css', 'report_script.js',
    'logs/furey_papers_check.log', 'logs/furey_construction_check.log', 'logs/mutate_furey.log')))

# ---- the page itself
def external(t):
    return (re.search(r'(src|href)="https?://(?!arxiv\.org)', t) or 'url(http' in t or '@import' in t or re.search(r'<script[^>]+src=', t) or re.search(r'<link[^>]+href', t))
chk('T20 no external request (links to arxiv.org only), the script is inline', not external(page) and '<script>' in page)
chk('T21 no e-mail address, no mail link, no personal address anywhere in the page or in the folder\'s text files', not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', page, flags=re.S)) and ('mail' + 'to:') not in page
    and not any(re.search(r'[\w.+-]+@[\w-]+\.[a-z]{2,}', open(os.path.join(HERE, f), encoding='utf-8').read()) for f in os.listdir(HERE) if f.endswith(('.py', '.md', '.css', '.js', '.json'))))
chk('T22 themes and guards present; the page has a head with the title and one date of issue', 'prefers-color-scheme: dark' in page and ':root[data-theme="dark"]' in page and ':root:not([data-theme="light"])' in page
    and re.search(r'<title>([^<]+)</title>', page).group(1) == C.TITLE and page.count('7 October 2026') >= 2 and not re.search(r'\b\d{1,2} (January|February|March|April|May|June|July|August|September|November|December) 202[56]', plain.replace('7 October 2026', '')))
chk('T23 size is reasonable (< 400 kB)', len(page.encode('utf-8')) < 400_000, str(len(page)))
chk('T24 no history in the visible text of the page (shared pattern list, reports/no_history.py), no corrections section, no struck sentence; every "<" in a text node is written &lt;, so the reader sees all the text', not NH.scan_page(page) and not NH.bare_lt(page) and not re.search(r'\bE-\d{3}\b', plain), str(NH.scan_page(page)[:3]))
chk('T25 the history scan catches its planted phrases', not NH.selftest(), str(NH.selftest()))
chk('T26 nothing addressed to a person: no letter wording, no "you", no name of a person as addressee', not re.search(r'\b(dear|sincerely|yours|your|you|please|thank)\b', plain, re.I), str(re.findall(r'\b(?:dear|sincerely|yours|your|you|please|thank)\b', plain, re.I)[:3]))
chk('T27 the calibration is named in the current wording: Calibration 2 (Furey), the defining sentence; no "Test 2", no "Warm-up", no step numbers', 'Calibration 2 (Furey)' in plain and 'A calibration is a run on something whose answer is known, to show which inputs the method needs; it is not a test of a new theory.' in plain
    and 'Test 2' not in plain and 'Warm-up' not in plain and not re.search(r'[Ss]teps? \d', plain))
FORBIDDEN = ['derive', 'proves that nature', 'the universe is', 'reality is', 'explains why nature', 'predicts', 'discovers', 'a wall', 'nature has three', 'explains the three generations', 'the particles of nature are',
             'is the electron', 'is the top quark']
outside = (plain + ' ' + tips).lower()
chk('T28 the forbidden sentences are nowhere on the page (text and tooltips); no reading is called derived', not any(w in outside for w in FORBIDDEN), str([w for w in FORBIDDEN if w in outside]))
RIGHT = ['Nothing here is a result about nature', 'nothing says that a cell, a block or a product of irreps is a particle', 'This paper has not been read', 'The Cartan factorization that recasts V as a product of spinor and conjugate-spinor representations',
         'are not rebuilt', 'so they show that the quantum numbers can be recovered, nothing more', 'It does not say that three generations of nature must come from a bigger block', 'The two counts answer different questions and are not compared with each other',
         'Whether the products are physical states, and with which dynamics, is not computed', 'This report makes no statement about a weak mixing angle', 'independent here means', 'the checkpoint of Coleman–Mandula is not tested',
         'a sign that fails to associate', 'The counts are about colour, isospin and hypercharge only', 'is input of the construction, not forced by the Witt pairing', 'is not established here']
chk('T29 the right wording is on the page', all(t in plain for t in RIGHT), str([t for t in RIGHT if t not in plain]))
chk('T30 the five tags are explained at the head (a legend of chips, words and meanings), input among them', all(t in SK.kinds(page.split('<nav')[0]) for t in ('standard', 'checked', 'ours', 'open', 'input')) and 'a choice or datum the physics page needs that the algebra does not supply' in plain)
chk('T31 inputs are tagged in the findings, and the section Inputs says what the algebra does supply', sum(1 for f in fin.values() if 'input' in f[0]) >= 7 and 'What the algebra does supply' in plain)
chk('T32 limits and open items are stated: no dynamics, Cartan factorization not rebuilt, the 2025 paper not read, the cells are not particle states, three generations not decided',
    all(s in plain for s in ('Dynamics.', 'The Cartan factorization of Trialities.', 'The superalgebra paper has not been read.', 'The physical status of the cells.', 'Three generations.', 'Dead ends and honest limits')))
chk('T33 tooltips on the drawings: 64 + 13 + 11 + 25 + 7 = 120', page.count('data-tip="') == 120, str(page.count('data-tip="')))
chk('T34 the drawings are drawn from the data: 13 ladder bars, 11 blocks (6 + 5, 3 of them glued), 5 gauge cells and 20 cells by type 2, 2, 4, 6, 4, 2 with 8 beyond the first generation, 7 room bars (1 of three sets)',
    len(re.findall(r'<g class="fv-bar"', page)) == 19 and len(re.findall(r'<g class="fv-bar three"', page)) == 1 and len(re.findall(r'<g class="fv-blk', page)) == 11 and page.count('fv-blk glued') == 3
    and page.count('class="fv-gauge"') == 5 and [page.count(f'<g class="fv-cell ft{i}') for i in range(6)] == [2, 2, 4, 6, 4, 2] and page.count(' beyond"') == 8)
chk('T35 the six papers: the arXiv numbers are linked, the months are those of the identifiers, the 2025 paper is marked as not read', all(f'href="https://arxiv.org/abs/{n}"' in page for n in ('2312.12377', '2312.12799', '2312.14207', '2409.17948', '2505.07923', '2607.18450'))
    and plain.count('December 2023') >= 3 and 'September 2024' in plain and 'May 2025' in plain and 'July 2026' in plain and 'This paper has not been read.' in plain)
chk('T36 the page does not mention any other report by file name', not re.search(r'_report\.html|\.zip|MANIFEST', plain))

# ---- the status chips and the sabotage coverage
chk('T37 every status is an icon chip (role img, name and hover text start with the word, the drawing of the atlas badge, no word chip, one legend entry per flag); all five flags are used',
    not SK.problems(page) and set(SK.kinds(page)) == set(SK.FLAGS), str(SK.problems(page)[:3]))
_rx = re.compile(r",\s*'([A-Z]\d+[a-z]?)'\)\s*,?\s*(?:#.*)?$")
_named = {m.group(1) for m in (_rx.search(l.rstrip('\n')) for l in open('mutate_furey.py', encoding='utf-8')) if m}
_mc = re.search(r'Checks with at least one sabotage: (\d+) of (\d+)\s*; the others \(([^)]*)\) have none', plain)
chk('T38 the sabotage card says how many of the 42 checks have at least one sabotage (38 of 42, as the target ids of the mutants of mutate_furey.py give) and names the four that have none: B3, B6, R2, R5',
    _named <= set(IDS) and bool(_mc) and (int(_mc.group(1)), int(_mc.group(2))) == (len(_named), len(IDS)) == (38, 42) and _mc.group(3) == ', '.join(sorted(set(IDS) - _named)) == 'B3, B6, R2, R5', str(_mc.groups() if _mc else None))

# ---- browser behaviour (needs playwright with Chromium)
NOBROWSER = bool(os.environ.get('REPORT_NO_BROWSER'))
NB = 12
if NOBROWSER:
    print('skip the %d browser tests: REPORT_NO_BROWSER is set' % NB)
else:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1100, 'height': 900})
        errs = []; reqs = []
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.on('request', lambda r: reqs.append(r.url) if not r.url.startswith(('file:', 'data:')) else None)
        pg.goto('file://' + os.path.abspath(PAGE)); pg.wait_for_timeout(200)
        chk('B1 no page errors, no network requests', not errs and not reqs, str((errs[:2], reqs[:2])))
        chk('B2 drawings: 64 table cells; 13 + 7 bars; 6 + 5 blocks; 20 cells and 5 gauge cells', pg.locator('#s5 svg g.fv-pos, #s5 svg g.fv-neg').count() == 64 and pg.locator('#s2 svg g.fv-bar').count() == 13 and pg.locator('#s7 svg g.fv-blk').count() == 11
            and pg.locator('#s10 svg g.fv-cell').count() == 20 and pg.locator('#s10 svg g.fv-gauge').count() == 5 and pg.locator('#s13 svg g.fv-bar').count() == 7)
        cell = pg.locator('#s5 g.fv-neg').first; cell.scroll_into_view_if_needed(); pg.wait_for_timeout(250); cell.hover(); pg.wait_for_timeout(150)
        chk('B3 tooltip on a table cell (hover) gives the product and the check', pg.locator('#tip.on').count() == 1 and re.search(r'e\d · e\d = −e\d', pg.inner_text('#tip')) and 'check B1' in pg.inner_text('#tip'))
        bc = pg.locator('#s10 g.fv-cell').nth(5); bc.scroll_into_view_if_needed(); pg.wait_for_timeout(250); bc.focus(); pg.wait_for_timeout(150)
        chk('B4 tooltip on a board cell (focus) names its irrep, its labels and the checks', pg.locator('#tip.on').count() == 1 and 'irrep' in pg.inner_text('#tip') and 'labels in the figure' in pg.inner_text('#tip') and 'checks F1, F4' in pg.inner_text('#tip'))
        bar = pg.locator('#s13 g.fv-bar').last; bar.scroll_into_view_if_needed(); pg.wait_for_timeout(250); bar.focus(); pg.wait_for_timeout(150)
        chk('B5 tooltip on the last room bar: dimension 14, 264,810 structures, the checks', pg.locator('#tip.on').count() == 1 and 'complex dimension 14' in pg.inner_text('#tip') and '264,810' in pg.inner_text('#tip') and 'checks N1, N2' in pg.inner_text('#tip'))
        lb = pg.locator('#s2 g.fv-bar').first; lb.scroll_into_view_if_needed(); pg.wait_for_timeout(250); lb.focus(); pg.wait_for_timeout(150)
        chk('B6 tooltip on the first ladder bar: Spin(10), dimension 45', pg.locator('#tip.on').count() == 1 and 'dimension 45' in pg.inner_text('#tip') and 'check R7' in pg.inner_text('#tip'))
        pg.click('#themebtn'); chk('B7 theme button: light', pg.get_attribute('html', 'data-theme') == 'light')
        fill_l = pg.evaluate("getComputedStyle(document.querySelector('#s10 g.fv-cell.ft0 rect')).fill")
        pg.click('#themebtn'); chk('B8 theme button: dark, and the board colours change with it', pg.get_attribute('html', 'data-theme') == 'dark' and pg.evaluate("getComputedStyle(document.querySelector('#s10 g.fv-cell.ft0 rect')).fill") != fill_l)
        chk('B9 no horizontal overflow at 1100', pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth') <= 0)
        pg.set_viewport_size({'width': 375, 'height': 800}); pg.wait_for_timeout(150)
        chk('B10 no horizontal overflow at 375', pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth') <= 0, str(pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth')))
        wide = pg.evaluate('''() => [...document.querySelectorAll('.finding, .card, .notice, .kpi, section > p')].filter(e => e.scrollWidth > e.clientWidth + 2 && getComputedStyle(e).overflowX === 'visible').map(e => e.id || e.className).slice(0, 5)''')
        chk('B11 no card overflows its box at 375', not wide, str(wide))
        chk('B12 at 375 each drawing scrolls inside its own box (the drawing keeps a readable width)', pg.evaluate('''() => [...document.querySelectorAll('.sv')].every(e => e.scrollWidth >= e.clientWidth)''') and pg.locator('.sv').count() == 5)
        b.close()
print('\ntest_report_furey: %d ok, %d failed' % (ok, bad) + (', %d browser tests skipped' % NB if NOBROWSER else '')); sys.exit(1 if bad else 0)
