#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Builds ../html/furey_report.html: one self-contained page (inline CSS, SVG and a little JS, no external request).
Every number in it is read from logs/furey_papers_check.log and logs/furey_construction_check.log (the checks), logs/mutate_furey.log (the sabotage run) and furey_papers.json
(the data that furey_papers_check.py writes), or computed here from the explicit octonion product of model.py; none is typed by hand except the text of content_furey.py,
which test_report_furey.py pins against the logs.
Run: python3 furey_papers_check.py > logs/furey_papers_check.log ; python3 furey_construction_check.py > logs/furey_construction_check.log ;
     python3 mutate_furey.py > logs/mutate_furey.log ; python3 build_report_furey.py"""
import os, sys, re, html
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import content_furey as C
import figs_furey as FG
import status_chips as SC

E = html.escape
TODAY = '7 October 2026'

# ------------------------------------------------------------------ the checks (from the logs) and the sabotage run
def read_log(name):
    ids, texts, bad = [], {}, 0
    for line in open(os.path.join(HERE, 'logs', name), encoding='utf-8'):
        m = re.match(r'(ok|FAIL)\s+([A-Z]\d+):?\s+(.*)', line)
        if m:
            if m.group(1) == 'ok': ids.append(m.group(2)); texts[m.group(2)] = m.group(3)
            else: bad += 1
    return ids, texts, bad
IDS1, TEXTS, BAD1 = read_log('furey_papers_check.log')
IDS2, TEXTS2, BAD2 = read_log('furey_construction_check.log')
TEXTS.update(TEXTS2)
IDS = IDS1 + IDS2
BAD = BAD1 + BAD2
assert BAD == 0, 'a check fails: fix it before building the report'
assert len(IDS1) == 30 and len(IDS2) == 12 and len(set(IDS)) == 42, (len(IDS1), len(IDS2))
OK = len(IDS)
_m = re.search(r'mutants caught: (\d+) of (\d+)', open(os.path.join(HERE, 'logs', 'mutate_furey.log'), encoding='utf-8').read())
MUT_OK, MUT_ALL = int(_m.group(1)), int(_m.group(2))
assert MUT_OK == MUT_ALL, 'a sabotage was missed'
_rx = re.compile(r",\s*'([A-Z]\d+[a-z]?)'\)\s*,?\s*(?:#.*)?$")                 # the id of the check that a mutant must make fail ends its line
_named = {m.group(1) for m in (_rx.search(l.rstrip('\n')) for l in open(os.path.join(HERE, 'mutate_furey.py'), encoding='utf-8')) if m}
MUT_NAMED = len(_named & set(IDS)); MUT_UNNAMED = ', '.join(sorted(set(IDS) - _named))
assert MUT_NAMED + len(set(IDS) - _named) == len(IDS) and _named <= set(IDS), sorted(_named - set(IDS))
BLOCKS = [(b[0], b[1], sum(1 for i in IDS if i.startswith(b[0])), b[2]) for b in C.CHECK_BLOCKS]
assert sum(b[2] for b in BLOCKS) == OK, (sum(b[2] for b in BLOCKS), OK)

# ------------------------------------------------------------------ facts that the drawings and the text use, tied to the log lines
def lt(i): return TEXTS[i]
assert '(2, 6, 4, 2, 1, 1)' in lt('B5') and '(1, 3, 2, 1, 1)' in lt('B6')
assert [s for _, s in FG.REAL_BLOCKS] == [2, 6, 4, 2, 1, 1] and [s for _, s in FG.CX_BLOCKS] == [1, 3, 2, 1, 1]
assert '45 -> 21' in lt('R7') and '-> 15' in lt('R7') and '-> 11' in lt('R7') and '-> 10' in lt('R7') and '24 -> 12' in lt('R8') and '-> 10' in lt('R8') and '-> 9' in lt('R8')
LAD = FG.DATA['roadmap']
assert [s['dim'] for s in LAD['spin10_line']] == [45, 21, 15, 11, 10] and [s['dim'] for s in LAD['su5_line']] == [24, 12, 10, 9]
assert 'spinor intersection 24' in lt('R9') and 'three-way with the octonionic spinor 12' in lt('R9') and 'five-way with the quaternionic and complex spinors 9' in lt('R9') and 'also 9' in lt('R9')
assert [LAD['intersections'][k] for k in ('vector_spinor', 'three_way_O', 'five_way_O_H_C', 'four_way_no_O')] == [24, 12, 9, 9]
assert 'the 20 cells hold 2 Q_L, 2 u_R, 4 d_R, 6 L, 4 e_R, 2 nu_R' in lt('C1') and FG.type_counts() == {'Q_L': 2, 'u_R': 2, 'd_R': 4, 'L': 6, 'e_R': 4, 'nu_R': 2}
assert 'two complete sets' in lt('C2') and 'Q_L, u_R and nu_R lack a third copy' in lt('C2')
assert '5,582' in lt('N1') and 'S = 6' in lt('N2') and 'dimension 14' in lt('N2') and '5,582' in lt('B12') and 'histogram 0: 5463, 1: 103, 2: 16' in lt('B12')
RM = FG.DATA['room']
assert RM['first_dimension_with_three_sets'] == 14 and [RM['by_dimension'][str(d)]['max_S'] // 2 for d in range(8, 15)] == [1, 1, 1, 2, 2, 2, 4]
assert RM['by_dimension']['8']['structures'] == 5582
assert '18480' in lt('B9') and '616' in lt('B9') and '168' in lt('B1') and '65,536' in lt('B2') and 'label 123' in lt('B4') and '128' in lt('B4')
assert '(Hamming' not in lt('B3') and 'extended Hamming code' in lt('B3') and 'S(3,4,8)' in lt('B3')
assert 'diagonal 62' in lt('B5') and 'off the diagonal 194' in lt('B5') and 'diagonal 16, off the diagonal 48' in lt('B6') and '(32, 20, 8, 2, 1)' in lt('B6') and 'dimension 31' in lt('B6')
assert 'summing to 48' in lt('B7') and 'one direction 24' in lt('B7') and '3 + 2 + 1 + 2 = 24' in lt('B8')
assert '0, 3, 8, 11' in lt('B10') and 'eight -1 signs' in lt('B10')
AX = FG.assoc_example()                                   # ((x, y, z), (xy)z sign, x(yz) sign, label of the result)
(ax, ay, az), sl, sr_, ak = AX
assert sl == -sr_ and ak == ax ^ ay ^ az

# ------------------------------------------------------------------ the page pieces
def chip(kind): return SC.chip(kind)      # a status is an icon chip: the word is its aria-label and title, never visible

def wrap_sv(h):                                           # a drawing scrolls sideways on a phone instead of shrinking its text to nothing
    return re.sub(r'(<svg [^>]*class="chart[^"]*"[^>]*>.*?</svg>)', r'<div class="sv">\1</div>', h, flags=re.S)

def fig(title, body, cap=''):
    return f'<figure class="fig"><div class="figtitle">{title}</div>{wrap_sv(body)}' + (f'<figcaption>{cap}</figcaption>' if cap else '') + '</figure>'

FIGS = {
 'OCT': fig('Drawing 1 · The octonion product table', FG.octonion_figure(),
            'The cell in row a and column b shows the sign and the label of e<sub>a</sub>e<sub>b</sub> = ±e<sub>a⊕b</sub>. Hover or focus a cell for the product and the labels in binary.'),
 'LADDERS': fig('Drawing 2 · The two ladders of reflections and the intersections', FG.ladders_figure(),
                'Dimension of the algebra left by each choice, from the checks R7 to R9. Hover or focus a bar for its algebra and the reflections applied.'),
 'BOARDS': fig('Drawing 3 · The two boards', FG.boards_figure(),
               'Left, the real board End<sub>ℝ</sub>(V) with diagonal blocks of sizes 2, 6, 4, 2, 1, 1. Right, the complex board End<sub>ℂ</sub>(V), where ω fuses the last two rank-1 blocks: sizes 1, 3, 2, 1, 1, '
               'each with the irrep (colour, isospin, hypercharge) of its block. Hover or focus a block.'),
 'BOARD': fig('Drawing 4 · The board of Fig. 1 of the 2026 paper', FG.board_figure(),
              'Cell (row, column) is the operator from the block of its row to the block of its column; its irrep is block(column) ⊗ conjugate block(row). The colour is the Standard Model type of the irrep, '
              'the dashed outline marks the cells beyond the first generation. Hover or focus a cell for its irrep, labels and electric charges.'),
 'ROOM': fig('Drawing 5 · Room for complete sets', FG.room_figure(),
             'The most complete sets held by any admissible block structure of complex dimension 8 to 14, with the number of structures. Hover or focus a bar for the structures by sets held and one structure that reaches the best.'),
}

# the ten edges, from the 20 cells of Fig. 1: for each pair of blocks the direction whose irrep is the particle's own
SIZES = [s for _, s in FG.CX_BLOCKS]
cells = {(c['row'], c['col']): c for c in FG.DATA['fig1']['cells']}
edge_rows = []
for i in range(5):
    for j in range(i + 1, 5):
        a, b = cells[(i, j)], cells[(j, i)]
        ta, oa = FG.cell_type(a['irrep']); tb, ob = FG.cell_type(b['irrep'])
        assert ta == tb
        pick = (i, j) if oa == 'particle' and (ob != 'particle' or not a['dagger']) else (j, i)
        c = cells[pick]
        assert FG.cell_type(c['irrep'])[1] == 'particle'
        edge_rows.append((i, j, pick, c, ta))
assert len(edge_rows) == 10
cap = [2 * SIZES[i] * SIZES[j] for i, j, *_ in edge_rows]
assert sum(cap) == 48 and max(cap) == 12
first_cells = [r for r in edge_rows if FG.first_generation(r[3])]
assert len(first_cells) == 6
edges_tab = ('<div class="tvscroll" style="max-height:none"><table><caption class="sr">The ten edges between the five blocks</caption><thead><tr><th>Edge</th><th class="num">Capacity</th><th>Irrep, one direction</th><th>Type</th>'
             '<th>Labels in Fig. 1</th><th>In Fig. 1</th></tr></thead><tbody>'
             + ''.join(f'<tr><td>{i} – {j}</td><td class="num">{cap[k]}</td><td>from {p[0]} to {p[1]}: {E(FG.pretty(c["irrep"]))}</td><td>{FG.sub_html(FG.TYPE_TEXT[t].split(" (")[0])}</td>'
                       f'<td>{FG.sub_html(FG.greek(c["labels"][0]))}</td><td>{"first generation" if FG.first_generation(c) else "beyond the first generation"}</td></tr>'
                       for k, (i, j, p, c, t) in enumerate(edge_rows))
             + f'<tr><td><b>Total</b></td><td class="num"><b>{sum(cap)}</b></td><td colspan="4">one direction: {sum(cap) // 2}</td></tr></tbody></table></div>')

CN = FG.DATA['counting']
rows_c = []
for t in FG.TYPES:
    rows_c.append(f'<tr><td>{FG.sub_html(FG.TYPE_TEXT[t].split(" (")[0])}</td><td>{E(FG.SM_IRREP[t].replace("-", "−"))}</td><td class="num">{CN["cells_by_type"][t]}</td><td class="num">{CN["sets_on_shell"][t]}</td>'
                  f'<td class="num">{CN["sets_doubled"][t]}</td><td class="num">{CN["missing_for_three_doubled"].get(t, 0)}</td></tr>')
assert min(CN['sets_on_shell'].values()) == 1 and min(CN['sets_doubled'].values()) == 2 and CN['missing_for_three_doubled'] == {'Q_L': 1, 'u_R': 1, 'nu_R': 1}
counts_tab = ('<div class="tvscroll" style="max-height:none"><table><caption class="sr">Cells and complete sets by Standard Model type</caption><thead><tr><th>Type</th><th>Irrep</th><th class="num">Cells</th>'
              '<th class="num">Sets, one label per cell</th><th class="num">Sets, every cell doubled</th><th class="num">Short of three, doubled</th></tr></thead><tbody>'
              + ''.join(rows_c) + f'<tr><td><b>Complete sets</b></td><td></td><td class="num"></td><td class="num"><b>{min(CN["sets_on_shell"].values())}</b></td><td class="num"><b>{min(CN["sets_doubled"].values())}</b></td><td class="num"></td></tr></tbody></table></div>')

def finding(fid, title, chips, left, right, ids):
    wide = any(('%%' + k + '%%') in left + right for k in ('FIG_LADDERS', 'FIG_BOARDS', 'FIG_BOARD', 'FIG_ROOM', 'TAB_EDGES', 'TAB_COUNTS'))
    cls = 'fbody one' if wide else 'fbody'
    ch = ''.join(chip(c) for c in chips)
    subs = {'%%FIG_' + k + '%%': v for k, v in FIGS.items()}
    subs.update({'%%TAB_EDGES%%': edges_tab, '%%TAB_COUNTS%%': counts_tab, '%%AX%%': str(ax), '%%AY%%': str(ay), '%%AZ%%': str(az), '%%AK%%': str(ak),
                 '%%AL%%': '+' if sl > 0 else '−', '%%AR%%': '+' if sr_ > 0 else '−'})
    for k, v in subs.items(): left = left.replace(k, v); right = right.replace(k, v)
    assert '%%' not in left + right, fid
    return (f'<article class="finding" id="{fid.lower()}"><div class="fhead"><span class="fid">{fid}</span><h3>{title}</h3><div class="chips">{ch}</div></div>'
            f'<div class="{cls}"><div>{left}</div><div>{right}<p class="ids">checks {ids}.</p></div></div></article>')

FINDINGS = ''.join(finding(*f) for f in C.FINDINGS)

def paper_card(pid, name, title, who, ref, date, builds, rebuilt, ids, chips):
    num = ref.split(':')[1]
    return (f'<div class="card paper" id="paper-{pid}"><h3>{name}</h3><div class="by">{title} · {who} · <a href="https://arxiv.org/abs/{num}">{ref}</a> · {date}</div>'
            f'<p><b>It builds.</b> {builds}</p><p><b>Rebuilt here.</b> {rebuilt}</p><p class="ids">checks {ids}.</p><p>{"".join(chip(c) for c in chips)}</p></div>')
PAPERS = ''.join(paper_card(*p) for p in C.PAPERS)

def tagspan(t): return ' '.join(SC.chip(w) for w in re.split(r' · ', t))
DICT_ROWS = ''.join(f'<tr><td>{o}</td><td>{b}</td><td>{tagspan(t)}</td><td class="ids">{c}</td></tr>' for o, b, t, c in C.DICT)
INPUT_ROWS = ''.join(f'<tr><td><b>{i}</b></td><td>{w}</td><td>{s}</td><td class="ids">{c}</td></tr>' for i, w, s, c in C.INPUTS)
CHECKS_TABLE = ''.join(f'<tr><td><b>{E(b[0])}</b></td><td>{b[1]}</td><td class="num">{b[2]}</td><td><code>{E(b[3])}</code></td></tr>' for b in BLOCKS)
LIM1 = ''.join(f'<li>{x}</li>' for x in C.LIMITS_REACH); LIM2 = ''.join(f'<li>{x}</li>' for x in C.LIMITS_DONE)
SRC = ''.join(f'<li>{x}</li>' for x in C.SOURCES)
CHIPS = SC.legend(['standard', 'checked', 'ours', 'open', 'input'], {'standard': "textbook or the paper's own statement, used as is", 'input': 'a choice or datum the physics page needs that the algebra does not supply'})

CSS = open(os.path.join(HERE, 'report_style.css'), encoding='utf-8').read() + SC.CSS
CSS += '''
/* the Furey report */
.sr{position:absolute;left:-9999px}
:root{--ft0:#cfe3f5;--fs0:#0072b2;--ft1:#fbd9c2;--fs1:#d55e00;--ft2:#c5ebdf;--fs2:#009e73;--ft3:#f3d9e7;--fs3:#b8578c;--ft4:#fbe6b8;--fs4:#c78500;--ft5:#d6ecfa;--fs5:#2f8fc7}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--ft0:#1b3a54;--fs0:#56a3d9;--ft1:#50301a;--fs1:#f08a4b;--ft2:#17433a;--fs2:#2fc9a0;--ft3:#4a2b3c;--fs3:#e6a5c8;--ft4:#4d3e12;--fs4:#f3b73d;--ft5:#1d3f52;--fs5:#8ccdf2}}
:root[data-theme="dark"]{--ft0:#1b3a54;--fs0:#56a3d9;--ft1:#50301a;--fs1:#f08a4b;--ft2:#17433a;--fs2:#2fc9a0;--ft3:#4a2b3c;--fs3:#e6a5c8;--ft4:#4d3e12;--fs4:#f3b73d;--ft5:#1d3f52;--fs5:#8ccdf2}
svg.fv .fv-x{fill:var(--ink2);font:12px system-ui,sans-serif}svg.fv .fv-h,svg.fv .fv-h2{fill:var(--ink);font:700 14px system-ui,sans-serif}
svg.fv .fv-s{fill:var(--ink2);font:11.5px system-ui,sans-serif}svg.fv .fv-n{fill:var(--ink);font:700 15px system-ui,sans-serif}svg.fv .fv-n2{fill:var(--ink);font:600 13px system-ui,sans-serif}
svg.fv .fv-pos rect{fill:var(--tint);stroke:var(--line2)}svg.fv .fv-neg rect{fill:var(--ours);stroke:var(--ours)}svg.fv .fv-neg text{fill:#0b0b0b}
.sw.fv-swpos{background:var(--tint);border:1px solid var(--line2);color:var(--ink)}.sw.fv-swneg{background:var(--ours);color:#0b0b0b}
svg.fv g[data-tip]:hover rect,svg.fv g[tabindex]:focus rect{stroke:var(--ink);stroke-width:2}
svg.fv .fv-bar rect{fill:var(--e);stroke:var(--e)}svg.fv .fv-bar.three rect{fill:var(--chk);stroke:var(--chk)}
svg.fv .fv-ax{stroke:var(--line2);stroke-width:1}svg.fv .fv-hz{stroke:var(--open);stroke-width:1.5;stroke-dasharray:4 3}
svg.fv .fv-board{fill:var(--tint);stroke:var(--ink);stroke-width:1.5}svg.fv .fv-blk rect{fill:var(--surf);stroke:var(--ink);stroke-width:1.5}svg.fv .fv-blk.glued rect{fill:var(--ours)}
.sw.fv-swblk{background:var(--surf);border:1.5px solid var(--ink);color:var(--ink)}.sw.fv-swglue{background:var(--ours);color:#0b0b0b}
svg.fv .fv-gauge rect{fill:var(--tint);stroke:var(--line2);stroke-dasharray:3 3}svg.fv .fv-cell rect{stroke-width:1.6}svg.fv .fv-cell.beyond rect{stroke-dasharray:5 3}
svg.fv .ft0 rect{fill:var(--ft0);stroke:var(--fs0)}svg.fv .ft1 rect{fill:var(--ft1);stroke:var(--fs1)}svg.fv .ft2 rect{fill:var(--ft2);stroke:var(--fs2)}
svg.fv .ft3 rect{fill:var(--ft3);stroke:var(--fs3)}svg.fv .ft4 rect{fill:var(--ft4);stroke:var(--fs4)}svg.fv .ft5 rect{fill:var(--ft5);stroke:var(--fs5)}
.sw.ftsw0{background:var(--ft0);border:1.5px solid var(--fs0);color:var(--ink)}.sw.ftsw1{background:var(--ft1);border:1.5px solid var(--fs1);color:var(--ink)}.sw.ftsw2{background:var(--ft2);border:1.5px solid var(--fs2);color:var(--ink)}
.sw.ftsw3{background:var(--ft3);border:1.5px solid var(--fs3);color:var(--ink)}.sw.ftsw4{background:var(--ft4);border:1.5px solid var(--fs4);color:var(--ink)}.sw.ftsw5{background:var(--ft5);border:1.5px solid var(--fs5);color:var(--ink)}
.sw.fv-swbeyond{background:var(--surf);border:1.5px dashed var(--ink);color:var(--ink)}
'''
JS = open(os.path.join(HERE, 'report_script.js'), encoding='utf-8').read()

TEMPLATE = r'''<!doctype html>
<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 -->
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%%TITLE%%</title>
<meta name="description" content="Furey's papers on the Standard Model and the division algebras, rebuilt from the octonion table and counted: the numbers recomputed, the explicit model read in the bit rule, the inputs the construction makes, and the checks.">
<style>%%CSS%%</style>
</head>
<body>
<header class="hero"><div class="wrap">
 <span class="kick">Furey lens · %%TODAY%%</span>
 <h1>%%H1%%</h1>
 <p class="sub">%%SUB%%</p>
 <div class="notice">%%NOTICE%%</div>
 <div class="kpis">
  <div class="kpi"><b>%%NOK%%</b><span>checks pass, %%NBAD%% fail</span></div>
  <div class="kpi"><b>%%MUTOK%% of %%MUTALL%%</b><span>deliberate sabotages of the checks were caught (automated)</span></div>
  <div class="kpi"><b>%%NFIND%%</b><span>findings, each with its tags and check ids</span></div>
  <div class="kpi"><b>%%NINP%%</b><span>inputs the construction makes that the algebra does not supply</span></div>
 </div>
 <p class="lead"><b>In one paragraph.</b> %%LEAD%%</p>
 <p style="font-size:13.5px;color:var(--muted)">%%CHIPS%%</p>
</div></header>

<nav class="toc"><div class="wrap">
 <a href="#how">What is done</a><a href="#papers">Papers</a><a href="#findings">Findings</a><a href="#dict">Dictionary</a><a href="#inputs">Inputs</a><a href="#limits">Limits</a><a href="#checks">Checks</a><a href="#src">Sources</a>
 <button id="themebtn" type="button" aria-label="Switch colour theme">theme: auto</button>
</div></nav>

<main class="wrap">

<section id="how"><h2>What is done <small>rebuilt, read, counted</small></h2>
 <div class="grid3">
  <div class="card"><h3>1 · Rebuilt from the octonion table</h3><p>The explicit algebra is built from the multiplication table of the octonions, not typed in: the ten gamma matrices of the Roadmap, the derivations of 𝕆, and the sixteen-dimensional space V of the 2026 paper. <code>furey_papers_check.py</code> runs %%NP%% checks (about 30 seconds); <code>furey_construction_check.py</code> runs the three scripts that build V and prints %%NB%% more (about 10 seconds).</p></div>
  <div class="card"><h3>2 · Read in the bit rule</h3><p>The octonion table, Cl(0,8), the sixteen axes with their Hamming code and the complex structure ω are written as labels (the Dictionary): which label, which sign, which product. The findings S5 to S7 and S14 state what that reading adds and what it does not.</p></div>
  <div class="card"><h3>3 · Counted, with the inputs named</h3><p>Fig. 1 of the 2026 paper is compared cell by cell with the ten edges; complete Standard Model sets are counted in three conventions that are kept apart. Where the construction makes a choice that the rule does not make (the complex structure, the partition of the axes, the labels), the finding says so and the section Inputs lists it.</p></div>
 </div>
</section>

<section id="papers"><h2>Papers <small>six, in order of appearance</small></h2>
 <p class="lead">What each paper builds, and which of its numbers are recomputed here. The paper of 2025 has not been read; its figure is checked as the 2026 paper prints it.</p>
 <div class="papers">%%PAPERS%%</div>
</section>

<section id="findings"><h2>Findings <small>each with its tags and check ids</small></h2>
%%FINDINGS%%
</section>

<section id="dict"><h2>Dictionary <small>the objects as labels</small></h2>
 <p class="lead">Each row is an object of the papers, what it is in the bit rule, its tags and the checks that compute it.</p>
 <div class="tvscroll" style="max-height:none"><table><thead><tr><th>Object</th><th>In the bit rule</th><th>Tags</th><th>Checks</th></tr></thead><tbody>%%DICT%%</tbody></table></div>
</section>

<section id="inputs"><h2>Inputs <small>what the algebra does not supply</small></h2>
 <p class="lead">An input is a choice or a datum the construction needs that the algebra does not supply. Each is tagged input in the findings above.</p>
 <div class="tvscroll" style="max-height:none"><table><thead><tr><th>Id</th><th>The construction needs</th><th>What the algebra does supply</th><th>Checks</th></tr></thead><tbody>%%INPUTS%%</tbody></table></div>
</section>

<section id="limits"><h2>Dead ends and honest limits</h2>
 <div class="grid2">
  <div class="card"><h3>What the algebra does not reach</h3><ul class="tight">%%LIM1%%</ul></div>
  <div class="card"><h3>What was not done or verified</h3><ul class="tight">%%LIM2%%</ul></div>
 </div>
</section>

<section id="checks"><h2>Checks <small>%%NOK%% pass, %%NBAD%% fail</small></h2>
 <div class="grid2">
  <div class="card"><div style="overflow-x:auto"><table><thead><tr><th>Block</th><th>What it tests</th><th class="num">Checks</th><th>Script</th></tr></thead><tbody>%%CHECKS%%<tr><td></td><td><b>Total</b></td><td class="num"><b>%%NOK%%</b></td><td></td></tr></tbody></table></div></div>
  <div class="card"><h3>Sabotage test</h3><p>Each of %%MUTALL%% deliberate changes (a flipped sign, a wrong count, a wrong hypercharge, a wrong label, a wrong constant) is made in a temporary copy of one of the scripts and must make the named check fail: <b>%%MUTOK%% of %%MUTALL%% are caught</b>. A crash that does not point at the named check does not count as caught. Checks with at least one sabotage: <b>%%MUTNAMED%% of %%NOK%%</b>; the others (%%MUTUNNAMED%%) have none. The five scripts that are copies of the atlas's own are changed only in the temporary copies.</p>
   <h3 style="margin-top:12px">Rerun</h3><pre>cd reports/furey
python3 furey_papers_check.py &gt; logs/furey_papers_check.log               # %%NP%% checks, about 30 seconds
python3 furey_construction_check.py &gt; logs/furey_construction_check.log   # %%NB%% checks, about 10 seconds
python3 mutate_furey.py &gt; logs/mutate_furey.log                           # automated sabotage, about 5 minutes
python3 build_report_furey.py                                             # this page, into ../html/
python3 test_report_furey.py</pre><p style="font-size:13px;color:var(--muted)">Needs Python 3 and numpy. <code>python3 furey_papers_check.py --compare furey_papers.json</code> asserts that the stored data equals the rebuilt data. The atlas package this folder ships in is only needed for the byte-for-byte comparison of the copied scripts in the tests (two folders up, or set <code>ATLAS_PKG</code>).</p>
  </div>
 </div>
</section>

<section id="src"><h2>Sources</h2>
 <ul class="tight">%%SRC%%</ul>
</section>
</main>
<footer><div class="wrap">Cascade Atlas · preliminary report, %%TODAY%% · generated by <code>build_report_furey.py</code> from the logs, the data file and the explicit model. Not a theory of nature: a set of checks and readings.</div></footer>
<div id="tip" role="tooltip"></div>
<script>%%JS%%</script>
</body></html>
'''
out = TEMPLATE
rep = {'%%CSS%%': CSS, '%%JS%%': JS, '%%TODAY%%': TODAY, '%%TITLE%%': E(C.TITLE), '%%H1%%': C.H1, '%%SUB%%': C.SUB, '%%NOTICE%%': C.NOTICE, '%%LEAD%%': C.LEAD, '%%CHIPS%%': CHIPS,
       '%%NOK%%': str(OK), '%%NBAD%%': str(BAD), '%%MUTOK%%': str(MUT_OK), '%%MUTNAMED%%': str(MUT_NAMED), '%%MUTUNNAMED%%': MUT_UNNAMED, '%%MUTALL%%': str(MUT_ALL), '%%NFIND%%': str(len(C.FINDINGS)), '%%NINP%%': str(len(C.INPUTS)),
       '%%NP%%': str(len(IDS1)), '%%NB%%': str(len(IDS2)), '%%PAPERS%%': PAPERS,
       '%%FINDINGS%%': FINDINGS, '%%DICT%%': DICT_ROWS, '%%INPUTS%%': INPUT_ROWS, '%%LIM1%%': LIM1, '%%LIM2%%': LIM2, '%%CHECKS%%': CHECKS_TABLE, '%%SRC%%': SRC}
for k, v in rep.items(): out = out.replace(k, v)
assert out.count('<body>') == 1; out = out.replace('<body>', '<body>\n' + SC.SPRITE, 1)      # the five icons, once
assert '%%' not in out, re.findall(r'%%\w+%%', out)
assert not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', out, flags=re.S)), 'an e-mail address is in the page'
path = os.path.join(HERE, '..', 'html', 'furey_report.html'); os.makedirs(os.path.dirname(path), exist_ok=True)   # the shipped page lives in reports/html/
open(path, 'w', encoding='utf-8').write(out)
print('wrote', path, len(out), 'bytes;', f'checks {OK}, sabotage {MUT_OK} of {MUT_ALL}, findings {len(C.FINDINGS)}, inputs {len(C.INPUTS)}')
