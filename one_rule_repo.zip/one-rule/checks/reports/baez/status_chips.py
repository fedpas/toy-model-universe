# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The status chips of a report page: a status is shown by a small drawn icon, never by a word.  One icon per flag, each with its own shape (so that colour is never the
only carrier) and its own colour on top: standard = an open book, checked = a tick in a ring, ours = a lamp, open = a dashed ring with a question mark, input = a plug.  The
five drawings are the 16 x 16 stroke icons of the atlas's own status badges (ICON_PATHS of StatusBadge.jsx); the page holds them once, as a hidden sprite, and each chip refers
to its symbol.  The word of the flag is the accessible name (aria-label) and the hover text (title) of the chip, and it stands in the one legend line of the page.
The same file is in each report folder that builds its page from Python (category, baez, schuller, hestenes, furey); test_reports.mjs compares the copies.
    chip('checked')                     one icon chip: <span class="chip checked" role="img" aria-label="checked" title="checked: computed by a script">...</span>
    chip('checked', 'checked: found in the text')   a chip whose name says more than the flag word
    legend(['checked', 'standard'], MEANING)         the legend line: each chip, its word and its meaning
    verdict('kept', 'kept')             a kind label that is not a status (kept, partly, dead end, recalled): a plain word, no flag class
    SPRITE, CSS                         the hidden sprite (put it right after <body>) and the style rules (appended to the page's style sheet)"""
import html

FLAGS = ('standard', 'checked', 'ours', 'open', 'input')
ICON_PATHS = {
    'standard': ['M8 4.4v8.4', 'M8 4.4C6.6 3.3 4.5 3 2.4 3.4v8.7c2.1-.4 4.2-.1 5.6.9 1.4-1 3.5-1.3 5.6-.9V3.4C11.5 3 9.4 3.3 8 4.4z'],
    'checked': ['M4.9 8.3l2.2 2.3 4.1-4.9'],
    'ours': ['M8 2.1a4 4 0 0 0-2.3 7.3c.5.4.8.9.8 1.5v.3h3v-.3c0-.6.3-1.1.8-1.5A4 4 0 0 0 8 2.1z', 'M6.4 13.1h3.2', 'M7 14.8h2'],
    'open': ['M6.2 6.3a1.9 1.9 0 1 1 2.7 1.7c-.6.3-.9.7-.9 1.4', 'M8 11.5v.1'],
    'input': ['M5.6 2v3.2', 'M10.4 2v3.2', 'M4 5.2h8v2.2a4 4 0 0 1-8 0z', 'M8 11.4V14.2'],
}
RING = {'checked': '<circle cx="8" cy="8" r="6.6"/>', 'open': '<circle cx="8" cy="8" r="6.6" stroke-dasharray="2.2 1.9"/>'}
MEANING = {'standard': "textbook or the source's own statement, used as is", 'checked': 'computed by a script', 'ours': 'our reading', 'open': 'not settled',
           'input': 'a choice or datum the algebra does not supply'}

def _sprite():
    sym = ''.join('<symbol id="i-%s" viewBox="0 0 16 16"><g fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">%s%s</g></symbol>'
                  % (f, RING.get(f, ''), ''.join('<path d="%s"/>' % d for d in ICON_PATHS[f])) for f in FLAGS)
    return '<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>%s</defs></svg>' % sym
SPRITE = _sprite()

def chip(flag, label=None, meaning=None, title=None):
    """An icon chip.  The accessible name is the flag word (or `label`); the hover text is the word with its meaning (or `title`, or `label`); no word is visible."""
    assert flag in FLAGS, flag
    name = label or flag
    tip = title or label or (flag + ': ' + (meaning or MEANING[flag]))
    return ('<span class="chip %s" role="img" aria-label="%s" title="%s"><svg class="ic" aria-hidden="true" focusable="false"><use href="#i-%s"/></svg></span>'
            % (flag, html.escape(name, quote=True), html.escape(tip, quote=True), flag))

def legend(flags, meanings=None):
    """The one legend line of a page: for each flag its chip, its word and its meaning."""
    m = dict(MEANING, **(meanings or {}))
    return ' '.join('%s <b>%s</b>: %s%s' % (chip(f, meaning=m[f]), f, m[f], ';' if i < len(flags) - 1 else '.') for i, f in enumerate(flags))

def verdict(kind, text):
    """A kind label that is not a status: the word is the label and carries no flag class."""
    assert kind not in FLAGS, kind
    return '<span class="vd %s">%s</span>' % (kind, html.escape(text))

CSS = '''
/* status chips: one drawn icon per flag, the colour on top (the shape carries the meaning, never the colour alone) */
:root{--ic-checked:#0a7d5a;--ic-standard:#1f5fbf;--ic-ours:#9a5b00;--ic-open:#c22f2f;--ic-input:#6b46c1}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--ic-checked:#34d399;--ic-standard:#60a5fa;--ic-ours:#fbbf24;--ic-open:#f87171;--ic-input:#c4b5fd}}
:root[data-theme="dark"]{--ic-checked:#34d399;--ic-standard:#60a5fa;--ic-ours:#fbbf24;--ic-open:#f87171;--ic-input:#c4b5fd}
.chip{display:inline-block;padding:2px;border:1px solid currentColor;border-radius:6px;line-height:0;vertical-align:-4px;margin:0 6px 0 0;white-space:nowrap}
.chip .ic{display:block;width:15px;height:15px}
.chip.checked{color:var(--ic-checked)}.chip.standard{color:var(--ic-standard)}.chip.ours{color:var(--ic-ours)}.chip.open{color:var(--ic-open)}.chip.input{color:var(--ic-input)}
.vd{display:inline-block;font-size:12px;line-height:1.5;border:1px solid var(--line2);border-radius:6px;padding:0 7px;margin-right:6px;color:var(--ink2);background:var(--tint)}
'''
