#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Tests of ../html/baez_atlas_report.html against its own sources: every headline number equals the logs and the matrix data; no external request except
links to arxiv.org; no e-mail address anywhere; every check id the page cites exists in the log; the statements about what the papers cite and contain are pinned to the text files.
Run: python3 test_report_baez.py"""
import os, re, sys, html, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..'))
import no_history as NH
import status_check as SK
import matrix_baez as MD
page = open(os.path.join(HERE, '..', 'html', 'baez_atlas_report.html'), encoding='utf-8').read()   # the page is built into reports/html/
strip = lambda t: re.sub(r'<style.*?</style>|<script.*?</script>', '', t, flags=re.S)
plain = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', strip(page))))
ok = bad = 0
def chk(name, cond, msg=''):
    global ok, bad
    if cond: ok += 1
    else: bad += 1
    print(('ok   ' if cond else 'FAIL ') + name + (': ' + msg if (msg and not cond) else ''))
ids, o, b = [], 0, 0
for l in open(os.path.join(HERE, 'logs', 'baez_check.log'), encoding='utf-8'):
    m = re.match(r'(ok  |FAIL) (\S+?):', l)
    if m:
        ids.append(m.group(2)); o += m.group(1).startswith('ok'); b += m.group(1).startswith('FAIL')
chk('T1 headline checks = log', f'{o} pass, {b} fail' in plain, f'{o} {b}')
chk('T2 no check fails in the log', b == 0 and o == 56)
st = MD.stats()
chk('T3 rows and cells = matrix data', f'{st["n"]} × 22' in plain and f'{st["total_cells"]} filled cells' in plain)
be = st['best']
chk('T4 best-grade counts = matrix data', f'{be["E"]} of the {st["n"]} things' in plain and f'{be["S"]} a structural one' in plain and f'{be["A"]} an analogy' in plain and f'{be["gap"]} none' in plain)
chk('T5 gap rows named', all(r[0] in plain for r in MD.ROWS if not r[3]))
chk('T6 every matrix cell is in the page (table view)', all(html.escape(note) in page for r in MD.ROWS for g, note in r[3].values()))
def external(t):
    return (re.search(r'(src|href)="https?://(?!arxiv\.org)', t) or 'url(http' in t or '@import' in t or re.search(r'<script[^>]+src=', t) or re.search(r'<link[^>]+href', t))
chk('T7 no external request (links to arxiv.org only)', not external(page))
EMAIL = r'[\w.+-]+@[\w-]+\.[\w.]+'
chk('T8 no e-mail address and no mail link in the report', not re.search(EMAIL, re.sub(r'<!--.*?-->', '', page, flags=re.S)) and ('mail' + 'to:') not in page)
cited = set()
for m in re.finditer(r'checks? ([A-Z]\d[\w–,\- ]*)', plain):
    for tok in re.findall(r'[A-Z]\d[a-z]?', m.group(1)): cited.add(tok)
exist = lambda tok: tok in ids or any(i.startswith(tok) for i in ids)
chk('T9 every check id the page cites exists in the log (full ids such as H2d, T1b, S2)', len(cited) >= 25 and all(exist(c) for c in cited), str(sorted(c for c in cited if not exist(c))) + ' n=' + str(len(cited)))
chk('T10 themes and guards present', 'prefers-color-scheme: dark' in page and ':root[data-theme="dark"]' in page and ':root:not([data-theme="light"])' in page)
chk('T11 title is a name of 2-4 words', re.search(r'<title>([^<]+)</title>', page).group(1).count(' ') in (1, 2, 3))
mut = open(os.path.join(HERE, 'logs', 'mutate_baez.log'), encoding='utf-8').read() if os.path.exists(os.path.join(HERE, 'logs', 'mutate_baez.log')) else ''
mm = re.search(r'mutants caught: (\d+) of (\d+)', mut)
chk('T12 sabotage counts: automated run log = page, all caught', bool(mm) and mm.group(1) == mm.group(2) and f'{mm.group(1)} of {mm.group(2)}' in plain)
chk('T13 every check has a sabotage that names it', len(re.findall(r'^caught', mut, re.M)) == int(mm.group(2)) if mm else False)
FD = json.load(open(os.path.join(HERE, 'logs', 'baez_figdata.json')))
chk('T14 figure data agree with the log (56 ok, 0 bad)', FD['counts'] == {'ok': o, 'bad': b})
chk('T15 Fig. 1 has seven nodes and the eight edges a-h, each with a tip and a list entry', len(re.findall(r'class="nd( ex| iso)?"', page)) == 7 and all(f'<span class="el">{c}</span>' in page or f'id="ed-{c}"' in page or f'>{c}</text>' in page for c in 'abcdefgh'))
chk('T31 the Cl(0,3) comparison and the graph names on the page are those of the log (15 of 42; srg(27,10,1,5) with its complement srg(27,16,10,8)); nowhere, matrix tooltips and table view included, is srg(27,10,1,5) itself called the Schlafli graph', '15 of the 42 products' in open(os.path.join(HERE, 'logs', 'baez_check.log'), encoding='utf-8').read() and '15 of the 42 products' in plain and 'srg(27, 16, 10, 8)' in plain and 'srg(27, 10, 1, 5)' in plain and not re.search(r'Schl[aä]fli graph,? srg\(27, ?10, ?1, ?5\)', html.unescape(page)) and all('Schlafli graph srg(27,16,10,8)' in n for r in MD.ROWS for k, (g, n) in r[3].items() if 'srg(27,10,1,5)' in n))
chk('T32 no internal note and no name of another person\'s lectures on the page', not re.search(r'genesis|web app|Schuller', plain))
chk('T33 row ids are dotted (G.1 ... C.5) and distinct from the findings J1-J10 and the check ids', all(re.match(r'[GJEDKTC]\.\d+$', r[0]) for r in MD.ROWS) and len(set(r[0] for r in MD.ROWS)) == len(MD.ROWS))
# T16-T24, T34, T35 pin statements to the seven papers' texts (txt/, made with pdftotext; not shipped with the package, as for check R1 of baez_check.py).
# With the texts beside this script they run and count; without them they are reported as skipped and not counted (never as passed).
TXTS = ('The_Standard_Model_Gauge_Group_from_the_Exceptional_Jordan_Algebra.txt', 'Jordan_Pair_Quantum_Theory_and_the_Standard_Model.txt', 'Three_Generations_in_E7.txt', 'Three-Dimensional_Geometry_in_Exceptional_Algebra.txt', 'Second_Quantization_for_the_Kepler_Problem.txt', 'Triangulations_of_the_Sphere.txt', 'Double_Categories_of_Open_Systems_-_the_Cospan_Approach.txt')
HAVE_TXT = all(os.path.exists(os.path.join(HERE, 'txt', n)) for n in TXTS); skipped = []
if HAVE_TXT:
    T = lambda n: open(os.path.join(HERE, 'txt', n), encoding='utf-8').read()
    gauge = T('The_Standard_Model_Gauge_Group_from_the_Exceptional_Jordan_Algebra.txt'); jordan = T('Jordan_Pair_Quantum_Theory_and_the_Standard_Model.txt'); e7 = T('Three_Generations_in_E7.txt')
    geo = T('Three-Dimensional_Geometry_in_Exceptional_Algebra.txt'); kep = T('Second_Quantization_for_the_Kepler_Problem.txt'); tri = T('Triangulations_of_the_Sphere.txt'); cos = T('Double_Categories_of_Open_Systems_-_the_Cospan_Approach.txt')
    chk('T16 citations: jordan cites gauge, geo cites gauge, e7 cites jordan (arXiv numbers in the texts)', '2606.15235' in jordan and '2606.15235' in geo and '2607.10833' in e7)
    chk('T17 no other paper cites another of the seven', all(n not in t for t, ns in ((kep, ('2606.15235', '2607.10833', '2608.06271', '2609.07538', '2606.10072', '2509.22584')), (tri, ('2606.15235', '2607.10833', '2608.06271', '2609.07538', '2507.11428', '2509.22584')), (cos, ('2606.15235', '2607.10833', '2608.06271', '2609.07538', '2507.11428', '2606.10072')), (gauge, ('2607.10833', '2608.06271', '2609.07538', '2507.11428', '2606.10072', '2509.22584'))) for n in ns))
    chk('T18 versions and dates in the sources are those of the texts', all(s in t for s, t in (('2606.15235v1', gauge), ('2607.10833v1', jordan), ('2608.06271v3', e7), ('2609.07538v1', geo), ('2507.11428v5', kep), ('2606.10072v2', tri), ('2509.22584v3', cos))) and all(s in page for s in ('2606.15235', '2607.10833', '2608.06271', '2609.07538', '2507.11428', '2606.10072', '2509.22584')))
    chk('T19 pinned statements: gauge paper (S(U(2), Lemma 4), E7 paper (Lemma 2, trichotomy, Lemma 4), triangulation note (does not know)', 'S(U(2)' in gauge and 'Lemma 4' in gauge and 'Lemma 2' in e7 and 'trichotomy' in e7 and 'Lemma 4' in e7 and 'do not know' in tri)
    chk('T20 pinned: Jordan-pair paper equations (69), (75), (76) are cited on the page and exist in the text', all(f'({n}' in jordan for n in (69, 75, '76a', '76b', '76c')) and 'eqs. (69), (75), (76)' in plain)
    chk('T21 pinned: Kepler paper has the Madelung rules, eqs. (6), (9), (13), the conformal group of Section 5.1 and SU(2) x SU(2)', 'Madelung' in kep and all(x in kep for x in ('(6)', '(9)', '(13)', 'Digression on the conformal group', 'SU(2) × SU(2)')))
    chk('T22 pinned: triangulation note has the Eisenstein lattice, Thurston and the hermitian form of signature (1,9)', 'Eisenstein' in tri and 'Thurston' in tri and re.search(r'signa-?\s*ture \(1, 9\)', tri) is not None and 'Is this just a coincidence? I do not know' in re.sub(r'\s+', ' ', tri))
    chk('T23 pinned: geometry paper has the octonions, bioctonions and h3', 'bioctonion' in geo.lower() and 'Zorn' in geo or 'split octonion' in geo.lower())
    chk('T24 pinned: cospan paper is about double categories, cospans and Petri nets', 'cospan' in cos.lower() and 'Petri' in cos and 'double categor' in cos.lower())
    chk('T34 Kepler eq. (12): the printed third line has M where L is needed (text extraction, confirmed on the PDF page)', re.search(r'\{Mj , Mk \} = ϵjkℓ Mℓ', kep) is not None and 'eq. (12)' in plain)
    chk('T35 the E7 paper states Lemma 2 by the weight lattice of A2 (squared lengths 3/2.. 2/3, 2, 8/3) and its Table 1 reads Higgs 5 and 5bar', 'weight lattice' in e7 and 'Higgs 5' in e7 and 'Table 2. The en series from n = 7 down to n = 3' in e7)
else:
    skipped = ['T16', 'T17', 'T18', 'T19', 'T20', 'T21', 'T22', 'T23', 'T24', 'T34', 'T35']
    print('skip ' + ', '.join(skipped) + ": these pin the report to the seven papers' texts, which are not shipped (put them in txt/ to run them)")
# the forbidden wording (quoted below as test strings only) is nowhere on the page, the right wording is on the page,
# and the matrix rows K.6 and C.2 carry their notes (the whole page, tooltips included)
outside = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', strip(page))) + ' ' + ' '.join(html.unescape(t) for t in re.findall(r'data-tip="([^"]*)"', page)))
FORBIDDEN = ['particle to antiparticle', 'particle <-> antiparticle', 'the antiparticle side', 'the labels explain', 'computed by us', 'build a generation', 'builds a generation', 'tower builds', 'generation builder',
           'no chiral generation inside', 'does not sit in h3(O)', 'Hodge complement', 'Hodge-complement', 'coefficient of label 0', 'complement as antiparticle', 'the reading of the energy trio', 'The same trio is the extra generator s = 0, -1, +1 of step 11']
chk('T36 the forbidden wording is nowhere on the page (text, tooltips, matrix notes)', not any(w in outside for w in FORBIDDEN), str([w for w in FORBIDDEN if w in outside]))
RIGHT = ['calling that flip charge conjugation is ours', 'the standard anomaly cancellation, recomputed over the labels', 'the nested triples contain (3,2), then (3̄,1) + (1,1), then one generation, then 11 more states',
         'self-conjugate, a real representation', 'a real representation is vector-like (standard)', 'a metric Hodge star only without null generators', 'coefficient of the empty label, the unit',
         'For p + q ≥ 1 the label algebra is not commutative, not even in the super sense', 'a commutative Frobenius monoid in super vector spaces, and not a special one', 'reading this as the reason why those pieces occur is ours', 'the first 10 is real, the second complex',
         'the only real division algebra', 'one family on the doubling bit', 'all of Hull’s signatures', 'its real lattice is II₂,₁₈', 'and the link to ℝ', 'remains numerology',
         'exactly, at every phase-space point', 'one Inönü–Wigner family in c = −2μE', 'the bivector algebra of Cl(−1,−1,−1,s) of step 11 exactly for s = −ε = sign E', 'Every hodograph goes to a geodesic', 'Fock (1935) and Moser (1970): pointers, sources unread', 'bridge checks (selfcheck/bridges/) bd·kep·1–6']
chk('T37 the right wording is on the page', all(t in plain or t in outside for t in RIGHT), str([t for t in RIGHT if t not in plain and t not in outside]))
rowsd = {r[0]: r for r in MD.ROWS}
chk('T38a rows K.1 and K.2 carry the exact Kepler identities and the step-11 identification through Fock’s projection as exact cells', rowsd['K.1'][3]['rule'][0] == 'E' and 'bd·kep·1' in rowsd['K.1'][3]['rule'][1] and rowsd['K.2'][3]['rule'][0] == 'E' and 'bd·kep·2' in rowsd['K.2'][3]['rule'][1]
    and rowsd['K.2'][3]['projective'][0] == 'E' and 'exactly for s = -eps = sign E' in rowsd['K.2'][3]['projective'][1] and 'bd·kep·3–6' in rowsd['K.2'][3]['projective'][1])
chk('T38 rows K.6 and C.2 keep their grades and carry the notes (no product used; for p + q >= 1 not commutative against commutative Frobenius; the null part a commutative, non-special Frobenius monoid in super vector spaces)', rowsd['K.6'][3]['rule'][0] == 'E' and 'no product of the bit rule is used' in rowsd['K.6'][3]['rule'][1]
    and rowsd['C.2'][3]['rule'][0] == 'S' and 'For p + q >= 1 the label algebra is not commutative, not even in the super sense' in rowsd['C.2'][3]['rule'][1] and 'commutative, non-special Frobenius monoid in super vector spaces (bd·cat·22)' in rowsd['C.2'][3]['rule'][1])
# the bridge checks of selfcheck/bridges/ the page cites (bd·<family>·n): each is a check of a script of its family once the folder is in the package
_bd = sorted({f'bd·{m[0]}·{k}' for m in re.findall(r'bd·([a-z]+)·(\d+)(?:–(\d+))?', plain) for k in range(int(m[1]), int(m[2] or m[1]) + 1)})
chk('T38b the page cites the bridge checks of the octonion input, the octonion family, Hull’s lists, the lattice II(2,18), the null Frobenius monoid and the Kepler problem through Fock’s projection', all(x in _bd for x in ('bd·alg·21', 'bd·alg·22', 'bd·alg·16', 'bd·alg·24', 'bd·str·7', 'bd·str·19', 'bd·cat·22', 'bd·kep·1', 'bd·kep·2', 'bd·kep·3', 'bd·kep·4', 'bd·kep·5', 'bd·kep·6')), str(_bd))
_bdir = os.path.join(HERE, '..', '..', 'selfcheck', 'bridges')
if os.path.isdir(_bdir):
    _src = {f: open(os.path.join(_bdir, f), encoding='utf-8').read() for f in os.listdir(_bdir) if f.endswith('.py')}
    _miss = [x for x in _bd if not any(f.startswith(x.split('·')[1] + '_') and re.search(re.escape(x) + r'(?!\d)', t) for f, t in _src.items())]
    chk('T38c every bridge check the page cites is a check of selfcheck/bridges/<family>_*.py', not _miss, str(_miss))
else:
    print('note: selfcheck/bridges/ is not in this package yet; the page cites ' + ', '.join(_bd))
chk('T39 no corrections section, no struck sentence, no erratum id', 'id="corr"' not in page and 'href="#corr"' not in page and '<s>' not in page and not re.search(r'\bE-\d{3}\b', plain))
chk('T40 no history in the visible text of the page (shared pattern list, reports/no_history.py); every "<" in a text node is written &lt;, so the reader sees all the text', not NH.scan_page(page) and not NH.bare_lt(page), NH.scan_page(page)[:3])
chk('T41 the history scan catches its planted phrases', not NH.selftest(), NH.selftest())
for fid in ['J%d' % i for i in range(1, 11)]:
    chk(f'T25 {fid} present with tags', f'id="{fid.lower()}"' in page and re.search(rf'id="{fid.lower()}".*?class="chips">(.*?)</div>', page, re.S) is not None
        and SK.kinds(re.search(rf'id="{fid.lower()}".*?class="chips">(.*?)</div>', page, re.S).group(1)) != [])
S = {k: int(v) for k, v in FD['stab'].items()}
chk('T26 stabiliser numbers on the page are those of the data (52, 28, 16, 36, 18, 12, 11)', all(str(S[k]) in plain for k in ('f4', 'frame', 'B', 'A', 'X', 'SM', 'derived')) and S['f4'] == 52 and S['SM'] == 12)
chk('T27 tooltips on the figures', page.count('data-tip="') > 150, str(page.count('data-tip="')))
chk('T28 size is reasonable (< 600 kB) and the script is inline', len(page.encode('utf-8')) < 600_000 and '<script>' in page)
chk('T29 limits and open questions are stated, and the perspectives are offered to a reader of the papers, not addressed to a person', 'Dead ends and honest limits' in page and 'overview level' in plain
    and '<h2>Perspectives <small>all ours or open; offered, not claimed</small></h2>' in page and '<h3>3 · Perspectives</h3>' in page and 'A short list of statements the label view may offer a reader of these papers' in plain
    and not re.search(r'Perspectives for|offer him|\bthe author\b', plain))
chk('T30 no claim of a result about nature', 'Nothing here is a result about nature' in plain)
F4 = ('checked', 'standard', 'ours', 'open')
chk('T42 every status is an icon chip (role img, name and hover text start with the word, the drawing of the atlas badge, no word chip, one legend entry per flag); the four flags are used; the relation chips say what they stand for',
    not SK.problems(page, F4) and set(SK.kinds(page)) == set(F4) and all(any(c[0] == f and c[1] == n for c in SK.chips(page)) for f, n in (('checked', 'checked: cites'), ('checked', 'checked: computed'), ('ours', 'ours: our reading'), ('open', 'open'))), str(SK.problems(page, F4)[:3]))
print(f'\ntest_report_baez: {ok} ok, {bad} failed' + (f', {len(skipped)} skipped (no txt/)' if skipped else '')); sys.exit(1 if bad else 0)
