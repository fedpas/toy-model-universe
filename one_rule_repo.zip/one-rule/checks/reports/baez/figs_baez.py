# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""SVG figures of the Baez report.  Every number drawn is read from logs/baez_figdata.json (written by baez_check.py) or recomputed here from the bit rule (bitcliff); none is typed by hand."""
import math, html, itertools
from fractions import Fraction as Fr
E = html.escape


def tip(*lines):
    return E('\n'.join(lines), quote=True)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# the seven papers and how they are related (Fig. 1)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
PAPERS = {  # key: (short title, authors, arXiv, order on the circle, exceptional cluster?)
    'geo': ('3D geometry in exceptional mathematics', 'Baez, Pumplün', '2609.07538', 0, True),
    'gauge': ('SM gauge group from h3(O)', 'Baez, Schwahn', '2606.15235', 1, True),
    'jordan': ('Jordan pair quantum theory and the SM', 'Baez, Bokor, Boyle', '2607.10833', 2, True),
    'kepler': ('Second quantization for the Kepler problem', 'Baez', '2507.11428', 3, False),
    'e7': ('Three generations in E7', 'Baez', '2608.06271', 4, True),
    'tri': ('Triangulations of the sphere', 'Baez', '2606.10072', 5, False),
    'cospan': ('Double categories of open systems: cospans', 'Baez', '2509.22584', 6, False),
}
# kind: cite (the arXiv number of the cited paper is found in the citing paper's text: R1), chk (a computed link), our (our reading, partly computed), opn (open)
REL = [
    ('a', 'geo', 'gauge', 'cite', 'Cited: the geometry paper\'s text contains the arXiv number of the gauge-group paper (R1). Shared object: the octonions and h3(O); O = C + C^3 and the derivations that kill a unit (O1c, O3a).'),
    ('b', 'gauge', 'jordan', 'cite', 'Cited: the Jordan-pair paper cites the gauge-group paper (R1). Shared object: the Standard Model group. In the Albert algebra it is the stabiliser S(U(2) x U(3)) in F4; in the triples it is K0 of M_{3,2}(C). Computed: the two su(3) + su(2) subalgebras act differently on the 27 (S2).'),
    ('c', 'jordan', 'e7', 'cite', 'Cited: the E7 paper cites the Jordan-pair paper (R1). Shared object: the chain of triples 27 > 16 > 10 > 6 as grade-1 pieces of e7, e6, so(10), sl5 (E1b-E2d); under the E7 su(3) + su(2) they build one generation step by step (S1).'),
    ('d', 'geo', 'e7', 'our', 'Not cited. The 27 is both h3(O_C) (geometry paper) and the grade-1 piece of e7 (E7 paper): computed on the E7 side (E1b, E2d). Whether the three complex 3-spaces of the geometry paper and the three generations of the E7 paper are related is open.'),
    ('e', 'jordan', 'kepler', 'chk', 'The complexification of so(4,2) is the 3-graded algebra so(6, C) = 4 + 7 + 4 of the type BDI triple C^4 of the Jordan-pair paper (Tables 1 and 2, n = 4); SU(2) x SU(2) of the Kepler paper sits in its K0 (K4). That one paper uses so(4,2) for hydrogen and the other so(6, C) for matter is our remark.'),
    ('f', 'e7', 'kepler', 'our', 'Fermionic Fock space on the bound states (Kepler) against 32 = Lambda C^5 with particles and antiparticles (E7): both are the label set of five (or n) bits with Cl(n,n) acting (H3a-b, E3e). Our reading; no computation says the two spaces coincide as physical spaces.'),
    ('g', 'e7', 'tri', 'chk', 'The 126 roots of e7 projected to the plane of the generation sl3 land on the Eisenstein lattice of the triangulation paper, in shells N = 0, 1, 3 and never N = 2 (T1a, T1b).'),
    ('h', 'gauge', 'tri', 'opn', 'The Jordan algebra h2(O) of the gauge paper is the Lorentz cone of signature (1,9) (O3i); the hermitian form of the triangulation paper also has signature (1,9) (T3). Baez asks whether that is a coincidence; the first 10 is real, the second complex, and we find no mechanism (T4).'),
]


LAYOUT = {  # centre of each node in the viewBox; planar: the 4-cycle geo-gauge-jordan-e7 with tri inside and kepler outside
    'geo': (125, 195), 'gauge': (440, 55), 'jordan': (755, 195), 'e7': (440, 345), 'tri': (440, 200), 'kepler': (745, 390), 'cospan': (125, 390)}
LINES = {
    'geo': ('3D geometry in', 'exceptional mathematics'), 'gauge': ('SM gauge group', 'from h3(O)'), 'jordan': ('Jordan pair quantum', 'theory and the SM'),
    'e7': ('Three generations', 'in E7'), 'kepler': ('Second quantization', 'for the Kepler problem'), 'tri': ('Triangulations', 'of the sphere'), 'cospan': ('Double categories of', 'open systems: cospans')}


def relation_svg(edges_found):
    W, H = 880, 450
    pos = LAYOUT
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The seven papers as nodes; edges are citations, computed links, our readings and open questions" class="chart">',
             '<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="var(--ink)"/></marker></defs>']
    bw, bh = 210, 64
    def border(a, b):                                    # point on the border of node a's box towards node b
        x0, y0 = pos[a]; x1, y1 = pos[b]; dx, dy = x1 - x0, y1 - y0
        t = min((bw / 2 + 3) / abs(dx) if dx else 1e9, (bh / 2 + 3) / abs(dy) if dy else 1e9)
        return x0 + dx * t, y0 + dy * t
    mids = {}
    for lab, a, b, kind, txt in REL:
        if kind == 'cite':                               # arrow from the citing to the cited paper, direction read from the logs
            src, dst = (a, b)
            if (a, b) not in edges_found and (b, a) in edges_found: src, dst = b, a
        else:
            src, dst = a, b
        x0, y0 = border(src, dst); x1, y1 = border(dst, src)
        mids[lab] = ((x0 + x1) / 2, (y0 + y1) / 2)
        mark = ' marker-end="url(#ah)"' if kind == 'cite' else ''
        parts.append(f'<line x1="{x0:.1f}" y1="{y0:.1f}" x2="{x1:.1f}" y2="{y1:.1f}" class="ed {kind}"{mark} data-tip="{tip(lab + ": " + PAPERS[a][0] + " / " + PAPERS[b][0], txt)}" tabindex="0"/>')
    for k, (title, au, ax, idx, ex) in PAPERS.items():
        x, y = pos[k]
        cls = 'nd ex' if ex else ('nd iso' if k == 'cospan' else 'nd')
        l1, l2 = LINES[k]
        parts.append(f'<g class="{cls}" data-tip="{tip(title, au + ", arXiv:" + ax, "in the exceptional-algebra cluster" if ex else ("connects to the atlas only (C1), not to the other papers" if k == "cospan" else "outside the exceptional cluster; linked to it by the edges shown"))}" tabindex="0">'
                     f'<rect x="{x - bw / 2:.1f}" y="{y - bh / 2:.1f}" width="{bw}" height="{bh}" rx="9"/><text x="{x:.1f}" y="{y - 12:.1f}" text-anchor="middle" class="tt">{E(l1)}</text>'
                     f'<text x="{x:.1f}" y="{y + 4:.1f}" text-anchor="middle" class="tt">{E(l2)}</text>'
                     f'<text x="{x:.1f}" y="{y + 23:.1f}" text-anchor="middle" class="ss">{E(au)} · {ax}</text></g>')
    for lab, a, b, kind, txt in REL:                     # edge letters on top of everything
        mx, my = mids[lab]
        parts.append(f'<g data-tip="{tip(lab + ": " + PAPERS[a][0] + " / " + PAPERS[b][0], txt)}" tabindex="0"><circle cx="{mx:.1f}" cy="{my:.1f}" r="12" class="bd"/><text x="{mx:.1f}" y="{my + 4.5:.1f}" text-anchor="middle" class="bdt">{lab}</text></g>')
    parts.append(f'<text x="{pos["cospan"][0]}" y="{pos["cospan"][1] + 52}" text-anchor="middle" class="mut">no link to the other six: atlas only (C1)</text>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="30" y2="5" class="ed cite" marker-end="url(#ah)"/></svg> cites (found by arXiv number, R1)</span>'
           '<span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="36" y2="5" class="ed chk"/></svg> link we computed</span>'
           '<span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="36" y2="5" class="ed our"/></svg> our reading</span>'
           '<span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="36" y2="5" class="ed opn"/></svg> open question</span>'
           '<span><svg width="26" height="16" aria-hidden="true"><rect x="2" y="2" width="22" height="12" rx="3" class="legex"/></svg> exceptional-algebra cluster</span></div>')
    return ''.join(parts) + leg


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# one generation as five bits (Fig. J1): weak bits a in 0..2, colour bits b in 0..3
# ------------------------------------------------------------------------------------------------------------------------------------------------------
NAMEMAP = {'e-bar_R': ('ē', 'R'), 'nu-bar_R': ('ν̄', 'R'), 'q_L': ('q', 'L'), 'd-bar_R': ('d̄', 'R'), 'u-bar_R': ('ū', 'R'), 'l_L': ('l', 'L')}
PHYS = {'e-bar_R': 'positron (anti-electron), right-handed', 'nu-bar_R': 'right-handed antineutrino', 'q_L': 'left-handed quark doublet (u, d), three colours', 'd-bar_R': 'anti-down, three colours',
        'u-bar_R': 'anti-up, three colours', 'l_L': 'left-handed lepton doublet (neutrino, electron)'}


def sub_name(nm):
    base, sub = NAMEMAP[nm]
    return f'{base}<tspan baseline-shift="sub" font-size="75%">{sub}</tspan>'


def gentable_svg(FD):
    cw, ch, ox, oy = 150, 78, 70, 44
    W, H = ox + 4 * cw + 10, oy + 3 * ch + 134
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The 32 five-bit labels by number of weak bits and colour bits; the 16 even labels are one generation" class="chart fx">']
    parts.append(f'<text x="{ox + 2 * cw}" y="16" text-anchor="middle" class="t2">b = colour bits set (of 3)</text>')
    parts.append(f'<text x="14" y="{oy + 1.5 * ch}" text-anchor="middle" class="t2" transform="rotate(-90 14 {oy + 1.5 * ch})">a = weak bits set (of 2)</text>')
    for b in range(4): parts.append(f'<text x="{ox + b * cw + cw / 2}" y="{oy - 8}" text-anchor="middle" class="t">{b}</text>')
    for a in range(3): parts.append(f'<text x="{ox - 10}" y="{oy + a * ch + ch / 2 + 5}" text-anchor="end" class="t">{a}</text>')
    by_ab = {(c['a'], c['b']): c for c in FD['classes']}
    slot = {'e-bar_R': 'k1', 'nu-bar_R': 'k2', 'q_L': 'k3', 'd-bar_R': 'k4', 'u-bar_R': 'k5', 'l_L': 'k6'}
    for a in range(3):
        for b in range(4):
            n = math.comb(2, a) * math.comb(3, b); x = ox + b * cw; y = oy + a * ch
            if (a, b) in by_ab:
                c = by_ab[(a, b)]; k = slot[c['name']]
                t = tip(f'{c["name"]}: {PHYS[c["name"]]}', f'(a, b) = ({a}, {b}), {c["n"]} labels', f'Peirce eigenvalues (lambda_1, lambda_2) = ({c["l1"]}, {c["l2"]})', f'hypercharge Y = {c["Y"]}, charge Q = ' + ', '.join(c['Q']))
                parts.append(f'<g data-tip="{t}" tabindex="0"><rect x="{x + 2}" y="{y + 2}" width="{cw - 4}" height="{ch - 4}" rx="8" class="{k}"/>'
                             f'<text x="{x + cw / 2}" y="{y + 27}" text-anchor="middle" class="big i{k[1]}">{sub_name(c["name"])} × {c["n"]}</text>'
                             f'<text x="{x + cw / 2}" y="{y + 46}" text-anchor="middle" class="ink2 i{k[1]}">Y = {c["Y"]}</text>'
                             f'<text x="{x + cw / 2}" y="{y + 63}" text-anchor="middle" class="ink2 i{k[1]}">(λ₁, λ₂) = ({c["l1"]}, {c["l2"]})</text></g>')
            else:
                ca, cb = 2 - a, 3 - b
                nm = by_ab[(ca, cb)]['name']
                parts.append(f'<g data-tip="{tip("odd labels: " + str(n) + " states, the complements of the even ones", "complement of the class (" + str(ca) + ", " + str(cb) + ") = " + nm + ": XOR with 11111 flips Q and Y")}" tabindex="0"><rect x="{x + 2}" y="{y + 2}" width="{cw - 4}" height="{ch - 4}" rx="8" fill="none" stroke="var(--line2)" stroke-dasharray="4 3"/>'
                             f'<text x="{x + cw / 2}" y="{y + 38}" text-anchor="middle" class="mut">odd · {n} labels</text></g>')
    gy = oy + 3 * ch + 26
    parts.append(f'<text x="{ox}" y="{gy}" class="ink">Number of set bits k:  all 32 labels graded</text>')
    mx = max(FD['grading'])
    for k, v in enumerate(FD['grading']):
        bx = ox + k * 92; h = 48 * v / mx
        parts.append(f'<g data-tip="{tip(str(v) + " labels with " + str(k) + " set bits", "dimension of the exterior power Lambda^" + str(k) + " C^5")}" tabindex="0"><rect x="{bx}" y="{gy + 28 + 48 - h:.1f}" width="60" height="{h:.1f}" rx="3" fill="var(--s)"/>'
                     f'<text x="{bx + 30}" y="{gy + 28 + 62 + 6}" text-anchor="middle" class="t">k={k}</text><text x="{bx + 30}" y="{gy + 28 + 48 - h - 4:.1f}" text-anchor="middle" class="ink">{v}</text></g>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# the tower 6 < 10 < 16 < 27 under the Standard Model subalgebra of the E7 chain (Fig. J3)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
IRR = [('3|2', 'k1', '(3,2)', 6, 'quark doublet q'), ('3b|1', 'k2', '(3̄,1)', 3, 'anti-colour singlets ū, d̄'), ('1|2', 'k3', '(1,2)', 2, 'lepton doublet l'),
       ('1|1', 'k4', '(1,1)', 1, 'singlets ē, ν̄'), ('3|1', 'k5', '(3,1)', 3, 'extra colour triplet, not in one generation')]


def tower_svg(FD):
    names = [('4', 'M₃,₂(ℂ)', '(r,a,b) = (2,2,1)'), ('5', 'a₅(ℂ)', '(2,4,2)'), ('6', 'bi-Cayley', '(2,6,4)'), ('7', 'Albert', '(3,8,0)')]
    unit = 11.5; ox, oy = 40, 24; colw = 92; gap = 24
    H = oy + 27 * unit + 62; W = ox + 4 * colw + 3 * gap + 190
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Grade-1 triples of the E7 chain split into SU(3) x SU(2) pieces" class="chart fx">']
    base = oy + 27 * unit
    for i, (n, nm, rab) in enumerate(names):
        x = ox + i * (colw + gap); d = FD['dec'][n]; y = base
        total = 0
        for key, k, lab, dim, desc in IRR:
            m = d.get(key, 0)
            for rep in range(m):
                h = dim * unit; y -= h; total += dim
                parts.append(f'<g data-tip="{tip(nm + ": piece " + lab + " (" + str(dim) + " states)", desc)}" tabindex="0"><rect x="{x}" y="{y + 1.5:.1f}" width="{colw}" height="{h - 3:.1f}" rx="4" class="{k}"/>'
                             + (f'<text x="{x + colw / 2}" y="{y + h / 2 + 4.5:.1f}" text-anchor="middle" class="ink i{k[1]}">{lab}</text>' if h >= 20 else '') + '</g>')
        parts.append(f'<text x="{x + colw / 2}" y="{base + 18}" text-anchor="middle" class="big">{total}</text><text x="{x + colw / 2}" y="{base + 35}" text-anchor="middle" class="ink">{nm}</text><text x="{x + colw / 2}" y="{base + 51}" text-anchor="middle" class="mut">{rab}</text>')
    xr = ox + 4 * colw + 3 * gap + 14
    parts.append(f'<text x="{xr}" y="{oy + 6}" class="ink">pieces, bottom to top</text>')
    yy = oy + 26
    for key, k, lab, dim, desc in IRR:
        parts.append(f'<rect x="{xr}" y="{yy - 12}" width="18" height="18" rx="4" class="{k}"/><text x="{xr + 26}" y="{yy + 2}" class="ink">{lab} · {dim}</text><text x="{xr + 26}" y="{yy + 18}" class="mut">{E(desc.split(", ")[0])}</text>')
        yy += 40
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# the plane of the generation sl3: shadows of the 126 roots of e7 on the Eisenstein lattice (Fig. J4)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def plane_svg(FD):
    W, H = 560, 520; cx, cy = 280, 222; s = 135
    pts = FD['plane']
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The 126 roots of e7 projected onto the plane of the generation sl3, on the Eisenstein lattice" class="chart fx">']
    u1 = (0.0, 0.8165); u2 = (0.7071, 0.4082)
    for a in range(-4, 5):
        for b in range(-4, 5):
            x = a * u1[0] + b * u2[0]; y = a * u1[1] + b * u2[1]
            if math.hypot(x, y) <= 1.5:
                parts.append(f'<circle cx="{cx + s * x:.1f}" cy="{cy - s * y:.1f}" r="2.4" fill="var(--line2)"/>')
    r2 = math.sqrt(4 / 3) * 0.8165 / math.sqrt(2 / 3) * math.sqrt(2 / 3)       # radius of the empty shell N = 2: sqrt(2/3 x 2) = 1.1547
    r2 = math.sqrt(2 / 3 * 2)
    parts.append(f'<circle cx="{cx}" cy="{cy}" r="{s * r2:.1f}" fill="none" stroke="var(--line2)" stroke-dasharray="5 4"/>')
    parts.append(f'<text x="{cx + s * r2 * 0.72:.1f}" y="{cy - s * r2 * 0.72 - 6:.1f}" class="mut">N = 2: no lattice point</text>')
    # the three lines through opposite w_k
    for ang in (30, 90, 150):
        a = math.radians(ang)
        parts.append(f'<line x1="{cx - s * 1.0 * math.cos(a):.1f}" y1="{cy + s * 1.0 * math.sin(a):.1f}" x2="{cx + s * 1.0 * math.cos(a):.1f}" y2="{cy - s * 1.0 * math.sin(a):.1f}" stroke="var(--line2)" stroke-width="1"/>')
    kind_slot = {'zero': 'k1', 'w': 'k2', 'A': 'k3'}
    for p in pts:
        x = cx + s * p['x']; y = cy - s * p['y']; n = p['n']; k = kind_slot[p['kind']]
        r = 6 + 2.4 * math.sqrt(n)
        if p['kind'] == 'zero': t = tip(f'{n} roots project to 0: the 30 roots of Phi_0 (type A5, rank 5)', 'Eisenstein norm N = 0')
        elif p['kind'] == 'w': t = tip(f'{n} roots project to this vector (one of the six weights ±w_k)', 'squared length 2/3, Eisenstein norm N = 1', 'the 30 roots of Phi_k split 15 + 15 between +w_k and -w_k')
        else: t = tip('1 root of e7 projects to itself: one of the six roots of the generation sl3 (A2)', 'squared length 2, Eisenstein norm N = 3')
        parts.append(f'<g data-tip="{t}" tabindex="0"><circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" class="{k}" stroke="var(--surf)" stroke-width="1.5"/><text x="{x:.1f}" y="{y + 4.5:.1f}" text-anchor="middle" class="ink i{k[1]}">{n}</text></g>')
    parts.append(f'<g class="ink2"><rect x="14" y="440" width="14" height="14" rx="3" class="k1"/><text x="34" y="452" class="ink">30 roots at 0 (N = 0)</text><rect x="14" y="462" width="14" height="14" rx="3" class="k2"/><text x="34" y="474" class="ink">6 weights ±w_k, 15 roots each (N = 1): 90</text>'
                 f'<rect x="14" y="484" width="14" height="14" rx="3" class="k3"/><text x="34" y="496" class="ink">the 6 roots of the generation sl3 (N = 3)</text></g>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# the Fano plane of the octonions on three-bit labels (Fig. J5)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def fano_svg(FD):
    W, H = 470, 424
    A = (235, 40); B = (60, 340); C = (410, 340)            # vertices: labels 1, 2, 4 (generators) at A, B, C
    P = {1: A, 2: B, 4: C}
    def mid(p, q): return ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2)
    P[3] = mid(A, B); P[5] = mid(A, C); P[6] = mid(B, C)
    gx = (A[0] + B[0] + C[0]) / 3; gy = (A[1] + B[1] + C[1]) / 3
    P[7] = (gx, gy)
    r = math.dist(P[7], P[3])
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The Fano plane: the seven non-zero three-bit labels with the seven lines a, b, a XOR b" class="chart fx">']
    lines = {tuple(sorted(l)): l for l in FD['fano']['lines']}
    drawn = []
    segs = {(1, 2, 3): (A, B), (1, 4, 5): (A, C), (2, 4, 6): (B, C), (3, 4, 7): (C, P[3]), (2, 5, 7): (B, P[5]), (1, 6, 7): (A, P[6])}
    for key in lines:
        if key in segs:
            p, q = segs[key]
            if key in ((3, 4, 7), (2, 5, 7), (1, 6, 7)):                      # medians: extend through the centre
                pass
            parts.append(f'<line x1="{p[0]:.1f}" y1="{p[1]:.1f}" x2="{q[0]:.1f}" y2="{q[1]:.1f}" class="fn-line" data-tip="{tip("line {" + ", ".join(format(v, "03b") for v in key) + "}", "e_a e_b = ±e_(a XOR b): these three units close into a quaternion subalgebra (associative)")}" tabindex="0"/>')
        else:                                                                  # the circle through 3, 5, 6
            parts.append(f'<circle cx="{P[7][0]:.1f}" cy="{P[7][1]:.1f}" r="{r:.1f}" fill="none" class="fn-line" data-tip="{tip("line {" + ", ".join(format(v, "03b") for v in key) + "}", "e_a e_b = ±e_(a XOR b): these three units close into a quaternion subalgebra (associative)")}" tabindex="0"/>')
    for v, (x, y) in P.items():
        parts.append(f'<g class="fn-pt" data-tip="{tip("label " + format(v, "03b") + " = e_" + str(v), "squares to -1; lies on three lines")}" tabindex="0"><circle cx="{x:.1f}" cy="{y:.1f}" r="18"/><text x="{x:.1f}" y="{y + 4.5:.1f}" text-anchor="middle" class="ink" style="fill:var(--s-ink)">{format(v, "03b")}</text></g>')
    parts.append(f'<text x="14" y="{H - 34}" class="ink2">7 lines × 3! = 42 ordered triples of distinct labels associate;</text><text x="14" y="{H - 14}" class="ink2">the other {FD["fano"]["negs"]} of 7·6·5 = 210 anti-associate.</text>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# dimension ladder of the stabilisers in f4, and the 27 under the two Standard Model subalgebras (Fig. J6)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def stab_svg(FD):
    S = {k: int(v) for k, v in FD['stab'].items()}
    rows = [('f4 = derivations of h3(O)', S['f4'], 'k1', 'F4: 52'), ('spin(9): stabiliser of A = h2(O)', S['A'], 'k1', 'Stab(A) = Spin(9)'),
            ('so(8): stabiliser of the Jordan frame', S['frame'], 'k1', 'so(8), triality'), ('so(3) + so(6): stabiliser of X = h2(C)', S['X'], 'k1', 'Stab(X)'),
            ('su(3) + su(3): stabiliser of B = h3(C)', S['B'], 'k1', 'Stab(B)^0'), ('Standard Model: X and B together', S['SM'], 'k2', 'S(U(2) x U(3))'),
            ('derived algebra su(2) + su(3)', S['derived'], 'k3', '8 + 3'), ('su(3)', 8, 'k3', ''), ('su(2)', 3, 'k3', ''), ('centre u(1): hypercharge', 1, 'k4', '')]
    W, rh = 640, 27; H = 14 + rh * len(rows) + 6; x0 = 250; sc = 6.1
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Dimensions of the stabilisers inside f4" class="chart fx">']
    for i, (lab, d, k, note) in enumerate(rows):
        y = 8 + i * rh
        parts.append(f'<text x="{x0 - 8}" y="{y + 16}" text-anchor="end" class="ink2">{E(lab)}</text>')
        parts.append(f'<g data-tip="{tip(lab, "dimension " + str(d))}" tabindex="0"><rect x="{x0}" y="{y + 2}" width="{d * sc:.1f}" height="{rh - 8}" rx="3" class="{k}"/></g>')
        parts.append(f'<text x="{x0 + d * sc + 6:.1f}" y="{y + 16}" class="ink">{d}</text>')
    parts.append('</svg>')
    return ''.join(parts)


def sm27_svg(FD):
    cls = [('0|0', 'k4', 'singlet'), ('0|3/8', 'k3', 'weak doublet'), ('0|1', 'k6', 'weak triplet'), ('4/9|0', 'k2', 'colour triplet'), ('4/9|3/8', 'k1', 'colour triplet + weak doublet')]
    W, rh = 640, 56; x0 = 150; sc = 17
    parts = [f'<svg viewBox="0 0 {W} {2 * rh + 94}" role="img" aria-label="The 27 under the two Standard Model subalgebras by Casimir class" class="chart fx">']
    for r, (lab, key) in enumerate((('Baez–Schwahn, in F4', 'cont'), ('E7 chain, in E6', 'cont7'))):
        y = 10 + r * rh; x = x0
        parts.append(f'<text x="{x0 - 8}" y="{y + 28}" text-anchor="end" class="ink">{lab}</text>')
        for ck, k, nm in cls:
            n = FD[key].get(ck, 0)
            if not n: continue
            w = n * sc
            parts.append(f'<g data-tip="{tip(lab + ": " + nm, str(n) + " of 27 states", "Casimir (su(3), su(2)) = (" + ck.replace("|", ", ") + ")")}" tabindex="0"><rect x="{x + 1:.1f}" y="{y}" width="{w - 2:.1f}" height="40" rx="4" class="{k}"/><text x="{x + w / 2:.1f}" y="{y + 25}" text-anchor="middle" class="ink i{k[1]}">{n}</text></g>')
            x += w
    ly = 2 * rh + 16
    for i, (ck, k, nm) in enumerate(cls):
        lx = 14 + (i % 3) * 205; yy = ly + (i // 3) * 26
        parts.append(f'<rect x="{lx}" y="{yy - 12}" width="16" height="16" rx="3" class="{k}"/><text x="{lx + 22}" y="{yy + 1}" class="ink2">{nm}</text>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# signatures (p, 10-p): clock, type, real Weyl spinors (Fig. J7)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def sig_svg(FD):
    info = FD['triang']['info']; rw = {tuple(x) for x in FD['triang']['real_weyl']}
    cw = 58; W = 12 + 11 * cw + 6; H = 214
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The eleven signatures (p, 10-p) with their clock type" class="chart fx">']
    slot = {'R': 'k1', 'C': 'k3', 'H': 'k2', 'R2': 'k4', 'H2': 'k5'}
    for p in range(11):
        q = 10 - p; typ, tsq = info[f'{p}|{q}']; x = 6 + p * cw; k = slot.get(typ, 'k1'); real = (p, q) in rw
        c = (p - q) % 8
        parts.append(f'<g data-tip="{tip(f"signature ({p}, {q}): clock {c}, type {typ}", "pseudoscalar squares to " + ("+1" if tsq == 1 else "-1"), "real Majorana-Weyl spinors of 16 components" if real else "no real Weyl spinor in this algebra")}" tabindex="0">'
                     f'<text x="{x + cw / 2 - 2}" y="22" text-anchor="middle" class="ink">({p},{q})</text>'
                     f'<rect x="{x}" y="34" width="{cw - 4}" height="62" rx="6" class="{k}"/><text x="{x + cw / 2 - 2}" y="64" text-anchor="middle" class="big i{k[1]}">{typ}</text>'
                     f'<text x="{x + cw / 2 - 2}" y="86" text-anchor="middle" class="ink2 i{k[1]}">c={c}</text>'
                     f'<text x="{x + cw / 2 - 2}" y="118" text-anchor="middle" class="ink">I² = {"+1" if tsq == 1 else "−1"}</text>'
                     + (f'<rect x="{x - 1}" y="28" width="{cw - 2}" height="116" rx="8" fill="none" stroke="var(--ink)" stroke-width="2.4"/><text x="{x + cw / 2 - 2}" y="138" text-anchor="middle" class="ink">★ real</text>' if real else '') + '</g>')
    for j, t in enumerate(('★ real = type R, with the pseudoscalar squaring to +1:', 'the even part splits and 32 = 16 + 16 real spinors (Majorana–Weyl).', '(1,9): the complex form of the triangulation note, and h2(O) = ℝ ⊕ ℝ⁹ (real) by its determinant; no mechanism links them.')):
        parts.append(f'<text x="14" y="{H - 48 + 20 * j}" class="ink2">{t}</text>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# Kepler: the three orbit types and the algebra each one carries (Fig. J8)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def orbits_svg(FD):
    W, H = 720, 268; pw = 220; ph = 178
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Ellipse, parabola and hyperbola with the Lie algebra of each" class="chart fx">']
    spec = [('1', 'bound orbit (ellipse), E < 0', 'ε = +1', 0.6, 50), ('0', 'parabola, E = 0', 'ε = 0', 1.0, 30), ('-1', 'scattering orbit (hyperbola), E > 0', 'ε = −1', 1.6, 40)]
    names = {'1': 'so(4)', '0': 'e(3)', '-1': 'so(3,1)'}
    for i, (key, title, eps, e, scale) in enumerate(spec):
        ox = 12 + i * (pw + 18); cx = ox + pw / 2; cy = 112
        lim = math.pi if e < 1 else (math.pi - 1e-3 if e == 1 else math.acos(-1 / e) - 1e-3)
        pts = []
        for t in range(601):
            th = -lim + 2 * lim * t / 600
            den = 1 + e * math.cos(th)
            if den <= 1e-6: continue
            r = 1 / den; x = r * math.cos(th); y = r * math.sin(th)
            if abs(y) * scale <= 66 and abs(x) * scale <= 190: pts.append((x, y))              # keep the part that fits the panel
        xs = [q[0] for q in pts]; mid = (max(xs) + min(xs)) / 2
        path = ' '.join(('M' if j == 0 else 'L') + f'{cx + scale * (x - mid):.1f},{cy - scale * y:.1f}' for j, (x, y) in enumerate(pts))
        k = FD['kepler'][key]
        t = tip(title, f'fourth generator squares to {eps[-2:].strip()}' if key != '0' else 'fourth generator is null', f'Killing form (positive, negative, zero) = ({k[0]}, {k[1]}, {k[2]})', 'algebra ' + names[key])
        parts.append(f'<g data-tip="{t}" tabindex="0"><rect x="{ox}" y="6" width="{pw}" height="{ph}" rx="10" fill="var(--surf)" stroke="var(--line)"/><path d="{path}" fill="none" stroke="var(--c{1 + i})" stroke-width="2.6"/>'
                     f'<circle cx="{cx - scale * mid:.1f}" cy="{cy}" r="4.5" fill="var(--ink)"/>'
                     f'<text x="{cx}" y="26" text-anchor="middle" class="ink">{E(title)}</text></g>')
        parts.append(f'<text x="{cx}" y="{ph + 28}" text-anchor="middle" class="big">{eps} → {names[key]}</text><text x="{cx}" y="{ph + 48}" text-anchor="middle" class="ink2">Killing signs (+,−,0) = ({k[0]}, {k[1]}, {k[2]})</text>')
    parts.append(f'<text x="14" y="{H - 6}" class="mut">Dot: the centre of force. Shapes from r = 1/(1 + e cos θ) with e = 0.6, 1, 1.6, cut to the panel.</text>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# the Madelung order as rows of the periodic table (Fig. J9)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def madelung_svg(FD):
    sub = FD['madelung']['sub']; cum = FD['madelung']['cum']; noble = FD['madelung']['noble']
    letters = 'spdfg'; slot = {'s': 'k1', 'p': 'k2', 'd': 'k3', 'f': 'k4'}
    rows = []; cur = []
    for (n, l) in sub:
        if l == 0 and cur: rows.append(cur); cur = []
        cur.append((n, l))
    rows.append(cur)
    unit = 8.2; rh = 38; ox = 70; W = ox + 14 * 4 * unit + 90 + 20; H = 12 + rh * len(rows) + 70
    # rows are the periods: 1s | 2s 2p | 3s 3p | 4s 3d 4p | 5s 4d 5p | 6s 4f 5d 6p | 7s 5f 6d 7p
    parts = [f'<svg viewBox="0 0 {W:.0f} {H}" role="img" aria-label="Subshells in Madelung order, one row per period" class="chart fx">']
    z = 0
    for ri, row in enumerate(rows):
        y = 8 + ri * rh; x = ox
        parts.append(f'<text x="{ox - 12}" y="{y + 24}" text-anchor="end" class="ink">period {ri + 1}</text>')
        for (n, l) in row:
            cap = 2 * (2 * l + 1); w = cap * unit * 2; k = slot[letters[l]]; z += cap
            parts.append(f'<g data-tip="{tip(str(n) + letters[l] + " subshell: " + str(cap) + " electrons", "cumulative electrons " + str(z), "order: n + l = " + str(n + l) + ", then n")}" tabindex="0"><rect x="{x + 1:.1f}" y="{y}" width="{w - 2:.1f}" height="{rh - 8}" rx="4" class="{k}"/>'
                         f'<text x="{x + w / 2:.1f}" y="{y + 20}" text-anchor="middle" class="ink i{k[1]}">{n}{letters[l]}</text></g>')
            x += w
        parts.append(f'<text x="{x + 8:.1f}" y="{y + 20}" class="big">{noble[ri]}</text>')
    ly = 8 + len(rows) * rh + 14
    for i, (c, nm) in enumerate((('k1', 's: 2'), ('k2', 'p: 6'), ('k3', 'd: 10'), ('k4', 'f: 14'))):
        parts.append(f'<rect x="{ox + i * 130}" y="{ly - 12}" width="16" height="16" rx="3" class="{c}"/><text x="{ox + i * 130 + 22}" y="{ly + 1}" class="ink2">{nm} electrons</text>')
    parts.append(f'<text x="{ox}" y="{ly + 24}" class="ink2">Bold number at the end of a row: electrons when the row is full (noble gas).</text>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# composition by shared variables as the bit rule (Fig. J10)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def cospan_svg(Alg):
    # verify the displayed identity with the bit rule itself: e_0 e_1 . e_1 e_2 = eps_1 e_0 e_2
    ok = True
    for eps in itertools.product((1, -1, 0), repeat=3):
        al = Alg(eps); s, c = al.blade_mul(0b011, 0b110)
        ok &= (c == 0b101 and s == eps[1])
    assert ok, 'the displayed composition identity fails in the bit rule'
    W, H = 520, 352
    def box(x, y, w, h, t, sub=''):
        return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="var(--surf)" stroke="var(--ink)" stroke-width="1.8"/>'
                f'<text x="{x + w / 2}" y="{y + h / 2 + 5}" text-anchor="middle" class="big">{t}</text>')
    p = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Two open systems composed along a shared wire, and the same composition of labels" class="chart fx">']
    p.append('<text x="14" y="20" class="ink">Open systems composed by identifying a shared variable</text>')
    p.append(box(60, 44, 120, 56, 'system A') + box(290, 44, 120, 56, 'system B'))
    p.append('<line x1="14" y1="62" x2="60" y2="62" stroke="var(--ink)" stroke-width="2.2"/><text x="14" y="54" class="ink2">wire 1</text>')
    p.append('<line x1="180" y1="84" x2="290" y2="84" stroke="var(--ours)" stroke-width="3.4"/><text x="235" y="116" text-anchor="middle" class="ink">wire 2, shared</text>')
    p.append('<line x1="410" y1="62" x2="470" y2="62" stroke="var(--ink)" stroke-width="2.2"/><text x="418" y="54" class="ink2">wire 3</text>')
    p.append('<text x="14" y="140" class="ink2">A has wires {1, 2}, B has wires {2, 3}; the composite has wires {1, 3}.</text>')
    p.append('<text x="14" y="180" class="ink">The same on labels (the bit rule)</text>')
    p.append(box(40, 198, 180, 56, 'e₁e₂ · e₂e₃') + '<text x="244" y="232" text-anchor="middle" class="big">=</text>' + box(268, 198, 160, 56, 'ε₂ · e₁e₃'))
    p.append('<text x="14" y="278" class="ink2">bit 2 is in both labels: it is contracted by its square ε₂ (+1, −1 or 0);</text>')
    p.append('<text x="14" y="296" class="ink2">bits 1 and 3 are in one label each: they stay (XOR).</text>')
    p.append(f'<text x="14" y="{H - 28}" class="ink">Checked in the bit rule for all 27 choices of (ε₁, ε₂, ε₃) ∈ {{+1, −1, 0}}³.</text>')
    p.append(f'<text x="14" y="{H - 8}" class="mut">A reading of “composition by shared variables”; the cospan paper is not computed.</text>')
    p.append('</svg>')
    return ''.join(p)
