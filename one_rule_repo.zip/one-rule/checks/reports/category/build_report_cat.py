#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Builds ../html/category_atlas_report.html: one self-contained page (inline CSS, SVG and a little JS, no external request).
Every number in it is read from logs/cat_check.log (the checks), logs/mutation_cat.log (the sabotage run), cat_results.json (data written by cat_check.py) or computed from matrix_cat.py;
none is typed by hand.  Run: python3 cat_check.py --write > logs/cat_check.log ; python3 mutate_cat.py > logs/mutation_cat.log ; python3 build_report_cat.py"""
import os, sys, re, json, html
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import matrix_cat as MD
import figs_cat as FG
import content_cat as CT
import status_chips as SC

E = html.escape
TODAY = '7 October 2026'
tip = FG.tip

# ------------------------------------------------------------------ the checks (from the log) and the sabotage run
LOG = open(os.path.join(HERE, 'logs', 'cat_check.log'), encoding='utf-8').read()
IDS = []; OK = BAD = 0
for line in LOG.splitlines():
    m = re.match(r'(ok  |FAIL) (\S+?):', line)
    if m:
        IDS.append(m.group(2)); OK += m.group(1).startswith('ok'); BAD += not m.group(1).startswith('ok')
assert BAD == 0, 'a check fails: fix it before building the report'
MUTTXT = open(os.environ.get('MUT_LOG') or os.path.join(HERE, 'logs', 'mutation_cat.log'), encoding='utf-8').read()
_m = re.search(r'mutants caught: (\d+) of (\d+)', MUTTXT); MUT_OK, MUT_ALL = int(_m.group(1)), int(_m.group(2))
MUT_LINES = [l for l in MUTTXT.splitlines() if re.match(r'(caught|MISSED|ERROR|TIMEOUT)', l)]
assert len(MUT_LINES) == MUT_ALL
RES = json.load(open(os.path.join(HERE, 'cat_results.json'), encoding='utf-8'))
assert RES['nok'] == OK and RES['nbad'] == 0, (RES['nok'], OK)
R = RES['res']
def chk_text(cid): return re.search(r'^ok   %s: (.*)$' % re.escape(cid), LOG, re.M).group(1)

def block(pred): return sum(1 for i in IDS if pred(i))
BLOCKS = [
    ('S', 'Associativity of the bit rule for every choice of the trio of squares', lambda i: i[0] == 'S'),
    ('L', 'The bottom of the ladder: n = 0 (the empty label) and n = 1 (dual numbers; the trio over R and over finite fields)', lambda i: i[0] == 'L'),
    ('R', 'Radical, Loewy series, super-centre, centre', lambda i: i[0] == 'R'),
    ('G', 'Grading lift: free rank of the label-homogeneous grading group, and the matrix-unit counterexample', lambda i: i[0] == 'G'),
    ('F', 'Frobenius duality, Nakayama automorphism, symmetrising forms, the trace, the torsor under the units', lambda i: i[0] == 'F'),
    ('K', 'Cube category and its sign, cohomology, octonion cochain, Gauss sum and types, ladders and the sorting sign', lambda i: i[0] == 'K'),
    ('T', 'Tian’s algebra and its truncations', lambda i: i[0] == 'T'),
    ('M', 'Mother algebra and paired against unpaired nulls', lambda i: i[0] == 'M'),
    ('W', 'Witt index, split rank and the quadric counts', lambda i: i[0] == 'W'),
    ('Q', 'Dynkin and extended forms, E_n, Gauss–Milgram, E_n mod 2 against Cl(n,0)', lambda i: i[0] == 'Q'),
    ('E', 'Euler form of the cube category', lambda i: i[0] == 'E'),
    ('J', 'Majkić’s construction on the cube category and the quiver-form reading', lambda i: i[0] == 'J'),
    ('B', 'Fermionic and bosonic ladder', lambda i: i[0] == 'B'),
    ('C', 'Graded types, the Bloch ball and the Born rule, states with null generators', lambda i: i[0] == 'C'),
]
assert sum(block(b[2]) for b in BLOCKS) == OK, (sum(block(b[2]) for b in BLOCKS), OK)

# ------------------------------------------------------------------ the matrix
ST = MD.stats(); ROWS, COLS = MD.ROWS, MD.COLS
GRADE_WORD = {'E': 'exact', 'S': 'structural', 'A': 'analogy'}
best = ST['best']; nrows = ST['n']; ncells = ST['total_cells']
SRC_NAME, SRC_SHORT, ORDER = MD.SRC_NAME, MD.SRC_SHORT, MD.ORDER
SRC_N = {s: sum(1 for r in ROWS if r[1] == s) for s in ORDER}
GAP_ROWS = [r for r in ROWS if not r[3]]
def rd(rid): return rid[0] + '.' + rid[1:]

def matrix_html():
    bands = [('pages 1–2', 2), ('step 1', 1), ('pages 4–5', 2), ('steps 2–16', 15), ('page 7', 1), ('step 17', 1)]
    out = ['<div class="mxwrap" role="group" aria-label="Translation matrix, rows are notions from the four papers and the category lens, columns are atlas pages and steps"><div class="mx">']
    out.append('<div class="mx-corner"></div>')
    for name, span in bands: out.append(f'<div class="mx-band" style="grid-column: span {span}">{name}</div>')
    out.append('<div class="mx-corner2">row</div>')
    for k, short, long_, page in COLS: out.append(f'<div class="mx-ch" title="{E(long_)}"><span>{E(short)}</span></div>')
    cur = None
    for rid, src, title, cells in ROWS:
        if src != cur:
            cur = src
            out.append(f'<div class="mx-grp" style="grid-column: 1 / -1">{E(SRC_NAME[src])} <b>· {SRC_N[src]} rows</b></div>')
        gap = not cells
        lab = f'<span class="rid">{rd(rid)}</span> {E(title)}'
        if gap: lab = '<span class="pill gap">gap</span> ' + lab
        out.append(f'<div class="rl{" gaprow" if gap else ""}" title="{E(title)}">{lab}</div>')
        for k, short, long_, page in COLS:
            if k in cells:
                g, note = cells[k]
                t = tip(f'{rd(rid)}  {title}', f'× {long_} ({page})', f'{GRADE_WORD[g].capitalize()} ({g})', note)
                out.append(f'<div class="c g-{g}" tabindex="0" data-tip="{t}" aria-label="{E(rd(rid))} by {E(short)}: {GRADE_WORD[g]}">{g}</div>')
            else:
                out.append('<div class="c z"></div>')
    out.append('</div></div>')
    rows = []
    for rid, src, title, cells in ROWS:
        if not cells: rows.append(f'<tr><td>{rd(rid)}</td><td>{E(title)}</td><td colspan="3"><i>gap: no counterpart in the atlas</i></td></tr>')
        for k, short, long_, page in COLS:
            if k in cells:
                g, note = cells[k]
                rows.append(f'<tr><td>{rd(rid)}</td><td>{E(title)}</td><td>{E(long_)}</td><td>{g} {GRADE_WORD[g]}</td><td>{E(note)}</td></tr>')
    out.append('<details class="tv"><summary>Table view of the same matrix (%d filled cells and %d gap rows)</summary><div class="tvscroll"><table><thead><tr><th>Row</th><th>Notion</th><th>Atlas column</th><th>Grade</th><th>What matches</th></tr></thead><tbody>%s</tbody></table></div></details>' % (ncells, len(GAP_ROWS), ''.join(rows)))
    return '\n'.join(out)

def coverage_svg():
    W = 520; x0 = 118; scale = 11
    H = 12 + 38 * len(ORDER)
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Rows by best grade for each source" class="chart">']
    y = 8
    for s_ in ORDER:
        parts.append(f'<text x="0" y="{y + 14}" class="t">{SRC_SHORT[s_]}</text><text x="0" y="{y + 27}" class="t2">{SRC_N[s_]} rows</text>')
        x = x0
        for g in ('E', 'S', 'A', 'gap'):
            n = ST['bysrc'][s_].get(g, 0)
            if not n: continue
            w = n * scale * 1.0 + 8
            cls = f'sv-{g}' if g != 'gap' else 'sv-gap'
            tp = f'{SRC_SHORT[s_]}: {n} rows, best grade {GRADE_WORD.get(g, "none (gap)")}'
            parts.append(f'<rect x="{x + 1}" y="{y}" width="{w - 2}" height="28" rx="3" class="{cls}" data-tip="{E(tp, quote=True)}" tabindex="0"/>')
            parts.append(f'<text x="{x + w / 2}" y="{y + 19}" text-anchor="middle" class="bar-{g}">{(g if g != "gap" else "–")} {n}</text>')
            x += w
        y += 38
    parts.append('</svg>')
    leg = '<div class="legend"><span><i class="sw g-E">E</i> exact</span><span><i class="sw g-S">S</i> structural</span><span><i class="sw g-A">A</i> analogy</span><span><i class="sw gapsw">–</i> gap (no counterpart)</span></div>'
    cnt = {k: sum(ST['col'][k].values()) for k, *_ in COLS}
    order = [k for k in sorted(cnt, key=lambda k: (-cnt[k], [c[0] for c in COLS].index(k))) if cnt[k] > 0]
    bh = 18; H2 = bh * len(order) + 8; xl = 78; sc = 14
    long_of = {c[0]: c[2] for c in COLS}; short_of = {c[0]: c[1] for c in COLS}
    p2 = [f'<svg viewBox="0 0 440 {H2}" role="img" aria-label="Filled cells per atlas column" class="chart">']
    for i, k in enumerate(order):
        yy = 3 + i * bh
        p2.append(f'<text x="{xl - 8}" y="{yy + 12}" text-anchor="end" class="t">{E(short_of[k])}</text>')
        x = xl
        for g in ('E', 'S', 'A'):
            n = ST['col'][k].get(g, 0)
            if not n: continue
            w = n * sc
            p2.append(f'<rect x="{x + 1}" y="{yy}" width="{max(w - 2, 2)}" height="14" rx="2" class="sv-{g}" data-tip="{E(f"{long_of[k]}: {n} {GRADE_WORD[g]} cell(s)", quote=True)}" tabindex="0"/>')
            x += w
        p2.append(f'<text x="{x + 5}" y="{yy + 12}" class="t2">{cnt[k]}</text>')
    p2.append('</svg>')
    unused = [short_of[k] for k, *_ in COLS if cnt[k] == 0]
    return ('<div class="figcols"><div><div class="figtitle">Rows by their best grade</div>' + ''.join(parts) + leg + '</div><div><div class="figtitle">Filled cells per atlas column</div>' + ''.join(p2)
            + f'<div class="cap2">Atlas columns with no cell at all: {len(unused)} of {len(COLS)} ({E(", ".join(unused))}). The four papers are about Clifford algebra, classification and categories; they do not touch Maxwell, the Dirac equation, couplings or gravity.</div></div></div>')

def chip(kind): return SC.chip(kind)      # a status is an icon chip: the word is its aria-label and title, never visible

def wrap_sv(h): return re.sub(r'(<svg [^>]*class="chart[^"]*"[^>]*>.*?</svg>)', r'<div class="sv">\1</div>', h, flags=re.S)

def finding(fid, title, chips, left, right='', one=False):
    cls = 'fbody one' if (one or not right) else 'fbody'
    ch = ''.join(chip(c) for c in chips)
    return (f'<article class="finding" id="{fid.lower()}"><div class="fhead"><span class="fid">{fid}</span><h3>{title}</h3><div class="chips">{ch}</div></div>'
            f'<div class="{cls}"><div>{left}</div>{("<div>" + right + "</div>") if right else ""}</div></article>')

def fig(title, body, cap=''):
    return f'<div class="figtitle">{title}</div>{wrap_sv(body)}' + (f'<figcaption>{cap}</figcaption>' if cap else '')

def sg(t): return '(' + ','.join(str(v) for v in t) + ')'

# ------------------------------------------------------------------ numbers used in the text, all from the data
Ed = R['E']; Jg = R['Jsig']; J = R['J']; LAD = R['LAD']; H2 = RES['H2']; PR = RES['PR']; SIGE = RES['sig_E']; TS = RES['TS']; WI = RES['WI']
assert Ed == {'0': [1, 0, 0], '1': [2, 0, 0], '2': [4, 0, 0], '3': [6, 0, 2], '4': [14, 2, 0], '5': [20, 2, 10]}
assert Jg == {'2': [4, 0, 0], '3': [11, 0, 1], '4': [26, 4, 2]}
nE, nS, nA = ST['cellg']['E'], ST['cellg']['S'], ST['cellg']['A']
bE, bS, bA, bG = best.get('E', 0), best.get('S', 0), best.get('A', 0), best.get('gap', 0)
assert bE + bS + bA + bG == nrows
nsig_R = len(R['R']) - 1; nsig_F = len(R['F'])

# ------------------------------------------------------------------ tables
def tbl(head, rows, cls='tabsm'):
    return f'<div style="overflow-x:auto"><table class="{cls}"><thead><tr>{"".join(f"<th>{h}</th>" for h in head)}</tr></thead><tbody>{"".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)}</tbody></table></div>'

def alg_name(k):
    p, q, r = map(int, k.split(',')); return f'Cl({p},{q},{r})' if r else f'Cl({p},{q})'
SAMPLE = ['1,0,0', '0,1,0', '0,0,1', '1,0,1', '0,0,2', '1,1,1', '0,0,3', '3,0,1', '1,1,2']
T_ALG = tbl(['algebra', 'n', 'dim', 'radical', 'Loewy length', 'super-centre', 'centre', 'Frobenius'],
            [[alg_name(k), R['R'][k]['n'], R['R'][k]['dim'], R['R'][k]['rad'], len(R['R'][k]['layers']) + 1, R['R'][k]['sc'], R['R'][k]['centre'], 'symmetric' if R['F'][k]['symmetric'] else 'not symmetric'] for k in SAMPLE])
# the eight graded classes, parsed from the log of C1
_c1 = chk_text('C1'); _pairs = re.findall(r'c=(\d): (\w+)/(\w+)', _c1); assert len(_pairs) == 8
def tname(t): return {'R2': 'R ⊕ R', 'H2': 'H ⊕ H'}.get(t, t)
T_C1 = tbl(['clock c = p − q mod 8', 'Cl(p,q)', 'its even subalgebra'], [[c, tname(a), tname(b)] for c, a, b in _pairs])
def tian_row(k):
    p, q, r = TS[str(k)]; m = k // 2
    return [k, sg((p, q, r)), (f'Cl({m},{m}) = M_{2 ** m}(R), unimodular over Z' if r == 0 else f'Cl({m},{m},1): one label 0 (radical vector a₁ − a₃ + …)')]
T_TIAN = tbl(['k generators cut', 'real signature', 'algebra'], [tian_row(k) for k in range(1, 10)])
T_H2 = tbl(['n', 'cocycles', 'coboundaries', 'H²', 'quadratic forms n(n+1)/2'], [[n, H2[n]['dimZ'], H2[n]['dimB'], H2[n]['dimH'], H2[n]['expected']] for n in ('1', '2', '3', '4')])
T_J = tbl(['n of the cube', 'non-identity arrows', 'atoms', 'orthogonal pairs', 'composable in one order', 'ordered pairs where additivity fails'],
          [[n, J[n]['arrows'], J[n]['atoms'], J[n]['orth'], J[n]['one'], f"{J[n]['nonbilinear']} of {J[n]['tested']}"] for n in ('2', '3')])
T_LAD = tbl(['n', 'blades of Cl(n,0) with square −1', 'classes of E_n/2E_n with q = 1', 'non-trivial blades with square +1', 'non-zero classes with q = 0', 'radical dimension (both)', 'positive roots'],
            [[n, LAD[n]['cl_q1'], LAD[n]['q1'], LAD[n]['cl_q0'], LAD[n]['q0'], f"{LAD[n]['cl_rad']} = {LAD[n]['rad']}", {'3': '4', '4': '10', '5': '20', '6': str(PR['E6']), '7': str(PR['E7']), '8': str(PR['E8'])}[n]] for n in ('3', '4', '5', '6', '7', '8')])
def wrow(k, who):
    w = WI[k]; pts = w['dims']['1']; mx = w['count']; p, q = k.split(',')
    return [who, 2 ** w['w'], pts, mx]
T_W = tbl(['algebra', '2^w (split rank)', 'points: blades with square +1, up to a sign', 'maximal commuting sets'],
          [wrow('4,0', 'Cl(4,0) = M₂(H)'), wrow('2,2', 'Cl(2,2) = M₄(R)'), wrow('6,0', 'Cl(6,0) = M₄(H)'), wrow('8,0', 'Cl(8,0) = M₁₆(R)')])
def sigrow(n, note):
    t = SIGE[str(n)]; return [f'E{n}', sg(t), str(9 - n), note]
T_TOP = tbl(['rung', 'signature (+, −, 0)', 'det Cartan', 'what label 0 does here'],
            [sigrow(11, 'none: ten +1 and one −1 (Lorentzian, recalled name: a form on the root lattice, not a spacetime)'), sigrow(10, 'none: nine +1 and one −1 (hyperbolic, recalled name)'),
             sigrow(9, 'one null: the null root of E₈~, marks sum to 30; the −1 of E10 has become a 0'),
             sigrow(8, 'none: positive definite; 120 positive roots; 135 points and 270 solids on the quadric of Cl(8,0)'),
             sigrow(7, 'none; 63 positive roots; the mod-2 pairing has a radical of dimension 1, the pseudoscalar of Cl(7,0)'),
             sigrow(6, 'none; 36 positive roots; 27 points and 45 lines on the quadric of Cl(6,0)'),
             sigrow(5, 'none; D₅; the mod-2 radical has dimension 1 (n odd)'), sigrow(4, 'none; A₄'), sigrow(3, 'none; A₂ × A₁ (determinant 6); the mod-2 radical has dimension 1')])
T_CHK = ''.join(f'<tr><td><b>{E(b[0])}</b></td><td>{E(b[1])}</td><td class="num">{block(b[2])}</td></tr>' for b in BLOCKS)
def _mut_row(l):
    mark = '✓' if l.startswith('caught') else '✗'
    body = re.sub(r'^(caught|MISSED|ERROR|TIMEOUT)\s+', '', l)
    return '<tr><td>' + mark + '</td><td>' + E(body) + '</td></tr>'
T_MUT = ''.join(_mut_row(l) for l in MUT_LINES)

# ------------------------------------------------------------------ cards
def cards_html():
    out = []
    for k, title, by, says, did, chips in CT.PAPER_CARDS:
        note = f'<p class="not">{E(CT.NOTES[k])}</p>' if k in CT.NOTES else ''
        out.append(f'<div class="card paper"><h3>{E(title)}</h3><div class="by">{E(by)}</div>{note}<p><b>It says.</b> {says}</p><p><b>What we computed.</b> {did}</p><p>{"".join(chip(c) for c in chips)}</p></div>')
    return ''.join(out)
CHIPLAB = {'kept': 'kept', 'partly': 'partly', 'deadend': 'dead end', 'recalled': 'recalled'}
LENS_HTML = ''.join(f'<div class="card"><h3>{E(t)}</h3>' + (f'<p class="not">{E(CT.NOTES[t])}</p>' if t in CT.NOTES else '') + f'<p>{SC.verdict(c, CHIPLAB[c])} <span class="ids">{E(ids)}</span></p><p>{E(txt)}</p></div>' for t, c, txt, ids in CT.LENSES)
_KL = {'cite': 'checked: found in the text', 'chk': 'checked: computed', 'our': 'ours: our reading', 'opn': 'open: a dead end or open'}
def _chipkind(kind): return 'checked' if kind in ('cite', 'chk') else ('ours' if kind == 'our' else 'open')
def chip2(kind): return SC.chip(_chipkind(kind), _KL[kind])
def _rel(lab, a, b, kind, txt):
    return ('<div class="r"><span class="badge">' + lab + '</span><div><b>' + E(FG.NODES[a][0]) + '</b> and <b>' + E(FG.NODES[b][0]) + '</b> ' + chip2(kind) + '<br>' + E(txt) + '</div></div>')
REL_HTML = '<div class="rel">' + ''.join(_rel(*e) for e in FG.EDGES) + '</div>'

LADDER_ROWS = ''
for n, exists, what, first, ids in CT.LADDER:
    what = what.replace('{E3}', sg(Ed['3'])).replace('{E4}', sg(Ed['4']))
    exists = exists.replace('{E5}', sg(Ed['5']))
    LADDER_ROWS += '<tr><td class="num"><b>' + n + '</b></td><td>' + E(exists) + '</td><td>' + E(what) + '</td><td>' + E(first) + '</td><td class="ids">' + E(ids) + '</td></tr>'

def questions_html():
    out = []
    for g, title, items in CT.QUESTIONS:
        out.append(f'<h3 class="qg" id="qg-{g.lower()}"><span class="fid">Q{g}</span> {E(title)} <small>{len(items)} question{"s" if len(items) != 1 else ""}</small></h3>')
        for qid, who, q, checked, notchecked in items:
            out.append(f'<article class="qcard" id="q-{qid.lower()}"><div class="qh"><span class="qid">Q{qid}</span><span class="qwho">ask: {E(who)}</span></div><p class="qq">{E(q)}</p>'
                       f'<div class="qcols"><div><b>Checked.</b> {E(checked)}</div><div><b>Not checked.</b> {E(notchecked)}</div></div></article>')
    return ''.join(out)
NQ = sum(len(g[2]) for g in CT.QUESTIONS)

# ------------------------------------------------------------------ findings
N1 = finding('N1', 'Label 0 is the non-invertible direction: radical, Loewy series, super-centre, grading lift', ['checked', 'standard'],
 '<p>In the bit rule with squares ε<sub>i</sub> ∈ {+1, −1, 0} the labels that contain a null bit span the <b>radical</b>: a two-sided ideal of dimension 2ⁿ − 2^(p+q), nilpotent, with the ordinary algebra Cl(p,q) as quotient (R1; the criterion, the kernel of the trace form of the regular representation, is recalled). The powers of the radical are spanned by the labels with at least k null bits, so the <b>Loewy length is r + 1</b> and the layers have dimension C(r,k)·2^(p+q) (R2). The <b>super-centre</b>, the elements with zx = (−1)^(|z||x|) xz, is exactly the exterior algebra on the r null generators, of dimension 2^r (R3). The ordinary algebras are graded-central simple for every n, so the algebra is <b>graded-Azumaya if and only if r = 0</b>. The ordinary centre of Cl(p,q) has dimension 1 for n even and 2 for n odd (R4); the gap between the ordinary and the super count is the whole story of ungraded against graded Morita classes.</p>'
 '<p><b>Grading.</b> Among the gradings in which every label is homogeneous, the largest free abelian grading group has rank r (G1; the universal label-homogeneous grading group is Z₂^(p+q) × Z^r, proved for all n in T2): a generator with square ±1 forces 2g = 0, while a null generator is exactly one whose Z₂-grading lifts to Z, an additive integer degree (we do not call it conserved: there is no Hamiltonian here). The exterior algebra is N^r-graded. The qualifier is necessary: for arbitrary gradings the rank can exceed r, since M₂(R) = Cl(2,0) carries a Z-grading by matrix-unit degree (G2).</p>'
 '<p class="not">What this is not: a classification. The representation type of the exterior algebra Λ(k^r) (finite for r ≤ 1, tame for r = 2, wild for r ≥ 3) is recalled, not computed, and calling it a “distance from invertible” is a reading (questions QA1–QA3).</p>'
 f'<p class="ids">checks R1–R4, G1, G2; {nsig_R} signatures with up to five generators.</p>',
 '<div class="figtitle">Nine algebras of the ladder</div>' + T_ALG + '<figcaption>Dimension of the radical, of the quotient chain (Loewy length = r + 1) and of the super-centre, all solved on the labels, not read from a formula. The Frobenius column is N3.</figcaption>')

N2 = finding('N2', 'The clock of a degenerate cell is the clock of its quotient; the types are one Gauss sum; five ungraded types against eight graded', ['checked', 'standard', 'ours', 'open'],
 '<p>The clock c = p − q mod 8 is the phase of one sum over the labels, Σ<sub>a</sub> i^(|a∩P| − |a∩Q|) = (1 + i)^p (1 − i)^q, with P the positive and Q the negative generators (exact Gaussian integers for all p + q ≤ 10; K4a). Summed over the labels without a null bit it is the Gauss sum of the quotient Cl(p,q) = Cl(p,q,r)/J; summed over all labels with a null bit adding 0 to the exponent (T4 (iii)) it is 2^r times that, the Gauss sum of the mother cell Cl(p+r, q+r), with the same phase. Both cells are canonical, and the value 2 on a radical class would make the sum 0, so <b>the clock of Cl(p,q,r) is the clock of its quotient and of its mother cell</b>: forced, not chosen (bd·mat·3, bd·cat·4, bd·geo·5, bd·xck·3). Nor is r a second coordinate of the class. Over its super-centre Λ(R^r) the degenerate cell is graded Azumaya (bd·mat·10, bd·alg·9), and its graded Hochschild groups HH¹ and HH² relative to Λ(R^r) vanish, computed exactly for r = 1 with p + q ≤ 3 and for r = 2 with p + q ≤ 2 (over R they do not: the null square is a deformation direction, bd·hh·5); for r = 1 and p + q ≤ 3 every free graded Λ(R)-algebra with fibre Cl(p,q) is Cl(p,q,1), computed from first principles (bd·hh·1–4). So <b>r is the base ring</b>; for every (p,q,r) this follows from the separability of Cl(p,q) (pointer, source unread). Over R the graded Morita classes of the cells form the monoid Z₈ × N, (clock, r), with no inverse for r ≥ 1 (bd·cat·11). The trio −1, 0, +1 are the three steps of the clock: back, stay, forward.</p>'
 '<p>The sum of the squares of the labels, Σ<sub>a</sub> e<sub>a</sub>² = Re S + Im S = Re((1 − i)S) = 2^((n+1)/2) cos((p − q − 1)π/4) (K4c), has a sign that is the type: positive R, zero C, negative H. It is not the real part of S alone: at c = 2 the real part of S is 0 while the type is R. The same number is the Frobenius–Schur count of the group {±e<sub>a</sub>} acting on the algebra by left multiplication, computed from the squares of the labels: in the normalisation Σ e<sub>a</sub>² = kN·ind(D) the indicator per simple summand M<sub>N</sub>(D) is +1, 0, −2 for R, C, H (T4), and the number of simple factors is read from the square of the full label (K4b, 45 signatures; the textbook list is used only to compare). So <b>Schur’s lemma</b>, which gives Baez’s R, C, H, and the <b>mod-8 table</b> of the KTH notes (Table 5.1) are one count on the labels.</p>'
 '<p>Ungraded the real Clifford algebras have five types; graded, eight: the pair (type of Cl(p,q), type of its even subalgebra) separates the eight clock values (C1, table). That is the count behind the ten of the Tenfold Way (Wall, recalled): eight real classes and two complex. We recomputed the pairs; Wall’s theorem that these are the graded Morita classes with group Z₈ is recalled.</p>'
 '<p class="not">Standard, quoted and not computed: Baez’s paper states that the ten super division algebras correspond to the ten symmetry classes of free-fermion matter, and Kitaev’s periodic table (arXiv:0901.2686) matches the eight real and two complex Clifford classes with them. Which class sits at which clock value needs T² and C² as input; whether a null generator has a place among them is open (question QC3).</p>'
 '<p class="ids">checks K4a–K4c, K5a, C1, L1a; bridge checks (selfcheck/bridges/) bd·mat·3, bd·mat·10, bd·cat·4, bd·cat·11, bd·geo·5, bd·xck·3, bd·alg·9, bd·hh·1–5.</p>'
 + fig('Fig. 3 · The clock, and the null direction r', FG.clock_svg(R), 'Left: the eight types by clock value. Right: Cl(1,1,r) for r = 0…3, cut by the powers of the radical; the clock stays 0 for every r, the clock of the quotient Cl(1,1). Hover for numbers.') + '<div class="figtitle" style="margin-top:12px">The eight graded classes</div>' + T_C1, one=True)

N3 = finding('N3', 'The complement mask is a Frobenius duality for every signature; ungraded, the top-blade form is symmetric iff n is odd, and the algebra has a symmetric form iff n is odd or r = 0; in super vector spaces it is super-symmetric for every signature', ['checked', 'standard'],
 '<p>The coefficient λ of the full label 11…1 defines a pairing (a,b) ↦ λ(e<sub>a</sub>e<sub>b</sub>) that is non-zero exactly when b = a xor 11…1, with value ±1. So it is non-degenerate for every signature, label 0 included (F1; 55 signatures with up to five generators). In algebra terms the complement mask is a <b>Frobenius (Poincaré-type) duality</b> and not only a metric Hodge star, which needs an invertible pseudoscalar. It obeys λ(e<sub>a</sub>e<sub>b</sub>) = (−1)^(|b|(n−|b|)) λ(e<sub>b</sub>e<sub>a</sub>): the Nakayama automorphism is the identity for n odd and the grade involution for n even (F2).</p>'
 '<p>Ungraded, a symmetrising form of <i>any</i> kind exists exactly when n is odd or r = 0 (F3). For n even and r ≥ 1, for example the 3D projective algebra Cl(3,0,1), the algebra is Frobenius but not symmetric, and no unit of the algebra implements the grade involution: every element that conjugates the grade involution is supported on labels with a null bit, so it lies in the radical and is nilpotent (F5, computed exactly for n = 2, 4, 6; proved for all n in T3).</p>'
 '<p>The scalar part ⟨x⟩₀, the usual trace or probability rule, is another form: its pairing has rank 2^(p+q) only and is blind to every label with a null bit (F4). In Cl(3,0) the two forms agree up to the central pseudoscalar, λ(x) = −⟨ωx⟩₀ (C2).</p>'
 '<p><b>The torsor.</b> All Frobenius forms of the algebra are λ(u·) with u <i>any</i> unit: non-degenerate iff u is a unit, a torsor under the whole unit group; only the symmetric forms, when they exist, are a torsor under the central units (F5; T3). In Cl(3,0), u = 2 + e₁ is a non-central unit and λ(u·) is a non-degenerate, non-symmetric Frobenius form.</p>'
 '<p><b>In super vector spaces.</b> With b the complement of a the Nakayama sign (−1)^(|b|(n−|b|)) is (−1)^(|a||b|), the Koszul sign: λ(xy) = (−1)^(|x||y|) λ(yx) for homogeneous x, y, so λ is super-symmetric and every Cl(p,q,r) is a symmetric Frobenius algebra in super vector spaces (bd·cat·5, every sign vector with n ≤ 7). The super-symmetric Frobenius forms are exactly λ(z·) with z a unit of the super-centre Λ(R^r): a torsor under those units, for every signature (bd·cat·8, n ≤ 5). The symmetric statements above are the ungraded ones.</p>'
 '<p class="not">Observed by rank tests for n ≤ 5 and by the exact conjugator computation for n ≤ 6; the statements are proved for all n in T3 (theorem T3 of the page For researchers of the atlas, script researchers_checks/check_T3.py). Their meaning for the dual used in projective geometric algebra is a question (QA4, QA5).</p>'
 '<p class="ids">checks F1–F5, C2; bridge checks (selfcheck/bridges/) bd·cat·5, bd·cat·8.</p>',
 fig('Fig. 4 · Where a symmetric form exists', FG.frob_svg(R), 'Rows n = 1…5, columns r = 0…5; each cell counts the signatures (p,q,r) with p + q + r = n. Orange cells have no symmetric form. Hover a cell.'))

N4 = finding('N4', 'The cube of labels as a category: one sign up to gauge, the Koszul complex, H² = quadratic forms, the octonions as a cochain', ['checked', 'standard'],
 '<p>Order the labels by inclusion: the Boolean lattice, a category with 3ⁿ arrows (K1a, counted for n ≤ 6). Give the arrow a → a + {i} the sign (−1)^(number of set bits below i): the product of the four signs round every square is −1 for n ≤ 7, so <b>every square anticommutes</b>. This is the bit-rule sign, e<sub>i</sub>e<sub>a</sub> = (−1)^(#{j ∈ a : j &lt; i}) e<sub>a+i</sub> (K1b), the Jordan–Wigner string. It is <b>unique up to gauge</b>: H¹ of the cube with F₂ coefficients is zero (K1c, n ≤ 6), and a brute-force count on the 3-cube finds 128 = 2⁷ anticommuting assignments among 4096, one orbit of the rescaling of the eight labels (K1d). The same signs make the boundary d e<sub>a</sub> = Σ ± e<sub>a−i</sub> square to zero, and the complex is exact (K1e): the Koszul complex and the creation operators of the Fock space.</p>'
 '<p><b>Cohomology of the sign.</b> The normalised 2-cocycles of Z₂ⁿ with values in F₂ give dim H² = n(n+1)/2 (table): a class is a quadratic form, fixed by the squares and the commutators (K2a). The bit rule with ε = ±1 is a 2-cocycle whose commutators are all 1; these 2ⁿ classes are the Clifford algebras among the twisted group algebras (K2b). The octonions are the same eight labels with a sign F that is not a cocycle: the associator sign is (−1)^det over F₂, −1 on exactly the 168 independent triples, and it is the coboundary of F, a 3-cocycle (pentagon identity on all 4096 quadruples), while the Clifford sign of Cl(0,3) on the same labels is a cocycle (K3a, K3b).</p>'
 '<p class="not">Standard: sign uniqueness on cubes of resolutions, H² as quadratic forms, the cochain-twist form of the octonions (Albuquerque–Majid, recalled). The atlas adds that all three are statements about one rule. For the null value 0 the sign takes values in a monoid, and the right cohomological framework is a question (B2).</p>'
 '<p class="ids">checks K1a–K1e, K2a, K2b, K3a, K3b.</p>',
 '<div class="figtitle">H² of Z₂ⁿ with values in F₂</div>' + T_H2 + '<figcaption>The invariants (squares and commutators) have full rank on H² and kill the coboundaries, so the classes are the quadratic forms.</figcaption>')

N5 = finding('N5', 'Ladders as maps: double, halve, restrict to a face, complement; with three or more null generators and no other, label 0 cannot be peeled off', ['checked', 'standard'],
 '<p><b>Up.</b> Concatenating two lists of generators is exactly the graded tensor product, (a₁⊗b₁)(a₂⊗b₂) = (−1)^(|b₁||a₂|) a₁a₂ ⊗ b₁b₂, on all label pairs for six pairs of signatures including null generators (K5a). The sign is the parity of the number of inversions of the concatenated list, by an independent bubble sort on all 65 536 label pairs of eight generators (K5c): the sorting sign of Tian’s Lemma 4.20.</p>'
 '<p><b>Down.</b> The even subalgebra of Cl(p,q,r) is Cl(p,q−1,r) (or Cl(q,p−1,r)) as soon as one generator t with non-zero square exists, through f<sub>i</sub> = e<sub>i</sub>e<sub>t</sub> (K5b; all signatures with 1 to 4 generators). With only null generators it fails from three generators on, and only there (p = q = 0, r ≥ 3; T5 (d)): the even part of the exterior algebra on three generators has dimension 4 and zero products (Loewy length 2), while a Clifford algebra on two generators, here Λ(R²), has Loewy length 3. With one or two null generators and no other the even part is still a Clifford algebra, R or the dual numbers. <b>In that sense, and only for r ≥ 3, label 0 cannot be peeled off from the top.</b></p>'
 '<p><b>Sideways.</b> With one null generator the radical is the half of the cube that contains the null bit, a face; with r ≥ 2 it is spanned by the labels with at least one null bit, the complement of the face of labels with none (R1). The face of labels without a null bit carries the quotient Cl(p,q). The mother algebra of the KTH notes sends each null generator to f⁺ − f⁻ in the ordinary Cl(p+r, q+r) (nine signatures up to six generators, images multiply by the bit rule and are independent; M1): a label 0 is the null vector of a hyperbolic pair, and the pair (+1, −1) together is the zero of the Witt group. In Cl(1,1) the vectors u = e₁ + e₂ and v = e₁ − e₂ square to 0 with uv + vu = 4 and generate a matrix algebra with zero radical; two unpaired null generators have a radical of dimension 3 (M2). The word “null” covers two things: a <b>paired</b> null (creation and annihilation, the Fock pair of the notes and of Tian) and an <b>unpaired</b> null (label 0).</p>'
 '<p class="not">Standard: graded tensor product, even subalgebra, Witt group. Cl is a functor: restrict, quotient and mother are Cl applied to maps of quadratic spaces, with Cl(σ∘μ) = Cl(σ)∘Cl(μ) (bd·cat·17), and doubling is Cl of an orthogonal sum; halving is a natural isomorphism Cl∘(halve) ⇒ Cl⁰ on pointed quadratic spaces (V, t), t² ≠ 0, with the isometries that fix t (bd·cat·16); the complement is the Frobenius structure of each algebra, not a map between algebras. The atlas’s step 5 builds spinors from even parts and has the same limitation; step 3 reflects in invertible vectors and a null vector has no reflection.</p>'
 '<p class="ids">checks K5a–K5c, M1, M2; bridge checks (selfcheck/bridges/) bd·cat·16, bd·cat·17.</p>'
 + fig('Fig. 6 · Four moves between dimensions', FG.functors_svg(), 'Up and down are the first two paragraphs above; the red text marks the one move that fails, and only for three or more null generators with no other.'), one=True)

N6 = finding('N6', 'Tian’s algebra is a Clifford algebra of the atlas in a hyperbolic basis; its odd truncations hide one label 0', ['checked', 'standard', 'open'],
 '<p>Tian’s relations a<sub>i</sub>² = 0, a<sub>i</sub>a<sub>j</sub> = −a<sub>j</sub>a<sub>i</sub> for |i − j| > 1 and a<sub>i</sub>a<sub>i+1</sub> + a<sub>i+1</sub>a<sub>i</sub> = 1 are realised on the exterior algebra of n sites (a<sub>2j</sub> creates, a<sub>2j−1</sub> annihilates at two sites, with the sign of the occupied sites below). They hold for n = 1, 2, 3 and the 4ⁿ monomials are linearly independent, so End(V<sub>n</sub>) = M<sub>2ⁿ</sub>(Z) is faithful (T1: our own check of what the paper proves in Lemma 3.3).</p>'
 '<p>The quadratic form behind the relations, v² = Σ c<sub>i</sub>c<sub>i+1</sub>, has the path graph as its polar form, and its real signature is (⌊k/2⌋, ⌊k/2⌋, k mod 2) for k = 1…10 (T3, table). Even length: hyperbolic, Cl(m,m) = M<sub>2^m</sub>(R), the clock-0 matrix algebra, unimodular over Z. Odd length: one label 0 hides in the form. A cut at odd length 2n − 1 has the radical vector a₁ − a₃ + a₅ − …, non-zero, of square 0, anticommuting with every generator (T2): a label 0 that Tian’s relations do not display. Re-expressed in an orthonormal basis of the form, a₁…a<sub>k</sub> (k = 2, 3, 4) multiply by the bit rule of Cl(1,1), Cl(1,1,1) and Cl(2,2) on all label pairs (T4). So Tian’s algebra over R <b>is</b> an atlas algebra in a non-orthogonal basis, and its nilpotent a<sub>i</sub> are paired nulls (a₁ + a₂ has square +1, a₁ − a₂ square −1), not label 0.</p>'
 '<p>The paper’s sign, x ~ N(x)[η(x)] with η the number of inversions (Lemma 4.20), is the bit-rule sign (K5c). That each inversion is an odd cohomological shift, the diagrammatics and the contact categories are the paper’s statements and were not tested.</p>'
 '<p class="not">Open in the paper: Remark 2.6 (is Hom(∅,∅) one-dimensional?) and Conjecture 2.11. Open for us: does the radical vector of an odd truncation have an object in CL (question QB5)?</p>'
 '<p class="ids">checks T1–T4, K5c.</p>',
 '<div class="figtitle">Truncations of Tian’s generator list</div>' + T_TIAN + '<figcaption>Signature of the form on k generators a₁…a<sub>k</sub>, computed from the path graph.</figcaption>')

N7 = finding('N7', 'Majkić’s arrows-as-vectors fails as written; a quiver-form reading of ours has computed signatures', ['checked', 'ours', 'open'],
 f'<p class="not">{E(CT.NOTE_V3)}</p>'
 '<p>Implemented on the cube category: objects are the labels, an arrow a → b for a ⊆ b. For n = 2 there are 5 non-identity arrows (4 atoms): 8 unordered pairs are orthogonal in the paper’s sense (not composable in either order), 2 are composable in one order and none in both, since a poset has no cycles. For n = 3, 19 arrows, 153 orthogonal, 18 composable (J1). Two findings.</p>'
 '<p><b>One.</b> For the composable pairs fg + gf is a scalar plus a bivector, not a scalar, so the Clifford relation fg + gf = 2⟨f,g⟩ does not hold there. <b>Two.</b> The inner product of Def. 4 is not additive along composition: on the 2-cube f = (∅ → {1,2}) is the composite of two atoms, but f·atom = 0 while the atom-by-atom sum is 2 (table, J2). The paper says itself that V is not a vector space (Corollary 1), so there is no quadratic form v ↦ v², and the two properties of Corollary 2 hold by definition: norm 1 for atoms, and the opposite orientation of the two bivectors.</p>'
 '<p><b>A reading that is ours.</b> Put the Gram matrix with 2 on the diagonal and 1 for atoms that compose on the cube category. A symmetric form has a signature and a Clifford algebra, and a quiver’s Tits form is of this kind. For n = 2, 3, 4 (4, 12, 32 atoms) the signature is (4,0,0), (11,0,1), (26,4,2) (J3): definite, then one null direction at n = 3, then indefinite. The Euler form of the cube category itself, symmetrised, goes (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0…5 (E1; Fig. 5). Its Tits form, which governs the representation type, differs from n = 3 on: (6,1,1) at n = 3 (T8). Whether the Gram, Euler and E_n sequences share a reason is question QB4; we do not call it a pattern.</p>'
 '<p class="not">Ours: the reading as a Gram form, and the interpretation of the null direction of the Euler form at n = 3 as a label 0, which is a reading of a computed signature. Not computed: why it appears at n = 3 (question QB4). The Metacategory and the topology of the paper are not touched.</p>'
 '<p class="ids">checks J1–J3, E1.</p>',
 '<div class="figtitle">Majkić’s construction on the cube category</div>' + T_J + '<figcaption>“Additivity fails” counts ordered pairs (f, g) where f·g differs from the sum of the products of the atoms in a decomposition of f and g.</figcaption>')

N8 = finding('N8', 'Top-down: the E_n ladder gets a null direction at E9, the null root, and the next rung trades it for a −1', ['checked', 'standard', 'ours'],
 '<p>The Cartan (Tits) form of a Dynkin diagram is a quadratic form on Z^n of signature (n,0,0): the algebra Cl(n,0). For the extended diagrams A₃~, D₄~, D₇~, E₆~, E₇~, E₈~ it is positive semi-definite with a one-dimensional radical, signature (n,0,1): Cl(n,0,1). The radical of E₈~ is the null root with marks 1, 2, 2, 3, 3, 4, 4, 5, 6 summing to 30, the Coxeter number of E₈ (Q1, exact rational diagonalisation). Along the series, det Cartan(E<sub>n</sub>) = 9 − n (Q2); E₈ is (8,0,0), E₉ = E₈~ is (8,0,1), E₁₀ is (9,1,0), E₁₁ is (10,1,0). Going <b>down</b> from the Lorentzian rung, the −1 becomes a 0 at the affine rung and disappears at the finite one: det = 9 − n is 0 only at n = 9, the only rung with a null direction (Q1, Q2). Calling n = 9 a “boundary” between the definite and the Lorentzian rungs is ours. That E₉, E₁₀, E₁₁ are the affine, hyperbolic and Lorentzian Kac–Moody diagrams is recalled; the signatures are computed. They are signatures of the Cartan form on the root lattice, not of a spacetime; nothing here touches E₁₀ or E₁₁ in supergravity. The finite series stops because 9 − n reaches 0; the 8 it shares with the clock is the period of the Gauss-sum phase, and Clifford periodicity does not cause the stop (T10 (7)).</p>'
 '<p><b>What else the rungs carry.</b> Positive roots by reflection orbits: A₃ 6, A₈ 36, D₄ 12, D₈ 56, E₆ 36, E₇ 63, E₈ 120 (Q3), which by Gabriel’s theorem (recalled) are the numbers of indecomposable representations of the quivers. Gauss–Milgram: the sum over the discriminant group of exp(πi x·x) has the phase 2πn/8 for A₃, A₈, D₄, D₈, E₆, E₇, E₈ (numerically, exact norms): the same clock as the labels of Cl(n,0) (Q4, K4a). And E<sub>n</sub>/2E<sub>n</sub> with q = x·x/2 mod 2 has the same counts as the blades of Cl(n,0) for n = 3…8 (Q5, table); at n = 7 the 64 classes with q = 1 are the 63 positive roots plus the central pseudoscalar.</p>'
 '<p class="not">Standard: root counts, Gauss–Milgram, roots modulo 2. Recalled: the Kac–Moody names. W(E<sub>n</sub>) mod 2 = O(Q) is not recalled: the atlas checks it (groups_check.py part B, n = 3…8; a certificate for n = 3…20, bd·en·2, the kernel being the centre for n ≤ 8, bd·en·3) and T9 proves it, with E<sub>n</sub>/2E<sub>n</sub> carrying the label form of Cl(n,0) for every n ≥ 3 and A<sub>n</sub>/2A<sub>n</sub> that of Cl(0,n), the two coinciding iff 4 | n. The reading of label 0 as the null root is ours (questions QD1–QD3).</p>'
 '<p class="ids">checks Q1–Q5.</p>',
 '<div class="figtitle">The E_n ladder</div>' + T_TOP + '<div class="figtitle" style="margin-top:12px">E_n modulo 2 against the blades of Cl(n,0)</div>' + T_LAD)

N9 = finding('N9', 'Witt index = split rank: the finite shadow of the spectral theorem, with counts', ['checked', 'standard'],
 '<p>The largest set of mutually commuting labels whose blades all square to +1 spans a split commutative algebra R^(2^w); its 2^w orthogonal projectors are the finite shadow of the spectral theorem. By exhaustive search over the totally singular subspaces of the F₂ quadric q(a) = [e<sub>a</sub>² = −1], the largest w satisfies 2^w = (number of simple factors) × N, where Cl(p,q) = M<sub>N</sub>(K) (⊕ M<sub>N</sub>(K)): for all 36 signatures tried (W1).</p>'
 '<p>Counts: Cl(4,0) has 5 points and no lines; Cl(6,0) 27 points and 45 lines, the points and lines of the elliptic quadric Q⁻(5,2) on which W(E₆) acts (the 27 lines and 45 tritangent planes: recalled; not the Klein quadric Q⁺(5,2), which has 35 points and is the class of Cl(3,3), Cl(4,2), Cl(0,6), T11); Cl(8,0) 135 points and 270 solids, the points and solids of Q⁺(7,2) (W2). The 270 solids split into two families of 135, two solids being in the same family when their intersection has even codimension: the two half-spin classes. With the 135 points they are the three 135s of triality (W3, counted). Cl(2,2) has 9 points and 6 maximal sets, the shape of a 3 × 3 grid: the Peres–Mermin square (recalled; the sign pattern was not checked).</p>'
 '<p class="not">This answers item 2 of “Next, in order” at the level of counts (question QE2). The identification with contextuality sets and anything at 24 or the Golay code are not touched (question QE5).</p>'
 '<p class="ids">checks W1–W3.</p>',
 '<div class="figtitle">Commuting sets of blades with square +1</div>' + T_W)

N10 = finding('N10', 'The fermionic and the bosonic ladder are the same relations with a super-commutator; in Cl(3,0) the trace of the Born rule is a symmetric Frobenius form, and the top-blade form is never a state (λ(1) = 0)', ['checked', 'ours'],
 '<p><b>Ladder.</b> On the 2ⁿ labels (n ≤ 4) the fermionic oscillators satisfy [a<sub>i</sub>, a<sub>j</sub>⁺]<sub>super</sub> = a<sub>i</sub>a<sub>j</sub>⁺ + a<sub>j</sub>⁺a<sub>i</sub> = δ<sub>ij</sub> and [N<sub>i</sub>, a<sub>j</sub>] = −δ<sub>ij</sub>a<sub>j</sub>: the Heisenberg-ladder relations of the boson with the commutator replaced by the super-commutator (the Koszul sign for two odd elements). The dimension is 2ⁿ, the super-dimension (the trace of the parity) is 0, which is what [a, a⁺] = 1 needs: an ordinary commutator has trace 0 and cannot equal the identity in finite dimension. Pauli’s a² = 0 is the super-commutator of an odd element with itself (B1). This answers item 3 of “Next, in order” at the level of relations; the bosonic Fock space and the limit n → ∞ are not touched (question QE3).</p>'
 '<p><b>Bloch ball.</b> In Cl(3,0) = M₂(C) the mixed state ρ = (1 + v)/2 and the projector P = (1 + u)/2 give 2⟨ρP⟩₀ = (1 + v·u)/2 exactly (twelve rational pairs); (2ρ − 1)² = v², so ρ is positive iff |v| ≤ 1 and pure iff |v| = 1; and the top-blade Frobenius form of N3 is λ(x) = −⟨ωx⟩₀ with ω the central pseudoscalar: <b>the trace of quantum mechanics is a symmetric Frobenius form</b>, canonical up to a central unit among the symmetric ones (C2, F5; all Frobenius forms are λ(u·) with u any unit). Only the trace is a state: λ(1) = 0. This answers item 1 of “Next, in order” for n = 3 (questions QE1, QA5).</p>'
 '<p><b>States with null generators.</b> The scalar-part probability rule does not need the top-blade form when null generators are present. With the dagger involution the scalar part is a positive functional whose Gram matrix is the identity on the labels without a null bit and 0 on the labels with one; adding to it any hermitian functional supported on the radical breaks positivity; and the top-blade form is never a positive hermitian functional (C3, all 34 signatures with up to four generators). So every state vanishes on the labels with a null bit, the states of Cl(p,q,r) are exactly those of Cl(p,q), and the scalar part stays the state functional, blind to the radical as every state must be (proved for all n and every involution in T15; the scalar part is positive for the dagger involution).</p>'
 '<p class="not">Ours: reading the trace as a Frobenius form of the algebra, and the finite shadow of why the bosonic ladder needs infinite dimension. Not computed here: composite systems, the bosonic side, involutions other than the dagger one for positivity.</p>'
 '<p class="ids">checks B1, C2, C3, F4, F5.</p>')

FINDINGS = ''.join([N1, N2, N3, N4, N5, N6, N7, N8, N9, N10])

# ------------------------------------------------------------------ the page
CSS = open(os.path.join(HERE, 'report_style.css'), encoding='utf-8').read() + open(os.path.join(HERE, 'cat_style_extra.css'), encoding='utf-8').read() + SC.CSS
JS = open(os.path.join(HERE, 'report_script.js'), encoding='utf-8').read()
MATRIX = matrix_html(); COVER = coverage_svg(); CARDS = cards_html()
CHIPS = SC.legend(['checked', 'standard', 'ours', 'open'], {'standard': 'textbook or the paper’s own statement, used as is'})
DEAD = ''.join(f'<li>{E(t)}</li>' for t in CT.DEAD_ENDS)
LIMS = ''.join(f'<li>{E(t)}</li>' for t in CT.LIMITS)
NEXT_ROWS = ''.join(f'<tr><td>{a}</td><td>{E(b)}</td><td>{c}</td></tr>' for a, b, c in [
    ('1', 'Ch. 17: mixed states as (1 + v)/2 in Cl(3,0), the probability rule as a trace', 'done for n = 3: <a href="#n10">N10</a>, check C2; null generators settled: no state sees them, check C3 and T15 (<a href="#q-e1">QE1</a>, <a href="#q-a5">QA5</a>); composite systems open'),
    ('2', 'Ch. 8–11: finite shadow of the spectral theorem', 'counts done: <a href="#n9">N9</a>, checks W1–W3; contextuality link open (<a href="#q-e2">QE2</a>)'),
    ('3', 'Ch. 16: what the fermionic oscillator shares with the bosonic ladder', 'relations done: <a href="#n10">N10</a>, check B1; the limit open (<a href="#q-e3">QE3</a>)'),
    ('4', 'The Dirac signs (F9)', 'settled in the algebra'),
    ('5', 'One combined matrix along Schuller’s pipeline', 'the three matrices are merged (131 rows × 22, translation_matrix.json); the reordering along the pipeline is not done (<a href="#q-e4">QE4</a>)')])

_bs = ST['bysrc']
assert set(_bs['M']) <= {'A', 'gap'} and _bs['K'].get('E', 0) == 9 and {r[0] for r in GAP_ROWS if r[1] == 'T'} == {'T4', 'T5'}
_cnt = {k: sum(ST['col'][k].values()) for k, *_ in COLS}; _short = {c[0]: c[1] for c in COLS}
_top = sorted(_cnt, key=lambda k: (-_cnt[k], [c[0] for c in COLS].index(k)))[:3]
READCOV = (f"Reading it: the atlas is closest to the KTH notes ({_bs['K'].get('E', 0)} of {SRC_N['K']} rows have an exact counterpart, because the notes’ combinatorial algebra is the bit rule) and to the category notions we brought ({_bs['C'].get('E', 0)} of {SRC_N['C']} exact). "
           f"It is farthest from Majkić ({SRC_N['M']} rows, none exact or structural) and from the DG category of Tian (T.4 and T.5 are gaps: the atlas has no DG categories and no diagrammatics). "
           f"The atlas columns with the most cells are {', '.join(_short[k] + ' (' + str(_cnt[k]) + ')' for k in _top)}, which is where label 0 lives.")

TEMPLATE = r'''<!doctype html>
<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 -->
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Category Lens on the Atlas</title>
<meta name="description" content="Four attachments on Clifford algebras and categories read against the Cascade Atlas: what the label 0 is, one dimension at a time from the bottom, then from the top down through the lenses, with computed checks and questions for specialists.">
<style>%%CSS%%</style>
</head>
<body>
<header class="hero"><div class="wrap">
 <span class="kick">Category lens · %%TODAY%%</span>
 <h1>What is label 0, seen through categories?</h1>
 <p class="sub">Four attachments as background noise, the atlas as the instrument. First from the bottom up, one dimension at a time, asking what the label 0 is at each n; then from the top down through the lenses; then the questions a third party can check.</p>
 <div class="notice"><b>Preliminary.</b> The four attachments were read to the depth stated under Limits; no proof in them was re-derived. Every statement we call checked was recomputed on the bit rule (the algebra with one bit per generator, product by XOR, a sign, and squares −1, 0 or +1); the rest is marked standard, ours or open. Nothing here is a result about nature, and this report changes nothing in the webapp. Tags are the atlas’s: %%CHIPS%%</div>
 <div class="kpis">
  <div class="kpi"><b>%%NOK%%</b><span>checks pass, %%NBAD%% fail</span></div>
  <div class="kpi"><b>%%MUTOK%% of %%MUTALL%%</b><span>deliberate sabotages of the checks were caught (automated)</span></div>
  <div class="kpi"><b>%%NROWS%% × 22</b><span>notions × atlas columns, %%NCELLS%% filled cells</span></div>
  <div class="kpi"><b>%%NQ%%</b><span>questions for specialists, each with what was and was not checked</span></div>
 </div>
 <p class="lead"><b>In one paragraph.</b> Through categories the label 0 (a generator whose square is 0) is the one direction in which the label algebra is not invertible. Algebraically it spans the radical, of Loewy length r + 1, with the exterior algebra on the null generators as super-centre, and, among label-homogeneous gradings, it is exactly where the Z₂-grading lifts to Z (N1). The mod-8 clock of a degenerate cell is the clock of its quotient (and of its mother cell), and over its super-centre r is the base ring, not a class; the scalar-part trace does not see it; the complement-mask duality does, as a Frobenius pairing for every signature; ungraded, the algebra has a symmetric Frobenius form only for odd n or without null generators, so the 3D projective algebra is Frobenius but not symmetric, while in super vector spaces every cell is symmetric Frobenius (N2, N3). In the cube of labels the radical is a face when there is one null generator (for r ≥ 2 it is the complement of the face of labels without a null bit); in the category itself a null direction first appears at n = 3 in the symmetrised Euler form, %%E3%%, while the Tits form there is (6,1,1) (reading either as a label 0 is ours, QB4); from the top down the E_n ladder gets a null direction at E9 = Ẽ8, the null root, which E10 trades for a −1 (N7, N8). With three or more null generators and no other it cannot be peeled off by taking the even subalgebra (N5), and it is not the nilpotent generators of Tian’s algebra, which are paired nulls (N6). Of the four papers the KTH notes and Tian’s give exact links (the bit rule is the notes’ combinatorial Clifford algebra; Tian’s algebra is Cl(m,m) or Cl(m,m,1) with our sorting sign); Baez’s three pages give the clock and the three types as one count; Majkić’s construction does not survive as written but suggests a quiver-form reading that we compute. Of the %%NROWS%% rows of the matrix, %%BE%% have an exact counterpart, %%BS%% a structural one, %%BA%% an analogy, %%BG%% none. Nothing here contradicts an existing atlas statement; two refinements are named under Perspectives.</p>
</div></header>

<nav class="toc"><div class="wrap">
 <a href="#obj">Objectives</a><a href="#how">How I explored</a><a href="#papers">The papers</a><a href="#fig1">Fig. 1 map</a><a href="#up">Bottom up</a><a href="#down">Top down</a><a href="#findings">Findings</a><a href="#limits">Limits</a><a href="#persp">Perspectives</a><a href="#questions">Questions</a><a href="#checks">Checks</a><a href="#src">Sources</a>
 <button id="themebtn" type="button" aria-label="Switch colour theme">theme: auto</button>
</div></nav>

<main class="wrap">

<section id="obj"><h2>Objectives <small>what the request reduced to</small></h2>
 <div class="grid3">
  <div class="card"><h3>1 · Background noise</h3><p>State what each of the four papers sets out to do, in its own words and page numbers, and let that be the noise around the atlas’s own question, not the thing we test.</p></div>
  <div class="card"><h3>2 · Bottom up, then top down</h3><p>One dimension at a time from n = 0: what is the label 0 there? Then from the top: E11 down to E3, the lenses of the atlas, and the maps that go down and up the ladder.</p></div>
  <div class="card"><h3>3 · Questions to drill on</h3><p>Everything that is not computed turned into a question for a named kind of specialist, with what we checked and what we did not, so that a third party can attack each subject separately.</p></div>
 </div>
 <p>The papers’ own objectives, in one line each. <b>KTH notes:</b> a self-contained course on Clifford and geometric algebra. <b>Tenfold Way:</b> why there are ten kinds of super division algebra. <b>Tian:</b> a DG category whose Grothendieck group is a Z-form of the Clifford algebra. <b>Majkić:</b> to treat a category as a geometric object whose arrows are vectors. None of them asks what a generator with square 0 is; the atlas does.</p>
 <p>Ground rules kept: explore several views before choosing; quote the papers by the numbers printed in them; no address of any person appears in this report.</p>
</section>

<section id="how"><h2>How I explored <small>nine views, before choosing</small></h2>
 <div class="lens">%%LENSES%%</div>
</section>

<section id="papers"><h2>The four papers <small>what each says and what we computed</small></h2>
 <div class="papers">%%CARDS%%</div>
</section>

<section id="fig1"><h2>Fig. 1 · How they meet the atlas <small>one hub, four spokes and a lens</small></h2>
 <p class="lead">The letters on the edges are keyed to the list below. No paper cites another (by name search in the texts); the KTH notes thank Baez for correspondence. Every other edge goes through the atlas.</p>
 %%HUB%%
 %%RELLIST%%
</section>

<section id="up"><h2>Bottom up <small>one dimension at a time: what is label 0 now?</small></h2>
 <p class="lead">“Zero” means three different things in category language, and one symbol can stand for more than one of them. <b>The unit.</b> The empty bit string at n = 0 is the label of the unit object: 1 · 1 = 1 (L0). <b>The zero object or zero morphism.</b> Not used: the null generator is not the element 0, since e ≠ 0 and the arrow ∅ → {i} of the cube is non-zero. <b>The nilpotent.</b> A generator with e² = 0 and e ≠ 0: this is the label 0 of the trio −1, 0, +1, and the one this report is about.</p>
 %%LADDERFIG%%
 <div class="card" style="margin-top:14px"><div style="overflow-x:auto"><table class="tabsm"><thead><tr><th>n</th><th>what exists</th><th>what label 0 is here</th><th>what first appears</th><th>checks</th></tr></thead><tbody>%%LADDERROWS%%</tbody></table></div></div>
 <div class="answer"><h3>So, what is label 0 now?</h3>
  <p>Not the empty label, which is the unit. It is the <b>non-invertible direction</b> of the label algebra, and it has four faces that the ladder shows one at a time.</p>
  <ul class="tight">
   <li><b>As algebra:</b> it spans the radical (Loewy length r + 1), its super-centre is the exterior algebra on the null generators, and, among label-homogeneous gradings, it is where the Z₂-grading lifts to an additive integer degree (N1).</li>
   <li><b>As geometry:</b> with one null generator the radical is a face of the cube of labels, the half that contains the null bit, and the other half carries the ordinary algebra (figure above); with r ≥ 2 null generators it is the set of labels with at least one null bit, the complement of the face of labels with none.</li>
   <li><b>As category:</b> a null direction first appears inside the cube category at n = 3, in its symmetrised Euler form (the Tits form there is (6,1,1)); from the top, E9 has the null root (N7, N8). Reading these null directions as label 0 is ours (QB4, QD1).</li>
   <li><b>As duality:</b> the clock of a degenerate cell is the clock of its quotient, and the scalar-part trace does not see the null labels, nor does any state (N10); the complement-mask pairing does; for even n the pairing is Frobenius but not symmetric, and in super vector spaces it is super-symmetric for every n (N2, N3).</li>
  </ul>
  <p>It is not the nilpotent generators of Tian’s algebra (those are paired nulls, N6), and, with three or more null generators and no other, it cannot be removed by passing to the even subalgebra (N5). Every one of these is a computed statement with a check id; what it means for physics is not claimed.</p></div>
</section>

<section id="down"><h2>Top down <small>the same ladder from the largest object, through all our lenses</small></h2>
 <p class="lead">Start at the top of what the atlas can see: the E<sub>n</sub> series and the algebras Cl(n,0) up to Cl(8,0). Each rung has a signature (positive, negative, null); stepping down removes a generator, and the question is again where the 0 sits.</p>
 %%SIGFIG%%
 <p>Read from the top: E10 and E11 have one −1 (Lorentzian forms on the root lattice, not spacetimes); E9, the affine rung, has a 0 instead, the null root; E8 and below are positive definite and carry the quadric geometry of N9. det = 9 − n is 0 only at n = 9 (Q2). The symmetrised Euler form of the cube category of the bottom-up pass goes definite, a null direction at n = 3, indefinite; its Tits form at n = 3 is (6,1,1) (T8). Whether the two sequences have anything in common is what the questions QB4 and QD1 ask; we do not claim a pattern.</p>
 <h3 style="margin-top:18px">The way down, and the way up</h3>
 <p>Between the rungs the atlas has four moves (N5). Doubling by the graded product works for every square. Halving by the even subalgebra needs one invertible generator; with only null generators it still works for one or two of them and fails from three on (T5 (d)). Projecting onto the face of labels without a null bit is the quotient by the radical. The complement mask is a Frobenius duality at every rung (N3). That is the whole “category” content that survived: three maps and a duality, each with a computed check, and one place where a map fails. The maps are Cl applied to maps of quadratic spaces, halving is a natural isomorphism, and the duality is the Frobenius structure of each algebra (N5).</p>
 <h3 style="margin-top:18px">Fig. 7 · All the lenses at once <small>%%NROWS%% rows × 22 atlas columns</small></h3>
 <p class="lead">Each row is a notion from one of the four papers or from the category lens; each column is an atlas page or step (the same 22 as in the Schuller and Baez matrices). Hover or focus a cell for what matches. Row ids are written K.1, T.3, C.7 … with a dot, to tell them from the check ids K1a, T3 and C1. A row with no cell is a gap.</p>
 <div class="legend"><span><i class="sw g-E">E</i> exact: same object or identity, computed</span><span><i class="sw g-S">S</i> structural: same structure, other generality, or a standard fact</span><span><i class="sw g-A">A</i> analogy: our reading, not computed as the same</span><span><i class="sw gapsw">–</i> no cell: nothing in the atlas</span></div>
 %%MATRIX%%
 <h3 style="margin-top:18px">Fig. 8 · Coverage</h3>
 %%COVER%%
 <p>%%READCOV%%</p>
</section>

<section id="findings"><h2>Findings <small>each with its tags and check ids</small></h2>
%%FINDINGS%%
</section>

<section id="limits"><h2>Dead ends and honest limits</h2>
 <div class="grid2">
  <div class="card"><h3>Dead ends</h3><ul class="tight">%%DEAD%%</ul></div>
  <div class="card"><h3>What I did not do or verify</h3><ul class="tight">%%LIMS%%</ul></div>
 </div>
</section>

<section id="persp"><h2>Perspectives for the atlas <small>all proposals; this report changes nothing in the webapp</small></h2>
 <div class="grid2">
  <div class="card"><h3>P1 · A card for label 0 %%C_CHK%% %%C_STD%%</h3><p>One page of the atlas that says what the null generator is, with the radical (a face of the cube when there is one null generator), the Loewy length, the super-centre, the grading lift and the two kinds of null (N1, N5). It would sit with the null surfaces and the projective steps. All checked; recalled facts are marked.</p></div>
  <div class="card"><h3>P2 · The complement mask as a Frobenius duality %%C_CHK%%</h3><p>Where the atlas uses the complement mask (the signed complement of the Forque rows, the Hodge-type statements of the null self-check), say that it is a Frobenius pairing for every signature, that a metric Hodge star needs an invertible pseudoscalar, and that for even n with a null generator the Nakayama twist is the grade involution (N3). On the pages searched no wording needs to change (the Forque rows already read “signed complement”); not every page was read.</p></div>
  <div class="card"><h3>P3 · A page for the four moves %%C_CHK%% %%C_OURS%%</h3><p>Double, halve, face, complement, with the one arrow that fails for a pure label 0 (N5). It would tie steps 3, 5 and 16 together. The reading of the cube as a category is ours; the checks are exact.</p></div>
  <div class="card"><h3>P4 · The top of the ladder %%C_CHK%% %%C_OURS%%</h3><p>A short extension of the Gosset page with E9, E10 and E11 as signatures (8,0,1), (9,1,0), (10,1,0), the null root, and the mod-2 table of N8. “det = 9 − n is 0 only at n = 9, the only rung with a null direction” is checked; calling it a boundary between the definite and the Lorentzian rungs stays ours, and the Lorentzian rungs are forms on a lattice, not spacetimes.</p></div>
  <div class="card"><h3>P5 · Two refinements, not drastic %%C_CHK%%</h3><p>(1) “Null” has two meanings in the atlas’s own pages, and step 13 has both: the horizon vector e<sub>t</sub> − e<sub>r</sub> in the ambient (t,r) plane is a paired null of the non-degenerate Cl(1,1), not a label 0, while the tangent algebra Cl(0,n−2,1) of the null hypersurface has an unpaired null, its radical (T18); the projective generator of step 11 is unpaired (its image in the conformal algebra is f⁺ − f⁻). (2) The even-subalgebra step of the spinor page needs an invertible generator. Neither (1) nor (2) contradicts an existing statement; each makes one of them more exact.</p></div>
  <div class="card"><h3>P6 · What not to add %%C_OPEN%%</h3><p>Majkić’s construction in version 2 and the DG category of Tian stay in the report, not in the webapp: the first fails as written and the second has no counterpart in the atlas. Which of the ten symmetry classes of matter sits at which clock value stays a question (QC3).</p></div>
 </div>
</section>




<section id="questions"><h2>Questions for specialists <small>%%NQ%% questions in five groups; each says what was checked and what was not</small></h2>
 <p class="lead">Each card can be sent alone. “Ask” names the kind of reader who could settle it; “checked” is what a script computed and where; “not checked” is what the answer would have to supply. The last group takes up the “Next, in order” section of the Schuller report, with its status:</p>
 <div class="card"><div style="overflow-x:auto"><table class="tabsm"><thead><tr><th>Item</th><th>As written there</th><th>Status here</th></tr></thead><tbody>%%NEXTROWS%%</tbody></table></div></div>
 %%QUESTIONS%%
</section>

<section id="checks"><h2>Checks <small>%%NOK%% pass, %%NBAD%% fail</small></h2>
 <div class="grid2">
  <div class="card"><div style="overflow-x:auto"><table><thead><tr><th>Block</th><th>What it tests</th><th class="num">Checks</th></tr></thead><tbody>%%CHECKS%%<tr><td></td><td><b>Total</b></td><td class="num"><b>%%NOK%%</b></td></tr></tbody></table></div></div>
  <div class="card"><h3>Sabotage test</h3><p>Each check was run against a deliberately wrong version (a flipped sign, a swapped formula, a wrong count, a wrong reading of the diagram). One place is changed in a temporary copy of the script and the named check must fail; a crash or a timeout does not count as caught: <b>%%MUTOK%% of %%MUTALL%%</b> were caught, automated in <code>mutate_cat.py</code>.</p>
   <details class="tv"><summary>The %%MUTALL%% sabotages</summary><div class="tvscroll"><table><tbody>%%MUTS%%</tbody></table></div></details>
   <h3 style="margin-top:12px">Rerun</h3><pre>cd reports/category
python3 cat_check.py --write &gt; logs/cat_check.log   # the %%NOK%% checks (--write: cat_results.json here)
python3 mutate_cat.py &gt; logs/mutation_cat.log   # automated sabotage
python3 build_report_cat.py              # this page, into ../html/</pre><p style="font-size:13px;color:var(--muted)">Needs the atlas package this folder ships in (two folders up; or set <code>ATLAS_PKG</code>), Python 3, numpy. Every number on this page is read from the logs, the data file written by the check script, or the matrix data.</p></div>
 </div>
</section>

<section id="src"><h2>Sources</h2>
 <ul class="tight">
  <li>D. Lundholm, L. Svensson, <i>Clifford algebra, geometric algebra, and applications</i>, lecture notes, KTH, rev. 7 June 2016. (Attached; read in the parts named under Limits.)</li>
  <li>J. C. Baez, <i>The Tenfold Way</i>, <a href="https://arxiv.org/abs/2011.14234">arXiv:2011.14234</a>, 1 December 2020. (Attached.) It cites C. T. C. Wall, <i>Graded Brauer groups</i>, J. reine angew. Math. 213 (1964); F. Dyson, J. Math. Phys. 3 (1962); D. Freed, G. Moore, <a href="https://arxiv.org/abs/1208.5055">arXiv:1208.5055</a>; Deligne–Morgan; Trimble. (Not read here.)</li>
  <li>Y. Tian, <i>A diagrammatic categorification of a Clifford algebra</i>, <a href="https://arxiv.org/abs/1309.6049">arXiv:1309.6049</a> v1, 24 September 2013. (Attached.)</li>
  <li>Z. Majkić, <i>Categorial Geometry and Algebraic Topology</i>, <a href="https://arxiv.org/abs/2403.19689">arXiv:2403.19689</a> v2, 22 March 2026. (Attached; the parts that define the Cat-arrows space.)</li>
  <li>The Schuller bridge report, section “Next, in order” (the items answered in the last group of questions) and the Baez report, from which the 22 atlas columns are taken.</li>
  <li>Standard facts used from memory, not fetched from a source (recalled): Wall’s theorem and BW(R) = Z₈, Gabriel’s theorem, representation type of exterior algebras, Kac–Moody names for E9–E11, the classification of quadratic spaces over F₂, Gauss–Milgram, the cochain-twist form of the octonions, derived equivalences of incidence algebras, the Peres–Mermin square.</li>
  <li>The theorems of the page For researchers of the atlas (T2, T3, T4, T5, T8, T9, T10, T11, T15 and T18 are cited here), each with its check script in <code>researchers_checks/</code> and its verification status on that page: they prove for every n what the scripts of this report check for small n.</li>
  <li>The atlas package (steps 1–17, <code>bitcliff.py</code>).</li>
 </ul>
</section>
</main>
<footer><div class="wrap">Cascade Atlas · preliminary report, %%TODAY%% · generated by <code>build_report_cat.py</code> from the logs, the data file and the matrix data. Not a theory of nature: a set of checks and readings.</div></footer>
<div id="tip" role="tooltip"></div>
<script>%%JS%%</script>
</body></html>
'''
out = TEMPLATE
rep = {'%%CSS%%': CSS, '%%JS%%': JS, '%%TODAY%%': TODAY, '%%CHIPS%%': CHIPS, '%%NOK%%': str(OK), '%%NBAD%%': str(BAD), '%%MUTOK%%': str(MUT_OK), '%%MUTALL%%': str(MUT_ALL),
       '%%NROWS%%': str(nrows), '%%NCELLS%%': str(ncells), '%%NQ%%': str(NQ), '%%BE%%': str(bE), '%%BS%%': str(bS), '%%BA%%': str(bA), '%%BG%%': str(bG), '%%E3%%': sg(Ed['3']),
       '%%LENSES%%': LENS_HTML, '%%CARDS%%': CARDS, '%%HUB%%': wrap_sv(FG.hub_svg()), '%%RELLIST%%': REL_HTML,
       '%%LADDERFIG%%': fig('Fig. 2 · The cube of labels for n = 0…4', FG.ladder_svg(R), 'One null generator is chosen (the last bit); the highlighted labels contain it and span the radical. Hover a label or read the table.'),
       '%%LADDERROWS%%': LADDER_ROWS,
       '%%SIGFIG%%': fig('Fig. 5 · Signatures: E_n, the cube category and the Majkić atoms', FG.sigbars_svg(R, SIGE), 'Each bar is a form on that many dimensions, split into positive, negative and null directions. The yellow part is the null directions (reading them as a label 0 is ours).') + '<div style="margin-top:14px">' + T_TOP + '</div>',
       '%%READCOV%%': READCOV, '%%MATRIX%%': MATRIX, '%%COVER%%': COVER, '%%FINDINGS%%': FINDINGS, '%%DEAD%%': DEAD, '%%LIMS%%': LIMS, '%%NEXTROWS%%': NEXT_ROWS, '%%QUESTIONS%%': questions_html(),
       '%%CHECKS%%': T_CHK, '%%MUTS%%': T_MUT,
       '%%C_OURS%%': chip('ours'), '%%C_CHK%%': chip('checked'), '%%C_OPEN%%': chip('open'), '%%C_STD%%': chip('standard')}
for k, v in rep.items(): out = out.replace(k, v)
assert out.count('<body>') == 1; out = out.replace('<body>', '<body>\n' + SC.SPRITE, 1)      # the five icons, once
assert '%%' not in out, re.findall(r'%%\w+%%', out)
assert not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', out, flags=re.S)), 'an e-mail address is in the page'
path = os.path.join(HERE, '..', 'html', 'category_atlas_report.html'); os.makedirs(os.path.dirname(path), exist_ok=True)   # the shipped page lives in reports/html/
open(path, 'w', encoding='utf-8').write(out)
print('wrote', path, len(out), 'bytes;', f'checks {OK}, mutants {MUT_OK}/{MUT_ALL}, rows {nrows}, cells {ncells}, best E/S/A/gap {bE}/{bS}/{bA}/{bG}, questions {NQ}')
