#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Automated sabotage test for cat_check.py: each mutant changes one expression of a temporary copy; the run must FAIL the named check (a crash does not count as caught).
Python standard library only.   Run: python3 mutate_cat.py   (a few minutes; three mutants run at a time)"""
import os, sys, subprocess, tempfile, re
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, 'cat_check.py')).read()
M = [
 ('M1  S1: a spurious sign on some triples in the associativity test', "bad += (s1 * s2 != t1 * t2)", "bad += (s1 * s2 != t1 * t2 * (1 - 2 * (a & b & c & 1)))", 'S1'),
 ('M2  L0: the empty label squares to -1', "A0.blade_mul(0, 0) == (1, 0)", "A0.blade_mul(0, 0) == (-1, 0)", 'L0'),
 ('M3  L1a: norm form a^2 + eps b^2', "ok &= det == a_ * a_ - eps * b_ * b_", "ok &= det == a_ * a_ + eps * b_ * b_", 'L1a'),
 ('M4  L1b: unit count (p-1)(p+chi)', "ok &= nu == (p - 1) * (p - chi)", "ok &= nu == (p - 1) * (p + chi)", 'L1b'),
 ('M5  R1: the first null generator is left out of the radical', "nullset = [i for i in range(n) if A.eps[i] == 0]", "nullset = [i for i in range(n) if A.eps[i] == 0 and i > 0]", 'R1'),
 ('M6  R2: first layer of the radical miscounted', "layers = []; cur = set(radb)", "layers = []; cur = set(radb[1:])", 'R2'),
 ('M7  R3: wrong super-commutation sign', "row[k] = s1 - sg * s2", "row[k] = s1 + sg * s2", 'R3'),
 ('M8  R4: centre dimensions swapped', "TAB[(p, q, 0)]['centre'] == (1 if (p + q) % 2 == 0 else 2)", "TAB[(p, q, 0)]['centre'] == (2 if (p + q) % 2 == 0 else 1)", 'R4'),
 ('M9  G1: zero products also impose relations', "            if A.blade_mul(a, b)[0] != 0:\n                row = [0] * N; row[a] += 1", "            if True:\n                row = [0] * N; row[a] += 1", 'G1'),
 ('M10 F1: pairing taken against the complement shifted by one bit', "if s and c == F: G[a][b] = s", "if s and c == F ^ 1: G[a][b] = s", 'F1'),
 ('M11 F2: Nakayama sign without the (n - |b|) factor', "ratio_ok &= chi == (-1) ** (pc(b) * (n - pc(b)))", "ratio_ok &= chi == (-1) ** pc(b)", 'F2'),
 ('M12 F3: symmetric iff n odd (drops r = 0)', "bad_sym = [k for k, v in FR.items() if v['symmetric'] != (v['n'] % 2 == 1 or k[2] == 0)]", "bad_sym = [k for k, v in FR.items() if v['symmetric'] != (v['n'] % 2 == 1)]", 'F3'),
 ('M13 F4: scalar-part pairing replaced by a pairing on the two lowest labels', "G0 = [[(A.blade_mul(a, b)[0] if a == b else 0) for b in range(N)] for a in range(N)]", "G0 = [[(A.blade_mul(a, b)[0] if a ^ b in (0, 1) else 0) for b in range(N)] for a in range(N)]", 'F4'),
 ('M14 K1a: squares commute instead of anticommute', "jw(a, i) * jw(a | (1 << i), j) * jw(a, j) * jw(a | (1 << j), i) == -1", "jw(a, i) * jw(a | (1 << i), j) * jw(a, j) * jw(a | (1 << j), i) == 1", 'K1a'),
 ('M15 K1b: right instead of left multiplication', "ok &= A.blade_mul(1 << i, a)[0] == jw(a, i)", "ok &= A.blade_mul(a, 1 << i)[0] == jw(a, i)", 'K1b'),
 ('M16 K1c: a square condition with three edges only', "| (1 << eid[(a, j)]) | (1 << eid[(a | (1 << j), i)]))", "| (1 << eid[(a, j)]))", 'K1c'),
 ('M17 K1d: wrong number of assignments expected', "sols == 2 ** 7 == 128", "sols == 2 ** 7 == 127", 'K1d'),
 ('M18 K1e: boundary without signs', "D[a ^ (1 << i)][a] = jw(a ^ (1 << i), i)", "D[a ^ (1 << i)][a] = 1", 'K1e'),
 ('M19 K2a: coboundaries counted without the homomorphisms', "dB = (1 << n) - 1 - n", "dB = (1 << n) - 1", 'K2a'),
 ('M20 K2b: commutator invariant inverted', "(A.blade_mul(1 << i, 1 << j)[0] != A.blade_mul(1 << j, 1 << i)[0]) for i in range(3) for j in range(i + 1, 3)", "(A.blade_mul(1 << i, 1 << j)[0] == A.blade_mul(1 << j, 1 << i)[0]) for i in range(3) for j in range(i + 1, 3)", 'K2b'),
 ('M21 K3a: associator sign inverted', "PHI[t] == (-1) ** det2(*t)", "PHI[t] == (-1) ** (1 - det2(*t))", 'K3a'),
 ('M22 K3b: coboundary formula with a wrong argument', "OCT[(b, c)][0] * OCT[(a ^ b, c)][0] * OCT[(a, b ^ c)][0] * OCT[(a, b)][0] == PHI[(a, b, c)]", "OCT[(b, c)][0] * OCT[(a, c)][0] * OCT[(a, b ^ c)][0] * OCT[(a, b)][0] == PHI[(a, b, c)]", 'K3b'),
 ('M23 K4a: Gauss sum with the conjugate imaginary table', "im_ + (0, 1, 0, -1)[k]", "im_ + (0, -1, 0, 1)[k]", 'K4a'),
 ('M24 K4b: number of simple factors read from the wrong sign', "f = 2 if (n % 2 == 1 and A.sq((1 << n) - 1) == 1) else 1", "f = 2 if (n % 2 == 1 and A.sq((1 << n) - 1) == -1) else 1", 'K4b'),
 ('M25 K4c: closed form with the phase shifted', "math.cos((p - q - 1) * math.pi / 4)", "math.cos((p - q + 1) * math.pi / 4)", 'K4c'),
 ('M26 K5a: Koszul sign with the wrong pair of degrees', "exp = (-1) ** (pc(b1) * pc(a2)) * s_1 * s_2", "exp = (-1) ** (pc(a1) * pc(b2)) * s_1 * s_2", 'K5a'),
 ('M27 K5b: even subalgebra without the sign twist', "B = Alg(tuple(-s * A.eps[i] if A.eps[i] != 0 else 0 for i in others))", "B = Alg(tuple(s * A.eps[i] if A.eps[i] != 0 else 0 for i in others))", 'K5b'),
 ('M28 T1: annihilation part with a relative minus sign', "a[2 * j - 1] = annih(j) + annih(j - 1)", "a[2 * j - 1] = annih(j) - annih(j - 1)", 'T1'),
 ('M29 T2: radical vector without alternating signs', "rr = sum(((-1) ** k) * a[2 * k + 1] for k in range(n))", "rr = sum(a[2 * k + 1] for k in range(n))", 'T2'),
 ('M30 T3: determinant of the path form without the sign', "(0 if k % 2 else (-1) ** (k // 2))", "(0 if k % 2 else 1)", 'T3'),
 ('M31 T4: generators ordered +1, 0, -1 instead of +1, -1, 0', "key=lambda t: {1: 0, -1: 1, 0: 2}[eps[t]]", "key=lambda t: {1: 0, 0: 1, -1: 2}[eps[t]]", 'T4'),
 ('M32 M1: null generator 2 f+ - f- (square 3, not 0)', "{1 << (p + k): 1, 1 << (p + r + q + k): -1}", "{1 << (p + k): 2, 1 << (p + r + q + k): -1}", 'M1'),
 ('M33 M2: anticommutator of the null pair', "A11.add(A11.mul(u, v), A11.mul(v, u)) == {0: 4}", "A11.add(A11.mul(u, v), A11.mul(v, u)) == {0: 2}", 'M2'),
 ('M34 W1: split rank without the number of simple factors', "    return f * Nn\n", "    return Nn\n", 'W1'),
 ('M35 W2: commutation form inverted', "Bf = [[0 if A.comm_sign(a, b) == 1 else 1 for b in range(N)] for a in range(N)]", "Bf = [[0 if A.comm_sign(a, b) == -1 else 1 for b in range(N)] for a in range(N)]", 'W2'),
 ('M36 W3: family parity taken mod 3', "parity = lambda S, T: (4 - int(math.log2(len(S & T)))) % 2", "parity = lambda S, T: (4 - int(math.log2(len(S & T)))) % 3", 'W3'),
 ('M49 K5c: a swap over a gap larger than 3 counted twice', "if L[k] > L[k + 1]: L[k], L[k + 1] = L[k + 1], L[k]; sw += 1; done = False", "if L[k] > L[k + 1]: sw += 1 + (L[k] - L[k + 1] > 3); L[k], L[k + 1] = L[k + 1], L[k]; done = False", 'K5c'),
 ('M37 Q1: the extended A3 diagram drawn as an open path', "def cycle(n): return n, [(i, (i + 1) % n) for i in range(n)]", "def cycle(n): return n, [(i, i + 1) for i in range(n - 1)]", 'Q1'),
 ('M38 Q2: determinant formula 8 - n', "det_ok &= (d == 9 - n) if n >= 4", "det_ok &= (d == 8 - n) if n >= 4", 'Q2'),
 ('M39 Q3: reflection with the wrong sign', "y = list(x); y[i] -= c; y = tuple(y)", "y = list(x); y[i] += c; y = tuple(y)", 'Q3'),
 ('M40 Q4: Gauss-Milgram with exp(2 pi i x.x)', "complex(math.cos(math.pi * float(nm)), math.sin(math.pi * float(nm)))", "complex(math.cos(2 * math.pi * float(nm)), math.sin(2 * math.pi * float(nm)))", 'Q4'),
 ('M41 Q5: quadratic form without the factor 1/2', "val = sum(v[i] * C[i][j] * v[j] for i in range(nd) for j in range(nd)) // 2", "val = sum(v[i] * C[i][j] * v[j] for i in range(nd) for j in range(nd)) // 1", 'Q5'),
 ('M42 E1: Moebius factor [[1,-2],[0,1]] instead of [[1,-1],[0,1]]', "M_ = kron(M_, Uu) if True else M_", "M_ = kron(M_, [[1, -2], [0, 1]])", 'E1'),
 ('M43 J1: composability read as same domain', "comp = lambda f, g: f[1] == g[0]", "comp = lambda f, g: f[0] == g[0]", 'J1'),
 ('M44 J2: additivity test compares a quantity with itself', "if sum(dot(x, y) for x in decomp(f) for y in decomp(g)) != dot(f, g): bad += 1", "if sum(dot(x, y) for x in decomp(f) for y in decomp(g)) != sum(dot(x, y) for x in decomp(f) for y in decomp(g)): bad += 1", 'J2'),
 ('M45 J3: Gram matrix without the composability entries', "G = [[2 if f == g else (1 if (comp(f, g) or comp(g, f)) else 0) for g in atoms] for f in atoms]", "G = [[2 if f == g else 0 for g in atoms] for f in atoms]", 'J3'),
 ('M46 B1: commutator instead of anticommutator for the odd pair', "sc = a[i] @ a[j].T + a[j].T @ a[i]; ok &=", "sc = a[i] @ a[j].T - a[j].T @ a[i]; ok &=", 'B1'),
 ('M47 C1: the eight classes read one step further', "p, q = c + 1, 1 ", "p, q = c + 2, 1 ", 'C1'),
 ('M48 C2: probability (1 - v.u)/2', "okb &= prob == (1 + sum(a * b for a, b in zip(u, v))) / 2", "okb &= prob == (1 - sum(a * b for a, b in zip(u, v))) / 2", 'C2'),
 # M50 to M54: sabotages of K4c, G2, F5 and C3
 ('M50 K4c: the type read from the real part of the Gauss sum alone', "okc_sum = all(fs(p, q)[1] == gauss(p, q)[0] + gauss(p, q)[1] for p in range(9) for q in range(9 - p))", "okc_sum = all(fs(p, q)[1] == gauss(p, q)[0] for p in range(9) for q in range(9 - p))", 'K4c'),
 ('M51 G2: every grading has free rank r, the sentence without the qualifier', "rank_mu == 1 and GR[(2, 0, 0)] == 0", "rank_mu == GR[(2, 0, 0)]", 'G2'),
 ('M52 F5: Frobenius forms as a torsor under the central units', "tor_ok &= (nd == unit)  ", "tor_ok &= (nd == (unit and central))  ", 'F5'),
 ('M53 C3: the top-blade form taken for a positive hermitian functional, a state', "st_ok &= GL[0, 0] == 0 and (not herm or np.linalg.eigvalsh(GL).min() < -1e-9)", "st_ok &= GL[0, 0] == 0 and (herm and np.linalg.eigvalsh(GL).min() >= -1e-9)", 'C3'),
 ('M54 C3: a hermitian functional on the radical taken to keep positivity, a state that sees label 0', "np.linalg.eigvalsh(Gt).min() < -1e-9", "np.linalg.eigvalsh(Gt).min() >= -1e-9", 'C3'),
]
import concurrent.futures as cf
def run_one(m):
    name, old, new, cid = m
    if SRC.count(old) != 1:
        return False, f'ERROR {name}: pattern found {SRC.count(old)} times'
    code = SRC.replace(old, new)
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, 'cat_check.py'); open(path, 'w').write(code)
        env = dict(os.environ); env['ATLAS_PKG'] = os.environ.get('ATLAS_PKG', os.path.abspath(os.path.join(HERE, '..', '..')))   # the package this folder ships in
        try:
            r = subprocess.run([sys.executable, path], capture_output=True, text=True, env=env, timeout=200)
        except subprocess.TimeoutExpired:
            return False, f'TIMEOUT {name}  -> no verdict within 200 s (a hang is not a caught mutant)'
    failed = re.findall(r'^FAIL (\w+):', r.stdout, re.M)
    crash = r.returncode != 0 and 'Traceback' in r.stderr
    hit = cid in failed
    return hit, f"{'caught' if hit else 'MISSED'}  {name}  -> failing: {','.join(failed) or '-'}{'  (crash)' if crash else ''}"
with cf.ThreadPoolExecutor(max_workers=3) as ex:
    results = list(ex.map(run_one, M))
caught = sum(1 for h, _ in results if h); lines = [l for _, l in results]
for l in lines: print(l)
print(f'mutants caught: {caught} of {len(M)}')
sys.exit(0 if caught == len(M) else 1)
