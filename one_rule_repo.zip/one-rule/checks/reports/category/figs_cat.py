# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""SVG figures of the category-lens report.  Every number drawn is read from cat_results.json (written by cat_check.py) or recomputed here from the bit rule (bitcliff); none is typed by hand."""
import math, html, itertools
E = html.escape


def tip(*lines):
    return E('\n'.join(lines), quote=True)


def key(p, q, r): return f'{p},{q},{r}'


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# Fig. 1  the four papers, the category notions I brought, and the atlas
# ------------------------------------------------------------------------------------------------------------------------------------------------------
NODES = {  # key: (line 1, line 2, line 3, centre)
    'K': ('Lundholm–Svensson', 'Clifford algebra, geometric', 'algebra and applications · KTH', (125, 78)),
    'W': ('Baez · The tenfold way', 'Wall, Dyson, Schur: R, C, H', 'and the ten super division algebras', (755, 78)),
    'T': ('Tian · diagrammatic', 'categorification of a', 'Clifford algebra · arXiv:1309.6049', (125, 392)),
    'M': ('Majkić · Categorial geometry', 'and algebraic topology', 'arrows of a category as vectors', (755, 392)),
    'C': ('Category notions I brought', 'cube category, cochains, Frobenius,', 'quiver forms (ours, standard words)', (440, 440)),
    'A': ('The atlas', 'bit labels, XOR, sign;', 'the trio of squares −1, 0, +1', (440, 235)),
}
# kind: cite (a citation or an acknowledgement found in the text), chk (computed), our (our reading), opn (open or dead end)
EDGES = [
    ('a', 'A', 'K', 'chk', 'The combinatorial Clifford algebra Cl(X,R,r) of Sect. 2.2 (pp. 13–17) is the bit rule; signature value 0 is allowed (p. 10, 81–82); the mother algebra of Sect. 5.3 (p. 62) writes a null generator as f⁺ − f⁻. Computed: S1, R1–R3, K5a, M1, M2.'),
    ('b', 'A', 'W', 'chk', 'The mod-8 clock and the three types R, C, H (Schur’s lemma) come out of the squares of the labels as a Gauss sum and a Frobenius–Schur indicator; ungraded 5 types, graded 8 (K4a–c, C1). That the ten super division algebras (here: the eight clock values and the two complex ones) correspond to the ten symmetry classes of free-fermion matter is stated in Baez’s paper (standard, quoted; not computed here); which class sits at which clock value is open.'),
    ('c', 'A', 'T', 'chk', 'Tian’s Z-algebra with aᵢ² = 0 and aᵢaᵢ₊₁ + aᵢ₊₁aᵢ = 1 is, over R, the Clifford algebra Cl(m,m) or Cl(m,m,1) of the atlas in a hyperbolic basis; the nilpotent aᵢ are paired nulls, not label 0; the sorting sign of the paper (Lemma 4.20) is the bit-rule sign (T1–T4, K5c).'),
    ('d', 'A', 'M', 'opn', 'As written the construction is not a Clifford algebra of a vector space (the inner product is not additive along composition; the two Clifford properties hold by definition): J1, J2. A constructive reading by a quiver form (Gram 2 on the diagonal, 1 on composable atoms) is ours: signatures (4,0,0), (11,0,1), (26,4,2) (J3).'),
    ('e', 'A', 'C', 'chk', 'The cube of labels as a category with the Jordan–Wigner sign (unique up to gauge), H² = quadratic forms, the octonion cochain, the Frobenius duality, radical and Loewy series of label 0, Dynkin and E_n forms (K1–K3, F1–F4, R1–R4, Q1–Q5, E1, W1–W3).'),
    ('f', 'K', 'W', 'cite', 'The KTH notes thank Baez “for helpful correspondence concerning division algebras” (acknowledgements); Table 5.1 (p. 58) and the Brauer–Wall clock are the same classification. No citation between the four papers was found by name search in the texts.'),
    ('g', 'K', 'T', 'our', 'Both realise the exterior algebra on the labels as a Fock space: the notes in Sect. 4.3 and 8.2 (creation = wedge, annihilation = contraction), Tian in Sect. 3 (faithful module V of Cl_Z). Our reading of the common structure.'),
    ('h', 'T', 'M', 'our', 'Both put a category around a Clifford algebra: Tian’s DG category CL has K0 = Cl_Z; Majkić takes the arrows of a category as vectors. The first is a theorem of the paper, the second is not (d).'),
]


def hub_svg():
    W, H = 880, 486; bw, bh = 214, 66
    pos = {k: v[3] for k, v in NODES.items()}
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The four papers, the category notions brought in and the atlas as nodes; edges are computed links, our readings, citations and open questions" class="chart">']
    def border(a, b):
        x0, y0 = pos[a]; x1, y1 = pos[b]; dx, dy = x1 - x0, y1 - y0
        t = min((bw / 2 + 3) / abs(dx) if dx else 1e9, (bh / 2 + 3) / abs(dy) if dy else 1e9)
        return x0 + dx * t, y0 + dy * t
    mids = {}
    for lab, a, b, kind, txt in EDGES:
        x0, y0 = border(a, b); x1, y1 = border(b, a); mids[lab] = ((x0 + x1) / 2, (y0 + y1) / 2)
        parts.append(f'<line x1="{x0:.1f}" y1="{y0:.1f}" x2="{x1:.1f}" y2="{y1:.1f}" class="ed {kind}" data-tip="{tip(lab + ": " + NODES[a][0] + " / " + NODES[b][0], txt)}" tabindex="0"/>')
    for k, (l1, l2, l3, (x, y)) in NODES.items():
        cls = 'nd ex' if k == 'A' else ('nd iso' if k == 'C' else 'nd')
        t = {'A': 'the atlas: bit labels with XOR and a sign; the trio of squares', 'C': 'standard categorical language, used by us as a lens; not from one paper'}.get(k, 'paper attached to the request')
        parts.append(f'<g class="{cls}" data-tip="{tip(l1 + " · " + l2 + " " + l3, t)}" tabindex="0"><rect x="{x - bw / 2:.1f}" y="{y - bh / 2:.1f}" width="{bw}" height="{bh}" rx="9"/>'
                     f'<text x="{x}" y="{y - 12}" text-anchor="middle" class="tt">{E(l1)}</text><text x="{x}" y="{y + 4}" text-anchor="middle" class="ss">{E(l2)}</text><text x="{x}" y="{y + 20}" text-anchor="middle" class="ss">{E(l3)}</text></g>')
    for lab, a, b, kind, txt in EDGES:
        mx, my = mids[lab]
        parts.append(f'<g data-tip="{tip(lab + ": " + NODES[a][0] + " / " + NODES[b][0], txt)}" tabindex="0"><circle cx="{mx:.1f}" cy="{my:.1f}" r="12" class="bd"/><text x="{mx:.1f}" y="{my + 4.5:.1f}" text-anchor="middle" class="bdt">{lab}</text></g>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="36" y2="5" class="ed cite"/></svg> a thank-you or citation found in the text</span>'
           '<span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="36" y2="5" class="ed chk"/></svg> link we computed</span>'
           '<span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="36" y2="5" class="ed our"/></svg> our reading</span>'
           '<span><svg width="38" height="10" aria-hidden="true"><line x1="0" y1="5" x2="36" y2="5" class="ed opn"/></svg> dead end as written, open</span>'
           '<span><svg width="26" height="16" aria-hidden="true"><rect x="2" y="2" width="22" height="12" rx="3" class="legex"/></svg> the atlas</span></div>')
    return ''.join(parts) + leg


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# Fig. 2  bottom-up: the cube of labels for n = 0 .. 4 with the null bit highlighted
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def _cube_points(n):
    vs = [(46, 0), (0, -46), (24, -22)]
    def p3(m): return (sum(v[0] for i, v in enumerate(vs) if m >> i & 1), sum(v[1] for i, v in enumerate(vs) if m >> i & 1))
    if n <= 3:
        return [p3(m) for m in range(1 << n)]
    sc, dx, dy = 0.7, 12, 82                                 # n = 4: two cubes, the lower without the top bit, the upper (the radical) with it
    return [(p3(m & 7)[0] * sc + (dx if m >> 3 & 1 else 0), p3(m & 7)[1] * sc + (dy if m >> 3 & 1 else 0)) for m in range(16)]


def ladder_svg(RES):
    R = RES['R']; F = RES['F']; Ed = RES['E']; Jg = RES['Jsig']
    pw, ph = 176, 366; W = 5 * pw + 8; H = ph + 14
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The cube of labels for n = 0 to 4 generators with the labels that contain the null bit highlighted" class="chart fx">']
    for n in range(5):
        x0 = 4 + n * pw
        P = _cube_points(n); xs = [p[0] for p in P]; ys = [p[1] for p in P]
        cx = x0 + pw / 2 - (min(xs) + max(xs)) / 2; cy = 104 - (min(ys) + max(ys)) / 2
        parts.append(f'<rect x="{x0}" y="4" width="{pw - 8}" height="{ph}" rx="10" fill="none" stroke="var(--line2)"/>')
        parts.append(f'<text x="{x0 + (pw - 8) / 2}" y="28" text-anchor="middle" class="big">n = {n}</text>')
        # edges
        for m in range(1 << n):
            for i in range(n):
                if not m >> i & 1:
                    a, b = P[m], P[m | 1 << i]
                    hot = bool((m | 1 << i) >> (n - 1) & 1) and n >= 1 and (n - 1 == i or (m >> (n - 1)) & 1)
                    cls = 'lad-eh' if (m >> (n - 1)) & 1 and n >= 1 else 'lad-e'
                    parts.append(f'<line x1="{cx + a[0]:.1f}" y1="{cy + a[1]:.1f}" x2="{cx + b[0]:.1f}" y2="{cy + b[1]:.1f}" class="{cls}"/>')
        for m in range(1 << n):
            hot = n >= 1 and (m >> (n - 1)) & 1
            lab = format(m, f'0{n}b')[::-1] if n else '∅'                  # bit 1 first
            t = tip(f'label {lab if n else "empty"} (n = {n})', ('contains the null bit: in the radical' if hot else ('does not contain the null bit: quotient Cl(' + str(n - 1) + ',0)' if n else 'the empty label, the unit')))
            parts.append(f'<g data-tip="{t}" tabindex="0"><circle cx="{cx + P[m][0]:.1f}" cy="{cy + P[m][1]:.1f}" r="{7 if n < 4 else 6}" class="{"lad-nh" if hot else "lad-n"}"/></g>')
        # facts from the data
        lines = []
        if n == 0:
            lines = ['Cl() = R', '1 label: the empty one', 'it is the unit, not a null', 'no generator yet', ' ']
        else:
            k = key(n - 1, 0, 1); r_ = R[k]; f_ = F[k]
            lay = '·'.join(str(v) for v in r_['layers']) if r_['layers'] else '–'
            lines = [f'Cl({n - 1},0,1): dim {r_["dim"]}', f'radical: {r_["rad"]} label' + ('s' if r_['rad'] != 1 else '') + ' (null bit set)', f'Loewy length {len(r_["layers"]) + 1}', f'super-centre dimension {r_["sc"]}', 'Frobenius ' + ('symmetric' if f_['symmetric'] else 'not symmetric')]
        for j, t_ in enumerate(lines):
            parts.append(f'<text x="{x0 + 10}" y="{204 + 17 * j}" class="{"ink" if j == 0 else "ink2"}">{E(t_)}</text>')
        ex = {0: ['Euler form of the cube', f'signature {tuple(Ed["0"])}'],
              1: ['Euler form ' + str(tuple(Ed['1'])), 'the arrow A2'],
              2: ['Euler form ' + str(tuple(Ed['2'])) + ' (= D4)', 'Majkić Gram ' + str(tuple(Jg['2']))],
              3: ['Euler form ' + str(tuple(Ed['3'])) + ':', 'two null directions', 'Majkić Gram ' + str(tuple(Jg['3']))],
              4: ['Euler form ' + str(tuple(Ed['4'])) + ':', 'indefinite', 'Majkić Gram ' + str(tuple(Jg['4']))]}[n]
        for j, t_ in enumerate(ex):
            parts.append(f'<text x="{x0 + 10}" y="{304 + 16 * j}" class="mut">{E(t_)}</text>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span><svg width="16" height="16" aria-hidden="true"><circle cx="8" cy="8" r="6" class="lad-n"/></svg> label without the null bit (the quotient algebra)</span>'
           '<span><svg width="16" height="16" aria-hidden="true"><circle cx="8" cy="8" r="6" class="lad-nh"/></svg> label containing the null bit (the radical; here r = 1, so it is a face of the cube)</span></div>')
    return ''.join(parts) + leg


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# Fig. 3  the clock (the clock of the quotient Cl(p,q)) and the null direction r
# ------------------------------------------------------------------------------------------------------------------------------------------------------
CLOCK_TYPES = ['R', 'R²', 'R', 'C', 'H', 'H²', 'H', 'C']          # recalled textbook list; the computed list of K4b equals it


def clock_svg(RES):
    R = RES['R']
    W, H = 880, 330
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The clock Z8 of types and the vertical direction of null generators" class="chart fx">']
    cx, cy, ro, ri = 190, 168, 128, 62
    slot = {'R': 'k1', 'R²': 'k4', 'C': 'k3', 'H': 'k2', 'H²': 'k5'}
    for c in range(8):
        a0 = math.radians(-90 + 45 * c - 22.5); a1 = math.radians(-90 + 45 * c + 22.5)
        def pt(r, a): return cx + r * math.cos(a), cy + r * math.sin(a)
        p1, p2, p3, p4 = pt(ro, a0), pt(ro, a1), pt(ri, a1), pt(ri, a0)
        typ = CLOCK_TYPES[c]; k = slot[typ]
        mid = math.radians(-90 + 45 * c); tx, ty = pt((ro + ri) / 2, mid)
        t = tip(f'clock c = p − q ≡ {c} (mod 8)', f'Cl(p,q) is of type {typ}', 'all signatures with this clock; label 0 (null generators) does not move it', 'Gauss sum phase c·π/4 (K4a); type = sign of Re (K4b, K4c)')
        parts.append(f'<g data-tip="{t}" tabindex="0"><path d="M{p1[0]:.1f},{p1[1]:.1f} A{ro},{ro} 0 0 1 {p2[0]:.1f},{p2[1]:.1f} L{p3[0]:.1f},{p3[1]:.1f} A{ri},{ri} 0 0 0 {p4[0]:.1f},{p4[1]:.1f} Z" class="{k}" stroke="var(--surf)" stroke-width="2"/>'
                     f'<text x="{tx:.1f}" y="{ty - 2:.1f}" text-anchor="middle" class="big i{k[1]}">{typ}</text><text x="{tx:.1f}" y="{ty + 15:.1f}" text-anchor="middle" class="ink2 i{k[1]}">c={c}</text></g>')
    parts.append(f'<text x="{cx}" y="{cy - 4}" text-anchor="middle" class="ink">clock</text><text x="{cx}" y="{cy + 13}" text-anchor="middle" class="mut">p − q mod 8</text>')
    parts.append(f'<text x="{cx}" y="{H - 8}" text-anchor="middle" class="ink2">one step round the ring: +1 generator forward, −1 back, 0 stays</text>')
    # the r direction: radical filtration for Cl(1,1,r), r = 0..3
    x0 = 400; parts.append(f'<text x="{x0}" y="26" class="ink">The other direction: r null generators (shown for Cl(1,1,r))</text>')
    parts.append(f'<text x="{x0}" y="44" class="mut">each bar is the algebra cut by the powers of the radical; the clock stays 0 for every r</text>')
    cols = ['k1', 'k4', 'k2', 'k5']
    maxdim = 1 << 5; scale = 8.0
    for r in range(4):
        rec = R[key(1, 1, r)]; dims = [rec['dim']] + rec['layers'] + [0]
        # layer sizes: A/rad, rad/rad^2, ... ; dims is [dim A, dim rad, dim rad^2, ..., 0]
        sizes = [dims[i] - dims[i + 1] for i in range(len(dims) - 1)]
        y = 70 + r * 62; x = x0
        parts.append(f'<text x="{x0}" y="{y + 20}" class="ink">r = {r}</text>')
        xb = x0 + 54
        for i, s in enumerate(sizes):
            w = s * scale
            t = tip(f'Cl(1,1,{r}), dimension {rec["dim"]}', ('top layer: the semisimple quotient Cl(1,1) = M2(R), dimension %d' % s) if i == 0 else f'layer {i}: rad^{i}/rad^{i + 1}, dimension {s} = C({r},{i})·4', f'Loewy length {len(rec["layers"]) + 1}, super-centre {rec["sc"]}, radical {rec["rad"]}')
            parts.append(f'<g data-tip="{t}" tabindex="0"><rect x="{xb:.1f}" y="{y + 2}" width="{max(w - 2, 3):.1f}" height="36" rx="4" class="{"k1" if i == 0 else cols[min(i, 3)]}"/><text x="{xb + w / 2:.1f}" y="{y + 25}" text-anchor="middle" class="ink {"i1" if i == 0 else "i" + cols[min(i, 3)][1]}">{s}</text></g>')
            xb += w
        parts.append(f'<text x="{xb + 8:.1f}" y="{y + 18}" class="ink2">Loewy {len(rec["layers"]) + 1} · super-centre {rec["sc"]}</text>')
    parts.append(f'<text x="{x0}" y="{H - 8}" class="ink2">blue: Cl(1,1) = M2(R), what the clock sees; the rest: radical</text>')
    parts.append('</svg>')
    return ''.join(parts)


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# Fig. 4  signatures: E_n, the cube category, Majkić's atoms (the trio at work)
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def sigbars_svg(RES, sig_E):
    Ed = RES['E']; Jg = RES['Jsig']
    groups = [('Cartan form of E_n  (n = 3 … 11)', [(f'E{n}', tuple(sig_E[str(n)]), {'9': 'E9 = affine E8: the null root', '10': 'E10 hyperbolic', '11': 'E11 Lorentzian form (of the root lattice, not a spacetime)'}.get(str(n), '')) for n in range(3, 12)]),
              ('Euler form of the cube category  (n = 0 … 5)', [(f'n={n}', tuple(Ed[str(n)]), '') for n in range(6)]),
              ('Gram form of Majkić’s atoms on the cube  (n = 2 … 4)', [(f'n={n}', tuple(Jg[str(n)]), '') for n in range(2, 5)])]
    bw, gap = 62, 8; rows = []
    W = 880; H = 3 * 210 + 20
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Signatures (positive, negative, null) of three families of forms" class="chart fx">']
    y0 = 6
    for title, items in groups:
        mx = max(sum(s) for _, s, _ in items)
        sc = 124.0 / mx
        parts.append(f'<text x="8" y="{y0 + 14}" class="ink">{E(title)}</text>')
        base = y0 + 24 + 124 + 18
        for i, (lab, (p, q, r), note) in enumerate(items):
            x = 12 + i * (bw + gap)
            y = base
            tp = tip(f'{title.split("  ")[0]} · {lab}', f'signature (positive, negative, null) = ({p}, {q}, {r}) on {p + q + r} dimensions', note or ('a null direction (reading it as a label 0 is ours)' if r else 'no null direction'))
            parts.append(f'<g data-tip="{tp}" tabindex="0">')
            for cnt, k in ((p, 'k1'), (q, 'k5'), (r, 'k4')):
                if cnt:
                    h = cnt * sc
                    y -= h
                    parts.append(f'<rect x="{x}" y="{y:.1f}" width="{bw - 6}" height="{max(h - 1.5, 1.5):.1f}" rx="2" class="{k}"/>')
                    if h >= 15: parts.append(f'<text x="{x + (bw - 6) / 2}" y="{y + h / 2 + 4.5:.1f}" text-anchor="middle" class="ink i{k[1]}">{cnt}</text>')
            parts.append(f'<text x="{x + (bw - 6) / 2}" y="{base + 15}" text-anchor="middle" class="t">{lab}</text>')
            if r: parts.append(f'<text x="{x + (bw - 6) / 2}" y="{y - 5:.1f}" text-anchor="middle" class="ink">0 ×{r}</text>')
            parts.append('</g>')
        y0 += 210
    parts.append('</svg>')
    leg = ('<div class="legend"><span><i class="sw k1">+</i> positive: generators with square +1 (split, spacelike)</span><span><i class="sw k5">−</i> negative: square −1 (inert, timelike)</span>'
           '<span><i class="sw k4">0</i> null: square 0, a label 0 (ramified, null)</span></div>')
    return ''.join(parts) + leg


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# Fig. 5  where the Frobenius form is symmetric
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def frob_svg(RES):
    F = RES['F']
    cw, ch, ox, oy = 92, 56, 78, 46
    W = ox + 6 * cw + 10; H = oy + 5 * ch + 56
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="For n = 1 to 5 generators and r null ones: signatures whose label algebra has a symmetric Frobenius form or only a non-symmetric one" class="chart fx">']
    parts.append(f'<text x="{ox + 3 * cw}" y="18" text-anchor="middle" class="t2">r = number of null generators (label 0)</text>')
    parts.append(f'<text x="14" y="{oy + 2.5 * ch}" text-anchor="middle" class="t2" transform="rotate(-90 14 {oy + 2.5 * ch})">n = number of generators</text>')
    for r in range(6): parts.append(f'<text x="{ox + r * cw + cw / 2}" y="{oy - 8}" text-anchor="middle" class="t">{r}</text>')
    for n in range(1, 6):
        parts.append(f'<text x="{ox - 10}" y="{oy + (n - 1) * ch + ch / 2 + 5}" text-anchor="end" class="t">{n}</text>')
        for r in range(0, n + 1):
            sigs = [(p, n - r - p) for p in range(n - r + 1)]
            recs = [F[key(p, q, r)] for p, q in sigs if key(p, q, r) in F]
            ns = sum(1 for x in recs if x['symmetric']); nn = len(recs) - ns
            x = ox + r * cw; y = oy + (n - 1) * ch
            k = 'k1' if nn == 0 else 'k2'
            t = tip(f'n = {n}, r = {r}: {len(recs)} signatures', f'symmetric Frobenius form exists: {ns}', f'Frobenius only, not symmetric: {nn}', 'rule: symmetric exactly when n is odd or r = 0 (F3)',
                    'the top-blade form is symmetric exactly for n odd (F2)')
            parts.append(f'<g data-tip="{t}" tabindex="0"><rect x="{x + 2}" y="{y + 2}" width="{cw - 4}" height="{ch - 4}" rx="7" class="{k}"/>'
                         f'<text x="{x + cw / 2}" y="{y + 24}" text-anchor="middle" class="big i{k[1]}">{len(recs)}</text>'
                         f'<text x="{x + cw / 2}" y="{y + 42}" text-anchor="middle" class="ink2 i{k[1]}">{"symmetric" if nn == 0 else "not symmetric"}</text></g>')
    # 3D PGA
    x = ox + 1 * cw; y = oy + 3 * ch
    parts.append(f'<rect x="{x}" y="{y}" width="{cw}" height="{ch}" rx="9" fill="none" stroke="var(--ink)" stroke-width="2.6" stroke-dasharray="5 3"/>')
    parts.append(f'<text x="{ox + 1 * cw + cw / 2}" y="{oy + 5 * ch + 18}" text-anchor="middle" class="ink">★ n = 4, r = 1 contains Cl(3,0,1), the 3D projective algebra</text>')
    parts.append(f'<text x="{ox + 3 * cw}" y="{oy + 5 * ch + 38}" text-anchor="middle" class="ink2">Frobenius (non-degenerate top-blade pairing) in every cell; a symmetric form exists only for n odd or r = 0</text>')
    parts.append('</svg>')
    leg = '<div class="legend"><span><i class="sw k1">n</i> a symmetric form exists for every signature in the cell</span><span><i class="sw k2">n</i> none exists: Frobenius, not symmetric (Nakayama = grade involution)</span></div>'
    return ''.join(parts) + leg


# ------------------------------------------------------------------------------------------------------------------------------------------------------
# Fig. 6  the ladder as four maps (Cl applied to maps of quadratic spaces; halving a natural isomorphism) and what label 0 does to each
# ------------------------------------------------------------------------------------------------------------------------------------------------------
def functors_svg():
    W, H = 880, 356
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Four ways to move between dimensions: double, halve, restrict to a face, complement; and what a null generator does to each" class="chart fx"><defs><marker id="ah2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="var(--ink)"/></marker><marker id="ah3" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="var(--open)"/></marker></defs>']
    xs = [110, 330, 550, 770]
    names = ['n − 1', 'n', 'n + 1', 'n + 2']
    for x, nm in zip(xs, names):
        parts.append(f'<rect x="{x - 62}" y="140" width="124" height="56" rx="10" class="fn-box"/><text x="{x}" y="164" text-anchor="middle" class="big">{nm} generators</text><text x="{x}" y="184" text-anchor="middle" class="mut">2^({nm}) labels</text>')
    # up arrows (doubling), drawn above
    for i in range(3):
        a, b = xs[i] + 62, xs[i + 1] - 62
        parts.append(f'<path d="M{a + 4},{140} C{a + 30},{92} {b - 30},{92} {b - 4},{140}" fill="none" stroke="var(--ink)" stroke-width="2.4" marker-end="url(#ah2)" data-tip="{tip("double: graded tensor product with one more generator", "concatenate the lists of generators; Koszul sign = the bit-rule sign (K5a, K5c)", "works for any square, null included")}" tabindex="0"/>')
    parts.append(f'<text x="{(xs[0] + xs[3]) / 2}" y="66" text-anchor="middle" class="ink">UP: double (graded tensor product, Koszul sign = sorting sign)  ·  works for +1, −1 and 0  ·  K5a, K5c</text>')
    # down arrows (even subalgebra), drawn below
    for i in range(3):
        a, b = xs[i + 1] - 62, xs[i] + 62
        mk = 'ah2'; col = 'var(--ink)'
        t = tip('halve: the even subalgebra', 'Cl_even(p,q,r) = Cl(p,q-1,r) when one generator with a non-zero square exists (K5b)', 'with only null generators it fails from r = 3 on: the even part of Λ(R³) has Loewy length 2, a Clifford algebra on two generators has 3 (K5b); for r ≤ 2 it is still a Clifford algebra (T5(d))') 
        parts.append(f'<path d="M{a - 4},{196} C{a - 30},{244} {b + 30},{244} {b + 4},{196}" fill="none" stroke="{col}" stroke-width="2.4" marker-end="url(#{mk})" data-tip="{t}" tabindex="0"/>')
    parts.append(f'<text x="{(xs[0] + xs[3]) / 2}" y="278" text-anchor="middle" class="ink">DOWN: even subalgebra  ·  needs one invertible generator (+1 or −1), unless r ≤ 2 and all null  ·  K5b</text>')
    parts.append(f'<text x="{(xs[0] + xs[3]) / 2}" y="296" text-anchor="middle" class="ink" fill="var(--open)" style="fill:var(--open)">✗ fails exactly when there are only null generators and three or more of them (T5(d)): then label 0 cannot be peeled off</text>')
    parts.append(f'<text x="{(xs[0] + xs[3]) / 2}" y="318" text-anchor="middle" class="ink2">SIDEWAYS: a face of the cube is a sub-algebra; the face without null bits carries Cl/radical; for r = 1 the radical is the other face (R1)</text>')
    parts.append(f'<text x="{(xs[0] + xs[3]) / 2}" y="340" text-anchor="middle" class="ink2">DUALITY: complement mask a ↔ a xor 11…1 is a Frobenius pairing for every signature, null included; Nakayama = grade involution (F1, F2)</text>')
    parts.append('</svg>')
    return ''.join(parts)
