# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The hand-written text of the category-lens report: paper cards, the views tried, the ladder rows, the questions for specialists.
Numbers that rest on a check are not typed here: they are filled in by build_report_cat.py from the logs (placeholders in braces)."""

PAPER_CARDS = [
 ('K', 'Clifford algebra, geometric algebra, and applications', 'Douglas Lundholm, Lars Svensson · KTH lecture notes, rev. 7 June 2016',
  'A course on Clifford and geometric algebra. The combinatorial definition Cl(X,R,r) puts one basis element on every subset of a set X, with a signature r: X → R and a product A·B = τ(A,B)·(A△B) (Def. 2.4, p. 14; Lemma 2.6, whose recursion gives no closed formula for τ). Signature value 0 is allowed: degenerate algebras and “the degenerate line” (pp. 10, 81–82). The real classification as a table (Thm 5.5, Table 5.1, pp. 57–58), the graded tensor product (Prop. 5.8) and the even subalgebra (Prop. 5.1), the mother algebra Cl(s,t,u) inside Cl(n,n) with a null generator f⁺ − f⁻ (Sect. 5.3, p. 62), the simplicial boundary (Sect. 4.1), Fock space and irreducible representations (Sect. 4.3, Ch. 8), octonions (Sect. 8.3.1).',
  'The combinatorial algebra is the bit rule; associativity for every choice of the trio, null included (S1); the mod-8 rule and the types as one Gauss sum (K4a–c); concatenation of generators is the graded product with the Koszul sign (K5a); the even subalgebra needs an invertible generator (K5b); the mother algebra (M1, M2); the boundary squares to zero (K1e); the Fock relations (B1). Not touched: spin groups, Clifford analysis, the octonion formula with the 3-vector.',
  ['checked', 'standard']),
 ('W', 'The Tenfold Way', 'John C. Baez · arXiv:2011.14234, three pages, 1 December 2020',
  'Schur’s lemma makes R, C and H the endomorphism algebras of irreducible real representations (Dyson’s threefold way). For super vector spaces there are ten real super division algebras: R, C, H purely even and seven with an odd generator (2 + 3 + 2). Wall showed they are all Clifford algebras: the eight real ones are the eight Morita classes of real Clifford algebras, the two complex ones the complex classes; real and complex Bott periodicity are united, and the ten families of symmetric spaces correspond to them.',
  'The eight classes as the clock p − q mod 8 and the three types as the sign of Re S + Im S of one Gauss sum S, the sum of the squares of the labels, a Frobenius–Schur count (K4a–c); five ungraded types against eight graded ones, separated by the type of the even part (C1); n = 1 gives the two graded division algebras with e² = ±1 (L1a). The Brauer–Wall group Z8 and Wall’s theorem are recalled, not recomputed. The physical ten classes of matter are not touched.',
  ['checked', 'standard', 'ours']),
 ('T', 'A diagrammatic categorification of a Clifford algebra', 'Yin Tian · arXiv:1309.6049 v1, 24 September 2013, 51 pages',
  'The Z-algebra Cl_Z with aᵢ² = 0, aᵢaⱼ = −aⱼaᵢ for |i − j| > 1 and aᵢaᵢ₊₁ + aᵢ₊₁aᵢ = 1 acts faithfully on an exterior algebra (Lemma 3.3, p. 17). A DG category CL of diagrams with morphisms over F2 has K0(CL) = Cl_Z (Thm 1.1, Prop. 2.1, p. 14); signs come from odd cohomological shifts, x ≅ N(x)[η(x)] with η the number of inversions (Lemma 4.20, p. 29); the motivation is contact categories of a strip. Whether Hom(∅,∅) is one-dimensional (Remark 2.6, p. 11) and Conjecture 2.11 are open in the paper.',
  'The relations on the exterior algebra of n sites (T1); the finite truncations: odd length hides one radical vector a₁ − a₃ + a₅ − …, even length is a matrix algebra (T2, T3); over R the algebra is the bit-rule algebra Cl(m,m) or Cl(m,m,1) in a hyperbolic basis, and the nilpotent aᵢ are paired nulls, not label 0 (T4); the sorting sign of the paper is the bit-rule sign (K5c). Not touched: the DG category, the diagrammatics, the contact categories, the conjecture.',
  ['checked', 'standard', 'open']),
 ('M', 'Categorial geometry and algebraic topology', 'Zoran Majkić · arXiv:2403.19689 v2 [math.GM], 22 March 2026',
  'A category is read as a discrete geometric object whose points are the objects and whose arrows are oriented paths. The “Cat-arrows space” V has a partial addition of composable arrows (Def. 2), a norm counting the minimal number of generating arrows (Def. 3) and an inner product f·g = ‖f‖‖g‖ when g = f or f, g compose, and 0 otherwise (Def. 4); orthogonal means “not composable in either order”. The paper says V is not a vector space and that angles are not supported (Corollary 1), defines an outer product (Def. 6) and claims the two Clifford conditions e² = 1 and fg = −gf for orthogonal f, g (Corollary 2). A Metacategory space and comma-propagation are the topological part.',
  'Implemented literally on the cube category. The inner product of Def. 4 is not additive along composition and the two properties of Corollary 2 hold by definition (norm 1 for atoms, opposite orientation of the two bivectors), not as consequences of a quadratic form (J1, J2). A constructive reading, ours and not in the paper: the quiver form with 2 on the diagonal and 1 for composable atoms, whose signatures run (4,0,0), (11,0,1), (26,4,2) (J3). Not touched: the Metacategory, comma-propagation, the topology.',
  ['checked', 'ours', 'open']),
]

# the version of Majkić’s paper that this report reads, and what the other version defines (shown at the head of the view 8, of the paper card and of finding N7)
NOTE_V3 = ('This reads arXiv:2403.19689 v2, 22 March 2026. Version 3 (arXiv:2403.19689 v3, 17 July 2026) defines the norm as a crossing time (Def. 2), '
           'the inner product through planar angles (Def. 3), the outer product (Def. 5) and the Clifford conditions (Corollary 1); its reading on the labels '
           'is on step 18 of the atlas, under “Arrows as vectors”, with the checks of the families bd·mjc, bd·mja, bd·mjg and bd·mjp of selfcheck/bridges/.')
NOTES = {'M': NOTE_V3, '8 · Majkić: arrows of a category as vectors': NOTE_V3}

# the nine views tried before choosing:  (title, kind, text, ids)
LENSES = [
 ('1 · The null label as an element: the radical', 'kept', 'Take the generators that square to 0 and ask what ideal they generate. The labels with a null bit span the radical; the quotient is the ordinary algebra; the powers of the radical are counted by null bits.', 'R1, R2, G1'),
 ('2 · The cube of labels as a category', 'kept', 'Labels ordered by inclusion form a category (the Boolean lattice). The bit-rule sign makes every square anticommute, and nothing else does: the sign is unique up to rescaling the labels.', 'K1a–K1e'),
 ('3 · The sign as a cocycle', 'kept', 'Group cohomology of Z₂ⁿ: the bit rule is a 2-cocycle; its class is a quadratic form; the octonions are the same labels with a 2-cochain whose coboundary is the associator.', 'K2a, K2b, K3a, K3b'),
 ('4 · Frobenius duality and the trace', 'kept', 'The complement mask pairs every label with its complement. That is a Frobenius pairing for every signature, null included; the top-blade form itself is symmetric only for odd n, and the algebra has some symmetric form only for odd n or without null generators; in super vector spaces the top-blade form is super-symmetric for every signature (bd·cat·5).', 'F1–F4, C2'),
 ('5 · Graded Morita classes: the tenfold way', 'kept', 'Baez’s three pages and Wall’s theorem: eight real classes. In the atlas they are the clock, and the types come from one Gauss sum.', 'K4a–K4c, C1, L1a'),
 ('6 · The ladder as maps', 'kept', 'Up by the graded tensor product (concatenate generators, Koszul sign), down by the even subalgebra, sideways by faces of the cube, and the mother algebra that turns a null into a pair.', 'K5a–K5c, M1, M2'),
 ('7 · Quiver forms and root systems', 'kept', 'The form of a Dynkin diagram, its extended version, and the Euler form of a category are quadratic forms, so each has a signature (p, q, r) and a Clifford algebra. Reading the null root as a label 0 is ours.', 'Q1–Q5, E1, W1–W3'),
 ('8 · Majkić: arrows of a category as vectors', 'deadend', 'As written the construction is not a Clifford algebra of a vector space. One piece survives, a reading of our own through the Gram form of a quiver.', 'J1–J3'),
 ('9 · Braidings: fermion = Koszul sign, boson = no sign', 'partly', 'The fermionic and bosonic ladders are the same relations with a super-commutator or a commutator; what the symmetric braiding of super vector spaces adds beyond that was only recalled.', 'B1, K5a'),
]

# the bottom-up ladder, one dimension at a time:  (n, what exists, what label 0 is here, what first appears, ids)
LADDER = [
 ('0', 'One label, the empty bit string. The algebra is R, the cube is a point.',
  'There is no generator, so there is no null one. The label 00…0 (here the empty string) is the unit: 1·1 = 1. It is the unit object of the monoidal structure, not the generator with square 0.',
  'The unit. Every later “0” has to be told apart from this one.', 'L0'),
 ('1', 'Two labels, ∅ and {1}; the cube is one arrow. Cl(0,0,1) = R[x]/x², the dual numbers.',
  'The first place a label can square to 0. With a + b·e the norm is a² − ε b², so ε = +1 is split (R ⊕ R), ε = −1 is inert (C) and ε = 0 is ramified (the dual numbers): the trio −1, 0, +1 is the trichotomy of quadratic algebras. The single label {1} is the radical; the quotient is R. The odd generator is nilpotent, so the two graded division algebras (ε = ±1) are lost. Over the finite fields F₃ … F₁₃ the number of units is (p − 1)(p − χ(d)) with χ the Legendre symbol: the same three values, exactly, for n = 1.',
  'The trio as inert / ramified / split; the nilpotent odd generator; the radical.', 'L1a, L1b, R1'),
 ('2', 'Four labels; the cube is a square. Cl(0,0,2) = Λ(R²), Cl(1,0,1), Cl(0,1,1), and the ordinary algebras.',
  'Two things carry the same symbol 0. An unpaired null generator (Cl(0,0,2)) spans a radical of dimension 3 with Loewy length 3 and a super-centre of dimension 4. A paired null (in Cl(1,1), u = e₁ + e₂ and v = e₁ − e₂ square to 0 and uv + vu = 4) generates a matrix algebra with zero radical. Tian’s nilpotent aᵢ are the second kind; the null generator of the atlas’s projective step is the first. The cube has its first anticommuting square, and H²(Z₂²; Z₂) = 3 quadratic forms.',
  'Paired against unpaired null; the first non-symmetric Frobenius form (Cl(1,0,1), Cl(0,1,1), Cl(0,0,2)); the first cocycle choice (H² of dimension 3).', 'R1–R3, M2, F3, K1a, K2a'),
 ('3', 'Eight labels; the cube is a cube. The same labels carry Cl(3,0) = M₂(C) and the octonions.',
  'The first place where a null direction shows up in the category itself: the symmetrised Euler form of the cube category has signature {E3} (two null directions), while its Tits form, which governs the representation type, has signature (6,1,1) (T8); the Gram form of Majkić’s atoms (11,0,1) has one null direction. Reading either null direction as a label 0 is ours (question QB4). The octonions use the same eight labels with a sign that is a 2-cochain, not a cocycle, and the associator is its coboundary. For odd n the pseudoscalar is central and the top-blade Frobenius form is symmetric.',
  'A null direction of the Euler form (not of the Tits form); the octonion cochain; the first odd n above 1 with a central pseudoscalar.', 'E1, J3, K3a, K3b, F2'),
 ('4', 'Sixteen labels. Cl(3,0,1) is the 3D projective algebra of rigid motions.',
  'With one null generator and three ordinary ones: dimension 16, radical of dimension 8 (a face of the 4-cube), Loewy length 2, super-centre of dimension 2. The duality is Frobenius but not symmetric, and its Nakayama automorphism is the grade involution, which no unit of the algebra implements. The category’s Euler form leaves the definite region, {E4}, and Majkić’s Gram form is (26,4,2). The cube at n = 2 had the signature of D₄; the affine A₃ has the signature (3,0,1) of the generators of Cl(3,0,1), a coincidence of shape that we only record.',
  'The first projective algebra of physical size; non-symmetric Frobenius duality with a null; indefinite Euler form.', 'R1–R3, F1–F3, E1, J3, Q1'),
 ('5 …', 'The cube keeps doubling; the Euler form of the 5-cube is {E5}.',
  'Nothing new in kind. Loewy length is r + 1, the super-centre is Λ(R^r) of dimension 2^r, the label-homogeneous grading group has free rank r (for arbitrary gradings this fails already at M₂(R), G2), and the clock never moves. The lift of a null generator’s Z₂-degree to an additive Z-degree (among label-homogeneous gradings) is the one structural fact about label 0 that survives to every n.',
  'The pattern; the exterior algebra is the all-null end of the ladder.', 'R2, R3, G1, K4a'),
]

# questions for specialists: (group, id, who, question, checked, not checked)
QUESTIONS = [
 ('A', 'The null label as an algebra element', [
  ('A1', 'graded ring theory',
   'For the bit-rule algebra Cl(p,q,r) the super-centre is the exterior algebra on the r null generators and the algebra is graded-Azumaya exactly when r = 0. Is this a known statement, and is there a graded Brauer-type group that contains the degenerate Clifford algebras, so that the clock p − q mod 8 can be extended by a second coordinate for r?',
   'R1–R4 for all 56 signatures with up to five generators, solved as linear systems. The clock of a degenerate cell is the clock of its quotient Cl(p,q) and of its mother cell Cl(p+r,q+r), forced (K4a; bd·cat·4, bd·geo·5, bd·xck·3). Over its super-centre the cell is graded Azumaya and its graded Hochschild groups HH¹, HH² relative to Λ(R^r) vanish (r = 1 with p + q ≤ 3, r = 2 with p + q ≤ 2; bd·mat·10, bd·hh·1–4): r is the base ring, not a second coordinate. Over R the graded Morita classes form the monoid Z₈ × N, (clock, r) (bd·cat·11).',
   'Larger cells and r ≥ 3 beyond the separability argument (pointer, source unread); a literature search.'),
  ('A2', 'representation theory of algebras',
   'The exterior algebra Λ(k^r) has finite representation type for r ≤ 1, tame for r = 2 and wild for r ≥ 3 (recalled). Does that measure how far label 0 is from invertible, and what does it become for Cl(p,q,r) with p + q ≥ 1 (a Morita-type reduction to the exterior algebra through Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(R^r), the graded tensor product)?',
   'Loewy length r + 1 and the layer sizes C(r,k)·2^(p+q) (R2); the graded tensor product on the labels (K5a; T2).',
   'The representation types themselves; the reduction.'),
  ('A3', 'graded algebra',
   'Among the gradings in which every label is homogeneous, the universal grading group of Cl(p,q,r) is Z₂^(p+q) × Z^r, of free rank r (G1 for 34 signatures with up to four generators; proved for all n in T2). The qualifier is necessary: M₂(R) = Cl(2,0) carries a Z-grading by matrix-unit degree (G2). Is the universal grading group for arbitrary gradings known, torsion part included?',
   'The label-homogeneous free rank, by linear algebra on the labels (G1); the matrix-unit grading of Cl(2,0) (G2).', 'Arbitrary gradings; the torsion part; larger n.'),
  ('A4', 'Frobenius and Gorenstein algebras; PGA',
   'The complement mask pairs a with a xor 11…1 and is a Frobenius pairing for every signature. The top-blade form λ is symmetric exactly for odd n; the algebra has some symmetric Frobenius form exactly for odd n or r = 0, and for n even with r ≥ 1 (for example the 3D projective algebra Cl(3,0,1)) none exists; the Nakayama automorphism of λ is then the grade involution. In super vector spaces that twist is the Koszul sign and λ is super-symmetric for every signature (bd·cat·5). Is this known for the exterior and projective algebras, and does the twist matter for the duality (“dual”, “Hodge”) used in the projective-geometric-algebra literature?',
   'F1–F3 for all signatures with up to five generators (rank tests on random members of the space of symmetric functionals, plus the Nakayama formula on every label); the conjugators of the grade involution lie in the radical (F5); all of it proved for every n in T3.',
   'Any use of the twist in PGA practice; a reference for the degenerate case (we could not name one).'),
 ('A5', 'Frobenius algebras and quantum foundations',
  'All Frobenius forms of Cl(p,q,r) are λ(u·) with u any unit; only the symmetric ones, when they exist, are a torsor under the central units (F5; T3). For Cl(3,0) the trace of quantum mechanics is the top-blade form up to the central pseudoscalar (C2). With null generators the scalar-part form is blind to every label with a null bit (F4) and only the top-blade form is non-degenerate; but the top-blade form is never a state and every state vanishes on the radical, so the states of Cl(p,q,r) are those of Cl(p,q) (C3; T15: the top-blade form is not a state). Is this dichotomy, non-degenerate against positive, known for degenerate Clifford algebras, and what is the right notion of state for composite systems?',
   'C2 (Cl(3,0), twelve rational pairs); F4 (up to five generators); F5 (the torsor, exact); C3 (states for all 34 signatures with up to four generators, dagger involution).',
   'Composite systems (graded against ungraded tensor products); involutions other than the dagger one for positivity (T15 covers the vanishing on the radical for every involution); the literature.'),
 ]),
 ('B', 'The cube, its sign and its cohomology', [
  ('B1', 'categorification; knot homology',
   'The cube of labels with the Jordan–Wigner sign is the standard picture of a cube of resolutions. Is Tian’s DG category CL a categorification of this signed cube, or of something else, and is the uniqueness of the sign up to gauge (H¹(cube; F₂) = 0) the reason the sign conventions of such constructions agree?',
   'K1a–K1e (n ≤ 6; brute force on the 3-cube: 128 sign assignments = one gauge orbit), K5c (the sign equals the sorting sign of Tian’s Lemma 4.20).',
   'The DG category, its diagrammatics, Remark 2.6 and Conjecture 2.11 of the paper.'),
 ('B2', 'cohomology with a monoid of coefficients',
  'For ε = ±1 the bit rule is a 2-cocycle of Z₂ⁿ in {±1}. For a null generator the sign function takes the value 0 on some pairs, so it lives in the multiplicative monoid {+1, −1, 0}, which is not a group. Is there a cohomology theory (twisted monoid algebras, partial cocycles) in which the degenerate algebras are twisted algebras and the radical is a cohomological notion?',
   'S1: associativity for every choice of the trio (all 81 choices with four generators, 331 776 triples each); K2b for ε = ±1.',
   'Anything about a cohomology of the monoid-valued rule. We do not know the right framework.'),
 ('B3', 'non-associative algebra; cochain twists',
  'The octonion sign is a 2-cochain on Z₂³ whose coboundary is the associator (−1)^det, a 3-cocycle (pentagon); the Clifford sign of Cl(0,3) on the same labels is a cocycle. This is the cochain-twist picture of Albuquerque and Majid (recalled). Is there a null analogue (split or dual octonions) and a place for the radical in it?',
   'K3a, K3b (all 4096 quadruples).', 'Null octonions; the literature statement itself.'),
 ('B4', 'derived categories of finite-dimensional algebras',
  'The Euler form of the n-cube category (the incidence algebra of the Boolean lattice, a tensor power of A₂) has signature (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0 … 5. For n = 2 this is the signature of D₄, consistent with the commutative square being derived equivalent to D₄ (recalled). For n = 3 it is positive semi-definite with a two-dimensional radical on eight dimensions, the profile of a tubular algebra; T8 adds that the Coxeter polynomial is the D₄ polynomial at n = 2 and (x−1)²(x²+x+1)³ at n = 3, the tubular (3,3,3) profile, that the two null directions at n = 3 are exactly the Coxeter-fixed vectors, that the Tits form at n = 3 has signature (6,1,1) (it differs from the symmetrised Euler form from n = 3 on), and that the algebra is not representation-finite from n = 3 and wild from n = 4 (de la Peña, recalled). Is the 3-cube derived equivalent to the tubular algebra of type (3,3,3), and is it tame?',
   'The signatures (E1), by exact rational diagonalisation; the Coxeter polynomials, Fix(Φ) = Euler radical and the Tits form (theorem T8 of the page For researchers, researchers_checks/check_T8.py).', 'The derived equivalence; tame versus wild at n = 3 (open in T8: only the Coxeter polynomial and the corank-2 Euler form have the tubular profile).'),
 ('B5', 'categorification',
  'Tian’s odd truncations have a radical vector a₁ − a₃ + a₅ − …, a label 0 that the relations do not display (T2, T3). Is there an object in CL (or in K0) whose class is that vector, and what happens to it in the limit of the infinite algebra Cl_Z, which has no radical?',
   'T2 for n ≤ 3; T3 (signature ⌊k/2⌋, ⌊k/2⌋, k mod 2 for k ≤ 10).', 'Anything inside the DG category.'),
 ]),
 ('C', 'The tenfold way and graded Morita classes', [
  ('C1', 'Brauer–Wall groups',
   'The clock is a homomorphism for the graded product (K4a, K5a), and null generators contribute 0. What is the graded Morita class of Cl(p,q,r), and is there a version of the Brauer–Wall group in which r is a second coordinate (for instance classes over dual numbers or exterior algebras)?',
   'The clock of the quotient (K4a); five ungraded against eight graded types (C1).', 'Any group that includes r.'),
  ('C2', 'number theory; algebra over finite fields',
   'Over F_p the one-generator algebra has (p − 1)(p − χ(d)) units: split, ramified, inert as +1, 0, −1 (L1b). Does the clock have a finite-field version (the Brauer–Wall group of F_q, recalled to be Z₄ or Z₂ × Z₂), and for n = 2 is “null” the same thing as “ramified” for quaternion algebras over Q (Hilbert symbols)?',
   'The unit count at n = 1 for p = 3, 5, 7, 11, 13.', 'Everything for n ≥ 2 and every field other than R and the five primes above.'),
  ('C3', 'condensed-matter classification',
   'The eight clock values and the two complex classes match the ten symmetry classes of free-fermion matter (Kitaev’s periodic table, arXiv:0901.2686; the paper’s last section; Freed–Moore): standard. Which class sits at which clock value needs T² and C² as input. Does a nilpotent generator (r ≥ 1) correspond to anything physical in that classification (gapless or degenerate directions), or is it simply absent?',
   'The eight graded pairs (C1). That the ten super division algebras correspond to the ten classes is stated in the paper and in Kitaev’s table (standard, quoted here).', 'The class assignment (T², C²); anything about r ≥ 1.'),
 ]),
 ('D', 'From the top: root systems, E_n and lattices', [
  ('D1', 'Kac–Moody algebras; lattices',
   'The forms of E₈, E₉ = Ẽ₈, E₁₀, E₁₁ have signatures (8,0,0), (8,0,1), (9,1,0), (10,1,0): the first step beyond the finite root system adds one null direction (the null root with marks summing to 30), the next trades it for a −1. For n = 3 … 8 the quadratic space E_n/2E_n has the same counts as the blades of Cl(n,0): 4, 10, 20, 36, 64, 120 blades with square −1; the extra class at n = 7 is the central pseudoscalar. W(E_n) mod 2 = O(Q) holds as groups for n = 3…8: the atlas checks it (groups_check.py part B) and T9 proves it, with E_n/2E_n carrying the label form of Cl(n,0) for every n ≥ 3 and A_n/2A_n that of Cl(0,n), the two coinciding iff 4 | n (so the class is not a function of rank and signature: A₆ against E₆). For n = 3…20 the image of W(E_n) is all of O(q), by a certificate (bd·en·2), and for n ≤ 8 the kernel is the centre of W(E_n) (bd·en·3); for every n the image is the group generated by the orthogonal transvections of q (bd·en·5). Is this identification known, and what does it mean through E₉, E₁₀, E₁₁, where the real form turns affine and Lorentzian?',
   'Q1, Q2, Q5 (counts, radicals and determinants by exact arithmetic); the classification of quadratic spaces over F₂ is recalled; the groups for n = 3…8 are checked by the atlas (groups_check.py part B) and proved in T9, and for n = 3…20 by a certificate (bd·en·2).', 'A reference; for n > 20 the group statement rests on Dieudonné’s theorem (pointer, source unread); what the identification means through E₉, E₁₀, E₁₁.'),
  ('D2', 'topology; lattices',
   'The phase of the Gauss sum over the labels of Cl(n,0) is (p − q)π/4 (K4a), and for the root lattices A₃, A₈, D₄, D₈, E₆, E₇, E₈ the Gauss–Milgram sum of the discriminant form has the phase n·π/4 (Q4). Is “clock = Brown invariant of the Z₄-valued quadratic form of the labels” the correct statement, and is it the same Z₈ as the signature mod 8 of an even lattice?',
   'Numerically on seven lattices, tolerance 10⁻⁹; exact Gaussian integers for the Gauss sum with p + q ≤ 10.', 'The naming; a proof for all n.'),
  ('D3', 'quiver representations',
   'The number of blades with square −1 equals the number of positive roots of E_n for n = 3, 4, 5, 6, 8 (4, 10, 20, 36, 120) and is 64 = 63 + 1 for n = 7. By Gabriel’s theorem (recalled) the positive roots count the indecomposable representations of the quiver. The matching with roots mod 2 is standard; is there a reason, or a use, for reading the same number as blades of a Clifford algebra?',
   'Q3 (positive roots by reflection orbits: 36, 63, 120), Q5.', 'Gabriel’s theorem; any use of the reading.'),
 ]),
 ('E', 'The questions left in the Schuller report (“Next, in order”) and the horizon items', [
  ('E1', 'quantum foundations',
   'Item 1, Chapter 17: in Cl(3,0) the mixed state ρ = (1 + v)/2 and the projector P = (1 + u)/2 give the probability 2⟨ρP⟩₀ = (1 + v·u)/2, ρ is positive iff |v| ≤ 1 and pure iff |v| = 1: the Bloch ball. For a general Cl(p,q) with the dagger involution the states are the density elements ρ ≥ 0 of the scalar-part trace, and with null generators nothing replaces the scalar part: every state vanishes on the radical, so the states of Cl(p,q,r) are exactly those of Cl(p,q) (C3; proved in T15; QA5). Is this the right notion of state for the atlas’s cells, and how do entanglement and composite systems enter?',
   'C2 (exact, rational), F4, C3 (34 signatures with up to four generators).', 'Entanglement; composite systems; involutions other than the dagger one for positivity.'),
  ('E2', 'quantum foundations; finite geometry',
   'Items 2, Chapters 8–11: the finite shadow of the spectral theorem. The largest set of mutually commuting blades with square +1 spans R^(2^w), w the Witt index of the quadric of squares, and 2^w equals the number of simple factors times the matrix size N (W1). The counts are 5 points for Cl(4,0); 27 points and 45 lines for Cl(6,0) (the elliptic quadric Q⁻(5,2), not the Klein quadric, which is the class of Cl(3,3), Cl(4,2), Cl(0,6) with 35 points; T11); 135 points and 270 solids, two families of 135, for Cl(8,0) (W2, W3); Cl(2,2) has 9 points and 6 maximal sets, the shape of the Peres–Mermin square (recalled; the sign pattern is not checked in this package, it is proved from the bit rule in T11). Is this the known polar-space picture of Pauli-type groups, and which of the counts are new to the contextuality literature?',
   'W1–W3 by exhaustive enumeration over totally singular subspaces.', 'The identification with contextuality sets; infinite dimensions.'),
  ('E3', 'mathematical physics',
   'Item 3, Chapter 16: the fermionic and the bosonic ladder satisfy the same relations [N, a] = −a and [a, a⁺] = 1 once the commutator is a super-commutator; the dimension is 2ⁿ and the super-dimension is 0, which is what [a, a⁺] = 1 needs in finite dimension (an ordinary commutator has trace 0). Is “super-dimension 0” the finite shadow of why the bosonic ladder needs infinite dimension, and what is the right limit n → ∞ taking one into the other?',
   'B1 (n ≤ 4).', 'The bosonic side beyond the commutator relations; the limit.'),
  ('E4', 'mathematical physics',
   'Item 5: a single combined matrix with the geometry and quantum rows reordered along Schuller’s pipeline. This report adds the category column: its matrix has 40 rows against the same 22 atlas pages. The combined matrix (131 rows from the three reports) is in translation_matrix.json and keeps the three reports’ row orders; the reordering along the pipeline is not done.',
   'The category matrix; the merge of the three (131 × 22).', 'The reordering.'),
  ('E5', 'number theory; finite groups',
   'Horizon, “24”: the three families of 135 in Cl(8,0) are the three 135s of triality (W3, counted). Whether they are the three 8-bit bricks of the Golay code is not touched here.',
   'W3.', 'The Golay code; anything at 24.'),
  ('E6', 'quantum theory; number theory',
   'Horizon, the trio: timelike, null, spacelike as −1, 0, +1 is the trichotomy inert / ramified / split at n = 1 over F_p (L1b), and the clock does not distinguish the three at all beyond ±1 versus 0 (K4a). Is there a statement at n ≥ 2 (QC2) or in the energy-cone picture that makes “null” more than a resemblance?',
   'L1a, L1b.', 'Everything at n ≥ 2.'),
  ('E7', 'representation theory',
   'Horizon, layering: the filtration of Cl(p,q,r) by powers of the radical has layers C(r,k)·2^(p+q) (R2); the layer sizes of the E₈ root ladder in the Schuller report (240, 126, 72, 40, 20, 8 and 56, 27, 16, 10, 6) are a different count. No mechanism connects them and nothing here tests it.',
   'R2.', 'The link.'),
 ]),
]

DEAD_ENDS = [
 'Majkić’s “Cat-algebra” as a Clifford algebra of a vector space: the inner product is not additive along composition and the two Clifford properties are put in by definition (J1, J2). Kept: the quiver-form reading (J3).',
 'Reading Tian’s nilpotent generators as label 0: they come in hyperbolic pairs with square +1 and −1 combinations (T4). The label 0 of the truncations is the radical vector, which the relations do not display (T2).',
 'Peeling the null label off from the top by taking the even subalgebra: that step needs an invertible generator and fails for the exterior algebra on three or more generators (K5b; T5(d)); with one or two null generators and no other the even part is still a Clifford algebra.',
 'Replacing the scalar-part trace by the top-blade form as the state functional on algebras with null generators: the top-blade form is a Frobenius duality and never a state, and every state vanishes on the labels with a null bit (C3; T15); the scalar part is blind to the radical exactly as every state must be.',
 'A single “zero” in category language: the empty label is the unit object, the zero object is not used, and label 0 is a nilpotent element; the three are different objects (L0, answer card).',
 'The symmetric Frobenius form as a universal statement: ungraded, it holds for odd n or r = 0 only (F3); the top-blade form is not symmetric for every n, and the check says why (F2). In super vector spaces it is universal: the top-blade form is super-symmetric for every signature (bd·cat·5).',
 'Frobenius forms as a torsor under the central units: all Frobenius forms are λ(u·) with u any unit, and only the symmetric ones are a torsor under the central units (F5; T3). The reason for the non-symmetry at even n with a null generator is that every conjugator of the grade involution lies in the radical (F5). That is the ungraded dead end; in super vector spaces the super-symmetric Frobenius forms are λ(z·), a torsor under the units of the super-centre Λ(R^r), for every signature (bd·cat·8).',
]

LIMITS = [
 'Reading: the KTH notes, printed pages 1–31, 42–71, 73–76, 80–84, 87–110, 120–125 and the references (pp. 127–129); not read: pp. 32–41, 72, 77–79, 85–86, 111–119, 126 and the indices. Tian’s paper in full at the level of statements and proof strategy (its earlier paper arXiv:1210.5680 not read). The Tenfold Way in full (three pages). Majkić’s paper: the definitions of the Cat-arrows space, the norm, the inner product, the outer product and Corollary 2 were read and implemented; the Metacategory and comma-propagation parts were not examined.',
 'No proof in the four papers was re-derived. What was recomputed are the statements that can be recomputed on labels; every other statement is recalled and marked so.',
 'Recalled and not recomputed: Wall’s theorem and BW(R) = Z₈; Gabriel’s theorem; the representation type of Λ(k^r); the classification of quadratic spaces over F₂; the cochain-twist form of the octonions (Albuquerque–Majid); derived equivalences of incidence algebras; BW over finite fields. (The torsor statement for Frobenius forms is computed, F5.)',
 'Computed ranges: up to five generators for the radical and Frobenius tables (56 and 55 signatures), up to four for the grading lift, the states and the even-subalgebra isomorphism, up to six for the cube, the conjugators of the grade involution and the quadric counts, up to eight for the types and the Cl(8,0) geometry. Nothing is claimed beyond those ranges by this package; where a statement is proved for every n, the proof is a theorem of the page For researchers of the atlas (T2, T3, T9, T11, T15, T18; scripts in researchers_checks/), named as such.',
 'The signature tables of E₉, E₁₀, E₁₁ are computed from their Cartan matrices; that these are the affine, hyperbolic and Lorentzian Kac–Moody diagrams is recalled. “Lorentzian” is the signature of the Cartan form on the root lattice, not of a spacetime; nothing here touches E₁₀ or E₁₁ in supergravity.',
 'Two readings in the text are ours and carry that tag: calling n = 9, the only rung where det = 9 − n is 0 and the only one with a null direction, a “boundary” between the definite and the Lorentzian rungs; and reading the null direction of the symmetrised Euler form at n = 3 as a label 0 (the Tits form at n = 3 has signature (6,1,1) instead, T8). They are readings of computed signatures, not theorems.',
 'Layout was checked by screenshot at 1100 and 375 px, light and dark; drawings and the matrix scroll sideways on a phone instead of shrinking their text.',
]
