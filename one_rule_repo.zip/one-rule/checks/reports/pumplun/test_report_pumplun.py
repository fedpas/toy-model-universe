#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Tests of ../html/pumplun_dictionary_report.html against its own sources: the page is what build/build.py makes of build/*; its numbers are those of golden.json (the independent
Python run) and of the log of pumplun_checks.py; the 19 noise tests, 13 widgets and the points P1-P6 and questions Q1-Q7 are all there and cite things that exist; the page is written
about a paper, not to its author (no second person, no request, no name in a greeting); no history wording, no external request, no address; every script has the licence header.
Run: python3 test_report_pumplun.py          (about 40 seconds: a fresh quick run of pumplun_checks.py and of the JavaScript engine test)
     python3 test_report_pumplun.py --full   also the exhaustive MRD enumeration over F_8 (about 5 minutes) against golden.json
The browser part is test_page_pumplun.mjs (widgets, noise tests, phone width)."""
import os, re, sys, html, json, subprocess, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..'))
import no_history as NH
import status_check as SK
FULL = '--full' in sys.argv
PAGEF = os.path.join(HERE, '..', 'html', 'pumplun_dictionary_report.html')
page = open(PAGEF, encoding='utf-8').read()
plain = NH.visible(page)
ok = bad = 0; skipped = []
def chk(name, cond, msg=''):
    global ok, bad
    if cond: ok += 1
    else: bad += 1
    print(('ok   ' if cond else 'FAIL ') + name + (': ' + msg if (msg and not cond) else ''))
B = lambda f: open(os.path.join(HERE, 'build', f), encoding='utf-8').read()
G = json.load(open(os.path.join(HERE, 'golden.json')))
LOG = open(os.path.join(HERE, 'logs', 'pumplun_checks.log'), encoding='utf-8').read()
N = lambda x: f'{x:,}'

# --- 1. the page is what the sources make; the sources and the numbers
tmp = tempfile.mkdtemp(prefix='pumplun_build_')
try:
    dst = os.path.join(tmp, 'p.html'); subprocess.run([sys.executable, os.path.join(HERE, 'build', 'build.py'), dst], check=True, capture_output=True)
    chk('T1 the shipped page is exactly what build/build.py makes of build/*', open(dst, encoding='utf-8').read() == page)
finally: shutil.rmtree(tmp, ignore_errors=True)
chk('T2 six numbered log lines of the independent run are present and none fails', re.search(r'checks: (\d+) ok, 0 failed', LOG) is not None and len(re.findall(r'^ok   C\d+:', LOG, re.M)) == int(re.search(r'checks: (\d+) ok', LOG).group(1)) >= 9)
g = G['F9_exh']
chk('T3 headline numbers of the page equal golden.json (23,040 algebras, 3,200 division algebras, 0 disagreements, 6,400 monic disagreements)',
    g['total'] == 23040 and N(g['total']) in plain and N(g['division']) in plain and g['full_mismatch'] == 0 and 'tested against Theorem 3.2 of the paper: 0 disagreements' in plain
    and N(g['monic_mismatch']) in plain and f'{N(g["monic_mismatch"])} of 15,360' in plain and '7,680 algebras' in plain and 7680 + 15360 == g['total'])
chk('T4 class counts of the page equal golden.json (F9: 30 in 3 classes of 10; F27: 273 in 3 classes of 91)',
    G['F9_irr'] == 30 and G['F9_class_sizes'] == [10, 10, 10] and 'the 30 monic irreducible quadratics fall into 3 classes of 10' in plain
    and G['F27_irr'] == 273 and G['F27_class_sizes'] == [91, 91, 91] and f'We count {G["F27_irr"]} monic irreducible quadratics in 𝔽₂₇[t;σ], in three classes of 91' in plain)
f8 = G['F8_l2']
chk('T5 the MRD numbers of the page equal golden.json (4,704 cases over F_8, 4,676 agree with the literal reading, 4,704 with the divisor reading)',
    f8['cases'] == 4704 and f8['agree_divisor_criterion'] == 4704 and f8['agree_product_criterion'] == 4676 and f'{N(f8["agree_product_criterion"])} of the {N(f8["cases"])} cases over 𝔽₈' in plain
    and f'exact in all {N(f8["cases"])} cases over 𝔽₈' in plain and f'{N(f8["cases"])} + 150 MRD cases' in plain and 'only 21 divide h' in plain)
# --- 2. what is on the page
SEC = ['0 · The atlas in one page', '1 · Dictionary', '2 · Build up from zero', '3 · Noise', '4 · What was reproduced, and what is to check', '5 · Build down',
       '6 · The atlas’s views and lenses, in the paper’s language', '7 · Open questions', '8 · Glossary and references']
heads = [re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', h))).strip() for h in re.findall(r'<h2>(.*?)</h2>', page, re.S)]
chk('T6 nine sections with the present headings, in order, and the navigation links to them', [h.split(' ', 3)[0] + ' ' + h.split(' ', 3)[1] for h in heads] == [s.split(' ', 2)[0] + ' ' + s.split(' ', 2)[1] for s in SEC]
    and all(s in heads[i] for i, s in enumerate(SEC)) and all(f'href="#s{i}"' in page and f'<section id="s{i}">' in page for i in range(9)), str(heads))
_leg = SK.chips(page.split('<div class="tags">')[1].split('</div>')[0])
chk('T7 the head: title, kick with the date of issue, status notice, the legend of the five kinds of status as icon chips (standard: textbook; standard: a statement of the paper; checked; ours; open: to check), four figures',
    '<title>Bit rule, crossed products and Petit algebras: a dictionary report</title>' in page and 'Preliminary · dictionary report · 7 October 2026' in plain
    and 'Unreviewed and preliminary; written by the atlas authors with computer-algebra help.' in plain and len(re.findall(r'<div class="kpi">', page)) == 4
    and [(c[0], c[1]) for c in _leg] == [('standard', 'standard'), ('standard', 'standard: a statement of the paper'), ('checked', 'checked'), ('ours', 'ours'), ('open', 'open: to check')]
    and [c[2] for c in _leg] == ['standard: textbook', 'standard: a statement of the paper', 'checked: recomputed by a widget on this page', 'ours: what the atlas claims', 'open: to check, differs from our reading of the paper']
    and all(c in plain for c in ('a statement of the paper', 'textbook', 'recomputed by a widget on this page', 'what the atlas claims', 'to check, differs from our reading of the paper')))
BODY = re.sub(r'<script.*?</script>|<style.*?</style>', '', page, flags=re.S)
chk('T8 the thirteen widgets W0-W12 and the noise table are placeholders in the page and have code', all(len(re.findall(rf'data-w="W{i}"', BODY)) == 1 for i in range(13)) and BODY.count('data-w="NOISE"') == 1
    and all(f"mount('W{i}'" in B('widgets.js') for i in range(13)))
tests = re.findall(r"\{id:'(N\d+)',tag:'(\w+)'", B('noise.js'))
chk('T9 the 19 noise tests N1-N19 exist; four are tagged paper, six ask (the points that differ from the statement as read), the rest standard or atlas', [t[0] for t in tests] == ['N%d' % i for i in range(1, 20)]
    and [t[0] for t in tests if t[1] == 'paper'] == ['N2', 'N4', 'N5', 'N16'] and [t[0] for t in tests if t[1] == 'ask'] == ['N3', 'N6', 'N7', 'N17', 'N18', 'N19'], str(tests))
chk('T10 the page says 19 noise tests, and "13 passed, 6 differ" is what the report below states in the test of the browser', '19</b><span>noise and null tests that run in the browser (§3)' in page and len(tests) == 19)
def sec(i): return re.search(rf'<section id="s{i}">(.*?)</section>', page, re.S).group(1)
cited = set(re.findall(r'\b([NW]\d+)\b', plain)); have = {t[0] for t in tests} | {f'W{i}' for i in range(13)}
chk('T11 every N and W id the page cites exists', cited <= have and len(cited) >= 25, str(sorted(cited - have)))
chk('T12 every one of the 19 noise tests and 13 widgets is cited somewhere in the text of the sections 1-7', all(re.search(rf'\b{i}\b', ' '.join(re.sub(r'<[^>]+>', ' ', sec(k)) for k in range(1, 8))) for i in sorted(have - {'N1', 'N15'})), '')
P = re.findall(r'<tr><td>(P\d)</td>', sec(4)); Q = re.findall(r'<b>(Q\d) \(([^)]*)\)', sec(7))
chk('T13 six points P1-P6 in section 4 and seven questions Q1-Q7 in section 7; Q4-Q7 cite the points they come from', P == ['P%d' % i for i in range(1, 7)] and [q[0] for q in Q] == ['Q%d' % i for i in range(1, 8)]
    and dict(Q)['Q4'] == 'P1' and dict(Q)['Q5'] == 'P2' and dict(Q)['Q6'] == 'P3' and dict(Q)['Q7'] == 'P4–P6', str(P) + str(Q))
chk('T14 the points are present caveats about our reading, in neutral words (K7)', 'each such point may come from a misreading of the statement or its hypotheses on our side' in plain
    and 'In each case the difference may come from a misreading of the statement or its hypotheses on our side' in plain and 'Two readings are possible; which one is intended is the question Q6.' in plain
    and 'A row that says differs from the statement as we read it is a point of §4, not a failure of the page' in plain)
chk('T15 the dictionary table of section 1 has its fourteen rows with a "where checked" column', len(re.findall(r'<tr>', sec(1))) == 15 and 'in the paper’s language' in sec(1) and 'where checked' in sec(1))
chk('T16 section 6: the horizon sentence is the present one; the lenses (Baez, Schuller, Furey, finite-group, category) are described', 'the atlas states each of them separately. These readings also use inputs that the rule does not supply' in plain
    and all(x in plain for x in ('Category lens', 'Finite-group lens', 'Baez lens', 'Schuller lens', 'Furey lens', 'Clock · trinity, gauge gravity')))
chk('T17 the page states what it does not do: the physics and the paper are not claimed', 'The page makes no claim about the physics; this is the reason it stays at the level of cochains and classes.' in plain
    and 'Not tested individually: Theorems 3.8, 3.10, 4.2, 6.2, 6.7' in plain and 'They are sufficient conditions or formulas, and were read but not re-run.' in plain)
chk('T18 where the scripts are: the package folder, in the present tense; the footer', 'The JavaScript engine of this page and the independent Python scripts are in the package folder reports/pumplun/.' in plain
    and 'This page runs entirely in your browser; it contains no personal data and loads nothing from the network.' in plain and 'preliminary report, 7 October 2026' in plain)
# --- 3. a page about a paper, not a message to its author
second = re.findall(r'\b(you|your|yours|yourself)\b', plain, re.I)
chk('T19 no second person except "your browser" (the reader\'s own browser: twice)', sorted(w.lower() for w in second) == ['your', 'your'] and plain.count('in your browser') == 2, str(second))
FORBID = ['for S. Pumplün', 'written for', 'Questions for you', 'your Theorem', 'your paper', 'your §', 'your class', 'your Remark', 'your construction', 'your binomial', 'we would be glad', 'please say so',
          'we will update', 'Do you agree', 'do you intend', 'we would like to', 'would like to know', 'hers', 'her list', 'We do not ask you', 'loose reading', 'Dear ', 'Referee', 'referee', 'with you']
chk('T20 none of the sentences addressed to the author is on the page (test-side list of forbidden strings)', not [f for f in FORBID if f in plain], str([f for f in FORBID if f in plain]))
pum = [plain[max(0, m.start() - 12): m.end()] for m in re.finditer('Pumplün', plain)]
chk('T21 the name of the author appears only as a name in a bibliography or in the title of a source (S. Pumplün, Baez and Pumplün, Baez, S. Pumplün)', all(re.search(r'(S\. |and |, S\. )Pumplün$|Pumplün$', p) for p in pum) and not re.search(r'(Dear|Hello|Hi|Thanks|Thank) +\w* *Pumplün', plain), str(pum))
chk('T22 no chip, class or variable of the page still says "hers"', 'hers' not in page and '--hers' not in page and re.search(r'\bHER\b', page) is None)
# --- 4. no history, no address, no network
chk('T23 no history in the visible text of the page (shared pattern list, reports/no_history.py); every "<" in a text node is written &lt;, so the reader sees all the text', not NH.scan_page(page) and not NH.bare_lt(page), NH.scan_page(page)[:3])
chk('T24 the history scan catches its planted phrases', not NH.selftest(), NH.selftest())
chk('T25 no external request (links to arxiv.org only), no script from outside, no image', not (re.search(r'(src|href)="https?://(?!arxiv\.org)', page) or 'url(http' in page or '@import' in page or re.search(r'<script[^>]+src=', page) or re.search(r'<link[^>]+href', page) or '<img' in page))
EMAIL = r'[\w.+-]+@[\w-]+\.[\w.]+'
chk('T26 no e-mail address, no mail link, no "@" except in CSS @media rules', not re.search(EMAIL, page) and ('mail' + 'to:') not in page and not re.search(r'@(?!media)', re.sub(r'<style.*?</style>', lambda m: re.sub(r'@media', '', m.group(0)), page, flags=re.S)))
chk('T27 themes and guards present; the viewport is set', 'prefers-color-scheme: dark' in page and ':root[data-theme="dark"]' in page and ':root:not([data-theme="light"])' in page and 'name="viewport"' in page)
chk('T28 size is reasonable (< 400 kB), the script and the style are inline', len(page.encode('utf-8')) < 400_000 and '<script>' in page and '<style>' in page)
# --- 5. sources, scripts, licence
hdr = ('SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', 'Required Notice: Copyright (c) 2026 the Cascade Atlas authors', 'Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)')
files = [os.path.join('build', f) for f in sorted(os.listdir(os.path.join(HERE, 'build'))) if f.endswith(('.js', '.py', '.css'))] + ['pumplun_checks.py', 'test_report_pumplun.py', 'test_page_pumplun.mjs']
chk('T29 every script and style file of the folder carries the three-line licence header', all(all(h in '\n'.join(open(os.path.join(HERE, f), encoding='utf-8').read().split('\n')[:6]) for h in hdr) for f in files), str([f for f in files if not all(h in open(os.path.join(HERE, f), encoding='utf-8').read()[:700] for h in hdr)]))
chk('T30 the folder holds no cover note and no letter (what ships is the page, its sources, its scripts, its logs)', not [f for f in os.listdir(HERE) if re.search(r'letter|outreach|errata|CORRECTION|pumplun_report\.md', f, re.I)])
# --- 6. the independent re-run (fresh) and the engine against it
def run(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)
out = os.path.join(tempfile.mkdtemp(prefix='pumplun_run_'), 'q.json')
r = run([sys.executable, os.path.join(HERE, 'pumplun_checks.py')] + (['--full'] if FULL else []) + ['--out', out], cwd=HERE)
okl = lambda t: [l for l in t.split('\n') if re.match(r'(ok  |FAIL) ', l)]
rec = okl(LOG)
chk('T31 a fresh run of pumplun_checks.py exits 0 and its ok lines are the first ' + str(len(rec)) + ' of the recorded log' if not FULL else 'T31 a fresh full run exits 0', r.returncode == 0 and okl(r.stdout)[:len(rec)] == rec if not FULL else r.returncode == 0, r.stdout[-400:] + r.stderr[-400:])
Fr = json.load(open(out)) if os.path.exists(out) else {}
common = [k for k in Fr if k in G]
chk('T32 the numbers of that run equal golden.json on every key they share (' + ', '.join(common[:4]) + ' ...)' + (' (full: every key of golden.json)' if FULL else ''), len(common) >= 6 and all(Fr[k] == G[k] for k in common) and (not FULL or set(Fr) >= set(G)), str([k for k in common if Fr[k] != G[k]]))
if FULL:
    chk('T33 the F_8 enumeration (4,704 cases) is in golden.json and equals the run', G['F8_l2'] == Fr.get('F8_l2'))
else: skipped.append('T33 (F_8 enumeration; --full)')
node = shutil.which('node')
if node:
    r = run([node, 'test_engine.js'], cwd=os.path.join(HERE, 'build'), timeout=900)
    chk('T34 the JavaScript engine of the page gives the numbers of golden.json (F_9 exhaustive 23,040, F_27 counts), build/test_engine.js', r.returncode == 0 and 'ALL OK' in r.stdout, r.stdout[-300:] + r.stderr[-300:])
else: skipped.append('T34 (no node)')
shutil.rmtree(os.path.dirname(out), ignore_errors=True)
# --- 7. the status chips: icons, never words
F4 = ('checked', 'standard', 'ours', 'open')
_noise = B('lib.js') + B('noise.js')            # lib.js: chip(kind, place) makes the chips of the noise table; /*@@CHIPS@@*/ is replaced by build.py
chk('T35 every status of the page is an icon chip (role img, name and hover text start with the word, the drawing of the atlas badge, no word chip, one legend entry per flag); the four flags are used; the noise table makes the same chips from the table CHIP_KINDS that build.py writes into lib.js',
    not SK.problems(page, F4) and set(SK.kinds(page)) == set(F4) and len(SK.chips(page)) >= 40 and 'class="cref"' in page and '/*@@CHIPS@@*/' in _noise and 'function chip(kind,place)' in _noise and not re.search(r'class="tg ', page + _noise)
    and {t[1] for t in tests} <= set(re.findall(r"^    '(\w+)': \(", B('build.py'), re.M)) == {'paper', 'std', 'chk', 'ours', 'ask'},
    str(SK.problems(page, F4)[:3]))
print(f'\ntest_report_pumplun: {ok} ok, {bad} failed' + (f', {len(skipped)} skipped: ' + '; '.join(skipped) if skipped else '')); sys.exit(1 if bad else 0)
