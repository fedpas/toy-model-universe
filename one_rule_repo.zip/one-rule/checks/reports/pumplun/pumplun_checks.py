#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Independent finite-field re-run of the main statements of S. Pumplun, arXiv:2606.18371 (Python 3, standard library only).

Contents: GF(p^n) arithmetic, K[t;sigma], the algebras S_f(K,i0,nu,rho), division test (every left multiplication injective),
Theorem 3.2 vs brute force over F_9 (all 23,040 algebras), the monic reduction of Proposition 3.5 vs brute force,
class counts over F_9 and F_27, Example 7.4's matrix criterion, the hand-checkable counterexamples (P1, P3) and the sign cochains of Q2; with --full also the MRD enumeration over F_8 (l = 2, 4,704 cases; a few minutes).
Usage: python3 pumplun_checks.py [--full] [--out FILE.json]
Prints the computations, then one line per claim of the report "ok   C<n>: ..." (or "FAIL"), and exits 1 if a claim fails.  --out writes the numbers as JSON;
the shipped golden.json is the result of: python3 pumplun_checks.py --full --out golden.json   (about 5 minutes; without --full about 15 seconds).
"""
import sys, json, itertools, time, random
FULL='--full' in sys.argv

# ===== ff.py =====
# Independent finite-field + skew-polynomial engine (Python, plain ints). Used to explore and later cross-check the JS engine.

class GF:
    """GF(p^n), elements are ints 0..p^n-1 in base-p digit representation of a polynomial in x mod modpoly.
    sigma = Frobenius x->x^p (generator of Gal(K/F_p))."""
    def __init__(self, p, n, modpoly):
        # modpoly: list of n+1 coeffs low->high, monic, irreducible
        self.p, self.n, self.size = p, n, p**n
        self.mod = modpoly
        self.q = self.size
        # build mult via polynomial arithmetic then tables
        def to_vec(a):
            v=[]
            for _ in range(n):
                v.append(a%p); a//=p
            return v
        def to_int(v):
            a=0
            for c in reversed(v): a=a*p+c
            return a
        self.to_vec, self.to_int = to_vec, to_int
        def pmul(a,b):
            va,vb=to_vec(a),to_vec(b)
            res=[0]*(2*n-1)
            for i,x in enumerate(va):
                if x:
                    for j,y in enumerate(vb):
                        res[i+j]=(res[i+j]+x*y)%p
            for d in range(2*n-2,n-1,-1):
                c=res[d]
                if c:
                    for k in range(n+1):
                        res[d-n+k]=(res[d-n+k]-c*modpoly[k])%p
            return to_int(res[:n])
        self.mul_tab=[[pmul(a,b) for b in range(self.size)] for a in range(self.size)]
        self.add_tab=[[to_int([(x+y)%p for x,y in zip(to_vec(a),to_vec(b))]) for b in range(self.size)] for a in range(self.size)]
        self.neg_tab=[to_int([(-x)%p for x in to_vec(a)]) for a in range(self.size)]
        self.inv_tab=[0]*self.size
        for a in range(1,self.size):
            for b in range(1,self.size):
                if self.mul_tab[a][b]==1: self.inv_tab[a]=b;break
        # frobenius
        def pw(a,e):
            r=1
            for _ in range(e): r=self.mul_tab[r][a]
            return r
        self.frob=[pw(a,p) for a in range(self.size)]
        self.pw=pw
    def add(self,a,b): return self.add_tab[a][b]
    def sub(self,a,b): return self.add_tab[a][self.neg_tab[b]]
    def neg(self,a): return self.neg_tab[a]
    def mul(self,a,b): return self.mul_tab[a][b]
    def inv(self,a): return self.inv_tab[a]
    def sig(self,a,k=1):
        k%=self.n
        for _ in range(k): a=self.frob[a]
        return a
    def norm(self,a):  # N_{K/F}(a) = a * s(a) * ... * s^{n-1}(a)
        r=1; x=a
        for _ in range(self.n):
            r=self.mul_tab[r][x]; x=self.frob[x]
        return r

def make_F9():
    # F_3[i]/(i^2+1); element a+b i -> int a+3b. modpoly x^2+1 -> [1,0,1]
    return GF(3,2,[1,0,1])

class Skew:
    """K[t;sigma] with sigma=Frobenius^s? we use sigma = Frobenius power 'sg' (default 1) -- must generate Gal(K/F_p) (gcd(sg,n)=1)."""
    def __init__(self,K,sg=1):
        self.K=K; self.sg=sg
    def s(self,a,i): return self.K.sig(a,self.sg*i)
    def trim(self,g):
        g=list(g)
        while g and g[-1]==0: g.pop()
        return g
    def add(self,g,h):
        K=self.K; m=max(len(g),len(h)); r=[]
        for i in range(m):
            r.append(K.add(g[i] if i<len(g) else 0, h[i] if i<len(h) else 0))
        return self.trim(r)
    def smul(self,c,g): return self.trim([self.K.mul(c,x) for x in g])
    def mul(self,g,h):
        K=self.K
        if not g or not h: return []
        r=[0]*(len(g)+len(h)-1)
        for i,a in enumerate(g):
            if a==0: continue
            for j,b in enumerate(h):
                if b==0: continue
                r[i+j]=K.add(r[i+j],K.mul(a,self.s(b,i)))
        return self.trim(r)
    def divmod_r(self,g,f):
        """right division g = q f + r, f monic? (we need leading coeff invertible, general)."""
        K=self.K; g=self.trim(g); f=self.trim(f)
        df=len(f)-1; q=[]; r=list(g)
        qd=[0]*max(0,len(g)-df)
        while len(r)-1>=df and r:
            d=len(r)-1-df
            # lead(r) = c * s^d(lead(f))  => c = lead(r) / s^d(lead f)
            c=K.mul(r[-1],K.inv(self.s(f[-1],d)))
            qd[d]=c
            # subtract c t^d f
            sub=[0]*d+[K.mul(c,self.s(x,d)) for x in f]
            r=self.trim([K.sub(r[i] if i<len(r) else 0, sub[i] if i<len(sub) else 0) for i in range(max(len(r),len(sub)))])
        return self.trim(qd), r
    def modr(self,g,f): return self.divmod_r(g,f)[1]

# ===== pum.py =====
# Pumplun's algebras S_f(K,i0,nu,rho) over K=F_{p^n}, sigma=Frobenius, F=F_p. Independent Python implementation.

class Alg:
    def __init__(self,K,f,i0,nu,rho):
        """f: list of coefficients low->high, monic degree m. rho: python function K->K (F_p-linear bijection). Elements of R_m: tuples length m of K."""
        self.K=K; self.R=Skew(K); self.f=list(f); self.m=len(f)-1; self.i0=i0; self.nu=nu; self.rho=rho
    def mul(self,b,c):
        K=self.K; R=self.R; m=self.m
        left=list(b)+[K.mul(self.nu,self.rho(b[self.i0]))]
        prod=R.mul(R.trim(left),R.trim(list(c)))
        r=R.modr(prod,self.f)
        r=r+[0]*(m-len(r))
        return tuple(r)

def elements(K,m):
    return itertools.product(range(K.size),repeat=m)

def is_division(A):
    """brute force: no zero divisors (finite => division). returns (bool, witness)"""
    m=A.m; K=A.K
    els=[e for e in elements(K,m) if any(e)]
    zero=tuple([0]*m)
    for b in els:
        for c in els:
            if A.mul(b,c)==zero: return False,(b,c)
    return True,None

def make_rho(K,y):
    """rho(x)=sum_i y_i sigma^i(x)"""
    def rho(x):
        r=0
        for i,yi in enumerate(y):
            if yi: r=K.add(r,K.mul(yi,K.sig(x,i)))
        return r
    return rho

# ===== la.py =====
# F_p linear algebra helpers
def rank_mod(M,p):
    M=[row[:] for row in M]; r=0; rows=len(M); cols=len(M[0]) if M else 0
    for c in range(cols):
        piv=None
        for i in range(r,rows):
            if M[i][c]%p: piv=i;break
        if piv is None: continue
        M[r],M[piv]=M[piv],M[r]
        inv=pow(M[r][c],-1,p)
        M[r]=[(x*inv)%p for x in M[r]]
        for i in range(rows):
            if i!=r and M[i][c]%p:
                f=M[i][c]
                M[i]=[(x-f*y)%p for x,y in zip(M[i],M[r])]
        r+=1
        if r==rows: break
    return r
def nullspace_mod(M,p):
    """M: rows x cols; returns basis of {x: M x = 0}"""
    rows=len(M); cols=len(M[0])
    A=[row[:] for row in M]; piv=[]; r=0
    for c in range(cols):
        pi=None
        for i in range(r,rows):
            if A[i][c]%p: pi=i;break
        if pi is None: continue
        A[r],A[pi]=A[pi],A[r]
        inv=pow(A[r][c],-1,p)
        A[r]=[(x*inv)%p for x in A[r]]
        for i in range(rows):
            if i!=r and A[i][c]%p:
                f=A[i][c]; A[i]=[(x-f*y)%p for x,y in zip(A[i],A[r])]
        piv.append(c); r+=1
        if r==rows: break
    free=[c for c in range(cols) if c not in piv]
    basis=[]
    for fc in free:
        v=[0]*cols; v[fc]=1
        for i,pc in enumerate(piv):
            v[pc]=(-A[i][fc])%p
        basis.append(v)
    return basis

# ===== balg.py =====
# generic finite-dimensional algebra over F_p given by structure constants; nuclei, center, unit, division
class BAlg:
    def __init__(self,p,d,T):
        """T[j][k] = list of d ints (coords of e_j * e_k)"""
        self.p=p; self.d=d; self.T=T
    def mul(self,x,y):
        p=self.p; d=self.d; r=[0]*d
        for j in range(d):
            if x[j]:
                for k in range(d):
                    if y[k]:
                        c=x[j]*y[k]
                        t=self.T[j][k]
                        for i in range(d):
                            if t[i]: r[i]=(r[i]+c*t[i])%p
        return r
    def e(self,j):
        v=[0]*self.d; v[j]=1; return v
    def nuclei(self):
        """returns (dim Nuc_l, dim Nuc_m, dim Nuc_r) as F_p vector spaces, and dim Comm, dim center"""
        p,d=self.p,self.d
        E=[self.e(j) for j in range(d)]
        # precompute products
        # left nucleus: x such that (x y)z = x (y z) for all basis y,z
        rowsL=[];rowsM=[];rowsR=[]
        # unknown x as vector in F_p^d: build matrix columns by evaluating associator for x=e_i
        for (y,z) in itertools.product(range(d),repeat=2):
            # for each output coord we need row; build d x d matrix: rows=output coord, cols=i
            colsL=[];colsM=[];colsR=[]
            for i in range(d):
                # left: x=e_i
                a=self.mul(self.mul(E[i],E[y]),E[z]); b=self.mul(E[i],self.mul(E[y],E[z]))
                colsL.append([(u-v)%p for u,v in zip(a,b)])
                # middle: [y,x,z]
                a=self.mul(self.mul(E[y],E[i]),E[z]); b=self.mul(E[y],self.mul(E[i],E[z]))
                colsM.append([(u-v)%p for u,v in zip(a,b)])
                # right: [y,z,x]
                a=self.mul(self.mul(E[y],E[z]),E[i]); b=self.mul(E[y],self.mul(E[z],E[i]))
                colsR.append([(u-v)%p for u,v in zip(a,b)])
            for o in range(d):
                rowsL.append([colsL[i][o] for i in range(d)])
                rowsM.append([colsM[i][o] for i in range(d)])
                rowsR.append([colsR[i][o] for i in range(d)])
        nl=len(nullspace_mod(rowsL,p)); nm=len(nullspace_mod(rowsM,p)); nr=len(nullspace_mod(rowsR,p))
        return nl,nm,nr
    def nucleus_basis(self,which):
        p,d=self.p,self.d
        E=[self.e(j) for j in range(d)]
        rows=[]
        for (y,z) in itertools.product(range(d),repeat=2):
            cols=[]
            for i in range(d):
                if which=='l': a=self.mul(self.mul(E[i],E[y]),E[z]); b=self.mul(E[i],self.mul(E[y],E[z]))
                if which=='m': a=self.mul(self.mul(E[y],E[i]),E[z]); b=self.mul(E[y],self.mul(E[i],E[z]))
                if which=='r': a=self.mul(self.mul(E[y],E[z]),E[i]); b=self.mul(E[y],self.mul(E[z],E[i]))
                cols.append([(u-v)%p for u,v in zip(a,b)])
            for o in range(d): rows.append([cols[i][o] for i in range(d)])
        return nullspace_mod(rows,p)
    def is_division(self):
        p,d=self.p,self.d
        # L_x injective for all x != 0 ; enumerate all x (p^d)
        for x in itertools.product(range(p),repeat=d):
            if not any(x): continue
            M=[self.mul(list(x),self.e(j)) for j in range(d)]
            if rank_mod(M,p)<d: return False
        return True
    def left_unit(self):
        # u with u*x = x all x: linear system
        p,d=self.p,self.d
        rows=[];rhs=[]
        # unknown u (d coords); for each basis y: sum_j u_j T[j][y] = e_y
        import itertools
        A=[];B=[]
        for y in range(d):
            for o in range(d):
                A.append([self.T[j][y][o] for j in range(d)]); B.append(1 if o==y else 0)
        return solve_mod(A,B,p)
    def right_unit(self):
        p,d=self.p,self.d
        A=[];B=[]
        for y in range(d):
            for o in range(d):
                A.append([self.T[y][j][o] for j in range(d)]); B.append(1 if o==y else 0)
        return solve_mod(A,B,p)
def solve_mod(A,B,p):
    rows=len(A); cols=len(A[0])
    M=[A[i][:]+[B[i]] for i in range(rows)]
    r=0; piv=[]
    for c in range(cols):
        pi=None
        for i in range(r,rows):
            if M[i][c]%p: pi=i;break
        if pi is None: continue
        M[r],M[pi]=M[pi],M[r]
        inv=pow(M[r][c],-1,p); M[r]=[(x*inv)%p for x in M[r]]
        for i in range(rows):
            if i!=r and M[i][c]%p:
                f=M[i][c]; M[i]=[(x-f*y)%p for x,y in zip(M[i],M[r])]
        piv.append(c); r+=1
        if r==rows: break
    for i in range(r,rows):
        if M[i][cols]%p: return None
    sol=[0]*cols
    for i,c in enumerate(piv): sol[c]=M[i][cols]
    return sol

def from_pum(A):
    """Convert pum.Alg to BAlg over F_p"""
    K=A.K; m=A.m; p=K.p; n=K.n
    d=m*n
    def vec(e):
        out=[]
        for c in e: out+=K.to_vec(c)
        return out
    def unvec(v):
        return tuple(K.to_int(v[i*n:(i+1)*n]) for i in range(m))
    basis=[unvec([1 if k==j else 0 for k in range(d)]) for j in range(d)]
    T=[[vec(A.mul(basis[j],basis[k])) for k in range(d)] for j in range(d)]
    return BAlg(p,d,T),vec,unvec

# ---- spread-set invariants (idealisers, centraliser) ----
def matL(B,a):
    """matrix of L_a: columns = a*e_j  (as d x d list rows)"""
    d=B.d
    cols=[B.mul(a,B.e(j)) for j in range(d)]
    return [[cols[j][i] for j in range(d)] for i in range(d)]
def matR(B,a):
    d=B.d
    cols=[B.mul(B.e(j),a) for j in range(d)]
    return [[cols[j][i] for j in range(d)] for i in range(d)]
def matmul(A,Bm,p):
    d=len(A)
    return [[sum(A[i][k]*Bm[k][j] for k in range(d))%p for j in range(d)] for i in range(d)]
def flat(M): return [x for row in M for x in row]
def spread(B,which='L'):
    d=B.d
    f=matL if which=='L' else matR
    return [f(B,B.e(j)) for j in range(d)]
def annihilator(mats,p):
    rows=[flat(M) for M in mats]
    return nullspace_mod(rows,p)   # vectors w with <M,w>=0 for all M in C
def idealiser_dims(B,which='L'):
    """returns (dim I_l, dim I_r, dim Cent) of spread set C_L or C_R"""
    p,d=B.p,B.d
    C=spread(B,which)
    W=annihilator(C,p)
    # unknown Phi (d x d) as d*d vector, index a*d+b
    def lin_conditions(kind):
        rows=[]
        for Mj in C:
            # Y = Phi*Mj  (kind 'l') or Mj*Phi ('r') ; condition <Y,w>=0 for all w in W
            for w in W:
                row=[0]*(d*d)
                for a in range(d):
                    for b in range(d):
                        # coefficient of Phi_{ab}
                        if kind=='l':
                            # Y_{ac} = sum_b Phi_{ab} Mj_{bc}; <Y,w>=sum_{a,c} Y_{ac} w_{ac}
                            row[a*d+b]=sum(Mj[b][c]*w[a*d+c] for c in range(d))%p
                        else:
                            # Y_{cb} = sum_a Mj_{ca} Phi_{ab}; <Y,w>=sum_{c,b} Y_{cb} w_{cb}
                            row[a*d+b]=sum(Mj[c][a]*w[c*d+b] for c in range(d))%p
                rows.append(row)
        return rows
    def cent_conditions():
        rows=[]
        for Mj in C:
            # Phi*Mj - Mj*Phi = 0: entry (i,k): sum_b Phi_{ib} Mj_{bk} - sum_a Mj_{ia} Phi_{ak}
            for i in range(d):
                for k in range(d):
                    row=[0]*(d*d)
                    for b in range(d): row[i*d+b]=(row[i*d+b]+Mj[b][k])%p
                    for a in range(d): row[a*d+k]=(row[a*d+k]-Mj[i][a])%p
                    rows.append(row)
        return rows
    il=len(nullspace_mod(lin_conditions('l'),p)) if W else d*d
    ir=len(nullspace_mod(lin_conditions('r'),p)) if W else d*d
    ce=len(nullspace_mod(cent_conditions(),p))
    return il,ir,ce

# ===== checks =====
# Golden numbers from the independent Python engine (ff.py, pum.py, balg.py, la.py)
out={}
t0=time.time()
# ---- F_9, m=2 ----
K=make_F9(); R=Skew(K); p=3; m=2
def irreducibles_py(K,R,m):
    res=[]
    for idx in range(K.size**m):
        x=idx; c=[]
        for i in range(m): c.append(x%K.size); x//=K.size
        f=c+[1]
        ok=True
        for d in range(1,m):
            for jdx in range(K.size**d):
                y=jdx; g=[]
                for i in range(d): g.append(y%K.size); y//=K.size
                if R.modr(f,g+[1])==[]: ok=False;break
            if not ok: break
        if ok: res.append(f)
    return res
irr=irreducibles_py(K,R,2)
out['F9_irr']=len(irr)
def vecr(r,m,K):
    r=r+[0]*(m-len(r)); o=[]
    for c in r: o+=K.to_vec(c)
    return o
def bound_py(R,K,f):
    m=len(f)-1; n=K.n
    vs=[]
    for j in range(0,m+2):
        v=vecr(R.modr([0]*(n*j)+[1],f),m,K); vs.append(v)
        for d in range(1,j+1):
            pass
    for d in range(1,m+2):
        for cs in itertools.product(range(K.p),repeat=d):
            tot=[0]*len(vs[0])
            for c,x in zip(cs,vs[:d]): tot=[(t+c*y)%K.p for t,y in zip(tot,x)]
            if tot==vs[d]: return tuple((-c)%K.p for c in cs)+(1,)
classes={}
for f in irr: classes.setdefault(bound_py(R,K,f),[]).append(f)
out['F9_class_sizes']=sorted(len(v) for v in classes.values())
out['F9_bounds']=sorted(','.join(map(str,b)) for b in classes)
# exhaustive Theorem 3.2 vs brute force
def is_div(K,m,A,p):
    d=m*K.n
    basis=[]
    for j in range(m):
        for e in range(K.n):
            v=[0]*m; v[j]=K.p**e; basis.append(tuple(v))
    def vec(e):
        o=[]
        for c in e: o+=K.to_vec(c)
        return o
    T=[[vec(A.mul(b1,b2)) for b2 in basis] for b1 in basis]  # T[j][k]
    for x in itertools.product(range(p),repeat=d):
        if not any(x): continue
        M=[[sum(x[j]*T[j][k][i] for j in range(d))%p for i in range(d)] for k in range(d)]
        if rank_mod(M,p)<d: return False
    return True
rhos=[]
for y0 in range(9):
    for y1 in range(9):
        rho=make_rho(K,[y0,y1])
        if sorted(rho(x) for x in range(9))==list(range(9)): rhos.append((y0,y1))
out['F9_rho_count']=len(rhos)
cnt_div=0; bad_full=0; bad_monic=0; tot=0
for cl in classes.values():
    sim=cl
    for f in cl:
        for i0 in (0,1):
            for (y0,y1) in rhos:
                rho=make_rho(K,[y0,y1])
                for nu in range(1,9):
                    A=Alg(K,f,i0,nu,rho)
                    d=is_div(K,2,A,3)
                    full=True
                    for g in sim:
                        gi=g[i0]
                        if gi==0: continue
                        c=K.mul(nu,gi)
                        for x in range(1,9):
                            if K.mul(c,rho(x))==x: full=False;break
                        if not full: break
                    monic=True
                    for g in sim:
                        gi=g[i0]
                        if gi!=0 and K.mul(nu,rho(gi))==1: monic=False;break
                    tot+=1; cnt_div+=d
                    bad_full+= (d!=full); bad_monic+=(d!=monic)
out['F9_exh']={'total':tot,'division':cnt_div,'full_mismatch':bad_full,'monic_mismatch':bad_monic}
print('F9 done',flush=True)
# ---- F_27 m=2 counts ----
K27=GF(3,3,[1,2,0,1]); R27=Skew(K27)
irr27=irreducibles_py(K27,R27,2)
cl27={}
for f in irr27: cl27.setdefault(bound_py(R27,K27,f),[]).append(f)
out['F27_irr']=len(irr27); out['F27_class_sizes']=sorted(len(v) for v in cl27.values())
print('F27 done',flush=True)

if FULL:

    K8=GF(2,3,[1,1,0,1]); R8=Skew(K8)
    irr8=irreducibles_py(K8,R8,2); out['F8_irr']=len(irr8)
    f=irr8[0]
    h=[1,0,0,1,0,0,1]
    assert R8.modr(h,f)==[]
    mon=[list(g) for g in irr8]
    prods=sorted(set(tuple(R8.mul(g1,g2)) for g1 in mon for g2 in mon))
    fb=[]
    for j in range(2):
        for d in range(3):
            e=[0]*2; e[j]=2**d; fb.append(e)
    def Lrank(a):
        rows=[]
        for e in fb:
            r=R8.modr(R8.mul(R8.trim(list(a)),R8.trim(list(e))),f)
            rows.append(vecr(r,2,K8))
        return rank_mod(rows,2)
    def rho_of(y):
        def rho(x):
            r=0
            for i,yi in enumerate(y):
                if yi: r=K8.add(r,K8.mul(yi,K8.sig(x,i)))
            return r
        return rho
    ys=[]
    for y in itertools.product(range(8),repeat=3):
        if not any(y): continue
        rho=rho_of(list(y))
        if sorted(rho(x) for x in range(8))==list(range(8)): ys.append(list(y))
    out['F8_bijective_rho']=len(ys)
    def divides(a): return R8.modr(h,R8.trim(list(a)))==[]
    agree1=agree2=tot8=0; notmrd=0
    bad_list=[]
    for y in ys:
        rho=rho_of(y)
        for i0 in range(4):
            for nu in range(1,8):
                # criterion variants
                c1=False;c2=False
                for pr in prods:
                    for lam in range(1,8):
                        a=[K8.mul(lam,c) for c in pr]
                        if len(a)!=5: continue
                        if a[4]==K8.mul(nu,rho(a[i0])):
                            c1=True
                            if divides(a): c2=True
                # brute force: min rank over P_{i0,2}
                mrd=True
                for d in itertools.product(range(8),repeat=4):
                    if not any(d): continue
                    a=list(d)+[K8.mul(nu,rho(d[i0]))]
                    if Lrank(R8.trim(a))<4: mrd=False;break
                tot8+=1; notmrd+=(not mrd)
                agree1+=((not c1)==mrd); agree2+=((not c2)==mrd)
                if (not c1)!=mrd: bad_list.append((tuple(y),i0,nu))
    out['F8_l2']={'cases':tot8,'not_mrd':notmrd,'agree_product_criterion':agree1,'agree_divisor_criterion':agree2}
    print('F8 done',flush=True)

# ---- Example 7.4 ----
K=make_F9(); p=3; n=2; m=2
# Example 7.4: f = t^2 - a0, i0=1. matrix code C = { [[z0+nu rho(z1) a0, z1 a0],[sigma(z1), sigma(z0)+sigma(nu) sigma(rho(z1)) a0]] }
def det2(M): return K.sub(K.mul(M[0][0],M[1][1]),K.mul(M[0][1],M[1][0]))
agree=tot=0
mism=[]
for a0 in range(9):
    f=[K.neg(a0),0,1]
    # irreducible?
    R=Skew(K)
    if any(R.modr(f,[K.neg(c),1])==[] for c in range(9)): continue
    for rn,y in (('id',[1,0]),('sigma',[0,1]),('mixed',[1,4])):
        rho=make_rho(K,y)
        if sorted(rho(x) for x in range(9))!=list(range(9)): continue
        for nu in range(1,9):
            A=Alg(K,f,1,nu,rho)
            B,vec,unvec=from_pum(A)
            div=B.is_division()
            # matrix test: det M != 0 for all (z0,z1)!=(0,0)
            ok=True
            for z0 in range(9):
                for z1 in range(9):
                    if z0==0 and z1==0: continue
                    M=[[K.add(z0,K.mul(K.mul(nu,rho(z1)),a0)), K.mul(z1,a0)],
                       [K.sig(z1), K.add(K.sig(z0),K.mul(K.mul(K.sig(nu),K.sig(rho(z1))),a0))]]
                    if det2(M)==0: ok=False;break
                if not ok: break
            tot+=1
            if ok==div: agree+=1
            else: mism.append((a0,rn,nu,div,ok))
print("Example 7.4 matrix criterion vs brute force:",agree,"/",tot,"agree")
out['Ex74_agree']=[agree,tot]

# ---- hand-checkable cases (the points P1 and P3 of the page, and the sign cochains of Q2) ----
K=make_F9(); R=Skew(K); al=4; iEl=3          # F_9 = F_3(i); i = 3, alpha = 1+i = 4
def pw(x,k):
    r=1
    for _ in range(k): r=K.mul(r,x)
    return r
f=[1,al,1]                                    # t^2 + alpha t + 1 (class A)
A=Alg(K,f,0,iEl,make_rho(K,[1,al]))           # i0 = 0, nu = i, rho = id + alpha*sigma
b=(iEl,K.add(2,iEl))                          # b = i + (2+i) t
print("P1 by hand: b o 1 =",A.mul(b,(1,0)),"; division algebra:",is_division(A)[0])
out['P1_hand']={'b_circ_1':list(A.mul(b,(1,0))),'division':is_division(A)[0]}
def star_division(reading,nu,rho,i0=0):
    zero=(0,0); els=[e for e in elements(K,2) if any(e)]
    def rnu(y): return K.sub(y,K.mul(K.mul(nu,f[i0]),rho(y)))
    for g in els:
        h=list(g); h[i0]=rnu(g[i0]); L=R.add(R.trim(h),R.smul(K.mul(nu,rho(g[i0])),f))
        if reading=='b': L=R.modr(L,f)
        for c in els:
            r=R.modr(R.mul(L,R.trim(list(c))),f); r=tuple(r+[0]*(2-len(r)))
            if r==zero: return False
    return True
rho=make_rho(K,[1,0]); nu=pw(al,2)
bij=len({K.sub(y,K.mul(K.mul(nu,f[0]),rho(y))) for y in range(9)})==9
print("P3 by hand (rho = id, nu = alpha^2): rho_nu bijective:",bij,"; S_f division:",is_division(Alg(K,f,0,nu,rho))[0],
      "; (R_2,*) reading (a):",star_division('a',nu,rho),"; reading (b):",star_division('b',nu,rho))
out['P3_hand']={'rho_nu_bijective':bij,'S_f_division':is_division(Alg(K,f,0,nu,rho))[0],'star_a':star_division('a',nu,rho),'star_b':star_division('b',nu,rho)}
def bit_div(p_,mask):
    sg=lambda a,b_: 1 if (a==0 or b_==0) else (-1 if (mask>>((a-1)*3+(b_-1)))&1 else 1)
    def det(M):
        M=[r[:] for r in M]; d=1
        for c in range(4):
            piv=next((r for r in range(c,4) if M[r][c]%p_),None)
            if piv is None: return 0
            if piv!=c: M[c],M[piv]=M[piv],M[c]; d=-d
            d=d*M[c][c]%p_; inv=pow(M[c][c],-1,p_)
            for r in range(c+1,4):
                f_=M[r][c]*inv%p_
                if f_: M[r]=[(x-f_*y)%p_ for x,y in zip(M[r],M[c])]
        return d%p_
    for x in itertools.product(range(p_),repeat=4):
        if not any(x): continue
        M=[[0]*4 for _ in range(4)]          # matrix of L_x in the basis e_0..e_3 (labels a XOR b)
        for a in range(4):
            for b_ in range(4): M[a^b_][b_]=(M[a^b_][b_]+x[a]*sg(a,b_))%p_
        if det(M)==0: return False
    return True
q2={p_:sum(bit_div(p_,mask) for mask in range(512)) for p_ in (3,5,7)}
print("Q2: division algebras among the 512 normalised sign cochains on Z_2^2 over F_3, F_5, F_7:",q2)
out['Q2_sign_cochains_division']=q2

# ---- the claims of the report, one numbered line each ----
N_OK=N_BAD=0
def chk(cid,cond,msg):
    global N_OK,N_BAD
    if cond: N_OK+=1
    else: N_BAD+=1
    print(('ok   ' if cond else 'FAIL ')+cid+': '+msg)
chk('C1',out['F9_irr']==30 and out['F9_class_sizes']==[10,10,10] and out['F9_bounds']==['1,0,1','2,1,1','2,2,1'] and out['F9_rho_count']==48,
    'over F_9 the ring F_9[t;sigma] has 30 monic irreducible quadratics, in 3 similarity classes of 10 (bounds 1+z^2, 2+z+z^2, 2+2z+z^2 in z = t^2), and 48 bijective F_3-linear maps rho')
chk('C2',out['F9_exh']['total']==23040==30*2*48*8,'the exhaustive family S_f(F_9,i0,nu,rho) has 30 f x 2 i0 x 48 rho x 8 nu = 23,040 algebras')
chk('C3',out['F9_exh']['full_mismatch']==0 and out['F9_exh']['division']==3200,'Theorem 3.2 (P_{i0} contains no polynomial similar to f) agrees with the brute-force division test in all 23,040 algebras; 3,200 are division algebras')
chk('C4',out['F9_exh']['monic_mismatch']==6400,'the monic reduction of Proposition 3.5 as printed disagrees with brute force in 6,400 of the 23,040 algebras (point P1 of the page)')
chk('C5',out['F27_irr']==273 and out['F27_class_sizes']==[91,91,91],'over F_27 there are 273 monic irreducible quadratics, in 3 classes of 91 (point P5 of the page; 91 = (3^6-1)/(3^2-1))')
chk('C6',out['Ex74_agree'][0]==out['Ex74_agree'][1]==144,'Example 7.4: the matrix criterion (all non-zero spread-set matrices invertible) agrees with the brute-force division test in 144 of 144 algebras of this run (the page runs the larger family, N5)')
chk('C7',out['P1_hand']=={'b_circ_1':[0,0],'division':False},'point P1 by hand: for nu = i, rho = id + alpha*sigma, b = i + (2+i)t gives b o 1 = 0, so S_f(K,0,nu,rho) is not a division algebra')
chk('C8',out['P3_hand']=={'rho_nu_bijective':True,'S_f_division':False,'star_a':False,'star_b':True},'point P3 by hand (rho = id, nu = alpha^2): rho_nu is bijective, S_f is not a division algebra; (R_2,*) is not one in reading (a) and is one in reading (b)')
chk('C9',out['Q2_sign_cochains_division']=={3:0,5:0,7:0},'question Q2: none of the 512 normalised sign cochains on Z_2^2 gives a division algebra over F_3, F_5 or F_7')
if FULL:
    chk('C10',out['F8_irr']==21 and out['F8_bijective_rho']==168,'over F_8 (m = 2) there are 21 monic irreducible quadratics and 168 bijective F_2-linear maps rho = y0 + y1 sigma + y2 sigma^2')
    g=out['F8_l2']
    chk('C11',g=={'cases':4704,'not_mrd':4676,'agree_product_criterion':4676,'agree_divisor_criterion':4704},
        'Theorem 4.1 over F_8 (l = 2): of 4,704 cases 4,676 are not MRD; the literal criterion agrees with brute force in 4,676, the criterion with g a right divisor of h in 4,704 (point P2 of the page)')
print('\nchecks: %d ok, %d failed'%(N_OK,N_BAD))
if '--out' in sys.argv: json.dump(out,open(sys.argv[sys.argv.index('--out')+1],'w'),indent=1)
sys.exit(1 if N_BAD else 0)
