# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""SVG figures of the Hestenes / LDG report.  Every number drawn is computed here from the bit rule (bitcliff: Alg((1,-1,-1,-1))) or from the closed formulas that the checks of
this folder test (g^2 = 2M/r and its consequences); none is typed by hand.  The builder asserts the values the figures show against the lines of logs/hest_check.log."""
import html, math
from fractions import Fraction as Fr
E = html.escape

def tip(*lines):
    return E('\n'.join(lines), quote=True)

# ---------------------------------------------------------------------------------------------------------------------------------------------------
# the algebra: labels, squares, the chirality map
# ---------------------------------------------------------------------------------------------------------------------------------------------------
def pc(x): return bin(x).count('1')

NAME = {0: '1', 1: 'γ0', 2: 'γ1', 4: 'γ2', 8: 'γ3', 3: 'σ1', 5: 'σ2', 9: 'σ3', 12: 'Iσ1', 10: 'Iσ2', 6: 'Iσ3', 15: 'I',
        7: 'γ0γ1γ2', 11: 'γ0γ1γ3', 13: 'γ0γ2γ3', 14: 'γ1γ2γ3'}
POS_KERNEL = (0, 6, 10, 12)          # span{1, I sigma_k}: the kernel of the Dirac map at p = (m, 0, 0, 0)  (check H4)
NEG_KERNEL = (3, 5, 9, 15)           # span{sigma_k, I}: the kernel at p = (-m, 0, 0, 0)                      (check H5)
CHIRAL = 9                           # psi -> I psi J is XOR 9 on labels                                      (check H16)


def chirality_signs(A):
    """sign s_m in I e_m J = s_m e_(m xor 9), computed with the engine; J = gamma2 gamma1 = -e_6."""
    out = {}
    for m in (0, 3, 5, 6, 9, 10, 12, 15):
        s1, c1 = A.blade_mul(15, m)
        s2, c2 = A.blade_mul(c1, 6)
        out[m] = (-s1 * s2, c2)
    return out


def label_figure(A):
    """Fig. 1: the 16 labels of Cl(1,3) by grade; the eight even ones coloured by the kernel they span; XOR 9 pairs joined."""
    sg = chirality_signs(A)
    for m, (s, c) in sg.items(): assert c == m ^ CHIRAL
    W, H = 800, 392
    bw, bh = 82, 46
    rowy = {0: 46, 1: 126, 2: 214, 3: 298, 4: 366}
    xs = {0: [130], 1: [250, 370, 490, 610], 2: [130, 250, 370, 490, 610, 730], 3: [250, 370, 490, 610], 4: [730]}
    order = {0: [0], 1: [1, 2, 4, 8], 2: [9, 3, 10, 5, 12, 6], 3: [7, 11, 13, 14], 4: [15]}
    pos = {}
    for gr in range(5):
        for x, m in zip(xs[gr], order[gr]): pos[m] = (x, rowy[gr])
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The 16 labels of the algebra Cl(1,3) by grade; the eight even labels are coloured by the kernel of the Dirac map they span; the chirality joins them in pairs by XOR 9" class="chart hs">']
    # grade captions
    for gr, n in zip(range(5), (1, 4, 6, 4, 1)):
        parts.append(f'<text x="6" y="{rowy[gr] + 4}" class="t2">grade {gr}</text><text x="6" y="{rowy[gr] + 17}" class="t2">{n} label{"s" if n > 1 else ""}</text>')
    # chirality links (drawn first, under the boxes)
    for a, b in ((0, 9), (3, 10), (5, 12), (6, 15)):
        (xa, ya), (xb, yb) = pos[a], pos[b]
        if xa == xb: x1, y1, x2, y2 = xa, ya + bh / 2, xb, yb - bh / 2
        else:
            x1, y1, x2, y2 = (xa + bw / 2, ya, xb - bw / 2, yb) if xa < xb else (xa - bw / 2, ya, xb + bw / 2, yb)
        t = tip(f'labels {a} and {b}: ψ ↦ IψJ exchanges e{a} and e{b}', f'I e{a} J = {sg[a][0]:+d} e{b}, I e{b} J = {sg[b][0]:+d} e{a}', f'{a} XOR {b} = {a ^ b}', 'check H16')
        parts.append(f'<g class="hs-link" data-tip="{t}" tabindex="0"><line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}"/><text x="{(x1 + x2) / 2 + (9 if xa == xb else 0)}" y="{(y1 + y2) / 2 + (4 if xa == xb else -5)}" text-anchor="{"start" if xa == xb else "middle"}" class="hs-x">XOR 9</text></g>')
    for m, (x, y) in sorted(pos.items(), key=lambda kv: kv[1]):
        cls = 'hs-pos' if m in POS_KERNEL else 'hs-neg' if m in NEG_KERNEL else 'hs-odd'
        sq = A.sq(m)
        kind = ('in the kernel at p = (m,0,0,0): span{1, Iσk}' if m in POS_KERNEL else 'in the kernel at p = (−m,0,0,0): span{σk, I}' if m in NEG_KERNEL else 'odd label: not a component of ψ')
        lines = [f'label {m} = {m:04b} (grade {pc(m)}): {NAME[m]}', f'square {sq:+d}', kind]
        if m in sg: lines.append(f'chirality: I e{m} J = {sg[m][0]:+d} e{sg[m][1]}')
        parts.append(f'<g class="{cls}" data-tip="{tip(*lines)}" tabindex="0"><rect x="{x - bw / 2}" y="{y - bh / 2}" width="{bw}" height="{bh}" rx="7"/>'
                     f'<text x="{x}" y="{y - 3}" text-anchor="middle" class="hs-n">{m}</text><text x="{x}" y="{y + 13}" text-anchor="middle" class="hs-s">{E(NAME[m])}</text></g>')
    parts.append('</svg>')
    leg = ('<div class="legend"><span><i class="sw hs-swpos">0</i> kernel at p = (m, 0, 0, 0): labels 0, 6, 10, 12</span>'
           '<span><i class="sw hs-swneg">3</i> kernel at p = (−m, 0, 0, 0): labels 3, 5, 9, 15</span>'
           '<span><i class="sw hs-swodd">1</i> odd labels (not in ψ)</span><span>line: ψ ↦ IψJ, XOR 9</span></div>')
    return ''.join(parts) + leg


# ---------------------------------------------------------------------------------------------------------------------------------------------------
# the horizon: the square of the gradient of r, and the two time shifts
# ---------------------------------------------------------------------------------------------------------------------------------------------------
def horizon_figure():
    """Fig. 3: h(e_r)^2 = g^2 - 1 = 2M/r - 1 against r/M, with the zones; the three sample points of checks G2a-G2c."""
    W, H = 560, 300
    x0, x1, y0, y1 = 56, 540, 20, 262                 # plot box
    rmin, rmax, ymin, ymax = 0.5, 6.0, -1.15, 3.2
    X = lambda r: x0 + (r - rmin) / (rmax - rmin) * (x1 - x0)
    Y = lambda v: y1 - (v - ymin) / (ymax - ymin) * (y1 - y0)
    f = lambda r: 2 / r - 1
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The square of the radial gradient against r over M: positive inside, zero on the horizon, negative outside" class="chart hs">']
    parts.append(f'<rect x="{X(rmin)}" y="{y0}" width="{X(2) - X(rmin)}" height="{y1 - y0}" class="hs-zin"/><rect x="{X(2)}" y="{y0}" width="{X(rmax) - X(2)}" height="{y1 - y0}" class="hs-zout"/>')
    parts.append(f'<line x1="{x0}" y1="{Y(0)}" x2="{x1}" y2="{Y(0)}" class="hs-ax"/><line x1="{X(2)}" y1="{y0}" x2="{X(2)}" y2="{y1}" class="hs-hz"/>')
    for r in (1, 2, 3, 4, 5, 6):
        parts.append(f'<line x1="{X(r)}" y1="{y1}" x2="{X(r)}" y2="{y1 + 4}" class="hs-ax"/><text x="{X(r)}" y="{y1 + 17}" text-anchor="middle" class="t2">{r}</text>')
    for v in (-1, 0, 1, 2, 3):
        parts.append(f'<line x1="{x0 - 4}" y1="{Y(v)}" x2="{x0}" y2="{Y(v)}" class="hs-ax"/><text x="{x0 - 8}" y="{Y(v) + 4}" text-anchor="end" class="t2">{str(v).replace("-", "−")}</text>')
    pts = []
    n = 160
    for i in range(n + 1):
        r = rmin + (rmax - rmin) * i / n
        pts.append(f'{X(r):.1f},{Y(f(r)):.1f}')
    parts.append(f'<polyline points="{" ".join(pts)}" class="hs-curve"/>')
    parts.append(f'<text x="{(X(rmin) + X(2)) / 2}" y="{y0 + 16}" text-anchor="middle" class="t">timelike, square +1</text>'
                 f'<text x="{(X(2) + X(rmax)) / 2 + 40}" y="{Y(-0.5) - 36}" text-anchor="middle" class="t">spacelike, square −1</text>'
                 f'<text x="{X(2) + 6}" y="{y1 - 8}" class="t">horizon, square 0</text>')
    parts.append(f'<text x="{(x0 + x1) / 2}" y="{H - 4}" text-anchor="middle" class="t2">r / M</text><text x="12" y="{(y0 + y1) / 2}" text-anchor="middle" class="t2" transform="rotate(-90 12 {(y0 + y1) / 2})">h̄(e<tspan dy="3" font-size="9">r</tspan><tspan dy="-3">)² = g² − 1</tspan></text>')
    # the sample points of G2a-G2c: g = 3/5, 1, 5/3, with r = 2M/g^2 and square g^2 - 1
    for g, word, cid in ((Fr(3, 5), 'outside', 'G2a'), (Fr(1), 'on the horizon', 'G2b'), (Fr(5, 3), 'inside', 'G2c')):
        r = Fr(2) / (g * g); v = g * g - 1
        parts.append(f'<circle cx="{X(float(r)):.1f}" cy="{Y(float(v)):.1f}" r="5.5" class="hs-dot" data-tip="{tip(f"g = {g}, r = {r} M ({word})", f"h̄(e_r)² = g² − 1 = {v}", f"check {cid}")}" tabindex="0"/>')
    parts.append('</svg>')
    return ''.join(parts)


def shift_figure():
    """Fig. 4: the integrands of the two time shifts, g/(1 - 2M/r) (to Schwarzschild time, diverges at r = 2M) and g/(1 + g) (to Kerr-Schild time, finite)."""
    W, H = 560, 300
    x0, x1, y0, y1 = 56, 540, 20, 262
    rmin, rmax, ymin, ymax = 0.4, 6.0, -6, 6
    X = lambda r: x0 + (r - rmin) / (rmax - rmin) * (x1 - x0)
    Y = lambda v: y1 - (max(ymin, min(ymax, v)) - ymin) / (ymax - ymin) * (y1 - y0)
    g = lambda r: math.sqrt(2 / r)
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The two time shifts as functions of r over M: one diverges at the horizon, the other stays finite" class="chart hs">']
    parts.append(f'<line x1="{x0}" y1="{Y(0)}" x2="{x1}" y2="{Y(0)}" class="hs-ax"/><line x1="{X(2)}" y1="{y0}" x2="{X(2)}" y2="{y1}" class="hs-hz"/>')
    for r in (1, 2, 3, 4, 5, 6):
        parts.append(f'<line x1="{X(r)}" y1="{y1}" x2="{X(r)}" y2="{y1 + 4}" class="hs-ax"/><text x="{X(r)}" y="{y1 + 17}" text-anchor="middle" class="t2">{r}</text>')
    for v in (-6, -3, 0, 3, 6):
        parts.append(f'<line x1="{x0 - 4}" y1="{Y(v)}" x2="{x0}" y2="{Y(v)}" class="hs-ax"/><text x="{x0 - 8}" y="{Y(v) + 4}" text-anchor="end" class="t2">{str(v).replace("-", "−")}</text>')
    def poly(fn, ra, rb, cls, n=120):
        pts = [f'{X(ra + (rb - ra) * i / n):.1f},{Y(fn(ra + (rb - ra) * i / n)):.1f}' for i in range(n + 1)]
        return f'<polyline points="{" ".join(pts)}" class="{cls}"/>'
    T = lambda r: 1 - 2 / r
    parts.append(poly(lambda r: g(r) / T(r), rmin, 1.93, 'hs-curve2')); parts.append(poly(lambda r: g(r) / T(r), 2.07, rmax, 'hs-curve2'))
    parts.append(poly(lambda r: g(r) / (1 + g(r)), rmin, rmax, 'hs-curve'))
    parts.append(f'<text x="{X(3.3)}" y="{Y(3.7)}" class="t">g / (1 − 2M/r)</text><text x="{X(3.9)}" y="{Y(1.6)}" class="t">g / (1 + g)</text>')
    parts.append(f'<text x="{(x0 + x1) / 2}" y="{H - 4}" text-anchor="middle" class="t2">r / M (the drawing is cut at ±6)</text>')
    parts.append('</svg>')
    return ''.join(parts)


# ---------------------------------------------------------------------------------------------------------------------------------------------------
# the curvature operator of the point mass
# ---------------------------------------------------------------------------------------------------------------------------------------------------
def weyl_data(A):
    """The map B -> B + 3 sigma_r B sigma_r on the six bivector labels (sigma_r = sigma_3 = label 9), exactly: eigenvalue per label."""
    s_r = 9
    out = {}
    for b in (3, 5, 6, 9, 10, 12):
        s1, c1 = A.blade_mul(s_r, b); s2, c2 = A.blade_mul(c1, s_r)
        assert c2 == b
        out[b] = 1 + 3 * s1 * s2
    return out


def weyl_figure(A):
    """Fig. 2: the six eigenvalues of the curvature operator in units of M/r^3: -(1/2) x (eigenvalue of B + 3 sigma_r B sigma_r)."""
    wd = weyl_data(A)
    ev = {b: Fr(-1, 2) * w for b, w in wd.items()}
    assert sorted(ev.values()) == [-2, -2, 1, 1, 1, 1] and sum(ev.values()) == 0
    order = [9, 6, 3, 5, 12, 10]
    W, H = 560, 262
    x0, base, unit = 70, 100, 34              # base line y; 1 unit = 34 px
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="The six eigenvalues of the curvature operator of a point mass, in units of M over r cubed: minus two twice and plus one four times" class="chart hs">']
    parts.append(f'<line x1="{x0 - 10}" y1="{base}" x2="{W - 20}" y2="{base}" class="hs-ax"/>')
    for v in (-2, -1, 1):
        parts.append(f'<text x="{x0 - 16}" y="{base - v * unit + 4}" text-anchor="end" class="t2">{str(v).replace("-", "−")}</text>')
    for i, b in enumerate(order):
        x = x0 + 20 + i * 76; v = ev[b]
        top = base - float(v) * unit
        yy, hh = (top, base - top) if v > 0 else (base, top - base)
        cls = 'hs-bar-neg' if v < 0 else 'hs-bar-pos'
        rad = 'radial pair' if b in (9, 6) else 'transverse'
        t = tip(f'bivector label {b} = {NAME[b]} ({rad})', f'B + 3σ_r B σ_r = {wd[b]:+d} B  (σ_r = σ3, label 9)', f'curvature eigenvalue −(1/2)({wd[b]:+d}) = {v} in units of M/r³', 'checks L6, L7, G8c, S10a')
        parts.append(f'<rect x="{x}" y="{yy:.1f}" width="46" height="{hh:.1f}" rx="3" class="{cls}" data-tip="{t}" tabindex="0"/>')
        parts.append(f'<text x="{x + 23}" y="{(yy - 6) if v > 0 else (yy + hh + 14):.1f}" text-anchor="middle" class="t">{"+" if v > 0 else "−"}{abs(v)}</text>')
        parts.append(f'<text x="{x + 23}" y="{base + 106}" text-anchor="middle" class="t2">label {b}</text><text x="{x + 23}" y="{base + 120}" text-anchor="middle" class="t2">{E(NAME[b])}</text>')
    parts.append('</svg>')
    return ''.join(parts)


def counts_table():
    """Riemann = Ricci + Weyl component counts by the dimension n (checks G6a-G6c)."""
    rows = []
    for n in range(3, 9):
        riem = n * n * (n * n - 1) // 12; ric = n * (n + 1) // 2; weyl = riem - ric
        rows.append((n, riem, ric, weyl))
    return rows
