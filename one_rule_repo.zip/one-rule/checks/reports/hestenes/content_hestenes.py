# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The text of the Hestenes / LDG report: findings, dictionary rows, inputs, limits, sources.  Plain data; build_report_hestenes.py puts it on the page and test_report_hestenes.py
pins it against logs/hest_check.log (every check id named here exists, every id of the log is named, the numbers equal the log).  A status tag is one of
standard (textbook or the source's own statement, used as is), checked (a script in this folder recomputed it), ours (our reading), open (not settled),
input (a choice or datum the physics page needs that the algebra does not supply: the chart and the derivative, the frame, the grade a field lives in, the time direction,
the complex structure, a postulated equation).  The words %%FIG_...%% are replaced by figures."""

TITLE = 'Hestenes and gauge-theory gravity: a lens report'
H1 = 'Space-time algebra and gauge-theory gravity in the bit rule'
SUB = ('What the atlas\'s one rule (bit labels, XOR and a sign) says about Hestenes\' space-time algebra and about the gauge-theory gravity of Lasenby, Doran and Gull: '
       'which statements are the same object, which are computed, which are only our reading, and which choices the physics page makes that the algebra does not.')
NOTICE = ('<b>Preliminary.</b> The equations named in the checks are read from Hestenes, <i>Space-Time Algebra</i>, and from Lasenby, Doran and Gull (LDG), <i>Gravity, gauge theories and geometric algebra</i>, '
          'by the equation numbers the checks quote. The rest of LDG (the field equations of gauge-theory gravity, cosmology, the Hawking-radiation sections, rotating solutions) is not decoded. '
          'A statement tagged checked is recomputed by a script in this folder, in flat space for the Dirac equation and Maxwell, and for one metric (the point mass) in gravity. '
          'Nothing here is a result about nature: the equations are postulated by the physics page, and the algebra is the arena they are written in.')

LEAD = ('The atlas\'s Dirac step (step 4), spinor step (step 5), null-surface step (step 13) and gauge-gravity step (step 12), and its Maxwell calibration (Calibration 1), all use Hestenes\' space-time algebra '
        'Cl(1,3), where γ<sub>0</sub> squares to +1. This report takes their objects one at a time and recomputes them in the bit rule, with a second, independent implementation of the algebra. '
        'What the algebra gives, as exact statements about labels: the eight even labels 0, 3, 5, 6, 9, 10, 12, 15 as the eight real components of ψ; the “i” of the Dirac equation as the real bivector J (label 6); '
        'the two kernels of the Dirac map, the labels 0, 6, 10, 12 at p = (m, 0, 0, 0) and the labels 3, 5, 9, 15 at p = (−m, 0, 0, 0); the chirality ψ ↦ IψJ as XOR with 9; '
        'Maxwell\'s four equations as the grade-1 and grade-3 parts of one equation; and the Newtonian-gauge shear of the point mass as a rank-one nilpotent 1 + N, whose metric is vacuum with Kretschmann scalar 48M²/r⁶ '
        'and whose curvature operator is −(M/2r³)(B + 3σ<sub>r</sub>Bσ<sub>r</sub>). What the algebra does not give: the time direction, the chart and the derivative, the grade each field lives in, the complex structure, '
        'the equations themselves, and the form of the shear. Those are the inputs; the section Inputs lists each, with the check that shows what depends on it.')

# status tags: chips in the finding head
# finding: (id, title, chips, left, right, ids)
FINDINGS = [
 ('F1', 'The cell Cl(1,3), its sixteen labels and their names', ['standard', 'checked', 'input'],
  '<p>The algebra of the Dirac step has one generator that squares to +1 and three that square to −1: Cl(1,3), Hestenes\' space-time algebra with γ<sub>0</sub>² = +1. Its 16 labels are the masks 0–15 '
  '(bit 0 is γ<sub>0</sub>, bits 1–3 are γ<sub>1</sub>, γ<sub>2</sub>, γ<sub>3</sub>), and the product of two labels is XOR with a sign. The names used on this page, with their labels (Fig. 1): '
  'σ<sub>k</sub> = γ<sub>k</sub>γ<sub>0</sub> (labels 3, 5, 9; square +1), I = γ<sub>0</sub>γ<sub>1</sub>γ<sub>2</sub>γ<sub>3</sub> (label 15; I² = −1) and Iσ<sub>k</sub> (labels 12, 10, 6; square −1). '
  'I = σ<sub>1</sub>σ<sub>2</sub>σ<sub>3</sub> exactly; I anticommutes with every vector and commutes with every even element, so it is a central “i” of the even subalgebra only.</p>'
  '<p>The eight even labels, with σ<sub>k</sub> written e<sub>k</sub>, multiply exactly as the algebra Cl(3,0) = M<sub>2</sub>(ℂ): all 64 products agree. The six bivector labels split 3 + 3 by their relation to γ<sub>0</sub>: '
  'the σ<sub>k</sub> anticommute with it (electric type) and the Iσ<sub>k</sub> commute with it (magnetic type).</p>',
  '<p><b>Standard.</b> Cl(1,3) ≅ M<sub>2</sub>(ℍ), the cell [4,−2] of the atlas (Lawson–Michelsohn, <i>Spin Geometry</i>, Ch. I §4; Lundholm–Svensson, Theorem 5.5 and Table 5.1; the types are tabulated by '
  '<code>groups_check.py</code> part A and <code>cat_check.py</code> K4a–c). Its even subalgebra is M<sub>2</sub>(ℂ).</p>'
  '<p class="not"><b>Input.</b> Which generator is called time and which sign is called space. The page takes the generator that squares to +1 as γ<sub>0</sub>. The mirror Cl(3,1) carries a real Dirac operator with the '
  'physical mass shell as well (<code>researchers_checks/check_T16.py</code>), so which of the two is spacetime is a convention, and naming the cell “Minkowski” is a reading (ours).</p>'
  '%%FIG_LABELS%%',
  'H1, H2, S1a–S2d, S4a, S7b'),

 ('F2', 'The “i” of the Dirac equation is a real bivector', ['standard', 'checked', 'input'],
  '<p>In Hestenes\' form the Dirac equation is ∇ψJ = mψγ<sub>0</sub> with J = γ<sub>2</sub>γ<sub>1</sub> = Iσ<sub>3</sub> (label 6, up to sign): a real bivector with J² = −1 that commutes with γ<sub>0</sub> '
  '(H1, S3a, S3b). The unknown ψ is an even multivector, eight real components on the labels 0, 3, 5, 6, 9, 10, 12, 15. Right multiplication by J is a complex structure on those eight dimensions (S5a). '
  'It commutes with every left multiplication, so the left action is the action of Lorentz rotors and the right action by exp(φJ) is the U(1) phase (S5b); multiplication by an even element never changes the parity of a label (S5c).</p>'
  '<p>Through the column u = (1, 0, 0, 0), with γ<sub>0</sub>u = u and Ju = iu (H7), the map ψ ↦ ψu is a real-linear bijection of the eight-dimensional even subalgebra onto ℂ⁴ (H8), and Hestenes\' equation goes to '
  'iγ<sup>μ</sup>∂<sub>μ</sub>Ψ − mΨ = 0, the equation of the matrix formulation, for 200 random ψ, derivatives and m (H9). The opposite sign of the unit is the same equation: ψ ↦ ψγ<sub>3</sub>γ<sub>2</sub> '
  'maps the solutions of ∇ψγ<sub>2</sub>γ<sub>1</sub> = mψγ<sub>0</sub> to those of ∇ψγ<sub>1</sub>γ<sub>2</sub> = mψγ<sub>0</sub> (H10).</p>',
  '<p><b>Standard</b> (Hestenes; LDG appendix A). <b>Checked</b> as stated.</p>'
  '<p class="not"><b>Input.</b> The complex structure J. The algebra offers several elements that square to −1: the rotation bivectors Iσ<sub>k</sub> and the pseudoscalar I. Which of them plays “i”, and with it the spin '
  'axis σ<sub>3</sub>, is part of the equation. J is the one that commutes with γ<sub>0</sub> and acts on even elements from the right.</p>',
  'H1, H7–H10, S2c, S2d, S3a, S3b, S5a–S5c'),

 ('F3', 'The Dirac equation on plane waves: two kernels, one for each sign of the energy', ['standard', 'checked'],
  '<p>For a plane wave ψ = ψ<sub>0</sub>exp(−J p·x) the equation becomes a linear map on the eight real components. Its determinant is |p² − m²|⁴ (40 random p and m, H3): the mass shell p² = m² is where the map has a kernel. '
  'At p = (m, 0, 0, 0) the kernel is the four-dimensional span{1, Iσ<sub>k</sub>}, the labels 0, 6, 10, 12 (H4). At p = (−m, 0, 0, 0) it is span{σ<sub>k</sub>, I}, the labels 3, 5, 9, 15 (H5): another space, '
  'so the sign of the energy belongs to the point p. At either point the kernel is closed under right multiplication by J, of complex dimension 2: the two spin states (H6, S6c).</p>'
  '<p>Boosted plane waves ψ = (m + E + pσ<sub>3</sub>)χ exp(−J(Et − pz)) with χ in {1, Iσ<sub>k</sub>} satisfy the equation (S6a) and fail with the wrong sign of the momentum (S6b, a control). '
  'The four even labels that commute with γ<sub>0</sub> carry the rest-frame solutions of positive energy; the four that anticommute with it, the solutions of negative energy.</p>',
  '<p><b>Standard</b> and <b>checked</b>. What the algebra supplies is the kernel as a set of labels, one for each sign of the energy.</p>'
  '<p class="not">Not said: which kernel is matter. Calling the negative-energy kernel antiparticles is the physics page\'s reading; the checks stop at the labels.</p>',
  'H3–H6, S6a–S6c'),

 ('F4', 'The chirality ψ ↦ IψJ is XOR with 9', ['checked', 'ours', 'open'],
  '<p>The map ψ ↦ IψJ sends every blade e<sub>m</sub> to ±e<sub>m⊕9</sub>, where 9 = 15 ⊕ 6 holds the bits of γ<sub>0</sub>γ<sub>3</sub> (H16). The eight even labels are paired 0 ↔ 9, 3 ↔ 10, 5 ↔ 12, 6 ↔ 15 (Fig. 1). '
  'The map is an involution (H17); on an even ψ it is the right multiplication IψJ = −ψσ<sub>3</sub> = ψγ<sub>0</sub>γ<sub>3</sub> (H18); its two eigenspaces on the eight even blades have dimension 4 + 4 (H19). '
  'Under Ψ = ψu it goes to −γ<sub>5</sub>Ψ with γ<sub>5</sub> = iγ⁰γ¹γ²γ³, that is, ψσ<sub>3</sub> goes to γ<sub>5</sub>, the identification of LDG appendix A (A.3; H20).</p>'
  '<p>The derivative term ∇ψJ anticommutes with the map, and the mass term ψγ<sub>0</sub> commutes with it (H21). So for m = 0 the Dirac equation splits into two independent halves, the two Weyl equations, and the mass term is what '
  'couples them. Because the derivative term anticommutes, the map takes a solution at p to a solution at −p: it maps the kernel at −p onto the kernel at p (H22; ten random on-shell points, five of each sign of the energy, '
  'kernel dimension 4 at both). So the chirality exchanges the two signs of the energy between p and −p.</p>',
  '<p><b>Checked</b> as stated, including the match with −γ<sub>5</sub> in the convention of LDG A.3. <b>Ours</b>: the label form, chirality as XOR with 9 and the four pairs.</p>'
  '<p class="not"><b>Open.</b> The chiral coupling is not drawn; with a chiral coupling the mass term needs a scalar doublet, one more step and not an input. The map is algebra: which half couples to which field is a statement of a physics page, and the atlas makes none.</p>',
  'H16–H22'),

 ('F5', 'Pointors and the Yvon–Takabayasi slice', ['standard', 'checked', 'ours'],
  '<p>For an even ψ the product ψψ̃ has only a scalar and a pseudoscalar part, ψψ̃ = a + bI = ρe<sup>Iβ</sup> (H24), and ψ = √ρ e<sup>Iβ/2</sup>R with RR̃ = 1 (H28): β is the Yvon–Takabayasi angle. '
  'A <i>pointor</i> is a ψ for which ψIψ̃ is a multiple of I; that holds exactly when b = 0, that is sin β = 0 (H25; 200 samples, 134 with β = 0 or π and 66 generic). The slice is β ∈ {0, π}, not β = 0 alone: '
  'ψ = I has ψψ̃ = −1 and ψIψ̃ = −I, a pointor with β = π (H26), and e<sup>Iπ/4</sup>, with β = π/2, is not a pointor (H27).</p>'
  '<p>The vector ψxψ̃ = ρRxR̃ does not see β, while ψIψ̃ = ρe<sup>Iβ</sup>I does (H29). The current X = ψγ<sub>0</sub>ψ̃ is a vector with X² = a² + b² = ρ² (H30). On the mass shell every solution at p has b = 0 '
  'and the sign of a equal to the sign of the energy p⁰: β = 0 for p⁰ &gt; 0 and β = π for p⁰ &lt; 0 (H23).</p>',
  '<p><b>Standard</b> (Hestenes\' pointor language; the atlas\'s step 5). <b>Checked</b> as stated. <b>Ours</b>: describing the pointors as the b = 0 slice of the Yvon–Takabayasi angle, and pairing its two values with the two signs of the energy.</p>'
  '<p class="not">Not claimed: a physical meaning of β. The checks compute the algebra of ψψ̃ only.</p>',
  'H23–H30'),

 ('F6', 'Maxwell: four equations are two grades of one', ['standard', 'checked', 'input'],
  '<p>With F = E + IB, a bivector (electric labels 3, 5, 9, magnetic labels 12, 10, 6), F² = (E² − B²) + 2I E·B: the two Lorentz invariants and no bivector part (S7a; 40 random integer fields). '
  'Multiplication by I maps bivectors to bivectors and is a complex structure on the six-dimensional bivector space, so bivectors form ℂ³ (S7c). The first-order operator ∇ = γ<sup>μ</sup>∂<sub>μ</sub> squares to the wave operator, '
  '∇² = ∂<sub>t</sub>² − Δ (S11a, H12).</p>'
  '<p>∇F has grades 1 and 3 only: grade 1 is Gauss and Ampère (four equations), grade 3 is Faraday and ∇·B = 0 (four equations; H11, 20 random samples). In n dimensions grade 1 has n components and grade 3 has C(n,3): '
  '4 + 4 for n = 4, 5 + 10 for n = 5 (standard counting; H13 evaluates the two binomials). For F = ∇∧A the grade-3 part vanishes (the Bianchi identity, S11b) and ∇F = □A − ∇(∇·A) = J (LDG 2.45; S11c): Maxwell\'s four equations are the grade-1 part of one equation. '
  'The symbol F ↦ pF of ∇F = 0 on bivectors has ranks (grade 1, grade 3, both) = (3, 3, 6) for a timelike and for a spacelike p and (3, 3, 4) for a null p (H14). '
  'The Lorentz force is F·u = (Fu − uF)/2 = ⟨Fu⟩<sub>1</sub>, which for F = E + IB and u = γ(γ<sub>0</sub> + v<sup>k</sup>γ<sub>k</sub>) gives γ[(E·v)γ<sub>0</sub> + (E + v × B)<sup>k</sup>γ<sub>k</sub>] (H15).</p>',
  '<p><b>Standard</b> (Hestenes; LDG Section 2), <b>checked</b> as stated: the grades (H11), the ranks (H14), the force (H15). The component counts n and C(n,3) are <b>standard</b> counting: H13 evaluates the binomials and builds no algebra for n = 5.</p>'
  '<p class="not"><b>Input.</b> That the field is a bivector (grade 2), the derivative ∇ with the chart it acts in, and the equation ∇F = J itself. The algebra shows that this one equation has exactly a vector and a trivector part, '
  'with n and C(n,3) equations.</p>',
  'H11–H15, S7a, S7c, S11a–S11c'),

 ('F7', 'Three classes of bivector in the Lorentz group', ['standard', 'checked', 'ours'],
  '<p>The six bivector labels close under the commutator into so(1,3) = sl(2,ℂ), the Lie algebra of Spin(1,3) = SL(2,ℂ); the Jacobi identity holds for all 216 triples (S8a). Inside Cl(1,3) the rotation bivector γ<sub>1</sub>γ<sub>2</sub> '
  '(label 6) squares to −1, the boost σ<sub>1</sub> squares to +1, and their sum σ<sub>1</sub> + γ<sub>1</sub>γ<sub>2</sub> squares to 0; the exponential of the null one is 1 plus the null one, a parabolic element (S9a).</p>',
  '<p><b>Standard</b>, <b>checked</b> (S8a, S9a). <b>Ours</b>: reading the three classes of Lorentz elements as the trio of squares (−1, +1, 0) that the bit rule assigns to generators. The classes are standard; the trio is the atlas\'s bookkeeping of them.</p>',
  'S8a, S9a'),

 ('F8', 'The free Dirac action gives Hestenes\' equation', ['standard', 'checked', 'input', 'open'],
  '<p>For the free Dirac action of LDG (3.38), written L = ⟨∇ψ Iγ<sub>3</sub> ψ̃ − mψψ̃⟩, the Euler–Lagrange equations in the eight real components of ψ are EL = T·D, where D = ∇ψIσ<sub>3</sub> − mψγ<sub>0</sub> is '
  'Hestenes\' equation (its odd part, eight components) and T is an invertible 8 × 8 matrix with |det T| = 256 (A2, S12a). Both maps have rank 8, and so does the map of the two stacked: the two systems have the same solutions (A1). '
  'The Euler–Lagrange equation of the action is equivalent to Hestenes\' equation.</p>',
  '<p><b>Standard</b>, <b>checked</b>: the Euler–Lagrange equations are computed from the eight real components, not taken from a variational theorem.</p>'
  '<p class="not"><b>Input.</b> The action itself is postulated. <b>Open.</b> The coupling: the sign and the size of the source term e·X of ∇F = eX come from an action principle with a gauge field that is not rebuilt here, '
  'so the coupling constant is not derived.</p>',
  'A1, A2, S12a'),

 ('F9', 'Gauge-theory gravity: the point mass is one unipotent shear of flat space', ['standard', 'checked', 'input'],
  '<p>In gauge-theory gravity the point mass in the Newtonian gauge is one linear map of the vector space, h̄ = 1 + N with N² = 0, rank N = 1 and det h̄ = 1 (G1a), where h̄(e<sub>r</sub>) = e<sub>r</sub> + g e<sub>t</sub>, '
  'g² = 2M/r, and e<sub>t</sub> and the angular directions are not moved (LDG 6.79; G7a). The Gram matrix h̄(e<sub>μ</sub>)·h̄(e<sub>ν</sub>) is g<sup>tt</sup> = 1, g<sup>tr</sup> = g, g<sup>rr</sup> = g² − 1 (G1b); in the reciprocal frame '
  'ds² = dt² − (dr + g dt)² = (1 − 2M/r)dt² − 2√(2M/r) dt dr − dr², the Painlevé–Gullstrand form; the sign of the cross term is a frame convention, not physics (G1c, G1d). The shear is not an isometry of the flat metric: '
  'gauge fields live in GL, rotors in the orthogonal group, and the rank-1 unipotent 1 + N is a real transvection N = u(v·) with v·u = 0, here e<sub>t</sub>(e<sub>r</sub>·) with e<sub>r</sub>·e<sub>t</sub> = 0 (G4a).</p>'
  '<p>The metric is tested directly. For the Painlevé–Gullstrand shear the metric is vacuum (Ricci = 0 to finite-difference accuracy, below 10<sup>−6</sup>) with Kretschmann scalar 48M²/r⁶, at r = 4.1 and inside the horizon at r = 1.3 (L1, G8a); '
  'the Kerr–Schild null shear and Schwarzschild coordinates give the same (L2, L3). Controls: the shear with g² = 2M²/r² is not vacuum (L4); the shear with g² = 3M/r is vacuum, with mass 3M/2, '
  'so the test sees the mass and g² = 2M/r is not a free choice (L5, G8b).</p>',
  '<p><b>Standard</b> (LDG Section 6), <b>checked</b>: the structure of the shear (G1, G4a) and the vacuum tests on the metric it gives (numerical, finite differences).</p>'
  '<p class="not"><b>Input.</b> The shear itself, g² = 2M/r: the Schwarzschild solution as LDG write it, taken as given. The page does not solve the field equations of gauge-theory gravity (they are not decoded); '
  'it tests the metric for Ricci = 0 and for the mass.</p>',
  'G1a–G1d, G4a, G8a, G8b, L1–L5'),

 ('F10', 'Free fall and the curvature operator of the point mass', ['standard', 'checked'],
  '<p>Free fall in the Painlevé–Gullstrand metric, computed from its Christoffel symbols alone, has d²r/dτ² = −M/r², Newton\'s law, on both sides of r = 2M, for the energies α = 1 and α = 1.4, from r = 12 down to r = 0.5 '
  '(L8; G8d: error below 10<sup>−11</sup>, four-velocities of unit length). The quantity (1 − 2M/r)ṫ − ṙ√(2M/r) = α is conserved (LDG 6.83), and for α = 1, fall from rest at infinity, ṫ = 1 and ṙ = −√(2M/r): '
  'the falling observer crosses r = 2M with nothing special happening (L9, G8e).</p>'
  '<p>The curvature operator R<sup>ab</sup><sub>cd</sub> of the metric, in the orthonormal frame of the shear at r = 4.1, has the eigenvalues (−2, −2, 1, 1, 1, 1)·M/r³ and trace 0 (L6, G8c). They are the eigenvalues of '
  '−(M/2r³)(B + 3σ<sub>r</sub>Bσ<sub>r</sub>) computed in the bit rule on the six bivector labels: B + 3σ<sub>r</sub>Bσ<sub>r</sub> has eigenvalue 4 on the radial pair (labels 9 and 6) and −2 on the other four (L7; Fig. 2). '
  'This Weyl map of a point mass is of type D, traceless (Σ<sub>k</sub> σ<sub>k</sub>W(σ<sub>k</sub>) = 0, LDG 5.22) and complex-linear (W(IB) = IW(B), LDG 5.21), so it is a symmetric traceless complex 3 × 3 matrix, '
  '5 complex = 10 real degrees of freedom, with complex eigenvalues (4, −2, −2) (S10a–S10c).</p>',
  '<p><b>Standard</b>, <b>checked</b>. The geodesics and the curvature operator of the metric are computed numerically (Christoffel symbols, an ODE integrator, finite differences); the map B ↦ B + 3σ<sub>r</sub>Bσ<sub>r</sub> on the six bivector labels exactly.</p>'
  '%%FIG_WEYL%%',
  'G8c–G8e, L6–L9, S10a–S10c'),

 ('F11', 'The horizon: a null radial gradient, not the label 0', ['standard', 'checked', 'ours'],
  '<p>The image of the radial direction, h̄(e<sub>r</sub>) = e<sub>r</sub> + g e<sub>t</sub>, has square g² − 1 = −(1 − 2M/r) exactly (G7a). The inverse metric has g<sup>rr</sup> = −T = h̄(e<sub>r</sub>)² with T = 1 − 2M/r, '
  'so h̄(e<sub>r</sub>) is the physical gradient of r (G7b). Its square is the zone test: spacelike (square −1) outside, null (square 0) on the horizon, timelike (square +1) inside; at g = 3/5, 1, 5/3 the squares are −16/25, 0 and 16/9 '
  '(G2a–G2c; Fig. 3). The same three classes as the squares of a generator in the bit rule.</p>'
  '<p>Two time shifts connect the charts exactly. t<sub>PG</sub> = t<sub>S</sub> + φ(r) with φ′ = g/T turns the Painlevé–Gullstrand block into diag(T, −1/T), Schwarzschild coordinates (G7c); φ′ = g/(1 + g), finite at the horizon, '
  'turns it into the Kerr–Schild block with g<sub>tr</sub> = −2M/r and g<sub>rr</sub> = −(1 + 2M/r) (G7d, L10; Fig. 4). The Kerr–Schild shear is h̄ = 1 + (M/r)e<sub>−</sub>(e<sub>−</sub>·) with e<sub>−</sub> = e<sub>t</sub> − e<sub>r</sub> null: '
  'N² = 0 and det h̄ = 1 (G3b), and the inverse metric is η + (2M/r)ll with l null (G3c).</p>'
  '<p>The vector e<sub>t</sub> − e<sub>r</sub> is a null vector of the non-degenerate algebra Cl(1,1) (G3a): a null vector with a partner, the paired null of <code>cat_check.py</code> M2. It is not the atlas\'s label 0, a generator with square 0. '
  'That one has no partner: in the null-surface step it is the radical of the tangent algebra Cl(0, n − 2, 1) (<code>null_selfcheck.py</code> S5.7). The page does not say that the horizon is the label 0.</p>',
  '<p><b>Standard</b> (LDG; the charts and the time shifts), <b>checked</b> (G2, G3, G7). <b>Ours</b>: reading the three zones as the three classes of the trio, and the distinction between a paired and an unpaired null.</p>'
  '%%FIG_HORIZON%%',
  'G2a–G2c, G3a–G3c, G7a–G7d, L10'),

 ('F12', 'Time reversal turns the infalling gauge into the outgoing one', ['standard', 'checked', 'ours'],
  '<p>Time reversal is the single reflection a ↦ −e<sub>t</sub>ae<sub>t</sub>, a grade-1 element of Pin with determinant −1 (G5a). It turns the infalling gauge into the outgoing one: T h̄<sub>g</sub> T = h̄<sub>−g</sub> (G5b). '
  'So T is not a symmetry of the fixed gauge; a displacement must follow it, as in LDG (6.88)–(6.91). Both gauges have det = 1: the shear does not touch the volume form (G5c).</p>',
  '<p><b>Standard</b>, <b>checked</b>. <b>Ours</b>: calling the discrete sign of g the time arrow of the gauge. Nothing is claimed about a direction of time in nature.</p>',
  'G5a–G5c'),

 ('F13', 'Curvature counts by dimension: Weyl first appears at n = 4', ['standard', 'checked', 'ours'],
  '<p>In n dimensions the Riemann tensor has n²(n² − 1)/12 components, Ricci has n(n + 1)/2, and the Weyl part is the difference: 6 = 6 + 0 at n = 3, 20 = 10 + 10 at n = 4, 50 = 15 + 35 at n = 5 (G6a; table). '
  'At n = 2 Riemann has one component. Weyl is zero for n ≤ 3 and first non-zero at n = 4 (G6c). In four dimensions the count of the curvature map on bivectors goes from 36 to 20 by one trivector identity (LDG 5.6; G6b). '
  'The threshold n = 4 is also where a bivector first has a square that is not a scalar: B² = scalar + 4-vector needs four independent directions.</p>%%TAB_COUNTS%%',
  '<p><b>Standard</b> counts, <b>checked</b> (G6a–G6c). <b>Ours</b>: the remark that the two thresholds coincide. It is stated as a coincidence of thresholds, not as an explanation of one by the other.</p>',
  'G6a–G6c'),
]

# dictionary rows: (object in Hestenes / LDG, in the bit rule, tags, checks)
DICT = [
 ('Time direction γ<sub>0</sub>', 'label 1, the generator that squares to +1', 'input', 'H1'),
 ('Space directions γ<sub>1</sub>, γ<sub>2</sub>, γ<sub>3</sub>', 'labels 2, 4, 8; each squares to −1', 'standard · checked', 'S1a'),
 ('Pseudoscalar I = γ<sub>0</sub>γ<sub>1</sub>γ<sub>2</sub>γ<sub>3</sub>', 'label 15; I² = −1; anticommutes with vectors, central in the even part', 'standard · checked', 'H2, S2a–S2d'),
 ('Pauli vectors σ<sub>k</sub> = γ<sub>k</sub>γ<sub>0</sub>', 'labels 3, 5, 9; σ<sub>k</sub>² = +1; σ<sub>1</sub>σ<sub>2</sub>σ<sub>3</sub> = I', 'standard · checked', 'S1a, S1b, S2b'),
 ('The “i” of the Dirac equation, J = γ<sub>2</sub>γ<sub>1</sub> = Iσ<sub>3</sub>', 'label 6 up to sign; J² = −1; commutes with γ<sub>0</sub>', 'standard · checked · input', 'H1, S3a, S3b'),
 ('Dirac spinor ψ', 'an even multivector: eight real components on the labels 0, 3, 5, 6, 9, 10, 12, 15', 'standard · checked', 'H8, S4a'),
 ('Complex structure on ψ', 'right multiplication by J; left multiplication is the rotor action', 'checked · input', 'S5a, S5b'),
 ('Dirac equation ∇ψJ = mψγ<sub>0</sub>', 'a linear map on the eight components; det = |p² − m²|⁴ on plane waves', 'input · checked', 'H3, H9, S6a'),
 ('Rest-frame solutions', 'kernel on labels 0, 6, 10, 12 at p = (m, 0, 0, 0); on labels 3, 5, 9, 15 at p = (−m, 0, 0, 0)', 'checked', 'H4–H6'),
 ('Chirality (−γ<sub>5</sub>)', 'XOR with 9: the pairs 0 ↔ 9, 3 ↔ 10, 5 ↔ 12, 6 ↔ 15', 'checked · ours', 'H16–H22'),
 ('Yvon–Takabayasi angle β', 'ψψ̃ = a + bI on the labels 0 and 15', 'standard · checked', 'H24, H28, H29'),
 ('Pointor', 'the slice b = 0, β ∈ {0, π}; ψIψ̃ proportional to I', 'standard · checked · ours', 'H25–H27'),
 ('Current X = ψγ<sub>0</sub>ψ̃', 'a vector (label of grade 1) with X² = ρ²', 'standard · checked', 'H30'),
 ('Electromagnetic field F = E + IB', 'a bivector: E on labels 3, 5, 9, IB on labels 12, 10, 6', 'standard · checked · input', 'S7a–S7c'),
 ('Maxwell ∇F = J', 'grade 1 (Gauss, Ampère) and grade 3 (Faraday, ∇·B = 0) of one equation', 'standard · checked · input', 'H11–H14, S11a–S11c'),
 ('Lorentz force F·u', 'the commutator product, the grade-1 part of Fu', 'standard · checked', 'H15'),
 ('Lorentz group Spin(1,3)', 'the six bivector labels (two bits set) close into so(1,3) = sl(2,ℂ)', 'standard · checked', 'S8a'),
 ('Rotation, boost, null element', 'bivectors with square −1, +1, 0: the trio of squares', 'checked · ours', 'S9a'),
 ('Dirac action', 'Euler–Lagrange = T · Dirac, |det T| = 256', 'standard · checked · input', 'A1, A2, S12a'),
 ('Gauge field h̄', 'a linear map of the vector space, not an element of the algebra; in the Newtonian gauge 1 + N with N² = 0', 'standard · checked · input', 'G1a–G1d, G4a'),
 ('Weyl map of a point mass', 'B ↦ −(M/2r³)(B + 3σ<sub>r</sub>Bσ<sub>r</sub>) on the six bivector labels', 'standard · checked', 'L6, L7, S10a–S10c, G8c'),
 ('Horizon generator e<sub>t</sub> − e<sub>r</sub>', 'a paired null vector of Cl(1,1); not the label 0', 'checked · ours', 'G2b, G3a, G7a'),
 ('Time reversal', 'the reflection a ↦ −e<sub>t</sub>ae<sub>t</sub>, one grade-1 element of Pin', 'checked', 'G5a–G5c'),
]

# the inputs: (id, what the physics page needs, what the algebra does supply, where it enters)
INPUTS = [
 ('I1', 'The time direction and the signature', 'Both cells Cl(1,3) and Cl(3,1) exist with all their labels; each carries a real Dirac operator. Which is spacetime is a convention, and the +1 generator is called γ<sub>0</sub> here.', 'H1, S1a, S2a'),
 ('I2', 'The chart and the derivative', 'The algebra is the fibre: it has no coordinates and no ∂. The page takes ∇ = γ<sup>μ</sup>∂<sub>μ</sub> on functions of x, and plane waves for the Dirac checks.', 'H3, H11, H12, S11a'),
 ('I3', 'The grade a field lives in', 'ψ is even (eight components), F is a bivector, the source is a vector. The algebra shows the consequences of each choice (the splits into grades), not the choice.', 'H8, S7a, H11'),
 ('I4', 'The complex structure J', 'Several elements square to −1 (the rotation bivectors, I). J = γ<sub>2</sub>γ<sub>1</sub>, acting from the right, is the one that makes the even subalgebra a complex space on which the left action is the rotor action.', 'H1, H7–H10, S5a, S5b'),
 ('I5', 'The equations', 'The algebra checks properties of the Dirac equation, of ∇F = J and of the Dirac action; it does not make them the equations of anything.', 'H3–H9, H11–H15, A1, A2'),
 ('I6', 'The form of the shear', 'g² = 2M/r is the Schwarzschild solution as LDG write it. The metric it gives is tested for Ricci = 0 and for the mass, and the controls show that the test would see another g; the gauge field equations are not decoded.', 'G1a–G1d, L1–L5, G8a, G8b'),
 ('I7', 'The coupling', 'The sign and the size of the source term eX are not derived; the chiral coupling is not drawn.', 'H21, H22'),
]

LIMITS_REACH = [
 '<b>The field equations of gauge-theory gravity.</b> The gauge-field equations of LDG, the torsion and spin-density terms, and the action from which they follow are not decoded. Only the metric of one solution is tested, directly.',
 '<b>Other parts of LDG.</b> Cosmology, the rotating solution, the Hawking-radiation sections: not read for this report.',
 '<b>The Dirac equation in a gravitational field.</b> The Dirac equation is checked in flat space, and gravity at the level of one metric (free fall, the curvature operator, the horizon); the covariant derivative of a spinor in the gauge fields is not built.',
 '<b>The chiral coupling and the coupling constants.</b> Not drawn and not derived (F4, F8).',
 '<b>Analysis and topology.</b> Hilbert-space structure, boundary conditions, the global topology of the spin group: not touched.',
]
LIMITS_DONE = [
 'The independent scripts use floating-point arithmetic with the tolerances their lines state (1e-9 or better for the algebra, finite differences for the curvature, an ODE integrator for the geodesics). <code>gtg_check.py</code> is exact where its lines say so. An identity of multivectors means a difference below the tolerance.',
 'Equations are cited by the numbers the checks quote (LDG 2.45, 3.38, 5.6, 5.21, 5.22, 6.79, 6.83, 6.88–6.91, A.3); page numbers are not given.',
 'The conventions are those of LDG appendix A as the scripts implement them: σ<sub>k</sub> = γ<sub>k</sub>γ<sub>0</sub>, I = γ<sub>0</sub>γ<sub>1</sub>γ<sub>2</sub>γ<sub>3</sub>, ∇ = γ<sup>μ</sup>∂<sub>μ</sub>, the reciprocal frame. Another convention changes signs in the formulas.',
 'The second implementation of the algebra (<code>stalg.py</code>) shares no code with the atlas, but it was written by the same authors: independent here means separate code, not separate authorship.',
 'The vacuum test uses two charts of one metric and one control chart; it does not test the shear at other masses than the ones named in L5, G8b.',
 '<code>gtg_check.py</code> also has parts R and F (Roelfs–De Keninck, transvections). They belong to steps 1, 12 and 17 and are not part of this report.',
]

SOURCES = [
 'D. Hestenes, <i>Space-Time Algebra</i> (Gordon and Breach, 1966; second edition, Birkhäuser, 2015): the Dirac equation ∇ψJ = mψγ<sub>0</sub>, pointors, Maxwell ∇F = J.',
 'A. Lasenby, C. Doran, S. Gull, <i>Gravity, gauge theories and geometric algebra</i>, Phil. Trans. R. Soc. Lond. A 356 (1998) 487–582, <a href="https://arxiv.org/abs/gr-qc/0405033">arXiv:gr-qc/0405033</a>: read for the equations the checks name (2.45, 3.38, 5.6, 5.21, 5.22, 6.79, 6.83, 6.88–6.91, appendix A); the rest is not decoded.',
 'D. Lundholm, L. Svensson, <i>Clifford algebra, geometric algebra, and applications</i>, lecture notes, KTH, rev. 7 June 2016 (Theorem 5.5 and Table 5.1 for the cells).',
 'H. B. Lawson, M.-L. Michelsohn, <i>Spin Geometry</i>, Princeton University Press, 1989 (Chapter I, §4).',
 'S. Hsu, A. Barker, M. Hobson, A. Lasenby, <i>The radial metric function does not identify null surfaces</i>, <a href="https://arxiv.org/abs/2504.13255">arXiv:2504.13255</a> (the null-surface step 13, which the horizon finding F11 points to).',
 'The atlas package: steps 4, 5, 12 and 13 and Calibration 1; <code>selfcheck/steps15_17/gtg_check.py</code> and <code>bitcliff.py</code> (copied here byte for byte), <code>cat_check.py</code>, <code>null_selfcheck.py</code>, <code>groups_check.py</code>.',
]

CHECK_BLOCKS = [  # (first letter of the id, what it tests, script)
 ('H', 'Hestenes\' space-time algebra, independent implementation: cell facts, the Dirac map, its kernels, the 4 × 4 form, the chirality, pointors, Maxwell, the Lorentz force', 'hest_indep.py'),
 ('L', 'Gauge-theory gravity, independent: vacuum test of three charts, controls, the curvature operator, free fall, the time shifts', 'ldg_indep.py'),
 ('A', 'The free Dirac action: Euler–Lagrange against Hestenes\' equation', 'ldg_action.py'),
 ('S', 'The space-time algebra in the atlas\'s engine: names, the “i”, plane waves, Maxwell, the Lorentz group, the Weyl map, the action', 'gtg_check.py S'),
 ('G', 'Gauge fields as shears in the atlas\'s engine: the Newtonian gauge, Kerr–Schild, the horizon classes, time reversal, curvature counts, the three charts', 'gtg_check.py G'),
]
