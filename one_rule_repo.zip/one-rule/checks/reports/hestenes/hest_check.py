#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The checks of the Hestenes and gauge-theory-gravity report, in one run and one format (`ok   <id>: <text>`):
  H1-H30  hest_indep.py   spacetime algebra, Dirac equation, chirality, pointors, Maxwell, Lorentz force   (own algebra, numpy)
  L1-L10  ldg_indep.py    metrics of the shears: vacuum, Kretschmann scalar, curvature operator, free fall, Kerr-Schild as a time shift   (numpy, scipy)
  A1-A2   ldg_action.py   the Euler-Lagrange equation of the free Dirac action
  S, G    gtg_check.py S G   the same statements in the atlas's own engine (bitcliff.py), parts S (spacetime algebra) and G (gauge fields as shears); byte-identical to selfcheck/steps15_17/gtg_check.py;
          its lines are renumbered here (S1a, S1b, ... where the script reuses an id)
Prints the lines of the four scripts and a last line `checks: N ok, M failed`; exit 1 if anything fails.   Run: python3 hest_check.py"""
import os, re, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = [(['hest_indep.py'], r'(ok  |FAIL) (H\d+): (.*)'), (['ldg_indep.py'], r'(ok  |FAIL) (L\d+): (.*)'), (['ldg_action.py'], r'(ok  |FAIL) (A\d+): (.*)'),
        (['gtg_check.py', 'S', 'G'], r'\s+(ok  |FAIL) ([SG]\d+) (.*)')]
nok = nbad = 0; out = []; rc_all = 0
for cmd, pat in RUNS:
    r = subprocess.run([sys.executable] + cmd, cwd=HERE, capture_output=True, text=True)
    if r.returncode != 0 and cmd[0] != 'gtg_check.py': rc_all = 1
    rows = [m.groups() for m in (re.match(pat, l) for l in r.stdout.split('\n')) if m]
    if not rows: print('FAIL %s: no check line (exit %d) %s' % (cmd[0], r.returncode, r.stderr[-300:])); rc_all = 1
    seen = {}
    for st, cid, text in rows:
        if cmd[0] == 'gtg_check.py':                                    # the script reuses an id for several lines: S1a, S1b, ...
            seen[cid] = seen.get(cid, 0) + 1; cid = cid + 'abcdefghijklmnopqrstuvwxyz'[seen[cid] - 1]
        good = st.strip() == 'ok'
        nok += good; nbad += not good
        out.append(('ok   ' if good else 'FAIL ') + cid + ': ' + text.strip())
print('\n'.join(out)); print('\nchecks: %d ok, %d failed' % (nok, nbad)); sys.exit(1 if (nbad or rc_all) else 0)
