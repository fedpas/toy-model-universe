#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Automated sabotage test for the independent checks of this folder (hest_indep.py, ldg_indep.py, ldg_action.py and the algebra stalg.py they share): each mutant changes one line of a
temporary copy (a wrong sign, exponent, signature, label or constant); the run must FAIL the named check (a crash does not count as caught).  gtg_check.py is not mutated: it is a
byte-identical copy of the script of the atlas and is sabotaged by selfcheck/steps15_17/run_mutations.py.   Run: python3 mutate_hestenes.py   (about 1 minute)"""
import os, sys, subprocess, tempfile, re, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
F = ['hest_indep.py', 'ldg_indep.py', 'ldg_action.py', 'stalg.py']
SRC = {f: open(os.path.join(HERE, f), encoding='utf-8').read() for f in F}
M = [  # (name, file, old, new, id of the check that must fail)
 ('M1  stalg: J = gamma1 gamma2 instead of gamma2 gamma1', 'stalg.py', "J = gp(g[2], g[1])", "J = gp(g[1], g[2])", 'H1'),
 ('M2  stalg: no anticommutation sign in the bit rule', 'stalg.py', "s = -1 if swaps % 2 else 1", "s = 1", 'H1'),
 ('M3  stalg: the reciprocal frame equals the frame', 'stalg.py', "gup = [g[0], -g[1], -g[2], -g[3]]", "gup = [g[0], g[1], g[2], g[3]]", 'H9'),
 ('M4  H3: determinant exponent 2 instead of 4', 'hest_indep.py', "abs(abs(d) - abs((p2 - m * m) ** 4))", "abs(abs(d) - abs((p2 - m * m) ** 2))", 'H3'),
 ('M5  H4: kernel looked for at p = (-m,0,0,0) instead of (m,0,0,0)', 'hest_indep.py', "K = symbol(prest, m); ns", "K = symbol(-prest, m); ns", 'H4'),
 ('M6  H5: the negative-energy kernel claimed to be the positive-energy one', 'hest_indep.py', "set(kb2) == {3, 5, 9, 15}", "set(kb2) == {0, 6, 10, 12}", 'H5'),
 ('M7  H7: the column u = (0,0,1,0) instead of (1,0,0,0)', 'hest_indep.py', "u = np.array([1, 0, 0, 0], complex)", "u = np.array([0, 0, 1, 0], complex)", 'H7'),
 ('M8  H9: Dirac matrices with the spatial sign of the lower index dropped', 'hest_indep.py', "Glow = [Gup[0]] + [-x for x in Gup[1:]]", "Glow = [Gup[0]] + [x for x in Gup[1:]]", 'H9'),
 ('M9  H11: Faraday term with the wrong sign of the curl', 'hest_indep.py', "faraday = np.allclose(biv[1:], dB[0][1:] + cE[1:])", "faraday = np.allclose(biv[1:], dB[0][1:] - cE[1:])", 'H11'),
 ('M10 H14: the symbol of a null p claimed to have full rank', 'hest_indep.py', "SR['null'] == (3, 3, 4)", "SR['null'] == (3, 3, 6)", 'H14'),
 ('M11 H15: the Lorentz force with E - v x B', 'hest_indep.py', "(E + np.cross(v, B))[k - 1] * g[k]", "(E - np.cross(v, B))[k - 1] * g[k]", 'H15'),
 ('M12 H16: chirality claimed to be XOR with 10', 'hest_indep.py', "flip[mm][0] == mm ^ 9", "flip[mm][0] == mm ^ 10", 'H16'),
 ('M13 H18: I psi J claimed to be +psi sigma3', 'hest_indep.py', "np.allclose(gp(gp(I, psi), J), -gp(psi, sig3)) and", "np.allclose(gp(gp(I, psi), J), gp(psi, sig3)) and", 'H18'),
 ('M14 H19: eigenspaces claimed 5 + 3', 'hest_indep.py', "sorted(ev).count(1.0) == 4", "sorted(ev).count(1.0) == 5", 'H19'),
 ('M15 H21: the derivative term claimed to commute with the chirality', 'hest_indep.py', "ok1 &= np.allclose(Kc, -CK)", "ok1 &= np.allclose(Kc, CK)", 'H21'),
 ('M16 H23: the sign of a claimed opposite to the sign of the energy', 'hest_indep.py', "q[0] * E_sign > 0", "q[0] * E_sign < 0", 'H23'),
 ('M17 H25: pointors claimed to be the elements with a = 0', 'hest_indep.py', "cnt += (pt == np.isclose(b, 0))", "cnt += (pt == np.isclose(a, 0))", 'H25'),
 ('M18 H30: X^2 claimed to be a^2 - b^2', 'hest_indep.py', "np.isclose(X2[0], a * a + b * b)", "np.isclose(X2[0], a * a - b * b)", 'H30'),
 ('M19 L1: Kretschmann scalar compared with 24 M^2/r^6', 'ldg_indep.py', "abs(K / (48 * M * M * k2 / r ** 6) - 1) < 1e-5", "abs(K / (24 * M * M * k2 / r ** 6) - 1) < 1e-5", 'L1'),
 ('M20 L2: Kerr-Schild with a non-null vector (1 - q) instead of (1 + q) in g_rr', 'ldg_indep.py', "G[1, 1] = -(1 + q); G[2, 2] = -r * r; G[3, 3] = -(r * np.sin(th)) ** 2; return G\ndef g_s", "G[1, 1] = -(1 - q); G[2, 2] = -r * r; G[3, 3] = -(r * np.sin(th)) ** 2; return G\ndef g_s", 'L2'),
 ('M21 L6: the curvature operator without the metric signs eta_aa eta_bb', 'ldg_indep.py', "Kop[i, j] = eta[a, a] * eta[b, b] * Rf[a, b, c, d]", "Kop[i, j] = Rf[a, b, c, d]", 'L6'),
 ('M22 L7: the operator B + 2 sigma_r B sigma_r instead of B + 3 sigma_r B sigma_r', 'ldg_indep.py', "Bv + 3 * ST.gp(ST.gp(s_r, Bv), s_r)", "Bv + 2 * ST.gp(ST.gp(s_r, Bv), s_r)", 'L7'),
 ('M23 L9: the conserved quantity with +r-dot', 'ldg_indep.py', "- u[1] * np.sqrt(2 * M / xx[1]) - alpha))", "+ u[1] * np.sqrt(2 * M / xx[1]) - alpha))", 'L9'),
 ('M24 L10: the time shift with the wrong sign of the cross term', 'ldg_indep.py', "c_rr = gtt * phi_p ** 2 + 2 * gtr * phi_p + grr", "c_rr = gtt * phi_p ** 2 - 2 * gtr * phi_p + grr", 'L10'),
 ('M25 A2: the action with I gamma_2 instead of I gamma_3', 'ldg_action.py', "Ig3 = gp(I, g[3])", "Ig3 = gp(I, g[2])", 'A2'),
 ('M26 A2: the Dirac map with +m psi gamma_0', 'ldg_action.py', "for mu in range(4)) - m * gp(mv(psi), g[0])", "for mu in range(4)) + m * gp(mv(psi), g[0])", 'A2'),
]
caught = 0; lines = []
for name, target, old, new, cid in M:
    src = SRC[target]
    if src.count(old) != 1:
        lines.append(f'ERROR {name}: pattern found {src.count(old)} times'); continue
    with tempfile.TemporaryDirectory() as td:
        for f in F: open(os.path.join(td, f), 'w', encoding='utf-8').write(SRC[f] if f != target else src.replace(old, new))
        script = target if target != 'stalg.py' else ('hest_indep.py' if cid.startswith('H') else 'ldg_indep.py')
        r = subprocess.run([sys.executable, os.path.join(td, script)], capture_output=True, text=True, timeout=600)
    failed = re.findall(r'^FAIL ([A-Z]\d+)', r.stdout, re.M)
    crash = r.returncode != 0 and 'Traceback' in r.stderr
    hit = cid in failed
    caught += hit
    lines.append(f"{'caught' if hit else 'MISSED'}  {name}  -> failing: {','.join(failed) or '-'}{'  (crash)' if crash else ''}")
for l in lines: print(l)
print(f'mutants caught: {caught} of {len(M)}')
sys.exit(0 if caught == len(M) else 1)
