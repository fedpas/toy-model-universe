#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Independent check of the gauge-theory-gravity pieces that the atlas reads from Lasenby, Doran and Gull (LDG): the metrics that the Newtonian-gauge shear and the Kerr-Schild
shear give are vacuum with Kretschmann scalar 48 M^2/r^6; the curvature operator in an orthonormal frame has the eigenvalues of the point-mass Weyl map; free fall in the
Painleve-Gullstrand metric; the Kerr-Schild chart as a time shift of the Painleve-Gullstrand chart.  The curvature comes from the metric alone, by finite differences (numpy),
the geodesics by scipy; nothing is imported from the atlas.  Signature (+,-,-,-), coordinates (t, r, theta, phi), M = 1.   One line `ok   L<n>: ...` per check, exit 1 if one fails.
Run: python3 ldg_indep.py"""
import os, sys
import numpy as np
from scipy.integrate import solve_ivp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import stalg as ST
M = 1.0
NOK = NBAD = 0
def check(text, cond):
    global NOK, NBAD
    if cond: NOK += 1
    else: NBAD += 1
    print(('ok   ' if cond else 'FAIL ') + 'L%d: %s' % (NOK + NBAD, text))

def g_pg(x, k=2.0):            # Painleve-Gullstrand, from hbar(a) = a - g (a.e_r) e_t:  ds^2 = dt^2 - (dr + g dt)^2 - r^2 dOmega^2,  g^2 = k M / r  (k = 2: Schwarzschild); 'bad': g^2 = 2 M^2/r^2
    t, r, th, ph = x; g = np.sqrt(k * M / r) if k != 'bad' else np.sqrt(2 * M * M / r ** 2)
    G = np.zeros((4, 4)); G[0, 0] = 1 - g * g; G[0, 1] = G[1, 0] = -g; G[1, 1] = -1; G[2, 2] = -r * r; G[3, 3] = -(r * np.sin(th)) ** 2; return G
def g_ks(x):                   # Kerr-Schild (Eddington) form, from hbar(a) = a + (M/r)(a.e_-)e_-:  g = eta - (2M/r) l l,  l = (1, 1)
    t, r, th, ph = x; q = 2 * M / r
    G = np.zeros((4, 4)); G[0, 0] = 1 - q; G[0, 1] = G[1, 0] = -q; G[1, 1] = -(1 + q); G[2, 2] = -r * r; G[3, 3] = -(r * np.sin(th)) ** 2; return G
def g_s(x):                    # Schwarzschild coordinates (control)
    t, r, th, ph = x; f = 1 - 2 * M / r
    return np.diag([f, -1 / f, -r * r, -(r * np.sin(th)) ** 2])
def d1(F, x, k, h):            # 4th-order central derivative of an array-valued function with respect to coordinate k
    e = np.zeros(4); e[k] = h
    return (-F(x + 2 * e) + 8 * F(x + e) - 8 * F(x - e) + F(x - 2 * e)) / (12 * h)
def christoffel(gf, x, h=1e-3):
    Gi = np.linalg.inv(gf(x)); dG = np.array([d1(gf, x, k, h) for k in range(4)])          # dG[k,a,b] = d_k g_ab
    return 0.5 * np.einsum('ls,msn->lmn', Gi, dG.transpose(0, 1, 2)) + 0.5 * np.einsum('ls,nsm->lmn', Gi, dG) - 0.5 * np.einsum('ls,smn->lmn', Gi, dG)
def riemann(gf, x, h=1e-3):    # R^r_{s m n} = d_m Gam^r_{n s} - d_n Gam^r_{m s} + Gam^r_{m l} Gam^l_{n s} - Gam^r_{n l} Gam^l_{m s}
    Gam = christoffel(gf, x, h)
    dGam = np.array([d1(lambda y: christoffel(gf, y, h), x, k, h * 5) for k in range(4)])   # dGam[k,r,m,n]
    R = np.einsum('mrns->rsmn', dGam) - np.einsum('nrms->rsmn', dGam) + np.einsum('rml,lns->rsmn', Gam, Gam) - np.einsum('rnl,lms->rsmn', Gam, Gam)
    return R, Gam
def invariants(gf, x):
    R, Gam = riemann(gf, x); G = gf(x); Gi = np.linalg.inv(G)
    Ric = np.einsum('rsrn->sn', R); Rl = np.einsum('ab,bscd->ascd', G, R)
    Ru = np.einsum('ai,sj,ck,dl,ijkl->ascd', Gi, Gi, Gi, Gi, Rl)
    return np.abs(Ric).max(), np.einsum('ascd,ascd->', Rl, Ru), R, G, Rl
x0 = np.array([0.3, 4.1, 1.1, 0.4])
def at(r): x = x0.copy(); x[1] = r; return x
def vacuum(gf, r, k2=1.0):
    ric, K, *_ = invariants(gf, at(r)); return ric < 1e-6 and abs(K / (48 * M * M * k2 / r ** 6) - 1) < 1e-5
check('the Painleve-Gullstrand shear (g^2 = 2M/r) gives a vacuum metric (Ricci = 0 to finite-difference accuracy, below 1e-6) with Kretschmann scalar 48 M^2/r^6, at r = 4.1 and r = 1.3 (inside the horizon)', vacuum(g_pg, 4.1) and vacuum(g_pg, 1.3))
check('the Kerr-Schild null shear gives a vacuum metric with Kretschmann scalar 48 M^2/r^6, at r = 4.1 and r = 1.3', vacuum(g_ks, 4.1) and vacuum(g_ks, 1.3))
check('Schwarzschild coordinates (control) give the same vacuum test and the same Kretschmann scalar at r = 4.1', vacuum(g_s, 4.1))
ric_bad, K_bad, *_ = invariants(lambda y: g_pg(y, 'bad'), at(4.1))
check('control: the shear with g^2 = 2M^2/r^2 is not vacuum (max |Ricci| above 0.05)', ric_bad > 0.05)
check('control: the shear with g^2 = 3M/r is vacuum with the mass 3M/2: Kretschmann scalar 48 (3M/2)^2/r^6, so g^2 = 2M/r is not a free choice', vacuum(lambda y: g_pg(y, 3.0), 4.1, k2=2.25))
# curvature operator in the orthonormal frame of the PG shear
def coframe_pg(x):             # theta^0 = dt, theta^1 = dr + g dt, theta^2 = r dtheta, theta^3 = r sin(theta) dphi
    t, r, th, ph = x; g = np.sqrt(2 * M / r)
    C = np.zeros((4, 4)); C[0, 0] = 1; C[1, 0] = g; C[1, 1] = 1; C[2, 2] = r; C[3, 3] = r * np.sin(th); return C
x = x0.copy(); _, _, R, G, Rl = invariants(g_pg, x)
C = coframe_pg(x); E = np.linalg.inv(C); eta = np.diag([1., -1, -1, -1])
assert np.allclose(C.T @ eta @ C, G)               # the coframe is orthonormal for the PG metric
Rf = np.einsum('ia,jb,kc,ld,ijkl->abcd', E, E, E, E, Rl)
pairs = [(a, b) for a in range(4) for b in range(a + 1, 4)]
Kop = np.zeros((6, 6))
for i, (a, b) in enumerate(pairs):
    for j, (c, d) in enumerate(pairs): Kop[i, j] = eta[a, a] * eta[b, b] * Rf[a, b, c, d]
unit = M / x[1] ** 3
ev = np.sort(np.linalg.eigvals(Kop).real) / unit
check('the curvature operator R^{ab}_{cd} of the metric, in the orthonormal frame of the shear at r = 4.1, has the eigenvalues (-2, -2, 1, 1, 1, 1) M/r^3 (error below 1e-5) and trace 0', np.allclose(ev, [-2, -2, 1, 1, 1, 1], atol=1e-5) and abs(ev.sum()) < 1e-5)
s_r = ST.gp(ST.g[1], ST.g[0])                        # sigma_r = gamma_1 gamma_0 (radial direction = axis 1)
biv = [a for a in range(16) if ST.grade(a) == 2]
Wm = np.zeros((6, 6))
for j, a in enumerate(biv):
    Bv = ST.bl(a); out = Bv + 3 * ST.gp(ST.gp(s_r, Bv), s_r)
    for i, b in enumerate(biv): Wm[i, j] = out[b]
w = np.sort(np.linalg.eigvals(Wm).real)
check('the operator B -> B + 3 sigma_r B sigma_r on the six bivectors of the bit-rule algebra has the eigenvalues (-2, -2, -2, -2, 4, 4); times -M/2r^3 they are the eigenvalues of the curvature operator above', np.allclose(w, [-2, -2, -2, -2, 4, 4]) and np.allclose(np.sort(-0.5 * w), [-2, -2, 1, 1, 1, 1]))
# geodesics of the PG metric: LDG (6.83)-(6.87)
def geod(tau, y):
    xx = y[:4]; u = y[4:]; Gam = christoffel(g_pg, xx, 1e-4)
    return np.concatenate([u, -np.einsum('lmn,m,n->l', Gam, u, u)])
def run(alpha, r0=12.0, th0=np.pi / 2):
    g0 = np.sqrt(2 * M / r0); rd = -np.sqrt(alpha ** 2 - (1 - 2 * M / r0)); td = (alpha + rd * g0) / (1 - 2 * M / r0)
    y0 = np.array([0, r0, th0, 0, td, rd, 0, 0]); G = g_pg(y0[:4]); u = y0[4:]
    assert abs(u @ G @ u - 1) < 1e-12
    return solve_ivp(geod, [0, 28], y0, rtol=1e-10, atol=1e-12, dense_output=True, max_step=0.05)
good = {}
for alpha in (1.0, 1.4):
    sol = run(alpha); w_acc = w_cons = w_norm = w_rain = 0; rmin = 99
    for tau in np.linspace(0.2, 24.0, 120):
        y = sol.sol(tau); xx = y[:4]; u = y[4:]
        if xx[1] < 0.5: break
        rmin = min(rmin, xx[1]); acc = geod(tau, y)[4:]
        w_acc = max(w_acc, abs(acc[1] - (-M / xx[1] ** 2)))
        w_cons = max(w_cons, abs((1 - 2 * M / xx[1]) * u[0] - u[1] * np.sqrt(2 * M / xx[1]) - alpha))
        w_norm = max(w_norm, abs(u @ g_pg(xx) @ u - 1))
        if alpha == 1.0: w_rain = max(w_rain, abs(u[0] - 1), abs(u[1] + np.sqrt(2 * M / xx[1])))
    good[alpha] = (rmin < 2, w_acc < 1e-7, w_cons < 1e-6, w_norm < 1e-6, w_rain < 1e-6)
check('free fall in the Painleve-Gullstrand metric, from the Christoffel symbols of the metric alone: d^2 r/d tau^2 = -M/r^2 (Newton) on both sides of r = 2M, for the energies alpha = 1 and alpha = 1.4, from r = 12 down to r = 0.5 (error below 1e-7)', all(good[a][0] and good[a][1] and good[a][3] for a in good))
check('the quantity (1 - 2M/r) t-dot - r-dot sqrt(2M/r) = alpha is conserved along those geodesics (LDG 6.83), and for alpha = 1 (fall from rest at infinity) t-dot = 1 and r-dot = -sqrt(2M/r): the rain crosses r = 2M with nothing special happening', all(good[a][2] for a in good) and good[1.0][4])
# Kerr-Schild as a time shift of PG
r = np.linspace(0.4, 9, 7); gg = np.sqrt(2 * M / r); phi_p = gg / (1 + gg)
gtt = 1 - gg ** 2; gtr = -gg; grr = -1
c_tr = gtt * phi_p + gtr; c_rr = gtt * phi_p ** 2 + 2 * gtr * phi_p + grr
q = 2 * M / r
roots_ok = all(np.isclose(min(abs(np.roots([1 - qq, -2 * qq, -(1 + qq)]) + 1)), 0) for qq in (0.3, 1.7))
check('the Kerr-Schild chart is the Painleve-Gullstrand chart with the time shift t_PG = t_KS + integral of g/(1+g) dr, finite at the horizon: g_tr = -2M/r and g_rr = -(1 + 2M/r) exactly, and one ingoing null ray is t + r = const', np.allclose(c_tr, -2 * M / r) and np.allclose(c_rr, -(1 + 2 * M / r)) and roots_ok)
print('\nchecks: %d ok, %d failed' % (NOK, NBAD)); sys.exit(1 if NBAD else 0)
