#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Independent check of LDG (3.38): the free Dirac action  S = < grad(psi) I gamma_3 psi~ - m psi psi~ >  (psi even, 8 real components, <> the scalar part) has the
Euler-Lagrange equation  grad(psi) I sigma_3 = m psi gamma_0  (LDG 3.37 with A = 0).  The Lagrangian is a quadratic form in (psi, d_mu psi); its Euler-Lagrange map and
the Dirac map are both linear maps from the 8 + 32 values (psi, d_mu psi) to the 8 odd components; they are compared.  Own bit-rule algebra (stalg.py), numpy only.
One line `ok   A<n>: ...` per check, exit 1 if one fails.   Run: python3 ldg_action.py"""
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stalg import *
NOK = NBAD = 0
def check(text, cond):
    global NOK, NBAD
    if cond: NOK += 1
    else: NBAD += 1
    print(('ok   ' if cond else 'FAIL ') + 'A%d: %s' % (NOK + NBAD, text))
sc = lambda x: x[0]
Ig3 = gp(I, g[3])
B = np.zeros((4, 8, 8)); S = np.zeros((8, 8))                       # L = sum_mu psi_mu^T B^mu psi - m psi^T S psi
for mu in range(4):
    for i, a in enumerate(EVEN):
        for j, b in enumerate(EVEN): B[mu, i, j] = sc(gp(gp(gp(gup[mu], bl(a)), Ig3), rev(bl(b))))
for i, a in enumerate(EVEN):
    for j, b in enumerate(EVEN): S[i, j] = sc(gp(bl(a), rev(bl(b))))
assert np.allclose(S, S.T)
m = 0.83
def mv(c):
    x = np.zeros(N)
    for k, a in enumerate(EVEN): x[a] = c[k]
    return x
def EL_of(psi, dpsi): return sum((B[mu].T - B[mu]) @ dpsi[mu] for mu in range(4)) - 2 * m * (S @ psi)        # dL/dpsi - d_mu dL/d(d_mu psi)
def D_of(psi, dpsi):
    D = sum(gp(gup[mu], gp(mv(dpsi[mu]), gp(I, sig[3]))) for mu in range(4)) - m * gp(mv(psi), g[0])      # grad psi I sigma_3 - m psi gamma_0
    return np.array([D[a] for a in ODD])
n = 8 + 32
def basis(k):
    v = np.zeros(n); v[k] = 1; return v[:8], v[8:].reshape(4, 8)
ELm = np.array([EL_of(*basis(k)) for k in range(n)]).T              # 8 x 40
Dm = np.array([D_of(*basis(k)) for k in range(n)]).T                # 8 x 40
check('the Euler-Lagrange map of L = <grad psi I gamma_3 psi~ - m psi psi~> and the Dirac map psi -> grad psi I sigma_3 - m psi gamma_0 both have rank 8, and so does the map of the two stacked: the same solution space', 
      np.linalg.matrix_rank(ELm) == 8 and np.linalg.matrix_rank(Dm) == 8 and np.linalg.matrix_rank(np.vstack([ELm, Dm])) == 8)
T = ELm @ np.linalg.pinv(Dm)
check('Euler-Lagrange = T x Dirac exactly (residual below 1e-12) with T an invertible 8 x 8 matrix, |det T| = 256: the Euler-Lagrange equation is equivalent to Hestenes\' equation', np.abs(ELm - T @ Dm).max() < 1e-12 and abs(abs(np.linalg.det(T)) - 256) < 1e-6)
print('\nchecks: %d ok, %d failed' % (NOK, NBAD)); sys.exit(1 if NBAD else 0)
