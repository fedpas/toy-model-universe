#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Tests that ../html/hestenes_ldg_report.html agrees with its sources and behaves in a browser: every headline number equals the log; every check id the page names exists in the log
and every id of the log is named; each finding tagged checked names a check; the numbers in the text equal the lines of the log they come from; a fresh run of the checks gives the log;
the two copied scripts are byte-identical to the atlas's; the cross-references to other scripts exist; no external request, no address, no history wording, the forbidden sentences are
nowhere on the page.  Run after build_report_hestenes.py: python3 test_report_hestenes.py   (REPORT_NO_BROWSER=1 skips the browser tests, which are then reported as skipped and not counted)"""
import os, re, sys, html, json, subprocess, filecmp
HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..'))
import no_history as NH
import status_check as SK
import content_hestenes as C
import figs_hestenes as FG
PKG = os.path.abspath(os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..')))
PAGE = os.path.join(HERE, '..', 'html', 'hestenes_ldg_report.html')
page = open(PAGE, encoding='utf-8').read()
strip = lambda t: re.sub(r'<style.*?</style>|<script.*?</script>', '', t, flags=re.S)
plain = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', strip(page))))
tips = ' '.join(html.unescape(t) for t in re.findall(r'data-tip="([^"]*)"', page))
ok = bad = 0
def chk(name, cond, msg=''):
    global ok, bad
    if cond: ok += 1
    else: bad += 1
    print(('ok   ' if cond else 'FAIL ') + name + (': ' + msg if (msg and not cond) else ''))

LOG = open(os.path.join('logs', 'hest_check.log'), encoding='utf-8').read()
MUT = open(os.path.join('logs', 'mutate_hestenes.log'), encoding='utf-8').read()
LINES = {}; IDS = []
for l in LOG.splitlines():
    m = re.match(r'(ok  |FAIL) (\S+?): (.*)', l)
    if m: IDS.append(m.group(2)); LINES[m.group(2)] = m.group(3)
nlog = int(re.search(r'checks: (\d+) ok, 0 failed', LOG).group(1))

# ---- the headline numbers = the log
chk('T1 the log passes all and its count is the number of ok lines (95, ids distinct)', nlog == len(IDS) == len(set(IDS)) == 95 and 'FAIL' not in LOG, (nlog, len(IDS)))
def kpi(label):
    m = re.search(r'<div class="kpi"><b>([^<]+)</b><span>%s' % re.escape(label), page); return m.group(1) if m else None
chk('T2 headline: checks pass, 0 fail', kpi('checks pass') == str(nlog) and f'{nlog} pass, 0 fail' in plain, kpi('checks pass'))
mm = re.search(r'mutants caught: (\d+) of (\d+)', MUT)
chk('T3 sabotage: the log says all caught, the page says so, one line per mutant', bool(mm) and mm.group(1) == mm.group(2) and kpi('deliberate sabotages') == f'{mm.group(1)} of {mm.group(2)}'
    and len(re.findall(r'^caught', MUT, re.M)) == int(mm.group(2)) and 'MISSED' not in MUT and 'ERROR' not in MUT, str(mm.groups() if mm else None))
blocks = re.findall(r'<tr><td><b>([A-Z])</b></td><td>[^<]*</td><td class="num">(\d+)</td>', page)
chk('T4 five blocks H, L, A, S, G; each count equals the log; the total is the headline', [b for b, _ in blocks] == ['H', 'L', 'A', 'S', 'G'] and all(int(n) == sum(1 for i in IDS if i[0] == b) for b, n in blocks)
    and sum(int(n) for _, n in blocks) == nlog and f'<td class="num"><b>{nlog}</b></td>' in page, str(blocks))
chk('T5 13 findings F1-F13 and 7 inputs on the page; the headline numbers say so', all(f'id="f{i}"' in page for i in range(1, 14)) and kpi('findings, each') == '13' and kpi('inputs the physics page') == '7'
    and len(C.FINDINGS) == 13 and len(C.INPUTS) == 7)

# ---- check ids: every id the page names exists, every id of the log is named by a finding
def hit(i, x): return i == x or (i.startswith(x) and i[len(x)].isalpha())
def expand(spec):
    out = []
    for tok in [t.strip() for t in spec.split(',') if t.strip()]:
        m = re.fullmatch(r'([A-Z]\d+[a-z]?)(?:–([A-Z]\d+[a-z]?))?', tok)
        if not m: return None
        a, b = m.group(1), m.group(2) or m.group(1)
        ia = [k for k, i in enumerate(IDS) if hit(i, a)]; ib = [k for k, i in enumerate(IDS) if hit(i, b)]
        if not ia or not ib or ia[0] > ib[-1]: return None
        out += IDS[ia[0]:ib[-1] + 1]
    return out
spec_lists = [f[5] for f in C.FINDINGS] + [d[3] for d in C.DICT] + [d[3] for d in C.INPUTS]
chk('T6 every id list (findings, dictionary, inputs) is well formed and names existing ids', all(expand(s) for s in spec_lists), str([s for s in spec_lists if not expand(s)]))
cited = set()
for f in C.FINDINGS: cited |= set(expand(f[5]) or [])
chk('T7 every id of the log is named by a finding', cited == set(IDS), str(sorted(set(IDS) - cited)))
inline = set()
for m in re.finditer(r'(?<![\w.])([HLAS]\d+[a-z]?|G\d+[a-z]?)(?![\w]|\.\d)', re.sub(r'(?:logs|hest)[^ ]*', '', plain)):
    inline.add(m.group(1))
chk('T8 every id named in the running text (H3, S7a, ...) exists in the log', len(inline) >= 60 and all(any(hit(i, x) for i in IDS) for x in inline), str(sorted(x for x in inline if not any(hit(i, x) for i in IDS))))
tags_ok = {'standard', 'checked', 'ours', 'open', 'input'}
fin = {}
for m in re.finditer(r'<article class="finding" id="(f\d+)">.*?class="chips">(.*?)</div>.*?<p class="ids">checks ([^<]*)\.</p>', page, re.S):
    fin[m.group(1)] = (set(SK.kinds(m.group(2))), m.group(3))
chk('T9 each finding has tags from the five, and every finding tagged checked names at least one check (rule X3)', len(fin) == 13 and all(t <= tags_ok and t for t, _ in fin.values())
    and all(('checked' not in t) or (expand(s) and len(expand(s)) >= 1) for t, s in fin.values()), str(fin))
chk('T10 the dictionary has 23 rows, each with tags and checks; tags are from the five; each row shows its tags as icon chips, in the order of the content', len(re.findall(r'<tr><td>[^<]*(?:<sub>[^<]*</sub>[^<]*)*</td><td>', page.split('id="dict"')[1].split('id="inputs"')[0])) >= 23
    and len(C.DICT) == 23 and all(set(re.split(r' · ', d[2])) <= tags_ok for d in C.DICT)
    and [SK.kinds(r) for r in re.findall(r'<tr>(.*?)</tr>', page.split('id="dict"')[1].split('id="inputs"')[0], re.S)[1:]] == [d[2].split(' · ') for d in C.DICT])
chk('T11 the inputs I1-I7 are all on the page, each with checks', all(f'<td><b>I{i}</b></td>' in page for i in range(1, 8)) and [d[0] for d in C.INPUTS] == ['I%d' % i for i in range(1, 8)])

# ---- the numbers in the text = the lines of the log they come from
PINS = [('|det T| = 256', 'A2', '|det T| = 256'), ('134 with β = 0 or π and 66 generic', 'H25', '134 with beta = 0 or pi, 66 generic'), ('48M²/r⁶', 'L1', 'Kretschmann scalar 48 M^2/r^6'),
        ('(−2, −2, 1, 1, 1, 1)·M/r³', 'L6', '(-2, -2, 1, 1, 1, 1) M/r^3'), ('−16/25', 'G2a', '-16/25'), ('16/9', 'G2c', '16/9'), ('|p² − m²|⁴', 'H3', '|p^2 - m^2|^4'),
        ('40 random p and m', 'H3', '40 random p and m'), ('200 random ψ', 'H9', '200 random psi'), ('dimension 4 + 4', 'H19', '4 + 4'), ('all 216 triples', 'S8a', 'all 216 triples'),
        ('all 64 products', 'S4a', 'all 64 products'), ('ten random on-shell points, five of each sign', 'H22', '10 random on-shell p, 5 of each sign'), ('from r = 12 down to r = 0.5', 'L8', 'from r = 12 down to r = 0.5'),
        ('α = 1.4', 'L8', 'alpha = 1.4'), ('at r = 4.1 and inside the horizon at r = 1.3', 'L1', 'r = 4.1 and r = 1.3'), ('mass 3M/2', 'L5', '3M/2'), ('20 random samples', 'H11', '20 random samples'),
        ('40 random integer fields', 'S7a', '40 random integer fields'), ('36 to 20', 'G6b', '36 -> 20'), ('6 = 6 + 0 at n = 3, 20 = 10 + 10 at n = 4, 50 = 15 + 35 at n = 5', 'G6a', 'n=3: 6 = 6 + 0; n=4: 20 = 10 + 10; n=5: 50 = 15 + 35'),
        ('5 complex = 10 real degrees of freedom', 'S10c', '5 complex = 10 real dof'), ('4 + 4 for n = 4, 5 + 10 for n = 5', 'H13', 'n = 4: 4 + 4; n = 5: 5 + 10'),
        ('eigenvalue 4 on the radial pair', 'L7', '(-2, -2, -2, -2, 4, 4)'), ('(3, 3, 6) for a timelike and for a spacelike p and (3, 3, 4) for a null p', 'H14', 'rank 6 of 6'),
        ('rank N = 1', 'G1a', 'rank(N) = 1')]
bad_pins = [p for p in PINS if p[0] not in plain or p[2] not in LINES[p[1]]]
chk('T12 the numbers in the text are those of the log lines they cite (%d pins)' % len(PINS), not bad_pins, str(bad_pins))
rows = FG.counts_table()
chk('T13 the table of curvature counts: Riemann n²(n²−1)/12, Ricci n(n+1)/2, Weyl the difference, n = 3..8, and the rows of the log', rows == [(3, 6, 6, 0), (4, 20, 10, 10), (5, 50, 15, 35), (6, 105, 21, 84), (7, 196, 28, 168), (8, 336, 36, 300)]
    and all(f'<td class="num">{r[0]}</td><td class="num">{r[1]}</td><td class="num">{r[2]}</td><td class="num">{r[3]}</td>' in page for r in rows))
# the labels: from an independent bit-rule product (stalg.py), not from the page's own helper
import stalg as ST
sq = lambda m: ST.bsign(m, m)
chk('T14 the labels named on the page: gamma squares +1,-1,-1,-1; sigma_k (3,5,9) square +1; I sigma_k (12,10,6) and I (15) square -1; the even labels are 0,3,5,6,9,10,12,15; XOR 9 pairs them',
    [sq(m) for m in (1, 2, 4, 8)] == [1, -1, -1, -1] and [sq(m) for m in (3, 5, 9)] == [1, 1, 1] and [sq(m) for m in (12, 10, 6, 15)] == [-1, -1, -1, -1]
    and sorted(m for m in range(16) if bin(m).count('1') % 2 == 0) == [0, 3, 5, 6, 9, 10, 12, 15] and sorted({tuple(sorted((m, m ^ 9))) for m in (0, 3, 5, 6, 9, 10, 12, 15)}) == [(0, 9), (3, 10), (5, 12), (6, 15)]
    and FG.POS_KERNEL == (0, 6, 10, 12) and FG.NEG_KERNEL == (3, 5, 9, 15) and all(s in plain for s in ('the labels 0, 6, 10, 12', 'the labels 3, 5, 9, 15', '0 ↔ 9, 3 ↔ 10, 5 ↔ 12, 6 ↔ 15')))

# ---- a fresh run, the copied scripts, the cross-references
def norm(t): return re.sub(r'[0-9.]+e[-+][0-9]+|\b\d+\.\d+\b', '<n>', t)
env = dict(os.environ)
fresh = subprocess.run([sys.executable, 'hest_check.py'], capture_output=True, text=True, env=env).stdout
chk('T15 a fresh run of hest_check.py gives the log (the numbers that carry a residual are compared after normalisation)', norm(fresh) == norm(LOG), 'differs')
rawlog = open(os.path.join('logs', 'gtg_check_SG.log'), encoding='utf-8').read()
fresh2 = subprocess.run([sys.executable, 'gtg_check.py', 'S', 'G'], capture_output=True, text=True, env=env).stdout
chk('T16 a fresh run of gtg_check.py S G gives the raw log it was copied from (after normalisation of residuals and timings)', norm(re.sub(r'\[\s*[\d.]+s\]', '', fresh2)) == norm(re.sub(r'\[\s*[\d.]+s\]', '', rawlog)) and 'FAIL' not in fresh2)
orig = os.path.join(PKG, 'selfcheck', 'steps15_17')
if os.path.isdir(orig):
    chk('T17 gtg_check.py and bitcliff.py are byte-identical to the atlas\'s copies in selfcheck/steps15_17', all(filecmp.cmp(os.path.join(HERE, f), os.path.join(orig, f), shallow=False) for f in ('gtg_check.py', 'bitcliff.py')))
    chk('T18 the sabotage script of the atlas that covers gtg_check.py exists', os.path.exists(os.path.join(orig, 'run_mutations.py')) and 'gtg_check' in open(os.path.join(orig, 'run_mutations.py'), encoding='utf-8').read())
    def rd(*p):
        f = os.path.join(PKG, *p); return open(f, encoding='utf-8').read() if os.path.exists(f) else ''
    cat = rd('selfcheck', 'reports', 'cat_check.py') or open(os.path.join(HERE, '..', 'category', 'cat_check.py'), encoding='utf-8').read()
    HAVE_RC = os.path.isdir(os.path.join(PKG, 'researchers_checks'))
    chk('T19 the cross-references named on the page exist: cat_check.py K4a, K4c, M2; null_selfcheck.py S5.7; groups_check.py with its part A; researchers_checks/check_T16.py (when that folder is in the package)', all(f"'{k}'" in cat for k in ('K4a', 'K4c', 'M2'))
        and '"S5.7"' in rd('selfcheck', 'null_selfcheck.py') and 'def part_A' in rd('selfcheck', 'steps15_17', 'groups_check.py') and (not HAVE_RC or os.path.exists(os.path.join(PKG, 'researchers_checks', 'check_T16.py')))
        and all(s in plain for s in ('cat_check.py K4a–c', 'cat_check.py M2', 'null_selfcheck.py S5.7', 'groups_check.py part A', 'check_T16.py')))
    if not HAVE_RC: print('skip T19, the part on researchers_checks/check_T16.py: researchers_checks/ not found (set ATLAS_PKG); the other cross-references are checked')
else:
    print('skip T17-T19: the atlas package is not beside this folder (set ATLAS_PKG)')
chk('T20 the files of this folder: the five scripts, their logs, the builder, the content, the figures', all(os.path.exists(f) for f in ('hest_indep.py', 'ldg_indep.py', 'ldg_action.py', 'stalg.py', 'hest_check.py', 'mutate_hestenes.py', 'build_report_hestenes.py', 'content_hestenes.py',
    'figs_hestenes.py', 'gtg_check.py', 'bitcliff.py', 'README_hestenes.md', 'logs/hest_check.log', 'logs/mutate_hestenes.log', 'logs/gtg_check_SG.log')))

# ---- the page itself
def external(t):
    return (re.search(r'(src|href)="https?://(?!arxiv\.org)', t) or 'url(http' in t or '@import' in t or re.search(r'<script[^>]+src=', t) or re.search(r'<link[^>]+href', t))
chk('T21 no external request (links to arxiv.org only), the script is inline', not external(page) and '<script>' in page)
chk('T22 no e-mail address, no mail link, no personal address anywhere in the page or in the folder\'s text files', not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', page, flags=re.S)) and ('mail' + 'to:') not in page
    and not any(re.search(r'[\w.+-]+@[\w-]+\.[a-z]{2,}', open(os.path.join(HERE, f), encoding='utf-8').read()) for f in os.listdir(HERE) if f.endswith(('.py', '.md', '.css', '.js'))))
chk('T23 themes and guards present; the page has a head with the title and one date of issue', 'prefers-color-scheme: dark' in page and ':root[data-theme="dark"]' in page and ':root:not([data-theme="light"])' in page
    and re.search(r'<title>([^<]+)</title>', page).group(1) == C.TITLE and page.count('7 October 2026') >= 2 and not re.search(r'\b\d{1,2} (January|February|March|April|May|June|July|August|September|November|December) 2026', plain.replace('7 October 2026', '')))
chk('T24 size is reasonable (< 400 kB)', len(page.encode('utf-8')) < 400_000, str(len(page)))
chk('T25 no history in the visible text of the page (shared pattern list, reports/no_history.py), no corrections section, no struck sentence; every "<" in a text node is written &lt;, so the reader sees all the text', not NH.scan_page(page) and not NH.bare_lt(page) and not re.search(r'\bE-\d{3}\b', plain), str(NH.scan_page(page)[:3]))
chk('T26 the history scan catches its planted phrases', not NH.selftest(), str(NH.selftest()))
chk('T27 nothing addressed to a person: no letter wording, no "you", no name of a person as addressee', not re.search(r'\b(dear|sincerely|yours|your|you|please)\b', plain, re.I), str(re.findall(r'\b(?:dear|sincerely|yours|your|you|please)\b', plain, re.I)[:3]))
_pl = plain.replace('steps 1, 12 and 17', '')                # "steps 1, 12 and 17" are the steps the unused parts of gtg_check.py belong to
steps = set(re.findall(r'[Ss]tep (\d+)', _pl)) | set(re.findall(r'[Ss]teps (\d+)', _pl))
chk('T28 step references are in the current numbering (4 Dirac, 5 spinors, 13 null surfaces, 12 gauge gravity); Calibration 1 (Maxwell); no "Test 1"', steps <= {'4', '5', '12', '13'} and 'Calibration 1' in plain and 'Test 1' not in plain and not (steps & {'2', '11', '14', '16'}), str(steps))
FORBIDDEN = ['the horizon is the label 0', 'the horizon is the 0 label', 'horizon is label 0', 'horizon = label 0', 'the horizon is the null generator', 'derived from nature', 'is derived', 'we derive', 'a wall', 'proves that nature',
             'the universe is', 'reality is', 'explains why nature', 'chiral coupling is derived', 'the coupling constant is derived', 'matter and antimatter are', 'particles are']
outside = (plain + ' ' + tips).replace('does not say that the horizon is the label 0', '')      # the one negated sentence is the right wording, see T30
chk('T29 the forbidden sentences are nowhere on the page (text and tooltips)', not any(w in outside for w in FORBIDDEN), str([w for w in FORBIDDEN if w in outside]))
RIGHT = ['The page does not say that the horizon is the label 0', 'Nothing here is a result about nature', 'naming the cell “Minkowski” is a reading (ours)', 'the sign of the energy belongs to the point p',
         'The chiral coupling is not drawn', 'the coupling constant is not derived', 'The page does not solve the field equations', 'a null vector with a partner', 'is not the atlas\'s label 0',
         'Calling the negative-energy kernel antiparticles is the physics page\'s reading', 'a coincidence of thresholds, not as an explanation', 'independent here means separate code, not separate authorship']
chk('T30 the right wording is on the page', all(t in plain for t in RIGHT), str([t for t in RIGHT if t not in plain]))
chk('T31 the five tags are explained at the head (a legend of chips, words and meanings), input among them', all(t in SK.kinds(page.split('<nav')[0]) for t in ('standard', 'checked', 'ours', 'open', 'input')) and 'a choice or datum the physics page needs that the algebra does not supply' in plain)
chk('T32 every input of the page is tagged input in a finding, and the findings that name an input say what the algebra does supply', 'input' in SK.kinds(page) and sum(1 for f in fin.values() if 'input' in f[0]) >= 5, str(sum(1 for f in fin.values() if 'input' in f[0])))
chk('T33 limits and open items are stated: field equations not decoded, flat-space Dirac, no chiral coupling, no coupling constant', all(s in plain for s in ('The field equations of gauge-theory gravity', 'The Dirac equation in a gravitational field', 'The chiral coupling and the coupling constants', 'Dead ends and honest limits')))
chk('T34 tooltips on the figures: 16 label boxes, 4 links, 3 points, 6 bars', page.count('data-tip="') == 29, str(page.count('data-tip="')))
chk('T35 the figures are drawn from the engine: 16 label boxes (4 + 4 + 8), 4 chirality links, 3 sample points, 6 bars (2 + 4)', len(re.findall(r'<g class="hs-(?:pos|neg|odd)"', page)) == 16 and page.count('class="hs-pos"') == 4 and page.count('class="hs-neg"') == 4
    and page.count('class="hs-odd"') == 8 and page.count('class="hs-link"') == 4 and page.count('class="hs-dot"') == 3 and page.count('hs-bar-neg') >= 2 and len(re.findall(r'class="hs-bar-(?:neg|pos)"', page)) == 6)
chk('T36 the Hestenes page does not mention any other report by version or file name', not re.search(r'_report\.html|\.zip|MANIFEST', plain))

# ---- the status chips, the sabotage coverage, the docstring of the runner
chk('T37 every status is an icon chip (role img, name and hover text start with the word, the drawing of the atlas badge, no word chip, one legend entry per flag); all five flags are used',
    not SK.problems(page) and set(SK.kinds(page)) == set(SK.FLAGS), str(SK.problems(page)[:3]))
_rx = re.compile(r",\s*'([A-Z]\d+[a-z]?)'\)\s*,?\s*(?:#.*)?$")
_named = {m.group(1) for m in (_rx.search(l.rstrip('\n')) for l in open('mutate_hestenes.py', encoding='utf-8')) if m}
_indep = [i for i in IDS if i[0] in 'HLA']
_mc = re.search(r'Checks of these four scripts with at least one sabotage: (\d+) of (\d+)', plain)
chk('T38 the sabotage card says how many of the checks of the four independent scripts (H, L, A: 42) have at least one sabotage: 23 of 42, as the target ids of the mutants of mutate_hestenes.py give',
    len(_indep) == 42 and _named <= set(_indep) and bool(_mc) and (int(_mc.group(1)), int(_mc.group(2))) == (len(_named), len(_indep)) == (23, 42), str(_mc.groups() if _mc else None))
_doc = open('hest_check.py', encoding='utf-8').read().split('"""')[1]
chk('T39 the docstring of hest_check.py names the id ranges of the log: H1-H30, L1-L10, A1-A2, and S, G', all(f'{b}1-{b}{max(int(i[1:]) for i in IDS if i[0] == b and i[1:].isdigit())}' in _doc for b in 'HLA') and 'H1-H30' in _doc and 'S, G' in _doc)

# ---- browser behaviour (needs playwright with Chromium)
NOBROWSER = bool(os.environ.get('REPORT_NO_BROWSER'))
NB = 10
if NOBROWSER:
    print('skip the %d browser tests: REPORT_NO_BROWSER is set' % NB)
else:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1100, 'height': 900})
        errs = []; reqs = []
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.on('request', lambda r: reqs.append(r.url) if not r.url.startswith(('file:', 'data:')) else None)
        pg.goto('file://' + os.path.abspath(PAGE)); pg.wait_for_timeout(200)
        chk('B1 no page errors, no network requests', not errs and not reqs, str((errs[:2], reqs[:2])))
        chk('B2 Fig. 1: 16 label boxes, 4 links; Fig. 2: 6 bars; Fig. 3: 3 points; Fig. 4: 3 curves (2 pieces of the divergent one + 1)', pg.locator('#f1 svg g.hs-pos, #f1 svg g.hs-neg, #f1 svg g.hs-odd').count() == 16 and pg.locator('#f1 g.hs-link').count() == 4
            and pg.locator('#f10 svg rect.hs-bar-neg, #f10 svg rect.hs-bar-pos').count() == 6 and pg.locator('#f11 circle.hs-dot').count() == 3 and pg.locator('#f11 polyline.hs-curve2').count() == 2 and pg.locator('#f11 polyline.hs-curve').count() == 2)
        box = pg.locator('#f1 g.hs-pos').first; box.scroll_into_view_if_needed(); pg.wait_for_timeout(250); box.hover(); pg.wait_for_timeout(150)
        chk('B3 tooltip on a label box (hover) names its label and the kernel', pg.locator('#tip.on').count() == 1 and 'label 0' in pg.inner_text('#tip') and 'kernel' in pg.inner_text('#tip'))
        dot = pg.locator('#f11 circle.hs-dot').first; dot.scroll_into_view_if_needed(); pg.wait_for_timeout(250); dot.focus(); pg.wait_for_timeout(150)
        chk('B4 tooltip on a sample point (focus) names its check', pg.locator('#tip.on').count() == 1 and 'check G2' in pg.inner_text('#tip'))
        bar = pg.locator('#f10 rect.hs-bar-neg').first; bar.scroll_into_view_if_needed(); pg.wait_for_timeout(250); bar.focus(); pg.wait_for_timeout(150)
        chk('B5 tooltip on a bar gives the eigenvalue', pg.locator('#tip.on').count() == 1 and 'curvature eigenvalue' in pg.inner_text('#tip'))
        pg.click('#themebtn'); chk('B6 theme button: light', pg.get_attribute('html', 'data-theme') == 'light')
        pg.click('#themebtn'); chk('B7 theme button: dark', pg.get_attribute('html', 'data-theme') == 'dark')
        chk('B8 no horizontal overflow at 1100', pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth') <= 0)
        pg.set_viewport_size({'width': 375, 'height': 800}); pg.wait_for_timeout(150)
        chk('B9 no horizontal overflow at 375', pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth') <= 0, str(pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth')))
        wide = pg.evaluate('''() => [...document.querySelectorAll('.finding, .card, .notice, .kpi, section > p')].filter(e => e.scrollWidth > e.clientWidth + 2 && getComputedStyle(e).overflowX === 'visible').map(e => e.id || e.className).slice(0, 5)''')
        chk('B10 no card overflows its box at 375', not wide, str(wide))
        b.close()
print('\ntest_report_hestenes: %d ok, %d failed' % (ok, bad) + (', %d browser tests skipped' % NB if NOBROWSER else '')); sys.exit(1 if bad else 0)
