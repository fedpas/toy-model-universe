#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Builds ../html/hestenes_ldg_report.html: one self-contained page (inline CSS, SVG and a little JS, no external request).
Every number in it is read from logs/hest_check.log (the checks) and logs/mutate_hestenes.log (the sabotage run), or computed here from the bit rule (bitcliff, Alg((1,-1,-1,-1)))
and from the closed formulas the checks test; none is typed by hand except the text of content_hestenes.py, which test_report_hestenes.py pins against the log.
Run: python3 hest_check.py > logs/hest_check.log ; python3 mutate_hestenes.py > logs/mutate_hestenes.log ; python3 build_report_hestenes.py"""
import os, sys, re, html
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from bitcliff import Alg
import content_hestenes as C
import figs_hestenes as FG
import status_chips as SC

E = html.escape
TODAY = '7 October 2026'

# ------------------------------------------------------------------ the checks (from the log) and the sabotage run
def read_log(name):
    ids, texts, bad = [], {}, 0
    for line in open(os.path.join(HERE, 'logs', name), encoding='utf-8'):
        m = re.match(r'(ok  |FAIL) (\S+?): (.*)', line)
        if m:
            if m.group(1).startswith('ok'): ids.append(m.group(2)); texts[m.group(2)] = m.group(3)
            else: bad += 1
    return ids, texts, bad
IDS, TEXTS, BAD = read_log('hest_check.log')
assert BAD == 0, 'a check fails: fix it before building the report'
OK = len(IDS)
_m = re.search(r'mutants caught: (\d+) of (\d+)', open(os.path.join(HERE, 'logs', 'mutate_hestenes.log'), encoding='utf-8').read())
MUT_OK, MUT_ALL = int(_m.group(1)), int(_m.group(2))
assert MUT_OK == MUT_ALL, 'a sabotage was missed'
_rx = re.compile(r",\s*'([A-Z]\d+[a-z]?)'\)\s*,?\s*(?:#.*)?$")                 # the id of the check that a mutant must make fail ends its line
_named = {m.group(1) for m in (_rx.search(l.rstrip('\n')) for l in open(os.path.join(HERE, 'mutate_hestenes.py'), encoding='utf-8')) if m}
INDEP = [i for i in IDS if i[0] in 'HLA']                  # the checks of the four independent scripts (S and G are gtg_check.py, sabotaged by the atlas's own script)
MUT_NAMED = len(_named & set(INDEP)); assert _named <= set(INDEP), sorted(_named - set(INDEP))
BLOCKS = [(b[0], b[1], sum(1 for i in IDS if i.startswith(b[0])), b[2]) for b in C.CHECK_BLOCKS]
assert sum(b[2] for b in BLOCKS) == OK, (sum(b[2] for b in BLOCKS), OK)

# ------------------------------------------------------------------ the labels the text names, computed in the atlas engine
A = Alg((1, -1, -1, -1))                      # bit 0 = gamma_0 (+1), bits 1..3 = gamma_k (-1)
def lab(*bits): return sum(1 << b for b in bits)
assert [A.sq(m) for m in (1, 2, 4, 8)] == [1, -1, -1, -1]
sigma = {k: A.mul({1 << k: 1}, {1: 1}) for k in (1, 2, 3)}             # sigma_k = gamma_k gamma_0
assert [list(sigma[k]) for k in (1, 2, 3)] == [[3], [5], [9]] and all(A.mul(sigma[k], sigma[k]) == {0: 1} for k in (1, 2, 3))
I_ = {15: 1}
assert A.mul(I_, I_) == {0: -1} and A.mul(A.mul(sigma[1], sigma[2]), sigma[3]) == I_
Isig = {k: A.mul(I_, sigma[k]) for k in (1, 2, 3)}
assert [list(Isig[k]) for k in (1, 2, 3)] == [[12], [10], [6]] and all(A.mul(Isig[k], Isig[k]) == {0: -1} for k in (1, 2, 3))
Jm = A.mul({4: 1}, {2: 1})                                              # J = gamma_2 gamma_1
assert Jm == Isig[3] and A.mul(Jm, Jm) == {0: -1} and list(Jm) == [6]
assert A.mul(Jm, {1: 1}) == A.mul({1: 1}, Jm)                           # J commutes with gamma_0
EVEN = [m for m in range(16) if bin(m).count('1') % 2 == 0]
assert EVEN == [0, 3, 5, 6, 9, 10, 12, 15]
assert sorted(set(FG.POS_KERNEL) | set(FG.NEG_KERNEL)) == EVEN and not set(FG.POS_KERNEL) & set(FG.NEG_KERNEL)
assert {m ^ FG.CHIRAL for m in EVEN} == set(EVEN) and sorted({tuple(sorted((m, m ^ 9))) for m in EVEN}) == [(0, 9), (3, 10), (5, 12), (6, 15)]
assert FG.CHIRAL == 15 ^ 6 == lab(0, 3)
# the electric / magnetic split of the bivector labels by their commutation with gamma_0
elec = [m for m in (3, 5, 6, 9, 10, 12) if A.mul({m: 1}, {1: 1}) == {k: -v for k, v in A.mul({1: 1}, {m: 1}).items()}]
assert elec == [3, 5, 9]
# the cells: the other signature and the numbers of the trio
assert [A.sq(m) for m in (3, 5, 9)] == [1, 1, 1] and [A.sq(m) for m in (6, 10, 12)] == [-1, -1, -1] and A.sq(15) == -1
# facts that figures and text use, tied to the log
def logtext(i): return TEXTS[i]
assert '134 with beta = 0 or pi, 66 generic' in logtext('H25') and '|det T| = 256' in logtext('A2') and 'Kretschmann scalar 48 M^2/r^6' in logtext('L1')
assert '(-2, -2, 1, 1, 1, 1) M/r^3' in logtext('L6') and '(-2, -2, -2, -2, 4, 4)' in logtext('L7')
assert '-16/25' in logtext('G2a') and 'NULL' in logtext('G2b') and '16/9' in logtext('G2c')
assert 'n=4: 20 = 10 + 10' in logtext('G6a') and 'n=5: 50 = 15 + 35' in logtext('G6a')
rows = FG.counts_table()
assert rows[0] == (3, 6, 6, 0) and rows[1] == (4, 20, 10, 10) and rows[2] == (5, 50, 15, 35)

# ------------------------------------------------------------------ the page pieces
def chip(kind): return SC.chip(kind)      # a status is an icon chip: the word is its aria-label and title, never visible

def wrap_sv(h):                                           # a drawing scrolls sideways on a phone instead of shrinking its text to nothing
    return re.sub(r'(<svg [^>]*class="chart[^"]*"[^>]*>.*?</svg>)', r'<div class="sv">\1</div>', h, flags=re.S)

def fig(title, body, cap=''):
    return f'<figure class="fig"><div class="figtitle">{title}</div>{wrap_sv(body)}' + (f'<figcaption>{cap}</figcaption>' if cap else '') + '</figure>'

FIGS = {
 'LABELS': fig('Fig. 1 · The sixteen labels of Cl(1,3)', FG.label_figure(A),
               'Hover or focus a box for its label, grade, square and, for the even labels, the sign of the chirality map. The dashed lines join the labels that ψ ↦ IψJ exchanges: XOR with 9, up to sign.'),
 'WEYL': fig('Fig. 2 · The curvature operator of the point mass', FG.weyl_figure(A),
             'Eigenvalues in units of M/r³ of −(M/2r³)(B + 3σ<sub>r</sub>Bσ<sub>r</sub>) on the six bivector labels, with σ<sub>r</sub> = σ3 (label 9). The radial pair is the labels 9 and 6.'),
 'HORIZON': ('<div class="figcols"><div>' + fig('Fig. 3 · The square of the radial gradient', FG.horizon_figure(),
             'h̄(e<sub>r</sub>)² = g² − 1 = 2M/r − 1 against r/M: positive inside the horizon (timelike), zero on it (null), negative outside (spacelike). The marked points are g = 5/3, 1 and 3/5 of checks G2c, G2b and G2a.')
             + '</div><div>' + fig('Fig. 4 · Two time shifts', FG.shift_figure(),
             'The integrands φ′ of the shifts from Painlevé–Gullstrand time. The one to Schwarzschild time diverges at r = 2M; the one to Kerr–Schild time is finite across it (G7c, G7d).') + '</div></div>'),
}
counts_tab = ('<div class="tvscroll" style="max-height:none"><table><caption class="sr">Riemann, Ricci and Weyl component counts by dimension</caption><thead><tr><th class="num">n</th><th class="num">Riemann</th><th class="num">Ricci</th><th class="num">Weyl</th></tr></thead><tbody>'
              + ''.join(f'<tr><td class="num">{n}</td><td class="num">{r}</td><td class="num">{ri}</td><td class="num">{w}</td></tr>' for n, r, ri, w in rows) + '</tbody></table></div>')

def finding(fid, title, chips, left, right, ids):
    wide = '%%FIG_LABELS%%' in right or '%%FIG_HORIZON%%' in right
    cls = 'fbody one' if wide else 'fbody'
    ch = ''.join(chip(c) for c in chips)
    for k, v in FIGS.items(): right = right.replace(f'%%FIG_{k}%%', v)
    left = left.replace('%%TAB_COUNTS%%', counts_tab)
    assert '%%' not in left + right, fid
    return (f'<article class="finding" id="{fid.lower()}"><div class="fhead"><span class="fid">{fid}</span><h3>{title}</h3><div class="chips">{ch}</div></div>'
            f'<div class="{cls}"><div>{left}</div><div>{right}<p class="ids">checks {ids}.</p></div></div></article>')

FINDINGS = ''.join(finding(*f) for f in C.FINDINGS)

def tagspan(t): return ' '.join(SC.chip(w) for w in re.split(r' · ', t))
DICT_ROWS = ''.join(f'<tr><td>{o}</td><td>{b}</td><td>{tagspan(t)}</td><td class="ids">{c}</td></tr>' for o, b, t, c in C.DICT)
INPUT_ROWS = ''.join(f'<tr><td><b>{i}</b></td><td>{w}</td><td>{s}</td><td class="ids">{c}</td></tr>' for i, w, s, c in C.INPUTS)
CHECKS_TABLE = ''.join(f'<tr><td><b>{E(b[0])}</b></td><td>{E(b[1])}</td><td class="num">{b[2]}</td><td><code>{E(b[3])}</code></td></tr>' for b in BLOCKS)
LIM1 = ''.join(f'<li>{x}</li>' for x in C.LIMITS_REACH); LIM2 = ''.join(f'<li>{x}</li>' for x in C.LIMITS_DONE)
SRC = ''.join(f'<li>{x}</li>' for x in C.SOURCES)
CHIPS = SC.legend(['standard', 'checked', 'ours', 'open', 'input'], {'standard': "textbook or the source's own statement, used as is", 'input': 'a choice or datum the physics page needs that the algebra does not supply'})

CSS = open(os.path.join(HERE, 'report_style.css'), encoding='utf-8').read() + SC.CSS
CSS += '''
/* the Hestenes report */
.sr{position:absolute;left:-9999px}
svg.hs .hs-pos rect{fill:var(--e);stroke:var(--e)}svg.hs .hs-pos text{fill:var(--e-ink)}
svg.hs .hs-neg rect{fill:var(--ours);stroke:var(--ours)}svg.hs .hs-neg text{fill:#0b0b0b}
svg.hs .hs-odd rect{fill:var(--tint);stroke:var(--line2)}svg.hs .hs-odd text{fill:var(--ink)}
svg.hs .hs-n{font:700 15px system-ui,sans-serif}svg.hs .hs-s{font:11.5px system-ui,sans-serif}
svg.hs g[data-tip]:hover rect,svg.hs g[tabindex]:focus rect{stroke:var(--ink);stroke-width:2}
svg.hs .hs-link line{stroke:var(--ink2);stroke-width:1.6;stroke-dasharray:5 3}svg.hs .hs-x{fill:var(--ink2);font:11px system-ui,sans-serif}
svg.hs .hs-link:hover line,svg.hs .hs-link:focus line{stroke:var(--ink);stroke-width:2.6}
.sw.hs-swpos{background:var(--e);color:var(--e-ink)}.sw.hs-swneg{background:var(--ours);color:#0b0b0b}.sw.hs-swodd{background:var(--tint);border:1px solid var(--line2);color:var(--ink)}
svg.hs .hs-zin{fill:var(--tint)}svg.hs .hs-zout{fill:var(--surf)}
svg.hs .hs-ax{stroke:var(--line2);stroke-width:1}svg.hs .hs-hz{stroke:var(--open);stroke-width:1.5;stroke-dasharray:4 3}
svg.hs .hs-curve{fill:none;stroke:var(--acc);stroke-width:2.4}svg.hs .hs-curve2{fill:none;stroke:var(--ours);stroke-width:2.4}
svg.hs .hs-dot{fill:var(--surf);stroke:var(--ink);stroke-width:2}svg.hs .hs-dot:hover,svg.hs .hs-dot:focus{stroke-width:3.5}
svg.hs .hs-bar-neg{fill:var(--ours)}svg.hs .hs-bar-pos{fill:var(--e)}
svg.hs rect[data-tip]:hover,svg.hs rect[tabindex]:focus{stroke:var(--ink);stroke-width:1.5}
'''
JS = open(os.path.join(HERE, 'report_script.js'), encoding='utf-8').read()

TEMPLATE = r'''<!doctype html>
<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 -->
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%%TITLE%%</title>
<meta name="description" content="Hestenes' space-time algebra and the gauge-theory gravity of Lasenby, Doran and Gull read in the bit rule: computed statements, readings, the inputs the algebra does not supply, and the checks.">
<style>%%CSS%%</style>
</head>
<body>
<header class="hero"><div class="wrap">
 <span class="kick">Hestenes · LDG lens · %%TODAY%%</span>
 <h1>%%H1%%</h1>
 <p class="sub">%%SUB%%</p>
 <div class="notice">%%NOTICE%%</div>
 <div class="kpis">
  <div class="kpi"><b>%%NOK%%</b><span>checks pass, %%NBAD%% fail</span></div>
  <div class="kpi"><b>%%MUTOK%% of %%MUTALL%%</b><span>deliberate sabotages of the independent scripts were caught (automated)</span></div>
  <div class="kpi"><b>%%NFIND%%</b><span>findings, each with its tags and check ids</span></div>
  <div class="kpi"><b>%%NINP%%</b><span>inputs the physics page needs that the algebra does not supply</span></div>
 </div>
 <p class="lead"><b>In one paragraph.</b> %%LEAD%%</p>
 <p style="font-size:13.5px;color:var(--muted)">%%CHIPS%%</p>
</div></header>

<nav class="toc"><div class="wrap">
 <a href="#how">What is done</a><a href="#findings">Findings</a><a href="#dict">Dictionary</a><a href="#inputs">Inputs</a><a href="#limits">Limits</a><a href="#checks">Checks</a><a href="#src">Sources</a>
 <button id="themebtn" type="button" aria-label="Switch colour theme">theme: auto</button>
</div></nav>

<main class="wrap">

<section id="how"><h2>What is done <small>one object at a time, twice</small></h2>
 <div class="grid3">
  <div class="card"><h3>1 · The objects</h3><p>The Dirac, Maxwell, spinor, null-surface and gauge-gravity objects of the atlas's steps 4, 5, 12, 13 and Calibration 1, written as labels of the algebra Cl(1,3): which label, which square, which product (the Dictionary).</p></div>
  <div class="card"><h3>2 · Two implementations</h3><p><code>gtg_check.py</code> runs in the atlas's own engine; <code>stalg.py</code> is a second implementation of the algebra, written for this report, with its own checks of the Dirac map, the chirality, pointors, Maxwell, the vacuum tests and the action. One wrapper, <code>hest_check.py</code>, runs all four and prints one log of %%NOK%% lines.</p></div>
  <div class="card"><h3>3 · The inputs, named</h3><p>Where the physics page needs a choice that the algebra does not make (the time direction, the chart, the grade of a field, the complex structure, the equations, the shear), the finding says so and the section Inputs lists it with the check that shows what depends on it.</p></div>
 </div>
</section>

<section id="findings"><h2>Findings <small>each with its tags and check ids</small></h2>
%%FINDINGS%%
</section>

<section id="dict"><h2>Dictionary <small>the objects as labels</small></h2>
 <p class="lead">Each row is an object of Hestenes or LDG, what it is in the bit rule, its tags and the checks that compute it.</p>
 <div class="tvscroll" style="max-height:none"><table><thead><tr><th>Object</th><th>In the bit rule</th><th>Tags</th><th>Checks</th></tr></thead><tbody>%%DICT%%</tbody></table></div>
</section>

<section id="inputs"><h2>Inputs <small>what the algebra does not supply</small></h2>
 <p class="lead">An input is a choice or a datum the physics page needs that the algebra does not supply. Each is tagged input in the findings above.</p>
 <div class="tvscroll" style="max-height:none"><table><thead><tr><th>Id</th><th>The physics page needs</th><th>What the algebra does supply</th><th>Checks</th></tr></thead><tbody>%%INPUTS%%</tbody></table></div>
</section>

<section id="limits"><h2>Dead ends and honest limits</h2>
 <div class="grid2">
  <div class="card"><h3>What the algebra does not reach</h3><ul class="tight">%%LIM1%%</ul></div>
  <div class="card"><h3>What was not done or verified</h3><ul class="tight">%%LIM2%%</ul></div>
 </div>
</section>

<section id="checks"><h2>Checks <small>%%NOK%% pass, %%NBAD%% fail</small></h2>
 <div class="grid2">
  <div class="card"><div style="overflow-x:auto"><table><thead><tr><th>Block</th><th>What it tests</th><th class="num">Checks</th><th>Script</th></tr></thead><tbody>%%CHECKS%%<tr><td></td><td><b>Total</b></td><td class="num"><b>%%NOK%%</b></td><td></td></tr></tbody></table></div></div>
  <div class="card"><h3>Sabotage test</h3><p>Each of %%MUTALL%% deliberate changes (a flipped sign, a wrong exponent, a wrong signature, a wrong label, a wrong constant) is made in a temporary copy of one of the four independent scripts and must make the named check fail: <b>%%MUTOK%% of %%MUTALL%% are caught</b>. A crash does not count as caught. Checks of these four scripts with at least one sabotage: <b>%%MUTNAMED%% of %%NINDEP%%</b>; the others have none. <code>gtg_check.py</code> is a copy of the atlas's script, byte for byte, and is sabotaged by the atlas's own <code>selfcheck/steps15_17/run_mutations.py</code>.</p>
   <h3 style="margin-top:12px">Rerun</h3><pre>cd reports/hestenes
python3 hest_check.py &gt; logs/hest_check.log        # the %%NOK%% checks, about 20 seconds
python3 mutate_hestenes.py &gt; logs/mutate_hestenes.log   # automated sabotage, about 2 minutes
python3 build_report_hestenes.py   # this page, into ../html/
python3 test_report_hestenes.py</pre><p style="font-size:13px;color:var(--muted)">Needs Python 3, numpy and scipy. The atlas package this folder ships in is only needed for the cross-references in the tests (two folders up, or set <code>ATLAS_PKG</code>).</p>
  </div>
 </div>
</section>

<section id="src"><h2>Sources</h2>
 <ul class="tight">%%SRC%%</ul>
</section>
</main>
<footer><div class="wrap">Cascade Atlas · preliminary report, %%TODAY%% · generated by <code>build_report_hestenes.py</code> from the logs and the algebra engine. Not a theory of nature: a set of checks and readings.</div></footer>
<div id="tip" role="tooltip"></div>
<script>%%JS%%</script>
</body></html>
'''
out = TEMPLATE
rep = {'%%CSS%%': CSS, '%%JS%%': JS, '%%TODAY%%': TODAY, '%%TITLE%%': E(C.TITLE), '%%H1%%': C.H1, '%%SUB%%': C.SUB, '%%NOTICE%%': C.NOTICE, '%%LEAD%%': C.LEAD, '%%CHIPS%%': CHIPS,
       '%%NOK%%': str(OK), '%%NBAD%%': str(BAD), '%%MUTOK%%': str(MUT_OK), '%%MUTNAMED%%': str(MUT_NAMED), '%%NINDEP%%': str(len(INDEP)), '%%MUTALL%%': str(MUT_ALL), '%%NFIND%%': str(len(C.FINDINGS)), '%%NINP%%': str(len(C.INPUTS)),
       '%%FINDINGS%%': FINDINGS, '%%DICT%%': DICT_ROWS, '%%INPUTS%%': INPUT_ROWS, '%%LIM1%%': LIM1, '%%LIM2%%': LIM2, '%%CHECKS%%': CHECKS_TABLE, '%%SRC%%': SRC}
for k, v in rep.items(): out = out.replace(k, v)
assert out.count('<body>') == 1; out = out.replace('<body>', '<body>\n' + SC.SPRITE, 1)      # the five icons, once
assert '%%' not in out, re.findall(r'%%\w+%%', out)
assert not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', out, flags=re.S)), 'an e-mail address is in the page'
path = os.path.join(HERE, '..', 'html', 'hestenes_ldg_report.html'); os.makedirs(os.path.dirname(path), exist_ok=True)   # the shipped page lives in reports/html/
open(path, 'w', encoding='utf-8').write(out)
print('wrote', path, len(out), 'bytes;', f'checks {OK}, sabotage {MUT_OK} of {MUT_ALL}, findings {len(C.FINDINGS)}, inputs {len(C.INPUTS)}')
