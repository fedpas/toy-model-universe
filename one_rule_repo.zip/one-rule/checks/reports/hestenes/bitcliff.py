#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Shared engine for the chapter scripts: the bit rule  e_a e_b = s(a,b) e_{a xor b}  and small exact helpers.
Python standard library + numpy only (numpy is used only where a script says so).

Generator i (bit i of a mask) squares to eps[i] in {+1,-1,0}.  Cl(p,q) = eps with p entries +1 followed by q entries -1.
   s(a,b) = (-1)^{#{(i in a, j in b, j < i)}} * prod_{i in a&b} eps[i]
A multivector is a dict {mask: Fraction-or-int coefficient}."""
from fractions import Fraction
from itertools import combinations
import random

def pc(x):
    return bin(x).count('1')

def reorder_sign(a, b):
    """sign from moving every generator of b to its place past the larger generators of a"""
    a >>= 1
    s = 0
    while a:
        s += pc(a & b)
        a >>= 1
    return -1 if s & 1 else 1

def sig(p, q, r=0):
    return tuple([1] * p + [-1] * q + [0] * r)

class Alg:
    def __init__(self, eps):
        self.eps = tuple(eps)
        self.n = len(self.eps)
        self.N = 1 << self.n
        self._sq = {}
    def blade_mul(self, a, b):
        c = reorder_sign(a, b)
        m = a & b
        i = 0
        while m:
            if m & 1:
                c *= self.eps[i]
                if c == 0:
                    return 0, a ^ b
            m >>= 1
            i += 1
        return c, a ^ b
    def sq(self, a):
        """e_a * e_a as a scalar"""
        if a not in self._sq:
            self._sq[a] = self.blade_mul(a, a)[0]
        return self._sq[a]
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                s, c = self.blade_mul(a, b)
                if s:
                    out[c] = out.get(c, 0) + s * ca * cb
        return {k: v for k, v in out.items() if v != 0}
    def add(self, x, y, cy=1):
        out = dict(x)
        for k, v in y.items():
            out[k] = out.get(k, 0) + cy * v
        return {k: v for k, v in out.items() if v != 0}
    def scal(self, x, c):
        return {k: c * v for k, v in x.items() if c * v != 0}
    def comm_sign(self, a, b):
        """+1 if e_a e_b = e_b e_a, -1 if they anticommute  (a, b nonzero blades, eps all nonzero)"""
        return (-1) ** ((pc(a) * pc(b) - pc(a & b)) & 1)
    def center_blades(self):
        return [a for a in range(self.N) if all(self.comm_sign(a, 1 << i) == 1 for i in range(self.n))]
    def counts(self):
        """(N_plus, N_minus, N_zero): number of blades (identity included) whose square is +1, -1, 0"""
        c = {1: 0, -1: 0, 0: 0}
        for a in range(self.N):
            c[self.sq(a)] += 1
        return c[1], c[-1], c[0]

def rand_mv(alg, grades=None, rng=random, lo=-3, hi=3):
    out = {}
    for a in range(alg.N):
        if grades is None or pc(a) in grades:
            v = rng.randint(lo, hi)
            if v:
                out[a] = v
    return out

def associativity_check(alg, trials=40, seed=1):
    rng = random.Random(seed)
    for _ in range(trials):
        x, y, z = (rand_mv(alg, rng=rng) for _ in range(3))
        if alg.mul(alg.mul(x, y), z) != alg.mul(x, alg.mul(y, z)):
            return False
    return True

def regular_matrix(alg, x):
    """left-multiplication matrix of x on the 2^n blade basis, as a list of lists of ints (column j = x * e_j)"""
    N = alg.N
    M = [[0] * N for _ in range(N)]
    for a, ca in x.items():
        for b in range(N):
            s, c = alg.blade_mul(a, b)
            if s:
                M[c][b] += s * ca
    return M

TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']   # the textbook mod-8 table (used only to COMPARE, never as input)
