# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The spacetime algebra Cl(1,3) written a second time, for the independent checks of this folder (hest_indep.py, ldg_indep.py, ldg_action.py): own bit-rule sign
function, own multivector product on 16 real components (numpy), nothing imported from the atlas.  Conventions of Hestenes and of Lasenby-Doran-Gull (LDG, appendix A):
frame gamma_mu (bit 0 = gamma_0, gamma_0^2 = +1; bits 1..3 = gamma_k, gamma_k^2 = -1), reciprocal frame gamma^mu, grad = gamma^mu d_mu,
I = gamma_0 gamma_1 gamma_2 gamma_3, sigma_k = gamma_k gamma_0, i sigma_3 = J = gamma_2 gamma_1."""
import numpy as np
SQ = [1, -1, -1, -1]           # squares of gamma_0 .. gamma_3
N = 16
def bits(m): return [i for i in range(4) if m >> i & 1]
def grade(m): return bin(m).count('1')
def bsign(a, b):
    """sign of e_a e_b = s e_(a xor b): the transpositions that sort the joined index list, then the squares of the repeated generators."""
    la, lb = bits(a), bits(b)
    swaps = sum(1 for i in la for j in lb if i > j)
    s = -1 if swaps % 2 else 1
    for i in set(la) & set(lb): s *= SQ[i]
    return s
TAB = np.zeros((N, N), int)
for _a in range(N):
    for _b in range(N): TAB[_a, _b] = bsign(_a, _b)
def gp(A, B):
    """geometric product of two multivectors (arrays of 16 components)"""
    C = np.zeros(N)
    for a in np.nonzero(A)[0]:
        for b in np.nonzero(B)[0]: C[a ^ b] += TAB[a, b] * A[a] * B[b]
    return C
def bl(m, c=1.0):
    v = np.zeros(N); v[m] = c; return v
def rev(A): return np.array([A[m] * (-1) ** (grade(m) * (grade(m) - 1) // 2) for m in range(N)])
def part(A, k): return np.array([A[m] if grade(m) == k else 0 for m in range(N)])
g = [bl(1 << i) for i in range(4)]                      # frame gamma_mu
gup = [g[0], -g[1], -g[2], -g[3]]                       # reciprocal frame gamma^mu
I = gp(gp(g[0], g[1]), gp(g[2], g[3]))                  # gamma_0 gamma_1 gamma_2 gamma_3
J = gp(g[2], g[1])                                      # i sigma_3 = gamma_2 gamma_1
sig = [None] + [gp(g[k], g[0]) for k in (1, 2, 3)]      # sigma_k = gamma_k gamma_0
EVEN = [m for m in range(N) if grade(m) % 2 == 0]
ODD = [m for m in range(N) if grade(m) % 2]
