#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Builds ../html/symmetry_breaking_note.html: one self-contained page (inline CSS and SVG, a few lines of JS for the theme button, no external request).
The model is shown as it stands in Furey's latest papers (the Roadmap cascade, the Trialities paper, the 2026 nested embeddings) next to the Atlas.
Every number the figures use is asserted against logs/symmetry_note_check.log (the checks of this note) and the Furey report logs of the Atlas.
Run:  python3 symmetry_note_check.py > logs/symmetry_note_check.log ; python3 build_note.py [--out FILE]
Takes status_chips.py, report_style.css and the Furey logs from ../furey (the Atlas log assertions)."""
import html, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
FUREY = os.path.join(HERE, '..', 'furey')
sys.path.insert(0, FUREY)
import status_chips as SC

E = html.escape
ATLAS = os.path.join(FUREY, 'logs')
LOGS = os.path.join(HERE, 'logs')


# ------------------------------------------------------------------ the logs
def read_log(path):
    ids, texts, info, bad = [], {}, [], 0
    for line in open(path, encoding='utf-8'):
        m = re.match(r'(ok|FAIL|info)\s+([A-Z]\d+):?\s+(.*)', line)
        if not m:
            continue
        if m.group(1) == 'ok':
            ids.append(m.group(2)); texts[m.group(2)] = m.group(3)
        elif m.group(1) == 'info':
            info.append((m.group(2), m.group(3)))
        else:
            bad += 1
    return ids, texts, info, bad


MIDS, MT, MINFO, MBAD = read_log(os.path.join(LOGS, 'symmetry_note_check.log'))
assert MBAD == 0
assert MIDS == ['M%d' % i for i in range(15)], MIDS                 # M12 is printed by the function that checks M11
assert len(MINFO) == 1 and MINFO[0][0] == 'M13'
MSAB = [l for l in open(os.path.join(LOGS, 'symmetry_note_check_sabotage.log'), encoding='utf-8') if l.startswith('sabotage')]
assert len(MSAB) == 8 and all(' exit 1,' in l for l in MSAB)
assert 'ALL SLIDE CHECKS PASS (14 check functions; M0-M14)' in open(os.path.join(LOGS, 'symmetry_note_check.log'), encoding='utf-8').read()

# the Spin(10) line as the script prints it (M10): the cascade of Roadmap I Fig. 4, and the charges
assert '(45, 0, [45]), (21, 0, [15,3,3]), (15, 1, [8,3,3]), (11, 3, [8]), (10, 2, [8])' in MT['M10']
assert 'lie in the 11; Q and B-L lie in the 10, Y does not' in MT['M10']
assert '21 even' in MT['M14']

AIDS, AT, _, ABAD = read_log(os.path.join(ATLAS, 'furey_papers_check.log'))
BIDS, BT, _, BBAD = read_log(os.path.join(ATLAS, 'furey_construction_check.log'))
assert ABAD == 0 and BBAD == 0
AT.update(BT)
for k in ['A2', 'A3', 'A4', 'A5', 'R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9', 'R10', 'R11', 'T1', 'T2', 'T3', 'T4', 'T5', 'F1', 'F2', 'F3', 'F4', 'C1', 'N1', 'N2',
          'B1', 'B2', 'B5', 'B6', 'B11', 'B12']:
    assert k in AT, k
assert '-> 11 (u(3)+u(1)+u(1)) -> 10' in AT['R7'] and '45 -> 21' in AT['R7'] and '-> 15' in AT['R7']
assert '24 -> 12 (su(3)+su(2)+u(1))' in AT['R8'] and '-> 10 (quaternionic) -> 9 (complex)' in AT['R8'] and 'either octonionic reflection' in AT['R8']
assert '12 (su(3)+su(2)+u(1))' in AT['R9'] and '9 (su(3)+u(1)_Q)' in AT['R9'] and '24 (su(5))' in AT['R9']
assert '9 + 28 + 96 = 133' in AT['T5']
assert '(1,2,+-1/2)' in AT['T3']
assert '256 blades' in AT['B2'] and '(2, 6, 4, 2, 1, 1)' in AT['B5'] and '(1, 3, 2, 1, 1)' in AT['B6'] and '128 + 128' in AT['B11']
assert 'dimension 14' in AT['N2'] and 'S = 6' in AT['N2']
assert 'no structure gives 3' in AT['B12'] and '5,582' in AT['B12'] and 'one complete set' in AT['C1']

CASCADE = [  # the Spin(10) line (M10): name, algebra in lines (svg markup), dimension, centre, ideals
    ('Spin(10)', ['so(10)'], 45, 0, '[45]'),
    ('Pati–Salam', ['su(4)', '+ su(2)_{L} + su(2)_{R}'], 21, 0, '[15, 3, 3]'),
    ('Left–Right', ['su(3) + u(1)_{B−L}', '+ su(2)_{L} + su(2)_{R}'], 15, 1, '[8, 3, 3]'),
    ('W± out', ['su(3) + u(1)_{B−L}', '+ u(1)_{T3L} + u(1)_{T3R}'], 11, 3, '[8]'),
    ('unbroken + (B−L)', ['su(3) + u(1)_{EM}', '+ u(1)_{B−L}'], 10, 2, '[8]'),
]
SU5 = [  # the SU(5) line (Atlas R8, R9): column of the shared grid, name, algebra lines, dimension
    (0, 'SU(5)', ['su(5)'], 24),
    (1, 'Standard Model', ['su(3) + su(2) + u(1)'], 12),
    (3, 'after ℍ', [], 10),
    (4, 'unbroken', ['su(3) + u(1)_{Q}'], 9),
]
OPS = [('L_{e7}', 'from 𝕆'), ('R_{e7}', 'from 𝕆'), ('L_{ε3}', 'from ℍ'), ('i → −i', 'from ℂ')]


# ------------------------------------------------------------------ small helpers for SVG text and html text
def over_svg(t):
    return re.sub('([0-9])[\u0304\u0305]', lambda m: '<tspan text-decoration="overline">%s</tspan>' % m.group(1), t)


def mk(s):
    """markup for svg text: _{x} subscript, ^{x} superscript (dy-shifted tspans, which every browser handles)"""
    out, i, shift = [], 0, 0
    pat = re.compile(r'([_^])\{([^}]*)\}')
    pos = 0
    chunks = []
    for m in pat.finditer(s):
        if m.start() > pos:
            chunks.append(('n', s[pos:m.start()]))
        chunks.append((m.group(1), m.group(2)))
        pos = m.end()
    if pos < len(s):
        chunks.append(('n', s[pos:]))
    cur = 0
    for kind, txt in chunks:
        if kind == 'n':
            out.append('<tspan dy="%s">%s</tspan>' % (-cur, over_svg(E(txt))) if cur else over_svg(E(txt)))
            cur = 0
        else:
            d = 3.5 if kind == '_' else -4.5
            out.append('<tspan dy="%s" font-size="75%%">%s</tspan>' % (d - cur, E(txt)))
            cur = d
    if cur:
        out.append('<tspan dy="%s"></tspan>' % -cur)
    return ''.join(out)


def tx(x, y, s, cls='ink2', anchor='start', extra=''):
    return '<text x="%s" y="%s" class="%s" text-anchor="%s" %s>%s</text>' % (x, y, cls, anchor, extra, mk(s))


def hx(s):
    """markup for html text: _{x} -> <sub>, ^{x} -> <sup>"""
    s = E(s)
    s = re.sub(r'_\{([^}]*)\}', r'<sub>\1</sub>', s)
    s = re.sub(r'\^\{([^}]*)\}', r'<sup>\1</sup>', s)
    s = re.sub('([0-9])[\u0304\u0305]', r'<span class="ob">\1</span>', s)
    return s


def chips(*flags):
    return ''.join(SC.chip(f) for f in flags)


def ids(*xs):
    return '<span class="ids">%s</span>' % E(', '.join(xs))


# ------------------------------------------------------------------ Figure 1: the cascade, two lines of reflections
def fig_cascade():
    W, Hh = 1000, 676
    cx = [110, 305, 500, 695, 890]
    bw, sc = 112, 3.4
    baseA, baseB = 262, 540
    o = ['<svg class="chart fx" viewBox="0 0 %d %d" role="img" aria-label="Two lines of reflections drawn as bars to scale: Spin(10) 45, 21, 15, 11, 10 and SU(5) 24, 12, 10, 9">' % (W, Hh)]
    o.append('<line x1="20" y1="%s" x2="980" y2="%s" class="bd-ax"/>' % (baseA, baseA))
    o.append('<line x1="20" y1="%s" x2="980" y2="%s" class="bd-ax"/>' % (baseB, baseB))
    o.append(tx(20, 18, 'Spin(10) line · Roadmap I, Fig. 4', 'ink'))
    o.append('<line x1="20" y1="364" x2="980" y2="364" stroke="var(--line2)" stroke-width="1" stroke-dasharray="4 3"/>')
    o.append(tx(20, 388, 'SU(5) line · Roadmap I, Fig. 5', 'ink'))

    def arrow(i, j, op, src, drop, y):
        xa = cx[i] + bw / 2 + 6
        xb = cx[j] - bw / 2 - 6
        o.append('<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="var(--ink)" stroke-width="1.8"/>' % (xa, y, xb - 7, y))
        o.append('<path d="M%s %s l-8 -4.5 l0 9 z" fill="var(--ink)"/>' % (xb, y))
        mid = (xa + xb) / 2
        o.append(tx(mid, y - 20, op, 'big', 'middle'))
        o.append(tx(mid, y - 6, '%s · −%d' % (src, drop), 'mut', 'middle'))

    def bar(i, base, name, alg, dim, cls, note, title):
        x = cx[i] - bw / 2
        h = dim * sc
        o.append('<g><title>%s</title><rect x="%s" y="%s" width="%s" height="%s" class="%s"/></g>' % (E(title), x, base - h, bw, h, cls))
        o.append(tx(cx[i], base - h - 8, str(dim), 'big', 'middle'))
        o.append(tx(cx[i], base + 20, name, 'ink', 'middle'))
        for k, line in enumerate(alg):
            o.append(tx(cx[i], base + 38 + 16 * k, line, 'ink2', 'middle'))
        o.append(tx(cx[i], base + 38 + 16 * len(alg) + 2, note, 'mut', 'middle'))

    for i, (name, alg, dim, cen, ide) in enumerate(CASCADE):
        bar(i, baseA, name, alg, dim, 'k1', 'centre %d · ideals %s' % (cen, ide),
            '%s: dimension %d, centre %d, simple ideals %s (recomputed, M10)' % (name, dim, cen, ide))
    for i, (op, src) in enumerate(OPS):
        arrow(i, i + 1, op, src, CASCADE[i][2] - CASCADE[i + 1][2], 62)
    for col, name, alg, dim in SU5:
        bar(col, baseB, name, alg, dim, 'k3', 'Atlas R8' if col < 4 else 'Atlas R8, R9',
            '%s: dimension %d (Atlas checks R8, R9)' % (name, dim))
    arrow(0, 1, OPS[0][0], OPS[0][1], 24 - 12, 440)
    arrow(1, 3, OPS[2][0], OPS[2][1], 12 - 10, 440)
    arrow(3, 4, OPS[3][0], OPS[3][1], 10 - 9, 440)
    o.append(tx(cx[2], baseB - 34, 'either octonionic', 'mut', 'middle'))
    o.append(tx(cx[2], baseB - 20, 'reflection gives the 12', 'mut', 'middle'))
    # legend
    o.append('<rect x="20" y="628" width="14" height="14" class="k1"/>' + tx(40, 640, 'recomputed in this note: dimension, centre and simple ideals of each stage (M10, M14)', 'ink2'))
    o.append('<rect x="20" y="648" width="14" height="14" class="k3"/>' + tx(40, 660, 'dimensions from the Atlas’s check of Fig. 5 (R8); the algebras named for 12 (R8) and 9 (R9). Bars to scale.', 'ink2'))
    o.append('</svg>')
    return ''.join(o)


# ------------------------------------------------------------------ Figure 3: four voices
def voice1():
    o = ['<svg class="chart" viewBox="0 0 460 250" role="img" aria-label="Nested boxes: Spin(10) contains Pati-Salam and so on">']
    names = [(n, d) for n, _, d, _, _ in CASCADE]
    for i, (n, d) in enumerate(names):
        x, y = 6 + i * 20, 6 + i * 22
        w, h = 448 - i * 40, 238 - i * 44
        o.append('<rect x="%s" y="%s" width="%s" height="%s" rx="10" fill="%s" stroke="var(--ink2)" stroke-width="1.4"/>' % (x, y, w, h, 'var(--surf)' if i % 2 == 0 else 'var(--tint)'))
        o.append(tx(x + 10, y + 17, '%s · %d' % (n, d), 'ink'))
    o.append('</svg>')
    return ''.join(o)


FANO_POS = {'V1': (60, 190), 'V2': (230, 190), 'V3': (145, 43), 'M12': (145, 190), 'M23': (188, 116), 'M13': (102, 116), 'C': (145, 141)}
FANO_LAB = {'V1': 1, 'V2': 2, 'V3': 5, 'M12': 4, 'M23': 3, 'M13': 6, 'C': 7}


def voice2():
    o = ['<svg class="chart" viewBox="0 0 520 250" role="img" aria-label="The Fano plane with the three lines through the unit 7, and the 45 generators as 21 even and 24 odd cells">']
    # Fano plane, lines through 7 on
    P = FANO_POS
    sides = [('V1', 'V2'), ('V2', 'V3'), ('V1', 'V3')]
    for a, b in sides:
        o.append('<line x1="%s" y1="%s" x2="%s" y2="%s" class="fn-line"/>' % (P[a] + P[b]))
    o.append('<circle cx="%s" cy="%s" r="%s" class="fn-line"/>' % (145, 141, 50))
    for a, b in [('V1', 'M23'), ('V2', 'M13'), ('V3', 'M12')]:
        o.append('<line x1="%s" y1="%s" x2="%s" y2="%s" class="fn-line on"/>' % (P[a] + P[b]))
    for k, (x, y) in P.items():
        o.append('<g class="fn-pt"><circle cx="%s" cy="%s" r="13" fill="%s" stroke="var(--ink)" stroke-width="%s"/><text x="%s" y="%s" text-anchor="middle" style="font:700 13px system-ui">%d</text></g>'
                 % (x, y, 'var(--c2)' if k == 'C' else 'var(--s)', 2 if k == 'C' else 1, x, y + 4.5, FANO_LAB[k]))
    o.append(tx(145, 236, 'lines through 7: (1,3), (2,6), (4,5)', 'mut', 'middle'))
    # the strip of 45
    groups = [('L_{a}L_{b}, a<b≤6', 15, True), ('L_{a}L_{7}', 6, False), ('L_{ε}L_{ε}', 3, True), ('iL_{ε}L_{a}, a≤6', 18, False), ('iL_{ε}L_{7}', 3, True)]
    x0, y0, s = 285, 80, 11
    o.append(tx(285, 36, 'the 45 generators of so(10)', 'ink'))
    o.append(tx(285, 52, 'conjugation by L_{e7} multiplies by (−1)^{k},', 'mut'))
    o.append(tx(285, 66, 'k = number of L_{ej} with j≤6', 'mut'))
    yy = y0
    for lab, n, ev in groups:
        per = 10
        for c in range(n):
            xx = x0 + (c % per) * (s + 2)
            y = yy + (c // per) * (s + 2)
            o.append('<rect x="%s" y="%s" width="%s" height="%s" rx="2" fill="%s" stroke="var(--c1)" stroke-width="1.3"/>' % (xx, y, s, s, 'var(--c1)' if ev else 'var(--surf)'))
        rows = (n + per - 1) // per
        o.append(tx(x0 + per * (s + 2) + 6, yy + 10, '%d · %s' % (n, lab), 'mut'))
        yy += rows * (s + 2) + 6
    o.append('<rect x="285" y="%s" width="12" height="12" fill="var(--c1)"/>' % (yy + 6) + tx(302, yy + 16, '21 even: commute, the Pati–Salam line', 'ink2'))
    o.append('<rect x="285" y="%s" width="12" height="12" fill="var(--surf)" stroke="var(--c1)" stroke-width="1.3"/>' % (yy + 26) + tx(302, yy + 36, '24 odd: anticommute, removed', 'ink2'))
    o.append('</svg>')
    return ''.join(o)


def voice3():
    o = ['<svg class="chart" viewBox="0 0 460 250" role="img" aria-label="A base line with four fibres of dimension 24, 6, 4 and 1 and a section through them">']
    o.append('<line x1="20" y1="200" x2="440" y2="200" stroke="var(--ink)" stroke-width="2"/>')
    o.append(tx(20, 222, 'base', 'ink2'))
    fib = [(80, 24, 'L_{e7}'), (170, 6, 'R_{e7}'), (260, 4, 'L_{ε3}'), (350, 1, 'i → −i')]
    pts = []
    for i, (x, d, lab) in enumerate(fib):
        h = d * 5.0
        o.append('<g><title>fibre G/H of dimension %d</title><line x1="%s" y1="200" x2="%s" y2="%s" stroke="var(--c1)" stroke-width="6" stroke-linecap="round"/></g>' % (d, x, x, 200 - h))
        yq = 200 - h * 0.55
        pts.append((x, yq))
        o.append('<circle cx="%s" cy="%s" r="4.5" fill="var(--c2)" stroke="var(--ink)"/>' % (x, yq))
        o.append(tx(x, 200 - h - 8, 'dim %d' % d, 'ink', 'middle'))
        o.append(tx(x, 240, lab, 'ink2', 'middle'))
    path = 'M%s %s' % pts[0]
    for a, b in zip(pts[:-1], pts[1:]):
        path += ' Q %s %s %s %s' % ((a[0] + b[0]) / 2, min(a[1], b[1]) - 16, b[0], b[1])
    o.append('<path d="%s" fill="none" stroke="var(--c2)" stroke-width="2"/>' % path)
    o.append(tx(20, 20, 'a choice of J at each point = a section of the bundle with fibre G/H', 'mut'))
    o.append(tx(20, 36, 'fibres of dimension 45−21, 21−15, 15−11, 11−10', 'mut'))
    o.append('</svg>')
    return ''.join(o)


def voice4():
    o = ['<svg class="chart" viewBox="0 0 520 250" role="img" aria-label="Chain of monomorphisms g10 to g45, each an equaliser">']
    xs = [50, 160, 270, 380, 490]
    names = [('g_{10}', 10), ('g_{11}', 11), ('g_{15}', 15), ('g_{21}', 21), ('g_{45}', 45)]
    y = 70
    for x, (n, d) in zip(xs, names):
        o.append('<circle cx="%s" cy="%s" r="22" fill="var(--surf)" stroke="var(--ink)" stroke-width="1.6"/>' % (x, y))
        o.append(tx(x, y + 4, n, 'ink', 'middle'))
        o.append(tx(x, y + 40, 'dim %d' % d, 'mut', 'middle'))
    for a, b in zip(xs[:-1], xs[1:]):
        o.append('<path d="M%s %s h%s" stroke="var(--ink)" stroke-width="1.8" fill="none"/>' % (a + 28, y, b - a - 62))
        o.append('<path d="M%s %s q-6 -4 0 -8" stroke="var(--ink)" stroke-width="1.8" fill="none"/>' % (a + 28, y + 0))
        o.append('<path d="M%s %s l-8 -4.5 l0 9 z" fill="var(--ink)"/>' % (b - 28, y))
    # the equaliser inset
    o.append(tx(20, 150, 'each step is an equaliser of two arrows into gl(32, ℂ):', 'ink'))
    ex, ey = 110, 205
    o.append('<circle cx="%s" cy="%s" r="20" fill="var(--surf)" stroke="var(--ink)" stroke-width="1.6"/>' % (ex, ey) + tx(ex, ey + 4, 'g_{k}', 'ink', 'middle'))
    o.append('<circle cx="%s" cy="%s" r="20" fill="var(--surf)" stroke="var(--ink)" stroke-width="1.6"/>' % (ex + 130, ey) + tx(ex + 130, ey + 4, 'g_{k−1}', 'ink', 'middle'))
    o.append('<circle cx="%s" cy="%s" r="26" fill="var(--surf)" stroke="var(--ink)" stroke-width="1.6"/>' % (ex + 290, ey) + tx(ex + 290, ey + 4, 'gl(32,ℂ)', 'ink', 'middle'))
    o.append('<path d="M%s %s h%s" stroke="var(--ink)" stroke-width="1.8" fill="none"/><path d="M%s %s l-8 -4.5 l0 9 z" fill="var(--ink)"/>' % (ex + 24, ey, 80, ex + 106, ey))
    for dy in (-7, 7):
        o.append('<path d="M%s %s h%s" stroke="var(--ink)" stroke-width="1.8" fill="none"/><path d="M%s %s l-8 -4.5 l0 9 z" fill="var(--ink)"/>' % (ex + 154, ey + dy, 100, ex + 260, ey + dy))
    o.append(tx(ex + 205, ey - 14, 'ι', 'ink2', 'middle'))
    o.append(tx(ex + 205, ey + 28, 'Ad_{X}∘ι', 'ink2', 'middle'))
    o.append(tx(20, 20, 'a chain of monomorphisms: g_{10} ↪ g_{11} ↪ g_{15} ↪ g_{21} ↪ g_{45}', 'mut'))
    o.append('</svg>')
    return ''.join(o)


# ------------------------------------------------------------------ the grid: her model, topic by topic, and the Atlas (Figure 3)
TOPICS = [  # topic, pointer to the 2021 talk, her model (kind, text, ids), the Atlas (kind, text, ids); kind: std read, chk checked, opn open
    ('One generation: Cl(10) and so(10)', 'talk pp. 10 to 23, 43 to 46', [
        ('std', 'A = ℝ⊗ℂ⊗ℍ⊗𝕆 acting on itself holds one generation of Standard Model Weyl states in a single copy. The 45 left-multiplication generators close as spin(10) on the 16 left-handed states; sl(2,ℂ) acts by right multiplication (PLB 827, 2022; Roadmap I, 2023: ten gamma matrices, ladder operators, vacuum).', ''),
    ], [
        ('chk', 'Rebuilt from the octonion table: the 45 generators close as so(10); ℂ³² = (16; 2) with commutant M₂(ℂ); the products span all of Cl(10); the gamma matrices, ladder operators and vacuum; the left-handed projector has rank 16; Y, Q and B−L take the Standard Model values on the 16, with trace and sum of cubes zero.', 'M1–M6, A2–A5, R1–R6, R11'),
    ]),
    ('The cascade', 'talk pp. 27 to 31', [
        ('std', 'Roadmap I, Figures 4 and 5: reflections by L_{e7} and R_{e7} (octonionic), L_{ε3} (quaternionic) and complex conjugation. Spin(10) line 45 → 21 → 15 → 11 → 10 (all four); SU(5) line 24 → 12 → 10 → 9 (three of them). Roadmap III: intersections of spinor conditions give 24, 12 and 9; a single constraint with a free scalar gives 12.', ''),
    ], [
        ('chk', 'Both lines recomputed (R7, R8). The Spin(10) line also as Lie algebras on the 32 complex dimensions, with centres, simple ideals and the charges Y, Q, B−L (M9, M10, M14). The intersections and the single constraint (R9, R10).', 'R7–R10, M9, M10, M14'),
    ]),
    ('Triality and the Higgs', 'talk pp. 38 to 56', [
        ('std', 'Trialities (2024, with Hughes): the Standard Model algebra inside tri(ℍ) + tri(𝕆), acting on (Ψ⁺, Ψ⁻, V); the Higgs doublets (1,2,±½) sit in V; e₇ = tri(ℍ) + tri(𝕆) + 3 ℍ⊗𝕆, 133 = 9 + 28 + 96; a Cartan factorization.', ''),
    ], [
        ('chk', 'The 14 operators of eq. (24) as derivations of 𝕆; the Standard Model action and its hypercharge spectra on Ψ⁺, Ψ⁻, V; Cartan’s triality principle; the dimension counts of e₇ and e₈.', 'T1–T5'),
        ('chk', 'The quaternionic factor on its own: tri(ℝ, ℂ, ℍ, 𝕆) of dimensions 0, 2, 9, 28; tri(ℍ) = su(2)³ acting on the halves (4,2,1; 2,1) + (4̄,1,2; 2,1) and on a (2,2) scalar that becomes one complex doublet.', 'M7, M8, M11–M13'),
        ('opn', 'The Cartan factorization is not rebuilt.', ''),
    ]),
    ('Spacetime', 'talk pp. 45 to 47', [
        ('std', 'sl(2,ℂ) = so(3,1) acts by right multiplication and commutes with the 45 generators, “guaranteed never to run foul of the Coleman-Mandula theorem” (PLB 827 §2.4). Roadmap II lists the theorem as its first checkpoint.', ''),
    ], [
        ('chk', 'The commutation, and sl(2,ℂ) as a simple real algebra.', 'M4, M5'),
        ('opn', 'The checkpoint of Roadmap II, the Dirac operator and the Lagrangian are not tested.', ''),
    ]),
    ('The 2026 model: V, Cl(0,8), Peirce blocks', 'talk pp. 58 to 67', [
        ('std', 'Nested embeddings ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆 (2026): V = 𝕆 ⊕ 𝕆′ of 16 real dimensions, End_{ℝ}(V) = Cl(0,8), Peirce blocks of real ranks (2, 6, 4, 2, 1, 1), Y and Q as sums of projectors, the 20 cells of her Fig. 1 labelled with the fermions.', ''),
    ], [
        ('chk', 'The 256 blades of 8-bit labels; the Peirce blocks (2,6,4,2,1,1) and (1,3,2,1,1); the 20 cells of Fig. 1 with their irreps and charges; Tr Y = Tr Q = 3; one complete set of fermions, 8 complex dimensions beyond it.', 'B1–B11, F1–F4, C1'),
        ('chk', 'Our own counts. Over the 5,582 admissible block structures of complex dimension 8, counting the linear off-diagonal and the antilinear operators of End_{ℝ}(V), none gives three complete generations (at most two). Counting complete sets in linear cells only, one fits up to dimension 10, two at 11 to 13, and three first appear at dimension 14.', 'B12, N1, N2'),
    ]),
]


def topics_grid():
    o = ['<div class="mxwrap"><div class="tp" role="table" aria-label="Furey’s model topic by topic, and what the Atlas has for it">']
    o.append('<div class="tp-h" role="columnheader">topic</div><div class="tp-h" role="columnheader">Furey’s model, as we read it in 2026</div><div class="tp-h" role="columnheader">The Atlas</div>')

    def cell(col, items):
        r = ['<div class="tp-cell" role="cell" data-col="%s">' % E(col)]
        for k, text, cid in items:
            flag = {'chk': 'checked', 'std': 'standard', 'opn': 'open'}[k]
            r.append('<div class="tp-c %s"><div class="tp-t">%s%s</div>%s</div>' % (k, SC.chip(flag), ids(cid) if cid else '', hx(text)))
        r.append('</div>')
        return ''.join(r)
    for name, ptr, her, atl in TOPICS:
        o.append('<div class="tp-r" role="rowheader"><b>%s</b><br><span class="ids">%s</span></div>' % (E(name), E(ptr)))
        o.append(cell('Furey’s model', her))
        o.append(cell('The Atlas', atl))
    o.append('</div></div>')
    return ''.join(o)


# the checks table: one short line per id
CHECK_LINES = {
    'M0': 'the octonion table is a normed division algebra',
    'M1': 'Cl(0,6) = M8(ℝ) from L_{e1}…L_{e6}; the diamond of p. 10',
    'M2': 'R_{e7} formula; left against right for 𝕆, ℍ, ℂ',
    'M3': 'the 45 generators close as so(10); so(7) + so(3) and the 21',
    'M4': 'the commutant is M2(ℂ): 32 = (16; 2)',
    'M5': 'sl(2,ℂ) by right multiplication, commuting with so(10)',
    'M6': 'the products span all of M32(ℂ) = Cl(10)',
    'M7': 'dimensions of tri(ℝ, ℂ, ℍ, 𝕆): 0, 2, 9, 28',
    'M8': 'quaternionic triality and Yukawa invariance',
    'M9': 'the new basis of p. 23 and the 21 of the Pati–Salam line',
    'M10': 'the Spin(10) line 45, 21, 15, 11, 10 of Roadmap I Fig. 4; the charges Y, Q, B−L in the 11 and the 10',
    'M11': 'ψ⁺ and ψ⁻: irreducible halves, Casimirs, 4 against 4̄',
    'M12': 'tri(ℍ) inside g_{PS} + sl(2,ℂ); multiplicity 4',
    'M13': 'the Higgs bidoublet and its complex doublet; arithmetic of pp. 54–55 (info)',
    'M14': 'the sign rules behind each step; the Fano lines through e7; u(3) = centraliser of J',
}


def check_table():
    o = ['<table class="gs"><thead><tr><th>id</th><th>what it recomputes</th></tr></thead><tbody>']
    for k in MIDS:
        o.append('<tr><td><b>%s</b></td><td>%s</td></tr>' % (k, hx(CHECK_LINES[k])))
    o.append('</tbody></table>')
    return ''.join(o)


# ------------------------------------------------------------------ the page
QUOTES = [
    ('“a sequence of complex structures which induces a cascade of breaking symmetries”', 'abstract'),
    ('“Clifford algebraic grade involutions (equivalently, complex structures)”', '§1'),
    ('“They derive from the octonions, then the quaternions, then the complex numbers.”', '§1'),
    ('“requiring commutation with the complex structure L_{e7} is equivalent to requiring invariance under the Clifford algebraic grade involution, L_{ej} → −L_{ej} for j = 1…6”', '§2.3'),
]

CSS_EXTRA = '''
.tp{display:grid;grid-template-columns:150px minmax(0,1fr) minmax(0,1fr);gap:6px;align-items:start}
.tp-h{font-size:12.5px;font-weight:700;color:var(--ink2);padding:2px 6px;border-bottom:2px solid var(--line2)}
.tp-r{font-size:13.5px;padding:7px;background:var(--tint);border-radius:8px}
.tp-cell{display:flex;flex-direction:column;gap:5px;min-width:0}
.tp-c{font-size:13px;line-height:1.4;padding:6px 8px 7px 12px;border:1px solid var(--line);border-radius:8px;background:var(--surf)}
.tp-c.chk{box-shadow:inset 4px 0 0 var(--ic-checked)}.tp-c.std{box-shadow:inset 4px 0 0 var(--ic-standard)}.tp-c.opn{box-shadow:inset 4px 0 0 var(--ic-open)}
.tp-t{margin-bottom:3px;display:flex;align-items:center;gap:4px;flex-wrap:wrap}.tp-t .chip{margin:0}
@media (max-width:760px){.tp{grid-template-columns:1fr}.tp-h{display:none}.tp-r{margin-top:8px}.tp-cell::before{content:attr(data-col);font-size:11.5px;font-weight:700;color:var(--muted)}}
.voices{display:grid;grid-template-columns:1fr 1fr;gap:14px}.voices>*{min-width:0}
@media (max-width:860px){.voices{grid-template-columns:1fr}}
.voice h3{font-size:16px}.voice .vh{display:flex;gap:8px;align-items:baseline;flex-wrap:wrap}.voice .who{font-size:12px;color:var(--muted)}
.voice p{font-size:14px;margin:6px 0}.voice blockquote{margin:6px 0;padding:2px 0 2px 10px;border-left:3px solid var(--line2);font-size:13.5px;color:var(--ink2)}
.voice blockquote cite{display:block;font-size:11.5px;color:var(--muted);font-style:normal}
.voice .warn{font-size:12.5px;border:1px dashed var(--line2);border-radius:8px;padding:5px 8px;background:var(--tint);margin:6px 0}
.qlist{counter-reset:q;list-style:none;padding:0}.qlist li{counter-increment:q;position:relative;padding:10px 14px 10px 46px;margin:8px 0;background:var(--surf);border:1px solid var(--line);border-radius:12px;box-shadow:var(--shadow);font-size:15px}
.qlist li::before{content:counter(q);position:absolute;left:12px;top:10px;width:24px;height:24px;line-height:24px;text-align:center;border-radius:50%;background:var(--e);color:var(--e-ink);font-weight:700;font-size:13px}
.qlist li small{display:block;color:var(--muted);font-size:12.5px;margin-top:3px}
.eqn{font-family:ui-serif,Georgia,'Times New Roman',serif;font-size:16px;margin:6px 0;padding:6px 12px;background:var(--tint);border-radius:8px;overflow-x:auto}
.ob{text-decoration:overline}
.legendline{font-size:13px;color:var(--ink2);margin:8px 0}
'''

STEPS_TABLE = [
    ('1', 'octonionic, left', 'commute with L_{e7} = L_{e1}…L_{e6}; P_{L}, P_{R} = ½(1 ± iL_{e7})', 'M9, M10, M14, R7', 'so(6) + su(2) + su(2) · 21'),
    ('2', 'octonionic, right', 'commute with R_{e7} = ½(−L_{e7} + L_{e1}L_{e3} + L_{e2}L_{e6} + L_{e4}L_{e5}); the u(3) is the centraliser of J = L_{e1}L_{e3} + L_{e2}L_{e6} + L_{e4}L_{e5}', 'A2, M2, M10, M14, R7', 'u(3) + su(2) + su(2) · 15'),
    ('3', 'quaternionic', 'commute with L_{ε3} on the 16 of Spin(10); of each su(2) only the generator along ε3 stays', 'M10, M14, R7', 'u(3) + u(1) + u(1) · 11'),
    ('4', 'complex', 'equal to the complex conjugate, i → −i (every L and R matrix is real, i is central: only the grade involution acts)', 'M10, M14, R7', 'u(3) + u(1) · 10'),
]


def fix_vars(page):
    """move fill=\"var(--x)\" and stroke=\"var(--x)\" attributes into a style attribute (every browser accepts var() there)"""
    def tag(m):
        t = m.group(0)
        decl = re.findall(r'\s(fill|stroke)="(var\([^"]*\))"', t)
        if not decl:
            return t
        t = re.sub(r'\s(fill|stroke)="var\([^"]*\)"', '', t)
        add = ';'.join('%s:%s' % d for d in decl)
        ms = re.search(r'\sstyle="([^"]*)"', t)
        if ms:
            return t.replace(ms.group(0), ' style="%s;%s"' % (add, ms.group(1)), 1)
        return re.sub(r'(/?>)$', r' style="%s"\1' % add, t)
    return re.sub(r'<[a-zA-Z][^<>]*>', tag, page)


def build():
    css = open(os.path.join(FUREY, 'report_style.css'), encoding='utf-8').read() + SC.CSS + CSS_EXTRA
    kp = [('67', 'slides read'), ('15 of 15', 'checks pass (M0–M14); 1 info line'), ('8 of 8', 'deliberately broken variants stopped at a named check'),
          ('7', 'papers read: the two of 2022 and five later (Roadmap I–III, Trialities, nested embeddings)')]
    h = []
    A = h.append
    A('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Division algebraic symmetry breaking and the Atlas</title>')
    A('<style>%s</style></head><body>' % css)
    A(SC.SPRITE)
    A('<header class="hero"><div class="wrap"><span class="kick">a note on the work of Furey and Hughes</span>')
    A('<h1>Division algebraic symmetry breaking: Furey’s model as we read it in 2026, and what the Atlas did for it</h1>')
    A('<p class="sub">Starting point: the talk of N. Furey with M. J. Hughes, Perimeter Institute, 15 March 2021 (PIRSA 21030013, 67 slides). Its algebra (pages 10 to 56) was recomputed from the octonion multiplication table. '
      'The model is shown as it stands in Furey’s latest papers, 2022 to 2026, which the Atlas already holds, next to the Atlas’s own reading. Section 5 lists what was not done.</p>')
    A('<div class="notice">Read the figures first; the words and equations follow them. The status icons: ' + SC.legend(['checked', 'standard', 'ours', 'input', 'open']) + '</div>')
    A('<div class="kpis">' + ''.join('<div class="kpi"><b>%s</b><span>%s</span></div>' % (E(a), E(b)) for a, b in kp) + '</div></div></header>')
    A('<nav class="toc"><div class="wrap"><a href="#f1">1 Cascade</a><a href="#f2">2 Four voices</a><a href="#f3">3 The model and the Atlas</a>'
      '<a href="#q">4 Questions</a><a href="#not">5 What this does not show</a><a href="#run">6 Rerun</a><a href="#src">7 Sources</a><button type="button" id="th">theme: auto</button></div></nav>')
    A('<main class="wrap">')

    # --- Figure 1
    A('<section id="f1"><h2>1 · The cascade</h2>')
    A('<p class="lead">Furey’s cascade, in its latest form (Roadmap I, December 2023), is a sequence of reflections of the 45 generators of Spin(10): octonionic from the left, octonionic from the right, quaternionic, complex. '
      'Each reflection is a condition and leaves a smaller Lie algebra. Rebuilt from the octonion table, the dimensions, the centres and the simple ideals of the Spin(10) line are exactly those of the algebras named. '
      'The SU(5) line, which passes through the Standard Model algebra itself, is the Atlas’s check of Roadmap I, Fig. 5.</p>')
    A('<figure class="fig"><div class="figtitle">Figure 1 · two lines of reflections</div><div class="sv">%s</div>' % fig_cascade())
    A('<figcaption>%s the Spin(10) line recomputed on the 32 complex dimensions of ℂ⊗ℍ⊗𝕆 (M10, M14) and, by dimension, in the Atlas (R7); the SU(5) line in the Atlas (R8, R9). '
      '%s Roadmap I, Figures 4 and 5, as the Atlas reads them. %s the name “W± out” for the stage of dimension 11, where only the T<sub>3</sub> of each su(2) remains, is ours.</figcaption></figure>' % (chips('checked'), chips('standard'), chips('ours')))
    A('<h3 style="margin-top:14px">In equations</h3><div class="tvscroll" style="max-height:none"><table class="gs" style="min-width:640px"><thead><tr><th>step</th><th>reflection</th><th>condition</th><th>checks</th><th>left</th></tr></thead><tbody>')
    for a, b, c, d, e in STEPS_TABLE:
        A('<tr><td class="num">%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (a, hx(b), hx(c), hx(d), hx(e)))
    A('</tbody></table></div>')
    A('<p>' + hx('The three charges of the Atlas (R11) are combinations of three generators of the 11: B−L = J/3, Y = T_{3R} + (B−L)/2, Q = T_{3L} + Y. All three lie in the 11. After the last reflection Q and B−L remain and Y does not (M10).') + ' %s</p>' % chips('checked'))
    A('<p class="not">Steps 1 and 3 are also sign rules on the 45 generators (grade involutions of the Clifford algebra), step 2 a centraliser and step 4 the complex conjugation: that is the content of Figure 2, second card.</p></section>')

    # --- Figure 2
    A('<section id="f2"><h2>2 · The same cascade in four voices</h2>')
    A('<p class="lead">First as Furey writes it, then in the Atlas’s words (bit labels), then in the vocabulary of Schuller’s lectures, then in the language of categories. The second voice is checked; the third and fourth are our translations and say so.</p>')
    A('<figure class="fig" style="margin:0"><div class="figtitle">Figure 2 · the cascade in four voices</div></figure>')
    A('<div class="voices">')
    # voice 1
    A('<div class="card voice"><div class="vh"><h3>1 · Furey’s words</h3><span class="who">PLB 831 and Roadmap I</span></div>')
    A('<div class="sv">%s</div>' % voice1())
    for q, w in QUOTES[:2]:
        A('<blockquote>%s<cite>%s</cite></blockquote>' % (hx(q), E(w)))
    A('<p>Russian dolls: each model sits inside the previous one. The steps “derive from the octonions, then the quaternions, then the complex numbers”; in Roadmap I the octonionic step is applied twice, from the left and from the right, then the quaternionic and the complex ones, each as a reflection.</p>')
    A('<p>%s the quotations are from PLB 831 (2022), as printed; the reflections are read from Roadmap I (2023).</p></div>' % chips('standard'))
    # voice 2
    A('<div class="card voice"><div class="vh"><h3>2 · Our words: bit labels</h3><span class="who">the Atlas</span></div>')
    A('<div class="sv">%s</div>' % voice2())
    A('<p>' + hx('The octonion units can be given 3-bit labels, and the product is then the unit of the XOR of the labels, with a sign (B1, in its own numbering; the Fano figure below uses the numbering of M14). L_{e1}…L_{e6} are six anticommuting generators and their product is L_{e7}. '
                 'Steps 1 and 3 are sign rules on the 45 generators. Step 1 keeps those with an even number of the six (L_{e7} counts as six): 21 survive, 24 do not. '
                 'Step 2 is a centraliser: the three pairs in R_{e7} are the three lines through the point 7 of the Fano plane, and what survives is the centraliser of J, the 9-dimensional u(3), with J spanning its centre. '
                 'Step 3 is a sign on ε1 and ε2: of each su(2) only the generator along ε3 survives. Step 4 is i → −i, and every L and R matrix is real.') + '</p>')
    A('<p>%s M14, M10, A3 %s the wording as a sign rule on bit labels is ours; the facts are computed.</p></div>' % (chips('checked'), chips('ours')))
    # voice 3
    A('<div class="card voice"><div class="vh"><h3>3 · Schuller’s vocabulary</h3><span class="who">our translation</span></div>')
    A('<div class="sv">%s</div>' % voice3())
    A('<div class="warn">Our translation into the vocabulary of the constructive-gravity lectures (quadratic form, Clifford algebra, fibre and base, principal and associated bundles). These are not his words and he has not seen them.</div>')
    A('<p>' + hx('A complex structure J is a point of a coset G/H. Choosing one at every point of a base is a section of the associated bundle with fibre G/H, which is the same as reducing the structure group from G to H. '
                 'The cascade is four successive reductions, with fibres of dimension 24, 6, 4 and 1 (45−21, 21−15, 15−11, 11−10). '
                 'On the algebra side, the picture of the left action as base and the right action as fibre (F10 of the Atlas’s Schuller report, for Clifford algebras acting on themselves) fits the left and right multiplications of the division algebras: for ℍ the right multiplications are an independent commuting copy; for 𝕆 they lie inside the left algebra (M2).') + '</p>')
    A('<p>%s the dimensions and M2 are computed; %s the translation, and the use of the F10 picture for the division algebras, are ours.</p></div>' % (chips('checked'), chips('ours')))
    # voice 4
    A('<div class="card voice"><div class="vh"><h3>4 · Categorical words</h3><span class="who">our reading</span></div>')
    A('<div class="sv">%s</div>' % voice4())
    A('<p>' + hx('In the category of real Lie algebras, step k is the equaliser of two parallel maps g_{k−1} ⇉ gl(32, ℂ): the inclusion, and the inclusion followed by conjugation by the k-th reflection X (an involution; for the last step, complex conjugation). '
                 'An equaliser is a monomorphism and the largest subobject on which the two maps agree, so the cascade is a chain g_{10} ↪ g_{11} ↪ g_{15} ↪ g_{21} ↪ g_{45}, each arrow universal for its condition.') + '</p>')
    A('<p class="not">The Atlas’s own category lens (step 18) concerns labels ordered by inclusion; this use, Lie algebras and their equalisers, is standard category theory applied to the cascade, not a result of that step.</p>')
    A('<p>%s equalisers in Lie algebras %s the reading of the cascade as such a chain is ours; the commutants it names are computed (M10).</p></div>' % (chips('standard'), chips('ours')))
    A('</div></section>')

    # --- Figure 3: the model and the Atlas
    A('<section id="f3"><h2>3 · The model, topic by topic, and the Atlas</h2>')
    A('<p class="lead">Left, Furey’s model as it stands in her latest paper on each topic; right, what the Atlas has rebuilt for it and where it has nothing. '
      'Under each topic are the pages of the 2021 talk that deal with it.</p>')
    A('<figure class="fig"><div class="figtitle">Figure 3 · the model against the Atlas</div>%s' % topics_grid())
    A('<figcaption>%s checked, with ids of the Atlas (A, R, T, B, F, C, N) or of this note (M); %s read in the sources; %s not computed, not read, or not rebuilt.</figcaption></figure>'
      % (chips('checked'), chips('standard'), chips('open')))
    A('<h3 style="margin-top:16px">The checks of this note</h3>' + check_table())
    A('<p class="not">One info line in the log is not a check: the arithmetic of pp. 54–55 (8 copies of the triality scalar).</p></section>')

    # --- questions
    A('<section id="q"><h2>4 · Questions that the papers do not settle</h2>')
    A('<p class="lead">All four concern the latest model or what the Atlas found around it; the most elementary first. A pointer to a place in a paper is enough as an answer to any of them.</p>')
    A('<ol class="qlist">')
    A('<li>' + hx('The 11-dimensional stage. In our reading of Roadmap I, Fig. 4, the quaternionic reflection keeps, in each of the two su(2), only the generator along ε3 (the two T_{3}) and removes the charged ones; the complex reflection then keeps their sum, so that Q and B−L survive and Y does not (M10). Is that how you read the 11 and the 10?') +
      '<small>Figure 1; M10 and R7. The Roadmap is Furey’s alone, so this may be better put to her.</small></li>')
    A('<li>' + hx('One generation and three. The cascade acts on the 16 of one generation (Roadmap I); the Trialities paper puts the Standard Model algebra inside tri(ℍ) + tri(𝕆), acting on (Ψ^{+}, Ψ^{−}, V). We have checked each side and have not compared them. Is the Standard Model algebra of the triality model, restricted to the states of one generation, the su(3) + su(2) + u(1) of dimension 12 on the SU(5) line?') +
      '<small>R8 and R9 against T1–T3.</small></li>')
    A('<li>' + hx('Reflections and Peirce blocks. The real Peirce projectors of End_{ℝ}(V) in the 2026 model, as the Atlas rebuilds them (B5), include ½(1 ∓ L_{e7}R_{e7}), built from the same L_{e7} and R_{e7} as the first two reflections of the cascade. Is that the origin of the Peirce decomposition, so that the blocks (2, 6, 4, 2, 1, 1) record the reflections?') +
      '<small>B5, B6 against R7.</small></li>')
    A('<li>' + hx('Three generations. In the frame of the 2026 paper one complete set of fermions fits in V (C1). We count in two conventions and do not compare them. (B12) Over the 5,582 admissible block structures of complex dimension 8, counting the linear off-diagonal and the antilinear operators of End_{ℝ}(V), we find at most two complete generations. (N2) Counting complete sets in linear cells only, one fits up to dimension 10, two at 11 to 13, and three first appear at dimension 14. Is the route to three generations an enlargement of V, the triality of the 2024 paper, or something else?') +
      '<small>B12, N1, N2; the Superalgebra paper of 2025 is not read here.</small></li>')
    A('</ol></section>')

    # --- limits
    A('<section id="not"><h2>5 · What this does not show</h2><ul class="tight">')
    for t in [
        'The checks are linear algebra in floating point (tolerances of 1e-8 to 1e-9) and exact counts: they show that the stated dimensions, algebras and representations follow from the construction as written, not that the physics is right.',
        'The checks of this note cover the algebra from the octonion table to the cascade and the quaternionic triality. They do not reproduce the Dirac operator and Lagrangian, the octonionic part of the Yukawa term, the removal of B−L, or the last part of the talk (the su(3)<sub>C</sub> decomposition of Cl(8), the multi-action, the coarse-graining).',
        'The SU(5) line, the spinor intersections and the single constraint come from the Atlas’s checks of Roadmap I and III (R8 to R10); the script of this note does not recompute them.',
        'The Superalgebra paper (arXiv:2505.07923) was not read; the Cartan factorization of the Trialities paper is not rebuilt; Roadmap II’s checkpoint of Coleman–Mandula is not tested.',
        'The third and fourth voices of Figure 2 are translations of ours. They add no check and no claim about what Schuller or any category theorist says.',
        'What each reflection does in Roadmap I Fig. 4 and 5 is read from the Atlas’s checks R7 and R8, not quoted from the Roadmap’s text; the name “W± out” for the stage of dimension 11 is ours.',
    ]:
        A('<li>%s</li>' % t)
    A('</ul></section>')

    # --- rerun
    A('<section id="run"><h2>6 · Rerun</h2><p>Python 3 and numpy only. The script, its logs and the builder of this page are in <code>reports/note/</code> of the package.</p>')
    A('<pre>python3 reports/note/symmetry_note_check.py              # 15 ok lines M0–M14, 1 info line, about 20 s\npython3 reports/note/symmetry_note_check.py --selftest   # eight broken variants; each must stop at a named check</pre>')
    A('<p>The eight variants stop at: M0 (a wrong octonion triple), M2 (a sign in the right-multiplication formula), M10 twice (the quaternionic step left out; the complex-conjugation step left out), M5 (left instead of right multiplication for sl(2,ℂ)), M3 (a missing i in the generators), M8 (a sign in the triality transformation), M14 (L<sub>e7</sub> counted as odd in the sign rule).</p>')
    A('<p class="ids">Logs: reports/note/logs/symmetry_note_check.log and symmetry_note_check_sabotage.log.</p></section>')

    # --- sources
    A('<section id="src"><h2>7 · Sources</h2><ul class="tight">')
    for t in [
        'N. Furey with M. J. Hughes, “Division algebraic symmetry breaking”, slides, Perimeter Institute, 15 March 2021, PIRSA 21030013 (67 pages).',
        'N. Furey, M. J. Hughes, “Division algebraic symmetry breaking”, Phys. Lett. B 831 (2022) 137186, <a href="https://arxiv.org/abs/2210.10126">arXiv:2210.10126</a> (read in full).',
        'N. Furey, M. J. Hughes, “One generation of standard model Weyl representations as a single copy of ℝ⊗ℂ⊗ℍ⊗𝕆”, Phys. Lett. B 827 (2022) 136959, <a href="https://arxiv.org/abs/2209.13016">arXiv:2209.13016</a> (read in full).',
        'N. Furey, An Algebraic Roadmap of Particle Theories, Parts I–III, arXiv:2312.12377, 2312.12799, 2312.14207 (December 2023).',
        'N. Furey, M. J. Hughes, Three Generations and a Trio of Trialities, arXiv:2409.17948 (September 2024).',
        'N. Furey, A Superalgebra Within, arXiv:2505.07923 (May 2025; not read). N. Furey, Standard Model Symmetries and the Nested Embeddings of ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆, arXiv:2607.18450 (July 2026).',
        'The Atlas: the Furey report (<a href="furey_report.html">furey_report.html</a>; <code>reports/furey</code>: furey_papers_check.py A, R, T, F, C, P, N; furey_construction_check.py B) of the package.',
    ]:
        A('<li>%s</li>' % t)
    A('</ul></section></main>')
    A('<footer><div class="wrap">No address or contact of any person is in this page or in the files of reports/note/.</div></footer>')
    A("<script>var b=document.getElementById('th');if(b){var modes=['auto','light','dark'],i=0;b.addEventListener('click',function(){i=(i+1)%3;var m=modes[i];if(m==='auto')document.documentElement.removeAttribute('data-theme');else document.documentElement.setAttribute('data-theme',m);b.textContent='theme: '+m;});}</script>")
    A('</body></html>')
    return fix_vars(''.join(h))


if __name__ == '__main__':
    out = sys.argv[sys.argv.index('--out') + 1] if '--out' in sys.argv else os.path.join(HERE, '..', 'html', 'symmetry_breaking_note.html')
    page = build()
    open(out, 'w', encoding='utf-8').write(page)
    print('wrote', out, len(page), 'bytes')
