# Division algebraic symmetry breaking and the Atlas: a note

Shipped in the web-app package as `reports/note/` (this folder) with the built page in `../html/symmetry_breaking_note.html`. The note is a single self-contained page that opens offline (light and dark, readable at 375 px), written to be sent as a link: figures first, then the words and the equations. It is not one of the six reports: it has no zip, no entry in `../html/index.json` and no line in the For researchers page. The build copies the page to `dist/reports/html/` with the reports, so on a site that serves the package it is at `reports/html/symmetry_breaking_note.html`.

The note shows the division-algebraic cascade of Furey (the reflections of the 45 generators of Spin(10)) as it stands in her latest papers, 2022 to 2026, next to the Atlas's reading: the Spin(10) line 45, 21, 15, 11, 10 (Roadmap I, Fig. 4) with the centre and the simple ideals of each stage, the SU(5) line 24, 12, 10, 9 (Roadmap I, Fig. 5), the charges B−L, Y and Q on the generators, the same cascade in four voices (Furey's, the Atlas's, Schuller's, the category theorist's), the algebra of the talk of Furey and Hughes at the Perimeter Institute (15 March 2021, PIRSA 21030013, 67 slides) rebuilt from the octonion table, four questions, and what the note does not show. The starting point is the talk; the model that the note states is that of the papers.

## Files
- `../html/symmetry_breaking_note.html`: the note (one self-contained file; three figures drawn in SVG, with the five status icons of the Atlas; no external request).
- `symmetry_note_check.py`: 15 checks `M0` to `M14` (about 20 s; Python 3 and numpy only). It builds the octonions from the seven triples (1,2,4) (2,3,5) (3,4,6) (4,5,7) (5,6,1) (6,7,2) (7,1,3), the algebra ℂ⊗ℍ⊗𝕆 as 32 complex dimensions, and recomputes: the normed division algebras, the left and right multiplications and the Clifford algebra they span, so(10) and its commutant sl(2,ℂ), the triality algebras of dimensions 0, 2, 9, 28 and the quaternionic triality and Yukawa forms, the cascade as four conditions on the 45 generators with the dimension, centre and simple ideals of each stage and the charges, the representation content (4,2,1;2,1) + (4̄,1,2;2,1), the bidoublet Higgs, and the sign rules of the bit labels. Log lines are `ok   M<n> <text>`, `info M13 <text>` for the one line that is arithmetic and not a check, and `ALL SLIDE CHECKS PASS (14 check functions; M0-M14)` at the end. `--sabotage K` (K = 1 to 8) runs one broken ingredient and `--selftest` runs all eight and prints where each stops.
- `build_note.py`: builds the page from the two logs, the Furey report's logs (`../furey/logs/`), the chip module and the style sheet of `../furey/`. It asserts every number that a figure uses against the logs before it writes the page. `--out FILE` writes elsewhere.
- `logs/symmetry_note_check.log`, `logs/symmetry_note_check_sabotage.log`: the output of the check script and of its eight broken variants (each exits 1, at a named check).
- `../furey/`: the Atlas checks of the same cascade (`furey_papers_check.py`: R7 the Spin(10) line by dimension, R8 and R9 the SU(5) line, R11 the charges; `furey_construction_check.py`: B12 the count of complete generations) are read from there, not repeated.
- `test_note.mjs` (package root): the data test of this folder.

## Rerun

    python3 reports/note/symmetry_note_check.py > reports/note/logs/symmetry_note_check.log
    python3 reports/note/symmetry_note_check.py --selftest > reports/note/logs/symmetry_note_check_sabotage.log
    python3 reports/note/build_note.py          # writes reports/html/symmetry_breaking_note.html
    python3 reports/make_package.py             # manifest
    node test_note.mjs

## Honest status
- Every statement tagged checked is recomputed by `symmetry_note_check.py` or by a script of `../furey/` that the line names. The numerical checks use floating point with a tolerance of 1e-9; dimensions, centres and ideals are integers.
- The cascade is read as four conditions on the 45 generators, one per division-algebraic reflection: commute with L_e7, commute with R_e7, commute with L_ε3 on the 16 of Spin(10), equal to the complex conjugate. That reading is an input, stated on the page, and it is the Atlas's reading of Roadmap I, Fig. 4; the Roadmap is Furey's alone. The name "W± out" for the stage of dimension 11 is the Atlas's.
- The SU(5) line is shown from the Atlas check of Roadmap I, Fig. 5 (dimensions, with the named algebras); its centres and ideals are not recomputed here.
- The counts of complete generations of the Furey report are quoted with their conventions apart: B12 counts, over the 5,582 admissible block structures of complex dimension 8, the linear off-diagonal and the antilinear operators of End_ℝ(V); N2 counts complete sets in linear cells only. The note does not compare the two.
- One info line (M13, slides 54 and 55) is arithmetic: the octonionic colour split of the inner product and the simultaneous H and O conjugation of the tilde are not computed. A Superalgebra Within (2025) has not been read.
- The cascade of the Roadmap is not compared with the Standard Model algebra of the Trialities paper; the note puts that comparison as question 2.
- The note changes no statement of the web app. No address of any person is in any file.
