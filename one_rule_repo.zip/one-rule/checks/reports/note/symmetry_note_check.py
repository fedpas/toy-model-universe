#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Checks of the algebra of the talk "Division algebraic symmetry breaking"
(N. Furey with M. J. Hughes, Perimeter Institute, pirsa.org/21030013, 15 March 2021;
the page numbers in the output are those of its 67-page PDF) and of the cascade of Roadmap I Fig. 4.

Standalone: Python 3 and numpy only.  It builds the octonions from the seven triples
(1,2,4) (2,3,5) (3,4,6) (4,5,7) (5,6,1) (6,7,2) (7,1,3), the quaternions e1 e2 = e3, and the
algebra C x H x O as 32 complex dimensions (the quaternion factor first, the octonion factor
second), and recomputes the numbers the slides print.  Output: one line `ok   Mn text` per
check, `info Mn text` for lines that are not checks, `ALL ... PASS` at the end.

    python3 symmetry_note_check.py                 # about 20 seconds
    python3 symmetry_note_check.py --sabotage K    # K = 1..8: one wrong ingredient, must stop at a named check
    python3 symmetry_note_check.py --selftest      # runs the eight sabotage variants and reports where each stops

What is an input here and not a computation: the cascade is read as four conditions on the 45
generators, one per division-algebraic reflection, as in Roadmap I Fig. 4 and the Atlas check R7
(commute with L_e7; commute with R_e7; commute with L_eps3 on the 16 of Spin(10); equal to the
complex conjugate).  M10 states them and prints what they give.
"""
import os
import subprocess
import sys

import numpy as np

SAB = 0
if '--sabotage' in sys.argv:
    SAB = int(sys.argv[sys.argv.index('--sabotage') + 1])
rng = np.random.default_rng(20210315)
TOL = 1e-9
LINES = []


def ok(tag, text):
    print('ok   %s %s' % (tag, text))
    sys.stdout.flush()


def info(tag, text):
    print('info %s %s' % (tag, text))
    sys.stdout.flush()


# ----------------------------------------------------------------------------- the algebras
TRIP = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
if SAB == 1:
    TRIP[2] = (3, 4, 5)           # two triples share the pair (4, 5): not the octonions


def structure_tensor(trip, n):
    """t[a, b, c] with e_a e_b = sum_c t[a, b, c] e_c, units 1..n-1 imaginary, unit 0 = 1."""
    t = np.zeros((n, n, n))
    for a in range(n):
        t[0, a, a] = 1
        t[a, 0, a] = 1
    for a in range(1, n):
        t[a, a, 0] = -1
    for (i, j, k) in trip:
        for (a, b, c) in [(i, j, k), (j, k, i), (k, i, j)]:
            t[a, b, c] = 1
            t[b, a, c] = -1
    return t


TO = structure_tensor(TRIP, 8)                      # octonions
TH = structure_tensor([(1, 2, 3)], 4)               # quaternions e1 e2 = e3
TC = structure_tensor([], 2)                        # complex numbers
TR = structure_tensor([], 1)                        # reals


def left_right(t):
    n = t.shape[0]
    L = np.array([t[a].T for a in range(n)])        # L[a][c, b] = t[a, b, c]  (e_a e_b -> e_c)
    R = np.array([t[:, a, :].T for a in range(n)])  # R[a][c, b] = t[b, a, c]  (e_b e_a -> e_c)
    return L, R


LO, RO = left_right(TO)
LH, RH = left_right(TH)
I4, I8 = np.eye(4), np.eye(8)
Le = lambda a: np.kron(I4, LO[a]).astype(complex)       # left multiplication by e_a  (a = 1..7)
Re = lambda a: np.kron(I4, RO[a]).astype(complex)       # right multiplication by e_a
Lq = lambda m: np.kron(LH[m], I8).astype(complex)       # left multiplication by eps_m (m = 1..3)
Rq = lambda m: np.kron(RH[m], I8).astype(complex)       # right multiplication by eps_m
ID = np.eye(32, dtype=complex)


def rank(M, tol=TOL):
    return int(np.linalg.matrix_rank(M, tol=tol))


def vec(M):
    return np.concatenate([np.real(M).ravel(), np.imag(M).ravel()])


# ----------------------------------------------------------------------------- Lie algebra tools
def lie_structure(mats):
    d = len(mats)
    V = np.array([vec(M) for M in mats]).T
    assert rank(V) == d, 'generators are not independent'
    P = np.linalg.pinv(V)
    f = np.zeros((d, d, d))
    for i in range(d):
        for j in range(i + 1, d):
            c = vec(mats[i] @ mats[j] - mats[j] @ mats[i])
            x = P @ c
            assert np.allclose(V @ x, c, atol=1e-8), 'not closed under the commutator'
            f[i, j] = x
            f[j, i] = -x
    return f


def commutant_real(As, m):
    """Real m x m matrices Y with A Y = Y A for all A in As: returns an orthonormal basis (list of m x m)."""
    G = np.zeros((m * m, m * m))
    for A in As:
        T = np.kron(np.eye(m), A) - np.kron(A.T, np.eye(m))
        G += T.T @ T
    w, U = np.linalg.eigh(G)
    k = int((w < 1e-9).sum())
    return [U[:, i].reshape(m, m, order='F') for i in range(k)]


def analyse(mats):
    """(dimension, centre, derived algebra, sizes of the simple ideals of the derived algebra)."""
    d = len(mats)
    f = lie_structure(mats)
    ad = np.transpose(f, (0, 2, 1))                          # ad[i][k, j] = f[i, j, k]
    K = np.einsum('ikj,ljk->il', ad, ad)
    centre = d - rank(f.reshape(d, d * d).T)
    der = rank(f.reshape(d * d, d))
    if der == 0:
        return d, centre, 0, []
    u, s, vt = np.linalg.svd(f.reshape(d * d, d), full_matrices=False)
    Q = vt[:der].T                                           # d x der, basis of [g, g]
    Ks = Q.T @ K @ Q
    assert np.all(np.linalg.eigvalsh(Ks) < -1e-9), 'Killing form of [g,g] is not negative definite'
    Lc = np.linalg.cholesky(-Ks)
    Qk = Q @ np.linalg.inv(Lc).T                             # -Killing-orthonormal basis of [g, g]
    Qp = np.linalg.pinv(Qk)
    Rs = [Qp @ ad[i] @ Qk for i in range(d)]
    for R in Rs:
        assert np.allclose(R, -R.T, atol=1e-8)
    As = [sum(rng.normal() * R for R in Rs) for _ in range(4)]
    Ys = commutant_real(As, der)
    Y = sum(rng.normal() * (Yk + Yk.T) / 2 for Yk in Ys)
    ev = np.sort(np.linalg.eigvalsh(Y))
    sizes, cur = [], 1
    for a, b in zip(ev[:-1], ev[1:]):
        if b - a < 1e-6:
            cur += 1
        else:
            sizes.append(cur)
            cur = 1
    sizes.append(cur)
    assert len(sizes) == len(Ys), (sizes, len(Ys))
    return d, centre, der, sorted(sizes, reverse=True)


def null_coeffs(A):
    """Real null space (rows) of the real matrix A (columns = unknown coefficients)."""
    u, s, vt = np.linalg.svd(A)
    r = int((s > 1e-9).sum())
    return vt[r:]


# ============================================================================= M0, M1, M2: the octonions, quaternions, Cl(0,6)
def check_M0():
    for _ in range(50):
        x, y = rng.normal(size=8), rng.normal(size=8)
        prod = np.einsum('a,b,abc->c', x, y, TO)
        assert abs(np.linalg.norm(prod) - np.linalg.norm(x) * np.linalg.norm(y)) < 1e-9
    for a in range(1, 8):
        assert np.allclose(LO[a] @ LO[a], -np.eye(8))
    ok('M0', 'the multiplication table is a normed division algebra: |xy| = |x||y| for 50 random pairs, and the seven imaginary units square to -1 (p. 38-39, K = R, C, H, O; the units are the seven triples of the Atlas)')


def check_M1():
    L = [None] + [LO[a] for a in range(1, 7)]
    for a in range(1, 7):
        for b in range(a + 1, 7):
            assert np.allclose(L[a] @ L[b], -L[b] @ L[a])
    mons = []
    for mask in range(64):
        M = np.eye(8)
        for a in range(6):
            if mask >> a & 1:
                M = M @ L[a + 1]
        mons.append(M.ravel())
    assert rank(np.array(mons)) == 64
    assert np.allclose(L[1] @ L[2] @ L[3] @ L[4] @ L[5] @ L[6], LO[7])
    # slide 10: a product of the six left multiplications omitting one index j7 is plus or minus L_{j7}
    for omit in range(1, 8):
        P = np.eye(8)
        for a in range(1, 8):
            if a != omit:
                P = P @ LO[a]
        assert np.allclose(P, LO[omit]) or np.allclose(P, -LO[omit]), omit
    ok('M1', 'p. 10, 13, 14: the left multiplications by e1..e6 anticommute and square to -1; their 64 products are linearly independent, so they span M8(R) = Cl(0,6); L_e1 L_e2 ... L_e6 = L_e7; every product of six distinct L_ej is plus or minus the L of the omitted index (the diamond of slide 10)')


def check_M2():
    R7 = 0.5 * (-LO[7] + LO[1] @ LO[3] + LO[2] @ LO[6] + LO[4] @ LO[5])
    if SAB == 2:
        R7 = 0.5 * (+LO[7] + LO[1] @ LO[3] + LO[2] @ LO[6] + LO[4] @ LO[5])
    assert np.allclose(R7, RO[7])
    # the printed formula for any of the seven units, on the lines through that unit
    mons = []
    L = [None] + [LO[a] for a in range(1, 7)]
    for mask in range(64):
        M = np.eye(8)
        for a in range(6):
            if mask >> a & 1:
                M = M @ L[a + 1]
        mons.append(M.ravel())
    mons = np.array(mons)
    for a in range(1, 8):
        assert rank(np.vstack([mons, RO[a].ravel()])) == 64
    # quaternions: left and right multiplications are two commuting copies of Cl(0,2); right is not in the span of left
    LQ = [np.eye(4), LH[1], LH[2], LH[1] @ LH[2]]
    assert rank(np.array([m.ravel() for m in LQ])) == 4
    assert rank(np.array([m.ravel() for m in LQ] + [RH[3].ravel()])) == 5
    for m in range(1, 4):
        for n in range(1, 4):
            assert np.allclose(LH[m] @ RH[n], RH[n] @ LH[m])
    prods = [np.linalg.matrix_power(LH[1], i) @ np.linalg.matrix_power(LH[2], j) @ np.linalg.matrix_power(RH[1], k) @ np.linalg.matrix_power(RH[2], l)
             for i in (0, 1) for j in (0, 1) for k in (0, 1) for l in (0, 1)]
    assert rank(np.array([p.ravel() for p in prods])) == 16
    # complex numbers: left and right multiplication by i coincide
    LC, RC = left_right(TC)
    assert np.allclose(LC[1], RC[1])
    ok('M2', 'p. 11, 14: right multiplication by e7 is 1/2(-L_e7 + L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5), and every right multiplication lies in the algebra of the left ones (L mult ~ R mult: yes for O); for H the right multiplication eps3 is not in the 4-dimensional left algebra and left and right commute and together span M4(R) (16 dimensions: no); for C they coincide (yes)')


# ============================================================================= the 45 generators
def build_basis():
    basis = []
    for a in range(1, 8):
        for b in range(a + 1, 8):
            basis.append(Le(a) @ Le(b))
    for m in range(1, 4):
        for n in range(m + 1, 4):
            basis.append(Lq(m) @ Lq(n))
    for m in range(1, 4):
        for a in range(1, 8):
            basis.append((1j if SAB != 6 else 1) * Lq(m) @ Le(a))
    assert len(basis) == 45
    return basis


BASIS = build_basis()
BVEC = np.array([vec(B) for B in BASIS]).T                # 2048 x 45


def in_span(mats, tol=1e-8):
    V = np.array([vec(M) for M in mats]).T
    return np.linalg.matrix_rank(np.hstack([BVEC, V]), tol=tol) == 45


def check_M3():
    for B in BASIS:
        assert np.allclose(B.conj().T, -B), 'generator is not anti-Hermitian'
    f = lie_structure(BASIS)
    d, centre, der, ideals = analyse(BASIS)
    assert (d, centre, der, ideals) == (45, 0, 45, [45]), (d, centre, der, ideals)
    # decomposition so(10) = so(7) + so(3) + Im(O) x Im(H)   (p. 43)
    so7, so3, mix = list(range(0, 21)), list(range(21, 24)), list(range(24, 45))
    sub = lambda idx: [BASIS[i] for i in idx]
    lie_structure(sub(so7 + so3))
    for i in so7:
        for j in so3:
            assert np.allclose(BASIS[i] @ BASIS[j], BASIS[j] @ BASIS[i])
    for i in so7 + so3:
        for j in mix:
            c = vec(BASIS[i] @ BASIS[j] - BASIS[j] @ BASIS[i])
            x = np.linalg.pinv(BVEC) @ c
            assert np.allclose(BVEC @ x, c, atol=1e-8)
            assert np.allclose(x[so7 + so3], 0, atol=1e-8)
    for i in mix:
        for j in mix:
            c = vec(BASIS[i] @ BASIS[j] - BASIS[j] @ BASIS[i])
            x = np.linalg.pinv(BVEC) @ c
            assert np.allclose(x[mix], 0, atol=1e-8)
    ok('M3', 'p. 21, 23, 43: the 45 operators L_ea L_eb (a<b<=7), L_eps_m L_eps_n, i L_eps_m L_ea are anti-Hermitian, close under the commutator, have trivial centre, negative-definite Killing form and one simple ideal of dimension 45: so(10); and so(10) = so(7)+so(3) (21+3) plus Im(O) x Im(H) (21), with [so(7), so(3)] = 0 and the 21 a module for both')


def commutant_complex(gens, tol=1e-9):
    """Complex null space of X -> [G, X] for G in gens, as a list of 32 x 32 matrices (Gram method)."""
    n = gens[0].shape[0]
    Gm = np.zeros((n * n, n * n), dtype=complex)
    I = np.eye(n)
    for G in gens:
        T = np.kron(I, G) - np.kron(G.T, I)
        Gm += T.conj().T @ T
    w, U = np.linalg.eigh(Gm)
    k = int((w < tol).sum())
    return [U[:, i].reshape(n, n, order='F') for i in range(k)]


def check_M4():
    C = commutant_complex(BASIS)
    assert len(C) == 4, len(C)
    R = [ID, Rq(1), Rq(2), Rq(3)]
    for X in R:
        assert all(np.allclose(X @ B, B @ X) for B in BASIS)
    allm = np.array([X.ravel() for X in C] + [X.ravel() for X in R])
    assert rank(allm) == 4
    ok('M4', 'p. 43, 45, 46: the complex commutant of the 45 generators in M32(C) has dimension 4 and equals the span of 1, R_eps1, R_eps2, R_eps3 (right multiplications by the quaternion units), i.e. M2(C): C^32 is two equivalent copies of one 16-dimensional irreducible representation of so(10), (16; 2) of so(10) + sl(2,C)')


def check_M5():
    R = [Rq(1), Rq(2), Rq(3)]
    if SAB == 5:
        R = [Lq(1), Lq(2), Lq(3)]
    assert np.allclose(R[0] @ R[1] - R[1] @ R[0], -2 * R[2]) or np.allclose(R[0] @ R[1] - R[1] @ R[0], 2 * R[2])
    for X in R:
        assert all(np.allclose(X @ B, B @ X) for B in BASIS), 'does not commute with so(10)'
    real6 = R + [1j * X for X in R]
    f = lie_structure(real6)
    ad = np.transpose(f, (0, 2, 1))
    K = np.einsum('ikj,ljk->il', ad, ad)
    ev = np.linalg.eigvalsh(K)
    assert (ev > 1e-9).sum() == 3 and (ev < -1e-9).sum() == 3          # Killing form of so(3,1) = sl(2,C): signature (3,3)
    assert 6 - rank(f.reshape(6, 36).T) == 0 and rank(f.reshape(36, 6)) == 6   # no centre, perfect
    Cm = commutant_real([sum(rng.normal() * a for a in ad) for _ in range(4)], 6)
    assert len(Cm) == 2                                                 # adjoint commutant = C: simple, with a complex structure
    d3, c3, der3, id3 = analyse(R)
    assert (d3, c3, der3, id3) == (3, 0, 3, [3])
    ok('M5', 'p. 46, 50: right multiplication by C x Im(H), the real span of R_eps_m and i R_eps_m, is a 6-dimensional real Lie algebra, perfect, with trivial centre, Killing form of signature (3,3) and adjoint commutant C: sl(2,C) = so(3,1) as a simple real algebra; it commutes with so(10); the R_eps_m alone are the compact su(2)_spin (3 dimensions)')


def check_M6():
    # complex Clifford algebra of slide 17 and 34: the left multiplications by C x O together with left and right by H generate M32(C)
    prods = []
    L = [None] + [LO[a] for a in range(1, 7)]
    for mask in range(64):
        M = np.eye(8)
        for a in range(6):
            if mask >> a & 1:
                M = M @ L[a + 1]
        for k in range(16):
            Hm = np.eye(4)
            if k & 1:
                Hm = Hm @ LH[1]
            if k & 2:
                Hm = Hm @ LH[2]
            if k & 4:
                Hm = Hm @ RH[1]
            if k & 8:
                Hm = Hm @ RH[2]
            prods.append(np.kron(Hm, M).ravel())
    assert rank(np.array(prods)) == 1024
    ok('M6', 'p. 17, 34: the products of the left multiplications by e1..e6 with the left and right multiplications by the quaternion units span 64 x 16 = 1024 = 2^10 dimensions over C, i.e. all of M32(C) = the complex Clifford algebra Cl(10) (the Atlas check A4 of the Furey report builds the ten gamma matrices of Roadmap I eq. 25 and checks the anticommutation)')


# ============================================================================= triality (p. 38-42)
def triality_dim(t):
    n = t.shape[0]
    if n == 1:
        return 0, 0, []
    gens = []
    for p in range(n):
        for q in range(p + 1, n):
            E = np.zeros((n, n))
            E[p, q], E[q, p] = 1, -1
            gens.append(E)
    cols = []
    for slot in range(3):
        for E in gens:
            if slot == 0:
                T = np.einsum('ijk,il->ljk', t, E)
            elif slot == 1:
                T = np.einsum('ijk,jm->imk', t, E)
            else:
                T = np.einsum('ijk,kn->ijn', t, E)
            cols.append(T.ravel())
    A = np.array(cols).T
    N = null_coeffs(A)
    g = len(gens)
    rankA = rank(N[:, :g]) if len(N) else 0
    return len(N), rankA, N


def check_M7():
    dims = []
    for name, t in (('R', TR), ('C', TC), ('H', TH), ('O', TO)):
        tri, proj, N = triality_dim(t)
        dims.append((name, tri, proj))
    assert dims == [('R', 0, 0), ('C', 2, 1), ('H', 9, 6), ('O', 28, 28)], dims
    # tri(H) is su(2)+su(2)+su(2) (p. 40, 42): three commuting-by-blocks copies, read as 12 x 12 matrices
    tri, proj, N = triality_dim(TH)
    gens = []
    for p in range(4):
        for q in range(p + 1, 4):
            E = np.zeros((4, 4))
            E[p, q], E[q, p] = 1, -1
            gens.append(E)
    mats = []
    for row in N:
        M = np.zeros((12, 12), dtype=complex)
        for s_ in range(3):
            M[4 * s_:4 * s_ + 4, 4 * s_:4 * s_ + 4] = sum(c * E for c, E in zip(row[s_ * 6:(s_ + 1) * 6], gens))
        mats.append(M)
    d, centre, der, ideals = analyse(mats)
    assert (d, centre, der, ideals) == (9, 0, 9, [3, 3, 3]), (d, centre, der, ideals)
    ok('M7', 'p. 40, 41: the dimensions of the triality algebras tri(K) = {(A,B,C) in so(dim K)^3 : t(Av,psi,chi) + t(v,B psi,chi) + t(v,psi,C chi) = 0} are 0, 2, 9, 28 for K = R, C, H, O, with images in the first so(dim K) of dimensions 0, 1, 6, 28 (so(1), so(2), so(4), so(8)) and extra parts 0, u(1), su(2), 0; tri(H) is semisimple with three ideals (su(2) + su(2) + su(2))')


def qmul(a, b):
    return np.einsum('a,b,abc->c', a, b, TH)


def qconj(a):
    return np.array([a[0], -a[1], -a[2], -a[3]])


def im(m):
    return np.array([0.0] + list(m))


def check_M8():
    # p. 42: the three representations of the quaternionic triality and the Yukawa-type invariant (p. 54)
    sgn = -1 if SAB == 7 else 1
    for _ in range(20):
        v, psi, chi = rng.normal(size=4), rng.normal(size=4), rng.normal(size=4)
        th1, th2, th3 = im(rng.normal(size=3)), im(rng.normal(size=3)), im(rng.normal(size=3))
        T = lambda v_, p_, c_: np.dot(c_, qmul(v_, p_))               # <chi* v psi> = chi_c t_abc v_a psi_b
        dv = qmul(th1, v) - qmul(v, th2)
        dpsi = qmul(th2, psi) + sgn * qmul(psi, th3)
        dchi = qmul(th1, chi) + qmul(chi, th3)
        dT = T(dv, psi, chi) + T(v, dpsi, chi) + T(v, psi, dchi)
        assert abs(dT) < 1e-9, dT
    # which theta's act on which field: v on (theta1, theta2), psi on (theta2, theta3), chi on (theta1, theta3)
    # p. 49-55: psi+ ~ (L; spin), psi- ~ (R; spin), h ~ (L, R): <psi+~ h psi-> is invariant
    for _ in range(20):
        pp, h, pm = rng.normal(size=4), rng.normal(size=4), rng.normal(size=4)
        thL, thR, thS = im(rng.normal(size=3)), im(rng.normal(size=3)), im(rng.normal(size=3))
        Y = lambda a, b, c: qmul(qmul(qconj(a), b), c)[0]
        dpp = qmul(thL, pp) + qmul(pp, thS)
        dpm = qmul(thR, pm) + qmul(pm, thS)
        dh = qmul(thL, h) - qmul(h, thR)
        dY = Y(dpp, h, pm) + Y(pp, dh, pm) + Y(pp, h, dpm)
        assert abs(dY) < 1e-9, dY
    ok('M8', 'p. 42, 54: with theta_i in Im(H), delta v = th1 v - v th2, delta psi = th2 psi + psi th3, delta chi = th1 chi + chi th3 leave <chi* v psi> invariant (20 random draws); and the Yukawa form <psi+~ h psi-> with delta psi+ = thL psi+ + psi+ thS, delta psi- = thR psi- + psi- thS, delta h = thL h - h thR is invariant: h is a bidoublet (1,2,2;1) of g_PS + su(2)_spin, scalar under su(2)_spin')


# ============================================================================= the cascade (p. 27-31, 49-50)
L7, R7 = Le(7), Re(7)
L3q = Lq(3)
PLUS, MINUS = 0.5 * (ID + 1j * L7), 0.5 * (ID - 1j * L7)       # the two halves of C^32, eigenspaces of i L_e7 (psi+, psi-)
CHIR = 0.5 * (ID - 1j * Rq(3))                                  # the chirality of Spin(10) used in the Roadmap papers (Atlas: P_L)


def sub_by(conds):
    """Subalgebra of the 45: coefficients c with every condition(sum c_k B_k) = 0 (real-linear)."""
    cols = []
    for B in BASIS:
        cols.append(np.concatenate([np.concatenate([np.real(c(B)).ravel(), np.imag(c(B)).ravel()]) for c in conds]))
    A = np.array(cols).T
    N = null_coeffs(A)
    return [sum(c * B for c, B in zip(row, BASIS)) for row in N]


cO = lambda M: M @ L7 - L7 @ M
cOr = lambda M: M @ R7 - R7 @ M
cC = lambda M: M - M.conj()
cH_on = lambda P: (lambda M: (M @ L3q - L3q @ M) @ P)


def check_M9():
    # the new basis of slide 23 spans the same 45 dimensions as the old one of slide 21
    new = []
    for a in range(1, 7):
        for b in range(a + 1, 7):
            new.append(Le(a) @ Le(b))
    for n in range(1, 4):
        new.append(PLUS @ Lq(n))
        new.append(MINUS @ Lq(n))
    for n in range(1, 4):
        for a in range(1, 7):
            new.append(1j * Lq(n) @ Le(a))
    for a in range(1, 7):
        new.append(Le(a) @ Le(7))
    assert len(new) == 45 and in_span(new) and rank(np.array([vec(M) for M in new]), 1e-8) == 45
    # slide 27: the part that commutes with e7 is r_ij e_i e_j (i,j <= 6) + r_n P_L eps_n + r'_n P_R eps_n
    ps = sub_by([cO])
    mine = [Le(a) @ Le(b) for a in range(1, 7) for b in range(a + 1, 7)] + [PLUS @ Lq(n) for n in range(1, 4)] + [MINUS @ Lq(n) for n in range(1, 4)]
    assert len(ps) == 21 and in_span(mine)
    Vps = np.array([vec(M) for M in ps]).T
    assert rank(np.hstack([Vps, np.array([vec(M) for M in mine]).T])) == 21
    ok('M9', 'p. 21, 23, 27: the 45 generators can be written as 15 L_ei L_ej (i,j<=6) + 3 P_L L_eps_n + 3 P_R L_eps_n + 18 i L_eps_n L_ei (i<=6) + 6 L_ei L_e7, with P_L, P_R the two eigenspaces of i L_e7; those that commute with L_e7 are exactly the 15 + 3 + 3 = 21 of the Pati-Salam line of slide 27')


def check_M10():
    # Roadmap I Fig. 4, the Spin(10) line (Atlas check R7): four reflections, each a condition on the 45 generators
    #   O: commute with L_e7;  Or: commute with R_e7;  H: commute with L_eps3 (on the 16 of Spin(10));  C: equal to the complex conjugate
    g45 = BASIS
    g21 = sub_by([cO])
    g15 = sub_by([cO, cOr])
    if SAB == 3:
        g11 = g15                                        # the quaternionic step left out
    else:
        g11 = sub_by([cO, cOr, cH_on(CHIR)])
    g10 = sub_by([cO, cOr, cH_on(CHIR), cC]) if SAB != 4 else g11
    want = [(45, 0, 45, [45]), (21, 0, 21, [15, 3, 3]), (15, 1, 14, [8, 3, 3]), (11, 3, 8, [8]), (10, 2, 8, [8])]
    got = [analyse(g) for g in (g45, g21, g15, g11, g10)]
    for w, g in zip(want, got):
        assert tuple(w) == tuple(g), (w, g)
    # the Lie algebras are the named ones: u(3) in so(6), the two T3 of the quaternionic part, their sum
    so6_part = [Le(a) @ Le(b) for a in range(1, 7) for b in range(a + 1, 7)]
    u3_of_so6 = []
    A = np.array([np.concatenate([np.real(cOr(B)).ravel(), np.imag(cOr(B)).ravel()]) for B in so6_part]).T
    for row in null_coeffs(A):
        u3_of_so6.append(sum(c * B for c, B in zip(row, so6_part)))
    assert len(u3_of_so6) == 9
    named11 = u3_of_so6 + [PLUS @ Lq(3), MINUS @ Lq(3)]
    V11 = np.array([vec(M) for M in g11]).T
    N11 = np.array([vec(M) for M in named11]).T
    assert rank(N11) == 11 and rank(np.hstack([V11, N11])) == 11
    named10 = u3_of_so6 + [Lq(3)]
    S10 = np.array([vec(M) for M in g10]).T
    N10 = np.array([vec(M) for M in named10]).T
    assert rank(N10) == 10 and rank(np.hstack([S10, N10])) == 10
    # the charges of the Atlas check R11 as combinations of J, P_+ L_eps3, P_- L_eps3 (anti-Hermitian generators)
    J = Le(1) @ Le(3) + Le(2) @ Le(6) + Le(4) @ Le(5)
    T3L, T3R = -0.5 * PLUS @ Lq(3), -0.5 * MINUS @ Lq(3)
    BmL = J / 3
    Yc = T3R + BmL / 2
    Qc = T3L + Yc
    in_span = lambda M, V: rank(np.hstack([V, vec(M)[:, None]])) == rank(V)
    assert all(in_span(X, V11) for X in (Yc, Qc, BmL))
    assert in_span(Qc, S10) and in_span(BmL, S10) and not in_span(Yc, S10)
    ok('M10', 'Roadmap I Fig. 4, the Spin(10) line (the Atlas check R7), as four conditions on the 45 generators (commute with L_e7; commute with R_e7; commute with L_eps3 on the 16 of Spin(10); equal to the complex conjugate): 45 -> 21 (so(6)+su(2)+su(2)) -> 15 (u(3)+su(2)+su(2)) -> 11 (u(3)+u(1)+u(1): the quaternionic condition keeps P_+ L_eps3 and P_- L_eps3, the two T3) -> 10 (u(3)+u(1): the extra u(1) is L_eps3, the sum of the two T3); each stage is a Lie algebra with the dimension, centre and simple ideals (45, 0, [45]), (21, 0, [15,3,3]), (15, 1, [8,3,3]), (11, 3, [8]), (10, 2, [8]); the charges of the Atlas check R11 (B-L = J/3, Y = T3R + (B-L)/2, Q = T3L + Y) lie in the 11; Q and B-L lie in the 10, Y does not')


def check_M11():
    g = sub_by([cO])
    # psi+ and psi-: the two halves, 16 complex dimensions each
    for P in (PLUS, MINUS):
        assert rank(P) == 16 and np.allclose(P @ P, P)
    # orthonormal bases of the two halves
    def half(P):
        u, s, vt = np.linalg.svd(P)
        return u[:, :16]
    Up, Um = half(PLUS), half(MINUS)
    so6 = [Le(a) @ Le(b) for a in range(1, 7) for b in range(a + 1, 7)]
    sl2 = [Rq(1), Rq(2), Rq(3)]
    JL = [PLUS @ Lq(n) for n in range(1, 4)]
    JR = [MINUS @ Lq(n) for n in range(1, 4)]
    for X in so6 + JL + JR + sl2:
        assert np.allclose(X @ PLUS, PLUS @ X) and np.allclose(X @ MINUS, MINUS @ X)
    res = {}
    for name, U in (('+', Up), ('-', Um)):
        gens = [U.conj().T @ X @ U for X in so6 + JL + JR + sl2]
        C = commutant_complex(gens)
        assert len(C) == 1                                     # irreducible under g_PS + sl(2,C)
        Js = JL if name == '+' else JR
        Cm = commutant_complex([U.conj().T @ X @ U for X in Js + sl2])
        assert len(Cm) == 16                                   # (2; 2) with multiplicity space of dimension 4
        cas = lambda Js: -sum((0.5 * U.conj().T @ J @ U) @ (0.5 * U.conj().T @ J @ U) for J in Js)
        cL, cR, cS = cas(JL), cas(JR), cas(sl2)
        res[name] = (cL[0, 0].real, cR[0, 0].real, cS[0, 0].real)
        for c, v in ((cL, res[name][0]), (cR, res[name][1]), (cS, res[name][2])):
            assert np.allclose(c, v * np.eye(16), atol=1e-9)
    assert np.allclose(res['+'], (0.75, 0.0, 0.75)) and np.allclose(res['-'], (0.0, 0.75, 0.75)), res
    # 4 against 4-bar: the character of so(6) on psi- is the complex conjugate of that on psi+ and the two differ
    X = sum(rng.normal() * M for M in so6)
    w, V = np.linalg.eig(X)
    expX = (V * np.exp(w)) @ np.linalg.inv(V)
    tp = np.trace(Up.conj().T @ expX @ Up)
    tm = np.trace(Um.conj().T @ expX @ Um)
    assert abs(tm - np.conj(tp)) < 1e-9 and abs(tp - tm) > 0.1, (tp, tm)
    ok('M11', 'p. 49, 50: C^32 = psi+ + psi-, each of complex dimension 16 and irreducible under g_PS + sl(2,C); su(2)_L (= P_L L_eps) has Casimir j(j+1) = 3/4 on psi+ and 0 on psi-, su(2)_R the reverse, su(2)_spin (right multiplication) 3/4 on both; the character of so(6) on psi- is the complex conjugate of that on psi+ and differs from it (a random element: %.3f%+.3fi against %.3f%+.3fi): (4,2,1;2,1) + (4bar,1,2;2,1)' % (tp.real, tp.imag, tm.real, tm.imag))
    # tri(H) = su(2)_L + su(2)_R + su(2)_spin inside g_PS + sl(2,C)
    d, centre, der, ideals = analyse(JL + JR + sl2)
    assert (d, centre, der, ideals) == (9, 0, 9, [3, 3, 3]), (d, centre, der, ideals)
    ok('M12', 'p. 50: su(2)_L + su(2)_R + su(2)_spin (the real spans of P_L L_eps, P_R L_eps, R_eps) form a 9-dimensional semisimple algebra with three simple ideals of dimension 3, the algebra tri(H) of M7, inside g_PS + sl(2,C); on psi+ the multiplicity space of (2_L; 2_spin) has dimension 4, on psi- of (2_R; 2_spin) also 4: "4 lots" of (2,1;2) and (1,2;2)')


def check_M13():
    # p. 52-53: the Higgs h in H: 4 real degrees of freedom, a bidoublet of su(2)_L x su(2)_R, one complex doublet after the breaking to u(1)_Y
    LL = [LH[m] for m in range(1, 4)]
    RR = [RH[m] for m in range(1, 4)]
    C_full = commutant_real(LL + RR, 4)
    assert len(C_full) == 1                       # (2,2) of su(2) x su(2): real irreducible
    C_br = commutant_real(LL + [RH[3]], 4)
    assert len(C_br) == 2                         # one complex doublet
    assert np.allclose(RH[3] @ RH[3], -np.eye(4))
    ok('M13', 'p. 52, 53: h in H with delta h = th_L h - h th_R is the real irreducible (2,2) of su(2)_L + su(2)_R (commutant of dimension 1) and, with su(2)_R broken to the T3 generated by right multiplication by eps3, one complex doublet (commutant of dimension 2 = C, T3^2 = -1): 4 real degrees of freedom, the right representation for the Standard Model Higgs')
    # p. 54, 55: counting
    assert 4 * 4 == 16 and 4 * 2 == 8
    info('M13', 'p. 54, 55: 16 complex dimensions of psi+ = 4 colours A x (C x H: 4 complex); splitting the colours and the C-real/C-imaginary parts gives 4 x 2 = 8 copies of the quaternionic triality scalar: arithmetic only, the octonionic colour split of the inner product and the simultaneous H and O conjugation of the tilde are not computed here')



def check_M14():
    # The three rules of the bit-label reading (the Atlas voice of the report): each condition of the cascade is a sign rule on the 45 generators.
    labels = []
    for a in range(1, 8):
        for b in range(a + 1, 8):
            labels.append(('LL', a, b))
    for m in range(1, 4):
        for n in range(m + 1, 4):
            labels.append(('qq', m, n))
    for m in range(1, 4):
        for a in range(1, 8):
            labels.append(('qL', m, a))
    assert len(labels) == 45
    g7 = 1 if SAB == 8 else 6                               # L_e7 is the product of six generators: grade 6, even
    grade = lambda a: 1 if a <= 6 else g7
    L7i = np.linalg.inv(L7)
    L3i = np.linalg.inv(L3q)
    n_even = 0
    for B, lab in zip(BASIS, labels):
        if lab[0] == 'LL':
            par = (grade(lab[1]) + grade(lab[2])) % 2
        elif lab[0] == 'qq':
            par = 0
        else:
            par = grade(lab[2]) % 2
        s = (-1) ** par
        assert np.allclose(L7 @ B @ L7i, s * B), ('step 1 sign rule', lab)
        n_even += par == 0
        # step 3: conjugation by L_eps3 flips L_eps1 and L_eps2 and fixes L_eps3 and the octonionic factors
        if lab[0] == 'LL':
            flips = 0
        elif lab[0] == 'qq':
            flips = (lab[1] in (1, 2)) + (lab[2] in (1, 2))
        else:
            flips = lab[1] in (1, 2)
        assert np.allclose(L3q @ B @ L3i, (-1) ** flips * B), ('step 3 sign rule', lab)
    assert n_even == 21
    # step 2: the right multiplications by e1..e6 are six generators of the same kind and their product is plus or minus R_e7
    R = [None] + [Re(a) for a in range(1, 8)]
    for a in range(1, 7):
        assert np.allclose(R[a] @ R[a], -ID)
        for b in range(a + 1, 7):
            assert np.allclose(R[a] @ R[b] + R[b] @ R[a], 0)
    vol = R[1] @ R[2] @ R[3] @ R[4] @ R[5] @ R[6]
    sgn = 1 if np.allclose(vol, R[7]) else -1
    assert np.allclose(vol, sgn * R[7]) and np.allclose(R[7] @ R[7], -ID)
    # step 4: every L and R matrix is real, so complex conjugation of an operator is the involution i -> -i of the C factor
    for a in range(1, 8):
        assert np.allclose(Le(a).imag, 0) and np.allclose(Re(a).imag, 0)
    for m in range(1, 4):
        assert np.allclose(Lq(m).imag, 0) and np.allclose(Rq(m).imag, 0)
    # the pairs in R_e7 = 1/2(-L_e7 + L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5): the Fano lines through e7
    pairs = set()
    for a in range(1, 7):
        col = np.nonzero(np.abs(LO[7][:, a]) > 0.5)[0]
        assert len(col) == 1
        pairs.add(tuple(sorted((a, int(col[0])))))
    assert pairs == {(1, 3), (2, 6), (4, 5)}, pairs
    # u(3) is the centraliser of J = L1 L3 + L2 L6 + L4 L5 in the 15 bivectors, and J spans its centre (the u(1) of B-L)
    so6 = [Le(a) @ Le(b) for a in range(1, 7) for b in range(a + 1, 7)]
    J = Le(1) @ Le(3) + Le(2) @ Le(6) + Le(4) @ Le(5)
    assert np.allclose(R7 @ R7, -ID) and np.allclose(0.5 * (-L7 + J), R7)
    A = np.array([np.concatenate([np.real(J @ B - B @ J).ravel(), np.imag(J @ B - B @ J).ravel()]) for B in so6]).T
    cen = null_coeffs(A)
    assert cen.shape[0] == 9
    u3 = [sum(c * B for c, B in zip(row, so6)) for row in cen]
    Vu = np.array([vec(M) for M in u3]).T
    assert rank(np.hstack([Vu, vec(J)[:, None]])) == 9
    for M in u3:
        assert np.allclose(M @ J, J @ M)
    ok('M14', 'p. 22-31, the rules of the bit-label reading: conjugation by L_e7 multiplies each of the 45 generators by (-1) to the number of factors L_ej with j <= 6 (L_e7 is a product of six, so even): 21 even (they commute, the Pati-Salam line) and 24 odd; conjugation by L_eps3 multiplies each by (-1) to the number of factors L_eps1, L_eps2; the right multiplications R_e1..R_e6 are six anticommuting generators with R_e1...R_e6 = %sR_e7; the matrices of L and R are real, so complex conjugation of an operator is i -> -i; the pairs (1,3), (2,6), (4,5) of R_e7 are the three Fano lines through e7, and the centraliser of J = L1 L3 + L2 L6 + L4 L5 among the 15 bivectors is the 9-dimensional u(3), J spanning its centre' % ('+' if sgn == 1 else '-'))


CHECKS = [check_M0, check_M1, check_M2, check_M3, check_M4, check_M5, check_M6, check_M7, check_M8, check_M9, check_M10, check_M11, check_M13, check_M14]


def main():
    done = 0
    for c in CHECKS:
        c()
        done += 1
    print('ALL SLIDE CHECKS PASS (%d check functions; M0-M14)' % done)


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        for k in range(1, 9):
            env = dict(os.environ)
            p = subprocess.run([sys.executable, __file__, '--sabotage', str(k)], capture_output=True, text=True, env=env)
            last_ok = [l for l in p.stdout.splitlines() if l.startswith('ok')]
            where = p.stderr.strip().splitlines()[-1] if p.stderr.strip() else '(no error)'
            fn = [l.split(' in ')[-1].strip() for l in p.stderr.splitlines() if ' in check_M' in l]
            print('sabotage %d: exit %d, stopped in %s, last passing id %s, with: %s' % (k, p.returncode, fn[-1] if fn else '-', last_ok[-1].split()[1] if last_ok else '-', where[:140]))
        sys.exit(0)
    main()
