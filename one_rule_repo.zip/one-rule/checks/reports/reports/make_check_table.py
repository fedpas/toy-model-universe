#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Writes the table "check id -> one line" of selfcheck/reports/README.md from the five report scripts' own output, so that a reader can look up
an id such as cat·K5b or qm·Q10a.  Python standard library only.

    python3 make_check_table.py            reads the recorded output (the logs in reports/<report>/logs/) and rewrites the table in the README
    python3 make_check_table.py --run      runs the five scripts of selfcheck/reports/ instead (about 45 s; needs numpy, networkx, scipy), checks that
                                           their ids and messages equal the logs, then rewrites the table
    python3 make_check_table.py --check    writes nothing; exit 1 if the table in the README is not what the logs give

The table sits between the lines <!-- check-table:start --> and <!-- check-table:end -->.  Ids are namespaced as on the Lenses page
(cat·, baez·, fibre·, bridge·, qm·); an id that a script prints on several lines (one per case) is one row with the number of lines."""
import os, re, sys, subprocess
HERE = os.path.dirname(os.path.abspath(__file__)); PKG = os.path.dirname(HERE)
README = os.path.join(PKG, 'selfcheck', 'reports', 'README.md')
SCRIPTS = [('cat', 'cat_check.py', os.path.join('category', 'logs', 'cat_check.log')),
           ('baez', 'baez_check.py', os.path.join('baez', 'logs', 'baez_check.log')),
           ('fibre', 'fibre_check.py', os.path.join('schuller', 'logs', 'fibre_check_final.log')),
           ('bridge', 'bridge_check.py', os.path.join('schuller', 'logs', 'bridge_check_final.log')),
           ('qm', 'bridge_check_qm.py', os.path.join('schuller', 'logs', 'bridge_check_qm_final.log'))]
LINE = re.compile(r'^(ok  |FAIL) (\S+?): (.*)$')

def parse(text):
    rows = {}
    for l in text.splitlines():
        m = LINE.match(l)
        if m:
            cid, msg = m.group(2), m.group(3).strip()
            if cid in rows: rows[cid][1] += 1
            else: rows[cid] = [msg, 1]
    return rows

def one_line(msg, width=150):
    msg = msg.replace('|', '\\|')                    # a bar inside a markdown table cell is escaped
    if len(msg) <= width: return msg
    cut = msg[:width].rsplit(' ', 1)[0].rstrip(',;:')
    return cut + ' …'

def table(per):
    out = ['| id | script | lines | what it checks (the start of the script\'s own message) |', '|---|---|---|---|']
    for ns, script, _ in SCRIPTS:
        for cid, (msg, k) in per[ns].items():
            out.append(f'| `{ns}·{cid}` | `{script}` | {k} | {one_line(msg)} |')
    return '\n'.join(out)

per = {ns: parse(open(os.path.join(HERE, log), encoding='utf-8').read()) for ns, _, log in SCRIPTS}
if '--run' in sys.argv:
    env = dict(os.environ); env.setdefault('ATLAS_PKG', PKG)
    for ns, script, log in SCRIPTS:
        out = subprocess.run([sys.executable, os.path.join(PKG, 'selfcheck', 'reports', script)], capture_output=True, text=True, env=env, cwd=os.path.join(PKG, 'selfcheck', 'reports')).stdout
        fresh = parse(out)
        if ns == 'baez' and 'R1' not in fresh and re.search(r'^skip R1', out, re.M):
            fresh = {'R1': per['baez']['R1'], **fresh}          # R1 needs the papers' texts, which are not shipped: keep its recorded line
        if list(fresh) != list(per[ns]) or any(fresh[c] != per[ns][c] for c in fresh):
            sys.exit(f'{script}: a fresh run does not give the recorded lines of {log}; rerun the report folder first')
        print(f'{script}: {len(fresh)} ids, as recorded')
T = table(per)
text = open(README, encoding='utf-8').read()
m = re.search(r'(<!-- check-table:start -->\n)(.*?)(<!-- check-table:end -->)', text, re.S)
if not m: sys.exit('README.md has no check-table markers')
new = text[:m.start(2)] + T + '\n' + text[m.end(2):]
n = sum(len(v) for v in per.values()); lines = sum(k for v in per.values() for _, k in v.values())
if '--check' in sys.argv:
    print(('up to date: ' if new == text else 'OUT OF DATE: ') + f'{n} ids, {lines} lines')
    sys.exit(0 if new == text else 1)
open(README, 'w', encoding='utf-8').write(new)
print(f'wrote the table of selfcheck/reports/README.md: {n} ids ({lines} check lines)')
