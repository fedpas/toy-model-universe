# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The shared check of the six reports: a page states every result as it stands.  This module holds the pattern list (what a shipped report never says: the ids of
a list of notes, a note that a wording was fixed, text crossed out, a first-draft or before-and-after narrative, a version or round stamp) and the reader of a page's
visible text and its title, tip and label attributes.  Each report's test suite imports it and asserts that its page has no hit.  The tests themselves may quote
a wording that is kept out as a FORBIDDEN string; this module is only for what a page says.   Run on a page: python3 no_history.py <file.html> ..."""
import re, sys, html as _H

# (id, meaning, regex); case-insensitive; English.  A letter in square brackets (stron[g], stru[c]k) is the same regex written so that this file does not match its own patterns.
PATTERNS = [
    ('P1', 'ids of a list of notes', r"\berrat(a|um)\b|\bE-\d{3}\b|\bfinding E-"),
    ('P2', 'a note that a wording was fixed', r"\bcorrected (on|in|after|before|by|6|5)\b|\bcorrections? (of|applied|block|section)\b|\bnow corrected\b|\bwas corrected\b|\bcorrected after a check\b|\bcorrigend|\bthe correction[ ]of F\d+|\bcorrected\b|\bcorrection\b"),
    ('P3', 'taken back, crossed out', r"\bwithdrawn\b|\bretract(ed|ion)\b|\bretired\b|\bstru[c]k( through| out)?\b|\bsuperseded\b|\bobsolete\b|\bstale\b|\bdiscarded wording\b"),
    ('P4', 'first-draft and before-and-after narrative',
     r"\b(was|were|is|are) (wrong|false|too stron[g]|too weak|a mistake|mistaken)\b(?! (for|in|when|if|only|here|on|exactly|iff|unless|as|at|once|whenever|because|since|before))"
     r"|\bas first (written|stated|printed|said)\b|\bfirst (guess|draft|version|reading|explanation|wording)\b"
     r"|\bour (own )?(first|earlier|previous|old) (guess|reading|explanation|claim|sentence|wording|version|statement)\b"
     r"|\b(earlier|previous|former|old) (draft|version|wording|claim|statement|sentence|reading|analysis|release|report|row)s?\b"
     r"|\b(we|it) (once|previous[l]y|used to|had) (said|thought|claimed|believed|written|read)\b|\bused to (say|read|claim|be called)\b|\bformerly\b|\bpreviou[s]ly\b"
     r"|\bno longer (said|claimed|true|a mistake|stated)\b|\bto say what we said\b"),
    ('P5', 'over-statement narrative', r"\boverstate[sd]?\b|\boverclaim|\btoo stron[g]\b|\bwe (had )?misread\b|\bwas (misread|misstated)\b|\bour (own )?(error|errors|slip|slips|mistake|mistakes)\b|\bmisinterpret"),
    ('P6', 'version, date of a fix, round',
     r"\bv(7|8|9)(\.\d+)?\b|\bv10(\.[01])?\b|\bv1\.[0-9]\b|\baudit round( [12])?\b|\bround[- ](1|2|two|one)\b|\bsecond (round|pass)\b|\bchangelog\b|\bsince the last (report|release|version)\b|\bwhat('| i)s new\b|\b(5|6) October 2026\b|\bwork[- ]in[- ]progress\b|\b_wip\b"),
]
# whole page: forbidden markup (strike-through text, a section of fixes)
MARKUP = [
    ('M1', 'strike-through text', r"<(s|del|strike)[ >]"),
    ('M2', 'a section of fixes or its class', r'id="corr2?"|class="[^"]*\b(cat|bz|sc)-corr\b|href="#corr2?"|\brs-wrong\b'),
]
FLAGS = re.I
_COMP = [(i, m, re.compile(r, FLAGS)) for i, m, r in PATTERNS]
_MCOMP = [(i, m, re.compile(r, FLAGS)) for i, m, r in MARKUP]

# a tag: "<" and a letter, "/", "!" or "?", up to the ">" that is outside the quotes of an attribute value; any other "<" is a character of the text
_TAG = re.compile(r'<[A-Za-z/!?](?:[^>"\']|"[^"]*"|\'[^\']*\')*>')

def visible(html_text):
    """The text a reader can see or hear from a page: text nodes (script and style bodies excluded; a "<" that does not open a tag is a character of the text) plus the title,
    data-tip, aria-label and alt attributes."""
    h = re.sub(r'<style.*?</style>|<script.*?</script>', ' ', html_text, flags=re.S)
    attrs = re.findall(r'\b(?:title|data-tip|aria-label|alt)="([^"]*)"', h)
    body = _TAG.sub(' ', h)
    return re.sub(r'\s+', ' ', _H.unescape(' '.join([body] + attrs))).strip()

def bare_lt(html_text):
    """The places where a text node of a page holds a "<" written as a character instead of &lt; (a browser reads it as text, a validator does not): list of contexts."""
    h = re.sub(r'<style.*?</style>|<script.*?</script>|<!--.*?-->', ' ', html_text, flags=re.S)
    body = _TAG.sub('\x00', h)
    return [body[max(0, m.start() - 40): m.end() + 40].replace('\x00', ' ') for m in re.finditer('<', body)]

def scan(text, allow=()):
    """Hits in a plain text: list of (pattern id, matched text, context).  `allow` is a list of regexes; a hit whose context matches one of them is not a hit."""
    out = []
    al = [re.compile(a, FLAGS) for a in allow]
    for i, m, rx in _COMP:
        for mt in rx.finditer(text):
            ctx = text[max(0, mt.start() - 60): mt.end() + 60]
            if any(a.search(ctx) for a in al): continue
            out.append((i, mt.group(0), ctx))
    return out

def scan_markup(html_text):
    out = []
    for i, m, rx in _MCOMP:
        for mt in rx.finditer(html_text):
            out.append((i, mt.group(0), html_text[max(0, mt.start() - 40): mt.end() + 40]))
    return out

def scan_page(html_text, allow=()):
    return (scan(visible(html_text), allow) + scan_markup(re.sub(r'<style.*?</style>', ' ', html_text, flags=re.S))
            + [('M3', '<', c) for c in bare_lt(html_text)])

SELF = {  # one planted phrase per group: the scanner must catch each (a test of the test); written in pieces so that this file does not match its own patterns
    'P1': 'see err' + 'atum E-0' + '12 of the list', 'P2': 'wording cor' + 'rected on 6 October', 'P3': 'the sentence was with' + 'drawn and str' + 'uck through',
    'P4': 'our first gue' + 'ss was wr' + 'ong here and the earl' + 'ier version said so', 'P5': 'the wording was too str' + 'ong and over' + 'stated the result', 'P6': 'this is v1' + '.2 of the second ro' + 'und',
}
def selftest():
    bad = []
    for k, t in SELF.items():
        if not any(h[0] == k for h in scan(t)): bad.append(k)
    if not scan_markup('<p><s>old</s></p>') or not scan_markup('<section id="corr">'): bad.append('markup')
    if bare_lt('<p>j &lt; i</p><a title="x < y">t</a><script>if (a<b) {}</script>'): bad.append('bare_lt flags valid markup')
    if len(bare_lt('<p>if j < i then</p>')) != 1: bad.append('bare_lt misses a bare <')
    if 'j < i then' not in visible('<p>if j < i then <b>stop</b></p>') or 'a > b' not in visible('<p title="a > b">t</p>'): bad.append('visible')
    return bad

if __name__ == '__main__':
    bad = selftest()
    if bad: print('selftest FAILED for', bad); sys.exit(2)
    n = 0
    for f in sys.argv[1:]:
        t = open(f, encoding='utf-8').read()
        hits = scan_page(t)
        print(f, len(hits), 'hits')
        for h in hits: print('  ', h[0], repr(h[1]), '...', h[2].replace('\n', ' ')[:150])
        n += len(hits)
    sys.exit(1 if n else 0)
