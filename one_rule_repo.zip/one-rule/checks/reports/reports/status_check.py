# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The shared check of the status chips of the six reports: a status is shown by an icon, never by a word.  Each report's test suite imports this module and asserts that its
page has no problem.  A status chip is `<span class="chip FLAG" role="img" aria-label="NAME" title="TIP"><svg ...><use href="#i-FLAG"/></svg></span>`: the flag is one of
standard, checked, ours, open, input; the name and the hover text start with the flag word (and may say more: "standard: a statement of the paper"); the chip holds the
drawing and no text.  The page holds the five drawings once, as symbols of a hidden sprite, and the paths are those of the atlas's own badges (ICON_PATHS of StatusBadge.jsx;
test_reports.mjs compares this table with that file).   Run on a page: python3 status_check.py <file.html> ..."""
import re, sys, html as _H

FLAGS = ('standard', 'checked', 'ours', 'open', 'input')
ICON_PATHS = {
    'standard': ['M8 4.4v8.4', 'M8 4.4C6.6 3.3 4.5 3 2.4 3.4v8.7c2.1-.4 4.2-.1 5.6.9 1.4-1 3.5-1.3 5.6-.9V3.4C11.5 3 9.4 3.3 8 4.4z'],
    'checked': ['M4.9 8.3l2.2 2.3 4.1-4.9'],
    'ours': ['M8 2.1a4 4 0 0 0-2.3 7.3c.5.4.8.9.8 1.5v.3h3v-.3c0-.6.3-1.1.8-1.5A4 4 0 0 0 8 2.1z', 'M6.4 13.1h3.2', 'M7 14.8h2'],
    'open': ['M6.2 6.3a1.9 1.9 0 1 1 2.7 1.7c-.6.3-.9.7-.9 1.4', 'M8 11.5v.1'],
    'input': ['M5.6 2v3.2', 'M10.4 2v3.2', 'M4 5.2h8v2.2a4 4 0 0 1-8 0z', 'M8 11.4V14.2'],
}
CHIP = re.compile(r'<span class="chip (\w+)" role="img" aria-label="([^"]*)" title="([^"]*)">(.*?)</span>', re.S)

def chips(page):
    """Every status chip of a page as (flag, accessible name, hover text, inner markup)."""
    return [(m.group(1), _H.unescape(m.group(2)), _H.unescape(m.group(3)), m.group(4)) for m in CHIP.finditer(page)]

def kinds(fragment):
    """The flags of the chips in a piece of markup, in order."""
    return [c[0] for c in chips(fragment)]

def sprite_problems(page):
    out = []
    for f in FLAGS:
        m = re.search(r'<symbol id="i-%s" viewBox="0 0 16 16">(.*?)</symbol>' % f, page, re.S)
        if not m: out.append('no symbol i-%s' % f); continue
        if re.findall(r'<path d="([^"]*)"/>', m.group(1)) != ICON_PATHS[f]: out.append('the paths of i-%s are not those of the atlas badge' % f)
        ring = re.search(r'<circle cx="8" cy="8" r="6.6"( stroke-dasharray="2.2 1.9")?/>', m.group(1))
        if (f in ('checked', 'open')) != bool(ring) or (f == 'open') != bool(ring and ring.group(1)): out.append('the ring of i-%s differs from the badge' % f)
        if 'fill="none" stroke="currentColor"' not in m.group(1): out.append('i-%s is not a stroke icon in the colour of its chip' % f)
    return out

def problems(page, flags=FLAGS, legend=True):
    """The problems of the status chips of a page (an empty list: none).  `flags`: the flags that this page uses; `legend`: each of them has a legend entry (chip, word, meaning)."""
    out = []
    n_span = len(re.findall(r'<span class="chip[ "]', page))
    cs = chips(page)
    if n_span != len(cs): out.append('%d chips, %d of them are not an icon chip with role, name and hover text' % (n_span, n_span - len(cs)))
    if '<i></i>' in page: out.append('a dot chip is left')
    for f, name, tip, inner in cs:
        if f not in flags: out.append('flag %s is not one of this page\'s' % f)
        if not name.startswith(f) or not tip.startswith(f): out.append('the name or the hover text of a %s chip does not start with the word: %r %r' % (f, name, tip))
        if not re.fullmatch(r'<svg class="ic" aria-hidden="true" focusable="false"><use href="#i-%s"/></svg>' % f, inner): out.append('a %s chip holds more than its drawing: %r' % (f, inner[:60]))
    out += sprite_problems(page)
    if re.search(r'<span class="[^"]*">(?:standard|checked|ours|open|input)</span>', page): out.append('a flag word stands as a word chip')
    if 'class="tg ' in page: out.append('a word tag is left')
    if legend:
        for f in flags:
            if not re.search(r'<span class="chip %s" role="img" aria-label="[^"]*" title="[^"]*"><svg [^>]*><use href="#i-%s"/></svg></span> <b>%s</b>: ' % (f, f, f), page): out.append('no legend entry (chip, word, meaning) for %s' % f)
    return out

if __name__ == '__main__':
    n = 0
    for f in sys.argv[1:]:
        ps = problems(open(f, encoding='utf-8').read())
        print(f, len(ps), 'problems'); n += len(ps)
        for p in ps[:10]: print('  ', p)
    sys.exit(1 if n else 0)
