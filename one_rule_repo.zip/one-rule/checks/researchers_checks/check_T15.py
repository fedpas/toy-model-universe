#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T15: states (positive functionals) on Cl(p,q,r) (independent code).
Positivity of a functional w is tested EXACTLY as a finite problem: w(x* x) >= 0 for all x  <=>  the Gram matrix
G_ab = w(e_b* e_a) (2^n x 2^n, symmetric when w is hermitian) is positive semidefinite.
 A. the involution dagger (e_a^dag = e_a^{-1} for non-null blades; null generators e^dag = e) is an involutive
    anti-automorphism for every signature n <= 4; for r = 0, L_{x^dag} = L_x^T and <x^dag x>_0 = sum x_a^2.
 B. Cl(3,0) = M2(C): w_rho(x) = 2<rho x>_0 with rho = (1 + v)/2 is positive iff |v| <= 1 (Bloch ball), Born rule
    2<rho P>_0 = (1 + v.u)/2 for P = (1 + u)/2, lambda(x) = -<omega x>_0.
 C. r >= 1, every signature n <= 4, for FOUR involutions (dagger, dagger with null e -> -e, reversion, Clifford
    conjugation): the scalar part is positive for dagger and vanishes on the radical J; every hermitian functional
    w = (a state pulled back from Cl(p,q)) + t phi, phi hermitian, supported on J, t != 0, is NOT positive
    (G has a negative eigenvalue) for 20 random phi, t = +-0.1; the top-blade form lambda is never positive.
 D. the hermiticity hypothesis is needed over R: in Cl(0,0,1) with eps* = -eps, w(a + b eps) = a + c b is positive
    for every c.
 E. tracial hermitian functionals on Cl(p,q), n <= 5: their dimension is the number of simple summands (1, or 2 when
    p - q = 1 mod 4); the normalised scalar part is a tracial state."""
import numpy as np
from clC import Alg, popcount

rng = np.random.default_rng(15)
fails = 0
count = 0


def ok(cond, msg):
    global fails, count
    count += 1
    if not cond:
        fails += 1
        print('FAIL', msg)


def sigs(nmin, nmax):
    for n in range(nmin, nmax + 1):
        for r in range(0, n + 1):
            for q in range(0, n - r + 1):
                yield (n - q - r, q, r)


def involution(A, kind):
    """return the vector of signs d_a with e_a^* = d_a e_a (all four are of this diagonal form)"""
    d = np.zeros(A.N)
    for a in range(A.N):
        k = popcount(a)
        rev = -1 if (k * (k - 1) // 2) % 2 else 1
        if kind == 'dagger':        # e_i -> eps_i e_i (non-null), e_i -> e_i (null); composed with reversion
            f = 1
            for i in range(A.n):
                if a >> i & 1 and A.eps[i] != 0:
                    f *= A.eps[i]
            d[a] = rev * f
        elif kind == 'dagger-':     # same but null e_i -> -e_i
            f = 1
            for i in range(A.n):
                if a >> i & 1:
                    f *= A.eps[i] if A.eps[i] != 0 else -1
            d[a] = rev * f
        elif kind == 'reversion':
            d[a] = rev
        elif kind == 'conjugation':  # Clifford conjugation = reversion o grade involution
            d[a] = rev * (-1) ** k
    return d


def star(d, x):
    return d * x


def gram(A, d, w):
    """G[a, b] = w(e_b^* e_a)"""
    G = np.zeros((A.N, A.N))
    for a in range(A.N):
        for b in range(A.N):
            s = A.S[b, a]
            if s:
                G[a, b] = w[b ^ a] * s * d[b]
    return G


# ---------- A ----------
for (p, q, r) in sigs(1, 4):
    A = Alg.pq(p, q, r)
    for kind in ['dagger', 'dagger-', 'reversion', 'conjugation']:
        d = involution(A, kind)
        for _ in range(3):
            x = rng.normal(size=A.N); y = rng.normal(size=A.N)
            ok(np.allclose(star(d, A.mul(x, y)), A.mul(star(d, y), star(d, x))), f'anti-automorphism {kind} {p,q,r}')
            ok(np.allclose(star(d, star(d, x)), x), 'involutive')
    if r == 0:
        d = involution(A, 'dagger')
        x = rng.normal(size=A.N)
        ok(np.allclose(A.Lmat(star(d, x)), A.Lmat(x).T), f'L(x^dag) = L(x)^T {p,q}')
        ok(np.isclose(A.mul(star(d, x), x)[0], x @ x), '<x^dag x>_0 = |x|^2')
print('A: four involutive anti-automorphisms on all 34 signatures n <= 4; for r = 0 dagger = transpose of the regular rep')

# ---------- B ----------
A = Alg.pq(3, 0)
d = involution(A, 'dagger')
for _ in range(200):
    v = rng.normal(size=3) * rng.uniform(0.2, 1.8) / np.sqrt(3)
    rho = (A.scalar(1.0) + A.vec(v)) / 2
    w = 2 * rho  # w(x) = 2<rho x>_0 = sum_a (2 rho)_a <e_a x>_0 ; build as functional on blades:
    wf = np.array([2 * A.mul(rho, A.blade(a))[0] for a in range(A.N)])
    G = gram(A, d, wf)
    pos = np.linalg.eigvalsh((G + G.T) / 2).min() >= -1e-12
    if abs(np.linalg.norm(v) - 1) > 1e-6:
        ok(pos == (np.linalg.norm(v) <= 1), 'Bloch ball')
    u = rng.normal(size=3); u /= np.linalg.norm(u)
    P = (A.scalar(1.0) + A.vec(u)) / 2
    ok(np.isclose(2 * A.mul(rho, P)[0], (1 + v @ u) / 2), 'Born rule')
om = A.blade(7)
x = rng.normal(size=8)
ok(np.isclose(x[7], -A.mul(om, x)[0]), 'lambda(x) = -<omega x>_0')
print('B: Cl(3,0): w_rho positive iff |v| <= 1 (200 samples), Born rule (1 + v.u)/2, lambda = -<omega .>_0')

# ---------- C ----------
nsig = 0
tested = set()
for (p, q, r) in sigs(1, 4):
    if r == 0:
        continue
    nsig += 1
    A = Alg.pq(p, q, r)
    nullmask = sum(1 << i for i in range(p + q, A.n))
    J = [a for a in range(A.N) if a & nullmask]
    for kind in ['dagger', 'dagger-', 'reversion', 'conjugation']:
        d = involution(A, kind)
        herm = lambda a: d[a] == 1     # w(e_a^*) = w(e_a) forces w(e_a) = 0 when d_a = -1
        base = np.zeros(A.N); base[0] = 1
        base_pos = np.linalg.eigvalsh((gram(A, d, base) + gram(A, d, base).T) / 2).min() >= -1e-12
        if kind in ('dagger', 'dagger-'):
            ok(base_pos, 'scalar part positive for dagger')
            ok(all(base[a] == 0 for a in J), 'scalar part vanishes on J')
        if not base_pos:
            continue          # no positive base point for this involution: nothing to perturb
        tested.add((p, q, r, kind))
        for _ in range(20):
            phi = np.zeros(A.N)
            for a in J:
                if herm(a):
                    phi[a] = rng.normal()
            if not phi.any():
                continue
            phi /= abs(phi).max()
            # exact reason: G_aa = w(e_a^* e_a) = +-w(e_a^2) = 0 for a in J, and a PSD matrix with a zero diagonal
            # entry has a zero row, in particular G_a0 = w(e_a) = 0
            Gp = gram(A, d, base + phi)
            ok(all(abs(Gp[a, a]) < 1e-12 for a in J), 'zero diagonal on J')
            for t in (0.1, -0.1):
                w = base + t * phi
                G = gram(A, d, w)
                G = (G + G.T) / 2
                ok(np.linalg.eigvalsh(G).min() < -1e-9, f'non-zero on J => not positive {p,q,r} {kind}')
        lam = np.zeros(A.N); lam[A.N - 1] = 1
        G = gram(A, d, lam)
        ok(np.linalg.eigvalsh((G + G.T) / 2).min() < -1e-12 or d[A.N - 1] == -1,
           f'top-blade form not positive {p,q,r} {kind}')
print(f'C: {nsig} null signatures n <= 4, {len(tested)} (signature, involution) pairs with a positive base point: any hermitian functional non-zero on J fails positivity; '
      'the top-blade form is never a positive hermitian functional')

# ---------- D ----------
A = Alg.pq(0, 0, 1)
d = np.array([1., -1.])
for c in [-5., 0.3, 7.]:
    w = np.array([1., c])
    G = gram(A, d, w)
    ok(np.allclose(G, np.diag([1., 0.])) or np.linalg.eigvalsh((G + G.T) / 2).min() >= -1e-12, 'D: positive for any c')
print('D: Cl(0,0,1) with eps* = -eps: w(a + b eps) = a + c b is positive for every c (not hermitian unless c = 0)')

# ---------- E ----------
for (p, q, r) in sigs(1, 5):
    if r:
        continue
    A = Alg.pq(p, q, 0)
    d = involution(A, 'dagger')
    # linear conditions on w: w(e_a e_b - e_b e_a) = 0 for all a, b ; w(e_a) = 0 when d_a = -1
    rows = []
    for a in range(A.N):
        for b in range(A.N):
            v = np.zeros(A.N)
            v[a ^ b] += A.S[a, b] - A.S[b, a]
            if v.any():
                rows.append(v)
        if d[a] == -1:
            v = np.zeros(A.N); v[a] = 1; rows.append(v)
    dim = A.N - np.linalg.matrix_rank(np.array(rows))
    n = p + q
    summands = 2 if (n % 2 == 1 and (p - q) % 4 == 1) else 1
    ok(dim == summands, f'tracial hermitian dim {p,q}: {dim} vs {summands}')
print('E: hermitian tracial functionals on Cl(p,q), n <= 5: dimension = number of simple summands')
print(f'check_T15: {count - fails} of {count} assertions hold')
if fails:
    raise SystemExit(1)
