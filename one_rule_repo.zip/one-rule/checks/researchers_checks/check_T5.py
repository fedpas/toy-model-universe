#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T5.py -- independent check of T5 (even subalgebra, D1, D2, and what fails with only null generators).

Asserts:
  EV   for every signature (p,q,r) with 1 <= n <= 5 and at least one non-null generator t = e_k (every such k tried):
       f_i = e_i t (i != k) satisfy f_i^2 = -e_i^2 t^2, anticommute pairwise, and their 2^{n-1} sorted products are a basis of the even part
       (exact rank; the span consists of even labels only).  Hence Cl0(p,q,r) = Cl(p,q-1,r) if t^2 = -1, = Cl(q,p-1,r) if t^2 = +1.
  D1   Cl(0,m) = Cl0(m+1,0) for m = 1..7 through f_i = e_i e_{m+1} (squares -1, anticommute, basis of the even part).
  D2   Cl(p,q) -> Cl(n+2,0), e_j -> e_j (j positive), e_j -> e_j P, P = e_{n+1} e_{n+2}: squares, anticommutation, odd images, and the
       2^n images of the labels are +- distinct blades (injective, graded), for all p+q <= 5.
  NUL  with only null generators: the even part of Lambda(R^r), r = 3, 4, 5, has radical dimension 2^{r-1} - 1 and Loewy length floor(r/2) + 1,
       and NO Cl(p',q',r') with p'+q'+r' = r - 1 has these two invariants (its radical dimension is 2^{r-1} - 2^{p'+q'}, Loewy length r'+1).
       For r = 2 the even part is the dual numbers Cl(0,0,1) (the one accident), for r = 1 it is R.
"""
import sys, itertools
from fractions import Fraction
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from bitrule_A import BR, rank_fr, anticomm, comm, popcount

ok_all = True
def report(name, cond, msg=''):
    global ok_all; ok_all &= bool(cond); print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))
def sig(p, q, r=0): return tuple([1] * p + [-1] * q + [0] * r)
def triples(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]

# ---------------------------------------------------------------- EV
def even_iso_ok(A, k):
    n = A.n; t = A.gen(k); t2 = A.eps[k]
    others = [i for i in range(n) if i != k]
    f = {i: A.mul(A.gen(i), t) for i in others}
    ok = all(A.mul(f[i], f[i]) == ({0: -A.eps[i] * t2} if A.eps[i] * t2 else {}) for i in others)   # f_i^2 = e_i t e_i t = -e_i^2 t^2
    ok &= all(anticomm(A, f[i], f[j]) == {} for i in others for j in others if i < j)
    rows = []
    for J in itertools.chain.from_iterable(itertools.combinations(others, m) for m in range(n)):
        w = A.word(f, J)
        ok &= all(popcount(a) % 2 == 0 for a in w)
        rows.append(w)
    ok &= rank_fr(rows, A.M) == A.M // 2
    return ok
okE = True; cnt = 0
for n in range(1, 6):
    for (p, q, r) in triples(n):
        A = BR(sig(p, q, r))
        for k in range(n):
            if A.eps[k] != 0:
                okE &= even_iso_ok(A, k); cnt += 1
report('EV', okE, f'{cnt} (signature, invertible generator) pairs with n <= 5: f_i = e_i t gives Cl(p,q-1,r) or Cl(q,p-1,r) = the even part, null generators carried along')

# ---------------------------------------------------------------- D1
okD1 = all(even_iso_ok(BR(sig(m + 1, 0)), m) for m in range(1, 8))
report('D1', okD1, 'Cl(0,m) = Cl0(m+1,0) for m = 1..7 via f_i = e_i e_{m+1} (f_i^2 = -1)')

# ---------------------------------------------------------------- D2
okD2 = True
for n in range(0, 6):
    for p in range(n + 1):
        q = n - p; B = BR(sig(n + 2, 0)); P = B.mul(B.gen(n), B.gen(n + 1))
        img = [B.gen(j) if j < p else B.mul(B.gen(j), P) for j in range(n)]
        okD2 &= all(B.mul(img[j], img[j]) == {0: (1 if j < p else -1)} for j in range(n))
        okD2 &= all(anticomm(B, img[i], img[j]) == {} for i in range(n) for j in range(i + 1, n))
        okD2 &= all(all(popcount(a) % 2 == 1 for a in img[j]) for j in range(n))
        seen = set()
        for a in range(1 << n):
            w = B.word(img, [j for j in range(n) if (a >> j) & 1])
            okD2 &= len(w) == 1 and abs(next(iter(w.values()))) == 1
            seen.add(next(iter(w)))
        okD2 &= len(seen) == (1 << n)
report('D2', okD2, 'Cl(p,q) -> Cl(n+2,0) by e_j -> e_j P on negative generators: squares -1, anticommutation, odd images, labels -> +- distinct blades (injective graded embedding), all p+q <= 5')

# ---------------------------------------------------------------- NUL: invariants of the even part of the exterior algebra vs Clifford algebras on r-1 generators
def invariants_of_subalgebra(A, basis):
    """basis: list of multivectors spanning a subalgebra S (closed under product).  Returns (dim, radical dim, Loewy length) where the radical of S is
    computed as the largest nilpotent ideal: here S is spanned by labels so rad = span of basis labels that are nilpotent... we compute it honestly:
    rad(S) = {x : trace form of the regular representation vanishes on x S} (S finite-dim over Q, char 0: rad = kernel of the trace form)."""
    d = len(basis); idx = {next(iter(b)): i for i, b in enumerate(basis)}   # basis elements are single labels here
    # structure constants: basis[i]*basis[j] = sum_k c_ijk basis[k]
    def coords(x): return [Fraction(x.get(next(iter(basis[k])), 0)) for k in range(d)]
    # left regular matrices
    L = []
    for i in range(d):
        L.append([coords(A.mul(basis[i], basis[j])) for j in range(d)])   # column j = coords of b_i b_j
    def tr(i, j):   # trace of L_i L_j
        return sum(sum(L[i][m][k] * L[j][k][m] for m in range(d)) for k in range(d))  # careful with the column convention: L[i][j][k] = (b_i b_j)_k
    T = [[sum(sum(L[i][m][k] * L[j][k][m] for m in range(d)) for k in range(d)) for j in range(d)] for i in range(d)]
    rk = rank_fr([{c: T[r][c] for c in range(d)} for r in range(d)], d)
    rad_dim = d - rk
    # Loewy length: smallest k with rad^k = 0, where rad = span of nilpotent labels here (all basis elements are labels; the kernel is label-spanned)
    rad_labels = [next(iter(b)) for b in basis if all(T[idx[next(iter(b))]][j] == 0 for j in range(d))]
    Rk = [{a: 1} for a in rad_labels]; length = 1
    while Rk:
        nxt = []
        for x in Rk:
            for a in rad_labels:
                y = A.mul(x, {a: 1})
                if y: nxt.append(y)
        # reduce to a spanning set of labels
        labs = set(itertools.chain.from_iterable(y.keys() for y in nxt))
        Rk = [{a: 1} for a in labs]; length += 1
        if length > 20: break
    return d, rad_dim, length
okN = True; msgs = []
for r in range(1, 6):
    A = BR(sig(0, 0, r))
    ev = [{a: 1} for a in range(A.M) if popcount(a) % 2 == 0]
    d, rad, ll = invariants_of_subalgebra(A, ev)
    cands = []
    for (p2, q2, r2) in triples(r - 1):
        Bc = BR(sig(p2, q2, r2)); d2, rad2, ll2 = invariants_of_subalgebra(Bc, [{a: 1} for a in range(Bc.M)])
        if (d2, rad2, ll2) == (d, rad, ll): cands.append((p2, q2, r2))
    expected_rad = 2 ** (r - 1) - 1 if r >= 2 else 0
    expected_ll = r // 2 + 1
    okN &= rad == expected_rad and ll == expected_ll
    if r <= 2: okN &= cands == [(0, 0, r - 1)]
    else: okN &= cands == []
    msgs.append(f'r={r}: even part dim {d}, radical {rad}, Loewy {ll}, matching Cl(p,q,r) on {r-1} generators: {cands if cands else "none"}')
report('NUL', okN, ' | '.join(msgs))
print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
