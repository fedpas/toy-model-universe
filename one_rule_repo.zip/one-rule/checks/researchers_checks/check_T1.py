#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T1.py  --  independent check of T1 (associativity of the bit rule for every n and every eps in {+1,-1,0}^n).

Own code (no atlas import).  Bit rule: e_a e_b = s(a,b) e_{a xor b},
   s(a,b) = (-1)^{N(a,b)} * prod_{i in a&b} eps_i,   N(a,b) = #{(i in a, j in b): j < i}.

What is asserted (each line would FAIL if the corresponding step of the proof were false):
  A. N(a,b) mod 2 is bilinear on F_2^n  (N(a xor a', b) = N(a,b) + N(a',b) mod 2, same in b), exhaustive n <= 7.
  B. the 2-cocycle identity of the sign part  sigma(a,b) sigma(a^b,c) = sigma(a,b^c) sigma(b,c), exhaustive n <= 7 (2^21 triples at n=7).
  C. the one-bit identity  x*y + (x xor y)*z == x*(y xor z) + y*z  as INTEGERS on all 8 bit triples (this is what lets eps_i = 0 through).
  D. full associativity  (e_a e_b) e_c = e_a (e_b e_c)  on all blade triples for ALL 3^n eps choices, n <= 4 (81 x 4096), and for n = 5, 6 on 40 random eps
     choices each (32768 and 262144 triples per choice), with the product computed by the bit rule only.
  E. associativity on random multivectors with exact Fraction coefficients (n = 5, 6, mixed eps), 200 trials.
  F. a sabotage: the same test with the sign (-1)^{#(i in a, j in b, j <= i)} (<= instead of <) must FAIL at some triple (so the test can fail).
"""
import itertools, random, sys
from fractions import Fraction
import numpy as np

def popcount(x): return bin(x).count('1')

def N_pairs(a, b):
    """number of pairs (i in a, j in b) with j < i"""
    c = 0
    i = 0
    while a >> i:
        if (a >> i) & 1:
            c += popcount(b & ((1 << i) - 1))
        i += 1
    return c

def sign_eps(a, b, eps):
    s = -1 if N_pairs(a, b) & 1 else 1
    m = a & b
    i = 0
    while m:
        if m & 1:
            s *= eps[i]
        m >>= 1; i += 1
    return s

def Nmat(n):
    M = 1 << n
    T = np.zeros((M, M), dtype=np.int64)
    for a in range(M):
        for b in range(M):
            T[a, b] = N_pairs(a, b) & 1
    return T

ok_all = True
def report(name, cond, msg=''):
    global ok_all
    ok_all &= bool(cond)
    print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))

# A, B: bilinearity and cocycle identity of the sign part, exhaustive up to n = 7
for n in range(1, 8):
    M = 1 << n
    T = Nmat(n)
    idx = np.arange(M)
    X = idx[:, None] ^ idx[None, :]              # a xor b table
    # bilinearity in the first argument: T[a^a', b] == T[a,b] + T[a',b]
    bil1 = np.all((T[X[:, :, None], idx[None, None, :]] - T[idx[:, None, None], idx[None, None, :]] - T[idx[None, :, None], idx[None, None, :]]) % 2 == 0)
    bil2 = np.all((T[idx[:, None, None], X[None, :, :]] - T[idx[:, None, None], idx[None, :, None]] - T[idx[:, None, None], idx[None, None, :]]) % 2 == 0)
    # cocycle: T[a,b] + T[a^b,c] == T[a,b^c] + T[b,c]  (mod 2)
    lhs = T[idx[:, None, None], idx[None, :, None]] + T[X[:, :, None], idx[None, None, :]]
    rhs = T[idx[:, None, None], X[None, :, :]] + T[idx[None, :, None], idx[None, None, :]]
    coc = np.all((lhs - rhs) % 2 == 0)
    report(f'A/B n={n}', bil1 and bil2 and coc, f'N mod 2 bilinear and a 2-cocycle on all {M**3} triples')

# C: the integer identity that carries eps_i = 0
okC = all(x*y + (x ^ y)*z == x*(y ^ z) + y*z for x in (0, 1) for y in (0, 1) for z in (0, 1))
report('C', okC, 'x*y + (x xor y)*z == x*(y xor z) + y*z as integers for all 8 bit triples: the exponent of eps_i is the same integer on both sides')

# D: full associativity by the bit rule, all eps for n <= 4, random eps for n = 5, 6
def assoc_exhaustive(n, eps, signfun=sign_eps):
    M = 1 << n
    S = [[signfun(a, b, eps) for b in range(M)] for a in range(M)]
    for a in range(M):
        for b in range(M):
            ab = a ^ b; sab = S[a][b]
            for c in range(M):
                l = sab * S[ab][c]
                r = S[b][c] * S[a][b ^ c]
                if l != r:
                    return False, (a, b, c)
    return True, None

tot = 0
bad = []
for n in range(1, 5):
    for eps in itertools.product((1, -1, 0), repeat=n):
        ok, w = assoc_exhaustive(n, eps)
        tot += 1
        if not ok: bad.append((n, eps, w))
report('D n<=4', not bad and tot == 3 + 9 + 27 + 81, f'all {tot} eps choices with n <= 4: (e_a e_b) e_c == e_a (e_b e_c) on every blade triple')
rng = random.Random(20261005)
for n in (5, 6):
    bad = []
    for _ in range(40):
        eps = tuple(rng.choice((1, -1, 0)) for _ in range(n))
        ok, w = assoc_exhaustive(n, eps)
        if not ok: bad.append((eps, w))
    report(f'D n={n}', not bad, f'40 random eps choices, all {(1 << n) ** 3} blade triples each')

# E: random multivectors with Fraction coefficients
def mul(x, y, eps):
    out = {}
    for a, ca in x.items():
        for b, cb in y.items():
            s = sign_eps(a, b, eps)
            if s:
                out[a ^ b] = out.get(a ^ b, 0) + s * ca * cb
    return {k: v for k, v in out.items() if v != 0}
okE = True
for t in range(200):
    n = rng.choice((5, 6)); M = 1 << n
    eps = tuple(rng.choice((1, -1, 0)) for _ in range(n))
    mv = lambda: {a: Fraction(rng.randint(-5, 5), rng.randint(1, 4)) for a in rng.sample(range(M), 6)}
    x, y, z = mv(), mv(), mv()
    okE &= mul(mul(x, y, eps), z, eps) == mul(x, mul(y, z, eps), eps)
report('E', okE, '200 random Fraction multivectors, n = 5, 6, mixed eps: (xy)z == x(yz) exactly')

# F: sabotage.  NOTE: replacing j < i by j <= i does NOT break associativity: N_le(a,b) = N(a,b) + |a & b| and |a & b| mod 2 is bilinear
# too, so that variant is another 2-cocycle (it is the bit rule with every eps_i replaced by -eps_i).  A sabotage must be NON-bilinear:
# multiply the sign by (-1)^{[a > b and a & b == 0]}.  This must fail somewhere (shows the test has teeth).
def N_le(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << (i + 1)) - 1))
        i += 1
    return c
def sign_le(a, b, eps):
    s = -1 if N_le(a, b) & 1 else 1
    m = a & b; i = 0
    while m:
        if m & 1: s *= eps[i]
        m >>= 1; i += 1
    return s
okF1, _ = assoc_exhaustive(4, (1, 1, -1, 0), sign_le)
report('F1', okF1, 'the variant j <= i is STILL associative (it is a cocycle: N + |a&b| is bilinear); it equals the bit rule with eps -> -eps')
def sign_bad(a, b, eps):
    return sign_eps(a, b, eps) * (-1 if (a > b and (a & b) == 0) else 1)
okF, w = assoc_exhaustive(3, (1, 1, 1), sign_bad)
report('F2', not okF, f'non-bilinear sabotage fails associativity at triple {w} in Cl(3,0): the test can fail')

print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
