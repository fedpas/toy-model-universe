# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T14: extended Hamming, Turyn's Golay code, total singularity in Cl(24,0), S(5,8,24), and 8 | n. Own code.
Asserts:
 1. H = extended cyclic Hamming (g = 1 + x + x^3) and RM(1,3) are both [8,4,4] with enumerator 1 + 14x^4 + x^8; H ≅ RM(1,3)
    by a coordinate permutation; |Aut(H)| = 1344 by brute force over all 8! permutations.
 2. H' (reciprocal g' = 1 + x^2 + x^3, extended): H ∩ H' = {0, 1}, H + H' = even-weight code.
 3. Turyn code G = {(a+x, b+x, a+b+x)}: dimension 12, self-dual, doubly even, min weight 8,
    enumerator 1 + 759x^8 + 2576x^12 + 759x^16 + x^24; Pless second moment gives A_8 = 759 by hand formula.
 4. G is totally singular for Q(a) = C(|a|,2) mod 2 (the label form of Cl(24,0)); that form has Gauss sum +2^12,
    so its Witt index is 12 (G is maximal) and it has 2^23 + 2^11 singular vectors (counted by the binomial sum).
 5. Every 5-subset of the 24 points lies in exactly one octad (all 42504 checked) — S(5,8,24).
 6. n = 8k: a doubly-even self-dual code exists for n = 8, 16, 24 (direct sums of H); for n even and n ≢ 0 mod 8 the label
    form of Cl(n,0) has no Lagrangian subspace containing 1...1 (Gauss sum sign / Q(1..1)), checked n = 2..64.
 7. Leech minimal-vector shape arithmetic 1104 + 97152 + 98304 = 196560 (arithmetic only).
"""
import sys, itertools
from math import comb

ok = 0


def check(c, m):
    global ok
    if not c:
        print("FAIL:", m)
        sys.exit(1)
    ok += 1


def pc(x):
    return bin(x).count("1")


def span(gens):
    S = {0}
    for g in gens:
        S |= {s ^ g for s in S}
    return S


def cyclic_ext_hamming(g):
    gens = []
    for s in range(4):
        w = 0
        for i in range(4):
            if g >> i & 1:
                w |= 1 << ((i + s) % 7)
        w |= (pc(w) & 1) << 7  # parity bit
        gens.append(w)
    return span(gens)


def enum(C, n):
    A = [0] * (n + 1)
    for c in C:
        A[pc(c)] += 1
    return A


H = cyclic_ext_hamming(0b1011)   # 1 + x + x^3
Hp = cyclic_ext_hamming(0b1101)  # 1 + x^2 + x^3
check(len(H) == 16 and enum(H, 8) == [1, 0, 0, 0, 14, 0, 0, 0, 1], "H enumerator")
check(len(Hp) == 16 and enum(Hp, 8) == [1, 0, 0, 0, 14, 0, 0, 0, 1], "H' enumerator")
# RM(1,3): affine functions on F_2^3 evaluated at points 0..7
RM = set()
for c0 in range(2):
    for lin in range(8):
        w = 0
        for pt in range(8):
            if (c0 + pc(lin & pt)) & 1:
                w |= 1 << pt
        RM.add(w)
check(enum(RM, 8) == enum(H, 8), "RM(1,3) enumerator")


def permute(w, perm, n):
    out = 0
    for i in range(n):
        if w >> i & 1:
            out |= 1 << perm[i]
    return out


aut = 0
equiv = None
for perm in itertools.permutations(range(8)):
    img = {permute(c, perm, 8) for c in H}
    if img == H:
        aut += 1
    if equiv is None and img == RM:
        equiv = perm
check(aut == 1344, f"|Aut H| = {aut}")
check(equiv is not None, "H equivalent to RM(1,3)")
print(f"1 ok: H ≅ RM(1,3) (perm {equiv}), weight enumerator 1 + 14x^4 + x^8, |Aut| = {aut} = 8 * 168")
ONE8 = 255
check(H & Hp == {0, ONE8}, "H ∩ H' = {0,1}")
check(len({a ^ b for a in H for b in Hp}) == 128 and all(pc(c) % 2 == 0 for c in (a ^ b for a in H for b in Hp)), "H+H' = even")
print("2 ok: H ∩ H' = {0, 1}, H + H' = even-weight code")

G = set()
for a in H:
    for b in H:
        for x in Hp:
            G.add((a ^ x) | ((b ^ x) << 8) | ((a ^ b ^ x) << 16))
A = enum(G, 24)
check(len(G) == 4096, "dim 12")
check(A[8] == 759 and A[12] == 2576 and A[16] == 759 and A[24] == 1 and A[0] == 1 and sum(A) == 4096, f"enumerator {A}")
check(all(pc(c) % 4 == 0 for c in G), "doubly even")
basis = []
sp = {0}
for c in sorted(G):
    if c not in sp:
        basis.append(c)
        sp |= {s ^ c for s in sp}
check(len(basis) == 12, "basis")
check(all(pc(u & v) % 2 == 0 for u in basis for v in basis), "self-orthogonal => self-dual (dim 12 of 24)")
# Pless moment by hand formula: sum w^2 = |C| n(n+1)/4 ; with A16 = A8, A12 = 4094 - 2 A8
A8 = (4096 * 24 * 25 // 4 - 144 * 4094 - 576) // (64 + 256 - 288)
check(A8 == 759, "Pless moment gives 759")
print("3 ok: Turyn code: [24,12,8], self-dual, doubly even, enumerator 1 + 759x^8 + 2576x^12 + 759x^16 + x^24")

Q = lambda w: (w * (w - 1) // 2) % 2
check(all(Q(pc(c)) == 0 for c in G), "Q = 0 on G")
check(all((pc(u) * pc(v) - pc(u & v)) % 2 == 0 for u in basis for v in basis), "polar form 0 on G")
gauss = sum(comb(24, k) * (-1) ** Q(k) for k in range(25))
sing = sum(comb(24, k) for k in range(25) if Q(k) == 0)
check(gauss == 2 ** 12 and sing == 2 ** 23 + 2 ** 11, f"Gauss sum {gauss}, singular {sing}")
print(f"4 ok: Golay code is a maximal totally singular subspace of the Cl(24,0) label form (Gauss sum 2^12, {sing} = 2^23 + 2^11 singular)")

octads = [c for c in G if pc(c) == 8]
cover = {}
for o in octads:
    pts = [i for i in range(24) if o >> i & 1]
    for f in itertools.combinations(pts, 5):
        cover[f] = cover.get(f, 0) + 1
check(len(cover) == comb(24, 5) == 42504 and set(cover.values()) == {1}, "S(5,8,24)")
check(all(pc(o1 & o2) in (0, 2, 4, 8) for o1 in octads[:60] for o2 in octads), "octads meet in 0,2,4,8")
print("5 ok: every 5-set lies in exactly one octad (42504 = 759 * 56)")

# 6: lengths
for n in range(2, 65, 2):
    g = sum(comb(n, k) * (-1) ** Q(k) for k in range(n + 1))
    lag = (g > 0) and Q(n) == 0
    check(lag == (n % 8 == 0), f"n={n}")
for k in (1, 2, 3):
    C = {0}
    for blk in range(k):
        C = {c ^ (h << (8 * blk)) for c in C for h in H}
    check(len(C) == 2 ** (4 * k) and all(pc(c) % 4 == 0 for c in C), "H^k doubly even self-dual")
print("6 ok: Lagrangian t.s. subspace of Q_{Cl(n,0)} containing 1..1 exists iff 8 | n (n = 2..64); H^k realises n = 8k")
check(4 * comb(24, 2) == 1104 and 759 * 2 ** 7 == 97152 and 24 * 2 ** 12 == 98304 and 1104 + 97152 + 98304 == 196560, "Leech")
print("7 ok: 1104 + 97152 + 98304 = 196560 (shape arithmetic only)")
print(f"ALL {ok} CHECKS PASSED")
