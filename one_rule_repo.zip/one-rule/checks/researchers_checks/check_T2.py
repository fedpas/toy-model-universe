#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T2.py -- independent check of T2 (radical, Loewy series, super-centre, graded tensor product, grading lift) for Cl(p,q,r).

Asserts, for all 83 signatures with 1 <= n <= 6 unless said otherwise:
  GT   the bit-rule sign of a concatenated generator list factorises with the Koszul sign: s((a1,a2),(b1,b2)) = s1(a1,b1) s2(a2,b2) (-1)^{|a2||b1|}
       (exhaustive over all label pairs for all splits of all signatures with n <= 6): Cl(p,q,r) = Cl(p,q) (x)^ Lambda(R^r), graded tensor product.
  RAD  the kernel of the trace form of the regular representation (= Jacobson radical in characteristic 0, Dickson) is exactly the span of the labels
       containing a null bit: dimension 2^n - 2^{p+q}, and that span is an ideal (products of a radical label with any label are 0 or radical labels).
  LOE  J^k = span of labels with >= k null bits (both inclusions by products), so the layers have dimension C(r,k) 2^{p+q} and J^{r+1} = 0 != J^r.
  SC   the super-centre (homogeneous z with z x = (-1)^{|z||x|} x z for all x), computed as the solution space of the linear system against all
       generators, is spanned by the labels contained in the null mask: dimension 2^r.  (n <= 5 for speed.)
  CEN  the ordinary centre of Cl(p,q) has dimension 1 (n even) or 2 (n odd, spanned by 1 and the pseudoscalar), n <= 6.
  GRA  for r = 0, n odd, the central idempotents (1 +- w)/2 (w pseudoscalar, w^2 = +1 case) are not homogeneous, so the two simple factors are not graded
       ideals; for r >= 1 the radical is a graded ideal.  (This is the graded-simplicity part of 'graded Azumaya iff r = 0'.)
  GL   label-homogeneous gradings: the relations e_i^2 = eps_i != 0 force 2 deg(e_i) = 0 and e_i^2 = 0 forces nothing; the universal label-homogeneous
       grading group is Z_2^{p+q} x Z^r (free rank r): checked as the rank of the relation lattice.
"""
import sys, itertools
from fractions import Fraction
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from bitrule_A import BR, rank_fr, anticomm, comm, popcount, N_pairs

ok_all = True
def report(name, cond, msg=''):
    global ok_all; ok_all &= bool(cond); print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))
def sig(p, q, r=0): return tuple([1] * p + [-1] * q + [0] * r)
def triples(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]

# ---------------------------------------------------------------- GT
okG = True
for n in range(1, 7):
    for (p, q, r) in triples(n):
        A = BR(sig(p, q, r))
        for m in range(0, n + 1):                     # split after m generators
            A1 = BR(A.eps[:m]); A2 = BR(A.eps[m:]); lo = (1 << m) - 1
            for a in range(A.M):
                a1, a2 = a & lo, a >> m
                for b in range(A.M):
                    b1, b2 = b & lo, b >> m
                    okG &= A.s(a, b) == A1.s(a1, b1) * A2.s(a2, b2) * (-1) ** (popcount(a2) * popcount(b1))
report('GT', okG, 'Koszul factorisation of the sign over every split, every label pair, every signature with n <= 6: concatenation = graded tensor product')

# ---------------------------------------------------------------- RAD, LOE
def trace_form_kernel_dim(A):
    # T[a][b] = trace of left multiplication by e_a e_b = s(a,b) * trace(L_{e_{a^b}}); trace(L_{e_c}) = 0 unless c = 0 (permutation without fixed points) else 2^n
    T = [[(A.s(a, b) * A.M if (a ^ b) == 0 else 0) for b in range(A.M)] for a in range(A.M)]
    return A.M - rank_fr([{c: T[r][c] for c in range(A.M)} for r in range(A.M)], A.M)
okR = okL = True
for n in range(1, 7):
    for (p, q, r) in triples(n):
        A = BR(sig(p, q, r)); nullmask = ((1 << n) - 1) ^ ((1 << (p + q)) - 1)
        J = [a for a in range(A.M) if a & nullmask]
        okR &= trace_form_kernel_dim(A) == len(J) == A.M - 2 ** (p + q)
        okR &= all((A.s(a, b) == 0) or ((a ^ b) & nullmask) for a in J for b in range(A.M))    # ideal (two-sided: s(b,a) likewise)
        okR &= all((A.s(b, a) == 0) or ((a ^ b) & nullmask) for a in J for b in range(A.M))
        # Loewy: J^k = span of labels with >= k null bits.  Compute J^k iteratively as a label set (products of labels are +- labels or 0).
        Jk = set(J); k = 1; layers = []
        while Jk:
            expected = {a for a in range(A.M) if popcount(a & nullmask) >= k}
            okL &= Jk == expected
            layers.append(len(Jk))
            Jk = {a ^ b for a in Jk for b in J if A.s(a, b) != 0}; k += 1
        okL &= k - 1 == r and layers == [sum(__import__('math').comb(r, j) * 2 ** (p + q) for j in range(i, r + 1)) for i in range(1, r + 1)]
report('RAD', okR, 'radical (trace-form kernel) = span of labels with a null bit, dimension 2^n - 2^{p+q}, two-sided ideal; all signatures n <= 6')
report('LOE', okL, 'J^k = labels with >= k null bits, layers C(r,k) 2^{p+q}, Loewy length r+1; all signatures n <= 6')

# ---------------------------------------------------------------- SC, CEN
def solve_supercentre(A):
    dim = 0
    for parity in (0, 1):
        labels = [a for a in range(A.M) if popcount(a) % 2 == parity]
        rows = []     # equations: for each generator i and each output label c, coefficient of z_a
        for i in range(A.n):
            eq = {}
            for a in labels:
                sgn = (-1) ** (parity * 1)   # z e_i - (-1)^{|z|*1} e_i z
                v1 = A.s(a, 1 << i); v2 = A.s(1 << i, a)
                c = a ^ (1 << i)
                if v1: eq.setdefault(c, {})[a] = eq.setdefault(c, {}).get(a, 0) + v1
                if v2: eq.setdefault(c, {})[a] = eq.setdefault(c, {}).get(a, 0) - sgn * v2
            rows.extend(eq.values())
        # unknowns indexed by position in labels
        pos = {a: k for k, a in enumerate(labels)}
        rk = rank_fr([{pos[a]: v for a, v in row.items() if v != 0} for row in rows], len(labels))
        dim += len(labels) - rk
    return dim
okS = True
for n in range(1, 6):
    for (p, q, r) in triples(n):
        okS &= solve_supercentre(BR(sig(p, q, r))) == 2 ** r
report('SC', okS, 'super-centre dimension 2^r for all signatures n <= 5 (solved as a linear system against the generators)')
okC = True
for n in range(1, 7):
    for p in range(n + 1):
        A = BR(sig(p, n - p)); F = A.M - 1
        cen = [a for a in range(A.M) if all(A.s(a, 1 << i) == A.s(1 << i, a) for i in range(n))]
        okC &= cen == ([0] if n % 2 == 0 else [0, F])
report('CEN', okC, 'centre of Cl(p,q): {1} for n even, {1, pseudoscalar} for n odd (n <= 6)')

# ---------------------------------------------------------------- GRA
okA = True
for n in range(1, 7):
    for p in range(n + 1):
        A = BR(sig(p, n - p)); F = A.M - 1
        if n % 2 == 1 and A.sq(F) == 1:
            okA &= popcount(F) % 2 == 1          # the idempotents (1 +- e_F)/2 mix parities: not graded
report('GRA', okA, 'for r = 0, n odd with w^2 = +1 the central idempotents (1 +- w)/2 are inhomogeneous (w odd): no graded ideal; for r >= 1 the radical is graded (spanned by labels)')

# ---------------------------------------------------------------- GL
okGL = True
for n in range(1, 7):
    for (p, q, r) in triples(n):
        # relation lattice in Z^n: 2 g_i for each invertible generator; rank p+q; universal group Z^n / lattice = Z_2^{p+q} x Z^r
        rows = [{i: 2} for i in range(n) if sig(p, q, r)[i] != 0]
        okGL &= (rank_fr(rows, n) if rows else 0) == p + q
report('GL', okGL, 'label-homogeneous gradings: universal group Z_2^{p+q} x Z^r, free rank r (n <= 6)')
print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
