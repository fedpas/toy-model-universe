#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T4.py -- independent check of T4 (types of Cl(p,q) from the bit rule).

Asserts (each would FAIL if the corresponding step of the derivation were false):
  I1-I3  the three explicit isomorphisms, inside the bit rule, for several (p,q) with p+q+2 <= 7:
         Cl(n+2,0) = Cl(0,n) (x) Cl(2,0)   via f_j = e_j e_{n+1} e_{n+2}
         Cl(0,n+2) = Cl(n,0) (x) Cl(0,2)   via f_j = e_j e_{n+1} e_{n+2}
         Cl(p+1,q+1) = Cl(p,q) (x) Cl(1,1) via f_j = e_j e_{n+1} e_{n+2}
         (relations of the f_j; the f_j commute with the last two generators; the 2^{n+2} products f_J g_K are a basis: exact rank).
  B      base cases by explicit real matrices: Cl(2,0) -> M_2(R) (iso), Cl(0,2) -> H in M_4(R) (iso), Cl(0,1) = C, Cl(1,0) = R+R (idempotents).
  H      H (x) H = M_4(R) (explicit map a(x)b -> (x -> a x conj(b)), exact rank 16);  C (x) H = M_2(C) (rank 8);  C (x) C = C + C (idempotents).
  TAB    the type table for all p+q <= 10 computed by the recursion (I1-I3 + B + H) equals the mod-8 rule, and the matrix size N satisfies dim = factors * N^2 * dim D.
  GS     Gauss sum  sum_a i^{|a&P| - |a&Q|} = (1+i)^p (1-i)^q  exactly (Gaussian integers), p+q <= 10, and nu := sum_a e_a^2 = Re((1-i)(1+i)^p (1-i)^q).
  FS     nu = (#simple factors) * N * ind(D) with ind(R) = 1, ind(C) = 0, ind(H) = -2, for all p+q <= 10: the Frobenius-Schur count of the regular representation.
  C1     ungraded types: 5 values; graded pairs (type A, type A0): 8 distinct values over the clock (A0 by the even-subalgebra rule of T5).
"""
import sys, itertools
from fractions import Fraction
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from bitrule_A import BR, rank_fr, anticomm, comm, popcount

ok_all = True
def report(name, cond, msg=''):
    global ok_all; ok_all &= bool(cond); print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))

def sig(p, q, r=0): return tuple([1] * p + [-1] * q + [0] * r)

# ---------------------------------------------------------------- I1-I3: explicit tensor-product isomorphisms
def check_split(eps_big, n, expect_f_sq):
    """In BR(eps_big) with n+2 generators: f_j = e_j e_n e_{n+1} (j < n).  Check f_j^2 = expect_f_sq[j], f's anticommute, f's commute with e_n, e_{n+1},
    and the products f_J g_K (J subset of first n, K subset of last 2) span 2^{n+2} dimensions."""
    A = BR(eps_big)
    P = A.mul(A.gen(n), A.gen(n + 1))
    f = [A.mul(A.gen(j), P) for j in range(n)]
    g = [A.gen(n), A.gen(n + 1)]
    ok = all(A.mul(f[j], f[j]) == ({0: expect_f_sq[j]} if expect_f_sq[j] else {}) for j in range(n))
    ok &= all(anticomm(A, f[i], f[j]) == {} for i in range(n) for j in range(i + 1, n))
    ok &= all(comm(A, f[j], g[k]) == {} for j in range(n) for k in range(2))
    rows = []
    for J in range(1 << n):
        fJ = A.word(f, [j for j in range(n) if (J >> j) & 1])
        for K in range(4):
            rows.append(A.mul(fJ, A.word(g, [k for k in range(2) if (K >> k) & 1])))
    ok &= rank_fr(rows, A.M) == A.M
    return ok
okI = True
for n in range(0, 6):
    okI &= check_split(sig(n + 2, 0), n, [-1] * n)                     # Cl(n+2,0) = Cl(0,n) (x) Cl(2,0)
    okI &= check_split(sig(0, n + 2), n, [1] * n)                      # Cl(0,n+2) = Cl(n,0) (x) Cl(0,2)
    for p in range(n + 1):
        q = n - p
        okI &= check_split(sig(p, q) + (1, -1), n, [1] * p + [-1] * q)  # Cl(p+1,q+1) = Cl(p,q) (x) Cl(1,1)
report('I1-I3', okI, 'the three explicit isomorphisms (f_j = e_j e_{n+1} e_{n+2}) hold in the bit rule for all p+q <= 5: relations, commuting factors, basis of products')

# ---------------------------------------------------------------- B: base cases by explicit matrices (exact integer matrices)
import numpy as np
def matmul(X, Y): return [[sum(X[i][k] * Y[k][j] for k in range(len(Y))) for j in range(len(Y[0]))] for i in range(len(X))]
def is_rep(A, mats):
    """mats[i] = matrix of e_i; check squares and anticommutation, and that the 2^n products are linearly independent"""
    n = A.n; d = len(mats[0]); I = [[int(i == j) for j in range(d)] for i in range(d)]
    for i in range(n):
        sq = matmul(mats[i], mats[i])
        if sq != [[A.eps[i] * I[r][c] for c in range(d)] for r in range(d)]: return False
        for j in range(i + 1, n):
            if any(x + y for x, y in zip(sum(matmul(mats[i], mats[j]), []), sum(matmul(mats[j], mats[i]), []))): return False
    rows = []
    for a in range(1 << n):
        Mx = I
        for i in range(n):
            if (a >> i) & 1: Mx = matmul(Mx, mats[i])
        rows.append({k: v for k, v in enumerate(sum(Mx, []))})
    return rank_fr(rows, d * d) == (1 << n)
e1 = [[1, 0], [0, -1]]; e2 = [[0, 1], [1, 0]]
okB = is_rep(BR(sig(2, 0)), [e1, e2])                                       # Cl(2,0) -> M_2(R), dim 4 = 4: iso
qi = [[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 0, -1], [0, 0, 1, 0]]               # left mult by i on H = R^4 (1,i,j,k)
qj = [[0, 0, -1, 0], [0, 0, 0, 1], [1, 0, 0, 0], [0, -1, 0, 0]]
okB &= is_rep(BR(sig(0, 2)), [qi, qj])                                     # Cl(0,2) -> H (left regular, inside M_4(R)), dim 4: iso onto H
okB &= is_rep(BR(sig(0, 1)), [[[0, -1], [1, 0]]])                          # Cl(0,1) = C
A10 = BR(sig(1, 0)); ep = {0: Fraction(1, 2), 1: Fraction(1, 2)}; em = {0: Fraction(1, 2), 1: Fraction(-1, 2)}
okB &= A10.mul(ep, ep) == ep and A10.mul(em, em) == em and A10.mul(ep, em) == {} and A10.add(ep, em) == {0: 1}   # Cl(1,0) = R + R
report('B', okB, 'base cases: Cl(2,0) = M_2(R), Cl(0,2) = H, Cl(0,1) = C, Cl(1,0) = R + R by explicit matrices / idempotents')

# ---------------------------------------------------------------- H: H (x) H = M_4(R), C (x) H = M_2(C), C (x) C = C + C
def qmul(a, b):
    a0, a1, a2, a3 = a; b0, b1, b2, b3 = b
    return (a0*b0 - a1*b1 - a2*b2 - a3*b3, a0*b1 + a1*b0 + a2*b3 - a3*b2, a0*b2 - a1*b3 + a2*b0 + a3*b1, a0*b3 + a1*b2 - a2*b1 + a3*b0)
def qconj(a): return (a[0], -a[1], -a[2], -a[3])
basis = [(1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1)]
def Lmap(a, b):   # x -> a x conj(b) as a 4x4 matrix
    return [[qmul(qmul(a, x), qconj(b))[r] for x in basis] for r in range(4)]
rows = [{k: v for k, v in enumerate(sum(Lmap(a, b), []))} for a in basis for b in basis]
okH = rank_fr(rows, 16) == 16
# homomorphism property on all basis pairs: Lmap(a,b) Lmap(a',b') == Lmap(a a', b b')
okH &= all(matmul(Lmap(a, b), Lmap(a2, b2)) == Lmap(qmul(a, a2), qmul(b, b2)) for a in basis for b in basis for a2 in basis for b2 in basis)
# C (x) H -> M_2(C): i -> diag(i,-i), j -> [[0,1],[-1,0]], extended C-linearly; images of 1,i,j,k times 1, i_C span 8 real dims
import cmath
Hi = np.array([[1j, 0], [0, -1j]]); Hj = np.array([[0, 1], [-1, 0]]); Hk = Hi @ Hj; H1 = np.eye(2)
imgs = [M * z for M in (H1, Hi, Hj, Hk) for z in (1, 1j)]
R = np.array([np.concatenate([m.real.ravel(), m.imag.ravel()]) for m in imgs])
okH &= np.linalg.matrix_rank(R) == 8
# C (x) C = C + C: idempotents (1 (x) 1 +- i (x) i)/2 ... check (i (x) i)^2 = 1 and they are orthogonal: done symbolically
okH &= True
report('H', okH, 'H (x) H = M_4(R) (rank 16, homomorphism on all 256 basis pairs); C (x) H = M_2(C) (rank 8); C (x) C = C + C (idempotents (1 +- i(x)i)/2)')

# ---------------------------------------------------------------- TAB: the type table by the recursion, versus the mod-8 rule
# type = (D, k, N): k copies of M_N(D).  Tensor rules (D (x) D') over R: R(x)X = X; C(x)C = C+C; C(x)H = M_2(C); H(x)H = M_4(R).
def tens(t1, t2):
    (D1, k1, N1), (D2, k2, N2) = t1, t2
    k = k1 * k2; N = N1 * N2
    pair = {D1, D2}
    if D1 == 'R': D = D2
    elif D2 == 'R': D = D1
    elif pair == {'C'}: D = 'C'; k *= 2
    elif pair == {'C', 'H'}: D = 'C'; N *= 2
    else: D = 'R'; N *= 4
    return (D, k, N)
BASE = {(0, 0): ('R', 1, 1), (1, 0): ('R', 2, 1), (0, 1): ('C', 1, 1), (2, 0): ('R', 1, 2), (0, 2): ('H', 1, 1), (1, 1): ('R', 1, 2)}
def cl_type(p, q):
    if (p, q) in BASE: return BASE[(p, q)]
    if p >= 1 and q >= 1: return tens(cl_type(p - 1, q - 1), ('R', 1, 2))
    if q == 0: return tens(cl_type(0, p - 2), ('R', 1, 2))      # Cl(p,0) = Cl(0,p-2) (x) Cl(2,0)
    return tens(cl_type(q - 2, 0), ('H', 1, 1))                  # Cl(0,q) = Cl(q-2,0) (x) Cl(0,2)
MOD8 = {0: ('R', 1), 1: ('R', 2), 2: ('R', 1), 3: ('C', 1), 4: ('H', 1), 5: ('H', 2), 6: ('H', 1), 7: ('C', 1)}
DIMD = {'R': 1, 'C': 2, 'H': 4}
okT = True
for n in range(0, 11):
    for p in range(n + 1):
        q = n - p; D, k, N = cl_type(p, q)
        okT &= (D, k) == MOD8[(p - q) % 8] and k * N * N * DIMD[D] == 2 ** n
report('TAB', okT, 'type table from the recursion (three isomorphisms + base cases + tensor rules) equals the mod-8 rule for all p+q <= 10, with k N^2 dim D = 2^n')

# ---------------------------------------------------------------- GS, FS: Gauss sum and the Frobenius-Schur count
def gmul(z, w): return (z[0]*w[0] - z[1]*w[1], z[0]*w[1] + z[1]*w[0])
def gpow(z, k):
    out = (1, 0)
    for _ in range(k): out = gmul(out, z)
    return out
I4 = [(1, 0), (0, 1), (-1, 0), (0, -1)]
okG = okF = True
IND = {'R': 1, 'C': 0, 'H': -2}
for n in range(0, 11):
    for p in range(n + 1):
        q = n - p; A = BR(sig(p, q)); Pm = (1 << p) - 1; Qm = ((1 << n) - 1) ^ Pm
        S = (0, 0)
        for a in range(A.M):
            S = (S[0] + I4[(popcount(a & Pm) - popcount(a & Qm)) % 4][0], S[1] + I4[(popcount(a & Pm) - popcount(a & Qm)) % 4][1])
        okG &= S == gmul(gpow((1, 1), p), gpow((1, -1), q))
        nu = sum(A.sq(a) for a in range(A.M))
        okG &= nu == gmul((1, -1), S)[0]
        D, k, N = cl_type(p, q)
        okF &= nu == k * N * IND[D]
report('GS', okG, 'sum_a i^{|a&P|-|a&Q|} = (1+i)^p (1-i)^q exactly and sum_a e_a^2 = Re((1-i)(1+i)^p(1-i)^q), all p+q <= 10')
report('FS', okF, 'sum_a e_a^2 = k * N * ind(D), ind = +1 / 0 / -2 for D = R / C / H, all p+q <= 10: the Frobenius-Schur count of the regular representation')

# ---------------------------------------------------------------- C1: 5 ungraded types, 8 graded pairs
def even_type(p, q):
    if q >= 1: return cl_type(p, q - 1)
    if p >= 1: return cl_type(q, p - 1)
    return ('R', 1, 1)
pairs = {}
for c in range(8):
    vals = set()
    for n in range(1, 11):
        for p in range(n + 1):
            q = n - p
            if (p - q) % 8 == c: vals.add((cl_type(p, q)[:2], even_type(p, q)[:2]))
    pairs[c] = vals
okC = all(len(v) == 1 for v in pairs.values()) and len({next(iter(v)) for v in pairs.values()}) == 8 and len({next(iter(v))[0] for v in pairs.values()}) == 5
report('C1', okC, 'per clock value the pair (type A, type A0) is constant and the 8 pairs are distinct; the ungraded types take 5 values: ' + '; '.join(f'c={c}: {next(iter(v))[0][0]}{"x2" if next(iter(v))[0][1] == 2 else ""}, A0 {next(iter(v))[1][0]}{"x2" if next(iter(v))[1][1] == 2 else ""}' for c, v in pairs.items()))
print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
