#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T20: the label set is the Fock basis; Cl(m,m) = End(Lambda(R^m)) (independent code, exact integers).
For m = 1..5 on the 2^m labels:
 A. left multiplication by e_i in the all-null rule Cl(0,0,m) is the creation operator (wedge) c_i^+;
    its transpose is the contraction c_i (defined separately by the formula e_S -> [i in S] (-1)^{#(j in S, j<i)} e_{S-i}).
 B. the bit rule with eps_i = +1 / -1 gives L_{e_i} = c_i^+ + c_i / c_i^+ - c_i (exact matrix equality).
 C. CAR: {c_i, c_j^+} = delta_ij, {c_i, c_j} = {c_i^+, c_j^+} = 0.
 D. gamma_i = c_i^+ + c_i, gammat_i = c_i^+ - c_i: squares +1 / -1, pairwise anticommuting (2m generators of Cl(m,m)).
 E. the 4^m ordered products of these generators are linearly independent and span all 2^m x 2^m matrices
    (rank 4^m), and every matrix unit |S><T| equals c_S^+ P0 c_T (P0 = prod_i c_i c_i^+ the vacuum projector).
 F. Fock basis: c_{s1}^+ ... c_{sk}^+ |0> = e_S (s1 < ... < sk) with sign +1; number operator sum c_i^+ c_i = popcount,
    = sum (1 - gamma_i gammat_i)/2.
 G. super-trace: str(1) = 0, str(XY + YX) = 0 for random odd X, Y; tr([X, Y]) = 0 for any X, Y (no finite CCR).
 H. in the bit-rule Cl(m,m) (bits 0..m-1 square +1, bits m..2m-1 square -1): n_i = (e_i + f_i)/2, nt_i = (e_i - f_i)/2
    satisfy n_i^2 = 0, {n_i, nt_j} = delta_ij, {n_i, n_j} = {nt_i, nt_j} = 0 (Witt pairs), m <= 3.
Would fail if the creation/annihilation identification, a sign, the CAR, or the dimension count were wrong."""
import itertools
import numpy as np
from clC import Alg, popcount

fails = 0
count = 0


def ok(cond, msg):
    global fails, count
    count += 1
    if not cond:
        fails += 1
        print('FAIL', msg)


def contraction(m, i):
    N = 1 << m
    M = np.zeros((N, N), dtype=np.int64)
    for S in range(N):
        if S >> i & 1:
            sgn = -1 if popcount(S & ((1 << i) - 1)) % 2 else 1
            M[S ^ (1 << i), S] = sgn
    return M


def Lgen(A, i):
    N = A.N
    M = np.zeros((N, N), dtype=np.int64)
    for b in range(N):
        s = A.S[1 << i, b]
        if s:
            M[(1 << i) ^ b, b] = s
    return M


for m in range(1, 6):
    N = 1 << m
    I = np.eye(N, dtype=np.int64)
    Anull, Apos, Aneg = Alg([0] * m), Alg([1] * m), Alg([-1] * m)
    cd = [Lgen(Anull, i) for i in range(m)]
    c = [contraction(m, i) for i in range(m)]
    for i in range(m):
        ok(np.array_equal(cd[i].T, c[i]), f'A: transpose of creation = contraction m={m} i={i}')
        ok(np.array_equal(Lgen(Apos, i), cd[i] + c[i]), f'B: eps=+1 gives c+ + c, m={m}')
        ok(np.array_equal(Lgen(Aneg, i), cd[i] - c[i]), f'B: eps=-1 gives c+ - c, m={m}')
        for j in range(m):
            ok(np.array_equal(c[i] @ cd[j] + cd[j] @ c[i], I * (i == j)), 'C: {c_i, c_j^+} = delta')
            ok(not (c[i] @ c[j] + c[j] @ c[i]).any(), 'C: {c_i, c_j} = 0')
            ok(not (cd[i] @ cd[j] + cd[j] @ cd[i]).any(), 'C: {c_i^+, c_j^+} = 0')
    g = [cd[i] + c[i] for i in range(m)]
    gt = [cd[i] - c[i] for i in range(m)]
    gens = g + gt
    sq = [1] * m + [-1] * m
    for a in range(2 * m):
        ok(np.array_equal(gens[a] @ gens[a], sq[a] * I), 'D: squares')
        for b in range(a + 1, 2 * m):
            ok(not (gens[a] @ gens[b] + gens[b] @ gens[a]).any(), 'D: anticommute')
    # E: products of generators over all 2m-bit labels
    if m <= 4:
        rows = []
        for lab in range(1 << (2 * m)):
            P = I.copy()
            for a in range(2 * m):
                if lab >> a & 1:
                    P = P @ gens[a]
            rows.append(P.flatten())
        rk = np.linalg.matrix_rank(np.array(rows, dtype=float))
        ok(rk == 4 ** m, f'E: rank {rk} = 4^{m}')
    P0 = I.copy()
    for i in range(m):
        P0 = P0 @ (c[i] @ cd[i])
    vac = np.zeros(N, dtype=np.int64)
    vac[0] = 1
    ok(np.array_equal(P0, np.outer(vac, vac)), 'E: P0 = |0><0|')
    for S in range(N):
        for T in range(N):
            CS = I.copy()
            for i in range(m):
                if S >> i & 1:
                    CS = CS @ cd[i]
            CT = I.copy()
            for i in range(m):
                if T >> i & 1:
                    CT = CT @ cd[i]
            E = CS @ P0 @ CT.T
            U = np.zeros((N, N), dtype=np.int64)
            U[S, T] = 1
            ok(np.array_equal(E, U), f'E: matrix unit S={S} T={T}')
        # F: Fock basis
        CS = I.copy()
        for i in range(m):
            if S >> i & 1:
                CS = CS @ cd[i]
        ok(np.array_equal(CS @ vac, np.eye(N, dtype=np.int64)[S]), 'F: c_S^+|0> = e_S')
    Nop = sum(cd[i] @ c[i] for i in range(m))
    ok(np.array_equal(Nop, np.diag([popcount(S) for S in range(N)])), 'F: number operator = popcount')
    ok(np.array_equal(2 * Nop, sum(I - g[i] @ gt[i] for i in range(m))), 'F: N = sum (1 - gamma gammat)/2')
    # G: super-trace
    par = np.array([(-1) ** popcount(S) for S in range(N)])
    ok(par.sum() == 0, 'G: sdim = 0')
    rng = np.random.default_rng(m)
    odd_mask = np.array([[(popcount(a) + popcount(b)) % 2 for b in range(N)] for a in range(N)])
    for _ in range(5):
        X = rng.integers(-3, 4, (N, N)) * odd_mask
        Y = rng.integers(-3, 4, (N, N)) * odd_mask
        ok(int(np.sum(np.diag(X @ Y + Y @ X) * par)) == 0, 'G: str of an anticommutator of odd operators = 0')
        X2 = rng.integers(-3, 4, (N, N))
        Y2 = rng.integers(-3, 4, (N, N))
        ok(np.trace(X2 @ Y2 - Y2 @ X2) == 0, 'G: trace of a commutator = 0 (no finite CCR)')
    print(f'm = {m}: creation/annihilation, CAR, Cl({m},{m}) generators, matrix units, Fock basis, sdim 0: ok')

# H: Witt pairs inside the bit-rule Cl(m,m)
for m in range(1, 4):
    A = Alg([1] * m + [-1] * m)
    e = [A.blade(1 << i) for i in range(m)]
    f = [A.blade(1 << (m + i)) for i in range(m)]
    n_ = [(e[i] + f[i]) / 2 for i in range(m)]
    nt = [(e[i] - f[i]) / 2 for i in range(m)]
    for i in range(m):
        ok(np.allclose(A.mul(n_[i], n_[i]), 0) and np.allclose(A.mul(nt[i], nt[i]), 0), 'H: n^2 = 0')
        for j in range(m):
            ac = A.mul(n_[i], nt[j]) + A.mul(nt[j], n_[i])
            ok(np.allclose(ac, A.scalar(1.0 if i == j else 0.0)), 'H: {n_i, nt_j} = delta')
            ok(np.allclose(A.mul(n_[i], n_[j]) + A.mul(n_[j], n_[i]), 0), 'H: {n_i, n_j} = 0')
print('H: Witt pairs n_i = (e_i + f_i)/2, nt_i = (e_i - f_i)/2 in the bit-rule Cl(m,m), m = 1..3: ok')
# I: in the Witt (creation/annihilation) basis the C(2m,2) bivectors of Cl(m,m) are m Cartan elements plus
#    2m(m-1) root vectors with roots +-e_i +- e_j (the D_m root system; m = 8 gives 112 + 8 = 120)
for m in range(2, 5):
    N = 1 << m
    I = np.eye(N, dtype=np.int64)
    Anull = Alg([0] * m)
    cd = [Lgen(Anull, i) for i in range(m)]
    c = [contraction(m, i) for i in range(m)]
    H = [cd[k] @ c[k] - I / 2 for k in range(m)]
    gens = [cd[i] + c[i] for i in range(m)] + [cd[i] - c[i] for i in range(m)]
    biv = [gens[a] @ gens[b] for a in range(2 * m) for b in range(a + 1, 2 * m)]
    roots = []
    vecs = []
    for i in range(m):
        for j in range(m):
            for (X, wi, wj) in [(cd[i] @ cd[j], 1, 1), (c[i] @ c[j], -1, -1), (cd[i] @ c[j], 1, -1)]:
                if i == j or (wi == wj and i > j):
                    continue
                w = np.zeros(m)
                w[i] += wi
                w[j] += wj
                for k in range(m):
                    ok(np.allclose(H[k] @ X - X @ H[k], w[k] * X), 'I: root vector weight')
                roots.append(tuple(w))
                vecs.append(X.flatten())
    vecs += [h.flatten() for h in H]
    ok(len(roots) == 2 * m * (m - 1) and len(set(roots)) == len(roots), f'I: {len(roots)} distinct roots')
    span_b = np.linalg.matrix_rank(np.array([b.flatten() for b in biv], dtype=float))
    both = np.linalg.matrix_rank(np.array([b.flatten() for b in biv] + vecs, dtype=float))
    ok(span_b == m * (2 * m - 1) and both == span_b, 'I: root vectors + Cartan span exactly the bivectors')
print('I: Witt-basis bivectors = m Cartan + 2m(m-1) roots +-e_i +- e_j of so(m,m), m = 2..4 (m = 8: 8 + 112 = 120)')
print(f'check_T20: {count - fails} of {count} assertions hold')
if fails:
    raise SystemExit(1)
