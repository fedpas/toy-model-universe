#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T6.py -- independent check of T6 (cube category sign, Koszul complex, H^2(Z_2^n;F_2) = quadratic forms, octonion cochain).

Asserts:
  SQ    the Jordan-Wigner edge sign (-1)^{#{j in a: j < i}} on a -> a+i has product -1 around every square of the n-cube, n <= 7.
  H1    H^1 of the 2-skeleton of the n-cube with F_2 coefficients is 0 (rank computation: dim ker(delta_1) = dim im(delta_0) = 2^n - 1), n <= 5;
        hence any two anticommuting sign assignments differ by a gauge (vertex signs), and the solution set has exactly 2^{2^n - 1} elements
        (brute force 128 on the 3-cube).
  KZ    the Koszul boundary d e_a = sum_{i in a} (-1)^{#{j in a: j<i}} e_{a-i} satisfies d^2 = 0 and the complex is exact (ranks 2^{n-1}), n <= 7;
        the homotopy h = (left wedge by e_0) satisfies dh + hd = id.
  H2    dim H^2(Z_2^n; F_2) (normalised 2-cocycles modulo coboundaries, computed over F_2) = n(n+1)/2 for n <= 4, and the map [f] -> (a -> f(a,a))
        is zero on coboundaries and has image of dimension n(n+1)/2 (= all quadratic forms); the Clifford cocycles (bilinear, upper-triangular)
        realise every quadratic form.
  OCT   the Albuquerque-Majid cochain F on Z_2^3: F(a,a) = -1 for a != 0, F(a,b) = -F(b,a) for distinct non-zero a,b; dF = (-1)^{det(a,b,c)} on all 512
        triples (so F is NOT a cocycle: 168 triples with associator -1); the composition criterion F(a,b)F(a+d,b+d) + F(a,b+d)F(a+d,b) = 0 for all a, b
        and d != 0 (448 cases) which is equivalent to N(xy) = N(x)N(y); and the Cl(0,3) sign on the same labels IS a cocycle and is NOT a composition sign.
"""
import sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from bitrule_A import popcount, N_pairs

ok_all = True
def report(name, cond, msg=''):
    global ok_all; ok_all &= bool(cond); print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))

def jw(a, i): return (-1) ** popcount(a & ((1 << i) - 1))

# ---------------------------------------------------------------- SQ
okS = True
for n in range(2, 8):
    for a in range(1 << n):
        for i in range(n):
            if (a >> i) & 1: continue
            for j in range(i + 1, n):
                if (a >> j) & 1: continue
                okS &= jw(a, i) * jw(a | (1 << i), j) * jw(a, j) * jw(a | (1 << j), i) == -1
report('SQ', okS, 'every square of the n-cube anticommutes with the Jordan-Wigner sign, n <= 7')

# ---------------------------------------------------------------- H1 (F_2 linear algebra with int bit rows)
def f2_rank(rows):
    piv = {}
    for v in rows:
        while v:
            h = v.bit_length() - 1
            if h in piv: v ^= piv[h]
            else: piv[h] = v; break
    return len(piv)
okH1 = True
for n in range(1, 6):
    V = 1 << n
    edges = [(a, i) for a in range(V) for i in range(n) if not (a >> i) & 1]
    eid = {e: k for k, e in enumerate(edges)}
    # delta_0: vertex cochain g -> edge cochain g(a) + g(a+i); as a matrix with rows = edges: row has bits a and a+i
    d0_rows = [(1 << a) | (1 << (a | (1 << i))) for (a, i) in edges]          # columns = vertices
    rk_d0 = f2_rank(d0_rows)                                                   # = dim im(delta_0) (rank of the transpose = rank)
    # delta_1: edge cochain -> square cochain: sum of the 4 edges of each square
    d1_rows = []
    for a in range(V):
        for i in range(n):
            if (a >> i) & 1: continue
            for j in range(i + 1, n):
                if (a >> j) & 1: continue
                d1_rows.append((1 << eid[(a, i)]) | (1 << eid[(a | (1 << i), j)]) | (1 << eid[(a, j)]) | (1 << eid[(a | (1 << j), i)]))
    rk_d1 = f2_rank(d1_rows)
    dim_ker_d1 = len(edges) - rk_d1
    okH1 &= dim_ker_d1 == rk_d0 == V - 1
# brute force on the 3-cube: assignments with all 6 squares anticommuting
V = 8; edges = [(a, i) for a in range(V) for i in range(3) if not (a >> i) & 1]; eid = {e: k for k, e in enumerate(edges)}
cnt = 0
for bitsv in range(1 << 12):
    sgn = lambda a, i: -1 if (bitsv >> eid[(a, i)]) & 1 else 1
    good = True
    for a in range(V):
        for i in range(3):
            if (a >> i) & 1: continue
            for j in range(i + 1, 3):
                if (a >> j) & 1: continue
                if sgn(a, i) * sgn(a | (1 << i), j) * sgn(a, j) * sgn(a | (1 << j), i) != -1: good = False
    cnt += good
okH1 &= cnt == 128
report('H1', okH1, 'H^1(n-cube 2-skeleton; F_2) = 0 for n <= 5 (ker delta_1 = im delta_0, dimension 2^n - 1); 3-cube brute force: 128 = 2^7 anticommuting assignments = one gauge orbit')

# ---------------------------------------------------------------- KZ
from fractions import Fraction
from bitrule_A import rank_fr
okK = True
for n in range(1, 8):
    V = 1 << n
    def d(x):
        out = {}
        for a, c in x.items():
            for i in range(n):
                if (a >> i) & 1:
                    b = a ^ (1 << i); out[b] = out.get(b, 0) + c * jw(a, i)
        return {k: v for k, v in out.items() if v}
    def h(x):   # left wedge by e_0: e_0 e_a = e_{a+0} with sign +1 if 0 not in a
        return {a | 1: c for a, c in x.items() if not a & 1}
    def add(u, w):
        out = {k: u.get(k, 0) + w.get(k, 0) for k in set(u) | set(w)}
        return {k: v for k, v in out.items() if v}
    okK &= all(d(d({a: 1})) == {} for a in range(V))
    okK &= all(add(d(h({a: 1})), h(d({a: 1}))) == {a: 1} for a in range(V))
    if n <= 6:
        rows = [d({a: 1}) for a in range(V)]
        okK &= rank_fr(rows, V) == V // 2          # image dim 2^{n-1}; kernel dim 2^{n-1} = image dim: exact (d^2 = 0 gives im in ker)
report('KZ', okK, 'd^2 = 0 and dh + hd = id (h = wedge by e_0) on all labels for n <= 7; rank d = 2^{n-1} (exact) for n <= 6')

# ---------------------------------------------------------------- H2
okH2 = True
for n in range(1, 5):
    G = 1 << n; pairs = [(a, b) for a in range(G) for b in range(G)]; pid = {p: k for k, p in enumerate(pairs)}
    # normalised cochains: f(0,b) = f(a,0) = 0 imposed as equations; cocycle: f(a,b)+f(a^b,c)+f(a,b^c)+f(b,c) = 0
    eqs = [1 << pid[(0, b)] for b in range(G)] + [1 << pid[(a, 0)] for a in range(G)]
    for a in range(G):
        for b in range(G):
            for c in range(G):
                eqs.append((1 << pid[(a, b)]) ^ (1 << pid[(a ^ b, c)]) ^ (1 << pid[(a, b ^ c)]) ^ (1 << pid[(b, c)]))
    dimZ = G * G - f2_rank(eqs)
    # coboundaries of normalised 1-cochains g (g(0) = 0): (dg)(a,b) = g(a)+g(b)+g(a^b); as vectors in pair space
    cob = []
    for v in range(1, G):
        row = 0
        for (a, b) in pairs:
            if ((a == v) + (b == v) + ((a ^ b) == v)) & 1: row |= 1 << pid[(a, b)]
        cob.append(row)
    dimB = f2_rank(cob)
    okH2 &= dimZ - dimB == n * (n + 1) // 2
    # the map f -> (a -> f(a,a)): zero on coboundaries; image on cocycles has dimension n(n+1)/2
    okH2 &= all(all(((r >> pid[(a, a)]) & 1) == 0 for a in range(G)) for r in cob)
    # Clifford cocycles: bilinear upper-triangular f(a,b) = sum_{i<=j} m_ij a_i b_j realise all quadratic forms q(a) = sum_{i<=j} m_ij a_i a_j
    qforms = set()
    for m in itertools.product((0, 1), repeat=n * (n + 1) // 2):
        M = {}; k = 0
        for i in range(n):
            for j in range(i, n): M[(i, j)] = m[k]; k += 1
        f = lambda a, b: sum(M[(i, j)] * ((a >> i) & 1) * ((b >> j) & 1) for i in range(n) for j in range(i, n)) % 2
        okH2 &= all((f(a, b) + f(a ^ b, c) + f(a, b ^ c) + f(b, c)) % 2 == 0 for a in range(G) for b in range(G) for c in range(G)) if n <= 3 else True
        qforms.add(tuple(f(a, a) for a in range(G)))
    okH2 &= len(qforms) == 2 ** (n * (n + 1) // 2)
report('H2', okH2, 'dim H^2(Z_2^n; F_2) = n(n+1)/2 for n <= 4; the diagonal map kills coboundaries; bilinear upper-triangular cocycles realise all 2^{n(n+1)/2} quadratic forms')

# ---------------------------------------------------------------- OCT
def bits3(a): return [(a >> i) & 1 for i in range(3)]
def fAM(x, y):
    X, Y = bits3(x), bits3(y)
    return (sum(X[i] * Y[j] for i in range(3) for j in range(i, 3)) + Y[0] * X[1] * X[2] + X[0] * Y[1] * X[2] + X[0] * X[1] * Y[2]) % 2
F = lambda x, y: (-1) ** fAM(x, y)
def det2(a, b, c):
    A = [bits3(a), bits3(b), bits3(c)]
    return (A[0][0] * (A[1][1] * A[2][2] + A[1][2] * A[2][1]) + A[0][1] * (A[1][0] * A[2][2] + A[1][2] * A[2][0]) + A[0][2] * (A[1][0] * A[2][1] + A[1][1] * A[2][0])) % 2
def s03(a, b):
    v = (-1) ** N_pairs(a, b)
    for i in range(3):
        if (a >> i) & 1 and (b >> i) & 1: v = -v
    return v
okO = all(F(a, a) == -1 for a in range(1, 8)) and all(F(a, b) == -F(b, a) for a in range(1, 8) for b in range(1, 8) if a != b)
okO &= all(F(a, b) * F(a ^ b, c) * F(a, b ^ c) * F(b, c) == (-1) ** det2(a, b, c) for a in range(8) for b in range(8) for c in range(8))
okO &= sum(det2(a, b, c) for a in range(8) for b in range(8) for c in range(8)) == 168
okO &= all(F(a, b) * F(a ^ d, b ^ d) + F(a, b ^ d) * F(a ^ d, b) == 0 for a in range(8) for b in range(8) for d in range(1, 8))
okO &= all(s03(a, b) * s03(a ^ b, c) == s03(a, b ^ c) * s03(b, c) for a in range(8) for b in range(8) for c in range(8))
okO &= not all(s03(a, b) * s03(a ^ d, b ^ d) + s03(a, b ^ d) * s03(a ^ d, b) == 0 for a in range(8) for b in range(8) for d in range(1, 8))
# N(xy) = N(x) N(y) on random integer vectors as a sanity check of the criterion
import random
rng = random.Random(3)
def omul(x, y):
    out = [0] * 8
    for a in range(8):
        for b in range(8): out[a ^ b] += F(a, b) * x[a] * y[b]
    return out
for _ in range(200):
    x = [rng.randint(-3, 3) for _ in range(8)]; y = [rng.randint(-3, 3) for _ in range(8)]
    okO &= sum(v * v for v in omul(x, y)) == sum(v * v for v in x) * sum(v * v for v in y)
report('OCT', okO, 'Albuquerque-Majid cochain: squares -1, anticommuting, dF = (-1)^det (168 independent triples), composition criterion on 448 cases (+ 200 random N(xy) = N(x)N(y)); the Cl(0,3) sign is a cocycle but not a composition sign')
print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
