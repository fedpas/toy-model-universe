# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T9: W(E_n) mod 2 = O(q) for n = 3..8, the F2 class of E_n/2E_n and A_n/2A_n.

Independent code (own helpers in f2lib.py, nothing from the atlas). Exact integer / F_2 arithmetic.
Asserts (each assert would fail if the statement in T9.md were false):
 A. For n = 3..16: the explicit map a -> (|a| mod 2; a) is an isometry F_2^n (Q of Cl(n,0)) -> E_n/2E_n;
    for n = 1..16: a -> a + |a| e_0 is an isometry F_2^n (Q of Cl(0,n)) -> A_n/2A_n.
 B. Class invariants (n, dim rad, q on rad, Gauss sum) of Cl(n,0) and Cl(0,n) agree iff n = 0 mod 4 (n = 1..20).
 C. |O(q)|: brute-force isometry count = formula for every F2 class met with n <= 6.
 D. For n = 3..8: roots mod 2 = nonsingular vectors outside rad b (plus possibly the radical vector);
    image of W(E_n) in GL(E_n/2E_n) (Schreier-Sims on the transvections of the simple roots) has order |O(q)|;
    |W(E_n)| (Schreier-Sims on the root system) / |image| = kernel order 2,1,1,1,2,2;
    -1 in W iff n in {7, 8} (and for E3 the kernel is the A1 reflection).
 E. Extra (beyond the atlas): n = 9, 10 image order vs |O(q)|.
 F. A6 and E6: same rank and signature, different Arf invariant (the class is not a function of signature).
"""
import sys, time
from fractions import Fraction
from f2lib import *

t0 = time.time()
ok = 0


def check(cond, msg):
    global ok
    if not cond:
        print("FAIL:", msg)
        sys.exit(1)
    ok += 1


# ---------------- A. explicit isometries
for n in range(3, 17):
    R = lorentz_En_simple_roots(n)
    G = gram(R, neg_lorentz)
    q = qtable_from_gram(G)
    seen = set()
    for c in range(1 << n):
        # image of sum c_j alpha_j in I_{1,n}/2 I_{1,n}
        v = [0] * (n + 1)
        for j in range(n):
            if c >> j & 1:
                for t in range(n + 1):
                    v[t] += R[j][t]
        vb = [x & 1 for x in v]
        a = sum(vb[t] << (t - 1) for t in range(1, n + 1))
        k = pc(a)
        assert vb[0] == k % 2, (n, c)
        assert q[c] == (k * (k - 1) // 2) % 2, (n, c)
        seen.add(a)
    check(len(seen) == 1 << n, f"E_{n}/2E_{n} -> Cl({n},0) bijective isometry")
for n in range(1, 17):
    G = cartan_An(n)
    q = qtable_from_gram(G)
    seen = set()
    for c in range(1 << n):
        w = 0  # in F_2^{n+1}, coordinates 0..n ; alpha_j = e_j - e_{j+1}
        for j in range(n):
            if c >> j & 1:
                w ^= (1 << j) ^ (1 << (j + 1))
        a = w >> 1  # coordinates 1..n
        k = pc(a)
        assert (w & 1) == k % 2
        assert q[c] == ((k + 1) * k // 2) % 2, (n, c)
        seen.add(a)
    check(len(seen) == 1 << n, f"A_{n}/2A_{n} -> Cl(0,{n}) bijective isometry")
print(f"A ok: explicit isometries E_n (n=3..16), A_n (n=1..16)  [{time.time()-t0:.1f}s]")


# ---------------- B. class coincidence Cl(n,0) vs Cl(0,n)
def inv_cliff_closed(p, qn):
    """Invariants of Q_{Cl(p,qn)} computed by brute force for n <= 14, else via the binomial Gauss sum."""
    n = p + qn
    return form_invariants(q_clifford(p, qn), n)


for n in range(1, 15):
    i1, i2 = inv_cliff_closed(n, 0), inv_cliff_closed(0, n)
    check((i1 == i2) == (n % 4 == 0), f"Cl({n},0) ~ Cl(0,{n}) iff 4|n  ({i1} {i2})")
# beyond 14: Gauss sums via binomials (b = J - I is the same for both; rad = <1..1> iff n odd)
from math import comb
for n in range(15, 41):
    g1 = sum(comb(n, k) * (-1) ** (k * (k - 1) // 2) for k in range(n + 1))
    g2 = sum(comb(n, k) * (-1) ** (k * (k + 1) // 2) for k in range(n + 1))
    if n % 2 == 0:
        same = (g1 == g2)
    else:
        same = ((n * (n - 1) // 2) % 2 == (n * (n + 1) // 2) % 2)  # q(1..1) must agree first
    check(same == (n % 4 == 0), f"n={n} coincidence via Gauss sums")
print(f"B ok: Cl(n,0) and Cl(0,n) F2 classes coincide iff n = 0 mod 4 (n = 1..40)  [{time.time()-t0:.1f}s]")

# ---------------- C. |O(q)| brute force vs formula
classes = {}
for n in range(1, 7):
    for p in range(n + 1):
        q = q_clifford(p, n - p)
        inv_ = form_invariants(q, n)
        if inv_ not in classes:
            classes[inv_] = q
for inv_, q in sorted(classes.items()):
    n = inv_[0]
    b = brute_order_O(q, n)
    f = order_O_formula(inv_)
    check(b == f, f"|O(q)| brute {b} = formula {f} for {inv_}")
print(f"C ok: |O(q)| brute force = formula for {len(classes)} classes with n <= 6  [{time.time()-t0:.1f}s]")


# ---------------- D. Weyl groups
def int_inv(a):
    n = len(a)
    M = [[Fraction(a[j][i]) for j in range(n)] + [Fraction(int(i == j)) for j in range(n)] for i in range(n)]
    for c in range(n):
        p = next(r for r in range(c, n) if M[r][c] != 0)
        M[c], M[p] = M[p], M[c]
        pv = M[c][c]
        M[c] = [x / pv for x in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c]
                M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    rows = [[int(M[i][n + j]) for j in range(n)] for i in range(n)]
    return tuple(tuple(rows[i][j] for i in range(n)) for j in range(n))


def reflections_int(A):
    n = len(A)
    out = []
    for i in range(n):
        cols = []
        for j in range(n):
            col = [int(t == j) for t in range(n)]
            col[i] -= A[i][j]  # s_i(alpha_j) = alpha_j - A_ij alpha_i  (A symmetric)
            cols.append(tuple(col))
        out.append(tuple(cols))
    return out


def root_system(A):
    n = len(A)
    S = reflections_int(A)
    roots = {tuple(int(t == i) for t in range(n)) for i in range(n)}
    frontier = list(roots)
    while frontier:
        nf = []
        for r in frontier:
            for s in S:
                y = int_apply(s, r)
                if y not in roots:
                    roots.add(y)
                    nf.append(y)
        frontier = nf
    return roots


expected = {3: (12, 6, 2), 4: (120, 120, 1), 5: (1920, 1920, 1), 6: (51840, 51840, 1),
            7: (2903040, 1451520, 2), 8: (696729600, 348364800, 2)}
for n in range(3, 9):
    A = cartan_En(n)
    q = qtable_from_gram(A)
    inv_ = form_invariants(q, n)
    check(inv_ == form_invariants(q_clifford(n, 0), n), f"E_{n} class = Cl({n},0) class")
    roots = root_system(A)
    rad = {x for x in range(1 << n) if all(polar(q, x, 1 << j) == 0 for j in range(n))}
    rclasses = {sum((r[i] & 1) << i for i in range(n)) for r in roots}
    nonsing = {x for x in range(1 << n) if q[x] == 1}
    check(len(rclasses) == len(roots) // 2, f"E_{n}: distinct root pairs give distinct classes")
    check(rclasses <= nonsing and nonsing - rclasses <= rad,
          f"E_{n}: root classes = nonsingular vectors (up to the radical)")
    # image of W in GL(n,2): generated by the transvections of the simple roots
    gens2 = [transvection(q, n, 1 << i) for i in range(n)]
    img = f2_group(gens2, n)
    oimg = img.order()
    oO = order_O_formula(inv_)
    # W itself, acting on roots, base = simple roots
    Sint = reflections_int(A)
    base = [tuple(int(t == i) for t in range(n)) for i in range(n)]
    W = StabChain(Sint, base, int_apply, int_mul, int_inv, int_ident(n))
    oW = W.order()
    minus1 = tuple(tuple(-int(t == j) for t in range(n)) for j in range(n))
    has_m1 = W.contains(minus1)
    eW, eI, eK = expected[n]
    check(oimg == oO == eI, f"E_{n}: |image| {oimg} = |O(q)| {oO} = {eI}")
    check(oW == eW and oW // oimg == eK and oW % oimg == 0, f"E_{n}: |W| {oW}, kernel {oW // oimg}")
    check(has_m1 == (n in (7, 8)), f"E_{n}: -1 in W  is {has_m1}")
    if n == 3:
        # kernel element: the reflection in the A1 root alpha_0 acts trivially mod 2
        check(transvection(q, n, 1) == ident(n), "E_3: s_{alpha_0} acts trivially mod 2")
    print(f"  E_{n}: roots {len(roots)}, |W| = {oW}, image order {oimg} = |O(q)| = {oO}, kernel {oW // oimg}, "
          f"-1 in W: {has_m1}, invariants {inv_}  [{time.time()-t0:.1f}s]")
print("D ok")

# ---------------- E. beyond the atlas: n = 9, 10
for n in (9, 10, 11, 12):
    A = cartan_En(n)
    q = qtable_from_gram(A)
    inv_ = form_invariants(q, n)
    gens2 = [transvection(q, n, 1 << i) for i in range(n)]
    img = f2_group(gens2, n)
    oO = order_O_formula(inv_)
    print(f"  E_{n}: det {det_int(A)}, invariants {inv_}, image of W(E_{n}) mod 2 has order {img.order()}, "
          f"|O(q)| = {oO}, equal: {img.order() == oO}  [{time.time()-t0:.1f}s]")
    check(img.order() == oO, f"E_{n} mod 2 onto O(q)")
print("E ok")

# ---------------- F. the class is not a function of rank and signature
iA6 = form_invariants(qtable_from_gram(cartan_An(6)), 6)
iE6 = form_invariants(qtable_from_gram(cartan_En(6)), 6)
check(det_int(cartan_An(6)) % 2 == 1 and det_int(cartan_En(6)) % 2 == 1, "odd determinants")
check(iA6 != iE6 and iA6[1] == iE6[1] == 0, f"A6 {iA6} and E6 {iE6}: both positive definite rank 6, Arf differs")
print("F ok: A6 (Gauss sum %d) and E6 (Gauss sum %d) are both even, positive definite, rank 6, odd det" % (iA6[3], iE6[3]))

# ---------------- G. S_{n+1} = W(A_n) inside O(Q of Cl(0,n)): onto iff n <= 5
from math import factorial
for n in range(2, 11):
    q = qtable_from_gram(cartan_An(n))
    inv_ = form_invariants(q, n)
    check(inv_ == form_invariants(q_clifford(0, n), n), f"A_{n} class = Cl(0,{n}) class")
    img = f2_group([transvection(q, n, 1 << i) for i in range(n)], n)
    oO = order_O_formula(inv_)
    check(img.order() == factorial(n + 1), f"S_{n+1} acts faithfully mod 2 (n={n})")
    check((oO == factorial(n + 1)) == (n <= 5), f"S_{n+1} = O(q) iff n <= 5 (n={n})")
    print(f"  A_{n}: image = S_{n+1} of order {img.order()}, |O(q)| = {oO}, index {oO // img.order()}")
# n = 11..40 by the order formulas only (the class of Cl(0,n) from its invariants in closed form)
for n in range(11, 41):
    if n % 2 == 0:
        g = sum(comb(n, k) * (-1) ** (k * (k + 1) // 2) for k in range(n + 1))
        oO = order_O_eps(n // 2, 1 if g > 0 else -1)
    else:
        m = (n - 1) // 2
        if (n * (n + 1) // 2) % 2 == 1:
            oO = order_Sp(m)
        else:
            # quotient class: Cl(0,n) with n odd, radical 1..1 singular; Gauss sum = 2 * gamma(quotient)
            g = sum(comb(n, k) * (-1) ** (k * (k + 1) // 2) for k in range(n + 1))
            oO = 2 ** (2 * m) * order_O_eps(m, 1 if g > 0 else -1)
    check(oO > factorial(n + 1), f"index > 1 at n={n}")
print("G ok: S_{n+1} fills O(Q of Cl(0,n)) exactly for n <= 5; index 8, 64, 960 at n = 6, 7, 8; > 1 up to n = 40")

# ---------------- H. certificates: n mutually orthogonal roots in E_7 and E_8 (so -1 is a product of reflections)
for n in (7, 8):
    A = cartan_En(n)
    roots = sorted(root_system(A))
    def ip(u, v):
        return sum(u[i] * A[i][j] * v[j] for i in range(n) for j in range(n))
    best = []
    def rec(chosen, start):
        global best
        if len(chosen) == n:
            best = chosen[:]
            return True
        for t in range(start, len(roots)):
            r = roots[t]
            if all(ip(r, c) == 0 for c in chosen):
                chosen.append(r)
                if rec(chosen, t + 1):
                    return True
                chosen.pop()
        return False
    rec([], 0)
    check(len(best) == n, f"E_{n}: {n} mutually orthogonal roots exist")
    print(f"  E_{n}: mutually orthogonal roots (simple-root coordinates): {best}")
print("H ok")

print(f"ALL {ok} CHECKS PASSED  [{time.time()-t0:.1f}s]")
