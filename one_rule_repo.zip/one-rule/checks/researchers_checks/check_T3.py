#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T3.py -- independent check of T3 (Frobenius duality of the top-label form, Nakayama automorphism, symmetric or not, torsor statements).

Asserts:
  F1   for all 119 signatures with 1 <= n <= 6: lambda(e_a e_b) (coefficient of the full label F) is non-zero iff b = a xor F, with value +-1
       (so the Gram matrix is a signed permutation: non-degenerate), null generators included.
  F2   lambda(e_a e_b) = (-1)^{|a|(n-|a|)} lambda(e_b e_a) on complementary pairs; hence Nakayama = id (n odd) or grade involution alpha (n even).
  F3   n even: the space W = {w : alpha(e_a) w = w e_a for all a} (the elements that would implement alpha by conjugation) is computed exactly;
       for r = 0 it contains the pseudoscalar (a unit) -> symmetric; for r >= 1 every element of W is nilpotent (W inside the radical) -> alpha not
       inner -> no symmetrising form.  n <= 6.  (And a direct rank test: for r >= 1, n even, NO symmetric non-degenerate associative form exists:
       the space of symmetric associative functionals is computed and a random member has degenerate pairing; n <= 5.)
  F4   the scalar-part pairing <e_a e_b>_0 has rank 2^{p+q}.
  TOR  torsor statements on Cl(3,0), Cl(2,1), Cl(1,1,1), Cl(2,0,1): lambda(u .) is non-degenerate iff u is a unit (random u, exact);
       for n odd (Cl(3,0), Cl(2,1)) lambda(z .) is symmetric iff z is central; on Cl(3,0) a NON-central unit u gives a non-degenerate NON-symmetric
       Frobenius form lambda(u .): the Frobenius forms are a torsor under ALL units, only the symmetric ones under the central units.
  C2   on Cl(3,0): lambda(x) = -<w x>_0 with w = e_123 (so the trace form of M_2(C) is lambda(-w .), w a central unit).
"""
import sys, itertools, random
from fractions import Fraction
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from bitrule_A import BR, rank_fr, popcount

ok_all = True
def report(name, cond, msg=''):
    global ok_all; ok_all &= bool(cond); print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))
def sig(p, q, r=0): return tuple([1] * p + [-1] * q + [0] * r)
def triples(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]
rng = random.Random(7)

okF1 = okF2 = okF4 = True
for n in range(1, 7):
    for (p, q, r) in triples(n):
        A = BR(sig(p, q, r)); F = A.M - 1
        for a in range(A.M):
            for b in range(A.M):
                v = A.s(a, b) if (a ^ b) == F else 0
                okF1 &= (v != 0) == (b == (a ^ F)) and (v in (-1, 0, 1))
            b = a ^ F
            okF2 &= A.s(a, b) == (-1) ** (popcount(a) * (n - popcount(a))) * A.s(b, a)
        okF4 &= rank_fr([{a: A.s(a, a)} for a in range(A.M) if A.s(a, a)], A.M) == 2 ** (p + q)
report('F1', okF1, 'top-label pairing non-zero exactly on complementary pairs, values +-1: non-degenerate for all 119 signatures n <= 6')
report('F2', okF2, 'lambda(e_a e_b) = (-1)^{|a|(n-|a|)} lambda(e_b e_a): Nakayama = id (n odd), grade involution (n even)')
report('F4', okF4, 'scalar-part pairing has rank 2^{p+q}')

# ---------------------------------------------------------------- F3: is alpha inner?  W = {w : alpha(e_a) w = w e_a}
def alpha_inner_space(A):
    """solve alpha(e_a) w - w e_a = 0 for all labels a; return basis of solutions as multivectors (dict)"""
    eqs = []
    for a in range(A.M):
        sa = (-1) ** popcount(a)
        eq = {}
        for c in range(A.M):   # w = sum_c w_c e_c
            out = a ^ c
            v = sa * A.s(a, c) - A.s(c, a)
            if v: eq.setdefault(out, {})[c] = v
        eqs.extend(eq.values())
    # nullspace over Q
    M = [[Fraction(e.get(c, 0)) for c in range(A.M)] for e in eqs]
    piv = []; rk = 0
    for col in range(A.M):
        pr = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if pr is None: continue
        M[rk], M[pr] = M[pr], M[rk]; inv = 1 / M[rk][col]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(col); rk += 1
    basis = []
    for free in (c for c in range(A.M) if c not in piv):
        v = {free: Fraction(1)}
        for i, c in enumerate(piv):
            if M[i][free] != 0: v[c] = -M[i][free]
        basis.append(v)
    return basis
def is_nilpotent(A, x):
    y = dict(x)
    for _ in range(A.n + 2):
        y = A.mul(y, x)
        if not y: return True
    return False
okF3 = True; msgs = []
for n in range(2, 7, 2):
    for (p, q, r) in triples(n):
        A = BR(sig(p, q, r)); W = alpha_inner_space(A)
        if r == 0:
            okF3 &= any(set(w.keys()) == {A.M - 1} for w in W)          # pseudoscalar is a solution (a unit)
        else:
            nullmask = ((1 << n) - 1) ^ ((1 << (p + q)) - 1)
            okF3 &= all(all(c & nullmask for c in w) for w in W)          # every solution lies in the radical
            okF3 &= all(is_nilpotent(A, w) for w in W)
            # also: solutions are c e_F + odd null labels, as the proof says
            okF3 &= all(all(c == A.M - 1 or (c & ~nullmask) == 0 and popcount(c) % 2 == 1 for c in w) for w in W)
        msgs.append(f'({p},{q},{r}): dim W = {len(W)}')
report('F3', okF3, 'n even: W = {w: alpha(x) w = w x}; r = 0: contains the pseudoscalar (unit) -> alpha inner -> symmetric; r >= 1: W inside the radical, all nilpotent -> no symmetrising form. ' + ' '.join(msgs))

# direct rank test of symmetric associative forms, n <= 5, n even, r >= 1
def symmetric_forms_degenerate(A, tries=6):
    rows = []
    for a in range(A.M):
        for b in range(a + 1, A.M):
            s1, s2 = A.s(a, b), A.s(b, a)
            if s1 != s2: rows.append({a ^ b: s1 - s2})
    # functionals mu with mu(e_a e_b) = mu(e_b e_a): nullspace
    M = [[Fraction(r_.get(c, 0)) for c in range(A.M)] for r_ in rows]
    piv = []; rk = 0
    for col in range(A.M):
        pr = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if pr is None: continue
        M[rk], M[pr] = M[pr], M[rk]; inv = 1 / M[rk][col]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(col); rk += 1
    basis = []
    for free in (c for c in range(A.M) if c not in piv):
        v = [Fraction(0)] * A.M; v[free] = Fraction(1)
        for i, c in enumerate(piv): v[c] = -M[i][free]
        basis.append(v)
    for _ in range(tries):
        mu = [sum(rng.randint(-5, 5) * v[c] for v in basis) for c in range(A.M)]
        G = [{b: A.s(a, b) * mu[a ^ b] for b in range(A.M) if A.s(a, b) * mu[a ^ b] != 0} for a in range(A.M)]
        if rank_fr(G, A.M) == A.M: return False
    return True
okF3b = all(symmetric_forms_degenerate(BR(sig(p, q, r))) for n in (2, 4) for (p, q, r) in triples(n) if r >= 1)
okF3b &= not symmetric_forms_degenerate(BR(sig(3, 1)))      # control: a symmetric non-degenerate form exists for r = 0
report('F3b', okF3b, 'direct rank test: no symmetric non-degenerate associative functional for n = 2, 4 with r >= 1 (6 random members each); control Cl(3,1) has one')

# ---------------------------------------------------------------- TOR
def regular_matrix(A, u):
    return [{a ^ c: v * A.s(c, a) for c, v in u.items() if A.s(c, a) != 0} for a in range(A.M)]   # row a = coords of u e_a
def is_unit(A, u): return rank_fr(regular_matrix(A, u), A.M) == A.M
def lam_u_nondeg(A, u):
    F = A.M - 1
    G = []
    for a in range(A.M):
        row = {}
        for b in range(A.M):
            x = A.mul(u, A.mul({a: 1}, {b: 1}))
            if F in x: row[b] = x[F]
        G.append(row)
    return rank_fr(G, A.M) == A.M
def lam_u_symmetric(A, u):
    F = A.M - 1
    for a in range(A.M):
        for b in range(a, A.M):
            x = A.mul(u, A.mul({a: 1}, {b: 1})); y = A.mul(u, A.mul({b: 1}, {a: 1}))
            if x.get(F, 0) != y.get(F, 0): return False
    return True
def is_central(A, z): return all(A.mul(z, {a: 1}) == A.mul({a: 1}, z) for a in range(A.M))
okT = True; stats = []
for eps in (sig(3, 0), sig(2, 1), sig(1, 1, 1), sig(2, 0, 1)):
    A = BR(eps); nu = ns = 0
    for t in range(30):
        u = {a: rng.randint(-2, 2) for a in range(A.M)}; u = {k: v for k, v in u.items() if v}
        if not u: continue
        unit = is_unit(A, u); nu += unit
        okT &= lam_u_nondeg(A, u) == unit
        if A.n % 2 == 1 and all(e != 0 for e in eps):
            okT &= lam_u_symmetric(A, u) == is_central(A, u); ns += is_central(A, u)
    stats.append(f'{eps}: {nu} units among 30 random u')
A3 = BR(sig(3, 0)); u = {0: 1, 1: 1}          # 1 + e_1: a unit of Cl(3,0) ((1+e1)(1-e1)/... (1+e1)^2 = 2(1+e1): not a unit!) -> use 2 + e_1
u = {0: 2, 1: 1}
okT &= is_unit(A3, u) and lam_u_nondeg(A3, u) and not lam_u_symmetric(A3, u) and not is_central(A3, u)
report('TOR', okT, 'lambda(u .) non-degenerate iff u unit; for n odd, r = 0 symmetric iff u central; on Cl(3,0) u = 2 + e_1 gives a non-symmetric Frobenius form. ' + '; '.join(stats))

# ---------------------------------------------------------------- C2
w = {7: 1}
okC2 = all(A3.mul({a: 1}, {a ^ 7: 1}).get(7, 0) == -A3.mul(w, A3.mul({a: 1}, {a ^ 7: 1})).get(0, 0) for a in range(8))
report('C2', okC2, 'Cl(3,0): lambda(x) = -<w x>_0 with w = e_123 central, w^2 = -1')
print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
