#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T19: Floquet trio and the spring on the cube (independent code).
 A. M in SL(2,Z) random: X = M - (tr M/2) 1 has X^2 = ((tr M)^2/4 - 1) 1 exactly; in Cl(2,0) = M2(R) coordinates
    X = a e1 + b e2 + c e12 with X^2 = a^2 + b^2 - c^2; tr(M^N) = 2 T_N(tr M / 2) exactly (Chebyshev), N <= 12.
 B. growth of M^N: bounded (elliptic), linear (parabolic, X != 0), exponential (hyperbolic).
 C. Hill's equation psi'' = (V - E) psi with a Kronig-Penney potential: the monodromy from exact piece matrices equals an
    RK4 integration (1e-7), det = 1; the pieces are cos + sin n (n^2 = -1), cosh + sinh n (n^2 = +1), 1 + g n (n^2 = 0);
    at band edges found by bisection of |tr M| = 2, X^2 = 0 and M has eigenvalue +-1 (periodic / antiperiodic solution).
    Dirac comb: tr M / 2 = cos ka + (g/2k) sin ka exactly.
 D. n-cube Laplacian L = nI - A (n <= 8): Walsh vectors w_S(x) = (-1)^{S.x} satisfy L w_S = 2|S| w_S, the 2^n Walsh
    vectors are orthogonal, so the spectrum is 2j with multiplicity C(n,j) (exact integers).
 E. signed network D = sum_i L_{e_i} on Cl(n,0) (n <= 7): symmetric, D^2 = nI, tr D = 0, face flux -1; K = nI - D has
    eigenvalues n -+ sqrt(n), each 2^(n-1) times."""
import numpy as np
from math import comb
from clC import Alg, popcount

rng = np.random.default_rng(19)
fails = 0
count = 0


def ok(cond, msg):
    global fails, count
    count += 1
    if not cond:
        fails += 1
        print('FAIL', msg)


# ---------- A ----------
e1 = np.array([[1, 0], [0, -1]])
e2 = np.array([[0, 1], [1, 0]])
e12 = e1 @ e2
ok(np.array_equal(e1 @ e1, np.eye(2)) and np.array_equal(e2 @ e2, np.eye(2)) and np.array_equal(e1 @ e2, -(e2 @ e1)),
   'Cl(2,0) = M2(R) generators')


def cheb(N, x):
    a, b = 1, x
    if N == 0:
        return a
    for _ in range(N - 1):
        a, b = b, 2 * x * b - a
    return b


def rand_sl2z():
    M = np.eye(2, dtype=object)
    for _ in range(rng.integers(1, 6)):
        k = int(rng.integers(-3, 4))
        G = np.array([[1, k], [0, 1]], dtype=object) if rng.random() < .5 else np.array([[1, 0], [k, 1]], dtype=object)
        M = M.dot(G)
    if rng.random() < .3:
        M = M.dot(np.array([[0, -1], [1, 0]], dtype=object))
    return M


from fractions import Fraction
kinds = {'elliptic': 0, 'parabolic': 0, 'hyperbolic': 0}
for _ in range(300):
    M = rand_sl2z()
    t = M[0, 0] + M[1, 1]
    g = Fraction(t, 2)
    X = M - g * np.eye(2, dtype=object)
    X2 = X.dot(X)
    ok(X2[0, 1] == 0 and X2[1, 0] == 0 and X2[0, 0] == X2[1, 1] == g * g - 1, 'X^2 = (g^2 - 1) 1')
    # Cl(2,0) coordinates of X: X = a e1 + b e2 + c e12
    a = Fraction(X[0, 0]); b = Fraction(X[0, 1] + X[1, 0], 2); c = Fraction(X[0, 1] - X[1, 0], 2)
    ok(a * a + b * b - c * c == g * g - 1, 'X^2 = a^2 + b^2 - c^2')
    P = np.eye(2, dtype=object)
    for N in range(1, 13):
        P = P.dot(M)
        ok(P[0, 0] + P[1, 1] == 2 * cheb(N, g), 'Chebyshev')
    kinds['elliptic' if abs(t) < 2 else 'parabolic' if abs(t) == 2 else 'hyperbolic'] += 1
print('A: X^2 = (tr^2/4 - 1) = a^2 + b^2 - c^2 and tr M^N = 2 T_N(tr M/2), 300 random SL(2,Z):', kinds)

# ---------- B ----------
for name, M in [('elliptic', np.array([[0., -1], [1, 1]])), ('parabolic', np.array([[1., 1], [0, 1]])),
                ('hyperbolic', np.array([[2., 1], [1, 1]])), ('parabolic -I', np.array([[-1., 1], [0, -1]]))]:
    with np.errstate(all='ignore'):
        norms = [np.linalg.norm(np.linalg.matrix_power(M, N)) for N in (10, 100, 1000)]
    if name == 'elliptic':
        ok(max(norms) < 10, 'elliptic bounded')
    elif name.startswith('parabolic'):
        ok(50 < norms[1] / norms[0] * 10 < 200 and 5 < norms[2] / norms[1] < 15, 'parabolic linear growth')
    else:
        ok(norms[1] > 1e30, 'hyperbolic exponential')
print('B: iterates bounded / linear / exponential for |tr| < 2, = 2 (X != 0), > 2')


# ---------- C: Kronig-Penney / Hill ----------
def piece(E, V, l):
    """exact transfer matrix of psi'' = (V - E) psi over length l acting on (psi, psi')"""
    if E > V:
        k = np.sqrt(E - V)
        n = np.array([[0, 1 / k], [-k, 0]])
        return np.cos(k * l) * np.eye(2) + np.sin(k * l) * n, n
    if E < V:
        k = np.sqrt(V - E)
        n = np.array([[0, 1 / k], [k, 0]])
        return np.cosh(k * l) * np.eye(2) + np.sinh(k * l) * n, n
    n = np.array([[0, 1.], [0, 0]])
    return np.eye(2) + l * n, n


pot = [(0.0, 0.7), (6.0, 0.3)]   # (V, length) pieces of one period a = 1


def monodromy(E):
    M = np.eye(2)
    for V, l in pot:
        P, _ = piece(E, V, l)
        M = P @ M
    return M


def rk4(E, steps=2000):
    """numerical integration of psi'' = (V - E) psi, restarting at each jump of V"""
    cols = []
    for y0 in (np.array([1., 0]), np.array([0., 1])):
        y = y0.copy()
        for V, l in pot:
            h = l / steps
            f = lambda yy: np.array([yy[1], (V - E) * yy[0]])
            for _ in range(steps):
                k1 = f(y); k2 = f(y + h / 2 * k1); k3 = f(y + h / 2 * k2); k4 = f(y + h * k3)
                y = y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        cols.append(y)
    return np.array(cols).T


for E in [1.0, 4.0, 9.5, 20.0, 37.0]:
    M = monodromy(E)
    ok(abs(np.linalg.det(M) - 1) < 1e-10, 'det M = 1')
    ok(np.allclose(M, rk4(E), atol=1e-7), f'exact pieces = RK4 at E={E}')
for E, V in [(5.0, 2.0), (1.0, 2.0), (2.0, 2.0)]:
    _, n = piece(E, V, 0.3)
    want = -1 if E > V else (1 if E < V else 0)
    ok(np.allclose(n @ n, want * np.eye(2)), 'piece generator squares -1 / +1 / 0')
# band edges by bisection of f(E) = |tr M| - 2
Es = np.linspace(0.05, 90, 6000)
f = np.array([abs(np.trace(monodromy(E))) - 2 for E in Es])
edges = []
for i in range(len(Es) - 1):
    if f[i] * f[i + 1] < 0:
        lo, hi = Es[i], Es[i + 1]
        for _ in range(60):
            mid = (lo + hi) / 2
            if (abs(np.trace(monodromy(lo))) - 2) * (abs(np.trace(monodromy(mid))) - 2) <= 0:
                hi = mid
            else:
                lo = mid
        edges.append((lo + hi) / 2)
for E in edges:
    M = monodromy(E)
    g = np.trace(M) / 2
    X = M - g * np.eye(2)
    ok(np.allclose(X @ X, 0, atol=1e-7), 'X^2 = 0 at a band edge')
    ev = np.linalg.eigvals(M)
    ok(np.allclose(ev, np.sign(g), atol=1e-3), 'eigenvalue +-1 at a band edge')
ok(len(edges) >= 4, f'found {len(edges)} edges')
print(f'C: Kronig-Penney monodromy = RK4, det 1; {len(edges)} band edges up to E = 90, X^2 = 0 at each')
# Dirac comb: kick (psi' jumps by g psi) after free flight of length a
for k, g, a in [(1.3, 0.7, 1.0), (2.9, -1.1, 0.8), (0.4, 3.0, 2.0)]:
    free = np.array([[np.cos(k * a), np.sin(k * a) / k], [-k * np.sin(k * a), np.cos(k * a)]])
    kick = np.array([[1, 0], [g, 1]])
    ok(np.isclose(np.trace(kick @ free) / 2, np.cos(k * a) + g / (2 * k) * np.sin(k * a)), 'Dirac comb')
    ok(np.allclose((kick - np.eye(2)) @ (kick - np.eye(2)), 0), 'kick generator squares to 0')
print('C: Dirac comb tr/2 = cos ka + (g/2k) sin ka')

# ---------- D: cube Laplacian ----------
for n in range(1, 9):
    N = 1 << n
    Adj = np.zeros((N, N), dtype=np.int64)
    for x in range(N):
        for i in range(n):
            Adj[x, x ^ (1 << i)] = 1
    L = n * np.eye(N, dtype=np.int64) - Adj
    W = np.array([[(-1) ** popcount(S & x) for x in range(N)] for S in range(N)], dtype=np.int64)
    ok(np.array_equal(W @ W.T, N * np.eye(N, dtype=np.int64)), 'Walsh orthogonal')
    for S in range(N):
        ok(np.array_equal(L @ W[S], 2 * popcount(S) * W[S]), 'L w_S = 2|S| w_S')
    mult = {}
    for S in range(N):
        mult[2 * popcount(S)] = mult.get(2 * popcount(S), 0) + 1
    ok(all(mult[2 * j] == comb(n, j) for j in range(n + 1)), 'multiplicity C(n,j)')
print('D: n-cube Laplacian spectrum 2j with multiplicity C(n,j), Walsh eigenvectors, n = 1..8')

# ---------- E: signed network ----------
for n in range(1, 8):
    A = Alg([1] * n)
    N = A.N
    D = np.zeros((N, N), dtype=np.int64)
    for i in range(n):
        for b in range(N):
            D[(1 << i) ^ b, b] += A.S[1 << i, b]
    ok(np.array_equal(D, D.T), 'D symmetric')
    ok(np.array_equal(D @ D, n * np.eye(N, dtype=np.int64)), 'D^2 = n I')
    ok(np.trace(D) == 0, 'tr D = 0')
    for x in range(N):
        for i in range(n):
            for j in range(i + 1, n):
                y, z, w = x ^ (1 << i), x ^ (1 << i) ^ (1 << j), x ^ (1 << j)
                ok(D[y, x] * D[z, y] * D[w, z] * D[x, w] == -1, 'flux pi')
    ev = np.sort(np.linalg.eigvalsh((n * np.eye(N) - D).astype(float)))
    ok(np.allclose(ev[:N // 2], n - np.sqrt(n)) and np.allclose(ev[N // 2:], n + np.sqrt(n)), 'levels n -+ sqrt n')
print('E: signed network D^2 = nI, tr 0, flux -1 on every face, K = nI - D has n -+ sqrt(n) each 2^(n-1) times, n = 1..7')
print(f'check_T19: {count - fails} of {count} assertions hold')
if fails:
    raise SystemExit(1)
