#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T17: bivector squares and the rotation / boost / translation trichotomy (independent code).
Asserts (exactly with integers where possible, else to 1e-9):
 A. every bivector B in every signature (p,q,r), n <= 6: B^2 has grades 0 and 4 only,
    <B^2>_0 = -sum eps_i eps_j B_ij^2, <B^2>_4 = B ^ B (outer product computed separately).
 B. B ^ B = 0  <=>  rank of the skew matrix (B_ij) <= 2  <=> B simple (random low-rank integer B, n <= 6).
 C. simple B = u ^ v: B^2 = (u.v)^2 - u^2 v^2 = -det Gram(u,v); the vector flow generator D(x) = x.B satisfies
    D^3 = s D (s = B^2), so exp(tD) is trigonometric / polynomial / hyperbolic; for s = 0 three kinds: a plane of Gram
    rank 1 has D^2 = 0 exactly when its radical is a null direction of the whole space (translation), else D^2 != 0
    (null rotation); a plane of Gram 0 (totally null: two orthogonal independent null vectors) has D^2 = 0. Among the
    non-degenerate cells the totally null plane needs min(p,q) >= 2; the targeted examples are Cl(3,1), Cl(3,0,1), Cl(2,2).
    exp(tB) closed forms against the power series.
 D. n = 4: lambda^2 - S lambda + W^2 I^2/4 = 0; complex roots only in Cl(2,2) (sampling), the AM-GM bound in the
    definite cells (exact on integers); the invariant decomposition b_i = B(T - lambda_i)/(lambda_j - lambda_i) with
    T = (B^B)/2 gives commuting simple b_i, b_i^2 = lambda_i, b1 + b2 = B, exp(B) = exp(b1) exp(b2)
    in (4,0), (3,1), (2,2) real cases, (1,3), (0,4); complex case in (2,2) with complex arithmetic.
 E. Cl(3,0,1): Mozzi-Chasles b2 = (B^B) B / (2 B.B) has b2^2 = 0, commutes with b1 = B - b2, b1^2 = B.B.
 F. Riesz example in Cl(2,2): lambda = +- i/2.
 G. ATL-018 frame strain S(h) = h^T eta h - eta: d/dt tr(eta^{-1} S(1 + tA)) at 0 = 2 tr A = 2 d/dt det(1 + tA).
Fails when one of these does not hold: B^2 has a grade-2 part, the scalar formula differs, a simple B has B^B != 0,
D^3 != s D, a real-root signature gives complex roots, or the decomposition formula differs."""
import itertools
import numpy as np
from clC import Alg, exp_mv, reorder_sign

rng = np.random.default_rng(17)
fails = 0
count = 0


def ok(cond, msg):
    global fails, count
    count += 1
    if not cond:
        fails += 1
        print('FAIL', msg)


def sigs(nmax):
    for n in range(1, nmax + 1):
        for r in range(0, n + 1):
            for q in range(0, n - r + 1):
                yield (n - q - r, q, r)


def skew_of(A, B):
    n = A.n
    M = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            M[i, j] = B[(1 << i) | (1 << j)]
            M[j, i] = -M[i, j]
    return M


def dot(A, u, v):
    return sum(A.eps[i] * u[i] * v[i] for i in range(A.n))


# ---------- A: grades of B^2 ----------
nsig = 0
for (p, q, r) in sigs(6):
    A = Alg.pq(p, q, r)
    nsig += 1
    for _ in range(6 if A.n >= 5 else 15):
        B = np.zeros(A.N, dtype=np.int64)
        for (i, j) in A.bivec_index():
            B[(1 << i) | (1 << j)] = rng.integers(-3, 4)
        B2 = A.mul(B, B)
        ok(all(B2[a] == 0 for a in range(A.N) if A.grade[a] not in (0, 4)), f'grade of B^2 {p,q,r}')
        S = -sum(A.eps[i] * A.eps[j] * B[(1 << i) | (1 << j)] ** 2 for (i, j) in A.bivec_index())
        ok(B2[0] == S, f'scalar part {p,q,r}')
        W = A.wedge(B, B)
        ok(np.array_equal(A.gp(B2, 4), W), f'grade-4 part = B^B {p,q,r}')
print(f'A: B^2 = S + B^B, grades 0 and 4 only: {nsig} signatures n <= 6')

# ---------- B: B^B = 0 <=> rank <= 2 ----------
for n in range(2, 7):
    A = Alg([1] * n)
    for _ in range(40):
        k = rng.integers(1, 4)  # number of rank-2 pieces
        M = np.zeros((n, n), dtype=np.int64)
        for _ in range(k):
            u = rng.integers(-2, 3, n)
            v = rng.integers(-2, 3, n)
            M += np.outer(u, v) - np.outer(v, u)
        B = np.zeros(A.N, dtype=np.int64)
        for i in range(n):
            for j in range(i + 1, n):
                B[(1 << i) | (1 << j)] = M[i, j]
        rank = np.linalg.matrix_rank(M.astype(float))
        WW = A.wedge(B, B)
        ok((not WW.any()) == (rank <= 2), f'B^B=0 <=> rank<=2, n={n}, rank={rank}')
print('B: B^B = 0 exactly when rank(B_ij) <= 2 (simple), n = 2..6')


# ---------- C: simple bivectors, flows ----------
def vecmv(A, u):
    return A.vec(u)


def wedge_uv(A, u, v):
    return A.wedge(A.vec(u), A.vec(v))


def Dmat(A, B):
    """matrix of D(x) = x.B = (xB - Bx)/2 on vectors"""
    n = A.n
    M = np.zeros((n, n))
    for k in range(n):
        x = A.blade(1 << k)
        y = (A.mul(x, B) - A.mul(B, x)) / 2
        for i in range(n):
            M[i, k] = y[1 << i]
        ok(np.allclose(A.gp(y, 1), y), 'x.B is a vector')
    return M


kinds = {}
for (p, q, r) in sigs(5):
    A = Alg.pq(p, q, r)
    if A.n < 2:
        continue
    for _ in range(10):
        u = rng.integers(-2, 3, A.n).astype(float)
        v = rng.integers(-2, 3, A.n).astype(float)
        B = wedge_uv(A, u, v)
        if not B.any():
            continue
        s_expected = dot(A, u, v) ** 2 - dot(A, u, u) * dot(A, v, v)
        B2 = A.mul(B, B)
        ok(np.allclose(B2, A.scalar(s_expected)), f'simple B^2 = (u.v)^2 - u^2 v^2 {p,q,r}')
        s = s_expected
        D = Dmat(A, B)
        ok(np.allclose(D @ D @ D, s * D), f'D^3 = sD {p,q,r}')
        # closed form of exp(tB)
        t = 0.37
        E = exp_mv(A, t * B)
        if s < 0:
            w = np.sqrt(-s)
            cf = A.scalar(np.cos(w * t)) + B * np.sin(w * t) / w
            kind = 'rotation'
        elif s > 0:
            w = np.sqrt(s)
            cf = A.scalar(np.cosh(w * t)) + B * np.sinh(w * t) / w
            kind = 'boost'
        else:
            cf = A.scalar(1.0) + t * B
            D2zero = np.allclose(D @ D, 0)
            G = np.array([[dot(A, u, u), dot(A, u, v)], [dot(A, u, v), dot(A, v, v)]])
            if np.allclose(G, 0):
                kind = 'totally null plane'
                ok(D2zero, 'totally null plane => D^2 = 0')
            else:
                w0, V0 = np.linalg.eigh(G)
                c = V0[:, np.argmin(abs(w0))]
                rad = c[0] * u + c[1] * v          # the radical of the plane
                glob = all(abs(A.eps[i] * rad[i]) < 1e-9 for i in range(A.n))  # orthogonal to every vector
                kind = 'translation' if glob else 'null rotation'
                ok(D2zero == glob, f'rank-1 plane: D^2 = 0 <=> its radical is in the radical of the space {p,q,r}')
        ok(np.allclose(E, cf), f'exp closed form {p,q,r} {kind}')
        kinds.setdefault((p, q, r), set()).add(kind)
        # eigenvalues of D: 0 and +-sqrt(s)
        ev = np.linalg.eigvals(D)
        if s > 0:
            ok(np.isclose(max(ev.real), np.sqrt(s)), 'boost eigenvalue')
        if s < 0:
            ok(np.isclose(max(abs(ev.imag)), np.sqrt(-s)), 'rotation eigenvalue')
for (p, q, r), u, v, want in [((3, 1, 0), [1, 0, 0, 0], [0, 1, 0, 1], 'null rotation'),
                              ((3, 0, 1), [1, 0, 0, 0], [0, 0, 0, 1], 'translation'),
                              ((2, 2, 0), [1, 0, 1, 0], [0, 1, 0, 1], 'totally null plane')]:
    A = Alg.pq(p, q, r)
    u = np.array(u, float); v = np.array(v, float)
    B = wedge_uv(A, u, v)
    D = Dmat(A, B)
    ok(np.allclose(A.mul(B, B), 0), 'targeted s = 0')
    d2 = np.allclose(D @ D, 0)
    ok(d2 == (want != 'null rotation'), f'targeted {want}')
    ok(np.allclose(D @ D @ D, 0), 'D^3 = 0 when s = 0')
    kinds.setdefault((p, q, r), set()).add(want)
print('C: simple bivectors: B^2 = -det Gram, D^3 = sD, closed forms; kinds seen:')
for k in [(3, 0, 0), (2, 1, 0), (3, 1, 0), (3, 0, 1), (1, 3, 0), (2, 2, 0)]:
    print('   ', k, sorted(kinds.get(k, [])))
ok('translation' in kinds[(3, 0, 1)] and 'null rotation' in kinds[(3, 1, 0)] and 'totally null plane' in kinds[(2, 2, 0)], 'all three s=0 kinds occur')

# ---------- D: n = 4 roots and decomposition ----------
def pf(B):
    b = lambda i, j: B[(1 << i) | (1 << j)]
    return b(0, 1) * b(2, 3) - b(0, 2) * b(1, 3) + b(0, 3) * b(1, 2)


cx_count = {}
for (p, q, r) in [(4, 0, 0), (3, 1, 0), (2, 2, 0), (1, 3, 0), (0, 4, 0), (3, 0, 1), (2, 1, 1), (2, 0, 2)]:
    A = Alg.pq(p, q, r)
    I2 = int(np.prod(A.eps))
    nc = 0
    for _ in range(400):
        B = np.zeros(A.N, dtype=np.int64)
        for (i, j) in A.bivec_index():
            B[(1 << i) | (1 << j)] = rng.integers(-5, 6)
        S = int(A.mul(B, B)[0])
        Wc = int(A.wedge(B, B)[15])
        ok(Wc == 2 * pf(B), 'B^B = 2 Pf e1234')
        disc = S * S - Wc * Wc * I2
        if disc < 0:
            nc += 1
        if (p, q) in [(4, 0), (0, 4)] and r == 0:
            ok(abs(S) >= abs(Wc), 'AM-GM: |S| >= 2|Pf| in definite cells')
    cx_count[(p, q, r)] = nc
    ok((nc > 0) == ((p, q, r) == (2, 2, 0)), f'complex roots only in Cl(2,2): {p,q,r} {nc}')
print('D: complex root pairs out of 400 random integer bivectors:', cx_count)


def decompose(A, B):
    """b_i = B (T - lambda_j)/(lambda_i - lambda_j), T = (B^B)/2 ; complex arithmetic"""
    Bc = B.astype(complex)
    S = A.mul(Bc, Bc)[0]
    T = A.wedge(Bc, Bc) / 2
    I2 = np.prod(A.eps)
    WI = A.wedge(Bc, Bc)[15]
    disc = S * S - WI * WI * I2
    sq = np.sqrt(complex(disc))
    l1, l2 = (S + sq) / 2, (S - sq) / 2
    BT = A.mul(Bc, T)
    b1 = (BT - l1 * Bc) / (l2 - l1)
    b2 = (BT - l2 * Bc) / (l1 - l2)
    return b1, b2, l1, l2


for (p, q, r) in [(4, 0, 0), (3, 1, 0), (2, 2, 0), (1, 3, 0), (0, 4, 0)]:
    A = Alg.pq(p, q, r)
    for _ in range(30):
        B = rng.normal(size=A.N) * 0.6
        B = A.gp(B, 2)
        b1, b2, l1, l2 = decompose(A, B)
        if abs(l1 - l2) < 1e-6:
            continue
        ok(np.allclose(b1 + b2, B), 'b1+b2=B')
        ok(np.allclose(A.mul(b1, b2), A.mul(b2, b1)), 'commute')
        ok(np.allclose(A.mul(b1, b2), A.wedge(B, B).astype(complex) / 2), 'b1 b2 = (B^B)/2, grade 4')
        ok(np.allclose(A.mul(b1, b1), A.scalar(l1, complex)), 'b1^2=l1')
        ok(np.allclose(A.mul(b2, b2), A.scalar(l2, complex)), 'b2^2=l2')
        ok(np.allclose(A.gp(b1, 2), b1) and np.allclose(A.gp(b2, 2), b2), 'b_i bivectors')
        lhs = exp_mv(A, B.astype(complex), 60)
        rhs = A.mul(exp_mv(A, b1, 60), exp_mv(A, b2, 60))
        ok(np.allclose(lhs, rhs, atol=1e-8), f'exp(B)=exp(b1)exp(b2) {p,q,r}')
print('D: invariant decomposition verified (30 random bivectors per n = 4 cell)')

# ---------- E: Mozzi-Chasles in Cl(3,0,1) (null generator = bit 3) ----------
A = Alg.pq(3, 0, 1)
for _ in range(50):
    B = A.gp(rng.normal(size=A.N), 2)
    BB = A.mul(B, B)[0]
    T = A.wedge(B, B)
    b2 = A.mul(T, B) / (2 * BB)
    b1 = B - b2
    ok(np.allclose(A.mul(b2, b2), 0), 'b2^2 = 0')
    ok(np.allclose(A.mul(b1, b2), A.mul(b2, b1)), 'b1 b2 commute')
    ok(np.allclose(A.mul(b1, b1), A.scalar(BB)), 'b1^2 = B.B')
    ok(np.allclose(A.gp(b2, 2), b2), 'b2 bivector')
print('E: Mozzi-Chasles in Cl(3,0,1): b2^2 = 0, [b1,b2] = 0, b1^2 = B.B (50 random)')

# ---------- F: Riesz example ----------
A = Alg.pq(2, 2)
B = A.bivector({(0, 1): .5, (0, 3): .5, (1, 2): -.5, (2, 3): -.5})
b1, b2, l1, l2 = decompose(A, B)
ok(np.isclose(sorted([l1.imag, l2.imag])[1], 0.5) and abs(l1.real) < 1e-12, 'Riesz lambda = +- i/2')
ok(np.allclose(A.wedge(B, B), -A.blade(15)), 'Riesz B^B = -e1234')
print('F: Riesz example in Cl(2,2): lambda =', np.round(l1, 6), np.round(l2, 6))

# ---------- G: frame strain (ATL-018) ----------
for eta in [np.diag([-1., 1, 1, 1]), np.diag([1., -1, -1, -1])]:
    for _ in range(20):
        Am = rng.normal(size=(4, 4))
        t = 1e-6
        h = np.eye(4) + t * Am
        S = h.T @ eta @ h - eta
        ok(abs(np.trace(np.linalg.inv(eta) @ S) / t - 2 * np.trace(Am)) < 1e-4, 'tr strain ~ 2 tr A')
        ok(abs((np.linalg.det(h) - 1) / t - np.trace(Am)) < 1e-4, 'det change ~ tr A')
    # strain vanishes on a boost
    phi = 0.7
    L = np.eye(4)
    L[0, 0] = L[1, 1] = np.cosh(phi)
    L[0, 1] = L[1, 0] = np.sinh(phi)
    ok(np.allclose(L.T @ eta @ L - eta, 0), 'strain of a Lorentz map is 0')
print('G: frame strain S = h^T eta h - eta: first-order trace = 2 x volume change; 0 on Lorentz maps')

print(f'check_T17: {count - fails} of {count} assertions hold')
if fails:
    raise SystemExit(1)
