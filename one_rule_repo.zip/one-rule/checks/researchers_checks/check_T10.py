# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T10: the E_n series (n = 3..11). Own code, exact arithmetic where it matters.
Asserts:
 1. det Cartan(E_n) = 9 - n (n = 3..20), and det T_{p,q,r} = pq + qr + rp - pqr (p,q,r <= 9).
 2. signatures: (n,0,0) for n <= 8, (8,0,1) for n = 9, (n-1,1,0) for n = 10..20 (exact pivots, Fractions).
 3. Kac type via the Perron vector: finite (n <= 8), affine (n = 9), indefinite (n >= 10).
 4. E9 null root: marks (in simple-root coordinates) sum to 30; it is the vector k = (3;-1^9) of I_{1,9} up to sign.
 5. E10 is hyperbolic (every proper connected subdiagram finite or affine), E11 is not (contains E10).
 6. Norm-2 vectors of E_n counted in the I_{1,n} model = W-orbit of the simple roots: 8, 20, 40, 72, 126, 240.
 7. D8+ = D8 ∪ (D8 + (1/2)^8): 112 + 128 = 240 norm-2 vectors, simple system with Cartan matrix of type E8.
 8. root pairs of E_n = blades of Cl(n,0) squaring to -1, minus 1 at n = 7.
"""
import sys, itertools
from fractions import Fraction
import numpy as np
from f2lib import cartan_En, cartan_An, det_int, lorentz_En_simple_roots, pc

ok = 0


def check(c, m):
    global ok
    if not c:
        print("FAIL:", m)
        sys.exit(1)
    ok += 1


def inertia(M):
    """Exact inertia (pos, neg, zero) of a symmetric rational matrix by symmetric elimination."""
    A = [[Fraction(x) for x in r] for r in M]
    n = len(A)
    pos = neg = 0
    idx = list(range(n))
    while idx:
        piv = next((i for i in idx if A[i][i] != 0), None)
        if piv is None:
            # all remaining diagonal zero: look for off-diagonal a_ij != 0, use x_i + x_j
            pair = next(((i, j) for i in idx for j in idx if i < j and A[i][j] != 0), None)
            if pair is None:
                break
            i, j = pair
            for t in range(n):
                A[i][t] += A[j][t]
            for t in range(n):
                A[t][i] += A[t][j]
            continue
        d = A[piv][piv]
        if d > 0:
            pos += 1
        else:
            neg += 1
        for i in idx:
            if i != piv and A[i][piv] != 0:
                f = A[i][piv] / d
                for t in idx:
                    A[i][t] -= f * A[piv][t]
        for i in idx:
            if i != piv:
                A[piv][i] = A[i][piv] = Fraction(0)
        idx.remove(piv)
    return pos, neg, n - pos - neg


def T_pqr(p, q, r):
    """Cartan matrix of the tree with arms of p, q, r nodes counting the common centre."""
    nodes = 1 + (p - 1) + (q - 1) + (r - 1)
    A = [[0] * nodes for _ in range(nodes)]
    for i in range(nodes):
        A[i][i] = 2
    nxt = 1
    for arm in (p, q, r):
        prev = 0
        for _ in range(arm - 1):
            A[prev][nxt] = A[nxt][prev] = -1
            prev = nxt
            nxt += 1
    return A


# 1
for n in range(3, 21):
    check(det_int(cartan_En(n)) == 9 - n, f"det E_{n}")
for p in range(1, 10):
    for q in range(1, 10):
        for r in range(1, 10):
            check(det_int(T_pqr(p, q, r)) == p * q + q * r + r * p - p * q * r, f"det T{p,q,r}")
print("1 ok: det E_n = 9 - n (n = 3..20); det T_{p,q,r} = pq+qr+rp-pqr (p,q,r <= 9)")

# 2
for n in range(3, 21):
    s = inertia(cartan_En(n))
    exp = (n, 0, 0) if n <= 8 else ((8, 0, 1) if n == 9 else (n - 1, 1, 0))
    check(s == exp, f"signature E_{n} = {s}")
print("2 ok: signatures (n,0,0) n<=8, (8,0,1) n=9, (n-1,1,0) n=10..20")

# 3 Perron vector
for n in range(3, 13):
    A = np.array(cartan_En(n), dtype=float)
    if n == 3:
        continue  # E3 = A2 + A1 is decomposable; each factor is finite
    w, V = np.linalg.eigh(A)
    u = V[:, 0] * np.sign(V[0, 0])
    check(np.all(u > 1e-9), f"Perron vector positive E_{n}")
    lam = w[0]
    kind = "finite" if lam > 1e-9 else ("affine" if abs(lam) < 1e-9 else "indefinite")
    exp = "finite" if n <= 8 else ("affine" if n == 9 else "indefinite")
    check(kind == exp, f"type of E_{n}: {kind}")
print("3 ok: Kac type by the Perron vector: finite n<=8, affine n=9, indefinite n>=10")

# 4 E9 null root
A9 = cartan_En(9)
# kernel: solve exactly
M = [[Fraction(x) for x in r] for r in A9]
# null vector by elimination
n = 9
aug = [r[:] for r in M]
piv_cols = []
row = 0
for c in range(n):
    p = next((i for i in range(row, n) if aug[i][c] != 0), None)
    if p is None:
        continue
    aug[row], aug[p] = aug[p], aug[row]
    pv = aug[row][c]
    aug[row] = [x / pv for x in aug[row]]
    for i in range(n):
        if i != row and aug[i][c] != 0:
            f = aug[i][c]
            aug[i] = [x - f * y for x, y in zip(aug[i], aug[row])]
    piv_cols.append(c)
    row += 1
free = [c for c in range(n) if c not in piv_cols]
check(len(free) == 1, "E9 corank 1")
f = free[0]
delta = [Fraction(0)] * n
delta[f] = Fraction(1)
for r_i, c in enumerate(piv_cols):
    delta[c] = -aug[r_i][f]
den = 1
for x in delta:
    den = den * x.denominator // np.gcd(den, x.denominator)
delta = [int(x * den) for x in delta]
g = 0
for x in delta:
    g = int(np.gcd(g, abs(x)))
delta = [x // g for x in delta]
if delta[0] < 0:
    delta = [-x for x in delta]
check(all(x > 0 for x in delta) and sum(delta) == 30 and min(delta) == 1, f"marks {delta}")
R = lorentz_En_simple_roots(9)
vec = [sum(delta[j] * R[j][t] for j in range(9)) for t in range(10)]
check(vec == [3] + [-1] * 9 or vec == [-3] + [1] * 9, f"null root = k: {vec}")
print(f"4 ok: E9 null root marks {delta} (sum 30) = k = {vec} in I_(1,9)")


# 5 hyperbolicity
def connected(sub, A):
    sub = list(sub)
    seen = {sub[0]}
    st = [sub[0]]
    while st:
        x = st.pop()
        for y in sub:
            if y not in seen and A[x][y] != 0:
                seen.add(y)
                st.append(y)
    return len(seen) == len(sub)


def kind(A, sub):
    B = [[A[i][j] for j in sub] for i in sub]
    pos, neg, z = inertia(B)
    if neg == 0 and z == 0:
        return "finite"
    if neg == 0 and z == 1:
        return "affine"
    return "indefinite"


for n, expect_hyp in ((10, True), (11, False)):
    A = cartan_En(n)
    bad = []
    for size in range(1, n):
        for sub in itertools.combinations(range(n), size):
            if connected(sub, A) and kind(A, sub) == "indefinite":
                bad.append(sub)
    check((len(bad) == 0) == expect_hyp, f"E_{n} hyperbolic = {expect_hyp}")
    print(f"5: E_{n}: proper connected subdiagrams of indefinite type: {len(bad)}  -> hyperbolic: {len(bad) == 0}")


# 6 norm-2 vectors in the I_{1,n} model vs W-orbit
def norm2_count(n):
    cnt = 0
    B = int((2 * n / (9 - n)) ** 0.5) + 1
    for x0 in range(-B, B + 1):
        target_sum = -3 * x0
        target_sq = x0 * x0 + 2
        # enumerate x in Z^n with sum target_sum, sum squares target_sq ; |xi| <= sqrt(target_sq)
        m = int(target_sq ** 0.5)
        def rec(i, s, sq):
            if sq > target_sq:
                return 0
            if i == n:
                return int(s == target_sum and sq == target_sq)
            return sum(rec(i + 1, s + v, sq + v * v) for v in range(-m, m + 1))
        cnt += rec(0, 0, 0)
    return cnt


def worbit(A):
    n = len(A)
    roots = {tuple(int(t == i) for t in range(n)) for i in range(n)}
    fr = list(roots)
    while fr:
        nf = []
        for r in fr:
            for i in range(n):
                ip = sum(r[j] * A[j][i] for j in range(n))
                y = list(r)
                y[i] -= ip
                y = tuple(y)
                if y not in roots:
                    roots.add(y)
                    nf.append(y)
        fr = nf
    return len(roots)


exp6 = {3: 8, 4: 20, 5: 40, 6: 72, 7: 126, 8: 240}
for n in range(3, 9):
    a, b = norm2_count(n), worbit(cartan_En(n))
    check(a == b == exp6[n], f"E_{n}: norm-2 {a}, orbit {b}")
print("6 ok: norm-2 vectors = roots: 8, 20, 40, 72, 126, 240 (positive: 4, 10, 20, 36, 63, 120)")

# 7 D8+ model
vecs = []
for i, j in itertools.combinations(range(8), 2):
    for si in (1, -1):
        for sj in (1, -1):
            v = [0] * 8
            v[i] = 2 * si
            v[j] = 2 * sj
            vecs.append(tuple(v))  # doubled coordinates
n_int = len(vecs)
for signs in itertools.product((1, -1), repeat=8):
    if signs.count(-1) % 2 == 0:
        vecs.append(tuple(signs))
check(n_int == 112 and len(vecs) == 240, "112 + 128")
check(all(sum(x * x for x in v) == 8 for v in vecs), "all norm 2 (doubled coords: 8)")
# simple system for a generic functional
fvec = [1 + 0.001 * 2 ** i for i in range(8)]
fvec = [37.0, 19.1, 9.7, 5.03, 2.51, 1.27, 0.61, 0.29]
pos = [v for v in vecs if sum(a * b for a, b in zip(v, fvec)) > 0]
posset = set(pos)
def add(u, v):
    return tuple(a + b for a, b in zip(u, v))
simple = [v for v in pos if not any(add(u, w) == v for u in pos for w in pos if u != w and w in posset and add(u, w) == v)]
simple = [v for v in pos if not any(tuple(a - b for a, b in zip(v, u)) in posset for u in pos)]
check(len(simple) == 8, f"8 simple roots, got {len(simple)}")
C = [[sum(a * b for a, b in zip(u, v)) // 4 for v in simple] for u in simple]
degs = sorted(sum(1 for j in range(8) if j != i and C[i][j] != 0) for i in range(8))
check(det_int(C) == 1 and degs == sorted(sum(1 for j in range(8) if j != i and cartan_En(8)[i][j] != 0) for i in range(8)),
      "Cartan of D8+ simple system has det 1 and E8 degree sequence")
check(inertia(C) == (8, 0, 0) and all(C[i][j] in (0, -1) for i in range(8) for j in range(8) if i != j), "PD, simply laced")
print("7 ok: D8+ has 112 + 128 = 240 norm-2 vectors; its simple system is a tree with det 1 of the E8 shape")

# 8 mod-2 vs blades
for n in range(3, 9):
    blades_minus = sum(1 for a in range(1 << n) if (pc(a) * (pc(a) - 1) // 2) % 2 == 1)
    check(exp6[n] // 2 == blades_minus - (1 if n == 7 else 0), f"n={n}")
print("8 ok: root pairs = blades of Cl(n,0) with square -1, minus the pseudoscalar at n = 7 (at n = 3 the radical class is the A1 root)")
print(f"ALL {ok} CHECKS PASSED")
