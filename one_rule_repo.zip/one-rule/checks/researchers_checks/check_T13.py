# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T13: E8 ⊃ E6 x A2, the three 27s, E7 ⊃ A2 x A5, the 27-point graph. Own code; E8 in the D8+ model with
doubled integer coordinates (so a root has norm 8 and inner products are 4 x the true ones).
Asserts:
 1. each E8 root has exactly 56 roots at inner product -1; #A2 subsystems = 240*56/12 = 1120 (enumerated);
 2. the 1120 A2's form ONE orbit of W(E8) (BFS under the 120 root reflections); each has exactly 72 orthogonal roots, forming
    a root system with an E6 Cartan matrix (det 3, PD, E6 degree sequence);
 3. for one A2: the 240 roots split as 72 (E6) + 6 (A2) + 6 x 27 by projection onto the A2 plane; 78 + 8 + 2*81 = 248;
    the 27 roots in a projection class, minus their projection, have norm 4/3;
 4. the 27-point graph (inner product -2/3 after removing the projection) is srg(27,10,1,5), (1/3) srg(27,16,10,8);
 5. E7 = roots orthogonal to one root; its A2's have complement A5 (30 roots); the 126 roots project onto the A2 plane as
    30 (zero) + 6 (A2) + 90; minimal vectors of the E7 dual coset (56) split 18 + 18 + 20.
"""
import sys, itertools
from fractions import Fraction

ok = 0


def check(c, m):
    global ok
    if not c:
        print("FAIL:", m)
        sys.exit(1)
    ok += 1


roots = []
for i, j in itertools.combinations(range(8), 2):
    for si in (2, -2):
        for sj in (2, -2):
            v = [0] * 8
            v[i], v[j] = si, sj
            roots.append(tuple(v))
for s in itertools.product((1, -1), repeat=8):
    if s.count(-1) % 2 == 0:
        roots.append(s)
ip = lambda u, v: sum(a * b for a, b in zip(u, v))  # = 4 x true inner product
neg = lambda u: tuple(-a for a in u)
add = lambda u, v: tuple(a + b for a, b in zip(u, v))
R = set(roots)
check(len(R) == 240, "240")
for r in roots:
    check(sum(1 for s in roots if ip(r, s) == -4) == 56, "56 at -1")
A2s = set()
for r in roots:
    for s in roots:
        if ip(r, s) == -4:
            t = add(r, s)
            A2s.add(frozenset([r, s, neg(t), neg(r), neg(s), t]))
check(len(A2s) == 1120 == 240 * 56 // 12, f"{len(A2s)} A2 subsystems")


def refl(r):
    def f(v):
        c = ip(v, r) // 4  # true inner product
        return tuple(a - c * b for a, b in zip(v, r))
    return f


pos = [r for r in roots if next(a for a in r if a != 0) > 0]
refls = [refl(r) for r in pos]
start = next(iter(A2s))
orbit = {start}
fr = [start]
while fr:
    nf = []
    for A in fr:
        for f in refls:
            B = frozenset(f(v) for v in A)
            if B not in orbit:
                orbit.add(B)
                nf.append(B)
    fr = nf
check(orbit == A2s, "one W(E8)-orbit")


def det(M):
    M = [[Fraction(x) for x in r] for r in M]
    n = len(M)
    d = Fraction(1)
    for c in range(n):
        p = next((i for i in range(c, n) if M[i][c] != 0), None)
        if p is None:
            return 0
        if p != c:
            M[c], M[p] = M[p], M[c]
            d = -d
        d *= M[c][c]
        for i in range(c + 1, n):
            f = M[i][c] / M[c][c]
            M[i] = [a - f * b for a, b in zip(M[i], M[c])]
    return d


def simple_system(rs):
    fvec = [37.0, 19.1, 9.7, 5.03, 2.51, 1.27, 0.61, 0.29]
    P = [r for r in rs if sum(a * b for a, b in zip(r, fvec)) > 0]
    Ps = set(P)
    return [v for v in P if not any(tuple(a - b for a, b in zip(v, u)) in Ps for u in P)]


for A in list(A2s)[:40] + [start]:
    perp = [r for r in roots if all(ip(r, a) == 0 for a in A)]
    check(len(perp) == 72, "72 orthogonal roots")
S = simple_system([r for r in roots if all(ip(r, a) == 0 for a in start)])
C = [[ip(u, v) // 4 for v in S] for u in S]
degs = sorted(sum(1 for j in range(6) if j != i and C[i][j]) for i in range(6))
check(len(S) == 6 and det(C) == 3 and degs == [1, 1, 1, 2, 2, 3], f"E6 Cartan: det {det(C)}, degrees {degs}")
print("1-2 ok: 1120 = 240*56/12 A2 subsystems, one W(E8)-orbit, complement = E6 (72 roots, Cartan det 3, branched tree)")

# 3: projection onto the A2 plane
a1, a2 = [v for v in start][:2]
basisA = [r for r in start][:]
r1 = next(iter(start))
r2 = next(v for v in start if ip(v, r1) == -4)
G = [[ip(r1, r1), ip(r1, r2)], [ip(r2, r1), ip(r2, r2)]]


def proj_coords(v):
    # solve G c = (v.r1, v.r2)
    b1, b2 = Fraction(ip(v, r1)), Fraction(ip(v, r2))
    D = Fraction(G[0][0] * G[1][1] - G[0][1] * G[1][0])
    c1 = (b1 * G[1][1] - G[0][1] * b2) / D
    c2 = (G[0][0] * b2 - G[1][0] * b1) / D
    return (c1, c2)


classes = {}
for r in roots:
    classes.setdefault(proj_coords(r), []).append(r)
sizes = sorted(len(v) for v in classes.values())
zero = classes[(0, 0)]
check(len(zero) == 72, "72 with zero projection")
others = {k: v for k, v in classes.items() if k != (0, 0)}
sz = sorted(len(v) for v in others.values())
check(sz == [1] * 6 + [27] * 6, f"projection classes {sz}")
check(78 + 8 + 2 * 81 == 248 and 72 + 6 + 6 * 27 == 240, "248")
# norm after removing projection: true norm = 2 - |proj|^2 ; |proj|^2 for 27-classes should be 2/3
for k, v in others.items():
    if len(v) == 27:
        c1, c2 = k
        pn = (c1 * c1 * G[0][0] + 2 * c1 * c2 * G[0][1] + c2 * c2 * G[1][1]) / 4  # true norm of projection
        check(pn == Fraction(2, 3), "projection norm 2/3, remainder norm 4/3")
print("3 ok: 240 = 72 + 6 + 6 x 27 by projection onto the A2 plane; 248 = 78 + 8 + 81 + 81")

# 4: srg(27,10,1,5)
k27 = next(k for k, v in others.items() if len(v) == 27)
V = others[k27]
c1, c2 = k27
def residual_ip(u, v):
    # true inner product of u - p, v - p where p = projection (same for both) : u.v - p.p
    pn = (c1 * c1 * G[0][0] + 2 * c1 * c2 * G[0][1] + c2 * c2 * G[1][1]) / 4
    return Fraction(ip(u, v), 4) - pn
vals = sorted({residual_ip(u, v) for u in V for v in V if u != v})
check(vals == [Fraction(-2, 3), Fraction(1, 3)], f"inner products {vals}")
adj = {u: {v for v in V if v != u and residual_ip(u, v) == Fraction(-2, 3)} for u in V}
deg = {len(a) for a in adj.values()}
lam = {len(adj[u] & adj[v]) for u in V for v in adj[u]}
mu = {len(adj[u] & adj[v]) for u in V for v in V if v != u and v not in adj[u]}
check(deg == {10} and lam == {1} and mu == {5}, f"srg {deg} {lam} {mu}")
adj2 = {u: {v for v in V if v != u and residual_ip(u, v) == Fraction(1, 3)} for u in V}
check({len(a) for a in adj2.values()} == {16} and {len(adj2[u] & adj2[v]) for u in V for v in adj2[u]} == {10}, "Schlafli")
print("4 ok: on the 27, inner product -2/3 gives srg(27,10,1,5); inner product 1/3 gives the Schlafli graph srg(27,16,10,8)")

# 5: E7 = roots orthogonal to a root rho
rho = roots[0]
E7 = [r for r in roots if ip(r, rho) == 0]
check(len(E7) == 126, "126")
E7s = set(E7)
A2_in_E7 = [A for A in A2s if A <= E7s]
compl = {len([r for r in E7 if all(ip(r, a) == 0 for a in A)]) for A in A2_in_E7}
check(compl == {30}, f"A2 in E7 complement sizes {compl}")
A = A2_in_E7[0]
r1 = next(iter(A)); r2 = next(v for v in A if ip(v, r1) == -4)
G = [[ip(r1, r1), ip(r1, r2)], [ip(r2, r1), ip(r2, r2)]]
cl = {}
for r in E7:
    cl.setdefault(proj_coords(r), []).append(r)
z = len(cl[(0, 0)])
a2 = sum(len(v) for k, v in cl.items() if k != (0, 0) and len(v) == 1)
rest = 126 - z - a2
check((z, a2, rest) == (30, 6, 90), f"E7 shadows {(z, a2, rest)}")
# the 56: E8 roots with inner product 1 with rho, minus rho/2, are the 56 minimal vectors of the nontrivial E7* coset
W56 = [r for r in roots if ip(r, rho) == 4]
check(len(W56) == 56, "56")
cl56 = {}
for r in W56:
    cl56.setdefault(proj_coords(r), []).append(r)   # rho is orthogonal to the A2 plane, so projection of r - rho/2 = proj r
s56 = sorted(len(v) for v in cl56.values())
check(s56 == [6, 6, 6, 6, 6, 6, 20], f"56 split {s56}")
print("5 ok: E7 ⊃ A2 x A5 (complement 30 roots); 126 roots project as 30 + 6 + 90; 56 = 3x6 + 3x6 + 20 by projection")
print(f"ALL {ok} CHECKS PASSED")
