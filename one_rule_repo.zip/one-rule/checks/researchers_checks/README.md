# researchers_checks

The 20 checks behind the theorems T1 to T20 of the "For researchers" page (each script re-derives or recomputes the statement of its theorem and prints `ALL OK` or a pass count).
Run one with `cd researchers_checks && python3 check_T1.py`. Each script imports its helper from the same folder (`bitrule_A.py` for T1 to T8, `f2lib.py` for T9 to T14, `clC.py` for T15 to T20). Twelve scripts and `clC.py` need numpy (`pip install numpy`); the others use only the standard library.
These are our own derivations; they were re-derived once by a second reader and have not been reviewed by a specialist. Licence: see ../LICENSE.
