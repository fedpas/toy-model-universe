#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T8.py -- independent computation for T8 (representation type of the incidence algebra of the Boolean lattice B_n).

Computes / asserts:
  CART  Cartan matrix C_n (C[a][b] = 1 if a subset of b) = kron^n [[1,1],[0,1]]; Euler form matrix C^{-1} = Moebius = kron^n [[1,-1],[0,1]];
        symmetrised Euler-form signatures (1,0,0),(2,0,0),(4,0,0),(6,0,2),(14,2,0),(20,2,10) for n = 0..5 (reproduces E1 independently).
  COX   Coxeter matrix Phi_n = -C^{-T} C equals (-1)^{n-1} kron^n Phi_1 with Phi_1 = [[-1,-1],[1,0]] (eigenvalues w, w^2, w = e^{2 pi i/3});
        characteristic polynomials: n=1: x^2+x+1; n=2: (x-1)(x^3-1) = (x-1)^2 (x^2+x+1) [D4 type: Coxeter number 6? no: D4 has h=6; see md];
        n=3: (x-1)^2 (x^2+x+1)^3 = Coxeter polynomial of the canonical tubular algebra of type (3,3,3); n=4: (x+1)^6 (x^2-x+1)^5; n=5: (x-1)^{10} (x^2+x+1)^{11}.
        The fixed space of Phi_n (eigenvalue 1) has dimension = radical of the symmetrised Euler form: 0,0,0,2,0,10 for n=0..5.
  TITS  Tits form q_T(x) = sum x_a^2 - sum_{|b-a|=1, a<b} x_a x_b + sum_{|b-a|=2, a<b} x_a x_b (one minimal relation per square);
        q_T = Euler form for n <= 2; for n = 3, q_T = chi + x_0 x_7 (positive semi-definite, radical of dimension 1 instead of 2: signature (7,0,1));
        for n = 4 and 5, q_T is indefinite and NOT weakly non-negative: an explicit non-negative integer vector with q_T(x) < 0 is printed.
  CROWN for n >= 3 the rank-1 and rank-2 labels form a convex subposet whose Hasse diagram contains a cycle (n = 3: a hexagon), so the incidence algebra
        has the hereditary algebra of an A~ quiver as a convex subcategory (quotient by an idempotent ideal): not representation-finite.
"""
import sys, itertools, random
import numpy as np
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from bitrule_A import popcount
from fractions import Fraction

ok_all = True
def report(name, cond, msg=''):
    global ok_all; ok_all &= bool(cond); print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))

def kron_pow(M, n):
    out = np.array([[1]])
    for _ in range(n): out = np.kron(out, M)
    return out
def signature_exact(S):
    """signature of a symmetric integer matrix by exact rational diagonalisation (Lagrange)"""
    S = [[Fraction(int(x)) for x in row] for row in S]; d = len(S); pos = neg = 0
    S = [row[:] for row in S]
    while S:
        d = len(S)
        piv = next((i for i in range(d) if S[i][i] != 0), None)
        if piv is None:
            # find off-diagonal nonzero i,j and replace basis e_i -> e_i + e_j
            found = next(((i, j) for i in range(d) for j in range(i + 1, d) if S[i][j] != 0), None)
            if found is None: return pos, neg, d       # all zero: radical
            i, j = found
            for k in range(d): S[i][k] += S[j][k]
            for k in range(d): S[k][i] += S[k][j]
            continue
        p = S[piv][piv]
        if p > 0: pos += 1
        else: neg += 1
        # eliminate
        newS = []
        for i in range(d):
            if i == piv: continue
            row = []
            for j in range(d):
                if j == piv: continue
                row.append(S[i][j] - S[i][piv] * S[piv][j] / p)
            newS.append(row)
        S = newS
    return pos, neg, 0

U = np.array([[1, 1], [0, 1]]); Uinv = np.array([[1, -1], [0, 1]])
sigs = {}; okC = True
for n in range(0, 6):
    C = kron_pow(U, n); Ci = kron_pow(Uinv, n)
    okC &= np.array_equal(C @ Ci, np.eye(1 << n, dtype=int))
    okC &= all(C[a][b] == (1 if (a & b) == a else 0) for a in range(1 << n) for b in range(1 << n))
    sigs[n] = signature_exact(Ci + Ci.T)
okC &= [sigs[n] for n in range(6)] == [(1, 0, 0), (2, 0, 0), (4, 0, 0), (6, 0, 2), (14, 2, 0), (20, 2, 10)]
report('CART', okC, 'Cartan = kron^n [[1,1],[0,1]], Euler = Moebius; symmetrised signatures ' + ', '.join(f'n={n}: {sigs[n]}' for n in range(6)))

# COX
Phi1 = np.array([[-1, -1], [1, 0]])
okX = True; msgs = []
for n in range(1, 6):
    C = kron_pow(U, n); Ci = kron_pow(Uinv, n)
    Phi = -Ci.T @ C
    okX &= np.array_equal(Phi, (-1) ** (n - 1) * kron_pow(Phi1, n))
    ev = np.linalg.eigvals(Phi.astype(float))
    # count eigenvalues by argument: 1, -1, w, w^2, -w, -w^2
    from collections import Counter
    cnt = Counter()
    for z in ev:
        key = min(((abs(z - t), name) for t, name in [(1, '1'), (-1, '-1'), (np.exp(2j * np.pi / 3), 'w'), (np.exp(-2j * np.pi / 3), 'w^2'), (-np.exp(2j * np.pi / 3), '-w'), (-np.exp(-2j * np.pi / 3), '-w^2')]))
        okX &= key[0] < 1e-6; cnt[key[1]] += 1
    fixdim = (1 << n) - np.linalg.matrix_rank(Phi - np.eye(1 << n))
    okX &= fixdim == sigs[n][2]
    msgs.append(f'n={n}: ' + ' '.join(f'{k}^{v}' for k, v in sorted(cnt.items())) + f', fix dim {fixdim}')
    if n == 3: okX &= cnt == Counter({'1': 2, 'w': 3, 'w^2': 3})
    if n == 4: okX &= cnt == Counter({'-1': 6, '-w': 5, '-w^2': 5})
    if n == 2: okX &= cnt == Counter({'-1': 2, '-w': 1, '-w^2': 1})     # (x+1)^2 (x^2-x+1): the Coxeter polynomial of D4 (h = 6, exponents 1,3,3,5)
report('COX', okX, 'Phi_n = (-1)^{n-1} kron^n Phi_1; eigenvalue multiplicities: ' + '; '.join(msgs) + '; fixed space = radical of the Euler form')

# TITS
def tits_matrix(n):
    N = 1 << n; Q = np.zeros((N, N), dtype=int)
    for a in range(N):
        Q[a][a] = 2
        for b in range(N):
            if (a & b) == a and a != b:
                d = popcount(b ^ a)
                if d == 1: Q[a][b] -= 1; Q[b][a] -= 1
                if d == 2: Q[a][b] += 1; Q[b][a] += 1
    return Q       # q_T(x) = x^T Q x / 2
okT = True; msgs = []
rng = random.Random(1)
for n in range(1, 6):
    Q = tits_matrix(n); Ci = kron_pow(Uinv, n); E = Ci + Ci.T
    if n <= 2: okT &= np.array_equal(Q, E)
    if n == 3:
        D = Q - E; okT &= D[0][7] == 1 and D[7][0] == 1 and np.count_nonzero(D) == 2
    sg = signature_exact(Q); msgs.append(f'n={n}: Tits signature {sg}')
    if n == 3: okT &= sg == (6, 1, 1)     # indefinite as a real form, but weakly non-negative: q_T = chi + x_0 x_7 with chi >= 0
    if n == 3:
        # weak non-negativity: descent search must not find a negative value
        worst = 0
        for _ in range(300):
            x = np.array([rng.choice([0, 0, 1, 1, 2, 3]) for _ in range(8)]); v = int(x @ Q @ x) // 2
            improved = True
            while improved:
                improved = False
                for i in range(8):
                    for dlt in (1, -1):
                        if x[i] + dlt < 0: continue
                        x[i] += dlt; v2 = int(x @ Q @ x) // 2
                        if v2 < v: v = v2; improved = True
                        else: x[i] -= dlt
            worst = min(worst, v)
        okT &= worst == 0; msgs.append(f'n=3: descent search finds no negative value of q_T on x >= 0 (min {worst})')
    if n >= 4:
        # search non-negative integer vectors with q_T < 0: descent with early exit (an indefinite form descends without bound)
        best = None
        for _ in range(200):
            x = np.array([rng.choice([0, 0, 1, 1, 2, 3]) for _ in range(1 << n)])
            v = int(x @ Q @ x) // 2; steps = 0; improved = True
            while improved and v >= 0 and steps < 400:
                improved = False
                for i in range(1 << n):
                    for dlt in (1, -1):
                        if x[i] + dlt < 0: continue
                        x[i] += dlt; v2 = int(x @ Q @ x) // 2; steps += 1
                        if v2 < v: v = v2; improved = True
                        else: x[i] -= dlt
                    if v < 0: break
            if best is None or v < best[0]: best = (v, x.copy())
            if v < 0: break
        okT &= best[0] < 0
        msgs.append(f'n={n}: q_T = {best[0]} at x = {best[1].tolist()}')
report('TITS', okT, ' | '.join(msgs))

# CROWN
okW = True
for n in range(3, 6):
    N = 1 << n
    S = [a for a in range(N) if popcount(a) in (1, 2)]
    # convex: no chain a < b < c with a, c in S and b not in S (ranks 1..2: any b strictly between has rank between, i.e. impossible)
    okW &= all(not ((a & b) == a and (b & c) == b and a != b and b != c and a in S and c in S and b not in S) for a in range(N) for b in range(N) for c in range(N))
    # Hasse diagram of S restricted: edges rank1 -> rank2; number of edges = 2 * C(n,2), vertices n + C(n,2): cycle rank = E - V + 1
    E = sum(1 for a in S for b in S if (a & b) == a and popcount(b ^ a) == 1); V = len(S)
    okW &= E - V + 1 >= 1
    if n == 3: okW &= (V, E) == (6, 6)
report('CROWN', okW, 'ranks 1-2 form a convex subposet whose Hasse diagram has cycles (n=3: 6 vertices, 6 edges, a hexagon = A~_5 crown): not representation-finite for n >= 3')
print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
