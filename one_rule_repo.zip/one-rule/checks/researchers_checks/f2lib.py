# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Small independent helpers for the checks (own code; imports nothing from the atlas).

Vectors of F_2^n are Python ints (bit i = coordinate i).
A linear map of F_2^n is a tuple of n ints: the images of the basis vectors e_0..e_{n-1}.
"""
from itertools import combinations


def pc(x):
    return bin(x).count("1")


# ---------------------------------------------------------------- lattices
def lorentz_En_simple_roots(n):
    """Simple roots of E_n (n >= 3) as vectors in I_{1,n} = Z^{1+n}, form x0^2 - sum xi^2.
    alpha_0 = e0 - e1 - e2 - e3, alpha_i = e_i - e_{i+1} (i = 1..n-1).
    The lattice E_n is their span with the NEGATED Lorentzian form."""
    roots = []
    a0 = [0] * (n + 1)
    a0[0] = 1
    for i in (1, 2, 3):
        if i <= n:
            a0[i] = -1
    roots.append(a0)
    for i in range(1, n):
        v = [0] * (n + 1)
        v[i] = 1
        v[i + 1] = -1
        roots.append(v)
    return roots


def neg_lorentz(u, v):
    return -(u[0] * v[0]) + sum(u[i] * v[i] for i in range(1, len(u)))


def gram(vecs, form):
    return [[form(u, v) for v in vecs] for u in vecs]


def cartan_En(n):
    return gram(lorentz_En_simple_roots(n), neg_lorentz)


def cartan_An(n):
    A = [[0] * n for _ in range(n)]
    for i in range(n):
        A[i][i] = 2
        if i + 1 < n:
            A[i][i + 1] = A[i + 1][i] = -1
    return A


def cartan_Dn(n):
    A = cartan_An(n)
    # D_n: chain 0..n-2, node n-1 attached to n-3
    A[n - 2][n - 1] = A[n - 1][n - 2] = 0
    A[n - 3][n - 1] = A[n - 1][n - 3] = -1
    return A


def det_int(M):
    """Exact integer determinant (Bareiss)."""
    n = len(M)
    A = [row[:] for row in M]
    sign = 1
    prev = 1
    for k in range(n - 1):
        if A[k][k] == 0:
            sw = None
            for i in range(k + 1, n):
                if A[i][k] != 0:
                    sw = i
                    break
            if sw is None:
                return 0
            A[k], A[sw] = A[sw], A[k]
            sign = -sign
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                A[i][j] = (A[i][j] * A[k][k] - A[i][k] * A[k][j]) // prev
        prev = A[k][k]
    return sign * A[n - 1][n - 1]


# ---------------------------------------------------------------- F2 quadratic forms
def qtable_from_gram(G):
    """q(x) = x.x/2 mod 2 on F_2^n for an even Gram matrix G (in the lattice basis)."""
    n = len(G)
    for i in range(n):
        assert G[i][i] % 2 == 0
    q = [0] * (1 << n)
    for x in range(1 << n):
        bits = [i for i in range(n) if x >> i & 1]
        s = sum(G[i][i] // 2 for i in bits) + sum(G[i][j] for i, j in combinations(bits, 2))
        q[x] = s & 1
    return q


def polar(q, x, y):
    return q[x ^ y] ^ q[x] ^ q[y]


def q_clifford(p, qn, n=None):
    """Q(a) = [e_a^2 = -1] for Cl(p,qn): generators 0..p-1 square +1, p..p+qn-1 square -1."""
    n = p + qn
    negmask = ((1 << qn) - 1) << p
    out = [0] * (1 << n)
    for a in range(1 << n):
        k = pc(a)
        out[a] = ((k * (k - 1) // 2) + pc(a & negmask)) & 1
    return out


def form_invariants(q, n):
    """Complete invariants of a quadratic form over F_2 (classification, see T9.md Lemma 2):
    (n, r = dim rad b, delta = [q not identically 0 on rad b], gauss = sum (-1)^q)."""
    N = 1 << n
    basis_polar = [[polar(q, 1 << i, 1 << j) for j in range(n)] for i in range(n)]
    # radical of b: vectors x with b(x, e_j) = 0 for all j
    rad = [x for x in range(N) if all(polar(q, x, 1 << j) == 0 for j in range(n))]
    r = len(rad).bit_length() - 1
    delta = int(any(q[x] for x in rad))
    gauss = sum(1 - 2 * q[x] for x in range(N))
    return (n, r, delta, gauss)


def order_O_formula(inv):
    """|O(q)| from the invariants, by the formulas proved in T9.md (Lemma 3)."""
    n, r, delta, gauss = inv
    if r == 0:
        m = n // 2
        eps = 1 if gauss > 0 else -1
        return order_O_eps(m, eps)
    if r == 1 and delta == 1:
        m = (n - 1) // 2
        return order_Sp(m)
    if r == 1 and delta == 0:
        m = (n - 1) // 2
        eps = 1 if gauss > 0 else -1
        return 2 ** (2 * m) * order_O_eps(m, eps)
    raise NotImplementedError(inv)


def order_O_eps(m, eps):
    if m == 0:
        return 1
    out = 2 * 2 ** (m * (m - 1)) * (2 ** m - eps)
    for i in range(1, m):
        out *= 2 ** (2 * i) - 1
    return out


def order_Sp(m):
    out = 2 ** (m * m)
    for i in range(1, m + 1):
        out *= 2 ** (2 * i) - 1
    return out


def brute_order_O(q, n):
    """Count isometries of (F_2^n, q) by backtracking over images of the basis (no theory used)."""
    N = 1 << n
    qe = [q[1 << i] for i in range(n)]
    be = [[polar(q, 1 << i, 1 << j) for j in range(n)] for i in range(n)]
    cand = [[v for v in range(1, N) if q[v] == qe[i]] for i in range(n)]
    count = 0

    def rec(i, imgs, span):
        nonlocal count
        if i == n:
            count += 1
            return
        for v in cand[i]:
            if v in span:
                continue
            ok = True
            for j in range(i):
                if polar(q, v, imgs[j]) != be[i][j]:
                    ok = False
                    break
            if not ok:
                continue
            newspan = span | {s ^ v for s in span}
            rec(i + 1, imgs + [v], newspan)

    rec(0, [], {0})
    return count


# ---------------------------------------------------------------- linear maps over F2
def apply(g, x):
    y = 0
    i = 0
    while x:
        if x & 1:
            y ^= g[i]
        x >>= 1
        i += 1
    return y


def mul(a, b):
    """a o b"""
    return tuple(apply(a, c) for c in b)


def ident(n):
    return tuple(1 << i for i in range(n))


def inv(a):
    n = len(a)
    # solve a o x = id: build rows of matrix; use Gaussian elimination on augmented columns
    # represent a as matrix M with column j = a[j]; find inverse by elimination on rows
    rows = []
    for i in range(n):
        r = 0
        for j in range(n):
            if a[j] >> i & 1:
                r |= 1 << j
        rows.append([r, 1 << i])
    for col in range(n):
        piv = None
        for i in range(col, n):
            if rows[i][0] >> col & 1:
                piv = i
                break
        assert piv is not None, "singular"
        rows[col], rows[piv] = rows[piv], rows[col]
        for i in range(n):
            if i != col and rows[i][0] >> col & 1:
                rows[i][0] ^= rows[col][0]
                rows[i][1] ^= rows[col][1]
    # rows[i][1] is row i of inverse; convert to columns
    cols = []
    for j in range(n):
        c = 0
        for i in range(n):
            if rows[i][1] >> j & 1:
                c |= 1 << i
        cols.append(c)
    return tuple(cols)


def transvection(q, n, w):
    """t_w(x) = x + b(x,w) w ; an isometry of q when q(w) = 1."""
    return tuple((1 << i) ^ (w if polar(q, 1 << i, w) else 0) for i in range(n))


# ---------------------------------------------------------------- Schreier-Sims (deterministic)
class StabChain:
    """Deterministic Schreier-Sims for a group of invertible F_2-linear maps acting on vectors.
    Base = e_0..e_{n-1} (a base: only the identity fixes every basis vector).
    Elements are tuples of column ints. act(g, x) = apply(g, x).
    Also usable for integer matrix groups acting on a finite invariant point set via act/mul/inv/id hooks."""

    def __init__(self, gens, base, act, mul_, inv_, idn):
        self.base = base
        self.act, self.mul, self.inv, self.id = act, mul_, inv_, idn
        k = len(base)
        self.S = [[] for _ in range(k)]  # strong generators placed at the deepest level they fix
        for g in gens:
            if g != idn:
                j = self._fixdepth(g)
                self.S[j].append(g)
        self.T = [None] * k
        for i in range(k):
            self._orbit(i)
        self._run()

    def _fixdepth(self, g):
        j = 0
        while j < len(self.base) - 1 and self.act(g, self.base[j]) == self.base[j]:
            j += 1
        return j

    def gens_at(self, i):
        out = []
        for j in range(i, len(self.base)):
            out.extend(self.S[j])
        return out

    def _orbit(self, i):
        b = self.base[i]
        T = {b: (self.id, self.id)}
        frontier = [b]
        gens = self.gens_at(i)
        ginv = [self.inv(s) for s in gens]
        while frontier:
            nf = []
            for x in frontier:
                u, ui = T[x]
                for s, si in zip(gens, ginv):
                    y = self.act(s, x)
                    if y not in T:
                        T[y] = (self.mul(s, u), self.mul(ui, si))
                        nf.append(y)
            frontier = nf
        self.T[i] = T

    def sift(self, g, start=0):
        for i in range(start, len(self.base)):
            x = self.act(g, self.base[i])
            if x not in self.T[i]:
                return g, i
            g = self.mul(self.T[i][x][1], g)
        return g, len(self.base)

    def _run(self):
        k = len(self.base)
        i = k - 1
        while i >= 0:
            restart = False
            gens = self.gens_at(i)
            for x, (u, ui) in list(self.T[i].items()):
                for s in gens:
                    y = self.act(s, x)
                    h = self.mul(self.T[i][y][1], self.mul(s, u))
                    r, j = self.sift(h, i + 1)
                    if j < k or r != self.id:
                        jj = min(j, k - 1)
                        self.S[jj].append(r)
                        for l in range(i + 1, jj + 1):
                            self._orbit(l)
                        i = jj
                        restart = True
                        break
                if restart:
                    break
            if not restart:
                i -= 1

    def order(self):
        o = 1
        for T in self.T:
            o *= len(T)
        return o

    def contains(self, g):
        r, j = self.sift(g, 0)
        return j == len(self.base) and r == self.id


def f2_group(gens, n):
    return StabChain(gens, [1 << i for i in range(n)], apply, mul, inv, ident(n))


# integer matrices acting on integer vectors (tuples); element = tuple of columns (tuples)
def int_apply(g, v):
    n = len(v)
    m = len(g[0])
    out = [0] * m
    for i in range(n):
        if v[i]:
            col = g[i]
            for k in range(m):
                out[k] += v[i] * col[k]
    return tuple(out)


def int_mul(a, b):
    return tuple(int_apply(a, c) for c in b)


def int_ident(n):
    return tuple(tuple(1 if i == j else 0 for i in range(n)) for j in range(n))
