#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T7.py -- independent check of T7 (Tian's algebra Cl_Z truncated to k generators = Cl(m,m) or Cl(m,m,1); sorting sign = bit-rule sign).

Asserts:
  EMB  in the bit-rule algebra Cl(m,m) with generators ordered (+1,-1,+1,-1,...) and hyperbolic pairs u_j = (e_{2j} + e_{2j+1})/2, v_j = (e_{2j} - e_{2j+1})/2,
       the elements a_{2j-1} = u_j + u_{j-1} (u_0 = 0), a_{2j} = v_j satisfy Tian's relations a_i^2 = 0, a_i a_{i+1} + a_{i+1} a_i = 1,
       a_i a_j = -a_j a_i (|i-j| > 1), for k = 2m <= 8 generators; and the 2^k sorted words in a_1..a_k are linearly independent (exact rank),
       so they span the whole Cl(m,m) (dimension 4^m): the truncated Tian algebra IS Cl(m,m).
  ODD  for odd k = 2m-1 the words in a_1..a_k span a 2^k-dimensional subalgebra; the vector a_1 - a_3 + a_5 - ... equals (-1)^{m-1} u_m, squares to 0,
       anticommutes with a_1..a_k, and is not in the span of a_1..a_k's ... (it IS in the span of the a_i: it is their alternating sum); it spans the
       radical of the quadratic form restricted to span(a_1..a_k).
  SIG  the quadratic form v^2 = sum_i c_i c_{i+1} of v = sum c_i a_i (computed in the algebra, exact) has Gram matrix = path adjacency / 2; its signature
       is (floor(k/2), floor(k/2), k mod 2) for k <= 12 (eigenvalues 2cos(pi j/(k+1)) by numpy, and the exact null vector for odd k).
  SRT  the bit-rule sign (-1)^{#(i in a, j in b, j < i)} equals (-1)^{inversions of the concatenated word sorted(a) ++ sorted(b)}, exhaustively for n <= 8,
       the inversion count done by an explicit bubble sort.
"""
import sys, itertools, math
from fractions import Fraction
import numpy as np
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from bitrule_A import BR, rank_fr, anticomm, popcount, N_pairs

ok_all = True
def report(name, cond, msg=''):
    global ok_all; ok_all &= bool(cond); print(('ok   ' if cond else 'FAIL ') + name + ('  ' + msg if msg else ''))

def tian_gens(m):
    A = BR(tuple([1, -1] * m)); h = Fraction(1, 2)
    u = [None] + [A.add(A.scal(A.gen(2 * j), h), A.scal(A.gen(2 * j + 1), h)) for j in range(m)]          # u[1..m]
    v = [None] + [A.add(A.scal(A.gen(2 * j), h), A.scal(A.gen(2 * j + 1), -h)) for j in range(m)]
    a = {}
    for j in range(1, m + 1):
        a[2 * j - 1] = A.add(u[j], u[j - 1]) if j >= 2 else u[j]
        a[2 * j] = v[j]
    return A, a, u, v
def tian_relations(A, a, k):
    ok = all(A.mul(a[i], a[i]) == {} for i in range(1, k + 1))
    for i in range(1, k + 1):
        for j in range(i + 1, k + 1):
            ac = anticomm(A, a[i], a[j])
            ok &= ac == ({0: 1} if j == i + 1 else {})
    return ok
def words_rank(A, a, k):
    rows = [A.word({i: a[i] for i in range(1, k + 1)}, J) for r_ in range(k + 1) for J in itertools.combinations(range(1, k + 1), r_)]
    return rank_fr(rows, A.M)

okE = True; okO = True; msgs = []
for m in range(1, 5):
    A, a, u, v = tian_gens(m); k = 2 * m
    okE &= tian_relations(A, a, k) and words_rank(A, a, k) == A.M
    msgs.append(f'k={k}: rank {A.M}')
    kk = 2 * m - 1
    okO &= tian_relations(A, a, kk) and words_rank(A, a, kk) == 2 ** kk
    rad = {}
    for j in range(1, m + 1): rad = A.add(rad, a[2 * j - 1], (-1) ** (j - 1))
    okO &= rad == A.scal(u[m], (-1) ** (m - 1)) and A.mul(rad, rad) == {} and all(anticomm(A, rad, a[i]) == {} for i in range(1, kk + 1))
    msgs.append(f'k={kk}: rank {2 ** kk}, radical vector = (-1)^{m-1} u_{m}')
report('EMB', okE, 'Tian relations hold for a_{2j-1} = u_j + u_{j-1}, a_{2j} = v_j and the 2^k words span Cl(m,m): ' + '; '.join(x for x in msgs if 'u_' not in x))
report('ODD', okO, 'odd truncations: 2^k-dimensional, radical vector a_1 - a_3 + ... = (-1)^{m-1} u_m (the unpaired half of the last hyperbolic pair): ' + '; '.join(x for x in msgs if 'u_' in x))

# SIG: quadratic form of the span of a_1..a_k, exactly from the algebra for k <= 8, signature by eigenvalues for k <= 12
okS = True
for k in range(1, 13):
    G = np.zeros((k, k))
    for i in range(k - 1): G[i, i + 1] = G[i + 1, i] = 0.5
    ev = np.linalg.eigvalsh(G)
    sgn = (int(np.sum(ev > 1e-9)), int(np.sum(ev < -1e-9)), int(np.sum(np.abs(ev) <= 1e-9)))
    okS &= sgn == (k // 2, k // 2, k % 2)
    if k % 2 == 1:
        c = np.array([((-1) ** (i // 2) if i % 2 == 0 else 0) for i in range(k)], dtype=float)
        okS &= np.allclose(G @ c, 0)
    if k <= 8:
        m = (k + 1) // 2; A, a, u, v = tian_gens(m)
        for i in range(k):
            for j in range(k):
                pr = A.add(A.mul(a[i + 1], a[j + 1]), A.mul(a[j + 1], a[i + 1]))
                okS &= pr == ({0: 1} if abs(i - j) == 1 else {})          # polar form 2B(a_i,a_j) = {a_i,a_j}
report('SIG', okS, 'Gram matrix = path adjacency / 2 (from the algebra, k <= 8); signature (floor(k/2), floor(k/2), k mod 2) for k <= 12; null vector (1,0,-1,0,1,...) for odd k')

# SRT
def inversions_by_bubble(seq):
    s = list(seq); c = 0
    for i in range(len(s)):
        for j in range(len(s) - 1 - i):
            if s[j] > s[j + 1]: s[j], s[j + 1] = s[j + 1], s[j]; c += 1
    return c
okR = True
for n in range(1, 9):
    for a in range(1 << n):
        for b in range(1 << n):
            word = [i for i in range(n) if (a >> i) & 1] + [j for j in range(n) if (b >> j) & 1]
            okR &= (-1) ** inversions_by_bubble(word) == (-1) ** N_pairs(a, b)
report('SRT', okR, 'bit-rule sign = parity of the number of inversions (bubble sort) of sorted(a) ++ sorted(b), exhaustive n <= 8')
print('ALL OK' if ok_all else 'SOME CHECK FAILED'); sys.exit(0 if ok_all else 1)
