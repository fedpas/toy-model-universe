// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The words of the "For researchers" page (ResearchersSection.jsx), English and Italian with the same keys. The data it shows (the statements,
// the theorems, errata, questions, sources and scripts) is English where no Italian text exists: those blocks carry lang="en" and the Italian
// page says so in one line (enNote, claimsNote). The Young Learner reads only `pointer`.
export const VERSION = 'v10.2';
export const RS = {
  en: {
    tocLbl: 'On this page',
    toc: { status: 'Status', claims: 'Claims', matrix: 'Matrix', theorems: 'Theorems', questions: 'Questions', sources: 'Sources', errata: 'Errata', run: 'Run the checks', genesis: 'Genesis story' },
    pointer: 'This page is for grown-up researchers: it lists, one by one, what we looked up, what we checked with a program and what is only our way of reading. Everything here is also written in the pages.',
    enNote: 'This section is in English.',
    claimsNote: 'Statements without an Italian text are in English, as are the citations and the script names.',
    status: {
      h: 'Where the audit stands',
      intro: 'Counted from the claims table below, so the numbers and the table cannot disagree.',
      total: 'statements in the audit, each listed once',
      known: 'known ground: standard and checked, neither ours nor open',
      flag: 'statements carry this flag',
      several: 'A statement can carry several flags, so the four flag counts add up to more than the total.',
      version: 'version of the atlas',
      date: 'audit round 2: the date of the claims table',
      run: 'scripts you can rerun (section “Run the checks”)',
      theorems: 'theorems written for the atlas, each with its own check script',
      matrix: (rows, cols) => `${rows} × ${cols}`,
      matrixLbl: 'translation matrix: items of three sets of sources against the parts of the atlas'
    },
    claims: {
      h: 'Every statement, with its flags',
      intro: 'One row per statement of the atlas. A statement that mixes a theorem and a reading is split: the theorem line first, the reading line second, each with its own flags. Known ground means standard and checked, and neither ours nor open; a line that is only standard is a citation without a check of ours.',
      legendH: 'The four flags',
      flagsLbl: 'Flags',
      modeLbl: 'Match',
      mode: { all: 'all chosen flags', any: 'any chosen flag' },
      groundLbl: 'Known ground',
      ground: { all: 'Show all', known: 'Known ground only', hide: 'Everything except known ground', 'hide+std': 'Also hide plain citations' },
      groundNote: n => `“Everything except known ground” hides what the reader filter hides; the ${n} rows of the tally of the equations page are navigation and are never hidden.`,
      groupLbl: 'Group',
      allGroups: 'All groups',
      searchLbl: 'Search text and id',
      searchPh: 'e.g. Cl(3,1), ATL-007, check_T4',
      clear: 'Clear the filters',
      shown: (n, N) => `${n} of ${N} statements shown`,
      among: 'among them',
      cols: { id: 'Id', where: 'Where', lines: 'Statement and flags', cited: 'Cited', checked: 'Checked by' },
      label: { theorem: 'theorem', reading: 'reading', line: '' },
      frozen: 'wording frozen',
      frozenHelp: 'a Genesis node: its text is frozen, and the audit statement is not the text the page shows',
      tally: 'navigation row',
      tallyHelp: 'a row of the tally of the equations page: it summarises a step and is never hidden by the reader filter',
      known: 'known ground',
      noFlag: 'no flag yet',
      none: 'No statement matches these filters.',
      go: 'Open the page where it is shown',
      tableLbl: 'Statements of the atlas with their flags'
    },
    groups: {},
    matrix: {
      h: 'Translation matrix: three sets of sources against the atlas',
      intro: 'Each row is one item of a source (a lecture chapter, a paper, a notion of the category lens); each column is a part of the atlas. A cell grades how the item meets that part: E exact counterpart (checked in a script), S structural (the same structure in another generality, or a standard fact), A analogy (our reading; nothing computes it). The colours are those of the flags: E checked, S standard, A ours. An empty cell is a gap; a row with no cell is an item the atlas does not reach.',
      grade: { E: 'exact', S: 'structural', A: 'analogy', gap: 'gap' },
      srcLbl: 'Source', allSrc: 'All three',
      colLbl: 'Column', allCols: 'All columns',
      gradeLbl: 'Grade',
      shown: (n, N) => `${n} of ${N} rows shown`,
      help: 'Choose an id for the notes of its cells, or a column name for its counts.',
      item: 'Item',
      countRow: g => `${g}: cells per column`,
      close: 'Close',
      noCells: 'No cell: the atlas does not reach this item.',
      colCounts: (E, S, A) => `${E} exact, ${S} structural, ${A} analogy`,
      withCell: 'Rows with a cell here',
      noneIn: c => `None in “${c}”`,
      noneInEmpty: 'every shown row has a cell here',
      go: 'Open this part of the atlas',
      tableLbl: 'Translation matrix: rows are items of the sources, columns are parts of the atlas',
      cellLbl: (col, g) => `${col}: ${g}`,
      sources: {},
      cols: {}
    },
    theorems: {
      h: 'Theorems proved for the atlas',
      intro: 'Each theorem has a written proof, a script that checks it on the bit rule, and the verdict of an independent verifier who re-derived it. The statements that a theorem backs or corrects are linked to the claims table.',
      caption: 'proved here = derived and independently re-derived once by a second reader; no specialist has reviewed it yet',
      status: { proved: 'proved here', reduced: 'by reduction', range: 'range checked', open: 'open' },
      statusHelp: { proved: 'derived and independently re-derived once by a second reader; no specialist has reviewed it yet', reduced: 'proved from a recalled standard theorem, which is not re-proved here', range: 'an exhaustive computation over the stated range only, not a proof for every n', open: 'a part of the statement is not settled' },
      verifier: { verified: 'verified', gaps: 'verified with gaps' },
      kv: { status: 'Status', verifier: 'Independent verifier', script: 'Script', checks: 'What it asserts', usedFor: 'Backs or corrects', corrections: 'Corrections applied' },
      usedForHelp: 'show this statement in the claims table'
    },
    questions: {
      h: 'Questions for specialists',
      intro: 'What we would ask someone who knows the field, with what we checked and what we did not.',
      kv: { whom: 'Who could answer', checked: 'Checked', notChecked: 'Not checked' }
    },
    sources: {
      h: 'Sources, verdicts and dead ends',
      intro: 'The papers and lectures the atlas was compared with: what each says, what we computed, and the verdict. Dead ends stay on the list.',
      deadEnd: 'dead end',
      kv: { itSays: 'What it says', weComputed: 'What we computed', verdict: 'Verdict' }
    },
    errata: {
      h: 'Errata: our own mistakes, newest first',
      intro: 'Mistakes found in our own reports and statements. An entry is never edited away; a later correction is a new entry.',
      kv: { where: 'Where', wrong: 'Was', right: 'Now', foundBy: 'Found by', guard: 'Guarded by', gradeChange: 'Change of grade or flag' }
    },
    run: {
      h: 'Run the checks yourself',
      intro: 'The scripts behind the flag “checked”, each with the command that reruns it from the package folder.',
      kv: { what: 'What it checks', checks: 'Checks', command: 'Command' }
    },
    genesis: { h: 'Genesis story', later: 'Recorded for later' }
  },
  it: {
    tocLbl: 'In questa pagina',
    toc: { status: 'Stato', claims: 'Affermazioni', matrix: 'Matrice', theorems: 'Teoremi', questions: 'Domande', sources: 'Fonti', errata: 'Errata corrige', run: 'Rieseguire i controlli', genesis: 'Storia della Genesi' },
    pointer: 'Questa pagina è per i ricercatori adulti: elenca, uno per uno, che cosa abbiamo cercato nei libri, che cosa abbiamo controllato con un programma e che cosa è solo il nostro modo di leggere. Tutto ciò che c’è qui è scritto anche nelle pagine.',
    enNote: 'Questa sezione è in inglese.',
    claimsNote: 'Le affermazioni senza un testo italiano sono in inglese, come le citazioni e i nomi degli script.',
    status: {
      h: 'A che punto è la verifica',
      intro: 'Contati dalla tabella delle affermazioni qui sotto, così i numeri e la tabella non possono contraddirsi.',
      total: 'affermazioni nella verifica, ognuna elencata una volta',
      known: 'terreno noto: standard e verificato, né nostro né aperto',
      flag: 'affermazioni hanno questa etichetta',
      several: 'Un’affermazione può avere più etichette, quindi i quattro conteggi delle etichette sommano a più del totale.',
      version: 'versione dell’atlante',
      date: 'secondo giro di verifica: la data della tabella delle affermazioni',
      run: 'script che puoi rieseguire (sezione «Rieseguire i controlli»)',
      theorems: 'teoremi scritti per l’atlante, ognuno con il suo script di controllo',
      matrix: (rows, cols) => `${rows} × ${cols}`,
      matrixLbl: 'matrice di traduzione: elementi di tre gruppi di fonti a confronto con le parti dell’atlante'
    },
    claims: {
      h: 'Ogni affermazione, con le sue etichette',
      intro: 'Una riga per ogni affermazione dell’atlante. Un’affermazione che mescola un teorema e una lettura è divisa: prima la riga del teorema, poi quella della lettura, ognuna con le sue etichette. Terreno noto vuol dire standard e verificato, e né nostro né aperto; una riga solo standard è una citazione senza un nostro controllo.',
      legendH: 'Le quattro etichette',
      flagsLbl: 'Etichette',
      modeLbl: 'Corrispondenza',
      mode: { all: 'tutte le etichette scelte', any: 'almeno un’etichetta scelta' },
      groundLbl: 'Terreno noto',
      ground: { all: 'Mostra tutto', known: 'Solo il terreno noto', hide: 'Tutto tranne il terreno noto', 'hide+std': 'Nascondi anche le sole citazioni' },
      groundNote: n => `«Tutto tranne il terreno noto» nasconde ciò che nasconde il filtro del lettore; le ${n} righe del bilancio della pagina delle equazioni servono a navigare e non sono mai nascoste.`,
      groupLbl: 'Gruppo',
      allGroups: 'Tutti i gruppi',
      searchLbl: 'Cerca nel testo e negli id',
      searchPh: 'per esempio Cl(3,1), ATL-007, check_T4',
      clear: 'Togli i filtri',
      shown: (n, N) => `${n} affermazioni mostrate su ${N}`,
      among: 'tra queste',
      cols: { id: 'Id', where: 'Dove', lines: 'Affermazione ed etichette', cited: 'Citato', checked: 'Controllato da' },
      label: { theorem: 'teorema', reading: 'lettura', line: '' },
      frozen: 'testo congelato',
      frozenHelp: 'un nodo della Genesi: il suo testo è congelato, e l’affermazione della verifica non è il testo che la pagina mostra',
      tally: 'riga di navigazione',
      tallyHelp: 'una riga del bilancio della pagina delle equazioni: riassume un passo e il filtro del lettore non la nasconde mai',
      known: 'terreno noto',
      noFlag: 'ancora nessuna etichetta',
      none: 'Nessuna affermazione corrisponde a questi filtri.',
      go: 'Apri la pagina dove si trova',
      tableLbl: 'Affermazioni dell’atlante con le loro etichette'
    },
    // the group names of the claims table; the English page reads groupName from the claims file
    groups: { ATL: 'Celle dell’atlante', GEN: 'Scala della Genesi (testo congelato)', FUR: 'Risultati su Furey', PAG: 'Strisce di affermazioni delle pagine', LAB: 'Strisce dei passi 15–17', EQN: 'Equazioni: passo 1 e bilancio', SHP: 'Forme: ortoplesso', GOS: 'Forme: Gosset', CPL: 'Passo 3: accoppiamento', GRV: 'Passi 6–7: gravità', MAT: 'Passo 5: materia', MIR: 'Passo 8: specchi', PRJ: 'Passo 9: proiettivo', YM: 'Passo 4: Yang–Mills', NUL: 'Passo 14: superfici nulle', FRQ: 'Passo 10: forque', SPN: 'Passo 11: spin', SPR: 'Passo 12: molle', RIG: 'Passo 13: corpo rigido', MAP: 'Nodi della mappa', RSN: 'Note per i ricercatori' },
    matrix: {
      h: 'Matrice di traduzione: tre gruppi di fonti a confronto con l’atlante',
      intro: 'Ogni riga è un elemento di una fonte (un capitolo delle lezioni, un articolo, una nozione della lente delle categorie); ogni colonna è una parte dell’atlante. Una cella dice come l’elemento incontra quella parte: E controparte esatta (controllata da uno script), S strutturale (la stessa struttura in un’altra generalità, o un fatto standard), A analogia (una nostra lettura; nulla la calcola). I colori sono quelli delle etichette: E verificato, S standard, A nostro. Una cella vuota è una lacuna; una riga senza celle è un elemento che l’atlante non raggiunge.',
      grade: { E: 'esatto', S: 'strutturale', A: 'analogia', gap: 'lacuna' },
      srcLbl: 'Fonte', allSrc: 'Tutte e tre',
      colLbl: 'Colonna', allCols: 'Tutte le colonne',
      gradeLbl: 'Grado',
      shown: (n, N) => `${n} righe mostrate su ${N}`,
      help: 'Scegli un id per le note delle sue celle, o il nome di una colonna per i suoi conteggi.',
      item: 'Elemento',
      countRow: g => `${g}: celle per colonna`,
      close: 'Chiudi',
      noCells: 'Nessuna cella: l’atlante non raggiunge questo elemento.',
      colCounts: (E, S, A) => `${E} esatte, ${S} strutturali, ${A} analogie`,
      withCell: 'Righe con una cella qui',
      noneIn: c => `Nessuna in «${c}»`,
      noneInEmpty: 'ogni riga mostrata ha una cella qui',
      go: 'Apri questa parte dell’atlante',
      tableLbl: 'Matrice di traduzione: le righe sono elementi delle fonti, le colonne sono parti dell’atlante',
      cellLbl: (col, g) => `${col}: ${g}`,
      // the names of the three sources and of the 22 columns (short, long); the English page reads them from the matrix file
      sources: { schuller: 'Lezioni di Schuller e chiusura gravitazionale', baez: 'Sette articoli di Baez', category: 'Lente delle categorie (note KTH sulle algebre di Clifford, Tenfold Way, Tian, Majkic, contesto)' },
      cols: {
        rule: ['Regola', 'La regola: etichette di bit, XOR, segni'], cells: ['Celle', 'L’atlante delle celle Cl(p,q), l’orologio'], maxwell: ['Maxwell', 'Prova 1: Maxwell ∇F=J'], furey: ['Furey', 'Prova 2: Furey, una generazione in Cl(0,8)'],
        shapes: ['Forme', 'Ortoplesso, demicubo, serie di Gosset'], comm: ['1 Commut', 'Passo 1: commutatori dei bivettori'], dirac: ['2 Dirac', 'Passo 2: equazione di Dirac'], coupling: ['3 Accopp', 'Passo 3: accoppiamento'],
        ym: ['4 YM', 'Passo 4: Yang–Mills'], matter: ['5 Materia', 'Passo 5: materia carica'], grav1: ['6 Gravità', 'Passo 6: gravità, tetrade e curvatura'], grav2: ['7 Gravità', 'Passo 7: gravità, forma di Einstein'],
        mirrors: ['8 Specchi', 'Passo 8: specchi e versori'], projective: ['9 Proiett', 'Passo 9: proiettivo e conforme'], forque: ['10 Forque', 'Passo 10: dinamica del forque'], spin: ['11 Spin', 'Passo 11: spinori'],
        spring: ['12 Molle', 'Passo 12: molle'], rigid: ['13 Rigido', 'Passo 13: corpi rigidi'], null: ['14 Nulle', 'Passo 14: superfici nulle'], clock: ['15 Orologio', 'Passo 15: orologio e trinità'],
        gauge: ['16 Gauge', 'Passo 16: gravità di gauge'], groups: ['17 Gruppi', 'Passo 17: gruppi finiti']
      }
    },
    theorems: {
      h: 'Teoremi dimostrati per l’atlante',
      intro: 'Ogni teorema ha una dimostrazione scritta, uno script che lo controlla sulla regola dei bit e il giudizio di un verificatore indipendente che l’ha ricavato di nuovo. Le affermazioni che un teorema sostiene o corregge sono collegate alla tabella delle affermazioni.',
      caption: 'dimostrato qui = ricavato e poi ricavato di nuovo, in modo indipendente, da un secondo lettore; nessuno specialista l’ha ancora esaminato',
      status: { proved: 'dimostrato qui', reduced: 'per riduzione', range: 'controllato in un intervallo', open: 'aperto' },
      statusHelp: { proved: 'ricavato e poi ricavato di nuovo, in modo indipendente, da un secondo lettore; nessuno specialista l’ha ancora esaminato', reduced: 'dimostrato a partire da un teorema standard richiamato, che qui non è dimostrato di nuovo', range: 'un calcolo esaustivo solo nell’intervallo indicato, non una dimostrazione per ogni n', open: 'una parte dell’enunciato non è risolta' },
      verifier: { verified: 'confermato', gaps: 'confermato con lacune' },
      kv: { status: 'Stato', verifier: 'Verificatore indipendente', script: 'Script', checks: 'Che cosa controlla', usedFor: 'Sostiene o corregge', corrections: 'Correzioni applicate' },
      usedForHelp: 'mostra questa affermazione nella tabella'
    },
    questions: {
      h: 'Domande per gli specialisti',
      intro: 'Che cosa chiederemmo a chi conosce il campo, con ciò che abbiamo controllato e ciò che non abbiamo controllato.',
      kv: { whom: 'Chi potrebbe rispondere', checked: 'Controllato', notChecked: 'Non controllato' }
    },
    sources: {
      h: 'Fonti, verdetti e vicoli ciechi',
      intro: 'Gli articoli e le lezioni con cui l’atlante è stato confrontato: che cosa dice ciascuno, che cosa abbiamo calcolato e il verdetto. I vicoli ciechi restano nell’elenco.',
      deadEnd: 'vicolo cieco',
      kv: { itSays: 'Che cosa dice', weComputed: 'Che cosa abbiamo calcolato', verdict: 'Verdetto' }
    },
    errata: {
      h: 'Errata corrige: i nostri errori, i più recenti per primi',
      intro: 'Errori trovati nei nostri rapporti e nelle nostre affermazioni. Una voce non viene mai cancellata; una correzione successiva è una voce nuova.',
      kv: { where: 'Dove', wrong: 'Era', right: 'Ora', foundBy: 'Trovato da', guard: 'Sorvegliato da', gradeChange: 'Cambio di grado o di etichetta' }
    },
    run: {
      h: 'Riesegui i controlli da solo',
      intro: 'Gli script dietro l’etichetta «verificato», ognuno con il comando che lo riesegue dalla cartella del pacchetto.',
      kv: { what: 'Che cosa controlla', checks: 'Controlli', command: 'Comando' }
    },
    genesis: { h: 'Storia della Genesi', later: 'Annotato per dopo' }
  }
};
