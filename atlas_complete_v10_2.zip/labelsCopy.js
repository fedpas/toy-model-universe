// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Copy of the Steps 15-17 page (labels, gauge gravity, finite groups), English and Italian, formal and plain.
// Status words: checked, standard, ours, open (see storyCopy.js). Keys ending in Y are what the Young Learner reads in their place.
import { stepCount, stepNo } from './steps.js';

const N = stepCount('eq');
const W = { en: ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen'], it: ['zero', 'uno', 'due', 'tre', 'quattro', 'cinque', 'sei', 'sette', 'otto', 'nove', 'dieci', 'undici', 'dodici', 'tredici', 'quattordici', 'quindici', 'sedici'] };

// ---- the frame of the page: heading, what it does, what came before and after, the tags strip
export const PAGE = {
  en: {
    h: 'Three more steps: labels, gauge gravity and finite groups',
    does: 'The rule gives every cell one of three labels: its square is −1, +1 or 0. Step 15 asks what those labels are (a rotation, a boost, a translation), why the all-positive cells are enough, and what changes at four dimensions. Step 16 reads a published gauge theory of gravity in the same language, where the horizon of a black hole is the 0 label. Step 17 turns to finite groups: the same rule over two elements, counting symmetries from the cube up to the Golay code. Every picture here is computed in your browser from the bit rule, and the scripts that check the same numbers come with the package.',
    before: `The equations page ended with its tally of ${W.en[N]} steps.`,
    after: 'Next: the map of everything so far, with the tree of knowledge and the next step.',
    tags: [
      ['checked standard', `every number and picture here is rebuilt from the bit rule in your browser and by three scripts: the class of each cell, the trinity counts, the roots at n = 4, the group orders and the Golay code; the curvature counts (Riemann, Ricci and Weyl for each n) are the textbook formulas, computed by linear algebra in step ${stepNo('eq', 'grav1')}`],
      ['standard', 'the classification of Clifford algebras, gauge theory gravity (Lasenby, Doran and Gull), the invariant decomposition (Roelfs and De Keninck), the Golay code and the orders of the large groups are published results, quoted'],
      ['checked standard ours', 'the labels −1, +1, 0 as rotation, boost and translation for a vector or a simple bivector (the elliptic, hyperbolic and parabolic one-parameter subgroups; from n = 4 they are no longer enough); reading the horizon as the 0 label; E_{n} for the positive family and A_{n} for the negative one; the finite lens itself'],
      ['checked open', 'the field equations of the gravity theory; groups over more than two elements; most sporadic groups (translation inside a non-degenerate cell is not open: it is a null rotation there, T = 1 − a n_{∞}/2, checked in gtg_check.py, part R)'],
    ],
  },
  it: {
    h: 'Altri tre passi: etichette, gravità di gauge e gruppi finiti',
    does: 'La regola dà a ogni cella una di tre etichette: il suo quadrato è −1, +1 o 0. Il passo 15 chiede che cosa sono quelle etichette (una rotazione, un boost, una traslazione), perché bastano le celle tutte positive e che cosa cambia a quattro dimensioni. Il passo 16 legge nello stesso linguaggio una teoria di gauge della gravità pubblicata, dove l’orizzonte di un buco nero è l’etichetta 0. Il passo 17 passa ai gruppi finiti: la stessa regola su due elementi, che conta le simmetrie dal cubo fino al codice di Golay. Ogni immagine qui è calcolata nel tuo browser dalla regola dei bit, e gli script che controllano gli stessi numeri sono nel pacchetto.',
    before: `La pagina delle equazioni è finita con il suo bilancio di ${W.it[N]} passi.`,
    after: 'Avanti: la mappa di tutto ciò che c’è finora, con l’albero della conoscenza e il passo successivo.',
    tags: [
      ['checked standard', `ogni numero e immagine qui è ricostruito dalla regola dei bit nel tuo browser e da tre script: la classe di ogni cella, i conteggi della trinità, le radici a n = 4, gli ordini dei gruppi e il codice di Golay; i conteggi della curvatura (Riemann, Ricci e Weyl per ogni n) sono le formule da manuale, calcolate con l’algebra lineare nel passo ${stepNo('eq', 'grav1')}`],
      ['standard', 'la classificazione delle algebre di Clifford, la gravità come teoria di gauge (Lasenby, Doran e Gull), la decomposizione invariante (Roelfs e De Keninck), il codice di Golay e gli ordini dei grandi gruppi sono risultati pubblicati, citati'],
      ['checked standard ours', 'le etichette −1, +1, 0 come rotazione, boost e traslazione per un vettore o un bivettore semplice (i sottogruppi a un parametro ellittici, iperbolici e parabolici; da n = 4 non bastano più); leggere l’orizzonte come etichetta 0; E_{n} per la famiglia positiva e A_{n} per quella negativa; la lente finita stessa'],
      ['checked open', 'le equazioni di campo della teoria della gravità; gruppi su più di due elementi; la maggior parte dei gruppi sporadici (la traslazione dentro una cella non degenere non è aperta: lì è una rotazione nulla, T = 1 − a n_{∞}/2, controllata in gtg_check.py, parte R)'],
    ],
  },
};
export const PAGE_YL = {
  en: {
    h: 'Three more discoveries: the clock, the edge of a black hole, and counting shuffles',
    does: 'Every box has one of three signs. We find out what the signs mean, watch space fall into a black hole, and count the ways to shuffle a pattern made only of 0 and 1. Every picture here is worked out by your browser while you look.',
    before: 'The equations page ended with its list of what is drawn.',
    after: 'Next: the map of everything so far.',
    tags: [
      ['checked standard', 'every number and picture here is worked out again by your browser from the switch rule, and scripts check the same numbers'],
      ['standard', 'the list of all kinds of box, falling space around a black hole, and the code with 4096 words are known maths from books and papers'],
      ['checked standard ours', 'calling the three signs a turn, a push and a slide, and reading the edge of a black hole as the zero sign, are our way of reading'],
      ['checked open', 'what the slide means inside the plain boxes, and the equations that tell space how to fall'],
    ],
  },
  it: {
    h: 'Altre tre scoperte: l’orologio, il bordo di un buco nero e il conto dei rimescolamenti',
    does: 'Ogni scatola ha uno di tre segni. Scopriamo che cosa significano, guardiamo lo spazio cadere in un buco nero e contiamo i modi di rimescolare uno schema fatto solo di 0 e 1. Ogni immagine qui è rifatta dal tuo browser mentre guardi.',
    before: 'La pagina delle equazioni è finita con l’elenco di ciò che è disegnato.',
    after: 'Avanti: la mappa di tutto ciò che c’è finora.',
    tags: [
      ['checked standard', 'ogni numero e immagine qui è rifatto dal tuo browser con la regola degli interruttori, e alcuni script controllano gli stessi numeri'],
      ['standard', 'l’elenco di tutti i tipi di scatola, lo spazio che cade intorno a un buco nero e il codice con 4096 parole sono matematica nota, da libri e articoli'],
      ['checked standard ours', 'chiamare i tre segni una svolta, una spinta e uno scivolamento, e leggere il bordo di un buco nero come il segno zero, è il nostro modo di leggere'],
      ['checked open', 'che cosa significa lo scivolamento dentro le scatole semplici, e le equazioni che dicono allo spazio come cadere'],
    ],
  },
};
// short readings for the Young Learner and the Physicist (audienceCopy.js SHORT.page_labels)
export const SHORT = {
  en: [
    'Three more discoveries. A clock with eight places tells what each box is made of. Space falls into a black hole like water down a drain, and its edge is the zero sign. And with only 0 and 1 we can count shuffles and meet a famous code.',
    'Step 15: the Z_{8} clock, rotor algebras, the trinity X^{2} = −1, +1, 0 and bivectors at n = 4. Step 16: gauge theory gravity, the horizon as the 0 label, curvature counts. Step 17: O(Q) over F_{2}, W(E_{n}) and S_{n+1}, the Golay code, M_{24} and the primes. All computed live; three scripts check the same numbers.',
  ],
  it: [
    'Altre tre scoperte. Un orologio con otto posti dice di che cosa è fatta ogni scatola. Lo spazio cade in un buco nero come l’acqua in uno scarico, e il suo bordo è il segno zero. E con solo 0 e 1 possiamo contare i rimescolamenti e incontrare un codice famoso.',
    'Passo 15: l’orologio Z_{8}, le algebre di rotori, la trinità X^{2} = −1, +1, 0 e i bivettori a n = 4. Passo 16: la gravità come teoria di gauge, l’orizzonte come etichetta 0, i conteggi della curvatura. Passo 17: O(Q) su F_{2}, W(E_{n}) e S_{n+1}, il codice di Golay, M_{24} e i primi. Tutto calcolato dal vivo; tre script controllano gli stessi numeri.',
  ],
};
export const TABS_LBL = { en: 'Labels, gauge gravity and finite groups, step by step', it: 'Etichette, gravità di gauge e gruppi finiti, un passo alla volta' };

// ---- the tabs and the pictures
export const COPY = {
  en: {
    live: 'computed in your browser now',
    tabs: {
      clock: {
        ledeY: ['Every box has a hand on a clock with eight places. The place tells what the box is made of: ordinary numbers, turning numbers or spinning numbers, one copy or two. Click a box and the computer works it out.',
          'The odd-looking boxes are not new. The turning numbers are the rotations of a flat sheet, the spinning numbers are the rotations of space. And every box can hide inside a box that has only plus switches, with two more switches added.'],
        lede: ['Every cell has a label on the Z_{8} clock, c = p − q mod 8, and the clock fixes what the cell is: R, R^{2}, C, H or H^{2} (matrices over the reals, the complex numbers or the quaternions, once or twice). Pick a cell: the computer rebuilds its type, its matrix size, and the phase of a Gauss sum over its 2^{n} blade addresses, which is the clock.',
          'Two facts make the all-positive cells enough. C, H and H^{2} are not new objects: Cl(0,n) is the even part (the rotors) of the all-positive cell with one more generator. And every Cl(p,q) sits inside the all-positive cell with two more generators, grading kept: a positive generator stays, a negative one is multiplied by P = e_{n+1}e_{n+2}, whose square is −1.'],
        ledeM: ['Every cell Cl(p,q) carries the class c = p − q mod 8 in Z_{8}. By Bott periodicity the class fixes the Wedderburn type among R, R^{2}, C, H, H^{2} and the matrix size. For a picked cell the page recomputes it three ways: from the bit rule, as a matrix size, and as the phase of the Gauss sum over the 2^{n} blade addresses, which equals (1+i) to the power p times (1−i) to the power q, so its argument is c × 45°.'],
        glance: { tags: [['checked standard', 'C, H, H^{2} and every Cl(0,n) as rotor algebras (72 isomorphisms, n ≤ 8); the embedding in Cl(n+2,0); the trinity; the roots at n = 4'], ['standard', 'the classification table of Clifford algebras'], ['checked ours', 'reading −1, +1, 0 as rotation, boost, translation'], ['checked standard', 'translation inside a non-degenerate cell: a null rotation, T = 1 − a n_{∞}/2 with n_{∞} null (checked in gtg_check.py, part R)']],
          est: 'Established here: the 0 label is a translation only in the generator algebra (and in the projective picture); on vectors of a non-degenerate cell it is a null rotation. From n = 4 the label −1/+1/0 is no longer enough: a bivector has two numbers.', script: 'labels_check.py (sections 1–11) · log labels_check.log' },
      },
      gauge: {
        ledeY: ['Think of space itself falling into a black hole, like water down a drain. Far away it falls slowly, closer it falls faster, and at one distance, the edge, it falls exactly as fast as light can swim against it.',
          'The same three signs appear again. Outside the edge light can swim out. At the edge it stands still. Inside, even light is swept in. At the bottom you can also count how many numbers it takes to say how space is bent.'],
        lede: ['Gauge theory gravity (Lasenby, Doran and Gull) writes gravity as a gauge field on flat space: a position-dependent linear map h̄ of the vectors. In the Newtonian gauge (Painlevé–Gullstrand form) Schwarzschild is one unipotent shear, h̄ = 1 + N with N^{2} = 0; we rebuilt it with matrices. The flow vector e_{r} + g e_{t}, with g = √(2M/r), squares to g^{2} − 1: negative outside, 0 on the horizon, positive inside. It is the same three-way sorting as the spring trinity, now in the (t, r) plane Cl(1,1).',
          'The second picture counts curvature. Riemann = Ricci + Weyl for n ≥ 3, and the Weyl part is first non-zero at n = 4, the dimension at which a bivector first has a square with two parts.'],
        ledeM: ['Gauge theory gravity puts the gravitational field in a position-dependent linear map h̄ on flat space. In the Newtonian gauge (Painlevé–Gullstrand) Schwarzschild is a single unipotent shear, h̄ = 1 + N with N^{2} = 0, rebuilt here with explicit matrices. The flow vector v = e_{r} + g e_{t}, g = √(2M/r), has v^{2} = g^{2} − 1, negative outside, 0 on the horizon, positive inside: the three classes of the spring trinity, in the plane Cl(1,1).'],
        glance: { tags: [['checked standard ours', `the shear h̄ = 1 + N with N^{2} = 0 (Painlevé–Gullstrand form), (e_{r} + g e_{t})^{2} = g^{2} − 1, the Kerr–Schild null vector, time reversal as one reflection, and the curvature counts (textbook formulas, computed in step ${stepNo('eq', 'grav1')}); reading r = 2M as the 0 class (a paired null of the (t, r) plane)`], ['checked standard', 'gauge theory gravity; the Weyl map eigenvalues (4, −2, −2)'], ['ours', 'reading the horizon as the 0 label of the (t, r) plane: unpaired (the radical) in the tangent algebra Cl(0,2,1) of the surface, the paired null e_{t} − e_{r} inside Cl(1,1)'], ['open', 'the field equations, cosmology and Hawking parts of the paper are not decoded']],
          est: 'Established here: kinematics only. The shear, the horizon sign, the Kerr–Schild form, the sign of g as the arrow of time (the cross-term sign is a frame convention) and the curvature counts. Not decoded: the field equations.', script: 'gtg_check.py (parts S and G, and R for Roelfs–De Keninck) · log gtg_check.log' },
      },
      groups: {
        ledeY: ['Now use only two numbers, 0 and 1. The same switch rule makes a finite pattern, and we can count its symmetries, the ways to shuffle it without breaking it. Two families of shuffles fill these counts exactly.',
          'And the cube hides a famous code with 4096 words. In it, any five of 24 places lie together in exactly one special group of eight.'],
        lede: ['The finite lens: replace the real numbers by the two elements 0 and 1. The bit rule keeps working, and each cell leaves a finite shadow: the quadratic form Q on its 2^{n} blade addresses (Q(a) = 1 when the blade e_{a} squares to −1, 0 when it squares to +1), and its orthogonal group O(Q). The class of the shadow follows the clock and its order is counted exactly. Two families of familiar groups fill it: the Weyl groups W(E_{n}) reduced mod 2 give exactly O(Q) of Cl(n,0), for n = 3 … 8; the symmetric groups S_{n+1} of the simplex lie in O(Q) of Cl(0,n) and fill it only up to n = 5.',
          'At n = 3 the cube gives the Hamming code, and two copies of it, glued, give the Golay code and the Mathieu group M_{24}. The primes enter the picture one rung at a time: p first divides |GL(n,2)| at the rung n = order of 2 modulo p.'],
        ledeM: ['Over F₂ each cell Cl(p,q) leaves the quadratic form Q on its 2^{n} blade addresses (Q(a) = 1 exactly when e_{a} squares to −1) and its orthogonal group O(Q), whose order is counted exactly. The Weyl groups W(E_{n}) reduced mod 2 equal O(Q) of Cl(n,0) for n = 3 … 8; the symmetric groups S_{n+1} embed in O(Q) of Cl(0,n) and fill it only for n = 2 … 5, with index 8, 64, 960 at n = 6, 7, 8.'],
        glance: { tags: [['checked standard', 'the form Q and |O(Q)| for every class; W(E_{n}) mod 2 = O(Q) for n = 3…8; S_{n+1} in O(Q); the Pin lifts 2.A_{4} and 2.A_{5}; the Golay code, M_{24}, 196 560 Leech vectors; the primes by rung'], ['standard', 'uniqueness of the Golay code, simplicity of the large groups, the orders of Co_{1} and the Monster, Monster ⊃ 2^{1+24}.Co_{1}'], ['checked standard ours', 'reading S_{n+1} as permuting the positive generators; the finite shadow of a translation; the Klein link at n = 4'], ['open', 'groups of Lie type over more than two elements, the exceptional families, most sporadic groups; the exact statement of Cartan–Dieudonné in characteristic 2']],
          est: 'Established here: exact orders and identifications for n ≤ 8, the Golay/M_{24} chain, and the 2-part of the Monster. Quoted, not derived: classification statements and the big orders. Classes for n > 8 are checked as F_{2} forms only.', script: 'groups_check.py (parts A–F) · log groups_check.log · 29 mutants, all caught' },
      },
    },
    lattice: {
      title: 'Pick a cell: the clock reads its type', titleY: 'Pick a box: the clock tells what it is made of',
      cap: 'Each square is a cell Cl(p,q): p generators squaring to +1, q to −1; row n = p + q, columns q = 0…n. The colour is the ungraded type; the clock c = p − q mod 8 fixes it. Click or press Enter on a cell.',
      capY: 'Each square is a box with some plus switches and some minus switches. The colour says what the box is made of. Click a box.',
      types: { R: 'matrices of real numbers', R2: 'two copies of that', C: 'matrices of complex numbers', H: 'matrices of quaternions', H2: 'two copies of that' },
      typesY: { R: 'ordinary numbers', R2: 'two sets of ordinary numbers', C: 'turning numbers', H: 'spinning numbers', H2: 'two sets of spinning numbers' },
      rows: { cell: 'cell', n: 'generators n', clock: 'clock c = p − q mod 8', type: 'type', k: 'matrix size k', dim: 'dimension check', gauss: 'Gauss sum over the 2^{n} addresses', embed: 'inside Cl(n+2,0)', rotor: 'as rotors' },
      rowsY: { cell: 'box', n: 'switches', clock: 'place on the clock (0 to 7)', type: 'made of', k: 'size', dim: 'pieces', gauss: 'the hand of the clock', embed: 'hides in a plus-only box with two more switches', rotor: 'it is' },
      embedOk: 'all relations hold (squares, anticommutation, every image odd): checked now', dimTxt: (d, k, c, f) => `${d} = ${c > 1 ? c + ' · ' : ''}${k}^{2} · ${f}`,
      rotor: { 1: 'C = Cl(0,1) = the even part of Cl(2,0): the rotations of a plane', 2: 'H = Cl(0,2) = the even part of Cl(3,0): the rotations of 3-space (unit quaternions)', 3: 'H^{2} = Cl(0,3) = the even part of Cl(4,0): the rotations of 4-space (a left and a right quaternion)', any: n => `Cl(0,${n}) = the even part (the rotors) of the all-positive cell Cl(${n + 1},0)`, none: 'a cell with plus switches: it is not a rotor algebra of one more switch; it sits inside a plus-only cell' },
      rotorY: { 1: 'the rotations of a flat sheet', 2: 'the rotations of ordinary space', 3: 'the rotations of a space with four directions', any: 'the turns of a plus-only box with one more switch', none: 'not made of turns alone; it hides in a plus-only box' },
      wheel: 'The clock: eight places, c = 0…7. The arrow is the phase of the Gauss sum of the chosen cell.', wheelY: 'The clock has eight places. The arrow points where the chosen box sits.',
      pmW: (p, q) => `${p} plus, ${q} minus`, pmDot: (p, q) => `${p} plus · ${q} minus`, yesW: 'yes', gaussTxt: (re, im, n2, n, ph) => `${re} ${im < 0 ? '−' : '+'} ${Math.abs(im)} i,  norm² ${n2} = 2^{${n}},  phase ${ph} × 45°`,

    },
    trinity: {
      title: 'The three labels: spring, free, inverted', titleY: 'Spring, no spring, anti-spring',
      k: 'spring strength k', kY: 'spring strength', hand: 'Move the generator by hand: X = a e_{1} + b e_{2} + c e_{12}', handY: 'Move it by hand',
      names: { '-1': 'rotation: an oscillator, the orbits are ellipses', '0': 'translation: free motion, the orbits are straight lines', '1': 'boost: an inverted oscillator, the orbits are hyperbolas' },
      namesY: { '-1': 'the ball swings round and round', '0': 'the ball just drifts in a straight line', '1': 'the ball runs away' },
      cone: 'the generator in the (ρ, c) plane, ρ = √(a^{2} + b^{2}); the cone c = ±ρ is the 0 label', coneY: 'where the move sits: inside the cone it turns, outside it runs away, on the cone it slides',
      phase: 'phase plane (x, v): the orbits of exp(tX); the spring x″ = −kx has a = 0, b = (1−k)/2, c = (1+k)/2, so X^{2} = −k', phaseY: 'the path of the ball (position across, speed up)',
      pause: 'Pause', play: 'Play', counts: (g, c) => `On the whole-number grid −6…6 (${g.total} generators): ${c.ell} turn (X^{2} < 0), ${c.hyp} run away (X^{2} > 0), ${c.par} slide (X^{2} = 0, X ≠ 0).`, countsY: (g, c) => `Try every move on a grid of ${g.total}: ${c.ell} turn, ${c.hyp} run away, ${c.par} slide.`,
      read: (s, cls) => `X^{2} = a^{2} + b^{2} − c^{2} = ${s.toFixed(2)}  (label ${cls > 0 ? '+1' : cls < 0 ? '−1' : '0'})`,
      note: 'The line a e_{1} + … is a traceless 2×2 matrix; the square is exact (the bit rule of Cl(2,0) gives the same number for whole-number a, b, c). The 0 label is a translation of the phase plane (x → x + vt). On vectors of a non-degenerate cell the 0 class acts as a null rotation, and as a translation only in the projective picture.',
    },
    biv: {
      title: 'At n = 4 a bivector has two numbers', titleY: 'Four dimensions need two numbers',
      sig: 'signature', coef: 'bivector B = Σ b_{ij} e_{ij}', presets: { rot: 'a simple rotation', two: 'e_{12} + e_{34}', nul: 'a null simple one', cplx: 'a complex pair' },
      read: { S: 'S = ⟨B^{2}⟩_{0}', W: 'W = coefficient of e_{1234} in B^{2}', I2: 'I^{2} (+1 for q even, −1 for q odd)', D: 'discriminant S^{2} − W^{2}I^{2}', lam: 'the two squares λ of the commuting simple parts: λ^{2} − Sλ + W^{2}I^{2}/4 = 0' },
      verdict: { zero: 'zero', rotation: 'a simple rotation', boost: 'a simple boost', null: 'a null simple bivector', 'double-rotation': 'a double rotation (two real rotations)', 'double-boost': 'a double boost', 'rotation-boost': 'a rotation plus a boost', complex: 'a complex pair: not a sum of two real simple bivectors (loxodromic)', 'null-mixed': 'a null part plus another' },
      cap: 'B^{2} is a scalar S plus a 4-vector W e_{1234}: two invariants, so the single label −1/+1/0 is no longer enough. The roots are real in every signature except Cl(2,2), where the discriminant can go negative (the shaded wedge) and the complex numbers re-enter as the splitting field of a real bivector.',
      capY: 'In four dimensions a twist has two parts, not one. In one box only (two plus, two minus) the two parts can be a pair of complex numbers.',
      mc: (s) => `${s.N} whole-number bivectors per signature, ${s.skipped} of them zero or degenerate here: real ${s.real}, complex ${s.complex}.`,
      mcT: 'random bivectors with complex roots', mcTY: 'how often a twist needs complex numbers',
    },
    pg: {
      title: 'Rain falling through the horizon', titleY: 'Space falling into a black hole',
      r: 'distance r / 2M', rY: 'distance from the black hole', rev: 'reverse time (g → −g)', revY: 'run the film backwards',
      names: { '-1': 'outside: the vector e_{r} + g e_{t} is spacelike (class −1)', '0': 'on the horizon: the vector is null (class 0)', '1': 'inside: the vector is timelike (class +1)' },
      namesY: { '-1': 'outside: light can swim out', '0': 'at the edge: light stands still', '1': 'inside: even light is swept in' },
      read: (g, s) => `g = √(2M/r) = ${g.toFixed(3)}   (e_{r} + g e_{t})² = g^{2} − 1 = ${s.toFixed(3)}`,
      cap: 'Painlevé–Gullstrand form, ds^{2} = dt^{2} − (dr + g dt)^{2}. Each pair of lines is a light cone: outgoing rays have dr/dt = 1 − g, ingoing −1 − g; the rain (free fall from far away) has −g and crosses r = 2M smoothly. At g = 1 the outgoing ray stands still; inside it is swept in as well. Reversing time sends g to −g (T h̄_{g} T = h̄_{−g}): the cones tilt the other way, so the sign of g is the arrow of time. The cross-term sign is a frame convention, not physics.',
      capY: 'Each pair of lines shows where light can go from that spot. Close to the hole the lines lean inward. The blue curve is a raindrop falling in: it passes the edge without any bump.',
      horizon: 'horizon r = 2M', horizonY: 'the edge', rain: 'rain', shear: 'Schwarzschild is one shear of flat space: h̄ = 1 + N with N^{2} = 0, rank 1, determinant 1 (checked with matrices). It is not an isometry: gauge fields live in GL, rotors in the orthogonal group.',
    },
    curv: {
      title: 'Counting curvature: Riemann = Ricci + Weyl', titleY: 'Counting the ways space can bend',
      cap: 'Number of independent components of the curvature in n dimensions. For n ≥ 3 the Riemann tensor splits into Ricci (n(n+1)/2) and Weyl (n(n+1)(n+2)(n−3)/12). Weyl is first non-zero at n = 4, the same dimension at which B^{2} of a bivector first has two parts. At n = 2 the three Ricci components are all fixed by one scalar, which is the single Riemann component.',
      capY: 'How many numbers say how space is bent in n dimensions. The part in gold is the bend that is not fixed by the matter at that spot. It is zero up to three dimensions and first appears at four.',
      riem: 'Riemann', ricci: 'Ricci', weyl: 'Weyl', bsq: 'B² of a bivector', bsqS: 'a scalar', bsq4: 'scalar + 4-vector', at4: 'n = 4: 20 = 10 + 10 (Weyl as 5 complex numbers)',
      weylY: 'the bend that is not fixed by matter', ricciY: 'the bend fixed by matter', riemY: 'all the bend',
    },
    rails: {
      title: 'Two rails, one count', titleY: 'Two families of shuffles',
      cap: 'Outline: the size of O(Q), the symmetries of the finite shadow of the cell. Solid: what a family of familiar groups fills. Right: W(E_{n}) reduced mod 2 fills O(Q) of Cl(n,0) exactly for n = 3…8. Left: S_{n+1} inside O(Q) of Cl(0,n) fills it for n = 2…5 and falls short from n = 6. The two families are mirror images, n → −n, on the clock. Bars are on a log scale.',
      capY: 'Each bar counts the ways to shuffle a pattern. The coloured part is what one famous family of shuffles reaches. On the right it reaches all of them; on the left it reaches all of them up to five switches, and then falls short.',
      left: 'A_{n}: S_{n+1} in O(Q) of Cl(0,n)', right: 'E_{n}: W(E_{n}) mod 2 = O(Q) of Cl(n,0)', leftY: 'the family of the simplex', rightY: 'the family E, with the shape in 8 dimensions',
      row: { E: (n, e, f) => `n = ${n}: ${e[0]}, |W| = ${e[2].toLocaleString('en')}, kernel ${e[4]}, image ${e[3].toLocaleString('en')} = |O(Q)| (class ${e[1]})`, A: (n, a, idx) => `n = ${n}: S_{${n + 1}} = ${a[1].toLocaleString('en')} inside |O(Q)| = ${a[2].toLocaleString('en')} (class ${a[0]}), index ${idx}` },
      pin: 'The even Pin lifts of S_{4} and S_{5} in Cl(4,0) and Cl(5,0) are the binary tetrahedral group 2.A_{4} = SL(2,3) (order 24) and the binary icosahedral group 2.A_{5} = SL(2,5) (order 120).',
      none: '(no row at this n)',
    },
    golay: {
      title: 'The Golay code and the five-point rule', titleY: 'A code with 4096 words',
      cap: 'The [24,12,8] Golay code, built here from the cyclic code of length 23 plus a parity bit (the script builds it from two cube codes and checks that the weights agree). 4096 words of weight 0, 8, 12, 16, 24; the 759 words of weight 8 are the octads. Tap points on the ring: the octads through them shrink 759 → 253 → 77 → 21 → 5 → 1, and five points pick exactly one octad (a Steiner system S(5,8,24); all 42 504 five-sets were checked). Its symmetry group M_{24} has order 244 823 040 and is 5-transitive.',
      capY: 'Tap places on the ring. The more you tap, the fewer special groups of eight still contain them. After five taps exactly one is left.',
      weights: 'weights of the 4096 words', count: k => `${k} point${k === 1 ? '' : 's'} chosen`, through: n => `${n} octad${n === 1 ? '' : 's'} through them`, unique: 'exactly one octad', clear: 'Clear', demo: 'Show an octad',
      countY: k => `${k} place${k === 1 ? '' : 's'} tapped`, throughY: n => `${n} group${n === 1 ? '' : 's'} of eight still contain them`, uniqueY: 'exactly one group of eight',
      link: 'The same code is a maximal totally singular subspace of the address form of Cl(24,0) (Witt index 12), and the 2-part of the Monster is 2^{46}: the blade group of Cl(24,0) has order 2^{25}, and the 2-part of |Co_{1}| is 2^{21}.',
    },
    primes: {
      title: 'The rung where each prime enters', titleY: 'Which step first needs each prime',
      n: 'rung n', cap: 'A prime p first divides |GL(n,2)| at the rung n = the order of 2 modulo p. Slide n to see the primes that enter at that rung. The gold dots are the 14 odd primes of the order of the Monster, at their rungs; 59 enters last, at n = 58. n = 6 is the one rung with no new prime (Zsigmondy).',
      capY: 'Slide to a step n. The primes shown are the ones that appear for the first time at that step. The gold ones divide the size of the Monster, the biggest sporadic group.',
      enters: n => `rung n = ${n}: new primes`, none: 'none (the one exception: 2^{6} − 1 = 63 = 3^{2} · 7)', monster: 'divides the order of the Monster',
    },
    checkedNote: 'Everything in the pictures is recomputed in your browser; the Python scripts in the package are the reference (README_update_v10.md).',
  },
  it: {
    live: 'calcolato ora nel tuo browser',
    tabs: {
      clock: {
        ledeY: ['Ogni scatola ha una lancetta su un orologio con otto posti. Il posto dice di che cosa è fatta la scatola: numeri comuni, numeri che girano o numeri che ruotano, una copia o due. Clicca una scatola e il computer lo calcola.',
          'Le scatole dall’aspetto strano non sono nuove. I numeri che girano sono le rotazioni di un foglio piatto, i numeri che ruotano sono le rotazioni dello spazio. E ogni scatola può nascondersi in una scatola con soli interruttori più, con due interruttori in più.'],
        lede: ['Ogni cella ha un’etichetta sull’orologio Z_{8}, c = p − q mod 8, e l’orologio fissa che cos’è la cella: R, R^{2}, C, H o H^{2} (matrici sui reali, sui complessi o sui quaternioni, una volta o due). Scegli una cella: il computer ricostruisce il suo tipo, la dimensione delle matrici e la fase di una somma di Gauss sui suoi 2^{n} indirizzi di lama, che è l’orologio.',
          'Due fatti bastano per le celle tutte positive. C, H e H^{2} non sono oggetti nuovi: Cl(0,n) è la parte pari (i rotori) della cella tutta positiva con un generatore in più. E ogni Cl(p,q) sta dentro la cella tutta positiva con due generatori in più, con la graduazione conservata: un generatore positivo resta, uno negativo è moltiplicato per P = e_{n+1}e_{n+2}, il cui quadrato è −1.'],
        ledeM: ['Ogni cella Cl(p,q) porta la classe c = p − q mod 8 in Z_{8}. Per la periodicità di Bott la classe fissa il tipo di Wedderburn fra R, R^{2}, C, H, H^{2} e la dimensione delle matrici. Per una cella scelta la pagina lo ricalcola in tre modi: dalla regola dei bit, come dimensione di matrici, e come fase della somma di Gauss sui 2^{n} indirizzi di lama, che vale (1+i) alla p per (1−i) alla q, quindi con argomento c × 45°.'],
        glance: { tags: [['checked standard', 'C, H, H^{2} e ogni Cl(0,n) come algebre di rotori (72 isomorfismi, n ≤ 8); l’immersione in Cl(n+2,0); la trinità; le radici a n = 4'], ['standard', 'la tabella di classificazione delle algebre di Clifford'], ['checked ours', 'leggere −1, +1, 0 come rotazione, boost, traslazione'], ['checked standard', 'la traslazione dentro una cella non degenere: una rotazione nulla, T = 1 − a n_{∞}/2 con n_{∞} nullo (controllata in gtg_check.py, parte R)']],
          est: 'Stabilito qui: l’etichetta 0 è una traslazione solo nell’algebra dei generatori (e nel quadro proiettivo); sui vettori di una cella non degenere è una rotazione nulla. Da n = 4 l’etichetta −1/+1/0 non basta più: un bivettore ha due numeri.', script: 'labels_check.py (sezioni 1–11) · log labels_check.log' },
      },
      gauge: {
        ledeY: ['Pensa allo spazio stesso che cade in un buco nero, come l’acqua in uno scarico. Lontano cade piano, più vicino cade più in fretta, e a una certa distanza, il bordo, cade veloce quanto la luce riesce a nuotare contro.',
          'Ricompaiono gli stessi tre segni. Fuori dal bordo la luce può nuotare via. Sul bordo sta ferma. Dentro, anche la luce viene trascinata. In fondo si contano anche i numeri che servono per dire come lo spazio è curvo.'],
        lede: ['La gravità come teoria di gauge (Lasenby, Doran e Gull) scrive la gravità come un campo di gauge sullo spazio piatto: una mappa lineare h̄ dei vettori che dipende dal punto. Nel gauge newtoniano (forma di Painlevé–Gullstrand) Schwarzschild è un solo taglio unipotente, h̄ = 1 + N con N^{2} = 0; l’abbiamo ricostruito con matrici. Il vettore di flusso e_{r} + g e_{t}, con g = √(2M/r), ha quadrato g^{2} − 1: negativo fuori, 0 sull’orizzonte, positivo dentro. È la stessa suddivisione in tre della trinità della molla, ora nel piano (t, r) Cl(1,1).',
          'La seconda immagine conta la curvatura. Riemann = Ricci + Weyl per n ≥ 3, e la parte di Weyl è diversa da zero per la prima volta a n = 4, la dimensione in cui un bivettore ha per la prima volta un quadrato in due parti.'],
        ledeM: ['La gravità come teoria di gauge mette il campo gravitazionale in una mappa lineare h̄ dipendente dal punto, sullo spazio piatto. Nel gauge newtoniano (Painlevé–Gullstrand) Schwarzschild è un unico taglio unipotente, h̄ = 1 + N con N^{2} = 0, ricostruito qui con matrici esplicite. Il vettore di flusso v = e_{r} + g e_{t}, g = √(2M/r), ha v^{2} = g^{2} − 1, negativo fuori, 0 sull’orizzonte, positivo dentro: le tre classi della trinità della molla, nel piano Cl(1,1).'],
        glance: { tags: [['checked standard ours', `il taglio h̄ = 1 + N con N^{2} = 0 (forma di Painlevé–Gullstrand), (e_{r} + g e_{t})^{2} = g^{2} − 1, il vettore nullo di Kerr–Schild, l’inversione temporale come una sola riflessione e i conteggi della curvatura (formule da manuale, calcolate nel passo ${stepNo('eq', 'grav1')}); leggere r = 2M come la classe 0 (un nullo accoppiato del piano (t, r))`], ['checked standard', 'la gravità come teoria di gauge; gli autovalori della mappa di Weyl (4, −2, −2)'], ['ours', 'leggere l’orizzonte come etichetta 0 del piano (t, r): non accoppiata (il radicale) nell’algebra tangente Cl(0,2,1) della superficie, il nullo accoppiato e_{t} − e_{r} dentro Cl(1,1)'], ['open', 'le equazioni di campo, la cosmologia e le parti su Hawking dell’articolo non sono decodificate']],
          est: 'Stabilito qui: solo la cinematica. Il taglio, il segno dell’orizzonte, la forma di Kerr–Schild, il segno di g come freccia del tempo (il segno del termine misto è una convenzione di riferimento) e i conteggi della curvatura. Non decodificate: le equazioni di campo.', script: 'gtg_check.py (parti S e G, e R per Roelfs–De Keninck) · log gtg_check.log' },
      },
      groups: {
        ledeY: ['Ora usiamo solo due numeri, 0 e 1. La stessa regola degli interruttori fa uno schema finito, e possiamo contare le sue simmetrie, i modi di rimescolarlo senza romperlo. Due famiglie di rimescolamenti riempiono questi conti esattamente.',
          'E il cubo nasconde un codice famoso con 4096 parole. Dentro, ogni cinque posti su 24 stanno insieme in uno e un solo gruppo speciale di otto.'],
        lede: ['La lente finita: si sostituiscono i numeri reali con i due elementi 0 e 1. La regola dei bit continua a funzionare, e ogni cella lascia un’ombra finita: la forma quadratica Q sui suoi 2^{n} indirizzi di lama (Q(a) = 1 quando la lama e_{a} ha quadrato −1, 0 quando ha quadrato +1), e il suo gruppo ortogonale O(Q). La classe dell’ombra segue l’orologio e il suo ordine si conta esattamente. Due famiglie di gruppi noti la riempiono: i gruppi di Weyl W(E_{n}) ridotti mod 2 danno esattamente O(Q) di Cl(n,0), per n = 3 … 8; i gruppi simmetrici S_{n+1} del simplesso stanno in O(Q) di Cl(0,n) e lo riempiono solo fino a n = 5.',
          'A n = 3 il cubo dà il codice di Hamming, e due copie incollate danno il codice di Golay e il gruppo di Mathieu M_{24}. I primi entrano uno a ogni gradino: p divide per la prima volta |GL(n,2)| al gradino n = ordine di 2 modulo p.'],
        ledeM: ['Su F₂ ogni cella Cl(p,q) lascia la forma quadratica Q sui suoi 2^{n} indirizzi di lama (Q(a) = 1 esattamente quando e_{a} ha quadrato −1) e il suo gruppo ortogonale O(Q), il cui ordine si conta esattamente. I gruppi di Weyl W(E_{n}) ridotti mod 2 sono uguali a O(Q) di Cl(n,0) per n = 3 … 8; i gruppi simmetrici S_{n+1} entrano in O(Q) di Cl(0,n) e lo riempiono solo per n = 2 … 5, con indice 8, 64, 960 per n = 6, 7, 8.'],
        glance: { tags: [['checked standard', 'la forma Q e |O(Q)| per ogni classe; W(E_{n}) mod 2 = O(Q) per n = 3…8; S_{n+1} in O(Q); i sollevamenti Pin 2.A_{4} e 2.A_{5}; il codice di Golay, M_{24}, 196 560 vettori di Leech; i primi per gradino'], ['standard', 'unicità del codice di Golay, semplicità dei grandi gruppi, gli ordini di Co_{1} e del Mostro, Mostro ⊃ 2^{1+24}.Co_{1}'], ['checked standard ours', 'leggere S_{n+1} come permutazione dei generatori positivi; l’ombra finita di una traslazione; il legame di Klein a n = 4'], ['open', 'gruppi di tipo Lie su più di due elementi, le famiglie eccezionali, la maggior parte dei gruppi sporadici; l’enunciato esatto di Cartan–Dieudonné in caratteristica 2']],
          est: 'Stabilito qui: ordini e identificazioni esatti per n ≤ 8, la catena Golay/M_{24} e la parte 2 del Mostro. Citati, non derivati: gli enunciati di classificazione e i grandi ordini. Le classi per n > 8 sono controllate solo come forme su F_{2}.', script: 'groups_check.py (parti A–F) · log groups_check.log · 29 mutanti, tutti scoperti' },
      },
    },
    lattice: {
      title: 'Scegli una cella: l’orologio ne legge il tipo', titleY: 'Scegli una scatola: l’orologio dice di che cosa è fatta',
      cap: 'Ogni quadrato è una cella Cl(p,q): p generatori che al quadrato danno +1, q che danno −1; riga n = p + q, colonne q = 0…n. Il colore è il tipo non graduato; l’orologio c = p − q mod 8 lo fissa. Clicca o premi Invio su una cella.',
      capY: 'Ogni quadrato è una scatola con alcuni interruttori più e alcuni meno. Il colore dice di che cosa è fatta. Clicca una scatola.',
      types: { R: 'matrici di numeri reali', R2: 'due copie di quelle', C: 'matrici di numeri complessi', H: 'matrici di quaternioni', H2: 'due copie di quelle' },
      typesY: { R: 'numeri comuni', R2: 'due serie di numeri comuni', C: 'numeri che girano', H: 'numeri che ruotano', H2: 'due serie di numeri che ruotano' },
      rows: { cell: 'cella', n: 'generatori n', clock: 'orologio c = p − q mod 8', type: 'tipo', k: 'dimensione k delle matrici', dim: 'controllo della dimensione', gauss: 'somma di Gauss sui 2^{n} indirizzi', embed: 'dentro Cl(n+2,0)', rotor: 'come rotori' },
      rowsY: { cell: 'scatola', n: 'interruttori', clock: 'posto sull’orologio (da 0 a 7)', type: 'fatta di', k: 'dimensione', dim: 'pezzi', gauss: 'la lancetta dell’orologio', embed: 'si nasconde in una scatola solo più con due interruttori in più', rotor: 'è' },
      embedOk: 'tutte le relazioni valgono (quadrati, anticommutazione, ogni immagine dispari): controllato ora', dimTxt: (d, k, c, f) => `${d} = ${c > 1 ? c + ' · ' : ''}${k}^{2} · ${f}`,
      rotor: { 1: 'C = Cl(0,1) = la parte pari di Cl(2,0): le rotazioni di un piano', 2: 'H = Cl(0,2) = la parte pari di Cl(3,0): le rotazioni dello spazio a 3 dimensioni (quaternioni unitari)', 3: 'H^{2} = Cl(0,3) = la parte pari di Cl(4,0): le rotazioni dello spazio a 4 dimensioni (un quaternione sinistro e uno destro)', any: n => `Cl(0,${n}) = la parte pari (i rotori) della cella tutta positiva Cl(${n + 1},0)`, none: 'una cella con interruttori più: non è l’algebra dei rotori di un interruttore in più; sta dentro una cella solo più' },
      rotorY: { 1: 'le rotazioni di un foglio piatto', 2: 'le rotazioni dello spazio comune', 3: 'le rotazioni di uno spazio con quattro direzioni', any: 'le svolte di una scatola solo più con un interruttore in più', none: 'non è fatta di sole svolte; si nasconde in una scatola solo più' },
      wheel: 'L’orologio: otto posti, c = 0…7. La freccia è la fase della somma di Gauss della cella scelta.', wheelY: 'L’orologio ha otto posti. La freccia indica dove sta la scatola scelta.',
      pmW: (p, q) => `${p} più, ${q} meno`, pmDot: (p, q) => `${p} più · ${q} meno`, yesW: 'sì', gaussTxt: (re, im, n2, n, ph) => `${re} ${im < 0 ? '−' : '+'} ${Math.abs(im)} i,  norma² ${n2} = 2^{${n}},  fase ${ph} × 45°`,

    },
    trinity: {
      title: 'Le tre etichette: molla, libero, invertito', titleY: 'Molla, niente molla, anti-molla',
      k: 'forza della molla k', kY: 'forza della molla', hand: 'Muovi il generatore a mano: X = a e_{1} + b e_{2} + c e_{12}', handY: 'Muovilo a mano',
      names: { '-1': 'rotazione: un oscillatore, le orbite sono ellissi', '0': 'traslazione: moto libero, le orbite sono rette', '1': 'boost: un oscillatore invertito, le orbite sono iperboli' },
      namesY: { '-1': 'la palla oscilla girando e girando', '0': 'la palla scivola dritta', '1': 'la palla scappa via' },
      cone: 'il generatore nel piano (ρ, c), ρ = √(a^{2} + b^{2}); il cono c = ±ρ è l’etichetta 0', coneY: 'dove sta la mossa: dentro il cono gira, fuori scappa, sul cono scivola',
      phase: 'piano delle fasi (x, v): le orbite di exp(tX); la molla x″ = −kx ha a = 0, b = (1−k)/2, c = (1+k)/2, quindi X^{2} = −k', phaseY: 'il percorso della palla (posizione in orizzontale, velocità in alto)',
      pause: 'Pausa', play: 'Avvia', counts: (g, c) => `Sulla griglia di interi −6…6 (${g.total} generatori): ${c.ell} girano (X^{2} < 0), ${c.hyp} scappano (X^{2} > 0), ${c.par} scivolano (X^{2} = 0, X ≠ 0).`, countsY: (g, c) => `Proviamo ogni mossa su una griglia di ${g.total}: ${c.ell} girano, ${c.hyp} scappano, ${c.par} scivolano.`,
      read: (s, cls) => `X^{2} = a^{2} + b^{2} − c^{2} = ${s.toFixed(2)}  (etichetta ${cls > 0 ? '+1' : cls < 0 ? '−1' : '0'})`,
      note: 'Il generatore è una matrice 2×2 a traccia nulla; il quadrato è esatto (la regola dei bit di Cl(2,0) dà lo stesso numero per a, b, c interi). L’etichetta 0 è una traslazione del piano delle fasi (x → x + vt). Sui vettori di una cella non degenere la classe 0 agisce come rotazione nulla, e come traslazione solo nel quadro proiettivo.',
    },
    biv: {
      title: 'A n = 4 un bivettore ha due numeri', titleY: 'Quattro dimensioni vogliono due numeri',
      sig: 'segnatura', coef: 'bivettore B = Σ b_{ij} e_{ij}', presets: { rot: 'una rotazione semplice', two: 'e_{12} + e_{34}', nul: 'uno semplice nullo', cplx: 'una coppia complessa' },
      read: { S: 'S = ⟨B^{2}⟩_{0}', W: 'W = coefficiente di e_{1234} in B^{2}', I2: 'I^{2} (+1 per q pari, −1 per q dispari)', D: 'discriminante S^{2} − W^{2}I^{2}', lam: 'i due quadrati λ delle parti semplici che commutano: λ^{2} − Sλ + W^{2}I^{2}/4 = 0' },
      verdict: { zero: 'zero', rotation: 'una rotazione semplice', boost: 'un boost semplice', null: 'un bivettore semplice nullo', 'double-rotation': 'una doppia rotazione (due rotazioni reali)', 'double-boost': 'un doppio boost', 'rotation-boost': 'una rotazione più un boost', complex: 'una coppia complessa: non è somma di due bivettori semplici reali (lossodromica)', 'null-mixed': 'una parte nulla più un’altra' },
      cap: 'B^{2} è uno scalare S più un 4-vettore W e_{1234}: due invarianti, quindi la sola etichetta −1/+1/0 non basta più. Le radici sono reali in ogni segnatura tranne Cl(2,2), dove il discriminante può diventare negativo (il cuneo in ombra) e i numeri complessi rientrano come campo di spezzamento di un bivettore reale.',
      capY: 'In quattro dimensioni una torsione ha due parti, non una. In una sola scatola (due più, due meno) le due parti possono essere una coppia di numeri complessi.',
      mc: (s) => `${s.N} bivettori interi per segnatura, ${s.skipped} dei quali nulli o degeneri qui: reali ${s.real}, complessi ${s.complex}.`,
      mcT: 'bivettori casuali con radici complesse', mcTY: 'quante volte una torsione richiede numeri complessi',
    },
    pg: {
      title: 'La pioggia che cade attraverso l’orizzonte', titleY: 'Lo spazio che cade in un buco nero',
      r: 'distanza r / 2M', rY: 'distanza dal buco nero', rev: 'inverti il tempo (g → −g)', revY: 'fai andare il film all’indietro',
      names: { '-1': 'fuori: il vettore e_{r} + g e_{t} è di tipo spazio (classe −1)', '0': 'sull’orizzonte: il vettore è nullo (classe 0)', '1': 'dentro: il vettore è di tipo tempo (classe +1)' },
      namesY: { '-1': 'fuori: la luce può nuotare via', '0': 'sul bordo: la luce sta ferma', '1': 'dentro: anche la luce è trascinata' },
      read: (g, s) => `g = √(2M/r) = ${g.toFixed(3)}   (e_{r} + g e_{t})² = g^{2} − 1 = ${s.toFixed(3)}`,
      cap: 'Forma di Painlevé–Gullstrand, ds^{2} = dt^{2} − (dr + g dt)^{2}. Ogni coppia di linee è un cono di luce: i raggi uscenti hanno dr/dt = 1 − g, quelli entranti −1 − g; la pioggia (caduta libera da lontano) ha −g e attraversa r = 2M senza scosse. A g = 1 il raggio uscente sta fermo; dentro viene trascinato anche lui. Invertire il tempo manda g in −g (T h̄_{g} T = h̄_{−g}): i coni si inclinano dall’altra parte, quindi il segno di g è la freccia del tempo. Il segno del termine misto è una convenzione di riferimento, non fisica.',
      capY: 'Ogni coppia di linee mostra dove può andare la luce da quel punto. Vicino al buco le linee si piegano verso l’interno. La curva blu è una goccia di pioggia che cade: passa il bordo senza alcun urto.',
      horizon: 'orizzonte r = 2M', horizonY: 'il bordo', rain: 'pioggia', shear: 'Schwarzschild è un solo taglio dello spazio piatto: h̄ = 1 + N con N^{2} = 0, rango 1, determinante 1 (controllato con matrici). Non è un’isometria: i campi di gauge vivono in GL, i rotori nel gruppo ortogonale.',
    },
    curv: {
      title: 'Contare la curvatura: Riemann = Ricci + Weyl', titleY: 'Contare i modi in cui lo spazio può curvarsi',
      cap: 'Numero di componenti indipendenti della curvatura in n dimensioni. Per n ≥ 3 il tensore di Riemann si spezza in Ricci (n(n+1)/2) e Weyl (n(n+1)(n+2)(n−3)/12). Weyl è diverso da zero per la prima volta a n = 4, la stessa dimensione in cui B^{2} di un bivettore ha per la prima volta due parti. A n = 2 le tre componenti di Ricci sono tutte fissate da uno scalare, che è l’unica componente di Riemann.',
      capY: 'Quanti numeri dicono come lo spazio è curvo in n dimensioni. La parte dorata è la curvatura non fissata dalla materia in quel punto. È zero fino a tre dimensioni e compare per la prima volta a quattro.',
      riem: 'Riemann', ricci: 'Ricci', weyl: 'Weyl', bsq: 'B² di un bivettore', bsqS: 'uno scalare', bsq4: 'scalare + 4-vettore', at4: 'n = 4: 20 = 10 + 10 (Weyl come 5 numeri complessi)',
      weylY: 'la curvatura non fissata dalla materia', ricciY: 'la curvatura fissata dalla materia', riemY: 'tutta la curvatura',
    },
    rails: {
      title: 'Due rotaie, un solo conto', titleY: 'Due famiglie di rimescolamenti',
      cap: 'Contorno: la grandezza di O(Q), le simmetrie dell’ombra finita della cella. Pieno: quanto ne riempie una famiglia di gruppi noti. A destra: W(E_{n}) ridotto mod 2 riempie O(Q) di Cl(n,0) esattamente per n = 3…8. A sinistra: S_{n+1} dentro O(Q) di Cl(0,n) lo riempie per n = 2…5 e non basta da n = 6. Le due famiglie sono immagini speculari, n → −n, sull’orologio. Le barre sono in scala logaritmica.',
      capY: 'Ogni barra conta i modi di rimescolare uno schema. La parte colorata è quanto ne raggiunge una famosa famiglia di rimescolamenti. A destra li raggiunge tutti; a sinistra li raggiunge tutti fino a cinque interruttori, poi non basta più.',
      left: 'A_{n}: S_{n+1} in O(Q) di Cl(0,n)', right: 'E_{n}: W(E_{n}) mod 2 = O(Q) di Cl(n,0)', leftY: 'la famiglia del simplesso', rightY: 'la famiglia E, con la forma a 8 dimensioni',
      row: { E: (n, e, f) => `n = ${n}: ${e[0]}, |W| = ${e[2].toLocaleString('it')}, nucleo ${e[4]}, immagine ${e[3].toLocaleString('it')} = |O(Q)| (classe ${e[1]})`, A: (n, a, idx) => `n = ${n}: S_{${n + 1}} = ${a[1].toLocaleString('it')} dentro |O(Q)| = ${a[2].toLocaleString('it')} (classe ${a[0]}), indice ${idx}` },
      pin: 'I sollevamenti Pin pari di S_{4} e S_{5} in Cl(4,0) e Cl(5,0) sono il gruppo tetraedrale binario 2.A_{4} = SL(2,3) (ordine 24) e il gruppo icosaedrale binario 2.A_{5} = SL(2,5) (ordine 120).',
      none: '(nessuna riga per questo n)',
    },
    golay: {
      title: 'Il codice di Golay e la regola dei cinque punti', titleY: 'Un codice con 4096 parole',
      cap: 'Il codice di Golay [24,12,8], costruito qui dal codice ciclico di lunghezza 23 più un bit di parità (lo script lo costruisce da due codici del cubo e controlla che i pesi coincidano). 4096 parole di peso 0, 8, 12, 16, 24; le 759 parole di peso 8 sono le ottadi. Tocca punti sull’anello: le ottadi che li contengono scendono 759 → 253 → 77 → 21 → 5 → 1, e cinque punti scelgono esattamente un’ottade (un sistema di Steiner S(5,8,24); tutti i 42 504 insiemi di cinque punti sono stati controllati). Il suo gruppo di simmetria M_{24} ha ordine 244 823 040 ed è 5-transitivo.',
      capY: 'Tocca dei posti sull’anello. Più ne tocchi, meno gruppi speciali di otto li contengono ancora. Dopo cinque tocchi ne resta esattamente uno.',
      weights: 'pesi delle 4096 parole', count: k => `${k} ${k === 1 ? 'punto scelto' : 'punti scelti'}`, through: n => `${n} ${n === 1 ? 'ottade li contiene' : 'ottadi li contengono'}`, unique: 'esattamente un’ottade', clear: 'Azzera', demo: 'Mostra un’ottade',
      countY: k => `${k} ${k === 1 ? 'posto toccato' : 'posti toccati'}`, throughY: n => `${n} ${n === 1 ? 'gruppo di otto li contiene ancora' : 'gruppi di otto li contengono ancora'}`, uniqueY: 'esattamente un gruppo di otto',
      link: 'Lo stesso codice è un sottospazio totalmente singolare massimale della forma degli indirizzi di Cl(24,0) (indice di Witt 12), e la parte 2 del Mostro è 2^{46}: il gruppo delle lame di Cl(24,0) ha ordine 2^{25}, e la parte 2 di |Co_{1}| è 2^{21}.',
    },
    primes: {
      title: 'Il gradino in cui entra ogni primo', titleY: 'Quale passo ha bisogno per primo di ogni numero primo',
      n: 'gradino n', cap: 'Un primo p divide per la prima volta |GL(n,2)| al gradino n = l’ordine di 2 modulo p. Fai scorrere n per vedere i primi che entrano a quel gradino. I punti dorati sono i 14 primi dispari dell’ordine del Mostro, ai loro gradini; 59 entra per ultimo, a n = 58. n = 6 è l’unico gradino senza primi nuovi (Zsigmondy).',
      capY: 'Fai scorrere fino a un passo n. I primi mostrati sono quelli che compaiono per la prima volta a quel passo. Quelli dorati dividono la grandezza del Mostro, il più grande gruppo sporadico.',
      enters: n => `gradino n = ${n}: primi nuovi`, none: 'nessuno (l’unica eccezione: 2^{6} − 1 = 63 = 3^{2} · 7)', monster: 'divide l’ordine del Mostro',
    },
    checkedNote: 'Tutto ciò che è nelle immagini è ricalcolato nel tuo browser; gli script Python del pacchetto sono il riferimento (README_update_v10.md).',
  },
};
