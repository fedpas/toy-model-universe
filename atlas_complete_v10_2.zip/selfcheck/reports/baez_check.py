#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Seven Baez papers and the bit rule (third note, 5 October 2026).  Questions asked: how are the seven papers related to each other, and can the bit rule (labels, Clifford signs, Hodge complement, the
trio -1, 0, +1) reproduce, explain or sharpen their statements?  Every statement below is computed; what the papers claim is hard-coded from the papers' own text (page references in the report) and
compared with what the label rule gives.  Readings are tagged in the messages and in the report.
Python standard library + numpy + networkx + scipy.   Run: python3 baez_check.py
Shipped in the webapp package as selfcheck/reports/baez_check.py: needs bitcliff.py at <package>/selfcheck/steps15_17 (default: the package two levels up from this script; override with the environment variable ATLAS_PKG). Python dependencies: numpy, networkx, scipy (and the standard library). Writes nothing into the package: the figure data logs/baez_figdata.json is written only with --write (and only if a logs folder exists next to the script). The seven papers' texts are not shipped, so R1 (cross-citations) is skipped here and not counted."""
import os, sys, math, random, itertools, re
from fractions import Fraction as Fr
from collections import Counter
import numpy as np
import networkx as nx
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..'))      # the webapp package: two levels up from selfcheck/reports/
sys.path.insert(0, os.path.join(PKG, 'selfcheck', 'steps15_17'))
from bitcliff import Alg, sig, pc, reorder_sign, TYPES

N_OK = N_BAD = 0
def chk(cid, cond, msg=''):
    global N_OK, N_BAD
    if cond: N_OK += 1
    else: N_BAD += 1
    print(('ok   ' if cond else 'FAIL ') + cid + (': ' + msg if msg else ''))
# =====================================================================================================================================================
# R. How the seven papers cite one another (read from the text files extracted from the seven PDFs).
# =====================================================================================================================================================
IDS = {'kepler': '2507.11428', 'cospan': '2509.22584', 'tri': '2606.10072', 'gauge': '2606.15235', 'jordan': '2607.10833', 'e7': '2608.06271', 'geo': '2609.07538'}
FILES = {'kepler': 'Second_Quantization_for_the_Kepler_Problem', 'cospan': 'Double_Categories_of_Open_Systems_-_the_Cospan_Approach', 'tri': 'Triangulations_of_the_Sphere',
         'gauge': 'The_Standard_Model_Gauge_Group_from_the_Exceptional_Jordan_Algebra', 'jordan': 'Jordan_Pair_Quantum_Theory_and_the_Standard_Model', 'e7': 'Three_Generations_in_E7',
         'geo': 'Three-Dimensional_Geometry_in_Exceptional_Algebra'}
TXT = {}
for k, v in FILES.items():
    p = os.path.join(HERE, 'txt', v + '.txt')
    TXT[k] = re.sub(r'\s+', ' ', open(p, encoding='utf-8', errors='replace').read()) if os.path.exists(p) else ''
edges = sorted((a, b) for a in IDS for b in IDS if a != b and IDS[b] in TXT[a])
if not all(TXT.values()):
    print('skip R1: the seven texts are not beside this script (txt/ folder, made with pdftotext from the papers; not shipped): the cross-citation check cannot run here and is not counted')
    edges = []                                                                   # no texts, no edges (the list is used only for the figure data, written next to the texts)
else: chk('R1', all(len(TXT[k]) > 5000 for k in TXT) and edges == [('e7', 'jordan'), ('geo', 'gauge'), ('jordan', 'gauge')],
    'cross-citations found by arXiv number in the seven texts: ' + ', '.join(f'{a} -> {b}' for a, b in edges) + '. The four papers on the exceptional Jordan algebra form one cited chain (gauge <- jordan <- e7, gauge <- geo); the Kepler, triangulation and cospan papers cite none of the others, and are cited by none')

# =====================================================================================================================================================
# H. Five-bit labels and one generation.  The Baez-Bokor-Boyle paper (Sec. 5.1) cuts the 16 complex dimensions of the bi-Cayley triple with the Peirce projectors of two colinear
#    minimal tripotents e1, e2 and finds six pieces of dimension 1,1,6,3,3,2 that are the six irreducible representations of one generation (their eqs. (69), (75), (76)).
#    Here: the 5-bit labels, with bits 0,1 (weak: u, d) and bits 2,3,4 (colour: r, g, b).
# =====================================================================================================================================================
a_of = lambda x: pc(x & 3)          # number of weak bits set
b_of = lambda x: pc(x >> 2)         # number of colour bits set
LAB = range(32)
grading = [sum(1 for x in LAB if pc(x) == k) for k in range(6)]
EVEN = [x for x in LAB if pc(x) % 2 == 0]; ODD = [x for x in LAB if pc(x) % 2 == 1]
chk('H1a', grading == [1, 5, 10, 10, 5, 1] and len(EVEN) == 16 and len(ODD) == 16 and [pc(x) for x in range(32)].count(2) == 10,
    'the 32 five-bit labels graded by number of set bits: 1, 5, 10, 10, 5, 1 = dimensions of the exterior powers of C^5; even labels 1 + 10 + 5 = 16, odd labels 5 + 10 + 1 = 16 (Spin(10): 16 + 16-bar)')
chk('H1b', all(pc(x ^ 31) == 5 - pc(x) and (x ^ 31) ^ 31 == x and (pc(x ^ 31) % 2) != (pc(x) % 2) for x in LAB),
    'the all-ones mask (XOR with 11111, the Hodge complement of F7) is an involution that sends k set bits to 5-k and swaps even with odd labels: particle <-> antiparticle')
# the paper's table (69),(76): names, dimensions, hypercharges Y (the six pieces that occur); P_l2(e2) P_l1(e1) with l = Peirce eigenvalue
BBB = {(Fr(1, 2), Fr(1)): ('e-bar_R', 1, Fr(1)), (Fr(1), Fr(1, 2)): ('nu-bar_R', 1, Fr(0)), (Fr(1, 2), Fr(1, 2)): ('q_L', 6, Fr(1, 6)),
       (Fr(0), Fr(1, 2)): ('d-bar_R', 3, Fr(1, 3)), (Fr(1, 2), Fr(0)): ('u-bar_R', 3, Fr(-2, 3)), (Fr(0), Fr(0)): ('l_L', 2, Fr(-1, 2))}
S2 = 0b00011                                                  # e2 sits on the weak pair; e1 on the empty label (the vacuum)
lam1 = lambda x: 1 - Fr(pc(x), 4)                             # Peirce eigenvalue of x w.r.t. e1: 1 - (Hamming distance to the vacuum label)/4
lam2 = lambda x: 1 - Fr(pc(x ^ S2), 4)                        # same for e2: 1 - (Hamming distance to the label of e2)/4
classes = {}
for x in EVEN: classes.setdefault((lam1(x), lam2(x)), []).append(x)
Yf = lambda x: Fr(a_of(x), 2) - Fr(b_of(x), 3)
ok = set(classes) == set(BBB) and all(len(classes[k]) == BBB[k][1] for k in BBB)
ok &= all(Yf(x) == BBB[k][2] for k in BBB for x in classes.get(k, []))
ok &= all(len({(a_of(x), b_of(x)) for x in classes[k]}) == 1 for k in classes) and len({(a_of(classes[k][0]), b_of(classes[k][0])) for k in classes}) == 6
chk('H2a', ok, 'Peirce eigenvalue of an even label x with respect to a tripotent whose label is S: 1 - d(x,S)/4 (d = Hamming distance). For e1 = the empty label and e2 = the weak pair, the 16 even labels fall into exactly the six non-vanishing '
    '(l1,l2) pieces of the paper, sizes 1,1,6,3,3,2 = ' + ', '.join(f'{BBB[k][0]}: {len(classes.get(k, []))}' for k in BBB) + '; the two-eigenvalue pieces that the paper finds to vanish (P1P1, P1P0, P0P1) are empty; and the pieces are exactly the classes (number of weak bits, number of colour bits)')
chk('H2b', all(Yf(x) == Fr(a_of(x), 2) - Fr(b_of(x), 3) for x in LAB) and Counter(Yf(x) for x in EVEN) == Counter({Fr(0): 1, Fr(1): 1, Fr(1, 6): 6, Fr(1, 3): 3, Fr(-2, 3): 3, Fr(-1, 2): 2}),
    'hypercharge is linear in the bit counts, Y = a/2 - b/3 (a = weak bits set, b = colour bits set), and reproduces the six hypercharges of the paper: 0, +1, +1/6, +1/3, -2/3, -1/2 with multiplicities 1,1,6,3,3,2')
Q = lambda x: (x & 1) - Fr(b_of(x), 3)                        # charge = (first weak bit) - (colour bits)/3
T3 = lambda x: Fr((x & 1) - ((x >> 1) & 1), 2)
ok = all(Q(x) == T3(x) + Yf(x) for x in LAB)
qsets = {BBB[k][0]: sorted({Q(x) for x in classes.get(k, [])}) for k in BBB}
ok &= qsets == {'e-bar_R': [Fr(1)], 'nu-bar_R': [Fr(0)], 'q_L': [Fr(-1, 3), Fr(2, 3)], 'd-bar_R': [Fr(1, 3)], 'u-bar_R': [Fr(-2, 3)], 'l_L': [Fr(-1), Fr(0)]}
ok &= all(Q(x ^ 31) == -Q(x) and Yf(x ^ 31) == -Yf(x) for x in LAB)
chk('H2c', ok, 'electric charge is Q = (first weak bit) - (colour bits)/3, and Q = T3 + Y with T3 = (first - second weak bit)/2: charges 1, 0, (2/3, -1/3), 1/3, -2/3, (0, -1) for the six pieces; the complement mask flips Q and Y on all 32 labels')
sY = sum(Yf(x) for x in EVEN); sQ = sum(Q(x) for x in EVEN); sY3 = sum(Yf(x) ** 3 for x in EVEN)
s2Y = sum(Yf(x) for x in EVEN if a_of(x) == 1); s3Y = sum(Yf(x) for x in EVEN if b_of(x) in (1, 2))
chk('H2d', sY == 0 and sQ == 0 and sY3 == 0 and s2Y == 0 and s3Y == 0,
    'anomaly sums computed from the labels: sum Y = 0 (gravitational), sum Q = 0, sum Y^3 = 0, sum of Y over weak doublets = 0 (SU(2)^2 U(1)), sum of Y over colour (anti)triplets = 0 (SU(3)^2 U(1)): the 16 even labels are anomaly free (standard fact, recomputed from the label rule)')

# ---- the Fock space of five modes realises the bit rule of Cl(5,5): E_i = a_i + a_i^+ (square +1), F_i = a_i - a_i^+ (square -1), all real 32 x 32
def a_op(i):
    M = np.zeros((32, 32))
    for x in range(32):
        if (x >> i) & 1: M[x ^ (1 << i), x] = (-1) ** pc(x & ((1 << i) - 1))
    return M
A5 = [a_op(i) for i in range(5)]
car = all(np.allclose(A5[i] @ A5[j].T + A5[j].T @ A5[i], np.eye(32) * (i == j)) and np.allclose(A5[i] @ A5[j] + A5[j] @ A5[i], 0) for i in range(5) for j in range(5))
Nop = sum(A.T @ A for A in A5)
chk('H3a', car and np.allclose(np.diag(Nop), [pc(x) for x in range(32)]) and np.allclose(Nop, np.diag(np.diag(Nop))),
    'five fermionic modes on the 32 labels (a_i flips bit i with the Jordan-Wigner sign): canonical anticommutation relations hold and the number operator is the popcount of the label (Fock space = label set, F7)')
GE = [A + A.T for A in A5] + [A - A.T for A in A5]            # generators 0..4 square +1, 5..9 square -1
A55 = Alg(sig(5, 5))
rho_cache = {}
def rho(a):
    if a not in rho_cache:
        M = np.eye(32)
        for i in range(10):
            if (a >> i) & 1: M = M @ GE[i]
        rho_cache[a] = M
    return rho_cache[a]
rng = random.Random(7)
ok = True
for _ in range(400):
    a, b = rng.randrange(1024), rng.randrange(1024)
    s, c = A55.blade_mul(a, b)
    if not np.allclose(rho(a) @ rho(b), s * rho(c)): ok = False
rank = np.linalg.matrix_rank(np.array([rho(a).ravel() for a in range(1024)]))
chk('H3b', ok and rank == 1024 and all(np.allclose(np.diag(GE[i] @ GE[i]), 1 if i < 5 else -1) for i in range(10)),
    'the 1024 blades of the bit-rule algebra Cl(5,5) map to real 32 x 32 matrices that multiply by the bit rule (400 random pairs) and are linearly independent (rank 1024 = 32^2): Cl(5,5) = M_32(R), the cell [10, 0] clock 0 of the atlas, and the 32-dimensional module is the Fock space of the 5 label bits')
BIV = [a for a in range(1024) if pc(a) == 2]
Bmat = np.array([rho(a).ravel() for a in BIV]).T               # 1024 x 45
def coords(M):
    c, res, rk, sv = np.linalg.lstsq(Bmat, M.ravel(), rcond=None)
    return c, np.linalg.norm(Bmat @ c - M.ravel())
closed = True
for _ in range(60):
    i, j = rng.sample(range(45), 2)
    X, Y_ = rho(BIV[i]), rho(BIV[j])
    if coords(X @ Y_ - Y_ @ X)[1] > 1e-9: closed = False
c_N, r_N = coords(Nop - 2.5 * np.eye(32))
adN = np.array([coords(Nop @ rho(BIV[k]) - rho(BIV[k]) @ Nop)[0] for k in range(45)]).T
ev = np.round(np.linalg.eigvals(adN).real).astype(int)
chk('H3c', closed and len(BIV) == 45 and r_N < 1e-9 and Counter(ev) == Counter({2: 10, -2: 10, 0: 25}),
    'the 45 bivectors close under the commutator (so(5,5), the real form of so(10) that the signature of Cl(5,5) gives; so(10) over C); the number operator minus 5/2 is itself a bivector; ad(N) splits so(10) into degrees +2, 0, -2 of dimensions 10, 25, 10: Lambda^2 C^5 + gl(5) + dual = the 3-grading of so(10) by pair creation')
# ---- the 3-graded structure is the Jordan pair of type D III (skew 5 x 5 matrices): x_A = (1/2) sum A_ij a_i^+ a_j^+ ;  triple product [x,y,z] = [[x, y^+], z] versus (1/2)(x y^+ z + z y^+ x)
def x_of(A): return 0.5 * sum(A[i, j] * (A5[i].T @ A5[j].T) for i in range(5) for j in range(5))
def rskew(r):
    M = np.array([[complex(r.gauss(0, 1), r.gauss(0, 1)) for _ in range(5)] for _ in range(5)]); return M - M.T
cs = []; resid = 0
for t in range(12):
    A, B, C = rskew(rng), rskew(rng), rskew(rng)
    xa, xb, xc = x_of(A), x_of(B), x_of(C)
    T_ = (xa @ xb.conj().T - xb.conj().T @ xa) @ xc - xc @ (xa @ xb.conj().T - xb.conj().T @ xa)
    Em = A @ B.conj().T @ C + C @ B.conj().T @ A
    skew = np.allclose(Em, -Em.T)
    X = x_of(Em) * 0.5
    cc = np.vdot(X, T_) / np.vdot(X, X); cs.append(cc); resid = max(resid, np.linalg.norm(T_ - cc * X)); resid = max(resid, 0 if skew else 1)
chk('H3d', resid < 1e-8 and max(abs(c - cs[0]) for c in cs) < 1e-8 and abs(cs[0]) > 0.5,
    'Tits-Kantor-Koecher in the Fock space: for kets x_A = (1/2) sum A_ij a_i^+ a_j^+ with A skew 5 x 5, the commutator triple [[x_A, x_B^+], x_C] equals the constant c = ' + f'{cs[0].real:.6g}' + ' times x of (1/2)(A B^+ C + C B^+ A), the triple product of the Jordan triple of skew matrices a_5(C) (type D III) of the paper (12 random complex triples, residual < 1e-8)')
# Peirce spectrum of the tripotent e = a_0^+ a_1^+  (the matrix A0 = E12 - E21 satisfies A0 A0^+ A0 = A0, so e is a tripotent of the matrix triple)
A0 = np.zeros((5, 5)); A0[0, 1], A0[1, 0] = 1, -1
e_ = x_of(A0)
Dop = lambda x: ((e_ @ e_.conj().T - e_.conj().T @ e_) @ x - x @ (e_ @ e_.conj().T - e_.conj().T @ e_)) / cs[0]
pairs = [(i, j) for i in range(5) for j in range(i + 1, 5)]
eig = {}
for (i, j) in pairs:
    xx = A5[i].T @ A5[j].T
    out = Dop(xx); lam = np.vdot(xx, out) / np.vdot(xx, xx)
    eig[(i, j)] = (round(lam.real * 2) / 2, np.linalg.norm(out - lam * xx) < 1e-9)
ok = all(v[1] for v in eig.values()) and all(v[0] == Fr(len({i, j} & {0, 1}), 2) for (i, j), v in eig.items())
chk('H3e', ok and Counter(v[0] for v in eig.values()) == Counter({1.0: 1, 0.5: 6, 0.0: 3}),
    'Peirce eigenvalues of the tripotent e = a_0^+ a_1^+ on the ten kets a_i^+ a_j^+: lambda = |{i,j} intersect {0,1}| / 2 ; multiplicities 1 (lambda = 1), 6 (1/2), 3 (0): the Peirce decomposition of the paper (W-prime = a_5(C): 10 = 1 + 6 + 3) read off the labels')
# su(3) x su(2) x u(1) inside so(10): the colour and weak bit groups; Casimirs per label
def Ecol(i, j): return A5[i].T @ A5[j]
def Ncol(): return sum(A5[i].T @ A5[i] for i in (2, 3, 4))
def Et(i, j): return Ecol(i, j) - (Ncol() / 3 if i == j else 0 * Ncol())                # traceless part on the colour block
col = (2, 3, 4)
C2_3 = 0.5 * sum(Et(i, j) @ Et(j, i) for i in col for j in col)
H1c = Et(2, 2) - Et(3, 3); H2c = Et(3, 3) - Et(4, 4); R1c = Et(2, 3); R2c = Et(3, 4)      # Cartan elements and the two simple raising operators of su(3) on the colour block
def dynkin(b):
    idx = [x for x in LAB if a_of(x) == 0 and b_of(x) == b]                     # colour sector with b bits set, no weak bit
    K = np.vstack([R1c[np.ix_(idx, idx)], R2c[np.ix_(idx, idx)]])
    u, sv, vt = np.linalg.svd(K); null = vt[(sv > 1e-9).sum():]
    if len(null) != 1: return None
    v = null[0]; return (round(float(v @ H1c[np.ix_(idx, idx)] @ v)), round(float(v @ H2c[np.ix_(idx, idx)] @ v)))
dyn = {b: dynkin(b) for b in range(4)}
Tp = A5[0].T @ A5[1]; Tm = A5[1].T @ A5[0]; T3op = 0.5 * (A5[0].T @ A5[0] - A5[1].T @ A5[1])
C2_2 = T3op @ T3op + 0.5 * (Tp @ Tm + Tm @ Tp)
Yop = 0.5 * (A5[0].T @ A5[0] + A5[1].T @ A5[1]) - Ncol() / 3
diag_ok = all(np.allclose(M, np.diag(np.diag(M))) for M in (C2_3, C2_2))
comm_ok = all(np.allclose(Yop @ g, g @ Yop) for g in [Et(i, j) for i in col for j in col] + [Tp, Tm, T3op])
tab = {}
for x in LAB: tab[(a_of(x), b_of(x))] = (round(C2_2[x, x], 6), round(C2_3[x, x], 6))
ok = diag_ok and comm_ok and tab[(0, 0)][:2] == (0, 0) and tab[(2, 0)][:2] == (0, 0) and tab[(1, 1)][:2] == (0.75, round(4 / 3, 6)) and tab[(0, 2)][:2] == (0, round(4 / 3, 6)) \
    and tab[(2, 2)][:2] == (0, round(4 / 3, 6)) and tab[(1, 3)][:2] == (0.75, 0) and dyn[0] == (0, 0) and dyn[3] == (0, 0) and dyn[1] in ((1, 0), (0, 1)) and dyn[2] in ((1, 0), (0, 1)) and dyn[1] != dyn[2]
chk('H3f', ok, 'su(2) on the weak bits and su(3) on the colour bits (generators a_i^+ a_j, traceless on the colour block) commute with the hypercharge operator N_w/2 - N_c/3; quadratic Casimirs su(2)/su(3): '
    'q_L (a=1,b=1) 3/4 and 4/3, d-bar_R and u-bar_R (b=2) 0 and 4/3, l_L (a=1,b=3) 3/4 and 0, singlets 0 and 0; the highest-weight Dynkin labels of the colour sector are ' + str(dyn[1]) + ' for b=1 (colour 3) and ' + str(dyn[2]) + ' for b=2 (colour 3-bar), (0,0) for b=0 and b=3: (3,2), (3-bar,1) twice, (1,2), (1,1) twice')
# =====================================================================================================================================================
# E. E8 > E7 > E6 > D5 > A4 > A2+A1 as Levi subsystems (delete simple roots alpha_8, alpha_7, ... : the series e_n of "Three Generations in E7", Table 2), the 3-gradings and the Peirce counts.
# =====================================================================================================================================================
S8 = np.array([[1, -1, -1, -1, -1, -1, -1, 1], [2, 2, 0, 0, 0, 0, 0, 0], [-2, 2, 0, 0, 0, 0, 0, 0], [0, -2, 2, 0, 0, 0, 0, 0], [0, 0, -2, 2, 0, 0, 0, 0], [0, 0, 0, -2, 2, 0, 0, 0],
               [0, 0, 0, 0, -2, 2, 0, 0], [0, 0, 0, 0, 0, -2, 2, 0]])        # Bourbaki simple roots of E8, coordinates doubled (inner product = dot / 4)
rts = []
for i in range(8):
    for j in range(i + 1, 8):
        for si in (2, -2):
            for sj in (2, -2):
                v = [0] * 8; v[i] = si; v[j] = sj; rts.append(tuple(v))
for sg in itertools.product((1, -1), repeat=8):
    if sum(1 for s_ in sg if s_ < 0) % 2 == 0: rts.append(sg)
R8 = np.array(rts); ip = lambda u, v: int(np.dot(u, v)) // 4
cartan = np.array([[ip(u, v) for v in S8] for u in S8])
coef = np.rint(R8 @ np.linalg.inv(S8.astype(float))).astype(int)               # coefficients of every root on the simple roots
ok = len(R8) == 240 and (np.abs(coef @ S8 - R8).max() == 0) and cartan.trace() == 16 and sorted(set(cartan[np.triu_indices(8, 1)])) == [-1, 0] and int((cartan[np.triu_indices(8, 1)] == -1).sum()) == 7
chk('E1a', ok and (coef.min() >= -6 and coef.max() <= 6) and (coef >= 0).all(axis=1).sum() == 120, 'E8: 240 roots (Bourbaki simple roots, Cartan matrix of the E8 diagram), 120 positive, every root an integer combination of the simple roots')
def levi(n): return [k for k in range(240) if all(coef[k, m] == 0 for m in range(n, 8))]       # roots in the span of alpha_1..alpha_n
sizes = [len(levi(n)) for n in (8, 7, 6, 5, 4, 3)]
dims = [n_ + s for n_, s in zip((8, 7, 6, 5, 4, 3), sizes)]
g1 = {n: [k for k in levi(n) if coef[k, n - 1] == 1] for n in (8, 7, 6, 5, 4)}   # grade +1 of the 3-grading of e_n given by the coefficient of alpha_n (for E8, grade +1 of a 5-grading)
chk('E1b', sizes == [240, 126, 72, 40, 20, 8] and dims == [248, 133, 78, 45, 24, 11] and [len(g1[n]) for n in (8, 7, 6, 5, 4)] == [56, 27, 16, 10, 6] and len(levi(8)) - len(levi(7)) == 2 * 56 + 2,
    'deleting alpha_8, alpha_7, ...: root counts ' + ', '.join(map(str, sizes)) + ' and algebra dimensions ' + ', '.join(map(str, dims)) + ' (Table 2 of the E7 paper: 133, 78, 45, 24, 11); the roots with coefficient 1 on the deleted node number 56, 27, 16, 10, 6: '
    'exactly the link sizes found from the E8 roots in F15 (the Gosset vertex-figure tower 4_21 > 2_21 > 1_21 > ...)')
chk('E1c',
    all(len(levi(n)) == len(levi(n - 1)) + 2 * len(g1[n]) for n in (7, 6, 5, 4)),
    '3-graded step: |roots(e_n)| = |roots(e_(n-1))| + 2 x (grade-1 size): 126 = 72 + 2x27, 72 = 40 + 2x16, 40 = 20 + 2x10, 20 = 8 + 2x6, i.e. e_n = g(-1) + (e_(n-1) + u(1)) + g(+1) with g(+-1) of dimension 27, 16, 10, 6 (the Albert, bi-Cayley, a_5 and M_(3,2) triples)')
# Peirce counts: for a root beta in grade 1, the root vectors e_gamma (gamma in grade 1) are eigenvectors of D(e_beta, e_beta) = ad[e_beta, e_-beta] with eigenvalue <gamma, beta>, Peirce eigenvalue <gamma,beta>/2
peirce = {}
for n in (7, 6, 5, 4):
    G = g1[n]; allc = []
    for be in G:
        allc.append(tuple(sorted(Counter(ip(R8[ga], R8[be]) for ga in G).items())))
    peirce[n] = set(allc)
want = {7: ((0, 10), (1, 16), (2, 1)), 6: ((0, 5), (1, 10), (2, 1)), 5: ((0, 3), (1, 6), (2, 1)), 4: ((0, 2), (1, 3), (2, 1))}
chk('E2a', all(peirce[n] == {want[n]} for n in want),
    'Peirce multiplicities (eigenvalue 0, 1/2, 1) of a minimal tripotent, read as inner products <gamma,beta> = 0, 1, 2 of grade-1 roots, the same for every choice of beta: Albert triple 27 = 10 + 16 + 1, bi-Cayley 16 = 5 + 10 + 1, a_5(C) 10 = 3 + 6 + 1, M_(3,2) 6 = 2 + 3 + 1; no root has inner product -1 (so the grading has no grade 2 inside g(+1) x g(+1))')
JT = {7: (3, 8, 0), 6: (2, 6, 4), 5: (2, 4, 2), 4: (2, 2, 1)}
JT_RAB = dict(JT)                    # rank r and characteristic multiplicities (a, b) of the four triples: dim = r + a r(r-1)/2 + b r
okj = True
for n, (r_, a_, b_) in JT.items():
    dimW = r_ + a_ * r_ * (r_ - 1) // 2 + b_ * r_
    p_half = a_ * (r_ - 1) + b_
    p_zero = (r_ - 1) + a_ * (r_ - 1) * (r_ - 2) // 2 + b_ * (r_ - 1)
    okj &= (dimW == len(g1[n]) and (0, p_zero) == want[n][0] and (1, p_half) == want[n][1])
chk('E2b', okj, 'the Jordan-theory formulas dim W = r + a r(r-1)/2 + b r, Peirce 1/2 dimension a(r-1) + b and Peirce 0 dimension of the rank r-1 subtriple, with (r,a,b) = (3,8,0), (2,6,4), (2,4,2), (2,2,1) for the Albert, bi-Cayley, a_5 and M_(3,2) triples, agree with the root counts')
def graph_from(G, color=None):                                            # complete graph on G with edge attribute = inner product
    g = nx.Graph()
    for i, u in enumerate(G):
        g.add_node(i)
        for j in range(i):
            g.add_edge(i, j, w=ip(R8[u], R8[G[j]]))
    return g
def model_graph(items, f):
    g = nx.Graph()
    for i, u in enumerate(items):
        g.add_node(i)
        for j in range(i): g.add_edge(i, j, w=f(u, items[j]))
    return g
em = lambda a, b: a['w'] == b['w']
# models: 16 = even labels of 5 bits with <.,.> = 2 - d/2 ; 10 = 2-subsets of 5 with |intersection| ; 6 = {1,2} x {1,2,3} with delta + delta
m16 = model_graph(EVEN, lambda x, y: 2 - Fr(pc(x ^ y), 2))
m10 = model_graph([c for c in itertools.combinations(range(5), 2)], lambda x, y: len(set(x) & set(y)))
m6 = model_graph([(i, j) for i in range(2) for j in range(3)], lambda x, y: (x[0] == y[0]) + (x[1] == y[1]))
g16, g10, g6 = graph_from(g1[6], None), graph_from(g1[5], None), graph_from(g1[4], None)
m16i = nx.Graph(); m16i.add_nodes_from(range(16))
for u, v, d in m16.edges(data=True): m16i.add_edge(u, v, w=int(d['w']) if d['w'].denominator == 1 else d['w'])
chk('E2c', nx.is_isomorphic(g16, m16i, edge_match=em) and nx.is_isomorphic(g10, m10, edge_match=em) and nx.is_isomorphic(g6, m6, edge_match=em),
    'the grade-1 roots of e6, so(10), sl5, with edges coloured by their inner product, are isomorphic to the label models: 16 = even 5-bit labels with <x,y> = 2 - (Hamming distance)/2 (so Peirce eigenvalue = 1 - d/4, the rule of H2a), '
    '10 = 2-subsets of 5 bits with <x,y> = |x intersect y| (eigenvalue |x intersect S|/2, the rule of H3e), 6 = {u,d} x {r,g,b} with <x,y> = number of equal coordinates')
# the 27: Schlafli graph (non-orthogonal roots adjacent at inner product 0 are 10-regular, strongly regular with parameters (27,10,1,5))
G27 = g1[7]; adj0 = nx.Graph(); adj0.add_nodes_from(range(27))
for i in range(27):
    for j in range(i):
        if ip(R8[G27[i]], R8[G27[j]]) == 0: adj0.add_edge(i, j)
deg = {d for _, d in adj0.degree()}
lam = {len(set(adj0[u]) & set(adj0[v])) for u, v in adj0.edges()}; mu = {len(set(adj0[u]) & set(adj0[v])) for u in range(27) for v in range(u) if not adj0.has_edge(u, v)}
chk('E2d', deg == {10} and lam == {1} and mu == {5}, 'the 27 grade-1 roots of e7, joined when their inner product is 0, form a strongly regular graph with parameters (27, 10, 1, 5): the intersection graph of the 27 lines on a cubic surface; its complement (inner product 1, 16-regular, the edge graph of the Gosset polytope 2_21) is the Schlafli graph srg(27, 16, 10, 8)')
# ---- the E7 paper: the generation sl3, the plane P, the trichotomy and the three D6's
E7 = levi(7); Rr = R8[E7]
cent = [k for k in E7 if all(ip(R8[k], S8[i]) == 0 for i in range(4))]            # roots orthogonal to alpha_1..alpha_4: g_SM has Cartan h' = span(alpha_1,alpha_2,alpha_3, h_4)
Acent = R8[cent]
Pb = np.array([S8[5], S8[6]], dtype=float)                                         # the generation plane P = span(alpha_6, alpha_7)
Pproj = lambda v: (np.array(v, dtype=float) @ Pb.T) @ np.linalg.inv(Pb @ Pb.T) @ Pb       # orthogonal projection of a (doubled) vector onto P
nz = lambda v: float(np.dot(v, v)) / 4
proj = [Pproj(R8[k]) for k in E7]
kinds = Counter()
cls = {}
for k, p in zip(E7, proj):
    nrm = nz(p)
    key = 'zero' if nrm < 1e-9 else ('w' if abs(nrm - 2 / 3) < 1e-9 else ('A' if abs(nrm - 2) < 1e-9 else 'other'))
    kinds[key] += 1; cls[k] = (key, tuple(np.round(p, 6)))
atA = {k for k in E7 if cls[k][0] == 'A'}
wvals = sorted({cls[k][1] for k in E7 if cls[k][0] == 'w'})
chk('E3a', len(cent) == 6 and set(cent) == atA and kinds == Counter({'zero': 30, 'w': 90, 'A': 6}) and len(wvals) == 6,
    'E7 paper, Prop. 1 and Lemma 2-3: the roots of e7 orthogonal to g_SM (to alpha_1..alpha_4) are 6 and form the A2 of the generation sl3; projecting the 126 roots to its plane P gives only 0 (30 roots), six vectors of squared length 2/3 (the weights +-w_k; 90 roots) '
    'and the six roots of A (6 roots, exactly A itself): 126 = 6 + 30 + 30 + 30 + 30')
def profile(idx): return Counter(ip(R8[idx[0]], R8[j]) for j in idx)
def irreducible(idx):
    g = nx.Graph(); g.add_nodes_from(idx)
    for i in idx:
        for j in idx:
            if i < j and ip(R8[i], R8[j]) != 0: g.add_edge(i, j)
    return nx.is_connected(g)
def model_prof(roots_model):
    return Counter(int(np.dot(roots_model[0], r)) for r in roots_model)
A5m = [tuple(1 if t == i else (-1 if t == j else 0) for t in range(6)) for i in range(6) for j in range(6) if i != j]
D6m = [tuple(si * (t == i) + sj * (t == j) for t in range(6)) for i in range(6) for j in range(i + 1, 6) for si in (1, -1) for sj in (1, -1)]
Phi0 = [k for k in E7 if cls[k][0] == 'zero']
# group the 90 roots by the line {+w_k, -w_k}: canonical representative = lexicographically larger of the two opposite vectors
lines = {}
for k in E7:
    if cls[k][0] == 'w':
        p = cls[k][1]; q = tuple(-x if x != 0 else 0.0 for x in p); lines.setdefault(max(p, tuple(np.round(q, 6))), []).append(k)
ok = len(Phi0) == 30 and profile(Phi0) == model_prof(A5m) and irreducible(Phi0) and np.linalg.matrix_rank(R8[Phi0].astype(float)) == 5 and len(lines) == 3 and all(len(v) == 30 for v in lines.values())
chk('E3b', ok, f'Lemma 3: Phi_0 has 30 roots, rank 5, irreducible, and the same inner-product profile ({dict(profile(Phi0))}) as the root system A5; the three classes Phi_1, Phi_2, Phi_3 (projection on the line of w_k) have 30 roots each')
okd = True
for key, Phi_k in lines.items():
    # beta_k is the root of A orthogonal (in P) to w_k
    wk = np.array(key)
    bk = [k for k in atA if abs(np.dot(R8[k], np.array(wk) * 4)) < 1e-9]
    ok_k = len(bk) == 2
    D = [r for r in E7 if ip(R8[r], R8[bk[0]]) == 0]
    ok_k &= set(D) == set(Phi0) | set(Phi_k) and len(D) == 60 and profile(D) == model_prof(D6m) and irreducible(D) and np.linalg.matrix_rank(R8[D].astype(float)) == 6
    okd &= ok_k
chk('E3c', okd, 'Lemma 4: for each k the 60 roots of e7 orthogonal to beta_k are exactly Phi_0 + Phi_k, of rank 6, irreducible, with the inner-product profile of D6 (60 roots): so12(beta_k) commuting with sl2(beta_k)')
# Prop. 5: 133 = 3 + 66 + 64, the 64 roots at inner product +-1 with beta_k; the 32 at +1, projected to the orthogonal complement, are the weights of a half-spin representation of D6
oks = True; prof32 = None
for key, Phi_k in lines.items():
    bk = [k for k in atA if abs(np.dot(R8[k], np.array(key) * 4)) < 1e-9][0]
    plus = [r for r in E7 if ip(R8[r], R8[bk]) == 1]; minus = [r for r in E7 if ip(R8[r], R8[bk]) == -1]
    oks &= len(plus) == 32 and len(minus) == 32 and 3 + 66 + 64 == 133
    vecs = [R8[r] - (ip(R8[r], R8[bk]) / 2) * R8[bk] for r in plus]               # projection orthogonal to beta_k (still doubled)
    gram = {(i, j): Fr(int(np.dot(vecs[i], vecs[j])), 4) for i in range(32) for j in range(32)}
    G_ = nx.Graph(); G_.add_nodes_from(range(32))
    for i in range(32):
        for j in range(i): G_.add_edge(i, j, w=gram[(i, j)])
    spin = [tuple(Fr(1 - 2 * ((x >> t) & 1), 2) for t in range(6)) for x in range(64) if pc(x) % 2 == 0]
    M_ = nx.Graph(); M_.add_nodes_from(range(32))
    for i in range(32):
        for j in range(i): M_.add_edge(i, j, w=sum(a * b for a, b in zip(spin[i], spin[j])))
    oks &= all(gram[(i, i)] == Fr(3, 2) for i in range(32)) and nx.is_isomorphic(G_, M_, edge_match=em)
chk('E3d', oks, 'Prop. 5: for each k the roots with <r, beta_k> = +1 and -1 number 32 each (133 = 3 + 66 + 2 x 32 = sl2 + so12 + 2 (x) 32), and the 32 at +1, projected orthogonally to beta_k, have the weight system of the half-spin representation of D6 '
    '(vectors (+-1/2)^6 with an even number of minus signs, squared length 3/2): same inner-product graph, 32 = 1 + 15 + 15 + 1 by Hamming distance 0, 2, 4, 6')
# Lemma 9 / Thm 12: V_k = e_(+-beta_k) + root spaces of Phi_k  = Lambda^even C^6 as an sl6 weight system; and 32 = all subsets of five bits
okv = True
Phi0_vecs = R8[Phi0]
for key, Phi_k in lines.items():
    bk = [k for k in atA if abs(np.dot(R8[k], np.array(key) * 4)) < 1e-9]
    Vk = list(Phi_k) + bk
    # projection onto the span of Phi_0 (the sl6 Cartan): least squares onto the rows of Phi0
    B = Phi0_vecs.astype(float)
    Pm = B.T @ np.linalg.pinv(B @ B.T) @ B                                          # orthogonal projector onto span(Phi_0)
    pv = [Pm @ R8[k].astype(float) for k in Vk]
    gram = [[round(float(np.dot(u, v)) / 4, 6) for v in pv] for u in pv]
    Gk = nx.Graph(); Gk.add_nodes_from(range(32))
    for i in range(32):
        for j in range(i): Gk.add_edge(i, j, w=gram[i][j])
    subs = [x for x in range(64) if pc(x) % 2 == 0]
    wS = lambda S, T: round(pc(S & T) - pc(S) * pc(T) / 6, 6)
    Mk = nx.Graph(); Mk.add_nodes_from(range(32))
    for i in range(32):
        for j in range(i): Mk.add_edge(i, j, w=wS(subs[i], subs[j]))
    okv &= nx.is_isomorphic(Gk, Mk, edge_match=lambda a, b: abs(a['w'] - b['w']) < 1e-5) and sorted(round(gram[i][i], 6) for i in range(32)) == sorted(round(pc(S) - pc(S) ** 2 / 6, 6) for S in subs)
chk('E3e', okv, 'Thm. 12: V_k = (the two root spaces of +-beta_k) + (the 30 of Phi_k), projected to the Cartan of sl6, has the weight system of Lambda^even C^6 = Lambda^0 + Lambda^2 + Lambda^4 + Lambda^6 (weights e_S - |S|/6, <e_S,e_T> = |S intersect T| - |S||T|/6, 32 even-size subsets of six bits) '
    'for each of the three k; dropping the sixth bit identifies the 32 even subsets of six bits with the 32 labels of five bits, S <-> S minus {6} (the parity bit is determined): V_k = the five-bit label space, three times: 3 x 32 = 96, 133 = 35 + 2 + 96')
# =====================================================================================================================================================
# O. Octonions on three-bit labels (Cayley-Dickson: the XOR rule with another sign), split octonions on the same eight labels (Zorn: join and meet), and the Albert algebra h3(O):
#    Peirce split 27 = 3 + 8 + 8 + 8, derivations f4 (52), and the Standard Model subalgebras of Baez-Schwahn at the level of Lie algebras.
# =====================================================================================================================================================
def cd_conj(z):
    if len(z) == 1: return list(z)
    h = len(z) // 2
    return cd_conj(z[:h]) + [-t for t in z[h:]]
def cd_mul(x, y):
    n = len(x)
    if n == 1: return [x[0] * y[0]]
    h = n // 2; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    p1 = cd_mul(a, c); p2 = cd_mul(cd_conj(d), b); p3 = cd_mul(d, a); p4 = cd_mul(b, cd_conj(c))
    return [u - v for u, v in zip(p1, p2)] + [u + v for u, v in zip(p3, p4)]
unit = lambda n, i: [1 if t == i else 0 for t in range(n)]
OCT = {}                                                         # (a, b) -> (sign, label)
for a in range(8):
    for b in range(8):
        r = cd_mul(unit(8, a), unit(8, b)); nzr = [t for t in range(8) if r[t] != 0]
        OCT[(a, b)] = (r[nzr[0]], nzr[0]) if len(nzr) == 1 else None
ok = all(OCT[(a, b)] is not None and OCT[(a, b)][1] == a ^ b and abs(OCT[(a, b)][0]) == 1 for a in range(8) for b in range(8))
sq = [OCT[(a, a)][0] for a in range(8)]
chk('O1a', ok and sq == [1] + [-1] * 7, 'Cayley-Dickson doubling of the reals three times: every product of two basis units of the octonions is +-1 times the unit whose label is the XOR of the two labels (64 products), and every non-zero label squares to -1: the octonions are the bit rule on 3 bits with another sign function')
rng = random.Random(11)
rv = lambda: [rng.randint(-3, 3) for _ in range(8)]
alt = all(cd_mul(cd_mul(x, x), y) == cd_mul(x, cd_mul(x, y)) and cd_mul(cd_mul(y, x), x) == cd_mul(y, cd_mul(x, x)) for x, y in ((rv(), rv()) for _ in range(40)))
nrm = lambda x: sum(t * t for t in x)
normed = all(nrm(cd_mul(x, y)) == nrm(x) * nrm(y) for x, y in ((rv(), rv()) for _ in range(40)))
def assoc_sign(a, b, c):
    s1 = OCT[(a, b)][0] * OCT[(a ^ b, c)][0]; s2 = OCT[(b, c)][0] * OCT[(a, b ^ c)][0]
    return s1 * s2
def f2_independent(a, b, c):
    return a != 0 and b != 0 and c != 0 and a != b and a != c and b != c and (a ^ b) != c
negs = [(a, b, c) for a in range(8) for b in range(8) for c in range(8) if assoc_sign(a, b, c) == -1]
A03 = Alg(sig(0, 3))
cl_assoc = all(A03.blade_mul(A03.blade_mul(a, b)[1], c)[0] * A03.blade_mul(a, b)[0] == A03.blade_mul(a, A03.blade_mul(b, c)[1])[0] * A03.blade_mul(b, c)[0] for a in range(8) for b in range(8) for c in range(8))
sqdiff = [a for a in range(8) if A03.sq(a) != OCT[(a, a)][0]]
pdiff = sum(1 for a in range(1, 8) for b in range(1, 8) if a != b and A03.blade_mul(a, b)[0] != OCT[(a, b)][0])    # products of distinct non-zero labels on which Cl(0,3) and the octonions disagree
chk('O1b', alt and normed and len(negs) == 168 and all(f2_independent(*t) for t in negs) and cl_assoc and sqdiff == [7],
    'octonions: alternative and normed on random vectors; the associator sign (+1 or -1 between the two bracketings of e_a e_b e_c) is -1 for exactly the 168 = 7 x 6 x 4 ordered triples of labels that are linearly independent over F2 (not on a line of the Fano plane), '
    f'+1 otherwise; the Clifford sign rule on the same 3 bits (Cl(0,3)) is associative; its squares differ from the octonion squares only at label 111 (the pseudoscalar), but it also differs on {pdiff} of the 42 products of distinct non-zero labels (necessarily: one rule is associative, the other not): octonion = bit rule with a non-associative sign, associator = (-1)^determinant over F2')
# the subalgebra C = {e0, e1} and its centralizer of automorphisms: derivations of O (g2, 14) and those killing e1 (su(3), 8) acting complex-linearly on the 6-dim complement
def der_system(mult, n):
    T = np.zeros((n, n, n))
    for a in range(n):
        for b in range(n):
            r = mult(unit(n, a), unit(n, b))
            T[a, b, :] = r
    rows = []
    for i in range(n):
        for j in range(n):
            for l in range(n):
                row = np.zeros((n, n))                          # unknown D[p, q]: (D x)_p = sum_q D[p,q] x_q
                row[l, :] += T[i, j, :]                         # D(b_i b_j)_l = sum_m T[i,j,m] D[l,m]
                row[:, i] -= T[:, j, l]                         # (D b_i) b_j : sum_k D[k,i] T[k,j,l]
                row[:, j] -= T[i, :, l]                         # b_i (D b_j) : sum_k D[k,j] T[i,k,l]
                rows.append(row.ravel())
    return T, np.array(rows)
def nullspace(M, tol=1e-9):
    u, s, vt = np.linalg.svd(M, full_matrices=True)
    r = int((s > tol * max(1, s[0])).sum()); return vt[r:].T
TO, MO = der_system(cd_mul, 8)
NO = nullspace(MO)
Dlist = [NO[:, t].reshape(8, 8) for t in range(NO.shape[1])]
# derivations killing e1
Cn = np.array([[D[:, 1] for D in Dlist][t] for t in range(len(Dlist))]).T       # (8, g) : D e1 as a function of the coefficient vector
kn = nullspace(Cn)
Dsu3 = [sum(kn[t, s] * Dlist[t] for t in range(len(Dlist))) for s in range(kn.shape[1])]
Lj = np.array([[TO[1, b, c] for b in range(8)] for c in range(8)])              # left multiplication by e1 on coordinates (row c, column b)
comp = [2, 3, 4, 5, 6, 7]
ok = all(np.allclose(D @ Lj, Lj @ D) for D in Dsu3) and np.allclose(Lj @ Lj, -np.eye(8)) 
chk('O1c', len(Dlist) == 14 and len(Dsu3) == 8 and ok, 'derivations of the octonions: dimension 14 (g2); those that kill the unit e1 (a chosen square root of -1) form an 8-dimensional algebra, and all of them commute with left multiplication by e1, i.e. act complex-linearly on the 6-dimensional complement C^3: su(3) of the paper (O = C + C^3 with SU(3) acting)')
# ---- split octonions: Zorn's product on the exterior algebra of R^3 (join and meet)
def zorn(x, y):
    al, a, ap, alp = x[0], np.array(x[1:4]), np.array(x[4:7]), x[7]
    be, b, bp, bep = y[0], np.array(y[1:4]), np.array(y[4:7]), y[7]
    return np.array([al * be + a @ bp, *(al * b + bep * a - np.cross(ap, bp)), *(be * ap + alp * bp + np.cross(a, b)), ap @ b + alp * bep])
ZL = [0, 1, 2, 4, 6, 5, 3, 7]        # index -> label:  alpha=000, a_i = {i} (bits 001, 010, 100), a'_i = complement of {i} (110, 101, 011), alpha' = 111
zr = np.random.RandomState(5)
def nz_(x): return x[0] * x[7] - x[1:4] @ x[4:7]
comp_ok = all(abs(nz_(zorn(x, y)) - nz_(x) * nz_(y)) < 1e-9 for x, y in ((zr.randn(8), zr.randn(8)) for _ in range(40)))
alt_z = all(np.allclose(zorn(zorn(x, x), y), zorn(x, zorn(x, y))) and np.allclose(zorn(zorn(y, x), x), zorn(y, zorn(x, x))) for x, y in ((zr.randn(8), zr.randn(8)) for _ in range(40)))
ez = np.array([1, 0, 0, 0, 0, 0, 0, 1.0]); id_ok = all(np.allclose(zorn(ez, x), x) and np.allclose(zorn(x, ez), x) for x in (zr.randn(8) for _ in range(10)))
Qm = np.zeros((8, 8)); Qm[0, 7] = Qm[7, 0] = 0.5
for i in range(3): Qm[1 + i, 4 + i] = Qm[4 + i, 1 + i] = -0.5
evq = np.linalg.eigvalsh(Qm)
mono = {}; kinds_z = Counter(); zero_div = False
for i in range(8):
    for j in range(8):
        r = zorn(unit(8, i), unit(8, j)); nzr = [t for t in range(8) if abs(r[t]) > 1e-12]
        mono[(i, j)] = nzr
        if len(nzr) == 1 and abs(abs(r[nzr[0]]) - 1) < 1e-12:
            x, y, z = ZL[i], ZL[j], ZL[nzr[0]]
            if x & y == 0 and z == x | y: kinds_z['join'] += 1
            elif x | y == 7 and z == x & y: kinds_z['meet'] += 1
            else: kinds_z['other'] += 1
        elif len(nzr) == 0: kinds_z['zero'] += 1
        else: kinds_z['bad'] += 1
        if len(nzr) == 0 and i == j and 0 < i < 7: zero_div = True
chk('O2a', comp_ok and alt_z and id_ok and (evq > 0).sum() == 4 and (evq < 0).sum() == 4,
    'Zorn product on R^8 = Lambda R^3 (alpha, a, a-prime, alpha-prime): composition n(xy) = n(x) n(y) with n = alpha alpha-prime - a.a-prime (40 random pairs), alternative, unit 1 + pi (alpha = alpha-prime = 1), and the norm has signature (4,4): the split octonions')
chk('O2b', kinds_z['bad'] == 0 and kinds_z['other'] == 0 and kinds_z['join'] + kinds_z['meet'] + kinds_z['zero'] == 64 and zero_div,
    f'on the eight labels of Lambda R^3 (alpha = 000, a_i = {{i}}, a-prime_i = complement of {{i}}, alpha-prime = 111) every Zorn product of two labels is 0 or +-1 times one label: ' + ', '.join(f'{k} {v}' for k, v in sorted(kinds_z.items())) +
    ' of 64; every non-zero product is the join (x union y, when x and y are disjoint) or the meet (x intersect y, when x union y is everything), and the nilpotent units a_i square to 0 (zero divisors): wedge and regressive product, the PGA pair, on the same labels as the XOR rule')
pi_ = unit(8, 7)
Lp = np.array([zorn(pi_, unit(8, j)) for j in range(8)]).T; Rp = np.array([zorn(unit(8, j), pi_) for j in range(8)]).T
ok = np.allclose(Lp, np.diag(np.diag(Lp))) and np.allclose(Rp, np.diag(np.diag(Rp)))
gr = [int(round(2 * Lp[i, i] + Rp[i, i])) for i in range(8)]
chk('O2c', ok and np.allclose(zorn(pi_, pi_), pi_) and [gr[i] for i in range(8)] == [pc(ZL[i]) for i in range(8)],
    'pi = label 111 is an idempotent of the Zorn algebra and left and right multiplication by pi are diagonal in the label basis with eigenvalues (0,0), (0,1), (1,0), (1,1) on the grades 0, 1, 2, 3: the popcount of a label = 2 x (left Peirce eigenvalue) + (right Peirce eigenvalue) (Baez-Pumplun, proof of Thm. 6)')
def tau_sign(x): return -1 if (pc(x) * (pc(x) + 1) // 2) % 2 else 1          # (-1)^(k(k+1)/2) = reversion sign x grade-involution sign = Clifford conjugation sign
tauz = np.zeros((8, 8)); tau0 = np.zeros((8, 8))
for i in range(8):
    tauz[ZL.index(ZL[i] ^ 7), i] = tau_sign(ZL[i]); tau0[ZL.index(ZL[i] ^ 7), i] = 1
def dev(T_, anti):
    return max(np.linalg.norm(T_ @ zorn(x, y) - (zorn(T_ @ y, T_ @ x) if anti else zorn(T_ @ x, T_ @ y))) for x, y in ((zr.randn(8), zr.randn(8)) for _ in range(20)))
chk('O2d', dev(tauz, False) < 1e-9 and dev(tau0, False) > 1e-3 and dev(tau0, True) > 1e-3,
    'the Hodge complement of a label (x -> x XOR 111, join <-> meet, the particle-hole map of F7), composed with the Clifford-conjugation sign (-1)^(k(k+1)/2) on grade k, is an automorphism of the Zorn algebra (alpha <-> alpha-prime, a_i <-> -a-prime_i); the bare complement is neither an automorphism nor an anti-automorphism')
# ---- the Albert algebra h3(O) on the XOR octonions
def mat_of(v):                                                   # 27 coordinates -> 3 x 3 matrix of octonions (8-vectors)
    M = np.zeros((3, 3, 8))
    for i in range(3): M[i, i, 0] = v[i]
    x12, x23, x31 = np.array(v[3:11]), np.array(v[11:19]), np.array(v[19:27])
    M[0, 1], M[1, 0] = x12, cd_conj(list(x12))
    M[1, 2], M[2, 1] = x23, cd_conj(list(x23))
    M[2, 0], M[0, 2] = x31, cd_conj(list(x31))
    return M
def coords_of(M):
    return np.array([M[0, 0, 0], M[1, 1, 0], M[2, 2, 0], *M[0, 1], *M[1, 2], *M[2, 0]])
OT = np.zeros((8, 8, 8))
for (a, b), (s_, c) in OCT.items(): OT[a, b, c] = s_
def omul(x, y): return np.einsum('a,b,abc->c', x, y, OT)
def mmul(X, Y):
    Z = np.zeros((3, 3, 8))
    for i in range(3):
        for j in range(3):
            for k in range(3): Z[i, j] += omul(X[i, k], Y[k, j])
    return Z
def jprod(u, v):
    X, Y = mat_of(u), mat_of(v); return coords_of(0.5 * (mmul(X, Y) + mmul(Y, X)))
JT = np.zeros((27, 27, 27))
for i in range(27):
    for j in range(i + 1):
        JT[i, j] = JT[j, i] = jprod(unit(27, i), unit(27, j))
jr = np.random.RandomState(9)
jord = True
for _ in range(20):
    x, y = jr.randn(27), jr.randn(27)
    x2 = np.einsum('a,b,abc->c', x, x, JT)
    lhs = np.einsum('a,b,abc->c', np.einsum('a,b,abc->c', x2, y, JT), x, JT); rhs = np.einsum('a,b,abc->c', x2, np.einsum('a,b,abc->c', y, x, JT), JT)
    jord &= np.allclose(lhs, rhs)
ident = np.array([1, 1, 1] + [0] * 24, dtype=float)
chk('O3a', jord and all(np.allclose(np.einsum('a,b,abc->c', ident, x, JT), x) for x in jr.randn(5, 27)) and np.allclose(JT, JT.transpose(1, 0, 2)),
    'the 27-dimensional space of hermitian 3 x 3 matrices over the XOR octonions (3 diagonal + 3 x 8 off-diagonal) with the product (xy + yx)/2: commutative, unit 1, Jordan identity (x^2 y) x = x^2 (y x) (20 random pairs): the exceptional Jordan algebra h3(O)')
Le1 = JT[0].T                                                    # L_{e1} as a matrix: (L x)_c = sum_b x_b JT[0,b,c]
evs = np.round(np.linalg.eigvals(Le1).real * 2) / 2
pe = Counter(evs.tolist())
Le2 = JT[1].T
ij = lambda idx: [3 + t for t in range(8)] if idx == 12 else ([11 + t for t in range(8)] if idx == 23 else [19 + t for t in range(8)])
inter_ok = True
for (i1, i2, idxs) in ((0, 1, ij(12)), (1, 2, ij(23)), (2, 0, ij(31))):
    for v in idxs:
        x = np.array(unit(27, v), dtype=float); inter_ok &= np.allclose(JT[i1].T @ x, 0.5 * x) and np.allclose(JT[i2].T @ x, 0.5 * x)
chk('O3b', pe == Counter({1.0: 1, 0.5: 16, 0.0: 10}) and inter_ok and 3 + 3 * 8 == 27,
    'Peirce decomposition of h3(O) for the idempotent e1: eigenvalues 1 (dimension 1), 1/2 (16 = the two 8-dimensional off-diagonal blocks that touch index 1), 0 (10 = span(e2,e3) + 8): the Jordan-frame split 27 = 3 + 8 + 8 + 8 of Baez-Schwahn (eqs. (3), (4))')
rowsD = []
for i in range(27):
    for j in range(i, 27):
        for l in range(27):
            row = np.zeros((27, 27))
            row[l, :] += JT[i, j, :]; row[:, i] -= JT[:, j, l]; row[:, j] -= JT[i, :, l]
            rowsD.append(row.ravel())
MA = np.array(rowsD)
NA = nullspace(MA)
DA = [NA[:, t].reshape(27, 27) for t in range(NA.shape[1])]
chk('O3c', len(DA) == 52, 'derivations of h3(O): the linear system D(x o y) = Dx o y + x o Dy has a 52-dimensional solution space: f4 (the automorphism group F4)')
def stab(subspace_sets, base=None):
    """dimension and basis of {D in Der : D(U) subset U for every coordinate subspace U in the list}, and {D: D u = 0 for u in the 'kill' list}"""
    rows = []
    for U in subspace_sets:
        Uc = [q for q in range(27) if q not in U]
        for q in U:
            for p in Uc:
                rows.append([DA[t][p, q] for t in range(len(DA))])
    M = np.array(rows) if rows else np.zeros((1, len(DA)))
    k = nullspace(M); return [sum(k[t, s] * DA[t] for t in range(len(DA))) for s in range(k.shape[1])]
FRAME = [{0}, {1}, {2}]
st_frame = [D for D in stab(FRAME)]
Bset = {0, 1, 2, 3, 4, 11, 12, 19, 20}
Xset = {0, 1, 3, 4}
Aset = {0, 1} | set(range(3, 11))
Bsub = all(np.allclose(JT[i, j][[q for q in range(27) if q not in Bset]], 0) for i in Bset for j in Bset)
Xsub = all(np.allclose(JT[i, j][[q for q in range(27) if q not in Xset]], 0) for i in Xset for j in Xset)
Asub = all(np.allclose(JT[i, j][[q for q in range(27) if q not in Aset]], 0) for i in Aset for j in Aset)
EL = (JT[0] + JT[1]).T                                         # L_{e1+e2}
ev1 = np.linalg.eig(EL)
E1_dim = int(sum(1 for v in ev1[0] if abs(v - 1) < 1e-9))
chk('O3d', Bsub and Xsub and Asub and len(Bset) == 9 and len(Xset) == 4 and len(Aset) == 10 and E1_dim == 10,
    'the Jordan subalgebras of Baez-Schwahn are closed under the product: B = h3(C) (3 diagonal + three complex entries, dimension 9, entries in the subalgebra C = {e0, e1}), X = h2(C) (dimension 4), A = h2(O) (dimension 10, = the Peirce 1-space of l = e1 + e2, '
    'dimension 10: Lemma 7 and Lemma 10: the unique h2(O) containing X)')
# stabilisers at the Lie algebra level
dimF = len(stab([]))
d_frame = len(st_frame); d_B = len(stab([Bset])); d_A = len(stab([Aset])); d_X = len(stab([Xset]))
sBX = stab([Bset, Xset]); sAB = stab([Aset, Bset])
chk('O3e', dimF == 52 and d_frame == 28 and d_B == 16 and d_A == 36 and d_X == 18 and len(sBX) == 12 and len(sAB) == 12,
    f'Lie algebras of the stabilisers inside f4 (dimension 52): of the Jordan frame {d_frame} (so(8)), of B = h3(C) {d_B} (su(3) + su(3)), of A = h2(O) {d_A} (spin(9)), of X = h2(C) {d_X} (so(3) + so(6) inside spin(9): the stabiliser of a 3-plane in R^9 = the traceless part of A), and of X together with B: {len(sBX)}; of A together with B: {len(sAB)} (the same Lie algebra, as X determines A and A and B determine X): '
    'dimension 12 = 8 + 3 + 1 of the Standard Model gauge group (Theorems 1 and 2 of Baez-Schwahn, at the level of Lie algebras)')
def structure(basis):
    n = len(basis)
    Bm = np.array([b.ravel() for b in basis]).T
    def co(M):
        c = np.linalg.lstsq(Bm, M.ravel(), rcond=None)[0]; return c, np.linalg.norm(Bm @ c - M.ravel())
    ad = []; clos = True
    for x in basis:
        cols = []
        for y in basis:
            c, r = co(x @ y - y @ x); clos &= r < 1e-8; cols.append(c)
        ad.append(np.array(cols).T)
    return ad, clos
def invariants(basis, rng_):
    ad, clos = structure(basis); n = len(basis)
    kill = np.array([[np.trace(ad[a] @ ad[b]) for b in range(n)] for a in range(n)])
    centre_dim = n - np.linalg.matrix_rank(np.vstack(ad), tol=1e-8)
    # rank = dimension of the centraliser of a generic element
    cg = sum(rng_.randn() * ad[a] for a in range(n))
    cent = nullspace(cg, 1e-8).shape[1]
    return ad, clos, kill, centre_dim, cent
def commutant_eigs(ad, n):
    """dimension of End_g(g) and eigenvalue multiplicities of a generic element of it (equal to the dimensions of the simple ideals, centre excluded)"""
    unk = n * n; rows = []
    for a in range(n):
        A_ = ad[a]
        M = np.kron(np.eye(n), A_) - np.kron(A_.T, np.eye(n))
        rows.append(M)
    Mat = np.vstack(rows); N = nullspace(Mat, 1e-8)
    return N
sr = np.random.RandomState(3)
res = {}
for name, basis in (('SM', sBX), ('B', stab([Bset])), ('A', stab([Aset])), ('F4', DA)):
    ad, clos, kill, cdim, cent = invariants(basis, sr)
    n = len(basis)
    # derived algebra
    br = []
    for a in range(n):
        for b in range(a + 1, n): br.append(np.linalg.lstsq(np.array([x.ravel() for x in basis]).T, (basis[a] @ basis[b] - basis[b] @ basis[a]).ravel(), rcond=None)[0])
    dd = np.linalg.matrix_rank(np.array(br), tol=1e-8) if br else 0
    res[name] = dict(n=n, clos=clos, centre=cdim, derived=dd, rank=cent, kmax=np.linalg.eigvalsh(0.5 * (kill + kill.T)).max())
ok = res['SM']['n'] == 12 and res['SM']['clos'] and res['SM']['centre'] == 1 and res['SM']['derived'] == 11 and res['SM']['rank'] == 4 and res['SM']['kmax'] < 1e-8
ok &= res['B']['n'] == 16 and res['B']['centre'] == 0 and res['B']['rank'] == 4 and res['A']['n'] == 36 and res['A']['rank'] == 4 and res['F4']['n'] == 52 and res['F4']['rank'] == 4 and res['F4']['centre'] == 0
chk('O3f', ok, f"structure of the twelve-dimensional stabiliser: it closes under the commutator, has a one-dimensional centre (the hypercharge u(1)), derived algebra of dimension 11 = 8 + 3, rank 4 (a generic element has a 4-dimensional centraliser), and its Killing form is negative semi-definite "
    f"(compact), like su(3) + su(2) + u(1); for comparison B: dimension 16, rank 4, centre 0 (su(3) + su(3)); A: 36, rank 4 (spin(9)); f4: 52, rank 4, centre 0")
# the 11-dimensional derived algebra splits into ideals of dimension 8 and 3
adS, _, _, _, _ = invariants(sBX, sr)
Bsm = np.array([x.ravel() for x in sBX]).T
brk = []
for a in range(12):
    for b in range(a + 1, 12):
        brk.append(np.linalg.lstsq(Bsm, (sBX[a] @ sBX[b] - sBX[b] @ sBX[a]).ravel(), rcond=None)[0])
brk = np.array(brk); U_, s_, Vt_ = np.linalg.svd(brk); Dv = Vt_[:11]                        # basis of the derived algebra in coefficient space
def ad_in(basis_coef):
    n = 12; mats = []
    for c in basis_coef:
        Xc = sum(c[t] * sBX[t] for t in range(12)); cols = []
        for d in basis_coef:
            Yc = sum(d[t] * sBX[t] for t in range(12)); Zc = Xc @ Yc - Yc @ Xc
            z = np.linalg.lstsq(Bsm, Zc.ravel(), rcond=None)[0]; cols.append(Dv @ z)       # coordinates in the derived basis
        mats.append(np.array(cols).T)
    return mats
adD = ad_in(list(Dv))
Nc = commutant_eigs(adD, 11)
Xg = sum(sr.randn() * Nc[:, t] for t in range(Nc.shape[1])).reshape(11, 11)
evX = np.round(np.linalg.eigvals(Xg).real, 4)
mult = sorted(Counter(evX.tolist()).values())
chk('O3g', Nc.shape[1] == 2 and mult == [3, 8], 'the derived algebra (dimension 11) of the Standard Model stabiliser has a two-dimensional commutant of its adjoint action, i.e. two simple ideals, of dimensions 3 and 8: su(2) + su(3); with the u(1) centre this is the Lie algebra of S(U(2) x U(3)) = gauge group of the Standard Model (Baez-Schwahn, Thm. 1)')
# triality: the three 8-dimensional blocks under the Jordan-frame stabiliser so(8)
blocks = {'12': list(range(3, 11)), '23': list(range(11, 19)), '31': list(range(19, 27))}
rep = {k: [D[np.ix_(v, v)] for D in st_frame] for k, v in blocks.items()}
def commutant_dim(r1, r2):
    rows = [np.kron(np.eye(8), A_) - np.kron(B_.T, np.eye(8)) for A_, B_ in zip(r1, r2)]
    return nullspace(np.vstack(rows), 1e-8).shape[1]
irr = {k: commutant_dim(rep[k], rep[k]) for k in rep}
cross = {(a, b): commutant_dim(rep[a], rep[b]) for a, b in (('12', '23'), ('23', '31'), ('12', '31'))}
leak = max(np.abs(D[np.ix_(blocks['12'], blocks['23'])]).max() for D in st_frame)
cas = {}
# Casimir with respect to the trace form of the 28 matrices on the 8 + 8 + 8 + 3 coordinates (the same form for all three blocks)
Mtot = [D for D in st_frame]
Gm = np.array([[np.trace(A_ @ B_) for B_ in Mtot] for A_ in Mtot]); Gi = np.linalg.inv(Gm)
for k, v in blocks.items():
    C_ = sum(Gi[a, b] * rep[k][a] @ rep[k][b] for a in range(28) for b in range(28))
    cas[k] = C_[0, 0]
chk('O3h', all(v == 1 for v in irr.values()) and all(v == 0 for v in cross.values()) and leak < 1e-9 and abs(cas['12'] - cas['23']) < 1e-8 and abs(cas['23'] - cas['31']) < 1e-8,
    'triality inside f4: the stabiliser so(8) (28) of the Jordan frame acts on the three 8-dimensional blocks xi_12(O), xi_23(O), xi_31(O); each block is irreducible (commutant of dimension 1), the three are pairwise inequivalent (no non-zero intertwiner), '
    f'and they have the same Casimir value ({cas["12"]:.4f}): vector, left spinor, right spinor of Spin(8). So h3(O) = 3 + 3 x 8, the 3 x 8 of F14')
# =====================================================================================================================================================
# S. Where the three papers meet inside E6: (i) the ten-dimensional Jordan algebra A = h2(O) is the Lorentz cone of signature (1,9); (ii) the triples M_(3,2) < a_5 < bi-Cayley < Albert build one generation
#    step by step under the Standard Model subalgebra of the E7 paper; (iii) the Standard Model subalgebra of Baez-Schwahn acts on the Albert algebra in a different, self-conjugate way.
# =====================================================================================================================================================
# ---- (i) A = h2(O): x^2 - tr(x) x + det(x) 1_A = 0, det(x) = a b - |z|^2, signature (1,9); the traceless part is a Euclidean R^9 with v o v = |v|^2 1_A, a vector space of the Clifford algebra Cl(9,0)
Ai = sorted(Aset); eA = np.zeros(27); eA[0] = eA[1] = 1
prodA = lambda u, v: np.einsum('a,b,abc->c', u, v, JT)
ar = np.random.RandomState(21); okq = True; okv9 = True
for _ in range(20):
    x = np.zeros(27); x[Ai] = ar.randn(10)
    t_ = x[0] + x[1]; rem = prodA(x, x) - t_ * x; d_ = -rem[0]
    okq &= np.allclose(rem, -d_ * eA) and abs(d_ - (x[0] * x[1] - np.sum(x[3:11] ** 2))) < 1e-9
    v = x.copy(); v[0], v[1] = (x[0] - x[1]) / 2, -(x[0] - x[1]) / 2                         # traceless part
    okv9 &= np.allclose(prodA(v, v), (v[0] ** 2 + np.sum(v[3:11] ** 2)) * eA)
def dform(vec):
    x = np.zeros(27); x[Ai] = vec; return x[0] * x[1] - np.sum(x[3:11] ** 2)
Qd = np.zeros((10, 10))
for i in range(10):
    Qd[i, i] = dform(np.eye(10)[i])
    for j in range(i): Qd[i, j] = Qd[j, i] = 0.5 * (dform(np.eye(10)[i] + np.eye(10)[j]) - dform(np.eye(10)[i]) - dform(np.eye(10)[j]))
evd = np.linalg.eigvalsh(Qd)
A90 = Alg(sig(9, 0))
chk('O3i', okq and okv9 and (int((evd > 1e-9).sum()), int((evd < -1e-9).sum())) == (1, 9) and A90.center_blades() == [0, 511] and A90.sq(511) == 1 and A90.N == 2 * 16 * 16 and TYPES[9 % 8] == 'R2',
    'A = h2(O) (dimension 10, the Jordan algebra of Baez-Schwahn, Lemma 10) satisfies the quadratic equation x o x - tr(x) x + det(x) 1_A = 0 with det = a b - |z|^2 (20 random elements): it is the spin factor R + R^9, the traceless part is a Euclidean R^9 with v o v = |v|^2 1_A, '
    'and the determinant has signature (1, 9): the positive cone of h2(O) is the future light cone of ten-dimensional Minkowski space. The same vector space R^9 generates the bit-rule algebra Cl(9,0): clock 9 = 1, type R2, centre {1, e_1...9} with e_1...9 squaring to +1, dimension 512 = 2 x 16^2 = M_16(R) + M_16(R): '
    'the 16 = the Peirce 1/2 space of A in the Albert algebra (27 = 10 + 16 + 1, E2a, O3b) is the real spinor module of Spin(9) = Stab(A) (36, O3e)')
# ---- (ii) the grade-1 triples of the E7 chain under the Standard Model subalgebra g_SM = A2(alpha_1, alpha_3) + A1(alpha_2) + centre (E7 paper): irreducible pieces (su(3), su(2)), recovered from highest weights
SU3W = {'1': [(0, 0)], '3': [(1, 0), (-1, 1), (0, -1)], '3b': [(0, 1), (1, -1), (-1, 0)]}
SU2W = {'1': [0], '2': [1, -1]}
def labE(k): return (ip(R8[k], S8[0]), ip(R8[k], S8[2]), ip(R8[k], S8[1]))                # Dynkin labels with respect to alpha_1, alpha_3 (su(3)) and alpha_2 (su(2))
def decomp_sm(ids):
    pool = Counter(labE(k) for k in ids); out = Counter(); rais = [(2, -1, 0), (-1, 2, 0), (0, 0, 2)]
    while pool:
        hw = sorted(w for w in pool if all(tuple(a + b for a, b in zip(w, r)) not in pool for r in rais))
        w = hw[0]; s3 = {(0, 0): '1', (1, 0): '3', (0, 1): '3b'}.get(w[:2]); s2 = {0: '1', 1: '2'}.get(w[2])
        if s3 is None or s2 is None: return None
        for a in SU3W[s3]:
            for b in SU2W[s2]:
                tt = (a[0], a[1], b)
                if pool[tt] <= 0: return None
                pool[tt] -= 1
                if pool[tt] == 0: del pool[tt]
        out[(s3, s2)] += 1
    return out
dimsm = lambda key: {'1': 1, '3': 3, '3b': 3}[key[0]] * {'1': 1, '2': 2}[key[1]]
dec = {n: (decomp_sm(g1[n]) or Counter()) for n in (4, 5, 6, 7)}
okd = all(dec[n] is not None and sum(dimsm(k) * m for k, m in dec[n].items()) == len(g1[n]) for n in dec)
exp = {4: {('3', '2'): 1}, 5: {('3', '2'): 1, ('3b', '1'): 1, ('1', '1'): 1}, 6: {('3', '2'): 1, ('3b', '1'): 2, ('1', '2'): 1, ('1', '1'): 2}, 7: {('3', '2'): 1, ('3b', '1'): 3, ('3', '1'): 1, ('1', '2'): 3, ('1', '1'): 3}}
okc = all(dict(dec[n]) == exp[n] for n in exp)
okchain = all(all(dec[n].get(k, 0) >= m for k, m in dec[n - 1].items()) for n in (5, 6, 7))
# the label side: the 16 even labels with su(2) on bits 0,1 and su(3) on bits 2,3,4 (H3f) have the same content: (a, b) = (1,1): (3,2); (0,2) and (2,2): (3b,1); (1,3): (1,2); (0,0), (2,0): (1,1)
labcont = Counter()
for x in EVEN:
    a_, b_ = a_of(x), b_of(x)
    labcont[({0: '1', 1: '3', 2: '3b', 3: '1'}[b_], {0: '1', 1: '2', 2: '1'}[a_])] += 1
labdec = Counter({('3', '2'): labcont[('3', '2')] // 6, ('3b', '1'): labcont[('3b', '1')] // 3, ('1', '2'): labcont[('1', '2')] // 2, ('1', '1'): labcont[('1', '1')]})
chk('S1', okd and okc and okchain and labdec == Counter(exp[6]),
    'under g_SM = su(3)(alpha_1, alpha_3) + su(2)(alpha_2) + u(1) of the E7 paper the grade-1 spaces of the chain (highest-weight peeling of the root labels) split as: M_(3,2)(C), 6 = (3,2); a_5(C), 10 = (3,2) + (3-bar,1) + (1,1); bi-Cayley, 16 = (3,2) + 2 (3-bar,1) + (1,2) + 2 (1,1); '
    'Albert, 27 = 16 + (3,1) + 2 (1,2) + (1,1) (each triple contains the previous one): the 16 is exactly one generation (q_L; u-bar, d-bar; l_L; e-bar, nu-bar), and the six even labels of H2a with their (weak, colour) bit counts have the same content (the 16 even labels: 6 + 3 + 3 + 2 + 1 + 1). '
    'So the tower M_(3,2) < a_5 < bi-Cayley < Albert is a stepwise construction of one generation: first the quark doublet, then the antiup and the positron, then the rest, then 11 extra states (which are not Standard Model particles)')
# ---- (iii) the Standard Model subalgebra of Baez-Schwahn acting on h3(O) (27 real dimensions): Casimirs of its two simple ideals on the 27
XgT = Xg.T                                                                                 # the commutant of the adjoint action is found for the transposed matrices (row-major vectorisation)
ev_, vecs_ = np.linalg.eig(XgT)
vals_ = np.round(ev_.real, 3); ideals = {}
for v in sorted(set(vals_.tolist())):
    vm = float(np.mean(ev_.real[vals_ == v]))                                              # the exact eigenvalue of the cluster
    ns = nullspace(XgT - vm * np.eye(11), 1e-6)
    ideals[ns.shape[1]] = ns                                                              # 3 -> su(2), 8 -> su(3): coordinates in the derived basis
def mats_of(ns):
    out = []
    for t in range(ns.shape[1]):
        coef = Dv.T @ ns[:, t]; out.append(sum(coef[s] * sBX[s] for s in range(12)))
    return out
def casimir_on(mats, rep_mats=None):
    k = len(mats); Bm_ = np.array([m.ravel() for m in mats]).T
    ad_ = [np.array([np.linalg.lstsq(Bm_, (x @ y - y @ x).ravel(), rcond=None)[0] for y in mats]).T for x in mats]
    K_ = np.array([[np.trace(ad_[a] @ ad_[b]) for b in range(k)] for a in range(k)]); Ki = np.linalg.inv(K_)
    return sum(Ki[a, b] * mats[a] @ mats[b] for a in range(k) for b in range(k))       # K^(ab) X_a X_b: positive on a compact algebra (the Killing form is negative)
m2, m3 = mats_of(ideals[3]), mats_of(ideals[8])
C2_27, C3_27 = casimir_on(m2), casimir_on(m3)
# the Casimir of an ideal on its own adjoint representation is 1 (Killing normalisation): check on the 12-dimensional algebra's adjoint action restricted to the ideal
def adj_cas(mats):
    k = len(mats); Bm_ = np.array([m.ravel() for m in mats]).T
    ad_ = [np.array([np.linalg.lstsq(Bm_, (x @ y - y @ x).ravel(), rcond=None)[0] for y in mats]).T for x in mats]
    K_ = np.array([[np.trace(ad_[a] @ ad_[b]) for b in range(k)] for a in range(k)]); Ki = np.linalg.inv(K_)
    return sum(Ki[a, b] * ad_[a] @ ad_[b] for a in range(k) for b in range(k))
close_eye = lambda M_, k_: M_.shape == (k_, k_) and np.allclose(M_, np.eye(k_), atol=1e-8)
okadj = close_eye(adj_cas(m2), 3) and close_eye(adj_cas(m3), 8)
Mx = C3_27 + 10 * C2_27
evm = np.linalg.eigvals(Mx); assert np.abs(evm.imag).max() < 1e-7
cont = Counter()
for lam_ in evm.real:
    best_ = min(((c3, c2) for c3 in (0, Fr(4, 9)) for c2 in (0, Fr(3, 8), 1)), key=lambda p: abs(float(p[0]) + 10 * float(p[1]) - lam_))
    cont[best_] += 1; okadj &= abs(float(best_[0]) + 10 * float(best_[1]) - lam_) < 1e-6
want_f4 = Counter({(Fr(0), Fr(0)): 2, (Fr(0), Fr(3, 8)): 4, (Fr(0), Fr(1)): 3, (Fr(4, 9), Fr(3, 8)): 12, (Fr(4, 9), Fr(0)): 6})
cont = Counter({(Fr(c3), Fr(c2)): n for (c3, c2), n in cont.items()})
# the same table for the E7 side: dimension by (su(3) Casimir, su(2) Casimir)
cas3 = {'1': Fr(0), '3': Fr(4, 9), '3b': Fr(4, 9)}; cas2 = {'1': Fr(0), '2': Fr(3, 8)}
cont7 = Counter()
for (s3, s2), mult in dec[7].items(): cont7[(cas3[s3], cas2[s2])] += mult * dimsm((s3, s2))
chk('S2', okadj and cont == want_f4 and sum(cont.values()) == 27 and cont7 != cont,
    'the Standard Model subalgebra of Baez-Schwahn (12-dimensional stabiliser of X and B in f4, O3e-O3g) acts on the 27 real dimensions of h3(O); its simple ideals su(2) (3) and su(3) (8), normalised so that their Casimir is 1 on their own adjoint representation, have joint Casimir values (su(3), su(2)) with dimensions: '
    + ', '.join(f'({c3}, {c2}): {n}' for (c3, c2), n in sorted(cont.items())) + ' = 27, exactly what the explicit description of Lemma 4 predicts ((X, M) -> (g X g*, h M g*): 27 = (1,1) + (1,8) + (3,3-bar) + (3-bar,3) under SU(3)_colour x SU(3)_g, with SU(2) x U(1) in SU(3)_g: 2 + 4 + 3 + 12 + 6 states in the classes (1,1), (1,2), (1,3), (3 or 3-bar, 2), (3 or 3-bar, 1)). '
    'The same table for the E7 subalgebra of (ii) on the 27 of E6 is ' + ', '.join(f'({c3}, {c2}): {n}' for (c3, c2), n in sorted(cont7.items())) + ': different. Since F4 < E6 and the 27 of E6 restricts to the real h3(O) = 1 + 26, the two su(3) + su(2) subalgebras are not conjugate in E6. '
    'The group of Baez-Schwahn is the Standard Model group abstractly, and acts on h3(O) in a self-conjugate way (a real representation); the chiral generation is the 16 of the bi-Cayley triple, acted on by the su(3) + su(2) of the E7 chain, a different subalgebra of e6')
# =====================================================================================================================================================
# K. The Kepler paper: the trio -1, 0, +1 of orbits, the hidden so(4) as bivectors, left and right multiplication on H, shell counts, the periodic table, so(4,2) as a 3-graded algebra.
# =====================================================================================================================================================
def poisson(f, g, q, p, h=1e-5):
    tot = 0.0
    for i in range(3):
        dq = np.zeros(3); dq[i] = h
        fq = (f(q + dq, p) - f(q - dq, p)) / (2 * h); gq = (g(q + dq, p) - g(q - dq, p)) / (2 * h)
        fp = (f(q, p + dq) - f(q, p - dq)) / (2 * h); gp = (g(q, p + dq) - g(q, p - dq)) / (2 * h)
        tot += fq * gp - fp * gq
    return tot
Lf = lambda i: (lambda q, p: np.cross(q, p)[i])
Ef = lambda q, p: 0.5 * p @ p - 1 / np.linalg.norm(q)
ef = lambda i: (lambda q, p: (np.cross(p, np.cross(q, p)) - q / np.linalg.norm(q))[i])
kr = np.random.RandomState(2)
eps3 = lambda j, k, l: (j - k) * (k - l) * (l - j) // 2
ok = True; Es = []
for trial in range(6):
    q = kr.randn(3); p = kr.randn(3) * (0.4 if trial < 3 else 1.3); En = Ef(q, p); Es.append(En)
    Lv = np.array([Lf(i)(q, p) for i in range(3)]); ev_ = np.array([ef(i)(q, p) for i in range(3)])
    ok &= abs(ev_ @ ev_ - (1 + 2 * (Lv @ Lv) * En)) < 1e-9                               # e^2 = 1 + 2 L^2 E
    for j in range(3):
        for k in range(3):
            if j == k: continue
            l = 3 - j - k
            ok &= abs(poisson(ef(j), ef(k), q, p) - (-2 * En * eps3(j, k, l) * Lv[l])) < 1e-6      # {e_j, e_k} = -2E eps_jkl L_l
            ok &= abs(poisson(Lf(j), ef(k), q, p) - eps3(j, k, l) * ev_[l]) < 1e-6
            ok &= abs(poisson(Lf(j), Lf(k), q, p) - eps3(j, k, l) * Lv[l]) < 1e-6
chk('K1a', ok and any(E_ < 0 for E_ in Es) and any(E_ > 0 for E_ in Es),
    'Kepler problem, checked at random phase-space points of both energy signs (finite-difference Poisson brackets): e^2 = 1 + 2 L^2 E, {L_j,L_k} = eps L, {L_j,e_k} = eps e, {e_j,e_k} = -2E eps L: the algebra of L and e has structure constants that depend on the energy only through the factor -2E (eqs. (6), (9))')
def bivs(eps):
    A = Alg((1, 1, 1, eps))
    one = lambda m, c=1: {m: Fr(c)}
    Lp = [one(0b0110), one(0b0101, -1), one(0b0011)]                     # L'_1 = e2 e3, L'_2 = e3 e1 = -e1 e3, L'_3 = e1 e2
    Mp = [one(0b1001), one(0b1010), one(0b1100)]                         # M'_k = e_k e4
    return A, Lp, Mp
def cmt(A, x, y): return A.add(A.mul(x, y), A.mul(y, x), -1)
res_k = {}
for eps in (1, 0, -1):
    A, Lp, Mp = bivs(eps)
    Lk = [A.scal(x, Fr(-1, 2)) for x in Lp]; Mk = [A.scal(x, Fr(-1, 2)) for x in Mp]            # L = -L'/2 and M = -M'/2: {L_j,L_k} = eps L_l
    okc = True
    for j, k in ((0, 1), (1, 2), (2, 0)):
        l = 3 - j - k
        okc &= cmt(A, Lk[j], Lk[k]) == Lk[l] and cmt(A, Lk[j], Mk[k]) == Mk[l] and cmt(A, Mk[j], Mk[k]) == A.scal(Lk[l], Fr(eps))
    basis = Lk + Mk
    # structure constants and Killing form
    def coords_(x):
        out = []
        for b in basis:
            m = next(iter(b)); out.append(x.get(m, 0) / b[m])
        return out
    ad = []
    for x in basis:
        ad.append(np.array([[float(c) for c in coords_(cmt(A, x, y))] for y in basis]).T)
    kill = np.array([[np.trace(ad[a] @ ad[b]) for b in range(6)] for a in range(6)])
    evk = np.linalg.eigvalsh(kill)
    res_k[eps] = (okc, (int((evk > 1e-9).sum()), int((evk < -1e-9).sum()), int((abs(evk) <= 1e-9).sum())))
chk('K1b', all(v[0] for v in res_k.values()) and res_k[1][1] == (0, 6, 0) and res_k[0][1] == (0, 3, 3) and res_k[-1][1] == (3, 3, 0),
    'the same algebra from the bit rule: bivectors L = -e_j e_k / 2 and M = -e_k e_4 / 2 of the algebra with generator squares (+1, +1, +1, eps) satisfy [L_j,L_k] = L_l, [L_j,M_k] = M_l, [M_j,M_k] = eps L_l; '
    'the Killing form has (positive, negative, zero) eigenvalue counts ' + ', '.join(f'eps = {e_:+d}: {res_k[e_][1]}' for e_ in (1, 0, -1)) + ': so(4), the Euclidean algebra e(3), so(3,1). Kepler: M = e / sqrt(-2E), so eps = -sign(E): bound orbit (ellipse) <-> so(4), parabola <-> e(3), hyperbola <-> so(3,1): the trio of the fourth generator square')
A4_, Lp4, Mp4 = bivs(1)
Lk = [A4_.scal(x, Fr(-1, 2)) for x in Lp4]; Mk = [A4_.scal(x, Fr(-1, 2)) for x in Mp4]
Aa = [A4_.scal(A4_.add(Lk[i], Mk[i]), Fr(1, 2)) for i in range(3)]; Bb = [A4_.scal(A4_.add(Lk[i], Mk[i], -1), Fr(1, 2)) for i in range(3)]
okab = all(cmt(A4_, Aa[j], Aa[k]) == Aa[3 - j - k] and cmt(A4_, Bb[j], Bb[k]) == Bb[3 - j - k] and cmt(A4_, Aa[j], Bb[k]) == {} for j, k in ((0, 1), (1, 2), (2, 0))) and all(cmt(A4_, Aa[i], Bb[i]) == {} for i in range(3))
chk('K1c', okab, 'A = (L + M)/2 and B = (L - M)/2 of eq. (13), formed from the bit-rule bivectors of the algebra with squares (+1,+1,+1,+1), satisfy [A_j,A_k] = A_l, [B_j,B_k] = B_l, [A_j,B_k] = 0: so(4) = so(3) + so(3) with the two so(3) the half-sum and half-difference of rotations and boosts-like bivectors')
# left and right multiplication on the quaternions H = Cl(0,2) = {1, e1, e2, e12}
AH = Alg(sig(0, 2))
def Lmat(a): return np.array([[AH.blade_mul(a, b)[0] * (AH.blade_mul(a, b)[1] == c) for b in range(4)] for c in range(4)], dtype=float)
def Rmat(a): return np.array([[AH.blade_mul(b, a)[0] * (AH.blade_mul(b, a)[1] == c) for b in range(4)] for c in range(4)], dtype=float)
Ls = [Lmat(a) for a in (1, 2, 3)]; Rs = [Rmat(a) for a in (1, 2, 3)]
cm = lambda X, Y: X @ Y - Y @ X
okh = all(np.allclose(cm(Ls[i], Rs[j]), 0) for i in range(3) for j in range(3)) and np.allclose(cm(Ls[0], Ls[1]), 2 * Ls[2]) and np.allclose(cm(Rs[0], Rs[1]), -2 * Rs[2])
span = np.array([M.ravel() for M in Ls + Rs]); rank6 = np.linalg.matrix_rank(span)
skew = all(np.allclose(M, -M.T) for M in Ls + Rs)
fix1 = all(np.allclose((Ls[i] - Rs[i]) @ np.array([1, 0, 0, 0]), 0) for i in range(3)) and not any(np.allclose((Ls[i] + Rs[i]) @ np.array([1, 0, 0, 0]), 0) for i in range(3))
chk('K2a', okh and rank6 == 6 and skew and fix1,
    'H = Cl(0,2) on its four labels: left and right multiplications by e1, e2, e12 are skew 4 x 4 matrices that commute pairwise (left with right), close into two copies of su(2), and together span all six dimensions of so(4); '
    'L_a - R_a (conjugation, the angular momentum of eq. (28)) fixes the unit label 0 and L_a + R_a does not: SU(2) x SU(2) acts on S^3 = unit labels of H by q -> g q h^-1, the hidden symmetry of the bound states')
def spin_mats(j2):                                            # spin j = j2/2 matrices (Jx, Jy, Jz)
    d = j2 + 1; m = np.array([j2 / 2 - t for t in range(d)])
    Jz = np.diag(m); Jp = np.zeros((d, d))
    for t in range(1, d): Jp[t - 1, t] = math.sqrt((j2 / 2) * (j2 / 2 + 1) - m[t] * (m[t] + 1))
    Jx = (Jp + Jp.T) / 2; Jy = (Jp - Jp.T) / 2j
    return Jx, Jy, Jz
okcg = True; shells = []
for j2 in range(0, 13):
    n = j2 + 1; d = n * n
    Jx, Jy, Jz = spin_mats(j2); Id = np.eye(j2 + 1)
    Aop = [np.kron(J, Id) for J in (Jx, Jy, Jz)]; Bop = [np.kron(Id, J) for J in (Jx, Jy, Jz)]
    Lop = [a + b for a, b in zip(Aop, Bop)]
    L2 = sum(M @ M for M in Lop); A2 = sum(M @ M for M in Aop)
    evl = np.round(np.linalg.eigvalsh((L2 + L2.conj().T) / 2), 6)
    cnt = Counter(evl.tolist()); want_ = {float(l * (l + 1)): 2 * l + 1 for l in range(n)}
    okcg &= dict(cnt) == want_ and np.allclose(A2, (n * n - 1) / 4 * np.eye(d)) and np.allclose(4 * A2 + np.eye(d), n * n * np.eye(d))
    shells.append(n * n)
tot2 = [2 * n * n for n in range(1, 8)]
chk('K2b', okcg and all(n * (n + 1) + n * (n - 1) == 2 * n * n for n in range(1, 30)) and tot2 == [2, 8, 18, 32, 50, 72, 98],
    'V_j (x) V_j for j = 0, 1/2, ..., 6 (n = 2j+1 = 1..13): 4 A^2 + 1 = n^2 (energy -1/(2n^2)), and under L = A + B the shell splits into V_l for l = 0..n-1 (Clebsch-Gordan: dimensions 2l+1 add up to n^2, computed from the spin matrices); with the electron spin 2n^2 = n(n+1) + n(n-1) (Dirac eigenspaces F_(n+1/2) and F_(-n+1/2)): 2, 8, 18, 32, 50, 72, 98')
sub = sorted(((n + l, n, l) for n in range(1, 9) for l in range(n)))
cum = list(itertools.accumulate(2 * (2 * l + 1) for _, n, l in sub))
want_cum = [2, 4, 10, 12, 18, 20, 30, 36, 38, 48, 54, 56, 70, 80, 86, 88, 102, 112, 118]
start = [0] + cum[:-1]
noble = [s_ for s_, (_, n, l) in zip(start, sub) if l == 0 and s_ > 0]                 # electron count just before each new s subshell opens
periods = [b - a for a, b in zip([0] + noble, noble + [118])]
chk('K3', cum[:19] == want_cum and noble[:6] == [2, 10, 18, 36, 54, 86] and periods[:7] == [2, 8, 8, 18, 18, 32, 32] and [p // 2 for p in periods[:7]] == [1, 4, 4, 9, 9, 16, 16],
    'Madelung rules (subshells in order of n + l, then n; subshell (n,l) holds 2(2l+1) electrons): cumulative electron counts ' + ', '.join(map(str, cum[:19])) + '; noble-gas closures ' + ', '.join(map(str, noble[:6])) + ', 118; period lengths ' + ', '.join(map(str, periods[:7])) +
    ' = 2 m^2 with m = 1,2,2,3,3,4,4 (the second quantisation of the paper: electrons = set bits among the orbital labels; the ground state of N electrons = the first N bits in the Madelung order)')
# so(4,2): the conformal algebra as the bivectors of the algebra with squares (+1,+1,+1,+1,-1,-1): 15 = 4 + 7 + 4 under a hyperbolic generator and under an elliptic one
A42 = Alg(sig(4, 2)); BV42 = [m for m in range(64) if pc(m) == 2]
def adm(Dm):
    cols = []
    for b in BV42:
        r = cmt(A42, Dm, {b: Fr(1)}); cols.append([float(r.get(c, 0)) for c in BV42])
    return np.array(cols).T
Dh = {0b010001: Fr(1, 2)}                                                          # e0 e4 : (+1)(-1) hyperbolic plane, D^2 = +1/4
De = {0b110000: Fr(1, 2)}                                                          # e4 e5 : (-1)(-1) elliptic plane, D^2 = -1/4
evh = np.linalg.eigvals(adm(Dh)); eve = np.linalg.eigvals(adm(De))
ch = Counter(np.round(evh.real, 6).tolist()); ce = Counter(np.round(eve.imag, 6).tolist())
cmp_ = [m for m in BV42 if (m & 0b110000) == 0]                                    # bivectors of the four positive generators: so(4)
comm_so4 = all(not cmt(A42, De, {m: Fr(1)}) for m in cmp_)
Kil = np.array([[np.trace(adm({a: Fr(1)}) @ adm({b: Fr(1)})) for b in BV42] for a in BV42]); evKil = np.linalg.eigvalsh(Kil)
chk('K4', len(BV42) == 15 and ch == Counter({1.0: 4, -1.0: 4, 0.0: 7}) and ce == Counter({1.0: 4, -1.0: 4, 0.0: 7}) and comm_so4 and (int((evKil > 1e-9).sum()), int((evKil < -1e-9).sum())) == (8, 7),
    'so(4,2) = the 15 bivectors of the algebra with squares (+1,+1,+1,+1,-1,-1): ad of a hyperbolic bivector (null pair, the dilatation of the conformal ladder of Step 9) has real eigenvalues +1, 0, -1 with multiplicities 4, 7, 4; ad of an elliptic bivector '
    '(the plane of the two negative generators: the energy of the Einstein universe) has eigenvalues +i, 0, -i with the same multiplicities 4, 7, 4, and it commutes with the six bivectors of the positive generators = so(4) = su(2) + su(2) of the paper (Sec. 5.1: SU(2) x SU(2) in SO(2,4)); '
    'Killing form: 8 positive, 7 negative: maximal compact so(4) + so(2). This is a real form of the 3-graded Lie algebra so(6, C) = g(-1) + g(0) + g(+1) = 4 + 7 + 4 that the type BDI Jordan triple C^4 (Baez-Bokor-Boyle, Table 1, n = 4) carries; the paper itself lists the complex algebra and its compact form, not so(4,2)')

# =====================================================================================================================================================
# T. The triangulation note: the Eisenstein lattice, the three triangle solids, the hermitian form of signature (1,9), and the clock of the algebra of signature (1,9).
# =====================================================================================================================================================
def rE(nn): return sum(1 for a in range(-12, 13) for b in range(-12, 13) if a * a - a * b + b * b == nn)
chi = lambda d: 0 if d % 3 == 0 else (1 if d % 3 == 1 else -1)
thetaE = [rE(nn) for nn in range(0, 31)]
form = [1] + [6 * sum(chi(d) for d in range(1, nn + 1) if nn % d == 0) for nn in range(1, 31)]
chk('T1a', thetaE == form and thetaE[:8] == [1, 6, 0, 6, 6, 0, 0, 12], 'Eisenstein integers a + b w (w = exp(2 pi i / 3)) of norm a^2 - ab + b^2 = n: counts 1, 6, 0, 6, 6, 0, 0, 12 for n = 0..7 (and the formula 6 x sum over d | n of chi_-3(d) for n up to 30): six units, none of norm 2, six of norm 3')
# shadows of the E7 roots in the generation plane: the weight lattice of A2 (min squared length 2/3), Eisenstein norm N = (3/2)|pi|^2
Ns = Counter(round(1.5 * nz(p)) for p in proj)
latt = Counter()
w1 = np.array([1.0, 0.0]); w2 = np.array([-0.5, math.sqrt(3) / 2])
for a in range(-6, 7):
    for b in range(-6, 7):
        v = a * w1 + b * w2; N_ = a * a - a * b + b * b                      # hexagonal lattice: Eisenstein norm
        latt[N_] += 1
chk('T1b', Ns == Counter({0: 30, 1: 90, 3: 6}) and latt[0] == 1 and latt[1] == 6 and latt[2] == 0 and latt[3] == 6,
    'the 126 roots of e7 projected to the generation plane land on the Eisenstein lattice (the weight lattice of A2) in Eisenstein norms N = 0 (30 roots), 1 (90 roots, the six weights +-w_k) and 3 (the 6 roots of A): exactly the shells N <= 3 that the theta series allows '
    '(1, 6, 0, 6: no point of norm 2): the trichotomy of Lemma 2 of the E7 paper is the statement that the Eisenstein lattice has no vector of norm 2; the lattice of the triangulation paper and the plane of the generation sl3 are the same hexagonal lattice')
Vs = [(4, 3), (6, 4), (12, 5)]
okp = all(V_ * (6 - k_) == 12 and (V_ * k_) % 3 == 0 and V_ - (V_ * k_ // 2) + (V_ * k_ // 3) == 2 for V_, k_ in Vs)
from scipy.spatial import ConvexHull
okh_ = True
for t in range(6):
    pts = np.random.RandomState(40 + t).randn(25 + 7 * t, 3); pts /= np.linalg.norm(pts, axis=1)[:, None]
    hull = ConvexHull(pts); deg = Counter()
    for s_ in hull.simplices:
        for v_ in s_: deg[v_] += 1
    okh_ &= sum(6 - d_ for d_ in deg.values()) == 12 and len(hull.simplices) == 2 * len(deg) - 4
chk('T2', okp and okh_, 'discrete Gauss-Bonnet for triangulations of the sphere: the sum over vertices of (6 - valence) is 12 (each 5-valent vertex is a cone point of deficit pi/3): tetrahedron 4 x 3, octahedron 6 x 2, icosahedron 12 x 1, and for six random convex triangulations of the sphere (25 to 60 points)')
sq3 = math.sqrt(3.0)
def Qform(vec):                                   # vec: 20 reals (x1..x10, y1..y10); v11 = -sum; returns (4/sqrt3) area of the polygon - sum |v_j|^2
    v = [complex(vec[i], vec[10 + i]) for i in range(10)]; v.append(-sum(v))
    z = [0j]
    for t in range(11): z.append(z[-1] + v[t])
    area = 0.5 * sum((z[t].conjugate() * z[t + 1]).imag for t in range(11))
    return 4 / sq3 * area - sum(abs(t) ** 2 for t in v)
E20 = np.eye(20); Hm = np.zeros((20, 20))
for i in range(20):
    Hm[i, i] = Qform(E20[i])
    for k in range(i):
        Hm[i, k] = Hm[k, i] = 0.5 * (Qform(E20[i] + E20[k]) - Qform(E20[i]) - Qform(E20[k]))
evH = np.linalg.eigvalsh(Hm)
Jm = np.zeros((20, 20)); Jm[:10, 10:] = -np.eye(10); Jm[10:, :10] = np.eye(10)                 # multiplication by i on (x, y)
tr = np.random.RandomState(8); integer_ok = True; rot_ok = True
om = complex(-0.5, sq3 / 2)
for t in range(30):
    ab = tr.randint(-4, 5, size=(10, 2)); vz = [a_ + b_ * om for a_, b_ in ab]
    vec = np.array([v.real for v in vz] + [v.imag for v in vz]); q0 = Qform(vec)
    integer_ok &= abs(q0 - round(q0)) < 1e-9
    vz2 = [v * om for v in vz]; q1 = Qform(np.array([v.real for v in vz2] + [v.imag for v in vz2])); rot_ok &= abs(q1 - q0) < 1e-9
chk('T3', (int((evH > 1e-9).sum()), int((evH < -1e-9).sum())) == (2, 18) and np.allclose(Jm.T @ Hm @ Jm, Hm) and integer_ok and rot_ok,
    'Thurston triangulations: with the polygon P determined by 10 Eisenstein integers v_1..v_10 (v_11 = -sum), the number of triangles of the folded star = (4/sqrt3) x area(P) - sum |v_j|^2 (the 11 inward yellow triangles of side |v_j| removed): '
    'this quadratic form on R^20 = C^10 is invariant under multiplication by i (hence the real part of a hermitian form), takes integer values on Eisenstein 10-tuples (30 random ones) and is invariant under multiplication by w; '
    f'its eigenvalues have signs ({int((evH > 1e-9).sum())}, {int((evH < -1e-9).sum())}) over R: complex signature (1, 9), the claim of the note (reproduced from the shoelace formula, not taken from Engel-Smillie)')
def clock_info(p, q):
    n = p + q; c = (p - q) % 8; A = Alg(sig(p, q)); top = A.N - 1
    return TYPES[c], A.sq(top)
rw = [(p, 10 - p) for p in range(11)]
info = {pq: clock_info(*pq) for pq in rw}
real_weyl = [pq for pq in rw if info[pq][0] == 'R' and info[pq][1] == 1]
chk('T4', real_weyl == [(1, 9), (5, 5), (9, 1)] and info[(1, 9)] == ('R', 1) and info[(10, 0)] == ('R', -1) and Alg(sig(1, 9)).center_blades() == [0],
    'the algebra of signature (1,9) (the signature of the hermitian form) has clock 1 - 9 = -8 = 0 mod 8: type R, so Cl(1,9) = M_32(R), simple (centre = scalars), and its pseudoscalar squares to +1, so the even part splits and there are real (Majorana-Weyl) spinors of 16 components, 32 = 16 + 16: '
    'among the 11 signatures (p, 10 - p) exactly (1,9), (5,5), (9,1) have a real type and a pseudoscalar of square +1. The note asks whether (1,9) being the ten-dimensional Minkowski signature is a coincidence: this is what the clock says about it; it does not give a mechanism for the signature of the form')
# =====================================================================================================================================================
# C. The cospan paper: Frobenius structure of the label algebra.  Wires are bits; composing along a shared wire contracts it with eps_i, a closed loop gives a scalar.
# =====================================================================================================================================================
frob = {}
for n in (2, 3, 4):
    for eps in itertools.product((1, -1, 0), repeat=n):
        A = Alg(eps); N_ = A.N; top = N_ - 1
        Gs = np.zeros((N_, N_)); Gt = np.zeros((N_, N_))
        for a in range(N_):
            for b in range(N_):
                s_, c = A.blade_mul(a, b)
                if c == 0: Gs[a, b] = s_
                if c == top: Gt[a, b] = s_
        rs = np.linalg.matrix_rank(Gs); rt = np.linalg.matrix_rank(Gt)
        sym = np.allclose(Gt, Gt.T); gsym = all(Gt[a, b] == (-1) ** (pc(a) * pc(b)) * Gt[b, a] for a in range(N_) for b in range(N_))
        frob[(n, eps)] = (rs == N_, rt == N_, sym, gsym)
ok = all((v[0] == (0 not in k[1])) and v[1] and (v[2] == (k[0] % 2 == 1)) and v[3] for k, v in frob.items())
chk('C1', ok and len(frob) == 9 + 27 + 81,
    'for all 3^n signature patterns (eps_i in {+1,-1,0}), n = 2, 3, 4 (117 algebras): the scalar-part form (x,y) -> coefficient of label 0 in xy is non-degenerate exactly when no generator is null (no eps_i = 0); the top-label form (x,y) -> coefficient of the all-ones label in xy '
    '(the Berezin integral; Hodge complement) is non-degenerate for every pattern including the null ones, symmetric when n is odd and graded-symmetric (-1)^(|x||y|) always: a Frobenius form exists for the whole trio of generator squares only in its top-label version (a reading of the "commutative Frobenius monoid" '
    'of the cospan paper in the label algebra; not a computation of the double categories themselves)')

# ---- data for the figures of the report (written only when a logs folder is next to the script; not part of any check)
import json
if '--write' in sys.argv and os.path.isdir(os.path.join(HERE, 'logs')):
    Pb_ = Pb[:, :]; q1 = Pb_[0] / np.linalg.norm(Pb_[0]); q2 = Pb_[1] - (Pb_[1] @ q1) * q1; q2 /= np.linalg.norm(q2)
    pts = Counter()
    for k, p in zip(E7, proj):
        key = (round(float(p @ q1) / 2, 4), round(float(p @ q2) / 2, 4), cls[k][0]); pts[key] += 1          # doubled coordinates -> real ones (divide by 2)
    FD = dict(
        edges=edges,
        classes=[dict(name=BBB[k][0], l1=str(k[0]), l2=str(k[1]), n=len(classes[k]), a=a_of(classes[k][0]), b=b_of(classes[k][0]), Y=str(Yf(classes[k][0])), Q=[str(q) for q in sorted({Q(x) for x in classes[k]})], labels=classes[k]) for k in BBB],
        grading=grading, ladder=dict(sizes=sizes, dims=dims, g1=[len(g1[n]) for n in (8, 7, 6, 5, 4)], rab={str(k): v for k, v in JT_RAB.items()}, want={str(k): v for k, v in want.items()}),
        dec={str(n): {f'{a}|{b}': m for (a, b), m in dec[n].items()} for n in dec},
        plane=[dict(x=k[0], y=k[1], kind=k[2], n=v) for k, v in sorted(pts.items())], plane_ns={str(k): v for k, v in Ns.items()}, theta=thetaE[:31],
        fano=dict(lines=[sorted([a, b, a ^ b]) for a in range(1, 8) for b in range(a + 1, 8) if a ^ b > b], negs=len(negs)), zorn=dict(kinds_z), zl=ZL,
        stab=dict(f4=dimF, frame=d_frame, B=d_B, A=d_A, X=d_X, SM=len(sBX), derived=res['SM']['derived']),
        cont={f'{c3}|{c2}': n for (c3, c2), n in cont.items()}, cont7={f'{c3}|{c2}': n for (c3, c2), n in cont7.items()},
        kepler={str(e_): list(v[1]) for e_, v in res_k.items()}, so42=dict(h=dict(ch), e={str(k): v for k, v in ce.items()}),
        madelung=dict(sub=[(n, l) for _, n, l in sub[:19]], cum=cum[:19], noble=noble[:7], periods=periods[:7]),
        triang=dict(Ns={str(k): v for k, v in Ns.items()}, eig_pos=int((evH > 1e-9).sum()), eig_neg=int((evH < -1e-9).sum()), real_weyl=real_weyl, info={f'{p}|{q}': list(v) for (p, q), v in info.items()}),
        frob=dict(n=len(frob), nondeg_scalar=sum(1 for v in frob.values() if v[0]), nondeg_top=sum(1 for v in frob.values() if v[1])),
        counts=dict(ok=N_OK, bad=N_BAD))
    json.dump(FD, open(os.path.join(HERE, 'logs', 'baez_figdata.json'), 'w'), default=str, indent=1)
print(f'\n{N_OK} checks ok, {N_BAD} failed')
sys.exit(0 if N_BAD == 0 else 1)
