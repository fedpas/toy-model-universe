# ONE RULE 2.8.0

The proofs round's sixth pass: the three themes of the Atiyah lens's map that pass five left and the gauge half of the instanton count. Three statements (group ATY, ATY-035 to ATY-037) placed as details after the rows they extend — Atiyah's determinant of a configuration of points on the labels of Cl(3,0), with the Berry–Robbins lift as the bit-rule product (1 + u·e)f₀; the Einstein obstructions of the edge-cone corollaries on named pairs and the paper's family of self-dual Einstein cones in closed form, both theorems closing for every β; the shifted Dirac equation on the frame of a weak static field, the quantization in proper time, the paper's (2.12) not reproduced — and ATY-034 completed (the ten fields that fix the instanton density are gauge transformations, with their parameters written down), from four scripts under `checks/selfcheck/proofs/` (55 check lines, 14 fault runs, logs beside them); three more entries in the Atiyah lens; the analysis page's map marked done to its last row, section 9 with items 11 to 14. Release notes: `docs/RELEASE_NOTES_v2.8.md`; the record: `docs/round8/PROOFS_ROUND6.md`.

# ONE RULE 2.7.0

The proofs round's fifth pass: the checks the Atiyah lens's map asked for. Nine statements (group ATY, ATY-026 to ATY-034) placed as details after the rows they extend — the Atiyah–Bott–Shapiro ring on the labels to degree 16, the Lefschetz fixed-point formula on the cube complex, the sign of chirality at n = 3, Spinors × Spinors = Forms as a rank, the Klein correspondence over 𝔽₂ in Cl(3,3), flat connections and the two-dimensional field theory of the binary icosahedral group, McKay for the binary tetrahedral and dihedral groups, the finite theta law, the conformal zero modes of the BPST instanton — from seven scripts under `checks/selfcheck/proofs/` (83 check lines, 21 fault runs, logs beside them); the Atiyah–Bott–Shapiro source of LAB-018 read through two expositions; nine more entries in the Atiyah lens; the analysis page's map marked done row by row, with a section 9. Release notes: `docs/RELEASE_NOTES_v2.7.md`; the record: `docs/round8/PROOFS_ROUND5.md`.

# ONE RULE 2.6.0

The tutorials and the proofs round's fourth pass: a tutorials page (`#/tutorials`) with eight courses taught through the Atlas's own objects — the rule from zero, geometry, algebra, category theory, topology, coding with the bit rule (a builder's guide for agents), physics (the four engines) and the conformal model — one self-contained page each with figures drawn from the package's code and logs and widgets that recompute in the browser, every claim a row id with its status and every computation a check id whose log ships; 60 candidates decided by passing scripts became rows, 14 readings proved and narrowed to what their checks decide, 30 placements of readings and questions demoted so that 31 of 32 page chains close, four open questions answered by computation, eight candidate statements corrected, four negative results kept (among them the window element of the exterior algebra for even r); 41 new scripts read again by a separate reader before they entered the tables; the registry and generator of the tutorials. Notes: `docs/RELEASE_NOTES_v2.6.md`; the records: `docs/round8/PROOFS_ROUND4.md`, `docs/round8/TUTORIALS.md`.

# ONE RULE 2.5.0

The Atiyah lens and the door's graphic novel: the door's picture is a strip of six panels in which a figure asks what the One Rule is and another answers one field at a time, each answer a row of the Atlas; the lens `atiyah` (71 dictionary entries, 252 readings on 150 rows) built from Sir Michael Atiyah's *Collected Works* vol. 7 and Hitchin's account, with the analysis page "Michael Atiyah: geometry and physics, read with the Atlas" (the narrative, the map of his themes on the Atlas, five papers read with the Atlas's method); 25 new statements (group ATY) with five scripts read again by a separate reader before they entered the tables, two negative results kept against the printed pages; `tools/make_analysis.mjs` for analysis pages; the tutorial "The bit rule and four college courses" and the symmetry-breaking note listed in the Logbook's Reports tab. Notes: `docs/RELEASE_NOTES_v2.5.md`; the record of the round: `docs/round8/ATIYAH.md`.

# ONE RULE 2.4.3

The proofs round, pass three: the rest of the list; seventeen rows closed (the two embeddings of the Standard-Model algebra, the generation A2 in the 16-dimensional model, the tenfold way, the area metric, a non-abelian source), 29 candidates became rows, the open clauses of pass two closed (Lense–Thirring, the conformal clauses, the finite gauge law, Laman), six rows changed by what the pass found, eleven open lines, the depends table repaired and extended, fourteen new scripts, 67 learner texts. Notes: `docs/RELEASE_NOTES_v2.4.md`, `docs/round7/PROOFS_ROUND3.md`.

# ONE RULE 2.4.2

The proofs round, pass two: eight rows closed (the Yang–Mills and the Dirac field equations derived from their actions), fifty-nine rows added and proved (the four statements the first pass opened, 55 candidates that a passing check decides), seven lines split off, eighteen sentences narrowed by the cross-check, twenty new scripts, seven scripts made stronger, 65 learner texts. Notes: `docs/RELEASE_NOTES_v2.4.md`, `docs/round7/PROOFS_ROUND2.md`.

# ONE RULE 2.4.1

The proofs round, first pass: the top twenty of the proofs list closed (36 rows proved by the Atlas, ten sentences narrowed to what their checks show), three scripts under `checks/selfcheck/proofs/`, the check records repaired. Notes: `docs/RELEASE_NOTES_v2.4.md`, `docs/round7/PROOFS_ROUND1.md`.

# ONE RULE 2.4.0

One door, one page, one record: the door at `#/` with the leaves as ways into the Atlas pages, the page top (lead, hero figure across the page, try line, three notes, two ways) and the record fold on every page, the look of Octavo through the design tokens, the guide and the export for agents (`#/agents`, `content/tuning/`), the third batch of gravity checks closed (26 rows, 16 scripts, 22 runs), the missing proofs listed with eight lead briefs, the story review proposed for every held paragraph and accepted by rule, the nine leaves of Octavo not yet drawn now drawn as page tops and section figures (28 rows, nine tests), Furey's six pages, a learner text for every story row and matrix line, the prime lab. Notes: `docs/RELEASE_NOTES_v2.4.md`.

# ONE RULE 2.3.0

The story round: narration rows, page composition, the chapters' parts, the figures chunk, the matrix learner texts, the review proposals. Notes: `docs/RELEASE_NOTES_v2.3.md`.

# ONE RULE 2.2.0

The physics restoration: the wave P4–P11 of `docs/PHYSICS_AUDIT.md` closes its 85 `must` gaps, so that every step page prints the physics its checks compute, by name and number, as checked output of the Atlas (D29); the translation matrices of spin, forque, the spring and the rigid body are rows of the Atlas, line by line (D35); and every figure with a ladder follows the Atlas method, from the lowest stored cell up, every lens at every rung, and down from the top (D37). The counts are in `docs/RELEASE_NOTES_v2.2.md`.

## Content

- adds the overlay `content/physics/` (D33): the seeds of the wave's 32 figures (`figures.p4.json` … `figures.p11.json`, one file per owner), the shared `placements.json`, and the rows and research texts of the four translation matrices (`rows.p6.json`, `rows.p9.json`, `rows.p11.json` with their `texts.p<k>.json`: 149 rows, D35)
- extends `tools/merge_physics.mjs` to the rows and texts of D35: the rows go into `rows.json` with `since: "v2.2"` (ids `SPN-M01` … `SPN-M30`, `FRQ-M00` … `FRQ-M40`, `SPR-M01` … `SPR-M22`, `RIG-M01` … `RIG-M56`), each keeping the placements it carries, marked `overlay: "physics"`, and completed to the shape of a row of 02 §1 (empty values; a row without a stage takes the stage of its step); the texts go into `texts.json` as drafts with `source: "physics:P<k>"`, and a `human` text is never replaced; the overlay's part is removed and added again on every run, so a second run writes the same bytes; `--check` prints what a merge would do
- adds the stored tables `content/stored_p4.json` … `stored_p11.json` (D34), written by `tools/physics/stored_p<k>.mjs` from `checks/selfcheck/*.json` and loaded by the figures on demand, not bundled
- computes the status of the 149 rows from their evidence (D22): proved by the Atlas 127, our reading 22; the badge "new" covers `since` v2.2 (`tools/build_content.mjs`); the status of every other row is unchanged
- draws `extra-generator`, `riemann-split` and `ladders` at learner level too, their chips offered at both levels (`tools/migrate/figures_from_v15.mjs`; the reflections of `ladders` as chips); gives `null-figures` the entry of its switch from the top; marks every control of the Atlas method that v15 did not have `from: "D37"` (20 entries on 19 figures)

## Engines

- adds `engines/physics/`, one module per owner, every sign and product from the kernel: `maxwellLadders.js` (P4), `commutators.js` and `dirac.js` (P5), `spinPhysics.js` and `forquePhysics2.js` (P6), `gauge.js` (P7), `gravity.js` and `projective.js` (P8), `nullPhysics.js` and `springPhysics.js` (P9), `furey.js` (P10), `rigid.js` (P11)
- merges the eight manifest fragments `engines/physics/MANIFEST.p<k>.json` into `engines/MANIFEST.json`: one entry per module (the twelve above and the shared `TranslationMatrix.jsx`), each with the kernel it imports, the stored table it reads and its test

## App

- draws the tally rows EQN-006 … EQN-020 through `TallyLine` in the sections (`src/components/Section.jsx`) and as the hero of Light and Dirac (`src/components/Hero.jsx`): at research level the record's four cells under the column names equation · where · components · incidences
- registers the wave's figures per owner (`src/figures/physics/p4.js` … `p11.js`, spread into `FIGURES`)
- shows the release 2.2.0 in the footer

## Figures

- adds the wave's 32 figures: `maxwell-ladders` (Light); `comm-ladder` (Step 2); `spin-rotor`, `spin-hestenes`, `spin-pointor`, `spin-halves`, `spin-matrix` (Step 5); `coupling-ring`, `coupling-ladder` (Step 6); `ym-graph`, `ym-ladder` (Step 7); `matter-halves`, `matter-ladder` (Step 8); `curvature-pairs` (Step 9); `einstein-terms`, `cosmological-generator` (Step 10); `null-pair-moves` (Step 11); `null-neck`, `null-criterion` (Step 13); `forque-lines`, `forque-matrix` (Step 14); `spring-oscillator`, `spring-faces`, `spring-table` (Step 15); `rigid-segment`, `rigid-square`, `rigid-frame-table`, `rigid-matrix` (Step 16); `furey-charges`, `furey-composites`, `furey-room`, `furey-trialities` (Calibration 2)
- adds the shared `TranslationMatrix.jsx` (D35: a line per row, its two columns a statement once its text record exists, the badge in a folded column, filters by status and thread) and `TallyLine.jsx`
- keeps `comm-ladder` and `null-pair-moves` within the page at phone width: their panels may shrink below the width of their tables, which scroll (a minimum width of 0)
- extends `charges` (the legend by mark and word, E² − B² and E·B, the force term by term, F on the simplex, the 14 checks), `comm-graph` (the roles in words, the commutators of the cell), `dirac-pic` (the counts, the Maxwell names, the covariance, momentum space, the independent check, the cube reading), `extra-generator` (the commutator constant and k = −s; the learner words), `rain` (the cone lines, the metric, the shear), `riemann-split` (the grades of B², 20 = 10 + 10; the learner words), `null-figures` (the mirror lens, the Gram readouts, the summary, the ladder of the stored rungs), `spring-cube` (the conjugation table), `furey-board` (what is short for three doubled sets, the capacities) and `ladders` (the restrictions named, the slot not stored; the learner words)

## Tests

- adds `tests/physics.test.mjs`, the runner of `tests/physics/p4.test.mjs` … `p11.test.mjs`, to `npm test` and to the release; it checks first that every module of `engines/physics/` has its entry in `engines/MANIFEST.json`
- rebuilds the broken copies of `tests/explore/physics.test.mjs` (8), `tests/explore/motion.test.mjs` (8) and `tests/physics/p10.test.mjs` (11 broken sources) with esbuild's asynchronous build: the synchronous one takes no plugin, so those copies did not build and counted as caught; each one builds and is caught by failing checks (589, 277 and 134 of them), and a copy that does not build fails the test; the learner words of the explorers are read by the full simplex checks
- extends `tests/figures.render.test.mjs`: an interactive entry with `from: "D37"` is a control of the Atlas method, never a slider
- extends `tests/logbook.test.mjs`: the badge "new" for `since` v16, v2.1 and v2.2; a research draft may name `physics:P<k>` as its drafter
- sets the budgets of `tests/shipped.test.mjs` at 480 kB gzipped for `dist/app.js` and 120 kB for `dist/app.css` (D38)
- adjusts one check each in `tests/physics/p6.test.mjs` (a proved line shows "checked" or the badge "new"), `p7.test.mjs` (a control may say `from: "D37"`) and `p11.test.mjs` (once the rows are merged, `rigid-matrix` prints each line's words as its row's text record)

## Docs

- adds `docs/RELEASE_NOTES_v2.2.md`; `tools/release.sh` runs the physics suite, writes the physics line and the budgets of D38 into the counts, and reads the registries of `src/figures/physics/`
- adds the decisions D33–D38 and the questions A38–A45 to `docs/DECISIONS.md`
- names the next work in `docs/HANDOVER.md` §3: the story round of `docs/STORY_PLAN.md`, the chunk split of D38, the audit's items left, the learner drafts of the 149 matrix rows

# ONE RULE 2.1.1

The physics layer of Calibration 1: the Light page and the lens explorers print what the checks of Maxwell's equation compute — the equations by name, the components of the field by role, the sources, cell by cell — as checked output of the Atlas (D29), and the large figures take the width of the page (D31). The counts are in `docs/RELEASE_NOTES_v2.1.1.md`.

## Content

- adds the seeds `maxwell-equations` (caption EQN-006, the hero of the Light page) and `maxwell-components` (caption PAG-010, the Maxwell section) to `content/figures.json`, with the controls they port (`tools/migrate/figures_from_v15.mjs`)
- adds the field `size: "wide"` to seventeen seeds (D31): the Maxwell figures, `four-views`, `lattice`, `dirac-pic`, `einstein-form-identity`, `kerr-schild-f`, `matrix-heatmap`, `cube-category`, `spring-cube`, `schuller-chain`, `e8-ladder`, `gosset-plane` (in `figures_from_v15.mjs`) and the three lens explorers (in `content/explore/figures.lens.json`, merged by `tools/merge_explore.mjs`)
- merges the rows MIR-007 (two mirrors make a boost: a computation, `mirrors_selfcheck` ran) and MIR-008 (the demicube as the picture of motion: a reading) into `content/explore/rows.json` and `texts.json`, placed in the two ways of the demicube explorer (D30: the drafts of A24 and A22 accepted)
- keeps the status of every row as computed; prints the stored output of `checks/selfcheck/maxwell.json` (blades with roles and names, equations with ids, names, terms and signs, incidences, the convention, the checks) as fact, with the sign convention shown as the input it is (INP-011), under D29

## Engines

- adds `engines/maxwellPhysics.js` (interface 23): the 15 stored cells Cl(k, d), k, d ≤ 4, k + d ≤ 7 — per cell the blades with their squares, roles and names, every term of ∇F = J with its sign, the equations with their ids, names and terms, the counts, the convention, the checks, the mirror, the algebra and the ladders — read from the stored block and recomputed through the kernel; `equationsOf` and `roleName` at both levels
- passes the physics to the explorers through `engines/explore/lens.js` (interface 24), and the motion of a plane corner on the demicube: the even element of two mirrors and its sandwich R x R̃ through the kernel, two moves composed

## App

- adds the wide layout of D31 (`src/components/Hero.jsx`, `src/components/FigureFrame.jsx`, `src/styles/components.css`): from 1100 px a figure whose seed says `size: "wide"` takes the full content width — a hero's figure under its statement, a section's under the section title, before the statements, with the section's small figures side by side after them; inside the frame the drawing comes first and its controls under it; the figures with readouts (the equations of a cell, the components of F, the explorers with one picture) put them beside the drawing; below 1100 px every figure keeps its column
- shows the release 2.1.1 in the footer

## Figures

- adds `maxwell-equations`: the equations of the picked cell by name, term by term with the mark of each role (KaTeX at research level, words at learner level), the strip of the components an equation uses, the mirror, and the folds of the ladders, the sign convention and the checks; time and space chips, the equation picker and the mirror, as v15 had them
- adds `maxwell-components`: the field F of the cell as the grid of its components by role (E, B, T) with the sources under it; a tap lists the equations a component enters, with its sign
- labels the rows of `four-views-maxwell` by field component with the textbook sign; the blade's name in the active lens is the second line (D29, A7 reversed)
- names the physics on the simplex and cube explorers (`src/figures/explore/lens/physics.jsx`): a source on every vertex, a field component on every edge, the equation it carries on every triangle, in every lens; a picked element lists its equations (D29, A33 reversed); where a drawing is dense some names are tooltips only (A37)
- draws the motion on the demicube explorer (`src/figures/explore/lens/motion.jsx`): a boost's spacetime diagram with its two mirrors, the tick, the rod, an event and its image, and the square or cube in motion; a turn's rod, square or cube; Play from rest to the chosen amount; a second plane composes the two moves

## Tests

- adds `tests/maxwell.test.mjs` (in `npm run test:data` and the release): the 15 cells recomputed through the kernel equal the stored file, broken copies caught, the three Maxwell figures printing the stored equations at both levels
- adds `tests/explore/motion.test.mjs` to the Explore runner, which requires it: every move against the textbook matrices and formulas and `mirrors.json`, every frame of Play
- adds `tests/explore/physics.test.mjs` to the Explore runner, which requires it: every name, equation and sign on the explorers against the stored file and the kernel
- extends `tests/figures.render.test.mjs`: the two Maxwell figures over a spread of the stored cells; every seed's size is "wide" or absent, and the figures D31 names are wide
- extends `tests/coverage.test.mjs`: a figure frame is marked wide exactly when its seed says so, a hero exactly when its own figure is
- lets `tests/logbook.test.mjs` read `explore:` as the drafter of a research draft the Explore overlay adds for its own row, beside `translator:`
- extends `tests/ui/smoke.test.mjs`: at 1920 and 1366 px the hero's figure of the Light page and of the simplex explorer spans the page column with no wider element and its controls under its drawing, the wide figures of the Light page's sections span the column, at 1024 px the hero's figure keeps its column; screenshots `tests/ui/shots/p3-*.png`
- extends `tests/shipped.test.mjs`: the notes of a patch release are the release's notes (read by the banned-words rule, required by the release files); the release notes name no date, so that a content rebuild leaves them true; the stylesheet budget is 96 kB, the script budget 340 kB gzipped (D20)

## Docs

- adds `docs/RELEASE_NOTES_v2.1.1.md`; `tools/release.sh` writes the counts into the notes of the release (a patch release's own when it has them), without a date
- states the content version of `docs/RELEASE_NOTES_v2.1.md` as the build's
- adds the decisions D29 to D32 and the question A37 to `docs/DECISIONS.md`, and marks A7 and A33 as reversed by D29
- names the next work in `docs/HANDOVER.md` §3: the wave P4–P11 of `docs/PHYSICS_AUDIT.md`, then the story round of `docs/STORY_PLAN.md` (D32)

# ONE RULE 2.1.0

Explore, the playable layer of the Atlas: a home with the path of eight leaves and the shelf of loose leaves, one live picture per leaf with three notes, and three lens explorers. Every sentence on an Explore page is a text record of a row; every number a picture prints is computed by the kernel and tested against a standard route or a stored check result. The counts are in `docs/RELEASE_NOTES_v2.1.md`.

## Content

- adds the overlay `content/explore/`: the registry of the path, the shelf and the lens explorers (`registry.json`), the home, ten leaf pages and three explorer pages (`pages.json`), the placements of existing rows on them (`placements.json`, each of order 1000 or more, so that no row's home moves), and the seeds of the thirteen Explore figures (`figures.leaf.json`, `figures.lens.json`)
- adds `tools/merge_explore.mjs`: merges the overlay into `rows.json`, `pages.json`, `figures.json` and `texts.json`, writing the same bytes on every run; `npm run content` and `tools/migrate/run_all.sh` run it, so a re-migration keeps Explore (D23)
- adds `content/texts_learner_explore.json`: learner drafts in the full register for the rows Explore shows that had none (the first learner texts of rows of the group INP among them) and in the short register for the notes and the heroes
- uses the short register of the content model (D21): a short learner text says less than its row, never more, in 20 to 200 characters; at learner level a hero prefers it
- computes the status of a row without v15 flags from its evidence (D22): a check that ran with a passing run gives proved by the Atlas; the badge "new" marks the rows whose `since` is v16 or v2.1
- keeps the status of the 1,013 rows of the Atlas as it is; places no statement that the rows do not make (the printing rule, D26), and keeps the three drafted rows of the author's questions A22, A24 and A28 out of the tables until the author accepts them

## Engines

- adds `engines/explore/leaves/`: the logics of the ten finished leaves of Octavo V₀ (clock, moves, zero, light, fall, roots, seats, magnets, springs, charge) on the kernel, every product through `engines/labels.js` or `engines/bitrule.js`, with no sign or parity loop of their own
- returns data, not sentences (D28): every sentence the Octavo logic returned (alt, aria, status, captions, notes) is a data key or is gone; the pictures draw names, values and formula readouts
- adds `engines/explore/names.js` (a label named by its bits, its number or its primes, on the kernel's `PRIMES` and `label`), `engines/explore/shared.js` and `engines/explore/index.js` (`LEAF_LOGIC`)
- adds `engines/explore/lens.js`: the numbers of the three lens explorers on `maxwellViews` and the kernel
- adds `engines/explore/leaves/stored/`: the outputs of Octavo's modules for the whole state space the controls reach, held value for value against the port
- adds the entries of `engines/explore/` to `engines/MANIFEST.json`

## App

- adds `#/explore`, the home of Explore: the path of eight leaves in reading order (a leaf without a page is a quiet card that says "not drawn yet"), the shelf of the drawn loose leaves, the lens explorers, and the way to the full Atlas
- adds `#/explore/<slug>`, a leaf or a lens explorer: where it sits on the path, its live picture first and wide, its hero row, its notes (rows, in the short register at learner level when the row has one), the try line, the two ways by mode, the open fold, the loose leaves that hang there, the neighbouring leaves, and "Connect to the full Atlas", which opens the page of the row the leaf rests on with that row targeted
- opens Explore at learner level: every link into it from another page carries `l=learner` and keeps the mode and the lens (the Contents menu, the start page, the lens rooms); Explore has no route default (D24)
- lists Explore once in the Contents menu, without its leaves and explorers
- keeps the previous and next links of the full Atlas among its own pages: the glossary is the last of them
- passes the mode to every figure (D25)
- shows the release 2.1.0 in the footer

## Figures

- adds the ten leaf pictures (`leaf-<slug>`): the front pictures of Octavo drawn with the design tokens from the leaf logics; turn, boost and slide told by mark and word, never by colour alone; Octavo's controls as chips, steppers, toggles, picks and buttons at both levels, never a slider (D24); animations start paused; at research level the Mathematician's or the Physicist's picture by mode
- adds the three lens explorers: the simplex view of Maxwell (`lens-simplex-maxwell`), the demicube view of moves (`lens-demicube-moves`) and the cube view of Maxwell (`lens-cube-maxwell`), redrawn by the lens chips simplex, cube, demicube and orthoplex, and at research level printed in bits or primes
- takes the caption row of each Explore figure from the hero row of its page

## Tests

- adds `tests/explore/`: a test per leaf (every number against the kernel and against a standard route that does not use the bit rule's sign, Octavo's outputs value for value, and broken copies of the logic that the checks must catch), the names over their whole domain, the lens explorers against `maxwell.json`, `mirrors.json` and `shapes.json`, and `pages.test.mjs`, the pages of Explore against the tables and rendered on the server
- adds `tests/explore.test.mjs`: runs every Explore test and the browser smoke test of Explore, sums their checks, and fails when one fails; `npm test` runs it
- adds `tests/ui/explore.smoke.test.mjs`: the home, two leaves and an explorer in the browser at 390 and 1366 px, light and dark, at both levels and from `file://`
- extends `tests/coverage.test.mjs`: on every leaf and explorer a note shows the short register exactly when the level is learner and its row has one; every link into Explore from another page opens learner level
- extends `tests/figures.render.test.mjs`: the thirteen Explore figures with their parameter sets, in both modes; the controls of D24; the colour rule in every folder of `src/figures/`
- extends `tests/shipped.test.mjs`: every rule reads the files of Explore; the budget of `dist/app.js` is 340 kB gzipped (D20)
- counts the badge "new" of the rows whose `since` is v16 or v2.1 in `tests/logbook.test.mjs`

## Docs

- adds `docs/EXPLORE_PLAN.md` (what the pictures may print as fact, the pages, the figures, the tests), `docs/EXPLORE_PORT.md` (the leaf logics on the kernel) and `docs/EXPLORE_CONTENT.md` (each line of Octavo, the row that carries it or "dropped: no row")
- adds `docs/RELEASE_NOTES_v2.1.md`; the release archive carries the release notes of 2.0 and 2.1
- adds the decisions D20 to D28 and the author's questions A22 to A36 to `docs/DECISIONS.md`
- describes Explore in `README.md` and `docs/HANDOVER.md`: what it holds, how to add a leaf, what is open

# ONE RULE 2.0.0

The Cascade Atlas as a static site with one kernel, its content in tables, and a Logbook. The counts are in `docs/RELEASE_NOTES_v2.0.md`.

## Content

- adds `content/rows.json`: every statement of the author's package as a row (a row that held several lines is split into `<id>b`, `<id>c` …), with its notions, kind, stage, evidence, dependencies and the page sections that show it
- adds `content/texts.json`: a research text for every row, in the author's words; the author's learner texts; the translator's learner drafts with the status `draft`
- adds the tables `pages`, `steps`, `needs`, `inputs`, `theorems`, `questions`, `sources`, `matrix`, `map`, `glossary`, `conventions`, `readings` and `lenses` (each lens with its dictionary)
- adds `content/checks.json` and `content/check_runs.json`: every check script with its recorded runs
- adds `content/leads.json`: the wave-3 leads as proposed edits beside the rows they touch
- adds `content/figures.json`: a seed for every figure, with its caption row, engine, lenses and parameters
- adds `content/candidates.json`: the missing pieces named by the labelling passes, deduplicated and linked to rows
- adds `content/lens_readings.json`: each lens's term for an element a row states, attached only by a shared check id or by the dictionary phrase standing in the research text
- adds `content/derived/status.json`: the status, badge, signature, address and neighbours of every row, computed
- adds `content/MIGRATION_COUNTS.json`: the counts every migration step must produce
- adds `content/persona_rules.md`: the rules of the guide and the five status words, in the author's words
- adds `tools/migrate/`: `run_all.sh` rebuilds `content/` from the author's package and stops on any count that differs
- adds `tools/build_content.mjs`: validates the tables, computes status, address and neighbours, writes `docs/COVERAGE.md`
- adds the learner pipeline: `tools/check_learner_texts.mjs` (thirteen rules), `tools/merge_learner_texts.mjs`, `npm run content`
- keeps the author's check scripts unchanged in `checks/`, with the wave-3 scripts and their logs beside them

## Kernel and engines

- adds `engines/bitrule.js`, the one kernel: the product of two blades by XOR with a sign; labels as lenses (Clifford indices, bits, primes, set, signature word, bit × square); checked against the Python reference `bitrule_A.py`
- points `labels`, `labelsEngine`, `categoryEngine`, `baezEngine`, `schullerEngine`, `nullEngine`, `spinEngine`, `pgaEngine` and `productKernels` at the kernel, each compared value by value with a fixture recorded from the author's modules (`engines/stored/`)
- keeps the comparison sign routes inside the comparison block of `engines/productKernels.js`, timed and compared with the kernel
- adds `engines/gravityChecks.js`: the stored gravity results, read from the logs of the checks
- adds `engines/MANIFEST.json`: the status of every module

## App

- adds the static site: `sh build.sh` writes `dist/` (one esbuild bundle, hash addresses, runs from `file://` and from any static server)
- adds the shell with three switches — mode (physics, mathematics), level (research, learner), lens — and the theme, all kept in the address so that a link reproduces a view
- shows every route of `pages.json`: Zero, the rule, the cells and each cell, the clock, light, the steps, the shapes, matter, the lenses and each lens room, the Logbook, ask, the glossary
- shows each statement as the text record of its row, with at most one badge, computed from the evidence
- shows evidence, needs, dependencies, readings, numbers and the address in a drawer, one click from the statement
- shows the reading of a row under its statement when a lens is active, never in its place
- shows at learner level only the rows with a learner text, with no formula; a section without one shows a notice
- loads KaTeX only when a research text on screen holds a formula
- adds the search palette (the Search button, or Ctrl/⌘-K): row ids, the words of the texts at the current level, page titles, step names, lens names and glossary terms; a hit opens its place with the current settings
- adds the map of the twenty steps on `/steps`: an arrow from one step to another where a row of the second derives from a row of the first
- adds the guide on `/ask`: the rows that match the question, each rendered as its statement with its id and badge, and the status words explained from `content/persona_rules.md`; no generated prose
- adds the Logbook: the register with filters and the row drawer, theorems, questions, sources, checks with their runs, how to run every check again, reports, analyses, leads with their proposed edits, candidates, the matrix heatmap, the dependency map of the pages, the method
- shows the version of the build in the footer: the release number and the content version
- draws the light and the dark theme from the design tokens

## Figures

- adds the figures registered in `src/figures/index.js` — the lattice of cells, the clock wheel, the four views of a product and the four views of Maxwell among them — drawn from the kernel and the stored check results with the design tokens only (their number is in the release notes)
- shows a labelled placeholder for every seed of `figures.json` that has no component
- takes every caption from the figure's caption row

## Tests

- adds `tests/kernel.test.mjs`: the kernel against the Python reference
- adds `tests/engines.test.mjs`: every engine against the kernel and its recorded fixture; no engine with a sign loop of its own
- adds `tests/figures.render.test.mjs`: every figure at both levels, both themes and every lens it declares
- adds `tests/logbook.test.mjs`: the register's filter counts against the tables
- adds `tests/coverage.test.mjs`: every rendered statement is a text record of its row; no formula at learner level; badges as computed
- adds `tests/ui/smoke.test.mjs`: the browser on the built site — screenshots, no console error, no overflow, the switches, the drawer, a deep link, the theme, `file://`
- adds `tests/shipped.test.mjs`: no history words in a shipped text, the licence header on every source file, no contact details or user paths, a closed import graph and one kernel, the size budget, the routes, the rows each page shows, the release files

## Docs

- adds the build book (`docs/00_README.md` to `docs/11_RESEARCH_TODO.md`), `docs/BUILD_CONTRACTS.md`, `docs/LABELLING_SCHEME.md`, `docs/Q2_SOURCES.md`, `docs/LENS_READINGS.md`, the learner notes `docs/LEARNER_TEXTS*.md` and `docs/labelling/` (the persona passes, merged and judged)
- adds `docs/COVERAGE.md`, written by the content build: rows, texts, statuses and learner gaps by page
- adds `docs/HANDOVER.md` (how to change a statement, add a row, a lens, a figure or a check) and `docs/DECISIONS.md` (what is decided, and what is left to the author)
- adds `docs/RELEASE_NOTES_v2.0.md` and `tools/release.sh` (`npm run release`): the content pipeline, the build, every suite, then `release/one-rule-v2.0.0.zip` with its size and sha256
- keeps the PolyForm Noncommercial License 1.0.0 (`LICENSE`) and its three-line notice on every source file
