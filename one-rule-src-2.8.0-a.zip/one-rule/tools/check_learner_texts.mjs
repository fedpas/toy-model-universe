#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/check_learner_texts.mjs — the mechanical checker of docs/09_TRANSLATION_PROTOCOL.md §3, applied to the learner drafts of
// content/texts_learner.json (BUILD_CONTRACTS interface 8). A learner text is a translation of its row's research text: the same statement
// in plain words, with no formula, no history wording, every number and every status or scope word of the research text kept.
//
// Usage (from the repository root):
//   node tools/check_learner_texts.mjs                 check content/texts_learner.json; exit 1 on any failure, with a table of failures by rule
//   node tools/check_learner_texts.mjs --fix           first recompute the two derived fields of every record (termsUsed, keptNumbers) from its body
//   node tools/check_learner_texts.mjs --explain ID    print what the checker reads in the research text of row ID (numbers to keep, status words)
//   node tools/check_learner_texts.mjs --file PATH     check another file of the same shape
//
// The rules (each failure names its rule):
//   R1  shape       a record has exactly the keys row, lang "en", mode "both", level "learner", lens null, register "full"|"short", body, status "draft"|"reviewed",
//                   (a "short" record is the few-words register of 02 §2 — Explore notes and heroes; it may say less than its row, never more: R6 is replaced by R7 for it, R9 is 20 to 200 characters)
//                   source "translator:learner@…" (or "translator:story@…", the story variant of the persona, STORY_PLAN §1.5), termsUsed [strings], keptNumbers [strings]
//   R2  row         the row exists in content/rows.json, has a research text (level research, lens null, mode both) and no human learner text
//   R3  duplicate   no two records with the same (row, mode, level, lens, register)
//   R4  formula     no formula marks: $ \ ^ _ { } = < > | ~, no operator or arrow (≡ ⊗ ∧ ∂ ∇ ∑ ∫ ⟨ ⟩ → ↦ ≅ ≤ ≥ ± × · …), no superscript or subscript
//                   character, no Greek letter, no blackboard or script letter (ℝ ℂ ℍ 𝕆 ℓ …), no vulgar fraction (½), no letter/letter fraction,
//                   no single-letter variable (a lone letter other than a, A, I)
//   R5  history     no word of the banned families: the list of BUILD_CONTRACTS (corrected, withdrawn, superseded, formerly, previously, re-worded,
//                   now proved, historically, used to, no longer), the English families P1–P6, P8, P9 of v15's test_no_history.mjs (reused below),
//                   and no date
//   R6  numbers     every number of the research text is in the learner text: every integer ≥ 2 (in digits, or as a number word: "two",
//                   "twelve", "second", "half" for 2 …) and every decimal or scientific number verbatim ("116.6", "3e-5"); numbers that belong to an
//                   identifier are not required (see IDENTIFIERS: Cl(1,3), cell addresses [4,−2], group names so(4,2), e1/E8/T18-style names,
//                   row and check ids, step, figure and equation numbers, script names, arXiv numbers, dates, digits under ^ or _);
//                   a check count "5569/5569" is kept by "5569 of 5569"
//   R7  new number  no number written in digits in the learner text that is absent from the research text (0 and 1 excepted)
//   R8  status      each status or scope word of the research text is in the learner text (open, input, checked, conjecture, ours / our reading,
//                   not proved, textbook / standard, exact, at points, floats, cited, recalled, unread, untested, not checked, not claimed,
//                   not derived, by hand, regression, for every n): see STATUS
//   R9  length      40 to 900 characters, or up to 1.5 × the length of the research text when that is longer (long rows are translated whole, not split)
//   R10 terms       termsUsed lists glossary terms (content/glossary.json) that occur in the body, and every glossary term that occurs in the body
//                   (the three context-bound terms form, vertex, mode excepted, as in src/app/glossary.js)
//   R11 kept        keptNumbers lists exactly the numbers R6 requires
//   R12 names       a capitalised word inside a sentence (a name) occurs in the research text of the row or of its parent row: no new authority
//   R13 contact     no e-mail address, link, script name or machine path
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const C = path.join(ROOT, 'content');
const readJSON = f => JSON.parse(fs.readFileSync(f, 'utf8'));

// ---------------------------------------------------------------------------------------------------------------------------- R4 formula
const FORMULA = [
  ['dollar, backslash, caret, underscore, brace', /[$\\^_{}]/],
  ['equals, comparison, bar or tilde sign', /[=<>|~]/],
  ['operator or arrow', /[≡⊗∧∨∂∇∑Σ∏∫⟨⟩→←↦⇒⇔⇐↔≅≃≈≠≤≥±∓⊕⊖⊂⊃⊆⊇∈∉∪∩√∞×·⋅⋆∘′″‖⊞⊠♭♯∗†‡∝∅∀∃⊥∥∠°]/],
  ['superscript or subscript character', /[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿⁱ₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑₒₓₔₕₖₗₘₙₚₛₜᵀᴬ-ᵪ]/],
  ['combining accent', /[̀-ͯ⃐-⃿]/],
  ['Greek letter', /[Ͱ-Ͽἀ-῿]/],
  ['blackboard or script letter', /[ℂℍℕℙℚℝℤℓℏℒℱℋℐ℘\u{1d400}-\u{1d7ff}]/u],
  ['vulgar fraction', /[¼½¾⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞]/],
  ['letter over letter (a symbolic fraction)', /\p{L}\s*\/\s*[\p{L}(]/u],
];
const LONE_OK = new Set(['a', 'A', 'I']);
function formulaHits(body) {
  const out = [];
  for (const [name, re] of FORMULA) { const m = body.match(re); if (m) out.push(`${name}: “${m[0]}”`); }
  // a lone letter, not inside a word or a name with digits (E8, 4D), not an apostrophe ending (Hestenes’), not a name before "(" (U(1)), is a variable
  const lone = [...body.matchAll(/(?<![\p{L}\p{N}’'\-])(\p{L})(?![\p{L}\p{N}’'\-(])/gu)].map(m => m[1]).filter(ch => !LONE_OK.has(ch));
  if (lone.length) out.push(`single-letter variable: “${[...new Set(lone)].join('”, “')}”`);
  return out;
}

// ---------------------------------------------------------------------------------------------------------------------------- R5 history
// The list of BUILD_CONTRACTS Round 2 and of the translator prompt (09 §2), then the English families of v15's test_no_history.mjs
// (P1–P6, P8, P9: the regexes are copied from that file; P7 is its Italian family and does not apply). Dates are not used in a learner text.
const HISTORY = [
  ['banned word (BUILD_CONTRACTS)', /\b(corrected|withdrawn|superseded|formerly|previously|re-?worded|now proved|historically|used to|no longer)\b/i],
  ['P1 ids of a list of notes', /\berrat(a|um)\b|\bE-\d{3}\b|\bfinding E-/i],
  ['P2 a note that a wording was fixed', /\bcorrected (on|in|after|before|by|6|5)\b|\bcorrections? (of|applied|block|section)\b|\bnow corrected\b|\bwas corrected\b|\bcorrected after a check\b|\bcorrigend|\bthe correction of F\d+|\bsee the corrections\b|\bcorrection\b/i],
  ['P3 taken back, crossed out', /\bwithdrawn\b|\bretract(ed|ion)\b|\bretired\b|\bstruck( through| out)?\b|\bsuperseded\b|\bobsolete\b|\bstale\b|\bdiscarded wording\b/i],
  ['P4 first-draft narrative', /\b(was|were|is|are) (wrong|too strong|too weak|a mistake|mistaken)\b(?! (for|in|when|if|only|here|on)\b)|\b(was|were|is|are) false\b(?! (for|in|when|if|only|here|on)\b)|\bas first (written|stated|printed|said)\b|\bfirst (guess|draft|version|reading|explanation|wording)\b|\bour (own )?(first|earlier|previous|old) (guess|reading|explanation|claim|sentence|wording|version|statement)\b|\b(earlier|previous|former|old) (draft|version|wording|claim|statement|sentence|reading|analysis|release|report)s?\b|\b(we|it) (once|previously|used to|had) (said|thought|claimed|believed|written|read)\b|\bused to (say|read|claim|be called)\b|\bformerly\b|\bpreviously\b|\bno longer (said|claimed|true|a mistake|stated)\b|\bto say what we said\b/i],
  ['P5 over-statement narrative', /\boverstate[sd]?\b|\boverclaim|\btoo strong\b|\bwe (had )?misread\b|\bwas (misread|misstated)\b|\bour (own )?(error|errors|slip|slips|mistake|mistakes)\b|\bmisinterpret/i],
  ['P6 version, date of a fix, round', /\bv(7|8|9)(\.\d+)?\b|\bv10(\.[01])?\b|\bv1\.[01]\b|\baudit round( [12])?\b|\bround (1|2|two|one)\b|\bsecond (round|pass)\b|\bchangelog\b|\bsince the last (report|release|version)\b|\bwhat('| i)s new\b|\bwork[- ]in[- ]progress\b/i],
  ['P8 the working of the package, told', /\bREADME_update_|\blane [A-D]\b|\brelabell?ed from\b|\boriginal (label|wording|sentence|text|claim|name)\b|\bfirst assumed\b|\bre-?worded\b|\bwe (have |had )?(replaced|renamed|rewrote|reworded)\b|\bhad been\b|\bhad to be (pulled|taken|split|set|separated|fixed|changed|replaced|rewritten)\b|\bfound (it |them |this )?late\b|\bmet on the way\b|\bnow (proved|proven|exists?|stands?|holds?|states|covers|includes?|carries|stated|written|shown|listed|given|a theorem|T\d+)\b|\band now\b|\(corrections?\b|\bafter an? (noted |small |one-line |written-down )?correction\b|\ba correction we (wrote|noted|made)\b|\bthe new (widget|report|reports|script|scripts|tab|tabs|chapter|chapters)\b|\b(older|previously known as|formerly called) (word|wording|term|name|text|sentence|label)\b|\bin (this|that|the|a) (working )?session\b|\b(this|the) (line|page|sentence|paragraph|text|README|brief|row) (said|called|read|claimed|stated|gave)\b|\bfound by an independent\b|\((first|second|third|fourth|fifth|sixth|seventh) note\b|\b(of|saw|see|under|uses?|used) version [1-9]\b(?![.\d])|\bversion [1-9] (of|gave|fixes)\b|\(version [1-9]:/i],
  ['P9 release number or date as a time word', /\b(up to|until|since|predates?|before|prior to|new in|added in|introduced in|fixed in|changed in|(?:as )?it did in|unchanged from) v?\d+\.\d+\.\d+\b|\bv1\.\d+|\bv1[12345]\.\d+|\b(in|since|new in|added in|changed in|of|for|after|before|from|than) v1[12345]\b/i],
  ['a date', /\b20\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b|\b\d{1,2} (January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\b|\b(January|February|March|April|May|June|July|August|September|October|November|December) (\d{1,2},? )?(19|20)\d\d\b/i],
];
const historyHits = body => HISTORY.filter(([, re]) => re.test(body)).map(([name, re]) => `${name}: “${body.match(re)[0]}”`);

// ---------------------------------------------------------------------------------------------------------------------------- R6, R7, R11 numbers
// Spans whose digits name something (they are not quantities the statement asserts); their numbers are not required in the learner text.
const MONTH = '(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)';
export const IDENTIFIERS = [
  ['script or file name', /[\w.-]+\.(?:py|mjs|js|jsx|json|md|txt|csv)\b/g],
  ['arXiv number', /\b(?:arXiv:?\s*)?\d{4}\.\d{4,5}(?:\s*v\d+)?\b/gi],
  ['date', new RegExp(`\\b\\d{1,2}\\s+${MONTH}\\b\\.?(?:\\s+\\d{4})?|\\b${MONTH}\\.?\\s+\\d{4}\\b|\\b\\d{4}-\\d{2}-\\d{2}\\b|\\b\\d{1,2}:\\d{2}\\b`, 'g')],
  ['year of a citation', /\(\s*(?:1[89]|20)\d\d\s*\)|,\s*(?:1[89]|20)\d\d\s*\)/g],
  ['row id', /\b[A-Z]{2,4}-\d{3}[a-z]?\b/g],
  ['check id', /\p{L}[\p{L}\d]*(?:·[\p{L}\d–-]+)+/gu],
  ['cell name', /Cl[⁰⁺⁻0]?\s*\([^()]*\)/g],
  ['cell address', /\[\s*\d+\s*,\s*[+−\-±]?\s*\d+\s*\]/g],
  ['group, algebra or binomial', /\b(?:so|su|sp|sl|gl|spin|pin|iso|u|o|e|g|SO|SU|Sp|SL|GL|PSL|Spin|Pin|U|O|M|C|R|W|End|Hom|Der|Aut|Sym)\s*\(\s*[^()]*\)/g],
  ['letter-and-digit name', /\b[A-Za-z]{1,3}\d+(?:\.\d+)*[a-z]?\b/g],
  ['polytope name', /[−-]?\d+[₀-₉]+/g],
  ['step, figure, equation or section number', /\b(?:[Ss]teps?|[Ss]tages?|[Cc]alibration|[Ff]ig\.?|[Ff]igures?|[Ee]qs?\.?|Algorithm|Theorem|Thm|Lemma|Table|[Ii]dea|[Pp]art|[Ww]arm-up)\s+\(?\d+(?:\.\d+)*\)?(?:\s*(?:,|and|to|–|-|or)\s*\(?\d+(?:\.\d+)*\)?)*/g],
  ['step number', /\bsteps?-\d+(?:\/\d+)?\b/g],
  ['equation number', /\(\s*\d+(?:\.\d+)?\s*\)(?:\s*[–-]\s*\(\s*\d+(?:\.\d+)?\s*\))?/g],
  ['digits under ^ or _', /[\^_]\s*(?:\{[^{}]*\}|\([^()]*\)|[−-]?[\p{L}\d.]+)/gu],
];
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹', SUB = '₀₁₂₃₄₅₆₇₈₉';
const scriptsToAscii = s => s.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+|[₀₁₂₃₄₅₆₇₈₉]+/g, m => ' ' + [...m].map(ch => (SUP.includes(ch) ? SUP.indexOf(ch) : SUB.indexOf(ch))).join('') + ' ');
export function stripIdentifiers(text) {
  let t = text;
  for (const [, re] of IDENTIFIERS) t = t.replace(re, ' ');
  return t;
}
const NUMBER = /(?<![\d.])\d+(?:\.\d+)?(?:e[-−+]?\d+)?(?![\d])/g;
const normNum = s => s.replace('−', '-').replace(/^0+(?=\d)/, '');
const isInt = s => /^\d+$/.test(s);
// LaTeX shorthand fractions (\tfrac12, \frac34, \dfrac12) are two one-digit numbers, not one two-digit number: read them as "1/2"
const FRAC_SHORT = /\\[dt]?frac\s*(\d)\s*(\d)/g;
export function numbersOf(text) { return [...String(text).replace(FRAC_SHORT, ' $1/$2 ').matchAll(NUMBER)].map(m => normNum(m[0])); }
/** the numbers of a research text that a translation keeps: integers ≥ 2 and every decimal or scientific number, outside identifiers */
export function requiredNumbers(research) {
  const out = new Set();
  for (const n of numbersOf(stripIdentifiers(research))) if (!isInt(n) || Number(n) >= 2) out.add(isInt(n) ? String(Number(n)) : n);
  return [...out].sort((a, b) => (isInt(a) && isInt(b) ? Number(a) - Number(b) : isInt(a) ? -1 : isInt(b) ? 1 : a < b ? -1 : 1));
}
const WORDS = {
  two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15,
  sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90,
  hundred: 100, thousand: 1000, second: 2, third: 3, fourth: 4, fifth: 5, sixth: 6, seventh: 7, eighth: 8, ninth: 9, tenth: 10, eleventh: 11, twelfth: 12,
  twentieth: 20, half: 2, halves: 2, halved: 2, twice: 2, double: 2, doubled: 2, doubles: 2, thrice: 3, triple: 3, quarter: 4, quarters: 4,
};
/** the numbers a learner text states: digits outside identifiers, and number words (twenty-four counts as 24) */
export function numbersIn(body) {
  const set = new Set(numbersOf(stripIdentifiers(body)).map(n => (isInt(n) ? String(Number(n)) : n)));
  const words = String(body).toLowerCase().match(/[a-z]+(?:-[a-z]+)?/g) || [];
  for (const w of words) {
    if (WORDS[w] != null) set.add(String(WORDS[w]));
    const [a, b] = w.split('-');
    if (b && WORDS[a] != null && WORDS[b] != null && WORDS[a] >= 20 && WORDS[a] % 10 === 0 && WORDS[b] < 10) set.add(String(WORDS[a] + WORDS[b]));
    if (b && WORDS[a] != null && WORDS[b] != null) { set.add(String(WORDS[a])); set.add(String(WORDS[b])); }
  }
  return set;
}
const missingNumbers = (research, body) => { const have = numbersIn(body); return requiredNumbers(research).filter(n => !have.has(n)); };
function newNumbers(research, body) {
  const allowed = new Set(numbersOf(scriptsToAscii(research)).map(n => (isInt(n) ? String(Number(n)) : n)));
  return [...new Set(numbersOf(stripIdentifiers(body)).map(n => (isInt(n) ? String(Number(n)) : n)))].filter(n => n !== '0' && n !== '1' && !allowed.has(n));
}

// ---------------------------------------------------------------------------------------------------------------------------- R8 status and scope words
// [name, what in the research text calls for it, what in the learner text answers it]
export const STATUS = [
  ['open', /\bopen\b/i, /\bopen\b/i],
  ['input', /\binputs?\b/i, /\binputs?\b/i],
  ['checked', /\bchecked\b/i, /\bcheck(ed|s|ing)?\b/i],
  ['conjecture', /\bconjectur/i, /\bconjectur/i],
  ['ours', /\bours\b|\bour (reading|interpretation|name|naming|phrase|translation|work|idea|choice)s?\b|\bof ours\b/i, /\bours\b|\bour (own )?(reading|interpretation|name|naming|phrase|translation|work|idea|way|choice|proposal|guess)s?\b/i],
  ['not proved', /\bnot (yet )?prov(ed|en)\b|\bunproved\b/i, /\bnot (yet )?prov(ed|en)\b|\bunproved\b/i],
  ['textbook / standard', /\btextbook\b|\bstandard\b/i, /\btextbook\b|\bstandard\b|\bwell[- ]known\b/i],
  ['exact', /\bexact(ly)?\b/i, /\bexact(ly)?\b/i],
  ['at points', /\bat (the )?(checked |rational |random |numeric |sample )?points\b/i, /\bpoints?\b/i],
  ['floats', /\bfloats?\b|\bfloating[- ]point\b|\bnumerically\b|\bnumpy\b/i, /\bfloat|\bfloating[- ]point\b|\bnumeric|\bnumpy\b/i],
  ['cited', /\bcited\b/i, /\bcited\b|\bquoted\b/i],
  ['recalled', /\brecalled\b/i, /\brecalled\b|\bfrom memory\b/i],
  ['unread', /\bunread\b|\bnot read\b/i, /\bunread\b|\bnot (been )?read\b|\bhave not read\b/i],
  ['untested', /\buntested\b|\bnot tested\b/i, /\buntested\b|\bnot tested\b/i],
  ['not checked', /\bnot checked\b/i, /\bnot checked\b|\bunchecked\b/i],
  ['not claimed', /\bnot claimed\b/i, /\bnot claimed\b|\bdo(es)? not claim\b|\bno claim\b/i],
  ['not derived', /\bnot derived\b/i, /\bnot derived\b|\bnot worked out\b/i],
  ['by hand', /\bplain-text derivation\b|\bhand derivation\b|\bnot a machine-checked proof\b/i, /\bby hand\b|\bin plain text\b|\bnot (a )?machine-checked\b/i],
  ['regression', /\bregression\b/i, /\bregression\b|\bguard\b/i],
  ['for every n', /\bfor (every|all|any) n\b/i, /\b(every|all|any) (number|n)\b|\bany size\b|\bevery size\b/i],
];
const missingStatus = (research, body) => STATUS.filter(([, inR, inL]) => inR.test(research) && !inL.test(body)).map(([name]) => name);

// ---------------------------------------------------------------------------------------------------------------------------- R10 terms
const CONTEXT_BOUND = new Set(['form', 'vertex', 'mode']);
const esc = t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const termRegexes = term => term.split(/\s*\/\s*/).map(v => v.trim()).filter(v => v.length >= 3).map(v => new RegExp(`(?<![\\p{L}\\p{N}])${esc(v)}(?![\\p{L}\\p{N}])`, 'iu'));
export const termOccurs = (term, body) => termRegexes(term).some(re => re.test(body));
/** the glossary terms a body uses: every term that occurs, the context-bound ones only when already listed */
export function termsIn(body, glossary, listed = []) {
  return glossary.map(g => g.term).filter(t => termOccurs(t, body) && (!CONTEXT_BOUND.has(t) || listed.includes(t)));
}

// ---------------------------------------------------------------------------------------------------------------------------- R12 names
const NAME_OK = new Set(['I', 'Cl', 'Standard', 'Model']); // the pronoun, the cell prefix, and "Standard Model", which names no authority
function newNames(body, sourceText) {
  const out = new Set();
  for (const m of body.matchAll(/(?<![\p{L}\p{N}’'])(\p{Lu}[\p{L}’'\-]*)/gu)) {
    const w = m[1].replace(/[’']s?$/, '').replace(/-$/, '');
    const before = body.slice(0, m.index).replace(/[\s“”"‘’()]+$/, '');
    if (!before || /[.!?:;]$/.test(before)) continue; // the first word of a sentence or of a clause after a colon
    if (NAME_OK.has(w) || w.length < 2) continue;
    const parts = w.split('-').filter(p => /^\p{Lu}/u.test(p));
    for (const p of parts) if (!new RegExp(`(?<![\\p{L}])${esc(p)}`, 'u').test(sourceText)) out.add(p);
  }
  return [...out];
}

// ---------------------------------------------------------------------------------------------------------------------------- R13 contact
const CONTACT = /\b[\w.+-]+@[\w-]+\.[\w.]+\b|https?:\/\/|www\.|\/home\/|\/tmp\/|\/opt\/|[A-Z]:\\|\.(py|mjs|jsx?|json|sh)\b/;

// ---------------------------------------------------------------------------------------------------------------------------- the tables
export function loadTables() {
  const rows = readJSON(path.join(C, 'rows.json'));
  const texts = readJSON(path.join(C, 'texts.json'));
  const glossary = readJSON(path.join(C, 'glossary.json'));
  const backlog = readJSON(path.join(C, 'learner_backlog.json'));
  const rowById = new Map(rows.map(r => [r.id, r]));
  const research = new Map(), humanLearner = new Set();
  for (const t of texts) {
    if (t.level === 'research' && t.lens == null && t.mode === 'both' && (t.register || 'full') === 'full') research.set(t.row, t.body);
    if (t.level === 'learner' && t.lens == null && t.status === 'human') humanLearner.add(t.row);
  }
  const pageOf = new Map();
  for (const [grp, secs] of Object.entries(backlog)) for (const [sec, ids] of Object.entries(secs)) for (const id of ids) pageOf.set(id, { group: grp, section: sec });
  return { rows, rowById, research, humanLearner, glossary, backlog, pageOf };
}
export const SOURCE = 'translator:learner@2026-10-10';
/** the two derived fields of a record, from its body and its row's research text */
export function deriveFields(rec, T) {
  const research = T.research.get(rec.row) || '';
  return { termsUsed: termsIn(rec.body || '', T.glossary, rec.termsUsed || []), keptNumbers: requiredNumbers(research) };
}

// ---------------------------------------------------------------------------------------------------------------------------- the check
const KEYS = ['row', 'lang', 'mode', 'level', 'lens', 'register', 'body', 'status', 'source', 'termsUsed', 'keptNumbers'];
export const RULES = {
  R1: 'shape', R2: 'row', R3: 'duplicate', R4: 'formula', R5: 'history', R6: 'numbers', R7: 'new number', R8: 'status',
  R9: 'length', R10: 'terms', R11: 'kept', R12: 'names', R13: 'contact',
};
export function check(records, T) {
  const fails = [];
  const F = (rule, row, msg) => fails.push({ rule, row, msg });
  if (!Array.isArray(records)) { F('R1', '—', 'the file is not an array'); return fails; }
  const glossaryTerms = new Set(T.glossary.map(g => g.term));
  const seen = new Set();
  for (const [i, r] of records.entries()) {
    const id = r && typeof r.row === 'string' ? r.row : `#${i}`;
    if (!r || typeof r !== 'object' || Array.isArray(r)) { F('R1', id, 'not an object'); continue; }
    const keys = Object.keys(r);
    const missing = KEYS.filter(k => !keys.includes(k)), extra = keys.filter(k => !KEYS.includes(k));
    if (missing.length) F('R1', id, `missing key(s): ${missing.join(', ')}`);
    if (extra.length) F('R1', id, `unknown key(s): ${extra.join(', ')}`);
    if (r.lang !== 'en') F('R1', id, `lang is ${JSON.stringify(r.lang)}, not "en"`);
    if (r.mode !== 'both') F('R1', id, `mode is ${JSON.stringify(r.mode)}, not "both"`);
    if (r.level !== 'learner') F('R1', id, `level is ${JSON.stringify(r.level)}, not "learner"`);
    if (r.lens !== null) F('R1', id, `lens is ${JSON.stringify(r.lens)}, not null`);
    if (r.register !== 'full' && r.register !== 'short') F('R1', id, `register is ${JSON.stringify(r.register)}, not "full" or "short"`);
    if (r.status !== 'draft' && r.status !== 'reviewed') F('R1', id, `status is ${JSON.stringify(r.status)}, not "draft" or "reviewed"`);
    if (typeof r.source !== 'string' || !/^translator:(learner|story)@/.test(r.source)) F('R1', id, `source is ${JSON.stringify(r.source)}, not "translator:learner@…" or "translator:story@…"`);
    if (typeof r.body !== 'string' || !r.body.trim()) { F('R1', id, 'body is empty or not a string'); continue; }
    if (r.body !== r.body.trim() || /\s{2,}|\n/.test(r.body)) F('R1', id, 'body has leading, trailing, doubled or line-break whitespace');
    if (!Array.isArray(r.termsUsed) || r.termsUsed.some(x => typeof x !== 'string')) F('R1', id, 'termsUsed is not a list of strings');
    if (!Array.isArray(r.keptNumbers) || r.keptNumbers.some(x => typeof x !== 'string')) F('R1', id, 'keptNumbers is not a list of strings');
    const key = [r.row, r.mode, r.level, r.lens, r.register].join('|');
    if (seen.has(key)) F('R3', id, 'a second record with the same (row, mode, level, lens, register)');
    seen.add(key);
    const row = T.rowById.get(r.row);
    const research = T.research.get(r.row);
    if (!row) { F('R2', id, 'no such row in content/rows.json'); continue; }
    if (!research) { F('R2', id, 'the row has no research text (level research, lens null, mode both)'); continue; }
    if (T.humanLearner.has(r.row) && (r.register || 'full') === 'full') F('R2', id, 'the row has a human learner text in texts.json: the merge keeps it, so this draft would never ship');
    const body = r.body;
    for (const h of formulaHits(body)) F('R4', id, h);
    for (const h of historyHits(body)) F('R5', id, h);
    const isShort = r.register === 'short';
    const miss = isShort ? [] : missingNumbers(research, body);
    if (miss.length) F('R6', id, `number(s) of the research text missing: ${miss.join(', ')}`);
    const neu = newNumbers(research, body);
    if (neu.length) F('R7', id, `number(s) in digits that the research text does not have: ${neu.join(', ')}`);
    const st = missingStatus(research, body);
    if (st.length) F('R8', id, `status or scope word(s) of the research text missing: ${st.join(', ')}`);
    if (isShort) { if (body.length < 20 || body.length > 200) F('R9', id, `${body.length} characters (short register: 20 to 200)`); }
    else { const lim = Math.max(900, Math.ceil(1.5 * research.length)); if (body.length < 40 || body.length > lim) F('R9', id, `${body.length} characters (40 to ${lim}: 900, or 1.5 × the research text when that is longer)`); }
    if (Array.isArray(r.termsUsed)) {
      for (const t of r.termsUsed) {
        if (!glossaryTerms.has(t)) F('R10', id, `termsUsed has “${t}”, not a glossary term`);
        else if (!termOccurs(t, body)) F('R10', id, `termsUsed has “${t}”, which the body does not use`);
      }
      const want = termsIn(body, T.glossary, r.termsUsed);
      const unlisted = want.filter(t => !r.termsUsed.includes(t));
      if (unlisted.length) F('R10', id, `glossary term(s) in the body but not in termsUsed: ${unlisted.join(', ')}`);
    }
    if (Array.isArray(r.keptNumbers)) {
      const want = requiredNumbers(research);
      const a = [...new Set(r.keptNumbers)].sort().join(' '), b = [...want].sort().join(' ');
      if (a !== b || r.keptNumbers.length !== want.length) F('R11', id, `keptNumbers is [${r.keptNumbers.join(', ')}], the research text asks for [${want.join(', ')}]`);
    }
    const parent = row.splitFrom ? (T.research.get(row.splitFrom) || '') : '';
    const names = newNames(body, `${research}\n${parent}`);
    if (names.length) F('R12', id, `name(s) not in the research text: ${names.join(', ')}`);
    const c = body.match(CONTACT);
    if (c) F('R13', id, `contact detail, link, script name or path: “${c[0]}”`);
  }
  return fails;
}

// ---------------------------------------------------------------------------------------------------------------------------- self-test
// A test of the test, run before every check: on a synthetic row (not the content, so an edit of the content cannot break it), one good
// record must pass every rule and one planted record per rule must be caught by that rule.
export function selftest() {
  const research = 'Checked exactly at points: the value 210 is open, and Cl(1,3) has 16 parts (step 4; core·B3); reading it as a mirror is ours.';
  const T = {
    rowById: new Map([['TST-001', { id: 'TST-001', splitFrom: null }], ['TST-002', { id: 'TST-002', splitFrom: null }]]),
    research: new Map([['TST-001', research], ['TST-002', research]]),
    humanLearner: new Set(['TST-002']),
    glossary: [{ term: 'mirror' }, { term: 'form' }],
  };
  const good = { row: 'TST-001', lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full',
    body: 'Checked exactly at points: the number 210 is open, and the cell Cl(1,3) has 16 parts. Reading it as a mirror is ours.',
    status: 'draft', source: SOURCE, termsUsed: ['mirror'], keptNumbers: ['16', '210'] };
  const plant = (rule, patch) => [rule, { ...good, ...patch }];
  const PLANTS = [
    plant('R1', { status: 'human' }),
    plant('R1', { source: 'translator:storyline@2026-10-12' }),
    plant('R2', { row: 'TST-404' }),
    plant('R2', { row: 'TST-002' }),
    plant('R4', { body: good.body.replace('16 parts', 'n parts, with $x$ as 16') }),
    plant('R4', { body: good.body.replace('the number 210', 'the number α, 210,') }),
    plant('R5', { body: good.body.replace('is open', 'is open; this was corrected') }),
    plant('R5', { body: good.body.replace('is open', 'is open since 9 October 2026') }),
    plant('R6', { body: good.body.replace('the number 210 ', 'that number ') }),
    plant('R7', { body: good.body.replace('16 parts', '16 parts and 999 more') }),
    plant('R8', { body: good.body.replace(' is open,', ',') }),
    plant('R9', { body: 'Checked exactly at points: 210, 16, open, ours.'.slice(0, 30) }),
    plant('R10', { termsUsed: ['mirror', 'flux'] }),
    plant('R10', { termsUsed: [] }),
    plant('R11', { keptNumbers: ['16'] }),
    plant('R12', { body: good.body.replace('Reading it as a mirror', 'Reading it, as Einstein did, as a mirror') }),
    plant('R13', { body: good.body.replace('16 parts.', '16 parts (see check_x.py).') }),
  ];
  const bad = [];
  const g = check([good], T);
  if (g.length) bad.push(`the good record fails: ${g.map(f => `${f.rule} ${f.msg}`).join('; ')}`);
  if (check([{ ...good, source: 'translator:story@2026-10-12' }], T).length) bad.push('the good record with the story source fails');
  for (const [rule, rec] of PLANTS) if (!check([rec], T).some(f => f.rule === rule)) bad.push(`a planted ${rule} (${RULES[rule]}) record is not caught`);
  if (!check([good, good], T).some(f => f.rule === 'R3')) bad.push('a planted R3 (duplicate) pair is not caught');
  return bad;
}

// ---------------------------------------------------------------------------------------------------------------------------- main
function main(argv) {
  const arg = k => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
  const st = selftest();
  if (st.length) { console.log(`check_learner_texts: SELF-TEST FAILED\n  ${st.join('\n  ')}`); return 2; }
  const T = loadTables();
  const explain = arg('--explain');
  if (explain) {
    const research = T.research.get(explain);
    if (!research) { console.log(`${explain}: no research text`); return 1; }
    console.log(`${explain} research text (${research.length} characters):\n  ${research}\n`);
    console.log(`numbers to keep: ${requiredNumbers(research).join(', ') || '(none)'}`);
    console.log(`status and scope words to keep: ${STATUS.filter(([, inR]) => inR.test(research)).map(([n]) => n).join(', ') || '(none)'}`);
    console.log(`identifiers whose numbers are not required: ${IDENTIFIERS.flatMap(([name, re]) => (research.match(re) || []).map(m => `${m.trim()} (${name})`)).join('; ') || '(none)'}`);
    return 0;
  }
  // --file <one file>; by default every content/texts_learner*.json (sorted), checked together so that R3 catches a row drafted twice
  const files = arg('--file') ? [path.resolve(arg('--file'))] : fs.readdirSync(C).filter(n => /^texts_learner.*\.json$/.test(n)).sort().map(n => path.join(C, n));
  if (!files.length || files.some(f => !fs.existsSync(f))) { console.log(`check_learner_texts: no content/texts_learner*.json file`); return 1; }
  const file = files.length === 1 ? files[0] : path.join(C, 'texts_learner*.json');
  let records = [];
  for (const f of files) {
    let recs = readJSON(f);
    if (argv.includes('--fix') && Array.isArray(recs)) {
      recs = recs.map(r => ({ ...r, ...deriveFields(r, T) }));
      fs.writeFileSync(f, JSON.stringify(recs, null, 1) + '\n');
      console.log(`--fix: termsUsed and keptNumbers recomputed for ${recs.length} records in ${path.relative(ROOT, f)}`);
    }
    if (!Array.isArray(recs)) { console.log(`check_learner_texts: ${path.relative(ROOT, f)} is not an array`); return 1; }
    records = records.concat(recs);
  }
  const fails = check(records, T);
  const n = Array.isArray(records) ? records.length : 0;
  const byPage = {};
  for (const r of Array.isArray(records) ? records : []) { const g = (T.pageOf.get(r.row) || { group: '(not in the backlog)' }).group; byPage[g] = (byPage[g] || 0) + 1; }
  console.log(`check_learner_texts: ${n} records in ${path.relative(ROOT, file)} (${Object.entries(byPage).map(([k, v]) => `${k} ${v}`).join(', ')})`);
  if (!fails.length) { console.log(`PASS: all ${Object.keys(RULES).length} rules hold for every record`); return 0; }
  const by = {};
  for (const f of fails) (by[f.rule] ||= []).push(f);
  console.log(`\nFAIL: ${fails.length} failure(s) in ${new Set(fails.map(f => f.row)).size} record(s)\n`);
  console.log('rule  name         failures  rows');
  for (const k of Object.keys(RULES)) if (by[k]) console.log(`${k.padEnd(5)} ${RULES[k].padEnd(12)} ${String(by[k].length).padStart(8)}  ${[...new Set(by[k].map(f => f.row))].slice(0, 8).join(', ')}${new Set(by[k].map(f => f.row)).size > 8 ? ', …' : ''}`);
  console.log('');
  for (const k of Object.keys(RULES)) for (const f of by[k] || []) console.log(`${f.rule} ${f.row}: ${f.msg}`);
  return 1;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) process.exit(main(process.argv.slice(2)));
