#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// build_content.mjs — validates content/ (02_CONTENT_MODEL.md §10), computes status/address/neighbours (§4, §9), writes content/derived/*.json and docs/COVERAGE.md.
// Status: the v15 rows by their legacy flags and evidence; a row without v15 flags by 02 §4 (D22: proved-by-atlas when a ran check has a recorded
// run that passed); the badge "new" for since v16, v2.1 and v2.2. A narration row (kind story, docs/STORY_PLAN.md §1.6) is meta: no badge, never new,
// nobody's neighbour.
// Usage: node tools/build_content.mjs   (exit 1 on a validation error; the errors are printed with record ids)
import fs from 'node:fs'; import path from 'node:path';
const C = path.resolve('content'); const J = n => JSON.parse(fs.readFileSync(path.join(C, n), 'utf8'));
const rows = J('rows.json'), texts = J('texts.json'), pages = J('pages.json'), checks = J('checks.json'), runs = J('check_runs.json'), lenses = J('lenses.json'), figures = J('figures.json'), theorems = J('theorems.json'), questions = J('questions.json');
const NOTIONS = ['lbl','sgn','sq','grd','qf','clk','mir','nul','tns','mod','biv','cnx','var','sol','lat','fin','div','dyn','s-alg','s-geo','s-phy','s-cat','src','i-chart','i-time','i-J','i-act','i-tab','i-meta'];
const PRIMES = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109];
const SQ = n => n.startsWith('i-') ? 0 : (n.startsWith('s-') || n === 'src') ? -1 : 1;
const KINDS = new Set(['definition','construction','lemma','theorem','range','classification','invariant','example','counterexample','computation','reduction','reading','conjecture','question','dead-end','pointer','meta','story']);
const STAGES = new Set('AKFDOM'); const PTYPES = new Set(['postulate','definition','derivation','identity','solution','limit','symmetry','observable','calibration','reading','open','negative']);
const RELS = new Set(['derives','equiv','instance','uses-input','cycle','contradicts','restates']); // restates: a story row names the rows whose numbers and formulas it repeats
const ROLES = new Set(['result','detail','evidence','lead','caption','learner','next','note']);     // the roles of a placement (STORY_PLAN §1.3; note: a page top's notes, round 7); the sections intro and top-notes are reserved
const errs = [], warns = [];
const E = (id, m) => errs.push(`${id}: ${m}`), Wn = (id, m) => warns.push(`${id}: ${m}`);

// ---- 1. validation -------------------------------------------------------------------------------------------------
const ids = new Set(); for (const r of rows) { if (ids.has(r.id)) E(r.id, 'duplicate id'); ids.add(r.id); }
const thm = new Set(theorems.map(t => t.id)), qs = new Set(questions.map(q => q.id)), pageRoutes = new Set(pages.map(p => p.route)), lensKeys = new Set(lenses.map(l => l.key));
const checkIds = new Set(); for (const c of checks) { if (c.script) checkIds.add(path.basename(c.script).replace(/\.(py|mjs)$/, '')); for (const i of (c.ids || [])) checkIds.add(i.id); }
const lastRun = {}; for (const r of runs) if (r.script) { const k = r.script; if (!lastRun[k] || r.date >= lastRun[k].date) lastRun[k] = r; }
const runOf = s => { const k = s && (s.startsWith('checks/') ? s : 'checks/' + s.replace(/^(selfcheck|researchers_checks)/, '$1')); return lastRun[k] || Object.values(lastRun).find(x => x.script.endsWith('/' + path.basename(s || ''))) || null; };
const passedScript = s => { const r = runOf(s); return r ? r.passed !== false : null; };
// rows without v15 flags (the rows added after the migration, since "v2.1"): status by 02 §4 (D22) — a recorded run that passed with no failure
const runPassed = s => { const r = runOf(s); return !!r && r.passed !== false && !(Number(r.fail) > 0); };
const standardRead = ref => typeof ref === 'string' && ref.trim() !== '' && !/\bunread\b|\bnot read\b|\bpointer\b/i.test(ref);
function statusWithoutFlags(r, q) {
  const ev = r.evidence || [], ranE = ev.filter(e => e.mode === 'ran');
  if (['question', 'conjecture', 'pointer'].includes(r.kind) || r.ptype === 'open') return 'open';   // a dead-end or counterexample is not open (D3)
  if (ranE.some(e => runPassed(e.script || e.check))) return 'proved-by-atlas';
  if (ranE.length || (ev.length && ev.every(e => e.mode === 'read'))) return 'cited';                   // a failing or missing run, or read only
  if (r.kind === 'reading' || r.ptype === 'reading') return 'ours';
  if (r.group === 'INP') return 'input';
  if (q > 0 && standardRead(r.standardRef)) return 'standard';
  return 'ours';
}
const NEW_SINCE = new Set(['v16', 'v2.1', 'v2.2', 'v2.4', 'v2.4.2', 'v2.4.3', 'v2.5', 'v2.6', 'v2.7', 'v2.8']); // the rows that carry the badge "new" (D22; v2.2: the rows of the translation matrices, D35; v2.4: the rows of the leaves of round 7, wave 2; v2.4.2: the rows the proofs round adds)
const researchText = {}, learnerText = {};
for (const t of texts) { if (!ids.has(t.row)) E(t.row, 'text for an unknown row'); if (t.level === 'research' && t.lens === null && t.mode === 'both') researchText[t.row] = t; if (t.level === 'learner' && t.lens === null) learnerText[t.row] = t;
  if (t.level === 'learner') { if (/\$|\\\(|\\\[/.test(t.body)) E(t.row, 'learner text contains a formula marker'); if (/[α-ωΑ-Ω]/.test(t.body)) Wn(t.row, 'learner text uses a Greek letter'); if (/[A-Za-z_]\w*\s*=\s*[A-Za-z_(]/.test(t.body)) Wn(t.row, 'learner text has a symbolic equation'); }
  if (t.lens !== null && !lensKeys.has(t.lens)) E(t.row, `text for an unknown lens ${t.lens}`); }
for (const r of rows) {
  if (r.notions) { for (const n of r.notions) if (!NOTIONS.includes(n)) E(r.id, `unknown notion ${n}`); if (!r.notions.length) E(r.id, 'empty notions'); }
  if (r.kind && !KINDS.has(r.kind)) E(r.id, `bad kind ${r.kind}`); if (r.stage && !STAGES.has(r.stage)) E(r.id, `bad stage ${r.stage}`); if (r.ptype && !PTYPES.has(r.ptype)) E(r.id, `bad ptype ${r.ptype}`);
  for (const d of r.depends || []) { if (!RELS.has(d.rel)) E(r.id, `bad relation ${d.rel}`); if (!(ids.has(d.id) || thm.has(d.id) || qs.has(d.id) || ids.has(d.id.replace(/[a-z]$/, '')))) Wn(r.id, `dependency on unknown ${d.id}`); }
  for (const e of r.evidence || []) { const ok = checkIds.has(e.check) || (e.script && checkIds.has(path.basename(e.script).replace(/\.(py|mjs)$/, ''))); if (!ok) Wn(r.id, `evidence not in checks.json: ${e.check} ${e.script || ''}`); }
  for (const s of r.shownOn || []) { if (!pageRoutes.has(s.page)) E(r.id, `shownOn unknown page ${s.page}`); if (s.role != null && !ROLES.has(s.role)) E(r.id, `shownOn role ${s.role}`); }
  if (!researchText[r.id]) E(r.id, 'no research text');
}
for (const f of figures) { if (f.captionRow && !ids.has(f.captionRow)) E(f.id, `captionRow ${f.captionRow} unknown`); for (const l of f.lenses) if (!lensKeys.has(l)) E(f.id, `unknown lens ${l}`); }
const CONTACT = /\b[\w.+-]+@[\w-]+\.[\w.]+\b|\/home\/\w+|C:\\\\/; for (const t of texts) if (CONTACT.test(t.body)) E(t.row, 'contact detail or machine path in a text');

// ---- 2. status, address, neighbours -------------------------------------------------------------------------------------
const derived = {}; const byMask = {};
for (const r of rows) {
  const notions = r.notions || []; const p = notions.filter(n => SQ(n) === 1).length, q = notions.filter(n => SQ(n) === -1).length, rr = notions.filter(n => SQ(n) === 0).length;
  const mask = notions.reduce((m, n) => m | (1 << NOTIONS.indexOf(n)), 0); let prime = 1n; for (const n of notions) prime *= BigInt(PRIMES[NOTIONS.indexOf(n)]);
  const flags = new Set(r.legacyFlags || []);
  const ran = (r.evidence || []).filter(e => e.mode === 'ran'); const ranPassed = ran.some(e => runPassed(e.script || e.check));   // strict (round 7): a recorded run that passed, never a missing one
  const readOnly = (r.evidence || []).length > 0 && (r.evidence || []).every(e => e.mode === 'read');
  let status;
  const story = r.kind === 'story';
  if (story || r.kind === 'meta' || (notions.length === 1 && notions[0] === 'i-meta') || r.legacyLabel === 'note') status = 'meta';
  else if (r.id.startsWith('CAND-')) status = (ran.length && ranPassed) ? 'proved-by-atlas' : 'candidate';   // a candidate that became a row: proved by the check that decided it, else still a candidate
  else if (!flags.size) status = statusWithoutFlags(r, q);
  else if (['question', 'conjecture', 'pointer'].includes(r.kind) || r.ptype === 'open' || (flags.has('open') && !flags.has('checked') && !flags.has('standard') && !['dead-end', 'counterexample'].includes(r.kind))) status = 'open';
  else if (flags.has('checked') && ran.length && ranPassed) status = 'proved-by-atlas';
  else if (flags.has('checked') && (readOnly || !ran.length)) status = 'cited';
  else if (r.kind === 'reading' || r.ptype === 'reading' || r.legacyLabel === 'reading') status = 'ours';
  else if (r.group === 'INP' || (rr > 0 && flags.has('input') && !flags.has('checked'))) status = 'input';
  else if (flags.has('standard')) status = 'standard';
  else if (flags.has('ours')) status = 'ours';
  else if (flags.has('open')) status = 'open';
  else status = 'ours';
  const badge = story ? null : status === 'open' ? 'open' : status === 'cited' ? 'not yet proved here' : status === 'ours' ? 'our reading' : status === 'input' ? `needs an input${r.inputKindName ? ': ' + r.inputKindName : ''}` : (NEW_SINCE.has(r.since) ? 'new' : null);
  derived[r.id] = { status, new: !story && NEW_SINCE.has(r.since), badge, signature: [p, q, rr], grade: notions.length, mask, prime: prime.toString(), address: `${(r.cells && r.cells[0]) || '—'} · (${p},${q},${rr}) · ${r.stage || '?'}/${r.kind || '?'} · ${prime}`, flagsLegacy: [...flags], openAlso: flags.has('open') && status !== 'open' };
  if (notions.length && !story) (byMask[mask] ||= []).push(r.id);   // a story row is nobody's neighbour
}
for (const r of rows) { const d = derived[r.id]; if (!d.grade || r.kind === 'story') { d.neighbours = []; continue; } const n = []; for (let i = 0; i < NOTIONS.length; i++) n.push(...(byMask[d.mask ^ (1 << i)] || [])); d.neighbours = n.filter(x => x !== r.id).slice(0, 40); }
fs.mkdirSync(path.join(C, 'derived'), { recursive: true });
fs.writeFileSync(path.join(C, 'derived', 'status.json'), JSON.stringify(derived, null, 1));

// ---- 3. coverage report ---------------------------------------------------------------------------------------------------
const cnt = a => a.reduce((m, x) => { m[x] = (m[x] || 0) + 1; return m; }, {});
const statuses = cnt(rows.map(r => derived[r.id].status));
const byPage = {}; for (const r of rows) for (const s of r.shownOn) { const b = (byPage[s.page] ||= { rows: 0, results: 0, badges: 0, learner: 0, cited: 0, open: 0, ours: 0, input: 0, new: 0, heroLearner: false }); b.rows++; if (s.role === 'result') b.results++; const d = derived[r.id]; if (d.badge && s.role === 'result') b.badges++; if (learnerText[r.id]) b.learner++; if (d.status === 'cited') b.cited++; if (d.status === 'open') b.open++; if (d.status === 'ours') b.ours++; if (d.status === 'input') b.input++; if (d.new) b.new++; }
for (const p of pages) if (p.hero && p.hero.row && byPage[p.route]) byPage[p.route].heroLearner = !!learnerText[p.hero.row];
const drafts = texts.filter(t => t.status === 'draft').length;
const lines = [];
lines.push(`# Coverage report (generated by tools/build_content.mjs)\n`, `Rows: ${rows.length} (v15 ids ${rows.filter(r => !r.splitFrom).length}, split lines ${rows.filter(r => r.splitFrom).length}); research texts ${Object.keys(researchText).length}; learner texts ${Object.keys(learnerText).length}; draft texts ${drafts}; rows labelled ${rows.filter(r => r.notions).length}; validation errors ${errs.length}, warnings ${warns.length}.\n`);
lines.push('## Status (computed)\n' + Object.entries(statuses).sort((a, b) => b[1] - a[1]).map(([k, v]) => `- ${k}: ${v}`).join('\n') + '\n');
lines.push('## Pages\n| page | rows | results | badges on results | learner texts | hero has learner text | cited | open | ours | input | new |\n|---|---|---|---|---|---|---|---|---|---|---|\n' + Object.entries(byPage).sort().map(([k, b]) => `| ${k || '/'} | ${b.rows} | ${b.results} | ${b.badges} | ${b.learner} | ${b.heroLearner ? 'yes' : 'no'} | ${b.cited} | ${b.open} | ${b.ours} | ${b.input} | ${b.new} |`).join('\n') + '\n');
lines.push('## Rows not yet proved here (status cited)\n' + rows.filter(r => derived[r.id].status === 'cited').map(r => `- ${r.id}: ${(r.evidence || []).map(e => e.script || e.check).join(', ')}`).join('\n') + '\n');
lines.push('## Review notes from the labelling (the judge and the personas)\n' + rows.filter(r => r.review).map(r => `- ${r.id}: ${r.review}`).join('\n') + '\n');
lines.push('## Rows the v16 leads change (badge new)\n' + rows.filter(r => r.since === 'v16').map(r => `- ${r.id}${r.mergeNeeded ? ' (merge needed)' : ''}`).join('\n') + '\n');
lines.push(`## Validation\n${errs.length ? errs.slice(0, 80).map(e => '- ERROR ' + e).join('\n') : '- no errors'}\n${warns.length ? '\n' + warns.slice(0, 40).map(w => '- warning ' + w).join('\n') + (warns.length > 40 ? `\n- … ${warns.length - 40} more warnings` : '') : ''}\n`);
fs.mkdirSync('docs', { recursive: true }); fs.writeFileSync(path.join('docs', 'COVERAGE.md'), lines.join('\n'));
console.log(lines.slice(0, 3).join('\n')); console.log(`errors ${errs.length}, warnings ${warns.length}; see docs/COVERAGE.md`);
if (errs.length) { console.log(errs.slice(0, 30).join('\n')); process.exit(1); }
