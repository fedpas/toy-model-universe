#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// verify_counts.mjs — the numbers of 03_MIGRATION.md §2.9 and of the story round (STORY_PLAN §3.5); exit 1 when one differs.
import fs from 'node:fs';
const c = JSON.parse(fs.readFileSync('content/MIGRATION_COUNTS.json', 'utf8'));
const expect = { 'rows.v15Rows': 789, 'rows.v15Lines': 1045, 'rows.researchTexts': c.rows.rows, 'tables.theorems': 20, 'tables.questions': 34, 'tables.answered': 15, 'tables.sources': 26, 'tables.matrixRows': 131, 'tables.matrixColumns': 22, 'tables.matrixCells': 246, 'tables.lensRows': 80, 'tables.readings': 982, 'tables.mapNodes': 63, 'tables.steps': 23, 'tables.glossary': 16, 'tables.reports': 6, 'tables.analyses': 16, 'inputs.inputs': 94, 'inputs.tabs': 31, 'inputs.kinds': 11, 'inputs.unjoined': 0, 'checks.v15Scripts': 236, 'checks.wave3Scripts': 14, 'checks.checks': 250, 'checks.gravityRows': 69, 'checks.gravityOk': 5569, 'checks.gravityFail': 0, 'checks.wave3Ok': 1342, 'checks.wave3Fail': 0, 'checks.bridgeIds': 348, 'leads.leads': 8, 'leads.rowsReworded': 26, 'pages.unplaced': 1,
  // the story round (docs/STORY_PLAN.md §3.5; tools/migrate/story_from_v15.mjs, tools/merge_story.mjs): the v15 strings and blocks, the layout, the
  // learner texts (pins after the 386 review choices of round 7: same-as and drop move blocks between the classes); the outcomes of the test as sums that a choice of content/story/review.json moves between story, held and proposed but never changes
  'story.stringsWalked': 11625, 'story.proseBlocks': 3169, 'story.uniqueBlocks': 3136, 'story.blocks.rows': 1124, 'story.blocks.tables': 426, 'story.blocks.frames': 114,
  'story.blocks.missing': 1586, 'story.blocks.leftOut': 573, 'story.blocks.labels': 39, 'story.blocks.learnerStrips': 348, 'story.blocks.research': 610, 'story.blocks.findingTitles': 16,
  'story.blocks.story': 571 - ((c.story || {}).blocks || {}).held - ((c.story || {}).blocks || {}).statements, 'story.storyRows': ((c.story || {}).blocks || {}).story + (c.story || {}).learnerOnlyRows + ((c.story || {}).shortLeads || {}).story + ((c.story || {}).tableLeads || {}).story,
  'story.layout': 931, 'story.layoutByRole.learner': 81, 'story.humanLearnerTexts.chapterLearnerLines': 81, 'story.humanLearnerTexts.existingRowsPaired': 63, 'story.ids': 858,   // 12 learner lines are details (readings and questions that stood as key results at learner level; docs/round8/PROOFS_ROUND4.md): their learner texts pair with their rows
  'storyMerge.storyRows': (c.story || {}).storyRows, 'storyMerge.layout': 956 };   // 931 of layout.json + 25 of content/story/furey.json (round 7, FUREY; + FUR-006 and CAND-102 of the proofs round, + CAND-049)
let bad = 0;
for (const [k, v] of Object.entries(expect)) { const got = k.split('.').reduce((o, p) => (o || {})[p], c); const ok = got === v; if (!ok) bad++; console.log(`${ok ? 'ok  ' : 'FAIL'} ${k} = ${got} (expected ${v})`); }
console.log(bad ? `${bad} counts differ` : 'all counts as expected'); process.exit(bad ? 1 : 0);
