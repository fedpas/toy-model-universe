#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/export_tuning.mjs — the Atlas as a tuning set (BUILD_CONTRACTS interface 39, docs/round7/AI_TUNING.md). One record per statement, with its
// words, its label (the bit rule), the known law it states, the checks that ran on it (with their last recorded run), what it rests on, and how the
// lenses read it; written at every build (build.sh, after build_chunks.mjs) to dist/content/tuning/:
//   rows.jsonl      one JSON object per line, one per row of content/rows.json after the merges, in id order; the keys are those of
//                   content/tuning/schema.json (#/definitions/row), in its order: the row's own fields, the label as bits / mask / signature / grade /
//                   prime / address (content/derived/status.json, checked here against the notions), status and badge, every text of texts.json
//                   (the body as it is), the evidence resolved to its check script and the last recorded run of that script (the Logbook's rule:
//                   src/logbook/registerModel.js), the dependencies typed by what they name, the lens readings of lens_readings.json
//   lenses.json     the registry of lenses with their dictionaries (content/lenses.json, by key)
//   checks.json     the check scripts, each with its last recorded run and its run count (content/checks.json, content/check_runs.json)
//   runs.json       every recorded run, by script and day
//   theorems.json   T1–T20, and questions.json the author's questions: the nodes a dependency can name besides a row
//   schema.json     the formats, the 29 notions, the status values and the roles of the loop (content/tuning/schema.json, as it is)
//   manifest.json   the versions of the build, the counts, and the size and sha256 of each file
//   README.md       the loop, the fields, the guide's rules (content/persona_rules.md), how to cite: content/tuning/README.md with its blocks written
//                   from the tables
// Also written, for the page #/agents when the site is opened from file:// (the build's table twins): schema.js and manifest.js.
// The output depends on the tables and on the two versions only: the same content gives the same bytes. No machine path, no contact detail, no clock.
// Two defects of the tables are normalised, not copied: a check whose `ids` list holds the characters of a printed note (its script prints no list of
// ids) is exported with ids [] and the note as idsNote; the count is in manifest.counts. Defects that only the tables can mend are returned as
// warnings (a script named by two check records, a run whose script no check names, an evidence entry tied to no script).
// Usage: node tools/export_tuning.mjs [outDir=dist]     (exit 1 when a table is incoherent: an unknown notion, a mask that disagrees with its notions, …)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { parsePersonaRules } from '../src/app/personaRules.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const FILE_NAMES = ['rows.jsonl', 'lenses.json', 'checks.json', 'runs.json', 'theorems.json', 'questions.json', 'schema.json', 'manifest.json', 'README.md'];
const GLOBAL = '__ONE_RULE_CONTENT__';
const LICENCE_HEADER = [
  '<!--',
  'SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0',
  'Required Notice: Copyright (c) 2026 the Cascade Atlas authors',
  'Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)',
  '-->',
  '',
].join('\n');

const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
/** ids with a number compare by prefix, then by the number (T2 before T10); others by code point */
const natural = (a, b) => {
  const x = /^(\D*)(\d+)(.*)$/s.exec(a), y = /^(\D*)(\d+)(.*)$/s.exec(b);
  return x && y && x[1] === y[1] ? (Number(x[2]) - Number(y[2])) || cmp(x[3], y[3]) : cmp(a, b);
};
const clone = v => JSON.parse(JSON.stringify(v));
const sha256 = s => crypto.createHash('sha256').update(s, 'utf8').digest('hex');
const LINE_BREAKS = new RegExp('[' + String.fromCharCode(0x2028, 0x2029, 0x85) + ']', 'g'); // valid in JSON, but a line reader that splits on them would cut a record
const jsonLine = o => JSON.stringify(o).replace(LINE_BREAKS, c => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
const stripExt = s => s.replace(/\.(py|mjs|js|sh|html)$/, '');

// ---------------------------------------------------------------- the tables
/** the tables the export reads, from a repository root: content/ (after the merges), the version of package.json, the template of the README */
export function readTables(root = ROOT) {
  const C = path.join(root, 'content');
  const J = f => JSON.parse(fs.readFileSync(path.join(C, f), 'utf8'));
  return {
    rows: J('rows.json'), texts: J('texts.json'), status: J(path.join('derived', 'status.json')), checks: J('checks.json'), runs: J('check_runs.json'),
    lenses: J('lenses.json'), readings: J('lens_readings.json'), theorems: J('theorems.json'), questions: J('questions.json'),
    persona: parsePersonaRules(fs.readFileSync(path.join(C, 'persona_rules.md'), 'utf8')),
    schemaText: fs.readFileSync(path.join(C, 'tuning', 'schema.json'), 'utf8'),
    readmeTemplate: fs.readFileSync(path.join(C, 'tuning', 'README.md'), 'utf8'),
    appVersion: JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).version,
  };
}

// ---------------------------------------------------------------- checks and runs
/** a check whose `ids` holds the characters of a printed note, one object per character, with no statement: the note, else null */
export function spreadNote(ids) {
  if (!Array.isArray(ids) || !ids.length) return null;
  const ok = ids.every(i => i && typeof i.id === 'string' && i.id.length === 1 && i.statement === '' && Object.keys(i).length === 2);
  return ok ? ids.map(i => i.id).join('') : null;
}
/** script → its last run: the record with the latest date; on equal dates the later record (the Logbook's lastRunIndex, tools/build_content.mjs) */
export function lastRunIndex(runs) {
  const last = {};
  for (const r of runs) if (r.script) { const k = r.script; if (!last[k] || r.date >= last[k].date) last[k] = r; }
  return last;
}
/** the last run of a script named in a row: its path under checks/, else the first last run whose script ends with /<basename> (the Logbook's runFor) */
function runFor(last, s) {
  if (!s) return null;
  const k = s.startsWith('checks/') ? s : 'checks/' + s;
  if (last[k]) return last[k];
  const base = '/' + s.split('/').pop();
  return Object.values(last).find(x => x.script.endsWith(base)) || null;
}
/** the indexes the Logbook builds on checks.json (its checksIndex): by script path (the last record wins), by basename (the first), by check id (the first) */
function checksIndex(checks) {
  const byScript = new Map(), byBase = new Map(), byId = new Map();
  for (const c of checks) {
    if (c.script) { byScript.set(c.script, c); const b = stripExt(c.script.split('/').pop()); if (!byBase.has(b)) byBase.set(b, c); }
    if (!spreadNote(c.ids)) for (const i of c.ids || []) if (!byId.has(i.id)) byId.set(i.id, { check: c, statement: i.statement });
  }
  return { byScript, byBase, byId };
}
/** a row's evidence tied to its check script and the last run, one entry per (script, check id, mode) — the Logbook's resolveEvidence */
function resolveEvidence(row, cidx, last) {
  const out = [], seen = new Map();
  for (const e of row.evidence || []) {
    const base = e.script ? stripExt(e.script.split('/').pop()) : null;
    const idHit = e.check ? cidx.byId.get(e.check) : null;
    const rec = (e.script && (cidx.byScript.get(e.script.startsWith('checks/') ? e.script : 'checks/' + e.script) || cidx.byBase.get(base))) || (idHit && idHit.check) || cidx.byBase.get(e.check) || null;
    const run = e.script ? runFor(last, e.script) : rec ? last[rec.script] || null : runFor(last, e.check);
    const script = rec ? rec.script : e.script ?? null;
    const key = `${script || ''}|${e.check}|${e.mode}`;
    if (seen.has(key)) {
      const prev = seen.get(key);
      if (prev.text === undefined && typeof e.text === 'string') { prev.text = e.text; if (typeof e.since === 'string') prev.since = e.since; }
      continue;
    }
    const rec2 = { check: e.check, script, mode: e.mode, lastRun: run ? { date: run.date, ok: run.ok ?? null, fail: run.fail ?? null, passed: run.passed === true } : null };
    if (typeof e.text === 'string') { rec2.text = e.text; if (typeof e.since === 'string') rec2.since = e.since; }
    seen.set(key, rec2); out.push(rec2);
  }
  return out;
}

// ---------------------------------------------------------------- the build
const rankOf = (m, v) => (v in m ? m[v] : 9);
const LEVEL = { research: 0, learner: 1 }, MODE = { both: 0, phys: 1, math: 2 }, REGISTER = { full: 0, short: 1, caption: 2 };
const matchClass = m => { const x = /^(?:match:\s*)?(exact|partial|none)\b/i.exec(String(m || '').trim()); return x ? x[1].toLowerCase() : 'other'; };
const count = (list, f) => { const m = {}; for (const x of list) { const k = f(x); m[k] = (m[k] || 0) + 1; } return Object.fromEntries(Object.entries(m).sort(([a], [b]) => cmp(a, b))); };
const num = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const cell = s => String(s ?? '').replace(/\|/g, '\\|').replace(/\s*\n\s*/g, ' ').trim();

/**
 * The files of the export from the tables: { files: { name → text }, counts, warnings }. Pure: no file, no clock. `T` is readTables()'s result,
 * `contentVersion` the content version of the build (null when the build has none).
 */
export function buildTuning(T, { contentVersion = null } = {}) {
  const schema = JSON.parse(T.schemaText);
  const NOTIONS = schema['x-notions'];
  const CODES = NOTIONS.map(n => n.code);
  if (NOTIONS.length !== 29 || NOTIONS.some((n, i) => n.bit !== i)) throw new Error('schema.json: x-notions must list the 29 notions, bit 0 to 28 in order');
  const PROPS = Object.keys(schema.definitions.row.properties);
  const warnings = [];
  const fail = m => { throw new Error('export_tuning: ' + m); };

  // ---- indexes
  const rowIds = new Set(); for (const r of T.rows) { if (rowIds.has(r.id)) fail(`the row id ${r.id} occurs twice`); rowIds.add(r.id); }
  const theoremIds = new Set(T.theorems.map(t => t.id)), questionIds = new Set(T.questions.map(q => q.id));
  const checkIds = new Set(); for (const c of T.checks) if (!spreadNote(c.ids)) for (const i of c.ids || []) checkIds.add(i.id);
  const cidx = checksIndex(T.checks), last = lastRunIndex(T.runs);
  const textsOf = new Map();
  for (const t of T.texts) { if (!rowIds.has(t.row)) fail(`a text names the unknown row ${t.row}`); if (!textsOf.has(t.row)) textsOf.set(t.row, []); textsOf.get(t.row).push(t); }
  const readingsOf = new Map();
  for (const r of T.readings) { if (!rowIds.has(r.row)) fail(`a lens reading names the unknown row ${r.row}`); if (!readingsOf.has(r.row)) readingsOf.set(r.row, []); readingsOf.get(r.row).push(r); }

  // ---- rows.jsonl
  const records = [];
  let unresolvedEvidence = 0, unknownEdges = 0;
  for (const r of [...T.rows].sort((a, b) => cmp(a.id, b.id))) {
    const d = T.status[r.id];
    if (!d) fail(`${r.id} has no record in derived/status.json: run npm run content`);
    const notions = r.notions || [];
    for (const n of notions) if (!CODES.includes(n)) fail(`${r.id} uses the unknown notion ${n}`);
    const mask = notions.reduce((m, n) => m + 2 ** CODES.indexOf(n), 0);
    let prime = 1n; for (const n of notions) prime *= BigInt(NOTIONS[CODES.indexOf(n)].prime);
    if (mask !== d.mask) fail(`${r.id}: the derived mask ${d.mask} is not the mask ${mask} of its notions: run npm run content`);
    if (String(prime) !== d.prime) fail(`${r.id}: the derived prime ${d.prime} is not the product ${prime} of its notions: run npm run content`);
    const texts = (textsOf.get(r.id) || []).slice().sort((a, b) => rankOf(LEVEL, a.level) - rankOf(LEVEL, b.level) || rankOf(MODE, a.mode) - rankOf(MODE, b.mode) || cmp(a.lens || '', b.lens || '') || rankOf(REGISTER, a.register) - rankOf(REGISTER, b.register) || cmp(a.lang || '', b.lang || ''))
      .map(t => ({ lang: t.lang, mode: t.mode, level: t.level, lens: t.lens ?? null, register: t.register, body: t.body, status: t.status, source: t.source ?? null }));
    const evidence = resolveEvidence(r, cidx, last);
    unresolvedEvidence += evidence.filter(e => !e.script).length;
    const depends = (r.depends || []).map(e => {
      const kind = rowIds.has(e.id) ? 'row' : theoremIds.has(e.id) ? 'theorem' : questionIds.has(e.id) ? 'question' : checkIds.has(e.id) ? 'check' : 'unknown';
      if (kind === 'unknown') unknownEdges++;
      return { id: e.id, rel: e.rel, kind };
    });
    const readings = (readingsOf.get(r.id) || []).map(x => ({ lens: x.lens, atlas: x.atlas, term: x.term, match: x.match, matchClass: matchClass(x.match), evidence: x.evidence || [], via: x.via }));
    const rec = {
      id: r.id, group: r.group, kind: r.kind, stage: r.stage, ptype: r.ptype ?? null, phenomena: r.phenomena || [], fields: r.fields || [], cells: r.cells || [], notions,
      bits: CODES.map(c => (notions.includes(c) ? '1' : '0')).join(''), mask, signature: d.signature, grade: d.grade, prime: d.prime, address: d.address,
      homePhys: r.homePhys ?? '', homeMath: r.homeMath ?? '', standardRef: r.standardRef ?? null,
      status: d.status, badge: d.badge ?? null, new: !!d.new, since: r.since, visibleTo: r.visibleTo || [],
      texts, evidence, depends, links: r.links || [], lensTags: r.lensTags || [], readings,
      shownOn: (r.shownOn || []).map(s => ({ page: s.page, section: s.section, order: s.order, role: s.role })),
      theorems: r.theorems || [], splitFrom: r.splitFrom ?? null, inputKind: r.inputKind ?? null, review: r.review ?? null,
    };
    if (Object.keys(rec).join() !== PROPS.join()) fail(`the keys of a record (${Object.keys(rec).join(', ')}) are not those of schema.json (${PROPS.join(', ')})`);
    records.push(rec);
  }
  const rowsJsonl = records.map(jsonLine).join('\n') + '\n';

  // ---- lenses, checks, theorems, questions
  const lenses = clone(T.lenses).sort((a, b) => cmp(a.key, b.key));
  let spread = 0;
  const checks = [...T.checks].map((c, i) => ({ c, i })).sort((a, b) => cmp(a.c.id, b.c.id) || a.i - b.i).map(({ c }) => {
    const o = clone(c), note = spreadNote(c.ids);
    if (note !== null) { o.ids = []; o.idsNote = note; spread++; }
    const run = last[c.script] || null;
    o.lastRun = run ? clone(run) : null;
    o.runCount = T.runs.filter(x => x.script === c.script).length;
    return o;
  });
  const runs = [...T.runs].map((r, i) => ({ r, i })).sort((a, b) => cmp(a.r.script, b.r.script) || cmp(a.r.date, b.r.date) || a.i - b.i).map(({ r }) => clone(r));
  const theorems = clone(T.theorems).sort((a, b) => natural(a.id, b.id)), questions = clone(T.questions).sort((a, b) => natural(a.id, b.id));
  const seenScripts = new Set(); for (const c of T.checks) { if (seenScripts.has(c.script)) warnings.push(`checks.json: the script ${c.script} is named by two check records`); seenScripts.add(c.script); }
  const orphan = [...new Set(T.runs.filter(r => !seenScripts.has(r.script)).map(r => r.script))];
  if (orphan.length) warnings.push(`check_runs.json: ${orphan.length} script(s) with a recorded run that no check record names: ${orphan.join(', ')}`);
  if (unresolvedEvidence) warnings.push(`rows.json: ${unresolvedEvidence} evidence entries name a check id that no script of checks.json lists (script null, lastRun null)`);
  if (unknownEdges) warnings.push(`rows.json: ${unknownEdges} dependencies name no row, theorem, question or check id (kind unknown)`);

  // ---- counts
  const lensTexts = T.texts.filter(t => t.lens != null).length;
  const counts = {
    rows: records.length, byKind: count(records, r => r.kind), byStatus: count(records, r => r.status), byStage: count(records, r => r.stage),
    texts: T.texts.length, textsByLevel: count(T.texts, t => t.level), textsByStatus: count(T.texts, t => t.status), textsWithLens: lensTexts,
    evidence: records.reduce((n, r) => n + r.evidence.length, 0), evidenceWithLastRun: records.reduce((n, r) => n + r.evidence.filter(e => e.lastRun).length, 0),
    depends: records.reduce((n, r) => n + r.depends.length, 0), readings: records.reduce((n, r) => n + r.readings.length, 0),
    lenses: lenses.length, dictionaryEntries: lenses.reduce((n, l) => n + (l.dictionary || []).length, 0),
    checks: checks.length, runs: runs.length, lastRuns: Object.keys(last).length, lastRunsPassed: Object.values(last).filter(r => r.passed === true).length,
    theorems: theorems.length, questions: questions.length, notions: NOTIONS.length,
    checksWithPrintedNote: spread,
  };

  // ---- the README
  const readme = writeReadme(T, schema, records, counts, contentVersion);

  // ---- the files and the manifest
  const files = {
    'rows.jsonl': rowsJsonl,
    'lenses.json': JSON.stringify(lenses) + '\n',
    'checks.json': JSON.stringify(checks) + '\n',
    'runs.json': JSON.stringify(runs) + '\n',
    'theorems.json': JSON.stringify(theorems) + '\n',
    'questions.json': JSON.stringify(questions) + '\n',
    'schema.json': T.schemaText,
    'README.md': readme,
  };
  const recordsOf = { 'rows.jsonl': records.length, 'lenses.json': lenses.length, 'checks.json': checks.length, 'runs.json': runs.length, 'theorems.json': theorems.length, 'questions.json': questions.length, 'schema.json': null, 'README.md': null };
  const manifest = {
    name: 'one-rule-tuning', format: 1, appVersion: T.appVersion, contentVersion, licence: 'PolyForm-Noncommercial-1.0.0',
    files: FILE_NAMES.filter(n => n !== 'manifest.json').map(name => ({ name, records: recordsOf[name], bytes: Buffer.byteLength(files[name], 'utf8'), sha256: sha256(files[name]) })),
    counts,
  };
  files['manifest.json'] = JSON.stringify(manifest, null, 1) + '\n';
  const ordered = {}; for (const n of FILE_NAMES) ordered[n] = files[n];
  return { files: ordered, counts, warnings, manifest };
}

// ---------------------------------------------------------------- the README
const typeWords = p => [].concat(p.type || (p.enum ? 'string' : 'any')).join(' or ');
function table(head, rows) { return [`| ${head.join(' | ')} |`, `| ${head.map(() => '---').join(' | ')} |`, ...rows.map(r => `| ${r.map(cell).join(' | ')} |`)].join('\n'); }
function writeReadme(T, schema, records, counts, contentVersion) {
  const defs = schema.definitions, roles = schema['x-roles'];
  const row = defs.row.properties;
  const block = {};
  block.version = `Built from ONE RULE ${T.appVersion}${contentVersion ? `, content ${contentVersion}` : ''}: ${num(counts.rows)} records, ${num(counts.texts)} texts, ${num(counts.readings)} lens readings, ${num(counts.checks)} check scripts with ${num(counts.runs)} recorded runs.`;
  block.files = table(['file', 'records', 'what it holds'], schema['x-files'].map(f => [`\`${f.name}\``, { 'rows.jsonl': counts.rows, 'lenses.json': counts.lenses, 'checks.json': counts.checks, 'runs.json': counts.runs, 'theorems.json': counts.theorems, 'questions.json': counts.questions }[f.name] ?? '', f.what]));
  block.fields = table(['key', 'type', 'role', 'holds'], Object.entries(row).map(([k, p]) => [`\`${k}\``, typeWords(p), roles[p['x-role']].label, p.description]));
  const nestedOf = (title, d) => `**Inside \`${title}\`** (${d.description || ''})\n\n` + table(['key', 'holds'], Object.entries(d.properties).map(([k, p]) => [`\`${k}\``, p.description || '']));
  block.nested = [
    nestedOf('texts', { description: 'one object per text', properties: defs.text.properties }),
    nestedOf('evidence', { description: 'one object per check script and check id', properties: { ...defs.evidence.properties, lastRun: { description: defs.evidence.properties.lastRun.description + ' Its keys: ' + Object.keys(defs.lastRunShort.properties).join(', ') + '.' } } }),
    nestedOf('depends', { description: 'one object per edge', properties: defs.edge.properties }),
    nestedOf('readings', { description: 'one object per reading', properties: defs.reading.properties }),
    nestedOf('shownOn', { description: 'one object per place', properties: defs.placement.properties }),
  ].join('\n\n');
  block.notions = table(['bit', 'code', 'square', 'prime', 'the notion'], schema['x-notions'].map(n => [n.bit, `\`${n.code}\``, n.square > 0 ? '+1' : n.square < 0 ? '−1' : '0', n.prime, n.meaning]));
  block.statuses = table(['status', 'the guide\'s word', 'when'], schema['x-status'].map(s => [`\`${s.status}\``, s.word, s.rule]));
  const sections = T.persona.sections, find = re => sections.find(s => re.test(s.title));
  const sw = find(/status words/i), never = find(/never says/i), open = find(/^open$/i);
  if (!sw || !never || !open || !T.persona.statusWords.length) throw new Error('export_tuning: content/persona_rules.md lacks its status words, its "never says" list or its "Open" list');
  block.status_words = (sw.lead.length ? sw.lead.join(' ') + '\n\n' : '') + T.persona.statusWords.map(w => `- **${w.word}** (\`${w.kind}\`): ${w.text}`).join('\n');
  block.never = never.items.map(i => `- ${i.text}`).join('\n');
  block.open = (open.lead.length ? open.lead.join(' ') + '\n\n' : '') + open.items.map(i => `- ${i.text}`).join('\n');
  const st = counts.textsByStatus;
  block.limits = [
    `- Texts: ${num(st.human || 0)} are the author's words (\`human\`), ${num(st.reviewed || 0)} are a model's words the author accepted (\`reviewed\`), ${num(st.draft || 0)} are a model's words not yet reviewed (\`draft\`). A \`draft\` is not ground truth.`,
    counts.textsWithLens === 0
      ? '- No text carries a lens yet: `lens` is null in every text. The words of a field are in `readings` and in the dictionaries of `lenses.json`: for an element of the Atlas, the term a lens uses.'
      : `- ${num(counts.textsWithLens)} texts carry a lens; the others use the Atlas's own words (\`lens\` null). Further field vocabulary is in \`readings\` and in \`lenses.json\`.`,
    `- ${num(counts.byKind.story || 0)} records have kind \`story\`: narration between statements, not statements. Filter them out when a statement is wanted.`,
    '- The proposals for missing statements (the candidates) and the Atlas\'s own pages are not part of these files.',
    `- \`evidence[].lastRun\` is null where no run is recorded for the script, or where a check id cannot be tied to a script (${num(counts.evidence - counts.evidenceWithLastRun)} of ${num(counts.evidence)} entries).`,
    '- A `script` is an address from the root of the site: the build copies the Python scripts there, so most can be read at that address.',
    counts.checksWithPrintedNote ? `- ${num(counts.checksWithPrintedNote)} check scripts print no list of check ids: \`ids\` is empty and \`idsNote\` says how their output is labelled.` : null,
    '- Status words state what the Atlas has checked and what it has not. A check that ran and passed is a recorded run of a script, not a measurement of nature; the Atlas is a guide, not an oracle.',
  ].filter(Boolean).join('\n');
  // an example: the first record with both levels of text, a passed run, an edge to a row and a reading, cut where long
  const ex = records.find(r => r.texts.some(t => t.level === 'research') && r.texts.some(t => t.level === 'learner') && r.evidence.some(e => e.lastRun && e.lastRun.passed) && r.depends.some(e => e.kind === 'row') && r.readings.length && r.status === 'proved-by-atlas');
  const cut = (s, n = 70) => (typeof s === 'string' && s.length > n ? s.slice(0, n).trimEnd() + '…' : s);
  const small = ex ? { ...ex,
    homePhys: cut(ex.homePhys), homeMath: cut(ex.homeMath), standardRef: cut(ex.standardRef),
    texts: [ex.texts.find(t => t.level === 'research'), ex.texts.find(t => t.level === 'learner')].map(t => ({ ...t, body: cut(t.body) })),
    evidence: ex.evidence.filter(e => e.lastRun).slice(0, 1),
    depends: ex.depends.slice(0, 2), links: ex.links.slice(0, 2), readings: ex.readings.slice(0, 1).map(x => ({ ...x, atlas: cut(x.atlas), term: cut(x.term) })), shownOn: ex.shownOn.slice(0, 1),
  } : null;
  block.example = small ? JSON.stringify(small, null, 1) : '{}';
  let out = T.readmeTemplate.replace(/^<!--[\s\S]*?-->\n/, LICENCE_HEADER);
  out = out.replace(/^\{\{(\w+)\}\}$/gm, (m, k) => { if (!(k in block)) throw new Error(`export_tuning: README template: the block {{${k}}} is unknown`); return block[k]; });
  const left = /\{\{\w+\}\}/.exec(out);
  if (left) throw new Error(`export_tuning: README: ${left[0]} is left in the output (a block must stand alone on its line)`);
  return out.replace(/\n{3,}/g, '\n\n');
}

// ---------------------------------------------------------------- writing
/** write the files to <outDir>/content/tuning/ (the folder is emptied first), with the script twins of schema and manifest for file:// */
export function writeTuning(outDir, result) {
  const dir = path.join(outDir, 'content', 'tuning');
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  for (const [name, text] of Object.entries(result.files)) fs.writeFileSync(path.join(dir, name), text);
  for (const name of ['schema', 'manifest']) {
    const json = JSON.stringify(JSON.parse(result.files[`${name}.json`]));
    fs.writeFileSync(path.join(dir, `${name}.js`), `(window.${GLOBAL}=window.${GLOBAL}||{})[${JSON.stringify('tuning/' + name)}]=${json};\n`);
  }
  return dir;
}

/** the versions the build wrote (dist/content/version.json), else the version of package.json and no content version */
export function buildVersions(outDir, appVersion) {
  try { const v = JSON.parse(fs.readFileSync(path.join(outDir, 'content', 'version.json'), 'utf8')); return { appVersion: v.appVersion || appVersion, contentVersion: v.contentVersion || null }; }
  catch { return { appVersion, contentVersion: null }; }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const out = path.resolve(ROOT, process.argv[2] || 'dist');
  try {
    const T = readTables();
    const v = buildVersions(out, T.appVersion);
    T.appVersion = v.appVersion;
    const res = buildTuning(T, { contentVersion: v.contentVersion });
    const dir = writeTuning(out, res);
    for (const w of res.warnings) console.warn(`export_tuning: warning: ${w}`);
    const bytes = Object.values(res.files).reduce((n, s) => n + Buffer.byteLength(s, 'utf8'), 0);
    console.log(`export_tuning: ${num(res.counts.rows)} records, ${num(res.counts.texts)} texts, ${num(res.counts.checks)} checks and ${num(res.counts.runs)} runs, ${num(res.counts.lenses)} lenses, ${(bytes / 1048576).toFixed(2)} MB in ${path.relative(ROOT, dir)}/`);
  } catch (e) {
    console.error(e && e.message ? e.message : e);
    process.exit(1);
  }
}
