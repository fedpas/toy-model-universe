#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/merge_learner_texts.mjs — merges the translator drafts of every content/texts_learner*.json file (09_TRANSLATION_PROTOCOL §4) into content/texts.json.
// A text record is keyed by (row, level, mode, lens, register). A record whose status is `human` is never replaced; a draft or reviewed
// record is replaced by the draft of the same key. Idempotent and deterministic: run it after any migration (run_all.sh does) and after editing texts_learner.json.
import fs from 'node:fs'; import path from 'node:path';
const C = path.resolve('content');
const J = f => JSON.parse(fs.readFileSync(path.join(C, f), 'utf8'));
const key = t => [t.row, t.level, t.mode, t.lens || '', t.register || 'full'].join('|');
const texts = J('texts.json');
const files = fs.readdirSync(C).filter(n => /^texts_learner.*\.json$/.test(n)).sort();
if (!files.length) { console.log('merge_learner_texts: no content/texts_learner*.json — nothing to merge'); process.exit(0); }
const drafts = files.flatMap(f => J(f));
const rows = new Set(J('rows.json').map(r => r.id));
const byKey = new Map(texts.map(t => [key(t), t]));
let added = 0, replaced = 0, kept = 0, skipped = 0;
for (const d of drafts) {
  if (!rows.has(d.row) || d.level !== 'learner' || !d.body || !String(d.body).trim()) { skipped++; continue; }
  const rec = { row: d.row, lang: d.lang || 'en', mode: d.mode || 'both', level: 'learner', lens: d.lens || null, register: d.register || 'full', body: String(d.body).trim(), status: d.status === 'reviewed' ? 'reviewed' : 'draft', source: d.source || 'translator:learner' };
  const k = key(rec), old = byKey.get(k);
  if (!old) { byKey.set(k, rec); added++; }
  else if (old.status === 'human') kept++;
  else { byKey.set(k, rec); replaced++; }
}
const out = [...byKey.values()].sort((a, b) => a.row.localeCompare(b.row, 'en') || a.level.localeCompare(b.level) || String(a.lens || '').localeCompare(String(b.lens || '')));
fs.writeFileSync(path.join(C, 'texts.json'), JSON.stringify(out, null, 1));
const cf = path.join(C, 'MIGRATION_COUNTS.json'); const prev = fs.existsSync(cf) ? JSON.parse(fs.readFileSync(cf, 'utf8')) : {};
prev.learnerDrafts = { drafts: drafts.length, added, replaced, keptHuman: kept, skipped, learnerTexts: out.filter(t => t.level === 'learner').length, texts: out.length };
fs.writeFileSync(cf, JSON.stringify(prev, null, 1));
console.log(JSON.stringify(prev.learnerDrafts));
