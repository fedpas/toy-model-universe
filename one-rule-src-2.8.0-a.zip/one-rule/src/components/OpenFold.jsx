// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/OpenFold.jsx — the open items, collapsed at the end of a page with their badges; never between results. Learner level calls it
// "Not finished yet". Its groups come from the page model (docs/STORY_PLAN.md §2.1 item 6): the rows with status open (questions, dead ends,
// conjectures, pointers) grouped by part on a chapter page (by section elsewhere), then the sections of the open part — a chapter's perspectives,
// questions and notes — each one group with its lead (the group's intro) and every row it holds; a group of sections (the category's P1–P6) shows
// each as a sub-group; in a group with pairs each question comes first with "the statement behind the question" folded under it, as v15 had it.
import { useSettings } from '../app/content.js';
import Statement from './Statement.jsx';
import Lead from './Lead.jsx';
import Drawer from './Drawer.jsx';
import { BadgeIcon } from './Icons.jsx';
import { STORY_WORDS } from '../app/vocab.js';

function GroupRows({ g }) {
  if (!g.pairs) return g.rows.map(id => <Statement key={id} id={id} />);
  return g.pairs.map(p => (p.questions.length ? (
    <div className="pair" key={p.statement} data-pair={p.statement}>
      {p.questions.map(q => <Statement key={q} id={q} />)}
      <details className="pair__behind">
        <summary className="pair__summary">{STORY_WORDS.behind}</summary>
        <Statement id={p.statement} />
      </details>
    </div>
  ) : <Statement key={p.statement} id={p.statement} />));
}

export default function OpenFold({ groups, open, onToggle, drawers = true, drawer, onDrawer }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  const rows = groups.flatMap(g => g.rows);
  const leads = groups.flatMap(g => [g.lead, ...(g.sub || []).map(x => x.lead)]).filter(Boolean);
  if (!rows.length && !leads.length) return null;
  const title = learner ? 'Not finished yet' : 'Open items';
  const titled = groups.length > 1 || groups.some(g => g.lead || g.sub);
  return (
    <details className="fold" id="sec-open-items" data-outline={title} open={!!open} onToggle={e => onToggle && onToggle(e.currentTarget.open)}>
      <summary className="fold__summary">
        <span className="fold__icon"><BadgeIcon kind="open" size={14} /></span>
        <span className="fold__title">{title}</span>
        <span className="fold__count">{rows.length}</span>
      </summary>
      <div className="fold__body">
        {groups.map(g => (
          <div className="fold__group" key={g.id} data-group={g.id}>
            {titled ? <h3 className="fold__group-title">{g.label}</h3> : null}
            {g.lead ? <Lead id={g.lead} variant="group" /> : null}
            {g.sub ? g.sub.map(x => (
              <div className="fold__sub" key={x.id} data-group={x.id}>
                <h4 className="fold__sub-title">{x.label}</h4>
                {x.lead ? <Lead id={x.lead} variant="group" /> : null}
                <GroupRows g={x} />
              </div>
            )) : <GroupRows g={g} />}
          </div>
        ))}
        {drawers ? (
          <Drawer sid="__open" rows={rows} open={drawer && drawer.open} focus={drawer && drawer.focus} onToggle={o => onDrawer && onDrawer('__open', o)} />
        ) : null}
      </div>
    </details>
  );
}
