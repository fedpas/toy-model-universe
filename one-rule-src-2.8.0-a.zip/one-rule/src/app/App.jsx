// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/App.jsx — loads the tables every page needs, then renders the shell, the page of the route and the footer. The landing of
// content/story/landing.json is applied to the tables before a render reads them (applyLanding in router.js: the start page of the full Atlas at
// `#/atlas`); `#/` is the door (round 7). An old address of the leaves (#/explore, #/explore/<slug>) shows the page it now leads to at once and is
// replaced in the address bar (location.replace: no history entry), its settings and other parameters kept (redirectHash in router.js).
import { useEffect, useState } from 'react';
import { useSettings, loadTable } from './content.js';
import { peekTable, primeTable } from './store.js';
import { getHash, replaceHash } from './location.js';
import { useRoute, applyLanding, redirectHash } from './router.js';
import { applyDocumentSettings } from './theme.js';
import Shell from '../components/Shell.jsx';
import Footer from '../components/Footer.jsx';
import ErrorBoundary from '../components/ErrorBoundary.jsx';
import Page from '../pages/Page.jsx';
import Zero from '../pages/Zero.jsx';
import Cells from '../pages/Cells.jsx';
import Cell from '../pages/Cell.jsx';
import Steps from '../pages/Steps.jsx';
import Lenses from '../pages/Lenses.jsx';
import LensRoom from '../pages/LensRoom.jsx';
import Glossary from '../pages/Glossary.jsx';
import Ask from '../pages/Ask.jsx';
import GateLogbook from '../pages/GateLogbook.jsx';
import NotFound from '../pages/NotFound.jsx';
import Door from '../pages/Door.jsx';
import Agents from '../pages/Agents.jsx';
import Tutorials from '../pages/Tutorials.jsx';
import PageRecord from '../components/PageRecord.jsx';

/** the tables loaded before the first page renders (the drawers load checks.json and check_runs.json when opened) */
export const CORE_TABLES = ['pages', 'steps', 'texts', 'derived_status', 'rows', 'lenses', 'glossary', 'figures', 'needs', 'inputs'];
const OPTIONAL_TABLES = ['version'];
const coreReady = () => CORE_TABLES.every(n => peekTable(n) !== undefined);

function RoutePage({ route }) {
  const m = route.match;
  switch (m.name) {
    case 'door': return <Door />;
    case 'agents': return <><Agents /><PageRecord route={m.page} /></>;
    // the tutorials (docs/round8/TUTORIALS.md): a static page, as the guide for agents; it places no row, so its record shows nothing
    case 'tutorials': return <><Tutorials /><PageRecord route={m.page} /></>;
    case 'zero': return <Zero route={m.page} />;
    case 'cells': return <Cells />;
    case 'cell': return <Cell cellKey={m.key} />;
    case 'steps': return <Steps />;
    case 'lenses': return <Lenses />;
    case 'lens': return <LensRoom lensKey={m.key} />;
    case 'glossary': return <Glossary />;
    // the pages that draw themselves without PageView end with the record of the page too (round 7, R7-4; it shows nothing on a page that places no row)
    case 'ask': return <><Ask /><PageRecord route={m.page} /></>;
    case 'logbook': return <><GateLogbook tab={m.tab} /><PageRecord route={m.page} /></>;
    case 'page': return <Page route={m.page} />;
    default: return <NotFound />;
  }
}

function Loading({ error, retry }) {
  return (
    <div className="boot" role={error ? 'alert' : 'status'}>
      {error ? (
        <>
          <p className="boot__text">The content tables could not be loaded: {String(error.message || error)}</p>
          <button type="button" className="btn" onClick={retry}>Try again</button>
        </>
      ) : <p className="boot__text">Loading the Atlas…</p>}
    </div>
  );
}

export default function App() {
  // the tables as landing.json places the pages (a no-op once applied, and before the tables are in); server rendering primes the tables
  // and renders at once, so this runs here and not only after the load
  if (coreReady()) applyLanding();
  const s = useSettings();
  const route = useRoute();
  const [ready, setReady] = useState(coreReady);
  const [error, setError] = useState(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (ready) return undefined;
    let alive = true;
    setError(null);
    Promise.all([
      ...CORE_TABLES.map(n => loadTable(n)),
      ...OPTIONAL_TABLES.map(n => loadTable(n).catch(() => { primeTable(n, null); return null; })),
    ]).then(() => { applyLanding(); if (alive) setReady(true); }, e => alive && setError(e));
    return () => { alive = false; };
  }, [attempt]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { applyDocumentSettings(s); }, [s.theme, s.level]); // eslint-disable-line react-hooks/exhaustive-deps

  // an old address of the leaves: the page it leads to is drawn already; the address follows, replaced (once the tables are in, so that the target is known)
  const redirect = route.match && route.match.redirect;
  useEffect(() => {
    if (!redirect || typeof window === 'undefined') return;
    const to = redirectHash(getHash());
    if (to && to !== getHash()) replaceHash(to);
  }, [redirect, route.path, ready]); // eslint-disable-line react-hooks/exhaustive-deps

  // a new page starts at its top, unless the address names a place on it (at=…), which the page brings into view; at=top is the top of the page
  useEffect(() => {
    if (typeof window === 'undefined' || (route.at && route.at !== 'top')) return;
    window.scrollTo(0, 0);
  }, [route.path]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!ready) {
    return (
      <div className="app">
        <Loading error={error} retry={() => setAttempt(a => a + 1)} />
      </div>
    );
  }
  const pageKey = `${route.path}`;
  return (
    <div className="app" data-mode={s.mode} data-level={s.level}>
      <Shell route={route} />
      <main id="main" className="main" tabIndex={-1} data-ready="true">
        <ErrorBoundary name="this page" resetKey={`${pageKey}|${s.mode}|${s.level}|${s.lens}`} fallback={err => (
          <div className="notice" role="alert"><p className="notice__text">This page could not be drawn: {String((err && err.message) || err)}</p></div>
        )}>
          <RoutePage key={pageKey} route={route} />
        </ErrorBoundary>
      </main>
      <Footer />
    </div>
  );
}
