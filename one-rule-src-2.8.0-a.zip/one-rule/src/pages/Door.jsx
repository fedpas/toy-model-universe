// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Door.jsx — `#/`, the door ("Start here"; docs/round7/PLAN.md R7-2, §4 ARCH item 3, interface 36: .door .door-hero .door-cards .door-card
// .door-card-icon .door-card-n .door-shelf .door-chapters .door-door), laid out as Octavo's home: the mark and the line beside the door's picture, a
// tiny graphic novel (src/door/Comic.jsx, .door-comic): panels in which one figure asks "What is the One Rule?" and the other answers for one
// field, each answer a row of the Atlas drawn by Statement, each panel with "Open →" to that row's place; the door draws no leaf figure (the clock
// lives at the top of its page, #/clock). "Eight ways in" — the path of eight leaves of content/explore/registry.json, each card with the
// leaf's picture, its number, its name, its line (the hero row of the leaf: the caption row of its figure, in the short register where the row has one at
// this level; a leaf not drawn yet has no line) and "Open →" to the leaf's place on its Atlas page (its page at its anchor:
// at=top, the page top, or at=<section>); a leaf not drawn yet says "coming" and opens its page anyway; "On the shelf" — the drawn shelf leaves, each
// "hangs under n"; "The Atlas, chapter by chapter" — one card per main page of content/story/landing.json, its title and its lead story row (else its
// hero row); the door to the full Atlas (#/atlas), with the guide for agents (#/agents) and the tutorials (#/tutorials) beside it. A first visit
// opens at learner level (src/app/settings.js). Every sentence is a row (Statement);
// the words of this file and of content/story/door.json are names and directions.
import { useEffect } from 'react';
import { useSettings, textFor } from '../app/content.js';
import { pageTitle, pageLead, visibleIn } from '../app/queries.js';
import { ATLAS_ROUTE, landingChapters, leafPlace, matchRoute, useRoute } from '../app/router.js';
import { pagesByRoute, rowsById } from '../app/store.js';
import Link from '../components/Link.jsx';
import Statement from '../components/Statement.jsx';
import LeafIcon, { DoorMark, IconLock } from '../components/LeafIcons.jsx';
import { pathLeaves, shelfLeaves, leafRow, leafName, pathLeaf, isDrawn } from '../components/LeafPath.jsx';
import Comic from '../door/Comic.jsx';
import { registerOf } from '../components/LeafNotes.jsx';
import WORDS from '../../content/story/door.json';
import '../styles/explore.css';
import '../styles/door.css';

const W = WORDS && typeof WORDS === 'object' ? WORDS : {};
const word = (k, sub, fallback) => (sub ? (W[k] && W[k][sub]) : W[k]) || fallback;

// ---------------------------------------------------------------- the chapter cards (STORY_PLAN §2.7, interface 27: pageLead)
const hasText = (id, s, register) => textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register }) != null;
/**
 * The row a chapter card shows, its register and where it comes from: the page's lead story row, from pageLead(route, settings) (interface
 * 27: { id, register } — the short register where the row has one at this level). A page without a lead shows its hero row instead, in the same
 * registers; a hero row the mode does not show, or without a text at this level, leaves the card with its title alone.
 */
export function chapterRow(route, s) {
  const lead = pageLead(route, s);
  if (lead && lead.id) return { id: lead.id, register: lead.register || 'full', source: 'lead' };
  const def = pagesByRoute()?.get(route);
  const id = def && def.hero ? def.hero.row : null;
  const row = id ? rowsById()?.get(id) : null;
  if (!row || !visibleIn(row, s.mode)) return null;
  const register = hasText(id, s, 'short') ? 'short' : 'full';
  return hasText(id, s, register) ? { id, register, source: 'hero' } : null;
}

function ChapterCard({ route }) {
  const s = useSettings();
  const row = pagesByRoute()?.has(route) ? chapterRow(route, s) : null;
  return (
    <li className="door-card door-card--chapter leaf-card leaf-card--chapter" data-chapter={route} data-source={row ? row.source : undefined}>
      <h3 className="door-card__title leaf-card__title"><Link to={route} className="door-card__link leaf-card__link">{pageTitle(route, s)}</Link></h3>
      {row ? <Statement id={row.id} register={row.register} variant="card" evidence={false} /> : null}
    </li>
  );
}

// ---------------------------------------------------------------- the leaves
/** a card of the path or the shelf: picture, number (path) or the leaf it hangs under (shelf), name, line, the way to its place */
function LeafCard({ entry }) {
  const s = useSettings();
  const drawn = isDrawn(entry);
  const row = leafRow(entry);
  const place = leafPlace(entry);
  const reachable = !!(place.path != null && pagesByRoute()?.has(place.path));
  const shelf = entry.kind === 'shelf';
  const under = shelf && entry.under ? pathLeaf(entry.under) : null;
  const shown = row && hasText(row, s, registerOf(row, s)) && visibleIn(rowsById()?.get(row) || {}, s.mode);
  return (
    <li className={`door-card door-card--${entry.kind}${drawn ? '' : ' is-coming'}`} data-leaf={entry.slug} data-page={reachable ? place.path : undefined} data-anchor={reachable ? place.at : undefined}>
      <span className="door-card-icon"><LeafIcon slug={entry.slug} size={shelf ? 48 : 64} /></span>
      {entry.kind === 'path' ? <span className="door-card-n" aria-hidden="true">{entry.n}</span> : null}
      {under ? <span className="door-card-under"><span>{word('shelf', 'under', 'hangs under')}</span>{' '}<span className="door-card-n">{under.n}</span><span className="vh">{`, ${leafName(under)}`}</span></span> : null}
      <h3 className="door-card__title">{leafName(entry)}</h3>
      {!drawn ? <p className="door-card__coming">{word('coming', null, 'coming')}</p> : null}
      {shown ? <Statement id={row} register={registerOf(row, s)} variant="card" evidence={false} /> : null}
      {reachable ? <Link to={place.path} at={place.at} className="door-card__open" aria-label={`${word('open', null, 'Open')}: ${leafName(entry)}`}>{`${word('open', null, 'Open')} →`}</Link> : null}
    </li>
  );
}

/** a page the router knows that is not a page of pages.json (the guide for agents, the tutorials, once their routes exist) */
const routeKnown = r => !!r && !['notfound', 'redirect'].includes(matchRoute(r).name) && !matchRoute(r).redirect;

export default function Door() {
  const route = useRoute();
  const path = pathLeaves(), shelf = shelfLeaves().filter(isDrawn), chapters = landingChapters();
  const first = path.find(isDrawn) || null;
  // at=<part> (the button "See the shelf", an old link to the Explore home's shelf) brings that part into view
  useEffect(() => {
    if (!route.at || typeof document === 'undefined') return undefined;
    const t = setTimeout(() => { const el = document.getElementById(`sec-${route.at}`); if (el) el.scrollIntoView({ block: 'start' }); }, 30);
    return () => clearTimeout(t);
  }, [route.at]);
  const agents = W.agents && routeKnown(W.agents.route) ? W.agents : null;
  const tutorials = W.tutorials && routeKnown(W.tutorials.route) ? W.tutorials : null;
  return (
    <article className="page door" data-route="" aria-labelledby="page-title">
      <section className="door-hero" id="sec-door">
        <div className="door-hero__text">
          <p className="door-hero__mark"><DoorMark size={30} /><span className="door-hero__name">{word('title', null, 'ONE RULE')}</span></p>
          <h1 className="door-hero__line" id="page-title">{word('line', null, 'Eight ways into the Atlas.')}</h1>
          <p className="door-hero__actions">
            {first ? <Link to={leafPlace(first).path} at={leafPlace(first).at} className="btn btn--primary door-begin">{`${word('begin', null, 'Begin with the clock')} →`}</Link> : null}
            {shelf.length ? <Link to="" at="shelf" className="btn btn--ghost door-see-shelf">{word('seeShelf', null, 'See the shelf')}</Link> : null}
          </p>
        </div>
        <Comic words={W.comic} />
      </section>

      <section className="door-cards" id="sec-path" aria-labelledby="h-path" data-outline={word('path', 'title', 'Eight ways in')}>
        <header className="door-cards__head">
          <h2 className="door-cards__title" id="h-path">{word('path', 'title', 'Eight ways in')}</h2>
          <p className="door-cards__line" data-connective="door">{word('path', 'line', '')}</p>
        </header>
        <ol className="door-cards__list">{path.map(e => <LeafCard key={e.slug} entry={e} />)}</ol>
      </section>

      {shelf.length ? (
        <section className="door-shelf" id="sec-shelf" aria-labelledby="h-shelf" data-outline={word('shelf', 'title', 'On the shelf')}>
          <header className="door-cards__head">
            <h2 className="door-cards__title" id="h-shelf">{word('shelf', 'title', 'On the shelf')}</h2>
            <p className="door-cards__line" data-connective="door">{word('shelf', 'line', '')}</p>
          </header>
          <ul className="door-cards__list door-cards__list--shelf">{shelf.map(e => <LeafCard key={e.slug} entry={e} />)}</ul>
        </section>
      ) : null}

      {chapters.length ? (
        <section className="door-chapters" id="sec-chapters" aria-labelledby="h-chapters" data-outline={word('chapters', 'title', 'The Atlas, chapter by chapter')}>
          <header className="door-cards__head">
            <h2 className="door-cards__title" id="h-chapters">{word('chapters', 'title', 'The Atlas, chapter by chapter')}</h2>
            <p className="door-cards__line" data-connective="door">{word('chapters', 'line', '')}</p>
          </header>
          <ol className="door-cards__list door-cards__list--chapters leaf-grid leaf-grid--chapters">{chapters.map(r => <ChapterCard key={r} route={r} />)}</ol>
        </section>
      ) : null}

      <nav className="door-door" id="sec-atlas" aria-labelledby="h-atlas">
        <span className="door-door__icon"><IconLock size={30} /></span>
        <h2 className="door-door__title" id="h-atlas">{word('door', 'title', 'The Atlas')}</h2>
        <Link to={ATLAS_ROUTE} className="btn btn--primary door-door__open">{`${word('door', 'open', 'Connect to the full Atlas')} →`}</Link>
        {agents ? <Link to={agents.route} className="btn btn--ghost door-door__agents">{agents.title}</Link> : null}
        {tutorials ? <Link to={tutorials.route} className="btn btn--ghost door-door__tutorials">{tutorials.title}</Link> : null}
      </nav>
    </article>
  );
}
