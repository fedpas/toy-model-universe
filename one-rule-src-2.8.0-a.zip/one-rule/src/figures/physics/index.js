// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/index.js — the figures of the physics restoration (docs/PHYSICS_AUDIT.md, owners P4–P11), one registry file per owner.
import { P4_FIGURES } from './p4.js';
import { P5_FIGURES } from './p5.js';
import { P6_FIGURES } from './p6.js';
import { P7_FIGURES } from './p7.js';
import { P8_FIGURES } from './p8.js';
import { P9_FIGURES } from './p9.js';
import { P10_FIGURES } from './p10.js';
import { P11_FIGURES } from './p11.js';
export const PHYS_FIGURES = { ...P4_FIGURES, ...P5_FIGURES, ...P6_FIGURES, ...P7_FIGURES, ...P8_FIGURES, ...P9_FIGURES, ...P10_FIGURES, ...P11_FIGURES };
