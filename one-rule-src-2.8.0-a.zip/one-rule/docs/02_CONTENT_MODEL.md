# 02 — Content model

All content lives in `content/` as JSON (one file per table; arrays of records; UTF-8; stable ids; sorted by id on write so diffs are readable). The app never reads v15 modules; a build step turns `content/` into per-page chunks (`08_BUILD_TEST.md`). The tables below are the whole model. Field names are final; add fields only with a schema change and a migration note.

## 1. `rows.json` — the statements

```jsonc
{
  "id": "GRV-012",                      // stable; v15 ids kept; new rows: "<GROUP>-<3 digits>" above the v15 range, candidates "CAND-<3 digits>"
  "group": "GRV",                       // v15 group code (28 groups) — kept for the register, not used for layout
  "kind": "theorem",                    // mathematician's kind: definition|construction|lemma|theorem|range|classification|invariant|example|counterexample|computation|reduction|reading|conjecture|question|dead-end|pointer|meta
  "stage": "D",                         // physicist's stage: A algebra | K kinematics | F fields | D dynamics | O observation | M method
  "ptype": "solution",                  // physicist's type: postulate|definition|derivation|identity|solution|limit|symmetry|observable|calibration|reading|open|negative
  "phenomena": ["gravity","black-hole"],// physicist's phenomena (0..n)
  "fields": ["geometry","analysis"],    // mathematician's fields (0..n): algebra|geometry|topology|category|combinatorics|analysis
  "cells": ["(1,3,0)"],                 // the algebra cell(s) the statement is about; "all n", "row 8", "(p,q,1)" allowed; [] if none
  "notions": ["cnx","sol","s-geo","i-chart","i-act"],   // the label: subset of the 29 notion codes (04_LABELLING.md)
  "homePhys": "Birkhoff's theorem",     // the name physics gives it, or ""
  "homeMath": "uniqueness of spherically symmetric vacuum solutions", // the name mathematics gives it, or ""
  "standardRef": "…",                   // v15 standardRef, verbatim (author and title; the author's read/unread note kept)
  "evidence": [                         // what proves it here (see §5); [] allowed
    {"check": "C1", "script": "selfcheck/gravity/c1_birkhoff.py", "mode": "ran"},
    {"check": "gravity_new_checks", "script": "selfcheck/gravity/gravity_new_checks.py", "mode": "ran"}
  ],
  "depends": [                          // logical relations (04_LABELLING.md §4)
    {"id": "GRV-010", "rel": "derives"}, {"id": "INP-056", "rel": "uses-input"}, {"id": "T18", "rel": "instance"}
  ],
  "links": ["L5", "S3-schuller"],       // translation-matrix row uids and report finding ids (kept from v15 `links`)
  "lensTags": ["CLF","GRV"],            // v15 lens codes (kept; informational)
  "shownOn": [{"page": "steps/grav2", "section": "solutions", "order": 3, "role": "result"}],  // where it renders; a row may render in several places
  "visibleTo": ["phys","math"],         // modes in which it renders (both by default)
  "legacyFlags": ["standard","checked","input"],  // v15 flags, kept read-only for the register and for migration tests
  "legacyLines": 2,                     // number of v15 lines merged into this row's texts
  "since": "v15",                       // "v15" | "v16" | "v2.1" | "v2.2" | "v2.4" | "v2.4.2" | "v2.4.3" | "v2.5" | "v2.6" | "v2.7" | "v2.8" (the release that added the row; the badge "new" follows it)
  "status": null                        // computed at build; never stored by hand (see §4)
}
```

Rules: `id` unique; `notions` non-empty for every row except `kind = meta` rows which carry exactly `["i-meta"]`; `shownOn` non-empty for every row that is not `meta` or `candidate`; every `depends.id` exists (a row, a theorem `T1`–`T20`, or a question id); `evidence.check` exists in `checks.json`.

**Splitting v15 rows.** A v15 row has one to several *lines* (theorem line, reading line, learner line …). In V2 each line that states something different becomes its own row (`GRV-012` stays for the first line; further lines become `GRV-012b`, `GRV-012c` … with `since: "v15"` and a `depends` of kind `equiv` or `derives` to the first). Lines that are the same statement in plain words become learner *texts* of the same row, not new rows. The migration script does the mechanical part (`03_MIGRATION.md` §2); the author reviews the split in the register.

## 2. `texts.json` — the words

```jsonc
{
  "row": "GRV-012",
  "lang": "en",                         // only "en" at launch; the field exists so a language is a dimension, not a fork
  "mode": "both",                       // both | phys | math
  "level": "research",                  // research | learner
  "lens": null,                         // null = the Atlas's own words; else a lens key
  "register": "full",                   // full | short (one line, for cards and heroes) | caption (for a figure)
  "body": "In the radial Kerr–Schild class the Einstein form vanishes only for f = M/ρ + (c/2)ρ²: Schwarzschild and Schwarzschild–(anti-)de Sitter.",
  "status": "human",                    // human (the author's words) | draft (a model's words, not yet reviewed) | reviewed (a model's words the author accepted)
  "source": "gravityCopy.js#GRAV2.points[4][1]"   // where the words come from (a v15 locator, a lead's RESULT.md, or "translator:<persona>@<date>")
}
```

Formulas inside `body` use the author's inline notation (`Cl(1,3)`, `E_a`, `ρ²`, `e₁₂₃`) and `$…$` for KaTeX where needed; learner texts contain no `$`, no `=` with symbols, no Greek letters used as variables (a build test enforces this).

**Lookup order** (the only fallback the app performs): `(lang, mode, level, lens)` → `(lang, both, level, lens)` → `(lang, mode, level, null)` → `(lang, both, level, null)`. If nothing is found: research level renders the row in the Atlas's own words with a drawer note "no <lens> reading yet"; learner level does not render the row at all and the page's coverage report counts it.

## 3. `lenses.json` — the registry of ways of looking

```jsonc
{
  "key": "cat",
  "name": "Category theory",
  "kind": "branch",                     // branch | shape | researcher | labels | convention
  "short": "category",
  "describes": "monoidal and super categories, Morita classes, Frobenius algebras, nerves",
  "ordering": "kind",                   // how rows reorder inside a section under this lens: none | kind | stage | grade | custom:<fn>
  "dictionary": [                       // the atlas element → the lens term (from reports/lens_dictionary.json + the readings)
    {"atlas": "clock c = p − q mod 8", "term": "Brauer–Wall class; central charge of Sem^p ⊠ Sem̄^q", "match": "exact", "evidence": ["bd·cat·9"], "rows": ["LAB-017","LAB-018"]}
  ],
  "matrixColumn": "category",           // key of the translation-matrix source whose rows this lens explains, or null
  "figures": ["cube-category","sign-flux"],  // figure ids this lens can redraw
  "translator": "persona:cat",          // id of the translation persona (09_TRANSLATION_PROTOCOL.md) or null
  "conventions": {}                     // for convention lenses: {"spaceSquare": "+1"|"-1", "time": "first"|"last", "signature": "(1,3)"|"(3,1)"}
}
```

Launch registry (keys): `alg geo top cat comb` (branches); `clifford simplex cube prime orthoplex demicube gosset` (shapes); `furey baez schuller hestenes pga roelfs tian majkic pumplun hbhl atiyah` (researchers; `atiyah` is built from Atiyah's Collected Works vol. 7 and Hitchin's account, `docs/round8/ATIYAH.md`); `bits primes sigword bitsq` (labels); `space-plus time-plus cl13 cl31` (conventions). Dictionaries: branches and the six languages come from `reports/lens_dictionary.json` (80 rows × up to 6 terms) and the 982 reading rows; researchers from the three translation matrices and the report dictionaries (`matrix/analyses_dictionaries.json` has them keyed by source).

## 4. Status — computed, never typed

Inputs: the row's `notions`, `evidence`, `kind`, `ptype`, `since`, and `checks.json` (which checks ran and passed in the last recorded run). Algorithm (the same as `labelling/merge_labels.py`, which is the reference implementation):

```
p = #notions with square +1; q = #notions with square −1; r = #notions with square 0
if kind == meta or notions == ["i-meta"]:            status = meta
elif kind in {question, conjecture, dead-end, pointer} or ptype == open:   status = open
elif row is a candidate (id starts with CAND-):      status = proved-by-atlas if a ran check passed, else candidate
elif evidence has an entry with mode "ran" whose check passed in the last run:   status = proved-by-atlas
elif evidence names a script or source with mode "read" only:                   status = cited      # "not yet proved by the Atlas"
elif kind == reading or ptype == reading:            status = ours
elif r > 0 and the row is an input (group INP) :      status = input
elif q > 0 and a standardRef was read:               status = standard
else:                                                status = ours
new = (since == latest release) or (a text of the row has status draft/reviewed newer than the previous release)
```

Notes: `input` rows (the 94 of group INP, plus any row whose only content is a choice) carry a badge naming the kind of input; rows that *use* inputs but are proved keep `proved-by-atlas` and show the inputs in the drawer, not as a badge. `cited` is the v15 "checked, script read" case the author asked to flag as not yet proved. `proved-by-atlas` requires a check that **passed in the recorded run** (`checks.json.lastRun`); a failing or missing run demotes the row to `cited` automatically.

## 5. `checks.json` and `check_runs.json` — the evidence

`checks.json` (seeded from `matrix/checks.json`): one record per script with `family`, `script`, `ids` (check ids with their one-line statements where the script prints them), `method`, `independentRoute`, `controls`, `deps`, `storedResult` (the `selfcheck/*.json` file), `rowsNaming` (row ids whose evidence names it). `check_runs.json`: one record per run of a script: `script`, `date`, `machine` (free text, no paths), `ok`, `fail`, `lastLine`, `passed` (bool), `ids` (per-id pass/fail when the script prints ids). The build computes `lastRun` per script. V2 ships with the author's shipped logs imported as the first run (gravity `logs/SUMMARY.txt`; bridges stored json; core 28/28; T-scripts and page scripts as re-run on 10 Oct 2026).

## 6. `figures.json` — drawings that state something

```jsonc
{
  "id": "clock-wheel",
  "engine": "engines/labels.js#clockWheel",   // module#function of the ported engine
  "params": {"nMax": 8},                      // defaults; the figure may expose controls
  "inputs": ["content/data/core.json#B3"],    // stored results it reads (never computed numbers typed in)
  "captionRow": "LAB-017",                    // the row whose texts caption it (research and learner captions come from that row's texts)
  "statesRows": ["LAB-017","LAB-018","ATL-004"],  // rows the figure makes visible (for the coverage test)
  "lenses": ["clifford","simplex","cube","prime","alg","cat"],  // lens keys it can redraw in (notation or vocabulary)
  "learner": true,                            // renders at learner level (with the learner caption)
  "interactive": ["n","signature"]            // controls exposed
}
```

## 7. `pages.json` — pages are queries plus layout

```jsonc
{
  "route": "steps/grav2",
  "title": {"phys": "Gravity II: the Einstein form", "math": "The Einstein form as a variation", "learner": "Gravity, part 2: Einstein's equation"},
  "stepNo": 10,                               // for the twenty steps; null elsewhere
  "needs": ["steps/grav1"],                   // the dependency map (from v15 needs strips + labelling)
  "hero": {"row": "GRV-010", "figure": "einstein-form-identity"},
  "sections": [
    {"id": "identities", "title": {"phys": "What the engine proves", "math": "Exact identities"}, "query": {"shownOn.section": "identities"}, "orderBy": {"phys": "shownOn.order", "math": "kind"}, "drawer": ["evidence","needs","depends","readings","scripts"]},
    {"id": "solutions", "…": "…"}
  ],
  "connective": {"identities": "Each identity below is checked twice: by the engine and by a route that never touches it."}  // ≤ 240 characters per section, no claim
}
```

`query` selects rows by `shownOn` (and may add `status != open` for the body; open rows render in the section's "open" fold). `role` in `shownOn`: `hero` (one per page), `result` (body), `detail` (drawer), `evidence` (drawer, under "numbers").

## 8. Other tables (seeded straight from v15)

`theorems.json` (T1–T20 as in `researchersData.js`, plus `rowsUsing`), `questions.json` (34), `sources.json` (26, with `read` true/false), `matrix.json` (131 rows × 22 columns, E/S/A, notes), `inputs.json` (the 94 input lines with their eleven kinds and the tab they belong to), `steps.json` (the twenty steps: id, no, names in both modes and learner, stage), `glossary.json` (16 terms + the labelling vocabulary, research and learner definitions), `analyses.json` (17 entries of `reports/analyses/index.json`), `reports.json` (6 + note + tutorial), `tutorials.json` (the 8 tutorials of `#/tutorials`: hand fields and the fields `tools/tutorials/registry.mjs` computes from each source, docs/round8/TUTORIALS.md), `leads.json` (the wave-3 leads: id, status, scripts, rows changed, proposed wording with source), `readings.json` (the 982 dictionary rows), `map.json` (the 63 nodes of v15's tree, kept for the Logbook's "where things were").

## 9. The address of a row (04_LABELLING.md)

Computed, shown in the drawer and the register, never typed: `cell · (p,q,r) · stage/kind · prime`, e.g. `(1,3,0) · (2,1,2) · D/theorem · 37·43·71·89·103`. The bit mask (29 bits) and the prime product are stored in the built chunks for search and for the "neighbours" navigation (rows one notion away).

## 10. Validation (run at build; fails the build)

- ids unique across `rows.json`; every reference resolves (`depends`, `evidence.check`, `shownOn.page` exists in `pages.json`, `captionRow` exists, lens keys exist).
- every row that is not `meta`/`candidate` has at least one `research` text; every page has at least its hero row with a `learner` text.
- learner texts contain no `$`, no `\\(`, no `=` between symbols, no Greek variable letters; research texts with `$` parse in KaTeX.
- `notions` ⊆ the 29 codes; `kind`, `stage`, `ptype`, `fields`, `phenomena` within their enums.
- no e-mail address, phone number or filesystem path in any content file; no history words (the v15 list, `08_BUILD_TEST.md` §4).
- the coverage invariant: every `<Statement>` in the rendered app has a row id; connective prose per section ≤ 240 characters; the rendered text of every statement equals a text record byte for byte.
- counts after migration equal the numbers in `03_MIGRATION.md`.
