<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Review guide: accepting or changing a proposed choice

1. Read `docs/round7/REVIEW_DIGEST.md`: the counts by choice, then your list, one line per paragraph (locator and id, its first words, the proposed choice, why); the full reason, with the rows and checks it names, is under the same locator in `content/story/review_proposed_a.json` or `_b.json`, and `docs/STORY_REVIEW.md` shows every entry with its proposal.
2. To accept: `node tools/accept_review.mjs --ids LNB-516,LNC-542 --dry-run` shows what would be written, the same without `--dry-run` writes it to `content/story/review.json` (select with `--ids` by id or locator, `--page <route>`, `--choice <choice>` or `--all`); `hold` is never copied, and an entry you wrote is never replaced unless you add `--force`.
3. To change a choice, write your own in `content/story/review.json` as `"<locator>": "<choice>"`: `story`, `reading`, `statement:<check id>`, `same-as:<row id>` or `drop`; to leave a paragraph held, write nothing.
4. A `reading` or `statement:` choice needs the row's labels (`notions`, a row `kind`, `stage`) in its entry of `content/story/pending.json`: the tool names the missing ones and copies nothing until they are there.
5. Then run `npm run content`; a `story` choice shows on the page after `node tools/migrate/story_from_v15.mjs <v15 root>` runs again, and only where the test of `docs/STORY_PLAN.md` §1.4 clears the paragraph in its section.
