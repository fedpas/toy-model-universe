# Explore — the plan of Round 4 (v2.1.0)

Explore is the light, playable layer of ONE RULE: a home with the **path of 8** leaves and the **shelf of 11**, one live picture per leaf, three short notes, and **three lens explorers** (the simplex as Maxwell, the demicube as motion, the cube as Maxwell). It ports the author's last trial, Octavo V₀ ("The Atlas in eight leaves"), into V2's rules: every sentence is a row, every number is computed by the kernel and tested against a standard route, every badge is computed. This file is what the builders of Round 4 read; the owners and interfaces are in `docs/BUILD_CONTRACTS.md`, "Round 4". Read §1 before anything else: it says what the pictures may print as fact.

Sources read for this plan: the V2 build book and contracts, the code a section plugs into, the Octavo hand-off (`HANDOFF.md`, `_status.txt`, `COMMON_OCTAVO.md`, the 17 leaf briefs, `survey/S2_core.md`, the Octavo kit and the two finished leaves, every WIP folder), and `content/rows.json` / `texts.json` / `derived/status.json`. The Octavo tests were re-run for this plan in a scratch copy of the Octavo base with the WIP files laid over it (numbers in §0).

---

## §0 Octavo V₀ in one page

**What it is.** A friendly front door to the Atlas, written for v16 and never released (the session limit cut 20 agents off on 10 Oct 2026, about 05:10). Eight leaves on a path (clock, moves, mirrors, half-turns, zero, light, fall, roots) and eleven loose leaves on a shelf, each hanging under the path leaf it needs (seats→5, magnets→4, charge→6, field→6, steps→6, cube→6, electron→6, springs→2, bands→2, tumbling→2, hung→2). Each leaf has a **front** ("See it": one live picture, at most one row of controls, a status line, a "Try" line, three numbered notes) and a **back** ("Say it two ways": a Mathematician panel with its own way in — geometry, algebra, topology, category or counting — and a Physicist panel, with different words and different pictures). The owner's rules: no guessing and no taking anyone's word until it checks in the Atlas; the Atlas is a guide, not an oracle ("notation only" and "open" are not walls, but nothing unchecked is printed as fact); a name can mean something (the prime names of labels, shown by a bits | numbers | primes switch); the even labels are the corners of the demicube, where the moves live.

**The leaf contract** (`base/v16/octavo/leaves/README.md`): a leaf is `<slug>.logic.js` (pure functions, no React, no randomness without a seed; every number, line and path a face prints is computed there with `labelsEngine.js`; exports `COPY = {head{see ≤ 12 words, say ≤ 14}, notes[3] ≤ 26 words, tryLine ≤ 22, panels{math, phys} ≤ 10, lens}`), `<slug>.jsx` (exports `built`, `head`, `See`, `Say`; draws only what the logic computes) and `test_octavo_<slug>.mjs` (every number recomputed by the engine **and** a standard route that does not use the bit rule's sign formula, over the whole state space the controls reach, with at least four deliberately broken copies of the logic that the checks must catch: `mutant`, `catches` in `octavo_tkit.mjs`).

**State of the 19 leaves** (`_status.txt` at the cut, and the same tests re-run for this plan):

| leaf | place | logic | test | face (jsx) | test at the cut | re-run for this plan | Round 4 |
|---|---|---|---|---|---|---|---|
| clock | path 1 | finished | `test_octavo_clock.mjs` | finished | — | 3,581 checks, 0 failures | port (X2), picture (X6) |
| moves | path 2 | finished | **none** (never written; `test_octavo.mjs` only measures its COPY) | finished | — | — | port + new test (X2), picture (X6) |
| mirrors | path 3 | WIP | none | WIP | no test | — | not in v2.1 |
| half-turns | path 4 | WIP | yes | WIP | 16,572 / 289 failures | 16,572 / 289 (label placement "keeps off the lines") | not in v2.1 |
| zero | path 5 | WIP | yes | WIP | 28,950 / 1 | 28,950 / 1: the `built` flag of the face | port (X2), picture (X6) |
| light | path 6 | WIP | yes | WIP | 3,065 / 1 | 3,065 / 1: the `built` flag | port, picture |
| fall | path 7 | WIP | yes | WIP | 2,001 / 0 | 2,001 / 0 | port, picture |
| roots | path 8 | WIP | yes | WIP | 6,443 / 0 | 6,443 / 0 | port, picture |
| seats | shelf ·5 | WIP | yes | WIP | 4,238 / 0 | 4,238 / 0 | port, picture |
| magnets | shelf ·4 | WIP | yes | WIP (built) | 13,679 / 0 | 13,679 / 0 | port, picture |
| charge | shelf ·6 | WIP | yes | WIP | 14,518 / 1 | 14,518 / 1: "the faces are built" | port, picture |
| springs | shelf ·2 | WIP | yes | WIP | 1,621 / 0 | 1,621 / 0 | port, picture |
| bands | shelf ·2 | WIP | yes | WIP | 61 / 2 | 61 / 2 (the verdict snap; the RK4 period matrix, 145 positions off) | not in v2.1 |
| field, steps, cube | shelf ·6 | WIP | none | WIP | — | — | not ported; **read** by X3 (they hold the explorers' first drafts) |
| electron, tumbling, hung | shelf | WIP | none | WIP | — | — | not in v2.1 |

The one failure of zero, light and charge is the Octavo release gate (the face's `built` flag and its headlines from `COPY`), not a check of the logic; it has no meaning in V2 (no `built`, no `COPY` on screen), so those three ports count as clean. **Ten leaves are ported in v2.1: clock, moves, zero, light, fall, roots, seats, magnets, charge, springs.**

**What carries over into V2**

| Octavo | V2 |
|---|---|
| `leaves/<slug>.logic.js` and its test with mutants | `engines/explore/leaves/<slug>.logic.js` and `tests/explore/leaves.<slug>.test.mjs`. Products re-pointed from `labelsEngine.js` to the kernel: import `mul`, `bladeMul`, `sigVec`, `mvZero`, `wedderburn`, `gaussSum`, `pg*`, `expTX`, `springX`, `squareByBitRule`, `trinityClass`, `apply`, `lcg`, `bladeName`, `popcount`, `TYPES` from `engines/labels.js` (the v15 API, every sign taken from `engines/bitrule.js`, pinned to v15 by `tests/engines.test.mjs` §H) and `sign`, `reorderSign`, `label`, `PRIMES`, `cell` from `engines/bitrule.js`; `schullerEngine`, `springEngine`, `pgaEngine`, `chargeEngine`, `maxwellData` from `engines/`; `gossetData.js` → `engines/stored.js` (GOSSET) or `checks/selfcheck/gosset.json` |
| `octavo/names.js`, the switch bits \| numbers \| primes | `engines/explore/names.js` on the kernel: bits = `label(v, 'bits', cell(n, 0))`, numbers = `String(v)`, primes = the product of `PRIMES[i]` over the bits of v (factor string = `label(v, 'primes')`); `SWITCH_PRIMES = PRIMES.slice(0, 8)` tied in the test to `checks/selfcheck/dictionary.json` `ladder[8].prime_names.switch_primes`. The page lenses `bits` and `primes` set the switch's default |
| "two ways in": Mathematician \| Physicist | V2's mode switch (math \| phys): the order and names of the rows; a leaf figure may draw the Mathematician's or the Physicist's picture by `mode` at research level (interface 18) |
| front / back | learner level / research level (Explore is entered at learner level; research is one tap on the shell's level switch) |
| the per-leaf math lens geometry \| algebra \| topology \| category \| counting | the branch lenses `geo` \| `alg` \| `top` \| `cat` \| `comb`; at research level the leaf page offers one chip "Read it in <lens>" that sets the page lens (the lens readings then show under the statements) |
| status line, aria lines computed by the logic | readouts **inside the figure** (computed, tested, never a stored sentence) |
| `COPY.notes`, `head`, `tryLine`, `panels` | not rendered. Notes become rows (their learner texts, short register when allowed: §2.4); the headline becomes the hero row; the try line becomes the notes section's connective (an instruction, ≤ 240 characters); titles are names only |
| `registry.js` (PATH, SHELF, needs, under) | `content/explore/registry.json` (slugs, names, needs, under), merged into the `explore` home entry of `pages.json` |
| `home.jsx` (dial, path, shelf, door) | `src/pages/ExploreHome.jsx` with V2 tokens; the door is a link back to `#/` |

**What does not carry over.** Octavo's palette (Paper/Night hex values, `--turn/--slide/--boost`, `--hi`), its fonts (Newsreader, Instrument Sans, Noto Sans Math), its `oc-*` classes and inline style strings (`S('…')`), its `#octavo…` routes (they become `#/explore` and `#/explore/<slug>`; the back face is the research level, not a route), its Unbuilt stubs, its `built` flags, the release-gate tests (`test_octavo.mjs`, `test_octavo_ui.mjs`), the COPY word-limit checks, and every constant sentence that states a fact (hints, captions such as "The shadow of v on the axis u … is the part that passes"). V2's tokens, shell, Statement, Badge, Drawer and FigureFrame apply. `three` is not available: every picture is SVG.

---

## §1 The Atlas rows behind the three pictures

### The printing rule (binding on every Round 4 agent)

1. **A leaf's notes are rows.** They render as `Statement`s of existing rows (preferred) or of new rows that X4 adds with evidence. The words on screen are the row's text record (research, learner, or learner short); nothing else states a law.
2. **A printed number is computed by the kernel** (through `engines/bitrule.js` or an engine that imports it) **and tied in a test to a standard route or a stored check result** (`checks/selfcheck/*.json`). Readouts inside figures follow the same rule.
3. **What the rows do not state is not printed**, or it is printed only as the row that carries it, with that row's badge (`open`, `our reading`, `not yet proved here`, `needs an input`). A connective may say, in so many words, "The Atlas does not state this." (≤ 240 characters, no claim of its own).
4. The status words come from `content/derived/status.json`; nobody types a badge.

Status abbreviations below: **P** proved-by-atlas (no badge), **S** standard (no badge), **I** input ("needs an input: …"), **O** ours ("our reading"), **C** cited ("not yet proved here"), **Op** open, **M** meta. "no L" = the row has no learner text yet (X4 drafts one, §2.4).

### (a) The n-simplex as the picture of Maxwell in n + 1 dimensions

| row | status | what it states |
|---|---|---|
| MAP-004 | P · no L | Maxwell in 1–4 space and 1–4 time dimensions: the algebra view, which sees the signs, and **three notations for the same labels (simplex, cube, whole numbers), which depend only on how many generators there are**; the step each new generator adds; the mirror world. |
| MAP-003 | P · no L | ∇F = J on **every split with k, d ≤ 4 and k + d ≤ 7**; **n·C(n,2) incidences (2, 9, 24, 50, 90, 147)**; two sign choices reproduce it (q → −q), a positive field energy fixes source against force; the mirror Cl(q,p) gives the same system; the time ladder Cl(k,1) to k = 11. |
| EQN-006 | P | ∇F = J (Calibration 1), cells n = 2 to 7; 6 field parts and 24 incidences in 4D (hero of `/light`). |
| ATL-017 | P | F is a grade-2 element of a 4D spacetime algebra with 6 components (Cl(1,3) or its mirror Cl(3,1)); ∇F = J; dF = 0 and d⋆F = J are its grade-3 and grade-1 parts; Calibration 1 checks every term. |
| MAP-013 | P · no L | Even blades: 2ⁿ⁻¹ vertices; Cl⁰(p,q) = Cl(p,q−1); **in Maxwell F is even and ∇F = J maps even to odd**. |
| EQN-001 | P | Two field components share an equation exactly when they share an index — the same graph as the non-commuting pairs: 12 edges at n = 4; equal counts for n = 3…7. |
| PAG-008 | P | Every term and the wave equation, with the signs found by search against the textbook equations; nothing is predicted. |
| PAG-011 | P | The wave operator is elliptic, hyperbolic or ultrahyperbolic by signature; without null generators **hyperbolic exactly for Lorentzian signatures**. |
| INP-004 | I · no L | F is a bivector (grade 2) and J a vector (grade 1): **the grades are assigned, not found** ("F on the edges" rests on this input). |
| INP-011 | I · no L | Which sign is called time, and Cl(k,d) against its mirror Cl(d,k), are conventions; only a Lorentzian split gives a hyperbolic wave operator. |
| ATL-017b | O | Placing electromagnetism at the cell Cl(3,1) (the card name "EM Maxwell") is ours. |
| PAG-023 | O | Reading the derivative and coupling terms as edges and corner simplices of the cube is ours. |
| GRV-001b, YM-008 | O | The axis simplex in gravity and in Yang–Mills: readings, not results. |
| RSN-025 | C · no L | ∇F = J for a bivector in n = k + d generators; ∇∇F = □F and charge conservation hold — **carries no evidence**, although `maxwell.json` stores `wave_equation` and `charge_conservation` true in all 15 cells (decision A25). |
| GOS-004 | S | Maxwell view of E8: nothing comes back (F has four generators, E8 needs sixteen). |

**May be printed as fact:** for n = 1, 2, 3, 4 with one time generator (Cl(1,n)), the n-simplex carries F on its C(n+1,2) edges, J on its n + 1 vertices and dF = 0 on its C(n+1,3) triangles; each edge meets its two ends by contraction and the n − 1 triangles through it by wedge; the incidences number 2, 9, 24, 50 (MAP-003, MAP-004, EQN-006), every sign from the kernel equal to `checks/selfcheck/maxwell.json` (cells `1,1` … `1,4`). That F is even and its equation lands in the odd half (MAP-013). That only one-time splits are hyperbolic (PAG-011).

**The Atlas does not state:** that the simplex *is* the picture of Maxwell (it is one of three notations of the labels, and it does not see the signs: MAP-004); Maxwell with d > 4, k > 4 or k + d > 7 (no stored cell; `maxwell.json` `ladder` goes to Cl(1,8) for counts only, and no row prints them); anything physical for splits with two or more time generators (stored cells (2,4), (3,3), (4,2), (3,4), (4,3) are algebra only: PAG-011, INP-012 is a dead end); that "F lives on the edges" is found rather than assigned (INP-004). The simplex explorer therefore stops at n = 4 with one time generator.

### (b) The demicube as the picture of motion in spacetime

| row | status | what it states |
|---|---|---|
| MIR-001 | P | The corners of the n-cube are sign patterns; the layers by number of mirrors are the binomial counts; **the even half is the demicube**; reading the layers as numbers of mirrors is a relabelling; Bₙ and Dₙ are textbook. |
| EQN-014 | P | Mirrors x ↦ −a x a⁻¹, versors, Cartan–Dieudonné, n = 2 to 8; **in 4D: 16 corners, 8 rotors, 8 reflections, at most 4 mirrors**. |
| MIR-002 | P | Two mirrors at any angle give any rotation in their plane; the commutator graph of step 2 is the algebra of these rotations. |
| RSN-007 | P · no L | A corner of the n-cube is the product of the coordinate mirrors on its axes; Cartan–Dieudonné checked exactly for n = 2…5. |
| MAP-013 | P · no L | Even blades: 2ⁿ⁻¹ vertices; Cl⁰(p,q) = Cl(p,q−1) for q ≥ 1. |
| EQN-002 | P | At n = 4 the **16-cell** has the scalar and the pseudoscalar at two poles and the **six bivectors as its equator**; the equator octahedron has 12 edges; the three commuting pairs are its antipodes. |
| LNS-020, ATL-008 | P | The even part of Cl(1,3) is Cl(1,2) ≅ M₂(ℂ); **its unit even versors, generated by the six bivectors, form SL(2,ℂ), the spin group of special relativity**. |
| LNC-121 | S | Cl⁰(1,3) ≅ Cl(1,2); its even elements of norm 1 form Spin⁺(1,3) ≅ SL(2,ℂ). |
| LAB-015 (= PAG-031) | P | The sign −1, +1, 0 of the square of a vector or a **simple** bivector is rotation, boost, translation; **from n = 4 these three are no longer enough**. |
| RSN-010 | P · no L | n = 2: X = a e₁ + b e₂ + c e₁₂ squares to a² + b² − c²: rotation, translation, boost. |
| MAP-017 | P · no L | ψ even in Cl(1,3): its 8 components are the 8 corners of the demicube (Dirac). |
| YM-003 | P | Generators and their commutator pairs are corners and edges of the demicube. |
| GOS-001, MIR-003, SHP-006 | P | The 8-demicube is the 128-corner half of the 240 roots of E8; their mirrors permute the 240. |
| INP-018 | I | The reflection formula x ↦ −a x a⁻¹ fixes one of two sign conventions (Pin against its twin). |
| INP-020 | I | A time orientation e_t is chosen. |
| INP-078 (and INP-073) | I | The versor condition uses the reversion, a choice. (Not needed when the explorer moves points by two mirrors.) |
| LAB-003 | P (see A26) | "Reading the signs −1, +1, 0 of a square as rotation, boost, translation"; a run check lifts it to proved-by-atlas, so it shows no badge, while its learner text ends "is ours". |
| MIR-005, PAG-019 | O | Mirrors are a tool for rotations here, not a field; even blades as fields and odd as sources is ours. |
| GRV-004, GRV-001b, YM-008, CPL-010, MAT-008 | O | Other terms drawn on the demicube: readings. |
| MAP-016, MAP-011 | C | Bivectors anticommute exactly when they share one index; the Lorentz algebra from boosts and rotations / the cube seen from its even half. |

**May be printed as fact:** the even labels of n generators are the 2ⁿ⁻¹ corners of the n-demicube (MIR-001, MAP-013): a segment {0, 3} at n = 2, a tetrahedron at n = 3 and the 16-cell at n = 4 (`shapes.json`: `demicube_is_simplex_at: [3]`, `demicube_is_orthoplex_at: [4]`; EQN-002); in Cl(1,3) the six plane corners are the six bivectors, the unit even versors they generate are the spin group of special relativity (LNS-020); a plane squaring to −1 turns, to +1 boosts (LAB-015, for simple planes only); two mirrors make a rotation in their plane (MIR-002); 8 rotors and 8 reflections in 4D (EQN-014). Every square, product and count from the kernel and tied to `mirrors.json`, `shapes.json`, `maxwell.json` (cell `1,3` blade squares).

**The Atlas does not state:** that the demicube *is* the picture of motion in spacetime (no row; as a sentence it is a reading: a new row of kind `reading`, status ours, if the author wants it — A22); that a move in one plane "lives on the edge" between the identity corner and its plane, or that moves "multiply like corners" (Octavo's Cube brief computed and tested these in the leaf: they are not Atlas rows — A23); that **two mirrors make a boost** (`mirrors.json` stores the example `boost_5_4_3_4`, normals (1/4, −5/4) and (−2, 4), matrix ((5/4, 3/4), (3/4, 5/4)), but no row says it — A24); that two boosts in different directions leave a turn (Wigner rotation: not in the Atlas); that a boost keeps the light lines (no row); anything about general 4D bivectors (non-simple; the isoclinic case is unproved, T17). The explorer moves only along single coordinate planes and prints the boost example only as numbers until A24 is decided.

### (c) The n-cube as the picture of n-Maxwell

| row | status | what it states |
|---|---|---|
| MAP-004 | P · no L | The cube is one of the three notations of Maxwell's labels in 1–4 space and 1–4 time dimensions. |
| MAP-003 | P · no L | ∇F = J on every split k, d ≤ 4, k + d ≤ 7; n·C(n,2) incidences (2, 9, 24, 50, 90, 147) — on the cube, **the edges that leave the layer of F**. |
| EQN-006 | P | Cells n = 2 to 7; 6 and 24 in 4D. |
| MAP-013 | P · no L | F is even and ∇F = J maps even to odd: every move crosses between the two halves of the cube. |
| CPL-001 | P | Maxwell → Dirac: the coupling reuses the n cube edges at each corner; only a factor A is new. |
| EQN-001 | P | Components share an equation iff they share an index (12 edges at n = 4). |
| LNC-056 | P | The labels ordered by inclusion are the Boolean lattice; the edge a → a ∪ {i} gets the bit-rule sign (the Jordan–Wigner string); every square anticommutes; unique up to gauge; the same signs give the Koszul boundary, which squares to 0. |
| SHP-007 | P | The cube category: one arrow S → T for S ⊆ T, 3ⁿ arrows; an arrow is a cube face. |
| SHP-001 | P | The orthoplex is the dual of the cube: its 2ⁿ facets match the cube's corners (the blades). |
| PAG-023, CPL-010 | O | Drawing derivative, coupling and mass terms as cube edges is ours. |
| INP-004, INP-011 | I | F is assigned grade 2; which sign is time is a convention. |
| RSN-025 | C | ∇∇F = □F and charge conservation (no evidence: A25). |
| PAG-003 | O | Prime labels are notation only (for the primes printing). |
| ATL-022, ATL-022b | Op | The counting facts 70 and 1120, and the number 210: open. Not printed. |

**May be printed as fact:** for every stored split (k, d ≤ 4, k + d = n ≤ 7) the 2ⁿ labels are the corners of the n-cube in layers 1, n, C(n,2), …; F occupies layer 2, J layer 1, dF layer 3; the n·C(n,2) incidences are the cube edges that leave layer 2, each with the kernel's sign (equal to `maxwell.json`, all 15 cells); every move changes the parity of the label (MAP-013). The edge signs of the whole cube are the Jordan–Wigner string and the boundary squares to 0 (LNC-056).

**The Atlas does not state:** "n-Maxwell" in the sense of a field of another grade (p-form electrodynamics) — no row; the explorer keeps F at grade 2 and has no layer picker (A27); Maxwell beyond n = 7; anything physical for splits with two or more time generators (PAG-011); the cube as *the* picture (notation: MAP-004).

### Octavo's own statements, checked against the rows

| Octavo (HANDOFF §2) | in V2 |
|---|---|
| (3) prime names; name(a XOR b) = a·b/gcd² | checked by `dictionary_selfcheck.py` for 65,536 pairs (`dictionary.json` `ladder[8].prime_names`), but no row states it; PAG-003 (O): "prime labels are notation only"; `prime_scan.note`: the names depend on the vertex order. Printed as labels (D8); a sentence about the rule needs a new computation row citing `dictionary_selfcheck` (X4 may add it: A28); nothing about meaning |
| (3) "210" as the name of the four-switch volume | ATL-022b (Op): 210 is not derived. Print the number only as a label under the primes lens, never commented |
| (4) even labels = demicube corners; E8's 128 = 8-demicube; chooser segment / tetrahedron / 16-cell | MIR-001, MAP-013, GOS-001, MIR-003, EQN-002, `shapes.json` (P) |
| (4) moves live on the demicube and multiply like its corners | not a row (A23) |
| (5) the Monster guess | stays out: no row (INP-079, LAB-010 only quote the Monster's order); nothing on any page (A29) |

---

## §2 Explore in V2

### 2.1 Routes and pages

| route | page kind (`pages.json` `kind`) | renders |
|---|---|---|
| `#/explore` | `explore-home` | `src/pages/ExploreHome.jsx`: the path of 8 (always 8 cards; a leaf without a page is a quiet card "not drawn yet", no link), the shelf (only leaves with a page), the three lens explorers, a link back to `#/` |
| `#/explore/<slug>` | `leaf` | `src/pages/ExploreLeaf.jsx` (§2.2) |
| `#/explore/simplex-maxwell`, `#/explore/demicube-moves`, `#/explore/cube-maxwell` | `explorer` | the same component as a leaf, without path navigation |

`src/app/router.js` gets one line: `if (a === 'explore') return b ? { name: 'leaf', page: segs.join('/') } : { name: 'explore', page: 'explore' };` (placed before the generic pages lookup); `src/app/App.jsx` two cases. The shell's Contents menu lists `explore` once and hides the pages of kind `leaf` and `explorer`. **Learner level is the default entry**: every link into Explore from outside it (the Contents menu, the Zero page) carries `l=learner`, keeping mode, lens and theme; a deep link keeps its own `l`; there is no route-level default (it would change what the coverage test renders without `l`).

A leaf or explorer entry of `pages.json` (X4 writes it in `content/explore/pages.json`; `tools/merge_explore.mjs` merges it):

```jsonc
{
  "route": "explore/moves", "kind": "leaf",
  "title": { "phys": "Three moves", "math": "Three moves", "learner": "Three moves" },   // a name, never a claim
  "stepNo": null,
  "needs": ["explore/clock"],                         // Octavo's needs, as routes (the header's "Builds on" chips)
  "hero": { "row": "LAB-015", "figure": "leaf-moves" },
  "sections": [
    { "id": "notes", "title": { "phys": "Three notes", "math": "Three notes" }, "query": { "shownOn.section": "notes" }, "drawer": ["evidence","needs","depends","readings","numbers","address"] },
    { "id": "two-ways", "title": { "phys": "The physicist's way", "math": "The mathematician's way" }, "query": { "shownOn.section": "two-ways" }, "drawer": ["evidence","needs","depends","readings","numbers","address"] }
  ],
  "connective": { "notes": "Press + until the strength passes zero, then press Play." },   // the try line: an instruction, ≤ 240 characters
  "explore": { "slug": "moves", "path": 2, "under": null, "lens": "geo", "rests": "LAB-015" }
}
```

`explore.rests` is an existing row whose home (`rowHome`, the lowest `shownOn.order`) is a page of the full Atlas: "Connect to the full Atlas" links there with `at=<row>`. The home entry (`route: "explore"`, `kind: "explore-home"`) carries `explore.map` = the registry (path: `{n, slug, name, needs}`, shelf: `{slug, name, under}`, lenses: `{slug, name}`), merged from `content/explore/registry.json`.

### 2.2 The leaf page

`ExploreLeaf` builds the page model with `buildPageModel(route, settings, { custom: ['notes'] })` and renders `PageView` with:

- **heading** — eyebrow "Leaf 2 of 8" / "On the shelf · hangs under Leaf 5" / "Lens explorer"; title from `pages.json`; the needs chips.
- **hero** — the leaf figure first and wide (Octavo: "the picture is the first thing under the headline"; done by CSS order in `explore.css`, without touching `Hero.jsx`), then the hero row (`Hero` already prefers its short register), then, at learner level, the computed "How do we know?" line (`howWeKnow`, unchanged).
- **notes** — a `custom` renderer for the section `notes`: each row as `<Statement id register={short ? 'short' : 'full'} />` where `short` = the row has a learner text in the short register and the level is learner; at research level always `full`. No numbering (05 §8). The section connective is the try line. At least three rows with a learner text, or the page shows "This page has no plain-words version yet" at learner level.
- **two ways** — the generic section; rows ordered by mode (physics by the placement order, mathematics by kind then field, as `sortEntries` does); at research level the chip "Read it in <lens>" (`explore.lens`; greyed with "no readings yet" when the page has none in that lens, as `LensPicker` counts them).
- **open fold** — as on every page ("Not finished yet" at learner level).
- **loose leaves that hang here** (path leaves) — chips to the shelf leaves whose `under` is this leaf and that have a page.
- **navigation** — ← previous path leaf · Connect to the full Atlas · next path leaf → (shelf leaves: ← the shelf · Connect · back to the leaf it hangs under).

No component writes a sentence that states a law. Chrome words (eyebrows, "Builds on", "Connect to the full Atlas", "not drawn yet", "Read it in geometry") are connectives within the coverage budget.

### 2.3 Figures

- **Ids**: `leaf-<slug>` for the ten leaves; `lens-simplex-maxwell`, `lens-demicube-moves`, `lens-cube-maxwell` for the explorers.
- **Components** under `src/figures/explore/leaf/` (X6) and `src/figures/explore/lens/` (X3), registered through `src/figures/explore/index.js`, which `src/figures/index.js` spreads into `FIGURES` (one line, written in step 0). Props as interface 2, plus `mode` (`FigureFrame` passes it; a figure that ignores it draws the same picture). Every figure sets `Component.meta = { id, lenses, learner: true }` and `Component.data(params)`.
- **Seeds** in `content/explore/figures.leaf.json` (X6) and `figures.lens.json` (X3), merged into `figures.json`. `captionRow` = the page's hero row (fixed in §2.8 and §2.6, so the figure is the hero figure); `statesRows` = the rows the picture makes visible.
- **Controls**: the ports of Octavo's front controls, at **both levels** (Explore is played at learner level; this amends 05 §6 for explore figures only). Every Octavo slider becomes chips (≤ 9 values) or a stepper: one entry per param, one control kind, and D18 forbids sliders at learner level. Entries carry `from: "octavo/leaves/<slug>.jsx: <control>"`. The lens explorers' **lens picker is `FigureFrame`'s lens chips** (shape lenses simplex | cube | demicube | orthoplex are shown at learner level already): no new control; selecting a chip sets the page lens and the figure redraws (`lens` prop). The picks a, b and the steppers n, k are ported from the Steps and Cube leaves.
- **Look**: tokens only (`--fg --muted --line --line-2 --accent --panel`, clock colours only for c = 0…7). Turn, boost and slide are told by **mark and word**, never by colour: turn = ring with "−1", boost = diamond with "+1", slide = bar with "0" (classes `.mv-turn .mv-boost .mv-slide` in the explore figure stylesheets). `--accent` marks the selection only. Kinds ℝ ℂ ℍ by letter. Text ≥ 11 px at 390 px width. Animations start paused (`usePlayer`), respect reduced motion.
- **Readouts** inside a figure are computed by the logic and tested; they never hold 40 characters of a row's text (the coverage leak rule reads figure text too).

### 2.4 Content: tables, overlay, new rows, learner texts

Explore's content lives in an **overlay** that survives a re-migration (`tools/migrate/run_all.sh` regenerates `rows.json`, `pages.json`, `figures.json` from v15):

```
content/explore/registry.json      the path, the shelf, the explorers: slugs, names, needs, under
content/explore/pages.json         the home, the leaf and the explorer entries (§2.1)
content/explore/placements.json    [{ row, page, section, order, role }] added to existing rows' shownOn (order ≥ 1000, so no row's home moves)
content/explore/rows.json          new rows (since "v2.1"), full records of 02 §1
content/explore/texts.json         research texts of the new rows (status "draft", source "explore:X4")
content/explore/figures.leaf.json  seeds of leaf-* (X6)          content/explore/figures.lens.json  seeds of lens-* (X3)
content/texts_learner_explore.json learner drafts (through the 13-rule checker, merged by merge_learner_texts.mjs)
```

`tools/merge_explore.mjs` (X4) merges the overlay into `rows.json`, `pages.json`, `figures.json`, `texts.json`, idempotently (replace by id / route / row+key; placements added once), and runs before `build_content.mjs` in `npm run content` and after `figures_from_v15.mjs` in `run_all.sh`.

**New rows** only when a note is not an existing row: natural group, id above the v15 range (e.g. `MIR-007`), `since: "v2.1"`, `notions`/`kind`/`stage`/`ptype` labelled as in `docs/04_LABELLING.md`, evidence = a check of `checks.json` that computes the statement (mode `ran`), else the row is a reading (ours) or a question (open). Facts computed only by the explore tests are **not** rows (A23); the figures may draw them.

**Status of new rows** (X4, `tools/build_content.mjs`): today a row reaches `proved-by-atlas` only through its v15 flag `checked`, so a new row with a check that ran would come out `ours`. The amendment applies 02 §4 to rows without legacy flags: a `ran` check that passed → proved-by-atlas; only `read` → cited; kind/ptype reading → ours; question, conjecture, pointer or ptype open → open; group INP → input; a read `standardRef` → standard; else ours. The `new` badge covers `since ∈ {v16, v2.1}` (L4). The 1,013 existing rows keep their status (X4 verifies `status.json` unchanged for them).

**Learner texts**: (1) full-register drafts for the existing rows Explore shows that have none (§1 "no L": MAP-003, MAP-004, MAP-013, MAP-017, RSN-007, RSN-010, RSN-025, INP-004, INP-011, and those of §2.8); (2) drafts for the new rows; (3) **short-register** drafts — Octavo's notes, in ≤ 30 words, same statement, status words kept — only if the lead extends the checker (L2). The `COPY.notes` of each Octavo leaf are the starting wording; a note that says more than its row is cut or dropped, never stretched.

### 2.5 Engines

- `engines/explore/leaves/<slug>.logic.js` (X2): the Octavo module with the same exports and return shapes, minus `COPY` and every constant sentence; imports as in §0; no sign or parity loop of its own (`tests/shipped.test.mjs` rule 4 scans `engines/`): the reversion sign in charge becomes the kernel's `reorderSign(m, m)`, the Walsh sign in springs `springEngine.walsh`, Jordan–Wigner signs come from `mul`.
- `engines/explore/names.js`, `shared.js` (Octavo's `KIND`, `algebra`, `num`, `hourStep` … without hex colours), `index.js` exporting `LEAF_LOGIC = { clock, moves, … }` (X2).
- `engines/explore/lens.js` (X3): the explorers' numbers on `maxwellViews(k, d)`, `mirrors(n, q)`, `zonogon(n)`, `twoMirrors`, `MIRROR_EXAMPLES` (`engines/labels.js`) and the kernel.

### 2.6 The three lens explorers

All three are pages of kind `explorer` with the leaf frame. The lens chips simplex | cube | demicube | orthoplex (and, at research level, bits | primes for the printing of labels) redraw the same data; the explorer's own view is its default (no lens, or its own lens).

**A — `lens-simplex-maxwell`, route `explore/simplex-maxwell`** (picture (a))
- *Drawn*: the n-simplex for n = 1…4 (Cl(1,n): vertex t on top, x, y, z, w), J on the vertices (ρ filled, J_i ring), F on the edges (E: one time index, filled; B: none, ring), dF on the triangles (shaded faces). A picked piece a (an edge) and axis b (a vertex direction) light one incidence: a contraction (solid arrow to the end of the edge, "drop b") or a wedge (dashed arrow into the triangle through the edge, "add b"), with its sign. Counts under the drawing: pieces C(n+1,2), sources n + 1, triangles C(n+1,3), incidences (n+1)·C(n+1,2).
- *Controls*: `n` chips 1–4; `a` pick (an edge); `b` chips (the axes); `mirror` button (k, d) → (d, k), ported from four-views-maxwell. Lens chips: **cube** (labels as corners of the (n+1)-cube; F = layer 2; the incidence is the edge to the flipped corner), **demicube** (F among the even corners; the move leaves the half), **orthoplex** (a label is the facet with + poles on its bits; a move crosses one ridge), **primes** (drop = ÷ the axis prime, add = ×).
- *Kernel*: `maxwellViews(1, n)` and the mirror; signs by `sign(1<<b, a, eps)`.
- *Caption row*: MAP-004. statesRows: MAP-004, MAP-003, EQN-006, ATL-017, MAP-013. Page rows: notes MAP-004 (hero), EQN-006, MAP-003, ATL-017; two ways MAP-013, EQN-001, PAG-011, INP-004 (badge: needs an input: grade of a field), INP-011, PAG-023 (our reading), ATL-017b (our reading); RSN-025 (not yet proved here) only if A25 is not taken. `rests`: EQN-006 (`/light`).
- *Must not print*: anything beyond n = 4, or a multi-time split as light; that the simplex is *the* shape of light.
- *Tests* (X3): every incidence, sign, target and count equal to `maxwell.json` cells `1,1`–`1,4` and their mirrors; counts 2, 9, 24, 50 = MAP-003; ≥ 4 mutants (contract ↔ wedge, a sign, an off-by-one in the triangle count, time as the wrong vertex).

**B — `lens-demicube-moves`, route `explore/demicube-moves`** (picture (b))
- *Drawn*: the n-demicube of the even labels of Cl(1, n−1) for n = 2, 3, 4: a segment {0, 3}, a tetrahedron {0, 3, 5, 6}, the 16-cell {0, 3, 5, 6, 9, 10, 12, 15} drawn as an octagon with the identity on top and the 4-volume at the bottom, the three boost planes facing the three turn planes, the six edges out of the identity bold. Plane corners marked by the sign of their square (diamond "+1" boost / ring "−1" turn). Beside it the spacetime picture of the move: for n = 2 events in the (x, t) plane with the light lines dashed; for n = 3 a square in (x, y) with time up; for n = 4 a cube with each corner's new time printed. The move is made by two mirrors (half the angle or rapidity apart); its two weights (cos, sin or cosh, sinh of half the amount) are bars on the identity corner and the plane corner. A second picked plane shows the corner their product lands on, with its sign.
- *Controls*: `n` chips 2–4; `a` pick (a plane corner); `amount` chips (turn: 0°, 30°, 60°, 90°, 120°; boost: speeds 0, 0.2, 0.4, 0.6, 0.8 of light); `b` pick (a second plane corner, for the product). Lens chips: **cube** (all 2ⁿ corners, even filled, odd rings: the mirrors-cube view), **simplex** (the even faces of the (n−1)-simplex: planes = edges, the 4-volume = the whole), **orthoplex** (the even facets; at n = 4 the 16-cell again), **primes** (the 16-cell corners named 1, 6, 10, 14, 15, 21, 35, 210; products as a·b/gcd²).
- *Kernel*: even labels and edges (`zonogon`, `mirrors(n, n−1)`), squares `sign(b, b, eps)`, products `bladeMul`, the two mirrors and their product by `mul` in Cl(1, n−1), applied to points; the stored examples `MIRROR_EXAMPLES`.
- *Caption row*: MIR-001. statesRows: MIR-001, MAP-013, EQN-002, EQN-014, LAB-015, LNS-020. Page rows: notes MIR-001 (hero), EQN-002, LNS-020, LAB-015; two ways MIR-002, EQN-014, RSN-007, MAP-013, LNC-121, MAP-017, GOS-001, INP-018, INP-020 (needs an input), MIR-005 and PAG-019 (our reading), MAP-016 (not yet proved here); a new row for the stored boost example if A24 is taken. `rests`: MIR-001 (`/steps/mirrors`).
- *Must not print*: "moves live on edges / multiply like corners" as a sentence (A23); the Wigner rotation; anything for non-simple planes; "the demicube is the picture of motion" except as the reading row of A22.
- *Tests* (X3): corner counts = `mirrors.json` ladder rotors (2, 4, 8); `demicube_is_simplex_at`/`_orthoplex_at` = `shapes.json`; the 16-cell's 24 edges and degree 6 by direct count, its equator (12 edges, 3 antipodal commuting pairs) = EQN-002; plane squares = `maxwell.json` cell `1,3` blade squares; the two-mirror product equals the textbook Lorentz boost (cosh, sinh of the rapidity) and rotation matrices, preserves the interval on every pair of points, has determinant +1 (one mirror −1); the stored `boost_5_4_3_4` and `rotation_3_4_5` reproduced; the product table of the even corners against explicit matrices (2 × 2 complex for n = 3; 4 × 4 real or the Dirac matrices for n = 4); ≥ 4 mutants (factor 2 between mirror angle and move, tanh ↔ sinh, mirror sign x ↦ a x a⁻¹, odd labels taken as the demicube, an edge between corners one bit apart).

**C — `lens-cube-maxwell`, route `explore/cube-maxwell`** (picture (c))
- *Drawn*: the n-cube of the labels of Cl(k, d) for n = k + d = 2…7, as layers by grade (columns 1, n, C(n,2), …; oblique projection for n ≤ 4); layer 2 = F (E filled, B ring, T square for two time indices), layer 1 = J, layer 3 = dF; the n·C(n,2) incidences as the edges that leave layer 2, solid down (contract), dashed up (wedge); the even half filled, the odd half hollow. A picked corner a and axis b show the step e_b e_a = ± e_{a xor b}.
- *Controls*: `n` chips 2–7; `k` chips 1–4 (only splits with d ≤ 4 enabled); `a` pick (a corner); `b` chips (the axes). Lens chips: **simplex** (explorer A's view for the same split), **demicube**, **orthoplex**, **bits | primes** (printing).
- *Kernel*: `maxwellViews(k, d)`, layers by `popcount`, signs by the kernel.
- *Caption row*: MAP-003. statesRows: MAP-003, MAP-004, EQN-006, MAP-013, CPL-001, LNC-056. Page rows: notes MAP-003 (hero), MAP-004, MAP-013, LNC-056; two ways CPL-001, EQN-001, SHP-007, SHP-001, PAG-011, INP-004, INP-011, PAG-023 and CPL-010 (our reading), PAG-003 (our reading, printed only under the primes lens). `rests`: EQN-006 (`/light`).
- *Must not print*: a layer picker or any grade other than 2 for F (A27); n > 7; physics for k ≥ 2.
- *Tests* (X3): all 15 stored cells of `maxwell.json` (incidences, signs, targets, ops, counts E/B/T, layers); counts = MAP-003; Jordan–Wigner edge signs = `reorderSign` and every square anticommutes (LNC-056) by direct enumeration; ≥ 4 mutants (XOR → OR, a sign flipped, layer 2 off by one, wedge and contract swapped).

### 2.7 Tests

| file | owner | checks |
|---|---|---|
| `tests/explore.test.mjs` | X5 | the runner: runs every `tests/explore/*.test.mjs`, sums, exits 1 on a failure; in `npm test` |
| `tests/explore/tkit.mjs` | X2 | Octavo's helpers on the V2 tree: `tally`, `seeded`, `mutant(rel, patches)` (rel from the repository root), `catches`, `typeByInvariants`, `TEXTBOOK`, `engineKind`, `sameType`, `eigenvaluesSymmetric` |
| `tests/explore/leaves.<slug>.test.mjs`, `names.test.mjs` | X2 | the ported checks and mutants; the Octavo-only checks (COPY limits, registry, `built`, the face) removed and counted in X2's report |
| `tests/explore/lens.test.mjs` | X3 | §2.6 |
| `tests/explore/pages.test.mjs` | X5 | every explore page: hero row exists, its figure is the leaf's; ≥ 3 note rows with learner texts; titles are names (no digit, ≤ 40 characters, not a sentence); try lines ≤ 240 characters and hold no 40 characters of a record; `rests` is an existing row whose home is not under `explore/`; placements have order ≥ 1000; every registry slug with a page has a figure seed; new rows have `since: "v2.1"` and a research text |
| `tests/coverage.test.mjs` | X5 | covers the explore routes already (they are `pages.json` routes, rendered in every lens, and its rules — statement = record, badges as computed, connective budget, no row words outside a statement — apply unchanged); add: on a leaf at learner level a note renders the short register exactly when the row has one, the full one otherwise |
| `tests/figures.render.test.mjs` | X5 | PARAMS for the 13 explore figures; both modes; the tokens rule recursive into `src/figures/explore/**`; controls at learner level allowed for `leaf-*` and `lens-*` (never a slider) |
| `tests/shipped.test.mjs` | X5 | the budget of L1; rule 4 over `engines/explore/` and `src/figures/explore/`; licence headers on every new file |
| `tests/ui/explore.smoke.test.mjs` | X1 | Playwright: `#/explore`, two leaves and one explorer at 390 and 1366 px, light and dark, from `file://`; no console error, no overflow; the level switch reaches research; "Connect" lands on the step page with the row targeted |

### 2.8 The ten leaves

Candidate rows are starting points for X4 (status today; "no L" = learner draft needed). The hero row is also the figure's `captionRow`.

| leaf | needs / under | figure controls (params) | hero (candidates) | notes (candidates) | rests | lens |
|---|---|---|---|---|---|---|
| clock | — | `p`, `q` steppers (each ≤ 16, sum ≤ 20); `hour` pick; `eight`, `swap` buttons | LAB-017 (P) | LNC-101 (P: plus forward, minus back, zero stays), PAG-004 (P: the type of every cell), GEN-009 / ATL-023 (P: period 8), LAB-018 (P), LAB-002 (M) | LAB-017 `/clock` | comb |
| moves | 1 | `k` chips −2…2 by 0.5; play | LAB-015 (P) | RSN-010 (P, no L), EQN-018 (P: oscillator, inverted, free), LNB-023c (P: ellipse, parabola, hyperbola by the sign of E), LAB-003 (A26) | LAB-015 `/clock` | geo |
| zero | 1 | `eps` pick per switch (+ − 0); `a`, `b` corner picks | LNC-101 (P) | LNC-014, LNC-019, LNC-102 (P), RIG-007 (P: the slide) | LNC-101 `/steps/category` | alg |
| light | 2, 5 | `p`, `q` steppers (2 ≤ p + q ≤ 5); play | LNS-102 (P) | PAG-011, LNS-012, NUL-010 (P); PAG-034 (Op, fold) | PAG-011 `/light` | geo |
| fall | 2, 5, 6 | `r` chips 0.4…3 (r/2M); play | LAB-005 (P) | RSN-017 (P, no L), NUL-001 (P), RSN-015 (P, no L) | LAB-005 `/steps/gauge` | geo |
| roots | 1, 3 | `fam` chips (two switches / half-cube corners / all); `root` pick | SHP-006 (P) | GOS-001, MIR-003, LNC-042 (P); not LNC-047 or PAG-020 (the "same 8 as the clock" stays out) | SHP-006 `/shapes` | comb |
| seats | under 5 | `seat` pick; `op` add / take; `names` chips bits \| numbers \| primes | LNS-129 (P) | LNS-130, LNS-005, LNS-019c (P); PAG-003 (O) beside the names | LNS-129 `/steps/schuller` | alg |
| magnets | under 4 | `m1`, `m2`, `m3` picks (up, right, down, left); play | LNS-134 (P) | LNS-135, LNS-021 (P); SPN-004 (Op, fold: probability beyond Cl(3,0)) | LNS-134 `/steps/schuller` | geo |
| springs | under 2 | `label` chips 000…111; `pluck` toggle with `corner` pick; play | EQN-018 (P) | MAP-026 (P, no L), SPR-003 (P, kind reading), SPR-004 (P), SPR-002 (O) | EQN-018 `/steps/spring` | comb |
| charge | under 6 | `E`, `B` steppers; `preset` chips (B only, E only, crossed); play | PAG-009 (P) | RSN-026 (P, no L), PAG-008, ATL-017 (P), INP-007, INP-008 (I) | PAG-009 `/light` | geo |

Octavo statements without a row (drop, or keep only as a computed readout of the figure): springs "each 1 stretches four more springs"; charge "the sign of E² − B² decides: below zero it circles, at zero it slides off, above zero it runs away" (the brief itself asked to confirm it with the engine first); fall "the rain reaches the speed of light" (LAB-005 and RSN-017 state the sign of g² − 1; the speed wording is Octavo's); seats "Möbius", "divisors of 30"; clock "Eight more switches bring the hand home" is GEN-009/ATL-023 only in the form "Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ): the types repeat".

Home: hero LAB-017 with figure `leaf-clock` (Octavo's home showed the clock); no sections (`learnerNotice` off, as on the Zero page).

---

## §3 Agent briefs

### Order and interfaces

```
step 0 (lead)  decisions L1–L8 · skeleton files (BUILD_CONTRACTS Round 4) · this plan read by all
wave 1         X2 logic port ─┐   X4 content ─┐   X1 shell, home, leaf page ─┐   X3 lens explorers ─┐
wave 2         X6 leaf pictures (on X2's modules, in priority order)        │                       │
wave 3         X5 tests extended, docs, release v2.1.0  ←──────────────────┴───────────────────────┘
```

- X2 → X6: the logic API = Octavo's exports and return shapes, minus `COPY` (interface 16). X6 starts each leaf when X2's test for it passes.
- X4 → X1, X3, X6: `pages.json` entries (interface 14), placements, the hero rows of §2.6 and §2.8 (fixed here so nobody waits), learner texts for every hero row.
- X3, X6 → X4: their seeds (`figures.lens.json`, `figures.leaf.json`) with the params of §2.6 / §2.8; X4 writes try lines against those params.
- Everyone → X5: the "report back" items below.
- Every agent: keep every suite green; never change a `human` text body; licence header on every new file; no contact details or machine paths; no banned history words; no `npm install`; do not publish, message the user or search the web; edit only owned files; algebra only through the kernel; no colour as the only carrier of meaning; no free text that states a law; no control that v15 or Octavo did not have, except the explorers' lens picker, new by design and realised as `FigureFrame`'s lens chips (the picks a, b and the steppers n, k port the Steps and Cube leaves' controls).

### X1 — Explore shell and home

**Goal.** The routes, the Explore home, the leaf/explorer page, the styles, and a smoke test, in V2's shell and tokens.
**Read first.** This plan §0, §2.1–2.3; `05_DESIGN_SYSTEM.md`; `src/pages/PageView.jsx`, `Page.jsx`, `Zero.jsx`; `src/components/{Hero,Section,Statement,FigureFrame,Shell,Link}.jsx`; `src/app/{router,queries,content}.js`; Octavo `frame.jsx`, `home.jsx` (layout only).
**Owns.** `src/pages/ExploreHome.jsx`, `src/pages/ExploreLeaf.jsx`, `src/components/Leaf*.jsx` (e.g. `LeafCard`, `LeafNav`, `LeafNotes`, `LeafLensChip`), `src/styles/explore.css` (imported by the two pages), `tests/ui/explore.smoke.test.mjs`; lines in `src/app/router.js` (the explore line), `src/app/App.jsx` (two imports, two cases), `src/components/Shell.jsx` (Contents: `explore` once, kinds `leaf`/`explorer` hidden), `src/components/FigureFrame.jsx` (pass `mode`), `src/pages/Zero.jsx` (one link "Explore" with `l=learner`).
**Deliverables.** Everything of §2.1 and §2.2: cards (title link + the leaf's hero row as a compact `Statement` below, never inside the link), unbuilt path cards, shelf filter, lens explorers group; leaf page with heading, wide hero figure, notes renderer (short/full by level), two ways, lens chip, hang chips, navigation, "Connect" via `rowHome(explore.rests)`.
**Verification.** `sh build.sh`; `node tests/coverage.test.mjs` (the explore routes render in every lens, both levels, both modes); `node tests/shipped.test.mjs`; your smoke test. Until X4's content lands, test against a fixture page in your smoke test's own temporary copy of `dist/content/pages.json`, never in `content/`.
**Must not.** Write a sentence that states a law; add a route default for the level; draw a picture (pictures are figures); use a literal colour.
**Report back.** Files; the connective words you introduced (each ≤ 240 characters); screenshots taken; anything the coverage test flagged.

### X2 — Port of the Octavo leaf logics

**Goal.** Ten logic modules and their tests on the V2 tree, re-pointed to the kernel, every check kept except the Octavo-only ones.
**Read first.** §0, §2.5; Octavo `leaves/README.md`, `octavo_tkit.mjs` (base), `names.js`, `shared.js`; the ten logic files and tests (clock, moves from `base/v16/octavo/leaves/` and `base/v16/test_octavo_clock.mjs`; the others from `wip/HANDOFF_OCTAVO/wip/<slug>/`); `engines/labels.js` exports; `tests/engines.test.mjs` §H.
**Owns.** `engines/explore/leaves/*.logic.js`, `engines/explore/names.js`, `engines/explore/shared.js`, `engines/explore/index.js`, `tests/explore/tkit.mjs`, `tests/explore/leaves.*.test.mjs`, `tests/explore/names.test.mjs`, `docs/EXPLORE_PORT.md`.
**Deliverables.** In priority order clock, moves, zero, light, fall, roots, seats, magnets, springs, charge: (1) the module with imports re-pointed, `COPY` and constant sentences removed, no own sign loop (charge's reversion → `reorderSign(m, m)`; springs' Walsh sign → `springEngine.walsh`); (2) the test ported: imports re-pointed (`labelsEngine.js` → `engines/labels.js`, `gossetData.js` → stored gosset data, `octavo/names.js` → `engines/explore/names.js`), mutant patches that no longer apply rewritten with the same meaning, Octavo-only checks removed (COPY, registry, `built`, face sources); (3) **moves gets a new test**: `expTX` against the 2 × 2 matrix exponential of `matrixOf(a, b, c)`, the sign of X² against `trinityClass` and the closed forms (cos, linear, cosh) of x″ = −kx, the planet's conic e² = 1 + 2pE against an RK4 orbit, equal areas in equal times; ≥ 4 mutants; (4) `names.js` with its test (bits, numbers, primes against `label()`, `PRIMES`, `dictionary.json`; the gcd rule over all 65,536 pairs by plain integers).
**Verification.** Each test exits 0; `node tests/shipped.test.mjs` rule 4 finds no sign loop in `engines/explore/`; `node tests/engines.test.mjs` still green.
**Must not.** Weaken a check (a check that fails is reported with its cause); render text; touch `engines/labels.js` or the kernel.
**Report back.** Per leaf: Octavo count, removed Octavo-only checks, V2 count, mutants caught; any number that changed under the kernel (with cause); the public functions each module exposes (the API X6 draws from).

### X3 — The three lens explorers

**Goal.** `lens-simplex-maxwell`, `lens-demicube-moves`, `lens-cube-maxwell` as figures with controls, their numbers and their tests.
**Read first.** §1 (all of it), §2.3, §2.6; `src/figures/{kit.jsx,FourViews.jsx,FourViewsMaxwell.jsx,MirrorsCube.jsx,Zonogon.jsx,PetrieOrthoplex.jsx}`; `engines/labels.js` (`maxwellViews`, `mirrors`, `zonogon`, `twoMirrors`, `MIRROR_EXAMPLES`); `checks/selfcheck/{maxwell,mirrors,shapes}.json`; Octavo WIP `field`, `steps`, `cube` logic and briefs (drafts to learn from, not to copy blindly; their numbers were never tested).
**Owns.** `src/figures/explore/lens/*` (components, `index.js`, `lens.css`), `engines/explore/lens.js`, `tests/explore/lens.test.mjs`, `content/explore/figures.lens.json`.
**Deliverables.** In order A, C, B: each figure with its seed (params of §2.6, `from` naming the four-views-maxwell, Steps or Cube control it ports, lenses `simplex, cube, demicube, orthoplex, bits, primes`, `learner: true`, caption row of §2.6), `meta`, `data()`, the lens redraws, the counts; the tests of §2.6.
**Verification.** `node tests/explore/lens.test.mjs`; `node tests/figures.render.test.mjs` (your figures render at both levels, both themes, every lens, every param set); `node tests/shipped.test.mjs`.
**Must not.** Print any statement of the "does not state" lists of §1; offer n beyond §2.6; add a layer picker; draw with literal colours or colour-only meaning.
**Report back.** Per explorer: what it draws at each lens, its numbers and the stored results they equal, mutants caught; any picture the rows could not support (so X4 leaves it out).

### X6 — Leaf pictures

**Goal.** The ten `leaf-<slug>` figures: Octavo's front pictures redrawn with V2's kit and tokens, from X2's modules; optionally the two back pictures by `mode` at research level.
**Read first.** §0, §2.3, §2.8; the Octavo faces (`base/v16/octavo/leaves/{clock,moves}.jsx`, `wip/<slug>/octavo/leaves/<slug>.jsx`), Octavo `kit.jsx`; `src/figures/kit.jsx` and two V2 figures (`MirrorsCube.jsx`, `SpringCube.jsx`).
**Owns.** `src/figures/explore/leaf/*` (components, `index.js`, `leaf.css`), `content/explore/figures.leaf.json`.
**Deliverables.** In the order of X2's deliveries: each figure with the params of §2.8 (sliders become chips or steppers), readouts computed by the logic, turn/boost/slide by mark and word, play paused by default; its seed (`captionRow` = the hero row of §2.8, `from: "octavo/leaves/<slug>.jsx: …"`).
**Verification.** `node tests/figures.render.test.mjs`; `sh build.sh` and a look at each figure at 390 px (screenshots under `tests/ui/shots/explore-*`).
**Must not.** Render `COPY` or any constant sentence that states a fact; compute a number the logic does not give.
**Report back.** Leaves drawn; params per figure; anything Octavo's face showed that you left out and why.

### X4 — Content of Explore

**Goal.** Rows, placements, pages, texts and the overlay pipeline, so that every word on an Explore page is a row's text record.
**Read first.** §1, §2.4, §2.8; `02_CONTENT_MODEL.md`, `04_LABELLING.md`, `09_TRANSLATION_PROTOCOL.md`, `docs/LEARNER_TEXTS.md`; `tools/build_content.mjs`, `tools/merge_learner_texts.mjs`, `tools/check_learner_texts.mjs` (read only); the Octavo leaf briefs and `survey/S2_core.md` (their "print only these" and "keep out" lists).
**Owns.** `content/explore/{registry,pages,placements,rows,texts}.json`, `content/texts_learner_explore.json`, `tools/merge_explore.mjs`, `docs/EXPLORE_CONTENT.md`. **May edit** `tools/build_content.mjs` (the status block for rows without legacy flags; the set of `since` values that carry `new`) and one line of `tools/migrate/run_all.sh` (`merge_explore.mjs` after `figures_from_v15.mjs`).
**Deliverables.** (1) First, the merge tool (X3 and X6 need it for their seeds) and the status amendment, with `status.json` unchanged for the 1,013 existing rows (show the diff count: 0). (2) For the home, each ported leaf and each explorer: the `pages.json` entry (§2.1), the hero row, three or more note rows, the two-ways rows, placements (order ≥ 1000), the try line (an instruction naming the figure's learner controls). (3) New rows only where a note is not an existing row, each with its evidence (A24, A28 drafts if the lead agrees). (4) Learner drafts: full register for the rows lacking one; short register (Octavo's notes) only if L2 is taken. (5) `docs/EXPLORE_CONTENT.md`: per page, each Octavo note → row id, or "dropped: no row".
**Verification.** `node tools/check_learner_texts.mjs && node tools/merge_learner_texts.mjs && node tools/merge_explore.mjs && node tools/build_content.mjs` (0 errors); `node tests/coverage.test.mjs`; `node tests/logbook.test.mjs`.
**Must not.** Change a `human` text or an existing row's evidence, notions or status inputs (A25 and A26 are the author's); place an Octavo keep-out statement; write a research text for an existing row.
**Report back.** Rows placed per page; new rows with their computed status; drafts written (full / short); Octavo notes dropped and why.

### X5 — Tests and release v2.1.0

**Goal.** The test extensions of §2.7, the docs, and `release/one-rule-v2.1.0.zip`.
**Read first.** §2.7, §4; `docs/BUILD_CONTRACTS.md`; the seven suites; `tools/release.sh`; `CHANGELOG.md`, `docs/RELEASE_NOTES_v2.0.md`.
**Owns.** `tests/explore.test.mjs`, `tests/explore/pages.test.mjs`, `CHANGELOG.md`, `docs/RELEASE_NOTES_v2.1.md`. **May edit** `tests/coverage.test.mjs`, `tests/figures.render.test.mjs`, `tests/shipped.test.mjs` (extensions only), `package.json` (version 2.1.0; `merge_explore.mjs` in `content` and `test:data`; `tests/explore.test.mjs` and the explore smoke test in `test`), `docs/DECISIONS.md` (D20 onwards: the decisions L1–L8 as taken), `docs/HANDOVER.md`, `README.md`, `engines/MANIFEST.json` (entries for `engines/explore/*`), `tools/release.sh` (only if the release files change).
**Deliverables.** Every test of §2.7; the budget as decided (L1); the release notes with their counts markers; `npm run release` green.
**Verification.** `npm test`; `npm run release`; the zip lists `index.html`, the Explore assets and the release files.
**Must not.** Weaken an existing check to make room (a raised budget is a recorded decision, not an edit in passing).
**Report back.** Suite counts before and after; the bundle size; anything left red and its owner.

---

## §4 Risks and decisions

**For the lead, before launch**

| # | question | recommendation |
|---|---|---|
| L1 | **Bundle budget.** `dist/app.js` is 231 kB gzipped of 260 (D16). Minified and gzipped, the ten logic modules alone are ≈ 37 kB, their Octavo faces ≈ 28 kB, and the WIP field, steps and cube leaves (the explorers' nearest kin) ≈ 28 kB: Explore will push the bundle to roughly 290–320 kB. | Raise D16 to 340 kB for v2.1 (recorded as D20; X5 sets it from the measured size + 10 %). The alternative — a lazily injected classic-script chunk for the explore figures and logic (`file://` forbids module imports), with React shared through a `window` bridge and the figures registered on load — keeps 260 kB but is the riskiest piece of the round. |
| L2 | **Short notes.** Octavo's point is few words; V2 shows the row's learner text (some run to 1,000 characters). The `short` register exists in 02 §2 but `check_learner_texts.mjs` (the lead's) accepts only `register: "full"`. | Extend the checker: R1 accepts `short`; for short, R9 = 20–200 characters, R6 (every number kept) replaced by R7 (no new number), R8 (status words) kept. Side effect: `Hero` prefers short, so the learner heroes of `/clock` (LAB-017), `/light` (EQN-006), `/steps/mirrors` (MIR-001), `/steps/gauge` (LAB-005) and any other page whose hero row gets a short text become shorter. |
| L3 | **Who draws the leaves.** The five agents named leave the ten leaf pictures to nobody. | Add X6 (wave 2). Without it, v2.1 ships the three explorers and leaf pages without pictures, which defeats Octavo. |
| L4 | **Status of new rows** (`build_content.mjs` needs the v15 flag `checked` for proved-by-atlas) and the `new` badge (`since === 'v16'` hard-coded). | Approve the 02 §4 amendment for rows without legacy flags; `new` for `since ∈ {v16, v2.1}`. |
| L5 | **Re-migration** regenerates `rows.json`, `pages.json`, `figures.json`. | The overlay `content/explore/` and `merge_explore.mjs` (§2.4). |
| L6 | Learner default for Explore. | Entry links carry `l=learner`; no route default. |
| L7 | Controls at learner level for explore figures (05 §6 says none). | Allow chips, steppers, toggles and picks for `leaf-*` and `lens-*`; sliders stay forbidden at learner level (D18). |
| L8 | `mode` passed to figures. | Yes (one line in `FigureFrame`); the back pictures are optional in v2.1. |

**For the author** (numbered after `DECISIONS.md` A21)

| # | question | options |
|---|---|---|
| A22 | "The demicube is the picture of motion in spacetime": the Atlas states the parts (MIR-001, MAP-013, EQN-002, LNS-020) but not the picture. | leave it unsaid (the explorer shows it); or one new row of kind reading, status ours, badge "our reading" |
| A23 | Octavo's "computed here and tested" facts (moves live on a demicube edge and multiply like corners; the 16 labels as divisors of 210; the Jordan–Wigner sign as a count of lower primes; Möbius) are not Atlas rows. | figures only (default); or register the explore logic check as an Atlas check (family `explore` in `checks.json`, runs in `check_runs.json`), after which X4 may write them as rows that compute to proved-by-atlas |
| A24 | "Two mirrors make a boost": stored in `mirrors.json` (`boost_5_4_3_4`), stated by no row. | add one computation row citing `mirrors_selfcheck` (status proved-by-atlas under L4); or numbers only |
| A25 | RSN-025 (∇∇F = □F, charge conservation) has no evidence, though `maxwell.json` stores both true in all 15 cells; it shows "not yet proved here". | add `maxwell_selfcheck` (ran) to its evidence; or leave |
| A26 | Rows of kind reading that a run check lifts to proved-by-atlas, so they carry no badge: LAB-003 (its learner text says "is ours"), MIR-001, NUL-012, SHP-003, SPR-003. | keep (status follows evidence); or retag the reading part as its own `ours` row |
| A27 | "n-Maxwell": if it means a field of another grade (p-form electrodynamics), no row supports it. | confirm the reading "Maxwell with n generators" (what the cube explorer shows) or ask for the p-form rows |
| A28 | The prime names: checked as arithmetic (`dictionary_selfcheck`, 65,536 pairs) but stated only as "notation only" (PAG-003, ours). | keep them as labels; optionally one computation row for the gcd rule; nothing about meaning, and 210 never commented (ATL-022b open) |
| A29 | The Monster guess. | stays out of every page (Octavo's PRIME LAB never ran) |
| A30 | Leaves not ported (mirrors, half-turns, field, steps, cube, electron, bands, tumbling, hung). | "not drawn yet" path cards for mirrors and half-turns; the shelf shows only drawn leaves; a later round finishes their tests first (half-turns: 289 placement failures; bands: 2 real ones) |
| A31 | The section's name in the shell: "Explore" or the author's "Octavo". | "Explore" (plain) with "Octavo" as the home's title, or one of them alone |
| A32 | The glossary has no learner definitions (A12); Explore at learner level would underline nothing. | write the 16 learner definitions |

**Risks.** The coverage test renders every page in all 34 lenses: fourteen more pages (the home, ten leaves, three explorers) add about 1,900 renders to its run. A short note that says less than its row is allowed; one that says more is a new claim — X4's `EXPLORE_CONTENT.md` table is where the author checks this. The leak rule reads figure text: a readout that copies 40 characters of a row fails the build. Explore's figures sit in the main bundle unless L1 chooses the chunk.
