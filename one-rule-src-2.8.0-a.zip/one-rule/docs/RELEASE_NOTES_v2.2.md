<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# ONE RULE 2.2.0 — release notes

ONE RULE, *an atlas of cells, clocks and lenses*, shows how one labelling — blades of a Clifford algebra as bit masks, products by XOR with a sign — reaches, step by step and with a check at every step, the cells of the algebra, their clock, light, matter, gravity, mechanics, and the languages of several branches of mathematics and of several researchers. Release 2.2.0 is the physics restoration: every step page prints the physics its checks compute — the equations by name, the components by role, the ladders by dimension, the numbers of the scripts that ran — as checked output of the Atlas (D29). The 85 `must` gaps of `docs/PHYSICS_AUDIT.md` are closed; the four translation matrices of spin, forque, the spring and the rigid body are rows of the Atlas, line by line, each with the badge its evidence computes to (D35); and every figure that has a ladder follows the Atlas method (D37): from the lowest stored cell up, every lens at every rung, and down again from the top.

## What it holds

<!-- counts: written by tools/release.sh from the tables (sh tools/release.sh notes); edit the tables, not these lines -->
- **Release** 2.2.0 · content: the version the build carries (`content/version.json`, printed in the footer).
- **Statements**: 1,164 rows (the 789 rows of the author's package, with 224 more where a row held several lines, 2 rows the Explore overlay adds and 149 rows of the translation matrices the physics overlay adds (D35)), each with a research text (the author's words, or a draft for review for a row an overlay adds).
- **Texts**: 2,052 in all — 1,013 research texts and 32 learner texts by the author, 151 research drafts and 856 learner drafts waiting for review (drafts by file: texts_learner.json 209, texts_learner_2.json 166, texts_learner_baez.json 246, texts_learner_explore.json 63, texts_learner_schuller.json 172).
- **Status**, computed from the evidence and the labelling: proved by the Atlas 650 · standard 37 · not yet proved here (cited) 31 · our reading 135 · needs an input 93 · open 127 · about the Atlas itself 91.
- **Lenses**: 34, with 973 dictionary entries; 1,901 lens readings on 435 rows in 10 lenses; 982 readings in the readings table.
- **Checks**: 250 scripts with 319 recorded runs; the gravity checks: 5,569 pass, 0 fail.
- **Figures**: 91 drawn, 0 of the 91 seeds shown as labelled placeholders.
- **Candidates**: 150 missing pieces named by the labelling passes, kept in the Logbook until the author accepts them as rows.
- **Pages and tables**: 45 routes; 20 theorems; 34 questions (15 answered); 26 sources; 16 glossary terms; 8 wave-3 leads with 28 proposed edits on 26 rows.
- **Explore**: 14 pages — the home, 10 leaves (6 of the 8 on the path, 4 on the shelf) and 3 lens explorers; not drawn yet: Mirrors, Half-turns; 90 placements of rows of the Atlas; 13 figures; 63 learner drafts (24 in the full register, 39 in the short one); 2 new rows.
- **Physics** (the overlay `content/physics/`, D33): 32 figures of the wave P4–P11 (14 of them at learner level too, 23 wide); 149 rows of the translation matrices (spin 30, forque 41, spring 22, the rigid body 56), computed: proved by the Atlas 127 · our reading 22; placed on their step pages as details (71) and as numbers (22), 56 shown in their figure only; 8 stored tables loaded on demand (`content/stored_p<k>.json`, 229.3 kB, D34).
- **Build**: `dist/app.js` 1367.8 kB, 432.7 kB gzipped (budget 480 kB, D38); `dist/app.css` 99.9 kB (budget 120 kB, D38).
- **Validation** (docs/COVERAGE.md): 0 errors.
<!-- end of the counts -->

## What the reader sees, page by page

Each figure below draws its numbers from the stored output of a script that ran (`checks/selfcheck/*.json`, shipped as the tables `content/stored_p4.json` … `stored_p11.json` and loaded when a page needs them, D34) and recomputes every sign, count and equation it can through the kernel. A figure marked *research* is drawn at research level only, as v15 showed it inside its fold for older readers; the others are drawn at both levels, in words at learner level.

- **Light (Calibration 1).** Beside the equations of the 15 stored cells and the components of the field, `maxwell-ladders` draws the ladder through the chosen cell, from Cl(1,0) up to ten generators, every rung with the components of F by role and the equations of ∇F = J, a rung the store lacks marked "not stored"; the strip of the chosen cell (its algebra, I², whether I is central, whether the algebra splits, the class of the wave operator); what the step adds, with ★ on the equations of the new generator; the cells of six and seven generators; and the two stored ladders, folded, with the period 8. At learner level: bars of field pieces and equations, the step as a readout, "period 8 · grid × 16". The `charges` figure names every mark by shape and word (the charge and its velocity, E, B, the force), prints E² − B² and E·B, the force term by term with live values, F on the simplex of the world, and the 14 checked rows of the script (9 exact, 5 numeric).
- **Step 2, commutators.** `comm-graph` names the roles in words at both levels (a boost, a turn, two time directions) and lists what each commutator is made of for the chosen cell; `comm-ladder` (*research*) is the table n = 2 … 8 — bivectors, the pairs that do not commute, the closed triangles, the signatures checked — with the graph of each rung in the lens.
- **Step 4, Dirac.** Under the five panels of `dirac-pic`: 8 components, 8 equations, 40 incidences (32 derivative and 8 mass terms); the six bivector rows named Ex … Bz in the Hestenes lens, "Maxwell 24 · Dirac 40"; the covariance under all six turns and boosts, ✓ six times; the momentum-space table (the determinant exact at 7 points, solutions only on the mass shell, two spin states); the independent check (200 of 200 cases agree, the wrong versions fail); the cube lens's reading of the 32 edges, marked as ours.
- **Step 5, spin.** `spin-rotor` (both levels: the dial and the arrow) shows the double cover — the vector turns by 2t while the rotor turns by t, R = −1 at 180°; `spin-hestenes`, `spin-pointor` and `spin-halves` (*research*) show the Hestenes spinors with the chirality as XOR with 9, the pointor test over the stored cells (a D37 ladder), and how a rotor keeps or mixes the halves; `spin-matrix` holds the 30 lines of the paper and the lecture against the bit rule (22 agree exactly, 2 differ as printed, 6 not checked) with the findings for the authors; at learner level the strip of the lines and the counts.
- **Step 6, coupling.** `coupling-ring`, the hero's figure at both levels, draws one equation of the coupled Dirac–Maxwell system on Cl(1, n−1), its 2n + 1 terms on two rings (the push of the field, the change along each direction), for n = 1 … 8; `coupling-ladder` (*research*) has the ladder, every view per n, the exact identities and the matrix check.
- **Step 7, Yang–Mills.** `ym-graph` draws so(m) as a graph for m = 2 … 8, a picked generator with its 2(m−2) neighbours and their commutators; `ym-ladder` (*research*) has the ladder with the standard names, the space-time table, the identities, the so(4) split and the Maxwell reduction, and the matrix check.
- **Step 8, charged matter.** `matter-halves` draws the gauge action on the even and odd internal blades (at learner level as rows of switches); `matter-ladder` (*research*) has the ladder, the space-time table with the corners of the current, the identities and the matrix check.
- **Step 9, gravity I.** `curvature-pairs` (both levels) is the table of curvature components as pairs of planes by class, the first-Bianchi relation of four axes, the ladder n = 2 … 8 and the matrix check.
- **Step 10, gravity II.** `einstein-terms` (both levels) places the C(n−1, 2) terms of the Einstein form around a ring, with the ladder; `cosmological-generator` (*research*) shows the cosmological term as one more generator, k = −s.
- **Step 11, one more generator.** `extra-generator` is drawn at learner level too (the geometry each choice names, its moves) and prints the commutator constant and k = −s at research level; `null-pair-moves` draws the null pair, the points and the table P(x)·P(y), the moves as products of mirrors, the conformal generators, the counts and the doubling.
- **Step 12, gauge gravity.** `rain` names the cone lines (outgoing, ingoing, the rain), the metric and the shear; `riemann-split` adds the grades of B² and the line 20 = 10 + 10 at n = 4, and is drawn at learner level too (all the bend, the bend fixed by matter, the bend not fixed by matter).
- **Step 13, null surfaces.** `null-figures` gains the mirror lens, the Gram readouts, the summary 64 computed · 64 passed · 2 readings, and the ladder of the stored rungs with its switch from the top; `null-neck` and `null-criterion` (*research*) draw the neck (Schwarzschild beside the Ellis wormhole, three lenses) and the criterion of g_tt = 0 with Kerr's ergosurface and its seven exact points.
- **Step 14, forque.** `forque-matrix`, the hero's figure, holds the 41 lines of the paper against the bit rule (27 agree exactly, 9 differ as printed, 5 not checked), the conventions as the input they are, and the findings; `forque-lines` (*research*) sets the four lines of the dynamics with the rows that check them and the numerical cross-check, with the tennis-racket rate predicted and measured.
- **Step 15, the spring.** `spring-oscillator` (one spring, one rotor: circle, hyperbola, line), `spring-faces` (the stretches close around every face) and `spring-table` (the lens ladder, the rungs n = 2 … 5 with their Betti numbers and levels, the 22 lines of the claim matrix) are *research*; `spring-cube` adds the conjugation table of the picked mode.
- **Step 16, the rigid body.** `rigid-segment` (the segment with its exact series), `rigid-square` (the free square and its constant world momentum), `rigid-frame-table` (every count from the segment to the 5-cube, the motor coefficient on every vertex in the lens) and `rigid-matrix` (the 56 lines, 110 claims) are *research*.
- **Calibration 2, Furey.** `furey-charges` (Y and Q on the eight complex dimensions, the trace and the mean 3/8, the blocks, the axes), `furey-composites` (the three tensor products that hold Q_L, u_R and ν_R), `furey-room` (the generations a structure holds, the exhaustive search: never three; where the 128 complex dimensions go) and `furey-trialities` (the spectra, the trialities, the ladder ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆) are drawn at both levels; `furey-board` adds what is short for three doubled sets and the capacities of the edges; `ladders` is drawn at learner level too. The Furey rows keep the status their evidence gives (D36).
- **The tally.** The fifteen summary rows EQN-006 … EQN-020 are set, at research level, in the four columns v15 gave them — equation · where · components · incidences — on the step pages and in the heroes of Light and Dirac; the text record is unchanged.

## The 85 gaps, by page

| page | gaps | closed by |
|---|---|---|
| Light | MX1–MX15, MX17 (16) | `maxwell-equations`, `maxwell-components`, `four-views-maxwell` and the explorers (MX1–MX5, MX17); `maxwell-ladders` (MX6–MX10); `charges` (MX11–MX15) |
| Commutators | CM1–CM3 (3) | `comm-graph`, `comm-ladder` |
| Dirac | DI1–DI5 (5) | `dirac-pic` |
| Spin | SP1–SP4, SP7 (5) | `spin-rotor`, `spin-hestenes`, `spin-pointor`, `spin-halves`, `spin-matrix` |
| Coupling | CP1–CP3, CP5, CP6 (5) | `coupling-ring`, `coupling-ladder` |
| Yang–Mills | YG1–YG6 (6) | `ym-graph`, `ym-ladder` |
| Charged matter | MT1–MT5 (5) | `matter-halves`, `matter-ladder` |
| Gravity I | G1–G3 (3) | `curvature-pairs` |
| Gravity II | E1–E3 (3) | `einstein-terms`, `cosmological-generator` |
| One more generator | PR1–PR6 (6) | `extra-generator`, `null-pair-moves` |
| Gauge gravity | GG1–GG3 (3) | `rain`, `riemann-split` |
| Null surfaces | NS1–NS4 (4) | `null-neck`, `null-criterion`, `null-figures` |
| Forque | FQ1–FQ3, FQ5 (4) | `forque-lines`, `forque-matrix` |
| The spring | SR1–SR6 (6) | `spring-oscillator`, `spring-faces`, `spring-table`, `spring-cube` |
| The rigid body | RB1–RB3, RB5 (4) | `rigid-segment`, `rigid-square`, `rigid-frame-table`, `rigid-matrix` |
| Calibration 2 (Furey) | FU1–FU6 (6) | `furey-charges`, `furey-composites`, `furey-room`, `furey-trialities`, `furey-board`, `ladders` |
| The tally | TL1 (1) | `TallyLine` in the sections and the heroes |

Six of the nine `should` items are drawn too, each marked as our reading: the cube reading of Dirac (DI6), the findings of the spin matrix (SP8), the corner simplex of the coupling (CP4), the triangles of so(m) (YG7), the corners of the current (MT6) and the findings of the forque matrix (FQ4). The five `no` items stay out: no row states them (MX18, MX19, DI7, RB6, FU7).

## The translation matrices, as rows

Each line of the four "paper ↔ Atlas" tables v15 printed is a row (kind `reading`, `since: "v2.2"`), its research text the line's two columns joined by " ↔ " — a draft for the author's review — and its status computed from its evidence: proved by the Atlas when the line cites the check that verifies it, which ran and passed; our reading otherwise. A proved line carries the badge "new" (D22).

| matrix | rows | proved by the Atlas | our reading | where it is shown |
|---|---|---|---|---|
| spin (paper and lecture) | SPN-M01 … SPN-M30 | 22 | 8 | `spin-matrix`; the details of Step 5 |
| forque | FRQ-M00 … FRQ-M40 | 27 | 14 | `forque-matrix`, `forque-lines`; the details of Step 14 |
| the spring | SPR-M01 … SPR-M22 | 22 | 0 | `spring-table`; the numbers of Step 15 |
| the rigid body | RIG-M01 … RIG-M56 | 56 | 0 | `rigid-matrix` |
| **all** | 149 | 127 | 22 | |

The rows have no learner text yet: at learner level a page leaves them out, and the matrices show the counts by status.

## How it is tested

- `tests/physics.test.mjs` runs the eight tests of the wave (`tests/physics/p4.test.mjs` … `p11.test.mjs`): every printed item tied to its stored json and, where a kernel route exists, recomputed through the kernel; the results of numpy runs and exhaustive searches tied to the json only (D11); broken copies caught in every file. It checks first that every module of `engines/physics/` has its entry in `engines/MANIFEST.json`, with the kernel it imports, its stored table and its test.
- The broken copies of `tests/explore/physics.test.mjs` (8), `tests/explore/motion.test.mjs` (8) and the eleven broken sources of `tests/physics/p10.test.mjs` are bundled with esbuild's asynchronous build, which takes the plugin that swaps the file: each copy builds and is caught by a failing check; a copy that does not build fails the test.
- `tests/figures.render.test.mjs` renders the 91 figures at both levels, both themes and every lens, every control an interactive entry; a control of the Atlas method that v15 did not have says `from: "D37"` (D37).
- `tests/coverage.test.mjs`: every statement a text record of its row, the lines of the matrices among them, inside their figures; at learner level no row without a learner text, so no line of a matrix; the tally line's four cells are the record byte for byte.
- `tests/logbook.test.mjs`: the badge "new" for `since` v16, v2.1 and v2.2; a research draft names its drafter as `translator:`, `explore:` or `physics:`.
- The release notes name no date: the content version is the one the build carries (`tests/shipped.test.mjs`, rule 1).
- The budgets: `dist/app.js` within 480 kB gzipped and `dist/app.css` within 120 kB (D38). The sizes of this build are in the counts above.

## What is still open

- **The story round** (`docs/STORY_PLAN.md`, S1–S5): the narration v15 printed on its pages, as story rows; the page composition, Furey's tabs, the chapters' parts; it comes next.
- **The chunk split** (D38): a lazily injected classic-script chunk for the physics and Explore figures, to bring `dist/app.js` back to 340 kB gzipped.
- **The audit's items left** (`docs/DECISIONS.md` A38–A45): the `should` items SP5, SP6 and RB4; the real board numbers of Furey's model, stored only in a json that is not shipped; the Furey figures in mathematics mode; the lenses and the switch of `charges`; the placement of the rigid body's lines; the labels of the spin and forque lines; the badge "new" on the proved lines.
- **Learner drafts for the 149 matrix rows**, through the checker of `docs/09_TRANSLATION_PROTOCOL.md`.
- The review of the learner drafts, the author's questions A1–A45 and the leaves not drawn: `docs/HANDOVER.md` §3 and `docs/DECISIONS.md`.
