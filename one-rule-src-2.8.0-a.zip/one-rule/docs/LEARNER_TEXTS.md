<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts: the drafts of the translator

`content/texts_learner.json` holds **209 learner drafts**, one per row, for the rows of `content/learner_backlog.json` outside the `lenses` and `unplaced` groups (242 rows in scope). **33 rows are left out**, each with its reason below. Every draft is a translation of its row's research text (`texts.json`, level research, lens null, mode both) under `docs/09_TRANSLATION_PROTOCOL.md` §2: the same statement in plain words, with no formula, no new claim, and every number, scope and status word kept. Each record has the shape of `texts.json` plus two derived fields:

```json
{ "row": "ATL-001", "lang": "en", "mode": "both", "level": "learner", "lens": null, "register": "full",
  "body": "With no switches at all, the cell Cl(0,0) holds only the number 1 …", "status": "draft",
  "source": "translator:learner@2026-10-10", "termsUsed": ["mirror"], "keptNumbers": ["2"] }
```

`termsUsed` lists the glossary terms (`content/glossary.json`) that occur in the body; `keptNumbers` lists the numbers of the research text that the body keeps (all of those the checker requires). Both are computed by the checker (`--fix`), never typed.

The pipeline: `node tools/check_learner_texts.mjs` (must pass) → `node tools/merge_learner_texts.mjs` (writes the drafts into `texts.json` with status `draft`; a `human` text is never overwritten) → `node tools/build_content.mjs` → `node tests/coverage.test.mjs` and `node tests/logbook.test.mjs`. All five pass with the 209 drafts merged: `texts.json` gains 209 records and loses or changes none; it holds 241 learner texts (32 human, 209 draft); the build reports 0 errors and no new warning; no status or badge changes, since status comes from evidence and label only (protocol §4).

## Drafts by page

A row shown on two routes counts on both (PAG-001 is on `/` and `rule`).

| route | backlog rows | drafts | left out |
|---|---|---|---|
| `/` (Zero) | 2 | 2 | 0 |
| `rule` (with its conventions section) | 10 | 9 | 1 |
| `cells` (the 25 cards and the type-and-clock list) | 55 | 55 | 0 |
| `clock` (step 1) | 15 | 15 | 0 |
| `light` (Calibration 1) | 7 | 7 | 0 |
| `steps` (the twenty steps) | 4 | 2 | 2 |
| `steps/comm` | 5 | 5 | 0 |
| `steps/mirrors` | 7 | 7 | 0 |
| `steps/dirac` | 1 | 1 | 0 |
| `steps/spin` | 6 | 6 | 0 |
| `steps/coupling` | 11 | 10 | 1 |
| `steps/ym` | 9 | 9 | 0 |
| `steps/matter` | 9 | 9 | 0 |
| `steps/grav1` | 11 | 5 | 6 |
| `steps/grav2` | 8 | 3 | 5 |
| `steps/projective` | 8 | 5 | 3 |
| `steps/gauge` | 4 | 2 | 2 |
| `steps/nullsurf` | 18 | 11 | 7 |
| `steps/forque` | 6 | 6 | 0 |
| `steps/spring` | 5 | 4 | 1 |
| `steps/rigid` | 8 | 5 | 3 |
| `steps/category` (the tally line EQN-021) | 1 | 1 | 0 |
| `shapes` | 19 | 19 | 0 |
| `matter` (Calibration 2) | 14 | 12 | 2 |
| `ask` | 1 | 1 | 0 |

By backlog group: atlas 55 of 55, rule 5 of 5, maxwell 6 of 6, shapes 19 of 19, equations 92 of 122, furey 12 of 14, conventions 19 of 20, ask 1 of 1. Lengths run from 50 to 900 characters (median 285). The pages whose hero row has no learner text after this pass: `steps` (PAG-021), `steps/grav1` (GRV-003), `steps/grav2` (GRV-010), `steps/projective` (PRJ-002), `steps/gauge` (LAB-005), `steps/nullsurf` (NUL-001); all six are left out for length (below).

## Rows left out, and why

A learner text may be longer than its research text but never a shorter claim, and the checker caps a learner text at 900 characters. Where a faithful plain version of every claim, number and scope does not fit, the row is left out rather than shortened. Splitting such a row into its separate claims (02 §1, "Splitting v15 rows") would let each part get a learner text.

| row | page | reason |
|---|---|---|
| PAG-013 | matter | a source list (five arXiv numbers with a date range); a learner text has no statement to make beyond the list, and it carries no date |
| FUR-002b | matter | it repeats FUR-002 (drafted) and adds the capacity count 48 over the ten edges, the maximum 12, the commutator action and the conjugate pairs: past 900 characters |
| PAG-021 | steps (hero) | a list of fourteen checked items, each with its own scope (exact, as power series, with matrices, in floating point), in 998 characters; the tightest faithful plain version is 983 |
| PAG-024 | steps | the open items plus the planets-table offsets (116.6 km, 41.5 km), the joints rebuilt after a paper with its equation and algorithm, and the exact acceleration checks |
| CPL-008 | steps/coupling | 1438 characters: the Lichnerowicz square, the axial torsion term, the Maxwell stress by variation, the Reissner–Nordström check |
| GRV-002 | steps/grav1 | 936 characters dense with ranges, sampler bounds and three identities; the faithful plain version runs to about 1100 |
| GRV-003 | steps/grav1 (hero) | 2463 characters: Lichnerowicz with and without torsion, coefficients, controls |
| GRV-004c | steps/grav1 | 2123 characters: the normal conformal Cartan connection, its curvature components and Bianchi identities |
| GRV-004d | steps/grav1 | 2085 characters: Cartan flatness against the field equation on 21 frames and 96 pairs, and the duality rotation |
| GRV-005 | steps/grav1 | 1835 characters: the Einstein–Cartan and MacDowell–Mansouri variations with their sampling bounds |
| GRV-006 | steps/grav1 | 1402 characters: the Cartan–Koszul inverse, its ranges and three probability bounds |
| GRV-007 | steps/grav2 | 2393 characters: the sign of the cosmological term in both conventions, FRW, the constant potential, orbits, Cartan flatness |
| GRV-008 | steps/grav2 | 1189 characters: the divergence identity, the Noether identity of diffeomorphisms and two sampling bounds |
| GRV-010 | steps/grav2 (hero) | 1769 characters: the Einstein form as the Einstein tensor for any frame, the sampling bound, the MacDowell–Mansouri identities |
| GRV-011 | steps/grav2 | 6354 characters: the weak-field limit, the matter actions, one cosmology solved, the spin source of torsion |
| GRV-012 | steps/grav2 | its central claim is a set of formulas (the mixed Einstein tensor of the radial Kerr–Schild class and its solutions), which cannot be stated without them, and it is past 900 |
| PRJ-002 | steps/projective (hero) | 1671 characters: the constant of the extra generator, the pseudoscalar square for 2 to 6 directions, the Killing signatures in both conventions |
| PRJ-005 | steps/projective | 1378 characters: the free top in three algebras, the printed equations matched, stability, the inertial form of a second paper |
| PRJ-006 | steps/projective | 2328 characters: the cosmological sign, the null generators of so(2,4), Kaluza–Klein, two independent signs |
| LAB-005 | steps/gauge (hero) | 1568 characters: the shear, the radial gradient, the vacuum test, free fall, the periastron advance with its runs, controls and precisions |
| LAB-006 | steps/gauge | 1985 characters: the Weyl map, geodesic deviation, the tidal tensor with its signs and index placements, Kerr, moments, covariant derivatives |
| EQN-020 | steps/nullsurf | 1217 characters and fifteen numbers: five surface gravities, the Kerr horizon, the counts of four logs |
| NUL-001 | steps/nullsurf (hero) | 1430 characters: the regular chart, the null test, the surface gravity in both charts, five values, the Kruskal exponent, the identity on four horizons |
| NUL-001b | steps/nullsurf | 1734 characters: Kerr with thirteen numbers, the reduced potential, the ergosurface, the gradient at fourteen points |
| NUL-001d | steps/nullsurf | 2391 characters: the first law and Smarr with fitted constants, Komar integrals, ten horizons, the fifth chip |
| NUL-003 | steps/nullsurf | 2745 characters: the null-surface criterion with four cases, the twist identity on Kerr, static horizons |
| NUL-004 | steps/nullsurf | 2750 characters: the tangent algebra for 2 to 6 directions, the horizon crossing, the little group, the plane wave, the two kinds of null |
| NUL-010 | steps/nullsurf | a determinant and the focusing law of null geodesics are part of the claim; with the gauge-fixed symbol, the ranks and the 112 null vectors the plain version runs past 900 |
| SPR-004 | steps/spring | 1413 characters: the Majorana sum, the staggered phases, the Bloch Hamiltonian with its zero modes and tastes, the spring between bodies |
| RIG-002 | steps/rigid | 961 characters with the gravity-gradient torque, the octupole and hexadecapole terms and the bodies tested; the plain version runs to about 1100 |
| RIG-005 | steps/rigid | 1554 characters, sixteen numbers and two dates of data: the planets table against the ephemeris |
| EQN-019 | steps/rigid | 4122 characters, about forty numbers and two dates of data |
| CPL-011 | rule (conventions) | 4285 characters: the text of the glossary entry “the action” (gravity Noether identities, sampling bounds, the Dirac–Maxwell action, the Kaluza–Klein signs) |

## What the checker enforces

`tools/check_learner_texts.mjs` reads `content/texts_learner.json` (or `--file PATH`), `content/rows.json`, `content/texts.json`, `content/glossary.json` and `content/learner_backlog.json`, prints a table of failures by rule with every failing record, and exits 1 on any failure (0 when all rules hold). Before each run it tests itself: on a synthetic row, one good record must pass and one planted record per rule must be caught (exit 2 if not). `--explain ROW` prints what it reads in a research text: the numbers to keep, the status and scope words, the identifiers it sets aside.

| rule | what fails |
|---|---|
| R1 shape | a record without exactly the keys above, or with lang not `en`, mode not `both`, level not `learner`, lens not null, register not `full`, status not `draft`/`reviewed`, a source not `translator:learner@…`, an empty body, stray whitespace |
| R2 row | a row that is not in `rows.json`, has no research text, or already has a human learner text (the merge keeps that one, so the draft would never ship) |
| R3 duplicate | two records with the same (row, mode, level, lens, register) |
| R4 formula | `$ \ ^ _ { } = < > \| ~`; operators and arrows (`≡ ⊗ ∧ ∂ ∇ ∑ ∫ ⟨ ⟩ → ↦ ≅ ≤ ≥ ± × ·` …); superscript or subscript characters; Greek letters; blackboard and script letters (ℝ ℂ ℍ 𝕆 ℓ …); vulgar fractions (½); a letter over a letter (`B/F`); a lone letter used as a variable (any single letter except a, A, I, and a name before a parenthesis such as U(1)). `Cl(1,3)`, `so(10)`, `E8`, `4D`, fractions of digits such as 3/8, and `+1`, `−1` are allowed |
| R5 history | the ten banned words of the translator prompt (09 §2) and of the G rules in BUILD_CONTRACTS (the list is in the checker), the English families P1–P6, P8, P9 of v15's `test_no_history.mjs` (regexes copied from it), and any date |
| R6 numbers | an integer ≥ 2 of the research text that the body does not state, in digits or as a number word ("two", "twelve", "second", "half" or "twice" for 2, "third" or "triple" for 3, "quarter" for 4); a decimal or scientific number not kept verbatim ("116.6", "3e-5"). Numbers inside identifiers are not required: cell names `Cl(…)`, cell addresses `[4,−2]`, group and algebra names `so(4,2)`, `SU(2)`, `C(16, 2)`, letter-and-digit names `e1`, `E8`, `T18`, `RK4`, row ids, check ids `bd·phy·18`, `core·B3`, step, figure, equation, theorem and section numbers, equation numbers in parentheses, script names, arXiv numbers, dates and years of citations, polytope names `4₂₁`, digits under `^` or `_`. A check count "5569/5569" is kept by "5569 of 5569" |
| R7 new number | a number written in digits in the body that the research text does not have (0 and 1 excepted; superscript and subscript digits of the research count) |
| R8 status | a status or scope word of the research text missing from the body: open; input; checked (check…); conjecture; ours (ours, our reading, our idea …); not proved; textbook/standard; exact; at points; in floats/numerically; cited; recalled; unread/not read; untested; not checked; not claimed; not derived; by hand (for "a plain-text derivation, not a machine-checked proof"); regression; for every n |
| R9 length | fewer than 40 or more than 900 characters |
| R10 terms | a `termsUsed` entry that is not a glossary term or does not occur in the body; a glossary term that occurs in the body but is not listed (the context-bound terms form, vertex, mode only when listed, as in `src/app/glossary.js`) |
| R11 kept | `keptNumbers` other than exactly the numbers R6 requires |
| R12 names | a capitalised word inside a sentence (a name) that occurs neither in the research text of the row nor in that of its parent row: no new authority (“Standard Model” excepted) |
| R13 contact | an e-mail address, a link, a script name or a machine path |

The coverage test is the second checker: it renders every page at learner level and fails on any KaTeX node and on any statement that is not its text record.

## How the author reviews

1. Read a draft beside its research text: the row drawer of the Logbook's register shows the research text and the learner text one above the other (it does not mark a draft as such yet; 09 §4 asks for a small mark there), and `node tools/check_learner_texts.mjs --explain ROW` prints what the checker reads in the research text.
2. To accept it as written, set `"status": "reviewed"` in `content/texts_learner.json`. To change it, edit `body` (and set `reviewed` when satisfied), then run `node tools/check_learner_texts.mjs --fix` (recomputes `termsUsed` and `keptNumbers`) and `node tools/check_learner_texts.mjs` until it passes.
3. Run `node tools/merge_learner_texts.mjs` and `node tools/build_content.mjs`. The merge replaces the draft of the same key in `texts.json`; a reviewed record keeps the source `translator:learner@…` and gets the status `reviewed` there.
4. A learner text the author writes from scratch goes into `texts.json` with status `human` (protocol §4). The merge never overwrites it, and the checker then fails the draft of that row (R2) so that it can be deleted from `texts_learner.json`.

To draft a row that is left out, split it into its claims in `rows.json` and give each part a research text; the parts can then be translated one by one.

## The register of the drafts

The drafts follow the 32 human learner texts and the v15 Young Learner layer (`ylAtlas.js`, the story strips): a generator is a **switch**; a switch that gives +1, −1 or 0 when multiplied by itself is a **plus**, **minus** or **zero switch**; a cell is written “the cell Cl(p,q)” and its elements are **pieces**; the volume element is **the piece made of all the switches**; central is “commutes with every piece”; a matrix algebra is “the n by n grids of real numbers / complex numbers / quaternions”; a bivector is a **plane** or a piece made of two switches; a commutator is “the order matters”; the demicube is the **half-cube**; the bit rule is **the switch rule**; in the physics steps a generator is a **direction** (“with 4 directions”); a null generator is a **zero switch**, while a paired null vector stays a **null direction** (the two kinds of null of the glossary); the step-3 reflections are **mirrors** or reflections, and **mirror** alone is the convention mirror (every square flips sign). A strip line of v15 (“Checked:”, “Open:”, “Ours:”, “standard inputs”) keeps the tag it had in v15 (the row's `legacyFlags`) so that a line of a list reads as a sentence. Names of researchers appear only where the research text names them; identifiers (check ids, row ids, script names) are dropped, since the drawer shows the evidence.

## Three examples

**ATL-007b** (cells, a reading).
Research: “The name “quark” for this cell is ours and open: B=2, F=1 ↦ 2/3 is only the ratio B/(B+F), not a charge computed from the algebra, and quark colour does not follow from this cell.”
Learner: “The name “quark” for this cell is ours, and open. Its 2 plus switches and 1 minus switch give the number 2/3 only as a ratio, the plus switches over all 3 switches; it is not a charge computed from the algebra, and quark colour does not follow from this cell.”

**EQN-006** (light, a line of the tally table, hero of the page).
Research: “∇F = J (Maxwell) · Calibration 1; cells n = 2 to 7 · 6 in 4D · 24 in 4D”
Learner: “Maxwell’s equation, in Calibration 1: drawn from the switch rule and checked by a script for cells with 2 to 7 directions. In 4D the field has 6 parts, and they enter the equations at 24 places.”

**LAB-023** (clock, a lemma with a reading).
Research: “the clock sum is the product Π_{j}(1 + i^{ε_{j}}) over the generators (bd·mjp·31, every ε of n entries in {+1, −1, 0}, n ≤ 6), the grand partition function of n modes with charges ε_{j} at the fugacity i: the clock is its phase, and a null generator is a zero mode, a factor 2 with no phase (at a real fugacity e^{−β} the same product is checked by bd·mjp·22); reading the sum as a partition function is ours”
Learner: “The clock sum is a product over the switches of one plus the imaginary unit raised to the switch’s square (checked for every pattern of +1, −1 and 0, up to 6 switches): the grand partition function of as many modes as switches, with the squares as charges, at the fugacity equal to the imaginary unit. The clock is its phase, and a zero switch is a zero mode, a factor 2 with no phase (the same product at a real fugacity is checked too). Reading the sum as a partition function is ours.”

## Points for the author

- The glossary has no learner definitions (`learner` is null for 15 terms and a list of status words for “the action”), so no term is underlined at learner level and `termsUsed` names research-level terms. Learner definitions of “mirror”, “null”, “calibration”, “bit rule” and “base / fibre” would serve these drafts first.
- Six page heroes have no learner text (above). A one-line `short` register text for these heroes, or a split of the rows, would give those pages a learner hero.
- PAG-013: the v15 Young Learner strip says “six papers”; the research text lists five arXiv numbers.
- Strip lines whose research text is a bare phrase (PAG-001 to PAG-034, LAB-001 to LAB-016) carry their v15 tag in the learner text (“Checked:”, “Open:”, “standard”); the research texts of those rows do not, so a reader at research level sees the phrase without its tag where the row has no badge.
- Duplicated rows keep identical drafts: PAG-029 and LAB-013, PAG-030 and LAB-014, PAG-031 and LAB-015, PAG-032 and LAB-016, FUR-003 and FUR-003b (identical research texts).
