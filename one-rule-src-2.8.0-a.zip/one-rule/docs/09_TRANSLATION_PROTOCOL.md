# 09 — Texts for every (row, mode, level, lens): the translation protocol, and the Ask guide

A row has one authoritative research text (the author's words, status `human`). Every other text — learner, mathematics-mode variant, each lens — is a *translation* of that text: the same statement, other words, no new claim. Translations are produced by translator personas (a model with a fixed prompt per lens), stored with status `draft`, checked mechanically, reviewed by the author, and only then marked `reviewed`. They are never produced live in a page: the brief's "dynamical agentic translation" is a build-time pipeline with a human gate, because a page must show the same words to every reader and the author must be able to correct them in one place.

## 1. When a translation is produced

`docs/COVERAGE.md` (08 §3) lists, per page and lens, the rows without a text. The translation job runs on that list:

1. **Learner** texts first (every page needs its hero and results in plain words; 1 learner persona).
2. **Mathematics-mode** variants only where the physics text names a law by a physics name that mathematics names otherwise (the `homeMath` field says so); otherwise the text is shared (`mode: both`).
3. **Lenses**, in the order of use: branches (alg, geo, top, cat, comb), then the researcher lenses with a dictionary (furey, baez, schuller, hestenes, pga), then the rest. The labelling lenses (bits, primes, sigword, bitsq) need no texts: they change only how labels print (07 §1). Convention lenses need texts only for rows whose wording depends on the convention (the `i-time`/`sq` rows); the rest reprint signatures.

A lens with fewer than 20 rows with a text on launch is listed as "partial" in its room and in the picker; nothing is hidden.

## 2. The translator persona (one prompt template, instantiated per lens)

Inputs given to the model, all from the tables: the lens record (name, kind, `describes`, its dictionary rows), the row (id, kind, stage, notions, cells, homes), the authoritative research text, the row's `depends` with the one-line texts of those rows, the glossary entries the text uses, and — for the learner persona — the v15 learner texts of neighbouring rows as examples of the voice.

Prompt (verbatim; fill the brackets):

> You translate one statement of the Atlas into the language of [lens name]: [describes]. The statement is a fixed fact; you may rename, reorder and explain, you may not add, strengthen, weaken or drop a claim, a number, a scope ("checked at these points", "for n ≤ 6", "an input") or a status word. Use the dictionary below where it applies: [dictionary rows: atlas element → term]. Keep the author's register: short sentences, present tense, no dates, no narration of earlier states, no words from this list: corrected, withdrawn, superseded, formerly, previously, re-worded, now proved. Do not use the names of people as authorities beyond what the statement cites. Output exactly one JSON object: `{"row": "[id]", "lens": "[key]", "level": "[level]", "mode": "[mode]", "register": "full", "body": "…", "termsUsed": ["…"], "notionsSeen": ["…"]}` where `notionsSeen` lists the codes of the 29 notions you recognise in your own text.
>
> Statement: [research text]. Kind: [kind]; stage: [stage]; cells: [cells]; notions: [notions]. It rests on: [depends texts]. Glossary: [entries].

Learner persona, in place of the lens paragraph: "You rewrite one statement of the Atlas for a reader before university: plain words, no formulas, no symbols as variables, no Greek letters, numbers allowed, one or two sentences, the same fact with the same scope and the same honesty (if it says 'our reading' or 'not finished', say so in plain words)."

## 3. The checker (mechanical, before any review)

`tools/translate/check_draft.mjs` rejects a draft when: it is empty or longer than 2.2 × the source; it contains `$`, `=` between symbols, or Greek letters at learner level; it contains a history word (08 §4 list) or a contact detail; it introduces a number absent from the source (digits compared as a multiset, scopes included); it drops a number present in the source; `notionsSeen` adds an `i-…` or `s-…` notion the row does not carry (a new input or source smuggled in) — the labelling scheme as a content checker; or its `termsUsed` contains a term not in the lens dictionary while the dictionary has a term for that atlas element. Rejected drafts go back to the persona with the reason once; a second rejection lands in `docs/COVERAGE.md` for the author.

## 4. Review and status

Accepted drafts are written to `texts.json` with `status: "draft"`, `source: "translator:<lens>@<build date>"`. The register shows drafts with a small "draft" mark in the drawer (not in the body); the author flips a draft to `reviewed` (or edits it, which makes it `human`) in the content file. A release may ship drafts; the Logbook's Method tab states how many texts are drafts per lens. Nothing a draft says can change a row's status: status comes from evidence and label only.

## 5. The Ask guide

The chat answers from the same rows (07 §6): its core is generated and pinned by test; its tail carries the reader's mode, level and lens so the answer uses the same vocabulary as the page the reader came from. Rules the persona keeps from v15 (ported into `content/persona_rules.md`): the five status words and when each is used; what is never said (that the Atlas is a theory of nature; that gravity comes from the bit rule; which sign nature has); the open list; a claim shown wrong is called wrong plainly; images and non-https links are filtered from answers (`lib/answerFilter.js`). New in V2: an answer that states a row names it (`[GRV-012]`) so the reader can open it; the guide refuses to produce texts for the content (translations are a build-time job, not a chat).

## 6. Many lenses, one matrix

The brief asks whether more lenses need a bigger matrix or a new one. In this model a lens is a key on the `texts` table and a record in `lenses.json`; adding a lens adds rows to those two tables and nothing to `rows.json`. The "bigger matrix" is the Cartesian product rows × lenses that the build materialises per page; it is never stored whole. A lens that needs its own objects (a researcher's statements that the Atlas does not have as rows) gets them as `candidate` rows linked to the existing ones (04 §6), not as a second matrix.
