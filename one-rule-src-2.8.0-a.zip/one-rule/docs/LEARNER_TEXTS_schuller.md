<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts of the Schuller chapter (step 20)

`content/texts_learner_schuller.json` holds **172 learner drafts**, one for every row whose id starts with `LNS`: the Schuller-lectures lens chapter, route `steps/schuller`, the 25 `sc-` sections of the `lenses` group of `content/learner_backlog.json`. **No row is left out.** Every draft is a translation of its row's research text (`texts.json`, level research, lens null, mode both) under `docs/09_TRANSLATION_PROTOCOL.md` §2 and the rules of `docs/LEARNER_TEXTS.md`: the same statement in plain words, no formula, no new claim, every number, scope and status word kept. The record shape is that of `docs/LEARNER_TEXTS.md` (`status: "draft"`, `source: "translator:learner@2026-10-10"`); `termsUsed` and `keptNumbers` are computed by `node tools/check_learner_texts.mjs --fix`, never typed.

Pipeline, all passing: `node tools/check_learner_texts.mjs --file content/texts_learner_schuller.json` (all 13 rules; also with every `texts_learner*.json` checked together, so no row is drafted twice); `node tools/merge_learner_texts.mjs` (`texts.json` holds the 172 drafts, status `draft`; no `human` text touched); `node tools/build_content.mjs` (0 errors; none of its warnings concerns an `LNS` row); `node tests/coverage.test.mjs` (`steps/schuller` renders 172 learner statements in physics mode and 171 in mathematics mode, the same counts as at research level); `node tests/logbook.test.mjs` (535 of 535). Status and badges do not change: they come from evidence and label only.

## Drafts by section

| section | rows | drafts | left out |
|---|---|---|---|
| sc-first | 11 | 11 | 0 |
| sc-chain | 10 | 10 | 0 |
| sc-table | 4 | 4 | 0 |
| sc-hyper | 7 | 7 | 0 |
| sc-area | 7 | 7 | 0 |
| sc-deform | 5 | 5 | 0 |
| sc-fibre | 16 | 16 | 0 |
| sc-fock | 8 | 8 | 0 |
| sc-spin | 2 | 2 | 0 |
| sc-total | 3 | 3 | 0 |
| sc-bands | 6 | 6 | 0 |
| sc-stops | 6 | 6 | 0 |
| sc-persp | 17 | 17 | 0 |
| sc-quantum | 5 | 5 | 0 |
| sc-notes | 3 | 3 | 0 |
| sc-questions | 7 | 7 | 0 |
| sc-honest | 14 | 14 | 0 |
| sc-thm | 5 | 5 | 0 |
| sc-w-chain | 7 | 7 | 0 |
| sc-w-table | 3 | 3 | 0 |
| sc-w-fibre | 5 | 5 | 0 |
| sc-w-bench | 6 | 6 | 0 |
| sc-w-bands | 7 | 7 | 0 |
| sc-w-seats | 6 | 6 | 0 |
| sc-w-magnets | 2 | 2 | 0 |
| **total** | **172** | **172** | **0** |

The hero of the page, LNS-001, has a learner text. Lengths run from 44 to 1733 characters (median 310). Nine drafts are longer than 900 characters, inside the allowance of 1.5 × the research text: LNS-012 (999), LNS-013b (1733), LNS-013d (1220), LNS-013f (907), LNS-014 (1165), LNS-017e (1199), LNS-030 (1638), LNS-032 (1703), LNS-045b (1162). LNS-013b, LNS-017e and LNS-034 sit close to their caps; they were tightened in wording only, every claim, number and scope kept.

## Rows left out

None. No faithful text had to be dropped for a rule of the checker; the one rule that pressed on a faithful wording (R4 and the Petrov letters, LNS-013d) is described under the points for the author.

## The register

The drafts follow the author's 32 human learner texts and the v15 Young Learner layer of this chapter (`schullerCopy.js`: "switch (plus, minus or zero), box = cell, corner = label, outside / inside, a paired zero"), with the words of `docs/LEARNER_TEXTS.md`:

- a generator is a **switch** (a **direction** where the row speaks of space, time or momentum); a null generator is a **zero switch**, a paired null stays a **paired zero**; a blade label is a **label** or a **corner**, an element a **piece**; the top blade is **the top corner, the piece made of all the switches**; the complement is **the opposite corner, where exactly the other switches are on**; `Cl(p,q)` with letters becomes "the cells of plus and minus switches" (a lone letter fails R4), named cells stay "the cell Cl(1,3)"; `M₂(ℂ)` is "the 2 by 2 grids of complex numbers"; a scalar part is **the plain number part** and the rest of an element **the rest**; `P = Σ kᵢeᵢ` is **the momentum piece**; base and fibre stay **base** and **fibre** (glossary), with **outside** and **inside** where the row uses them; occupation patterns are **seats** where the row uses them, **filled modes** otherwise; "box" is kept where the research text says box.
- "his" is kept for Schuller wherever the research text says "his"; the name appears only in the five rows that print it (LNS-064, LNS-071, LNS-101, LNS-102, LNS-105). The sources are named as the rows name them: the notes, the quantum notes, the geometry course, the closure paper, the constructive-gravity article, the review. Cited authors (Jancewicz, Bagchi, Duval, Gibbons, Horvathy, Plebanski) are kept; their arXiv numbers are dropped.
- identifiers: check ids are dropped and a bare check reference becomes "(checked)"; proposal ids (P2, P3, P4, P6, P8, P10) are dropped; finding ids are kept as "finding F9" where the row names the finding; rows of the translation matrix stay "row C12 of the matrix"; theorem numbers stay "theorem T16" (sub-part letters such as "(f)" are dropped: a lone letter fails R4); equation and page numbers stay where the row cites them; section numbers stay verbatim ("section 21.4", "remark 14.17", "example 17.13"), because the checker reads them as decimals that must be kept.
- the grades of the chain (S, E, A) are written structural, exact, analogy, the match codes of the lens dictionary; the items "1." to "5." of sc-quantum keep their numbers (R6 asks for them).
- the research texts' past tense ("were checked", "we did not rebuild") is in the present ("are checked", "are not rebuilt here").
- short explanations added, no claim among them: hyperbolic, in LNS-002, with the author's v15 phrase "waves are sent forward in time, neither stuck in place nor blowing up"; general linear electrodynamics as "light in any linear medium"; Klein–Gordon matter as "a scalar field" (the words of LNS-068); SL(2,ℂ) as "the spin group of relativity" (the lens dictionary, row L12); a manifold as "a space made of patches"; global as "over a whole space"; structure functions as "coefficients that are functions, not constants"; elliptic and ultrahyperbolic cells by their counts of plus and minus switches.

## Three examples

**LNS-010g** (sc-chain, ours and open).
Research: “The sign of Λ cannot come out of his equations: they leave Λ/κ free (exact, on his printed Klein–Gordon closure). Reading it as −s·κ², with s the square of the extra generator of step 11, is ours and open, neither confirmed nor refuted: it would need input his closure does not contain.”
Learner: “The sign of the cosmological constant cannot come out of his equations: they leave the cosmological constant divided by the coupling free (exact, on his printed closure for Klein–Gordon matter). Reading that sign as minus the square of the extra switch of step 11 times the coupling squared is ours and open, neither confirmed nor refuted: it would need an input that his closure does not contain.”

**LNS-016** (sc-fibre, a computation with its numbers).
Research: “Fix V = ℝ¹⁶ and eight real 16×16 matrices γ₁ … γ₈ that anticommute and square to −1: Cl(0,8) = M₁₆(ℝ). Base: the algebra of the first k of them; fibre: its commutant in End(V). For k = 0 … 8 the fibre has dimension 256, 128, 64, 32, 16, 8, 4, 2, 1 = 2^{8−k}; the commutant of the fibre is the base again; base and fibre have the same centre, of dimension 1 for k even and 2 for k odd.”
Learner: “Fix a real space with 16 directions and eight real 16 by 16 matrices that anticommute and square to minus one: together they make the cell Cl(0,8), all the 16 by 16 real grids. The base is the algebra of the first few of them; the fibre is everything in the grids that commutes with the base. For 0 to 8 matrices in the base the fibre has size 256, 128, 64, 32, 16, 8, 4, 2 and 1: it halves with each matrix added. What commutes with the fibre is the base again, and base and fibre have the same centre, of size 1 for an even number of matrices and 2 for an odd number.”

**LNS-131** (sc-w-seats, the two kinds of zero).
Research: “ε_k = ½[(ε_k + ι_k) + (ε_k − ι_k)] is half the sum of a plus and a minus generator: a paired null, never a label 0 (a generator with square 0); its partner ι_k takes the particle out.”
Learner: “Adding a particle is half the sum of a plus switch and a minus switch, the operators adding plus removing and adding minus removing: it is a paired zero, never a zero switch, a switch whose square is zero; its partner, the removing operator, takes the particle out.”

## Points for the author: unclear research texts and readings to confirm

- **LNS-013d, the Petrov letters.** "D for Schwarzschild …, N for plane waves, O for de Sitter and FRW" uses single letters, which R4 rejects as variables (only a, A and I pass). The draft writes the common hyphenated form "type-D", "type-N", "type-O", "type-I", which the checker accepts. If "type D" is preferred, R4 needs an exception for a letter after "type"; the hyphen is the only change.
- **LNS-034, LNS-107.** "Λ = 3c" uses a constant c that the row does not define; read as the cosmological term of the Einstein form (as in GRV-005 and GRV-007) and written "3 times the cosmological term".
- **LNS-014, LNS-029.** In "c = (deg P − 1)p¹¹" the coefficient p¹¹ is not defined in the row; written "the degree of the polynomial minus one times one of its coefficients".
- **LNS-013b.** "the normalisation p = 1" leaves p undefined (read as the factor of the quartic polynomial); "the other three, which make g₃ symmetric, touch only edge cells of the mixed block" does not say whether g₃ is the mixed block, so the draft says "the third block".
- **LNS-017e.** φ is introduced as "a scalar" and then constrained by "a constant radius"; the row does not say that φ is the radius of the extra direction, and the draft keeps both words as printed.
- **LNS-015.** The sign (−1)^{|b||c|} leaves b and c undefined; read as the fibre label of the first factor and the base label of the second, which is what passing them past each other gives.
- **LNS-017f, LNS-121.** "the descent of F11" is read from the title of finding F11 in the v15 page ("Keep the 8 fixed and step the base down: the commutant fills"): "the step down of finding F11, where the base gives up switches to the fibre".
- **LNS-012, LNS-116.** "every null covector gives a double root" is read with null meaning that the polynomial vanishes on the covector.
- **LNS-003, LNS-059.** The exception "(p,q) = (1,0) on an ungraded module" names no number of null generators; the draft keeps it so ("one plus switch and no minus switch").
- **LNS-042.** The row never names the Dirac equation, so the draft cannot either (R12: no name the research text does not print); it describes the printed equation instead.
- **LNS-104** carries a note that finding F6 lists the grades in another order than the figure; aligning F6 with the figure would let the row lose the note.
- **LNS-024, LNS-025, LNS-037** are flagged by the labelling review notes in `docs/COVERAGE.md` ("No Lagrangian and no variation" holds for the chapter as read, not for the atlas; the "open" of mixed states against theorem T15). **LNS-032** is among the rows a v16 lead changes. The drafts translate the research texts as they stand; when those texts change, the drafts need a fresh translation.
- Rows with near-identical research texts have near-identical drafts: LNS-068 and LNS-076; LNS-064, LNS-071 and LNS-102; LNS-019f and LNS-028b; LNS-012c and LNS-118; LNS-034 and LNS-107; LNS-024 and LNS-057; LNS-051 and LNS-070; LNS-054 and LNS-073; LNS-055 and LNS-074; LNS-056 and LNS-075; LNS-022d and LNS-127; LNS-022e and LNS-128; LNS-031b and LNS-133; LNS-017f and LNS-121; LNS-033 and LNS-040; LNS-028d and LNS-045; LNS-014e, LNS-029 and LNS-047.

## How the author reviews

As in `docs/LEARNER_TEXTS.md`: read a draft beside its research text (`node tools/check_learner_texts.mjs --explain LNS-…` prints what the checker reads in the research text); set `"status": "reviewed"` to accept it, or edit `body`, then run `node tools/check_learner_texts.mjs --fix --file content/texts_learner_schuller.json`, the checker, `node tools/merge_learner_texts.mjs` and `node tools/build_content.mjs`. A learner text written from scratch goes into `texts.json` with status `human`; the merge never overwrites it, and the checker then fails the draft of that row (R2) so that it can be deleted here.
