# 08 — Build, test, deploy

## 1. Repository layout

```
one-rule/
  content/                 the tables of 02_CONTENT_MODEL.md (JSON); MIGRATION_COUNTS.json; persona_rules.md; data/ (copies of selfcheck/*.json the figures read)
  checks/                  the author's check scripts, unchanged (03 §2.5); RUNBOOK.md
  engines/                 bitrule.js, numeric.js, labels.js, category.js, baez.js, schuller.js, furey.js, pga.js, charges.js, spin.js, spring.js, null.js, forque.js; MANIFEST.json
  src/
    app/                   main.jsx, router.js (hash routes), settings.js (mode/level/lens/theme in the address + localStorage), shell/ (Shell, LensPicker, Search, Footer)
    pages/                 Zero, Rule, Cells, Cell, Clock, Light, Steps, Step, Shapes, Matter, Lenses, LensRoom, Logbook (tabs), Ask, Glossary — thin: each reads its pages.json entry and renders sections
    components/            PageHeader, Hero, Statement, Badge, Drawer, FigureFrame, CellCard, StepIndex, Register, MatrixHeatmap, GlossaryTerm, OpenFold, DependencyMap
    figures/               one component per figure id (07 §3)
    styles/                tokens.css, base.css, components.css, katex (self-hosted)
    content/               generated at build: per-page chunks (rows + texts for every mode/level/lens of that page), index.json, search index, persona core
  public/                  reports/ (the self-contained HTML reports, note, tutorial, analyses; tutorials/: one page per tutorial and src/<name>/ with
                           its markdown source, figs/ and widgets/), katex/, fonts fallback
  tools/
    migrate/               the scripts of 03_MIGRATION.md
    build_content.mjs      validates content/, computes status/address/neighbours, writes src/content chunks
    build_persona.mjs      the Ask guide's core from the tables
    import_runs.py         logs → check_runs.json
    bench/                 productKernels, benchKernels, label bench page builder
    make_tutorial.mjs      one tutorial page from its markdown source (and analyses/tutorial_style.css, the style it adds to the analyses' sheet)
    tutorials/             registry.mjs (the computed fields of content/tutorials.json), figs_<name>.py (the figures of each tutorial)
  tests/                   node tests (data) and playwright tests (ui); see §4
  api/                     chat.js, chat-openai.js, contact.js (ported), lib/ (guards, answer filter)
  docs/                    this build book, HANDOVER.md (how to add a row / a check / a lens), DECISIONS.md
```

## 2. Toolchain

Node ≥ 20 (v15 was tested on 22), Vite 5 + React 18 (JSX, no TypeScript required; JSDoc types welcome), Playwright for UI tests, Python 3.11+ with numpy and scipy for running the checks (the app itself needs no Python at runtime). Pinned versions in `package.json`; `npm ci` reproducible; no network needed to build (fonts from Google Fonts are optional with full fallback stacks; KaTeX self-hosted).

Scripts: `npm run migrate -- <v15 root> <leads root>` (runs 03 §2 in order, then `verify_counts`); `npm run content` (`build_content.mjs`: validate + chunks + persona + search index); `npm run dev`; `npm run build` (content then Vite; fails on any validation error); `npm test` (data tests), `npm run test:ui` (Playwright; skips with a message when Chromium cannot start, as v15's `--ci` does); `npm run checks -- <script>` (runs one Python check from `checks/` and imports its run).

## 3. Build pipeline (`tools/build_content.mjs`)

1. Load every table; validate (02 §10); stop on the first error with the record id.
2. Compute per row: status, `new`, signature, grade, mask, prime, address, neighbours (one bit away), chain/class membership (from `depends`), the "rests on / leads to" lists.
3. Resolve texts: for each page × mode × level × lens actually registered, materialise the text each statement will show (with the fallback chain of 02 §2) and record where a fallback was used (→ `src/content/coverage.json`: per page, per lens, how many rows have a reading; the lens picker reads it).
4. Emit `src/content/pages/<route>.json` chunks (rows of that page with their texts, figures, drawer data), `index.json` (routes, titles, step numbers, needs), `search.json` (id, text, home, notions), `persona.txt`.
5. Emit `docs/COVERAGE.md`: pages without a learner hero, rows without research text (must be 0), connective budget per section, texts with status draft (count) — the author's to-do list.

Deterministic output (same content → same bytes); a test compares a fresh build to the committed chunks (the v15 `--check` habit).

## 4. Tests (all must pass before a release)

Data tests (node, fast):
- `schema.test.mjs` — 02 §10, every rule.
- `kernel.test.mjs` — `engines/bitrule.js` against the tables generated from `bitrule_A.py` (n ≤ 5, all signatures; 120 sign vectors at n ≤ 4) and against `checks/selfcheck/core.json`.
- `engines.test.mjs` — every engine manifest: recompute the numbers of its figures and compare with the stored json (ports of v15 `test_pgadyn`, `test_spring`, `test_null`, `test_charges`, `test_lens_*_widgets`, `test_gosset`, `test_shapes`, …).
- `coverage.test.mjs` — the invariant: render every page (server-side with react-dom/server or in Playwright) for every (mode, level) and every registered lens; every `<Statement>` has a row id and its text equals a text record; connective prose per section ≤ 240 characters; at learner level no KaTeX node and no row without a learner text in the body; at research level no `cited`/`open` row without its badge; no row with status proved/standard carries a badge.
- `counts.test.mjs` — the numbers of `MIGRATION_COUNTS.json` and of 03 §2.9.
- `no_history.test.mjs` — port of v15's `test_no_history.mjs`: the forbidden phrase families P1–P9 (erratum ids; "was corrected"; withdrawn/retracted/superseded/obsolete/stale; "was wrong", "as first written", "previously", "formerly"; overstate/overclaim/misread; version words and dates used as time words; "relabelled from", "re-worded", "now proved", "in this session", "Versions" headings; release numbers as time words and ISO dates other than the date of issue) with the same allow-list ideas (negative controls "a wrong version must fail", a paper's own version number, a caveat on a printed line, a conditional "would fail if … were wrong") and the same self-check (one planted phrase per family must be caught; every allow-list entry must clear something). Scopes: every text in `content/`, every string in `src/`, the READMEs and this book's handover doc; `checks/` as the author ships it; the analyses stay the documented exemption. The date of issue of the V2 content build is the one date allowed.
- `no_contact.test.mjs` — no e-mail address, phone number, postal address or machine path in `content/`, `src/`, `docs/`, `checks/` (v15's rule).
- `license.test.mjs` — every file copied from v15 keeps its three-line header; new files carry the licence the author chooses (decision for the author: the same PolyForm notice, or another).
- `imports.test.mjs` — the import graph of `src/` and `engines/` is closed (no import outside the repository), as v15's `test_package`.
- `persona.test.mjs` — every sentence of the generated Ask core maps to a row id or to `persona_rules.md`; the core stays under the size cap.
- `labels.test.mjs` — `labelling/validate_labels.py` logic ported: every row's notions ⊆ the 29 codes; signature = computed; address format.

- `tutorials.test.mjs` — the tutorials (`content/tutorials.json`, `public/reports/tutorials/`): the registry's shape (its keys in order, words of at most 240 characters, `part`, `html`, `sources`); each entry's source, page, figure script `tools/tutorials/figs_<name>.py`, figures and widgets exist; the computed fields (figures, widgets, rows, checks) are what the source gives (the function of `tools/tutorials/registry.mjs` that writes them) and `node tools/make_tutorial.mjs <id> --check` is current; every row id and check id exists; no banned history word (the families P1–P9, read from the source of `shipped.test.mjs`), e-mail address or machine path in the sources, figures, widgets and figure scripts; every SVG under 80 kB with no script, no raster and its words as text; every widget one function expression with its self-test; `#/tutorials` rendered on the server at both levels; planted faults caught. `--figs` also runs each figure script and checks that it gives the same bytes. It runs in `npm run test:data`.

The tutorials are built by hand, not by `npm run content`: after a tutorial changes, run its figure script (`python3 -I -B tools/tutorials/figs_<name>.py`), then `node tools/tutorials/registry.mjs` (the counts and ids of `content/tutorials.json`; it fails on a row or check id that does not exist), then `node tools/make_tutorial.mjs <id>` (the page; `--check` compares, `--src <file.md> --out <file.html>` renders a draft outside the registry). `build.sh` copies `public/` into `dist/` as it is.

UI tests (Playwright, one browser, phone 390 × 844 and desktop 1366 × 900, light and dark):
- every route renders without console errors; no horizontal overflow; the sticky shell stays within the safe area;
- the three switches change the page (a statement's text changes with the lens; formulas disappear at learner level; order changes with the mode);
- the drawer opens and shows the Evidence tab with at least one check for a proved row;
- the register filters and the heatmap click work;
- a deep link `#/steps/grav2?m=math&l=learner&lens=cat` reproduces the view;
- `ui/tutorials.smoke.test.mjs` (run it under the chromium lock, as `ui/smoke.test.mjs`): every page of `content/tutorials.json` from `dist/` at 390 and 1280 px in both themes, with no page error, no horizontal overflow at 390 px, its figures drawn, every `.widget` filled after load and its self-test holding, and "All tutorials" leading back to `#/tutorials`; `#/tutorials` in both themes and levels with one card per entry and the four courses in one page last; the door's way to it. `--shots <dir>` writes the screenshots. It runs in `npm run test:ui` and in `tools/release.sh`.

## 5. Performance budgets

First page JS ≤ 250 kB gzipped (React + shell + the Zero page); a page chunk ≤ 150 kB gzipped (texts for all lenses included; split further if a page exceeds it); KaTeX loaded only at research level; figures lazy-loaded per section; the register virtualised (789+ rows); the Python mirrors downloadable from `checks/` as files, never bundled; total static site ≤ 56 MB including the reports, the analyses and the tutorials HTML, the checks with their logs and the tuning export (`tests/shipped.test.mjs` rule 5; v15 shipped 8.4 MB of JS eagerly; V2 must not).

## 6. Deployment

A static site (`dist/`), hash-routed, deployable on any static host; the two chat routes and the contact route are serverless functions (ported from `api/`; their settings documented as v15's BUILDING.md does; the model name and the keys are environment variables; no key in the repository). A `CONTENT_VERSION` (date of the content build) is shown in the footer and is the one date the no-history test allows.

## 7. Definition of done for the whole build

All tests green; `docs/COVERAGE.md` shows 0 rows without research text and lists the remaining learner gaps and draft texts for the author; the four journeys of 01 §"Four journeys" pass by hand on a phone and a laptop; `HANDOVER.md` walks through adding one v16 row (for example `PRJ-005`'s force-line passage) with its evidence and texts and shows it appearing with the `new` badge; `DECISIONS.md` lists every "decision for the author" with the default taken.
