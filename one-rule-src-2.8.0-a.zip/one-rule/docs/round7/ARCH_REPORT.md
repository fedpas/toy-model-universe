<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# ARCH — one door, one page, one record (round 7, wave 1)

Owner ARCH, docs/round7/PLAN.md §4 "ARCH". The leaves have no pages of their own any more: each lives at the top or in a section of an Atlas page,
`#/` is the door, every page that has a hero opens with the page top, and every page that places a row ends with its record.

## 1. The map: where each figure lives (R7-3)

| figure | page | place | from the brief |
|---|---|---|---|
| leaf-clock | `clock` | page top | as planned; the clock-wheel moves to the section `clock` ("Pick a cell: the clock reads its type") |
| leaf-moves | `clock` | section `clock-trinity` | the page has its "three moves" section already ("The three squares of an element: spring, free, inverted"); no new section |
| leaf-zero | `steps/category` | page top | as planned |
| leaf-light | `light` | page top | as planned; maxwell-equations moves to the section `views` |
| leaf-charge | `light` | section `charges` | as planned |
| lens-simplex-maxwell | `light` | section `views` | as planned |
| lens-cube-maxwell | `light` | section `views`, under the chip "Another view" | as planned |
| leaf-fall | `steps/gauge` | page top | as planned; rain moves to `eq-gauge` with the intro's captions |
| leaf-roots | `shapes` | page top | as planned; gosset-plane moves to `sh-gosset` |
| leaf-seats | `steps/schuller` | section `sc-fock` | as planned |
| leaf-magnets | `steps/schuller` | section `sc-total` | not `sc-spin`, not `steps/spin`: its rows (SPN-004, LNS-021, LNS-021c, LNS-135) are in `sc-total` ("Total spin" / "Three magnets") |
| leaf-springs | `steps/spring` | page top | as planned; spring-cube moves to `sr-vertices` with the intro's captions |
| lens-demicube-moves | `steps/mirrors` | page top | as planned (the picture of Mirrors until that leaf lands); mirrors-cube moves to `eq-mirrors` with the intro's captions |

Every leaf figure is drawn on exactly one page, at research and learner level (tests/door.test.mjs B); no figure of the Atlas is lost or drawn
twice (the figure map of every page before and after the round was compared: only the moves above differ). The figures a top displaces are
listed in `content/explore/pages.json` (`moves`), and `tools/merge_explore.mjs` writes them as slots of kind `move`.

**Reserved for wave 2** (the leaf owners take these slots; the registry entry gets its `figure` and the merge does the rest):

| leaf | page | place |
|---|---|---|
| mirrors | `steps/mirrors` | page top; lens-demicube-moves then moves to `eq-mirrors` as a lens slot (under "Another view") |
| half-turns | `steps/spin` | page top (the page has no top yet; its card opens the page) |
| bands | `steps/schuller` | section `sc-bands` |
| field | `light` | section `views` (the six parts of F) |
| steps | `light` | section `ladders` |
| cube | `steps/rigid` | section `rg-square` |
| electron | `steps/dirac` | page top |
| tumbling | `steps/rigid` | page top |
| hung | `steps/forque` | page top |

## 2. The rows

`content/explore/placements.json` holds 52 placements, each marked `overlay: "explore"` in rows.json: 19 notes in the reserved section `top-notes`
of 7 page tops (role `note`) and 33 results in the sections of the leaves (role `result`). All 90 placements of the 13 Explore pages of 2.3 are on
the page their leaf lives on (the others were placed there already). The two new rows of the overlay are MIR-007 and MIR-008.
Deviations: the notes have orders 1001–1003, not 1–3 — an order below a row's other entries would move its home, and every overlay order stays at
1000 or more so that no home moves; shapes and steps/spring have two notes, because the leaf's third note is the page's hero row (D26: the slot
stays empty). The connective `notes` of each leaf page is the page's `connective["top-notes"]` (the try line); a section leaf's try line is its slot's.

## 3. What was built

- **Door** `src/pages/Door.jsx` at `#/`, words in `content/story/door.json`: the mark and line, the live clock with its controls, the eight path
  cards (icon, number, name, the caption row of the leaf's figure, "Open →" to its page at its anchor; a leaf not drawn yet says "coming", shows no
  line and opens its page anyway), the drawn shelf leaves ("hangs under n"), the chapter cards, the door to `#/atlas` (and the guide for agents once
  its route exists: `door.json` `agents`). Icons ported to `src/components/LeafIcons.jsx` (currentColor only).
- **Page top** `src/components/PageTop.jsx` and `TwoWays.jsx` (interface 37 in `buildPageModel`: `top: { lead, hero: { row, figure, wide }, tryLine,
  notes, ways: { phys, math, one, lens }, leaf, fromMap }`). Leaf and lens seeds are `size: "wide"`.
- **Record** `src/components/PageRecord.jsx` (closed fold before the links to the previous and next page; also after Ask and the Logbook, which draw
  themselves; no fold on a page that places no row) and `tools/page_records.mjs`, run by `tools/build_chunks.mjs` (no build.sh change needed):
  36 files `dist/content/records/<route>.json` and the index `records.json` (+ `records.js`). `scripts` are the ids of checks.json.
- **Routes** `src/app/router.js`: `#/explore` → `#/`, `#/explore/<slug>` → the leaf's page `?at=<anchor>` (location.replace, every other parameter
  kept), an unknown slug → `#/`. Contents: "Start here", "The Atlas", the chapters. The palette finds the leaves by name (kind `leaf`, "Way in").
- **Sections** (`src/app/queries.js`, `Section.jsx`): a section's figures are blocks — a leaf first, the section's own figures, a moved figure, the
  explorers; an explorer marked detail sits under the chip "Another view"; `sec.figures` lists the figure column, `sec.another` the chip's, and
  `sec.captions` every caption the blocks show. A figure a section names and the map places there too is the map's (with its try line).

## 4. Markup for LOOK (interface 36)

Door: `article.page.door` > `section.door-hero#sec-door` (`.door-hero__text`, `.door-hero__mark`, `h1.door-hero__line`, `.door-hero__actions` with
`a.btn.btn--primary.door-begin` and `a.btn.btn--ghost.door-see-shelf`, `.door-hero__picture` holding the figure) · `section.door-cards#sec-path` and
`section.door-shelf#sec-shelf` (`header.door-cards__head` > `h2.door-cards__title` + `p.door-cards__line`; `ol|ul.door-cards__list`) with
`li.door-card.door-card--path|--shelf[.is-coming][data-leaf][data-page][data-anchor]` > `.door-card-icon`, `.door-card-n`, `.door-card-under`,
`h3.door-card__title`, `p.door-card__coming`, the Statement (variant card), `a.door-card__open` · `section.door-chapters#sec-chapters` with
`li.door-card.door-card--chapter[data-chapter]` · `nav.door-door#sec-atlas` (`.door-door__icon`, `h2.door-door__title`, `a.door-door__open`,
`a.door-door__agents`).
Page top: `section.top#sec-top[data-top]` > `div.top-lead` · `div.top-hero[.top-hero--wide]#hero[data-size=wide]` > the figure and
`div.top-hero__caps` · `p.top-try` (`.top-try__label`, `.top-try__text`) · `ol.top-notes` > `li.top-note[data-note=1…3][data-row]` > Statement ·
`div.top-ways[.top-ways--one][data-row]` > `section.top-way.top-way-phys|top-way-math[data-mode]` (`p.top-way__eyebrow`, Statement, `div.top-way-lens`
with the lens chip) · `p.hero__how.top-how`. A note can carry a badge (light: INP-011): its meta belongs under the words.
Sections: `p.sec__try` (`.sec__try-label`, `.sec__try-text`) under a leaf; `details.sec__another` > `summary.chip.sec__another-chip`.
Record: `details.record#sec-record[data-record-rows]` > `summary.record-head` (`.record-head__caret`, `.record-head__label`, `.record-head__n`) ·
`.record-body` > `a.record-download`, `.record-scroll` > `table.record-table` > `tr.record-row[data-row]` (`.record-row__id`, `__kind`, `__status`,
`__scripts`, `__n`, `__address`; scripts once each, with "n checks").
`src/styles/door.css`, `top.css`, `record.css` in this copy are stand-ins so that the pages build and can be seen; LOOK's files replace them.

## 5. Tests

New: `tests/door.test.mjs` (1141 checks; five broken inputs caught: a page a card opens removed, a leaf figure on a second page, a placed row taken
off its page, the anchor's section removed, a top figure changed) and `tests/record.test.mjs` (33418 checks; five broken inputs caught: a row dropped
from a file, a script id checks.json lacks, a stale file, a machine path in a file, a download link to another page's file), both in `test:ui`.
Rewritten for the door: `tests/story/landing.test.mjs` (786), `tests/explore/pages.test.mjs` (1436), `tests/ui/explore.smoke.test.mjs` (569);
updated: `tests/coverage.test.mjs` (the door rendered; notes and ways as text records; old links), `tests/shipped.test.mjs` (rule 7 accepts `intro`
and `top-notes` under a hero, with a self-check; rule 1 reads the shipped words of content/story/; the door's code joins rules 2–4),
`tests/ui/smoke.test.mjs` (the door and #/atlas, the theme ground from `--bg`, research level named, page tops wide and on a phone, redirects, the
record fold). The Round 6 T1 items are done (several were already in place). `tests/ui/explore.fixture.mjs` is no longer used.
Known exceptions (`tests/shipped.test.mjs`, not of this round): `docs/RELEASE_NOTES_v2.3.0-pre.1.md` line 10 carries "second pass" (P6); the
release files of 2.3.0-pre.1 (not a release number; no RELEASE_NOTES_v2.3.md) wait for the release of wave 3.

Screenshots: `tests/ui/shots/round7/arch_{door,clock,light,steps-mirrors}-{1280,390}-{light,dark}.png` and `arch_clock-record-{1280,390}-light.png`.

## 6. Patches for files of other owners (applied in this copy, to be applied at the merge)

Exact unified diffs (one line of context), against the files of this round's start.

`tools/merge_story.mjs` (R1) and `tools/build_content.mjs`: the role `note`.

```diff
--- a/tools/merge_story.mjs
+++ b/tools/merge_story.mjs
@@ -65,3 +65,3 @@
 const DRAWER = ['evidence', 'needs', 'depends', 'readings', 'numbers', 'address'];
-export const ROLES = new Set(['lead', 'caption', 'result', 'detail', 'learner', 'next', 'evidence']);
+export const ROLES = new Set(['lead', 'caption', 'result', 'detail', 'learner', 'next', 'evidence', 'note']); // note: a page top's notes (round 7, interface 37)
 const INTRO = 'intro';
--- a/tools/build_content.mjs
+++ b/tools/build_content.mjs
@@ -18,3 +18,3 @@
 const RELS = new Set(['derives','equiv','instance','uses-input','cycle','contradicts','restates']); // restates: a story row names the rows whose numbers and formulas it repeats
-const ROLES = new Set(['result','detail','evidence','lead','caption','learner','next']);            // the roles of a placement (STORY_PLAN §1.3); the section intro is reserved
+const ROLES = new Set(['result','detail','evidence','lead','caption','learner','next','note']);     // the roles of a placement (STORY_PLAN §1.3; note: a page top's notes, round 7); the sections intro and top-notes are reserved
 const errs = [], warns = [];
```

`src/styles/components.css` (LOOK): in a wide frame a leaf's drawing comes before its controls.

```diff
--- a/src/styles/components.css
+++ b/src/styles/components.css
@@ -289,3 +289,3 @@
   /* the figure's own root: the drawing first, its controls under it, then the rest in its own order */
-  .fig[data-size="wide"] > .fig__draw > .fig > :is(.fig-svg, .fig-panels, .fig-scroll) { order: -2; }
+  .fig[data-size="wide"] > .fig__draw > .fig > :is(.fig-svg, .fig-panels, .fig-scroll, .leaf-row) { order: -2; }
   .fig[data-size="wide"] > .fig__draw > .fig > .fig-controls { order: -1; }
```

`tests/explore/motion.test.mjs`: MIR-007 and MIR-008 are placed on the explorer's page.

```diff
--- a/tests/explore/motion.test.mjs
+++ b/tests/explore/motion.test.mjs
@@ -13,3 +13,3 @@
 //      fractions the row MIR-007 quotes = the stored ones; the rows MIR-007 and MIR-008 merged (since v2.1, their kinds, evidence, status and badge, their
-//      places: the two ways of the explorer and a home in the full Atlas)
+//      places: the page of the Atlas the explorer lives on (content/explore/registry.json; round 7) and a home in the full Atlas)
 //   C  every ordered pair of planes at every chip and 4 sampled amounts: R_b R_a through the kernel = the product of the two textbook matrices; its boost part and
@@ -199,3 +199,5 @@
   ok((status['MIR-007'] || {}).status === 'proved-by-atlas' && status['MIR-007'].badge === 'new' && (status['MIR-008'] || {}).status === 'ours' && status['MIR-008'].badge === 'our reading', 'the computed status: MIR-007 proved by the Atlas (badge "new"), MIR-008 ours (badge "our reading")');
-  ok(['MIR-007', 'MIR-008'].every(id => (row(id).shownOn || []).some(s => s.page === 'explore/demicube-moves' && s.section === 'two-ways' && s.order >= 1000) && home(id).page && !String(home(id).page).startsWith('explore')), 'both are placed in the two ways of explore/demicube-moves and have their home in the full Atlas');
+  // the explorer lives on a page of the Atlas since round 7 (the door's map, content/explore/registry.json): both rows are placed on that page
+  const at = ((J('content/explore/registry.json').lenses || []).find(e => e.slug === 'demicube-moves') || {}).page;
+  ok(!!at && ['MIR-007', 'MIR-008'].every(id => (row(id).shownOn || []).some(s => s.page === at) && home(id).page && !String(home(id).page).startsWith('explore')), `both are placed on ${at}, the page of the explorer, and have their home in the full Atlas`);
   ok(['MIR-007', 'MIR-008'].every(id => texts.some(t => t.row === id && t.level === 'learner' && t.lens == null)), 'both have a learner text');
@@ -367,4 +369,5 @@
   const BADGE = { research: ['new', 'our reading'], learner: ['new', 'our idea'] };
+  const page = ((JSON.parse(fs.readFileSync(path.join(C, 'explore', 'registry.json'), 'utf8')).lenses || []).find(e => e.slug === 'demicube-moves') || {}).page;   // the explorer's page (round 7)
   for (const level of ['research', 'learner']) {
-    const h = ssr.render(`#/explore/demicube-moves${level === 'learner' ? '?l=learner' : ''}`), at = h.indexOf('data-figure="lens-demicube-moves"'), fig = at < 0 ? '' : h.slice(at, h.indexOf('</figure>', at));
+    const h = ssr.render(`#/${page}${level === 'learner' ? '?l=learner' : ''}`), at = h.indexOf('data-figure="lens-demicube-moves"'), fig = at < 0 ? '' : h.slice(at, h.indexOf('</figure>', at));
     const block = fig.slice(fig.indexOf('data-motion-rows'));
```

`tests/story/ask.test.mjs` part D: the palette's hits on the names of the leaves.

```diff
--- a/tests/story/ask.test.mjs
+++ b/tests/story/ask.test.mjs
@@ -17,4 +17,5 @@
 //   C rankStory and rankRows of src/app/search.js against the ranking computed here, on the fixture.
-//   D the palette: a hit on a page of Explore found from a page outside Explore carries l=learner; found inside Explore (and from #/, the
-//     Explore home), it carries nothing, and no other hit does.
+//   D the palette: no page of Explore is left (round 7: the leaves live on the Atlas pages); a hit on the name of a leaf of the door's map
+//     (content/explore/registry.json) opens the page the leaf lives on, at its anchor, from any page, and carries no parameter of its own (the
+//     reader's level is kept); no other hit does.
 // Usage: node tests/story/ask.test.mjs   (exit 1 on a failure; the offline modules from NODE_MODULES, default /opt/npm-tools/node_modules)
@@ -258,3 +259,3 @@
 
-// ------------------------------------------------------------------ D. the palette: hits on Explore pages and l=learner
+// ------------------------------------------------------------------ D. the palette: hits on the names of the leaves (round 7)
 part = 'D';
@@ -262,18 +263,17 @@
 {
-  const explorePages = REAL.pages.filter(p => p.route === 'explore' || String(p.route).startsWith('explore/'));
-  const leaf = explorePages.find(p => p.kind === 'leaf');
-  ok(!!leaf, 'the content has an Explore leaf to search for');
-  if (leaf) {
-    const name = leaf.title.phys;
-    for (const [from, outside] of [['#/atlas', true], ['#/rule', true], ['#/steps/grav2?m=math', true], ['#/explore', false], ['#/explore/moves', false], ['#/', false]]) {
-      const { hits } = ssr.renderSearch(name, from);
-      const h = hits.find(x => x.kind === 'page' && x.path === leaf.route);
-      if (!ok(!!h, `palette "${name}" from ${from}: a hit on the leaf ${leaf.route}`)) continue;
-      ok(outside ? h.extra && h.extra.l === 'learner' : !h.extra, `palette "${name}" from ${from}: the leaf's hit carries ${JSON.stringify(h.extra)} (${outside ? 'l=learner: a way into Explore from outside it' : 'nothing: the palette is inside Explore'})`);
-      const others = hits.filter(x => x !== h && x.extra && !(x.kind === 'page' && (x.path === 'explore' || x.path.startsWith('explore/'))));
-      ok(!others.length, `palette "${name}" from ${from}: no hit outside Explore carries parameters (${others.map(x => x.key).join(', ')})`);
-    }
+  const REG = readJSON(path.join(ROOT, 'content', 'explore', 'registry.json'));
+  const leaves = [...(REG.path || []), ...(REG.shelf || []), ...(REG.lenses || [])].filter(e => e && e.name && e.page != null && REAL.pages.some(p => p.route === e.page));
+  ok(leaves.length > 0, "the door's map has leaves on pages of the Atlas to search for");
+  ok(!REAL.pages.some(p => p.route === 'explore' || String(p.route).startsWith('explore/')), 'no page of Explore is left (the leaves live on the Atlas pages)');
+  for (const e of leaves) for (const from of ['#/', '#/rule', '#/steps/grav2?m=math&l=learner']) {
+    const { hits } = ssr.renderSearch(e.name, from);
+    const h = hits.find(x => x.kind === 'leaf' && x.id === e.slug);
+    if (!ok(!!h, `palette "${e.name}" from ${from}: a hit on the leaf ${e.slug}`)) continue;
+    ok(h.path === e.page && h.at === (e.anchor || 'top'), `palette "${e.name}" from ${from}: the hit opens ${h.path} at ${h.at} (the leaf's page ${e.page} at ${e.anchor || 'top'})`);
+    ok(!h.extra, `palette "${e.name}" from ${from}: the leaf's hit carries ${JSON.stringify(h.extra)} (nothing: the reader's level is kept)`);
+    const others = hits.filter(x => x !== h && x.extra);
+    ok(!others.length, `palette "${e.name}" from ${from}: no other hit carries parameters (${others.map(x => x.key).join(', ')})`);
   }
   const { hits } = ssr.renderSearch('rule', '#/atlas');
-  ok(hits.filter(x => x.kind === 'page' && !String(x.path).startsWith('explore')).every(x => !x.extra), 'a page hit outside Explore carries no parameter');
+  ok(hits.filter(x => x.kind === 'page').every(x => !x.extra), 'a page hit carries no parameter');
 }
@@ -287,2 +287,2 @@
 }
-console.log('PASS: Ask answers with at most three lead story rows holding most of the words, then at most twelve statements that are not story rows, both as Statements, ranked as computed here; an empty answer in one line; palette hits into Explore from outside it carry l=learner');
+console.log('PASS: Ask answers with at most three lead story rows holding most of the words, then at most twelve statements that are not story rows, both as Statements, ranked as computed here; an empty answer in one line; palette hits on the names of the leaves open their pages at their anchors');
```

Optional (silences the two warnings of merge_explore; the model already draws these leaves only where the map places them):
`content/story/chapters.json` — `steps/category` `cat-label0` `"figure": ["cube-category", "leaf-zero"]` → `["cube-category"]`; `steps/schuller`
`sc-chain` `"figure": ["schuller-chain", "leaf-light"]` → `["schuller-chain"]`. `content/story/landing.json` — the key `"home"` is no longer read.

With EXPORT's route (`agents` in `src/app/router.js`), this copy's `src/app/App.jsx` needs `import Agents from '../pages/Agents.jsx';` and
`case 'agents': return <Agents />;`; the door and the Contents menu then show the guide (`content/story/door.json` `agents`), so landing.json needs
no card for it.
