# Script changes, part A (SCR-A): Kerr, curved points, bounds, and the d-sign patches

This is the closing of batch 3 on the script side, part A, done in the V2 repository as `B3_ADDENDUM.md` asks. Paths are relative to the repository root; `G` = `checks/selfcheck/gravity/`. Every run below used the addendum's command, run from `checks/`: `python3 -I -B selfcheck/gravity/<script>.py` under `ulimit -v 3000000`, `nice -n 10`, `timeout 900`, with `OMP_NUM_THREADS=1`. The mutation tables come from `$SP/leads3/tools/mutate_pkg.py`, run with `python3 -B` from `checks/`. All runs took place on 2026-10-12. Before any edit, `G` was byte-identical to `$SP/leads3/_review/pkg/selfcheck/gravity/`, the engine files included (`diff -rq` found no difference).

## 0. Summary

| file | finding | kind of change | ok before → after | mutation table |
|---|---|---|---|---|
| `G/h5l_bianchi_kerr.py` | AUD-A-1 (S1), AUD-A-12 (S4); the script part of AUD-A-3 | behaviour: one check line corrected, three lines added; docstring | 79 → 82 | re-run: all 8 faults still seen |
| `G/b3c4_curved_points.py` | AUD-D-1 (S2) | behaviour: the 14th d-probe line; Scope line of the docstring | 37 → 44 | re-run: M4 now seen (6 lines), other cells unchanged |
| `G/a5_strong_maps.py` | AUD-D-17 (S4); AUD-D-4 (S3), the script's share of it | docstring and four printed messages only | 137 → 137 | kept (no behaviour change) |
| the 13 scripts of L7's `patches/` | L7, D2 of the ledger | one line each (the d-probe call), applied with `patch -p0` | +7 each | not re-run here (see §4) |
| `G/d_probe.py`, `G/blind_spot_probes.py`, `G/a6_strong.py`, `G/f3_kn_horizons.py`, `G/f4_komar_kn.py` | AUD-D-1/-2, AUD-D-6/-7/-12/-13, AUD-A-5..11 | none: no finding is about the wording of these files (§5) | unchanged | unchanged |

There are 16 re-run logs, all exit 0, with 0 FAIL lines and the last line `FAILS (<ID>): none`. One test outside this folder needs a one-line change for the a4 probe lines: `tests/engines.test.mjs`, an exact patch in §7. The mutation tables written are `G/mut/h5l_bianchi_kerr.mut.log` and `.json`, `G/mut/b3c4_curved_points.mut.log` and `.json`, and `G/mut/b3c4_curved_points.only_M4.mut.log` and `.json`. The words scan (`node $SP/leads/tools/scan_words.mjs`) found no hits on all 17 script files touched or read for changes (the 16 changed ones and `d_probe.py`).

## 1. `h5l_bianchi_kerr.py` (H5L-B-Kerr)

**AUD-A-1 (S1), the fix.** `weyl_pseudo_invariant` (lines 212–225) computed ½ Σ W_{rsmv} [mvpq] W^{rspq}, with all four indices of the second factor raised. Because g ≠ η at these points, that sum is not a scalar. The function now computes the invariant itself:

- W·*W = ½ W_{rsmv} ε^{mvpq} W^{rs}_{pq}, with ε_0123 = +1.
- det g = −1 on these frames (det e = 1), so ε^{mvpq} = −[mvpq] and I2 = −½ [mvpq] W_{rsmv} W^{rs}_{pq}.
- Only r and s are raised in the second factor.
- W·W is unchanged.

Three helpers were added:

- `weyl_contraction_all_raised(st)` (lines 227–234): the old contraction, kept only for the control.
- `frame_weyl_invariants(C, ct, E)` (lines 236–253) [bit]: W·W and W·*W from the engine's Weyl 2-form W^{ab}. They are computed from its frame components W^{ab}_{cd} = W^{ab}_{μν} E^μ_c E^ν_d, with indices moved by η.
- `psi2_kn(M, a, s, r, c)` (lines 257–262): the recalled Kerr–Newman Ψ₂ = (−Mρ + 2s)/(ρ̄³ρ), with ρ = r + i a cos θ and Q² = 2s, as exact Gaussian rationals.

The part-3 loop stores the values for each point (lines 344–347). That includes `eq` (cos θ = 0), so "the two equatorial points" is checked, not only named: the zero-pattern line requires W·*W = 0 ⟺ d_∇Cot = 0 ⟺ cos θ = 0 at each point, and the [recalled] line requires Im Ψ₂ = 0 ⟺ cos θ = 0. The block after the loop (lines 349–364) prints one corrected line and three added ones.

**Old line (log line 87), now false as worded:** `[std] at the 4 Kerr-Newman points: d_nabla Cot = Weyl ^ S vanishes exactly where the pseudoscalar Weyl invariant W_{rsmv} (*W)^{rsmv} vanishes (the equatorial points: no magnetic part), and is nonzero where it does not (the generic and axis points); the scalar invariant W_{rsmv} W^{rsmv} != 0 everywhere; I2 = -4688119521360000000000/10063170355379759040105652969, 0, -897/156250, 0`

**New lines (log lines 87–90), verbatim:**
1. `[std] at the 4 Kerr-Newman points: d_nabla Cot = Weyl ^ S vanishes exactly where the pseudoscalar Weyl invariant W.*W = (1/2) W_{rsmv} eps^{mvpq} W^{rs}_{pq} (eps_0123 = +1) vanishes (the two equatorial points), and is nonzero where it does not (the generic and axis points); the scalar invariant W.W = W_{rsmv} W^{rsmv} != 0 at all four; W.*W = -2930074700850000000/1005412164589845043471441, 0, -207/15625, 0`
2. `[bit==std] at the 4 Kerr-Newman points: W.W and W.*W of the engine's Weyl 2-form W^{ab} (frame components W^{ab}_{cd} = W^{ab}_{mu nu} E^mu_c E^nu_d, indices moved with eta) = W.W and W.*W of the std route (coordinate components, indices moved with g)`
3. `[std] [recalled] at the 4 Kerr-Newman points: W.W = 48 Re(Psi_2^2) and W.*W = -48 Im(Psi_2^2) exactly, with the Kerr-Newman Weyl scalar Psi_2 = (-M rho + 2 s)/(rhobar^3 rho), rho = r + i a cos(theta) (recalled, Q^2 = 2 s); Psi_2 is real at the two equatorial points and not real at the generic and axis points`
4. `[ctl] the permutation symbol met by p, q raised, (1/2) [m v p q] W_{rsmv} W^{rspq} (all four indices of the second factor raised), is not W.*W: with either sign it differs from W.*W at the generic and axis points (-4688119521360000000000/10063170355379759040105652969, -897/156250 against -2930074700850000000/1005412164589845043471441, -207/15625; g != eta at these points) (ok)`

**Values to quote.** These are exactly the values the audit computed (`scratch_AUD-A/wf_offeq.py`):

| point | W·*W (exact) | W·*W (float) |
|---|---|---|
| (M, a, s) = (5, 1, 4), generic r = 20 | −2930074700850000000/1005412164589845043471441 | −2.914e-6 |
| (5, 1, 4), equator r = 20 | 0 | 0 |
| (7/2, 2, 1), axis r = 4 | −207/15625 | −0.013248 |
| (7/2, 2, 1), equator r = 5 | 0 | 0 |

The old contraction is −4.659e-7 at the generic point and −5.741e-3 at the axis point, that is 0.160 and 0.433 times the invariant. The zero pattern is the same, so GRV-004's clause "where the pseudoscalar invariant W·*W of the Weyl tensor vanishes" is now supported as printed. AUD-A-1's fallback wordings (the README cell and the GRV-004 clause) are not needed. The script does not print W·W values, so the ledger should not quote them.

**AUD-A-12 (S4) and the script part of AUD-A-3.** These are docstring edits:

- **Scope (lines 24–29).** It now lists the six `MORE_KERR` points: (5, 3) at r = 1 (the inner horizon), at r = 4, at r = 1/2 (inside r₋) and on the south axis; (1, 1/2) at r = 2; (3/2, 2) at r = 1 (a > M). It states that `std_route2` runs at the three `KERR_PTS` points, and that at the six `MORE_KERR` points only the engine's lines and the Christoffel Ricci 2-jet run (no `std_route2`). This is AUD-A-3's limit, now in the script's own words. The Kerr–Newman points are now named by kind: generic and equator for (5, 1, 4), axis and equator for (7/2, 2, 1).
- **[bit], [std], [bit==std] and Controls (lines 9–23).** They describe the invariants, the recalled Ψ₂ and the control.
- **Exports line.** It lists the three helpers, and it now gives the actual signature `cartan_run(C, e, want_E)`; the text had an `E` argument that the function does not take.

**Counts.** 79 ok → 82 ok: [bit] 38 → 38, [std] 23 → 24, [bit==std] 11 → 12, [ctl] 7 → 8. There are 0 FAIL lines and the last line is `FAILS (H5L-B-Kerr): none`. The run took 22 s. The log and the mutation table were re-run on the final file, after the last docstring edit and the `eq` condition, and the check lines are identical to the first run. Apart from timing lines, the diff with the old log is exactly the one changed line and the three added ones.

**Mutation table** (`G/mut/h5l_bianchi_kerr.mut.log`, run on the final file; baseline 82 ok, 0 fail):

| | M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 |
|---|---|---|---|---|---|---|---|---|
| before (H5LK, `_review`) | 49 | 7 | 9 | 4 | 9 | 39 | 9 | 9 |
| after | 50 | 7 | 9 | 4 | 9 | 40 | 9 | 9 |

All eight faults are still seen. The extra failing line under M1 and under M6 is the new [bit==std] invariant line; this was checked by listing the failing lines. M4 does not change it: under d → −d the Weyl 2-form is unchanged, and only D_L W and D_L C flip.

**Sentence parts for LED (not script text):**

- AUD-A-2: the GRV-004 checkedBy. Use the audit's replacement, `… W.f != 0 at a generic and an axis Kerr-Newman point, W.f = 0 at the two equatorial points`.
- AUD-A-3: the GRV-004 parenthesis (Christoffel comparison at 3 of the 9 Kerr points).
- AUD-A-4: INP-058 (Cotton as a 1-jet).
- AUD-A-13: section C wording.

## 2. `b3c4_curved_points.py` (B3C4-curved)

**AUD-D-1 (S2).**

- **Line 166.** It is `    from d_probe import d_sign_probe; d_sign_probe()`. It sits right after the first `head(...)` (line 165, inside `main()`, outside any loop) and has the same form as the 13 L7 patches. The probe uses its own random generators and no truncation, and the script's `random.Random(9)` is not touched. The 37 old check lines are identical in the new log.
- **Docstring Scope (lines 22–24).** It separates the two parts: (A) runs at k = 0, +1, −1, with two rational points for each of k = ±1. (B), the exponential potential, runs at k = 0 and c = 0 only, at (κ, λ) = (1, 1) and (2, 3). The part-5 heading of the log already said "k = 0, c = 0"; the Scope line did not, and it is the limit that AUD-B-5 asks to keep.

**Counts.** 37 ok → 44 ok: [bit] 11, [std] 8 → 9, [bit==std] 9 → 13, [ctl] 9 → 11. There are 0 FAIL lines, the last line is `FAILS (B3C4-curved): none`, and the run took 7 s. The diff with the old log is the seven probe lines plus timing lines.

**`--only M4`** (`G/mut/b3c4_curved_points.only_M4.mut.log`): baseline 44 ok; M4 is SEEN, 38 ok and 6 fail. The six failing lines are the probe's.

**Mutation table** (`G/mut/b3c4_curved_points.mut.log`):

| | M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 |
|---|---|---|---|---|---|---|---|---|
| before (L9bB, `_review`) | 29 | 19 | 0 | 0 | 0 | 11 | 1 | 1 |
| after | 29 | 19 | 0 | **6** | 0 | 11 | 1 | 1 |

M4 is now seen, through the six probe lines only. M3 and M5 stay silent (L9bB: silent by construction on these frames). Every cell seen before is still seen with the same count.

## 3. `a5_strong_maps.py` (A5-strong)

- **AUD-D-17 (S4), docstring lines 26–28.** The text was "its j-th derivative (degree j + 2)/(1 -+ beta_k^2)^(j+1), so over N0^3 … every coefficient has degree <= 6". It now reads "its j-th derivative (degree 2 for j = 0, at most 2j + 1 for j >= 1)/(1 -+ beta_k^2)^(j+1), so over N0^3 (N0 = (U U~)(0)) every term has degree <= 6 in each plane's coefficients and 1 in e: 3n(n - 1) + 1", which is the audit's text.
  - I checked the degrees myself with exact polynomial arithmetic in (β₀, β₁, β₂), for rotation and boost planes (scratch `rotor_degree_check.py`). The 2β/(1 ± β²) entries have numerator degrees [1, 3, 5] for j = 0, 1, 2; the (1 ∓ β²)/(1 ± β²) entries have [2, 2, 4].
  - Over (1 ± β₀²)³ these give [5, 5, 5] and [6, 4, 4], so the per-plane maximum is 6. The old "degree j + 2" fails at j = 2 for the 2β entries.
  - So q = 3n(n − 1) + 1 stands. The re-run prints the same D, r and bound for all 54 rows of the bound table, and the same four combined bounds (1.74e-06, 1.19e-05, 1.09e-05, 2.50e-04).
- **AUD-D-4 (S3), the script's share.** The audit notes that the log's own summary repeated the loose "P, T, PT, and U U~ of either sign". The four summary messages (log lines 207–210) now name the nine types as the bound table runs them:
  - `n = 3, Cayley maps (the Cayley map and P, T, PT times it): …`
  - `n = 3, rotor maps (U U~ > 0 and U U~ < 0, and P, T, PT times the rotor with U U~ > 0): …`
  - and the same two for n = 4.

  Docstring line 21 now says "times the Cayley map and times the rotor map with U U~ > 0". The INP-045 sentence itself is LED's.
- **Counts.** 137 ok (unchanged), 0 FAIL, last line `FAILS (A5-strong): none`, 28 s. The diff with the old log is the four summary lines and timing lines; the check conditions are unchanged.
- **Mutation table.** Kept: `$SP/leads3/S6/mut/a5_strong_maps.mut.log` = `$SP/leads3/_review/mut/a5_strong_maps.mut.log`, M1:44 M2:44 M3:24 M4:24 M5:24 M6:44 M7:24 M8:24.

## 4. The 13 d-probe patches of L7 (applied here)

They were applied from `G` with `patch -p0 --no-backup-if-mismatch < $SP/leads3/L7/patches/<name>.diff`. All 13 dry runs passed first. Each patched file is byte-identical to `$SP/leads3/L7/patched/<name>.py`, and no `.orig` or `.rej` file was left. Each log was re-run once, one at a time.

- **Diffs against the old logs.** Each diff is the seven probe lines. For `a4_einstein_tensor` and `d2_linearised` it also has the probe's own heading line, `D-PROBE  the sign of the engine's exterior derivative (n = 3, 4)`, and a blank line. The other differences are timing lines and, in `dup_6`, the module-version lines, which print file modification times.
- **Comparison with L7.** The check lines (`ok`/`FAIL`) of every new log are identical to L7's patched run from the package root (`$SP/leads3/L7/runs/patched/<name>.root.log`).
- **Imports.** No other script's output changes. The importers of these modules use only their helpers (for example `a2b_strong_sampling` uses `A2.residual_DR` and `A4m.engine_E`, `g2_forque_*` use the `G2T` helpers, `c3_rn` uses `C1.std_G`); none calls a function that holds the probe line.

**The 14 patched scripts** (D2's table with its 14th row):

| script | probe line | ok before | ok after | last line | s (this run) | M4 before | M4 after (failing lines) |
|---|---|---|---|---|---|---|---|
| `a2_sampling.py` | 50 | 37 | 44 | `FAILS (A2): none` | 41 | silent | seen (6) |
| `a4_einstein_tensor.py` | 121 (own heading) | 30 | 37 | `FAILS (A4): none` | 4 | silent | seen (6) |
| `b3c4_curved_points.py` | 166 | 37 | 44 | `FAILS (B3C4-curved): none` | 7 | silent | seen (6), run here |
| `c1_birkhoff.py` | 57 | 16 | 23 | `FAILS (C1): none` | 17 | silent | seen (6) |
| `d2_linearised.py` | 383 (own heading) | 97 | 104 | `FAILS (D2): none` | 4 | silent | seen (6) |
| `dup_6.py` | 17 | 20 | 27 | `FAILS (DUP-6): none` | 1 | silent | seen (6) |
| `e2s4_spin_fluid.py` | 101 | 14 | 21 | `FAILS (E2S4-fluid): none` | 8 | silent | seen (6) |
| `g2_tidal_forque.py` | 157 | 93 | 100 | `FAILS (G2): none` | 1 | silent | seen (6) |
| `h1_petrov.py` | 23 | 157 | 164 | `FAILS (H1): none` | 3 | silent | seen (6) |
| `h1_duality_rotation.py` | 247 | 117 | 124 | `FAILS (H1-rotation): none` | 5 | silent | seen (6) |
| `h3_pseudoscalar.py` | 93 | 89 | 96 | `FAILS (H3-pseudoscalar): none` | 14 | silent | seen (6) |
| `h5s_conformal.py` | 93 | 100 | 107 | `FAILS (H5S): none` | 2 | silent | seen (6) |
| `l3_cartan_weyl.py` | 322 | 288 | 295 | `FAILS (L3): none` | 4 | silent | seen (6) |
| `l3_cartan_weyl_flipped.py` | 302 | 292 | 299 | `FAILS (L3-flipped): none` | 7 | silent | seen (6) |

For the 13 L7 scripts, "M4 after" is L7's `--only M4` run on the same bytes with the same engine: `$SP/leads3/L7/runs/patched/<name>.m4.log`, all 13 SEEN with 6 failing lines. Its full tables for five of them show the seven other cells unchanged. `gravity_selfcheck.py`, `b1lib.py` and `d_probe.py` here are byte-identical to L7's, so I did not repeat those 13 runs. The probe reads only d, so none of the other seven faults can change through it.

## 5. Findings that need no script change (and why)

- **AUD-D-1, the d_probe header.** `d_probe.py` does not list its callers; its header gives only the form of the call. The list belongs to README D3 (LED).
- **AUD-D-2.** `blind_spot_probes.py` never says "silent cells". Its own title is "Three places where a check of the engine cannot see an engine fault, and the reason, checked", which is AUD-D-2's meaning. Its docstring already names D1's weak-field frame and "Kerr (5, 3) at 6 points of C2's grid; Schwarzschild at 4 points", and its log lines are scoped the same way. The "silent cells" wording is in the README row D1 and in D3 paragraph 2 (LED).
- **AUD-D-6, -7, -12, -13 (`a6_strong.py`).** The docstring already says "D = 4 for every form identity". The ranks paragraph already gives one sample's nullity as an upper bound with certainty and the null vectors as the lower bound. The log prints "Holst = 0 (D = 18) at most 5.89e-06 with R = 500" and "(4/101)^3 = 6.22e-05 < 6.3e-5". All four findings are about INP-044 and the D1 row (LED).
- **AUD-D-8.** The script's `TYPES` and its bound table name the nine types correctly; "P, T, PT times each" is the D1 row's wording (LED).
- **AUD-A-5..11 (`f3_kn_horizons.py`, `f4_komar_kn.py`).**
  - The docstrings write Ω_H = 1/(2M) (AUD-A-8). F4-KN's Extremal paragraph says "ours, derived from the closed forms", and its [std] log line says "along dM … on members approaching XK and X1" (AUD-A-5).
  - The F3-KN off-horizon control prints "8 points per member … for the generator of every horizon … 160 of 160 samples" (AUD-A-9). The ∇χ lines say off-axis and pole explicitly (AUD-A-6).
  - Every one of these findings is about row text (NUL-001, NUL-003, EQN-020, the D1 row F3-KN; AUD-A-11 for "both horizons").

## 6. For LED: the exact numbers and texts the README, the ledger and `content/*.json` need

- **D1, H5L-B-Kerr.** ok **82**, FAIL 0, exit 0, last line `FAILS (H5L-B-Kerr): none`, s 22.
  - Standard-route cell, proposed: `an own Christoffel route as jets (metric 4-jet, Riemann 2-jet, Schouten); h5l_bianchi.std_route2 at the 3 Kerr and 4 Kerr-Newman points; the 2-jet helpers as independent series routes; W.W and W.*W = (1/2) W_{rsmv} eps^{mvpq} W^{rs}_{pq} from the standard Weyl tensor (indices moved with g), equal to those of the engine's Weyl 2-form and to 48 Re Psi_2^2, -48 Im Psi_2^2 of the recalled Kerr-Newman Psi_2`.
  - "What it checks" may keep its text; optionally end it with `, where W.*W vanishes`.
  - AUD-A-12: the row's "Kerr (9 points, 3 members)" needs no change.
- **D1, B3C4-curved.** ok **44**, FAIL 0, last line unchanged, s 7. Optionally add `; the d-sign probe (D-PROBE's d_sign_probe)` to "What it checks".
- **D1, A5-strong.** ok 137, FAIL 0, last line unchanged, s 28. The row's map-type wording is AUD-D-8 (LED).
- **D2.** The table becomes the 14 rows of §4; "13 scripts had no line that reads d itself" becomes 14. The line goes after the first heading, and in `a4_einstein_tensor.py` and `d2_linearised.py` once before the loop over n, under its own heading.
- **D3, paragraph 1.** Add `b3c4_curved_points.py` to the list of callers (AUD-D-1, preferred form) and the AUD-D-14 clause on a4/d2. The fact the paragraph states stays true for all 14: "in these scripts M4 is seen through those six lines only" (B3C4-curved: M4:6).
- **D4, counts.** My changes add 3 (H5L-B-Kerr) + 7 (the 14th probe) = **10** check lines to the draft's 7,002. Before SCR-B's changes the total is 5,569 + 1,342 + 3 + 7 × 14 = 7,012. AUD-D-1's alternative D4 sentence is not needed; with the patch, 12 of the 14 new rows see M4, by SCR-A's runs for B3C4-curved and H5L-B-Kerr and the `_review` tables for the others; SCR-B reports any change to its six. G1-force and G1-forced build no engine object.
- **`content/checks.json`** (addendum §3.3).
  - For `selfcheck/gravity/h5l_bianchi_kerr.py`, `ids[0].statement` and `what` are truncated today ("… Kerr-Schild frames at"). Proposed: `the Bianchi identity of the so(2,4) Cartan curvature (f = Schouten, b = 0) on exact 4-jets of Kerr (9 points, 3 members) and Kerr-Newman (4 points, 2 members) Kerr-Schild frames: on Kerr E_a and the Schouten tensor vanish as 2-jets, the Cotton 2-form as a 1-jet, D_A F = 0 and D_L W = 0 with W != 0; on Kerr-Newman D_L W = e C - e C != 0 and D_L C = W.f with both sides nonzero at a generic and an axis point and zero at the two equatorial points, where the pseudoscalar Weyl invariant W.*W = (1/2) W_{rsmv} eps^{mvpq} W^{rs}_{pq} vanishes (W.W and W.*W of the engine's Weyl 2-form equal the Christoffel route's and the recalled Psi_2's)`.
  - Its `independentRoute` may add `; W.W and W.*W from h5l_bianchi.std_route2's Weyl tensor; the recalled Kerr-Newman Psi_2`.
  - For `selfcheck/gravity/b3c4_curved_points.py` (`ids` and `what` are empty today), proposed `what`: `the Einstein-scalar FRW series solved at the spatial origin (k = +1, -1) satisfy the engine's equations at rational points x0 != 0 of the isotropic chart with the exact Taylor jet of 1/(1 + k r^2/4); the exponential potential reproduces a = t^p, phi = (2/lam) ln t about t0 = 1 (k = 0, c = 0; p and V0 derived); the d-sign probe of d_probe.py`.
- **`content/check_runs.json`, one run per re-run script.** All 16 runs have date `2026-10-12`, machine `the round-7 closing, run from checks/`, fail 0, `passed: true` and source `checks/selfcheck/gravity/logs/<script>.log`:

| script (`checks/selfcheck/gravity/…`) | ok | lastLine | seconds |
|---|---|---|---|
| `a2_sampling.py` | 44 | `FAILS (A2): none` | 41 |
| `a4_einstein_tensor.py` | 37 | `FAILS (A4): none` | 4 |
| `c1_birkhoff.py` | 23 | `FAILS (C1): none` | 17 |
| `d2_linearised.py` | 104 | `FAILS (D2): none` | 4 |
| `dup_6.py` | 27 | `FAILS (DUP-6): none` | 1 |
| `e2s4_spin_fluid.py` | 21 | `FAILS (E2S4-fluid): none` | 8 |
| `g2_tidal_forque.py` | 100 | `FAILS (G2): none` | 1 |
| `h1_petrov.py` | 164 | `FAILS (H1): none` | 3 |
| `h1_duality_rotation.py` | 124 | `FAILS (H1-rotation): none` | 5 |
| `h3_pseudoscalar.py` | 96 | `FAILS (H3-pseudoscalar): none` | 14 |
| `h5s_conformal.py` | 107 | `FAILS (H5S): none` | 2 |
| `l3_cartan_weyl.py` | 295 | `FAILS (L3): none` | 4 |
| `l3_cartan_weyl_flipped.py` | 299 | `FAILS (L3-flipped): none` | 7 |
| `b3c4_curved_points.py` | 44 | `FAILS (B3C4-curved): none` | 7 |
| `h5l_bianchi_kerr.py` | 82 | `FAILS (H5L-B-Kerr): none` | 22 |
| `a5_strong_maps.py` | 137 | `FAILS (A5-strong): none` | 28 |

## 7. Not done here, and pending on others

- **`tests/engines.test.mjs` needs one line changed (an exact patch for the lead; SCR-A does not own the file).** Section I counts every `[ctl]` in `G/logs/a4_einstein_tensor.log` and requires the count to equal the 12 controls stored in `engines/gravityChecks.js`. The d-probe adds two `[ctl] d-probe:` lines, so the count is now 14 against 12. On this copy the suite gives `engines: 1089 of 1090 checks hold, 1 FAIL` (`A4: the 12 controls and "FAILS (A4): none" = the log`).
  - The patch counts the controls that are not the probe's. The total stays strict: an extra or a missing A4 control still fails, which I checked with planted offenders on the log text.
  - Line 393: replace `(A4L.match(/\[ctl\]/g) || []).length === A4.controls.length` with `(A4L.match(/\[ctl\] (?!d-probe:)/g) || []).length === A4.controls.length`.
  - With the patch, run from a temporary shadow root over this copy, the suite gives `engines: 1090 of 1090 checks hold`. The diff is `docs/round7/batch3/scratch_scr-a/engines_test_A4_ctl.patch` (`patch -p1` from the repository root; checked with `--dry-run`).
  - No other suite reads the logs or scripts changed here: by grep, `p11` reads `f2_first_law`, `f2_kn_maxwell`, `f4_komar` and `c2_kerr` logs; the `C1` checks of section I use `includes` and are unaffected. `node tests/logbook.test.mjs` passes: 580 of 580.

- **`G/MANIFEST.sha256`** is not edited. It lists the v15 files only: the 14 batch-3 scripts, their logs and `mut/` are already absent from it. After this change, the sums of 13 scripts and 13 logs no longer match, and after LED's edit neither does that of `README.md`. It should be regenerated once, after the merge of SCR-A, SCR-B and LED, as the folder's README defines it (every file except itself): `cd checks/selfcheck/gravity && find . -type f ! -name MANIFEST.sha256 -printf '%P\n' | LC_ALL=C sort | xargs sha256sum > MANIFEST.sha256`. Whether `mut/` belongs in it is the lead's call. The sums of the files I wrote are in `docs/round7/batch3/scratch_scr-a/NOTES.md`.
- **`G/logs/SUMMARY.txt`** is the record of the author's whole run, and `G/run_all.sh` does not list the 14 batch-3 rows; both are left as they are. A full `run_all.sh` rewrites SUMMARY.txt.
- **The README** (D1, D2, D3, D4), the ledger rows and `content/*.json` belong to LED (§6). The scripts of `agent_b3_scripts_b.md` belong to SCR-B.
- **Scratch.** `docs/round7/batch3/scratch_scr-a/` holds my notes and the sums (`NOTES.md`), the run status (`runs_status.txt`), the prototypes (`proto_inv.py`, `rotor_degree_check.py`, `which_lines.py`), `scr-a_scripts.diff` (all 16 script diffs; `patch -p1` from the root of `$SP/v3/one-rule` reproduces the 16 final files, checked), the test patch and the outputs of the two suites. It is not for merging.
