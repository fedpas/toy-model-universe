# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# prov_check_final.py: provenance and anchors of the final ledger of batch 3 (extends deliver_batch3/work/prov_check.py, which stays as it is).
#
# Provenance. Every text the final ledger proposes (the "Should read" blockquotes of section B, the checkedBy and standardRef texts of section B,
# the README paragraphs of section D3 and the "What it checks" / "Standard route" cells of section D1) is split into sentences, and each sentence
# is put in one class:
#   LEAD    verbatim in a lead's text (leads3/<LEAD>/RESULT.md, SHIP_NOTES.md, proposed_wording_only.txt)
#   AUDIT   verbatim in an audit's replacement text (deliver_batch3/audit/AUD-*.md: blockquotes, and the quoted text after "Replacement",
#           "Proposed", "replace ... by/with", "suggest", "->", in the findings section; never the quoted text that a finding criticises)
#   TODAY   verbatim in today's text (deliver_batch3/work/rows_today_v15.txt, or the README of checks/selfcheck/gravity/ as the V2 repository
#           v3/one-rule ships it: the README of this repository carries the D1 rows and D3 paragraphs once the apply step has run, and would
#           count them as their own source)
#   SCRIPT  verbatim in the texts the two script agents give for this ledger (v3_agents/scr-a/.../script_changes_A.md, scr-b/.../script_changes_B.md)
#   DRAFT   verbatim in the draft ledger (deliver_batch3/work/LEDGER_BATCH3_draft.md): the coordinator's own edits there (its section C)
#           and its README cells; a sentence that is also a lead's is counted as LEAD
#   SPLICE  covered by verbatim pieces of the sources above (pieces of at least MINPIECE characters), with gaps of at most GAP characters of
#           connecting words or punctuation: a lead's sentence with an audit's replacement applied, or two sources joined; the pieces are printed
#   OWN     anything else: it must be listed, with its reason, in own_wording.txt (next to this file), or the check fails
# Anchors. Every "Today" fragment of section B (blockquotes "> Today: “… <fragment> …”") must be verbatim in today's text of its row in
# rows_today_v15.txt and in the research text of the V2 row the block names (content/texts.json of this repository, or, once the apply step
# has run, the body it replaced, content/story/retired_texts.json).
# Usage, from the repository root:  python3 -B docs/round7/batch3/prov_check_final.py [--verbose]
# Exit 1 when a sentence is OWN and not listed, or an anchor is missing.
import json, os, re, sys

SP = '/tmp/claude-0/-home-claude/74388214-b700-5a31-b3ee-04cbd8de9097/scratchpad/'
HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
LEDGER = os.path.join(HERE, 'LEDGER_BATCH3_final.md')
OWN_FILE = os.path.join(HERE, 'own_wording.txt')
VERBOSE = '--verbose' in sys.argv
MINPIECE, GAP = 10, 8

def norm(s):
    s = s.replace('’', "'").replace('‘', "'").replace('“', '"').replace('”', '"')
    s = s.replace('**', '').replace('`', '')
    s = re.sub(r'\s+', ' ', s)
    return s.strip()

def strip_ctx(s):
    s = s.strip()
    s = re.sub(r'^(…|\.\.\.)\s*', '', s); s = re.sub(r'\s*(…|\.\.\.)$', '', s)
    return s.strip()

# ---------------------------------------------------------------------------------------------------------------- the sources
lead_txt = {}
for lead in ['H5LK', 'L5c', 'L7', 'L9bA', 'L9bB', 'L10b', 'L14', 'S6']:
    t = ''
    for f in ['RESULT.md', 'SHIP_NOTES.md', 'proposed_wording_only.txt']:
        p = SP + 'leads3/%s/%s' % (lead, f)
        if os.path.exists(p): t += open(p, encoding='utf-8').read() + '\n'
    lead_txt[lead] = norm(t)

MARK = re.compile(r'(Replacements?\b[^"“`]*|Proposed\b[^"“`]*|[Rr]eplace\b.*?\b(?:by|with)\b:?|[Ss]uggest\b|→|\bby:|(?<=["”`]) by (?=["“`]))')
QUOTED = re.compile(r'"([^"]{3,})"|“([^”]{3,})”|`([^`]{3,})`')
HEADER = re.compile(r'(Replacements?|Proposed)\b[^"“`]*$')          # a header line whose replacement texts follow as list items
audit_strings = {}
for lane in 'ABCD':
    p = SP + 'deliver_batch3/audit/AUD-%s.md' % lane
    lines = open(p, encoding='utf-8').read().splitlines()
    # the findings section only: from "## 2." to "## 3."
    a = next(i for i, l in enumerate(lines) if l.startswith('## 2'))
    b = next(i for i, l in enumerate(lines) if l.startswith('## 3'))
    out = []; under = False
    for l in lines[a:b]:
        ls = l.strip()
        if not ls or ls.startswith('###'): under = False
        if ls.startswith('> '): out.append(ls[2:]); continue
        ms = list(MARK.finditer(l))
        if ms:
            first = ms[0].group(0)
            tail = l[ms[0].end():] if first.startswith(('Replacement', 'Proposed')) else l[ms[-1].end():]
            rb = list(re.finditer(r'[Rr]eplace\b.*?\b(?:by|with)\b:?|(?<=["”`]) by (?=["“`])', tail))
            if rb: tail = tail[rb[-1].end():]
            for m in QUOTED.finditer(tail): out.append(next(g for g in m.groups() if g))
            if HEADER.search(l) and not QUOTED.search(tail): under = True
            continue
        if under and ls.startswith('- '):
            for m in QUOTED.finditer(ls): out.append(next(g for g in m.groups() if g))
    audit_strings[lane] = [norm(x) for x in out]
audit_txt = ' ¶ '.join(x for v in audit_strings.values() for x in v)

today_raw = open(SP + 'deliver_batch3/work/rows_today_v15.txt', encoding='utf-8').read()
README_V2 = SP + 'v3/one-rule/checks/selfcheck/gravity/README.md'
if os.path.exists(README_V2): readme_today = open(README_V2, encoding='utf-8').read()
else:
    readme_today = open(os.path.join(REPO, 'checks/selfcheck/gravity/README.md'), encoding='utf-8').read()
    print('note: %s not found; the README of this repository stands for today\'s (after the apply step the D1 and D3 texts count as TODAY)' % README_V2)
today_txt = norm(today_raw) + ' ¶ ' + norm(readme_today)
draft_txt = norm(open(SP + 'deliver_batch3/work/LEDGER_BATCH3_draft.md', encoding='utf-8').read())
scr_txt = ' ¶ '.join(norm(open(SP + 'v3_agents/%s/one-rule/docs/round7/batch3/script_changes_%s.md' % (a, b), encoding='utf-8').read())
                     for a, b in (('scr-a', 'A'), ('scr-b', 'B')) if os.path.exists(SP + 'v3_agents/%s/one-rule/docs/round7/batch3/script_changes_%s.md' % (a, b)))
SOURCES = [('LEAD', ' ¶ '.join(lead_txt.values())), ('AUDIT', audit_txt), ('TODAY', today_txt), ('SCRIPT', scr_txt), ('DRAFT', draft_txt)]
SOURCES_D = SOURCES

# own wording: blocks "row: …" / "text: …" / "reason: …", separated by blank lines
own = []
if os.path.exists(OWN_FILE):
    for blk in re.split(r'\n\s*\n', open(OWN_FILE, encoding='utf-8').read()):
        d = {}
        for l in blk.splitlines():
            m = re.match(r'^(row|text|reason):\s*(.*)$', l)
            if m: d[m.group(1)] = m.group(2)
        if 'text' in d: own.append(d)
own_texts = {norm(d['text']): d for d in own}

# ---------------------------------------------------------------------------------------------------------------- sentences and cover
def sentences(s):
    parts = re.split(r'(?<=\.)\s+(?=[A-Z])', s)
    return [p.strip() for p in parts if len(p.strip()) >= 3]

def longest_from(frag, i, src):
    lo, hi = 0, len(frag) - i
    step = MINPIECE
    if frag[i:i + step] not in src: return 0
    lo = step
    while lo < hi:                                   # gallop then bisect
        nxt = min(hi, lo * 2)
        if frag[i:i + nxt] in src: lo = nxt
        else:
            a, b = lo, nxt - 1
            while a < b:
                m = (a + b + 1) // 2
                if frag[i:i + m] in src: a = m
                else: b = m - 1
            return a
    return lo

def cover(frag, sources):
    i, pieces, gaps = 0, [], []
    while i < len(frag):
        best, bcls = 0, None
        for cls, src in sources:
            L = longest_from(frag, i, src)
            if L > best: best, bcls = L, cls
        if best >= MINPIECE:
            pieces.append((bcls, frag[i:i + best])); i += best
        else:
            if gaps and gaps[-1][1] == i: gaps[-1][1] = i + 1
            else: gaps.append([i, i + 1])
            i += 1
    return pieces, [frag[a:b] for a, b in gaps]

def classify(sent, sources):
    for cls, src in sources:
        if sent in src: return cls, [], []
    pieces, gaps = cover(sent, sources)
    if all(len(g) <= GAP for g in gaps) and sum(len(g) for g in gaps) <= max(GAP, len(sent) // 20):
        return 'SPLICE', pieces, gaps
    return 'OWN', pieces, gaps

# ---------------------------------------------------------------------------------------------------------------- the ledger
L = open(LEDGER, encoding='utf-8').read().splitlines()
sec = None; cur = None; v2 = None
frags, anchors = [], []
for ln in L:
    if ln.startswith('## '): sec = ln[3:5].strip(); cur = None
    if ln.startswith('### D'): sec = ln[4:6]
    m = re.match(r'^### ([A-Z]{3}-\d{3}) .*· V2 row ([A-Z0-9a-z\-, ]+)$', ln)
    if m: cur = m.group(1); v2 = [x.strip() for x in m.group(2).split(',')]
    mv = re.match(r'^\*Today\* \(V2 row ([A-Z]{3}-\d{3}[a-z]?);', ln)
    if mv: v2now = mv.group(1)
    if ln.startswith('> Today:'):
        a = ln[len('> Today:'):].strip()
        a = a.strip('“”"')
        anchors.append((cur, v2now, strip_ctx(a)))
        continue
    if ln.startswith('> '):
        txt = strip_ctx(ln[2:]).replace(' [PENDING-SCRIPT]', '')
        frags.append((sec, cur or '-', 'text', txt))
        continue
    if sec == 'B.' and re.match(r'^- \*\*(checkedBy|standardRef)', ln):
        for mm in re.finditer(r'`([^`]+)`', ln):
            frags.append((sec, cur or '-', 'ref', mm.group(1).lstrip('; ')))
    if sec == 'D1' and ln.startswith('| ') and not ln.startswith('| Step') and not ln.startswith('|---'):
        cells = [c.strip() for c in ln.strip('|').split('|')]
        if len(cells) >= 5:
            for c in (cells[2], cells[3]):
                frags.append((sec, cells[0], 'cell', c.replace(' [PENDING-SCRIPT]', '')))

counts = {k: 0 for k in ['LEAD', 'AUDIT', 'TODAY', 'SCRIPT', 'DRAFT', 'SPLICE', 'OWN']}
own_found, own_missing, splices = [], [], []
for (sec_, row, kind, txt) in frags:
    srcs = SOURCES_D if sec_ in ('D1', 'D2', 'D3', 'D4') else SOURCES
    for s in sentences(norm(txt)):
        cls, pieces, gaps = classify(s, srcs)
        counts[cls] += 1
        if cls == 'SPLICE': splices.append((row, s, pieces, gaps))
        if cls == 'OWN':
            hit = own_texts.get(s)
            (own_found if hit else own_missing).append((row, s, gaps))

print('PROVENANCE (sentences of the proposed texts):')
for k, v in counts.items(): print('  %-6s %d' % (k, v))
if VERBOSE:
    for row, s, pieces, gaps in splices:
        print('SPLICE %s: %s' % (row, s[:110]))
        for cls, p in pieces: print('    %-5s %s' % (cls, p[:100]))
        if gaps: print('    gaps: %s' % gaps)
print('OWN, listed in own_wording.txt: %d' % len(own_found))
for row, s, gaps in own_found:
    print('  OWN %s: %s' % (row, s[:160]))
    print('      own words: %s' % [g for g in gaps if len(g.strip()) > 1][:8])
print('OWN, NOT listed: %d' % len(own_missing))
for row, s, gaps in own_missing:
    print('  MISSING %s: %s' % (row, s))
    print('      uncovered: %s' % [g for g in gaps if len(g.strip()) > 1][:12])
unused = [d['text'][:80] for k, d in own_texts.items() if not any(k == s for _, s, _ in own_found)]
if unused: print('own_wording.txt entries matching no sentence: %d' % len(unused)); [print('  ', u) for u in unused]

# anchors
rows_today = {}
cur = None
for l in today_raw.splitlines():
    m = re.match(r'^== ([A-Z]+-\d+) ', l)
    if m: cur = m.group(1); rows_today[cur] = ''; continue
    if cur: rows_today[cur] += l + '\n'
T = json.load(open(os.path.join(REPO, 'content/texts.json'), encoding='utf-8'))
body = {t['row']: t['body'] for t in T if t['level'] == 'research' and t['lens'] is None and t['mode'] == 'both' and t.get('register', 'full') == 'full'}
kept_p = os.path.join(REPO, 'content/story/retired_texts.json')
kept = {}
if os.path.exists(kept_p):
    for r in json.load(open(kept_p, encoding='utf-8')): kept.setdefault(r['row'], []).append(r['body'])
bad_a = 0
for row, v2row, a in anchors:
    n = norm(a)
    in15 = n in norm(rows_today.get(row, ''))
    in_v2 = n in norm(body.get(v2row, '')) or any(n in norm(b) for b in kept.get(v2row, []))
    if not (in15 and in_v2):
        bad_a += 1; print('ANCHOR MISSING %s / %s (v15: %s, V2 today or kept body: %s): %s' % (row, v2row, in15, in_v2, a[:100]))
print('ANCHORS: %d Today fragments checked, %d missing' % (len(anchors), bad_a))
sys.exit(1 if (own_missing or bad_a) else 0)
