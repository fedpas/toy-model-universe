# Disposition of the audit findings of batch 3

One line per finding of `deliver_batch3/audit/AUD-A.md`, `AUD-B.md`, `AUD-C.md`, `AUD-D.md` (61 findings; AUD-B-15 has nine parts, one line each). Decision: **applied** (the final text is in `LEDGER_BATCH3_final.md` at the place named), **script** (SCR-A or SCR-B changes the script; the ledger adjusts only the sentence or README cell that depends on it), **declined** (with the reason), **not a ledger matter** (with the reason). “B · ROW” is the block of the row in section B of the final ledger; the V2 row is named where it differs from the v15 id.

| id | sev. | row or file | decision | where |
|---|---|---|---|---|
| AUD-A-1 | S1 | README H5L-B-Kerr; GRV-004 (the W·*W clause) | script (SCR-A: the contraction with W^{rs}_{pq} in `weyl_pseudo_invariant`, a control with the wrong contraction, new log and mutation table); ledger: the GRV-004 clause stays, the README cell follows SCR-A’s check line | `script_changes_A.md`; B · GRV-004 (GRV-004c); D1 H5L-B-Kerr |
| AUD-A-2 | S1 | GRV-004 checkedBy | applied (the audit’s text: W.f != 0 at a generic and an axis point, W.f = 0 at the two equatorial points) | B · GRV-004 |
| AUD-A-3 | S2 | GRV-004, second place (merge edit 2) | applied (the audit’s parenthesis: the Christoffel route’s d_∇Weyl at the three Kerr points of M = 5, a = 3, its Ricci 2-jet at the other six) | B · GRV-004 (GRV-004c); C · 2 |
| AUD-A-4 | S2 | INP-058, clause 1 | applied (the Cotton part zero as a 1-jet; the control says E_a and the Schouten tensor are not zero at degree 2) | B · INP-058 |
| AUD-A-5 | S3 | NUL-001 (a) | applied (its dM part checked on members approaching extremal Kerr and one extremal Kerr–Newman member); the optional exact closed form declined: it is the auditor’s derivation and no script line checks it in all three directions | B · NUL-001 (NUL-001d) |
| AUD-A-6 | S3 | EQN-020 | applied (“null off the axis”) | B · EQN-020 |
| AUD-A-7 | S3 | NUL-001, line 4, the count that stays | applied (three Kerr members, extremal Kerr and Kerr just off it among them, and two Kerr–Newman members) | B · NUL-001 (NUL-001d) |
| AUD-A-8 | S4 | NUL-001 (c), NUL-003 | applied (Ω_H = 1/(2M) in both) | B · NUL-001 (NUL-001d), B · NUL-003 |
| AUD-A-9 | S4 | NUL-003 | applied (both replacements: the Kerr members named; 96 points, per generator) | B · NUL-003 |
| AUD-A-10 | S4 | NUL-001 (a), insertion point | applied (after “… and the Smarr relation.”) | B · NUL-001 (NUL-001d); C2 |
| AUD-A-11 | S4 | README F3-KN | applied (one double horizon on each extremal member) | D1 F3-KN |
| AUD-A-12 | S4 | `h5l_bianchi_kerr.py` docstring | script (SCR-A: the six `MORE_KERR` points in the Scope) | `script_changes_A.md` |
| AUD-A-13 | S4 | section C, item 1 | applied (the reason worded as the audit gives it) | C · 1 |
| AUD-A-14 | S4 | INP-058 against NUL-001 and EQN-020 (two stress signs) | declined: the relation the audit asks to confirm is the package’s definition, τ_a = −T^b_a Θ_b, stated in GRV-011’s text where both stresses are defined, so the two rows agree; the suggested parenthesis would put a row id into a page sentence, which no research text does | — |
| AUD-B-1 | S1 | GRV-011 piece 2b; `b3c4_dirac_frw.py` docstring line 18; L9bB SHIP_NOTES | applied in the text (the rest class conserves both parts; m = 0 only a⁶ρ_c; no “only”), merged with AUD-B-3; docstring: script (SCR-B); the L9bB outcome line of `content/leads.json` states the checked result in the apply step; the SHIP_NOTES are the lead’s file (read-only), not a ledger matter | B · GRV-011; D4; `script_changes_B.md` |
| AUD-B-2 | S1 | EQN-019, LAB-006, their checkedBy texts, README G2-observers; docstring and log messages of `g2_forque_observers.py` | applied (the M² orders only where they were separated; for the geodesic momentarily at rest they are not); docstring and messages: script (SCR-B) | B · EQN-019, B · LAB-006; D1 G2-observers; `script_changes_B.md` |
| AUD-B-3 | S2 | GRV-011 piece 2b | applied (one generic data set with κ = 1, m = 7/4, a = 1, H = 1/2, plus a spinor at rest and one with m = 0; “on that data set”), merged with AUD-B-1 | B · GRV-011; C2 |
| AUD-B-4 | S2 | INP-050 | applied (the series fixes 3/16 at κ = 1; the power of κ from the contact term at κ = 4, 1, 9/5; e2s4_hehl_datta.py appended to checkedBy) | B · INP-050 |
| AUD-B-5 | S2 | GRV-011 place 1, second sentence | applied (k = 0, c = 0; the exponent and V₀ named; the two parameter sets) | B · GRV-011 |
| AUD-B-6 | S3 | GRV-011, the kept “One system is solved end to end:” | applied (“The Einstein–scalar system is solved end to end:”) | B · GRV-011 |
| AUD-B-7 | S3 | GRV-011 piece 2a; README E2S4-belinfante | applied (τ_ab − τ_ba written out; the torsion-free Dirac shell) | B · GRV-011; D1 E2S4-belinfante |
| AUD-B-8 | S3 | LNS-032 | applied (the audit’s sentence) | B · LNS-032 |
| AUD-B-9 | S3 | PAG-024 | applied (the audit’s parenthesis) | B · PAG-024 |
| AUD-B-10 | S3 | INP-049 | applied (the audit’s sentence) | B · INP-049 |
| AUD-B-11 | S3 | LAB-006 | applied; merged with AUD-B-12: “n radial” stands at the first use of n, and “now with” reads “with” | B · LAB-006; C · 7 |
| AUD-B-12 | S3 | LAB-006 kept text; EQN-019 naming | applied in both; in EQN-019 “n the radial unit vector” is added, since n is the dimension elsewhere in that row | B · EQN-019, B · LAB-006; C · 6 |
| AUD-B-13 | S3 | GRV-003, the optional pointer | declined with the pointer: GRV-003 stays as it is; the coefficient 3κ/8 of the Hehl–Datta equation is stated and checked in CPL-008 and GRV-011; the finding concerns only the pointer’s wording | B · GRV-003 |
| AUD-B-14 | S3 | RIG-002, L10b’s clause | applied (the three random bodies; “respectively”); the same scope in RIG-002’s checkedBy text (“for every radial observer run”) | B · RIG-002; C · 9 |
| AUD-B-15(a) | S4 | GRV-011 piece 2a, CPL-008 (“strong”) | applied (“3 random polynomial frames and spinors”) | B · GRV-011, B · CPL-008 |
| AUD-B-15(b) | S4 | GRV-011 piece 2a (“changes D̸”) | applied (“changes the Dirac operator”) | B · GRV-011 |
| AUD-B-15(c) | S4 | GRV-011 place 1 | applied (“residuals through t⁸”); the optional rename of V₀ declined: each V₀ is defined where it appears and the logs call both V0 | B · GRV-011 |
| AUD-B-15(d) | S4 | GRV-011 piece 2b, the DOP853 sentence | applied in part (the series cut one order below the solved one, at t = 0.01 to 0.08); declined “(relative remainder below 0.25)”: at t = 0.01 the ratio is 20.9 for a (a deviation at the level of rounding), and the check states the bound at t = 0.02 and 0.04 for χ and the bilinears and at 0.04 and 0.08 for a | B · GRV-011; C · 8 |
| AUD-B-15(e) | S4 | CPL-008 | applied (“the same term (3κ/8)Is, cubic in ψ”; K* defined); the definition of K* is also used in GRV-011 | B · CPL-008, B · GRV-011 |
| AUD-B-15(f) | S4 | EQN-019 checkedBy | applied through AUD-B-2’s checkedBy text (“for the radial ones”) | B · EQN-019 |
| AUD-B-15(g) | S4 | GRV-007 checkedBy | applied (`b3c4_dirac_frw.py` not appended to GRV-007; README B3C4-dirac without GRV-007) | B · GRV-007; D1 B3C4-dirac; C · 10 |
| AUD-B-15(h) | S4 | shipped log labels of `e2s4_belinfante.py` | script (SCR-B) | `script_changes_B.md` |
| AUD-B-15(i) | S4 | GRV-011, optional | declined: the two dust + stiff statements are consistent as written (t = 0 of three frames; every order of the solved series), and the suggested words would put a time word into a page sentence | — |
| AUD-C-1 | S2 | PRJ-005 (energy through t⁵) | applied by wording, as decided (the script is not changed) | B · PRJ-005 |
| AUD-C-2 | S2 | PRJ-004 | applied (“we checked it as exact series through t⁶ on a few bodies”; “re-derived” for the free top only) | B · PRJ-004 |
| AUD-C-3 | S3 | PRJ-005; the g1_forced_top checkedBy text; README G1-forced; `g1_forced_top.py` docstring | applied (linear stability defined: every l² real and ≤ 0, one zero); docstring and message: script (SCR-B) | B · PRJ-005 and every G1 checkedBy entry; D1 G1-forced; `script_changes_B.md` |
| AUD-C-4 | S3 | PRJ-005 | applied (the second anchor balances too, unstably) | B · PRJ-005 |
| AUD-C-5 | S3 | PRJ-005 | applied (every law and body run; bodies of 2 to 4 points, the wrong power included) | B · PRJ-005 |
| AUD-C-6 | S3 | PRJ-005, the block against the kept opening | applied on the block’s side, merged with AUD-C-7 (“Step 14’s force lines …”) | B · PRJ-005 |
| AUD-C-7 | S3 | PRJ-005, S³ of signed points | applied (the audit’s combined first sentence) | B · PRJ-005 |
| AUD-C-8 | S3 | FRQ-005 tag input | applied (v15 tags [checked,open,input]; input tally 179 → 182 with C-9; in V2 the tags stay read-only, D4) | B · FRQ-005; A |
| AUD-C-9 | S3 | RIG-003 | applied (the audit’s clause, with “, an input”; tags [ours,checked,input]) | B · RIG-003 |
| AUD-C-10 | S3 | RIG-002, L14’s sentence | applied as decided: not added, with its two G1 checkedBy texts, its standardRef extension, RIG-002 in the Atlas-rows cells of G1-force and G1-forced and in the summary | B · RIG-002; D1; A |
| AUD-C-11 | S4 | PRJ-005, RIG-002 (“one per κ”) | applied in PRJ-005 (“per κ_G”); RIG-002 does not take the sentence | B · PRJ-005 |
| AUD-C-12 | S4 | PRJ-005, the symbols k and d_s | applied (the audit’s two texts) | B · PRJ-005 |
| AUD-C-13 | S4 | PRJ-005 standardRef | applied (one Gunn entry, with §9.7) | B · PRJ-005 |
| AUD-C-14 | S4 | D3, G1-force and G1-forced | applied, merged with AUD-D-3 | D3 |
| AUD-C-15 | S4 | `leads3/L14/RESULT.md` | not a ledger matter: the lead’s file, which does not ship (read-only here) | — |
| AUD-D-1 | S2 | D2, D3, D4: `b3c4_curved_points.py` and M4 | script (SCR-A: the 14th one-line patch, new log, `--only M4` and the mutation table); ledger: the 14th row of D2, the script in D3’s list, the placement note of D3 and D4 | `script_changes_A.md`; D2, D3, D4 |
| AUD-D-2 | S3 | README BLIND-SPOTS; D3 paragraph 2 | applied (blind spots, not silent cells; the frames and points named); the script’s own wording: script (SCR-A) | D1 BLIND-SPOTS; D3; `script_changes_A.md` |
| AUD-D-3 | S3 | D3, the sentence on G1, G3, G4, H2, H6, L2 | applied, merged with AUD-C-14 | D3 |
| AUD-D-4 | S3 | INP-045 | applied (the audit’s parenthesis: the 42 maps as run, the 54 strong maps, n = 5 without a bound) | B · INP-045 |
| AUD-D-5 | S3 | ATL-018 | applied (the audit’s clause) | B · ATL-018 (ATL-018b) |
| AUD-D-6 | S3 | INP-044 | applied (the degree stated) | B · INP-044 |
| AUD-D-7 | S3 | INP-044 | applied (the dimension bounded) | B · INP-044 |
| AUD-D-8 | S3 | README A5-strong | applied (nine types named as run) | D1 A5-strong |
| AUD-D-9 | S3 | D4, MANIFEST | applied (the files that change listed; regenerated at the merge) | D4 |
| AUD-D-10 | S3 | D4, documents that quote counts | applied as it reads in V2 (V2 has no copy of the package’s README line 78 or BUILDING line 91; the wall-time sentence and the import counts named) | D4 |
| AUD-D-11 | S3 | D1 totals, “about 40 minutes” | applied (the sentence takes the total of the shipped run) | D1 (totals) |
| AUD-D-12 | S4 | INP-044, (18/997)³ | applied ((18/(1001 − 4))³) | B · INP-044 |
| AUD-D-13 | S4 | README A6-strong | applied (“for Holst = 0 at T = 0 (R = 500)”) | D1 A6-strong |
| AUD-D-14 | S4 | D3 paragraph 1 | applied (the two scripts whose call stands before their loop) | D3 |
| AUD-D-15 | S4 | section A descriptions | applied (INP-044, ATL-018) | A |
| AUD-D-16 | S4 | INP-045, INP-055 standardRef | applied (“set”: the field is empty today) | B · INP-045, B · INP-055 |
| AUD-D-17 | S4 | `a5_strong_maps.py` docstring; `leads3/S6/RESULT.md` | script (SCR-A: the rotor degree count); RESULT.md: not a ledger matter (the lead’s file, read-only) | `script_changes_A.md` |

Counts by severity (61 findings): S1 4 (A-1, A-2, B-1, B-2), S2 8 (A-3, A-4, B-3, B-4, B-5, C-1, C-2, D-1), S3 30, S4 19. Decisions over the 69 lines of this table (AUD-B-15 in its nine parts): applied 60 (B-1, B-2, C-3 and D-2 with a script part too), script 5 (A-1, A-12, B-15(h), D-1, D-17; the sentence or cell that depends on each is adjusted), declined 3 (A-14, B-13, B-15(i)), not a ledger matter 1 (C-15). Declined inside an applied line: the optional parts of A-5 (the exact closed form) and B-15(c) (the rename of V₀), and B-15(d)’s ratio.
