# Ledger of batch 3, final: the sentences, checkedBy and standardRef texts of 31 rows, and the texts of the gravity check folder

**Against the draft** (`deliver_batch3/work/LEDGER_BATCH3_draft.md`): (1) every finding of the four audits, AUD-A-1 to AUD-D-17, is decided, one line each in `AUDIT_DISPOSITION.md`; every S1 and S2 is fixed, in the sentence or, where the script was at fault, by SCR-A or SCR-B with the sentence and the README cell adjusted to their runs.
(2) Three statements now say only what the checks show (the higher orders for every observer, the separate conservation in the Einstein–Dirac series, the W·*W check line), and the limits the draft lost are back (one data set at κ = 1, k = 0 and c = 0 for the exponential potential, the energy through t⁵, the Christoffel comparison at three Kerr points, the Cotton part as a 1-jet, the strong frames of A5).
(3) RIG-002 does not take L14’s hung-body sentence (it is said once, in RIG-003), GRV-007 does not take `b3c4_dirac_frw.py`, GRV-003’s optional pointer is not added, D2 has 14 patches (`b3c4_curved_points.py` is the 14th), and every entry names the V2 row (`content/rows.json`) it changes.

Nothing in the v15 package is changed by this file. Every sentence is English and is the same text in both slots (`V11_ENGLISH_IN_ITALIAN = true`); no Italian text is written. The texts are at the scope the check lines show; “derived” is used only where the package derives (the exponential potential’s exponent and V₀, solved from the equations by the script), “re-derived” only where v15 already says it; attributions to papers nobody here has read stay “recalled” or “pointer, source unread”. The apply step of `B3_ADDENDUM.md` §3 writes these texts into the V2 tables of this copy (section D4).

## A. Summary table

| row | V2 row | family | change | scripts added to checkedBy | from |
|---|---|---|---|---|---|
| ATL-014 | ATL-014c | ATL Atlas cells | checkedBy only | h5l_bianchi_kerr | H5LK |
| ATL-018 | ATL-018b | ATL Atlas cells | one clause: failure bounds; the controls also on these frames | a5_strong_maps | S6 |
| CPL-008 | CPL-008 | CPL Step 6 coupling | one insertion: the Dirac equation from the action with the torsion eliminated | e2s4_hehl_datta | L9bA |
| CPL-011 | CPL-011 | CPL Step 6 coupling | checkedBy only | a6_strong | S6 |
| EQN-019 | EQN-019 | EQN Equations: step 2 and tally | clause extended: the factor belongs to the observer; the higher orders where separated | g2_forque_observers | L10b |
| EQN-020 | EQN-020 | EQN Equations: step 2 and tally | tally appended: Kerr–Newman and extremal horizons | f3_kn_horizons, f4_komar_kn | L5c |
| FRQ-005 | FRQ-005 | FRQ Step 14 forque | last sentence: the forced top; tag input | g1_force_line, g1_forced_top | L14 |
| GRV-003 | GRV-003 | GRV Steps 9–10 gravity | unchanged (optional pointer not added) | none | L9bA |
| GRV-004 | GRV-004c | GRV Steps 9–10 gravity | two places: Kerr and Kerr–Newman frame 4-jets | h5l_bianchi_kerr | H5LK |
| GRV-007 | GRV-007 | GRV Steps 9–10 gravity | checkedBy only | b3c4_curved_points | L9bB |
| GRV-010 | GRV-010 | GRV Steps 9–10 gravity | parenthesis: failure bound | a6_strong | S6 |
| GRV-011 | GRV-011 | GRV Steps 9–10 gravity | one word of the kept text, three places, the tail, standardRef (merged) | e2s4_belinfante, e2s4_hehl_datta, b3c4_curved_points, b3c4_dirac_frw | L9bA + L9bB |
| INP-044 | INP-044 | INP Needs and inputs | three parentheses: failure bounds and the rank bound | a6_strong | S6 |
| INP-045 | INP-045 | INP Needs and inputs | the parenthesis: the 42 maps as run, bounds for every map type | a5_strong_maps | S6 |
| INP-048 | INP-048 | INP Needs and inputs | one parenthesis: failure bound | a6_strong | S6 |
| INP-049 | INP-049 | INP Needs and inputs | one sentence appended: the constant c | b3c4_curved_points, b3c4_dirac_frw | L9bB |
| INP-050 | INP-050 | INP Needs and inputs | one sentence appended: κ in the Einstein–Dirac series | b3c4_curved_points, b3c4_dirac_frw, e2s4_hehl_datta | L9bB |
| INP-055 | INP-055 | INP Needs and inputs | one clause: failure bound | a5_strong_maps | S6 |
| INP-058 | INP-058 | INP Needs and inputs | two insertions, one sentence adapted (merged) | f3_kn_horizons, h5l_bianchi_kerr | L5c + H5LK |
| INP-075 | INP-075 | INP Needs and inputs | unchanged | none | L10b |
| LAB-006 | LAB-006 | LAB Clock, gauge and groups strips | clause extended | g2_forque_observers | L10b |
| LAB-008 | LAB-008 | LAB Clock, gauge and groups strips | one phrase: 43 horizons, 129 rows | f4_komar_kn | L5c |
| LNS-032 | LNS-032 | LNS Schuller (step 20) | one insertion: the Belinfante term | e2s4_belinfante | L9bA |
| MAP-023 | MAP-023 | MAP Map nodes | last sentence: the forced top (merged) | h5l_bianchi_kerr, g1_force_line, g1_forced_top | L14 + H5LK |
| NUL-001 | NUL-001d | NUL Step 13 null surfaces | five edits in line 4 | f3_kn_horizons, f4_komar_kn | L5c |
| NUL-003 | NUL-003 | NUL Step 13 null surfaces | one passage appended to line 1 | f3_kn_horizons | L5c |
| PAG-024 | PAG-024 | PAG Page claim strips | parenthesis replaced | b3c4_curved_points, b3c4_dirac_frw | L9bB |
| PRJ-004 | PRJ-004 | PRJ Step 11 projective | one sentence: checked, not re-derived, for the forced top | g1_force_line, g1_forced_top | L14 |
| PRJ-005 | PRJ-005 | PRJ Step 11 projective | one sentence replaced by a block; tag input | g1_force_line, g1_forced_top | L14 |
| RIG-002 | RIG-002 | RIG Step 16 rigid body | one clause (L10b); L14’s sentence not added | g2_forque_observers | L10b (+ L14, not added) |
| RIG-003 | RIG-003 | RIG Step 16 rigid body | one clause; tags checked and input | g1_force_line, g1_forced_top | L14 |

Counts: 31 rows. Sentence changes: 26, on 26 V2 rows. checkedBy only: 3 (ATL-014, CPL-011, GRV-007). Unchanged: 2 (GRV-003, INP-075). Merged from two leads: 4 (GRV-011, INP-058, MAP-023, RIG-002). Tags changed: 3 (FRQ-005 and PRJ-005 gain input; RIG-003 gains checked and input). Scripts named in the checkedBy entries: 12 of the 14 (`d_probe.py` and `blind_spot_probes.py` back no row), on 29 rows.

Effect on the tallies of the v15 claims table when the sentences and tags are applied: lines tagged *checked* 631 → 632 (RIG-003), lines tagged *input* 179 → 182 (FRQ-005, PRJ-005, RIG-003); the generator (`make_claims_data.mjs`) recomputes every other count. In V2 the tags are `legacyFlags`, kept read-only (`docs/02_CONTENT_MODEL.md` §1), and the status is computed (D4).

## B. The rows, one patch each (alphabetical)

Each block: the v15 row id, its family, the change, the lead, **the V2 row** (`content/rows.json` id) whose research text changes; then *Today* (verbatim in today’s text) and *Should read* (the text to paste, English in both slots), the checkedBy entries appended, the standardRef change, the tags, and the audit findings applied in the block (the disposition of every finding is `AUDIT_DISPOSITION.md`).

### ATL-014 · ATL Atlas cells · checkedBy only · from H5LK · V2 row ATL-014c
No sentence changes. The line “The Bianchi identity D_A F = 0 of that so(2,4) Cartan curvature holds equally for the so(1,5) and so(3,3) tables …” (V2 row ATL-014c) is an identity of the table; the Kerr and Kerr–Newman frames add a consistency line to that chain and a statement about the jets (GRV-004, INP-058), not a different claim here. AUD-A: OK.

- **checkedBy, append:** `h5l_bianchi_kerr.py (D_A F = 0 of the so(2,4) table on Kerr and Kerr–Newman frame 4-jets)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** ATL-014c: `H5L-B-Kerr` (moved from ATL-014, where V2 recorded it on the base row)

### ATL-018 · ATL Atlas cells · one clause: failure bounds; the controls also on these frames · from S6 (a5_strong_maps) · V2 row ATL-018b
*Today* (V2 row ATL-018b; the second line, the [checked] line (part)):
> Today: “… rotating e without ω, a Euclidean rotation, the law without det(L) and L cut to its 1-jet all fail. …”
*Should read:*
> … at n = 3, 4, on three frames per n, with every sampled coefficient of the frame and of the maps uniform on 10001 values, a false law would pass all three with probability at most 1.1e-5 for the Cayley transforms and 2.5e-4 for the rotor products (P, T, PT times the Cayley transform and the rotor with UŨ > 0 included); rotating e without ω, a Euclidean rotation, the law without det(L) and L cut to its 1-jet all fail, also on these frames. …

- **checkedBy, append:** `a5_strong_maps.py (every map type on strong random frames, failure bound per type and n)`
- **standardRef, extend** (ATL-018, ATL-018b, ATL-018c, ATL-018d): `; Schwartz, Fast probabilistic algorithms for verification of polynomial identities; Zippel, Probabilistic algorithms for sparse polynomials (the failure bound; recalled)`
- **tags:** unchanged
- **evidence (V2):** ATL-018b: `a5_strong_maps`
- **audit:** AUD-D-5 (the property attached to the frames and the maps; “pass all three”; P, T, PT named), AUD-D-15 (the summary line).

### CPL-008 · CPL Step 6 coupling · one insertion: the Dirac equation from the action with the torsion eliminated · from L9bA (e2s4_hehl_datta) · V2 row CPL-008
*Today* (V2 row CPL-008; after “… a |T|² shift (exact at the origin of 4 random polynomial frames, n = 4).” insert):
> Today: “… a |T|² shift (exact at the origin of 4 random polynomial frames, n = 4). …”
*Should read:*
> … a |T|² shift (exact at the origin of 4 random polynomial frames, n = 4). The Dirac equation from the action with the torsion eliminated carries the same term (3κ/8)Is, cubic in ψ: the Euler–Lagrange form on ω_LC + K* (K* the contorsion of that axial torsion) is that of L_D(ω_LC) + (3κ/16)(s·s)vol, with 3κ/8 = twice the contact coefficient in operator form, and a trace torsion drops out of it (exact at the origin of 3 random polynomial frames and spinors, with a numpy variation of the textbook action). …

- **checkedBy, append:** `e2s4_hehl_datta.py (the Hehl-Datta equation in closed form: EL(omega*) = EL(omega_LC) + (3 kappa/16) d(s.s vol)/dpsi, operator form with 3 kappa/8; a trace contorsion drops out)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** CPL-008: `e2s4_hehl_datta`
- **audit:** AUD-B-15(a) (“3 random polynomial frames and spinors”: these fields carry no failure bound), AUD-B-15(e) (the term named, K* defined).

### CPL-011 · CPL Step 6 coupling · checkedBy only · from S6 · V2 row CPL-011
No wording change; a6_strong.py is appended next to a6_topological.py (AUD-D: supported; its part 7 checks the MacDowell–Mansouri / Einstein–Cartan difference by d of the Euler Chern–Simons form that the row states).

- **checkedBy, append:** `a6_strong.py (the topological companions on strong random fields, failure bound)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** CPL-011: `a6_strong`

### EQN-019 · EQN Equations: step 2 and tally · clause extended: the factor belongs to the observer · from L10b (g2_forque_observers) · V2 row EQN-019
*Today* (V2 row EQN-019; the clause (the rest of the line unchanged)):
> Today: “… the second carries terms of order M² and M³, the third of order M² to M⁴; …”
*Should read:*
> … the second carries terms of order M² and M³, the third of order M² to M⁴; the factor belongs to the observer, not to the curvature: for every radial observer run (static, in free fall from rest at infinity, geodesic momentarily at rest in the Kerr–Schild frame) the tidal tensor is the same ∂_i∂_jΦ and the first covariant derivative is g(u, ∂_t) times the coordinate derivative, the observer’s energy per unit mass — √(1 − 2M/r) for the static observer, 1 − M/r for the Kerr–Schild observer (accelerated, ∇_u E₀ = (M/r²) n, n the radial unit vector) and for the radial geodesic momentarily at rest in that frame, 1 for the radial free fall from rest at infinity, whose first covariant derivative is the coordinate derivative exactly — while the second and third covariant derivatives are not Φ’s derivatives for any observer run, and where their orders in M were separated (Kerr–Schild, static, free fall) they carry terms of order M² and higher (M² only for that free fall), and a transverse boost changes the tidal tensor itself (exact, 2M/r = 9/25 at two points, through ε⁴, with controls); …

- **checkedBy, append:** `g2_forque_observers.py (the covariant derivatives of the tidal tensor for five observers: for the radial ones the first-order factor is the observer's energy, the free fall from rest at infinity has factor 1; the higher orders keep M^2 terms for the Kerr-Schild, static and free-falling observers; the transverse boost changes the tidal tensor)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** EQN-019: `G2-observers`
- **audit:** AUD-B-2 (S1: the M² orders only where they were separated), AUD-B-12 (the accelerated Kerr–Schild field named; n defined, since n is the dimension elsewhere in this row), AUD-B-15(f) (covered by AUD-B-2's checkedBy text). The optional MTW pointer of the draft is not added (nothing in the clause rests on it).

### EQN-020 · EQN Equations: step 2 and tally · tally appended: Kerr–Newman and extremal horizons · from L5c (f3_kn_horizons, f4_komar_kn) · V2 row EQN-020
*Today* (V2 row EQN-020; append at the end of the line):
> Today: “… Smarr from the integral side holds on ten horizons (69 checks in its own log) …”
*Should read:*
> … Smarr from the integral side holds on ten horizons (69 checks in its own log); F = ∇_aχ_b∇^aχ^b = −2κ_H² on the horizons of ten Kerr–Newman members with a ≠ 0 and Q ≠ 0 (three extremal), of extremal Kerr and of Kerr just off it (20 horizons; 26 with the a = 0 and Q = 0 limits), with ∇χ ≠ 0 but null off the axis on the rotating extremal horizons (121 checks in its own log); the Komar integrals and Smarr from the integral side on 16 more horizons and the first law on 14 more, extremal ones included (59 checks in its own log) …

- **checkedBy, append:** `f3_kn_horizons.py (F = −2κ_H² on Kerr–Newman and extremal horizons)`
- **checkedBy, append:** `f4_komar_kn.py (Komar integrals and Smarr on 16 more horizons; the first law at κ_H = 0)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** EQN-020: `F3-KN`, `F4-KN`
- **audit:** AUD-A-6 (∇χ is zero at the poles: “off the axis”).

### FRQ-005 · FRQ Step 14 forque · last sentence: the forced top · from L14 (g1_force_line, g1_forced_top) · V2 row FRQ-005
The sentences about the “one source on constrained dynamics … partly read (abstract and slides; the full text was not reachable)” stay as they are; they are the subject of the Hadfield–Lasenby lead.

*Today* (V2 row FRQ-005; today’s last sentence, replaced):
> Today: “… The free top in the three plane-based algebras (not conformal) is checked, with the inertia built from points in each algebra. …”
*Should read:*
> … The free top and the top forced by force lines (the force law an input) in the three plane-based algebras (not conformal) are checked, with the inertia built from points in each algebra. …

- **checkedBy, append:** `g1_force_line.py (force lines in Cl_kappa: the join weight sin d / d / sinh d, three laws as inputs, the forque = the std torque with the sign +1, the hung body at k sin d_s = m g / k d_s = m g / k sinh d_s = m g, kappa_G = +1, 0, -1)`
- **checkedBy, append:** `g1_forced_top.py (the top forced by force lines, engine = top with a fixed point in R^4 / R^{3,1} with the torque and Newton-Euler, series through t^6, kappa_G = +1, 0, -1; the hung cube: equal characteristic polynomials, hung vertex linearly stable (all l^2 <= 0, one zero), complement unstable)`
- **standardRef:** no change
- **tags:** tags [checked,open] → [checked,open,input] (v15 tags; legacyFlags in V2 stay as imported, see D4)
- **evidence (V2):** FRQ-005: `g1_force_line`, `g1_forced_top`
- **audit:** AUD-C-8 (the tag input, as on PRJ-005), AUD-C-3 (“linearly stable” in the g1_forced_top checkedBy text).

### GRV-003 · GRV Steps 9–10 gravity · unchanged (the optional pointer is not added) · from L9bA · V2 row GRV-003
No change. The draft offered an optional pointer at the end of the line; it is not added: the line’s statement stands as it is, and the link between the coefficient 3κ/8 and the Hehl–Datta equation is stated in CPL-008 and GRV-011, which carry the check. AUD-B-13 concerned the wording of that pointer only.

- **standardRef:** no change
- **tags:** unchanged

### GRV-004 · GRV Steps 9–10 gravity · two places in the third line: Kerr and Kerr–Newman frame 4-jets (merge edits; AUD-A-3) · from H5LK (h5l_bianchi_kerr) · V2 row GRV-004c
*Today* (V2 row GRV-004c; first place):
> Today: “… (n = 4, frame 3-jets; Kerr: Lorentz part only) …”
*Should read:*
> … (n = 4, frame 3-jets; Kerr and Kerr–Newman on exact frame 4-jets, where the Schouten tensor is zero as a 2-jet on Kerr and not on Kerr–Newman) …

*Today* (V2 row GRV-004c; second place):
> Today: “… both sides zero on Schwarzschild and Schwarzschild–de Sitter, nonzero on Reissner–Nordström) and D_L C = W·f (both sides zero at the Reissner–Nordström point tested, where the Weyl 2-form and the Schouten tensor are diagonal in the same static frame, and nonzero on a random frame); checked at one point per frame on frame 4-jets against a second-order Christoffel route; Kerr not done. …”
*Should read:*
> … both sides zero on Schwarzschild, Schwarzschild–de Sitter and Kerr (on Kerr the Schouten tensor vanishes as a 2-jet and the Weyl 2-form does not); nonzero on Reissner–Nordström and Kerr–Newman) and D_L C = W·f (both sides zero at the Reissner–Nordström point tested, where the Weyl 2-form and the Schouten tensor are diagonal in the same static frame, and at the two equatorial Kerr–Newman points, where the pseudoscalar invariant W·*W of the Weyl tensor vanishes; both sides nonzero at a generic and an axis Kerr–Newman point and on a random frame); checked at one point per frame on frame 4-jets against a second-order Christoffel route (Kerr: nine points of three members with the vacuum form D_L W = 0, compared with the Christoffel route’s d_∇Weyl at M = 5, a = 3 on the axis, on the equator and generic, and through its Ricci 2-jet at the other six; Kerr–Newman: (M, a, s) = (5, 1, 4) and (7/2, 2, 1) with s = κQ²/4, four points, where the vacuum form fails). …

- **checkedBy, append:** `h5l_bianchi_kerr.py (D_A F = 0, D_L W = e C - e C and D_L C = W.f on Kerr and Kerr-Newman frame 4-jets; W.f != 0 at a generic and an axis Kerr-Newman point, W.f = 0 at the two equatorial points)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** GRV-004c: `H5L-B-Kerr` (moved from GRV-004, where V2 recorded it on the base row)
- **audit:** AUD-A-3 (S2: the Christoffel comparison at three Kerr points, the Ricci 2-jet at the other six), AUD-A-2 (S1: the checkedBy text at the points run), AUD-A-1 (S1: the check line of W·*W, a script matter; the clause on W·*W is true as mathematics and stays once the script contracts W^{rs}_{pq}).

### GRV-007 · GRV Steps 9–10 gravity · checkedBy only · from L9bB · V2 row GRV-007
No wording change (the constant c of E_a(c) is the input INP-049 describes). Only b3c4_curved_points.py is appended (it refits the c column of E_a(c) − κτ_a at points off the spatial origin); b3c4_dirac_frw.py checks nothing this row states (AUD-B-15(g)) and is not appended here.

- **checkedBy, append:** `b3c4_curved_points.py (the k = +-1 series off the spatial origin with the exact conformal-factor jet; the exponential potential's power-law solution)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** GRV-007: `B3C4-curved`

### GRV-010 · GRV Steps 9–10 gravity · parenthesis: failure bound · from S6 (a6_strong) · V2 row GRV-010
*Today* (V2 row GRV-010; the theorem line (part); the first-variation sentence keeps its scope, without a bound):
> Today: “… (exact polynomial identities at n = 4 on random connections and frames, no torsion condition; local, nothing global) …”
*Should read:*
> … (exact polynomial identities at n = 4, no torsion condition, checked on three random connections and frames whose every jet coefficient is an integer uniform in [−50, 50]: each identity has degree at most 4 in these coefficients, so a false one would pass all three with probability at most (4/101)³ < 6.3e-5; local, nothing global) …

- **checkedBy, append:** `a6_strong.py (the topological companions on strong random fields, failure bound)`
- **standardRef, extend** (GRV-010, GRV-010b): `; Schwartz, Fast probabilistic algorithms for verification of polynomial identities; Zippel, Probabilistic algorithms for sparse polynomials (the failure bound; recalled)`
- **tags:** unchanged
- **evidence (V2):** GRV-010: `a6_strong`
- **audit:** AUD-D: OK.

### GRV-011 · GRV Steps 9–10 gravity · one word in the kept text, three places, the tail, standardRef (merged; AUD-B) · from L9bA + L9bB (merged) · V2 row GRV-011
*Today* (V2 row GRV-011; the kept text: one word (AUD-B-6)):
> Today: “… One system is solved end to end: …”
*Should read:*
> … The Einstein–scalar system is solved end to end: …

*Today* (V2 row GRV-011; place 1 (L9bB, Part 1): insert after “… recursion exactly.”):
> Today: “… and the coefficients equal the textbook Friedmann–Klein–Gordon recursion exactly. …”
*Should read:*
> … and the coefficients equal the textbook Friedmann–Klein–Gordon recursion exactly. For k = ±1 the same series solve the equations at rational points away from the spatial origin of the isotropic chart when the frame carries the exact Taylor jet of the conformal factor 1/(1 + kr²/4) (two points per k, one with kr² of order one, series to order 10, residuals through t⁸; the truncated polynomial 1 − kr²/4 fails there, and the frame of the other k fails). An exponential potential V = V₀e^{−λφ} reproduces its power-law solution a = t^{2κ/λ²}, φ = (2/λ) ln t about t = 1 (k = 0, c = 0; the exponent and V₀ = (12κ/λ² − 2)/λ² derived from the equations; exact series to order 10 at (κ, λ) = (1, 1) and (2, 3); a wrong exponent and a wrong sign of the potential fail). …

*Today* (V2 row GRV-011; place 2: the last sentence (“Not built: …”) replaced by pieces 2a (L9bA), 2b (L9bB, Part 2) and 2c (the merged tail)):
> Today: “… Not built: the size of κ and the sign of the source (inputs fixed by attraction), the Belinfante term as a separate object, the Hehl–Datta equation from the effective action, any solution of the coupled equations. …”
*Should read:*
> … The Belinfante term is built as a separate object. With the torsion-free connection written as a function of the frame, the frame variation of L_D(e, ω_LC(e), ψ) is the Hilbert stress τ^LC_a = τ_a + B_a, where B_a is the variation of ω_LC paired with the spin form and reduces to the closed form B_ab = −½(D S)_ab (D S_ab = ∇_cσ^c_ab vol, the covariant divergence of the spin density on the torsion-free connection; the coefficient is fixed by an exact fit and the ε-dual is absent). B_ab is antisymmetric, so the Hilbert stress has the symmetric part of the canonical one; its antisymmetric part, (τ^LC_ab − τ^LC_ba) vol = ½(γ_aγ_bψ)·EL_ψ, is zero on the torsion-free Dirac shell, where the canonical stress keeps τ_ab − τ_ba = (D S)_ab (Rosenfeld). The Hehl–Datta equation in closed form: with ω* = ω_LC + K* (K* the contorsion of that axial torsion) held fixed, the Dirac Euler–Lagrange form off shell is EL(ω*) = EL(ω_LC) + (3κ/16) ∂(s·s vol)/∂ψ, the stationarity of L_D(ω_LC) + (3κ/16)(s·s)vol, and in operator form (D̸ψ)Jγ₀ − mψ + (3κ/8)(Isψ)Jγ₀: the cubic coefficient is twice the contact coefficient, and it is the ψ-derivative of the contact term of the effective action. A trace contorsion drops out of the Euler–Lagrange form (K^A∧S_A = 0) although it changes the Dirac operator. Exact at the origin of 3 random polynomial frames and spinors (first-order jets; the Hehl–Datta difference also as a jet statement), with numpy cross-checks by numerical variation of the textbook density (the Hilbert stress with the Christoffel spin connection recomputed from the frame and its derivatives; the Euler–Lagrange form with the contorsion from the bilinears): T_H = T_can + ½∇^cσ_cab (the coefficient ½ to 1e-6) and (iΓ^a∇_a − m)χ + (3κ/8)A_dΓ^dγ5χ (3/8 to 1e-8). Controls: the opposite sign of B, the canonical stress in place of the Hilbert one on shell, a spinor off shell, a torsionful connection in the closed form; the closed form without the cubic term, with the opposite sign, with the contact coefficient doubled, a trace torsion in place of the axial one. The coupled Einstein–Dirac system of the torsionful shell is solved as an exact power series in t in the FRW frame (k = 0, homogeneous spinor; one generic data set with κ = 1, m = 7/4, a = 1 and H = 1/2 at t = 0, plus one spinor at rest and one with m = 0; a to order 9, ψ to order 8, residuals through t⁷): the Friedmann constraint, imposed at t = 0 only, holds at every order computed (not with the contorsion of the wrong sign, not with the free Dirac equation on the torsionful frame), and the Einstein form of the torsion-free connection reads ρ = m⟨ψψ̃⟩ + ρ_c, p = ρ_c with ρ_c = (3κ/16)|ψψ̃|² at every order, with one continuity equation for the total. For a spinor at rest (ψ(0) commuting with γ₀, which the series preserves: P = s⁰ = 0 at every order, with P the pseudoscalar part of ψψ̃ and s⁰ the time component of the axial current) the two parts are conserved separately, a³⟨ψψ̃⟩ and a⁶ρ_c constant; for m = 0 the source is the stiff part alone and a⁶ρ_c is constant, while a³⟨ψψ̃⟩ is not; for the generic homogeneous spinor run the mass term exchanges energy between them, d(a³⟨ψψ̃⟩)/dt = −(3κ/4)a³Ps⁰ and d(a⁶ρ_c)/dt = (3κ/4)m a⁶Ps⁰ (exact through t⁶ on that data set), and only the total is conserved. Numpy cross-check: Dirac matrices, the Christoffel spin connection and the Hehl–Datta equation (the form checked above against the action) integrated with DOP853 agree with the series, cut one order below the solved one, at t = 0.01 to 0.08 up to its first dropped term. Not built: the size of κ and the sign of the source (inputs fixed by attraction), solutions beyond this class (k ≠ 0, non-homogeneous spinors, late times). …

- **checkedBy, append:** `e2s4_belinfante.py (the Belinfante term: Hilbert stress = canonical stress - (1/2) D S, symmetric on the Dirac shell; Rosenfeld)`
- **checkedBy, append:** `e2s4_hehl_datta.py (the Hehl-Datta equation in closed form: EL(omega*) = EL(omega_LC) + (3 kappa/16) d(s.s vol)/dpsi, operator form with 3 kappa/8; a trace contorsion drops out)`
- **checkedBy, append:** `b3c4_curved_points.py (the k = +-1 series off the spatial origin with the exact conformal-factor jet; the exponential potential's power-law solution)`
- **checkedBy, append:** `b3c4_dirac_frw.py (the Einstein-Dirac FRW series of the torsionful shell, k = 0, homogeneous spinor: constraint propagated, dust + stiff contact fluid, the exchange through the mass term; DOP853 cross-check)`
- **standardRef, replace** “Hehl and Datta, J. Math. Phys. 12 (1971) 1334 (the contact coefficient 3κ/16; the form of their Dirac operator, recalled)” by `Hehl and Datta, J. Math. Phys. 12 (1971) 1334 (the contact coefficient 3κ/16 and the cubic term 3κ/8 of their Dirac equation, recalled)` and append `; Belinfante 1940, Rosenfeld 1940 (the symmetrised stress as the canonical one plus half the divergence of the spin): pointers, sources unread`
- **tags:** unchanged
- **evidence (V2):** GRV-011: `e2s4_belinfante`, `e2s4_hehl_datta`, `B3C4-curved`, `b3c4_dirac_frw`
- **audit:** AUD-B-1 (S1: the separate conservation laws, the rest class and m = 0 apart), AUD-B-3 (S2: one data set, κ = 1, the rest and massless sets), AUD-B-5 (S2: k = 0, c = 0, the two parameter sets, the exponent named), AUD-B-6 (“The Einstein–scalar system”), AUD-B-7 (the factor 2: τ_ab − τ_ba, the torsion-free shell), AUD-B-15(a) (no “strong”), (b) (“the Dirac operator”), (c) (“residuals through t⁸”), (d) (the cut series and the times; see the disposition for the part not taken).

### INP-044 · INP Needs and inputs · three parentheses: failure bounds and the rank bound · from S6 (a6_strong) · V2 row INP-044
*Today* (V2 row INP-044; first parenthesis):
> Today: “… its topological companions (exact, n = 4, local): …”
*Should read:*
> … its topological companions (exact, n = 4, local; on three random fields per identity whose every jet coefficient is an integer uniform in [−50, 50]; each identity has degree at most 4 in these coefficients, so a false one would pass all three with probability at most (4/101)³ < 6.3e-5): …

*Today* (V2 row INP-044; second parenthesis):
> Today: “… they are the only two exact k(R, R) of this kind on so(1,3); …”
*Should read:*
> … they are the only two exact k(R, R) of this kind on so(1,3) (on one field the dimension of that space is at most 2, with certainty; the two Chern–Simons identities, with the bound above, make it at least 2); …

*Today* (V2 row INP-044; third parenthesis):
> Today: “… vanishes at T = 0 and not with torsion. …”
*Should read:*
> … vanishes at T = 0 (at the origin of three random frames with integer coefficients uniform in [−500, 500]: false-pass probability at most (18/(1001 − 4))³ < 5.9e-6) and not with torsion. …

- **checkedBy, append:** `a6_strong.py (the topological companions on strong random fields, failure bound)`
- **standardRef, extend** (INP-044): `; Schwartz, Fast probabilistic algorithms for verification of polynomial identities; Zippel, Probabilistic algorithms for sparse polynomials (the failure bound; recalled)`
- **tags:** unchanged
- **evidence (V2):** INP-044: `a6_strong`
- **audit:** AUD-D-6 (the degree stated), AUD-D-7 (the dimension is bounded), AUD-D-12 (1001 − 4), AUD-D-15 (the summary line).

### INP-045 · INP Needs and inputs · the parenthesis: the 42 maps and the bounds for every map type · from S6 (a5_strong_maps) · V2 row INP-045
*Today* (V2 row INP-045; the parenthesis at the end of the line):
> Today: “… (checked exactly at the origin of random polynomial frames, 2-jets, n = 3, 4, 5, 42 maps: Cayley transforms, rotor products and P, T, PT times them; for the Cayley maps a false law would pass three strong frames with probability at most 1.8e-3 at n = 3 and 1.2e-2 at n = 4). …”
*Should read:*
> … (checked exactly at the origin of random polynomial frames, 2-jets, n = 3, 4, 5, 42 maps: Cayley transforms, rotor products with UŨ of either sign, and P, T, PT times the Cayley transforms; at n = 3, 4 also on three strong frames per n with nine map types on each (54 maps; P, T, PT also times the rotor with UŨ > 0), every sampled coefficient uniform on 10001 values (integers in [−5000, 5000], except the constant term of a boost parameter): a false law would pass all three with probability at most 1.8e-6 (n = 3) and 1.1e-5 (n = 4) for the Cayley transforms and P, T, PT times them, and 1.2e-5 (n = 3) and 2.5e-4 (n = 4) for the rotor products (UŨ > 0 and UŨ < 0) and P, T, PT times the first; n = 5, one frame, carries no bound). …

- **checkedBy, append:** `a5_strong_maps.py (every map type on strong random frames, failure bound per type and n)`
- **standardRef, set** (INP-045; empty today): `Schwartz, Fast probabilistic algorithms for verification of polynomial identities; Zippel, Probabilistic algorithms for sparse polynomials (the failure bound; recalled)`
- **tags:** unchanged
- **evidence (V2):** INP-045: `a5_strong_maps`
- **audit:** AUD-D-4 (the 42 maps of a5_lorentz_covariance.py described as they ran; the 54 strong maps; n = 5 without a bound), AUD-D-16 (standardRef set, the field is empty today).

### INP-048 · INP Needs and inputs · one parenthesis: failure bound · from S6 (a6_strong) · V2 row INP-048
*Today* (V2 row INP-048; one parenthesis):
> Today: “… torsion allowed (n = 4, exact, local). …”
*Should read:*
> … torsion allowed (n = 4, exact, local; on three random fields whose every jet coefficient is an integer uniform in [−50, 50], false-pass probability at most (4/101)³ < 6.3e-5). …

- **checkedBy, append:** `a6_strong.py (the topological companions on strong random fields, failure bound)`
- **standardRef, extend** (INP-048): `; Schwartz, Fast probabilistic algorithms for verification of polynomial identities; Zippel, Probabilistic algorithms for sparse polynomials (the failure bound; recalled)`
- **tags:** unchanged
- **evidence (V2):** INP-048: `a6_strong`
- **audit:** AUD-D: OK.

### INP-049 · INP Needs and inputs · one sentence appended: the constant c · from L9bB (b3c4_curved_points, b3c4_dirac_frw) · V2 row INP-049
*Today* (V2 row INP-049; append at the end of the line):
> Today: “… while r = sign H² in both. …”
*Should read:*
> … while r = sign H² in both. In the solved Einstein–scalar and Einstein–Dirac series c is not derived: it is chosen, or fixed by the 00 equation at t = 0 for the chosen H₀ and matter data (in the k = 0 quartic family that equation fixes V₀ instead, which enters with c only through c + κV₀/3). …

- **checkedBy, append:** `b3c4_curved_points.py (the k = +-1 series off the spatial origin with the exact conformal-factor jet; the exponential potential's power-law solution)`
- **checkedBy, append:** `b3c4_dirac_frw.py (the Einstein-Dirac FRW series of the torsionful shell, k = 0, homogeneous spinor: constraint propagated, dust + stiff contact fluid, the exchange through the mass term; DOP853 cross-check)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** INP-049: `B3C4-curved`, `b3c4_dirac_frw`
- **audit:** AUD-B-10 (c chosen, or fixed by the 00 equation; V₀ in the k = 0 quartic family).

### INP-050 · INP Needs and inputs · one sentence appended: κ in the Einstein–Dirac series · from L9bB (b3c4_curved_points, b3c4_dirac_frw) · V2 row INP-050
*Today* (V2 row INP-050; after “… a source with κ/2 fails the constraint at order t⁰.” append):
> Today: “… a source with κ/2 fails the constraint at order t⁰. …”
*Should read:*
> … a source with κ/2 fails the constraint at order t⁰. The same κ enters the Einstein–Dirac series through the contact term (3κ/16)|ψψ̃|² and through the coupling of E_a to τ_a; the series runs at κ = 1, so it fixes the coefficient 3/16 (the contact coefficient 3/8 in its place fails), and the power of κ is fixed at κ = 4, 1, 9/5 by the contact term of the action with the torsion eliminated. …

- **checkedBy, append:** `b3c4_curved_points.py (the k = +-1 series off the spatial origin with the exact conformal-factor jet; the exponential potential's power-law solution)`
- **checkedBy, append:** `b3c4_dirac_frw.py (the Einstein-Dirac FRW series of the torsionful shell, k = 0, homogeneous spinor: constraint propagated, dust + stiff contact fluid, the exchange through the mass term; DOP853 cross-check)`
- **checkedBy, append:** `e2s4_hehl_datta.py (the contact term -(3/16) kappa^2 (s.s) vol at three values of kappa)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** INP-050: `B3C4-curved`, `b3c4_dirac_frw`, `e2s4_hehl_datta`
- **audit:** AUD-B-4 (S2: at κ = 1 the series cannot tell κ from κ²; the power of κ from e2s4_hehl_datta at κ = 4, 1, 9/5).

### INP-055 · INP Needs and inputs · one clause: failure bound · from S6 (a5_strong_maps) · V2 row INP-055
*Today* (V2 row INP-055; one clause in the last parenthesis):
> Today: “… random polynomial frames, n = 3, 4, 5; the step …”
*Should read:*
> … random polynomial frames, n = 3, 4, 5; on three strong frames per n = 3, 4 and for every map type, a false law would pass with probability at most 2.5e-4; the step …

- **checkedBy, append:** `a5_strong_maps.py (every map type on strong random frames, failure bound per type and n)`
- **standardRef, set** (INP-055; empty today): `Schwartz, Fast probabilistic algorithms for verification of polynomial identities; Zippel, Probabilistic algorithms for sparse polynomials (the failure bound; recalled)`
- **tags:** unchanged
- **evidence (V2):** INP-055: `a5_strong_maps`
- **audit:** AUD-D-16 (standardRef set).

### INP-058 · INP Needs and inputs · two insertions, one sentence adapted (merged; AUD-A-4) · from H5LK + L5c (merged) · V2 row INP-058
*Today* (V2 row INP-058; after “… that fail.” the two clauses (H5LK, then L5c) and the sentence that follows, adapted):
> Today: “… that fail. This checks Kerr at points; it does not derive it. …”
*Should read:*
> … that fail. At nine rational points of the same members (M = 5, a = 3 on the axis, on the equator, generic, on both horizons and inside r₋; (1, 1/2) and (3/2, 2) at one point each), on exact 4-jets of the frame, the Einstein form vanishes as a 2-jet: the Ricci tensor and its first and second derivatives vanish at the point, by the engine and by the Christoffel route (metric 4-jet, Riemann 2-jet); the Schouten tensor is zero as a 2-jet there, so the Cotton part of the conformal Cartan curvature is zero there as a 1-jet (on the 4-jet cut to degree 3, E_a and the Schouten tensor are not zero at degree 2). Kerr–Newman in the same form (f = (Mr − s)r²/(r⁴ + a²z²), s = κQ²/4, A = (Qr³/(r⁴ + a²z²)) l) is borrowed the same way: at one horizon point of each of ten members with a ≠ 0 and Q ≠ 0, three of them extremal, the engine’s Einstein form is E_a = −κT_a with the Maxwell stress T(a) = −½FaF, all 16 components, and E_a = 0 on extremal Kerr and on Kerr just off it. This checks Kerr and Kerr–Newman at points; it does not derive them. …

- **checkedBy, append:** `f3_kn_horizons.py (E_a = −κT_a on ten Kerr–Newman members, one point each)`
- **checkedBy, append:** `h5l_bianchi_kerr.py (E_a = 0 and Schouten = 0 as 2-jets on Kerr frame 4-jets at nine points)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** INP-058: `H5L-B-Kerr`, `F3-KN`
- **audit:** AUD-A-4 (S2: the Cotton part zero as a 1-jet; the control says what fails). AUD-A-14 (the two stress signs): no text change, see the disposition.

### INP-075 · INP Needs and inputs · unchanged · from L10b · V2 row INP-075
No change (AUD-B: L10b takes Newton’s law as an input; its negative result concerns the forque lines beyond first order, not the weak-field law of this row).

- **standardRef:** no change
- **tags:** unchanged

### LAB-006 · LAB Clock, gauge and groups strips · clause extended (AUD-B-2, -11, -12) · from L10b (g2_forque_observers) · V2 row LAB-006
*Today* (V2 row LAB-006; the clause at the end of the line):
> Today: “… the engine’s covariant derivatives for the same observer (u = E₀ of the Kerr–Schild frame) agree with them at first order in M only, ∇_k E^i_j = (1 − M/r) ∂_k E^i_j, while the second carries terms of order M² and M³ and the third of order M² to M⁴ (two points, through ε⁴) …”
*Should read:*
> … the engine’s covariant derivatives for the Kerr–Schild observer u = E₀ (at the point it moves with that falling observer, but as a field it is accelerated, ∇_u E₀ = (M/r²) n, n radial) agree with them at first order in M only, ∇_k E^i_j = (1 − M/r) ∂_k E^i_j, while the second carries terms of order M² and M³ and the third of order M² to M⁴ (two points, through ε⁴); for the other radial observers, built as local boosts of that frame, E^i_j is the same ∂_i∂_jΦ and the first factor is the observer’s energy per unit mass g(u, ∂_t) — √(1 − 2M/r) static, 1 for the free fall from rest at infinity (then ∇E = ∂E exactly) — and the second and third derivatives keep terms of order M² for the static observer and the free fall (for the geodesic momentarily at rest the orders in M are not separated), while a transverse boost of speed 3/5 changes E^i_j itself by (M/r³)(27/16 δ − 27/8 n n − 27/16 m m) (m the direction of the boost; exact at the same two spatial points, with M = 9/10 and 63/50 so that 2M/r = 9/25, with controls; for the Kerr–Schild observer the covariant derivative of the four-index curvature, contracted with u afterwards, agrees with ∇E at first order and differs from order M³ on) …

- **checkedBy, append:** `g2_forque_observers.py (tidal tensor and its covariant derivatives for the static, free-falling, momentarily-at-rest and transversely boosted observers: first-order factor g(u, d_t) for the radial ones; M^2 terms beyond where the orders in M are separated)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** LAB-006: `G2-observers`
- **audit:** AUD-B-2 (S1), AUD-B-11 (n, m, the masses of the two points, the second reading), AUD-B-12 (the Kerr–Schild field is accelerated). Merge: AUD-B-11’s “n radial” sits at the first use of n (AUD-B-12’s parenthesis) and “now with” reads “with”.

### LAB-008 · LAB Clock, gauge and groups strips · one phrase: 43 horizons, 129 rows · from L5c (f4_komar_kn) · V2 row LAB-008
*Today* (V2 row LAB-008; line 1, the parenthesis):
> Today: “… (checked at points: 29 horizons, 84 first-law rows, κ = 1, 2, 4 as stand-ins for 8πG) …”
*Should read:*
> … (checked at points: 43 horizons, extremal Kerr and Kerr–Newman among them, and 129 first-law rows in two logs; κ = 1, 2, 4 as stand-ins for 8πG) …

- **checkedBy, append:** `f4_komar_kn.py (first law and Smarr on 14 more horizons, extremal Kerr and Kerr–Newman)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** LAB-008: `F4-KN`
- **audit:** AUD-A: OK.

### LNS-032 · LNS Schuller (step 20) · one insertion: the Belinfante term · from L9bA (e2s4_belinfante) · V2 row LNS-032
*Today* (V2 row LNS-032; after “A principal-tensor treatment carries neither the spin nor this antisymmetric part.” insert):
> Today: “… A principal-tensor treatment carries neither the spin nor this antisymmetric part. …”
*Should read:*
> … A principal-tensor treatment carries neither the spin nor this antisymmetric part. On the torsion-free connection the symmetrised stress is, on the Dirac shell, the canonical stress plus the Belinfante term −½ D S, which is built from the spin density alone and is antisymmetric: it cancels the antisymmetric part there and leaves the symmetric part untouched (exact at the origin of three random frames and spinors, n = 4, first-order jets, with a numpy cross-check). …

- **checkedBy, append:** `e2s4_belinfante.py (the Belinfante term: Hilbert stress = canonical stress - (1/2) D S, symmetric on the Dirac shell; Rosenfeld)`
- **standardRef, extend** (LNS-032): `; Belinfante 1940, Rosenfeld 1940 (the symmetrised stress as the canonical one plus half the divergence of the spin): pointers, sources unread`
- **tags:** unchanged
- **evidence (V2):** LNS-032: `e2s4_belinfante`
- **audit:** AUD-B-8 (the torsion-free connection, the shell, the stress without the contact term, the scope at points).

### MAP-023 · MAP Map nodes · last sentence: the forced top (merged) · from L14 + H5LK (merged) · V2 row MAP-023
*Today* (V2 row MAP-023; today’s last sentence, replaced (L14)):
> Today: “… One free-top flow runs in Euclid, elliptic and hyperbolic with the inertia built from points in each. …”
*Should read:*
> … One top flow, free and forced by force lines, runs in Euclid, elliptic and hyperbolic with the inertia built from points in each. …

- **checkedBy, append:** `h5l_bianchi_kerr.py (the so(2,4) Cartan curvature on Kerr and Kerr–Newman)`
- **checkedBy, append:** `g1_force_line.py (force lines in Cl_kappa: the join weight sin d / d / sinh d, three laws as inputs, the forque = the std torque with the sign +1, the hung body at k sin d_s = m g / k d_s = m g / k sinh d_s = m g, kappa_G = +1, 0, -1)`
- **checkedBy, append:** `g1_forced_top.py (the top forced by force lines, engine = top with a fixed point in R^4 / R^{3,1} with the torque and Newton-Euler, series through t^6, kappa_G = +1, 0, -1; the hung cube: equal characteristic polynomials, hung vertex linearly stable (all l^2 <= 0, one zero), complement unstable)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** MAP-023: `H5L-B-Kerr`, `g1_force_line`, `g1_forced_top`
- **audit:** AUD-A (the H5LK entry): OK. AUD-C: OK; the shared g1_forced_top text carries AUD-C-3. The two checkedBy lists are independent: the merge is a union.

### NUL-001 · NUL Step 13 null surfaces · five edits in line 4 (AUD-A-5, -7, -8, -10) · from L5c (f3_kn_horizons, f4_komar_kn) · V2 row NUL-001d
*Today* (V2 row NUL-001d; (a) after “… and the Smarr relation.” insert (AUD-A-10: after the sentence that names the constants’ physical form)):
> Today: “… these are dM = κ_H dA/8πG + Ω dJ + Φ dq and the Smarr relation. …”
*Should read:*
> … these are dM = κ_H dA/8πG + Ω dJ + Φ dq and the Smarr relation. With the same constants, not fitted again, both hold exactly on 14 more horizons and 45 more directions: Kerr–Newman with κ = 2 and 4, one nearly extremal member, Kerr and Kerr–Newman just off extremality, extremal Kerr (a = M) and three extremal Kerr–Newman members. On the extremal ones κ_H = 0, and along the extremal set M² = a² + κQ²/2 the first law reads dM = Ω_H dJ + (κ/2)Φ_H dQ. Along directions that leave that set the area term ½κ_H d(A/4π) does not tend to 0 but to M(M dM − a da − (κQ/2) dQ)/(M² + a²) (our derivation from the closed forms; its dM part checked on members approaching extremal Kerr and one extremal Kerr–Newman member); with this value the first law holds at the extremal members along every direction checked: there it is the limit of the non-extremal law. …

*Today* (V2 row NUL-001d; (a′) the count that stays (AUD-A-7)):
> Today: “… (standard; computed below on one Kerr and two Kerr–Newman members) …”
*Should read:*
> … (standard; computed below on three Kerr members, extremal Kerr and Kerr just off it among them, and on two Kerr–Newman members) …

*Today* (V2 row NUL-001d; (b)):
> Today: “… gives M and Ma on Schwarzschild and Kerr, R = ½ to 20. …”
*Should read:*
> … gives M and Ma on Schwarzschild and Kerr, R = ½ to 20, extremal Kerr (M = a) and Kerr just off it included. …

*Today* (V2 row NUL-001d; (c)):
> Today: “… On ten horizons, inner and extremal included, the integrand of ⋆dχ♭ equals 2κ_H (A/4π) sin θ exactly at four points each, so M_K − 2Ω_H J_K = κ_H A/4π there. Smarr then reads M − M_K(r_h) − 2Ω_H(Ma − J_K(r_h)) = (κ/2)Φ_H Q, checked on all ten. …”
*Should read:*
> … On 26 horizons, inner and extremal included (extremal Kerr and three extremal Kerr–Newman among them), the integrand of ⋆dχ♭ equals 2κ_H (A/4π) sin θ exactly at four points each, so M_K − 2Ω_H J_K = κ_H A/4π there. At κ_H = 0 this is M_K = 2Ω_H J_K; on extremal Kerr (Ω_H = 1/(2M), J_K = Ma) it reads M = 2Ω_H Ma, exactly. Smarr then reads M − M_K(r_h) − 2Ω_H(Ma − J_K(r_h)) = (κ/2)Φ_H Q, checked on all 26. …

*Today* (V2 row NUL-001d; (d)):
> Today: “… carries angular momentum (J_K(r_h) < Ma), so …”
*Should read:*
> … carries angular momentum (J_K(r_h) < Ma on all 17 Kerr–Newman horizons checked, the three extremal ones included), so …

- **checkedBy, append:** `f3_kn_horizons.py (F = −2κ_H² on Kerr–Newman and extremal horizons)`
- **checkedBy, append:** `f4_komar_kn.py (Komar M and J, Smarr and the first law on more Kerr–Newman horizons, extremal included)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** NUL-001d: `F3-KN`, `F4-KN` (moved from NUL-001, where V2 recorded it on the base row)
- **audit:** AUD-A-5 (the dM part checked; the optional exact form not taken), AUD-A-7, AUD-A-8 (1/(2M)), AUD-A-10 (insertion point).

### NUL-003 · NUL Step 13 null surfaces · one passage appended to line 1 (AUD-A-8, -9) · from L5c (f3_kn_horizons) · V2 row NUL-003
*Today* (V2 row NUL-003; line 1: append at its end):
> Today: “… At the 14 checked points off the horizons (two or three per member) F differs from −2κ_H² of either horizon of the member. …”
*Should read:*
> … At the 14 checked points off the horizons (two or three per member) F differs from −2κ_H² of either horizon of the member. On Kerr–Newman frames with a ≠ 0 and Q ≠ 0, and on extremal Kerr and Kerr just off it, the identity holds as well, for χ = ∂_t + Ω_H∂_φ, with κ_H from ∇_χχ = κ_Hχ and ∇χ from the engine’s connection, both equal to the Christoffel route, and κ_H, Ω_H equal to the recalled Boyer–Lindquist values. It is checked at four points of each horizon (pole and equator included): outer and inner horizons of seven members (κ = 1, 2, 4; one nearly extremal, one just off an extremal member), three extremal members, Kerr just off extremality and extremal Kerr (a = M, Ω_H = 1/(2M)). At these points χ ∧ ∇χ = 0 (w = 0), so ∇χ = χ ∧ u with χ·u = −κ_H, and F = −2(χ·u)² = −2κ_H² (our reading, checked at the points). On the extremal horizons κ_H = 0 and F = 0, but ∇χ is not zero off the axis: χ·u = 0 with u spacelike, so ∇χ is a null 2-form (both of its invariants vanish); of the four checked points it vanishes at the pole only, while on the extremal Reissner–Nordström horizons it vanishes at every checked point. At 8 points off the horizons of each of these twelve members (96 points) F differs from −2κ_H² for the generator of each of its horizons. Controls that fail as they must: ω → −ω, the generator ∂_t + (9/10)Ω_H∂_φ, −2κ_H in place of −2κ_H², the other horizon’s κ_H, and the members just off extremality, where κ_H ≠ 0. …

- **checkedBy, append:** `f3_kn_horizons.py (F = −2κ_H² on Kerr–Newman, extremal Kerr–Newman and extremal Kerr horizons)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** NUL-003: `F3-KN`
- **audit:** AUD-A-8 (1/(2M)), AUD-A-9 (the Kerr members named; the off-horizon count per generator).

### PAG-024 · PAG Page claim strips · parenthesis replaced (AUD-B-9) · from L9bB (b3c4_curved_points, b3c4_dirac_frw) · V2 row PAG-024
*Today* (V2 row PAG-024; the first parenthesis):
> Today: “… (pointer, not rebuilt; the gravity action and the scalar and Maxwell actions with their coupling to gravity are checked, and one Einstein–scalar cosmology is solved from them as an exact power series about one time) …”
*Should read:*
> … (pointer, not rebuilt; the gravity action and the scalar and Maxwell actions with their coupling to gravity are checked, and one Einstein–scalar cosmology is solved from them as an exact power series about one time, at and away from the spatial origin for k = ±1, as is the power-law cosmology of an exponential potential for k = 0; with the Dirac action the coupled Einstein–Dirac system of the torsionful shell is solved the same way for k = 0 and a homogeneous spinor) …

- **checkedBy, append:** `b3c4_curved_points.py (the k = +-1 series off the spatial origin with the exact conformal-factor jet; the exponential potential's power-law solution)`
- **checkedBy, append:** `b3c4_dirac_frw.py (the Einstein-Dirac FRW series of the torsionful shell, k = 0, homogeneous spinor: constraint propagated, dust + stiff contact fluid, the exchange through the mass term; DOP853 cross-check)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** PAG-024: `B3C4-curved`, `b3c4_dirac_frw`
- **audit:** AUD-B-9 (the Dirac action named; the exponential potential at k = 0).

### PRJ-004 · PRJ Step 11 projective · one sentence (AUD-C-2: checked, not re-derived) · from L14 (g1_force_line, g1_forced_top) · V2 row PRJ-004
*Today* (V2 row PRJ-004; the sentence on Gunn’s statement):
> Today: “… for the free top we re-derived it as exact series, with the inertia rebuilt from points in each algebra. …”
*Should read:*
> … for the free top we re-derived it as exact series, and for the top forced by force lines, with the force law as an input, we checked it as exact series through t⁶ on a few bodies, with the inertia rebuilt from points in each algebra. …

- **checkedBy, append:** `g1_force_line.py (force lines in Cl_kappa: the join weight sin d / d / sinh d, three laws as inputs, the forque = the std torque with the sign +1, the hung body at k sin d_s = m g / k d_s = m g / k sinh d_s = m g, kappa_G = +1, 0, -1)`
- **checkedBy, append:** `g1_forced_top.py (the top forced by force lines, engine = top with a fixed point in R^4 / R^{3,1} with the torque and Newton-Euler, series through t^6, kappa_G = +1, 0, -1; the hung cube: equal characteristic polynomials, hung vertex linearly stable (all l^2 <= 0, one zero), complement unstable)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** PRJ-004: `g1_force_line`, `g1_forced_top`
- **audit:** AUD-C-2 (S2: “re-derived” stays for the free top only).

### PRJ-005 · PRJ Step 11 projective · one sentence replaced by a block (AUD-C-1, -3 to -7, -11, -12); tag input added · from L14 (g1_force_line, g1_forced_top) · V2 row PRJ-005
*Today* (V2 row PRJ-005; today’s last sentence, replaced by the block (its last sentence is today’s, kept)):
> Today: “… Forced motion in the curved members and conformal dynamics are not developed; the equivalence with conformal dynamics stated in one partly read talk is cited, not re-derived. …”
*Should read:*
> … Step 14’s force lines run in the curved members too (the elliptic one read as the sphere S³ of signed points, the hyperbolic one as one sheet), with the force law as an input. The join of two normalised points has weight sin d, d, sinh d, so k times the join of a point and a centre is a force toward the centre of magnitude k sin d, k d, k sinh d (the potential −k cos d, k d²/2, k cosh d); μ times the join over the cube of its weight has magnitude μ / sin² d, μ / d², μ / sinh² d (the potentials −μ cot d, −μ / d, −μ coth d); a constant weight is the third law. Read through the free top’s dictionary, the engine’s forque is the torque of the top with a fixed point in ℝ⁴ / ℝ^{3,1} (one sign, +1, for every law and body run: bodies of 2 to 4 random points, the wrong power included), and the forced flows agree as exact series through t⁶, the energy being constant through t⁵ (random bodies of 3 to 4 points, the three laws, κ_G = +1, 0, −1; Euclid against Newton–Euler with the forces). A body hung by a vertex from a zero-length spring under a weight line through its centre rests with the anchor at the distance d_s above the vertex, where k sin d_s = m g, k d_s = m g, k sinh d_s = m g (on the sphere only for m g ≤ k; a second anchor at π − d_s balances too, unstably); the vertex is the sign-bit vertex of the body-frame weight line, as in Euclid; for one cube-like body per κ_G the hung vertex is linearly stable (every l² real and ≤ 0, one zero: the free turn about the vertical line) and its complement unstable, the characteristic polynomials of the engine’s linearised flow and of the Lagrangian being equal exactly. Nothing says which force law a curved space has. Conformal dynamics is not developed; the equivalence with conformal dynamics stated in one partly read talk is cited, not re-derived. …

- **checkedBy, append:** `g1_force_line.py (force lines in Cl_kappa: the join weight sin d / d / sinh d, three laws as inputs, the forque = the std torque with the sign +1, the hung body at k sin d_s = m g / k d_s = m g / k sinh d_s = m g, kappa_G = +1, 0, -1)`
- **checkedBy, append:** `g1_forced_top.py (the top forced by force lines, engine = top with a fixed point in R^4 / R^{3,1} with the torque and Newton-Euler, series through t^6, kappa_G = +1, 0, -1; the hung cube: equal characteristic polynomials, hung vertex linearly stable (all l^2 <= 0, one zero), complement unstable)`
- **standardRef, replace** “Gunn, thesis ch. 9: (9.19), (9.26)-(9.27)” by `Gunn, thesis ch. 9: (9.19), (9.26)-(9.27); §9.7: forces as weighted lines, the forced Euler equation (no force law for the curved members)`
- **tags:** tags [standard,checked,ours,open] → [standard,checked,ours,open,input] (v15 tags; legacyFlags in V2 stay as imported, see D4)
- **evidence (V2):** PRJ-005: `g1_force_line`, `g1_forced_top`
- **audit:** AUD-C-1 (S2: energy through t⁵, by wording), AUD-C-3 (linear stability defined), AUD-C-4 (the second anchor unstable), AUD-C-5 (the bodies of the forque check), AUD-C-6 + AUD-C-7 (the first sentence: step 14’s lines; S³ of signed points, one sheet), AUD-C-11 (per κ_G), AUD-C-12 (k and d_s introduced), AUD-C-13 (one Gunn entry in standardRef).

### RIG-002 · RIG Step 16 rigid body · one clause (L10b, AUD-B-14); L14’s sentence not added (AUD-C-10) · from L10b (g2_forque_observers); L14’s sentence dropped · V2 row RIG-002
*Today* (V2 row RIG-002; the clause, before the final period):
> Today: “… (two points, five symmetric and three random bodies at each). …”
*Should read:*
> … (two points, five symmetric and three random bodies at each); with the covariant derivatives of the observer in radial free fall from rest at infinity the ε² force and the ε³ torque are the summed lines’ exactly and, for the three random bodies, the ε³ force and the ε⁴ terms are not, and for the static and Kerr–Schild observers the ε² force and ε³ torque are the lines’ times √(1 − 2M/r) and 1 − M/r respectively (exact, two points). …

- **checkedBy, append:** `g2_forque_observers.py (the eps^2 force and eps^3 torque with the free-falling observer's covariant derivative are exact; on the three random bodies the eps^3 force and eps^4 terms are not, for every radial observer)`
- **standardRef:** no change
- **tags:** unchanged
- **evidence (V2):** RIG-002: `G2-observers`
- **audit:** AUD-B-14 (the random bodies; “respectively”), AUD-C-10 (the hung body said once, in RIG-003: L14’s addition, its two G1 checkedBy texts and its standardRef extension are not added here). The checkedBy text is SCR-B’s (`script_changes_B.md` §4(b)): on the three random bodies, for every radial observer; the transverse boost is not contracted with the bodies (g2_forque_observers.log:138–157).

### RIG-003 · RIG Step 16 rigid body · one clause (AUD-C-9); tags checked and input added · from L14 (g1_force_line, g1_forced_top) · V2 row RIG-003
*Today* (V2 row RIG-003; the clause, replaced):
> Today: “… the sign-bit rule for balancing a hung body (E11) and for contact (G3); …”
*Should read:*
> … the sign-bit rule for balancing a hung body (E11), with its elliptic and hyperbolic form for a spring weighted by its join, an input (the anchor at the distance d_s above the vertex where k sin d_s = m g, on the sphere only for m g ≤ k, or k sinh d_s = m g, in place of m g / k), and for contact (G3); …

- **checkedBy, append:** `g1_force_line.py (force lines in Cl_kappa: the join weight sin d / d / sinh d, three laws as inputs, the forque = the std torque with the sign +1, the hung body at k sin d_s = m g / k d_s = m g / k sinh d_s = m g, kappa_G = +1, 0, -1)`
- **checkedBy, append:** `g1_forced_top.py (the top forced by force lines, engine = top with a fixed point in R^4 / R^{3,1} with the torque and Newton-Euler, series through t^6, kappa_G = +1, 0, -1; the hung cube: equal characteristic polynomials, hung vertex linearly stable (all l^2 <= 0, one zero), complement unstable)`
- **standardRef:** no change
- **tags:** tags [ours] → [ours,checked,input] (v15 tags; legacyFlags in V2 stay as imported, see D4)
- **evidence (V2):** RIG-003: `g1_force_line`, `g1_forced_top`
- **audit:** AUD-C-9 (d_s defined, the bound, the input named; the tag checked is the consequence, input follows the rule PRJ-005 follows).


## C. The coordinator’s edits, as finally decided

The five edits of the draft to a lead’s sentence, with the audits’ verdicts:

| # | row | the draft’s edit | final decision |
|---|---|---|---|
| 1 | GRV-004 | “where the Schouten tensor vanishes as a 2-jet” confined to Kerr | kept (AUD-A: right). The reason, worded as AUD-A-13 gives it: on Schwarzschild–de Sitter the Schouten tensor is a nonzero constant multiple of the metric; the Schouten tensor’s covariant derivative is zero, so the Cotton 2-form vanishes. |
| 2 | GRV-004 | “Kerr: nine points of three members, among them …”; “with s = κQ²/4” | the nine-point parenthesis is replaced by AUD-A-3’s (the Christoffel route compares d_∇Weyl at the three Kerr points of M = 5, a = 3 and reaches the other six through its Ricci 2-jet); the definition of s is kept. |
| 3 | GRV-011 | “(recalled form)” → “(the form checked above against the action)” | kept (AUD-B: justified; the three routes use the same 3κ/8). |
| 4 | INP-058 | “This checks Kerr and Kerr–Newman at points; it does not derive them.” | kept (AUD-A: right). |
| 5 | LNS-032 | standardRef extended with the Belinfante and Rosenfeld pointers | kept (AUD-B: OK). |

The edits of this final ledger to a lead’s or an audit’s text, beyond applying a replacement as the audit gives it (each sentence is in `own_wording.txt` when it is not covered by the sources; `prov_check_final.py` prints the classes):

| # | row | edit | why |
|---|---|---|---|
| 6 | EQN-019 | “n the radial unit vector” after AUD-B-12’s “∇_u E₀ = (M/r²) n” | in this row n is also the dimension (“n = 1 to 4”); the log gives the acceleration as (M/r²) times the radial unit vector (`g2_forque_observers.log`, section 2.1) |
| 7 | LAB-006 | AUD-B-11’s “n radial” stands at the first use of n, in AUD-B-12’s parenthesis; “now with M = 9/10 and 63/50” reads “with M = 9/10 and 63/50” | n is used in AUD-B-12’s parenthesis before AUD-B-11 defines it; the shorter phrase says the same |
| 8 | GRV-011 | “(K* the contorsion of that axial torsion)” after “ω* = ω_LC + K*”; P and s⁰ defined at their first use, in AUD-B-1’s rest-class parenthesis; AUD-B-15(d) taken without its “(relative remainder below 0.25)” | K* was not defined in the row (AUD-B-15(e) gives the definition for CPL-008); AUD-B-1’s text uses P and s⁰ before it defines them; the ratio is 20.9 for a at t = 0.01, where the deviation is at the level of rounding (`b3c4_dirac_frw.log`, the DOP853 block), and the check states its bound at t = 0.02 and 0.04 for χ and the bilinears and at 0.04 and 0.08 for a |
| 9 | RIG-002 | checkedBy: “for the three random bodies the eps^3 force and eps^4 terms are not, for every radial observer run” | AUD-B-14’s scope, applied to the checkedBy text; the transverse boost is not contracted with the bodies (`g2_forque_observers.log`, the bodies lines of both points) |
| 10 | GRV-007 | checkedBy: `b3c4_dirac_frw.py` not appended; the README row B3C4-dirac does not name GRV-007 | AUD-B-15(g): the script checks nothing this row states |

### C2. Rows that two leads or two audits touch: how the texts were merged

- **GRV-004** (one lead, one audit, AUD-A): the draft’s three merge edits stay except edit 2’s parenthesis, which AUD-A-3 replaces; AUD-A-1’s clause on W·*W stays, because the zero pattern is true as mathematics and SCR-A’s script now computes the invariant (section D1); AUD-A-2 is the checkedBy text. No conflict.
- **GRV-011** (two leads, one audit, AUD-B): AUD-B-1 and AUD-B-3 touch the same sentence of piece 2b; AUD-B-3’s data-set parenthesis goes into the first parenthesis of piece 2b and its “on that data set” into AUD-B-1’s replacement (“exact through t⁶ on that data set”). AUD-B-5 replaces the second sentence of place 1 and AUD-B-15(c) extends its first sentence; AUD-B-6 changes the kept text; AUD-B-7 and AUD-B-15(a, b) go into piece 2a. Piece 2a’s and piece 2b’s “Not built” items are each dropped because the other lead built them (the draft’s reasoning, AUD-B: true).
- **INP-058** (two leads, one audit, AUD-A): AUD-A-4 changes the end of H5LK’s clause; L5c’s clause is as the lead wrote it; AUD-A-14 changes nothing (see the disposition).
- **RIG-002** (two leads, two audits): AUD-B-14 rewrites L10b’s clause; AUD-C-10 (decision 2 of the brief) leaves out L14’s sentence, its two G1 checkedBy texts and its standardRef extension. The two do not conflict.
- **MAP-023** (two leads, two audits): the sentence is L14’s (AUD-C: OK); the checkedBy list is the union of H5LK’s entry (AUD-A: OK) and the two G1 texts, the g1_forced_top text with AUD-C-3’s “linearly stable (all l^2 <= 0, one zero)”.
- **NUL-001** (one lead, one audit, AUD-A): AUD-A-10 moves edit (a) after “… and the Smarr relation.”; AUD-A-5 changes edit (a)’s parenthesis; AUD-A-7 changes the count that stays in the next sentence; AUD-A-8 writes 1/(2M) in edit (c). All in line 4 (NUL-001d); no conflict.
- **LAB-006** (one lead, three findings of AUD-B in one clause): AUD-B-12 at the head of the clause, AUD-B-2 in its middle, AUD-B-11 in its last parenthesis; merged as edit 7.
- **EQN-019 / EQN-020**: EQN-019 takes AUD-B-2 and AUD-B-12 in one clause (edit 6); EQN-020 takes AUD-A-6. No conflict.

## D. The folder `checks/selfcheck/gravity/`: README, run_all, MANIFEST, the d-sign patches

### D1. README table: fourteen rows (the nine columns of the folder’s table)

The rows go into the table at the places of the matching rows of `run_all.sh` (the table follows its order): A5-strong after A5, A6-strong after A6, B3C4-curved and B3C4-dirac after B3C4S, E2S4-belinfante and E2S4-HD after E2S4-fluid, F3-KN after F3-reduced, F4-KN after F4-komar, G1-force and G1-forced after G1, G2-observers after G2-fourth, H5L-B-Kerr after H5L-B, D-PROBE and BLIND-SPOTS after DUP-6. The “s” column is the wall time of the run whose log ships (the closing’s re-run for the nine rows SCR-A and SCR-B re-ran (`script_changes_A.md` §6, `script_changes_B.md` §2), the lead’s run for A6-strong, F3-KN, F4-KN, D-PROBE and BLIND-SPOTS, whose logs ship as the leads wrote them); `run_all.sh` replaces it when the lead runs the rows.

| Step | Script | What it checks | Standard route (second source) | Atlas rows | Exit code and last line of the shipped log | ok | FAIL | s |
|---|---|---|---|---|---|---|---|---|
| A5-strong | `a5_strong_maps.py` | the laws of A5 (E law, R law, connection law, coordinate tensor) for all nine map types (Cayley; rotor products with U U~ > 0 and < 0; P, T, PT times the Cayley map and times the rotor with U U~ > 0) on three strong frames per n = 3, 4, with the degree D of each law and the failure bound per map type and n | A5's polynomial code without the engine (Lambda^T eta Lambda = eta as 2-jets, the metric of Lambda e, the Christoffel spin connection and its gauge law, a Leibniz determinant) and A4's standard Einstein tensor; the Schwartz-Zippel lemma (recalled) | ATL-018, INP-045, INP-055 | 0; `FAILS (A5-strong): none` | 137 | 0 | 28 |
| A6-strong | `a6_strong.py` | the identities of A6 on strong random data, three seeds per case: the Chern-Simons fits (1, 1/6), the exact k(R,R) space (nullity 2 + 10), Nieh-Yan, Holst = 0 at T = 0, the MacDowell-Mansouri expansion, n = 5 and n = 2; each with its degree D and failure bound ((4/101)^3 < 6.3e-5 for every form identity, (18/997)^3 < 5.9e-6 for Holst = 0 at T = 0 (R = 500)) | A6's numpy route (so(1,3) matrices, tr(R R), 8 Pf(R), Chern-Simons with 2/3, stencils) at strong data; the Christoffel route at T = 0; the Schwartz-Zippel lemma (recalled) | CPL-011, GRV-010, INP-044, INP-048 | 0; `FAILS (A6-strong): none` | 294 | 0 | 182 |
| B3C4-curved | `b3c4_curved_points.py` | the Einstein-scalar FRW series solved at the spatial origin (k = +1, -1) satisfy the engine's equations at rational points of the isotropic chart with the exact Taylor jet of 1/(1 + k r^2/4); the exponential potential reproduces a = t^p, phi = (2/lambda) ln t (p, V0 derived; k = 0, c = 0, (kappa, lambda) = (1, 1) and (2, 3)); the d-sign probe (D-PROBE's d_sign_probe) | the Christoffel route of g = diag(1, -a^2 f^2, ...) at the point as series in t on plain rationals; the textbook Friedmann-Klein-Gordon recursion; the closed form derived in the script | GRV-007, GRV-011, INP-049, INP-050, PAG-024 | 0; `FAILS (B3C4-curved): none` | 44 | 0 | 7 |
| B3C4-dirac | `b3c4_dirac_frw.py` | the coupled Einstein-Dirac system of the torsionful shell (k = 0, homogeneous spinor; one generic data set, a spinor at rest and a massless one, all at kappa = 1) solved as an exact series in t: the Friedmann constraint imposed at t = 0 only is propagated; the torsion-free Einstein form reads dust + stiff contact fluid at every order; the two parts exchange energy through the mass term | E2's Dirac matrices, E1's Christoffel spin connection, the Hehl-Datta form of the Dirac equation, the textbook symmetric stress, scipy DOP853 | GRV-011, INP-049, INP-050, PAG-024 | 0; `FAILS (B3C4-dirac): none` | 31 | 0 | 44 |
| E2S4-belinfante | `e2s4_belinfante.py` | the Belinfante term of the Dirac field as a separate object: Hilbert stress = canonical stress + B, B_ab = -(1/2)(D S)_ab (exact fit), antisymmetric; off shell tau^LC_ab - tau^LC_ba = (1/2)(B_ab psi).EL / vol; on the torsion-free Dirac shell the Hilbert stress is symmetric and the canonical tau_ab - tau_ba = (D S)_ab (Rosenfeld) | numpy: the Hilbert stress by a numerical functional derivative of the textbook density with the Christoffel spin connection recomputed from (e, de); the textbook canonical stress and spin current; T_H = T_can + (1/2) nabla^c sigma_cab | GRV-011, LNS-032 | 0; `FAILS (E2S4-belinfante): none` | 67 | 0 | 101 |
| E2S4-HD | `e2s4_hehl_datta.py` | the Hehl-Datta equation in closed form: on omega* = omega_LC + K*(psi) the Dirac Euler-Lagrange form off shell is EL(omega_LC) + (3 kappa/16) d[(s.s) vol]/dpsi (exact fit, at the origin and as first-order jets); operator form with 3 kappa/8 (twice the contact coefficient); a trace contorsion drops out | numpy: the textbook density with the Christoffel spin connection and K* from the bilinears, varied numerically in chibar: (i Gamma nabla - m) chi + (3 kappa/8) A_d Gamma^d gamma5 chi | CPL-008, GRV-011, INP-050 | 0; `FAILS (E2S4-HD): none` | 52 | 0 | 20 |
| F3-KN | `f3_kn_horizons.py` | F = nabla_a chi_b nabla^a chi^b = -2 kappa_H^2 on the horizons (outer and inner; one double horizon on each of the three extremal members) of ten Kerr-Newman members with a != 0, Q != 0, extremal Kerr and Kerr just off it; nabla chi = chi ^ u; on the rotating extremal horizons F = 0 with nabla chi a nonzero null 2-form (zero at the poles); the a = 0 and Q = 0 limits reproduce F3 | Christoffel symbols of g = e^T eta e (nabla_m chi_n, F, kappa_H, twist, second invariant); the recalled Boyer-Lindquist kappa_H and Omega_H | EQN-020, INP-058, NUL-001, NUL-003 | 0; `FAILS (F3-KN): none` | 121 | 0 | 56 |
| F4-KN | `f4_komar_kn.py` | the engine's Komar integrands equal F4's closed forms at 108 points on 27 spheres; on 16 more horizons (*d chi^b) = 2 kappa_H Abar sin(theta) pointwise, M_K - 2 Omega_H J_K = kappa_H Abar, Smarr from the integral side; F2's first law on 14 more horizons, extremal included, with the first law at kappa_H = 0 as the limit of the area term | F4's float route (closed-form Kerr-Schild metric, complex-step derivatives, Gauss-Legendre at two orders), its Boyer-Lindquist closed forms and plain-polynomial route | EQN-020, LAB-008, NUL-001 | 0; `FAILS (F4-KN): none` | 59 | 0 | 29 |
| G1-force | `g1_force_line.py` | force lines in Cl_kappa^3 (kappa = +1, 0, -1): the join of two normalised points has weight sin d, d, sinh d; three laws (join, join over the cube of its weight, constant weight); the forque = the torque of the top with a fixed point in R^4 / R^{3,1} under G1's dictionary (sign +1 on every law and body run); the hung body rests iff k sin d_s = m g, k d_s = m g, k sinh d_s = m g (S^3 bound m g <= k) | the geodesic formulas in R^4 / R^{3,1}; the torque sum of the top with a fixed point; Euclid: force and moment, E11 with pgadyn_selfcheck's own functions | FRQ-005, MAP-023, PRJ-004, PRJ-005, RIG-003 | 0; `FAILS (G1-force): none` | 138 | 0 | 0 |
| G1-forced | `g1_forced_top.py` | the top forced by force lines: the engine flow equals the top with a fixed point in R^4 / R^{3,1} with the torque and Newton-Euler with the forces, as exact series through t^6 (energy through t^5); the characteristic polynomial of the linearised engine flow equals that of the Lagrangian exactly at the hung cube's rest states; the hung vertex is linearly stable (all l^2 <= 0, one zero: the turn about the vertical) and the complement unstable, one cube-like body of 8 points per kappa = +1, 0, -1 | G1's top with a fixed point with the torque term, textbook Newton-Euler, Lagrangian small oscillations (exact Hessians), numpy roots | FRQ-005, MAP-023, PRJ-004, PRJ-005, RIG-003 | 0; `FAILS (G1-forced): none` | 88 | 0 | 19 |
| G2-observers | `g2_forque_observers.py` | the tidal tensor and its covariant derivatives for other observers (static, radial free fall, geodesic momentarily at rest, transverse boost) as local boosts of the Kerr-Schild frame: E' = Phi_,ij for every radial observer; the first covariant derivative is g(u, d_t) times Phi's third derivatives (1 for the free fall from rest at infinity: nabla E' = dE' exactly); the second and third are not Phi's derivatives for any radial observer and keep M^2 terms for the Kerr-Schild, static and free-falling observers (orders not separated for the geodesic momentarily at rest); the transverse boost changes E'; at the Kerr-Schild observer the two readings of the covariant derivative agree at the first derivative and differ from order M^3 on | Lorentz condition and matrix form of the boost; the Christoffel route with the observer's 4-velocity; Taylor coefficients of Phi and G2's vector sums | EQN-019, LAB-006, RIG-002 | 0; `FAILS (G2-observers): none` | 207 | 0 | 195 |
| H5L-B-Kerr | `h5l_bianchi_kerr.py` | the Bianchi identity of the so(2,4) Cartan curvature on exact 4-jets of Kerr (9 points, 3 members) and Kerr-Newman (4 points, 2 members) Kerr-Schild frames: on Kerr E_a and the Schouten tensor vanish as 2-jets, the Cotton 2-form as a 1-jet, D_A F = 0 and D_L W = 0 with W != 0; on Kerr-Newman D_L W = e C - e C != 0 and D_L C = W.f with both sides nonzero at a generic and an axis point and zero at the two equatorial points, where W.*W vanishes | an own Christoffel route as jets (metric 4-jet, Riemann 2-jet, Schouten); h5l_bianchi.std_route2 at the 3 Kerr and 4 Kerr-Newman points; the 2-jet helpers as independent series routes; W.W and W.*W = (1/2) W_{rsmv} eps^{mvpq} W^{rs}_{pq} from the standard Weyl tensor (indices moved with g), equal to those of the engine's Weyl 2-form and to 48 Re Psi_2^2, -48 Im Psi_2^2 of the recalled Kerr-Newman Psi_2 | ATL-014, GRV-004, INP-058, MAP-023 | 0; `FAILS (H5L-B-Kerr): none` | 82 | 0 | 21 |
| D-PROBE | `d_probe.py` | the engine's d of polynomial functions and 1-forms against plain partial derivatives (n = 3, 4); its function d_sign_probe() runs inside the scripts named under "Engine faults M1 to M8" | partial derivatives on exponent tuples (textbook calculus) | - | 0; `FAILS (D-PROBE): none` | 7 | 0 | 0 |
| BLIND-SPOTS | `blind_spot_probes.py` | why three blind spots of the mutation tables stay ok under a fault: C2's Kretschmann scalar under M1, D1's particle at rest under M3 and M5, F2's fifth chip under M6 | the Kretschmann scalar and the Riemann tensor by the Christoffel route; -Gamma u u from the metric; the keys of the h table by the commutation rule | - | 0; `FAILS (BLIND-SPOTS): none` | 25 | 0 | 5 |

The cells of the 14 patched rows (D2) change too: their ok cell is the “ok after” of D2 and their s cell the time of the re-run log. Totals when all 83 rows run: 5,569 (v15’s 69 rows as the author ran them) + 91 (the 13 patches, 7 lines each) + 1,342 (the 14 rows of this batch as the leads ran them) + 10 (the 14th patch, 7 lines, and the three lines SCR-A added to H5L-B-Kerr) = 7,012 checks, 0 FAIL (`script_changes_A.md` §6; SCR-B’s edits change no count). The wall-time sentence of the README’s “Run” section, “the rows of the shipped run add up to about 23 minutes of wall time”, takes the total of the shipped run (`logs/SUMMARY.txt`) when the lead runs the rows; until then it reads “(one script at a time; the s cells of the table add up to about 35 minutes of wall time)”: 1,395 s for the 69 rows (the author’s 1,401 s, with the 13 patched rows at the times of their re-runs) and 707 s for the 14 rows, 2,102 s in all (AUD-D-11).

### D2. The d-sign probe in fourteen scripts (L7, and the 14th by AUD-D-1)

Why. The pair (d, ω) → (−d, −ω) leaves R and the Einstein form E_a unchanged, so a check that reads only R, E_a or what is built from them cannot see the fault M4 (a sign flip of the engine’s exterior derivative). Thirteen scripts of the author’s package and `b3c4_curved_points.py` of this batch had no line that reads d itself; the probe `d_probe.d_sign_probe()` (7 lines; 6 of them fail under M4) is called after their first heading. Each patch adds one line.

How. SCR-A applied the 13 diffs of `leads3/L7/patches/` with `patch -p0` (each file byte for byte L7’s patched copy) and wrote the 14th line after the first `head(...)` of `b3c4_curved_points.py` (its line 166), then re-ran the 14 logs once each from `checks/`: every check line of L7’s patched runs is reproduced, the 37 lines of `b3c4_curved_points.log` are unchanged and the seven probe lines follow its first heading. M4 is seen with six failing lines in all 14 (L7’s `--only M4` runs for the 13; for the 14th SCR-A’s `--only M4` run and its full table, M1:29 M2:19 M3:0 M4:6 M5:0 M6:11 M7:1 M8:1, every other cell as before). In `a4_einstein_tensor.py` and `d2_linearised.py`, whose first heading runs inside a loop over n, the line goes once before the loop and prints its own heading.

| script | ok before | ok after | M4 before | M4 after (failing lines) |
|---|---|---|---|---|
| `a2_sampling.py` | 37 | 44 | silent | seen (6) |
| `a4_einstein_tensor.py` | 30 | 37 | silent | seen (6) |
| `b3c4_curved_points.py` | 37 | 44 | silent | seen (6) |
| `c1_birkhoff.py` | 16 | 23 | silent | seen (6) |
| `d2_linearised.py` | 97 | 104 | silent | seen (6) |
| `dup_6.py` | 20 | 27 | silent | seen (6) |
| `e2s4_spin_fluid.py` | 14 | 21 | silent | seen (6) |
| `g2_tidal_forque.py` | 93 | 100 | silent | seen (6) |
| `h1_petrov.py` | 157 | 164 | silent | seen (6) |
| `h1_duality_rotation.py` | 117 | 124 | silent | seen (6) |
| `h3_pseudoscalar.py` | 89 | 96 | silent | seen (6) |
| `h5s_conformal.py` | 100 | 107 | silent | seen (6) |
| `l3_cartan_weyl.py` | 288 | 295 | silent | seen (6) |
| `l3_cartan_weyl_flipped.py` | 292 | 299 | silent | seen (6) |

The claims rows are untouched by the patches (L7 changes no row).

### D3. The README section “Engine faults M1 to M8”

Two paragraphs, after the last paragraph of the section (L7’s, with AUD-D-1, AUD-D-14 and AUD-D-2):

> M4 changes the sign of d. Where omega is the closed form built with the engine's d, the pair (d, omega) -> (-d, -omega) leaves R and the Einstein form E_a unchanged, so check lines that read only R, E_a or what is built from them cannot see M4. `d_probe.py` reads d itself: its function `d_sign_probe()` compares the engine's d of polynomial functions and 1-forms (n = 3 and 4) with plain partial derivatives, and six of its seven lines fail under M4 (the seventh states that no derivative of the test data is zero). The scripts `a2_sampling.py`, `a4_einstein_tensor.py`, `c1_birkhoff.py`, `d2_linearised.py`, `dup_6.py`, `e2s4_spin_fluid.py`, `g2_tidal_forque.py`, `h1_petrov.py`, `h1_duality_rotation.py`, `h3_pseudoscalar.py`, `h5s_conformal.py`, `l3_cartan_weyl.py`, `l3_cartan_weyl_flipped.py` and `b3c4_curved_points.py`, whose own lines do not see M4, call it after their first heading (`a4_einstein_tensor.py` and `d2_linearised.py` once before their loop over n, under its own heading); in these scripts M4 is seen through those six lines only.

> `blind_spot_probes.py` checks the reason for three blind spots of the mutation tables, checks that stay ok under a fault. On the Kerr-Schild frames of C2 (at six of C2's Kerr points and four Schwarzschild points) the quadratic part of R is aligned with the null 1-form l in both index pairs and l is a repeated principal null direction of R, so the Kretschmann contraction does not read the coefficient of that part (M1; other lines of C2 see M1). On D1's weak-field frame the free fall of a particle at rest does not read the entry sorted(h)[3] that M3 and M5 change (D1's M3 and M5 cells are silent); a particle with a y velocity does. On the fifth chip of F2 every omega^{a3} lies along e^3, so R does not read the f signs that M6 changes; Kerr-Newman off the equator does (F2 sees M6 through its Kerr-Newman lines).

And the sentence of the same section “G1, G4, H2, H6 and L2 do not use the parts of the engine that these faults change; their controls are faults of their own (G1, G4 and L2 also take `--fault`).” is replaced by (L7’s finding, with AUD-D-3 and AUD-C-14):

> G1, G1-force, G1-forced, the three G3 scripts, G4, L2, `h6_closure_kg.py` and `forque_gunn_check.py` build no object of this engine. H2, `h6_area_metric.py` and H6-count build some through `g2_weyl.py`, but none of their check lines reads a quantity that one of the eight faults changes: every cell of their tables is silent. Their controls are faults of their own (G1, G1-force, G1-forced, G4 and L2 also take `--fault`).

The placement of the rows against the eight faults: `leads3/L7/L7_TABLE.md` places v15’s 69 README rows (42 see M4, 13 had no line that sees it and call the probe, 8 build no engine object, 3 build objects with every cell silent, 3 are import-only helpers); of the 14 rows of this batch, 11 see M4 through their own lines, B3C4-curved through the probe (M4:6 in SCR-A’s table, the six probe lines), and G1-force and G1-forced build no engine object (AUD-D-1).

### D4. What else the build has to touch, and what the apply step of this copy does

The folder (`checks/selfcheck/gravity/`):
- `run_all.sh`: the 14 rows, at the places of D1 (69 → 83 rows); written in this copy. Three scripts import a sibling of this batch (`f4_komar_kn` ← `f3_kn_horizons`, `e2s4_hehl_datta` ← `e2s4_belinfante`, `g1_forced_top` ← `g1_force_line`); the order of the rows does not matter for imports.
- `README.md`: the 14 rows of D1, the ok and s cells of the 14 patched rows, the two paragraphs and the sentence of D3, the wall-time sentence; written in this copy.
- `MANIFEST.sha256` (AUD-D-9): 28 entries to add (14 scripts, 14 logs); to change: every script SCR-A and SCR-B edited (the 14 patched ones among them), `run_all.sh`, `README.md`, `logs/SUMMARY.txt` and every log that is re-run (all of them when `run_all.sh` runs whole). It can only be written once the scripts and logs of SCR-A, SCR-B and this copy are in one tree: the lead regenerates it at the merge (`cd checks/selfcheck/gravity && sha256sum` of every file but itself).
- `logs/SUMMARY.txt`: the 14 rows and the 14 re-run rows, from the lead’s `bash run_all.sh` (or `bash run_all.sh <the 28 names>`) after the merge; the README’s s cells then follow it.

The V2 tables (the apply step of `B3_ADDENDUM.md` §3, done in this copy; `BATCH3_RESULT_final.md` gives the counts):
- `content/texts.json`: the research texts of the 26 V2 rows of section A take the final bodies (the Today fragments replaced by the Should-read texts), `status: "reviewed"`, `source: "ledger:batch3"`; the replaced bodies go to `content/story/retired_texts.json` as `{ row, body, status: "human", source, retiredBy: "ledger:batch3" }` (never rendered).
- `content/rows.json`: the evidence entries of section B (`{ check, script: "checks/selfcheck/gravity/<script>.py", mode: "ran" }`; the check is the id `content/checks.json` has, or the script’s name where the record has no id); the entries V2 put on the base rows ATL-014, GRV-004 and NUL-001 move to the lines they back (ATL-014c, GRV-004c, NUL-001d); `since: "v16"` on the 26 V2 rows of section A (ATL-018b, GRV-004c and NUL-001d in place of ATL-018, GRV-004 and NUL-001, whose texts do not change); the standardRef changes of section B (on every line of the v15 row); `mergeNeeded` cleared on GRV-011 and RIG-002, and their two notes that said a merge was needed say how it was done.
- The tags: `legacyFlags` stay as imported (read-only, `docs/02_CONTENT_MODEL.md` §1); the tag changes of section B are the v15 claims table’s. The V2 status is computed by `npm run content`: with its legacy tags RIG-003 stays “our reading”, which suits a line that is a reading with one checked clause.
- `content/check_runs.json`: one run per script re-run in the closing (SCR-A’s and SCR-B’s logs), `machine: "the round-7 closing, run from checks/"`, `source: "checks/selfcheck/gravity/logs/<script>.log"`.
- `content/checks.json`: the `ids` and `what` of the scripts whose printed statement changed: `h5l_bianchi_kerr.py` (the corrected W·*W line and the three lines SCR-A added; SCR-A’s statement, in place of the truncated one), `b3c4_curved_points.py` (the probe; the record had no id and no statement: id B3C4-curved and SCR-A’s statement), `g2_forque_observers.py` (SCR-B’s fragment for the orders in M) and `a5_strong_maps.py` (the nine types as they run, AUD-D-8 and SCR-A’s messages).
- `content/leads.json`: every `edits` entry gains `disposition` and `ledgerEntry`; `mergeNeeded` is `[]`; `coordinatorNotes` keeps only what is not done; the outcome line of L9bB, which repeats AUD-B-1’s false “only on the rest class or for m = 0”, reads:

> pass; a negative part against the brief: for the generic homogeneous spinor run the mass term exchanges energy between the dust and the stiff contact part, so they are not conserved separately; they are for a spinor at rest, and for m = 0 the stiff part a⁶ρ_c alone is constant

The documents (AUD-D-10, read for V2): V2 has no copy of the package’s `README.md` line 78 or `BUILDING.md` line 91; in V2 the only text that quotes a count of these rows is the README’s wall-time sentence (D1). `tools/migrate/verify_counts.mjs` pins the import of the author’s package (`checks.gravityRows` 69, `checks.gravityOk` 5569, `checks.wave3Ok` 1342 in `content/MIGRATION_COUNTS.json`); those are the counts of the import, and the runs of the closing are recorded in `content/check_runs.json` instead. v15’s own pins (`test_gravity_scripts.mjs`, `test_claims_sync`, …) belong to the author’s package and are not in V2.

The learner texts (the translator's files, not tables of this copy):
- 17 rows of section A have a learner draft written for their v15 text: `content/texts_learner.json` (ATL-018b, FRQ-005, LAB-008, PRJ-004, RIG-003), `content/texts_learner_2.json` (CPL-008, EQN-019, EQN-020, GRV-004c, GRV-010, GRV-011, LAB-006, NUL-001d, NUL-003, PRJ-005, RIG-002) and `content/texts_learner_schuller.json` (LNS-032). Against the final bodies `node tools/check_learner_texts.mjs` finds 30 failures in these 17 records (R6 numbers 10, R7 1, R8 status words 7, R11 kept numbers 12), so `npm run content` stops at its first step; three drafts say the opposite of the final body (GRV-004c "Kerr not done", GRV-011 "Not built", PRJ-005 "not developed").
- `docs/round7/batch3/learner_drafts_b3.json` holds the 17 records with the parts the final body changes translated again (same row, level, lens, mode and register; `status: "draft"`). `node tools/check_learner_texts.mjs --file docs/round7/batch3/learner_drafts_b3.json`: all 13 rules hold. With the 17 records in place of the old ones in the three files, `npm run content` passes with 0 validation errors, and logbook, engines, `build.sh` and coverage pass; shipped holds 61 of its 64 checks, the three others failing on files this batch does not touch (`docs/RELEASE_NOTES_v2.3.0-pre.1.md`, the 136 "intro" placements that `content/pages.json` lacks, the release files of 2.3.0-pre.1). The three files belong to R1 and stay as they are in this copy: the lead puts the 17 records in, or R1 translates the 17 rows from the final bodies.

Running the apply step again:
- `docs/round7/batch3/apply_b3.py` with `apply_b3_data.json` is the apply step of this copy as a script, run from the repository root: with `--check` it prints what it would write and writes nothing. A second run writes the same bytes (on this copy `--check` reports 0 texts, 0 evidence entries, 0 runs and 0 README edits to write), and a value that holds neither the import's text nor the ledger's stops it before anything is written.
- `npm run migrate` (`tools/migrate/run_all.sh`) writes `content/texts.json`, `rows.json`, `checks.json`, `check_runs.json`, `leads.json` and `wave3_ship_notes.json` again from the author's package and the leads' folders, which takes the apply step out of those tables (not out of `content/story/retired_texts.json`, the README or `run_all.sh`); `apply_b3.py` then puts it back.
- `content/wave3_ship_notes.json` (SCR-B's §4(a)): the migration's record of the leads' SHIP_NOTES keeps the leads' `what`, `ok` and `checkedBy` of the 14 scripts (H5L-B-Kerr at 79 ok, the G2-observers fragment "terms beyond first order in M listed as exact fits per observer"). `npm run content`, `build.sh` and the tests do not read it; `npm run migrate` copies its checkedBy texts into the evidence of `rows.json`. It has no owner in `PLAN.md` §3 and stays as it is in this copy (the lead's call).
- The `disposition` and `ledgerEntry` fields of `content/leads.json` are records only: `src/logbook/Leads.jsx` does not show them.
