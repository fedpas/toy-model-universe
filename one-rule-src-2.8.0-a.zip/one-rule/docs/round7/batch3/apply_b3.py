# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# apply_b3.py: the apply step of docs/round7/B3_ADDENDUM.md §3, from LEDGER_BATCH3_final.md (sections D1 and D3) and apply_b3_data.json (both next to
# this file). It writes content/texts.json, content/story/retired_texts.json, content/rows.json, content/check_runs.json, content/checks.json,
# content/leads.json, checks/selfcheck/gravity/README.md and checks/selfcheck/gravity/run_all.sh. Idempotent: a value that already holds the ledger's
# is left as it is; a value that holds neither today's (the v15 text, the import) nor the ledger's stops the run before anything is written.
# Usage, from the repository root:  python3 -B docs/round7/batch3/apply_b3.py [--check]      (--check: report, write nothing)
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
C = os.path.join(ROOT, 'content'); G = os.path.join(ROOT, 'checks', 'selfcheck', 'gravity')
CHECK_ONLY = '--check' in sys.argv
D = json.load(open(os.path.join(HERE, 'apply_b3_data.json'), encoding='utf-8'))
LEDGER = open(os.path.join(HERE, 'LEDGER_BATCH3_final.md'), encoding='utf-8').read()
SRC = 'ledger:batch3'
errors, done = [], []
rd = lambda p: json.load(open(p, encoding='utf-8'))
def wr(p, obj):
    if not CHECK_ONLY: open(p, 'w', encoding='utf-8').write(json.dumps(obj, ensure_ascii=False, indent=1))

# ---------------------------------------------------------------- 1. texts.json and retired_texts.json
T = rd(os.path.join(C, 'texts.json'))
RT_P = os.path.join(C, 'story', 'retired_texts.json')
RT = rd(RT_P) if os.path.exists(RT_P) else []
isres = lambda t: t['level'] == 'research' and t['lens'] is None and t['mode'] == 'both' and t.get('register', 'full') == 'full'
n_text = n_ret = 0
for row, b in D['bodies'].items():
    recs = [t for t in T if t['row'] == row and isres(t)]
    if len(recs) != 1: errors.append(f'texts: {row}: {len(recs)} research records'); continue
    t = recs[0]
    if t['body'] == b['new'] and t['status'] == 'reviewed' and t['source'] == SRC: pass
    elif t['body'] == b['old']:
        t['body'], t['status'], t['source'] = b['new'], 'reviewed', SRC; n_text += 1
    else: errors.append(f'texts: {row}: the body is neither today\'s nor the ledger\'s')
    if not any(r['row'] == row and r.get('retiredBy') == SRC for r in RT):
        RT.append({'row': row, 'body': b['old'], 'status': 'human', 'source': b['source'], 'retiredBy': SRC}); n_ret += 1
RT.sort(key=lambda r: (r['row'], r.get('retiredBy', '')))
done.append(f'texts.json: {n_text} research texts written ({len(D["bodies"])} in the ledger); retired_texts.json: {n_ret} added ({len(RT)} records)')

# ---------------------------------------------------------------- 2. rows.json
R = rd(os.path.join(C, 'rows.json')); byid = {r['id']: r for r in R}
n_ev = n_mv = n_since = n_sref = 0
for row, entries in D['evidenceAdd'].items():
    ev = byid[row].setdefault('evidence', [])
    for e in entries:
        if not any(x.get('check') == e['check'] and x.get('script') == e['script'] for x in ev): ev.append(dict(e)); n_ev += 1
for row, scripts in D['evidenceMove'].items():
    ev = byid[row].get('evidence') or []
    keep = [x for x in ev if not any((x.get('script') or '') == 'checks/selfcheck/gravity/' + s for s in scripts)]
    n_mv += len(ev) - len(keep); byid[row]['evidence'] = keep
for row in D['sinceOn']:
    if byid[row].get('since') != 'v16': byid[row]['since'] = 'v16'; n_since += 1
for row in D['sinceOff']:
    if byid[row].get('since') == 'v16': byid[row]['since'] = 'v15'; n_since += 1
for row, s in D['standardRef'].items():
    cur = byid[row].get('standardRef')
    if cur == s['new']: continue
    if cur == s['old']: byid[row]['standardRef'] = s['new']; n_sref += 1
    else: errors.append(f'rows: {row}: standardRef is neither today\'s nor the ledger\'s')
for row in D['clearMergeNeeded']: byid[row].pop('mergeNeeded', None)
for row, (old, new) in D['rowNotes'].items():
    notes = byid[row].get('v16') or []
    if old not in notes and new not in notes: errors.append(f'rows: {row}: the note to rewrite is missing')
    byid[row]['v16'] = [new if v == old else v for v in notes]
done.append(f'rows.json: {n_ev} evidence entries added, {n_mv} moved off base rows, since changed on {n_since} rows, standardRef on {n_sref} rows, mergeNeeded cleared on {len(D["clearMergeNeeded"])}')

# ---------------------------------------------------------------- 3. check_runs.json and checks.json
CR = rd(os.path.join(C, 'check_runs.json')); n_run = 0
for r in D['runs']:
    r = {k: v for k, v in r.items() if k != 'by'}
    if not any(x.get('script') == r['script'] and x.get('date') == r['date'] and x.get('machine') == r['machine'] for x in CR): CR.append(r); n_run += 1
CK = rd(os.path.join(C, 'checks.json')); n_ck = 0
for u in D['checks']:
    recs = [c for c in CK if c.get('script') == u['script']]
    if len(recs) != 1: errors.append(f'checks: {u["script"]}: {len(recs)} records'); continue
    c = recs[0]
    for k, v in (u.get('set') or {}).items():
        if c.get(k) != v: c[k] = v; n_ck += 1
    for k, v in (u.get('append') or {}).items():
        if not (c.get(k) or '').endswith(v): c[k] = (c.get(k) or '') + v; n_ck += 1
    for a, b in u.get('replace') or []:
        for f in u['fields']:
            if f == 'ids[0].statement': holder, key = c['ids'][0], 'statement'
            else: holder, key = c, f
            if b in holder[key]: continue
            if a in holder[key]: holder[key] = holder[key].replace(a, b); n_ck += 1
            else: errors.append(f'checks: {u["script"]} {f}: the fragment to replace is missing')
done.append(f'check_runs.json: {n_run} runs added ({len(CR)} in all); checks.json: {n_ck} fields written')

# ---------------------------------------------------------------- 4. leads.json
L = rd(os.path.join(C, 'leads.json'))
norm = lambda s: re.sub(r'\s+', ' ', s.replace('’', "'").replace('“', '"').replace('”', '"')).strip()
L2 = D['leads']
if len(L['edits']) != len(L2['dispositions']): errors.append(f'leads: {len(L["edits"])} edits, {len(L2["dispositions"])} dispositions')
bodies_new = {row.rstrip('bcdefgh'): b['new'] for row, b in D['bodies'].items()}
for e, dd, rows in zip(L['edits'], L2['dispositions'], L2['expectRows']):
    if e['rows'] != rows: errors.append(f'leads: edit {dd["index"]} names {e["rows"]}, expected {rows}')
    e['disposition'], e['ledgerEntry'] = dd['disposition'], dd['ledgerEntry']
for i, row in L2['appliedCheck'].items():
    prop = L['edits'][int(i)].get('proposed') or ''
    prop = re.sub(r'^\[[a-z,]+\] (line|theorem|reading)?:? ?', '', prop).strip(' "“”')
    prop = re.sub(r'\s*(\.\.\.|…)$', '', re.sub(r'^(\.\.\.|…)\s*', '', prop))
    if prop and norm(prop) not in norm(bodies_new.get(row, '')): errors.append(f'leads: edit {i} is marked applied but its text is not in the final body of {row}')
L['mergeNeeded'] = L2['mergeNeeded']; L['coordinatorNotes'] = L2['coordinatorNotes']
for lead in L['leads']:
    o = L2['outcome'].get(lead['id'])
    if o and lead['outcome'] == o[0]: lead['outcome'] = o[1]
    elif o and lead['outcome'] != o[1]: errors.append(f'leads: outcome of {lead["id"]} is neither today\'s nor the ledger\'s')
done.append(f'leads.json: {len(L["edits"])} edits with a disposition; mergeNeeded []; coordinatorNotes {len(L["coordinatorNotes"])}')

# ---------------------------------------------------------------- 5. README.md and run_all.sh of checks/selfcheck/gravity/
def section(title):
    i = LEDGER.index(title); j = LEDGER.find('\n### ', i + 1)
    return LEDGER[i:j if j > 0 else None]
d1 = [l for l in section('### D1.').splitlines() if l.startswith('| ') and not l.startswith('| Step') and not l.startswith('|---')]
d1_by_script = {re.search(r'`([^`]+\.py)`', l.split('|')[2]).group(1): l for l in d1}
d3 = section('### D3.')
quotes = [l[2:] for l in d3.splitlines() if l.startswith('> ')]
if len(quotes) != 3: errors.append(f'README: D3 has {len(quotes)} paragraphs, expected 3')
RM_P = os.path.join(G, 'README.md'); RM = open(RM_P, encoding='utf-8').read()
lines = RM.split('\n')
def row_index(script):
    for i, l in enumerate(lines):
        if l.startswith('| ') and len(l.split('|')) > 3 and l.split('|')[2].strip() == f'`{script}`': return i
    return None
n_rm = 0
order = list(D['readme']['after'].items())
for _ in range(3):                                             # rows placed after rows of this batch need their anchor first
    for script, after in order:
        if row_index(script) is not None: continue
        a = row_index(after)
        if a is None: continue
        lines.insert(a + 1, d1_by_script[script]); n_rm += 1
missing = [s for s, _ in order if row_index(s) is None]
if missing: errors.append(f'README: rows not placed: {missing}')
for script, (ok, sec) in D['readme']['patched'].items():
    i = row_index(script)
    if i is None: errors.append(f'README: no row for {script}'); continue
    cells = lines[i].split('|')                                # ['', step, script, what, std, rows, exit, ok, fail, s, '']
    if cells[7].strip() != str(ok) or cells[9].strip() != str(sec):
        cells[7], cells[9] = f' {ok} ', f' {sec} '; lines[i] = '|'.join(cells); n_rm += 1
RM2 = '\n'.join(lines)
old_rt, new_rt = D['readme']['runtime']
if new_rt not in RM2:
    if old_rt in RM2: RM2 = RM2.replace(old_rt, new_rt); n_rm += 1
    else: errors.append('README: the wall-time sentence is missing')
old_s = D['readme']['oldSentence']; new_s = quotes[2] if len(quotes) == 3 else None
if new_s and new_s not in RM2:
    if old_s in RM2: RM2 = RM2.replace(old_s, new_s); n_rm += 1
    else: errors.append('README: the sentence of the engine-faults section is missing')
if len(quotes) == 3 and quotes[0] not in RM2:
    h = D['readme']['beforeHeading']; k = RM2.index(h)
    RM2 = RM2[:k] + quotes[0] + '\n\n' + quotes[1] + '\n\n' + RM2[k:]; n_rm += 1
RA_P = os.path.join(G, 'run_all.sh'); RA = open(RA_P, encoding='utf-8').read(); n_ra = 0
ra_lines = RA.split('\n')
def ra_index(name):
    for i, l in enumerate(ra_lines):
        if l.strip() == f'"{name}|{name}.py"': return i
    return None
for _ in range(3):
    for script, after in D['run_all']['after'].items():
        n, a = script[:-3], after[:-3]
        if ra_index(n) is not None: continue
        j = ra_index(a)
        if j is None: continue
        ra_lines.insert(j + 1, f'  "{n}|{script}"'); n_ra += 1
if any(ra_index(s[:-3]) is None for s in D['run_all']['after']): errors.append('run_all.sh: rows not placed')
done.append(f'README.md: {n_rm} edits (rows {len(d1)} in D1); run_all.sh: {n_ra} rows added')

# ---------------------------------------------------------------- write
if errors:
    print('apply_b3: NOT applied:'); [print('  ' + e) for e in errors]; sys.exit(1)
if not CHECK_ONLY:
    wr(os.path.join(C, 'texts.json'), T); wr(RT_P, RT); wr(os.path.join(C, 'rows.json'), R); wr(os.path.join(C, 'check_runs.json'), CR)
    wr(os.path.join(C, 'checks.json'), CK); wr(os.path.join(C, 'leads.json'), L)
    open(RM_P, 'w', encoding='utf-8').write(RM2); open(RA_P, 'w', encoding='utf-8').write('\n'.join(ra_lines))
print(('apply_b3 (check only, nothing written):' if CHECK_ONLY else 'apply_b3: applied:')); [print('  ' + x) for x in done]
