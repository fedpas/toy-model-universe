# Batch 3, script side B (SCR-B): the six scripts after the audits

Copy: `$SP/v3_agents/scr-b/one-rule`; scripts in `checks/selfcheck/gravity/`. Every run was made from `checks/` as `B3_ADDENDUM.md` §1 gives it (`python3 -I -B`, `ulimit -v 3000000`, `timeout 900`, `nice -n 10`, `OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1`, one run at a time). The logs that ran are `checks/selfcheck/gravity/logs/<script>.log` of this copy. "Before" means the leads' shipped log and script (byte-identical in V2 and in `$SP/leads3/_review/pkg/selfcheck/gravity/`).

To merge from this copy: the six scripts and six logs of §1, and this file. `docs/round7/batch3/scratch_SCR-B/` is working scratch (notes, run status, the comparison tool `ast_same.py`): not for merging.

## 0. At a glance

| script (step) | findings acted on in the script | what changed | ok before → after | FAIL | last line | mutation table |
|---|---|---|---|---|---|---|
| `g2_forque_observers.py` (G2-observers) | AUD-B-2 (S1); AUD-B-11, AUD-B-14 (S3); one item of mine | docstring; 2 check messages (6 log lines) | 207 → 207 | 0 | `FAILS (G2-observers): none` | unchanged: text-only edit |
| `b3c4_dirac_frw.py` (B3C4-dirac) | AUD-B-1 (S1); AUD-B-3 (S2) | docstring; one comment; one heading | 31 → 31 | 0 | `FAILS (B3C4-dirac): none` | unchanged: text-only edit |
| `e2s4_belinfante.py` (E2S4-belinfante) | AUD-B-7 (S3); AUD-B-15h, AUD-B-15a (S4) | docstring; 2 headings; 3 check messages (9 log lines) | 67 → 67 | 0 | `FAILS (E2S4-belinfante): none` | unchanged: text-only edit |
| `e2s4_hehl_datta.py` (E2S4-HD) | AUD-B-15a (S4) | docstring; one heading | 52 → 52 | 0 | `FAILS (E2S4-HD): none` | unchanged: text-only edit |
| `g1_force_line.py` (G1-force) | AUD-C-5 (S3) | docstring | 138 → 138 | 0 | `FAILS (G1-force): none` | unchanged: text-only edit |
| `g1_forced_top.py` (G1-forced) | AUD-C-3 (S3); AUD-C-11 (S4); AUD-C-1 (S2) in the docstring only, the check untouched | docstring; function docstring; 2 headings | 88 → 88 | 0 | `FAILS (G1-forced): none` | unchanged: text-only edit |
| `d_probe.py` (D-PROBE) | none is mine (SCR-A's) | nothing | | | | |

- Exit code 0 for all six. Tag splits ([bit] / [std] / [bit==std] / [ctl]) as before: G2-observers 93/12/66/36, B3C4-dirac 18/2/6/5, E2S4-belinfante 32/10/9/16, E2S4-HD 28/6/3/15, G1-force 50/10/51/27, G1-forced 33/7/26/22.
- No printed line was added or removed: the logs keep their line counts (311, 61, 82, 67, 157, 123), so every log line number the audits and the draft ledger cite still points to the same line.
- Code identical apart from text, checked mechanically for all six: `scratch_SCR-B/ast_same.py` parses the script before and after, blanks every string constant and the message arguments of `chk`, `head` and `print`, and compares the two trees (tags, check conditions, control flow, arithmetic): SAME for all six. Its control, one comparison `>` turned into `>=` in a check condition, is reported as DIFFERENT.
- `node $SP/leads/tools/scan_words.mjs` on the six edited scripts: no hits.

## 1. Per script: lines (of the edited file), finding, reason, log diff

Every log diff below is against the leads' log; apart from the lines named, the only lines that differ are the timing lines (`(…: N s)`, `[time] …`, `TOTAL …`). All printed numbers (fits, residuals, roots, polynomials, counts) are identical.

### 1.1 `g2_forque_observers.py`

- **Docstring, lines 28–37** (AUD-B-2, AUD-B-11, AUD-B-14). The sentence "the second and third derivatives carry terms beyond first order in M for every observer" is replaced by: "the second and third derivatives are not Phi's derivatives for any radial observer run, and where the lam run separates their orders in M (Kerr-Schild, static, free fall) they carry terms of order M^2 and higher (listed as exact fits … from the lam run); for the geodesic momentarily at rest and the wrong-sign control no lam run is made and the orders in M are not separated". Reason: the lam bookkeeping runs only for `LAMRUN = ('ks', 'a', 'b', 'd')` (script line 64); the table (log 303–308) prints "not separated" for the other two; AUD-B-2 shows by scaling that for the geodesic at rest the departures are of order M and M^0, so "beyond first order in M" does not hold for that observer.
  The two readings: "agree on the spatial components at first order and differ beyond" becomes "at the Kerr-Schild observer the two readings … agree on the spatial components at the first derivative and, at the second and third, through order M^2, and differ from order M^3 on" (log 121, 126, 269: reading 2 is computed for the Kerr-Schild observer only; lam-degrees 6 and 8 differ, not below).
  The bodies: "The bodies of G2 (16) … the force at eps^3 and the eps^4 terms miss the lines for every observer" becomes "G2's bodies (8 at each point: 3 random, 5 centrally symmetric) … for the radial observers the force at eps^2 and the torque at eps^3 are Ecal(u) times the summed force lines' …; on the 3 random bodies the force at eps^3 and the eps^4 terms miss the lines for every radial observer (the centrally symmetric bodies have no force or torque at eps^3, in the lines and in the contraction); for the transverse boost the torque at eps^2 misses the lines already" (log 139–158, 279–298).
- **Check message, lines 399–400** (AUD-B-2; keys 'c' and 'w'). The `chk` on "nabla nabla E' and nabla^3 E' are not Phi's derivatives" keeps its condition; its tail "terms beyond first order in M" is printed only for the observers of `LAMRUN`; for the geodesic momentarily at rest and the wrong-sign control it reads "the orders in M are not separated for this observer (no lam run)". Log lines changed: 84, 112, 232, 260. The lines of the Kerr-Schild, static and free-falling observers (20, 39, 64, 177, 196, 214) are unchanged: their lam run (the lam^2 part is Phi's, no lam^0 or lam^1 part) supports the tail.
- **Check message, line 542** (mine, not an audit finding). The transverse-boost line said "…misses the summed lines (3 random bodies), and so do the higher orders", which its condition does not test order by order. It now prints what the condition computes: "…misses the summed lines (3 random bodies); neither the coordinate derivatives (eps^2..eps^4) nor Ecal times the lines' with nabla E' (force at eps^2, torque at eps^3) hold for all 8 bodies". Log lines changed: 154, 294.
- Run: rc 0, 195 s wall, 207 ok, 0 FAIL; log diff: exactly the 6 lines named (84, 112, 154, 232, 260, 294).

### 1.2 `b3c4_dirac_frw.py`

- **Docstring, lines 18–19** (AUD-B-1, S1): "(so a^3 S and a^6 rho_c are separately constant exactly when m P s^0 = 0: the rest class psi commuting with gamma_0, or m = 0)" replaced by the audit's text: "(so a^3 S is constant where P s^0 = 0, as on the rest class psi commuting with gamma_0, and a^6 rho_c where m P s^0 = 0; at m = 0 a^3 S is not constant)". Log line 57 agrees ("m = 0: a^6 rho_c constant through t^6 …; a^3 S is not constant (S still rotates into P), which is harmless as m S = 0"), as do lines 16–17 (generic data: both rates non-zero, c2 = −c1) and 54 (rest class: P = s^0 = 0, both constant).
- **Docstring Scope, lines 28–34** (AUD-B-3, S2): it now opens "one time t0 = 0, one generic data set (kappa = 1, m = 7/4, a = 1 and H = 1/2 at t = 0) plus one spinor at rest and one with m = 0, every solve at kappa = 1 (so the powers of kappa in rho_c and in the rates are not separated; the power of kappa of the contact term is fixed by e2s4_hehl_datta.py at three values of kappa)". The rest of the Scope is unchanged (reflowed). Code line 193 (`kap, m = F(1), F(7, 4)`) is the only kappa of the run.
- **Comment, line 316** (AUD-B-1, the same error in a comment): "4. the rest class and the massless spinor: both parts conserved separately" becomes "4. the rest class (a^3 S and a^6 rho_c both constant) and the massless spinor (a^6 rho_c constant, a^3 S not)".
- **Heading, line 208** (AUD-B-3): the part-1 heading, which already printed the data set and "kappa = 1", ends with "(one data set; every solve of this run has kappa = 1, so the powers of kappa are not separated)". Log line changed: 2.
- Run: rc 0, 44 s wall (TOTAL 42.8 s), 31 ok, 0 FAIL; log diff: line 2 only.

### 1.3 `e2s4_belinfante.py`

- **Docstring, lines 17–18** (AUD-B-7, the factor-2 convention): "on the Dirac shell tau^LC is symmetric while the canonical tau keeps tau_[ab] = (1/2)(D S)_ab" becomes "on the torsion-free Dirac shell (EL(omega_LC) = 0) tau^LC is symmetric while the canonical tau keeps tau_ab - tau_ba = (D S)_ab, i.e. tau_[ab] = (1/2)(D S)_ab (Rosenfeld)". The check (script line 282: `tl[a][b] - tl[b][a] == DSm[a][b]`) compares the difference.
- **Check message, line 283** (AUD-B-7): "on shell the canonical tau_[ab] = (1/2)(D S)_ab, non-zero (Rosenfeld: the antisymmetric part of the canonical stress is the spin divergence)" becomes "on shell the canonical tau_ab - tau_ba = (D S)_ab, i.e. tau_[ab] = (1/2)(D S)_ab, non-zero (Rosenfeld: the difference tau_ab - tau_ba is the spin divergence)". Log lines 57, 65, 73.
- **Heading, line 272** (AUD-B-7): "(2) on the Dirac shell (…): …, the canonical one keeps (1/2) D S (Rosenfeld)" becomes "(2) on the torsion-free Dirac shell (…): …, the canonical one keeps tau_ab - tau_ba = (D S)_ab (Rosenfeld)". Log line 54.
- **Check messages, lines 253 and 284** (AUD-B-15h): the printed value is `mmax(asym(·))`, half the difference; the label "max |tau^LC_ab - tau^LC_ba| =" and "max |tau_ab - tau_ba| =" now read "… / 2 =". The values are unchanged (30.58, 40.76, 28.67; 8.931, 22.49, 20.57). Log lines 12, 27, 42; 58, 66, 74.
- **Docstring lines 9–10 and 25–26, heading line 223** (AUD-B-15a): "strong random polynomials" / "3 strong random configurations" / "[strong fields, …]" become "random polynomials for e and psi (e2s4_dirac_stress.strong_fields: every monomial to x-degree 2, integers in [-9, 9]; no failure bound)", "3 random polynomial configurations with first-order jets (no failure bound)" and "[random polynomial fields, every monomial to x-degree 2, 3 seeds]". Reason: in this batch "strong" names the samplers with a failure bound (A5-strong, A6-strong); these fields have none. Log line 2.
- Run: rc 0, 101 s wall (TOTAL 100.0 s), 67 ok, 0 FAIL; log diff: lines 2, 12, 27, 42, 54, 57, 58, 65, 66, 73, 74 only.

### 1.4 `e2s4_hehl_datta.py`

- **Docstring lines 8–11 and 25–26, heading line 135** (AUD-B-15a): as in 1.3, "the strong random fields of E2S4" / "3 strong random configurations" / "[strong random e, psi; …]" become "the random polynomial fields of E2S4 (e2s4_dirac_stress.strong_fields: every monomial to x-degree 2, integers in [-9, 9]; no failure bound)", "3 random polynomial configurations with first-order jets (no failure bound)" and "[random polynomial e, psi; …]". Log line 2.
- AUD-B-13 and AUD-B-4 need nothing here: docstring item (3) already says "the cubic coefficient of the equation is twice the contact coefficient of the action", and log lines 9, 19, 29 print the contact term −(3/16) kappa^2 (s.s) vol at kappa = 4, 1, 9/5.
- Run: rc 0, 20 s wall (TOTAL 19.1 s), 52 ok, 0 FAIL; log diff: line 2 only.

### 1.5 `g1_force_line.py`

- **Docstring, lines 17–19** (AUD-C-5): "one sign c for all laws and bodies" becomes "one sign c = +1 for every law and body run (three bodies of 2 to 4 random points per curved kappa, the wrong power included)" (log 35–93: elliptic bodies of 2, 4, 2 points, hyperbolic 2, 3, 2, four laws each; Euclid reads (f, q x f) instead).
- AUD-C-4 needs nothing here: log 106 says the second anchor "balances too", which is what this script shows; its instability is G1-forced's (log 81–86 there), and that script's docstring says so.
- Run: rc 0, 0 s wall (TOTAL 0.3 s), 138 ok, 0 FAIL; log diff: timing lines only. (Re-run although no printed line changed, by decision 6 of `COMMON_B3.md`; it costs a second.)

### 1.6 `g1_forced_top.py`

- **Function docstring of `stable_from_roots`, lines 261–263** (AUD-C-3): "all l^2 real and <= 0 (one zero allowed): the linearised motion is bounded; any l^2 > 0 or complex: unstable" becomes "the spectral verdict on the numpy roots of the exact polynomial (|Im| and Re against tol): every l^2 real and <= 0, zero roots allowed: linearly stable (at the hung states the one zero is the free turn about the vertical line, along which the linearised motion is a uniform turn, not bounded); any l^2 > 0 or complex: linearly unstable".
- **Module docstring** (AUD-C-3, AUD-C-11): title line 5 "the stability of the hung body" → "the linear stability of the hung body"; lines 18–20 add "the roots l^2 (numpy roots of the exact polynomial) are reported, and the verdict is spectral: linearly stable when every l^2 is real and <= 0 (one zero: the free turn about the vertical line), linearly unstable when some l^2 > 0 or is complex. One cube-like body of 8 points per kappa."; line 22 "… are unstable" → "… are linearly unstable".
- **Module docstring, lines 11–12** (AUD-C-1, wording only): "the energy … is constant" → "the energy … is constant through t^(N-1) (the check stops one order below the flow)". The check itself (script line 290, `E[1:N]`, printed "through t^5") is untouched, as decision 2 of `COMMON_B3.md` requires.
- **Headings, lines 269 and 337** (AUD-C-3, AUD-C-11): "…, and the stability of the hung body (series through t^6)" → "…, and the linear stability of the hung body (series through t^6)"; "(2) stability of the hung cube: …; roots l^2" → "(2) linear stability of the hung cube (one cube-like body of 8 points per kappa): …; roots l^2 (numpy roots of the exact polynomial)". The verdict messages already said "linearly stable" / "linearly unstable" and are unchanged. Log lines 2 and 67.
- Run: rc 0, 19 s wall (TOTAL 18.7 s), 88 ok, 0 FAIL; log diff: lines 2 and 67 only.

## 2. The runs, for `content/check_runs.json` (`B3_ADDENDUM.md` §3.3)

All six: `date` 2026-10-12 (the day of the runs), `machine` "the round-7 closing, run from checks/", `passed` true, `fail` 0, `source` `checks/selfcheck/gravity/logs/<script>.log`.

| script | ok | lastLine | wall s | sha256 of the log |
|---|---|---|---|---|
| `checks/selfcheck/gravity/g2_forque_observers.py` | 207 | `FAILS (G2-observers): none` | 195 | `0f0c2432ab5dcd75d1c7c2adef2234407b40c6f9b18eb877557a3517234c5b74` |
| `checks/selfcheck/gravity/b3c4_dirac_frw.py` | 31 | `FAILS (B3C4-dirac): none` | 44 | `c51ea84658ff8e11ba7a76741910a667526ef3d8f9e042fcbffe1dd5fc4ac2dc` |
| `checks/selfcheck/gravity/e2s4_belinfante.py` | 67 | `FAILS (E2S4-belinfante): none` | 101 | `e78a175b10f75b944b23872fbdbad791d74e446323553f70f12eeccecef732c8` |
| `checks/selfcheck/gravity/e2s4_hehl_datta.py` | 52 | `FAILS (E2S4-HD): none` | 20 | `52c601d8ccb38252dc2bba07fa975656d6d0b6f83280ecef8a655761f3a77b34` |
| `checks/selfcheck/gravity/g1_force_line.py` | 138 | `FAILS (G1-force): none` | 0 | `72f5b956a5a13b0b9159a85f2c69c70d79fb82c598823d8b865fe1dd376a4927` |
| `checks/selfcheck/gravity/g1_forced_top.py` | 88 | `FAILS (G1-forced): none` | 19 | `372af1bd057b018c8e3cb7a6f05d5a5567c484ae7d660685bba6972e0c253c04` |

sha256 of the scripts as they ran (for the MANIFEST step of D4): `g2_forque_observers.py` `3f01298b460343a98e2b0a1806642f18647cec06d5f8a35ecd414533e6e38c65`, `b3c4_dirac_frw.py` `800be3fa7fbe9f1615016e7e3e168945c59d67e1c831b908057e24d857d44b7b`, `e2s4_belinfante.py` `b08ae6bf74a6885220cd77df1c58026179c1758711f395d0ad69bca635163493`, `e2s4_hehl_datta.py` `176d2eb992d0ed239cb77874a444660dd728fcb466ec8194c62ed6e667310604`, `g1_force_line.py` `82ea015c5aae2e8cb4e7b613603c83b605c72bd44d2cb0be8ae955047bad08df`, `g1_forced_top.py` `88c94b6b3221fb787500cd9fbd7e358ccd25efbcd00deb4ca799d2aca82fac08`.

`content/checks.json` (`ids`, `what`): no check id changes; the G2-observers `what` needs the fragment patch of §4 (a).

## 3. Mutation tables

Not re-run: every edit is text (§0, the tree comparison), so no check line was added, removed or changed in what it compares, and the leads' tables stand. Valid tables: `$SP/leads3/L10b/mut/g2_forque_observers.mut.log` (run with `1`), `L9bB/mut/b3c4_dirac_frw.mut.log`, `L9bA/mut/e2s4_belinfante.mut.log` (merged from `_a` and `_b`), `L9bA/mut/e2s4_hehl_datta.mut.log`, `L14/mut/g1_force_line.mut.log`, `L14/mut/g1_forced_top.mut.log` (and their `.json`); they equal `$SP/leads3/_review/mut/` cell for cell:

| step | M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 |
|---|---|---|---|---|---|---|---|---|
| G2-observers (first point) | 30 | 0 | 7 | 23 | 7 | 25 | 18 | 7 |
| B3C4-dirac | 14 | 12 | 0 | 4 | 0 | 12 | 0 | 0 |
| E2S4-belinfante | 0 | 0 | 6 | 12 | 6 | 4 | 6 | 6 |
| E2S4-HD | 4 | 0 | 3 | 3 | 3 | 4 | 3 | 3 |
| G1-force | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| G1-forced | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

I did not copy them into `checks/selfcheck/gravity/mut/` (V2 carries none for these scripts; the brief says keep). If the lead copies them into the package: the M6 `first:` line of `L9bA/mut/e2s4_belinfante.mut.log` (line 18; also in `e2s4_belinfante_b.mut.log` and in the `first` lists of both `.json`) quotes the Rosenfeld message as it read before §1.3; the cells are not affected. No other `first:` line quotes an edited message.

## 4. What LED's texts must quote

### (a) `content/checks.json`, entry `selfcheck/gravity/g2_forque_observers.py`
In `what` and in `ids[0].statement`, replace the fragment
`terms beyond first order in M listed as exact fits per observer`
with
`terms of order M^2 and higher listed as exact fits where the orders in M are separated (Kerr-Schild, static, free fall; not separated for the geodesic momentarily at rest and the wrong-sign control)`.
The same fragment, and the three checkedBy texts of (b), are in `content/wave3_ship_notes.json`, the migration record of the leads' SHIP_NOTES: `npm run migrate` (`tools/migrate/run_all.sh`) writes it with `checks_from_v15.py` and `leads_v16.py` copies its checkedBy texts into the evidence of `rows.json`; `npm run content`, `build.sh` and the tests do not read it. It has no owner in `PLAN.md` §3, so it is the lead's call; a re-run of the migration after LED's apply step would bring the leads' wording back into `rows.json`.

### (b) `content/rows.json` evidence texts of G2-observers (the ledger's checkedBy)
- EQN-019: AUD-B-2's text, `g2_forque_observers.py (the covariant derivatives of the tidal tensor for five observers: for the radial ones the first-order factor is the observer's energy, the free fall from rest at infinity has factor 1; the higher orders keep M^2 terms for the Kerr-Schild, static and free-falling observers; the transverse boost changes the tidal tensor)`.
- LAB-006: AUD-B-2's text, `g2_forque_observers.py (tidal tensor and its covariant derivatives for the static, free-falling, momentarily-at-rest and transversely boosted observers: first-order factor g(u, d_t) for the radial ones; M^2 terms beyond where the orders in M are separated)`.
- RIG-002 (today "… the eps^3 force and eps^4 terms are not, for every observer"; AUD-B-14 gives the sentence, not this text): to match the check lines (log 139, 144, 148, 152, 157), `g2_forque_observers.py (the eps^2 force and eps^3 torque with the free-falling observer's covariant derivative are exact; on the three random bodies the eps^3 force and eps^4 terms are not, for every radial observer)`.

### (c) README D1 rows (numbers from §2; the "s" column is the build's)
- **G2-observers**: 0; `FAILS (G2-observers): none` | 207 | 0. In "What it checks", replace "the second and third keep M^2 terms for every observer" with "the second and third are not Phi's derivatives for any radial observer and keep M^2 terms for the Kerr-Schild, static and free-falling observers (orders not separated for the geodesic momentarily at rest)". This is AUD-B-2's text with "radial" added: the check line runs on the five radial observer fields, and the transverse boost already changes E'. Replace "the two readings of the covariant derivative agree at first order" with "at the Kerr-Schild observer the two readings of the covariant derivative agree at the first derivative and differ from order M^3 on" (AUD-B-11; log 121, 126, 269).
- **B3C4-dirac**: 0; `FAILS (B3C4-dirac): none` | 31 | 0. AUD-B found the row right; to carry AUD-B-3's limit as the docstring now does, write "(k = 0, homogeneous spinor; one generic data set, a spinor at rest and a massless one, all at kappa = 1)" in place of "(k = 0, homogeneous spinor)".
- **E2S4-belinfante**: 0; `FAILS (E2S4-belinfante): none` | 67 | 0. AUD-B-7's text is what the log prints after §1.3: "off shell tau^LC_ab - tau^LC_ba = (1/2)(B_ab psi).EL / vol; on the torsion-free Dirac shell the Hilbert stress is symmetric and the canonical tau_ab - tau_ba = (D S)_ab (Rosenfeld)".
- **E2S4-HD**: 0; `FAILS (E2S4-HD): none` | 52 | 0. Cell unchanged.
- **G1-force**: 0; `FAILS (G1-force): none` | 138 | 0. Optional, as the docstring now reads: "(sign +1)" → "(sign +1 on every law and body run)".
- **G1-forced**: 0; `FAILS (G1-forced): none` | 88 | 0. AUD-C-3 with AUD-C-11: "the hung vertex is stable and the complement unstable at kappa = +1, 0, -1" → "the hung vertex is linearly stable (all l^2 <= 0, one zero: the turn about the vertical) and the complement unstable, one cube-like body of 8 points per kappa = +1, 0, -1". Keep "(energy through t^5)": the check is unchanged.
- **D3 paragraph** (AUD-C-14, AUD-D-3): the facts hold. `g1_force_line.py` and `g1_forced_top.py` import `b1lib` for `head`, `chk`, `finish` only and build no object of the gravity engine (no `Lie`, `Grav`, `Forms` or `gs` in them or in `g1_clkappa.py`; they run on `forque_selfcheck`); all eight cells of their tables are 0; both parse `--fault` (FK, FS, FP; G1-forced also FC). So "G1, G1-force, G1-forced, …" and "(G1, G1-force, G1-forced, G4 and L2 also take `--fault`)" are right.

## 5. Sentence parts left to LED
The script part of each finding is done as in §1; their sentence parts are LED's and need no further script change: AUD-B-1 (GRV-011 piece 2b), AUD-B-2 (EQN-019, LAB-006, their checkedBy, README), AUD-B-3 (GRV-011), AUD-B-4 (INP-050 and its checkedBy; the power of kappa is in `e2s4_hehl_datta.log` 9, 19, 29), AUD-B-5 and AUD-B-15c (`b3c4_curved_points.py`, SCR-A's script), AUD-B-6, -8, -9, -10, -11, -12, -13, -14, AUD-B-15a, b, d, e, f, g, i; AUD-C-1 (PRJ-005: "the energy being constant through t⁵"), AUD-C-2 to AUD-C-13 (PRJ-004, PRJ-005, FRQ-005, RIG-002, RIG-003, standardRef), AUD-C-14 (D3). AUD-B-12 needs no script change: the script's observer names are already distinct ("Kerr-Schild observer (identity boost)", "geodesic momentarily at rest in the Kerr-Schild frame").

## 6. Declined or not done
1. AUD-C-1's script alternative (check `E[1:N + 1]`): declined by decision 2 of `COMMON_B3.md`; the energy check still covers t^1 to t^5 and only the docstring states that order (§1.6).
2. Mutation re-runs: not made (§3).
3. The leads' own `RESULT.md` and `SHIP_NOTES.md` (AUD-B-1: L9bB `SHIP_NOTES.md` line 16; AUD-B-2: L10b's "In one sentence"; AUD-C-1: L14 `RESULT.md` line 79; AUD-C-15): not in V2 and read-only; in V2 their wording survives in the content records of §4 (a), (b) and in the leads' proposals of `content/leads.json` (`edits`), which LED's final ledger decides.
4. Copies to the lead's folder and to `$SP/leads3/_review/runs/`: not made (read-only under `B3_ADDENDUM.md` §1); the record is the log in this copy and LED's run entry.
5. `d_probe.py`: no finding of mine.
