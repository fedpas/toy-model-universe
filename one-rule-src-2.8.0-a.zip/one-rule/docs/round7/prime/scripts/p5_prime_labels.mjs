#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P5. Prime numbers among the integer labels (the gold borders of the Maxwell page).   node p5_prime_labels.mjs

 Question: does "the integer label N is a prime number" carry anything about the blade e_N beyond "N is odd" (switch 0 on)?
 [bit] for n = 2..8 and every signature Cl(p,q), p + q = n, the invariants of e_N from labelsEngine.js: grade, square sign, central,
       anticommuting with every generator, and the clock position clockOf(p_N, q_N) and type of the sub-cell of its switches.
 [std] primality by trial division; two exact nulls: (A) every relabelling of the switches that keeps switch 0 ((n−1)! of them, all
       enumerated): where do the images of the odd primes fall; (B) the hypergeometric law of a random set of odd labels of the same size
       (exact BigInt binomials). Two-sided p-values for every (n, signature, invariant, value); the count of tests and a Bonferroni bound.
 [ctl] a planted set (odd labels chosen by square −1) must be flagged far below the Bonferroni bound; the Maxwell data's prime_labels
       must equal the trial-division list.
 Result shape: nothing beyond switch 0 and the grade (null A); the grade itself is not like that of random odd labels (null B), an effect of
 base 2 (at n = 8 every odd label with six switches on is divisible by 3, 5 or 17); the top label 2^n − 1 is prime for n = 2, 3, 5, 7. */
import { head, chk, note, finish, loadEngine, loadData, isPrimeTD, binom, permutations } from './plib.mjs';
const { bladeMul, sigVec, popcount, clockOf, wedderburn } = await loadEngine();
const MAX = await loadData('maxwellData.js');
const ID = 'PRIME-P5';

function hyperP(M, K, d, x) {   // two-sided: 2·min(P(X<=x), P(X>=x)), X ~ Hypergeometric(M, K, d), exact
  const den = binom(M, d); let lo = 0n, hi = 0n;
  for (let k = 0; k <= Math.min(K, d); k++) { const t = binom(K, k) * binom(M - K, d - k); if (k <= x) lo += t; if (k >= x) hi += t; }
  const f = v => Number((v * 1000000000000n) / den) / 1e12; return Math.min(1, 2 * Math.min(f(lo), f(hi)));
}
function invariants(n, sq) {   // per label N: {grade, sq, central, anti, clock, type}
  const out = [];
  for (let N = 0; N < (1 << n); N++) {
    let central = true, anti = true; for (let i = 0; i < n; i++) { const a = bladeMul(1 << i, N, sq)[1], b = bladeMul(N, 1 << i, sq)[1]; if (a !== b) central = false; if (a !== -b) anti = false; }
    let pN = 0, qN = 0; for (let i = 0; i < n; i++) if ((N >> i) & 1) { if (sq[i] > 0) pN++; else qN++; }
    out.push({ grade: popcount(N), square: bladeMul(N, N, sq)[1], central, anti, clock: clockOf(pN, qN), type: N ? wedderburn(pN, qN).type : 'scalar' });
  }
  return out;
}
const FEATS = ['grade', 'square', 'central', 'anti', 'clock', 'type'];
let tests = 0, minA = 1, minB = 1, sigA = 0, sigB = 0, worst = '';
const allTests = [];
head('P5a. Every n = 2..8, every signature: invariants of the prime labels against the two nulls');
for (let n = 2; n <= 8; n++) {
  const L = 1 << n, odd = [...Array(L).keys()].filter(N => N % 2 === 1), oddPrimes = odd.filter(isPrimeTD);
  const perms = [...permutations([...Array(n - 1).keys()].map(x => x + 1))].map(p => [0, ...p]);       // relabellings keeping switch 0
  const img = (N, pi) => { let m = 0; for (let a = 0; a < n; a++) if ((N >> a) & 1) m |= 1 << pi[a]; return m; };
  const imgs = perms.map(pi => oddPrimes.map(N => img(N, pi)));
  for (let p = 0; p <= n; p++) {
    const q = n - p, inv = invariants(n, sigVec(p, q));
    for (const f of FEATS) {
      const vals = [...new Set(odd.map(N => String(inv[N][f])))];
      if (vals.length < 2) continue;
      for (const v of vals) {
        const obs = oddPrimes.filter(N => String(inv[N][f]) === v).length, K = odd.filter(N => String(inv[N][f]) === v).length;
        const cs = imgs.map(S => S.filter(N => String(inv[N][f]) === v).length), mean = cs.reduce((s, x) => s + x, 0) / cs.length;
        const pA = cs.filter(c => Math.abs(c - mean) >= Math.abs(obs - mean) - 1e-12).length / cs.length;
        const pB = hyperP(odd.length, K, oddPrimes.length, obs);
        const byGrade = new Map(); let gdet = true; for (const N of odd) { const g = inv[N].grade, val = String(inv[N][f]); if (byGrade.has(g) && byGrade.get(g) !== val) gdet = false; byGrade.set(g, val); }
        tests++; allTests.push([n, p, q, f, v, obs, K, pA, pB, gdet]);
        if (pA < minA) minA = pA; if (pB < minB) { minB = pB; worst = `n=${n} Cl(${p},${q}) ${f}=${v}: ${obs} of ${oddPrimes.length} odd primes, ${K} of ${odd.length} odd labels`; }
        if (pA < 0.05) sigA++; if (pB < 0.05) sigB++;
      }
    }
  }
}
const bonf = 0.05 / tests;
note(`${tests} tests (n, signature, invariant, value); Bonferroni bound 0.05/${tests} = ${bonf.toExponential(2)}`);
note(`null A (relabellings keeping switch 0): ${sigA} tests with p < 0.05 (chance level about ${(0.05 * tests).toFixed(0)}), smallest p = ${minA.toFixed(4)}`);
note(`null B (random odd sets, exact): ${sigB} tests with p < 0.05, smallest p = ${minB.toFixed(4)} (${worst})`);
chk('std', minA >= bonf, `null A: no invariant separates the prime labels beyond what switch 0 and the grade fix (relabellings keep both): smallest p = ${minA.toFixed(4)} ≥ ${bonf.toExponential(2)}`);
const hits = allTests.filter(t => t[8] < bonf);
chk('std', hits.length > 0 && hits.every(t => t[9]), `null B: ${hits.length} tests fall below the Bonferroni bound, and every one is an invariant fixed by the grade in its signature (the grade itself, or clock and type where all switches have one sign)`);
note('below the bound: ' + [...new Set(hits.map(t => `n=${t[0]} ${t[3]}=${t[4]} in Cl(${t[1]},${t[2]}) (${t[5]} primes, ${t[6]} odd labels)`))].slice(0, 12).join('; '));

head('P5b. The grade effect is arithmetic of base 2');
{
  const tab = []; for (let n = 2; n <= 8; n++) { const row = []; for (let g = 1; g <= n; g++) { const odd = [...Array(1 << n).keys()].filter(N => N % 2 && popcount(N) === g); row.push(`${g}:${odd.filter(isPrimeTD).length}/${odd.length}`); } tab.push(`n=${n} [${row.join(' ')}]`); }
  note('odd labels by grade, primes/all: ' + tab.join(' | '));
  const six = [...Array(256).keys()].filter(N => N % 2 && popcount(N) === 6);
  chk('std', six.length === 21 && six.every(N => N % 3 === 0 || N % 5 === 0 || N % 17 === 0) && 255 === 3 * 5 * 17,
    'n = 8: each of the 21 odd labels with six switches on is divisible by 3, 5 or 17, the prime factors of 2^8 − 1 = 255 (N mod 3 counts the bits at even minus odd places, 2 ≡ −1 mod 3); no prime below 256 has six bits on');
}
head('P5c. The one exact coincidence: the top label 2^n − 1');
{
  const mers = []; for (let n = 2; n <= 12; n++) if (isPrimeTD(2 ** n - 1)) mers.push(n);
  const inv11 = invariants(11, sigVec(11, 0)), inv7 = invariants(7, sigVec(7, 0));
  chk('bit==std', JSON.stringify(mers) === '[2,3,5,7]' && inv7[127].central && inv11[2047].central && !isPrimeTD(2047),
    'the top label 2^n − 1 is prime for n = 2, 3, 5, 7 among n ≤ 12 (Mersenne primes); the top blade is central for odd n whether or not its label is prime (n = 11: 2047 = 23·89, central)');
}

head('P5d. Controls and data');
{
  const n = 8, L = 256, sq = sigVec(4, 4), inv = invariants(n, sq), odd = [...Array(L).keys()].filter(N => N % 2), size = odd.filter(isPrimeTD).length;
  const planted = odd.filter(N => inv[N].square === -1).slice(0, size), obs = planted.length, K = odd.filter(N => inv[N].square === -1).length;
  const pB = hyperP(odd.length, K, size, obs);
  chk('ctl', pB < bonf, `a planted set (${size} odd labels, all with square −1, in Cl(4,4)) is flagged: p = ${pB.toExponential(2)} < ${bonf.toExponential(2)}`);
  let dataOk = true; for (const C of Object.values(MAX.cells)) { const want = [...Array(1 << C.n).keys()].filter(isPrimeTD); if (JSON.stringify(want) !== JSON.stringify(C.primes.prime_labels)) dataOk = false; }
  chk('data', dataOk, 'maxwellData.js prime_labels (the gold borders) = the prime numbers below 2^n by trial division, all 15 cells');
}
const top = allTests.sort((a, b) => a[8] - b[8]).slice(0, 3).map(t => `n=${t[0]} Cl(${t[1]},${t[2]}) ${t[3]}=${t[4]}: obs ${t[5]}, pA ${t[7].toFixed(3)}, pB ${t[8].toFixed(4)}`);
note('three smallest null-B p-values: ' + top.join(' | '));
finish(ID);
