#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P7. Six exact readings of "the Monster's 15 primes and the unit as sixteen members", tested on the bit rule.   node p7_monster.mjs

 Inputs [given, not rebuilt]: the 15 primes dividing the order of the Monster, 2 3 5 7 11 13 17 19 23 29 31 41 47 59 71, the exponents
 46 20 9 6 2 3 and 1 for the other nine, and the order itself (the product is multiplied out once as a consistency check).
 (i)   maps from the 15 points of PG(3,2) (the non-empty labels of four switches; lines {a, b, a XOR b} from bladeMul) to the 15 primes:
       an order-free map must be constant on the switch-permutation classes (sizes 4, 6, 4, 1), and no invariant of the primes has classes
       of those sizes; line relations χ(f(a))χ(f(b))χ(f(a XOR b)) = 1 for χ = (−1/·), (2/·), (−2/·) with χ(2) = ±1, and f(a)f(b)f(c) ≡ 1
       mod 8 and mod 24; five explicit maps against 10^5 seeded random bijections; the order-free question "is there a bijection that
       satisfies a relation on all 35 lines" (a count condition) and its exact chance over all 15-subsets of the first 20 primes.
 (ii)  the square-free kernel (the primes with odd exponent) as a label on 15 switches named by the Monster's primes.
 (iii) the sixteenth place: the 16th prime 53, the primorial 53#, Cl(16,0), the rung-16 data; 16 = 15 + 1 labels of four switches.
 (iv)  Lucas/Kummer: the primes dividing some C(n,k), 0 < k < n, for n ≤ 24 and 71 (grade counts from the engine for n ≤ 20), the
       exceptions predicted by base-p digits, and whether the set is ever the Monster's (n ≤ 2000).
 (v)   the departure from the natural order: a table to 113; every single condition and every pair (five Boolean combinations) of a list
       of conditions; which separate the 15 from the 5 skipped primes up to 71; family-wise chance over all 15-subsets of the first 20
       primes (exact) and over 10^5 seeded draws.
 (vi)  the signature from the primes, p ↦ (−1/p), 2 taken both ways: clock and type of the cell for the Monster's 15, the first 15, the
       16 members with the unit, the first 16; engine wedderburn against a recalled table. A construction, not a finding about the Monster.
 [ctl] a planted XOR-respecting map must reach 35 lines and be flagged; a planted separable list must be found by the search; the
       count rule (all 35 lines ⇔ 0 or 8 values −1) is checked by brute force on 4-point models. */
import { head, chk, note, finish, loadEngine, loadData, gcd, firstPrimes, primesUpTo, isPrimeTD, factorTD, binom, ordMod, legendre, rng, shuffle, subsets, randInt } from './plib.mjs';
const { bladeMul, sigVec, popcount, clockOf, wedderburn, ordTwo, MONSTER_PRIMES } = await loadEngine();
const DICT = await loadData('dictionaryData.js');
const ID = 'PRIME-P7';

const M15 = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 41, 47, 59, 71];                                          // given
const EXP = new Map(M15.map(p => [p, { 2: 46, 3: 20, 5: 9, 7: 6, 11: 2, 13: 3 }[p] || 1]));                    // given
const ORDER = 808017424794512875886459904961710757005754368000000000n;                                            // given
const ORD_GIVEN = { 3: 2, 5: 4, 7: 3, 11: 10, 13: 12, 17: 8, 19: 18, 23: 11, 29: 28, 31: 5, 41: 20, 47: 23, 59: 58, 71: 35 };   // given
const F20 = firstPrimes(20);

head('P7.0 Inputs');
{
  let prod = 1n; for (const [p, e] of EXP) prod *= BigInt(p) ** BigInt(e);
  chk('given', prod === ORDER, 'the product of p^e over the 15 primes equals the order as given');
  chk('data', JSON.stringify(MONSTER_PRIMES) === JSON.stringify(M15), 'labelsEngine.js MONSTER_PRIMES is the same list');
  chk('bit==std', M15.slice(1).every(p => ordTwo(p) === ordMod(2, p) && ordMod(2, p) === ORD_GIVEN[p]), 'order of 2 modulo each odd prime: engine ordTwo = direct powers = the given list');
  const skipped = F20.filter(p => !M15.includes(p)), idx = skipped.map(p => F20.indexOf(p) + 1), diffs = M15.map((p, i) => p - F20[i]);
  chk('std', JSON.stringify(skipped) === '[37,43,53,61,67]' && JSON.stringify(idx) === '[12,14,16,18,19]' && JSON.stringify(skipped.map(p => p % 8)) === '[5,3,5,5,3]' && JSON.stringify(diffs) === '[0,0,0,0,0,0,0,0,0,0,0,4,6,16,24]' && F20[15] === 53,
    'up to 71 the list skips the 12th, 14th, 16th, 18th, 19th primes 37, 43, 53, 61, 67 (residues mod 8: 5, 3, 5, 5, 3); position by position it exceeds the first 15 primes by 0 (eleven times), 4, 6, 16, 24');
  chk('std', binom(13, 8) === 1287n && binom(20, 15) === 15504n, `C(13,8)/C(20,15) = 1287/15504 = ${(1287 / 15504).toFixed(4)}`);
}

// ---------------------------------------------------------------- (i)
head('P7(i) Maps from the 15 points of PG(3,2) to the 15 primes');
const sq4 = sigVec(4, 0), POINTS = [...Array(15).keys()].map(x => x + 1), LINES = [];
for (let a = 1; a < 16; a++) for (let b = a + 1; b < 16; b++) { const [c] = bladeMul(a, b, sq4); if (c > b) LINES.push([a, b, c]); }
{
  const dig = x => [0, 1, 2, 3].map(k => Math.floor(x / 2 ** k) % 2), stdLines = [];
  for (let a = 1; a < 16; a++) for (let b = a + 1; b < 16; b++) for (let c = b + 1; c < 16; c++) if (dig(a).every((d, k) => (d + dig(b)[k] + dig(c)[k]) % 2 === 0)) stdLines.push([a, b, c]);
  chk('bit==std', LINES.length === 35 && JSON.stringify(LINES) === JSON.stringify(stdLines) && POINTS.every(p => LINES.filter(l => l.includes(p)).length === 7), '35 lines {a, b, a XOR b}, 7 through each point (engine labels = digit sums mod 2)');
}
const sym = { m1: p => legendre(-1, p), two: p => legendre(2, p), m2: p => legendre(-2, p) };
const chi = (s, c2) => p => (p === 2 ? c2 : sym[s](p));
const RELS = [];
for (const s of ['m1', 'two', 'm2']) for (const c2 of [1, -1]) { const f = chi(s, c2); RELS.push({ id: `${s === 'm1' ? '(−1/p)' : s === 'two' ? '(2/p)' : '(−2/p)'}, χ(2)=${c2 > 0 ? '+' : '−'}1`, chi: f, line: (x, y, z) => f(x) * f(y) * f(z) === 1 }); }
for (const m of [8, 24]) RELS.push({ id: `product ≡ 1 mod ${m}`, line: (x, y, z) => (x * y * z) % m === 1 });
const countLines = (f, R) => LINES.filter(([a, b, c]) => R.line(f[a], f[b], f[c])).length;
{
  const classes = [1, 2, 3, 4].map(g => POINTS.filter(p => popcount(p) === g).length);
  const INV = { 'order of 2': p => (p === 2 ? 0 : ordMod(2, p)), exponent: p => EXP.get(p), 'p mod 8': p => p % 8, '(−1/p)': p => legendre(-1, p), '(2/p)': p => legendre(2, p), '(−2/p)': p => legendre(-2, p) };
  const sizes = Object.fromEntries(Object.entries(INV).map(([k, f]) => { const m = new Map(); for (const p of M15) m.set(f(p), (m.get(f(p)) || 0) + 1); return [k, [...m.values()].sort((x, y) => x - y)]; }));
  chk('std', JSON.stringify(classes) === '[4,6,4,1]' && Object.values(sizes).every(s => JSON.stringify(s) !== '[1,4,4,6]'),
    `switch permutations split the 15 points by grade into 4, 6, 4, 1; class sizes of the prime invariants: ${Object.entries(sizes).map(([k, s]) => `${k} [${s.join(',')}]`).join('; ')}: none is 1, 4, 4, 6, so no invariant matches the classes and no order-free bijection exists`);
  // the order-free count condition, and its brute-force check on a small model: F2^2 (3 points, 1 line) and F2^3 (7 points, 7 lines)
  const minus = RELS.slice(0, 6).map(R => M15.filter(p => R.chi(p) === -1).length);
  const okRel = RELS.slice(0, 6).filter((R, i) => minus[i] === 0 || minus[i] === 8).map(R => R.id);
  note(`number of primes with χ = −1 for the six symbol relations: ${minus.join(', ')}; a bijection satisfying all 35 lines exists exactly for 0 or 8 (a character of F2^4): ${okRel.join(' and ')}`);
  const exists = Array(16).fill(false); let nChar = 0;
  for (let mask = 0; mask < (1 << 15); mask++) { const v = k => ((mask >> (k - 1)) & 1 ? -1 : 1); if (LINES.every(([a, b, c]) => v(a) * v(b) * v(c) === 1)) { nChar++; exists[popcount(mask)] = true; } }
  chk('ctl', nChar === 16 && exists.every((e, k) => e === (k === 0 || k === 8)), 'brute force over all 2^15 sign patterns on PG(3,2): exactly 16 satisfy all 35 lines (the characters of F2^4), with 0 or 8 values −1; a list of signs can be arranged to satisfy all lines exactly when it has 0 or 8 values −1');
  chk('std', JSON.stringify(okRel) === JSON.stringify(['(2/p), χ(2)=−1', '(−2/p), χ(2)=+1']), 'the Monster primes admit an XOR-respecting bijection for (2/p) with χ(2) = −1 and for (−2/p) with χ(2) = +1 only');
  // explicit maps
  const byGN = POINTS.slice().sort((x, y) => popcount(x) - popcount(y) || x - y), asg = (order) => { const f = {}; byGN.forEach((pt, i) => { f[pt] = order[i]; }); return f; };
  const MAPS = {
    'label N ↦ N-th prime': Object.fromEntries(POINTS.map(N => [N, M15[N - 1]])),
    'grade order ↦ increasing': asg(M15),
    'grade order ↦ order of 2': asg(M15.slice().sort((x, y) => (x === 2 ? 0 : ordMod(2, x)) - (y === 2 ? 0 : ordMod(2, y)) || x - y)),
    'grade order ↦ exponent': asg(M15.slice().sort((x, y) => EXP.get(y) - EXP.get(x) || x - y)),
    'grade order ↦ p mod 8': asg(M15.slice().sort((x, y) => (x % 8) - (y % 8) || x - y)) };
  const r = rng(4242), NR = 100000, dist = RELS.map(() => new Int32Array(36));
  for (let t = 0; t < NR; t++) { const sh = shuffle(r, M15), f = {}; POINTS.forEach((pt, i) => { f[pt] = sh[i]; }); RELS.forEach((R, j) => { dist[j][countLines(f, R)]++; }); }
  const pval = (j, obs) => { let s = 0; for (let k = obs; k <= 35; k++) s += dist[j][k]; return s / NR; };
  let minp = 1, rows = []; const ntest = Object.keys(MAPS).length * RELS.length;
  for (const [mn, f] of Object.entries(MAPS)) { const obs = RELS.map(R => countLines(f, R)), ps = obs.map((o, j) => pval(j, o)); minp = Math.min(minp, ...ps); rows.push(`${mn}: ${obs.join('/')} (p ≥ ${Math.min(...ps).toFixed(3)})`); }
  note('lines satisfied (of 35) per relation [' + RELS.map(R => R.id).join(' | ') + ']: ' + rows.join('; '));
  chk('std', minp > 0.05 / ntest, `five explicit maps × ${RELS.length} relations = ${ntest} tests against ${NR} seeded random bijections: smallest p = ${minp.toFixed(4)}, above the Bonferroni bound ${(0.05 / ntest).toExponential(2)}`);
  // planted control: put the 7 primes with (2/p) = +1 on a hyperplane (the 7 points with bit 3 off), the other 8 off it
  const plus = M15.filter(p => p !== 2 && legendre(2, p) === 1), rest = M15.filter(p => !plus.includes(p)), hyper = POINTS.filter(x => !((x >> 3) & 1)), off = POINTS.filter(x => (x >> 3) & 1), fP = {};
  hyper.forEach((pt, i) => { fP[pt] = plus[i]; }); off.forEach((pt, i) => { fP[pt] = rest[i]; });
  const jTwo = RELS.findIndex(R => R.id === '(2/p), χ(2)=−1'), obsP = countLines(fP, RELS[jTwo]);
  const pBest = 15 / 6435;   // exact: a random bijection respects the (2/p) character with probability 15·7!·8!/15! = 15/C(15,7)
  chk('ctl', obsP === 35 && Math.abs(pval(jTwo, obsP) - pBest) < 6e-4, `planted map (the 7 primes ≡ ±1 mod 8 on a Fano plane): 35 of 35 lines, p = ${pval(jTwo, obsP).toExponential(2)} against the exact 15/6435 = ${pBest.toExponential(2)}: the test sees it, and this is the smallest p it can give for that relation (no Bonferroni bound over ${ntest} tests can be reached)`);
  // exact chance of the count condition over all 15-subsets of the first 20 primes
  let any = 0, tw = 0, all = 0; const per = Array(6).fill(0);
  for (const S of subsets(F20, 15)) { all++; let hit = false; RELS.slice(0, 6).forEach((R, j) => { const k = S.filter(p => R.chi(p) === -1).length; if (k === 0 || k === 8) { per[j]++; hit = true; } }); if (hit) any++; if (S.includes(7) && S.includes(17) && S.includes(23) && S.includes(31) && S.includes(41) && S.includes(47) && S.includes(71)) tw++; }
  note(`exact over all ${all} 15-subsets of the first 20 primes: fraction admitting an XOR-respecting bijection, per relation ${per.map(x => (x / all).toFixed(4)).join(', ')}; for at least one of the six: ${(any / all).toFixed(4)}; containing all seven primes ≡ ±1 mod 8: ${(tw / all).toFixed(4)}`);
  chk('std', per[RELS.findIndex(R => R.id === '(2/p), χ(2)=−1')] === 1287 && any / all > 0.05, `the (2/p) condition holds for 1287 of 15504 subsets (${(1287 / 15504).toFixed(3)}), the family of six for ${(any / all).toFixed(3)}: chance level`);
}

// ---------------------------------------------------------------- (ii)
head('P7(ii) The square-free kernel as a label');
{
  const odd = M15.filter(p => EXP.get(p) % 2 === 1); let K = 1n; for (const p of odd) K *= BigInt(p);
  const Q = ORDER / K; let s = 1n << 90n; for (let i = 0; i < 200; i++) s = (s + Q / s) >> 1n; while (s * s > Q) s--; while ((s + 1n) * (s + 1n) <= Q) s++;
  let mask = 0; odd.forEach(p => { mask |= 1 << M15.indexOf(p); });
  const [m2, sgn] = bladeMul(mask, mask, sigVec(15, 0)), comp = 32767 ^ mask; let compName = 1; for (let a = 0; a < 15; a++) if ((comp >> a) & 1) compName *= M15[a];
  chk('given', ORDER % K === 0n && s * s === Q && JSON.stringify(odd) === '[5,13,17,19,23,29,31,41,47,59,71]', `kernel K = 5·13·17·19·23·29·31·41·47·59·71 = ${K}; order / K is a perfect square`);
  chk('bit', popcount(mask) === 11 && mask === 32740 && m2 === 0 && sgn === -1 && compName === 462, `on 15 switches named by the Monster's primes the kernel is the label with 11 switches on (integer label ${mask}, odd, Möbius −1); its square in Cl(15,0) is −1; the even-exponent switches 2, 3, 7, 11 form the complement, name 462`);
  chk('std', !firstPrimes(15).includes(59) && !firstPrimes(15).includes(71), 'with the first 15 primes as names the kernel is no label (59 and 71 name no switch)');
}

// ---------------------------------------------------------------- (iii)
head('P7(iii) The sixteenth place');
{
  const P16 = firstPrimes(16); let pr = 1n; for (const p of P16) pr *= BigInt(p);
  const w = wedderburn(16, 0), L16 = DICT.ladder[16];
  const odd16 = [...new Set([...Array(15).keys()].map(g => g + 1).flatMap(g => [...factorTD(binom(16, g)).keys()]))].filter(p => p > 2).sort((a, b) => a - b);
  chk('std', P16[15] === 53 && pr === 32589158477190044730n, 'the 16th prime is 53; the top name of 16 switches is 53# = 32589158477190044730');
  chk('bit==std', w.type === 'R' && w.k === 256 && w.c === 0 && L16.plus_edge.name === 'M256(R)' && JSON.stringify(L16.odd_primes_in_grade_counts) === JSON.stringify(odd16) && JSON.stringify(odd16) === '[3,5,7,11,13]',
    'Cl(16,0) = M256(R) at clock 0 (engine and rung-16 data); the odd primes in the grade counts C(16,g) are 3, 5, 7, 11, 13 (data = trial division)');
  const missing = P16.filter(p => !M15.includes(p)), extra = M15.filter(p => !P16.includes(p));
  chk('std', JSON.stringify(missing) === '[37,43,53]' && JSON.stringify(extra) === '[59,71]', 'against the first 16 primes the Monster list lacks 37, 43, 53 and has 59, 71; of the rung-16 grade-count primes all are in the list');
  // 16 = 15 + 1: naming each non-empty label of four switches by its own prime breaks the product rule on every pair
  const f = Object.fromEntries(POINTS.map((N, i) => [N, M15[i]])); let good = 0, pairs = 0;
  for (const a of POINTS) for (const b of POINTS) { if (a === b) continue; pairs++; const c = a ^ b, g = gcd(f[a], f[b]); if (f[a] * f[b] / (g * g) === f[c]) good++; }
  chk('std', POINTS.length + 1 === 16 && good === 0 && pairs === 210, 'four switches have 16 labels: 15 non-empty and the empty one named 1; a prime for each non-empty label satisfies the product rule on 0 of the 210 ordered pairs (the product of two primes is never a prime)');
}

// ---------------------------------------------------------------- (iv)
head('P7(iv) Lucas/Kummer: the primes in the grade counts');
{
  const S = n => { const row = []; for (let k = 1; k < n; k++) row.push(binom(n, k)); return primesUpTo(n).filter(p => row.some(c => c % BigInt(p) === 0n)); };
  const lucasExc = (n, p) => { const d = []; let m = n; while (m) { d.push(m % p); m = Math.floor(m / p); } return d.length >= 2 && d.slice(0, -1).every(x => x === p - 1); };
  let bitOk = true; for (let n = 1; n <= 20; n++) { const cnt = Array(n + 1).fill(0); for (let x = 0; x < (1 << n); x++) cnt[popcount(x)]++; if (!cnt.every((c, k) => BigInt(c) === binom(n, k))) bitOk = false; }
  chk('bit==std', bitOk, 'grade counts of the 2^n labels (engine popcount) = C(n,k), n = 1..20');
  let agree = true; const exc = [];
  for (let n = 1; n <= 120; n++) { const s = S(n), e = primesUpTo(n).filter(p => !s.includes(p)); if (JSON.stringify(e) !== JSON.stringify(primesUpTo(n).filter(p => lucasExc(n, p)))) agree = false; if (n <= 24 && e.length) exc.push(`${n}:{${e.join(',')}}`); }
  chk('std', agree, 'n = 1..120: a prime p ≤ n divides no C(n,k), 0 < k < n, exactly when every base-p digit of n below the leading one is p − 1 (direct divisibility = Lucas)');
  note(`n ≤ 24 with a prime ≤ n missing from the grade counts: ${exc.join(' ')}`);
  const s71 = S(71);
  chk('std', JSON.stringify(s71) === JSON.stringify(F20), 'n = 71: all 20 primes ≤ 71 divide some C(71,k): the Monster\'s 15 together with 37, 43, 53, 61, 67');
  let eq = 0, first = null; const Mset = JSON.stringify(M15);
  for (let n = 1; n <= 2000; n++) { const s = primesUpTo(n).filter(p => !lucasExc(n, p)); if (JSON.stringify(s) === Mset) eq++; if (first === null && M15.every(p => s.includes(p))) first = n; }
  chk('std', eq === 0 && first === 71, `n = 1..2000: the set of primes in the grade counts is never the Monster's 15; it contains all 15 first at n = 71, and then also others`);
  note('for every n: below 71 the prime 71 is missing; at 71 and 72 the prime 37 divides some C(n,k); from 73 on a prime above 71 does (Bertrand: the largest prime P ≤ n would need n + 1 = 2P, and then no prime lies in (P, 2P)) [ours, recalled theorem]');
}

// ---------------------------------------------------------------- (v)
head('P7(v) The departure from the natural order');
{
  const PR = primesUpTo(113), inM = p => M15.includes(p);
  const row = p => { const i = PR.indexOf(p) + 1, o = p === 2 ? '-' : ordMod(2, p); return `${i}:${p}${inM(p) ? '*' : ''} m8=${p % 8} m12=${p % 12} m24=${p % 24} (−1/p)=${legendre(-1, p)} (2/p)=${legendre(2, p)} (−2/p)=${legendre(-2, p)} ord=${o} ${[24, 48, 72].filter(m => m % (p - 1) === 0).map(m => `p−1|${m}`).join(',')}${[24, 48, 72].filter(m => m % (p + 1) === 0).map(m => ` p+1|${m}`).join(',')}${p >= 5 ? ' (p²−1)/24=' + (p * p - 1) / 24 : ''}`; };
  note('table (* = in the list): ' + PR.map(row).join(' ; '));
  const ATOMS = new Map(), add = (name, f) => { let m = 0; F20.forEach((p, i) => { if (f(p, i + 1)) m |= 1 << i; }); if (m && m !== (1 << 20) - 1 && ![...ATOMS.values()].includes(m)) ATOMS.set(name, m); };
  for (const m of [3, 4, 5, 8, 12, 24]) for (let r = 0; r < m; r++) add(`p≡${r} mod ${m}`, p => p % m === r);
  for (const [nm, a] of [['−1', -1], ['2', 2], ['−2', -2], ['3', 3], ['−3', -3]]) for (const v of [-1, 0, 1]) add(`(${nm}/p)=${v}`, p => legendre(a, p) === v);
  const o = p => (p === 2 ? null : ordMod(2, p));
  add('ord even', p => o(p) !== null && o(p) % 2 === 0); add('2 primitive root', p => o(p) === p - 1); add('ord=(p−1)/2', p => o(p) !== null && 2 * o(p) === p - 1); add('ord≤12', p => o(p) !== null && o(p) <= 12);
  for (const m of [24, 48, 72]) { add(`ord|${m}`, p => o(p) !== null && m % o(p) === 0); add(`p−1|${m}`, p => m % (p - 1) === 0); add(`p+1|${m}`, p => m % (p + 1) === 0); }
  for (const m of [12, 24]) { add(`${m}|p+1`, p => (p + 1) % m === 0); add(`${m}|p−1`, p => (p - 1) % m === 0); }
  add('(p−1)/2 prime', p => isPrimeTD((p - 1) / 2)); add('(p+1)/2 prime', p => isPrimeTD((p + 1) / 2)); add('p+2 prime', p => isPrimeTD(p + 2)); add('p−2 prime', p => isPrimeTD(p - 2)); add('(p²−1)/24 even', p => p >= 5 && ((p * p - 1) / 24) % 2 === 0);
  add('index≤11', (p, i) => i <= 11); add('index≤15', (p, i) => i <= 15); for (const m of [2, 3, 4]) for (let r = 0; r < m; r++) add(`index≡${r} mod ${m}`, (p, i) => i % m === r);
  const A = [...ATOMS.entries()], ALL = (1 << 20) - 1, RULES = new Map();
  for (const [nm, m] of A) RULES.set(m, nm);
  for (let i = 0; i < A.length; i++) for (let j = i + 1; j < A.length; j++) { const [na, a] = A[i], [nb, b] = A[j];
    for (const [op, m] of [['and', a & b], ['or', a | b], ['and not', a & ~b & ALL], ['not and', ~a & b & ALL], ['xor', a ^ b]]) if (!RULES.has(m)) RULES.set(m, `${na} ${op} ${nb}`); }
  const tried = A.length + 5 * A.length * (A.length - 1) / 2;
  let MON = 0; F20.forEach((p, i) => { if (inM(p)) MON |= 1 << i; });
  const sepBy = s => RULES.get(s) || RULES.get(ALL ^ s) || null;
  const found = sepBy(MON);
  note(`${A.length} distinct single conditions and ${tried - A.length} pair rules (five combinations per pair): ${tried} rules tried, ${RULES.size} distinct subsets of the first 20 primes`);
  let any = 0, cnt = 0; for (const S of subsets([...Array(20).keys()], 15)) { cnt++; let m = 0; for (const i of S) m |= 1 << i; if (sepBy(m)) any++; }
  const r = rng(9001); let hits = 0; for (let t = 0; t < 100000; t++) { const S = shuffle(r, [...Array(20).keys()]).slice(0, 15); let m = 0; for (const i of S) m |= 1 << i; if (sepBy(m)) hits++; }
  chk('std', found === null, `no single condition and no pair separates the 15 listed primes from the 5 skipped ones up to 71${found ? ' (found: ' + found + ')' : ''}`);
  note(`family-wise chance: ${any} of all ${cnt} 15-subsets of the first 20 primes are separable by some rule of the family (${(any / cnt).toFixed(4)}); seeded draws: ${hits} of 100000`);
  let planted = 0; for (let i = 0; i < 20; i++) if ((i + 1) % 4 !== 0) planted |= 1 << i;   // a planted list: skip the 4th, 8th, 12th, 16th, 20th primes
  chk('ctl', sepBy(planted) !== null, `a planted list (the first 20 primes without the 4th, 8th, 12th, 16th, 20th: ${F20.filter((p, i) => !((planted >> i) & 1)).join(', ')} skipped) is found, by "${sepBy(planted)}"`);
  const beyond = PR.filter(p => p > 71), periodic = [...ATOMS.keys()].filter(k => /mod|\/p\)|ord even|primitive/.test(k));
  note(`any rule must also exclude all ${beyond.length} primes 73..113 here (and every prime above 71): congruence and symbol conditions hold for infinitely many primes (Dirichlet, recalled), so a rule matching the list has to contain 71 itself`);
}

// ---------------------------------------------------------------- (vi)
head('P7(vi) Signature from the primes (a construction)');
{
  const LM = { 0: ['R', 1], 1: ['R2', 1], 2: ['R', 1], 3: ['C', 2], 4: ['H', 4], 5: ['H2', 4], 6: ['H', 4], 7: ['C', 2] };   // recalled: type by (p − q) mod 8, real dimension of the field
  const SETS = { 'Monster 15': M15, 'first 15': firstPrimes(15), 'Monster 15 + unit': [1, ...M15], 'first 15 + unit': [1, ...firstPrimes(15)], 'first 16': firstPrimes(16) };
  let ok = true; const out = [];
  for (const [nm, S] of Object.entries(SETS)) for (const c2 of [1, -1]) {
    const sg = S.map(p => (p === 1 ? 1 : p === 2 ? c2 : legendre(-1, p))), P = sg.filter(x => x > 0).length, Q = sg.length - P, w = wedderburn(P, Q), c = clockOf(P, Q), [t, fd] = LM[(((P - Q) % 8) + 8) % 8];
    const copies = t.endsWith('2') ? 2 : 1, k = Math.round(Math.sqrt(2 ** (P + Q) / (copies * fd)));
    if (!(w.type === t && w.k === k && w.c === c && copies * k * k * fd === 2 ** (P + Q))) ok = false;
    out.push(`${nm}, 2 as ${c2 > 0 ? '+' : '−'}: Cl(${P},${Q}) c=${c} ${t === 'R2' ? `M${k}(R)²` : t === 'H2' ? `M${k}(H)²` : `M${k}(${t})`}`);
  }
  note(out.join('; '));
  chk('bit==std', ok, 'clock and type from sigVec counts and wedderburn agree with the recalled table for all ten cases');
  chk('std', out[4].includes('c=6') && out[5].includes('c=4') && out[4].includes('(H)') && out[5].includes('(H)') && out[6].includes('c=0') && out[7].includes('c=6'), 'with the unit as a sixteenth + switch the Monster list gives a quaternionic cell for both choices of the sign of 2 (c = 6 or 4); the first 15 with the unit give c = 0 (real) or 6');
}
finish(ID);
