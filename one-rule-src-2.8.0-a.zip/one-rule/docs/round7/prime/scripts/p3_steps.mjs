#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P3. The Maxwell steps as divisions and multiplications.   node p3_steps.mjs

 Statement, for every cell of maxwellData.js (n = 2..7 generators): every incidence (source, axis, target, op) satisfies
 name(target) = name(source) ÷ p_axis for contract and × p_axis for wedge (names from the first n primes); among the n·C(n,2)·2 choices
 (piece, axis, drop or add) the ones that are not incidences are exactly the drops where p_axis does not divide the name and the adds
 where it already divides (24 + 24 = 48 for the cell [1,3]). Second step: the end labels are even; two different steps taken in the two
 orders end on the same label with opposite bladeMul signs, so they cancel (in particular the roads to the scalar, name 1, and to the
 grade-4 labels, name 210 = 2·3·5·7 in the cell [1,3]); equal steps give ε_a ∂_a², the wave operator.
 [bit] bladeMul with sigVec(k,d) of the cell: incidence targets and signs (sign = bladeMul sign × the field's convention sign), the roads
       of the second step, and the second step applied to polynomial fields.
 [std] (1) the textbook component equations of the cell [1,3] (Gauss, Ampère, Faraday, no monopole; c = 1), written here, against the
       incidences as sets of (axis, component, sign) up to one overall sign per equation; (2) random polynomial fields with exact partial
       derivatives: the textbook □ = Σ_time ∂² − Σ_space ∂² on each component, and Σ ∂_a ∂_b F_ab = 0 for antisymmetric F; names by plain
       integer arithmetic.
 [ctl] a drop taken as a multiplication; contract and wedge swapped; the sign of one road dropped (the roads add); time with the wrong
       sign in □; names shifted by one prime (the rule survives, the numbers change: 1155 instead of 210).
 [data] the cell's own checks (wave_equation, only_grades_1_and_3, charge_conservation) and the blade squares.
 Scope: all 15 cells; polynomial fields: 3 seeded fields per cell, degree ≤ 3. */
import { head, chk, note, finish, loadEngine, loadData, firstPrimes, rng, randInt } from './plib.mjs';
const { bladeMul, sigVec, popcount } = await loadEngine();
const MAX = await loadData('maxwellData.js');
const ID = 'PRIME-P3';
const comb = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return r; };

// ---------------------------------------------------------------- tiny polynomials: Map("e0,e1,...") -> integer coefficient (std, no engine)
const padd = (A, B, s = 1) => { const R = new Map(A); for (const [k, v] of B) { const w = (R.get(k) || 0) + s * v; if (w) R.set(k, w); else R.delete(k); } return R; };
const pder = (A, a) => { const R = new Map(); for (const [k, v] of A) { const e = k.split(',').map(Number); if (!e[a]) continue; const c = v * e[a]; e[a]--; const kk = e.join(','); R.set(kk, (R.get(kk) || 0) + c); } for (const [k, v] of R) if (!v) R.delete(k); return R; };
const peq = (A, B) => A.size === B.size && [...A].every(([k, v]) => B.get(k) === v);
const prand = (r, n) => { const P = new Map(); for (let t = 0; t < 4; t++) { const e = Array(n).fill(0); for (let j = 0; j < 3; j++) e[randInt(r, n)]++; const k = e.join(','); P.set(k, (P.get(k) || 0) + randInt(r, 7) - 3); } for (const [k, v] of P) if (!v) P.delete(k); return P; };
// grad by the bit rule: X = {blade: poly}; grad X = sum_a e_a d_a X (signs from bladeMul)
function grad(X, n, sq, absSign = false) { const R = new Map(); for (const [m, c] of X) for (let a = 0; a < n; a++) { const [m2, s] = bladeMul(1 << a, m, sq); const d = pder(c, a); if (!d.size) continue; R.set(m2, padd(R.get(m2) || new Map(), d, absSign ? 1 : s)); } return R; }

let totInc = 0, totNon = 0, cellsOk = 0;
const keys = Object.keys(MAX.cells);
head(`P3a. Incidences as divisions and multiplications, all ${keys.length} cells`);
for (const key of keys) {
  const C = MAX.cells[key], n = C.n, k = C.k, dd = C.d, sq = sigVec(k, dd), P = firstPrimes(n);
  const name = m => { let x = 1; for (let a = 0; a < n; a++) if ((m >> a) & 1) x *= P[a]; return x; };
  const fo = C.conventions.field_order, sgn = C.conventions.signs, sF = f => sgn[fo.indexOf(f)];
  let incOk = 0, engOk = 0;
  for (const i of C.incidences) {
    const ns = name(i.source), nt = name(i.target), p = P[i.axis];
    if (i.op === 'contract' ? (ns % p === 0 && nt === ns / p) : (ns % p !== 0 && nt === ns * p)) incOk++;
    const [t, s] = bladeMul(1 << i.axis, i.source, sq); if (t === i.target && s * sF(i.field) === i.sign && fo.indexOf(i.field) >= 0) engOk++;
  }
  const pieces = [...new Set(C.incidences.map(i => i.source))], isInc = new Set(C.incidences.map(i => `${i.source}|${i.axis}|${i.op === 'contract' ? 'drop' : 'add'}`));
  let non = 0, nonOk = 0, choices = 0;
  for (const S of pieces) for (let a = 0; a < n; a++) for (const op of ['drop', 'add']) { choices++; const inc = isInc.has(`${S}|${a}|${op}`), divides = name(S) % P[a] === 0;
    if (!inc) { non++; if ((op === 'drop' && !divides) || (op === 'add' && divides)) nonOk++; } else if (!((op === 'drop' && divides) || (op === 'add' && !divides))) nonOk -= 1000; }
  const sqOk = C.blades.every(b => bladeMul(b.N, b.N, sq)[1] === b.square), checks = C.checks.wave_equation && C.checks.only_grades_1_and_3 && C.checks.charge_conservation;
  const ok = chk('bit==std', incOk === C.incidences.length && engOk === C.incidences.length && pieces.length === comb(n, 2) && non === nonOk && non + C.incidences.length === choices && sqOk && checks,
    `cell [${key}] Cl(${k},${dd}), n=${n}: ${C.incidences.length} incidences all ÷p (contract) or ×p (wedge), targets and signs from bladeMul; ${non} non-incidences = drops with p∤name and adds with p|name; ${choices} choices; data checks and blade squares agree`);
  if (ok) cellsOk++; totInc += C.incidences.length; totNon += non;
  if (key === '1,3') chk('std', C.incidences.length === 24 && non === 24 && choices === 48, 'the cell [1,3] (four switches): 24 incidences + 24 non-incidences = 48 choices');
}
note(`all cells: ${totInc} incidences, ${totNon} non-incidences, ${cellsOk}/${keys.length} cells agree`);

head('P3b. The second step: roads, cancellation, the wave operator (every cell, every piece, every ordered pair of steps)');
for (const key of keys) {
  const C = MAX.cells[key], n = C.n, sq = sigVec(C.k, C.d), P = firstPrimes(n), name = m => { let x = 1; for (let a = 0; a < n; a++) if ((m >> a) & 1) x *= P[a]; return x; };
  let even = true, cancel = true, diag = true, toZero = 0, toFour = 0, fourNames = new Set();
  const pieces = [...new Set(C.incidences.map(i => i.source))];
  for (const S of pieces) for (let a = 0; a < n; a++) for (let b = 0; b < n; b++) {
    const [m1, s1] = bladeMul(1 << a, S, sq), [m2, s2] = bladeMul(1 << b, m1, sq);
    if (popcount(m2) % 2) even = false;
    if (a === b) { if (m2 !== S || s1 * s2 !== sq[a]) diag = false; continue; }
    const [n1, t1] = bladeMul(1 << b, S, sq), [n2, t2] = bladeMul(1 << a, n1, sq);
    if (n2 !== m2 || t1 * t2 !== -s1 * s2) cancel = false;
    if (m2 === 0) toZero++; if (popcount(m2) === 4) { toFour++; fourNames.add(name(m2)); }
  }
  const four = [...fourNames].sort((x, y) => x - y);
  chk('bit', even && cancel && diag, `cell [${key}]: end labels even; the two orders of two different steps end on one label with opposite signs; equal steps give ε_a (${toZero} roads to name 1, ${toFour} roads to grade 4${n === 4 ? ', named ' + four.join(', ') : ''})`);
}

head('P3c. [std] textbook component equations of the cell [1,3] against its incidences');
{
  const C = MAX.cells['1,3'];
  // textbook (c = 1): div E = rho; curl B - dE/dt = J; curl E + dB/dt = 0; div B = 0. Rows: [axis, component, sign]
  const T = {
    gauss: [['x', 'E_x', 1], ['y', 'E_y', 1], ['z', 'E_z', 1]],
    amp_x: [['y', 'B_z', 1], ['z', 'B_y', -1], ['t', 'E_x', -1]], amp_y: [['z', 'B_x', 1], ['x', 'B_z', -1], ['t', 'E_y', -1]], amp_z: [['x', 'B_y', 1], ['y', 'B_x', -1], ['t', 'E_z', -1]],
    far_x: [['y', 'E_z', 1], ['z', 'E_y', -1], ['t', 'B_x', 1]], far_y: [['z', 'E_x', 1], ['x', 'E_z', -1], ['t', 'B_y', 1]], far_z: [['x', 'E_y', 1], ['y', 'E_x', -1], ['t', 'B_z', 1]],
    divB: [['x', 'B_x', 1], ['y', 'B_y', 1], ['z', 'B_z', 1]] };
  const byTarget = new Map(); for (const i of C.incidences) { if (!byTarget.has(i.target)) byTarget.set(i.target, []); byTarget.get(i.target).push([i.axis_name, i.field, i.sign]); }
  let matched = 0; const used = new Set();
  for (const [id, rowsT] of Object.entries(T)) {
    const keyT = rowsT.map(r => r[0] + r[1]).sort().join(' ');
    for (const [tg, rowsD] of byTarget) { if (rowsD.map(r => r[0] + r[1]).sort().join(' ') !== keyT) continue;
      const ratio = new Set(rowsT.map(([ax, f, s]) => s * rowsD.find(r => r[0] === ax && r[1] === f)[2])); if (ratio.size === 1 && !used.has(tg)) { matched++; used.add(tg); } }
  }
  chk('bit==std', matched === 8 && byTarget.size === 8, `all 8 textbook equations match one target each, as sets of (axis, component), with one overall sign per equation (${matched}/8)`);
  const wrong = JSON.parse(JSON.stringify(T)); wrong.amp_x[0][2] = -1; let m2 = 0; for (const rowsT of Object.values(wrong)) { const keyT = rowsT.map(r => r[0] + r[1]).sort().join(' ');
    for (const [, rowsD] of byTarget) if (rowsD.map(r => r[0] + r[1]).sort().join(' ') === keyT && new Set(rowsT.map(([ax, f, s]) => s * rowsD.find(r => r[0] === ax && r[1] === f)[2])).size === 1) m2++; }
  chk('ctl', m2 === 7, `a wrong sign in the textbook Ampère row (∂_y B_z with −) matches no target (${m2}/8 match)`);
}

head('P3d. [std] the second step on random polynomial fields: textbook □ against the engine, every cell');
for (const key of keys) {
  const C = MAX.cells[key], n = C.n, sq = sigVec(C.k, C.d), r = rng(77 + 13 * n + C.k);
  const eps = [...Array(C.k).fill(1), ...Array(C.d).fill(-1)];                   // textbook: + on the time axes, − on the space axes (written here)
  const pieces = [...new Set(C.incidences.map(i => i.source))];
  let ok = true, cons = true, ctlRoad = false, ctlTime = false;
  for (let t = 0; t < 3; t++) {
    const F = new Map(pieces.map(S => [S, prand(r, n)]));
    const G = grad(grad(F, n, sq), n, sq);
    for (const [m, c] of G) if (!pieces.includes(m) && c.size) ok = false;
    for (const S of pieces) { let box = new Map(); for (let a = 0; a < n; a++) box = padd(box, pder(pder(F.get(S), a), a), eps[a]); if (!peq(G.get(S) || new Map(), box)) ok = false;
      let boxW = new Map(); for (let a = 0; a < n; a++) boxW = padd(boxW, pder(pder(F.get(S), a), a), -1); if (!peq(G.get(S) || new Map(), boxW)) ctlTime = true; }
    // textbook charge conservation: F_ab antisymmetric, sum over a, b of d_a d_b F_ab = 0
    let s = new Map(); for (const S of pieces) { const a = Math.min(...[0, 1, 2, 3, 4, 5, 6].filter(x => (S >> x) & 1)), b = Math.max(...[0, 1, 2, 3, 4, 5, 6].filter(x => (S >> x) & 1));
      s = padd(s, pder(pder(F.get(S), a), b), 1); s = padd(s, pder(pder(F.get(S), b), a), -1); } if (s.size) cons = false;
    const Gabs = grad(grad(F, n, sq, true), n, sq, true); for (const [m, c] of Gabs) if (!pieces.includes(m) && c.size) ctlRoad = true;
  }
  chk('bit==std', ok && cons, `cell [${key}]: grad grad F = □F on every component (textbook signs), no other grade; Σ∂_a∂_b F_ab = 0 (3 seeded fields)`);
  chk('ctl', ctlRoad && ctlTime, `cell [${key}]: with the road signs dropped the roads add (other grades appear); time with the wrong sign in □ disagrees`);
}

head('P3e. Controls on the names');
{
  const C = MAX.cells['1,3'], P = firstPrimes(4), Q = [3, 5, 7, 11], nm = (m, L) => { let x = 1; for (let a = 0; a < 4; a++) if ((m >> a) & 1) x *= L[a]; return x; };
  const contractAsMul = C.incidences.filter(i => i.op === 'contract').every(i => nm(i.target, P) === nm(i.source, P) * P[i.axis]);
  chk('ctl', !contractAsMul, 'a drop taken as a multiplication fails on the contract incidences');
  const swapped = C.incidences.every(i => (i.op === 'wedge' ? nm(i.target, P) * P[i.axis] === nm(i.source, P) : nm(i.target, P) === nm(i.source, P) * P[i.axis]));
  chk('ctl', !swapped, 'contract and wedge swapped: the rule fails');
  const shiftedRule = C.incidences.every(i => (i.op === 'contract' ? nm(i.target, Q) * Q[i.axis] === nm(i.source, Q) : nm(i.target, Q) === nm(i.source, Q) * Q[i.axis]));
  chk('ctl', shiftedRule && nm(15, Q) === 1155 && nm(15, P) === 210, 'names shifted by one prime (t → 3): the ÷/× rule still holds (a relabelling), but the 4-volume is named 1155, not 210: the numbers are notation');
}
finish(ID);
