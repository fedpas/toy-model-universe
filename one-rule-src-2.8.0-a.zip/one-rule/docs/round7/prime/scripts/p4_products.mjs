#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P4. The basis elements and their products, with names.   node p4_products.mjs

 Statement: in Cl(3,0), Cl(0,3), Cl(1,3), Cl(3,1), Cl(2,2), Cl(4,0), Cl(0,4) the full table of products of basis blades (8 × 8 or 16 × 16)
 has the sign of the engine and the unsigned part named a·b/gcd² (names from the first n primes); the three planes of three switches
 are named 6, 10, 15 and the volume 30 = lcm(6, 10, 15); with i = e01, j = e02, k = ij the quaternion relations i² = j² = k² = ijk = −1
 hold and the names obey 6·10/2² = 15; the even half of three switches is {1, 6, 10, 15} and closed; the even labels of four switches
 are named 1, 6, 10, 14, 15, 21, 35, 210 (the 4-demicube: each has six neighbours at two flips and one antipode, product name 210).
 [bit] bladeMul with sigVec(p,q). [std] explicit matrices: Pauli σ1, σ2, σ3 for Cl(3,0); iσ_k ⊕ (−iσ_k) for Cl(0,3) (two quaternion
       blocks, faithful); Dirac matrices γ0 = diag(1,1,−1,−1), γk = [[0,σk],[−σk,0]] for Cl(1,3), iγ for Cl(3,1) (γ0 last), γ0, iγk for
       Cl(4,0), iγ0, γk for Cl(0,4); real 4×4 X⊗1, Z⊗1, J⊗X, J⊗Z for Cl(2,2); each product matrix is matched to ± one blade matrix.
 [ctl] the switch names [2,2,5,7], [4,3,5,7], [6,10,7,11] in the 16 × 16 table of Cl(1,3); the Cl(3,1) signs against the Cl(1,3) matrices.
 Scope: seven cells, all ordered pairs of blades (8·64 + ... = 1600 products checked twice). */
import { head, chk, note, finish, loadEngine, cmat, cI, cmul, ceq, cscale, ctimesI, ckron, cblock, gcd, firstPrimes, mobius, isPrimeTD } from './plib.mjs';
const { bladeMul, sigVec, popcount } = await loadEngine();
const ID = 'PRIME-P4';

const s1 = cmat(2, [0, 1, 1, 0]), s2 = cmat(2, [0, 0, 0, 0], [0, -1, 1, 0]), s3 = cmat(2, [1, 0, 0, -1]), I2 = cI(2), Z2 = cscale(I2, 0);
const blk = (A, B, C, D) => { const d = 2 * A.d, M = cmat(d, Array(d * d).fill(0)); [[A, 0, 0], [B, 0, 1], [C, 1, 0], [D, 1, 1]].forEach(([X, bi, bj]) => { for (let i = 0; i < A.d; i++) for (let j = 0; j < A.d; j++) { M.re[(bi * A.d + i) * d + bj * A.d + j] = X.re[i * A.d + j]; M.im[(bi * A.d + i) * d + bj * A.d + j] = X.im[i * A.d + j]; } }); return M; };
const g0 = blk(I2, Z2, Z2, cscale(I2, -1)), gk = [s1, s2, s3].map(s => blk(Z2, s, cscale(s, -1), Z2));
const X = cmat(2, [0, 1, 1, 0]), Zr = cmat(2, [1, 0, 0, -1]), J = cmat(2, [0, 1, -1, 0]);
const CELLS = [
  ['Cl(3,0)', 3, 0, [s1, s2, s3]],
  ['Cl(0,3)', 0, 3, [s1, s2, s3].map(s => cblock(ctimesI(s), cscale(ctimesI(s), -1)))],
  ['Cl(1,3)', 1, 3, [g0, ...gk]],
  ['Cl(3,1)', 3, 1, [...gk.map(ctimesI), ctimesI(g0)]],
  ['Cl(2,2)', 2, 2, [ckron(X, I2), ckron(Zr, I2), ckron(J, X), ckron(J, Zr)]],
  ['Cl(4,0)', 4, 0, [g0, ...gk.map(ctimesI)]],
  ['Cl(0,4)', 0, 4, [ctimesI(g0), ...gk]],
];
const bladeMat = (gens, m) => { let M = cI(gens[0].d); for (let a = 0; a < gens.length; a++) if ((m >> a) & 1) M = cmul(M, gens[a]); return M; };
function stdTable(gens) {   // product table read from the matrices: [label, sign] for every ordered pair
  const n = gens.length, L = 1 << n, B = []; for (let m = 0; m < L; m++) B.push(bladeMat(gens, m));
  const T = []; for (let a = 0; a < L; a++) { T.push([]); for (let b = 0; b < L; b++) { const P = cmul(B[a], B[b]); let hit = null; for (let c = 0; c < L && !hit; c++) { if (ceq(P, B[c])) hit = [c, 1]; else if (ceq(P, cscale(B[c], -1))) hit = [c, -1]; } T[a].push(hit); } }
  return T;
}
const namesFrom = (w) => { const n = w.length, out = []; for (let m = 0; m < (1 << n); m++) { let x = 1; for (let a = 0; a < n; a++) if ((m >> a) & 1) x *= w[a]; out.push(x); } return out; };

head('P4a. Full product tables: engine against matrices, names against a·b/gcd²');
let T13 = null;
for (const [nm, p, q, gens] of CELLS) {
  const n = p + q, sq = sigVec(p, q), L = 1 << n, nmz = namesFrom(firstPrimes(n));
  let gensOk = true; for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { const A = cmul(gens[i], gens[j]), B = cmul(gens[j], gens[i]); if (i === j ? !ceq(A, cscale(cI(gens[0].d), sq[i])) : !ceq(A, cscale(B, -1))) gensOk = false; }
  const T = stdTable(gens); if (nm === 'Cl(1,3)') T13 = T;
  let agree = 0, named = 0, tot = 0;
  for (let a = 0; a < L; a++) for (let b = 0; b < L; b++) { tot++; const [c, s] = bladeMul(a, b, sq), h = T[a][b];
    if (h && h[0] === c && h[1] === s) agree++; const g = gcd(nmz[a], nmz[b]); if (nmz[c] === nmz[a] * nmz[b] / (g * g)) named++; }
  chk('std', gensOk, `${nm}: the ${n} matrices (${gens[0].d}×${gens[0].d}) square to ${sq.join(', ')} and anticommute`);
  chk('bit==std', agree === tot, `${nm}: the ${L}×${L} table from bladeMul equals the matrix table, label and sign (${agree}/${tot})`);
  chk('bit==std', named === tot, `${nm}: the unsigned part of every product is named name(a)·name(b)/gcd² (${named}/${tot})`);
}

head('P4b. Three switches: planes, quaternions, the even half');
for (const [p, q] of [[3, 0], [0, 3]]) {
  const sq = sigVec(p, q), nmz = namesFrom([2, 3, 5]), m = (a, b) => bladeMul(a, b, sq);
  const planes = [3, 5, 6].map(x => nmz[x]), vol = nmz[7], lcm3 = [6, 10, 15].reduce((x, y) => x * y / gcd(x, y));
  const [ij, sij] = m(3, 5), [kk, skk] = m(ij, ij), [ijk, sijk] = (() => { const [t, s] = m(3, 5); const [u, s2] = m(t, ij); return [u, s * s2 * sij]; })();
  const ii = m(3, 3), jj = m(5, 5);
  chk('bit==std', JSON.stringify(planes) === '[6,10,15]' && vol === 30 && lcm3 === 30, `Cl(${p},${q}): the planes e01, e02, e12 are named 6, 10, 15; the volume e012 is named 30 = lcm(6,10,15) (6·10·15 = 900 = 30²)`);
  chk('bit', ii[0] === 0 && ii[1] === -1 && jj[0] === 0 && jj[1] === -1 && kk === 0 && skk === -1 && ijk === 0 && sijk === -1 && nmz[ij] === 15,
    `Cl(${p},${q}): i = e01, j = e02, k = ij = ${sij > 0 ? '' : '−'}e12: i² = j² = k² = ijk = −1, and the name of k is 6·10/2² = 15`);
  const even = [0, 3, 5, 6]; let closed = true; for (const a of even) for (const b of even) if (!even.includes(m(a, b)[0])) closed = false;
  chk('bit==std', closed && JSON.stringify(even.map(x => nmz[x])) === '[1,6,10,15]', `Cl(${p},${q}): the even half {1, e01, e02, e12} is closed; names 1, 6, 10, 15 (a tetrahedron of the cube)`);
}
{
  const nmz = namesFrom([2, 3, 5, 7]), ev = [...Array(16).keys()].filter(x => popcount(x) % 2 === 0), names = ev.map(x => nmz[x]).sort((x, y) => x - y);
  let nb = true; for (const a of ev) { const d = ev.filter(b => b !== a).map(b => popcount(a ^ b)); if (d.filter(x => x === 2).length !== 6 || d.filter(x => x === 4).length !== 1) nb = false; const anti = ev.find(b => popcount(a ^ b) === 4); const g = gcd(nmz[a], nmz[anti]); if (nmz[a] * nmz[anti] / (g * g) !== 210) nb = false; }
  chk('bit==std', JSON.stringify(names) === '[1,6,10,14,15,21,35,210]' && names.every(x => mobius(x) === 1) && nb, 'four switches: the 8 even labels are named 1, 6, 10, 14, 15, 21, 35, 210 (Möbius +1); each has 6 neighbours at two flips and one antipode with name product 210 (the 4-demicube)');
}

head('P4c. Controls');
{
  const L = 16, sq = sigVec(1, 3);
  const bad = w => { const nz = namesFrom(w); let ok = true, div = true; for (let a = 0; a < L; a++) for (let b = 0; b < L; b++) { const [c] = bladeMul(a, b, sq), g = gcd(nz[a], nz[b]); if (nz[c] !== nz[a] * nz[b] / (g * g)) ok = false; }
    const N = nz[15]; for (let d = 1; d <= N; d++) if (N % d === 0 && !nz.includes(d)) div = false; return { ok, div }; };
  const a = bad([2, 2, 5, 7]), b = bad([4, 3, 5, 7]), c = bad([6, 10, 7, 11]);
  chk('ctl', !a.ok, 'Cl(1,3) table with switch names [2,2,5,7]: the name rule fails');
  chk('ctl', b.ok && !b.div, 'with [4,3,5,7]: the name rule holds, but 2 divides the top name 420 and names no blade');
  chk('ctl', !c.ok, 'with [6,10,7,11]: the name rule fails (6·10/2² = 15 is not the name 60 of e01)');
  let diff = 0; const sq31 = sigVec(3, 1); for (let x = 0; x < L; x++) for (let y = 0; y < L; y++) { const [cc, s] = bladeMul(x, y, sq31); if (!(T13[x][y][0] === cc && T13[x][y][1] === s)) diff++; }
  chk('ctl', diff > 0, `the Cl(3,1) signs against the Cl(1,3) matrices: ${diff} of 256 products differ (labels agree, signs do not)`);
}
note(`primes among the names of four switches: ${namesFrom([2, 3, 5, 7]).filter(isPrimeTD).join(', ')} (the single switches)`);
finish(ID);
