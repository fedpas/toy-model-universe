#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P1. The dictionary as a lattice.   node p1_lattice.mjs

 Statement. Name switch a by the (a+1)-th prime and a label by the product of the primes of its switches that are on (N = the product of
 the n primes). Then name(a XOR b) = name(a)·name(b)/gcd², name(a AND b) = gcd, name(a OR b) = lcm, name(NOT a) = N/name(a) (the antipode of
 a corner is the cofactor), the grade is the number of prime factors, (−1)^grade is the Möbius function of the name, the even labels are the
 names with an even number of prime factors, and the labels are exactly the divisors of N. Which assignments of names to switches work
 (brute force over all assignments of names 1..30 for n = 2, 3 and 1..12 for n = 4): the product rule ⇔ AND = gcd ⇔ pairwise coprime
 names; divisibility ⇔ inclusion ⇔ no name divides a product of other names; the product rule together with "the labels are exactly
 the divisors of N" ⇔ distinct primes; "the labels are exactly the divisors of N" alone also holds for chains p, p², p⁴, ... (names
 p^(integer label)), which break the product rule; grade = number of prime factors with the Möbius sign ⇔ distinct primes.
 [bit] labelsEngine.js: the label of the product from bladeMul in three signatures (n,0), (0,n), (⌈n/2⌉,⌊n/2⌋); the parity from the
       commutation sign with one extra generator outside the label; AND read from bladeMul with one null generator (the product vanishes
       exactly when the null switch is shared); the wedge (all generators null) is non-zero exactly for disjoint labels; NOT from the
       product with the top blade.
 [std] BigInt products, Euclid's gcd, trial division (Möbius, number of prime factors), the divisors of N by trial division up to √N.
 [ctl] two switches with the same prime [2,2,5]; a switch named 4 [4,3,5] (keeps the product rule, fails the divisor and Möbius
       statements); names 6 and 10 [6,10,7]; the chain [2,4,16] (all divisors are labels, the product rule fails).
 Scope: n = 1..10 all 4^n pairs; n = 11, 12 a seeded sample of 10^6 pairs each; the null-generator reading of AND for all pairs at
 n ≤ 8 and the first 10^5 pairs above. */
import { head, chk, note, finish, loadEngine, loadData, gcd, firstPrimes, factorTD, bigOmega, mobius, isPrimeTD, rng, randInt } from './plib.mjs';
const { bladeMul, sigVec, popcount } = await loadEngine();
const DICT = await loadData('dictionaryData.js');
const ID = 'PRIME-P1';

const namesOf = w => { const n = w.length, out = new Array(1 << n); for (let m = 0; m < (1 << n); m++) { let x = 1n; for (let a = 0; a < n; a++) if ((m >> a) & 1) x *= w[a]; out[m] = x; } return out; };
const bitsStd = m => m.toString(2).split('').filter(c => c === '1').length;     // grade by counting characters, not by the engine

head('P1a. Names from the first n primes: the four lattice operations, grade, Möbius sign, divisors (n = 1..12)');
for (let n = 1; n <= 12; n++) {
  const P = firstPrimes(n).map(BigInt), names = namesOf(P), N = names[(1 << n) - 1], full = (1 << n) - 1;
  const sigs = [sigVec(n, 0), sigVec(0, n), sigVec(Math.ceil(n / 2), Math.floor(n / 2))], ext = [...sigs[2], 1], X = 1 << n;
  // per label: parity from the engine, Möbius / number of prime factors from trial division, NOT from the product with the top blade
  let parOk = 0, gradeOk = 0, evenOk = 0, notOk = 0;
  for (let m = 0; m <= full; m++) {
    const s1 = bladeMul(X, m, ext)[1], s2 = bladeMul(m, X, ext)[1], parity = s1 * s2;           // e_x e_m = parity · e_m e_x
    const om = bigOmega(names[m]);
    if (mobius(names[m]) === parity) parOk++;
    if (om === popcount(m) && om === bitsStd(m)) gradeOk++;
    if ((parity === 1) === (om % 2 === 0)) evenOk++;
    const [c, s] = bladeMul(m, full, sigs[0]); if (c === (full ^ m) && Math.abs(s) === 1 && names[c] === N / names[m] && N % names[m] === 0n) notOk++;
  }
  const L = full + 1;
  chk('bit==std', parOk === L, `n=${n}: (−1)^grade from the engine (commutation with an outside generator) = Möbius of the name, ${parOk}/${L} labels`);
  chk('bit==std', gradeOk === L && evenOk === L, `n=${n}: grade = number of prime factors of the name; even labels = names with an even number of prime factors (${gradeOk}, ${evenOk} of ${L})`);
  chk('bit==std', notOk === L, `n=${n}: NOT a = the label of a·(top blade); its name is N/name(a), N = ${N} (${notOk}/${L})`);
  // the divisors of N by trial division up to √N (Number is exact here: N < 2^53 for n <= 13)
  const Nn = Number(N), dv = []; for (let d = 1; d * d <= Nn; d++) if (Nn % d === 0) { dv.push(d); if (d * d !== Nn) dv.push(Nn / d); }
  const A = dv.map(BigInt).sort((x, y) => (x < y ? -1 : x > y ? 1 : 0)), B = names.slice().sort((x, y) => (x < y ? -1 : x > y ? 1 : 0));
  chk('std', A.length === L && A.every((x, i) => x === B[i]), `n=${n}: the ${L} names are exactly the ${A.length} divisors of N (trial division up to √N)`);
  // pairs
  const all = n <= 10, npairs = all ? L * L : 1000000, r = rng(1000 + n);
  let xorOk = 0, andOk = 0, orOk = 0, sigAgree = 0, nullOk = 0, nullTried = 0, wedgeOk = 0;
  const wedge = sigVec(0, 0, n);
  for (let t = 0; t < npairs; t++) {
    const a = all ? Math.floor(t / L) : randInt(r, L), b = all ? t % L : randInt(r, L);
    const [c0, s0] = bladeMul(a, b, sigs[0]), [c1, s1] = bladeMul(a, b, sigs[1]), [c2, s2] = bladeMul(a, b, sigs[2]);
    if (c0 === c1 && c1 === c2 && c0 === (a ^ b) && Math.abs(s0) === 1 && Math.abs(s1) === 1 && Math.abs(s2) === 1) sigAgree++;
    const A_ = names[a], B_ = names[b], g = gcd(A_, B_);
    if (names[c0] === (A_ * B_) / (g * g) && (A_ * B_) % (g * g) === 0n) xorOk++;
    const andMask = (a + b - c0) / 2, orMask = c0 + andMask;                                          // integer identity a + b = (a xor b) + 2 (a and b)
    if (names[andMask] === g) andOk++;
    if (names[orMask] === (A_ * B_) / g) orOk++;
    if ((bladeMul(a, b, wedge)[1] !== 0) === (g === 1n)) wedgeOk++;
    if (n <= 8 || t < 100000) {                                                                      // AND read from the engine with one null switch at a time
      nullTried++; let m = 0; for (let i = 0; i < n; i++) { const sq = sigs[2].slice(); sq[i] = 0; if (bladeMul(a, b, sq)[1] === 0) m |= 1 << i; }
      let byPrime = 0; for (let i = 0; i < n; i++) if (g % P[i] === 0n) byPrime |= 1 << i;
      if (m === andMask && m === byPrime) nullOk++;
    }
  }
  const sc = all ? `all ${npairs} pairs` : `${npairs} seeded pairs`;
  chk('bit', sigAgree === npairs, `n=${n}: the product label is a XOR b in Cl(${n},0), Cl(0,${n}), Cl(${Math.ceil(n / 2)},${Math.floor(n / 2)}), sign ±1 (${sc})`);
  chk('bit==std', xorOk === npairs, `n=${n}: name(a XOR b) = name(a)·name(b)/gcd² (${sc}, ${xorOk} agree)`);
  chk('bit==std', andOk === npairs && orOk === npairs, `n=${n}: name(a AND b) = gcd and name(a OR b) = lcm (${sc}; ${andOk}, ${orOk})`);
  chk('bit==std', wedgeOk === npairs, `n=${n}: with all ${n} generators null the product is non-zero exactly when the names are coprime (${sc})`);
  chk('bit==std', nullOk === nullTried, `n=${n}: switch i is shared (in a AND b) exactly when the product vanishes with e_i null, exactly when p_i divides the gcd (${nullTried} pairs)`);
}

head('P1b. The Atlas data use the same names (dictionaryData.js ladder[n].prime_names)');
{
  const rows = DICT.ladder.filter(x => x && x.prime_names);
  chk('data', rows.length > 0 && rows.every(x => JSON.stringify(x.prime_names.switch_primes) === JSON.stringify(firstPrimes(x.n)) && x.prime_names.names === 2 ** x.n && x.prime_names.pairs_checked === 4 ** x.n),
    `ladder rows with prime names: n = ${rows.map(x => x.n).join(', ')}; switch primes = the first n primes, 2^n names, 4^n pairs`);
}

head('P1c. Which assignments of names to switches work (brute force)');
const wNames = w => { const n = w.length, out = []; for (let m = 0; m < (1 << n); m++) { let x = 1; for (let a = 0; a < n; a++) if ((m >> a) & 1) x *= w[a]; out.push(x); } return out; };
function props(w) {
  const n = w.length, nm = wNames(w), L = 1 << n, Nn = nm[L - 1];
  let prod = true, andg = true;
  for (let a = 0; a < L && (prod || andg); a++) for (let b = 0; b < L; b++) { const g = gcd(nm[a], nm[b]); if (nm[a ^ b] * g * g !== nm[a] * nm[b]) prod = false; if (nm[a & b] !== g) andg = false; }
  let coprime = true; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (gcd(w[i], w[j]) !== 1) coprime = false;
  const distinctPrimes = w.every(isPrimeTD) && new Set(w).size === n;
  const dv = []; for (let d = 1; d * d <= Nn; d++) if (Nn % d === 0) { dv.push(d); if (d * d !== Nn) dv.push(Nn / d); } dv.sort((x, y) => x - y);
  const sorted = nm.slice().sort((x, y) => x - y), divisors = dv.length === L && dv.every((d, i) => d === sorted[i]);
  let mob = true; for (let m = 0; m < L; m++) if (mobius(nm[m]) !== (bitsStd(m) % 2 ? -1 : 1) || bigOmega(nm[m]) !== bitsStd(m)) mob = false;
  let incl = true; for (let a = 0; a < L; a++) for (let b = 0; b < L; b++) if ((nm[b] % nm[a] === 0) !== ((a & b) === a)) incl = false;   // divisibility <=> inclusion
  const gt1 = w.every(x => x > 1);
  let indep = gt1; for (let a = 0; a < n && indep; a++) for (let T = 0; T < L; T++) if (!((T >> a) & 1) && nm[T] % w[a] === 0) { indep = false; break; }   // no name divides a product of other names
  // the exact shape of "every divisor of N is a label": each name a prime power, and for each prime the exponents are 1, 2, 4, ..., 2^(k-1)
  let chain = gt1; const ex = new Map();
  for (const x of w) { const f = factorTD(x); if (f.size !== 1) { chain = false; break; } const [[p, e]] = [...f]; if (!ex.has(p)) ex.set(p, []); ex.get(p).push(e); }
  if (chain) for (const E of ex.values()) { E.sort((x, y) => x - y); if (!E.every((e, i) => e === 2 ** i)) chain = false; }
  return { prod, andg, coprime, distinctPrimes, divisors, mob, incl, gt1, chain, indep };
}
for (const [n, M] of [[2, 30], [3, 30], [4, 12]]) {
  let tot = 0, cntIncl = 0, bad1 = 0, bad2 = 0, bad3 = 0, bad4 = 0, bad5 = 0, bad6 = 0, cntChain = 0, cntProd = 0, cntDiv = 0; const w = Array(n).fill(1);
  const rec = i => { if (i === n) { tot++; const p = props(w); if (p.prod) cntProd++; if (p.divisors) cntDiv++;
      if (p.prod !== p.coprime) bad1++; if (p.andg !== p.coprime) bad2++; if ((p.divisors && p.prod) !== p.distinctPrimes) bad3++; if (p.mob !== (p.distinctPrimes)) bad4++;
      if (p.incl !== p.indep || (p.coprime && p.gt1 && !p.incl)) bad5++; if (p.incl && !p.coprime) cntIncl++; if (p.divisors !== p.chain) bad6++; if (p.divisors && !p.prod) cntChain++; return; }
    for (let v = 1; v <= M; v++) { w[i] = v; rec(i + 1); } };
  rec(0);
  chk('std', bad1 === 0 && bad2 === 0, `n=${n}, names 1..${M}: product rule ⇔ AND = gcd ⇔ pairwise coprime names, all ${tot} assignments (${cntProd} satisfy it)`);
  chk('std', bad5 === 0, `n=${n}, names 1..${M}: divisibility of names ⇔ inclusion of labels, exactly when no name divides a product of other names; coprime names > 1 always qualify (${tot} assignments; ${cntIncl} qualify without being coprime, e.g. [4,6])`);
  chk('std', bad3 === 0, `n=${n}, names 1..${M}: product rule and "the labels are exactly the divisors of N" together ⇔ the names are ${n} distinct primes (${tot} assignments)`);
  chk('std', bad6 === 0, `n=${n}, names 1..${M}: "the labels are exactly the divisors of N" alone ⇔ every name is a prime power and each prime's exponents are 1, 2, 4, ... (${cntDiv} assignments, ${cntChain} of them chains that break the product rule)`);
  chk('std', bad4 === 0, `n=${n}, names 1..${M}: "grade = number of prime factors and (−1)^grade = Möbius" for every label ⇔ distinct primes (${tot} assignments)`);
}

head('P1d. Controls: wrong names must fail');
{
  const c1 = props([2, 2, 5]), c2 = props([4, 3, 5]), c3 = props([6, 10, 7]);
  chk('ctl', !c1.prod && !c1.andg && !c1.divisors, 'two switches with the same prime [2,2,5]: product rule fails (2·2/2² = 1, but the XOR label is named 4), AND = gcd fails, divisors fail');
  chk('ctl', c2.prod && c2.andg && !c2.divisors && !c2.mob, 'a switch named 4 [4,3,5]: product rule and AND = gcd still hold (coprime), but 2 divides N and is no label, and the Möbius sign of 4 is 0, not −1');
  chk('ctl', !c3.prod && !c3.andg, 'names 6 and 10 [6,10,7]: 6·10/2² = 15 is not the name 60 of the XOR label; gcd(6,10) = 2 is no label');
  const c4 = props([2, 4, 16]);
  chk('ctl', c4.divisors && !c4.prod && !c4.incl, 'the chain [2,4,16] names every label 2^(integer label): all divisors of 2^7 are labels, but names multiply by adding integer labels (with carries), so the product rule and divisibility ⇔ inclusion fail');
  const fx = factorTD(60); note(`60 = ${[...fx].map(([p, e]) => p + (e > 1 ? '^' + e : '')).join('·')}`);
}
finish(ID);
