#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P2. Seats: the exclusion rule as square-freeness, the sign as a count.   node p2_seats.mjs

 Statement (n = 1..6 seats, seat i named by the (i+1)-th prime p_i, pattern S named by the product of the primes of its full seats):
 c_i⁺|S⟩ ≠ 0 ⇔ p_i does not divide name(S); c_i|S⟩ ≠ 0 ⇔ p_i divides name(S); the image is named name(S)·p_i or name(S)/p_i; the sign
 of c_i⁺ on S is (−1)^(number of prime factors of name(S) smaller than p_i); the parity (−1)^F is the Möbius function of name(S); a second
 particle in a full seat would be named p·p, a number that is not square-free, and (c_i⁺)² = 0.
 [std] Jordan–Wigner matrices from Kronecker products of 2×2 integer matrices (Z on the seats before i), the anticommutation relations,
       (−1)^F = Π (1 − 2 c_i⁺ c_i); names by trial division.
 [bit] (1) inside Cl(n,n) with mul and sigVec(n,n): c_i⁺ = (e_i + f_i)/2, c_i = (e_i − f_i)/2 (a null pair), vacuum Ω = Π c_i c_i⁺,
       states |S⟩ = c_{s1}⁺ ⋯ c_{sk}⁺ Ω (s1 < ... < sk), the action read off as ±|S'⟩ or 0; (2) on the labels of Cl(n,0): c_i⁺ = (L_i + R_i)/2
       (wedge), c_i = (L_i − R_i)/2 (contraction), L_i x = e_i x, R_i x = α(x) e_i, with bladeMul: the label basis is the Fock basis.
 [ctl] no string (the anticommutation must fail); the string on the seats after i (the relations hold, the prime-count sign must fail);
       the exclusion dropped (a full seat accepted: nilpotency and square-freeness must fail).
 Scope: n = 1..6, every seat and every pattern. */
import { head, chk, note, finish, loadEngine, cmat, cI, cmul, cadd, cscale, ceq, czero, ckron, cget, firstPrimes, factorTD, mobius, squarefree } from './plib.mjs';
const { bladeMul, sigVec, mul, mvZero, popcount } = await loadEngine();
const ID = 'PRIME-P2';

const Z2 = cmat(2, [1, 0, 0, -1]), I2 = cI(2), SP = cmat(2, [0, 0, 1, 0]), SM = cmat(2, [0, 1, 0, 0]), N1 = cmat(2, [0, 0, 0, 1]);
// operator on n seats: factor for seat j acts on bit j of the Fock index (seat n-1 is the leftmost Kronecker factor)
const onSeats = (n, f) => { let M = f(n - 1); for (let j = n - 2; j >= 0; j--) M = ckron(M, f(j)); return M; };
const jw = (n, i, kind) => onSeats(n, j => (j === i ? (kind === '+' ? SP : SM) : (j < i ? Z2 : I2)));
const jwAfter = (n, i, kind) => onSeats(n, j => (j === i ? (kind === '+' ? SP : SM) : (j > i ? Z2 : I2)));
const noString = (n, i, kind) => onSeats(n, j => (j === i ? (kind === '+' ? SP : SM) : I2));
const anti = (A, B) => cadd(cmul(A, B), cmul(B, A));
function carOk(n, mk) {
  const d = 1 << n, Zd = cscale(cI(d), 0), Id = cI(d); let ok = true;
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    const ci = mk(n, i, '-'), cj = mk(n, j, '-'), cjp = mk(n, j, '+'), cip = mk(n, i, '+');
    if (!ceq(anti(ci, cjp), i === j ? Id : Zd) || !ceq(anti(ci, cj), Zd) || !ceq(anti(cip, cjp), Zd)) ok = false;
  }
  return ok;
}
const primesBelow = (x, p) => [...factorTD(x).keys()].filter(q => q < p).length;   // number of prime factors of x smaller than p

for (let n = 1; n <= 6; n++) {
  head(`P2, n = ${n} seats (primes ${firstPrimes(n).join(', ')})`);
  const P = firstPrimes(n), d = 1 << n, names = []; for (let S = 0; S < d; S++) { let x = 1; for (let a = 0; a < n; a++) if ((S >> a) & 1) x *= P[a]; names.push(x); }
  const CP = [], CM = []; for (let i = 0; i < n; i++) { CP.push(jw(n, i, '+')); CM.push(jw(n, i, '-')); }
  chk('std', carOk(n, jw), `Jordan–Wigner matrices (${d}×${d}) satisfy {c_i, c_j⁺} = δ_ij, {c_i, c_j} = {c_i⁺, c_j⁺} = 0`);
  // names against the std matrices
  let excl = 0, ann = 0, img = 0, sgn = 0, cnt = 0;
  for (let i = 0; i < n; i++) for (let S = 0; S < d; S++) {
    cnt++;
    let tp = -1, vp = 0, tm = -1, vm = 0; for (let T = 0; T < d; T++) { const [a] = cget(CP[i], T, S), [b] = cget(CM[i], T, S); if (a) { tp = T; vp = a; } if (b) { tm = T; vm = b; } }
    const coprime = names[S] % P[i] !== 0;
    if ((tp >= 0) === coprime) excl++;
    if ((tm >= 0) === !coprime) ann++;
    if ((tp < 0 || names[tp] === names[S] * P[i]) && (tm < 0 || names[tm] === names[S] / P[i])) img++;
    if (tp < 0 || vp === (primesBelow(names[S], P[i]) % 2 ? -1 : 1)) sgn++;
  }
  chk('std', excl === cnt, `c_i⁺|S⟩ ≠ 0 exactly when p_i and name(S) are coprime (${excl}/${cnt} seat-pattern pairs)`);
  chk('std', ann === cnt, `c_i|S⟩ ≠ 0 exactly when p_i divides name(S) (${ann}/${cnt})`);
  chk('std', img === cnt, `the image is named name(S)·p_i (creation) and name(S)/p_i (annihilation) (${img}/${cnt})`);
  chk('std', sgn === cnt, `the sign of c_i⁺ on S is (−1)^(number of prime factors of name(S) smaller than p_i) (${sgn}/${cnt})`);
  let Par = cI(d); for (let i = 0; i < n; i++) Par = cmul(Par, cadd(cI(d), cscale(cmul(CP[i], CM[i]), -2)));
  let par = 0; for (let S = 0; S < d; S++) { let off = true; for (let T = 0; T < d; T++) if (T !== S && cget(Par, T, S)[0]) off = false; if (off && cget(Par, S, S)[0] === mobius(names[S])) par++; }
  chk('std', par === d, `(−1)^F = Π(1 − 2c_i⁺c_i) is diagonal with entry μ(name(S)) on every pattern (${par}/${d})`);
  let nil = true, rep = true; for (let i = 0; i < n; i++) { if (!czero(cmul(CP[i], CP[i]))) nil = false; for (let S = 0; S < d; S++) if (names[S] % P[i] === 0 && squarefree(names[S] * P[i])) rep = false; }
  chk('std', nil && rep, `(c_i⁺)² = 0, and a second particle in a full seat is named p_i·p_i·…, never square-free`);

  // [bit] (2): the labels of Cl(n,0); wedge (L+R)/2 and contraction (L-R)/2 from bladeMul
  const sq = sigVec(n, 0); let lab = 0, labc = 0;
  for (let i = 0; i < n; i++) for (let S = 0; S < d; S++) {
    const [m1, s1] = bladeMul(1 << i, S, sq), [m2, s2] = bladeMul(S, 1 << i, sq), al = popcount(S) % 2 ? -1 : 1;
    const w = (s1 + al * s2) / 2, c = (s1 - al * s2) / 2;   // coefficients of e_(S xor i) in (L_i ± R_i)/2 e_S
    let ok = m1 === m2 && m1 === (S ^ (1 << i));
    for (let T = 0; T < d; T++) { const [a] = cget(CP[i], T, S), [b] = cget(CM[i], T, S); if (a !== (T === m1 ? w : 0) || b !== (T === m1 ? c : 0)) ok = false; }
    if (ok) lab++; labc++;
  }
  chk('bit==std', lab === labc, `labels of Cl(${n},0): (L_i + R_i)/2 and (L_i − R_i)/2 from bladeMul equal the Jordan–Wigner c_i⁺ and c_i entry by entry (${lab}/${labc})`);

  // [bit] (1): inside Cl(n,n) by mul, null pairs, vacuum and states
  const sqn = sigVec(n, n), D = 1 << (2 * n), vec = (pairs) => { const v = mvZero(2 * n); for (const [m, c] of pairs) v[m] += c; return v; };
  const cp = [], cm = []; for (let i = 0; i < n; i++) { cp.push(vec([[1 << i, 0.5], [1 << (n + i), 0.5]])); cm.push(vec([[1 << i, 0.5], [1 << (n + i), -0.5]])); }
  let nullOk = true; for (let i = 0; i < n; i++) { const a = mul(cp[i], cp[i], sqn), b = mul(cm[i], cm[i], sqn); if (a.some(x => x) || b.some(x => x)) nullOk = false; }
  let Om = vec([[0, 1]]); for (let i = 0; i < n; i++) Om = mul(Om, mul(cm[i], cp[i], sqn), sqn);
  const st = []; for (let S = 0; S < d; S++) { let v = Om; for (let i = n - 1; i >= 0; i--) if ((S >> i) & 1) v = mul(cp[i], v, sqn); st.push(v); }
  const prop = (v, w) => { let s = 0; for (let k = 0; k < D; k++) { if (!v[k] && !w[k]) continue; if (!w[k]) return 0; const r = v[k] / w[k]; if (s === 0) s = r; else if (r !== s) return 0; } return s; };
  const nonzero = st.every(v => v.some(x => x));
  let fock = 0, fc = 0;
  for (let i = 0; i < n; i++) for (let S = 0; S < d; S++) {
    fc++;
    const up = mul(cp[i], st[S], sqn), dn = mul(cm[i], st[S], sqn);
    const T1 = S | (1 << i), T2 = S & ~(1 << i);
    const sUp = up.some(x => x) ? prop(up, st[T1]) : 0, sDn = dn.some(x => x) ? prop(dn, st[T2]) : 0;
    const [a] = (S >> i) & 1 ? [0] : cget(CP[i], T1, S), [b] = (S >> i) & 1 ? cget(CM[i], T2, S) : [0];
    if (sUp === a && sDn === b) fock++;
  }
  chk('bit', nullOk && nonzero, `Cl(${n},${n}): (e_i ± f_i)/2 square to 0; the ${d} states c_S⁺Ω are non-zero (${D} blades)`);
  chk('bit==std', fock === fc, `Cl(${n},${n}): c_i⁺ and c_i act on the states c_S⁺Ω with the Jordan–Wigner entries (${fock}/${fc})`);

  if (n >= 2) {
    chk('ctl', !carOk(n, noString), 'no string: the anticommutation relations fail');
    const after = []; for (let i = 0; i < n; i++) after.push(jwAfter(n, i, '+'));
    let sgnAfter = 0; for (let i = 0; i < n; i++) for (let S = 0; S < d; S++) { if ((S >> i) & 1) continue; const T = S | (1 << i); if (cget(after[i], T, S)[0] === (primesBelow(names[S], P[i]) % 2 ? -1 : 1)) sgnAfter++; }
    chk('ctl', carOk(n, jwAfter) && sgnAfter < n * d / 2, `string on the seats after i: the relations hold, but the prime-count sign holds on only ${sgnAfter} of ${n * d / 2} creations`);
  }
  let drop = true, exclBroken = true; for (let i = 0; i < n; i++) { const X = cadd(CP[i], onSeats(n, j => (j === i ? N1 : I2))); if (czero(cmul(X, X))) drop = false;
    let seen = false; for (let S = 0; S < d; S++) if (names[S] % P[i] === 0) { for (let T = 0; T < d; T++) if (cget(X, T, S)[0]) seen = true; } if (!seen) exclBroken = false; }
  chk('ctl', drop && exclBroken, 'exclusion dropped (a full seat accepted): the square is no longer 0, and "non-zero ⇔ coprime" fails on every seat');
}
note('the Fock basis is the label basis: the 2^n patterns S are the 2^n labels (Atlas: core_check.py core·B10 and B10b; the doubling Cl(V) ⊗ Cl(−V) = End Cl(V))');
finish(ID);
