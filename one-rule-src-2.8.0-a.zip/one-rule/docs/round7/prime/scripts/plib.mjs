// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// plib.mjs: the check lines of the prime scripts (head / chk / finish, the layout of b1lib.py) and their standard helpers.
// Everything below except loadEngine / loadData is independent of the engine: trial division, Euclid's gcd, BigInt binomials,
// a seeded generator, small integer and Gaussian-integer matrices. The package files are found at ../../../v16/ from this
// folder, or in the folder named by the environment variable ATLAS_DIR.
import { pathToFileURL } from 'url';

export const FAILS = [];
export const head = s => console.log('\n' + s);
export function chk(tag, cond, msg) { console.log(`  ${cond ? 'ok  ' : 'FAIL'} [${tag}] ${msg}`); if (!cond) FAILS.push(`[${tag}] ${msg}`); return !!cond; }
export const note = s => console.log(`  ..   ${s}`);
export function finish(id) { console.log(`\nFAILS (${id}): ${FAILS.length ? FAILS.join('; ') : 'none'}`); process.exit(FAILS.length ? 1 : 0); }

export const atlasURL = f => (process.env.ATLAS_DIR ? pathToFileURL(process.env.ATLAS_DIR.replace(/\/?$/, '/') + f) : new URL('../../../v16/' + f, import.meta.url));
export const loadEngine = () => import(atlasURL('labelsEngine.js'));
export const loadData = async f => (await import(atlasURL(f))).default;

// ---------------------------------------------------------------- integers (Number or BigInt), never the engine
export const gcd = (a, b) => { while (b) [a, b] = [b, a % b]; return a < 0 ? -a : a; };
export function isPrimeTD(x) { x = Number(x); if (x < 2) return false; for (let d = 2; d * d <= x; d++) if (x % d === 0) return false; return true; }
export function firstPrimes(n) { const P = []; for (let x = 2; P.length < n; x++) if (isPrimeTD(x)) P.push(x); return P; }
export function primesUpTo(m) { const P = []; for (let x = 2; x <= m; x++) if (isPrimeTD(x)) P.push(x); return P; }
// trial division; x a Number (exact) or a BigInt; returns Map(prime -> exponent) with Number keys
export function factorTD(x) {
  const f = new Map(), big = typeof x === 'bigint';
  if (big) { let y = x, d = 2n; while (d * d <= y) { while (y % d === 0n) { f.set(Number(d), (f.get(Number(d)) || 0) + 1); y /= d; } d += 1n; } if (y > 1n) f.set(Number(y), (f.get(Number(y)) || 0) + 1); return f; }
  let y = x; for (let d = 2; d * d <= y; d++) while (y % d === 0) { f.set(d, (f.get(d) || 0) + 1); y /= d; }
  if (y > 1) f.set(y, (f.get(y) || 0) + 1); return f;
}
export const bigOmega = x => [...factorTD(x).values()].reduce((s, e) => s + e, 0);   // number of prime factors with multiplicity
export const mobius = x => { const f = factorTD(x); for (const e of f.values()) if (e > 1) return 0; return f.size % 2 ? -1 : 1; };
export const squarefree = x => [...factorTD(x).values()].every(e => e === 1);
export function binom(n, k) { if (k < 0 || k > n) return 0n; let r = 1n; const K = BigInt(k), N = BigInt(n); for (let i = 1n; i <= K; i++) r = r * (N - K + i) / i; return r; }
export const ordMod = (a, p) => { let x = a % p, n = 1; while (x !== 1) { x = (x * a) % p; n++; if (n > p) return null; } return n; };
// Legendre / Kronecker symbol (a/p) for an odd prime p by Euler's criterion; (a/2) by the Kronecker rule (0 for even a, +1 for a = +-1 mod 8, -1 for a = +-3 mod 8)
export function legendre(a, p) {
  if (p === 2) { const r = ((a % 8) + 8) % 8; return a % 2 === 0 ? 0 : (r === 1 || r === 7 ? 1 : -1); }
  const e = (p - 1) / 2; let base = ((a % p) + p) % p, r = 1, k = e; if (base === 0) return 0;
  let b = BigInt(base), R = 1n; const P = BigInt(p); let K = BigInt(k); while (K > 0n) { if (K & 1n) R = R * b % P; b = b * b % P; K >>= 1n; } r = Number(R);
  return r === 1 ? 1 : -1;
}

// ---------------------------------------------------------------- a seeded generator (mulberry32) and sampling
export function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
export const randInt = (r, m) => Math.floor(r() * m);
export function shuffle(r, arr) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = randInt(r, i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; }
export function* permutations(arr) { if (arr.length <= 1) { yield arr.slice(); return; } for (let i = 0; i < arr.length; i++) { const rest = arr.slice(0, i).concat(arr.slice(i + 1)); for (const p of permutations(rest)) yield [arr[i], ...p]; } }
export function* subsets(arr, k, start = 0, acc = []) { if (acc.length === k) { yield acc.slice(); return; } for (let i = start; i <= arr.length - (k - acc.length); i++) { acc.push(arr[i]); yield* subsets(arr, k, i + 1, acc); acc.pop(); } }

// ---------------------------------------------------------------- Gaussian-integer matrices {d, re[], im[]} (row-major), never the engine
export const cmat = (d, re, im) => ({ d, re: re.slice(), im: (im || Array(d * d).fill(0)).slice() });
export const cI = d => { const re = Array(d * d).fill(0); for (let i = 0; i < d; i++) re[i * d + i] = 1; return cmat(d, re); };
export function cmul(A, B) {
  const d = A.d, re = Array(d * d).fill(0), im = Array(d * d).fill(0);
  for (let i = 0; i < d; i++) for (let k = 0; k < d; k++) { const ar = A.re[i * d + k], ai = A.im[i * d + k]; if (!ar && !ai) continue;
    for (let j = 0; j < d; j++) { const br = B.re[k * d + j], bi = B.im[k * d + j]; re[i * d + j] += ar * br - ai * bi; im[i * d + j] += ar * bi + ai * br; } }
  return { d, re, im };
}
export const cadd = (A, B) => ({ d: A.d, re: A.re.map((x, i) => x + B.re[i]), im: A.im.map((x, i) => x + B.im[i]) });
export const cscale = (A, s) => ({ d: A.d, re: A.re.map(x => x * s), im: A.im.map(x => x * s) });
export const ctimesI = A => ({ d: A.d, re: A.im.map(x => -x), im: A.re.slice() });
export const ceq = (A, B) => A.d === B.d && A.re.every((x, i) => x === B.re[i]) && A.im.every((x, i) => x === B.im[i]);
export const czero = A => A.re.every(x => x === 0) && A.im.every(x => x === 0);
export function ckron(A, B) {
  const d = A.d * B.d, re = Array(d * d).fill(0), im = Array(d * d).fill(0);
  for (let i1 = 0; i1 < A.d; i1++) for (let j1 = 0; j1 < A.d; j1++) { const ar = A.re[i1 * A.d + j1], ai = A.im[i1 * A.d + j1]; if (!ar && !ai) continue;
    for (let i2 = 0; i2 < B.d; i2++) for (let j2 = 0; j2 < B.d; j2++) { const br = B.re[i2 * B.d + j2], bi = B.im[i2 * B.d + j2], r = (i1 * B.d + i2) * d + j1 * B.d + j2; re[r] = ar * br - ai * bi; im[r] = ar * bi + ai * br; } }
  return { d, re, im };
}
export function cblock(A, B) { const d = A.d + B.d, M = cmat(d, Array(d * d).fill(0)); for (let i = 0; i < A.d; i++) for (let j = 0; j < A.d; j++) { M.re[i * d + j] = A.re[i * A.d + j]; M.im[i * d + j] = A.im[i * A.d + j]; } for (let i = 0; i < B.d; i++) for (let j = 0; j < B.d; j++) { M.re[(A.d + i) * d + A.d + j] = B.re[i * B.d + j]; M.im[(A.d + i) * d + A.d + j] = B.im[i * B.d + j]; } return M; }
export const cget = (A, i, j) => [A.re[i * A.d + j], A.im[i * A.d + j]];
