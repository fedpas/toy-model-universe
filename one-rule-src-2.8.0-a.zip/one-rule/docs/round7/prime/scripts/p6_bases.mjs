#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P6. Other readings of "base".   node p6_bases.mjs

 (b) Mixed radix: the primorial place values 1, 2, 6, 30, 210, ... are the names of the labels 2^k − 1 (the first k switches on), as the
     binary place values 1, 2, 4, 8 are the integer labels of the single switches. Test: is the XOR rule visible digit by digit in the
     primorial expansion of the names (is each digit of name(a XOR b) a function of the same digit of name(a) and name(b))? Control:
     the binary digits of the integer labels must pass the same test (digit XOR).
 (c) Cl(p+8,q) against Cl(p,q) from wedderburn: same type, matrix size × 16 (Cl(n+8) = Cl(n) ⊗ M16(R)), for every p + q ≤ 8; the names
     of the bigger cube multiply the old name by the name of the eight new switches, and the top name by the product of the eight new
     primes. [bit] wedderburn, bladeMul; [std] the recalled table of the eight types, BigInt products.
 Scope: (b) n = 1..6, all pairs; (c) p + q ≤ 8, names to n = 16. */
import { head, chk, note, finish, loadEngine, firstPrimes, gcd } from './plib.mjs';
const { bladeMul, sigVec, wedderburn } = await loadEngine();
const ID = 'PRIME-P6';

head('P6b. Primorial place values against binary place values');
{
  const P = firstPrimes(12); let prim = 1n, ok = true; for (let k = 0; k <= 12; k++) { let nm = 1n; for (let a = 0; a < k; a++) nm *= BigInt(P[a]); if (nm !== prim) ok = false; if (k < 12) prim *= BigInt(P[k]); }
  chk('std', ok, 'the primorial place values 1, 2, 6, 30, 210, 2310, ... are the names of the labels 2^k − 1 (first k switches on), k = 0..12');
  const digits = (m, R) => { const d = []; for (const r of R) { d.push(m % r); m = Math.floor(m / r); } d.push(m); return d; };
  for (let n = 1; n <= 6; n++) {
    const Pn = firstPrimes(n), L = 1 << n, name = S => { let x = 1; for (let a = 0; a < n; a++) if ((S >> a) & 1) x *= Pn[a]; return x; }, R = firstPrimes(n + 1);
    const funcPrim = new Map(), funcBin = new Map(); let primFn = true, binFn = true;
    for (let a = 0; a < L; a++) for (let b = 0; b < L; b++) {
      const [c] = bladeMul(a, b, sigVec(n, 0)), da = digits(name(a), R), db = digits(name(b), R), dc = digits(name(c), R);
      da.forEach((x, k) => { const key = `${k}|${x}|${db[k]}`; if (funcPrim.has(key) && funcPrim.get(key) !== dc[k]) primFn = false; funcPrim.set(key, dc[k]); });
      for (let k = 0; k < n; k++) { const key = `${k}|${(a >> k) & 1}|${(b >> k) & 1}`, v = (c >> k) & 1; if (funcBin.has(key) && funcBin.get(key) !== v) binFn = false; funcBin.set(key, v); }
    }
    if (n >= 2) chk('std', !primFn, `n=${n}: the primorial digits of name(a XOR b) are not a digit-by-digit function of those of name(a), name(b): the expansion does not carry the rule`);
    chk('ctl', binFn, `n=${n}: the binary digits of the integer labels do carry it (digit by digit XOR)`);
  }
  note('example: names 6 = (0,0,1), 10 = (0,2,1), 15 = (1,1,2) in place values 1, 2, 6: the digits do not follow the switches');
}

head('P6c. The rung n + 8 is the rung n tensored with M16(R)');
{
  const TAB = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C'];   // recalled: type of Cl(p,q) by (p − q) mod 8
  let ok = true, cnt = 0;
  for (let n = 0; n <= 8; n++) for (let p = 0; p <= n; p++) { const q = n - p, a = wedderburn(p, q), b = wedderburn(p + 8, q), c = wedderburn(p, q + 8); cnt++;
    if (!(a.type === b.type && a.type === c.type && b.k === 16 * a.k && c.k === 16 * a.k && b.dim === 256 * a.dim && a.type === TAB[(((p - q) % 8) + 8) % 8])) ok = false; }
  chk('bit==std', ok, `Cl(p+8,q) and Cl(p,q+8) have the type of Cl(p,q) and 16 times its matrix size, all ${cnt} cells with p + q ≤ 8 (type from the recalled table)`);
  let nm = true; const P = firstPrimes(16).map(BigInt);
  for (let n = 0; n <= 8; n++) { let old = 1n, nw = 1n, all = 1n; for (let a = 0; a < n; a++) old *= P[a]; for (let a = n; a < n + 8; a++) nw *= P[a]; for (let a = 0; a < n + 8; a++) all *= P[a]; if (all !== old * nw || gcd(old, nw) !== 1n) nm = false; }
  chk('std', nm, 'the top name of n + 8 switches is the old top name times the product of the eight new primes (coprime factors), n = 0..8');
  note('so a label of the bigger cube is a pair (old label, new label) and its name the product of the two names: the rule a·b/gcd² works factor by factor');
}
finish(ID);
