#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
/* PRIME-P8. Which blade the "210 checkpoint" is, and what is exact about it.   node p8_checkpoint.mjs

 The Atlas's texts (matrixData.js row Sector_GUT_Junction, node-metadata.js, genesis_audit_v3.js, claim ATL-022) place it at grade 4
 ("Grade 4 Quadrivector", "3-face"), in the cell B+F = 8, B−F = −4, i.e. Cl(2,6) = M8(H), with the track pattern [1, 1, 1, 1] and the
 primorial 2·3·5·7. With the dictionary's names (switch a ↦ the (a+1)-th prime) the blade named 210 is the label S = {0,1,2,3}.
 [bit] bladeMul: its square for each of the 28 placements of the two + signs among the eight switches; the grade-4 blades that square to
       −1 in sigVec(2,6); over all 8! orderings of the primes, which blade carries the name 210.
 [std] a 16 × 16 complex representation of Cl(2,6) for every placement (eight anticommuting Kronecker products of Pauli matrices, the
       six − generators multiplied by i); the square read from the matrices; counts C(8,4) = 70 and 16·70 = 1120; the type M8(H) from the
       recalled table; names by plain multiplication.
 [ctl] a square formula without the reversal sign must disagree with the engine on some blade; the integer label 210 (bits 11010010) is
       not the blade named 210; with the primes in the reverse order the name 210 sits on another blade.
 Nothing here says what 210 means. */
import fs from 'fs';
import { fileURLToPath } from 'url';
import { head, chk, note, finish, loadEngine, loadData, atlasURL, cmat, cI, cmul, ceq, cscale, ctimesI, ckron, firstPrimes, permutations } from './plib.mjs';
const { bladeMul, sigVec, popcount, wedderburn } = await loadEngine();
const DICT = await loadData('dictionaryData.js');
const { CLAIMS } = await import(atlasURL('claimsData.js'));
const ID = 'PRIME-P8';
const txt = f => fs.readFileSync(fileURLToPath(atlasURL(f)), 'utf8');

head('P8a. What the Atlas texts say');
{
  const row = txt('matrixData.js').split('\n').find(l => l.includes("['Sector_GUT_Junction'")) || '';
  const meta = txt('node-metadata.js'), gen = txt('genesis_audit_v3.js'), atl = CLAIMS.find(c => c.id === 'ATL-022');
  chk('data', /Grade 4 Quadrivector/.test(row) && /B\+F=8, B-F=-4/.test(row) && /3-face/.test(row) && /\[1, 1, 1, 1\]/.test(row) && /210/.test(row), "matrixData.js row Sector_GUT_Junction: grade 4, cell B+F=8, B−F=−4, a 3-face, track pattern [1, 1, 1, 1], the primorial 210");
  chk('data', /primorial product number 210 \(2 \* 3 \* 5 \* 7\)/.test(meta) && /Cl\(2,6\)=M₈\(ℍ\) at \[8,−4\] is verified; whether 210 means anything is open/.test(gen), 'node-metadata.js names 210 = 2·3·5·7; genesis_audit_v3.js: Cl(2,6) = M8(H) at [8,−4] verified, the meaning of 210 open');
  chk('data', !!atl && /Cl\(2,6\)≅M₈\(ℍ\)/.test(atl.en[0].text) && /70 four-vertex faces/.test(atl.en[0].text) && /1120/.test(atl.en[0].text) && /not derived/.test(atl.en[1].text), 'ATL-022: Cl(2,6) ≅ M8(H), 70 four-vertex faces, 1120 four-dimensional faces; 210 not derived');
}

head('P8b. The cell and the blade');
const P8 = firstPrimes(8), nameOf = (m, P = P8) => { let x = 1; for (let a = 0; a < 8; a++) if ((m >> a) & 1) x *= P[a]; return x; };
{
  const w = wedderburn(2, 6), B = (8 + -4) / 2, F = (8 - -4) / 2;
  let faces4 = 0; for (let m = 0; m < 256; m++) if (popcount(m) === 4) faces4++;
  chk('bit==std', B === 2 && F === 6 && w.type === 'H' && w.k === 8 && ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C'][((2 - 6) % 8 + 8) % 8] === 'H' && faces4 === 70 && 16 * faces4 === 1120,
    'B + F = 8, B − F = −4 gives Cl(2,6) = M8(H) (engine; recalled table); 70 grade-4 labels = four-vertex faces of the 7-simplex; 16·70 = 1120 four-dimensional faces of the 8-cube');
  const named = [...Array(256).keys()].filter(m => nameOf(m) === 210);
  chk('std', JSON.stringify(named) === '[15]' && popcount(15) === 4, 'with the dictionary names exactly one blade is named 210: the label S = {0,1,2,3} (integer label 15, grade 4, a 3-face): the "210 checkpoint" read as a blade');
}

head('P8c. Its square, for every placement of the two + signs');
// std: eight anticommuting 16x16 matrices squaring to +1 (Kronecker products of Pauli matrices), times i for the − generators
const X = cmat(2, [0, 1, 1, 0]), Y = cmat(2, [0, 0, 0, 0], [0, -1, 1, 0]), Z = cmat(2, [1, 0, 0, -1]), I2 = cI(2);
const kr = fs_ => fs_.reduce((A, B) => ckron(A, B));
const GAM = []; for (let j = 0; j < 4; j++) for (const T of [X, Y]) GAM.push(kr([...Array(j).fill(Z), T, ...Array(3 - j).fill(I2)]));
let placementsOk = true; const byOverlap = { 0: new Set(), 1: new Set(), 2: new Set() }, cnt = { 0: 0, 1: 0, 2: 0 }; let defaultSq = null;
for (let a = 0; a < 8; a++) for (let b = a + 1; b < 8; b++) {
  const sq = Array(8).fill(-1); sq[a] = 1; sq[b] = 1;
  const gens = GAM.map((G, i) => (sq[i] > 0 ? G : ctimesI(G)));
  let M = cI(16); for (const i of [0, 1, 2, 3]) M = cmul(M, gens[i]); const M2 = cmul(M, M);
  const stdSq = ceq(M2, cI(16)) ? 1 : ceq(M2, cscale(cI(16), -1)) ? -1 : 0, [m0, s] = bladeMul(15, 15, sq);
  let gensOk = true; for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) { const A = cmul(gens[i], gens[j]), Bm = cmul(gens[j], gens[i]); if (i === j ? !ceq(A, cscale(cI(16), sq[i])) : !ceq(A, cscale(Bm, -1))) gensOk = false; }
  if (!(gensOk && m0 === 0 && s === stdSq)) placementsOk = false;
  const ov = [a, b].filter(x => x < 4).length; byOverlap[ov].add(s); cnt[ov]++; if (a === 0 && b === 1) defaultSq = s;
}
chk('bit==std', placementsOk, 'all 28 placements: the matrices satisfy the Clifford relations of Cl(2,6), and the square of e0e1e2e3 from the matrices equals bladeMul');
chk('bit', JSON.stringify([...byOverlap[0]]) === '[1]' && JSON.stringify([...byOverlap[1]]) === '[-1]' && JSON.stringify([...byOverlap[2]]) === '[1]' && cnt[0] === 6 && cnt[1] === 16 && cnt[2] === 6 && defaultSq === 1,
  'e0e1e2e3 squares to −1 exactly when one of the two + generators is among switches 0..3 (16 placements); to +1 when both are (6) or none is (6); in sigVec(2,6) (+ on switches 0, 1) it squares to +1');

head('P8d. The grade-4 blades that square to −1');
{
  const sq = sigVec(2, 6), minus = [...Array(256).keys()].filter(m => popcount(m) === 4 && bladeMul(m, m, sq)[1] === -1);
  const names = minus.map(m => nameOf(m)).sort((x, y) => x - y);
  chk('bit', minus.length === 40 && minus.every(m => [0, 1].filter(i => (m >> i) & 1).length === 1) && !names.includes(210), 'in sigVec(2,6): 40 of the 70 grade-4 blades square to −1, those with exactly one of the two + switches; 210 is not among their names');
  note('their names: ' + names.join(', '));
  let inv = true; for (let a = 0; a < 8; a++) for (let b = a + 1; b < 8; b++) { const s2 = Array(8).fill(-1); s2[a] = 1; s2[b] = 1; if ([...Array(256).keys()].filter(m => popcount(m) === 4 && bladeMul(m, m, s2)[1] === -1).length !== 40) inv = false; }
  chk('bit', inv, 'for every placement of the two + signs, 40 of the 70 grade-4 blades square to −1 (the count does not depend on the placement; which blades do, does)');
  const s04 = Array(8).fill(-1); s04[0] = 1; s04[4] = 1; const m04 = [...Array(256).keys()].filter(m => popcount(m) === 4 && bladeMul(m, m, s04)[1] === -1);
  chk('bit', m04.includes(15) && m04.length === 40, 'e.g. with + on switches 0 and 4 (primes 2 and 11) the blade named 210 is one of the 40 that square to −1');
}

head('P8e. The name 210 under every ordering of the primes');
{
  const perBlade = new Map(); let alwaysOne = true, minusCount = 0; const sq = sigVec(2, 6);
  for (const perm of permutations(P8)) { let m210 = 0, k = 0; for (let a = 0; a < 8; a++) if ([2, 3, 5, 7].includes(perm[a])) { m210 |= 1 << a; k++; }
    if (k !== 4) alwaysOne = false; perBlade.set(m210, (perBlade.get(m210) || 0) + 1); if (bladeMul(m210, m210, sq)[1] === -1) minusCount++; }
  const counts = [...perBlade.values()];
  chk('std', alwaysOne && perBlade.size === 70 && counts.every(c => c === 576), 'over all 40320 orderings exactly one blade is named 210 each time, and it is each of the 70 grade-4 blades in turn (576 = 4!·4! orderings each): no blade is named 210 under every ordering');
  chk('bit', minusCount === 23040, `in sigVec(2,6) the blade named 210 squares to −1 for ${minusCount} of the 40320 orderings (4/7) and to +1 for the rest`);
}

head('P8f. Controls and the other 210 in the data');
{
  const sq = sigVec(2, 6); let diff = 0; for (let m = 0; m < 256; m++) { let s = 1; for (let a = 0; a < 8; a++) if ((m >> a) & 1) s *= sq[a]; if (s !== bladeMul(m, m, sq)[1]) diff++; }
  chk('ctl', diff > 0, `the square as the bare product of the generator squares (no reversal sign) disagrees with the engine on ${diff} of 256 blades (it agrees at grade 4, where the reversal sign is +1)`);
  const S210 = [...Array(8).keys()].filter(a => (210 >> a) & 1), n210 = nameOf(210);
  chk('ctl', JSON.stringify(S210) === '[1,4,6,7]' && n210 === 10659 && DICT.code.faces.includes(210) && DICT.code.fano_line_tetrahedra.includes(210) && !DICT.code.faces.includes(15) && bladeMul(210, 210, sq)[1] === -1,
    'the integer label 210 (bits 11010010, S = {1,4,6,7}) is another blade: named 3·11·17·19 = 10659, a face of the code in dictionaryData.js (a Fano-line tetrahedron), square −1 in sigVec(2,6); the blade named 210 (label 15) is not a code face');
  const rev = P8.slice().reverse(), mrev = [...Array(256).keys()].filter(m => nameOf(m, rev) === 210);
  chk('ctl', JSON.stringify(mrev) === '[240]', 'with the primes in the reverse order the name 210 sits on S = {4,5,6,7} (label 240), not on label 15: the name is notation');
}
finish(ID);
