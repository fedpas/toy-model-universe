# Notes for the owner: what the primes do on the bit rule

You wrote: *"If primes are just labels, what about us using binary and the bit rule? Labelling sure, but they can address to mean something. Labelling is a way of helping the reasoning and logic."* Here is what our engine and an independent route agree on, and what they do not support. Every sentence below is backed by a script in `scripts/` and its log in `logs/`.

## 1. What the dictionary gives
Give each switch its own prime (2, 3, 5, 7, …) and name a corner by multiplying the primes of the switches that are on. Then the whole bit rule becomes ordinary arithmetic on those names:
* joining two corners (the XOR) is "multiply and strike out squares": a·b/gcd²;
* the switches two corners share (AND) are the greatest common divisor; all the switches of either (OR) are the least common multiple; the opposite corner (NOT) is the top name divided by the name;
* the number of switches on is the number of prime factors, and the sign of the corner (even or odd) is the Möbius sign of its name;
* the corners are exactly the divisors of the top name.
Checked for all pairs up to 10 switches and a million pairs at 11 and 12.

**Why primes are the right names.** We tried every way of naming 2, 3 or 4 switches by numbers up to 30 (or 12). The joining rule works exactly when the names share no factor (pairwise coprime). "The corners are exactly the divisors" needs more: with coprime names it holds exactly when every name is a prime. A name 4 keeps the joining rule but makes 2 a divisor that is no corner. Names 2, 4, 16 (powers of one prime) give every divisor, but then multiplying names adds the corners as ordinary binary numbers, with carries, instead of joining them: binary with carries is one prime; binary without carries is many primes. Which prime sits on which switch stays a choice (notation); the rule itself is not a choice.

The same names read the physics pages exactly: a Maxwell step divides or multiplies the name by the prime of its direction, and a step that is not allowed is exactly a division by a prime that is not there or a multiplication by one that already is (all 15 cells). For particles in seats: putting a particle in seat i is possible exactly when its prime does not divide the name; "a second particle in a full seat" would need p·p, which is never a name; the sign is (−1) to the number of smaller primes already present (when seats are ordered like their primes).

## 2. Your reading of "bases 2·5"
*"I meant bases, 2*5, because there is 2*3 and 3*5, also 2*3*5 and so on."* With three switches, 2·3 = 6, 2·5 = 10 and 3·5 = 15 are the three planes, and 2·3·5 = 30 is the volume. The three planes are the quaternion units: i·j = k reads 6·10/2² = 15 in names, and the even corners {1, 6, 10, 15} form a closed little algebra. With four switches the even corners are 1, 6, 10, 14, 15, 21, 35, 210. Checked against Pauli, quaternion and Dirac matrices in seven cells. The primorial number base (place values 1, 2, 6, 30, 210) adds nothing: its place values are just the names of "the first k switches on", and its digits do not follow the joining rule.

Whether a corner's *integer* label is a prime number (the gold borders) says nothing about the corner beyond switch 0 and the number of switches on. One exact surprise: at 8 switches no prime has exactly six switches on, because every such number is divisible by 3, 5 or 17 (the factors of 255): that is arithmetic of binary numbers, not a property of the algebra.

## 3. The Monster readings (one line each)
*"it goes up to the monster group, with 15 primes and '1' as the non prime 16th member"* and *"The precise fact that they are ordered differently is probably why it's special."* (the Monster's list is taken as given, not rebuilt).
* Map the 15 primes onto the 15 non-empty corners of four switches: no natural map exists; the best regularity (the seven primes of the form 8k ± 1 can sit on one Fano plane so that every line's sign rule works) happens for 8.3% of random lists: **chance**.
* The primes with odd exponent as one corner of 15 switches: computed (11 switches on, odd), no test possible: **open**.
* "15 primes and 1 as the 16th member": four switches have exactly 16 corners, 15 non-empty and the empty one named 1, an exact count; but a separate prime for each corner breaks the joining rule on every pair: **negative** as a dictionary.
* The primes in the counts of corners by grade, C(n,k): never exactly the Monster’s 15 (computed up to n = 2000; a short argument covers every n): **negative**.
* The different order (37, 43 missing, 59, 71 in): 8323 simple rules tried, none separates the list from the skipped primes; such rules match random lists 1.6% of the time: **negative**.
* Squares from the primes (p of the form 4k+1 squares to +1, 4k+3 to −1): the 15 primes plus the unit give a quaternionic cell for both choices for 2: a **construction**, not a finding.

## 4. The 210 checkpoint
In the dictionary, 210 = 2·3·5·7 is the name of exactly one corner: switches 0, 1, 2, 3 on (grade 4), in the cell Cl(2,6) = M8(H). In the engine's standard placement (+ on switches 0 and 1) it squares to +1; it squares to −1 exactly when one of the two + switches is among 0 to 3. Change the order of the primes and the name 210 moves to another corner (each grade-4 corner gets it equally often). The Atlas data also contain the *integer* label 210 (switches 1, 4, 6, 7), a different corner: a face of the 8-bit code, squaring to −1. What 210 means stays open.

## 5. Three precise questions for the next step
1. **The Fano-plane placement across other lists.** For the prime lists of other groups (given as input, like the Monster's), how many allow the seven-and-eight placement for the sign of (2/p)? If far more than 8.3% do, the placement is about such lists; if about 8.3%, it is chance. (Needs the lists as given facts.)
2. **"Multiplicity" made countable.** Is there a count on the 16 corners of four switches (or on its 35 lines) whose values are the exponents 46, 20, 9, 6, 3, 2 and nine 1s? A declared list of counts can be searched and compared with random exponent lists.
3. **Which corner is the checkpoint?** Is it the corner *named* 210 (switches 0 to 3) or the corner with *integer label* 210 (switches 1, 4, 6, 7, a code face)? And which two switches square to +1 in your Cl(2,6)? With those two answers the square and the code membership are already computed.
