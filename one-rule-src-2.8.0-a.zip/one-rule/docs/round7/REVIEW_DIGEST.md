<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Review digest: the held paragraphs and the proposed statements

One proposal for each of 424 of the 468 entries of `content/story/pending.json`; Furey's 44 statements wait for the owner of his pages. Each reason, with the rows and checks it names, is under the paragraph's locator in `content/story/review_proposed_a.json` (the full-Atlas pages) or `_b.json` (the three chapters and Furey's held blocks). How to accept or change a choice: `docs/REVIEW_GUIDE.md`.

## Counts by choice

| file | story | same-as | drop | statement | reading | hold | all |
|---|---|---|---|---|---|---|---|
| `review_proposed_a.json`, full-Atlas pages | 219 | 32 | 5 | 8 | 0 | 2 | 266 |
| `review_proposed_b.json`, chapters and Furey's held blocks | 109 | 18 | 12 | 7 | 0 | 12 | 158 |
| all | 328 | 50 | 17 | 15 | 0 | 14 | 424 |

The default rule (R7-7, `node tools/accept_review.mjs --rule default`) accepts 386 of them: story 328, same-as 41, drop 17. It leaves you the 38 below: 14 holds, 15 statements, and the 9 finding titles proposed as the statement of one row, which A58 asks you to confirm. No paragraph is proposed as a reading.

What accepting does. A `same-as` or a `drop` keeps the paragraph off the pages; a finding title's `same-as` becomes its row's short research text. A `story` choice places the paragraph only where the test of §1.4 clears it in its section when the migration runs again: measured with all 328 accepted, one is placed (PRJ-509) and 327 stay held: 274 hold a formula or number that no row of their section or page writes the same way, 42 restate only rows of other sections of their page, 11 repeat 40 characters of a row. The 15 statements need the row's labels (notions, a row kind, stage) in their entries of `pending.json` before `tools/merge_story.mjs` takes them; none has them yet.

## Your list

Each line: locator (id) · the paragraph in twelve words, in your words · the proposed choice · why.

**clock**
- `labelsCopy.js#COPY.en.tabs.clock.lede.1` (LAB-505) · "every Cl(p,q) sits inside the all-positive cell … It does not carry the reversion" · hold · the embedding is LAB-001 (labels_check F3); that the reversion is not carried, so a compact Spin(n+2) cannot contain Spin(1,3), no row states and no run tests
**matter/papers** (the "what we rebuilt" and "what we checked" lines; PAG-014 says only "30 checks"; the recorded passing run of furey_papers_check computes each)
- `fureyCopy.js#fc.earlier.papers.r1.repro` (FUR-543) · "the ten gamma matrices, the vacuum, … the dimension ladders 45 → 21 → 15 → 11 → 10" · statement:furey_papers_check · its checks A1–A5, R1–R8
- `fureyCopy.js#fc.earlier.papers.r2.repro` (FUR-547) · "The chirality element is −R_{ε₃}; the left-handed projector has rank 16 of 32" · statement:furey_papers_check · A5, R3, R11
- `fureyCopy.js#fc.earlier.papers.r3.repro` (FUR-551) · "Intersection dimensions 24 (spinor), 12 (three-way), 9 (five-way) and 9 (four-way without 𝕆)" · statement:furey_papers_check · R9, R10
- `fureyCopy.js#fc.earlier.papers.tri.repro` (FUR-555) · "The 14 derivations of 𝕆, … and 133 = 9 + 28 + 96, 248 = 28 + 28 + 192" · statement:furey_papers_check · T1–T5; "the Cartan factorization itself is not rebuilt" stays as you wrote it
- `fureyCopy.js#fc.earlier.cpDetail.1.ours` (FUR-570) · "ℂ⊗ℍ⊗𝕆 is 32-dimensional over ℂ, and its left-handed projector P_L has rank 16" · statement:furey_papers_check · R3
- `fureyCopy.js#fc.earlier.cpDetail.2.ours` (FUR-572) · "The chirality element Γ₁⋯Γ₁₀ equals −R_{ε₃}, a right multiplication by a quaternion unit" · statement:furey_papers_check · A5
- `fureyCopy.js#fc.earlier.cpDetail.3.ours` (FUR-573) · "The direct route leaves the 12-dimensional su(3)⊕su(2)⊕u(1), in which B−L is not a generator" · statement:furey_papers_check · R9, R11
**shapes**
- `gossetCopy.js#en.glueNote.3` (GOS-511) · "n = 16: length 4. … rank 16 has E8 ⊕ E8 (E8 twice) and D₁₆⁺" · hold · gosset_selfcheck computes the D₁₆⁺ glue, not this list of the even unimodular lattices of rank 16; no row states it
**steps/baez** (finding titles, A58)
- `baezCopy.js#COPY.en.findings.0.title` (LNB-516) · "One generation is the 16 even five-bit labels, and the Peirce rule is a Hamming distance" · same-as:LNB-014b · LNB-014b states it (the Peirce value 1 − d(x,S)/4); the first line, LNB-014, is the paper's
- `baezCopy.js#COPY.en.findings.3.title` (LNB-538) · "The plane of the three generations is the Eisenstein lattice of the triangulation note" · same-as:LNB-032 · not the first line, LNB-017
- `baezCopy.js#COPY.en.findings.4.title` (LNB-542) · "Octonions and split octonions are the label rule with another sign" · same-as:LNB-018 · the split octonions are LNB-019b
- `baezCopy.js#COPY.en.findings.8.title` (LNB-537) · "The periodic table as bits: electrons are set bits, a ground state is a prefix" · same-as:LNB-024b · not the Madelung counts of LNB-024
**steps/category**
- `categoryCopy.js#COPY.en.defs.items.1.1` … `items.15.1` (LNC-512 to LNC-523, twelve) · "a basis vector of the radical of the quadratic form; r does not depend" · hold · your list "Definitions, and the theorems this page cites" without its terms; standard definitions, not results: a glossary, story rows with their terms, or nothing, for the whole list
- `categoryCopy.js#COPY.en.moves.ftitle` (LNC-542) · "Four maps between dimensions: join, halve, restrict to a face, complement" · same-as:LNC-073 · finding title; not the first line, LNC-035
- `categoryCopy.js#COPY.en.top.ftitle` (LNC-553) · "Top down: the E_{n} series meets a null direction at n = 9" · same-as:LNC-042 · finding title; the null root is LNC-043
- `categoryCopy.js#COPY.en.more.items.1.title` (LNC-570) · "The cube of labels as a category: one sign up to gauge, the Koszul complex" · same-as:LNC-056 · finding title
- `categoryCopy.js#COPY.en.more.items.2.title` (LNC-571) · "Tian’s algebra is a Clifford algebra of the atlas in a hyperbolic basis" · same-as:LNC-057 · finding title
**steps/coupling**
- `couplingCopy.js#en.idNote` (CPL-508) · "The identity holds for any ψ and A, so on every solution (D = 0)" · statement:coupling_selfcheck · div X = 0 on solutions and first-order gauge invariance; no row of step 6 states them
**steps/dirac**
- `equationsCopy.js#en.d.cube.t` (EQN-524) · "The 32 derivative terms are all 32 edges of the 4-cube" · statement:equations_selfcheck · EQN-008 gives only the count; the cube reading is also tagged ours
- `equationsCopy.js#en.d.comm.t` (EQN-526) · "For each of the 6 bivectors B the identity D(Bψ) = B D(ψ) − D′(ψ) holds exactly" · statement:equations_selfcheck · INP-021 says only that covariance is checked
- `equationsCopy.js#en.d.disp.t` (EQN-527) · "The 8 × 8 system has determinant (p² − m²)⁴, checked exactly at 7 points" · statement:equations_selfcheck · the energy signs are spin_selfcheck's
- `equationsCopy.js#en.d.mat.t` (EQN-528) · "With explicit 4 × 4 gamma matrices (numpy) we send ψ to Ψ = ψu" · statement:dirac_matrix_check · with its two wrong versions, which fail
**steps/forque**
- `forqueCopy.js#en.f.num` (FRQ-515) · "the positions agree to 9e-12 or better, momentum is conserved" · statement:forque_matrix_check · FRQ-001 and EQN-016 state only the power-series checks
**steps/matter**
- `matterCopy.js#en.idNote` (MAT-509) · "Commutator: the covariant derivatives satisfy [D_μ, D_ν]Ψ = gF_{μν}Ψ" · statement:matter_selfcheck · three identities; MAT-003 states the conservation only
**steps/schuller**
- `schullerCopy.js#COPY.en.fibre.findings.1.title` (LNS-540) · "Keep the 8 fixed and step the base down: the commutant fills" · same-as:LNS-016 · finding title
**steps/ym**
- `yangmillsCopy.js#en.idNote` (YM-509) · "Bianchi: D_λF_{μν} + D_μF_{νλ} + D_νF_{λμ} = 0, which needs the Jacobi identity" · statement:yangmills_selfcheck · YM-004 says the identities are checked without naming them
