# Batch 3 closing — addendum for SCR-A, SCR-B and LED (Round 7)

Read this first, then `COMMON_B3.md` and your own brief (`agent_b3_scripts_a.md`, `agent_b3_scripts_b.md`, `agent_b3_ledger.md`). The briefs were written for the author's v15 package; the release is now built on the V2 repository (ONE RULE, `$SP/v3/one-rule`), which carries the same 14 scripts under `checks/selfcheck/gravity/` and the statements as rows of `content/rows.json` with their texts in `content/texts.json`. These substitutions apply; where the addendum and a brief disagree, the addendum wins.

## 1. Paths

| the brief says | read instead |
|---|---|
| `$SP/leads3/_review/pkg/selfcheck/gravity/` (the authoritative copy of a script) | `$SP/v3_agents/<you>/one-rule/checks/selfcheck/gravity/` — your copy of the repository; edit the scripts there. The package root for running is `checks/`: `cd $SP/v3_agents/<you>/one-rule/checks && (ulimit -v 3000000; timeout 900 nice -n 10 python3 -I -B selfcheck/gravity/<script>.py > selfcheck/gravity/logs/<script>.log 2>&1)`; `export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1`. |
| the lead's own folder `$SP/leads3/<LEAD>/…` "must stay byte-identical" | read-only now; do not write there. The record of what ran is the log under `checks/selfcheck/gravity/logs/` and the run entry LED adds to `content/check_runs.json`. |
| `$SP/leads3/_review/runs/`, `mut/` | write your logs and mutation tables inside your copy: `checks/selfcheck/gravity/logs/<script>.log`, `checks/selfcheck/gravity/mut/<script>.mut.log` and `.json` (create `mut/`). The mutation tool stays `$SP/leads3/tools/mutate_pkg.py`, run from `checks/`: `python3 -B $SP/leads3/tools/mutate_pkg.py selfcheck/gravity/<script>.py --log selfcheck/gravity/mut/<script>.mut.log`. |
| `$SP/deliver_batch3/final/` (LED's outputs) | `$SP/v3_agents/led/one-rule/docs/round7/batch3/` (`LEDGER_BATCH3_final.md`, `AUDIT_DISPOSITION.md`, `prov_check_final.py`, `own_wording.txt`, `BATCH3_RESULT_final.md`), and the apply step of §3. |
| `$SP/deliver_batch3/work/script_changes_A.md` / `_B.md` | the same names under `$SP/v3_agents/scr-a/one-rule/docs/round7/batch3/` and `$SP/v3_agents/scr-b/one-rule/docs/round7/batch3/` (LED reads them there at its end; a missing file means the marker rule of its brief applies). |
| `rows_today_v15.txt`, `prov_check.py`, `anchor_check.py`, the draft ledger, the audits | unchanged, read-only, under `$SP/deliver_batch3/`. |
| `$SP/v15` | the texts of the rows are now `content/texts.json` (research level, `status: "human"`); the rows `content/rows.json`; the one-row tool `node $SP/v15_work/one_claim_v15.mjs ROW-ID` still prints the v15 text of a row and is fine for "Today" fragments. |
| the scan `node $SP/leads/tools/scan_words.mjs <file>` | still the tool for anything that ships (scripts, docstrings, README cells, the texts); V2's own rule is `node tests/shipped.test.mjs` after `sh build.sh` (LED runs it once at the end). |

The README of the scripts folder is `checks/selfcheck/gravity/README.md` (the D1 rows go there); the one-line `d_probe` patches of the 13 scripts (L7) are **not yet applied** in V2 (`content/leads.json` `coordinatorNotes` says so): SCR-A applies them (`$SP/leads3/L7/patches/`), re-runs the 13 logs once each (they are short; one at a time; diff: only the probe's lines may differ) and lists the 14 patched scripts in `script_changes_A.md`.

## 2. What else V2 changes for the closers

- The leads' own proposed wordings are recorded in `content/leads.json` (`edits`, 32 entries with the quoted "Should read" texts) and 26 rows carry `since: "v16"`; **the research texts of the rows are still the v15 texts** (`status: "human"`). The audits corrected several of those proposals; the final ledger is what decides. LED reads `content/leads.json` to see what V2 recorded and makes the final ledger supersede it (its §3 apply step marks every edit entry `applied`, `superseded` or `declined`).
- Row ids are the v15 ids; where V2 split a v15 row into lines (`GRV-004b`, `GRV-004c` …, see `docs/02_CONTENT_MODEL.md` §1), the ledger's "third line of GRV-004" is the row `GRV-004c` (count the lines in `node $SP/v15_work/one_claim_v15.mjs GRV-004` and match the text). LED writes the V2 row id next to every ledger entry.
- Rows gaining evidence get an `evidence` entry `{ "check": "<check id as in content/checks.json>", "script": "checks/selfcheck/gravity/<script>.py", "mode": "ran" }`; the status is computed (`npm run content`), never typed.

## 3. LED's apply step (after the final ledger is written)

1. For every row of the final ledger: the research text of the row (`content/texts.json`, `level: "research"`, `lens: null`, `mode` as today) gets the ledger's final body, `status: "reviewed"`, `source: "ledger:batch3"`; the replaced body is appended to `content/story/retired_texts.json` as `{ row, body, status: "human", source: <old source>, retiredBy: "ledger:batch3" }` (never rendered; a record). A row whose ledger entry adds a sentence without replacing one gets the sentence appended to the same body (one text record per row and level).
2. `content/rows.json`: the evidence entries of D4 ("rows gaining evidence"); `since: "v16"` on every row the ledger changes (the release's badge rule counts them as new).
3. `content/check_runs.json`: one run per re-run script (`script`, `date` = the day of the run, `machine: "the round-7 closing, run from checks/"`, `ok`, `fail`, `lastLine`, `passed`, `source: "checks/selfcheck/gravity/logs/<script>.log"`); `content/checks.json`: the `ids` and `what` of a script whose printed statement changed (AUD-A-1's check line, the M4 probe of `b3c4_curved_points.py`).
4. `content/leads.json`: every `edits` entry gains `"disposition": "applied" | "superseded by the ledger" | "declined"` with the ledger entry id; `mergeNeeded` becomes `[]` with the merged wordings of GRV-011 and RIG-002 written; `coordinatorNotes` emptied of what is now done.
5. `checks/selfcheck/gravity/README.md`: the D1 rows, D2 table (14 patches), D3 paragraphs.
6. `npm run content` (no validation error), `node tests/logbook.test.mjs`, `node tests/engines.test.mjs`, `sh build.sh`, `node tests/shipped.test.mjs`, `node tests/coverage.test.mjs` (under `flock $SP/v3_agents/.chromium.lock`, timeout 600000): green, or the report says which line and why.
7. `BATCH3_RESULT_final.md` closes with the counts: rows changed, scripts changed, runs recorded, and the sentence "these are records for the full Atlas side; no page sentence outside these rows changes".

## 4. Same rules

Never write into `$SP/leads3`, `$SP/deliver_*`, `$SP/v15`, `$SP/v16*`, `$SP/v3`, another owner's copy. No e-mail, phone or postal address; no history words in anything that ships (the texts, the scripts, the README); `python3 -B`, `ulimit -v 3000000`, `nice -n 10`, one heavy run at a time, `timeout 900`; never `pkill -f`. Final message to the lead: at most 250 words, as `COMMON_B3.md` says.
