# LOOK — the face of ONE RULE (Round 7, R7-5)

The look of Octavo applied through the design tokens: Paper and Night, ink on paper for every action, one highlight (`--hi`) for the pressed and the current, the three move colours for the three moves only, Newsreader · Instrument Sans · Noto Sans Math with system fallbacks; the door, the page top and the record styled against a static fixture with the class names of interface 36. The system is written down in `docs/05_DESIGN_SYSTEM.md`; this page holds the numbers, the decisions taken on the way, and what the lead applies.

## 1. Files

| file | what |
|---|---|
| `src/styles/tokens.css` | Paper and Night (R7-5 values), `--fg-2` (Octavo's second ink), `--hi`, `--turn --slide --boost`, `--accent` = ink, `--accent-soft` = `--hi`, the four font stacks, `--fs-6` 40 px, `--radius` 8 px; the forced theme repeated verbatim; the quiet ink re-pointed to `--fg-2` on every highlighted state; no status hue |
| `src/styles/base.css` | `.btn` as Octavo's pill (44 px, 1.5 px ink; `.btn--on` ink with paper letters) |
| `src/styles/components.css` | display face at 500 for titles (page 40 px, section 26 px), eyebrows in small capitals, segmented switches and the lens button as pills with the chosen option on `--hi` under an ink ring, the lens chips under a figure as Octavo chips, badges in ink (dashed rim for open), cards with 1.5 px lines and 16 px corners, text buttons underlined (actions are ink), D31 orders a leaf's picture row first |
| `src/styles/story.css`, `explore.css` | the same rules (parts 32 px, More statements as an ink pill, the try line on the page, not on a ground) |
| `src/styles/door.css`, `top.css`, `record.css` | new: the door, the page top, the record (§3 of 05) |
| `src/figures/explore/leaf/leaf.css`, `lens/lens.css` | Octavo chips (44 px, 1.5 px ink, `--hi` when pressed + ink ring), the stepper as one box with its value in the math face, the moves coloured through `--turn --slide --boost` on their marks and on the paths that carry `data-class`, selections as thicker ink on `--hi`, readout lines in `--fg-2`, `.lt-math` in the math face |
| `index.html` | the fonts link: Newsreader, Instrument Sans, Noto Sans Math (and JetBrains Mono), same non-blocking pattern |
| `tests/ui/fixtures/round7_top.html` | the static page of interface 36: a door (8 cards, 4 shelf cards, chapters, the door to the Atlas), a page top (lead, the clock leaf in a wide frame, try line, three notes, two ways), a section with the moves leaf, a record with 12 rows; the rows, texts and figures are the built app's (clock page) |
| `tests/ui/look.test.mjs` | checks 1–6 (below) and `--routes [light|dark]` |
| `tests/ui/shots/round7/look_{door,top,record}_{390,1280}_{light,dark}.png` | 12 screenshots, looked at |
| `docs/05_DESIGN_SYSTEM.md` | tokens and their one meaning, validation, contrast table, fonts, the door, the top, the record |

## 2. Numbers

**Validator** (dataviz `validate_palette.js`, on the new surfaces; ΔE OKLab ×100): clock Paper on #FFFEFA pass (CVD 9.1, normal 19.6; #1baf7a 2.79, #eda100 2.15, #e87ba4 2.67 below 3:1, relief: `c = n` printed); clock Night on #151D28 pass (CVD 8.4, normal 19.3, all ≥ 3:1); moves all-pairs Paper pass (CVD 11.0, normal 18.7, 3.83 / 3.39 / 5.14 on `--panel`), Night pass (CVD 11.8, normal 17.7, 4.79 / 5.73 / 4.11); grades `--ordinal` pass both (light end 2.09); V2 status hues all-pairs FAIL both (Paper CVD 4.5 / normal 10.5; Night CVD 1.6 / normal 9.8).

**Text on ground** (minimum of every pair the sheets draw): Paper 4.95 (`--muted` on `--line-2`), Night 4.81 (`--fg-2` on `--hi`); full table in 05 §1. **Every visible text** (`look.test.mjs --routes`, all 54 routes × research and learner + the open search palette, 1280 px): Paper 109 pages, 29,090 texts, weakest 5.56:1; Night 109 pages, 28,948 texts, weakest 4.81:1; none below 4.5. The fixture: 336–340 texts, weakest 5.56 (Paper) / 6.65 (Night).

**Budget**: `dist/app.css` 109,203 B; a trial bundle with the three new sheets imported 118,607 B ≤ 122,880 B (D38's 120 kB; 4.2 kB left, 10.6 kB if `explore.css` leaves the bundle with the Explore pages).

## 3. Decisions taken (each one token or rule to undo)

1. **No status hue.** The five status hues were the clock's own hexes and three of them sit ΔE 3–6 from the moves; as a set of five they fail the validator in both looks. A status is drawn in ink (icon + word; the open badge with a dashed rim), as Octavo draws everything but the moves.
2. **`--fg-2`** (Octavo's `ink2` #424954 / #C4C8CF) for ledes, card lines and readout lines, and as the quiet ink on a `--hi` ground: `--muted` on Night's `--hi` is 3.16:1, so `tokens.css` re-points `--muted` on every pressed, current, chosen, on, targeted or open thing (this fixed three figure tables found by the audit: `.mx-op` on #/light, `.g7-ns` on #/steps/ym, `th.is-on` on #/steps/rigid).
3. **An ink ring on the pressed.** `--hi` against `--panel` is 1.30 (Paper) / 2.10 (Night); a pressed chip, segmented option or lens button also wears an inner 1.5 px ink ring.
4. **Collisions R7-5 leaves standing, to know**: turn↔c1 ΔE 5.4 / 3.0, slide↔c2 5.1 / 3.7, boost↔c0 6.1 / 5.3, boost↔grade E 6.1 / 5.3. On the clock page (the clock leaf and Three moves) one orange means c = 1 and turn; the mark and the word tell them apart. If the owner wants one hue one meaning there too, the clock leaf's discs could be drawn in ink with their letter (Octavo's clock) — a change for the leaf's owner.

## 4. What was run

`sh build.sh` (flock); `node tests/ui/look.test.mjs`: PASS (tokens of R7-5 in both themes and forced; 12 text pairs and 8 mark pairs a theme; 4 × 60 computed styles = tokens and 60 with the sheets loaded first; no overflow at 390 / 1280 in both themes, nor with wider stand-in faces; 6 of 6 injected faults caught). `--routes light` / `--routes dark`: PASS. `node tests/ui/smoke.test.mjs` with patch A: 4 failures, the 4 of the base (`#/` shows "explore", ROUND6_NEXT T1, ARCH's); without patch A 17 (13 more: the old background colours). `explore.smoke` with patch A: PASS; `story.smoke`: PASS; `figures.render`: 90,292 of 90,292 (no literal colour in the leaf and lens sheets); `shipped`: licence, contact and budget pass; its 3 failures (history in the release notes, 136 section placements, release files) are the base's.

Not done: the three web fonts could not be drawn (offline, no local copies): the layout was checked with the fallbacks this machine resolves (Liberation Serif, Inter, Liberation Serif for math, DejaVu Sans Mono) and with wider stand-ins (DejaVu Serif and Sans). Chromium 141 floors a 1.5 px border to 1 px at every pixel ratio; the sheets keep 1.5 px (R7-5) and the test checks what the browser draws.

## 5. For the lead: patches and seams

**A** — the smoke tests read the body's ground (ARCH's files):

```sh
sed -i -e 's/rgb(17, 20, 25)/rgb(14, 20, 28)/g' -e 's/rgb(245, 246, 248)/rgb(246, 243, 234)/g' tests/ui/smoke.test.mjs tests/ui/explore.smoke.test.mjs
```

**B** — the three sheets in the bundle, `src/app/main.jsx` after `import '../styles/components.css';`:

```js
import '../styles/door.css';
import '../styles/top.css';
import '../styles/record.css';
```

**C** — `package.json` `test:ui` (ARCH's line): append ` && node tests/ui/look.test.mjs`.

**D** (comments only) — `src/figures/explore/leaf/leafKit.jsx` lines 6–7: "The three moves are told by mark and word, never by colour:" → "The three moves are told by mark and word, their colour (--turn --slide --boost, leaf.css) only repeating them:"; `LeafCharge.jsx` line 8: "(solid, dotted, dashed), never by colour." → "(solid, dotted, dashed), the colour only repeating them."

**The markup the sheets expect** (the fixture is the contract): door cards as `ol`/`ul` > `li` > `a.door-card` (icon `.door-card-icon`, `.door-card-n`, name `h3`, line `p`, foot a last `span` "Open →" / "coming"; an undrawn leaf `.door-card.is-coming`); the hero words in a `div` (optional eyebrow `p`, `h1`, the line `p`, a `p` of links); `ol.top-notes > li.top-note > Statement` with no printed number and a `.top-try` without the word "Try" (both come from `top.css`); each `.top-way` with an `h3` eyebrow, the lens chip `button.top-way-lens` inside it; `details.record > summary.record-head` (a title `span`, a counts `span`), the table in a `.table-scroll` (it also scrolls alone), `code` for ids, scripts and addresses, `td.num` for counts.
