<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The Atlas as a tuning set

One content model, two uses. A reader sees one idea per page, with a picture and few words. A model is tuned on the same statements, each one a record with its label (the bit rule), its lenses, its proof and its dependencies, so that it can translate a statement of one field into another and predict the known law from the right label. The export of the second use is `dist/content/tuning/`, rebuilt at every `sh build.sh` by `tools/export_tuning.mjs`; the page `#/agents` explains it.

## The owner's sketch

The diagram: an input IN₀ goes into the Claude AI model, which gives OUT₁. OUT₁, read as the input IN₁ of the Universal Intelligence model (nature), gives OUT₀; the goal is IN₀ → OUT₀. The Atlas takes OUT₁ and gives back OUT₂/IN₂, which feeds the model again; Octavo shows the loop to a human. In the circle: *"The INPUTS IN₁ that give the KNOWN OUTPUTS are AFTER the U.I. reasoning."* The owner's words, typed from the sketch:

> By correctly labelling IN₁ we should exactly predict OUT₀. Nature doesn't change much: she has different representations at different scales, but all logically connected. We can probe the Universal Intelligence all the time; she keeps running, never stops, and we try to understand it. We find by experimenting on IN₁ what leaves invariant OUT₀, we try to find patterns, we try to look for symmetries, and as humans we collected many examples to show how to get OUT₀ from the right initial conditions IN₁. So once we know how to go from OUT₁ → IN₁ then we know exactly OUT₀, because the Universal Intelligence follows the laws of nature. The Atlas's first goal is to train the Claude AI model to find the correct OUT₁ → IN₁ such that the model can predict OUT₀ from OUT₁. Octavo is supposed to give a human interface to show with lenses the reasoning, statements, results of how an AI model tuned by the Atlas correctly predicts Universal Intelligence = Nature.

## The mapping

A row is one example of the loop. Left, the sketch; middle, what it is in the Atlas; right, where it lives: the table of `content/` and the key of the record in `rows.jsonl`.

| Sketch element | In the Atlas | Table · key of the export |
|---|---|---|
| IN₀, the input to the model | not stored; the Ask page's question is the nearest | none |
| the Claude AI model | the model being tuned | outside the Atlas |
| OUT₁, a statement in the words of one field | a text with its mode, level, lens and register | `texts.json`: `texts` |
| IN₁, the label, the inputs that give the known output | the notions the statement uses, its cell, its mask and prime | `rows.json` and `derived/status.json`: `notions`, `bits`, `mask`, `signature`, `grade`, `prime`, `address`, `cells`, `stage`, `kind`, `ptype`, `fields`, `phenomena` |
| the Universal Intelligence (nature) | not modelled; the Atlas states what its rule computes and what is standard | none |
| OUT₀, the known output | the known law the statement states, under the names physics and mathematics give it | `rows.json`: `standardRef`, `homePhys`, `homeMath`, `theorems`; `theorems.json` |
| "we can probe it all the time" | the check that ran: a script that computes the statement through the bit rule and agrees with a standard route, with its recorded runs | `checks.json`, `check_runs.json`: `evidence`, `status` |
| "what leaves invariant OUT₀", patterns, symmetries | restatements and instances (an `equiv` or `instance` edge); neighbours, which differ by one notion | `rows.json`: `depends`; `bits` |
| "different representations at different scales, all logically connected" | the lenses, and the chains between statements | `lenses.json`, `lens_readings.json`: `readings`, `lensTags`, `depends` |
| "many examples" | the rows: one record per statement | `rows.json`: `rows.jsonl` |
| the Atlas | the tables and the guide's rules | `persona_rules.md`: `status` |
| OUT₂/IN₂, what the Atlas gives back | the whole record with its status word, and what the guide may say of it | one record of `rows.jsonl` |
| Octavo, the human interface with lenses | the pages of the Atlas, each ending with the record of its statements | `shownOn` |

## The loop in five sentences

1. **A record.** Every statement of the Atlas is one record: its words (OUT₁), its label in the bit rule (IN₁), the known law it states (OUT₀), the check that ran on it, and what it rests on.
2. **Words to label.** A model reads a statement in the words of one field and gives its label: the notions the statement uses, written as a mask of 29 bits.
3. **Label to law.** From the label it should reach the known law, and say how far the Atlas has checked it: the last recorded run of the check is the probe.
4. **Lenses and chains.** Lenses are the fields the model translates between; an equiv edge links two wordings of one statement, so the same result holds in both.
5. **Back to the model.** The Atlas gives the whole record back to the model (OUT₂). That is the aim of the tuning, not a result: an open or not-yet-proved mark means no theorem yet.

## Three tasks

- **Words to label** (OUT₁ → IN₁): from `texts[].body`, predict `bits`. Grade by exact match, or by the number of bits that differ.
- **Label to law** (IN₁ → OUT₀): from the label with `kind`, `stage` and `cells`, predict `homePhys`, `homeMath`, `theorems` and the `status` word. The recorded run in `evidence[].lastRun` is what a predicted `status` is graded against.
- **Field to field**: from a statement and a lens, predict the lens's term for each Atlas element in `readings`; or `homePhys` from `homeMath` and back.

Hold out whole groups or pages, not random records: `equiv` edges and `splitFrom` lines repeat a statement in other words, and so do the research and learner texts of one record, so a random split hands the answer across.

## What the limits are

- The label is the Atlas's labelling of its statements: an organisation, not a theorem about them. The Atlas is a guide, not an oracle; an open or notation-only mark means no theorem yet, not a wall.
- A check that passed is a recorded run of a script. It is not a measurement of nature, and nothing in the files says that the Atlas predicts nature.
- A text of status `draft` is a model's words that the author has not reviewed: not ground truth. The counts of the build, and which lenses have texts, are in the README of the export.
- A negative result is kept as a negative result: kinds `dead-end` and `counterexample`, and `contradicts` edges, are records like any other.
