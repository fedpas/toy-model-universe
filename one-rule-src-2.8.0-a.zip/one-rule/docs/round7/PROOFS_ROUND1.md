<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The proofs round, first pass: what the top twenty changed, what the Atlas gains, what to test next

Three leads ran on the top twenty of `docs/PROOFS_TODO.md` (L7-01 the Logbook lines, L7-02 Furey, L7-03 the category chapter and the reports): three new scripts under `checks/selfcheck/proofs/` (`step_lines.py` 252 checks, `furey_bit_route.py` 90, `catw_lines.py` 83), 35 scripts of the package re-run here with their runs recorded, every assert read against the sentence it was said to back. The leads' records: `$SP/leads4/L7-0{1,2,3}/` (BEFORE, RESULT, SHIP_NOTES, apply.json, logs); the apply step `$SP/v3_work/apply_leads.py`.

## 1. What changed in the tables

- **36 rows closed.** Every `cited` row of the Atlas (31 at the start of the round) and the four `ours` claims are `proved-by-atlas` now: the list's two first classes are empty. proved-by-atlas 678 → 712; the page chains complete at research level 7 → 12 of 32.
- **Ten sentences narrowed or corrected** (the owner's words kept, the scope the check shows added; the replaced bodies are in `content/story/retired_texts.json`):
  - FUR-001, FUR-001b — *"ω commutes with all of them"* says more than holds: ω = L_{e₇} commutes with four of the six projectors and with the sum of the other two, not with P_{e₇ℝ} and P_ℝ separately (`run_all.py` asserts the opposite; the bit route agrees). The sentence also listed five of six projectors.
  - LNB-029c — *"an unsymmetrised cubic Casimir cannot tell 3 from 3̄"* says more than holds: the trace tensor gives −8/9 and −28/9. What cannot tell them apart is the **antisymmetric** cubic (a multiple of the quadratic one, 4/3 on both); the symmetrised one gives 10/9 and −10/9; checked exactly on 3 × 3 matrices and on the colour bits of the 32 labels. The same false sentence stands in `checks/reports/baez/build_report_baez.py` and its built report (flagged, not edited).
  - MAP-027 — *"110 exact claims"* → 110 claims, 106 exact (a plausibility row and three float comparisons); the timings moved to a second line (MAP-027b, meta).
  - RSN-018 — *Ricci n(n+1)/2* holds for n ≥ 3; at n = 2 the Ricci rank is 1; the Bianchi-map clause is checked for n = 2 to 8.
  - MAP-019 — Yang–Mills: the script checks first-order covariance and covariant conservation at seven (m, dimension) pairs, not full covariance.
  - RSN-005 — only one direction of the printed "⇔" is checked: "gives" (d = 2, 3; numpy agrees to 1e-8).
  - MAP-018 — the Dirac current is a vector only for n = 3, 4 and has a grade-5 part from n = 5; conservation checked for n = 3, 4, 5.
  - MAP-020 — "conserved" → "covariantly conserved" (six (n, m) pairs).
  - MAP-024 — the energy with space squaring −1 is computed by no script (moved to MAP-024b, a stated limit).
  - MAP-007, MAP-010 — "rebuilt from the octonion table and counted (30 checks)"; "Y and Q as sums of projectors" (Q needs a projector onto one component of the doublet, not one of the five block projectors).
- **Four splits** (MAP-005b, MAP-024b, MAP-025b, MAP-027b) and one (SRC-003c): a reading or a stated limit that sat inside a checked sentence stands as its own line with its own status.
- **The tables repaired:** 143 check records whose `ids` the migration had split into characters carry the printed note as `idsNote` (`tools/migrate/checks_from_v15.py` fixed); the status rule of `tools/build_content.mjs` is strict (a row with legacy flags is proved only by a recorded passing run; no row changed by it); the run records of `matrixrep_check.py` and `dirac_matrix_check.py` no longer claim a `--compare` the scripts do not take; `checks.json` says of `yangmills_matrix_check.py` that its representation part is built with the bit product (not independent); the lens readings re-attached from the current evidence (1,901 → 1,979; one reading that hung on LNB-029c through a shared check id let go).

## 2. What the proofs change downstream (the usual method)

Read from the bottom up, cell by cell, as the Atlas does: a statement proved at one size is checked again one dimension up, and a formula is trusted only where the ladder reaches.

- **The ladder finds its own floor.** Two of the narrowings are exactly the lowest rung: at n = 2 the Ricci tensor has rank 1 (one curvature number: the Gaussian curvature fixes everything), so n(n+1)/2 starts at n = 3 and the Weyl part at n = 4 (20 = 10 + 10). The Dirac current ψγ₀ψ̃ is a vector at n = 3 and 4 and grows a grade-5 part at n = 5: the grades of the current follow 1 mod 4 up the ladder. Both were printed for "all n" and are now printed where the rungs were climbed.
- **Signs are the first thing the top-down reading catches.** From the biggest object down: the Witt torus of Furey's model is not a group of 16 but of 32 — the 16 code blades with both signs; −1 is the product of the four line blades that miss a point 0, 2, 4 or 6 (for 1, 3, 5 the product is +1). The 16 axes and the eight −1 signs of a generator are untouched (the owner's sentence is true as printed); the brief's premise was not. The same reading fixes which cubic Casimir carries the sign of conjugation: the symmetrised one (10/9 against −10/9), and on the labels the sign shows on the colour bits of the five-bit cube.
- **The rows that rest on the twenty stand on proved ground.** MAP-021 (25 rows rest on it), MAP-016 (23), FUR-002 (9), FUR-001 (8), LNC-021 (5): the dependency chains through the curvature identities, the commutator rule, Furey's ranks and edges and the null normal are complete; five more pages have a complete chain at research level (12 of 32).
- **What the Atlas gains as statements** (candidates for rows; none written yet, each with the check that would decide it):
  1. the current ψγ₀ψ̃ has grades 1, 5, 9, … (1 mod 4), vector for n ≤ 4 — `coupling_selfcheck.py` counts (0, 0, 1, 3, 6) are the start; a script over n ≤ 8 by the kernel;
  2. the line blades of the Fano plane generate a group of order 32 = 2 · 16, the sign a central ℤ₂, and the parity of the lines missing a point decides it — `furey_bit_route.py` has the computation; a row of kind computation;
  3. the sign of the symmetrised cubic Casimir is the conjugation 3 ↔ 3̄, read on the colour bits — a row with `catw_lines.py` catl·C1–C4;
  4. the Ricci count n(n+1)/2 for n ≥ 3 with rank 1 at n = 2, and the Weyl count n(n+1)(n+2)(n−3)/12 for n ≥ 3 (CAND-087, checked, waits for the owner).
- **What the proofs took away** (printed as checked, and checked no longer at that scope): the "⇔" of the force law (one direction), "every observer" readings that were already narrowed in batch 3, "all n" where the rungs stop, the energy with space squaring −1.

## 3. Defects the round found in the checks themselves (to fix before the next pass)

- `coupling_selfcheck.py` line 154: the "(2n+1)·2ⁿ⁻¹ terms" assert compares the formula with itself; the lead recounted the terms through the script's own product (they hold) — the assert should count.
- `spin_selfcheck.py` prints "ALL SPIN CHECKS PASS" before its `--compare` assertion; a compare failure shows only in the exit code.
- `yangmills_selfcheck.py`, `matter_selfcheck.py`, `coupling_selfcheck.py` check their identities on one random field each (the gravity engine uses three).
- `mutate_furey.py` needs `reports/furey/logs/furey_papers_check.log`, which the package does not ship (in a scratch copy it caught 44 of 44).
- `check_T18.py` part A is floating point (1e-8); exact radicals would close it.
- `checks/run_all.py` needs `model.py` beside it (copied now from `checks/reports/furey/`).
- 187 evidence entries of `rows.json` name a check id that no script of `checks.json` lists (the export marks them `script null`).

## 4. The next proofs (`docs/PROOFS_TODO.md` §2, regenerated: 113 statements ranked, 27 open and 86 candidates)

The first three would be false as printed if wrong; from the fourth on a wrong statement is a missing claim. The briefs L7-04 … L7-08 exist (`docs/round7/leads/`); the groups below them have none yet.

| lead | statements | what a pass gives |
|---|---|---|
| **L7-04 SM16** — ATL-020b (rank 1), CAND-003, CAND-020, CAND-044 | the 3/8 ratio Tr T₃²/Tr Q² over the 16 as an exact rational; the SU(3)³ and global SU(2) anomaly conditions on the 16; the 27 of E₆ under so(10) × u(1) as 16 + 10 + 1 | the Standard-Model labels of the five-bit cube checked as arithmetic on the labels, not recalled |
| **L7-05 YM** (Opus) — INP-033 (rank 2), INP-037 (rank 3) | the stationarity of S = −¼⟨FF⟩ − ⟨AJ⟩ for so(m) gives D^μF_μν = J_ν with the structure constants of the bit rule; the Dirac action with the covariant derivative gives the matter equation and the Noether current | two inputs of the model become derived statements: the field equations follow from the actions the Atlas states |
| **L7-06 POLAR** — CAND-008, CAND-055, CAND-123, CAND-048 | the maximal isotropic subspaces of the symplectic form on 𝔽₂²ⁿ (15 at n = 2, each with 4 sign choices); every real quadratic space as V_an + Hᵐ + rad Q from the signature (p, q, r); the top-blade form as the Berezin integral (λ(exp B) = Pf A, n ≤ 10); pair creation and annihilation preserving the CAR | the Pauli groups, quadrics and Fock encodings as one computation on the labels |
| **L7-07 WIRECAND** — CAND-113, CAND-061, CAND-100, CAND-108, CAND-021, CAND-119, CAND-054 (29 in all) | candidates that a passing check already decides (Majoranas and Cl(p,q), the Nakayama automorphism, B_n = B₁ⁿ, the sampling lemma stated once, 133 under sl₃ + sl₆, fermionic modes and qubits, reversion on the even subalgebra) | 29 candidates become rows with evidence, by reading, as the top twenty did |
| **L7-08 GRAVEM** (Opus) — CAND-030, CAND-039 | the projectivised null cone of ℝ^{1,3} as the sphere; the field stress T(a) = −½FaF with divergence F·J whenever ∇F = J, as a polynomial identity on exact fields | two exact identities of the gravity and Maxwell engines |
| without a brief yet: SOLID (5, best rank 18), RANGE (5), DIRAC (6), CAT (3), LAT (3), EMB (15), MEDIA (6) | the commutant of the minimal module per cell (Frobenius–Schur), the ranges of the ladders, the Dirac rows, the category and lattice groups, the Baez embeddings, Maxwell in media | briefs to write from the list's notes |

Also to test, from this pass: the four candidate statements of §2 and the seven defects of §3 (a script each, the method unchanged: BEFORE first, `[bit]`, `[std]`, controls, a negative result kept).
