<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# The story plan (S0, the story round, v2.2.0)

**The question.** The author's review of V2: "what happened to Furey's part? I see only one page now, but there were a few tabs about her papers, the three generations"; "Baez page too, what is that infinite series of statements without a story?"; "if the Atlas is now written so that only AI agents can read it … Octavo was supposed to be a front end, the landing page for humans — a front end showing/translating/picturing the concepts inside the Atlas. For now it is not like this."

**The diagnosis (the lead's, measured here in §0).** The migration took v15's claims table as rows and v15's widgets as figures. v15's narrative prose — page and tab intros, section leads, the "at a glance" frames, widget copy, the chapter glue of the Baez, Schuller and category lenses, Furey's five tabs — lived in copy files and components, was never a row, and fell off the pages. And a page renders every row as an equal statement, so a chapter reads as a list.

**The fix.** Keep the invariant (every text that counts is a row, D2) and add the missing kind: **narration rows** (kind `story`, the author's own words from v15, status `meta`, no badge; a story row states no law of its own). Add page **composition**: lead → picture → key results → details folded. Make Explore the landing page.

**Sources read.** In V2: `docs/01_VISION.md`, `02_CONTENT_MODEL.md`, `06_PAGES.md`, `DECISIONS.md`, `BUILD_CONTRACTS.md` (every round), `EXPLORE_PLAN.md` §0 and §2, `EXPLORE_CONTENT.md` §6, `PHYSICS_AUDIT.md`, `09_TRANSLATION_PROTOCOL.md`, `05_DESIGN_SYSTEM.md`, `HANDOVER.md`; `content/pages.json`, `rows.json`, `texts.json`, `steps.json`, `story_frames.json`, `figures.json`, `derived/status.json`; `src/pages/PageView.jsx`, `Page.jsx`, `Zero.jsx`, `ExploreHome.jsx`, `Ask.jsx`; `src/components/Section.jsx`, `Hero.jsx`, `Statement.jsx`, `OpenFold.jsx`, `FigureFrame.jsx`; `src/app/queries.js`, `router.js`, `settings.js`, `content.js`; `tools/migrate/*`, `tools/merge_explore.mjs`, `tools/build_content.mjs`, `tools/check_learner_texts.mjs`; `tests/coverage.test.mjs`, `tests/shipped.test.mjs`. In the v15 package (read-only): `storyCopy.js`, `audienceCopy.js`, `conventionsCopy.js`, `labelsCopy.js`, `lensesCopy.js`, `mapCopy.js`, `rigidCopy.js`, `spinCopy.js`, `springCopy.js`, `forqueCopy.js`, every other step copy, `plainStepsCopy.js`, `fureyCopy.js`, `findingsData.js`, `FureyPage.jsx`, `FureyKit.jsx`, `FureyEarlier.jsx`, `FureyFindings.jsx`, `ThreeGenSection.jsx`, `FureyHelp.jsx`, `DictionarySection.jsx`, `MaxwellSection.jsx`, `ChargesWidget.jsx`, `baezCopy.js`, `baezWidgetsCopy.js`, `baezIntegration.js`, `BaezSection.jsx`, `categoryCopy.js`, `categoryWidgetsCopy.js`, `categoryIntegration.js`, `schullerCopy.js`, `schullerWidgetsCopy.js`, `schullerIntegration.js`, `SchullerSection.jsx`, `atlasLines.js`, `ylAtlas.js`, `proofs.js`, `storyOverrides.js`, `inputsData.js`, `steps.js`, `Fold.jsx`, `Formal.jsx`, `StoryShell.jsx`, `claimsLocators*.json`.

**How the numbers were made.** Every v15 copy module above was imported read-only (as `tools/migrate/tables_from_v15.mjs` does); the three copy blocks inside JSX (`DictionarySection.jsx` UI/STAGE/TAIL/CARTAN_INFO/YL_NAME/YL, `MaxwellSection.jsx` T/VL/TX/BIG/YLM, `ChargesWidget.jsx` T/YLC) were bundled with esbuild with those constants exported; `fureyCopy.js` was read as `fc('en')`. Every English string was walked (keys `it` skipped): 11,514 strings (and 382 functions of templated copy, not read). A **prose block** is a string of at least 60 characters and 8 words: 3,176, of which **3,143 unique** (33 repeats: the Map page re-uses the chapters' map paragraphs, the conventions page re-exports its frame). Each block was assigned to its v15 page and tab by file and key path, then to the V2 route the migration re-pointed that tab to, and matched against `content/texts.json`: by locator (the `source` field, `file#path`), exact text, containment either way, or ≥ 88 % of its words in one text (41 such near matches); else against the other tables (glossary, conventions, theorems, questions, sources, inputs, matrix, map, analyses, reports, readings, needs, figures, lenses), and against `story_frames.json` and `pages.json` `learnerFrame` (stored, never rendered). The same method is the first half of S1's tool (§3), so S1 reproduces these counts or explains each difference.

---

## §0 Diagnosis in one page

### 0.1 The prose that fell off, page by page

| V2 page | v15 prose blocks | already rows | in other tables | stored, never shown | **missing** | of which learner |
|---|---:|---:|---:|---:|---:|---:|
| `#/` Zero | 22 | 2 | 0 | 18 | **2** | 1 |
| `rule` | 118 | 6 | 87 | 8 | **17** | 1 |
| `cells` | 162 | 65 | 0 | 7 | **90** | 6 |
| `clock` | 37 | 11 | 1 | 0 | **25** | 3 |
| `light` (Calibration 1) | 88 | 16 | 4 | 8 | **60** | 24 |
| `shapes` | 92 | 25 | 3 | 7 | **57** | 26 |
| `steps` (index) | 17 | 4 | 0 | 12 | **1** | 1 |
| `steps/comm` · `mirrors` · `dirac` | 18 · 26 · 24 | 4 · 9 · 6 | 0 · 1 · 1 | 0 | **14 · 16 · 17** | 8 · 7 · 7 |
| `steps/spin` | 89 | 11 | 1 | 0 | **77** | 12 |
| `steps/coupling` · `ym` · `matter` | 31 · 26 · 30 | 16 · 11 · 15 | 1 · 1 · 1 | 0 | **14 · 14 · 14** | 6 · 6 · 6 |
| `steps/grav1` · `grav2` · `projective` | 29 · 30 · 29 | 15 · 12 · 9 | 1 · 1 · 1 | 0 | **13 · 17 · 19** | 4 · 5 · 10 |
| `steps/gauge` · `nullsurf` | 24 · 61 | 10 · 20 | 1 · 2 | 0 | **13 · 39** | 2 · 9 |
| `steps/forque` · `spring` · `rigid` | 40 · 72 · 95 | 9 · 8 · 12 | 1 · 1 · 1 | 0 | **30 · 63 · 82** | 9 · 12 · 9 |
| `steps/groups` | 22 | 6 | 1 | 0 | **15** | 2 |
| `steps/category` | 309 | 191 | 13 | 0 | **105** | 24 |
| `steps/baez` | 309 | 238 | 6 | 0 | **65** | 13 |
| `steps/schuller` | 278 | 167 | 2 | 0 | **109** | 41 |
| `matter` (Calibration 2, Furey) | 205 | 24 | 7 | 9 | **165** | 44 |
| `lenses` | 16 | 4 | 0 | 10 | **2** | 0 |
| **the pages above** | **2,299** | **926** | **139** | **79** | **1,155** | **298** |
| the 15 equation steps together | 624 | 167 | 15 | 0 | 442 | 112 |
| the three lens chapters together | 896 | 596 | 21 | 0 | 279 | 78 |
| Logbook (v15 Map, For researchers), tally, Ask, chrome | 844 | 121 | 382 | 22 | 319 | 7 |
| **all** | **3,143** | **1,047** | **521** | **101** | **1,474** | **305** |

Read: half of the page prose of v15 (1,155 of 2,299 blocks, about 250,000 characters) is nowhere in V2, and 79 more blocks are copied into `content/story_frames.json` and `pages.json` `learnerFrame`, which no component reads. On Furey's page 165 of 205 blocks are missing; on the four steps built on a paper (spin, forque, spring, rigid) 252 of 296.

### 0.2 What the missing blocks are

| kind of block (by its key path in v15) | missing on the pages | becomes (§1, §3) |
|---|---:|---|
| statements and narrative of the body (threads, paper cards, findings text, stages) | 450 | story rows, or statements by the test of §1.4 |
| figure copy (widget intros, captions, legends, "how to read") | 189 | `caption` story rows under the section's figure |
| Young Learner strips (`yl`, `PLAIN`, `capY`, `SHORT[tab][0]` …) | 177 | learner texts of story rows (§1.5) |
| page and tab leads (`lede`, `short`, `SHORT[tab]`, `does`, `scope`, `words`) | 120 | `lead` story rows |
| section intros (`…Intro`, `MAP_TEXT` paragraphs, `intro`) | 95 | `lead` story rows of the sections |
| script and download notes (`dl`, `script`, `repro`, `take`) | 70 | left out: the Evidence drawer names the scripts and their runs |
| open and honest lists not yet rows | 33 | rows by the test (questions are `open`) |
| page frames (`h`, `before`, `after`) | 16 | page `next` lines; `before` left out |
| needs strips in plain words | 5 | learner text of the page's needs fold |

**Not a gap, on purpose:** `proofs.js` (69 blocks on `cells`: the per-cell proof sketches, drawer material by 06 `/cells`), `storyOverrides.js` (16: the role-name layer 01 drops on purpose), the 70 script notes, and the Logbook prose (the v15 Map page's 135 missing blocks and the For-researchers page's 121: the Logbook keeps tables; the tally's 53 lines belong to the physics audit's TL1). These stay out of the story round (decision A46).

### 0.3 The second loss: every row is an equal statement

- **No section has a name.** The 31 full-Atlas pages have 151 sections; every title in `pages.json` is its v15 anchor slug, turned into words by `sectionLabel` ("Top", "Ten", "Which", "Family (figure)"). v15 had a menu label (a name) and a heading for each; none survives.
- **No lead, no order of importance.** `Section.jsx` renders `sec.body.map(id => <Statement/>)`: the Baez page is 249 statements in 24 sections, all of one weight.
- **The learner lines are research rows.** 93 v15 Young Learner lines became research rows of their own on the three chapters (Baez 56, Schuller 25, category 12) and render at research level beside the formal lines they restate (A19).
- **Captions are cut from their figures.** 150 widget-copy rows (Baez 78, Schuller 36, category 36) sit in 19 sections named "… (figure)" at the end of their pages. A figure sits in the section of its caption row, so the three Baez figures all sit at the top (`five-bits` as hero figure, `e8-ladder` and `kepler-trio` in `bz-top`), not in "One generation", "The ladder" and "Kepler" where v15 drew them.
- **No figure has a caption.** `FigureFrame` asks for the caption row's text in the `caption` register; `texts.json` holds no record in that register (registers in use: `full`, `short`).
- **Steps lost their body.** A step page is needs + one section of all rows + the tally line. `steps/spin` shows its five open items and the tally (SPN-001…005, EQN-017); its six threads, eight widgets and 30-row matrix are gone (physics audit SP1–SP8).

### 0.4 Furey: five tabs became one section

v15's Calibration 2 (`FureyPage.jsx`) was five tabs read one at a time, each a head (eyebrow, title, lede in three voices, a short intro with "Full introduction" folded) and sections each holding a widget and its statements, with a closed "For older readers" fold for the learner. In V2 the 22 placements of `matter` sit in two sections, `furey` (14 rows) and `needs` (8); the hero shows `furey-board`, the section `dictionary-boards` and `ladders` (`ladders` is research only).

| v15 tab (title · learner title) | v15 content | rows in V2 | figures in V2 | figures P10 adds (physics audit) | missing |
|---|---|---|---|---|---|
| frame | `STORY.pages.furey` does / before / after; 4 tags; `fc.ui.calib` (said once, under the tab bar); report link | PAG-013…016 (the tags) | hero: `furey-board` | — | 3 (+9 stored, never shown) |
| The dictionary | lede + short; the build-up 0 → 8 switches (9 stages and the tail, each in two voices); the dictionary (pick an entry: Peirce simplex, Fano plane, 8-cube); the diagonal generators; the prime names; download | INP-087, INP-088 | `dictionary-boards` (its 16 × 16 grids not ported, A9) | — | 33 of 36 |
| Her papers | lede + short; six sections (six papers, one program; her five checkpoints; from Spin(10) to the Standard Model; one generation as numbers; trialities; how the papers fit), each with learner lines and formal statements; six paper cards (what it builds, what we rebuilt, in two voices); the five checkpoints (she says / we checked, in two voices); widgets Timeline, Checkpoints, Cascade, Spectra, Triality | PAG-013 (the list of papers), INP-089 | `ladders` (Cascade) | `furey-trialities` (Spectra, Triality) | 68 of 71 |
| Her 2026 model | lede + short; five sections (the blocks; Y and Q from five projectors; ten edges; sixteen axes; where it stays open) with five cards (learner + formal) and widgets Peirce, Charges, Edges, Axes | FUR-001…005 and their b-lines (the cards' formal texts, from `findingsData.js`), INP-090…092 | none of its own | `furey-charges` (Charges, the blocks table) | 14 of 31 |
| Three generations · How many families? | lede + short; five sections (the board of Fig. 1; counting complete sets; the missing irreps as products; room for three sets; where the 256 go) with Board, Ledger, Composites, Room, Whole | PAG-015 (one complete set, two doubled, three need 14), INP-093 | `furey-board` (Board and tally) | `furey-composites`, `furey-room` (Room, Ledger counts, Whole) | 24 of 26 |
| What may help | lede + short; five results she can use; six questions (four more in plain words); what was checked (Scoreboard of 30); take it with you (CSV, scripts) | PAG-016 (the open questions), INP-094 | — | — (Timeline and Scoreboard stay out: FU7) | 23 of 25 |

Of Furey's 165 missing blocks, 44 are learner texts and 44 carry v15's own status tags (`[tags, text]`; the tags: 25 checked, 11 open, 7 standard, 4 ours, some blocks carrying two): they are statements in v15's eyes (the counting statement, the composites, the room), not narration.

### 0.5 Baez: seventeen sections with intros became twenty-four lists

| v15 section (menu label) | v15 content (`BaezSection.jsx`, `baezCopy.js`, `baezIntegration.js`) | V2 (`steps/baez`) | gone |
|---|---|---|---|
| top | title; lede (physics) or ledeMath (mathematics); four lines; scope; "The statements, with their domains" (15, folded for the physicist); six theorems cited; words; widget BW2 | `bz-top`: 19 equal rows (LNB-001…011d); hero LNB-001 + `five-bits`; `e8-ladder` and `kepler-trio` also here | title, both ledes, scope, words, the fold, BW2 |
| Seven papers | intro; 7 paper lines; 2 points; widget BW5 (the map, its 34 caption lines) | `bz-papers` 12; `bz-w-papers` 34 at the end | intro, map paragraph; BW5 not drawn |
| One generation | BW1; findings J1, J2 (a title and 7 lines each) | `bz-generation` 20 (6 are learner lines); `bz-w-family` 10 | J1, J2 titles; map paragraph |
| The ladder | BW3; J3 | `bz-ladder` 8; `bz-w-ladder` 6 | title of J3; map paragraph |
| Which Standard Model? | hook to BW2; J6 | `bz-which` 7; `bz-w-which` 7 | J6 title; map paragraph |
| Ten dimensions | J7; the table of the 11 signatures with its caption | `bz-ten` 7 | J7 title; map paragraph; the table |
| Kepler | BW4; J8; link to step 11 | `bz-kepler` 15; `bz-w-kepler` 8 | J8 title; map paragraph |
| Periodic table | BW7 (physicist); J9 folded | `bz-periodic` 6; `bz-w-madelung` 6 | BW7 not drawn |
| The empty ring | BW6; J4 folded | `bz-ring` 8 (placed before "Which"); `bz-w-ring` 7 | map paragraph; BW6 not drawn |
| More findings | J5, J10 folded; links to the category lens and step 16 | `bz-more` 12 (placed before "Which") | titles, links |
| Same numbers · Gaps and limits · Honest list | 3 lines · intro, 9 gaps, limits, dead ends · 6 lines | `bz-numbers` 5 · `bz-gaps` 10 · `bz-honest` 12 | — |
| Perspectives · Questions · Notes | intro and 8 questions, each with "the statement behind the question" folded · intro and 8 · intro and 2, folded | `bz-persp` 17 · `bz-questions` 8 · `bz-notes` 2, all in the open fold, ungrouped | the three intros; the question/statement pairing |
| Bar and matrix · Script | honesty bar, its note, the matrix · script text, report | lens room · drawer | the note |
| Young Learner body | one sentence; ten sections of plain lines with their own menu; on v15's Map, eight map paragraphs in plain words | 28 plain lines are research rows; the rest missing | the learner page |

In numbers: v15 had a top, 17 named sections, 7 widgets inside their sections, 10 titled findings, 9 intros (papers, which, gaps, perspectives, questions, notes, bar, ten, the statements) and 8 map paragraphs (the chapter and 7 sections) in two voices. V2 has 24 sections titled by slug, 249 statements of one weight in a different order, no intro, no finding title, the widget lines detached, four of seven widgets undrawn. 65 of 309 blocks are missing; 36 of the 246 LNB rows are kind `meta` (paper lines, limits, captions: narration already).

### 0.6 Schuller and the category lens

**Schuller** (`steps/schuller`): v15 had 21 named sections (first … sources) with headings, 7 intros, titled findings, 7 widgets (SW1–SW7) inside their sections and a learner body of 11 sections after its lede. V2: 174 placements in 26 sections, 7 "(figure)" sections holding 36 widget rows, 25 learner lines as research rows; 109 of 278 blocks missing (41 learner).
**Category** (`steps/category`): v15 had 19 named sections with headings and 5 intros, the perspectives P1–P6 as one section, 6 widgets. V2: 158 placements in 29 sections, P1–P6 split into six sections of one to three rows, 5 "(figure)" sections holding 36 widget rows, 12 learner lines as research rows; 105 of 309 blocks missing (24 learner).

---

## §1 Narration rows

### 1.1 The rule

A **narration row** (kind `story`) carries the author's own words from v15: an intro, a section lead, the reading of a figure, the bridge to the next page. It states no law of its own. Its status is `meta`: no badge, never `new`. A v15 block that states a law is not a story row: it is a row the Atlas already has (nothing is added), or it becomes a `reading` (badge "our reading"), or — when a check that ran proves it and the author accepts — a statement row with that evidence. The invariant of D2 stays: every text that counts is a text record of a row; the coverage test needs no exception.

### 1.2 The record

```jsonc
// content/story/rows.json (an overlay, merged by tools/merge_story.mjs; 02 §1 gains the kind "story" and the relation "restates")
{
  "id": "FUR-512",                 // the natural group of its page, numbers 501–999 (§1.3)
  "group": "FUR",
  "kind": "story",
  "stage": "M", "ptype": null,     // narration has no physicist's type
  "notions": ["i-meta"],           // as every meta row (02 §1), so status = meta by the existing rule
  "fields": [], "phenomena": [], "cells": [], "homePhys": "", "homeMath": "", "standardRef": null,
  "evidence": [],                  // narration cites nothing; the rows it restates carry the evidence
  "depends": [{ "id": "PAG-015", "rel": "restates" }],   // the rows whose numbers and formulas it repeats (§1.4 T4); [] when it has none
  "links": [], "lensTags": [], "legacyFlags": [], "legacyLines": 0, "legacyLabel": "story", "legacyKnown": false,
  "since": "v2.2",
  "tabV15": "threegen", "anchorV15": "fy-count",
  "source": "fureyCopy.js#fc.threegen.secs.count.yl.0",  // provenance of the research text (file#path, the claims locators' form)
  "shownOn": [{ "page": "matter/generations", "section": "count", "order": 0, "role": "lead" }],
  "visibleTo": ["phys", "math"],
  "review": null, "notesPersona": [], "theorems": [], "readingRefs": 0, "v16": [], "splitFrom": null, "labelFrom": null
}
```

### 1.3 Ids, texts, roles

- **Ids.** `<GROUP>-501` to `<GROUP>-999` in the group of the page (the 500s are narration; the v15 ranges end at 178, Explore and the physics wave continue them from below): `atlas` (Zero) and `light` PAG · `rule` GEN · `cells` ATL · `clock`, `steps/gauge`, `steps/groups` LAB · `shapes` SHP (orthoplex, demicube), GOS (Gosset) · `steps`, `steps/comm`, `steps/dirac` EQN · `steps/mirrors` MIR · `steps/spin` SPN · `steps/coupling` CPL · `steps/ym` YM · `steps/matter` MAT · `steps/grav1`, `grav2` GRV · `steps/projective` PRJ · `steps/nullsurf` NUL · `steps/forque` FRQ · `steps/spring` SPR · `steps/rigid` RIG · `steps/category` LNC · `steps/baez` LNB · `steps/schuller` LNS · `matter/*` FUR · `lenses` LNP. `content/story/ids.json` (locator → id) keeps ids stable across re-runs.
- **Texts** (`content/story/texts.json`, status `human`, `source` = the v15 locator): research `full` = the formal voice (`lede`, `intro`, the formal caption); research `short` = v15's short version where it had one (`SHORT[tab][1]`, `short[1]`), used where a page shows the row in one line (the home's chapter cards at research level), never in place of a learner text (`textFor` never falls back across levels); **mode variants** where v15 had them (Baez `lede`/`ledeMath`, Schuller `first.lede`/`ledeM`, category `ledeP`/`ledeM`: `mode: "phys"` and `mode: "math"`); learner `full` = the v15 Young Learner words (§1.5). A text body is the v15 string verbatim; a block of more than 900 characters stays whole (D15's spirit), and `Statement` folds it as it folds long rows.
- **Roles** (`shownOn.role`): `lead` — at most one per section; the page's own lead sits in the reserved section `intro`; rendered first, before the figure. `caption` — the reading of the section's figure, rendered under it. `result` — statements; the first N are the key results (§2.2). `detail` — rendered in the section's "More statements (n)" fold (the inputs keep their own place: §2.1). `learner` — a row shown only at learner level, where v15's plain body showed it (the 93 learner lines of §0.3, decision A42). `next` — one per page, in `intro`, rendered by `PrevNext` above the link to the next page (v15's `after`). `evidence` — unchanged (drawer, Numbers).

### 1.4 The test: does a block state a law?

S1 runs it on every candidate block; the author reviews what it flags.

| # | signal | how (mechanical) |
|---|---|---|
| T0 | v15 printed it as a statement | the block is the text of a `[tags, text]` pair, or sits in a statement list of v15 (`findings[].lines`, `pts`, `items`, `p`, `m`, `open`, `honest`, `questions`) |
| T1 | a formula | the R4 mark set of `tools/check_learner_texts.mjs` (`$ \ ^ _ { } = < > \| ~`, operators and arrows, super- and subscripts, Greek letters, ℝ ℂ ℍ 𝕆, `½`), and `Cl(p,q)`-style names |
| T2 | a claim word | prove(s/d), proof, theorem, lemma, equals, equivalent, iff, implies, unique(ly), exactly, always, never, isomorphic, reduces to, is given by, holds, fails, vanishes, (anti)commutes, squares to, must, cannot |
| T3 | a free number | a number that is not an identifier by R6's list (step numbers, `Cl(1,3)`, ids, arXiv numbers, years) |
| T4 | it restates | every T1 token and T3 number of the block occurs in the research text of a row of the same section (or the page's hero); `depends` names those rows with `rel: "restates"` |
| T5 | statuses kept | each restated row whose status is `ours`, `open`, `cited` or `input` has its status word in the block (R8's list) |

**Outcomes.** `story` when T0–T3 are all absent, or when T4 and T5 hold (it repeats what rows state, carrying their statuses). `held` when a signal is not cleared (it states something no row of its section states): the block waits in `content/story/pending.json` for the author (A38). `statement` when T0 holds: the block is proposed as a row with v15's tags as `legacyFlags` and, where its words or its tab name a check that ran, that evidence (A39); it waits in `pending.json` too. Measured on the 710 research blocks the pages miss (after the 155 left out and the 290 learner strips): **200** have no signal; **258** have one signal, of which about 214 restate their page's rows; **199** have two or more, of which 123 restate; **53** are v15 statements (T0). So about **537 story rows**, about **120 held** and **53 proposed statements**; of the 129 law-like leads and section intros, 100 restate. (The restating figures were measured against the rows of the whole page; S1 measures per section, which can only hold more.)

**The review table.** S1 writes `docs/STORY_REVIEW.md` from the data: one line per `held`, `statement` and T4-cleared block — proposed id, page and section, locator, the first 160 characters, the signals, the restated rows, the default — with a column for the author's choice: `story`, `reading`, `statement:<check id>`, `same-as:<row id>`, `drop`. The choices live in `content/story/review.json` (locator → choice), which every run of the tool reads, so a re-migration keeps them.

### 1.5 Learner texts of story rows

The v15 Young Learner strips are the learner texts of the story rows when they exist (status `human`, `source` their locator); S1 pairs them mechanically, from v15's own structure:

| v15 learner source | paired with |
|---|---|
| `audienceCopy SHORT[tab][0]`, `fc.<tab>.short[0]` | the tab's lead (learner `full`); `[1]` is the same row's research `short` |
| `STORY_YL.pages.<p>.does`, `.after` | the page lead, the `next` row |
| `STORY_YL.pages.<p>.tags[i]`, `PAGE_YL.tags[i]` | the row made from the same tag of `STORY`/`PAGE` (the 36 PAG rows and the 4 LNP rows; it replaces their drafts, A47) |
| `secs.<s>.yl` (Furey), `COPY.yl.en.<section>` (chapters), `PLAIN.<step>.story`, `<step>.yl`, `MAP_TEXT.yl` | the section's lead; further paragraphs become learner-only story rows (role `learner`) |
| `capY`, `introY`, `pictureY`, `noteY`, `PIC_YL[tab]`, `YLM`, `YLC`, `CWC/SWC.*.yl.caps` | the caption row of that figure |
| `cpDetailY`, cards' `yl` | the checkpoint and card rows |
| `PLAIN.<step>.try` | not a row: the section's connective at learner level (an instruction, ≤ 240 characters, as Explore's try line) |
| the 93 chapter learner lines (research rows) | their own learner text = their research text (human), role `learner` (A42) |

Measured: 298 learner blocks are missing on the pages and 41 more are stored in `story_frames.json`. A story row without a v15 strip gets a learner **draft** through `09_TRANSLATION_PROTOCOL.md` with a story variant of the persona ("You rewrite one narration paragraph of the Atlas for a reader before university … no number and no claim the paragraph does not make; keep its status words"), checked by R1–R13 unchanged, merged by `merge_learner_texts.mjs` from `content/texts_learner_story.json` (S5). As for every row, a story row without a learner text is not shown at learner level.

### 1.6 Status, badge, and what a story row may not do

`tools/build_content.mjs`: kind `story` → status `meta` and badge `null` always (today a meta row with `since` in NEW_SINCE would get `new`); `v2.2` is not added to NEW_SINCE (the round adds no new mathematics); `restates` is a valid relation. The 1,013 existing rows keep their status byte for byte. Checked at merge and in `tests/story/migration.test.mjs`: a story row's research text equals the v15 string at its locator; it carries `["i-meta"]`, no evidence, no badge; T4/T5 hold for its numbers and formulas; it holds no 40 characters of another row's text; its section has no other lead; it gets no lens reading (`tools/migrate/lens_readings.mjs` skips kind `story`: a reading names an element a row states, D7); a banned history word in it is reported as "author's text" (shipped rule 1), never edited.

---

## §2 Page composition

### 2.1 The page

1. `PageHeader` — unchanged (a sub-page reads "Calibration 2 · Her papers").
2. **Intro** — the page's `lead` story row (v15 `does`, or the tab's lede), one paragraph under the header; at learner level its learner text.
3. `Hero` — unchanged: one statement (short register at learner level) and one figure, full width under the statement from 1100 px when the seed says `size: "wide"` (D31); at learner level the "How do we know?" line. The hero figure's caption rows render under it.
4. **At a glance** — the page-strip rows PAG-001…034, which are v15's tags under the page intro, as the intro's key results (A48), at both levels (learner: v15's own learner tags, A47).
5. **Parts and sections** — on the chapter pages, part headings (`h2`) group the sections (`h3`); elsewhere sections follow one another. Each section by §2.2.
6. **Open items** — the open fold, grouped by part (the chapters' perspectives, questions and notes each one group, as v15 had them).
7. **What this page takes from outside (n)** — the inputs (the `needs` sections' INP rows) as one folded list with their badges, at the end (06's "Inputs render as a compact list"), in place of a body section titled "Needs".
8. `PrevNext` — with the `next` row above the link.

### 2.2 The section

```
title            a name: v15's menu label (research) and the learner menu label (learner) — A44
lead             the one `lead` story row
figure           pages.json section.figure (explicit; a wide seed takes the column width), then its `caption` rows
key results      the first N `result` rows in order (N = 3 learner, 5 research; section.key overrides) — A45
More statements  a closed fold "More statements (n)": the other results, then the `detail` rows
drawer           "Evidence and more", unchanged (it lists the section's statements; a story row has no evidence of its own)
```

A section without a lead starts with its figure or its first result; S1 reports how many such sections each page keeps. A figure assigned to a section (or to the hero) is not placed again by its caption row; the caption-row rule stays only for figures no page assigns.

### 2.3 The two levels

**Learner:** intro → hero (short text, picture, "How do we know?") → each section: learner title, lead, picture with learner captions and the try line, three key results (the section's `learner` rows first, when it has them, as v15's plain body did; then results with learner texts), "More statements (n)" closed → "Not finished yet" → next line. No formula anywhere (D5); a section with nothing in plain words is left out; fewer than three results on the page keeps the "no plain-words version yet" notice.
**Research:** everything, folded where long: intro, hero, at a glance, sections with lead, figure, captions and key results open, the rest in "More statements", open items and inputs folded, every drawer one click away. `learner` rows are not shown (their formal neighbours are).

### 2.4 The chapter pages regain their v15 structure

Section order, titles and intros come from v15; S2 writes them in `content/story/chapters.json`. Baez (`steps/baez`):

| part | section | title (research · learner) | lead | figure | key results / fold |
|---|---|---|---|---|---|
| — | `intro` | — | `lede` (phys) · `ledeMath` (math) · learner `yl.sentence` | hero `five-bits` (LNB-001) + BW1 captions | — |
| — | `bz-top` | (none: v15's top had no heading) | `scope` | (BW2 not drawn) | LNB-001b…001d; fold: the 15 statements LNB-002…011d (v15 folded them for the physicist), `words` as a detail story row |
| Seven papers | `bz-papers` | Seven papers | `papersIntro` (learner: map paragraph) | (BW5 not drawn) | the 7 paper lines; fold: 2 points; BW5 lines as `detail` until BW5 is drawn |
| What the rule finds | `bz-generation` | One generation · One family | map paragraph | — (the hero shows it) | J1, J2 first lines; fold: the rest |
| | `bz-ladder` · `bz-which` · `bz-ten` · `bz-kepler` | The ladder · Which Standard Model? · Ten dimensions · Kepler (Three orbits) | map paragraphs | `e8-ladder` · — · the signature table when drawn · `kepler-trio` | the finding's first lines; captions from `bz-w-*` |
| | `bz-periodic` · `bz-ring` · `bz-more` · `bz-numbers` | Periodic table (Electrons) · The empty ring · More findings · Same numbers | map paragraph where v15 had one | BW7, BW6 when drawn | v15 order (ring after periodic) |
| What the atlas cannot reach | `bz-gaps` · `bz-honest` | Gaps and limits (Nothing there) · Honest list | `gapsIntro` | — | the lines; the bar and matrix stay in the lens room |
| open fold | Perspectives · Questions · Notes | as v15 | the three intros as the groups' leads | — | each perspective's question with its statement folded under it |

Part titles are v15 headings where one exists (Seven papers; What the atlas cannot reach; His chain, our trail; Where the rule stops); the others named here are proposals for A44. Rules for all three chapters: the "(figure)" sections disappear — their rows become `caption` rows (or `detail`) of the section that holds the figure (A43); the finding titles that state a law become the `short` research text of the finding's first row when the author confirms it is the same statement, else they stay out (A49); the questions, perspectives (category P1–P6 as one group with six sub-groups) and notes are grouped in the open fold; the scripts and the honesty bar stay in the drawer and the lens room. Schuller: parts "His chain, our trail" (chain, table, hyper, area, deform), "Fibre and base" (fibre, fock, spin, total, bands), "Where the rule stops" (stops, quantum, honest); open fold: perspectives, notes, questions; `thm`, `scripts`, `sources` in the drawer. Category: parts "What label 0 is" (zero, defs, label0, twozeros), "Structures on the labels" (frobenius, moves, top, cube, bottom, arrows), "More findings and background" (more, papers), "Dead ends and refinements" (deadends, refine), "Limits" (honest); open fold: perspectives P1–P6, questions.

### 2.5 Furey's page regains its tabs

**Sub-routes** (A40): `matter` keeps the calibration's overview — intro (`STORY.pages.furey.does`), the calibration sentence once (`fc.ui.calib`, which v15 printed under the tab bar and V2 keeps only in the glossary), hero FUR-001 + `furey-board`, the four tags as "at a glance", and the tab strip — and five pages hang under it, each a full page of the generic frame (hero, sections, drawers, open fold, deep links, coverage):

| route | title · learner title | lead | sections (v15 `secs`, titles `h` · `hy`) → figure | rows placed there |
|---|---|---|---|---|
| `matter/dictionary` | The dictionary | `UI.lede` + `SHORT.dictionary` | build-up 0 → 8 (stages, story or held by T1) · the dictionary → `dictionary-boards` · the seven channels (Fano) · the diagonal generators · prime names | INP-087, 088 (inputs) |
| `matter/papers` | Her papers · Her papers, in the order they came out | `earlier.lede` + `short` | six papers, one program (the six paper cards) · her five checkpoints (she says / we checked) · from Spin(10) to the Standard Model → `ladders` · one generation as numbers · trialities → `furey-trialities` (it draws the spectra too) · how the papers fit | PAG-013, INP-089 |
| `matter/model` | Her 2026 model · The big board, block by block | `findings.lede` + `short` | the blocks · Y and Q → `furey-charges` (with the blocks table) · ten edges · sixteen axes · where it stays open (open fold) | FUR-001…005 (+ b-lines), INP-090…092 |
| `matter/generations` | Three generations · How many families? | `threegen.lede` + `short` | the board of Fig. 1 → `furey-board` · counting complete sets · the missing irreps as products → `furey-composites` · room for three sets → `furey-room` (with where the 256 go) · where the 256 go | PAG-015, INP-093 |
| `matter/help` | What may help | `help.lede` + `short` | five results she can use · questions our numbers leave to her (open) · what was checked (the count only; Scoreboard stays out) | PAG-016, INP-094 |

Who owns what: **P10** (physics wave) owns the four new Furey figures, the edits of `FureyBoard.jsx` and `Ladders.jsx` (learner ladders), their seeds in `content/physics/figures.p10.json`, `content/stored_p10.json` and `engines/fureyPapersEngine.js`. **S3** owns the six Furey pages (`content/story/furey.json`), the placement of rows and figures by tab, `SubNav.jsx`, and the Furey part of the review: v15's 44 tagged statements of Furey proposed as rows with the evidence of the scripts that ran (`furey_papers_check.py`, `threegen_selfcheck.py`, `dictionary_selfcheck.py`), which is the physics audit's D33 seen from the rows' side. S3 names P10's ids before they exist (§3.2, PENDING_FIGURES); P10 never edits page layout.

### 2.6 The other pages

- **The 15 equation steps:** the intro is the tab's lede (`SHORT[step]` as short and learner text, `PLAIN.<step>.story` as learner paragraphs); the sections follow v15's tab: the six threads of spin, the four lines of forque, the six threads of spring and the seven of rigid, the views, identities and checks of the others; each section names the figure the physics wave draws for it (P5–P11 ids, §3.2); the open lists stay rows in the open fold. The law-like thread texts of spin, forque, spring and rigid restate few rows (their content is the matrices of physics-audit D32): most will be `held`, and the author decides them together with D32.
- **`light`:** intro `STORY.pages.maxwell.does`; sections views, charges, ladders with the leads of `MaxwellSection` `T` and `ChargesWidget` `T`, captions from their `YLM`/`YLC`; the P1/P4 figures.
- **`shapes`, `clock`, `cells`, `rule`, `steps`, `lenses`:** intro from `STORY.pages.<p>.does`; section leads from `shapesCopy`, `gossetCopy`, `labelsCopy` tabs, `conventionsCopy` CONV ledes, `lensesCopy`; the cards of `cells` keep `ylAtlas.js` as their learner texts.

### 2.7 Two entries: Explore at `#/`, the Atlas at `#/atlas`

Recommendation (A41): `#/` renders the Explore home — the path of eight leaves, the shelf, the lens explorers — with one new part, **"The Atlas, chapter by chapter"**: a card per main page (the rule, the cells, the clock, light, the twenty steps, shapes, matter, lenses), each showing the page title and its `lead` story row (short register at learner level), linking to the page. The present Zero page moves to `#/atlas`, titled "The Atlas" (the rule in one screen, the steps by stage, the calibrations), reached from the home's door and second in the Contents menu after "Explore". A first visit with no settings in the address and none stored opens at learner level (the shell's switch reaches research). `#/explore` keeps working. This is what Octavo was for: the leaves picture the concepts, the chapter cards translate each page into one paragraph of the author's words, the Atlas stays one click away.

### 2.8 Ask answers with story rows first

The answer has two lists, both rows rendered by `Statement`: **"Where to read about it"** — up to three `lead` story rows holding most of the question's words, each with the page it lives on — then **the statements** — the matching non-story rows, as today (most words first, at most 12). The status words fold and the persona rules are unchanged; an empty answer stays one line.

### 2.9 What changes in the model

`pages.json` (through the overlays): a section gains `figure`, `key`, `part` and a real `title` `{ phys, math, learner }`; a page gains `parts: [{ id, title, sections }]`, `parent` and `tab` (sub-pages), and the reserved section `intro`. `buildPageModel` (S2) returns `intro: { lead, next, glance }`, `parts`, and per section `lead`, `figure`, `captions`, `key`, `more`, `learnerRows`; it exports `pageLead(route, settings)` for the home's cards. 02 §1 gains kind `story`, relation `restates`, roles `lead`, `caption`, `learner`, `next`; 02 §7 gains the meaning of `detail` as "More statements" (no existing row changes: today every `detail` row outside the Logbook is an input of a `needs` section, which §2.1 item 7 renders).

---

## §3 Migration

### 3.1 `tools/migrate/story_from_v15.mjs <v15 root>`

1. **Read** the copy modules (dynamic import, read-only) and the three JSX copy blocks (bundled into a temporary folder with esbuild, constants exported, as `tests/coverage.test.mjs` bundles its entry); walk the English strings; locators `file#path` (`fc.` prefix for `fc('en')`, `<Component>.jsx#CONST.en.…` for the JSX blocks).
2. **Map** each string by an explicit table (unknown paths fail the run; nothing is guessed per string):

| v15 source | V2 route · section | becomes |
|---|---|---|
| `storyCopy` `STORY`/`STORY_YL` `.pages.<p>.does` · `.after` · `.tags` | page of `<p>` · `intro` | page lead · `next` · learner texts of PAG rows (`.before` left out) |
| `audienceCopy` `SHORT[tab]` · `PIC_YL[tab]` | the tab's page | lead's short and learner texts · caption learner texts |
| `conventionsCopy` CONV ledes, `PAGE`; `labelsCopy` tabs, lattice, trinity, biv, pg, curv, rails, golay, primes | `rule`, `clock`, `steps/gauge`, `steps/groups` | leads, captions (rows, ideas, glossary are tables already) |
| `MaxwellSection` T/VL/TX/BIG/YLM · `ChargesWidget` T/YLC | `light` views, ladders · charges | leads, captions, learner texts |
| `shapesCopy` o, d · `gossetCopy` | `shapes` `sh-orth`, demicube, `sh-gosset` | leads, captions, body |
| `equationsCopy` c, d; `mirrorsCopy` … `rigidCopy`; `plainStepsCopy` `PLAIN.<step>` | `steps/<step>` | intro, thread sections, captions, learner texts |
| `fureyCopy` `fc('en')` ui, earlier, findings, threegen, help; `DictionarySection` UI/STAGE/TAIL/CARTAN_INFO/YL | `matter`, `matter/<tab>` | leads, sections, captions, card learner texts, statements (T0) |
| `categoryCopy`/`baezCopy`/`schullerCopy` (+ `yl`), `*WidgetsCopy`, `*Integration` `MAP_TEXT` | `steps/category`, `baez`, `schuller` | intros, section leads, map paragraphs, captions, learner texts |
| `lensesCopy` PAGE · `inputsData` `NEEDS.<tab>.yl` | `lenses`, `steps` · the page's inputs fold | page lead · learner-only lead of the inputs list |
| `atlasLines`, `ylAtlas`, `cellStatusCopy` | `cells` | rows already; card learner texts |
| `proofs.js`, `storyOverrides.js`; `equationsCopy` t (tally); `mapCopy`, `researchers*`, `researcherNotes`; `PERSONA`; keys `dl`, `script*`, `cmd`, `repro`, `report`, `take`, `prov` | — | left out (A46; the tally is TL1's) |

3. **Dedupe** against `texts.json` (locator, exact, containment, ≥ 88 % words): a block that is a row adds nothing, and gives that row its v15 place (step 7).
4. **Test** each block (§1.4) and apply `content/story/review.json`.
5. **Pair** learner strips (§1.5); unpaired strips become learner-only story rows (role `learner`).
6. **Ids** from `content/story/ids.json`, new ones appended in page and v15 order.
7. **Lay out** each page from v15's render order, transcribed once per page into the tool as an ORDER table from the v15 component (e.g. `BaezSection.jsx` `FormalBody`: top, papers, generation, ladder, which, ten, kepler, periodic, ring, more, numbers, gaps, persp, questions, notes, honest): section order, titles (menu labels; learner menu labels), parts, the figure of each section (the V2 port of the v15 widget that sat there, existing or listed in PENDING_FIGURES), the lead, and `order` for story rows and for existing rows on their home page (0–999; a row's home never moves: every existing row keeps the page of its lowest `order`, checked).
8. **Write** `content/story/rows.json`, `texts.json`, `layout.json`, `sections.json`, `pending.json`, `docs/STORY_REVIEW.md`, and the counts under `story` in `content/MIGRATION_COUNTS.json`. Deterministic: two runs give the same bytes.

### 3.2 The overlay

```
content/story/rows.json       story rows (since "v2.2"), full records of §1.2                         S1 (generated)
content/story/texts.json      their texts, and the human learner texts paired to existing rows        S1 (generated)
content/story/layout.json     [{ row, page, section, order, role }] replacing the row's entry on that page (same page; order < 1000)   S1
content/story/sections.json   per page: sections (id, title, part, figure, key), parts, intro          S1 (generated)
content/story/chapters.json   the three chapters, hand-made over sections.json                         S2
content/story/furey.json      matter and its five sub-pages: entries, sections, figures, layout        S3
content/story/landing.json    { routes: { "": "atlas" } } and the home's chapter list                  S4
content/story/ids.json        locator → id                                                            S1
content/story/review.json     the author's choices, locator → story | reading | statement:<check> | same-as:<row> | drop   the author
content/story/pending.json    held blocks and proposed statements: never merged                        S1 (generated), S3 (Furey's evidence)
content/story/pending_figures.json   the figure ids the physics wave will register (below)             the lead (step 0)
```

Precedence: `chapters.json`, `furey.json`, `landing.json` over `sections.json`. **PENDING_FIGURES** (the lead writes it at step 0 from PHYSICS_AUDIT §4): the ids P4–P11 will register (`maxwell-ladders`, `comm-ladder`, `spin-rotor`, `spin-hestenes`, `spin-pointor`, `spin-halves`, `spin-matrix`, `forque-lines`, `forque-matrix`, `coupling-ring`, `coupling-ladder`, `ym-graph`, `ym-ladder`, `matter-halves`, `matter-ladder`, `curvature-pairs`, `einstein-terms`, `cosmological-generator`, `null-pair-moves`, `null-neck`, `null-criterion`, `spring-oscillator`, `spring-faces`, `spring-table`, `rigid-segment`, `rigid-square`, `rigid-frame-table`, `furey-charges`, `furey-composites`, `furey-room`, `furey-trialities`). A section may name one; until it exists it renders nothing and the story test lists it; at the release the list must be empty or each entry explained.

### 3.3 `tools/merge_story.mjs`

Merges the overlay into `rows.json`, `texts.json` and `pages.json` as `merge_explore.mjs` does (replace by id, text key, route; idempotent; `--check`; on an error nothing is written): story rows; their texts (a `human` text of an existing row is never replaced; a paired v15 learner text replaces a `draft` of the same key); the layout (same page only; order < 1000; the home of every existing row unchanged); the sections and parts; the route renames of `landing.json` (pages and shownOn). It refuses a story row that fails §1.6, a second lead in a section, a `caption` in a section without a figure, a section figure that is neither in `figures.json` nor in PENDING_FIGURES. It runs after `merge_explore.mjs` and the physics merge, before `build_content.mjs`, in `npm run content` and `tools/migrate/run_all.sh`.

### 3.4 Order and roles

Within a section: the lead first (`order` 0), then v15's order — the order of the lines in their finding, of the findings in their section, of the widget in the section (captions follow the figure). `lead` on exactly one row in every section v15 introduced (an intro, a map paragraph, a short), none elsewhere. `caption` for widget copy (the 150 chapter widget rows included, A43): v15 printed it with its widget, and a fold away from the picture would repeat the "(figure)" sections in small (SL8); `detail` for the copy of a widget V2 does not draw, for the tally lines that stay on a page, the second paragraph of an intro, folded statements v15 folded (Baez's 15 statements, the J9/J4/J5/J10 folds). `learner` for the 93 chapter learner lines and the unpaired strips.

### 3.5 Counts to verify (`MIGRATION_COUNTS.json` → `story`, pinned by `verify_counts.mjs`)

Baseline from this plan (S1 reproduces it or explains each difference): strings walked 11,514; prose blocks 3,176, unique 3,143; on the pages 2,299 = 926 rows + 139 tables + 79 frames + 1,155 missing; of the 1,155: 155 left out (proofs 69, overrides 16, script notes 70), 290 learner strips, 710 research blocks = about 537 story + about 120 held + 53 proposed statements; from the frames, about 22 page leads and `next` rows and 41 learner texts. Expected after the merge: about 560–620 story rows, about 330 human learner texts paired, the 1,013 existing rows with unchanged status and home, every chapter section with a v15 intro holding exactly one lead, zero "(figure)" sections, zero section titles equal to their slug.

---

## §4 Agent briefs

### Order, ownership, interfaces

**Step 0 (the lead):** take the decisions of §5; after v2.1.1 is released (P3's D31 change of `Hero.jsx` in), create `content/story/*.json` as `[]` (`landing.json` `{}`), `tests/story.test.mjs` (a runner of `tests/story/*.test.mjs`, joined to `npm run test:data`), PENDING_FIGURES (`content/story/pending_figures.json`), and in `package.json` the merge line (`node tools/merge_story.mjs` after the Explore and physics merges in `content` and `test:data`); one line in `tools/migrate/run_all.sh`.
**Waves:** 1 — S1, S2 (on a fixture overlay of its own until S1 lands), S4 in parallel · 2 — S3; S2 finishes the chapters on S1's output · 3 — S5. The physics wave P4–P11 can run beside waves 1–2: the files are disjoint (table below); S5 runs after both and releases them together (SL1).

| owner | creates | may edit | never |
|---|---|---|---|
| **S1** narration rows | `tools/migrate/story_from_v15.mjs`, `tools/merge_story.mjs`, `content/story/{rows,texts,layout,sections,ids,pending}.json`, `docs/STORY_REVIEW.md`, `tests/story/migration.test.mjs` | `tools/build_content.mjs` (kind `story`, badge, `restates`, roles), `tools/migrate/lens_readings.mjs` (skip `story`), `tools/migrate/verify_counts.mjs` | `content/figures.json`, src |
| **S2** composition | `src/components/{Lead,MoreFold,Part,InputsFold}.jsx`, `src/styles/story.css`, `content/story/chapters.json`, `tests/story/composition.test.mjs`, `tests/ui/story.smoke.test.mjs`, `tests/story/fixture/*` | `src/app/queries.js`, `src/app/vocab.js`, `src/pages/PageView.jsx`, `src/components/{Section,OpenFold,PrevNext,PageHeader}.jsx`, `src/components/Hero.jsx` (caption rows only, D31 kept), `src/styles/components.css` (append) | `Statement.jsx` (P11's hook), figures |
| **S3** Furey | `content/story/furey.json`, `src/components/SubNav.jsx`, `tests/story/furey.test.mjs` | the Furey entries of `pending.json` (evidence and labels of the proposed statements) | P10's figures and seeds |
| **S4** landing, Ask | `content/story/landing.json`, `tests/story/{landing,ask}.test.mjs` | `src/app/router.js`, `src/app/App.jsx`, `src/app/settings.js` (first visit), `src/app/search.js`, `src/pages/{Zero,ExploreHome,Ask,NotFound}.jsx`, `src/components/Shell.jsx` | queries.js (asks S2) |
| **S5** learner, tests, release | `content/texts_learner_story.json`, `docs/LEARNER_TEXTS_story.md`, `docs/RELEASE_NOTES_v2.2.md` | `tests/coverage.test.mjs`, `tests/shipped.test.mjs`, `tests/ui/smoke.test.mjs`, `tests/explore/pages.test.mjs`, `tests/logbook.test.mjs`, `src/logbook/registerModel.js` (kind order: one word), `package.json` (version), `CHANGELOG.md`, `docs/DECISIONS.md`, `docs/HANDOVER.md`, `README.md`, `tools/release.sh` | — |

Disjoint from the physics wave: P-owners hold `src/figures/physics/*`, `engines/physics/*`, `tools/physics/*`, `content/physics/*`, `content/stored_p*.json`, the figure files and engines the audit names, `src/components/TallyLine.jsx` and the one hook in `Statement.jsx`. Shared suites (`coverage`, `figures.render`, `shipped`, `smoke`) change in one place at a time: S5 last.

Interfaces (numbered after BUILD_CONTRACTS' 24):
25. **Story overlay** (S1 → all): the files of §3.2, the record of §1.2, the texts of §1.3.
26. **Roles** (S1 writes, S2 renders): `lead`, `caption`, `result`, `detail`, `learner`, `next`, `evidence`; the reserved section `intro`.
27. **Page model** (S2 → S3, S4): `buildPageModel` as §2.9; `pageLead(route, settings)`.
28. **Section figures** (S1, S2, S3 write; S2 renders): `section.figure` explicit; an id of `figures.json` or PENDING_FIGURES; a missing figure renders nothing; explicit assignment wins over caption-row placement.
29. **Sub-pages** (S3 → S2, S4): entries with `parent` and `tab`; `PageHeader` eyebrow "<parent title> · <tab title>", `SubNav` lists the siblings, `PrevNext` walks them, the Contents menu hides them.
30. **Landing** (S4): `''` → Explore home; `atlas` → the Atlas page (route renamed in content); `explore` kept; Contents: Explore, The Atlas, then the pages; first visit at learner level if A41 is taken.
31. **Ask** (S4): the two lists of §2.8.
32. **Learner texts of story rows** (S1 pairs, S5 drafts): §1.5.
33. **Status** (S1): §1.6.

### S1 — Narration rows: the migration and the merge (wave 1)

- **Scope:** §1 and §3: every page block of §0.1 → story rows, paired learner texts, layout, sections, pending; the merge; the status rules; the review table.
- **Do:** implement §3.1 step by step (the mapping table complete and exhaustive; ORDER tables from the v15 components); the test of §1.4 as a function with the exact R4 and R6 sets imported from `tools/check_learner_texts.mjs` (no copy); the 93 chapter learner lines (`layout.json` role `learner`, learner text = research text, human); the 150 chapter widget rows as captions of their section's figure; the PAG rows into `intro` with their v15 learner tags.
- **Verify:** two runs → identical files; `node tools/merge_story.mjs --check`; `npm run content`; `node tests/story/migration.test.mjs` (each story text = the v15 string at its locator, re-read; ids unique, 501–999, in their group; `["i-meta"]`, no evidence, status meta, no badge; one lead per section; T4/T5; no 40 characters of another row; homes unchanged; `status.json` unchanged for the 1,013 rows; counts = MIGRATION_COUNTS; `pending.json` not merged); `npm run test:data` green.
- **Report:** the counts of §3.5 with each difference explained; sections per page with and without a lead; the held and proposed blocks by page.

### S2 — Page composition and the chapter structure (waves 1–2)

- **Scope:** §2.1–2.4 and §2.9: the page and section templates at both levels, parts, the inputs fold, the open fold grouped, the next line, explicit figures; the three chapters' `chapters.json`.
- **Do:** `Lead.jsx` renders a story row through `Statement` (`variant="lead"`, no badge, no evidence chevron, an anchor `row-<id>` for `at=`), so the coverage invariant holds unchanged; `MoreFold.jsx` is a `<details>` with "More statements (n)" (a connective); captions under the figure; the key results by `key`. Sort stays per mode inside key and fold; leads, captions and next lines are placed by role, never sorted. Section titles from the overlay; `sectionLabel` only for sections without one.
- **Verify:** `sh build.sh`; `node tests/coverage.test.mjs` green as it stands; `node tests/story/composition.test.mjs` (server-side, every page × level × mode: order lead → figure → captions → ≤ N key → fold; titles are names (≤ 60 characters, no claim word of T2, no final period); learner: no `learner`-role row at research level; chapters in v15 order with their parts; no "(figure)" section); `node tests/ui/story.smoke.test.mjs` (390 and 1366 px, light and dark: `steps/baez`, `steps/spin`, `matter/generations`, a learner page; no overflow, no console error); the budget of `tests/shipped.test.mjs`.

### S3 — Calibration 2: Furey's five tabs (wave 2)

- **Scope:** §2.5: the overview and five sub-pages; rows and figures by tab; `SubNav`; the Furey part of the review.
- **Do:** `furey.json` with the six entries (titles from v15's map nodes, learner titles from `NODES_YL`, `hy` headings), heroes per tab (a row the tab holds: e.g. PAG-015 on `matter/generations`), the sections and their figures (P10's ids from PENDING_FIGURES), the layout of the 22 present placements and of the Furey story rows; in `pending.json`, each of the 44 tagged Furey statements with its v15 tags, proposed labelling (04) and evidence from the script that computes it (mode `ran` only when `checks.json` records a passing run), so that accepting one is one move in `review.json` (A39, with D33).
- **Verify:** `node tests/story/furey.test.mjs` (six routes render at both levels and modes; each tab has a lead and its v15 sections in order; every one of the 22 placements is on a tab; SubNav links the five in v15 order; every Furey figure is placed once); coverage and composition green.

### S4 — The landing page and Ask (wave 1)

- **Scope:** §2.7, §2.8.
- **Do:** the route rename (`landing.json`) and the router; the Explore home part "The Atlas, chapter by chapter" from `pageLead()`; the door and the brand link; Contents order; the first-visit rule in `settings.js` (try/catch, the address wins); Ask's two lists (`rankStory` beside `rankRows` in `search.js`).
- **Verify:** `node tests/story/landing.test.mjs` (`#/` renders the Explore home with eight path cards and one card per chapter whose text is that page's lead record; `#/atlas` renders the Atlas page; old `#/explore` links work; Contents order), `node tests/story/ask.test.mjs` (story list ≤ 3 lead rows by matched words, statement list without story rows, both as Statements), `node tests/ui/explore.smoke.test.mjs`.

### S5 — Learner layer, tests, release v2.2.0 (wave 3)

- **Scope:** §1.5 drafts; the shared suites; the release.
- **Do:** drafts for the story rows without a v15 strip (`content/texts_learner_story.json`, the story persona, R1–R13, `merge_learner_texts.mjs`); extend `tests/coverage.test.mjs` (lead, caption, learner and next rows are text records; titles within the connective budget; the landing routes), `tests/shipped.test.mjs` (the overlay read for history words, human texts reported), `tests/ui/smoke.test.mjs` (`#/`, `#/atlas`, `#/matter/generations`, `#/steps/baez`), `tests/explore/pages.test.mjs` (home route), `tests/logbook.test.mjs` (register counts with story rows); record the taken decisions in `DECISIONS.md`; HANDOVER "Add a story row"; release notes; version 2.2.0.
- **Verify:** `npm run content && sh build.sh && npm test` green with the story and physics runners; PENDING_FIGURES empty or explained; `npm run release` → `release/one-rule-v2.2.0.zip`.

**Done when** every full-Atlas page shows its intro where v15 had one, sections in v15 order with names, a lead where v15 introduced the section, its figure and at most N key results with the rest folded; Furey has its five tabs; the chapters have their parts and no "(figure)" section; `#/` is Explore with the chapter cards and `#/atlas` the Atlas; Ask answers with story rows first; `docs/STORY_REVIEW.md` lists every held and proposed block with its default; all suites green.

---

## §5 Decisions

### For the author (after A36)

| # | question | options (recommendation first) |
|---|---|---|
| A37 | When is a v15 paragraph narration? | **(a)** it states nothing of its own: any number or formula it holds is stated by a row of its section, which it names (`restates`), and it keeps those rows' status words — then it is a story row without badge (§1.4); (b) strict: any formula, claim word or number makes it a reading with the badge "our reading" |
| A38 | v15 paragraphs that state something no row states (about 120 on the pages) | **(a)** held in `content/story/pending.json` until you choose in `review.json`: story, reading, statement with a check, same as a row, drop; (b) shown at once as readings in the "More statements" fold |
| A39 | v15's own statements in prose (53 on the pages, 44 of them Furey's: the counting statement, the composites, the room) | **(a)** proposed as rows with v15's tags and the evidence of the script that ran (furey_papers_check, threegen_selfcheck, dictionary_selfcheck), accepted one by one or tab by tab; with D33 their status follows the scripts that ran; (b) kept as readings |
| A40 | Furey's tabs | **(a)** five sub-pages `matter/dictionary`, `matter/papers`, `matter/model`, `matter/generations`, `matter/help` under the overview `matter`, titles from v15 ("The dictionary", "Her papers", "Her 2026 model", "Three generations", "What may help"); (b) tabs inside one page |
| A41 | The landing page | **(a)** `#/` is Explore with "The Atlas, chapter by chapter"; the Zero page at `#/atlas` named "The Atlas"; a first visit opens at learner level; (b) Zero stays at `#/` with a larger door to Explore |
| A42 | The 93 v15 learner lines that are research rows on the three chapters (A19) | **(a)** role `learner`: shown only at learner level where v15's plain body had them, their words as their learner text; (b) A19's option: become the learner texts of their formal rows; (c) leave |
| A43 | The 150 widget-copy rows of the chapters | **(a)** captions under their figure in the section that holds it (the 19 "(figure)" sections go); lines of an undrawn widget (BW2, BW5, BW6, BW7) folded as details until it is drawn; (b) leave |
| A44 | Section titles | **(a)** v15's menu labels (research) and learner menu labels; v15 headings that state a law ("Sign the cube: the bit-rule sign is unique up to gauge") are not titles; (b) v15's headings as they are |
| A45 | Key results per section | **(a)** three at learner level, five at research level, the rest in "More statements (n)"; (b) another number, or per page |
| A46 | What stays out of the round | **(a)** the per-cell proof sketches (69, a drawer task of their own), the role-name layer (16, dropped by 01), script and download notes (70), the v15 Map and For-researchers prose (256, the Logbook keeps tables), the Ask persona strings; (b) migrate some of them too |
| A47 | v15 learner words that belong to existing rows (the page-strip tags of the 36 PAG and 4 LNP rows, the card and section strips) | **(a)** they replace the translator drafts of those rows (status `human`); (b) keep the drafts |
| A48 | The page-strip rows PAG-001…034 | **(a)** "at a glance" under the page's intro, as v15 showed them; (b) where they are |
| A49 | The finding titles of the chapters (Baez J1–J10, Schuller and category F-titles) | **(a)** the `short` research text of the finding's first row where you confirm it is the same statement, else left out; (b) reading rows |

### For the lead, before launch

| # | decision | recommendation |
|---|---|---|
| SL1 | The story round and the physics wave P4–P11 | in parallel on disjoint files (§4 table); S5 after both; one release, v2.2.0 |
| SL2 | Schema amendments | 02 §1: kind `story`, relation `restates`, roles `lead`, `caption`, `learner`, `next`; 02 §7: `detail` = "More statements"; ids 501–999 for narration |
| SL3 | The overlay and its precedence | §3.2; `merge_story.mjs` after the Explore and physics merges |
| SL4 | PENDING_FIGURES | write it at step 0 from PHYSICS_AUDIT §4; S5 empties or explains it |
| SL5 | Numbering | PHYSICS_AUDIT §3 proposes D30–D33, while BUILD_CONTRACTS took D30–D32 for other decisions: record the audit's under the next free numbers when taken |
| SL6 | The content size | about 900 new text records (about 25 % more `texts.json`, fetched, not bundled); the components add a few kB to `app.js` |
| SL7 | Who reviews `docs/STORY_REVIEW.md` before v2.2.0 | the author; until then the held and proposed blocks stay out of the pages and the release notes say how many |
| SL8 | Widget copy: the role `caption` (under its figure) in place of `detail` (in the fold) | take it; `detail` stays for the copy of undrawn widgets and for tally lines |
