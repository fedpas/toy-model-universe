<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Explore content: Octavo's words and the rows behind them

Explore ports the ten finished leaves of Octavo V₀ (clock, moves, zero, light, fall, roots, seats, magnets, springs, charge) and adds three lens explorers. Every sentence on an Explore page is a text record of a row (`docs/EXPLORE_PLAN.md` §1, D26). This file is where the author checks that: for each leaf, each Octavo line (`COPY` of `<slug>.logic.js`: head, notes, try line, panels) is mapped to the row that now carries it, or marked **dropped: no row**; the tables under each page give the words that row shows at learner level. A note may say less than Octavo said, never more.

## 1. Files and pipeline

| file | what it holds |
|---|---|
| `content/explore/registry.json` | the path of 8 (with Octavo's needs as path numbers), the shelf of the drawn leaves (seats, magnets, charge, springs, each with the path leaf it hangs under), the three explorers |
| `content/explore/pages.json` | the home (`explore`, kind `explore-home`), ten leaves (kind `leaf`), three explorers (kind `explorer`) |
| `content/explore/placements.json` | 88 placements `{ row, page, section, order, role }`, sections `notes` and `two-ways`, role `result`, order 1001… (notes) and 1011… (two ways) |
| `content/explore/rows.json`, `content/explore/texts.json` | new rows and their research texts: **none** in this round (§6) |
| `content/texts_learner_explore.json` | 61 learner drafts: 22 in the full register, 39 in the short register |
| `tools/merge_explore.mjs` | merges the overlay into `rows.json`, `texts.json`, `pages.json`, `figures.json` |

Order: `node tools/check_learner_texts.mjs && node tools/merge_learner_texts.mjs && node tools/merge_explore.mjs && node tools/build_content.mjs`. The two merges may run in either order and give the same tables; `merge_explore.mjs` run twice writes the same bytes. `tools/migrate/run_all.sh` calls it right after `figures_from_v15.mjs`, so a re-migration keeps Explore (D23).

What the merge owns, and so replaces on every run: the pages `explore` and `explore/…`; every `shownOn` entry on those pages; the figures `leaf-*` and `lens-*` (seeds of X6 and X3); texts whose source starts with `explore:`; the rows it added before (listed in `MIGRATION_COUNTS.json`, key `explore`), which it removes with their texts when the overlay no longer holds them. It never replaces a `human` text and never changes a row of the migration except by adding Explore placements. Before writing it checks the overlay and stops on an error: placements of order ≥ 1000 on a declared section, no hero row placed in a section, hero and rests rows that exist, a rests row whose home (lowest `shownOn.order`) stays in the full Atlas, titles that are names (no digit, at most 40 characters, not a sentence), connectives of at most 240 characters, needs that are pages, registry and pages that agree, seeds with a caption row and known lenses. `node tools/merge_explore.mjs --check` prints the same report and writes nothing.

## 2. How a leaf page is filled

- **Hero** = the figure's caption row (the seeds of X6 use the same rows). The hero row is not placed in a section: `buildPageModel` renders it as the hero, and a placement would attach the other figures captioned by that row (`clock-wheel` for LAB-017) to the section.
- **Notes** = three rows (four on magnets, whose LNS-135 is shown in physics mode only), in Octavo's note order. At learner level a note shows its short text when it has one, else its full one.
- **Two ways** = the rows of Octavo's two back panels (the Mathematician's and the Physicist's), physics order by placement; open rows go to the open fold.
- **Try line** = `connective.notes`: an instruction naming the figure's learner controls as the seeds of `content/explore/figures.leaf.json` declare them, with no claim; each holds no 40 characters of a text record.
- **Connect to the full Atlas** = `explore.rests`, a row whose home is a step page: LAB-017 (`clock`), LAB-015 (`clock`), LNC-101 (`steps/category`), PAG-011 (`light`), LAB-005 (`steps/gauge`), SHP-006 (`shapes`), LNS-129 and LNS-134 (`steps/schuller`), EQN-018 (`steps/spring`), PAG-009 (`light`); the explorers EQN-006 (`light`), MIR-001 (`steps/mirrors`), EQN-006.
- Lenses (the Mathematician's way in): clock comb, moves geo, zero alg, light geo, fall geo, roots comb, seats alg, magnets geo, springs comb, charge geo; simplex and demicube explorers geo, cube explorer cat (its rows LNC-056 and SHP-007 are the cube as a category).

In the tables below, "proved here" is the status proved-by-atlas (no badge on the page); every other status is the badge the page shows.

## 3. Octavo's words, leaf by leaf

### The clock (path 1, lens comb)

| Octavo | row | in V2 |
|---|---|---|
| head "Count the switches. Read the hour." | LAB-017 (hero) | an instruction, not a claim: the hero row is the clock sum of LAB-017 |
| note 1 "Each switch squares to +1 or −1. Plus switches turn the hand forward, minus switches back." | LNC-101 | the row's words: plus forward, minus back, zero not at all, and the product of corners holding a zero switch |
| note 2 "Where the hand stops names your table: ordinary (ℝ), turning (ℂ) or spinning (ℍ) numbers." | PAG-004 | the kind of every cell from the classical mod 8 table; "where the hand stops" is cut (the row does not name the hand) |
| note 3 "Eight more switches bring the hand home. The table only gets bigger." | ATL-023 | period 8, every number replaced by a 16 by 16 real grid (GEN-009 states the same with an open clause on the Higgs) |
| panel (math) "Every corner of the cube casts a vote." | RSN-029 | the clock as the phase of the sum over all pieces |
| panel (phys) "You already know some of these boxes." | PAG-006 | the textbook identifications of some cells |
| the swap button | INP-017 | the clock's sign convention (input) |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | LAB-017 | proved here | (short) With no zero switch, the clock sum is one plus the imaginary unit, once for each plus switch, times one minus it, once for each minus switch; one or two zero switches each add a factor 2. |
| notes 1001 | LNC-101 | proved here | (short) A plus switch turns the clock hand forward, a minus switch back, a zero switch not at all. Multiply one more corner holding a zero switch than there are zero switches, and you get nothing. |
| notes 1002 | PAG-004 | proved here | (short) The kind of every cell, grids of real, complex or quaternion numbers, single or doubled, comes from the classical mod 8 table, checked against its recursion. |
| notes 1003 | ATL-023 | proved here | (short) Period 8: add 8 switches and the kind of the cell comes back, with every number replaced by a 16 by 16 grid of real numbers. |
| two-ways 1011 | PAG-006 | standard | (full) |
| two-ways 1012 | INP-017 | needs an input: sign convention | (full) |
| two-ways 1013 | RSN-029 | proved here | (full) |

### Three moves (path 2, lens geo)

| Octavo | row | in V2 |
|---|---|---|
| head "One sign decides: turn, slide or boost." | LAB-015 (hero) | the sign of a square sorts rotation, boost, translation for a vector or a simple plane, with the row's zero cases and its limit from 4 directions |
| note 1 "A spring that pulls back makes the ball swing to and fro: a turn." | EQN-018 | the three kinds of imaginary unit as oscillator, inverted oscillator, free motion |
| note 2 "No spring: it drifts on, a slide. A spring that pushes away: it runs off, a boost." | EQN-018 | the same row; "drifts", "runs off" are the figure's to show |
| note 3 "The square of the move sorts them: below zero a turn, zero a slide, above zero a boost." | RSN-010 | with 2 directions the sign of the square sorts ellipses, parallel lines, hyperbolas |
| (the reading of the three signs) | LAB-003 | "is ours" in its learner text; no badge, its run check makes it proved (A26) |
| panel (phys) "A planet obeys the same rule." | LNB-023c | ellipse, parabola, hyperbola by the sign of the energy |
| panel (math) "Every plane element squares to a number." | LAB-004 | translation inside a cell with no zero switch is a null rotation |
| try "drag the slider through zero. Watch the curve open up, then split." | — | rewritten as an instruction for the `k` chips; the prediction is dropped |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | LAB-015 | proved here | (short) For a vector or a simple plane the sign of the square sorts the move: −1 rotation, +1 boost, 0 translation, null rotation or a plane of null directions; from 4 directions on, three are not enough. |
| notes 1001 | EQN-018 | proved here | (short) A spring network on the cube, 8 masses and 12 springs in 3D: the three kinds of imaginary unit appear as an oscillator, an inverted oscillator and free motion, and all 60 exact claims hold. |
| notes 1002 | RSN-010 | proved here | (short) With 2 directions, the sign of a piece’s square sorts ellipses, parallel lines and hyperbolas: rotation, translation, boost. |
| notes 1003 | LAB-003 | proved here | (full) Reading the signs −1, +1 and 0 of a square as rotation, boost and translation is ours. |
| two-ways 1011 | LNB-023c | proved here | (full) |
| two-ways 1012 | LAB-004 | proved here | (full) |

### Zero (path 5, lens alg)

| Octavo | row | in V2 |
|---|---|---|
| head "A switch that squares to nothing." | LNC-101 (hero) | the zero switch leaves the hand, and the product of one more zero corner than zero switches is nothing |
| note 1 "A zero switch times itself gives nothing. Yet the switch is not nothing: times another switch it makes a new corner." | LNC-013 | its human learner text ("… gives nothing. Nothing can undo it …"); "makes a new corner" is cut |
| note 2 "So a product that uses a zero switch twice is nothing, whatever else it holds." | LNC-101 (hero) | in the row's form (one more corner than there are zero switches) |
| note 3 "The solid corners multiply among themselves and never give nothing: a complete table of their own." | LNC-014 | in the row's form: the zero corners span the radical, and what is left is the cell without zero switches |
| (layers of zero) | LNC-102 | the lit corners: one face, or every corner outside one face |
| panel (math) "Layers of zero." | LNC-019 | no state sees a corner with a zero switch (the one sentence on probabilities the leaf brief allows) |
| panel (phys) "Zero is how a body slides." | RIG-007 | the slide of plane-based geometry |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | LNC-101 | proved here | (short) A plus switch turns the clock hand forward, a minus switch back, a zero switch not at all. Multiply one more corner holding a zero switch than there are zero switches, and you get nothing. |
| notes 1001 | LNC-013 | proved here | (full) A zero switch is a switch that, multiplied by itself, gives nothing. Nothing can undo it: that is why it is the one switch with no way back. |
| notes 1002 | LNC-014 | proved here | (short) The corners that hold a zero switch span the radical; take it away and what is left is the cell with the same plus and minus switches and no zero switch. |
| notes 1003 | LNC-102 | proved here | (full) With one zero switch, the lit corners fill one face of the cube. With two or more, they are all the corners outside one face: the face where every zero switch is off. |
| two-ways 1011 | RIG-007 | proved here | (full) |
| two-ways 1012 | LNC-019 | proved here | (full) |

### Light (path 6, lens geo)

| Octavo | row | in V2 |
|---|---|---|
| head "One switch against the rest: waves that travel like light." | LNS-102 (hero) | exactly one plus or exactly one minus switch, up to nine switches |
| note 1 "… With exactly one plus switch, or exactly one minus switch, call that one time; the others are space." | INP-011 | calling it time is a convention: the badge "needs an input: sign convention" |
| note 2 "Then every ripple, heading any way, travels at one speed. The crests stay on one growing ring …" | PAG-011 | hyperbolic exactly when one sign stands against the rest; "one speed" and the ring are **dropped: no row** (the figure may draw the ripple) |
| note 3 "Stacked over time, the rings make a cone: the arrows whose square is zero …" | NUL-010 | null surfaces carry wavefronts; the determinant vanishes on the null cone for 3 to 5 directions, at the checked points |
| panel (math) "Hyperbolic directions fill the inside of the cone." | LNS-012, LNS-002 | the hyperbolic direction and the search for 2 to 7 switches |
| (well-posedness) | PAG-034 | open: in the open fold |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | LNS-102 | proved here | (short) Waves that travel like light need exactly one plus switch or exactly one minus switch, checked for every box with up to nine switches. |
| notes 1001 | INP-011 | needs an input: sign convention | (short) Which sign is called time, and a cell against its mirror, are conventions; only one sign against all the others gives a hyperbolic wave operator. |
| notes 1002 | PAG-011 | proved here | (short) The wave operator is elliptic, hyperbolic or ultrahyperbolic by the signs; with no zero switch it is hyperbolic exactly when one sign stands alone against the rest. |
| notes 1003 | NUL-010 | proved here | (short) Null surfaces are those that can carry a wavefront; to first order the gauge-fixed Einstein form has a determinant zero exactly on the null cone, for 3, 4 and 5 directions (checked at points). |
| two-ways 1011 | LNS-012 | proved here | (full) |
| two-ways 1012 | LNS-002 | proved here | (full) |
| two-ways 1013 | PAG-034 | open | (full) |

### Fall (path 7, lens geo)

| Octavo | row | in V2 |
|---|---|---|
| head "At the horizon, falling rain reaches the speed of light." | LAB-005 (hero) | the radial direction plus a factor times time squares to the factor squared minus one; "reaches the speed of light" is **dropped: no row** (Octavo's wording) |
| note 1 "Rain let go far away falls faster and faster. The two edges of each cone are where light from that spot can go." | RSN-017 | the sign of the radial gradient: negative outside, zero on the horizon, positive inside; the faster fall and the cone edges are the figure's |
| note 2 "At the horizon the rain reaches light's speed. A flash sent outward from there stands still: it never gets out." | RSN-015 | the paper's "photon that stands still"; "never gets out" is **dropped: no row** |
| note 3 "Inside, both edges of every cone lean in. Even a flash sent outward is swept in; nothing there can climb out." | RSN-017 | only "positive inside"; "swept in", "nothing can climb out" are **dropped: no row** |
| (the horizon null) | LAB-007 | one element in two algebras |
| panel (phys) "Far away it is Newton." | NUL-001 | the surface gravity on five horizons (RSN-017 carries the weak-field limit in its full text) |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | LAB-005 | proved here | (short) The radial direction plus a factor times the time direction squares to the factor squared minus one. Checked: orbits against a textbook formula, the geodesic equation exactly at 30 states. |
| notes 1001 | RSN-017 | proved here | (short) The radial gradient squares to a factor squared minus one, the factor being the square root of twice the mass over the distance: negative outside, zero on the horizon, positive inside. |
| notes 1002 | RSN-015 | proved here | (short) The generator of a null surface is a null geodesic lying in it, the paper’s “photon that stands still”: a surface of constant radius is null exactly when the time factor is zero. |
| notes 1003 | LAB-007 | proved here | (short) At the horizon the radial gradient is one element in two algebras: a paired null direction of spacetime, and the zero switch of the cell along the surface. |
| two-ways 1011 | NUL-001 | new | (full) |

### Roots (path 8, lens comb)

| Octavo | row | in V2 |
|---|---|---|
| head "Eight switches draw 240 arrows, the roots of E8." | SHP-006 (hero) | 112 edges and 128 even facets make the 240 roots; the series stops at E8 |
| note 1 "Each arrow is a list of eight numbers, one for each switch. Tap a mark to read its list." | — | **dropped: no row**; the figure's readout prints the list, the try line asks for the tap |
| note 2 "112 arrows set two switches to +1 or −1 and the other six to 0: the dots." | SHP-006 (hero) | "the 112 edges" |
| note 3 "128 set all eight to +½ or −½, with an even number of minus signs: half of the cube's corners, the rings." | GOS-001, MIR-003 | the 8-demicube is the 128-corner half; its corners are the even corners of the 8-cube; the mirrors permute the 240 |
| panel (math) "Why 112 + 128, and why it stops." | LNC-042 | determinant 9 − n by exact elimination; its short text replaces, on the leaf, a human text that points at a v15 picture |
| panel (phys) "Eight-dimensional billiard balls." | MAP-022 | the E8 roots permuted by their mirrors |
| (an input) | INP-016 | the Cartan matrices of E6, E7, E8 are imported |
| keep-out "the same 8 as the clock" | — | LNC-047, PAG-020, MAP-014, GOS-005 are not placed |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | SHP-006 | proved here | (short) With 8 directions, the 112 edges and the 128 even facets make exactly the 240 roots of E8, and the finite series stops at E8. |
| notes 1001 | GOS-001 | proved here | (short) The half-cube in 8 dimensions is the 128-corner half of E8, and 8 is the only number of directions where the corners of the half-cube are roots. |
| notes 1002 | MIR-003 | proved here | (full) From Gosset to mirrors: the half-cube corners of E8 are the even corners of the cube in 8 dimensions, and all 240 roots are shuffled among themselves by their mirrors. |
| notes 1003 | LNC-042 | proved here | (short) The matrix of the E-series has determinant 9 minus its size, by exact elimination for sizes 3 to 20: every direction plus up to 8, one zero direction at 9, one minus direction from 10. |
| two-ways 1011 | MAP-022 | proved here | (full) |
| two-ways 1012 | INP-016 | needs an input: imported data | (full) |

### Seats (shelf, under leaf 5, lens alg)

| Octavo | row | in V2 |
|---|---|---|
| head "Three seats make eight patterns." | LNS-129 (hero) | 1, 3, 3, 1 by number of particles; a particle into a full seat gives nothing |
| note 1 "Three seats, each empty or full, make 8 patterns: 1 with no particle, 3 with one, 3 with two, 1 with all three." | LNS-129 (hero) | the hero carries it |
| note 2 "A seat holds one particle at most. Add one more to a full seat and the result is nothing …" | LNS-130 | the patterns as labels; adding a particle twice gives zero (Pauli exclusion) |
| note 3 "Three names, one rule: a full seat's bit is already 1, its number already counted, its prime already a factor." | — | **dropped: no row** (A28); PAG-003 "prime labels are notation only" (our reading) sits beside the names |
| (the cell of the seats) | LNS-005 | as many plus as minus switches: all linear maps on the patterns |
| panel (math) "Add twice, get nothing." | LNC-060 | super-dimension 0; the bosonic ladder has no finite solution (its reading part is ours) |
| panel (phys) "Electrons share a house." | LNS-019c | qubits by the same rule |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | LNS-129 | proved here | (short) Three seats make eight patterns: 1, 3, 3 and 1 by number of particles. A particle put into a full seat gives nothing. |
| notes 1001 | LNS-130 | proved here | (short) With any number of seats, each pattern of particles is a label, the particle number counts its bits that are on, and adding the same particle twice gives zero (Pauli exclusion). |
| notes 1002 | LNS-005 | proved here | (short) A cell with as many plus as minus switches is all the linear maps on the patterns of that many seats, built from adding and removing particles. |
| notes 1003 | PAG-003 | our reading | (full) Labelling the pieces by prime numbers is notation only: the primes are names, nothing more. |
| two-ways 1011 | LNS-019c | proved here | (full) |
| two-ways 1012 | LNC-060 | proved here | (full) |

### Magnets (shelf, under leaf 4, lens geo)

| Octavo | row | in V2 |
|---|---|---|
| head "A beam through three magnets." | LNS-134 (hero) | same way all, sideways half, back after a sideways magnet half again |
| note 1 "A magnet lets through the part of the beam that points its way. Same way: all of it." | LNS-135 | 100% (physics mode only: the row is `visibleTo` phys) |
| note 2 "Sideways: half of it. The opposite way: none. What gets through then points the magnet's way." | LNS-135 | 50%, 0%; "what gets through then points the magnet's way" is **dropped: no row** |
| note 3 "So after a sideways magnet, turning back to up lets only half through again." | LNS-021c | up, up 100%; up, sideways 50%; up again 50%, because the two switches anticommute |
| panel (math) "States live in a ball." | LNS-037 | mixed states and the passing rule in Cl(3,0); other signatures open |
| panel (phys) "The order of two magnets matters." | LNS-021c, LNS-021 | the anticommuting switches; the Casimir values 0, 2, 2, 0 |
| keep-out "probability beyond Cl(3,0)" | SPN-004 | open: in the open fold |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | LNS-134 | proved here | (short) Magnets pointing the same way pass all of the beam, a sideways one half, and turning back after a sideways magnet passes half again. |
| notes 1001 | LNS-135 | proved here | (short) In the cell Cl(3,0) a beam pointing the magnet’s way passes 100%, a sideways one 50%, an opposite one 0%; up, sideways, up passes 100%, 50% and 50% of what enters each. |
| notes 1002 | LNS-021c | proved here | (short) In the cell Cl(3,0), up then up passes 100%, up then sideways 50%, and a further up again 50%, because the up-down and the left-right switches anticommute. |
| notes 1003 | LNS-037 | proved here | (short) In the cell Cl(3,0) a mixed state is one plus a vector, over 2, and the chance of passing a magnet is one plus the dot product of the two vectors, over 2. Other signatures are open. |
| notes 1004 | LNS-021 | proved here | (short) In the cell Cl(3,0) the four grades carry the Casimir values 0, 2, 2 and 0: a singlet and a triplet, two spins one half making spin zero and spin one. |
| two-ways 1011 | SPN-004 | open | (full) |

### Springs (shelf, under leaf 2, lens comb)

| Octavo | row | in V2 |
|---|---|---|
| head "Every wobble of a cube of springs is a label." | EQN-018 (hero) | the spring network, its three kinds of motion, 60 exact claims; "every wobble is a label" is carried by MAP-026 below |
| note 1 "Each label but 000 is a way to wobble: corners marked + go up while corners marked − go down, then back." | SPR-003 | "Ours: reading the labels as the normal ways the cube vibrates" (no badge, A26) |
| note 2 "More 1s, faster: each 1 stretches four more springs, and the speed is √(2 × number of 1s)." | MAP-026 | speed squared = twice the number of ones; "each 1 stretches four more springs" is **dropped: no row** |
| note 3 "Pluck one corner and all eight labels join in. Energy flows between springs and motion; the total never changes." | SPR-001 | energy conservation among the 60 claims; "all eight labels join in" is **dropped: no row** |
| panels | SPR-002, SPR-004 | the standard inputs (our reading) and the scope: one number per corner |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | EQN-018 | proved here | (short) A spring network on the cube, 8 masses and 12 springs in 3D: the three kinds of imaginary unit appear as an oscillator, an inverted oscillator and free motion, and all 60 exact claims hold. |
| notes 1001 | SPR-003 | proved here | (short) Ours: reading the labels as the normal ways the cube of springs vibrates. |
| notes 1002 | MAP-026 | proved here | (short) Each label is a way the cube of springs vibrates, its speed squared twice its number of ones; 60 exact claims, with one input, the cube’s translations, for the Dirac reading. |
| notes 1003 | SPR-001 | meta | (short) Checked: all 60 claims, among them the normal ways of vibrating and the conservation of energy. |
| two-ways 1011 | SPR-002 | our reading | (full) |
| two-ways 1012 | SPR-004 | proved here | (full) |

### Charge (shelf, under leaf 6, lens geo)

| Octavo | row | in V2 |
|---|---|---|
| head "A charge in a field circles, slides off or runs away." | PAG-009 (hero) | "the force on a charge, six situations" (its full learner text is one line; no short text) |
| note 1 "B alone pushes sideways to the motion: the speed never changes, and the charge goes round a circle. A turn." | RSN-026 | the circle agrees with its closed form; "the speed never changes" and "a turn" are **dropped: no row** |
| note 2 "E alone pushes along its lines: the charge speeds up for ever, yet never reaches the speed of light. A boost." | RSN-026 | the hyperbola agrees with its closed form; "never reaches the speed of light" is **dropped: no row** (`maxwell.json` stores the check `speed_limit`, no row prints it) |
| note 3 "Both at once: the sign of E² − B² decides. Below zero it circles, at zero it slides off, above zero it runs away." | — | **dropped: no row** (`maxwell.json` stores the invariants E² − B² and E·B; no row states the sorting) |
| (inputs) | INP-007, INP-008 | the force law is postulated; charge, mass and start are chosen by hand |
| panels | PAG-008, ATL-017 | every term found by search against the textbook; the field as a piece of two switches with 6 parts |

| place | row | status | learner words shown |
|---|---|---|---|
| hero | PAG-009 | proved here | (full) Checked: the force on a charge, in six situations. |
| notes 1001 | RSN-026 | proved here | (short) The circle, the hyperbola, the drift across crossed fields and a plane wave agree with closed forms; nothing predicts anything. |
| notes 1002 | INP-007 | needs an input: postulated equation | (full) The Lorentz force, the part with one switch of the field times the motion, is a postulated force law, not derived from the field equation. |
| notes 1003 | INP-008 | needs an input: imported data | (full) The charge, the mass, the start position and the start speed are chosen by hand in each of the six situations. |
| two-ways 1011 | PAG-008 | proved here | (full) |
| two-ways 1012 | ATL-017 | proved here | (full) |

### The three explorers

The rows are those of `docs/EXPLORE_PLAN.md` §2.6, with three choices: ATL-008 instead of LNS-020 as the demicube note (it names the spin group of special relativity; LNS-020 says "of his chapter 15"); RSN-025 (not yet proved here) is placed on the simplex explorer, since A25 is not taken; PAG-003 is not placed on the cube explorer (a row cannot be limited to the primes lens). Nothing of the "does not state" lists of plan §1 is placed: no row says that a shape *is* the picture, the A22 reading is not a row, and the explorers' notes say "notations" (MAP-004).

**Simplex view of Maxwell (`explore/simplex-maxwell`, lens geo)**

| place | row | status | learner words shown |
|---|---|---|---|
| hero | MAP-004 | proved here | (short) Maxwell in 1 to 4 space and 1 to 4 time dimensions: the simplex, the cube and the whole numbers are three notations for the same labels; only the algebra view sees the signs. |
| notes 1001 | EQN-006 | proved here | (full) Maxwell’s equation, in Calibration 1: drawn from the switch rule and checked by a script for cells with 2 to 7 directions. In 4D the field has 6 parts, and they enter the equations at 24 places. |
| notes 1002 | MAP-003 | proved here | (short) Checked on every split with at most 4 space and 4 time dimensions, at most 7 in all: the field equation holds, and its parts enter at 2, 9, 24, 50, 90 and 147 places. |
| notes 1003 | ATL-017 | proved here | (short) The electromagnetic field is a piece made of two switches, with 6 parts, in a 4D spacetime algebra; the Maxwell equations combine into one, checked exactly term by term. |
| two-ways 1011 | EQN-001 | proved here | (full) |
| two-ways 1012 | PAG-011 | proved here | (full) |
| two-ways 1013 | MAP-013 | proved here | (full) |
| two-ways 1014 | INP-004 | needs an input: grade of a field | (full) |
| two-ways 1015 | INP-011 | needs an input: sign convention | (full) |
| two-ways 1016 | PAG-023 | our reading | (full) |
| two-ways 1017 | ATL-017b | our reading | (full) |
| two-ways 1018 | RSN-025 | not yet proved here | (full) |

**Demicube view of moves (`explore/demicube-moves`, lens geo)**

| place | row | status | learner words shown |
|---|---|---|---|
| hero | MIR-001 | proved here | (short) The corners of the cube are patterns of signs, in layers by number of mirrors; the even half is the half-cube. The mirror groups of both are textbook. |
| notes 1001 | EQN-002 | proved here | (short) With 4 directions the half-cube is the 16-cell: the plain number and the all-switch piece at two poles, the six planes around the equator. |
| notes 1002 | ATL-008 | proved here | (short) The even half of the spacetime cell Cl(1,3) is the cell Cl(1,2), the 2 by 2 complex grids; its even products of norm one form the spin group of special relativity. |
| notes 1003 | LAB-015 | proved here | (short) For a vector or a simple plane the sign of the square sorts the move: −1 rotation, +1 boost, 0 translation, null rotation or a plane of null directions; from 4 directions on, three are not enough. |
| two-ways 1011 | MIR-002 | proved here | (full) |
| two-ways 1012 | EQN-014 | proved here | (full) |
| two-ways 1013 | RSN-007 | proved here | (full) |
| two-ways 1014 | MAP-013 | proved here | (full) |
| two-ways 1015 | MAP-017 | proved here | (full) |
| two-ways 1016 | GOS-001 | proved here | (full) |
| two-ways 1017 | INP-018 | needs an input: sign convention | (full) |
| two-ways 1018 | INP-020 | needs an input: time direction | (full) |
| two-ways 1019 | MIR-005 | our reading | (full) |
| two-ways 1020 | PAG-019 | our reading | (full) |
| two-ways 1021 | MAP-016 | not yet proved here | (full) |

**Cube view of Maxwell (`explore/cube-maxwell`, lens cat)**

| place | row | status | learner words shown |
|---|---|---|---|
| hero | MAP-003 | proved here | (short) Checked on every split with at most 4 space and 4 time dimensions, at most 7 in all: the field equation holds, and its parts enter at 2, 9, 24, 50, 90 and 147 places. |
| notes 1001 | MAP-004 | proved here | (short) Maxwell in 1 to 4 space and 1 to 4 time dimensions: the simplex, the cube and the whole numbers are three notations for the same labels; only the algebra view sees the signs. |
| notes 1002 | MAP-013 | proved here | (short) The even pieces sit on half the corners; in Maxwell’s equation the field is even, and the equation takes even pieces to odd ones. |
| notes 1003 | LNC-056 | proved here | (short) Ordered by inclusion, the labels form the Boolean lattice; giving each edge the sign of the switch rule makes every square anticommute, and the boundary it gives squares to zero and is exact. |
| two-ways 1011 | CPL-001 | proved here | (full) |
| two-ways 1012 | EQN-001 | proved here | (full) |
| two-ways 1013 | SHP-007 | proved here | (full) |
| two-ways 1014 | SHP-001 | proved here | (full) |
| two-ways 1015 | PAG-011 | proved here | (full) |
| two-ways 1016 | INP-004 | needs an input: grade of a field | (full) |
| two-ways 1017 | INP-011 | needs an input: sign convention | (full) |
| two-ways 1018 | PAG-023 | our reading | (full) |
| two-ways 1019 | CPL-010 | our reading | (full) |

## 4. Learner drafts written

All in `content/texts_learner_explore.json`, source `translator:learner@2026-10-10`, status `draft`, passing the 13 rules of `tools/check_learner_texts.mjs` together with the other learner files (854 records).

- **Full register (22)**, rows that Explore shows and that had no learner text: RSN-029, INP-017, RSN-010, RSN-017, RSN-015, MAP-026, RSN-026, INP-007, INP-008, MAP-004, MAP-003, MAP-013, INP-004, INP-011, RSN-025, RSN-007, MAP-017, INP-018, INP-020, MAP-016, MAP-022, INP-016. They are the first learner texts of rows of group INP: at learner level the input badges of Explore now have words.
- **Short register (39)**, heroes and notes: LAB-017, LNC-101, PAG-004, ATL-023, LAB-015, EQN-018, RSN-010, LNC-014, LNS-102, PAG-011, INP-011, NUL-010, LAB-005, RSN-017, RSN-015, LAB-007, SHP-006, GOS-001, LNC-042, LNS-129, LNS-130, LNS-005, LNS-134, LNS-135, LNS-021c, LNS-037, LNS-021, SPR-003, MAP-026, SPR-001, RSN-026, MAP-004, MAP-003, ATL-017, MIR-001, EQN-002, ATL-008, MAP-013, LNC-056. A short text keeps every status and scope word of its row (rule R8) and every scope it states (3 to 5 directions, up to nine switches, Cl(3,0) only); where a scope would not fit, the clause is left out rather than widened.
- No research text is written for an existing row; no human text is changed (LNC-013, LNC-019 and LNC-042 keep their human full texts; LNC-042 gains a short text only).

**Side effect on the full Atlas** (D21, the hero prefers a short text at learner level): the learner hero of `clock` (LAB-017), `steps/gauge` (LAB-005, whose full learner text runs to about 2,300 characters), `steps/mirrors` (MIR-001), `shapes` (GOS-001) and `steps/spring` (SPR-001) is now the short text.

## 5. Not mapped

Dropped because no row states them (each may be drawn by the figure as a computed readout, never as a sentence): the roots note "each arrow is a list of eight numbers"; light's "one speed" and "growing ring"; fall's "the rain reaches the speed of light", "never gets out", "swept in", "nothing can climb out"; magnets' "what gets through then points the magnet's way"; springs' "each 1 stretches four more springs" and "all eight labels join in"; charge's "the speed never changes", "never reaches the speed of light" and the sorting by the sign of E² − B²; seats' "three names, one rule" (A28); zero's "times another switch it makes a new corner"; clock's "where the hand stops". Octavo's panel headlines and the remaining try-line predictions ("see the beam stay at half", "the loops … break open when E reaches B") are not printed.

## 6. New rows: none merged; three drafts for the author

No Octavo note needed a new row to give each page three notes. The candidates of plan §4 are written here as drafts, not merged, for two reasons: they are the author's decisions (A22, A24, A28), and a row with `since: "v2.1"` now carries `new` (D22), which `tests/logbook.test.mjs` does not expect yet: its check "status.json new = rows since v16" counts `since === 'v16'` only and would fail. Merging any of them needs that line to count `since` in {v16, v2.1} first.

| id | kind / ptype | statement (research draft) | evidence | status it would compute |
|---|---|---|---|---|
| MIR-007 (A24) | computation / identity | Two mirrors make a boost: in Cl(1,1) the mirrors with normals (1/4, −5/4) and (−2, 4) compose to the matrix ((5/4, 3/4), (3/4, 5/4)), as two mirrors with normals (2, 0) and (8/5, −4/5) compose to the rotation ((3/5, −4/5), (4/5, 3/5)) in Cl(0,2). | `mirrors_selfcheck` (ran; `mirrors.json` examples `boost_5_4_3_4`, `rotation_3_4_5`) | proved-by-atlas, badge new |
| LAB-026 (A28) | computation / identity | Name a switch by a prime and a label by the product of the primes of its switches: the name of the product of two labels is their product divided by the square of their greatest common divisor, checked for all 65,536 pairs of the 256 labels of 8 switches. | `dictionary_selfcheck` (ran; `dictionary.json` `ladder[8].prime_names`: 256 names, 65,536 pairs) | proved-by-atlas, badge new |
| MIR-008 (A22) | reading / reading | The even labels of n switches drawn as the corners of the n-demicube, with the planes as the corners next to the identity, as a picture of the moves of spacetime, is our reading. | none | ours, badge "our reading" |

A row of this kind goes into `content/explore/rows.json` (group, notions, kind, stage, ptype labelled as in `docs/04_LABELLING.md`, `since: "v2.1"`, no legacy flags) with its research text in `content/explore/texts.json` (status `draft`, source `explore:X4`); its placement in `placements.json`; its status is then computed by the amendment of §7.

## 7. The status of rows without v15 flags (D22)

`tools/build_content.mjs` computes the status of a row without legacy flags by 02 §4: meta; candidate; open (question, conjecture, pointer, ptype open; a dead end is not open); proved-by-atlas when a `ran` check has a recorded run that passed with no failure; cited when its ran checks have no passing run or its evidence is read only; ours for kind or ptype reading; input for group INP; standard for an imported notion with a read `standardRef`; else ours. The badge `new` covers `since` v16 and v2.1. The four existing rows without flags (EQN-005, MAP-029, MAP-030, RSN-009) are meta and stay meta; `content/derived/status.json` is byte-for-byte unchanged for the 1,013 rows. Tried on a scratch copy with eight synthetic rows: a passing run gives proved-by-atlas, a read check or a check with no recorded run gives cited, a reading gives ours, a question gives open, an INP row gives input, an imported notion with a read reference gives standard, and a row with nothing gives ours.

## 8. Points for the author

- A22, A24, A28: accept a draft of §6 (and the logbook test line), or leave the notes dropped.
- A26: LAB-003 and SPR-003 are notes; their learner texts say "ours" while the page shows no badge.
- A31: the home's title is "Explore"; "Octavo" is a one-field change of `content/explore/pages.json`.
- Magnets hangs under leaf 4, half-turns, which is not drawn (A30): its "back to the leaf it hangs under" has no page to go to.
- The full-Atlas learner heroes of §4 become short texts; a short text the author dislikes can be deleted from `content/texts_learner_explore.json`, and the hero falls back to the full text.
