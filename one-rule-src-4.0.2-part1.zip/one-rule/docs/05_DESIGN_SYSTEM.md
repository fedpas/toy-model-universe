# 05 — Design system

One system for the whole app, written as CSS custom properties in `src/styles/tokens.css`, used by every component; no component carries a literal colour or font. The look is Octavo's (R7-5): two looks, **Paper** (light) and **Night** (dark), both designed, not inverted; ink on paper for every action; one highlight, `--hi`, for what is pressed, current or chosen; the three move colours for the three moves and nothing else; the clock's eight hues for the clock and nothing else; big playable pictures in cards, few words, a serif for display and a sans for reading. **One colour keeps one meaning.**

## 1. Tokens

```css
:root {                                   /* Paper */
  --bg: #F6F3EA; --panel: #FFFEFA; --fg: #1D2127; --fg-2: #424954; --muted: #5A626E; --line: #D9D4C7; --line-2: #EAE6DC;
  --hi: #F7E08A;
  --accent: var(--fg); --accent-ink: var(--bg); --accent-soft: var(--hi);
  --turn: #D55E00; --slide: #009E73; --boost: #0072B2;
  --c0: #2a78d6; --c1: #eb6834; --c2: #1baf7a; --c3: #eda100; --c4: #e87ba4; --c5: #008300; --c6: #6250d6; --c7: #e34948;
  --g-e: #1c5cab; --g-s: #5598e7; --g-a: #86b6ef; --g-gap: #E4E0D4;
  --font-display: "Newsreader", Georgia, "Times New Roman", serif;
  --font-body: "Instrument Sans", "Helvetica Neue", Arial, sans-serif;
  --font-math: "Noto Sans Math", "STIX Two Math", "Cambria Math", serif;
  --font-mono: "JetBrains Mono", ui-monospace, Menlo, monospace;
  --fs-0: 13px; --fs-1: 14.5px; --fs-2: 16px; --fs-3: 18px; --fs-4: 22px; --fs-5: 28px; --fs-6: 40px;
  --lh: 1.55; --measure: 68ch; --gutter: 16px; --radius: 8px;
  color-scheme: light;
}
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) {   /* Night */
  --bg: #0E141C; --panel: #151D28; --fg: #ECE9E1; --fg-2: #C4C8CF; --muted: #9AA3AF; --line: #2B3644; --line-2: #202A36;
  --hi: #5E4F12;
  --turn: #DE6410; --slide: #10AA82; --boost: #2A82C4;
  --c0: #3987e5; --c1: #d95926; --c2: #199e70; --c3: #c98500; --c4: #d55181; --c5: #008300; --c6: #9085e9; --c7: #e66767;
  --g-e: #3987e5; --g-s: #256abf; --g-a: #184f95; --g-gap: #2B3644;
  color-scheme: dark; } }
:root[data-theme="dark"] { /* the same Night values, repeated verbatim, so the toggle wins both ways */ }
/* on a --hi ground the quiet ink is the second ink */
:is([aria-pressed="true"], [aria-current], [aria-checked="true"], [aria-selected="true"], .is-on, .is-active, .is-target, .is-focus, details[open].tm-d) { --muted: var(--fg-2); }
```

What each token means, and only means:

| token | meaning | never |
|---|---|---|
| `--bg`, `--panel` | the page; a card, a panel, a figure frame | — |
| `--fg` = `--accent` | the ink: text, every button and link, the focus ring, a selection's line | a series colour |
| `--fg-2` | the second ink: ledes, card lines, readout lines, the quiet ink on a `--hi` ground | — |
| `--muted` | the quiet ink: eyebrows, labels, counts, axis words | on `--hi` (re-pointed to `--fg-2` there) |
| `--line`, `--line-2` | card and frame lines; hairlines between statements, hover grounds | text |
| `--hi` = `--accent-soft` | the pressed, the current, the chosen, the targeted (a ground, with an ink ring on controls) | a text colour; "new"; a try line |
| `--turn --slide --boost` | the three moves (−1, 0, +1, the sign of a square), always with their mark (ring, bar, diamond) and word | anything else |
| `--c0 … --c7` | the clock, c = 0 … 7, always with `c = n` printed | status; moves |
| `--g-e --g-s --g-a --g-gap` | the grades E/S/A of the translation matrix (letters always printed) | anything else |

A status (open, not yet proved here, our reading, needs an input, new) is told by its shape and word in ink (`Badge`), not by a hue (the numbers below). Learner level: `--fs-2: 17px; --lh: 1.6; --measure: 60ch` on `html[data-level="learner"]` (the notes one step larger with it: 17 → 18 px).

**Validation** (`node <dataviz skill>/scripts/validate_palette.js`, against the surfaces of this system; ΔE is OKLab ×100; contrast is WCAG 2):

- **The clock** (8 slots, adjacent pairs, as validated). Paper on `--panel` #FFFEFA: band, chroma pass; CVD worst adjacent 9.1 (#eda100↔#1baf7a, protan), tritan 5.8; normal-vision worst 19.6 (#e87ba4↔#eda100); three slots below 3:1 (#1baf7a 2.79, #eda100 2.15, #e87ba4 2.67; on `--bg` also #eb6834 2.88): the relief rule holds, every swatch prints `c = n` on or beside it. Night on `--panel` #151D28: all pass; CVD 8.4 (#c98500↔#199e70), tritan 8.7; normal 19.3; all 8 ≥ 3:1 on `--panel` and on `--bg`.
- **The moves** (3 slots, all pairs: any two can sit side by side). Paper on #FFFEFA: all pass; CVD worst 11.0 (#009E73↔#D55E00, deutan), tritan 8.6; normal 18.7 (#0072B2↔#009E73); on `--panel` 3.83 / 3.39 / 5.14, on `--bg` 3.49 / 3.08 / 4.67 (turn / slide / boost). Night on #151D28: all pass; CVD 11.8 (#10AA82↔#DE6410), tritan 7.4; normal 17.7 (#2A82C4↔#10AA82); on `--panel` 4.79 / 5.73 / 4.11, on `--bg` 5.23 / 6.25 / 4.48.
- **The grades** (`--ordinal`): monotone, steps ≥ 0.06, single hue, light end 2.09:1 on `--panel` in both looks: pass.
- **The status hues** of V2 (#eb6834 #6250d6 #1baf7a #e87ba4 #2a78d6 / dark #d95926 #9085e9 #199e70 #d55181 #3987e5), all pairs: Paper FAIL (CVD 4.5, #2a78d6↔#6250d6; normal 10.5), Night FAIL (CVD 1.6, #d55181↔#199e70; normal 9.8); they were the clock's own hexes (ΔE 0 to c0, c1, c2, c4, c6) and sit 3.0–6.1 from the moves (open↔turn 5.4 / 3.0, ours↔slide 5.1 / 3.7, new↔boost 6.1 / 5.3). Five statuses cannot be told apart by hue (the all-pairs cap is three), so status is drawn in ink: the dashed rim of `open` and the five icons with their words carry it. Restoring a hue is one token and one rule per status.
- **Overlaps to know**: the moves sit 3.0–6.1 from three clock slots (turn↔c1 5.4 / 3.0, slide↔c2 5.1 / 3.7, boost↔c0 6.1 / 5.3), and boost 6.1 / 5.3 from the grade E: where they meet on one page (the clock page: the clock and Three moves), the mark and the word tell them apart, never the hue. `--hi` sits 15.9 / 25.0 from c3.

**Text on ground** (every pair the sheets draw, both looks; `tests/ui/look.test.mjs` computes them):

| ink on ground | Paper | Night |
|---|---|---|
| `--fg` on `--bg` / `--panel` / `--line-2` / `--hi` | 14.57 / 16.02 / 12.97 / 12.30 | 15.24 / 13.98 / 11.97 / 6.65 |
| `--fg-2` on `--bg` / `--panel` / `--line-2` / `--hi` | 8.18 / 9.00 / 7.29 / 6.91 | 11.02 / 10.10 / 8.65 / 4.81 |
| `--muted` on `--bg` / `--panel` / `--line-2` | 5.56 / 6.11 / 4.95 | 7.25 / 6.65 / 5.69 |
| `--accent-ink` on `--accent` | 14.57 | 15.24 |
| not drawn: `--muted` on `--hi` | 4.69 | 3.16 |

Marks: the focus ring (`--accent`) 16.02 / 14.57 Paper, 13.98 / 15.24 Night on `--panel` / `--bg`. `--hi` against `--panel` is 1.30 (Paper) and 2.10 (Night): a pressed control therefore also wears an inner 1.5 px ink ring (chips, segmented options, the lens button), a pressed mark in a figure a thicker ink line.

## 2. Typography

- **Display** Newsreader 400–600 (optical size on): page titles (500, `--fs-6`, −0.015em; phone 32 px), section titles (500, 26 px), part titles (32 px), card names (26 px), the door's mark (66 px), the page's lede (21 px, `--fg-2`), the record's title; `text-wrap: balance`.
- **Body and controls** Instrument Sans 400–700: statements, notes, drawers, every control (chips and buttons 600 15 px); eyebrows are 13 px 600–700, uppercase, `letter-spacing: .09em`, in `--muted` (on a card, the ink).
- **Math** Noto Sans Math: formula labels in the pictures (ℝ ℂ ℍ, the stepper values), the switch squares; KaTeX keeps its own fonts (`public/katex/`, research level only).
- **Mono** JetBrains Mono 400/500: row ids, check ids, scripts, addresses, the status lines of the pictures (`.leaf-readout`, `.lx-readout`); `tabular-nums` on every column of numbers.
- Scale: `--fs-6` page title, 26 px section title, `--fs-3` hero statement, `--fs-2` body (17 px learner), 17 px notes (18 px learner), `--fs-1` drawers, record and captions, `--fs-0` chips and eyebrows.

Fonts link (index.html), optional and non-blocking (`media="print" onload="this.media='all'"`, `display=swap`): `https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400..600;1,6..72,400..600&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Noto+Sans+Math&family=JetBrains+Mono:wght@400;500&display=swap`. Without network the stacks above are drawn (checked: display and titles in a serif, body in a sans, formulas in a math or serif face; the fixture keeps its layout with wider stand-in faces).

## 3. Layout

- Shell: sticky top bar (56 px; phone 48 px + a second row for the switches); the segmented switches and the lens button are pills, the chosen option on `--hi` under an ink ring; content column `max-width: 1180px`, side gutter `--gutter`; a section is `grid: minmax(0, 1fr) minmax(0, 420px)` above 960 px, one column below; a wide figure (D31) takes the column from 1100 px, its drawing first, its controls under it.
- Lines: cards and frames 1.5 px `--line`, hairlines 1 px `--line-2`, controls 1.5 px ink (Chromium 141 floors a border of 1.5 px to 1 px at every pixel ratio; the look test checks each width against what the browser draws). Corners: 16 px for cards and frames (`calc(var(--radius) * 2)`), 8 px for drawers and folds, pills for chips and buttons, 12 px for a stepper.
- Spacing: an 8 px scale (4, 8, 12, 16, 24, 32, 48); `gap`, not margins, between siblings.
- Cards only where an object is really separate: the door's leaves, the hero picture, the two ways, the record, cell, step, stage and lens cards; statements are not cards (a hairline between them).
- Tables scroll in their own `overflow-x: auto` box; the page never scrolls sideways (390 px checked on every route).

### 3.1 The door (`src/styles/door.css`, `#/`)

`.door` (the page) holds, 56 px apart: `.door-hero` — the words (an optional eyebrow p, the mark in an h1, the line p in the display face, a p of links: the strong one ink, the other a ghost) beside the live clock in a card (two columns 5 : 8 from 1100 px, stacked below); `.door-cards` — a heading, an optional line, an `ol` of `li > a.door-card` (1 column, 2 from 560 px, 4 from 1100 px); `.door-shelf` — the same with row cards; `.door-chapters` — a heading and the stage cards; `.door-door` — the way to `#/atlas` in an ink frame (20 px corner), the words left, the strong button right.

A `.door-card`: the icon first (`.door-card-icon`, 64 px; 48 px on a phone and on the shelf), the number in a 28 px ink ring at the top right (`.door-card-n`; "under n" in `--muted` on the shelf), the name (h3, display 26 px), the line (p, 15 px `--fg-2`, at most 4 lines), the foot (a last span: "Open →", 14 px 600). An undrawn leaf: `.door-card.is-coming`, dashed line on `--bg`, its foot "coming" in `--muted`.

### 3.2 The page top (`src/styles/top.css`)

`.top` holds, 28 px apart: `.top-lead` (the page's lead row: display 21 px `--fg-2`, 64ch; 19 px on a phone); `.top-hero` (the FigureFrame in a card at every width: 1.5 px line, 16 px corner, 24 × 28 px padding, 12 px on a phone; the drawing first and large, its chips in one row under it, the status line in mono; the lens chips under a rule; then the "How do we know?" line); `.top-try` (the connective of `top-notes`, 14 px under the card, "Try" in 600 from the sheet); `.top-notes` (an `ol` of three `li.top-note`, each a 28 px ink ring with its number from the sheet and the note's text at 17 px; side by side from 760 px); `.top-ways` (two `.top-way` cards side by side from 900 px — one across when only a `both` text exists — each an eyebrow heading, 13 px 700 uppercase: "The physicist's way" (`.top-way-phys`), "The mathematician's way" (`.top-way-math`) followed by its lens chip `.top-way-lens`, a 32 px ink pill, `--hi` when pressed).

### 3.3 The record (`src/styles/record.css`)

`details.record` closed at the end of the page (before the links to the previous and next page): a card (1.5 px line, 16 px corner); its `summary.record-head` the title in the display face (21 px) and the counts in a second span (`--fs-1`, `--muted`), a drawn chevron at the right. Inside: `.record-table` in a `.table-scroll` box (or scrolling itself), `--fs-1`, quiet: uppercase `--fs-0` heads in `--muted`, 1 px `--line-2` between `.record-row`s, ids, scripts and addresses in `code`, counts in `td.num` right-aligned, the status as Badge's chip or its plain word; then `.record-download`, a ghost pill.

## 4. Components (name → what it renders → props → rules)

| component | renders | props | rules |
|---|---|---|---|
| `Shell` | name, mode segmented control (Physics · Mathematics), level toggle (Research · Learner), lens picker, search, theme menu, the page outline | settings from the address | settings persist in the address (`?m= l= lens=`) and in localStorage as a convenience (try/catch) |
| `LensPicker` | popover with five groups (branches, shapes, researchers, labels, conventions), one radio list, "none" first, the count of rows on this page that have a text in that lens | lenses.json | a lens with 0 texts on the page is listed, greyed, with "no readings yet"; the button on `--hi` with an ink ring while a lens is on |
| `PageHeader` | step number ("Step 10 of 20", as an eyebrow), title (per mode / learner), the "needs" chips linking to the pages this one needs, the stage word | pages.json | numbers derived from steps.json, never typed |
| `Door` | the door of §3.1 | door.json, registry.json | classes of interface 36 only |
| `PageTop`, `TwoWays` | the page top of §3.2 | the page model's `top` (interface 37) | classes of interface 36 only; numbers and "Try" from the sheet |
| `PageRecord` | the record of §3.3 | the page's rows (interface 38) | classes of interface 36 only |
| `Hero` | one `Statement` (hero row, register short at the top, full below) + one `FigureFrame` | hero of the page | always visible, never folded; the figure's learner caption at learner level |
| `Statement` | the row's text for the current (mode, level, lens); at most one `Badge`; an evidence affordance ("›" button) that opens its line in the section drawer; glossary terms with dotted underline | row id | the rendered text equals a text record; the component refuses to render free text (no `children`) |
| `Badge` | shape + word: theorem (filled square, "theorem"; 4.0.0, D90), open (dashed circle, dashed rim, "open"), cited (hollow square, "not yet proved here"), ours (lamp, "our reading"), input (plug, "needs an input: <kind>"), new (star, "new") | status | ink on `--panel`, a 1 px `--muted` rim, no hue (§1); `aria-label` with the full word; learner words: "proved for every size", "not finished", "not yet proved here", "our idea", "we had to choose this", "new" |
| `Drawer` | tabs: Evidence · Needs · Rests on / leads to · Readings · Numbers · Address | row ids of the section | research level only, except a learner "How do we know?" tab with one plain sentence per evidence item and a download link |
| `FigureFrame` | title, the drawing, controls, lens chips (Octavo chips, 44 px), "what this draws", data download | figure id | redraws on lens change; animation paused until play; `prefers-reduced-motion` respected |
| `CellCard` | signature, type (ℝ, ℂ, ℍ, M₂(ℝ)…), clock colour, one reading line, badge | cell | the 25 cards on the lattice by n (columns) and c (rows); tap → `/cells/p,q` |
| `ClockWheel` | eight sectors coloured `--c0..7`, the Gauss-sum phase, the cell's position | p, q | from `labelsEngine`; sectors labelled `c = n` |
| `Lattice` | the n × c lattice of cells with the four view switch (Clifford, simplex, cube, prime) | n ≤ 8 | the four views are the first "shape" lenses |
| `StepIndex` | the twenty steps as cards grouped by stage (physics) or by field (mathematics), each with its hero line and badge count | steps.json | the dependency arrows drawn as a small SVG map |
| `LensRoom` | the lens's description, its dictionary table, its translation-matrix column as a strip of E/S/A cells, the pages where it has readings | lens key | |
| `Register` | the virtualised table of rows with filters and a row drawer | rows | |
| `MatrixHeatmap` | 131 × 22 grid, E/S/A colours with letters, click → note | matrix.json | letters always printed (the ramp is light) |
| `GlossaryTerm` | dotted underline, tooltip/popover with the definition at the current level | term | |
| `Search` | palette: rows by text, id, check id, notion, home | built index | the current hit on `--hi` with an ink bar |
| `Footer` | credit, licence, version and date of the content build, "how the Atlas is checked" link | | |

## 5. Figures and charts

Follow the dataviz skill: thin marks, labels in text colour (never the series colour), a legend whenever two or more series, hover tooltips on every interactive drawing, dark theme as its own steps, texture available for print. The clock colours are categorical identity (c = 0…7), used only for that. The moves are a mark and a word first — a ring "−1" turn, a bar "0" slide, a diamond "+1" boost, and on a path its dash (solid, dotted, dashed) — and their colour repeats the mark through `--turn --slide --boost` only (`leaf.css`, `lens.css`: the ring's and the diamond's line, the bar's body, a path with `data-class`). A selection is a thicker ink line on a `--hi` ground. The controls of the leaves and the lens explorers are Octavo's chips: 44 px tall, a 1.5 px ink line, 600 15 px, `--hi` under the pointer and when pressed, an inner ink ring when pressed; a stepper is one box (− value +) with a 12 px corner and its value in the math face. Counts are bars or tiles with tabular numerals; the translation matrix is the one heatmap.

## 6. Learner level, as a visual rule

Larger type, shorter measure, no formulas, no drawers except "How do we know?", figures with their learner captions and no parameter controls beyond play/pause and the lens chips for shapes; badges in plain words; the page outline shows at most eight items; every page keeps its hero and at least three results, or it says "This page has no plain-words version yet" and offers the research version (never shows research text silently).

## 7. Accessibility and quality

Contrast ≥ 4.5:1 for every text on its ground in both looks (§1; `node tests/ui/look.test.mjs --routes` audits every visible text of every route at both levels: Paper weakest 4.69:1, Night 4.81:1, none below 4.5); marks ≥ 3:1; keyboard: tabs with roving tabindex, drawers as `<details>`, a skip link, visible focus (`outline: 2px solid var(--accent)`, ink); every badge and icon has an accessible name; figures have `role="img"` and an `aria-label` from the caption row; `prefers-reduced-motion` disables all animation; phone width 360–400 px verified on every page by the layout test; no element wider than the viewport except tables and drawings in their own scroll boxes; touch targets of the pictures' controls 44 px.

## 8. What not to do

No badges on standard-and-recomputed statements; no colour-only meaning; no hue for a status; no blue (or any hue) for an action: actions are ink; no `--hi` as a text colour, and no `--muted` on `--hi`; no move colour outside a move, no clock hue outside the clock; no inverted dark theme; no emoji; no numbered markers on content that is not a sequence (the twenty steps and the three notes of a page top are sequences and keep their numbers; results inside a section are not numbered); no hero taller than its content; no modal dialogs.
