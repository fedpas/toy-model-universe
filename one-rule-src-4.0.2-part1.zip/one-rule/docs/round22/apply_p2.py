#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# docs/round22/apply_p2.py — the content edits of phase 2 (release 4.0.0, "the grammar"; docs/round20/PLAN.md §4; D88–D95), applied to the
# overlays and the base tables, idempotent (a second run changes nothing). Run from the repository root, then `npm run content` twice.
#   WP15a (D88)  the shifted page is "Audit 3": its titles, its learner frame, the intro lead ATY-701 (the storyteller's drafts, round 14) says what an
#                audit is and names the three negative results; FUR-702's next line names it; content/ways.json follows (docs/round21/ways_write.py)
import json, os, sys

ROOT = os.getcwd()
def load(rel):
    with open(os.path.join(ROOT, rel), encoding='utf-8') as f: return json.load(f)
def save(rel, data, indent=1):
    text = json.dumps(data, ensure_ascii=False, indent=indent) + '\n'
    p = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    old = open(p, encoding='utf-8').read() if os.path.exists(p) else None
    if old == text: print('unchanged', rel); return
    with open(p, 'w', encoding='utf-8') as f: f.write(text)
    print('wrote', rel)

def set_text(rel, row, level, body, chain=None):
    recs = load(rel); hit = 0
    for t in recs:
        if t.get('row') == row and t.get('level') == level and t.get('lens') is None and t.get('chain', None) == chain and t.get('register', 'full') in ('full',):
            if t['body'] != body: t['body'] = body
            hit += 1
    assert hit == 1, (rel, row, level, hit)
    save(rel, recs)

# ---------------------------------------------------------------- WP15a: Audit 3 (D88)
AUDIT_RESEARCH = ("An audit, not a calibration: the paper has no measured answer to compare with, so the page runs its claims on the labels one by one, "
    "each computed, read or open, and names what fails. Three of them fail: the deviation the paper reads off its shifted operator is the imaginary part of "
    "a quantity that is not real; the paper's printed solution for the radius on a de Sitter base leaves out the friction of the base; and the radius is "
    "the scalar of a scalar–tensor theory of the kind the solar system excludes. "
    "Atiyah and Moore propose to delay the basic equations of physics by a fixed amount: the Dirac operator is exponentiated, so that one equation retards one sign of frequency and advances the other, and the same shift is carried over to the equations of gravity. This page follows their reasoning in its own order, nine steps from a prologue to three closing questions. Each step opens with the paper’s move, told in the Atlas’s words; then come the statements the labels compute at that step, told as chains; then what stays open there. The readings the Atlas proposes and the items that remain open close the page, each with its badge.")
AUDIT_LEARNER = ("This page is an audit: the paper has no measured answer to compare with, so each of its claims is run on the labels, and the page says which hold and which fail. Three fail: the small effect the paper reads off its delayed equation is the imaginary part of a number that is not real; its printed solution for the size of a fifth direction leaves out the braking of an expanding universe; and that size behaves like a field that measurements in the solar system rule out. "
    "Atiyah and Moore delay the electron's equation by a fixed amount, so that one equation looks a little into the past and a little into the future at once, and carry the same delay over to gravity. The page follows their reasoning in its own order, nine steps from a prologue to three closing questions: the paper's move in plain words, then what the labels work out, then what is still open. Our readings and the open questions come last, each with its badge.")

def wp15a():
    page = load('content/chains/shifted/page.json')
    p = page['pages'][0]['page']
    p['title'] = {'phys': "Atiyah's way: the shifted view, audited", 'math': "Atiyah's way: shifted operators, audited", 'learner': "Atiyah's way: the delayed waves, audited"}
    lf = p['learnerFrame']
    lf['h'] = "Atiyah's way: the delayed waves, audited"
    lf['before'] = "Warm-up 2 counted Furey's families of particles on the labels. Here there is no answer key: a famous mathematician's last idea, an equation that looks a little into the past and a little into the future at once, is run on the labels claim by claim, and three of its claims fail."
    save('content/chains/shifted/page.json', page)
    set_text('content/chains/shifted/texts.json', 'ATY-701', 'research', AUDIT_RESEARCH)
    set_text('content/chains/learner/shifted.json', 'ATY-701', 'learner', AUDIT_LEARNER)
    set_text('content/chains/matter/texts.json', 'FUR-702', 'research', "Next: her five tabs, the dictionary, her papers, her model, three generations and what may help; then Atiyah's way, the shifted view of Atiyah and Moore.")
    set_text('content/chains/learner/matter.json', 'FUR-702', 'learner', "Next: her five tabs, the dictionary, her papers, her model, three families and what may help. Atiyah's way follows, audited: the delayed waves of Atiyah and Moore.")
    # the note to Moore: the two negative results of the fifth direction (ATY-054, ATY-055; since 3.7.1) join the section "Where the work and the Atlas met"
    notes = load('content/notes.json'); m = next(n for n in notes['notes'] if n['key'] == 'moore')
    sec = m['sections'][1]
    line = ("The radius of the fifth direction on a de Sitter base solves the paper's equation (4.3) with the friction of the base, which the printed solution (4.4) leaves out; "
            "and as the scalar of a scalar–tensor theory it has ω = 0, which the Cassini bound excludes. Both are computed on the labels of Cl(1,4) with the engine's curvature.")
    if line not in sec['text']: sec['text'].append(line)
    for rid in ['ATY-054', 'ATY-055']:
        if rid not in sec['rows']: sec['rows'].append(rid)
        if rid not in m['rows']: m['rows'].append(rid)
    save('content/notes.json', notes, indent=2)   # the file's own indentation

# ---------------------------------------------------------------- WP12: the spine, the applications and the ways (D91)
PARTS = {1: 'spine', 2: 'spine', 3: 'spine', 4: 'spine', 5: 'spine', 6: 'spine', 7: 'spine', 8: 'spine', 9: 'spine', 10: 'spine', 11: 'spine', 12: 'spine', 13: 'spine',
         14: 'application', 15: 'application', 16: 'application', 17: 'lens', 18: 'lens', 19: 'way', 20: 'way'}
SPINE_TITLE = {'phys': 'The spine, the applications and the ways', 'math': 'The spine, the applications and the ways', 'learner': 'The spine, the applications and the ways'}

def wp12():
    # steps.json: the part of each of the twenty steps (D91): spine (1–13, the stage axis A → K → F → D → O), application (14–16), lens (17–18:
    # the finite groups lens and the category lens, steps that are lenses), way (19–20: Baez's papers and Schuller's lectures, steps that follow one
    # source; the ways that are not steps are content/ways.json)
    steps = load('content/steps.json')
    for st in steps:
        if st.get('group') in ('core', 'eq', 'lens'): st['part'] = PARTS[st['no']]
    save('content/steps.json', steps, indent=1)
    # landing.json: the page of the twenty steps is addressed as the spine (#/spine; #/steps redirects there), titled for its three parts; the door's chapters follow
    landing = load('content/story/landing.json')
    landing['routes']['steps'] = 'spine'
    landing['titles']['spine'] = SPINE_TITLE
    landing['chapters'] = ['spine' if c == 'steps' else c for c in landing['chapters']]
    save('content/story/landing.json', landing, indent=2)
    # the title on disk too (the researcher view and the record read pages.json): a chains-overlay entry for the page, last precedence
    frame = next(p for p in load('content/pages.json') if p['route'] in ('steps', 'spine'))['learnerFrame']
    frame = dict(frame); frame['h'] = 'The spine: twenty steps in three groups — thirteen on the stage axis, three applications, four ways and lenses'
    save('content/chains/spine/page.json', {'pages': [{'route': 'steps', 'page': {'title': SPINE_TITLE, 'learnerFrame': frame}}], 'layout': []})
    # the door: the card of the full Atlas opens the spine
    door = load('content/story/door.json')
    door['door'] = {'route': 'spine', 'title': 'The full Atlas', 'open': 'Walk the spine: thirteen steps, three applications, the ways'}
    door['atlas']['line'] = 'The full Atlas begins here: the rule as a statement, then the twenty steps — the spine by stage, the applications, the ways — with what each has computed and what stays open.'
    save('content/story/door.json', door, indent=1)

# ---------------------------------------------------------------- WP13: the lenses' roles (D92)
ROLES = {'dialect': ['alg', 'geo', 'top', 'cat', 'comb', 'str', 'sol', 'fld', 'furey', 'baez', 'schuller', 'hestenes', 'pga', 'roelfs', 'tian', 'majkic', 'pumplun', 'hbhl', 'atiyah'],
         'view': ['clifford', 'simplex', 'cube', 'prime', 'orthoplex', 'demicube', 'gosset', 'bits', 'primes', 'sigword', 'bitsq'],
         'toggle': ['space-plus', 'time-plus', 'cl13', 'cl31', 'role-names']}

def wp13():
    # lenses.json: the role of every lens (D92), as src/app/vocab.js LENS_ROLES (the build refuses a disagreement)
    lenses = load('content/lenses.json')
    role_of = {k: r for r, ks in ROLES.items() for k in ks}
    for l in lenses:
        l['role'] = role_of.get(l['key'], 'dialect')
        # the key order: role right after kind
        keys = list(l); keys.remove('role'); keys.insert(keys.index('kind') + 1, 'role')
        for k in keys: l[k] = l.pop(k)
    save('content/lenses.json', lenses, indent=1)

# WP10 (D94): the 16 "ours and open" name rows of the cards (the older role names: quark, lepton, confinement, electroweak, the cosmic horizon, the U(1)
# phase as the electromagnetic phase …) are placed under the toggle role-names only: their placements carry conv 'role-names', and the pages draw them
# when that toggle is on (src/app/queries.js placementOn). Their statuses and reasons are unchanged (D85).
ROLE_NAME_ROWS = ['ATL-003b', 'ATL-005b', 'ATL-007b', 'ATL-008b', 'ATL-011b', 'ATL-013b', 'ATL-014d', 'ATL-015b', 'ATL-016b', 'ATL-018d', 'ATL-019b', 'ATL-020c', 'ATL-021b', 'ATL-022b', 'ATL-024b', 'PAG-006b']
def wp10():
    rows = load('content/rows.json'); hit = 0
    for r in rows:
        if r['id'] in ROLE_NAME_ROWS:
            for so in r.get('shownOn', []):
                if so.get('page') == 'cells': so['conv'] = 'role-names'; hit += 1
    assert hit == len(ROLE_NAME_ROWS), hit
    save('content/rows.json', rows, indent=1)

# the grammar in the titles (the owner, 22 Oct 2026: "the word calibration was just for Maxwell"; the twenty steps are the spine, the applications and the
# ways): light is the calibration, unnumbered; matter is Furey's way (its title the way's, content/ways.json); the shifted page is Atiyah's way, audited
# (wp15a above); the door's chapters add the three clocks and the measured numbers
def wp12c():
    landing = load('content/story/landing.json'); ways = load('content/ways.json')
    furey = next(w for w in ways if w['key'] == 'furey')
    landing['titles']['light'] = {'phys': 'Calibration: light (Maxwell)', 'math': 'Calibration: light (Maxwell)', 'learner': 'Warm-up: do the boxes give back what we know about light?'}
    landing['titles']['matter'] = {'phys': furey['title']['phys'], 'math': furey['title'].get('math', furey['title']['phys']), 'learner': furey['title']['learner']}
    ch = landing.get('chapters', [])
    for r, after in (('clocks', 'clock'), ('calib4', 'shifted')):
        if r not in ch: ch.insert(ch.index(after) + 1 if after in ch else len(ch), r)
    landing['chapters'] = ch
    save('content/story/landing.json', landing)

if __name__ == '__main__':
    steps = sys.argv[1:] or ['wp15a', 'wp12', 'wp12c', 'wp13', 'wp10']
    for s in steps: globals()[s]()
