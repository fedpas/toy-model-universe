# The cell coordinate: the rows left on the family (p,q,r) (4.0.0, WP11)

Written by tools/migrate/fill_cells.mjs --worksheet. 3 statement rows received the cells their research text names (rows.json cellsFrom "round22:WP11 text"); the 216 rows below name no cell Cl(p,q) in their text, so the build gives them the family "(p,q,r)" as their coordinate (derived/status.json cellFrom "default": the address prints the family, no clock, no n). A worker assigns each a cell where one is meant (the cell of the step, of the paper's algebra, of the figure) by adding it to the row's `cells` in content/rows.json with cellsFrom "round22:WP11 worker", or leaves it on the family with a note. The lattice neighbours of a row (same cell, other stage; same stage, next cell) exist only for a concrete cell.

| row | group | kind | stage | home | first words |
|---|---|---|---|---|---|
| **The cells** (8) | | | | | |
| CAND-011 | CAND | computation | F | cells · cards | For so(m) the Yang–Mills–Dirac action, with the positive-energy sign of the Yang–Mills term, ties the coupling |
| CAND-012 | CAND | computation | F | cells · cards | Expanded in 1/c with exact fractions (ħ = 1), the minimally coupled Dirac–Hestenes equation ∇ψJ − eAψ = mcψγ₀  |
| CAND-037 | CAND | computation | F | cells · cards | For pressureless dust, D τ_a = 0 (forced by the Bianchi/Noether identity once E_a = κτ_a holds) is equivalent  |
| CAND-044 | CAND | computation | F | cells · cards | Tr T₃² / Tr Q² = 3/8 over the 16 (2 and 16/3) and over the 5, 10, 10̄, 5̄ and 24 of SU(5) (checked, exact): th |
| CAND-045 | CAND | computation | F | cells · cards | With D = ∇ψJ − eAψ − mψγ₀ (the coupling step), parity ψ ↦ γ₀ψ(x̄)γ₀ with A ↦ γ₀A(x̄)γ₀, time reversal ψ ↦ γ₀ψ( |
| CAND-058 | CAND | theorem | A | cells · cards | With ω = e₁ … e_n: ω̃ = (−1)^{n(n−1)/2} ω and ω ω̃ = Π_j ε_j, so ω² = (−1)^{n(n−1)/2 + q} for r = 0 and ω² = 0 |
| CAND-104 | CAND | range | A | cells · cards | The faces of the n-cube [0,1]ⁿ are the intervals [S, T] = {U : S ⊆ U ⊆ T} of the Boolean lattice 2^[n] (the co |
| CAND-138 | CAND | computation | F | cells · cards | The Kerr–Schild form of Schwarzschild, g = η + (2M/r) k⊗k (signature (−,+,+,+); η − (2M/r) k⊗k in (+,−,−,−)),  |
| **Step 1: the clock and the trinity** (1) | | | | | |
| CAND-057 | CAND | theorem | A | clock · clock | On a diagonal cell Cl(p,q,r), w = π + 2Q is Σ_{j∈a} ε_j mod 4 with ε_j = 1 for a generator of square +1 and 3  |
| **Lenses** (2) | | | | | |
| LNP-003 | LNP | reading | M | lenses · intro | the category language, “up and down”, rung 9 as the boundary, the reading of the squares −1, 0, +1 as one thre |
| LNP-004 | LNP | question | M | lenses · intro | Open: closure equations and an action principle for Schuller’s chain (not rebuilt); groups, chirality, masses  |
| **Calibration 1: light (Maxwell)** (7) | | | | | |
| CAND-139 | CAND | computation | F | light · summary | Maxwell’s equations in four dimensions are invariant under the special conformal generator K_b of so(2,4) for  |
| INP-005 | INP | definition | K | light · needs | Which generators count as time, and the overall sign of J: see the Conventions page. |
| INP-006 | INP | definition | F | light · needs | Units with c = ε₀ = μ₀ = 1: the speed of light and the two vacuum constants are set to one. |
| INP-008 | INP | definition | D | light · needs | Charge, mass, start position and start speed are chosen by hand in each of the six situations. |
| PAG-010 | PAG | reduction | F | light · intro | Maxwell in geometric algebra (Hestenes) |
| PAG-012 | PAG | question | O | light · intro | Any link between this calibration and Furey's model is open: none is claimed. |
| PAG-034 | PAG | reduction | F | light · intro | Standard, the source unread (Gårding, Acta Math. 85, 1951; Hörmander, The Analysis of Linear Partial Different |
| **Logbook** (6) | | | | | |
| CAND-035 | CAND | computation | A | logbook · map | A bar framework with V joints and E bars in ℝᵈ whose joints span ℝᵈ affinely has dim(mechanisms) − dim(self-st |
| CAND-088 | CAND | computation | K | logbook · notes | For a hypersurface-orthogonal Killing field ξ the set ξ² = 0 is a Killing horizon where ξ is regular, and for  |
| CAND-117 | CAND | computation | F | logbook · map | The Larmor power is checked for the hyperbolic motion; the recoil is not. With the Liénard–Wiechert field of t |
| MAP-035 | MAP | pointer | M | logbook · map | To read (a plan): Doran and Lasenby (action, rotor mechanics), Roelfs and De Keninck (exponentials in any sign |
| RSN-001 | RSN | computation | O | logbook · notes | Every Standard Model particle and gauge generator of one generation of your model, in six notations, side by s |
| RSN-003e | RSN | range | O | logbook · notes | Over all 5,582 admissible 8-dimensional blocks at most one set fits; among dimensions 8 to 14, the smallest th |
| **Calibration 2: matter (Furey)** (1) | | | | | |
| CAND-049 | CAND | computation | F | matter · fur-model | On the labels the doublet (1, 2, +½) is the pair of odd labels with one weak bit and no colour bit; its neutra |
| **Three generations** (1) | | | | | |
| FUR-618c | FUR | question | O | matter/generations · room | Open (not tested): whether a triality acting on a space larger than her 16-dimensional model gives an order-3  |
| **What may help** (2) | | | | | |
| FUR-630 | FUR | reading | O | matter/help · results | Our reading: the 2024 Cartan factorization and the 2026 recombination of b′_R, h′ and τ′_R play the same role, |
| FUR-637 | FUR | question | O | matter/help · questions | Open: how the e₇ of the 2024 dimension count, 133 = 9 + 28 + 96 (with the dimensions 9 and 28 of tri(ℍ) and tr |
| **Her papers** (5) | | | | | |
| FUR-555 | FUR | computation | A | matter/papers · timeline | Trialities rebuilt from the octonion table (numpy): the 14 derivations of 𝕆, the Standard Model action on Ψ⁺, |
| FUR-588 | FUR | computation | O | matter/papers · triality | Trialities rebuilt from the octonion table (numpy): the 14 derivations of 𝕆 (8 fix e₇, 6 move it), the Standa |
| FUR-589 | FUR | computation | O | matter/papers · triality | In the Standard Model action of Trialities (numpy, from the octonion table), on 32 real dimensions each: V has |
| FUR-591 | FUR | reading | O | matter/papers · fit | Our reading of the three papers side by side: 2023 gives one generation as the 16-dimensional complex space Ψ_ |
| FUR-592 | FUR | question | O | matter/papers · fit | Open: whether the 2024 Cartan factorization of Furey and Hughes and the 2026 recombination of b′_R, h′ and τ′_ |
| **The rule** (1) | | | | | |
| PAG-003 | PAG | reading | M | rule · intro | Which prime names which switch is a choice, and nothing is read into the names beyond the label they name: our |
| **Shapes** (3) | | | | | |
| CAND-026 | CAND | computation | A | shapes · sh-gosset | The Gauss sum over L/2L, Σ i^{x·x} (exact Gaussian integers), equals 2^{n/2} ζ₈^σ, σ the exact signature, for  |
| CAND-101 | CAND | lemma | A | shapes · sh-gosset | Let L be an odd unimodular lattice of rank n and k a characteristic vector (k·x ≡ x·x mod 2 for all x). Then k |
| PAG-017 | PAG | computation | K | shapes · intro | face counts, duality, even subalgebras, equation couplings, E6–E8 roots and polytopes from the Cartan matrices |
| **BAEZ: SEVEN PAPERS AND THE ATLAS** (92) | | | | | |
| CAND-007 | CAND | computation | A | steps/baez · bz-more | Λ(ℝ^r) is super-commutative (exact; commutative in the plain sense only for r ≤ 1), and the Berezin integral,  |
| CAND-019 | CAND | computation | A | steps/baez · bz-generation | On the 32 labels of five bits with five Fock modes, the 45 operators a_ia_j, a_i⁺a_j⁺ and a_i⁺a_j − δ_ij/2 kee |
| CAND-020 | CAND | computation | A | steps/baez · bz-ladder | The 27 grade-1 roots of e₇ split by the coefficient of α₆ into 1, 16 and 10 roots: the 16 is the half-spin and |
| CAND-022 | CAND | computation | A | steps/baez · bz-ladder | For the Jordan pair (h₃(𝕆), h₃(𝕆)) the space V⁺ ⊕ instr ⊕ V⁻ with [x⁺, y⁻] = (D(x,y), −D(y,x)) satisfies the |
| CAND-025 | CAND | computation | A | steps/baez · bz-papers | so(4,2) is the algebra of the 15 bivectors of four generators of square +1 and two of square −1: its Killing f |
| CAND-029 | CAND | computation | K | steps/baez · bz-kepler | Fock's map F_c(p) = (c − ¦p¦², 2p)/(c + ¦p¦²), c = −2μE, is an isometry from 4¦dp¦²/(c + ¦p¦²)² onto S³, ℝ³ (b |
| CAND-032 | CAND | computation | K | steps/baez · bz-ten | The form, not the moduli space: Thurston's triangle count on Eisenstein 10-tuples, (4/√3)·area(P) − Σ¦v_j¦², i |
| CAND-048 | CAND | computation | F | steps/baez · bz-top | The pair terms a_i⁺a_j⁺ − a_ja_i are bivectors of degrees ±2; their exponentials are orthogonal Bogoliubov tra |
| CAND-060 | CAND | computation | A | steps/baez · bz-papers | On the Albert algebra h₃(𝕆) over the XOR (Cayley–Dickson) octonions, 27 coordinates in exact integers, det =  |
| CAND-062 | CAND | computation | A | steps/baez · bz-generation | On Λℂⁿ the map e_S ↦ σ(S) e_{S̄}, σ(S) the sign of the permutation (S, S̄), is the Hodge star (u ∧ ⋆v = ⟨u, v⟩ |
| CAND-066 | CAND | computation | A | steps/baez · bz-ladder | For a frame of orthogonal minimal tripotents (each D(e,e) with eigenvalues 0, 1, 2) the joint Peirce spaces V_ |
| CAND-071 | CAND | computation | A | steps/baez · bz-generation | The two cuts of one generation are isomorphic modules of su(3) ⊕ su(2) ⊕ u(1). With Furey’s model rebuilt exac |
| CAND-074 | CAND | computation | A | steps/baez · bz-top | The hypotheses of the classification, checked exactly: II_{r,s} = U^{min(r,s)} ⊕ E₈(±1)^{¦r−s¦/8} is integral, |
| CAND-081 | CAND | computation | A | steps/baez · bz-which | For so(10) = D₅ (extended diagram with marks 1; 1, 2, 2, 1, 1), each of the 62 non-empty proper subsets S of t |
| CAND-082 | CAND | computation | A | steps/baez · bz-top | Branchings e₆ ⊃ f₄ ⊃ su(3) ⊕ su(3). The folding of the E₆ diagram (α₁ ↔ α₆, α₃ ↔ α₅), lifted to the bracket of |
| CAND-105 | CAND | range | A | steps/baez · bz-persp | The number of (x, y) ∈ ℤ² with x² − xy + y² = N is r(N) = 6 Σ_{d ¦ N} χ₋₃(d), χ₋₃ the character mod 3 (0, 1, − |
| CAND-107 | CAND | computation | A | steps/baez · bz-ring | The weight lattice of A₂, with the Killing-normalised form (roots of squared length 2, fundamental weights of  |
| CAND-131 | CAND | computation | F | steps/baez · bz-kepler | For E > 0 the Poisson algebra of L and N = A/√(2μE) is so(3,1), the bit-rule algebra of the bivectors of the s |
| CAND-133 | CAND | computation | F | steps/baez · bz-which | In so(10), as antisymmetric 10 × 10 matrices with the complex structure J and ℝ¹⁰ = ℝ⁴ ⊕ ℝ⁶ split by the weak  |
| CAND-143 | CAND | computation | F | steps/baez · bz-periodic | The Madelung order in a Thomas–Fermi field, numerically: the Thomas–Fermi function (initial slope −1.588071 by |
| INP-083 | INP | definition | O | steps/baez · needs | The colour labels 3 and 3̄ depend on a sign convention for the weights. |
| INP-084 | INP | definition | O | steps/baez · needs | The periodic-table section fills subshells in the Madelung order (n + l, then n), a textbook rule taken as giv |
| LNB-004 | LNB | computation | A | steps/baez · bz-top | B.3 Jordan data (r, a, b) = (3,8,0), (2,6,4), (2,4,2), (2,2,1) for the Albert, bi-Cayley, a₅(ℂ) and M₃,₂(ℂ) tr |
| LNB-007 | LNB | theorem | K | steps/baez · bz-top | B.6 The 27 grade-1 roots of e₇ joined at inner product 0 form srg(27,10,1,5), the intersection graph of the 27 |
| LNB-008 | LNB | computation | O | steps/baez · bz-top | B.7 On the 27 the two su(3)+su(2) branch by Casimir class (singlet, weak doublet, weak triplet, colour triplet |
| LNB-010 | LNB | computation | K | steps/baez · bz-top | B.9 The 126 roots of e₇ project to the plane of the generation A₂ as 30 at 0, 90 on the six weights ±w_k (Eise |
| LNB-010b | LNB | computation | K | steps/baez · bz-top | B.9 The lattice of these shadows is the Eisenstein lattice ℤ[ω], the lattice the triangulation note builds on  |
| LNB-017 | LNB | computation | K | steps/baez · bz-ring | In the E7 paper the roots of e₇ orthogonal to g_SM form an A₂, the generation sl₃, and the 126 roots are sorte |
| LNB-017b | LNB | computation | K | steps/baez · bz-ring | The shadows are 30 at 0, 90 on the six vectors ±w_k of squared length 2/3, and 6 on the roots of A₂ itself: 12 |
| LNB-017c | LNB | computation | K | steps/baez · bz-ring | The Eisenstein lattice has 1, 6, 0, 6, 6, 0, 0, 12 vectors of norm N = a² − ab + b² = 0 … 7: nothing at N = 2  |
| LNB-017d | LNB | computation | K | steps/baez · bz-ring | Also by enumeration: Φ₀, the 30 roots whose shadow is 0, has the profile of A₅; the 60 roots orthogonal to β_k |
| LNB-017e | LNB | computation | K | steps/baez · bz-ring | The tie to the triangulation note is the identification of the lattice, and it is checked: the weight lattice  |
| LNB-021 | LNB | computation | O | steps/baez · bz-which | The 27-dimensional space of hermitian 3 × 3 matrices over the XOR octonions, with (xy + yx)/2, satisfies the J |
| LNB-021b | LNB | computation | O | steps/baez · bz-which | At Lie-algebra level the stabilisers of the paper come out as: the Jordan frame 28, so(8), acting on the three |
| LNB-021c | LNB | computation | O | steps/baez · bz-which | The 12-dimensional algebra closes, has a one-dimensional centre, a derived algebra of dimension 11 with two si |
| LNB-021d | LNB | computation | O | steps/baez · bz-which | Its Casimir classes on the 27 real dimensions (singlet, weak doublet, weak triplet, colour triplet, colour tri |
| LNB-021e | LNB | computation | O | steps/baez · bz-which | The 27 is self-conjugate: the algebra acts on the real space h₃(𝕆), a real representation (baez·S2). |
| LNB-021f | LNB | computation | O | steps/baez · bz-which | Real representations are vector-like; the chiral generation is the 16 of the bi-Cayley triple under the E7 pap |
| LNB-021g | LNB | computation | O | steps/baez · bz-which | How the two embeddings relate through Spin(9) ⊂ Spin(10), where the 16 of Spin(9) is real: the Albert-algebra  |
| LNB-031 | LNB | reading | M | steps/baez · bz-persp | The chain is in both papers (the E7 paper’s Table 2 and introduction; the Jordan-pair paper’s Table 3 and eq.  |
| LNB-031b | LNB | reading | M | steps/baez · bz-persp | Is the su(3)+su(2) content of each rung, (3,2) first and one generation at the bi-Cayley rung, worth a table b |
| LNB-032 | LNB | computation | M | steps/baez · bz-persp | The proof of Lemma 2 uses the weight lattice of A₂ (squared lengths 2/3, 2, 8/3, …) and the bound ¦π(r)¦² ≤ 2. |
| LNB-032b | LNB | reading | M | steps/baez · bz-persp | Is it worth one sentence that the lattice in the proof of Lemma 2 is the lattice of Thurston’s stars? |
| LNB-035 | LNB | computation | O | steps/baez · bz-persp | The subalgebra of the Albert-algebra paper and the one of the E7 paper act on the 27 in different ways (J6; ba |
| LNB-035b | LNB | computation | O | steps/baez · bz-persp | The two copies of su(3)+su(2)+u(1), in f₄ and in e₇: the f₄ copy lies in an so(9) = f₄ ∩ so(10) with its su(2) |
| LNB-035c | LNB | question | O | steps/baez · bz-persp | The Jordan-pair paper says in words that the two subalgebras act on the 27 in different ways, and the E7 paper |
| LNB-038 | LNB | computation | O | steps/baez · bz-questions | The F₄ and the E₇ copies of su(3)+su(2)+u(1) (P6), computed on the roots: both lie in a copy of so(10) inside  |
| LNB-043 | LNB | computation | K | steps/baez · bz-questions | The eleven extra states of the Albert rung are the 10 + 1 of so(10,ℂ): the 27 grade-1 roots of e₇ split by the |
| LNB-045 | LNB | classification | K | steps/baez · bz-questions | The table of the regular embeddings of su(3)+su(2)+u(1) in F₄, E₆ and Spin(10), built from the roots (closed A |
| LNB-056 | LNB | computation | K | steps/baez · bz-ring | Tile a floor with triangles and count its points ring by ring: rings 0 to 7 hold 1, 6, 0, 6, 6, 0, 0 and 12 po |
| LNB-056b | LNB | computation | K | steps/baez · bz-ring | One paper lays 126 arrows of a big symmetry flat on such a floor: 30 land in the centre, 90 on ring 1 and 6 on |
| LNB-056c | LNB | computation | K | steps/baez · bz-ring | This floor is the triangle floor of another of Baez's papers, the triangulation note: the plane of the shadows |
| LNB-057 | LNB | computation | O | steps/baez · bz-periodic | Electrons in an atom take their seats in a known order. That rule of thumb closes the rows of the periodic tab |
| LNB-057b | LNB | computation | O | steps/baez · bz-periodic | Real atoms sometimes break the rule: it is an approximation. |
| LNB-057c | LNB | computation | O | steps/baez · bz-periodic | Seeing each electron as a switch turned on is our reading. |
| LNB-111 | LNB | computation | O | steps/baez · bz-which | On the 27 the stabiliser algebra of the gauge-group paper (12-dimensional, inside f₄) has Casimir classes 2, 4 |
| LNB-112 | LNB | computation | O | steps/baez · bz-top | The proof of the gauge-group paper’s Lemma 4 gives the action: 27 ⊗ ℂ = (1,1) + (1,8) + (3,3̄) + (3̄,3) under  |
| LNB-113 | LNB | computation | K | steps/baez · bz-top | The gauge-group paper’s 27 is self-conjugate (a real representation, baez·S2). |
| LNB-114 | LNB | reduction | O | steps/baez · bz-top | Real representations are vector-like; the comparison here is at Lie-algebra level only. |
| LNB-115 | LNB | computation | O | steps/baez · bz-top | In the E7 paper’s 27 the 16 of one generation takes 2, 2, 0, 6, 6 and the 11 further states 1, 4, 0, 6, 0 (bae |
| LNB-116 | LNB | computation | K | steps/baez · bz-top | Lie algebras only: the E7 paper’s su(3) + su(2) is the regular (root-based) one on the nodes α₁, α₃, α₂; the g |
| LNB-117 | LNB | computation | O | steps/baez · bz-top | How the two embeddings are related, computed on the roots: the Albert-algebra copy lies in Spin(9) inside Spin |
| LNB-119 | LNB | computation | K | steps/baez · bz-ladder | The first step is 5-graded (240 = 126 + 2·56 + 2), the others 3-graded (126 = 72 + 2·27, 72 = 40 + 2·16, 40 =  |
| LNB-121 | LNB | computation | O | steps/baez · bz-ladder | Under the E7 paper’s su(3) + su(2) the nested triples 6 ⊂ 10 ⊂ 16 ⊂ 27 contain (3,2); then + (3̄,1) + (1,1); t |
| LNB-122 | LNB | reading | O | steps/baez · bz-ladder | Reading the ladder as building a generation step by step is ours; the labels 3 and 3̄ depend on a sign convent |
| LNB-123 | LNB | computation | K | steps/baez · bz-ladder | A second route: the common neighbours of a chain of adjacent roots number 56, 27, 16, 10, 6 and then 3, the sa |
| LNB-129 | LNB | reduction | D | steps/baez · bz-kepler | A planet, or hydrogen’s electron, loops round, just escapes, or flies past, depending on its energy. |
| LNB-139 | LNB | computation | O | steps/baez · bz-papers | The two su(3) + su(2) act differently on the 27 (baez·S2; see “Which Standard Model?”). |
| LNB-141 | LNB | computation | O | steps/baez · bz-papers | They are the grade-1 pieces of E7, E6, D5, A4, and under the E7 paper’s su(3) + su(2) the 16 is one generation |
| LNB-142 | LNB | computation | K | steps/baez · bz-papers | The 27 is the grade-1 piece of E7 (baez·E1b, baez·E2d); the geometry paper’s h₃(𝕆_ℂ) also has complex dimensi |
| LNB-143 | LNB | reading | K | steps/baez · bz-papers | Linking the two papers through the 27 is ours, with a computation behind it: the E7 paper's 27 has the same Jo |
| LNB-144 | LNB | question | K | steps/baez · bz-papers | Whether the three complex 3-spaces of one and the three generations of the other are related is open. |
| LNB-146 | LNB | reading | M | steps/baez · bz-papers | That one author uses so(4,2) for hydrogen and so(6,ℂ) for matter is our remark. |
| LNB-149 | LNB | computation | K | steps/baez · bz-papers | The 126 roots of E7 projected to the plane of the generation sl₃ land on the Eisenstein lattice of the triangu |
| LNB-150 | LNB | computation | K | steps/baez · bz-papers | The two papers are tied through this lattice, and the tie is computed: the shadows of the E7 paper lie on the  |
| LNB-155 | LNB | computation | O | steps/baez · bz-papers | A script shows that the two papers place that group in two different ways. |
| LNB-158 | LNB | reading | K | steps/baez · bz-papers | No citation: both papers have a set of 27 things, and more than the number matches: the E7 paper's 27 has the  |
| LNB-159 | LNB | question | K | steps/baez · bz-papers | Whether that link means anything is open. |
| LNB-161 | LNB | reading | M | steps/baez · bz-papers | That one author uses it for atoms and for matter is our remark. |
| LNB-163 | LNB | computation | K | steps/baez · bz-papers | The 126 arrows of a big symmetry cast shadows that land on the triangle grid of paper 6, never on ring 2; a sc |
| LNB-164 | LNB | computation | K | steps/baez · bz-papers | The two papers are linked this way through a shared object that is computed: the 126 shadows land on the trian |
| LNB-166 | LNB | computation | K | steps/baez · bz-ring | Eisenstein norm N = x² − xy + y²: the rings 0 … 7 hold 1, 6, 0, 6, 6, 0, 0, 12 points; none of norm 2 (baez·T1 |
| LNB-167 | LNB | computation | K | steps/baez · bz-ring | The 126 roots of E7 project to the plane of α₆, α₇ (the generation sl₃) as aω₆ + bω₇ with N = a² + ab + b²: 30 |
| LNB-168 | LNB | reduction | K | steps/baez · bz-ring | That only N = 0, 1, 3 can occur (a shadow is never longer than a root) is the argument of the E7 paper’s Lemma |
| LNB-169 | LNB | computation | K | steps/baez · bz-ring | This lattice is the one of the triangulation note: the weight lattice of A₂, scaled by 3/2, is the Eisenstein  |
| LNB-170 | LNB | computation | K | steps/baez · bz-ring | The rings of the triangle grid hold 1, 6, 0, 6, 6, 0, 0 and 12 points. Nobody stands on ring 2. |
| LNB-171 | LNB | computation | K | steps/baez · bz-ring | The 126 shadows fall 30 in the middle, 90 on ring 1 and 6 on ring 3, and none on ring 2. |
| LNB-172 | LNB | computation | K | steps/baez · bz-ring | This is the grid of Baez's note on triangles (checked, exact: CAND-107); the link between the two papers is dr |
| LNB-173 | LNB | reduction | O | steps/baez · bz-periodic | Madelung rules: the subshell (n, l) holds 2(2l + 1) electrons, and subshells fill in order of n + l, then n. A |
| LNB-174 | LNB | computation | O | steps/baez · bz-periodic | Rows close at 2, 10, 18, 36, 54, 86, 118; the row lengths 2, 8, 8, 18, 18, 32, 32 are 2m² (baez·K3, bzw·P5). |
| LNB-177 | LNB | reduction | O | steps/baez · bz-periodic | A known rule of thumb fills the places in this order; real atoms sometimes break it. |
| LNB-178 | LNB | computation | O | steps/baez · bz-periodic | The rule closes the rows at 2, 10, 18, 36, 54, 86 and 118; a script checks the counting. |
| **THE CATEGORY LENS: WHAT IS LABEL 0?** (24) | | | | | |
| CAND-006 | CAND | computation | A | steps/category · cat-p6 | Kitaev's periodic table as Clifford extension problems on the bit rule: J, T, C anticommuting with the squares |
| CAND-051 | CAND | computation | A | steps/category · cat-label0 | If q is non-degenerate of even dimension, z′_j = e_F z_j commute with q and satisfy the relations of δ·q′ (δ = |
| CAND-055 | CAND | computation | A | steps/category · cat-twozeros | Every real quadratic space of signature (p,q,r) splits as H^m ⊥ V_an ⊥ rad with m = min(p,q), dim V_an = ¦p −  |
| CAND-065 | CAND | computation | A | steps/category · cat-arrows | For a finite poset P the Hochschild groups of the incidence algebra kP are the cohomology of the order complex |
| CAND-067 | CAND | computation | A | steps/category · cat-more | For every cell Cl(p,q,r) with n ≤ 5 (56 cells), checked exactly: the radical J, spanned by the labels with a n |
| CAND-072 | CAND | computation | A | steps/category · cat-questions | The group side: reduction mod 2 maps W(E_n) onto the whole isometry group of (E_n/2E_n, x·x/2 mod 2) for every |
| CAND-079 | CAND | computation | A | steps/category · cat-arrows | On the labels of n bits with r null bits, a·b = a ⊕ b when no null bit is shared and 0 otherwise is a monoid w |
| CAND-095 | CAND | range | A | steps/category · cat-arrows | A finite category has a strictly positive additive weight, w(g∘f) = w(f) + w(g) with w > 0 on every non-identi |
| CAND-096 | CAND | range | A | steps/category · cat-bottom | For a finite poset, Leinster's Euler characteristic, the sum Σ_{x,y} μ(x,y) of the entries of the inverse of t |
| CAND-103 | CAND | computation | A | steps/category · cat-more | Every anticommuting sign on the cube is a gauge transform of the Jordan–Wigner string (n ≤ 6); the Bravyi–Kita |
| CAND-106 | CAND | range | A | steps/category · cat-arrows | The number of up-sets of B_k (the empty and the full up-set included, so also the number of antichains and of  |
| CAND-123 | CAND | computation | F | steps/category · cat-first | λ is the Berezin integral ∫dθ_n…dθ_1, and on the Grassmann cell the top coefficient of exp(Σ_{i<j} A_ij θ_iθ_j |
| CAND-129 | CAND | range | F | steps/category · cat-first | A ℤ-grading with generator N is conserved by e^{−iHt} for all t exactly when [H, N] = 0 (recalled). In Cl(n,n) |
| CAND-135 | CAND | computation | F | steps/category · cat-frobenius | Λ(ℝⁿ) has super-dimension Σ_a (−1)^{¦a¦} = 0, and for finite graded complexes built from it with Q² = 0 and H  |
| CAND-137 | CAND | computation | F | steps/category · cat-more | From the fermionic to the bosonic ladder: the scalar part is a trace, ⟨e_A e_B⟩₀ = ⟨e_B e_A⟩₀ for every pair o |
| CAND-141 | CAND | computation | F | steps/category · cat-first | For H = Σ ε_i n_i the Gibbs functional x ↦ Tr(e^{−β(H−μN)} x)/Z is a state in the sense of T15, Z = Π(1 + e^{− |
| CAND-142 | CAND | reading | F | steps/category · cat-twozeros | On the labels the finite part of the construction is checked: the Koszul boundary d e_a = Σ_{i∈a} ± e_{a−i} sq |
| CAND-149 | CAND | computation | F | steps/category · cat-first | The lattice facts behind the pointer, computed: E₁₀ = T₂,₃,₇ has inertia (9,1,0) and determinant −1, and every |
| LNC-012 | LNC | definition | A | steps/category · cat-zero | Nothing. The element 0 and the zero object are not used: a null generator e is not the element 0 (e ≠ 0), and  |
| LNC-068 | LNC | counterexample | O | steps/category · cat-deadends | Majkić’s arrows-as-vectors construction in version 2, as a Clifford algebra: its inner product is not additive |
| LNC-069 | LNC | pointer | M | steps/category · cat-deadends | Tian’s DG category, whose K₀ is the ℤ-form of the algebra, has no counterpart in the atlas and was not tested; |
| LNC-094 | LNC | reading | M | steps/category · cat-honest | The word “category” for this lens, the moves “up and down” a ladder, and rung 9 as “the boundary” between the  |
| LNC-104 | LNC | reading | M | steps/category · intro | Calling the lit corners “where the zero hides” is our picture; what a zero switch means in nature we do not cl |
| LNC-116 | LNC | reading | M | steps/category · cat-moves | “Up and down” a ladder of boxes is our reading. |
| **MAXWELL MEETS DIRAC** (3) | | | | | |
| CAND-039 | CAND | computation | F | steps/coupling · eq-coupling | The field's stress-energy T(a) = −½ F a F has divergence J·F = −F·J whenever ∇F = J (F·J = ⟨FJ⟩₁). Conservatio |
| CAND-069 | CAND | computation | A | steps/coupling · eq-coupling | Cl⁺(1,n−1) ≅ Cl(n−1,0) (T5) is the algebra the clock (T4) gives: M₂(ℂ), M₂(ℍ), M₂(ℍ) ⊕ M₂(ℍ), M₄(ℍ), M₈(ℂ) for |
| CAND-084 | CAND | computation | F | steps/coupling · eq-coupling | Squares of the Dirac operator in a curved frame, exact at the origin. Levi-Civita connection: D̸²ψ = ∇^a∇_aψ − |
| **FORQUE: FORCE AND TORQUE AS ONE LINE** (6) | | | | | |
| CAND-036 | CAND | range | D | steps/forque · summary | At a pure rotation of the free top in the plane (a, b), for the Euclidean top (a fixed point in ℝ³), the ellip |
| FRQ-M36 | FRQ | reading | D | steps/forque · eq-forque | The paper's Lagrangian derivation (2.38), I^r I[Ḃ] = B × (I^r I[B]) ↔ not checked: it needs the dual (reciproc |
| FRQ-M37 | FRQ | reading | D | steps/forque · eq-forque | constrained motion: L v F_L = 0 (hinge) ↔ not done: a second, longer computation; the building blocks (inertia |
| FRQ-M38 | FRQ | reading | M | steps/forque · eq-forque | The ganja.js code, the hypercube, the SAT collision test and the Euler and RK4 integrators ↔ code listings pri |
| FRQ-M40 | FRQ | reading | D | steps/forque · eq-forque | Exercises and solutions (Appendix D) ↔ D.1 and D.2, as the translation matrix records them (the 2D inertia of  |
| INP-064 | INP | definition | K | steps/forque · needs | The time derivative along the motor path: the only chart is the time parameter t. |
| **GRAVITY I: CONNECTION, CURVATURE, TORSION** (1) | | | | | |
| CAND-108 | CAND | computation | A | steps/grav1 · eq-grav1 | The Schwartz–Zippel lemma (recalled for every n, d and S): a non-zero polynomial of total degree d vanishes at |
| **GRAVITY II: THE EINSTEIN FORM** (9) | | | | | |
| CAND-005 | CAND | computation | F | steps/grav2 · eq-grav2 | Noether’s second theorem for the Einstein–Cartan action, in a finite form, exact. The two identities, D E_a =  |
| CAND-010 | CAND | computation | D | steps/grav2 · eq-grav2 | Every spherically symmetric vacuum solution with Λ is locally Schwarzschild–(anti-)de Sitter, and static outsi |
| CAND-015 | CAND | computation | F | steps/grav2 · eq-grav2 | The Dirac stress and the Hehl–Datta equation, exact at the origin of 3 random polynomial frames and spinors (f |
| CAND-033 | CAND | computation | A | steps/grav2 · eq-grav2 | Invariant quadratic forms and the forms P(F), from the engine’s Lie tables, exact. For each of the 12 algebras |
| CAND-038 | CAND | computation | F | steps/grav2 · eq-grav2 | The divergence-free symmetric tensors built from the curvature, at the origin of random polynomial frames with |
| CAND-118 | CAND | computation | D | steps/grav2 · eq-grav2 | The one-body part of the Einstein–Infeld–Hoffmann equations is checked: on the isotropic Schwarzschild frame,  |
| CAND-127 | CAND | computation | D | steps/grav2 · eq-grav2 | For g = η − 2f l l with l null and geodesic the field equations are linear in f, and the stationary axisymmetr |
| CAND-148 | CAND | computation | D | steps/grav2 · eq-grav2 | The two Friedmann equations with k and Λ come from the engine’s Einstein form (c4_frw), and so does the Friedm |
| CAND-150 | CAND | computation | O | steps/grav2 · eq-grav2 | In Schwarzschild–de Sitter the periastron advance per orbit gains πΛa³√(1 − e²)/(GM) at Newtonian order (GRV-0 |
| **FINITE GROUPS: THE LENS THAT COUNTS** (4) | | | | | |
| CAND-008 | CAND | computation | A | steps/groups · ln-groups | The n-qubit stabiliser states are the 2^n Π_{k=1}^{n}(2^k + 1) joint eigenspaces of the maximal totally isotro |
| CAND-091 | CAND | theorem | A | steps/groups · ln-groups | Let w be a ℤ₄-valued quadratic refinement of a symmetric bilinear form b on 𝔽₂^m and R = rad b. Then w takes  |
| CAND-116 | CAND | range | F | steps/groups · ln-groups | Kramers degeneracy and the three types of commutant, at the cells of the bit rule: for each of the 36 cells Cl |
| LAB-012 | LAB | question | M | steps/groups · ln-groups | Open, and not treated here: the groups of Lie type over fields with more than two elements, the exceptional fa |
| **MATTER CHARGED UNDER so(m)** (1) | | | | | |
| INP-040 | INP | computation | F | steps/matter · needs | The coupling κ in D^μF_{μν} = κj_ν is fixed by the coupling g of the covariant derivative: with one action, th |
| **MIRRORS: VERSORS, CARTAN–DIEUDONNÉ, THE CUBE AS A GROUP** (2) | | | | | |
| CAND-002 | CAND | computation | A | steps/mirrors · eq-mirrors | Pin(p,q) and the twisted adjoint on the bit rule: for a non-null vector a of Cl(p,q), x ↦ α(a)xa⁻¹ = −axa/a² i |
| CAND-054 | CAND | range | A | steps/mirrors · needs | Clifford conjugation x̄ = α(x̃) equals reversion on every even element, since the grade involution α is +1 on  |
| **NULL SURFACES: THE GENERATOR OF A HORIZON IS A NULL GEODESIC** (6) | | | | | |
| CAND-016 | CAND | computation | O | steps/nullsurf · summary | A Killing horizon of surface gravity κ radiates at T = κ/2π (Hawking; Gibbons and Hawking; recalled). The Eucl |
| CAND-028 | CAND | computation | K | steps/nullsurf · nl-res-1 | The tangent algebra Cl(0, n−2, 1) of a null hypersurface, and Cl(n−2, 0, 1), has a degenerate inner product wh |
| CAND-040 | CAND | computation | F | steps/nullsurf · eq-nullsurf | The linearised Einstein form on the frame perturbation, exact: at every null covector checked (7 at n = 4) the |
| CAND-042 | CAND | computation | F | steps/nullsurf · eq-nullsurf | For a null congruence dθ/dλ = −θ²/2 − σ² + ω² − R_ab k^a k^b, fitted exactly on 23 rows with the engine’s conn |
| CAND-085 | CAND | computation | D | steps/nullsurf · summary | On the Kerr–Newman family M has weight 1 under (A, J, Q) ↦ (λ²A, λ²J, λQ); Euler's relation with ∂M/∂A = κ_H/8 |
| CAND-128 | CAND | computation | O | steps/nullsurf · needs | Fermi–Walker transport of a spin along a circular geodesic of Schwarzschild gives the de Sitter (geodetic) pre |
| **ONE MORE GENERATOR, AND A NULL PAIR** (2) | | | | | |
| CAND-018 | CAND | computation | F | steps/projective · eq-projective | Kaluza and Klein’s reduction, at the level of the field equations (the reduction of the action is recalled: Ka |
| CAND-030 | CAND | computation | K | steps/projective · summary | The projectivised null cone of ℝ^{1,3} is S² = ℂP¹, parametrised by P(x) = o + x − ½x²ε and the line of ε; the |
| **A RIGID BODY: FROM THE SEGMENT TO THE TESSERACT** (4) | | | | | |
| CAND-132 | CAND | computation | D | steps/rigid · summary | The pole-dipole equations on the engine’s Schwarzschild curvature, exact. Among force and torque F^a = k_F R^a |
| INP-076 | INP | definition | O | steps/rigid · needs | The planets' masses and positions are the example's own printed table, dated 16 Jan 2018, six bodies: data, an |
| INP-077 | INP | definition | K | steps/rigid · needs | The time derivative along the motor path: the only chart is the time parameter t (the engine integrates numeri |
| RIG-M30 | RIG | reading | D | steps/rigid · eq-rigid | Vertex masses average x² to s²/4, a uniform solid box to s²/12. So the rotational inertia of the printed cuboi |
| **SCHULLER: FROM THE ALGEBRA TO THE DYNAMICS, FIBRE AND BASE** (15) | | | | | |
| CAND-009 | CAND | computation | K | steps/schuller · sc-chain | Gårding hyperbolicity for the quadratic form P(x) = x·x of the 55 cells Cl(p,q,r), n ≤ 5: h is hyperbolic (P(h |
| CAND-056 | CAND | computation | A | steps/schuller · sc-first | For B central simple in End(V) the commutant C is central simple, C(C) = B, B ⊗ C ≅ End(V) and [C] = [B]; when |
| CAND-089 | CAND | computation | F | steps/schuller · sc-area | The self-dual Weyl tensor, written as a complex symmetric trace-free 3 × 3 matrix Q, has Jordan types I, II, D |
| CAND-090 | CAND | computation | K | steps/schuller · sc-area | The 36 components of a constitutive tensor χ^{abcd} (antisymmetric in ab and in cd) split under GL(4) as princ |
| CAND-146 | CAND | computation | F | steps/schuller · sc-fock | Exact bosonization on two closed square surfaces, the surface of the 3-cube (6 faces, 12 edges, 8 vertices) an |
| INP-085 | INP | definition | F | steps/schuller · needs | The matter action (Schuller’s stone 1) and his closure construction are imported; the page rebuilds the symbol |
| LNS-023 | LNS | question | M | steps/schuller · sc-stops | Gluing. Topology, bundles and connections as sections over a manifold: the atlas is pointwise algebra and fini |
| LNS-054 | LNS | reading | M | steps/schuller · sc-honest | The names base and fibre, outside and inside, are ours. |
| LNS-063 | LNS | reading | M | steps/schuller · sc-chain | Two of his seven stones match our rule exactly, and a script checks both. |
| LNS-063b | LNS | reading | M | steps/schuller · sc-chain | The other stones match only in shape, or only as our reading: how close each one comes is our judgement, shown |
| LNS-065 | LNS | reading | M | steps/schuller · sc-fibre | Calling them outside and inside, and what they are in physics, is our reading. |
| LNS-069 | LNS | question | M | steps/schuller · sc-stops | Our rule works at one point at a time, with a finite number of switches; spaces with endless directions are ou |
| LNS-073 | LNS | reading | M | steps/schuller · sc-honest | The names outside and inside are ours. |
| LNS-101 | LNS | reading | M | steps/schuller · sc-chain | Schuller works from how matter and light move to the law of gravity. Our rule matches his second and third ste |
| LNS-104 | LNS | reading | M | steps/schuller · sc-chain | Grades S, E, E, S, S, S, A in the figure’s order (finding F6 lists them as E, S, E, …: the figure is right). T |
| **POINTORS AND THE THREE KINDS OF i** (2) | | | | | |
| CAND-017 | CAND | computation | F | steps/spin · eq-spin | Cl⁰(1,3) ⊗ ℂ is M₂(ℂ) ⊕ M₂(ℂ): ω = iI is central with ω² = 1, the idempotents (1 ± ω)/2 split it, and the matr |
| SPN-M26 | SPN | reading | K | steps/spin · eq-spin | §3.3 (end), §4 ↔ the paper announces a specific real idempotent, the construction of “spinors” from pointors b |
| **A SPRING ON THE CUBE: VERTICES, EDGES, FACES** (2) | | | | | |
| CAND-034 | CAND | computation | F | steps/spring · eq-spring | The fermion doubling theorem, the count: H(k) = Σ sin(k_μ)γ_μ with γ_μ the left multiplication matrices of Cl( |
| INP-074 | INP | definition | K | steps/spring · needs | The time derivative along the flow: the only chart is the time parameter t. |
| **YANG–MILLS** (6) | | | | | |
| ATY-014 | ATY | computation | F | steps/ym · ym-checks | The paper's numbers for one Skyrmion, recomputed by a standard route only (floats: quad, solve_bvp; no row of  |
| ATY-015 | ATY | reduction | F | steps/ym · ym-checks | Atiyah and Sutcliffe, read, not run here. Checked here: baryon number equals instanton number for the charge-o |
| ATY-015b | ATY | reading | F | steps/ym · ym-checks | The paper's outlook, a reading and not a result: the infinite curvature limit, curvature read as a pion mass a |
| CAND-027 | CAND | computation | K | steps/ym · summary | A Cartan connection A valued in g = h ⊕ g/h has curvature F = dA + ½[A, A], with D_A F = 0 (from the Jacobi id |
| CAND-124 | CAND | computation | F | steps/ym · summary | The BPST connection (regular gauge; on so(3) and on one su(2) factor of so(4)) is self-dual on Euclidean ℝ⁴ wi |
| INP-035 | INP | definition | F | steps/ym · needs | The gauge coupling g is a free constant. |
