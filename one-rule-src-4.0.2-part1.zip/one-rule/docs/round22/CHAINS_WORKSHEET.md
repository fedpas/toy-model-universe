# Statements in no chain: the worksheet of WP14 (4.0.0)

Written by `node tools/story/extract_chains.mjs --sections-without-chains --out <file>` from the merged tables. Of the 1539 statement rows of the tables (story and meta rows apart), 717 are told in a chain of content/chains.json and 822 are not: 366 of them stand in the sections of the story pages with role result or detail (the table below, largest section first, with the chains the section already has); the others are the 149 lines of the translation matrices (told as tables, D35), 67 rows of the Logbook's own pages (the notes and the map are views), 119 rows of the inputs sections ("the inputs of this step": one chain per page, WP14), 121 rows placed with another role (caption, evidence, note, learner, next). The composer takes a section with `--page <route> --section <id>` (the mechanical draft by E1–E9) or `--into content/chains/<owner>/chains.json` (the draft added for titling), then the storyteller's pass under the sweep brief (docs/09_TRANSLATION_PROTOCOL.md §2.2, checker R1–R13). A row told in a figure caption only, or a note of a page top, may stay out with its reason recorded in the section's chains file.

| page · section | chains | rows in no chain / rows | the rows |
|---|---|---|---|
| steps/baez · bz-persp | 0 | 20 / 20 | CAND-105 LNB-030 LNB-030b LNB-031 LNB-031b LNB-032 LNB-032b LNB-033 LNB-033b LNB-033c LNB-034 LNB-034b LNB-034c LNB-035 LNB-035b LNB-035c LNB-036 LNB-036b LNB-037 LNB-037b |
| steps/schuller · sc-persp | 0 | 19 / 19 | LNS-027 LNS-028 LNS-028b LNS-028c LNS-028d LNS-028e LNS-029 LNS-030 LNS-030b LNS-031 LNS-031b LNS-032 LNS-033 LNS-033b LNS-034 LNS-035 LNS-035b LNS-036 LNS-036b |
| cells · cards | 23 | 16 / 86 | ATL-004 ATL-009 ATL-022c ATL-022d CAND-001 CAND-011 CAND-012 CAND-037 CAND-045 CAND-058 CAND-104 CAND-126 CAND-138 GEN-011 GEN-033 GEN-034 |
| steps/baez · bz-generation | 3 | 16 / 32 | CAND-062 FUR-041 LNB-014 LNB-014b LNB-014c LNB-014d LNB-014e LNB-014f LNB-014g LNB-015 LNB-015b LNB-015c LNB-015d LNB-015e LNB-015f LNB-015g |
| steps/category · cat-first | 1 | 16 / 16 | CAND-043 CAND-077 CAND-111 CAND-123 CAND-129 CAND-141 CAND-149 LNC-002 LNC-003 LNC-004 LNC-005 LNC-006 LNC-007 LNC-008 LNC-009 LNC-010 |
| steps/category · cat-questions | 0 | 16 / 18 | CAND-072 LNC-077 LNC-078 LNC-078b LNC-079 LNC-079b LNC-082 LNC-082b LNC-083 LNC-083b LNC-083c LNC-084 LNC-085 LNC-086 LNC-087 LNC-088 |
| steps/schuller · sc-first | 0 | 11 / 12 | CAND-056 LNS-001 LNS-001b LNS-003 LNS-003b LNS-004 LNS-005 LNS-006 LNS-007 LNS-008 LNS-009 |
| steps/schuller · sc-questions | 0 | 10 / 10 | LNS-045 LNS-045b LNS-045c LNS-046 LNS-046b LNS-047 LNS-048 LNS-048b LNS-049 LNS-050 |
| steps/baez · bz-questions | 0 | 9 / 9 | LNB-038 LNB-039 LNB-040 LNB-041 LNB-042 LNB-042b LNB-043 LNB-044 LNB-045 |
| steps/category · cat-honest | 1 | 9 / 12 | LNC-089 LNC-090 LNC-091 LNC-092 LNC-093 LNC-094 LNC-095 LNC-096 LNC-097 |
| matter/help · results | 0 | 8 / 8 | FUR-628 FUR-629 FUR-630 RSN-003 RSN-003b RSN-003c RSN-003d RSN-003e |
| steps/coupling · eq-coupling | 8 | 8 / 46 | CAND-039 CAND-084 CAND-110 CPL-005 CPL-006 CPL-006b CPL-008 CPL-010b |
| steps/category · cat-deadends | 0 | 7 / 7 | LNC-063 LNC-064 LNC-065 LNC-066 LNC-067 LNC-068 LNC-069 |
| steps/schuller · sc-fock | 1 | 7 / 16 | CAND-146 LNS-066 LNS-130 LNS-131 LNS-133 LNS-133b PAG-003 |
| steps/schuller · sc-honest | 0 | 7 / 7 | LNS-051 LNS-052 LNS-053 LNS-054 LNS-055 LNS-056 LNS-057 |
| steps/spin · eq-spin | 0 | 7 / 7 | CAND-017 SPN-003 SPN-003b SPN-004 SPN-004b SPN-005 SPN-005b |
| matter/generations · room | 0 | 6 / 6 | FUR-615 FUR-618 FUR-618b FUR-618c FUR-619 FUR-619b |
| matter/help · questions | 0 | 6 / 9 | FUR-637 PAG-016 PAG-016b PAG-016c PAG-016d PAG-016e |
| steps/baez · bz-top | 6 | 6 / 29 | CAND-023 LNB-002 LNB-003 LNB-004 LNB-007 LNB-009 |
| steps/category · cat-moves | 2 | 6 / 16 | CAND-119 LNC-117 LNC-118 LNC-121 LNC-122 LNC-123 |
| matter/papers · timeline | 0 | 5 / 5 | FUR-543 FUR-547 FUR-551 FUR-555 PAG-014 |
| steps/baez · bz-honest | 0 | 5 / 5 | LNB-047 LNB-047b LNB-048 LNB-049 LNB-051 |
| steps/category · cat-frobenius | 2 | 5 / 14 | CAND-135 LNC-111 LNC-112 LNC-113 LNC-114 |
| steps/dirac · dirac-xref | 0 | 5 / 6 | EQN-031 EQN-524 EQN-526 EQN-527 EQN-528 |
| steps/groups · ln-groups | 3 | 5 / 14 | CAND-008 CAND-116 LAB-011 LAB-011b LAB-012 |
| steps/rigid · eq-rigid | 0 | 5 / 6 | RIG-002 RIG-003 RIG-003b RIG-005 RIG-006 |
| steps/schuller · sc-quantum | 0 | 5 / 5 | CAND-144 LNS-037 LNS-038 LNS-039 LNS-040 |
| steps/schuller · sc-thm | 0 | 5 / 5 | LNS-058 LNS-059 LNS-060 LNS-061 LNS-062 |
| clock · clock | 3 | 4 / 38 | LAB-001 LAB-015 LAB-016 PAG-006 |
| matter/generations · count | 0 | 4 / 4 | FUR-606 FUR-608 PAG-015 RSN-003b |
| matter/papers · checkpoints | 0 | 4 / 4 | FUR-570 FUR-572 FUR-573 FUR-573b |
| rule · conventions | 0 | 4 / 4 | CPL-011 CPL-011b PAG-031 PAG-032 |
| steps/category · cat-top | 2 | 4 / 14 | LNC-127 LNC-129 LNC-130 LNC-131 |
| steps/category · cat-twozeros | 1 | 4 / 10 | CAND-113 CAND-142 LNC-134 LNC-136 |
| steps/forque · eq-forque | 0 | 4 / 4 | FRQ-002 FRQ-003 FRQ-005 FRQ-515 |
| steps/nullsurf · eq-nullsurf | 1 | 4 / 8 | NUL-008 NUL-009 NUL-011 NUL-012 |
| matter/generations · board | 0 | 3 / 3 | RSN-003 RSN-003d RSN-003e |
| matter/generations · composite | 0 | 3 / 3 | FUR-611 FUR-612 RSN-003c |
| matter/model · axes | 1 | 3 / 37 | FUR-014b FUR-041 FUR-042 |
| matter/papers · cascade | 0 | 3 / 3 | FUR-581 FUR-582 FUR-583 |
| rule · ideas | 6 | 3 / 33 | GEN-006b GEN-033 GEN-034 |
| shapes · sh-gosset | 4 | 3 / 21 | ATY-019b GOS-511 GOS-511b |
| steps/mirrors · eq-mirrors | 3 | 3 / 18 | LAB-015 MIR-006 PAG-019 |
| steps/nullsurf · summary | 0 | 3 / 3 | CAND-016 CAND-085 EQN-020 |
| steps/schuller · sc-notes | 0 | 3 / 3 | LNS-042 LNS-043 LNS-044 |
| steps/ym · summary | 1 | 3 / 6 | CAND-027 CAND-047 EQN-010 |
| light · summary | 0 | 2 / 3 | CAND-139 EQN-006 |
| matter · fur-next | 1 | 2 / 9 | FUR-014b INP-011b |
| matter/papers · fit | 0 | 2 / 2 | FUR-591 FUR-592 |
| matter/papers · triality | 0 | 2 / 2 | FUR-588 FUR-589 |
| steps/baez · bz-notes | 0 | 2 / 2 | LNB-046 LNB-046c |
| steps/category · cat-bottom | 1 | 2 / 6 | CAND-096 LNC-054b |
| steps/category · cat-label0 | 2 | 2 / 12 | CAND-051 CAND-147 |
| steps/category · cat-more | 4 | 2 / 13 | LNC-057 LNC-058 |
| steps/category · cat-p3 | 0 | 2 / 2 | LNC-073 LNC-073b |
| steps/category · cat-p4 | 0 | 2 / 2 | LNC-074 LNC-074b |
| steps/category · cat-p6 | 0 | 2 / 5 | LNC-076 LNC-076d |
| steps/category · cat-papers | 0 | 2 / 2 | LNC-061d LNC-062 |
| steps/forque · summary | 0 | 2 / 2 | CAND-036 EQN-016 |
| steps/matter · eq-matter | 3 | 2 / 9 | MAT-006 MAT-007 |
| steps/rigid · summary | 0 | 2 / 2 | CAND-132 EQN-019 |
| steps/schuller · sc-chain | 1 | 2 / 11 | CAND-009 LNS-106b |
| steps/spin · summary | 0 | 2 / 2 | CAND-076 EQN-017 |
| steps/ym · ym-checks | 1 | 2 / 6 | ATY-015b YM-509 |
| clock · clock-biv | 0 | 1 / 1 | LAB-004 |
| light · charges | 0 | 1 / 1 | RSN-026 |
| matter · fur-labels | 2 | 1 / 12 | FUR-042 |
| matter · fur-sixteen | 1 | 1 / 8 | FUR-041 |
| matter/generations · whole | 0 | 1 / 1 | FUR-621 |
| matter/model · charges | 0 | 1 / 1 | FUR-598 |
| matter/papers · spectra | 0 | 1 / 1 | FUR-585 |
| shapes · sh-orth | 2 | 1 / 9 | MAP-022 |
| steps/baez · bz-numbers | 1 | 1 / 5 | LNB-058c |
| steps/baez · bz-periodic | 1 | 1 / 9 | LNB-057c |
| steps/category · cat-defs | 0 | 1 / 1 | LNC-517 |
| steps/category · summary | 0 | 1 / 1 | EQN-021 |
| steps/comm · summary | 0 | 1 / 1 | EQN-007 |
| steps/coupling · cp-checks | 0 | 1 / 1 | CAND-120 |
| steps/coupling · summary | 0 | 1 / 1 | EQN-009 |
| steps/grav1 · eq-grav1 | 2 | 1 / 12 | GRV-005b |
| steps/grav1 · g1-checks | 0 | 1 / 2 | ATY-018 |
| steps/grav1 · summary | 0 | 1 / 1 | EQN-012 |
| steps/grav2 · eq-grav2 | 5 | 1 / 30 | ATY-024b |
| steps/grav2 · summary | 0 | 1 / 1 | EQN-013 |
| steps/matter · mt-checks | 0 | 1 / 1 | MAT-509 |
| steps/matter · summary | 0 | 1 / 1 | EQN-011 |
| steps/mirrors · summary | 0 | 1 / 1 | EQN-014 |
| steps/nullsurf · nl-res-1 | 1 | 1 / 7 | CAND-028 |
| steps/nullsurf · nl-res-2 | 0 | 1 / 1 | NUL-002 |
| steps/nullsurf · nl-res-3 | 0 | 1 / 1 | NUL-003 |
| steps/nullsurf · nl-res-4 | 0 | 1 / 1 | NUL-004 |
| steps/projective · summary | 1 | 1 / 5 | EQN-015 |
| steps/schuller · sc-fibre | 3 | 1 / 22 | LNS-018 |
| steps/schuller · sc-total | 1 | 1 / 4 | SPN-004 |
| steps/spring · eq-spring | 1 | 1 / 4 | CAND-034 |
