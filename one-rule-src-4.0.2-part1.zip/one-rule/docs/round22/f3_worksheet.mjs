#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// docs/round22/f3_worksheet.mjs — the worksheet of the math referee's list F.3 (round 20: the computed rows that are corollaries of standard theorems,
// "upgradeable to for every n with the citation"), written from the tables: per group the rows, the referee's citation, each row's status at 4.0.0,
// its kind, whether its text already claims every n, and what the owner's edit would be. Nothing here changes a table: the upgrade of a row to
// `theorem` needs its research text to claim every n and its reference to name the theorem (tools/status_rule.mjs), and the text is the author's.
// Usage: node docs/round22/f3_worksheet.mjs > docs/round22/F3_UPGRADES.md
import fs from 'node:fs';
import { claimsEveryN, namedProof } from '../../tools/status_rule.mjs';
const J = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const R = J('content/rows.json'), S = J('content/derived/status.json'), T = J('content/texts.json');
const txt = new Map(T.filter(t => t.level === 'research' && t.lens === null && t.mode === 'both' && !t.chain && t.register !== 'span').map(t => [t.row, t.body]));
const byId = new Map(R.map(r => [r.id, r]));
const GROUPS = [
  ['GEN-010 GEN-013 GEN-017 GEN-031', 'Cl(n+8) ≅ Cl(n) ⊗ Cl(8): Atiyah–Bott–Shapiro, Clifford modules, Topology 3 (1964), Prop. 4.2; Lawson–Michelsohn, Spin Geometry, Ch. I §4'],
  ['GEN-018 GEN-022 ATY-001 ATY-026', 'KO^{p−q}(pt) from graded modules: ABS Table 2 (and the derivation from the type table, review D)'],
  ['GEN-021 GEN-027 GEN-028', 'Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^r); idempotent lifting over a nilpotent ideal: Lam, A First Course in Noncommutative Rings, §21'],
  ['GEN-015 GEN-020', 'the CAR and its Bratteli diagram 1 → 2 → 4 → …'],
  ['GEN-026 GEN-030', 'direct limits of matrix algebras, the dimension group ℤ[1/16] = ℤ[1/2]: Bratteli 1972; Glimm 1960'],
  ['GEN-032', 'the Gauss sum in closed form'],
  ['GEN-033 GEN-034', 'complexification: Cl(p,q) ⊗ ℂ ≅ ℂl_n'],
  ['GEN-011', 'the ungraded tensor product has the type of the graded one iff one clock is 0 or 4 mod 8: the lemma of review D (Lawson–Michelsohn I.4)'],
  ['LNC-059 CAND-083', 'primitive idempotents = maximal totally singular subspaces (review D, lnc059_idempotents.py)'],
  ['LAB-035', "Witt's theorem for ℤ₄-forms (Wood, Trans. AMS 336 (1993)); the count of Lagrangians (Taylor, The Geometry of the Classical Groups, the chapter on orthogonal groups)"],
  ['LAB-034', "Weil's Theorem 5 (Acta Math. 111 (1964)), an instance"],
  ['ATY-033', 'quadratic Gauss sums (the self-duality of a ℤ₄-bent function)'],
  ['LAB-017 RSN-029 LNC-006', 'elementary (the Gauss sum product formula)'],
  ['LNC-045 LNC-130 LNC-087', 'E_n/2E_n for n ≤ 8: Coble; Dolgachev–Ortland, Astérisque 165, Ch. VI'],
  ['LAB-030', 'the Clifford group as the normaliser of the Pauli group: Bolt–Room–Wall 1961; Weil n° 10'],
  ['CAND-008', 'stabiliser counts'],
  ['CAND-026 ATY-016', "van der Blij's congruence; Milgram's formula (Milnor–Husemoller, Symmetric Bilinear Forms, App. 4)"],
  ['CAND-104 CAND-096 CAND-065 CAND-100 CAND-106', 'face posets (Ziegler; Stanley), Leinster, Gerstenhaber–Schack, Dedekind'],
  ['CAND-050', 'Frenkel–Kac'],
  ['CAND-063 CAND-064', "triality; Cartan's pure spinors"],
  ['CAND-140 ATY-032 CAND-145', 'McKay; Bethe'],
  ['ATY-031', "Mednykh's / Frobenius's formula for |Hom(π₁Σ_g, G)|"],
  ['CAND-116', 'Dyson; Kramers'],
  ['MAP-016 EQN-007', 'so(p,q) structure constants'],
  ['MIR-009 MIR-010 RSN-007 RSN-023', 'Cartan–Dieudonné over ℝ'],
  ['PAG-005 CAND-058', 'the centre of Cl(p,q,r)'],
  ['LNC-002 LNC-014 LNC-016 LNC-017', 'the radical'],
  ['LNC-004 LNC-028 LNC-029 LNC-030 CAND-061', 'the Frobenius structure of Λ(V) and Cl: symmetric iff n odd (Skowroński–Yamagata, Frobenius Algebras I, Ch. IV; Lam, Lectures on Modules and Rings, §16)'],
  ['LNC-007 LNC-036', 'the even subalgebra'],
  ['LNC-035 LNC-117', 'the graded tensor product'],
  ['THM-004 LNC-144', 'the incidence algebra inside End Λ'],
  ['LNB-002 CAND-094', 'Albuquerque–Majid, J. Algebra 220 (1999)'],
  ['LNB-016 LNB-118 LNB-119 CAND-052', 'Levi gradings'],
  ['LNB-007 CAND-109', 'the Schläfli graph'],
  ['LNB-010 LNB-167 CAND-021', 'E₇ ⊃ A₂ × A₅'],
  ['CAND-024 LNB-011', 'Majorana–Weyl iff s − t ≡ 0 mod 8'],
  ['CAND-074', 'Serre, A Course in Arithmetic, Ch. V'],
  ['CAND-107 CAND-105', 'the Eisenstein integers'],
  ['CAND-019', 'ℤ₆'],
  ['CAND-003', 'anomaly sums'],
];
const out = [];
out.push('<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->');
out.push('# Round 22 — the worksheet of the referee\'s list F.3: computed rows that are corollaries of standard theorems', '');
out.push('Written by `docs/round22/f3_worksheet.mjs` from the tables (`node docs/round22/f3_worksheet.mjs > docs/round22/F3_UPGRADES.md`). The math referee of round 20 (`docs/round20/review_math_REVIEW.md` §F.3) lists the computed rows that are immediate corollaries of standard theorems, "upgradeable to for every n with the citation". At 4.0.0 a row is `theorem` when its kind says so, its research text claims every n in words and its proof is named (`tools/status_rule.mjs`, D90); the text is the author\'s, so the upgrade of a row that does not yet claim every n is the owner\'s edit, listed here with the referee\'s citation, not applied. A row whose text claims every n and whose kind is not a theorem kind is a question for the labelling (the kind is the mathematician persona\'s, `docs/labelling/`).', '');
let n = 0, done = 0, needText = 0, needKind = 0, needRef = 0;
out.push('| rows | the referee\'s citation | row | kind | status at 4.0.0 | claims every n | proof named | the owner\'s edit |', '|---|---|---|---|---|---|---|---|');
for (const [ids, cite] of GROUPS) {
  for (const id of ids.split(' ')) {
    const r = byId.get(id); if (!r) { out.push(`| ${ids} | ${cite} | ${id} | — | not a row | | | |`); continue; }
    n++;
    const st = (S[id] || {}).status, every = claimsEveryN(txt.get(id)), named = namedProof(r), thk = ['theorem', 'lemma', 'classification', 'invariant'].includes(r.kind);
    let edit;
    if (st === 'theorem') { edit = 'none: theorem at 4.0.0'; done++; }
    else if (!['computed', 'standard-recomputed'].includes(st)) edit = `none: the status is ${st}`;
    else { const parts = []; if (!every) { parts.push('the text to say "for every n" (or the theorem\'s quantifier) with the citation'); needText++; } if (!thk) { parts.push(`the kind (${r.kind}) to theorem, lemma, classification or invariant if the statement is one`); needKind++; } if (!named) { parts.push('the citation into standardRef'); needRef++; } edit = parts.join('; ') || 'none'; }
    out.push(`| ${ids} | ${cite} | ${id} | ${r.kind} | ${st} | ${every ? 'yes' : 'no'} | ${named ? 'yes' : 'no'} | ${edit} |`);
  }
}
out.push('', `${n} rows in the list: ${done} are \`theorem\` at 4.0.0; ${needText} need the text to claim every n; ${needKind} need their kind looked at; ${needRef} need the citation in \`standardRef\`.`);
process.stdout.write(out.join('\n') + '\n');
