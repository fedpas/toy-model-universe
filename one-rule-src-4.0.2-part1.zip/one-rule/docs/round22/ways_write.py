#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round22/ways_write.py — the ways at 4.0.0 (D87, D91; docs/round20/PLAN.md §4 WP12): the pages of the chains overlay that follow one source
in the source's own order, and the registry content/ways.json. 3.8.0 wrote Weil's and Penrose's ways (docs/round21/ways_write.py, whose specs are
reused here); 4.0.0 adds Kitaev's way (content/chains/way-kitaev/: the periodic table of free-fermion matter read on the labels, its rows kept at
their homes on the clock and category pages) and registers the ways that were pages already — Baez's seven papers (steps/baez), Schuller's
lectures (steps/schuller), Furey's model (matter, Calibration 2) — beside Atiyah–Moore (shifted, Audit 3). The leads of Kitaev's way are research
drafts (source round22:WP12, since v4.0); its chains' links are what the tables give (node docs/round20/rejoin.mjs --relink, D83). Idempotent.
Usage: python3 docs/round22/ways_write.py"""
import importlib.util, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
_spec = importlib.util.spec_from_file_location('ways21', os.path.join(ROOT, 'docs', 'round21', 'ways_write.py'))
W21 = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(W21)
SRC = 'round22:WP12'
STORY21, TEXT21 = W21.story, W21.text


def story(rid, group, page, section, role, order, restates):
    r = STORY21(rid, group, page, section, role, order, restates)
    r['since'] = 'v4.0'; r['source'] = SRC
    return r


def text(rid, body):
    t = TEXT21(rid, body); t['source'] = SRC
    return t


# ====================================================================================================================== Kitaev's way
KITAEV = {
    'route': 'ways/kitaev', 'key': 'ways-kitaev', 'group': 'LNC', 'folder': 'way-kitaev', 'after': 'shifted', 'needs': ['clock', 'steps/category'],
    'title': {'phys': "Kitaev's way: the periodic table, read on the labels", 'math': "Kitaev's way: the tenfold way and KO, read on the labels", 'learner': "Kitaev's way: a table of matter, read on the switches"},
    'hero': {'row': 'LAB-021', 'figure': None},
    'learnerFrame': {'h': "Kitaev's way: a table of matter, read on the switches", 'before': "The clock of the cells counts in eighths of a turn. A physicist's table of 2009 sorts the kinds of matter made of free fermions into ten classes, eight of which repeat with the same period; here the table is read with the switches in the place of its symmetries.", 'after': 'Next: ways of looking, the lenses page.', 'tags': []},
    'intro': ('LNC-731', ['LNC-076b'], "Kitaev's way through the Atlas. The periodic table of free-fermion matter sorts its symmetry classes by the squares of time reversal and of charge conjugation, builds from each class a Clifford algebra, and reads the phases of matter in each dimension off the K-theory of a point, which repeats with period eight. Here the table is read on the labels of one cell at a time: the symmetry algebra of a class is a cell, the extension problem that classifies the phases is run on the labels, the K-theory is the clock, and the eightfold degeneracy of Majorana chains that the same author found with Fidkowski is computed at a junction of chains. The way ends where the labels stop: which class sits at which clock value needs the squares of the symmetries as inputs, and the match is fixed only up to a reflection."),
    'sections': [
        {'id': 'k-1', 'lead': 'LNC-741', 'title': {'phys': '§2. The symmetry classes as cells', 'math': '§2. The symmetry algebra of a class as Cl(p,q)', 'learner': 'Part 2: ten kinds of symmetry, ten small cells'},
         'rows': ['LNC-076b'], 'chain': {'slug': 'classes', 'phys': 'The symmetry algebra of each class', 'math': 'The ten classes as cells of the bit rule', 'learner': 'Each kind of symmetry as a cell'},
         'text': "The table starts from the symmetries a free-fermion Hamiltonian can have: time reversal and charge conjugation, each squaring to plus or minus one, and their product; the ten ways to have or lack them are the Altland–Zirnbauer classes. The paper notes that the anticommuting generators of a class generate a Clifford algebra. On the labels that algebra is a cell: for each real class the cell of the anticommuting generators built from the squares of the symmetries, and for the two complex classes an algebra over the complex numbers; the commutant of the minimal module of each cell is read off the type table, class by class."},
        {'id': 'k-2', 'lead': 'LNC-742', 'title': {'phys': '§3. The table as a Clifford extension problem', 'math': '§3. The extension problem Cl(p,q) → Cl(p,q+1)', 'learner': 'Part 3: adding one generator at a time'},
         'rows': ['CAND-006'], 'chain': {'slug': 'extension', 'phys': 'The periodic table as Clifford extension problems', 'math': 'The extension problems of the eight real classes', 'learner': 'The table as a game of adding a generator'},
         'text': "The paper classifies the phases of a class in a given dimension by an extension problem: a flattened Hamiltonian is one more Clifford generator, and the kinetic generators of the dimension are others, so the phases are the ways to extend the symmetry algebra by one generator, counted by the K-theory of a point. On the labels the extension problem is run as written, for each real class and each dimension, with the generators of the symmetry algebra and of the kinetic terms as labels, and the count of extensions is computed cell by cell."},
        {'id': 'k-3', 'lead': 'LNC-743', 'title': {'phys': '§4. The period eight: KO on the labels', 'math': '§4. KO^{s−d}(pt) from graded modules', 'learner': 'Part 4: why the table repeats after eight'},
         'rows': ['ATY-001', 'ATY-026'], 'chain': {'slug': 'ko', 'phys': 'The K-theory of a point by the clock', 'math': 'The ABS ring from the bit rule', 'learner': 'The eight-step repeat of the table'},
         'text': "The paper reads the table off the K-theory of a point, which depends on the difference between the number of symmetry generators and the dimension, and repeats with period eight by Bott periodicity. On the labels that K-theory is the clock: the graded modules of a cell modulo those that extend to one more generator are computed from the cells' own left ideals, and the list the paper takes from Atiyah, Bott and Shapiro comes out of the bit rule, with its period."},
        {'id': 'k-4', 'lead': 'LNC-744', 'title': {'phys': 'After the table: the eightfold way of Majorana chains', 'math': 'After the table: the ℤ₈ of Fidkowski and Kitaev', 'learner': 'After the table: eight kinds of chain'},
         'rows': ['LAB-021', 'LAB-018b', 'LAB-016b'], 'chain': {'slug': 'z8', 'phys': 'The junction of Majorana chains and the clock', 'math': 'The ℤ₈ of the junction and its names in the literature', 'learner': 'Chains that meet, and a count of eight'},
         'text': "A year after the table, the same author and Fidkowski found that interactions reduce the integer classification of time-reversal-invariant Majorana chains to a classification by eight, the first of the ℤ₈ invariants of interacting matter. On the labels the junction of two stacks of such chains carries a cell whose clock is the difference of their windings, and the degeneracy of the junction's ground state is computed from the clock alone; the names the literature gives the same eight — the bordism of pin-minus surfaces, the Brown invariant, the matching of the two time reversals with the two pin groups — are read, not computed, and said so."},
        {'id': 'k-next', 'lead': 'LNC-745', 'title': {'phys': 'Which class sits where: the open step', 'math': 'The match up to s ↦ 2 − s: the open step', 'learner': 'Which kind of matter is which cell: still open'},
         'rows': ['LNC-076c', 'LNC-081'], 'chain': {'slug': 'direction', 'phys': 'The match of the classes with the clock, up to a reflection', 'math': 'The commutants match the clock table up to s ↦ 2 − s', 'learner': 'The table matches the clock, but the direction is a choice'},
         'text': "Where the way stops: the symmetry algebras of the eight real classes have the commutants of the clock table, entry for entry, and the two complex classes give the complex numbers with one and two summands; but the match is fixed only up to the reflection that exchanges a clock value with its mirror, and its direction depends on how the Hamiltonian meets the two symmetries, which is an input the labels do not supply. Both facts are checked on exact numbers; which class sits at which clock value stays open."},
    ],
}


def main():
    for W in (W21.WEIL, W21.PENROSE):
        n = W21.write_way(W); print(W['route'], 'story rows', n[0], 'chains', n[1], 'placements', n[2])
    # Kitaev's way through the round-21 writer, with the round-22 story records (since v4.0, source round22:WP12)
    W21.story, W21.text = story, text
    n = W21.write_way(KITAEV); print(KITAEV['route'], 'story rows', n[0], 'chains', n[1], 'placements', n[2])
    ways = [   # in the reading order of the Atlas: the two steps that are ways, Calibration 2, Audit 3, then the three ways of 3.8.0 and 4.0.0
        {'key': 'baez', 'page': 'steps/baez', 'title': {'phys': "Baez's way: seven papers and the Atlas", 'math': "Baez's way: seven papers and the Atlas", 'learner': "Baez's way: seven papers"},
         'description': "Seven papers of John Baez and his co-authors read line by line against the labels: the octonions, the Standard Model's algebra, the division algebras and the Kepler problem, the ring of the E7 paper; step 19 of the Atlas.",
         'source': {'author': 'J. C. Baez and co-authors', 'title': 'Seven papers (the citations by arXiv number on the page)', 'year': None, 'link': 'https://arxiv.org/a/baez_j_1', 'locatorStyle': 'arXiv', 'citation': 'J. C. Baez and co-authors, seven papers, cited by arXiv number on the page steps/baez.'}},
        {'key': 'schuller', 'page': 'steps/schuller', 'title': {'phys': "Schuller's way: from the algebra to the dynamics", 'math': "Schuller's way: from the algebra to the dynamics, fibre and base", 'learner': "Schuller's way: lectures, read on the switches"},
         'description': "Frederic Schuller's lectures on geometric anatomy, quantum theory and constructive gravity read against the labels: the algebra, the bundle, the dynamics, fibre and base; step 20 of the Atlas.",
         'source': {'author': 'F. P. Schuller', 'title': 'Lectures on the Geometric Anatomy of Theoretical Physics; Lectures on Quantum Theory; Constructive Gravity', 'year': None, 'link': None, 'locatorStyle': '§', 'citation': 'F. P. Schuller, *Lectures on the Geometric Anatomy of Theoretical Physics*; *Lectures on Quantum Theory*; with Düll, Stritzelberger and Wolz, *Gravitational closure of matter field equations*, arXiv:1611.08878.'}},
        {'key': 'furey', 'page': 'matter', 'title': {'phys': "Furey's way: the Standard Model on the labels", 'math': "Furey's way: the Standard Model on the labels", 'learner': "Furey's way: particles on the switches"},
         'description': "Cohl Furey's construction of the Standard Model's algebra from the division algebras read against the labels: her blocks, hypercharges, ladders and the 16's weights recomputed (Calibration 2); what the labels do not reach — chirality, generations, masses — named as open.",
         'source': {'author': 'C. Furey', 'title': 'Standard model physics from an algebra? (and the papers the page cites)', 'year': 2016, 'link': 'https://arxiv.org/abs/1611.09182', 'locatorStyle': 'eq.', 'citation': 'C. Furey, *Standard model physics from an algebra?*, PhD thesis, Waterloo (2015), arXiv:1611.09182; and the papers the page matter/papers cites.'}},
        {'key': 'atiyah-moore', 'page': 'shifted', 'title': {'phys': "Atiyah's way: the shifted view", 'math': "Atiyah's way: the shifted view", 'learner': "Atiyah's way: the delayed waves"},
         'description': "Atiyah and Moore's paper taken step by step as the Atlas's third audit: a prologue, nine moves run on the labels, three questions left open at the end.",
         'source': {'author': 'M. Atiyah and G. W. Moore', 'title': 'A shifted view of fundamental physics', 'year': 2010, 'link': 'https://arxiv.org/abs/1009.3176', 'locatorStyle': 'eq.', 'citation': 'M. Atiyah and G. W. Moore, *A shifted view of fundamental physics*, Surveys in Differential Geometry 15 (2010), 1–15; Atiyah\'s Collected Works, vol. 7.'}},
        {'key': 'weil', 'page': 'ways/weil', 'title': W21.WEIL['title'],
         'description': "The 1964 memoir on unitary operators taken number by number, a cell's labels standing in for the locally compact group: the index is the clock, the automorphisms are Clifford gates, the theta functions are stabilizer states, Theorem 5's subgroups are codes, the genus average closes it; and where the labels stop.",
         'source': {'author': 'A. Weil', 'title': "Sur certains groupes d'opérateurs unitaires", 'year': 1964, 'link': 'https://doi.org/10.1007/BF02391012', 'locatorStyle': 'n°', 'citation': "A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964), 143–211."}},
        {'key': 'penrose', 'page': 'ways/penrose', 'title': W21.PENROSE['title'],
         'description': "The review of twistor theory at fifty read with the Atlas's method: twistor space from the conformal cell, the incidence relation on exact numbers, the integral formulae as residues, the Lax pair in the review's coordinates; then the passes the programme plans next.",
         'source': {'author': 'M. Atiyah, M. Dunajski and L. J. Mason', 'title': 'Twistor theory at fifty: from contour integrals to twistor strings', 'year': 2017, 'link': 'https://doi.org/10.1098/rspa.2017.0530', 'locatorStyle': '§', 'citation': 'M. Atiyah, M. Dunajski and L. J. Mason, *Twistor theory at fifty: from contour integrals to twistor strings*, Proc. R. Soc. A 473 (2017), 20170530.'}},
        {'key': 'kitaev', 'page': 'ways/kitaev', 'title': KITAEV['title'],
         'description': "The periodic table of free-fermion matter read on the labels: the symmetry algebra of each class as a cell, the extension problem run as written, the K-theory of a point as the clock, the eightfold way of Majorana chains computed at a junction; and the open step, which class sits at which clock value.",
         'source': {'author': 'A. Kitaev', 'title': 'Periodic table for topological insulators and superconductors', 'year': 2009, 'link': 'https://arxiv.org/abs/0901.2686', 'locatorStyle': '§', 'citation': 'A. Kitaev, *Periodic table for topological insulators and superconductors*, AIP Conf. Proc. 1134 (2009), 22–30; arXiv:0901.2686.'}},
    ]
    W21.save(os.path.join(ROOT, 'content', 'ways.json'), json.dumps(ways, ensure_ascii=False, indent=1) + '\n')


if __name__ == '__main__':
    main()
