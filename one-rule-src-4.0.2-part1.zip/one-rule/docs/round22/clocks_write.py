#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round22/clocks_write.py — the page "The three clocks" (4.0.0, D95; docs/round20/PLAN.md §4 WP9): mod 2, mod 4 and mod 8 as the organising
chapter of the algebra part. Three new statement rows join the base tables (content/rows.json, content/texts.json; since v4.0, source round22:WP9;
each computed by checks/selfcheck/round22/three_clocks.py, registered in content/checks.json and content/check_runs.json; their homes on the clock
page after LAB-039, the clocks page tells them): LAB-040, the two polar
forms (w refines the dot product, Q the commutation form); LAB-041, the Arf invariant of the descended form as the mod-2 shadow of the clock;
LAB-042, the clocks add under the orthogonal sum, the finite instance of Brown's theorem. The page is a page of the chains overlay
(content/chains/clocks/): three sections, mod 2, mod 4, mod 8, each with a lead story row and one or two chains that tell rows kept at their
homes (placements of order 2000 and more; the three new rows have their homes here). Idempotent. Then: node docs/round20/rejoin.mjs --relink <the
chains>, npm run content twice.
Usage: python3 docs/round22/clocks_write.py"""
import importlib.util, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
_spec = importlib.util.spec_from_file_location('ways21', os.path.join(ROOT, 'docs', 'round21', 'ways_write.py'))
W21 = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(W21)
SRC = 'round22:WP9'
SCRIPT = 'checks/selfcheck/round22/three_clocks.py'


def load(rel):
    with open(os.path.join(ROOT, rel), encoding='utf-8') as f: return json.load(f)


def story(rid, page, section, role, order, restates):
    r = W21.story(rid, 'LAB', page, section, role, order, restates)
    r['since'] = 'v4.0'; r['source'] = SRC
    return r


def text(rid, body):
    t = W21.text(rid, body); t['source'] = SRC
    return t


# ---------------------------------------------------------------- the three new rows (the base tables)
HOME = {'LAB-040': ('clock', 42), 'LAB-041': ('clock', 43), 'LAB-042': ('clock', 44)}   # the home of each new row: the clock page's section clock, after LAB-039 (41); the clocks page tells them


def row(rid, kind, notions, cells, home_phys, home_math, evidence, depends, standard_ref, ptype='identity', fields=('algebra',)):
    return {'id': rid, 'group': 'LAB', 'standardRef': standard_ref, 'links': [], 'lensTags': [], 'evidence': evidence, 'depends': depends, 'notions': notions,
            'kind': kind, 'stage': 'A', 'ptype': ptype, 'review': None, 'notesPersona': [], 'phenomena': [], 'fields': list(fields), 'cells': cells,
            'homePhys': home_phys, 'homeMath': home_math, 'tabV15': None, 'anchorV15': None, 'theorems': [], 'readingRefs': 0, 'v16': [], 'since': 'v4.0',
            'legacyLabel': None, 'legacyFlags': [], 'legacyKnown': False, 'legacyLines': 0, 'splitFrom': None, 'visibleTo': ['phys', 'math'],
            'shownOn': [{'page': 'clock', 'section': HOME[rid][0], 'order': HOME[rid][1], 'role': 'detail'}], 'labelFrom': None, 'source': SRC}


EV = lambda k: {'check': f'tc.{k}', 'script': SCRIPT, 'mode': 'ran'}
NEW_ROWS = [
    (row('LAB-040', 'lemma', ['lbl', 'sgn', 'sq', 'grd', 'qf', 'clk', 'fin'], ['(p,q,0), every n: the derivation', '(p,q,0), n ≤ 8: the check on every pair of labels (n ≤ 6) or 65536 pairs (n = 7, 8)'],
         'the two forms the clock rests on: w = π + 2Q sees the graded algebra (its polar form is the dot product, the Koszul sign), Q alone sees the ungraded one (its polar form is the commutation form), which is why Q fixes the clock only up to c ↔ 2 − c',
         'the ℤ₄-form w = π + 2Q is a quadratic refinement of the dot product a·b, while Q is an 𝔽₂-quadratic form whose polar form is the commutation form β(a,b) = |a||b| + a·b; the two bilinear forms differ on every cell with n ≥ 2',
         [EV('K1')], [{'id': 'LAB-017', 'rel': 'derives'}, {'id': 'LAB-019', 'rel': 'derives'}, {'id': 'LNC-120', 'rel': 'derives'}],
         'R. C. Kirby, L. R. Taylor, Pin structures on low-dimensional manifolds (1990), §3 (a ℤ₄-enhancement is a quadratic refinement of the intersection form; read); E. H. Brown, Generalizations of the Kervaire invariant, Ann. Math. 95 (1972) (read at statement level); the round-20 review of the Atlas, F.1 (the two polar forms named)', 'identity', ('algebra',)),
     "The two polar forms. The ℤ₄-form w(a) = π(a) + 2Q(a) of the labels (LAB-017: π the parity, Q(a) = [e_a² = −1]) and the 𝔽₂-form Q refine two different bilinear forms, and the Atlas names both. For every n: w(a ⊕ b) − w(a) − w(b) = 2 a·b mod 4, with a·b = |a ∧ b| mod 2 the dot product of the bit vectors — so w is a quadratic refinement of the dot product, the form that sees the ℤ₂-grading (the Koszul sign of disjoint labels, LNC-120); and Q(a ⊕ b) + Q(a) + Q(b) = β(a,b) = |a||b| + a·b mod 2, the commutation form (e_a e_b = (−1)^{β(a,b)} e_b e_a) — so Q is an 𝔽₂-quadratic form whose polar form sees the ungraded algebra. Derivation for every n: π(a ⊕ b) − π(a) − π(b) = −2π(a)π(b) as integers, and e_{a⊕b}² = (−1)^{β(a,b)} e_a² e_b² gives Q(a ⊕ b) = Q(a) + Q(b) + β(a,b) mod 2; adding, −2π(a)π(b) + 2|a||b| + 2 a·b = 2 a·b mod 4. Checked on every cell Cl(p,q) with n ≤ 8 (44 cells; every pair of labels for n ≤ 6, 65536 pairs per cell for n = 7 and 8), and that the two bilinear forms differ on some pair in every cell with n ≥ 2 (tc.K1). This is why Q alone fixes the clock only up to c ↔ 2 − c (LAB-019): the commutation form is the ungraded algebra's, the dot product the graded one's."),
    (row('LAB-041', 'range', ['lbl', 'sq', 'grd', 'qf', 'clk', 'fin', 's-alg'], ['(p,q,0), n even, n ≤ 8, p − q ≡ 0 mod 4: 12 cells, computed', 'every even n with p − q ≡ 0 mod 4: the Arf invariant of the descended form, recalled'],
         'the mod-2 shadow of the clock: when the top label squares to +1 the ℤ₄-form descends to an 𝔽₂-quadratic form on the even labels modulo the top one, and its Arf invariant is the clock divided by four, 0 at clock 0 and 1 at clock 4 — the mod-2 level of the hierarchy mod 2 → mod 4 → mod 8',
         'for n even with ω² = +1 (c ≡ 0 mod 4) w vanishes on F = 1…1, q = w/2 = Q is an 𝔽₂-quadratic form on F^⊥/⟨F⟩ (dimension n − 2) and Arf(q) = c/4 mod 2: plus type at c = 0, minus type at c = 4',
         [EV('K2')], [{'id': 'LAB-040', 'rel': 'derives'}, {'id': 'LAB-017', 'rel': 'derives'}, {'id': 'LAB-035', 'rel': 'derives'}, {'id': 'T9', 'rel': 'instance'}],
         'D. E. Taylor, The Geometry of the Classical Groups (1992), the chapter on quadratic forms over 𝔽₂ (the Arf invariant and the type of a quadratic form; read at statement level); R. C. Kirby, L. R. Taylor, Pin structures on low-dimensional manifolds (1990), §3 (read); the round-20 review of the Atlas, F.1', 'identity', ('algebra', 'topology')),
     "The Arf invariant as the mod-2 shadow of the clock. For a cell Cl(p,q) with n even and ω² = +1, that is c = p − q ≡ 0 mod 4, the ℤ₄-form w vanishes on the top label F = 1…1 (w(F) = n mod 2 + 2[ω² = −1] = 0), so w is even on F^⊥, the labels of even weight, and q = w/2 = Q descends to an 𝔽₂-quadratic form on F^⊥/⟨F⟩, of dimension n − 2, whose polar form is the dot product there. Its Arf invariant is the clock divided by four: Arf(q) = c/4 mod 2 — the form is of plus type at c = 0 and of minus type at c = 4. Computed exactly on the 12 cells with n ≤ 8, n even and p − q ≡ 0 mod 4 (tc.K2: Cl(1,1), Cl(0,4), Cl(2,2), Cl(4,0), Cl(1,5), Cl(3,3), Cl(5,1), Cl(0,8), Cl(2,6), Cl(4,4), Cl(6,2), Cl(8,0); the Arf invariant read as the majority value of q); for every even n it is the statement that the Brown invariant of w reduces mod 2 to the Arf invariant of the descended form, recalled (Kirby–Taylor §3; Taylor). It is what makes the count of self-dual codes of labels work (LAB-035, T9(f)): the codes are the maximal totally singular subspaces of q, which exist exactly in the plus type, c ≡ 0 mod 8."),
    (row('LAB-042', 'reduction', ['lbl', 'sq', 'grd', 'qf', 'clk', 'tns', 'fin', 's-alg', 's-geo'], ['(p,q,0) × (p′,q′,0), n, n′ ≤ 4: 196 pairs, computed', 'every pair of ℤ₄-forms: Brown\'s theorem, recalled'],
         'why the clocks add: the orthogonal sum of two cells\' forms is the form of their graded product, and the Brown invariant of an orthogonal sum is the sum of the invariants — Brown\'s theorem that the invariant is an isomorphism from the Witt group of ℤ₄-forms to ℤ₈ is the structural reason behind the addition of the clocks under concatenation',
         'the Brown invariant β: W(ℤ₄-quadratic forms on 𝔽₂-spaces) → ℤ₈ is an isomorphism of groups (Brown 1972); on the labels, the form of Cl(p,q) ⊗̂ Cl(p′,q′) is the orthogonal sum w ⊥ w′ and β(w ⊥ w′) = β(w) + β(w′) mod 8, computed on 196 pairs of cells with n, n′ ≤ 4',
         [EV('K3')], [{'id': 'LAB-018', 'rel': 'derives'}, {'id': 'LNC-035', 'rel': 'instance'}, {'id': 'LAB-017', 'rel': 'derives'}, {'id': 'GEN-013', 'rel': 'derives'}],
         'E. H. Brown, Generalizations of the Kervaire invariant, Ann. Math. 95 (1972) 368–383 (the Brown invariant is an isomorphism W(ℤ₄-forms) → ℤ₈; read at statement level); R. C. Kirby, L. R. Taylor, Pin structures on low-dimensional manifolds (1990), §3 (read); L. R. Taylor, Gauss sums in algebra and topology (the Gauss sum as the invariant; read at statement level)', 'identity', ('algebra', 'topology')),
     "The clocks add: Brown's theorem on the labels. Brown's theorem (1972) says that the Brown invariant β, the phase of the Gauss sum Σ_a i^{w(a)} = 2^{n/2} e^{iπβ/4}, is an isomorphism from the Witt group of ℤ₄-valued quadratic forms on 𝔽₂-spaces to ℤ₈: additive under the orthogonal sum, zero exactly on the forms Witt-equivalent to zero; recalled, not proved here. On the labels the orthogonal sum is the graded tensor product (LNC-035): the form of the concatenated cell Cl(p+p′, q+q′), the generators of the first cell first, is w(a) + w′(b) on the label (a, b), and its Gauss sum is the product of the two Gauss sums, so the clock of the concatenation is c + c′ mod 8 — the addition of the clocks (LAB-017, LAB-018) is the additivity of the Brown invariant, and the period eight of the type table (GEN-013) is the order of ℤ₈. Computed exactly on the 196 pairs of cells with n, n′ ≤ 4 (tc.K3: the concatenated form, its Gauss sum as the product, its phase as the sum of the clocks)."),
]

# ---------------------------------------------------------------- the page
CLOCKS = {
    'route': 'clocks', 'key': 'clocks', 'folder': 'clocks', 'after': 'clock', 'needs': ['clock', 'rule'],
    'title': {'phys': 'The three clocks: mod 2, mod 4, mod 8', 'math': 'The three clocks: ℤ₂, ℤ₄, ℤ₈', 'learner': 'Three clocks: two, four and eight hours'},
    'hero': {'row': 'LAB-042', 'figure': None},
    'learnerFrame': {'h': 'Three clocks: two, four and eight hours', 'before': 'The clock page counted the cells in eighths of a turn. This page shows that there are three clocks, one inside the other: a clock with two hours, a clock with four, and the clock with eight, and why the big clock adds up when two cells are put together.', 'after': 'Next: light, the first warm-up.', 'tags': []},
    'intro': ('LAB-761', ['LAB-040', 'LAB-041', 'LAB-042'], "The three clocks. The algebra of the labels is organised by three counts, one inside the other: the parity of a label, mod 2; the ℤ₄-form w that refines the dot product, mod 4; and the clock, the Brown invariant of w, mod 8. Each level has its own objects — the grading and the Koszul sign, then the quadratic refinement and the characters of the second degree, then the Gauss sum, the index and the period of the type table — and each level is the shadow of the next: the Arf invariant of the descended form is the clock divided by four, and the clock is the class of w in Brown's Witt group. The page tells the three levels in that order, with the rows of the clock page, the category page and the finite groups page kept at their homes, and three rows of its own: the two polar forms the clock rests on, the Arf invariant as the mod-2 shadow, and Brown's theorem as the reason the clocks add."),
    'sections': [
        {'id': 'm2', 'lead': 'LAB-771', 'title': {'phys': 'Mod 2: parity, the grading and its shadow', 'math': 'Mod 2: the ℤ₂-grading, the Koszul sign, the Arf invariant', 'learner': 'The two-hour clock: even and odd'},
         'chains': [{'slug': 'parity', 'phys': 'The grading, its sign and the two bilinear forms', 'math': 'The ℤ₂-grading, the Koszul sign and the two polar forms', 'learner': 'Even and odd, and two ways to compare labels', 'rows': ['LNC-120', 'GEN-010', 'LAB-040']},
                    {'slug': 'arf', 'phys': 'The Arf invariant as the shadow of the clock', 'math': 'The Arf invariant of the descended form is c/4', 'learner': 'What the two-hour clock remembers of the eight-hour one', 'rows': ['LAB-041', 'LAB-035']}],
         'text': "At the first level a label is even or odd. The parity is the ℤ₂-grading of the cell, and the sign a pair of disjoint labels picks up when they are swapped is the Koszul sign of that grading — the exchange sign of fermions, in physics. Two bilinear forms live here, and the Atlas names both: the dot product of the bit vectors, which the grading sees, and the commutation form, which says whether two labels commute or anticommute and which the ungraded algebra sees. The parity, refined by the square of a label, is the ℤ₄-form of the next level; and when the top label squares to plus one the ℤ₄-form descends to a form over two elements whose Arf invariant is the clock divided by four — the shadow mod 2 of the clock, and the reason the self-dual codes of labels exist only at clock zero."},
        {'id': 'm4', 'lead': 'LAB-772', 'title': {'phys': 'Mod 4: the ℤ₄-form and its index', 'math': 'Mod 4: the ℤ₄-form w = π + 2Q', 'learner': 'The four-hour clock: the form that counts the squares'},
         'chains': [{'slug': 'form', 'phys': 'The ℤ₄-form as a charge, a frame and a theta law', 'math': 'w = π + 2Q as a charge, frame data and a theta law', 'learner': 'The four-hour count and its rules', 'rows': ['CAND-057', 'LAB-022', 'LAB-024', 'ATY-033', 'LAB-028']},
                    {'slug': 'signs', 'phys': 'The grade-dependent signs and the ℤ₄-enhancements', 'math': 'The grade signs of period four; ℤ₄-enhancements', 'learner': 'Flipping a label: two signs with period four', 'rows': ['INP-019', 'LAB-018b']}],
         'text': "At the second level the parity is refined by the square of a label: the form w of the labels, the parity plus twice the square's sign, takes its values in the integers mod 4. On a diagonal cell it is a charge, the sum over the generators of a label of one for a square plus one and three for a square minus one; on disjoint labels it adds, which singles out a frame; it is self-dual under the Walsh transform, the finite theta law; and it is Weil's character of the second degree on the labels, whose index is the clock. The signs of reversion and of conjugation, which depend on the grade of a label with period four, live here too, and so does the identification of such a refinement of an intersection form with a pin-minus structure on a surface, read in the literature and said so."},
        {'id': 'm8', 'lead': 'LAB-773', 'title': {'phys': 'Mod 8: the clock, its names and why it adds', 'math': 'Mod 8: the Brown invariant, the Witt group and the period', 'learner': 'The eight-hour clock, and why it adds up'},
         'chains': [{'slug': 'clock', 'phys': 'The clock as the Brown invariant of w', 'math': 'The Gauss sum, the Brown invariant, the triple (V, Q, π)', 'learner': 'The eight-hour clock and its three names', 'rows': ['LAB-017', 'LAB-023', 'LAB-019', 'LAB-025', 'CAND-091', 'LAB-031']},
                    {'slug': 'witt', 'phys': 'Why the clocks add, and the period eight', 'math': 'The Witt group of ℤ₄-forms and the period of the type table', 'learner': 'Putting two cells together adds their clocks', 'rows': ['LAB-042', 'LAB-021', 'GEN-009', 'GEN-013', 'ATY-001', 'LAB-016b']}],
         'text': "At the third level the form w is summed: its Gauss sum has modulus a power of two and a phase that is an eighth root of unity, the clock, which is the Brown invariant of w, Weil's index of the cell, and the one invariant that, with the parity of the number of generators, fixes the triple of the labels, their squares and their parities up to isomorphism. The structural reason the clocks add when two cells are put together is Brown's theorem: the invariant is an isomorphism from the Witt group of forms mod 4 to the integers mod 8, so the orthogonal sum of two forms, which is the form of the graded product, has the sum of the two clocks. The same eight is the period of the type table, the degeneracy of a junction of Majorana chains, and, read in the literature and said so, the matching of the two time reversals with the two pin groups."},
    ],
}


def write_rows():
    rows = load('content/rows.json'); texts = load('content/texts.json')
    by = {r['id']: i for i, r in enumerate(rows)}
    changed = 0
    for rec, body in NEW_ROWS:
        rid = rec['id']
        if rid in by:
            # the merge adds the placements of the pages that tell the row (shownOn beyond its home): kept when the home is the same
            cur = rows[by[rid]]; same_home = cur.get('shownOn') and rec['shownOn'] and cur['shownOn'][0] == rec['shownOn'][0]
            want = dict(rec, shownOn=cur['shownOn']) if same_home else rec
            if cur != want: rows[by[rid]] = want; changed += 1
        else:
            # after the last LAB row
            last = max(i for i, r in enumerate(rows) if r['group'] == 'LAB')
            rows.insert(last + 1, rec); by = {r['id']: i for i, r in enumerate(rows)}; changed += 1
        t = {'row': rid, 'lang': 'en', 'mode': 'both', 'level': 'research', 'lens': None, 'register': 'full', 'body': body, 'status': 'draft', 'source': SRC}
        i = next((k for k, x in enumerate(texts) if x['row'] == rid and x['level'] == 'research' and x.get('lens') is None and x.get('chain') is None), None)
        if i is None: texts.append(t); changed += 1
        elif texts[i] != t: texts[i] = t; changed += 1
    if changed:
        W21.save(os.path.join(ROOT, 'content', 'rows.json'), json.dumps(rows, ensure_ascii=False, indent=1) + '\n')
        W21.save(os.path.join(ROOT, 'content', 'texts.json'), json.dumps(texts, ensure_ascii=False, indent=1) + '\n')
    else: print('unchanged content/rows.json, content/texts.json (the three rows)')
    # the check and its run
    checks = load('content/checks.json'); runs = load('content/check_runs.json')
    entry = {'id': 'selfcheck/round22/three_clocks.py', 'family': 'round22', 'script': SCRIPT,
             'ids': [{'id': 'tc.K1', 'statement': 'the polar form of w = π + 2Q is the dot product and that of Q the commutation form, on every cell with n ≤ 8; the two differ on every cell with n ≥ 2'},
                     {'id': 'tc.K2', 'statement': 'for n even with p − q ≡ 0 mod 4, w vanishes on the top label, q = Q descends to F^⊥/⟨F⟩ and Arf(q) = c/4 mod 2 (12 cells, n ≤ 8)'},
                     {'id': 'tc.K3', 'statement': 'the form of the concatenated cell is the orthogonal sum, its Gauss sum the product, its clock c + c′ mod 8 (196 pairs, n, n′ ≤ 4)'}],
             'what': 'LAB-040, LAB-041, LAB-042: the three clocks of the labels — the two polar forms (K1), the Arf invariant of the descended form as c/4 (K2), the clocks add under the orthogonal sum (K3); 2,319,396 checks',
             'method': 'an own bit-rule kernel (e_a² and the commutation sign from the bits); exact integers; every pair of labels for n ≤ 6 and 65536 sampled pairs per cell for n = 7, 8; the Arf invariant as the majority value; the Gauss sum as integer pairs',
             'independentRoute': 'no (the forms are computed from the bits as defined)', 'controls': 'yes: --fault POLAR, ARF, ADD, each wrong version exits 1 (logs/three_clocks.faults.log)',
             'deps': 'none (pure Python)', 'storedResult': None, 'log': 'checks/selfcheck/round22/logs/three_clocks.log', 'rowsNaming': ['LAB-040', 'LAB-041', 'LAB-042'],
             'notes': 'round 22 (release 4.0.0): the page of the three clocks (D95)', 'since': 'v4.0'}
    i = next((k for k, c in enumerate(checks) if c.get('id') == entry['id']), None)
    if i is None: checks.append(entry)
    else: checks[i] = entry
    W21.save(os.path.join(ROOT, 'content', 'checks.json'), json.dumps(checks, ensure_ascii=False, indent=1) + '\n')
    run = {'script': SCRIPT, 'date': '2026-10-22', 'machine': 'round 22 release run (4.0.0), from the script\'s own folder', 'ok': None, 'fail': 0,
           'lastLine': 'ALL OK: 2319396 checks (K1 the two polar forms, K2 the Arf invariant as c/4, K3 the clocks add)', 'passed': True, 'seconds': 3.3,
           'status': 'pass (-I -B from its folder; 3 --fault runs each exit 1); about 3.3 s alone', 'source': 'checks/selfcheck/round22/logs/three_clocks.log'}
    j = next((k for k, r in enumerate(runs) if r.get('script') == SCRIPT), None)
    if j is None: runs.append(run)
    else: runs[j] = run
    W21.save(os.path.join(ROOT, 'content', 'check_runs.json'), json.dumps(runs, ensure_ascii=False, indent=1) + '\n')


def write_page():
    W = CLOCKS; page, key = W['route'], W['key']
    intro_id, intro_restates, intro_text = W['intro']
    rows = [story(intro_id, page, 'intro', 'lead', 0, intro_restates)]
    texts = [text(intro_id, intro_text)]
    sections, chains, layout = [], [], []
    order = 2000
    own = set()   # every row the page tells keeps its home elsewhere (the three new rows on the clock page): all are placed by the layout
    for s in W['sections']:
        lead_rows = [r for c in s['chains'] for r in c['rows']]
        rows.append(story(s['lead'], page, s['id'], 'lead', 0, lead_rows))
        texts.append(text(s['lead'], s['text']))
        sections.append({'id': s['id'], 'title': s['title'], 'lead': s['lead']})
        for k, c in enumerate(s['chains']):
            chains.append(W21.chain(page, key, s['id'], k + 1, c, c['rows']))
            for rid in c['rows']:
                if rid in own: continue   # a row of this page: placed by the base table (its home), not by the layout
                order += 1
                layout.append({'row': rid, 'page': page, 'section': s['id'], 'order': order, 'role': 'result', 'add': True})
    entry = {'route': page, 'page': {'title': W['title'], 'after': W['after'], 'needs': W['needs'], 'learnerFrame': W['learnerFrame'], 'connective': {}},
             'hero': W['hero'], 'intro': {'lead': intro_id}, 'parts': [], 'sections': sections}
    folder = os.path.join(ROOT, 'content', 'chains', W['folder'])
    os.makedirs(folder, exist_ok=True)
    out = {'page.json': {'pages': [entry], 'layout': layout}, 'rows.json': rows, 'texts.json': texts}
    for name, data in out.items():
        W21.save(os.path.join(folder, name), json.dumps(data, ensure_ascii=False, indent=1) + '\n')
    cf = os.path.join(folder, 'chains.json')
    if os.path.exists(cf):
        old = json.load(open(cf, encoding='utf-8'))
        for c in chains:
            o = next((x for x in old if x['id'] == c['id']), None)
            if o and o['rows'] == c['rows']: c['links'], c['shape'], c['joins'] = o['links'], o['shape'], o['joins']
    W21.save(cf, W21.dump_chains(chains))
    print(page, 'story rows', len(rows), 'chains', len(chains), 'placements', len(layout))


if __name__ == '__main__':
    write_rows(); write_page()
