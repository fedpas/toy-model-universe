#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round22/calib4_write.py — Three measured numbers, hydrogen, Mercury and Gravity Probe B (4.0.0, D89, titled "Calibration 4" in the plan; docs/round20/PLAN.md §4 WP15b). The engine's closed forms
(CAND-013 the Sommerfeld–Dirac energies, CAND-118 the periastron advance, CAND-128 the geodetic precession) evaluated on the inputs their sources
state and compared with the measured values: hydrogen's 2P fine-structure interval, Mercury's perihelion, Gravity Probe B's geodetic drift; and
Kitaev's table as a known answer beside them. What joins the base tables (content/rows.json, texts.json, sources.json, checks.json,
check_runs.json; since v4.0, source round22:WP15): ten input rows (INP-098 to INP-107: the constants, the orbits, the measured values and the
published table, each with its source and its reason), and three comparison rows (CPL-013, GRV-013, NUL-013: the engine's number against the
measured one, computed by checks/selfcheck/round22/calibration4.py), at their homes on the step pages. The page calib4 is a page of the chains
overlay (content/chains/calib4/): four sections, each a chain "the inputs · the engine's number · the measured value · the match", the rows kept
at their homes; anchored after matter (a base page: the merge joins the overlay folders in their sorted order, and shifted, which calib4 follows in
the reading order, is an overlay page joined later and inserted before it). Idempotent. Then: node docs/round20/rejoin.mjs --relink <the chains>, npm run content twice.
Usage: python3 docs/round22/calib4_write.py"""
import importlib.util, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
_spec = importlib.util.spec_from_file_location('ways21', os.path.join(ROOT, 'docs', 'round21', 'ways_write.py'))
W21 = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(W21)
SRC = 'round22:WP15'
SCRIPT = 'checks/selfcheck/round22/calibration4.py'


def load(rel):
    with open(os.path.join(ROOT, rel), encoding='utf-8') as f: return json.load(f)


def story(rid, page, section, role, order, restates):
    r = W21.story(rid, 'GRV', page, section, role, order, restates)
    r['since'] = 'v4.0'; r['source'] = SRC
    return r


def text(rid, body):
    t = W21.text(rid, body); t['source'] = SRC
    return t


def base_row(rid, group, kind, stage, ptype, notions, cells, phenomena, fields, home_phys, evidence, depends, standard_ref, shown, extra=None):
    r = {'id': rid, 'group': group, 'standardRef': standard_ref, 'links': [], 'lensTags': [], 'evidence': evidence, 'depends': depends, 'notions': notions,
         'kind': kind, 'stage': stage, 'ptype': ptype, 'review': None, 'notesPersona': [], 'phenomena': phenomena, 'fields': fields, 'cells': cells,
         'homePhys': home_phys, 'homeMath': '', 'tabV15': None, 'anchorV15': None, 'theorems': [], 'readingRefs': 0, 'v16': [], 'since': 'v4.0',
         'legacyLabel': None, 'legacyFlags': [], 'legacyKnown': False, 'legacyLines': 0, 'splitFrom': None, 'visibleTo': ['phys', 'math'],
         'shownOn': shown, 'labelFrom': None, 'source': SRC}
    if extra: r.update(extra)
    return r


def inp(rid, page, order, standard_ref, home, why, phenomena, body):
    return (base_row(rid, 'INP', 'definition', 'O', 'postulate', ['src', 'i-tab'], ['(1,3,0)'], phenomena, ['geometry'], home, [], [], standard_ref,
                     [{'page': page, 'section': 'needs', 'order': order, 'role': 'detail'}],
                     {'inputKind': 'data', 'inputKindName': 'imported data', 'reason': {'kind': 'input', 'why': why, 'from': SRC}}), body)


EV = lambda k: {'check': f'c4.{k}', 'script': SCRIPT, 'mode': 'ran'}
CODATA = 'CODATA 2018 recommended values of the fundamental physical constants (E. Tiesinga, P. J. Mohr, D. B. Newell, B. N. Taylor, Rev. Mod. Phys. 93 (2021) 025010; read at statement level)'
NEW_ROWS = [
    inp('INP-098', 'steps/coupling', 26, CODATA + ': α = 7.297 352 5693 × 10⁻³', 'the fine-structure constant, α = 7.2973525693 × 10⁻³ (CODATA 2018)',
        'The fine-structure constant is an input as its source states it (CODATA 2018); no computation on the labels gives it.', ['electron', 'qm'],
        'The fine-structure constant is an input, as its source states it: α = 7.297 352 5693 × 10⁻³ (CODATA 2018). The page of three measured numbers evaluates the Sommerfeld–Dirac energies of CAND-013 on it; no computation on the labels gives it.'),
    inp('INP-099', 'steps/coupling', 27, CODATA + ': m_e c² = 510 998.950 00 eV, m_p/m_e = 1836.152 673 43, h = 4.135 667 696 × 10⁻¹⁵ eV s (exact)', 'the electron\'s mass energy, the proton–electron mass ratio and Planck\'s constant (CODATA 2018)',
        'The electron\'s mass, the proton–electron mass ratio and Planck\'s constant are inputs as their source states them (CODATA 2018); no computation on the labels gives them.', ['electron', 'qm'],
        'The electron\'s mass energy, the proton–electron mass ratio and Planck\'s constant are inputs, as their source states them: m_e c² = 510 998.950 00 eV, m_p/m_e = 1836.152 673 43, h = 4.135 667 696 × 10⁻¹⁵ eV s (CODATA 2018). The page of three measured numbers uses the reduced mass of the electron in hydrogen and converts energies to frequencies with them; no computation on the labels gives them.'),
    inp('INP-104', 'steps/coupling', 28, 'E. W. Hagley, F. M. Pipkin, Separated oscillatory field measurement of hydrogen 2S₁/₂–2P₃/₂ fine structure interval, Phys. Rev. Lett. 72 (1994) 1172: 9911.200(12) MHz; S. R. Lundeen, F. M. Pipkin, Measurement of the Lamb shift in hydrogen, n = 2, Phys. Rev. Lett. 46 (1981) 232: 1057.845(9) MHz (both read at statement level)', 'the measured 2P₃/₂ − 2P₁/₂ interval of hydrogen, 10 969.045(15) MHz, the sum of the two measured intervals',
        'The measured fine-structure interval of hydrogen is an input as its sources state it (Hagley and Pipkin 1994; Lundeen and Pipkin 1981); it is what the page of three measured numbers compares with.', ['electron', 'qm'],
        'The measured 2P₃/₂ − 2P₁/₂ interval of hydrogen is an input, as its sources state it: the 2S₁/₂–2P₃/₂ interval 9911.200(12) MHz (Hagley and Pipkin, 1994) plus the Lamb shift 2S₁/₂–2P₁/₂ = 1057.845(9) MHz (Lundeen and Pipkin, 1981), 10 969.045(15) MHz in all. the page of three measured numbers compares the Sommerfeld–Dirac interval of CAND-013 with it (CPL-013).'),
    inp('INP-100', 'steps/grav2', 25, 'IAU 2015 Resolution B3, nominal solar mass parameter GM_⊙ = 1.327 124 4 × 10²⁰ m³ s⁻² (the DE430 value 1.327 124 400 41 × 10²⁰ used; read at statement level); the speed of light c = 299 792 458 m/s (exact)', 'the Sun\'s gravitational parameter GM_⊙ = 1.327 124 400 41 × 10²⁰ m³ s⁻² and the speed of light',
        'The Sun\'s gravitational parameter and the speed of light are inputs as their sources state them (IAU 2015; the SI); no computation on the labels gives them.', ['gravity'],
        'The Sun\'s gravitational parameter is an input, as its source states it: GM_⊙ = 1.327 124 400 41 × 10²⁰ m³ s⁻² (IAU 2015 nominal value, DE430), with the speed of light c = 299 792 458 m/s. The page of three measured numbers evaluates the periastron advance of CAND-118 with it (GRV-013); no computation on the labels gives it.'),
    inp('INP-101', 'steps/grav2', 26, 'JPL Solar System Dynamics, Keplerian elements for approximate positions of the planets (J2000 epoch; read at statement level): Mercury a = 0.387 099 27 au; the astronomical unit 149 597 870 700 m (IAU 2012, exact)', 'Mercury\'s semi-major axis, a = 0.387 099 27 au (JPL, J2000)',
        'Mercury\'s semi-major axis is an input as its source states it (JPL Keplerian elements, J2000); no computation on the labels gives it.', ['gravity'],
        'Mercury\'s semi-major axis is an input, as its source states it: a = 0.387 099 27 au, the astronomical unit 149 597 870 700 m (JPL Keplerian elements, J2000; IAU 2012). The page of three measured numbers evaluates the periastron advance of CAND-118 with it, and takes the period from Kepler\'s third law (GRV-013); no computation on the labels gives it.'),
    inp('INP-102', 'steps/grav2', 27, 'JPL Solar System Dynamics, Keplerian elements for approximate positions of the planets (J2000 epoch; read at statement level): Mercury e = 0.205 635 93', 'Mercury\'s eccentricity, e = 0.205 635 93 (JPL, J2000)',
        'Mercury\'s eccentricity is an input as its source states it (JPL Keplerian elements, J2000); no computation on the labels gives it.', ['gravity'],
        'Mercury\'s eccentricity is an input, as its source states it: e = 0.205 635 93 (JPL Keplerian elements, J2000). The page of three measured numbers evaluates the periastron advance of CAND-118 with it (GRV-013); no computation on the labels gives it.'),
    inp('INP-105', 'steps/grav2', 28, 'C. M. Will, The confrontation between general relativity and experiment, Living Rev. Relativ. 17 (2014) 4, §4.3 (read at statement level): the relativistic part of the observed advance of Mercury\'s perihelion, 42.98 ± 0.04 arcseconds per century (radar ranging)', 'the measured relativistic advance of Mercury\'s perihelion, 42.98 ± 0.04 arcseconds per century',
        'The measured advance of Mercury\'s perihelion is an input as its source states it (Will 2014, §4.3); it is what the page of three measured numbers compares with.', ['gravity'],
        'The relativistic part of the observed advance of Mercury\'s perihelion is an input, as its source states it: 42.98 ± 0.04 arcseconds per century, from radar ranging, the Newtonian perturbations of the other planets and the solar quadrupole removed (Will, Living Reviews in Relativity 17 (2014), §4.3). the page of three measured numbers compares the advance of CAND-118 with it (GRV-013).'),
    inp('INP-103', 'steps/nullsurf', 32, 'IAU 2015 Resolution B3, nominal terrestrial mass parameter GM_⊕ = 3.986 004 × 10¹⁴ m³ s⁻² (read at statement level); C. W. F. Everitt et al., Gravity Probe B: final results of a space experiment to test general relativity, Phys. Rev. Lett. 106 (2011) 221101 (read at statement level): a polar orbit of 642 km altitude, semi-major axis 7027.4 km', 'the Earth\'s gravitational parameter GM_⊕ = 3.986 004 × 10¹⁴ m³ s⁻² and the semi-major axis of the Gravity Probe B orbit, 7027.4 km',
        'The Earth\'s gravitational parameter and the Gravity Probe B orbit are inputs as their sources state them (IAU 2015; Everitt et al. 2011); no computation on the labels gives them.', ['gravity'],
        'The Earth\'s gravitational parameter and the orbit of Gravity Probe B are inputs, as their sources state them: GM_⊕ = 3.986 004 × 10¹⁴ m³ s⁻² (IAU 2015 nominal value) and a polar orbit of semi-major axis 7027.4 km, 642 km above the Earth (Everitt et al., 2011). The page of three measured numbers evaluates the geodetic precession of CAND-128 with them, the period from Kepler\'s third law (NUL-013); no computation on the labels gives them.'),
    inp('INP-106', 'steps/nullsurf', 33, 'C. W. F. Everitt et al., Gravity Probe B: final results of a space experiment to test general relativity, Phys. Rev. Lett. 106 (2011) 221101 (read at statement level): the geodetic drift rate −6601.8 ± 18.3 mas/yr, against the GR prediction −6606.1 mas/yr; the frame-dragging rate −37.2 ± 7.2 mas/yr against −39.2', 'the measured geodetic drift of Gravity Probe B\'s gyroscopes, 6601.8 ± 18.3 milliarcseconds per year',
        'The measured geodetic drift of Gravity Probe B is an input as its source states it (Everitt et al. 2011); it is what the page of three measured numbers compares with.', ['gravity'],
        'The measured geodetic drift of the gyroscopes of Gravity Probe B is an input, as its source states it: 6601.8 ± 18.3 milliarcseconds per year, against the general-relativistic prediction of 6606.1 for the actual orbit; the frame-dragging drift 37.2 ± 7.2 against 39.2 beside it (Everitt et al., 2011). the page of three measured numbers compares the geodetic precession of CAND-128 with the first (NUL-013); the frame-dragging rate is not compared (the Lense–Thirring factor of CAND-128 is checked at two radii, not evaluated for the Earth).'),
    inp('INP-107', 'steps/category', 1, 'A. Kitaev, Periodic table for topological insulators and superconductors, AIP Conf. Proc. 1134 (2009) 22; arXiv:0901.2686 (read at statement level): Table 1, the classification of the ten symmetry classes in dimensions d = 0 … 7 by ℤ, ℤ₂ and 0', 'Kitaev\'s periodic table, the published classification of free-fermion matter by symmetry class and dimension',
        'Kitaev\'s table is an input as its source states it (Kitaev 2009, Table 1); it is the known answer the extension problem of CAND-006 is compared with.', ['matter'],
        'Kitaev\'s periodic table is an input, as its source states it: the published classification of free-fermion matter by symmetry class and dimension, ℤ, ℤ₂ or 0 in each entry, with the eight real classes repeating with period eight (Kitaev, 2009, Table 1). The page of three measured numbers takes it as a known answer: the Clifford extension problem run on the labels (CAND-006) reproduces its entries, and the match of the classes with the clock values is fixed up to a reflection whose direction is an input (LNC-076c, LNC-081).'),
]
NEEDS_SECTION = {'steps/category': 'needs'}   # INP-107 goes to the category page's needs section too


def comparison(rid, group, page, section, order, notions, phenomena, home, evidence, depends, body):
    return (base_row(rid, group, 'computation', 'O', 'calibration', notions, ['(1,3,0)'], phenomena, ['geometry'], home, evidence, depends, None,
                     [{'page': page, 'section': section, 'order': order, 'role': 'detail'}]), body)


COMPARISONS = [
    comparison('CPL-013', 'CPL', 'steps/coupling', 'eq-coupling', 56, ['sol', 'dyn', 's-phy', 'i-tab'], ['electron', 'qm'],
               'the fine-structure interval of hydrogen from the Dirac equation on the labels, 10 943.7 MHz, against the measured 10 969.045 MHz: the difference, 0.23 %, is the QED part',
               [EV('M1')], [{'id': 'CAND-013', 'rel': 'derives'}, {'id': 'INP-098', 'rel': 'uses-input'}, {'id': 'INP-099', 'rel': 'uses-input'}, {'id': 'INP-104', 'rel': 'uses-input'}],
               "Hydrogen's fine structure against the measured interval. The Sommerfeld–Dirac formula of CAND-013, E(n, j) = m c² [1 + (α/(n − j − ½ + √((j + ½)² − α²)))²]^{−1/2}, evaluated on the fine-structure constant (INP-098) and the reduced mass of the electron in hydrogen (INP-099), gives the 2P₃/₂ − 2P₁/₂ interval of hydrogen as 10 943.694 MHz (the leading term m c² α⁴/32 is 10 949.284 MHz). The measured interval is 10 969.045 ± 0.015 MHz (INP-104). The engine's number is 25.351 MHz below it, 0.231 %: the difference is the quantum-electrodynamic part, the Lamb shifts of the two 2P levels, which the Dirac equation does not contain and the Atlas does not compute. The comparison passes at the 0.3 % level stated and no finer (c4.M1; a fine-structure constant one percent off, or the Schrödinger energies with no fine structure, fail)."),
    comparison('GRV-013', 'GRV', 'steps/grav2', 'eq-grav2', 20, ['sol', 'dyn', 's-phy', 'i-tab'], ['gravity'],
               "Mercury's perihelion from the engine's periastron advance, 42.980 arcseconds per century, against the measured 42.98 ± 0.04",
               [EV('M2')], [{'id': 'CAND-118', 'rel': 'derives'}, {'id': 'INP-100', 'rel': 'uses-input'}, {'id': 'INP-101', 'rel': 'uses-input'}, {'id': 'INP-102', 'rel': 'uses-input'}, {'id': 'INP-105', 'rel': 'uses-input'}],
               "Mercury's perihelion against the measured advance. The periastron advance per orbit of CAND-118, 6πGM/(c²a(1 − e²)), evaluated on the Sun's gravitational parameter (INP-100), Mercury's semi-major axis (INP-101) and eccentricity (INP-102), is 0.10352 arcseconds per orbit; with the period from Kepler's third law, 87.9695 days, 415.20 orbits per Julian century, the advance is 42.980 arcseconds per century. The measured relativistic advance is 42.98 ± 0.04 arcseconds per century (INP-105): the engine's number is 0.01 standard deviations from it (c4.M2; a solar mass one percent off fails at 16 standard deviations). The formula is the first post-Newtonian one the engine's orbits reproduce; the next order, 10⁻⁷ of the first, is below the measurement."),
    comparison('NUL-013', 'NUL', 'steps/nullsurf', 'eq-nullsurf', 27, ['sol', 'dyn', 's-phy', 'i-tab'], ['gravity'],
               "Gravity Probe B's geodetic drift from the engine's precession per orbit, 6603.9 milliarcseconds per year, against the measured 6601.8 ± 18.3",
               [EV('M3')], [{'id': 'CAND-128', 'rel': 'derives'}, {'id': 'INP-103', 'rel': 'uses-input'}, {'id': 'INP-106', 'rel': 'uses-input'}],
               "Gravity Probe B against the measured geodetic drift. The geodetic precession per orbit of CAND-128, 2π(1 − √(1 − 3GM/(c²r))), evaluated on the Earth's gravitational parameter and the semi-major axis of the Gravity Probe B orbit (INP-103), is 1.2269 milliarcseconds per orbit; with the period from Kepler's third law, 97.71 minutes, 5382.7 orbits per Julian year, the drift is 6603.9 milliarcseconds per year (the first-order rate (3/2)(GM)^{3/2}/(c²r^{5/2}) gives the same to the figures shown). The measured geodetic drift is 6601.8 ± 18.3 milliarcseconds per year (INP-106): the engine's number is 0.11 standard deviations from it (c4.M3; an Earth mass one percent off fails at 5.5 standard deviations). The published general-relativistic prediction for the actual orbit, 6606.1, carries the terms of the orbit's eccentricity and the Earth's oblateness, which the circular-orbit formula does not; the frame-dragging drift is not compared."),
]

CALIB4 = {
    'route': 'calib4', 'key': 'calib4', 'folder': 'calib4', 'after': 'matter', 'needs': ['steps/coupling', 'steps/grav2', 'steps/nullsurf', 'steps/category'],
    'title': {'phys': 'Three measured numbers: hydrogen, Mercury, Gravity Probe B', 'math': 'Three measured numbers: hydrogen, Mercury, Gravity Probe B', 'learner': 'Three numbers that were measured'},
    'hero': {'row': 'GRV-013', 'figure': None},
    'learnerFrame': {'h': 'Three numbers that were measured', 'before': "The calibration checked the rule against light and Furey's way against the algebra of a published model; neither compared a number with an experiment. Here three numbers the rule's engine computes are set beside what was measured: a line in the light of hydrogen, the slow turn of Mercury's orbit, and the tilt of a gyroscope in orbit around the Earth.", 'after': 'Next: ways of looking, the lenses page.', 'tags': []},
    'intro': ('GRV-731', ['CPL-013', 'GRV-013', 'NUL-013'], "Three measured numbers. The calibration of light and Furey's way compare the rule with light, in the sense of Maxwell's equations, and with the printed algebra of a published model; neither compares a number with an experiment. This page does: three closed forms the engine's checks establish on the labels — the Sommerfeld–Dirac energies, the periastron advance of an orbit, the geodetic precession of a gyroscope — are evaluated on the inputs their sources state and set beside the measured values, each an input row with its source. No physics is added: the match is a comparison, with its difference stated in the units of the measurement, and what the formula does not contain is named. A fourth section takes Kitaev's periodic table as a known answer of another kind, a classification the labels reproduce up to a reflection whose direction is an input."),
    'sections': [
        {'id': 'c-h', 'lead': 'GRV-741', 'title': {'phys': "Hydrogen's fine structure, measured", 'math': "Hydrogen: the Dirac interval, measured", 'learner': 'A line in the light of hydrogen'},
         'chain': {'slug': 'hydrogen', 'phys': 'The constants, the Dirac energies, the measured interval', 'math': 'α and m_e, the Sommerfeld–Dirac formula, the measurement', 'learner': 'Two constants, one formula, one measurement'}, 'rows': ['INP-098', 'INP-099', 'CAND-013', 'INP-104', 'CPL-013'],
         'text': "The Dirac equation on the labels has the closed bound states of hydrogen with the Sommerfeld–Dirac energies; the fine-structure constant and the electron's mass are inputs, as CODATA states them. Evaluated on them, the interval between the two 2P levels comes out a quarter of a percent below the measured one, and the page says what the difference is: the quantum-electrodynamic shifts of the two levels, which the Dirac equation does not contain. The comparison passes at the level it states and no finer."},
        {'id': 'c-m', 'lead': 'GRV-742', 'title': {'phys': "Mercury's perihelion, measured", 'math': "Mercury: the periastron advance, measured", 'learner': 'The slow turn of an orbit'},
         'chain': {'slug': 'mercury', 'phys': "The Sun, the orbit, the engine's advance, the measurement", 'math': 'GM, a and e, the advance per orbit, the measurement', 'learner': 'The Sun, the orbit and the measured turn'}, 'rows': ['INP-100', 'INP-101', 'INP-102', 'CAND-118', 'INP-105', 'GRV-013'],
         'text': "The engine's orbits reproduce the first post-Newtonian advance of the periastron, six pi times the mass over the latus rectum per orbit; the Sun's mass, Mercury's semi-major axis and its eccentricity are inputs, as their sources state them, and the period follows from Kepler's law. Evaluated on them the advance is 42.980 arcseconds per century, against the measured relativistic advance of 42.98 with an uncertainty of 0.04: a hundredth of a standard deviation apart. A solar mass one percent off fails by sixteen."},
        {'id': 'c-g', 'lead': 'GRV-743', 'title': {'phys': 'Gravity Probe B: the geodetic drift, measured', 'math': 'Gravity Probe B: the geodetic precession, measured', 'learner': 'A gyroscope in orbit'},
         'chain': {'slug': 'gyroscope', 'phys': "The Earth, the orbit, the precession, the measurement", 'math': 'GM and r, the precession per orbit, the measurement', 'learner': 'The Earth, the orbit and the measured tilt'}, 'rows': ['INP-103', 'CAND-128', 'INP-106', 'NUL-013'],
         'text': "Fermi–Walker transport along a circular geodesic of Schwarzschild gives the geodetic precession per orbit in closed form, checked on the engine; the Earth's mass and the orbit of Gravity Probe B are inputs, as their sources state them. Evaluated on them the drift agrees with the measured one to a tenth of a standard deviation; the published prediction for the actual orbit carries corrections the circular formula does not. The frame-dragging drift is not compared."},
        {'id': 'c-k', 'lead': 'GRV-744', 'title': {'phys': "Kitaev's table as a known answer", 'math': "Kitaev's table: the extensions against the classification", 'learner': 'A table of matter as the answer key'},
         'chain': {'slug': 'kitaev', 'phys': 'The table, the cells, the extensions, the direction', 'math': 'The table, the symmetry algebras, the extensions', 'learner': 'The table, the cells, one generator at a time'}, 'rows': ['INP-107', 'LNC-076b', 'CAND-006', 'LNC-081'],
         'text': "A known answer of another kind: the periodic table of free-fermion matter, published in 2009, classifies ten symmetry classes in every dimension by three possible groups and repeats with period eight. Taken as an input, it is compared with what the labels give: the symmetry algebra of each class is a cell, the extension problem the table rests on is run on the labels as written, and its entries come out. What the labels do not fix is said: the match of the classes with the clock values is determined only up to a reflection, and its direction depends on how a Hamiltonian meets the two symmetries, an input; the question stays open."},
    ],
}

SOURCES = [
    {'id': 'S30', 'source': 'CODATA 2018 (Tiesinga, Mohr, Newell, Taylor, Rev. Mod. Phys. 93 (2021) 025010)', 'itSays': 'The recommended values of the fundamental constants: α = 7.2973525693 × 10⁻³, m_e c² = 510 998.950 00 eV, m_p/m_e = 1836.152 673 43, h exact in the SI.', 'weComputed': 'The Sommerfeld–Dirac interval 2P₃/₂ − 2P₁/₂ of hydrogen on these values (CPL-013, calibration4.py M1); the constants themselves are inputs (INP-098, INP-099).', 'verdict': 'Read at statement level; the values taken as stated.', 'deadEnd': False, 'read': True},
    {'id': 'S31', 'source': 'Hagley and Pipkin, Phys. Rev. Lett. 72 (1994) 1172; Lundeen and Pipkin, Phys. Rev. Lett. 46 (1981) 232', 'itSays': 'The measured 2S₁/₂–2P₃/₂ interval of hydrogen, 9911.200(12) MHz, and the Lamb shift 2S₁/₂–2P₁/₂, 1057.845(9) MHz.', 'weComputed': 'Their sum, 10 969.045(15) MHz, is the measured 2P fine-structure interval the Dirac value is compared with (INP-104, CPL-013): 0.23 % apart, the QED part.', 'verdict': 'Read at statement level; the measured values taken as stated.', 'deadEnd': False, 'read': True},
    {'id': 'S32', 'source': 'Will, The confrontation between general relativity and experiment, Living Rev. Relativ. 17 (2014) 4, §4.3', 'itSays': 'The relativistic part of the observed advance of Mercury\'s perihelion is 42.98 ± 0.04 arcseconds per century, from radar ranging.', 'weComputed': 'The engine\'s periastron advance on the Sun\'s and Mercury\'s parameters, 42.980 arcseconds per century (GRV-013, calibration4.py M2): 0.01 standard deviations apart.', 'verdict': 'Read at statement level; the measured value taken as stated.', 'deadEnd': False, 'read': True},
    {'id': 'S33', 'source': 'Everitt et al., Gravity Probe B: final results of a space experiment to test general relativity, Phys. Rev. Lett. 106 (2011) 221101', 'itSays': 'The geodetic drift rate −6601.8 ± 18.3 mas/yr and the frame-dragging rate −37.2 ± 7.2 mas/yr, against the GR predictions −6606.1 and −39.2, for a polar orbit of 642 km altitude.', 'weComputed': 'The engine\'s geodetic precession on the Earth\'s parameter and the orbit, 6603.9 mas/yr (NUL-013, calibration4.py M3): 0.11 standard deviations from the measurement; the frame-dragging rate not compared.', 'verdict': 'Read at statement level; the measured values taken as stated.', 'deadEnd': False, 'read': True},
    {'id': 'S34', 'source': 'Kitaev, Periodic table for topological insulators and superconductors, AIP Conf. Proc. 1134 (2009) 22; arXiv:0901.2686', 'itSays': 'The ten symmetry classes of free-fermion matter and their classification in every dimension by ℤ, ℤ₂ or 0, the eight real classes with period eight, from the Clifford extension problem and the K-theory of a point.', 'weComputed': 'The symmetry algebra of each class as a cell (LNC-076b), the extension problem on the labels with the table\'s entries (CAND-006), the match with the clock up to a reflection (LNC-076c, LNC-081); the table as an input (INP-107). Kitaev\'s way (ways/kitaev) follows the paper in its order.', 'verdict': 'Read at statement level.', 'deadEnd': False, 'read': True},
]


def write_rows():
    rows = load('content/rows.json'); texts = load('content/texts.json'); changed = 0
    by = {r['id']: i for i, r in enumerate(rows)}
    for rec, body in NEW_ROWS + COMPARISONS:
        rid = rec['id']
        if rid in by:
            # the merge adds the placements of the pages that tell the row (shownOn beyond its home): kept when the home is the same
            cur = rows[by[rid]]; same_home = cur.get('shownOn') and rec['shownOn'] and cur['shownOn'][0] == rec['shownOn'][0]
            want = dict(rec, shownOn=cur['shownOn']) if same_home else rec
            if cur != want: rows[by[rid]] = want; changed += 1
        else:
            last = max(i for i, r in enumerate(rows) if r['group'] == rec['group'] and r['kind'] != 'story')
            rows.insert(last + 1, rec); by = {r['id']: i for i, r in enumerate(rows)}; changed += 1
        t = {'row': rid, 'lang': 'en', 'mode': 'both', 'level': 'research', 'lens': None, 'register': 'full', 'body': body, 'status': 'draft', 'source': SRC}
        i = next((k for k, x in enumerate(texts) if x['row'] == rid and x['level'] == 'research' and x.get('lens') is None and x.get('chain') is None), None)
        if i is None: texts.append(t); changed += 1
        elif texts[i] != t: texts[i] = t; changed += 1
    if changed:
        W21.save(os.path.join(ROOT, 'content', 'rows.json'), json.dumps(rows, ensure_ascii=False, indent=1) + '\n')
        W21.save(os.path.join(ROOT, 'content', 'texts.json'), json.dumps(texts, ensure_ascii=False, indent=1) + '\n')
    else: print('unchanged content/rows.json, content/texts.json (the thirteen rows)')
    sources = load('content/sources.json')
    for s in SOURCES:
        i = next((k for k, x in enumerate(sources) if x['id'] == s['id']), None)
        if i is None: sources.append(s)
        else: sources[i] = s
    W21.save(os.path.join(ROOT, 'content', 'sources.json'), json.dumps(sources, ensure_ascii=False, indent=1) + '\n')
    checks = load('content/checks.json'); runs = load('content/check_runs.json')
    entry = {'id': 'selfcheck/round22/calibration4.py', 'family': 'round22', 'script': SCRIPT,
             'ids': [{'id': 'c4.M1', 'statement': 'the Sommerfeld–Dirac 2P₃/₂ − 2P₁/₂ interval of hydrogen on CODATA 2018, with the reduced mass: 10 943.694 MHz against the measured 10 969.045(15), within 0.3 % (the difference the QED part)'},
                     {'id': 'c4.M2', 'statement': "the periastron advance 6πGM/(c²a(1 − e²)) per orbit on the Sun's and Mercury's parameters, with Kepler's period: 42.980 arcseconds per century against 42.98 ± 0.04, within 2 standard deviations"},
                     {'id': 'c4.M3', 'statement': "the geodetic precession 2π(1 − √(1 − 3GM/(c²r))) per orbit on the Earth's parameter and the GP-B orbit, with Kepler's period: 6603.9 mas/yr against 6601.8 ± 18.3, within 1 standard deviation"}],
             'what': "CPL-013, GRV-013, NUL-013: three measured numbers, the engine's closed forms on their inputs against three measured numbers (hydrogen's fine structure, Mercury's perihelion, Gravity Probe B's geodetic drift)",
             'method': 'floating point; the closed forms the rows establish, the inputs as their sources state them, the periods from Kepler\'s third law; each comparison in units of the measurement\'s uncertainty',
             'independentRoute': 'no (the formulas are evaluated as written)', 'controls': 'yes: --fault ALPHA, G, GM, SCHRODINGER, each wrong version exits 1 (logs/calibration4.faults.log)',
             'deps': 'none (pure Python)', 'storedResult': None, 'log': 'checks/selfcheck/round22/logs/calibration4.log', 'rowsNaming': ['CPL-013', 'GRV-013', 'NUL-013'],
             'notes': 'round 22 (release 4.0.0): three measured numbers (D89)', 'since': 'v4.0'}
    i = next((k for k, c in enumerate(checks) if c.get('id') == entry['id']), None)
    if i is None: checks.append(entry)
    else: checks[i] = entry
    W21.save(os.path.join(ROOT, 'content', 'checks.json'), json.dumps(checks, ensure_ascii=False, indent=1) + '\n')
    run = {'script': SCRIPT, 'date': '2026-10-22', 'machine': "round 22 release run (4.0.0), from the script's own folder", 'ok': None, 'fail': 0,
           'lastLine': 'ALL OK: 3 comparisons (M1 hydrogen, M2 Mercury, M3 Gravity Probe B)', 'passed': True, 'seconds': 0.1,
           'status': 'pass (-I -B from its folder; 4 --fault runs each exit 1); about 0.1 s alone', 'source': 'checks/selfcheck/round22/logs/calibration4.log'}
    j = next((k for k, r in enumerate(runs) if r.get('script') == SCRIPT), None)
    if j is None: runs.append(run)
    else: runs[j] = run
    W21.save(os.path.join(ROOT, 'content', 'check_runs.json'), json.dumps(runs, ensure_ascii=False, indent=1) + '\n')


def write_page():
    W = CALIB4; page, key = W['route'], W['key']
    intro_id, intro_restates, intro_text = W['intro']
    rows = [story(intro_id, page, 'intro', 'lead', 0, intro_restates)]
    texts = [text(intro_id, intro_text)]
    sections, chains, layout = [], [], []
    order = 2000
    for s in W['sections']:
        rows.append(story(s['lead'], page, s['id'], 'lead', 0, s['rows']))
        texts.append(text(s['lead'], s['text']))
        sections.append({'id': s['id'], 'title': s['title'], 'lead': s['lead']})
        chains.append(W21.chain(page, key, s['id'], 1, s['chain'], s['rows']))
        for rid in s['rows']:
            order += 1
            layout.append({'row': rid, 'page': page, 'section': s['id'], 'order': order, 'role': 'result', 'add': True})
    entry = {'route': page, 'page': {'title': W['title'], 'after': W['after'], 'needs': W['needs'], 'learnerFrame': W['learnerFrame'], 'connective': {}},
             'hero': W['hero'], 'intro': {'lead': intro_id}, 'parts': [], 'sections': sections}
    folder = os.path.join(ROOT, 'content', 'chains', W['folder'])
    os.makedirs(folder, exist_ok=True)
    out = {'page.json': {'pages': [entry], 'layout': layout}, 'rows.json': rows, 'texts.json': texts}
    for name, data in out.items():
        W21.save(os.path.join(folder, name), json.dumps(data, ensure_ascii=False, indent=1) + '\n')
    cf = os.path.join(folder, 'chains.json')
    if os.path.exists(cf):
        old = json.load(open(cf, encoding='utf-8'))
        for c in chains:
            o = next((x for x in old if x['id'] == c['id']), None)
            if o and o['rows'] == c['rows']: c['links'], c['shape'], c['joins'] = o['links'], o['shape'], o['joins']
    W21.save(cf, W21.dump_chains(chains))
    print(page, 'story rows', len(rows), 'chains', len(chains), 'placements', len(layout))


if __name__ == '__main__':
    write_rows(); write_page()
