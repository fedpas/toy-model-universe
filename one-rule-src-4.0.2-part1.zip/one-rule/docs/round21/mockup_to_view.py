#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round21/mockup_to_view.py — writes content/views/shifted.json, the source overlay of the shifted page's researcher view (D86: hand-written
material the generator reads: the paper's citation, the conventions paragraph with its display (S0.1), and the display formulas of every row and
lead with their equation numbers), from the mockup of round 20 (docs/round20/staging/shifted_view/source/p1.md … p4.md). The prose of the mockup
is not copied: the generator prints the tables' research texts (the staging of 3.7.1 applied the mockup's words to them). Idempotent.
Usage: python3 docs/round21/mockup_to_view.py"""
import json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
SRC = os.path.join(ROOT, 'docs', 'round20', 'staging', 'shifted_view', 'source')
OUT = os.path.join(ROOT, 'content', 'views', 'shifted.json')
# the section of each step heading of the mockup, and its lead story row (content/chains/shifted/page.json)
STEP_SECTION = {'1': 'sv-1', '2': 'sv-2', '3': 'sv-3', '4': 'sv-4', '5': 'sv-5', '6a': 'sv-6a', '6b': 'sv-6b', '6c': 'sv-6c', '7': 'sv-7', '8': 'sv-8', '9': 'sv-9', 'open': 'sv-open'}
LEADS = {'sv-1': 'ATY-711', 'sv-2': 'ATY-712', 'sv-3': 'ATY-713', 'sv-4': 'ATY-714', 'sv-5': 'ATY-715', 'sv-6a': 'ATY-716', 'sv-6b': 'ATY-717', 'sv-6c': 'ATY-718', 'sv-7': 'ATY-719', 'sv-8': 'ATY-720', 'sv-9': 'ATY-721', 'sv-open': 'ATY-722'}


def displays_of(text):
    out = []
    for d in re.finditer(r'\$\$(.+?)\$\$', text, re.S):
        tex = d.group(1).strip()
        m = re.search(r'\s*\\tag\{([^}]*)\}', tex)
        tag = m.group(1) if m else None
        if m: tex = (tex[:m.start()] + tex[m.end():]).strip()
        tex = re.sub(r'[\s,.;]+$', '', tex)   # the mockup's sentence punctuation inside a display is not part of the formula
        out.append({'tex': tex, 'tag': tag})
    return out


def main():
    lines = []
    for i in (1, 2, 3, 4):
        lines += open(os.path.join(SRC, f'p{i}.md'), encoding='utf-8').read().split('\n')
    displays = {}
    box = None
    step = None
    i = 0
    while i < len(lines):
        st = lines[i].strip()
        h = re.match(r'^### (?:Step (\w+)\.|(Three questions))', st)
        if h: step = h.group(1) or 'open'
        m = re.match(r':::(row|lead|box|see|fig) ?(\S*) ?(\S*)', st)
        if not m: i += 1; continue
        kind = m.group(1)
        j = i + 1; blk = []
        while lines[j].strip() != ':::': blk.append(lines[j]); j += 1
        text = '\n'.join(blk)
        if kind == 'box' and box is None:
            box = text
        elif kind in ('row', 'lead'):
            key = m.group(2) if kind == 'row' else LEADS[STEP_SECTION[step]]
            for d in displays_of(text):
                if d['tag'] is None: continue   # the one untagged display (the symbols of the variants, ATY-058) is prose in the research text
                displays.setdefault(key, []).append(d)
        i = j + 1
    # the box: the citation of the paper and the conventions paragraph with (S0.1)
    paras = [p.strip() for p in re.split(r'\n\s*\n', box) if p.strip()]
    cite = paras[0].split('The paper: ', 1)[1]
    k = next(i for i, p in enumerate(paras) if p.startswith('**Equations.**')), next(i for i, p in enumerate(paras) if p.startswith('**Badges.**'))
    conv = '\n\n'.join(paras[k[0]:k[1]])
    conv_disp = displays_of(conv)
    conv = re.sub(r'\$\$.+?\$\$', '', conv, flags=re.S).strip()
    conv = re.sub(r'^\*\*Equations\.\*\*\s*', '', conv)
    view = {
        'key': 'shifted', 'page': 'shifted',
        '_about': 'The source overlay of the researcher view of the page shifted (D86): what the tables do not hold — the citation of the paper, the conventions of the view with its display (S0.1), and the display formulas of the rows and the leads with their equation numbers (S<step>.<k>), from the mockup of round 20 (docs/round20/staging/shifted_view/source); written by docs/round21/mockup_to_view.py. The generator (tools/researcher_view.mjs) prints the research texts of the tables; tools/formulas.mjs catalogues the displays (content/formulas.json).',
        'source': cite,
        'conventions': {'text': conv, 'displays': conv_disp},
        'displays': displays,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    text = json.dumps(view, ensure_ascii=False, indent=1) + '\n'
    old = open(OUT, encoding='utf-8').read() if os.path.exists(OUT) else None
    if text != old: open(OUT, 'w', encoding='utf-8').write(text); print('wrote', os.path.relpath(OUT, ROOT))
    else: print('unchanged', os.path.relpath(OUT, ROOT))
    n = sum(len(v) for v in displays.values()) + len(conv_disp)
    print(f'{n} displays for {len(displays)} rows and leads')


if __name__ == '__main__':
    main()
