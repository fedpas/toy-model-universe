#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round21/apply_p1.py — release 3.8.0, "the ledger" (docs/round20/PLAN.md §3, D85–D87): the table edits of the release, idempotent.

  1. the `reason` of every row whose status is our reading or open, and of every input row that imports a number (WP1, D85): docs/round21/reasons.py,
     written into the file that owns the row — the base tables (content/rows.json), the Explore overlay (content/explore/rows.json), the physics
     overlay (content/physics/rows.p6.json, a label of the line: tools/physics/stored_p6.mjs keeps it), the chains overlay of round 14
     (content/chains/<owner>/rows.json), a promoted row's pending entry (content/story/pending.json) or its further-rows entry of
     content/story/review_rows.json (tools/merge_story.mjs carries `reason` from the labels) — and into the merged copy in content/rows.json;
  2. (WP3) the lead story rows of the ways weil and penrose: content/chains/ways/rows.json and texts.json (written by hand, checked by the merge).

Usage: python3 docs/round21/apply_p1.py [--dry-run]     then `npm run content` twice; the script is a fixed point after the merge.
"""
import json, os, sys, glob

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
DRY = '--dry-run' in sys.argv
sys.path.insert(0, HERE)
from reasons import REASONS, KINDS  # noqa: E402

said = []


def path(rel):
    return os.path.join(ROOT, rel)


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    data, nl = json.loads(raw), raw.endswith('\n')
    assert json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if nl else '') == raw, f'{rel}: a load and dump would change its text: stop'
    return data, nl


def save(rel, data, nl):
    text = json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if nl else '')
    old = open(path(rel), encoding='utf-8').read()
    if text == old:
        said.append(f'unchanged {rel}'); return
    if not DRY:
        open(path(rel), 'w', encoding='utf-8').write(text)
    said.append(f'wrote {rel}')


def reason_of(rid):
    kind, src, why = REASONS[rid]
    assert kind in KINDS and len(why) >= 40, rid
    return {'kind': kind, 'why': why, 'from': src}


def set_reason(r, rid):
    """the field reason on a row record (or a labels record); True when it changed"""
    want = reason_of(rid)
    if r.get('reason') == want: return False
    r['reason'] = want
    return True


def apply_reasons():
    ids = set(REASONS)
    # the files that own rows: the overlays first, so that a row of the tables that is also an overlay's is written in the overlay too
    overlays = sorted(glob.glob(path('content/explore/rows.json')) + glob.glob(path('content/physics/rows.p*.json')) + glob.glob(path('content/chains/*/rows.json')))
    done = {}
    for f in overlays:
        rel = os.path.relpath(f, ROOT)
        data, nl = load(rel); changed = False
        for r in data:
            if r.get('id') in ids:
                if set_reason(r, r['id']): changed = True
                done.setdefault(r['id'], []).append(rel)
        if changed: save(rel, data, nl)
        else: said.append(f'unchanged {rel}')
    # a promoted row (tools/merge_story.mjs, the review's choices): its labels are its pending entry, or its entry of review_rows.json (or a further row's)
    rv, rv_nl = load('content/story/review_rows.json'); rv_changed = False
    for loc, e in rv.items():
        if not isinstance(e, dict): continue
        for m in e.get('more') or []:   # a further row: its labels are the entry's
            if isinstance(m, dict) and m.get('id') in ids:
                if set_reason(m.setdefault('labels', {}), m['id']): rv_changed = True
                done.setdefault(m['id'], []).append('content/story/review_rows.json')
    review = json.load(open(path('content/story/review.json'), encoding='utf-8'))
    pend, nl = load('content/story/pending.json'); changed = False
    for p in pend:
        rid, loc = p.get('id'), p.get('locator')
        if rid not in ids or not review.get(loc) or rid in done: continue
        rr = rv.get(loc)
        if isinstance(rr, dict) and isinstance(rr.get('labels'), dict):   # the promoted row's labels are its review_rows entry's
            if set_reason(rr['labels'], rid): rv_changed = True
            done.setdefault(rid, []).append('content/story/review_rows.json')
        else:                                                              # else the pending entry's own
            if set_reason(p, rid): changed = True
            done.setdefault(rid, []).append('content/story/pending.json')
    if rv_changed: save('content/story/review_rows.json', rv, rv_nl)
    else: said.append('unchanged content/story/review_rows.json')
    if changed: save('content/story/pending.json', pend, nl)
    else: said.append('unchanged content/story/pending.json')
    # the merged tables: every row (the base rows own their reason here; the overlay rows carry a copy until the next merge rewrites them)
    rows, nl = load('content/rows.json'); changed = False; seen = set()
    for r in rows:
        if r['id'] in ids:
            seen.add(r['id'])
            if set_reason(r, r['id']): changed = True
    if changed: save('content/rows.json', rows, nl)
    else: said.append('unchanged content/rows.json')
    missing = ids - seen
    assert not missing, f'rows without a record in content/rows.json: {sorted(missing)}'
    base = sorted(ids - set(done))
    said.append(f'reasons: {len(ids)} rows — {len(base)} of the base tables, {len(ids) - len(base)} of overlays ({", ".join(sorted({x for v in done.values() for x in v}))})')


def main():
    apply_reasons()
    for s in said: print(s)


if __name__ == '__main__':
    main()
