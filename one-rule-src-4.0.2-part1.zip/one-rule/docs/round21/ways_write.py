#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round21/ways_write.py — the two ways of 3.8.0 as pages of the chains overlay (D87; docs/round20/PLAN.md §3 WP3b): content/chains/way-weil/
and content/chains/way-penrose/ (page.json, rows.json, texts.json, chains.json), and the registry content/ways.json. A way is a page whose
sections are the source's steps, each with a lead story row that tells the source's move in the Atlas's words (a research draft, source
round21:WP3), and whose chains tell the rows the labels compute at that step, placed on the page by the overlay's layout (order 2000 and more: a
home never moves). The links of the chains are what the tables give their positions (node docs/round20/rejoin.mjs --relink, D83). Idempotent.
Usage: python3 docs/round21/ways_write.py"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
SRC = 'round21:WP3'


def story(rid, group, page, section, role, order, restates):
    return {'id': rid, 'group': group, 'kind': 'story', 'stage': 'M', 'ptype': None, 'notions': ['i-meta'], 'fields': [], 'phenomena': [], 'cells': [],
            'homePhys': '', 'homeMath': '', 'standardRef': None, 'evidence': [], 'depends': [{'id': x, 'rel': 'restates'} for x in restates], 'links': [],
            'lensTags': [], 'legacyFlags': [], 'legacyLines': 0, 'legacyLabel': 'story', 'legacyKnown': False, 'since': 'v3.8', 'tabV15': None,
            'anchorV15': None, 'source': SRC, 'shownOn': [{'page': page, 'section': section, 'order': order, 'role': role}], 'visibleTo': ['phys', 'math'],
            'review': None, 'notesPersona': [], 'theorems': [], 'readingRefs': 0, 'v16': [], 'splitFrom': None, 'labelFrom': None}


def text(rid, body):
    return {'row': rid, 'lang': 'en', 'mode': 'both', 'level': 'research', 'lens': None, 'register': 'full', 'body': body, 'status': 'draft', 'source': SRC}


def chain(page, key, section, order, title, rows, links=None, shape='line'):
    return {'id': f'{key}.{section}.{title["slug"]}', 'page': page, 'section': section, 'order': order,
            'title': {'phys': title['phys'], 'math': title.get('math', title['phys']), 'learner': title.get('learner', title['phys'])}, 'lead': None,
            'rows': rows, 'mention': [], 'twins': {}, 'joins': [], 'links': links if links is not None else [{'rel': 'order'}] * (len(rows) - 1), 'shape': shape,
            'extracted': None, 'story': 'none'}


# ====================================================================================================================== Weil's way
WEIL = {
    'route': 'ways/weil', 'key': 'ways-weil', 'group': 'LAB', 'folder': 'way-weil', 'after': 'shifted', 'needs': ['clock', 'steps/category'],
    'title': {'phys': "Weil's way: the memoir of 1964, read on the labels", 'math': "Weil's way: the memoir on the unitary operators (1964), on the labels", 'learner': "Weil's way: an old book, read on the switches"},
    'hero': {'row': 'LAB-028', 'figure': 'weil-index'},
    'learnerFrame': {'h': "Weil's way: an old book, read on the switches", 'before': "The clock of the cells counts in eighths of a turn. A mathematician's book of 1964 explains, number by number, where such a count comes from; here the book is read with the switches in the place of its groups.", 'after': 'Next: the twistor way, where light rays become points.', 'tags': []},
    'intro': ('LAB-731', ['LAB-028'], "Weil's way through the Atlas. The memoir of 1964 on certain groups of unitary operators is read from its first number to its last, and at each of its numbered steps the labels of one cell stand in for its locally compact abelian group: the clock of the cell is Weil's index, the Clifford gates of qubits are his group of automorphisms, the stabilizer states his theta functions, the self-dual codes of labels the subgroups of his fifth theorem, and the average over a genus of codes his closing formula. Each step opens with the memoir's move, told in the Atlas's words; then come the statements the labels compute at that step, each with its checks; what the memoir does over the adeles, which the Atlas does not reach, is said at the end."),
    'sections': [
        {'id': 'w-0', 'lead': 'LAB-741', 'title': {'phys': 'Before the memoir: the clock sum as a path', 'math': "Before the memoir: the partial sums of the clock's Gauss sum", 'learner': 'Before the book: the clock drawn as a path'},
         'rows': ['LAB-026', 'LAB-027'], 'chain': {'slug': 'path', 'phys': 'The clock sum drawn as a path', 'math': 'The partial sums of the Gauss sum', 'learner': 'The clock drawn as a path'},
         'text': "Before the memoir, the sum that the clock's hand adds up is drawn as a path. Counting the labels of a cell in their order, each label a unit step turned by its square and its parity, the partial sums trace a curve that every new generator copies and turns by a quarter: the end of the path is the clock's hand, fixed by the cell, while the path itself depends on the order the labels are counted in. The boundary of the picture is then counted label by label, with the growth rate the literature gives it."},
        {'id': 'w-1', 'lead': 'LAB-742', 'title': {'phys': 'n° 1–10. The group A(G) and its automorphisms', 'math': 'n° 1–10. A(G), B₀(G) and the first of the theorems', 'learner': 'Numbers 1 to 10: the group and the moves that keep it'},
         'rows': ['LAB-029', 'LAB-030'], 'chain': {'slug': 'heisenberg', 'phys': 'The Heisenberg group of the labels and its automorphisms', 'math': 'A(G) and B₀(G) on the labels', 'learner': 'The group of the switches and its moves'},
         'text': "The memoir opens with a locally compact abelian group, its dual and the characters of the second degree on it; from the group and its dual it builds the unitary operators of translation and of multiplication by a character, whose products close up to a scalar: a Heisenberg group, the canonical commutation relations in Weyl's form. Its first theorem says that every automorphism of that group fixing its centre comes from one unitary operator, unique up to a scalar. On the labels the group is the set of labels of a cell with an even number of generators, its operators are the Pauli strings of qubits, and the automorphisms are the Clifford group modulo its scalars."},
        {'id': 'w-2', 'lead': 'LAB-743', 'title': {'phys': 'n° 13–15. The lifts and the index', 'math': 'n° 13–15. The lifting r₀ and the index γ', 'learner': 'Numbers 13 to 15: the price of a choice'},
         'rows': ['LAB-028', 'LAB-031', 'LAB-032', 'LAB-037'], 'chain': {'slug': 'index', 'phys': 'The lifts and the index', 'math': 'The lifting, the index and the factor system', 'learner': 'The phase that stays'},
         'text': "To fix the scalar the memoir lifts each element of the big cell to one operator by an integral formula, and finds the price: two lifts compose up to a number of absolute value one, the index of a character of the second degree, Weil's Theorem 3. On the labels that index is the clock's phase, an eighth root of unity, and the question of which phases a group of Clifford gates can shed is settled for one qubit and for two or more."},
        {'id': 'w-3', 'lead': 'LAB-744', 'title': {'phys': 'n° 16–21. The theta transform', 'math': 'n° 16–21. The theta transform and the stabilizer states', 'learner': 'Numbers 16 to 21: the theta transform'},
         'rows': ['LAB-033'], 'chain': {'slug': 'theta', 'phys': 'The theta transform and the stabilizer states', 'math': 'The theta transform on the labels', 'learner': 'Theta functions on the switches'},
         'text': "The theta transform takes a subgroup of the group and its annihilator in the dual, and carries a function to one that is quasi-periodic under the pair: an isometry, and on the operations that keep the pair the lifts compose with no scalar left, Weil's Theorem 4. On the labels the subgroup is a code, the quasi-periodic functions are the stabilizer states, and on the stabilizer of such a state the projective representation becomes a true one."},
        {'id': 'w-4', 'lead': 'LAB-745', 'title': {'phys': 'n° 20. The clock at zero', 'math': 'n° 20. Characters trivial on a lattice: self-dual codes', 'learner': 'Number 20: when the clock stands at zero'},
         'rows': ['LAB-034', 'LAB-035'], 'chain': {'slug': 'codes', 'phys': 'Self-dual codes and the clock at zero', 'math': 'Self-dual codes of labels and their genus', 'learner': 'Codes of switches and the clock at zero'},
         'text': "When a character of the second degree is trivial on a subgroup that is its own annihilator, its index is one: Weil's Theorem 5, the source of the quadratic reciprocity law over the adeles. On the labels the subgroup is a self-dual code of labels of square plus one, which exists only when the clock stands at zero; the codes of a cell form one genus, and the counting formula of that genus is computed."},
        {'id': 'w-5', 'lead': 'LAB-746', 'title': {'phys': 'n° 43. The relation (40) and the covers', 'math': 'n° 43. The relation (40) and the n-fold covers', 'learner': 'Number 43: how many sheets a cover needs'},
         'rows': ['LAB-038'], 'chain': {'slug': 'covers', 'phys': 'The covers of the symplectic group', 'math': 'The relation (40) on the labels', 'learner': 'How many sheets the cover needs'},
         'text': "In its forty-third number the memoir asks for an n-fold cover of the symplectic group, built from a function on the big cell with a relation to the index. On the labels, for two or more qubits, the relation has a solution for the fourfold covers and none for the double cover that the metaplectic group gives over the reals."},
        {'id': 'w-6', 'lead': 'LAB-747', 'title': {'phys': 'n° 52. The Siegel–Weil formula', 'math': 'n° 52. The formula of the last number', 'learner': 'Number 52: the formula at the end of the book'},
         'rows': ['LAB-036', 'LAB-039'], 'chain': {'slug': 'siegel-weil', 'phys': 'The genus average and the orbit sum', 'math': 'The genus average as an orbit sum', 'learner': 'The average over the codes'},
         'text': "The memoir ends on the formula of its last number, proved in the next memoir: the theta series integrated over the adelic quotient of its unitary group equals a sum over the classes of a parabolic subgroup, a formula of Siegel's kind. On the labels the integral is an average over the genus of codes, the sum is a normalised sum over an orbit of the Clifford group, and the identity is proved in every genus for every cell; the Eisenstein-series side is a reading, ours."},
        {'id': 'w-open', 'lead': 'LAB-748', 'title': {'phys': 'Beyond the labels: the adeles and the limit', 'math': 'Beyond the labels: Chapter II and the limit', 'learner': 'Where the switches stop'},
         'rows': ['LNC-080'], 'chain': {'slug': 'limit', 'phys': 'The adeles and the limit', 'math': 'The CAR to CCR limit', 'learner': 'The step the switches do not take'},
         'text': "Beyond the labels: the memoir's second chapter works over the adeles of a number field, where the reciprocity law and the formula of the last number live, and the Atlas has no adeles. The frame holds the canonical commutation relations of finitely many qubits; what limit takes the fermionic ladder to the bosonic one, which needs infinite dimension, is open."},
    ],
}

# ====================================================================================================================== Penrose's way
PENROSE = {
    'route': 'ways/penrose', 'key': 'ways-penrose', 'group': 'ATY', 'folder': 'way-penrose', 'after': 'shifted', 'needs': ['steps/projective', 'light', 'steps/ym'],
    'title': {'phys': "Penrose's way: twistor theory at fifty, read on the labels", 'math': "Penrose's way: the review of Atiyah, Dunajski and Mason, on the labels", 'learner': "Penrose's way: light rays as points"},
    'hero': {'row': 'ATY-066', 'figure': None},
    'learnerFrame': {'h': "Penrose's way: light rays as points", 'before': "Weil's way read an old book on the switches. Here a review of fifty years of twistor theory is read the same way: its objects are built on the switches and its formulas are run on exact numbers.", 'after': 'Next: the lenses, ways of looking at the same statements.', 'tags': []},
    'intro': ('ATY-731', ['ATY-066'], "Penrose's way through the Atlas. The review of twistor theory at fifty by Atiyah, Dunajski and Mason is read with the Atlas's method: its objects are built on the labels of one cell and its formulae are run on exact numbers. Twistor space is a module of the conformal cell, the incidence relation is checked both ways, Penrose's contour integrals are residues computed on rational twistor functions, and the Lax pair of anti-self-dual Yang–Mills fields is written in the review's coordinates with its orientation settled. The passes the programme plans next are listed at the end, each with the rows it starts from."),
    'sections': [
        {'id': 't-1', 'lead': 'ATY-741', 'title': {'phys': 'Twistor space from the labels', 'math': 'Twistor space and the Klein quadric from the conformal cell', 'learner': 'A space where points are lines'},
         'rows': ['ATY-066'], 'chain': {'slug': 'twistors', 'phys': 'Twistor space and the Klein quadric', 'math': 'The module of the conformal cell', 'learner': 'The space of twistors'},
         'text': "The review starts from the correspondence that gave twistor theory its name: a point of compactified complexified space-time is a line of twistor space, and twistors are the spinors of the conformal group. On the labels the conformal cell carries that group as its bivectors, its volume element is a complex structure, and a left ideal of its even part is the twistor space, with the Klein quadric read off the labels."},
        {'id': 't-2', 'lead': 'ATY-742', 'title': {'phys': 'Incidence, light rays and the Robinson congruence', 'math': 'The incidence relation on exact numbers', 'learner': 'Light rays as points'},
         'rows': ['ATY-067'], 'chain': {'slug': 'incidence', 'phys': 'Incidence and the Robinson congruence', 'math': 'The incidence relation and the congruence', 'learner': 'When a point sits on a twistor'},
         'text': "The incidence relation says when a point lies on a twistor: a light ray is a point of a five-dimensional space, and a non-null twistor is a twisting family of light rays filling space, one through each point, the Robinson congruence. On exact numbers the relation is checked both ways, and the congruence is drawn ray by ray."},
        {'id': 't-3', 'lead': 'ATY-743', 'title': {'phys': 'The Penrose transform and the integral formulae', 'math': "Penrose's integral formulae as residues", 'learner': 'Fields from contour integrals'},
         'rows': ['ATY-068'], 'chain': {'slug': 'transform', 'phys': 'The integral formulae as residues', 'math': 'The Penrose transform on rational twistor functions', 'learner': 'Fields from integrals'},
         'text': "Penrose's integral formulae give massless fields of every spin as contour integrals of holomorphic functions on twistor space. On rational twistor functions the integrals are residues, computed exactly, and the fields they give solve the wave equation and the zero-rest-mass equations, the spin-one field a self-dual Maxwell field."},
        {'id': 't-4', 'lead': 'ATY-744', 'title': {'phys': 'Lax pairs, anti-self-duality and Nahm', 'math': "The Lax pair of the review and Nahm's equations", 'learner': 'Two equations that agree'},
         'rows': ['ATY-069'], 'chain': {'slug': 'lax', 'phys': "The Lax pair and Nahm's equations", 'math': 'The Lax pair in the review’s coordinates', 'learner': 'The pair of equations'},
         'text': "The review's Lax pair makes an anti-self-dual Yang–Mills field the compatibility condition of a linear system with a spectral parameter, and Nahm's equations its reduction to one variable. On the labels the pair is written in the review's coordinates, its orientation settled, so that the Atlas's own instanton is self-dual there and its mirror image is an instanton in the review's sense."},
        {'id': 't-next', 'lead': 'ATY-745', 'title': {'phys': 'The next passes of the programme', 'math': 'The next passes: 14b to 14e', 'learner': 'What comes next'},
         'rows': ['ATY-017', 'ATY-025', 'CAND-124', 'LNS-017g'], 'chain': {'slug': 'starts', 'phys': 'The rows the next passes start from', 'math': 'The starting points of passes 14b to 14e', 'learner': 'Where the next steps begin'},
         'text': "Where the way goes next, as the programme plans it: curved twistors and the nonlinear graviton on the gravity engine, from the metrics it already checks; instantons from twistor data, the 't Hooft ansatz and the ADHM construction of charge one; amplitudes on rational kinematics; and the reductions, sine-Gordon, Nahm's spectral curve and the Newtonian limit with its Newton–Cartan connection. The rows these passes start from are told here: the self-dual metric the engine checks, the limits of the cone family as the paper states them, a reading of ours, the instanton, and the null case the engine can run and has not run, open."},
    ],
}


def write_way(W):
    page, key, group = W['route'], W['key'], W['group']
    intro_id, intro_restates, intro_text = W['intro']
    rows = [story(intro_id, group, page, 'intro', 'lead', 0, intro_restates)]
    texts = [text(intro_id, intro_text)]
    sections, chains, layout = [], [], []
    order = 2000
    for i, s in enumerate(W['sections']):
        rows.append(story(s['lead'], group, page, s['id'], 'lead', 0, s['rows']))
        texts.append(text(s['lead'], s['text']))
        sections.append({'id': s['id'], 'title': s['title'], 'lead': s['lead']})
        chains.append(chain(page, key, s['id'], 1, s['chain'], s['rows']))
        for rid in s['rows']:
            order += 1
            layout.append({'row': rid, 'page': page, 'section': s['id'], 'order': order, 'role': 'result', 'add': True})
    entry = {'route': page, 'page': {'title': W['title'], 'after': W['after'], 'needs': W['needs'], 'learnerFrame': W['learnerFrame'], 'connective': {}},
             'hero': W['hero'], 'intro': {'lead': intro_id}, 'parts': [], 'sections': sections}
    folder = os.path.join(ROOT, 'content', 'chains', W['folder'])
    os.makedirs(folder, exist_ok=True)
    out = {'page.json': {'pages': [entry], 'layout': layout}, 'rows.json': rows, 'texts.json': texts}
    for name, data in out.items():
        save(os.path.join(folder, name), json.dumps(data, ensure_ascii=False, indent=1) + '\n')
    # the chain file in the owners' format (tools/story/extract_chains.mjs formatChains); the links are set by rejoin.mjs --relink
    cf = os.path.join(folder, 'chains.json')
    if os.path.exists(cf):
        old = json.load(open(cf, encoding='utf-8'))
        for c in chains:
            o = next((x for x in old if x['id'] == c['id']), None)
            if o and o['rows'] == c['rows']: c['links'], c['shape'], c['joins'] = o['links'], o['shape'], o['joins']
    save(cf, dump_chains(chains))
    return len(rows), len(chains), len(layout)


CHAIN_KEYS = ['id', 'page', 'section', 'order', 'title', 'lead', 'rows', 'mention', 'twins', 'joins', 'links', 'shape', 'extracted', 'story']


def dump_chains(lst):
    J = lambda v: json.dumps(v, ensure_ascii=False, separators=(',', ':'))
    rec = lambda c: ' {\n' + ',\n'.join(f'  {J(k)}: {J(c[k])}' for k in [k for k in CHAIN_KEYS if k in c] + [k for k in c if k not in CHAIN_KEYS]) + '\n }'
    return '[\n' + ',\n'.join(rec(c) for c in lst) + '\n]\n'


def save(f, textv):
    old = open(f, encoding='utf-8').read() if os.path.exists(f) else None
    if old == textv: print('unchanged', os.path.relpath(f, ROOT)); return
    open(f, 'w', encoding='utf-8').write(textv); print('wrote', os.path.relpath(f, ROOT))


def main():
    for W in (WEIL, PENROSE):
        n = write_way(W); print(W['route'], 'story rows', n[0], 'chains', n[1], 'placements', n[2])
    ways = [
        {'key': 'atiyah-moore', 'page': 'shifted', 'title': {'phys': "Atiyah's way: the shifted view", 'math': "Atiyah's way: the shifted view", 'learner': "Atiyah's way: the delayed waves"},
         'description': "The paper of Atiyah and Moore followed in its own order, nine steps from a prologue to three closing questions (Audit 3).",
         'source': {'author': 'M. Atiyah and G. W. Moore', 'title': 'A shifted view of fundamental physics', 'year': 2010, 'link': 'https://arxiv.org/abs/1009.3176', 'locatorStyle': 'eq.', 'citation': 'M. Atiyah and G. W. Moore, *A shifted view of fundamental physics*, Surveys in Differential Geometry XV (2010), [arXiv:1009.3176](https://arxiv.org/abs/1009.3176).'}},
        {'key': 'weil', 'page': 'ways/weil', 'title': WEIL['title'],
         'description': "Weil's memoir of 1964 read number by number, the labels of a cell in the place of its locally compact abelian group: the clock as the index, the Clifford gates as the automorphisms, the stabilizer states as theta functions, the codes as the subgroups of Theorem 5, the genus average as the formula of the last number.",
         'source': {'author': 'A. Weil', 'title': "Sur certains groupes d'opérateurs unitaires", 'year': 1964, 'link': 'https://doi.org/10.1007/BF02391012', 'locatorStyle': 'n°', 'citation': "A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964), 143–211."}},
        {'key': 'penrose', 'page': 'ways/penrose', 'title': PENROSE['title'],
         'description': "The review of twistor theory at fifty read with the Atlas's method: twistor space from the conformal cell, the incidence relation on exact numbers, the integral formulae as residues, the Lax pair in the review's coordinates; then the passes the programme plans next.",
         'source': {'author': 'M. Atiyah, M. Dunajski and L. J. Mason', 'title': 'Twistor theory at fifty: from contour integrals to twistor strings', 'year': 2017, 'link': 'https://doi.org/10.1098/rspa.2017.0530', 'locatorStyle': '§', 'citation': 'M. Atiyah, M. Dunajski and L. J. Mason, *Twistor theory at fifty: from contour integrals to twistor strings*, Proc. R. Soc. A 473 (2017), 20170530.'}},
    ]
    save(os.path.join(ROOT, 'content', 'ways.json'), json.dumps(ways, ensure_ascii=False, indent=1) + '\n')


if __name__ == '__main__':
    main()
