<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Learner texts of wave 2, part a: `cells` · cards, `clock`, `light` (round 15, storyteller T4a, release 2.16.0)

The storyteller of `docs/round14/STORY_ROUND.md` §7 (`docs/09_TRANSLATION_PROTOCOL.md` §2.2), run on the chains of `docs/round15/SPINE_wave2.md` §4–§6 as composed by C2 (`content/chains/{cells,clock,light}/chains.json`, links from `depends` after A62). Read first: STORY_ROUND §2.2, §3.2 (C1–C11, with the lead's ruling of round 15: "then" is a sequence word and may open an `order` link), §7; SPINE_wave2; OWNER_ANSWERS A60, A63, A64; B1_NOTES; the pilot record `docs/LEARNER_TEXTS_chains.md` and the pilot's spans of `content/chains/learner/cells.json` and `rule.json` (the voice). Every record has the shape of STORY_ROUND §2.2: `lang: "en"`, `level: "learner"`, `lens: null`, `status: "draft"`, `source: "storyteller@2026-10-17"` (the one human span `status: "human"` with its human source); `termsUsed` and `keptNumbers` are computed by the checker's own functions (`deriveFields`), never typed (the human span keeps `[]`, as the human spans of wave 1 do).

## 1. What was written

**All 30 chains are storied; none is left out** (no written piece was rejected by the checker, so D54's fallback applies to none).

| file (`content/chains/learner/`) | chains | spans: told + mentions | human spans | learner texts of the section leads | learner full texts of rows that had none | records written |
|---|---:|---|---:|---|---|---:|
| `cells.json` (added to the pilot's 16 records, none changed) | 20 | 54: 54 + 0 | 0 | ATL-711 | ATL-001b, ATL-002b, CAND-086 | 58 |
| `clock.json` (new) | 4 | 20: 19 + 1 | 0 | LAB-711, LAB-712 | — | 22 |
| `light.json` (new) | 6 | 25: 23 + 2 | 1 (PAG-023) | PAG-711 | — | 26 |
| **all** | **30** | **99: 96 + 3** | **1** | **4** | **3** | **106** |

No chain of wave 2 has a chain lead (`lead: null` in all 30 records), so the leads written are the four section leads, story rows of role `lead`: each at most 300 characters (298, 292, 276, 300), no digit, no claim word of T2, so T1–T5 read each as narration against its section.

- **ATL-711** (`cells` · cards): "Each card names one box by its plus and minus switches, from none to eight, and its other lines say how the Atlas reads it. The stories go card by card, from the plain numbers to light, a stretched frame and the repeat at eight switches. Most names on the cards are readings; the stories say which."
- **LAB-711** (`clock` · clock): "The boxes coloured by kind, and the clock that reads a box's kind from its plus and minus switches. The clock is read three ways: as the angle of one sum over the labels, each with a charge; in surfaces and in chains of wires, the same clock by other routes; and as a count of graded modules."
- **LAB-712** (`clock` · clock-trinity): "Every piece of a box has a square, and the Atlas reads its sign as the motion the piece makes: a turn for minus, a boost for plus, a slide for zero. That reading is followed into three places: a network of springs, the curves of the plane and the orbits of the Kepler problem."
- **PAG-711** (`light` · ladders): "The ladders add one switch at a time to the boxes of Maxwell's equation. Along them: which boxes let a wave travel in time, as the wave-type table says; and in the spacetime box one step of the equation, under a label's three names, its cancellations giving charge conservation and the wave operator."

### 1.1 The chains, position by position

| chain | shape | told | mentions | links (in order) | story / budget (C7) |
|---|---|---:|---:|---|---|
| `cells.cards.empty` | line | 2 | 0 | continues | 500 / 502 |
| `cells.cards.one-plus` | line | 2 | 0 | continues | 637 / 641 |
| `cells.cards.phase` | line | 2 | 0 | continues | 188 / 192 |
| `cells.cards.quaternions` | line | 2 | 0 | continues | 209 / 209 |
| `cells.cards.pauli` | fork | 3 | 0 | order, continues·ATL-006 | 702 / 702 |
| `cells.cards.split-three` | line | 2 | 0 | continues | 275 / 278 |
| `cells.cards.even-spacetime` | line | 2 | 0 | continues | 397 / 399 |
| `cells.cards.spacetime` | cycle | 3 | 0 | cycle, cycle | 836 / 844 |
| `cells.cards.split-four` | line | 3 | 0 | uses-input, continues | 526 / 527 |
| `cells.cards.conformal` | line | 2 | 0 | continues | 302 / 304 |
| `cells.cards.six` | fork | 4 | 0 | continues, continues·ATL-014, continues·ATL-014 | 848 / 848 |
| `cells.cards.pinors` | line | 2 | 0 | continues | 637 / 637 |
| `cells.cards.chiral` | line | 2 | 0 | continues | 285 / 286 |
| `cells.cards.maxwell` | fork | 3 | 0 | order, continues·ATL-017 | 1100 / 1101 |
| `cells.cards.strain` | fork | 4 | 0 | continues, continues·ATL-018, continues·ATL-018 | 1502 / 1503 |
| `cells.cards.row-eight` | fork | 8 | 0 | continues, order, continues, instance·ATL-023, continues, order, continues·ATL-020 | 1092 / 1092 |
| `cells.cards.scalar` | line | 2 | 0 | continues | 261 / 271 |
| `cells.cards.two-six` | line | 2 | 0 | continues | 382 / 387 |
| `cells.cards.types` | line | 2 | 0 | continues | 383 / 391 |
| `cells.cards.peirce` | line | 2 | 0 | order | 969 / 975 |
| `clock.clock.gauss` | cycle | 7 | 0 | equiv, order, cycle·LAB-017, cycle, derives·CAND-057, derives·LAB-022 | 3806 / 3808 |
| `clock.clock.brown` | fork | 3 | 1 (LAB-017) | derives, derives, instance·LAB-018 | 2029 / 2030 |
| `clock.clock.k-theory` | fork | 5 | 0 | derives, equiv, equiv, derives·ATY-026 | 7341 / 7650 |
| `clock.clock-trinity.trinity` | fork | 4 | 0 | instance, instance·LAB-003, instance·LAB-003 | 873 / 875 |
| `light.views.equation` | fork | 6 | 0 | instance, instance, derives, derives, continues·ATL-017 | 1543 / 1545 |
| `light.views.notations` | line | 4 | 0 | order, derives, order | 978 / 979 |
| `light.views.cube` | line | 3 | 0 | order, derives | 444 / 556 |
| `light.views.dual` | line | 3 | 0 | derives, order | 1336 / 1340 |
| `light.ladders.hyperbolic` | line | 2 | 1 (MAP-003) | derives, equiv | 1030 / 1140 |
| `light.ladders.steps` | fork | 5 | 1 (ATL-017) | instance, derives, derives·MAP-036, derives, instance·MAP-038 | 1867 / 1896 |

The openings follow C4 and the round-15 ruling: `continues` "And", "Also"; `derives` "So", "Hence", "From the steps"; `instance` "For instance", "For example", "Take"; `equiv` "In other words", "The same holds"; `cycle` "In turn", "Closing the loop"; `uses-input` "Given those"; the `order` links open freely and never with a derivation or contrast word: "Then an open card" (ATL-019), "Then even pieces" (MAP-013), "Then, from Maxwell to Dirac" (CPL-001), "Spacetime has it too" (CAND-122), "The Hodge–Dirac operator on the bit rule" (CAND-086), "That ratio" (CAND-044), "The rule beneath" (CAND-098), "Underneath, a derivation" (CAND-057), "Beside it" (EQN-001), "On that Boolean lattice" (LNC-056). The weak links say their status in the span (C5): the card readings "ours" (ATL-001b, ATL-002b, ATL-006b, ATL-010b, ATL-017b in both chains, ATL-023b, CPL-010) and "ours and open" or "open" (ATL-003b, ATL-005b, ATL-007b, ATL-008b, ATL-011b, ATL-013b, ATL-014d, ATL-015b, ATL-016b, ATL-018d, ATL-019, ATL-019b, ATL-020c, ATL-021b, ATL-022, ATL-022b, ATL-024b); no status word on a proved row whose research text lacks it (LAB-003, CAND-122: "choosing a time direction", never "a choice"). The three mentions recall in one sentence, with no number: LAB-017 ("Recall: a box's clock is the Brown invariant of its labels with their charge round four places."), MAP-003 and ATL-017 on `light` · ladders.

### 1.2 The full texts

ATL-001b, ATL-002b and CAND-086 had no learner text anywhere (SPINE_wave2 §4: the rows that waited for their wave); each `full` text is its span made to stand alone, with the clauses the chain's budget left out put back: ATL-001b keeps "in every order of the switches" and the reason for every number ("because the sign of the empty label is an empty product"); ATL-002b the box of the pair, the measure of the square, "the pieces that square to themselves and those that square to zero differ between the two" and the reference to row GEN-002; CAND-086 the sign of the partner ("plus the divergence, minus the codifferential"), "whose whole coefficients run from minus 50 to 50" and "with the engine's derivative and star on one side and its connection and curvature on the other". Every side note of the three pages already has a learner text, human or a translator draft (checked one by one: `cells` · cards ATL-004, ATL-009, CAND-001, CAND-011, CAND-012, CAND-037, CAND-045, CAND-058, CAND-104, CAND-126, CAND-138, GEN-011, GEN-031; `clock` LAB-001, LAB-002, LAB-013, LAB-014, LAB-015, LAB-016, PAG-006 (human), LAB-004; `light` RSN-026, EQN-006, CAND-139), so no other full text was due.

### 1.3 Human and reviewed words

- **C10, A63.** PAG-023 (`light.views.cube` · 1) has a human learner text: its span is that text verbatim, `status: "human"`, `source: "storyCopy.js#STORY_YL.en.pages.equations.tags.2.1"`; CPL-001 and CPL-010 carry the connection ("Then, from Maxwell to Dirac …", "So drawing …"). No other told row of the three pages has a human learner text.
- ATL-020b and ATL-020c have *reviewed* learner texts (`lead:L7-04`), not human, so C10 does not bind them: their spans follow those words within the chain's budget, and ATL-020c's span adds the status word "(open)" that its reviewed text lacks (C5: the row is open). The reviewed texts stay the rows' `full` texts.

## 2. The voice

The words of the pilot spans and of the human texts of the pages (ATL-501 "a map of 25 cards, each showing a different box of rules built from the same switches", GEN-507 "a clock with eight places", LNC-101 "a plus switch moves the clock hand forward", PAG-508): a generator is a switch (plus, minus or zero switch by its square), a cell a box, a blade a piece, an address a label, a bivector a plane or a 2-switch piece, the volume element the all-three (all-four, all-switch) piece, a quadratic form on labels a sign form, M₁₆(ℝ) "16 by 16 real grids", ℤ₄ "round four places", mod 8 "round 8 places", the clock sum's phase "the angle of one sum", "the imaginary unit" for i, "the empty label" for label 0 of a blade (the glossary's "label 0" names a zero switch, so the span avoids it), arrow fields (1-forms), "reversion" and "Clifford conjugation" by name. The card titles of C2 give the openings of the cards' first spans ("No switch at all", "Two plus, one minus", "Eight switches"). A row told on two pages has a span in each chain, in the opening its link asks: ATL-017 and ATL-017b (`cells.cards.maxwell`, `light.views.equation`), GEN-018, GEN-022, GEN-031 (`clock.clock.k-theory`, beside their `rule` and `cells` spans, whose words they share: GEN-022 opens "The same holds" on its `equiv` link, GEN-031 "So" on its `derives` link, GEN-018 "In other words" without the `rule` span's reference to a map that `clock` does not tell).

## 3. What bit, and how it was met

- **C7, the budget, everywhere.** The card rows are short and dense with symbols, and a plain word is longer than a symbol: the tight budgets of SPINE_wave2 §10 were met at 188/192 (`phase`), 209/209 (`quaternions`), 275/278 (`split-three`), 285/286 (`chiral`), 261/271 (`scalar`), 302/304 (`conformal`), and four chains end exactly at their budget (`pauli` 702, `six` 848, `pinors` 637, `row-eight` 1092). The trinity of `clock` (875 for four spans, three of them symbol-dense instances) and the `light` views (1545, 979, 1340) took three to five rounds each. Every number, scope and status word is in its span; what was compressed is listed in §4.
- **R6, numbers inside identifiers.** "(683)" alone in parentheses reads as an equation number and is stripped: "from 11 to 16, 683 kinds". "so (up to 5)" reads as the group name so(…): "add thus (up to 5)". A hyphenated number word does not count ("half-rapidity", "two-switch"): "a boost of half the rapidity", "2-switch". "her equation 44" keeps the identifier's number, allowed because the research text holds it; it was dropped later for the budget.
- **C5, the status words.** "our name" does not carry the word "ours" (C5 failed once on ATL-023b in a draft, before writing): "the name … is ours". Open rows whose research text does not say "open" carry it plainly: ATL-019 "Then an open card", ATL-022 "an open card", ATL-020c "(open)", ATL-015b "ours, open". LAB-003 ("reading the signs … as rotation, boost, translation") is computed proved and its research text has no "our reading", so its span has no status word, although its translator draft says "is ours" (§5).
- **R12, names.** A name inside a sentence must be in the row's research text or its parent's: "Kepler" is in neither LNB-023c's nor LNB-023's, so the span says "Take orbits" (the lead LAB-712 names the Kepler problem, from its own research text); "Runge–Lenz" comes from the parent LNB-023; "Maxwell" is not in RSN-025's text ("The field's equation"), "Atlas" is lowercase in ATL-006b's and ATL-010b's ("the atlas's Spatial reading").
- **R4, no symbol.** No lone letter: the corners t, x, y, z are "the time and space corners", n is "every number of switches", W and W′ "the windings", i "the imaginary unit"; sl(2,ℝ), SL(2,ℂ), M₂(ℍ) become "real sl(2)", "complex SL(2)", "2 by 2 quaternion grids"; 10̄ is "conjugate 10".
- **The words rule.** Every draft was screened before writing, every 40-character run at every offset, against the strings the pages draw outside statements (`content/*.json` but the text, row and learner tables, the `explore`, `physics`, `story` and `tuning` folders but their text records, `src/`, the three chain files): eighteen runs in fifteen drafts were found and rephrased before any write — the cell list of CAND-078 against the check statement `polar·L1` (`checks.json`) and `candidates.json`; ATL-014 "the conformal algebra of Minkowski space" (`candidates.json`); ATL-012 "the opposite convention, a mismatch of" (`sources.json`); LNS-012 "a hyperbolic direction exists exactly" (`conventions.json`, `story_frames.json`); and runs of CAND-086, LAB-017, CAND-057, GEN-018, RSN-010, LNB-023c, EQN-018, PAG-036, PAG-037, CPL-010 and LNC-056. Two families of hits were spurious and left the screen: `content/story/retired_texts.json` (retired drafts, never drawn) and the text records of `content/explore/` and `content/physics/` (statements, like the spans). The final screen of the 105 draft records finds none, `node tools/check_notes.mjs` (rule G) passes, and `tests/coverage.test.mjs` passes after each page.

## 4. What the budget cost

Method detail and locators, never a number, a scope or a status word; the rows' research texts and drawers keep everything, and the three full texts keep their clauses.

- **Cards.** The cell addresses ([0,0] … [8,−4], identifiers the cards print) throughout; ATL-002b "idempotents and nilpotents differ" and "(GEN-002)" (both in its full text); ATL-003b "(the 'clock' of the fiber)"; CAND-122 the product I = γ₀γ₁γ₂γ₃ folded into "the pseudoscalar" and the tensor components into "as in the field tensor"; ATL-012 "(γ₀² = +1)" told once, in ATL-010's span, and "in which time squares to +1" folded into "the opposite convention"; ATL-013 the pointer "used in step 11"; ATL-014 Cl(5,1)'s type M₄(ℍ) ("Cl(5,1) is another box"); ATL-014b "a cell different again" as "another box"; ATL-015b "(particle-hole, XOR with 1…1)" as "flipped labels"; ATL-016b "(the grade involution of the spatial algebra)" as "a reflection in space's algebra"; CAND-086 the codifferential's sign formula and the engine's two sides (full text keeps both); ATL-018b the transformation law in words ("picks up the map's determinant and inverse"), "uniform" before "10001 values", and the four failing controls as "four wrong variants fail"; ATL-018c the general counts n² and n(n+1)/2 told by their case at 4 directions ("16 parts through 10") and "at every covector"; ATL-020b "(her eq. 44)"; CAND-044 the traces 2 and 16/3 told in the neighbouring span (its 2 kept as "two traces") and the reference SHP-005; ATL-022b "(for GL(n,2) a prime p enters when n is the order of 2 modulo p)"; ATL-024 "(step 1)"; CAND-098 "(e = 0, or (1 + e)/2 in ℝ ⊕ ℝ)" as "a non-full one spans less" and the names "(Lam; Jacobson)".
- **Clock.** The check ids (core·B1 … bd·fk·1–3) as their scopes; the theorem and lemma numbers of LAB-018 (Kirby–Taylor Thm 3.2, Lemma 3.6, Debray–Gunningham Thm 3.12, 3.15, Taylor Thm 2.5) and "the characteristic vector 1…1"; CAND-057's derivation formulas and its controls named as "with controls"; ATY-033's θ(−1/z) formula ("a finite theta law") and the standard route's charge; LAB-023 "e^{−β}"; EQN-018 "x″ = −Lx", "(step 15)" and "(series at n = 3)"; LNB-023c "(M = e at E = 0)" and the family m(c) as "one Inönü–Wigner family"; RSN-010 the element a e₁ + b e₂ + c e₁₂ and S + W e₁₂₃₄ in words; ATY-026 "Table 2" and "the ring ℤ[μ]" folded; GEN-018 "and the swap (GEN-013)".
- **Light.** PAG-037 the boost and the field-mixing formulas ("a boost of half the rapidity", "the textbook law"); PAG-036 "in rational arithmetic" (its "exactly" kept); ATL-017 on `light` "2 by 2", "4 by 4" and "Calibration 1" (the page is Calibration 1; its `cells` span keeps both grid sizes); MAP-003 the formula n·C(n,2) (the six counts kept); MAP-004 "(Calibration 1)"; MAP-036 "of piece, direction and drop or add"; RSN-025 the formula ½(Fu − uF) in words.

## 5. For the owner and the lead

- **PAG-023's human words** are a v15 tag fragment ("drawing the pieces of each equation as edges and corners of the cube, and a speed trick …", lowercase, no final period); as the first span of `light.views.cube` they open the paragraph as a fragment. C10 keeps them verbatim; a sentence of the owner's would read better there.
- **LAB-003's translator draft** says the reading of the signs "is ours", while the row's computed status is proved-by-atlas and its research text names no "our reading"; the span follows the status (no status word). The owner may want the research text to say whose reading it is.
- **The inputs fold of `light`** (`needs`: INP-001, INP-002, INP-003, INP-005, INP-006, INP-009, INP-010, INP-012, CAND-115) has no learner text; at learner level `Statement` draws nothing for them. They are not side notes of a storied section (the inputs sections are outside the chains, E1), so this run wrote none; a learner pass on the inputs is open.
- **C7's 0.8 on the card rows**: the short symbol-dense rows (the cards, the trinity, the `light` views) cost most of the compressions of §4. The owner's open question of a 0.9 budget (HANDOVER §3) would let §4's card and trinity items back into the spans.
- **A concurrent build**: `sh build.sh` starts with `rm -rf dist`; the first run of `tests/ui/chains.smoke.test.mjs` after `cells` failed (404s in parts 2 and 3) while another owner's build replaced `dist/`, and passed when run again on a quiet `dist/`.

## 6. The commands, and their last lines

| step | last line |
|---|---|
| `node tools/check_learner_texts.mjs --explain <chain id>`, for each of the 30 chains | the worksheets (budget, links and C4 words, C5 words, R6 numbers, R8 words), read before each chain was written |
| drafting: the checker's own functions (`check`, `checkChains`, `deriveFields`) on the drafts with the whole learner set, the C7 measure and the 40-character screen, before each write (as T3m did) | each written piece passed; no piece was rejected after writing |
| `node tools/check_learner_texts.mjs --file content/chains/learner/<page>.json` after each piece (cells 13 pieces, clock 4, light 5), and once more on `clock.json` after a re-reading put back into LNB-023c's span the paper's case ("so(4) below zero, the paper's case"), first left out for the budget | `PASS: all 24 rules hold for every record` (cells 74 records, clock 22, light 26) |
| `node tools/check_learner_texts.mjs` (every learner file together, R3 across files) | `check_learner_texts: 1551 records in content/texts_learner*.json and content/chains/learner/*.json (… spans of cells 69, spans of clock 20, spans of light 25, …)` · `PASS: all 24 rules hold for every record` |
| `npm run content` (after each page; last run) | `merge_chains --check: 75 chains on 10 page(s), 75 storied (0 reviewed), 310 spans; round-14 rows: 45 story rows, 13 statement rows` (no warning left for a lead without a learner text) · `validation errors 0, warnings 0` · `errors 0, warnings 0; see docs/COVERAGE.md` |
| `node tests/coverage.test.mjs` (after each page; last run) | `chains (round 14): … 43776 statements of chains read with their chain, 16560 connective words within 24 characters, 2232 status lines within 60, 5400 story paragraphs of statements only, 10800 chain titles free of row words` · `PASS: every statement is a text record of its row; no KaTeX at learner level; badges as computed; …` (PASS after `cells`, after `clock`, after `light` and on the last tables) |
| `node tests/story/composition.test.mjs` (after each page) | `PASS: every composed section reads lead → figure → captions → key results (at most N) → "More statements"; titles are names; …` |
| `node tools/check_notes.mjs` | `check_notes: 11 of 11 rules pass` |
| `node tests/chains.test.mjs` (B1's; not a gate of this brief) | `chains: 8540 checks; 17 pilot chains, 75 merged; 144 renders (1040 chains: 520 lists, 1528 connectives, 216 mentions, 512 stories, 8 fallbacks)` · `PASS: the extraction gives its fixture and SPINE.md §4's drafts, deterministically; …` |
| `sh build.sh` | `dist: 872 files, 52.57 MB — app.js 976.4 kB (298.9 kB gzipped), app.css 118.8 kB, content 23.54 MB, …` · `export_tuning: 1,897 records, 3,886 texts, 367 checks and 624 runs, 35 lenses, 7.34 MB in dist/content/tuning/` |
| `node tests/ui/chains.smoke.test.mjs` | `chains.smoke: 356 checks; 6 screenshots (…)` · `PASS: the chains render at both levels, in both themes, at 390 and 1366 px, without overflow or console error: …` (after each page; the first run after `cells` met a concurrent rebuild of `dist/`, §5) |
| a look at learner level (Playwright on `dist/`, `#/cells?l=learner`, `#/clock?l=learner`, `#/light?l=learner` at 1366 px light, 390 px dark and light) | `cells` 23 chains, 23 storied (69 statements in the stories, 22 badges); `clock` 4, 4 (20, 0); `light` 6, 6 (25, 2); no chain list, no loose text node in a story, 0 px of overflow and 0 console errors at each setting; the four section leads drawn in their learner words |
