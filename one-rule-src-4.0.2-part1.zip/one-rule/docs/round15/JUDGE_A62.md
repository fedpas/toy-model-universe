<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The judge's verdicts on the labelling pass A62 (round 15, judge J2)

The verdicts of `docs/round15/PLAN.md` §2.5 on the 270 entries of `content/story/depends_a62.json` (the proposals and their clauses: `docs/round15/LABELLING_A62.md`). Read on the tables of 2.15.0 (`content/rows.json`, `texts.json` of 17 Oct, 20:08). The judge changed no table and no text: each entry of the overlay now carries a `verdict` and a one-line `why`; this record gives the method, the rulings received, the verdicts task by task with the deciding clauses, the counts, the notes for the owner and the list R8 applies. "A on B" means A rests on B, as in the labeller's record.

**In short.** Task 1: 3 accepted, 1 rejected (GEN-008 on GEN-007, the weak rung). Task 2: 8 accepted, 1 rejected (LNS-038 against CAND-144: CAND-144 answers LNS-038's open question, a note for the owner). Task 3: 9 accepted (8 drops, 1 set-cycle); directed cycles 7 → 0. Task 4: 15 accepted as `equiv` (the 5 twins, the 8 physicist's lines of `bz-persp`, GOS-006b, SRC-003b), 233 rejected under the amendment. The extraction after the accepted entries: chains 211 → 215, rows in chains 784 → 798, side notes 315 → 301, singletons 356 → 342, sections of three rows or more without a chain 14 → 11, directed cycles 7 → 0; `merge_chains --check`: the 41 shipped chains pass, one warning (`rule.ideas.genesis` link 1).

## 1. Method

1. **Read.** PLAN §2; the labeller's record; the overlay and its `_about`; `docs/LABELLING_SCHEME.md` §4; `docs/labelling/JUDGE_LOG.md`. For every entry, the research texts of both rows (`content/texts.json`, level research) with their homes, cells, depends and evidence (`content/rows.json`), and where a clause rests on a check, the check's statement (`content/checks.json`: catl·C1–C4 and opn·CONJ for cycle 2; chn·11 and elad·22 for a note of §8).
2. **The test.** An entry is accepted when a clause of each text says the dependence, in the direction and with the relation proposed; adjacency, a shared object, theorem or input is not one (SCHEME §2, E8). The tables quote the deciding clause of each text where the judge differs from the labeller and where the lead asked for a decision; elsewhere the labeller's clauses were checked and stand (the `why` of each entry names them).
3. **Task 4.** All 248 lines read against their first lines: first ranked by the share of a line's words found in its first line (so that no near-verbatim line is missed), then every line read in full.
4. **Re-measured, as the labeller did.** `content/`, `tools/` and `package.json` copied twice into the scratchpad; the accepted entries applied to one copy's `rows.json` with a few lines of node (26 adds, 8 drops, 1 set-cycle; no turn, no changed relation); `tools/story/extract_chains.mjs --counts` and `tools/merge_chains.mjs --check` run on both copies; the directed cycles counted as the strongly connected sets of `derives`, `instance` and `uses-input` over all rows (SPINE §5.4). The unchanged copy gives the labeller's "before" table byte for byte. A third copy with tasks 1–3 alone isolates task 4.
5. **The verdict's form.** `verdict` is "accept" or "reject" on every entry: no entry is turned and none changes its relation, so neither the `_about`'s `{ "rel": … }` nor the lead's string form ("equiv", "derives", …) is used. `why` is written after `verdict` in the tool's one-entry-per-line format (`formatOverlay` of `tools/story/split_edges.mjs`); nothing else in the file changed.

## 2. The rulings received

The lead's, binding on this pass (recorded as theirs, not the judge's):

- **(i) Task 4, the split lines.** The labeller's amendment is accepted: no `equiv` edges for the 248 split lines (most lines are further statements, not restatements); every task-4 entry is rejected with the reason "amendment: the extraction keeps reading splitFrom as continues", except a line whose text restates its first line verbatim or nearly, accepted as `equiv`; LNB-025c's `derives` is rejected (its "So" follows from LNB-025b, not from its first line).
- **(ii) "Then" is a sequence word, not a derivation word.** C4's derivation set (`CONNECTIVES.derives` of `tools/check_learner_texts.mjs`) loses "then"; R8 makes the change. An `order` link may open with "then" or "next"; a `derives` link with "so", "hence", "therefore", "it follows", "thus".
- **(iii) The off-rung edges of the genesis** (GEN-007 on GEN-003, GEN-006 on GEN-004) **and the weak rung** GEN-008 on GEN-007: accepted only if both texts support them; a weak edge is worse than an `order` link.
- **(iv) Cycles and the open decisions.** Cycles 1 and 2: drop or set-cycle on the texts (does each use the other? if not, drop). LNS-038 against CAND-144: `contradicts` or `derives`; if CAND-144 answers what LNS-038 calls open, LNS-038's "open" is out of date: a note for the owner, and the edge rejected (a `contradicts` edge between a question and its answer is not what the scheme means). CAND-040 and CAND-042 on NUL-010: `derives` or `equiv`, on the texts.

## 3. Task 1 — the genesis ladder

| entry | proposal | verdict | the deciding clauses |
|---|---|---|---|
| GEN-002 on GEN-001 | derives (rung 0 → 1) | **accept** | GEN-001 "the reference element every later algebra is built on"; GEN-002 "One null generator (e²=0): a grade-1 filtration step" (home ℝ[ε]/(ε²): ℝ·1 and one null generator). The construction of node 1 uses node 0. Only this rung gets GEN-001's edge (E8: not a hub). |
| GEN-006 on GEN-004 | instance (off the rungs) | **accept** (iii) | GEN-006 "Cl(2,2,1): the same role as Node 3 with a bigger block" names node 3, which is GEN-004, "Cl(1,1,1): one fused pair and one null generator (radical)": the same construction with a pair-block, PLAN §2.1's `instance`. No link of the ladder changes (GEN-006 links from GEN-005). |
| GEN-007 on GEN-003 | derives (off the rungs) | **accept** (iii) | GEN-007 "Three Witt Pairs. Cl(3,3)=M₈(ℝ) … Three pairs do not carry …"; GEN-003 "A pairing {n,ñ}=1 is added … one generator of each sign" (home: the Witt pair). Cl(3,3) is three of GEN-003's pairs, as GEN-005's "Four nulls give two Witt pairs" is two (GEN-005 on GEN-003, in 2.15.0). Rung 5 → 6 links `derives·GEN-003`. |
| GEN-008 on GEN-007 | derives (rung 6 → 7) | **reject** (iii) | GEN-008's split is "The central involution ω=e₁…e₇ (ω²=+1) splits the algebra into two sectors"; its "the leftover switch given the sign +1" is said of "Cl(1,0), Cl(2,1), Cl(3,2)", not of node 6, and nothing in GEN-007 ("Cl(3,3)=M₈(ℝ), dimension 64") is used by the split. M₈(ℝ) in both is a shared object; neither text names the other. Rung 6 → 7 keeps `order`. |

**Rung by rung, after the verdicts** (the mechanical links of GEN-001 … GEN-009 on the changed copy): `GEN-001 —derives→ GEN-002 —order→ GEN-003 —derives→ GEN-004 —derives·GEN-003→ GEN-005 —derives→ GEN-006 —derives·GEN-003→ GEN-007 —order→ GEN-008 —order→ GEN-009`, shape ladder.

- 0 → 1 `derives` (accepted above).
- 1 → 2 `order`: both texts deny the step, GEN-002 "not one of the paired nulls of the Hyperbolic Plane", GEN-003 "an extra datum, not a consequence of the null seed"; the pairing is the input GEN-003 uses (INP-011, INP-013).
- 2 → 3 `derives`, 3 → 4 `derives·GEN-003`, 4 → 5 `derives`: the edges of 2.15.0, confirmed on the texts.
- 5 → 6 `derives·GEN-003` (GEN-007 on GEN-003, accepted).
- 6 → 7 `order` (rejected above).
- 7 → 8 `order`: GEN-009's "Cl(n+8)=Cl(n)⊗M₁₆(ℝ), so the types repeat" names no cell of node 7; no entry.

Three rungs keep `order`; under ruling (ii) their spans may open with "then" or "next". Not entered, and so not judged: GEN-004 on GEN-002 (the labeller's "noted"); on my reading both texts support it (GEN-002 "the unpaired null (the radical, the label 0 of the later pages)", GEN-004 "one null generator (radical)"), off the rungs, for a later pass if wanted.

## 4. Task 2 — the seven sections that are not lists

| entry | proposal | verdict | the deciding clauses (where asked or where the judge differs) |
|---|---|---|---|
| EQN-018 on LAB-003 | instance | **accept** | "the three kinds of i as oscillator, inverted oscillator, free motion" against "reading the signs −1, +1, 0 of a square as rotation, boost, translation" |
| RSN-010 on LAB-003 | instance | **accept** | "ellipses, parallel lines, hyperbolas, that is rotation, translation, boost" (n = 2) |
| LNB-023c on LAB-003 | instance | **accept** | "so(4), e(3), so(3,1) for E < 0, = 0, > 0" · "For ε = 0 the fourth generator is null: its square is 0": the rotation, translation and boost algebras by the sign of a square (LNB-023d: "what agrees is the class of the bivectors") |
| CAND-040 on NUL-010 | derives | **accept** (iv) | CAND-040 restates NUL-010's "n(n−3)/2 more (2 at n = 4) at a null covector" and uses it: "so a plane wave with such a polarisation solves the linearised equation", then the helicity "on the exact plane wave". NUL-010 ("d2_linearised", run on its own) uses nothing CAND-040 adds. The two rows do not say the same thing: `derives`, not `equiv`. |
| CAND-042 on NUL-010 | derives | **accept** (iv) | CAND-042 restates NUL-010's "the expansion of a null geodesic congruence obeys dθ/dλ = −θ²/2 − σ² + w² − R_ab N^a N^b … (23 rows)" and derives from it, with the energy condition, "twist-free congruences have dθ/dλ ≤ −θ²/2 − σ² (the local focusing inequality)"; the FRW rays and the dust and radiation frames are its own. `derives`, not `equiv`. |
| SPR-003 on SPR-002 | derives | **accept** | "masses, springs and closure", "the signs as flux π", "the step 5 labels as normal modes" read SPR-002's "Hooke's law, the spectrum of the hypercube (Walsh functions), the compatibility of strain … the signed matrix with D² = n·I" |
| SPR-004 on SPR-002 | derives | **accept** | "the signed network is D = Σ_k (c_k + c_k^†) …: flux π per face and D² = n·I are the Clifford relation" takes SPR-002's "the signed matrix with D² = n·I" |
| LNB-032 on CAND-105 | derives | **accept** | "with theta series 1, 6, 0, 6, …" is CAND-105's "the theta series of the hexagonal lattice begins 1 + 6q + 6q³ + 6q⁴ + …" (r(N) to 10⁴); CAND-105 uses nothing of Lemma 2 |
| LNS-038 against CAND-144 | contradicts | **reject** (iv) | LNS-038 "the finite shadow of the spectral theorem (commuting blades of square +1 and their projectors): the counts are done in the category chapter; the link to contextuality is open" (cells (2,2,0), (p,q,0)); CAND-144 "In Cl(2,2) the nine blades of square +1 form a 3 × 3 grid of six commuting triples whose six products have sign product −1 under all 512 re-signings; none of the 512 ±1 assignments fits (checked, exhaustive)" (home: "The Peres–Mermin square proves contextuality"). CAND-144 answers the question in LNS-038's first cell; the question does not rest on the result. LNS-038's "open" is out of date (§8.1). No edge. |

**The sections.** `clock` · clock-trinity, `steps/nullsurf` · eq-nullsurf and `steps/spring` · eq-spring each gain a chain (drafts: `LAB-003 —instance→ EQN-018 —instance·LAB-003→ RSN-010 —instance·LAB-003→ LNB-023c`; `NUL-010 —derives→ CAND-040 —derives·NUL-010→ CAND-042` with NUL-008, NUL-009 attached; `SPR-002 —derives→ SPR-003 —derives·SPR-002→ SPR-004`); in `steps/baez` · bz-persp CAND-105 leaves the side notes for LNB-032's chain; `steps/schuller` · sc-quantum stays without a chain (its six rows side notes, the numbered list its texts make). The two sections without entries were read too: `steps/forque` · eq-forque (each FRQ note speaks of the step's table, none of another note) and `steps/schuller` · sc-thm (each of LNS-058 … LNS-062 restates one theorem) are lists by their texts; the judge agrees that nothing is to be proposed there.

## 5. Task 3 — the seven directed cycles

All nine entries accepted. For each cycle, the way the dependence runs and the clause that decides; in cycles 1 and 2 only one row uses the other, so the edge is dropped, not set to `cycle` (ruling iv).

| # | rows | entry | verdict | the dependence runs | the deciding clauses |
|---|---|---|---|---|---|
| 1 | FUR-003, FUR-006 | drop FUR-003 on FUR-006 (derives) | **accept** | FUR-006 rests on FUR-003, one way | FUR-003 computes its axes "in the standard basis" ("their 16 joint eigenspaces are the coordinate axes of V", grades 0, 4, 8, "616 diagonalize all block projectors"), with none of FUR-006's signs; FUR-006 uses FUR-003's commuting blades: "The seven Fano-line blades … with the signs of the bit rule, generate a group of 32 elements". Not a `cycle`: FUR-003 does not use FUR-006. |
| 2 | LNB-029c, LNB-179 | drop LNB-029c on LNB-179 (derives) | **accept** | LNB-179 rests on LNB-029c, one way | LNB-029c is computed on its own (catl·C1–C4: the Casimirs on 3 × 3 matrices and on the colour bits; its 3̄ on 3 × 3 matrices is the standard dual); no clause uses LNB-179's flip "C = c₂c₃c₄"; LNB-179 uses LNB-029c's values: "Across it the symmetrised cubic Casimir changes sign, d_abc T_a T_b T_c = 10/9 on b = 1 and −10/9 on b = 2". Not a `cycle`. |
| 3 | LNB-015, LNB-106 | drop LNB-015 on LNB-106 (uses-input) | **accept** | LNB-106 rests on LNB-015 (its `derives`, kept) | LNB-015 "the canonical anticommutation relations hold and the number operator is the popcount" names no piece and uses no convention; LNB-106 "The names of the pieces … a sign convention" names the pieces of LNB-015's Fock space. The convention is used by the lines LNB-015e ("(3,2), (3̄,1) twice …") and LNB-015f ("Convention: …"), which keep their edge. |
| 4 | GRV-012, INP-056 | drop INP-056 on GRV-012 (derives) | **accept** | GRV-012 rests on INP-056 (uses-input, kept) | INP-056's "used inside the one-function radial Kerr–Schild class, where Schwarzschild is derived" restates GRV-012's class (the `equiv` edges, both ways, kept); its own clause, "elsewhere the metric is put in, not derived", is the input GRV-012 uses: "Step 12 takes the Schwarzschild solution from the literature … the Painlevé–Gullstrand form and Kerr are still put in". An input stays an input. |
| 5 | GRV-011, MAT-007, INP-050 | drop INP-050 on MAT-007 (derives) | **accept** | GRV-011 and MAT-007 rest on INP-050 (uses-input, kept); INP-050 — GRV-011 stays the declared `cycle` (κ = 8πG by the Newtonian limit) | INP-050's "E_a + κT_a = 0 holds exactly when s = κQ²/4" restates MAT-007's "so E_a + κT_a = 0 when s = κQ²/4" (the `equiv`, kept); its own clause, "a free constant of the action L_grav(c) − κL_m", is what MAT-007 and GRV-011 ("the size of κ is a free parameter") use. |
| 6 | EQN-012, GRV-006, GRV-010, INP-044, INP-045, INP-048 | drop EQN-012 on INP-044 (uses-input); set-cycle INP-045 on GRV-010 (derives → cycle) | **accept** both | GRV-006 on INP-045, GRV-010 on INP-048, INP-048 on INP-044 (the statements rest on the inputs); INP-044 on GRV-006 (its "solved for ω in closed form"); INP-045 — GRV-010 mutual | EQN-012 "R = dω + ¼[ω,ω], T = de + ωe · step 9; identities worked out for all n" holds for any e and ω and uses no action; INP-044 uses EQN-012's definitions ("with R = dω + ¼[ω,ω] and T = de + ωe"), the other way round. INP-045's frame ("A tetrad e on a chart … gauge under Pin(1,n−1)") is used by GRV-006 and so by GRV-010, and its covariance clause uses GRV-010's Einstein form: "E_a(L e) = det(L)(L⁻¹)^b_a E_b(e), with the connection recomputed from L e" — an input and the theorem that makes it a gauge, the scheme's `cycle` (a split of INP-045 would make it one way, §8.2). |
| 7 | CPL-010, PAG-023, YM-008 | drop PAG-023 on CPL-010 and on YM-008 (derives) | **accept** both | CPL-010 and YM-008 rest on PAG-023 (instance, kept) | PAG-023 "reading the derivative and coupling terms as edges and corner simplices of the cube (ours)" is the general reading and "the 2ⁿ vertices of a box come from n + 1 sandwiches" uses neither case; CPL-010 ("Drawing the derivative, coupling and mass terms as edges of the cube") and YM-008 ("the closed index triples as triangles of the simplex") are its cases. |

Four of the seven close through `uses-input` (3, 4, 5, 6). In 4, 5 and 6 an INP row rested on a row that uses it; in each the dependence runs from the input to the statement, and what ran back was a restatement (4, 5: `equiv`, kept), a definition used the wrong way round (6: EQN-012), or an input whose own clause is justified by the theorem that uses it (6: INP-045, now `cycle`). Cycle 3 closes through a convention that belongs to two later lines of the row, not to its first line. After the nine changes no directed cycle is left (§7).

## 6. Task 4 — the split lines

Ruling (i) applied to the 248 lines, every one read against its first line. **15 accepted** as `equiv`, each restating its first line verbatim or nearly:

| line | first line | why |
|---|---|---|
| FUR-001b, FUR-002b, FUR-003b, FUR-004b, FUR-005b | FUR-001 … FUR-005 | twins (V5): the mathematics copy of the first line, its text word for word (FUR-003b entire; the others with a sentence or two added: the centralizer dimensions, the capacity count, "Hence no single torus generator relates ω and ω′", the 3/8 remark) |
| GOS-006b | GOS-006 | GOS-006's text nearly word for word, with more ranges, and its "In general (ours)" claim restated as "the lemma CAND-101" with its checks |
| LNB-030b | LNB-030 | "This may be a short remark for Section 5.1 of the Jordan-pair paper", with "Peirce value = 1 − d/4 on five-bit labels", asked |
| LNB-031b | LNB-031 | "the su(3)+su(2) content of each rung" as a table beside the two chains, asked |
| LNB-032b | LNB-032 | "That lattice is … the Eisenstein lattice of the triangulation note", asked (Thurston's stars are that note's lattice) |
| LNB-033b | LNB-033 | LNB-033's second sentence nearly word for word: "yes for the 90 = 3 ⊗ 15 ⊕ 3̄ ⊗ 15̄", the completing root vectors in sl₃, the span 98 |
| LNB-034c | LNB-034 | "Could hydrogen be read as a Jordan-pair quantum system?", word for word in LNB-034, with M₂,₂ one row below M₃,₂ |
| LNB-035b | LNB-035 | LNB-035's computation condensed: the f₄ copy in an so(9), the e₇ copy in none, not conjugate in e₆, conjugate su(3)s |
| LNB-036b | LNB-036 | "Real 10 vs complex 10: … no mechanism connects them", asked and answered "we found none" |
| LNB-037b | LNB-037 | "the Frobenius forms of label algebras might serve as a finite test case", asked |
| SRC-003b | SRC-003 | SRC-003's first sentence in other words: "the k-th level is the functor category Fun(B_k, C)", checked on six base categories |

**233 rejected**, `why` "amendment: the extraction keeps reading splitFrom as continues"; for six of them the `why` adds a word:

| line | first line | why the line is not a restatement |
|---|---|---|
| LNB-025c | LNB-025 | ruling (i), confirmed on the texts: "So the exterior algebra … is Frobenius through its top form and not through its scalar part" follows from LNB-025b ("the scalar-part form … is non-degenerate exactly when no generator is null"), not from LNB-025's gluing rule "e₁e₂ · e₂e₃ = ε₂ e₁e₃". The edge LNB-025c on LNB-025b is a sibling edge outside the rule (not entered). |
| CPL-007c | CPL-007 | a narrowed question ("What the copies of the Dirac field from n = 5 stand for …; whether the grade-5 part … vanishes at some ψ ≠ 0 for n = 7 and 8") that rests on the answers CPL-007b and CPL-007d |
| LNB-023b | LNB-023 | the same brackets computed in the bit rule ("[L,L] = L, [L,M] = M and [M,M] = εL") with the Killing counts: a parallel statement; the identification with LNB-023's Poisson brackets is made in LNB-023c |
| NUL-001c | NUL-001 | "Checked again … on Reissner–Nordström": new values (1/9, −1, 2/49, −2/9, 0) and new properties (expansion, shear, twist zero), not NUL-001 restated |
| LNC-098c | LNC-098 | the question narrowed after LNC-098b's "Pointwise, yes", not LNC-098's question |
| LNS-064b | LNS-064 | the contrapositive of LNS-064 in other words ("Boxes whose switches are all plus or all minus fail; so do boxes with at least two of each kind"): logically a restatement, but not near-verbatim, so rejected under the letter of (i); the lead may accept it as `equiv` in one line |

The labeller's sample counted four restatements; one is accepted (LNB-030b), three are not (CPL-007c, LNB-023b, NUL-001c, above). The flags: the 5 twins and the 5 question lines accepted; the 24 reading lines rejected (the amendment's `derives` for readings is not part of the lead's ruling: they keep `continues`); the 2 near lines rejected. The rejected lines by group: ATL 26, CPL 3, GOS 2, GRV 5, INP 2, LNB 98, LNC 13, LNS 65, MAP 1, MAT 1, NUL 5, PAG 2, PRJ 1, RSN 4, SHP 1, SRC 1, YM 3 (each with its verdict in the overlay).

**Effect.** With E2b the counts do not move (E2b joined each line to its first line already); without E2b, chains 159 → 166 and singletons 571 → 556 against tasks 1–3 alone. In the drafts the link between an accepted line and its first line reads `equiv` instead of `continues` (`bz-persp`: `LNB-030b —equiv←→ LNB-030` and its seven siblings; GOS-006b; SRC-003b); the twins ride with their parents (E1) and change no link.

## 7. The counts, before and after

`tools/story/extract_chains.mjs --counts` (E1–E9, MAX = 8) on copies of the tables: before = 2.15.0 (the unchanged copy, equal to the labeller's "before"); after = the accepted entries applied. The labeller's column takes every entry as accepted, for comparison.

| | before (2.15.0) | after the accepted entries | the labeller's, every entry |
|---|---:|---:|---:|
| chains | 211 | 215 | 215 |
| rows in chains (+ attached) | 784 (+ 41) | 798 (+ 41) | 799 (+ 41) |
| side notes | 315 | 301 | 300 |
| singletons | 356 | 342 | 341 |
| sections of ≥ 3 rows without a chain | 14 | 11 | 11 |
| chains · singletons without E2b | 154 · 586 | 166 · 556 (tasks 1–3 alone: 159 · 571) | 215 · 341 |
| directed cycles (`derives`, `instance`, `uses-input`, all rows) | 7 | 0 | 0 |
| shapes | cycle 5, fork 83, line 123 | cycle 5, fork 86, line 124 | cycle 5, fork 86, line 124 |

The one row of difference with the labeller's measure is GEN-008, a side note of `rule` · ideas while rung 6 → 7 keeps `order`.

- **Where it moves.** `rule` 3 → 4 chains, 26 (+ 2) → 29 rows in chains, side notes 7 → 6, singletons 9 → 6 (C1 `GEN-001 —derives→ GEN-002`; GEN-003 … GEN-007 in one fork with GEN-015, GEN-020, GEN-030; side note GEN-008); `clock` 2 → 3 chains, 15 (+ 1) → 19 (+ 1), side notes 11 → 7; `steps/nullsurf` 1 → 2 chains, 6 → 9 (+ 2), side notes 17 → 12; `steps/spring` 0 → 1 chain, 0 → 3, side notes 6 → 3; `steps/baez` rows in chains 177 → 178 (+ 5), side notes 41 → 40, without E2b 24 → 32 chains. Every other page gives the same draft.
- **The 11 sections left without a chain**: `rule` · conventions, `steps/nullsurf` · summary, `steps/forque` · eq-forque, `steps/category` · cat-deadends, `steps/baez` · bz-honest and · bz-questions, `steps/schuller` · sc-quantum, · sc-honest, · sc-notes and · sc-thm, `matter/help` · questions; the three that gained one are clock-trinity, eq-nullsurf, eq-spring.
- **The waves** (chains [without E2b]; sections of ≥ 3 rows without a chain): wave 1 31 → 32 chains; wave 2 36 [20] → 37 [21], 2 → 1; wave 3 20 [17] → 20 [17], 1 → 1; wave 4 13 [12] → 14 [13], 2 → 1; wave 5 8 [8] → 9 [9], 2 → 1; wave 6 102 [64] → 102 [72], 7 → 7; waves 2–6 179 [121] → 182 [132], 14 → 11.
- **The shipped chains.** `tools/merge_chains.mjs --check` on the changed copy: 41 chains on 6 pages, 196 spans, no error; one warning, `rule.ideas.genesis` link 1 (GEN-001 → GEN-002): "an order link, but depends has an edge (derives)". Link 6 (GEN-006 → GEN-007) now has `derives·GEN-003` too and is not warned (the check reads adjacent pairs). When C2 or R8 re-links links 1 and 6, the spans of GEN-002 ("One lonely switch …") and GEN-007 ("Six switches make …") need an opening of C4's derives set ("From this …", "From the pairing again …"); links 2, 7 and 8 stay `order`.

## 8. Notes for the owner

1. **LNS-038's "open" is out of date.** LNS-038 says "the link to contextuality is open" for the commuting blades of square +1; CAND-144 (since v2.4.2) shows that the nine blades of square +1 of Cl(2,2), LNS-038's first cell, form a Peres–Mermin square with no consistent ±1 assignment (exhaustive). The wording is the owner's (A6): settled in Cl(2,2); whether "open" is meant for the other cells (p,q,0) its cells list is the owner's to say. No edge is written. Round 1 recorded the same pattern, LNS-037 against T15, as `contradicts` with a review note; under ruling (iv) it would be a note like this one (outside this pass).
2. **INP-044 and INP-045 are rows to split.** Each holds an input and checked identities in one text. INP-045: the frame on a chart (the input GRV-006 uses) and the covariance law of the Einstein form (which rests on GRV-010; the reason for the `cycle`); split, the input line stays an input and the covariance line rests on GRV-010, one way (ATL-018b states the same law as a further line of the strain card). INP-044: the Einstein–Cartan action (the input) with "solved for ω in closed form" (resting on GRV-006), the Bianchi checks (EQN-012's and GRV-002's results again) and the topological companions.
3. **GRV-002 on INP-044, outside any cycle.** GRV-002 rests on INP-044 by `uses-input`, but its identities are "derived for every n from three facts about the bit rule: the product is associative, d d = 0, d is a graded derivation"; no clause uses the action — the pattern of EQN-012's dropped edge. Not in this pass (it closes no cycle); for the later cleanup.
4. **The 216 migration copies.** 216 of the 248 split lines carry their first line's `depends` unchanged (208 of them non-empty), copied by the migration: LNB-015b, c, d and g still name LNB-106 as an input they do not use (only LNB-015e and f use the convention). A pass of its own, later.

Also noticed while reading, not judged:

- `tools/story/split_edges.mjs --write` keeps a task-4 entry's `verdict` but not its `why` (`mergeOverlay` rebuilds the entry): R8 applies before any re-run, or keeps `why` there.
- LNB-022b and LNB-026b call the spin(9) action on the Peirce 16 "recalled and not computed here", while LNB-026 (chn·11: the nine traceless directions act on that 16 "with square |v|² and anticommuting") and CAND-023 (elad·22: an invertible intertwiner with the spinor module of Cl(9,0)) now check most of it: the two lines' status words may want a re-reading.
- LNS-028b repeats LNS-019f word for word (less its last sentence): an `equiv` across rows for a later pass.

## 9. What R8 applies

The accepted entries of `content/story/depends_a62.json` (35), by op; "A on B" = add `{ id: B, rel }` to A's `depends`:

- **add (26).** Task 1: GEN-002 on GEN-001 `derives`; GEN-006 on GEN-004 `instance`; GEN-007 on GEN-003 `derives`. Task 2: EQN-018, RSN-010 and LNB-023c on LAB-003 `instance`; CAND-040 and CAND-042 on NUL-010 `derives`; SPR-003 and SPR-004 on SPR-002 `derives`; LNB-032 on CAND-105 `derives`. Task 4 (`equiv`, each line on its first line): FUR-001b, FUR-002b, FUR-003b, FUR-004b, FUR-005b, GOS-006b, LNB-030b, LNB-031b, LNB-032b, LNB-033b, LNB-034c, LNB-035b, LNB-036b, LNB-037b, SRC-003b.
- **drop (8).** EQN-012 on INP-044 `uses-input`; FUR-003 on FUR-006 `derives`; INP-050 on MAT-007 `derives`; INP-056 on GRV-012 `derives`; LNB-015 on LNB-106 `uses-input`; LNB-029c on LNB-179 `derives`; PAG-023 on CPL-010 `derives`; PAG-023 on YM-008 `derives`.
- **set-cycle (1).** INP-045 on GRV-010: `derives` → `cycle`.
- **turn, changed relation: none.** Every edge named by a drop and by the set-cycle exists in 2.15.0; no add exists already (the copy applied 26 adds, 0 skipped).
- **Not applied (235):** GEN-008 on GEN-007; LNS-038 `contradicts` CAND-144; 233 split lines, LNB-025c among them.
- **With it** (not the overlay's): ruling (ii), "then" out of `CONNECTIVES.derives` in `tools/check_learner_texts.mjs`; after `npm run content`, the re-linking of `rule.ideas.genesis` links 1 and 6 (C2) and the two spans' openings (T4a).

## 10. Files

- `content/story/depends_a62.json` — `verdict` and `why` on all 270 entries; nothing else changed.
- `docs/round15/JUDGE_A62.md` — this record.
