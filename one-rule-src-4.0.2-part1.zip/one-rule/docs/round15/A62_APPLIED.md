<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# A62 applied (round 15, composer C2)

The judge's verdicts of `docs/round15/JUDGE_A62.md` (§9, what R8 applies) applied to the live tables of 2.15.0, with ruling (ii) on the checker, before the extraction of wave 2. Nothing else in the tables changed: no text, no placement, no home.

## 1. The overlay, as step 0 of the story merge

`tools/merge_story.mjs` gains a step 0, run before everything else in `mergeStory` (so the chains of step 5b and `tools/merge_chains.mjs --check`, which runs the merge in memory, read the labelled graph):

- **What it reads.** Every `content/story/depends_<pass>.json` (files sorted; today `depends_a62.json`), `{ _about, edges }`; an entry's pass is its `from` (`"a62"`).
- **What it applies.** Every entry with `verdict: "accept"`, by its op, as the overlay's `_about` defines it: add (no `op`: the edge `{ id, rel }` appended to the row's `depends` when the row lacks it), `drop` (removed), `set-cycle` (the edge's relation becomes `cycle`, in its place), `turn` (removed, and `{ id: row, rel }` added to the row `id`); a verdict `"turn"` adds an added edge the other way round and a verdict `{ rel }` adds it with that relation (neither is used by A62); `"reject"` and `null` apply nothing. An entry on a row or target that is not a row, or with an op, relation or verdict outside the record, is an error (nothing written); an entry whose edge is already as it leaves it changes nothing and is a warning.
- **The book.** The rows carry no provenance per edge: all 4,437 edges of `rows.json` are `{ id, rel }`; `labelFrom` is a field of the row (the first line whose labels a split line took, `tools/migrate/rows_from_v15.mjs`) and `review` a reviewer's note on the row. So the pass is recorded in the book only: `content/story/merged.json` gains `depends`, one entry per changed row, `{ orig, wrote, ops }` (`orig` the row's depends before step 0, `wrote` a digest of what it wrote, `ops` the applied entries, e.g. `"a62: add GEN-001 derives"`). `baseTables` restores `orig` where the row still holds what the merge wrote, like every other write of the merge, so the base the migration and `merge_explore` read is the table without the pass, and the next run applies it again.
- **Idempotent, and kept by a re-migration.** `npm run content` twice writes the same bytes (`rows.json`, `texts.json`, `pages.json`, `chains.json`, `story/merged.json`, `derived/status.json`, `MIGRATION_COUNTS.json`, `docs/COVERAGE.md`). A rebuilt `rows.json` without the pass (the 2.15.0 table put back in a copy of the repository, as a re-migration leaves it) gives, after `node tools/merge_story.mjs`, a `rows.json` and a book identical to the live ones.
- **The counts.** `merge_story: depends overlays: 35 accepted entries, 35 applied (26 add, 8 drop, 1 set-cycle) on 34 rows`; `MIGRATION_COUNTS.json` → `storyMerge.dependsOverlays`. The 34 rows: CAND-040, CAND-042, EQN-012, EQN-018, FUR-001b … FUR-005b, FUR-003, GEN-002, GEN-006, GEN-007, GOS-006b, INP-045, INP-050, INP-056, LNB-015, LNB-023c, LNB-029c, LNB-030b, LNB-031b, LNB-032, LNB-032b, LNB-033b, LNB-034c, LNB-035b, LNB-036b, LNB-037b, PAG-023 (two drops), RSN-010, SPR-003, SPR-004, SRC-003b. Every accepted entry holds in `rows.json`; the base restores the 2.15.0 depends of all 34 (no other row's depends differs).
- **A test.** `tests/chains.test.mjs` C checks both on every run: each accepted entry holds in the merged rows, and the book's `orig` is the base's depends.

## 2. Ruling (ii): "then" is a sequence word

`tools/check_learner_texts.mjs`: "then" leaves `CONNECTIVES.derives` (C4). A `derives` link opens with so, hence, thus, therefore, this means, it follows, from this, from the, because of this, as a result, which gives or which is why; an `order` link opens freely and may open with "then" (never with a derivation or contrast word). The chain self-test plants one failure more (C4: "Then" on a derives link) and checks the other side (a "Then" on an order link passes every rule); the self-test passes.

Four spans opened with "Then" on a `derives` link and were changed in their first words only:

| span | link | was | now |
|---|---|---|---|
| ATY-046 · `shifted.sv-6c.potential` · 2 | derives (on ATY-008) | "Then the potential is given a slope, …" | "From this, the potential is given a slope, …" |
| ATY-053 · `shifted.sv-7.ricci` · 4 | derives (on ATY-052) | "Then de Sitter space is worked out …" | "From the series, de Sitter space is worked out …" |
| ATY-039 · `shifted.sv-9.mu` · 3 (a mention) | derives (on ATY-037) | "Then the pull of a uniform field …" | "Hence the pull of a uniform field …" |
| GEN-006 · `rule.ideas.fixture-core` · 4 (the test fixture, good and broken files) | derives (on GEN-005) | "Then a spectator beside …" | "So a spectator beside …" |

## 3. The counts on the live tables

`node tools/story/extract_chains.mjs --counts` (E1–E9, MAX = 8) on the tables before (2.15.0) and after the overlay; the directed cycles are the strongly connected sets of `derives`, `instance` and `uses-input` over all rows. The judge's after-column is reproduced exactly.

| | before (2.15.0) | after |
|---|---:|---:|
| chains | 211 | 215 |
| rows in chains (+ attached) | 784 (+ 41) | 798 (+ 41) |
| side notes | 315 | 301 |
| singletons | 356 | 342 |
| sections of ≥ 3 rows without a chain | 14 | 11 |
| chains · singletons without E2b | 154 · 586 | 166 · 556 |
| shapes | cycle 5, fork 83, line 123 | cycle 5, fork 86, line 124 |
| directed cycles | 7 | 0 |
| wave 2: chains [without E2b]; sections without a chain | 36 [20]; 2 | 37 [21]; 1 |

Where it moved: `rule` 3 → 4 chains (C1 `GEN-001 —derives→ GEN-002`; GEN-003 … GEN-007 in one fork with GEN-015, GEN-020, GEN-030; GEN-008 the one side note), `clock` 2 → 3 (clock-trinity's chain), `steps/nullsurf` 1 → 2, `steps/spring` 0 → 1, `steps/baez` 177 → 178 rows in chains. The seven cycles broken: FUR-003/FUR-006, LNB-029c/LNB-179, LNB-015/LNB-106, GRV-012/INP-056, GRV-011/MAT-007/INP-050, the six of EQN-012 … INP-048, CPL-010/PAG-023/YM-008.

`node tools/merge_chains.mjs --check` after the overlay and before the re-linking: 41 chains on 6 pages, 196 spans, the one warning `rule.ideas.genesis link 1 (GEN-001 → GEN-002): an order link, but depends has an edge (derives)`.

## 4. The genesis re-linked

`content/chains/pilot/chains.json`, `rule.ideas.genesis`: its links recomputed from its positions on the labelled tables (`chainRecord` of `tools/story/extract_chains.mjs`, as `--into` and the test compute them), nothing else in the record but `extracted`:

`GEN-001 —derives→ GEN-002 —order→ GEN-003 —derives→ GEN-004 —derives·GEN-003→ GEN-005 —derives→ GEN-006 —derives·GEN-003→ GEN-007 —order→ GEN-008 —order→ GEN-009`, shape ladder.

- **Link 1** (GEN-001 → GEN-002): `order` → `derives` (GEN-002 on GEN-001).
- **Link 6** (GEN-006 → GEN-007): `order` → `derives` with `from: "GEN-003"` (interface 40: GEN-007 rests on an earlier position than the previous one, GEN-003, the pairing; GEN-007 has no edge to GEN-006). The ladder's rungs now read: three `order` links (1 → 2, 6 → 7, 7 → 8), five derivations, two of them from the pairing (rungs 3 → 4 and 5 → 6).
- GEN-006 on GEN-004 (`instance`) changes no link (GEN-006 links from GEN-005); no join of the pilot changed.
- `extracted` of the six `rule.ideas` chains set to what `--diff` lists on the labelled tables (the draft's chains renumbered: genesis C3 → C4, blocks C2 → C3, car C3 → C4, null C2 → C3, limit C1 → C2, routes C1 → C2); `--diff` shows no drift for the 17 pilot chains.
- `merge_chains --check`: 41 chains on 6 pages, 196 spans, **no warning**.

**The two spans** (`content/chains/learner/rule.json`), which now stand on `derives` links, open with a word of C4's derives set:

| span | was | now |
|---|---|---|
| GEN-002 · 2 | "One lonely switch with square zero is the first rung: … a switch of square plus one or minus one, …" | "So a lone switch with square zero is the first rung: … a switch of square plus or minus one, …" |
| GEN-007 · 7 | "Six switches make three pairs: the 8 by 8 grids of real numbers, 64 pieces. …" | "From the pairing, six switches make three pairs: the 8 by 8 real grids, 64 pieces. …" |

The genesis story had 3 characters left of C7's budget (2,578 of 2,581); the openings cost 21, so the two spans give back what they add ("lonely" → "lone", "plus one or minus one" → "plus or minus one", "grids of real numbers" → "real grids", the words span 9 uses): 2,580 of 2,581. Every number and status word is kept. `node tools/check_learner_texts.mjs --file content/chains/learner/rule.json`: PASS, all 24 rules.

## 5. The tests

`tests/chains.test.mjs` follows the labelled tables: A, the mechanical draft of `rule` · ideas (GEN) is the one above (four chains, side note GEN-008); B, the genesis's composed sequence with links 1 and 6; C, the overlay's two checks (§1). After `npm run content` (0 errors, the same bytes twice), with A62 applied and before wave 2 was composed (the lines after wave 2: `docs/round15/SPINE_wave2.md` §11; the mechanical counts of §3 do not move with the composition):

- `node tests/chains.test.mjs` — PASS (6,411 checks; 144 renders)
- `node tests/coverage.test.mjs` — PASS
- `node tests/story/{ask,composition,furey,landing,migration,shifted}.test.mjs` — PASS, each

## 6. Left

- **T4a**: the two genesis spans and the three shifted openings are drafts with their new first words (status unchanged); a reading by the storyteller is welcome. `docs/round14/STORY_ROUND.md` §3.2 still lists "then" in C4's derives set (a round-14 design record, not edited here; `docs/09_TRANSLATION_PROTOCOL.md` §2's prompt names only so, hence, therefore, it follows).
- **The owner** (JUDGE_A62 §8): LNS-038's "open" against CAND-144; INP-044 and INP-045 as rows to split; GRV-002 on INP-044; the 216 migration copies of split lines' depends (ATL-010b's copied `cycle` to ATL-012 is one: it is the link the cells page's spacetime chain reads, `docs/round15/SPINE_wave2.md`).
- **R8**: `tools/story/split_edges.mjs --write` keeps a task-4 entry's `verdict` but rebuilds its `why` (JUDGE_A62 §8): applying from the overlay as it stands is safe, a re-run of the tool before the release is not.
