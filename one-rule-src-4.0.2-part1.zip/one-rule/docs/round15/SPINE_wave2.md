<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The story spine of wave 2 (round 15, composer C2)

The chains of the sixteen sections of wave 2 (`docs/round15/PLAN.md` §4): `rule` · conventions, `cells` · cards (the ATL cards), `clock`, `light`, `steps/comm`, `steps/mirrors`, `steps/dirac`, composed as `docs/round14/SPINE.md` §4 composed the pilot, on the tables labelled by A62 (`docs/round15/A62_APPLIED.md`). It is the map the storytellers write from (T4a: `rule`, `cells`, `clock`, `light`; T4b: steps 2–4) and what R8 records for 2.16.0. Every chain is made of rows of the tables; every relation is a `depends` edge, `continues` (a split line and its first line) or `order` (adjacent only). Nothing here is a claim of physics or mathematics.

**How to read a chain** (as SPINE.md): `A —derives→ B`: B rests on A. `—derives·X→ B`: B rests on X, an earlier position than the previous one (a branch). `—order→`: no edge, the rows only sit side by side (the storyteller may not open with a derivation word there, C4; since A62 it may open with "then"). `(A)`: a mention, told in another chain of the page. After each chain: its shape, its weakest link (the weakest computed status of its rows: open > not yet proved here > our reading > needs an input > proved), its counts, and its titles, physics · mathematics · learner.

**The files.** `content/chains/{cells,clock,light,steps-comm,steps-mirrors}/chains.json` (34 chain records, interface 40: links, shape, joins and `extracted` computed by `tools/story/extract_chains.mjs` from the positions, `story: "none"`, `lead: null`); the five section leads in `content/chains/{cells,clock,light,steps-mirrors}/rows.json` with their research texts in `texts.json`; `content/chains/pilot/chains.json`: the three GEN chains of `cells` · cards take the orders after the cards (below). `rule` · conventions and `steps/dirac` stay lists and have no file. No row moved: no placement, order or home changed; the sections' `chains` fields are the merge's.

## 1. The counts

| page · section | rows | mechanical (after A62): chains · in chains (+ attached) · side notes | composed: chains · told · mentions · side notes | section lead |
|---|---:|---|---|---|
| `rule` · conventions | 5 | 0 · 0 · 5 | 0 · 0 · 0 · 5 (a list) | GEN-507 (v15, kept) |
| `rule` · ideas | 0 (the 30 GEN rows are the pilot's) | — | — (the pilot's six chains) | — |
| `cells` · cards (ATL, CAND) | 65 | 20 · 49 (+ 2) · 14 | 20 · 54 · 0 · 11 | ATL-711 (new) |
| `clock` · clock | 22 | 2 · 15 (+ 1) · 6 | 3 · 15 · 1 · 7 | LAB-711 (new) |
| `clock` · clock-trinity | 4 | 1 · 4 · 0 | 1 · 4 · 0 · 0 | LAB-712 (new) |
| `clock` · clock-biv | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 (a list) | — |
| `light` · views | 16 | 5 · 14 (+ 1) · 1 | 4 · 16 · 0 · 0 | PAG-508 (v15, kept) |
| `light` · charges | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 (a list) | PAG-524 (v15, kept) |
| `light` · ladders | 7 | 2 · 7 · 0 | 2 · 7 · 2 · 0 | PAG-711 (new) |
| `light` · summary | 2 | 0 · 0 · 2 | 0 · 0 · 0 · 2 (a list) | — |
| `steps/comm` · eq-comm | 4 | 1 · 2 (+ 1) · 1 | 1 · 3 · 0 · 1 | — (the page's lead EQN-507; the section has no heading) |
| `steps/comm` · summary | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 (a list) | — |
| `steps/mirrors` · eq-mirrors | 19 | 6 · 13 (+ 1) · 5 | 3 · 12 · 0 · 7 | MIR-711 (new) |
| `steps/mirrors` · summary | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 (a list) | — |
| `steps/dirac` · dirac-xref | 2 | 0 · 0 · 2 | 0 · 0 · 0 · 2 (a list) | — |
| `steps/dirac` · summary | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 (a list) | — |
| **wave 2** | **151** | **37 · 104 (+ 6) · 41** | **34 · 111 · 3 · 40** | **5 new** |

151 = 111 told + 40 side notes (a row placed on two pages counts on each, as in SPINE.md §6). Mechanical: `node tools/story/extract_chains.mjs --page <route>` (cells with `--groups ATL,CAND`, the GEN rows being the pilot's), 37 chains as `--counts` gives for wave 2 after A62 (JUDGE_A62 §7). Spans to write: 114 (111 told positions and 3 mentions), and the learner texts of the 5 leads; every side note has a learner text already (human or a translator draft), so no side-note text is due.

The **sections that stay lists** (eight): `rule` · conventions (the tags of the conventions: checked, quoted, standard, open, the action principle), `clock` · clock-biv (one row), `light` · charges (one row), the four tallies (`light`, `steps/comm`, `steps/mirrors`, `steps/dirac` · summary), and `steps/dirac` · dirac-xref (two cross-references, no edge between them). Their rows are side notes, told in no order; `rule` · conventions is the one section of three rows or more without a chain left in wave 2, as A62 left it.

## 2. The method and the choices

1. **Extract, read, compose.** Per section the mechanical draft (`--page/--section`, MAX = 8), then every research text, cell, status and edge of its rows; the chains are composed where the texts make one argument, every link recomputed from `depends` by `chainRecord` (the composer chooses positions, order and mentions; the links are the tables'), and every departure from the draft is the list `--diff` gives (recorded in `extracted.departures`). The script that built the records and its spec are the composer's scratch; `node tools/story/extract_chains.mjs --diff content/chains/<key>/chains.json` reproduces every `extracted`.
2. **A card is a chain or a side note.** `src/app/queries.js` `cellCards` builds a card from every row of `cells` · cards, grouped by `splitFrom`: the first line titles the card and its further lines are the card's other lines (`more`). So a card with further lines is told as one chain, its first line then its lines (`continues`), the card's own story; a card of one line is a side note (ATL-004, ATL-009); two cards share a chain where one rests on the other (ATL-010 and ATL-012, a `cycle`; ATL-023 and ATL-020, an `instance`) or where one's text states the other's cell (ATL-023 names Cl(5,3): ATL-019 rides in row eight).
3. **A detail threaded where it states the card's fact.** A CAND detail of the section is a position (an `order` link) only where its text and the card's make one argument: CAND-122 (the σ_k generate the Pauli algebra, Cl(3,0) as the even part of Cl(1,3)) with ATL-006; CAND-086 (∇ = d + δ) with ATL-017 (dF = 0 and d⋆F = J as the grade-3 and grade-1 parts of ∇F = J); CAND-044 (the trace ratio 3/8, "Furey's 3/8 … equals it as a number") with ATL-020b; CAND-098 (the Peirce decomposition, checked on Cl(0,8)'s blocks 2, 6, 4, 2, 1, 1, 194 off the diagonal, 48 complex) with ATL-025. CAND-078 rides with ATL-011 by its edge. The other CAND details stay side notes (no text of a card states them). The isomorphic pairs (Cl(3,0) and Cl(1,2); Cl(4,1) and Cl(2,3)) name each other but rest on nothing of each other: told card by card, side by side in the lattice.
4. **Mentions** head a chain to recall the row it rests on, told in an earlier chain of the page (as `rule.ideas.car` does): (LAB-017) in `clock.clock.brown`, (MAP-003) and (ATL-017) in the two chains of `light` · ladders.
5. **The section leads** are story rows (D60's record with `since: "v2.16"`, ids `<GROUP>-711 …` of the page's group, one placement of role `lead` at order 0, `restates` none: their texts hold no formula, no number in digits and no claim word, so T4/T5 clear them against their sections without restating a row), written in the Atlas's research voice: what the section shows, no claim of its own. A section keeps the lead it has (GEN-507, PAG-508, PAG-524, v15's human texts: a second lead would demote one of them); a list section and `steps/comm` · eq-comm (no heading of its own; the page's lead EQN-507 introduces it) get none. Their learner texts are the storytellers'; `merge_chains --check` warns while they are missing.
6. **A told row is drawn once in the body.** `tests/story/composition.test.mjs` (D52): a row a chain tells appears once in the page's body. MIR-007 and MIR-008 are drawn on `steps/mirrors` by the motion lens of `lens-demicube-moves` (`MOTION_ROWS` of `src/figures/explore/lens/motion.jsx`, compact statements): they stay side notes, and the mirrors chain is told without them (a first draft that told them failed the test).
7. **Orders.** A section's chains follow its rows' page order. On `cells` · cards the cards come first (orders 7–61 of the section) and the GEN details after (66–82): the 20 card chains take orders 1–20 and the pilot's three GEN chains (`cells.cards.null`, `limit`, `routes`, storied in wave 1) follow as 21–23 (they were 1–3); nothing else of the pilot moved.
8. **`since: "v2.16"`.** `tools/merge_chains.mjs` V9 accepts `v2.15` (wave 1) and `v2.16` (wave 2) for a row of the chains overlay (`SINCES`); `tests/story/migration.test.mjs` C likewise. NEW_SINCE (`tools/build_content.mjs`) is R8's: a story row is never "new" either way.

## 3. `rule` · conventions — a list

Five rows, the tags of the conventions page: PAG-029 (the clock rebuilt in the browser and by scripts), PAG-030 (the classification and the conventions of the literature, quoted), PAG-031 (the signs of a square as rotation, boost and translation; the choices of words), PAG-032 (what is not treated and not settled; the null rotation, checked), CPL-011 (the action principle). No edge joins two of them (they rest on the tags of `clock`, on a theorem, on an input or on a row of `light`'s intro): side notes, under the v15 lead GEN-507. The section `ideas` is the pilot's (wave 1): its six chains are unchanged but for the genesis's links 1 and 6 (A62).

## 4. `cells` · cards — twenty card stories

*Mechanical draft (ATL, CAND; after A62):* 20 chains, one per card with further lines (C1 … C20: the card and its lines by `continues`; C7 `CAND-078 —uses-input→ ATL-011 —continues→ ATL-011b`; C9 `ATL-010 —continues→ ATL-010b —cycle←→ ATL-012`; C17 `ATL-023 —instance→ ATL-020 —continues→ ATL-020b —continues·ATL-023→ ATL-023b —continues·ATL-020→ ATL-020c`), ATL-004 and ATL-009 attached to C2 as labelling neighbours; side notes the 13 CAND details and ATL-025.

*Composed:* 20 chains, 54 told, no mention, 11 side notes, lead ATL-711. The weakest link of almost every card is its reading line (ours or open); the badges stand where the story is weakest (D57).

- `cells.cards.empty` · line · proved by the Atlas · 2 told — "No generator: the unit of every cell" · "Cl(0,0) = ℝ, the unit and centre of every cell" · "No switch at all: the number one": ATL-001 —continues→ ATL-001b.
- `cells.cards.one-plus` · line · proved · 2 told — "One generator of square +1" · "Cl(1,0) ≅ ℝ ⊕ ℝ and the null seed" · "One switch whose square is plus one": ATL-002 —continues→ ATL-002b. (ATL-002 against GEN-002, a `contradicts` of A6, stays apart: GEN-002 is told on `rule`.)
- `cells.cards.phase` · line · weakest **open** (ATL-003b) · 2 told — "One generator of square −1: the phases" · "Cl(0,1) ≅ ℂ and the circle group U(1)" · "One switch whose square is minus one": ATL-003 —continues→ ATL-003b.
- `cells.cards.quaternions` · line · weakest **open** (ATL-005b) · 2 told — "Two generators of square −1: the quaternions" · "Cl(0,2) ≅ ℍ and Sp(1) ≅ SU(2)" · "Two minus switches: the quaternions": ATL-005 —continues→ ATL-005b.
- `cells.cards.pauli` · fork · weakest **our reading** (ATL-006b) · 3 told — "The Pauli algebra, inside spacetime too" · "Cl(3,0) ≅ M₂(ℂ) and the even part of Cl(1,3)" · "Three plus switches: the algebra of spin": ATL-006 —order→ CAND-122 —continues·ATL-006→ ATL-006b.
- `cells.cards.split-three` · line · weakest **open** (ATL-007b) · 2 told — "Two plus, one minus: an algebra in two halves" · "Cl(2,1) ≅ M₂(ℝ) ⊕ M₂(ℝ) and its central split" · "Two plus, one minus: a box in two halves": ATL-007 —continues→ ATL-007b.
- `cells.cards.even-spacetime` · line · weakest **open** (ATL-008b) · 2 told — "One plus, two minus: the even part of spacetime" · "Cl(1,2) ≅ M₂(ℂ), SL(2,ℂ) and Spin(1,2)" · "One plus, two minus: the turns of relativity": ATL-008 —continues→ ATL-008b.
- `cells.cards.spacetime` · **cycle** · weakest **our reading** (ATL-010b) · 3 told — "The two spacetime cells, mirrors of each other" · "Cl(3,1) ≅ M₄(ℝ) and Cl(1,3) ≅ M₂(ℍ)" · "Spacetime twice: one time and three space": ATL-010 —cycle→ ATL-012 —cycle→ ATL-010b. The two cells first (each records the other as `cycle`), then the reading that names one of them spacetime, which applies to both; its link is the `cycle` edge ATL-010b carries as a copy of ATL-010's (one of the migration copies of JUDGE_A62 §8.4).
- `cells.cards.split-four` · line · weakest **open** (ATL-011b) · 3 told — "Two plus, two minus: the bivectors as two copies" · "Cl(2,2) ≅ M₄(ℝ) and so(2,2) ≅ sl₂(ℝ) ⊕ sl₂(ℝ)" · "Two plus, two minus: turns come in two sets": CAND-078 —uses-input→ ATL-011 —continues→ ATL-011b.
- `cells.cards.conformal` · line · weakest **open** (ATL-013b) · 2 told — "Four plus, one minus: the conformal model" · "Cl(4,1) ≅ M₄(ℂ), the conformal model of space" · "Four plus, one minus: a box for circles and lines": ATL-013 —continues→ ATL-013b.
- `cells.cards.six` · fork · weakest **open** (ATL-014d) · 4 told — "Six generators: the conformal algebra of spacetime" · "Cl(4,2), Cl(2,4) and the algebra so(4,2)" · "Six switches: the moves that keep angles": ATL-014 —continues→ ATL-014b —continues·ATL-014→ ATL-014c —continues·ATL-014→ ATL-014d.
- `cells.cards.pinors` · line · weakest **open** (ATL-015b) · 2 told — "Seven generators: two ideals, two pinor classes" · "Cl(4,3) ≅ M₈(ℝ) ⊕ M₈(ℝ) and its central split" · "Seven switches: a box in two copies": ATL-015 —continues→ ATL-015b.
- `cells.cards.chiral` · line · weakest **open** (ATL-016b) · 2 told — "Two plus, three minus: a central complex structure" · "Cl(2,3) ≅ M₄(ℂ) and its central volume element" · "Two plus, three minus: a built-in complex unit": ATL-016 —continues→ ATL-016b.
- `cells.cards.maxwell` · fork · weakest **our reading** (ATL-017b) · 3 told — "The electromagnetic field as one bivector" · "F of grade two, ∇F = J and the split ∇ = d + δ" · "Light as one object with six parts": ATL-017 —order→ CAND-086 —continues·ATL-017→ ATL-017b.
- `cells.cards.strain` · fork · weakest **open** (ATL-018d) · 4 told — "The strain of a frame and the Einstein form" · "S = hᵀηh − η, its gauge law and its linearisation" · "How much a frame is stretched": ATL-018 —continues→ ATL-018b —continues·ATL-018→ ATL-018c —continues·ATL-018→ ATL-018d.
- `cells.cards.row-eight` · fork · weakest **open** (ATL-019, ATL-019b, ATL-020c) · 8 told — "Row eight: the period and two of its cells" · "Row 8: Cl(5,3), Cl(4,4) ≅ M₁₆(ℝ), two ratios of traces" · "Eight switches: the pattern repeats": ATL-023 —continues→ ATL-023b —order→ ATL-019 —continues→ ATL-019b —instance·ATL-023→ ATL-020 —continues→ ATL-020b —order→ CAND-044 —continues·ATL-020→ ATL-020c. The row and its reading (a repeat of types, not a wall), then its clock-2 cell Cl(5,3), which ATL-023 names, and its conjecture, then the self-mirror Cl(4,4) with the two numbers 3/8 that agree and are not the same, and the count 4/17. The card of Cl(5,3) alone would have had 104 characters of story for two spans (C7).
- `cells.cards.scalar` · line · weakest **open** (ATL-021b) · 2 told — "The scalar part: central, and only a rescaling" · "The grade-0 part ℝ·1 is central in every cell" · "Plain numbers only stretch": ATL-021 —continues→ ATL-021b.
- `cells.cards.two-six` · line · weakest **open** (ATL-022, ATL-022b) · 2 told — "Two plus, six minus: two counts and an open number" · "Cl(2,6) ≅ M₈(ℍ), its face counts and the number 210" · "Two plus, six minus: counting faces": ATL-022 —continues→ ATL-022b.
- `cells.cards.types` · line · weakest **open** (ATL-024b) · 2 told — "The lattice of addresses and the types of cells" · "Cell addresses, the mod-8 classification, real forms" · "Where each box sits, and what it is made of": ATL-024 —continues→ ATL-024b.
- `cells.cards.peirce` · line · proved · 2 told — "The Peirce blocks of Cl(0,8)" · "Peirce blocks of End_ℝ(𝕍) ≅ Cl(0,8) ≅ M₁₆(ℝ)" · "Cutting the biggest grid into blocks": ATL-025 —order→ CAND-098 (two side notes of the draft, threaded: CAND-098 checks ATL-025's blocks).
- side notes: ATL-004 (Cl(2,0) ≅ M₂(ℝ)), ATL-009 (Cl(4,0) ≅ M₂(ℍ)), CAND-001 (the Inönü–Wigner family on the base Cl(1,3)), CAND-011 (one coupling for Yang–Mills–Dirac), CAND-126 (the little groups in Spin(1,3); spin one half from the mass shell), CAND-012 (the Pauli equation from the Dirac–Hestenes equation, g = 2), CAND-045 (P, T and C on the coupled operator), CAND-058 (ω², the centre of every cell), CAND-138 (Kerr–Schild and Coulomb), CAND-037 (free fall from the field equation), CAND-104 (the faces of the cube and the cross-polytope); the pilot's GEN-011 and GEN-031 stay side notes.
- departures (`--diff`): ATL-004, ATL-009 left (side notes); CAND-122, CAND-086, CAND-044 added from the side notes; ATL-025 and CAND-098 a chain of their own; ATL-019, ATL-019b added from C16; ATL-012 moved (before ATL-010b); ATL-023b moved (after ATL-023); and the titles.
- the pilot's chains follow: `cells.cards.null`, `limit`, `routes` (orders 21–23).
- lead **ATL-711**: "Each card names the algebra of one cell, from no generator to eight, by its two counts of generators, and its further lines say how the Atlas reads it. The stories under the lattice go card by card: the real, complex and quaternionic cells of one and two generators, the Pauli algebra and the even part of spacetime, the two spacetime cells that mirror each other, the conformal cells of five and six generators, the split cell of seven, the field of light and the strain of a frame, and the cells of row eight, where the types repeat. Most names on the cards are readings, and the stories say which."

## 5. `clock` — Step 1: the clock and the trinity

### 5.1 `clock` · clock — the clock three ways

*Mechanical draft:* C1 · cycle (ten rows and LAB-001 attached): `LAB-017 —order→ CAND-057 —cycle·LAB-017→ LAB-022 —derives·CAND-057→ ATY-033 —cycle·LAB-022→ LAB-023 —derives·LAB-022→ LAB-024 —derives·LAB-017→ LAB-018 —derives→ LAB-025 —instance·LAB-018→ LAB-021 —equiv←·LAB-017→ RSN-029`; C2 · fork: `ATY-001 —derives→ ATY-026 —equiv→ GEN-018 —equiv→ GEN-022 —derives·ATY-026→ GEN-031`; side notes LAB-002, LAB-013, LAB-014, LAB-015, LAB-016, PAG-006. C1 runs two arguments together, the clock as the phase of a sum and the clock as an invariant reached by other routes, and ends on a back `equiv`.

*Composed:* 3 chains, 15 told, 1 mention, 7 side notes, lead LAB-711. The hero row LAB-017 is told in its chain (the top shows the headline).

- `clock.clock.gauss` · **cycle** · proved · 7 told — "The clock as the phase of one sum" · "The clock sum, the ℤ₄-form w and its Gauss sum" · "The clock hand as the angle of one sum": RSN-029 —equiv→ LAB-017 —order→ CAND-057 —cycle·LAB-017→ LAB-022 —cycle→ LAB-023 —derives·CAND-057→ ATY-033 —derives·LAB-022→ LAB-024. The logbook's plain statement first (the class is the phase of the Gauss sum, `equiv` forward, not back), the hero's precise one, its derivation for every n (CAND-057), the charge that adds on disjoint addresses and the product over the generators (the declared loop LAB-017, LAB-022, LAB-023), the theta law, and the frame as an input word. Two readings inside are ours by their texts (the partition function, the theta law) on proved rows.
- `clock.clock.brown` · fork · proved · 3 told, 1 mention — "The same clock as an invariant of surfaces and wires" · "The Brown invariant, Pin⁻ bordism and the Kitaev ℤ₈" · "The same clock in surfaces and in wires": (LAB-017) —derives→ LAB-018 —derives→ LAB-025 —instance·LAB-018→ LAB-021. Joins: LAB-022 → LAB-025 (derives).
- `clock.clock.k-theory` · fork · proved · 5 told — "Graded modules: the K-theory of a point by the clock" · "Graded Clifford modules, KO of a point and the ABS ring" · "Counting the modules of each box by the clock": ATY-001 —derives→ ATY-026 —equiv→ GEN-018 —equiv→ GEN-022 —derives·ATY-026→ GEN-031 (the mechanical C2; GEN-018 and GEN-031 are told on `rule` too, GEN-022 on `rule` and `cells`, a span in each chain).
- side notes: LAB-001 (the clock tab's list of results: rotor algebras, the embedding, the trinity, the roots), LAB-002 (the classification table), LAB-013, LAB-014 (the tags of the clock, as on `rule`), LAB-015 (the signs of a square; its section is this one, not the trinity's), LAB-016 (open: Pin±, the primordial ideas), PAG-006 (the textbook identifications).
- departures: C1 cut in two by its arguments (LAB-018, LAB-025, LAB-021 to `brown`), LAB-001 left (a side note), RSN-029 and LAB-023 moved; the mention LAB-017.
- lead **LAB-711**: "The lattice of cells coloured by their types, and the clock that reads the type of a cell from its two counts of generators. The clock is read three ways here: as the phase of one sum over the labels of a cell, each label carrying a charge; as an invariant of surfaces and of chains of wires, the same clock reached by other routes; and as the count of graded modules, the K-theory of a point."

### 5.2 `clock` · clock-trinity — the chain A62 gave it

- `clock.clock-trinity.trinity` · fork · proved · 4 told — "Three signs of a square, three motions" · "Elliptic, parabolic, hyperbolic: three readings of one sign" · "Turn, slide, run away: what a sign says": LAB-003 —instance→ EQN-018 —instance·LAB-003→ RSN-010 —instance·LAB-003→ LNB-023c (A62's three `instance` edges, the mechanical draft unchanged: a star of three cases of one reading: the spring network, the conics at n = 2, the Kepler problem).
- lead **LAB-712**: "Each element of a cell has a square, and the Atlas reads its sign as the motion the element generates: a turn for a negative square, a boost for a positive one, a slide for zero. That reading is followed into three places: a network of springs, the conics of the plane and the orbits of the Kepler problem."

### 5.3 `clock` · clock-biv — a list

LAB-004 (a translation inside a non-degenerate cell is a null rotation), a side note under its caption and learner line.

## 6. `light` — Calibration 1: light (Maxwell)

### 6.1 `light` · views — four chains under the v15 lead PAG-508

*Mechanical draft:* C1 · fork `RSN-025 —instance→ ATL-017 —continues→ ATL-017b —instance·ATL-017→ PAG-035 —derives→ PAG-037 —derives→ PAG-036`; C2 · line `MAP-004 —order→ MAP-013 —derives→ MAP-003`, EQN-001 attached; C3 `PAG-023 —instance→ CPL-010` and C4 `CPL-001` alone (the path cover takes PAG-023 → CPL-010, the earlier start, and leaves CPL-010's other parent a chain of one); C5 `SHP-001 —derives→ SHP-007`; side note LNC-056.

*Composed:* 4 chains, 16 told, no side note.

- `light.views.equation` · fork · weakest **our reading** (ATL-017b) · 6 told — "One equation for the field, its frames and invariants" · "∇F = J in Cl(1,3): the bivector, its frames and invariants" · "Light as one object seen by moving observers": RSN-025 —instance→ ATL-017 —instance→ PAG-035 —derives→ PAG-037 —derives→ PAG-036 —continues·ATL-017→ ATL-017b. The equation on every split, the card's four-dimensional field, its six parts on the tetrahedron, a moving observer, the two invariants; the card's reading last.
- `light.views.notations` · line · proved · 4 told — "Maxwell in every split, and three notations" · "∇F = J on every Cl(k,d) and its incidence graph" · "The same equation in every number of directions": MAP-004 —order→ MAP-013 —derives→ MAP-003 —order→ EQN-001 (EQN-001's shared indices beside MAP-003's incidences, as its attachment had it).
- `light.views.cube` · line · weakest **our reading** (CPL-010) · 3 told — "The cube as a drawing of the terms" · "Derivative and coupling terms as faces of the cube" · "Drawing the equation on a cube": PAG-023 —order→ CPL-001 —derives→ CPL-010. PAG-023 has a human learner text: its span is that text, verbatim (C10).
- `light.views.dual` · line · proved · 3 told — "The cube, its dual and its arrows" · "The orthoplex, the cube category and the bit-rule sign" · "Corners, arrows and the mirror shape": SHP-001 —derives→ SHP-007 —order→ LNC-056 (the side note threaded: SHP-007's "a category with one arrow S → T whenever S ⊆ T, 3ⁿ arrows in all" is LNC-056's first sentence, whose signs follow).
- departures: ATL-017b moved (last); CPL-001 added from C4; LNC-056 added from the side notes; the titles.

### 6.2 `light` · charges — a list

RSN-026 (the six motions against closed forms; "nothing predicts anything"), a side note under the v15 lead PAG-524.

### 6.3 `light` · ladders — two chains

- `light.ladders.hyperbolic` · line · proved · 2 told, 1 mention — "Which cells carry waves with a time" · "Hyperbolic principal polynomials: signature (1, n − 1)" · "Which boxes let a wave travel": (MAP-003) —derives→ LNS-012 —equiv→ LNS-002.
- `light.ladders.steps` · fork · proved · 5 told, 1 mention — "One step of the equation, taken apart" · "The incidences of ∇F = J in Cl(1,3), step by step" · "Following one move of the equation": (ATL-017) —instance→ MAP-036 —derives→ MAP-037 —derives·MAP-036→ MAP-038 —derives→ MAP-039 —instance·MAP-038→ MAP-040. Joins: MAP-003 → MAP-036, MAP-004 → MAP-037, RSN-025 → MAP-038, LNC-056 → MAP-038, RSN-025 → MAP-039 (instance).
- departures: the two mentions; the titles.
- lead **PAG-711**: "The ladders add one generator at a time to the cells of Maxwell's equation. Along them: which cells carry a wave with a direction of time, the verdict of the wave-type table; and, in the spacetime cell, one step of the equation taken apart, under the three names of a label, with the cancellations that give the conservation of charge and the wave operator."

### 6.4 `light` · summary — a list

EQN-006 (the tally of the step), CAND-139 (the conformal invariance of Maxwell and of the massless Dirac–Hestenes equation): side notes.

## 7. `steps/comm` — Step 2: commutators

- `steps-comm.eq-comm.graph` · line · weakest **proved (standard)** (EQN-003) · 3 told — "Commutators as a graph" · "The commutator graph of so(p,q)" · "Which moves care about order": EQN-001 —instance→ EQN-002 —order→ EQN-003 (the mechanical C1 with its attached EQN-003 as the last position: what the graph is, the structure constants of so(p,q)). No section lead: the section has no heading, and the page's lead EQN-507 introduces it.
- side notes: EQN-004 (what is not shown: a Yang–Mills equation, any dynamics), and in `summary` EQN-007 (the tally): two lists.

## 8. `steps/mirrors` — Step 3: mirrors

*Mechanical draft:* C1 `MIR-001 —derives→ MIR-002 —order→ ATL-008 —derives→ MIR-008` with MIR-007 attached; C2 LAB-015 alone; C3 `GOS-001 —derives→ MIR-003`; C4 `RSN-007 —instance→ MIR-011`; C5 `MAP-013 —derives→ MAP-017`; C6 `MAP-016 —derives→ EQN-002`; side notes MIR-004, MIR-005, CAND-002, MIR-006, PAG-019.

*Composed:* 3 chains, 12 told, 7 side notes, lead MIR-711.

- `steps-mirrors.eq-mirrors.corners` · fork · proved · 4 told — "The corners of the cube as products of mirrors" · "Cartan–Dieudonné on the cube: corners, versors, turns" · "Every corner is a set of mirrors": MIR-001 —order→ RSN-007 —instance→ MIR-011 —derives·MIR-001→ MIR-002. The cube's corners as patterns of mirrors and the same corners as products of the coordinate mirrors (the two texts make one reading from two sides), the corner reflector as a case, and the planes of step 2 as corners of two mirrors.
- `steps-mirrors.eq-mirrors.demicube` · line · proved · 6 told — "The even half: the demicube" · "Even blades as the demicube, from Dirac to E8" · "The even half of the cube": MAP-013 —derives→ MAP-017 —order→ MAP-016 —derives→ EQN-002 —order→ GOS-001 —derives→ MIR-003 (C5, C6 and C3 in one chain: each text is the demicube's, from the even spinor's eight corners to the 16-cell's equator and the half of E8). GOS-001 has a human learner text: its span is that text, verbatim (C10).
- `steps-mirrors.eq-mirrors.pin` · line · proved · 2 told — "Mirrors as a group: Pin and time reversal" · "Pin(p,q), the twisted adjoint and time reversal" · "Mirrors as a group, and turning time back": CAND-002 —order→ MIR-005 (two side notes threaded: CAND-002's "the lift ±e_t of time reversal (MIR-005)" names the other row).
- side notes: MIR-007 and MIR-008 (drawn in the body by the motion lens: §2.6), ATL-008 and LAB-015 (placed here from `cells` and `clock`; with MIR-008 a side note, no told row of the section rests on them, nor they on one), MIR-004 (the literature's approach, meta), MIR-006 (the null case: no mirror), PAG-019 (even blades as fields and odd as sources, our reading); and in `summary` EQN-014 (the tally), a list.
- departures (named by the draft above; `--diff` drafts only the groups the file tells, MIR, RSN, MAP, EQN, GOS and CAND, so its chains are numbered one lower): RSN-007, MIR-011 added from C4; MAP-013, MAP-017, MAP-016, EQN-002 added from C5 and C6; ATL-008, LAB-015, MIR-007, MIR-008 left (side notes); CAND-002 and MIR-005 a chain of their own; the titles.
- lead **MIR-711**: "Each view of the cube teaches the others something about mirrors: two mirrors make a turn or a boost, and every corner of the cube is a product of mirrors; the even half of the cube, the demicube, runs from the spinor of the Dirac step to the roots of E8; and the mirrors form a group, with time reversal among them."

## 9. `steps/dirac` — Step 4: two lists

`dirac-xref` holds two cross-references with no edge between them, LNS-117 (the reduced principal polynomial m² − Q, Theorem T16) and EQN-031 (the slope of the mass shell as a speed); `summary` holds EQN-008 (the tally of the step, told on `shifted` in wave 1). Side notes; no chain and no lead.

## 10. For the storytellers (T4a, T4b)

- **Worksheets.** `node tools/check_learner_texts.mjs --explain <chain id>` for each of the 34 chains (links, the words C4 allows, the status words C5 asks for, the numbers R6 asks for); the spans go in `content/chains/learner/<page key>.json` (`cells`, `clock`, `light`: T4a, 99 spans; `steps-comm`, `steps-mirrors`: T4b, 15 spans), the leads' learner texts beside them (ATL-711, LAB-711, LAB-712, PAG-711: T4a; MIR-711: T4b).
- **C10.** PAG-023 (`light.views.cube` · 1) and GOS-001 (`steps-mirrors.eq-mirrors.demicube` · 5) have human learner texts: their spans are those texts, verbatim, status human.
- **C7, the tight budgets** (0.8 × the research texts): `cells.cards.phase` 192, `quaternions` 209, `split-three` 278, `chiral` 286, `scalar` 271, `conformal` 304 characters for two spans each (R9: 40 at least each); the longest stories are `clock.clock.k-theory` (7,650) and `clock.clock.gauss` (3,808).
- **Mentions.** (LAB-017) in `clock.clock.brown` · 1, (MAP-003) in `light.ladders.hyperbolic` · 1, (ATL-017) in `light.ladders.steps` · 1: one short sentence each that recalls the row, 20 to 300 characters, no new number (C8).
- **Order links** (open freely, never with a derivation or contrast word; "then" allowed): `cells.cards.pauli` · 2, `maxwell` · 2, `row-eight` · 3 and 7, `peirce` · 2; `clock.clock.gauss` · 3; `light.views.notations` · 2 and 4, `cube` · 2, `dual` · 3; `steps-comm.eq-comm.graph` · 3; `steps-mirrors.eq-mirrors.corners` · 2, `demicube` · 3 and 5, `pin` · 2.
- **Rows told on two pages** have a span in each chain: ATL-017 and ATL-017b (`cells`, `light`), EQN-001 (`light`, `steps/comm`), EQN-002 (`steps/comm`, `steps/mirrors`), MAP-013 (`light`, `steps/mirrors`), GEN-018 and GEN-031 (`rule`, `clock`), GEN-022 (`rule`, `cells`, `clock`).

## 11. Validation

After `npm run content` (0 errors; a second run writes the same bytes):

- `node tools/merge_chains.mjs --check` — 75 chains on 10 pages, 41 storied (0 reviewed), 196 spans; round-14 rows: 45 story rows, 13 statement rows; five warnings, one per new lead without a learner text yet.
- `node tools/story/extract_chains.mjs --counts` — unchanged by the composition (215 chains, 798 (+ 41) rows in chains, 301 side notes, 342 singletons, 11 sections without a chain; wave 2: 37 [21], 1); directed cycles 0.
- `node tools/check_learner_texts.mjs` — PASS, all 24 rules (no wave-2 span yet).
- `node tests/chains.test.mjs` — PASS (8,322 checks; 17 pilot chains, 75 merged; 144 renders, 1,040 chains drawn: 520 lists, 1,528 connectives, 216 mentions, 352 stories, 168 fallbacks: at learner level the twenty unstoried card chains of `cells`, among the pages the test draws, fall back to their rows' learner texts, D54).
- `node tests/story/*.test.mjs` — PASS, 6 of 6; `node tests/coverage.test.mjs` — PASS; `npm run test:data` — exit 0 (it re-runs the merges: the same bytes).
- `sh build.sh`, then `node tests/shipped.test.mjs`, `chunk`, `door`, `record`, `export.test.mjs --ui` — PASS (dist 52.42 MB by the build's count; app.js 298.9 kB and figures-extra.js 262.3 kB gzipped, within their budgets).

Tests that follow the new tables: `tests/chains.test.mjs` (A, B, C: A62, `docs/round15/A62_APPLIED.md` §5), `tests/story/migration.test.mjs` (C: a story row of the chains overlay since v2.15 or v2.16), `tests/logbook.test.mjs` (a draft's source may be `round15:C<k>`, the composer of wave 2, beside `round14:B<k>`).
