#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round15/apply_pass12.py -- applies pass 12a of round 15 (docs/round15/pass12a/apply.json: the pairings of the half-spinors in the split and the
compact cells of ten generators, Furey and Hughes's three copies on the roadmap's labels, the complexification of the cells and of the chains with
D = ℍ, the real ℍ chain interleaved with real matrix algebras) to the tables and the layout of the story overlay, with the lead's decisions of
docs/round15/PLAN.md §5 (GEN-034 accepted; the three proposed research-text edits applied as minimal clause replacements) and the release owner's
fix of GEN-030's folder path (PLAN §1), then the spans of the three edited rows changed where a claim or status word moved (the storyteller's rules,
under tools/check_learner_texts.mjs).

Modelled on docs/round13/apply_pass11.py. Idempotent: a second run writes the same bytes (the sha256 of every touched file is printed at the end),
also after npm run content. Every input is checked before the first file is written. In order:
  1 content/rows.json        FUR-041 and FUR-042 after FUR-040, GEN-033 and GEN-034 after GEN-032 (the order of the ids, the order tools/merge_story.mjs
                             sorts the rows in), since v2.16, all four computations (stage A); the four ids free (FUR-038 ... FUR-040 are the round-14
                             questions, FUR-5xx/6xx/7xx and GEN-5xx/7xx story rows; a row that holds one of the four ids and is not an earlier copy of
                             this pass stops the script); every (page, order) free page-wide (in the rows, the story overlay's layouts and the chains
                             overlay's placements), each section a section of its page; GEN-033 and GEN-034 on cells, section cards, with the concrete
                             first cell (0,2,0). The entries on matter go through the story overlay's layout (step 1b), as those of FUR-007 ... FUR-037
                             do since round 14 recomposed the page: the row carries its entry of the tables before the recomposition (matter, section
                             furey, its order) and the layout moves it to its section of the recomposed page (fur-sixteen, fur-labels); a row keeps the
                             moved entry here once the merge's book (content/story/merged.json) shows the merge wrote it, from that original. Every row
                             at home on matter stands on its tab too (tests/story/furey.test.mjs, §2.5 of round 14): the release owner places FUR-041 and
                             FUR-042 on the tab matter/model, section axes, at 1045 and 1046 (the orders S13's notes leave free there), after FUR-037 at
                             1044, as FUR-027 ... FUR-037 stand; an entry on a page the story overlay adds is written by tools/merge_story.mjs from the
                             layout (add: true), appended after the row's own entries, and a row keeps it here once the book shows the merge wrote it
 1b content/story/furey.json the four layout entries: the moves on matter (FUR-041 to fur-sixteen at 54, FUR-042 to fur-labels at 55) after FUR-037's
                             move, the two entries added on matter/model after FUR-037's: 101 -> 105 entries (tools/migrate/verify_counts.mjs counts the
                             overlay's layout from the file; tests/story/furey.test.mjs names the two rows as side notes of their sections and lists
                             them on the tab, R8)
  2 content/texts.json       their research texts (status draft, source pass12a:ten-pairings), each after the texts of the row before it (the order of
                             tools/merge_story.mjs: by row, then level); no learner text (the learner texts are the storytellers', PLAN §4)
 2b the text edits           (PLAN §5; each a minimal clause replacement that keeps the claim and the scope, recorded in the release notes):
                             (a) FUR-039 (a round-14 question, D61; its research text is the overlay's, content/chains/matter/texts.json, which the next
                             merge copies to texts.json): S13's proposal, the question open, the parenthesis says what FUR-042 computes;
                             (b) GEN-026 (pass 10c's draft): S13's proposal, GEN-034 named where the D = ℍ case was a reading of the hypotheses;
                             (c) GEN-030 (pass 11c's draft): S13's proposal, the union for D = ℍ as the union of C_k ⊗ ℍ (GEN-034); (d) GEN-030's folder
                             path out of its text: "(docs/round13/SOURCES.md)" -> "(the sources read in round 13)" (PLAN §1; the span's "Stacey's
                             theorem 13" stays)
 2c the spans                (the storyteller's files content/chains/learner/{rule,cells,matter}.json): where an edit moved a claim or a status word, the
                             span's clause changed minimally: GEN-026 in rule.ideas.limit and cells.cards.limit (span 5): the quaternion case covered
                             as stated through the chain of real grids; GEN-030 there (span 6): the same; FUR-039 in matter.fur-next.open (span 6) and its
                             learner full text: "read, not computed" -> what FUR-042 computes (the 32 states, R6), not the third family; the derived
                             fields termsUsed and keptNumbers recomputed by the checker's deriveFields once the research texts are merged (step 7)
  3 content/checks.json      the check record of ten_pairings.py (tp.*), after spinor_pairings.py
  4 content/check_runs.json  its run record: the stored log ends with the record's last line, its tagged check lines count the record's checks and
                             tags (26: bit 12, bit==std 4, ctl 5, std 5), and its fault log holds the six wrong versions in order, each exit 1, with as
                             many FAIL lines as its own last line counts (SCALAR 2, FORM 1, PSIDIM 1, NOCENTRAL 3, NOCRULE 1, QREAL 2)
  5 content/lenses.json      furey 39 -> 41, alg 152 -> 155, atiyah 107 -> 109 (schuller and geo: no entry); the blocks are lens_<key>, a block found
                             by its key; each entry with the keys, in their order, of its lens's own entries, appended after them
  6 node tools/merge_story.mjs            merges the overlay's edited research text of FUR-039, the spans and the two layout entries into the
                             tables, so that the checker (which reads a merged row's research text from texts.json first) reads the edited texts
  7 the derived fields       termsUsed and keptNumbers of the edited learner records, from tools/check_learner_texts.mjs deriveFields (not merged)
  8 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence and by text)
  9 node tools/check_learner_texts.mjs     every learner record and span, all 24 rules (exit 1 here on a failure)
No analysis is named by the pass (its key analyses holds no entry): content/analyses.json and the Atiyah page are not touched.
Each table keeps its own JSON form (indent 1, UTF-8, with or without the final newline it had); a table whose text a load and dump would change
stops the script before anything is written.
Usage (from anywhere): python3 docs/round15/apply_pass12.py [--no-node]    --no-node skips steps 6 to 9
"""
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
said = []
pending = {}   # rel -> text: the tables are written together once every input is checked
TOUCHED = []   # every file this script may write, for the sha256 line at the end


def path(rel):
    return os.path.join(ROOT, rel)


def dump(data, newline):
    return json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    data, nl = json.loads(raw), raw.endswith('\n')
    assert dump(data, nl) == raw, f'{rel}: a load and dump would change its text (its JSON form is not indent 1, UTF-8): stop'
    return data, nl


def stage(rel, data, newline):
    """the table's new text, written by flush() once every check of steps 1 to 5 has passed"""
    pending[rel] = dump(data, newline)
    if rel not in TOUCHED:
        TOUCHED.append(rel)


def flush():
    for rel, text in pending.items():
        old = open(path(rel), encoding='utf-8').read()
        if text != old:
            open(path(rel), 'w', encoding='utf-8').write(text)
            said.append(f'wrote {rel}')
        else:
            said.append(f'unchanged {rel}')
    pending.clear()


def swap(text, find, repl, what):
    """replace the one occurrence of find by repl; a second run finds repl in place and changes nothing"""
    if repl in text and (find not in text or find in repl):
        return text
    assert text.count(find) == 1, f'{what}: the phrase to replace is not there once ({text.count(find)} times): {find[:90]!r}'
    return text.replace(find, repl)


def digest(x):
    """tools/merge_story.mjs digest: the sha1 of JSON.stringify, its first 20 hex digits"""
    return hashlib.sha1(json.dumps(x, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()[:20]


def node(args, what):
    out = subprocess.run(['node', *args], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    if out.returncode:
        sys.stdout.write(out.stdout[-4000:])
        sys.stderr.write(out.stderr[-4000:])
        sys.exit(f'{what} failed')
    return out.stdout


# ---- the pass
P = json.load(open(os.path.join(HERE, 'pass12a', 'apply.json'), encoding='utf-8'))
IDS = ['FUR-041', 'FUR-042', 'GEN-033', 'GEN-034']
SCRIPT = 'checks/selfcheck/proofs/ten_pairings.py'
SRC = 'pass12a:ten-pairings'
CHECKS = ['tp.PAIR', 'tp.FH', 'tp.CPX', 'tp.INT']
EVIDENCE = {'FUR-041': 'tp.PAIR', 'FUR-042': 'tp.FH', 'GEN-033': 'tp.CPX', 'GEN-034': 'tp.INT'}
FAULTS = [('SCALAR', 2), ('FORM', 1), ('PSIDIM', 1), ('NOCENTRAL', 3), ('NOCRULE', 1), ('QREAL', 2)]
TAGS = {'bit': 12, 'bit==std': 4, 'ctl': 5, 'std': 5}
LAST = 'ten_pairings: 26 checks, 0 fail'
# the placements of PLAN §3 as the recomposed pages show them (apply.json's shownOn); on matter the entry of the tables is section furey (step 1)
WHERE = {'FUR-041': [('matter', 'fur-sixteen', 54), ('steps/baez', 'bz-generation', 281)],
         'FUR-042': [('matter', 'fur-labels', 55)],
         'GEN-033': [('rule', 'ideas', 45), ('cells', 'cards', 83)],
         'GEN-034': [('rule', 'ideas', 46), ('cells', 'cards', 84)]}
TAB = {'FUR-041': ('matter/model', 'axes', 1045), 'FUR-042': ('matter/model', 'axes', 1046)}   # R8: every row at home on matter on its tab (S13's free orders)
OVERLAY = {'matter/dictionary', 'matter/papers', 'matter/model', 'matter/generations', 'matter/help'}   # the sub-pages the story overlay adds (furey.json)
AFTER = {'FUR': 'FUR-040', 'GEN': 'GEN-032'}   # the row each group's new rows follow (the ids sorted)
MATTER_BASE = 'furey'                          # the section of matter in the tables before the recomposition of round 14 (the merge's book)
FIRST_CELL = {'GEN-033': '(0,2,0)', 'GEN-034': '(0,2,0)'}
BLOCKS = {'lens_furey': 'furey', 'lens_alg': 'alg', 'lens_schuller': 'schuller', 'lens_atiyah': 'atiyah', 'lens_geo': 'geo'}
LENS_N0 = {'furey': 39, 'alg': 152, 'atiyah': 107}   # the dictionaries of 2.15.0
LENS_ADD = {'furey': 2, 'alg': 3, 'atiyah': 2}
CONCRETE = re.compile(r'^\((\d{1,2}),(\d{1,2}),(\d{1,2})\)$')

assert P['pass'] == '12a' and P['agent'] == 'S13' and P['since'] == 'v2.16', (P['pass'], P['since'])
assert [r['id'] for r in P['rows']] == IDS, [r['id'] for r in P['rows']]
assert [t['row'] for t in P['texts']] == IDS, 'one research text per row, in the order of the rows'
assert [(e['row'], e['level']) for e in P['row_text_edits']] == [('FUR-039', 'research'), ('GEN-026', 'research'), ('GEN-030', 'research')], 'the three proposed edits'
assert P['files']['script'] == SCRIPT and all(os.path.exists(path(P['files'][k])) for k in ('script', 'log', 'faultLog')), P['files']
assert all(os.path.exists(path(d)) for d in P['files']['docs']), P['files']['docs']
assert P['analyses'] == [], 'the pass names no analysis: content/analyses.json and the Atiyah page stay as they are'
assert {k: P[k]['key'] for k in P if k.startswith('lens_')} == BLOCKS, 'the lens blocks'
said.append('checked docs/round15/pass12a/apply.json (pass 12a, S13, since v2.16; GEN-034 accepted by the lead, docs/round15/PLAN.md §5)')

# ===================================================================================================================== 1 rows
rows, rows_nl = load('content/rows.json')
book = json.load(open(path('content/story/merged.json'), encoding='utf-8'))


def earlier_copy(r):
    """a row of this pass written by an earlier run: since v2.16, its group, every evidence the pass's script"""
    return (r.get('since') == 'v2.16' and r.get('group') == r['id'][:3] and bool(r.get('evidence'))
            and all(e.get('script') == SCRIPT for e in r['evidence']))


clash = [r['id'] for r in rows if r['id'] in IDS and not earlier_copy(r)]
if clash:
    sys.exit(f'the ids {clash} are taken by other rows of content/rows.json: renumber the pass from the next free id of its group')
rows = [r for r in rows if r['id'] not in IDS]
assert [r['id'] for r in rows] == sorted(r['id'] for r in rows), 'content/rows.json is not in the order of the ids (tools/merge_story.mjs sorts it): run npm run content'
FUREY = 'content/story/furey.json'
fy, fy_nl = load(FUREY)
L15 = json.load(open(path('content/story/layout.json'), encoding='utf-8'))
chain_layouts = []
for owner in sorted(os.listdir(path('content/chains'))):
    f = path(f'content/chains/{owner}/page.json')
    if os.path.exists(f):
        chain_layouts += json.load(open(f, encoding='utf-8')).get('layout') or []
taken = ({(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])}
         | {(l['page'], l['order']) for l in fy['layout'] if l['row'] not in IDS}
         | {(l['page'], l['order']) for l in L15} | {(l['page'], l['order']) for l in chain_layouts})
mine = [(pg, o) for rid in IDS for pg, _, o in WHERE[rid]] + [(pg, o) for pg, _, o in TAB.values()]
assert len(mine) == len(set(mine)) and not set(mine) & taken, f'an order of the pass is taken (page-wide) or used twice: {sorted(set(mine) & taken)}'
pages = json.load(open(path('content/pages.json'), encoding='utf-8'))
sections = {p['route']: {s.get('id') for s in p.get('sections') or []} for p in pages}
base_matter = ((book.get('pages') or {}).get('matter') or {}).get('orig') or {}
assert MATTER_BASE in {s.get('id') for s in base_matter.get('sections') or []}, 'the section furey of matter in the tables before the recomposition (the merge\'s book)'
assert all(((book.get('entries') or {}).get(f'{x}|matter') or {}).get('orig', {}).get('section') == MATTER_BASE for x in ('FUR-028', 'FUR-035')), \
    'FUR-028 and FUR-035, the rows the pass places beside, stand in matter · furey in the tables (moved by the layout of the story overlay)'
for r in P['rows']:
    rid = r['id']
    assert r['since'] == 'v2.16' and r['group'] == rid[:3] and (r['kind'], r['stage']) == ('computation', 'A'), (rid, r['kind'], r['stage'])
    assert list(r.keys()) == list(next(x for x in rows if x['id'] == 'FUR-035').keys()), f'{rid}: the keys of a row of the proofs passes, in their order'
    assert [(s['page'], s['section'], s['order']) for s in r['shownOn']] == WHERE[rid], rid
    assert all(s['role'] == 'detail' and s['section'] in sections.get(s['page'], ()) for s in r['shownOn']), f'{rid}: a role or a section'
    home = sorted(r['shownOn'], key=lambda s: s['order'])[0]['page']   # a row's home is its entry of least order (src/app/queries.js, rowHome)
    assert home == ('matter' if rid.startswith('FUR') else 'rule'), f'{rid}: its home'
    on_cards = any((s['page'], s['section']) == ('cells', 'cards') for s in r['shownOn'])
    assert on_cards == (rid in FIRST_CELL), f'{rid}: on the cells page or not'
    if on_cards:
        m = CONCRETE.match(r['cells'][0]) if r['cells'] else None
        assert m and sum(map(int, m.groups())) <= 8 and r['cells'][0] == FIRST_CELL[rid], f"{rid}: a card of the cells page needs a concrete first cell, n <= 8"
    assert [e['check'] for e in r['evidence']] == [EVIDENCE[rid]] and all(e['mode'] == 'ran' and e['script'] == SCRIPT for e in r['evidence']), rid
    assert not any(s['page'] in OVERLAY for s in r['shownOn']), f'{rid}: an entry on a tab in apply.json (the tab entries are R8\'s, TAB)'
assert all(s in sections.get(pg, ()) for pg, s, _ in TAB.values()), 'the section axes of the tab matter/model'
assert sorted(EVIDENCE.values()) == sorted(CHECKS), 'every check id is some row\'s evidence'
ids = {r['id'] for r in rows} | set(IDS)
thm = {t['id'] for t in json.load(open(path('content/theorems.json'), encoding='utf-8'))}
for r in P['rows']:
    for d in r['depends']:
        assert d['id'] in ids or d['id'] in thm, f"{r['id']} depends on an unknown row {d['id']}"
# The entries on matter: the tables hold the entry of the page before round 14 recomposed it (section furey, the same order and role), and the story
# overlay's layout (1b) moves it to its section; the merge records the move in its book (key "<row>|matter": the original and the digest of what it
# wrote). A row keeps the moved entry once the book shows the merge wrote it from that original, so a second run writes the same bytes.
layout, added = [], []   # the moves on matter; the entries added on the tab
for r in P['rows']:
    put = []
    for s in r['shownOn']:
        if s['page'] != 'matter':
            put.append(dict(s))
            continue
        base = {'page': 'matter', 'section': MATTER_BASE, 'order': s['order'], 'role': s['role']}
        moved = {'page': 'matter', 'section': s['section'], 'order': s['order'], 'role': s['role']}
        e = (book.get('entries') or {}).get(f"{r['id']}|matter")
        put.append(moved if e and e.get('orig') == base and e.get('wrote') == digest(moved) else base)
        layout.append({'row': r['id'], 'page': 'matter', 'section': s['section'], 'order': s['order'], 'role': s['role']})
    if r['id'] in TAB:
        # the tab entry, appended by the merge after the row's own entries (book key "<row>|matter/model|add|<its index>", the digest of the entry)
        pg, sec, o = TAB[r['id']]
        tab = {'page': pg, 'section': sec, 'order': o, 'role': 'detail'}
        e = (book.get('entries') or {}).get(f"{r['id']}|{pg}|add|{len(put)}")
        if e and e.get('orig') is None and e.get('wrote') == digest(tab):
            put.append(tab)
        added.append({'row': r['id'], 'page': pg, 'section': sec, 'order': o, 'role': 'detail', 'add': True})
    new = {**r, 'shownOn': put}
    at = next(i for i, x in enumerate(rows) if x['id'] > r['id'])
    assert rows[at - 1]['id'] in (AFTER[r['group']], *IDS), (r['id'], rows[at - 1]['id'])
    rows.insert(at, new)
order = [r['id'] for r in rows]
assert order == sorted(order) and [i for i in order if i in IDS] == IDS, 'the four rows once each, in the order of the ids'
assert order.index('FUR-040') + 1 == order.index('FUR-041') and order.index('GEN-032') + 1 == order.index('GEN-033'), 'the rows after the rows they follow'
said.append('rows: ' + ', '.join(f"{r['id']} on " + '; '.join(f"{s['page']} · {s['section']} {s['order']}" for s in next(x for x in rows if x['id'] == r['id'])['shownOn']) for r in P['rows']))

# ---- 1b the story overlay's layout: the two moves on matter, after FUR-037's entry on matter (a move: no add, its order below 1000, its section the
#      recomposed page's)
keep = [l for l in fy['layout'] if l['row'] not in IDS]
at = next(i for i, l in enumerate(keep) if l['row'] == 'FUR-037' and l['page'] == 'matter') + 1
assert all(list(l.keys()) == list(keep[at - 1].keys()) for l in layout) and 'add' not in keep[at - 1], 'the layout entries of matter (moves)'
assert [(l['row'], l['section'], l['order']) for l in layout] == [('FUR-041', 'fur-sixteen', 54), ('FUR-042', 'fur-labels', 55)], layout
keep = keep[:at] + layout + keep[at:]
at = next(i for i, l in enumerate(keep) if l['row'] == 'FUR-037' and l['page'] == 'matter/model') + 1
assert keep[at - 1]['order'] == 1044 and keep[at - 1].get('add') is True and all(list(l.keys()) == list(keep[at - 1].keys()) for l in added), 'the entries of the tab (add)'
assert [(l['row'], l['section'], l['order']) for l in added] == [('FUR-041', 'axes', 1045), ('FUR-042', 'axes', 1046)], added
fy['layout'] = keep[:at] + added + keep[at:]
assert len(fy['layout']) == 101 + 4, len(fy['layout'])
stage(FUREY, fy, fy_nl)

# ===================================================================================================================== 2 texts
texts, texts_nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'], t.get('chain'))
mine_t = {key(t) for t in P['texts']}
texts = [t for t in texts if key(t) not in mine_t]
assert not any(t['row'] in IDS for t in texts), 'another text of the four rows stands in content/texts.json (no learner text in this pass: docs/round15/PLAN.md §4)'
form_t = list(next(t for t in texts if t['row'] == 'GEN-030' and t['level'] == 'research').keys())
for t in P['texts']:
    assert list(t.keys()) == form_t, f"{t['row']}: the keys of a research text"
    assert (t['status'], t['source'], t['level'], t['lens'], t['mode'], t['register'], t['lang']) == ('draft', SRC, 'research', None, 'both', 'full', 'en'), t['row']
    assert not re.search(r'/home/|/Users/|@[\w-]+\.\w|docs/round|SOURCES\.md', t['body']), f"{t['row']}: a machine path, a folder path or a contact detail"
# after the last text of the row before; the new rows have no other text (by row, then level: tools/merge_story.mjs's order)
for t in P['texts']:
    prev = {'FUR-041': 'FUR-040', 'FUR-042': 'FUR-041', 'GEN-033': 'GEN-032', 'GEN-034': 'GEN-033'}[t['row']]
    at = max(i for i, x in enumerate(texts) if x['row'] == prev) + 1
    texts.insert(at, t)
for a, b in (('FUR-040', 'FUR-042'), ('GEN-032', 'GEN-034')):
    j = max(i for i, x in enumerate(texts) if x['row'] == b)
    assert texts[j + 1]['row'] > b and texts[j - 1]['row'] in (a, b[:-1] + str(int(b[-1]) - 1)), f'the texts of {a} … {b} out of row order'

# ===================================================================================================================== 2b the text edits (PLAN §5, §1)
# Each a minimal clause replacement of a research draft (never an author's text): the claim and its scope kept; recorded in the release notes
EDITED = []   # (row, where, what), in the order of the edits
CHAIN_TEXTS = 'content/chains/matter/texts.json'
mtexts, mtexts_nl = load(CHAIN_TEXTS)


def research_in(lst, rid, source_re):
    t = [x for x in lst if x['row'] == rid and x['level'] == 'research' and x['lens'] is None and x.get('chain') is None]
    assert len(t) == 1 and t[0]['status'] == 'draft' and re.match(source_re, t[0]['source']), f'{rid}: one research draft'
    return t[0]


def edit(lst, rid, source_re, find, repl, where, what):
    t = research_in(lst, rid, source_re)
    t['body'] = swap(t['body'], find, repl, f'the research text of {rid} ({what})')
    assert t['body'].count(repl) == 1, (rid, what)
    EDITED.append((rid, where, what))
    return t


E = {e['row']: e for e in P['row_text_edits']}
# (a) FUR-039: the round-14 question of three generations (D61; status open, kind question): its research text lives in the chains overlay, which the
#     merge copies to texts.json (step 6); S13's proposal as written: the question stays open, the parenthesis says what FUR-042 computes
edit(mtexts, 'FUR-039', r'^docs/round13/PLAN\.md#triage\.4$', E['FUR-039']['find'], E['FUR-039']['replace'], CHAIN_TEXTS,
     '(a) what FUR-042 computes of the three copies, not their third generation')
# (b) GEN-026 (pass 10c's draft): S13's proposal as written, GEN-034 named where the D = ℍ case was a reading of the hypotheses
edit(texts, 'GEN-026', r'^pass10c:null-stages$', E['GEN-026']['find'], E['GEN-026']['replace'], 'content/texts.json',
     '(b) the union of the D = ℍ chain also a chain of real matrix algebras (GEN-034)')
# (c) GEN-030 (pass 11c's draft): S13's proposal as written, the union for D = ℍ as the union of C_k ⊗ ℍ (GEN-034)
edit(texts, 'GEN-030', r'^pass11c:chain-closure$', E['GEN-030']['find'], E['GEN-030']['replace'], 'content/texts.json',
     '(c) for D = ℍ the union of C_k ⊗ ℍ, to which the theorem applies as stated (GEN-034)')
# (d) GEN-030's folder path out of its text (PLAN §1: the number rule read the path as a 13); the span's "Stacey's theorem 13" stays
edit(texts, 'GEN-030', r'^pass11c:chain-closure$', 'read in secondary sources (docs/round13/SOURCES.md);', 'read in secondary sources (the sources read in round 13);',
     'content/texts.json', '(d) the folder path out: "the sources read in round 13"')
assert not any('docs/round13/SOURCES.md' in t['body'] for t in texts if t['level'] == 'research' and t['row'] in ('GEN-026', 'GEN-030')), 'a folder path left'
for rid in ('GEN-019', 'GEN-016'):   # the rows S13 says stand as written: no edit of their texts here
    assert not any(x for x in EDITED if x[0] == rid)
said.append('text edits: ' + '; '.join(f'{rid} ({where}) {what}' for rid, where, what in EDITED))

# ===================================================================================================================== 2c the spans (the storyteller's words)
# Where an edit moved a claim or a status word, the span's clause changes minimally, in the chain's words (the quaternions, real grids, the 32 states,
# families): R6 asks for the 32 of FUR-039's text; no other number, name or status word enters. The checker reads them in step 9.
GEN26_SPAN = ('(volume 38, pages 29 to 44, read in secondary sources, covering the quaternion case only by a reading of its hypotheses)',
              '(volume 38, pages 29 to 44, read in secondary sources, covering the quaternion case only by a reading of its hypotheses, though their '
              'union is also that of a chain of real grids, to which it applies as stated)')
GEN30_SPAN = ('which the stages are in the real and complex cases and not, as stated, for the quaternions;',
              'which the stages are in the real and complex cases and not, as stated, for the quaternions; for the quaternion chains the union is also '
              'that of a chain of real grids, to which it applies as stated;')
FUR39 = ('(arXiv:2409.17948, read, not computed).',
         '(arXiv:2409.17948, read; the finite part, their charges on the 32 states, is computed in row FUR-042, not their third family).')
SPANS = [('content/chains/learner/rule.json', 'GEN-026', 'rule.ideas.limit', 5, GEN26_SPAN),
         ('content/chains/learner/rule.json', 'GEN-030', 'rule.ideas.limit', 6, GEN30_SPAN),
         ('content/chains/learner/cells.json', 'GEN-026', 'cells.cards.limit', 5, GEN26_SPAN),
         ('content/chains/learner/cells.json', 'GEN-030', 'cells.cards.limit', 6, GEN30_SPAN),
         ('content/chains/learner/matter.json', 'FUR-039', 'matter.fur-next.open', 6, FUR39),
         ('content/chains/learner/matter.json', 'FUR-039', None, None, FUR39)]   # its learner full text, the same words
learner = {}
SPAN_EDITED = []
for rel, rid, chain, n, (find, repl) in SPANS:
    if rel not in learner:
        learner[rel] = load(rel)
    recs = learner[rel][0]
    hit = [r for r in recs if r['row'] == rid and r.get('chain') == chain and r.get('span') == n and r['level'] == 'learner'
           and r['register'] == ('span' if chain else 'full')]
    assert len(hit) == 1 and hit[0]['status'] == 'draft' and re.match(r'^storyteller@\d{4}-\d{2}-\d{2}$', hit[0]['source']), (rel, rid, chain, n)
    hit[0]['body'] = swap(hit[0]['body'], find, repl, f'{rid} in {chain or "its learner full text"}')
    assert hit[0]['body'].count(repl) == 1
    SPAN_EDITED.append(f'{rid} · {chain} · {n}' if chain else f'{rid} · learner full text')
said.append('spans: ' + '; '.join(SPAN_EDITED))

# ===================================================================================================================== 3 the check record
checks, checks_nl = load('content/checks.json')
cid = SCRIPT[len('checks/'):]
checks = [c for c in checks if c['id'] != cid]
assert checks[-1]['id'] == 'selfcheck/proofs/spinor_pairings.py', checks[-1]['id']
assert not any(x['id'] in CHECKS for c in checks for x in c.get('ids') or []), 'a tp.* id in another record'
form_c = list(checks[-1].keys())
assert len(P['checks']) == 1
c = P['checks'][0]
assert list(c.keys()) == form_c and c['id'] == cid and c['since'] == 'v2.16' and c['script'] == SCRIPT and c['log'] == P['files']['log'], c['id']
assert [x['id'] for x in c['ids']] == CHECKS and c['rowsNaming'] == IDS, c['id']
assert f"{sum(TAGS.values())} checks ({', '.join(f'{k} {v}' for k, v in TAGS.items())})" in c['notes'], c['notes'][:160]
checks.append(c)
stage('content/checks.json', checks, checks_nl)

# ===================================================================================================================== 4 the run record
# the stored log: its tagged check lines (all ok) count the record's checks and tags, and its last line is the record's; the fault log: the pass's
# wrong versions in order, each "--fault X: exit 1", with as many FAIL lines as its own "last:" line counts (RESULT.md §4)
runs, runs_nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
runs = [r for r in runs if rk(r) not in {rk(x) for x in P['check_runs']}]
run_form = list(runs[-1].keys())
TAG = re.compile(r'^  (ok|FAIL) +\[(bit|bit==std|ctl|std)\] ')
name = os.path.basename(SCRIPT)[:-len('.py')]
total = sum(TAGS.values())
log = open(path(P['files']['log']), encoding='utf-8').read().rstrip('\n').split('\n')
hits = [m for m in map(TAG.match, log) if m]
tags = {k: sum(1 for m in hits if m.group(2) == k) for k in TAGS}
assert all(m.group(1) == 'ok' for m in hits) and len(hits) == total and tags == TAGS, tags
assert log[-1] == LAST == f'{name}: {total} checks, 0 fail', log[-1]
tagword = ', '.join(f'{k} {v}' for k, v in TAGS.items())
assert len(P['check_runs']) == 1
r = P['check_runs'][0]
assert r['script'] == SCRIPT and r['source'] == P['files']['log'] and list(r.keys()) == run_form, r['script']
assert r['passed'] is True and r['ok'] == total and r['fail'] == 0 and r['lastLine'] == log[-1], r['script']
assert f'tags {tagword}' in r['status'] and f'{len(FAULTS)} --fault runs each exit 1' in r['status'], r['status']
got = []
for b in re.split(r'^(?=--fault )', open(path(P['files']['faultLog']), encoding='utf-8').read(), flags=re.M):
    if not b.strip():
        continue
    head = re.match(r'--fault (\w+): exit 1\n', b)
    last = re.search(rf'^last: {name}: (\d+) checks, (\d+) fail$', b, re.M)
    nfail = len(re.findall(r'^  FAIL +\[', b, re.M))
    assert head and last and int(last.group(1)) == total and int(last.group(2)) == nfail >= 1, b[:80]
    got.append((head.group(1), nfail))
assert got == FAULTS, got
for txt in (open(path(P['files']['log']), encoding='utf-8').read(), open(path(P['files']['faultLog']), encoding='utf-8').read()):
    assert not re.search(r'(?<![\w.~%-])/(home|Users)/[\w.-]', txt), 'a machine path in a stored log'
runs.append(r)
said.append(f"{SCRIPT}: {log[-1]} (tags {tagword}); faults {', '.join(f'{f} {k}' for f, k in got)}, each exit 1")
stage('content/check_runs.json', runs, runs_nl)

# ===================================================================================================================== 5 the lenses
# a block is found by its key; each entry has the keys of its lens's own entries, in their order, and is appended after them; each dictionary recounted
lenses, lenses_nl = load('content/lenses.json')
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows'] and e['atlas'] == f['atlas']
adds = {}
for blk, lkey in BLOCKS.items():
    for e in P[blk]['dictionary_add']:
        assert e['evidence'] and set(e['evidence']) <= set(CHECKS) and e['rows'] and set(e['rows']) <= set(IDS), (lkey, e['atlas'][:40])
        assert e['flags'] == ['checked'] and e['from'].endswith('(pass 12a)') and e['matrixRows'] == [], (lkey, e['from'])
        assert all(EVIDENCE[x] in e['evidence'] for x in e['rows']), (lkey, e['rows'], e['evidence'])
        adds.setdefault(lkey, []).append(e)
assert {k: len(v) for k, v in adds.items()} == LENS_ADD, {k: len(v) for k, v in adds.items()}
all_add = [e for v in adds.values() for e in v]
for lkey, add in adds.items():
    lens = next(x for x in lenses if x['key'] == lkey)
    form_l = list(lens['dictionary'][0].keys())
    assert all(list(e.keys()) == form_l for e in lens['dictionary'] + add), f'{lkey}: an entry in another form than the lens keeps'
    keep_l = [e for e in lens['dictionary'] if not any(same(e, f) for f in all_add)]
    assert len(keep_l) == LENS_N0[lkey], (lkey, len(keep_l))
    lens['dictionary'] = keep_l + add
    said.append(f"the lens {lkey}: {LENS_N0[lkey]} -> {len(lens['dictionary'])} dictionary entries")
assert {k: len(next(x for x in lenses if x['key'] == k)['dictionary']) for k in LENS_N0} == {'furey': 41, 'alg': 155, 'atiyah': 109}
stage('content/lenses.json', lenses, lenses_nl)

# ===================================================================================================================== 1, 2: the rows, the texts, the spans staged
stage('content/rows.json', rows, rows_nl)
stage('content/texts.json', texts, texts_nl)
stage(CHAIN_TEXTS, mtexts, mtexts_nl)
for rel, (recs, nl) in learner.items():
    stage(rel, recs, nl)
flush()   # every input of steps 1 to 5 checked: the tables written together
TOUCHED += ['content/pages.json', 'content/chains.json', 'content/story/merged.json', 'content/lens_readings.json', 'content/MIGRATION_COUNTS.json']

if not NO_NODE:
    # ================================================================================================================= 6 the story merge
    # FUR-039's research text is the chains overlay's (content/chains/matter/texts.json): the checker reads a merged row's research text from
    # texts.json first, so the merge runs before it (tools/merge_story.mjs restores its base and merges again: a second run writes the same bytes)
    out = node(['tools/merge_story.mjs'], 'tools/merge_story.mjs')
    line = next((l for l in out.split('\n') if l.startswith('merge_story:')), out.strip().split('\n')[-1])
    said.append('ran tools/merge_story.mjs: ' + line[:220] + ('…' if len(line) > 220 else ''))
    T2 = json.load(open(path('content/texts.json'), encoding='utf-8'))
    assert research_in(T2, 'FUR-039', r'^docs/round13/PLAN\.md#triage\.4$')['body'] == research_in(mtexts, 'FUR-039', r'^docs/round13/PLAN\.md#triage\.4$')['body'], \
        'FUR-039: texts.json holds the overlay\'s research text after the merge'
    R2 = {x['id']: x for x in json.load(open(path('content/rows.json'), encoding='utf-8'))}
    for rid in IDS:
        assert [(s['page'], s['section'], s['order']) for s in R2[rid]['shownOn']] == WHERE[rid] + ([TAB[rid]] if rid in TAB else []), (rid, R2[rid]['shownOn'])

    # ================================================================================================================= 7 the derived fields
    # termsUsed and keptNumbers of the edited learner records: the checker's own deriveFields on the merged tables (never typed; not merged)
    edited = []
    for rel, rid, chain, n, (find, repl) in SPANS:
        rec = next(r for r in learner[rel][0] if r['row'] == rid and r.get('chain') == chain and r.get('span') == n and r['register'] == ('span' if chain else 'full'))
        edited.append((rel, rec))
    js = ("import { pathToFileURL } from 'node:url'; import path from 'node:path';"
          "const m = await import(pathToFileURL(path.resolve('tools/check_learner_texts.mjs')).href);"
          "const T = m.loadTables(); const recs = JSON.parse(process.env.DERIVE_IN);"
          "process.stdout.write(JSON.stringify(recs.map(r => m.deriveFields(r, T))));")
    env = {**os.environ, 'NODE_PATH': NM, 'DERIVE_IN': json.dumps([rec for _, rec in edited], ensure_ascii=False)}
    out = subprocess.run(['node', '--input-type=module', '-e', js], cwd=ROOT, env=env, capture_output=True, text=True)
    if out.returncode:
        sys.stderr.write(out.stderr[-3000:])
        sys.exit('the derived fields (deriveFields of tools/check_learner_texts.mjs) failed')
    for (rel, rec), d in zip(edited, json.loads(out.stdout)):
        rec['termsUsed'], rec['keptNumbers'] = d['termsUsed'], d['keptNumbers']
    for rel, (recs, nl) in learner.items():
        stage(rel, recs, nl)
    flush()
    said.append('derived fields: ' + '; '.join(f"{rec['row']} {rec.get('chain') or 'full'}: keptNumbers {rec['keptNumbers']}" for _, rec in edited if rec['row'] == 'FUR-039'))

    # ================================================================================================================= 8 the lens readings
    out = node(['tools/migrate/lens_readings.mjs'], 'tools/migrate/lens_readings.mjs')
    sys.stdout.write(out[-600:])
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    mine_lr = [x for x in lr if x['row'] in IDS]
    said.append(f'ran tools/migrate/lens_readings.mjs: {len(lr)} readings, {len(mine_lr)} on the four rows ('
                + ', '.join(f"{k} {sum(1 for x in mine_lr if x['lens'] == k)}" for k in sorted({x['lens'] for x in mine_lr})) + ')')

    # ================================================================================================================= 9 the checker
    out = subprocess.run(['node', 'tools/check_learner_texts.mjs'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    tail = [l for l in out.stdout.strip().split('\n') if l][-3:]
    said.append('tools/check_learner_texts.mjs: ' + ' · '.join(tail)[-400:])
    if out.returncode:
        print('\n'.join(said))
        sys.stdout.write(out.stdout[-6000:])
        sys.exit('the checker fails on the learner records: change the span\'s words (2c) and run again')

print('\n'.join(said))
print('sha256 of the files this script touches:')
for rel in TOUCHED:
    print(f"  {hashlib.sha256(open(path(rel), 'rb').read()).hexdigest()}  {rel}")
