<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Learner texts of wave 2, part b: steps 2–4 and the pilot's leftovers (T4b, round 15, release 2.16.0)

The storyteller T4b of wave 2 wrote under `docs/round14/STORY_ROUND.md` §7 (the prompt and the budget), §2.2 (the span record) and §3.2 (C1–C11, with the lead's ruling of round 15: "then" is a sequence word and may open an `order` link; the derivation words are so, hence, therefore, thus, it follows), on the chains of `docs/round15/SPINE_wave2.md` §7–§9 (`content/chains/steps-comm/chains.json`, `content/chains/steps-mirrors/chains.json`), with `docs/round14/OWNER_ANSWERS.md` (A60, A63, A64), `docs/round14/B1_NOTES.md`, the voice of `docs/LEARNER_TEXTS_chains.md` and `docs/09_TRANSLATION_PROTOCOL.md` §2.2. T4a wrote `cells`, `clock` and `light` at the same time (`LEARNER_TEXTS_wave2_a.md`); no file of T4a's was touched here.

**All four chains are storied; none went back to the checker, none was rejected twice, none is left out** (D54's fallback applies to none of them). Every record has the shape of §2.2: `lang: "en"`, `level: "learner"`, `lens: null`, `status: "draft"`, `source: "storyteller@2026-10-17"`; the one human span (C10) `status: "human"` with its human source; `termsUsed` and `keptNumbers` are the checker's own (`deriveFields`), never typed, and empty on the human span as on wave 1's.

## 1. What was written

| file (`content/chains/learner/`) | records | what |
|---|---:|---|
| `steps-comm.json` (new) | 3 | the 3 spans of `steps-comm.eq-comm.graph` |
| `steps-mirrors.json` (new) | 15 | the 12 spans of the three chains of `eq-mirrors` (11 drafts and GOS-001's human words, C10); the learner text of the section lead MIR-711; the learner full texts of CAND-002 and MIR-005 (§5) |
| `steps-coupling.json` (wave 1's, appended) | 25 + 4 | the full texts of the pilot's leftovers CAND-013, CAND-084, CPL-007c, CPL-007d; the 25 spans of wave 1 unchanged, byte for byte (`diff`: additions only) |

Not written, after the checks of §5: `steps-dirac.json` (its three side notes have learner texts), `rule.json` and `cells.json` (GEN-011 and CAND-062 have learner drafts). In all: 15 spans (14 drafts, 1 human), 1 lead text, 6 full texts.

## 2. The chains, position by position

| chain | shape | positions and links | story / budget (C7) |
|---|---|---|---:|
| `steps-comm.eq-comm.graph` · "Which moves care about order" | line | EQN-001 —instance→ EQN-002 —order→ EQN-003 | 540 / 542 |
| `steps-mirrors.eq-mirrors.corners` · "Every corner is a set of mirrors" | fork | MIR-001 —order→ RSN-007 —instance→ MIR-011 —derives·MIR-001→ MIR-002 | 838 / 840 |
| `steps-mirrors.eq-mirrors.demicube` · "The even half of the cube" | line | MAP-013 —derives→ MAP-017 —order→ MAP-016 —derives→ EQN-002 —order→ GOS-001 (human) —derives→ MIR-003 | 1010 / 1011 |
| `steps-mirrors.eq-mirrors.pin` · "Mirrors as a group, and turning time back" | line | CAND-002 —order→ MIR-005 | 1155 / 1155 |

No chain of these pages has a chain lead (`lead: null`). The section lead **MIR-711** (role lead) has its learner text: 299 characters, no digit (E8 is a name), the four views of the research text in the page's words ("Each view of the cube teaches the others about mirrors: two mirrors make a turn or a boost, and every corner of the cube is made of mirrors; the even half of the cube runs from the spinor of the Dirac step to the roots of E8; and the mirrors form a group, the mirror that turns time back among them."); `testBlock` passes it against the section's rows as narration, as it passes the research text (not a gate for a section lead; checked to be sure).

**The openings (C4).** `instance`: "Take 4 directions" (EQN-002 in `graph`), "For instance" (MIR-011). `derives`: "So" (MIR-002, MAP-017, EQN-002 in `demicube`, MIR-003); MIR-002 rests on MIR-001, not on the corner reflector before it, and its span speaks of corners again, so its "So" reads back to the first position. `order`, opened freely and never with a derivation or contrast word: "These lines are" (EQN-003), "Each corner is" (RSN-007), "Two planes anticommute" (MAP-016), "The mirrors are a tool" (MIR-005); GOS-001's human text stands on its `order` link (C4 waived, C10). "Then", allowed on an `order` link since the ruling, was not needed.

**The status words (C5, R8).** Every told row of the four chains is proved (proved-by-atlas; EQN-003 standard), so no story carries a badge and no span says a weak status word that its research text lacks. The status and scope words the research texts carry are kept: MIR-005 "our reading" and "standard"; MIR-001 "textbook"; RSN-007 and MAP-016 "checked exactly"; CAND-002 "checked, exact" and "recalled"; EQN-001 "exactly" and "every size" (its "for every n"); EQN-003 "exactly", and its "one choice" (allowed: its research text says choice).

**The human words (C10, A63).** GOS-001 (`demicube` · 5) takes its human learner text verbatim, status human, source `gossetCopy.js#en.yl.gb.0.1`; the spans before and after it carry the links (EQN-002 ends on the 16-cell, MIR-003 opens "So E8's half-cube corners are the 8-cube's even ones"). PAG-019, the other human text of the page, is a side note.

## 3. The voice

The step pages' own human words (EQN-507, EQN-508, EQN-510 … 512 on `steps/comm`; MIR-501, MIR-504 … 509 on `steps/mirrors`; GOS-001): a generator is a **direction**, a bivector a **plane**, rotations and boosts **turns** and **boosts**, a commutator "**the order matters**" (and "commuting pairs" where the budget is tight), the scalar **the plain number**, the pseudoscalar **the top piece**, vertices **corners**, the demicube **the half cube**, reflections **mirrors**, a null generator **a zero direction**, an invertible one **a direction that can be undone**, the diagonal sign matrices **the sign grids**, Cl(q,p) beside Cl(p,q) **the cell with signs swapped**, so(p,q) **the turning algebras**, the commutator's third bivector **the third plane** (EQN-507's word), J **the quarter turn** (wave 1's word), e_t² = +1 "**time squares to plus one**". The names Cl(1,3), Cl(3,1), E8 and the 16-cell stay names; "the spinor" is MAP-017's and MIR-711's own word. Straight apostrophes, as in the pilot's and shifted's files.

## 4. What the budget cost (C7 with R6)

The four chains end at 99.6 % to 100 % of their budgets (the research texts of these rows are short and dense with symbols, which plain words lengthen; GOS-001's human text alone holds 235 of `demicube`'s 1011 characters). Every number, scope and status word of every told row is in its span; what was compressed is method detail, and a few clauses that a neighbouring row of the same page states, left to that row:

- `graph`: EQN-002's heading "(More shapes, step 2)" and its pointer "the octahedron above" (the octahedron is named, the pointer dropped); EQN-001's "on both sides" is carried by "the graph of planes whose order matters"; EQN-003's F = dA + A∧A is "a field acting on itself".
- `corners`: MIR-011's mirror formula (a formula); MIR-001's Bₙ and Dₙ as "both mirror groups".
- `demicube`: MAP-013's first clause, the even blades on 2ⁿ⁻¹ corners, which MIR-001's span states ("the even ones a half cube"; the number 2 stays, in "even half"); MAP-016's name so(p,q), which MIR-002's span states ("step 2's graph is their algebra"); EQN-002's word "octahedron" and the "three" of its commuting pairs, told in full in `graph` on `steps/comm`. MAP-013's Maxwell clause is kept ("Maxwell's even field has odd sources").
- `pin`: in CAND-002, that a vector and its negative give the same mirror, the Householder cross-check, "seeded integer", "unit", the basis vectors among the test vectors, and "a space reflection the other way" (MIR-005's span says it: "in Cl(3,1) the same formula is parity"); in MIR-005, e₁, e₂, e₃ as "space" and the automorphism as "a symmetry of the whole algebra". The full texts of CAND-002 and MIR-005 (§5) carry every clause back.

Whether chains like these get 0.9 is the owner's open question (`docs/HANDOVER.md` §3); at 0.9 the clauses above would fit.

## 5. The full texts

| row | where | status | characters | note |
|---|---|---|---:|---|
| CAND-013 | `steps/coupling` · eq-coupling, side note | proved-by-atlas | 1134 | the bound states of the Coulomb coupling: every number kept (2, 3, 4, 5, 7, 10, 12, 13, 24, 25, 1.7), the precision as "1.7 times 10 to the minus 10" (A64), "1S½" as "the 1S state with spin one half", γ as "the root factor", κ as "their Dirac number"; textbook, exactly, numerically, recalled, "every number of the shell and of the total spin" (R8's for every n) |
| CAND-084 | `steps/coupling` · eq-coupling, side note | proved-by-atlas | 1370 | the squares of the curved Dirac operator: 2.6e-5 verbatim, 3/101 cubed, minus 50 to 50; R/4 as "a quarter of the curvature", ∇*∇ as "the adjoint form of the second derivative", J as "the quarter turn", t as "a fraction of that torsion"; exact, recalled, "not run" |
| CPL-007c | `steps/coupling` · eq-coupling, side note | open (a question) | 261 | begins "Open:", as FUR-038 … FUR-040 do; 5, 7, 8, 9 kept |
| CPL-007d | `steps/coupling` · eq-coupling, side note | proved-by-atlas | 1199 | the grade-5 current on one Dirac copy: 2, 4, 5, 6, 7, 8, 16, 21, 32, 56 kept; Cl⁺(1,n−1) as "the even part", ±1, ±2, ±½ as "plus or minus one, two or a half"; exact, "not decided" |
| CAND-002 | `steps/mirrors` · eq-mirrors, told in `pin` | proved-by-atlas | 1269 | the span made to stand alone with every compressed clause back |
| MIR-005 | `steps/mirrors` · eq-mirrors, told in `pin` | proved-by-atlas | 562 | the same; "atlas" in lower case, as its research text writes it (R12) |

CAND-002 and MIR-005 are told rows, not side notes: they had no learner text anywhere, and the drawer and the search read a row's learner `full` text, so they are written as T3s and T3m wrote such rows in wave 1. They go beyond the brief's list (side notes and the pilot's leftovers): the last two records of `steps-mirrors.json`, to drop if the lead wants only the list.

**Checked and not written** (each has a learner text already): `steps/comm`: EQN-004, EQN-007 (`texts_learner.json`); `steps/mirrors`: MIR-004, MIR-006, EQN-014, ATL-008, LAB-015 (`texts_learner.json`), MIR-007 and MIR-008 (the side notes the motion lens draws, translator drafts of 2026-10-11 in `texts_learner_explore.json`), PAG-019 (human); `steps/dirac`: LNS-117 (`texts_learner_schuller.json`), EQN-031 (`texts_learner_explore.json`), EQN-008 (`texts_learner.json`); the pilot's GEN-011 (`texts_learner_pass8.json`, translator draft of 2026-10-16) and CAND-062 (`texts_learner_proofs2.json`, 2026-10-12).

## 6. The rules that bit

- **C7**, on all four chains (§4): the first drafts measured 683 / 542, 954 / 840, 1136 / 1011 and 1465 / 1155.
- **R6**: "halving" is not one of the checker's number words ("half", "halves", "halved" are), so MAP-013's 2 is kept by "even half".
- **R12**: names are compared with their capitals, and MIR-005's research text writes "atlas": its span and full text say "elsewhere in the atlas".
- **R4**: "°" is an operator mark ("20 to 50 degrees"); so(p,q) and Cl(p,q) hold lone letters ("the turning algebras", "the cell with signs swapped"); "½" is a vulgar fraction; ±, x̂, e_t, Zα, γ, κ said in words.
- **C4**: "From the other side" was refused before the checker saw it ("from the" is a derivation word, banned on an `order` link); "This gives" was avoided on an `order` link (a derivation in all but its words).
- **The words screens** (09 §2.2): every record's windows of 40 characters taken every 40 against the strings the pages draw outside statements (`notes.json`, `pages.json`, `figures.json`, `lenses.json`, `glossary.json`, the stored tables, `src/`), and every offset against the notes: no hit; `tools/check_notes.mjs` rule G passes.

## 7. The checker, the commands and their last lines

Four pieces, the checker on the file after each; **each passed on its first run**. Before each write, the drafts went through the checker's own functions (`check`, `checkChains` with `testBlock`, `deriveFields`) in a scratch harness outside the repository, as T3m drafted; they caught the C7 overruns of §6 and the R6 of MAP-013.

| command | last line |
|---|---|
| `node tools/check_learner_texts.mjs --explain <chain id>`, for the four chains | the worksheets (budget 542, 840, 1011, 1155; links and C4 words; C5 none, all proved; R6 and R8 lists; GOS-001's human text, C10) |
| `node tools/check_learner_texts.mjs --file content/chains/learner/steps-comm.json` (piece 1) | `PASS: all 24 rules hold for every record` (3 records) |
| `node tools/check_learner_texts.mjs --file content/chains/learner/steps-mirrors.json` (piece 2: `corners`, `demicube`, MIR-711; piece 3: `pin`, CAND-002 and MIR-005 full) | `PASS: all 24 rules hold for every record` (11, then 15 records) |
| `node tools/check_learner_texts.mjs --file content/chains/learner/steps-coupling.json` (piece 4) | `PASS: all 24 rules hold for every record` (29 records) |
| `node tools/check_learner_texts.mjs` (every learner file together, R3 across files) | `PASS: all 24 rules hold for every record` (1503 records; spans of steps-comm 3, spans of steps-mirrors 12) |
| `node tools/merge_chains.mjs --check` | `merge_chains --check: 75 chains on 10 page(s), 65 storied (0 reviewed), 265 spans; round-14 rows: 45 story rows, 13 statement rows` (with T4a's spans; the warning of MIR-711 is gone, the three left are T4a's leads LAB-711, LAB-712, PAG-711) |
| `npm run content` (after each page and after piece 4) | `errors 0, warnings 0; see docs/COVERAGE.md` (learner texts 1609) |
| `node tests/coverage.test.mjs` (after each page and after piece 4) | `PASS: every statement is a text record of its row; no KaTeX at learner level; badges as computed; …` (4680 story paragraphs of statements only) |
| `node tests/story.test.mjs` (the six story tests) | `story: 6 of 6 test files pass` |
| `sh build.sh` | `dist: 872 files, 52.51 MB — app.js 976.4 kB (298.9 kB gzipped), app.css 118.8 kB, …` |
| `node tests/ui/chains.smoke.test.mjs` | `chains.smoke: 356 checks; …` · `PASS: the chains render at both levels, in both themes, at 390 and 1366 px, without overflow or console error: …` (part 4 walks every page with chains, `steps/comm` and `steps/mirrors` among them) |
| `node tests/chains.test.mjs` (B1's; not a gate of this brief) | `PASS: the extraction gives its fixture and SPINE.md §4's drafts, deterministically; …` (8460 checks; 512 stories, 8 fallbacks) |
| `node tools/check_notes.mjs` | `check_notes: 11 of 11 rules pass` |
| a look at learner level (Playwright on `dist/`: `#/steps/comm`, `#/steps/mirrors`, `#/steps/coupling`, at 1366 px light and 390 px dark) | each chain one paragraph of its spans in order with the "›" of each statement; MIR-711 under the section title; the four side notes of `steps/coupling` under "More statements" (CPL-007c with the open ones); 0 px overflow, 0 console errors |

## 8. For the lead and the owner

- **The retire of 2.16.0 (R8).** The translator full drafts of EQN-002, EQN-003, MIR-001 and MIR-011 become eligible (every placement told in a storied chain), EQN-001's too once T4a's `light.views.notations` is storied. EQN-003 is the hero of `steps/comm` and has no short text, and `merge_chains --retire` reads placements, not heroes: retiring its full draft would leave the page top without learner words. Keep that draft, or give the hero a short text. MIR-001, the hero of `steps/mirrors`, keeps its short draft.
- **Pass 12a (`docs/round15/PLAN.md` §5).** The research-text edits proposed for GEN-026, GEN-030 and FUR-039 are not applied yet. Once R8 applies them, the spans of GEN-026 and GEN-030 (`rule.json` · `rule.ideas.limit`, `cells.json` · `cells.cards.limit`) and of FUR-039 (`matter.json`) need the checker again, and words to match where a clause changed. This brief kept those files out of T4b's hands.
- **A reading note, no rule.** The learner lines of the step pages (EQN-510 … 512, MIR-505 … 509, human story rows) follow the stories in their sections and restate parts of them: EQN-510 and EQN-001's span both say that two parts of the field share an equation exactly when they share a direction.
