#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round11/apply_pass9.py -- applies passes 9b and 9a of the proofs round (docs/round11/pass9b/apply.json, the periodicity map, the ABS
classes from ideals and the dimension group; docs/round11/pass9a/apply.json, fibre and base in the matter chapter) to the tables and the
Atiyah analysis page, 9b first, then 9a.

Modelled on docs/round10/apply_pass8c.py. Idempotent: a second run writes the same bytes. In order:
  1 content/rows.json        GEN-017 ... GEN-020 (9b) after GEN-016 and FUR-007 ... FUR-014 (9a) after FUR-006, since v2.12 (the twelve ids are
                             free: GEN-001 ... GEN-016 and FUR-001 ... FUR-006 stand, the GEN-5xx and FUR-5xx, FUR-6xx ids are story rows; a row
                             that holds one of the twelve ids and is not an earlier copy of its pass stops the script); every (page, order) of
                             the two passes free page-wide, and a row on cells, section cards, with a concrete first cell (its card links to
                             the cell of that entry when its text names no Cl(p,q) early: src/app/queries.js, cellCards). An entry on a page
                             the story overlay adds (matter/model) is not written here but by tools/merge_story.mjs from step 1b, which
                             appends it and records it in its book (content/story/merged.json); a row keeps it here once that book shows the
                             merge wrote it, so a run after npm run content writes the same bytes. Before this script ran, R4 set in 9b's
                             file the first cells of GEN-019 and GEN-020, (8,0,0) and (1,1,0), GEN-018's order on clock, 1004 (1003 is taken
                             page-wide), and two escapes of the page's markdown, and in 9a's FUR-013's order on steps/coupling, 30 (with 22,
                             below its 29 on matter, its home moved there); both files record it in their notes
 1b content/story/furey.json the layout entries (add: true) of the 9a rows on matter/model, after those of FUR-006, CAND-102 and CAND-049
  2 content/texts.json       their research texts (status draft; sources pass9b:period-map, pass9a:fibre-base), each after the texts of the row
                             before it and after the row's own learner texts, if any (the order tools/merge_learner_texts.mjs keeps: by row,
                             then level)
  3 content/checks.json      the check records of checks/selfcheck/proofs/period_map.py (pm.*) and fibre_base.py (fb.*), after chain_blocks.py
  4 content/check_runs.json  their run records: each stored log ends with the record's last line, its tagged check lines count the record's
                             checks and tags, and its fault log holds the pass's wrong versions in order, each exit 1, with as many FAIL lines
                             as its own last line counts (the counts of each RESULT.md, section 4)
  5 content/lenses.json      atiyah 100 -> 103 (two entries of 9b, one of 9a), alg 132 -> 135 (9b), cat 153 -> 154 (9b), furey 20 -> 24 and
                             schuller 113 -> 115 (9a); a block is found by its key, not by its name (9b's `lens` is atiyah, 9a's is furey;
                             9b's `lens_cat` and 9a's `lens_schuller`, `lens_atiyah` are new names), each entry with the keys, in their order,
                             of its lens's own entries, appended after them; the lens's own entries keep their bytes (the report and matrix
                             entries of furey and schuller among them)
  6 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence)
  7 content/analyses.json    the four check ids pm.* and the eight fb.* join the list of the entry atiyah (the only analysis either pass
                             names); the file is read again just before it is written and only that list is touched, as text
  8 public/reports/analyses/src/atiyah_lens.md   section 9: items 30 (9b) and 31 (9a) after item 29; 9a's edits of its first paragraph and
                             of the sources extend 9b's (their anchors are 9b's replacements), so each such pair is composed into one
                             replacement of the sentence of 2.11.0; theme 1 (9b) and theme 6 (9a), *The Atlas.*; the lens record (103 entries,
                             32 from the checks of section 9, the readings counted from the regenerated table); the learner texts that the
                             list of what is not done names (the rows of items 30 and 31; the drafts of round 11 cover those of items 19 to 29)
  9 node tools/make_analysis.mjs atiyah    renders the page
The `pass` value of the two files is the pass's name ("9b", "9a"), where pass 8c wrote "round10/pass8c". Each table keeps its own JSON form
(indent 1, UTF-8, with or without the final newline it had).
Usage (from anywhere): python3 docs/round11/apply_pass9.py [--no-node]    --no-node skips steps 6 and 9 (and leaves the count of readings of step 8)
"""
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
said = []


def path(rel):
    return os.path.join(ROOT, rel)


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    return json.loads(raw), raw.endswith('\n')


def save(rel, data, newline):
    text = json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')
    old = open(path(rel), encoding='utf-8').read()
    if text != old:
        open(path(rel), 'w', encoding='utf-8').write(text)
        said.append(f'wrote {rel}')
    else:
        said.append(f'unchanged {rel}')


def swap(text, find, repl, what):
    """replace the one occurrence of find by repl; a second run finds repl in place and changes nothing"""
    if repl in text and (find not in text or find in repl):
        return text
    assert text.count(find) == 1, f'{what}: the phrase to replace is not there once ({text.count(find)} times): {find[:90]!r}'
    return text.replace(find, repl)


# ---- the two passes, in the order they apply: 9b, then 9a (9a's page edits are written to follow 9b's)
B = json.load(open(os.path.join(HERE, 'pass9b', 'apply.json'), encoding='utf-8'))
A = json.load(open(os.path.join(HERE, 'pass9a', 'apply.json'), encoding='utf-8'))
PASSES = [
    {'C': B, 'name': '9b', 'src': 'pass9b:period-map', 'group': 'GEN', 'after': 'GEN-016', 'n': 30,
     'ids': [f'GEN-0{k}' for k in range(17, 21)], 'script': 'checks/selfcheck/proofs/period_map.py',
     'checks': ['pm.MAP', 'pm.ABS', 'pm.DG', 'pm.CAR'],
     'faults': [('OMEGAFIRST', 1), ('NOOMEGA', 2), ('NOSWAP', 6), ('UNGRADED', 4), ('PLAINTENSOR', 1), ('CLOCK2', 4), ('MULT8', 2)],
     'tags': {'bit': 19, 'bit==std': 4, 'ctl': 6, 'std': 4}, 'last': 'period_map: 33 checks, 0 fail',
     'where': {'GEN-017': [('rule', 'ideas', 29)], 'GEN-018': [('clock', 'clock', 1004), ('rule', 'ideas', 30)],
               'GEN-019': [('rule', 'ideas', 31), ('cells', 'cards', 69)], 'GEN-020': [('rule', 'ideas', 32), ('cells', 'cards', 70)]},
     'kind': {}, 'stage': {}, 'blocks': {'lens': 'atiyah', 'lens_alg': 'alg', 'lens_cat': 'cat'}},
    {'C': A, 'name': '9a', 'src': 'pass9a:fibre-base', 'group': 'FUR', 'after': 'FUR-006', 'n': 31,
     'ids': [f'FUR-0{k:02d}' for k in range(7, 15)], 'script': 'checks/selfcheck/proofs/fibre_base.py',
     'checks': ['fb.LR', 'fb.OCT', 'fb.TY', 'fb.MOD', 'fb.CHI', 'fb.COL', 'fb.S10', 'fb.DIR'],
     'faults': [('NOTWIST', 5), ('UNGRADED', 8), ('WRONGSIGN', 4), ('NOJ', 12), ('HH', 2), ('KKSIGN', 4)],
     'tags': {'bit': 36, 'bit==std': 9, 'ctl': 7, 'std': 10}, 'last': 'fibre_base: 62 checks, 0 fail',
     'where': {f'FUR-0{k:02d}': [('matter', 'furey', 16 + k), ('matter/model', 'axes', 1007 + k)] for k in range(7, 15)},
     'kind': {'FUR-014': 'reading'},
     'stage': {'FUR-007': 'A', 'FUR-008': 'O', 'FUR-009': 'A', 'FUR-010': 'A', 'FUR-011': 'A', 'FUR-012': 'O', 'FUR-013': 'F', 'FUR-014': 'A'},
     'blocks': {'lens': 'furey', 'lens_alg': 'alg', 'lens_schuller': 'schuller', 'lens_atiyah': 'atiyah'}},
]
# the further placements of 9a (docs/round11/pass9a/apply.json, notes: each after its anchor in its section's drawer)
PASSES[1]['where']['FUR-007'].append(('steps/schuller', 'sc-fibre', 507))
PASSES[1]['where']['FUR-011'].append(('steps/baez', 'bz-generation', 144))
PASSES[1]['where']['FUR-012'].append(('steps/baez', 'bz-generation', 182))
PASSES[1]['where']['FUR-013'].append(('steps/coupling', 'eq-coupling', 30))   # 30, not 22: its home stays on matter (R4, 9a's notes)
ALL_IDS = [i for P in PASSES for i in P['ids']]
ALL_CHECKS = [c for P in PASSES for c in P['checks']]
LENS_N0 = {'atiyah': 100, 'alg': 132, 'cat': 153, 'furey': 20, 'schuller': 113}   # the dictionaries of 2.11.0
CONCRETE = re.compile(r'^\((\d{1,2}),(\d{1,2}),(\d{1,2})\)$')

for P in PASSES:
    C = P['C']
    assert C['pass'] == P['name'] and C['since'] == 'v2.12', (P['name'], C['pass'], C['since'])
    assert [r['id'] for r in C['rows']] == P['ids'], [r['id'] for r in C['rows']]
    assert not C['row_text_edits'], f"pass {P['name']} proposes no edit of a research text"
    assert C['files']['script'] == P['script'], C['files']['script']
    assert all(os.path.exists(path(C['files'][k])) for k in ('script', 'log', 'faultLog')), C['files']
    assert [a['id'] for a in C['analyses']] == ['atiyah'] and C['analyses'][0]['checks_add'] == P['checks'], \
        f"pass {P['name']}: the one analysis it names is atiyah, with its check ids"
    assert {k: C[k]['key'] for k in C if k == 'lens' or k.startswith('lens_')} == P['blocks'], f"pass {P['name']}: the lens blocks"

# ===================================================================================================================== 1 rows
rows, nl = load('content/rows.json')


def pass_of(rid):
    return next(P for P in PASSES if rid in P['ids'])


def earlier_copy(r):
    P = pass_of(r['id'])
    return (r.get('since') == 'v2.12' and r.get('group') == P['group'] and bool(r.get('evidence'))
            and all(e.get('script') == P['script'] for e in r['evidence']))


clash = [r['id'] for r in rows if r['id'] in ALL_IDS and not earlier_copy(r)]
if clash:
    sys.exit(f'the ids {clash} are taken by other rows of content/rows.json: renumber the pass from the next free id of its group')
rows = [r for r in rows if r['id'] not in ALL_IDS]
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])}
mine = [(s['page'], s['order']) for P in PASSES for r in P['C']['rows'] for s in r['shownOn']]
assert len(mine) == len(set(mine)) and not set(mine) & taken, 'an order of the passes is taken (page-wide) or used twice'
sections = {p['route']: {s.get('id') for s in p.get('sections') or []} for p in json.load(open(path('content/pages.json'), encoding='utf-8'))}
for P in PASSES:
    for r in P['C']['rows']:
        rid = r['id']
        assert r['since'] == 'v2.12' and r['group'] == P['group'], rid
        assert (r['kind'], r['stage']) == (P['kind'].get(rid, 'computation'), P['stage'].get(rid, 'A')), (rid, r['kind'], r['stage'])
        assert [(s['page'], s['section'], s['order']) for s in r['shownOn']] == P['where'][rid], rid
        assert all(s['role'] == 'detail' and s['section'] in sections.get(s['page'], ()) for s in r['shownOn']), f'{rid}: a role or a section'
        if any((s['page'], s['section']) == ('cells', 'cards') for s in r['shownOn']):
            m = CONCRETE.match(r['cells'][0]) if r['cells'] else None
            assert m and sum(map(int, m.groups())) <= 8, f"{rid}: a card of the cells page needs a concrete first cell, n <= 8: {r['cells'][:1]}"
# An entry on a page the story overlay adds (content/story/furey.json: the five sub-pages of matter) goes through that file's layout
# (add: true, step 1b), as those of FUR-006, CAND-102 and CAND-049 do: tools/merge_story.mjs appends it after the row's own entries and records
# it in its book (content/story/merged.json, key "<row>|<page>|add|<index>", the sha1 digest of the entry), and the tables without the overlay
# (its baseTables) stay valid. Here a row keeps such an entry only once the book shows the merge wrote it, at the place the merge puts it.
FUREY = 'content/story/furey.json'
fy, fy_nl = load(FUREY)
OVERLAY = {p['route'] for p in fy['pages'] if 'page' in p}
assert OVERLAY == {'matter/dictionary', 'matter/papers', 'matter/model', 'matter/generations', 'matter/help'}, OVERLAY
book = json.load(open(path('content/story/merged.json'), encoding='utf-8')).get('entries', {})
digest = lambda so: hashlib.sha1(json.dumps(so, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()[:20]
layout = []   # the layout entries of the passes, in the order of the rows
for P in PASSES:
    put = []
    for r in P['C']['rows']:
        own = [s for s in r['shownOn'] if s['page'] not in OVERLAY]
        over = [s for s in r['shownOn'] if s['page'] in OVERLAY]
        wrote = [(book.get(f"{r['id']}|{s['page']}|add|{len(own) + k}") or {}).get('wrote') == digest(s) for k, s in enumerate(over)]
        assert all(wrote) or not any(wrote), f"{r['id']}: the merge wrote some of its overlay entries and not the others: run npm run content"
        put.append({**r, 'shownOn': own + (over if all(wrote) else [])})
        layout += [{'row': r['id'], 'page': s['page'], 'section': s['section'], 'order': s['order'], 'role': s['role'], 'add': True} for s in over]
    at = next(i for i, r in enumerate(rows) if r['id'] == P['after'])
    rows[at + 1:at + 1] = put
ids = {r['id'] for r in rows}
thm = {t['id'] for t in json.load(open(path('content/theorems.json'), encoding='utf-8'))}
for P in PASSES:
    for r in P['C']['rows']:
        for d in r['depends']:
            assert d['id'] in ids or d['id'] in thm, f"{r['id']} depends on an unknown row {d['id']}"
        for e in r['evidence']:
            assert e['mode'] == 'ran' and e['script'] == P['script'] and e['check'] in P['checks'], r['id']
save('content/rows.json', rows, nl)

# ---- 1b the story overlay's layout: the entries of the passes on its sub-pages, after the earlier proofs rounds' (FUR-006, CAND-102, CAND-049)
keep = [l for l in fy['layout'] if l['row'] not in ALL_IDS]
assert keep[-1]['row'] == 'CAND-049' and all(list(l.keys()) == list(keep[-1].keys()) for l in layout), 'the layout of the story overlay'
assert [l['row'] for l in layout] == [f'FUR-0{k:02d}' for k in range(7, 15)] and all(l['page'] == 'matter/model' for l in layout), 'one entry per row of 9a'
fy['layout'] = keep + layout
save(FUREY, fy, fy_nl)

# ===================================================================================================================== 2 texts
texts, nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'])
mine = {key(t) for P in PASSES for t in P['C']['texts']}
texts = [t for t in texts if key(t) not in mine]
assert all(t['level'] == 'learner' for t in texts if t['row'] in ALL_IDS), 'another research text of the twelve rows stands in content/texts.json'
for P in PASSES:
    C = P['C']
    assert [t['row'] for t in C['texts']] == P['ids'], f"pass {P['name']}: one research text per row, in the order of the rows"
    for t in C['texts']:
        assert (t['status'], t['source'], t['level'], t['lens'], t['mode'], t['register'], t['lang']) == \
            ('draft', P['src'], 'research', None, 'both', 'full', 'en'), t['row']
        assert not re.search(r'/home/|@[\w-]+\.\w', t['body']), f"{t['row']}: a machine path or a contact detail"
    # after the last text of the row before the pass; a row's research text after its own learner texts (by row, then level)
    at = start = max(i for i, t in enumerate(texts) if t['row'] == P['after']) + 1
    for t in C['texts']:
        while at < len(texts) and texts[at]['row'] == t['row']:
            at += 1
        texts.insert(at, t)
        at += 1
    assert texts[start - 1]['row'] < P['ids'][0] and (at == len(texts) or texts[at]['row'] > P['ids'][-1]), f"pass {P['name']}: the texts out of row order"
save('content/texts.json', texts, nl)

# ===================================================================================================================== 3 the check records
checks, nl = load('content/checks.json')
cids = [c['id'] for P in PASSES for c in P['C']['checks']]
checks = [c for c in checks if c['id'] not in cids]
assert checks[-1]['id'] == 'selfcheck/proofs/chain_blocks.py', checks[-1]['id']
assert not any(x['id'] in ALL_CHECKS for c in checks for x in c.get('ids') or []), 'a pm.* or fb.* id in another record'
form = list(checks[-1].keys())
for P in PASSES:
    C = P['C']
    for c in C['checks']:
        assert list(c.keys()) == form and c['id'] == P['script'][len('checks/'):] and c['since'] == 'v2.12', c['id']
        assert c['script'] == P['script'] and c['log'] == C['files']['log'], c['id']
        assert [x['id'] for x in c['ids']] == P['checks'] and c['rowsNaming'] == P['ids'], c['id']
    checks += C['checks']
save('content/checks.json', checks, nl)

# ===================================================================================================================== 4 the run records
# the stored log: its tagged check lines (all ok) count the record's checks and tags, and its last line is the record's; the fault log: the
# pass's wrong versions in order, each "--fault X: exit 1", with as many FAIL lines as its own "last:" line counts (RESULT.md, section 4)
runs, nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
mine = {rk(r) for P in PASSES for r in P['C']['check_runs']}
runs = [r for r in runs if rk(r) not in mine]
TAG = re.compile(r'^  (ok|FAIL) +\[(bit|bit==std|ctl|std)\] ')
for P in PASSES:
    C = P['C']
    name = os.path.basename(P['script'])[:-len('.py')]
    total = sum(P['tags'].values())
    log = open(path(C['files']['log']), encoding='utf-8').read().rstrip('\n').split('\n')
    hits = [m for m in map(TAG.match, log) if m]
    tags = {k: sum(1 for m in hits if m.group(2) == k) for k in P['tags']}
    assert all(m.group(1) == 'ok' for m in hits) and len(hits) == total and tags == P['tags'], (P['name'], tags)
    assert log[-1] == P['last'] == f'{name}: {total} checks, 0 fail', log[-1]
    tagword = ', '.join(f'{k} {v}' for k, v in P['tags'].items())
    for r in C['check_runs']:
        assert r['script'] == P['script'] and r['source'] == C['files']['log'] and list(r.keys()) == list(runs[-1].keys()), r['script']
        assert r['passed'] is True and r['ok'] == total and r['fail'] == 0 and r['lastLine'] == log[-1], r['script']
        assert f'tags {tagword}' in r['status'] and f"{len(P['faults'])} --fault runs each exit 1" in r['status'], r['status']
    got = []
    for b in re.split(r'^(?=--fault )', open(path(C['files']['faultLog']), encoding='utf-8').read(), flags=re.M):
        if not b.strip():
            continue
        head = re.match(r'--fault (\w+): exit 1\n', b)
        last = re.search(rf'^last: {name}: (\d+) checks, (\d+) fail$', b, re.M)
        nfail = len(re.findall(r'^  FAIL +\[', b, re.M))
        assert head and last and int(last.group(1)) == total and int(last.group(2)) == nfail >= 1, (P['name'], b[:80])
        got.append((head.group(1), nfail))
    assert got == P['faults'], (P['name'], got)
    runs += C['check_runs']
save('content/check_runs.json', runs, nl)

# ===================================================================================================================== 5 the lenses
# a block is found by its key; each entry has the keys of its lens's own entries, in their order, and is appended after them
lenses, nl = load('content/lenses.json')
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows'] and e['atlas'] == f['atlas']
adds = {}
for P in PASSES:
    for blk, lkey in P['blocks'].items():
        for e in P['C'][blk]['dictionary_add']:
            assert e['evidence'] and set(e['evidence']) <= set(P['checks']) and e['rows'] and set(e['rows']) <= set(P['ids']), (lkey, e['atlas'][:40])
            assert e['flags'] == ['checked'] and e['from'].endswith(f"(pass {P['name']})"), (lkey, e['from'])
            adds.setdefault(lkey, []).append(e)
assert {k: len(v) for k, v in adds.items()} == {'atiyah': 3, 'alg': 3, 'cat': 1, 'furey': 4, 'schuller': 2}, {k: len(v) for k, v in adds.items()}
for lkey, add in adds.items():
    lens = next(x for x in lenses if x['key'] == lkey)
    form = list(lens['dictionary'][0].keys())
    assert all(list(e.keys()) == form for e in lens['dictionary'] + add), f'{lkey}: an entry in another form than the lens keeps'
    keep = [e for e in lens['dictionary'] if not any(same(e, f) for f in add)]
    assert len(keep) == LENS_N0[lkey], (lkey, len(keep))
    lens['dictionary'] = keep + add
    said.append(f"the lens {lkey}: {LENS_N0[lkey]} -> {len(lens['dictionary'])} dictionary entries")
save('content/lenses.json', lenses, nl)
aty_dict = next(x for x in lenses if x['key'] == 'atiyah')['dictionary']

# ===================================================================================================================== 6 the lens readings
if not NO_NODE:
    out = subprocess.run(['node', 'tools/migrate/lens_readings.mjs'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout[-1500:])
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('lens_readings.mjs failed')
    said.append('ran tools/migrate/lens_readings.mjs')

# ===================================================================================================================== 7 the analyses registry
# the check ids of the entry atiyah, as text (read again now, written back at once): 9b's pm.*, then 9a's fb.*
rel = 'content/analyses.json'
raw = open(path(rel), encoding='utf-8').read()
before = json.loads(raw)
text = raw
m = re.search(r'\n(\s*)"id": "atiyah",', text)
assert m, 'the entry atiyah of content/analyses.json'
c = text.index('"checks": [', m.end())
end = text.index(']', c)
body = text[c + len('"checks": ['):end]
have = json.loads('[' + body + ']')
want = [x for x in ALL_CHECKS if x not in have]
if want:
    ind = re.search(r'\n(\s*)"', body).group(1)
    stripped = body.rstrip()
    new_body = stripped + ''.join(f',\n{ind}{json.dumps(x, ensure_ascii=False)}' for x in want) + body[len(stripped):]
    text = text[:c] + '"checks": [' + new_body + text[end:]
if text != raw:
    after = json.loads(text)
    a_old = next(x for x in before if x.get('id') == 'atiyah')
    a_new = next(x for x in after if x.get('id') == 'atiyah')
    assert a_new['checks'] == a_old['checks'] + want and {k: v for k, v in a_new.items() if k != 'checks'} == {k: v for k, v in a_old.items() if k != 'checks'}
    assert [x for x in after if x.get('id') != 'atiyah'] == [x for x in before if x.get('id') != 'atiyah']
    if open(path(rel), encoding='utf-8').read() != raw:
        sys.exit(f'{rel} changed while this step read it: run again')
    open(path(rel), 'w', encoding='utf-8').write(text)
    said.append(f'wrote {rel} (atiyah gains {len(want)} check ids)')
else:
    said.append(f'unchanged {rel}')

# ===================================================================================================================== 8 the Atiyah page
rel = 'public/reports/analyses/src/atiyah_lens.md'
md = open(path(rel), encoding='utf-8').read()
md0 = md
PAGE = []
for P in PASSES:
    an = P['C']['analyses'][0]
    assert an['source'] == rel and an['section9_numbering'].startswith(f"R4: {{n}} = {P['n']},"), an['section9_numbering']
    PAGE.append((P, an, (lambda n: lambda s: s.replace('{n}', str(n)))(P['n'])))

# section 9's items 30 (9b) and 31 (9a), after item 29
items = []
for P, an, fill in PAGE:
    its = [fill(s) for s in an['section9_items']]
    assert len(its) == 1 and its[0].startswith(f"{P['n']}. ") and '\n' not in its[0] and '{n}' not in its[0], P['name']   # 2^{n+8} stays
    items += its
lines = md.split('\n')
i29 = next(i for i, l in enumerate(lines) if l.startswith("29. *The chain of Cl(8)'s*"))
if lines[i29 + 1:i29 + 1 + len(items)] != items:
    assert not any(l.startswith(('30. ', '31. ')) for l in lines), 'an item 30 or 31 stands elsewhere'
    lines[i29 + 1:i29 + 1] = items
md = '\n'.join(lines)

# the edits, 9b's five and 9a's five. A 9a edit "after pass 9b's edit" finds a phrase of one of 9b's replacements: the pair is composed into one
# replacement of the sentence of 2.11.0, which a second run finds in place (two edits in a row on one sentence would lose their anchor)
WHERE_B = ['section 5, theme 1, *The Atlas.*', 'section 9, first paragraph', 'section 9, first paragraph', 'Sources, the Atlas', 'Sources, section 9']
WHERE_A = ['section 5, theme 6, *The Atlas.*', "section 9, first paragraph (after pass 9b's edit of it)",
           "section 9, first paragraph (after pass 9b's edit of it)", "Sources, the Atlas (after pass 9b's edit)", "Sources, section 9 (after pass 9b's edit)"]
(_, eb, fill_b), (_, ea, fill_a) = PAGE
assert [e['where'] for e in eb['edits']] == WHERE_B and [e['where'] for e in ea['edits']] == WHERE_A
plan = [[e['where'], e['find'], fill_b(e['replace'])] for e in eb['edits']]
for e in ea['edits']:
    find, repl = e['find'], fill_a(e['replace'])
    if "after pass 9b's edit" in e['where']:
        host = [p for p in plan[:len(eb['edits'])] if p[2].count(find) == 1]
        assert len(host) == 1, f"9a's edit {e['where']!r}: its anchor is not in exactly one of 9b's replacements"
        host[0][2] = host[0][2].replace(find, repl)
        host[0][0] += ', with 9a'
    else:
        plan.append([e['where'], find, repl])
for where, find, repl in plan:
    assert '{n}' not in repl and 'R4:' not in repl, where
    md = swap(md, find, repl, where)

# section 7, the lens record: the entries of the dictionary, those from the checks of section 9 (their source names a pass), the readings
n_dict = len(aty_dict)
n_sec9 = sum(1 for e in aty_dict if re.search(r'\(pass [^)]*\)$', e['from']))
assert (n_dict, n_sec9) == (103, 32), (n_dict, n_sec9)
assert md.count('28 entries from the narrative and the map above, 43 from the five readings,') == 1 and 28 + 43 + n_sec9 == n_dict
for pat in (r'carries a dictionary of \d+ entries', r'\d+ from the checks of section 9\.', r'The result is \d+ readings on \d+ rows\.'):
    assert len(re.findall(pat, md)) == 1, pat
md = re.sub(r'carries a dictionary of \d+ entries', f'carries a dictionary of {n_dict} entries', md)
md = re.sub(r'\d+ from the checks of section 9\.', f'{n_sec9} from the checks of section 9.', md)
if not NO_NODE:
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    a = [r for r in lr if r['lens'] == 'atiyah']
    n_read, n_rows = len(a), len({r['row'] for r in a})
    md = re.sub(r'The result is \d+ readings on \d+ rows\.', f'The result is {n_read} readings on {n_rows} rows.', md)
    said.append(f'the lens atiyah: {n_read} readings on {n_rows} rows')

# section 9, what is not done: the learner texts not written are now those of the rows of items 30 and 31 (round 11's drafts cover 19 to 29)
learner = {t['row'] for t in json.load(open(path('content/texts.json'), encoding='utf-8')) if t['level'] == 'learner'}
aty = sorted(i for i in ids if i.startswith('ATY-'))
assert aty == [f'ATY-{k:03d}' for k in list(range(1, 48)) + list(range(51, 56))], 'the ATY rows the sentence names'
assert all(i in learner for i in aty + [f'GEN-0{k}' for k in range(10, 17)]), 'a row the sentence says has a learner draft has none'
assert not any(i in learner for i in ALL_IDS), 'a row of items 30 and 31 has a learner text: the sentence must say so'
md = swap(md, 'learner texts for the rows of items 19 to 29 (ATY-042 to ATY-047, ATY-051 to ATY-055, GEN-010 to GEN-016; the rows ATY-001 to '
          'ATY-041 have learner drafts).', 'learner texts for the rows of items 30 and 31 (GEN-017 to GEN-020, FUR-007 to FUR-014; the rows ATY-001 '
          'to ATY-047, ATY-051 to ATY-055 and GEN-010 to GEN-016 have learner drafts).', 'the learner texts not written')

for must in items + [p[2] for p in plan] + ['24 to 28 pass 8b, 29 pass 8c, 30 pass 9b, 31 pass 9a.', f'carries a dictionary of {n_dict} entries',
                                            f'{n_sec9} from the checks of section 9.', 'learner texts for the rows of items 30 and 31 (GEN-017 to GEN-020,']:
    assert md.count(must) == 1, must[:90]
assert md.count('section 9 item 30)') == 1 and md.count('section 9 item 31)') == 1, 'theme 1 points to item 30, theme 6 to item 31'
assert not any(p in md for p in ('{n}', 'R4:', 'R2:', 'N readings on M rows')), 'a placeholder or a note of the passes left on the page'
if md != md0:
    open(path(rel), 'w', encoding='utf-8').write(md)
    said.append(f'wrote {rel}')
else:
    said.append(f'unchanged {rel}')

# ---- 9 the page
if not NO_NODE:
    out = subprocess.run(['node', 'tools/make_analysis.mjs', 'atiyah'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout)
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('make_analysis.mjs failed')

print('\n'.join(said))
