# SPDX-License-Identifier: MIT
"""GRV-011 ("with decay at infinity Phi_t = Phi_s: the standard argument, not run"): the step that was not run, made finite.
The space equations of the weak static limit force every second derivative of psi = Phi_t - Phi_s to vanish, d_i d_j psi = 0 (GRV-011 (b)).
(1) Exact linear algebra over Q: on polynomials in (x, y, z) of total degree <= d, d = 2 ... 6, the kernel of the Hessian map
    psi -> (d_i d_j psi)_{i<=j} is exactly the 4-dimensional space of affine functions a + b.x (rank of the Hessian = dim - 4), and of those
    only psi = 0 is bounded at infinity (an affine function with (a, b) != 0 is unbounded: the plain argument, finite because the kernel is).
(2) The general statement is one line: d_i d_j psi = 0 for all i, j gives d psi constant (integrate along lines), so psi is affine on R^3,
    and an affine function that tends to 0 (or stays bounded) at infinity is 0.  So Phi_t = Phi_s under decay (or boundedness), with no
    polynomial restriction.  The script also checks the control: on the kernel of the Laplacian alone (harmonic polynomials, the trace of the
    Hessian), the kernel is much larger (dimension 2d + 1 in each degree d), so the trace equation alone would not give Phi_t = Phi_s.
Controls (--fault, each exits 1): KER3 claims the Hessian kernel has dimension 3; LAP claims the Laplacian kernel equals the affine functions.
usage: python3 -I -B grv011_hessian_affine.py [--fault KER3|LAP]"""
import sys, itertools
from fractions import Fraction as Fr

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond: FAILS.append(msg)

def monos(d):
    return [(a, b, c) for a in range(d + 1) for b in range(d + 1 - a) for c in range(d + 1 - a - b)]

def rank(M):
    M = [list(map(Fr, row)) for row in M]
    if not M: return 0
    r = 0; cols = len(M[0])
    for c in range(cols):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]
        inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        r += 1
    return r

def dd(m, i, j):
    """coefficient map of d_i d_j on monomial m: returns (coefficient, monomial) or None"""
    e = list(m); coef = 1
    for k in (i, j):
        if e[k] == 0: return None
        coef *= e[k]; e[k] -= 1
    return coef, tuple(e)

def main():
    for d in range(2, 7):
        ms = monos(d); idx = {m: i for i, m in enumerate(ms)}
        rows = []
        for (i, j) in [(0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2)]:
            row_space = {}
            for m in ms:
                r = dd(m, i, j)
                if r:
                    coef, mm = r
                    row_space.setdefault(mm, [0] * len(ms))[idx[m]] += coef
            rows += list(row_space.values())
        ker = len(ms) - rank(rows)
        want = 3 if FAULT == 'KER3' else 4
        ck(ker == want, 'degree <= %d (%d monomials): kernel of the Hessian has dimension %d = the affine functions a + b.x' % (d, len(ms), ker))
        # Laplacian alone
        lap = {}
        for m in ms:
            for k in range(3):
                r = dd(m, k, k)
                if r:
                    coef, mm = r; lap.setdefault(mm, [0] * len(ms))[idx[m]] += coef
        kl = len(ms) - rank(list(lap.values()))
        expect = sum(2 * k + 1 for k in range(d + 1))
        ck((kl == expect) if FAULT != 'LAP' else (kl == 4), 'control: the Laplacian alone has kernel dimension %d (harmonic polynomials, sum of 2k+1) >> 4' % kl)
    print('FAILS: %s' % (FAILS or 'none')); sys.exit(1 if FAILS else 0)

if __name__ == '__main__':
    main()
