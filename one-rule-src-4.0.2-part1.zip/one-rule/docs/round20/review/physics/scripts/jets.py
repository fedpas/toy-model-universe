# SPDX-License-Identifier: MIT
"""jets.py -- exact truncated multivariate Taylor polynomials (Fraction coefficients) and an exact Christoffel
curvature route at the base point.  Reviewer's own kernel (no Atlas import).

A jet of order D in n variables is a dict {exponent tuple -> Fraction}, truncated at total degree D.
Functions exp/sin/cos/sinh/cosh take the exact value(s) at the base point as arguments so that every
coefficient stays rational (base points with e^{a0}, cos t0, sin t0 rational)."""
from fractions import Fraction as Fr
from itertools import product
from math import factorial

class Jet:
    def __init__(self, n, D, c=None):
        self.n, self.D = n, D
        self.c = {} if c is None else {k: v for k, v in c.items() if v != 0}
    @staticmethod
    def const(n, D, v):
        return Jet(n, D, {(0,) * n: Fr(v)}) if v != 0 else Jet(n, D)
    @staticmethod
    def var(n, D, i, v0=0):
        e = tuple(int(j == i) for j in range(n))
        c = {e: Fr(1)}
        if v0 != 0: c[(0,) * n] = Fr(v0)
        return Jet(n, D, c)
    def __add__(self, o):
        if not isinstance(o, Jet): o = Jet.const(self.n, self.D, o)
        c = dict(self.c)
        for k, v in o.c.items(): c[k] = c.get(k, 0) + v
        return Jet(self.n, self.D, c)
    __radd__ = __add__
    def __neg__(self): return Jet(self.n, self.D, {k: -v for k, v in self.c.items()})
    def __sub__(self, o): return self + (-o if isinstance(o, Jet) else -Fr(o))
    def __rsub__(self, o): return (-self) + o
    def __mul__(self, o):
        if not isinstance(o, Jet):
            o = Fr(o); return Jet(self.n, self.D, {k: v * o for k, v in self.c.items()})
        c = {}
        for k1, v1 in self.c.items():
            d1 = sum(k1)
            for k2, v2 in o.c.items():
                if d1 + sum(k2) > self.D: continue
                k = tuple(a + b for a, b in zip(k1, k2))
                c[k] = c.get(k, 0) + v1 * v2
        return Jet(self.n, self.D, c)
    __rmul__ = __mul__
    def val(self): return self.c.get((0,) * self.n, Fr(0))
    def d(self, i):
        """partial derivative (as a jet of the same order, exact up to degree D-1)"""
        c = {}
        for k, v in self.c.items():
            if k[i] > 0:
                kk = list(k); kk[i] -= 1
                c[tuple(kk)] = c.get(tuple(kk), 0) + v * k[i]
        return Jet(self.n, self.D, c)
    def coeff(self, k): return self.c.get(tuple(k), Fr(0))
    def deriv_at0(self, idx):
        """value of the mixed partial derivative with index tuple idx at the base point (exact if sum(idx) <= D)"""
        k = [0] * self.n
        for i in idx: k[i] += 1
        f = 1
        for m in k: f *= factorial(m)
        return self.coeff(k) * f
    def nil(self):
        """the jet minus its constant term"""
        return self - self.val()
    def powers(self):
        """[1, x, x^2, ..., x^D] of the nilpotent part"""
        x = self.nil(); out = [Jet.const(self.n, self.D, 1)]
        for _ in range(self.D): out.append(out[-1] * x)
        return out
    def inv(self):
        a = self.val()
        if a == 0: raise ZeroDivisionError('jet with zero constant term')
        P = self.powers(); out = Jet(self.n, self.D)
        for k, pk in enumerate(P): out = out + pk * (Fr(-1) ** k / a ** (k + 1))
        return out
    def __truediv__(self, o):
        if isinstance(o, Jet): return self * o.inv()
        return self * (Fr(1) / Fr(o))
    def apply_series(self, derivs):
        """f(a0 + x) = sum_k derivs[k] x^k / k!, derivs[k] = f^{(k)}(a0) given exactly"""
        P = self.powers(); out = Jet(self.n, self.D)
        for k, pk in enumerate(P): out = out + pk * (Fr(derivs[k]) / factorial(k))
        return out

def jexp(j, e0):
    """exp of the jet, e0 = exp(value at base point) exact"""
    return j.apply_series([Fr(e0)] * (j.D + 1))
def jsinh(j, s0, c0): return j.apply_series([Fr(s0), Fr(c0)] * (j.D // 2 + 1))
def jcosh(j, s0, c0): return j.apply_series([Fr(c0), Fr(s0)] * (j.D // 2 + 1))
def jsin(j, s0, c0): return j.apply_series([Fr(s0), Fr(c0), -Fr(s0), -Fr(c0)] * (j.D // 4 + 1))
def jcos(j, s0, c0): return j.apply_series([Fr(c0), -Fr(s0), -Fr(c0), Fr(s0)] * (j.D // 4 + 1))

def mat_inv(M):
    """exact inverse of a matrix of jets (Gauss-Jordan with jet division)"""
    n = len(M); A = [[M[i][j] for j in range(n)] + [Jet.const(M[0][0].n, M[0][0].D, int(i == j)) for j in range(n)] for i in range(n)]
    for col in range(n):
        piv = next(i for i in range(col, n) if A[i][col].val() != 0)
        A[col], A[piv] = A[piv], A[col]
        pinv = A[col][col].inv(); A[col] = [x * pinv for x in A[col]]
        for i in range(n):
            if i != col and A[i][col].c:
                f = A[i][col]; A[i] = [u - f * w for u, w in zip(A[i], A[col])]
    return [row[n:] for row in A]

def curvature_at0(g):
    """g: n x n matrix of jets of order >= 2 (coordinate metric). Returns (ginv0, Gamma0, Riemann R^r_{smv} at 0 (MTW sign),
    Ricci R_{sv} = R^r_{srv} at 0, scalar R).  Gamma as jets (order >= 1), its derivatives at 0 exact."""
    n = len(g); gi = mat_inv(g)
    Gam = [[[Jet(g[0][0].n, g[0][0].D) for _ in range(n)] for _ in range(n)] for _ in range(n)]
    for r in range(n):
        for m in range(n):
            for v in range(n):
                s = Jet(g[0][0].n, g[0][0].D)
                for l in range(n):
                    s = s + gi[r][l] * (g[l][m].d(v) + g[l][v].d(m) - g[m][v].d(l))
                Gam[r][m][v] = s * Fr(1, 2)
    G0 = [[[Gam[r][m][v].val() for v in range(n)] for m in range(n)] for r in range(n)]
    dG = [[[[Gam[r][m][v].deriv_at0((k,)) for k in range(n)] for v in range(n)] for m in range(n)] for r in range(n)]
    Riem = [[[[Fr(0)] * n for _ in range(n)] for _ in range(n)] for _ in range(n)]
    for r in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(n):
                    x = dG[r][v][s][m] - dG[r][m][s][v]
                    for l in range(n): x += G0[r][m][l] * G0[l][v][s] - G0[r][v][l] * G0[l][m][s]
                    Riem[r][s][m][v] = x
    Ric = [[sum(Riem[r][s][r][v] for r in range(n)) for v in range(n)] for s in range(n)]
    gi0 = [[gi[i][j].val() for j in range(n)] for i in range(n)]
    Rs = sum(gi0[s][v] * Ric[s][v] for s in range(n) for v in range(n))
    return gi0, Gam, Riem, Ric, Rs
