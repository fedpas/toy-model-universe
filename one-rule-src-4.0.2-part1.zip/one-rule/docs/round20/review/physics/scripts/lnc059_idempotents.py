# SPDX-License-Identifier: MIT
"""LNC-059 ("the idempotents follow; not computed"), LNS-038 (staged edit) and CAND-144 (staged edit), with the reviewer's own bit rule.

(A) LNC-059: for every Cl(p,q) with p + q <= 7 (36 signatures, Cl(0,0) included), a maximal set of mutually commuting labels of square +1,
    closed under the product (a maximal totally singular subspace of the F_2 quadric q(a) = [e_a^2 = -1] for the commutation form), of
    dimension w; the 2^w elements prod_i (1 + s_i e_{b_i})/2 (b_i a basis, s_i = +-1) are nonzero, idempotent, mutually orthogonal, sum to 1
    and span the same 2^w-dimensional commutative algebra as the labels; and 2^w = (number of simple factors) x N for Cl(p,q) = M_N(D) or two
    copies (the clock table).
(B) LNS-038 (staged items 4c/4d): for every Cl(p,q) with 1 <= p + q <= 8 (44 cells) the F_2 linear system of a non-contextual value assignment
    v(e_a) in {+-1} on the labels of square +1 with v(e_a e_b) = v(e_a) v(e_b) for every commuting pair (sign of the rule included) is
    consistent exactly for 14 cells, listed; the other 30 contain a Mermin-type obstruction.
(C) CAND-144: with e1 = X x 1, e2 = Z x 1, e3 = iY x X, e4 = iY x Z (real 4 x 4) the nine blades of square +1 of Cl(2,2) are Mermin's nine
    two-qubit operators up to sign and the six commuting lines are his rows and columns, with the odd line sign.
Controls (--fault, each exits 1): SIGN the product sign dropped in (B) (then every cell is consistent); ONE a non-maximal set in (A) at Cl(2,2);
  MERMIN e4 = iY x X in (C) (not a Clifford frame).
usage: python3 -I -B lnc059_idempotents.py [--fault SIGN|ONE|MERMIN]"""
import sys, time, itertools
from fractions import Fraction as Fr
import numpy as np

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond: FAILS.append(msg)

def popcount(x): return bin(x).count('1')
def npairs(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << i) - 1))
        i += 1
    return c
class BR:
    def __init__(self, eps): self.eps = tuple(eps); self.n = len(eps)
    def s(self, a, b):
        v = -1 if npairs(a, b) & 1 else 1
        m = a & b; i = 0
        while m:
            if m & 1: v *= self.eps[i]
            m >>= 1; i += 1
        return v
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                out[a ^ b] = out.get(a ^ b, 0) + self.s(a, b) * ca * cb
        return {k: v for k, v in out.items() if v != 0}
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)

def clock_type(p, q):
    """(number of simple factors, N, D) for Cl(p,q) = M_N(D) or 2 copies, from the Bott table"""
    n = p + q; c = (p - q) % 8
    dim = 2 ** n
    if c in (0, 2): k, D, d = 1, 'R', 1
    elif c == 1: k, D, d = 2, 'R', 1
    elif c in (3, 7): k, D, d = 1, 'C', 2
    elif c in (4, 6): k, D, d = 1, 'H', 4
    else: k, D, d = 2, 'H', 4
    N2 = dim // (k * d); N = int(round(N2 ** 0.5)); assert N * N == N2
    return k, N, D

def maximal_singular_subspace(A):
    """backtracking: a maximal set of mutually commuting labels of square +1, closed under xor (a subspace), of largest dimension"""
    n = A.n; plus = [a for a in range(1, 1 << n) if A.sq(a) == 1]
    best = []
    def extend(basis, span):
        nonlocal best
        if len(basis) > len(best): best = list(basis)
        for a in plus:
            if a in span or a <= (basis[-1] if basis else 0): continue
            if all(A.commute(a, b) for b in span):
                new = set(span) | {a ^ x for x in span}
                extend(basis + [a], new)
    extend([], {0})
    return best

def check_A():
    for n in range(0, 8):
        for p in range(n + 1):
            q = n - p; A = BR([1] * p + [-1] * q)
            basis = maximal_singular_subspace(A)
            if FAULT == 'ONE' and (p, q) == (2, 2): basis = basis[:1]
            w = len(basis)
            k, N, D = clock_type(p, q)
            idem = []
            for signs in itertools.product((1, -1), repeat=w):
                x = {0: Fr(1)}
                for s_, b in zip(signs, basis):
                    x = A.mul(x, {0: Fr(1, 2), b: Fr(s_, 2)})
                idem.append(x)
            ok_nonzero = all(len(x) > 0 for x in idem)
            ok_idem = all(A.mul(x, x) == x for x in idem)
            ok_orth = all(A.mul(idem[i], idem[j]) == {} for i in range(len(idem)) for j in range(len(idem)) if i != j)
            tot = {}
            for x in idem:
                for kk, v in x.items(): tot[kk] = tot.get(kk, 0) + v
            ok_sum = {kk: v for kk, v in tot.items() if v != 0} == {0: Fr(1)}
            span = {0}
            for b in basis: span |= {b ^ x for x in span}
            ok_span = all(set(x.keys()) <= span for x in idem) and len(span) == 2 ** w
            ok_count = (2 ** w == k * N)
            ck(ok_nonzero and ok_idem and ok_orth and ok_sum and ok_span and ok_count,
               'Cl(%d,%d): w = %d, 2^w = %d = %d x N(%d) (%s); the %d idempotents prod(1 +- e_b)/2 are nonzero, orthogonal, sum to 1, span the 2^w labels'
               % (p, q, w, 2 ** w, k, N, D, 2 ** w))

def f2_consistent(rows, nvar):
    """rows: list of (set of variable indices, rhs bit); Gaussian elimination over F_2 with bitmasks"""
    piv = {}
    for vars_, rhs in rows:
        m = 0
        for v in vars_: m ^= (1 << v)
        r = rhs
        while m:
            top = m.bit_length() - 1
            if top in piv:
                pm, pr = piv[top]; m ^= pm; r ^= pr
            else:
                piv[top] = (m, r); break
        else:
            if r: return False
    return True

def check_B():
    consistent = []
    for n in range(1, 9):
        for p in range(n + 1):
            q = n - p; A = BR([1] * p + [-1] * q)
            plus = [a for a in range(1, 1 << n) if A.sq(a) == 1]
            idx = {a: i for i, a in enumerate(plus)}
            rows = []
            for i, a in enumerate(plus):
                for b in plus[i + 1:]:
                    if A.commute(a, b):
                        c = a ^ b; sgn = A.s(a, b)
                        assert A.sq(c) == 1
                        bit = 1 if (sgn == -1 and FAULT != 'SIGN') else 0
                        rows.append(({idx[a], idx[b], idx[c]} if c else {idx[a], idx[b]}, bit))
            if f2_consistent(rows, len(plus)): consistent.append((p, q))
    expect = {(1, 0), (0, 1), (2, 0), (1, 1), (0, 2), (3, 0), (2, 1), (1, 2), (0, 3), (4, 0), (1, 3), (0, 4), (5, 0), (1, 4)}
    ck(set(consistent) == expect, 'LNS-038 edit: a consistent +-1 assignment on the commuting products of +1-blades exists in exactly 14 of the 44 cells '
       '1 <= p + q <= 8: %s' % sorted(consistent))

def check_C():
    X = np.array([[0, 1], [1, 0]]); Z = np.array([[1, 0], [0, -1]]); iY = np.array([[0, 1], [-1, 0]]); I2 = np.eye(2, dtype=int); Y = np.array([[0, -1j], [1j, 0]])
    e = [np.kron(X, I2), np.kron(Z, I2), np.kron(iY, X), np.kron(iY, Z if FAULT != 'MERMIN' else X)]
    sq = [int(round((m @ m)[0, 0])) for m in e]
    anti = all(np.array_equal(e[i] @ e[j], -e[j] @ e[i]) for i in range(4) for j in range(4) if i != j)
    ck(sq == [1, 1, -1, -1] and anti, 'e1..e4 = X x 1, Z x 1, iY x X, iY x Z are real 4 x 4 generators of Cl(2,2): squares %s, anticommuting' % sq)
    A = BR([1, 1, -1, -1])
    def mat(a):
        M = np.eye(4);
        for i in range(4):
            if a >> i & 1: M = M @ e[i]
        return M
    plus = [a for a in range(1, 16) if A.sq(a) == 1]
    paulis = {'X1': np.kron(X, I2), 'Z1': np.kron(Z, I2), '1X': np.kron(I2, X), '1Z': np.kron(I2, Z), 'XX': np.kron(X, X), 'ZZ': np.kron(Z, Z),
              'ZX': np.kron(Z, X), 'XZ': np.kron(X, Z), 'YY': np.real(np.kron(Y, Y))}
    names = {}
    for a in plus:
        M = mat(a)
        for nm, P in paulis.items():
            if np.allclose(M, P): names[a] = '+' + nm
            elif np.allclose(M, -P): names[a] = '-' + nm
    ck(len(plus) == 9 and len(names) == 9 and set(k[1:] for k in names.values()) == set(paulis),
       "the nine +1-blades of Cl(2,2) are Mermin's nine operators up to sign: %s" % {bin(a): v for a, v in names.items()})
    # the six lines: commuting triples with product +-1, as a 3x3 grid
    grid = [['X1', '1X', 'XX'], ['1Z', 'Z1', 'ZZ'], ['XZ', 'ZX', 'YY']]
    inv = {v[1:]: a for a, v in names.items()}
    if len(inv) < 9:
        ck(False, 'the grid cannot be formed: the blades are not the nine Mermin operators'); return
    lines = [[inv[x] for x in row] for row in grid] + [[inv[grid[r][c]] for r in range(3)] for c in range(3)]
    signs = []
    for L in lines:
        ok = all(A.commute(a, b) for a in L for b in L)
        x = {0: 1}
        for a in L: x = A.mul(x, {a: 1})
        signs.append(x.get(0, 0)); ok &= (set(x.keys()) == {0})
        if not ok: signs.append(None)
    prod = 1
    for s_ in signs: prod *= (s_ if s_ else 0)
    ck(None not in signs and prod == -1, 'the six lines (rows and columns of the grid) commute, multiply to +-1 on the labels, and the product of the six signs is -1: %s' % signs)

def main():
    t0 = time.time()
    check_A(); check_B(); check_C()
    print('TOTAL %.1f s; FAILS: %s' % (time.time() - t0, FAILS or 'none'))
    sys.exit(1 if FAILS else 0)

if __name__ == '__main__':
    main()
