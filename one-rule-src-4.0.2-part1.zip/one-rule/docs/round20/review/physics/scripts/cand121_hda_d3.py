# SPDX-License-Identifier: MIT
"""CAND-121 in d = 3 (the Atlas ran d = 2 only): the bracket of two Hamiltonian constraints of the ADM-type theory with the signature
parameter s, exact on polynomial jets at a point (reviewer's own route, jets.py; no Atlas code).

  H = -s q^{-1/2} (pi^{ij} pi_{ij} - c pi^2) - sqrt(q) R,   H_k = -2 q_{kj} nabla_i pi^{ij},   c = 1/(d - 1) = 1/2 in d = 3 (DeWitt),
  claim:  {H[N], H[M]} = eps H_k[ q^{kj} (N d_j M - M d_j N) ],  eps = -s   (s = -1 Lorentzian, +1 Euclidean, 0 zero signature).

Pointwise form checked exactly (Fractions) at the origin, the full functional derivatives of H[N] (the Ricci terms of delta(sqrt(q) R)/delta q
included) and of H[M] w.r.t. pi:
  B(x) := dH[N]/dq_ab . dH[M]/dpi^ab - (N <-> M)  =  d_a V^a + eps H^b (N d_b M - M d_b N),   V^a = 2 s pi^{ab} (M d_b N - N d_b M),
so that, V^a being a vector density, the integrated bracket is eps H_k[...] (a derivation: the N<->M symmetric terms cancel, the
antisymmetric part of nabla_a W_b drops against the symmetric pi^{ab}, and nabla_a pi^{ab} - (1 - 2c) nabla^b pi = nabla_a pi^{ab} at c = 1/2).
Controls (--fault, each exits 1): COEF the d = 2 coefficient c = 1 kept in d = 3 (the bracket does not close); EPS the opposite sign eps = +s;
  NODIV the divergence term dropped.  Random integer jets, 4 draws per s in {-1, 0, 1}; the identity is polynomial of low degree in the jet
  coefficients, so a false identity of this form passes 4 random draws with probability well below 1e-3 (Schwartz-Zippel, |S| = 7 per coefficient).
usage: python3 -I -B cand121_hda_d3.py [--fault COEF|EPS|NODIV]"""
import sys, os, random, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from jets import Jet, curvature_at0

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
N3, D = 3, 2
R3 = range(3)
FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond: FAILS.append(msg)

def monomials(n, D):
    out = []
    for k0 in range(D + 1):
        for k1 in range(D + 1 - k0):
            for k2 in range(D + 1 - k0 - k1):
                out.append((k0, k1, k2))
    return out
MONOS = monomials(N3, D)

def rand_jet(rng, lo=-3, hi=3, den=1, nonzero0=False):
    c = {m: Fr(rng.randint(lo, hi), den) for m in MONOS}
    if nonzero0 and c[(0, 0, 0)] == 0: c[(0, 0, 0)] = Fr(1)
    return Jet(N3, D, c)

def bracket_at0(s, c, q, pi, N, M):
    """B(0), d_a V^a (0), H^b (0), W_b(0) for the given jets"""
    gi0, Gam, Riem, Ric, Rs = curvature_at0(q)
    q0 = [[q[i][j].val() for j in R3] for i in R3]
    sq = None  # sqrt(q) at 0: q(0) = delta so sqrt(det) = 1 (the random part has no constant term); keep symbolic through sqdet = 1
    sqdet = Fr(1)
    assert all(q0[i][j] == (1 if i == j else 0) for i in R3 for j in R3)
    pi0 = [[pi[i][j].val() for j in R3] for i in R3]
    G0 = [[[Gam[r][m][v].val() for v in R3] for m in R3] for r in R3]
    def hess(f):   # nabla_a nabla_b f at 0 (coordinate indices), then raise with q0 = delta
        return [[f.deriv_at0((a, b)) - sum(G0[m][a][b] * f.deriv_at0((m,)) for m in R3) for b in R3] for a in R3]
    def grad(f): return [f.deriv_at0((a,)) for a in R3]
    # raised indices: at the origin q = delta, so up = down
    Ricup = [[sum(gi0[a][k] * gi0[b][l] * Ric[k][l] for k in R3 for l in R3) for b in R3] for a in R3]
    def dHdq(Nf):   # delta H[N] / delta q_ab at 0, potential part + kinetic part
        HN = hess(Nf); lap = sum(gi0[a][b] * HN[a][b] for a in R3 for b in R3); N0 = Nf.val()
        pot = [[-sqdet * (N0 * (Fr(1, 2) * Rs * gi0[a][b] - Ricup[a][b]) + HN[a][b] - gi0[a][b] * lap) for b in R3] for a in R3]
        # kinetic: -s q^{-1/2} (F - c pi^2), F = pi^{kl} pi^{mn} q_km q_ln ; dF/dq_ab = 2 (pi q pi)^{ab}, d(pi^2)/dq_ab = 2 pi pi^{ab}, d q^{-1/2}/dq_ab = -1/2 q^{-1/2} q^{ab}
        F = sum(pi0[k][l] * pi0[m][n] * q0[k][m] * q0[l][n] for k in R3 for l in R3 for m in R3 for n in R3)
        tr = sum(pi0[k][l] * q0[k][l] for k in R3 for l in R3)
        pqp = [[sum(pi0[a][l] * q0[l][n] * pi0[n][b] for l in R3 for n in R3) for b in R3] for a in R3]
        kin = [[N0 * (-s) * (-Fr(1, 2) * gi0[a][b] * (F - c * tr * tr) + (2 * pqp[a][b] - 2 * c * tr * pi0[a][b])) for b in R3] for a in R3]
        return [[pot[a][b] + kin[a][b] for b in R3] for a in R3]
    def dHdpi(Mf):  # delta H[M] / delta pi^ab at 0
        M0 = Mf.val(); tr = sum(pi0[k][l] * q0[k][l] for k in R3 for l in R3)
        pidn = [[sum(q0[a][k] * q0[b][l] * pi0[k][l] for k in R3 for l in R3) for b in R3] for a in R3]
        return [[-s * M0 * (2 * pidn[a][b] - 2 * c * tr * q0[a][b]) for b in R3] for a in R3]
    AN, AM = dHdq(N), dHdq(M); PN, PM = dHdpi(N), dHdpi(M)
    B0 = sum(AN[a][b] * PM[a][b] - AM[a][b] * PN[a][b] for a in R3 for b in R3)
    # V^a = 2 s pi^{ab} W_b as jets (order 1 exact), W_b = M d_b N - N d_b M
    W = [M * N.d(b) - N * M.d(b) for b in R3]
    V = [sum((pi[a][b] * W[b] for b in R3), Jet(N3, D)) * (2 * s) for a in R3]
    divV = sum(V[a].deriv_at0((a,)) for a in R3)
    # H^b = -2 nabla_a pi^{ab} (density weight 1): nabla_a pi^{ab} = d_a pi^{ab} + Gamma^b_{ak} pi^{ak}
    Hup = [-2 * (sum(pi[a][b].deriv_at0((a,)) for a in R3) + sum(G0[b][a][k] * pi0[a][k] for a in R3 for k in R3)) for b in R3]
    W0 = [w.val() for w in W]
    return B0, divV, Hup, W0

def main():
    t0 = time.time()
    c = Fr(1, 2) if FAULT != 'COEF' else Fr(1)
    for s in (-1, 1, 0):
        eps = -s if FAULT != 'EPS' else s
        rng = random.Random(1000 + s)
        allok = True
        for draw in range(4):
            q = [[None] * 3 for _ in R3]
            for i in R3:
                for j in range(i, 3):
                    r = rand_jet(rng, den=7); r = r - r.val()         # no constant term: q(0) = delta
                    q[i][j] = q[j][i] = r + (1 if i == j else 0)
            pi = [[None] * 3 for _ in R3]
            for i in R3:
                for j in range(i, 3):
                    pi[i][j] = pi[j][i] = rand_jet(rng)
            Nf = rand_jet(rng, nonzero0=True); Mf = rand_jet(rng, nonzero0=True)
            B0, divV, Hup, W0 = bracket_at0(s, c, q, pi, Nf, Mf)
            if FAULT == 'NODIV': divV = Fr(0)
            # eps H_k[q^{kj}(N d_j M - M d_j N)] integrand at 0 = eps H^b (N d_b M - M d_b N) = -eps H^b W_b
            rhs = divV + sum(-eps * Hup[b] * W0[b] for b in R3)
            ok = (B0 == rhs)
            allok &= ok
            print('     s = %2d draw %d: B(0) = %s, d_a V^a = %s, eps H.W = %s  -> %s' % (s, draw, B0, divV, rhs - divV, 'ok' if ok else 'FAIL'))
        ck(allok, 's = %d: {H[N],H[M]}(x) = d_a V^a + eps H_k[q^{kj}(N d_j M - M d_j N)](x) exactly at the origin with eps = %d (c = %s), 4 random jets'
           % (s, eps, c))
    print('TOTAL %.1f s; FAILS: %s' % (time.time() - t0, FAILS or 'none'))
    sys.exit(1 if FAILS else 0)

if __name__ == '__main__':
    main()
