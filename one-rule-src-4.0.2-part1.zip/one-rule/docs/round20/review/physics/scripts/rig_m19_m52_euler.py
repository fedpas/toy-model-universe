# SPDX-License-Identifier: MIT
"""RIG-M19 ("that sign is not run separately") and RIG-M52 ("the size [0.6, 2, 1] is not run here"), exact (Fractions), reviewer's own
vector form of the free rigid body: body angular velocity w, body-frame velocity of the centre v, inertia I_C = diag(i1, i2, i3), mass m,
  Euler:  I_C w' = sigma (I_C w) x w ,   v' = -w x v   (sigma = +1 the right sign; sigma = -1 the reversed Euler term).
(A) RIG-M19: the kinetic energy T = (1/2)(w.I_C w + m v.v) has dT/dt = 0 for BOTH signs sigma = +-1 (w.((I_C w) x w) = 0 for either sign,
    v.(w x v) = 0), on 6 random rational states; the world angular momentum L = R I_C w (R' = R [w]_x) has dL/dt = R (w x I_C w + I_C w')
    = 0 only for sigma = +1, and = 2 R (w x I_C w) != 0 for sigma = -1: the momentum fixes the sign, the energy cannot.
(B) RIG-M52: for the box of the example, sizes (s0, s1, s2) = (3/5, 2, 1), the two inertia maps of the Atlas's rows (the printed map:
    moments ((s0^2+s1^2)/12, (s0^2+s2^2)/12, (s1^2+s2^2)/12) on (e23, e13, e12); the paper's box: ((s1^2+s2^2)/12, (s0^2+s2^2)/12,
    (s0^2+s1^2)/12)) give different Euler flows: w' differs at a generic state (exact), equal only when s0 = s2 (checked on (1, 2, 1));
    a spin about a principal axis is stationary in both.
Controls (--fault, each exits 1): ENERGY claims dT/dt != 0 for sigma = -1; MOMENTUM claims dL/dt = 0 for sigma = -1; SAME claims the two maps
    agree at (3/5, 2, 1).
usage: python3 -I -B rig_m19_m52_euler.py [--fault ENERGY|MOMENTUM|SAME]"""
import sys, random
from fractions import Fraction as Fr

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond: FAILS.append(msg)

def cross(a, b): return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def Iw(I, w): return [I[k] * w[k] for k in range(3)]
def wdot(I, w, sigma):
    c = cross(Iw(I, w), w); return [sigma * c[k] / I[k] for k in range(3)]

def check_A():
    rng = random.Random(7)
    okE = okL = True
    for _ in range(6):
        I = [Fr(rng.randint(1, 9), rng.randint(1, 4)) for _ in range(3)]; m = Fr(rng.randint(1, 5))
        w = [Fr(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(3)]; v = [Fr(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(3)]
        for sigma in (1, -1):
            wd = wdot(I, w, sigma); vd = [-x for x in cross(w, v)]
            dT = dot(Iw(I, w), wd) + m * dot(v, vd)
            # dL/dt in the body frame (R^T dL/dt): w x I w + I w'
            dL = [cross(w, Iw(I, w))[k] + I[k] * wd[k] for k in range(3)]
            Lzero = all(x == 0 for x in dL)
            if sigma == 1: okE &= (dT == 0); okL &= Lzero
            else:
                okE &= (dT == 0) if FAULT != 'ENERGY' else (dT != 0)
                okL &= (not Lzero) if FAULT != 'MOMENTUM' else Lzero
    ck(okE, 'RIG-M19: dT/dt = 0 exactly for the right sign AND for the reversed Euler term (6 random rational states): the energy cannot fix the sign')
    ck(okL, 'RIG-M19: dL_world/dt = 0 exactly for the right sign and != 0 for the reversed Euler term on every state: the momentum fixes it')

def maps(s):
    printed = [(s[0] ** 2 + s[1] ** 2) / 12, (s[0] ** 2 + s[2] ** 2) / 12, (s[1] ** 2 + s[2] ** 2) / 12]   # on (e23, e13, e12) = axes (x, y, z)
    paper = [(s[1] ** 2 + s[2] ** 2) / 12, (s[0] ** 2 + s[2] ** 2) / 12, (s[0] ** 2 + s[1] ** 2) / 12]
    return printed, paper

def check_B():
    s = [Fr(3, 5), Fr(2), Fr(1)]
    P, Q = maps(s)
    w = [Fr(1, 3), Fr(-2, 5), Fr(7, 4)]
    d1, d2 = wdot(P, w, 1), wdot(Q, w, 1)
    differ = d1 != d2
    ck(differ if FAULT != 'SAME' else not differ,
       'RIG-M52: box (3/5, 2, 1): printed map moments %s vs paper %s; Euler w\' at w = %s: %s vs %s (differ)' % (P, Q, w, d1, d2))
    s2 = [Fr(1), Fr(2), Fr(1)]; P2, Q2 = maps(s2)
    ck(P2 == Q2 and wdot(P2, w, 1) == wdot(Q2, w, 1), 'RIG-M52: with s0 = s2 ((1, 2, 1)) the two maps and the flows coincide')
    stat = all(wdot(P, [Fr(k == a) * 3 for k in range(3)], 1) == [0, 0, 0] and wdot(Q, [Fr(k == a) * 3 for k in range(3)], 1) == [0, 0, 0] for a in range(3))
    ck(stat, 'RIG-M52: a spin about a principal axis is stationary under both maps')

if __name__ == '__main__':
    check_A(); check_B()
    print('FAILS: %s' % (FAILS or 'none')); sys.exit(1 if FAILS else 0)
