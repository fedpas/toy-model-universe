# SPDX-License-Identifier: MIT
"""CPL-006b (open: "a neutral form of the field for n = 1 and 2 is not built"): built, on the reviewer's own bit rule.
In Cl(1,1) (gamma_0^2 = +1, gamma_1^2 = -1) the even field psi = a + b gamma_0 gamma_1 has two REAL components and no complex structure
(Cl^0(1,1) = R + R, CPL-006).  The real first-order equation
      nabla psi = m psi gamma_1,        nabla = gamma^0 d_t + gamma^1 d_x  (gamma^1 = -gamma_1),
is the 1+1 Majorana equation (a real two-component spinor, no charge, no J): its real plane waves a, b in span{cos(kx - Et), sin(kx - Et)}
form a 2-dimensional solution space exactly on E^2 = k^2 + m^2 and none off it (exact 4 x 4 linear systems over Q); with gamma_0 in the
place of gamma_1 (nabla psi = m psi gamma_0) the shell is the tachyonic E^2 = k^2 - m^2; the charged form nabla psi J = m psi gamma_0 of
step 6 does not exist (no bivector of square -1).  For n = 1 (Cl(1,0)) the full algebra psi = a + b gamma_0 gives only d_t a = m a, d_t b = m b,
real exponentials: no oscillating neutral field with one generator, as the row says is not built (it cannot: no element squares to -1).
Controls (--fault, each exits 1): SHELL claims solutions off the shell at (E, k) = (6, 4); TACH claims the gamma_0 form has the massive shell.
usage: python3 -I -B cpl006b_majorana_cl11.py [--fault SHELL|TACH]"""
import sys
from fractions import Fraction as Fr

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond: FAILS.append(msg)

def popcount(x): return bin(x).count('1')
def npairs(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << i) - 1))
        i += 1
    return c
class BR:
    def __init__(self, eps): self.eps = tuple(eps); self.n = len(eps)
    def s(self, a, b):
        v = -1 if npairs(a, b) & 1 else 1
        m = a & b; i = 0
        while m:
            if m & 1: v *= self.eps[i]
            m >>= 1; i += 1
        return v
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                out[a ^ b] = out.get(a ^ b, 0) + self.s(a, b) * ca * cb
        return {k: v for k, v in out.items() if v != 0}

def rank(M):
    M = [list(map(Fr, r)) for r in M]; r = 0
    for c in range(len(M[0])):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        r += 1
    return r

def kernel_dim(E, k, m, mass_vector):
    """real trig plane waves psi = (ac cos + as sin) + (bc cos + bs sin) e01; nabla psi - m psi e_mass = 0 as a 4x4 system"""
    A = BR([1, -1]); g0 = {1: 1}; g1 = {2: 1}; g1up = {2: -1}
    # unknowns (ac, as, bc, bs); fields as dict label -> (cos coeff, sin coeff)
    rows = {}   # (label, trig) -> row vector
    def add(label, trig, col, val):
        rows.setdefault((label, trig), [Fr(0)] * 4); rows[(label, trig)][col] += val
    basis = [(0, 'c'), (0, 's'), (3, 'c'), (3, 's')]
    for col, (lab, trig) in enumerate(basis):
        # d_t: cos -> E sin, sin -> -E cos ;  d_x: cos -> -k sin, sin -> k cos
        dt = {('s', E) if trig == 'c' else ('c', -E)}; dx = {('s', -k) if trig == 'c' else ('c', k)}
        for (tr, coef) in dt:
            for l2, v in A.mul(g0, {lab: 1}).items(): add(l2, tr, col, coef * v)
        for (tr, coef) in dx:
            for l2, v in A.mul(g1up, {lab: 1}).items(): add(l2, tr, col, coef * v)
        for l2, v in A.mul({lab: 1}, g1 if mass_vector == 1 else g0).items(): add(l2, trig, col, -m * v)
    M = list(rows.values())
    return 4 - rank(M)

def main():
    m = 3
    on = [(5, 4), (5, -4), (-5, 4), (3, 0), (Fr(13, 4), Fr(5, 4))]
    off = [(6, 4), (5, 3), (4, 5)]
    d_on = [kernel_dim(E, k, m, 1) for E, k in on]; d_off = [kernel_dim(E, k, m, 1) for E, k in off]
    ck(all(x == 2 for x in d_on) and all(x == 0 for x in d_off),
       'nabla psi = m psi gamma_1 in Cl(1,1): real plane waves, kernel dimension 2 on E^2 = k^2 + m^2 (%s) and 0 off it (%s), m = 3' % (d_on, d_off))
    if FAULT == 'SHELL': ck(kernel_dim(6, 4, m, 1) == 2, 'control SHELL')
    tach_on = [kernel_dim(4, 5, m, 0), kernel_dim(0, 3, m, 0)]; tach_off = [kernel_dim(5, 4, m, 0), kernel_dim(3, 0, m, 0)]
    cond = all(x == 2 for x in tach_on) and all(x == 0 for x in tach_off)
    ck(cond if FAULT != 'TACH' else not cond, 'nabla psi = m psi gamma_0 instead: shell E^2 = k^2 - m^2 (tachyonic): kernels %s on it, %s on the massive shell' % (tach_on, tach_off))
    # no bivector of square -1 in Cl(1,1): the charged form does not exist
    A = BR([1, -1]); sq = A.mul({3: 1}, {3: 1})
    ck(sq == {0: 1}, 'Cl(1,1): the only bivector e_01 squares to %s: no J, no charged form (CPL-006)' % sq)
    # n = 1: Cl(1,0): psi = a + b gamma_0, nabla psi = gamma_0 (a\' + b\' gamma_0) = a\' gamma_0 + b\'; = m psi gamma_0 = m a gamma_0 + m b: a\' = m a, b\' = m b
    ck(True, 'Cl(1,0): nabla psi = m psi gamma_0 reads a\' = m a, b\' = m b (real exponentials, by hand): no oscillating neutral field at n = 1, as no element squares to -1')
    print('FAILS: %s' % (FAILS or 'none')); sys.exit(1 if FAILS else 0)

if __name__ == '__main__':
    main()
