# Review — MATHEMATICS (pages atlas, rule, cells, clock, shapes, steps/groups, steps/category, steps/mirrors, steps/comm, logbook, lenses, steps, steps/baez; theorems T1–T20; the Weil line LAB-026…039)

Referee: algebra / quadratic forms / K-theory / lattices / codes / Weil representation. Date: 21 Oct 2026. Inputs: `review_in/digest_math.md` (786 distinct rows, 103 chains), `review_in/theorems_T1_T20.md`, `review_in/chain_links.csv`, `map_out/map_full.json`, `map_out/map_stats.md`, the staging folder `STAGED.md`. Conventions used throughout: Cl(p,q) has p generators of square +1; c = p − q mod 8; Cl(1,3) is the spacetime cell with γ₀² = +1.

## A. Summary

1. Chains: 103 reviewed. 84 OK, 19 FIX (a relation word, a status or a scope to correct), 0 BREAK. No chain contains a link that does not hold.
2. Rows: 786 reviewed (633 proved-by-atlas, 63 open, 65 ours, 32 standard, 14 input, 19 meta). Every open / ours / standard row has an explicit verdict in C.2.
3. Row issues found: 0 mathematical errors in a statement that is claimed as computed; 6 status issues (rows labelled `standard` or `ours` that are computations or theorems the Atlas itself proves, and one `proved-by-atlas` row whose mathematical content is literature); 4 scope issues (underclaims: finite checks of statements that are theorems for all n with a citation); 5 naming/terminology issues; 2 overclaims of wording (not of mathematics).
4. All twenty theorems T1–T20 are correct as stated; the proofs or reductions given are adequate at the stated scope. One wording nit in T8 (3) ("tilted of type D₄, 11 indecomposables" is consistent: a tilted algebra of Dynkin type need not be separating, so 11 < 12 is fine) and one in T16 (the trivial p = q = 0 exception, already declared).
5. The Weil line LAB-026 … LAB-039 is mathematically sound; its finite claims were recomputed exactly here (W1–W5 below), including the crux of LAB-037/038 (the scalar i as a single commutator of two-qubit lifts).
6. Computations done: 5 scripts, 7,839 exact checks, 14 `--fault` controls (every one exits 1). They settle: LNC-059 ("the idempotents follow; not computed": now computed on all 44 cells n ≤ 8); the staged LNS-038 list of 30/14 cells with/without a Mermin grid (holds); CAND-144 (holds); LAB-028/032/037/038 finite content (holds); T8's Euler/Tits/Coxeter data, LNC-045's counts, T9(f), T10(1), LAB-035's code counts (hold); GEN-011's "agree iff one clock is 0 or 4" (holds, 235/260); T4(iv), the ABS table of GEN-022/ATY-001 from the type table, INP-019 and CAND-058 (hold).
7. Structural cross-check (F): the mod-8 table, the Brown/Arf–Brown–Kervaire reading of the clock, the Gauss sum, KO^{p−q} from graded modules, Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ), Weil's index, Fidkowski–Kitaev ℤ₈ are textbook and correctly stated; "E_n/2E_n carries the label form", "Golay = Lagrangian of Cl(24,0)" and the tenfold-way match are correct non-standard phrasings; nothing in item 4 of the common brief is wrong, but two phrasings overreach (the clock of a degenerate cell is "forced" only relative to a definitional choice; the "finite Siegel–Weil formula" is a transitive-orbit average).
8. The hierarchy mod 2 → mod 4 → mod 8 is correct as the Atlas states it, with two gaps it should name: the two 𝔽₂-bilinear forms it uses (dot product vs. commutation form) and the Arf invariant at the mod-2 level (F.1).
9. M₁₆(ℝ) is a legitimate organising object for exactly the graded-Morita-invariant data; the precise list of periodic and non-periodic data is in F.2.
10. Dangerous spots (G): status inflation ("proved-by-atlas" for small-n instances of textbook theorems), two unread citations under the category lens (Wang, Ladkani), the "forced clock" wording, the Siegel–Weil naming, the Weil-index "same number" reading, and the Pin⁺ side left open although it is textbook.

## B. Chain verdicts

Verdict key: OK = the chain is one argument and the link words and weakest status are right; FIX = a link word, status or scope to correct (the mathematics holds); BREAK = a link does not hold (none).

| chain | verdict | note |
|---|---|---|
| rule.ideas.genesis | FIX | GEN-002 "derives" from GEN-001: Cl(0,0,1) is not derived from Cl(0,0); use `order`. Rest OK (GEN-005 from GEN-003 is a genuine derivation; GEN-008's two pinor classes and GEN-009's row 8 are correct). |
| rule.ideas.blocks | FIX | GEN-031 "equiv" GEN-017: ABS's two-step maps are a finer statement whose fourfold composite is the eight-block map; `derives`. GEN-017 equiv GEN-013 acceptable (scope extension). |
| rule.ideas.car | OK | GEN-003 → GEN-015 → GEN-020: the CAR on labels and its Bratteli diagram; standard, correctly scoped. |
| rule.ideas.null | FIX | GEN-028 "equiv" GEN-023 (idempotent lifting vs. the stages of chains): not equivalent; `order`. |
| rule.ideas.limit | FIX | GEN-030 "equiv" GEN-026: the algebraic direct limit and its dimension group are different statements; `derives`. Weakest `ours` (GEN-016) is right. |
| rule.ideas.routes | OK | matrix route confirms the label route. |
| cells.cards.empty / one-plus / phase / quaternions / split-three / even-spacetime / conformal / pinors / chiral / scalar / two-six / types | OK | card chains: the algebra facts are the mod-8 table; the `open` second halves are physics names (no mathematical content). |
| cells.cards.pauli | OK | CAND-122's spacetime split is textbook (Hestenes). |
| cells.cards.spacetime | OK | cycle ATL-010 ↔ ATL-012 is a convention pair; weakest `ours` right. |
| cells.cards.split-four | FIX | ATL-011 "uses-input" CAND-078: CAND-078 is a computation, not an input; `derives`. |
| cells.cards.six | OK | so(2,4) ≅ so(4,2) by B ↦ −B is right (Killing form sign table). |
| cells.cards.maxwell | OK | — |
| cells.cards.strain | FIX | ATL-018 is `standard` but is proved in T17's statusNote (S = 0 iff h ∈ O(η); tr(η⁻¹S) = 2 tr ε): status `proved-by-atlas`. |
| cells.cards.row-eight | OK | ATL-023 (three clock-0 cells of row 8 are one graded algebra End(ℝ^{8|8})) is right. |
| cells.cards.peirce | OK | — |
| cells.cards.null | FIX | same as rule.ideas.null (GEN-028 "equiv" GEN-023). |
| cells.cards.limit | FIX | same as rule.ideas.limit. |
| cells.cards.routes | OK | — |
| clock.clock.gauss | OK | LAB-017 ≡ RSN-029 right; CAND-057/LAB-022/LAB-023 right; ATY-033 is the standard quadratic-Gauss-sum self-duality (see C). |
| clock.clock.brown | FIX | LAB-018 is `proved-by-atlas` but half its content (w is a Pin⁻ structure, Ω₂^{Pin⁻} ≅ ℤ₈, FK ℤ₈) is literature: split or mark the bordism identification `standard`. LAB-021 "instance" of LAB-018 is right. |
| clock.clock.k-theory | FIX | GEN-022 "equiv" GEN-018 (null cells vs. n + 8 of non-degenerate cells): `derives`. ATY-001 → ATY-026 right. |
| clock.clock-trinity.trinity | OK | the three instances are instances via bivector squares (LNB-023c: (e_ke₄)² = −ε). |
| shapes.sh-orth.dual | OK | — |
| shapes.sh-orth.sizes | OK | SHP-005's 16 = 1 + 10 + 5̄ with Y = a/2 − b/3 is textbook (Baez–Huerta). |
| shapes.sh-gosset.lattices | FIX | CAND-101 "derives from GOS-006" is reversed: the lemma precedes (GOS-006's own depends say derives→CAND-101). |
| shapes.sh-gosset.del-pezzo | FIX | ATY-019 is kind `reading` with status `proved-by-atlas`; by the Atlas's own vocabulary it is `ours` (facts computed, reading not). ATY-016 "instance" of GOS-007: `order`. |
| shapes.sh-gosset.views | FIX | GOS-004 (`standard`, dead-end) is narration: `meta` or `ours`, not literature. |
| shapes.sh-gosset.triality | OK | — |
| steps-groups.ln-groups.label-form | OK | — |
| steps-groups.ln-groups.mckay | FIX | ATY-032 "derives from CAND-140": McKay for 2T, 2D is not derived from the 2I computation; `order`. |
| steps-groups.ln-groups.brown | OK | — |
| steps-category.cat-first.scope | OK | meta. |
| steps-category.cat-zero.three-zeros | OK | LNC-012 `standard` is a definition; harmless. |
| steps-category.cat-label0.card | OK | — |
| steps-category.cat-label0.unpaired | OK | — |
| steps-category.cat-twozeros.partner | FIX | LNC-135 "equiv" LNC-026 (an unpaired null generates the radical vs. the mother-algebra embedding): `order`. |
| steps-category.cat-frobenius.pairing | OK | T3 verified by hand (C). |
| steps-category.cat-frobenius.hodge | OK | — |
| steps-category.cat-moves.maps | OK | — |
| steps-category.cat-moves.functor | OK | — |
| steps-category.cat-top.series | OK | LNC-046 (meta) "derives" is harmless. |
| steps-category.cat-top.mod-two | OK | — |
| steps-category.cat-cube.signs | OK | — |
| steps-category.cat-bottom.forms | FIX | LNC-054 (`standard`, Wang/Ladkani) "derives" from LNC-052 (an Euler-form computation): a citation does not derive from it; `order`. The two citations are unverified here (E). |
| steps-category.cat-arrows.monoid | OK | — |
| steps-category.cat-arrows.nerve | OK | — |
| steps-category.cat-arrows.weights | OK | — |
| steps-category.cat-arrows.comma | OK | — |
| steps-category.cat-more.clock | OK | — |
| steps-category.cat-more.sign | OK | — |
| steps-category.cat-more.commuting | OK | LNC-059's "not computed" clause is now computed (D). |
| steps-category.cat-more.ladder | OK | — |
| steps-category.cat-refine.two-meanings | OK | — |
| steps-category.cat-honest.carroll | OK | — |
| steps-mirrors.eq-mirrors.corners | OK | — |
| steps-mirrors.eq-mirrors.demicube | OK | — |
| steps-mirrors.eq-mirrors.pin | OK | — |
| steps-comm.eq-comm.graph | OK | — |
| steps-baez.bz-top.hero | OK | — |
| steps-baez.bz-top.compared | OK | — |
| steps-baez.bz-top.peirce | OK | — |
| steps-baez.bz-top.grading | OK | — |
| steps-baez.bz-top.shadows | OK | — |
| steps-baez.bz-top.signatures | OK | — |
| steps-baez.bz-papers.seven | OK | meta. |
| steps-baez.bz-papers.citations | OK | meta + two computations. |
| steps-baez.bz-papers.legend | OK | meta. |
| steps-baez.bz-papers.albert | OK | — |
| steps-baez.bz-papers.hydrogen | OK | — |
| steps-baez.bz-papers.fock | OK | — |
| steps-baez.bz-papers.ring | OK | — |
| steps-baez.bz-papers.ten | OK | — |
| steps-baez.bz-generation.weights | OK | — |
| steps-baez.bz-generation.no-mass | OK | — |
| steps-baez.bz-generation.fock | OK | — |
| steps-baez.bz-ladder.rungs | OK | — |
| steps-baez.bz-ladder.pieces | OK | — |
| steps-baez.bz-which.stabilisers | OK | — |
| steps-baez.bz-which.spin9 | OK | — |
| steps-baez.bz-ten.spin-factor | OK | — |
| steps-baez.bz-ten.two-tens | OK | LNB-022e "instance" of CAND-024 is right. |
| steps-baez.bz-kepler.orbits | OK | — |
| steps-baez.bz-kepler.fock | FIX | LNB-055c "equiv from LNB-023": a reading is not equivalent to the computation; `derives`. |
| steps-baez.bz-kepler.shells | OK | — |
| steps-baez.bz-periodic.madelung | FIX | LNB-024 "derives from LNB-175" (a reading): reversed; the computation does not derive from the reading. |
| steps-baez.bz-ring.rings | OK | — |
| steps-baez.bz-ring.paper | FIX | LNB-056c "equiv from LNB-017": the tie to the triangulation note is derived, not equivalent to the E7 paper's lemma; `derives`. |
| steps-baez.bz-more.octonions | OK | — |
| steps-baez.bz-more.zorn | OK | — |
| steps-baez.bz-more.frobenius | OK | — |
| steps-baez.bz-numbers.numbers | OK | — |
| steps-baez.bz-gaps.limits | OK | — |

## C. Row issues

### C.1 Rows with an issue

| row | severity | what is wrong | the correct statement, with reference |
|---|---|---|---|
| ATL-018 | status | `standard` for an easy computation that T17's own statusNote proves (S(h) = hᵀηh − η vanishes iff h ∈ O(η); first-order trace). | Status `proved-by-atlas`, evidence check_T17 (it is already listed). |
| GOS-004 | status | `standard` (kind dead-end) for a narrative remark ("F is a bivector of four generators and E8 needs sixteen"). | `meta` or `ours`; no literature is cited or needed. |
| ATY-019 | status | kind `reading`, status `proved-by-atlas`: the reading of Atiyah–Manton–Schroers (baryon number = signature) is an interpretation; the lattice numbers (h·h = 1, (2h)² = 4, genus 0 by adjunction) are computed. | Status `ours` by the Atlas's own vocabulary; keep the computed facts. |
| LAB-018 | status / scope | The row is `proved-by-atlas`, but "w is a Pin⁻ structure on #ⁿℝP²", "Ω₂^{Pin⁻} ≅ ℤ₈" and "the same ℤ₈ is Fidkowski–Kitaev's" are read, not computed. What is computed is the Brown invariant of w and the Gauss sums. | Split: computed part (Brown invariant of ⟨1⟩^p ⊕ ⟨−1⟩^q = p − q mod 8, Gauss sums) stays; the bordism identification is `standard`: Kirby–Taylor, *Pin structures on low-dimensional manifolds* (1990), Thm 3.2 (Pin⁻ structures ↔ ℤ₄-enhancements) and the Brown-invariant isomorphism Ω₂^{Pin⁻} → ℤ₈ in §3; Brown, Ann. Math. 95 (1972). |
| GOS-511b | status | `ours` for Witt's classification of even unimodular lattices of rank 16 (E₈ ⊕ E₈ and D₁₆⁺). | `standard`: Witt 1941; Conway–Sloane, SPLAG, Ch. 16 (and Ch. 4 §8.3 for D₁₆⁺). Nothing is "ours" in it. |
| LAB-505b | status | `ours` ("recalled, not computed") for a standard fact. | `standard`: a connected non-compact simple Lie group (Spin⁺(1,3) ≅ SL(2,ℂ)) has no non-trivial continuous homomorphism to a compact Lie group (a non-zero homomorphism from the simple Lie algebra sl(2,ℂ)_ℝ would be injective, but its Killing form is indefinite while that of a compact Lie algebra is negative semidefinite; Knapp, *Lie Groups Beyond an Introduction*, the chapter on compact Lie groups). |
| LAB-035 | scope (underclaim) | "a self-dual code of labels all of square +1 exists only when p ≡ q mod 8, and up to ten generators it exists exactly then, Π_{i=0}^{n/2−2}(2^i + 1) of them in each length." Both halves are theorems for every even n. | With w(1…1) = 0 (true iff ω² = +1, which holds for p ≡ q mod 8) the ℤ₄-form descends to an 𝔽₂-quadratic form q̄ on 1^⊥/⟨1⟩ (dimension n − 2) with Arf(q̄) = β(w)/4 = (p − q)/4 mod 2; the codes are the maximal totally singular subspaces of q̄, which exist iff q̄ is of plus type and then number Π_{i=0}^{n/2−2}(2^i + 1) (Taylor, *The Geometry of the Classical Groups*, the chapter on orthogonal groups: count of maximal totally singular subspaces of O⁺(2m,2); for q = 0 this is the count of Type II codes, MacWilliams–Sloane Ch. 19). Verified here for n ≤ 8 (`lattice_euler_checks.py`, L5). |
| LAB-019 | naming | "(Wood 1993, §5: ℤ₄ forms classified by the Brown invariant)" is too broad: non-singular ℤ₄-forms are classified by rank, Brown invariant *and* whether the bilinear form is alternating (⟨1⟩⊕⟨−1⟩ and the hyperbolic plane H both have β = 0 in rank 2 and are not isometric). | The Atlas's statement is right because π forces the non-alternating (diagonal) type: state "among forms whose bilinear form is the dot product (non-alternating), rank and Brown invariant classify" (Wood, Trans. AMS 336 (1993); Kirby–Taylor §3). |
| LAB-017 / ATY-033 | naming | The row uses two different polar forms without saying so: w = π + 2Q is a quadratic refinement of the dot product (w(a+b) = w(a)+w(b)+2a·b), while Q = [e_a² = −1] is an 𝔽₂-quadratic form whose polar form is the commutation form β(a,b) = |a||b| + a·b (= π(a)π(b) + a·b), not the dot product. | State both. This is exactly why "Q alone fixes only c ↔ 2 − c" (LAB-019): Q with β sees the ungraded algebra (commutation), w with the dot product sees the ℤ₂-grading (Koszul sign). |
| CAND-004 / T4(ii) | naming | "(type of A, type of its even part) read as the graded Morita class … (the definition of 'graded Morita class')". The pair is a complete invariant of the Brauer–Wall class for Clifford algebras, not its definition. | Definition: Wall 1964 (graded central simple algebras modulo graded Morita equivalence); Lam, *Introduction to Quadratic Forms over Fields*, the chapter on Clifford algebras (the graded Brauer group); Deligne, *Notes on spinors*, the section on the super Brauer group. Say "a complete invariant". |
| LNS-038 (staged edit) | scope | The staged text replaces "the same square sits in every Cl(p,q) with p ≥ 2 and q ≥ 2 (an argument from the sign rule, not a separate check)" by a check. The argument was already a proof: the subalgebra generated by two generators of square +1 and two of square −1 is Cl(2,2) (LNC-038's ι_T is an injective homomorphism, T1). | Keep the proof and add the check; do not downgrade a valid two-line argument to "not a separate check". The rest of the staged edit (30/14 cells) holds (D). |
| INP-019 | scope (nit) | "isomorphic exactly when n ≡ 0 mod 4 and the cell is indefinite": at n = 0 both involutions are the identity. | Add "for n ≥ 1". The statement is a theorem for all n: fixed-space dimensions differ unless n ≡ 0 mod 4, the trace forms ⟨x x̃⟩₀, ⟨x x̄⟩₀ have different signatures for definite cells, and for indefinite n ≡ 0 mod 4 the two anti-involutions have the same type and signature, hence are conjugate (Skolem–Noether; for q odd explicitly by e_i ↦ e_i I). Verified n ≤ 10 (`type_table_consequences.py`, C4). |
| LNC-076b | naming | "the clock table at c = 0, …, 7, entry for entry" — the match is of commutants by *position* s; the symmetry cells built (Cl(1,1), Cl(2,1), Cl(1,1), Cl(1,2), Cl(0,2), Cl(0,3), Cl(0,2), Cl(1,2)) have clocks 0,1,0,7,6,5,6,7, i.e. c ∈ {s, 2 − s}. | Correct, and LNC-076c says so; the sentence in LNC-076b should say "the commutant list of the clock table, position by position" (the ungraded symmetry algebra sees s only up to s ↔ 2 − s, Kitaev arXiv:0901.2686 §3). |
| LNC-059 | scope | "the idempotents follow; not computed". | Now computed (D): proposed text there. |
| T8 (3) / LNC-052 | scope (wording) | "n = 2: tilted of type D₄, 11 indecomposables, recalled" is consistent (verified by hand: the 11 indecomposables of the commutative square are the thin ones S₁…S₄, P₂, P₃, I₂, I₃, (1,1,1,0), (0,1,1,1), (1,1,1,1); a tilted algebra of Dynkin type has |Φ⁺| indecomposables only for a separating tilting module). | No change; a reader may expect 12 = |Φ⁺(D₄)|; add "(not separating)" if the sentence is kept. |
| LAB-036 / LAB-039 | overclaim (wording) | "A finite Siegel–Weil formula": what is computed is the average over the (one-class) genus of 1_C, which by Witt's theorem for ℤ₄-forms (Wood 1993) is an average over a transitive orbit, equal to the normalised fixed line of the Weil operators. | Keep the computation; call it "a finite Siegel–Weil-type identity (one class, transitive orbit)"; the Eisenstein-series side is a reading. |
| LNC-006 / LNC-018 / LNC-055 / LNC-107 | overclaim (wording) | "the clock of Cl(p,q,r) is forced, not a convention: the value 2 on a radical class would make the sum 0". Among the 2^r extensions of w to the radical with values in {0,2}, only the one with value 0 has a non-zero Gauss sum (CAND-091, correct). But the Brown invariant of a degenerate form is *defined* only when w vanishes on the radical (Kirby–Taylor §3), so "forced" is relative to that definitional choice. | Say: "with the standard definition (w = 0 on the radical) the Brown invariant of Cl(p,q,r) is that of Cl(p,q); any other extension has Gauss sum 0 (CAND-091)". |
| ATL-022c | status (nit) | `input` for "the 8-cube has 1120 four-faces, recalled at n = 8" — a one-line count, not an imported number. | Compute: 2^{n−k}C(n,k) = 16·70. |

### C.2 Verdicts on every `open`, `ours` and `standard` row (grouped; "OK" = status right and content true as far as it is mathematical)

**rule.** PAG-032 (open; Pin± vs T² = ±1, Pin⁺ bordism): the open part has a textbook answer, see F.1 and E. CPL-011b (ours; Kaluza–Klein signs): physics, not assessed here. GEN-006b, PAG-003 (ours; names): OK. GEN-016 (ours; "the finite block is all the limit keeps"): OK as a reading; the computed facts (ℤ[1/2]^s dimension group, M₁₆ and M₂₅₆ chains give the same algebra) are standard for UHF-type limits (Bratteli 1972; Glimm 1960) — the limit algebra is a real UHF algebra of type 16^∞ tensored with the start cell.

**cells.** ATL-003b, 005b, 007b, 008b, 011b, 013b, 014d, 015b, 016b, 018d, 019b, 020c, 021b, 022b, 024b, PAG-006b (open; physics names: quark, lepton, confinement, horizon, baryon, Higgs, 210, 4/17): OK as open, no mathematical content to verify; ATL-022b/024b's "210 is not derived" is honest. ATL-006b, 010b, 017b, 023b (ours; names/conventions): OK. ATL-018 (standard): status issue (C.1). PAG-006 (standard): textbook identifications, OK (Lounesto, *Clifford Algebras and Spinors*, Ch. 2, 7, 10; Hestenes). ATL-022c (input): nit (C.1). GEN-016: as above.

**clock.** LAB-016 (open): see PAG-032. LAB-505b (ours): status (C.1). PAG-006 (standard): OK. INP-017 (input; sign convention of the clock): OK and necessary.

**shapes.** GOS-006d (open; cells for other odd unimodular lattices): OK as open; remark: for any odd unimodular L and characteristic k, k^⊥ is even and (L_even/2L, x·x/2) is a quadratic space whose Arf/type is σ(L) mod 8 by van der Blij, so the "cell" is any (p,q) with p − q ≡ σ mod 8 and p + q = n; the Atlas's attachment of a cell is thus well defined up to that choice. SHP-005b (open): OK. GOS-511b (ours): status (C.1). GOS-004 (standard): status (C.1). INP-013 (Witt split as input), INP-014, INP-015, INP-016 (Cartan matrices): OK as inputs.

**steps/groups.** LAB-012 (open; groups of Lie type, Cartan–Dieudonné in char 2): OK; the generation part is Dieudonné's theorem (Dieudonné, *La géométrie des groupes classiques*, 1955, Ch. II; exception O⁺(4,2)), see QT3. LAB-011 (ours; two unnamed readings): OK but should name the facts it reads (the row says so itself). LAB-010 (standard; Golay uniqueness, Co₁, Monster): OK (Conway–Sloane SPLAG Ch. 10, 11, 29). INP-079: OK.

**steps/category.** Open rows: LNC-054b, LNC-083b (tame/derived-tubular over ℝ): partly answerable — Ladkani's derived equivalences of posets are "universal" (hold over any commutative ring), so if the cited Ex. 2.2 is one of those, the derived equivalence holds over ℝ; tameness is defined over an algebraically closed field (use ℝ ⊗ ℂ). LNC-069, LNC-088 (Tian's DG category): OK as open, not treated. LNC-076c, LNC-081 (tenfold way, nilpotent generator): OK as open; the standard classification has no degenerate direction (QC3). LNC-077, LNC-097, LNC-123 (Nakayama twist of Cl(3,0,1) vs PGA duality): the algebra is known (Λ(V) is symmetric iff dim V is odd; Frobenius for all V — Skowroński–Yamagata, *Frobenius Algebras I*, Ch. IV examples; Lam, *Lectures on Modules and Rings*, §16); whether PGA texts use the twist: unknown to me. LNC-078b (states of degenerate *-algebras, composites): OK as open; the single-system statement is standard for finite-dimensional *-algebras (positive functionals kill the *-radical). LNC-079b (polar-space picture): known — Saniga–Planat, *Multiple qubits as symplectic polar spaces of order two*, Adv. Stud. Theor. Phys. 1 (2007); Havlicek–Odehnal–Saniga (2009); the contextuality side: Mermin 1993. LNC-080 (CAR → CCR limit): OK as open, infinite-dimensional. LNC-082b (E_n/2E_n identification known?): yes for n ≤ 8 (Coble's mod-2 reduction; Dolgachev–Ortland, *Point sets in projective spaces and theta functions*, Astérisque 165, Ch. VI; Conway–Sloane SPLAG Ch. 4 for the quadratic form on E₈/2E₈), see QD1. LNC-084 (representation type of Cl(p,q,r)): answerable, see QA2. LNC-085 (universal grading group): see QA3. LNC-086 (cohomology for the monoid-valued sign): pointer to partial cohomology (Dokuchaev–Khrypchenko, J. Algebra 427 (2015)); OK as open. LNC-098c (Carroll): physics, OK as open. Ours rows LNC-022, 053, 073b, 074b, 094, 095, 096, 104, 116, 119, 126, 132 (readings: label 0, up/down the ladder, rung 9 as boundary): OK as readings; LNC-096's "*-closure of Cl(p,q,r) is Cl(p+r,q+r)" is the mother-algebra embedding, correct. Standard rows: LNC-012 (definition): OK; LNC-037, LNC-121 (Cl⁰(1,3) = M₂(ℂ), Spin⁺(1,3) = SL(2,ℂ)): OK (Lounesto Ch. 10); LNC-054, LNC-083 (Wang Prop 3.1, Ladkani Ex. 2.2): plausible and consistent with the computed Coxeter polynomial (x−1)²(x²+x+1)³ and corank-2 Euler form (the profile of the tubular canonical algebra of type (3,3,3), Ringel LNM 1099 Ch. 5), but the two citations are not verified here (E); LNC-061d (Lundholm–Svensson Def. 2.4): OK; LNC-120 (Koszul sign = fermion exchange): OK. INP-080 (dagger involution as input): OK and necessary.

**steps/mirrors.** MIR-008 (ours; moves of spacetime on the demicube): OK. MIR-006 (standard; no mirror in a null vector): trivial, OK. INP-018, INP-020: OK.

**steps/comm.** EQN-003 (standard; structure constants of so(p,q)): OK.

**logbook.** Open: LNP-004, MAP-034, MAP-035 (plans/pointers), RSN-004b (A₂ on generations): OK as open. Ours: LNP-003, MAP-001b, MAP-025b, RSN-012 (the four kinds of i), RSN-016, RSN-018b, RSN-028c, SRC-001b, SRC-003c: OK as readings; RSN-012's facts are checked in RSN-012b. RSN-028 (input; J = γ₂γ₁): OK.

**steps.** PAG-023 (ours): OK.

**steps/baez.** Open: LNB-011d, LNB-022f, LNB-036b, LNB-042b, LNB-051, LNB-058c, LNB-152, LNB-165 (the two tens; mechanism): OK as open (no mechanism is known to me either; the lattice side II₂,₁₈ is right: Serre, *A Course in Arithmetic*, Ch. V §2 classifies indefinite unimodular lattices by rank, signature and type — this settles the "pointer, source unread" of LNB-011c/022d). LNB-025e, LNB-037, LNB-037b (Frobenius forms as a test case for open systems): OK as open. LNB-033c, LNB-040, LNB-041, LNB-034, LNB-034c, LNB-035c, LNB-144, LNB-159 (model questions): OK as open. LNB-044 (Hamming form of the Peirce rule in Loos?): unknown to me; the Peirce eigenvalue 1 − d/4 on the exterior-algebra model is a direct consequence of Loos's joint Peirce decomposition for the bi-Cayley/Clifford-type triples, but I know no printed statement. LNB-046 (eq. (12) of the Kepler paper): cannot check the paper's text here. Ours (30 rows, readings of names, flips as charge conjugation, the spring's signs, the ladder, Peirce = Hamming remark, Eisenstein tie): all OK as readings; LNB-105 "calling the flip charge conjugation is ours" — note CAND-134 (candidate): on Weyl multiplets the complement map is CP, not C. Standard (18 rows: paper paraphrases, Madelung rule, vector-like real representations, Hull's signatures, the A₂ theta series): OK; LNB-168 is trivially standard. INP-082/083/084: OK.

### C.3 Theorems T1–T20 (verified against standard knowledge)

T1 correct (the cocycle proof is right; the ε = 0 case is the integer identity ab + (a⊕b)c = a(b⊕c) + bc; the construction is Lundholm–Svensson's combinatorial Clifford algebra, Def. 2.4). T2 correct (Lawson–Michelsohn Prop. I.1.5 for Cl(V⊕W) = Cl(V) ⊗̂ Cl(W), valid for degenerate forms; the radical and super-centre parts verified by hand: a blade is central iff it is an even product of null generators or ω with n odd; super-central iff it is a product of null generators). T3 correct (Nakayama automorphism id for n odd, α for n even; for n even, r ≥ 1 every conjugator of α lies in J — verified by hand: the only labels that can carry a coefficient are F and odd subsets of the null set; standard facts: Skowroński–Yamagata Ch. IV). T4 correct; (iv) is exactly the Frobenius–Schur indicator of the regular module of G = {±e_a} (Σ_g χ_A(g²) = 2^{n+1}ν; real FS indicator +1, 0, −2 for D = ℝ, ℂ, ℍ), verified n ≤ 10 (`type_table_consequences.py`). T5 correct. T6 correct (Albuquerque–Majid, J. Algebra 220 (1999) for (d)). T7 correct as a statement about the algebra defined by the relations (the Gram matrix of Σ c_i c_{i+1} has eigenvalues cos(πj/(k+1))). T8 correct; the derived equivalence and tameness rest on two citations (E). T9 correct (the kernel/image orders match Bourbaki's tables and the known isomorphisms W(E₆) ≅ O⁻₆(2), W(E₇) ≅ 2 × Sp₆(2), W(E₈) ≅ 2.O⁺₈(2)); (e)'s transvection argument is right modulo Dieudonné for the generation. T10 correct. T11 correct (the point counts are the standard ones for Q⁻(5,2), Q⁺(5,2), Q⁺(7,2)). T12 correct at its scope (Dieudonné's exception O⁺(4,2) is the right one). T13 correct. T14 correct; (4) proved by hand here (a totally singular n/2-space containing 1…1 has only even weights, hence is doubly even and self-dual; conversely trivial). T15 correct. T16 correct. T17 correct. T18 correct as local statements. T19 correct. T20 correct. No theorem is over-claimed; the statusNotes are honest about what is recalled.

## D. Computations performed

All scripts are in `review_out/math/scripts/`, run with `python3 -I -B <script>`; every `--fault` exits 1 (checked).

| row | claim | method | result | script | runtime | --fault controls | proposed new research text | proposed evidence id |
|---|---|---|---|---|---|---|---|---|
| LNC-059 (also CAND-083, LNS-038 first sentence) | "the 2^w orthogonal idempotents are the finite shadow of the spectral theorem (the idempotents follow; not computed)" | For all 44 cells Cl(p,q), 1 ≤ p+q ≤ 8: exhaustive DFS for a maximal totally singular subspace W (commuting labels of square +1 closed under xor); E_σ = ∏(1 + σ_k e_{u_k})/2 over a basis; exact rationals: E² = E, E_σE_τ = 0, ΣE_σ = 1, dim(AE_σ) = tr L_E = 2^{n−w} = N·dim D, dim(E A E) = dim D (primitivity) by the exact trace of x ↦ ExE; group law v_Tv_U = v_{T⊕U}. | holds: 5,195 checks; 2^w = sN in every cell; every E_σ primitive; the family is a complete set of orthogonal primitive idempotents | `lnc059_idempotents.py` | 2 m 27 s (n ≤ 8); 23 s for n ≤ 7 | SIGN (one factor re-signed), NONCOMM (a non-commuting label in the basis), WITT (claims w+1) | "The 2^w idempotents E_σ = ∏_k (1 + σ_k u_k)/2 over a basis u_1 … u_w of a maximal totally singular subspace are idempotent, pairwise orthogonal, sum to 1 and are primitive (dim E_σ A E_σ = dim D), with dim A E_σ = N dim D: a complete set of 2^w = sN orthogonal primitive idempotents, computed exactly for every cell with 1 ≤ p + q ≤ 8 (44 cells)." | rv.IDEM |
| LNS-038 (staged edit), check_T11 4c/4d | "a Mermin grid exists in 30 of the 44 cells 1 ≤ p+q ≤ 8 and in none of p+q ≤ 3, (4,0), (1,3), (0,4), (5,0), (1,4); in those 14 the triple equations are solvable" | independent exhaustive grid search over square-+1 labels (grid fixed by four corners); 512 assignments per grid; 𝔽₂ elimination of all commuting triples | holds exactly (30/14, same list); G2 and G3 hold. Side finding: in the 30 cells every commuting 3×3 grid of square-+1 blades has line-sign product −1 (the PARITY fault finds no +1 grid). | `mermin_grids.py` | 1.2 s | PARITY, LIST (expects a grid in (1,3)), MATRIX | The staged text is right; keep the subalgebra argument for p,q ≥ 2 as a proof (C.1). | rv.MERMIN |
| CAND-144 (staged) / T11 (4) | "e₁ = X⊗1, e₂ = Z⊗1, e₃ = iY⊗X, e₄ = iY⊗Z: the nine blades are Mermin's nine operators up to sign and the six lines his rows and columns"; sign product −1 under all 512 re-signings | explicit real 4×4 matrices | holds (blade ↦ operator table printed by the script) | `mermin_grids.py` | — | MATRIX | staged text correct as written | rv.MERMIN |
| LAB-028 | (S^{⊗p}(S†)^{⊗q}H^{⊗n})³ = e^{iπ(p−q)/4}·1 | exact arithmetic in ℤ[ζ₈][1/2], n ≤ 3, all (p,q) | holds | `clifford_phases.py` | 1 m 26 s (whole script) | — | none needed | rv.WEIL |
| LAB-032 | ⟨S,H⟩ has 192 elements with the 8 eighth roots as scalars; ⟨ζ⁻¹S, iH⟩ has 48 (2O) with scalars ±1; ⟨ζH,S,CNOT⟩ has 46080 elements, scalars {1,i,−1,−i}, commutator subgroup of order 23040 containing i; orbit of |000⟩: 4320 / 8640 | exact BFS closures; commutator subgroup by 40 pseudo-random commutators with an index-2 certificate | holds in every number | `clifford_phases.py` | — | DROPS | none needed | rv.WEIL |
| LAB-037 / LAB-038 | b = ζH⊗S, a = CNOT₁₀(1⊗ζH)CNOT₀₁(1⊗S)²(1⊗ζH): a monomial with entries ±i and aba⁻¹b⁻¹ = i·1 (hence no double cover carved by Weil's (40) for m ≥ 2) | exact | holds; the consequence is a valid one-line argument (a commutator of lifts is independent of the lifts) | `clifford_phases.py` | — | CNOT (control/target swapped: not a scalar) | none needed | rv.WEIL |
| T10 (1), LNC-042/127 | det E_n = 9 − n, n = 3..12 | exact Bareiss | holds | `lattice_euler_checks.py` | 2.9 s (whole script) | DET | — | rv.LAT |
| LNC-045 / LNC-130 / T9 | E_n/2E_n has 4, 10, 20, 36, 64, 120 classes with q = 1 (n = 3..8) = labels of square −1 of Cl(n,0); radical of dim [n odd] with q = 1 on it for n = 3, 7 and 0 for n = 5 | enumeration from the Cartan matrices | holds (64 at n = 7 = 63 root classes + the radical class) | `lattice_euler_checks.py` | — | — | — | rv.LAT |
| T9 (f) | A₆/2A₆ plus type (28 non-singular), E₆/2E₆ minus type (36) | enumeration | holds | `lattice_euler_checks.py` | — | — | — | rv.LAT |
| T8 (1)(2), LNC-058, LNC-083c | Euler-form inertias (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0..5; Tits form (6,1,1) and Coxeter polynomial (x−1)²(x²+x+1)³ at n = 3 | exact symmetric elimination; Faddeev–LeVerrier | holds | `lattice_euler_checks.py` | — | EULER | — | rv.LAT |
| LAB-035 / T14 (4) | number of self-dual codes of labels all of square +1 = Π_{i=0}^{n/2−2}(2^i+1) iff p ≡ q mod 8, else 0 (all self-dual codes: 1, 3, 15, 135) | enumeration of all self-dual binary codes, n ≤ 8, every (p,q) | holds (1, 2, 6, 30 at (1,1), (2,2), (3,3), row 8; 0 elsewhere) | `lattice_euler_checks.py` | — | CODES | "…and for every even n: the codes are the maximal totally singular subspaces of the form descended to 1^⊥/⟨1⟩, which exists iff w(1…1) = 0 (p ≡ q mod 4) and has maximal totally singular subspaces iff its Arf invariant (p − q)/4 mod 2 vanishes (p ≡ q mod 8); they then number Π_{i=0}^{n/2−2}(2^i + 1) (Taylor, the chapter on orthogonal groups)." | rv.LAT |
| GEN-011 | ungraded ⊗ has the type of the graded ⊗ exactly when one clock is 0 or 4 mod 8 (235 of 495 pairs) | from the type table with ℝ⊗D = D, ℂ⊗ℂ = ℂ², ℂ⊗ℍ = M₂(ℂ), ℍ⊗ℍ = M₄(ℝ) | holds, 235/260. Mechanism (a lemma for all n): if a factor has even n and ω² = +1 (clock 0 or 4), e'_j ↦ ω ⊗ e'_j gives Cl(p,q) ⊗ Cl(p',q') ≅ Cl(p+p',q+q') (Lawson–Michelsohn I.4); if a factor has even n and ω² = −1 (clock 2 or 6), the same map mirrors the other factor: the ungraded product is Cl(p+q', q+p') of clock c_even − c_other, whose type equals that of c_even + c_other only if 2c_other ≡ 0 or 2c_even ≡ 2 mod 8, i.e. only if c_other ∈ {0,4}; odd ⊗ odd has a 4-dimensional centre against 1. | `type_table_consequences.py` | 0.4 s (whole script) | CLOCK | add "(a lemma for every n: …)" with the mechanism above | rv.TYPE |
| T4 (iv), LNC-006 | ν = Σ_a e_a² = Re((1−i)(1+i)^p(1−i)^q) = sN·ind(D) | labels for p+q ≤ 8, closed forms to 10 | holds | `type_table_consequences.py` | — | IND | — | rv.TYPE |
| GEN-022, ATY-001, ATY-026 | A(p,q) = coker(N(Cl(p+1,q+1)) → N(Cl(p+1,q))) = ℤ, 0, 0, 0, ℤ, 0, ℤ₂, ℤ₂ by the clock = KO^{p−q}(pt) | from the type table alone (restriction multiplicities from dimensions; the (h,h) split for two-summand targets because the grade automorphism is inner in the larger cell) | holds for all 45 cells p+q ≤ 8; so the table is a corollary of T4 + ABS | `type_table_consequences.py` | — | KO | — | rv.TYPE |
| INP-019 | reversion ≅ Clifford conjugation iff n ≡ 0 mod 4 and indefinite | fixed-space dimensions and trace-form inertias, n ≤ 10; explicit intertwiner e_i ↦ e_i I for q odd | holds (plus the trivial n = 0 case) | `type_table_consequences.py` | — | — | add "(n ≥ 1; a theorem for all n by the invariants and Skolem–Noether)" | rv.TYPE |
| CAND-058 | dim centre = 2^{r−1} + [n odd] (r ≥ 1), super-centre 2^r | labels, all 84 cells n ≤ 6 | holds | `type_table_consequences.py` | — | — | — | rv.TYPE |

Items from the priority list that are not in my domain or already closed: GEN-024 ("dense square not run") is already closed in 3.7.0 by evidence ns.P3 (lastPassed true) — the digest text and the map record say P² = P was computed from the subset expansion on all 4^{|V|} pairs of terms; nothing is left to do. ATY-024, CAND-121, RIG-M19, RIG-M52, GRV-011, LNS-017e, YM-712, ATY-015, ATY-046, CAND-084, CAND-086/ATY-051 are physics rows (left to the physics referee); on CAND-084 I note only that the Lichnerowicz identity D² = ∇*∇ + R/4 is textbook (Lawson–Michelsohn Ch. II (the Lichnerowicz formula)) and the staged reasoning "(DJ)² = −D²" is right since J acts on the right and commutes with D.

## E. Not computable here, with the reason

| row | reason |
|---|---|
| LNC-054, LNC-083, LNC-054b, LNC-083b, QT2, QB4, QT9 (tameness and derived equivalence of kB₃) | tameness is not finitely decidable by a script; the derived equivalence needs a tilting complex (Ladkani's), i.e. the unread source. The computed profile (Coxeter polynomial, corank-2 Euler form) is necessary, not sufficient. |
| LAB-027 (Lévy dragon boundary counts to n = 419) | needs Duvall–Keesling's Proposition 5.1 and a long run; not re-run. |
| LNC-069, LNC-088, QB1, QB5 (Tian's DG category) | the category is not built in the Atlas; needs the source. |
| LNC-080, QE3's limit (CAR → CCR) | infinite-dimensional. |
| LAB-016 / PAG-032 Pin⁺ bordism | not a finite computation; standard (Kirby–Taylor: Ω₂^{Pin⁺} = ℤ₂, Ω₂^{Pin⁻} = ℤ₈, Ω₂^{Spin} = ℤ₂), see F.1. |
| GOS-511b (rank-16 classification) | enumeration of all even unimodular lattices of rank 16 needs the mass formula / Kneser neighbours; standard, cite instead. |
| LNB-046 (eq. (12) of the Kepler paper, v5) | needs the paper's text. |
| LNB-011c, LNB-022d, CAND-032 ("that the signature fixes an indefinite even unimodular lattice") | a theorem, not a computation: Serre, *A Course in Arithmetic*, Ch. V §2 (indefinite unimodular lattices are classified by rank, signature and type). |
| LNC-085, QA3 (fine gradings of Cl(p,q,r)) | a classification problem (Elduque–Kochetov for simple algebras; non-semisimple case open). |
| CPL-011b, LNC-098c, LNB-034/034c/040/041/144/159, MAP-034/035, LNP-004 | physics readings or plans, no finite statement to compute. |
| LAB-036/039's Eisenstein-series side | the identification with an Eisenstein series over the adeles is a reading; the finite identity is computed by the Atlas. |

## F. Structural cross-check and the four extra questions

### F.0 The claims of item 4 (common brief)

| claim | verdict | reference | note |
|---|---|---|---|
| mod-8 type table (T4 (i)) | textbook | Atiyah–Bott–Shapiro, Topology 3 (1964) Table 1; Lawson–Michelsohn Thm I.4.3; Lounesto Ch. 16 | verified entry by entry; c ↔ 2 − c symmetry of ungraded types right. |
| clock = Brown / Arf–Brown–Kervaire invariant of w = π + 2Q | textbook | Brown, Ann. Math. 95 (1972); Kirby–Taylor 1990 §3; Taylor, *Gauss sums in algebra and topology* | the Brown invariant of ⟨1⟩^p ⊕ ⟨−1⟩^q is p − q mod 8 by additivity; the Atlas's "exponent of the clock sum = w" is right. |
| Gauss sum (1+i)^p(1−i)^q = 2^{n/2}e^{iπ(p−q)/4} | textbook (elementary) | — | product formula ∏(1 + i^{ε_j}); null generators give a factor 2, verified. |
| KO^{p−q}(pt) from graded modules (ABS) | textbook | ABS §5 (Table 2) and §11 | the Atlas's indexing A(p,q) = KO^{p−q} is consistent with ABS's A_k = KO^{−k} for C_k = Cl(0,k); derived from the type table here (D). |
| Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ) | textbook | Lawson–Michelsohn Thm I.4.3; ABS Prop. 4.2 | the Atlas's map e_i ↦ e_iΩ is the standard proof; Cl(8,0), Cl(0,8), Cl(4,4) are one graded algebra End(ℝ^{8|8}). |
| Weil's index = e^{iπ(p−q)/4} | textbook | Weil, Acta Math. 111 (1964), Ch. II; Lion–Vergne, *The Weil representation, Maslov index and theta series*, Ch. 1; R. Ranga Rao, Pacific J. Math. 157 (1993) | γ(e^{iπx²}) = e^{iπ/4} on ℝ, multiplicative in orthogonal sums. The identification with the label Gauss sum is a correct reading: both are Brown-type invariants of a quadratic refinement whose one-dimensional values coincide. |
| tenfold way ↔ eight clocks + two complex classes | correct non-standard phrasing | Kitaev, arXiv:0901.2686 §3 (Clifford modules, KO^{s−d}); Altland–Zirnbauer 1997 | the match is up to s ↔ 2 − s for the symmetry algebra alone (LNC-076c says so); Kitaev's table uses the Clifford extension problem, which the Atlas reproduces in CAND-006. |
| E_n/2E_n carries the label form of Cl(n,0) | correct non-standard phrasing | Dolgachev–Ortland Astérisque 165 Ch. VI (Coble); Conway–Sloane SPLAG Ch. 4 §8; Manin, *Cubic Forms* Ch. IV | the Atlas's proof via k^⊥ ⊂ I_{1,n} and CAND-101 is clean and general; the identification with the even labels of Cl(1,n) = labels of Cl⁰(1,n) ≅ Cl(n,0) is the right standard name. |
| Golay = a Lagrangian of Cl(24,0) | correct non-standard phrasing | Wood 1993 §5; MacWilliams–Sloane Ch. 19 | true as "Type II codes = Lagrangians of (𝔽₂ⁿ, wt mod 4)"; the Clifford algebra itself plays no role beyond naming the ℤ₄-form. |
| Fidkowski–Kitaev ℤ₈ = the clock | textbook | Fidkowski–Kitaev, PRB 81 (2010) 134509 | FK's own analysis is via real Clifford modules; the Atlas's junction computation (LAB-021) reproduces their degeneracies. |

### F.1 Question 1: the hierarchy mod 2 → mod 4 → mod 8

Verdict: correct and essentially complete as a hierarchy of *invariants of the quadratic data of the labels*; two things are missing or mislabelled.

What lives at each level (standard):
- mod 2: the ℤ₂-grading π (parity), the Koszul sign, the grade automorphism α, the even subalgebra; the two symmetric bilinear forms on 𝔽₂ⁿ — the dot product a·b (polar form of w; the Jordan–Wigner commutator of *generators*) and the commutation form β(a,b) = π(a)π(b) + a·b (polar form of Q; the commutator of *blades*); the 𝔽₂-quadratic forms Q = [e_a² = −1] and its restriction to even labels (whose polar form is a·b); their Arf invariants (T9 (f)); Pin vs Spin (w₁, w₂ obstructions); over surfaces: Spin structures = ℤ₂-enhancements, Ω₂^{Spin} = ℤ₂ (Arf).
- mod 4: the ℤ₄-form w = π + 2Q (a quadratic refinement of the dot product; Weil's character of the second degree i^w); the grade-dependent signs (−1)^{k(k−1)/2} (reversion, e_a²) and (−1)^{k(k+1)/2} (conjugation), which have period 4 in k; the Walsh self-duality ATY-033 (a ℤ₄-bent function); the additivity on disjoint labels (CAND-057/LAB-022), which selects the 2ⁿ diagonal forms, i.e. a *frame* (LAB-024 says so correctly); over surfaces: Pin⁻ structures = ℤ₄-enhancements (Kirby–Taylor Thm 3.2); over finite fields BW(𝔽_q) ∈ {ℤ₄, ℤ₂²} (QC2).
- mod 8: the Brown invariant β(w) ∈ ℤ₈ = the clock = the phase of the Gauss sum = Weil's index = Wall's class in BW(ℝ) ≅ ℤ₈ = the period of KO^{p−q}(pt) = Ω₂^{Pin⁻} = σ(I_{p,q}) mod 8 (van der Blij) = the FK ℤ₈ = ζ₈ from (SH)³; and Brown's theorem that β is an *isomorphism* W(ℤ₄-forms) → ℤ₈ (so the clock is the Witt class of w, additive under ⊥ = the graded tensor product: this is the structural reason behind "the clocks add", K4a/LNC-035).

What the Atlas misses or mislabels: (i) it never says that Q and w refine different bilinear forms (C.1, LAB-017/ATY-033); this is the whole content of "Q sees only c ↔ 2 − c" (commutation form = ungraded algebra) versus "w sees c" (dot product = graded algebra). (ii) The Arf invariant is the mod-2 shadow of the clock and is named only in T9 (f): for even n with ω² = +1 (c ≡ 0, 4) the descended form on 1^⊥/⟨1⟩ has Arf = c/4 mod 2 — this is what makes LAB-035/T14 work and should be stated once. (iii) The Witt-group structure (Brown) is not stated; it would unify LAB-017/018/019/CAND-057. (iv) The Pin⁺ side is left open (LAB-016/PAG-032) although it is textbook: Kirby–Taylor §3: Pin⁻ structures ↔ ℤ₄-enhancements, Ω₂^{Pin⁻} ≅ ℤ₈ by Brown; Pin⁺ structures exist iff w₂ = 0 and Ω₂^{Pin⁺} ≅ ℤ₂ (no ℤ₄-enhancement; the invariant is the Arf of a Spin structure on a double cover); on fermions, time reversal with T² = 1 ↔ Pin⁻ (Majorana chains, FK ℤ₈ = Ω₂^{Pin⁻}) and T² = (−1)^F ↔ Pin⁺ (Kapustin–Thorngren–Turzillo–Wang, *Fermionic symmetry protected topological phases and cobordisms*, JHEP 2015). That closes the "recalled, not checked" sentence of LAB-016 by citation.

### F.2 Question 2: M₁₆(ℝ) as an organising object

Verdict: legitimate for exactly the data that are invariants of the *graded Morita class* (equivalently of the clock c and the parity of n), and not for anything that counts labels, modules or groups. Precisely:

Periodic (reduce faithfully to the cell with the same c, under (p,q) → (p+8,q), (p,q+8), (p+4,q+4), r fixed): the ungraded type (D, s); the division algebra of the commutant; the type of the even part; the BW class; the Brown invariant / Gauss phase / Weil index; KO^{p−q}(pt) and the ABS cokernel; the sign and vanishing of the FS count ν (not its value); ω² (for fixed c and n mod 8); existence of Majorana, Weyl and Majorana–Weyl real spinors (c ≡ 0, 1, 2 real; c ≡ 0 MW); the ± type (Arf) of the label quadric for even n; whether reversion ≅ conjugation (n mod 4 and definiteness, F/C.1); the tenfold-way class; the FK degeneracy pattern. For r ≥ 1: the clock (of the quotient) and the K-class (GEN-022) are periodic, while r itself is a separate coordinate on which nothing is periodic (the super-centre Λ(ℝ^r), the Loewy length r + 1, the radical dimension 2ⁿ − 2^{p+q}).

Not periodic (grow or change with n, p, q): dim 2ⁿ, the matrix size N, the dimensions of modules and ideals, the Witt index w ≈ n/2 and the number 2^w of primitive idempotents, the point/line counts of the label quadrics, the number of self-dual codes Π(2^i+1) and of stabiliser states, |O(Q)|, the Clifford-group orders and the order of its phase group (8 for one qubit, 4 for m ≥ 2: LAB-037), the Dedekind numbers, the Euler forms of B_n, the existence of a Mermin grid (depends on the signature, e.g. yes for (2,2), (3,1), no for (1,3), (4,0), (0,4), all of n = 4), the E_n data (det 9 − n, root counts, Weyl groups: n ≤ 8 only), the Peirce block sizes, the Gauss-sum modulus 2^{n/2}, the number of pinor classes' dimensions. The Atlas handles this correctly in practice (e.g. GEN-023 "only the radical grows", GEN-019 "each block multiplies every irreducible by 16"); the one place to watch is the cells page, which displays n-dependent counts (Peirce blocks, 210, 70) beside clock-periodic types.

### F.3 Question 3: which proved-by-atlas rows are corollaries of standard theorems

Immediate corollaries (upgradeable to "for every n" with the citation): GEN-010/013/017/031 (Cl(n+8) ≅ Cl(n) ⊗ Cl(8), ABS Prop. 4.2, Lawson–Michelsohn I.4); GEN-018/022/ATY-001/ATY-026 (ABS Table 2; and the derivation from the type table in D); GEN-021/027/028 (Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^r), idempotent lifting over a nilpotent ideal: Lam, *A First Course in Noncommutative Rings*, §21); GEN-015/020 (CAR and its Bratteli diagram 1 → 2 → 4 → …); GEN-026/030 (direct limits of matrix algebras, dimension group ℤ[1/16] = ℤ[1/2]: Bratteli 1972, Glimm 1960); GEN-032 (Gauss sum closed form); GEN-033/034 (complexification); GEN-011 (D above); LNC-059/CAND-083 (primitive idempotents = maximal totally singular subspaces, D); LAB-035 (Witt's theorem for ℤ₄-forms, Wood 1993; count of Lagrangians, Taylor Ch. 11); LAB-034 (Weil's Thm 5 instance); ATY-033 (quadratic Gauss sums); LAB-017/RSN-029/LNC-006 (elementary); LNC-045/130/087 for n ≤ 8 (Coble; Dolgachev–Ortland); LAB-030 (Clifford group = normaliser of the Pauli group: Bolt–Room–Wall 1961, Weil n° 10); CAND-008 (stabiliser counts); CAND-026/ATY-016 (van der Blij; Milgram); CAND-104, CAND-096, CAND-065, CAND-100, CAND-106 (face posets, Leinster, Gerstenhaber–Schack, Dedekind); CAND-050 (Frenkel–Kac); CAND-063/064 (triality, Cartan's pure spinors); CAND-140, ATY-032, CAND-145 (McKay, Bethe); ATY-031 (Mednykh/Frobenius formula for |Hom(π₁Σ_g, G)|); CAND-116 (Dyson/Kramers); MAP-016/EQN-007 (so(p,q)); MIR-009/010, RSN-007/023 (Cartan–Dieudonné over ℝ); PAG-005, CAND-058 (centre); LNC-002/014/016/017 (radical); LNC-004/028/029/030/CAND-061 (Frobenius structure of Λ(V) and Cl: symmetric iff n odd); LNC-007/036 (even subalgebra); LNC-035/117 (graded tensor product); THM-004/LNC-144 (incidence algebra inside End Λ); LNB-002/CAND-094 (Albuquerque–Majid); LNB-016/118/119/CAND-052 (Levi gradings); LNB-007/CAND-109 (Schläfli graph); LNB-010/167/CAND-021 (E₇ ⊃ A₂ × A₅); CAND-024/LNB-011 (Majorana–Weyl iff s − t ≡ 0 mod 8); CAND-074 (Serre Ch. V); CAND-107/105 (Eisenstein integers); CAND-019 (ℤ₆); CAND-003 (anomaly sums).

Genuinely new small computations (no textbook statement at this granularity known to me): the Mermin-grid existence table by cell (LNS-038/check_T11 4c; and the side finding that every commuting grid in those cells has parity −1); LAB-037/038 (the phase i as a single commutator; the minimal phase group of the two-qubit Clifford group is the fourth roots — I know this as folklore, not as a printed theorem); LAB-036/039 (the finite transitive-orbit identity, as computed); GEN-027 (commutant of a projective cover on null cells); LNC-003/CAND-077 (universal label-homogeneous grading group ℤ₂^{p+q} × ℤ^r); CAND-079 (partial-cohomology dimensions); LNC-058/T8 (Euler/Tits data of B_n for n ≤ 5); T12's transvection-length table; ATY-027 (Lefschetz on the cube complex); ATY-029/030 (Spinors × Spinors = Forms and the Klein quadric on labels — standard facts, new labelling); CAND-091 (Brown invariant of the 2^r extensions — standard argument, new count); T9 (f) (A₆ vs E₆: a standard fact, nicely isolated); ATL-002b (discriminant argument for the null seed).

### F.4 Question 4: the 34 questions to researchers

- QA1 (graded Brauer group with r): answer known in substance. Cl(p,q,r) ≅ Cl(p,q) ⊗̂ Λ(ℝ^r) is graded Azumaya over its super-centre Λ(ℝ^r) (artinian local, residue field ℝ); for artinian local rings Br(R) → Br(R/m) is an isomorphism (Azumaya; Knus–Ojanguren, *Théorie de la descente et algèbres d'Azumaya*, LNM 389), and the same holds for the graded group, so BW(Λ(ℝ^r)) ≅ BW(ℝ) = ℤ₈: r is not a Brauer-type coordinate; the class of Cl(p,q,r) over Λ(ℝ^r) is just c. Reference for BW(ℝ) = ℤ₈: Wall 1964; Lam, the chapter on Clifford algebras; Deligne, *Notes on spinors*.
- QA2 (representation type): answer: that of Λ(k^r) — finite (r ≤ 1), tame (r = 2), wild (r ≥ 3), for every (p,q), over an algebraically closed field. Proof: for p + q even Cl(p,q,r) ⊗ ℂ ≅ M_N(ℂ) ⊗ Λ(ℂ^r) is Morita equivalent to Λ(ℂ^r); for p + q odd it is Morita equivalent to the skew group algebra Λ(ℂ^r) ⋊ ℤ₂ (ℤ₂ acting by parity), which has the same representation type (Reiten–Riedtmann, J. Algebra 92 (1985), skew group algebras with |G| invertible). Over ℝ, representation-finiteness is detected after base change (Jensen–Lenzing). So "label 0" is measured by r alone.
- QA3 (universal grading group for arbitrary gradings): not a single group — fine gradings on M_N(D) have universal groups up to ℤ^{N−1} × (torsion) (Cartan grading); classification of fine gradings on real matrix algebras: Bahturin–Kochetov–Rodrigo-Escudero, J. Algebra (2018); Elduque–Kochetov, *Gradings on Simple Lie Algebras*, Ch. 2. For non-semisimple Cl(p,q,r): unknown to me.
- QA4 (complement duality, Nakayama twist): known in algebra (Λ(V) Frobenius for all V, symmetric iff dim V odd; Nakayama = grade involution; supersymmetric in sVec: Skowroński–Yamagata Ch. IV; Lam, *Lectures on Modules and Rings* §16). Whether PGA papers use the twist: unknown to me.
- QA5 (Frobenius forms, trace, states): the torsor statements are standard (Frobenius forms = λ(u·), symmetric ones under central units: Skowroński–Yamagata, *Frobenius Algebras I*, Ch. IV); states on M_N(D) as real *-algebras: Goodearl, *Notes on real and complex C*-algebras*; the radical part is the standard fact that positive functionals on a finite-dimensional *-algebra vanish on its *-radical.
- QB1, QB5 (Tian): unknown to me.
- QB2 (cohomology for monoid-valued signs): the framework exists — partial cohomology of groups and twisted partial group algebras (Dokuchaev–Khrypchenko 2015; Exel's partial actions); whether the radical is cohomological there: unknown to me.
- QB3 (octonion cochain, null analogue): the Albuquerque–Majid picture is known (J. Algebra 220 (1999)); the Cayley–Dickson family with μ ∈ {−1, 0, +1} (LNB-019b) is classical (Albert; Schafer, *An Introduction to Nonassociative Algebras*, Ch. III); a cochain treatment of the μ = 0 case: unknown to me.
- QB4, QT2, QT9: see C.2 (plausible; citations unverified; the radical of the Euler form of a tubular algebra is spanned by the dimension vectors h₀, h_∞ of the tubular families, Ringel, LNM 1099, Ch. 5 — for kB₃ these are the images under the derived equivalence, not necessarily dimension vectors of modules).
- QC1: as QA1 — the graded Morita class is (c, r) as a pair of invariants, not an element of a group containing r.
- QC2 (finite-field clock): BW(𝔽_q), q odd, is ℤ₄ if q ≡ 3 mod 4 and ℤ₂ × ℤ₂ if q ≡ 1 mod 4 (Wall 1964; Lam, *Introduction to Quadratic Forms over Fields*, Ch. IV); "null" (degenerate form) is not "ramified" (a ramified quaternion algebra over ℚ_p is a non-degenerate division algebra, Hilbert symbol −1): the L1b analogy does not extend to n = 2.
- QC3: no — the tenfold way classifies non-degenerate symmetry classes; a nilpotent generator has no place in it (gapless/degenerate directions are treated separately in the literature).
- QD1: known for n ≤ 8 (Coble; Dolgachev–Ortland Ch. VI; Conway–Sloane Ch. 4 §8 for E₈/2E₈ ↔ O⁺₈(2)); for E₁₀ the Atlas's cited Allcock agrees; beyond, see QT6.
- QD2: yes — "clock = Brown invariant of w" is the correct statement, and it is the same ℤ₈ as the signature mod 8 of odd unimodular lattices (Brown 1972; van der Blij) and of even lattices via Milgram's formula (Milnor–Husemoller, *Symmetric Bilinear Forms*, App. 4): answered.
- QD3: the equality "blades of square −1 = positive roots" for n = 3..8 is the statement that for Dynkin E_n every non-singular class of E_n/2E_n is a root class (W(E_n) is transitive on roots and on non-singular classes), plus the radical class at n = 7; it stops at n = 8 because E₉, E₁₀ have infinitely many roots. Gabriel's theorem is unrelated; no deeper reason known to me.
- QD4: yes — Mod(N_n) → Aut(H₁(N_n; ℤ₂), ·) is surjective for non-orientable surfaces (McCarthy–Pinkall, *Representing homology automorphisms of nonorientable surfaces*, MPI preprint; Gadgil–Pancholi, Proc. Indian Acad. Sci. Math. Sci. 115 (2005)), so Pin⁻ structures up to diffeomorphism are the O(V,·)-orbits of ℤ₄-enhancements, classified by the Brown invariant (Wood/Kirby–Taylor), and Aut(V,Q,π) is the stabiliser of one enhancement.
- QE1: standard (density elements over ℝ, ℂ, ℍ): answered.
- QE2: the finite-geometry picture is in print: Saniga–Planat 2007; Havlicek–Odehnal–Saniga 2009; Lévay–Saniga–Vrana 2008 (three-qubit operators and the split Cayley hexagon, with the E₆/27 connection); Mermin's square = the doily W(3,2) structure.
- QE3: the super-trace argument is the standard trace argument (tr[a,a†] = 0 ≠ tr 1) with tr replaced by str: answered, folklore.
- QE4: not mathematics.
- QE5, QE6, QE7: unknown to me (and I expect no relation).
- QT1: the cleanest printed route is Deligne, *Notes on spinors* (Quantum Fields and Strings I), §3: the super Brauer group of ℝ is ℤ₈ with Cl(p,q) ↦ p − q, proved by hand; Lam's chapter on Clifford algebras gives the extension 0 → Br(ℝ) → BW(ℝ) → Q(ℝ) → 0.
- QT3: generation is Dieudonné (1955), exception O⁺(4,2); length bounds in characteristic 2 are in Hahn–O'Meara, *The Classical Groups and K-Theory*, Ch. 6 (and Ellers' papers on products of transvections); the Atlas's 7 > 6 at n = 6 is consistent with the known failure of the real Cartan–Dieudonné bound in characteristic 2; an exact general formula: unknown to me.
- QT4: unknown to me.
- QT5: Roelfs–De Keninck, *Graded symmetry groups: plane and simple*, Adv. Appl. Clifford Algebras 33 (2023) prove the general-n invariant decomposition; the isoclinic case λ₁ = λ₂ is the classical non-uniqueness (Williamson normal form: any splitting of the eigenspace works): answered.
- QT6: for E₁₀ = II_{9,1} the Weyl group is the full reflection group of the lattice and O⁺(II_{9,1}) = W(E₁₀) (Vinberg 1975; Conway–Sloane SPLAG Ch. 27), and the Atlas's cited Allcock gives the image O⁺₁₀(2); for general n the Atlas's own argument (every non-singular class contains a root, so the image contains all transvections) plus Dieudonné's generation theorem is a proof once the first clause is proved for all n (it is checked to n = 200): plausible for all n ≥ 3; I know no printed statement for n > 10.
- QT7: yes — Wood 1993 §5 is this route; the lattice analogue (van der Blij/Milgram for Type II lattices in rank ≡ 0 mod 8) is in Milnor–Husemoller App. 4 and Serre Ch. V.
- QT8: open (model question).
- QT10: not mathematics.

## G. Dangerous spots (what a hostile referee attacks first)

1. **Status inflation.** 633 of 786 rows are `proved-by-atlas`; by the Atlas's own definition this means "computed at the stated scope", but a reader will read "proved". The list in F.3 shows that most of these are small-n instances of textbook theorems; the review should say so page by page (the T-rows and the "recalled" markers are the defence).
2. **LAB-018** (and clock.clock.brown): the bordism identifications are literature inside a `proved-by-atlas` row (C.1).
3. **"The clock of a degenerate cell is forced"** (LNC-006/018/055/107): a definitional choice presented as a theorem (C.1).
4. **The category lens rests on two unread citations** (Wang arXiv:2407.11363 Prop. 3.1; Ladkani arXiv:0708.1412 Ex. 2.2) for tameness and the derived equivalence of kB₃; everything else on the page is checked, but the headline "tame and derived-tubular" is not.
5. **The Weil line's "same number"** (LAB-028/031: the index of the real form of signature (p,q) and the label Gauss sum): true, but the structural reason (both are Brown-type invariants, multiplicative in ⊥, equal on one-dimensional forms) must be stated or it reads as numerology; and "finite Siegel–Weil formula" (LAB-036/039) names a transitive-orbit average after a deep theorem.
6. **"Golay = Lagrangian of Cl(24,0)"**: correct but the Clifford algebra contributes only the ℤ₄-form wt mod 4; a referee will ask what the algebra adds (answer: nothing beyond LAB-017's identification).
7. **Two polar forms, one name** (LAB-017/ATY-033/LAB-019): the dot product and the commutation form are both called "the form"; the c ↔ 2 − c ambiguity of Q is the symptom (C.1).
8. **The Pin⁺ side and T² = ±1** left `open` (LAB-016/PAG-032) although it is in Kirby–Taylor and Kapustin et al. (F.1).
9. **The tenfold-way match** needs T², C² and the direction as inputs (LNC-076c admits it); a referee will say the clock does not predict the table, it reproduces it.
10. **Readings with `proved-by-atlas`** (ATY-019, SHP-003, LNB-025b, MAP-025) blur the Atlas's own vocabulary; ATY-019 is the clearest case (C.1).
