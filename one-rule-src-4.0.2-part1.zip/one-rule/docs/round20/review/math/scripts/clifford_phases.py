#!/usr/bin/env python3
# Review script (math referee, Oct 2026). Exact arithmetic in Z[zeta_8][1/2]; no atlas import.
"""clifford_phases.py -- the Weil line LAB-028, LAB-032, LAB-037, LAB-038 on the labels, recomputed exactly.

Numbers are elements of Z[zeta][1/2], zeta = e^{i pi/4}, written a + b zeta + c zeta^2 + d zeta^3 (zeta^4 = -1) over a
power-of-two denominator; i = zeta^2, sqrt2 = zeta - zeta^3, H = (1/sqrt2)(1 1; 1 -1) = ((zeta - zeta^3)/2)(1 1; 1 -1).
 W1. LAB-028: (S^{(x)p} (S^dag)^{(x)q} H^{(x)n})^3 = zeta^{p-q} 1 for every (p,q) with n = p+q = 1..3 (Weil's index of the
     real quadratic form of signature (p,q) is e^{i pi (p-q)/4}; on the labels, the gates t_0 = S^p Sd^q and d'_0 = H^n).
 W2. LAB-032 (m = 1): <S, H> has 192 elements and its scalars are the eight eighth roots of unity; <zeta^-1 S, iH>
     has 48 elements (the binary octahedral group) with scalars +-1 only.
 W3. LAB-037: with qubit 0 the left tensor factor, b = zetaH (x) S and
     a = CNOT_10 (1 (x) zetaH) CNOT_01 (1 (x) S)^2 (1 (x) zetaH): a is monomial with entries +-i and a b a^-1 b^-1 = i 1.
     Consequence (LAB-038, "none with n = 2"): a commutator of lifts does not depend on the lifts, so no group of
     unitaries over the two-qubit Clifford group modulo scalars has scalars in {+-1} only; the least is {1,i,-1,-i}.
 W4. LAB-032 (m = 2): <zetaH, S, CNOT> (gates on either qubit) has 46080 elements, its scalars are exactly
     {1, i, -1, -i}, and its commutator subgroup has 23040 elements and contains i 1.
 W5. LAB-032 (m = 3): the orbit of |000> under zetaH, S, CNOT has 4320 vectors (= 1080 stabiliser states x 4 phases)
     and under H, S, CNOT 8640 (x 8 phases).
Faults: --fault CNOT (swaps control and target in a: the commutator is then not a scalar),
        --fault DROPS (drops S from the two-qubit generators: the order is then not 46080).
Usage: python3 -I -B clifford_phases.py [--fault NAME]   (about 1-2 minutes)
"""
import sys

# ---- Z[zeta_8]: tuples (a,b,c,d) = a + b z + c z^2 + d z^3, z^4 = -1 ----
def zmul(x, y):
    a, b, c, d = x; e, f, g, h = y
    return (a*e - b*h - c*g - d*f, a*f + b*e - c*h - d*g, a*g + b*f + c*e - d*h, a*h + b*g + c*f + d*e)
def zadd(x, y): return (x[0]+y[0], x[1]+y[1], x[2]+y[2], x[3]+y[3])
def zneg(x): return (-x[0], -x[1], -x[2], -x[3])
def zconj(x):  # complex conjugate: z -> z^-1 = -z^3, z^2 -> -z^2, z^3 -> -z
    a, b, c, d = x; return (a, -d, -c, -b)
Z0 = (0, 0, 0, 0); Z1 = (1, 0, 0, 0); ZETA = (0, 1, 0, 0); ZI = (0, 0, 1, 0)
def zpow(x, k):
    r = Z1
    for _ in range(k % 8): r = zmul(r, x)
    return r

# ---- matrices: (entries tuple-of-tuples over Z[zeta], exponent k) meaning entries / 2^k, normalised ----
def normalise(E, k):
    while k > 0 and all(all(v % 2 == 0 for v in x) for r in E for x in r):
        E = tuple(tuple(tuple(v // 2 for v in x) for x in r) for r in E); k -= 1
    return (E, k)
def M(rows, k=0): return normalise(tuple(tuple(tuple(x) for x in r) for r in rows), k)
def mmul(A, B):
    (EA, ka), (EB, kb) = A, B
    n, m, l = len(EA), len(EB[0]), len(EB)
    out = []
    for i in range(n):
        row = []
        for j in range(m):
            s = Z0
            for t in range(l): s = zadd(s, zmul(EA[i][t], EB[t][j]))
            row.append(s)
        out.append(tuple(row))
    return normalise(tuple(out), ka + kb)
def kron(A, B):
    (EA, ka), (EB, kb) = A, B
    n, m = len(EA), len(EB)
    out = tuple(tuple(zmul(EA[i // m][j // m], EB[i % m][j % m]) for j in range(n * m)) for i in range(n * m))
    return normalise(out, ka + kb)
def dagger(A):
    E, k = A; n = len(E)
    return (tuple(tuple(zconj(E[j][i]) for j in range(n)) for i in range(len(E[0]))), k)
def ident(n): return M([[Z1 if i == j else Z0 for j in range(n)] for i in range(n)])
def scalar_of(A):
    E, k = A; n = len(E); c = E[0][0]
    if all(E[i][j] == (c if i == j else Z0) for i in range(n) for j in range(n)): return (c, k)
    return None
def mscal(c, A):  # c in Z[zeta]
    E, k = A; return normalise(tuple(tuple(zmul(c, x) for x in r) for r in E), k)

ZH = M([[(1,0,1,0), (1,0,1,0)], [(1,0,1,0), (-1,0,-1,0)]], 1)        # zeta H = ((1+i)/2)(1 1;1 -1)
H = M([[(0,1,0,-1), (0,1,0,-1)], [(0,1,0,-1), (0,-1,0,1)]], 1)       # H = ((zeta - zeta^3)/2)(1 1; 1 -1)
S = M([[Z1, Z0], [Z0, ZI]]); Sd = dagger(S)
I2 = ident(2)
CNOT01 = M([[Z1,Z0,Z0,Z0],[Z0,Z1,Z0,Z0],[Z0,Z0,Z0,Z1],[Z0,Z0,Z1,Z0]])  # control qubit 0 (left factor), target qubit 1
CNOT10 = M([[Z1,Z0,Z0,Z0],[Z0,Z0,Z0,Z1],[Z0,Z0,Z1,Z0],[Z0,Z1,Z0,Z0]])  # control qubit 1, target qubit 0

def gen_group(gens, limit=200000):
    seen = set(gens); frontier = list(gens)
    while frontier:
        nxt = []
        for g in frontier:
            for h in gens:
                gh = mmul(g, h)
                if gh not in seen:
                    seen.add(gh); nxt.append(gh)
                    if len(seen) > limit: raise RuntimeError('group larger than the limit')
        frontier = nxt
    return seen

def eighth_roots():
    return {normalise(((zpow(ZETA, k),),), 0) for k in range(8)}

def main():
    args = sys.argv[1:]; fault = args[args.index('--fault') + 1] if '--fault' in args else None
    n_ok = 0
    def check(c, m):
        nonlocal n_ok
        if not c: print('FAIL:', m); sys.exit(1)
        n_ok += 1
    # sanity of the number system
    check(zmul(ZETA, zpow(ZETA, 7)) == Z1 and zpow(ZETA, 4) == zneg(Z1), "zeta arithmetic")
    check(mmul(H, H) == I2 and mmul(ZH, ZH) == mscal(ZI, I2), "H^2 = 1 and (zetaH)^2 = i")
    # W1
    for n in range(1, 4):
        for p in range(n + 1):
            q = n - p
            T = None; Hn = None
            for k in range(n):
                f = S if k < p else Sd
                T = f if T is None else kron(T, f)
                Hn = H if Hn is None else kron(Hn, H)
            Mx = mmul(T, Hn); M3 = mmul(mmul(Mx, Mx), Mx)
            sc = scalar_of(M3)
            check(sc is not None and sc == (zpow(ZETA, p - q), 0), f"(S^p Sd^q H^n)^3 != zeta^(p-q) at (p,q)=({p},{q})")
    print("ok  W1: (S^p Sd^q H^(x)n)^3 = zeta^(p-q) 1 for all (p,q) with n <= 3, zeta = e^{i pi/4}")
    # W2
    G1 = gen_group([S, H])
    scal1 = {normalise(((sc[0],),), sc[1]) for g in G1 for sc in [scalar_of(g)] if sc}
    check(len(G1) == 192, f"|<S,H>| = {len(G1)}, expected 192")
    check(scal1 == eighth_roots(), f"scalars of <S,H> are not the eight eighth roots")
    zinvS = mscal(zpow(ZETA, 7), S); iH = mscal(ZI, H)
    G2O = gen_group([zinvS, iH])
    scal2O = {normalise(((sc[0],),), sc[1]) for g in G2O for sc in [scalar_of(g)] if sc}
    check(len(G2O) == 48, f"|<zeta^-1 S, iH>| = {len(G2O)}, expected 48")
    check(scal2O == {normalise(((Z1,),), 0), normalise(((zneg(Z1),),), 0)}, "scalars of 2O are not +-1")
    print("ok  W2: |<S,H>| = 192 with the 8 eighth roots as scalars; |<zeta^-1 S, iH>| = 48 with scalars +-1")
    # W3
    b = kron(ZH, S); one_H = kron(I2, ZH); one_S = kron(I2, S)
    c1, c2 = (CNOT10, CNOT01) if fault != 'CNOT' else (CNOT01, CNOT10)
    a = mmul(mmul(mmul(mmul(c1, one_H), c2), mmul(one_S, one_S)), one_H)
    Ea, ka = a
    monomial = ka == 0 and all(sum(1 for j in range(4) if Ea[i][j] != Z0) == 1 for i in range(4)) and \
        all(x in (Z0, ZI, zneg(ZI)) for r in Ea for x in r)
    comm = mmul(mmul(mmul(a, b), dagger(a)), dagger(b))
    check(monomial, "a is not monomial with entries +-i")
    check(scalar_of(comm) == (ZI, 0), f"a b a^-1 b^-1 != i 1: {comm}")
    print("ok  W3: a is monomial with entries +-i and a b a^-1 b^-1 = i 1 (so no cover with scalars +-1 only, LAB-038)")
    # W4
    gens = [kron(ZH, I2), kron(I2, ZH), kron(S, I2), kron(I2, S), CNOT01, CNOT10]
    if fault == 'DROPS': gens = [kron(ZH, I2), kron(I2, ZH), CNOT01, CNOT10]
    G2 = gen_group(gens, limit=100000)
    scal2 = {normalise(((sc[0],),), sc[1]) for g in G2 for sc in [scalar_of(g)] if sc}
    fourth = {normalise(((zpow(ZI, k),),), 0) for k in range(4)}
    check(len(G2) == 46080, f"|<zetaH,S,CNOT>| = {len(G2)}, expected 46080")
    check(scal2 == fourth, "scalars of the two-qubit group are not {1,i,-1,-i}")
    # commutator subgroup: H = <[x,y] for 40 fixed pseudo-random pairs x,y in G> lies in G'; if |G:H| = 2 then G/H is
    # abelian, so G' <= H, and H = G'.
    import random
    random.seed(20261021)
    Gl = sorted(G2)
    comms = []
    for _ in range(40):
        x = random.choice(Gl); y = random.choice(Gl)
        comms.append(mmul(mmul(mmul(x, y), dagger(x)), dagger(y)))
    D = gen_group(comms, limit=100000)
    check(len(G2) == 2 * len(D), f"|G| = {len(G2)} is not twice |H| = {len(D)}: H may be smaller than G'")
    check(len(D) == 23040 and mscal(ZI, ident(4)) in D, f"commutator subgroup: {len(D)} elements, expected 23040 with i 1")
    print("ok  W4: |<zetaH,S,CNOT>| = 46080, scalars {1,i,-1,-i}, commutator subgroup of order 23040 containing i 1")
    # W5: orbits of |000>
    def vec_orbit(gates):
        v0 = M([[Z1], [Z0], [Z0], [Z0], [Z0], [Z0], [Z0], [Z0]])
        seen = {v0}; frontier = [v0]
        while frontier:
            nxt = []
            for v in frontier:
                for g in gates:
                    w = mmul(g, v)
                    if w not in seen: seen.add(w); nxt.append(w)
            frontier = nxt
        return len(seen)
    I4 = ident(4)
    def three(g1, pos):
        parts = [I2, I2, I2]; parts[pos] = g1
        return kron(kron(parts[0], parts[1]), parts[2])
    cn = [kron(CNOT01, I2), kron(CNOT10, I2), kron(I2, CNOT01), kron(I2, CNOT10)]
    gates_z = [three(ZH, k) for k in range(3)] + [three(S, k) for k in range(3)] + cn
    gates_h = [three(H, k) for k in range(3)] + [three(S, k) for k in range(3)] + cn
    o1 = vec_orbit(gates_z); o2 = vec_orbit(gates_h)
    check(o1 == 4320 and o2 == 8640, f"orbits of |000>: {o1}, {o2}; expected 4320 and 8640")
    print("ok  W5: orbit of |000> under zetaH,S,CNOT has 4320 vectors, under H,S,CNOT 8640")
    print(f"ALL OK: {n_ok} checks")

if __name__ == '__main__':
    main()
