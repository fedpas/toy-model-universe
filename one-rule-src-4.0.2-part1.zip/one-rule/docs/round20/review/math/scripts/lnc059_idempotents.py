#!/usr/bin/env python3
# Review script (math referee, Oct 2026). Own 30-line bit-rule kernel; no atlas import.
"""lnc059_idempotents.py -- LNC-059: "the 2^w orthogonal idempotents are the finite shadow of the
spectral theorem (the idempotents follow; not computed)".  Here they are computed.

For every non-degenerate cell Cl(p,q) with 1 <= p+q <= 8 (44 cells; also n = 9 with --n 9):
  W1. a maximal totally singular subspace W of the label quadric Q(a) = [e_a^2 = -1] (labels closed under xor whose
      blades commute pairwise and square to +1) is found by an exhaustive depth-first search; its dimension w is the
      largest such dimension, and 2^w = s * N for Cl(p,q) = M_N(D)^s (the mod-8 type table).
  I1. with a basis u_1..u_w of W, the 2^w elements E_sigma = prod_k (1 + sigma_k e_{u_k})/2 (sigma in {+-1}^w) are
      idempotent (E^2 = E exactly, rational arithmetic), pairwise orthogonal (E_sigma E_tau = 0), and sum to 1.
  I2. each E_sigma is primitive: dim(E A E) = dim D (= 1, 2, 4 for D = R, C, H), computed as the exact trace of the
      idempotent map x -> E x E on the 2^n labels; and dim(A E) = tr L_E = 2^(n-w) = N * dim D, the dimension of a
      minimal left ideal.  So the E_sigma are a complete set of orthogonal primitive idempotents: A = (+) A E_sigma
      is the decomposition into 2^w = s*N minimal left ideals, the "finite spectral theorem" of LNC-059/CAND-083.
  I3. the signed blades v_T = prod_{k in T} e_{u_k} (T subset of the basis) satisfy v_T v_U = v_{T xor U} exactly
      (the group law; the restricted sign cocycle is a coboundary), so E_sigma = 2^-w sum_T sigma(T) v_T.
Faults (each must make the script exit 1):
  --fault SIGN     flips the sign of one basis blade inside one factor only: the product is no longer idempotent.
  --fault NONCOMM  replaces the last basis label by a label of square +1 that does not commute with the first:
                   E^2 != E.
  --fault WITT     claims w+1 for the Witt index: the search must contradict it.
Usage: python3 -I -B lnc059_idempotents.py [--n 8] [--fault NAME]
"""
import sys, itertools
from fractions import Fraction

# ---------------- bit-rule kernel ----------------
def popcount(x): return bin(x).count('1')

def npairs(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << i) - 1))
        i += 1
    return c

class BR:
    def __init__(self, eps):
        self.eps = tuple(eps); self.n = len(eps)
    def s(self, a, b):
        v = -1 if npairs(a, b) & 1 else 1
        m = a & b; i = 0
        while m:
            if m & 1: v *= self.eps[i]
            m >>= 1; i += 1
        return v
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                v = self.s(a, b)
                if v: out[a ^ b] = out.get(a ^ b, 0) + v * ca * cb
        return {k: v for k, v in out.items() if v != 0}
    def add(self, x, y, c=1):
        out = dict(x)
        for k, v in y.items(): out[k] = out.get(k, 0) + c * v
        return {k: v for k, v in out.items() if v != 0}
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)

# ---------------- type table (T4 / ABS) ----------------
def type_table(p, q):
    """(D, s, N) for Cl(p,q) = M_N(D)^s."""
    n = p + q; c = (p - q) % 8
    D, s = {0: ('R', 1), 1: ('R', 2), 2: ('R', 1), 3: ('C', 1), 4: ('H', 1), 5: ('H', 2), 6: ('H', 1), 7: ('C', 1)}[c]
    dD = {'R': 1, 'C': 2, 'H': 4}[D]
    N2 = (1 << n) // (s * dD)
    N = int(round(N2 ** 0.5)); assert N * N == N2
    return D, s, N

# ---------------- search for a maximal totally singular subspace ----------------
def max_ts_subspace(A):
    """Exhaustive DFS over bases (increasing labels) of subspaces of square-+1, pairwise commuting labels.
    Returns (w, basis) for a subspace of maximal dimension."""
    n = A.n; N = 1 << n
    good = [a for a in range(1, N) if A.sq(a) == 1]
    comm = {a: set(b for b in good if A.commute(a, b)) for a in good}
    best = [0, []]
    def dfs(basis, span, cands):
        if len(basis) > best[0]:
            best[0] = len(basis); best[1] = list(basis)
        for v in sorted(cands):
            if v in span: continue
            # keep increasing order on the smallest new element of the coset to prune repeats
            if basis and v < max(basis): continue
            newspan = span | {v ^ u for u in span}
            if any(A.sq(x) != 1 for x in newspan): continue
            newc = {c for c in cands if c in comm[v] and c not in newspan}
            dfs(basis + [v], newspan, newc)
    dfs([], {0}, set(good))
    return best[0], best[1]

def idempotents(A, basis, fault=None):
    w = len(basis)
    out = []
    for sigma in itertools.product((1, -1), repeat=w):
        E = {0: Fraction(1)}
        for k, (sg, u) in enumerate(zip(sigma, basis)):
            f = {0: Fraction(1, 2), u: Fraction(sg, 2)}
            if fault == 'SIGN' and k == 0 and sigma == (1,) * w:
                f = {0: Fraction(1, 2), u: Fraction(-sg, 2)}   # one factor re-signed: the family is no longer a partition
            E = A.mul(E, f)
        out.append((sigma, E))
    return out

def trace_L(A, x):
    """trace of left multiplication by x on the 2^n labels = 2^n * scalar part"""
    return (1 << A.n) * x.get(0, 0)

def dim_EAE(A, E):
    """trace of the idempotent map x -> E x E on the label basis (exact)"""
    t = Fraction(0)
    for a in range(1 << A.n):
        y = A.mul(A.mul(E, {a: 1}), E)
        t += y.get(a, 0)
    return t

def main():
    args = sys.argv[1:]
    nmax = 8; fault = None
    if '--n' in args: nmax = int(args[args.index('--n') + 1])
    if '--fault' in args: fault = args[args.index('--fault') + 1]
    nchecks = 0
    def check(cond, msg):
        nonlocal nchecks
        if not cond:
            print('FAIL:', msg); sys.exit(1)
        nchecks += 1
    cells = [(p, n - p) for n in range(1, nmax + 1) for p in range(n, -1, -1)]
    for (p, q) in cells:
        n = p + q
        A = BR([1] * p + [-1] * q)
        D, s, N = type_table(p, q); dD = {'R': 1, 'C': 2, 'H': 4}[D]
        w, basis = max_ts_subspace(A)
        if fault == 'WITT': w_claim = w + 1
        else: w_claim = w
        check((1 << w_claim) == s * N, f"Cl({p},{q}): 2^w = {1 << w_claim} but s*N = {s*N} (w={w_claim})")
        if fault == 'NONCOMM' and w >= 2:
            good = [a for a in range(1, 1 << n) if A.sq(a) == 1 and not A.commute(a, basis[0])]
            basis = basis[:-1] + [good[0]]
        # group law on the signed blades
        span = {0: {0: 1}}
        for u in basis:
            new = {}
            for T, v in span.items():
                new[T] = v
                new[T ^ u] = A.mul(v, {u: 1})
            span = new
        for T, vT in span.items():
            for U, vU in span.items():
                check(A.mul(vT, vU) == span[T ^ U], f"Cl({p},{q}): group law fails at T={T},U={U}")
        Es = idempotents(A, basis, fault)
        for sigma, E in Es:
            check(A.mul(E, E) == E, f"Cl({p},{q}): E_sigma^2 != E_sigma for sigma={sigma}")
            check(trace_L(A, E) == (1 << (n - w)) and (1 << (n - w)) == N * dD,
                  f"Cl({p},{q}): dim(A E) = {trace_L(A,E)}, expected N*dimD = {N*dD}")
            check(dim_EAE(A, E) == dD, f"Cl({p},{q}): dim(E A E) = {dim_EAE(A,E)}, expected dim D = {dD}")
        for i in range(len(Es)):
            for j in range(i + 1, len(Es)):
                check(A.mul(Es[i][1], Es[j][1]) == {}, f"Cl({p},{q}): E_i E_j != 0")
        tot = {}
        for _, E in Es: tot = A.add(tot, E)
        check(tot == {0: Fraction(1)}, f"Cl({p},{q}): sum of E_sigma != 1")
        print(f"ok  Cl({p},{q}) = M_{N}({D})^{s}: w = {w}, 2^w = {1<<w} = s*N, {len(Es)} primitive orthogonal idempotents, "
              f"dim(AE) = {N*dD}, dim(EAE) = {dD}, basis = {basis}")
    print(f"ALL OK: {nchecks} checks on {len(cells)} cells (n <= {nmax})")

if __name__ == '__main__':
    main()
