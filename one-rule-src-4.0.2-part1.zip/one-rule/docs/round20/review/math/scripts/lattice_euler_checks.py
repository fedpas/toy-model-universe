#!/usr/bin/env python3
# Review script (math referee, Oct 2026). Exact integer / rational arithmetic; no atlas import.
"""lattice_euler_checks.py -- independent recomputation of small lattice and quiver facts quoted on the
steps/category, shapes and clock pages (T8, T9, T10, LNC-045, LNC-058, LAB-035).

 L1. T10 (1): det E_n = 9 - n for n = 3..12 (Cartan matrix of the tree T_{2,3,n-3}), exact Bareiss elimination.
 L2. LNC-045 / T9: on E_n/2E_n with q(x) = x.x/2 mod 2 the number of classes with q = 1 is 4, 10, 20, 36, 64, 120 for
     n = 3..8, equal to the number of labels of Cl(n,0) with e_a^2 = -1 (sum of C(n,k) over k = 2,3 mod 4); the
     radical of the mod-2 bilinear form has dimension 1 for odd n and 0 for even n (n = 3..8), and q is 1 on the
     radical for n = 3, 7 and 0 for n = 5 (so n = 7 counts 63 root classes plus the radical class: 64).
 L3. T9 (f): A6/2A6 has 28 non-singular classes (Arf 0, plus type) and E6/2E6 has 36 (Arf 1, minus type).
 L4. T8 / LNC-058: the symmetrised Euler form (C^-1 + C^-T) of the incidence algebra of the n-cube has inertia
     (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0..5 (exact rational LDL^T), and at n = 3 the
     Tits form chi + x_0 x_7 has inertia (6,1,1) and the Coxeter matrix Phi = -C^-T C has characteristic polynomial
     (x-1)^2 (x^2+x+1)^3 (exact Faddeev-LeVerrier).
 L5. LAB-035 / T14: the number of self-dual codes of length n all of whose words have square +1 in Cl(p,q) equals
     prod_{i=0}^{n/2-2} (2^i + 1) when p = q mod 8 and 0 otherwise, for every (p,q) with p+q <= 8 (enumeration of all
     self-dual binary codes, which number prod_{i=1}^{n/2-1}(2^i+1): 1, 3, 15, 135 for n = 2, 4, 6, 8).
Faults: --fault DET (expects det = 8 - n), --fault EULER (expects (6,1,1) for the Euler form at n = 3),
        --fault CODES (expects a code in Cl(4,0)).
Usage: python3 -I -B lattice_euler_checks.py [--fault NAME]
"""
import sys, itertools
from fractions import Fraction as Fr
from math import comb

def cartan_T(p, q, r):
    """Cartan matrix of the tree T_{p,q,r}: three arms of lengths p-1, q-1, r-1 from a central node.
    T_{2,3,0} is read as E_3 = A_2 + A_1 (the del Pezzo convention, three nodes, det 6)."""
    if r == 0:
        return [[2, -1, 0], [-1, 2, 0], [0, 0, 2]]
    n = p + q + r - 2
    A = [[0] * n for _ in range(n)]
    for i in range(n): A[i][i] = 2
    idx = 1; edges = []
    for arm in (p - 1, q - 1, r - 1):
        prev = 0
        for _ in range(arm):
            edges.append((prev, idx)); prev = idx; idx += 1
    for a, b in edges: A[a][b] = A[b][a] = -1
    return A

def det_bareiss(M):
    M = [row[:] for row in M]; n = len(M); sign = 1; prev = 1
    for k in range(n - 1):
        if M[k][k] == 0:
            sw = next((i for i in range(k + 1, n) if M[i][k] != 0), None)
            if sw is None: return 0
            M[k], M[sw] = M[sw], M[k]; sign = -sign
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                M[i][j] = (M[i][j] * M[k][k] - M[i][k] * M[k][j]) // prev
        prev = M[k][k]
    return sign * M[n - 1][n - 1]

def mod2_form_counts(G):
    """for a Gram matrix G of an even lattice: number of classes mod 2 with q = x.x/2 odd, radical dim, q on radical"""
    n = len(G); N = 1 << n
    def qv(x):
        xs = [(x >> i) & 1 for i in range(n)]
        s = sum(G[i][j] * xs[i] * xs[j] for i in range(n) for j in range(n))
        return (s // 2) % 2
    def bil(x, y):
        xs = [(x >> i) & 1 for i in range(n)]; ys = [(y >> i) & 1 for i in range(n)]
        return sum(G[i][j] * xs[i] * ys[j] for i in range(n) for j in range(n)) % 2
    count1 = sum(1 for x in range(N) if qv(x) == 1)
    rad = [x for x in range(N) if all(bil(x, 1 << i) == 0 for i in range(n))]
    qrad = {qv(x) for x in rad if x != 0}
    import math
    return count1, int(round(math.log2(len(rad)))), qrad

def inertia(S):
    """inertia (pos, neg, zero) of a symmetric rational matrix by exact symmetric elimination"""
    n = len(S); A = [[Fr(x) for x in row] for row in S]; pos = neg = zero = 0
    used = [False] * n
    for _ in range(n):
        # find a non-zero diagonal pivot
        k = next((i for i in range(n) if not used[i] and A[i][i] != 0), None)
        if k is None:
            # look for an off-diagonal non-zero among unused rows; if none, the rest is zero
            pair = next(((i, j) for i in range(n) if not used[i] for j in range(n) if not used[j] and A[i][j] != 0), None)
            if pair is None:
                zero += sum(1 for i in range(n) if not used[i]); break
            i, j = pair
            # replace row/col i by i + j (symmetric), then A[i][i] = 2 A[i][j] + A[j][j] != 0 unless ... (A[j][j] = 0 here)
            for t in range(n): A[i][t] += A[j][t]
            for t in range(n): A[t][i] += A[t][j]
            k = i
            if A[k][k] == 0:
                for t in range(n): A[i][t] -= 2 * A[j][t]
                for t in range(n): A[t][i] -= 2 * A[t][j]
                k = i
        d = A[k][k]
        if d > 0: pos += 1
        else: neg += 1
        used[k] = True
        for i in range(n):
            if i == k or used[i]: continue
            f = A[i][k] / d
            if f == 0: continue
            for j in range(n): A[i][j] -= f * A[k][j]
            for j in range(n): A[j][i] = A[i][j]
    return pos, neg, zero

def charpoly(Mx):
    """Faddeev-LeVerrier: coefficients of det(xI - M), highest first"""
    n = len(Mx); M = [[Fr(x) for x in r] for r in Mx]
    I = [[Fr(int(i == j)) for j in range(n)] for i in range(n)]
    coeffs = [Fr(1)]; Mk = [[Fr(0)] * n for _ in range(n)]
    for k in range(1, n + 1):
        # Mk = M (M_{k-1} + c_{k-1} I)
        B = [[Mk[i][j] + coeffs[-1] * I[i][j] for j in range(n)] for i in range(n)]
        Mk = [[sum(M[i][t] * B[t][j] for t in range(n)) for j in range(n)] for i in range(n)]
        c = -sum(Mk[i][i] for i in range(n)) / k
        coeffs.append(c)
    return coeffs

def polymul(a, b):
    out = [Fr(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): out[i + j] += x * y
    return out

def cube_cartan(n):
    C = [[1]]
    for _ in range(n):
        C = [[C[i // 2][j // 2] * [[1, 1], [0, 1]][i % 2][j % 2] for j in range(2 * len(C))] for i in range(2 * len(C))]
    return C

def inverse(Mx):
    n = len(Mx); A = [[Fr(x) for x in r] + [Fr(int(i == j)) for j in range(n)] for i, r in enumerate(Mx)]
    for c in range(n):
        p = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[p] = A[p], A[c]
        d = A[c][c]; A[c] = [x / d for x in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return [r[n:] for r in A]

# ---- codes ----
def popcount(x): return bin(x).count('1')
def npairs(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << i) - 1))
        i += 1
    return c
def square_sign(a, eps):
    v = -1 if npairs(a, a) & 1 else 1
    for i, e in enumerate(eps):
        if a >> i & 1: v *= e
    return v

def selfdual_codes(n):
    """all self-dual binary codes of length n (as frozensets of words), by extending self-orthogonal subspaces"""
    N = 1 << n; k = n // 2
    even = [x for x in range(1, N) if popcount(x) % 2 == 0]
    codes = set()
    def dfs(basis, span, cands):
        if len(basis) == k:
            codes.add(frozenset(span)); return
        for v in cands:
            if v in span or (basis and v < basis[-1]): continue
            if any(popcount(v & u) % 2 for u in basis): continue
            newspan = span | {v ^ u for u in span}
            dfs(basis + [v], newspan, [c for c in cands if c not in newspan])
    dfs([], {0}, even)
    return codes

def main():
    args = sys.argv[1:]; fault = args[args.index('--fault') + 1] if '--fault' in args else None
    n_ok = 0
    def check(c, m):
        nonlocal n_ok
        if not c: print('FAIL:', m); sys.exit(1)
        n_ok += 1
    # L1
    for n in range(3, 13):
        A = cartan_T(2, 3, n - 3)
        want = 9 - n if fault != 'DET' else 8 - n
        check(det_bareiss(A) == want, f"det E_{n} = {det_bareiss(A)}, expected {want}")
    print("ok  L1: det E_n = 9 - n for n = 3..12")
    # L2
    want_counts = {3: 4, 4: 10, 5: 20, 6: 36, 7: 64, 8: 120}
    for n in range(3, 9):
        A = cartan_T(2, 3, n - 3)
        c1, raddim, qrad = mod2_form_counts(A)
        lab = sum(comb(n, k) for k in range(n + 1) if k % 4 in (2, 3))
        check(c1 == want_counts[n] == lab, f"E_{n}/2E_{n}: {c1} classes with q=1, expected {want_counts[n]} = {lab} labels of square -1 in Cl({n},0)")
        check(raddim == (n % 2), f"E_{n}: radical dimension {raddim}")
        if n in (3, 7): check(qrad == {1}, f"E_{n}: q on the radical should be 1")
        if n == 5: check(qrad == {0}, "E_5: q on the radical should be 0")
    print("ok  L2: q=1 classes of E_n/2E_n = 4, 10, 20, 36, 64, 120 = labels of square -1 of Cl(n,0); radicals as stated")
    # L3
    A6 = [[2 if i == j else (-1 if abs(i - j) == 1 else 0) for j in range(6)] for i in range(6)]
    cA, _, _ = mod2_form_counts(A6); cE, _, _ = mod2_form_counts(cartan_T(2, 3, 3))
    check(cA == 28 and cE == 36, f"A6: {cA} (expected 28, plus type), E6: {cE} (expected 36, minus type)")
    print("ok  L3: A6/2A6 has 28 non-singular classes (Arf 0), E6/2E6 has 36 (Arf 1)")
    # L4
    want = {0: (1, 0, 0), 1: (2, 0, 0), 2: (4, 0, 0), 3: (6, 0, 2), 4: (14, 2, 0), 5: (20, 2, 10)}
    if fault == 'EULER': want[3] = (6, 1, 1)
    for n in range(6):
        C = cube_cartan(n); Ci = inverse(C); N = len(C)
        Sym = [[Ci[i][j] + Ci[j][i] for j in range(N)] for i in range(N)]
        inr = inertia(Sym)
        check(inr == want[n], f"n = {n}: Euler form inertia {inr}, expected {want[n]}")
        if n == 3:
            T = [row[:] for row in Sym]; T[0][7] += 1; T[7][0] += 1   # Tits form = chi + x_0 x_7 (symmetrised: +1 at (0,7),(7,0))
            check(inertia(T) == (6, 1, 1), f"Tits form inertia {inertia(T)}")
            # Coxeter matrix Phi = -C^-T C  (convention: Phi = -C^-T C or its transpose; both have the same char poly)
            CiT = [[Ci[j][i] for j in range(N)] for i in range(N)]
            Phi = [[-sum(CiT[i][t] * C[t][j] for t in range(N)) for j in range(N)] for i in range(N)]
            cp = charpoly(Phi)
            target = polymul(polymul([Fr(1), Fr(-1)], [Fr(1), Fr(-1)]), [Fr(1)])
            for _ in range(3): target = polymul(target, [Fr(1), Fr(1), Fr(1)])
            check(cp == target, f"Coxeter polynomial at n = 3: {cp}, expected (x-1)^2 (x^2+x+1)^3")
    print("ok  L4: Euler-form inertias (1,0,0),(2,0,0),(4,0,0),(6,0,2),(14,2,0),(20,2,10); Tits (6,1,1) and Coxeter (x-1)^2(x^2+x+1)^3 at n = 3")
    # L5
    allcodes = {n: selfdual_codes(n) for n in (2, 4, 6, 8)}
    want_total = {2: 1, 4: 3, 6: 15, 8: 135}
    for n, cs in allcodes.items():
        check(len(cs) == want_total[n], f"length {n}: {len(cs)} self-dual codes, expected {want_total[n]}")
    for n in (2, 4, 6, 8):
        for p in range(n + 1):
            q = n - p; eps = [1] * p + [-1] * q
            good = sum(1 for C in allcodes[n] if all(square_sign(a, eps) == 1 for a in C))
            if (p - q) % 8 == 0:
                exp = 1
                for i in range(n // 2 - 1): exp *= (2 ** i + 1)
            else:
                exp = 0
            if fault == 'CODES' and (p, q) == (4, 0): exp = 1
            check(good == exp, f"Cl({p},{q}): {good} self-dual codes with all squares +1, expected {exp}")
    print("ok  L5: codes of labels with all squares +1: prod_{i=0}^{n/2-2}(2^i+1) when p = q mod 8 (1, 2, 6, 30 at (1,1),(2,2),(3,3),(4,4)/(8,0)/(0,8)), none otherwise, n <= 8")
    print(f"ALL OK: {n_ok} checks")

if __name__ == '__main__':
    main()
