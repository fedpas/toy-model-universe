#!/usr/bin/env python3
# Review script (math referee, Oct 2026). Own bit-rule kernel; exact arithmetic; no atlas import.
"""type_table_consequences.py -- consequences of the mod-8 type table quoted on the rule, cells, clock and mirrors
pages, recomputed from the table (and, where cheap, from the labels).

 C1. GEN-011: for every ordered pair of non-degenerate cells with n1 + n2 <= 8 (495 pairs), the ungraded tensor
     product Cl(p,q) (x) Cl(p',q') has the type of Cl(p+p',q+q') (the graded product) exactly when one of the two
     clocks is 0 or 4 mod 8 (235 pairs agree, 260 differ).  The ungraded type is computed from the table with
     R(x)D = D, C(x)C = C+C, C(x)H = M_2(C), H(x)H = M_4(R); the mechanism is written in the review (section C).
 C2. T4 (iv): nu = sum_a e_a^2 = Re((1-i)(1+i)^p(1-i)^q) = s N ind(D), ind = +1, 0, -2, for p+q <= 10 (from the labels for
     p+q <= 8, from the closed forms for 9, 10).
 C3. GEN-022 / ATY-001 / ATY-026: the ABS groups A(p,q) = coker(N(Cl(p+1,q+1)) -> N(Cl(p+1,q))) from the type table
     alone: for s_target = 1 the map is multiplication by d'/d on each generator (d, d' the real dimensions of the
     irreducibles), for s_target = 2 the generator goes to (d'/2d, d'/2d) because the two simple modules are exchanged
     by the grade automorphism, which is inner in the larger cell (conjugation by the extra generator).  Result:
     Z, 0, 0, 0, Z, 0, Z2, Z2 by the clock c = p - q mod 8 = KO^{p-q}(pt), for all 45 cells with p+q <= 8.
 C4. INP-019: reversion and Clifford conjugation of Cl(p,q), n <= 10, as anti-involutions: the dimensions of their
     fixed spaces and the inertias of the trace forms <x tau(x)>_0 agree exactly when n = 0 mod 4 and p, q >= 1 (and trivially at n = 0)
     (necessary for an algebra automorphism intertwining them); and for n = 0 mod 4 with q odd the automorphism
     e_i -> e_i I (I the volume element, I^2 = -1) intertwines them on every label (sufficient).
 C5. CAND-058: the centre of Cl(p,q,r) has dimension 2^{r-1} + [n odd] for r >= 1 and 1 + [n odd] for r = 0, and the
     super-centre has dimension 2^r: from the labels for every (p,q,r) with n <= 6 (84 cells).
Faults: --fault CLOCK (expects agreement in C1 when one clock is 0 or 2), --fault IND (uses ind(H) = -1),
        --fault KO (expects Z2 at clock 3).
Usage: python3 -I -B type_table_consequences.py [--fault NAME]
"""
import sys
from fractions import Fraction as Fr

def popcount(x): return bin(x).count('1')
def npairs(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << i) - 1))
        i += 1
    return c
class BR:
    def __init__(self, eps): self.eps = tuple(eps); self.n = len(eps)
    def s(self, a, b):
        v = -1 if npairs(a, b) & 1 else 1
        m = a & b; i = 0
        while m:
            if m & 1: v *= self.eps[i]
            m >>= 1; i += 1
        return v
    def sq(self, a): return self.s(a, a)
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                v = self.s(a, b)
                if v: out[a ^ b] = out.get(a ^ b, 0) + v * ca * cb
        return {k: v for k, v in out.items() if v != 0}

TYPE = {0: ('R', 1), 1: ('R', 2), 2: ('R', 1), 3: ('C', 1), 4: ('H', 1), 5: ('H', 2), 6: ('H', 1), 7: ('C', 1)}
DIMD = {'R': 1, 'C': 2, 'H': 4}
def ttype(p, q):
    D, s = TYPE[(p - q) % 8]; n = p + q
    N2 = (1 << n) // (s * DIMD[D]); N = int(round(N2 ** 0.5)); assert N * N == N2
    return D, s, N

def tensor_type(t1, t2):
    """type of (M_N(D))^s (x) (M_N'(D'))^s' as a multiset-free descriptor (D'', s'', N'')"""
    (D1, s1, N1), (D2, s2, N2) = t1, t2
    table = {('R', 'R'): ('R', 1, 1), ('R', 'C'): ('C', 1, 1), ('R', 'H'): ('H', 1, 1), ('C', 'R'): ('C', 1, 1),
             ('H', 'R'): ('H', 1, 1), ('C', 'C'): ('C', 2, 1), ('C', 'H'): ('C', 1, 2), ('H', 'C'): ('C', 1, 2),
             ('H', 'H'): ('R', 1, 4)}
    D, s, N = table[(D1, D2)]
    return (D, s * s1 * s2, N * N1 * N2)

def main():
    args = sys.argv[1:]; fault = args[args.index('--fault') + 1] if '--fault' in args else None
    n_ok = 0
    def check(c, m):
        nonlocal n_ok
        if not c: print('FAIL:', m); sys.exit(1)
        n_ok += 1
    # C1
    cells = [(p, n - p) for n in range(0, 9) for p in range(n + 1)]
    agree = differ = 0
    special = {0, 4} if fault != 'CLOCK' else {0, 2}
    for (p, q) in cells:
        for (p2, q2) in cells:
            if p + q + p2 + q2 > 8: continue
            ung = tensor_type(ttype(p, q), ttype(p2, q2))
            gr = ttype(p + p2, q + q2)
            same = (ung == gr)
            pred = ((p - q) % 8 in special) or ((p2 - q2) % 8 in special)
            check(same == pred, f"({p},{q})x({p2},{q2}): ungraded {ung}, graded {gr}, agree={same}, predicted {pred}")
            agree += same; differ += (not same)
    check((agree, differ) == (235, 260), f"agree/differ = {agree}/{differ}, expected 235/260")
    print("ok  C1: ungraded (x) has the graded type iff one clock is 0 or 4 mod 8: 235 agree, 260 differ (495 pairs)")
    # C2
    def gauss_count(p, q):
        z = complex(1, 1) ** p * complex(1, -1) ** q * complex(1, -1)
        return int(round(z.real))
    for n in range(0, 11):
        for p in range(n + 1):
            q = n - p
            D, s, N = ttype(p, q)
            ind = {'R': 1, 'C': 0, 'H': -2 if fault != 'IND' else -1}[D]
            if n <= 8:
                A = BR([1] * p + [-1] * q)
                nu = sum(A.sq(a) for a in range(1 << n))
                check(nu == gauss_count(p, q), f"Cl({p},{q}): label count {nu} != Re((1-i)S) = {gauss_count(p,q)}")
            check(gauss_count(p, q) == s * N * ind, f"Cl({p},{q}): Re((1-i)S) = {gauss_count(p,q)} != sN ind(D) = {s*N*ind}")
    print("ok  C2: sum_a e_a^2 = Re((1-i)(1+i)^p(1-i)^q) = s N ind(D) for p+q <= 10 (labels for p+q <= 8)")
    # C3
    want = {0: 'Z', 1: '0', 2: '0', 3: '0', 4: 'Z', 5: '0', 6: 'Z2', 7: 'Z2'}
    if fault == 'KO': want[3] = 'Z2'
    for n in range(0, 9):
        for p in range(n + 1):
            q = n - p
            Dt, st, Nt = ttype(p + 1, q); dt = Nt * DIMD[Dt]           # target: modules of Cl(p+1,q) (graded Cl(p,q)-modules)
            Ds, ss, Ns = ttype(p + 1, q + 1); ds = Ns * DIMD[Ds]       # source: modules of Cl(p+1,q+1)
            ratio = Fr(ds, dt)
            if st == 1:
                # Z^{ss} -> Z, each generator -> ratio (an integer)
                check(ratio.denominator == 1, "non-integral restriction multiplicity")
                m = int(ratio); coker = 'Z' if m == 0 else ('0' if m == 1 else f'Z{m}')
            else:
                # Z^{ss} -> Z^2, each generator -> (ratio/2, ratio/2)
                half = ratio / 2
                check(half.denominator == 1, "non-integral half multiplicity")
                h = int(half)
                coker = 'Z' if h == 1 else f'Z+Z{h}'     # image generated by (h,h): coker = Z (+) Z/h
            c = (p - q) % 8
            check(coker == want[c], f"A({p},{q}) = {coker}, expected {want[c]} at clock {c}")
    print("ok  C3: ABS cokernels from the type table: Z, 0, 0, 0, Z, 0, Z2, Z2 by the clock, p+q <= 8 (KO^{p-q}(pt))")
    # C4
    def inv_data(A, kind):
        n = A.n; fix = 0; pos = neg = 0
        for a in range(1 << n):
            k = popcount(a)
            sgn = (-1) ** (k * (k - 1) // 2) if kind == 'rev' else (-1) ** (k * (k + 1) // 2)
            if sgn == 1: fix += 1
            t = sgn * A.sq(a)   # e_a tau(e_a) = sgn * e_a^2: the trace form <x tau(x)>_0 is diagonal on labels
            if t == 1: pos += 1
            else: neg += 1
        return (fix, pos, neg)
    for n in range(0, 11):
        for p in range(n + 1):
            q = n - p; A = BR([1] * p + [-1] * q)
            same = inv_data(A, 'rev') == inv_data(A, 'conj')
            pred = (n == 0) or ((n % 4 == 0) and p >= 1 and q >= 1)   # at n = 0 both involutions are the identity
            check(same == pred, f"Cl({p},{q}): invariants agree={same}, predicted {pred}: {inv_data(A,'rev')} vs {inv_data(A,'conj')}")
            if n % 4 == 0 and q % 2 == 1 and n <= 8:
                F = (1 << n) - 1
                check(A.sq(F) == -1, f"Cl({p},{q}): I^2 should be -1")
                # phi(e_a) = e_a I^{|a|} up to the product order: compute phi on labels as the product of e_i I
                gens = [A.mul({1 << i: 1}, {F: 1}) for i in range(n)]
                def phi(a):
                    out = {0: 1}
                    for i in range(n):
                        if a >> i & 1: out = A.mul(out, gens[i])
                    return out
                def rev_sign(a): k = popcount(a); return (-1) ** (k * (k - 1) // 2)
                def conj_sign(a): k = popcount(a); return (-1) ** (k * (k + 1) // 2)
                for a in range(1 << n):
                    img = phi(a)
                    # reversion applied to phi(e_a): rev is linear, acts on label b by rev_sign(b)
                    lhs = {b: rev_sign(b) * c for b, c in img.items()}
                    rhs = {b: conj_sign(a) * c for b, c in img.items()}
                    check(lhs == rhs, f"Cl({p},{q}): rev(phi(e_a)) != phi(conj(e_a)) at a={a}")
    print("ok  C4: reversion ~ conjugation invariants agree iff n = 0 mod 4 and p,q >= 1 (n <= 10); e_i -> e_i I intertwines them for q odd (n <= 8)")
    # C5
    for n in range(0, 7):
        for p in range(n + 1):
            for q in range(n - p + 1):
                r = n - p - q
                A = BR([1] * p + [-1] * q + [0] * r)
                def central(a):
                    return all(A.mul({a: 1}, {1 << i: 1}) == A.mul({1 << i: 1}, {a: 1}) for i in range(n))
                def supercentral(a):
                    k = popcount(a)
                    return all(A.mul({a: 1}, {1 << i: 1}) == {bb: ((-1) ** k) * c for bb, c in A.mul({1 << i: 1}, {a: 1}).items()} for i in range(n))
                cz = sum(1 for a in range(1 << n) if central(a))
                sz = sum(1 for a in range(1 << n) if supercentral(a))
                wantc = (2 ** (r - 1) if r >= 1 else 1) + (n % 2)
                check(cz == wantc and sz == 2 ** r, f"Cl({p},{q},{r}): centre {cz} (expected {wantc}), super-centre {sz} (expected {2**r})")
    print("ok  C5: dim centre = 2^(r-1) + [n odd] (r >= 1), 1 + [n odd] (r = 0); dim super-centre = 2^r, all cells n <= 6")
    print(f"ALL OK: {n_ok} checks")

if __name__ == '__main__':
    main()
