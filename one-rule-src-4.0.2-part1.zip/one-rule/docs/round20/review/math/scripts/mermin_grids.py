#!/usr/bin/env python3
# Review script (math referee, Oct 2026). Own bit-rule kernel; no atlas import.
"""mermin_grids.py -- the staged LNS-038 edit, CAND-144 and T11 (4), recomputed independently.

A Mermin grid in a cell is a 3 x 3 array of nine distinct non-zero labels whose blades square to +1, whose three
rows and three columns are commuting triples with product +-1 (the three labels of a line xor to 0), and whose six
line signs multiply to -1.  A grid is fixed by its four corner entries a11, a12, a21, a22 (the rest are xors).
Checks:
 G1. For every cell Cl(p,q) with 1 <= p+q <= 8 (44 cells) an exhaustive search over grids built from square-+1 labels
     decides whether a Mermin grid exists.  Expected (staged LNS-038 / check_T11 4c): none exactly in the 14 cells
     p+q <= 3, (4,0), (1,3), (0,4), (5,0), (1,4); one in the other 30.
 G2. In every cell with a grid, no +-1 assignment to the nine blades respects the six lines (512 tried) -- the
     parity argument: the product of the six line signs is -1 while every blade appears in one row and one column.
 G3. In every cell with 1 <= p+q <= 8, the system v(a)v(b)v(a^b) = sign(e_a e_b e_{a^b}) over ALL commuting triples
     of square-+1 blades is solvable (F2 elimination) exactly in the 14 cells without a grid (staged 4d).
 G4. CAND-144: with e1 = X(x)1, e2 = Z(x)1, e3 = iY(x)X, e4 = iY(x)Z (real 4x4), the nine square-+1 blades of Cl(2,2)
     are, up to sign, Mermin's nine operators {X1, 1X, XX; 1Z, Z1, ZZ; XZ, ZX, YY} and its six lines are the rows and
     columns of his square.
 G5. T11 (4): in Cl(2,2) the product of the six line signs stays -1 under all 512 re-signings of the nine blades.
Faults: --fault PARITY (looks for grids whose line-sign product is +1 instead: G2 then fails, an assignment exists),
        --fault LIST (expects a grid in (1,3)), --fault MATRIX (uses e3 = Y(x)X with a real Y: not a representation).
Usage: python3 -I -B mermin_grids.py [--fault NAME]
"""
import sys, itertools

def popcount(x): return bin(x).count('1')
def npairs(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << i) - 1))
        i += 1
    return c

class BR:
    def __init__(self, eps): self.eps = tuple(eps); self.n = len(eps)
    def s(self, a, b):
        v = -1 if npairs(a, b) & 1 else 1
        m = a & b; i = 0
        while m:
            if m & 1: v *= self.eps[i]
            m >>= 1; i += 1
        return v
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)
    def triple_sign(self, a, b, c):
        """sign of e_a e_b e_c when a^b^c = 0 and the three commute"""
        s1 = self.s(a, b); return s1 * self.s(a ^ b, c)

NO_GRID = {(1, 0), (0, 1), (2, 0), (1, 1), (0, 2), (3, 0), (2, 1), (1, 2), (0, 3), (4, 0), (1, 3), (0, 4), (5, 0), (1, 4)}

def find_grid(A, parity_fault=False):
    n = A.n; N = 1 << n
    good = [a for a in range(1, N) if A.sq(a) == 1]
    gs = set(good)
    comm = {a: [b for b in good if b != a and A.commute(a, b)] for a in good}
    def line_ok(a, b):
        c = a ^ b
        return c in gs and c != a and c != b
    for a11 in good:
        for a12 in comm[a11]:
            if not line_ok(a11, a12): continue
            a13 = a11 ^ a12
            for a21 in comm[a11]:
                if a21 in (a12, a13): continue
                if not line_ok(a11, a21): continue
                a31 = a11 ^ a21
                for a22 in comm[a12]:
                    if a22 not in comm[a21] or a22 in (a11, a13, a31): continue
                    if not line_ok(a12, a22) or not line_ok(a21, a22): continue
                    a23 = a21 ^ a22; a32 = a12 ^ a22; a33 = a11 ^ a12 ^ a21 ^ a22
                    cells = [a11, a12, a13, a21, a22, a23, a31, a32, a33]
                    if len(set(cells)) != 9 or a33 not in gs: continue
                    rows = [(a11, a12, a13), (a21, a22, a23), (a31, a32, a33)]
                    cols = [(a11, a21, a31), (a12, a22, a32), (a13, a23, a33)]
                    lines = rows + cols
                    if not all(A.commute(x, y) for L in lines for x, y in itertools.combinations(L, 2)): continue
                    prod = 1
                    for L in lines: prod *= A.triple_sign(*L)
                    if (prod == 1) if parity_fault else (prod == -1):
                        return cells, lines
    return None

def assignment_exists(cells, lines, A):
    for vals in itertools.product((1, -1), repeat=9):
        v = dict(zip(cells, vals))
        if all(v[a] * v[b] * v[c] == A.triple_sign(a, b, c) for a, b, c in lines):
            return True
    return False

def all_triples_solvable(A):
    """F2 elimination for v(a)v(b)v(a^b) = sign over every commuting triple of square-+1 blades."""
    n = A.n; N = 1 << n
    good = [a for a in range(1, N) if A.sq(a) == 1]
    idx = {a: i for i, a in enumerate(good)}
    rows = []
    for a, b in itertools.combinations(good, 2):
        c = a ^ b
        if c in idx and c > b and A.commute(a, b):
            sgn = A.triple_sign(a, b, c)
            # x_a + x_b + x_c = [sgn == -1] over F2, x in F2 with v = (-1)^x
            vec = (1 << idx[a]) | (1 << idx[b]) | (1 << idx[c])
            rows.append((vec, 1 if sgn == -1 else 0))
    # Gaussian elimination over F2 on (vec, rhs)
    pivots = {}
    for vec, rhs in rows:
        while vec:
            piv = vec.bit_length() - 1
            if piv in pivots:
                pv, pr = pivots[piv]; vec ^= pv; rhs ^= pr
            else:
                pivots[piv] = (vec, rhs); break
        if vec == 0 and rhs == 1:
            return False
    return True

# ---- CAND-144: real 4x4 matrices ----
def kron(A, B):
    return [[A[i // 2][j // 2] * B[i % 2][j % 2] for j in range(4)] for i in range(4)]
def mmul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def meq(A, B): return all(A[i][j] == B[i][j] for i in range(4) for j in range(4))
def mneg(A): return [[-x for x in r] for r in A]
I2 = [[1, 0], [0, 1]]; X = [[0, 1], [1, 0]]; Z = [[1, 0], [0, -1]]; iY = [[0, 1], [-1, 0]]  # iY = [[0,1],[-1,0]] (real)
YY = kron(mneg(iY), iY)  # Y(x)Y = -(iY)(x)(iY)

def main():
    args = sys.argv[1:]; fault = args[args.index('--fault') + 1] if '--fault' in args else None
    nchecks = 0
    def check(c, m):
        nonlocal nchecks
        if not c: print('FAIL:', m); sys.exit(1)
        nchecks += 1
    expected_none = set(NO_GRID)
    if fault == 'LIST': expected_none.discard((1, 3))
    cells = [(p, n - p) for n in range(1, 9) for p in range(n, -1, -1)]
    with_grid = []; without = []
    for p, q in cells:
        A = BR([1] * p + [-1] * q)
        g = find_grid(A, parity_fault=(fault == 'PARITY'))
        if g is None:
            without.append((p, q))
            check((p, q) in expected_none, f"Cl({p},{q}): no grid found but one was expected")
            check(all_triples_solvable(A), f"Cl({p},{q}): no grid, yet the triple equations are unsolvable")
        else:
            with_grid.append((p, q))
            check((p, q) not in expected_none, f"Cl({p},{q}): a grid was found but none was expected: {g[0]}")
            check(not assignment_exists(g[0], g[1], A), f"Cl({p},{q}): a +-1 assignment fits the grid")
            check(not all_triples_solvable(A), f"Cl({p},{q}): grid exists but the triple equations are solvable")
    print(f"ok  G1-G3: grids in {len(with_grid)} cells, none in {len(without)}: {sorted(without)}")
    # G4: CAND-144 matrices
    e1 = kron(X, I2); e2 = kron(Z, I2); e3 = kron(iY, X); e4 = kron(iY, Z)
    if fault == 'MATRIX':
        Yr = [[0, -1], [1, 0]]  # a real stand-in for Y: squares to -1 but does not anticommute correctly with Z(x)1? it does; use Y(x)X with the wrong scalar
        e3 = kron(Yr, X); e4 = kron(iY, Z)
        e3 = [[2 * x for x in r] for r in e3]
    gens = [e1, e2, e3, e4]
    E4 = [[1 if i == j else 0 for j in range(4)] for i in range(4)]
    for i, g in enumerate(gens):
        sq = mmul(g, g); want = E4 if i < 2 else mneg(E4)
        check(meq(sq, want), f"generator {i+1} square wrong")
    for i in range(4):
        for j in range(i + 1, 4):
            check(meq(mmul(gens[i], gens[j]), mneg(mmul(gens[j], gens[i]))), f"generators {i+1},{j+1} do not anticommute")
    A = BR([1, 1, -1, -1])
    def blade_matrix(a):
        M = E4
        for i in range(4):
            if a >> i & 1: M = mmul(M, gens[i])
        return M
    mermin = {'X1': kron(X, I2), '1X': kron(I2, X), 'XX': kron(X, X), '1Z': kron(I2, Z), 'Z1': kron(Z, I2),
              'ZZ': kron(Z, Z), 'XZ': kron(X, Z), 'ZX': kron(Z, X), 'YY': YY}
    found = {}
    for a in range(1, 16):
        if A.sq(a) == 1:
            M = blade_matrix(a)
            name = next((k for k, v in mermin.items() if meq(M, v) or meq(M, mneg(v))), None)
            check(name is not None, f"blade {a} is not one of Mermin's nine operators")
            found[a] = name
    check(len(found) == 9 and set(found.values()) == set(mermin), "the nine square-+1 blades are not Mermin's nine")
    g = find_grid(A)
    lines = [tuple(found[x] for x in L) for L in g[1]]
    mermin_lines = [{'X1', '1X', 'XX'}, {'1Z', 'Z1', 'ZZ'}, {'XZ', 'ZX', 'YY'}, {'X1', '1Z', 'XZ'}, {'1X', 'Z1', 'ZX'}, {'XX', 'ZZ', 'YY'}]
    check(sorted(map(sorted, map(set, lines))) == sorted(map(sorted, mermin_lines)), f"lines differ: {lines}")
    print(f"ok  G4: Cl(2,2) blades -> Mermin operators: {found}; lines = Mermin's rows and columns")
    # G5: re-signings
    for signs in itertools.product((1, -1), repeat=9):
        sg = dict(zip(g[0], signs))
        prod = 1
        for a, b, c in g[1]: prod *= A.triple_sign(a, b, c) * sg[a] * sg[b] * sg[c]
        check(prod == -1, "re-signing changed the product of line signs")
    print("ok  G5: the product of the six line signs is -1 under all 512 re-signings")
    print(f"ALL OK: {nchecks} checks")

if __name__ == '__main__':
    main()
