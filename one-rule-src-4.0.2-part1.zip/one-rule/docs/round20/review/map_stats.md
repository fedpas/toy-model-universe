# Atlas map — statistics (3.7.0 tables)

rows total 2064; statement rows (non-story, non-meta) 1516; story/meta rows 548
status over statement rows: proved-by-atlas 1137, ours 123, open 120, input 95, standard 41

## Status by group
| group | n | proved | standard | ours | input | open |
|---|---|---|---|---|---|---|
| LNB | 210 | 141 | 18 | 30 | 0 | 21 |
| LNS | 178 | 119 | 7 | 26 | 0 | 26 |
| LNC | 154 | 118 | 7 | 12 | 0 | 17 |
| CAND | 144 | 144 | 0 | 0 | 0 | 0 |
| INP | 120 | 31 | 0 | 0 | 89 | 0 |
| FUR | 80 | 64 | 0 | 6 | 1 | 9 |
| ATY | 68 | 51 | 1 | 9 | 1 | 6 |
| RIG | 65 | 64 | 0 | 1 | 0 | 0 |
| ATL | 53 | 32 | 1 | 4 | 1 | 15 |
| FRQ | 50 | 43 | 1 | 5 | 0 | 1 |
| LAB | 39 | 34 | 1 | 2 | 0 | 2 |
| SPN | 38 | 29 | 0 | 7 | 0 | 2 |
| RSN | 37 | 31 | 0 | 4 | 1 | 1 |
| MAP | 36 | 32 | 0 | 2 | 0 | 2 |
| GEN | 35 | 33 | 0 | 2 | 0 | 0 |
| PAG | 32 | 19 | 1 | 2 | 1 | 9 |
| EQN | 25 | 24 | 1 | 0 | 0 | 0 |
| SPR | 25 | 24 | 0 | 1 | 0 | 0 |
| CPL | 18 | 14 | 0 | 2 | 0 | 2 |
| GRV | 18 | 16 | 0 | 1 | 0 | 1 |
| MIR | 14 | 12 | 1 | 1 | 0 | 0 |
| NUL | 14 | 14 | 0 | 0 | 0 | 0 |
| GOS | 12 | 9 | 1 | 1 | 0 | 1 |
| YM | 11 | 8 | 0 | 1 | 0 | 2 |
| MAT | 10 | 7 | 0 | 1 | 1 | 1 |
| SHP | 8 | 7 | 0 | 0 | 0 | 1 |
| PRJ | 7 | 6 | 1 | 0 | 0 | 0 |
| SRC | 7 | 5 | 0 | 2 | 0 | 0 |
| THM | 6 | 6 | 0 | 0 | 0 | 0 |
| LNP | 2 | 0 | 0 | 1 | 0 | 1 |

## Status by page (home placements)
| page | n | proved | standard | ours | input | open |
|---|---|---|---|---|---|---|
| atlas | 1 | 1 | 0 | 0 | 0 | 0 |
| cells | 90 | 66 | 2 | 5 | 1 | 16 |
| clock | 44 | 40 | 1 | 1 | 1 | 1 |
| lenses | 2 | 0 | 0 | 1 | 0 | 1 |
| light | 56 | 36 | 0 | 3 | 15 | 2 |
| logbook | 88 | 76 | 0 | 8 | 1 | 3 |
| matter | 69 | 48 | 0 | 1 | 10 | 10 |
| matter/dictionary | 3 | 1 | 0 | 0 | 2 | 0 |
| matter/generations | 18 | 12 | 0 | 3 | 1 | 2 |
| matter/help | 18 | 7 | 0 | 1 | 1 | 9 |
| matter/model | 52 | 46 | 0 | 1 | 3 | 2 |
| matter/papers | 18 | 14 | 0 | 1 | 2 | 1 |
| rule | 41 | 36 | 0 | 4 | 0 | 1 |
| shapes | 42 | 34 | 1 | 1 | 4 | 2 |
| shifted | 38 | 25 | 0 | 6 | 1 | 6 |
| steps | 2 | 1 | 0 | 1 | 0 | 0 |
| steps/baez | 256 | 184 | 18 | 30 | 3 | 21 |
| steps/category | 199 | 162 | 7 | 12 | 1 | 17 |
| steps/comm | 4 | 3 | 1 | 0 | 0 | 0 |
| steps/coupling | 55 | 44 | 0 | 3 | 6 | 2 |
| steps/dirac | 19 | 13 | 0 | 0 | 6 | 0 |
| steps/forque | 57 | 46 | 1 | 5 | 4 | 1 |
| steps/gauge | 14 | 10 | 0 | 0 | 4 | 0 |
| steps/grav1 | 21 | 16 | 0 | 0 | 4 | 1 |
| steps/grav2 | 35 | 28 | 1 | 3 | 3 | 0 |
| steps/groups | 15 | 11 | 1 | 1 | 1 | 1 |
| steps/matter | 19 | 10 | 0 | 1 | 7 | 1 |
| steps/mirrors | 27 | 23 | 1 | 1 | 2 | 0 |
| steps/nullsurf | 25 | 22 | 0 | 0 | 3 | 0 |
| steps/projective | 18 | 14 | 1 | 0 | 3 | 0 |
| steps/rigid | 81 | 76 | 0 | 2 | 3 | 0 |
| steps/schuller | 193 | 130 | 7 | 27 | 2 | 27 |
| steps/spin | 50 | 36 | 0 | 7 | 5 | 2 |
| steps/spring | 33 | 28 | 0 | 2 | 3 | 0 |
| steps/ym | 27 | 18 | 0 | 2 | 5 | 2 |

## Status by clock value (p−q mod 8) of the row's cells
| clock | n | proved | standard | ours | input | open |
|---|---|---|---|---|---|---|
| 0 | 410 | 315 | 13 | 29 | 13 | 40 |
| 1 | 81 | 68 | 1 | 3 | 0 | 9 |
| 2 | 259 | 207 | 10 | 25 | 5 | 12 |
| 3 | 236 | 201 | 7 | 11 | 5 | 12 |
| 4 | 153 | 131 | 5 | 10 | 0 | 7 |
| 5 | 95 | 71 | 3 | 6 | 8 | 7 |
| 6 | 441 | 315 | 15 | 29 | 48 | 34 |
| 7 | 94 | 70 | 4 | 8 | 1 | 11 |

## Status by n = p+q+r
| n | n rows | proved | standard | ours | input | open |
|---|---|---|---|---|---|---|
| 0 | 6 | 6 | 0 | 0 | 0 | 0 |
| 1 | 46 | 31 | 0 | 4 | 0 | 11 |
| 2 | 163 | 136 | 5 | 15 | 1 | 6 |
| 3 | 205 | 182 | 7 | 6 | 4 | 6 |
| 4 | 737 | 543 | 30 | 61 | 59 | 44 |
| 5 | 159 | 130 | 4 | 9 | 2 | 14 |
| 6 | 76 | 59 | 2 | 2 | 1 | 12 |
| 7 | 37 | 33 | 0 | 1 | 0 | 3 |
| 8 | 130 | 98 | 0 | 9 | 9 | 14 |
| 9 | 34 | 27 | 1 | 4 | 0 | 2 |
| 10 | 151 | 112 | 8 | 8 | 3 | 20 |
| 11 | 10 | 9 | 0 | 1 | 0 | 0 |
| 14 | 1 | 1 | 0 | 0 | 0 | 0 |
| 16 | 9 | 8 | 0 | 1 | 0 | 0 |
| 24 | 5 | 3 | 1 | 0 | 1 | 0 |

statement rows with no cell: 250; with a symbolic cell only (no concrete (p,q,r)): 327

## Dependency graph
edges 4928; by relation: derives 2309, equiv 1224, uses-input 567, instance 526, restates 268, cycle 33, contradicts 1
edges to a non-row target (theorems T*, questions Q* excluded): 0
statement rows with no outgoing depends (axioms/inputs/roots): 171; with nothing depending on them (leaves): 600; isolated (both): 75
most depended-on rows: T4 (116), T18 (69), EQN-019 (63), T20 (49), T17 (48), EQN-016 (48), RIG-002 (47), FRQ-001 (42), T2 (41), INP-075 (39), T10 (38), T1 (34), T3 (34), EQN-017 (34), INP-066 (32), T16 (31), LNS-012 (30), T5 (29), SPN-001 (29), LNS-003 (29), LNB-021 (28), INP-089 (27), T15 (27), CPL-011 (26), MAP-021 (25)

cross-page dependency edges (from-page → to-page, top 40):
- steps/schuller → logbook: 72
- shifted → steps/coupling: 55
- steps/baez → shapes: 48
- matter/papers → matter: 36
- steps/grav2 → steps/grav1: 23
- steps/grav1 → steps/grav2: 20
- cells → rule: 19
- logbook → steps/category: 17
- shifted → steps/grav2: 16
- matter/generations → matter: 16
- logbook → matter: 15
- rule → clock: 14
- clock → rule: 13
- matter → light: 13
- steps/baez → steps/rigid: 13
- steps/schuller → steps/category: 13
- logbook → light: 13
- logbook → shapes: 13
- steps/projective → steps/grav2: 12
- steps/baez → cells: 12
- steps/baez → steps/projective: 12
- logbook → steps/schuller: 12
- steps/coupling → steps/dirac: 11
- rule → steps/category: 11
- cells → logbook: 10
- steps/matter → steps/ym: 10
- matter → steps/baez: 10
- cells → light: 9
- light → logbook: 9
- steps/matter → steps/dirac: 9
- steps/nullsurf → logbook: 9
- steps/forque → steps/rigid: 9
- lenses → steps/category: 9
- steps → steps/rigid: 9
- steps/forque → steps/projective: 8
- rule → cells: 8
- light → cells: 8
- steps/rigid → steps/mirrors: 8
- steps/ym → steps/comm: 7
- matter → logbook: 7

directed cycles over derives/instance/uses-input edges: 3
- ATY-011 → ATY-038 → ATY-041 → ATY-011
- LAB-034 → LAB-039 → LAB-035 → LAB-034
- LAB-039 → LAB-036 → LAB-039

## Chains
chains 186; shapes: fork 96, line 82, cycle 7, ladder 1
weakest link: proved-by-atlas 97, ours 39, open 34, standard 11, meta 3, input 2
statement rows told in a chain: 661 of 1516; not in any chain: 855
link relations used in chains: derives 268, continues 154, order 127, equiv 31, instance 25, cycle 8, uses-input 6

## Lenses
| lens | kind | dictionary | rows with a reading | pages touched |
|---|---|---|---|---|
| alg | branch | 168 | 263 | 29 |
| geo | branch | 83 | 248 | 30 |
| top | branch | 0 | 0 | 0 |
| cat | branch | 156 | 140 | 16 |
| comb | branch | 0 | 0 | 0 |
| str | language | 65 | 225 | 22 |
| sol | language | 72 | 190 | 25 |
| fld | language | 90 | 174 | 30 |
| clifford | shape | 0 | 0 | 0 |
| simplex | shape | 0 | 0 | 0 |
| cube | shape | 0 | 0 | 0 |
| prime | shape | 0 | 0 | 0 |
| orthoplex | shape | 0 | 0 | 0 |
| demicube | shape | 0 | 0 | 0 |
| gosset | shape | 0 | 0 | 0 |
| furey | researcher | 41 | 28 | 6 |
| baez | researcher | 70 | 35 | 3 |
| schuller | researcher | 115 | 15 | 6 |
| hestenes | researcher | 23 | 0 | 0 |
| pga | researcher | 0 | 0 | 0 |
| roelfs | researcher | 0 | 0 | 0 |
| tian | researcher | 0 | 0 | 0 |
| majkic | researcher | 155 | 45 | 8 |
| pumplun | researcher | 14 | 1 | 1 |
| hbhl | researcher | 0 | 0 | 0 |
| atiyah | researcher | 109 | 198 | 24 |
| bits | labels | 0 | 0 | 0 |
| primes | labels | 0 | 0 | 0 |
| sigword | labels | 0 | 0 | 0 |
| bitsq | labels | 0 | 0 | 0 |
| space-plus | convention | 0 | 0 | 0 |
| time-plus | convention | 0 | 0 | 0 |
| cl13 | convention | 0 | 0 | 0 |
| cl31 | convention | 0 | 0 | 0 |
| role-names | convention | 0 | 0 | 0 |
statement rows with at least one lens reading: 703 of 1516

### lens × page coverage (rows with a reading of that lens on that page)
| page | alg | geo | cat | str | sol | fld | furey | baez | schuller | majkic | pumplun | atiyah |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| atlas | 1 | 1 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| cells | 21 | 13 | 10 | 54 | 20 | 20 | 0 | 0 | 0 | 3 | 0 | 13 |
| clock | 26 | 19 | 6 | 11 | 14 | 16 | 0 | 1 | 0 | 5 | 0 | 12 |
| lenses | 1 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| light | 3 | 26 | 2 | 9 | 30 | 13 | 0 | 0 | 0 | 2 | 0 | 2 |
| logbook | 12 | 31 | 11 | 17 | 25 | 15 | 0 | 0 | 0 | 11 | 0 | 5 |
| matter | 23 | 1 | 0 | 2 | 3 | 6 | 26 | 0 | 3 | 0 | 0 | 7 |
| matter/dictionary | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| matter/generations | 5 | 0 | 1 | 1 | 0 | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| matter/help | 3 | 0 | 0 | 0 | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| matter/model | 20 | 1 | 0 | 2 | 2 | 4 | 26 | 0 | 3 | 0 | 0 | 7 |
| matter/papers | 1 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| rule | 25 | 4 | 7 | 6 | 7 | 7 | 1 | 0 | 0 | 0 | 0 | 9 |
| shapes | 13 | 12 | 7 | 18 | 3 | 3 | 1 | 0 | 2 | 1 | 0 | 12 |
| shifted | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 24 |
| steps | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| steps/baez | 59 | 14 | 5 | 35 | 13 | 15 | 12 | 34 | 0 | 0 | 0 | 27 |
| steps/category | 59 | 29 | 73 | 15 | 27 | 21 | 0 | 0 | 5 | 24 | 1 | 21 |
| steps/comm | 1 | 4 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| steps/coupling | 2 | 3 | 1 | 1 | 4 | 7 | 1 | 0 | 1 | 0 | 0 | 21 |
| steps/dirac | 2 | 6 | 1 | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 | 2 |
| steps/forque | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| steps/gauge | 1 | 6 | 0 | 5 | 1 | 5 | 0 | 0 | 0 | 0 | 0 | 2 |
| steps/grav1 | 2 | 11 | 0 | 0 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 8 |
| steps/grav2 | 0 | 8 | 0 | 0 | 1 | 2 | 0 | 1 | 0 | 0 | 0 | 15 |
| steps/groups | 6 | 5 | 5 | 5 | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 5 |
| steps/matter | 2 | 2 | 1 | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 | 3 |
| steps/mirrors | 2 | 16 | 0 | 3 | 4 | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| steps/nullsurf | 0 | 10 | 1 | 12 | 2 | 8 | 0 | 0 | 0 | 1 | 0 | 2 |
| steps/projective | 0 | 10 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 5 |
| steps/rigid | 0 | 4 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 1 | 0 | 0 |
| steps/schuller | 14 | 28 | 8 | 40 | 17 | 14 | 0 | 0 | 6 | 0 | 0 | 29 |
| steps/spin | 3 | 3 | 2 | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| steps/spring | 1 | 2 | 0 | 1 | 25 | 2 | 0 | 0 | 0 | 0 | 0 | 1 |
| steps/ym | 1 | 1 | 0 | 1 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 7 |

## Open rows (status open)
- **ATL-003b** [example/A; (0,1,0); cells] Reading that phase as the electromagnetic phase (the “clock” of the fiber) is ours and open; nothing here yields electromagnetism.
- **ATL-005b** [example/A; (0,2,0); cells] In Furey’s construction su(2)_L comes from the quaternion multiplication algebra; reading this cell as weak isospin is that model’s choice, not a result of this cell.
- **ATL-007b** [example/A; (2,1,0); cells] The name “quark” for this cell is ours and open: B=2, F=1 ↦ 2/3 is only the ratio B/(B+F), not a charge computed from the algebra, and quark colour does not follow from this cell.
- **ATL-008b** [example/K; (1,2,0), (1,3,0); cells] Reading this cell as the home of charged-lepton spinors (its name “lepton”) is ours and open, not a result.
- **ATL-011b** [example/K; (0,2,0), (2,2,0); cells] Calling it an electroweak core is an interpretation, and open: Furey’s su(2)_L comes from the quaternion multiplication algebra Cl(0,2) at [2,−2].
- **ATL-013b** [example/K; (2,3,0), (4,1,0); cells] Reading this cell as the frame behind maximal parity violation is ours and open: parity violation is a weak-interaction fact that does not follow from this cell.
- **ATL-014d** [example/K; (1,5,0), (2,4,0), (3,3,0), (4,2,0), (5,1,0); cells] The name “confinement” is ours and open: colour confinement is a physical statement that does not follow from this cell.
- **ATL-015b** [example/K; (3,4,0), (4,3,0), (k+1,k,0); cells] A central split of this kind has a standard reading elsewhere: the two ideals carry the two signs of a pseudoscalar mass (Schuller, for Cl(1,4)). In the five-bit label picture of one generation (Baez–Bokor–Boyle) antiparticles are instead the complement labels (particle-hole, XOR with 1…1). Reading the two ideals as matter and antimatter is ours, and it needs a choice of anti-involution as an input.
- **ATL-016b** [example/A; (2,3,0), (4,1,0); cells] The name “chiral parity” is ours and open: parity is a reflection (the grade involution of the spatial algebra), a different operation from the signature flip, and parity violation does not follow from this cell.
- **ATL-018d** [range/F; (1,n-1,0); cells] Reading S as a gravitational strain (the card name “Gravity Strain”) is only a reading of ours, and open. The two checks above are what the reading had to survive: the Einstein form depends on the frame only through S up to local Lorentz gauge, so E_a = 0 is an equation on S modulo that gauge, and its linearisation reads S⁽¹⁾ alone; nothing beyond the name is built from the strain reading.
- **ATL-019b** [example/A; (5,3,0); cells] A conserved baryon number is a conjecture: no grading or symmetry carrying it has been found. In the geometric models of Atiyah, Manton and Schroers the baryon number is the signature of a 4-manifold, whose value mod 8 is the clock of its frame lattice (ATY-016); that is the paper's reading, not a grading of this cell, and the conjecture stays open.
- **ATL-020c** [reading/O; (0,8,0), (4,4,0), (8,0,0); cells] The ratio 4/17 is not derived from the labels: the Atlas defines no count of neutral paths that gives it. It is not read as a weak mixing angle, and whether it means anything is open. The unification value of the weak mixing angle, sin²θ_W = Tr T₃²/Tr Q² over the 16, is 3/8 (CAND-044, checked).
- **ATL-021b** [lemma/A; all n; cells] Reading its passive role as a sterile-neutrino state and its active role as the Higgs VEV operator is our interpretation: neither follows from the algebra, and no mass scale comes out of it.
- **ATL-022b** [computation/A; (2,6,0), row 8; cells] 210 is not derived as a value of the model; whether it means anything is open.
- **ATL-024b** [classification/A; (1,4,0), (5,0,0), all n; cells] The odd primes outside the group orders of step 17, the continuous parameters, a map from irreps to cells (it has to target the real forms, not the triples) and the number 210 are open.
- **ATY-056** [question/O; (1,3,0), (1,4,0); shifted] Open: what the shifted Einstein equations (3.5) mean, as a series in r²Δ beyond perturbation or as an equation for the pair (g, φ) on the Hilbert space of 1-forms (ATY-057), and which shifted Ricci tensor, if any, an argument would select. Of the paper's readings of its shifted Einstein equations (3.5), the restriction to the 1-forms that solve the wave equation (3.10) is consistent on de Sitter to every order; on on…
- **ATY-057** [question/O; (1,3,0), (4,0,0), (1,4,0), (2,3,0); shifted] Open: the equation (3.11) for the pair (g, φ) on the Hilbert space of 1-forms, the third of the paper’s readings of its shifted Einstein equations, is not built. The Weitzenböck formula is checked on the labels with its signs, and the shifted Ricci operators are computed as series acting on 1-forms, with de Sitter worked out order by order (ATY-051, ATY-053); the equation for the pair stays open, as the paper leaves …
- **ATY-059** [question/O; (1,3,0); shifted] Open: what an equivalence-principle test of a shifted fermion weighs — the Noether energy, where the labels find no deviation, or the coupling per unit local density, where they find a J part — and how an experiment weighs a J-valued term. Whether the paper’s bound (2.15) applies depends on it; the Atlas evaluates no bound (ATY-037, ATY-039).
- **ATY-060** [question/F; (1,3,0); shifted] Open: the processes of quantum electrodynamics (Bhabha and Compton scattering, the Lamb shift, the anomalous magnetic moment), the Higgs mechanism and the odd-integer test of the Compton wavelengths are not computed with shifted operators. What runs is gauge covariance in a constant potential and a potential with a gradient to first order (ATY-008, ATY-046); a check of the processes would need interacting quantized f…
- **ATY-063** [question/F; (1,3,0); shifted] Open: a quantized field with the shifted operator (Fock space), localized wave packets, and the infinite-dimensional data of (2.1) as a space of states are not built, nor is the relation of shifting to geometric quantization. On finite sums of quantized plane waves the shifted theory reads as the ordinary one, reweighted (ATY-047, our reading), and in a potential with a gradient the shift mixes the two halves in the …
- **ATY-064** [question/O; (1,4,0), (1,3,0); shifted] Open: the magnitudes (2.8), (2.15), (3.7)–(3.9) and (5.1)–(5.4) are the paper’s and are not computed here. Their inputs — the lightest neutrino’s mass, the bound on violations of the equivalence principle, the observed cosmological constant — are inputs, given as their sources state them; the time scale ħ/kc of (4.4) is printed as a number (ATY-055), and its coincidence with the age of the universe is the paper’s rem…
- **CPL-006b** [dead-end/F; (1,0,0), (1,1,0), n = 1, n = 2; steps/coupling] A neutral form of the field for n = 1 and 2 is not built: open.
- **CPL-007c** [question/F; (1,n−1,0), n ≥ 5, n ≥ 5; steps/coupling] What the copies of the Dirac field from n = 5 stand for (a flavour or taste reading); and, on one copy, whether the grade-5 part of the current vanishes at some ψ ≠ 0 for n = 7 and 8, and what it is for n ≥ 9.
- **FRQ-005** [pointer/M; (0,3,1), (3,0,1), (4,1,0); steps/forque] The paper has no conformal dynamics, and the work of the other authors on this subject (Dechant, Roelfs, Eelbode, Holmer, the Lasenbys and Doran) is not read here. Newton's law in conformal space is a separate question. One source on constrained dynamics in the conformal and projective algebras is read only in its abstract and slides (the full text not reachable): its authors state the equivalence with PGA dynamics, …
- **FUR-005** [question/O; (0,8,0); matter] A map from irreps to cells (until one is defined the top quark has no cell: three cells have been tried, [7,±1], [4,+4] and [3,+1], none established); the origin of 210; odd primes and continuous parameters, which the lattice does not supply; whether the 8ℂ of extra edges are physical. The questions about Fig. 1 itself are on the Three generations and What may help tabs.
- **FUR-005b** [question/O; (0,8,0); matter] Open: a map from irreps to cells (until one is defined the top quark has no cell; of the candidate cells [7,±1], [4,+4] and [3,+1] none is established); the origin of 210; odd primes and continuous parameters, which the cells do not supply (their sizes are powers of 2); whether the 8ℂ of the four extra edges are physical; the ℤ₂ gauge parallel between ω and ω′. The questions about Fig. 1 itself are on the Three gener…
- **FUR-038** [question/O; (1,9,0), (0,10,0), (1,3,0), (0,4,0); matter] Open: what would relate the Lorentz algebra so(1,3) of Cl(1,9) to the su(2)_L ⊕ su(2)_R of Pati and Salam beyond their common complexification so(4,ℂ). Checked on the labels (FUR-034): so(1,3) and the compact so(4) of Cl(0,10) (Pati and Salam's algebra, recalled) are not isomorphic as real Lie algebras, their Killing forms on the bivector labels having inertias (3,3) and (0,6), from the squares (1,3) and (0,4) of the…
- **FUR-039** [question/O; (0,8,0); matter] Open: three generations. Checked: the board of her model holds one complete Standard Model set, two with every cell doubled, and in the doubled board exactly the irreps of Q_L, u_R and ν_R lack a third copy (RSN-003); counting a type and its conjugate together on the linear off-diagonal cells of blocks of her kind (sizes 1, 2, 3, Standard Model hypercharges |y| ≤ 2), structures of 8 to 10 complex dimensions hold at m…
- **FUR-040** [question/F; (1,9,0), (1,3,0) ⊗ (0,6,0); matter] Open: the spectrum of fibre momenta. Checked exactly at sampled momenta, with m = 4 and 8 (FUR-013, FUR-026): in the graded product Cl(1,9) = Cl(1,3) ⊗̂ Cl(0,6) a field has one mass for each fibre momentum, its plane waves with a fibre momentum of length m lying exactly on the mass shell E² = |p|² + m², and a field with two fibre momenta separates into one term on each shell, two rungs of a Kaluza–Klein tower (the na…
- **FUR-592** [question/O; ; matter/papers] Open: whether the 2024 Cartan factorization of Furey and Hughes and the 2026 recombination of b′_R, h′ and τ′_R are two views of one mechanism.
- **FUR-611** [question/O; (0,8,0); matter/generations] The products b_R ⊗ h, b_R ⊗ τ_R† and h ⊗ (ν_τ, τ)_L are tensor products of irreps: they show that the quantum numbers of the irreps Fig. 1 lacks can be recovered, nothing more. Whether these products are physical states, and with which dynamics, is open.
- **FUR-618c** [question/O; ; matter/generations] Open (not tested): whether a triality acting on a space larger than her 16-dimensional model gives an order-3 symmetry of three generations.
- **FUR-637** [question/O; ; matter/help] Open: how the e₇ of the 2024 dimension count, 133 = 9 + 28 + 96 (with the dimensions 9 and 28 of tri(ℍ) and tri(𝕆) recalled), compares with the e₇ in which three generations appear in other work; here only the dimension agrees.
- **GOS-006d** [question/K; (0,n,0), (1,n,0), (n,0,0); shapes] For an odd unimodular lattice L that is neither I_{p,q} nor E₈ ⊕ ℤ, k^⊥/2k^⊥ = (L_even/2L, x·x/2 mod 2) still holds (CAND-101), but the Atlas attaches no cell to L: whether this form is the label form of the even part of a cell (p,q) with p + q = n and p − q ≡ ±σ mod 8, and whether a root lattice orthogonal to a characteristic vector of L reduces to it, is not checked.
- **GRV-005b** [question/F; (1,3,0); steps/grav1] The coupling constant in front of the Einstein form is not derived here: open.
- **LAB-012** [question/M; ; steps/groups] Open, and not treated here: the groups of Lie type over fields with more than two elements, the exceptional families, most sporadic groups, and the exact statement of Cartan–Dieudonné in characteristic 2 for every n. What is checked: the orthogonal transvections generate the isometry group of every non-degenerate form of dimension 2, 4 and 6 except O⁺₄(2), where they give a subgroup of index 2 (CAND-059), and W(E_n) …
- **LAB-016** [question/M; (p,q,0); clock] Pin groups are treated on the labels: the twisted adjoint and the two lifts of a reflection, with the lift of time reversal squaring to +1 in Cl(1,n−1) and to −1 in Cl(n−1,1), n ≤ 6 (CAND-002); the clock as the class of a Pin⁻ structure and the ℤ₈ of the edges of time-reversal-invariant Majorana chains (LAB-018, LAB-021); the invariants of the ten symmetry classes (LNC-076d). Not treated, and open: matching Pin⁺ and …
- **LNB-011d** [computation/K; (1,9,0), (5,5,0), (9,1,0), (p,10−p,0), row 11; steps/baez] B.10 The two (1,9)s are not the same kind: the triangulation form is hermitian on ℂ¹⁰, a real form on ℝ²⁰ of signature (2,18), while det on h₂(𝕆) is a real form of signature (1,9) on ℝ¹⁰ (checked: baez·T3, baez·O3i; exact: bd·str·19, chn·11). Whether any mechanism links them is open: none is found, and the match stays numerology.
- **LNB-022f** [computation/K; (1,9,0), (5,5,0), (9,0,0), (9,1,0); steps/baez] Real 10 against complex 10, checked: the 10 of h₂(𝕆) is a real dimension, ℝ⁹ plus time, with det of signature (1,9) (baez·O3i; exact, chn·11); the 10 of the triangulation form is a complex dimension, ℂ¹⁰ = ℝ²⁰ of real signature (2,18) (baez·T3; exact, bd·str·19, chn·11). What the clock says about (1,9) is checked: as an algebra it is M₃₂(ℝ), clock 0 (baez·T4). Whether a mechanism connects the two tens is open: we fin…
- **LNB-025e** [reading/A; (0,0,r), (p,q,r), n ≤ 4; steps/baez] The cospan paper was read at overview level; the atlas has no categories, no Petri nets and no rates, and whether label algebras are a useful finite test case for the category-theoretic statements is open (P8).
- **LNB-033c** [question/K; (5,5,0); steps/baez] Whether the three label spaces can be made one space V ⊗ ℂ³ by a construction outside e₇ is open.
- **LNB-034** [question/D; (2,4,0), (4,2,0); steps/baez] The complexification of so(4,2), so(6,ℂ) = 4 + 7 + 4, is the Lie algebra of the triple M₂,₂(ℂ) (type A III, isomorphic to BDI with n = 4; Tables 1 and 2 of the Jordan-pair paper), and the Kepler su(2) + su(2) lies in its degree-0 part (checked at the level of Lie algebras: baez·K4; the 4 + 7 + 4 on the real form, h5l_conformal). The Standard Model group is K₀ of M₃,₂(ℂ), one row more, by the Jordan-pair paper's accou…
- **LNB-034c** [question/D; (2,4,0), (4,2,0); steps/baez] Could hydrogen be read as a Jordan-pair quantum system, with M₂,₂(ℂ) one row below the M₃,₂(ℂ) of the Standard Model?
- **LNB-035c** [question/O; ; steps/baez] The Jordan-pair paper says in words that the two subalgebras act on the 27 in different ways, and the E7 paper chooses its embedding on purpose (read; the different action on the 27 is also computed, baez·S2, LNB-035). Why the E7 paper prefers its embedding, and how the non-regular embeddings (countably many in so(10,ℂ), according to the E7 paper) relate the two, is open.
- **LNB-036b** [question/K; (1,9,0), (9,0,0); steps/baez] No mechanism connects the two tens; the numerology stays a question, open.
- **LNB-037** [question/A; (p,q,r); steps/baez] Shared wires as contracted bits, with the three squares +1, −1, 0 as three behaviours of a wire (J10). If it is useful, the Frobenius forms of label algebras might serve as a finite test case for the category-theoretic statements. Low priority, and well outside what the atlas can check.
- **LNB-037b** [question/A; (p,q,r); steps/baez] Could the Frobenius forms of label algebras serve as a finite test case for statements about open systems?
- **LNB-040** [question/K; (5,5,0); steps/baez] The atlas sees each V_k as the Fock module of Cl(5,5) (J2), not through the adjoint of e₇: is that a reading the E7 paper would accept?
- **LNB-041** [question/D; (4,2,0); steps/baez] Hydrogen as the Jordan pair M₂,₂(ℂ) inside M₃,₂(ℂ): is there physics in the inclusion? (P5)
- **LNB-042b** [question/K; (1,9,0); steps/baez] A mechanism behind the (1,9) is open (P7).
- **LNB-044** [question/A; (5,5,0); steps/baez] Is the Hamming-distance form of the Peirce rule, 1 − d/4, already in Loos’s Jordan theory?
- **LNB-046** [question/D; (3,0,1), (3,1,0), (4,0,0); steps/baez] Kepler paper, eq. (12), third line, as we read version 5: {M_j, M_k} = ε_jkℓ M_ℓ, which disagrees with the computed bracket ε_jkℓ L_ℓ. Whether the print is a slip for ε_jkℓ L_ℓ is unconfirmed: open.
- **LNB-051** [question/K; (1,9,0); steps/baez] Baez asked whether the triangle count’s likeness to ten-dimensional space-time is a coincidence; we found no reason: real 10 vs complex 10, no mechanism (J7): open.
- **LNB-058c** [question/M; (1,9,0); steps/baez] Baez himself asks whether that is a coincidence. We found no reason; the question is open.
- **LNB-144** [question/K; ; steps/baez] Whether the three complex 3-spaces of one and the three generations of the other are related is open.
- **LNB-152** [question/K; (1,9,0); steps/baez] Baez asks whether the likeness to ten-dimensional space-time is a coincidence. The 10 of h₂(𝕆) is real and the 10 of the form is complex (checked: baez·O3i, baez·T3, chn·11); a mechanism is open: we find none (the clock gives none, baez·T4).
- **LNB-159** [question/K; ; steps/baez] Whether that link means anything is open.
- **LNB-165** [question/K; (1,9,0); steps/baez] Papers 1 and 6 both meet the pattern of one time direction and nine space directions, in paper 6 over the complex numbers (checked). Baez asked whether that is a coincidence; we found no reason either way, and the question is open.
- **LNC-054b** [question/A; n = 3 (cube category); steps/category] Over ℝ, the field of the cells, whether k B₃ is tame and derived equivalent to the canonical algebra of type (3,3,3) is open.
- **LNC-069** [pointer/M; ; steps/category] Tian’s DG category, whose K₀ is the ℤ-form of the algebra, has no counterpart in the atlas and was not tested; its Remark 2.6 and Conjecture 2.11 are open in the paper.
- **LNC-076c** [question/O; (p,q,r), all eight clock values; steps/category] Which class sits at which clock value needs T² and C² as input: built from them, the symmetry algebras of the eight real classes have the commutants of the clock table at c = 0, …, 7 entry for entry, and A and AIII give ℂ with one and two summands; the match is fixed up to the reflection s ↦ 2 − s, and its direction is set by how the Hamiltonian meets T and C, also an input (checked, exact: solid·T1–T6, qmt·K2–K6; Ki…
- **LNC-077** [question/A; (3,0,1), (p,q,r); steps/category] The complement mask pairs a with a ⊕ 1…1 and is a Frobenius pairing for every signature. Ungraded, the pairing λ is symmetric exactly when n is odd, and a symmetric Frobenius form exists exactly when n is odd or r = 0; for n even with r ≥ 1, the projective algebra Cl(3,0,1) for example, the Nakayama automorphism is the grade involution, no unit implements it and no symmetric form exists. In super vector spaces that t…
- **LNC-078b** [question/K; (3,0,0), (p,q,0), (p,q,r); steps/category] Is this dichotomy, non-degenerate against positive, known for degenerate Clifford algebras, and how do composite systems and entanglement enter? Open; at sampled cells the graded products of states are computed (CAND-043).
- **LNC-079b** [question/K; (2,2,0), (p,q,0); steps/category] Is this the known polar-space picture of Pauli-type groups, and what in it does the contextuality literature not have? Open: the symplectic picture of the Pauli and Clifford groups is in Weil’s memoir and in Mastel’s paper, read; the polar-space papers of Saniga and Planat and the contextuality papers are not read.
- **LNC-080** [question/K; (n,n,0); steps/category] The fermionic and the bosonic ladders satisfy the same relations once the commutator is a super-commutator (checked, n ≤ 4); the super-dimension of the 2ⁿ labels is 0, which aa⁺ + a⁺a = 1 needs in finite dimension, while the bosonic [a, a⁺] = 1 has no finite-dimensional solution: the supertrace of an anticommutator of odd maps and the trace of a commutator vanish (checked; every n, Thm T20). Reading super-dimension 0…
- **LNC-081** [question/O; (p,q,r), (p,q,r) r≥1, all eight clock values; steps/category] The eight clock values and the two complex classes match the ten symmetry classes of free-fermion matter (Kitaev’s periodic table, arXiv:0901.2686, read at statement level; checked: built from T² and C², the symmetry algebras of the eight real classes have the commutants of the clock table at c = 0, …, 7 entry for entry, and A and AIII give ℂ with one and two summands, solid·T1–T6, qmt·K1–K7). Which class sits at whi…
- **LNC-082b** [question/K; (0,n,0), (n,0,0); steps/category] Is this identification known, and what more does it mean through E₉, E₁₀, E₁₁? Open.
- **LNC-083b** [question/A; n = 3 (cube category); steps/category] Over ℝ, the field of the cells, whether k B₃ is tame and derived equivalent to that algebra is open.
- **LNC-084** [question/A; (0,0,r), (p,q,r); steps/category] The exterior algebra Λ(k^{r}) has finite representation type for r ≤ 1, tame for r = 2 and wild for r ≥ 3 (recalled). Does that measure how far label 0 is from invertible, and what does it become for Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^{r}) with p + q ≥ 1?
- **LNC-085** [question/A; (2,0,0), (p,q,r); steps/category] Among label-homogeneous gradings the universal grading group is ℤ₂^{p+q} × ℤ^{r} (Thm T2; checked with its torsion for n ≤ 4); for arbitrary gradings the rank can exceed r, as the ℤ-grading of M₂(ℝ) by matrix units shows (checked). Is the universal grading group for arbitrary gradings known, torsion part included? Open.
- **LNC-086** [question/A; (p,q,r); steps/category] The labels of Cl(p,q,r) with the product “zero when two labels share a null bit” form a monoid with zero, M = (ℤ/2)^{p+q} × (subsets of an r-set under disjoint union, with an absorbing zero), and the bit-rule sign is a 2-cocycle on M, so Cl(p,q,r) is a twisted contracted monoid algebra of M (checked, n ≤ 4; its 𝔽₂ cohomology in low degrees, n ≤ 3). Is there a cohomology of such cocycles (contracted monoid algebras, p…
- **LNC-088** [question/A; (m−1,m−1,1); steps/category] Tian’s odd truncations have a radical vector a₁ − a₃ + a₅ − …, the half of the last hyperbolic pair whose partner is missing (checked; Thm T7). Is there an object in his DG category, or a class in K₀, that gives this vector, and what happens to it in the infinite algebra, which has no radical (not checked here)? Open; the DG category is not built here.
- **LNC-097** [question/A; (3,0,1); steps/category] Does the Nakayama twist of Cl(3,0,1), which no unit implements, matter for the complement-based dual of projective geometric algebra (QA4)?
- **LNC-098c** [question/K; (0,n−2,1); steps/category] Is the Carroll structure of a null hypersurface, as a field with its connection, and the reading of its unpaired null as label 0, more than the pointwise algebra? The literature on Carrollian horizons is the place to look (Donnay and Marteau; Duval, Gibbons, Horváthy and Zhang: pointers, the sources are not read in full here).
- **LNC-123** [question/A; (3,0,1); steps/category] Complement, in physics: the dual map of projective geometric algebra is built on the complement (standard: in the dynamics paper of Dorst and De Keninck the star is the signed complement, FRQ-002). The Nakayama twist of Cl(3,0,1) is the grade involution, which no unit implements, and in super vector spaces it is the Koszul sign (Thm T3); whether it matters for that dual in practice is open (QA4).
- **LNP-004** [question/M; ; lenses] Open: closure equations and an action principle for Schuller’s chain (not rebuilt); groups, chirality, masses and why three generations for the Baez embeddings.
- **LNS-013g** [computation/F; (1,3,0), (4,0,0); steps/schuller] Whether the eleven or more integration constants of his closure of general linear electrodynamics (“at least 11”: the constructive-gravity article, p. 18; the closure paper gives no count) organise along 6 + 12 + 3, or along the invariant pieces, is a question, not a result: the closure paper sets up the closure equations of this theory but does not solve them, and the perturbative solution it cites is not in the pac…
- **LNS-014e** [example/F; (0,0,1), (0,1,0), (1,0,0), 1+1; steps/schuller] P3: in 1+1 both deformations are functions on a line; for d > 1, Witt ⊗ A_ε is not literal. Whether his deformation algebra has a family in the sign ε with Euclidean, Carroll-type and Lorentzian members for d > 1 stays open. Frozen 1+1 model only, not his (48)–(50); nothing is computed beyond it.
- **LNS-023** [question/M; ; steps/schuller] Gluing. Topology, bundles and connections as sections over a manifold: the atlas is pointwise algebra and finite combinatorics, its fields are polynomials in one chart. Row L4 stays a gap.
- **LNS-024** [question/M; (1,3,0); steps/schuller] An action principle. His closure equations are not rebuilt: their derivation (his sections III–IV, the deformation algebra and its linearisation) and their solution for any matter other than Klein–Gordon are open (rows C7, C8). Evaluating them needs no action principle of ours: for Klein–Gordon matter his printed equations hold exactly on his printed solution, the six non-trivial ones component by component, at three…
- **LNS-025** [question/M; ; steps/schuller] Infinite dimensions. Banach and Hilbert spaces, the spectral theorem and the bosonic Fock space are beyond the finite labels (row M2): the bosonic relation [a, a⁺] = 1 has no finite-dimensional solution (Thm T20). Mixed states are not: in every cell the states, for the dagger involution, are the density elements of the scalar-part trace, and with null generators they are those of the cell without them (Thm T15 for ev…
- **LNS-026** [question/M; (2,0,0); steps/schuller] Analysis. Chapter 20 is reached only through its one-period matrix, not through the spectrum of the Schrödinger operator.
- **LNS-028c** [question/K; (2,2,0), (k,d,0); steps/schuller] The link of that (2,2) to hyperbolicity is ours.
- **LNS-028e** [question/K; (2,2,0), (k,d,0); steps/schuller] For a general area metric, beyond the cells and the one non-metric example of the package, the question stays open: the 23 algebraic classes of the closure paper are not in the package (source needed).
- **LNS-029** [question/F; (0,0,1), (0,1,0), (1,0,0), 1+1; steps/schuller] In the frozen 1+1 model ε is the sign class of the constant c = (deg P − 1)p¹¹ (P his principal polynomial, p¹¹ the one component of the structure function p^{ab} of (48), frozen to a constant), and both deformations are functions on a line; for d > 1, Witt ⊗ A_ε is not literal. Is there, for d > 1, a family in the sign ε with Euclidean, Carroll-type and Lorentzian members? Open; only the frozen 1+1 model is computed…
- **LNS-030b** [question/F; (1,3,0); steps/schuller] The number eleven is a lower bound of the constructive-gravity article (p. 18), not a count of the closure paper (read, not computed). Do the eleven or more constants of the closure of general linear electrodynamics organise along 6 + 12 + 3, or along the invariant pieces of the 21 (F4)? A check of whether the closure equations respect either split would say; the closure paper sets these equations up without solving …
- **LNS-033b** [lemma/O; (1,3,0), (3,1,0); steps/schuller] Only the lecture video would show whether the printed form is the lecturer’s or the transcript’s; optional.
- **LNS-036b** [question/K; (n,n,0), (p,q,0); steps/schuller] Does a global version exist? That is what row L4 leaves open.
- **LNS-038** [question/K; (2,2,0), (p,q,0); steps/schuller] 2. Chapters 8–11, the finite shadow of the spectral theorem: a largest set of commuting blades of square +1 spans ℝ^(2^w), with 2^w projectors, w the Witt index of the label quadric, and 2^w is the number of simple factors times N (checked for every Cl(p,q) with p + q ≤ 9; the counts are in the category chapter). In Cl(2,2) the nine blades of square +1 form the Peres–Mermin square: six commuting lines whose signs mul…
- **LNS-045b** [question/K; (1,3,0), (k,d,r), r >= 1, (k,d,r), r ≥ 1; steps/schuller] For r ≥ 1 the quadratic principal polynomial is at best weakly hyperbolic: a hyperbolic direction exists exactly when p = 1 or q = 1, never a strict one, with double roots along the kernel (Thm T18(f), every n), and the gradient at a null covector has no component along the null generators. Where smooth null covectors exist (p, q ≥ 1) the polynomial of least degree vanishing on their gradients is linear, the r null c…
- **LNS-045c** [question/K; (1,3,0), (k,d,r), r >= 1, (k,d,r), r ≥ 1; steps/schuller] For a general area metric the map is not computed here: the closure paper states that the three conditions hold only in seven of 23 algebraic classes of area metrics (sect. V C, citing its classification reference), and those classes are not in the package (source needed).
- **LNS-046b** [question/F; (1,3,0), (3,1,0); steps/schuller] Whether a closure that keeps the spinor, beyond its principal polynomial, would see the difference is open: no closure with a spinor exists in either paper (Dirac matter is one parenthesis in the closure paper and absent from the constructive-gravity article).
- **LNS-047** [question/F; (0,0,1), (0,1,0), (1,0,0); steps/schuller] Beyond 1+1, is there a family in the sign ε of the frozen deformation algebra with Euclidean, Carroll-type and Lorentzian members (P3)?
- **LNS-048b** [question/F; (1,3,0); steps/schuller] Do the closure constants of general linear electrodynamics respect the invariant split of the 21, and can a closure keep the tetrad and the spinor (P4, P6)? The closure constants are not examined here: the closure paper does not solve this closure (source needed), and no closure with a tetrad or a spinor exists in either paper.
- **LNS-049** [conjecture/F; (1,4,0), (2,3,0); steps/schuller] Does the sign of Λ follow the square s of the extra generator, Λ ~ −s·κ² (P8)? In the Atlas's geometry the sign does: on Schwarzschild–(anti-)de Sitter frames the Einstein form vanishes for Λ = −3s/ℓ² where space squares −1 (3s/ℓ² where it squares +1), ℓ the scale of the extended connection, a definition and not a relation to G (checked in both conventions). His equations neither confirm nor refute a tie of Λ to s: h…
- **LNS-050** [question/K; (n,n,0); steps/schuller] Is there a global version of base and fibre as left and right actions (P10, row L4)?
- **LNS-057** [question/M; (1,3,0); steps/schuller] His gravity equations need gluing and an action; their derivation (his sections III–IV, the deformation algebra and its linearisation) and their solution for any matter other than Klein–Gordon are not rebuilt (rows C7, C8; L4): open. Evaluating his closure equations needs no action principle of ours: for Klein–Gordon matter his printed equations hold exactly on his printed solution, at three random jet points (checke…
- **LNS-068** [question/M; (1,3,0); steps/schuller] His gravity equations need many small pieces of space glued into a whole, and a rule that picks the motion; where those equations come from, and their solution for other kinds of matter, are not rebuilt: that stays open. His printed equations for one kind of matter (a scalar field) hold exactly on his own printed solution, at a few points: that is checked. (“gluing” is our word: his paper cuts a space that is already…
- **LNS-069** [question/M; ; steps/schuller] Our rule works at one point at a time, with a finite number of switches; spaces with endless directions are out of its reach.
- **LNS-076** [question/M; (1,3,0); steps/schuller] His gravity equations need gluing pieces of space together and a rule that picks the motion; where those equations come from, and their solution for other kinds of matter, are not rebuilt: that stays open. His printed equations for one kind of matter (a scalar field) hold exactly on his own printed solution, at a few points: that is checked. (“gluing” is our word: his paper cuts a space that is already given into sli…
- **LNS-103** [question/M; (1,3,0); steps/schuller] His gravity equations need pieces our rule does not have; where those equations come from, and their solution for other kinds of matter, are not rebuilt: that stays open. His printed equations for one kind of matter (a scalar field) hold exactly on his own printed solution, at a few points: that is checked.
- **LNS-106** [question/F; (1,3,0); steps/schuller] Third condition (energy-distinguishing, row C12): beyond the sampled observers and cells it rests on his statement that for a metric principal polynomial condition 1 implies conditions 2 and 3 (closure paper p. 35). Stone 7 needs an action principle and gluing over a manifold: his closure equations are not rebuilt (rows C7, C8; L4), open.
- **MAP-034** [question/M; (n,0,0); logbook] A plan, not carried out as written: from the spring Lagrangian L = ½|ẋ|² − ½xᵀLx on the cube, put energy on its faces (lattice Maxwell: an edge field A with F = dA), then use the signed edges for Dirac. Parts are done by other routes: the signs of the signed edges are the staggered phases (MAP-026, CAND-047), and Wilson's plaquette energy for su(2) links on the n-cube gives −¼ tr F² at order four in the spacing (CAND…
- **MAP-035** [pointer/M; ; logbook] To read (a plan): Doran and Lasenby (action, rotor mechanics), Roelfs and De Keninck (exponentials in any signature), the lecture video itself, then Lasenby, Todd, Holmer and Mann for conformal dynamics and the visual language. On conformal dynamics one source is partly read, a constrained-dynamics talk (repository abstract and slides): its authors state the equivalence with PGA dynamics, which is not compared term b…
- **MAT-006** [question/O; (0,m,0), (1,3,0); steps/matter] Which representation the model uses. Left multiplication on Cl(0,m) is the spinor-type one; the commutator action gives tensor-type ones, and they are not drawn. The doublets of the standard electroweak theory are left-handed and charged under two groups; chiral coupling is not treated here (the real-linear chirality of the Spin step is not coupled to a gauge field). With a chiral coupling the mass term needs a scala…
- **PAG-006b** [reduction/O; (0,2,0), (1,2,0), (1,3,0), (3,0,0), (4,1,0), (4,2,0); cells] the other names given to cells, and the role names in the card titles (quark, lepton, confinement, electroweak, cosmic horizon, baryon, Leptonic Current Frame, Electroweak Gauge Fiber Ring, and the like), are readings we propose, not results
- **PAG-012** [question/O; ; light] Any link between this calibration and Furey's model is open: none is claimed.
- **PAG-016** [question/O; (0,8,0); matter] Open: which edge is lepton and which Higgs.
- **PAG-016b** [question/O; (0,8,0); matter] Open: what the doubling of every cell means.
- **PAG-016c** [question/O; (0,8,0); matter] Open: chirality (the edges carry colour, isospin and hypercharge, not chirality: FUR-002).
- **PAG-016d** [question/O; (0,8,0); matter] Open: the top-quark irreps as states.
- **PAG-016e** [question/O; (0,8,0); matter] Open: the ℤ₂ parallel (not established through a Witt-torus generator: FUR-004).
- **PAG-032** [question/M; (p,q,0); rule] Pin groups are treated on the labels: the twisted adjoint and the two lifts of a reflection, with the lift of time reversal squaring to +1 in Cl(1,n−1) and to −1 in Cl(n−1,1), n ≤ 6 (CAND-002); the clock as the class of a Pin⁻ structure and the ℤ₈ of the edges of time-reversal-invariant Majorana chains (LAB-018, LAB-021); the invariants of the ten symmetry classes (LNC-076d). Not treated, and open: matching Pin⁺ and …
- **PAG-034** [pointer/F; ; light] Pointer, source unread, recalled and not checked: by Gårding's theorem (Acta Math. 85, 1951) a hyperbolic operator with constant coefficients has a well-posed initial-value problem. What is checked is the hyperbolicity of the symbols themselves: without null generators the wave symbol is hyperbolic exactly for Lorentzian signatures; with null generators a hyperbolic direction exists exactly when one sign occurs once,…
- **RSN-004b** [question/O; n=8; logbook] Whether this A2 acts on generations in another model of the atlas (three copies of the 16, or the 27) is open.
- **SHP-005b** [example/O; (5,5,0); shapes] n = 5, reading and check. The orthoplex language (facets as particles) is ours. As a module of su(3) ⊕ su(2) ⊕ u(1) the even 16 is isomorphic to the 16 carried by six edges of Furey's model, each edge taken in the direction whose weights match: with her model rebuilt exactly, the maps from the 16 even five-bit labels to these six edges of End_ℂ(V) that commute with the action form a complex space of dimension 6, one …
- **SPN-004** [question/O; (3,0,0), (p,q,r); steps/spin] Not checked: the paper's Theorem 1 in general (its bivector form at n = 4: CAND-076), the local Spin(p, q) gauge of the points of plane-based PGA (the points as d-blades: FRQ-M03), the announced real idempotent, complex λ beyond n = 4, the representation-theory framing beyond k = 1, 3 (SPN-M15), and the lecture's reading of |γ|², the squared coefficients of pure spinors, as probabilities: the probability rule it rest…
- **SPN-005** [question/M; (n,0,0), n even, (n,0,0), n odd; steps/spin] The two papers the authors cite for the decomposition are not read, and the lecture is known only from its slides; whether the lecture intends its i for other dimensions is open.
- **YM-006b** [question/O; (0,10,0), (0,2n,0), (0,6,0), (0,7,0), (0,m,0); steps/ym] Which gauge algebra, if any, the model uses: open; so(m) is one choice (INP-034), and other algebras come with one more datum (YM-006). so(p,q) is what grade 2 gives: the bivectors of Cl(p,q) close under the commutator and act faithfully on the vectors as so(p,q) (checked exactly for every signature with p + q ≤ 8).
- **YM-007c** [question/D; (1,3,0); steps/ym] A source of gravity with Λ = 0 whose Yang–Mills field is not an embedded abelian one, its components spanning more than one direction of the gauge algebra (for example an asymptotically flat Einstein–Yang–Mills solution of that kind), is not built: open. With Λ = 0 the Wu–Yang field, whose components lie along one direction of the gauge algebra at every point and whose stress is that of the abelian magnetic monopole,…

## Our readings (status ours)
- **ATL-006b** [example/K; (3,0,0); cells] Reading these three generators as the directions of space on the base is the atlas’s Spatial reading (ours).
- **ATL-010b** [example/K; (1,3,0), (3,1,0); cells] Which of Cl(3,1) and Cl(1,3) is called spacetime is a convention; naming this cell “Minkowski” and reading +1 as space is the atlas’s Spatial reading (ours).
- **ATL-017b** [construction/F; (1,3,0), (3,1,0); cells] Placing electromagnetism at this cell of the atlas (the card name “EM Maxwell”) is ours; no link to Furey’s model is claimed.
- **ATL-023b** [example/A; (0,8,0), (1,7,0), (4,4,0), (5,3,0), (8,0,0), row 8; cells] The name “cosmic horizon” is ours: no horizon, Hubble constant or cosmological boundary follows from this cell; period 8 is a repeat of types, not a wall.
- **ATY-011** [reading/F; (1,3,0); steps/coupling] Why advanced and retarded terms come together (reading, ours). Checked: exp(−τ𝐃) retards the waves exp(−Jk·x) and advances the waves exp(+Jk·x) of the same solution space (ATY-005, n = 3, 4, 5); at rest it retards the half of a field that commutes with γ₀ and advances the half that anticommutes, on fields of the time alone (exact on polynomial fields; ATY-041); and in the action the adjoint of the shift is the opposi…
- **ATY-015b** [reading/F; ; steps/ym] The paper's outlook, a reading and not a result: the infinite curvature limit, curvature read as a pion mass and as a geometric mass term, and a charge-32 instanton for the cubic crystal chunk.
- **ATY-024b** [reading/F; (4,0,0); steps/grav2] Theorem 4.1 read through the engine's Einstein form (our reading): that its Einstein hypothesis is E_a(c) = 0 for every metric of the cell (4,0) is the algebra of GRV-004d, run on Lorentzian frames only.
- **ATY-025** [reading/D; (4,0,0); steps/grav2] Gravitational instantons as limits of edge cones (Atiyah and LeBrun, section 5, read; the paper's statements, not computed here). As β → 2 the family of ATY-022 tends to a double cover of Eguchi–Hanson, and as β → 0 to Taub–NUT; centres in hyperbolic space give multi-Taub–NUT. Hitchin's self-dual Einstein family on (CP², RP²), with β = 2/(k − 2), has ∫|W+|² = 4π²(4 − β²) by the totally real version of the signature d…
- **ATY-047** [reading/F; (1,3,0); steps/coupling] On its quantized solutions the shifted theory is the ordinary Dirac theory of each quantized mass, weighted by 1 − (−1)ⁿμJ (a reading, ours). Checked: on finite sums of quantized plane waves the canonical tensor of the shifted action is that of free Dirac fields of the masses E = m + (−1)ⁿκ, each multiplied by 1 − (−1)ⁿμJ, the factor of the Noether number, with no cross term between two masses (ATY-042; packets of fi…
- **ATY-058** [reading/F; (1,3,0), (1,n−1,0), n = 3…5; shifted] Our reading: if chiral fermions are to be shifted at all, D_s is the variant that admits them. At a null frequency the paper's operator D₊ has no plane wave unless m = κ = 0 (three null frequencies, three (m, κ, τ) with κτ = 1 among them, n = 4; ATY-005); at m = 0, at two null frequencies, D_s keeps the massless solutions and D_c has none in either reading (ATY-007); D₋ is not tested at a null frequency. Chiral repre…
- **ATY-061** [reading/F; (1,3,0), (1,n−1,0), n = 3…5; shifted] Our reading: the shift behaves as a clock. At the quantized shift Eτ = (n + ½)π, exactly where cos Eτ = 0 (ATY-005), the shifted wave is the wave turned by a quarter, (−1)ⁿψJ (ψJ at Eτ = π/2, ATY-009), and on the frame of a constant potential the quantization follows proper time, so that the rest energy of the shifted particle is redshifted like that of any clock, for every n (ATY-037).
- **ATY-062** [reading/F; (1,3,0); shifted] Our reading: the retarded and the advanced half of one spinor at rest are the halves that the paper's remark on Fock space would mix under external forces. What the reading rests on is computed: on the ordinary rest solutions the waves e^{−JEt} lie in the half that commutes with γ₀, which the shift retards, and the waves e^{+JEt} in the half that anticommutes, which it advances (ATY-041, ATY-038); on the quantized mo…
- **ATY-065** [reading/O; (1,3,0); shifted] Our reading: the paper's two constants meet on the labels in one number, μ = κτ (the paper's kr/ħ). What the reading rests on is computed: μ is the size of the deviation: per unit local density the coupling to a uniform potential is E₀(1 − (−1)ⁿμJ), a J part of size μE₀ (ATY-039); two quantized rest energies of one species at one shift, on the branch E = m ± κ, need μ to be an odd multiple of π/2, so |μ| ≥ π/2 (ATY-0…
- **CPL-010** [reading/M; all n; steps/coupling] Drawing the derivative, coupling and mass terms as edges of the cube, and the density and vector current as corners and edges of the demicube, is our reading: an idea we try, not a result.
- **CPL-011b** [reading/F; (1,4,0), (2,3,0); rule] In the Kaluza–Klein reduction at n = 5 the sign of the Maxwell energy is −ε for a fifth generator of square ε, and the sign of Λ₄ is −s for a sixth generator of square s (checked: CPL-011). Reading the sign of the Maxwell energy as the square of one generator of the bit rule is ours; reading both signs as one rule of the algebra, minus the square of a generator, is ours.
- **FRQ-M36** [reading/D; ; steps/forque] The paper's Lagrangian derivation (2.38), I^r I[Ḃ] = B × (I^r I[B]) ↔ not checked: it needs the dual (reciprocal) algebra used for the scalar-product form of the join. The free equation it leads to, I[Ḃ] = B × I[B], is checked as the free case of FRQ-M25 (d = 2, 3, exact power series).
- **FRQ-M37** [reading/D; ; steps/forque] constrained motion: L v F_L = 0 (hinge) ↔ not done: a second, longer computation; the building blocks (inertia map, join) are in place
- **FRQ-M38** [reading/M; ; steps/forque] The ganja.js code, the hypercube, the SAT collision test and the Euler and RK4 integrators ↔ code listings printed as figures in the paper. The equations of motion the listings integrate are checked in FRQ-M25 (d = 2, 3). The listings' expressions (the state derivative of the 2D and 4D listings, the 4D one the hypercube; the free Euler term, gravity, Hooke and damping; the attach line of the hanging-body listings), t…
- **FRQ-M39** [reading/K; (3,0,1); steps/forque] The closed forms for the exponential and the logarithm of a 3D motor (De Keninck) ↔ not checked: the paper gives them only as a figure of code (Chapter 1.5, Fig. 1.3).
- **FRQ-M40** [reading/D; ; steps/forque] Exercises and solutions (Appendix D) ↔ D.1 and D.2, as the translation matrix records them (the 2D inertia of a rotation about the centroid and of a translation), are the cases v = 0 and B = 0 of FRQ-M20, checked in d = 2, 3, 4; the other exercises are not read line by line and not checked.
- **FUR-014** [reading/A; (1,3,0) ⊗̂ (0,6,0), (1,3,0) ⊗ (0,6,0); matter] The owner writes 'left/right, fibre/base' beside the splits of a block. That his left and right are these two actions is our reading, as the names base and fibre are (LNS-054, LNS-115). Which product, split or signature a physical system uses is an input, as the signature is (INP-011): nothing here says that nature uses either.
- **FUR-591** [reading/O; ; matter/papers] Our reading of the three papers side by side: 2023 gives one generation as the 16-dimensional complex space Ψ_L; 2024 gives two generations as two 32-dimensional real spaces and the third as a factorized product; 2026 puts matter in the cells of End(V) for V of real dimension 16, and Fig. 1 shows three generations except the top-quark representations, to be recovered from the extra b′_R, h′ and τ′_R. In the 2024 and …
- **FUR-608** [reading/O; (0,8,0); matter/generations] Our reading of the caption of Fig. 1 against these counts: its “three generations apart from the top” reads as two complete sets plus the d_R, L and e_R of a third. The third copy of ν_R is also absent (checked), which the caption does not mention.
- **FUR-618b** [reading/O; all n; matter/generations] The labels of the bit rule form the group (ℤ/2)ⁿ, in which every label is its own inverse, so it has no element of order 3. Our reading: no cyclic permutation of three generations is an operation of the labels alone; it would need a symmetry of order 3 acting on the labels or an input from outside them, a triality for instance.
- **FUR-619b** [reading/O; (0,8,0); matter/generations] The maps of V that commute with the associative algebra Δ_SM (31 real dimensions) form a 12-dimensional algebra with nothing between blocks: a complex scalar on each of the first four blocks and a 2 × 2 real matrix on the last. On the edges of Q_L, u_R and L it acts as one complex scalar, so it only rephases them; the edges of d_R and ν_R touch the last block, and so does the edge of e_R type that Fig. 1 labels τ_R (…
- **FUR-630** [reading/O; ; matter/help] Our reading: the 2024 Cartan factorization and the 2026 recombination of b′_R, h′ and τ′_R play the same role, a last generation made of lower pieces. A comparison at the level of representations, not only of quantum numbers, would need her explicit factorization of V.
- **GEN-006b** [reading/A; (2,2,1); rule] Pair-Block Plus Spectator: the name, and reading this cell as the next rung of the genesis with the role of node 3, are ours.
- **GEN-016** [reading/A; (8,0,0), (p,q,r), n ≤ 8, at n + 8, row 8, row 16; rule] The finite block is all the limit keeps (our reading). The owner asks whether the infinite chain … ⊗ M₁₆(ℝ) ⊗ M₁₆(ℝ) ⊗ … singles anything out, and whether it is the chain … ⊗ M₂₅₆(ℝ) ⊗ …. Checked, exact: on the labels a stage of the chain is a prefix of an infinite label; for every cell with n ≤ 8 and each of the three clock-0 blocks of row 8, the clock p − q mod 8, the type of the semisimple quotient with its matrix…
- **GOS-511b** [reading/K; (16,0,0); shapes] Rank 16 has two even unimodular lattices, E8 ⊕ E8 (E8 twice) and D₁₆⁺ (whose roots are the edges only): Witt's classification, recalled, not computed here. This is a reading, not proven yet in the Atlas.
- **GRV-010b** [reading/F; (1,3,0), (1,n−1,0), n = 3..5, n = 3…5; steps/grav2] The pictures and the bit-rule reading of this form are ours.
- **LAB-011** [reading/A; (p,q,1), n = 4, row 4; steps/groups] Two readings of ours, named and not stated: the finite shadow of a translation, and the Klein link at n = 4; which computed facts they read is not stated.
- **LAB-505b** [reading/K; (n+2,0,0), (1,3,0); clock] That a compact Spin(n+2) therefore cannot contain the non-compact Spin(1,3) is recalled, not computed here: our reading until a check or a read source settles it.
- **LNB-001b** [example/O; (5,5,0); steps/baez] Calling those labels one generation of particles, and the bits weak and colour, is our reading; the labels add no physics. That they model the paper's pieces is checked: they fall into its six Peirce pieces with Y and Q as bit counts (LNB-001), and with su(2) on the weak bits and su(3) on the colour bits they carry the su(3) + su(2) content the paper gives for one generation, (3,2), (3̄,1) twice, (1,2) and (1,1) twic…
- **LNB-005b** [example/O; (5,5,0); steps/baez] B.4 (reading) Taking these classes as the reason why exactly six pieces occur is ours.
- **LNB-014f** [example/O; (5,5,0); steps/baez] On the labels the Peirce value is 1 − d/4, so the six non-empty classes are the six pieces (checked: baez·H2a). Taking this as the reason why only those pieces occur, and calling the flip charge conjugation, is our reading; what the flip does is checked: it exchanges the 16 and the 16̄ and negates every weight, Y and Q among them (baez·H1b, baez·H2c; CAND-062).
- **LNB-016g** [computation/K; row 8; steps/baez] Reading the ladder as the generation assembled rung by rung is ours, and so is the remark that neither paper states the split of each rung by the subalgebra; the split itself is checked: under the E7 paper's su(3) + su(2) the rungs hold (3,2); then also (3̄,1) and (1,1); then the content of one generation; then eleven more states, each rung's content containing the previous one's (baez·S1; LNB-016f).
- **LNB-016i** [reading/K; row 8; steps/baez] The E7 paper’s Table 1 reads (3,1) + (1,2) and (3̄,1) + (1,2̄) as the SU(5) Higgs multiplets; whether the rest has a role, the Jordan-pair paper’s Section 5.2 leaves open.
- **LNB-023f** [computation/D; (0,2,0), (0,3,1), (0,4,0), (1,3,0), (3,0,1), (3,1,0), (4,0,0), (4,2,0); steps/baez] The comparison with the spring is ours: the spring’s signs are the squares of bivectors, a different thing from the square of a generator; the sorting of squares is set out on the Conventions page.
- **LNB-023k** [computation/D; (0,2,0), (0,3,1), (0,4,0), (1,3,0), (3,0,1), (3,1,0), (4,0,0), (4,2,0); steps/baez] That one author uses so(4,2) for hydrogen and so(6,ℂ) for matter, in two papers, is our remark, not a theorem.
- **LNB-024b** [computation/O; (n,n,0); steps/baez] In the paper's second quantisation a state of N electrons is a set of N orbitals, N set bits among the orbital labels: the structure of J1 and J2, checked for fermions in labelled modes (a state is a subset of a labelled set, the number operator is the popcount: baez·H3a, baez·H3b; for any finite number of modes, Thm T20). That a prefix of N bits in the Madelung order is a ground state (inside the last, partly filled…
- **LNB-025** [reading/A; (0,0,r), (p,q,r), n ≤ 4; steps/baez] The cospan paper composes open systems by identifying variables. A label counterpart: two blades that share a bit are multiplied by contracting that bit with the square of its generator (+1, −1 or 0) and gluing the unshared bits by XOR, e₁e₂ · e₂e₃ = ε₂ e₁e₃. This is one line of the bit rule, not a computation of any double category.
- **LNB-025d** [reading/A; (0,0,r), (p,q,r), n ≤ 4; steps/baez] Reading the cospan paper's “commutative Frobenius monoid” as this form is ours. For p + q ≥ 1 it pairs unlike things: the label algebra is not super-commutative, its super-centre being Λ(ℝ^r), and from two generators on it is not commutative either (checked: CAND-058, derived for every n, exact for n ≤ 7); the null part Λ(ℝ^r) is super-commutative and its top form has parity r mod 2, so that it is a commutative Frobe…
- **LNB-026c** [dead-end/M; (9,0,0); steps/baez] An example it does not carry, our reading: the 16 even labels would be tied to that 16 only through how the two Standard Model embeddings relate. Computed on the roots, for the regular embeddings and at the level of Lie algebras, the two are not related through Spin(9) ⊂ Spin(10): the Albert-algebra copy lies in an so(9) = f₄ ∩ so(10), while the E7-paper copy, under which the 16 even labels carry the content of one g…
- **LNB-030b** [reading/M; (5,5,0); steps/baez] Would a one-line dictionary, Peirce value = 1 − d/4 on five-bit labels, be a useful remark beside Section 5.1 of the Jordan-pair paper?
- **LNB-031b** [reading/M; ; steps/baez] Is the su(3)+su(2) content of each rung, (3,2) first and one generation at the bi-Cayley rung, worth a table beside the two papers’ chains?
- **LNB-032b** [reading/M; ; steps/baez] Is it worth one sentence that the lattice in the proof of Lemma 2 is the lattice of Thurston’s stars?
- **LNB-047b** [reading/O; (5,5,0); steps/baez] Reading the 16 even labels as one generation of particles is our reading.
- **LNB-053f** [example/O; (5,5,0); steps/baez] The six groups and their charges are in the paper and in textbooks. What the switches add is checked: the groups are a way of counting, the classes by how many weak and how many colour switches are on, and each charge is a count (baez·H2a, baez·H2c). Reading the switches as particles is our idea.
- **LNB-055c** [computation/D; (3,0,1), (3,1,0), (4,0,0); steps/baez] Seeing the spring’s signs (turn, slide, stretch) in the three orbits is our reading.
- **LNB-057c** [computation/O; ; steps/baez] Seeing each electron as a switch turned on is our reading.
- **LNB-105** [reading/O; (5,5,0); steps/baez] Calling the even ↔ odd flip charge conjugation is ours.
- **LNB-122** [reading/O; ; steps/baez] Reading the ladder as building a generation step by step is ours; the labels 3 and 3̄ depend on a sign convention for the weights.
- **LNB-128** [reading/K; (3,0,1), (3,1,0), (4,0,0); steps/baez] Naming each move by its square (−1 turn, 0 slide, +1 stretch) is ours; reading ε as the spring’s signs is a different thing (the spring’s signs are squares of bivectors, ε is the square of a generator).
- **LNB-131** [reading/K; (3,0,1), (3,1,0), (4,0,0); steps/baez] Seeing the spring’s signs here is our reading.
- **LNB-143** [reading/K; ; steps/baez] Linking the two papers through the 27 is ours, with a computation behind it: the E7 paper's 27 has the same Jordan frame data (3,8,0) and the same f₄-content 1 + 26 as the Albert algebra h₃(𝕆) (jrd·14, jrd·12, elad·6, jrd·5), and the pair construction of h₃(𝕆) is a simple algebra 27 + 79 + 27 of dimension 133 (jrd·7, jrd·8), graded as e₇ is (baez·E1c). That the E7 paper's 27 is then h₃(𝕆) ⊗ ℂ, the geometry paper's h₃…
- **LNB-146** [reading/M; ; steps/baez] That one author uses so(4,2) for hydrogen and so(6,ℂ) for matter is our remark.
- **LNB-148** [reading/K; (n,n,0); steps/baez] Reading the two as one structure is ours; no computation says they are the same physical space.
- **LNB-158** [reading/K; ; steps/baez] No citation: both papers have a set of 27 things, and more than the number matches: the E7 paper's 27 has the same Jordan data as the Albert algebra, whose pair construction gives a simple algebra of dimension 133 (checked). That the two are one rests on a recalled classification, so linking them stays our idea.
- **LNB-161** [reading/M; ; steps/baez] That one author uses it for atoms and for matter is our remark.
- **LNB-162** [reading/K; (n,n,0); steps/baez] Both papers count states as patterns of switches: the states over n orbitals of one and the 32 states of the other (n = 5) are label sets of n bits with the algebra Cl(n,n) acting (checked); seeing them as one thing is our reading.
- **LNB-175** [reading/O; (n,n,0); steps/baez] Reading a ground state as the first N set bits of the orbital labels is ours.
- **LNB-176** [reading/O; (n,n,0); steps/baez] Seeing electrons as switches turned on is our reading.
- **LNC-022** [reading/A; (0,n−2,1), (3,0,1); steps/category] Reading these unpaired nulls of steps 11 and 13 as one object, “label 0”, is ours: the algebra is computed, the physics is not.
- **LNC-053** [reading/A; n = 3 (cube category); steps/category] “Label 0 first appears in the category itself at n = 3” reads the null directions of the Euler form as a label 0: that reading is ours.
- **LNC-073b** [reading/M; (p,q,r); steps/category] Reading the moves as steps “up and down” a ladder of boxes is ours.
- **LNC-074b** [reading/M; (10,1,0), (8,0,1), (9,1,0), E₁₀ (9,1,0), E₁₁ (10,1,0), E₉ (8,0,1); steps/category] Any reading of rung 9 beyond its signature is ours (the honest list says which).
- **LNC-094** [reading/M; ; steps/category] The word “category” for this lens, the moves “up and down” a ladder, and rung 9 as “the boundary” between the definite and the Lorentzian rungs are our readings.
- **LNC-095** [reading/A; (p,q,r); steps/category] The three values of a generator’s square, −1, 0, +1, move the clock back, leave it, move it forward (checked, cat·K4a). That this is the same three-way sorting as in the Baez and Schuller chapters, each beside its own check (there the squares of elements and of bivectors), is our reading.
- **LNC-096** [reading/O; (p,q,r) r≥1, n = 3 (cube category); steps/category] With the transpose as the involution (an input, T15), the *-closure of Cl(p,q,r) is Cl(p+r,q+r), with the same clock (checked for every cell with n ≤ 4, in floating point, bd·sol·12); that a null generator is therefore absent from the tenfold way is our reading. The Euler form of the cube category is definite for n ≤ 2 and has two null directions at n = 3 (checked, LNC-058); at n = 3 the category is tame and derived …
- **LNC-104** [reading/M; ; steps/category] Calling the lit corners “where the zero hides” is our picture; what a zero switch means in nature we do not claim.
- **LNC-116** [reading/M; ; steps/category] “Up and down” a ladder of boxes is our reading.
- **LNC-119** [reading/A; (p,q,r); steps/category] Reading the four moves as “up and down” a ladder is ours. The moves themselves are checked in LNC-041: restrict, quotient and mother are Cl applied to maps of quadratic spaces, and halving is a natural isomorphism on pointed quadratic spaces (bd·cat·16–17).
- **LNC-126** [reading/M; (8,0,1), E₉ (8,0,1); steps/category] Seeing rung 9 as the border is our idea.
- **LNC-132** [reading/M; (8,0,1), E₉ (8,0,1); steps/category] Calling n = 9, the only rung with a null direction, the “boundary” between the definite and the Lorentzian rungs is ours.
- **LNP-003** [reading/M; ; lenses] the category language, “up and down”, rung 9 as the boundary, the reading of the squares −1, 0, +1 as one three-way sorting across the chapters (the square of a generator, of an element or of a bivector: see step 1 and the Conventions page), the reading of the unpaired nulls of steps 11 and 13 as one object, label 0, and of the null directions of the cube category at n = 3 as a label 0 (checked: the null normal spans…
- **LNS-010e** [computation/F; (1,3,0), (3,0,0), (3,1,0); steps/schuller] Reading the atlas as running his chain the other way is ours: its steps 9 and 10 start from the tetrad, the curvature and the Einstein form and check them, where he reaches the gravitational action by closure.
- **LNS-011d** [theorem/A; (0,0,n), (1,3,0), (2,2,0), (3,1,0), (4,0,0), (p,q,r), all, all n; steps/schuller] The notes go from chapter 12 (forms) to chapter 15 (SL(2,ℂ)) without naming a Clifford algebra; one table could sit between them.
- **LNS-012e** [theorem/K; (1,1,1), (1,3,0), (2,2,0), (3,1,0), (k,d,0), (k,d,0), n = 2..7, (k,d,r), (k,d,r), n <= 6; steps/schuller] Drawing the filter as a map of cells is ours.
- **LNS-014d** [example/F; (0,0,1), (0,1,0), (1,0,0), 1+1; steps/schuller] This is a frozen flat 1+1 model, not his equations (48)–(50), whose structure functions depend on the phase space. Reading ε = +1 as the light cone, and the two Virasoro copies as the left and right movers of a closed string (a textbook picture; pointer, source unread), is ours, and so is grouping the three values of the generator’s square, −1, 0, +1, with the other three-way sortings of squares in the atlas (see the…
- **LNS-016c** [computation/A; (0,8,0), (0,k,0), k = 0..8, (0,k,0), k ≤ 8; steps/schuller] That the fibre of the physical Lorentz base is this commutant, and what lives in it, is our reading, not tested. What is checked is the algebra: the Cl(4,4) that the Lorentz base Cl(1,3) and its twisted right action make on its sixteen labels and the Cl(0,8) on which the commutant ladder runs are both M₁₆(ℝ) (in each the 256 products span all real 16 × 16 matrices), so they are isomorphic as algebras; the generators …
- **LNS-017f** [computation/F; (1,3,0), (1,3,0) + fibre (f₊,f₋), (1,3,1), (1,4,0), (2,3,0); steps/schuller] Reading the mass as coming from the descent of F11 is ours; nothing here says which direction a physical mass is.
- **LNS-019g** [theorem/K; (0,0,n), (2,2,0), (2N,0,0), (n,n,0); steps/schuller] Linking that (2,2) to the first ultrahyperbolic cell of the hyperbolicity map is ours.
- **LNS-022e** [theorem/D; (2,0,0); steps/schuller] Grouping band, edge and gap (the sign of X², the square of an element) with the other places of the sign trio −1, 0, +1 is ours.
- **LNS-027** [reading/M; (0,0,n), (1,2,0), (1,3,0); steps/schuller] The geometry lecture notes go from forms (ch. 12) to Lie groups, SL(2,ℂ) (ch. 15) and the Casimir (ch. 17), and from chapter 12 to chapter 15 without naming a Clifford algebra. Would one table (F1), which puts SL(2,ℂ) at a computed address (F5), be a useful bridge between them?
- **LNS-031b** [definition/K; (0,0,n), (n,n,0); steps/schuller] Bit label = occupation pattern is our reading.
- **LNS-035b** [reading/D; (2,0,0); steps/schuller] Setting them beside the frozen deformation algebra (F3) is ours.
- **LNS-036** [reading/K; (n,n,0), (p,q,0); steps/schuller] A local algebraic counterpart of his bundles, as our reading: on the labels of a non-degenerate cell A the plain right action commutes with the left action and is its commutant, isomorphic to A, of the same type, and the twisted right action is the mirror cell, which with the left action fills End(A) = Cl(n,n) (checked for every cell with n ≤ 5; F10, F11).
- **LNS-043** [reading/O; (2,0,0); steps/schuller] F13. The trace is written ψ₁(a) + ψ₂(a) where the band condition uses ψ₁(a) + ψ₂′(a): our reading of a slip in the transcript.
- **LNS-054** [reading/M; ; steps/schuller] The names base and fibre, outside and inside, are ours.
- **LNS-056** [reading/D; (1,4,0), (2,0,0), (2,3,0), (n,0,0), (n,0,1); steps/schuller] Bands, orbits and springs as one trio −1, 0, +1 is ours (the bands and the springs sort the square of an element, the orbits the square of the extra generator); so is Λ ~ −s·κ², neither confirmed nor refuted by his equations.
- **LNS-063b** [reading/M; ; steps/schuller] The other stones match only in shape, or only as our reading: how close each one comes is our judgement, shown stone by stone.
- **LNS-065** [reading/M; ; steps/schuller] Calling them outside and inside, and what they are in physics, is our reading.
- **LNS-066** [reading/K; (0,0,n), (n,n,0); steps/schuller] Reading a corner of the cube as a pattern of full seats is our reading.
- **LNS-067** [reading/D; (2,0,0); steps/schuller] Seeing here the same three signs as the switches have (minus, zero, plus) is our reading.
- **LNS-073** [reading/M; ; steps/schuller] The names outside and inside are ours.
- **LNS-075** [reading/D; (2,0,0), (n,0,1); steps/schuller] Bands, orbits and springs as one trio of signs is our reading.
- **LNS-115** [reading/K; (p,q,0); steps/schuller] Base as the left action and fibre as a right action (twisted: the mirror; plain: the commutant that the slider steps through), and calling them outside and inside as on page 1, is our reading of his local product (F10, F11); how fibres are glued over a manifold is the gap L4.
- **LNS-121** [reading/F; (1,3,0), (1,4,0); steps/schuller] Reading the mass as a momentum along a fibre direction, as the content of the descent of finding F11, is ours.
- **LNS-123** [reading/D; (2,0,0); steps/schuller] Calling these three cases “the spring’s signs” is our reading.
- **LNS-128** [reading/D; (2,0,0); steps/schuller] Grouping band, edge and gap (the sign of the square of an element) with the other homes of the trio −1, 0, +1 is ours.
- **LNS-133** [reading/K; (0,0,n), (n,n,0); steps/schuller] Reading a bit label as an occupation pattern is ours.
- **MAP-001b** [theorem/A; (1,1,0), (1,3,0), (3,1,0), all n; logbook] Taking three starting ideas as the rule (A a null seed, n² = 0; B polarization, an extra datum; C a budget of 8, the scope of the tour of eight switches: n bits, 2ⁿ blades, Cl(k,k,r)), and reading the signs as space or time, are ours. In B a conjugate null pair n, ñ (n² = ñ² = 0, nñ + ñn = 1) gives e = n + ñ with e² = +1 and f = n − ñ with f² = −1 (ATL-002b, checked). Which sign is called time is a convention (INP-01…
- **MAP-025b** [reading/K; (1,3,0), (2,0,0) to (7,0,0), (p,q,0); logbook] Our readings: ⊞ identification, left/right/conjugation label, self-dual code, XOR 9 chirality.
- **MAT-008** [reading/M; (0,m,0); steps/matter] The incidences are checked (MAT-001): the gauge algebra of step 7 acts on the internal blades through the demicube edges of the internal cube. Reading the gauge action as edges of the internal demicube, the gauge terms as products of a space-time cube edge and an internal edge, and the current as pairs of space-time corners, as a picture of the physics is our reading.
- **MIR-008** [reading/K; (1,1,0), (1,2,0), (1,3,0); steps/mirrors] The even labels of n switches are the corners of the n-demicube (MIR-001, exact for n = 2 to 6), and at n = 2, 3, 4 the planes are the corners joined to the identity by an edge, the edges joining labels two switches apart (MIR-031; at n = 4 the 16-cell with the six planes as its equator, EQN-002); in Cl(1, n−1), n = 2, 3, 4, two mirrors in one coordinate plane make a move whose weights sit on the two ends of that edg…
- **PAG-003** [reading/M; ; rule] Which prime names which switch is a choice, and nothing is read into the names beyond the label they name: our reading.
- **PAG-023** [reading/M; all n; steps] Reading the derivative and coupling terms as edges and corner simplices of the cube is our reading
- **RIG-003** [reading/M; (3,0,1); steps/rigid] The arrangement of the page is our reading: the rigid body read through one label, the balance, the contact and the outline laid out as bit rules, and the spring, the Euler term and the top read as the three kinds of i.
- **RSN-012** [reading/A; (0,1,0), (1,1,0), (3,0,0), (7,0,0); logbook] (scalar, 1-vector): the Cl(0,1) mirror unit; with one generator of square −1, +1 or 0 these form the complex, split-complex or dual numbers. (scalar, 2-vector): the bivector unit of the even part, of square −ab. (1-vector, 1-vector): the odd carrier plane x∘y = xuy, an algebra only after choosing u (unital, associative, isomorphic to the even part by x ↦ xu, of the same kind for every u), split-complex for Cl(1,1). T…
- **RSN-016** [reading/A; (0,k,1), (0,n-2,1); logbook] That “by contrast with the induced-metric approach” is a difference of presentation, and the reading of the ideal J as a facet of the cube and as the star of a vertex. Neither is computed.
- **RSN-018b** [reduction/K; all n, n=4; logbook] That Weyl’s first appearance and the 4-vector part of B² share a cause is a reading, not a theorem.
- **RSN-028c** [computation/K; (1,3,0); logbook] Calling the slice b = 0 the pointors of Roelfs, Eelbode and De Keninck, and writing the chirality as XOR 9 of the bit rule, is our reading.
- **SPN-003** [reading/M; (1,3,0), (n,0,0); steps/spin] The side-by-side reading is our work: the ⊞ identification of the lecture's B + i with the paper's idempotent, the left/right/conjugation label as one label, the table of the four kinds of i as what the sources call i, the XOR 9 action read as the chirality, and the common rotor as the condition the paper's theorem needs. It is marked as such in the remarks of the matrix lines.
- **SPN-M24** [reading/K; ; steps/spin] Theorem 1 (invariant decomposition) ↔ the paper's Theorem 1, cited there from Roelfs and De Keninck and from an article in preparation, neither of them read: a product of ℓ reflections factors into ⌈ℓ/2⌉ commuting simple factors. An input from the paper, not checked: only products already in that form (the b_j) are computed. Computed beside it at n = 4 (exact, CAND-076): over the reals every non-simple bivector with …
- **SPN-M25** [reading/K; (p,q,1); steps/spin] §2.1, §2.2, §2.5, §4: points as d-blades, geometric gauge Spin(p,q) at every point ↔ the paper's statement that in plane-based PGA points are d-blades, with a local Spin(p, q) gauge from the non-uniqueness of the factorisation. Checked exactly in Cl(d,0,1), d = 2, 3, 4, on the forque step: a point is a d-blade, the meet of d planes (FRQ-M02, FRQ-M03). The gauge, and points in the other signatures Cl(p,q,1), are the p…
- **SPN-M26** [reading/K; ; steps/spin] §3.3 (end), §4 ↔ the paper announces a specific real idempotent, the construction of “spinors” from pointors by throwing away the distinction between the $b_j$, for a separate paper. Not available here; not checked.
- **SPN-M27** [reading/K; (2,2,0); steps/spin] §2.4 footnote 1 ↔ the paper's remark on more exotic cases when λ is not real, in signatures such as ℝ^{2,2}. Checked at n = 4: non-real roots occur only in Cl(2,2) (T17 (c)); the authors' Riesz-type example there has λ = ±i/2 and splits into commuting b₁ + b₂ with exp(B) = exp(b₁)exp(b₂) (RSN-013); over the reals 256 of the 484 non-simple bivectors of Cl(2,2) with entries −1, 0, 1 have non-real roots and no split int…
- **SPN-M29** [reading/O; ; steps/spin] slides “Typical metaphor: probabilities”, “Final recap” ↔ the lecture reads |γ|², for the weight γ of a pure spinor in a sum Φ = γ₁Φ_σ + γ₂Φ_τ, as the probability of being in a pure state, with the cats, and says this “requires an interpretation”: the lecture's interpretation, an input, not checked. The probability rule from the scalar-part trace is checked: in Cl(3,0) the density elements ρ = (1 + v)/2 with |v| ≤ 1 …
- **SPN-M30** [reading/K; ; steps/spin] slides “Linear algebra to the rescue”, “What is a representation?”, “Somewhere on a GAME…” ↔ the lecture takes representation theory as the frame (basic fact 1: spinors live in a linear space on which rotors act as linear maps) and names a group by the three letters N, C, A: framing from the lecture, an input, not checked in general. Checked exactly for k = 1 and 3, in Cl(3,0) and Cl(7,0): the spinors form a complex …
- **SPR-003** [reading/D; (n,0,0), n = 2…5; steps/spring] The arrangement: masses, springs and closure as the three lenses of one cube; the reading of the signs as flux π through the faces; the reading of the step 5 labels as normal modes.
- **SRC-001b** [reading/A; (2,0,0), all n; logbook] Our verdict: v2 is a dead end as written, and our quiver-form reading survives, tagged ours (grade A); in v3 the squares, the clock and the null part have no counterpart (its inner product has signature (2,0) on every category tested, bd·mjp·30).
- **SRC-003c** [reading/A; all n; logbook] Reading this as a precise form of the comma hierarchy is ours. The group CS(ℤ) and the modulators are not examined.
- **YM-008** [reading/M; (0,m,0); steps/ym] The incidences are checked (YM-003): the generators and their commutator pairs are corners and edges of the demicube, and the number of ‘2–2’ edges equals the number of terms that do not vanish in [B, B]. Reading the gauge generators as corners of the demicube, their pairs that do not commute as its edges and the closed index triples as triangles of the simplex, as a picture of the physics, is our reading.

## Standard (cited, not recomputed) rows
- **ATL-018** [(1,n-1,0); cells] For a frame map h, the strain is S = hᵀηh − η. It vanishes exactly when h preserves the metric η (a Lorentz map), and for h = 1 + ε its trace to first order is tr(η⁻¹S) = 2 tr ε, twice the first-order volume change. — ref: linear algebra of the metric pull-back (any GR text on the tetrad); no single theorem needed; Schwartz, Fast probabilistic algorithms for verification of polyno…
- **ATY-024** [(4,0,0); steps/grav2] Checked: E_a(c) = 0 exactly where the trace-free Ricci tensor vanishes, Ric = −3cη, as an identity on 21 torsion-free Lorentzian frames, n = 4 (GRV-004d); in the cell (4,0), E_a(c) = 0 on the Einstein metrics S⁴ (c = −1) and CP² (c = −2) at three points each (ATY-018), and the edge-cone family (5.4)… — ref: M. Atiyah and C. LeBrun, Curvature, cones and characteristic numbers; I. M. Singer and J. A. Thorpe, The curvature of 4-dimensional Einstein spaces (recalled)
- **EQN-003** [(p,q,0); steps/comm] What this is. The structure constants of so(p,q). A non-abelian field strength F = dA + A∧A needs a gauge algebra, and so(n) is one choice whose structure is exactly this graph. Other Lie algebras are not covered. — ref: Hestenes, Space-Time Algebra; textbook so(p,q) structure constants
- **FRQ-002** [(0,3,1), (3,0,1); steps/forque] The equations themselves are the paper’s; the bit-rule product, the join as the inverse star of the wedge of stars (the star is the signed complement, a Frobenius pairing for every signature; with the null generator e₀² = 0 it is not a metric Hodge star), and Newton–Euler are textbook. The energy of… — ref: Dorst–De Keninck, PGA dynamics paper (as cited by the atlas)
- **GOS-004** [(1,3,0); shapes] Maxwell view. Nothing comes back. F is a bivector of four generators and E8 needs sixteen. — ref: Coxeter, Regular Polytopes (k_21 polytopes); Bourbaki, Lie Groups Ch. VI
- **LAB-010** [(24,0,0); steps/groups] uniqueness of the Golay code, simplicity of the large groups, the orders of Co_{1} and the Monster, Monster ⊃ 2^{1+24}.Co_{1} — ref: Lundholm–Svensson, KTH notes (rev. 2016), Thm 5.5 and Table 5.1; Lawson–Michelsohn, Spin Geometry, Ch. I §4
- **LNB-001d** [(5,5,0); steps/baez] Real representations are vector-like (compared here at Lie-algebra level only); the chiral 16 is the one of the bi-Cayley triple, under the E7 paper’s differently embedded su(3)+su(2). — ref: Baez–Bokor–Boyle, arXiv:2607.10833; Baez–Schwahn, arXiv:2606.15235; Baez, arXiv:2608.06271
- **LNB-014** [(5,5,0); steps/baez] Baez, Bokor and Boyle cut the 16 complex dimensions of the bi-Cayley triple with the Peirce projectors of two colinear minimal tripotents and find six non-vanishing pieces of dimensions 1, 1, 6, 3, 3, 2, the six irreducible pieces of one generation (their eqs. (69), (75), (76)), and three combinatio… — ref: Baez–Bokor–Boyle, arXiv:2607.10833, eqs. (69), (75), (76); anomaly cancellation (textbook)
- **LNB-014g** [(5,5,0); steps/baez] What this is not: a new result about the Standard Model. The six pieces and their hypercharges are in the paper; the names of the pieces follow its eq. (69). — ref: Baez–Bokor–Boyle, arXiv:2607.10833, eqs. (69), (75), (76); anomaly cancellation (textbook)
- **LNB-015f** [(5,5,0); steps/baez] Convention: the colour Dynkin label (1,0), one colour bit set, is called 3, and (0,1), two colour bits set, is called 3̄; the names 3 and 3̄ depend on this sign convention. — ref: Baez–Bokor–Boyle, arXiv:2607.10833, Table 1, Section 2.4; Jordan–Wigner, canonical anticommutation relations (textbook)
- **LNB-016c** [row 8; steps/baez] The chain from e₇ down is the E7 paper’s Table 2, and the chain of triples M₃,₂(ℂ) < a₅(ℂ) < bi-Cayley < Albert is the Jordan-pair paper’s Table 3 and eq. (77); the E₈ end (240 roots, the 56) is in neither paper. — ref: Baez, arXiv:2608.06271, Table 2; Baez–Bokor–Boyle, arXiv:2607.10833, Table 3 and eq. (77); Bourbaki (E8 simple roots); Loos (Jordan pairs)
- **LNB-017** [; steps/baez] In the E7 paper the roots of e₇ orthogonal to g_SM form an A₂, the generation sl₃, and the 126 roots are sorted by their orthogonal shadows on its plane P: Lemma 2 gives three kinds of shadow and Lemma 3 their counts; the three lines through ±w_k index the three so(12) + sl₂ and the three 32-dimensi… — ref: Baez, arXiv:2608.06271, Lemmas 2–4, Prop. 5, Thm. 12; Baez, arXiv:2606.10072
- **LNB-021f** [; steps/baez] Real representations are vector-like; the chiral generation is the 16 of the bi-Cayley triple under the E7 paper’s differently embedded su(3)+su(2). The Jordan-pair paper’s introduction already says that the F₄ line has not reached the chiral structure of the fermions; the table puts numbers on the … — ref: Baez–Schwahn, arXiv:2606.15235, Theorems 1 and 2, proof of Lemma 4
- **LNB-022c** [(1,9,0), (5,5,0), (9,0,0), (9,1,0); steps/baez] The triangulation note counts triangles with a hermitian form on ℂ¹⁰ of signature (1,9) and asks whether the resemblance to ten-dimensional Minkowski space is a coincidence (“I do not know”). — ref: Baez–Schwahn, arXiv:2606.15235 (h2(O)); Baez, arXiv:2606.10072; mod-8 type table (Lounesto; Thm T4)
- **LNB-023j** [(0,2,0), (0,3,1), (0,4,0), (1,3,0), (3,0,1), (3,1,0), (4,0,0), (4,2,0); steps/baez] The complexification so(6,ℂ) = 4 + 7 + 4 is the 3-graded algebra of the type BDI triple ℂ⁴ of the Jordan-pair paper (n = 4) and of A III with (p, q) = (2, 2); the paper’s Tables 1 and 2 list the complex algebra and its compact form, not so(4,2). — ref: Baez, arXiv:2507.11428, eqs. (6), (9), (12)–(14), Section 5.1; Baez–Bokor–Boyle, arXiv:2607.10833, Tables 1 and 2
- **LNB-024c** [(n,n,0); steps/baez] The Madelung rules are an approximation for real atoms, as the paper says; the exceptions and the relativistic and screening corrections are a gap of the matrix (K.8). The Weyl equation on ℝ × S³ and the unitary equivalence of the Hilbert spaces are analysis the atlas does not touch. — ref: Baez, arXiv:2507.11428 (Madelung rules)
- **LNB-053** [(5,5,0); steps/baez] Physicists sort the particles of one family into six groups. Baez, Bokor and Boyle find the same six groups, of sizes 1, 1, 6, 3, 3 and 2, in their paper. — ref: the seven papers as cited; textbook particle physics
- **LNB-055** [(3,0,1), (3,1,0), (4,0,0); steps/baez] A planet around the sun, or the electron of a hydrogen atom, can loop forever, just escape, or fly past. Baez’s paper studies the loops. — ref: the seven papers as cited; textbook particle physics
- **LNB-057b** [; steps/baez] Real atoms sometimes break the rule: it is an approximation. — ref: the seven papers as cited; textbook particle physics
- **LNB-114** [; steps/baez] Real representations are vector-like; the comparison here is at Lie-algebra level only. — ref: Baez–Schwahn, The Standard Model Gauge Group from the Exceptional Jordan Algebra, arXiv:2606.15235, Lemma 4, Thms 1–2; Baez, Three Generations in E7, arXiv:2608…
- **LNB-129** [; steps/baez] A planet, or hydrogen’s electron, loops round, just escapes, or flies past, depending on its energy. — ref: Baez, Second Quantization for the Kepler Problem, arXiv:2507.11428 v5, eqs. (6), (9), (13), (14)
- **LNB-168** [; steps/baez] That only N = 0, 1, 3 can occur (a shadow is never longer than a root) is the argument of the E7 paper’s Lemma 2. — ref: Baez, Triangulations of the Sphere, arXiv:2606.10072 v2; Baez, Three Generations in E7, arXiv:2608.06271, Lemma 2
- **LNB-173** [; steps/baez] Madelung rules: the subshell (n, l) holds 2(2l + 1) electrons, and subshells fill in order of n + l, then n. An approximation for real atoms. — ref: Baez, Second Quantization for the Kepler Problem, arXiv:2507.11428 v5 (Madelung rules); the Madelung rules (textbook)
- **LNB-177** [; steps/baez] A known rule of thumb fills the places in this order; real atoms sometimes break it. — ref: Baez, Second Quantization for the Kepler Problem, arXiv:2507.11428 v5 (Madelung rules); the Madelung rules (textbook)
- **LNC-012** [; steps/category] Nothing. The element 0 and the zero object are not used: a null generator e is not the element 0 (e ≠ 0), and the arrow ∅ → {i} of the cube of labels is not a zero arrow. — ref: Category report
- **LNC-037** [(1,2,0), (1,3,0); steps/category] Physics use of halving: spinors and SL(2,ℂ), through Cl⁰(1,3) = Cl(1,2) = M₂(ℂ). — ref: Category report, finding N5; Lundholm–Svensson Prop. 5.1, 5.8, Sect. 5.3
- **LNC-054** [n = 3 (cube category); steps/category] Over an algebraically closed field, k B₃ = (kA₂)^{⊗3} is tame and derived equivalent to the canonical algebra of type (3,3,3): a tensor product of three non-simple algebras is tame exactly when all three are A₂ (Wang, arXiv:2407.11363, Prop. 3.1), and the derived equivalence is Ladkani, arXiv:0708.1… — ref: Wang, arXiv:2407.11363, Prop. 3.1; Ladkani, arXiv:0708.1412, Ex. 2.2 (both read at statement level); Category report, finding N7
- **LNC-061d** [(p,q,r); steps/category] Lundholm and Svensson’s combinatorial Clifford algebra Cl(X,R,r) (their Def. 2.4, p. 14) is the bit rule, and a signature value 0 is allowed (pp. 10, 81–82); associativity for every choice of squares is checked (n ≤ 4, cat·S1). — ref: D. Lundholm, L. Svensson, “Clifford algebra, geometric algebra, and applications”, KTH lecture notes (rev. 2016), Def. 2.4 (p. 14), pp. 10, 81–82
- **LNC-083** [n = 3 (cube category); steps/category] Over an algebraically closed field, k B₃ = (kA₂)^{⊗3} is tame and derived equivalent to the canonical algebra of type (3,3,3): Wang, arXiv:2407.11363, Prop. 3.1, and Ladkani, arXiv:0708.1412, Ex. 2.2 (standard: both read at statement level, their proofs not read; QT2). — ref: Category report, question QT2
- **LNC-120** [(p+p′,q+q′,r+r′); steps/category] Double, in physics: two fermion systems side by side (a composite of fermions); the Koszul sign is the exchange sign of fermions. — ref: the Koszul sign rule of fermions (textbook)
- **LNC-121** [(1,2,0), (1,3,0); steps/category] Halve, in physics: Cl⁰(1,3) ≅ Cl(1,2) ≅ M₂(ℂ) (t of square −1); its even elements of norm 1 form Spin⁺(1,3) ≅ SL(2,ℂ), the group of two-component spinors. — ref: Lawson–Michelsohn, Spin Geometry, Ch. I; Lundholm–Svensson, KTH notes (rev. 2016), Prop. 5.1
- **LNS-010** [(1,3,0), (3,0,0), (3,1,0); steps/schuller] His pipeline: the matter action gives a principal polynomial; three conditions (hyperbolic, dual hyperbolic, energy-distinguishing) filter it; observers and a foliation give the induced geometry; the closure of the hypersurface deformation algebra gives linear equations whose solution, for Klein–Gor… — ref: Düll, Schuller, Stritzelberger, Wolz, Gravitational closure of matter field equations, arXiv:1611.08878; F. P. Schuller, Constructive Gravity: Foundations and A…
- **LNS-010f** [(1,3,0), (3,0,0), (3,1,0); steps/schuller] The back half, the closure equations and the action principle, is not rebuilt: row C7 stays an analogy and row C12 a gap (a harmless one for the quadratic P of the atlas: for a metric principal polynomial his first condition implies the second and the third, closure paper p. 35). — ref: Düll, Schuller, Stritzelberger, Wolz, Gravitational closure of matter field equations, arXiv:1611.08878; F. P. Schuller, Constructive Gravity: Foundations and A…
- **LNS-011c** [(0,0,n), (1,3,0), (2,2,0), (3,1,0), (4,0,0), (p,q,r), all, all n; steps/schuller] Not a new theorem: the Clifford algebra as a deformation of the exterior algebra is classical. — ref: F. P. Schuller, Lectures on the Geometric Anatomy of Theoretical Physics (2013/14, notes by S. Rea), ch. 12 (Theorem 12.8)
- **LNS-012b** [(1,1,1), (1,3,0), (2,2,0), (3,1,0), (k,d,0), (k,d,0), n = 2..7, (k,d,r), (k,d,r), n <= 6; steps/schuller] That the filter returns the Lorentzian signature is his own conclusion for the metric case. — ref: Düll, Schuller, Stritzelberger, Wolz, Gravitational closure of matter field equations, arXiv:1611.08878, §II.B (14)–(16), §II.C after (18), §V.B
- **LNS-017** [(1,3,0), (1,3,0) + fibre (f₊,f₋), (1,3,1), (1,4,0), (2,3,0); steps/schuller] A momentum along an extra space-like direction enters as a mass, E² = |p|² + m² (Kaluza–Klein). — ref: Kaluza–Klein reduction (standard)
- **LNS-044** [(2,0,0); steps/schuller] F13. The spectrum is called a union of open intervals; the standard statement has closed bands, the edges (the parabolic points) included (Floquet–Bloch, recalled). — ref: F. P. Schuller, Lectures on Quantum Theory (2015, student notes by S. Rea and R. Dadhley, not endorsed by the lecturer), §21.3 (footnote 54), ch. 20
- **LNS-127** [(2,0,0); steps/schuller] Finding F13 is the textbook elliptic, parabolic and hyperbolic split of SL(2,ℝ) (Thm T19). — ref: Schuller, Lectures on Quantum Theory (notes by Rea and Dadhley), ch. 20 (Lemma 20.8); Floquet–Bloch theory (Eastham 1973; Reed–Simon IV, XIII.16)
- **MIR-006** [(1,3,0), (p,q,1), (p,q,r); steps/mirrors] The degenerate case. A mirror in a null vector is not defined (a·a = 0). Step 11 takes up that case. — ref: Cartan–Dieudonné theorem; Humphreys, Reflection Groups (B_n, D_n)
- **PAG-006** [(0,2,0), (1,2,0), (1,3,0), (3,0,0), (4,1,0), (4,2,0); cells] the textbook identifications of some cells: the Pauli algebra Cl(3,0), the spacetime algebra Cl(1,3), SL(2,ℂ) in Cl(1,2), SU(2) in ℍ, the conformal so(4,2) in Cl(4,2), the conformal model Cl(4,1) — ref: Lundholm–Svensson, KTH notes (rev. 2016), Thm 5.5 and Table 5.1; Lawson–Michelsohn, Spin Geometry, Ch. I §4
- **PRJ-001** [(1,1,0), (p+1,q+1,0), (p,q,1); steps/projective] Cube → extra bits. The same bit rule: one extra generator is one more bit with square 0, −1 or +1, and the null pair is two bits (−1, +1). A single generator of square 0 is unpaired: it generates a radical, an ideal on which every product vanishes. The null pair is paired: together the two bits give… — ref: Lundholm–Svensson, KTH notes Def. 2.4 (signature value 0 allowed, p. 10), Sect. 5.3 (mother algebra, p. 62), Sect. 7.1 (degenerate/projective)

## Inputs (status input)
- **ATL-022c** [cells] The 8-cube has 2⁴ · 70 = 1120 four-dimensional faces, by the count 2^{n−k}C(n,k) of the faces of the n-cube: checked by enumeration for n ≤ 7, recalled at n = 8.
- **ATY-015** [steps/ym] Atiyah and Sutcliffe, read, not run here. Checked here: baryon number equals instanton number for the charge-one instanton of CAND-124, 1 for the holonomy along lines and along the circles of the hyperbolic slice and −1 for the anti-instanton (ATY-012, ATY-013…
- **FUR-573b** [matter/papers] She identifies this 12-dimensional algebra as su(3) ⊕ su(2) ⊕ u(1), in which B − L is not a generator (Roadmap II and III, taken as given); that B − L is not among its generators is not computed here.
- **INP-001** [light] The action of this step is an input: ½⟨FF⟩₀ − ⟨AJ⟩₀ with F = ∇∧A, put in and not derived from the bit rule. What follows from it is checked: in Cl(1,3) its stationarity in A gives the vector part of ∇F = J, and the grade-3 part ∇∧F = 0 holds because F = ∇∧A (I…
- **INP-002** [light] The constitutive relation is an input: in vacuum H = ⋆F, the Hodge dual of F; in a medium H = χ(F). That χ has 36 components, 20 principal, 15 skewon and 1 axion, is checked (CAND-090, bd·sol·14).
- **INP-003** [light] A flat chart with ∇ = Σ e^μ ∂_μ, in the orthonormal frame of the labels, is chosen: an input. For n ≤ 5 that frame is gauge under Pin(p,q) up to orientation and time orientation, four values when p, q ≥ 1 (checked for the coordinate frames: INP-003b).
- **INP-004** [light] F is a bivector (grade 2) and J a vector (grade 1) where ∇F = J is written for the field itself: assigned, an input. With the potential of this page, A a vector (grade 1, assigned) and F = ∇∧A, the grades of F and J follow from that of A: F = ∇∧A is a bivector…
- **INP-005** [light] Which generators count as time, and the overall sign of J: see the Conventions page.
- **INP-006** [light] Units with c = ε₀ = μ₀ = 1: the speed of light and the two vacuum constants are set to one.
- **INP-007** [light] The Lorentz force as the grade-1 part of F u: a postulated force law, not derived from ∇F = J.
- **INP-008** [light] Charge, mass, start position and start speed are chosen by hand in each of the six situations.
- **INP-009** [light] The time direction γ₀ of a frame is chosen: an input. It splits F into E and B; another γ₀ splits the same F differently. Only its time orientation carries information: one orbit of the even versors, two of the rotors (checked for Cl(1,n−1), n ≤ 6: INP-009b).
- **INP-010** [light] The Coulomb field of a point charge and the plane wave f(t − z) are put in as given fields: an input; the page does not solve for them. That they solve ∇F = J away from the charge (J = 0) is checked exactly (INP-010b; the Coulomb field also in CAND-138).
- **INP-011** [light] Which sign is called time (the minority sign), and Cl(k,d) against its mirror Cl(d,k), are conventions: an input. What is not a convention is checked: only a Lorentzian split gives a hyperbolic wave operator (T18 (f), PAG-011).
- **INP-011b** [light] Which fibre momenta, and so which masses, a field carries is taken from outside: on the labels a field has one mass for each fibre momentum (FUR-026), and the labels do not say which occur.
- **INP-012** [light] Extra time generators are an input with no time-domain realisation in a medium: the principal symbol of the time-domain equations is the ω → ∞ limit, where a causal medium tends to the vacuum, which is Lorentzian (our reading, not checked in general; INP-012b …
- **INP-013** [shapes] The Fock reading pairs the 2n null vectors and picks a vacuum: a Witt split, not given by the labels, an input. For k ≤ 4 the coordinate splits are gauge under Pin(k,k), and under Spin one bit remains, the family of the Lagrangian (checked: INP-013b; the two f…
- **INP-014** [shapes] Which two of the five bits are weak and which three are colour, the scale of the hypercharge, the formula B − L = 1 − 2b/3 and the names hypercharge and B − L are Baez, Bokor and Boyle's: an input. Given the split, the direction of the hypercharge is fixed by …
- **INP-015** [shapes] The Furey box uses her 16-dimensional model as imported on the Furey page; the page checks the bijection and the axes only.
- **INP-016** [shapes] The Cartan matrices of E6, E7 and E8 are imported: an input. From them the Lie bracket of E8 is built with the bit-rule sign of Cl(8,0) carried to E8/2E8, and the Jacobi identity holds on all 248³ basis triples (checked exactly: CAND-050).
- **INP-017** [clock] The clock c = p − q mod 8 assumes that p counts the generators that square to +1; the mirror convention gives −c.
- **INP-018** [steps/mirrors] The reflection formula x ↦ −a x a⁻¹ fixes one of two sign conventions for mirrors (Pin versus its twin).
- **INP-020** [steps/mirrors] A time orientation, given by the unit vector e_t (γ₀ in the Dirac line), is chosen: an input; e_t enters the mirror x ↦ −e_t x e_t. Only the orientation is a datum, and γ₀ in ψγ₀ψ̃ is a reference of the right action (checked: INP-020b).
- **INP-021** [steps/dirac] The action of this step is an input: ⟨∇ψIγ₃ψ̃⟩₀ − m⟨ψψ̃⟩₀, put in and not derived from the bit rule. Its stationarity gives ∇ψJ = mψγ₀, and the incidences, the determinant and the covariance of that equation are checked (INP-021b, EQN-008, T16).
- **INP-022** [steps/dirac] ψ is an even multivector (8 components in Cl(1,3)): the grade of the field is assigned.
- **INP-023** [steps/dirac] A time orientation is chosen, and the positive involution γ₀ψ̃γ₀ is used: an input. That only the orientation carries information, that γ₀ and J on the right are a reference while observers act on the left, and that γ₀ψ̃γ₀ is positive where the reversion is no…
- **INP-024** [steps/dirac] J = γ₂γ₁ plays the part of the Dirac i: a complex structure chosen in the algebra, not given by it, an input. For n = 4, 5, 6 the choice is gauge, one rotor orbit; at n = 3 J and −J differ (checked for the coordinate quarter turns: INP-024b).
- **INP-025** [steps/dirac] Cl(1,3) with γ₀² = +1 is used; Cl(3,1) reads the same system with the signs swapped.
- **INP-026** [steps/dirac] A flat chart with the vector derivative ∇ = Σ e^μ ∂_μ is chosen: an input, the chart of the light page. The derivative term of ∇ψJ comes from the action (checked: INP-021b).
- **INP-027** [steps/coupling] The action of this step is an input: ⟨∇ψIγ₃ψ̃ − mψψ̃ − eAψγ₀ψ̃⟩₀ + ½⟨FF⟩₀, put in and not derived from the bit rule. Its stationarity gives both equations with one e, and its coupling term is A·⟨X⟩₁, so no projection is chosen by hand (checked: INP-027b, CPL-0…
- **INP-028** [steps/coupling] The coupling constant e: its size is a free constant, as in every theory.
- **INP-029** [steps/coupling] The potential A is a vector (grade 1): assigned, an input. The current X = ψγ₀ψ̃ is not assigned: for even ψ its grades are ≡ 1 mod 4, so it is a vector in Cl(1,3) (checked exactly: CPL-012); from n = 5 it has a grade-5 part that ∇F has no slot for (CPL-002), …
- **INP-030** [steps/coupling] The time orientation of the Dirac step is chosen: an input, the same as on the mirrors and Dirac pages. The rest is checked: only the orientation carries information; ψ ↦ ψL̃ moves the reference γ₀, J and keeps X = ψγ₀ψ̃; reversion and Clifford conjugation giv…
- **INP-031** [steps/coupling] J = γ₂γ₁ of the Dirac step is chosen as the complex structure of ∇ψJ and of the charged form, which exists from n = 3: an input. At n = 3 it is a datum (J or −J); for n = 4, 5, 6 it is gauge, one rotor orbit (checked: INP-024b).
- **INP-032** [steps/coupling] The potential A is a vector-valued 1-form on a flat chart, and the replacement ∇ → ∇ − eA uses the same derivative.
- **INP-033b** [steps/ym] The action of this step: the Yang–Mills action of so(m) with a source (pointer, source unread).
- **INP-034** [steps/ym] so(m) as the gauge algebra is one choice; the Standard Model algebra is not an so(m) for any m.
- **INP-035** [steps/ym] The gauge coupling g is a free constant.
- **INP-036** [steps/ym] The covariant derivative D^μ = ∂^μ + gA^μ takes the potential A as a vector-valued 1-form on a flat chart.
- **INP-037b** [steps/matter] The action of this step: the Dirac action of Ψ with ∂ replaced by D (pointer, source unread).
- **INP-038** [steps/matter] Ψ = Σ Ψ_{S,T} is even in the space-time part and carries an internal blade T of Cl(0,m); the generators act on T: assigned.
- **INP-039** [steps/matter] The representation of the gauge algebra on Ψ is a choice: left multiplication on Cl(0,m), the spinor-type one; tensor-type ones and chiral doublets are not drawn.
- **INP-041** [steps/matter] The covariant derivative D = ∂ + gA^aB_a acts on a flat chart: the chart and ∂ are those of the Dirac step.
- **INP-042** [steps/matter] J = γ₂γ₁ of the Dirac step, acting from the right, is chosen as the complex structure of the matter equation: an input. Its generator gives the coupling step (checked: MAT-002), and the choice is one rotor orbit for n = 4 to 6, a datum at n = 3 (checked: INP-0…
- **INP-043** [steps/matter] The time orientation of the Dirac step is taken over: an input; γ₀ (label 1) stands on the right in the mass term and in the currents, built with the reversion. For the Dirac step, that γ₀ on the right is a reference and that γ₀ψ̃γ₀ is the positive involution,…
- **INP-044** [steps/grav1] The action of this step is an input: the Einstein–Cartan action of e and ω, with R = dω + ¼[ω,ω] and T = de + ωe (its published form read in three papers). What follows from it is checked: its first variation is an exact identity and its ω-equation is T = 0, s…
- **INP-045** [steps/grav1] A tetrad e on a chart: grade 1 is identified with tangent vectors by a choice of frame, an input. The frame is gauge under Pin(1,n−1) up to orientation and time orientation, and the field equation does not see the choice: E_a = 0 and G − Λ_n g are invariant un…
- **INP-046** [steps/grav1] ω is a bivector-valued 1-form and e a vector-valued 1-form: assigned.
- **INP-047** [steps/grav1] The frame algebra is Cl(1, n−1): one generator squares +1 (time) and the n−1 others square −1; the other convention swaps the two signs of the squares (see Conventions).
- **INP-048** [steps/grav2] The action of this step is an input: Einstein–Cartan with a cosmological term, in MacDowell–Mansouri form (its published form read in three papers). What follows from it is checked: its first variation and E_a = 0 in vacuum, D E_a = torsion terms, E_a as the E…
- **INP-049** [steps/grav2] Which sign of the cosmological term is de Sitter rests on the signature convention: c = Λ/3 here, c = −Λ/3 in the convention of the papers read (space squaring +1); an input. In the solved Einstein–scalar and Einstein–Dirac series c is not derived: it is chose…
- **INP-050** [steps/grav2] The coupling κ of matter to the Einstein form is a free constant of the action L_grav(c) − κL_m: its size is calibrated by Newton's G and its sign (κ > 0, s > 0) is the attraction input. What follows is checked: κ = 8πG from Poisson, Reissner–Nordström with s …
- **INP-051** [steps/projective] PGA is Cl(n,0,1) when space squares +1 (Dorst and De Keninck) and Cl(0,n,1) when space squares −1 (the convention used here).
- **INP-052** [steps/projective] The three plane-based geometries and the extension to spheres are taken from Dorst and De Keninck’s tables.
- **INP-053** [steps/projective] Conformal invariance of Maxwell, Yang–Mills and the massless Dirac equation, for every generator of the conformal algebra, is taken from the literature (Bateman and Cunningham for Maxwell, recalled, not read): an input. It is checked for sampled generators (CA…
- **INP-054** [steps/gauge] The Schwarzschild metric (a point mass) is borrowed in its Painlevé–Gullstrand form (Lasenby, Doran and Gull): the page rebuilds it as a shear of the frame and checks it; it does not solve for it there. An input. It is derived elsewhere: in the class of radial…
- **INP-055** [steps/gauge] A frame: the shear h̄ and the static time direction e_t are chosen, an input; the same metric has other frames. At a point the frame is gauge under Pin(1,3), and under the rotors up to its orientation and time orientation (coordinate frames, exact); two frames…
- **INP-056** [steps/gauge] The field equations of the theory are solved for the metric only in restricted settings: the one-function radial Kerr–Schild class, where Schwarzschild is derived (GRV-012), the areal orthogonal chart, itself an input (CAND-010), and eight Kerr–Schild profiles…
- **INP-057** [steps/gauge] Time squares +1; with the other convention the two signs of the squares swap and the 0 does not (see Conventions).
- **INP-058** [steps/nullsurf] The metrics (Schwarzschild, Kerr, Kerr–Newman, the Ellis wormhole) are borrowed: an input; the page rebuilds the null-surface statements on them and checks them. Kerr satisfies the engine's field equation at points and as 2-jets, Kerr–Newman satisfies E_a = −κ…
- **INP-059** [steps/nullsurf] A static Killing vector ξ and the covector n = dx: the null normal exists once the chart and the time direction are chosen.
- **INP-060** [steps/nullsurf] The claims of the paper of Hsu, Barker, Hobson and Lasenby are the statements this step tests: an input from a source (read), with its three wormhole examples used as given metrics. They are rebuilt on the bit rule and checked, except its Eq. (12), which is no…
- **INP-061** [steps/forque] The Newton–Euler equations Ṗ = F, Ḃ = I⁻¹[B × I[B] + F], Ṁ = −½MB of Dorst and De Keninck are taken as given: an input. The page's translation of the paper is checked: 27 of 41 rows agree exactly, 9 after a small adjustment, 5 are not checked (MAP-024, RSN-005…
- **INP-062** [steps/forque] The inertia map I and the forces are the paper’s examples.
- **INP-063** [steps/forque] With space squaring −1 the kinetic term changes sign (mainly-minus mechanics): a convention of the metric.
- **INP-064** [steps/forque] The time derivative along the motor path: the only chart is the time parameter t.
- **INP-066** [steps/spin] The pointor and spinor equations are the authors' and the lecturer's (Roelfs, Eelbode, De Keninck; Eelbode's lecture): an input. The page's translation is checked: 22 of 30 rows agree exactly, 2 after a small adjustment, 6 are not checked (MAP-025).
- **INP-067** [steps/spin] Which kind of i plays the complex unit, the central I, a bivector J, or the lecture's B + i, is a choice of complex structure: an input. In Cl(1,3) the coordinate unit spatial bivectors ±γ_iγ_j are one rotor orbit, so the choice among them is gauge (checked ex…
- **INP-068** [steps/spin] The pointor ψ lives in the even subalgebra; the chirality map ψ ↦ IψJ uses the chosen J.
- **INP-069** [steps/spin] The Dirac step is reused with its chart and ∇: an input. Its free plane waves solve the Dirac equation of that step (checked exactly at rational on-shell momenta, with no solution at the off-shell momenta tested: RSN-028b, FUR-037).
- **INP-070** [steps/spin] The time orientation of the Dirac step is taken over: an input. It fixes the energy sign of a plane wave, β = 0 or π (checked at rational on-shell momenta: INP-070b, RSN-028b). The positive involution γ₀ψ̃γ₀ (T15) is a datum: positive where the reversion in ψψ…
- **INP-071** [steps/spring] Hooke’s law x″ = −Lx on the cube’s graph, with one scalar displacement per vertex, is a postulated force law.
- **INP-072** [steps/spring] The sign s of the square of the generator (−1, 0, +1) is a parameter one chooses: an input. The matrix D = Σ e_i is built from the generators and has D² = n·I (checked exactly for n = 1 to 7: SPR-002, T19); that it is the signed matrix used by Huang (2019) is …
- **INP-074** [steps/spring] The time derivative along the flow: the only chart is the time parameter t.
- **INP-075** [steps/rigid] In step 16 Euler's equation, Hooke's and Newton's laws and Kepler's problem are taken as given: inputs of that step. The identities G1–G5 are checked exactly (RSN-006). Elsewhere Newton's law of gravitation is reached from the Einstein form: in the weak static…
- **INP-076** [steps/rigid] The planets' masses and positions are the example's own printed table, dated 16 Jan 2018, six bodies: data, an input. Against the JPL Horizons vectors of that date its five inner rows agree up to one common translation of 116.6 km, to 0.16 km and 0.14 mm/s, th…
- **INP-077** [steps/rigid] The time derivative along the motor path: the only chart is the time parameter t (the engine integrates numerically in t).
- **INP-079** [steps/groups] The uniqueness of the Golay code, the simplicity of the large groups, the orders of Co₁ and the Monster, and Monster ⊃ 2^{1+24}.Co₁ are quoted from the literature, not rebuilt.
- **INP-080** [steps/category] States use the dagger involution, e_i† = ε_i e_i with null generators fixed (T15), rather than the reversion or Clifford conjugation: an input, a datum. The dagger is the reversion only if q = 0 and conjugation only if p = 0 (checked for r = 0, n ≤ 8: INP-080b…
- **INP-082** [steps/baez] Baez’s octonion table and his embeddings of generations (E7, the Albert algebra) are imported; the multiplicities (a, b) are recalled from Loos.
- **INP-083** [steps/baez] The colour labels 3 and 3̄ depend on a sign convention for the weights.
- **INP-084** [steps/baez] The periodic-table section fills subshells in the Madelung order (n + l, then n), a textbook rule taken as given and an approximation for real atoms; the page counts the rows it closes.
- **INP-085** [steps/schuller] The matter action (Schuller’s stone 1) and his closure construction are imported; the page rebuilds the symbol and hyperbolicity (T18(f)), not the dynamics.
- **INP-086** [steps/schuller] One Lorentzian class in two conventions, P ↔ −P: the quantum notes print Cl(3,1), the Atlas Cl(1,3).
- **INP-087** [matter] Furey's octonion table and her nested flag ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆 in 𝕍 (real dimension 16) are imported: an input. That the octonion sign is not the rule's cocycle is checked, and up to a gauge of 16 presentations the table is fixed by the division property (LNB-018).
- **INP-088** [matter] The complex structure ω = L_{e₇} is imported: an input. As a blade of Cl(0,8) it is gauge: one of the 56 even blades of square −1, one orbit of the label automorphisms (checked: INP-088b).
- **INP-089** [matter] Her octonion table and the constructions of her papers (Roadmap I–III, Trialities, the 2026 paper) are taken as given; the page rebuilds the algebra from the octonion units and recomputes the quoted numbers.
- **INP-090** [matter] The partition of the 16 axes into blocks is an input, a datum. The 616 of 18 480 quadruple sets that diagonalise its projectors are the bases of one Lagrangian, a gauge; given it and ω, the partition falls into one of 11 orbits (checked: INP-090b, FUR-003).
- **INP-091** [matter] The complex structure ω = L_{e₇} of the Dictionary tab is hers: an input; the page builds 𝕍 with it and computes the blocks. At the level of the labels ω is gauge, also with her torus fixed (checked: INP-088b).
- **INP-092** [matter] The formulas of Y and Q as sums of projectors (her eqs. 44, 45) are hers; the page computes their traces and their values on the blocks.
- **INP-093** [matter] The Standard Model labels on the edges of her Fig. 1 are imported: an input. That one complete set fits is computed (FUR-002).
- **INP-094** [matter] The labels of the 20 cells of her Fig. 1 are hers; the table to download repeats them with the irreps and charges computed on the Three generations tab.
- **MAT-005b** [steps/matter] The size of the coupling is a free parameter, an input of the model (INP-035); with one action the κ of D^μF_{μν} = κj_ν is tied to the g of D (MAT-005).
- **PAG-010** [light] Maxwell in geometric algebra (Hestenes)
- **RSN-028** [logbook] In Cl(1,3) J = γ₂γ₁ is taken as the complex structure (an input, as on the Dirac page); with it ψ ↦ IψJ is the chirality involution of the space-time algebra, and β in ψψ̃ = a + bI = ρe^{Iβ} is the Yvon–Takabayasi angle (Hestenes). That an even spinor has ψψ̃ …

## Candidates not yet rows
- **CAND-014** Spin–statistics: In a Lorentz-covariant local QFT with positive energy, integer-spin fields obey the CCR and half-integer-spin fields the CAR.
- **CAND-073** Positive bases (forms over ℝ≥0): If a basis has non-negative structure constants, the simplicial cone it spans is closed under products and contains no line. A non-real element of ℂ or ℍ inside that cone has powers whose directions are dense on a circle, which would force a line into the cone. …
- **CAND-080** Definitions the rows use without stating: State for an involution (positive normalised functional), graded centre, Euler form Σ(−1)^i dim Ext^i and Tits form, universal grading group, radical of a quadratic form (C.2). Each belongs in A.0 before the rows that use it.
- **CAND-087** Algebraic curvature tensors and the Bianchi map: Sym²(Λ²V) = ker b ⊕ Λ⁴V with b(α·β) = α∧β; ker b splits into Ricci and Weyl parts, dim Weyl = n(n+1)(n+2)(n−3)/12 (n ≥ 3). So B∧B = b(B·B), the half of RSN-018's reading that is a theorem.
- **CAND-099** Structured cospans and the Frobenius law of wires: For a functor L: A → X with a left adjoint, structured cospans L(a) → x ← L(b) form a symmetric monoidal double category; in a category of relations or corelations the "identify variables" composition is governed by a special commutative Frobenius algebra on each object (the Frobenius law of Carboni–Walters).
- **CAND-134** C versus CP for Weyl multiplets: The complement map 16 → 16̄ sends left-handed states to the conjugate representation. On Weyl fields that is CP; C alone would require the opposite chirality.

## Questions to researchers (questions.json)
- **QA1** (graded ring theory; answered: True) The null label as an algebra element: a graded Brauer-type group with r: For the bit-rule algebra Cl(p,q,r) the super-centre is the exterior algebra on the r null generators and the algebra is graded-Azumaya over ℝ exactly when r = 0 (proved for all n, T2). Is this a known statement, and is there a graded Brauer-type group that contains the degenerate Clifford algebras, so that the clock p − q mod 8 can be extended by a…
- **QA2** (representation theory of algebras; answered: False) Representation type of the degenerate algebras: The exterior algebra Λ(k^r) has finite representation type for r ≤ 1, tame for r = 2 and wild for r ≥ 3 (recalled). Does that measure how far label 0 is from invertible, and what does it become for Cl(p,q,r) with p + q ≥ 1 (a Morita-type reduction to the exterior algebra through Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^r))?
- **QA3** (graded algebra; answered: False) The universal grading group of Cl(p,q,r): Among gradings in which every label is homogeneous, the universal grading group of Cl(p,q,r) is ℤ₂^{p+q} × ℤ^r, of free rank r (T2, proved; for arbitrary gradings the rank can be larger, since M₂(ℝ) carries a ℤ-grading by matrix units). Is the universal grading group for arbitrary gradings known, torsion part included?
- **QA4** (Frobenius and Gorenstein algebras; PGA; answered: False) The complement mask as a Frobenius duality: The complement mask pairs a with a xor 1…1 and is a Frobenius pairing for every signature; it is symmetric only for odd n or r = 0, and for even n with r ≥ 1 (the 3D projective algebra Cl(3,0,1), for example) no symmetric form exists; the Nakayama automorphism is the grade involution (all proved for all n, T3). Is this known for the exterior and pr…
- **QA5** (Frobenius algebras and quantum foundations; answered: False) Frobenius forms, the trace, and states on projective-type algebras: All Frobenius forms of Cl(p,q,r) are λ(u·) with u any unit; only the symmetric ones are a torsor under the central units (T3). In Cl(3,0) the trace is the top-blade form up to the central pseudoscalar (C2). With null generators the scalar part is blind to every label with a null bit (F4), only the top-blade form is non-degenerate, and T15 shows tha…
- **QB1** (categorification; knot homology; answered: False) The cube of labels and categorification: The cube of labels with the Jordan–Wigner sign is the standard picture of a cube of resolutions, and the sign is unique up to gauge (H¹(cube; 𝔽₂) = 0, proved for all n, T6 (a)). Is Tian's DG category CL a categorification of this signed cube, or of something else, and is the uniqueness of the sign the reason the sign conventions of such constructio…
- **QB2** (cohomology with a monoid of coefficients; answered: False) A cohomology for the monoid-valued sign: For ε = ±1 the bit rule is a 2-cocycle of ℤ₂ⁿ in {±1}. For a null generator the sign takes the value 0 on some pairs, so it lives in the multiplicative monoid {+1, −1, 0}, which is not a group; T1 proves associativity for every n by an integer identity on the exponents. Is there a cohomology theory (twisted monoid algebras, partial cocycles) in whi…
- **QB3** (non-associative algebra; cochain twists; answered: True) The octonion cochain and a null analogue: The octonion sign is a 2-cochain on ℤ₂³ whose coboundary is the associator (−1)^det, a 3-cocycle; the Clifford sign of Cl(0,3) on the same labels is a cocycle. This is the cochain-twist picture of Albuquerque and Majid (recalled); T6 (d) proves the finite content (coboundary and composition) and leaves the identification with 𝕆 to Hurwitz. Is there…
- **QB4** (derived categories of finite-dimensional algebras; answered: True) Is the 3-cube derived-tubular?: The Euler form of the n-cube category has signature (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0..5. T8 proves that its Coxeter polynomial is the D₄ polynomial at n = 2 and (x−1)²(x²+x+1)³ at n = 3, the tubular (3,3,3) profile, that the two null directions at n = 3 are exactly the Coxeter-fixed vectors, that the algebra is not …
- **QB5** (categorification; answered: False) Tian's radical vector in the categorification: Tian's odd truncations have a radical vector a₁ − a₃ + a₅ − …, which T7 identifies as (−1)^{m−1} u_m, the half of the last hyperbolic pair whose partner a_{2m} is missing. Is there an object in CL (or in K₀) whose class is that vector, and what happens to it in the limit of the infinite algebra Cl_ℤ, which has no radical?
- **QC1** (Brauer–Wall groups; answered: True) Graded Morita classes with r: The clock is a homomorphism for the graded product (K4a, K5a) and null generators contribute 0; T2 shows that the algebra is graded-simple only for r = 0. What is the graded Morita class of Cl(p,q,r), and is there a version of the Brauer–Wall group in which r is a second coordinate (classes over dual numbers or exterior algebras)?
- **QC2** (number theory; algebra over finite fields; answered: True) A finite-field clock: Over 𝔽_p the one-generator algebra has (p − 1)(p − χ(d)) units: split, ramified, inert as +1, 0, −1 (L1b). Does the clock have a finite-field version (the Brauer–Wall group of 𝔽_q, recalled to be ℤ₄ or ℤ₂ × ℤ₂), and for n = 2 is 'null' the same thing as 'ramified' for quaternion algebras over ℚ (Hilbert symbols)?
- **QC3** (condensed-matter classification; answered: False) The tenfold way and a nilpotent generator: The eight clock values and the two complex classes are Kitaev's ten classes of gapped free fermions (the tenfold way; Kitaev, arXiv:0901.2686, read at statement level; Freed–Moore: pointer, source unread); which class sits at which clock value needs T² and C² (input). Does a nilpotent generator (r ≥ 1) correspond to anything physical in that classi…
- **QD1** (Kac–Moody algebras; lattices; answered: True) E_n/2E_n and the label form of Cl(n,0): T9 proves that E_n/2E_n carries the label form of Cl(n,0) for every n ≥ 3 (and A_n/2A_n that of Cl(0,n)), that the two coincide iff 4 | n, that W(E_n) mod 2 is the full isometry group for n = 3..8 (and by computation for n = 9..12), and that the class is not a function of rank and signature (A₆ against E₆). The identification continues through E₉, …
- **QD2** (topology; lattices; answered: True) Is the clock the Brown invariant?: The phase of the Gauss sum over the labels of Cl(n,0) is (p − q)π/4 (K4a; T4 (iii)), and for the root lattices A₃, A₈, D₄, D₈, E₆, E₇, E₈ the Gauss–Milgram sum of the discriminant form has the phase n·π/4 (Q4). Is 'clock = Brown invariant of the ℤ₄-valued quadratic form of the labels' the correct statement, and is it the same ℤ₈ as the signature mo…
- **QD3** (quiver representations; answered: False) Blades with square −1 against positive roots: The number of blades with square −1 equals the number of positive roots of E_n for n = 3, 4, 5, 6, 8 (4, 10, 20, 36, 120) and is 64 = 63 + 1 for n = 7, the extra class being the central pseudoscalar (T10 (6), proved). By Gabriel's theorem (recalled) the positive roots count the indecomposable representations of the quiver. Is there a reason, or a u…
- **QD4** (low-dimensional topology; mapping class groups of non-orientable surfaces; answered: False) The cell as a Pin⁻ surface: mapping classes: For r = 0 the cell (V,w) is a Pin⁻ structure on the connected sum of n projective planes, with (V, ·) its first homology mod 2 (Kirby–Taylor Thm 3.2, read; QD2). Is Aut(V,Q,π) (core·B12) the image of the Pin⁻ mapping class group of that surface in the orthogonal group of its homology, so that Pin⁻ structures up to diffeomorphism are classified by t…
- **QE1** (quantum foundations; answered: False) The Born rule in a general cell: In Cl(3,0) the mixed state ρ = (1 + v)/2 and the projector P = (1 + u)/2 give 2⟨ρP⟩₀ = (1 + v·u)/2, ρ is positive iff |v| ≤ 1 and pure iff |v| = 1 (the Bloch ball). T15 proves the general version: for every Cl(p,q) with the dagger involution the states are the density elements ρ ≥ 0 of the scalar-part trace, and with null generators the states are …
- **QE2** (quantum foundations; finite geometry; answered: False) The finite shadow of the spectral theorem and contextuality: The largest set of mutually commuting blades with square +1 spans ℝ^{2^w}, w the Witt index of the quadric of squares, and 2^w is the number of simple factors times the matrix size (W1). The counts are 5 points for Cl(4,0); 27 points and 45 lines for Cl(6,0) (the elliptic quadric Q⁻(5,2), not the Klein quadric); 135 points and 270 solids in two fam…
- **QE3** (mathematical physics; answered: True) Super-dimension 0 and the bosonic ladder: The fermionic and the bosonic ladders satisfy the same relations [N, a] = −a and [a, a⁺] = 1 once the commutator is a super-commutator; the dimension is 2ⁿ and the super-dimension is 0, which is what [a, a⁺] = 1 needs in finite dimension (T20 (e), proved). Is 'super-dimension 0' the finite shadow of why the bosonic ladder needs infinite dimension, …
- **QE4** (mathematical physics; answered: False) One combined matrix along the pipeline: The Schuller report asked for a single matrix with the geometry and quantum rows reordered along his pipeline. The combined matrix has 131 rows from the three reports against the 22 atlas columns (the heatmap on this page), but it keeps the three reports' row orders. Is the reordering along the pipeline worth doing, and which rows would it move?
- **QE5** (number theory; finite groups; answered: False) The three 135s and the Golay code's three bricks: The three families of 135 in Cl(8,0) are the three 135s of triality (W3, counted; T11 (4)). T14 proves that the Golay code is a Lagrangian of the label form of Cl(24,0) built from three 8-bit bricks (Turyn). Whether the three 135s of Spin(8) and the three bricks of the Golay code are the same triple is not touched.
- **QE6** (quantum theory; number theory; answered: False) Is 'null' more than a resemblance?: Timelike, null, spacelike as −1, 0, +1 is the trichotomy inert, ramified, split at n = 1 over 𝔽_p (L1b), and the clock does not distinguish the three beyond ±1 against 0 (K4a). Is there a statement at n ≥ 2 (QC2) or in the energy-cone picture that makes 'null' more than a resemblance?
- **QE7** (representation theory; answered: False) Two layerings with no link: The filtration of Cl(p,q,r) by powers of the radical has layers C(r,k)·2^{p+q} (R2; proved in T2); the layer sizes of the E₈ root ladder in the Schuller report (240, 126, 72, 40, 20, 8 and 56, 27, 16, 10, 6; the first steps proved in T13) are a different count. No mechanism connects them and nothing here tests one.
- **QT1** (graded Brauer groups; answered: False) Wall's theorem inside the bit rule (T4): T4 proves that the pair (type of Cl(p,q), type of its even part) is a complete invariant of the clock, with 8 values, but that the eight pairs are the graded Morita classes forming the Brauer–Wall group ℤ₈ of ℝ is recalled from Wall (1964). Is there a short self-contained proof of Wall's theorem in the twisted-group-algebra language of the labels?
- **QT2** (representation theory of algebras; derived categories; answered: True) Tame or wild at n = 3 (T8): The cube category at n = 3 has Coxeter polynomial (x−1)²(x²+x+1)³ and a positive semidefinite Euler form of corank 2, the profile of the tubular algebra of type (3,3,3), but it is not strongly simply connected (the rank-1-2 subposet is a hexagon crown), so the Brüstle–de la Peña–Skowroński criterion does not apply. Is k B₃ tame, and is it derived e…
- **QT3** (classical groups over finite fields; answered: False) Transvections over 𝔽₂: generation and lengths for all n (T12): For every label form with n ≤ 6 the transvections generate O(Q) except for the class of Cl(2,2) (O⁺₄(2), index 2) and its degenerate relatives, and the longest words need up to n + 1 transvections (7 at n = 6). General n rests on Dieudonné's theorem (recalled), there is no hand proof of the O⁺₄(2) exception (Dickson invariant), and no length formul…
- **QT4** (operator algebras; quantum foundations; answered: False) States of composite systems with null generators (T15): T15 settles the single-system case: every state of Cl(p,q,r) vanishes on the radical, for every involution. Composite systems (the graded against the ungraded tensor product, Schuller's chapter 14) are not treated, and non-diagonal involutions on the complexification are covered by the proof but not tested numerically. What is the right state space…
- **QT5** (geometric algebra; invariant decomposition; answered: True) The isoclinic case and the general-n decomposition (T17): At n = 4 the commuting decomposition B = b₁ + b₂ is proved to exist and to be unique when λ₁ ≠ λ₂, with b_i = B(T − λ_i)/(λ_j − λ_i). The isoclinic case λ₁ = λ₂ (in the definite cells and for some Cl(2,2) bivectors) and the general-n invariant decomposition of Roelfs and De Keninck are not proved here. What is the right statement for λ₁ = λ₂, and d…
- **QT6** (Coxeter groups; lattices; answered: True) W(E_n) mod 2 for all n (T9): W(E_n) reduced mod 2 is the full isometry group O(q) of E_n/2E_n for n = 3..8 (proved) and for n = 9..12 (computed by Schreier–Sims); the map of E_n/2E_n onto the even labels of Cl(1,n) exists for every n (QD1). Does the group statement hold for every n ≥ 3, where W(E_n) is infinite from n = 10 on?
- **QT7** (coding theory; answered: True) Type II codes through the Clifford label form (T14): T14 proves that doubly-even self-dual codes of length n are exactly the n/2-dimensional totally singular subspaces of (𝔽₂ⁿ, Q_{Cl(n,0)}) containing the all-ones label, and that they exist iff 8 | n, by the Gauss sum of the label form alone. The classical proof goes through Gleason's theorem or the MacWilliams identity. Is this route in print?
- **QT8** (model building; exceptional Lie algebras; answered: True) Does Furey's End(V) contain the E₆-complement A₂? (T13): All 1120 A₂ subsystems of E₈ are W(E₈)-conjugate and each has an E₆ complement (T13), so the 'generation sl₃' used inside e₇ is conjugate in E₈ to one whose centraliser is E₆, while inside E₇ its complement is A₅. Whether the model built on End(V) = M₁₆(ℝ) contains this A₂, and whether the 3 of the branching has anything to do with generations, sta…
- **QT9** (representation theory of algebras; tubular algebras; answered: False) The null directions of the 3-cube as tubular families (T8): Over an algebraically closed field kB₃ is tame and derived equivalent to the canonical algebra of type (3,3,3) (T8 (3)), so its indecomposable modules come in one-parameter families. The radical of the symmetrised Euler form at n = 3 has dimension 2 and is the fixed space of the Coxeter matrix (T8 (1)). Are its two null vectors the dimension vector…
- **QT10** (hyperbolic PDE; gravitational closure; answered: False) Degenerate principal symbols and dual hyperbolicity (T18): With null generators a quadratic principal polynomial has a hyperbolic direction exactly when one sign occurs once, and it is never strictly hyperbolic (T18 (f)). Such a polynomial is degenerate, so the dual polynomial of the gravitational closure framework is not defined from it in the usual way. Do the conditions that follow hyperbolicity in Schu…

## Theorems T1–T20 (rows using each)
- **T1** None — used by 4 rows
- **T2** None — used by 7 rows
- **T3** None — used by 1 rows
- **T4** None — used by 32 rows
- **T5** None — used by 6 rows
- **T6** None — used by 1 rows
- **T7** None — used by 3 rows
- **T8** None — used by 0 rows
- **T9** None — used by 3 rows
- **T10** None — used by 11 rows
- **T11** None — used by 3 rows
- **T12** None — used by 5 rows
- **T13** None — used by 3 rows
- **T14** None — used by 7 rows
- **T15** None — used by 2 rows
- **T16** None — used by 5 rows
- **T17** None — used by 11 rows
- **T18** None — used by 13 rows
- **T19** None — used by 7 rows
- **T20** None — used by 5 rows