# docs/round20 — the review of 21 Oct 2026 (3.7.0 + 3.7.1 staging)

Drop this folder into the repository as `docs/round20/` (the plan refers to it as `docs/round20/review/` and `docs/round20/map/`).

- `ATLAS_FINDINGS.md` — what the Atlas is, the map of its statements and links, the referees' verdicts, the Shifted View format contract, the structural assessment, the 3.8 / 4.0.0 recommendation.
- `PLAN_OF_ACTION.md` — the plan: Phase 0 (3.7.1), Phase 1 (3.8.0, the ledger), Phase 2 (4.0.0, the grammar); decisions for the owner; packages with files, acceptance tests and prompts for worker models.
- `review/math/REVIEW.md`, `review/physics/REVIEW.md` — the two referee reviews (sections A–G: chain verdicts, row issues, computations, not computable, structural cross-check, dangerous spots); `review/*/scripts/` the 12 check scripts (run `python3 -I -B <script>` from its folder; `--fault NAME` must exit 1).
- `review/BRIEF_*.md` — the referees' briefs (reuse for the next referee pass); `review/chain_links.csv` — every chain link; `review/theorems_T1_T20.md`.
- `map/map_stats.md` — counts, lists of open/ours/standard/input rows, candidates, questions, the lens × page matrix; `map/map_digest.md` — every statement by page → section → chain; `map/map_full.json` — the machine-readable map (one record per row).
- `tools/build_map.py` — rebuilds the map: `python3 -I tools/build_map.py <content dir> <out dir>`.
