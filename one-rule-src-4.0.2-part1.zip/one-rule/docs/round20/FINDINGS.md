# The Atlas (ONE RULE 3.7.0 + 3.7.1 staging) — findings

Date: 21 Oct 2026. Sources read: the two halves of the 3.7.0 source (`one-rule-src-3.7.0-part1/2.zip`: content, docs, engines, src, tools; checks, tests, public), the 3.7.1 staging folder (STAGED.md, nine check scripts with logs, the Shifted View researcher-view mockup with its sources, the Politecnico briefs and their 29-script re-run). Every number below is computed from the shipped tables (`content/*.json`, `content/derived/status.json`) by `scripts/build_map.py`; the machine-readable map is `map_out/map_full.json` (one record per row: status, texts, depends, chains, lens readings, evidence with the result of its last recorded run), the readable one `map_out/map_digest.md` (every statement by page → section → chain), the statistics `map_out/map_stats.md`, the chain links `review_in/chain_links.csv`. The two referee reviews are `review_out/math/REVIEW.md` and `review_out/physics/REVIEW.md`; their 12 check scripts (all exact arithmetic, 29 `--fault` controls, every control re-run here and exiting 1) are in `review_out/*/scripts/`.

---

## 1. What the Atlas is, and what it is trying to do

**One rule.** Labels are bit masks a ∈ 𝔽₂ⁿ; the product of two labels is e_a e_b = s(a,b) e_{a⊕b}, with the sign s(a,b) = (−1)^{N(a,b)} ∏_{i∈a∧b} ε_i and ε_i ∈ {+1, −1, 0} the square of generator i. That is the whole construction: it is the Clifford algebra Cl(p,q,r) in an orthonormal frame, with p generators of square +1, q of square −1 and r null ones (theorem T1: the sign is a 2-cocycle, so the rule is associative for every n and every choice of squares). A **cell** is a signature (p,q,r); the **clock** is c = p − q mod 8 (Bott periodicity, the Brauer–Wall group ℤ₈ of ℝ, the Brown invariant of the ℤ₄-form w = π + 2Q on the labels, the phase of the Gauss sum (1+i)^p(1−i)^q, Weil's index); **M₁₆(ℝ)** = Cl(8,0) ≅ Cl(0,8) ≅ Cl(4,4) is the period block, Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ).

**What it reaches from the rule, with declared inputs.** From ℝ = Cl(0,0,0) outward: the lattice of cells and their types; the twenty steps (the clock and the trinity of squares; commutators; mirrors and Cartan–Dieudonné; Dirac; pointors and the three kinds of i; Maxwell meets Dirac; Yang–Mills; charged matter; gravity I and II (Einstein–Cartan, the Einstein form, MacDowell–Mansouri, solutions); one more generator and the null pair (projective/conformal, Kaluza–Klein); gauge gravity and horizons; null surfaces; forque, the spring on the cube, the rigid body; finite groups; the category lens; Baez; Schuller); three "calibrations" (light = Maxwell, every term recomputed; matter = Furey's octonion Standard Model, her algebra rebuilt; shifted = Atiyah and Moore's shifted Dirac theory); and three programmes of readings on the labels: Weil's 1964 memoir (the labels as his Heisenberg group, his index as the clock, his Theorems 1–5, a finite Siegel–Weil-type identity in every genus), Atiyah's collected works (Bott periodicity and Clifford modules as computed objects, instantons, edge cones, twistors), and Kitaev's tenfold way. Everything is tied to **inputs** (actions, charts, time orientations, complex structures, imported tables: 95 rows of status `input`) and to **sources** (41 `standard` rows, 29 sources).

**The discipline.** Every statement is a row with a status *computed from its evidence*: `proved-by-atlas` (a script recomputed it exactly at the scope the text names, with `--fault` controls), `standard` (cited, read, not recomputed), `ours` (an interpretation), `open`, `input`, `meta`. "Every number comes from a stored check result; nothing is typed by hand." 376 check scripts, 652 recorded runs; 20 theorems T1–T20 are the only claims for every n. A page shows results; the drawer shows evidence, dependencies, lens readings, the address; the Logbook holds the register.

**The ambition, in your metaphor.** The dialects are the languages the Atlas calls *lenses*: branches (algebra, geometry, topology, category, combinatorics), languages (string theory, solid state, field theory), researchers (Furey, Baez, Schuller, Hestenes, Dorst–De Keninck, Roelfs–Eelbode, Tian, Majkić, Pumplün, Hsu–Barker–Hobson–Lasenby, Atiyah) and conventions. The common tongue the Atlas proposes is the labels with their squares and the clock: a statement is told once, in the Atlas's words, and the dictionaries (1,161 entries over about 80 "atlas elements"; 2,876 mechanical readings attached to 725 rows; 982 reading rows) translate it into each dialect, graded `exact / exact with convention / exact with an input / partial / analogy / none`. The 27 notes to researchers are the letters that ask each dialect's speakers whether the translation is right. The Politecnico briefs (ten visits, one yes/no question per statement, the script that checks it) are the same thing done in person.

---

## 2. The map: what is in the tables

### 2.1 Counts (3.7.0 tables as shipped)

| | |
|---|---|
| rows | 2,064 = 1,516 statement rows + 548 story/meta rows (narration, section leads) |
| statement status | proved-by-atlas 1,137 · ours 123 · open 120 · input 95 · standard 41 |
| texts | 3,847 (research: 1,088 human, 645 reviewed, 332 draft; learner: 390 human, 822 full drafts, 450 span drafts, 32 human spans, 57 short drafts, 10 reviewed) |
| dependency edges | 4,928: derives 2,309 · equiv 1,224 · uses-input 567 · instance 526 · restates 268 · cycle 33 · contradicts 1; every target resolves |
| chains | 186 on 26 pages (646 chain links: derives 268, continues 154, order 127, equiv 31, instance 25, cycle 8, uses-input 6); shapes fork 96 · line 82 · cycle 7 · ladder 1 |
| theorems | 20 (T4 is used by 116 rows, T18 by 69, T20 by 49, T17 by 48; T8 by none) |
| lenses | 35 registered; 12 carry readings; 2,876 readings on 725 rows (703 of the 1,516 statements) |
| checks | 376 scripts, 652 runs; every `proved-by-atlas` row cites at least one script whose last recorded run passed (0 exceptions); 3 rows also cite the author's three table-printing scripts (`peirce_test`, `witt_test`, `z2_test`) recorded as "runs, prints tables" |
| candidates | 150 named by the labelling passes; 145 are rows now; 5 remain (CAND-014 spin–statistics, 073 positive bases, 080 missing definitions, 087 algebraic curvature tensors, 099 structured cospans, 134 C vs CP) |
| questions to researchers | 34 (13 marked answered) |
| figures | 109 (75 at learner level) |
| cells named by statements | (1,3,0) 315 rows · (3,0,1) 152 · (3,1,0) 85 · (5,5,0) 70 · (4,0,0) 69 · (0,8,0) 69 · (3,0,0) 59 …; 250 statements name no cell, 327 only a symbolic one ("all n", "(p,q,r)", "row 8") |

### 2.2 Where the statements live (home page: n, proved, standard, ours, input, open)

cells 90 (66/2/5/1/16) · clock 44 (40/1/1/1/1) · light 56 (36/0/3/15/2) · rule 41 (36/0/4/0/1) · shapes 42 (34/1/1/4/2) · shifted 38 (25/0/6/1/6) · matter + tabs 178 (128/0/7/19/24) · logbook 88 (76/0/8/1/3) · steps/baez 256 (184/18/30/3/21) · steps/category 199 (162/7/12/1/17) · steps/schuller 193 (130/7/27/2/27) · steps/rigid 81 (76/0/2/3/0) · steps/forque 57 (46/1/5/4/1) · steps/coupling 55 (44/0/3/6/2) · steps/spin 50 (36/0/7/5/2) · steps/grav2 35 (28/1/3/3/0) · steps/spring 33 (28/0/2/3/0) · steps/ym 27 (18/0/2/5/2) · steps/mirrors 27 (23/1/1/2/0) · steps/nullsurf 25 (22/0/0/3/0) · steps/grav1 21 (16/0/0/4/1) · steps/dirac 19 (13/0/0/6/0) · steps/matter 19 (10/0/1/7/1) · steps/projective 18 (14/1/0/3/0) · steps/groups 15 (11/1/1/1/1) · steps/gauge 14 (10/0/0/4/0) · steps/comm 4 (3/1/0/0/0).

Three pages hold 43 % of the statements and 54 % of the open ones: the three lens chapters Baez, category, Schuller (648 rows; 65 open). The physics steps 4–16 are almost entirely proved or input.

### 2.3 By clock and by n (cells named by the statements)

| clock c = p−q mod 8 | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|---|
| statements | 410 | 81 | 259 | 236 | 153 | 95 | 441 | 94 |
| open | 40 | 9 | 12 | 12 | 7 | 7 | 34 | 11 |

Clock 6 is the spacetime cell Cl(1,3) and its relatives; clock 0 is row 8 (M₁₆(ℝ)), Cl(4,4), Cl(5,5), Cl(2,2), Cl(0,0). By n: n = 4 carries 737 statements (49 %), n = 8 130, n = 10 151, n ≥ 11 25.

### 2.4 The dependency graph

- 171 statement rows have no outgoing edge (the axioms, inputs and roots); 600 have nothing depending on them (leaves); 75 are both. 39 statements have no edge in or out *and* are in no chain (36 of them CAND rows that became rows without being placed in the graph: CAND-001, 006, 013, 016, 017, 028, 034, 036, 037, 039, 045, 047, 051, 072, 077, 084, 088, 096, 104, 111, 113–115, 117–119, 123, 128–130, 132, 141, 142, 146, 149; plus INP-085, LNP-004, PAG-012, PAG-034).
- Most depended-on: T4 (116), T18 (69), EQN-019 (63), T20 (49), T17 (48), EQN-016 (48), RIG-002 (47), FRQ-001 (42), T2 (41), INP-075 (39), T10 (38), T1 (34), T3 (34), EQN-017 (34), INP-066 (32), T16 (31), LNS-012 (30), T5 (29), SPN-001 (29), LNS-003 (29).
- Cross-page edges (top): schuller → logbook 72; shifted → coupling 55; baez → shapes 48; matter/papers → matter 36; grav2 ↔ grav1 23/20; cells → rule 19; logbook → category 17; shifted → grav2 16; rule ↔ clock 14/13; matter → light 13. The physics spine (dirac → coupling → ym → matter; grav1 → grav2 → projective → gauge → nullsurf) is well connected; the lens chapters connect mostly to the logbook (the translation matrices) and to shapes.
- Three directed cycles over derives/instance/uses-input edges: ATY-011 ↔ ATY-041 (a reading and the computation it rests on, pointing both ways: the physics referee says ATY-041 "instance of ATY-011" is backwards), LAB-034 → LAB-039 → LAB-035 → LAB-034, and LAB-039 ↔ LAB-036 (the Weil line's general theorems and their finite cases cite each other: `instance` edges from the general theorem LAB-039 to its cases should be the only direction).

### 2.5 The chains

186 chains; weakest link: proved throughout 97, ours 39, open 34, standard 11, meta 3, input 2. **661 of the 1,516 statements are told in a chain; 855 are not.** 68 sections with three or more statements have no chain, led by steps/rigid·eq-rigid (62), steps/forque·eq-forque (45), logbook·notes (39), steps/spin·eq-spin (37), logbook·map (35), the `needs` sections of every step (inputs), the perspectives/questions/honest sections of the three lens chapters (the renderer draws those as lists by design, HANDOVER §3 item 5). Pages told well: shifted 38/38, cells 70/90, rule 30/41, grav2 27/35, matter/model 39/52; told badly: forque 2/57, spin 2/50, dirac 3/19, spring 5/33, rigid 14/81, nullsurf 9/25, logbook 10/88, matter/papers 0/18, matter/generations 0/18 — the translation-matrix lines (149 rows, D35) and the mechanics steps have almost no story.

### 2.6 The lenses

Readings by lens (rows with a reading / pages touched): alg 263/29 · geo 248/30 · str 225/22 · atiyah 198/24 · sol 190/25 · fld 174/30 · cat 140/16 · majkic 45/8 · baez 35/3 · furey 28/6 · schuller 15/6 · pumplun 1/1. **Twenty-three lenses carry no reading**: top, comb (branches with no dictionary at all), the seven shape lenses (clifford, simplex, cube, prime, orthoplex, demicube, gosset), the four label lenses (bits, primes, sigword, bitsq), the five convention lenses (space-plus, time-plus, cl13, cl31, role-names), hestenes (23 dictionary entries, 0 readings), pga, roelfs, tian, hbhl. Of the 12 active lenses, six (alg, geo, str, sol, fld, atiyah) reach 22–30 of the 36 pages; cat reaches 16; the researcher lenses stay on their own pages. The `match` field of the dictionary is free text (over 300 distinct values, from "exact" to a sentence); it is not a grade.

So: **the lenses do not section the Atlas, each with its own view.** Six dictionaries cover about half the statements; the shape and label "lenses" are renderings of a label, not dialects; the convention "lenses" are switches of an input; the researcher lenses are the translation matrices of their own chapters.

### 2.7 The statement labelling (the Atlas already labels itself with its rule)

`docs/labelling/SCHEME.md`: every row carries the set of the 29 primitive notions it uses, each notion with a square (+1 the rule supplies it, −1 imported from the literature, 0 an input), so a statement has a signature (p,q,r), a grade (popcount), a "clock", a prime name and neighbours at Hamming distance 1. Used today for the address in the drawer, the neighbours, search, and the candidates. What the data show: signatures (3,1,0) 76 · (4,1,0) 73 · (4,0,0) 66 · (2,1,0) 61 …; grades 2–13, mode 4; the statement "clock" is spread 176/285/342/265/197/88/54/109 over the eight residues; **449 statements have no neighbour at all** (their notion set is unique), 223 have one. The most used notions: src 699, lbl 606, sq 599, biv 538, mod 536, s-phy 526, nul 438, grd 431, i-act 292. The composition rule of §2 of the scheme ("a shared input kills the product") is a metaphor for navigation, as the scheme says itself; it is not a Clifford algebra of statements, and nothing in the tables uses the statement clock.

---

## 3. What is open, what is ours, what is standard (the lists are in `map_out/map_stats.md`)

**Open (120).** Four families. (a) *Physics names on cells* (cells page, 16): quark, lepton, confinement, electroweak core, chiral parity, matter/antimatter, cosmic horizon, baryon number, 210, 4/17, the Higgs VEV — all explicitly "ours and open, not a result"; the only mathematical content is the honest denial. (b) *Model questions of the lens chapters* (Baez 21, category 17, Schuller 27): the two tens of h₂(𝕆) and the triangulation form, hydrogen as a Jordan pair, the mechanism behind (1,9); tameness of kB₃ over ℝ, the universal grading group, the Nakayama twist and PGA duality, the tenfold way with a nilpotent generator, Tian's DG category, the Carroll structure of a horizon; Schuller's closure equations, gluing, an action principle, infinite dimensions, the 23 area-metric classes. (c) *Furey and the shifted view* (matter 24, shifted 6): the irreps-to-cells map, three generations, the spectrum of fibre momenta, Pati–Salam vs so(1,3); the meaning of the shifted Einstein equations, Fock space of a delay equation, what an equivalence-principle test weighs, QED processes with shifted operators. (d) *Isolated open items*: the coupling constant κ (GRV-005b), the gauge algebra (YM-006b), a non-abelian Einstein–Yang–Mills source (YM-007c), Pin⁺/Pin⁻ and T² = ±1 (LAB-016/PAG-032), Gårding's theorem as a pointer (PAG-034), neutral fields at n = 1, 2 (CPL-006b), the signature family of the deformation algebra (LNS-029/047/014e).

**Ours (123).** Readings of names (base/fibre, outside/inside, the trio of signs −1/0/+1 across the chapters, the spring's signs, label 0, "up and down" the ladder, rung 9 as the boundary), readings of papers (Atiyah–LeBrun's limits, Furey's three papers side by side, Fig. 1's caption), the shifted view's interpretations (ATY-011 why the two shifts come together, ATY-047 the quantized solutions as reweighted Dirac fields, ATY-058 D_s as the chiral variant, ATY-061 the shift as a clock, ATY-062 the retarded and advanced halves, ATY-065 the two constants meet in μ = κτ), the translation-matrix lines not checked (FRQ-M36…M40, SPN-M24…M30), and a handful that are in fact theorems or computations (see §4).

**Standard (41).** Textbook identifications (Pauli, spacetime algebra, SL(2,ℂ), the conformal models), Baez's and Schuller's paraphrases, Kaluza–Klein, Floquet, Cartan–Dieudonné, Lundholm–Svensson's definition, Wang/Ladkani (read at statement level), Atiyah–LeBrun's theorem, the Golay/Monster facts. Two are not literature (ATL-018 is proved by T17; GOS-004 is narration).

**Inputs (95).** The actions of every step (Maxwell, Dirac, coupling, Yang–Mills, matter, Einstein–Cartan, MacDowell–Mansouri), the charts, the time orientations, the complex structure J = γ₂γ₁, the sign conventions, the borrowed metrics, Furey's and Baez's tables, the planets' positions, the couplings e, g, κ, G. The input rows are the backbone of the honesty: the physics steps are "the rule + these inputs".

**The staging's by-choice gaps** (STAGED.md): ATY-015, ATY-046, CAND-121, GEN-024, GRV-011, LNS-017e, RIG-M19, RIG-M52, YM-712, LNC-059, ATY-024 — status after this review in §4.3.

---

## 4. The two referees' verdicts (full tables in `review_out/*/REVIEW.md`)

### 4.1 Headline

- **No mathematical or physical error in any proved computation.** 1,577 rows reviewed (786 math, 791 physics), 185 chains: 156 OK, 29 FIX (a relation word, a status or a scope), **0 BREAK**. All twenty theorems T1–T20 are correct as stated and their proofs or reductions adequate at the stated scope (T3, T4(iv), T14(4), T2's radical and super-centre re-derived by hand; T8/T9/T10's numbers recomputed).
- Two text errors: **CAND-121** states the d = 2 kinetic coefficient (π^{ij}π_{ij} − π²) "for every dimension" — in d = 3 the DeWitt coefficient is ½ and with 1 the constraint algebra does not close (the referee's control fails); **LNS-122**'s "at zero is the edge" contradicts LNS-125 (M = ±I is not a band edge; "at zero with X ≠ 0").
- **Status issues (15):** rows that are proved but labelled `standard` (ATL-018) or `ours` (GOS-511b Witt's rank-16 classification; LAB-505b no non-compact simple group inside a compact one; ATY-024b; FUR-619b a computation without a check id; CPL-006b now built); rows labelled `proved-by-atlas` that are readings (ATY-019) or that pack literature into a computation (LAB-018: "w is a Pin⁻ structure", Ω₂^{Pin⁻} ≅ ℤ₈ and the Fidkowski–Kitaev ℤ₈ are read, the Brown invariant is computed — split it); `open` rows that are pointers (PAG-034 → standard), readings (LNS-028c → ours) or answered by the literature (LNS-029/047/014e: Teitelboim 1973 and Henneaux 1979 give the signature family in every d; LAB-016/PAG-032: Kirby–Taylor and Kapustin et al. settle Pin⁺ ↔ T² = (−1)^F, Ω₂^{Pin⁺} = ℤ₂); `standard` that is narration (GOS-004); `input` that is a one-line count (ATL-022c); ATY-064 now computed from inputs.
- **Naming and scope (about 20):** the two 𝔽₂-bilinear forms the clock pages use are never distinguished (the dot product is the polar form of w; the commutation form |a||b| + a·b is the polar form of Q — this is exactly why "Q alone sees only c ↔ 2 − c", LAB-017/ATY-033/LAB-019); (type, even type) is a *complete invariant* of the Brauer–Wall class, not its definition (CAND-004/T4(ii)); "the clock of a degenerate cell is forced" is a definitional choice (Brown's invariant is defined for w vanishing on the radical; CAND-091 is right) (LNC-006/018/055/107); "finite Siegel–Weil formula" names a transitive-orbit average (LAB-036/039; keep the computation, call it a Siegel–Weil-type identity); LAB-019's Wood citation is too broad (rank, Brown invariant *and* non-alternating type classify); LNS-046's home name "Majorana only in Cl(3,1)" reads as physics (the Majorana condition is convention-independent; the real-module fact is right); GRV-010's E_a = −(G − Λδ)Θ is right in (+,−,−,−) but needs one sentence; CAND-086/ATY-051 must say "with the Atlas's δ = −δ_usual"; three staging wordings (ATY-044's gravitational source is *complex*, 1 − (−1)ⁿμJ times the Dirac tensor; ATY-055's "second tower at jπ/τ" is a property of a formal series, not a spectrum; ATY-058's symbol (1 + κτ)K degenerates at κτ = −1).
- **27 physics rows sit at the wrong stage** (A/K/F/D/O): Gårding cone, fermion doubling, Euler–Arnold stability, Hill numerics at A; Lichnerowicz with torsion, Noether's second theorem, Petrov types, Smarr at K; Birkhoff, Kerr, Friedmann, EIH, MPD, the constraint algebra at F; the geodetic precession, Λ-perihelion, fine structure, Hawking temperature at F instead of O; the matter tabs staged O wholesale (list in physics REVIEW F.1).
- **Underclaims upgradeable to every n with a citation:** LAB-035's code counts ∏(2^i + 1) (Witt/Wood + the count of maximal totally singular subspaces of O⁺(2m,2)); INP-019 (reversion ≅ conjugation iff n ≡ 0 mod 4 and indefinite, n ≥ 1, by invariants and Skolem–Noether); GEN-011 (a lemma proved in the review: the ungraded product has the graded type exactly when one clock is 0 or 4); the ABS table of GEN-022/ATY-001 (a corollary of the type table alone); and about 60 `proved-by-atlas` rows that are small-n instances of textbook theorems (math REVIEW F.3 lists them with references).

### 4.2 Structural cross-check: all textbook or correct-but-non-standard, none wrong

mod-8 type table; the clock as the Brown (Arf–Brown–Kervaire) invariant of w = π + 2Q; the Gauss sum; KO^{p−q}(pt) from graded modules (Atiyah–Bott–Shapiro); Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ); Weil's index = e^{iπ(p−q)/4}; the tenfold way (up to s ↔ 2 − s, as LNC-076c says); E_n/2E_n carrying the label form (Coble, Dolgachev–Ortland); the Golay code as a Lagrangian of (𝔽₂²⁴, wt mod 4) (Wood 1993; the Clifford algebra adds nothing beyond naming the ℤ₄-form); Fidkowski–Kitaev ℤ₈. The sign conventions of the physics (Weitzenböck/Lichnerowicz D̸² = □ − R/4 and D² = □ − Ric on 1-forms with the Atlas's δ, the Kaluza–Klein coupling −εφ²/2, Λ = −3s/ℓ², the Maxwell energy sign, the Fierz–Pauli symbol) are the textbook ones in the Atlas's own convention; nothing is silently mixed.

### 4.3 Computed in this review (12 scripts; every one re-run here; proposed texts and evidence ids in the reviews' section D)

| row | was | now |
|---|---|---|
| LNC-059 / CAND-083 | "the idempotents follow; not computed" | the 2^w idempotents built on all 44 cells n ≤ 8 (5,195 exact checks: idempotent, orthogonal, sum 1, primitive, dim AE = N dim D, 2^w = sN) — `lnc059_idempotents.py` (math), and independently on 36 cells (physics) |
| ATY-024 (with ATY-022, ATY-024b) | "the edge-cone family (5.4)–(5.6) … its Einstein form not computed" | Einstein with λ = (3/2)β²(2−β) by an independent exact Christoffel route at 7 (β, point) pairs; the (4,0) Einstein form vanishes exactly at c = −λ/3 and at no other c; fixes the σ₃ normalisation (unit S³ forms) — `aty024_cone_einstein.py` |
| CAND-121 (and LNS-029/047/014e) | d = 2 only; "d = 3 not run; every dimension recalled" | {H[N],H[M]} = εH_k[…] with ε = −s in d = 3 with the DeWitt coefficient ½, exact on 12 configurations; coefficient 1 fails; the three members s = −1, 0, +1 are Teitelboim's and Henneaux's algebras — `cand121_hda_d3.py` |
| RIG-M19 | "the sign of the Euler term is not run separately" | energy conserved for both signs; world momentum only for the right one — `rig_m19_m52_euler.py` |
| RIG-M52 | "the example's size [0.6, 2, 1] is not run" | at (3/5, 2, 1) the printed and the paper's inertia maps give different flows; equal only when s₀ = s₂ |
| GRV-011 (b) | "Φ_t = Φ_s with decay: the standard argument, not run" | the kernel of the Hessian map is the 4 affine functions (exact, degree ≤ 6) + the one-line argument — `grv011_hessian_affine.py` |
| CPL-006b | open: "a neutral form of the field for n = 1, 2 is not built" | built: ∇ψ = mψγ₁ on even ψ of Cl(1,1) is the 1+1 Majorana equation with the massive shell; none at n = 1 — `cpl006b_majorana_cl11.py` |
| ATY-003 | the Atiyah–Segal model's pages "as read" | pages 24, 18, 18, 10, 10, 8, 8, 8 and H(D) = (4,4) reproduced by an independent exterior-algebra route — `aty003_atiyah_segal_model.py` |
| LNS-038 / CAND-144 (staged) | the 30/14 Mermin-grid list and Mermin's nine operators | hold, by two independent routes (grid search; 𝔽₂ linear algebra); side finding: in the 30 cells every commuting 3×3 grid has line-sign product −1; the original "argument from the sign rule" for p,q ≥ 2 is a valid proof and should be kept — `mermin_grids.py` |
| LAB-028/032/037/038 (Weil line) | finite claims | recomputed exactly over ℤ[ζ₈][1/2]: (S^pS†^qH^n)³ = ζ^{p−q}; the group orders 192/48/46080/23040; aba⁻¹b⁻¹ = i·1, hence no double cover — `clifford_phases.py` |
| T8/T9/T10 data, LNC-045, LAB-035 counts, GEN-011, T4(iv), KO table, INP-019, CAND-058 | | hold — `lattice_euler_checks.py`, `type_table_consequences.py` |
| ATY-064 | open | computed from its three inputs by the staging (`shifted_review.py` N1); status input + proved |
| GEN-024 | listed as a gap | already closed in 3.7.0 (ns.P3) |
| ATY-046 | listed as a gap | closed by the staging's `shifted_gradient2.py` |
| ATY-015 | input, "read, not run" | stays an input: the paper's rational-map Skyrme energies are a numerical ansatz |
| LNS-017e (ε = 0) | "not run" | cannot run: a null fifth generator makes the 5D metric degenerate (the staging's reason is right); the runnable null case is the Bargmann lift with a null Killing vector (Newton–Cartan) — a different row |
| YM-712 | listed in STAGED.md | not a row id anywhere; drop from the list |

### 4.4 The calibrations

The physics referee's verdict: **light** is a calibration in the Atlas's sense. **Matter** calibrates the Atlas's algebra against Furey's *printed* algebra (blocks, hypercharges, ladders, the 16's weights, dimension ladders), not against nature: chirality, generations, masses are the open rows; the page's tally should say what is established. **Shifted is not a calibration**: the paper has no known answer; what the page does is an *audit* of Atiyah and Moore, and a good one — its three negative results stand on the referee's re-derivation ((2.12)'s deviation is the imaginary coefficient of a non-Hermitian operator; the printed (4.4) omits the Hubble friction 3Hr; the radius scalar is Brans–Dicke ω = 0, γ = ½, excluded by Cassini). Recommended: rename it ("Audit 3" or "Test 3"), and add a **fourth calibration with measured numbers** that the engine already computes: hydrogen's fine structure (CAND-013), Mercury's 42.98″/century (CAND-118, d5_perihelion), the GP-B geodetic rate 6606 mas/yr (CAND-128), or Kitaev's table against the published one.

### 4.5 What a hostile referee attacks first (both reviews, merged)

1. **Status inflation**: 1,137 `proved-by-atlas` reads as "proved"; by the Atlas's definition it means "computed at the stated scope", and most are small-n instances of textbook theorems. The vocabulary needs a tier for "an instance of a theorem, with the citation" and one for "computed, finite scope".
2. **"Calibration 3"** calibrates nothing; the word on the light page is weakened by it.
3. **The literal non-Hermitian reading of Atiyah–Moore's (2.12)** (ATY-037/039) must be stated as such, and ATY-044's complex gravitational source with it.
4. **Calibration 2 proves the Atlas's algebra, not physics.**
5. **LAB-018** packs bordism literature into a computed row; the Pin⁺ side is "open" although it is textbook.
6. **Two polar forms, one name** (LAB-017/ATY-033/LAB-019).
7. **The category lens's headline** (kB₃ tame and derived-tubular) rests on two unread citations (Wang, Ladkani).
8. **GRV-010's sign form**, **CAND-121's coefficient**, the **Hehl–Datta normalisation**, **7 % false-pass "proofs"** (CAND-005 at n = 6).
9. The Weil line's "same number" (index = Gauss sum) needs its structural reason (both are Brown-type invariants, multiplicative in ⊥, equal on one-dimensional forms) or it reads as numerology; "finite Siegel–Weil formula" overnames.
10. The tenfold-way match needs T², C² and the direction as inputs: the clock reproduces the table, it does not predict it.

---

## 5. The Shifted View mockup: the format contract it establishes

`shifted_view/source/p1.md … p4.md` + `build.py` + `evidence.json` → one self-contained HTML/PDF. Its contract, which is the right research-level unit for the whole Atlas:

1. **Header box**: the page and release; the source paper with its link; the conventions (cell, J in the place of i, units, the names of the paper's symbols on the labels); the **equation numbering** rule — (S4.2) = the second display of step 4, (2.12) = the paper's own; the **badge legend** with five values and what each requires: proved by the Atlas (checks named under it) · computed for this copy (script named, not yet released) · our reading (*with the reason it cannot be proved, and what it rests on*) · open (*with the reason it cannot be computed*) · input. "'Not computed', with no reason, is not used."
2. **The spine is the source's own order** (the paper's nine steps), not the Atlas's: each step opens with a `lead` ("the paper's move", told in the Atlas's words), then the statements the labels compute there, then what stays open there; `see` pointers to statements told at another step; figures captioned by rows.
3. **Each statement** (`row ID badge`): a bold one-line claim; numbered displays; the exact check data (scope: which fields, frames, parameters; exactness; tolerances); a `~ Controls:` line (which broken inputs fail) and a `Scope:` line (how far the run goes); the `Checks:` line generated from evidence.json (script → check ids); for a reading, a **"Why a reading"** paragraph.
4. **The closing ledger** ("For the next release"): a table *row | kind | the reason* for every statement that is not proved; "Still to compute" (empty when nothing is left by choice); "Changes from the 3.7.0 page" (row by row); the "Checks" table (script | argument | checks | controls); "Sources" with the exact numbers used.

The mockup is hand-written Markdown (121 KB for one page) with a 9 KB build script. It is right as a *format*; as a *process* it does not scale to 37 pages by hand — the rows, evidence, controls and scopes it prints are already in the tables (`rows.json`, `texts.json`, `checks.json` with `controls`, `method`, `ids`), so the view can be generated. The one thing the tables lack is the **reason** field of readings and open rows (my count: 6 of 120 open rows and 10 of 123 readings carry a reason-like clause today), and the **formula catalogue** (displays are inline `$$…$$` in texts, unnumbered, uncatalogued).

---

## 6. Structural assessment (your questions)

**Are the cells well organised?** The lattice is right (the 45 cells (p,q,0) with n ≤ 8, the null cells beside them); the *cards* are not: the cells page carries 16 open rows whose only content is a v15 role name ("quark", "lepton", "confinement", "cosmic horizon") marked "ours and open", beside the mod-8 facts. The referee's criterion separates what belongs to a cell as an object of the clock (periodic data: type (D, s), the commutant, the even type, the Brauer–Wall class, the Brown/Gauss/Weil phase, KO^{p−q}, the FS sign, ω², Majorana/Weyl/MW existence, the quadric's ± type, the tenfold class) from what belongs to it as a thing of size n (dimension 2ⁿ, N, the Witt index and the 2^w idempotents, point/line counts, code and stabiliser counts, group orders, the Clifford-phase order, Mermin-grid existence, E_n data, Peirce sizes) — and r is a separate, non-periodic coordinate. The cards mix the two lists and add physics names.

**Can mod 2 / mod 4 / mod 8 / M₁₆(ℝ) organise the Atlas?** Yes, for exactly the periodic data, and the referee's list says which (above). The hierarchy mod 2 (parity, Koszul, the even part, the Arf invariant) → mod 4 (w = π + 2Q, i^w and its Walsh self-duality, Pin⁻ structures, the additivity that picks out the 2ⁿ cell forms) → mod 8 (Brown/clock/KO/Weil/BW/FK, Brown's Witt-group isomorphism as the reason clocks add) is correct and complete as a hierarchy of invariants, and it is today scattered over the clock page, the LAB rows, the category chapter and the Weil line; it deserves one page of its own. It cannot organise the physics steps, the mechanics, the counts, or the lens chapters: there the cell (p,q,r) with n, the stage, and the source are the coordinates. The statement labelling of §2.7 (the 29 notions with squares) is a navigation device, not a structure: 449 statements have no neighbour, and nothing uses the statement clock.

**Do we need all the steps?** The twenty steps are the author's v15 tab order, and they conflate four things: the algebra (1–3), the physics derivation chain (4–13, which *is* the stage axis A → K → F → D → O, Schuller's "grade falls from algebra to dynamics"), applications (14–16: forque, spring, rigid body — 171 statements, 21 in a chain), and lens chapters (17–20: 648 statements, half the open items, where the "step" is a paper read line by line). Steps 17–20 are "ways", not steps.

**Are the lenses sectioning the Atlas, each with its own view?** No (§2.6): 12 of 35 do any sectioning; six reach most pages; the shape and label lenses are renderings; the convention lenses are input toggles; the researcher lenses are page-local matrices; `top` and `comb` are empty; the `match` grade is free text. The dictionary (the "Italian") exists — about 80 atlas elements with their terms in up to 12 dialects — but it is not yet a first-class, graded, bidirectional phrasebook, and it does not cover the physics steps (geo and fld reach them; alg, cat, str do not).

**Weil's way, Penrose's way, Atiyah's way.** The Shifted View page is "Atiyah's way" in the precise sense that its spine is Atiyah and Moore's paper in its own order. The same format applies verbatim to the two other programmes already in the tables: **Weil's way** — his 1964 memoir n° 1–52 as the spine, with LAB-026…039 (the labels as his Heisenberg group, Theorem 1 = the Clifford group, Theorem 3 = the phases, Theorem 4 = the stabiliser states, Theorem 5 = the self-dual codes and p ≡ q mod 8, n° 52 = the finite Siegel–Weil-type identity) hung on its numbers; **Penrose's way** — the twistor programme with *Twistor theory at fifty* as the spine (ATY-066…069 computed; passes 14b–14e planned: the nonlinear graviton, instantons from twistor data, amplitudes, the Newtonian limit). A "way" is a *source read in its own order with the Atlas's statements and open items hung on each of its moves*; it is the format the readers you want to reach (the dialect's speakers) will recognise, and it is what the Politecnico briefs already do one statement at a time.

---

## 7. Recommendation: 3.8 or 4.0.0?

**Both, in sequence; neither is a rewrite.** The data model (rows with computed status, texts, chains, lens readings, evidence with run records) is sound, the tables are complete and count-verified, the test harness is large (kernel 376,395 checks; figures 84,307; physics 9,787; Explore 90,036; …) and every proved row is backed by a passing run. What is wrong is *presentation and addressing*, and the tables already carry what a better layout needs.

- **3.8 — the ledger release** (weeks): apply the staging and this review (the 12 closures, the 29 chain fixes, the ~45 row fixes, the 27 stages), add the two missing fields (`reason` on every reading/open row, enforced by the build; the formula catalogue), and **generate** the Shifted-View researcher view for every page from the tables, plus the three "ways" (Atiyah–Moore, Weil, Penrose) as spine pages. Nothing moves; everything is said with its check, its scope, its controls and its reason.
- **4.0.0 — the grammar release** (a quarter): re-address the Atlas by what it proved: the lattice of cells with the clock as its periodic shadow, and the "three clocks" page (mod 2/4/8) as the organising chapter; the stage axis A → K → F → D → O as the physics spine (the twenty steps become paths through it, the lens chapters become ways, the mechanics become applications); the status vocabulary split (theorem-for-all-n with citation / computed at a finite scope / standard-recomputed / reading-with-reason / open-with-reason / input); every statement in a chain; the lenses sorted into dialects (completed or retired), views (renderings) and toggles (conventions), with a graded phrasebook as the common vocabulary; Calibration 3 renamed and a Calibration 4 with measured numbers.

The plan of action for both is in `PLAN_OF_ACTION.md`.
