#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""SHIFTED-FIFTH.  The radius of the circle of Atiyah and Moore's section 4 against the fifth-force bounds.   python3 shifted_fifthforce.py <checks/selfcheck> [--fault NAME]

Statement.  The paper ("A shifted view of fundamental physics", section 4) reduces the shifted Einstein equations on a circle, ds^2 = e^{2 sigma} Theta^2
  + ds-bar^2 (4.2), finds at F = 0 -nabla-bar^2 e^sigma = eps (k/hbar)^2 e^sigma (4.3), and says that the radius, a massless scalar with couplings of
  gravitational strength, "meets the bounds of fifth-force experiments".  Decided here, under the assumption (A) below: the reduced theory is Brans-Dicke
  with omega = 0; the shifted term gives the radius mass^2 = -eps kappa^2 with kappa^2 = Lambda, a range of about 1e28 cm, so that it is massless at 1 AU;
  the solved field of a point mass has gamma = 1/2 (alpha^2 = 1/3); Cassini's gamma - 1 = (2.1 +- 2.3)e-5 excludes gamma - 1 = -1/2 by about 2e4 standard
  deviations.  The claim does not hold under (A).
Assumption (A).  Matter couples to the four-dimensional metric as y-independent matter with no stress and no momentum along the circle: T^4_4 = T^4_a = 0
  (dust, ordinary matter at rest in the fifth direction).  (R5) shows that such matter is conserved in g4 and moves on its geodesics (g4 is the Jordan
  frame); (W1) shows what stress along the circle changes.  This is the setting in which the paper's "gravitational strength" applies.
Conventions (the Atlas's).  Signature (+,-,-,-); the fibre generator squares eps_f (-1: Cl(1,4), +1: Cl(2,3)); frame e^a = e4^a(x), e^4 = phi(x) dy (phi = e^sigma,
  F = 0, nothing depends on y); mixed frame components; G = kappa T with T^0_0 = rho > 0; box = eta^ab nabla_a nabla_b, the paper's -nabla-bar^2 (ATY-054).
  The matter is read off the five-dimensional equations: kappa5 T := G5 at c = 0, kappa5 T := X(c) = G5 - 6c delta with the cosmological term (h4_cosmological);
  the lowest order of the shifted equations, Ric5 = eps kappa^2 in the paper's signs, is 4c = eps kappa^2 (ATY-054, LNS-017e).  T_4 = L phi T is the
  four-dimensional stress tensor (L the coordinate period of y), kappa4 = kappa5/L = 8 pi G0, units G0 = 1 at phi = 1.  T = sum_a T^a_a (4D trace).
  Brans-Dicke in these signs: G4 = kappa5 T + (omega/phi^2)(grad phi grad phi - delta |grad phi|^2/2) + (Hess phi - delta box phi)/phi, box phi = kappa5 phi T/(3 + 2 omega)
  (= 8 pi T_4/(3 + 2 omega)).  A field of mass m obeys (box + m^2) phi = source.
Routes.  [bit] the engine (gravity_selfcheck.py through b1lib): h4_kaluza_klein.engine_G5, h4_cosmological.engine_X, exact at the origin of polynomial 2-jets.
  [std] the Christoffel route: h4_kaluza_klein.std_G5 and std4_pieces, h4_cosmological.std_X; an own five-dimensional Christoffel divergence at the origin.
  [num] scipy quad (QAWF and Cauchy weights) for the Fourier transforms of the static propagators; floats for the magnitudes.
Checks.
(R0) [bit==std] On Kaluza-Klein frames with F = 0 and non-constant phi (both eps_f) the engine's G5 equals h4_kaluza_klein's reduction formula and the
     Christoffel route.  Half of the frames are tuned (one second-order coefficient of e4, solved exactly) so that R4 = 0 at the origin.
(R1) [bit] The 44 equation: G5^4_4 = -R4/2 and G5^4_a = G5^a_4 = 0 on every frame; on the tuned frames the matter has T^4_4 = T^4_a = 0 and R4 = 0.
(R2) [bit] The trace of the 4D block with the 44 equation: box phi = kappa5 phi (T - 2 T^4_4)/3 on every frame; under (A) box phi = kappa5 phi T/3, Brans-Dicke's
     8 pi T_4/(3 + 2 omega) with omega = 0.
(R3) [bit] The 4D block: the exact fit of G5 - G4 over [Hess/phi, delta box/phi, grad grad/phi^2, delta |grad|^2/phi^2] is [-1, 1, 0, 0]: no (grad phi)^2 term;
     both Brans-Dicke equations with omega = 0 hold exactly on every frame under (A).
(R4) [bit==std] The shifted lowest order, kappa^2 = 1/3, eps = +1 and -1 (c = eps kappa^2/4), frames tuned to T^4_4 = 0: box phi = eps kappa^2 phi + kappa5 phi T/3
     exactly; linearised, (box + m^2) dphi = kappa5 T/3 with m^2 = -eps kappa^2, of size kappa^2 = Lambda.
(R5) [std] The five-dimensional divergence of a y-independent T with T^a_4 = 0 is nabla4_a T^a_b + (d_a phi/phi) T^a_b - (d_b phi/phi) T^4_4, exact at the origin of
     random jets (both eps_f): nabla4_a (phi T^a_b) = phi (nabla5 T)_b + (d_b phi) T^4_4, so T_4 = L phi T is conserved in g4 iff T^4_4 = 0.
(G1) [bit==std] A point mass, linearised static field, solved exactly on the five-dimensional engine: with potentials a, b, f quadratic in x (e^0 = (1 + a) dt,
     e^i = (1 - b) dx^i, phi = 1 + f, a = -A^ (k.x)^2/2, ...) G5 at the origin is exactly linear in (A^, B^, f^) and is the Fourier symbol; G5 = kappa5 T with
     kappa5 T^0_0 = 8 pi M, T^4_4 = 0, solved for three wave vectors (and eps_f = +1): A^ k^2, B^ k^2, f^ k^2 = (-2/3, -1/3, 1/3) 8 pi M, i.e. dphi = 2M/(3r),
     g00 = 1 - 2 (4M/3)/r, g_ij = -(1 + 2 (1/2)(4M/3)/r) delta_ij: gamma = 1/2 (Kepler mass 4M/3).
(G2) [bit] The 4D block alone gives the metric's response to M and to dphi; with Brans-Dicke's source dphi^ = 8 pi M/((3 + 2 omega) k^2) the solved metric gives
     gamma = (1 + omega)/(2 + omega) for omega = 0, 1/2, 1, -1, 5, 40000, alpha^2 = A/A_tensor - 1 = 1/(2 omega + 3), gamma = (1 - alpha^2)/(1 + alpha^2); omega = 0
     reproduces (G1): alpha^2 = 1/3, a coupling to the trace of gravitational strength.
(G3) [num] The static propagators: (1/(2 pi^2 r)) int k sin(kr) 4 pi/(k^2 + m^2) dk = e^{-mr}/r (m > 0, m = 0) and its principal value at m^2 = -kappa^2 is
     cos(kappa r)/r: with the responses of (G2) the solved field is g00 = 1 - 2 (M/r)(1 + Y/3), g_ij = -(1 + 2 (M/r)(1 - Y/3)), gamma(r) = (1 - Y/3)/(1 + Y/3).
(Y1) [num] The sign: from box phi = eps kappa^2 phi (4.3), the plane wave gives E^2 = p^2 - eps kappa^2, m^2 = -eps kappa^2: eps = -1 (c(D+^2), anti-de Sitter)
     a massive scalar, static field Y = e^{-kappa r}; eps = +1 (D+D-, de Sitter: the case the paper fixes by Lambda = kappa^2 > 0) a tachyon, E = +-i kappa
     (the growing e^{kappa t} of (4.4)), static field Y = cos(kappa r), no decay; finite differences confirm del^2 (Y/r) = -eps kappa^2 Y/r.
(Y2) [num] The range from |m| = sqrt(Lambda): 1/sqrt(Lambda) = 9.6e27 cm; at 1 AU r sqrt(Lambda) = 1.6e-15, so 1 - e^{-r/lambda} = 1.6e-15 (eps = -1) and
     1 - cos(r/lambda) = 1.2e-30 (eps = +1): gamma(1 AU) - 1 = -1/2 + O(1e-15); the background curvature Lambda r^2 = 2.4e-30.
(C1) [num] Cassini: (gamma(1 AU) - 1 - 2.1e-5)/2.3e-5 = -2.2e4 standard deviations.
(C2) [num] The general bound: gamma - 1 > 2.1e-5 - 2 x 2.3e-5 gives alpha^2 < 1.25e-5 and omega > 4e4, against alpha^2 = 1/3 and omega = 0.
(W1) [bit] Finding, stress along the circle, T^4_4 = w rho (mixed frame component; for eps_f = -1 a pressure -w rho along y): the same five-dimensional solve
     gives dphi = 2 (1 - 2w) M/(3r) and gamma = (1 + w)/(2 - w) (w = 1/4, 1/2, -1, 1), i.e. omega_eff = 3w/(1 - 2w) for the field of the source; the radius
     decouples (gamma = 1) only at w = 1/2, a tension rho/2 along the circle; by (R5) a body with w != 0 is not on a geodesic of g4: its mass goes as phi^w.
(K1-K3) [ctl] Wrong versions that must fail: Brans-Dicke with omega = 1 and -1 on the frames of (R3); a scalar of range 1 AU in (Y2); matter with stress
     along the circle (the untuned frames) in (R1)-(R2), and the divergence of (R5) without the circle term.
Inputs (as their sources state them).  Planck 2018 (Planck Collaboration, A&A 641, A6 (2020)): H0 = 67.36 km/s/Mpc, Omega_L = 0.6847, Lambda = 3 Omega_L H0^2/c^2
  = 1.089e-56 cm^-2 (the paper's kappa^2 = Lambda, (3.7)-(3.8)); 1 AU = 1.495978707e13 cm (IAU 2012 B2); c = 2.99792458e10 cm/s; 1 Mpc = 3.0856775814913673e24 cm;
  Cassini: gamma - 1 = (2.1 +- 2.3)e-5 (Bertotti, Iess and Tortora, Nature 425, 374 (2003)); eps = +1 for D+D-, -1 for c(D+^2), 0 for D_s^2 (ATY-052, ATY-054).
Controls (--fault NAME: the run must end with FAILS and exit 1).  OMEGA1, OMEGAM1: the reduced theory claimed to be Brans-Dicke with omega = 1, resp. -1, in (R3);
  RANGE1AU: a massive scalar of range 1 AU in (Y2); CIRCLE: matter with stress along the circle (T^4_4 != 0) in place of (A) in (R1)-(R3).
Scope.  Values at the origin of polynomial 2-jets, exact; F = 0 (no Maxwell field: with F != 0 the radius has the extra source (eps_f/4) phi^3 F^2); the zero
  mode (fields independent of y, no Kaluza-Klein tower); the lowest order of the shifted equations (Ric5 = eps kappa^2), not the paper's corrections in mu;
  the linearised static field on a flat background (the de Sitter curvature and the drift of phi on the time hbar/kc enter at relative order Lambda r^2
  = 2.4e-30 at 1 AU); classical; matter as in (A) unless (W1) says otherwise.  Fifth-force bounds other than Cassini's gamma are not used."""
import sys, os, time, math, random, itertools
from fractions import Fraction as F
sys.dont_write_bytecode = True
T0 = time.time()

FAULTS = ('OMEGA1', 'OMEGAM1', 'RANGE1AU', 'CIRCLE')
ARGS = sys.argv[1:]; FAULT = None
if '--fault' in ARGS:
    i = ARGS.index('--fault'); FAULT = ARGS[i + 1] if i + 1 < len(ARGS) else ''; del ARGS[i:i + 2]
    if FAULT not in FAULTS: print('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS))); sys.exit(1)
if not ARGS: print('usage: python3 shifted_fifthforce.py <checks/selfcheck folder> [--fault NAME]'); sys.exit(1)
SC = os.path.abspath(ARGS[0]); GRAV = os.path.join(SC, 'gravity')
for f in ('b1lib.py', 'h4_kaluza_klein.py', 'h4_cosmological.py'):
    if not os.path.isfile(os.path.join(GRAV, f)): raise SystemExit('%s not found in %s: the first argument is the Atlas\'s checks/selfcheck folder' % (f, GRAV))
if not os.path.isfile(os.path.join(SC, 'gravity_selfcheck.py')): raise SystemExit('gravity_selfcheck.py not found in ' + SC)
if GRAV not in sys.path: sys.path.insert(0, GRAV)                            # b1lib finds the engine (selfcheck/gravity_selfcheck.py) from its own folder
import numpy as np
from scipy.integrate import quad
import b1lib as bl                                                          # the engine and the standard route
import h4_kaluza_klein as h4                                                # engine_G5, std_G5, std4_pieces, predict_G5, kk_frame
import h4_cosmological as h4c                                               # engine_X, std_X (the cosmological term c)

ok = []
def chk(name, cond, msg): ok.append(bool(cond)); print(('ok  ' if cond else 'FAIL') + ' %s: %s' % (name, msg), flush=True)
print('SHIFTED-FIFTH  the radius of Atiyah-Moore section 4 against fifth-force bounds; selfcheck = %s%s' % (SC, '; fault: %s' % FAULT if FAULT else ''))
print('     assumption (A): matter couples to the four-dimensional metric as y-independent matter with no stress and no momentum along the circle '
      '(T^4_4 = T^4_a = 0: dust, ordinary matter at rest in the fifth direction); the paper\'s "gravitational strength" is read in this setting', flush=True)
N4, N5, ETA4 = 4, 5, [1, -1, -1, -1]
A0 = [{} for _ in range(N4)]
OMEGA_CLAIM = F(1) if FAULT == 'OMEGA1' else (F(-1) if FAULT == 'OMEGAM1' else F(0))
def d(a, b): return 1 if a == b else 0

# ================================================================================================ frames
def fresh_phi(rng, c0):
    """phi = c0 + a linear part (all four slots non-zero: the gradient at the origin does not vanish) + a random quadratic part"""
    p = {(0, 0, 0, 0): F(c0)}
    for i in range(N4): p[tuple(int(j == i) for j in range(N4))] = F(rng.choice([-2, -1, 1, 2]), rng.choice([1, 2, 3]))
    for ex in itertools.product(range(3), repeat=N4):
        if sum(ex) == 2 and rng.random() < .5:
            c = F(rng.randint(-2, 2), rng.choice([1, 2]))
            if c: p[ex] = c
    return p
def copy_frame(e4): return [{m: dict(p) for m, p in form.items()} for form in e4]
SLOTS = [(a, mu, ex) for ex in ((2, 0, 0, 0), (0, 2, 0, 0), (1, 1, 0, 0), (0, 0, 2, 0)) for a in range(N4) for mu in range(N4)]
def tune(e4, phi, target):
    """e4 with one second-order coefficient changed so that R4 = target at the origin (R4 there is affine in that coefficient; solved exactly)"""
    for a, mu, ex in SLOTS:
        def with_t(t):
            e = copy_frame(e4); p = dict(e[a].get(1 << mu, {})); v = p.get(ex, F(0)) + t
            if v: p[ex] = v
            else: p.pop(ex, None)
            if p: e[a][1 << mu] = p
            else: e[a].pop(1 << mu, None)
            return e
        r0 = h4.std4_pieces(with_t(F(0)), A0, phi)['R4']; r1 = h4.std4_pieces(with_t(F(1)), A0, phi)['R4']
        if r1 != r0:
            e = with_t((target - r0) / (r1 - r0))
            if h4.std4_pieces(e, A0, phi)['R4'] == target: return e
    raise SystemExit('no second-order slot tunes R4')
def run_frame(e4, phi, eps_f, cs=None):
    """[bit] G5 (or X(c) for c in cs) of the Kaluza-Klein frame, [std] the Christoffel route, and the 4D pieces"""
    e = h4.kk_frame(e4, A0, phi); P = h4.std4_pieces(e4, A0, phi)
    if cs is None: return dict(G5=h4.engine_G5(e, eps_f)[0], G5std=h4.std_G5(e, eps_f), P=P, eps=eps_f, e4=e4, phi=phi)
    X = h4c.engine_X(e, eps_f, cs)[0]
    return dict(X=X, Xstd={c: h4c.std_X(e, eps_f, c) for c in cs}, P=P, eps=eps_f)

# ================================================================================================ (R) the reduction with matter
rng = random.Random(7301); FR = []
for eps_f, nfr in ((-1, 3), (1, 2)):
    for i in range(nfr):
        e4 = bl.rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); phi = fresh_phi(rng, [F(1), F(3, 2), F(2, 3)][i % 3])
        g = run_frame(e4, phi, eps_f); g['tuned'] = False; FR.append(g)
        g = run_frame(tune(e4, phi, F(0)), phi, eps_f); g['tuned'] = True; FR.append(g)
TUNED = [g for g in FR if g['tuned']]; UNTUNED = [g for g in FR if not g['tuned']]
MATTER = UNTUNED if FAULT == 'CIRCLE' else TUNED                            # the frames that stand for matter of kind (A)
def kT(g): return [[g['G5'][b][a] for a in range(N4)] for b in range(N4)]      # kappa5 T^b_a, the 4D block
def trT(g): return sum(g['G5'][a][a] for a in range(N4))                       # kappa5 T (the 4D trace)
chk('R0', all(g['G5'] == g['G5std'] == h4.predict_G5(g['P'], g['eps']) for g in FR) and all(g['P']['grad2'] != 0 for g in FR),
    '[bit==std] on %d Kaluza-Klein frames (F = 0, phi non-constant with grad phi != 0 at the origin; eps_f = -1: %d, +1: %d; %d of them tuned to R4 = 0) the engine\'s G5 '
    'equals h4_kaluza_klein\'s reduction formula and the Christoffel route in all 25 components' % (len(FR), sum(g['eps'] == -1 for g in FR), sum(g['eps'] == 1 for g in FR), len(TUNED)))
all44 = all(g['G5'][N4][N4] == -g['P']['R4'] / 2 and all(g['G5'][N4][a] == 0 == g['G5'][a][N4] for a in range(N4)) for g in FR)
mat44 = all(g['G5'][N4][N4] == 0 and g['P']['R4'] == 0 for g in MATTER)
chk('R1', all44 and mat44, '[bit] the 44 equation at F = 0: G5^4_4 = -R4/2 and G5^4_a = G5^a_4 = 0 on all %d frames; on the %d frames of (A) the matter kappa5 T := G5 has '
    'T^4_4 = T^4_a = 0 and a non-zero 4D part (kappa5 T = %s on the first two; the identities need no energy condition) and R4 = 0 exactly: the 44 equation gives R4 = 0'
    % (len(FR), len(MATTER), ', '.join(str(trT(g)) for g in MATTER[:2])))
alltr = all(g['P']['box'] == g['P']['phi0'] * (trT(g) - 2 * g['G5'][N4][N4]) / 3 for g in FR)
mattr = all(g['P']['box'] == g['P']['phi0'] * trT(g) / 3 for g in MATTER)
chk('R2', alltr and mattr, '[bit] the trace of the 4D block with the 44 equation: box phi = kappa5 phi (T - 2 T^4_4)/3 on all %d frames; under (A) box phi = kappa5 phi T/3 '
    '= 8 pi T_4/(3 + 2 omega) with omega = 0 (box phi = %s on the first frame of (A)): the radius is sourced by the trace' % (len(FR), MATTER[0]['P']['box']))
rows, rhs = [], []
for g in FR:
    P = g['P']; p = P['phi0']
    for b in range(N4):
        for a in range(N4):
            rows.append([P['H'][b][a] / p, d(a, b) * P['box'] / p, P['P'][b][a] / p ** 2, d(a, b) * P['grad2'] / p ** 2]); rhs.append(g['G5'][b][a] - P['G4'][b][a])
wfit, rk, nv, cons = bl.solve_exact(rows, rhs)
def bd_holds(g, om):
    """both Brans-Dicke equations with parameter om at the origin of the frame g, with kappa5 T read off G5"""
    P = g['P']; p = P['phi0']; T_ = kT(g)
    metric = all(P['G4'][b][a] == T_[b][a] + om / p ** 2 * (P['P'][b][a] - d(a, b) * P['grad2'] / 2) + (P['H'][b][a] - d(a, b) * P['box']) / p for b in range(N4) for a in range(N4))
    return metric and P['box'] == p * trT(g) / (3 + 2 * om)
chk('R3', cons and rk == nv == 4 and wfit == [-1, 1, 0, 0] and all(bd_holds(g, OMEGA_CLAIM) for g in MATTER),
    '[bit] the 4D block: the exact fit of G5 - G4 over [Hess/phi, delta box/phi, grad grad/phi^2, delta |grad|^2/phi^2] on %d frames (%d equations, rank %d of %d) is %s: '
    'no (grad phi)^2 term; G4 = kappa5 T + (omega/phi^2)(grad phi grad phi - delta |grad phi|^2/2) + (Hess phi - delta box phi)/phi and box phi = kappa5 phi T/(3 + 2 omega) '
    'hold exactly on the %d frames of (A) with omega = %s: the reduced theory is Brans-Dicke with omega = %s'
    % (len(FR), len(rows), rk, nv, h4.fmt(wfit), len(MATTER), OMEGA_CLAIM, OMEGA_CLAIM))
# (R4) the shifted lowest order: X(c) = G5 - 6c delta with 4c = eps kappa^2
KAPPA2 = F(1, 3); rng4 = random.Random(7401); sh_ok = True; nsh = 0; sh_nomass = True
for eps in (1, -1):
    c = eps * KAPPA2 / 4
    for eps_f in (-1, 1):
        e4 = bl.rand_frame(rng4, N4, deg=2, coef=2, density=.5, nv=N4); phi = fresh_phi(rng4, F(5, 4))
        g = run_frame(tune(e4, phi, -12 * c), phi, eps_f, [c]); X = g['X'][c]; P = g['P']; p = P['phi0']; trX = sum(X[a][a] for a in range(N4))
        sh_ok &= X == g['Xstd'][c] and X[N4][N4] == 0 and all(X[N4][a] == 0 == X[a][N4] for a in range(N4)) and P['box'] == eps * KAPPA2 * p + p * trX / 3
        sh_nomass &= P['box'] != p * trX / 3; nsh += 1
chk('R4', sh_ok and sh_nomass, '[bit==std] the shifted lowest order Ric5 = eps kappa^2 (4c = eps kappa^2, kappa^2 = %s, eps = +1 and -1, both eps_f; %d frames tuned to T^4_4 = 0 at c, '
    'h4_cosmological\'s E_a(c)): box phi = eps kappa^2 phi + kappa5 phi T/3 exactly (without the eps kappa^2 phi term it fails on every frame); linearised, '
    '(box + m^2) dphi = kappa5 T/3 with m^2 = -eps kappa^2, of size kappa^2 = Lambda (the paper\'s (3.7)-(3.8))' % (KAPPA2, nsh))
# (R5) the matter: the five-dimensional divergence at the origin, Christoffel route
def christoffel0(g, n):
    g0 = [[bl.at0(g[(a, b)], N4) for b in range(n)] for a in range(n)]; det, g0i = bl.det_inv(g0)
    dg = lambda k, a, b: bl.at0(bl.sp_der(g[(a, b)], k), N4) if k < N4 else F(0)                 # nothing depends on y
    return {(l, m, v): F(1, 2) * sum(g0i[l][s] * (dg(m, s, v) + dg(v, s, m) - dg(s, m, v)) for s in range(n)) for l in range(n) for m in range(n) for v in range(n)}
def rpoly1(rng):
    """a random polynomial of degree 1 with a non-zero value at the origin"""
    p = {(0, 0, 0, 0): F(rng.choice([-3, -2, -1, 1, 2, 3]), rng.choice([1, 2]))}
    for i in range(N4):
        c = F(rng.randint(-3, 3), rng.choice([1, 2]))
        if c: p[tuple(int(j == i) for j in range(N4))] = c
    return p
def divergence_jet(rng, eps_f):
    e4 = bl.rand_frame(rng, N4, deg=2, coef=2, density=.5, nv=N4); phi = fresh_phi(rng, F(3, 2)); g4 = bl.std_metric(e4, N4, ETA4, N4, 2)
    g = {(A, B): (g4[(A, B)] if A < N4 and B < N4 else (bl.scale(bl.sp_mul(phi, phi, 2, N4), eps_f) if A == B == N4 else {})) for A in range(N5) for B in range(N5)}
    TU = {}
    for A in range(N5):
        for B in range(A, N5): TU[(A, B)] = TU[(B, A)] = {} if (A < N4) != (B < N4) else rpoly1(rng)        # T^{a4} = 0
    TM = {}
    for A in range(N5):
        for B in range(N5):
            t = {}
            for C in range(N5):
                if TU[(A, C)] and g[(C, B)]: t = bl.sp_add(t, bl.sp_mul(TU[(A, C)], g[(C, B)], 1, N4))
            TM[(A, B)] = t                                                                       # T^A_B, degree <= 1
    val = lambda p: bl.at0(p, N4); der = lambda p, k: bl.at0(bl.sp_der(p, k), N4) if k < N4 else F(0)
    G5_, G4_ = christoffel0(g, N5), christoffel0(g4, N4)
    div = lambda Gm, n, b: sum(der(TM[(A, b)], A) for A in range(n)) + sum(Gm[(A, A, C)] * val(TM[(C, b)]) for A in range(n) for C in range(n)) \
        - sum(Gm[(C, A, b)] * val(TM[(A, C)]) for A in range(n) for C in range(n))
    p0 = val(phi); dp = [der(phi, a) for a in range(N4)]; T44 = val(TM[(N4, N4)])
    div5 = [div(G5_, N5, b) for b in range(N4)]; div4 = [div(G4_, N4, b) for b in range(N4)]
    red = [div4[b] + sum(dp[a] / p0 * val(TM[(a, b)]) for a in range(N4)) - dp[b] / p0 * T44 for b in range(N4)]
    wrong = [div4[b] + sum(dp[a] / p0 * val(TM[(a, b)]) for a in range(N4)) for b in range(N4)]
    phiT = [p0 * div4[b] + sum(dp[a] * val(TM[(a, b)]) for a in range(N4)) for b in range(N4)]            # nabla4_a (phi T^a_b)
    return div5 == red, div5 != wrong and T44 != 0, phiT == [p0 * div5[b] + dp[b] * T44 for b in range(N4)]
rng5 = random.Random(7501); DIV = [divergence_jet(rng5, eps_f) for eps_f in (-1, -1, 1, 1)]
chk('R5', all(x[0] and x[2] for x in DIV), '[std] the five-dimensional divergence of a y-independent T with T^a_4 = 0 equals nabla4_a T^a_b + (d_a phi/phi) T^a_b - (d_b phi/phi) T^4_4 '
    'exactly at the origin of %d random jets (both eps_f), and nabla4_a (phi T^a_b) = phi (nabla5_A T^A_b) + (d_b phi) T^4_4: T_4 = L phi T is conserved in g4 iff T^4_4 = 0, '
    'so matter of kind (A) moves on geodesics of g4 (the Jordan frame of Brans-Dicke)' % len(DIV))

# ================================================================================================ (G) the point mass, linearised static field
def quad_poly(k, coef):
    """coef * (-(k.x)^2/2) in x^1..x^3 (four slots, static): its Hessian is -coef k_i k_j, the Fourier symbol of coef e^{i k.x} at x = 0"""
    p = {}
    for i in range(3):
        for j in range(3):
            ex = [0] * N4; ex[i + 1] += 1; ex[j + 1] += 1; ex = tuple(ex); p[ex] = p.get(ex, 0) - F(1, 2) * coef * k[i] * k[j]
    return {ex: v for ex, v in p.items() if v}
def static_frame(k, Ah, Bh, fh):
    """e^0 = (1 + a) dt, e^i = (1 - b) dx^i, phi = 1 + f with a = Ah q, b = Bh q, f = fh q, q = -(k.x)^2/2: g00 = 1 + 2a, g_ij = -(1 - 2b) delta_ij at linear order"""
    one = {(0,) * N4: F(1)}
    return [{1: bl.sp_add(one, quad_poly(k, Ah))}] + [{1 << i: bl.sp_add(one, quad_poly(k, -Bh))} for i in (1, 2, 3)], bl.sp_add(one, quad_poly(k, fh))
KVEC = [(-1, (1, 0, 0)), (-1, (1, 2, 2)), (-1, (2, -1, 3)), (1, (1, 2, 2))]
LIN = {}; lin_ok = True; bitstd = True
for eps_f, k in KVEC:
    cols = []
    for unit in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
        g = run_frame(*static_frame(k, *map(F, unit)), eps_f); cols.append(g['G5']); bitstd &= g['G5'] == g['G5std']
    gm = run_frame(*static_frame(k, F(2), F(-3), F(5, 2)), eps_f)
    lin_ok &= gm['G5'] == [[2 * cols[0][B][A] - 3 * cols[1][B][A] + F(5, 2) * cols[2][B][A] for A in range(N5)] for B in range(N5)]
    LIN[(eps_f, k)] = cols
def solve5(cols, w):
    """G5 = kappa5 T with kappa5 T^0_0 = 1 (= 8 pi M), kappa5 T^4_4 = w, the rest 0: (A^, B^, f^), exact; None if inconsistent or not unique"""
    rows, rhs = [], []
    for B in range(N5):
        for A in range(N5):
            rows.append([cols[j][B][A] for j in range(3)]); rhs.append(F(1) if A == B == 0 else (F(w) if A == B == N4 else F(0)))
    x, rk_, nv_, cons_ = bl.solve_exact(rows, rhs)
    return x if cons_ and rk_ == nv_ else None
def ksq(k): return sum(x * x for x in k)
S5 = {}
for (eps_f, k), cols in LIN.items():
    x = solve5(cols, 0); S5[(eps_f, k)] = None if x is None else tuple(v * ksq(k) for v in x)
sols = set(S5.values()); cA, cB, cF = next(iter(sols)) if len(sols) == 1 and None not in sols else (None, None, None)
gam5 = cB / cA if cA else None
chk('G1', lin_ok and bitstd and cA is not None and (cA, cB, cF) == (F(-2, 3), F(-1, 3), F(1, 3)) and gam5 == F(1, 2),
    '[bit==std] point mass M, linearised static field from the five-dimensional engine: at the origin of frames with quadratic potentials G5 is exactly linear '
    '(superposition exact) and is the Fourier symbol; G5 = kappa5 T (kappa5 T^0_0 = 8 pi M, T^4_4 = 0) has one solution for k = (1,0,0), (1,2,2), (2,-1,3) and at eps_f = +1: '
    '(A^, B^, f^) k^2/(8 pi M) = (%s, %s, %s), so dphi = %s M/r, g00 = 1 + 2A = 1 - 2 (%s M)/r, g_ij = -(1 - 2B) = -(1 + 2 (%s M)/r): Kepler mass %s M, gamma = B/A = %s'
    % (cA, cB, cF, 2 * cF, -2 * cA, -2 * cB, -2 * cA, gam5))
def solve4(cols, src, fsrc):
    """the 4D block alone: (A^, B^) for kappa5 T^0_0 = src and a given f^ = fsrc"""
    rows, rhs = [], []
    for b in range(N4):
        for a in range(N4): rows.append([cols[0][b][a], cols[1][b][a]]); rhs.append((F(src) if a == b == 0 else F(0)) - fsrc * cols[2][b][a])
    x, rk_, nv_, cons_ = bl.solve_exact(rows, rhs)
    return x if cons_ and rk_ == nv_ else None
RESP = set()
for (eps_f, k), cols in LIN.items():
    xm, xf = solve4(cols, 1, F(0)), solve4(cols, 0, F(1))
    RESP.add(None if xm is None or xf is None else (xm[0] * ksq(k), xm[1] * ksq(k), xf[0], xf[1]))
rAM, rBM, rAF, rBF = next(iter(RESP)) if len(RESP) == 1 and None not in RESP else (None,) * 4
OMEGAS = [F(0), F(1, 2), F(1), F(-1), F(5), F(40000)]; g2 = rAM is not None; lines = []
if g2:
    for om in OMEGAS:
        s = 1 / (3 + 2 * om); A_, B_ = rAM + rAF * s, rBM + rBF * s; gam = B_ / A_; al2 = A_ / rAM - 1
        g2 &= gam == (1 + om) / (2 + om) and al2 == 1 / (2 * om + 3) and gam == (1 - al2) / (1 + al2)
        if om == 0: g2 &= (A_, B_, s) == (cA, cB, cF); al2_0 = al2
        lines.append('%s: %s' % (om, gam))
chk('G2', g2 and (rAM, rBM, rAF, rBF) == (F(-1, 2), F(-1, 2), F(-1, 2), F(1, 2)),
    '[bit] the 4D block alone (all four wave vectors): A^ k^2/(8 pi M) = %s, B^ k^2/(8 pi M) = %s for the mass, A^/f^ = %s, B^/f^ = %s for the scalar (A = -M/r - dphi/2, '
    'B = -M/r + dphi/2); with Brans-Dicke\'s f^ = 8 pi M/((3 + 2 omega) k^2) the solved metric gives gamma = B/A = (1 + omega)/(2 + omega) exactly for omega = %s, '
    'alpha^2 = A/A_tensor - 1 = 1/(2 omega + 3) and gamma = (1 - alpha^2)/(1 + alpha^2); omega = 0 reproduces (G1): alpha^2 = %s, the scalar couples to the trace '
    'with gravitational strength' % (rAM, rBM, rAF, rBF, '; '.join(lines), al2_0 if g2 else None))
# (G3) the static propagators (scipy) and the field with the shifted mass
def ft_yukawa(m, r):
    """(1/(2 pi^2 r)) int_0^inf k sin(kr) 4 pi/(k^2 + m^2) dk"""
    if m == 0: v = quad(lambda k: math.sin(k * r) / k if k else r, 0, 1)[0] + quad(lambda k: 1 / k, 1, math.inf, weight='sin', wvar=r)[0]
    else: v = quad(lambda k: k / (k * k + m * m), 0, math.inf, weight='sin', wvar=r)[0]
    return 2 * v / (math.pi * r)
def ft_tachyon(K, r):
    """principal value of (1/(2 pi^2 r)) int_0^inf k sin(kr) 4 pi/(k^2 - K^2) dk: Cauchy weight on [0, 2K], QAWF beyond"""
    v1 = quad(lambda k: math.sin(k * r) * k / (k + K), 0, 2 * K, weight='cauchy', wvar=K, limit=200, epsabs=1e-13, epsrel=1e-12)[0]
    v2 = quad(lambda k: k / (k * k - K * K), 2 * K, math.inf, weight='sin', wvar=r, limlst=200)[0]
    return 2 * (v1 + v2) / (math.pi * r)
dy = max(abs(ft_yukawa(m, r) * r - math.exp(-m * r)) for m, r in ((0.7, 1.3), (2.0, 0.5), (0.0, 1.7)))
dt_ = max(abs(ft_tachyon(K, r) * r - math.cos(K * r)) for K, r in ((0.7, 1.3), (1.5, 0.8), (1.0, 2.5)))
def gamma_r(Y):
    """the solved field with the scalar profile Y(r) (dphi = (2/3)(M/r) Y): gamma(r) = B/A from the exact responses of (G2)"""
    A_ = 2 * rAM + rAF * F(2, 3) * Y; B_ = 2 * rBM + rBF * F(2, 3) * Y
    return B_ / A_, -A_, -B_
gr_ok = g2 and all(gamma_r(Y)[0] == (1 - Y / 3) / (1 + Y / 3) and gamma_r(Y)[1] == 1 + Y / 3 for Y in (F(1), F(1, 2), F(0), F(-1, 3)))
chk('G3', dy < 1e-9 and dt_ < 1e-9 and gr_ok, '[num] the static propagators by scipy: (1/(2 pi^2 r)) int k sin(kr) 4 pi/(k^2 + m^2) dk = e^{-mr}/r (m = 0.7, 2, 0; deviation %.1e) and its '
    'principal value at m^2 = -K^2 is cos(K r)/r (deviation %.1e); with the responses of (G2) and dphi = (2/3)(M/r) Y the solved field is g00 = 1 - 2 (M/r)(1 + Y/3), '
    'g_ij = -(1 + 2 (M/r)(1 - Y/3)), gamma(r) = (1 - Y/3)/(1 + Y/3), Y = e^{-mr} or cos(K r): gamma -> 1/2 where Y -> 1' % (dy, dt_))

# ================================================================================================ (Y) the sign and the range
kap = 1.0; fd = []; h = 1e-4
for eps in (-1, 1):
    Y = (lambda r: math.exp(-kap * r)) if eps == -1 else (lambda r: math.cos(kap * r))
    u = lambda r: Y(r) / r
    for r in (0.5, 1.3, 2.9):
        lap = (Y(r + h) - 2 * Y(r) + Y(r - h)) / h ** 2 / r                  # del^2 (Y/r) = (r u)''/r
        fd.append(abs(lap - (-eps * kap ** 2) * u(r)))
disp = {eps: -eps * kap ** 2 for eps in (-1, 1)}                            # E^2 at p = 0 from -E^2 + p^2 = eps kappa^2
chk('Y1', max(fd) < 1e-6 and disp[-1] > 0 and disp[1] < 0, '[num] the sign: with box = d_t^2 - del^2 a plane wave e^{-i(Et - p.x)} in box phi = eps kappa^2 phi (4.3) gives E^2 = p^2 - eps kappa^2, '
    'so m^2 = -eps kappa^2: eps = -1 (c(D+^2), anti-de Sitter) a massive scalar, E^2(p = 0) = +kappa^2, static field e^{-kappa r}/r (Yukawa); eps = +1 (D+D-, de Sitter, the case '
    'the paper fixes by Lambda = kappa^2 > 0) a tachyon, E = +-i kappa (the growing e^{kappa t} of (4.4)), static field cos(kappa r)/r, no decay; eps = 0 (D_s^2) massless; '
    'finite differences: del^2 (Y/r) = -eps kappa^2 Y/r to %.0e' % max(fd))
c_cms = 2.99792458e10; Mpc_cm = 3.0856775814913673e24; AU = 1.495978707e13
H0 = 67.36e5 / Mpc_cm; OL = 0.6847
Lam = 3 * OL * H0 ** 2 / c_cms ** 2                                         # (3.7) with Planck 2018
lam_range = AU if FAULT == 'RANGE1AU' else 1 / math.sqrt(Lam)               # 1/|m|, |m| = kappa = sqrt(Lambda) (3.8)
x_AU = AU / lam_range; sup = -math.expm1(-x_AU); tach = 2 * math.sin(x_AU / 2) ** 2; x10 = 10 * x_AU
dev = 1.5 * sup / (3 + math.exp(-x_AU)); dev_t = 1.5 * tach / (3 + math.cos(x_AU))   # gamma - 1/2 = 3 (1 - Y)/(2 (3 + Y)), from gamma(r) of (G3)
gAU = 0.5 + dev
chk('Y2', abs(Lam - 1.09e-56) < 0.01e-56 and 0.9e28 < lam_range < 1.1e28 and sup < 1e-14 and tach < 1e-28 and dev < 1e-14 and -math.expm1(-x10) < 1e-13,
    '[num] the range: Lambda = 3 Omega_L H0^2/c^2 = %.4e cm^-2 (Planck 2018), 1/sqrt(Lambda) = %.3e cm against 1 AU = %.6e cm: r/lambda = %.3e at 1 AU, so the Yukawa '
    'factor is e^{-r/lambda} = 1 - %.3e (eps = -1) and cos(r/lambda) = 1 - %.2e (eps = +1), at 10 AU 1 - %.2e: the radius is massless at solar-system scales, '
    'gamma(1 AU) - 1 = -1/2 + %.2e (eps = -1), -1/2 + %.1e (eps = +1); neglected background Lambda r^2 = %.1e'
    % (Lam, lam_range, AU, x_AU, sup, tach, -math.expm1(-x10), dev, dev_t, Lam * AU ** 2))

# ================================================================================================ (C) Cassini
g_mean, g_sig = 2.1e-5, 2.3e-5                                               # gamma - 1, Bertotti, Iess and Tortora, Nature 425, 374 (2003)
nsig = ((gAU - 1) - g_mean) / g_sig
chk('C1', 1.5e4 < abs(nsig) < 3e4, '[num] Cassini (Bertotti, Iess, Tortora 2003): gamma - 1 = (2.1 +- 2.3)e-5; the radius gives gamma - 1 = %.6f at 1 AU, %.4g standard deviations away: '
    'excluded by about 2e4 sigma' % (gAU - 1, nsig))
glo = g_mean - 2 * g_sig                                                     # two-sigma lower end of gamma - 1
al2max = -glo / (2 + glo); ommin = -1 / glo - 2
chk('C2', 1e-5 < al2max < 1.3e-5 and 3.9e4 < ommin < 4.1e4 and float(al2_0) / al2max > 2e4, '[num] the general bound: gamma - 1 > %.1e (two sigma) with gamma = (1 - alpha^2)/(1 + alpha^2) = (1 + omega)/(2 + omega) '
    'gives alpha^2 < %.3e and omega > %.3e, against alpha^2 = %s and omega = 0 for the radius (alpha^2 %.1e times the bound)' % (glo, al2max, ommin, al2_0, float(al2_0) / al2max))

# ================================================================================================ (W) finding: stress along the circle
wl = []; w_ok = True
for w in (F(1, 4), F(1, 2), F(-1), F(1)):
    sl = set()
    for (eps_f, k), cols in LIN.items():
        x = solve5(cols, w); sl.add(None if x is None else tuple(v * ksq(k) for v in x))
    if len(sl) != 1 or None in sl: w_ok = False; continue
    a_, b_, f_ = next(iter(sl)); gw = b_ / a_
    w_ok &= f_ == (1 - 2 * w) / 3 and gw == (1 + w) / (2 - w)
    if w != F(1, 2): om_eff = 3 * w / (1 - 2 * w); w_ok &= gw == (1 + om_eff) / (2 + om_eff); wl.append('w = %s: gamma = %s, omega_eff = %s' % (w, gw, om_eff))
    else: w_ok &= gw == 1 and f_ == 0 and a_ == F(-1, 2); wl.append('w = 1/2: gamma = 1, dphi = 0')
chk('W1', w_ok and all(x[0] for x in DIV), '[bit] finding, stress along the circle T^4_4 = w rho (for eps_f = -1 a pressure -w rho along y), the five-dimensional solve of (G1): '
    'dphi = 2 (1 - 2w) M/(3r) and gamma = (1 + w)/(2 - w), i.e. omega_eff = 3w/(1 - 2w) for the field of the source (%s); the radius decouples only at w = 1/2, a tension '
    'rho/2 along the circle; and by (R5) a body with w != 0 obeys nabla4_a T_4^a_b = w rho d_b ln phi: its mass goes as phi^w (not universal: equivalence principle)' % '; '.join(wl))

# ================================================================================================ (K) controls in the main run
chk('K1', all(not bd_holds(g, F(1)) and not bd_holds(g, F(-1)) for g in TUNED) and all(bd_holds(g, F(0)) for g in TUNED),
    '[ctl] Brans-Dicke with omega = 1 and with omega = -1 fails on each of the %d frames of (A), where omega = 0 holds' % len(TUNED))
x1 = 1.0; sup1 = -math.expm1(-x1); g1 = (1 - math.exp(-x1) / 3) / (1 + math.exp(-x1) / 3)
chk('K2', sup1 > 1e-14 and abs((g1 - 1 - g_mean) / g_sig) > 5e3, '[ctl] a massive scalar of range 1 AU: the Yukawa factor at 1 AU is e^{-1} = 1 - %.3f, not 1 - O(1e-15); '
    'it still gives gamma - 1 = %.4f there, %.3g sigma from Cassini' % (sup1, g1 - 1, (g1 - 1 - g_mean) / g_sig))
chk('K3', all(g['P']['R4'] != 0 and g['G5'][N4][N4] != 0 and g['P']['box'] != g['P']['phi0'] * trT(g) / 3 for g in UNTUNED) and all(x[1] for x in DIV),
    '[ctl] matter with stress along the circle (the %d untuned frames, T^4_4 = G5^4_4 != 0): R4 != 0 and box phi != kappa5 phi T/3 on each; the divergence of (R5) without the '
    '(d_b phi/phi) T^4_4 term fails on each of the %d jets' % (len(UNTUNED), len(DIV)))

print('     (total %.1f s)' % (time.time() - T0))
print('%d of %d checks hold' % (sum(ok), len(ok)))
print('FAILS (SHIFTED-FIFTH): ' + ('none' if all(ok) else ', '.join(n for n, o in zip(['R0', 'R1', 'R2', 'R3', 'R4', 'R5', 'G1', 'G2', 'G3', 'Y1', 'Y2', 'C1', 'C2', 'W1', 'K1', 'K2', 'K3'], ok) if not o)))
sys.exit(0 if all(ok) else 1)
