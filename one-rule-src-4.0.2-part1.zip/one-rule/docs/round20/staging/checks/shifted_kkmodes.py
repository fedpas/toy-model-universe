#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""SHIFTED-KK.  The massive modes on the circle of Atiyah and Moore's Kaluza-Klein reduction ("A shifted view of fundamental physics", section 4),
which ATY-054/ATY-055 leave aside: their masses, their descent as the circle grows on de Sitter space, where the zero-mode truncation fails, and where
the low-energy reading of the shifted operators holds for them.   python3 shifted_kkmodes.py <path of checks/selfcheck> [--fault NOPHI|NOR|ADIABATIC2]

Conventions.  The engine's (proofs/shifted_einstein.py, gravity/h4_kaluza_klein.py): squares sq = (1, -1, -1, -1, s), s the square of the fibre generator
(h4_kaluza_klein's eps: s = -1 is Cl(1,4), a space-like fibre; s = +1 is Cl(2,3)); coframe e^a = e4^a(x) (a < 4), e^4 = phi(x) dy with A = 0 (F = 0, the
case of the paper's (4.3)); metric e^T diag(sq) e; box = eta^ab nabla_a nabla_b (the Atlas's box is the paper's -nabla^2); D = d + delta on the full
algebra with D^2 = box - Ric on 1-forms (ATY-051).  The circle y ~ y + 2 pi R0 has proper length 2 pi R0 phi; the mode n is f(x) e^{i n y/R0}, k = n/R0.
Here, unlike in ATY-054, the fields DEPEND on y: the engine takes polynomial fields in all five coordinates (its d differentiates the y slot like any other).
hbar = c = 1; kappa = k/hbar; tau the shift (the paper's r); mu = kappa tau; x = m tau.  The paper's epsilon of (4.3) (eps kappa^2, +1 for D_+D_-) is a
different sign from s.
Statements and routes.
(M) [kk.MASS] (1) The scalar mode.  At the origin of random polynomial 2-jet frames (both s, five values of phi(0)), for f(x) g(y) with g = 1, y, y^2/2:
    box5(f g) = g box4 f + g phi^-1 grad phi.grad f + s f g''/phi^2, so for g = e^{iky} (2-jet 1 + i k y - k^2 y^2/2, the frame independent of y)
    box5(f e^{iny/R0}) = (box4 f + phi^-1 grad phi.grad f - s n^2 f/(R0 phi)^2) e^{iny/R0}:  s = -1 gives (box4 + phi^-1 grad phi.grad + m_n^2) f = 0 with
    m_n = |n|/(R0 phi) (the stated - n^2/(R0 phi)^2 in the paper's signature, where box -> -box); s = +1 gives m_n^2 = -n^2/(R0 phi)^2, a tachyonic tower.
    Routes: [std] own Christoffel calculus on the five-dimensional metric (exact Fractions, no engine): g^MN (d_M d_N F - Gamma^K_MN d_K F) at the origin;
    the four-dimensional pieces by the same route on e4^T eta e4; [bit] the engine (shifted_einstein's nabla, second_cov, box_of on engine_setup);
    [bit==std]; an exact fit over the frames fixes the powers of phi (the fibre term is s phi^-2, the gradient term phi^-1, no other power).
    (2) 1-forms on the product frame (phi constant): X = sum_A f_A(x) g(y) gamma_A; on the engine D5^2 X = box5 X - Ric5(X), and on the mode
    D5^2 = D4^2 - s n^2/(R0 phi)^2 (D4^2 = box4 - Ric4 on the base part, box4 on the fibre component; Ric5 = Ric4 + 0); on a flat base the curvature
    terms vanish and D5^2 = box4 - s (n/(R0 phi))^2 componentwise ([std] the coordinate wave operator); on a curved base (the four-dimensional engine
    as reference) the curvature term is -Ric4 on the base part and none on the fibre part.  For s = -1: D5^2 = D4^2 + m_n^2.
(G) [kk.GROW] (1) The mode equation on the de Sitter base with the growing radius, derived, not assumed: g5 = diag(1, -a^2, -a^2, -a^2, s phi^2),
    a = e^{Ht}, phi = phi0 e^{rt} (exact exponential monomials): the friction is d ln sqrt|g5|/dt (volume route) = -g^MN Gamma^t_MN (Christoffel route)
    = 3H + r, sqrt|g5| = a^3 phi; g^MN Gamma^y_MN = 0; the mass term -s k^2 e^{-2rt}/phi0^2: f'' + (3H + r) f' + m_n(t)^2 f = 0, m_n(t) = |n| e^{-rt}/(R0 phi0)
    for s = -1, so m_n(t) ~ e^{-rt}: the tower descends; adiabaticity parameter |m1'/m1^2| = r/m1.
    (2) [bit] The engine exactly in the chart (Laurent polynomials, conformal time): e^a = -dx^a/(H eta), e^4 = (-eta)^p dy, field (-eta)^q y^j/j!,
    j = 0, 1, 2: box5 = H^2 q (q + p - 3) (-eta)^q y^j/j! + s (-eta)^(q - 2p) [j = 2]; in cosmic time (-H eta = e^{-Ht}, r = -pH, f ~ e^{-qHt}) this is
    f'' + (3H + r) f' with the mass term s k^2/phi^2: the friction read off for each p is 3H + r (p = -2, -1, 1; q = -2..3; H = 1, 1/2; both s).
    (3) [std] scipy solve_ivp on the n = 1 equation in s = rt from r/m1 = 1e-3, eight initial phases, (H, r) = (kappa/2, kappa/2) (the five-dimensional
    de Sitter solution of ATY-055) and the base 3H^2 = kappa^2 with r = kappa (sqrt 7 - sqrt 3)/2: the exact solution z^nu (c1 J_nu(z) + c2 Y_nu(z)),
    z = m1/r, nu = (3H + r)/(2r), agrees; the adiabatic invariant J = V (f'^2 + m1^2 f^2)/(2 m1), V = a^3 phi (energy over frequency, the volume factor
    included) oscillates with relative amplitude (3H/2)/m1 (first order: the friction 3H + r minus the decay rate r of m1) and the first-order corrected
    I = V ((f' + (3H/2) f)^2 + m1^2 f^2)/(2 m1) changes only at second order, ((3H + r)/r)^2 (r/m1)^2/8 (sqrt(V) f oscillates at
    sqrt(m1^2 - (3H + r)^2/4)), while r/m1 << 1; at r/m1 = 1 and 2 J changes by factors O(1) to O(10):
    the oscillation stops at m1 = (3H + r)/2 (the frequency of sqrt(V) f vanishes) and the mode freezes like the zero mode.  For H = r = kappa/2 that is
    m1 = kappa, a circle of size 1/kappa, half the Hubble length 1/H = 2/kappa (r/m1 = 1 at the Hubble length).  Numbers: e-foldings ln(1/(kappa R0 phi0))
    and the time with 1/r = 2 hbar/kc.
(S) [kk.SHIFT] (1) The series of ATY-052 by own exact series (Fractions in kappa, tau; D_+ = D + kappa e^{-tau D}, D_- = D - kappa e^{tau D},
    D_s = D + kappa sinh(tau D); Ricci_++ - Ricci = even part of D_+^2 - D^2, etc.) to D^28: ATY-052's c_0..c_3, the closed forms c_j = kappa tau^(2j-1)
    alpha_j + kappa^2 tau^(2j) beta_j; the ratio c_(j+1) m^2/c_j = x^2 (alpha_(j+1) + mu beta_(j+1))/(alpha_j + mu beta_j) exactly, x^2/(2j(2j+1)) at mu -> 0
    for all three (exactly for D_+D_-): on D^2 = -m^2 the series is an expansion in (m tau)^2, low-energy only while m tau << 1; for (3.5a,b) the first
    ratio is c_1 m^2/c_0 = -(2x^2/mu)(1 - mu), 2x^2/mu: the D^2 term overtakes the constant kappa^2 already at m^2 = kappa/(2 tau).  (2) Numbers for the tower,
    in the four-dimensional reading D^2 = D4^2 = -m_n^2; in the five-dimensional one (the paper shifts the five-dimensional operator) D5^2 = D4^2 + m_n^2 on the
    product (M2) vanishes on an ordinary mode for every n, and a root -(j pi/tau)^2 of the series in D5^2 would give M^2 = m_n^2 + (j pi/tau)^2 (a reading).
    (3) Roots of the series at D^2 = -m^2: exact series identities (to x^28) with the closed forms Ricci_ss - Ricci = -(kappa/tau) sin x (2x + mu sin x),
    and on their matched backgrounds Ricci_++ (Lambda = -kappa^2) = (2 kappa/tau) sin x (x - mu sin x)... (the paper's signs, Ricci = Lambda):
    every operator has the factor sin(m tau), so roots at m_j = j pi/tau, j >= 1, exactly, for every small mu; Ricci_+- - Ricci and Ricci_++ - Ricci
    without the background term have roots at x_j = j pi +- (-1)^j mu/(2 j pi) + O(mu^2) (scipy brentq), the first also x_0 = sqrt(mu/2); off the
    timelike axis the second factors of Ricci_ss and Ricci_++ have roots at |tau D| ~ ln(4/mu), ln(2/mu) (complex, and one real D^2 > 0 for ++; Newton,
    counted by the argument principle), Ricci_+- none; the truncations at D^2J (the low-energy reading) place the first root at sqrt 6 (J = 2), none
    (J = 3), ... converging to pi.
Inputs (sources).  A circle of the Planck length R0 phi0 = 1.616e-33 cm (an input); kappa = 1.04e-28 cm^-1, sqrt(Lambda) of Planck 2018 as the Atlas
uses it (shifted_review.py: H0 = 67.36 km/s/Mpc, Omega_L = 0.6847 give 1.044e-28); the lightest neutrino below 0.45 eV (KATRIN, 90 % CL) giving
tau >= lambda_C/4 = 6.9e-5 cm (ATY-005's quantization tau = (2n+1) lambda_C/4); hbar c = 1.973269804e-5 eV cm, hc = 1.239841984e-4 eV cm,
c = 2.99792458e10 cm/s, the Julian year.
Controls (--fault puts each into the main checks; the run must end with FAILS and exit 1): NOPHI the mass formula without the 1/phi (m_n = |n|/R0);
NOR the friction 3H without r; ADIABATIC2 the claim that the truncation stays adiabatic (J within 10 %) at r/m1 = 2.  In the main run [ctl] lines show
that the first two differ from the engine.
Scope.  F = 0 (A = 0): the charge of the modes is not computed; values at the origin of polynomial 2-jet frames (exact) and identities in the chart of de
Sitter (Laurent, exact); the 1-forms on product frames (phi constant) only; the growth on the two (H, r) of ATY-055, numerically (scipy, double);
the shifted operators as series in D^2 on modes with D^2 a number (the paper's reading), not as operator equations; the roots are those of the
series' sums (entire functions), not solutions of a field theory built here.  No sympy in the run environment: every exact step uses Fractions
(standard library) and own series code.  No claim about nature."""
import os, sys, time, math, cmath, ast, types, random, itertools
from fractions import Fraction as Fr

ARGS = sys.argv[1:]
FAULTS = ('NOPHI', 'NOR', 'ADIABATIC2')
FAULT = None
if '--fault' in ARGS:
    i_ = ARGS.index('--fault'); FAULT = ARGS[i_ + 1] if i_ + 1 < len(ARGS) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
POS = [a for i, a in enumerate(ARGS) if not a.startswith('--') and not (i > 0 and ARGS[i - 1] == '--fault')]
if not POS: raise SystemExit('usage: python3 shifted_kkmodes.py <path of checks/selfcheck> [--fault NOPHI|NOR|ADIABATIC2]')
SELF = os.path.abspath(POS[0]); GRAVD = os.path.join(SELF, 'gravity'); SE_PATH = os.path.join(SELF, 'proofs', 'shifted_einstein.py')
for f_ in (os.path.join(SELF, 'gravity_selfcheck.py'), os.path.join(GRAVD, 'b1lib.py'), os.path.join(GRAVD, 'h4_kaluza_klein.py'), SE_PATH):
    if not os.path.isfile(f_): raise SystemExit('not found: %s (the argument is the checks/selfcheck folder of the Atlas)' % f_)
for p_ in (SELF, GRAVD):
    if p_ not in sys.path: sys.path.insert(0, p_)
sys.dont_write_bytecode = True
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import jv, yv
from scipy.optimize import brentq
import b1lib as BL
from b1lib import F, Lie, Grav, trunc, pm, at0, padd, scale, bmul, LORENTZ, rand_frame
import e1_lichnerowicz as E1
import h4_kaluza_klein as H4

T0 = time.time(); FAILS = []
def chk(tag, cond, msg):
    cond = bool(cond); print('%s[%s] %s' % ('ok   ' if cond else 'FAIL ', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def info(s): print('     ' + s, flush=True)
def tick(label): info('(%s: %.1f s)' % (label, time.time() - T0))
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
PHIPOW = 0 if FAULT == 'NOPHI' else 2                                   # the power of phi under the fibre term: m_n^2 ~ phi^-PHIPOW
FRICTION_R = 0 if FAULT == 'NOR' else 1                                 # the claimed friction 3H + FRICTION_R * r

# ------------------------------------------------------------------------------------------------ the full-algebra connection of shifted_einstein.py (definitions only)
SE_FUNCS = ('clean', 'mv_add', 'mvp_add', 'at0_mv', 'grades', 'D_full', 'contract', 'nabla', 'dirac', 'second_cov', 'box_of', 'engine_setup',
            'mono', 'exact_setup', 'form2_eval', 'ricci_exact', 'sum_polys', 'box_exact', 'D_exact')
def load_se(path):
    """the function definitions SE_FUNCS of proofs/shifted_einstein.py, executed alone (the module itself runs its checks at import)"""
    with open(path) as fh: tree = ast.parse(fh.read(), path)
    nodes = [nd for nd in tree.body if isinstance(nd, ast.FunctionDef) and nd.name in SE_FUNCS]
    assert sorted(nd.name for nd in nodes) == sorted(SE_FUNCS), 'shifted_einstein.py: definitions missing'
    ns = dict(Fr=F, padd=padd, bmul=bmul, pm=pm, trunc=trunc, at0=at0, scale=scale, itertools=itertools, fault=lambda name: False,
              bl=BL, e1=E1, Lie=Lie, Grav=Grav)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), path, 'exec'), ns)
    return types.SimpleNamespace(**{k: ns[k] for k in SE_FUNCS})
SE = load_se(SE_PATH)

def E0c_of(d):
    n = d['n']; return [[({(0,) * n: d['E0'][mu][a]} if d['E0'][mu][a] else {}) for a in range(n)] for mu in range(n)]
def engine_box_scalar(d, p):
    """[bit] box of the scalar field p (polynomial in all n coordinates) at the origin"""
    n = d['n']; nab = SE.nabla(d['Gv'], d['om'], d['E'], {0: p}, n, 1)
    return at0(SE.box_of(SE.second_cov(d['Gv'], d['om'], E0c_of(d), nab, n, 0), n, d['sq']).get(0, {}), n)
def engine_D2_box(d, X):
    """[bit] D^2 X and box X at the origin (multivector fields with polynomial coefficients)"""
    n, sq, Gv, om, E = d['n'], d['sq'], d['Gv'], d['om'], d['E']
    nab1 = SE.nabla(Gv, om, E, X, n, 1); Phi = SE.dirac(nab1, n, sq)
    D2 = SE.at0_mv(SE.dirac(SE.nabla(Gv, om, E, Phi, n, 0), n, sq), n)
    Lap = SE.at0_mv(SE.box_of(SE.second_cov(Gv, om, E0c_of(d), nab1, n, 0), n, sq), n)
    return D2, Lap

# ------------------------------------------------------------------------------------------------ [std] own polynomial Christoffel calculus (no engine, no b1lib)
def p_mul(a, b):
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            k = tuple(x + y for x, y in zip(k1, k2)); r[k] = r.get(k, 0) + v1 * v2
    return {k: v for k, v in r.items() if v}
def p_add(a, b, c=1):
    r = dict(a)
    for k, v in b.items(): r[k] = r.get(k, 0) + c * v
    return {k: v for k, v in r.items() if v}
def p_der(a, i):
    r = {}
    for k, v in a.items():
        if k[i]: kk = list(k); kk[i] -= 1; r[tuple(kk)] = r.get(tuple(kk), 0) + v * k[i]
    return {k: v for k, v in r.items() if v}
def p0(a, n): return a.get((0,) * n, Fr(0))
def g_inv(M):
    n = len(M); A = [list(map(Fr, r)) + [Fr(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[p] = A[p], A[c]; iv = 1 / A[c][c]; A[c] = [x * iv for x in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0: f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return [r[n:] for r in A]
def std_metric(e, sq, n):
    """g_MN = sum_a sq_a e^a_M e^a_N (exact polynomials)"""
    g = [[{} for _ in range(n)] for _ in range(n)]
    for M in range(n):
        for N in range(n):
            for a in range(n):
                u, v = e[a].get(1 << M, {}), e[a].get(1 << N, {})
                if u and v: g[M][N] = p_add(g[M][N], p_mul(u, v), sq[a])
    return g
def std_box(g, Fp, n):
    """[std] g^MN (d_M d_N F - Gamma^K_MN d_K F) at the origin"""
    gi = g_inv([[p0(g[M][N], n) for N in range(n)] for M in range(n)])
    dg = [[[p0(p_der(g[M][N], K), n) for N in range(n)] for M in range(n)] for K in range(n)]
    Gam = [[[Fr(1, 2) * sum(gi[K][L] * (dg[M][L][N] + dg[N][L][M] - dg[L][M][N]) for L in range(n)) for N in range(n)] for M in range(n)] for K in range(n)]
    dF = [p0(p_der(Fp, K), n) for K in range(n)]
    return sum(gi[M][N] * (p0(p_der(p_der(Fp, M), N), n) - sum(Gam[K][M][N] * dF[K] for K in range(n))) for M in range(n) for N in range(n))
def std_grad(g, a, b, n):
    gi = g_inv([[p0(g[M][N], n) for N in range(n)] for M in range(n)])
    return sum(gi[M][N] * p0(p_der(a, M), n) * p0(p_der(b, N), n) for M in range(n) for N in range(n))
def with_y(p4, j):
    """f(x) y^j / j! in five slots"""
    return {k + (j,): v / math.factorial(j) for k, v in p4.items()}

# ================================================================================================ (M) the masses of the modes
def part_M():
    head('(M) [kk.MASS] the modes f(x) e^{i n y/R0} on e^a = e4^a(x), e^4 = phi(x) dy: the engine with y-dependent fields, and own Christoffel calculus')
    PHI0 = (Fr(2), Fr(1, 2), Fr(3, 2), Fr(3), Fr(5, 4))
    ok_std = ok_bit = ok_bs = True; nfr = 0; rows = {}; ctl_seen = ctl_dif = 0; vals = []
    for s in (-1, 1):
        sq5 = [1, -1, -1, -1, s]; rows[s] = ([], [], [], [])
        for k, ph0 in enumerate(PHI0):
            rng = random.Random(9100 + 10 * k + (s > 0))
            e4 = rand_frame(rng, 4, deg=2, coef=2, density=.5)
            phi = H4.rand_poly4(rng, deg=2, coef=1, density=.6, c0=ph0)
            f = H4.rand_poly4(rng, deg=2, coef=3, density=.8, c0=rng.choice([1, 2, -1, 3]))
            e5 = H4.kk_frame(e4, [{} for _ in range(4)], phi)
            d5 = SE.engine_setup(e5, 5, sq5)
            g5 = std_metric(e5, sq5, 5); g4 = std_metric(e4, LORENTZ(4), 4)
            box4f = std_box(g4, f, 4); grad = std_grad(g4, phi, f, 4); f0 = p0(f, 4)
            pred = [box4f + grad / ph0, Fr(0), s * f0 / ph0 ** PHIPOW]
            B = [engine_box_scalar(d5, with_y(f, j)) for j in range(3)]
            S = [std_box(g5, with_y(f, j), 5) for j in range(3)]
            ok_std &= S == pred; ok_bit &= B == pred; ok_bs &= B == S; nfr += 1
            ctl_seen += 1; ctl_dif += int(B[2] != s * f0)
            r = rows[s]
            r[0].append([f0 / ph0 ** p for p in range(4)]); r[1].append(B[2])
            r[2].append([grad / ph0 ** p for p in range(3)]); r[3].append(B[0] - box4f)
            vals.append((s, ph0, B))
    info('e.g. s = -1, phi(0) = 2: box5(f g) at the origin for g = 1, y, y^2/2: %s' % ', '.join(str(x) for x in vals[0][2]))
    chk('std', ok_std, 'kk.MASS: own Christoffel calculus on g5 = e^T diag(1,-1,-1,-1,s) e, %d random 2-jet frames (s = -1, +1; phi(0) = 2, 1/2, 3/2, 3, 5/4), '
        'fields f(x) g(y): box5(f g)(0) = g box4 f + g phi^-1 grad phi.grad f + s f g\'\'/phi^2 (the four-dimensional pieces by the same route on e4^T eta e4), '
        'so box5(f e^{iny/R0}) = (box4 f + phi^-1 grad phi.grad f - s n^2 f/(R0 phi)^2) e^{iny/R0} exactly, for every n' % nfr)
    chk('bit', ok_bit, 'kk.MASS: the engine (y-dependent fields, polynomial in all five slots) gives the same at every frame: box5 of f, f y, f y^2/2 = '
        '(box4 f + phi^-1 grad phi.grad f, 0, s f/phi^2): for s = -1 (Cl(1,4)) the mode n solves (box4 + phi^-1 grad phi.grad + m_n^2) f = 0, m_n = |n|/(R0 phi) '
        '(the stated -n^2/(R0 phi)^2 in the paper\'s signature); for s = +1 (Cl(2,3)) m_n^2 = -n^2/(R0 phi)^2: a tachyonic tower')
    chk('bit==std', ok_bs, 'kk.MASS: the engine equals the five-dimensional Christoffel route on all %d frames and all three jets' % nfr)
    okfit = True; fits = {}
    for s in (-1, 1):
        r = rows[s]
        w2, rk2, nv2, c2 = BL.solve_exact(r[0], r[1]); w0, rk0, nv0, c0 = BL.solve_exact(r[2], r[3])
        fits[s] = (w2, w0)
        want2 = [0, 0, s, 0] if PHIPOW == 2 else [s, 0, 0, 0]                 # the claimed power of phi in the fibre term
        okfit &= bool(c2 and rk2 == nv2 == 4 and w2 == want2)
        okfit &= bool(c0 and rk0 == nv0 == 3 and w0 == [0, 1, 0])
    info('exact fits: fibre term over {f phi^0, f phi^-1, f phi^-2, f phi^-3}: s = -1 %s, s = +1 %s;  box5 f - box4 f over {grad, phi^-1 grad, phi^-2 grad}: %s, %s'
         % ([str(x) for x in fits[-1][0] or []], [str(x) for x in fits[1][0] or []], [str(x) for x in fits[-1][1] or []], [str(x) for x in fits[1][1] or []]))
    chk('bit', okfit, 'kk.MASS: exact fits over the five frames of each s (distinct phi(0)): the fibre term is s phi^-2 f (unique, rank 4 of 4) and the gradient term '
        'phi^-1 grad phi.grad f (rank 3 of 3), no other power of phi: the 1/phi in m_n = |n|/(R0 phi) is g^yy = s/phi^2, and the phi^-1 grad phi term the volume '
        'factor sqrt|g5| = phi sqrt|g4|; neither is chosen')
    if FAULT is None:
        chk('ctl', ctl_dif == ctl_seen, 'kk.MASS: control: the mass formula without the 1/phi (fibre term s f, m_n = |n|/R0) differs from the engine on %d of %d frames' % (ctl_dif, ctl_seen))
    tick('M scalars')
    # (2) 1-forms on product frames (phi constant)
    one = {(0,) * 4: Fr(1)}
    ok_flat = True; ok_curv = True; ok_ric = True; nf = 0; ric_nz = True
    for s in (-1, 1):
        sq5 = [1, -1, -1, -1, s]
        for k, (base, ph0) in enumerate((('flat', Fr(2)), ('flat', Fr(3, 2)), ('curved', Fr(2)), ('curved', Fr(1, 3)))):
            rng = random.Random(9300 + 10 * k + (s > 0))
            e4 = [{1 << a: dict(one)} for a in range(4)] if base == 'flat' else rand_frame(rng, 4, deg=2, coef=2, density=.5)
            e5 = H4.kk_frame(e4, [{} for _ in range(4)], {(0,) * 4: ph0}); d5 = SE.engine_setup(e5, 5, sq5)
            fA = [H4.rand_poly4(rng, deg=2, coef=3, density=.8, c0=rng.choice([1, -2, 3])) for _ in range(5)]
            if base == 'curved':
                d4 = SE.engine_setup(e4, 4, LORENTZ(4))
                D4, _ = engine_D2_box(d4, {1 << a: fA[a] for a in range(4)}); b44 = engine_box_scalar(d4, fA[4])
                ric5, ric4 = d5['ric'], d4['ric']
                ok_ric &= all(ric5[(a, b)] == ric4[(a, b)] for a in range(4) for b in range(4)) and all(ric5[(a, 4)] == 0 == ric5[(4, a)] for a in range(5))
                ric_nz &= any(ric4[(a, b)] != 0 for a in range(4) for b in range(4))
                pred0 = SE.clean({**{1 << a: D4.get(1 << a, Fr(0)) for a in range(4)}, 1 << 4: b44})
            else:
                pred0 = SE.clean({1 << A: sum(LORENTZ(4)[a] * p0(p_der(p_der(fA[A], a), a), 4) for a in range(4)) for A in range(5)})
            pred2 = SE.clean({1 << A: s * p0(fA[A], 4) / ph0 ** PHIPOW for A in range(5)})
            X0 = {1 << A: p0(fA[A], 4) for A in range(5)}
            RicX = SE.clean({1 << b: sum(sq5[b] * d5['ric'][(b, dd)] * X0[1 << dd] for dd in range(5)) for b in range(5)})
            res = []
            for j in range(3):
                D2, Lap = engine_D2_box(d5, {1 << A: with_y(fA[A], j) for A in range(5)})
                res.append((D2, Lap, SE.grades(D2)))
            okj = (res[0][0] == pred0 and SE.mv_add(res[0][0], res[0][1], -1) == SE.mv_add({}, RicX, -1) and res[1][0] == {} and res[1][1] == {}
                   and res[2][0] == pred2 and res[2][1] == pred2 and all(r_[2] in ([1], []) for r_ in res))
            if base == 'flat': ok_flat &= okj and RicX == {} and res[0][0] == res[0][1]
            else: ok_curv &= okj and RicX != {}
            nf += 1
    chk('bit', ok_flat, 'kk.MASS: 1-forms X = sum_A f_A(x) g(y) gamma_A (all five components) on the product frame e^a = dx^a, e^4 = phi0 dy (phi0 = 2, 3/2, both s): '
        'D5^2 X = box5 X (the curvature term of the Weitzenboeck formula vanishes) and, componentwise, D5^2 of f, f y, f y^2/2 = (eta^aa d_a^2 f, 0, s f/phi0^2): '
        'on the mode, D5^2 = box4 - s (n/(R0 phi0))^2, for s = -1 D5^2 = box4 + m_n^2 = D4^2 + m_n^2 (the paper\'s -nabla4^2 + m_n^2)')
    chk('bit', ok_curv and ok_ric and ric_nz, 'kk.MASS: the same on a curved base (random 2-jet e4, phi0 = 2, 1/3, both s), the four-dimensional engine as reference: '
        'Ric5 = Ric4 + 0 (no fibre row or column), D5^2 X - box5 X = -Ric5(X), and on the mode D5^2 = D4^2 - s (n/(R0 phi0))^2 with D4^2 = box4 - Ric4 on '
        'the base part and box4 on the fibre component: the curvature terms are those of the base alone; the n-dependence is the mass term only')
    tick('M 1-forms')

# ================================================================================================ (G) the growth: the tower descends
def es_add(a, b, c=1):
    r = dict(a)
    for k, v in b.items(): r[k] = r.get(k, 0) + c * v
    return {k: v for k, v in r.items() if v}
def es_mul(a, b):
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items(): r[k1 + k2] = r.get(k1 + k2, 0) + v1 * v2
    return {k: v for k, v in r.items() if v}
def es_der(a): return {k: v * k for k, v in a.items() if v * k}
def es_inv(a):
    (k, v), = a.items(); return {-k: 1 / v}
def fr_sqrt(x):
    x = Fr(x); a, b = math.isqrt(x.numerator), math.isqrt(x.denominator); assert a * a == x.numerator and b * b == x.denominator; return Fr(a, b)
def derive_mode(H, r, s, phi0):
    """[std] g5 = diag(1, -a^2, -a^2, -a^2, s phi^2), a = e^{Ht}, phi = phi0 e^{rt}, as exponential monomials {rate: coefficient}; F = f(t) e^{iky}.
    Returns (friction by the volume route, by the Christoffel route, the y-friction g^MN Gamma^y_MN, the mass term -g^yy k^2 / k^2, sqrt|g5|)."""
    g = [{Fr(0): Fr(1)}] + [{2 * H: Fr(-1)}] * 3 + [{2 * r: s * phi0 ** 2}]; n = 5
    gi = [es_inv(x) for x in g]
    det = {Fr(0): Fr(1)}
    for x in g: det = es_mul(det, x)
    (lam, c), = det.items(); vol = {lam / 2: fr_sqrt(abs(c))}
    fric_vol = es_mul(es_inv(vol), es_der(es_mul(vol, gi[0])))                 # (1/sqrt g) d_t (sqrt g g^tt d_t f): the coefficient of f'
    def dg(K, M, N): return es_der(g[M]) if (K == 0 and M == N) else {}         # d_K g_MN (the metric depends on t only, diagonal)
    def Gam(K, M, N):
        t = es_add(es_add(dg(M, K, N), dg(N, K, M)), dg(K, M, N), -1)          # g_KK diagonal: Gamma^K_MN = (1/2) g^KK (d_M g_KN + d_N g_KM - d_K g_MN)
        return {k: v / 2 for k, v in es_mul(gi[K], t).items()}
    fric_chr = {}; fric_y = {}
    for M in range(n):
        fric_chr = es_add(fric_chr, es_mul(gi[M], Gam(0, M, M)), -1)
        fric_y = es_add(fric_y, es_mul(gi[M], Gam(4, M, M)), -1)
    return fric_vol, fric_chr, fric_y, {k: -v for k, v in gi[4].items()}, vol

def part_G():
    head('(G) [kk.GROW] the growth: phi ~ e^{rt} on the de Sitter base; the n = 1 mode equation, derived; adiabaticity; where the truncation fails')
    ok = True; okm = True; seen = []
    for H, r in ((Fr(1), Fr(1)), (Fr(1, 2), Fr(1, 2)), (Fr(1), Fr(1, 3)), (Fr(1, 2), Fr(-1)), (Fr(3), Fr(2))):
        for s in (-1, 1):
            fv, fc, fy, m2, vol = derive_mode(H, r, s, Fr(2))
            claim = {Fr(0): 3 * H + FRICTION_R * r}
            ok &= fv == claim and fc == claim and fy == {} and vol == {3 * H + r: Fr(2)}
            claim_m2 = {-2 * r: Fr(-s) / Fr(2) ** 2} if PHIPOW == 2 else {Fr(0): Fr(-s)}   # NOPHI: m_n = |n|/R0, constant
            okm &= m2 == claim_m2
            seen.append((H, r, fv.get(Fr(0)), fc.get(Fr(0))))
    info('friction read off (H, r) -> (volume route, Christoffel route): ' + '; '.join('(%s, %s) -> (%s, %s)' % x for x in seen[::2]))
    chk('std', ok, 'kk.GROW: derived, not assumed (exact exponential monomials): on g5 = diag(1, -a^2, -a^2, -a^2, s phi^2), a = e^{Ht}, phi = 2 e^{rt}, five (H, r), both s: '
        'sqrt|g5| = a^3 phi = 2 e^{(3H + r)t}; for F = f(t) e^{iky} the coefficient of f\' is d ln sqrt|g5|/dt (volume route) = -g^MN Gamma^t_MN (Christoffel route) = 3H + r, '
        'and g^MN Gamma^y_MN = 0: the n = 1 mode obeys f\'\' + (3H + r) f\' + m1(t)^2 f = 0')
    chk('std', okm, 'kk.GROW: the mass term is -g^yy k^2 = -s k^2 e^{-2rt}/phi0^2: for s = -1, m_n(t) = |n| e^{-rt}/(R0 phi0) = |n|/(R0 phi(t)), so the tower descends as e^{-rt} '
        '(d ln m_n/dt = -r for every n) and the adiabaticity parameter is |m1\'/m1^2| = r/m1 = r R0 phi(t), growing as e^{rt}')
    # (2) the engine, exactly in the chart
    okE = True; ctl_seen = ctl_dif = 0; gam_read = {}
    for H in (Fr(1), Fr(1, 2)):
        for p in (-2, -1, 1):
            for s in (-1, 1):
                d = SE.exact_setup([SE.mono(5, (-1, 0, 0, 0, 0), -1 / H)] * 4 + [SE.mono(5, (p, 0, 0, 0, 0), (-1) ** (p % 2))], 5, [1, -1, -1, -1, s])
                okE &= d['torsion_free']
                r_ = -p * H; gam_claim = 3 * H + FRICTION_R * r_
                for q in (-2, -1, 1, 2, 3):
                    sg = Fr((-1) ** (q % 2))
                    lam = (q * H) ** 2 - q * H * gam_claim                     # f = e^{-qHt}: f'' + gamma f' = ((qH)^2 - qH gamma) f
                    for j in range(3):
                        b = SE.box_exact(d, {0: {(q, 0, 0, 0, j): sg / math.factorial(j)}}).get(0, {})
                        pred = {(q, 0, 0, 0, j): sg * lam / math.factorial(j)} if lam else {}
                        if j == 2:
                            key = (q - 2 * p if PHIPOW == 2 else q, 0, 0, 0, 0); pred = dict(pred); pred[key] = pred.get(key, 0) + s * Fr((-1) ** (key[0] % 2))
                            pred = {k: v for k, v in pred.items() if v}
                        okE &= b == pred
                        if j == 0 and q == 1:
                            v = b.get((1, 0, 0, 0, 0), Fr(0)) / sg; gam_read[(H, p)] = (H * H - v) / H        # v = H^2 - H gamma
                        if j == 0 and p * q != 0:
                            lw = (q * H) ** 2 - q * H * 3 * H                  # the friction 3H without r
                            ctl_seen += 1; ctl_dif += int(b != ({(q, 0, 0, 0, 0): sg * lw} if lw else {}))
    info('friction read off the engine (q = 1): ' + ', '.join('H = %s, p = %s (r = %s): %s' % (H, p, -p * H, g_) for (H, p), g_ in sorted(gam_read.items())))
    okE &= all(g_ == 3 * H - p * H for (H, p), g_ in gam_read.items())
    chk('bit', okE, 'kk.GROW: the engine, exactly in the chart (Laurent polynomials): e^a = -dx^a/(H eta), e^4 = (-eta)^p dy, field (-eta)^q y^j/j! (j = 0, 1, 2; '
        'p = -2, -1, 1; q = -2..3; H = 1, 1/2; s = +-1): box5 = H^2 q (q + p - 3) (-eta)^q y^j/j! + s (-eta)^(q - 2p) [j = 2]; with -H eta = e^{-Ht}, phi ~ e^{rt}, '
        'r = -pH, this is f\'\' + (3H + r) f\' - s k^2 f/phi^2: the friction read off is 3H + r for every p, the mass term s/phi^2')
    if FAULT is None:
        chk('ctl', ctl_dif == ctl_seen, 'kk.GROW: control: the friction 3H without r differs from the engine on %d of %d (p, q, H, s) with pq != 0' % (ctl_dif, ctl_seen))
    tick('G exact')
    # (3) numerics: the n = 1 mode in s = rt, z = m1/r = z0 e^{-s}
    K = 1.0
    CASES = [('5D de Sitter, H = r = kappa/2', 0.5 * K, 0.5 * K), ('base 3H^2 = kappa^2, r = kappa(sqrt 7 - sqrt 3)/2', K / math.sqrt(3), K * (math.sqrt(7) - math.sqrt(3)) / 2)]
    EPS0, EPSEND = 1e-3, 3.0; PH = np.linspace(0, math.pi, 8, endpoint=False)
    okJ1 = True; okI2 = True; brk = {}; errB = 0.0; tab = []
    for name, H, r in CASES:
        h = H / r; gam_true = 3 * h + 1; gam = 3 * h + FRICTION_R; nu = gam_true / 2; z0 = 1 / EPS0; s_end = math.log(z0 * EPSEND)
        ss = np.linspace(0, s_end, 120001); z = z0 * np.exp(-ss); V = np.exp(gam_true * ss)
        Jm = []; Im = []; Fz = []
        for ph in PH:
            A = 1 / math.sqrt(z0); f0 = A * math.cos(ph); fp0 = -A * z0 * math.sin(ph) - 0.5 * (gam_true - 1) * f0
            sol = solve_ivp(lambda t, y: [y[1], -gam * y[1] - (z0 * math.exp(-t)) ** 2 * y[0]], (0, s_end), [f0, fp0], rtol=1e-11, atol=1e-15, method='DOP853', dense_output=True)
            y = sol.sol(ss)
            # the exact solution z^nu (c1 J_nu + c2 Y_nu); d/ds (z^nu Z_nu(z)) = -z^(nu+1) Z_(nu-1)(z)
            Mb = np.array([[z0 ** nu * jv(nu, z0), z0 ** nu * yv(nu, z0)], [-z0 ** (nu + 1) * jv(nu - 1, z0), -z0 ** (nu + 1) * yv(nu - 1, z0)]])
            c = np.linalg.solve(Mb, [f0, fp0]); fb = c[0] * z ** nu * jv(nu, z) + c[1] * z ** nu * yv(nu, z)
            env = np.sqrt(y[0] ** 2 + (y[1] / np.maximum(z, 1.0)) ** 2)
            errB = max(errB, float(np.max(np.abs(fb - y[0]) / env)))
            J = V * (y[1] ** 2 + z ** 2 * y[0] ** 2) / (2 * z)
            I = V * ((y[1] + 1.5 * h * y[0]) ** 2 + z ** 2 * y[0] ** 2) / (2 * z)
            Jm.append(J / J[0]); Im.append(I / I[0]); Fz.append(y)
        Jm = np.array(Jm); Im = np.array(Im); ep = 1 / z
        def dJ(e1): m = ep <= e1; return float(np.max(np.abs(Jm[:, m] - 1)))
        def dI(e1): m = ep <= e1; return float(np.max(np.abs(Im[:, m] - 1)))
        at = lambda e1: float(np.max(np.abs(Jm[:, np.argmin(np.abs(ep - e1))] - 1)))
        C2 = gam_true ** 2 / 8                                                 # second order: sqrt(V) f oscillates at sqrt(m1^2 - (3H + r)^2/4), not m1
        r1 = [dJ(e1) / (1.5 * h * e1) for e1 in (0.01, 0.03, 0.1)]; r2 = [dI(e1) / (C2 * e1 ** 2) for e1 in (0.01, 0.03, 0.1)]
        okJ1 &= all(0.9 <= x <= 1.25 for x in r1); okI2 &= all(0.85 <= x <= 1.1 for x in r2)
        grid = np.geomspace(0.01, EPSEND, 400); eb = next(e1 for e1 in grid if dJ(e1) >= 0.5)
        frz = [abs(float(F_[1][-1] / F_[0][-1])) for F_ in Fz]                    # f'/f in units of r at r/m1 = 3
        brk[name] = dict(h=h, nu=nu, r1=r1, r2=r2, at1=at(1.0), at2=at(2.0), eb=eb, od=2 / gam_true, frz=float(np.median(frz)))
        tab.append('%s: (3H/2r) = %.3f; max|J/J0 - 1| / ((3H/2r) r/m1) at r/m1 = 0.01, 0.03, 0.1: %s; max|I/I0 - 1| / (((3H + r)/r)^2/8 (r/m1)^2) at the same: %s; '
                   'max|J/J0 - 1| reaches 0.5 at r/m1 = %.2f; at r/m1 = 1: %.2f, at 2: %.1f; oscillation stops at r/m1 = 2r/(3H + r) = %.3f; median |f\'/(r f)| at r/m1 = 3: %.3f'
                   % (name, 1.5 * h, ', '.join('%.3f' % x for x in r1), ', '.join('%.2f' % x for x in r2), eb, at(1.0), at(2.0), 2 / gam_true, brk[name]['frz']))
    for t_ in tab: info(t_)
    chk('std', errB < 1e-5, 'kk.GROW: scipy solve_ivp (DOP853, rtol 1e-11) on f\'\' + (3H + r) f\' + m1(t)^2 f = 0 from r/m1 = 1e-3 to 3, eight phases, the two (H, r) of ATY-055: '
        'the exact solution z^nu (c1 J_nu(z) + c2 Y_nu(z)), z = m1/r, nu = (3H + r)/(2r) = 2 and %.3f (scipy.special), agrees to %.1e of the envelope (the solution decays by '
        '(m1(0)/m1)^(nu - 1/2) ~ 1e6 over the run, so early rounding is amplified to this size)' % (brk[CASES[1][0]]['nu'], errB))
    chk('std', okJ1 and okI2, 'kk.GROW: the adiabatic invariant J = V (f\'^2 + m1^2 f^2)/(2 m1), V = a^3 phi (energy over frequency): while r/m1 << 1 its largest change over eight phases '
        'is (3H/2r)(r/m1) times %.2f..%.2f at r/m1 = 0.01, 0.03, 0.1 (first order: an oscillation of amplitude 3H/(2 m1), the friction 3H + r minus the decay rate r of m1, '
        'no drift), and the first-order corrected I = V ((f\' + (3H/2) f)^2 + m1^2 f^2)/(2 m1) changes by ((3H + r)/r)^2/8 (r/m1)^2 times %.2f..%.2f (second order: sqrt(V) f '
        'oscillates at sqrt(m1^2 - (3H + r)^2/4)): constant to the expected order, both (H, r)'
        % (min(min(b['r1']) for b in brk.values()), max(max(b['r1']) for b in brk.values()), min(min(b['r2']) for b in brk.values()), max(max(b['r2']) for b in brk.values())))
    b5 = brk[CASES[0][0]]
    if FAULT == 'ADIABATIC2':
        chk('std', all(b['at2'] <= 0.1 for b in brk.values()), 'kk.GROW: the claim that the truncation stays adiabatic at r/m1 = 2: J within 10 %% for every phase (largest change %s)'
            % ', '.join('%.1f' % b['at2'] for b in brk.values()))
    else:
        chk('std', all(b['at1'] > 1 and b['at2'] > 10 and b['eb'] < 0.5 and b['frz'] < 0.2 for b in brk.values()),
            'kk.GROW: it fails once r/m1 ~ 1: J changes by up to %.1f (%.1f) at r/m1 = 1 and %.0f (%.0f) at r/m1 = 2 (five-dimensional de Sitter; base 3H^2 = kappa^2), '
            'the change reaches 50 %% at r/m1 = %.2f (%.2f); the oscillation stops at m1 = (3H + r)/2 (r/m1 = %.3f, %.3f), after which the mode freezes (f\'/(r f) -> 0) like the '
            'zero mode.  For H = r = kappa/2: m1 = kappa, a circle of size 1/kappa = half the Hubble length 1/H = 2/kappa; r/m1 = 1 at the Hubble length 2/kappa'
            % (b5['at1'], brk[CASES[1][0]]['at1'], b5['at2'], brk[CASES[1][0]]['at2'], b5['eb'], brk[CASES[1][0]]['eb'], b5['od'], brk[CASES[1][0]]['od']))
    # (4) the numbers
    L0 = 1.616e-33; kap = 1.04e-28; c = 2.99792458e10; yr = 365.25 * 86400
    H0 = 67.36e5 / 3.0856775814913673e24; lam_P = math.sqrt(3 * 0.6847) * H0 / c
    N = math.log(1 / (kap * L0)); Tr = 2 / (kap * c) / yr; N2 = N + math.log(2)
    chk('std', abs(N - 139.94) < 0.01 and abs(Tr / 2.0e10 - 1) < 0.02 and abs(lam_P / kap - 1) < 0.01,
        'kk.GROW: numbers (inputs R0 phi0 = 1.616e-33 cm, kappa = 1.04e-28 cm^-1; Planck 2018 sqrt(Lambda) = %.4e): the truncation holds while the circle is below 1/kappa; '
        'from the Planck length that takes ln(1/(kappa R0 phi0)) = %.2f e-foldings of phi, at 1/r = 2 hbar/kc = %.3e years each: %.3e years (to r/m1 = 1, the Hubble length: '
        '%.2f e-foldings, %.3e years); today r/m1 = kappa R0 phi0/2 = %.1e, and the age of the universe (13.787 Gyr) is %.2f e-folding times'
        % (lam_P, N, Tr, N * Tr, N2, N2 * Tr, kap * L0 / 2, 13.787e9 / Tr))
    tick('G numerics')
    return dict(N=N, Tr=Tr, kap=kap, L0=L0)

# ================================================================================================ (S) the shifted operators on the tower
JS = 14; NSER = 2 * JS + 1
def bk_add(a, b, c=1):
    r = dict(a)
    for k, v in b.items(): r[k] = r.get(k, 0) + c * v
    return {k: v for k, v in r.items() if v}
def bk_mul(a, b):
    r = {}
    for (i, j), v in a.items():
        for (k, l), w in b.items(): r[(i + k, j + l)] = r.get((i + k, j + l), 0) + v * w
    return {k: v for k, v in r.items() if v}
def ser_mul(A, B): return [_sm(A, B, k) for k in range(NSER + 1)]
def _sm(A, B, k):
    t = {}
    for i in range(k + 1):
        if A[i] and B[k - i]: t = bk_add(t, bk_mul(A[i], B[k - i]))
    return t
def ser_lin(*terms):
    out = [{} for _ in range(NSER + 1)]
    for c, A in terms:
        for k in range(NSER + 1):
            if A[k]: out[k] = bk_add(out[k], bk_mul(c, A[k]))
    return out
ONE = {(0, 0): Fr(1)}; KAP = {(1, 0): Fr(1)}
def ser_exp(sg): return [{(0, k): Fr(sg ** k, math.factorial(k))} for k in range(NSER + 1)]
def taylor(fn, a=1):
    """exact Taylor coefficients of sin(a x), cos(a x) to x^NSER"""
    out = []
    for k in range(NSER + 1):
        f = Fr(a ** k, math.factorial(k))
        if fn == 'sin': out.append(f * (-1) ** ((k - 1) // 2) if k % 2 else Fr(0))
        else: out.append(Fr(0) if k % 2 else f * (-1) ** (k // 2))
    return out
def t_mul(a, b): return [sum(a[i] * b[k - i] for i in range(k + 1)) for k in range(NSER + 1)]
def xm_poly(series_in_x, mu_pow):
    return {(k, mu_pow): v for k, v in enumerate(series_in_x) if v}

def part_S(G):
    head('(S) [kk.SHIFT] the shifted Ricci operators as series in D^2 on a mode with D^2 = -m^2; ratios, numbers, roots')
    Dser = [{}, dict(ONE)] + [{} for _ in range(NSER - 1)]
    em, ep = ser_exp(-1), ser_exp(1)
    sinh_ = ser_lin(({(0, 0): Fr(1, 2)}, ep), ({(0, 0): Fr(-1, 2)}, em))
    Dp = ser_lin((ONE, Dser), (KAP, em)); Dm = ser_lin((ONE, Dser), ({(1, 0): Fr(-1)}, ep)); Ds = ser_lin((ONE, Dser), (KAP, sinh_))
    D2 = ser_mul(Dser, Dser); Dp2 = ser_mul(Dp, Dp)
    Gs = {'a': ser_lin((ONE, [x if k % 2 == 0 else {} for k, x in enumerate(Dp2)]), ({(0, 0): Fr(-1)}, D2)),
          'b': ser_lin((ONE, ser_mul(Dp, Dm)), ({(0, 0): Fr(-1)}, D2)), 'c': ser_lin((ONE, ser_mul(Ds, Ds)), ({(0, 0): Fr(-1)}, D2))}
    odd_ok = all(not Gs[x][2 * j + 1] for x in 'bc' for j in range(JS)) and any(Dp2[2 * j + 1] for j in range(JS))
    def alpha(x, j): return Fr(0) if j == 0 else Fr(2 if x == 'c' else -2, math.factorial(2 * j - 1))
    def beta(x, j):
        if x == 'a': return Fr(2 ** (2 * j), math.factorial(2 * j))
        if x == 'b': return Fr(-1) if j == 0 else Fr(0)
        return Fr(0) if j == 0 else Fr(2 ** (2 * j - 1), math.factorial(2 * j))
    closed = all(Gs[x][2 * j] == {k: v for k, v in {(1, 2 * j - 1): alpha(x, j), (2, 2 * j): beta(x, j)}.items() if v} for x in 'abc' for j in range(JS + 1))
    PR = {'a': [{(2, 0): 1}, {(1, 1): -2, (2, 2): 2}, {(1, 3): Fr(-1, 3), (2, 4): Fr(2, 3)}, {(1, 5): Fr(-1, 60), (2, 6): Fr(4, 45)}],
          'b': [{(2, 0): -1}, {(1, 1): -2}, {(1, 3): Fr(-1, 3)}, {(1, 5): Fr(-1, 60)}],
          'c': [{}, {(1, 1): 2, (2, 2): 1}, {(1, 3): Fr(1, 3), (2, 4): Fr(1, 3)}, {(1, 5): Fr(1, 60), (2, 6): Fr(2, 45)}]}
    printed = all(Gs[x][2 * j] == PR[x][j] for x in 'abc' for j in range(4))
    chk('bit', odd_ok and closed and printed, 'kk.SHIFT: own exact series (Fractions in kappa, tau) of D_+ = D + kappa e^{-tau D}, D_- = D - kappa e^{tau D}, D_s = D + kappa sinh(tau D) '
        'to D^%d: Ricci_xx - Ricci = sum_j c_j D^2j with ATY-052\'s c_0..c_3 (kappa^2, -kappa^2, 0; -2 kappa tau + 2 kappa^2 tau^2, -2 kappa tau, 2 kappa tau + kappa^2 tau^2; ...) '
        'and every c_j = kappa tau^(2j-1) alpha_j + kappa^2 tau^(2j) beta_j with alpha_j = -+2/(2j-1)!, beta_j = 4^j/(2j)!, 0, 4^j/(2 (2j)!); D_+D_- and D_s^2 even, D_+^2 not '
        '(its odd part is what the compression drops)' % NSER)
    # the ratios
    okr = True
    for x in 'abc':
        for j in range(1, JS):
            okr &= alpha(x, j + 1) / alpha(x, j) == Fr(1, 2 * j * (2 * j + 1))
            if x == 'b': okr &= beta(x, j) == 0
    rho = {x: ('x^2 (%s + %s mu)/(%s + %s mu)' % (alpha(x, 2), beta(x, 2), alpha(x, 1), beta(x, 1))) for x in 'abc'}
    rho0 = {x: (alpha(x, 1), beta(x, 1), beta(x, 0)) for x in 'ab'}           # c_1 m^2/c_0 = x^2 (alpha_1 + mu beta_1)/(mu beta_0)
    okr &= rho0['a'] == (-2, 2, 1) and rho0['b'] == (-2, 0, -1)
    info('c_2 m^2/c_1 (x = m tau): ++ %s; +- %s; ss %s;  c_1 m^2/c_0: ++ -(2x^2/mu)(1 - mu), +- 2x^2/mu' % (rho['a'], rho['b'], rho['c']))
    tau = 1.239841984e-4 / (4 * 0.45); hbc = 1.973269804e-5; kap, L0 = G['kap'], G['L0']; mu = kap * tau
    mstar = math.sqrt(kap / (2 * tau))
    chk('bit', okr, 'kk.SHIFT: on D^2 = -m^2 the ratio of successive terms is c_(j+1) m^2/c_j = x^2 (alpha_(j+1) + mu beta_(j+1))/(alpha_j + mu beta_j), x = m tau, exactly; '
        'at mu -> 0 it is x^2/(2j(2j+1)) for all three operators and j < %d (exactly so for D_+D_-): an expansion in (m tau)^2, the first correction (m tau)^2/6 of the leading '
        'D^2 term, low-energy only while m tau << 1 (at m tau = sqrt 6 the second term equals the first); for Ricci_++ and Ricci_+- the first ratio c_1 m^2/c_0 is -(2x^2/mu)(1 - mu) '
        'and 2x^2/mu: the D^2 term overtakes the constant kappa^2 already at m = sqrt(kappa/(2 tau)) = %.2e cm^-1 = %.1e eV (Ricci_ss has c_0 = 0)' % (JS, mstar, mstar * hbc))
    # the numbers for the tower
    N_tau = math.log(tau / L0); Tr = G['Tr']
    chk('std', abs(tau - 6.888e-5) < 0.002e-5 and abs(hbc / tau - 0.2865) < 0.001 and abs(1 / tau - 1.452e4) < 5,
        'kk.SHIFT: tau >= lambda_C/4 of the lightest neutrino below 0.45 eV = %.4e cm, 1/tau = %.4e cm^-1 = %.4f eV, mu = kappa tau = %.2e: the KK modes m_n = n/(R0 phi) with '
        'n tau/(R0 phi) << 1 are inside the low-energy reading; on a circle of the Planck length m1 tau = %.2e (none is); the first enters after ln(tau/(R0 phi0)) = %.2f '
        'e-foldings (%.2e years), while r/m1 = kappa tau/2 = %.1e (still adiabatic); when the truncation fails (circle 1/kappa) the modes n < 1/mu = %.1e are inside.  '
        'This is the four-dimensional reading (D^2 = D4^2 = -m_n^2); in the five-dimensional one D5^2 = D4^2 + m_n^2 on the product (kk.MASS), which is 0 on an ordinary mode for '
        'every n, so the series in D5^2 does not see m_n at all' % (tau, 1 / tau, hbc / tau, mu, tau / L0, N_tau, N_tau * Tr, mu / 2, 1 / mu))
    # roots at D^2 = -m^2: the series G_x(-m^2) tau/kappa as polynomials in (x, mu) against the closed forms
    def at_timelike(x):
        out = {}
        for j in range(JS + 1):
            for (i, k), v in Gs[x][2 * j].items():
                assert k == 2 * j + i - 2                                    # homogeneous: kappa^i tau^k = (kappa/tau) tau^2j mu^(i-1)
                out[(2 * j, i - 1)] = out.get((2 * j, i - 1), 0) + v * (-1) ** j
        return {k: v for k, v in out.items() if v}
    sn, cs2 = taylor('sin'), taylor('cos', 2); xs = [Fr(0), Fr(1)] + [Fr(0)] * (NSER - 1); xsin = t_mul(xs, sn); sin2 = t_mul(sn, sn)
    one = [Fr(1)] + [Fr(0)] * NSER
    def P(*terms):
        out = {}
        for c, ser, mp in terms:
            for k, v in enumerate(ser):
                if v and k <= 2 * JS: out[(k, mp)] = out.get((k, mp), 0) + c * v
        return {k: v for k, v in out.items() if v}
    want = {'c': P((-2, xsin, 0), (-1, sin2, 1)), 'a': P((2, xsin, 0), (1, cs2, 1)), 'b': P((2, xsin, 0), (-1, one, 1))}
    ser = {x: at_timelike(x) for x in 'abc'}
    id_ok = all(ser[x] == want[x] for x in 'abc')
    # factorised forms: ss = -sin x (2x + mu sin x); ++ matched (Lambda = -kappa^2: -mu + G_a) = 2 sin x (x - mu sin x); +- matched (+mu + G_b) = 2 x sin x
    fac_c = P((-2, xsin, 0), (-1, sin2, 1)); fac_a = P((2, xsin, 0), (-2, sin2, 1)); fac_b = P((2, xsin, 0))
    ma = dict(ser['a']); ma[(0, 1)] = ma.get((0, 1), 0) - 1; ma = {k: v for k, v in ma.items() if v}
    mb = dict(ser['b']); mb[(0, 1)] = mb.get((0, 1), 0) + 1; mb = {k: v for k, v in mb.items() if v}
    fac_ok = ser['c'] == fac_c and ma == fac_a and mb == fac_b
    trunc_at = lambda x, mu_: sum(float(v) * x ** k * mu_ ** m for (k, m), v in ser['c'].items())
    tv = max(abs(trunc_at(j * math.pi, mu)) for j in (1, 2))
    m1 = math.pi / tau
    chk('bit', id_ok and fac_ok and tv < 1e-6, 'kk.SHIFT: roots at D^2 = -m^2 (x = m tau), exact series identities to x^%d: (Ricci_ss - Ricci) tau/kappa = -sin x (2x + mu sin x) (c_0 = 0: '
        'no background term needed, Lambda = 0 is its lowest order), and on their matched lowest-order backgrounds (paper\'s Ricci = Lambda) Ricci_++ at Lambda = -kappa^2: 2 sin x (x - mu sin x), Ricci_+- at '
        'Lambda = kappa^2: 2 x sin x: all three carry sin(m tau), so they vanish exactly at m_j = j pi/tau, j = 1, 2, ..., for every mu (the other factors have no real '
        'non-zero root for |mu| < 1); the computed series vanishes at x = pi, 2 pi to %.0e.  Additional massive solutions at the shift scale: m_1 = pi/tau = %.3e cm^-1 = %.3f eV, '
        '= 2 x 0.45 eV (tau = lambda_C/4 makes pi/tau = 2 m_nu); in general m_j = 2j m_nu/(2 n_nu + 1)' % (2 * JS, tv, m1, m1 * hbc))
    # unmatched G_a, G_b (Lambda = 0): first-order locations, brentq
    gA = lambda x, m: 2 * x * math.sin(x) + m * math.cos(2 * x); gB = lambda x, m: 2 * x * math.sin(x) - m
    dev1 = 0.0; dev0 = 0.0; rows = []
    for m in (1e-2, 1e-3, 1e-4):
        for j in (1, 2, 3):
            for g_, sgn in ((gA, -1), (gB, 1)):
                pred = j * math.pi + sgn * (-1) ** j * m / (2 * j * math.pi)
                rt = brentq(lambda x: g_(x, m), j * math.pi - 0.3, j * math.pi + 0.3, xtol=1e-15)
                dev1 = max(dev1, abs(rt - pred) / m ** 2)
        x0 = brentq(lambda x: gB(x, m), 1e-9, 1.0, xtol=1e-16); dev0 = max(dev0, abs(x0 / math.sqrt(m / 2) - 1) / m)
        rows.append('mu = %.0e: x_1 = pi %+.3e (++), pi %+.3e (+-), x_0 = %.4e' % (m, brentq(lambda x: gA(x, m), 2.8, 3.4, xtol=1e-15) - math.pi, brentq(lambda x: gB(x, m), 2.8, 3.4, xtol=1e-15) - math.pi, x0))
    noA0 = all(gA(x, 1e-3) > 0 for x in np.linspace(1e-6, 2.5, 2000))
    info('; '.join(rows))
    chk('std', dev1 < 1 and dev0 < 0.1 and noA0, 'kk.SHIFT: without the background term (Lambda = 0) Ricci_++ - Ricci = (kappa/tau)(2x sin x + mu cos 2x) and Ricci_+- - Ricci = (kappa/tau)(2x sin x - mu) '
        'vanish at x_j = j pi - (-1)^j mu/(2 j pi) and j pi + (-1)^j mu/(2 j pi) + O(mu^2) (scipy brentq, mu = 1e-2..1e-4, j = 1..3: |error|/mu^2 <= %.1e), and Ricci_+- also at '
        'x_0 = sqrt(mu/2) (1 + O(mu)): m_0 = sqrt(kappa/(2 tau)), where its D^2 term meets the constant; Ricci_++ has no root below x = 2.5' % dev1)
    # off the timelike axis: Newton from the asymptotic families, counted by the argument principle (w = tau D, D^2 = w^2/tau^2)
    def newton(f, df, w):
        for _ in range(200):
            dw = f(w) / df(w); w -= dw
            if abs(dw) < 1e-13 * max(1.0, abs(w)): break
        return w
    def count(f, df, R, N=400000):
        th = np.linspace(0, 2 * np.pi, N, endpoint=False); w = R * np.exp(1j * th)
        return float(np.real(np.sum(df(w) / f(w) * w) / N))
    okc = True; lines = []
    for mval in (1e-2, 1e-3, mu):
        fams = {'ss': (lambda w: 2 * w + mval * np.sinh(w), lambda w: 2 + mval * np.cosh(w), 4.0, 1, 1),
                '++': (lambda w: mval * np.sinh(w) - w, lambda w: mval * np.cosh(w) - 1, 2.0, 0, 1)}
        R = 1.3 * math.log(4 / mval)
        for name, (f, df, cfac, odd, base) in fams.items():
            roots = []; k = 0
            while True:
                w = complex(math.log(cfac * 10 / mval), (2 * k + odd) * math.pi)
                for _ in range(60): w = complex(math.log(cfac * abs(w) / mval), w.imag)
                w = newton(f, df, w); roots.append(w)
                if abs(w) > R: break
                k += 1
            inside = [w for w in roots if abs(w) < R]
            pred = base + sum(2 if abs(w.imag) < 1e-9 else 4 for w in inside)
            n_ = count(f, df, R)
            okc &= abs(n_ - pred) < 1e-6 and all(abs(f(w)) < 1e-9 * max(1, abs(w)) for w in roots)
            if mval == mu: lines.append('%s: first %.4f%+.4fi (D^2 tau^2 = %.0f%+.0fi), %d zeros in |w| < %.1f (argument principle %.6f)' % (name, roots[0].real, roots[0].imag, (roots[0] ** 2).real, (roots[0] ** 2).imag, pred, R, n_))
        fb = lambda w: w * np.sinh(w); dfb = lambda w: np.sinh(w) + w * np.cosh(w)
        okc &= abs(count(fb, dfb, R) - (2 + 2 * math.floor(R / math.pi))) < 1e-6
    info('at mu = kappa tau = %.2e: ' % mu + '; '.join(lines))
    chk('std', okc, 'kk.SHIFT: off the timelike axis (w = tau D complex): the second factors 2w + mu sinh w (Ricci_ss) and mu sinh w - w (Ricci_++) have roots at Re w = ln(4|w|/mu), '
        'resp. ln(2|w|/mu), Im w near (2k+1) pi, resp. 2k pi (Newton from these families at mu = 1e-2, 1e-3, %.1e; the argument principle on |w| = 1.3 ln(4/mu) finds no other zero): '
        'at the paper\'s mu, |tau D| ~ 80, |D^2| ~ 6.3e3/tau^2 (the shift scale times ln^2(4|w|/mu)), complex for Ricci_ss and one real D^2 > 0 (tachyonic in the '
        'four-dimensional reading) for Ricci_++; Ricci_+- (w sinh w) has none beyond 0 and j pi i' % mu)
    # truncations: the low-energy reading keeps D^2 (J = 1)
    firsts = []
    for J in range(1, 13):
        cf = [float(Fr((-1) ** (j - 1), math.factorial(2 * j - 1))) for j in range(1, J + 1)]          # sin x / x truncated, in u = x^2
        rts = np.roots(cf[::-1]) if J > 1 else np.array([])
        re = sorted(math.sqrt(u.real) for u in rts if abs(u.imag) < 1e-9 and u.real > 0)
        firsts.append(re[0] if re else None)
    info('first non-zero root x of the truncation at D^2J, J = 1..12 (mu -> 0, Ricci_ss): ' + ', '.join('-' if v is None else '%.6f' % v for v in firsts))
    Jpi = next((J + 1 for J, v in enumerate(firsts) if v is not None and all(u is not None and abs(u - math.pi) < 1e-6 for u in firsts[J:])), None)
    chk('std', firsts[0] is None and abs(firsts[1] - math.sqrt(6)) < 1e-12 and firsts[2] is None and Jpi is not None and Jpi > 4,
        'kk.SHIFT: the low-energy reading cannot see them: Ricci_ss - Ricci truncated at D^2 (J = 1) has no non-zero root; at D^4 its root is x = sqrt 6, at D^6 none, at D^8, D^10 '
        '%.4f, %.4f, and the first root stays within 1e-6 of pi only from J = %s on (D^%s): the roots at j pi/tau are a property of the whole series, outside the range m tau << 1 '
        'where it is an expansion' % (firsts[3], firsts[4], Jpi, 2 * Jpi if Jpi else '-'))
    tick('S')

def main():
    head('SHIFTED-KK: the massive modes on the circle of Atiyah and Moore\'s Kaluza-Klein reduction' + (' [fault %s]' % FAULT if FAULT else ''))
    part_M()
    G = part_G()
    part_S(G)
    info('total %.1f s' % (time.time() - T0))
    finish('SHIFTED-KK')

if __name__ == '__main__': main()
