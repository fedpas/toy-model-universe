# Staged for 3.7.1 (release Monday 26 Oct 2026; more items may be added)

Source of these items: the Polimi briefs review of 20 Oct (questions must ask either for confirmation of what the Atlas proved, or for a reading
on what it cannot prove, with the reason stated). Nothing here is applied to the repository yet. Check scripts are in `checks/` of this folder (their run logs on the 3.7.0 archive in `logs/`),
in Atlas style (SPDX header, docstring, `--fault` controls that exit 1), and pass on the released 3.7.0 archive.

## New check scripts (copy into the repository)

| script (here) | destination | checks | faults | backs |
|---|---|---|---|---|
| `checks/mermin_square.py` | `checks/selfcheck/proofs/mermin_square.py` | 4 (B0–B3) | GEN, SIGN | CAND-144 |
| `checks/einstein_riem.py` | `checks/selfcheck/gravity/einstein_riem.py` (no argument needed there) | 12 | 2C, SIGN | ATY-024b, ATY-024 |
| `checks/weitzenboeck_forms.py` | see item 5 | see item 5 | see item 5 | CAND-086, ATY-051 |
| `checks/shifted_review.py` | `checks/selfcheck/proofs/` | 8 | DMINUS, CHIRAL, AGE, ODD | ATY-058, ATY-060, ATY-055 (age) |
| `checks/shifted_gravity.py` | `checks/selfcheck/proofs/` | 16 | NODUHAMEL, NOCONN, CANONICAL | ATY-044 |
| `checks/shifted_gradient2.py` | `checks/selfcheck/proofs/` | 9 | FREESHIFT, NODYSON2, NODOUBLE, NOCOMM | ATY-046 |
| `checks/shifted_frw_d4.py` | `checks/selfcheck/proofs/` | 19 | D4RIC2, NONSOL | ATY-053 |
| `checks/shifted_fifthforce.py` | `checks/selfcheck/proofs/` | 17 | OMEGA1, OMEGAM1, RANGE1AU, CIRCLE | ATY-055 (radius scalar) |
| `checks/shifted_kkmodes.py` | `checks/selfcheck/proofs/` | 22 | NOPHI, NOR, ADIABATIC2 | ATY-055 (massive modes) |

The six shifted_* scripts take the folder checks/selfcheck as their argument (none for shifted_review.py); in the repository the default should
become the script's own folder. All pass on the released 3.7.0 archive (21 Oct).

## Row edits

1. **LNS-038** (open; its last clause is contradicted by check_T11 items 4b–4d, added in 3.7.0).
   - "the same square sits in every Cl(p,q) with p ≥ 2 and q ≥ 2 (an argument from the sign rule, not a separate check)" →
     "… (checked on the generators 1, 2, p + 1, p + 2 of the 28 cells with p, q ≥ 2 and p + q ≤ 10, check_T11 item 4b)".
   - Add: "A search through every grid of the 44 cells with 1 ≤ p + q ≤ 8 finds such a square in 30 and none in the other 14: p + q ≤ 3, (4,0), (1,3),
     (0,4), (5,0) and (1,4); in those 14 the commuting blades of square +1 admit a consistent ±1 assignment (check_T11 items 4c, 4d)."
   - Open part becomes: "The link to contextuality is open: whether these counts are the known polar-space picture of Pauli-type groups and which
     of them the contextuality literature lacks (the polar-space and contextuality papers are not read)." Drop "(no check builds one)".
   - Evidence: + check_T11.
2. **CAND-144** (proved): add "With e₁ = X⊗1, e₂ = Z⊗1, e₃ = iY⊗X, e₄ = iY⊗Z (real 4 × 4, qubit 0 the left factor), the nine blades are Mermin's nine
   two-qubit operators up to sign, and the six lines are his rows and columns." Evidence: mermin_square (B0–B3).
3. **ATY-024b** (reading → proved): kind `reading` → `computation`. Text: "Theorem 4.1's Einstein hypothesis is E_a(c) = 0 for the engine's Einstein
   form in the cell (4,0): E_a(c), read as M = G − 3cδ as in GRV-004d, equals the Christoffel route's G − 3cδ exactly, c symbolic, at the origin of
   exact 2-jets of 8 generic frames and 9 Einstein frames (S⁴, ℂP², constant curvature K = −1 and 1/3); on the Einstein frames c = −R/12 is the only
   solution, on the generic ones there is none. The identity has degree 2 in the jet coefficients, so a false one passes the six strong draws with
   probability at most 6.0e−11." Evidence: einstein_riem.
   **ATY-024** (standard): "as an identity on 21 torsion-free Lorentzian frames, n = 4 (GRV-004d)" → add "and on exact 2-jets of Riemannian frames of
   the cell (4,0) (ATY-024b)".
4. **CAND-084** (proved): "with J on the right the square is ∇*∇ + R/4, recalled, not run" → "with J on the right the square is ∇*∇ + R/4: J
   multiplies from the right and J² = −1, so (DJ)² = −D², and −∇^a∇_a = ∇*∇ in a Riemannian cell".
5. **CAND-086 / ATY-051**: "Higher grades in curved frames are not run." → "In curved frames, at every degree k = 0 … n (n = 3 to 6, Lorentz and
   Euclidean squares, at n = 5 also Cl(2,3) (Cl(1,4) has the Lorentz squares); exact at the origin of three strong 2-jet draws and one frame with e(0) ≠ 1): (dδ + δd)α = ∇^c∇_cα − Ric(α) + Riem(α), Ric acting
   on each slot and Riem (R_a^d_b^e) on each pair of slots; the fit is unique for 2 ≤ k ≤ n − 1, reduces to (1.3) at k = 1 and to 0 at k = 0 and k = n
   (where Ric = Riem = Rα); a Christoffel route agrees and gives the textbook 2-form formula; the terms have degree ≤ 3, so a false identity passes
   with probability ≤ (3/101)³ = 2.6e−5 per case." ATY-051 (Clifford form (1.5)): "D²X − □X = −Ric(X) + Riem(X) at every grade (same frames)".
   Script: `checks/weitzenboeck_forms.py` → `checks/selfcheck/gravity/weitzenboeck_forms.py`; 87 checks for n = 3 to 5 (the default), 117 with `--n 6`; faults ONEFORM, RIEMSIGN; argument: the
   folder checks/selfcheck (default to be set to the script's parent folder on copy). Note: it reads shifted_einstein.py's function definitions
   through `ast`, because that module runs its checks at import; decide Monday whether to keep this or to make shifted_einstein import-safe.

## By-choice gaps found, to decide on Monday (compute, or state why it cannot be computed)

Rows whose research text says "not run" or "not computed" for something finite: ATY-015, ATY-046, CAND-121, GEN-024, GRV-011, LNS-017e, RIG-M19,
RIG-M52, YM-712; LNC-059 ("the idempotents follow; not computed"); ATY-024 ("its Einstein form not computed" for the edge-cone family (5.4)–(5.6)).

## Release mechanics to expect

Status change ATY-024b ours → proved (proved +1, ours −1): MIGRATION_COUNTS, verify_counts constants, test pins that count statuses; new
evidence ids in the check records; a DECISIONS entry; docs/round20/APPLIED.md in the release records; CHECKS report for the new scripts.

## The page `#/shifted` (Calibration 3), reviewed on 21 Oct

A researcher view of the page with every by-choice gap computed, given its reason, or listed as still to compute:
`shifted_view/source/p1.md … p4.md` (source), `shifted_view/Calibration 3 - shifted view (researcher view).html/.pdf` (built by `build.py`, `topdf.mjs`).
Its section "For the next release" lists the row edits (ATY-004, 037, 043, 044, 045, 046, 047, 051, 054, 055, 058, 060, 064, LNS-017e and the reasons on
every reading and open row) and "Still to compute". New checks: the six shifted_* scripts in the table above. Their results for the page: T_B sources a weak gravitational field (ATY-044); the potential
with a gradient at second order (ATY-046); the FRW restriction fails at the D⁴ term on actual solutions (ATY-053); the radius scalar is Brans–Dicke
with ω = 0, γ = 1/2, excluded by Cassini, so the paper's "meets the bounds" does not hold (ATY-055); the massive modes on the circle, the end of the
zero-mode truncation and a second tower at jπ/τ (ATY-055).

## The Polimi briefs (Claude Doc), updated 21 Oct

Section 1 now says n = 3 to 6 for the Weitzenböck formula; visit 9, Statement 3 adds the second order (shifted_gradient2.py, computed for the brief)
and the reason ATY-062 stays a reading. Once 3.7.1 carries these rows, the briefs should cite the rows instead of "computed for this brief".
