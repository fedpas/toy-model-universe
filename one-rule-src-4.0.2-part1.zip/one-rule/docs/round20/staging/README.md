# Atlas 3.7.1 staging (21 Oct 2026)

Everything computed and written since release 3.7.0 for the next release (Monday 26 Oct 2026), and the Politecnico outreach.
Nothing here is applied to the repository; release 3.7.0 is unchanged.

Start with **`STAGED.md`**. It lists the row edits, where each new script goes, the "not computed" gaps still to decide, and what the release
will have to update.

## Folders

| folder | what it holds |
|---|---|
| `checks/` | the nine new check scripts, in Atlas style (SPDX header, docstring, `--fault` controls) |
| `logs/` | every script run on the released 3.7.0 archive on 21 Oct: the normal run and each `--fault` control; `RESULTS.txt` has one line per run |
| `shifted_view/` | the researcher view of the page "Calibration 3: the shifted view" (PDF and HTML), its source, and the 3.7.0 page record it was built from |
| `polimi_outreach/` | the briefs for the Politecnico di Milano visits: PDFs, editable copies, the doc's XML, the build files, and the re-run of the 29 Atlas scripts the briefs name |

## The new check scripts

| script | backs | argument | checks | controls (each must exit 1) |
|---|---|---|---|---|
| `mermin_square.py` | CAND-144 | none | 4 | GEN, SIGN |
| `einstein_riem.py` | ATY-024b, ATY-024 | the Atlas's `checks/selfcheck/gravity` | 12 | 2C, SIGN |
| `weitzenboeck_forms.py` | CAND-086, ATY-051 | the Atlas's `checks/selfcheck` | 87 for n = 3 to 5; 117 with `--n 6` | ONEFORM, RIEMSIGN |
| `shifted_review.py` | ATY-058, ATY-060, ATY-055 (age of the universe) | none | 8 | DMINUS, CHIRAL, AGE, ODD |
| `shifted_gravity.py` | ATY-044 | the Atlas's `checks/selfcheck` | 16 | NODUHAMEL, NOCONN, CANONICAL |
| `shifted_gradient2.py` | ATY-046 | the Atlas's `checks/selfcheck` | 9 | FREESHIFT, NODYSON2, NODOUBLE, NOCOMM |
| `shifted_frw_d4.py` | ATY-053 | the Atlas's `checks/selfcheck` | 19 | D4RIC2, NONSOL |
| `shifted_fifthforce.py` | ATY-055 (radius scalar) | the Atlas's `checks/selfcheck` | 17 | OMEGA1, OMEGAM1, RANGE1AU, CIRCLE |
| `shifted_kkmodes.py` | ATY-055 (massive modes) | the Atlas's `checks/selfcheck` | 22 | NOPHI, NOR, ADIABATIC2 |

Run: `python3 -I -B checks/<script> <argument> [--fault NAME]` (Python 3 with numpy and scipy). The scripts only read the Atlas's files.
`weitzenboeck_forms.py --n 6` adds n = 6 (about 9 minutes; the default run takes about 2).

The briefs send four of them with the visits: `mermin_square.py`, `einstein_riem.py`, `weitzenboeck_forms.py`, `shifted_gradient2.py`.

## shifted_view/

- `Calibration 3 - shifted view (researcher view).pdf` / `.html`: the page with every 3.7.0 "not computed" item computed, or given the reason it
  cannot be; its last section, "For the next release", lists the row changes.
- `source/`: `p1.md` … `p4.md` and the build. Rebuild: `cat p1.md p2.md p3.md p4.md > all.md`, then `python3 build.py all.md shifted_view.html`
  (needs Node with `katex`; set `KD` in `build.py` to its `dist/` folder), then `node topdf.mjs shifted_view.html out.pdf` (Playwright and Chromium).
  `fig/` holds the five figures; `evidence.json` and `evidence_extra.json` give the evidence lines under each row.
- `data/`: `record_370.json` and `page_370.txt`, the 3.7.0 page as released, which the view starts from.

## polimi_outreach/

- `Atlas briefs - Politecnico (EN).pdf`, `Schede Atlas - Politecnico (IT).pdf`: the briefs, ten visits, one section per page.
- `editable/`: the same content as Word (`.docx`) and Markdown (`.md`), exported from the Claude Doc "Atlas briefs for Politecnico di Milano
  visits" (English tab at revision 131, Italian tab at revision 124). The doc is the copy to edit: https://claude.ai/artifact/TUgDwTMiLtKTdUxkmPmDrk
- `doc_xml/`: the two tabs as the doc stores them, at the same revisions; `build/` turns them into the PDFs
  (`python3 build_html.py en`, then `node topdf.mjs en "<out>.pdf"`; the same with `it`).
- `rerun_370/`: the 29 Atlas scripts and tests named in the briefs, run again on the 3.7.0 source on 20 Oct: `runall_370.sh` and its
  `results.txt` (one line per run; `cat_check.py` and `clock_walk.py` were run as well), one log per script, and `dirac_matrix_check.py`, run on
  its own (`r_dirac_matrix_check.log`). All pass.
