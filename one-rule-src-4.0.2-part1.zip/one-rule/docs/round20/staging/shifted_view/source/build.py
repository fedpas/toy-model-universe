#!/usr/bin/env python3
"""build.py <src.md> <out.html>: the researcher view of the page `shifted` as one self-contained HTML file (KaTeX rendered at build time, its
fonts and the figures embedded). Source format:
  # title | ## part | ### step | #### chain           headings
  :::lead ... :::                                       the paper's move (story row), told in the Atlas's words
  :::row ID BADGE ... :::                               a statement; BADGE in proved, new, reading, open, input; `checks` line added from evidence.json
  :::see ID text :::                                    a pointer to a statement told elsewhere
  :::fig ID ... :::                                     a figure (fig/ID.png) with its caption
  :::box ... :::                                        a framed note
  $$ ... $$ (own lines) display math; $...$ inline math; **bold**; *italic*; `code`; |a|b| tables; ~ small print; - list items"""
import sys, os, re, json, html, base64, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
src, out = sys.argv[1], sys.argv[2]
EV = json.load(open(os.path.join(HERE, 'evidence.json'), encoding='utf-8'))
EXTRA = json.load(open(os.path.join(HERE, 'evidence_extra.json'), encoding='utf-8')) if os.path.exists(os.path.join(HERE, 'evidence_extra.json')) else {}
lines = open(src, encoding='utf-8').read().split('\n')

math = []                                    # (tex, display)
def M(tex, disp):
    math.append((tex, disp)); return f'\x00{len(math) - 1}\x00'
E = html.escape
SUP = re.compile(r'(?<![a-z_])(e)\^(\{[^{}]*\}|[A-Za-z0-9\u0370-\u03ff])')
def inline(s):
    s = re.sub(r'\$([^$]+)\$', lambda m: M(m.group(1), False), s)
    s = SUP.sub(lambda m: M(m.group(1) + '^' + m.group(2), False), s)
    s = E(s, quote=False)
    s = re.sub(r'`([^`]+)`', r'<code>\1</code>', s)
    s = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', s)
    s = re.sub(r'(?<![\w*])\*([^*\s][^*]*?)\*(?![\w*])', r'<i>\1</i>', s)
    s = re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)', r'<a href="\2">\1</a>', s)
    return s
BADGE = {'proved': ('proved by the Atlas', 'b-proved'), 'new': ('computed for this copy', 'b-new'), 'reading': ('our reading', 'b-reading'),
         'open': ('open', 'b-open'), 'input': ('input', 'b-input')}
def checks(rid, badge):
    parts = [f'<code>{E(s)}</code> ({E(", ".join(c))})' for s, c in (EV.get(rid) or {}).items()] if badge != 'new' else []
    parts += [f'<code>{E(s)}</code> ({E(c)}; computed for this copy)' for s, c in (EXTRA.get(rid) or {}).items()] if badge == 'new' else []
    return f'<div class="checks">Checks: {"; ".join(parts)}</div>' if parts else ''

def body(block):
    """paragraphs, display math, lists, small print, tables inside a block"""
    outp = []; i = 0; para = []
    def flush():
        if para: outp.append(f'<p>{inline(" ".join(para))}</p>'); para.clear()
    while i < len(block):
        l = block[i]; st = l.strip()
        if st.startswith('$$'):
            flush(); tex = [st[2:]]
            while not tex[-1].rstrip().endswith('$$'):
                i += 1; tex.append(block[i].strip())
            t = '\n'.join(tex).rstrip()[:-2]
            outp.append(f'<div class="eq">{M(t, True)}</div>')
        elif st.startswith('|'):
            flush(); rows = []
            while i < len(block) and block[i].strip().startswith('|'):
                cells = [c.strip() for c in block[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-{3,}:?', c) for c in cells): rows.append(cells)
                i += 1
            i -= 1
            h = '<tr>' + ''.join(f'<th>{inline(c)}</th>' for c in rows[0]) + '</tr>'
            b = ''.join('<tr>' + ''.join(f'<td>{inline(c)}</td>' for c in r) + '</tr>' for r in rows[1:])
            outp.append(f'<table>{h}{b}</table>')
        elif st.startswith('- '):
            flush(); items = []
            while i < len(block) and block[i].strip().startswith('- '):
                items.append(block[i].strip()[2:]); i += 1
                while i < len(block) and block[i].startswith('  ') and block[i].strip() and not block[i].strip().startswith('- '):
                    items[-1] += ' ' + block[i].strip(); i += 1
            i -= 1
            outp.append('<ul>' + ''.join(f'<li>{inline(x)}</li>' for x in items) + '</ul>')
        elif st.startswith('~ '):
            flush(); outp.append(f'<p class="small">{inline(st[2:])}</p>')
        elif not st:
            flush()
        else:
            para.append(st)
        i += 1
    flush()
    return ''.join(outp)

html_parts = []; i = 0; toc = []; USED = set()
while i < len(lines):
    l = lines[i]; st = l.strip()
    if st.startswith(':::'):
        kind, *arg = st[3:].split(None, 2)
        blk = []; i += 1
        while lines[i].strip() != ':::':
            blk.append(lines[i]); i += 1
        if kind == 'row':
            rid, badge = arg[0], arg[1]
            lab, cls = BADGE[badge]
            own = [x.strip()[7:].strip() for x in blk if x.strip().startswith('checks:')]
            blk = [x for x in blk if not x.strip().startswith('checks:')]
            uid = rid + ('-new' if badge == 'new' else ''); n_ = 2
            while uid in USED: uid = rid + f'-{n_}'; n_ += 1
            USED.add(uid)
            html_parts.append(f'<div class="row {cls}" id="{uid}"><div class="rowhead"><span class="rid">{rid}</span><span class="badge">{lab}</span></div>'
                              f'{body(blk)}{(chr(60) + "div class=checks>Checks: " + inline(own[0]) + chr(60) + "/div>") if own else checks(rid, badge)}</div>')
        elif kind == 'lead':
            html_parts.append(f'<div class="lead"><div class="leadlab">The paper’s move</div>{body(blk)}</div>')
        elif kind == 'see':
            html_parts.append(f'<div class="see"><span class="rid">{" · ".join(" ".join(arg).split())}</span> {inline(" ".join(x.strip() for x in blk))}</div>')
        elif kind == 'fig':
            fid = arg[0]; png = base64.b64encode(open(os.path.join(HERE, 'fig', fid + '.png'), 'rb').read()).decode()
            html_parts.append(f'<figure class="{"wide" if fid == "shifted-quarter-turn" else ""}"><img src="data:image/png;base64,{png}" alt="{fid}">'
                              f'<figcaption>{inline(" ".join(x.strip() for x in blk))}</figcaption></figure>')
        elif kind == 'box':
            html_parts.append(f'<div class="box">{body(blk)}</div>')
        i += 1; continue
    if st == '<!--TOC-->':
        html_parts.append('<!--TOC-->'); i += 1; continue
    m = re.match(r'(#{1,4}) (.*)', st)
    if m:
        lvl = len(m.group(1)); txt = m.group(2)
        aid = 'h' + str(len(toc)); toc.append((lvl, txt, aid))
        html_parts.append(f'<h{lvl} id="{aid}">{inline(txt)}</h{lvl}>')
        i += 1; continue
    blk = []
    while i < len(lines) and not lines[i].strip().startswith(':::') and not re.match(r'#{1,4} ', lines[i].strip()) and lines[i].strip() != '<!--TOC-->':
        blk.append(lines[i]); i += 1
    html_parts.append(body(blk))

# KaTeX at build time
js = r"""
const katex = require('katex'); const fs = require('fs');
const items = JSON.parse(fs.readFileSync(0, 'utf8')); const out = [];
for (const [tex, disp] of items) { try { out.push(katex.renderToString(tex, {displayMode: disp, throwOnError: true, strict: 'ignore'})); }
  catch (e) { out.push('<span style="color:red">TeX error: ' + String(e.message).replace(/</g, '&lt;') + '</span>'); console.error('TEX ERROR', tex, e.message); } }
fs.writeFileSync(1, JSON.stringify(out));"""
env = dict(os.environ, NODE_PATH='/opt/npm-tools/node_modules')
r = subprocess.run(['node', '-e', js], input=json.dumps(math), capture_output=True, text=True, env=env)
if r.stderr: print(r.stderr[:3000])
rendered = json.loads(r.stdout)
doc = ''.join(html_parts)
doc = re.sub('\x00(\\d+)\x00', lambda m: rendered[int(m.group(1))], doc)

KD = '/opt/npm-tools/node_modules/katex/dist/'
kcss = open(KD + 'katex.min.css', encoding='utf-8').read()
def font(m):
    f = m.group(1)
    if f.endswith('.woff2'):
        return 'url(data:font/woff2;base64,' + base64.b64encode(open(KD + f, 'rb').read()).decode() + ')'
    return 'url(about:blank)'
kcss = re.sub(r'url\((fonts/[^)]+)\)', font, kcss)
css = open(os.path.join(HERE, 'style.css'), encoding='utf-8').read()
title = next(t for l, t, a in toc if l == 1)
navi = ''.join(f'<li class="t{l}"><a href="#{a}">{inline(t)}</a></li>' for l, t, a in toc if l in (2, 3))
page = (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        f'<title>{E(re.sub(r"[*`$]", "", title))}</title><style>{kcss}</style><style>{css}</style></head><body><main>'
        f'{doc.replace("<!--TOC-->", "<nav class=toc><ol>" + navi + "</ol></nav>")}</main></body></html>')
page = re.sub('\x00(\\d+)\x00', lambda m: rendered[int(m.group(1))], page)
open(out, 'w', encoding='utf-8').write(page)
print('built', out, len(page), 'bytes;', len(math), 'formulas;', sum('TeX error' in x for x in rendered), 'TeX errors')
