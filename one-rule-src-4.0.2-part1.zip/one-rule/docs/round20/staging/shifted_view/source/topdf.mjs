import { chromium } from 'playwright';
import path from 'path';
const [,, file, out] = process.argv;
const b = await chromium.launch({executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
const p = await b.newPage();
await p.goto('file://' + path.resolve(file)); await p.emulateMedia({media: 'print'});
await p.setViewportSize({width: Math.round(180 * 96 / 25.4), height: 1000}); await p.waitForTimeout(400);
const over = await p.$$eval('.eq, table', els => els.filter(e => e.scrollWidth > e.clientWidth + 2).map(e => (e.closest('.row') || {}).id + ' ' + (e.innerText || '').slice(-14).replace(/\s+/g, ' ')));
console.log('overflowing at print width:', JSON.stringify(over));
const clash = await p.$$eval('.eq', els => els.map(e => { const tag = e.querySelector('.tag'); if (!tag) return null;
  const tl = tag.getBoundingClientRect().left; let r = 0; e.querySelectorAll('.katex-html > .base').forEach(b => { r = Math.max(r, b.getBoundingClientRect().right); });
  return r > tl - 4 ? ((e.closest('.row') || {}).id + ' ' + tag.innerText) : null; }).filter(x => x));
console.log('tag clashes:', JSON.stringify(clash));
await p.pdf({path: out, format: 'A4', margin: {top: '16mm', bottom: '16mm', left: '15mm', right: '15mm'}, printBackground: true,
  displayHeaderFooter: true, headerTemplate: '<div></div>',
  footerTemplate: '<div style="font: 8px system-ui, sans-serif; color: #777; width: 100%; text-align: center;">Calibration 3: the shifted view · researcher view · <span class="pageNumber"></span> / <span class="totalPages"></span></div>'});
await b.close();
