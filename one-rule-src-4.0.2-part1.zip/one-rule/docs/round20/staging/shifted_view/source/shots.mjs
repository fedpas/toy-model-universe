import { chromium } from 'playwright';
const [,, url, outdir] = process.argv;
const browser = await chromium.launch({executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
const page = await browser.newPage({viewport: {width: 1100, height: 1000}, deviceScaleFactor: 2, colorScheme: 'light'});
const errs = []; page.on('pageerror', e => errs.push(String(e)));
await page.goto(url); await page.waitForTimeout(1500);
const ids = await page.$$eval('figure[data-figure]', fs => fs.map(f => f.getAttribute('data-figure')));
console.log('figures', JSON.stringify(ids));
for (const id of ids) {
  const el = await page.$(`figure[data-figure="${id}"]`);
  await el.scrollIntoViewIfNeeded(); await page.waitForTimeout(800);
  try { await page.waitForSelector(`figure[data-figure="${id}"][data-figure-state="ready"]`, {timeout: 8000}); } catch (e) { console.log('not ready', id); }
  await page.waitForTimeout(600);
  await el.screenshot({path: `${outdir}/${id}.png`});
  const box = await el.boundingBox(); console.log(id, Math.round(box.width), Math.round(box.height));
}
console.log('errors', errs.length, errs.slice(0, 2).join(' | '));
await browser.close();
