#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round20/apply_p0.py -- applies Phase 0 of round 20 (release 3.7.1) to the tables: the 3.7.1 staging (docs/round20/staging/STAGED.md
and the researcher view of the shifted page) and the two referee reviews of 21 Oct 2026 (docs/round20/review/, decisions D84-D95).

Modelled on docs/round18/apply_pass14a.py. Idempotent: a second run writes the same bytes (a text edit whose old phrase is gone and whose new
phrase is present is skipped as applied; a script, a check record, a run record or a row that exists is left as it is). In order:
  1 checks/                  22 new check scripts: the nine of the staging (mermin_square.py and the six shifted_* scripts into
                             checks/selfcheck/proofs/, einstein_riem.py and weitzenboeck_forms.py into checks/selfcheck/gravity/), the twelve of
                             the referees and cube_faces.py (checks/selfcheck/review20/, with the physicist's jets.py); each run once in place
                             (its log under logs/ beside it) and, with --faults, every --fault control (each must exit 1; logs/<name>.faults.log)
  2 content/checks.json      one record per script
  3 content/check_runs.json  one run record per script, from the run of step 1
  4 the rows                 kind, ptype, stage, flags, evidence, homes, standardRef, cells; the new rows LAB-018b, LAB-016b, ATY-019b, LNS-017g,
                             INP-095 .. INP-097, each placed after the row it comes from; the rows an overlay owns are edited in their overlay
                             file (content/physics/rows.p*.json, content/chains/<owner>/rows.json, content/story/review_rows.json) as well
  5 the research texts       drafts, source round20:<package>; the texts of the new rows; the overlay texts as in 4
  6 content/story/depends_round20.json   the labelling overlay of depends (the chain fixes, the three cycles, the turned edges)
  7 content/chains/*/chains.json         the link words of the chains the referees fixed (the reviews' section B); shapes recomputed
  8 content/theorems.json    T8 (3): "(not separating)"
Then run: node tools/migrate/lens_readings.mjs; npm run content (twice); the tests. Every table keeps its JSON form (indent 1, UTF-8).
Usage (from anywhere): python3 docs/round20/apply_p0.py [--faults] [--no-run] [--dry-run]
"""
import copy
import glob
import hashlib
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
STAGING = os.environ.get('ATLAS_STAGING') or os.path.join(HERE, 'staging', 'checks')
REVIEW = os.environ.get('ATLAS_REVIEW') or os.path.join(HERE, 'review')
FAULTS = '--faults' in sys.argv
NO_RUN = '--no-run' in sys.argv
DRY = '--dry-run' in sys.argv
DATE = '2026-10-21'
said = []
pending = {}
TOUCHED = []
SPDX = ['# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0',
        '# Required Notice: Copyright (c) 2026 the Cascade Atlas authors',
        '# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)']


def path(rel):
    return os.path.join(ROOT, rel)


CHAIN_KEYS = ['id', 'page', 'section', 'order', 'title', 'lead', 'rows', 'mention', 'twins', 'joins', 'links', 'shape', 'extracted', 'story']


def dump_chains(lst):
    """the owners' file format of content/chains/<owner>/chains.json (tools/story/extract_chains.mjs formatChains): one key per line, compact values"""
    if not lst: return '[]\n'
    J = lambda v: json.dumps(v, ensure_ascii=False, separators=(',', ':'))
    rec = lambda c: ' {\n' + ',\n'.join(f'  {J(k)}: {J(c[k])}' for k in [k for k in CHAIN_KEYS if k in c] + [k for k in c if k not in CHAIN_KEYS]) + '\n }'
    return '[\n' + ',\n'.join(rec(c) for c in lst) + '\n]\n'


def dump(data, newline, rel=''):
    if rel.startswith('content/chains/') and rel.endswith('/chains.json'):
        return dump_chains(data)
    return json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')


def load(rel):
    if rel in pending:
        return json.loads(pending[rel]), pending[rel].endswith('\n')
    raw = open(path(rel), encoding='utf-8').read()
    data, nl = json.loads(raw), raw.endswith('\n')
    assert dump(data, nl, rel) == raw, f'{rel}: a load and dump would change its text (its JSON form is not the expected one): stop'
    return data, nl


def stage(rel, data, newline):
    pending[rel] = dump(data, newline, rel)
    if rel not in TOUCHED:
        TOUCHED.append(rel)


def flush():
    for rel, text in pending.items():
        old = open(path(rel), encoding='utf-8').read() if os.path.exists(path(rel)) else None
        if text != old:
            if not DRY:
                os.makedirs(os.path.dirname(path(rel)), exist_ok=True)
                open(path(rel), 'w', encoding='utf-8').write(text)
            said.append(f'wrote {rel}')
        else:
            said.append(f'unchanged {rel}')
    pending.clear()


# ======================================================================================================================= 1. the scripts
# src: staging:<name>, review:<path> or local:<name>; dst; family; ids [(id, statement)] (the ids the script prints; [] when it prints none: the
# evidence then names the script by its basename); faults; rows (the rows naming it); what; method; deps; route (an independent route in the script)
SCRIPTS = [
    dict(src='staging:mermin_square.py', dst='checks/selfcheck/proofs/mermin_square.py', family='proofs', faults=['GEN', 'SIGN'], rows=['CAND-144', 'LNS-038'],
         what="the nine blades of square +1 of Cl(2,2) as Mermin's nine two-qubit operators: real 4 x 4 generators X x 1, Z x 1, iY x X, iY x Z; the six commuting lines his rows and columns; the line signs multiply to -1",
         method='exact integer 4 x 4 matrices; the nine blades and the six lines enumerated', deps='numpy', route='yes: the matrices against the labels',
         ids=[('B0', 'the four real 4 x 4 matrices satisfy e_i e_j + e_j e_i = 2 eta_ij with eta = (+1, +1, -1, -1): a representation of Cl(2,2)'),
              ('B1', "the nine blades are, up to sign, Mermin's nine two-qubit operators"), ('B2', "the six commuting lines of blades are Mermin's three rows and three columns"),
              ('B3', 'the six line products of the blades have product -1, as in Mermin (6.1)')]),
    dict(src='staging:einstein_riem.py', dst='checks/selfcheck/gravity/einstein_riem.py', family='gravity', faults=['2C', 'SIGN'], rows=['ATY-024b', 'ATY-024'], ids=[],
         what="the engine's Einstein form in the cell (4,0), read as M = G - 3c delta (GRV-004d), against the Christoffel route's G - 3c delta, c symbolic, at the origin of exact 2-jets of 8 generic and 9 Einstein frames (S^4, CP^2, constant curvature K = -1 and 1/3); on the Einstein frames c = -R/12 is the only solution, on the generic ones none; 12 checks",
         method='exact Fractions on 2-jets (the gravity engine of checks/selfcheck/gravity, read only); an own Christoffel route; the identity has degree 2 in the jet coefficients, false-pass probability at most 6.0e-11 on the six strong draws',
         deps='numpy; the engine modules of checks/selfcheck/gravity', route='yes: an own Christoffel route'),
    dict(src='staging:weitzenboeck_forms.py', dst='checks/selfcheck/gravity/weitzenboeck_forms.py', family='gravity', faults=['ONEFORM', 'RIEMSIGN'], rows=['CAND-086', 'ATY-051'], ids=[],
         what="the Weitzenboeck formula at every degree k = 0 .. n in curved frames (n = 3, 4, 5 by default, n = 6 with --n 6), Lorentz and Euclidean squares (at n = 5 also Cl(2,3)): (d delta + delta d) alpha = nabla^c nabla_c alpha - Ric(alpha) + Riem(alpha), Ric on each slot and Riem on each pair of slots, with the Atlas's delta (plus the divergence); the fit unique for 2 <= k <= n - 1, the 1-form identity at k = 1, zero at k = 0 and n; the Clifford form D^2 X - Box X = -Ric(X) + Riem(X) at every grade; a Christoffel route agrees and gives the textbook 2-form formula; 87 checks (117 with --n 6)",
         method='exact at the origin of three strong 2-jet draws and one frame with e(0) != 1; the gravity engine of checks/selfcheck (b1lib, e1_lichnerowicz, g2_hodge, gsb_dirac_sq) and the function definitions of shifted_einstein.py read through ast; false-pass probability at most (3/101)^3 = 2.6e-5 per case',
         deps='numpy; the engine modules of checks/selfcheck and checks/selfcheck/gravity', route='yes: an own Christoffel route'),
    dict(src='staging:shifted_review.py', dst='checks/selfcheck/proofs/shifted_review.py', family='proofs/shifted', faults=['DMINUS', 'CHIRAL', 'AGE', 'ODD'], rows=['ATY-058', 'ATY-060', 'ATY-055', 'ATY-064'],
         what="the shifted view reviewed: the symbols of the four variants at null frequencies (D_- has a plane wave only at m = kappa = 0, like D_+; D_s keeps the massless solutions and its symbol anticommutes with gamma_5), the odd-integer test of the Compton wavelengths against the KATRIN bound (no content while only an upper bound is known), the age of the universe against hbar/kc with Planck 2018 (the ratio 1.363), the paper's magnitudes from their inputs",
         method='numpy, scipy: complex 4 x 4 Dirac matrices, scipy expm; the standard flat-LambdaCDM age', deps='numpy, scipy', route='yes: Dirac matrices',
         ids=[('V0', 'at rest the symbols have a two-dimensional kernel where ATY-005 and ATY-007 put the solutions'),
              ('V1', 'at the null frequencies (1,1,0,0), (5,3,4,0), (13,5,12,0) D_- has a plane wave only at m = kappa = 0, like D_+'),
              ('V2', 'at m = 0 D_s keeps the massless solutions (kernel 2 at each null frequency); D_c has none in either reading'),
              ('C1', 'at m = 0 the symbol of D_s anticommutes with gamma_5 on timelike, null, spacelike and random K; the other variants do not'),
              ('C2', 'the massless kernel of D_s at each null frequency splits into one left-handed and one right-handed solution'),
              ('N1', "the paper's orders of magnitude hold with the inputs: r >= 6.9e-5 cm, k/hbar <= 1.5e-9 cm^-1 (equivalence principle), Lambda = 1.09e-56 cm^-2, k/hbar = sqrt(Lambda) = 1.04e-28 cm^-1, mu >= 7.2e-33, hbar/kc = 1.01e10 years"),
              ('A1', 'hbar/kc = 1/(c sqrt Lambda) = 10.1 Gyr and, in flat Lambda-CDM, t_0/(hbar/kc) = (2/sqrt 3) arsinh sqrt(Omega_Lambda/Omega_m) = 1.363, t_0 = 13.80 Gyr (Planck 2018: 13.787)'),
              ('O1', 'from 2 n_e + 1 = 1 135 553 up (m_e over 0.45 eV) a fraction 0.136 of 100 000 consecutive odd denominators admits an odd numerator matching m_p/m_e within one standard uncertainty, as the spacing of the odd fractions predicts')]),
    dict(src='staging:shifted_gravity.py', dst='checks/selfcheck/proofs/shifted_gravity.py', family='proofs/shifted', faults=['NODUHAMEL', 'NOCONN', 'CANONICAL'], rows=['ATY-044'],
         what="the Belinfante tensor T_B of the shifted action as the source of a weak gravitational field: the shifted action on a perturbed frame with the spin connection and the Duhamel term of the shift, delta S = -(1/2) int h_mu nu T_B^mu nu on solutions, exactly in Q(i)[pi]; kappa = 0 the textbook Dirac tensor, a uniform potential the Noether energy of ATY-039, the response to local Lorentz rotations zero; on one shell T_H = (1 - (-1)^n mu i) times the ordinary symmetric tensor; no source at the beat of two shells; 16 checks",
         method="exact Fractions on the labels (the modules of checks/selfcheck/proofs, read only); Dirac matrices with scipy expm and quad_vec, the Duhamel integral by Van Loan's block exponential", deps='numpy, scipy; imports shifted_tensor.py and shifted_einstein.py (by ast) from checks/selfcheck/proofs', route='yes: Dirac matrices, Van Loan',
         ids=[('gr.VB', "delta D = -(1/2) h_a^mu gamma^a d_mu + (1/4)(d_b s - d^a s_ab) gamma^b + (1/8) gamma^mu gamma^a gamma^b d_mu w_ab against the vierbein formula by differences"), ('gr.037', "ATY-037's N^-1/2 D' N^1/2 for a static h_00 = -2 Phi"),
              ('gr.SOL', 'delta S = -(1/2) int h_mu nu T_B^mu nu on single waves, two-wave fields on one shell and on two shells'), ('gr.TWO', 'on two shells at one shift: the coupling at the cross-shell frequency is zero, and so are T and T_B there'),
              ('gr.FAC', 'a constant h gives the factor (1 - (-1)^n mu i) on every component; on one shell T_H is that factor times the ordinary symmetric tensor'), ('gr.CONST', 'the constant term of the coupling'),
              ('gr.039', 'a uniform potential reproduces the Noether energy of ATY-039'), ('gr.BEAT', 'a Phi oscillating at the beat frequency couples to nothing, exactly'), ('gr.SYM', 'the response to the antisymmetric perturbations (local Lorentz rotations) is zero'),
              ('gr.ORD', 'kappa = 0: the textbook symmetric tensor of the Dirac field; the frame term alone the canonical tensor of ATY-042, the spin connection the improvement'), ('gr.GRAD', "shifted_tensor.py's own T_B and canonical T agree (7.8e-11)"),
              ('gr.STD', 'Dirac matrices with scipy expm and quad_vec agree to 1e-15'), ('gr.CAN', 'control: the canonical tensor in place of T_B fails')]),
    dict(src='staging:shifted_gradient2.py', dst='checks/selfcheck/proofs/shifted_gradient2.py', family='proofs/shifted', faults=['FREESHIFT', 'NODYSON2', 'NODOUBLE', 'NOCOMM'], rows=['ATY-046'],
         what="a potential with a gradient at second order: D_g = D + g V_1 + g^2 V_2, exp(-s D_g) = U_0 + g U_1 + g^2 U_2 by the Dyson terms; for A_0 = g x_3 and Phi = g x_3 the second-order solution of the ordinary equation of mass E solves the shifted equation at second order exactly in Q[pi] in the 16 cases of ATY-046; the derivation run at that order; 9 checks",
         method='exact Fractions on the labels; Dirac matrices with scipy expm and five-point differences in g', deps='numpy, scipy; imports shifted_tensor.py from checks/selfcheck/proofs', route='yes: Dirac matrices',
         ids=[('DYSON', "U_0' = -D U_0, U_1' = -D U_1 - V_1 U_0, U_2' = -D U_2 - V_1 U_1 - V_2 U_0 as functions of s on random fields of degree 7"), ('MIX', 'the parts of P_2 in the advanced half'),
              ('REG', 'O_0[P_2] + O_1[P_1] + O_2[P_0] = 0 exactly in Q[pi] in the 16 cases, A_0 and Phi'), ('WHY', 'the derivation at second order: sum U_i[P_j](s) = P_k e^{JEs}'),
              ('BITSTD', 'the label operator against Dirac matrices'), ('STD', 'Dirac matrices on x_3-polynomials of degree <= 10, moving waves included: relative residual 5.5e-9'), ('CTL', 'the controls')]),
    dict(src='staging:shifted_frw_d4.py', dst='checks/selfcheck/proofs/shifted_frw_d4.py', family='proofs/shifted', faults=['D4RIC2', 'NONSOL'], rows=['ATY-053'],
         what="the FRW restriction of the shifted Einstein equations carried to the D^4 term on actual solutions of (3.10): on the dust frame e^a = eta^2 dx^a the 77 Laurent solutions of the wave equation have D^2 X = -Ric X exactly and D^4 X = Ric^2 X - Box(Ric X) with Box(Ric X) != 0, so the residual fails at mu^3; on de Sitter D^2j X = Lambda^j X through mu^6; 19 checks",
         method='exact on the labels (the modules of checks/selfcheck/proofs, read only); an index route on the coordinate metric; numpy finite differences', deps='numpy; imports shifted_einstein.py (by ast) from checks/selfcheck/proofs', route='yes: an index route',
         ids=[('frw.FRAME', 'the FRW frame e^a = eta^2 dx^a is pressureless dust; the de Sitter frame'), ('frw.SOL', 'the exact solutions of (3.10) on the dust frame: Box(eta^t gamma_0) = (t^2 + 3t - 12) eta^(t-6) gamma_0, Box(eta^t gamma_i) = (t - 1)(t + 4) eta^(t-6) gamma_i; 77 solutions'),
              ('frw.D4', 'on every solution D^2 X = -Ric X and D^4 X = Ric^2 X - Box(Ric X), Box(Ric X) != 0; D^4 not tensorial on the solutions'), ('frw.SER', 'the residual of the three shifted operators order by order in mu: an endomorphism through mu^2, failing at mu^3 on FRW; a number times X through mu^6 on de Sitter'),
              ('frw.STD', 'an index route on the coordinate metric and numpy finite differences agree'), ('ds.CTL', 'the controls on de Sitter')]),
    dict(src='staging:shifted_fifthforce.py', dst='checks/selfcheck/proofs/shifted_fifthforce.py', family='proofs/shifted', faults=['OMEGA1', 'OMEGAM1', 'RANGE1AU', 'CIRCLE'], rows=['ATY-055'], ids=[],
         what="the radius scalar against the solar-system bounds: on ten Kaluza-Klein frames at F = 0 the 44 equation gives R_4 = 0 and the trace gives Box phi = kappa_5 phi T/3 with no (nabla phi)^2 term, Brans-Dicke with omega = 0, gamma = 1/2, alpha^2 = 1/3, M_K = 4M/3; against Cassini gamma - 1 = (2.1 +- 2.3)e-5 the paper's remark does not hold; with stress w rho along the circle gamma = (1 + w)/(2 - w); 17 checks (R0-R5, G1-G3, Y1-Y2, C1-C2, W1, K1-K3)",
         method='exact at points of 2-jet Kaluza-Klein frames (the gravity engine, read only), both squares of the fibre generator; the Christoffel route agrees in all 25 components; the linearized static field solved', deps='numpy, scipy; the engine modules of checks/selfcheck', route='yes: the Christoffel route'),
    dict(src='staging:shifted_kkmodes.py', dst='checks/selfcheck/proofs/shifted_kkmodes.py', family='proofs/shifted', faults=['NOPHI', 'NOR', 'ADIABATIC2'], rows=['ATY-055'],
         what="the massive modes on the circle: Box_5(f e^{iny/R_0}) = (Box_4 f + phi^-1 nabla phi . nabla f - s n^2 f/(R_0 phi)^2) e^{iny/R_0} exactly on ten 2-jet frames, both squares s; on the de Sitter base with the growing radius the mode obeys f'' + (3H + r) f' + m_1(t)^2 f = 0, the zero-mode truncation adiabatic while r/m_1 << 1 and failing at r/m_1 ~ 1; on modes with D^2 = -m^2 the three shifted operators reduce to the unshifted one exactly at m tau = j pi (a property of the series); 22 checks",
         method='exact at points of 2-jet frames (the gravity engine, read only); an own Christoffel route; the de Sitter chart exactly; scipy solve_ivp against the Bessel solution; series identities to x^28', deps='numpy, scipy; the engine modules of checks/selfcheck', route='yes: an own Christoffel route',
         ids=[('kk.MASS', 'the mode equation with the 1/phi^2 of g^yy and the gradient term of the volume factor, exact fits on ten frames; m_n = |n|/(R_0 phi) for s = -1, tachyonic for s = +1'),
              ('kk.GROW', "f'' + (3H + r) f' + m_1(t)^2 f = 0 on the de Sitter base, the friction derived three ways; the adiabatic invariant to 6e-7 while r/m_1 << 1, changing by factors 4 to 100 at r/m_1 = 1 to 2"),
              ('kk.SHIFT', '(tau/kappa)(Ricci_ss - Ricci) = -sin x (2x + mu sin x), Ricci_++: 2 sin x (x - mu sin x), Ricci_+-: 2x sin x, series identities to x^28: the three vanish at m_j = j pi/tau')]),
    # --- the referees' scripts (docs/round20/review/*/scripts)
    dict(src='review:math/scripts/lnc059_idempotents.py', dst='checks/selfcheck/review20/lnc059_idempotents.py', family='review20', faults=['SIGN', 'NONCOMM', 'WITT'], rows=['LNC-059', 'CAND-083', 'LNS-038'], ids=[],
         what='LNC-059: the 2^w idempotents of a maximal totally singular subspace of the label quadric, for every cell Cl(p,q) with 1 <= p + q <= 8 (44 cells): idempotent, pairwise orthogonal, summing to 1, primitive (dim E A E = dim D), dim A E = N dim D; 2^w = sN (5195 checks)',
         method='an own bit-rule kernel; exhaustive depth-first search for a maximal totally singular subspace; exact rational arithmetic; the trace of x -> E x E', deps='none (pure Python)', route='no (the idempotents are built and multiplied exactly)'),
    dict(src='review:math/scripts/mermin_grids.py', dst='checks/selfcheck/review20/mermin_grids.py', family='review20', faults=['PARITY', 'LIST', 'MATRIX'], rows=['LNS-038', 'CAND-144'],
         what="LNS-038, CAND-144: a Mermin grid of blades of square +1 exists in 30 of the 44 cells 1 <= p + q <= 8 and in none of p + q <= 3, (4,0), (1,3), (0,4), (5,0), (1,4); in those 14 the commuting triples admit a consistent +-1 assignment; CAND-144's matrices; in the 30 cells every commuting 3 x 3 grid has line-sign product -1 (651 checks)",
         method='an own bit-rule kernel; exhaustive grid search over the square-+1 labels (grids fixed by four corners); 512 assignments per grid; F_2 elimination of the triple equations', deps='none (pure Python)', route='yes: F_2 linear algebra beside the grid search',
         ids=[('G1-G3', 'grids in 30 cells, none in 14: p + q <= 3, (4,0), (1,3), (0,4), (5,0), (1,4); in those 14 the triple equations are solvable exactly'), ('G4', "Cl(2,2) blades -> Mermin's operators; the lines are Mermin's rows and columns"), ('G5', 'the product of the six line signs is -1 under all 512 re-signings')]),
    dict(src='review:math/scripts/clifford_phases.py', dst='checks/selfcheck/review20/clifford_phases.py', family='review20', faults=['CNOT', 'DROPS'], rows=['LAB-028', 'LAB-032', 'LAB-037', 'LAB-038'],
         what='LAB-028, LAB-032, LAB-037, LAB-038 recomputed exactly over Z[zeta_8][1/2]: (S^p S^dagger^q H^n)^3 = zeta^(p-q) for n <= 3; |<S,H>| = 192 with the eight eighth roots, |<zeta^-1 S, iH>| = 48 with +-1; the two-qubit group of zeta H, S, CNOT has 46080 elements with the fourth roots as scalars and a commutator subgroup of 23040 containing i; aba^-1b^-1 = i.1 for the certificate of LAB-037 (22 checks)',
         method='exact arithmetic in Z[zeta_8][1/2]; breadth-first closures; a commutator subgroup by 40 commutators with an index-2 certificate', deps='none (pure Python)', route='no (exact closures)',
         ids=[('W1', '(S^p Sd^q H^(x)n)^3 = zeta^(p-q) 1 for all (p,q) with n <= 3, zeta = e^{i pi/4}'), ('W2', '|<S,H>| = 192 with the 8 eighth roots as scalars; |<zeta^-1 S, iH>| = 48 with scalars +-1'),
              ('W3', 'a is monomial with entries +-i and a b a^-1 b^-1 = i 1 (so no cover with scalars +-1 only, LAB-038)'), ('W4', '|<zetaH,S,CNOT>| = 46080, scalars {1,i,-1,-i}, commutator subgroup of order 23040 containing i 1'), ('W5', 'orbit of |000> under zetaH,S,CNOT has 4320 vectors, under H,S,CNOT 8640')]),
    dict(src='review:math/scripts/lattice_euler_checks.py', dst='checks/selfcheck/review20/lattice_euler_checks.py', family='review20', faults=['DET', 'EULER', 'CODES'], rows=['LNC-045', 'LNC-058', 'LAB-035'],
         what='T10 (1): det E_n = 9 - n for n = 3..12; LNC-045/T9: the classes of E_n/2E_n with q = 1 (4, 10, 20, 36, 64, 120) and the radical; T9 (f): A_6 plus type, E_6 minus type; T8/LNC-058: the Euler-form inertias of B_n for n = 0..5, the Tits form (6,1,1) and the Coxeter polynomial (x-1)^2(x^2+x+1)^3 at n = 3; LAB-035/T14 (4): the self-dual codes of labels all of square +1 number prod(2^i + 1) exactly when p = q mod 8, n <= 8 (62 checks)',
         method='exact Bareiss determinants; enumeration from the Cartan matrices; exact symmetric elimination; Faddeev-LeVerrier; enumeration of all self-dual binary codes', deps='none (pure Python)', route='no (exact enumeration)',
         ids=[('L1', 'det E_n = 9 - n for n = 3..12'), ('L2', 'q=1 classes of E_n/2E_n = 4, 10, 20, 36, 64, 120 = labels of square -1 of Cl(n,0); radicals as stated'), ('L3', 'A6/2A6 has 28 non-singular classes (Arf 0), E6/2E6 has 36 (Arf 1)'),
              ('L4', 'Euler-form inertias (1,0,0),(2,0,0),(4,0,0),(6,0,2),(14,2,0),(20,2,10); Tits (6,1,1) and Coxeter (x-1)^2(x^2+x+1)^3 at n = 3'), ('L5', 'codes of labels with all squares +1: prod_{i=0}^{n/2-2}(2^i+1) when p = q mod 8, else none (n <= 8)')]),
    dict(src='review:math/scripts/type_table_consequences.py', dst='checks/selfcheck/review20/type_table_consequences.py', family='review20', faults=['CLOCK', 'IND', 'KO'], rows=['GEN-011', 'GEN-022', 'INP-019', 'CAND-058'],
         what='GEN-011: the ungraded product has the type of the graded one exactly when one clock is 0 or 4 mod 8 (235 of 495 pairs); T4 (iv): sum e_a^2 = Re((1-i)(1+i)^p(1-i)^q) = sN ind(D); GEN-022/ATY-026: the ABS table from the type table alone (KO^(p-q)(pt)); INP-019: reversion is conjugate to Clifford conjugation iff n = 0 mod 4 and the cell is indefinite (n <= 10, n >= 1); CAND-058: the centre and super-centre dimensions (1909 checks)',
         method='the type table and the Brauer group of R; labels for p + q <= 8, closed forms to 10; fixed-space dimensions and trace-form inertias; exact', deps='none (pure Python)', route='no (the type table)',
         ids=[('C1', 'ungraded (x) has the graded type iff one clock is 0 or 4 mod 8: 235 agree, 260 differ (495 pairs)'), ('C2', 'sum_a e_a^2 = Re((1-i)(1+i)^p(1-i)^q) = s N ind(D) for p+q <= 10'), ('C3', 'ABS cokernels from the type table: Z, 0, 0, 0, Z, 0, Z2, Z2 by the clock, p+q <= 8 (KO^{p-q}(pt))'),
              ('C4', 'reversion ~ conjugation invariants agree iff n = 0 mod 4 and p,q >= 1 (n <= 10); e_i -> e_i I intertwines them for q odd (n <= 8)'), ('C5', 'dim centre = 2^(r-1) + [n odd] (r >= 1), 1 + [n odd] (r = 0); dim super-centre = 2^r, all cells n <= 6')]),
    dict(src='review:physics/scripts/aty024_cone_einstein.py', dst='checks/selfcheck/review20/aty024_cone_einstein.py', family='review20', faults=['CONST', 'SIGMA', 'SIGN'], rows=['ATY-024', 'ATY-022', 'ATY-024b'], ids=[],
         what='ATY-024, ATY-022, ATY-024b: the Atiyah-LeBrun edge-cone family (5.4)-(5.6) is Einstein with lambda = (3/2) beta^2 (2 - beta) by an own exact Christoffel route on 2-jets at rational base points (beta = 1, 1/2, 2/3, 3/2, 25/81, 49/25), and its Einstein form in the cell (4,0), M(c) = G - 3c delta, vanishes exactly at c = -lambda/3 and at no other c; sigma_3 normalised to the unit S^3; at beta = 1 four times Fubini-Study',
         method="exact Fractions on 2-jets (the referee's jets.py); base points with e^{alpha_0}, cos theta_0, sin theta_0 rational; all 16 Ricci components", deps='none (pure Python; jets.py beside it)', route='yes: an own Christoffel route (no engine)'),
    dict(src='review:physics/scripts/cand121_hda_d3.py', dst='checks/selfcheck/review20/cand121_hda_d3.py', family='review20', faults=['COEF', 'EPS', 'NODIV'], rows=['CAND-121', 'LNS-029', 'LNS-047', 'LNS-014e'], ids=[],
         what='CAND-121 in d = 3: {H[N], H[M]} = eps H_k[q^kj (N d_j M - M d_j N)] with eps = -s for s = -1, 0, +1, with H = -s q^-1/2 (pi^ij pi_ij - pi^2/2) - sqrt(q) R (the DeWitt coefficient 1/2) on four random integer configurations per s; with the d = 2 coefficient 1 the algebra does not close',
         method='exact Fractions; jets at a point; the full functional derivatives with the Ricci terms; the bracket density against d_a V^a + eps H^b W_b', deps='none (pure Python; jets.py beside it)', route='no (own derivation, no engine)'),
    dict(src='review:physics/scripts/rig_m19_m52_euler.py', dst='checks/selfcheck/review20/rig_m19_m52_euler.py', family='review20', faults=['ENERGY', 'MOMENTUM', 'SAME'], rows=['RIG-M19', 'RIG-M52'], ids=[],
         what="RIG-M19: the kinetic energy of the free top is conserved for either sign of the Euler term, the world momentum only for the right one (six random rational states); RIG-M52: at the example's size (3/5, 2, 1) the printed and the paper's inertia maps give different rates omega-dot at a generic state and the same flow only when s_0 = s_2",
         method='exact Fractions, the vector form of the free top', deps='none (pure Python)', route='no'),
    dict(src='review:physics/scripts/grv011_hessian_affine.py', dst='checks/selfcheck/review20/grv011_hessian_affine.py', family='review20', faults=['KER3', 'LAP'], rows=['GRV-011'], ids=[],
         what='GRV-011 (b): on polynomials of degree <= 6 in three variables the kernel of the Hessian map d_i d_j psi is the four affine functions, exactly, so Phi_t - Phi_s is affine and decay at infinity gives Phi_t = Phi_s; the Laplacian alone has a larger kernel (control)',
         method='exact rank of the Hessian map on monomials', deps='none (pure Python)', route='no'),
    dict(src='review:physics/scripts/cpl006b_majorana_cl11.py', dst='checks/selfcheck/review20/cpl006b_majorana_cl11.py', family='review20', faults=['SHELL', 'TACH'], rows=['CPL-006b'], ids=[],
         what='CPL-006b: a neutral field at n = 2: nabla psi = m psi gamma_1 on the even (two real components) psi of Cl(1,1), the 1+1 Majorana equation, has real plane waves exactly on E^2 = k^2 + m^2 (exact kernels at five on-shell and three off-shell points, m = 3); the form with gamma_0 is tachyonic; at n = 1 no element squares to -1 and the equation gives real exponentials only',
         method='an own bit-rule kernel; real trigonometric plane waves; exact 4 x 4 kernels', deps='none (pure Python)', route='no'),
    dict(src='review:physics/scripts/aty003_atiyah_segal_model.py', dst='checks/selfcheck/review20/aty003_atiyah_segal_model.py', family='review20', faults=['PAGE14', 'NOTWIST'], rows=['ATY-003'], ids=[],
         what="ATY-003: the 24-dimensional model of Atiyah and Segal's Appendix by an independent exterior-algebra route: the pages of the degree filtration 24, 18, 18, 10, 10, 8, 8, 8 and the twisted cohomology H(d + x t) = 8 = (4, 4); no page has dimension 14",
         method='an own exterior algebra; the exact spectral sequence of the degree filtration', deps='none (pure Python)', route='yes: independent of the labels'),
    dict(src='review:physics/scripts/lnc059_idempotents.py', dst='checks/selfcheck/review20/lnc059_idempotents_std.py', family='review20', faults=['ONE', 'SIGN', 'MERMIN'], rows=['LNC-059', 'LNS-038', 'CAND-144'], ids=[],
         what="a second route for LNC-059 and the LNS-038 edit: the 2^w idempotents on the 36 signatures p + q <= 7 (own bit rule, backtracking for a maximal totally singular subspace); a consistent +-1 assignment on the commuting products of +1-blades exists in exactly 14 of the 44 cells 1 <= p + q <= 8 (an F_2 linear system, independent of any grid search); CAND-144's matrices",
         method='an own bit rule; numpy exact integer matrices; Gaussian elimination over F_2', deps='numpy', route='yes: a linear system beside the grid search'),
    dict(src='local:cube_faces.py', dst='checks/selfcheck/review20/cube_faces.py', family='review20', faults=['COUNT', 'EULER'], rows=['ATL-022c'], ids=[],
         what='ATL-022c: the k-faces of the n-cube for n <= 8, listed as vertex sets (a face is the set of vertices agreeing on n - k fixed coordinates): 2^{n-k} C(n,k) distinct faces at every (n, k), 1120 at (8, 4), with the Euler relation sum (-1)^k f_k = 1 at every n',
         method='exact enumeration of the faces as frozensets of vertices (3^8 = 6561 faces at n = 8)', deps='none (pure Python)', route='no (enumeration against the closed count)'),
]

CUBE_FACES = r'''#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cube_faces.py -- ATL-022c: the faces of the n-cube for n <= 8, enumerated as vertex sets, against the count 2^{n-k} C(n,k).
A k-face of the n-cube [0,1]^n is the set of vertices that agree with a fixed 0/1 assignment on n - k coordinates; the script lists every such
set (as a frozenset of vertices), checks that distinct (coordinate set, assignment) pairs give distinct faces, that their number is
2^{n-k} C(n,k) at every (n, k) with 0 <= k <= n <= 8 (1120 at (8, 4)), and that the f-vector satisfies the Euler relation sum_k (-1)^k f_k = 1.
Controls (--fault, each exits 1): COUNT expects 2^{n-k} C(n,k-1) at (8, 4); EULER expects the alternating sum to be 0.
usage: python3 -I -B cube_faces.py [--fault COUNT|EULER]
"""
import itertools
import sys
from math import comb

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
FAILS = []


def ok(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond:
        FAILS.append(msg)


def faces(n, k):
    """the k-faces of the n-cube as frozensets of vertices (vertices as integers 0 .. 2^n - 1)"""
    out = set()
    verts = range(1 << n)
    for free in itertools.combinations(range(n), k):
        fixed = [i for i in range(n) if i not in free]
        for bits in itertools.product((0, 1), repeat=len(fixed)):
            face = frozenset(v for v in verts if all(((v >> i) & 1) == b for i, b in zip(fixed, bits)))
            assert len(face) == 1 << k
            out.add(face)
    return out


def main():
    for n in range(0, 9):
        f = []
        for k in range(0, n + 1):
            F = faces(n, k)
            want = (1 << (n - k)) * comb(n, k)
            if FAULT == 'COUNT' and (n, k) == (8, 4):
                want = (1 << (n - k)) * comb(n, k - 1)
            ok(len(F) == want, f'n = {n}, k = {k}: {len(F)} faces as vertex sets, 2^(n-k) C(n,k) = {(1 << (n - k)) * comb(n, k)}' + (' (ATL-022c: the 1120 four-faces of the 8-cube)' if (n, k) == (8, 4) else ''))
            f.append(len(F))
        euler = sum((-1) ** k * x for k, x in enumerate(f))
        ok(euler == (0 if FAULT == 'EULER' else 1), f'n = {n}: f-vector {f}, sum (-1)^k f_k = {euler}' + ('' if FAULT == 'EULER' else ' = 1 (Euler)'))
    print('FAILS: %s' % (FAILS or 'none'))
    sys.exit(1 if FAILS else 0)


if __name__ == '__main__':
    main()
'''


def script_src(spec):
    kind, rel = spec.split(':', 1)
    return os.path.join(STAGING if kind == 'staging' else REVIEW, rel)


def copy_scripts():
    for s in SCRIPTS:
        dst = path(s['dst'])
        if s['src'].startswith('local:'):
            new_text = CUBE_FACES
        else:
            src = script_src(s['src'])
            assert os.path.isfile(src), f'missing source {src}'
            text = open(src, encoding='utf-8').read()
            lines = text.split('\n')
            if 'SPDX-License-Identifier: PolyForm' not in text:
                # the referees' scripts: the Atlas's licence header after the shebang (the MIT line of the referee's own kernel is replaced)
                lines = [l for l in lines if 'SPDX-License-Identifier: MIT' not in l]
                at = 1 if lines and lines[0].startswith('#!') else 0
                lines = lines[:at] + SPDX + lines[at:]
            # STAGED.md: the argument of the shifted_* scripts and of weitzenboeck_forms.py (the checks/selfcheck folder) defaults to the script's
            # parent folder on copy (the scripts live in checks/selfcheck/proofs and checks/selfcheck/gravity)
            DEFAULT = "os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))"
            PATCH = {'weitzenboeck_forms.py': ('if not POS: raise SystemExit(USAGE)', f'if not POS: POS = [{DEFAULT}]   # the checks/selfcheck folder beside this script\'s folder'),
                     'shifted_kkmodes.py': ("if not POS: raise SystemExit('usage: python3 shifted_kkmodes.py <path of checks/selfcheck> [--fault NOPHI|NOR|ADIABATIC2]')", f'if not POS: POS = [{DEFAULT}]   # the checks/selfcheck folder beside this script\'s folder'),
                     'shifted_fifthforce.py': ("if not ARGS: print('usage: python3 shifted_fifthforce.py <checks/selfcheck folder> [--fault NAME]'); sys.exit(1)", f'if not ARGS: ARGS = [{DEFAULT}]   # the checks/selfcheck folder beside this script\'s folder')}
            name = os.path.basename(s['dst'])
            if name in PATCH:
                joined = '\n'.join(lines); old, new = PATCH[name]
                assert old in joined or new in joined, f'{name}: the usage line to patch is not there'
                lines = joined.replace(old, new).split('\n')
            new_text = '\n'.join(lines)
        if os.path.exists(dst) and open(dst, encoding='utf-8').read() == new_text:
            said.append(f'unchanged {s["dst"]}'); continue
        if not DRY:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            open(dst, 'w', encoding='utf-8').write(new_text)
        said.append(f'wrote {s["dst"]}')
    jsrc = os.path.join(REVIEW, 'physics/scripts/jets.py'); jdst = path('checks/selfcheck/review20/jets.py')
    jt = [l for l in open(jsrc, encoding='utf-8').read().split('\n') if 'SPDX-License-Identifier: MIT' not in l]
    jtext = '\n'.join(SPDX + jt)
    if not (os.path.exists(jdst) and open(jdst, encoding='utf-8').read() == jtext):
        if not DRY:
            os.makedirs(os.path.dirname(jdst), exist_ok=True); open(jdst, 'w', encoding='utf-8').write(jtext)
        said.append('wrote checks/selfcheck/review20/jets.py')
    readme = path('checks/selfcheck/review20/README.md')
    rtext = ("# checks/selfcheck/review20 — the referees' scripts of round 20 (21 Oct 2026)\n\n"
             'Twelve check scripts written by the two referees of docs/round20/review/ (a mathematician and a physicist), each with its own kernel and no '
             'Atlas import, and cube_faces.py (ATL-022c), run with `python3 -I -B <script> [--fault NAME]` from this folder; every `--fault` exits 1. '
             "`jets.py` is the physicist's exact jet calculus (Fraction coefficients). The logs of the release run are in `logs/`. What each computes "
             "is in `content/checks.json` and in the reviews' section D.\n")
    if not (os.path.exists(readme) and open(readme, encoding='utf-8').read() == rtext):
        if not DRY: open(readme, 'w', encoding='utf-8').write(rtext)
        said.append('wrote checks/selfcheck/review20/README.md')


def run_scripts():
    """run every new script in place; write logs/<name>.log (and .faults.log with --faults); return {dst: (seconds, lastLine)}"""
    out = {}
    for s in SCRIPTS:
        dst = path(s['dst']); d = os.path.dirname(dst); name = os.path.basename(dst)[:-3]
        logd = os.path.join(d, 'logs'); os.makedirs(logd, exist_ok=True)
        log = os.path.join(logd, name + '.log'); flog = os.path.join(logd, name + '.faults.log')
        if os.path.exists(log) and (not FAULTS or os.path.exists(flog)) and os.path.exists(log + '.seconds'):   # run already (a rerun after a stop); --rerun forces
            if '--rerun' not in sys.argv:
                txt = open(log, encoding='utf-8').read().rstrip('\n').split('\n')
                out[s['dst']] = (float(open(log + '.seconds').read()), txt[-1] if txt else '')
                said.append(f'kept the run of {s["dst"]}')
                continue
        if NO_RUN and os.path.exists(log):
            txt = open(log, encoding='utf-8').read().rstrip('\n').split('\n')
            secs = float(open(log + '.seconds').read()) if os.path.exists(log + '.seconds') else 0
            out[s['dst']] = (secs, txt[-1] if txt else '')
            continue
        t0 = time.time()
        r = subprocess.run([sys.executable, '-I', '-B', name + '.py'], cwd=d, capture_output=True, text=True)
        secs = round(time.time() - t0, 1)
        open(log, 'w', encoding='utf-8').write(r.stdout + (('\n[stderr]\n' + r.stderr) if r.stderr.strip() else ''))
        open(log + '.seconds', 'w').write(str(secs))
        last = (r.stdout.rstrip('\n').split('\n') or [''])[-1]
        assert r.returncode == 0, f'{s["dst"]} exits {r.returncode}: {last}\n{r.stderr[-2000:]}'
        if FAULTS:
            with open(flog, 'w', encoding='utf-8') as fh:
                for f in s['faults']:
                    rf = subprocess.run([sys.executable, '-I', '-B', name + '.py', '--fault', f], cwd=d, capture_output=True, text=True)
                    fh.write(f'== --fault {f}: exit {rf.returncode}\n{rf.stdout}\n')
                    assert rf.returncode == 1, f'{s["dst"]} --fault {f} exits {rf.returncode}, not 1'
        out[s['dst']] = (secs, last)
        said.append(f'ran {s["dst"]}: {secs} s, {last[:90]}' + (f'; {len(s["faults"])} faults each exit 1' if FAULTS else ''))
    return out


def register_checks(runs):
    ck, nl = load('content/checks.json')
    have = {c['id'] for c in ck}
    for s in SCRIPTS:
        cid = s['dst'][len('checks/'):]
        name = os.path.basename(s['dst'])[:-3]
        if cid in have: continue
        ck.append({'id': cid, 'family': s['family'], 'script': s['dst'], 'ids': [{'id': i, 'statement': st} for i, st in s['ids']],
                   'what': s['what'], 'method': s['method'], 'independentRoute': s['route'],
                   'controls': f'yes: --fault {", ".join(s["faults"])}, each wrong version exits 1 (logs/{name}.faults.log)',
                   'deps': s['deps'], 'storedResult': None, 'log': os.path.dirname(s['dst']) + '/logs/' + name + '.log',
                   'rowsNaming': s['rows'], 'notes': 'round 20 (release 3.7.1): ' + ('the 3.7.1 staging (docs/round20/staging)' if s['src'].startswith('staging') else "a referee's script (docs/round20/review)" if s['src'].startswith('review') else 'written for the release'), 'since': 'v3.7.1'})
    stage('content/checks.json', ck, nl)
    cr, nl2 = load('content/check_runs.json')
    haveRun = {(r['script'], r.get('date')) for r in cr}
    for s in SCRIPTS:
        if (s['dst'], DATE) in haveRun: continue
        secs, last = runs.get(s['dst'], (0, ''))
        name = os.path.basename(s['dst'])[:-3]
        cr.append({'script': s['dst'], 'date': DATE, 'machine': "round 20 release run (3.7.1), from the script's own folder", 'ok': None, 'fail': 0, 'lastLine': last, 'passed': True,
                   'seconds': secs, 'status': f'pass (-I -B from its folder; {len(s["faults"])} --fault runs each exit 1); about {secs} s alone', 'source': os.path.dirname(s['dst']) + '/logs/' + name + '.log'})
    stage('content/check_runs.json', cr, nl2)


# ======================================================================================================================= 4. the rows
def ev(check, script):
    return {'check': check, 'script': script, 'mode': 'ran'}


P = 'checks/selfcheck/proofs/'; G = 'checks/selfcheck/gravity/'; R20 = 'checks/selfcheck/review20/'

# field edits per row: {field: value} (lists replace); 'evidence+' adds entries; 'flags' sets legacyFlags; 'depends+' adds edges (overlay-owned rows only)
ROW_EDITS = {
    # --- P0.1 the staging
    'ATY-024b': {'kind': 'computation', 'ptype': 'identity', 'evidence+': [ev('einstein_riem', G + 'einstein_riem.py'), ev('aty024_cone_einstein', R20 + 'aty024_cone_einstein.py')],
                 'homeMath': "the Einstein hypothesis of Atiyah and LeBrun's Theorem 4.1 as the engine's Einstein form on Riemannian 2-jets of the cell (4,0)", 'homePhys': 'the Einstein form of the gravity engine in the Euclidean cell (4,0), c symbolic'},
    'ATY-022': {'evidence+': [ev('aty024_cone_einstein', R20 + 'aty024_cone_einstein.py')]},
    'CAND-144': {'evidence+': [ev('B1', P + 'mermin_square.py'), ev('B3', P + 'mermin_square.py'), ev('G4', R20 + 'mermin_grids.py'), ev('G5', R20 + 'mermin_grids.py')]},
    'LNS-038': {'evidence+': [ev('check_T11', 'checks/researchers_checks/check_T11.py'), ev('G1-G3', R20 + 'mermin_grids.py'), ev('lnc059_idempotents_std', R20 + 'lnc059_idempotents_std.py')]},
    'CAND-086': {'evidence+': [ev('weitzenboeck_forms', G + 'weitzenboeck_forms.py')]},
    'ATY-051': {'evidence+': [ev('weitzenboeck_forms', G + 'weitzenboeck_forms.py')]},
    'ATY-044': {'evidence+': [ev('gr.VB', P + 'shifted_gravity.py'), ev('gr.SOL', P + 'shifted_gravity.py'), ev('gr.FAC', P + 'shifted_gravity.py'), ev('gr.BEAT', P + 'shifted_gravity.py'), ev('gr.STD', P + 'shifted_gravity.py')]},
    'ATY-046': {'evidence+': [ev('shifted_gradient2', P + 'shifted_gradient2.py')]},
    'ATY-053': {'evidence+': [ev('frw.SOL', P + 'shifted_frw_d4.py'), ev('frw.D4', P + 'shifted_frw_d4.py'), ev('frw.SER', P + 'shifted_frw_d4.py'), ev('frw.STD', P + 'shifted_frw_d4.py')]},
    'ATY-055': {'evidence+': [ev('A1', P + 'shifted_review.py'), ev('shifted_fifthforce', P + 'shifted_fifthforce.py'), ev('kk.MASS', P + 'shifted_kkmodes.py'), ev('kk.GROW', P + 'shifted_kkmodes.py'), ev('kk.SHIFT', P + 'shifted_kkmodes.py')]},
    'ATY-060': {'evidence': []},   # a question of the chains overlay, without evidence (V9); its text names shifted_review O1
    'ATY-064': {'kind': 'computation', 'ptype': 'calibration', 'evidence+': [ev('N1', P + 'shifted_review.py')],
                'depends+': [{'id': 'INP-095', 'rel': 'uses-input'}, {'id': 'INP-096', 'rel': 'uses-input'}, {'id': 'INP-097', 'rel': 'uses-input'}],
                'homePhys': "the paper's orders of magnitude from today's inputs: the KATRIN bound, the equivalence-principle bound, Planck 2018", 'homeMath': ''},
    # --- P0.3 the computations
    'LNC-059': {'evidence+': [ev('lnc059_idempotents', R20 + 'lnc059_idempotents.py'), ev('lnc059_idempotents_std', R20 + 'lnc059_idempotents_std.py')]},
    'CAND-121': {'evidence+': [ev('cand121_hda_d3', R20 + 'cand121_hda_d3.py')], 'cells': ['(s,+,+)', '(s,+,+,+)']},
    'LNS-029': {'kind': 'range', 'ptype': 'derivation', 'flags': ['standard'], 'evidence+': [ev('cand121_hda_d3', R20 + 'cand121_hda_d3.py')],
                'standardRef': 'C. Teitelboim, How commutators of constraints reflect the spacetime structure, Ann. Phys. 79 (1973) 542 (the signature family ε = ±1 in every d; read at statement level); M. Henneaux, Geometry of zero signature space-times, Bull. Soc. Math. Belg. 31 (1979) 47 (ε = 0; read at statement level); CAND-121 (d = 2, 3 computed)'},
    'LNS-047': {'kind': 'range', 'ptype': 'derivation', 'flags': ['standard'], 'evidence+': [ev('cand121_hda_d3', R20 + 'cand121_hda_d3.py')],
                'standardRef': 'C. Teitelboim, Ann. Phys. 79 (1973) 542; M. Henneaux, Bull. Soc. Math. Belg. 31 (1979) 47 (read at statement level); CAND-121 (d = 2, 3 computed)'},
    'LNS-014e': {'flags': ['checked'], 'evidence+': [ev('cand121_hda_d3', R20 + 'cand121_hda_d3.py')]},
    'RIG-M19': {'kind': 'computation', 'evidence+': [ev('rig_m19_m52_euler', R20 + 'rig_m19_m52_euler.py')]},
    'RIG-M52': {'kind': 'computation', 'evidence+': [ev('rig_m19_m52_euler', R20 + 'rig_m19_m52_euler.py')]},
    'GRV-011': {'evidence+': [ev('grv011_hessian_affine', R20 + 'grv011_hessian_affine.py')]},
    'CPL-006b': {'kind': 'computation', 'ptype': 'identity', 'flags': ['checked'], 'evidence+': [ev('cpl006b_majorana_cl11', R20 + 'cpl006b_majorana_cl11.py')], 'homeMath': 'the 1+1 Majorana equation on the even part of Cl(1,1)', 'homePhys': 'a neutral (Majorana) spinor field in 1+1 dimensions'},
    'ATY-003': {'evidence+': [ev('aty003_atiyah_segal_model', R20 + 'aty003_atiyah_segal_model.py')]},
    'LAB-028': {'evidence+': [ev('W1', R20 + 'clifford_phases.py'), ev('W2', R20 + 'clifford_phases.py')]},
    'LAB-032': {'evidence+': [ev('W2', R20 + 'clifford_phases.py')]},
    'LAB-037': {'evidence+': [ev('W3', R20 + 'clifford_phases.py'), ev('W4', R20 + 'clifford_phases.py')]},
    'LAB-038': {'evidence+': [ev('W3', R20 + 'clifford_phases.py')]},
    'LAB-035': {'evidence+': [ev('L5', R20 + 'lattice_euler_checks.py')]},
    'LNC-058': {'evidence+': [ev('L4', R20 + 'lattice_euler_checks.py')]},
    'LNC-045': {'evidence+': [ev('L2', R20 + 'lattice_euler_checks.py')]},
    'GEN-011': {'evidence+': [ev('C1', R20 + 'type_table_consequences.py')]},
    'GEN-022': {'evidence+': [ev('C3', R20 + 'type_table_consequences.py')]},
    'INP-019': {'evidence+': [ev('C4', R20 + 'type_table_consequences.py')]},
    'CAND-058': {'evidence+': [ev('C5', R20 + 'type_table_consequences.py')]},
    # --- P0.4 statuses
    'ATL-018': {'flags': ['checked', 'standard']},
    'GOS-004': {'flags': ['ours']},
    'ATY-019': {'evidence': [], 'flags': ['ours']},
    'GOS-511b': {'kind': 'classification', 'ptype': 'postulate', 'standardRef': 'E. Witt, Eine Identität zwischen Modulformen zweiten Grades, Abh. Math. Sem. Univ. Hamburg 14 (1941) 323–337 (the two even unimodular lattices of rank 16; read at statement level); J. H. Conway and N. J. A. Sloane, Sphere Packings, Lattices and Groups, Ch. 16 §1 and Ch. 4 §8.3 (D₁₆⁺; read)',
                 'homeMath': 'the two even unimodular lattices of rank 16: E₈ ⊕ E₈ and D₁₆⁺ (Witt)', 'homePhys': 'the two rank-16 even self-dual lattices of the heterotic string'},
    'LAB-505b': {'kind': 'lemma', 'ptype': 'identity', 'standardRef': 'A. W. Knapp, Lie Groups Beyond an Introduction, the chapter on compact Lie groups (the Killing form of a compact Lie algebra is negative semidefinite; read at statement level): a continuous homomorphism from a connected non-compact simple Lie group to a compact one is trivial',
                 'homeMath': 'no non-trivial continuous homomorphism from the non-compact simple Spin⁺(1,3) ≅ SL(2,ℂ) to a compact Lie group', 'homePhys': 'the Lorentz group cannot sit inside a compact gauge group'},
    'PAG-034': {'kind': 'reduction', 'flags': ['standard'], 'standardRef': 'L. Gårding, Linear hyperbolic partial differential equations with constant coefficients, Acta Math. 85 (1951) 1–62 (the well-posed Cauchy problem of a hyperbolic operator with constant coefficients); L. Hörmander, The Analysis of Linear Partial Differential Operators II, Ch. XII (recalled at statement level)'},
    'LNS-028c': {'kind': 'reading', 'ptype': 'reading'},
    'FUR-619b': {'kind': 'computation', 'ptype': 'identity', 'evidence+': [ev('family_test', 'checks/family_test.py')]},
    'ATL-022c': {'flags': [], 'evidence+': [ev('cube_faces', R20 + 'cube_faces.py')]},
    'YM-007c': {'standardRef': 'Peskin–Schroeder, An Introduction to Quantum Field Theory, Ch. 15; Weinberg, The Quantum Theory of Fields II, Ch. 15 (Yang–Mills with gauge algebra so(m)); R. Bartnik and J. McKinnon, Particlelike solutions of the Einstein–Yang–Mills equations, Phys. Rev. Lett. 61 (1988) 141 (asymptotically flat solitons with a genuinely non-abelian field, numerical; pointer, source unread)'},
    'CAND-139': {'standardRef': 'Bateman, The transformation of the electrodynamical equations; Cunningham, The principle of relativity in electrodynamics and an extension thereof; Y. Kosmann, Dérivées de Lie des spineurs, Ann. Mat. Pura Appl. 91 (1972) 317–395 (the conformal weight 3/2 of the massless Dirac field; recalled); R. Penrose and W. Rindler, Spinors and Space-Time II, §6.7 (recalled)'},
    'INP-053': {'standardRef': 'Bateman and Cunningham (the conformal invariance of Maxwell; recalled, not read); Y. Kosmann, Ann. Mat. Pura Appl. 91 (1972) and R. Penrose and W. Rindler, Spinors and Space-Time II, §6.7 (the massless Dirac field with weight 3/2; recalled, not read)'},
    'LAB-019': {'standardRef': 'Wood, Trans. AMS 336 (1993), §5 (non-singular ℤ/4-valued quadratic forms classified by their rank, their Brown invariant and whether the bilinear form is alternating; the label forms refine the dot product, non-alternating); Kirby–Taylor, Pin structures on low-dimensional manifolds, §3'},
    'LNS-046': {'homeMath': 'a real four-dimensional module exists for Cl(3,1) ≅ M₄(ℝ) and not for Cl(1,3) ≅ M₂(ℍ); the Majorana condition itself (ψ = ψᶜ) is convention-independent',
                'homePhys': 'real 4 × 4 gamma matrices exist for Cl(3,1) = M4(R), not for Cl(1,3) = M2(H); the Majorana condition is a real structure on the complexified spinor, in both signature conventions; gravitational closure of matter field equations'},
    'CAND-004': {'homeMath': "Wall's theorem, BW(ℝ) ≅ ℤ₈ (the pair of types as a complete invariant of the graded Morita class)"},
    'LAB-036': {'homeMath': "a finite Siegel–Weil-type identity on the labels (one class in the genus, a transitive orbit of the transvections): for a cell with p ≡ q mod 8 the average over the genus of the theta functional of genus g equals E_g/E_g(δ₀), the normalised sum over the orbit of δ₀ under Weil's operators"},
}
STAGES = {
    'CAND-034': 'F', 'CAND-036': 'D', 'CAND-112': 'D', 'CAND-009': 'K', 'CAND-084': 'F', 'CAND-005': 'F', 'ATY-020': 'F', 'ATY-021': 'F', 'ATY-023': 'F', 'CAND-089': 'F', 'CAND-085': 'D',
    'LNS-005': 'A', 'LNS-019': 'A', 'LNS-019b': 'A', 'LNS-019c': 'A', 'LNS-019d': 'A', 'LNS-019e': 'A', 'LNS-019f': 'A', 'LNS-019g': 'A', 'LNS-129': 'A', 'LNS-130': 'A', 'LNS-131': 'A', 'LNS-132': 'A', 'LNC-060': 'A', 'LNS-009': 'A', 'LNS-018': 'A',
    'CAND-121': 'D', 'CAND-127': 'D', 'CAND-010': 'D', 'CAND-148': 'D', 'CAND-118': 'D', 'CAND-132': 'D', 'CAND-128': 'O', 'CAND-150': 'O', 'CAND-013': 'O', 'CAND-016': 'O',
    'SPR-M05': 'A', 'SPR-M06': 'A', 'SPR-M07': 'A', 'SPR-M08': 'A', 'SPR-M17': 'A', 'SPR-M18': 'A', 'SPR-M19': 'A', 'SPR-M22': 'A', 'LNS-127': 'A', 'LNS-061': 'A',
    'ATY-010': 'F', 'ATY-052': 'F', 'ATY-053': 'F', 'MIR-034': 'K', 'CAND-144': 'A', 'LNS-021': 'A', 'LNS-042': 'K', 'LNS-040': 'K', 'LNS-033': 'K', 'EQN-528': 'F',
    'FUR-001': 'A', 'FUR-008': 'A', 'FUR-012': 'A', 'FUR-543': 'A', 'FUR-547': 'A', 'FUR-551': 'A', 'FUR-555': 'A', 'FUR-570': 'A', 'FUR-572': 'A', 'FUR-573': 'A', 'FUR-573b': 'A', 'FUR-581': 'A', 'FUR-582': 'A', 'FUR-583': 'A',
}

# the new rows: (id, after, fields, research text). Placed after `after` in rows.json and last in `after`'s home section (shownOn); split lines
# carry splitFrom; the open row and the input rows do not.
NEW_ROWS = [
    ('LAB-018b', 'LAB-018', dict(kind='reduction', stage='A', ptype='postulate', notions=['qf', 'clk', 'lat', 's-geo', 's-phy'], fields=['topology', 'algebra'], cells=['(p,q,0)'], split=True,
                               homePhys='Ω₂^{Pin⁻} ≅ ℤ₈ (Kirby–Taylor); the Fidkowski–Kitaev ℤ₈; the A_k of Atiyah–Bott–Shapiro as KO^{−k}(point)', homeMath='Pin⁻ structures as ℤ₄-enhancements; Ω₂^{Pin⁻} ≅ ℤ₈ by the Brown invariant; Atiyah–Bott–Shapiro',
                               standardRef='Kirby–Taylor, Pin structures on low-dimensional manifolds (1990), Thm 3.2 and Lemma 3.6, §3 (read); E. H. Brown, Generalizations of the Kervaire invariant, Ann. Math. 95 (1972) (read at statement level); Debray–Gunningham, arXiv:1803.11183, Thm 3.12, Thm 3.15 (read); Fidkowski–Kitaev, Phys. Rev. B 81 (2010) 134509 (abstract); Atiyah–Bott–Shapiro, Clifford modules, Topology 3 (1964) 3–38, the theorem A_* = KO^{−*}(point), read through the expositions named in LAB-018',
                               phenomena=['lattice'], depends=[{'id': 'LAB-018', 'rel': 'derives'}], shownOn={'page': 'clock', 'section': 'clock', 'role': 'result'}),
     "The same ℤ₈ in the literature, read and not computed: (V, ·) is H₁(#ⁿℝP²; ℤ₂) and w is a Pin⁻ structure on that surface (Kirby–Taylor, Thm 3.2), the clock its class in Ω₂^{Pin⁻} ≅ ℤ₈ (Kirby–Taylor, Lemma 3.6; Brown 1972; Debray–Gunningham, Thm 3.12 and 3.15); it is the Fidkowski–Kitaev ℤ₈ of an edge of time-reversal-invariant Majorana chains (Fidkowski–Kitaev 2010), and the KO-degree of the type table: that the groups A_k of Atiyah, Bott and Shapiro, whose ring the Atlas computes in ATY-026, are KO^{−k}(point) is their theorem, read, not finite. What the labels compute is in LAB-018: the Brown invariant of w and the Gauss sums; the identifications of this row are the literature's."),
    ('LAB-016b', 'LAB-016', dict(kind='reduction', stage='M', ptype='postulate', notions=['nul', 'biv', 'cnx', 's-phy', 's-geo'], fields=['topology'], cells=['(p,q,0)'], split=True,
                               homePhys='Pin⁻ ↔ T² = +1 (Majorana chains, the Fidkowski–Kitaev ℤ₈ = Ω₂^{Pin⁻}); Pin⁺ ↔ T² = (−1)^F, Ω₂^{Pin⁺} ≅ ℤ₂', homeMath='Pin⁺ and Pin⁻ structures on surfaces: ℤ₄-enhancements for Pin⁻ (Ω₂^{Pin⁻} ≅ ℤ₈), w₂ = 0 for Pin⁺ (Ω₂^{Pin⁺} ≅ ℤ₂)',
                               standardRef='Kirby–Taylor, Pin structures on low-dimensional manifolds (1990), §3 (read): Pin⁻ structures ↔ ℤ₄-enhancements, Ω₂^{Pin⁻} ≅ ℤ₈, Ω₂^{Pin⁺} ≅ ℤ₂; A. Kapustin, R. Thorngren, A. Turzillo, Z. Wang, Fermionic symmetry protected topological phases and cobordisms, JHEP 12 (2015) 052 (read at statement level): T² = 1 ↔ Pin⁻, T² = (−1)^F ↔ Pin⁺',
                               phenomena=['electron'], depends=[{'id': 'LAB-016', 'rel': 'derives'}, {'id': 'LAB-018b', 'rel': 'derives'}], shownOn={'page': 'clock', 'section': 'clock', 'role': 'result'}),
     'The matching of Pin⁺ and Pin⁻ with the time reversals of square ±1, read and not computed: on a surface a Pin⁻ structure is a ℤ₄-enhancement of the intersection form and Ω₂^{Pin⁻} ≅ ℤ₈ by the Brown invariant, while a Pin⁺ structure exists exactly when w₂ = 0 and Ω₂^{Pin⁺} ≅ ℤ₂ (Kirby–Taylor, §3); on fermions T² = +1 is the Pin⁻ case, the Majorana chains of the Fidkowski–Kitaev ℤ₈ = Ω₂^{Pin⁻}, and T² = (−1)^F is the Pin⁺ case (Kapustin, Thorngren, Turzillo and Wang 2015). What stays open in LAB-016 is a check of the Pin⁺ side on the labels: none builds it.'),
    ('ATY-019b', 'ATY-019', dict(kind='computation', stage='A', ptype='identity', notions=['sq', 'mir', 'lat', 'clk'], fields=['geometry', 'topology'], cells=['(1,0,0)', '(0,1,0)', '(0,0,0)'], split=True,
                               homePhys='the lattice numbers of the geometric models of matter: h·h = 1 on CP², (2h)² = 4, genus 0 by adjunction', homeMath='intersection numbers on CP² and S² × S²: h² = 1, (2h)² = 4, the antidiagonal of S² × S² with self-intersection −2; genus by adjunction with c₁ = 3h',
                               standardRef='Atiyah, Manton and Schroers, Geometric models of matter (read); the intersection forms of CP² and S² × S², adjunction (textbook)',
                               phenomena=['matter'], depends=[{'id': 'ATY-016', 'rel': 'derives'}, {'id': 'ATL-001', 'rel': 'instance'}, {'id': 'ATL-002', 'rel': 'instance'}, {'id': 'ATL-003', 'rel': 'instance'}],
                               shownOn={'page': 'shapes', 'section': 'sh-gosset', 'role': 'detail'}, evidence=[{'check': 'aty·matter·3', 'script': 'checks/selfcheck/gravity/aty_matter_models.py', 'mode': 'ran'}]),
     "The numbers of ATY-019, computed on the lattices: on the lattice (1) of the cell (1,0) the class h of CP² has h·h = 1 and the conic 2h has (2h)·(2h) = 4; the antidiagonal of S² × S² (form H, D′·D′ = −2 under the pull-back h ↦ x + y) gives RP²·RP² = −1; both curves have genus 0 by adjunction with c₁ = 3h; reversing the orientation negates the form (the mirror cell (q,p)), and the empty form of S⁴, the cell (0,0), is its own mirror. Checked in aty_matter_models.py (aty·matter·3); the reading of these numbers as particles is ATY-019, the paper's."),
    ('LNS-017g', 'LNS-017e', dict(kind='question', stage='F', ptype='open', notions=['sq', 'cnx', 'nul', 's-geo', 's-phy', 'i-chart'], fields=['geometry'], cells=['(1,4,0)', '(1,3,1)'], split=False,
                                homePhys='the Bargmann lift: a Lorentzian 5D metric with a null Killing vector reduces to Newton–Cartan gravity (Duval, Burdet, Künzle, Perrin)', homeMath='null Kaluza–Klein reduction (Bargmann structures) and Newton–Cartan geometry',
                                standardRef='C. Duval, G. Burdet, H. P. Künzle, M. Perrin, Bargmann structures and Newton–Cartan theory, Phys. Rev. D 31 (1985) 1841 (pointer, source unread)',
                                phenomena=['gravity'], depends=[{'id': 'LNS-017e', 'rel': 'derives'}], shownOn={'page': 'steps/schuller', 'section': 'sc-fibre', 'role': 'result'}),
     'Open: the null case that can run. A null fifth generator (ε = 0) makes the five-dimensional frame metric degenerate — no Levi-Civita connection, no volume form, no Einstein form — so LNS-017e cannot be run at ε = 0, and that is the reason, not a choice. The well-posed null case is a different one: a Lorentzian five-dimensional metric of the cell (1,4) with a null Killing vector (the Bargmann lift), whose reduction along that vector is Newton–Cartan gravity (Duval, Burdet, Künzle and Perrin 1985, pointer, source unread). The engine can run it (a null direction inside Cl(1,4), fields independent of it); it is not run here: open.'),
    ('INP-095', 'INP-094', dict(kind='definition', stage='O', ptype='postulate', notions=['src', 'i-tab'], fields=['geometry'], cells=['(1,3,0)'], split=False, inputKind='data', inputKindName='imported data',
                               homePhys='the KATRIN bound on the neutrino mass, m_ν < 0.45 eV (90 % confidence)', homeMath='',
                               standardRef='KATRIN Collaboration, Direct neutrino-mass measurement based on 259 days of KATRIN data, arXiv:2406.13516 (read at statement level): m_ν < 0.45 eV at 90 % confidence',
                               phenomena=['matter'], depends=[], shownOn={'page': 'steps/grav2', 'section': 'needs', 'role': 'detail'}),
     "The lightest neutrino's mass is an input, as its source states it: below 0.45 eV at 90 % confidence (KATRIN, 2024). The shifted view uses it as the bound on the shift r ≥ λ_C/4 of the lightest neutrino (ATY-064) and as the unit of the odd-integer test (ATY-060); no computation on the labels gives it."),
    ('INP-096', 'INP-095', dict(kind='definition', stage='O', ptype='postulate', notions=['src', 'i-tab'], fields=['geometry'], cells=['(1,3,0)'], split=False, inputKind='data', inputKindName='imported data',
                               homePhys="the bound 10⁻¹³ on violations of the equivalence principle, as the paper states it", homeMath='',
                               standardRef='Atiyah and Moore, "A shifted view of fundamental physics" (arXiv:1009.3176), (2.14) (read): the limit 10⁻¹³ on violations of the equivalence principle, which the paper takes from the experiments without naming one',
                               phenomena=['gravity'], depends=[], shownOn={'page': 'steps/grav2', 'section': 'needs', 'role': 'detail'}),
     "The bound on violations of the equivalence principle is an input, as the paper states it: 10⁻¹³ (2.14), the paper's figure, which it does not attribute to a named experiment. The shifted view uses it for the strength k/ħ ≤ 10⁻¹³/r (ATY-064); whether the test weighs the Noether energy or the coupling per unit density is ATY-059."),
    ('INP-097', 'INP-096', dict(kind='definition', stage='O', ptype='postulate', notions=['src', 'i-tab'], fields=['geometry'], cells=['(1,3,0)'], split=False, inputKind='data', inputKindName='imported data',
                               homePhys='the observed cosmological constant and the flat-ΛCDM parameters of Planck 2018: H₀ = 67.36 km s⁻¹ Mpc⁻¹, Ω_Λ = 0.6847, Ω_m = 0.3153, age 13.787 Gyr', homeMath='',
                               standardRef='Planck Collaboration, Planck 2018 results. VI. Cosmological parameters, arXiv:1807.06209 (read at statement level): H₀ = 67.36 km s⁻¹ Mpc⁻¹, Ω_Λ = 0.6847, Ω_m = 0.3153, age 13.787 Gyr',
                               phenomena=['cosmology'], depends=[], shownOn={'page': 'steps/grav2', 'section': 'needs', 'role': 'detail'}),
     'The observed cosmological constant is an input, as its source states it: Λ = 3Ω_ΛH₀²/c² with H₀ = 67.36 km s⁻¹ Mpc⁻¹ and Ω_Λ = 0.6847 (Planck 2018), with Ω_m = 0.3153 and the age 13.787 Gyr beside it. The shifted view uses it for the strength k/ħ = √Λ, the time scale ħ/kc and its ratio to the age of the universe (ATY-055, ATY-064); the size and the sign of Λ are not derived on the labels (ATY-010, INP-049).'),
]

SRC = {'P0.1': 'round20:P0.1', 'P0.3': 'round20:P0.3', 'P0.4': 'round20:P0.4', 'SV': 'round20:shifted-view'}

# research text edits: row -> (package, [(old, new) | ('append', text) | ('replace_all', text)]); applied to the research full text (lens none, mode both)
TEXT_EDITS = {
    'LNS-038': ('P0.1', [
        ('and the same square sits in every Cl(p,q) with p ≥ 2 and q ≥ 2 (an argument from the sign rule, not a separate check).',
         'and the same square sits in every Cl(p,q) with p ≥ 2 and q ≥ 2 (a proof from the sign rule: two generators of square +1 and two of square −1 generate a copy of Cl(2,2), by Thm T1; checked besides on the generators 1, 2, p + 1, p + 2 of the 28 cells with p, q ≥ 2 and p + q ≤ 10, check_T11 item 4b). A search through every grid of the 44 cells with 1 ≤ p + q ≤ 8 finds such a square in 30 and none in the other 14: p + q ≤ 3, (4,0), (1,3), (0,4), (5,0) and (1,4); in those 14 the commuting blades of square +1 admit a consistent ±1 assignment (check_T11 items 4c, 4d; the same lists by two independent routes, a grid search and a linear system over 𝔽₂: mermin_grids G1–G3, lnc059_idempotents_std), and in the 30 every commuting 3 × 3 grid has line-sign product −1 (mermin_grids G5).'),
        ('The link to contextuality is open: whether these counts are the known polar-space picture of Pauli-type groups and which of them the contextuality literature lacks, and, for the cells with p ≤ 1 or q ≤ 1, whether their blades of square +1 give such a square (no check builds one).',
         'The link to contextuality is open: whether these counts are the known polar-space picture of Pauli-type groups (the symplectic and orthogonal polar spaces of Saniga and Planat, Adv. Stud. Theor. Phys. 1 (2007), and of Havlicek, Odehnal and Saniga, SIGMA 5 (2009): pointers, not read) and which of them the contextuality literature lacks (the polar-space and contextuality papers are not read).')]),
    'CAND-144': ('P0.1', [('append', " With e₁ = X⊗1, e₂ = Z⊗1, e₃ = iY⊗X, e₄ = iY⊗Z (real 4 × 4, qubit 0 the left factor), the nine blades are Mermin's nine two-qubit operators up to sign, and the six lines are his rows and columns (mermin_square B0–B3; mermin_grids G4, G5).")]),
    'ATY-024b': ('P0.1', [('replace_all', "Theorem 4.1's Einstein hypothesis is E_a(c) = 0 for the engine's Einstein form in the cell (4,0): E_a(c), read as M = G − 3cδ as in GRV-004d, equals the Christoffel route's G − 3cδ exactly, c symbolic, at the origin of exact 2-jets of 8 generic frames and 9 Einstein frames (S⁴, ℂP², constant curvature K = −1 and 1/3); on the Einstein frames c = −R/12 is the only solution, on the generic ones there is none. The identity has degree 2 in the jet coefficients, so a false one passes the six strong draws with probability at most 6.0e−11 (einstein_riem). On the Atiyah–LeBrun edge-cone family (5.4)–(5.6) the same reading gives M(c) = 0 exactly at c = −β²(2 − β)/2 and at no other c, by an independent exact Christoffel route at seven (β, point) pairs, β = 1, 1/2, 2/3, 3/2, 25/81, 49/25, with σ₃ normalised to the unit S³ and, at β = 1, four times the Fubini–Study metric (aty024_cone_einstein; ATY-022, ATY-024).")]),
    'ATY-024': ('P0.1', [
        ('as an identity on 21 torsion-free Lorentzian frames, n = 4 (GRV-004d);', 'as an identity on 21 torsion-free Lorentzian frames, n = 4 (GRV-004d), and on exact 2-jets of Riemannian frames of the cell (4,0) (ATY-024b);'),
        ('(ATY-022, ATY-036; its Einstein form not computed)', '(ATY-022, ATY-036; its Einstein form in the cell (4,0) vanishes exactly at c = −β²(2 − β)/2 and at no other c, by an independent Christoffel route at seven (β, point) pairs: ATY-024b, aty024_cone_einstein)')]),
    'CAND-084': ('P0.1', [('with J on the right the square is ∇*∇ + R/4, recalled, not run', 'with J on the right the square is ∇*∇ + R/4: J multiplies from the right and J² = −1, so (DJ)² = −D², and −∇^a∇_a = ∇*∇ in a Riemannian cell')]),
    'CAND-086': ('P0.1', [('Higher grades in curved frames are not run.', "In curved frames, at every degree k = 0 … n (n = 3 to 5, Lorentz and Euclidean squares, at n = 5 also Cl(2,3); n = 6 with the option --n 6; exact at the origin of three strong 2-jet draws and one frame with e(0) ≠ 1): (dδ + δd)α = ∇^c∇_cα − Ric(α) + Riem(α), Ric acting on each slot and Riem (R_a^d_b^e) on each pair of slots, with the Atlas's δ (plus the divergence, minus the usual codifferential); the fit is unique for 2 ≤ k ≤ n − 1, reduces to the 1-form identity above at k = 1 and to 0 at k = 0 and k = n (where Ric = Riem = Rα); a Christoffel route agrees and gives the textbook 2-form formula; the terms have degree ≤ 3, so a false identity passes with probability ≤ (3/101)³ = 2.6e−5 per case (weitzenboeck_forms, 87 checks; 117 with n = 6).")]),
    'ATY-051': ('P0.1', [('Scope: values at points (jets of order two) of finitely many frames; the square only on 1-forms; GRV-003 holds the spinor analogue (Lichnerowicz).',
                          "Scope: values at points (jets of order two) of finitely many frames; GRV-003 holds the spinor analogue (Lichnerowicz). At every grade, in the Clifford form: D²X − □X = −Ric(X) + Riem(X) on the same kind of frames, Ric on each slot and Riem on each pair of slots, for n = 3 to 6 (Lorentz and Euclidean squares; at n = 5 also Cl(2,3), the second Kaluza–Klein algebra of step 8; n = 6 with the option --n 6), with the Atlas's δ, minus the usual codifferential; an independent Christoffel route agrees at every k, n and signature and gives for 2-forms the textbook formula Δ_Hα_ab = −∇²α_ab + Ric_a^cα_cb + Ric_b^cα_ac − 2R_a^c_b^dα_cd (weitzenboeck_forms).")]),
    # the researcher view of the shifted page (docs/round20/staging/shifted_view): the computed items, as prose
    'ATY-004': ('SV', [('(exact cos θ and sin θ; the shift vector itself is not built)', '(exact cos θ and sin θ; on a plane wave a translation by a acts only through θ = k·a, so the check runs on θ)')]),
    'ATY-037': ('SV', [('So (2.12) is not reproduced from the printed operator, and the page prints no step from (2.10) to it; what the paper calls T₀₀ is not defined on this page, no energy-momentum tensor of the shifted theory is built here, and wave packets are out of scope.',
                        'So (2.12) is not reproduced from the printed operator, and the paper prints no step from (2.10) to it. The energy-momentum tensor of the shifted action is built in ATY-042 and ATY-044, and finite packets of waves are ATY-043.')]),
    'ATY-043': ('SV', [('Scope: two packets of five waves; finite sums only, no integral over momenta and no localized packet.',
                        'Scope: two packets of five waves, finite sums. A packet localized in space is an integral over momenta; on one shell it is a limit of finite sums, and the identities, bilinear in the fields, pass to that limit (an argument, not a separate check).')]),
    'ATY-045': ('SV', [('two roots for the energy; the initial-value problem is not treated.',
                        'two roots for the energy. The initial-value problem is not treated, and the reason is not a choice: the data of a delay equation are a function on an interval of length τ, an infinite-dimensional space, of which the computed roots give the exponential solutions only.')]),
    'ATY-044': ('SV', [('Scope: finite sums of plane waves on rational shells; one rotor; the Belinfante improvement only; the coupling of T_B to a field is not computed.',
                        "Scope: finite sums of plane waves on rational shells; one rotor; the Belinfante improvement only. T_B is the source of a weak gravitational field: the shifted action ∫e ψ̄(iD − m + iκe^{−τD})ψ on a perturbed frame e_a^μ = δ_a^μ − ½h_a^μ(x), with the spin connection of D and the Duhamel term of the shift, δe^{−τD} = −∫₀^τ e^{−(τ−s)D} δD e^{−sD} ds; to first order, with h = s + w split into its symmetric and antisymmetric parts, δD = −½h_a^μγ^a∂_μ + ¼(∂_bs − ∂^as_ab)γ^b + ⅛γ^μγ^aγ^b∂_μw_ab (checked against the vierbein formula by differences, and against ATY-037's N^{−1/2}D′N^{1/2} for a static h₀₀ = −2Φ); on solutions, exactly in ℚ(i)[π] (i for the labels' J), with the signature (+, −, −, −), δS = −½∫h_μν T_B^μν, T_B the Belinfante tensor above. What fixes and tests it: κ = 0 reproduces the textbook symmetric tensor of the Dirac field, which fixes the signs; a uniform potential reproduces ATY-039, the Noether energy ρE(1 − (−1)ⁿμi); a constant h_μν, all ten components, gives the factor (1 − (−1)ⁿμi) on every component (16 single waves, rest and moving); h = εe^{iq·x}, q a cross frequency of two waves on one shell, gives the Fourier component −½ε_μνT_B^μν(−q), not that of the canonical T, which differs there by at least 16 %. The response to the antisymmetric perturbations (local Lorentz rotations) is zero, so the source is symmetric, and it is conserved. On one shell it is the ordinary one times the factor: T_H^μν = (1 − (−1)ⁿμi)(i/4)ψ̄(γ^μ∂↔^ν + γ^ν∂↔^μ)ψ, a complex source whose real part is the ordinary symmetric Dirac tensor; a real theory takes that scalar part (consistent with ATY-039 and ATY-047: the deviation is the imaginary coefficient of a non-Hermitian operator). The frame term alone gives exactly the canonical tensor of ATY-042, and the spin connection adds exactly the improvement ∂_λG^λ. On two shells at one shift the coupling at the cross-shell frequency is zero, and so are T and T_B there: there is no gravitational source at the beat; the beat that the density of the uniform-potential coupling shows (ATY-039, ATY-040) is therefore not a source, a Φ oscillating at the beat frequency couples to nothing, exactly, the Duhamel term cancelling it. Dirac matrices with scipy expm and quad_vec (the Duhamel integral also by Van Loan's block exponential) agree to 10⁻¹⁵, and shifted_tensor.py's own T_B to 8·10⁻¹¹. Controls: the shift built with the unperturbed D, the spin connection dropped, and the canonical tensor in place of T_B each fail. Scope of the source: first order in h, one Fourier mode of h; plane waves on rational shells with Eτ on the quarter turns (single waves, and two-wave fields on one shell or on two shells at one shift); classical fields (shifted_gravity, 16 checks).")]),
    'ATY-046': ('SV', [
        ('The reason, derived and not run beyond first order:', 'The reason, derived, and run at second order below:'),
        ('Scope: first order in g; a static linear potential; whether the shifted equation in a field has solutions other than the ordinary ones of the quantized masses is not settled; no time-dependent field, no Fock space.',
         "Scope: first order in g here and second order below; a static linear potential; whether the shifted equation in a field has solutions other than the ordinary ones of the quantized masses concerns every solution, which no finite family exhausts (ATY-047); no time-dependent field, no Fock space. At second order in the gradient: write 𝐃_g = 𝐃 + gV₁ + g²V₂ (for Φ = gx₃ the frame's second-order term is V₂ = (3/2)x₃²γ⁰∂_t − x₃γ³) and expand exp(−s𝐃_g) = U₀ + gU₁ + g²U₂, the Dyson terms fixed by U₀′ = −𝐃U₀, U₁′ = −𝐃U₁ − V₁U₀, U₂′ = −𝐃U₂ − V₁U₁ − V₂U₀ with U₀(0) = 1, U₁(0) = U₂(0) = 0 (checked as functions of s on random fields of degree 7; U₂ carries the double integral). For A₀ = gx₃ and for Φ = gx₃, in the 16 cases of the first order, the second-order solution P₀ + gP₁ + g²P₂ of the ordinary equation of mass E with the same coupled operator (P₁ of degree 3 and P₂ of degree 6 in x₃, exact elimination, unique once the part in the mode's half at degrees 0 and 1 is set to zero) solves the shifted equation at second order exactly in ℚ[π]: O₀[P₂] + O₁[P₁] + O₂[P₀] = 0 with O₂ = κU₂(τ)J (plus V₂J for Φ). The derivation is run at this order too: Σ_{i+j=k} U_i[P_j](s) = P_k e^{JEs} for k = 0, 1, 2. The two signs of frequency mix at second order as for the ordinary equation of mass E: the part of P₂ in the advanced half is (E/15)x₃⁵γ³Zγ₀J for A₀ and (E³x₃⁵/15 − 7Ex₃³/12 − x₃/(8E))γ³Zγ₀J for Φ. Dirac matrices on x₃-polynomials of degree ≤ 10 (22 cases, moving waves included; scipy expm of the whole operator, five-point differences in g) agree to a relative residual of 5.5·10⁻⁹. Controls: the shift built with the free 𝐃, the second-order Dyson term dropped, its double integral alone dropped, and x₃ treated as a constant inside the shift each break the second-order equation in all 16 cases. Scope of the second order: static linear potentials as formal series in g to second order; rest fields polynomial in x₃ up to degree 6, moving waves numerically; the four quarter-turn settings (shifted_gradient2, 9 checks).")]),
    'ATY-053': ('SV', [
        ('the order read from the series, not from a solution of (3.10) carried to order four; on de Sitter it is consistent to every order. Open: the meaning of the operator equations; the pair (g, φ) of (3.11).',
         "the order read from the series and confirmed on actual solutions of (3.10) carried to the D⁴ term (below); on de Sitter it is consistent to every order. Open: the meaning of the operator equations; the pair (g, φ) of (3.11). The FRW restriction carried to the D⁴ term on actual solutions: the FRW frame e^a = η²dx^a is pressureless dust (a ∝ t^{2/3}), and the wave equation (3.10) has exact solutions there, □(η^tγ₀) = (t² + 3t − 12)η^{t−6}γ₀ and □(η^tγ_i) = (t − 1)(t + 4)η^{t−6}γ_i, so ηγ_i and η⁻⁴γ_i with integer exponents, η^tγ₀ with t = (−3 ± √57)/2, and the families of x-degree ≤ 2: 77 solutions in all. On every one, exactly, D²X = −Ric X, and D⁴X = Ric²X − □(Ric X) with □(Ric X) ≠ 0 on every non-zero solution (D⁴X = 2Ric²X on ηγ_i and 12Ric²X on η⁻⁴γ_i). D⁴ is not tensorial on the solutions: Y = ηγ₁ − η⁻⁴γ₁ solves (3.10) and vanishes on the hypersurface η = 1, while D⁴Y = −360γ₁ there. So the residual of each of the three shifted operators, order by order in μ, is an endomorphism of X through μ² and fails at μ³, the D⁴ term, on actual solutions of (3.10). On de Sitter (44 solutions, in ℚ(√21) and ℚ(√13)) D^{2j}X = Λ^jX and the residual is a number times X at every order computed, μ⁰ to μ⁶. An index route on the coordinate metric and numpy finite differences agree. Controls: the claim D⁴X = Ric²X fails on every FRW solution; non-solutions of (3.10) break D²X = −Ric X. Scope: these two conformally flat frames, solutions Laurent in η of x-degree ≤ 2, the residual through μ⁴ on FRW and μ⁶ on de Sitter (shifted_frw_d4, 19 checks).")]),
    'ATY-055': ('SV', [("The coincidence with the age of the universe is the paper's remark, not computed; the dilaton against fifth-force bounds and the regime beyond the zero mode are not touched.",
                        "The coincidence with the age of the universe, computed: with the observed Λ = 3Ω_ΛH₀²/c² (Planck 2018, INP-097: H₀ = 67.36 km s⁻¹ Mpc⁻¹, Ω_Λ = 0.6847, Ω_m = 0.3153), k/ħ = √Λ = 1.044·10⁻²⁸ cm⁻¹ and ħ/kc = 1/(c√Λ) = 1/(√(3Ω_Λ)H₀) = 1.01·10¹⁰ years; in flat ΛCDM the age is t₀ = (2/(3H₀√Ω_Λ)) arsinh √(Ω_Λ/Ω_m), so t₀/(ħ/kc) = (2/√3) arsinh √(Ω_Λ/Ω_m) = 1.363 and t₀ = 13.80 Gyr (Planck 2018: 13.787 Gyr). The paper's coincidence is therefore a statement about today's ratio Ω_Λ/Ω_m: whenever Λ is set by its observed value, ħ/kc is the age of the universe times a number fixed by that ratio, whatever the shift does; the e-folding times of the growing radius, 2.0 and 2.2·10¹⁰ years with this Λ, are 1.5 and 1.6 times the age (inputs as their source states them; the formula for t₀ is the standard one for flat ΛCDM with radiation neglected: shifted_review A1). The radius scalar against the solar-system bounds: the paper's remark that a massless scalar with couplings of gravitational strength meets the bounds of fifth-force experiments does not hold. The assumption, stated: matter couples to the four-dimensional metric as matter independent of the fifth coordinate, with no stress and no momentum along the circle (T⁴₄ = T⁴_a = 0: dust, ordinary matter at rest in the fifth direction), the setting of a gravitational-strength coupling. On the engine, exactly at points of ten Kaluza–Klein frames (both squares of the fibre generator; the Christoffel route agrees in all 25 components), the 44 equation at F = 0 gives R₄ = 0, the trace of the four-dimensional block gives □φ = κ₅φT/3, and the block has no (∇φ)² term: the reduced theory is Brans–Dicke with ω = 0, G⁽⁴⁾ = κ₅T + (∇∇φ − g□φ)/φ, □φ = 8πT/(3 + 2ω), and matter of this kind is conserved in, and moves on geodesics of, the four-dimensional metric. The shifted lowest order adds εκ²φ: □φ = εκ²φ + κ₅φT/3, so the scalar's mass² is −εκ²: for ε = −1 it is massive, for ε = +1, the de Sitter case the paper fixes by Λ > 0, a tachyon whose static field is cos(κr)/r; either way its length 1/√Λ = 9.6·10²⁷ cm makes it massless in the solar system (at 1 AU the factor is 1 − 1.6·10⁻¹⁵). The linearized static field of a point mass M, solved on the five-dimensional engine, is g₀₀ = 1 − 2M_K/r, g_ij = −(1 + 2γM_K/r)δ_ij with γ = (1 + ω)/(2 + ω) = 1/2, α² = 1/(2ω + 3) = 1/3 and the Kepler mass M_K = 4M/3: the scalar couples to the trace with gravitational strength. Against the Cassini measurement γ − 1 = (2.1 ± 2.3)·10⁻⁵ (Bertotti, Iess and Tortora 2003, an input), γ − 1 = −1/2 lies 2.2·10⁴ standard deviations away; at two standard deviations the bound is α² < 1.25·10⁻⁵, or ω > 4·10⁴, against α² = 1/3. A finding beside it: with stress T⁴₄ = wρ along the circle, γ = (1 + w)/(2 − w), equal to 1 only at w = 1/2, and such bodies' masses vary as φ^w, which breaks the equivalence principle. A radius stabilised by F² (LNS-017e) would be a different theory, which the paper does not propose; for ε = +1 the tachyonic instability acts before Cassini does. Controls: Brans–Dicke with ω = 1 or −1 fails on the frames where ω = 0 holds; a scalar of range 1 AU would still give γ − 1 = −0.22 there; matter with stress along the circle breaks R₄ = 0 and the trace equation. Scope: the zero mode at the lowest shifted order, F = 0, the linearized static field (the background enters at Λr² ≈ 2·10⁻³⁰ at 1 AU), under the stated assumption on matter (shifted_fifthforce, 17 checks). The massive modes on the circle: on the engine (which takes fields depending on the fifth coordinate) and by an independent Christoffel route, on ten 2-jet frames with both squares s of the fibre generator, a field f(x)e^{iny/R₀} obeys □₅(fe^{iny/R₀}) = (□₄f + φ⁻¹∇φ·∇f − sn²f/(R₀φ)²)e^{iny/R₀} exactly, the 1/φ² coming from g^{yy} and the gradient term from the volume factor φ√|g₄| (exact fits; neither is chosen); for the spacelike fibre (s = −1, Cl(1,4)) the mode has the mass m_n = |n|/(R₀φ), for s = +1 (Cl(2,3)) the tower is tachyonic; on 1-forms the curvature terms are those of the base alone, and on the mode D₅² = D₄² + m_n². On the de Sitter base with the growing radius φ ∝ e^{rt} the mode obeys f″ + (3H + r)f′ + m₁(t)²f = 0, m_n(t) = |n|/(R₀φ(t)) ∝ e^{−rt}, the friction 3H + r derived three ways (the volume factor, the Christoffel symbols, the engine in the chart): the tower descends. The zero-mode truncation is adiabatic while r/m₁ ≪ 1 (the adiabatic invariant, energy over frequency, constant to the expected order: solve_ivp against the exact Bessel solution, to 6·10⁻⁷ of the envelope); it changes by 50 % at r/m₁ ≈ 0.2–0.3 and by factors of 4 to 100 at r/m₁ = 1–2, and the oscillation stops at m₁ = (3H + r)/2: the paper's \"the zero-mode approximation fails once the growth matters\" happens when the circle reaches about the Hubble size; from a circle of the Planck length (an input) that takes ln(1/(κR₀φ₀)) = 140 e-foldings of the radius, 2.8·10¹² years at 2ħ/kc = 2.03·10¹⁰ years each; today r/m₁ ∼ 10⁻⁶¹, and the age of the universe is 0.68 e-folding times. A finding beyond the paper: on a mode with D² = −m², x = mτ, the three shifted operators on their own lowest-order backgrounds factor exactly (series identities to x²⁸): (τ/κ)(Ricci_ss − Ricci) = −sin x(2x + μ sin x), Ricci₊₊: 2 sin x(x − μ sin x), Ricci₊₋: 2x sin x, so all three reduce to the unshifted operator at m_j = jπ/τ, a property of the formal series on eigenmodes, not a spectrum of states; with the KATRIN input (INP-095) the first such mass is π/τ = 0.90 eV, twice 0.45 eV, since τ = λ_C/4 makes π/τ = 2m_ν. No truncation of the low-energy series sees it: the first root stays within 10⁻⁶ of π only from the D¹⁶ term on. The low-energy reading holds while mτ ≪ 1, so the Kaluza–Klein modes enter it only after the circle has grown beyond τ (66 e-foldings from the Planck length); in the five-dimensional reading, where D₅² = D₄² + m_n² vanishes on every ordinary mode, the series does not see the Kaluza–Klein mass at all. Controls: the mass formula without the 1/φ, the friction without r, and the claim that the truncation stays adiabatic at r/m₁ = 2 each fail. Scope: F = 0; values at points of 2-jet frames and exact identities in the de Sitter chart; the growth numerically for the two (H, r) above; the shifted operators read as series on modes on which D² is a number (shifted_kkmodes, 22 checks).")]),
    'ATY-058': ('SV', [('D₋ is not tested at a null frequency. Chiral representations and the Higgs mechanism are not computed.',
                        "With Dirac matrices and K = γ^μk_μ, the symbols of iD_x − m on e^{−ik·x} are D₊: K − m + iκe^{iτK}, D₋: K − m − iκe^{−iτK}, D_s: K − m + κ sin τK, D_c (uniform): K − m + iκ cos τK, D_c (printed): K − m − κ cos τK (at rest they reproduce ATY-005 and ATY-007). At the null frequencies (1, 1, 0, 0), (5, 3, 4, 0), (13, 5, 12, 0) and for (m, κ, τ) = (3, 2, π/10), (1, 1, 1), (2, 1/2, 2), (0, 2, 1/2), (0, 0, 1): D₋ has a plane wave only at m = κ = 0, like D₊, since there K² = 0 and its symbol is (1 − κτ)K − (m + iκ), invertible unless m = κ = 0; at m = 0, D_s keeps the massless solutions (its symbol is (1 + κτ)K, for κτ ≠ −1) and D_c has none in either reading. At m = 0 the symbol of D_s is odd in K, because sin is odd, so it anticommutes with γ₅ = iγ₀γ₁γ₂γ₃: {γ₅, K + κ sin τK} = 0, and P_{L,R} = ½(1 ∓ γ₅) map solutions of D_s at m = 0 to solutions (checked on timelike, null, spacelike and random K, largest anticommutator 3·10⁻¹⁴); the massless kernel of D_s at each null frequency splits into one left-handed and one right-handed solution, each solving D_s by itself; the symbols of D₊, D₋ and D_c have a part even in K and do not anticommute (smallest anticommutator 187): D_s is the one variant with chiral representations (shifted_review V1, V2, C1, C2). The Higgs mechanism is not computed, and not by choice: it needs a model, a scalar field with its potential and its couplings to the two chiralities, which the paper does not give, so there is nothing determinate to compute. Why the first sentence stays a reading: whether chiral fermions are to be shifted at all is a choice of model, not a computation; what the choice would rest on is computed here.")]),
    'ATY-060': ('SV', [('append', " The odd-integer test of the Compton wavelengths, made definite: with one shift r for every stable fermion, cos Eτ = 0 gives E_f r/ħc = (n_f + ½)π, so every rest energy is an odd multiple of one unit, E_f = (2n_f + 1)u with u = πħc/2r ≤ m_ν c² for the lightest neutrino, and m_p/m_e = (2n_p + 1)/(2n_e + 1). With the KATRIN bound m_ν < 0.45 eV (INP-095) the denominator is at least 2n_e + 1 = m_ec²/u ≥ 1 135 553; over 100 000 consecutive odd denominators from that bound, a fraction 0.136 admits an odd numerator matching m_p/m_e = 1836.152 673 43(11) (CODATA 2018) within one standard uncertainty, as expected from the spacing 2/(2n_e + 1) of the odd fractions (0.136). So the test, as proposed, has no content while only an upper bound on the lightest mass is known: it needs u, the lightest neutrino's mass, to a relative precision of about 10⁻⁶, which fixes n_e (shifted_review O1). Why it cannot be done now: that mass is not measured; this is the reason, and it is not a choice. The QED processes need interacting quantized fields, and the Higgs mechanism a model the paper does not give: open for those reasons.")]),
    'ATY-064': ('SV', [('replace_all', "The magnitudes (2.8), (2.15), (3.7)–(3.9) and (5.1)–(5.4), from their inputs, as their sources state them: the lightest neutrino below 0.45 eV (KATRIN, 90 % confidence; INP-095); the equivalence-principle bound 10⁻¹³ (the paper's figure; INP-096); Λ = 3Ω_ΛH₀²/c² with Planck 2018 (INP-097). The shift r ≥ λ_C/4 of the lightest neutrino, hc/(4 · 0.45 eV) = 6.9·10⁻⁵ cm (the paper's (2.8), (5.1): ≳ 10⁻⁵ cm at 1 eV); the strength k/ħ ≤ 10⁻¹³/r from the equivalence principle, 1.5·10⁻⁹ cm⁻¹ ((2.15): < 10⁻⁸ cm⁻¹); the cosmological constant Λ = 1.09·10⁻⁵⁶ cm⁻² ((3.7): ∼ 10⁻⁵⁶ cm⁻²); the strength k/ħ = √Λ = 1.04·10⁻²⁸ cm⁻¹ ((3.8), (5.2): ∼ 10⁻²⁸ cm⁻¹); μ = kr/ħ ≥ 7.2·10⁻³³ ((3.9), (5.4): ≳ 10⁻³³); the time scale ħ/kc = 1/(c√Λ) = 1.01·10¹⁰ years ((4.4): ≈ 1.06·10¹⁰ years). The paper's orders of magnitude hold with today's inputs; the strength fixed by Λ lies 10¹⁹ times below the equivalence-principle bound. The inputs are the sources' numbers, not outputs of the labels (shifted_review N1); the time scale as a number is ATY-055's, and its coincidence with the age of the universe is computed there.")]),
    'ATY-054': ('SV', [('Scope: F = 0, values at points of random frames; the shifted Einstein–Maxwell equations with F ≠ 0 are not built.',
                        "Why a reading: that ε is the square of a further generator is an interpretation of a sign; the computation fixes the equations, not what the sign is. With F ≠ 0 (derived from this row and LNS-017e, not run as one check): at their lowest order the shifted equations in five dimensions are Ric⁵ = εκ², the five-dimensional Einstein equations with a cosmological term, c = εκ²/4; their reduction with F ≠ 0 is LNS-017e's, Maxwell with the coupling −ε_fφ²/2 and □φ = 4cφ + (ε_f/4)φ³F_abF^ab, ε_f the square of the fibre generator. Beyond the lowest order they are operator equations, whose meaning is Q1 (ATY-056). Scope: values at points of random frames; F = 0 in the check itself.")]),
    'ATY-011': ('SV', [('(a translation is unitary, recalled)', '(a translation is unitary on square-integrable fields, a standard fact)'),
                       ('append', ' Why a reading: "why" asks for a motive behind the paper\'s construction; the facts it rests on are computed above, and which of them is the reason is not a statement a computation decides.')]),
    'ATY-010': ('SV', [('the shift moves the input from c to k and does not derive it.', 'the shift moves the input from c to k and does not derive it. Why a reading: the sign is a choice of operator and the size a match to observation; no computation on the labels fixes either.')]),
    'ATY-052': ('SV', [("Reading (ours), as in ATY-010: the size and the sign of Λ stay inputs, moved from c to k. Open: what the operator equations mean (the paper's own doubt) and which operator an argument would select.",
                        "Reading (ours), as in ATY-010: the size and the sign of Λ stay inputs, moved from c to k; the reason is ATY-010's. Open, told under Q1 (ATY-056): what the operator equations mean (the paper's own doubt) and which operator an argument would select.")]),
    'ATY-061': ('SV', [('append', ' Why a reading: "clock" names what the computed facts have in common (a fixed phase per shift, read in proper time); that it is the right name is an interpretation.')]),
    'ATY-062': ('SV', [('append', " Why a reading: the paper's remark is not a formula, and the Fock space it refers to is a quantized field, infinite-dimensional; the identification of its halves with the computed ones is an interpretation.")]),
    'ATY-065': ('SV', [('append', ' Why a reading: that two constants "meet" in μ is a statement about which combination matters; the computations show that μ is the one that appears in each result, and no computation can show that no other combination will.')]),
    'ATY-056': ('SV', [('append', " Why open: the meaning of an operator equation is a question of interpretation, the paper's own doubt; and selecting one of the three operators needs a principle the paper does not give. The computations above are what each reading implies.")]),
    'ATY-057': ('SV', [('replace_all', "Open: the equation (3.11) for the pair (g, φ) on the Hilbert space of 1-forms, the third of the paper's readings of its shifted Einstein equations. The Weitzenböck formula is checked on the labels with its signs, now at every degree (ATY-051), and the shifted Ricci operators are computed as series acting on 1-forms, with de Sitter worked out order by order (ATY-052, ATY-053). Why open: the equation is posed on the Hilbert space of 1-forms, an infinite-dimensional space that no finite computation on the labels reaches, and the paper leaves it open.")]),
    'ATY-059': ('SV', [('replace_all', "Open: what an equivalence-principle test of a shifted fermion weighs — the Noether energy, where the labels find no deviation, or the coupling per unit local density, where they find a J part — and how an experiment weighs a J-valued term. Whether the paper's bound (2.15) applies depends on it (ATY-037, ATY-039); the bound's numbers, from their inputs, are computed in ATY-064. Why open: both candidates are computed; which one an apparatus measures is a question about the measurement, outside the algebra, and no computation on the labels chooses between them.")]),
    'ATY-063': ('SV', [('replace_all', "Open: a quantized field with the shifted operator (Fock space), localized wave packets, the infinite-dimensional data of (2.1) as a space of states, and the relation of shifting to geometric quantization. On finite sums of quantized plane waves the shifted theory reads as the ordinary one, reweighted (ATY-047, our reading), and in a potential with a gradient the shift mixes the two halves in the operator at first order (ATY-046). Why open: a quantized field and the data of a delay equation are infinite-dimensional objects; a localized packet is an integral over momenta, whose identities on one shell follow from the finite sums by continuity (ATY-043) but whose dynamics off the shells does not; and the relation to geometric quantization compares two frameworks, a question of interpretation rather than of computation.")]),
    'ATY-047': ('SV', [('In a static linear potential, at first order, the ordinary first-order solution of mass E solves the shifted equation, and the two signs of frequency mix in it as for the ordinary Dirac equation (ATY-046). That this makes the shifted theory a reweighted ordinary one on its quantized solutions, and not a different dynamics there, is our reading; so is the conclusion that the difficulties the paper expects from external forces (remark 2.2.4) do not arise on these solutions at first order. That exp(−τ𝐃), a power series in 𝐃, acts on every ordinary solution of mass E as f_J(E) is derived and run only in the cases above (ATY-045, ATY-046). Not computed: fields that are not superpositions of quantized modes, interactions, quantization, and whether the shifted equation in a potential has solutions other than the ordinary ones.',
                        "In a static linear potential the ordinary solution of mass E solves the shifted equation, at first and second order by computation and at every order by the derivation, and the two signs of frequency mix in it as for the ordinary Dirac equation (ATY-046). Why a reading: \"a reweighted ordinary theory, and not a different dynamics there\" interprets the computed identities; so does the conclusion that the difficulties the paper expects from external forces (remark 2.2.4) do not arise on these solutions. That exp(−τ𝐃), a power series in 𝐃, acts on every ordinary solution of mass E as f_J(E) is derived, and run in the cases above (ATY-045, ATY-046). Beyond the computed cases, and why: fields that are not superpositions of quantized modes include the general data of a delay equation, a function on an interval (infinite-dimensional); interactions and quantization need quantized fields; and whether the shifted equation in a potential has solutions other than the ordinary ones concerns every solution, which no finite family exhausts.")]),
    'INP-049': ('SV', [('In the solved Einstein–scalar and Einstein–Dirac series c is not derived: it is chosen, or fixed by the 00 equation at t = 0 for the chosen H₀ and matter data.',
                        'In the solved Einstein–scalar and Einstein–Dirac series c is chosen, or fixed by the 00 equation at t = 0 for the chosen H₀ and matter data: it is initial data, not a consequence of the equations.')]),
    # --- P0.3
    'LNC-059': ('P0.3', [('(the idempotents follow; not computed)', '(the 2^{w} idempotents E_σ = ∏_k(1 + σ_k u_k)/2 over a basis u₁ … u_w of a maximal totally singular subspace are idempotent, pairwise orthogonal, sum to 1 and are primitive, dim E_σ A E_σ = dim D, with dim A E_σ = N dim D: a complete set of 2^{w} = sN orthogonal primitive idempotents, computed exactly for every cell with 1 ≤ p + q ≤ 8, 44 cells, lnc059_idempotents; a second route on the 36 signatures with p + q ≤ 7, lnc059_idempotents_std)')]),
    'CAND-121': ('P0.3', [
        ('The bracket of two Hamiltonian constraints in d = 2, exact on polynomial data. With H = −s(1/√q)(π^ijπ_ij − π²) − √qR', 'The bracket of two Hamiltonian constraints in d = 2 and d = 3, exact on polynomial data. With H = −s(1/√q)(π^ijπ_ij − π²/(d − 1)) − √qR (the DeWitt coefficient of π²: 1 in d = 2, ½ in d = 3)'),
        ('For s = ±1 these are the ADM constraints (recalled); d = 3 is not run, and every dimension is recalled.', "For s = ±1 these are the ADM constraints (recalled). In d = 3 the same bracket holds exactly, {H[N], H[M]} = εH_k[q^{kj}(N∂_jM − M∂_jN)] with ε = −s, on four random integer configurations per s ∈ {−1, 0, +1}, with the full functional derivatives (the Ricci terms included); with the d = 2 coefficient 1 in place of ½ the algebra does not close (cand121_hda_d3). The three members s = −1, 0, +1 are Teitelboim's Lorentzian and Euclidean algebras and Henneaux's zero-signature one (recalled); every other dimension is recalled.")]),
    'LNS-029': ('P0.3', [('Is there, for d > 1, a family in the sign ε with Euclidean, Carroll-type and Lorentzian members? Open; only the frozen 1+1 model is computed (LNS-014, LNS-014c), not his (48)–(50).',
                          "For d > 1 the family in the sign ε exists in the hypersurface deformation algebra itself: Teitelboim 1973 (ε = ±1, every d) and Henneaux 1979 (ε = 0), recalled; in d = 2 and d = 3 the Atlas computes it, {H[N], H[M]} = εH_k[q^{kj}(N∂_jM − M∂_jN)] with ε = −s for s = −1, 0, +1 (CAND-121, cand121_hda_d3). That the frozen model's Witt ⊗ A_ε is the 1+1 shadow of that family is a remark of ours; the frozen model is computed (LNS-014, LNS-014c), his (48)–(50) are not.")]),
    'LNS-047': ('P0.3', [('replace_all', 'Beyond 1+1, the family in the sign ε with Euclidean, Carroll-type and Lorentzian members exists in the hypersurface deformation algebra itself (P3): Teitelboim 1973 for ε = ±1 in every d and Henneaux 1979 for ε = 0, recalled, and computed in d = 2 and d = 3 by the Atlas (CAND-121, cand121_hda_d3); the frozen deformation algebra Witt ⊗ A_ε is its 1+1 shadow (LNS-029).')]),
    'LNS-014e': ('P0.3', [('Whether his deformation algebra has a family in the sign ε with Euclidean, Carroll-type and Lorentzian members for d > 1 stays open. Frozen 1+1 model only, not his (48)–(50); nothing is computed beyond it.',
                           'His deformation algebra has a family in the sign ε with Euclidean, Carroll-type and Lorentzian members for d > 1: Teitelboim 1973 (ε = ±1) and Henneaux 1979 (ε = 0), recalled, and computed by the Atlas in d = 2 and d = 3 (CAND-121, cand121_hda_d3). Frozen 1+1 model only here, not his (48)–(50).')]),
    'RIG-M19': ('P0.3', [('It is conserved for either sign of the Euler term (reversing the term only reverses B′; that sign is not run separately), so it cannot fix the sign; the world momentum does (E2). ↔ n = 1…4, exact, four random states for each n, with the sign of the equation.',
                          'It is conserved for either sign of the Euler term (run for both signs: six random rational states, exact, rig_m19_m52_euler), so it cannot fix the sign; the world momentum does (E2): it is conserved only with the right sign, and changes as 2R(ω × Iω) with the reversed one. ↔ n = 1…4, exact, four random states for each n, with the sign of the equation; both signs of the Euler term on six states.')]),
    'RIG-M52': ('P0.3', [('They differ whenever s₀ ≠ s₂; the example itself draws the size [0.6, 2, 1], which is not run here.', "They differ whenever s₀ ≠ s₂; at the example's own size (3/5, 2, 1) the two maps give different rates ω̇ at a generic state (exact) and the same flow only when s₀ = s₂, while a spin about a principal axis is stationary under both (rig_m19_m52_euler)."),
                          ('↔ The example’s inertia map, with its size replaced by [1/2, 2, 1], [1, 2, 1/2] and [3/4, 3/2, 2], against both formulas, to 1e-13.', '↔ The example’s inertia map, with its size replaced by [1/2, 2, 1], [1, 2, 1/2] and [3/4, 3/2, 2], against both formulas, to 1e-13; at its own size (3/5, 2, 1) exactly.')]),
    'GRV-011': ('P0.3', [('and with decay at infinity Φ_t = Φ_s (that last step is the standard argument, not run);', 'and with decay at infinity Φ_t = Φ_s (on polynomials of degree ≤ 6 the kernel of the Hessian map is the four affine functions, exact, grv011_hessian_affine; in general ∂_i∂_jψ = 0 makes ∇ψ constant and ψ affine, so decay, or boundedness, at infinity gives Φ_t = Φ_s);')]),
    'CPL-006b': ('P0.3', [('replace_all', 'A neutral field exists at n = 2: ∇ψ = mψγ₁ on the even (two real components) ψ of Cl(1,1), the 1+1 Majorana equation, has real plane waves exactly on E² = k² + m² (exact kernels at five on-shell and three off-shell points, m = 3); the form with γ₀ in place of γ₁ is tachyonic (its shell is E² = k² − m²); at n = 1 no element squares to −1 and the equation gives real exponentials only (cpl006b_majorana_cl11).')]),
    'ATY-003': ('P0.3', [('and two controls (E₄ = E_∞ asserted; the printed ranks asserted).', 'and two controls (E₄ = E_∞ asserted; the printed ranks asserted); an independent exterior-algebra route reproduces the pages 24, 18, 18, 10, 10, 8, 8, 8 and the (4, 4), with no page of dimension 14 (aty003_atiyah_segal_model). The printed ranks are as read on the scanned page; the print itself is not in the package.')]),
    'LNS-017e': ('P0.3', [('(exact at points, both ε, c of both signs; ε = 0 not run).', '(exact at points, both ε, c of both signs). Here ε is the square of the fifth generator; ε = 0 is not a case to run: a null fifth generator makes the five-dimensional metric degenerate, and a degenerate metric has no Levi-Civita connection, so no Einstein form is defined; the well-posed null case, a Lorentzian five-dimensional metric with a null Killing vector, is LNS-017g (open).')]),
    # --- P0.4 status, naming
    'ATY-019': ('P0.4', [("The numbers are checked in aty_matter_models.py; the reading of particles as manifolds is the paper's and is not checked.", "The numbers are computed in ATY-019b (aty_matter_models.py); this row is the paper's reading of them as particles, which is not checked: our reading of the paper on the Atlas.")]),
    'GOS-511b': ('P0.4', [("Witt's classification, recalled, not computed here. This is a reading, not proven yet in the Atlas.", "Witt's classification (1941; Conway and Sloane, Sphere Packings, Lattices and Groups, Ch. 16 §1 and Ch. 4 §8.3), recalled, not computed here: standard, not a reading of ours.")]),
    'LAB-505b': ('P0.4', [('replace_all', 'That a compact Spin(n+2) cannot contain the non-compact Spin⁺(1,3) ≅ SL(2,ℂ) is standard: a continuous homomorphism from a connected non-compact simple Lie group to a compact one is trivial, since its differential would be an injective map of the simple Lie algebra so(1,3), whose Killing form is indefinite, into a compact Lie algebra, whose Killing form is negative semidefinite (Knapp, Lie Groups Beyond an Introduction, the chapter on compact Lie groups; recalled, not computed here).')]),
    'PAG-034': ('P0.4', [("Pointer, source unread, recalled and not checked: by Gårding's theorem", "Standard, the source unread (Gårding, Acta Math. 85, 1951; Hörmander, The Analysis of Linear Partial Differential Operators II, Ch. XII), recalled and not checked: by Gårding's theorem")]),
    'FUR-619b': ('P0.4', [("Computed by family_test, a script not among the Atlas's checks: not yet proved here.", "Computed by family_test.py, a script of the author's package in checks/, with its recorded run (family_results.json equal to the shipped file).")]),
    'ATL-022c': ('P0.4', [('checked by enumeration for n ≤ 7, recalled at n = 8.', 'checked by enumeration for n ≤ 8 (cube_faces: the faces listed as vertex sets, 1120 of them at (8, 4), with the Euler relation at every n).')]),
    'LAB-018': ('P0.4', [('replace_all', "the clock is the Brown (Arf–Brown–Kervaire) invariant of the Z_{4} enhancement w of the dot product (bd·geo·1–3, bd·str·1; core·B1–B3): equally w(a) = x·x mod 4 for the 0/1 vector x of a in the lattice I_{p,q}, and the clock is the signature of I_{p,q} mod 8 (Brown’s theorem, Taylor, Thm 2.5; van der Blij for the characteristic vector 1…1; bd·mat·7, bd·alg·8, bd·xck·6). The invariants of an edge with p T-even and q T-odd Majorana modes depend on the clock only (bd·sol·2–5), and so do the groups A_k of Atiyah, Bott and Shapiro, whose ring the Atlas computes in ATY-026 (bd·str·2, bd·sol·25), and the Dyson class of the even part (bd·str·20, bd·xph·1–2). That w is a Pin⁻ structure on #ⁿℝP² with the clock its class in Ω₂^{Pin⁻} ≅ ℤ₈, that this ℤ₈ is Fidkowski and Kitaev's, and that A_* is KO^{−*}(point), are read, not computed: LAB-018b")]),
    'LAB-016': ('P0.4', [('Not treated, and open: matching Pin⁺ and Pin⁻ with the time reversals of square ±1 on fermions (recalled, not checked) and Pin⁺ bordism.', 'The matching of Pin⁺ and Pin⁻ with the time reversals of square ±1 on fermions, and Pin⁺ bordism, are standard (LAB-016b, read); what stays open is a check of the Pin⁺ side on the labels, which none builds.')]),
    'PAG-032': ('P0.4', [('Not treated, and open: matching Pin⁺ and Pin⁻ with the time reversals of square ±1 on fermions (recalled, not checked) and Pin⁺ bordism.', 'The matching of Pin⁺ and Pin⁻ with the time reversals of square ±1 on fermions, and Pin⁺ bordism, are standard (LAB-016b, read); what stays open is a check of the Pin⁺ side on the labels, which none builds.')]),
    'LAB-017': ('P0.4', [('append', '; two bilinear forms are in play: w refines the dot product a·b (w(a + b) = w(a) + w(b) + 2a·b), while the 𝔽₂-quadratic form Q = [e_a² = −1] has the commutation form |a||b| + a·b as its polar form; the first sees the graded algebra (the Koszul sign), the second the ungraded one (which blades commute), which is why Q alone fixes the clock only up to c ↔ 2 − c (LAB-019)')]),
    'ATY-033': ('P0.4', [('and the law fails without the parity term in w or with the commutation form in place of the dot product.', 'and the law fails without the parity term in w or with the commutation form |a||b| + a·b (the polar form of Q, which sees the ungraded algebra) in place of the dot product (the polar form of w, which sees the graded one).')]),
    'LAB-019': ('P0.4', [('for every n (Wood 1993, §5: Z_{4} forms classified by the Brown invariant)', 'for every n (Wood 1993, §5: among the non-singular Z_{4}-valued forms whose bilinear form is non-alternating, as the label forms are, rank and Brown invariant classify; the alternating ones, the hyperbolic plane among them, are a class apart)')]),
    'CAND-004': ('P0.4', [('Read the class of a cell as (type and number of simple summands of A, division algebra of its even part):', 'Read the class of a cell as the pair (type and number of simple summands of A, division algebra of its even part), a complete invariant of its graded Morita class and not the definition of that class (Wall 1964; Lam, the chapter on Clifford algebras; Deligne, Notes on spinors):')]),
    'LNC-006': ('P0.4', [('Both cells are canonical, and the value 2 on a radical class would make the sum 0: the clock of Cl(p,q,r) is forced, not a convention.', 'Both cells are canonical; with the standard definition of the Brown invariant (w = 0 on the radical) the clock of Cl(p,q,r) is that of Cl(p,q), and any other extension of w to the radical, the value 2 on a radical class, has Gauss sum 0 (CAND-091): the clock is forced relative to that definition.')]),
    'LNC-018': ('P0.4', [('This is forced, not a convention: the value 2 on a radical class would make the Gauss sum 0.', 'With the standard definition of the Brown invariant, w = 0 on the radical, this is forced: any other extension, the value 2 on a radical class, makes the Gauss sum 0 (CAND-091).')]),
    'LNC-055': ('P0.4', [('Both cells are canonical and give one phase, and the value 2 on a radical class would make the sum 0: the clock of a degenerate cell is forced, not a convention.', 'Both cells are canonical and give one phase; with the standard definition of the Brown invariant (w = 0 on the radical) the clock of a degenerate cell is that of its quotient, and any other extension of w to the radical, the value 2 on a radical class, makes the sum 0 (CAND-091): forced relative to that definition.')]),
    'LNC-107': ('P0.4', [('This is forced, not a convention: the value 2 on a radical class would make the sum 0 (bd·geo·5, bd·xck·3).', 'With the standard definition of the Brown invariant, w = 0 on the radical, this is forced: the value 2 on a radical class would make the sum 0 (bd·geo·5, bd·xck·3; CAND-091).')]),
    'LAB-036': ('P0.4', [('A finite Siegel–Weil formula on the labels.', "A finite Siegel–Weil-type identity on the labels (one class in the genus, a transitive orbit of the transvections by Witt's theorem for ℤ₄-forms; the Eisenstein-series side of Weil's n° 52 is a reading).")]),
    'LAB-039': ('P0.4', [('A finite Siegel–Weil formula on the labels in every genus.', "A finite Siegel–Weil-type identity on the labels in every genus (a transitive-orbit average, proved for every n and every genus; the name of Weil's n° 52 is carried over as a reading).")]),
    'LNC-076b': ('P0.4', [('the clock table at c = 0, …, 7, entry for entry;', 'the commutant list of the clock table, position by position (the ungraded symmetry algebra sees the position s only up to s ↔ 2 − s, Kitaev §3);')]),
    'LNS-122': ('P0.4', [('?is the edge (with nothing left, M = ±I, it is a band point: LNS-125).', 'is the edge; with nothing left it is a band point (LNS-125).'),   # (a run before 3.7.1 wrote the formula form)
                         ('below zero the wave turns (a band), above zero it runs away (a gap), at zero is the edge.', 'below zero the wave turns (a band), above zero it runs away (a gap), and at zero, with something left after the plain number, is the edge; with nothing left it is a band point (LNS-125).')]),
    'GRV-010': ('P0.4', [('the overall sign is read off the engine and agrees with the hand derivation.', 'the overall sign is read off the engine and agrees with the hand derivation; in this convention, (+,−,−,−) with the sphere-positive Riemann sign, de Sitter has R_ab = −Λη_ab, so the vacuum equation reads G − Λδ = 0, which is G + Λg = κT in the (−,+,+,+) convention.')]),
    'INP-019': ('P0.4', [('and for cells with n ≤ 8 they are isomorphic exactly when n ≡ 0 mod 4 and the cell is indefinite (checked exactly, bd·tor·7).', 'and for cells with n ≤ 10, n ≥ 1, they are isomorphic exactly when n ≡ 0 mod 4 and the cell is indefinite (checked exactly, bd·tor·7 for n ≤ 8, type_table_consequences C4 for n ≤ 10: the fixed-space dimensions differ unless n ≡ 0 mod 4, the trace forms ⟨xx̃⟩₀ and ⟨xx̄⟩₀ have different signatures on definite cells, and on indefinite cells with n ≡ 0 mod 4 the two anti-involutions have the same type and signature, hence are conjugate by Skolem–Noether, for q odd explicitly by e_i ↦ e_iI: a theorem for every n; at n = 0 both are the identity).')]),
    'LAB-035': ('P0.4', [('and up to ten generators it exists exactly then, Π_{i=0}^{n/2−2}(2^i + 1) of them in each length.', 'and up to ten generators it exists exactly then, Π_{i=0}^{n/2−2}(2^i + 1) of them in each length; and for every even n: with w(1…1) = 0 (true iff ω² = +1, which holds for p ≡ q mod 8) the ℤ₄-form descends to an 𝔽₂-quadratic form on 1^⊥/⟨1⟩, of dimension n − 2, with Arf invariant (p − q)/4 mod 2, and the codes are its maximal totally singular subspaces, which exist iff the form is of plus type and then number Π_{i=0}^{n/2−2}(2^i + 1) (Taylor, The Geometry of the Classical Groups, the chapter on orthogonal groups; for q = 0 the count of Type II codes, MacWilliams–Sloane Ch. 19; recalled; verified for n ≤ 8 by enumeration, lattice_euler_checks L5).')]),
    'YM-007c': ('P0.4', [('is not built: open.', 'is not built: open (such solutions exist in the literature as numerical shooting solutions, Bartnik and McKinnon 1988, so the object is known; a check at rational points is not).')]),
    'LNS-028c': ('P0.4', [('replace_all', 'The link of that (2,2) to hyperbolicity is ours: a reading, not a question.')]),
    'INP-053': ('P0.4', [('(Bateman and Cunningham for Maxwell, recalled, not read)', '(Bateman and Cunningham for Maxwell; Kosmann 1972 and Penrose–Rindler II §6.7 for the massless Dirac field with weight 3/2; recalled, not read)')]),
}

SYNC_KEYS = ('kind', 'ptype', 'stage', 'evidence', 'homeMath', 'homePhys', 'standardRef', 'cells', 'legacyFlags', 'depends')


def edit_row(r, ed):
    for k, v in ed.items():
        if k == 'evidence+':
            have = {(e['check'], e['script']) for e in r['evidence']}
            for e in v:
                if (e['check'], e['script']) not in have: r['evidence'].append(dict(e)); have.add((e['check'], e['script']))
        elif k == 'depends+':
            have = {(d['id'], d['rel']) for d in r['depends']}
            for d in v:
                if (d['id'], d['rel']) not in have: r['depends'].append(dict(d))
        elif k == 'flags':
            r['legacyFlags'] = list(v)
        else:
            r[k] = copy.deepcopy(v)


def apply_rows():
    rows, nl = load('content/rows.json')
    byid = {r['id']: r for r in rows}
    for rid, ed in ROW_EDITS.items():
        edit_row(byid[rid], ed)
    for rid, st in STAGES.items():
        byid[rid]['stage'] = st
    for nid, after, f, _text in NEW_ROWS:
        if nid in byid:
            if f['split'] and byid[nid].get('readingRefs') != byid[after]['readingRefs']: byid[nid]['readingRefs'] = byid[after]['readingRefs']
            for k, v in (('since', 'v3.7.1'), ('legacyLabel', None), ('legacyFlags', []), ('legacyKnown', False), ('legacyLines', 0)):
                if byid[nid].get(k) != v: byid[nid][k] = v
            continue
        base = byid[after]
        rec = copy.deepcopy(base)
        so = f['shownOn']
        top = max([s['order'] for x in rows for s in x['shownOn'] if s['page'] == so['page'] and s['section'] == so['section'] and s['order'] < 1000] + [0])
        rec.update({'id': nid, 'group': nid.split('-')[0], 'kind': f['kind'], 'stage': f['stage'], 'ptype': f['ptype'], 'notions': list(f['notions']), 'fields': list(f['fields']), 'cells': list(f['cells']),
                    'homePhys': f['homePhys'], 'homeMath': f['homeMath'], 'standardRef': f['standardRef'], 'evidence': copy.deepcopy(f.get('evidence', [])), 'depends': copy.deepcopy(f['depends']),
                    'links': [], 'lensTags': [], 'review': None, 'notesPersona': ['round 20 (release 3.7.1): ' + ('a split line of ' + after if f['split'] else 'a new row beside ' + after)],
                    'phenomena': list(f['phenomena']), 'theorems': [], 'readingRefs': base['readingRefs'] if f['split'] else 0, 'v16': [],   # a split line shares its first line's readings (registerModel readingsForRow)
                    'since': 'v3.7.1', 'legacyLabel': None, 'legacyFlags': [], 'legacyKnown': False, 'legacyLines': 0,
                    'splitFrom': after if f['split'] else None, 'labelFrom': after if f['split'] else None, 'visibleTo': ['phys', 'math'], 'tabV15': None, 'anchorV15': None,
                    'shownOn': [{'page': so['page'], 'section': so['section'], 'order': top + 1, 'role': so['role']}]})
        for k in ('inputKind', 'inputKindName'):
            if k in f: rec[k] = f[k]
            elif k in rec: del rec[k]
        rows.insert(rows.index(base) + 1, rec)
        byid[nid] = rec
    stage('content/rows.json', rows, nl)
    # the rows an overlay owns: the same fields in the overlay file (the merge rebuilds the base copy from it)
    edited = set(ROW_EDITS) | set(STAGES)
    for f in sorted(glob.glob(path('content/physics/rows.p*.json'))) + sorted(glob.glob(path('content/chains/*/rows.json'))) + [path('content/explore/rows.json')]:
        rel = os.path.relpath(f, ROOT)
        ov, nlo = load(rel); changed = False
        for r in ov:
            if r.get('id') in edited:
                src = byid[r['id']]
                for k in SYNC_KEYS:
                    if k in src and r.get(k) != src[k]: r[k] = copy.deepcopy(src[k]); changed = True
        if changed: stage(rel, ov, nlo)
    # the promoted rows of the review (content/story/review_rows.json): the labels of a `more` entry, or of the main entry (its id through pending.json)
    rr, nlr = load('content/story/review_rows.json')
    pend = {p['id']: p['locator'] for p in json.load(open(path('content/story/pending.json'), encoding='utf-8')) if 'id' in p}
    changed = False
    def sync_labels(lb, src):
        nonlocal changed
        for k in ('kind', 'ptype', 'stage', 'evidence', 'legacyFlags', 'standardRef', 'homeMath', 'homePhys', 'cells'):
            if k not in src: continue
            if k in ('standardRef', 'homeMath', 'homePhys') and not src[k]: continue
            if k not in lb and k not in ('standardRef', 'homeMath', 'homePhys'): continue
            if lb.get(k) != src[k]: lb[k] = copy.deepcopy(src[k]); changed = True
    for loc, entry in rr.items():
        for x in entry.get('more', []):
            if x['id'] in edited: sync_labels(x['labels'], byid[x['id']])
    for rid in edited:
        loc = pend.get(rid)
        if loc and loc in rr and 'labels' in rr[loc]: sync_labels(rr[loc]['labels'], byid[rid])
    if changed: stage('content/story/review_rows.json', rr, nlr)


def research_text(texts, row):
    for t in texts:
        if t['row'] == row and t['level'] == 'research' and t['register'] == 'full' and t.get('lens') is None and t.get('mode') == 'both' and t.get('chain') is None:
            return t
    return None


def apply_edits(rid, body):
    """the edits of TEXT_EDITS[rid] on a body; returns (body, touched)"""
    pkg, edits = TEXT_EDITS[rid]; touched = False
    for e in edits:
        if e[0] == 'append':
            if e[1].strip() in body: continue
            body = body.rstrip() + e[1]; touched = True
        elif e[0] == 'replace_all':
            if body == e[1]: continue
            body = e[1]; touched = True
        else:
            old, new = e
            opt = old.startswith('?'); old = old[1:] if opt else old
            if new in body: continue                      # applied already (new may contain old)
            elif old in body: body = body.replace(old, new, 1); touched = True
            elif opt: continue                             # an optional edit (a form an earlier run wrote)
            else: raise AssertionError(f'{rid}: the phrase to replace is not there: {old[:90]}')
    return body, touched


def overlay_text_rows():
    """the rows whose research text an overlay owns: content/chains/<owner>/texts.json (the round-14 rows), content/physics/texts.p*.json (the
    matrix lines), content/story/review_rows.json (the promoted rows and their further rows). Their texts are edited in the overlay file only: the
    merge writes content/texts.json from it and records the write in its book, so that the next merge restores the base and applies it again."""
    own = {}
    for f in sorted(glob.glob(path('content/chains/*/texts.json'))):
        for t in json.load(open(f, encoding='utf-8')):
            if t['level'] == 'research': own[t['row']] = os.path.relpath(f, ROOT)
    for f in sorted(glob.glob(path('content/physics/texts.p*.json'))):
        for t in json.load(open(f, encoding='utf-8')):
            if t['level'] == 'research': own[t['row']] = os.path.relpath(f, ROOT)
    rr = json.load(open(path('content/story/review_rows.json'), encoding='utf-8'))
    pend = {p['id']: p['locator'] for p in json.load(open(path('content/story/pending.json'), encoding='utf-8')) if 'id' in p}
    for loc, entry in rr.items():
        for x in entry.get('more', []): own[x['id']] = 'content/story/review_rows.json'
    for rid, loc in pend.items():
        if loc in rr and 'text' in rr[loc]: own[rid] = 'content/story/review_rows.json'
    return own


def apply_texts():
    texts, nl = load('content/texts.json')
    own = overlay_text_rows()
    for rid in TEXT_EDITS:
        if rid in own: continue   # edited in its overlay file below
        t = research_text(texts, rid); assert t, f'no research text for {rid}'
        body, touched = apply_edits(rid, t['body'])
        if touched:
            t['body'] = body; t['status'] = 'draft'; t['source'] = SRC[TEXT_EDITS[rid][0]]
    for nid, after, f, text in NEW_ROWS:
        if research_text(texts, nid): continue
        base = research_text(texts, after); assert base, f'no research text for {after}'
        texts.insert(texts.index(base) + 1, {'row': nid, 'lang': 'en', 'mode': 'both', 'level': 'research', 'lens': None, 'register': 'full', 'body': text, 'status': 'draft', 'source': 'round20:P0.4'})
    # a merged copy of an overlay text that the book does not list as the merge's own is the trace of an edit made in content/texts.json before the
    # merge (the base would keep it and the base build would see a text of an unknown row): it leaves, and the merge writes it again from the overlay
    book = json.load(open(path('content/story/merged.json'), encoding='utf-8'))
    keep = []
    for t in texts:
        k = f"{t['row']}|{t.get('lang', 'en')}|{t['level']}|{t.get('mode', 'both')}|{t.get('lens') or ''}|{t.get('register', 'full')}" + (f"|{t['chain']}" if t.get('chain') is not None else '')
        if t['row'] in own and own[t['row']].startswith('content/chains/') and t['level'] == 'research' and t.get('chain') is None and k not in book.get('texts', {}):
            said.append(f'dropped the merged copy of {k} (not in the book: the merge writes it again)'); continue
        keep.append(t)
    stage('content/texts.json', keep, nl)
    for rid in TEXT_EDITS:
        if rid not in own or own[rid] == 'content/story/review_rows.json': continue
        rel = own[rid]; ov, nlo = load(rel); changed = False
        for t in ov:
            if t['row'] == rid and t['level'] == 'research' and t.get('register', 'full') == 'full' and t.get('lens') is None and t.get('chain') is None:
                body, touched = apply_edits(rid, t['body'])
                if touched:
                    t['body'] = body; t['status'] = 'draft'; changed = True
                    if not rel.startswith('content/physics/'): t['source'] = SRC[TEXT_EDITS[rid][0]]   # a physics overlay text keeps its source "physics:P<k>"
        if changed: stage(rel, ov, nlo)
    rr, nlr = load('content/story/review_rows.json')
    pend = {p['id']: p['locator'] for p in json.load(open(path('content/story/pending.json'), encoding='utf-8')) if 'id' in p}
    changed = False
    def edit_rr(text_rec, rid):
        nonlocal changed
        body, touched = apply_edits(rid, text_rec['body'])
        if touched: text_rec['body'] = body; text_rec['status'] = 'draft'; text_rec['source'] = SRC[TEXT_EDITS[rid][0]]; changed = True
    for loc, entry in rr.items():
        for x in entry.get('more', []):
            if x['id'] in TEXT_EDITS: edit_rr(x['text'], x['id'])
    for rid in TEXT_EDITS:
        loc = pend.get(rid)
        if loc and loc in rr and 'text' in rr[loc]: edit_rr(rr[loc]['text'], rid)
    if changed: stage('content/story/review_rows.json', rr, nlr)


# ======================================================================================================================= 6. the depends overlay
DEPENDS = [
    # (row, id, rel, op, why): without op the edge { id, rel } is added to the row; drop removes it (tools/merge_story.mjs step 0)
    # (the edge GEN-002 derives GEN-001 that A62 added is not dropped here: the A62 entry itself is rejected with this round as the item that undoes
    # it, D83 — reject_a62() below)
    ('GEN-031', 'GEN-017', 'derives', None, "ABS's two-step maps are a finer statement whose fourfold composite is the eight-block map: derives, not equiv"),
    ('GEN-031', 'GEN-017', 'equiv', 'drop', 'replaced by derives'),
    ('GEN-028', 'GEN-023', 'equiv', 'drop', 'idempotent lifting and the stages of chains are different statements: the link is order'),
    ('GEN-030', 'GEN-026', 'derives', None, 'the algebraic direct limit rests on the dimension group: derives, not equiv'),
    ('GEN-030', 'GEN-026', 'equiv', 'drop', 'replaced by derives'),
    ('ATL-011', 'CAND-078', 'derives', None, 'CAND-078 is a computation, not an input'),
    ('ATL-011', 'CAND-078', 'uses-input', 'drop', 'replaced by derives'),
    ('GEN-022', 'GEN-018', 'derives', None, 'the null cells rest on the n + 8 computation of the non-degenerate cells: derives, not equiv'),
    ('GEN-022', 'GEN-018', 'equiv', 'drop', 'replaced by derives'),
    ('ATY-016', 'GOS-007', 'instance', 'drop', 'the signature mod 8 of a 4-manifold is not an instance of the Gosset row: the link is order'),
    ('ATY-032', 'CAND-140', 'derives', 'drop', 'McKay for 2T and 2D is not derived from the 2I computation: order'),
    ('LNC-135', 'LNC-026', 'equiv', 'drop', 'an unpaired null generating the radical and the mother-algebra embedding are not equivalent: order'),
    ('LNC-054', 'LNC-052', 'derives', 'drop', 'a citation (Wang, Ladkani) does not derive from an Euler-form computation: order'),
    ('LNB-055c', 'LNB-023', 'derives', None, 'a reading derives from the computation it reads; it is not equivalent to it'),
    ('LNB-055c', 'LNB-023', 'equiv', 'drop', 'replaced by derives'),
    ('LNB-024', 'LNB-175', 'derives', 'drop', 'the computation does not derive from the reading: the reading derives from it'),
    ('LNB-024b', 'LNB-175', 'derives', 'drop', 'as LNB-024'),
    ('LNB-024c', 'LNB-175', 'derives', 'drop', 'as LNB-024'),
    ('LNB-175', 'LNB-024', 'derives', None, 'the reading (a ground state as the first N set bits) rests on the computation'),
    ('LNB-056c', 'LNB-017', 'derives', None, "the tie to the triangulation note is derived from the E7 paper's lemma, not equivalent to it"),
    ('LNB-056c', 'LNB-017', 'equiv', 'drop', 'replaced by derives'),
    ('CPL-010', 'CPL-001', 'derives', 'drop', 'a reading (the picture on the cube) does not derive from a lemma: order'),
    ('LNS-012', 'MAP-003', 'derives', 'drop', 'the hyperbolicity criterion is independent (T18), cross-checked against the wave-type table: order'),
    ('ATY-005', 'ATY-004', 'derives', 'drop', "the paper's covariant shift is not derived from a fixed shift vector of the mass term: it contrasts with it"),
    ('ATY-013', 'ATY-015', 'uses-input', None, "an input row is used, not derived: the holonomy computation uses the paper's statements"),
    ('ATY-012', 'ATY-015', 'uses-input', None, 'as ATY-013'),
    ('ATY-015', 'ATY-013', 'derives', 'drop', 'reversed into uses-input'),
    ('ATY-015', 'ATY-012', 'derives', 'drop', 'reversed into uses-input'),
    ('GRV-012', 'CAND-010', 'derives', 'drop', 'the Kerr–Schild class and the areal chart are independent charts: order'),
    ('LNS-122', 'LNS-125', 'contradicts', 'drop', 'the phrase "at zero is the edge" is corrected; the two rows agree'),
    ('LNS-122', 'LNS-125', 'equiv', None, 'the band condition and its edge, said twice'),
    ('ATY-041', 'ATY-011', 'instance', 'drop', 'a computation is not an instance of a reading; ATY-011 derives from ATY-041 (the cycle broken)'),
    ('LAB-039', 'LAB-035', 'derives', 'drop', 'a theorem for every n does not derive from its finite cases (the cycle broken); LAB-035 is an instance of it'),
    ('LAB-039', 'LAB-036', 'derives', 'drop', 'as LAB-035'),
    ('LAB-035', 'LAB-039', 'instance', None, 'the count formula for n <= 10 is an instance of the theorem for every n'),
    ('ATY-019', 'ATY-019b', 'derives', None, 'the reading rests on the computed numbers (split, round 20)'),
]


def write_depends():
    entries = []
    for row, id_, r, op, why in DEPENDS:
        e = {'row': row, 'id': id_, 'rel': r, 'from': 'round20', 'verdict': 'accept', 'why': why}
        if op: e['op'] = op
        entries.append(e)
    data = {'_about': "round 20 (release 3.7.1): the labelling overlay of depends that applies the two referee reviews of 21 Oct 2026 (docs/round20/review, sections B and C) and the split lines of the release: the chain link words corrected, the three directed cycles broken, two edges turned into uses-input; applied by tools/merge_story.mjs at step 0 after depends_a62.json (the files are read in sorted order). An entry without op adds { id, rel } to the row's depends; op drop removes it.", 'edges': entries}
    stage('content/story/depends_round20.json', data, True)
    reject_a62()


# the entries of A62 that an approved edit of this round undoes (D83): (row, id, rel, the why of the rejection)
A62_REJECTED = [
    ('GEN-002', 'GEN-001', 'derives', "GEN-002: the approved edit of round 20 (the math referee's section B, D96) leaves this add out: Cl(0,0,1) is not derived from Cl(0,0), the link of rule.ideas.genesis is order"),
]


def reject_a62():
    """An entry of the labelling overlay A62 that an approved edit undoes is rejected with the item that undoes it (D83, as round 19 did for
    INP-045 and LNB-036b): verdict reject, the why names the edit, the judge's why is kept as judgeWhy. The file is in the format of
    tools/story/split_edges.mjs formatOverlay (one entry per line): the entry's line alone is rewritten, in that format."""
    rel = 'content/story/depends_a62.json'
    raw = pending[rel] if rel in pending else open(path(rel), encoding='utf-8').read()
    lines = raw.split('\n')
    changed = False
    for row, id_, r, why in A62_REJECTED:
        for i, line in enumerate(lines):
            if not line.startswith('  {'): continue
            e = json.loads(line.rstrip(',').strip())
            if not (e['row'] == row and e['id'] == id_ and e['rel'] == r and not e.get('op')): continue
            if e.get('verdict') == 'reject': break
            e['verdict'] = 'reject'; e['judgeWhy'] = e['why']; e['why'] = why
            lines[i] = '  {' + ', '.join(f'{json.dumps(k)}: {json.dumps(e[k], ensure_ascii=False)}' for k in e) + '}' + (',' if line.rstrip().endswith(',') else '')
            changed = True
            break
    if changed:
        pending[rel] = '\n'.join(lines)
        if rel not in TOUCHED: TOUCHED.append(rel)


# ======================================================================================================================= 7. the chain files
# chain id -> [(link index (1-based), the new link)]: the link the tables give the position once the edges of DEPENDS hold (D83: what
# tools/story/extract_chains.mjs chainRecord gives; `node docs/round20/rejoin.mjs --links` lists the chains whose links or shape differ from it), so a
# position whose referee-settled edge is dropped takes the edge the tables keep (GEN-028 and LNC-135 on an earlier position, CPL-010 an instance of
# PAG-023, LNB-024 the computation LNB-175 rests on) and `order` only where the tables hold no edge
CHAIN_LINKS = {
    'rule.ideas.genesis': [(1, {'rel': 'order'})],
    'rule.ideas.blocks': [(3, {'rel': 'derives'})],
    'rule.ideas.null': [(3, {'rel': 'derives', 'from': 'GEN-021'})],
    'cells.cards.null': [(4, {'rel': 'derives', 'from': 'GEN-021'})],
    'rule.ideas.limit': [(5, {'rel': 'derives'})],
    'cells.cards.limit': [(5, {'rel': 'derives'})],
    'cells.cards.split-four': [(1, {'rel': 'derives'})],
    'clock.clock.k-theory': [(3, {'rel': 'derives'})],
    'shapes.sh-gosset.del-pezzo': [(2, {'rel': 'order'})],
    'steps-groups.ln-groups.mckay': [(2, {'rel': 'order'})],
    'steps-category.cat-twozeros.partner': [(4, {'rel': 'derives', 'dir': 'back', 'from': 'LNC-024'})],
    'steps-category.cat-bottom.forms': [(3, {'rel': 'order'})],
    'steps-baez.bz-kepler.fock': [(4, {'rel': 'derives', 'from': 'LNB-023'})],
    'steps-baez.bz-periodic.madelung': [(4, {'rel': 'derives', 'dir': 'back', 'from': 'LNB-175'})],
    'steps-baez.bz-ring.paper': [(6, {'rel': 'derives', 'from': 'LNB-017'})],
    'light.views.cube': [(2, {'rel': 'instance', 'from': 'PAG-023'})],
    'steps-coupling.eq-coupling.cube': [(1, {'rel': 'order'})],
    'light.ladders.hyperbolic': [(1, {'rel': 'order'})],
    'steps-coupling.eq-coupling.shift-waves': [(1, {'rel': 'contrasts', 'note': "the paper's covariant shift of the whole operator, exp(−τ𝐃), against a fixed shift vector of the mass term alone, which is frame bound"})],
    'shifted.sv-3.shift': [(1, {'rel': 'contrasts', 'note': "the paper's covariant shift of the whole operator, exp(−τ𝐃), against a fixed shift vector of the mass term alone, which is frame bound"}), (4, {'rel': 'derives', 'dir': 'back'})],
    'steps-ym.ym-checks.skyrme': [(4, {'rel': 'uses-input', 'dir': 'back', 'from': 'ATY-013'})],
    'steps-grav2.eq-grav2.form': [(3, {'rel': 'order'})],
}
# new positions: chain id -> (after row, new row, the link into the new position, the link out of it (None: it is last))
# (none at 3.7.1: a storied chain has a span for every position (V10, C2), and the storyteller's words for a new position are not written here;
# the split lines LAB-018b and ATY-019b are placed beside their first lines and told by no chain, as the 71 split lines of 3.7.0 are)
CHAIN_INSERTS = {}
# positions a run of this script before 3.7.1 inserted and that are taken out again: chain id -> (row, the links as they stand without it)
CHAIN_REMOVALS = {
    'clock.clock.brown': ('LAB-018b', [{'rel': 'derives'}, {'rel': 'derives'}, {'rel': 'instance', 'from': 'LAB-018'}]),
    'shapes.sh-gosset.del-pezzo': ('ATY-019b', [{'rel': 'order'}, {'rel': 'order'}, {'rel': 'order'}, {'rel': 'derives', 'from': 'ATY-016'}]),
}


def apply_chains():
    own = {}
    files = {}
    for f in sorted(glob.glob(path('content/chains/*/chains.json'))):
        rel = os.path.relpath(f, ROOT)
        data, nl = load(rel); files[rel] = (data, nl)
        for c in data: own[c['id']] = (rel, c)
    touched = set()
    for cid, edits in CHAIN_LINKS.items():
        rel, c = own[cid]
        for i, link in edits:
            if c['links'][i - 1] != link: c['links'][i - 1] = dict(link); touched.add(rel)
    for cid, (row, links) in CHAIN_REMOVALS.items():
        rel, c = own[cid]
        if row in c['rows']:
            c['rows'].remove(row); c['links'] = [dict(l) for l in links]; touched.add(rel)
        if c.get('extracted') is not None:
            deps = c['extracted'].get('departures', [])
            keep = [d for d in deps if not d.startswith('round 20: the link words') or 'placed after' not in d]
            if keep != deps: c['extracted']['departures'] = keep; touched.add(rel)
    for cid, (after, new, link, relink) in CHAIN_INSERTS.items():
        rel, c = own[cid]
        if new in c['rows']: continue
        i = c['rows'].index(after)
        c['rows'].insert(i + 1, new)
        c['links'].insert(i, dict(link))
        if relink is not None and i + 1 < len(c['links']): c['links'][i + 1] = dict(relink)
        touched.add(rel)
    # the shape (V6): cycle when a cycle edge joins two positions; a ladder stays a ladder (the rows decide it); else fork when a link has from, else line
    rows_by_id = {r['id']: r for r in load('content/rows.json')[0]}
    for cid in list(CHAIN_LINKS) + list(CHAIN_INSERTS) + list(CHAIN_REMOVALS):
        rel, c = own[cid]
        S = set(c['rows'])
        if any(d['rel'] == 'cycle' and d['id'] in S for rid in c['rows'] for d in rows_by_id.get(rid, {}).get('depends', [])): want = 'cycle'
        elif c['shape'] == 'ladder': want = 'ladder'
        else: want = 'fork' if any(l.get('from') for l in c['links']) else 'line'
        if c['shape'] != want: c['shape'] = want; touched.add(rel)
        if c.get('extracted') is not None:
            deps = c['extracted'].setdefault('departures', [])
            note = "round 20: the link words of the referees' section B applied"
            if cid in CHAIN_LINKS and note not in deps: deps.append(note); touched.add(rel)
    for rel in touched:
        data, nl = files[rel]
        stage(rel, data, nl)


def move_aty064():
    """ATY-064 leaves the chains overlay (tools/merge_chains.mjs V9 keeps a round-14 statement row a reading or a question without evidence):
    its record and its research text stay in the base tables, the overlay files drop them, and the book of the story merge no longer lists the row
    and its research text as the merge's own (else the next merge would drop the row). Its chain, shifted.sv-open.numbers, is retitled."""
    rid = 'ATY-064'
    ov, nl = load('content/chains/shifted/rows.json')
    if any(r['id'] == rid for r in ov): stage('content/chains/shifted/rows.json', [r for r in ov if r['id'] != rid], nl)
    tx, nlt = load('content/chains/shifted/texts.json')
    if any(t['row'] == rid for t in tx): stage('content/chains/shifted/texts.json', [t for t in tx if t['row'] != rid], nlt)
    rows, nlr = load('content/rows.json')
    assert any(r['id'] == rid for r in rows), 'ATY-064 is not in content/rows.json (run the merge first)'
    # a base row has its home on a base page (the migration test builds the base tables without the overlay): steps/grav2 · eq-grav2, as ATY-052 and
    # ATY-053; its entry on shifted (sv-open, 3211) is added by the overlay's layout, like INP-049's, and so are the entries of INP-095 .. INP-097
    r64 = next(r for r in rows if r['id'] == rid)
    base_home = [so for so in r64['shownOn'] if so['page'] != 'shifted']
    if not base_home:
        top = max([so['order'] for x in rows for so in x['shownOn'] if so['page'] == 'steps/grav2' and so['section'] == 'eq-grav2' and so['order'] < 1500] + [1000])
        r64['shownOn'] = [{'page': 'steps/grav2', 'section': 'eq-grav2', 'order': top + 1, 'role': 'detail'}]
        r64['source'] = 'round20:shifted-view'
        stage('content/rows.json', rows, nlr)
    pg, nlp = load('content/chains/shifted/page.json')
    lay = pg['layout']; have = {(l['row'], l['page']) for l in lay}; added = False
    for row, order, role in ((rid, 3211, 'result'), ('INP-095', 3212, 'result'), ('INP-096', 3213, 'result'), ('INP-097', 3214, 'result')):
        if (row, 'shifted') not in have: lay.append({'row': row, 'page': 'shifted', 'section': 'sv-open', 'order': order, 'role': role, 'add': True}); added = True
    if added: stage('content/chains/shifted/page.json', pg, nlp)
    texts, nlx = load('content/texts.json')
    assert research_text(texts, rid), 'ATY-064 has no research text in content/texts.json'
    book, nlb = load('content/story/merged.json')
    changed = False
    if rid in book.get('rows', []): book['rows'] = [x for x in book['rows'] if x != rid]; changed = True
    k = f'{rid}|en|research|both||full'
    if k in book.get('texts', {}): del book['texts'][k]; changed = True
    if changed: stage('content/story/merged.json', book, nlb)
    ch, nlc = load('content/chains/shifted/chains.json')
    for c in ch:
        if c['id'] == 'shifted.sv-open.numbers':
            changed = False
            old_t, new_t = "The paper’s numbers, not computed here", "The paper’s numbers, from their inputs"
            if c['title'].get('phys') == old_t:
                c['title'] = {'phys': new_t, 'math': 'The magnitudes (2.8) to (5.4), from their inputs', 'learner': 'The paper’s big numbers, from their inputs'}
                deps = c['extracted'].get('departures', [])
                c['extracted']['departures'] = [d.replace(f'title "{old_t}"', f'title "{new_t}"') for d in deps]; changed = True
            # the three inputs told after ATY-064, each a position the computation rests on by uses-input (the page tells every row it places)
            if c['rows'] == ['ATY-055', rid]:
                c['rows'] = ['ATY-055', rid, 'INP-095', 'INP-096', 'INP-097']
                c['links'] = [{'rel': 'derives'}, {'rel': 'uses-input', 'dir': 'back'}, {'rel': 'uses-input', 'dir': 'back', 'from': rid}, {'rel': 'uses-input', 'dir': 'back', 'from': rid}]
                c['shape'] = 'fork'
                c['extracted'].setdefault('departures', []).append('INP-095, INP-096, INP-097 added (round 20: the inputs of ATY-064)'); changed = True
            if changed: stage('content/chains/shifted/chains.json', ch, nlc)


def withdraw_learner():
    """D82: a learner text, span or plain line that tools/check_learner_texts.mjs refuses against the corrected research text of its row is withdrawn
    until its words are written (the row is then shown at research level only; a chain with a withdrawn span is told at learner level as the list
    of its rows, D54). The checker is run; every learner record of a refused row, and every span of a chain with a refused span or a refused
    connective, is moved from content/texts_learner*.json and content/chains/learner/*.json to docs/round20/withdrawn_learner.json; repeated
    until the checker passes."""
    import re
    store = os.path.join(HERE, 'withdrawn_learner.json')
    kept = json.load(open(store, encoding='utf-8')) if os.path.exists(store) else []
    seen = {(x['row'], x['level'], x.get('lens'), x.get('register'), x.get('chain'), x.get('span'), x['_file']) for x in kept}
    for _round in range(6):
        r = subprocess.run(['node', 'tools/check_learner_texts.mjs'], cwd=ROOT, capture_output=True, text=True, env={**os.environ, 'NODE_PATH': os.environ.get('NODE_PATH', '/opt/npm-tools/node_modules')})
        if r.returncode == 0: said.append('check_learner_texts: PASS'); return
        rows, chains = set(), set()
        for line in r.stdout.split('\n'):
            m = re.match(r'^([RC]\d+) ([A-Z]+-[A-Za-z0-9]+)(?:: ([a-z0-9-]+(?:\.[a-z0-9-]+)+): span (\d+))?', line)
            if not m: continue
            if m.group(3): chains.add(m.group(3))
            else: rows.add(m.group(2))
        if not rows and not chains: raise AssertionError('check_learner_texts fails without a parsable line:\n' + r.stdout[-3000:])
        files = sorted(glob.glob(path('content/texts_learner*.json'))) + sorted(glob.glob(path('content/chains/learner/*.json')))
        # every span of a chain that holds a refused row's span goes too (C2: a chain with one span has them all)
        for f in files:
            for x in json.load(open(f, encoding='utf-8')):
                if x.get('register') == 'span' and x['row'] in rows: chains.add(x['chain'])
        moved = 0
        for f in files:
            rel = os.path.relpath(f, ROOT); lst, nl = load(rel); keep = []
            for x in lst:
                drop = (x['row'] in rows and x.get('level') == 'learner') or (x.get('register') == 'span' and x.get('chain') in chains)
                if drop:
                    key = (x['row'], x['level'], x.get('lens'), x.get('register'), x.get('chain'), x.get('span'), rel)
                    if key not in seen: kept.append({**x, '_file': rel, '_withdrawn': 'round 20 (release 3.7.1), D82'}); seen.add(key)
                    moved += 1
                else: keep.append(x)
            if len(keep) != len(lst): stage(rel, keep, nl)
        flush()
        json.dump(kept, open(store, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        said.append(f'withdrew {moved} learner record(s): rows {sorted(rows)}; chains {sorted(chains)}')
    raise AssertionError('check_learner_texts still fails after six rounds of withdrawals')


LNS122_LEARNER = {'row': 'LNS-122', 'lang': 'en', 'mode': 'both', 'level': 'learner', 'lens': None, 'register': 'full',
                  'body': 'For each energy the browser multiplies the pieces of one step of the row and squares what is left after the plain number: below zero the wave turns (a band), above zero it runs away (a gap), and at zero, with something left after the plain number, is the edge; with nothing left it is a band point (LNS-125).',
                  'status': 'draft', 'source': 'storyteller@2026-10-21', 'termsUsed': [], 'keptNumbers': []}


def learner_lns122():
    """LNS-122 is a chapter learner line (A51: its v15 words are its learner text). Its research text changed (the referee's naming fix), so, as
    for the lines round 19 corrected, a learner text is written for the new words (content/chains/learner/steps-schuller.json, the storyteller's
    file) and its v15 words leave the story overlay (content/story/texts.json)."""
    f = 'content/chains/learner/steps-schuller.json'
    lst, nl = load(f)
    if not any(x['row'] == 'LNS-122' and x['level'] == 'learner' and x.get('register', 'full') == 'full' for x in lst):
        lst.append(dict(LNS122_LEARNER)); stage(f, lst, nl)
    ov, nlo = load('content/story/texts.json')
    keep = [t for t in ov if not (t['row'] == 'LNS-122' and t['level'] == 'learner')]
    if len(keep) != len(ov): stage('content/story/texts.json', keep, nlo)
    # the merged copy of those v15 words (the merge's own, listed in the book with no original) leaves content/texts.json now, as the next merge
    # would drop it: the checker (R2) reads content/texts.json before the merge runs
    texts, nlx = load('content/texts.json')
    keep = [t for t in texts if not (t['row'] == 'LNS-122' and t['level'] == 'learner' and t['status'] == 'human')]
    if len(keep) != len(texts):
        book, nlb = load('content/story/merged.json')
        k = 'LNS-122|en|learner|both||full'
        assert k in book.get('texts', {}) and not book['texts'][k].get('orig'), 'LNS-122: its human learner text is not the story merge\'s own'
        del book['texts'][k]; stage('content/story/merged.json', book, nlb)
        stage('content/texts.json', keep, nlx)


def apply_theorems():
    th, nl = load('content/theorems.json')
    for t in th:
        if t['id'] == 'T8':
            old, new = 'tilted of type D₄, 11 indecomposables, recalled', 'tilted of type D₄ (not separating), 11 indecomposables, recalled'
            if old in (t.get('statement') or ''): t['statement'] = t['statement'].replace(old, new, 1)
    stage('content/theorems.json', th, nl)


def main():
    if DRY: said.append('dry run: nothing is written')
    copy_scripts()
    runs = run_scripts() if not DRY else {}
    register_checks(runs)
    apply_rows()
    apply_texts()
    write_depends()
    apply_chains()
    move_aty064()
    learner_lns122()
    apply_theorems()
    flush()
    if not DRY: withdraw_learner()
    for s in said: print(s)
    for rel in TOUCHED:
        if os.path.exists(path(rel)):
            print('sha256', hashlib.sha256(open(path(rel), 'rb').read()).hexdigest()[:16], rel)


if __name__ == '__main__':
    main()
