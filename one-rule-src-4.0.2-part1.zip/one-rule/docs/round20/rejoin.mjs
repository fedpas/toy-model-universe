#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// docs/round20/rejoin.mjs — recomputes the joins of every chain of content/chains/*/chains.json (a derived field, D83) on the tables as the
// merge will read them: content/rows.json with the labelling overlays of depends applied (content/story/depends_*.json, sorted, accepted
// entries only, the ops of tools/merge_story.mjs step 0). Rewrites a file only where a join changed, in the owners' format.
// Usage: node docs/round20/rejoin.mjs [--check]     (--check: print the differences, write nothing)
//        node docs/round20/rejoin.mjs --links        (list the chains whose links or shape are not what the tables give their positions, D83;
//                                                     nothing is written: a link may carry a note, and a storied chain's spans read its words)
//        node docs/round20/rejoin.mjs --relink <chain id> …   (rewrite the links and the shape of these chains to what the tables give, then the joins:
//                                                     for a chain that is not storied and whose links carry no note, e.g. a new chain of a way, 3.8.0)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeTables, joinsOf, chainRecord, fmtSeq, formatChains } from '../../tools/story/extract_chains.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const C = path.join(ROOT, 'content'), S = path.join(C, 'story');
const J = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const rows = J(path.join(C, 'rows.json')).map(r => ({ ...r, depends: (r.depends || []).map(d => ({ ...d })) }));
const byId = new Map(rows.map(r => [r.id, r]));
const has = (r, id, rel) => r.depends.some(d => d.id === id && d.rel === rel);
for (const n of fs.readdirSync(S).filter(x => /^depends_[a-z0-9]+\.json$/.test(x)).sort()) {
  for (const e of J(path.join(S, n)).edges || []) {
    if (!e || e.verdict == null || e.verdict === 'reject') continue;
    const r = byId.get(e.row), t = byId.get(e.id); if (!r || !t) continue;
    let op = e.op || 'add', rel = e.rel;
    if (e.verdict === 'turn') op = 'add-turned'; else if (e.verdict && typeof e.verdict === 'object') rel = e.verdict.rel;
    if (op === 'add') { if (!has(r, e.id, rel)) r.depends.push({ id: e.id, rel }); }
    else if (op === 'add-turned') { if (!has(t, r.id, rel)) t.depends.push({ id: r.id, rel }); }
    else if (op === 'drop') r.depends = r.depends.filter(d => !(d.id === e.id && d.rel === rel));
    else if (op === 'set-cycle') r.depends = r.depends.map(d => (d.id === e.id && d.rel === rel ? { id: e.id, rel: 'cycle' } : d));
    else if (op === 'turn') { r.depends = r.depends.filter(d => !(d.id === e.id && d.rel === rel)); if (!has(t, r.id, rel)) t.depends.push({ id: r.id, rel }); }
  }
}
const T = makeTables({ rows, pages: J(path.join(C, 'pages.json')), runs: J(path.join(C, 'check_runs.json')), status: J(path.join(C, 'derived', 'status.json')) });
const files = fs.readdirSync(path.join(C, 'chains')).filter(d => fs.existsSync(path.join(C, 'chains', d, 'chains.json'))).sort().map(d => path.join(C, 'chains', d, 'chains.json'));
const all = files.flatMap(f => J(f).map(c => ({ c, f })));
if (process.argv.includes('--relink')) {
  const ids = process.argv.slice(process.argv.indexOf('--relink') + 1).filter(a => !a.startsWith('--'));
  const touched = new Set(); let n = 0;
  for (const { c, f } of all) {
    if (!ids.includes(c.id)) continue;
    if (c.story && c.story !== 'none') { console.log(`${c.id}: storied, not relinked (its spans read its links)`); continue; }
    if ((c.links || []).some(l => l.note)) { console.log(`${c.id}: a link carries a note, not relinked`); continue; }
    const re = chainRecord(T, { ...c, contrasts: {} });
    if (JSON.stringify(re.links) !== JSON.stringify(c.links) || re.shape !== c.shape) { console.log(`${c.id}: ${fmtSeq(c.rows, c.links, c.twins || {}, c.mention || [])} · ${c.shape} -> ${fmtSeq(c.rows, re.links, c.twins || {}, c.mention || [])} · ${re.shape}`); c.links = re.links; c.shape = re.shape; touched.add(f); n++; }
  }
  const js2 = joinsOf(T, all.map(x => x.c));
  for (const { c, f } of all) if (ids.includes(c.id)) { const want = js2.get(c.id) || []; if (JSON.stringify(want) !== JSON.stringify(c.joins || [])) { c.joins = want; touched.add(f); } }
  for (const f of touched) fs.writeFileSync(f, formatChains(all.filter(x => x.f === f).map(x => x.c)));
  console.log(`rejoin --relink: ${n} chain(s) relinked in ${touched.size} file(s)`);
  process.exit(0);
}
if (process.argv.includes('--links')) {
  let differ = 0;
  for (const { c, f } of all) {
    const re = chainRecord(T, { ...c, contrasts: Object.fromEntries((c.links || []).map((l, i) => [c.rows[i + 1], l.rel === 'contrasts' ? l.note : null]).filter(([, n]) => n)) });
    if (JSON.stringify(re.links) === JSON.stringify(c.links) && re.shape === c.shape) continue;
    differ++;
    console.log(`${c.id} (${path.relative(ROOT, f)})\n  stored: ${fmtSeq(c.rows, c.links, c.twins || {}, c.mention || [])} · ${c.shape}\n  tables: ${fmtSeq(c.rows, re.links, c.twins || {}, c.mention || [])} · ${re.shape}`);
  }
  console.log(`rejoin --links: ${differ} chain(s) whose links or shape are not what the tables give (of ${all.length})`);
  process.exit(differ ? 1 : 0);
}
const js = joinsOf(T, all.map(x => x.c));
const check = process.argv.includes('--check');
let changed = 0; const touched = new Set();
for (const { c, f } of all) {
  const want = js.get(c.id) || [], have = c.joins || [];
  if (JSON.stringify(want) !== JSON.stringify(have)) {
    changed++; touched.add(f);
    console.log(`${c.id}: joins ${JSON.stringify(have)} -> ${JSON.stringify(want)}`);
    if (!check) c.joins = want;
  }
}
if (!check) for (const f of touched) fs.writeFileSync(f, formatChains(all.filter(x => x.f === f).map(x => x.c)));
console.log(`rejoin: ${changed} chain(s) ${check ? 'differ' : 'rewritten'} in ${touched.size} file(s)`);
