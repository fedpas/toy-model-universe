<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 13a, the result: the path of the clock sum, the Lévy dragon and the boundary of its labels

Script `checks/selfcheck/proofs/clock_walk.py`: 14 checks (bit 4, bit==std 5, ctl 3, std 2), 0 fail, about 5 s alone; five `--fault` options, each run ending with FAIL lines and exit 1 (GRAY 7 failing lines, F2FIRST 1, NOPARITY 9, NOSTAR 2, MIRROR 5). Logs `checks/selfcheck/proofs/logs/clock_walk.log` and `clock_walk.faults.log`. Run from `checks/` as `python3 -I -B selfcheck/proofs/clock_walk.py`; the last line is `clock_walk: 14 checks, 0 fail`; from its own folder and on a second run the check lines are identical. Standard library only.

Conventions (stated in the script and in both rows): the kernel's labels, generator i = bit i; a cell (p, q) with its p generators of square +1 first; w(a) = (|a| mod 2) + 2[e_a² = −1] read from the kernel's squares; Gaussian integers as pairs of integers; the paper's maps on pairs of Fractions; counting order a = 0, 1, …, 2ⁿ − 1, Gray-code order m ↦ m xor (m >> 1).

## 1. Predicted (BEFORE.md) against what ran

All of it came out. What the prediction did not say, or said otherwise:

- **The Gray-code walk retraces itself.** In Gray-code order the labels with the newest generator are the first half read backwards, each times the newest generator, so the second half retraces the first backwards, turned by a quarter turn about its end — the folding of the Heighway dragon, where counting order gives Lévy's copy turned about the origin. Checked on the 91 cells with n ≤ 12 (cw.GRAY [bit]).
- **The complementary pairs have a reason.** The 8 interior labels of n = 14 come in pairs a, 2¹⁴ − 1 − a because the walk read backwards is its own mirror image: E − P_{2ⁿ−k} = i^{w(e₀⋯e_{n−1})} conj(P_k) for the points P_k and the end E (w of a label and of its complement add to w of the whole label, LAB-022), an isometry of the grid that maps the triangle of a label onto that of its complement; checked for every n ≤ 16 (cw.DK [bit]).
- **Allaart and Kawamura's exponent is w.** d_j is w of the label made of the digits before q_j plus j − 1: the charge of LAB-022 read two generators at a time, plus the quarter turn of the division by the end at each level.
- **λ to 22 digits.** By bisection on exact rationals: λ = 1.9547763991024639072660…; Sturm's theorem gives P three real roots and none above 1.96 (every root below 17 in size), so λ is the largest; the ratio |B₄₀₀|/|B₃₉₉| equals it to 10⁻⁹. Rabin's test modulo 7 alone shows P irreducible.
- **The share falls late.** The share of boundary labels is still 0.968 at n = 24 and 0.504 at n = 64: between them the counts grow by about 1.9676 per generator, faster than λ; the asymptotic rate λ sets in later (the ratio is 1.9549 at n = 120).
- Nothing was weakened: LAB-017, LAB-022, LAB-023, ATY-033 and the figure `gauss-sum` stand as they are; the two new rows say what the figure draws.

## 2. The answers

**The path.** The partial sums of the clock sum in counting order are a walk of unit steps i^{w(a)}; each generator appends a copy of the whole walk turned by i^{w(e_k)} = ±i. For Cl(0,n), divided by (1 − i)ⁿ, this is the n-th stage of Duvall and Keesling's IFS for Lévy's C curve, segment by segment and in order (for every n by induction; exact for n ≤ 12); for Cl(n,0) its mirror image. The same labels in Gray-code order draw the Heighway dragon.

**The curve through the dots.** The sum after 2^k labels is the clock sum of the first k generators: for Cl(n,0) the point (1 + i)^k on the logarithmic spiral z(t) = (1 + i)^t (modulus 2^{k/2}, angle k·45°), for Cl(0,n) on (1 − i)^t; one generator is one eighth of a turn of the clock and a factor √2.

**What is an invariant.** The end (1 + i)^p(1 − i)^q, the clock's phase; the path is a picture of the counting order: over the 511 orders of the signs of the 45 cells with n ≤ 8 the 511 paths are distinct and the ends are the cells'.

**The boundary on the labels.** No label of Cl(0,n) is interior for n ≤ 13; 8 are at n = 14, 44 at 15, 172 at 16. Duvall and Keesling's Proposition 5.1 continues the count; the growth rate of the boundary labels, their λ (§5, read), is the largest root of the irreducible nonic P, and by their Theorem 4.5 (read, not re-proved) the boundary of the dragon has Hausdorff dimension 2 log₂ λ = 1.9340071829…, which they print as 1.934007183.

## 3. What ran

| id | what | route | scope |
|---|---|---|---|
| cw.PATH | w from the kernel against the charge; the Thue–Morse square of each step; the doubling by i^{w(e_k)}; the end; Duvall and Keesling's maps on Fractions, f₁'s images first; Lévy's L-system; Allaart and Kawamura's L(t) and its exponent | the kernel's squares; Fractions; string rewriting | the 45 cells with n ≤ 8 (4097 labels); n ≤ 12 (8191 segments); m ≤ 6 (5460 points) |
| cw.GRAY | the same end in Gray-code order, the second half retraced; the Heighway dragon's L-system | the kernel's squares; string rewriting | the 91 cells with n ≤ 12 |
| cw.ORD | the end over every order of the signs; the step of e_k; distinct paths | the kernel's squares on every sign word | 511 sign words, n ≤ 8 |
| cw.DK | the triangles of the walk (doubled centres with a side), distinct; the star of 15 from the vertices; the interior labels; the backwards mirror; Proposition 5.1 with integer counts, its types and shares | integers; the paper's rule as printed | n ≤ 16 on the labels; the rule to n = 420 |
| cw.LAM | Berlekamp–Massey over ℚ; exact division by P; Rabin's test modulo 7; Sturm's sequence; bisection on rationals; the ratio of the counts | Fractions and integers | the counts n ≤ 419 |

## 4. Controls

Three `[ctl]` lines in the main run: the Gray-code order differs from F^n([0,1]) for every n from 2 to 12 (GRAY) and the stage built with f₂'s images first for every n from 1 to 12 (F2FIRST); w without its parity term (every step ±1, a walk on the real line) is not the dragon for any n from 1 to 12 (NOPARITY) and the walk of Cl(n,0) differs from it for every n from 1 to 12 (MIRROR); the star replaced by the 4 triangles that share an edge makes labels interior from n = 10 (2 of them, 350 at n = 14: NOSTAR). Under `--fault X` each wrong version is put in the main lines, which then fail: GRAY 7 lines, F2FIRST 1, NOPARITY 9, NOSTAR 2, MIRROR 5, each run exit 1.

## 5. The standard route

Never the bit rule: Duvall and Keesling's two maps as printed, on pairs of Fractions; their Proposition 5.1 as printed; the L-systems of Lévy's C curve and of the Heighway dragon; Allaart and Kawamura's digit formula. The walk of the kernel's labels is the bridge of the bit==std lines.

## 6. Proposed rows, lens entries and figures (apply.json)

| id | title | evidence | placed |
|---|---|---|---|
| LAB-026 | The path of the clock sum: Lévy's C curve in counting order, the Heighway dragon in Gray-code order, the end fixed by the cell | cw.PATH, cw.GRAY, cw.ORD | clock · clock 28 |
| LAB-027 | Duvall and Keesling's count of the boundary of the Lévy dragon, on the labels | cw.DK, cw.LAM | clock · clock 29 |

Both `since: "v3.1"`, role detail, kind computation, stage A, ptype identity, `legacyFlags: ["checked"]`; their research texts are drafts (`source: "pass13a:clock-walk"`); no learner text. Two entries of the lens geo (79 → 81): Lévy's C curve and the Heighway dragon beside LAB-026; the boundary of the dragon and its dimension beside LAB-027. The figures of the physics overlay p14: `clock-walk` (caption row LAB-026; the steppers p and q to n = 12, the order chips counting and Gray code, the frame chips plane and chord) and `dragon-blades` (caption row LAB-027; the stepper n from 2 to 16), research level only as `gauss-sum`, engine `engines/physics/clockWalk.js` through `engines/labels.js`, test `tests/physics/p14.test.mjs`. A body section draws the figures whose caption rows it places, so both stand in clock · clock after `lattice` and `gauss-sum`, with no change to `content/pages.json`.

## 7. Defects and open points

- **Theorem 4.5 is cited, not computed.** The dimension 2 log₂ λ is the paper's theorem applied to the λ computed here; the open set condition and the theorem are read, not re-proved.
- **The growth rate as the largest root.** That the boundary labels grow like λⁿ is the paper's §5 (Perron–Frobenius on the 752 types, read, not re-proved); here P divides the characteristic polynomial of the exact recurrence (checked to n = 419), its largest root is the ratio of the counts at n = 400 to 10⁻⁹ and the paper's λ; the other 86 roots of the order-95 polynomial are not located.
- **The attractor is not constructed.** The rows speak of the stages F^n([0,1]) and F^n(T₀), exact for the n named; the limit curve and Lévy's tiling of the plane are the paper's and Lévy's (cited).
- **Strichartz and Wang** (a method for the same dimension through an eigenvalue of an 11 × 11 matrix, as Duvall and Keesling describe it) were found, not read here; the two recent arXiv papers on the coordinate functions and on a shifted Lévy curve (PROOFS_ROUND13A.md §3) were seen as abstracts only.
- **No learner words.** The two rows stand as side notes of the section clock, outside its three storied chains; the figures are drawn at research level only. A storyteller's text would come with the next wave.
- **The Weil index** is a row of its own: the clock's phase e^{iπ(p−q)/4} as the Weil index of the real quadratic form of signature (p, q) needs a reading of Weil 1964 for its normalisation (`docs/DECISIONS.md` A70).

## 8. Not done

- The C curve's tiling of the plane, the open set condition, Theorem 4.5 (cited).
- Any statement about a cell that depends on the order of its labels beyond the end of the walk.
- The Weil index (A70).
