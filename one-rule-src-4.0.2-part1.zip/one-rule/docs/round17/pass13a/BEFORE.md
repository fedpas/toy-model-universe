<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 13a, before the script: the path of the clock sum, the Lévy dragon and the boundary of its labels

What the Atlas's rows and the sources read for this pass said, and what the prototypes of the reading gave, before `checks/selfcheck/proofs/clock_walk.py` was written. The question came from the figure `gauss-sum` (clock · clock): for Cl(8,0) and Cl(0,8) its path of 256 unit steps looks like a fractal, and the dots it numbers k = 0 … 8 (the sums after 2^k labels) seem to lie on one curve. What is the path, and what is that curve?

The hand algebra is the Atlas's own: the kernel `researchers_checks/bitrule_A.py` (e_a e_b = s(a,b) e_{a xor b}; generator i = bit i); a cell (p, q) has its p generators of square +1 first (`core_check.sig`); the ℤ₄-form of the labels w(a) = (|a| mod 2) + 2[e_a² = −1] (core.B1); the clock sum Σ_a i^{w(a)} = (1 + i)^p (1 − i)^q (LAB-017, core.B1–B3).

## What the rows say

- **LAB-017**: the exponent of the clock sum is w; its Gauss sum is (1 + i)^p(1 − i)^q, so the clock is the Brown invariant of (V, w).
- **LAB-022**: w adds on disjoint labels, w(a) = Σ ε_j over the generators of a (mod 4).
- **LAB-023**: the clock sum is the product Π_j (1 + i^{ε_j}) over the generators.
- **ATY-033**: the finite theta law, the phase i^w its own Walsh transform. None of the rows says anything about the partial sums: the figure `gauss-sum` draws them (`engines/labels.js` gaussPath) and no row states what they draw.

## The sources

- P. Duvall and J. Keesling, *The Hausdorff dimension of the boundary of the Lévy dragon*, arXiv:math/9907145 (read in full): the IFS f₁(x,y) = ((x−y)/2, (x+y)/2), f₂(x,y) = ((x+y+1)/2, (y−x+1)/2) (§§1, 4); T₀ = (0,0), (½,½), (1,0) and the triangulations T₀ ≻ T₁ ≻ …; Proposition 4.2 (F^k(T₀) is a union of 2^k triangles of T_k); the star N(T) of 15 triangles and covered triangles; "covered triangles do not exist until the 14th iteration, and only 8 of the 2^14 triangles that comprise F^14(T₀) are covered"; Theorem 4.5 (dim_H ∂K = ln β / ln √2, β = lim |B_k|^{1/k}); Proposition 5.1 (the neighbourhood types of the two halves of a triangle); S₁₉ = S₂₀ with 752 types; λ ≈ 1.954776399, dim_H ∂K ≈ 1.934007183, the rigorous bracket 1.824190 < λ < 1.974189.
- P. C. Allaart and K. Kawamura, *On the coordinate functions of Lévy's dragon curve* (preprint of 16 August 2005; read for its formula): L(t) = Σ_j 2^{−j} i^{d_j} l_{q_j} on the base-4 digits q_j of t, d_j the number of 0s minus the number of 3s among q₁ … q_{j−1} mod 4, l₀ = 0, l_q = q − 1 + i.
- The L-systems of Lévy's C curve (F → +F−−F+, 45°) and of the Heighway dragon (FX, X → X+YF+, Y → −FX−Y, 90°): standard, recalled.

## Predictions

1. **The path is Lévy's C curve** (cw.PATH). The labels with e_k are the earlier labels times e_k and w adds on disjoint labels, so their steps are the earlier steps times i^{w(e_k)} = ±i: each generator appends the whole path turned by a quarter turn. Divided by (1 − i)ⁿ, the path of Cl(0,n) is F^n([0,1]) of Duvall and Keesling segment by segment, f₁ the labels without the newest generator and f₂ those with it (by induction: 1/(1 − i) = (1 + i)/2 and −i/(1 − i) = (1 − i)/2); Cl(n,0) gives the mirror image. Lévy's L-system after n rounds gives the same directions turned by n eighths of a turn. Allaart and Kawamura's L(a/4^m), times the end (1 − i)^{2m}, is the walk of Cl(0,2m) at the label a. Each step squared is (−1)^{|a|}.
   - *Prototype (n ≤ 12):* the maps, the L-system (offset n eighths) and L(t) (m ≤ 5) all agree exactly.
   - Controls: the Gray-code order (GRAY), f₂'s images first (F2FIRST), w without its parity term (NOPARITY: every step ±1), the walk of Cl(n,0) for the dragon (MIRROR) each differ from F^n([0,1]).
2. **The same labels in Gray-code order draw the Heighway dragon** (cw.GRAY): the same end, the steps of Cl(n,0) the L-system's directions (offset 0), those of Cl(0,n) its mirror.
3. **The curve through the dots is the logarithmic spiral z(t) = (1 + i)^t** (for Cl(n,0); (1 − i)^t for Cl(0,n)): the sum after 2^k labels is the clock sum of the first k generators, (1 + i)^k, of modulus 2^{k/2} and angle k·45°. This needs no new check: it is LAB-017 for the cells Cl(k,0).
4. **The end is the cell's, the path the order's** (cw.ORD). Over every order of the signs of a cell the end (1 + i)^p(1 − i)^q stays, while the path changes with the order: the step of the label e_k is i^{w(e_k)}, so the path determines the order of the signs; the three cells of clock 0 at n = 8 end at 16 along C(8, p) paths: 1, 70, 1.
5. **Duvall and Keesling's count on the labels** (cw.DK). Each step of the path of Cl(0,n) is the long side of the triangle with third vertex z + d(1 + i)/2, the image of T₀; a label is interior when the 15 triangles of its star all belong to the path.
   - *Prototype:* no interior label for n ≤ 13, 8 at n = 14 (5977, 6662, 7341, 7346, 9037, 9042, 9721, 10406, complementary pairs a, 2¹⁴ − 1 − a), 44 at 15, 172 at 16; with the 4 triangles that share an edge in place of the star (NOSTAR) interior labels appear at n = 10 (2), 350 at 14.
   - Proposition 5.1 as printed, from the 15 types 2⁰ … 2¹⁴: the same counts for n ≤ 16, 752 types from n = 19 on; the share of boundary labels 0.968027 at n = 24 and 0.503783 at n = 64.
6. **λ as an algebraic number** (cw.LAM). *Prototype:* the counts satisfy an integer recurrence of order 95; P(x) = x⁹ − 3x⁸ + 3x⁷ − 3x⁶ + 2x⁵ + 4x⁴ − 8x³ + 8x² − 16x + 8 divides its characteristic polynomial exactly, is irreducible (Rabin's test modulo 7, 13 and 47), and its largest root is λ = 1.9547763991…; 2 log₂ λ = 1.934007183, the paper's dimension.

## Not to be computed here

Theorem 4.5 itself and the open set condition (read, not re-proved); Lévy's tiling of the plane by copies of the dragon (cited); anything about a cell that depends on the order of its labels; Strichartz and Wang's 11 × 11 matrix (not read); the Weil index (a row of its own, after a reading of Weil 1964: `docs/DECISIONS.md` A70).
