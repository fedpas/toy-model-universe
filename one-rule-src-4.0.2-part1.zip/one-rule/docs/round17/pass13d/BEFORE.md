<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 13d, before the script: Weil's Theorem 3 on the labels, and the phases of the Clifford group

What the Atlas's rows and the source said, and what the prototypes gave, before `checks/selfcheck/proofs/weil_cocycle.py` was written. Pass 13c (LAB-030) left as its next step Weil's Theorem 3 on the labels: the factor system of the projective representation of B₀((ℤ/2)^m) that Theorem 1 gives, and which roots of unity a group of its lifts needs for m ≥ 2. The owner's request names the question: the phase cocycle of Theorem 3 on B₀, and how the eighth roots enter the Clifford group of several qubits.

The hand algebra is the Atlas's own: the kernel `researchers_checks/bitrule_A.py` (e_a e_b = s(a,b) e_{a xor b}; generator i = bit i); a cell (p, q) has its p generators of square +1 first (`core_check.sig`).

## What the rows say

- **LAB-028**: Weil's index γ(f) of the labels' character of the second degree f = i^{w} on G = (ℤ/2)ⁿ, with the counting measure and its dual, is the clock's phase e^{iπ(p−q)/4} of the cell (p, q); his lifts t₀(i^{w}) and d′₀ are the gates S^{⊗p}(S†)^{⊗q} and H^{⊗n}, with (t₀d′₀)³ = e^{iπ(p−q)/4}·1.
- **LAB-029**: the labels of a cell with 2m generators are Weil's A((ℤ/2)^m) up to a coboundary (Jordan–Wigner); his U(w) are the Pauli strings.
- **LAB-030**: Theorem 1 on the labels: B₀((ℤ/2)^m) is the Clifford group of m qubits modulo its scalars, 24 and 11 520 elements for m = 1, 2, split over Sp(2, 𝔽₂), not over Sp(4, 𝔽₂); the group of S and H has 192 elements, its centre the eight eighth roots, (SH)³ = e^{iπ/4}.
- **LAB-017, LAB-019, CAND-057**: the Brown invariant of a ℤ₄-valued form read from its Gauss sum; ℤ₄-forms classified by rank and Brown invariant; the Brown homomorphism.
- No row names Weil's big cell Ω₀(G), his lifting r₀ of n° 13, his Theorem 3, the class of the projective representation, or his relation (40).

## The source

A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964) 143–211, read in full for pass 13b. What this pass uses:

- **n° 7, Proposition 1**: the set Ω₀(G) of the elements s = (σ, f) of B₀(G) whose block γ(s) is an isomorphism of G* onto G; each is written in one way only as s = t₀(f₁)d′₀(γ)t₀(f₂), with f₁(u) = f(u, −uαγ⁻¹) and f₂(u) = f(0, uγ⁻¹).
- **n° 13**: the lift r₀(s) = t₀(f₁)d′₀(γ)t₀(f₂) of Ω₀(G) and its formula (16), r₀(s)Φ(x) = |γ|^{1/2}∫Φ(xα + x*γ)f(x, x*)dx*, σ = (α β; γ δ) acting on the right; in general no section of the normaliser over B₀(G) is a subgroup.
- **n° 14**: Theorem 2 (the Fourier transform of a non-degenerate character of the second degree is γ(f) times a character of the second degree) and Corollary 2 (γ(f) as an integral); the remark that over a group of local type the γ(f) are eighth roots of unity, related to Gauss sums.
- **n° 15**: the factor system λ(s, s′) of r₀ on Ω₀(G), r₀(s)r₀(s′) = λ(s, s′)r₀(ss′), and **Theorem 3**: for s, s′, s″ = ss′ in Ω₀(G), f₀(u) = f(0, uγ⁻¹)f′(u, −uα′γ′⁻¹) is a non-degenerate character of the second degree of G, associated with γ⁻¹γ″γ′⁻¹, and λ(s, s′) = γ(f₀).
- **n° 42–43**: a character ψ of the metaplectic group equal to t ↦ tⁿ on its scalars is fixed by φ = ψ∘r on Ω, which by Theorem 3 satisfies his relation (40), φ(s″) = γ(f₀)⁻ⁿφ(s)φ(s′); conversely such a φ gives ψ, whose kernel is an n-fold cover, by his Lemma 6 (n° 42), a lemma of group theory whose hypotheses he checks for analytic groups over local fields. Over a local field of characteristic other than 2 he takes n = 2, the metaplectic double cover, and over ℂ n = 1, where γ = 1 and the extension is trivial. The introduction: there the class is of order 2 and in general not 0; except in characteristic 2 the metaplectic group extends the symplectic group by T (in characteristic 2 the group it extends is his pseudosymplectic group, n° 31 and 34).
- Recalled, not read: the generation of the Clifford group of m qubits by H, S and CNOT; the number of stabilizer states; Sp(4, 𝔽₂) ≅ S₆.

On G = (ℤ/2)^m, with G* = G by ⟨x, x*⟩ = (−1)^{x·x*}, the counting measure on G and its dual 2^{−m} on G*: |γ| = 2^m, so formula (16) reads r₀(s)[x, y] = 2^{−m/2} f(x, (y + xα)γ⁻¹), and γ(f) = (Σ_G f)/2^{m/2}.

## Predictions

1. **The lifting** (wc.LIFT). r₀(s) by formula (16) is unitary and lies over s: r₀(s)⁻¹U(w)r₀(s) = f(w)U(wσ) (relation (15)).
   - *Prototype:* all of Ω₀ for m = 1, 2: 16 and 6144 elements (of 24 and 11 520).
2. **Theorem 3** (wc.THM3). For s, s′ in Ω₀ with ss′ in Ω₀: r₀(s)r₀(s′) = γ(f₀)r₀(ss′), with f₀ a non-degenerate character of the second degree associated with γ⁻¹γ″γ′⁻¹ (in characteristic 2 the sign of −uα′γ′⁻¹ drops).
   - *Prototype:* all 128 pairs for m = 1, values e^{±iπ/4}; 41 728 of 41 728 sampled pairs for m = 2, values the four fourth roots.
   - *Prediction for m = 3:* the odd powers of e^{iπ/4} only (a non-degenerate form on 𝔽₂³ cannot be alternating, so it is the labels' form of a cell with p + q = 3, p − q odd).
3. **The values are clock phases** (wc.THM3). On an orthonormal basis of its form, f₀ is the labels' i^{w} of a cell (p, q), p + q = m, and γ(f₀) = e^{iπ(p−q)/4} (LAB-028); when the form is alternating (m even), γ(f₀) = ±1, the sign of its Arf invariant.
4. **The scalars no choice of lifts removes** (wc.CLASS). Every group of unitaries lying over all of B₀ contains the commutator subgroup of the Clifford group (commutators do not see scalars), hence its scalars; a group that has no more measures the order of the class.
   - *Prototype:* m = 1: the commutator subgroup of ⟨S, H⟩ has 24 elements and the scalars ±1, and the binary octahedral group (48 elements, the lifts of determinant 1) lies over B₀(ℤ/2) with ±1: order 2. m = 2: two lifts r₀(a), r₀(b) generating B₀ generate 46 080 unitaries with the fourth roots as scalars, and their commutator subgroup (23 040) has the same: order 4.
   - *Prediction for m ≥ 3:* order 8 — all eighth roots forced. The argument proposed: GL(3, 𝔽₂) is perfect, so CNOT ⊗ 1 is a product of commutators of permutation matrices; if e^{iπ/4}·CNOT were a product of commutators of the two-qubit group, e^{iπ/4}·1 would be one. The second step was not checked before the script.
5. **Controls.** r₀ without its normalisation 2^{−m/2} (|γ|^{1/2} with the dual measure) is not unitary (NOMODULE); f₀ without its factor f′ misses the factor system (NOFPRIME); the scalars of one group of lifts are not an invariant (SCALARS).

## Not to be computed here

Weil's theorems for a general G (read); Theorem 3 on all pairs for m = 2 and beyond a sample for m = 3; the Clifford groups for m ≥ 4; his Lemma 6 (n° 42, a lemma of group theory; its hypotheses are not checked on these finite groups).
