<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The proofs round, pass 13g: the class for every number of qubits, Weil's relation (40), and a finite Siegel–Weil formula in every genus

Passes 13d and 13f left four points open on the labels: the class of the labels' Clifford group for four or more qubits; Weil's relation (40) with n = 2 for two or more qubits; the finite Siegel–Weil formula of genus 2 beyond six generators, and genus 3; a proof for every n of the line of invariant vectors. This pass proves all four, for every number of qubits, every n and every genus, and computes their steps. It reads two papers the owner attached for what is known: K. Mastel, *The Clifford theory of the n-qubit Clifford group* (2025), and G. Nebe, E. M. Rains, N. J. A. Sloane, *Codes and invariant theory* (2003).

One script under `checks/selfcheck/proofs/` (`weil_general.py`; 13 check lines, bit 1, bit==std 1, ctl 3, std 8, 0 fail, about 71 s alone; five fault runs, each ending with FAIL lines and exit 1: NOS with 4 failing lines, ONEQ 2, SAMEPB 1, NOH 3, NOTV 2; `logs/weil_general.log` and `logs/weil_general.faults.log` beside it). Run from `checks/` as `python3 -I -B selfcheck/proofs/weil_general.py`, it ends with `weil_general: 13 checks, 0 fail`; from its own folder and on a second run the check lines are identical. It uses the standard library and numpy. The pass's working records are `docs/round17/pass13g/BEFORE.md` (the reading and the predictions), `RESULT.md` (what ran, and in §2 the proofs) and `apply.json` (the data), applied by `docs/round17/apply_pass13g.py`.

## 1. What changes in the tables

- **LAB-037, the class for every number of qubits** (wg.CLASS). For every m ≥ 2 the class of Weil's projective representation of B₀((ℤ/2)^m) has order 4.
  - *Not order 2.* i·1 is a single commutator of two qubits, aba⁻¹b⁻¹ with b = ζH ⊗ S and a = CNOT₁₀(1 ⊗ ζH)CNOT₀₁(1 ⊗ S)²(1 ⊗ ζH), so every group of unitaries lying over all of B₀ holds it.
  - *Order dividing 4.* The group of ζH, S and CNOT lies over all of B₀ for every m, with the fourth roots alone as scalars (its entries lie in ℤ[1/2, i]). Its image is all of Sp(2m, 2), by an induction that recalls nothing: transitive on the non-zero vectors; the moves fixing x₀ carry z₀ to every f with ⟨x₀, f⟩ = 1; the other m − 1 qubits give Sp(2m − 2, 2).
  - *Computed:* the commutator on two and three qubits; Sp(2, 2) and Sp(4, 2) reached; the two steps of the induction for m ≤ 8; the descent in ℤ[1/2, i] for k ≤ 12.
- **LAB-038, Weil's relation (40) on the labels** (wg.REL40). For m ≥ 2 a solution exists exactly when 4 | n; none with n = 2.
  - *For 4 | n,* from the character t·g ↦ tⁿ of the group of all lifts (φ = (−1)^m for n = 4: by Weil's formula (16) the entries of his lifts are 2^{−m/2} times fourth roots, for every m).
  - *Otherwise none,* by a certificate of four relations: P, B, X with PBP⁻¹B⁻¹ = −i·1, and P, B, X, BX, PX, PBX over the big cell, give (−i)ⁿ = 1. It is computed for m = 2 to 5 and carried to every m by tensor products.
  - *Against Weil's frame.* The solvability of (40) and the existence of the character coincide here, although the hypothesis of Lemma 6 fails on these finite groups: x lies in Ua when the Lagrangian of x is transversal to that of a, and the three Lagrangians ℓ ⊕ L′ (ℓ a line of the plane of qubit 0, L′ = ⟨z_1, …, z_{m−1}⟩) have no common transversal, every Lagrangian meeting their union, an (m + 1)-dimensional space. Computed: the triples without a common transversal also transversal to L*, 12 of 27 for m = 1 and 756 of 3375 for m = 2; the three of the argument for m ≤ 3.
- **LAB-039, a finite Siegel–Weil formula in every genus** (wg.TRANS, wg.LINE, wg.SW).
  - *No fixed vector off the clock at 0.* For p ≢ q mod 8, Weil's operators D_g hold the scalar e^{iπ(p−q)/4} and fix no non-zero function.
  - *The line.* For p ≡ q mod 8, for every n and every genus g, the functions fixed by D_g and the orthogonal transvections form the line spanned by Θ_g. It equals c_r = Π_{i=1}^{r}(1 + 2^{k−i})⁻¹ (k = (n − 2)/2) on the g-tuples of labels with f = 1 (even weight and square +1), mutually orthogonal, whose span with the top label has dimension r + 1, and 0 elsewhere.
  - *The formula.* A_g = Θ_g = E_g/E_g(δ₀), with E_g(δ₀) = |orbit|/‖A_g‖² > 0. With the stabilizer states recalled, E_g(δ₀) = Π_{i=0}^{g−1}(1 + 2^{2+i−n/2}).
  - *Computed:* the fixed space directly in 182 (cell, genus) cases (g = 1 to n = 12, g = 2 to n = 10, g = 3 to n = 6); the transitivity of the transvections for n ≤ 10, with the orbit sizes of the counting formula; the formula for g = 2 to n = 10 and g = 3 to n = 6; for (8,0) the genus-2 enumerator of the extended Hamming code, computed from its generator matrix.
- **Placement**: clock · clock at the orders 39, 40 and 41, role detail; stage A, kind theorem (each row a theorem for every m or every n, its steps computed), ptype identity; `since: "v3.5"`.
- **The lenses**: alg (three entries, 165 → 168): the class of the Clifford group for every number of qubits; Weil's relation (40) on the labels; the finite Siegel–Weil formula in every genus. fld (one entry, 87 → 88): code ensembles averaged in every genus. Attached by their check ids.

## 2. What came out against the prediction

All of BEFORE.md came out (RESULT.md §1). The proofs are written out in RESULT.md §2:

- Theorem A, the class;
- Theorem B, relation (40);
- Theorem C, the line, with the lemma that the reflections of a quadratic space over 𝔽₂ act transitively on the ordered bases of its totally singular subspaces;
- Theorem D, the formula.

The transitivity holds also for the hyperbolic space of dimension 4, where the reflections do not generate the orthogonal group (the audit counted 36 of its 72 elements); the lemma's induction does not need that generation, and its Eichler step is written out for that space apart, where the non-singular vectors of e^⊥ do not span it (RESULT.md §2.3).

Two readings came with the papers (RESULT.md §2.5):

- *Nebe, Rains and Sloane.* Their spanning theorem gives a second route to the line for q = 0. Their scalar group ℤ₈, of order the least length of a doubly-even code, is the scalar e^{iπ(p−q)/4} of Weil's operators in their frame. The minimal group of lifts carries the fourth roots, the eighth being a normalisation.
- *Mastel.* His Theorem III.6 proves that the full Clifford group maps onto Sp(2n, 2), his Lemma IV.1 that Sp(2n, 2) is transitive on the non-zero vectors; the generation of the Clifford group by H, S and CZ with phases he takes as known, and the induction proves it for ζH, S and CNOT up to scalars. The extension he states to be non-split is by the Pauli group, not the one by scalars whose class LAB-037 computes.

## 3. Sources

| source | how it is used | read |
|---|---|---|
| A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964) 143–211 | n° 10 (Theorem 1), n° 15 (Theorem 3), n° 25 (γ(f) = ±1 in characteristic 2), n° 42–43 (Lemma 6; relation (40); the covers over local fields), n° 52 (the formula), the introduction (the class) | in full (pass 13b); the theorems applied |
| K. Mastel, *The Clifford theory of the n-qubit Clifford group*, arXiv:2307.05810v2 (2025) | Theorem III.6, Corollary III.7, Lemma IV.1; the non-split extension by the Pauli group, set apart from the class by scalars | in full (attached by the owner) |
| G. Nebe, E. M. Rains, N. J. A. Sloane, *Codes and invariant theory*, arXiv:math/0311046 (2003) | Theorem 3.5 (the spanning by weight enumerators, its proof in their book), Remark 3.2 (genus-m enumerators), Theorem 4.2 and its remark, Theorem 5.2 (the scalars, ℤ₈ in the binary doubly-even case); their group, for binary doubly-even codes, the complex Clifford group of their earlier paper | in full (attached by the owner); their book and earlier paper not read |
| the Cauchy binomial theorem; the form of the stabilizer states (J. Dehaene, B. De Moor, 2003) and their number | the constant E_g(δ₀) in every genus | recalled |
| LAB-028, LAB-030, LAB-031, LAB-032, LAB-034, LAB-035, LAB-036 | the clock's phase as Weil's index and (FH)³; Theorem 1 on the labels; the normalised lifts; the class for m ≤ 3; the genus and its counts; the formula for g ≤ 2 | the Atlas's rows |

## 4. Defects and open points

- **The proofs are the Atlas's**, written out in RESULT.md §2 with their steps computed; an independent audit read them and recomputed the pass with its own code (RESULT.md §10), not a second mathematician. Its points are taken: the support of Θ_g named by f = 1, the failure of Lemma 6's hypothesis argued and computed, the Hamming enumerator computed from a generator matrix, the Eichler step written out, Mastel's theorems stated as what they prove, the scopes of the computations.
- **The constant E_g(δ₀) for g ≥ 4** rests on the recalled form and number of the stabilizer states (computed for g ≤ 3); the formula A_g = E_g/E_g(δ₀) does not.
- **The computations stop** at m = 8 (the induction), m = 5 (the certificate), n = 10 (the transitivity), and g = 3, n = 6 (the formula); the proofs carry them on.
- **Lemma 6's own conclusion** (every solution of (40) extends, uniquely, to a character) is not addressed.
- **Weil's formula of n° 52** is read as a statement; its proof is in the next memoir, not read.
- **No learner words** (as LAB-026 to LAB-036).

## 5. What a next pass would be

The twistor programme the owner has set next. On the Weil line: his Chapter II on the labels, γ as a character of the Witt group and the product formula behind quadratic reciprocity.
