<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 13e, before the script: Weil's theta transform, Theorem 4 and Theorem 5 on the labels

What the Atlas's rows and the source said before `checks/selfcheck/proofs/weil_theta.py` was written. Pass 13d (LAB-031, LAB-032) computed the factor system of Weil's lifting on the big cell and the class of his projective representation of B₀((ℤ/2)^m), of order 4 for m ≥ 2. Its §9 named the next pass: Weil's n° 16–21, where a subgroup Γ of G gives a subgroup B₀(G, Γ) of B₀ on which the projective representation becomes a true one, and Theorem 5, from which Weil derives the quadratic reciprocity law. The owner's instruction: keep to Weil's results, find the next steps and prove them, before the twistor programme.

The hand algebra is the Atlas's own: the kernel `researchers_checks/bitrule_A.py` (e_a e_b = s(a,b) e_{a xor b}; generator i = bit i); a cell (p, q) has its p generators of square +1 first (`core_check.sig`).

## What the rows say

- **LAB-028**: the labels of a cell with n generators are G = (ℤ/2)ⁿ; their form i^{w} is a character of the second degree whose symmetric morphism is the dot product, and its index γ is the clock's phase e^{iπ(p−q)/4}.
- **LAB-030, LAB-031, LAB-032**: B₀((ℤ/2)^m) is the Clifford group modulo its scalars; Weil's lifting r₀ of the big cell has the factor system γ(f₀); a group of lifts of all of B₀ needs the fourth roots for m ≥ 2.
- **ATY-033**: i^{w} is its own Walsh transform up to the Gauss sum: Σ_a i^{w(a)}(−1)^{a·b} = (1 + i)^p(1 − i)^q i^{−w(b)}.
- **LAB-017, LAB-019, CAND-057**: the Brown invariant of a ℤ₄-form from its Gauss sum; ℤ₄-forms classified by rank and Brown invariant.
- **CAND-026**: even unimodular lattices only in rank ≡ 0 mod 8, read from a Gauss sum (Milgram); Construction A on the extended Hamming code gives E₈.
- **LNB-011**: Majorana–Weyl spinors exactly when p − q ≡ 0 mod 8.
- **CAND-008** (a candidate): stabilizer states and the Clifford group as a symplectic polar space.
- No row names Weil's theta transform, his B₀(G, Γ), his Theorems 4 and 5, or self-dual codes of labels.

## The source

A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964) 143–211, read in full for pass 13b. What this pass uses:

- **n° 16**: a closed subgroup Γ of G and its annihilator Γ_* in G*; Haar measures dξ on Γ and dẋ on G/Γ with dx = dξ dẋ; Θ(x, x*) = ∫_Γ Φ(x + ξ)⟨ξ, x*⟩dξ (formula (20)), which for suitable choices gives the classical theta series.
- **n° 17–18**: the dual measures on G*/Γ_* and Γ_*; Θ(z + ζ) = Θ(z)F(ζ, z)⁻¹ for ζ ∈ Γ × Γ_* (formula (22)); the Hilbert space H(G, Γ) of such functions with the norm over Q = (G/Γ) × (G*/Γ_*); Z: Φ ↦ Θ an isometry of L²(G) onto it, with its inverse (formula (23)).
- **n° 19**: U(w)Θ(z) = Θ(z + w)F(z, w) (formula (24)); B₀(G, Γ), the s = (σ, f) of B₀ with f = 1 on Γ × Γ_* and σ keeping Γ × Γ_*; r_Γ(s)Θ(z) = Θ(zσ)f(z) (formula (25)), a representation of B₀(G, Γ) lying over it; **Theorem 4**: ∫_Γ Φ dξ = ∫_Γ r_Γ(s)Φ dξ (formula (26)), and its corollary, the construction of automorphic functions.
- **n° 20**: on Ω₀(G, Γ), where γ(s) carries Γ_* onto Γ, r_Γ coincides with r₀; for Γ, Γ_* discrete and s = d′₀(γ), Theorem 4 is the classical Poisson formula; **Theorem 5**: if a character of the second degree f of G is 1 on Γ and its symmetric morphism ρ is an isomorphism of (G, Γ) onto (G*, Γ_*), then γ(f) = 1; Theorem 3 gives it too; over the adeles it holds the quadratic reciprocity law (Chapter II).
- **n° 21**: for Γ compact and open the characteristic function of Γ is invariant under B₀(G, Γ).
- Recalled, not read: self-dual and doubly-even binary codes, the extended Hamming code and the number 30 of doubly-even self-dual codes of length 8; stabilizer states.

On G = (ℤ/2)^m with counting measures, Γ_* = Γ^⊥ (the dot product), and Γ × Γ^⊥ is a Lagrangian subspace of G × G* for the commutation form, so the characteristic function of Γ is the stabilizer state of that Lagrangian.

## Predictions

1. **The theta transform** (wt.ZAK). For every subgroup Γ of (ℤ/2)^m, m ≤ 3, formula (22) holds, Z keeps the norm with Weil's measures (counting on G/Γ, its dual 1/|Γ| on G*/Γ_*), formula (23) inverts it, and Z U(w) = U(w) Z with (24).
2. **Theorem 4** (wt.THM4). B₀(G, Γ) is made of the elements of the stabilizer of the Lagrangian L = Γ × Γ^⊥ with f = 1 on L: |Stab(L)|·2^m elements (4 for m = 1; 48·4 = 192 for each of the five subgroups when m = 2). r_Γ is unitary, lies over s, and is a representation, r_Γ(s)r_Γ(s′) = r_Γ(ss′) with no scalar: on the stabilizer of a stabilizer state the factor system of pass 13d disappears. On Ω₀(G, Γ) (m = 2, Γ of order 2) r_Γ = r₀ exactly, so Theorem 3's γ(f₀) is 1 there. The characteristic function of Γ is fixed by every r_Γ(s) with no phase; Theorem 4 holds; the Poisson formula holds for every subgroup.
3. **Theorem 5 on the labels** (wt.THM5). With LAB-028's dictionary, f = i^{w} and ρ = the identity of the dot product, so the hypothesis ρ(Γ) = Γ_* says Γ = Γ^⊥: a self-dual code of labels; f = 1 on Γ says every label of the code has square +1 (its weight is even, so w = 2·[e_a² = −1]). Theorem 5 then gives γ = 1, that is p ≡ q mod 8. Predicted also the converse: such a code exists in every cell with p ≡ q mod 8 (pairs of generators of opposite squares, and doubly-even codes on blocks of eight generators of the same square). For q = 0 the condition is |a| ≡ 0 mod 4: the doubly-even self-dual codes, so only lengths ≡ 0 mod 8, 30 of length 8.
   - The engine of the proof on finite G: the Poisson formula with ATY-033, 2ⁿΣ_Γ i^{w} = |Γ|(1 + i)^p(1 − i)^q Σ_{Γ^⊥} i^{−w}, which for a self-dual Γ with f = 1 on it reads 2^{n/2} = γ·2^{n/2}.
4. **Controls.** The theta transform without ⟨ξ, x*⟩ breaks (22) (NOPHASE); elements keeping L but with f ≠ 1 on it leave H(G, Γ) (NOFCOND); the weight condition |a| ≡ 0 mod 4 in place of the squares gives codes in cells with p ≢ q mod 8 (WEIGHT); a self-orthogonal code smaller than self-dual, the trivial code {0} added to the self-dual ones, does not satisfy Weil's hypothesis (NOTDUAL).

## Not to be computed here

Weil's theorems for a general G (read); B₀(G, Γ) for m = 3 beyond a sample; codes beyond length 10; the quadratic reciprocity law over the adeles (read); the classification of self-dual codes (recalled).
