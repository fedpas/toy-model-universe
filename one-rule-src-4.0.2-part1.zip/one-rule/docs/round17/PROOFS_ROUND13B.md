<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The proofs round, pass 13b: the clock's phase as Weil's index

The clock sum Σ_a i^{w(a)} = (1 + i)^p(1 − i)^q of a cell is a finite Gauss sum of modulus 2^{n/2}, and its phase e^{iπ(p−q)/4} is the clock (LAB-017). Pass 13a left a question (A70): the phase was recalled as Weil's index of the real quadratic form of signature (p, q), "up to the conventions of the character and of the sign", and no row could say so before the conventions were read. This pass reads A. Weil, *Sur certains groupes d'opérateurs unitaires* (Acta Math. 111, 1964), in full, fixes the normalisation, and checks on the labels that the clock's phase is Weil's index in three senses: as the scalar his relation (9) acquires when lifted to unitary operators on the labels, as the index of the real form of the cell for the character e^{2πiλt} with λ > 0, and, through his Theorem 5 on ℝⁿ × labels, as the reason the two agree.

One script under `checks/selfcheck/proofs/` (`weil_index.py`; 14 check lines, bit 6, bit==std 3, ctl 3, std 2, 0 fail, about 7 s alone; four fault runs, each ending with FAIL lines and exit 1: CHI with 5 failing lines, NOPARITY 9, COUNTING 5, CONJ 1; `logs/weil_index.log` and `logs/weil_index.faults.log` beside it). Run from `checks/` as `python3 -I -B selfcheck/proofs/weil_index.py`, it ends with `weil_index: 14 checks, 0 fail`; from its own folder and on a second run the check lines are identical. The pass's working records are `docs/round17/pass13b/BEFORE.md` (the reading and the predictions), `RESULT.md` (what ran and what came out) and `apply.json` (the data), applied by `docs/round17/apply_pass13b.py`.

## 1. What changes in the tables

- **LAB-028, Weil's index and the clock** (wi.DEF, wi.FT, wi.REAL, wi.WITT, wi.T5). On the labels f = i^{w} is a non-degenerate character of the second degree in Weil's sense (f(a ⊕ b) f(a)⁻¹ f(b)⁻¹ = (−1)^{a·b}, ρ the identity for the dot product). With the counting measure on the labels and its dual measure 2⁻ⁿ, Weil's lifted operators t₀(f) and d′₀(±ρ⁻¹) satisfy his relation (9) up to one scalar for each of the 45 cells with n ≤ 8, and the scalar is (1 + i)^p(1 − i)^q / 2^{n/2} = e^{iπ(p−q)/4}; (t₀ d′₀)³ = e^{iπ(p−q)/4}·1 (n ≤ 6). His Corollary 2 gives the clock sum over 2^{n/2}; his Theorem 2 is ATY-033's finite theta law with his constants (66 cells). Over ℝ his n° 26 gives, for χ(t) = e^{2πiλt}, the index e^{iπ(a−b)/4} of a form of inertia type (a, b) when λ > 0 and its conjugate when λ < 0 (recomputed by his own recipe, by quadrature, to 10⁻¹²); the form v ↦ v² of the cell has inertia type (p, q), so the clock's phase is the index of the real form of the cell for λ > 0 and that of the mirror cell for λ < 0. On the labels γ has the properties Proposition 3 and formula (28) give for real forms: it multiplies over orthogonal sums, is conjugated by the mirror cell, is 1 on the cell (1, 1), satisfies the corollary of Theorem 5 and the analogue of (28), and depends on p − q mod 8 alone. Weil's Theorem 5 on ℝⁿ × labels, with the subgroup of the points (x, 2x mod 2), x ∈ (½ℤ)ⁿ, has its hypotheses computed: the real and the finite index are one, and LAB-017 is Milgram's formula for the even lattice A₁^p ⊕ A₁(−1)^q, whose discriminant form is the labels with i^{w}.
- **Placement**: clock · clock at the order 30, role detail (a side note of the section, outside its three storied chains); stage A, kind computation, ptype identity; `since: "v3.2"`, so the badge "new" marks it (A60).
- **The lens** `alg` (two entries, 155 → 157): Weil's index on the labels and over ℝ; Theorem 5 on ℝⁿ × labels and the discriminant form. Attached by their check ids.
- **No figure.** The row reads the sum the figure `gauss-sum` draws.

## 2. What came out against the prediction

All of BEFORE.md came out (RESULT.md §1 has the details): i^{w} is a non-degenerate character of the second degree of the labels; its index, by Weil's definition, his Corollary 2 and his Theorem 2, is the clock's phase; over ℝ the sign of λ decides between the cell and its mirror; the properties of Proposition 3 hold on the labels; Theorem 5's hypotheses hold on ℝⁿ × labels. Beyond the prediction: the scalar of the lifted relation (9) is the clock's phase as an operator identity, (t₀ d′₀)³ = e^{iπ(p−q)/4}·1; the dual measure is what makes its modulus 1; the parity-free form has index ±1 by the type of the cell (the sign of GEN-032's count) and no index for odd n; the labels' cell (1, 1) and Weil's hyperbolic character are different characters with the same index 1.

## 3. Sources

| source | how it is used | read |
|---|---|---|
| A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964) 143–211 | n° 1, 2, 7, 13–14 (characters of the second degree, the dual measure, relation (9), the lifted operators, γ(f), Theorem 2, Corollary 2), n° 20 (Theorem 5 and its corollary), n° 22, n° 24–26 (γ of a quadratic form, Proposition 3, the real case), n° 25, 27, 28 (γ = ±1 when −1 is a square; Gauss sums; formula (28)), n° 30 (Proposition 5: the product formula and quadratic reciprocity), n° 44 (the representation for k = ℝ is Shale's; γ(f) = μ(ρ⁻¹)) | in full; the theorems applied, not re-proved |
| Milgram's formula for the Gauss sum of the discriminant form of an even lattice | the reading of LAB-017 for A₁^p ⊕ A₁(−1)^q | recalled |
| LAB-017, LAB-018, LAB-022, CAND-057, ATY-033, GEN-032 | the clock sum, the lattice I_{p,q}, w on disjoint labels, the theta law, the count of the types | the Atlas's rows |

## 4. Defects and open points

- **Weil's theorems are applied, not re-proved**: their hypotheses and their conclusions are computed on the cases named.
- **The real index is computed in floating point** (10⁻¹² for x², 10⁻⁹ for the cells); the labels' side is exact.
- **Milgram's formula** is recalled; its case here is computed.
- **The physics reading** of the scalar is a reading: on ℝⁿ the phase by which the lift of (9) fails in the Segal–Shale–Weil representation (n° 44), on the labels the qubit gates S^{⊗p}(S†)^{⊗q} and H^{⊗n} with (t₀ d′₀)³ = e^{iπ(p−q)/4}·1; the metaplectic group is read, not built on the labels.
- **No learner words, no figure** (as LAB-026 and LAB-027).

## 5. What a next pass would be

Weil's Chapter I on the labels further: his group A(G) for G = (ℤ/2)^m (n° 4, a central extension of G × G* by the circle) set beside the labels' sign cocycle s(a, b) on 2m generators, his Theorem 1 (the automorphisms of A(G) that fix its centre, implemented by unitary operators) on that group, and the scalars of his Theorem 3 (the cocycle γ(f₀)) checked there. A figure of the real index beside the clock walk. The adelic Proposition 5 on the labels' lattice is not in view.
