#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round17/apply_pass13.py -- applies pass 13a of round 17 (docs/round17/pass13a/apply.json: the path of the clock sum, Lévy's C curve and the
Heighway dragon on the labels, and Duvall and Keesling's count of the boundary of the Lévy dragon) to the tables, with the release owner's acceptance of
docs/round17/pass13a/RESULT.md §6.

Modelled on docs/round15/apply_pass12.py. Idempotent: a second run writes the same bytes (the sha256 of every touched file is printed at the end), also
after npm run content. Every input is checked before the first file is written. In order:
  1 content/rows.json        LAB-026 and LAB-027 after LAB-025 (the order of the ids, the order tools/merge_story.mjs sorts the rows in), since v3.1, both
                             computations (stage A), the key order of the rows of the proofs passes; the two ids free (LAB-5xx and LAB-7xx are story rows;
                             a row that holds one of the two ids and is not an earlier copy of this pass stops the script); every (page, order) free
                             page-wide (in the rows, the story overlay's layouts and the chains overlay's placements), the section a section of its page:
                             clock · clock at 28 and 29, role detail, the rows' only placements (their home)
  2 content/texts.json       their research texts (status draft, source pass13a:clock-walk), each after the texts of the row before it (the order of
                             tools/merge_story.mjs: by row, then level); no learner text
  3 content/checks.json      the check record of clock_walk.py (cw.PATH, cw.GRAY, cw.ORD, cw.DK, cw.LAM), after ten_pairings.py
  4 content/check_runs.json  its run record: the stored log ends with the record's last line, its tagged check lines count the record's checks and tags
                             (14: bit 4, bit==std 5, ctl 3, std 2), and its fault log holds the five wrong versions in order, each exit 1, with as many FAIL
                             lines as its own last line counts (GRAY 7, F2FIRST 1, NOPARITY 9, NOSTAR 2, MIRROR 5)
  5 content/lenses.json      geo 79 -> 81 (the path of the clock sum; the boundary of the dragon on the labels), appended after the lens's own entries,
                             each with the keys, in their order, of the lens's entries
  6 engines/MANIFEST.json    the entry of the fragment engines/physics/MANIFEST.p14.json (physics/clockWalk.js) after the entry of physics/fibreBase.js,
                             as the fragments p4 ... p13 stand merged there (tests/physics.test.mjs reads every fragment's entry in it)
  7 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence and by text)
The figures (content/physics/figures.p14.json) are merged by tools/merge_physics.mjs in npm run content; their placement needs no table: a body
section draws the figures whose caption row it places (src/app/queries.js). No analysis is named by the pass: content/analyses.json is not touched.
Each table keeps its own JSON form (indent 1, UTF-8, with or without the final newline it had); a table whose text a load and dump would change
stops the script before anything is written.
Usage (from anywhere): python3 docs/round17/apply_pass13.py [--no-node]    --no-node skips step 7
"""
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
said = []
pending = {}   # rel -> text: the tables are written together once every input is checked
TOUCHED = []   # every file this script may write, for the sha256 line at the end


def path(rel):
    return os.path.join(ROOT, rel)


def dump(data, newline):
    return json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    data, nl = json.loads(raw), raw.endswith('\n')
    assert dump(data, nl) == raw, f'{rel}: a load and dump would change its text (its JSON form is not indent 1, UTF-8): stop'
    return data, nl


def stage(rel, data, newline):
    """the table's new text, written by flush() once every check of steps 1 to 6 has passed"""
    pending[rel] = dump(data, newline)
    if rel not in TOUCHED:
        TOUCHED.append(rel)


def flush():
    for rel, text in pending.items():
        old = open(path(rel), encoding='utf-8').read()
        if text != old:
            open(path(rel), 'w', encoding='utf-8').write(text)
            said.append(f'wrote {rel}')
        else:
            said.append(f'unchanged {rel}')
    pending.clear()


def node(args, what):
    out = subprocess.run(['node', *args], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    if out.returncode:
        sys.stdout.write(out.stdout[-4000:])
        sys.stderr.write(out.stderr[-4000:])
        sys.exit(f'{what} failed')
    return out.stdout


# ---- the pass
P = json.load(open(os.path.join(HERE, 'pass13a', 'apply.json'), encoding='utf-8'))
IDS = ['LAB-026', 'LAB-027']
SCRIPT = 'checks/selfcheck/proofs/clock_walk.py'
SRC = 'pass13a:clock-walk'
CHECKS = ['cw.PATH', 'cw.GRAY', 'cw.ORD', 'cw.DK', 'cw.LAM']
EVIDENCE = {'LAB-026': ['cw.PATH', 'cw.GRAY', 'cw.ORD'], 'LAB-027': ['cw.DK', 'cw.LAM']}
FAULTS = [('GRAY', 7), ('F2FIRST', 1), ('NOPARITY', 9), ('NOSTAR', 2), ('MIRROR', 5)]
TAGS = {'bit': 4, 'bit==std': 5, 'ctl': 3, 'std': 2}
LAST = 'clock_walk: 14 checks, 0 fail'
WHERE = {'LAB-026': [('clock', 'clock', 28)], 'LAB-027': [('clock', 'clock', 29)]}
AFTER = 'LAB-025'                                   # the row the pass's rows follow (the ids sorted)
LENS_N0, LENS_ADD = 79, 2                           # the dictionary of the lens geo in 3.0.0, and the entries the pass adds
FORM_ROW = 'GEN-033'                                # a row of the proofs passes: the key order of the new rows
MANIFEST_FRAGMENT = 'engines/physics/MANIFEST.p14.json'

assert P['pass'] == '13a' and P['since'] == 'v3.1', (P['pass'], P['since'])
assert [r['id'] for r in P['rows']] == IDS, [r['id'] for r in P['rows']]
assert [t['row'] for t in P['texts']] == IDS, 'one research text per row, in the order of the rows'
assert P['row_text_edits'] == [] and P['analyses'] == [], 'the pass edits no text of another row and names no analysis'
assert P['files']['script'] == SCRIPT and all(os.path.exists(path(P['files'][k])) for k in ('script', 'log', 'faultLog')), P['files']
assert all(os.path.exists(path(d)) for d in P['files']['docs'] + P['files']['overlay']), [d for d in P['files']['docs'] + P['files']['overlay'] if not os.path.exists(path(d))]
said.append('checked docs/round17/pass13a/apply.json (pass 13a, since v3.1; the rows, texts, check, run, lens entries and the overlay p14 present)')

# ===================================================================================================================== 1 rows
rows, rows_nl = load('content/rows.json')


def earlier_copy(r):
    """a row of this pass written by an earlier run: since v3.1, its group, every evidence the pass's script"""
    return (r.get('since') == 'v3.1' and r.get('group') == r['id'][:3] and bool(r.get('evidence'))
            and all(e.get('script') == SCRIPT for e in r['evidence']))


clash = [r['id'] for r in rows if r['id'] in IDS and not earlier_copy(r)]
if clash:
    sys.exit(f'the ids {clash} are taken by other rows of content/rows.json: renumber the pass from the next free id of its group')
rows = [r for r in rows if r['id'] not in IDS]
assert [r['id'] for r in rows] == sorted(r['id'] for r in rows), 'content/rows.json is not in the order of the ids (tools/merge_story.mjs sorts it): run npm run content'
layouts = []
for rel in sorted(os.listdir(path('content/story'))):
    if rel.endswith('.json') and rel not in ('merged.json', 'rows.json', 'texts.json'):
        x = json.load(open(path(f'content/story/{rel}'), encoding='utf-8'))
        lay = x if rel == 'layout.json' else (x.get('layout') if isinstance(x, dict) else None)
        if isinstance(lay, list):
            layouts += [l for l in lay if isinstance(l, dict) and 'page' in l and 'order' in l]
for owner in sorted(os.listdir(path('content/chains'))):
    f = path(f'content/chains/{owner}/page.json')
    if os.path.exists(f):
        layouts += json.load(open(f, encoding='utf-8')).get('layout') or []
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])} | {(l['page'], l['order']) for l in layouts}
mine = [(pg, o) for rid in IDS for pg, _, o in WHERE[rid]]
assert len(mine) == len(set(mine)) and not set(mine) & taken, f'an order of the pass is taken (page-wide) or used twice: {sorted(set(mine) & taken)}'
pages = json.load(open(path('content/pages.json'), encoding='utf-8'))
sections = {p['route']: {s.get('id') for s in p.get('sections') or []} for p in pages}
form = list(next(x for x in rows if x['id'] == FORM_ROW).keys())
ids = {r['id'] for r in rows} | set(IDS)
for r in P['rows']:
    rid = r['id']
    assert r['since'] == 'v3.1' and r['group'] == 'LAB' and (r['kind'], r['stage'], r['ptype']) == ('computation', 'A', 'identity'), rid
    assert list(r.keys()) == form, f'{rid}: the keys of a row of the proofs passes, in their order'
    assert [(s['page'], s['section'], s['order']) for s in r['shownOn']] == WHERE[rid], rid
    assert all(s['role'] == 'detail' and s['section'] in sections.get(s['page'], ()) for s in r['shownOn']), f'{rid}: a role or a section'
    assert [e['check'] for e in r['evidence']] == EVIDENCE[rid] and all(e['mode'] == 'ran' and e['script'] == SCRIPT for e in r['evidence']), rid
    assert r['legacyFlags'] == ['checked'] and r['visibleTo'] == ['phys', 'math'], rid
    for d in r['depends']:
        assert d['id'] in ids and d['rel'] == 'derives', f'{rid} depends on {d}'
assert sorted(c for v in EVIDENCE.values() for c in v) == sorted(CHECKS), 'every check id is some row\'s evidence'
for r in P['rows']:
    at = next(i for i, x in enumerate(rows) if x['id'] > r['id'])
    assert rows[at - 1]['id'] in (AFTER, *IDS), (r['id'], rows[at - 1]['id'])
    rows.insert(at, dict(r))
order = [r['id'] for r in rows]
assert order == sorted(order) and [i for i in order if i in IDS] == IDS and order.index(AFTER) + 1 == order.index('LAB-026'), 'the two rows after LAB-025'
said.append('rows: ' + '; '.join(f"{r['id']} on " + ', '.join(f"{s['page']} · {s['section']} {s['order']}" for s in r['shownOn']) for r in P['rows']))

# ===================================================================================================================== 2 texts
texts, texts_nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'], t.get('chain'))
mine_t = {key(t) for t in P['texts']}
texts = [t for t in texts if key(t) not in mine_t]
assert not any(t['row'] in IDS for t in texts), 'another text of the two rows stands in content/texts.json (no learner text in this pass)'
form_t = list(next(t for t in texts if t['row'] == FORM_ROW and t['level'] == 'research').keys())
for t in P['texts']:
    assert list(t.keys()) == form_t, f"{t['row']}: the keys of a research text"
    assert (t['status'], t['source'], t['level'], t['lens'], t['mode'], t['register'], t['lang']) == ('draft', SRC, 'research', None, 'both', 'full', 'en'), t['row']
    assert not re.search(r'/home/|/Users/|@[\w-]+\.\w|docs/round|SOURCES\.md', t['body']), f"{t['row']}: a machine path, a folder path or a contact detail"
for t in P['texts']:
    prev = {'LAB-026': AFTER, 'LAB-027': 'LAB-026'}[t['row']]
    at = max(i for i, x in enumerate(texts) if x['row'] == prev) + 1
    texts.insert(at, dict(t))
j = max(i for i, x in enumerate(texts) if x['row'] == 'LAB-027')
assert texts[j + 1]['row'] > 'LAB-027' and texts[j - 1]['row'] == 'LAB-026', 'the texts of LAB-026 and LAB-027 out of row order'

# ===================================================================================================================== 3 the check record
checks, checks_nl = load('content/checks.json')
cid = SCRIPT[len('checks/'):]
checks = [c for c in checks if c['id'] != cid]
assert checks[-1]['id'] == 'selfcheck/proofs/ten_pairings.py', checks[-1]['id']
assert not any(x['id'] in CHECKS for c in checks for x in c.get('ids') or []), 'a cw.* id in another record'
form_c = list(checks[-1].keys())
assert len(P['checks']) == 1
c = P['checks'][0]
assert list(c.keys()) == form_c and c['id'] == cid and c['since'] == 'v3.1' and c['script'] == SCRIPT and c['log'] == P['files']['log'], c['id']
assert [x['id'] for x in c['ids']] == CHECKS and c['rowsNaming'] == IDS, c['id']
assert f"{sum(TAGS.values())} checks ({', '.join(f'{k} {v}' for k, v in TAGS.items())})" in c['notes'], c['notes'][:160]
checks.append(c)
stage('content/checks.json', checks, checks_nl)

# ===================================================================================================================== 4 the run record
runs, runs_nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
runs = [r for r in runs if rk(r) not in {rk(x) for x in P['check_runs']}]
run_form = list(runs[-1].keys())
TAG = re.compile(r'^  (ok|FAIL) +\[(bit|bit==std|ctl|std)\] ')
name = os.path.basename(SCRIPT)[:-len('.py')]
total = sum(TAGS.values())
log = open(path(P['files']['log']), encoding='utf-8').read().rstrip('\n').split('\n')
hits = [m for m in map(TAG.match, log) if m]
tags = {k: sum(1 for m in hits if m.group(2) == k) for k in TAGS}
assert all(m.group(1) == 'ok' for m in hits) and len(hits) == total and tags == TAGS, tags
assert log[-1] == LAST == f'{name}: {total} checks, 0 fail', log[-1]
tagword = ', '.join(f'{k} {v}' for k, v in TAGS.items())
assert len(P['check_runs']) == 1
r = P['check_runs'][0]
assert r['script'] == SCRIPT and r['source'] == P['files']['log'] and list(r.keys()) == run_form, r['script']
assert r['passed'] is True and r['ok'] == total and r['fail'] == 0 and r['lastLine'] == log[-1], r['script']
assert f'tags {tagword}' in r['status'] and f'{len(FAULTS)} --fault runs each exit 1' in r['status'], r['status']
got = []
for b in re.split(r'^(?=--fault )', open(path(P['files']['faultLog']), encoding='utf-8').read(), flags=re.M):
    if not b.strip():
        continue
    head = re.match(r'--fault (\w+): exit 1\n', b)
    last = re.search(rf'^last: {name}: (\d+) checks, (\d+) fail$', b, re.M)
    nfail = len(re.findall(r'^  FAIL +\[', b, re.M))
    assert head and last and int(last.group(1)) == total and int(last.group(2)) == nfail >= 1, b[:80]
    got.append((head.group(1), nfail))
assert got == FAULTS, got
for txt in (open(path(P['files']['log']), encoding='utf-8').read(), open(path(P['files']['faultLog']), encoding='utf-8').read()):
    assert not re.search(r'(?<![\w.~%-])/(home|Users|tmp)/[\w.-]', txt), 'a machine path in a stored log'
runs.append(r)
said.append(f"{SCRIPT}: {log[-1]} (tags {tagword}); faults {', '.join(f'{f} {k}' for f, k in got)}, each exit 1")
stage('content/check_runs.json', runs, runs_nl)

# ===================================================================================================================== 5 the lens geo
lenses, lenses_nl = load('content/lenses.json')
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows'] and e['atlas'] == f['atlas']
blk = P['lens_geo']
assert blk['key'] == 'geo' and len(blk['dictionary_add']) == LENS_ADD
for e in blk['dictionary_add']:
    assert e['evidence'] and set(e['evidence']) <= set(CHECKS) and e['rows'] and set(e['rows']) <= set(IDS), e['atlas'][:40]
    assert e['flags'] == ['checked'] and e['from'].endswith('(pass 13a)') and e['matrixRows'] == [], e['from']
    assert all(set(EVIDENCE[x]) <= set(e['evidence']) for x in e['rows']), (e['rows'], e['evidence'])
lens = next(x for x in lenses if x['key'] == 'geo')
form_l = list(lens['dictionary'][0].keys())
assert all(list(e.keys()) == form_l for e in lens['dictionary'] + blk['dictionary_add']), 'geo: an entry in another form than the lens keeps'
keep_l = [e for e in lens['dictionary'] if not e['from'].endswith('(pass 13a)') and not any(same(e, f) for f in blk['dictionary_add'])]   # an earlier copy of the pass's entries, whatever its words
assert len(keep_l) == LENS_N0, len(keep_l)
lens['dictionary'] = keep_l + blk['dictionary_add']
said.append(f"the lens geo: {LENS_N0} -> {len(lens['dictionary'])} dictionary entries")
stage('content/lenses.json', lenses, lenses_nl)

# ===================================================================================================================== 6 the merged manifest
man, man_nl = load('engines/MANIFEST.json')
frag = json.load(open(path(MANIFEST_FRAGMENT), encoding='utf-8'))
assert len(frag) == 1 and frag[0]['to'] == 'physics/clockWalk.js' and re.search(r'labels\.js', frag[0]['kernel']) and frag[0]['storedJson'] is None
assert re.search(r'tests/physics/p14\.test\.mjs', frag[0]['test']) and frag[0]['figures'] == ['clock-walk', 'dragon-blades'], frag[0]['figures']
man = [e for e in man if e.get('to') != 'physics/clockWalk.js']
at = next(i for i, e in enumerate(man) if e.get('to') == 'physics/fibreBase.js') + 1
man.insert(at, frag[0])
stage('engines/MANIFEST.json', man, man_nl)
said.append('engines/MANIFEST.json: the entry of physics/clockWalk.js after physics/fibreBase.js')

# ===================================================================================================================== 1, 2: the rows and the texts staged
stage('content/rows.json', rows, rows_nl)
stage('content/texts.json', texts, texts_nl)
flush()   # every input of steps 1 to 6 checked: the tables written together
TOUCHED += ['content/lens_readings.json']

if not NO_NODE:
    # ================================================================================================================= 7 the lens readings
    out = node(['tools/migrate/lens_readings.mjs'], 'tools/migrate/lens_readings.mjs')
    sys.stdout.write(out[-600:])
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    mine_lr = [x for x in lr if x['row'] in IDS]
    said.append(f'ran tools/migrate/lens_readings.mjs: {len(lr)} readings, {len(mine_lr)} on the two rows ('
                + ', '.join(f"{k} {sum(1 for x in mine_lr if x['lens'] == k)}" for k in sorted({x['lens'] for x in mine_lr})) + ')')

print('\n'.join(said))
print('sha256 of the files this script touches:')
for rel in TOUCHED:
    print(f"  {hashlib.sha256(open(path(rel), 'rb').read()).hexdigest()}  {rel}")
