<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 13b, the result: the clock's phase as Weil's index

Script `checks/selfcheck/proofs/weil_index.py`: 14 checks (bit 6, bit==std 3, ctl 3, std 2), 0 fail, about 7 s alone; four `--fault` options, each run ending with FAIL lines and exit 1 (CHI 5 failing lines, NOPARITY 9, COUNTING 5, CONJ 1). Logs `checks/selfcheck/proofs/logs/weil_index.log` and `weil_index.faults.log`. Run from `checks/` as `python3 -I -B selfcheck/proofs/weil_index.py`; the last line is `weil_index: 14 checks, 0 fail`; from its own folder and on a second run the check lines are identical. Standard library only.

Conventions (stated in the script and in the row): the kernel's labels, generator i = bit i; a cell (p, q) with its p generators of square +1 first; w(a) = (|a| mod 2) + 2[e_a² = −1] read from the kernel's squares, f = i^{w}; the labels identified with their dual by (−1)^{a·b}; the counting measure on the labels; Weil's Fourier transform Φ*(y) = Σ_x Φ(x)(−1)^{x·y}; over ℝ the character χ(t) = e^{2πiλt} and the pairing ⟨x, y⟩ = χ(xy); Gaussian integers as pairs of integers, the real index in floating point.

## 1. Predicted (BEFORE.md) against what ran

All of it came out. What the prediction did not say, or said otherwise:

- **The scalar is Weil's definition, not only his corollary.** Relation (9), lifted with the operators of n° 13, holds with one Gaussian scalar for each of the 45 cells with n ≤ 8, and the scalar divided by 2^{n/2} is the clock's phase: on the labels γ(i^{w}) is the number by which the modular relation (t₀ d′₀)³ = e fails to lift, (t₀ d′₀)³ = e^{iπ(p−q)/4}·1 (n ≤ 6; for one generator the familiar e^{iπ/4}).
- **The dual measure carries the modulus.** With the counting measure on the dual the scalar of (9) is the clock sum itself, of modulus 2^{n/2}; Weil's dual measure 2⁻ⁿ makes it of modulus 1, and the phase is the same either way (COUNTING).
- **The parity-free form gives the type, not the clock.** Without the parity term the bicharacter is the commutation form, ρ = J − I: degenerate for odd n (no index), and for even n ≤ 6 relation (9) holds with γ = Σ_a e_a² / 2^{n/2} = +1 for p − q ≡ 0, 2 mod 8 and −1 for p − q ≡ 4, 6 (the count GEN-032 reads the type from), never ±i (checked for n ≤ 6; for every n, as J − I is singular over 𝔽₂ exactly when n is odd and Corollary 2 gives γ = Σ e_a² / 2^{n/2}). The eighth roots need the ℤ₄ lift: as γ(conj f) = conj γ(f), a real f has γ = ±1, the analogue on the labels of Weil's remark of n° 25 (γ = ±1 when −1 is a square).
- **The cell (1, 1) and Weil's hyperbolic form are not the same character.** The labels' i^{w} on (1, 1) has ρ the identity (the dot product), Weil's (−1)^{x·x*} has ρ the exchange of the two halves; both are non-degenerate with γ = 1, the first computed, the second the corollary of Theorem 5.
- Nothing was weakened: LAB-017, LAB-018, LAB-022, ATY-033, GEN-032 and the figure `gauss-sum` stand as they are; the row says what Weil's frame adds.

## 2. The answers

**The normalisation (A70).** Over ℝ, with χ(t) = e^{2πiλt}, Weil's index of a form of inertia type (a, b) is e^{iπ(a−b)/4} for λ > 0 and e^{−iπ(a−b)/4} for λ < 0 (n° 26; Proposition 3). The form v ↦ v² of the cell (p, q) has inertia type (p, q). So the clock's phase e^{iπ(p−q)/4} is Weil's index of the real form of the cell for λ > 0, the index of x ↦ e^{2πiQ(x)}, the character the labels' phase e^{2πi w(a)/4} matches; for λ < 0 it is the phase of the mirror cell (q, p). It does not depend on the Haar measures (n° 24) nor on the size of λ.

**On the labels.** i^{w} is a non-degenerate character of the second degree of the group of labels in Weil's sense (n° 1), and its index is the clock's phase, by his definition (relation (9) lifted, n° 14; the lifted cube carries the same scalar, which Weil does not state but the lifts of n° 13 give), by his Corollary 2 (the clock sum over 2^{n/2}), and his Theorem 2 applied to the labels gives ATY-033's law with his constants. Proposition 3 and formula (28) are stated for forms over local fields; on the labels the script checks that γ has the same properties.

**Why they agree.** Weil's Theorem 5 on ℝⁿ × labels, with Γ′ = {(x, 2x mod 2)}: its hypotheses hold (computed; the annihilator for the pairing e^{2πi x·z}(−1)^{a·b}), so γ(f′) = 1, and since γ multiplies over products and γ(conj f) = conj γ(f) — Weil states both for forms (the proof of Proposition 3, n° 25); for any locally compact abelian groups they follow from Corollary 2 on a product with a real Φ — the real index and the labels' are one. In the language of lattices the labels with i^{w} are the discriminant form of ℤⁿ with Gram matrix 2·diag(ε), the even lattice A₁^p ⊕ A₁(−1)^q, and LAB-017 is Milgram's formula for it (recalled).

## 3. What ran

| id | what | route | scope |
|---|---|---|---|
| wi.DEF | relation (1) on all pairs; the dual measure from the inversion formula; relation (9) lifted, its scalar, the cube; Corollary 2 | the kernel's squares; Weil's operators on the 2ⁿ indicators (n ≤ 6) and through the kernel of d′₀ t₀ d′₀ (n = 7, 8); Gaussian integers | the 45 cells with n ≤ 8 (757 305 pairs) |
| wi.FT | Theorem 2 at every label | the fast Walsh–Hadamard transform on Gaussian integers | the 66 cells with n ≤ 10 (20 481 labels) |
| wi.REAL | γ(q₁) by Weil's recipe; the inertia of v ↦ v²; the real index against the labels' | trapezoid rule and the closed form (floating point); exact congruence diagonalisation | λ = ±½, ±¾, ±1; the 66 cells |
| wi.WITT | orthogonal sums, the mirror cell, (1, 1), the corollary of Theorem 5, formula (28), the eight values | the kernel's squares; Gaussian integers | 406 pairs of cells (n₁ + n₂ ≤ 8); m ≤ 4; the 66 cells |
| wi.T5 | the lattice's discriminant form and its Gauss sum; the labels as that form; Theorem 5's hypotheses and conclusion | Fractions; the quadrature for the conclusion | the 66 cells (translates for n ≤ 4) |

## 4. Controls

Three `[ctl]` lines in the main run: the opposite character makes the real index differ from the labels' for the 48 cells with p − q ≢ 0, 4 mod 8 (n ≤ 10) and f′ non-trivial on Γ′ (CHI); the parity-free form is degenerate for the 30 cells with odd n ≤ 9 and has γ = ±1 for even n ≤ 6, differing from the clock for the cells with p − q ≡ 2, 6 mod 8 (NOPARITY); the counting measure on the dual gives |γ| = 2^{n/2}, and f′ without the conjugate is not 1 on Γ′ (COUNTING, CONJ). Under `--fault X` each wrong version is put in the main lines, which then fail: CHI 5 lines, NOPARITY 9, COUNTING 5, CONJ 1, each run exit 1.

## 5. The standard route

Never the labels: Weil's recipe of n° 26 for the real index (Corollary 2 by quadrature, and the closed form of his elementary calculation), and the discriminant form of the lattice ℤⁿ with Gram matrix 2E, computed from the lattice. The kernel's labels are the bridge of the bit==std lines.

## 6. Proposed row, lens entries (apply.json)

| id | title | evidence | placed |
|---|---|---|---|
| LAB-028 | Weil's index and the clock: the scalar of his relation (9) on the labels, the real form's index for λ > 0, Theorem 5 between them | wi.DEF, wi.FT, wi.REAL, wi.WITT, wi.T5 | clock · clock 30 |

`since: "v3.2"`, role detail, kind computation, stage A, ptype identity, `legacyFlags: ["checked"]`; its research text a draft (`source: "pass13b:weil-index"`); no learner text; no figure. Two entries of the lens alg (155 → 157): Weil's index on the labels and over ℝ; Theorem 5 on ℝⁿ × labels and the discriminant form.

## 7. Defects and open points

- **Weil's theorems are applied, not re-proved.** Theorem 2, Corollary 2, Theorem 5 and Proposition 3 are read; the script computes their hypotheses and their conclusions on the cases named.
- **The real index is computed in floating point** (to 10⁻¹² for q₁; the cells' indices from it by Proposition 3, to 10⁻⁹); the labels' side is exact.
- **Milgram's formula** in general is recalled, not read; only its case A₁^p ⊕ A₁(−1)^q is computed.
- **The physics reading** is a reading: on ℝⁿ the eighth root of unity by which the lift of (9) fails in the Segal–Shale–Weil representation (Weil identifies his representation with Shale's for k = ℝ, n° 44), the phase of the Gaussian integral of e^{2πiQ}; on the labels his operators are the qubit gates S^{⊗p}(S†)^{⊗q} and H^{⊗n} (for one qubit (SH)³ = e^{iπ/4}), which is not the oscillator representation. The metaplectic group itself (Chapters III–IV) is read, not built on the labels.
- **wi.T5's last comparison repeats wi.REAL's numbers**; what the line adds is the hypotheses of Theorem 5 (the CONJ fault fails only them). f′ = 1 is computed on the classes a/2 (and their translates for n ≤ 4); all of Γ′ follows from Q(x + m) − Q(x) ∈ ℤ.
- **No learner words, no figure.** A picture of the real index (the Fresnel spiral of e^{2πiλx²}, whose chord points along e^{±iπ/4}) beside the clock walk would be the natural figure.

## 8. Not done

- The metaplectic group of the labels and Weil's Theorem 1 on them (the automorphisms of the labels' Heisenberg group that fix its centre, as unitary operators).
- Cells with null generators.
- Weil's adelic Proposition 5 and the law of quadratic reciprocity.
