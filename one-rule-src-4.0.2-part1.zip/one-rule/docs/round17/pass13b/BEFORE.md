<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 13b, before the script: the clock's phase as Weil's index

What the Atlas's rows and the source read for this pass said, and what the prototypes of the reading gave, before `checks/selfcheck/proofs/weil_index.py` was written. The question is A70 (`docs/DECISIONS.md`): the clock sum (1 + i)^p(1 − i)^q = 2^{n/2} e^{iπ(p−q)/4} is a finite Gauss sum, and its phase was recalled as Weil's index of the real quadratic form of signature (p, q) "up to the conventions of the character and of the sign". Which conventions, and is the statement true as the Atlas would print it?

The hand algebra is the Atlas's own: the kernel `researchers_checks/bitrule_A.py` (e_a e_b = s(a,b) e_{a xor b}; generator i = bit i); a cell (p, q) has its p generators of square +1 first (`core_check.sig`); the ℤ₄-form of the labels w(a) = (|a| mod 2) + 2[e_a² = −1] (core.B1) and its phase f(a) = i^{w(a)}; the clock sum Σ_a f(a) = (1 + i)^p(1 − i)^q (LAB-017).

## What the rows say

- **LAB-017**: the exponent of the clock sum is w; its Gauss sum is (1 + i)^p(1 − i)^q, so the clock is the Brown invariant of (V, w).
- **LAB-018**: w(a) = x·x mod 4 for the 0/1 vector x of a in the lattice I_{p,q}; the clock is the signature of I_{p,q} mod 8 (Brown's theorem, read through Taylor).
- **LAB-022, CAND-057**: w(a ⊕ b) = w(a) + w(b) + 2 a·b mod 4; w adds on disjoint labels, for every n.
- **ATY-033**: the finite theta law Σ_a i^{w(a)} (−1)^{a·b} = G i^{−w(b)}, G the clock sum (the reading as a theta law is the Atlas's).
- **GEN-032**: the count Σ_a e_a² = Re((1 − i)G) decides the type of a cell.
- No row names Weil, his index, or the character of ℝ the phase belongs to.

## The source

A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964) 143–211, read in full (69 pages: Chapters I to V and the bibliography). What the pass uses:

- **n° 1**: a *character of the second degree* f of a locally compact abelian group G: (x, y) ↦ f(x + y) f(x)⁻¹ f(y)⁻¹ is a bicharacter, written ⟨x, yρ⟩ (relation (1)) with ρ = ρ(f) a symmetric morphism of G into its dual G*; f is non-degenerate when ρ is an isomorphism. When x ↦ 2x is an automorphism of G every symmetric ρ comes from f_ρ(x) = ⟨x, 2⁻¹xρ⟩; on the group of labels it is not (2x = 0), which is why the Atlas needs a ℤ₄-valued w.
- **n° 2**: the Fourier transform Φ*(x*) = ∫ Φ(x) ⟨x, x*⟩ dx, the dual measure (the one for which Φ(x) = ∫ Φ*(x*) ⟨x, −x*⟩ dx*), the module |α| of an isomorphism.
- **n° 6–7, 13**: the elements d₀(α), d′₀(γ), t₀(f) of B₀(G) and their lifts to unitary operators, t₀(f)Φ(x) = Φ(x) f(x) and d′₀(γ)Φ(x) = |γ|^{−1/2} Φ*(−xγ*⁻¹); relation (9), d′₀(−ρ⁻¹) t₀(f) d′₀(ρ⁻¹) t₀(f⁻) = t₀(f⁻¹) d′₀(−ρ⁻¹), which Weil also writes (t₀(f) d′₀(−ρ⁻¹))³ = e and notes is well known in the classical theory of the modular group.
- **n° 14**: lifted, the two sides of (9) differ by a scalar of absolute value 1, γ(f); Theorem 2: the Fourier transform of f is γ(f) |ρ|^{−1/2} f(x*ρ⁻¹)⁻¹; Corollary 2: ∫(∫ Φ(x − y) f(y) dy) dx = γ(f) |ρ|^{−1/2} ∫ Φ(x) dx. For a group of local type these numbers are eighth roots of unity, related to Gauss sums.
- **n° 20**: Theorem 5: if f = 1 on a closed subgroup Γ and ρ is an isomorphism of (G, Γ) onto (G*, Γ_*), then γ(f) = 1; its corollary: f(x, x*) = ⟨x, x*⟩ on G × G* is non-degenerate with γ = 1. Weil notes that Theorem 5 on a group of adelic type contains the law of quadratic reciprocity (carried out in n° 30).
- **n° 22**: products of groups and of characters of the second degree.
- **n° 23–26**: a quadratic form f on a vector space over a local field k, a non-trivial character χ of k, γ(f) = γ(χ∘f), which depends on χ and not on the Haar measures; γ(f∘α) = γ(f), γ(−f) = γ(f)⁻¹; Proposition 3: f ↦ γ(f) is a character of the Witt group of k (γ(f₁ ⊕ f₂) = γ(f₁)γ(f₂), and γ = 1 on the trivial class by the corollary of Theorem 5). Over ℝ: χ(x) = e^{2πiλx} with λ real non-zero, a form of inertia type (a, b) has γ(f) = γ(q₁)^{a−b}, and Corollary 2 with Φ(x) = e^{−πx²} gives γ(q₁) = e^{πi/4} if λ > 0 and e^{−πi/4} if λ < 0; γ(q₄) = −1 for the norm of the quaternions.
- **n° 25, 28**: if −1 is a square in k (so in characteristic 2) then γ(f) = ±1; formula (28), γ(f)² = (D/−1) γ(q₁)^{2m} with D the discriminant; γ(f)⁸ = 1.
- **n° 27**: for a field with a discrete valuation, γ(f) is a normalised Gauss sum.
- Not used beyond the reading: the adelic case and Proposition 5 (n° 29–30), the metaplectic group (Chapter III), its reduction to a double cover (Chapter IV: there γ detects that the cover is not trivial), Chapter V. In his introduction Weil points out that the case of finite groups might deserve a closer look from the point of view of the memoir, with a pointer to Kloosterman (1946); the group of labels is such a finite group.

## Predictions

1. **i^{w} is a non-degenerate character of the second degree of the labels** (wi.DEF). By core.B1, f(a ⊕ b) f(a)⁻¹ f(b)⁻¹ = (−1)^{a·b}: ρ is the identity when the labels are identified with their dual by the dot product.
2. **Its index is the clock's phase** (wi.DEF, wi.FT). With the counting measure on the labels the dual measure is 2⁻ⁿ·(counting), |ρ| = 2⁻ⁿ, and Corollary 2 with Φ the indicator of 0 gives Σ f = γ 2^{n/2}: γ(i^{w}) = (1 + i)^p(1 − i)^q / 2^{n/2} = e^{iπ(p−q)/4}. Relation (9) lifted holds with that scalar, and Theorem 2 is ATY-033's law.
   - *Prototype (n ≤ 6):* (9) column by column on the 2ⁿ indicators: one Gaussian scalar per cell, equal to (1 + i)^p(1 − i)^q; for one generator (t₀ d′₀)³ = e^{iπ/4}.
3. **The real normalisation** (wi.REAL). The form v ↦ v² of Cl(p, q) has inertia type (p, q); with χ(t) = e^{2πiλt}, λ > 0, its index is e^{iπ(p−q)/4}, the labels' γ; with λ < 0 the conjugate, the mirror cell's.
   - *Prototype:* Corollary 2 by the trapezoid rule, inner integral first: γ(q₁) = e^{±iπ/4} for λ = ±½, ±¾, ±1 to 10⁻¹⁴, the modulus (2|λ|)^{−1/2}.
4. **Proposition 3's properties on the labels** (wi.WITT): γ multiplies over the cell with the generators of two cells, the mirror cell conjugates it, the cell (1, 1) has γ = 1; Weil's corollary of Theorem 5 holds for (−1)^{x·x*}; formula (28) holds with D = ∏ e_j² = (−1)^q.
5. **Theorem 5 explains the agreement** (wi.T5). On G′ = ℝⁿ × labels, f′ = e^{2πiQ} ⊗ conj(i^{w}) with Q(x) = Σ_j ε_j x_j² is 1 on Γ′ = {(x, 2x mod 2) : x ∈ (½ℤ)ⁿ}, and ρ′(x, a) = (2Ex, a) maps Γ′ onto its annihilator {(z, z mod 2) : z ∈ ℤⁿ}; so γ(e^{2πiQ}) = γ(i^{w}). Equivalently the labels with i^{w} are the discriminant form of the even lattice ℤⁿ with Gram matrix 2E (A₁^p ⊕ A₁(−1)^q), and LAB-017 is Milgram's formula for it.
6. **Controls.** The opposite character (CHI) conjugates the real index; without the parity term (NOPARITY) f is real, so γ = ±1 where it is defined (Weil's n° 25 in another form); the counting measure on the dual (COUNTING) gives a scalar of modulus 2^{n/2}; Theorem 5 without the conjugate (CONJ) loses its hypothesis.
   - *Prototype (NOPARITY, n ≤ 6):* the bicharacter is the commutation form, ρ = J − I, degenerate for odd n; for even n the scalar of (9) is Σ_a e_a² = ±2^{n/2}.

## Not to be computed here

Weil's theorems themselves (read; applied with their hypotheses computed); the metaplectic group and its double cover; Milgram's formula in general (recalled); cells with null generators (the form is degenerate there and no index is defined).
