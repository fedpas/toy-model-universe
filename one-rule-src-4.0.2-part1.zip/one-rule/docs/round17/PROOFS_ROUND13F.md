<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The proofs round, pass 13f: a finite analogue of the formula of Weil's n° 52 on the labels

Weil's memoir (A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111, 1964) ends with the formula that its successor proves (n° 52). For the rational points of a module over a simple algebra with an involution, the theta series integrated over the adelic quotient of the unitary group equals a sum over the classes of a parabolic subgroup, in today's name an Eisenstein series. The introduction says it generalises classical results of Siegel; it is the Siegel–Weil formula. Pass 13e (LAB-034) found on the labels the self-dual codes of labels of square +1, which exist only when p ≡ q mod 8, and up to n = 10 exactly then. This pass averages their theta functionals over all of them, the genus, and finds the finite counterpart of Weil's formula there.

One script under `checks/selfcheck/proofs/` (`weil_siegel.py`; 8 check lines, bit 1, bit==std 1, ctl 2, std 4, 0 fail, about 52 s alone; four fault runs, each ending with FAIL lines and exit 1: NOH with 5 failing lines, NOF 5, NOCROSS 4, FIXED 1; `logs/weil_siegel.log` and `logs/weil_siegel.faults.log` beside it). Run from `checks/` as `python3 -I -B selfcheck/proofs/weil_siegel.py`, it ends with `weil_siegel: 8 checks, 0 fail`; from its own folder and on a second run the check lines are identical. The pass's working records are `docs/round17/pass13f/BEFORE.md` (the reading, the dictionary and the predictions), `RESULT.md` and `apply.json`, applied by `docs/round17/apply_pass13f.py`.

## 1. What changes in the tables

- **LAB-035, the genus of the codes of labels and its counting formula** (ws.GENUS). For the 9 cells with p ≡ q mod 8, 2 ≤ n ≤ 10, the self-dual codes of labels of square +1 form one class under the orthogonal transvections of the labels' form. A label lies in every code, in N(n − 2) of them or in none (n ≤ 10), N(m) = Π_{i=0}^{m/2−2}(2^i + 1). Two labels lie together in N(n − 2(d − 1)) codes, d = dim span(ξ₁, ξ₂, 1), when the form is 1 on that span, and in none otherwise (n ≤ 8).
- **LAB-036, a finite Siegel–Weil formula on the labels** (ws.EIS, ws.SW). Weil's operators — the translation by the top label, its character, the multiplication by the form, the Fourier transform, and for genus 2 the cross term and the shears — generate a group D_g that commutes with those transvections (tested as operators; the form written without the kernel). Its orbit of δ₀ is the counterpart of the classes of P in Ps: when p ≡ q mod 8 it has one vector on each of its 6 (genus 1) or 60 (genus 2) lines and a non-zero sum; otherwise it carries δ₀ with the powers of the clock's phase and its sum is 0. The vectors invariant under both D_g and the transvections form a line when p ≡ q mod 8, spanned by the orbit sum (every cell with n even, n ≤ 10 for genus 1, n ≤ 6 for genus 2), and the average of the theta functional over the genus lies on it: it equals the orbit sum normalised at δ₀, exactly, for genus 1 (n ≤ 10) and genus 2 (n ≤ 6). In closed form for genus 1: E₁ = δ₀ + δ₁ + 2^{−n/2}(1 + (−1)^{ξ·1})(1 + f); E₁(δ₀) = 1 + 2^{2−n/2}, and E₂(δ₀) = (1 + 2^{2−n/2})(1 + 2^{3−n/2}). For (8,0) the average is the Hamming enumerator x⁸ + 14x⁴y⁴ + y⁸, its 30 codes being the copies of the extended Hamming code (computed).
- **Placement**: clock · clock at the orders 37 and 38, role detail; stage A, kind computation, ptype identity; `since: "v3.4"`.
- **The lenses**: alg (two entries, 163 → 165): the genus and its counting formula; the finite Siegel–Weil formula. fld (one entry, 86 → 87): ensembles of codes and the Eisenstein average.

## 2. What came out against the prediction

The genus, its counting formula of genus 1 and 2, the side of Weil's operators with its pattern of phases, and the formula for genus 1 and 2 all came out (RESULT.md §1). One control of BEFORE.md is no wrong version: without the translation and the character of the top label the orbit is unchanged, because F and H generate them (X = F², T = HXH, computed). The controls are NOH, NOF (the group without the multiplication by the form), NOCROSS and FIXED.

Beyond the prediction: the closed form of the orbit sum of genus 1; the constants E₁(δ₀) and E₂(δ₀) as products; the orbit sum 0 when p ≢ q mod 8; and the line of vectors invariant under both D_g and the transvections, from which the formula follows in the computed cells. RESULT.md §2 says what the analogue means — the integral over G_A/G_k as the average over the genus, the right side as the orbit sum. The clock at 0 decides two things: whether the genus is non-empty, and whether the orbit sum is non-zero, so that it can be normalised at δ₀. It also places the binary case next to the odd-p ensembles of code CFTs read holographically by Dymarsky, Henriksson and McPeak (consulted through a summary); binary code ensembles are treated elsewhere too (Kawabata, Nishioka, Okuda).

## 3. Sources

| source | how it is used | read |
|---|---|---|
| A. Weil, *Sur certains groupes d'opérateurs unitaires*, Acta Math. 111 (1964) 143–211 | n° 46–47 (the parabolic subgroup P(X) and its classes), n° 52 (the formula, stated), n° 40 (the lift r_k of Ps(X)_k), n° 13 and 16–21 (the operators and the theta functional) | in full (pass 13b); n° 52 a statement whose proof is in the next memoir, not read |
| A. Dymarsky, J. Henriksson, B. McPeak, *Holographic duality from Howe duality: Chern–Simons gravity as an ensemble of code CFTs*, arXiv:2504.08724 (2025) | the ensemble average of codes over 𝔽_p × 𝔽_p, p odd, as a Poincaré series by Howe duality; the holographic reading | consulted through a summary |
| T. Bouganis, J. Marzec-Ballesteros, *On an analogue of the doubling method in coding theory*, arXiv:2503.10201 (2025) | the Eisenstein series of genus g of codes as an average over the classes of a parabolic subgroup of the Clifford–Weil group | consulted through a summary and its §2.3 |
| K. Kawabata, T. Nishioka, T. Okuda, *Narain CFTs from qudit stabilizer codes*, arXiv:2212.07089 (2022) | ensembles of codes over prime dimensions, the binary ones among them | consulted through its abstract |
| Witt's theorem; the extended Hamming code and its enumerator; θ_{E₈} = E₄ | the names of what the computation finds | standard, recalled |
| LAB-028, LAB-033, LAB-034, CAND-026 | the form and the clock's phase, the theta functional, the codes, E₈ from the Hamming code | the Atlas's rows |

## 4. Defects and open points

- **The formula is an analogue**, its dictionary set out in BEFORE.md; Weil's own formula is read as a statement, its proof not read.
- **The computations stop at n = 10 (genus 1) and n = 6 (genus 2)**; no proof for every n; genus 3 not computed.
- **The invariant line for every n** is computed up to n = 10 (genus 1) and n = 6 (genus 2), not proved.
- **The condition of n° 52** (dim X > 4 dim Q) has no counterpart here, where the sums are finite; the computed cells of genus 2 lie outside its classical form (recalled).
- **The second sources were consulted through summaries.**
- **No learner words** (as LAB-026 to LAB-034).

## 5. What a next pass would be

Genus 2 for n = 8 and genus 3, with a faster transform; a proof for every n of the uniqueness of the invariant line; or the twistor programme that the owner has set next.
