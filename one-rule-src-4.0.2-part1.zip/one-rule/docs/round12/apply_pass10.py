#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round12/apply_pass10.py -- applies passes 10a, 10b and 10c of round 12 (docs/round12/pass10a/apply.json, Furey's construction on the
labels; docs/round12/pass10b/apply.json, the branching of the 16, the Majorana condition, fields that depend on x; docs/round12/pass10c/apply.json,
the null cells' classes and stages, the exact third stage, the wider standard routes, the limit as an ordered group) to the tables, the layout of
the story overlay and the Atiyah analysis page, in the order 10a, 10b, 10c (the page's items in the order of their numbers: 32 is 10c's, 33 10b's).

Modelled on docs/round11/apply_pass9.py. Idempotent: a second run writes the same bytes, also after npm run content. In order:
  1 content/rows.json        FUR-015 ... FUR-019 (10a) after FUR-014, FUR-020 ... FUR-026 (10b) after FUR-019 and GEN-021 ... GEN-026 (10c) after
                             GEN-020, since v2.13 (the eighteen ids are free: FUR-001 ... FUR-014 and GEN-001 ... GEN-020 stand, the FUR-5xx,
                             FUR-6xx and GEN-5xx ids are story rows; a row that holds one of the eighteen ids and is not an earlier copy of its pass
                             stops the script); every (page, order) of the three passes free page-wide (in the rows and in the story overlay's
                             layout), each section a section of its page; a row on cells, section cards, with a concrete first cell, n <= 8 (10c's
                             six: (0,0,8) and (8,0,0)); no row of 10a or 10b on the cells page. 10b's orders are the owner's (steps/baez 270 to 273,
                             steps/coupling 43 to 45: matter stays the rows' home, its orders 36 to 42 being the least). An entry on a page the story
                             overlay adds (matter/model: 10a's five, and the seven of 10b that R5 routes there, TAB_10B below, since every row whose
                             home is matter stands on a tab of the chapter) is not written here but by tools/merge_story.mjs from step 1b, which
                             appends it after the row's own entries and records it in its book (content/story/merged.json); a row keeps it here once
                             that book shows the merge wrote it, at the place the merge puts it, as apply_pass9.py does for FUR-007 ... FUR-014
 1b content/story/furey.json the layout entries (add: true) of 10a's and 10b's rows on matter/model, after those of FUR-014 (10a: sections axes and
                             edges, orders 1022 to 1026; 10b: section axes, 1027 to 1033); tools/migrate/verify_counts.mjs counts the overlay's
                             layout (976) and tests/story/furey.test.mjs lists the rows of that tab, both written with this release (R5)
  2 content/texts.json       their research texts (status draft; sources pass10a:furey-cl6, pass10b:branching-16, pass10c:null-stages), each after
                             the texts of the row before it (the order tools/merge_learner_texts.mjs keeps: by row, then level); then the two
                             row_text_edits, each one clause of a research draft of pass 9, the claim and its scope kept: FUR-012's "cited (...),
                             not computed" (10b: FUR-020 to FUR-022 compute the weights) and GEN-019's "Not computed: ... the ordered group of the
                             limit" (10c: GEN-026 computes it on the finite side)
  3 content/checks.json      the check records of checks/selfcheck/proofs/furey_cl6.py (fc.*), branching_16.py (br.*) and null_stages.py (ns.*),
                             after fibre_base.py
  4 content/check_runs.json  their run records: each stored log ends with the record's last line, its tagged check lines count the record's
                             checks and tags, and its fault log holds the pass's wrong versions in order, each exit 1, with as many FAIL lines
                             as its own last line counts (the counts of each RESULT.md)
  5 content/lenses.json      furey 24 -> 31 (five entries of 10a, two of 10b), alg 135 -> 142 (one of 10a, two of 10b, four of 10c), atiyah
                             103 -> 105 (10b's theme 6, 10c's theme 1), cat 154 -> 155 (10c); the blocks are lens_<key> (docs/round12/PLAN.md), a
                             block found by its key; each entry with the keys, in their order, of its lens's own entries, appended after them.
                             And one clause of pass 9a's furey entry on her Cl(6) over the reals (10a's notes): its match said her complex
                             ℂl(6) on ℂ ⊗ 𝕆 and her ladder operators "not reproduced", which fc.CPX and fc.CAR now reproduce; the match points
                             to FUR-015 and FUR-016 and stays partial (its own evidence, fb.OCT, computes the real form)
  6 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence)
  7 content/analyses.json    the check ids that the passes name for the entry atiyah (10b's br.*, then 10c's ns.*; 10a names no analysis and
                             has no item on the page); the file is read again just before it is written and only that list is touched, as text
  8 public/reports/analyses/src/atiyah_lens.md   section 9: items 32 (10c) and 33 (10b) after item 31; the edits of the two passes, those that
                             find one sentence composed into one replacement of the sentence of 2.12.0 in the order of the items (the numbering
                             sentence, the scripts of the sources, the sources of section 9), the clauses of the first paragraph each at its own
                             anchor (10c's after period_map.py's rows, 10b's after fibre_base.py's); theme 1 (10c) and theme 6 (10b), *The Atlas.*;
                             the last sentence of item 31 (10b); the list of what is not done (10c's edit, with 10b's rows: the learner texts of
                             the rows of items 30 to 33, deferred to the story round); the lens record (105 entries, 34 from the checks of section
                             9, the readings counted from the regenerated table)
  9 node tools/make_analysis.mjs atiyah    renders the page
Each table keeps its own JSON form (indent 1, UTF-8, with or without the final newline it had).
Usage (from anywhere): python3 docs/round12/apply_pass10.py [--no-node]    --no-node skips steps 6 and 9 (and leaves the count of readings of step 8)
"""
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
said = []


def path(rel):
    return os.path.join(ROOT, rel)


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    return json.loads(raw), raw.endswith('\n')


def save(rel, data, newline):
    text = json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')
    old = open(path(rel), encoding='utf-8').read()
    if text != old:
        open(path(rel), 'w', encoding='utf-8').write(text)
        said.append(f'wrote {rel}')
    else:
        said.append(f'unchanged {rel}')


def swap(text, find, repl, what):
    """replace the one occurrence of find by repl; a second run finds repl in place and changes nothing"""
    if repl in text and (find not in text or find in repl):
        return text
    assert text.count(find) == 1, f'{what}: the phrase to replace is not there once ({text.count(find)} times): {find[:90]!r}'
    return text.replace(find, repl)


# ---- the three passes, in the order they apply: 10a, 10b, 10c (the page's items: 32 is 10c's, 33 is 10b's)
A = json.load(open(os.path.join(HERE, 'pass10a', 'apply.json'), encoding='utf-8'))
B = json.load(open(os.path.join(HERE, 'pass10b', 'apply.json'), encoding='utf-8'))
C3 = json.load(open(os.path.join(HERE, 'pass10c', 'apply.json'), encoding='utf-8'))
LENS4 = {'lens_furey': 'furey', 'lens_alg': 'alg', 'lens_schuller': 'schuller', 'lens_atiyah': 'atiyah'}
PASSES = [
    {'C': A, 'name': '10a', 'src': 'pass10a:furey-cl6', 'group': 'FUR', 'after': 'FUR-014', 'n': None,
     'ids': [f'FUR-0{k}' for k in range(15, 20)], 'script': 'checks/selfcheck/proofs/furey_cl6.py',
     'checks': ['fc.CPX', 'fc.CAR', 'fc.FOCK', 'fc.SU3', 'fc.AX'],
     'faults': [('IMINUS', 18), ('WRONGPAIR', 27), ('NOFACTOR', 5), ('NOI', 27), ('DAGSIGN', 18), ('NONFANO', 16)],
     'tags': {'bit': 30, 'bit==std': 6, 'ctl': 7, 'std': 7}, 'last': 'furey_cl6: 50 checks, 0 fail',
     'where': {'FUR-015': [('matter', 'furey', 31), ('matter/model', 'axes', 1022)], 'FUR-016': [('matter', 'furey', 32), ('matter/model', 'axes', 1023)],
               'FUR-017': [('matter', 'furey', 33), ('matter/model', 'edges', 1024)], 'FUR-018': [('matter', 'furey', 34), ('matter/model', 'edges', 1025)],
               'FUR-019': [('matter', 'furey', 35), ('matter/model', 'axes', 1026)]},
     'kind': {}, 'stage': {}, 'blocks': LENS4, 'analyses': [], 'edits': []},
    {'C': B, 'name': '10b', 'src': 'pass10b:branching-16', 'group': 'FUR', 'after': 'FUR-019', 'n': 33,
     'ids': [f'FUR-0{k}' for k in range(20, 27)], 'script': 'checks/selfcheck/proofs/branching_16.py',
     'checks': ['br.W19', 'br.W010', 'br.W55', 'br.ONE', 'br.MAJ', 'br.SUM', 'br.POL', 'br.KK'],
     'faults': [('WRONGJ', 3), ('UNGRADED', 20), ('ODDLAB', 5), ('NOCONJ', 4), ('OTHERHALF', 1), ('SHELLSIGN', 8)],
     'tags': {'bit': 22, 'bit==std': 7, 'ctl': 6, 'std': 7}, 'last': 'branching_16: 42 checks, 0 fail',
     'where': {**{f'FUR-0{20 + k}': [('matter', 'furey', 36 + k), ('steps/baez', 'bz-generation', 270 + k)] for k in range(4)},
               **{f'FUR-0{24 + k}': [('matter', 'furey', 40 + k), ('steps/coupling', 'eq-coupling', 43 + k)] for k in range(3)}},
     'kind': {}, 'stage': {'FUR-024': 'F', 'FUR-025': 'F', 'FUR-026': 'F'}, 'blocks': LENS4, 'analyses': ['atiyah'], 'edits': ['FUR-012']},
    {'C': C3, 'name': '10c', 'src': 'pass10c:null-stages', 'group': 'GEN', 'after': 'GEN-020', 'n': 32,
     'ids': [f'GEN-0{k}' for k in range(21, 27)], 'script': 'checks/selfcheck/proofs/null_stages.py',
     'checks': ['ns.NUL', 'ns.ABS', 'ns.STG', 'ns.P3', 'ns.STD', 'ns.LIM'],
     'faults': [('NULLACTS', 4), ('PRQUOT', 8), ('NOSWAP', 2), ('ANTIPAIR', 1), ('MULT3', 4), ('NOUNIT', 1)],
     'tags': {'bit': 19, 'bit==std': 5, 'ctl': 7, 'std': 5}, 'last': 'null_stages: 36 checks, 0 fail',
     'where': {f'GEN-0{21 + k}': ([('clock', 'clock', 1005)] if k == 1 else []) + [('rule', 'ideas', 33 + k), ('cells', 'cards', 71 + k)] for k in range(6)},
     'kind': {}, 'stage': {}, 'blocks': {'lens_atiyah': 'atiyah', 'lens_alg': 'alg', 'lens_cat': 'cat'}, 'analyses': ['atiyah'], 'edits': ['GEN-019']},
]
ALL_IDS = [i for P in PASSES for i in P['ids']]
ALL_CHECKS = [c for P in PASSES for c in P['checks']]
# R5's routing of 10b's rows (docs/round12/pass10b/apply.json, notes): they keep their home on matter (orders 36 to 42, the least of each row, as the
# owner set them), and every row whose home is matter stands on one tab of the chapter (the story plan's section 2.5, tests/story/furey.test.mjs):
# Her 2026 model (matter/model), section axes, orders 1027 to 1033 after FUR-019, beside the rows of pass 9a they continue (FUR-011 to FUR-013, in
# that section); written through the overlay's layout as 10a's entries are, the rows of 10b's file unchanged
TAB_10B = {f'FUR-0{20 + k}': {'page': 'matter/model', 'section': 'axes', 'order': 1027 + k, 'role': 'detail'} for k in range(7)}
SHOWN = {r['id']: r['shownOn'] + ([TAB_10B[r['id']]] if r['id'] in TAB_10B else []) for P in PASSES for r in P['C']['rows']}
assert set(TAB_10B) == set(PASSES[1]['ids']) and not any(s['page'] == 'matter/model' for r in B['rows'] for s in r['shownOn']), "10b's rows and the tab"
LENS_N0 = {'furey': 24, 'alg': 135, 'atiyah': 103, 'cat': 154}   # the dictionaries of 2.12.0
CONCRETE = re.compile(r'^\((\d{1,2}),(\d{1,2}),(\d{1,2})\)$')
FIRST_CELL = {'GEN-021': '(0,0,8)', 'GEN-022': '(0,0,8)', 'GEN-023': '(0,0,8)', 'GEN-024': '(8,0,0)', 'GEN-025': '(8,0,0)', 'GEN-026': '(8,0,0)'}

for P in PASSES:
    C = P['C']
    assert C['pass'] == P['name'] and C['since'] == 'v2.13', (P['name'], C['pass'], C['since'])
    assert [r['id'] for r in C['rows']] == P['ids'], [r['id'] for r in C['rows']]
    assert [(e['row'], e['level']) for e in C['row_text_edits']] == [(x, 'research') for x in P['edits']], f"pass {P['name']}: its row_text_edits"
    assert C['files']['script'] == P['script'], C['files']['script']
    assert all(os.path.exists(path(C['files'][k])) for k in ('script', 'log', 'faultLog')), C['files']
    assert [a['id'] for a in C['analyses']] == P['analyses'] and all(a['checks_add'] == P['checks'] for a in C['analyses']), \
        f"pass {P['name']}: the analysis it names (atiyah, with its check ids) or none"
    assert {k: C[k]['key'] for k in C if k == 'lens' or k.startswith('lens_')} == P['blocks'], f"pass {P['name']}: the lens blocks"

# ===================================================================================================================== 1 rows
rows, nl = load('content/rows.json')


def pass_of(rid):
    return next(P for P in PASSES if rid in P['ids'])


def earlier_copy(r):
    P = pass_of(r['id'])
    return (r.get('since') == 'v2.13' and r.get('group') == P['group'] and bool(r.get('evidence'))
            and all(e.get('script') == P['script'] for e in r['evidence']))


clash = [r['id'] for r in rows if r['id'] in ALL_IDS and not earlier_copy(r)]
if clash:
    sys.exit(f'the ids {clash} are taken by other rows of content/rows.json: renumber the pass from the next free id of its group')
rows = [r for r in rows if r['id'] not in ALL_IDS]
FUREY = 'content/story/furey.json'
fy, fy_nl = load(FUREY)
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])} | {(l['page'], l['order']) for l in fy['layout'] if l['row'] not in ALL_IDS}
mine = [(s['page'], s['order']) for P in PASSES for r in P['C']['rows'] for s in SHOWN[r['id']]]
assert len(mine) == len(set(mine)) and not set(mine) & taken, f'an order of the passes is taken (page-wide) or used twice: {sorted(set(mine) & taken)}'
sections = {p['route']: {s.get('id') for s in p.get('sections') or []} for p in json.load(open(path('content/pages.json'), encoding='utf-8'))}
for P in PASSES:
    for r in P['C']['rows']:
        rid = r['id']
        assert r['since'] == 'v2.13' and r['group'] == P['group'], rid
        assert (r['kind'], r['stage']) == (P['kind'].get(rid, 'computation'), P['stage'].get(rid, 'A')), (rid, r['kind'], r['stage'])
        assert [(s['page'], s['section'], s['order']) for s in r['shownOn']] == P['where'][rid], rid
        assert all(s['role'] == 'detail' and s['section'] in sections.get(s['page'], ()) for s in SHOWN[rid]), f'{rid}: a role or a section'
        homes = sorted(SHOWN[rid], key=lambda s: s['order'])   # a row's home is its entry of least order (src/app/queries.js, rowHome)
        assert P['group'] != 'FUR' or (homes[0]['page'] == 'matter' and any(s['page'] == 'matter/model' for s in SHOWN[rid])), f'{rid}: home on matter, and on its tab'
        on_cards = any((s['page'], s['section']) == ('cells', 'cards') for s in r['shownOn'])
        assert on_cards == (rid in FIRST_CELL) and not any(s['page'] == 'cells' for s in r['shownOn'] if rid not in FIRST_CELL), f'{rid}: on the cells page or not'
        if on_cards:
            m = CONCRETE.match(r['cells'][0]) if r['cells'] else None
            assert m and sum(map(int, m.groups())) <= 8 and r['cells'][0] == FIRST_CELL[rid], f"{rid}: a card of the cells page needs a concrete first cell, n <= 8: {r['cells'][:1]}"
# An entry on a page the story overlay adds (content/story/furey.json: the five sub-pages of matter) goes through that file's layout
# (add: true, step 1b), as those of FUR-006, CAND-102, CAND-049 and FUR-007 ... FUR-014 do: tools/merge_story.mjs appends it after the row's own
# entries and records it in its book (content/story/merged.json, key "<row>|<page>|add|<index>", the sha1 digest of the entry), and the tables
# without the overlay (its baseTables) stay valid. Here a row keeps such an entry only once the book shows the merge wrote it, at the place the
# merge puts it.
OVERLAY = {p['route'] for p in fy['pages'] if 'page' in p}
assert OVERLAY == {'matter/dictionary', 'matter/papers', 'matter/model', 'matter/generations', 'matter/help'}, OVERLAY
book = json.load(open(path('content/story/merged.json'), encoding='utf-8')).get('entries', {})
digest = lambda so: hashlib.sha1(json.dumps(so, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()[:20]
layout = []   # the layout entries of the passes, in the order of the rows
for P in PASSES:
    put = []
    for r in P['C']['rows']:
        own = [s for s in SHOWN[r['id']] if s['page'] not in OVERLAY]
        over = [s for s in SHOWN[r['id']] if s['page'] in OVERLAY]
        wrote = [(book.get(f"{r['id']}|{s['page']}|add|{len(own) + k}") or {}).get('wrote') == digest(s) for k, s in enumerate(over)]
        assert all(wrote) or not any(wrote), f"{r['id']}: the merge wrote some of its overlay entries and not the others: run npm run content"
        put.append({**r, 'shownOn': own + (over if all(wrote) else [])})
        layout += [{'row': r['id'], 'page': s['page'], 'section': s['section'], 'order': s['order'], 'role': s['role'], 'add': True} for s in over]
    at = next(i for i, r in enumerate(rows) if r['id'] == P['after'])
    rows[at + 1:at + 1] = put
ids = {r['id'] for r in rows}
thm = {t['id'] for t in json.load(open(path('content/theorems.json'), encoding='utf-8'))}
for P in PASSES:
    for r in P['C']['rows']:
        for d in r['depends']:
            assert d['id'] in ids or d['id'] in thm, f"{r['id']} depends on an unknown row {d['id']}"
        for e in r['evidence']:
            assert e['mode'] == 'ran' and e['script'] == P['script'] and e['check'] in P['checks'], r['id']
save('content/rows.json', rows, nl)

# ---- 1b the story overlay's layout: the entries of 10a and of 10b (R5's routing) on its sub-page matter/model, after those of FUR-014 (pass 9a)
keep = [l for l in fy['layout'] if l['row'] not in ALL_IDS]
assert keep[-1]['row'] == 'FUR-014' and all(list(l.keys()) == list(keep[-1].keys()) for l in layout), 'the layout of the story overlay'
assert [l['row'] for l in layout] == PASSES[0]['ids'] + PASSES[1]['ids'] and all(l['page'] == 'matter/model' for l in layout), \
    'one entry per row of 10a and of 10b, none of 10c'
fy['layout'] = keep + layout
save(FUREY, fy, fy_nl)

# ===================================================================================================================== 2 texts
texts, nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'])
mine = {key(t) for P in PASSES for t in P['C']['texts']}
texts = [t for t in texts if key(t) not in mine]
assert not any(t['row'] in ALL_IDS for t in texts), 'another text of the eighteen rows stands in content/texts.json (no learner text this round: docs/round12/PLAN.md)'
for P in PASSES:
    C = P['C']
    assert [t['row'] for t in C['texts']] == P['ids'], f"pass {P['name']}: one research text per row, in the order of the rows"
    for t in C['texts']:
        assert (t['status'], t['source'], t['level'], t['lens'], t['mode'], t['register'], t['lang']) == \
            ('draft', P['src'], 'research', None, 'both', 'full', 'en'), t['row']
        assert not re.search(r'/home/|@[\w-]+\.\w', t['body']), f"{t['row']}: a machine path or a contact detail"
    # after the last text of the row before the pass; a row's research text after its own learner texts (by row, then level)
    at = start = max(i for i, t in enumerate(texts) if t['row'] == P['after']) + 1
    for t in C['texts']:
        while at < len(texts) and texts[at]['row'] == t['row']:
            at += 1
        texts.insert(at, t)
        at += 1
    assert texts[start - 1]['row'] < P['ids'][0] and (at == len(texts) or texts[at]['row'] > P['ids'][-1]), f"pass {P['name']}: the texts out of row order"
# the row_text_edits (10b: FUR-012; 10c: GEN-019), each one clause of a research draft of pass 9 replaced as the pass proposes it: the claim and its
# scope kept (FUR-012 still cites the decomposition and says what FUR-020 to FUR-022 compute, its weights; GEN-019 still leaves the limit and its
# completion uncomputed and points to GEN-026 for the ordered group on the finite side); recorded in the notes of the two apply.json files
for P in PASSES:
    for e in P['C']['row_text_edits']:
        t = [x for x in texts if x['row'] == e['row'] and x['level'] == 'research']
        assert len(t) == 1 and t[0]['status'] == 'draft' and t[0]['source'] in ('pass9a:fibre-base', 'pass9b:period-map'), e['row']
        t[0]['body'] = swap(t[0]['body'], e['find'], e['replace'], f"the research text of {e['row']} (pass {P['name']})")
        assert t[0]['body'].count(e['replace']) == 1, e['row']
save('content/texts.json', texts, nl)

# ===================================================================================================================== 3 the check records
checks, nl = load('content/checks.json')
cids = [c['id'] for P in PASSES for c in P['C']['checks']]
checks = [c for c in checks if c['id'] not in cids]
assert checks[-1]['id'] == 'selfcheck/proofs/fibre_base.py', checks[-1]['id']
assert not any(x['id'] in ALL_CHECKS for c in checks for x in c.get('ids') or []), 'an fc.*, br.* or ns.* id in another record'
form = list(checks[-1].keys())
for P in PASSES:
    C = P['C']
    for c in C['checks']:
        assert list(c.keys()) == form and c['id'] == P['script'][len('checks/'):] and c['since'] == 'v2.13', c['id']
        assert c['script'] == P['script'] and c['log'] == C['files']['log'], c['id']
        assert [x['id'] for x in c['ids']] == P['checks'] and c['rowsNaming'] == P['ids'], c['id']
    checks += C['checks']
save('content/checks.json', checks, nl)

# ===================================================================================================================== 4 the run records
# the stored log: its tagged check lines (all ok) count the record's checks and tags, and its last line is the record's; the fault log: the
# pass's wrong versions in order, each "--fault X: exit 1", with as many FAIL lines as its own "last:" line counts (RESULT.md of each pass)
runs, nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
mine = {rk(r) for P in PASSES for r in P['C']['check_runs']}
runs = [r for r in runs if rk(r) not in mine]
TAG = re.compile(r'^  (ok|FAIL) +\[(bit|bit==std|ctl|std)\] ')
for P in PASSES:
    C = P['C']
    name = os.path.basename(P['script'])[:-len('.py')]
    total = sum(P['tags'].values())
    log = open(path(C['files']['log']), encoding='utf-8').read().rstrip('\n').split('\n')
    hits = [m for m in map(TAG.match, log) if m]
    tags = {k: sum(1 for m in hits if m.group(2) == k) for k in P['tags']}
    assert all(m.group(1) == 'ok' for m in hits) and len(hits) == total and tags == P['tags'], (P['name'], tags)
    assert log[-1] == P['last'] == f'{name}: {total} checks, 0 fail', log[-1]
    tagword = ', '.join(f'{k} {v}' for k, v in P['tags'].items())
    for r in C['check_runs']:
        assert r['script'] == P['script'] and r['source'] == C['files']['log'] and list(r.keys()) == list(runs[-1].keys()), r['script']
        assert r['passed'] is True and r['ok'] == total and r['fail'] == 0 and r['lastLine'] == log[-1], r['script']
        assert f'tags {tagword}' in r['status'] and f"{len(P['faults'])} --fault runs each exit 1" in r['status'], r['status']
    got = []
    for b in re.split(r'^(?=--fault )', open(path(C['files']['faultLog']), encoding='utf-8').read(), flags=re.M):
        if not b.strip():
            continue
        head = re.match(r'--fault (\w+): exit 1\n', b)
        last = re.search(rf'^last: {name}: (\d+) checks, (\d+) fail$', b, re.M)
        nfail = len(re.findall(r'^  FAIL +\[', b, re.M))
        assert head and last and int(last.group(1)) == total and int(last.group(2)) == nfail >= 1, (P['name'], b[:80])
        got.append((head.group(1), nfail))
    assert got == P['faults'], (P['name'], got)
    runs += C['check_runs']
save('content/check_runs.json', runs, nl)

# ===================================================================================================================== 5 the lenses
# a block is found by its key; each entry has the keys of its lens's own entries, in their order, and is appended after them
lenses, nl = load('content/lenses.json')
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows'] and e['atlas'] == f['atlas']
adds = {}
for P in PASSES:
    for blk, lkey in P['blocks'].items():
        for e in P['C'][blk]['dictionary_add']:
            assert e['evidence'] and set(e['evidence']) <= set(P['checks']) and e['rows'] and set(e['rows']) <= set(P['ids']), (lkey, e['atlas'][:40])
            assert e['flags'] == ['checked'] and e['from'].endswith(f"(pass {P['name']})"), (lkey, e['from'])
            adds.setdefault(lkey, []).append(e)
assert {k: len(v) for k, v in adds.items()} == {'furey': 7, 'alg': 7, 'atiyah': 2, 'cat': 1}, {k: len(v) for k, v in adds.items()}
for lkey, add in adds.items():
    lens = next(x for x in lenses if x['key'] == lkey)
    form = list(lens['dictionary'][0].keys())
    assert all(list(e.keys()) == form for e in lens['dictionary'] + add), f'{lkey}: an entry in another form than the lens keeps'
    keep = [e for e in lens['dictionary'] if not any(same(e, f) for f in add)]
    assert len(keep) == LENS_N0[lkey], (lkey, len(keep))
    lens['dictionary'] = keep + add
    said.append(f"the lens {lkey}: {LENS_N0[lkey]} -> {len(lens['dictionary'])} dictionary entries")
# pass 9a's furey entry on her Cl(6) over the reals (docs/round11/pass9a/apply.json; 10a's notes): its match said that her complex ℂl(6) on ℂ ⊗ 𝕆
# and her ladder operators are "not reproduced", true of fibre_base.py and answered by fc.CPX and fc.CAR; one clause points to FUR-015 and FUR-016,
# the match word stays partial (the entry's own evidence, fb.OCT, computes the real form and ω₆), the atlas side and the term are unchanged
fu = next(x for x in lenses if x['key'] == 'furey')
e9 = [e for e in fu['dictionary'] if e['from'] == 'furey · fibre and base (pass 9a)' and e['term'].startswith('her Cl(6) (ℂl(6) from the left actions')]
assert len(e9) == 1 and e9[0]['evidence'] == ['fb.OCT'] and e9[0]['rows'] == ['FUR-008'], 'the entry of pass 9a on her Cl(6) over the reals'
LENS_EDIT = ('her complex ℂl(6) on ℂ ⊗ 𝕆 and her ladder operators not reproduced)', 'her complex ℂl(6) on ℂ ⊗ 𝕆 and her ladder operators reproduced in FUR-015 and FUR-016)')
e9[0]['match'] = swap(e9[0]['match'], *LENS_EDIT, "the match of pass 9a's furey entry on her Cl(6)")
assert e9[0]['match'] == 'partial (the real form and ω₆ = +L_{e₇} computed; ' + LENS_EDIT[1], e9[0]['match']
save('content/lenses.json', lenses, nl)
aty_dict = next(x for x in lenses if x['key'] == 'atiyah')['dictionary']

# ===================================================================================================================== 6 the lens readings
if not NO_NODE:
    out = subprocess.run(['node', 'tools/migrate/lens_readings.mjs'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout[-1500:])
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('lens_readings.mjs failed')
    said.append('ran tools/migrate/lens_readings.mjs')

# ===================================================================================================================== 7 the analyses registry
# the check ids of the entry atiyah, as text (read again now, written back at once): the ids of the passes that name it, 10b's br.*, then 10c's ns.*
NAMED = [c for P in PASSES if P['analyses'] for c in P['checks']]
assert NAMED == PASSES[1]['checks'] + PASSES[2]['checks'], NAMED
rel = 'content/analyses.json'
raw = open(path(rel), encoding='utf-8').read()
before = json.loads(raw)
text = raw
m = re.search(r'\n(\s*)"id": "atiyah",', text)
assert m, 'the entry atiyah of content/analyses.json'
c = text.index('"checks": [', m.end())
end = text.index(']', c)
body = text[c + len('"checks": ['):end]
have = json.loads('[' + body + ']')
want = [x for x in NAMED if x not in have]
if want:
    ind = re.search(r'\n(\s*)"', body).group(1)
    stripped = body.rstrip()
    new_body = stripped + ''.join(f',\n{ind}{json.dumps(x, ensure_ascii=False)}' for x in want) + body[len(stripped):]
    text = text[:c] + '"checks": [' + new_body + text[end:]
if text != raw:
    after = json.loads(text)
    a_old = next(x for x in before if x.get('id') == 'atiyah')
    a_new = next(x for x in after if x.get('id') == 'atiyah')
    assert a_new['checks'] == a_old['checks'] + want and {k: v for k, v in a_new.items() if k != 'checks'} == {k: v for k, v in a_old.items() if k != 'checks'}
    assert [x for x in after if x.get('id') != 'atiyah'] == [x for x in before if x.get('id') != 'atiyah']
    if open(path(rel), encoding='utf-8').read() != raw:
        sys.exit(f'{rel} changed while this step read it: run again')
    open(path(rel), 'w', encoding='utf-8').write(text)
    said.append(f'wrote {rel} (atiyah gains {len(want)} check ids)')
else:
    said.append(f'unchanged {rel}')
assert not any(x in next(a for a in json.loads(text) if a.get('id') == 'atiyah')['checks'] for x in PASSES[0]['checks']), 'fc.* on the entry atiyah'

# ===================================================================================================================== 8 the Atiyah page
rel = 'public/reports/analyses/src/atiyah_lens.md'
md = open(path(rel), encoding='utf-8').read()
md0 = md
PB, PC = PASSES[1], PASSES[2]
AN = {}
for P in (PC, PB):   # in the order of the items: 32 (10c), 33 (10b)
    an = P['C']['analyses'][0]
    assert an['source'] == rel and an['section9_numbering'].startswith(f"R5: {{n}} = {P['n']},"), an['section9_numbering']
    AN[P['name']] = (an, (lambda n: lambda s: s.replace('{n}', str(n)))(P['n']))

# section 9's items 32 (10c) and 33 (10b), after item 31
items = []
for P in (PC, PB):
    an, fill = AN[P['name']]
    its = [fill(s) for s in an['section9_items']]
    assert len(its) == 1 and its[0].startswith(f"{P['n']}. ") and '\n' not in its[0] and '{n}' not in its[0], P['name']
    items += its
lines = md.split('\n')
i31 = next(i for i, l in enumerate(lines) if l.startswith('31. *Fibre and base*'))
if lines[i31 + 1:i31 + 1 + len(items)] != items:
    assert not any(l.startswith(('32. ', '33. ')) for l in lines), 'an item 32 or 33 stands elsewhere'
    lines[i31 + 1:i31 + 1] = items
md = '\n'.join(lines)

# the edits, 10c's six and 10b's six. Where both passes find one sentence of 2.12.0 (the numbering sentence, the scripts of the sources, the sources
# of section 9) the two are composed into one replacement, in the order of the items (10c's clause, then 10b's), which a second run finds in place;
# the clauses of the first paragraph have their own anchors (10c's after the rows of period_map.py, 10b's after those of fibre_base.py); the list of
# what is not done is 10c's edit with 10b's rows added (10b leaves that paragraph to R5)
WHERE_C = ['section 5, theme 1, *The Atlas.*', 'section 9, first paragraph', 'section 9, first paragraph', 'section 9, the list of what is not done',
           'Sources, the Atlas', 'Sources, section 9']
WHERE_B = ['section 5, theme 6, *The Atlas.*', 'section 9, first paragraph', 'section 9, first paragraph', 'section 9, item 31', 'Sources, the Atlas',
           'Sources, section 9']
(ec, fill_c), (eb, fill_b) = AN['10c'], AN['10b']
assert [e['where'] for e in ec['edits']] == WHERE_C and [e['where'] for e in eb['edits']] == WHERE_B
c1, c2, c3, c4, c5, c6 = [(e['find'], fill_c(e['replace'])) for e in ec['edits']]
b1, b2, b3, b4, b5, b6 = [(e['find'], fill_b(e['replace'])) for e in eb['edits']]
# the numbering sentence: "30 pass 9b, 31 pass 9a." -> ", 32 pass 10c" (10c), then ", 33 pass 10b" before the full stop (10b's note)
assert c3[0].endswith(b3[0]) and c3[1] == c3[0][:-1] + ', 32 pass 10c.' and b3[1] == b3[0][:-1] + ', 33 pass 10b.', (c3, b3)
numbering = (c3[0], c3[1][:-1] + b3[1][len(b3[0]) - 1:])
# the learner texts not written: the rows of items 30 to 33 (10c's edit names items 30, 31 and 32; 10b's rows FUR-020 to FUR-026 join them)
OLD_ND = ('items 30, 31 and 32 (GEN-017 to GEN-026, FUR-007 to FUR-014;', 'items 30 to 33 (GEN-017 to GEN-026, FUR-007 to FUR-014 and FUR-020 to FUR-026;')
assert c4[1].count(OLD_ND[0]) == 1 and c4[1].endswith('deferred to the story round by the owner\'s direction;'), c4
not_done = (c4[0], c4[1].replace(*OLD_ND))
# the scripts of the sources: both passes add their script after fibre_base.py
assert c5[0] == b5[0] and c5[1] == c5[0].replace('`fibre_base.py` with', '`fibre_base.py`, `null_stages.py` with') \
    and b5[1] == b5[0].replace('`fibre_base.py` with', '`fibre_base.py`, `branching_16.py` with'), (c5, b5)
scripts = (c5[0], c5[0].replace('`fibre_base.py` with', '`fibre_base.py`, `null_stages.py`, `branching_16.py` with'))
# the sources of section 9: both passes extend the sentence that ends with Furey's paper, 10c's clause (item 32) first
F = c6[0]
assert F == b6[0] and F.endswith('.') and c6[1].startswith(F[:-1] + '; for item 32,') and b6[1].startswith(F[:-1] + '; for item 33,') \
    and c6[1].endswith('.') and b6[1].endswith('.'), (c6, b6)
sources9 = (F, F[:-1] + c6[1][len(F) - 1:-1] + b6[1][len(F) - 1:])
plan = [('theme 1 (10c)', *c1), ('theme 6 (10b)', *b1), ('section 9, first paragraph (10c)', *c2), ('section 9, first paragraph (10b)', *b2),
        ('section 9, the numbering (10c, 10b)', *numbering), ('section 9, item 31 (10b)', *b4), ('section 9, not done (10c, with 10b)', *not_done),
        ('Sources, the Atlas (10c, 10b)', *scripts), ('Sources, section 9 (10c, 10b)', *sources9)]
for where, find, repl in plan:
    assert '{n}' not in repl and 'R5:' not in repl and 'R4:' not in repl, where
    md = swap(md, find, repl, where)

# section 7, the lens record: the entries of the dictionary, those from the checks of section 9 (their source names a pass), the readings
n_dict = len(aty_dict)
n_sec9 = sum(1 for e in aty_dict if re.search(r'\(pass [^)]*\)$', e['from']))
assert (n_dict, n_sec9) == (105, 34), (n_dict, n_sec9)
assert md.count('28 entries from the narrative and the map above, 43 from the five readings,') == 1 and 28 + 43 + n_sec9 == n_dict
for pat in (r'carries a dictionary of \d+ entries', r'\d+ from the checks of section 9\.', r'The result is \d+ readings on \d+ rows\.'):
    assert len(re.findall(pat, md)) == 1, pat
md = re.sub(r'carries a dictionary of \d+ entries', f'carries a dictionary of {n_dict} entries', md)
md = re.sub(r'\d+ from the checks of section 9\.', f'{n_sec9} from the checks of section 9.', md)
if not NO_NODE:
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    a = [r for r in lr if r['lens'] == 'atiyah']
    n_read, n_rows = len(a), len({r['row'] for r in a})
    md = re.sub(r'The result is \d+ readings on \d+ rows\.', f'The result is {n_read} readings on {n_rows} rows.', md)
    said.append(f'the lens atiyah: {n_read} readings on {n_rows} rows')

# section 9, what is not done: the learner texts not written are those of the rows of items 30 to 33, deferred to the story round (docs/round12/PLAN.md,
# "Not this round"); the rows ATY-001 ... ATY-055 and GEN-010 ... GEN-016 have learner drafts
learner = {t['row'] for t in json.load(open(path('content/texts.json'), encoding='utf-8')) if t['level'] == 'learner'}
aty = sorted(i for i in ids if i.startswith('ATY-'))
assert aty == [f'ATY-{k:03d}' for k in list(range(1, 48)) + list(range(51, 56))], 'the ATY rows the sentence names'
assert all(i in learner for i in aty + [f'GEN-0{k}' for k in range(10, 17)]), 'a row the sentence says has a learner draft has none'
item_rows = [f'GEN-0{k}' for k in range(17, 27)] + [f'FUR-0{k:02d}' for k in range(7, 15)] + [f'FUR-0{k}' for k in range(20, 27)]
assert not any(i in learner for i in item_rows + PASSES[0]['ids']), 'a row of items 30 to 33 (or of pass 10a) has a learner text: the sentence must say so'

for must in items + [p[2] for p in plan] + ['30 pass 9b, 31 pass 9a, 32 pass 10c, 33 pass 10b.', f'carries a dictionary of {n_dict} entries',
                                            f'{n_sec9} from the checks of section 9.', 'learner texts for the rows of items 30 to 33 (GEN-017 to GEN-026,',
                                            '; item 33 computes its weights on the labels.']:
    assert md.count(must) == 1, must[:90]
assert md.count('section 9 item 32)') == 1 and md.count('section 9 item 33)') == 1, 'theme 1 points to item 32, theme 6 to item 33'
assert md.index('(six rows, GEN-021 to GEN-026)') < md.index('(seven rows, FUR-020 to FUR-026)') < md.index('Items 1 to 10 are pass five'), 'the clauses in item order'
assert not any(p in md for p in ('{n}', 'R5:', 'R4:', 'R2:', 'N readings on M rows', 'furey_cl6.py')), 'a placeholder, a note of the passes, or 10a on the page'
if md != md0:
    open(path(rel), 'w', encoding='utf-8').write(md)
    said.append(f'wrote {rel}')
else:
    said.append(f'unchanged {rel}')

# ---- 9 the page
if not NO_NODE:
    out = subprocess.run(['node', 'tools/make_analysis.mjs', 'atiyah'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout)
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('make_analysis.mjs failed')

print('\n'.join(said))
