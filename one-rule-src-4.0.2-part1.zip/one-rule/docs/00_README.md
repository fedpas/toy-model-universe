# ONE RULE — the V2 build book

This folder is the complete plan for rebuilding the Cascade Atlas (v15, plus the v16 leads) as a new, standalone web application. It is written so that an agentic AI of modest ability, or a developer who has never seen the project, can build the application end to end without further design decisions. Read the files in order the first time; afterwards use `10_TASKS.md` as the work list and the other files as the reference they point to.

| file | what it settles |
|---|---|
| `01_VISION.md` | what the app is, its name, the four modes, the lenses, the site map, the user journeys, the principles that decide every later choice |
| `02_CONTENT_MODEL.md` | the data: rows, texts, lenses, figures, evidence, pages; the status that is computed instead of typed; the one-badge rule; the address of a row |
| `03_MIGRATION.md` | how every piece of v15 and of the v16 leads becomes data of V2: source files, shapes, scripts to write, counts to verify |
| `04_LABELLING.md` | the bit-rule labelling of the rows: the scheme, how to finish the two persona passes, the validate/merge scripts (already written and tested), how the result organises the app |
| `05_DESIGN_SYSTEM.md` | tokens, typography, components, themes, learner variants, accessibility |
| `06_PAGES.md` | every route of the app: hero, sections as row queries, figures, drawer, learner and lens behaviour, acceptance criteria |
| `07_ENGINES_FIGURES.md` | the engines and figures to port, the single bit-rule kernel, formulas, the Python checks kept as evidence |
| `08_BUILD_TEST.md` | repository layout, toolchain, scripts, the tests that guard the invariants, performance budgets, deployment |
| `09_TRANSLATION_PROTOCOL.md` | how a text is produced for a (row, mode, level, lens) that has none: the translator personas, the draft status, the review, the checker; the Ask guide |
| `10_TASKS.md` | the ordered backlog with acceptance tests and stop points for the author's review |
| `11_RESEARCH_TODO.md` | what remains to research or decide (question 2 sources, remaining labelling passes, v16 merge, contradictions, decisions for the author) |

Companion material (same snapshot, `atlas_work/`): `matrix/atlas_matrix_v1.json` (the 789 rows with everything known about them), `matrix/checks.json` (236 check scripts), `matrix/analyses_dictionaries.json` (982 dictionary rows of the specialist readings), `labelling/SCHEME.md`, `labelling/PERSONA_*.md`, `labelling/chunks/`, `labelling/out/` (finished passes), `labelling/validate_labels.py`, `labelling/merge_labels.py`, `labelling/labels_merged.json` (partial), `notes/*.md` (the six reading notes of v15), and the published register "Cascade Atlas Matrix".

## Ground rules for whoever builds this

1. **The information is the author's; the form is new.** Every statement, number, check, source and reading comes from v15/v16. Nothing is invented, softened, strengthened or dropped. A sentence may be reworded only through the texts table, with its status marked (`human` if the author wrote it, `draft` if a model did), never in place.
2. **A page shows what is proved first, and the rest behind a click.** Reasoning data (checks, sampling bounds, logs, scripts, counts, audit lists, dependency graphs) lives in drawers and in the Logbook. The default view of any page is results.
3. **At most one badge per statement**, and only for what is open, not yet proved here, a reading of ours, an input, or new — and, from 4.0.0, for a theorem, a statement for every n. Statements that are computed at a finite scope, standard, or standard and recomputed carry no badge.
4. **Every statement on a page is a row.** Connective prose (one line that leads from one statement to the next) is allowed and budgeted; a law, a result, a number, a claim is never typed into a component.
5. **Lenses are a switch, not pages.** Mode (physics | mathematics), level (research | learner) and lens are three independent settings that change the text, the order and the figures of the same rows.
6. **Learner means no formulas.** A learner page shows only rows that have a learner text; it never falls back to the research text.
7. **The check scripts are kept exactly as they are** (same files, same ids, same stored results). V2 reads their results; it does not rewrite them.
8. **Do not guess what the author wants.** Where this book says "decision for the author", build the default it names and list the decision in the handover.
9. **No contact details of any person in any file**; no narration of earlier states in shipped text (the author's `no-history` rule: write what is true now).
10. **Verify counts.** Every migration step in `03_MIGRATION.md` states the number it must produce. A step that produces another number stops and reports.

## Vocabulary (used throughout)

- **row** — one statement of the Atlas (a claim, a theorem line, an input, a reading, a question). v15 has 789; V2 keeps their ids (`ATL-001`, `GRV-011`, `INP-044`, …) and adds new ones only for the v16 leads and for accepted "missing pieces" (status `candidate`).
- **text** — the words that render a row for one (language, mode, level, lens, register).
- **notion** — one of the 29 primitive notions of the labelling scheme (`lbl`, `sgn`, `sq`, …, `i-meta`); a row's label is the set of notions it uses; its signature is (p, q, r): how many of them the rule supplies, how many are imported, how many are inputs.
- **status** — computed from evidence and label: `theorem`, `computed`, `standard-recomputed` (the three a passing check gives, by what the statement claims: 4.0.0, D90), `standard`, `cited`, `ours`, `input`, `open`, `meta`, `candidate`, plus the transient `new`.
- **evidence** — a check id of a script that ran, or a source that was read, attached to a row.
- **lens** — a registered way of naming and drawing the same rows: a branch of mathematics, a polytope view, a researcher's conventions, a labelling base, or a sign convention.
- **drawer** — the on-demand panel under a section or a row that shows its evidence, address, dependencies, readings and scripts.
- **Logbook** — the researcher layer of the app: the register of rows, theorems, questions, sources, checks, reports, analyses, leads, replication, method.
