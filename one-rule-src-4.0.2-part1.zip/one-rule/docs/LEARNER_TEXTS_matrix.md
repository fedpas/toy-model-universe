<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts of the matrix rows (M1, D48)

`content/texts_learner_matrix.json` holds **89 learner drafts** for the **149 rows** of the four translation matrices (D35); the 60 rows without a draft are listed under "Rows left out". Every draft is a translation of its row's research text (`texts.json`, level research, lens null, mode both: "<what the paper writes> ↔ <what the Atlas computes>", or, for the spring and the rigid body, "<the claim> ↔ <how it is checked>") under `docs/09_TRANSLATION_PROTOCOL.md` §2, with the matrix variant of the learner persona of D48: one line of a translation table said for a reader before university, both columns in plain words and joined ("The paper writes … . With the switch rule …"; "<claim> … . The test: …"), every number, scope and status word of the research text kept, nothing added, no formula, Greek letters written out, present tense.

| matrix | rows | drafts | left out | length of the drafts (min · median · max) |
|---|---|---|---|---|
| spin `SPN-M01` … `SPN-M30` | 30 | 11 | 19 | 375 · 529 · 720 |
| forque `FRQ-M00` … `FRQ-M40` | 41 | 20 | 21 | 209 · 420 · 681 |
| spring `SPR-M01` … `SPR-M22` | 22 | 18 | 4 | 133 · 308 · 629 |
| rigid body `RIG-M01` … `RIG-M56` | 56 | 40 | 16 | 226 · 514 · 889 |
| all | 149 | 89 | 60 | 133 · 447 · 889 |

Each record has the shape of `texts.json` plus the two derived fields of the checker, recomputed by `node tools/check_learner_texts.mjs --fix --file content/texts_learner_matrix.json` (it changes nothing in the file as delivered):

```json
{ "row": "SPN-M01", "lang": "en", "mode": "both", "level": "learner", "lens": null, "register": "full",
  "body": "The paper writes a rotor as the exponential of an angle times a plane, …", "status": "draft",
  "source": "translator:learner@2026-10-11", "termsUsed": [], "keptNumbers": [] }
```

**The source.** Interface 35 names the source `translator:matrix@2026-10-11`. Rule R1 of `tools/check_learner_texts.mjs` accepts a source starting `translator:learner@` (or `translator:story@`, the story persona's of `docs/LEARNER_TEXTS_story.md`), so every record with the interface's source fails R1. The records carry `translator:learner@2026-10-11`, and the eight lines whose research text writes one half as `\tfrac12` (FRQ-M11, FRQ-M13, FRQ-M25, FRQ-M26, SPN-M09, SPN-M11, SPN-M14, SPN-M16) `translator:learner@2026-10-12`, the date of their drafts: the matrix persona is a variant of the learner persona, and the file name and the row ids mark the drafts as the matrices'. If the lead wants `translator:matrix@…`, R1 has to accept it first (one condition in the checker), then the source can be replaced in this file.

## Verification

| step | result |
|---|---|
| `node tools/check_learner_texts.mjs --file content/texts_learner_matrix.json` | PASS: 149 records, all 13 rules |
| `node tools/check_learner_texts.mjs` (every `texts_learner*.json` together) | PASS: 985 records, no matrix row drafted twice |
| `node tools/merge_learner_texts.mjs` (also inside `npm run content`) | each record added on its first run, replaced by itself on every later run; no human text replaced |
| `npm run content` | 0 errors; 224 warnings, the warnings of the tables (row dependencies, evidence ids), none about a text |
| `node tests/physics/matrix_learner.test.mjs` | 478 of 478 checks hold (see below) |
| `node tests/physics.test.mjs` | 10 of 10 test files pass (p4 … p11, q1 and this one) |
| `node tests/figures.render.test.mjs` | reads no text record: the learner drafts do not change what it checks |
| `node tests/logbook.test.mjs` | 554 of 554 checks hold |
| `node tests/coverage.test.mjs` | PASS: 6139 renders of 96 routes, 203527 statements checked: no statement, badge, KaTeX node or row-word failure |

No status or badge changes: status comes from evidence and label only (protocol §4).

## What the learner level shows

- **The matrix.** `src/figures/physics/TranslationMatrix.jsx` at learner level keeps the strip and the counts in words, and adds under them a fold "n of N lines in plain words" (folded at first exactly when the research list starts folded): each line whose row has a learner text is that text as a statement (`data-row` the row, `.statement__text` the record byte for byte, the row's lens reading, its one badge in the badge's learner words), with the line's stored status in words ("agrees exactly", "printed line differs", "not checked"; "checked"; "plausibility only", "cross-checked", "observation") and the line's id. A line without a learner text is not printed; with none the fold is not drawn and the markup is what it was. The research level never reads a learner record. On the pages this shows on `steps/spin` (spin-matrix: 30 of 30) and `steps/forque` (forque-matrix: 41 of 41). The spring table and the rigid matrix are research-only figures (`learner: false` in their seeds, P9's and P11's files), so the learner level does not draw them; the component would show 22 of 22 and 56 of 56.
- **The "More statements" fold.** The spin and forque lines are `detail` rows of `eq-spin` and `eq-forque`, and the rigid lines `detail` rows of `eq-rigid` (Q1, A43). S2's page model (`src/app/queries.js` as it stands in this round) puts a `detail` row that has a text at the page's level into its section's "More statements", at both levels, so at learner level the fold of those three sections lists the 30, 41 and 56 drafts. The spring lines are `evidence` rows (the drawer's numbers), which the learner level leaves out, so their 22 drafts show in the Logbook only.
- **The Logbook.** The register's facet "learner text" counts the 149 drafts; the row drawer shows each beside its research text with the draft mark.

`tests/physics/matrix_learner.test.mjs` pins this: (1) every record passes R1–R13 alone and with the other learner files, the rows without a record are exactly the table below, and `texts.json` holds every record after the merge; (2) at learner level the four matrices print each line with a learner text as a statement whose text is its record, the badge rule of the coverage test, the status word and the id, no formula and no control, and the markup without the learner fold is the markup recorded before this change; (3) at research level TranslationMatrix and MatrixLines, rendered with the props the four figures pass (bare, merged, merged with KaTeX; 20 cases), give the bytes recorded in `tests/fixtures/matrix_research.json` before the learner rendering was written, also with every learner record primed; and the four figures render the same research markup with and without the learner records.

## Rows left out

| row | matrix | reason |
|---|---|---|
| SPN-M01 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M04 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M08 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M09 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M11 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M13 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M14 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M18 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M20 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M21 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M22 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M23 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M24 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M25 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M26 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M27 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M28 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M29 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPN-M30 | spin | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M08 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M09 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M10 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M17 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M20 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M21 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M22 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M24 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M27 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M28 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M29 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M30 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M31 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M32 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M33 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M34 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M35 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M36 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M38 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M39 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| FRQ-M40 | forque | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPR-M04 | spring | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPR-M10 | spring | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPR-M12 | spring | its research text states the line as its check gives it; the learner words for that text are to be written |
| SPR-M18 | spring | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M02 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M05 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M06 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M07 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M08 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M11 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M12 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M13 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M14 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M16 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M19 | rigid body | its research text says what the referee's script computes for both signs of the Euler term (round 20); the learner words for that text are to be written (D82) |
| RIG-M33 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M44 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M50 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M52 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |
| RIG-M56 | rigid body | its research text states the line as its check gives it; the learner words for that text are to be written |

The eight lines whose research text writes one half as `\tfrac12` (FRQ-M11, FRQ-M13, FRQ-M25, FRQ-M26, SPN-M09, SPN-M11, SPN-M14, SPN-M16) are drafted like the others: the checker reads `\tfrac12` as the fraction one half, so R6 asks for a 2, which "half" gives.

## Three examples

**SPN-M02** (spin, the paper's and the lecture's formulas against the bit rule's).
Research: “$\tilde R\,\blacktriangle\,R:\ \text{two mirrors at angle }\beta\ \text{rotate by }2\beta$ · $RvR^{\sim}=v\cos 2t+u\sin 2t,\ \ R=\cos t+B\sin t$ ↔ $R=a+bB,\ (a,b)=(\cos t,\sin t):\ \ RvR^{\sim}=(a^2-b^2)\,v+2ab\,u$”
Learner: “The paper writes that two mirrors at an angle beta, applied as the reversed rotor and the rotor around an object, rotate it by 2 beta. The lecture writes that the rotor, the cosine of an angle plus the plane times its sine, sandwiching a vector gives the vector times the cosine of twice the angle plus the other vector times its sine. With the switch rule, for the rotor whose two numbers are that cosine and that sine, the sandwich gives the difference of their squares times the vector plus twice their product times the other vector.”

**FRQ-M04** (forque, a sign said in words).
Research: “$O^2=Q^2=\mathcal I_d^2=(-1)^{d(d-1)/2}\ \ (=-1\text{ in 2D, 3D})$ ↔ $O\,O=Q\,Q=\mathrm{pseudoscalar}_E^2$”
Learner: “The paper writes that the origin point, any other point and the pseudoscalar of space all have the same square, minus 1 raised to the number of pairs of directions, which is minus 1 in 2D and 3D. With the switch rule the origin times itself equals a point times itself equals the square of the pseudoscalar of space.”

**RIG-M38** (rigid body, a claim and how it is checked).
Research: “One body round a fixed centre, the Kepler problem in the plane, as a polynomial system in (x, v, u = 1/d). The circular orbit r = 2, v = 1, GM = 2 has the exact series x = 2 cos(t/2), y = 2 sin(t/2): ω²r³ = GM, Kepler III for a circle. ↔ Exact series through t¹⁰. Negative control: with the wrong power of d the series is a different curve.”
Learner: “One body around a fixed centre, the Kepler problem in the plane, written as a polynomial system in the position, the velocity and one over the distance. The circular orbit of radius 2 and speed 1, with the gravitational parameter 2, has the exact series in which the coordinates are 2 times the cosine and 2 times the sine of half the time: the square of the angular speed times the cube of the radius is the gravitational parameter, Kepler III for a circle. The test: exact series up to the tenth power of time. Negative control: with the wrong power of the distance the series is a different curve.”

## The register

The words of the earlier learner drafts (`docs/LEARNER_TEXTS.md`, the 32 human learner texts): a generator is a **switch** (plus, minus, zero switch), a blade a **piece**, the volume element **the piece of all (the) switches**, the bit rule **the switch rule**, a bivector a **plane**; in the physics lines a generator is a **direction** ("for 1 to 4 directions"), and motor, rotor, translator, forque, join, wedge, dual, star, commutator and pseudoscalar keep their names. A cell written with letters (`R(n,0,1)`, `n = 1…5`) is said in words ("the plane-based algebras with 1 to 5 directions and one zero switch"; in RIG-M35 "the dimension"); `Cl(3,0,1)`, `Cl(1,3)` stay, with their switches named where the line needs the number. The spin and forque lines start with the paper's column ("The paper writes …", "The lecture writes …") and give the bit rule's column after "With the switch rule"; the spring and rigid lines give the claim, then "The test: …" for the column "how it is checked". "Atlas" inside a sentence is a name the checker refuses unless the research text has it (R12), hence "the switch rule" for the Atlas's column. Identifiers are dropped (script names, references to other lines such as E1, E2, G3), except "line F25" and "line F20", which the forque lines cite as their evidence. The context-bound glossary term "mode" is listed in the three spring drafts where it means a Walsh mode; "null" (4 drafts) and "address" (1) are listed where they occur; "mirror" in the sense of a reflection (RIG-M32's "mirror image") is said "reflection", so that it is not read as the glossary's convention mirror.

## Points for the author

1. **FRQ-M10: the two columns and the stored note disagree on a sign.** The bit-rule column (`ours` of F10 in `checks/selfcheck/forque.json`) has a minus before ε(v∧B_E)B_E⁻¹, as the paper's printed line has; the stored note of F10 says the exact check needs a plus there and the printed minus does not add up. The learner text says what the research text says (a minus on both sides). One of the two (the `ours` TeX or the note) wants a look.
2. **The eight `\tfrac12` lines.** FRQ-M26 names T and Π the kinetic energy and the power, as the stored check of F26 computes them (the join and wedge forms of T against the classical kinetic energy, and the rate of change of T against Π); SPN-M09 calls w "the extra vector", after the stored check of S09 (conjugation by the extra reflection). The research texts give the symbols only; a word there would settle the names.
3. **RIG-M47 and RIG-M50** quote ganja literals, `−2e02` and `0.5e02`; the checker reads them as the numbers 2e02 and 0.5e02 and asks for them verbatim (R6). The learner texts quote them as code and say what they mean there ("2e02 means two times the piece of the zero switch with the second direction").
4. **SPN-M01**: the lecture's "R R⁻¹ = 1 ⟺ a² + b² = 1" reads as an identity that always holds; the learner text reads it as "undone by its partner (the rotor with the opposite plane part) exactly when the squares add up to 1", which the bit-rule column's (a + bB)(a − bB) = a² + b² supports. A word in the research text would remove the guess.
5. **SPN-M30** names "the group of three letters N, C, A": lone capitals are variables for the checker (R4) and "NCA" is a name the research text does not have (R12), so the learner text says "name a group by three letters". The line does not say what the letters stand for.
6. **SPN-M12** has no source column ("—"); the learner text says that the paper and the lecture have no line here. The row's status is proved (it is the Atlas's own table of the kinds of i), so it does not say "ours".
7. **SPN-M23** compares with Hestenes spinors (the stored reference of S23 says so), but the research text does not name Hestenes, so the learner text cannot (R12).
8. **RIG-M27** uses fᵢⱼ without saying what it is; the learner text says "a given number for that edge direction". **RIG-M37** writes "dual(a*) ∧ (b*)", probably dual(a* ∧ b*); the learner text says "the dual of the wedge of their duals", as RIG-M48 words ganja's join.
9. **RIG-M44** names a script inside its claim, and RIG-M45 a library file name ending in `.js`; R13 refuses both, so the learner texts say "a separate script" and "the ganja library 1.0.189".
10. **FRQ-M40** cites "D.1, D.2": a lone capital D fails R4, so the learner text says "the first two exercises" (of the exercises of the paper's appendix).
11. The printed lines that differ from the bit rule (F08, F10, F17, F24, F29, F30, F31, F33, F35) are translated as their two columns are written: where the columns differ (the offset of F17, the torque of F24), the learner text says both; what a difference means (a sign, a dropped factor, an order of axes) is written in the stored notes and the research level's "for the authors" fold, not in the research texts, so the learner texts do not state it.
