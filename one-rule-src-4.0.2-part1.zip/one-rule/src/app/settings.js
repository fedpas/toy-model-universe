// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/settings.js — mode, level, lens, view, conv and theme. They live in the address (?m= &l= &lens= &view= &conv= &theme=), so a link
// reproduces a view. From 4.0.0 (D92) the lenses are three switches: `lens` is a dialect (a lens that translates), `view` a view (a lens that
// renders a label: the shapes, the labels), `conv` a convention (a toggle); an address that names a view or a toggle under `lens`, as every
// address did before, is read into the right switch (normalize), so the old links keep their meaning.
// localStorage keeps the last ones as a convenience for an address that names none (every access in try/catch). An address that names no
// setting opens with the stored choice, and on a first visit (nothing stored, or storage blocked) at learner level (A50, STORY_PLAN §2.7):
// the address always wins, a stored choice wins over the first-visit view, and the level switch in the shell reaches research.
import { getHash, parseHash, replaceHash, subscribeLocation } from './location.js';
import { lensRole } from './vocab.js';

export const DEFAULTS = Object.freeze({ mode: 'phys', level: 'research', lens: null, view: null, conv: null, theme: 'auto' });
/** the view of a first visit: an address without settings and nothing stored opens at learner level */
export const FIRST_VISIT = Object.freeze({ ...DEFAULTS, level: 'learner' });
const SETTING_KEYS = ['m', 'l', 'lens', 'view', 'conv', 'theme'];
const STORE_KEY = 'one-rule.settings';
const THEMES = ['auto', 'light', 'dark'];

const key = v => (typeof v === 'string' && /^[a-z0-9-]{1,40}$/.test(v) ? v : null);
export function normalize(s) {
  // a lens key under the wrong switch goes to its own: `lens=cube` (an address from before 4.0.0) is the view cube; a view named as `conv` is the view
  const slots = { dialect: null, view: null, toggle: null };
  for (const [k, slot] of [['lens', 'dialect'], ['view', 'view'], ['conv', 'toggle']]) { const v = key(s[k]); if (v && slots[lensRole(v)] == null) slots[lensRole(v)] = v; else if (v && slot === lensRole(v)) slots[slot] = v; }
  return {
    mode: s.mode === 'math' ? 'math' : 'phys',
    level: s.level === 'learner' ? 'learner' : 'research',
    lens: slots.dialect,
    view: slots.view,
    conv: slots.toggle,
    theme: THEMES.includes(s.theme) ? s.theme : 'auto',
  };
}
export function settingsFromQuery(q) {
  return normalize({ mode: q.get('m'), level: q.get('l'), lens: q.get('lens'), view: q.get('view'), conv: q.get('conv'), theme: q.get('theme') });
}
/** the query of a settings object: only what differs from the defaults */
export function settingsQuery(s) {
  const q = new URLSearchParams();
  if (s.mode === 'math') q.set('m', 'math');
  if (s.level === 'learner') q.set('l', 'learner');
  if (s.lens) q.set('lens', s.lens);
  if (s.view) q.set('view', s.view);
  if (s.conv) q.set('conv', s.conv);
  if (s.theme && s.theme !== 'auto') q.set('theme', s.theme);
  return q;
}
const same = (a, b) => a.mode === b.mode && a.level === b.level && a.lens === b.lens && a.view === b.view && a.conv === b.conv && a.theme === b.theme;

function readStored() {
  try {
    const raw = window.localStorage.getItem(STORE_KEY);
    return raw ? normalize(JSON.parse(raw)) : null;
  } catch { return null; }
}
function writeStored(s) {
  try { window.localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch { /* private mode or blocked storage: the address still holds the view */ }
}

/** the address with these settings, keeping the path and any other parameter */
export function hashWithSettings(hash, s, { dropAt = false } = {}) {
  const { path, query } = parseHash(hash);
  const q = new URLSearchParams(query);
  SETTING_KEYS.forEach(k => q.delete(k));
  if (dropAt) q.delete('at');
  const merged = new URLSearchParams(settingsQuery(s));
  for (const [k, v] of q) merged.set(k, v);
  const qs = merged.toString();
  return '#/' + path + (qs ? '?' + qs : '');
}

function set(partial) {
  const now = getSettings();
  const next = normalize({ mode: now.mode, level: now.level, lens: now.lens, view: now.view, conv: now.conv, theme: now.theme, ...partial });
  if (same(next, now)) return;
  if (typeof window !== 'undefined') writeStored(next);
  replaceHash(hashWithSettings(getHash(), next, { dropAt: true }));
}

let snapHash = null, snap = null;
/** the current settings, as a stable object per address (for useSyncExternalStore) */
export function getSettings() {
  const h = getHash();
  if (h !== snapHash || !snap) {
    snapHash = h;
    snap = Object.freeze({ ...settingsFromQuery(parseHash(h).query), set });
  }
  return snap;
}
export { subscribeLocation as subscribeSettings };

/** the settings an address opens with: its own when it names any (the address wins), else the stored choice, else the first visit's view */
export function startSettings(query, stored) {
  if (SETTING_KEYS.some(k => query.has(k))) return settingsFromQuery(query);
  return stored ? normalize(stored) : FIRST_VISIT;
}

/** once, before the first render in the browser: an address without settings takes the stored ones (or, on a first visit, learner level);
 *  later views are stored. The first visit's view goes into the address and is not stored; a later change of view is. */
let started = false;
export function initSettings() {
  if (started || typeof window === 'undefined') return;
  started = true;
  const h = getHash();
  const { query } = parseHash(h);
  if (!SETTING_KEYS.some(k => query.has(k))) {
    const start = startSettings(query, readStored());
    if (!same(start, DEFAULTS)) replaceHash(hashWithSettings(h, start));
  }
  let last = getSettings();
  subscribeLocation(() => { const s = getSettings(); if (!same(s, last)) { last = s; writeStored(normalize(s)); } });
}
