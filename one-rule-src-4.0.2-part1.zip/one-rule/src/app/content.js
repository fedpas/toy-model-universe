// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/content.js — content access for every part of the app (BUILD_CONTRACTS §Interfaces 1).
// Exports exactly: loadTable, useTable, useSettings, textFor, statusOf. The cache and indexes live in store.js.
import { useEffect, useReducer, useSyncExternalStore } from 'react';
import { loadTableRaw, peekTable, tableError, textRecord } from './store.js';
import { getSettings, subscribeSettings } from './settings.js';

/** Promise of the parsed content/<name>.json, fetched from ./content/<name>.json; derived tables are named derived_<name>. */
export function loadTable(name) {
  return loadTableRaw(name);
}

/** React hook: [data, error]; data is null while loading. A null name asks for no table (a component that needs one only in a view): [null, null]. */
export function useTable(name) {
  const [, force] = useReducer(x => x + 1, 0);
  const data = name ? peekTable(name) : null;
  useEffect(() => {
    if (!name || peekTable(name) !== undefined) return undefined;
    let alive = true;
    loadTableRaw(name).then(() => alive && force(), () => alive && force());
    return () => { alive = false; };
  }, [name]);
  if (!name) return [null, null];
  return data !== undefined ? [data, null] : [null, tableError(name)];
}

/** { mode: 'phys'|'math', level: 'research'|'learner', lens: string|null, theme: 'auto'|'light'|'dark', set(partial) } — from the address. */
export function useSettings() {
  return useSyncExternalStore(subscribeSettings, getSettings, getSettings);
}

/**
 * The body of the text record for a row after the fallback chain of 02 §2, or null.
 * Options: { mode, level, lens, register = 'full', chain = null }. Learner level never falls back to a research text.
 * `chain` (the story round, D54): at learner level, inside that chain, the row's span (register "span", interface 41) through 02 §2's mode and lens
 * fallback, then the row's learner text of the register asked ("full" when the register asked is "span"), then nothing; at research level it is
 * ignored. That is the only fallback, and it never crosses levels. `chain` is a chain's id, or a Map row id → chain id (the chains that tell the rows
 * of a page: a caller that reads many rows at once, as the glossary's first-use rule does, reads each in the words the page shows it in).
 * texts.json must be loaded (the app loads it before any page renders); while it is not, this returns null and starts the load.
 */
export function textFor(rowId, { mode = 'phys', level = 'research', lens = null, register = 'full', chain = null } = {}) {
  if (peekTable('texts') === undefined) { loadTableRaw('texts').catch(() => {}); return null; }
  const ch = chain instanceof Map ? chain.get(rowId) || null : chain;
  if (ch && level === 'learner') {
    const span = textRecord(rowId, { mode, level, lens, chain: ch });
    if (span) return span.record.body;
  }
  const hit = textRecord(rowId, { mode, level, lens, register: register === 'span' ? 'full' : register });
  return hit ? hit.record.body : null;
}

/** The record of content/derived/status.json for a row (status, new, badge, signature, grade, mask, prime, address, neighbours), or null. */
export function statusOf(rowId) {
  const st = peekTable('derived_status');
  if (st === undefined) { loadTableRaw('derived_status').catch(() => {}); return null; }
  return (st && st[rowId]) || null;
}
