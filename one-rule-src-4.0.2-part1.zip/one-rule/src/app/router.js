// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/router.js — hash routes (#/ the door, #/rule, #/cells, #/cells/p,q, #/clock, #/light, #/spine (#/steps redirects to it; #/applications and #/ways open its parts), #/steps/<id>, #/shapes, #/matter,
// #/lenses, #/lenses/<key>, #/logbook[/<tab>], #/ask, #/glossary, #/agents, #/tutorials, #/notes, #/notes/<key>) and links that carry the current
// settings.
// The door (round 7, docs/round7/PLAN.md R7-2, §4 ARCH): `#/` is the door ("Start here", src/pages/Door.jsx). The start page of the full Atlas (the
// page record `atlas` of pages.json: the rule in one screen and the stats) is drawn at the bottom of the door, so its address `#/atlas` redirects to
// the door at that part (`#/?at=atlas`; an address that names its own place, `#/atlas?at=<row>`, keeps it), the settings kept. The leaves have no pages
// of their own: each lives at the top or in a section of an Atlas page (content/explore/registry.json, the door's data, bundled here as
// content/story/landing.json is), so the old addresses redirect — `#/explore` to the door, `#/explore/<slug>` to the leaf's page at its anchor
// (`at=top` or `at=<section>`), keeping the settings and every other parameter of the address; a slug the map does not know goes to the door.
// The landing (content/story/landing.json; decision A50, STORY_PLAN §2.7, interface 30): the start page of the full Atlas moves to the address its
// `routes` give it (`atlas`, titled by its `titles`); `chapters` are the door's chapter cards. applyLanding() applies landing.json to the loaded
// tables at run time — the route renames on pages.json and on every shownOn entry, the page titles — as tools/merge_story.mjs applies the renames on
// disk: once the merge has run there is nothing left to rename, and only the titles are applied here.
import { useMemo, useSyncExternalStore } from 'react';
import { getHash, parseHash, pushHash, subscribeLocation } from './location.js';
import { settingsQuery } from './settings.js';
import { pagesByRoute, peekTable, primeTable } from './store.js';
import LANDING from '../../content/story/landing.json';
import REGISTRY from '../../content/explore/registry.json';

// ---------------------------------------------------------------- the landing (content/story/landing.json)
const L = LANDING && typeof LANDING === 'object' && !Array.isArray(LANDING) ? LANDING : {};
const str = x => typeof x === 'string';
/** route in the tables → its address: the start page '' → 'atlas' */
const RENAMES = new Map(Object.entries(L.routes && typeof L.routes === 'object' ? L.routes : {}).filter(([a, b]) => str(b) && b !== a));
/** the titles landing.json gives a page, by its address: { phys, math, learner } */
const TITLES = new Map(Object.entries(L.titles && typeof L.titles === 'object' ? L.titles : {}).filter(([, t]) => t && typeof t === 'object'));
/** the address of the start page of the full Atlas ("The Atlas"): 'atlas' once landing.json moves it, else '' */
export const ATLAS_ROUTE = RENAMES.has('') ? RENAMES.get('') : '';
/** the part of the door that draws the start page (src/pages/Door.jsx, #sec-atlas): where `#/atlas` lands, `#/?at=atlas` */
export const ATLAS_AT = 'atlas';

/** the main pages for the door's chapter cards, in landing.json's order (v15's): the routes the tables have, or that the router knows */
export function landingChapters() {
  const pages = pagesByRoute();
  return (Array.isArray(L.chapters) ? L.chapters : []).filter(r => str(r) && r && (!pages || pages.has(r) || !['notfound', 'redirect'].includes(matchRoute(r).name)));
}

const sameTitle = (a, b) => !!a && Object.entries(b).every(([k, v]) => a[k] === v);
let landed = null;
/**
 * landing.json on the loaded tables (plan §3.3, done at run time while tools/merge_story.mjs has not renamed on disk): a page whose route
 * it renames, when no page holds the new route yet, takes the new route, and every shownOn entry that names the old route follows it (also
 * when the merge renamed the page and left a placement behind); a page it gives a title takes that title. New arrays replace the cached
 * tables (the indexes follow their identity); idempotent, cheap once applied. Returns true when it changed a table.
 */
export function applyLanding() {
  const pages = peekTable('pages'), rows = peekTable('rows');
  if (!Array.isArray(pages) || !Array.isArray(rows)) return false;
  if (landed && landed.pages === pages && landed.rows === rows) return false;
  const have = new Set(pages.map(p => p && p.route));
  const ren = new Map([...RENAMES].filter(([from, to]) => have.has(from) && !have.has(to)));
  let pagesOut = pages, rowsOut = rows;
  const renamed = pages.map(p => {
    if (!p || typeof p !== 'object') return p;
    let q = ren.has(p.route) ? { ...p, route: ren.get(p.route) } : p;
    const t = TITLES.get(q.route);
    if (t && !sameTitle(q.title, t)) q = { ...q, title: { ...(q.title || {}), ...t } };
    return q;
  });
  if (renamed.some((p, i) => p !== pages[i])) pagesOut = renamed;
  // a placement follows its page: it names a route no page holds any more, and a page holds the new one (renamed here, or by the merge)
  const after = new Set(renamed.map(p => p && p.route));
  const moves = new Map([...RENAMES].filter(([from, to]) => !after.has(from) && after.has(to)));
  if (moves.size) {
    const moved = rows.map(r => {
      const so = r && Array.isArray(r.shownOn) ? r.shownOn : null;
      if (!so || !so.some(e => e && moves.has(e.page))) return r;
      return { ...r, shownOn: so.map(e => (e && moves.has(e.page) ? { ...e, page: moves.get(e.page) } : e)) };
    });
    if (moved.some((r, i) => r !== rows[i])) rowsOut = moved;
  }
  if (pagesOut !== pages) primeTable('pages', pagesOut);
  if (rowsOut !== rows) primeTable('rows', rowsOut);
  landed = { pages: pagesOut, rows: rowsOut };
  return pagesOut !== pages || rowsOut !== rows;
}

/** the route in the tables of the page of the twenty steps: 'spine' once landing.json is applied (4.0.0, D91), 'steps' before */
export function spinePage() {
  const pages = pagesByRoute();
  return pages && !pages.has('spine') && pages.has('steps') ? 'steps' : 'spine';
}

/** the route in the tables of the start page of the full Atlas: its address once landing.json is applied, '' before */
export function atlasPage() {
  const pages = pagesByRoute();
  return pages && !pages.has(ATLAS_ROUTE) && pages.has('') ? '' : ATLAS_ROUTE;
}

// ---------------------------------------------------------------- the map of the leaves (content/explore/registry.json)
const R = REGISTRY && typeof REGISTRY === 'object' ? REGISTRY : {};
const listOf = (k, kind) => (Array.isArray(R[k]) ? R[k] : []).filter(e => e && str(e.slug)).map(e => ({ ...e, kind }));
/** every leaf of the door's map: the path of eight, the shelf, the lens explorers — { slug, name, kind, n?, needs?, under?, figure, page, anchor, lens, try, detail } */
export const LEAVES = Object.freeze([...listOf('path', 'path'), ...listOf('shelf', 'shelf'), ...listOf('lenses', 'lens')]);
/** the leaf of a slug, or null */
export const leafOf = slug => LEAVES.find(e => e.slug === slug) || null;
/** the place a leaf opens: { path: its page, at: its anchor ("top", or the section that holds it) } */
export const leafPlace = e => ({ path: e.page, at: e.anchor || 'top' });

// ---------------------------------------------------------------- routes
/** where an old address of the leaves leads: the door for #/explore and for a slug the map does not know, else the leaf's page at its anchor */
function exploreTarget(segs) {
  if (segs.length !== 2) return { path: '', at: null };
  const e = leafOf(segs[1]);
  return e && e.page != null ? leafPlace(e) : { path: '', at: null };
}

/** path → what to render */
export function matchRoute(path) {
  const segs = String(path || '').split('/').filter(Boolean);
  const pages = pagesByRoute();
  if (!segs.length) return { name: 'door', page: '' };
  const route = segs.join('/');
  // the start page of the full Atlas is a part of the door: its address leads there (App.jsx replaces it; the door draws its record's rows)
  if (ATLAS_ROUTE && route === ATLAS_ROUTE) return { name: 'door', page: '', redirect: { path: '', at: ATLAS_AT } };
  const [a, b] = segs;
  if (a === 'explore') {
    const to = exploreTarget(segs);
    const m = to.path ? matchRoute(to.path) : { name: 'door', page: '' };
    return { ...m, redirect: to };
  }
  if (a === 'cells') return b ? { name: 'cell', key: segs.slice(1).join('/') } : { name: 'cells', page: 'cells' };
  // the spine (4.0.0, D91): the page of the twenty steps is addressed as #/spine (landing.json renames the route steps → spine); #/steps, the address
  // before, redirects there, and #/applications and #/ways open its parts (the sections sec-applications and sec-ways)
  if (a === 'spine' && !b) return { name: 'steps', page: spinePage() };
  if (a === 'steps' && !b) return pages && pages.has('steps') && !pages.has('spine') ? { name: 'steps', page: 'steps' } : { name: 'steps', page: spinePage(), redirect: { path: 'spine' } };
  if ((a === 'applications' || a === 'ways') && !b) return { name: 'steps', page: spinePage(), redirect: { path: 'spine', at: a } };
  if (a === 'lenses') return b ? { name: 'lens', key: b, page: 'lenses' } : { name: 'lenses', page: 'lenses' };
  if (a === 'logbook') return { name: 'logbook', page: 'logbook', tab: b || null };
  if (a === 'ask' && !b) return { name: 'ask', page: 'ask' };
  if (a === 'glossary' && !b) return { name: 'glossary', page: 'glossary' };
  if (a === 'agents' && !b) return { name: 'agents', page: 'agents' };
  if (a === 'tutorials' && !b) return { name: 'tutorials', page: 'tutorials' };
  // the notes to researchers (content/notes.json, src/pages/Notes.jsx): the list, and one note by its key
  if (a === 'notes' && segs.length <= 2) return b ? { name: 'note', key: b, page: 'notes' } : { name: 'notes', page: 'notes' };
  if (pages && pages.has(route)) return { name: 'page', page: route };
  return { name: 'notfound', path };
}

/**
 * The address an old address of the leaves is replaced by (location.replace): the target's path, the settings and every other parameter of the old
 * address kept, and at=<anchor> unless the address names its own place. null when the address needs no redirect.
 */
export function redirectHash(hash) {
  const { path, query } = parseHash(hash);
  const m = matchRoute(path);
  if (!m.redirect) return null;
  const q = new URLSearchParams(query);
  if (m.redirect.at && !q.has('at')) q.set('at', m.redirect.at);
  const qs = q.toString();
  const p = String(m.redirect.path || '');
  return '#/' + p.split('/').filter(Boolean).map(s => encodeURIComponent(s).replace(/%2C/gi, ',')).join('/') + (qs ? '?' + qs : '');
}

export function parseRoute(hash) {
  const { path, query } = parseHash(hash);
  return { path, query, at: query.get('at'), match: matchRoute(path) };
}

/** React hook: the current route { path, query, at, match } — matched again once pages.json is loaded (generic routes come from it) */
export function useRoute() {
  const hash = useSyncExternalStore(subscribeLocation, getHash, getHash);
  const pages = peekTable('pages');
  return useMemo(() => parseRoute(hash), [hash, pages]);
}

/** the address of a route under the given settings, with optional extra parameters (e.g. { at: 'GRV-012' }) */
export function buildHref(path, settings, extra) {
  const q = settingsQuery(settings || {});
  if (extra) for (const [k, v] of Object.entries(extra)) if (v != null && v !== '') q.set(k, String(v));
  const qs = q.toString();
  const p = String(path || '').replace(/^\/+/, '');
  return '#/' + p.split('/').map(s => encodeURIComponent(s).replace(/%2C/gi, ',')).join('/') + (qs ? '?' + qs : '');
}

export function navigate(path, settings, extra) { pushHash(buildHref(path, settings, extra)); }

/** route of a cell page from a cells entry: "(1,3,0)" → "cells/1,3"; "(1,n-1,0)" → "cells/1,n-1,0"; "all n" → "cells/all n" */
export function cellRoute(cell) {
  const m = /^\((\d+),(\d+),(\d+)\)$/.exec(cell);
  if (m) return `cells/${m[1]},${m[2]}${m[3] !== '0' ? ',' + m[3] : ''}`;
  return 'cells/' + cell.replace(/^\(|\)$/g, '');
}
