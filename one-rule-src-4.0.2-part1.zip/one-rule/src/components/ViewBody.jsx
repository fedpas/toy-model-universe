// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/ViewBody.jsx — the body of a page at research level, composed as the researcher view prints it (4.0.1; tools/researcher_view.mjs
// and tools/views/spine.mjs, the format of the shifted page's mockup of round 20, docs/round20/staging/shifted_view): the page's figure and the
// hero row; the page's lead as the first lead block ("The page opens"); the notes of the top; "At a glance"; then the parts (h2) and the sections
// (h3), each section its lead block ("The source's move" on a way, "The section opens" elsewhere), its figures, its chains (h4: the chain's title,
// its lead block, its positions in chain order — a row block each, a mention a pointer to where the page tells the row — and the mathematics twin
// after its row), then "More statements" (the rows of the section no chain tells, its details, its evidence rows); what stays open after the
// part (or after the section on a page without parts); the sections of the reserved parts after the body (open, reference, inputs); the next line.
// Every statement is a Statement (variant view, the row block; variant lead, the lead block): the words of the tables, once each. A section the
// page draws itself (custom: the cells' lattice) keeps its own drawing under its heading. Learner level keeps the composition of the story round
// (src/pages/PageView.jsx, Section.jsx).
import { Fragment } from 'react';
import { useTable } from '../app/content.js';
import TallyLine, { isTallyRow } from '../figures/physics/TallyLine.jsx';
import { useRoute } from '../app/router.js';
import Statement from './Statement.jsx';
import Link from './Link.jsx';
import { FigureBlock, ViewSlot } from './Section.jsx';
import { TOP_WORDS } from '../app/vocab.js';
import { useWayLens } from './TwoWays.jsx';
import LeafLensChip from './LeafLensChip.jsx';
import { useSettings } from '../app/content.js';
import { rowsById } from '../app/store.js';

export const VIEW_WORDS = {
  pageOpens: 'The page opens', note: 'A note of the page top', glance: 'At a glance', sectionOpens: 'The section opens', sourceMove: 'The source’s move',
  chainOpens: 'The chain opens', more: 'More statements', statements: 'Statements', toldIn: 'told in', open: 'What stays open', reference: 'Reference',
  inputs: 'What this page takes from outside', next: 'Next', narration: 'In the Atlas’s words',
};

const isStory = id => (rowsById()?.get(id) || {}).kind === 'story';
/** a row block; a tally row (EQN-006 … EQN-020, P11's TL1) keeps its four cells under their names inside the block (TallyLine, variant view) */
const Row = ({ id, twinOf = null, told = false, anchor = null }) => (isTallyRow(id) ? <TallyLine key={id} id={id} variant="view" told={told} /> : <Statement key={id} id={id} variant="view" twinOf={twinOf} told={told} anchor={anchor} />);
const Lead = ({ id, label }) => (id ? <Statement id={id} variant="lead" label={label} /> : null);
/** the rows of a list, story rows as lead blocks (a narration placed among results), the others as row blocks */
const Rows = ({ ids, label = VIEW_WORDS.narration }) => ids.map(id => (isStory(id) ? <Lead key={id} id={id} label={label} /> : <Row key={id} id={id} />));

/** the way in of a page top (TwoWays, round 7): the hero row as a row block in the mode's words, with the chip that reads the page in the leaf's lens */
function WayIn({ id, lens, rowIds, anchor }) {
  const s = useSettings();
  const way = useWayLens(lens, rowIds);
  return (
    <div className="view-ways" data-row={id}>
      <section className="top-way" data-mode={s.mode} aria-label={s.mode === 'math' ? TOP_WORDS.math : TOP_WORDS.phys}>
        <Row id={id} anchor={anchor} />
        {way ? <div className="top-way-lens"><LeafLensChip lens={way} rowIds={rowIds} /></div> : null}
      </section>
    </div>
  );
}

/** a mention: where the page tells the row (the researcher view's `.see` line) */
function See({ p }) {
  const route = useRoute();
  return (
    <div className="see" data-mention={p.id} data-row={p.id}>
      <span className="rid">{p.id}</span> {VIEW_WORDS.toldIn} {p.toldIn ? <Link to={route.path} at={p.id} data-connective="told-in">{p.toldIn.title}</Link> : 'elsewhere'}{p.link && p.link.rel && p.link.rel !== 'order' ? <span className="see__rel"> · {p.link.rel}</span> : null}
    </div>
  );
}

/** a chain: its title, its lead, its positions in order */
function ChainView({ ch, sid }) {
  return (
    <div className="view-chain" id={`chain-${ch.id}`} data-chain={ch.id} data-section={sid}>
      <h4 className="chain__title view-h4" id={`h-chain-${ch.id}`}>{ch.title}</h4>
      <Lead id={ch.lead} label={VIEW_WORDS.chainOpens} />
      {ch.positions.map(p => (p.mention ? <See key={`${p.n}-${p.id}`} p={p} /> : <Fragment key={`${p.n}-${p.id}`}><Row id={p.id} twinOf={p.twinOf} told /></Fragment>))}
    </div>
  );
}

/** the figures of a section as the story composition draws them (Section.jsx): the column, the views of one slot under chips, "Another view" */
function Figures({ blocks }) {
  const shown = blocks.filter(b => !b.detail), detail = blocks.filter(b => b.detail), views = shown.filter(b => b.view);
  if (!blocks.length) return null;
  return (
    <div className="sec__figs view-figs">
      {shown.map(b => (b.view ? (b === views[0] ? <ViewSlot key="views" views={views} /> : null) : <FigureBlock key={b.id} b={b} />))}
      {detail.length ? (
        <details className="sec__another" data-another={detail.map(b => b.id).join(' ')}>
          <summary className="chip sec__another-chip">{TOP_WORDS.anotherView}</summary>
          {detail.map(b => <FigureBlock key={b.id} b={b} />)}
        </details>
      ) : null}
    </div>
  );
}

/** a body section in the view's order */
function SectionView({ sec, way, custom, openAfter }) {
  const figs = (Array.isArray(sec.blocks) && sec.blocks.length ? sec.blocks : (sec.figures || []).map((id, i) => ({ id, kind: 'own', captions: i === 0 ? sec.captions || [] : [], tryLine: null, detail: false })));
  const chains = Array.isArray(sec.chains) ? sec.chains : [];
  const told = new Set(sec.told || []);
  const rest = [...new Set([...(sec.key || []), ...(sec.more || []), ...(sec.numbers || [])])].filter(id => !told.has(id) && id !== sec.lead);
  const own = custom ? custom(sec) : null;
  return (
    <section className="sec sec--view" id={`sec-${sec.id}`} data-section={sec.id} aria-labelledby={sec.heading ? `h-${sec.id}` : undefined} aria-label={sec.heading ? undefined : sec.label} data-outline={sec.heading || undefined}>
      {sec.heading ? <h3 className="sec__title view-h3" id={`h-${sec.id}`}>{sec.heading}</h3> : null}
      <Lead id={sec.lead} label={way ? VIEW_WORDS.sourceMove : VIEW_WORDS.sectionOpens} />
      {sec.connective ? <p className="view-try" data-connective="section">{sec.connective}</p> : null}
      <Figures blocks={figs} />
      {own}
      {chains.map(ch => <ChainView key={ch.id} ch={ch} sid={sec.id} />)}
      {!own && rest.length ? (
        <div className="view-more" data-more={sec.id}>
          <h4 className="view-h4" id={`h-more-${sec.id}`}>{chains.length ? VIEW_WORDS.more : VIEW_WORDS.statements}</h4>
          <Rows ids={rest} />
        </div>
      ) : null}
      {openAfter}
    </section>
  );
}

/** a group of the open fold as the view prints it: a heading, its lead, its rows (and its sub-groups) */
function OpenGroup({ g, h = 'h4' }) {
  const H = h;
  const ids = g.sub ? [] : (g.rows || []);
  return (
    <div className="view-open" id={`open-${g.id}`} data-open-group={g.id}>
      <H className={`view-${h}`} id={`h-open-${g.id}`}>{g.label}</H>
      <Lead id={g.lead || null} label={VIEW_WORDS.sectionOpens} />
      <Rows ids={ids} />
      {g.sub ? g.sub.map(x => <OpenGroup key={x.id} g={x} h="h4" />) : null}
    </div>
  );
}

export default function ViewBody({ model, custom, heroAside = null, afterHero = null, afterSections = null, rowIds = [] }) {
  const [ways] = useTable('ways');
  const way = (ways || []).some(w => w.page === model.route);
  const customOf = sec => (custom && custom[sec.id] ? custom[sec.id] : null);
  // a model built elsewhere (a cell's page) has sections alone: the other fields are read as empty
  const sections = Array.isArray(model.sections) ? model.sections : [];
  const parts = Array.isArray(model.parts) ? model.parts : [];
  const open = Array.isArray(model.open) ? model.open : [];
  const intro = model.intro || {};
  const body = sections.filter(sec => sec.show !== false && (sec.placement || 'body') === 'body');
  // the body in the model's order: consecutive sections of one part under its heading (as src/pages/PageView.jsx groups them)
  const titles = new Map(parts.map(p => [p.id, p.title]));
  const blocks = [];
  for (const sec of body) { const pid = sec.part || null, last = blocks[blocks.length - 1]; if (pid && last && last.pid === pid) last.secs.push(sec); else blocks.push({ pid, secs: [sec] }); }
  const told = new Set(sections.flatMap(sec => sec.told || []));
  const partIds = new Set(parts.map(p => p.id));
  // the open groups: by part (after the part), by section (after the section), and the open part's own groups (after the body)
  const openOfPart = pid => open.filter(g => g.id === pid && !g.sub && g.part == null && partIds.has(g.id));
  const openOfSection = sid => open.filter(g => g.id === sid && !g.sub && g.part == null && !partIds.has(g.id));
  const placed = new Set();
  const renderOpen = (gs, h) => gs.filter(g => !placed.has(g)).map(g => { placed.add(g); return <OpenGroup key={g.id} g={g} h={h} />; });
  const section = (sec, openAfter = null) => <SectionView key={sec.id} sec={sec} way={way} custom={customOf(sec)} openAfter={openAfter} />;
  const hero = model.top && model.top.hero ? model.top.hero : null;
  // the hero row stands in the page top as the way in (round 7); where a chain of the page tells it, the chain's block is the anchored one (D52 excepts the top)
  const heroRow = model.hero && model.hero.id ? model.hero.id : null;
  const notes = (model.top && model.top.notes) || [];
  const introRows = [...new Set([...(intro.glance || []), ...(intro.more || [])])];
  return (
    <div className="view-body" data-view="research">
      {heroAside || (hero && hero.figure) || heroRow || notes.length ? (
        <section className={`top top--view${model.top && model.top.fromMap ? ' top--leaf' : ''}`} id="sec-top" data-top={model.top && model.top.leaf || undefined} aria-label="The page top">
          {heroAside || (hero && hero.figure) ? (
            <div className={`top-hero${!heroAside && hero && hero.wide ? ' top-hero--wide' : ''}`} id="hero" data-size={!heroAside && hero && hero.wide ? 'wide' : undefined} data-figure={heroAside ? undefined : hero.figure}>
              {heroAside || <FigureBlock b={{ id: hero.figure, kind: 'own', captions: model.hero ? model.hero.captions || [] : [], tryLine: null, detail: false }} />}
            </div>
          ) : null}
          {model.top && model.top.tryLine ? <p className="top-try view-try" data-connective="try"><span className="top-try__label">{TOP_WORDS.try}</span> <span className="top-try__text">{model.top.tryLine}</span></p> : null}
          <Lead id={intro.lead || null} label={VIEW_WORDS.pageOpens} />
          {notes.length ? (
            <ol className="top-notes top-notes--view" aria-label={TOP_WORDS.notes}>
              {notes.map((id, i) => <li className="top-note" key={id} data-note={i + 1} data-row={id}><Lead id={id} label={VIEW_WORDS.note} /></li>)}
            </ol>
          ) : null}
          {heroRow ? <WayIn id={heroRow} lens={model.top && model.top.ways ? model.top.ways.lens : null} rowIds={rowIds} anchor={!told.has(heroRow)} /> : null}
        </section>
      ) : <Lead id={intro.lead || null} label={VIEW_WORDS.pageOpens} />}
      {afterHero}
      {introRows.length ? (
        <section className="view-glance" id="sec-glance" aria-labelledby="h-glance" data-outline={VIEW_WORDS.glance}>
          <h4 className="view-h4" id="h-glance">{VIEW_WORDS.glance}</h4>
          <Rows ids={introRows} />
        </section>
      ) : null}
      {renderOpen(open.filter(g => g.id === 'intro'), 'h4')}
      {blocks.map((b, i) => (b.pid ? (
        <div className="part view-part" key={`part-${b.pid}-${i}`} id={`part-${b.pid}`} data-part={b.pid}>
          {titles.get(b.pid) ? <h2 className="part__title view-h2" id={`h-part-${b.pid}`}>{titles.get(b.pid)}</h2> : null}
          {b.secs.map(sec => section(sec, openOfSection(sec.id).length ? <div className="view-open-after">{renderOpen(openOfSection(sec.id), 'h4')}</div> : null))}
          {openOfPart(b.pid).length ? <div className="view-open-after"><h3 className="view-h3" id={`h-open-part-${b.pid}`}>{VIEW_WORDS.open}</h3>{renderOpen(openOfPart(b.pid), 'h4')}</div> : null}
        </div>
      ) : b.secs.map(sec => section(sec, openOfSection(sec.id).length ? <div className="view-open-after">{renderOpen(openOfSection(sec.id), 'h4')}</div> : null))))}
      {afterSections}
      {open.some(g => !placed.has(g)) ? (
        <section className="sec sec--view view-open-part" id="sec-open" aria-labelledby="h-open" data-outline={VIEW_WORDS.open}>
          <h2 className="view-h2" id="h-open">{VIEW_WORDS.open}</h2>
          {renderOpen(open, 'h3')}
        </section>
      ) : null}
      {model.reference && model.reference.length ? (
        <section className="sec sec--view view-reference" id="sec-reference" aria-labelledby="h-reference" data-outline={VIEW_WORDS.reference}>
          <h2 className="view-h2" id="h-reference">{VIEW_WORDS.reference}</h2>
          {model.reference.filter(sec => sec.show).map(sec => <SectionView key={sec.id} sec={sec} way={way} custom={null} openAfter={null} />)}
        </section>
      ) : null}
      {model.inputs ? (
        <section className="sec sec--view view-inputs" id="sec-inputs" aria-labelledby="h-inputs" data-outline={VIEW_WORDS.inputs}>
          <h2 className="view-h2" id="h-inputs">{VIEW_WORDS.inputs} ({model.inputs.rows.length})</h2>
          <Lead id={model.inputs.lead} label={VIEW_WORDS.sectionOpens} />
          <Rows ids={model.inputs.rows} />
        </section>
      ) : null}
    </div>
  );
}
