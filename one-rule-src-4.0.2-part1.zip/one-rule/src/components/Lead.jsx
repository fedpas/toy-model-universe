// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Lead.jsx — a story row placed by its role (docs/STORY_PLAN.md §1.3, §2.1–2.2; BUILD_CONTRACTS interface 26):
//   Lead     the lead of the page (variant "intro"), of a section ("section"), of a group of the open fold ("group"), of the inputs ("inputs"), the
//            page's next line ("next"), a learner-only paragraph of the intro ("intro-more"). It renders the row through Statement, so its words are
//            the row's text record and the coverage invariant holds unchanged; no evidence chevron, and no badge — a story row's status is meta and
//            carries none (a row whose computed status carries a badge keeps it: tests/coverage.test.mjs asks for a badge exactly where the status has
//            one). Statement's body variant gives the anchor row-<id> that at= scrolls to and folds a long paragraph; the look comes from the wrapper
//            class (lead lead--<variant>, src/styles/story.css), since Statement is not ours to give a variant.
//   Caption  a caption row under its figure (the hero's or a section's): the compact Statement (its badge and chevron as any statement), in a
//            wrapper that carries the anchor row-<id>.
import { useSettings, textFor, statusOf } from '../app/content.js';
import Statement from './Statement.jsx';

const hasWords = (id, s) => textFor(id, { mode: s.mode, level: s.level, lens: s.lens }) != null;

const LEAD_LABELS = { section: 'The section opens', next: 'Next', intro: 'The page opens' };
export default function Lead({ id, variant = 'section', label = null }) {
  const s = useSettings();
  if (!id || !hasWords(id, s)) return null;
  const st = statusOf(id);
  // 4.0.1: at research level a lead is the researcher view's lead block (its label, its id, its words, its displays)
  if (s.level !== 'learner') return <div className={`lead lead--${variant} lead--view`} data-role={variant === 'next' ? 'next' : 'lead'}><Statement id={id} variant="lead" label={label || LEAD_LABELS[variant] || LEAD_LABELS.section} /></div>;
  return (
    <div className={`lead lead--${variant}`} data-role={variant === 'next' ? 'next' : 'lead'}>
      <Statement id={id} badge={!!(st && st.badge)} evidence={false} />
    </div>
  );
}

export function Caption({ id }) {
  const s = useSettings();
  if (!id || !hasWords(id, s)) return null;
  return (
    <div className="cap" id={`row-${id}`} data-role="caption">
      <Statement id={id} variant="compact" />
    </div>
  );
}
