// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Ledger.jsx — the researcher view's frame around a page at research level (4.0.0: the Shifted View mockup of round 20 as the
// format of every page, docs/round20/staging/shifted_view): ViewBox, the box under the title — the way the page follows and its source
// (content/ways.json), the page's source and its equations and conventions (content/derived/views.json, from content/views/<key>.json),
// the badge legend in one sentence — and Ledger, the end of the page: What the reader finds, and why (the rows with a reason: id, status,
// the kind of reason; the words of the reason stand under each statement); Still to compute (the reasons of kind not-run: the finite
// computations the Atlas could run on the labels and has not, with the reason's words);
// Changes from the release before (content/derived/changes.json: the rows since this release, the statuses that moved, the rows the
// release before did not have); Checks (every script the page's rows cite, with its method, controls and last run); Sources (the standard
// references the rows cite, the way's and the view's sources, the pages this one builds on). Every word comes from the tables; a check's
// method and a reference are the words of their own tables (data-source="checks", data-source="sources"), never a row's.
import { useMemo } from 'react';
import { useSettings, useTable, statusOf } from '../app/content.js';
import { rowsById, checksIndex, lastRuns, pagesByRoute } from '../app/store.js';
import { statusWord } from '../app/vocab.js';
import { resolveEvidence, REASON_WORDS, runWordOf, baseName, rowHome, pageLabel } from '../app/queries.js';
import { useKatex, texToHtml } from '../app/math.js';
import Link from './Link.jsx';

/** the word of a status key of the release before: the keys 4.0.0 split (D90) are named as that release printed them */
const PREV_WORDS = { 'proved-by-atlas': 'proved by the Atlas' };
const prevWord = k => PREV_WORDS[k] || statusWord(k) || k;
/** the inline marks a source string may carry (*italics*, [text](url)) as nodes: the words stay the table's */
const MD = /(\*[^*\n]+\*|\[[^\]\n]+\]\((?:https?:\/\/)[^\s)]+\))/g;
function md(text) {
  return String(text || '').split(MD).filter(Boolean).map((part, i) => {
    if (/^\*[^*]+\*$/.test(part)) return <i key={i}>{part.slice(1, -1)}</i>;
    const m = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(part);
    if (m) return <a key={i} href={m[2]} rel="noopener">{m[1]}</a>;
    return part;
  });
}
/** a way's source (content/ways.json): author, title, year, the link */
const SourceLine = ({ src }) => src ? <>{src.author ? `${src.author}, ` : ''}<i>{src.title}</i>{src.year ? ` (${src.year})` : ''}{src.link ? <>, <a href={src.link} rel="noopener">{src.link.replace(/^https?:\/\//, '')}</a></> : null}</> : null;
const RowRef = ({ id }) => { const h = rowHome(id); return <Link to={h.path} at={h.at} className="ledger__ref">{id}</Link>; };

/** a display formula of the conventions, typeset in display mode */
function Eq({ tex, tag }) {
  const katex = useKatex(true);
  const src = tag ? `${tex} \\tag{${tag}}` : tex;
  const html = katex ? texToHtml(src, true) : null;
  return html ? <div className="statement__eq math" data-tex={src} data-display="" dangerouslySetInnerHTML={{ __html: html }} /> : <div className="statement__eq tex">{`$$${src}$$`}</div>;
}

/** the box under the page title: the way, the source, the conventions, the badges */
export function ViewBox({ route }) {
  const s = useSettings();
  const [ways] = useTable('ways');
  const [views] = useTable('derived_views');
  if (s.level === 'learner') return null;
  const way = (ways || []).find(w => w.page === route) || null;
  const view = (views && views[route]) || null;
  return (
    <aside className="viewbox" aria-label="The source, the conventions and the badges" data-view-box="" data-source="views">
      {way ? <p><b>A way through the Atlas.</b> {way.description} {way.source ? <>The source: <SourceLine src={way.source} />.</> : null}</p> : null}
      {view && view.source ? <p><b>The source.</b> {md(view.source)}</p> : null}
      {view && view.conventions ? (
        <>
          <p><b>Equations and conventions.</b> {view.conventions.text}</p>
          {(view.conventions.displays || []).map((d, i) => <Eq key={i} tex={d.tex} tag={d.tag} />)}
        </>
      ) : <p><b>Equations.</b> A display formula is numbered (S<i>n</i>.<i>k</i>), the <i>k</i>-th display of step <i>n</i> of this page, from the formulas catalogue; a text that quotes a paper's own number keeps it as the paper prints it.</p>}
      <p><b>Badges.</b> Each statement carries its computed status: <b>theorem</b>, a statement for every n with a recorded run of a check that passed and a named proof; <b>computed</b>, a finite computation with a recorded run that passed, named under it; <b>standard, recomputed</b>, a standard statement a check recomputed; <b>standard</b>, a textbook fact with its reference; <b>our reading</b>, an interpretation the Atlas proposes, with the reason it cannot be proved; <b>open</b>, a question, with the reason it cannot be computed; <b>needs an input</b>, a convention or a number taken from a source as the source states it; <b>not yet proved here</b>, a check cited without a passing run. Under each statement: its checks with their last run, its scope, its reason, what it depends on; what is left to compute is in the ledger at the end of the page.</p>
    </aside>
  );
}

/** the ledger at the end of the page, over the rows the page shows */
export default function Ledger({ route, rows }) {
  const s = useSettings();
  const [checks] = useTable('checks'); const [runs] = useTable('check_runs');
  const [changes] = useTable('derived_changes'); const [ways] = useTable('ways'); const [views] = useTable('derived_views');
  const research = s.level !== 'learner';
  const data = useMemo(() => {
    const R = rowsById(); if (!R || !research) return null;
    const ids = [...new Set(rows)].filter(id => R.has(id));
    const idx = checks ? checksIndex() : null, last = runs ? lastRuns() : null;
    const withReason = ids.filter(id => R.get(id).reason);
    const toRun = withReason.filter(id => R.get(id).reason.kind === 'not-run');
    const scripts = new Map();
    for (const id of ids) for (const ev of resolveEvidence(R.get(id), idx, last)) { const key = ev.script || ev.checkId; if (!key) continue; if (!scripts.has(key)) scripts.set(key, { ev, rows: [] }); scripts.get(key).rows.push(id); }
    const ch = changes || null;
    const newRows = ids.filter(id => (statusOf(id) || {}).new);
    const moved = ch ? ids.filter(id => ch.moved && ch.moved[id]).map(id => ({ id, from: ch.moved[id], to: (statusOf(id) || {}).status })) : [];
    const absent = ch ? ids.filter(id => (ch.absent || []).includes(id)) : [];
    const refs = [...new Set(ids.map(id => R.get(id).standardRef).filter(x => typeof x === 'string' && x.trim()))];
    const way = (ways || []).find(w => w.page === route) || null, view = (views && views[route]) || null;
    const page = pagesByRoute()?.get(route) || {};
    return { ids, withReason, toRun, scripts: [...scripts.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1)), newRows, moved, absent, refs, way, view, needs: page.needs || [], previous: ch ? ch.previous : null };
  }, [rows, checks, runs, changes, ways, views, research, route]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!data) return null;
  const { ids, withReason, toRun, scripts, newRows, moved, absent, refs, way, view, needs, previous } = data;
  const word = id => statusWord((statusOf(id) || {}).status, 'research');
  const movedGroups = [...moved.reduce((m, x) => (m.get(x.to) || m.set(x.to, []).get(x.to)).push(x) && m, new Map())].sort((a, b) => b[1].length - a[1].length);
  const noRun = scripts.filter(([, g]) => !g.ev.run).length;
  const lastDate = scripts.map(([, g]) => g.ev.run && g.ev.run.date).filter(Boolean).sort().pop() || '';
  return (
    <section className="ledger" id="sec-ledger" aria-labelledby="h-ledger" data-outline="The ledger">
      <h2 className="sec__title ledger__title" id="h-ledger">The ledger</h2>
      <h3 className="ledger__h3" id="ledger-why">What the reader finds, and why</h3>
      {withReason.length ? (
        <div className="table-scroll" tabIndex={0} role="region" aria-label="The rows with a reason">
          <table className="ledger__table"><thead><tr><th scope="col">row</th><th scope="col">status</th><th scope="col">the kind of reason</th></tr></thead>
            <tbody>{withReason.map(id => { const r = rowsById().get(id); return <tr key={id}><td><RowRef id={id} /></td><td>{word(id)}</td><td>{REASON_WORDS[r.reason.kind] || r.reason.kind}</td></tr>; })}</tbody></table>
        </div>
      ) : <p className="ledger__p">Every statement of this page is computed, a theorem, standard, or an input that is not a number: none needs a reason.</p>}
      <p className="ledger__p ledger__small">{ids.length} statements on this page; the words of each reason stand under its statement.</p>
      <h3 className="ledger__h3" id="ledger-todo">Still to compute</h3>
      {toRun.length ? (
        <>
          <p className="ledger__p ledger__small">Finite computations the Atlas could run on the labels and has not (reason kind not run):</p>
          <ul className="ledger__list" data-source="reasons">{toRun.map(id => <li key={id}><RowRef id={id} /> — {rowsById().get(id).reason.why}</li>)}</ul>
        </>
      ) : <p className="ledger__p">None: every finite computation this page names is run, or its reason is given above.</p>}
      <h3 className="ledger__h3" id="ledger-changes">Changes from {previous ? `release ${previous}` : 'the release before'}</h3>
      <ul className="ledger__list">
        <li>statements since this release: {newRows.length ? newRows.map((id, i) => <span key={id}>{i ? ', ' : ''}<RowRef id={id} /></span>) : 'none'}</li>
        {previous ? <li>statuses that moved: {moved.length ? movedGroups.map(([to, ms], i) => <span key={to}>{i ? '; ' : ''}{ms.length} to <b>{statusWord(to)}</b> (from {prevWord(ms[0].from)}): {ms.map((m, k) => <span key={m.id}>{k ? ', ' : ''}<RowRef id={m.id} /></span>)}</span>) : 'none'}</li> : <li>no status table of the release before to compare with</li>}
        {absent.length ? <li>rows this page tells that the release before did not have: {absent.map((id, i) => <span key={id}>{i ? ', ' : ''}<RowRef id={id} /></span>)}</li> : null}
        <li>reasons on this page: {withReason.length}</li>
      </ul>
      <h3 className="ledger__h3" id="ledger-checks">Checks</h3>
      {scripts.length ? (
        <details className="ledger__fold" data-source="checks">
          <summary className="ledger__sum">{scripts.length} scripts cited by the statements of this page{noRun ? `, ${noRun} without a recorded run` : ', every one with a recorded run that passed'}{lastDate ? `; the last run ${lastDate}` : ''} — the method and the controls of each</summary>
          <div className="table-scroll" tabIndex={0} role="region" aria-label="The scripts this page cites">
            <table className="ledger__table"><thead><tr><th scope="col">script</th><th scope="col">checks</th><th scope="col">method</th><th scope="col">controls</th><th scope="col">last run</th><th scope="col">rows</th></tr></thead>
              <tbody>{scripts.map(([key, g]) => { const c = g.ev.check; return (
                <tr key={key}><td><code>{baseName(key)}</code><br /><span className="ledger__mute">{String(key).replace(/\/[^/]*$/, '')}</span></td><td>{c ? (c.ids || []).length : '?'}</td><td>{c && c.method ? c.method : '—'}</td><td>{c && c.controls ? String(c.controls).replace(/\s*\(logs\/[^)]*\)/, '') : '—'}</td><td>{g.ev.run ? runWordOf(g.ev.run) : 'no run'}</td><td>{g.rows.map((id, i) => <span key={id}>{i ? ', ' : ''}<RowRef id={id} /></span>)}</td></tr>); })}</tbody></table>
          </div>
        </details>
      ) : <p className="ledger__p">No check is cited on this page.</p>}
      <h3 className="ledger__h3" id="ledger-sources">Sources</h3>
      {refs.length || way || view || needs.length ? (
        <details className="ledger__fold" data-source="sources" open={refs.length <= 6 || undefined}>
          <summary className="ledger__sum">{refs.length} references cited by the statements of this page{way ? ', the way\'s source' : ''}{view && view.source ? ', the source of the view' : ''}{needs.length ? `, the ${needs.length === 1 ? 'page' : 'pages'} this one builds on` : ''}</summary>
          <ul className="ledger__list">
            {view && view.source ? <li>{md(view.source)}</li> : null}
            {way && way.source ? <li><SourceLine src={way.source} /></li> : null}
            {refs.map(x => <li key={x}>{x}</li>)}
            {needs.length ? <li>The pages this one builds on: {needs.map((n, i) => <span key={n}>{i ? ', ' : ''}<Link to={n}>{pageLabel(n, s)}</Link></span>)}</li> : null}
          </ul>
        </details>
      ) : <p className="ledger__p">No standard reference is cited on this page.</p>}
    </section>
  );
}
