// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Shell.jsx — the sticky shell: the name (the mark, "Atlas" with its subtitle "one rule" beside it in the display face, hidden on a
// phone; a link to the door, #/), the contents, the search, the three switches (mode, level, lens), the page outline and the theme menu. Every switch
// writes the address; nothing else holds the view.
import { useMemo, useState } from 'react';
import { useSettings, useTable } from '../app/content.js';
import { peekTable } from '../app/store.js';
import { atlasPage, matchRoute } from '../app/router.js';
import DOOR_WORDS from '../../content/story/door.json';
import { pageLabel, rowsOfMatch } from '../app/queries.js';
import Segmented from './Segmented.jsx';
import LensPicker from './LensPicker.jsx';
import Popover from './Popover.jsx';
import Link from './Link.jsx';
import SearchPalette from './SearchPalette.jsx';
import { BrandMark, ListIcon, MenuIcon, ThemeIcon } from './Icons.jsx';

// The contents (interface 30; round 7: R7-2): "Start here" (the door, #/, which holds the start page of the full Atlas: the page record `atlas` is
// drawn at its bottom and is not listed on its own) first, then the pages in the order of pages.json (the chapters); a sub-page (interface 29: an entry
// with a parent) is reached from its parent's tabs and is not listed; the pages the router knows beyond pages.json (the guide for agents, the tutorials
// and the notes to researchers, content/story/door.json `agents`, `tutorials` and `notes`) follow them once their routes exist.
export const START = { route: '', door: true };
/** the entries the Contents menu lists, in its order: { route, door? } for the door, then pages.json entries, then known routes beyond them */
export function contentsPages() {
  const all = peekTable('pages') || [];
  const atlas = atlasPage();
  const pages = all.filter(p => p && !p.parent && p.route !== '' && p.route !== atlas);
  const extra = ['agents', 'tutorials', 'notes'].map(k => DOOR_WORDS[k]).filter(w => w && w.route && !pages.some(p => p.route === w.route) && routeKnown(w.route))
    .map(w => ({ route: w.route, label: w.title }));
  return [START, ...pages, ...extra];
}
// The grammar of 4.0.0 (D91) in the menu: the pages grouped — Start here; the rule and its cells; the calibration (light: Maxwell); the spine (its
// thirteen steps in order, each numbered along the spine); the applications; the ways (the two steps that are ways, Furey's and Atiyah's pages, and
// the pages of the ways); the measured numbers; the lenses (the two lens steps and the lenses page); the Logbook and the tools. A page of pages.json
// that none of the groups claims is listed after them, so nothing is lost when a page is added.
const GROUPS = [
  { key: 'rule', label: 'The rule', routes: ['rule', 'cells', 'clocks', 'shapes'] },
  { key: 'calibration', label: 'Calibration', routes: ['light'] },
  { key: 'spine', label: 'The spine', head: 'spine', part: 'spine' },
  { key: 'applications', label: 'Applications', part: 'application' },
  { key: 'ways', label: 'Ways', part: 'way', routes: ['matter', 'shifted'], prefix: 'ways/' },
  { key: 'measured', label: 'Measured numbers', routes: ['calib4'] },
  { key: 'lenses', label: 'Lenses', part: 'lens', routes: ['lenses'] },
  { key: 'tools', label: 'The Logbook and the tools', routes: ['logbook', 'ask', 'glossary', 'agents', 'tutorials', 'notes'] },
];
/** the menu's groups: [{ key, label, head?: route, entries: [{ route, label? }] }], from pages.json, steps.json (part) and ways.json */
export function contentsGroups(s) {
  const pages = contentsPages().filter(p => !p.door);
  const steps = (peekTable('steps') || []).filter(st => st.group !== 'shapes');
  const ways = peekTable('ways') || [];
  const byRoute = new Map(pages.map(p => [p.route, p]));
  const taken = new Set();
  const take = r => { const p = byRoute.get(r); if (!p || taken.has(r)) return null; taken.add(r); return p; };
  const wayLabel = r => { const w = ways.find(x => x.page === r); return w ? (s.level === 'learner' ? (w.title.learner || w.title.phys) : (w.title[s.mode] || w.title.phys)) : null; };
  const groups = [];
  for (const g of GROUPS) {
    const entries = [];
    const head = g.head ? take(g.head) : null;
    if (g.part) for (const st of steps.filter(x => (x.part || 'spine') === g.part)) { const p = take(st.route); if (p) entries.push(p); }
    for (const r of g.routes || []) { const p = take(r); if (p) entries.push({ ...p, label: g.key === 'ways' ? wayLabel(r) || p.label : p.label }); }
    if (g.prefix) for (const p of pages) if (p.route.startsWith(g.prefix)) { const q = take(p.route); if (q) entries.push({ ...q, label: wayLabel(q.route) || q.label }); }
    if (head || entries.length) groups.push({ key: g.key, label: g.label, head, entries });
  }
  const rest = pages.filter(p => !taken.has(p.route));
  if (rest.length) groups.push({ key: 'more', label: 'More', head: null, entries: rest });
  return groups;
}
const routeKnown = r => { const m = matchRoute(r); return !m.redirect && !['notfound', 'door'].includes(m.name); };
function Contents({ route }) {
  const s = useSettings();
  useTable('steps'); useTable('ways');   // the groups read them once they are in
  const groups = contentsGroups(s);
  const current = route.match && route.match.page != null ? route.match.page : null;
  const atDoor = route.match && route.match.name === 'door';
  const link = (p, close, cls = '') => (
    <Link to={p.route} onClick={close} aria-current={(p.door ? atDoor : !atDoor && current === p.route) ? 'page' : undefined} className={`contents__link${cls}`}>
      {p.door ? 'Start here' : p.label || pageLabel(p.route, s)}
    </Link>
  );
  return (
    <Popover label="Contents" className="pop--contents" panelClass="contents-panel" icon={<MenuIcon />} text="Contents">
      {close => (
        <div className="contents">
          {link(START, close, ' contents__link--door')}
          {groups.map(g => (
            <section className="contents__group" key={g.key} data-group={g.key}>
              {g.head ? link({ ...g.head, label: g.label }, close, ' contents__head') : <h3 className="contents__title">{g.label}</h3>}
              <ol className="contents__list">
                {g.entries.map(p => <li key={p.route}>{link(p, close)}</li>)}
              </ol>
            </section>
          ))}
        </div>
      )}
    </Popover>
  );
}

function Outline() {
  const s = useSettings();
  const [items, setItems] = useState([]);
  const read = () => {
    const els = [...document.querySelectorAll('#main [data-outline]')];
    setItems(els.map(el => ({ id: el.id, label: el.getAttribute('data-outline') })).filter(x => x.id && x.label));
  };
  const max = s.level === 'learner' ? 8 : 60;
  const go = (id, close) => {
    const el = document.getElementById(id);
    if (el) {
      if (el.tagName === 'DETAILS') el.open = true;
      el.scrollIntoView({ block: 'start', behavior: 'smooth' });
      const h = el.querySelector('h2, summary');
      if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
    }
    close();
  };
  return (
    <Popover label="On this page" className="pop--outline" panelClass="outline-panel" icon={<ListIcon />} text="On this page" onOpen={read}>
      {close => items.length ? (
        <ul className="outline">
          {items.slice(0, max).map(it => <li key={it.id}><button type="button" className="outline__item" onClick={() => go(it.id, close)}>{it.label}</button></li>)}
        </ul>
      ) : <p className="outline__empty">This page has no sections.</p>}
    </Popover>
  );
}

function ThemeMenu() {
  const s = useSettings();
  const opts = [['auto', 'Same as the system'], ['light', 'Light'], ['dark', 'Dark']];
  return (
    <Popover label="Theme" className="pop--theme" panelClass="theme-panel" icon={<ThemeIcon />} caret={false}>
      {close => (
        <div className="theme-list" role="radiogroup" aria-label="Theme">
          {opts.map(([v, label]) => (
            <label className="theme-opt" key={v}>
              <input type="radio" name="one-rule-theme" checked={s.theme === v} onChange={() => { s.set({ theme: v }); close(); }} />
              <span>{label}</span>
            </label>
          ))}
        </div>
      )}
    </Popover>
  );
}

export default function Shell({ route }) {
  const s = useSettings();
  const rowIds = useMemo(() => rowsOfMatch(route.match), [route.match]);
  const skip = e => { e.preventDefault(); const m = document.getElementById('main'); if (m) { m.focus(); m.scrollIntoView({ block: 'start' }); } };
  return (
    <header className="shell">
      <a className="skip" href="#main" onClick={skip}>Skip to content</a>
      <div className="shell__bar">
        <Link to="" className="brand" aria-label="Atlas, one rule: start page">
          <BrandMark />
          <span className="brand__name">Atlas</span>
          <span className="brand__sub">one rule</span>
        </Link>
        <div className="shell__nav"><Contents route={route} /><SearchPalette /></div>
        <div className="shell__switches">
          <Segmented label="Mode" value={s.mode} onChange={v => s.set({ mode: v })}
            options={[{ value: 'phys', label: 'Physics', short: 'Phys' }, { value: 'math', label: 'Mathematics', short: 'Math' }]} />
          <Segmented label="Level" value={s.level} onChange={v => s.set({ level: v })}
            options={[{ value: 'research', label: 'Research' }, { value: 'learner', label: 'Learner' }]} />
          <LensPicker rowIds={rowIds} />
        </div>
        <div className="shell__tools">
          <Outline />
          <ThemeMenu />
        </div>
      </div>
    </header>
  );
}
