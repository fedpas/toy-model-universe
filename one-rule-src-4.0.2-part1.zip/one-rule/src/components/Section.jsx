// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Section.jsx — a section of a page (docs/STORY_PLAN.md §2.2, the section of the page model of src/app/queries.js):
//   title      a name (the overlay's, A53; sectionLabel of the slug for a section without one; none for a section titled false) — h2, or h3 in a part
//   lead       the section's one `lead` story row (Lead)
//   figure     the section's figure (explicit, else placed by its caption row), then its `caption` rows under it and the try line (the section's
//              connective, which names the figure's controls); a wide seed takes the column width (D31); further figures after them
//   key        the first N results (a hairline between them, no cards); a tally row (EQN-006 … EQN-020) drawn by TallyLine (P11's hook)
//   More       "More statements (n)", closed: the other results, then the detail rows (MoreFold)
//   drawer     "Evidence and more", one per section: the statements of the section (story rows have no evidence of their own)
// In the markup the figure comes before the key results (the reading order on a phone); from 960 px a small figure stands in the right column.
// A section the page draws itself (`custom`: the cells' cards, a leaf's notes) and a section of a model built elsewhere (a cell's page) keep the
// frame they had: title, connective, body and figures side by side, the drawer.
// Round 7 (docs/round7/PLAN.md R7-3): the figures of a composed section are its blocks (the page model's sec.blocks): a leaf of the map first, with its
// try line under it; the section's own figures, the first with the section's caption rows and its try line; then a lens explorer (its try line) and a
// figure a page top moved here (with the captions that read it); an explorer marked detail sits under the chip "Another view" (a closed fold).
// A leaf and the explorers of one section are the views of one slot (the page model's b.view): a chip each, one view at a time, the first shown at
// first; every view is in the page (the others hidden), so that the server's page holds them all.
// Round 14 (docs/round14/STORY_ROUND.md §4.8): a composed section draws lead → figure blocks (captions, try line) → chains (Chain: each a story of
// the section's rows in chain order) → key results (the rows in no chain: its side notes) → "More statements"; with two chains or more their titles
// stand under the lead as links (ol.sec__chains: the path through the section). A section the page draws itself (the cells' lattice) draws its body,
// then its chains, then its drawer. The drawer lists the told positions with the other statements.
import { useState } from 'react';
import Statement from './Statement.jsx';
import FigureFrame from './FigureFrame.jsx';
import Drawer from './Drawer.jsx';
import Lead, { Caption } from './Lead.jsx';
import MoreFold from './MoreFold.jsx';
import Link from './Link.jsx';
import Chain from './Chain.jsx';
import TallyLine, { isTallyRow } from '../figures/physics/TallyLine.jsx';
import { rowsById } from '../app/store.js';
import { TOP_WORDS, CHAIN_LABELS } from '../app/vocab.js';
import { leafOf, useRoute } from '../app/router.js';

const row = id => (isTallyRow(id) ? <TallyLine key={id} id={id} /> : <Statement key={id} id={id} />);
/** the rows a section's drawer lists: its statements, story rows apart (they cite nothing) */
export const drawerRowsOf = ids => [...new Set(ids)].filter(id => (rowsById()?.get(id) || {}).kind !== 'story');
/** the chains of a section model (none for a model built elsewhere: a cell's page) */
const chainsOf = sec => (Array.isArray(sec.chains) ? sec.chains : []);

/** the path through a section with two chains or more: their titles, under its lead, each a link to its chain (at=<chain id>) */
function ChainPath({ chains }) {
  const route = useRoute();
  if (chains.length < 2) return null;
  return (
    <ol className="sec__chains" aria-label={CHAIN_LABELS.path}>
      {chains.map(c => <li key={c.id}><Link to={route.path} at={c.id} data-connective="chain-path">{c.title}</Link></li>)}
    </ol>
  );
}
/** the chains of a section, their titles one level under the section's */
const chainEls = (sec, H) => chainsOf(sec).map(c => <Chain key={c.id} chain={c} h={H === 'h3' ? 4 : 3} sid={sec.id} />);

function ClassicSection({ sec, H, drawers, drawer, onDrawer, custom }) {
  const hasFigs = sec.figures && sec.figures.length > 0;
  const label = sec.heading === undefined ? sec.label : sec.heading;
  const chains = chainEls(sec, H);
  return (
    <section className="sec" id={`sec-${sec.id}`} aria-labelledby={label ? `h-${sec.id}` : undefined} data-outline={label || undefined}>
      {label ? <H className="sec__title" id={`h-${sec.id}`}>{label}</H> : null}
      {sec.lead ? <Lead id={sec.lead} /> : null}
      <ChainPath chains={chainsOf(sec)} />
      {sec.connective ? <p className="sec__connective" data-connective="section">{sec.connective}</p> : null}
      <div className={`sec__grid${hasFigs ? ' sec__grid--fig' : ''}`}>
        <div className={`sec__body${custom ? ' sec__body--wide' : ''}`}>
          {custom ? custom(sec) : sec.body.map(row)}
        </div>
        {hasFigs ? <div className="sec__figs">{sec.figures.map(f => <FigureFrame key={f} id={f} />)}</div> : null}
      </div>
      {chains.length ? <div className="sec__body sec__story">{chains}</div> : null}
      {drawers ? (
        <Drawer
          sid={sec.id}
          rows={drawerRowsOf([...sec.body, ...(sec.told || [])])}
          details={sec.details}
          numbers={sec.numbers}
          tabs={sec.tabs}
          open={drawer && drawer.open}
          focus={drawer && drawer.focus}
          onToggle={o => onDrawer && onDrawer(sec.id, o)}
        />
      ) : null}
    </section>
  );
}

/** one figure of a section with what reads it: the frame, its caption rows, its try line (a leaf's, an explorer's), the section's connective */
export function FigureBlock({ b, connective = null }) {
  return (
    <>
      <FigureFrame id={b.id} />
      {b.captions && b.captions.length ? <div className="sec__caps" data-captions={b.id}>{b.captions.map(id => <Caption key={id} id={id} />)}</div> : null}
      {b.tryLine ? <p className="sec__connective sec__try" data-connective="try" data-figure={b.id}><span className="sec__try-label">{TOP_WORDS.try}</span> <span className="sec__try-text">{b.tryLine}</span></p> : null}
      {connective}
    </>
  );
}

/** the views of one slot: a chip each (the name of the leaf or the explorer in the door's map), one view at a time */
export function ViewSlot({ views }) {
  const [on, setOn] = useState(views[0].id);
  return (
    <div className="sec__views" data-views={views.map(b => b.id).join(' ')}>
      <div className="fig__lenses sec__views-chips" role="group" aria-label={TOP_WORDS.views}>
        {views.map(b => <button key={b.id} type="button" className="chip chip--lens" data-view={b.id} aria-pressed={b.id === on} onClick={() => setOn(b.id)}>{(leafOf(b.leaf) || {}).name || b.id}</button>)}
      </div>
      {views.map(b => <div key={b.id} className="sec__view" data-view={b.id} hidden={b.id !== on}><FigureBlock b={b} /></div>)}
    </div>
  );
}

export default function Section({ sec, level = 2, drawers = true, drawer, onDrawer, custom, moreOpen = false, onMore }) {
  const H = level === 3 ? 'h3' : 'h2';
  if (custom || !Array.isArray(sec.key)) return <ClassicSection sec={sec} H={H} drawers={drawers} drawer={drawer} onDrawer={onDrawer} custom={custom} />;
  const figs = sec.figures || [];
  const caps = figs.length ? sec.captions || [] : [];
  const more = figs.length ? sec.more || [] : [...(sec.more || []), ...(sec.captions || [])];
  const key = sec.key;
  // the chains come before the key results, in the body's column (beside a small figure from 960 px, as the key results stand)
  const chains = chainEls(sec, H);
  const body = key.length || chains.length ? <div className="sec__body">{chains}{key.map(row)}</div> : null;
  const tryLine = sec.connective ? <p className="sec__connective" data-connective="section">{sec.connective}</p> : null;
  // the blocks (a model of round 7), else the figures as the story round drew them: the first with the captions and the try line
  const blocks = Array.isArray(sec.blocks) && sec.blocks.length ? sec.blocks : figs.map((id, i) => ({ id, kind: 'own', captions: i === 0 ? caps : [], tryLine: null, detail: false }));
  const shown = blocks.filter(b => !b.detail), detail = blocks.filter(b => b.detail), views = shown.filter(b => b.view);
  const holder = shown.find(b => b.kind === 'own') || shown[0] || null;
  return (
    <section
      className="sec sec--composed" id={`sec-${sec.id}`} data-section={sec.id}
      aria-labelledby={sec.heading ? `h-${sec.id}` : undefined} aria-label={sec.heading ? undefined : sec.label}
      data-outline={sec.heading || undefined}
    >
      {sec.heading ? <H className="sec__title" id={`h-${sec.id}`}>{sec.heading}</H> : null}
      {sec.lead ? <Lead id={sec.lead} /> : null}
      <ChainPath chains={chainsOf(sec)} />
      {figs.length ? (
        <div className={`sec__grid sec__grid--fig${body ? '' : ' sec__grid--solo'}`}>
          <div className="sec__figs">
            {shown.map(b => (b.view ? (b === views[0] ? <ViewSlot key="views" views={views} /> : null) : <FigureBlock key={b.id} b={b} connective={b === holder ? tryLine : null} />))}
            {!holder || holder.view ? tryLine : null}
            {detail.length ? (
              <details className="sec__another" data-another={detail.map(b => b.id).join(' ')}>
                <summary className="chip sec__another-chip">{TOP_WORDS.anotherView}</summary>
                {detail.map(b => <FigureBlock key={b.id} b={b} />)}
              </details>
            ) : null}
          </div>
          {body}
        </div>
      ) : <>{tryLine}{body}</>}
      <MoreFold rows={more} id={`more-${sec.id}`} open={moreOpen} onToggle={onMore} />
      {drawers ? (
        <Drawer
          sid={sec.id}
          rows={drawerRowsOf([...caps, ...(sec.told || []), ...key, ...more])}
          numbers={sec.numbers}
          tabs={sec.tabs}
          open={drawer && drawer.open}
          focus={drawer && drawer.focus}
          onToggle={o => onDrawer && onDrawer(sec.id, o)}
        />
      ) : null}
    </section>
  );
}
