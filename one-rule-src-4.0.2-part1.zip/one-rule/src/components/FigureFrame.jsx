// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/FigureFrame.jsx — the frame of a figure of figures.json: the drawing (the component registered for the id when there is one, else a quiet
// placeholder naming the figure), its caption from the caption row's texts, and the lenses it can redraw in.
// data-size="wide" when the seed says size "wide" (D31: such a figure takes the full content width from 1100 px on, components.css).
// The figures chunk (D47, BUILD_CONTRACTS interface 34): an extra figure (src/figures/physics/, src/figures/explore/) drawn at this level whose chunk is
// not in yet asks src/app/lazyFigures.js for it and shows a labelled frame "loading the figure" in the drawing's place (data-figure-state="loading": the
// placeholder's box, as tall as a wide drawing for a wide figure, so that the caption and the page below barely move), then the figure
// (data-figure-state="ready"). If the chunk cannot load, a labelled frame "this figure could not load" (data-figure-state="failed"; lazyFigures.js warns
// once, never an error). A figure this build does not draw at all keeps the quiet placeholder (data-figure-state="none"); a figure not drawn at the level
// never asks for the chunk. On the server the registry holds every figure, so no frame waits there.
import { useEffect } from 'react';
import { useSettings, textFor } from '../app/content.js';
import { figuresById, lensesByKey } from '../app/store.js';
import { lensRole } from '../app/vocab.js';
import { captionRowOf } from '../app/queries.js';
import { figureComponent, figuresEnabled } from '../app/optional.js';
import { isExtraFigure, useExtraFigures, extraFigureMissing } from '../app/lazyFigures.js';
import { useResolvedTheme } from '../app/theme.js';
import ErrorBoundary from './ErrorBoundary.jsx';

function Placeholder({ id, failed }) {
  return (
    <div className="fig__placeholder" role="img" aria-label={`Figure ${id}${failed ? ' could not be drawn' : ', not drawn in this build'}`}>
      <span className="fig__ph-kind">Figure</span>
      <code className="fig__ph-id">{id}</code>
      {failed ? <span className="fig__ph-note">could not be drawn</span> : null}
    </div>
  );
}

/** an extra figure while the chunk loads, or after it failed: the placeholder's 4:3 box; for a wide figure the full width at the height components.css
 *  gives a wide drawing in a section (min(56vh, 460px)), near what such a figure takes, so that the page barely moves when it comes in */
function Pending({ id, failed, wide }) {
  const style = wide ? { aspectRatio: 'auto', height: 'min(56vh, 460px)' } : undefined;
  if (failed) {
    return (
      <div className="fig__placeholder" role="img" aria-label={`Figure ${id}: this figure could not load`} style={style}>
        <span className="fig__ph-kind">Figure</span>
        <code className="fig__ph-id">{id}</code>
        <span className="fig__ph-note">this figure could not load</span>
      </div>
    );
  }
  return (
    <div className="fig__placeholder" role="status" style={style}>
      <span className="fig__ph-note">loading the figure</span>
    </div>
  );
}

export default function FigureFrame({ id }) {
  const s = useSettings();
  const theme = useResolvedTheme(s.theme);
  const fig = figuresById()?.get(id);
  const learner = s.level === 'learner';
  const shown = !!fig && !(learner && !fig.learner);   // a figure not drawn at this level never asks for the chunk
  const Comp = shown ? figureComponent(id) : null;
  // an extra figure whose chunk is not in yet: never on the server, where the registry holds every figure
  const lazy = shown && !Comp && figuresEnabled() && isExtraFigure(id);
  const chunk = useExtraFigures(lazy);
  const missing = lazy && chunk === 'ready';   // the chunk is in but has no such figure (app.js and the chunk of different builds)
  useEffect(() => { if (missing) extraFigureMissing(id); }, [missing, id]);
  if (!shown) return null;
  const wide = fig.size === 'wide';
  const state = Comp ? 'ready' : lazy ? (chunk === 'failed' || missing ? 'failed' : 'loading') : 'none';
  const capRow = captionRowOf(fig, s.mode);   // A41: the mathematics twin captions the figure in mathematics mode where the seed names one
  const caption = capRow ? textFor(capRow, { mode: s.mode, level: s.level, lens: s.lens, register: 'caption' }) : null;
  const lenses = (fig.lenses || []).map(k => lensesByKey()?.get(k)).filter(Boolean).filter(l => !learner || l.kind === 'shape');
  // the lens a figure draws in (4.0.0, D92: three switches): the view when the figure has it, else the convention when it has it, else the dialect
  const lensKeys = fig.lenses || [];
  const drawLens = s.view && lensKeys.includes(s.view) ? s.view : s.conv && lensKeys.includes(s.conv) ? s.conv : s.lens;
  const switchOf = k => ({ view: 'view', toggle: 'conv', dialect: 'lens' })[lensRole(k)];
  const isOn = k => s[switchOf(k)] === k;
  return (
    <figure className="fig" data-figure={id} data-size={wide ? 'wide' : undefined} data-figure-state={state}>
      <div className="fig__draw">
        {Comp ? (
          <ErrorBoundary name={`figure ${id}`} resetKey={`${drawLens}|${s.level}|${theme}|${s.mode}`} fallback={<Placeholder id={id} failed />}>
            <Comp params={fig.params || {}} lens={drawLens} level={s.level} theme={theme} row={capRow} mode={s.mode} />
          </ErrorBoundary>
        ) : lazy ? <Pending id={id} failed={state === 'failed'} wide={wide} /> : <Placeholder id={id} />}
      </div>
      {caption ? <figcaption className="fig__caption">{caption}</figcaption> : null}
      {lenses.length ? (
        <div className="fig__lenses" role="group" aria-label="Redraw in a lens">
          {lenses.map(l => (
            <button key={l.key} type="button" className="chip chip--lens" aria-pressed={isOn(l.key)} onClick={() => s.set({ [switchOf(l.key)]: isOn(l.key) ? null : l.key })}>
              {l.name}
            </button>
          ))}
        </div>
      ) : null}
    </figure>
  );
}
