// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LensPicker.jsx — the lens switch (4.0.0, D92: three switches in one popover). The dialects (the branches, the languages, the
// researchers: the lenses that translate) are one radio list, "none" first, each with the number of rows on this page that have a text in that
// lens (a dialect with none is listed, greyed, "no readings yet"); the views (the shapes and the labels: the lenses that render a label) a second
// list, the conventions (the toggles) a third; the three are independent settings (`lens`, `view`, `conv`), so a page can be read in a dialect,
// drawn in a view and under a convention at once.
import { useMemo } from 'react';
import { useSettings } from '../app/content.js';
import { peekTable, lensesByKey } from '../app/store.js';
import { lensCounts } from '../app/queries.js';
import { LENS_KIND_ORDER, LENS_KIND_NAMES, LENS_ROLE_NAMES, lensRole } from '../app/vocab.js';
import Popover from './Popover.jsx';
import Link from './Link.jsx';
import { LensIcon } from './Icons.jsx';

/** the setting a role is kept in */
const SWITCH = { dialect: 'lens', view: 'view', toggle: 'conv' };
const NONE = { dialect: ['None', 'the Atlas’s own words'], view: ['None', 'the page’s own drawings'], toggle: ['None', 'the Atlas’s conventions'] };

export default function LensPicker({ rowIds }) {
  const s = useSettings();
  const lenses = peekTable('lenses') || [];
  const counts = useMemo(() => lensCounts(rowIds || [], s.level), [rowIds, s.level]);
  const byKey = lensesByKey();
  const current = s.lens ? byKey?.get(s.lens) : null;
  const chosen = ['lens', 'view', 'conv'].map(k => s[k]).filter(Boolean).map(k => (byKey?.get(k) || {}).name || k);
  const kinds = [...LENS_KIND_ORDER, ...[...new Set(lenses.map(l => l.kind))].filter(k => !LENS_KIND_ORDER.includes(k))];
  const choose = (role, key, close) => { s.set({ [SWITCH[role]]: key }); close(); };
  const active = chosen.length > 0;
  return (
    <Popover label={active ? `Lens: ${chosen.join(' · ')}` : 'Lens'} className={`pop--lens${active ? ' is-active' : ''}`} panelClass="lens-panel" icon={<LensIcon />} text={active ? (chosen.length > 1 ? `${chosen[0]} +${chosen.length - 1}` : chosen[0]) : 'Lens'}>
      {close => (
        <div className="lens-list">
          {['dialect', 'view', 'toggle'].map(role => {
            const mine = lenses.filter(l => lensRole(l.key) === role);
            if (!mine.length) return null;
            const sw = SWITCH[role], name = `one-rule-${sw}`;
            return (
              <div className="lens-role" key={role} data-role={role}>
                <h3 className="lens-role__title">{LENS_ROLE_NAMES[role]}</h3>
                <label className="lens-opt lens-opt--none">
                  <input type="radio" name={name} checked={!s[sw]} onChange={() => choose(role, null, close)} />
                  <span className="lens-opt__name">{NONE[role][0]}</span>
                  <span className="lens-opt__count">{NONE[role][1]}</span>
                </label>
                {kinds.map(kind => {
                  const items = mine.filter(l => l.kind === kind);
                  if (!items.length) return null;
                  return (
                    <fieldset className="lens-group" key={kind}>
                      <legend className="lens-group__title">{LENS_KIND_NAMES[kind] || kind}</legend>
                      {items.map(l => {
                        const n = role === 'dialect' ? counts.get(l.key) || 0 : null;
                        return (
                          <label className={`lens-opt${n === 0 ? ' is-empty' : ''}`} key={l.key}>
                            <input type="radio" name={name} checked={s[sw] === l.key} onChange={() => choose(role, l.key, close)} />
                            <span className="lens-opt__name">{l.name}</span>
                            {n != null ? <span className="lens-opt__count">{n ? `${n} on this page` : 'no readings yet'}</span> : null}
                          </label>
                        );
                      })}
                    </fieldset>
                  );
                })}
              </div>
            );
          })}
          <p className="lens-list__foot">
            {current ? <Link to={`lenses/${current.key}`} onClick={close}>About the {current.name} lens</Link> : <Link to="lenses" onClick={close}>All lenses</Link>}
          </p>
        </div>
      )}
    </Popover>
  );
}
