// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Statement.jsx — one row, in the words of its text record for the current (mode, level, lens).
// At most one Badge (from the computed status); a "›" that opens the row's line in its section drawer; glossary terms underlined.
// When a lens is active, the row's readings in that lens follow the text on one line (LensReading); with no lens, nothing is added.
// It renders nothing when the row has no text at this level, and it refuses free text: passing children throws.
// Round 14 (docs/round14/STORY_ROUND.md §4.5): `chain` (a chain's id) goes to textFor and is written as data-chain — at learner level the row's span in
// that chain, else its learner text (D54) — and two variants serve the chains (src/components/Chain.jsx, ChainStory.jsx):
//   span     inline markup, one sentence of a story paragraph (span.statement.statement--span, its words in span.statement__text, an inline
//            statement__meta): its badge inline exactly where the status has one (D56); where the row has a drawer line, a click on the sentence or
//            Enter on its "›" (a button: the keyboard's and the screen reader's way in, its focus visible) opens the row's drawer; a lens reading (D7)
//            inside the span after its words. With `mention`, a recall: the sentence is a link to where the page tells the row (at=<id>; plain
//            words, `unlinked`, where the page does not draw that told position at this level), with no
//            glossary term, no reading and no "›" inside it
//   mention  the compact statement of a row told in another chain of the page, folded to two lines ("Show all"), with the link "Told in <section>" to
//            at=<id>; no anchor, no reading (D7: on the told position only)
// `told` marks a told position (data-told: a deep link at=<id> scrolls to it, and only it is marked as the target); `anchor` gives the anchor row-<id>
// (false where the page top holds it); `drawer` is the section whose drawer lists the row, the one the "›" opens.
// 4.0.0: at research level a body or hero statement is the row block of the Shifted View mockup (docs/round20/staging/shifted_view; the format of
// every page): a head with the id, the status word (the Badge where the status has one, else the word) and "new in this release"; the claim line
// (the row's physics and mathematics names); the text; its numbered displays from the formulas catalogue; then Checks (the scripts with their last
// run), Scope (the cells), Why (the reason, D85) and Depends, inline — what the drawers held, printed under the statement (src/app/queries.js rowView).
// The words of the reason and of the claim are the row's own fields, inside the statement; the text record stays byte for byte in statement__text.
import { useContext, useState } from 'react';
import { useSettings, useTable, textFor, statusOf } from '../app/content.js';
import { useRoute } from '../app/router.js';
import { rowHome, pageLabel, rowView } from '../app/queries.js';
import { CHAIN_LABELS, STORY_NEW_BADGE, badgeKind, statusWord } from '../app/vocab.js';
import { useKatex, texToHtml } from '../app/math.js';
import { PageContext } from './PageContext.js';
import RichText from './RichText.jsx';
import Badge from './Badge.jsx';
import Link from './Link.jsx';
import LensReading from './LensReading.jsx';
import { Chevron } from './Icons.jsx';

/** a numbered display of the formulas catalogue, typeset by KaTeX in display mode with its tag */
function Display({ tex, tag }) {
  const katex = useKatex(true);
  const src = tag ? `${tex} \\tag{${tag}}` : tex;
  const html = katex ? texToHtml(src, true) : null;
  return html
    ? <div className="statement__eq math" data-tex={src} data-display="" dangerouslySetInnerHTML={{ __html: html }} />
    : <div className="statement__eq tex">{`$$${src}$$`}</div>;
}
/** a link to a row, a theorem or a question named in Depends */
function RowLink({ id }) { const h = rowHome(id); return <Link to={h.path} at={h.at} className="statement__ref">{id}</Link>; }
/** the lines under the text: Checks · Scope · Address · Lattice · Why · Depends · Lenses (the row block's foot; a tally row's too, TallyLine.jsx) */
export function RowFoot({ view }) {
  const lines = [];
  if (view.checks.length) lines.push(
    <p className="statement__line statement__checks" key="checks"><span className="statement__lab">Checks</span>
      {view.checks.map((c, i) => <span className="statement__check" key={c.script || i}>{i ? '; ' : ''}<code>{c.base}</code>{c.ids.length ? ` (${c.ids.join(', ')})` : ''}{c.read ? ' (read)' : ''} — <span className={`statement__run statement__run--${c.run ? (c.run.passed === false || Number(c.run.fail) > 0 ? 'fail' : 'pass') : 'none'}`}>{c.word}</span></span>)}
    </p>);
  if (view.cells.length) lines.push(<p className="statement__line" key="scope"><span className="statement__lab">Scope</span>cells {view.cells.join(', ')}</p>);
  if (view.coords) lines.push(<p className="statement__line statement__address" key="address"><span className="statement__lab">Address</span><code className="addr addr--coords" title="cell (p,q,r) · clock c · n · stage/kind · way">{view.coords}</code>{view.cellFrom === 'default' ? <span className="statement__note"> (the family, no cell named yet)</span> : view.cellFrom === 'family' ? <span className="statement__note"> (a family of cells)</span> : null}{view.address ? <> · <span className="statement__sublab">Notions</span> <code className="addr">{view.address}</code></> : null}</p>);
  if (view.lattice && (view.lattice.sameCell.length || view.lattice.nextCell.length)) lines.push(<p className="statement__line statement__lattice" key="lattice"><span className="statement__lab">Lattice</span>{view.lattice.sameCell.length ? <span data-lattice="same-cell">same cell, other stage: {view.lattice.sameCell.map((n, i) => <span key={n}>{i ? ', ' : ''}<RowLink id={n} /></span>)}</span> : null}{view.lattice.sameCell.length && view.lattice.nextCell.length ? ' · ' : ''}{view.lattice.nextCell.length ? <span data-lattice="next-cell">same stage, next cell: {view.lattice.nextCell.map((n, i) => <span key={n}>{i ? ', ' : ''}<RowLink id={n} /></span>)}</span> : null}</p>);
  if (view.reason) lines.push(<p className="statement__line statement__why" key="why"><span className="statement__lab">Why ({view.reason.word})</span>{view.reason.why}</p>);
  if (view.depends.length) lines.push(<p className="statement__line" key="depends"><span className="statement__lab">Depends</span>{view.depends.map((d, i) => <span key={`${d.id}-${d.rel}`}>{i ? ', ' : ''}<RowLink id={d.id} /> ({d.rel})</span>)}</p>);
  // the lenses that read the row, by name with their counts (the readings themselves stand under the lens the reader picks: LensReading)
  if (view.lenses && view.lenses.length) { const byLens = new Map(); for (const x of view.lenses) byLens.set(x.lens, (byLens.get(x.lens) || 0) + 1); lines.push(<p className="statement__line statement__lenses" key="lenses"><span className="statement__lab">Lenses</span>{[...byLens].map(([k, n], i) => <span key={k}>{i ? ', ' : ''}<i>{k}</i>{n > 1 ? ` (${n})` : ''}</span>)}</p>); }
  return lines.length ? <div className="statement__foot">{lines}</div> : null;
}

// characters above which a statement is shown folded to a few lines with "Show all" (the full text stays in the page); a bubble of the door's strip
// folds sooner, so that a long row keeps the strip's panels short; a mention folds to two lines
const LONG = { body: 700, compact: 700, hero: 520, bubble: 520, mention: 160 };

export default function Statement(props) {
  if (props.children != null) throw new Error('Statement renders the text record of its row and takes no children');
  const { id, register = 'full', variant = 'body', badge = true, evidence = true, where = false, chain = null, anchor = null, told = false, mention = false, toldIn = null, drawer = null, unlinked = false, label = null, twinOf = null } = props;
  const s = useSettings();
  const ctx = useContext(PageContext);
  const route = useRoute();
  const [expanded, setExpanded] = useState(false);
  const text = textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register, chain });
  if (text == null) return null;

  const st = statusOf(id);
  const recall = variant === 'mention' || !!mention;
  // the row block of the mockup: body and hero statements at research level (the tables of the checks, the runs and the formulas are asked for, so that
  // the lines fill in as they load)
  const asView = s.level !== 'learner' && !recall && variant !== 'span' && variant !== 'bubble' && variant !== 'compact' && variant !== 'mention';
  const isLead = variant === 'lead', isView = variant === 'view';
  useTable(asView ? 'checks' : null); useTable(asView ? 'check_runs' : null); useTable(asView ? 'formulas' : null);
  const view = asView ? rowView(id, route.path) : null;
  const terms = ctx.gloss && !recall ? ctx.gloss.get(id) : null;
  const foldable = !isView && !isLead && LONG[variant] != null && text.length > LONG[variant];
  const canOpen = evidence && !recall && !isView && !isLead && ctx.openEvidence && ctx.hasDrawer(id);
  const openIt = () => ctx.openEvidence(id, drawer || undefined);
  const home = where ? rowHome(id) : null;
  // A60: "new" inside a story is the switch of src/app/vocab.js (on by default: D56, badges unchanged)
  const showBadge = !!(badge && st && st.badge) && !(variant === 'span' && !STORY_NEW_BADGE && badgeKind(st.status, st.badge) === 'new');
  const uid = `${variant}-${chain ? `${chain}-` : ''}${id}`;
  const textId = `txt-${uid}`;
  const anchored = anchor == null ? variant === 'body' || variant === 'hero' || isView || isLead : !!anchor;
  const cls = ['statement', `statement--${variant}`];
  if (view && !isLead) cls.push('statement--view');
  if (isLead) cls.push('view-lead');
  if (variant === 'span' && recall) cls.push('statement--recall');
  if (foldable && !expanded) cls.push('statement--folded');
  // a row a chain of the page tells is the target only where it is told (the page top shows the hero row too)
  if (route.at === id && !recall && (told || !(ctx.isTold && ctx.isTold(id)))) cls.push('is-target');
  const marks = { 'data-row': id, 'data-register': register, 'data-chain': chain || undefined, 'data-told': told ? id : undefined, 'data-mention': recall ? '' : undefined, 'data-status': view && st ? st.status : undefined };
  const words = <RichText text={text} level={s.level} terms={terms} uid={uid} />;
  const evButton = canOpen ? (
    <button type="button" className="statement__ev" aria-label={`Evidence and more for this statement (${id})`} title="Evidence and more"
      aria-controls={drawer ? `drawer-${drawer}` : undefined} onClick={openIt}>
      <Chevron />
    </button>
  ) : null;

  if (variant === 'span') {
    const badgeEl = showBadge ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null;
    // a click on the sentence opens the drawer as its "›" does, unless it lands on a link, a button or a glossary term inside it
    const onClick = canOpen ? e => { const t = e.target; if (!(t && t.closest && t.closest('a, button, .gloss'))) openIt(); } : undefined;
    return (
      <span className={cls.join(' ')} {...marks} id={anchored ? `row-${id}` : undefined} onClick={onClick}>
        {recall && !unlinked
          ? <Link to={route.path} at={id} className="statement__text statement__recall" id={textId}>{words}</Link>
          : <span className={recall ? 'statement__text statement__recall' : 'statement__text'} id={textId}>{words}</span>}
        {recall ? null : <LensReading id={id} />}
        {badgeEl || evButton ? <span className="statement__meta">{badgeEl}{evButton}</span> : null}
      </span>
    );
  }

  const badgeEl = badge && st ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null;
  if (isLead) {
    return (
      <div className={cls.join(' ')} {...marks} id={anchored ? `row-${id}` : undefined} data-role="lead">
        <div className="leadlab">{label || 'The page opens'}<span className="leadlab__sep"> · </span><span className="rid">{id}</span>{showBadge ? <span className="leadlab__badge"> {badgeEl}</span> : null}</div>
        <p className="statement__text" id={textId}>{words}</p>
        {view ? view.displays.map(d => <Display key={d.no} tex={d.tex} tag={d.tag} />) : null}
        <LensReading id={id} />
      </div>
    );
  }
  // the row block: its id links to the row's home when the row is told here away from it (the researcher view's rowhead)
  const homeOf = isView ? rowHome(id) : null;
  return (
    <div className={cls.join(' ')} {...marks} id={anchored ? `row-${id}` : undefined}>
      {view ? (
        <div className="statement__head">
          {homeOf && homeOf.path !== route.path ? <Link to={homeOf.path} at={id} className="statement__id" title={`its home: ${pageLabel(homeOf.path, s)}`}>{id}</Link> : <span className="statement__id">{id}</span>}
          {st && st.badge ? badgeEl : st ? <span className="statement__status" data-status={st.status}>{statusWord(st.status)}</span> : null}
          {view.isNew && !(st && st.badge === 'new') ? <span className="statement__new">new in this release</span> : null}
          {twinOf ? <span className="statement__twin">the mathematics twin of {twinOf}</span> : null}
        </div>
      ) : null}
      {view && view.claim.length ? <p className="statement__claim">{view.claim.map((c, i) => <span key={i}>{i ? <span className="statement__dot"> · </span> : null}<b>{c}</b></span>)}</p> : null}
      <p className="statement__text" id={textId}>{words}</p>
      {view ? view.displays.map(d => <Display key={d.no} tex={d.tex} tag={d.tag} />) : null}
      {recall ? null : <LensReading id={id} />}
      {view ? <RowFoot view={view} /> : null}
      {!isView && ((badge && !view) || canOpen || foldable || home || (recall && toldIn)) && (
        <div className="statement__meta">
          {!view && st ? badgeEl : null}
          {home && home.path !== route.path ? <Link to={home.path} at={id} className="statement__where">{pageLabel(home.path, s)}</Link> : null}
          {recall && toldIn ? <Link to={route.path} at={id} className="statement__told" data-connective="told-in">{`${CHAIN_LABELS.told} ${toldIn.label}`}</Link> : null}
          {foldable ? (
            <button type="button" className="statement__more" aria-expanded={expanded} aria-controls={textId} onClick={() => setExpanded(x => !x)}>
              {expanded ? 'Show less' : 'Show all'}
            </button>
          ) : null}
          {evButton}
        </div>
      )}
    </div>
  );
}
