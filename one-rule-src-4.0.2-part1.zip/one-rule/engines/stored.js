// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/stored.js — the stored results of the author's check scripts that the figures draw as they are (07 §3: "a figure must be faithful to the v15 original or to
// stored data"). Each is a block of the JSON a script wrote under checks/selfcheck/ (its "storedResult" in content/checks.json): nothing here is computed or edited,
// and a changed check is a new run and a new build (07 §5). v15 bundled the whole files as its *Data.js modules (gossetData.js, projectiveData.js, fureyPapersData.js,
// pgadynData.js, nullData.js, schullerWidgetData.js …); V2 bundles only the blocks the figures read (engines/storedPaths.js PARTS, copied into engines/storedParts.js
// by tools/migrate/figures_from_v15.mjs and compared with the files by tests/engines.test.mjs), which keeps app.js within its budget (08 §5).
import P from './storedParts.js';

export const GOSSET = P.GOSSET, PROJECTIVE = P.PROJECTIVE, FUREY_PAPERS = P.FUREY_PAPERS, PGADYN = P.PGADYN, NULL = P.NULL, GRAVITY = P.GRAVITY;
export const LENS_SCH = P.LENS_SCH, LENS_BAEZ = P.LENS_BAEZ, DICTIONARY = P.DICTIONARY, MAXWELL = P.MAXWELL, CORE = P.CORE;
export { SOURCES, PARTS } from './storedPaths.js';
