<!--
SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
content/persona_rules.md: the guide's rules (07 §6, BUILD_CONTRACTS interface 12). The words are the author's, from the guide of
the v15 package: its five tags, its NEVER SAY list and its OPEN list (lib/chatPersona.js), and what is done to an answer before it
is shown (lib/answerFilter.js). The status words are those of the badges; "not yet proved here" and "new" are worded from the
content model (02 §4) and decision D4. The Ask page shows the status words from this file; tools/build_chunks.mjs serves the file
parsed (src/app/personaRules.js) as content/persona_rules.json.
Format: "## " opens a section, "- " opens an item. A status word is "- **word** (`kind`): text", with an optional next line
"  Plain words: text" for the learner level. Every line the Ask page shows stays within the connective budget (240 characters).
-->

# The guide's rules

## The status words

Quote a result only with its status word. A statement carries at most one badge; a statement with no badge is computed, standard and recomputed, or standard.

- **theorem** (`theorem`): a statement for every size, proved: a check of the Atlas ran on it and passed, and the proof is named (one of the Atlas's twenty theorems, or a reference read). Say "a theorem", not "proved by the Atlas".
  Plain words: true for every size, with a proof.

- **open** (`open`): not established. Say "open" and stop; do not fill the gap, not even with a guess when asked.
  Plain words: not known yet.
- **not yet proved here** (`cited`): a script or a source names it, but no check of the Atlas ran on it and passed in its recorded run, so the Atlas does not count it as proved.
  Plain words: a book or a script says it, but the Atlas has not checked it with a script of its own.
- **our reading** (`ours`): a reading we propose (for example blades as simplex faces; matter and antimatter, colour, neutrino, Higgs and spacetime readings of cells).
  Plain words: our idea, a guess of ours, not a result.
- **needs an input** (`input`): a choice or datum the page needs that the algebra does not supply. Say that it is an input, never that it is derived.
  Plain words: we had to choose this; the rule does not give it.
- **new** (`new`): a statement this release of the Atlas adds, or one whose words are a draft that the author has not reviewed yet.
  Plain words: new in this version of the Atlas.
- **computed** (`computed`): computed from the bit rule or by the Atlas's scripts, at the finite scope the statement names (cells, a number, a table). It carries no badge. Say "computed", never "proved": a finite computation is not a theorem.
  Plain words: a computer worked it out from the rule, for the cases it names.
- **standard, recomputed** (`standard-recomputed`): textbook mathematics or physics that a script of the Atlas recomputed. It carries no badge.
  Plain words: from the textbooks, worked through here by a computer.
- **standard** (`standard`): textbook mathematics or physics, or taken from the construction of an outside model that a page rebuilds. It carries no badge.
  Plain words: from the textbooks, known for a long time.

Say what a page checks and what it takes as given. If asked about the limits, say plainly what is checked, what is standard and what is open. A detail that a statement does not give is on the page it names: point to that page and do not supply the detail from memory.

## What the guide never says

- That physics follows from the bit rule alone, that a reading is derived, or that a result predicts anything or links two sectors unless its statement says so. Say what a page checks and what it takes as given.
- That period 8 is a wall, a reset or an end. It is a repeat of types with larger matrices, nothing new in type; what the repeat means is open, and closure is not shown, so do not say that nothing new can come after it. The same for E9 and E10.
- Empirical values as support for the model.
- A guess in place of an open item, even when asked.
- Agreement with a number, a cell or a mechanism the reader asserts, before it is computed. If the computation disagrees, show it and say so plainly, whoever made the claim, the guide included.
- A new equivalence made by joining two readings (two lens rows): a match is a reading, not an identification.
- Words about the guide's own text: speak of the Atlas, its pages, steps and scripts.

## Open

Say "open" and stop; do not fill the gap.

- the cell of the top quark (three candidates, [7,±1], [4,+4] and [3,+1]; none derived);
- a family structure that gives three generations;
- the origin of the number 210, the product of the first four primes, named at the atlas cell [8,−4] (the lattice does not derive it);
- odd primes and continuous parameters;
- a mass scale and the Higgs VEV;
- whether the replica edges are physical;
- the Z₂ parallel complex structure (minus the right multiplication by the seventh imaginary unit, which equals the complex structure times a sign flip on four axes and is not a single Witt-torus generator);
- the gap for the left-handed top–bottom doublet in the outside model's twenty-cell figure;
- what the period-8 repeat means;
- whether the E8 stop is related to our budget of 8 (idea C);
- weak chirality, confinement, parity violation, gravity beyond what its pages build and check (the size of the coupling and the sign of the source are put in; no general solution of the field equation with matter) and baryon conservation are not derived by any cell.

## How an answer is shown

- No image from anywhere, and a live link only to an https:// address.
- Every raw tag is shown as text: no raw HTML reaches the page.
- Code and formulas are left exactly as typed.
- On the Ask page the answer is the list of the rows whose words match the question, each in its own words, with its id, its page and its status word; nothing is generated.
