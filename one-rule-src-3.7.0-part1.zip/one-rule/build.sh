#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# build.sh — the static site in dist/: app.js + app.css (esbuild bundle of src/app/main.jsx), the figures chunk figures-extra.js, index.html, and,
# through tools/build_chunks.mjs, the content tables (dist/content/), dist/content/version.json ({ contentVersion, appVersion }, the app
# version read from package.json at every build), the guide's rules (content/persona_rules.md, parsed), KaTeX (dist/katex/),
# the reports (public/) and the check scripts; then tools/export_tuning.mjs writes the Atlas as a tuning set to dist/content/tuning/ (R7-9).
# The bundles are minified, with no source map (A21: the sources ship as their own archive); budgets in tests/shipped.test.mjs (rule 5).
# The figures chunk (D47, BUILD_CONTRACTS interface 34), in three steps:
#   1 the bundle of the full registry (src/figures/index.js: every figure) → app.js, app.css; its stylesheet stays dist/app.css, so that every
#     figure's styles are there in their import order, the extra figures' too;
#   2 tools/build_extra.mjs → figures-extra.js (the figures under src/figures/physics/ and src/figures/explore/, a classic script that reads React and
#     the app's stateful modules from window.__ONE_RULE_BRIDGE__) and its ids, dist/content/figures_extra_ids.json;
#   3 the bundle of the core registry (src/figures/core.js) with those ids baked in (__ONE_RULE_EXTRA_IDS__) → app.js, which inserts the chunk the
#     first time a page needs one of its figures (src/app/lazyFigures.js).
#   Should step 2 or 3 fail, app.js of step 1 stays (every figure in it, no chunk) and the reason is printed: the site works either way.
# Offline: every module comes from /opt/npm-tools/node_modules (or NODE_MODULES=...); no npm install. Run from anywhere.
#   sh build.sh
set -e
cd "$(dirname "$0")"
NM="${NODE_MODULES:-/opt/npm-tools/node_modules}"
export NODE_PATH="$NM"
ESB="$NM/.bin/esbuild"
[ -x "$ESB" ] || ESB="$NM/esbuild/bin/esbuild"
[ -x "$ESB" ] || { echo "build.sh: esbuild not found under $NM" >&2; exit 1; }
OUT=dist
rm -rf "$OUT"
mkdir -p "$OUT"

# the parts other owners build are used when they exist (BUILD_CONTRACTS §Interfaces 2 and 3), else the placeholders
FIG=./src/pages/optional/figures.js
LOG=./src/pages/optional/logbook.jsx
[ -f src/figures/index.js ] && FIG=./src/figures/index.js
[ -f src/logbook/LogbookPage.jsx ] && LOG=./src/logbook/LogbookPage.jsx

# bundle <figures module> <logbook module> [more esbuild options]
bundle() {
  _fig="$1"; _log="$2"; shift 2
  "$ESB" src/app/main.jsx --bundle --outfile="$OUT/app.js" --format=iife --platform=browser --target=es2020 \
    --jsx=automatic --loader:.js=jsx \
    --alias:@one-rule/figures="$_fig" --alias:@one-rule/logbook="$_log" \
    --define:process.env.NODE_ENV='"production"' --minify --legal-comments=none --log-level=warning "$@"
}
# step 1: every figure
if ! bundle "$FIG" "$LOG"; then
  echo "build.sh: the bundle failed with $FIG and $LOG; building again with the placeholders (the error is printed above)" >&2
  bundle ./src/pages/optional/figures.js ./src/pages/optional/logbook.jsx
  FIG=./src/pages/optional/figures.js
fi
# steps 2 and 3: the chunk and the core bundle (only when the figures themselves built)
if [ "$FIG" = ./src/figures/index.js ] && [ -f src/figures/core.js ] && [ -f tools/build_extra.mjs ]; then
  if node tools/build_extra.mjs "$OUT"; then
    IDS=$(node -e "process.stdout.write(JSON.stringify(JSON.parse(require('fs').readFileSync(process.argv[1], 'utf8')).ids))" "$OUT/content/figures_extra_ids.json")
    mv "$OUT/app.css" "$OUT/app.full.css"
    if ! bundle ./src/figures/core.js "$LOG" "--define:__ONE_RULE_EXTRA_IDS__=$IDS"; then
      echo "build.sh: the core bundle failed; app.js keeps every figure and the chunk is removed (the error is printed above)" >&2
      rm -f "$OUT/figures-extra.js" "$OUT/content/figures_extra_ids.json"
    fi
    mv "$OUT/app.full.css" "$OUT/app.css"
  else
    echo "build.sh: the figures chunk could not be built; app.js keeps every figure (the reason is printed above)" >&2
  fi
fi
cp index.html "$OUT/index.html"
node tools/build_chunks.mjs "$OUT"
node tools/export_tuning.mjs "$OUT"
