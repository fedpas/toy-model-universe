// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Statement.jsx — one row, in the words of its text record for the current (mode, level, lens).
// At most one Badge (from the computed status); a "›" that opens the row's line in its section drawer; glossary terms underlined.
// When a lens is active, the row's readings in that lens follow the text on one line (LensReading); with no lens, nothing is added.
// It renders nothing when the row has no text at this level, and it refuses free text: passing children throws.
// Round 14 (docs/round14/STORY_ROUND.md §4.5): `chain` (a chain's id) goes to textFor and is written as data-chain — at learner level the row's span in
// that chain, else its learner text (D54) — and two variants serve the chains (src/components/Chain.jsx, ChainStory.jsx):
//   span     inline markup, one sentence of a story paragraph (span.statement.statement--span, its words in span.statement__text, an inline
//            statement__meta): its badge inline exactly where the status has one (D56); where the row has a drawer line, a click on the sentence or
//            Enter on its "›" (a button: the keyboard's and the screen reader's way in, its focus visible) opens the row's drawer; a lens reading (D7)
//            inside the span after its words. With `mention`, a recall: the sentence is a link to where the page tells the row (at=<id>; plain
//            words, `unlinked`, where the page does not draw that told position at this level), with no
//            glossary term, no reading and no "›" inside it
//   mention  the compact statement of a row told in another chain of the page, folded to two lines ("Show all"), with the link "Told in <section>" to
//            at=<id>; no anchor, no reading (D7: on the told position only)
// `told` marks a told position (data-told: a deep link at=<id> scrolls to it, and only it is marked as the target); `anchor` gives the anchor row-<id>
// (false where the page top holds it); `drawer` is the section whose drawer lists the row, the one the "›" opens.
import { useContext, useState } from 'react';
import { useSettings, textFor, statusOf } from '../app/content.js';
import { useRoute } from '../app/router.js';
import { rowHome, pageLabel } from '../app/queries.js';
import { CHAIN_LABELS, STORY_NEW_BADGE, badgeKind } from '../app/vocab.js';
import { PageContext } from './PageContext.js';
import RichText from './RichText.jsx';
import Badge from './Badge.jsx';
import Link from './Link.jsx';
import LensReading from './LensReading.jsx';
import { Chevron } from './Icons.jsx';

// characters above which a statement is shown folded to a few lines with "Show all" (the full text stays in the page); a bubble of the door's strip
// folds sooner, so that a long row keeps the strip's panels short; a mention folds to two lines
const LONG = { body: 700, compact: 700, hero: 520, bubble: 520, mention: 160 };

export default function Statement(props) {
  if (props.children != null) throw new Error('Statement renders the text record of its row and takes no children');
  const { id, register = 'full', variant = 'body', badge = true, evidence = true, where = false, chain = null, anchor = null, told = false, mention = false, toldIn = null, drawer = null, unlinked = false } = props;
  const s = useSettings();
  const ctx = useContext(PageContext);
  const route = useRoute();
  const [expanded, setExpanded] = useState(false);
  const text = textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register, chain });
  if (text == null) return null;

  const st = statusOf(id);
  const recall = variant === 'mention' || !!mention;
  const terms = ctx.gloss && !recall ? ctx.gloss.get(id) : null;
  const foldable = LONG[variant] != null && text.length > LONG[variant];
  const canOpen = evidence && !recall && ctx.openEvidence && ctx.hasDrawer(id);
  const openIt = () => ctx.openEvidence(id, drawer || undefined);
  const home = where ? rowHome(id) : null;
  // A60: "new" inside a story is the switch of src/app/vocab.js (on by default: D56, badges unchanged)
  const showBadge = !!(badge && st && st.badge) && !(variant === 'span' && !STORY_NEW_BADGE && badgeKind(st.status, st.badge) === 'new');
  const uid = `${variant}-${chain ? `${chain}-` : ''}${id}`;
  const textId = `txt-${uid}`;
  const anchored = anchor == null ? variant === 'body' || variant === 'hero' : !!anchor;
  const cls = ['statement', `statement--${variant}`];
  if (variant === 'span' && recall) cls.push('statement--recall');
  if (foldable && !expanded) cls.push('statement--folded');
  // a row a chain of the page tells is the target only where it is told (the page top shows the hero row too)
  if (route.at === id && !recall && (told || !(ctx.isTold && ctx.isTold(id)))) cls.push('is-target');
  const marks = { 'data-row': id, 'data-register': register, 'data-chain': chain || undefined, 'data-told': told ? id : undefined, 'data-mention': recall ? '' : undefined };
  const words = <RichText text={text} level={s.level} terms={terms} uid={uid} />;
  const evButton = canOpen ? (
    <button type="button" className="statement__ev" aria-label={`Evidence and more for this statement (${id})`} title="Evidence and more"
      aria-controls={drawer ? `drawer-${drawer}` : undefined} onClick={openIt}>
      <Chevron />
    </button>
  ) : null;

  if (variant === 'span') {
    const badgeEl = showBadge ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null;
    // a click on the sentence opens the drawer as its "›" does, unless it lands on a link, a button or a glossary term inside it
    const onClick = canOpen ? e => { const t = e.target; if (!(t && t.closest && t.closest('a, button, .gloss'))) openIt(); } : undefined;
    return (
      <span className={cls.join(' ')} {...marks} id={anchored ? `row-${id}` : undefined} onClick={onClick}>
        {recall && !unlinked
          ? <Link to={route.path} at={id} className="statement__text statement__recall" id={textId}>{words}</Link>
          : <span className={recall ? 'statement__text statement__recall' : 'statement__text'} id={textId}>{words}</span>}
        {recall ? null : <LensReading id={id} />}
        {badgeEl || evButton ? <span className="statement__meta">{badgeEl}{evButton}</span> : null}
      </span>
    );
  }

  return (
    <div className={cls.join(' ')} {...marks} id={anchored ? `row-${id}` : undefined}>
      <p className="statement__text" id={textId}>{words}</p>
      {recall ? null : <LensReading id={id} />}
      {(badge || canOpen || foldable || home || (recall && toldIn)) && (
        <div className="statement__meta">
          {badge && st ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null}
          {home && home.path !== route.path ? <Link to={home.path} at={id} className="statement__where">{pageLabel(home.path, s)}</Link> : null}
          {recall && toldIn ? <Link to={route.path} at={id} className="statement__told" data-connective="told-in">{`${CHAIN_LABELS.told} ${toldIn.label}`}</Link> : null}
          {foldable ? (
            <button type="button" className="statement__more" aria-expanded={expanded} aria-controls={textId} onClick={() => setExpanded(x => !x)}>
              {expanded ? 'Show less' : 'Show all'}
            </button>
          ) : null}
          {evButton}
        </div>
      )}
    </div>
  );
}
