// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/ChainStory.jsx — a storied chain at learner level (docs/round14/STORY_ROUND.md §4.7; D53): one paragraph, p.chain__story[data-chain],
// holding in order the lead's learner text (the lead story row's own learner text, the story's first sentence) and one span per position, each a
// Statement of the span variant: a told position's span opens the row's drawer (where the row has one) and carries its badge inline; a mention's span
// is a short recall that links to where the page tells the row. No other text node stands in the paragraph: every sentence is a text record of its row
// (the coverage invariant), the spaces between them come from the stylesheet (src/styles/chains.css).
// Props: chain (a chain of the page model, src/app/queries.js chainModel), sid (the section whose drawer lists its told positions).
import Statement from './Statement.jsx';

export default function ChainStory({ chain, sid = null }) {
  return (
    <p className="chain__story" data-chain={chain.id}>
      {chain.lead ? <Statement id={chain.lead} variant="span" evidence={false} /> : null}
      {chain.positions.map(p => (
        <Statement
          key={p.n} id={p.id} variant="span" register="span" chain={chain.id}
          told={!p.mention} mention={p.mention} unlinked={p.mention && !p.toldIn} anchor={!p.mention && p.anchor} drawer={p.mention ? null : sid}
        />
      ))}
    </p>
  );
}
