#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""candidates_from_outlines.py — task T2.4: the missing pieces (section C) of the ten persona outlines become
`content/candidates.json` (status `candidate`) and the summary `docs/labelling/CANDIDATES.md`.

Usage, from the repository root:  python3 -I tools/migrate/candidates_from_outlines.py  [--dump]

Reads only files of the repository: docs/labelling/outlines/{phys,math}_{A..E}.md (section C of each),
docs/labelling/SCHEME.md (the 29 notion codes), content/rows.json (the ids, and splitFrom/legacyLines to resolve
"LNB-016 line 2" to the split row of that line), content/theorems.json and content/questions.json. Writes only
content/candidates.json and docs/labelling/CANDIDATES.md. Deterministic: no clock, no randomness, every collection is
ordered explicitly. Stdlib only.

Steps: (1) cut section C of each outline into items (numbered bold titles, "### n." headings or "**Cn.**" headings) and the
blocks that are not items; (2) read each item's labelled fields in any of the five layouts (inline "Source: … Links: …",
line labels, bullets, bold or italic labels); (3) resolve the linked ids against the tables, logging what is not a row or a
theorem; (4) merge the items that state the same standard result (MERGES, the judge's table); (5) build one record per
candidate (title and statement of the first item of a group, union of proposers, rows and sources, checkability
'partly' when the proposers' verdicts differ, notions from the SCHEME §1 lexicon); (6) sort, number and write.
"""
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUTLINES = ROOT / 'docs' / 'labelling' / 'outlines'
PERSONAS = ['phys_A', 'phys_B', 'phys_C', 'phys_D', 'phys_E', 'math_A', 'math_B', 'math_C', 'math_D', 'math_E']
FIELDS = ['algebra', 'geometry', 'topology', 'category', 'combinatorics', 'analysis', 'physics']
CHECK_VALUES = ['yes', 'partly', 'no']

# ------------------------------------------------------------------------------------------------ 1. section C, blocks
def section_c(text):
    m = re.search(r'^## C\..*$', text, flags=re.M)
    if not m:
        return None
    rest = text[m.end():]
    n = re.search(r'^## ', rest, flags=re.M)
    return rest[:n.start()] if n else rest

# an item starts with one of: "12. **Title.** …" | "### 12. Title" | "**C12. Title.**"
ITEM_HEAD = [
    re.compile(r'^(\d+)\.\s+\*\*(.+?)\*\*(.*)$'),
    re.compile(r'^###\s+(\d+)\.\s+(.+?)\s*()$'),
    re.compile(r'^\*\*C(\d+)\.\s+(.+?)\*\*\s*(.*)$'),
]
# a block that is not an item: a bold line at column 0 that is not an item head (collected lists, summaries)
OTHER_HEAD = re.compile(r'^\*\*(?!C\d+\.)(.+?)\*\*(.*)$')

def blocks(sec):
    """Split section C into ('preamble'|'item'|'other', head, number, lines)."""
    out, cur = [], ['preamble', '', None, []]
    for line in sec.split('\n'):
        hit = None
        for rx in ITEM_HEAD:
            m = rx.match(line)
            if m:
                hit = m
                break
        if hit:
            out.append(cur)
            cur = ['item', hit.group(2).strip(), int(hit.group(1)), [hit.group(3).strip()] if hit.group(3).strip() else []]
            continue
        m = OTHER_HEAD.match(line)
        if m and not line.startswith('***'):
            out.append(cur)
            cur = ['other', m.group(1).strip(), None, [m.group(2).strip()] if m.group(2).strip() else []]
            continue
        cur[3].append(line)
    out.append(cur)
    return [b for b in out if b[0] != 'preamble' or any(l.strip() for l in b[3])]

# ------------------------------------------------------------------------------------------------ 2. fields of an item
LABELS = {
    'statement': r'Statement', 'source': r'Sources?', 'links': r'Links', 'field': r'Field', 'check': r'Check|Script|Engine',
    'why': r'Why it matters|Effect|Two-way chain', 'phenomenon': r'Phenomen(?:on|a)(?: approached)?(?:, not derived)?', 'kind': r'Kind',
}
LABEL_ALT = '|'.join('(?P<%s>%s)' % (k, v) for k, v in LABELS.items())
# "**Check: yes.**" (phys_C): the verdict sits inside the bold label
BOLD_VERDICT = re.compile(r'\*\*(Check|Script|Engine):\s*(yes|partly|no)\.\*\*', flags=re.I)
# a label at the start of a (bullet) line: "- **Statement:**", "- *Statement:*", "- Statement:", "**Statement.**", "Statement:"
LINE_LABEL = re.compile(r'^\s*(?:[-*]\s+)?(?:\*{1,2})?(?:%s)(?:\*{1,2})?\s*[:.](?:\*{1,2})?\s*' % LABEL_ALT)
# a label inside running text, after the end of a sentence: "… E₈/2E₈. Source: …", "… roots. *Field:* algebra."
INLINE_LABEL = re.compile(r'(?<=[.;)\]”"*’])\s+(?:\*{1,2})?(?P<lab>Source|Sources|Links|Field|Check|Script|Engine)(?:\*{1,2})?:(?:\*{1,2})?\s+')

def which(m):
    return next(k for k in LABELS if m.group(k))

def fields_of(lines):
    """Return (lead text before the first label, {field: text}) with labels in any of the outline formats."""
    text = '\n'.join(lines)
    text = BOLD_VERDICT.sub(lambda m: '%s: %s.' % (m.group(1), m.group(2)), text)
    # put every inline label on a line of its own
    text = INLINE_LABEL.sub(lambda m: '\n%s: ' % m.group('lab'), text)
    lead, got, cur = [], {}, None
    for line in text.split('\n'):
        m = LINE_LABEL.match(line)
        if m:
            cur = which(m)
            got.setdefault(cur, [])
            got[cur].append(line[m.end():])
            continue
        (got[cur] if cur else lead).append(line)
    return '\n'.join(lead), {k: '\n'.join(v) for k, v in got.items()}

STAR = '\ue000'   # a literal star ("C*-algebra", "*-ideal") hidden from the emphasis rules

def protect_stars(s):
    return re.sub(r'(?<=\w)\*(?=-)|(?<=\s)\*(?=-)', STAR, s)

def clean(s):
    """Markdown → plain text: bullets joined, emphasis and code marks dropped, whitespace collapsed."""
    s = protect_stars(s)
    s = re.sub(r'^\s*[-*]\s+', '', s, flags=re.M)
    s = re.sub(r'\*\*(.+?)\*\*', r'\1', s)
    s = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'\1', s)
    s = s.replace('`', '').replace(STAR, '*')
    return re.sub(r'\s+', ' ', s).strip()

def parse_outline(persona):
    path = OUTLINES / (persona + '.md')
    sec = section_c(path.read_text(encoding='utf-8'))
    items, other = [], []
    if sec is None:
        other.append({'file': path.name, 'kind': 'missing', 'head': 'no section C found', 'text': '', 'lines': []})
        return items, other
    for kind, head, num, lines in blocks(sec):
        if kind != 'item':
            other.append({'file': path.name, 'kind': kind, 'head': clean(head), 'text': clean('\n'.join(lines)), 'lines': lines})
            continue
        lead, f = fields_of(lines)
        title = clean(head).rstrip('.').strip()
        items.append({'persona': persona, 'file': path.name, 'num': num, 'ref': '%s C%d' % (persona, num), 'title': title,
                      'statement': clean(f.get('statement', '') or lead), 'leadExtra': clean(lead) if f.get('statement') else '',
                      'source': clean(f.get('source', '')), 'sourceRaw': f.get('source', ''), 'links': f.get('links', ''),
                      'field': clean(f.get('field', '')), 'check': clean(f.get('check', '')), 'why': clean(f.get('why', '')),
                      'phenomenon': clean(f.get('phenomenon', '')), 'kindNote': clean(f.get('kind', ''))})
    return items, other

# ------------------------------------------------------------------------------------------------ 3. ids
def load_ids():
    rows = json.loads((ROOT / 'content' / 'rows.json').read_text(encoding='utf-8'))
    theorems = json.loads((ROOT / 'content' / 'theorems.json').read_text(encoding='utf-8'))
    questions = json.loads((ROOT / 'content' / 'questions.json').read_text(encoding='utf-8'))
    # "LNB-016 line 2" (the outlines number the lines of a v15 row from 1): the migration (rows_from_v15.mjs) kept line 1 as
    # LNB-016 and made each further non-learner line a row LNB-016b, LNB-016c, … in order. When a family has as many rows
    # as the v15 row had lines (legacyLines), no line was a learner line and line k is the k-th row of the family.
    # Families with learner lines are not resolved: the base row is linked and the reference is logged.
    family = {}
    for r in rows:
        family.setdefault(r.get('splitFrom') or r['id'], []).append(r)
    line_row = {}
    for b, rs in family.items():
        ids = sorted((r['id'] for r in rs), key=lambda x: (len(x), x))
        if len(ids) == rs[0].get('legacyLines'):
            for k, rid in enumerate(ids, 1):
                line_row[(b, k)] = rid
    return ({r['id'] for r in rows}, {t['id'] for t in theorems}, {q['id'] for q in questions}, line_row, rows)

ROW_ID = re.compile(r'(?<![\w-])(?P<grp>[A-Z]{2,4})-(?P<num>\d{3})(?P<suf>[a-z]?)(?![\w-])')
# after an id: a bare number continues the list ("LNC-006, 018/107"); a range runs to a bare number or a full id
# ("LNC-133…135", "MAP-021 to MAP-028"). A full id after a comma is not a continuation (the main loop takes it).
CONT = re.compile(r'\s*(?:(?P<sep>,|/)\s*(?P<num>\d{3})(?P<suf>[a-z]?)'
                  r'|(?P<rsep>…|\.\.\.|–|\bto\b)\s*(?:(?P<grp>[A-Z]{2,4})-)?(?P<rnum>\d{3}))(?![\w-])')
LINES = re.compile(r'\s*,?\s+lines?\s+(?P<a>\d+)(?:\s*[–-]\s*(?P<b>\d+))?')
THM_ID = re.compile(r'(?<![\w-])T(\d{1,2})(?![\w-])')
Q_ID = re.compile(r'(?<![\w-])(Q[A-ET]\d{1,2})(?![\w-])')
OTHER_TOKEN = re.compile(r'(?<![\w-])(?:P\d|[a-z]+·[A-Za-z]+·?\w*|core·\w+)(?![\w-])')

def extract_ids(text, valid_rows, valid_thms, questions, line_row, log, resolved=None, qout=None):
    """Ids named in a Links field, in order: rows (with comma/slash continuations, ranges, 'line N'), theorems.
    Everything that looks like an id but is not a row or a theorem goes to the log; the question ids of questions.json
    named there also go to `qout` (A13: an answer keeps the id of the question it answers)."""
    found = []
    def add(x):
        if x not in found:
            found.append(x)
    def one(grp, num, suf, end):
        """Add GRP-num (or the rows of 'line N' right after it); return the end of what was consumed."""
        lm = LINES.match(text, end)
        if not lm:
            add('%s-%03d%s' % (grp, num, suf))
            return end
        a = int(lm.group('a')); b = int(lm.group('b') or a)
        for k in range(a, b + 1):
            rid = line_row.get(('%s-%03d' % (grp, num), k))
            if rid:
                add(rid)
                if resolved is not None:
                    resolved.append(('%s-%03d line %d' % (grp, num, k), rid))
            else:
                log.append(('line not resolved, base row linked', '%s-%03d line %d' % (grp, num, k)))
                add('%s-%03d' % (grp, num))
        return lm.end()
    pos = 0
    while True:
        m = ROW_ID.search(text, pos)
        if not m:
            break
        grp, prev = m.group('grp'), int(m.group('num'))
        end = one(grp, prev, m.group('suf'), m.end())
        while True:
            c = CONT.match(text, end)
            if not c:
                break
            if c.group('rsep'):
                if c.group('grp') and c.group('grp') != grp:
                    break
                n = int(c.group('rnum'))
                for k in range(prev + 1, n + 1):
                    add('%s-%03d' % (grp, k))
                end = c.end()
            else:
                n = int(c.group('num'))
                end = one(grp, n, c.group('suf'), c.end())
            prev = n
        pos = end
    for m in THM_ID.finditer(text):
        add('T' + m.group(1))
    out = []
    for x in found:
        if x in valid_rows or x in valid_thms:
            out.append(x)
        else:
            log.append(('not a row or theorem', x))
    for q in Q_ID.findall(text):
        log.append(('question id (questions.json), not a row', q) if q in questions else ('unknown id', q))
        if qout is not None and q in questions and q not in qout:
            qout.append(q)
    for o in OTHER_TOKEN.findall(text):
        log.append(('not an id (check or problem reference)', o))
    return out

# ------------------------------------------------------------------------------------------------ 4. the same result twice
# The judge's merges: items of different personas that state the same standard theorem or definition (under the same or
# another name). The first item of a group is the primary: its title and statement represent the candidate; the proposers,
# the linked rows and the sources are the union over the group. Each item is named by "persona C<number>" and a fragment of
# its title, so that a renumbered outline is noticed (the item is then left unmerged and the mismatch is logged).
# Items that bundle two results join the group of the result their title names first.
MERGES = [
    ('lorentz-force', [('phys_A C1', 'Lorentz force'), ('phys_B C2', 'Lorentz force')]),
    ('geodesic-motion', [('phys_B C1', 'Geodesic motion'), ('phys_A C5', 'geodesic motion')]),
    ('gauge-principle', [('math_B C18', 'Utiyama'), ('phys_A C2', 'gauge principle'), ('phys_B C8', 'Yang–Mills')]),
    ('pauli-g2', [('phys_E C4', 'g = 2'), ('phys_B C3', 'g = 2'), ('phys_A C6', 'g = 2')]),
    ('noether-second', [('math_B C3', 'Noether'), ('math_A C9', 'Noether'), ('phys_A C17', 'Yang–Mills')]),
    ('chern-weil', [('math_B C4', 'Chern–Weil'), ('phys_E C17', 'Chern–Weil')]),
    ('lovelock', [('phys_E C1', 'Lovelock'), ('phys_B C4', 'Lovelock')]),
    ('birkhoff', [('phys_E C2', 'Birkhoff'), ('phys_B C5', 'Birkhoff'), ('math_B C8', 'Birkhoff')]),
    ('hawking-temperature', [('phys_A C15', 'Hawking'), ('phys_B C14', 'Hawking'), ('phys_E C11', 'temperature')]),
    ('raychaudhuri', [('phys_E C10', 'Raychaudhuri'), ('phys_C C4', 'focusing')]),
    ('gravitational-waves', [('phys_B C6', 'gravitational waves'), ('phys_A C4', 'Gravitational waves')]),
    ('garding', [('math_E C4', 'Gårding'), ('phys_E C9', 'Gårding'), ('math_A C10', 'hyperbolicity')]),
    ('spin-statistics', [('phys_E C12', 'Spin–statistics'), ('phys_A C21', 'Spin and statistics'), ('phys_C C10', 'Spin and statistics')]),
    ('cpt', [('phys_B C15', 'CPT'), ('phys_A C14', 'CPT')]),
    ('majorana-weyl', [('math_D C12', 'Majorana–Weyl'), ('phys_D C8', 'Majorana–Weyl')]),
    ('tenfold-way', [('math_A C16', 'Kitaev'), ('phys_C C2', 'Altland–Zirnbauer'), ('math_C C19', 'tenfold')]),
    ('pin', [('math_B C11', 'Pin'), ('math_A C17', 'Pin'), ('phys_A C18', 'Pin'), ('math_E C9', 'Pin')]),
    ('frobenius-tqft', [('math_D C23', 'TQFT'), ('phys_D C19', 'TQFT'), ('math_B C12', 'Frobenius')]),
    ('fermionic-composites', [('phys_C C6', 'composite'), ('phys_E C24', 'composite')]),
    ('lieb-flux', [('phys_E C14', 'Lieb'), ('phys_C C17', 'Lieb')]),
    ('fermion-doubling', [('phys_B C22', 'doubling'), ('math_B C16', 'doubling')]),
    ('wilson', [('phys_E C15', 'Wilson'), ('phys_B C21', 'Wilson')]),
    ('pauli-hydrogen', [('phys_D C4', 'hydrogen'), ('phys_A C11', 'Hydrogen')]),
    ('so42-hydrogen', [('math_D C19', 'so(4,2)'), ('phys_D C11', 'SO(4,2)')]),
    ('fock', [('math_D C17', 'Fock'), ('phys_D C10', 'Fock')]),
    ('dirac-coulomb', [('phys_A C10', 'Dirac–Coulomb'), ('phys_B C17', 'Dirac–Coulomb'), ('phys_D C12', 'fine structure')]),
    ('e6-so10', [('phys_D C2', '27'), ('math_D C2', '27')]),
    ('e7-su3-su6', [('math_D C3', 'E₇'), ('phys_D C9', 'E₇')]),
    ('spin10-su5', [('math_D C5', 'Spin(10)'), ('phys_D C1', 'Spin(10)')]),
    ('weinberg-angle', [('phys_A C12', 'sin²θ_W'), ('phys_D C6', 'sin²θ_W')]),
    ('anomalies', [('phys_D C5', 'anomaly'), ('math_D C25', 'Anomaly'), ('phys_A C13', 'anomaly'), ('phys_E C6', 'anomaly')]),
    ('tkk', [('math_D C8', 'Kantor–Koecher'), ('phys_D C3', 'Kantor–Koecher')]),
    ('spin9-peirce', [('math_D C11', 'Spin(9)'), ('phys_D C7', 'h₂(𝕆)')]),
    ('thurston-ii218', [('math_D C16', 'Thurston'), ('phys_D C18', 'II₂,₁₈')]),
    ('even-unimodular-mod8', [('math_A C20', 'unimodular'), ('math_E C23', 'Milgram')]),
    ('contractions', [('math_E C17', 'Contractions'), ('math_A C19', 'Contractions'), ('math_B C10', 'contractions'), ('math_D C18', 'contraction')]),
    ('carroll', [('phys_C C3', 'Carroll'), ('math_C C18', 'Carroll')]),
    ('celestial-sphere', [('math_B C15', 'celestial'), ('phys_C C12', 'Null vectors')]),
    ('wall', [('math_A C2', 'Wall'), ('math_E C1', 'Wall'), ('math_C C7', 'Brauer–Wall')]),
    ('pauli-polar-space', [('phys_C C14', 'Pauli group'), ('math_C C16', 'Pauli groups'), ('math_E C6', 'stabiliser')]),
    ('chirality', [('phys_C C11', 'chirality'), ('phys_B C16', 'Chirality'), ('phys_E C19', 'Chirality')]),
    ('higgs', [('phys_E C18', 'Higgs'), ('phys_A C19', 'Higgs')]),
    ('kaluza-klein', [('phys_B C19', 'Kaluza–Klein'), ('math_E C20', 'Kaluza–Klein'), ('phys_E C22', 'Kaluza–Klein')]),
    ('maxwell-calladine', [('math_B C17', 'Maxwell–Calladine'), ('math_E C22', 'Maxwell–Calladine')]),
    ('euler-arnold', [('math_B C13', 'Euler–Arnold'), ('phys_B C20', 'Euler–Poincaré')]),
    ('bogoliubov', [('phys_D C17', 'Bogoliubov'), ('phys_E C23', 'Bogoliubov')]),
    ('del-pezzo', [('math_A C13', 'del Pezzo'), ('phys_A C20', 'del Pezzo')]),
    ('belinfante', [('phys_B C10', 'Belinfante'), ('math_E C21', 'Einstein–Cartan'), ('phys_E C16', 'Belinfante')]),
    ('cartan-gravity', [('math_B C1', 'Cartan connections'), ('phys_E C8', 'MacDowell–Mansouri')]),
]

# ------------------------------------------------------------------------------------------------ 5. checkability
VERDICT = r'(yes|partly|no)'
def checkability(text):
    """(value, note) from the outline's Check/Script/Engine text. A text naming two verdicts for two parts ('yes for the
    algebra; partly for the spectrum', 'no (moduli space); partly (the form)') is 'partly'. 'not applicable' → 'no'."""
    t = text.strip()
    if re.match(r'(?i)not applicable\b', t):
        return 'no', 'not applicable (definitions)'
    m = re.match(r'(?i)\**%s\b\**' % VERDICT, t)
    if not m:
        return None, t
    lead = m.group(1).lower()
    found = {lead}
    for rx in (r'\*\*%s\*\*' % VERDICT, r'[;,]\s*%s\b(?!-)' % VERDICT, r'(?i)\b%s\s+(?:for|in|off|on)\b' % VERDICT, r'\b%s\s*\(' % VERDICT):
        for v in re.findall(rx, t):
            found.add(v.lower())
    value = lead if len(found) == 1 else 'partly'
    rest = t[m.end():]
    if value != lead or re.match(r'\s*(?:for|in|off|on|with)\b', rest):
        return value, t                      # a qualified or mixed verdict reads only as a whole
    note = rest.lstrip(' .,:;—–-').strip()
    if note.startswith('('):                 # "yes (the marks are in the enumerated roots)." → the parenthesis alone
        depth = 0
        for i, ch in enumerate(note):
            depth += (ch == '(') - (ch == ')')
            if depth == 0:
                if i == len(note.rstrip('.')) - 1:
                    note = note[1:i]
                elif note[i + 1:i + 2] == '.':   # "(already in use). Stated once …" → "already in use. Stated once …"
                    note = note[1:i] + note[i + 1:]
                break
    return value, note

# ------------------------------------------------------------------------------------------------ 6. statement and title
ABBREV = re.compile(r'(?:\b(?:e\.g|i\.e|cf|vs|Vol|vol|Thm|Fig|No|Ch|ch|eq|al|resp|approx|Prop|Sec|Def|etc)\.|\b[A-Z]\.)$')
def sentences(s):
    out, buf = [], ''
    for tok in re.split(r'(?<=[.!?])\s+', s):
        buf = buf + ' ' + tok if buf else tok
        if ABBREV.search(buf):
            continue
        out.append(buf)
        buf = ''
    if buf:
        out.append(buf)
    return out

MATH_WORDS = {'so', 'su', 'sl', 'sp', 'gl', 'iso', 'det', 'dim', 'tr', 'exp', 'mod', 'e', 'f', 'g', 'h', 'u', 'o', 'n', 'd', 'k', 'q', 'x'}
def short_statement(s, keep=2):
    """The outline's statement, verbatim, cut after its first `keep` sentences; a cut is marked with ' …'."""
    ss = sentences(s)
    out = ' '.join(ss[:keep])
    if len(ss) > keep:
        out += ' …'
    m = re.match(r'([a-z]+)\b(?![(_^₀-₉ⁿ])', out)
    if m and m.group(1) not in MATH_WORDS:
        out = out[0].upper() + out[1:]
    return out

# ------------------------------------------------------------------------------------------------ 7. sources
def split_refs(raw):
    """The references of a Source field: bullets (phys_C) or ';' outside parentheses; each with a key (its title in
    italics or quotes, else its text) for removing the same work cited by two proposers."""
    parts = []
    lines = [l for l in raw.split('\n') if l.strip()]
    chunks = [re.sub(r'^\s*[-*]\s+', '', l) for l in lines] if any(re.match(r'^\s*[-*]\s+', l) for l in lines) else [' '.join(lines)]
    for ch in chunks:
        depth, cur = 0, ''
        for c in ch:
            depth += (c == '(') - (c == ')')
            if c == ';' and depth == 0:
                parts.append(cur); cur = ''
            else:
                cur += c
        parts.append(cur)
    refs = []
    for p in parts:
        text = clean(p).rstrip('.').strip()
        if text:
            refs.append(parse_ref(p, text))
    return refs

BACKREF = re.compile(r'(?:,\s*|\s+)as above\b|\s*\(as (?:in )?(?:item |C\.?)(?P<n1>\d+)\)|,?\s+as in (?:item |C\.?)(?P<n2>\d+)')
BACKREF_SPLIT = re.compile(r'(?:,\s*|\s+)as above\b|\s*\(as (?:in )?(?:item |C\.?)\d+\)|,?\s+as in (?:item |C\.?)\d+')
INITIALS = re.compile(r'\s*(?:[A-ZÀ-Þ]\.\s*(?:-?[A-ZÀ-Þ]\.\s*)*)\S')

def surnames(s):
    s = re.sub(r'\([^)]*\)', ' ', s)
    toks = re.findall(r"(?<![\w.])([A-ZÀ-ÖØ-Þ][\w'’-]+)(?![\w.])", s.replace('–', ' '))
    return frozenset(t for t in toks if t not in {'And', 'The', 'As', 'In', 'Item', 'See'})

def norm_title(s):
    s = re.sub(r'\([^)]*\)', ' ', s)
    s = re.sub(r'[^\w]+', ' ', s.lower()).strip()
    return re.sub(r'^the ', '', s)

def parse_ref(raw, text):
    """A reference as {text, key (normalised title, or None for an author-only citation), authors, back} where back is
    None, 'above' or an item number when the outline cites by back-reference ('Slansky, as above', 'as in item 2', 'as C1')."""
    back = None
    b = BACKREF.search(text)
    if b:
        n = b.group('n1') or b.group('n2')
        back = int(n) if n else 'above'
    raw = protect_stars(raw)
    t = re.search(r'\*([^*]+)\*|[“"]([^”"]+)[”"]', raw)
    if t:
        title = (t.group(1) or t.group(2)).replace(STAR, '*')
        lead = clean(raw[:t.start()])
        return {'text': text, 'key': norm_title(title), 'authors': surnames(lead), 'back': back}
    head = BACKREF_SPLIT.split(text)[0] if back else text
    # "C. Doran and A. Lasenby, Geometric Algebra for Physicists": the title starts after the first comma (outside
    # parentheses) that is not followed by initials
    depth = 0
    for i, ch in enumerate(head):
        depth += (ch == '(') - (ch == ')')
        if ch != ',' or depth:
            continue
        if not INITIALS.match(head, i + 1):
            title = head[i + 1:].strip()
            if title and not back:
                return {'text': text, 'key': norm_title(title), 'authors': surnames(head[:i]), 'back': None}
            break
    return {'text': text, 'key': None, 'authors': surnames(head), 'back': back}

def resolve_backrefs(items_of_persona, log):
    """Replace 'X, as above' / 'X (as in item N)' by the reference to X that the same outline gave earlier."""
    done = {}
    for it in items_of_persona:
        out = []
        for r in split_refs(it['sourceRaw']):
            if r['back'] is None:
                out.append(r)
                continue
            # the item named, or else the nearest earlier item of the same outline
            pool = [(r['back'], x) for x in done.get(r['back'], [])] if isinstance(r['back'], int) else \
                   [(n, x) for n in sorted(done, reverse=True) for x in done[n]]
            hits = [(n, x) for n, x in pool if x['authors'] and x['authors'] == r['authors']]
            if not hits and r['authors']:
                hits = [(n, x) for n, x in pool if r['authors'] <= x['authors']]
            if not hits:
                log.append((it['ref'], 'back-reference in Source not resolved; kept as written', r['text']))
                out.append(dict(r, back=None))
                continue
            n0, first = hits[0]
            same = [x for x in done[n0] if x['authors'] == first['authors']]
            extra = BACKREF_SPLIT.split(r['text'])[-1].strip() if r['back'] == 'above' else ''
            for x in same:
                out.append({'text': x['text'] + ((' ' + extra) if extra else ''), 'key': x['key'], 'authors': x['authors'], 'back': None})
        done[it['num']] = out
        it['refs'] = out

def merge_refs(members):
    """The union of the members' references: the same title once; an author-only citation dropped when the same authors are
    cited with a title (and replaced by it when the titled one comes later)."""
    out = []
    for m in members:
        for r in m['refs']:
            if r['key'] is not None:
                # the same title, or the same authors with one title a prefix of the other ("Spinors and Space-Time" / "…, Vol. 1")
                if any(x['key'] == r['key'] or (x['key'] and x['authors'] and x['authors'] == r['authors'] and
                       (x['key'].startswith(r['key']) or r['key'].startswith(x['key']))) for x in out):
                    continue
                k = next((i for i, x in enumerate(out) if x['key'] is None and x['authors'] and x['authors'] == r['authors']), None)
                if k is not None:
                    out[k] = r
                    continue
                out.append(r)
            else:
                if r['authors'] and any(x['authors'] == r['authors'] for x in out):
                    continue
                out.append(r)
    return [r['text'] for r in out]

# ------------------------------------------------------------------------------------------------ 8. notions (SCHEME §1)
def scheme_codes():
    codes = []
    for line in (ROOT / 'docs' / 'labelling' / 'SCHEME.md').read_text(encoding='utf-8').split('\n'):
        m = re.match(r'^\|\s*(\d+)\s*\|\s*`([A-Za-z-]+)`\s*\|\s*([+−-]?\d)\s*\|\s*(\d+)\s*\|', line)
        if m:
            codes.append((int(m.group(1)), m.group(2), m.group(3).replace('−', '-'), int(m.group(4))))
    codes.sort()
    return [c[1] for c in codes], {c[1]: c[2] for c in codes}

# The words of each notion as SCHEME §1 describes it, matched on the title and the full statement of every item of a
# candidate. A lexicon is a labelling aid, not a reading: the author or a persona pass may correct a label.
LEXICON = {
    'lbl': [r'\blabels?\b', r'\bbit[- ](?:rule|masks?|counts?|strings?)\b', r'\bbits\b', r'\bfive-bit\b', r'\bXOR\b', r'\bpopcount',
            r'𝔽₂[ⁿ⁸³]|ℤ₂[ⁿ³⁸]|ℤ₂\^', r'\bBoolean lattice\b|\bB_n\b|\bBₙ\b|\bB₁ⁿ|\bB_k\b|\bBₖ|2\^\[n\]', r'\bn-cube\b|\bcube\b',
            r'\bWalsh\b', r'\bHamming distance\b', r'\boccupation patterns?\b'],
    'sgn': [r'\bcocycles?\b', r'\bcochains?\b', r'\bcoboundary\b', r'\bbit-rule signs?\b', r'\breordering sign\b',
            r'\bsign (?:assignments?|cocycle)\b', r'\bsigns on a cube\b', r'\bJordan–Wigner\b', r'\bKoszul sign\b',
            r'\banticommut', r'\bassociativ', r'\balternativ', r'\bH²\(', r'\bexchange sign\b', r'\bπ[- ]flux\b|\bflux π\b',
            r'\bcube sign\b'],
    'sq': [r'\bCl\(', r'\bCl⁰|\bCl⁺', r'\bsignatures?\b', r'\bLorentzian\b', r'\bEuclidean\b', r'\bsquares? to [+−-]1\b|\bsquares? to ±1\b|\bsquare of the volume element\b', r'ω² = \(−1\)|δ = ω²',
           r'\bsquare [+−-]1\b|\bsquares? ±1', r'\bsplit (?:form|real form|signature|octonions)\b', r'\bindefinite\b',
           r'\(p,\s?q\)|\(s,\s?t\)|\bp − q\b|\bs − t\b', r'\bspacelike\b|\btimelike\b', r'γ² = 1', r'\bnull covectors?\b'],
    'grd': [r'\bgrad(?:e|es|ed|ing|ings)\b', r'\b\d-grad', r'ℤ-grad', r'\bparity\b', r'\bdegree[- ](?:0|±\d)\b',
            r'\beven (?:sub)?algebra\b|\beven part\b|\beven elements?\b|\beven ψ\b|\beven labels\b|\beven Clifford\b|Λ\^ev',
            r'\bfiltration\b|\bfiltered\b|\bassociated graded\b|\bgr Cl\b', r'\bpseudoscalar\b|\bvolume element\b|γ5|γ₅|\btop[- ](?:blade|label)\b|ω² = \(−1\)|δ = ω²',
            r'\bchiral', r'\bsuper-?dimension\b|\bsupertrace\b|\(−1\)\^F'],
    'qf': [r'\bquadratic (?:forms?|spaces?|refinements?)\b', r'\bpolar (?:form|spaces?)\b', r'\bbilinear forms?\b', r'\bO\(Q\)',
           r'\bWitt (?:index|decomposition|pairing)\b', r'\btotally (?:singular|isotropic)\b', r'\bisotropic\b',
           r'\bLagrangians? of the label form\b|\bits Lagrangians\b|\ba Lagrangian, i\.e\.', r'\bhyperbolic planes?\b', r'\banisotropic\b', r'\bArf\b', r'\bquadrics?\b',
           r'\bsymplectic (?:form|polar space|space)\b', r'\bcommutation form\b', r'\bcharacteristic vectors?\b',
           r'ℤ₄-(?:valued|forms?|enhancements?)', r'\brefines? the dot product\b', r'\bradical of (?:a|the|its) (?:quadratic|polar|bilinear)'],
    'clk': [r'\bclock\b', r'\bGauss(?:–Milgram)? sums?\b', r'\bBrown (?:invariant|homomorphism)\b', r'ℤ₄', r'\bmod 8\b',
            r'ℤ₈|ℤ₁₆', r'\btype table\b', r'ℝ, ℂ or ℍ|ℝ/ℂ/ℍ', r'\bthreefold way\b|\btenfold\b|\bperiodic table\b|\bAltland–Zirnbauer\b|\bBott\b',
            r'\bFrobenius–Schur\b', r'\bMajorana–Weyl\b', r'M₂\(ℍ\)|M₄\(ℝ\)|M_N\(D', r'\bKervaire\b', r'\bMilgram\b',
            r'\bvan der Blij\b', r'\bKramers\b'],
    'mir': [r'\bmirror\b', r'\breversion\b', r'\bClifford conjugation\b', r'\banti-?involutions?\b', r'\binvolutions?\b',
            r'\bdagger\b', r'\bpositiv(?:e (?:normalised )?functionals?|ity)\b', r'\bGibbs state\b', r'\bFrobenius forms?\b',
            r'\btop-(?:label|blade) form\b', r'\bcharge conjugation\b|\bCPT\b|\bCP\b', r'\btime reversal\b', r'\bunitar',
            r'\bsuperselection\b', r'\bstates? (?:extend|vanishes|in the sense of|for an involution)\b', r'\bstate of a subsystem\b',
            r'\bPin\(p,\s?q\) and Pin\(q,\s?p\)'],
    'nul': [r'\bnull\b', r'\bradicals?\b', r'\bLoewy\b', r'\bnilpotent\b', r'\bexterior (?:algebras?|products?|calculus)\b',
            r'Λ\((?:V|ℝ|ℂ|H)|Λℝ|Λℂ|Λ\^(?:ev|top)|ΛV\b', r'\bGrassmann\b', r'\bBerezin\b',
            r'(?<!non-)\bdegenerate (?:metric|forms?|quadratic|case)\b|\bmetric degenerates\b', r'\bCarroll', r'\bd \+ δ\b|\bHodge\b',
            r'\bKoszul (?:complex|boundary)\b', r'\bQ² = 0\b', r'\bghosts?\b', r'\bzero-norm\b', r'\bregressive\b'],
    'tns': [r'\btensor products?\b', r'⊗̂', r'⊗', r'\bMorita\b', r'\bAzumaya\b', r'\bperiodicity\b', r'\bCl\(n,\s?n\)',
            r'\bEnd\((?:Λ|V|A)\b', r'\bbase change\b', r'\bcomplement (?:map|move|labels?)\b', r'\bhalving\b',
            r'\bBrauer(?:–Wall)?\b|BW\(ℝ\)', r'\bcomposite\b', r'\buntwisting\b', r'\bKronecker\b'],
    'mod': [r'\bmodules?\b', r'\bspinors?\b|\bhalf-spin\b|\bpinors?\b', r'\bideals?\b', r'\bidempotents?\b', r'\bPeirce\b',
            r'\bFock\b', r'\bCAR\b|\bCCR\b', r'\bladder\b', r'\bprojectors?\b', r'\bBorn rule\b',
            r'\brepresentations?\b(?! numbers?)|\birreps?\b|\birreducible\b', r'\bthe 16\b|\bthe 27\b(?! lines)|16 ⊕ 16̄|\b27 = |\b133 = ',
            r'\bcreation\b|\bannihilation\b', r'\boccupations?\b', r'\bqubits?\b', r'\bMajoranas?\b(?!–Weyl)',
            r'\bweight (?:sets?|spaces?)\b|\bfundamental weights?\b', r'\bbranching\b', r'\bmultiplets?\b', r'\bcommutant\b',
            r'\beigenbasis\b', r'\bstabili[sz]er states\b'],
    'biv': [r'\bbivectors?\b', r'\bcommutators?\b', r'\bLie (?:algebras?|groups?|brackets?)\b', r'(?<![A-Za-z])(?:so|su|sl|sp|gl|iso|spin)\([0-9nm]',
            r'(?<![A-Za-z])(?:so|su|sl|sp)[₀-₉]', r'(?<![A-Za-z])(?:Spin|SO|SU|SL|Sp|PSL|PU|GL)\(|(?<![A-Za-z])SO⁺|(?<![A-Za-z])O\((?!Q\))|(?<![A-Za-z])U\(\d',
            r'\brotors?\b|\bversors?\b|\bmotors?\b', r'\bCartan–Dieudonné\b', r'\binvariant decomposition\b', r'\breflections?\b',
            r'\bKilling form\b', r'\bCasimirs?\b', r'(?<![A-Za-z])[ef][₄₆₇₈](?![\w])|(?<![A-Za-z])g₂(?![\w])', r'\bE[₆₇₈] ⊃|⊃ D₅|⊃ SO',
            r'\bLevi (?:subalgebra|factors?|so)\b|\bthe Levi\b', r'\broot vectors?\b', r'\bcontractions?\b|\bcontracts? (?:su|so|the|to)\b', r'\blittle groups?\b',
            r'\bLorentz (?:group|algebra)\b|\bPoincaré (?:group|algebra)\b|\bGalilei\b', r'\bconformal (?:group|algebra)\b', r'\bboosts?\b',
            r'(?<!duality )\brotations?\b', r'\bKantor–Koecher\b|\bTits–Kantor\b', r'\bspectrum-generating\b|\bdynamical (?:algebra|group)\b',
            r'\bMöbius (?:maps|group)\b', r'\bskew operators?\b'],
    'cnx': [r'\bconnections?\b', r'\bcurvature\b', r'\btorsion\b', r'\bBianchi\b', r'\bcovariant(?:ly)? (?:derivative|conserv)',
            r'\bD_A\b|D⋆F|D\^μ', r'\bEinstein (?:form|tensor)\b|\bG_(?:μν|ab)\b|\bE_a\b|E⁽¹⁾', r'\bWeyl tensor\b|\bRicci\b|\bRiemann\b|\bholonomy\b',
            r'\bFermi–Walker\b|\bparallel transport\b|\bframe dragging\b|\bgeodetic\b', r'\bWeitzenböck\b|\bLichnerowicz\b',
            r'\bChern–Weil\b|\bcharacteristic (?:forms?|classes)\b|\bPontryagin\b|\bGauss–Bonnet', r'\bgauge (?:fields?|transformations?|invariance|invariant|principle|theor(?:y|ies))\b',
            r'\bYang–Mills\b', r'\bplaquettes?\b', r'\bminimal(?:ly)? coupl', r'\bKilling (?:fields?|horizons?)\b', r'\bspin connection\b',
            r'\bCartan (?:connections?|geometry|gravity)\b', r'\bRaychaudhuri\b'],
    'var': [r'\bEuler–Lagrange\b', r'\bvariation(?:al)?\b|\bvarying\b|\bfirst-variation\b', r'\bNoether\b', r'(?<!self-)\bstress(?:-energy|es)?\b',
            r'\bcurrents?\b', r'\bconserv(?:ed|ation)\b', r'\bBelinfante\b', r'\benergy[- ]momentum\b', r'\bdivergence(?:-free)?\b',
            r'\bidentities among\b|\bdifferential identity\b'],
    'sol': [r'\bKerr\b', r'\bSchwarzschild\b', r'\bReissner\b|\bNordström\b|\bKottler\b|\bNariai\b', r'\bde Sitter\b',
            r'\bFRW\b|\bFriedmann\b', r'\bplane[- ]waves?\b', r'\bsurface gravity\b', r'\bKomar\b|\bSmarr\b', r'\bweak-field\b|\bNewtonian\b',
            r'\bperihel|\bperiastron\b', r'\bprecessions?\b', r'\binstantons?\b|\bmonopoles?\b', r'\b(?:exact|classical|vacuum) solutions?\b|\bYang–Mills solutions\b',
            r'\bbound states?\b', r'\bLiénard–Wiechert\b', r'\bCoulomb (?:field|potential|problem)\b|\bDirac–Coulomb\b', r'\bretarded\b',
            r'\bhorizons?\b', r'\bHawking\b|\bblack[- ]holes?\b|\barea theorem\b', r'\bBirkhoff\b', r'\b1PN\b|\bpost-Newtonian\b',
            r'\bquadrupole\b', r'\bgravitational (?:waves?|radiation|polarisations)\b', r'\bfocus(?:ing|es)?\b', r'\bfine structure\b|\bSommerfeld\b|\bBalmer\b',
            r'\bscattering\b', r'\bLarmor\b'],
    'lat': [r'(?<!spring )(?<!bipartite )(?<!Boolean )\blattices?\b(?! (?:gauge|Dirac|operator|fermions?|Hamiltonian|Maxwell))', r'\broot (?:systems?|lattices?|graphs?|vectors?)\b|\b(?:simple|enumerated|27) roots\b|\bis a root\b|\bthe roots are\b',
            r'E_n/2E_n|E₈/2E₈|W\(E_n\)|\bE_n root|E_\{n\(n\)\}|\bE₈ lattice\b|E₈\(±1\)|(?<![A-Za-z])E₁[01]|Ẽ', r'\bGosset\b|\bpolytopes?\b|\bcross-polytope\b|\borthoplex\b|\bdemicube\b|\b24-cell\b|\b16-cells\b',
            r'\bW\(E', r'\bvan der Blij\b|\bMilgram\b|\bunimodular\b', r'\bDynkin\b|\bCartan matri(?:x|ces)\b|\bhighest root\b|\bcoroot\b|\bsubdiagrams?\b',
            r'\bhexagonal\b|\bEisenstein\b|\btheta series\b', r'II₂,₁₈|\bII_\{', r'\bweight lattice\b', r'\bSchläfli\b',
            r'\bdel Pezzo\b|\bexceptional curves\b|\b27 lines\b|\(−1\)-curves', r'\bLeech\b|\bConstruction A\b', r'\bMcKay\b|\bmarks\b', r'\bsimply-laced\b'],
    'fin': [r'\bcodes?\b', r'\bHamming code\b|\bextended Hamming\b', r'\bGolay\b|\bReed–Muller\b|\bRM\(1,3\)', r'\bSteiner\b', r'\btransvections?\b',
            r'\bquadrics?\b', r'\bPeres–Mermin\b|\bMermin–Peres\b', r'\bPauli (?:groups?|operators)\b|\bstabili[sz]er (?:formalism|codes?|groups?|states?)\b', r'\bClifford group\b',
            r'\bpolar spaces?\b|\bgeneralized quadrangle\b', r'𝔽₂', r'\bfinite (?:groups?|subgroups?|posets?|categor(?:y|ies)|structures?)\b',
            r'\bdouble groups?\b|\bbinary (?:icosahedral|octahedral)\b|2\.A[₄₅]', r'\bcharacter table\b', r'\bFano\b',
            r'\bDedekind\b|\bup-sets?\b|\bmonotone Boolean\b', r'\bposets?\b', r'\bstrongly regular\b|\bsrg\b', r'\bgraphs?\b',
            r'\bframeworks?\b|\bLaman\b', r'\bcontextuality\b|\bKochen–Specker\b'],
    'div': [r'\boctonions?\b|𝕆', r'\bFano\b', r'(?<![A-Za-z])G₂(?![\w])|(?<![A-Za-z])g₂(?![\w])', r'\btriality\b', r'\bCayley–Dickson\b|\bbi-Cayley\b',
            r'\bcomposition algebras?\b', r'\bHurwitz\b', r'\bZorn\b', r'\balternativ', r'\bAlbert algebra\b', r'\bdivision algebras?\b',
            r'\bquasialgebra\b'],
    'dyn': [r'\brigid\b', r'(?<!black-hole )(?<!quantum )\bmechanics\b', r'\bforque\b', r'\bPGA\b', r'\bsprings?\b', r'\bWalsh\b', r'\bsigned (?:network|hopping)\b',
            r'\bFloquet\b|\bBloch\b|\bbands?\b|\bBrillouin\b', r'\bKepler\b|\bRunge–Lenz\b', r'\bhydrogen\b', r'\bEuler(?:–Arnold|–Poincaré)\b|\bEuler equation\b',
            r'\bgyroscope\b|\bspinning\b', r'\bN-body\b|\bequations of motion\b', r'\bgeodesic (?:flow|motion|equation)\b|\bfree fall\b|\bgeodesics\b',
            r'\bphonons?\b|\bsound\b', r'\bhopping\b|\bHubbard\b|\bhalf-fill', r'\blattice (?:gauge|Dirac|fermions?|Hamiltonian|operator|Maxwell)\b',
            r'\bstaggered\b|\bKogut–Susskind\b|\bWilson\b|\bflux phase\b', r'\bHamiltonians?\b', r'\btennis-racket\b|\bsteady rotations?\b',
            r'\bmechanisms\b', r'\b(?:Majorana|dimerised|Ising) chain\b'],
    's-alg': [r'\bWall\b|\bBrauer(?:–Wall)?\b|BW\(ℝ\)', r'\bHurwitz\b', r'\bDieudonné\b', r'\bNakayama\b', r'\brepresentation type\b|\btame\b|\bwild\b',
              r'\bHochschild\b', r'\bMorita\b', r'\bseparab', r'\bdouble centrali[sz]er\b', r'\bChevalley\b', r'\bJordan (?:pairs?|triples?|algebras?)\b|\btripotents?\b',
              r'\bKac\b', r'\bDynkin\b', r'\bbranching\b'],
    's-geo': [r'\bChristoffel\b', r'\bSchwarzschild\b|\bKerr\b|\bReissner\b|\bNordström\b|\bFRW\b|\bFriedmann\b', r'\bBirkhoff\b', r'\bfirst law\b',
              r'\bPetrov\b', r'\bWeyl tensor\b', r'\bMacDowell–Mansouri\b', r'\bCartan (?:geometry|connections?)\b', r'\bWald\b',
              r'\bPin[⁻⁺±]? (?:bordism|structures?)\b|\bbordism\b|\bArf–Brown–Kervaire\b', r'\bLovelock\b', r'\bRaychaudhuri\b', r'\bHawking\b',
              r'\bKilling horizons?\b', r'\bdel Pezzo\b', r'\bThurston\b', r'\bGårding\b|\bhyperbolic(?:ity)? (?:polynomials?|cone)\b|\bwell-posed',
              r'\bChern–Weil\b|\bcharacteristic classes\b|\bw₂\b'],
    's-phy': [r'\bMaxwell(?:\'s)?\b(?!–Calladine)', r'\bLorentz force\b', r'\bDirac\b', r'\bYang–Mills\b', r'\bEinstein–Cartan\b', r'\bBelinfante\b',
              r'\bHehl–Datta\b', r'\bStandard Model\b|\bhypercharges?\b|\b(?:one|a|each|every|three|the) (?:Standard Model )?generations?\b|\belectroweak\b|\bquarks?\b|\bleptons?\b', r'\bFloquet–Bloch\b',
              r'\bKitaev\b|\bFidkowski\b|\bAltland–Zirnbauer\b', r"\bWigner's\b|\blittle groups?\b", r'\bHiggs\b', r'\banomal', r'\bspin–statistics\b|\bspin and statistics\b',
              r'\bCPT\b', r'\bKaluza–Klein\b', r'\bWeyl (?:spinors?|equations?)\b', r'\bLieb\b', r'\bBRST\b|\bKugo–Ojima\b', r'\bWitten index\b',
              r'\bKramers\b|\bDyson\b', r'\bBogoliubov\b', r'\bHubbard\b', r'\bFermi–Dirac\b|\bGibbs\b', r'\bBethe\b', r'\bRutherford\b',
              r'\bsupersymmetr', r'\bgauge principle\b|\bminimal(?:ly)? coupl', r'\bWilson\b', r'\bNielsen–Ninomiya\b|\bdoubling theorem\b',
              r'\bPauli (?:equation|limit|term)\b|\bg = 2\b', r'\bLarmor\b|\bAbraham–Lorentz', r'\bgravitational waves?\b', r'\bMadelung\b|\bThomas–Fermi\b',
              r'\bsin²θ_W\b|\bweak mixing\b'],
    's-cat': [r'\bsVec\b', r'\bFrobenius algebras?\b', r'\bmonoidal\b', r'\bnerves?\b', r'\bincidence algebras?\b', r'\bsimplicial (?:complex(?:es)?|sets?|cohomology)\b|\border complex\b',
              r'\bcohomology\b|\bH²\(|HH[•¹²≥]|\bH•', r'\bKoszul\b', r'\bcategor(?:y|ies)\b', r'\bfunctors?\b', r'\bTQFTs?\b', r'\bK-theory\b|\bKO-theory\b',
              r'\bbordism\b|\bcobordism', r'\bEuler characteristic\b', r'\bMöbius function\b', r'\bcospans?\b', r'\bmagnitude\b'],
    'src': [r'\bFurey\b', r'\bBaez\b', r'\bSchuller\b', r'\bHestenes\b|\bLasenby\b|\bDoran\b', r'\bDorst\b|\bDe Keninck\b|\bGunn\b',
            r'\bRoelfs\b|\bEelbode\b', r'\bTian\b', r'\bMajkić\b', r'\bPumplün\b', r'\bHobson\b', r'\bVollick\b'],
    'i-chart': [r'\bcharts?\b', r'\bcoordinates?\b', r'\bframe class\b', r'\bunits\b', r'\bstereographic\b', r'\bKerr–Schild (?:ansatz|form|frames?)\b'],
    'i-time': [r'\btime (?:orientation|reversal)\b', r'\bT² ?(?:=|and C²|, C²)', r'\b(?:signature|sign) conventions?\b|\(\+,−,−,−\)|\(−,\+,\+,\+\)|\btime-positive\b',
               r'\bchosen γ₀\b|\bsplit by γ₀\b'],
    'i-J': [r'\bcomplex structures?\b', r'\bvacua\b|\bvacuum (?:expectation|value)s?\b|\bchoice of vacuum\b', r'\bVEV\b', r'\bWitt (?:split|pairing)\b|\bpolari[sz]ation\b(?!s)', r'\bLagrangian splits?\b',
            r'\bneeds complexification\b|\bcomplexified\b'],
    'i-act': [r'\b(?:Einstein–Hilbert|Yang–Mills|Yang–Mills–Dirac|Dirac|rigid-body|Wilson|lattice gauge|gauged Dirac) actions?\b', r'\b(?:the|an) action\b(?! of)',
              r'\baction principle\b', r'(?<!its )\bLagrangians?\b(?! of the label form)(?! splits?)(?!, i\.e\.)', r'\bcouplings?\b', r'\bpostulat', r'\bforce law\b',
              r'\bYukawa\b', r'\bconstitutive\b', r'\bcosmological (?:constant|term)\b|\bwith Λ\b|\bΛ = |\bthe sign of Λ\b', r'\bequation of state\b',
              r'\bsign of the source\b'],
    'i-tab': [r'\bStandard Model\b|\bhypercharges?\b|\bSM labels\b', r'\bFurey\b', r'\bFig\. 1\b', r'\bephemer', r'\bMadelung\b',
              r'\bmultiplication table\b', r'\bGravity Probe B\b|\bobserved\b|\bCoNb₂O₆\b', r'\b(?:one|a|each|every|three|the) (?:Standard Model )?generations?\b'],
}
FIELD_IMPORT = {'algebra': 's-alg', 'combinatorics': 's-alg', 'geometry': 's-geo', 'analysis': 's-geo',
                'topology': 's-cat', 'category': 's-cat', 'physics': 's-phy'}

def notions_for(texts, field, codes):
    """The SCHEME §1 notions a candidate's statement would use: the lexicon on its titles and statements, plus the
    import (ε = −1) of its field — a candidate is by definition a standard result not yet derived in the Atlas."""
    blob = '\n'.join(texts)
    blob += '\n' + re.sub(r'(^|[.!?]\s+)([A-Z])(?=[a-z])', lambda m: m.group(1) + m.group(2).lower(), blob, flags=re.M)
    got = {FIELD_IMPORT[field]}
    for code, pats in LEXICON.items():
        if any(re.search(p, blob) for p in pats):
            got.add(code)
    return [c for c in codes if c in got]

# ------------------------------------------------------------------------------------------------ 9. the blocks that are not items
def classify_other(o):
    """'intro' (skipped), 'summary' (refers to the items above; skipped and listed) or 'unparsed' (missing pieces written
    outside the item format; listed with their linked rows, not made candidates)."""
    head = o['head']
    if o['kind'] == 'missing':
        return 'unparsed', ['the file has no section C']
    if o['kind'] == 'preamble' or re.match(r'(?i)missing pieces\b', head):
        return 'intro', []
    bullets = [re.sub(r'^\s*[-*]\s+', '', l).strip() for l in o['lines'] if re.match(r'^\s*[-*]\s+', l)]
    if re.search(r'(?i)no separate entry needed', head + ' ' + o['text']):
        body = re.sub(r'^\(no separate entry needed\):\s*', '', o['text'])
        return 'unparsed', [clean(x).rstrip('.') for x in body.split(';') if x.strip()]
    if re.search(r'\bitems? \d|\(\d+\)', o['text']) and not re.search(r'(?i)without being stated', head):
        return 'summary', []
    return 'unparsed', [clean(b).rstrip(';.') for b in bullets] or [o['text']]

# ------------------------------------------------------------------------------------------------ 10. build
def natural(x):
    m = re.match(r'^T(\d+)$', x)
    if m:
        return (1, '', int(m.group(1)), '')
    m = re.match(r'^([A-Z]+)-(\d+)([a-z]?)$', x)
    return (0, m.group(1), int(m.group(2)), m.group(3))

def build():
    codes, _eps = scheme_codes()
    assert len(codes) == 29, 'SCHEME §1 should list 29 notions, found %d' % len(codes)
    unknown = sorted(set(LEXICON) - set(codes))
    assert not unknown, 'lexicon codes not in SCHEME: %s' % unknown
    rows_ok, thms_ok, questions, line_row, _rows = load_ids()

    items, others = [], []
    log = []          # (where, what, detail)
    for p in PERSONAS:
        its, oth = parse_outline(p)
        resolve_backrefs(its, log)
        items += its
        others += oth
    byref = {it['ref']: it for it in items}

    # per item: field, ids, check
    for it in items:
        if it['persona'].startswith('phys'):
            it['fieldVote'] = 'physics'
            it['fields'] = ['physics']
        else:
            fs = [f.strip().rstrip('.').lower() for f in it['field'].split(',') if f.strip()]
            bad = [f for f in fs if f not in FIELDS]
            for f in bad:
                log.append((it['ref'], 'field not in the list, ignored', f))
            fs = [f for f in fs if f in FIELDS]
            if not fs:
                log.append((it['ref'], 'no field given; physics assumed', it['field']))
                fs = ['physics']
            it['fieldVote'], it['fields'] = fs[0], fs
        ids_text = it['links']
        if re.search(r'\bthose rows\b', ids_text):
            ids_text += '\n' + it['statement']
            log.append((it['ref'], 'Links say "those rows": the rows named in the statement are linked', ''))
        idlog, it['lineRefs'], it['qids'] = [], [], []
        it['ids'] = extract_ids(ids_text, rows_ok, thms_ok, questions, line_row, idlog, it['lineRefs'], it['qids'])
        for what, detail in idlog:
            log.append((it['ref'], what, detail))
        v, note = checkability(it['check'])
        if v is None:
            log.append((it['ref'], 'no yes/partly/no verdict; "partly" assumed', it['check']))
            v = 'partly'
        it['checkable'], it['checkNote'] = v, note

    # groups
    group_of, groups = {}, []
    for key, members in MERGES:
        ok = []
        for ref, frag in members:
            it = byref.get(ref)
            if it is None or frag.lower() not in it['title'].lower():
                log.append((ref, 'merge "%s": item missing or title changed (expected "%s"); left unmerged' % (key, frag),
                            it['title'] if it else ''))
                continue
            if ref in group_of:
                log.append((ref, 'merge "%s": item already in "%s"; skipped' % (key, group_of[ref]), ''))
                continue
            ok.append(it)
        if len(ok) >= 2:
            for it in ok:
                group_of[it['ref']] = key
            groups.append((key, ok))
        elif ok:
            log.append((ok[0]['ref'], 'merge "%s": fewer than two items left; kept alone' % key, ''))
    for it in items:
        if it['ref'] not in group_of:
            groups.append((None, [it]))

    cands = []
    for key, members in groups:
        prim = members[0]
        votes = {}
        for m in members:
            votes[m['fieldVote']] = votes.get(m['fieldVote'], 0) + 1
        field = sorted(votes, key=lambda f: (-votes[f], FIELDS.index(f)))[0]
        ids, qids = [], []
        for m in members:
            ids += [x for x in m['ids'] if x not in ids]
            qids += [q for q in m['qids'] if q not in qids]
        for m in members:
            if re.search(r'\bI recall\b', m['statement']) and m['refs'] and not m['refs'][-1]['text'].endswith('(recalled)'):
                m['refs'][-1] = dict(m['refs'][-1], text=m['refs'][-1]['text'] + ' (recalled)')
        refs = merge_refs(members)
        vs = [m['checkable'] for m in members]
        checkable = vs[0] if len(set(vs)) == 1 else 'partly'
        note = prim['checkNote']
        if not note:
            other = next((m for m in members[1:] if m['checkNote']), None)
            if other:
                note = '%s: %s' % (other['persona'], other['checkNote'])
        if len(set(vs)) > 1:
            note = (note + ' ' if note else '') + '[proposers differ: %s]' % ', '.join('%s %s' % (m['persona'], m['checkable']) for m in members)
        proposed = [p for p in PERSONAS if any(m['persona'] == p for m in members)]
        texts = [t for m in members for t in (m['title'], m['statement'])]
        cands.append({
            '_key': key, '_members': members, '_rank': min(m['num'] for m in members),
            'title': prim['title'],
            'statement': short_statement(prim['statement']),
            'field': field,
            'source': '; '.join(refs) if refs else 'not given',
            'linksRows': sorted(ids, key=natural),
            'linksQuestions': sorted(qids, key=lambda q: (q[:2], int(q[2:]))),
            'checkable': checkable,
            'checkNote': note,
            'proposedBy': proposed,
            'notions': notions_for(texts, field, codes),
            'status': 'candidate',
        })
    cands.sort(key=lambda c: (-len(c['proposedBy']), FIELDS.index(c['field']), c['_rank'], c['title'].lower(), c['_members'][0]['ref']))
    for i, c in enumerate(cands, 1):
        c['id'] = 'CAND-%03d' % i
    log = list(dict.fromkeys(log))
    return items, others, cands, log, (rows_ok, thms_ok, questions, line_row)

ORDER = ['id', 'title', 'statement', 'field', 'source', 'linksRows', 'linksQuestions', 'checkable', 'checkNote', 'proposedBy', 'notions', 'status']

def write_json(cands):
    out = [{k: c[k] for k in ORDER} for c in cands]
    (ROOT / 'content' / 'candidates.json').write_text(json.dumps(out, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    return out

def write_md(items, others, cands, log, ctx):
    rows_ok, thms_ok, questions, line_row = ctx
    L = []
    n_items = len(items)
    n_merged = sum(len(c['_members']) for c in cands if len(c['_members']) > 1)
    n_groups = sum(1 for c in cands if len(c['_members']) > 1)
    per_file = {p: sum(1 for it in items if it['persona'] == p) for p in PERSONAS}
    L.append('# Candidates: the missing pieces of the ten outlines (T2.4)')
    L.append('')
    L.append('Generated by `python3 -I tools/migrate/candidates_from_outlines.py` from section C of `docs/labelling/outlines/{phys,math}_{A..E}.md`; '
             'do not edit by hand (change the outlines or the script and re-run). The table is `content/candidates.json` '
             '(%d records, status `candidate`); the Logbook shows it in its Candidates tab, and no page renders it. '
             'A candidate is what a persona wrote: a standard result the rows use without stating, or that would link rows the Atlas keeps apart; '
             'it becomes a row only when the author decides so and evidence is attached.' % len(cands))
    L.append('')
    L.append('**Parsed:** %d items (%s). **After merging:** %d candidates; %d items were the same standard result proposed by several personas '
             'and became %d candidates (proposers and linked rows united; the first item of a group gives the title and the statement). '
             'Statements are the outline\'s own words, cut after two sentences (marked …). Order: number of personas, then field '
             '(%s), then the item\'s rank in its outline.'
             % (n_items, ', '.join('%s %d' % (p, per_file[p]) for p in PERSONAS), len(cands), n_merged, n_groups, ' < '.join(FIELDS)))
    L.append('')
    n_line = sum(len(it['lineRefs']) for it in items)
    L.append('**Links:** the row and theorem ids of each item\'s Links field (with "LNC-006, 018/107" lists and "LNC-133…135" ranges expanded), '
             'checked against `content/rows.json` and `content/theorems.json`. %d references of the form "LNB-016 line 2" were resolved to the row that '
             'line became in the migration (LNB-016b; the rule of `rows_from_v15.mjs`). Ids that are not rows or theorems are listed at the end.' % n_line)
    L.append('')
    L.append('**Notions:** the SCHEME §1 codes that a lexicon (the table `LEXICON` in the script, built from the notion descriptions of §1) finds in the '
             'titles and statements of a candidate\'s items, plus the import notion of its field (`s-alg`, `s-geo`, `s-cat` or `s-phy`): a candidate is a '
             'standard result recalled from a source, not yet derived in the Atlas. A persona pass may refine them. '
             '**Checkable:** the outline\'s yes/partly/no; an item that names two verdicts for two parts is `partly`, and so is a merged candidate whose '
             'proposers disagree (the note then lists their verdicts).')
    L.append('')
    # by field
    L.append('## By field')
    L.append('')
    L.append('| field | candidates | proposed by ≥ 2 personas | checkable yes / partly / no |')
    L.append('|---|---:|---:|---|')
    for f in FIELDS:
        cs = [c for c in cands if c['field'] == f]
        if not cs:
            continue
        multi = sum(1 for c in cs if len(c['proposedBy']) > 1)
        ch = '%d / %d / %d' % tuple(sum(1 for c in cs if c['checkable'] == v) for v in CHECK_VALUES)
        L.append('| %s | %d | %d | %s |' % (f, len(cs), multi, ch))
    tot = '%d / %d / %d' % tuple(sum(1 for c in cands if c['checkable'] == v) for v in CHECK_VALUES)
    L.append('| **all** | **%d** | **%d** | %s |' % (len(cands), sum(1 for c in cands if len(c['proposedBy']) > 1), tot))
    L.append('')
    L.append('The field of a merged candidate is the majority of its proposers\' fields (a physicist\'s item counts as physics, a mathematician\'s '
             'as the first field it lists; a tie goes to the earlier field in the order above).')
    L.append('')
    # top twenty
    L.append('## The twenty most-proposed')
    L.append('')
    for c in cands[:20]:
        L.append('%d. **%s** %s — %d personas (%s); %s; check %s; rows: %s' % (
            int(c['id'][5:]), c['id'], c['title'], len(c['proposedBy']), ', '.join(c['proposedBy']), c['field'], c['checkable'],
            ', '.join(c['linksRows']) if c['linksRows'] else 'none'))
    L.append('')
    # merges
    L.append('## Merged items')
    L.append('')
    L.append('The judge\'s merges (the table `MERGES` in the script); the first item is the one whose title and statement the candidate shows.')
    L.append('')
    for c in cands:
        if len(c['_members']) > 1:
            L.append('- %s ← %s' % (c['id'], '; '.join('%s "%s"' % (m['ref'], m['title']) for m in c['_members'])))
    L.append('')
    # unparsed
    L.append('## Not parsed as candidates')
    L.append('')
    unparsed, summaries = [], []
    for o in others:
        kind, entries = classify_other(o)
        if kind == 'unparsed':
            unparsed.append((o, entries))
        elif kind == 'summary':
            summaries.append(o)
    if not unparsed:
        L.append('Every missing piece of the ten outlines was parsed.')
    for o, entries in unparsed:
        L.append('- `%s`, block "%s" (%d entries, no source/field/check in the item format):' % (o['file'], o['head'].rstrip(':.'), len(entries)))
        for e in entries:
            idlog = []
            ids = extract_ids(e, rows_ok, thms_ok, questions, line_row, idlog)
            spelled = all(re.search(r'(?<![\w-])%s(?![\w-])' % re.escape(x), e) for x in ids)
            L.append('  - %s%s' % (e, (' — rows: ' + ', '.join(ids)) if ids and not spelled else ''))
    if summaries:
        L.append('- Summary blocks that only point back to the items (skipped): %s.' % '; '.join('`%s` "%s"' % (o['file'], o['head'].rstrip(':.')) for o in summaries))
    L.append('')
    # dropped links and other log entries
    L.append('## Links dropped and other notes')
    L.append('')
    cand_of = {m['ref']: c['id'] for c in cands for m in c['_members']}
    qs = {}
    rest = []
    for ref, what, detail in log:
        if what.startswith('question id'):
            qs.setdefault(detail, []).append(cand_of.get(ref, ref))
        else:
            rest.append((ref, what, detail))
    if qs:
        L.append('- Question ids named in Links (they exist in `questions.json` but are not rows: `linksRows` leaves them out, `linksQuestions` keeps them): ' +
                 '; '.join('%s (%s)' % (q, ', '.join(sorted(set(v)))) for q, v in sorted(qs.items(), key=lambda kv: (kv[0][:2], int(re.sub(r'\D', '', kv[0]))))) + '.')
    for ref, what, detail in rest:
        L.append('- %s (%s): %s%s' % (ref, cand_of.get(ref, '—'), what, (' — ' + detail) if detail else ''))
    if not qs and not rest:
        L.append('None.')
    L.append('')
    (ROOT / 'docs' / 'labelling' / 'CANDIDATES.md').write_text('\n'.join(L), encoding='utf-8')

def main():
    items, others, cands, log, ctx = build()
    if '--dump' in sys.argv:
        for c in cands:
            print('%s %-55.55s | %-13s | %s | %s | %s' % (c['_key'] or '-', c['title'], c['field'], ','.join(c['proposedBy']), c['checkable'], ' '.join(c['notions'])))
        return
    write_json(cands)
    write_md(items, others, cands, log, ctx)
    byf = {f: sum(1 for c in cands if c['field'] == f) for f in FIELDS}
    print('items parsed: %d from %d outlines; candidates: %d (%d merged groups)' % (
        len(items), len(PERSONAS), len(cands), sum(1 for c in cands if len(c['_members']) > 1)))
    print('by field: ' + ', '.join('%s %d' % (f, byf[f]) for f in FIELDS))
    print('wrote content/candidates.json and docs/labelling/CANDIDATES.md; %d log entries' % len(log))

if __name__ == '__main__':
    main()
