#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/build_extra.mjs — the figures chunk (BUILD_CONTRACTS interface 34, D47), called by build.sh before the core bundle of app.js:
//   <out>/figures-extra.js                   src/figures/extra.entry.js (the figures under src/figures/physics/ and src/figures/explore/) bundled by
//                                            esbuild's JS API as a classic script (IIFE: it must load from file://, where module scripts are refused),
//                                            minified like app.js, with no source map (A21); it registers its figures in window.__ONE_RULE_FIGURES_EXTRA__ and dispatches
//                                            "one-rule:figures"; an error while it runs is kept in window.__ONE_RULE_FIGURES_EXTRA_ERROR__ for the one
//                                            warning of src/app/lazyFigures.js, never thrown into the console
//   <out>/content/figures_extra_ids.json     the manifest { chunk, ids, bridged, carried }: the ids the chunk registers (build.sh bakes them into app.js as
//                                            __ONE_RULE_EXTRA_IDS__), the bridged modules it reads, the modules outside the two folders it carries
// One React, one store: a plugin resolves react, react/jsx-runtime and react-dom, and every module of src/ outside src/figures/ that a module of the
// chunk imports, to a shim that reads window.__ONE_RULE_BRIDGE__ (filled by app.js, src/app/lazyFigures.js). The bridged modules are the keys of
// bridgeModules() in src/app/lazyFigures.js; a module of the app the list does not name fails the build. A shim of an app module exports exactly the
// names of the real module (esbuild's metafile of that file), so an import of a name the module lacks fails here, and the shim checks at run time that
// the bridge holds every name (app.js and figures-extra.js of different builds are named, not run). The list may also name pure modules app.js carries
// whole (the kernel, the stored blocks, the figure kit …): read from app.js, not copied. Every other module is carried: the code app.js lacks, and copies of
// pure modules app.js carries in part (engines; memo caches at most — tests/chunk.test.mjs scans them). Stylesheets are empty here, because build.sh keeps
// every figure's stylesheet in app.css (the stylesheet of the full bundle, in its import order).
// Usage: node tools/build_extra.mjs [outDir=dist]        (exit 1 with the reason when the chunk cannot be built)
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const NM = process.env.NODE_MODULES || '/opt/npm-tools/node_modules';
const requireNM = createRequire(path.join(NM, 'noop.js'));
const esbuild = requireNM('esbuild');

export const ENTRY = 'src/figures/extra.entry.js';
export const LAZY = 'src/app/lazyFigures.js';
export const CHUNK = 'figures-extra.js';
export const MANIFEST = 'content/figures_extra_ids.json';
/** the folders whose figures are extra (interface 34) */
export const EXTRA_DIRS = ['src/figures/physics/', 'src/figures/explore/'];
/** React through the bridge: the specifier → the key of window.__ONE_RULE_BRIDGE__ */
export const REACT_BRIDGE = { react: 'React', 'react/jsx-runtime': 'jsxRuntime', 'react-dom': 'ReactDOM' };
const NS = 'one-rule-bridge';
const RUNTIME = 'runtime';
const rel = f => path.relative(ROOT, f).split(path.sep).join('/');
/** a module of the app: under src/ but not under src/figures/ — such a module reaches the chunk only through the bridge */
export const isAppModule = r => r.startsWith('src/') && !r.startsWith('src/figures/');

/** the keys of bridgeModules() in src/app/lazyFigures.js, each checked against the namespace import it names */
export function bridgeKeys() {
  const file = path.join(ROOT, LAZY);
  const src = fs.readFileSync(file, 'utf8');
  const block = /export const bridgeModules\s*=\s*\(\)\s*=>\s*\(\{([\s\S]*?)\}\);/.exec(src);
  if (!block) throw new Error(`${LAZY} has no "export const bridgeModules = () => ({ … });"`);
  const imports = new Map([...src.matchAll(/import \* as ([A-Za-z_$][\w$]*) from ['"]([^'"]+)['"]/g)].map(m => [m[1], m[2]]));
  const keys = [];
  for (const [, key, ident] of block[1].matchAll(/['"]([^'"]+)['"]\s*:\s*([A-Za-z_$][\w$]*)/g)) {
    const spec = imports.get(ident);
    if (!spec) throw new Error(`${LAZY}: the bridge entry ${key} names ${ident}, which is not imported there as a namespace (import * as ${ident} from …)`);
    const target = rel(path.resolve(path.dirname(file), spec));
    if (target !== key) throw new Error(`${LAZY}: the bridge entry ${key} names ${ident}, which is imported from ${target}`);
    if (!fs.existsSync(path.join(ROOT, key))) throw new Error(`${LAZY}: the bridge entry ${key} is not a file of the repository`);
    if (EXTRA_DIRS.some(d => key.startsWith(d)) || key === ENTRY) throw new Error(`${LAZY}: the bridge entry ${key} is a module of the chunk (app.js would carry it)`);
    keys.push(key);
  }
  if (!keys.length) throw new Error(`${LAZY}: bridgeModules() names no module`);
  return keys;
}

/** the export names of a module (esbuild's metafile of the file alone); a module that re-exports with export * cannot be bridged */
async function exportsOf(key) {
  const file = path.join(ROOT, key);
  const src = fs.readFileSync(file, 'utf8');
  if (/^\s*export\s*\*/m.test(src)) throw new Error(`${key} re-exports with "export *": list its names, or it cannot be bridged`);
  const r = await esbuild.build({ entryPoints: [file], absWorkingDir: ROOT, bundle: false, write: false, metafile: true, format: 'esm', outdir: 'out',
    loader: { '.js': 'jsx' }, jsx: 'automatic', logLevel: 'silent' });
  return Object.values(r.metafile.outputs)[0].exports || [];
}

const IDENT = /^[A-Za-z_$][\w$]*$/;
const runtimeSource = () => [
  'const B = typeof window !== "undefined" ? window.__ONE_RULE_BRIDGE__ : undefined;',
  'const fail = m => { throw new Error("figures-extra.js: " + m); };',
  'export function bridgedReact(key) {',
  '  if (!B) fail("window.__ONE_RULE_BRIDGE__ is missing (app.js fills it before it inserts the chunk)");',
  '  if (!B[key]) fail("the bridge of app.js has no " + key);',
  '  return B[key];',
  '}',
  'export function bridged(key, names) {',
  '  if (!B) fail("window.__ONE_RULE_BRIDGE__ is missing (app.js fills it before it inserts the chunk)");',
  '  const m = B.modules && B.modules[key];',
  '  if (!m) fail("the bridge of app.js has no module " + key + " (app.js and figures-extra.js come from different builds)");',
  '  const missing = names.filter(n => !(n in m));',
  '  if (missing.length) fail("the bridge\'s " + key + " lacks " + missing.join(", ") + " (app.js and figures-extra.js come from different builds)");',
  '  return m;',
  '}',
].join('\n');

/** the esbuild plugin: React and the bridged app modules → shims of the bridge; any other module of the app → an error naming it */
function bridgePlugin(keys, used) {
  const bridged = new Set(keys);
  const exportCache = new Map();
  const probe = abs => [abs, abs + '.js', abs + '.jsx', abs + '.mjs', path.join(abs, 'index.js'), path.join(abs, 'index.jsx')].find(c => fs.existsSync(c) && fs.statSync(c).isFile()) || null;
  return {
    name: NS,
    setup(build) {
      build.onResolve({ filter: /^react(-dom)?(\/.*)?$/ }, args => {
        if (!(args.path in REACT_BRIDGE)) return { errors: [{ text: `${rel(args.importer)} imports "${args.path}": the extra figures may import only ${Object.keys(REACT_BRIDGE).join(', ')} (through the bridge)` }] };
        used.react.add(args.path);
        return { path: args.path, namespace: NS, pluginData: { react: REACT_BRIDGE[args.path] } };
      });
      build.onResolve({ filter: /^\./ }, args => {
        if (args.namespace === NS) return { path: RUNTIME, namespace: NS, pluginData: { runtime: true } };
        const target = probe(path.resolve(args.resolveDir, args.path));
        if (!target) return undefined;
        const r = rel(target);
        if (bridged.has(r)) { used.modules.add(r); return { path: r, namespace: NS, pluginData: { module: r } }; }
        if (isAppModule(r)) return { errors: [{ text: `${rel(args.importer)} imports ${r}, a module of the app the bridge does not carry: add it to bridgeModules() in ${LAZY} (or keep the code under src/figures/)` }] };
        return undefined;
      });
      build.onLoad({ filter: /.*/, namespace: NS }, async args => {
        const d = args.pluginData || {};
        if (d.runtime) return { contents: runtimeSource(), loader: 'js', resolveDir: ROOT };
        // CommonJS, as the real React is: a default import is the module object, a named import a property of it
        if (d.react) return { contents: `module.exports = require("./${RUNTIME}").bridgedReact(${JSON.stringify(d.react)});\n`, loader: 'js', resolveDir: ROOT };
        if (!exportCache.has(d.module)) exportCache.set(d.module, await exportsOf(d.module));
        const names = exportCache.get(d.module);
        const odd = names.filter(n => n !== 'default' && !IDENT.test(n));
        if (odd.length) return { errors: [{ text: `${d.module} exports names the bridge cannot write: ${odd.join(', ')}` }] };
        const lines = [`import { bridged } from "./${RUNTIME}";`, `const m = bridged(${JSON.stringify(d.module)}, ${JSON.stringify(names)});`];
        for (const n of names) lines.push(n === 'default' ? 'export default m.default;' : `export const ${n} = m.${n};`);
        return { contents: lines.join('\n') + '\n', loader: 'js', resolveDir: ROOT };
      });
    },
  };
}

/** the ids the entry registers: the entry bundled for node (React from the offline modules, stylesheets empty) and its EXTRA_FIGURES read */
async function registeredIds() {
  const r = await esbuild.build({ entryPoints: [path.join(ROOT, ENTRY)], absWorkingDir: ROOT, bundle: true, write: false, format: 'cjs', platform: 'node', target: 'node20',
    jsx: 'automatic', loader: { '.js': 'jsx', '.css': 'empty' }, external: ['react', 'react-dom', 'react/jsx-runtime'], nodePaths: [NM],
    define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'silent' });
  const mod = { exports: {} };
  new Function('module', 'exports', 'require', r.outputFiles[0].text)(mod, mod.exports, requireNM);
  const reg = mod.exports.EXTRA_FIGURES;
  if (!reg || typeof reg !== 'object') throw new Error(`${ENTRY} exports no EXTRA_FIGURES`);
  const bad = Object.entries(reg).filter(([, c]) => !(typeof c === 'function' || (c && typeof c === 'object' && c.$$typeof))).map(([id]) => id);
  if (bad.length) throw new Error(`${ENTRY}: not a component: ${bad.join(', ')}`);
  return Object.keys(reg).sort();
}

/**
 * Build the chunk. Options: { outDir = 'dist', write = true, metafile = false }.
 * Returns { ids, bridged, react, carried, bytes, gzip, code, metafile } (code as a string when write is false).
 */
export async function buildExtra({ outDir = 'dist', write = true, metafile = false } = {}) {
  const out = path.resolve(ROOT, outDir);
  const keys = bridgeKeys();
  const used = { modules: new Set(), react: new Set() };
  const outfile = path.join(out, CHUNK);
  const r = await esbuild.build({
    entryPoints: [path.join(ROOT, ENTRY)], absWorkingDir: ROOT, outfile, bundle: true, write: false, metafile: true,
    format: 'iife', platform: 'browser', target: 'es2020', jsx: 'automatic', loader: { '.js': 'jsx', '.css': 'empty' }, nodePaths: [NM],
    define: { 'process.env.NODE_ENV': '"production"' }, minify: true, sourcemap: false, legalComments: 'none', logLevel: 'silent',
    // the chunk never throws into the page: an error while it runs is kept for the warning of src/app/lazyFigures.js
    banner: { js: 'try{' },
    footer: { js: '}catch(e){window.__ONE_RULE_FIGURES_EXTRA_ERROR__=String(e&&e.message||e)}' },
    plugins: [bridgePlugin(keys, used)],
  });
  const code = r.outputFiles.find(f => f.path === outfile).text;
  const inputs = Object.keys(r.metafile.inputs);
  // the modules outside the two folders the chunk carries (its stylesheets are empty, its entry is its own)
  const carried = inputs.filter(f => !f.startsWith(NS + ':') && !EXTRA_DIRS.some(d => f.startsWith(d)) && f !== ENTRY && !f.endsWith('.css')).sort();
  const leaked = carried.filter(f => isAppModule(f) || /(^|\/)node_modules\/react(-dom)?\//.test(f));
  if (leaked.length) throw new Error(`the chunk carries a copy of ${leaked.join(', ')} (they must come through the bridge)`);
  const ids = await registeredIds();
  const manifest = { chunk: CHUNK, ids, bridged: [...used.modules].sort(), react: [...used.react].sort(), carried };
  if (write) {
    fs.mkdirSync(path.join(out, 'content'), { recursive: true });
    fs.writeFileSync(outfile, code);
    fs.writeFileSync(path.join(out, MANIFEST), JSON.stringify(manifest, null, 1) + '\n');
  }
  return { ...manifest, bytes: Buffer.byteLength(code), gzip: zlib.gzipSync(code).length, code: write ? null : code, metafile: metafile ? r.metafile : null };
}

// ---- command line
if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  const outDir = process.argv[2] || 'dist';
  try {
    const t0 = Date.now();
    const res = await buildExtra({ outDir });
    const kb = n => (n / 1024).toFixed(1) + ' kB';
    console.log(`build_extra: ${CHUNK} ${kb(res.bytes)} (${kb(res.gzip)} gzipped) — ${res.ids.length} figures; ${res.react.join(', ')} and ${res.bridged.length} modules of app.js through the bridge; ${res.carried.length} modules outside ${EXTRA_DIRS.join(' and ')} carried; ${Date.now() - t0} ms`);
  } catch (e) {
    const errs = e && Array.isArray(e.errors) && e.errors.length ? e.errors.map(x => `${x.location ? `${x.location.file}:${x.location.line}: ` : ''}${x.text}`).join('\n  ') : (e && e.message) || String(e);
    console.error(`build_extra: the figures chunk could not be built:\n  ${errs}`);
    process.exit(1);
  }
}
