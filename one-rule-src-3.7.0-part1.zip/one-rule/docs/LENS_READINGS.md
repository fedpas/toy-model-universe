<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Lens readings

A **reading** of a row in a lens is the lens's term for an element the row states (BUILD_CONTRACTS, interface 7). It shows under the statement, in small muted type, when that lens is active, and never in place of the statement. The readings live in `content/lens_readings.json`; `node tools/migrate/lens_readings.mjs` writes that file from `rows.json`, `texts.json`, `lenses.json`, `readings.json` and `checks.json` (for the check ids each script lists), and from nothing else. No record is written by hand: after a change to one of those tables, run the script; the same tables always give the same file.

## A record

`{ lens, row, atlas, term, match, evidence, via, source }`. `atlas`, `term` and `match` are copied from the dictionary entry (`atlas`, `term`, `match`) or from the reading (`atlas_element`, `field_term`, `grade_or_status`). `via` names the link that attached it: `evidence`, `text` or `row`. `evidence` lists the check ids of that link: the ids the entry shares with the row when `via` is `evidence`; when `via` is `text` or `row`, the entry's own check ids that some row cites (often none). The file is sorted by (lens, row, atlas).

## How a reading reaches a row

Two sources and three links, nothing else.

1. **The dictionaries of the lens registry** (`lenses.json`: 1,161 entries in 35 lenses). An entry is attached
   - *via evidence* to every row whose `evidence[].check` shares a check id with the entry's `evidence` list (ids compared trimmed; a script path or `x.py` counts as its base name `x`), by the rule of single checks and whole scripts below;
   - *via text* to every row whose research text contains the entry's atlas phrase (below);
   - *via the row id* to every row the entry names: a row id written out in its atlas phrase, or listed in its `rows` field.
2. **The specialist readings** (`readings.json`: the 982 entries of the specialist analyses) whose `field` has a lens in the table `FIELD_LENS` at the top of the script. A reading is attached
   - *via evidence* through the check ids it names in its note and in its atlas element, by the rule of single checks and whole scripts below:
     - single checks written out, with the author's shorthand expanded (`bd·mja·3, 19, 21` gives three ids; likewise `core·B7–B9`, `core·B10b/c`, `cat·K1a–e`, `bd·mjg·1, ·7`), a group name standing for its members (`fibre·G5` for `fibre·G5a`, `fibre·G5b` …), and a check named after its script (`` `baez_check.py` T4 ok `` gives `baez·T4`, through the ids `checks.json` lists for that script);
     - whole scripts (`gtg_check`, `check_T4.py`) only when written in the note's evidence clause (`evidence: …` or `checks: …`, up to `; flag`), and only when no single check of the reading links any row: the most specific shared check wins. A script mentioned in running prose ("a check of that identification is not in baez_check.py") is not evidence.
   - *via text*, as for the dictionary entries;
   - *via the row id* to every row whose id is written out in its note or in its atlas element.

**Single checks and whole scripts.** A reading is shown beside a statement only where the two share the check that backs them. A single check — an id with `·` (`core·B14`, `bd·geo·12`), or an id that `checks.json` lists among a script's checks (`aty.A1`, `fc.CAR`) — links every row that cites it. A whole script — any other id (`check_T4`, `equations_selfcheck`, `gtg_check`) — links only the rows whose own evidence is that whole script: a row that cites it whole and none of its single checks. A row that cites single checks of that script (ATL-008 cites `geo_lorentz` and its check `bd·geo·12`) is linked by the single checks the entry names, or not at all. The script of a single check is the `script` of its evidence entry and the script `checks.json` lists it under; a whole id goes by its own name and by the `script` of the entries that cite it (`researchers_check_T6` ← `check_T6.py`).

**The atlas phrase.** The entry's atlas element with its `$…$` formulas, backticks and bold marks taken out, white space collapsed and the punctuation at its two ends trimmed. It must keep at least 12 characters and occur in the row's research text (research level, no lens; formulas and markup taken out the same way) verbatim up to case and as whole words: "generator square" does not match "generator squares".

**The row id.** A reading that names a row by its id is about that row. A row is named by its id written out in full as a whole word, the rule behind `rows.readingRefs`: "(LAB-004)" names LAB-004, "EQN-001/007" names EQN-001 only, "LNS-013d" names LNS-013d and not LNS-013. Only the rows of `rows.json` that are not narration count. The link by the row id is made only where no link by evidence or by text joins the entry and the row.

**One record per (lens, row, term).** When several links give the same term to the same row in the same lens, the record kept is a link by evidence before one by text, one by text before one by the row id, and the registry's entry before the reading; it carries the check ids of all the links of its kind.

## Counts

| lens | records | rows | via evidence | via text | via the row id | from the dictionary | from the readings |
|---|---|---|---|---|---|---|---|
| Algebra (`alg`) | 444 | 263 | 382 | 27 | 35 | 260 | 184 |
| Geometry (`geo`) | 509 | 248 | 469 | 9 | 31 | 185 | 324 |
| Category theory (`cat`) | 328 | 140 | 308 | 10 | 10 | 140 | 188 |
| String theory (`str`) | 367 | 225 | 357 | 2 | 8 | 98 | 269 |
| Solid state (`sol`) | 325 | 190 | 277 | 11 | 37 | 161 | 164 |
| Field theory (`fld`) | 278 | 174 | 232 | 18 | 28 | 206 | 72 |
| Furey (`furey`) | 33 | 28 | 28 | 0 | 5 | 33 | 0 |
| Baez (`baez`) | 46 | 35 | 46 | 0 | 0 | 0 | 46 |
| Schuller (`schuller`) | 16 | 15 | 16 | 0 | 0 | 4 | 12 |
| Majkić (`majkic`) | 221 | 45 | 211 | 10 | 0 | 10 | 211 |
| Pumplün (`pumplun`) | 1 | 1 | 0 | 1 | 0 | 1 | 0 |
| Atiyah (`atiyah`) | 308 | 198 | 264 | 38 | 6 | 308 | 0 |
| **all** | **2,876** | **725** | **2,590** | **126** | **160** | **1,406** | **1,470** |

The 725 rows read in some lens sit on 35 pages. Of the links by evidence, 2,167 go through single checks and 423 through a whole script alone, by 19 scripts (`maxwell_selfcheck` 66, `check_T4` 58, `gtg_check` 57, `check_T18` 39, `aty_cone_defects` 28, `equations_selfcheck` and `spring_selfcheck` 27 each …); every row they reach cites its script whole and none of its single checks, so the rule of single checks and whole scripts keeps them all: on step 2 the geometry reading "Λ²V ≅ 𝔰𝔬(V)" stands under the statements that rest on `equations_selfcheck` as a whole, as the reading does. The link by the row id gives 160 records (74 from the readings, 86 from the dictionaries) on 83 rows, 24 of which are read through it alone. Each of the 235 pairs of a mapped reading and a row it names (188 readings) carries a record of its term: 74 by this link from the reading, 59 by this link from the dictionary entry of the same term, 102 by evidence or by text. 459 of the 1,161 dictionary entries and 467 of the 889 mapped readings reach at least one row. A row has at most 15 readings in one lens (LAB-018 in `alg`); one term reaches at most 58 rows (the string-theory reading of the type table, through `check_T4`). The other 23 lenses have no reading: `top`, `comb`, the seven shapes, `hestenes`, `pga`, `roelfs`, `tian`, `hbhl`, the four label lenses and the five conventions. The same counts are in `content/MIGRATION_COUNTS.json` under `lensReadings` (`viaRow` for the third link).

## Fields and lenses

| field of `readings.json` | readings | lens |
|---|---|---|
| mathematics: algebra | 102 | `alg` |
| mathematics: geometry and topology | 93 | `geo` |
| mathematics: category theory | 87 | `cat` |
| category lens (KTH notes, Tenfold Way, Tian, Majkic v2) | 81 | `cat` |
| physics: string theory | 68 | `str` |
| physics: solid state | 82 | `sol` |
| physics: field theory | 46 | `fld` |
| Schuller lectures (mathematics for physics) | 113 | `schuller` |
| Baez: octonions, Jordan algebras, Standard Model | 70 | `baez` |
| Hestenes / Lasenby-Doran-Gull (…) | 23 | `hestenes` |
| Furey (…) | 20 | `furey` |
| Pumplun (…) | 14 | `pumplun` |
| Majkic paper (merged, four lanes); algebra, category theory, geometry, physics (Majkic reading) | 23 + 14 + 19 + 18 + 16 | `majkic` |
| physics: theoretical physics (all) | 48 | left out |
| mathematics: whole mathematics | 36 | left out |
| merge agreement (physics x mathematics) | 9 | left out |

The three fields left out have no obvious counterpart among the lenses; the script prints them. The registry files the first under `fld` and the second under `alg`, but there their entries carry no evidence ids, so they reach no row.

## Where readings show

- **Under a statement**, when a lens is active: `In the <lens> lens: <term> <match>`, the first two readings (links by evidence first, then by text, then by the row id; the registry's entries and exact matches first) and `+n`, a button that opens the rest. At learner level only the terms without a formula (no `$`, `\`, `^`, `_` or `=`). With no lens active nothing is added to the statement.
- **The lens room** (`/lenses/<key>`): the number of rows read in the lens and of their pages, "Pages with readings", and "Rows read in this lens" (the first 12, each row id linking to its place, with its first term; "Show all").
- **The lens index**: "N rows read" on each card. **The Logbook**: "Readings by lens" in a row's drawer (lens → term, match, and how the reading is joined: "via" the shared check ids, "via the phrase" and the atlas phrase, or "names this row").
- **Tests**: `tests/coverage.test.mjs` checks the table (known rows, no empty term, sorted, one record per lens, row and term, and every link holds: by evidence, check ids of the row's evidence, a whole script only where the row cites it whole and none of its single checks; by text, the atlas phrase in the row's research text; by the row id, an entry of the record's source with its atlas, term and match whose note and atlas element, or atlas phrase and `rows` field, name the row, and no atlas phrase in the row's research text) and every reading line rendered against it, with every lens on every page and with `cat`, `geo` and the lens with most readings after them on every route; with no lens, no line may render.

## A new lens

A lens gets readings when its dictionary entries carry `evidence` (check ids that rows cite in their evidence), atlas phrases that the research texts say word for word, or the ids of the rows they read (in the atlas phrase or the `rows` field). For a new analysis in `readings.json`, name the checks in the note's evidence clause as the analyses do (`evidence: core·B3, bd·cat·12; flag: …`) and add one line for its `field` to `FIELD_LENS`; a row id written in a reading's note or atlas element attaches it to that row where no check and no phrase does. Then run `node tools/migrate/lens_readings.mjs`; the coverage test fails on any record whose link does not hold.

**The Atiyah lens** (`atiyah`, `docs/round8/ATIYAH.md`) is a lens built this way from scratch: every dictionary entry names either check ids that rows cite (the five scripts of the Atiyah readings, cited by the ATY rows and by CAND-124, GOS-005 and LNS-013d; or an existing check such as `sm16·D1` or `bd·str·5`) or an atlas phrase taken verbatim from the research text of the row it reads, so that the generator attaches it there and nowhere else by hand. Its 109 entries give 309 records on 199 rows: 264 by evidence, 40 by the phrase, and 5 by the row that the entry's `rows` field names where neither joins them (ATY-024, ATY-028, CAND-089, CAND-140, LNS-017e).

## Decisions for the author

The whole-script links and the link by the row id are settled (`docs/DECISIONS.md` A1, A2) as the rules above: a whole script links only the rows whose own evidence it is, and a reading that names a row by its id is attached to it.

1. **Topology, Furey, Hestenes.** The analysis "geometry and topology" maps to `geo` only, as the registry does, so `top` has no reading. The Furey and Hestenes readings of `readings.json` name checks of their reports (`B1`, `H1`) that no row cites, and no row id, so they reach no row; `furey` has the readings of its dictionary entries of passes 9a to 12a, `hestenes` none.
2. **The two "(all)" fields.** Map "theoretical physics (all)" to `fld` and "whole mathematics" to `alg` as the registry does (one line each in `FIELD_LENS`), or keep them out.
