<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Round 18, pass 14a: flat twistor theory on the labels, read with *Twistor theory at fifty*

The owner set the twistor programme next and attached the review of M. Atiyah, M. Dunajski and L. J. Mason, *Twistor theory at fifty: from contour integrals to twistor strings* (Proc. R. Soc. A 473, 2017). This pass reads it with the Atlas's method — the objective and the predictions first (`docs/round18/pass14a/BEFORE.md`), then the review in full — computes the part of flat twistor theory the Atlas reaches, and plans the next passes.

One script under `checks/selfcheck/proofs/` (`twistor_flat.py`; 10 check lines, bit 1, bit==std 2, ctl 3, std 4, 0 fail, a few seconds alone; seven fault runs, each ending with FAIL lines and exit 1: CELL with 2 failing lines, NOI 2, NULLW 1, DEG 1, EUC 1, SDLAX 1, NAHM 1; `logs/twistor_flat.log` and `logs/twistor_flat.faults.log` beside it). Run from `checks/` as `python3 -I -B selfcheck/proofs/twistor_flat.py`, it ends with `twistor_flat: 10 checks, 0 fail`; from its own folder and on a second run the check lines are identical. The standard library only. The pass's working records are `docs/round18/pass14a/BEFORE.md`, `RESULT.md` (what ran, and in §3 the lemmas) and `apply.json` (the data), applied by `docs/round18/apply_pass14a.py`. An independent audit recomputed the pass with its own code (§4).

## 1. What changes in the tables

- **ATY-066, twistor space from the labels** (tf.SPIN). In the cell (4,2) the volume element Ω squares to −1 and is central in the even part; the left ideal through P = (1 + e₁e₅)(1 + e₂e₆)/4 is ℂ⁴ with J = Ω, the simple module of the even part (M₄(ℂ)); the 15 bivectors act faithfully, trace-free, keeping one Hermitian form, of signature (2, 2): so(4,2) ≅ su(2,2) from the labels. Λ² of the ideal is the vector of so(4,2), the quadratic form of the generators carried to a non-zero multiple of the wedge pairing: the lines of PT are the points of the Klein quadric.
- **ATY-067, the incidence relation** (tf.INC). The lines of two points meet exactly when their separation is null (computed both ways); a twistor meets a real point exactly when it is null, then along a light ray; the Robinson congruence of a non-null twistor has exactly one ray through every real point.
- **ATY-068, Penrose's integral formulae** (tf.PEN). Exact residues: the elementary state 1/(det[[A₀, A₁], [B₀, B₁]]·det(X − X₀)); the wave and zero-rest-mass equations up to spin 2; the field independent of the chart exactly at homogeneity −n − 2; the spin-1 field a self-dual Maxwell field, the kernel's star equal to the ε tensor's.
- **ATY-069, the Lax pairs** (tf.LAX). With the review's reality conditions and the Atlas's choice z = x₁ + ix₂, w = x₃ + ix₄, the integrability of the review's (5.3) is the anti-self-duality of F for its orientation; CAND-124's instanton is self-dual there, and its mirror image is an instanton in the review's sense, which takes instantons anti-self-dual; Nahm's equations as Ḃ = [B, C].
- **Derivations**: ATY-066 from ATL-014, ATY-067 from ATY-066, ATY-068 from ATY-067, ATY-069 from CAND-124.
- **Placement**: ATY-066 and ATY-067 on steps/projective · summary at 20 and 21, ATY-068 on light · summary at 45, ATY-069 on steps/ym · summary at 17, role detail; kind computation; `since: "v3.6"`.
- **The lenses**: geo (two entries, 81 → 83), fld (two, 88 → 90), str (one, 64 → 65). Attached by their check ids.

## 2. What came out against the prediction

Of the nine predictions of BEFORE.md (RESULT.md §1), the first four came out as predicted, two of them in part: twistor space as the spinor module of the conformal cell; the Klein correspondence (the complex incidence; the split-signature real case of Cl(3,3) not computed); the elementary state as a residue; spin from homogeneity (the primed, self-dual side only). The fifth was partly missed: it named CAND-124's instanton as the simplest bundle, and that instanton has the opposite duality to the review's instantons; it led to the Lax pair rather than to the bundle. The seventh, silence on integrable systems, did not hold: Nahm's Lax pair is a finite matrix identity. The ninth, silence on the Newtonian limit, was not tested: the Gibbons–Hawking family of the review's §8 is a metric the gravity engine could take. The sixth and the eighth were not computed. Two points were not among the predictions, and the review has both:

- *The equations are free, the homogeneity is not.* On one chart every integrand gives solutions of the wave and zero-rest-mass equations, as the review's (1.1) holds for any f; at homogeneity d the two charts of a line differ by the factor λ₀^{−(n+d+2)} (the review's footnote 2 on p. 6 gives the factor for 𝒪(k)), so the homogeneity −n − 2 is what makes the field independent of the chart. The control of the wrong homogeneity is therefore the two charts, not the equation.
- *The orientation.* The review's instantons are anti-self-dual (§5(c)); its (5.1) and Lax pair select the anti-self-dual forms of vol = dw ∧ dw̃ ∧ dz ∧ dz̃, which is 4 dx₁dx₂dx₃dx₄ for the Atlas's choice of z and w. The Atlas's BPST instanton (CAND-124) is self-dual for that orientation; its mirror image is an instanton in the review's sense.

## 3. Sources

| source | how it is used | read |
|---|---|---|
| M. Atiyah, M. Dunajski, L. J. Mason, *Twistor theory at fifty: from contour integrals to twistor strings*, Proc. R. Soc. A 473 (2017) 20170530 | §1 (1.1); §2 (2.1)–(2.5), PN, the Robinson congruence, the cohomology and the elementary state, footnote 2; §5 (5.1), (5.3), §5(c); §6 Nahm's equations; §3, §4, §7, §8 read for the plan | in full (attached by the owner), after BEFORE.md |
| Cauchy's residue theorem; the Plücker relation (a bivector of ℂ⁴ is decomposable exactly when b ∧ b = 0); the Klein quadric as complexified compactified Minkowski space; the sign of the helicity, a convention | the contour integrals as residues; the lines of PT as null vectors | recalled |
| ATL-014, CAND-025, ATY-030, CAND-124 (with `gravity/ym_solutions.py`), CAND-139 | the conformal cell, su(2,2) by explicit matrices, the Klein correspondence over 𝔽₂, the instanton and its 't Hooft symbols, the conformal invariance of the massless equations (cited) | the Atlas's rows |

## 4. How it was checked

An agent that had not seen the pass written read BEFORE.md, RESULT.md, the script and its logs against the review, and recomputed with its own code: Cl(4,2) from explicit real matrices and on the eigenspace of Ω, with the module, its forms, the intertwiner and the dependence of the Klein constant on the normalisation; the incidence both ways and the Robinson congruence as real lines; Penrose's fields as identities in X, numerical contour integrals on both charts and the factor between them; the duality conventions; the review's orientation under the choices of z and w and the sign of its Nahm equations; Nahm's Lax equation in the free algebra. It found the mathematics right, the script and its seven faults reproduced byte for byte, and no blocking issue; its points on the wording are taken in RESULT.md (§11), the script and the rows.

## 5. Defects and open points

- **Flat space only**: the nonlinear graviton, local twistors, the Ward correspondence for bundles beyond the Lax pair, the instantons from bundles, the other reductions, the amplitudes and strings, the Newtonian limit — read, not computed.
- **The unprimed fields and the cohomology**: the unprimed fields (homogeneity n − 2, derivatives in ω; for n = 2 the anti-self-dual Maxwell fields) and the classes themselves, not representatives, are not computed.
- **Not computed either**: the twisting of the Robinson congruence; the split-signature real twistors (Cl(3,3)).
- **The coordinates of the Lax pair** z = x₁ + ix₂, w = x₃ + ix₄ are the Atlas's choice; the review fixes only the reality conditions.
- **Random points**: the incidence and the formulae are computed at random rational points; the lemmas of RESULT.md §3 carry them to every point.
- **No learner words.**

## 6. What the next passes would be

14b, curved twistors (§3): anti-self-dual Weyl curvature of the Gibbons–Hawking and Eguchi–Hanson metrics and their α-surfaces with the gravity engine, Theorem 3.1 tested on them and on Schwarzschild. 14c, instantons from twistor data (§5): the 't Hooft ansatz and the ADHM data of charge 1, giving the review's instanton, CAND-124's mirror image. 14d, amplitudes (§7): spinor-helicity on rational kinematics, Parke–Taylor and the BCFW recursion. 14e, reductions and the Newtonian limit (§6, §8): sine-Gordon, Nahm's spectral curve, the Gibbons–Hawking family as c → ∞.
