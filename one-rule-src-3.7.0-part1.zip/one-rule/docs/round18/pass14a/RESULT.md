<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 14a, the result: flat twistor theory on the labels, read with *Twistor theory at fifty*

Script `checks/selfcheck/proofs/twistor_flat.py`: 10 checks (bit 1, bit==std 2, ctl 3, std 4), 0 fail, a few seconds alone. Seven `--fault` options, each run ending with FAIL lines and exit 1: CELL with 2 failing lines, NOI 2, NULLW 1, DEG 1, EUC 1, SDLAX 1, NAHM 1. Logs `checks/selfcheck/proofs/logs/twistor_flat.log` and `twistor_flat.faults.log`. Run from `checks/` as `python3 -I -B selfcheck/proofs/twistor_flat.py`; the last line is `twistor_flat: 10 checks, 0 fail`; from its own folder and on a second run the check lines are identical. The standard library only. An independent audit read the pass and recomputed it with its own code (§11).

The review: M. Atiyah, M. Dunajski, L. J. Mason, *Twistor theory at fifty: from contour integrals to twistor strings*, Proc. R. Soc. A 473 (2017) 20170530, 33 pages, attached by the owner and read in full after BEFORE.md was written (its corresponding author's contact line is not copied).

Conventions (stated in the script and in the rows):

- *The labels.* The kernel `researchers_checks/bitrule_A.py`: e_a e_b = s(a, b) e_{a xor b}, generator i = bit i; the cell (4,2) has its four generators of square +1 first. Ω = e₁⋯e₆ is the volume element (Ω here, ω being the twistor's first component), P = (1 + e₁e₅)(1 + e₂e₆)/4, and the ideal is the left ideal of the even part through P.
- *Twistors.* Z = (ω, π) with ω = iXπ, X = [[t + z, x + iy], [x − iy, t − z]] (the review's (2.5) with its factor 1/√2 scaled away, which changes neither the lines nor the zeros of Σ); Σ(Z, W) = Z⁰W̄² + Z¹W̄³ + Z²W̄⁰ + Z³W̄¹; a real point has X Hermitian. On a line, the charts π = (1, λ), where π·dπ = dλ, and π = (μ, 1), where π·dπ = −dμ. Penrose's formula: φ_{A′…B′}(X) = Res π_{A′}⋯π_{B′} f(iXπ, π) π·dπ at the root of A·Z, for f = (A·Z)⁻¹(B·Z)^{−(n+1)}, X = X^{AA′} any complex 2 × 2 matrix (complexified Minkowski space).
- *Exact numbers.* Gaussian rationals; first and second derivatives of rational functions at rational points by jets c₀ + c₁ε + c₂ε² (ε³ = 0).
- *Lax.* Euclidean ℝ⁴ with the review's reality z̃ = z̄, w̃ = −w̄ and the Atlas's choice z = x₁ + ix₂, w = x₃ + ix₄, which the review does not fix (w = x₃ − ix₄ would reverse the orientation); the 't Hooft tensors η (self-dual, ε₁₂₃₄ = 1) and η̄ (anti-self-dual) as in `checks/selfcheck/gravity/ym_solutions.py`.

## 1. Predicted (BEFORE.md) against the review and against what ran

| prediction | the review | what ran | verdict |
|---|---|---|---|
| 1. twistor space the spinor module of the conformal cell; a (2,2) form; Λ²T the vector, the Klein quadric | §2(a): T = ℂ⁴ with Σ of signature (++−−), SU(2,2) locally SO(4,2) | tf.SPIN: from the labels of (4,2), the ideal ℂ⁴, the one invariant form, (2,2); the 15 bivectors faithful; Λ² of the ideal ≅ the vector, the quadratic form carried to a multiple of the wedge pairing | met |
| 2. points as lines; lines meet iff the separation is null; the split-signature real case in Cl(3,3) | §2(a): (2.5), PN, real points ↔ lines in PN, null twistors ↔ light rays, null separation ↔ meeting lines | tf.INC: the complex incidence and its meeting lines both ways, real points and light rays, exact | met for the complex incidence; the split-signature real case (Cl(3,3), GEN-007) not computed |
| 3. Bateman's formula as a residue; the elementary state c/(x − x₀)² | §1 (1.1); §2(c): f = (P·Z)⁻¹(Q·Z)⁻¹, a fundamental solution | tf.PEN: φ = 1/(det[[A₀, A₁], [B₀, B₁]]·det(X − X₀)), X₀ the point whose line is A·Z = B·Z = 0 | met |
| 4. helicity from homogeneity; h = ±1 the (anti-)self-dual Maxwell fields | §2(c): H¹(PT, 𝒪(k)) and the zero-rest-mass fields | tf.PEN: homogeneity −n − 2 gives the fields of spin n/2 (n ≤ 4), independent of the chart exactly at that homogeneity (§3.3); n = 2 a self-dual Maxwell field | met for the primed fields; the unprimed ones (homogeneity n − 2, with derivatives in ω; for n = 2 the anti-self-dual Maxwell fields) not computed |
| 5. ASD Yang–Mills on twistor space; the BPST instanton (CAND-124) the simplest bundle | §5: Ward's theorem; the Lax pair (5.3); instantons are anti-self-dual (§5(c)) | tf.LAX: the integrability of (5.3) is exactly anti-self-duality for the review's orientation (with z = x₁ + ix₂, w = x₃ + ix₄); CAND-124's instanton is self-dual there | partly missed: CAND-124's instanton has the opposite duality to the review's instantons — its mirror image is one; led to the Lax pair; the bundle, the 't Hooft and ADHM data not computed |
| 6. ASD gravity: a check of self-duality, silent on the twistor construction | §3: the nonlinear graviton, Theorems 3.1–3.3 | — | not computed here (a later pass, with the gravity engine) |
| 7. integrable systems: silent | §6: reductions of ASDYM and of ASD conformal structures | tf.LAX: Nahm's Lax pair, a finite matrix identity | the Atlas is not silent on Nahm's equations |
| 8. strings and amplitudes: identities on rational kinematics, not derivations | §7: Parke–Taylor, Nair, the twistor string, BCFW, CHY, ambitwistor strings | — | not computed here (a later pass) |
| 9. the Newtonian limit: silent | §8: lim PT_c = 𝒪 ⊕ 𝒪(2); the Gibbons–Hawking family tending to Newton–Cartan | — | not tested: the metric family could be given to the gravity engine, which already checks Taub–NUT in Gibbons–Hawking form (`gravity/aty_matter_models.py`) |

## 2. What the review says (in the Atlas's words; read in full)

- **§1 (pp. 2–4).** Bateman's formula (1.1) solves the wave equation; its arguments are affine coordinates on PT restricted to a line; Minkowski space a real slice of the lines; f up to functions holomorphic inside the contour: Čech cohomology; rigorous correspondences for the wave equation and the higher-spin equations.
- **§2 (pp. 4–6).** The Hodge star on 2-forms, Λ² = Λ²₊ ⊕ Λ²₋ (2.1); T_ℂM ≅ S ⊗ S′ (2.2) with g = ε ⊗ ε′ (2.3); Λ²₊ ≅ S′* ⊙ S′*, Λ²₋ ≅ S* ⊙ S*; SO(4, ℂ) ≅ (SL(2, ℂ) × SL(2, ℂ))/ℤ₂ (2.4). (a) The incidence relation (2.5); points incident with one twistor are null separated; Σ of signature (++−−), kept by SU(2,2), locally SO(4,2); PN = {Σ = 0} ≅ S² × ℝ³, the light rays; real points give lines in PN; complex points ↔ lines, α-planes ↔ points, null separation ↔ meeting lines. (b) The plane dual to a non-null twistor meets PN in a three-parameter family of light rays, the Robinson congruence (figure 2, the twisting circles that named twistors). (c) A function of homogeneity −2 on the overlap of two charts gives an element of H¹(L_p, 𝒪(−2)); integrated it gives (1.1) with λ = Z³/Z²; its footnote 2 gives the factor λ^{−k} between the two charts for 𝒪(k); the elementary state (P·Z)⁻¹(Q·Z)⁻¹ gives a fundamental solution; the theorem of Eastwood, Penrose and Wells; higher spin from 𝒪(k).
- **§3 (pp. 6–11).** α-surfaces; Theorem 3.1 (Penrose): a three-parameter family of α-surfaces exactly when the Weyl tensor is anti-self-dual; Theorem 3.2: the moduli of rational curves with normal bundle 𝒪(1) ⊕ 𝒪(1) carry an anti-self-dual conformal structure; for a Ricci-flat one, a fibration over CP¹ with an 𝒪(2)-valued symplectic form on the fibres; the special classes (anti-self-dual Einstein, hyper-Hermitian, scalar-flat Kähler).
- **§4 (pp. 11–12).** Local twistors: the twistor equation (4.1), local twistor transport, the tractor bundle (4.2); an Einstein metric in the conformal class ↔ a parallel tractor (4.3).
- **§5 (pp. 12–14).** Full Yang–Mills is not integrable; the anti-self-dual equations *F = −F (5.1), on M_ℂ the vanishing of F on α-planes, with the linear system l·DΦ = m·DΦ = 0 along them (5.2); Theorem 5.1 (Ward): gauge classes of ASD connections ↔ holomorphic bundles on PT trivial on each line; the patching matrix and the Riemann–Hilbert problem; (b) the Lax pair (5.3) in coordinates w, z, w̃, z̃ with g = 2(dz dz̃ − dw dw̃) and vol = dw ∧ dw̃ ∧ dz ∧ dz̃, the Euclidean reality z̃ = z̄, w̃ = −w̄: [L, M] = F_{z̃w̃} − λ(F_{ww̃} − F_{zz̃}) + λ²F_{wz}; (c) instantons, the solutions of the ASD equations of finite action, and the ADHM construction.
- **§6 (pp. 15–18).** Integrable systems as reductions: sine-Gordon, Tzitzeica, Hitchin's equations, KdV and NLS (Mason–Sparling); Nahm's equations Φ̇₁ = [Φ₂, Φ₃] and cyclic, with the Lax form Ḃ = [B, C], B(λ) = (Φ₁ + iΦ₂) + 2Φ₃λ − (Φ₁ − iΦ₂)λ², C = −iΦ₃ + i(Φ₁ − iΦ₂)λ; dispersionless systems from ASD conformal structures.
- **§7 (pp. 18–23).** The Parke–Taylor formula (7.1) with null momenta as rank-one 2 × 2 matrices; Nair; Witten's twistor string on CP^{3|4}; the RSV formula; Hodges and Cachazo–Skinner for gravity; the CHY scattering equations; ambitwistor strings (7.2).
- **§8 (p. 24).** Penrose's collapse time; Newtonian twistors, lim PT_c = 𝒪 ⊕ 𝒪(2) with jumping lines; the Gibbons–Hawking family g(c) tending to a Newton–Cartan connection with Γ^i_{ττ} = ½δ^{ij}∂_jV.
- **§9–10 (pp. 24–25).** The googly problem; integral geometry (John's ultrahyperbolic equation); quasi-local mass; loop quantum gravity; non-commutative twistors.

## 3. The answers

### 3.1 Twistor space from the labels (tf.SPIN)

**Claim.** The left ideal of the even part of Cl(4,2) through P = (1 + e₁e₅)(1 + e₂e₆)/4 is a complex 4-space, J = Ω, on which the 15 bivectors act faithfully as su(2,2), keeping a Hermitian form of signature (2, 2), unique up to a real factor; Λ² of it is the vector of so(4,2), with the quadratic form of the generators carried to a non-zero multiple of the wedge pairing.

*Proof and computation.* Ω² = (−1)^{15}·(+1)⁴(−1)² = −1, and Ω commutes with the even labels (n even), so J = Ω is a complex structure commuting with the even part (computed on the 32 even labels). a = e₁e₅ and b = e₂e₆ commute and square to +1 (e₁² = +1, e₅² = −1), so P is an idempotent; the ideal through it has real dimension 8 (computed), complex dimension 4, and the 32 even labels act on it with rank 32 (computed): complex-linear maps spanning all of End_ℂ(ℂ⁴), so the even part is M₄(ℂ) and the ideal its simple module. The 15 bivectors act with rank 15 (faithful), commute with J and have complex trace 0 (computed). The real symmetric forms S with SJ-invariance (JᵀSJ = S) and Sg + gᵀS = 0 for every bivector g form a line (computed by exact linear algebra), of real signature (4, 4): the real part of a Hermitian form of signature (2, 2). So the bivectors form a 15-dimensional subalgebra of su(2,2), which has dimension 15: so(4,2) ≅ su(2,2) from the labels (CAND-025 by an explicit isomorphism). The intertwiners T: Λ²ℂ⁴ → ℂ⁶ with T·Λ²(L_x) = ad_x·T for the 15 bivectors x form a line over ℚ(i) (computed), T is invertible, and Tᵀ diag(1, 1, 1, 1, −1, −1) T = c·Pl with c ≠ 0, where b ∧ b′ = Pl(b, b′) v₁ ∧ v₂ ∧ v₃ ∧ v₄ for the complex basis v₁, …, v₄ of the ideal (computed; c = −2 for the intertwiner the computation picks, which carries no meaning of its own: T → sT gives s²c, and a change of basis A of ℂ⁴ multiplies c by det A). So a bivector of ℂ⁴ is decomposable — a 2-plane, a line of PT — exactly when its image is null (the Plücker relation, recalled: decomposable exactly when b ∧ b = 0): the lines of PT are the points of the Klein quadric in P⁵, complexified compactified Minkowski space (recalled). Over 𝔽₂ the same correspondence is ATY-030's.

### 3.2 The incidence relation, the light rays and the Robinson congruence (tf.INC)

**Lemma 1.** The lines L_X = {(iXπ, π)} and L_Y meet exactly when det(X − Y) = 0, and det(X − Y) is the interval of x − y.

*Proof.* A common point has Xπ = Yπ′ with π′ ∝ π, so (X − Y)π = 0; conversely a kernel vector π gives the common twistor (iXπ, π). det of t + xσ₁ + yσ₂ + zσ₃ is t² − x² − y² − z². ∎ (Computed both ways on 300 pairs: the 150 null ones meet at the twistor of the kernel, and for the 150 others the two planes span ℂ⁴.)

**Lemma 2.** A twistor Z = (ω, π), π ≠ 0, lies on the line of a real point exactly when Σ(Z, Z) = 0, and then the real points whose lines hold it form a light ray.

*Proof.* A Hermitian X with Xu = y (u ≠ 0) exists exactly when u†y is real: u†Xu is real for Hermitian X; conversely X = (yu† + uy†)/n − (u†y)uu†/n², n = u†u, is Hermitian with Xu = y when u†y is real. Here u = π, y = −iω, and u†y = −iπ†ω is real exactly when Re(π†ω) = 0, while Σ(Z, Z) = 2 Re(π†ω). Two solutions differ by a Hermitian K with Kπ = 0, a real multiple of u⊥u⊥†, u⊥ = (−π̄₁, π̄₀), whose determinant is 0: a null vector, so the solutions form a light ray. ∎ (Computed: the solution built for 100 null twistors, absent for 100 non-null ones; the ray checked.)

**Lemma 3 (the Robinson congruence).** For a non-null twistor W, through every real point passes exactly one light ray whose twistor Z has Σ(Z, W) = 0; so no two of these rays meet.

*Proof.* For Z = (iXπ, π), Σ(Z, W) = πᵀv with v = iXᵀw̄″ + w̄′ (w′ = (W⁰, W¹), w″ = (W², W³)), linear in π. If v ≠ 0 the condition fixes π up to a factor, π = (v₁, −v₀): one ray. v = 0 at a real point means Xw″ = −iw′ for a Hermitian X (conjugating), which by Lemma 2's criterion needs Re(w″†w′) = 0, that is Σ(W, W) = 0. Two rays of the family meeting at a point would be two rays through it. ∎ (Computed for 3 non-null W, 8 rational points each: the rays null, in W^⊥, and Σ(Z₁, Z₂) ≠ 0 for every pair; a line of PN is totally null for Σ, so Σ(Z₁, Z₂) ≠ 0 also shows directly that the rays do not meet. The twisting of the family, the review's figure 2, is not computed.)

### 3.3 Penrose's integral formulae (tf.PEN)

**The equations.** On the chart π = (1, λ) put φ_j(X) = Res λ^j f(iX(1, λ), (1, λ)) dλ at a simple pole moving holomorphically with X; derivatives in X pass under the residue (a fixed small contour). Since ω^A = iX^{AA′}π_{A′}, ∂/∂X^{AA′} acts on f(iXπ, π) as iπ_{A′}∂f/∂ω^A, so ε^{A′C′}∂_{AC′}φ_{A′B′…} carries the factor ε^{A′C′}π_{A′}π_{C′} = 0: the zero-rest-mass equations hold, and for n = 0 the wave operator 4(∂₀₀∂₁₁ − ∂₀₁∂₁₀) gives the factor π₀′π₁′ − π₁′π₀′ = 0. This holds for any integrand on one chart, as the review's (1.1) holds for any f. (Computed: the wave equation for 12 elementary states by second jets; the zero-rest-mass equations for n = 1, …, 4, 4 states each, by first jets.)

**The homogeneity.** Let f have homogeneity d. On π = (μ, 1) = μ(1, λ), λ = 1/μ, the integrand π_{0′}^{n−j}π_{1′}^j f π·dπ = μ^{n−j} f (−dμ) becomes μ^{n+d+2}λ^j f(iX(1, λ), (1, λ)) dλ = λ^{−(n+d+2)}λ^j f dλ, and at a simple pole λ₀ ≠ 0 its residue is λ₀^{−(n+d+2)} times the residue on the chart π = (1, λ). So the two charts give the same field exactly when d = −n − 2, the case in which π_{A′}⋯π_{B′} f π·dπ is a 1-form on the line (the review's footnote 2 gives the factor between the charts for 𝒪(k)). Computed: the two charts agree for n = 0, …, 4 at homogeneity −n − 2 (4 states each), and the state of homogeneity −3 (n = 0) differs (control DEG). The homogeneity −n − 2 for spin n/2 is thus what makes the field a field.

**The elementary state.** φ = Res 1/((a₀ + a₁λ)(b₀ + b₁λ)) = 1/(a₁b₀ − a₀b₁), where (a₀, a₁) = iα(X − X₀) and (b₀, b₁) = iβ(X − X₀) for α = (A₀, A₁), β = (B₀, B₁), since the line of X₀ lies in A·Z = B·Z = 0; so a₁b₀ − a₀b₁ = −det(i[α; β](X − X₀)) = det[[A₀, A₁], [B₀, B₁]]·det(X − X₀), and φ = 1/(det[[A₀, A₁], [B₀, B₁]]·det(X − X₀)). (Computed exactly at three points for each of 12 states.) It is a multiple of the fundamental solution 1/(x − x₀)² of the wave equation, translated.

**The spin-1 field.** For n = 2, F = φ_{A′B′}ε_{AB} (with the sigma matrices of (2.5)) is closed (computed by jets) and *F = iF with the star of the ε tensor (η = diag(1, −1, −1, −1), ε₀₁₂₃ = 1) at 4 random states and points; built from a primed spinor it lies in the review's Λ²₊ ≅ S′* ⊙ S′*. So dF = 0 and d*F = 0: a self-dual vacuum Maxwell field. The sign of *F = ±iF is a convention (ε₀₁₂₃ = −1 would give −i), stated with the computation. The star read from the kernel — the bivector times the pseudoscalar e₀e₁e₂e₃ of Cl(1,3) — equals the star of the ε tensor on all six basis 2-forms (bit==std).

### 3.4 The Lax pairs (tf.LAX)

**The review's (5.3).** With z = x₁ + ix₂, w = x₃ + ix₄ (the Atlas's choice; the review fixes z̃ = z̄, w̃ = −w̄), the vector fields ∂_z, ∂_{z̃}, ∂_w, ∂_{w̃} have the Euclidean products ∂_z·∂_{z̃} = ½, ∂_w·∂_{w̃} = −½ and 0 otherwise, so the review's g = 2(dz dz̃ − dw dw̃) is twice the Euclidean metric, and vol = dw ∧ dw̃ ∧ dz ∧ dz̃ = 4 dx₁dx₂dx₃dx₄ (computed; w = x₃ − ix₄ would give −4 and exchange η and η̄). The three coefficients of [L, M] = F_{z̃w̃} − λ(F_{ww̃} − F_{zz̃}) + λ²F_{wz} are linear in the 2-form F; they vanish on the three anti-self-dual η̄^a, and on the three self-dual η^a they form a 3 × 3 matrix of determinant 1/2 (computed). Since Λ² = Λ²₊ ⊕ Λ²₋, their common zeros are exactly the anti-self-dual 2-forms of the review's orientation: the integrability of (5.3) is (5.1), *F = −F, pointwise. CAND-124's BPST curvature is F = −4ηρ²/(x² + ρ²)² (computed by `gravity/ym_solutions.py`, not here), self-dual for this orientation: in these coordinates it does not solve (5.3), and its mirror image x₄ → −x₄, the anti-instanton with η̄, does — an instanton in the review's sense, which takes instantons anti-self-dual (§5(c)). The choice agrees with the sign of the review's Nahm equations (p. 16), which anti-self-duality for ε₁₂₃₄ = +1 gives with A₄ = 0 (the audit's computation, §11).

**Nahm's equations.** With Φ̇₁ = [Φ₂, Φ₃] and cyclic, the coefficients of Ḃ − [B, C] in λ are, by expansion: λ⁰: Φ̇₁ + iΦ̇₂ − [Φ₂ − iΦ₁, Φ₃]; λ¹: 2Φ̇₃ − 2[Φ₁, Φ₂]; λ²: −(Φ̇₁ − iΦ̇₂) + [Φ₂ + iΦ₁, Φ₃]; λ³: −[B₂, C₁] = i[Φ₁ − iΦ₂, Φ₁ − iΦ₂] = 0 — all zero on Nahm's equations, and conversely the λ⁰, λ² and λ¹ coefficients give back the three equations (the review's intermediate line). (Computed: for random Gaussian-integer matrices of sizes 2, 3, 4, three each, exactly; with the sign of the λ² term of B changed it fails, control NAHM.)

## 4. What ran

| id | what | route | scope |
|---|---|---|---|
| tf.SPIN | [bit] the ideal of Cl⁰(4,2), J = Ω, the even part as End_ℂ(ℂ⁴), the 15 bivectors trace-free, the invariant form and its signature, the intertwiner Λ² → vector and the Klein quadric. [bit==std] the signature of Σ and of CAND-025's η, (2, 2) | the kernel's products; exact rational and ℚ(i) linear algebra; `core_check.signature_of` | the cell (4,2) |
| tf.INC | [std] the incidence (2.5), meeting lines both ways, real points and light rays; the Robinson congruence | exact ℚ(i) | 300 pairs; 400 + 200 twistors; 3 non-null W, 24 rays |
| tf.PEN | [std] the elementary state's exact identity, the wave and zero-rest-mass equations, the two charts. [bit==std] the spin-1 field closed and self-dual; the kernel's star against the ε tensor | exact residues; jets of order 2 | n = 0, …, 4, 4 to 12 states each |
| tf.LAX | [std] the review's Lax pair against η and η̄, the products and the orientation; Nahm's Lax pair | exact ℚ(i) | the six 't Hooft tensors; 9 random triples of matrices |

## 5. Controls

Three `[ctl]` lines, computed without the fault:

- *CELL and NOI.* In the cell (3,3) the volume element squares to +1, so it is no complex structure there (the split real form). Without the factor i of (2.5) the line of a real point leaves PN.
- *NULLW and DEG.* For a null twistor W (the twistor of a real point) the condition on π vanishes at a real point of its ray, through which every light ray lies in W^⊥: no congruence. The state of homogeneity −3 solves the wave equation on one chart and gives different values on the two charts.
- *EUC, SDLAX and NAHM.* With the indices raised by the identity instead of η, F is no eigenform of the star. The self-dual tensors leave the Lax coefficients non-zero. With the sign of the λ² term of B changed, Ḃ ≠ [B, C].

Under `--fault X` each wrong version is put in the main lines, which then fail, and each run exits 1: CELL 2 failing lines, NOI 2, NULLW 1, DEG 1, EUC 1, SDLAX 1, NAHM 1. The homogeneity is controlled through the two charts, since on one chart every integrand gives solutions (§3.3).

## 6. The standard route

tf.SPIN is the bit side: the module, the forms and the intertwiner are read from the kernel's products in the cell (4,2). tf.INC, tf.PEN and tf.LAX use the review's matrices and coordinates and no kernel (the std side). Two bit==std lines compare: the signature of the form the labels give with that of the review's Σ and CAND-025's η (one invariant); the star read from the kernel's pseudoscalar of Cl(1,3) with the star of the ε tensor.

## 7. Second sources

None in the package beyond the review. Recalled, not read: Cauchy's residue theorem; the Plücker relation (a bivector of ℂ⁴ is decomposable exactly when b ∧ b = 0); the Klein quadric as complexified compactified Minkowski space; the sign of the helicity, a convention (the review calls the anti-self-dual case right-handed).

## 8. Proposed rows, lens entries (apply.json)

| id | title | evidence | placed |
|---|---|---|---|
| ATY-066 | twistor space from the labels of the conformal cell (4,2): the ideal ℂ⁴ with J = Ω, the (2,2) form, su(2,2) faithful; Λ² of it the vector of so(4,2), the lines of PT the null vectors (the Klein quadric) | tf.SPIN | steps/projective · summary 20 |
| ATY-067 | the incidence relation of the review, exact: meeting lines ↔ null separation; a twistor meets a real point exactly when it is null, then along a light ray; the Robinson congruence of a non-null twistor, one ray through every point | tf.INC | steps/projective · summary 21 |
| ATY-068 | Penrose's integral formulae as exact residues: the elementary state 1/(det[[A₀, A₁], [B₀, B₁]]·det(X − X₀)); the zero-rest-mass fields of spin n/2 ≤ 2, independent of the chart exactly at homogeneity −n − 2; the spin-1 field a self-dual Maxwell field | tf.PEN | light · summary 45 |
| ATY-069 | the review's Lax pairs: the integrability of (5.3) is anti-self-duality for its orientation (with z = x₁ + ix₂, w = x₃ + ix₄; CAND-124's instanton self-dual there, its mirror image an instanton in the review's sense); Nahm's equations as Ḃ = [B, C] | tf.LAX | steps/ym · summary 17 |

The rows carry `since: "v3.6"`, role detail, kind computation, `legacyFlags: ["checked"]`, research texts as drafts (`source: "pass14a:twistor-flat"`), no learner text; each derives from the row it builds on (ATY-066 from ATL-014, ATY-067 from ATY-066, ATY-068 from ATY-067, ATY-069 from CAND-124). Lens entries: geo (two: twistor space as the spinor module of the conformal cell and the Klein correspondence; the incidence relation and the Robinson congruence), fld (two: Penrose's integral formulae and the massless fields; the Lax pairs of anti-self-dual Yang–Mills and Nahm), str (one: twistors ℂ⁴ the spinors of Spin(4,2), computed).

## 9. Defects and open points

- **Flat space only.** The nonlinear graviton (Theorems 3.1–3.3), local twistors (§4), the Ward correspondence for bundles (Theorem 5.1) beyond the Lax pair, the instantons from bundles (the 't Hooft ansatz, ADHM), the integrable reductions other than Nahm's, the amplitudes and the twistor strings (§7), the Newtonian limit (§8): read, not computed.
- **The unprimed fields and the cohomology.** The unprimed fields, from homogeneity n − 2 with derivatives in ω (for n = 2 the anti-self-dual Maxwell fields), and the Čech cohomology itself (the equivalence classes of f) are not computed: the residues are taken for chosen representatives.
- **The twisting** of the Robinson congruence is not computed; the split-signature real twistors (Cl(3,3)) are not computed.
- **The coordinates of the Lax pair** z = x₁ + ix₂, w = x₃ + ix₄ are the Atlas's choice; the review fixes only the reality conditions.
- **Random points.** The incidence and the integral formulae are computed at random rational points; the lemmas of §3 carry them to every point.
- **No learner words.**

## 10. The next passes of the programme

1. **14b, curved twistors and the nonlinear graviton** (§3): with the gravity engine (`checks/selfcheck/gravity/`, which already checks Taub–NUT in Gibbons–Hawking form), the anti-self-dual Weyl curvature of the multi-centre Gibbons–Hawking and Eguchi–Hanson metrics, the α-surfaces of a self-dual metric as integrable distributions (Frobenius on the engine's frames), Theorem 3.1 checked on them and failing on Schwarzschild.
2. **14c, instantons from twistor data** (§5): the 't Hooft ansatz A from 1 + ρ²/|x − a|², its anti-self-duality in the review's orientation, and the ADHM data of charge 1 giving the review's instanton (CAND-124's mirror image); the patching matrix of its bundle on a line.
3. **14d, amplitudes** (§7): spinor-helicity on rational kinematics, the Parke–Taylor MHV formula, its little-group weights and the BCFW recursion for n ≤ 6 checked against it.
4. **14e, reductions and the Newtonian limit** (§6, §8): sine-Gordon from the review's SU(2) ansatz; the conservation of Nahm's spectral curve det(η − B(λ)); the Gibbons–Hawking family g(c) as c → ∞ and its Newton–Cartan connection Γ^i_{ττ} = ½δ^{ij}∂_jV, with the gravity engine.

## 11. The independent audit

An agent that had not seen the pass written read BEFORE.md, this file, the script and its logs against the review, and recomputed with its own code: Cl(4,2) from explicit 8 × 8 real matrices and, apart, on the eigenspace of Ω in ℂ⁸ (the module, its forms, the intertwiner, the dependence of the Klein constant on the normalisation); the incidence both ways, the Hermitian solutions and fifty rays of the Robinson congruence as real lines of ℝ⁴; Penrose's fields as identities in X, numerical contour integrals on both charts and the factor between them for every homogeneity; the duality conventions of the spin-1 field; the review's orientation under the choices of z and w, and the sign of its Nahm equations; Nahm's Lax equation in the free algebra. It found the mathematics right, the script and its seven faults reproduced byte for byte, and no blocking issue. Its points are taken in this file, the script and the rows: the Klein constant stated as a non-zero multiple; the coordinates z = x₁ + ix₂, w = x₃ + ix₄ named as the Atlas's choice, and CAND-124's instanton set against the review's instantons, which are anti-self-dual; the Maxwell field stated in vacuum, without a reading of E and B; the factor between the charts written out for every homogeneity; the verdicts of predictions 2, 5 and 9 stated with their scope; the products of the vector fields, the Euclidean metric half the review's g; the meeting of lines computed both ways; the elementary state's exact identity; spin in place of helicity where the sign is not computed; the recalled facts listed; the derivations of the rows limited to those that hold; the volume element written Ω.
