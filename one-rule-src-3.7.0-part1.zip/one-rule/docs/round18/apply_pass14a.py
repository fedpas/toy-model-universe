#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round18/apply_pass14a.py -- applies pass 14a of round 18 (docs/round18/pass14a/apply.json: flat twistor theory on the labels, read
with M. Atiyah, M. Dunajski and L. J. Mason's review Twistor theory at fifty) to the tables, with the release owner's acceptance of
docs/round18/pass14a/RESULT.md section 8.

Modelled on docs/round17/apply_pass13g.py. Idempotent: a second run writes the same bytes (the sha256 of every touched file
is printed at the end), also after npm run content. Every input is checked before the first file is written. In order:
  1 content/rows.json        ATY-066 to ATY-069 after ATY-065 (the order of the ids, the order tools/merge_story.mjs sorts the rows in), since
                             v3.6, computations, the key order of the rows of the proofs passes; the ids free (a row that holds one and is not an
                             earlier copy of this pass stops the script); every (page, order) free page-wide (in the rows, the story overlay's
                             layouts and the chains overlay's placements), the section a section of its page: steps/projective · summary at 20 and
                             21, light · summary at 45, steps/ym · summary at 17, role detail, the rows' only placements (their home)
  2 content/texts.json       their research texts (status draft, source pass14a:twistor-flat), after the texts of ATY-065 (the order of
                             tools/merge_story.mjs: by row, then level); no learner text
  3 content/checks.json      the check record of twistor_flat.py (tf.SPIN, tf.INC, tf.PEN, tf.LAX), after weil_general.py
  4 content/check_runs.json  its run record: the stored log ends with the record's last line, its tagged check lines count the record's checks and tags
                             (10: bit 1, bit==std 2, ctl 3, std 4), and its fault log holds the seven wrong versions in order, each exit 1, with as
                             many FAIL lines as its own last line counts (CELL 2, NOI 2, NULLW 1, DEG 1, EUC 1, SDLAX 1, NAHM 1)
  5 content/lenses.json      geo 81 -> 83 (twistor space from the labels; the incidence relation and the Robinson congruence), fld 88 -> 90 (Penrose's
                             integral formulae; the Lax pairs of anti-self-dual Yang-Mills and Nahm) and str 64 -> 65 (twistors from the labels),
                             appended after each lens's own entries, each with the keys, in their order, of the lens's entries
  6 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence and by text)
No figure and no analysis is named by the pass: engines/MANIFEST.json and content/analyses.json are not touched. Each table keeps its own JSON form
(indent 1, UTF-8, with or without the final newline it had); a table whose text a load and dump would change stops the script before anything is written.
Usage (from anywhere): python3 docs/round18/apply_pass14a.py [--no-node]    --no-node skips step 6
"""
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
said = []
pending = {}   # rel -> text: the tables are written together once every input is checked
TOUCHED = []   # every file this script may write, for the sha256 line at the end


def path(rel):
    return os.path.join(ROOT, rel)


def dump(data, newline):
    return json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    data, nl = json.loads(raw), raw.endswith('\n')
    assert dump(data, nl) == raw, f'{rel}: a load and dump would change its text (its JSON form is not indent 1, UTF-8): stop'
    return data, nl


def stage(rel, data, newline):
    """the table's new text, written by flush() once every check of steps 1 to 5 has passed"""
    pending[rel] = dump(data, newline)
    if rel not in TOUCHED:
        TOUCHED.append(rel)


def flush():
    for rel, text in pending.items():
        old = open(path(rel), encoding='utf-8').read()
        if text != old:
            open(path(rel), 'w', encoding='utf-8').write(text)
            said.append(f'wrote {rel}')
        else:
            said.append(f'unchanged {rel}')
    pending.clear()


def node(args, what):
    out = subprocess.run(['node', *args], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    if out.returncode:
        sys.stdout.write(out.stdout[-4000:])
        sys.stderr.write(out.stderr[-4000:])
        sys.exit(f'{what} failed')
    return out.stdout


# ---- the pass
P = json.load(open(os.path.join(HERE, 'pass14a', 'apply.json'), encoding='utf-8'))
IDS = ['ATY-066', 'ATY-067', 'ATY-068', 'ATY-069']
SCRIPT = 'checks/selfcheck/proofs/twistor_flat.py'
SRC = 'pass14a:twistor-flat'
CHECKS = ['tf.SPIN', 'tf.INC', 'tf.PEN', 'tf.LAX']
EVIDENCE = {'ATY-066': ['tf.SPIN'], 'ATY-067': ['tf.INC'], 'ATY-068': ['tf.PEN'], 'ATY-069': ['tf.LAX']}
FAULTS = [('CELL', 2), ('NOI', 2), ('NULLW', 1), ('DEG', 1), ('EUC', 1), ('SDLAX', 1), ('NAHM', 1)]
TAGS = {'bit': 1, 'bit==std': 2, 'ctl': 3, 'std': 4}
LAST = 'twistor_flat: 10 checks, 0 fail'
WHERE = {'ATY-066': [('steps/projective', 'summary', 20)], 'ATY-067': [('steps/projective', 'summary', 21)], 'ATY-068': [('light', 'summary', 45)],
         'ATY-069': [('steps/ym', 'summary', 17)]}
KINDS = {'ATY-066': ('computation', 'A', 'symmetry'), 'ATY-067': ('computation', 'K', 'identity'), 'ATY-068': ('computation', 'F', 'solution'),
         'ATY-069': ('computation', 'F', 'identity')}
AFTER = 'ATY-065'                                   # the row the pass's rows follow (the ids sorted)
LENSES = {'geo': (81, 2, 'lens_geo'), 'fld': (88, 2, 'lens_fld'), 'str': (64, 1, 'lens_str')}   # the dictionaries after pass 13g, the entries the pass adds, the block of apply.json
FORM_ROW = 'GEN-033'                                # a row of the proofs passes: the key order of the new rows
PREV_CHECK = 'selfcheck/proofs/weil_general.py'     # the check record the pass's record follows
OVERLAY = []

assert P['pass'] == '14a' and P['since'] == 'v3.6', (P['pass'], P['since'])
assert [r['id'] for r in P['rows']] == IDS, [r['id'] for r in P['rows']]
assert [t['row'] for t in P['texts']] == IDS, 'one research text per row, in the order of the rows'
assert P['row_text_edits'] == [] and P['analyses'] == [], 'the pass edits no text of another row and names no analysis'
assert P['files']['script'] == SCRIPT and all(os.path.exists(path(P['files'][k])) for k in ('script', 'log', 'faultLog')), P['files']
assert P['files']['overlay'] == OVERLAY, P['files']['overlay']
assert all(os.path.exists(path(d)) for d in P['files']['docs'] + P['files']['overlay']), [d for d in P['files']['docs'] + P['files']['overlay'] if not os.path.exists(path(d))]
said.append('checked docs/round18/pass14a/apply.json (pass 14a, since v3.6; the rows, texts, check, run and lens entries present)')

# ===================================================================================================================== 1 rows
rows, rows_nl = load('content/rows.json')


def earlier_copy(r):
    """a row of this pass written by an earlier run: since v3.6, its group, every evidence the pass's script"""
    return (r.get('since') == 'v3.6' and r.get('group') == r['id'][:3] and bool(r.get('evidence'))
            and all(e.get('script') == SCRIPT for e in r['evidence']))


clash = [r['id'] for r in rows if r['id'] in IDS and not earlier_copy(r)]
if clash:
    sys.exit(f'the ids {clash} are taken by other rows of content/rows.json: renumber the pass from the next free id of its group')
rows = [r for r in rows if r['id'] not in IDS]
assert [r['id'] for r in rows] == sorted(r['id'] for r in rows), 'content/rows.json is not in the order of the ids (tools/merge_story.mjs sorts it): run npm run content'
layouts = []
for rel in sorted(os.listdir(path('content/story'))):
    if rel.endswith('.json') and rel not in ('merged.json', 'rows.json', 'texts.json'):
        x = json.load(open(path(f'content/story/{rel}'), encoding='utf-8'))
        lay = x if rel == 'layout.json' else (x.get('layout') if isinstance(x, dict) else None)
        if isinstance(lay, list):
            layouts += [l for l in lay if isinstance(l, dict) and 'page' in l and 'order' in l]
for owner in sorted(os.listdir(path('content/chains'))):
    f = path(f'content/chains/{owner}/page.json')
    if os.path.exists(f):
        layouts += json.load(open(f, encoding='utf-8')).get('layout') or []
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])} | {(l['page'], l['order']) for l in layouts}
mine = [(pg, o) for rid in IDS for pg, _, o in WHERE[rid]]
assert len(mine) == len(set(mine)) and not set(mine) & taken, f'an order of the pass is taken (page-wide) or used twice: {sorted(set(mine) & taken)}'
pages = json.load(open(path('content/pages.json'), encoding='utf-8'))
sections = {p['route']: {s.get('id') for s in p.get('sections') or []} for p in pages}
form = list(next(x for x in rows if x['id'] == FORM_ROW).keys())
ids = {r['id'] for r in rows} | set(IDS)
for r in P['rows']:
    rid = r['id']
    assert r['since'] == 'v3.6' and r['group'] == 'ATY' and (r['kind'], r['stage'], r['ptype']) == KINDS[rid], rid
    assert list(r.keys()) == form, f'{rid}: the keys of a row of the proofs passes, in their order'
    assert [(s['page'], s['section'], s['order']) for s in r['shownOn']] == WHERE[rid], rid
    assert all(s['role'] == 'detail' and s['section'] in sections.get(s['page'], ()) for s in r['shownOn']), f'{rid}: a role or a section'
    assert [e['check'] for e in r['evidence']] == EVIDENCE[rid] and all(e['mode'] == 'ran' and e['script'] == SCRIPT for e in r['evidence']), rid
    assert r['legacyFlags'] == ['checked'] and r['visibleTo'] == ['phys', 'math'], rid
    for d in r['depends']:
        assert d['id'] in ids and d['rel'] == 'derives', f'{rid} depends on {d}'
assert sorted(c for v in EVIDENCE.values() for c in v) == sorted(CHECKS), 'every check id is some row\'s evidence'
for r in P['rows']:
    at = next((i for i, x in enumerate(rows) if x['id'] > r['id']), len(rows))
    assert rows[at - 1]['id'] in (AFTER, *IDS), (r['id'], rows[at - 1]['id'])
    rows.insert(at, dict(r))
order = [r['id'] for r in rows]
assert order == sorted(order) and [i for i in order if i in IDS] == IDS and all(order.index(a) + 1 == order.index(b) for a, b in zip([AFTER] + IDS, IDS)), 'the rows after ATY-065'
said.append('rows: ' + '; '.join(f"{r['id']} on " + ', '.join(f"{s['page']} · {s['section']} {s['order']}" for s in r['shownOn']) for r in P['rows']))

# ===================================================================================================================== 2 texts
texts, texts_nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'], t.get('chain'))
mine_t = {key(t) for t in P['texts']}
texts = [t for t in texts if key(t) not in mine_t]
assert not any(t['row'] in IDS for t in texts), 'another text of the rows stands in content/texts.json (no learner text in this pass)'
form_t = list(next(t for t in texts if t['row'] == FORM_ROW and t['level'] == 'research').keys())
for t in P['texts']:
    assert list(t.keys()) == form_t, f"{t['row']}: the keys of a research text"
    assert (t['status'], t['source'], t['level'], t['lens'], t['mode'], t['register'], t['lang']) == ('draft', SRC, 'research', None, 'both', 'full', 'en'), t['row']
    assert not re.search(r'/home/|/Users/|@[\w-]+\.\w|docs/round|SOURCES\.md', t['body']), f"{t['row']}: a machine path, a folder path or a contact detail"
prev = AFTER
for t in P['texts']:
    at = max(i for i, x in enumerate(texts) if x['row'] == prev) + 1
    texts.insert(at, dict(t))
    prev = t['row']
j = max(i for i, x in enumerate(texts) if x['row'] == IDS[-1])
assert (j + 1 == len(texts) or texts[j + 1]['row'] > IDS[-1]) and [texts[j - k]['row'] for k in range(len(IDS), -1, -1)] == [AFTER] + IDS, 'the texts of ATY-066 to ATY-069 out of row order'

# ===================================================================================================================== 3 the check record
checks, checks_nl = load('content/checks.json')
cid = SCRIPT[len('checks/'):]
checks = [c for c in checks if c['id'] != cid]
assert checks[-1]['id'] == PREV_CHECK, checks[-1]['id']
assert not any(x['id'] in CHECKS for c in checks for x in c.get('ids') or []), 'a tf.* id in another record'
form_c = list(checks[-1].keys())
assert len(P['checks']) == 1
c = P['checks'][0]
assert list(c.keys()) == form_c and c['id'] == cid and c['since'] == 'v3.6' and c['script'] == SCRIPT and c['log'] == P['files']['log'], c['id']
assert [x['id'] for x in c['ids']] == CHECKS and c['rowsNaming'] == IDS, c['id']
assert f"{sum(TAGS.values())} checks ({', '.join(f'{k} {v}' for k, v in TAGS.items())})" in c['notes'], c['notes'][:160]
checks.append(c)
stage('content/checks.json', checks, checks_nl)

# ===================================================================================================================== 4 the run record
runs, runs_nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
runs = [r for r in runs if rk(r) not in {rk(x) for x in P['check_runs']}]
run_form = list(runs[-1].keys())
TAG = re.compile(r'^  (ok|FAIL) +\[(bit|bit==std|ctl|std)\] ')
name = os.path.basename(SCRIPT)[:-len('.py')]
total = sum(TAGS.values())
log = open(path(P['files']['log']), encoding='utf-8').read().rstrip('\n').split('\n')
hits = [m for m in map(TAG.match, log) if m]
tags = {k: sum(1 for m in hits if m.group(2) == k) for k in TAGS}
assert all(m.group(1) == 'ok' for m in hits) and len(hits) == total and tags == TAGS, tags
assert log[-1] == LAST == f'{name}: {total} checks, 0 fail', log[-1]
tagword = ', '.join(f'{k} {v}' for k, v in TAGS.items())
assert len(P['check_runs']) == 1
r = P['check_runs'][0]
assert r['script'] == SCRIPT and r['source'] == P['files']['log'] and list(r.keys()) == run_form, r['script']
assert r['passed'] is True and r['ok'] == total and r['fail'] == 0 and r['lastLine'] == log[-1], r['script']
assert f'tags {tagword}' in r['status'] and f'{len(FAULTS)} --fault runs each exit 1' in r['status'], r['status']
got = []
for b in re.split(r'^(?=--fault )', open(path(P['files']['faultLog']), encoding='utf-8').read(), flags=re.M):
    if not b.strip():
        continue
    head = re.match(r'--fault (\w+): exit 1\n', b)
    last = re.search(rf'^last: {name}: (\d+) checks, (\d+) fail$', b, re.M)
    nfail = len(re.findall(r'^  FAIL +\[', b, re.M))
    assert head and last and int(last.group(1)) == total and int(last.group(2)) == nfail >= 1, b[:80]
    got.append((head.group(1), nfail))
assert got == FAULTS, got
for txt in (open(path(P['files']['log']), encoding='utf-8').read(), open(path(P['files']['faultLog']), encoding='utf-8').read()):
    assert not re.search(r'(?<![\w.~%-])/(home|Users|tmp)/[\w.-]', txt), 'a machine path in a stored log'
runs.append(r)
said.append(f"{SCRIPT}: {log[-1]} (tags {tagword}); faults {', '.join(f'{f} {k}' for f, k in got)}, each exit 1")
stage('content/check_runs.json', runs, runs_nl)

# ===================================================================================================================== 5 the lenses alg and fld
lenses, lenses_nl = load('content/lenses.json')
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows'] and e['atlas'] == f['atlas']
named = set()
for lkey, (n0, nadd, block) in LENSES.items():
    blk = P[block]
    assert blk['key'] == lkey and len(blk['dictionary_add']) == nadd, (lkey, len(blk['dictionary_add']))
    for e in blk['dictionary_add']:
        assert e['evidence'] and set(e['evidence']) <= set(CHECKS) and e['rows'] and set(e['rows']) <= set(IDS), e['atlas'][:40]
        assert e['flags'] == ['checked'] and e['from'].endswith('(pass 14a)') and e['from'].startswith(f'{lkey} · ') and e['matrixRows'] == [], e['from']
        named |= set(e['evidence'])
    lens = next(x for x in lenses if x['key'] == lkey)
    form_l = list(lens['dictionary'][0].keys())
    assert all(list(e.keys()) == form_l for e in lens['dictionary'] + blk['dictionary_add']), f'{lkey}: an entry in another form than the lens keeps'
    keep_l = [e for e in lens['dictionary'] if not e['from'].endswith('(pass 14a)') and not any(same(e, f) for f in blk['dictionary_add'])]   # an earlier copy, whatever its words
    assert len(keep_l) == n0, (lkey, len(keep_l))
    lens['dictionary'] = keep_l + blk['dictionary_add']
    said.append(f"the lens {lkey}: {n0} -> {len(lens['dictionary'])} dictionary entries")
assert set().union(*(set(e['evidence']) for blk in LENSES.values() for e in P[blk[2]]['dictionary_add'])) == set(CHECKS), 'the entries of the lenses together name every check id of the rows'
stage('content/lenses.json', lenses, lenses_nl)

# ===================================================================================================================== 1, 2: the rows and the texts staged
stage('content/rows.json', rows, rows_nl)
stage('content/texts.json', texts, texts_nl)
flush()   # every input of steps 1 to 5 checked: the tables written together
TOUCHED += ['content/lens_readings.json']

if not NO_NODE:
    # ================================================================================================================= 6 the lens readings
    out = node(['tools/migrate/lens_readings.mjs'], 'tools/migrate/lens_readings.mjs')
    sys.stdout.write(out[-600:])
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    mine_lr = [x for x in lr if x['row'] in IDS]
    said.append(f'ran tools/migrate/lens_readings.mjs: {len(lr)} readings, {len(mine_lr)} on the four rows ('
                + ', '.join(f"{k} {sum(1 for x in mine_lr if x['lens'] == k)}" for k in sorted({x['lens'] for x in mine_lr})) + ')')

print('\n'.join(said))
print('sha256 of the files this script touches:')
for rel in TOUCHED:
    print(f"  {hashlib.sha256(open(path(rel), 'rb').read()).hexdigest()}  {rel}")
