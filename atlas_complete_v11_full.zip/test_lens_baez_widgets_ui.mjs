// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Baez widgets in a real browser, through the real route #lenses/baez (step 19): English and Italian, Young Learner / Physicist / Mathematician, 1100 and
// 375 px, dark and light (?theme=light). The widgets are found by [data-widget] only (BW1 ... BW7, BaezWidgetsScript), after every fold of the chapter is
// opened, so this test runs on the chapter as delivered, whatever anchors and folds it uses. Each widget is driven (a click, a key, a slider) and what it
// shows is checked against baezEngine.js and the stored JSON (baezWidgetData.js); the badge says live = stored, or stored, as it should; the twin table holds
// the numbers of the picture; the captions are the copy's lines with their tags in the voice of the reader; no page error; no horizontal page scroll.
// Audiences (DECISIONS.md §2): BW1, BW4, BW5 for all three (must); BW2, BW3 for the Physicist and the Mathematician (must, never for the Young Learner);
// BW6 (all) and BW7 (Young Learner and Physicist) are optional: driven when the chapter shows them, reported when it does not.
// Run: node test_lens_baez_widgets_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
import { chromium } from 'playwright';
import { APP_HTML } from './paths.mjs';
import * as E from './baezEngine.js';
import D from './baezWidgetData.js';
import { BWC } from './baezWidgetsCopy.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const info = m => console.log('  ' + m);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const PROFILES = ['Young Learner', 'Physicist', 'Mathematician'];
const SHOW = { BW1: PROFILES, BW2: PROFILES.slice(1), BW3: PROFILES.slice(1), BW4: PROFILES, BW5: PROFILES, BW6: PROFILES, BW7: ['Young Learner', 'Physicist'] };
const OPTIONAL = new Set(['BW6', 'BW7', 'BaezWidgetsScript']);
const b = await chromium.launch();
const absent = new Set();

async function open(lang, prof, w, theme) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: theme === 'light' ? 'reduce' : 'no-preference' });
  await ctx.addInitScript(([l, a]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, [lang, prof]);
  const pg = await ctx.newPage(), errs = [];
  pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await pg.goto(APP_HTML + (theme === 'light' ? '?theme=light' : '') + '#lenses/baez'); await pg.waitForSelector('#ln-baez', { timeout: 15000 }); await pg.waitForTimeout(300);
  await pg.evaluate(() => document.querySelectorAll('#ln-baez details').forEach(d => { d.open = true; })); await pg.waitForTimeout(150);
  return { ctx, pg, errs };
}
const attr = (loc, a) => loc.first().getAttribute(a);
const text = loc => loc.first().innerText().then(t => t.replace(/\s+/g, ' ').trim());
const fill = async (pg, loc, v) => { await loc.first().fill(String(v)); await pg.waitForTimeout(60); };
// the captions of a widget: the copy's lines, in order, with their tags (the class names of the tag spans)
async function captions(W, items, tag) {
  const got = await W.locator('.bzw-cap .eq-pt').evaluateAll(es => es.map(e => [[...e.querySelectorAll('.tag')].map(t => ['standard', 'checked', 'ours', 'open'].find(k => t.classList.contains(k))).join(' '), e.querySelector('p').textContent.replace(/\s+/g, ' ').trim()]));
  ok(got.length === items.length && got.every(([t], i) => t === items[i][0]), `${tag}: the captions are the ${items.length} lines of the copy with their tags: ${JSON.stringify(got.map(g => g[0]))}`);
}
const badge = async (W, kind, lang, tag) => { const k = await attr(W.locator(':scope > [data-badge]'), 'data-badge'), t = await text(W.locator(':scope > [data-badge]')), want = tag.includes('Young Learner') ? BWC[lang].badgeY[kind] : BWC[lang].badge[kind]; ok(k === kind && t === want, `${tag}: the badge says "${want}" (${k}: ${t})`); };

for (const lang of ['en', 'it']) for (const prof of PROFILES) for (const [w, theme] of [[1100, 'dark'], [375, 'light'], [375, 'dark'], [1100, 'light']]) {
  const tag = `${lang} ${prof} ${w} ${theme}`, deep = theme === 'dark' ? w === 1100 : w === 375, yl = prof === 'Young Learner', C = BWC[lang];
  const { ctx, pg, errs } = await open(lang, prof, w, theme);
  ok(await pg.evaluate(() => document.documentElement.getAttribute('data-theme')) === theme, `${tag}: the page is in the ${theme} theme`);
  const present = {};
  for (const id of ['BW1', 'BW2', 'BW3', 'BW4', 'BW5', 'BW6', 'BW7', 'BaezWidgetsScript']) present[id] = await pg.locator(`#ln-baez [data-widget="${id}"]`).count();
  for (const [id, who] of Object.entries(SHOW)) {
    if (!who.includes(prof)) { ok(present[id] === 0 || OPTIONAL.has(id), `${tag}: ${id} is not shown to the ${prof}`); continue; }
    if (OPTIONAL.has(id)) { if (!present[id]) absent.add(`${id} for the ${prof}`); continue; }
    ok(present[id] >= 1, `${tag}: ${id} is on the page`);
  }
  for (const id of Object.keys(present)) if (present[id]) { const W = pg.locator(`#ln-baez [data-widget="${id}"]`).first(); ok(await W.evaluate(e => e.classList.contains('ln-card')), `${tag}: ${id} is an ln-card`); }

  // ---------------- BW1
  if (present.BW1) { const W = pg.locator('#ln-baez [data-widget="BW1"]').first(), t = C.bw1;
    await badge(W, 'match', lang, tag + ' BW1');
    ok(await W.locator('button.bzw-dot').count() === 32 && same(await W.locator('button.bzw-dot[data-lit="1"]').evaluateAll(es => es.map(e => +e.dataset.label).sort((x, y) => x - y)), E.family(false)), `${tag} BW1: 32 labels, the 16 even ones lit`);
    await captions(W, yl ? t.capY : t.cap, tag + ' BW1');
    if (deep) {
      await W.locator('button.bzw-dot[data-label="5"]').click(); await pg.waitForTimeout(60);
      const i5 = E.labelInfo(5);
      ok(await attr(W.locator('[data-read]'), 'data-y') === i5.Y && await attr(W.locator('[data-read]'), 'data-q') === i5.Q && (await text(W.locator('[data-read]'))).includes('2/3'), `${tag} BW1: label 5 (first weak, red) reads Y = ${i5.Y}, Q = ${i5.Q}`);
      ok(await attr(W.locator('[data-pick]'), 'data-count') === '1' && await attr(W.locator('[data-pick]'), 'data-sum') === '2/3', `${tag} BW1: one pick, charge sum 2/3`);
      await W.locator('[data-act="all"]').click(); await pg.waitForTimeout(60);
      ok(await attr(W.locator('[data-pick]'), 'data-count') === '16' && await attr(W.locator('[data-pick]'), 'data-sum') === '0' && /0\.?$/.test(await text(W.locator('[data-pick]'))), `${tag} BW1: all 16 picked, the charges add to 0`);
      await W.locator('[data-act="flip"]').click(); await pg.waitForTimeout(80);
      ok(await attr(W, 'data-flipped') === '1' && same(await W.locator('button.bzw-dot[data-lit="1"]').evaluateAll(es => es.map(e => +e.dataset.label).sort((x, y) => x - y)), E.family(true)) && await attr(W.locator('[data-read]'), 'data-q') === E.labelInfo(26).Q && await attr(W.locator('[data-pick]'), 'data-sum') === '0',
        `${tag} BW1: flip all five lights the 16 odd labels; the selected label becomes 26 with Q = ${E.labelInfo(26).Q}; the 16 still add to 0`);
      const rows = await W.locator('table[data-twin="classes"] tbody tr').evaluateAll(es => es.map(e => [e.dataset.class, +e.dataset.n, e.dataset.q]));
      const want = E.classesOf(E.family(true)).map(c => [`${c.a},${c.b}`, c.n, c.Q.join(' ')]);
      ok(same(rows, want), `${tag} BW1: the twin table is the six flipped classes of the engine: ${JSON.stringify(rows)}`);
      const cells = await W.locator('.bzw-cell.lit').evaluateAll(es => es.map(e => [e.dataset.cell, e.querySelectorAll('button.bzw-dot').length]));
      ok(same(cells.sort(), want.map(([k, n]) => [k, n]).sort()), `${tag} BW1: the lit cells of the picture are the rows of the twin table`);
      if (!yl) ok(same(await W.locator('table[data-twin="sums"] tr[data-row="live"] td').allTextContents(), ['0', '0', '0', '0', '0']) && (await text(W.locator('[data-adn]'))).includes(': 10') && (await text(W.locator('[data-adn]'))).includes('✓'), `${tag} BW1: the live anomaly sums of the flipped family are 0; ad N 10 + 25 + 10 ✓`);
      await W.locator('[data-act="clear"]').click(); await W.locator('[data-act="flip"]').click(); await pg.waitForTimeout(60);
      await W.locator('button.bzw-dot[data-label="3"]').focus(); await pg.keyboard.press('Enter'); await pg.waitForTimeout(60);
      ok(await attr(W.locator('[data-read]'), 'data-label') === '3' && await attr(W.locator('[data-read]'), 'data-q') === '1' && await attr(W, 'data-flipped') === '0', `${tag} BW1: the keyboard (Enter on a focused label) selects it: label 3, Q = 1`);
      if (!yl) ok((await text(W.locator('[data-read]'))).includes('Y = 1'), `${tag} BW1: the formal readout says Y = 1 for the weak pair`);
      else ok(!/[=_^]/.test(await text(W.locator('[data-read]'))), `${tag} BW1: the plain readout has no formula`);
    }
  }
  // ---------------- BW2
  if (present.BW2) { const W = pg.locator('#ln-baez [data-widget="BW2"]').first(), P = D.P2, t = C.bw2;
    await badge(W, 'stored', lang, tag + ' BW2'); await captions(W, t.cap, tag + ' BW2');
    const seg = r => W.locator(`.bzw-bar button[data-row="${r}"]`).evaluateAll(es => es.map(e => +e.dataset.n));
    ok(same(await seg(0), P.f4.filter(Boolean)) && same(await seg(1), P.e7.filter(Boolean)), `${tag} BW2: the two bars are ${P.f4} and ${P.e7}`);
    const col = c => W.locator(`table[data-twin="classes"] td[data-col="${c}"]`).allTextContents();
    ok(same((await col('f4')).map(Number), [...P.f4, 27]) && same((await col('e7')).map(Number), [...P.e7, 27]) && same((await col('e7_16')).map(Number), [...P.e7_16, 16]), `${tag} BW2: the twin table holds the bars and their totals 27, 27, 16`);
    if (deep) {
      await W.locator('.bzw-bar button[data-row="1"][data-class="4"]').click(); await pg.waitForTimeout(60);
      const r = await text(W.locator('[data-read]'));
      ok(await attr(W.locator('[data-read]'), 'data-class') === '4' && r.includes(String(P.f4[4])) && r.includes(String(P.e7[4])) && r.includes(t.classes[4]), `${tag} BW2: focusing a block reads its class and both counts: ${r}`);
      await W.locator('[data-act="where16"]').click(); await pg.waitForTimeout(60);
      const parts = await W.locator('.bzw-bar button[data-row="1"]').evaluateAll(es => es.map(e => [e.dataset.part, +e.dataset.n]));
      ok(await attr(W, 'data-show16') === '1' && parts.filter(p => p[0] === '16').reduce((s, p) => s + p[1], 0) === 16 && parts.filter(p => p[0] === '11').reduce((s, p) => s + p[1], 0) === 11 && await W.locator('[data-note16]').count() === 1, `${tag} BW2: "where is the 16" splits the E7 bar into 16 + 11`);
      ok(same(await W.locator('table[data-twin="stab"] td').allTextContents(), Object.values(P.stab).map(String)), `${tag} BW2: the stabiliser table is the stored 52, 28, 16, 36, 18, 12`);
    } }
  // ---------------- BW3
  if (present.BW3) { const W = pg.locator('#ln-baez [data-widget="BW3"]').first(), P = D.P3;
    await badge(W, 'match', lang, tag + ' BW3'); await captions(W, C.bw3.cap, tag + ' BW3');
    ok(await W.locator('.bzw-sub [data-badge="stored"]').count() === 1, `${tag} BW3: the branchings carry their own badge "${C.badge.stored}"`);
    ok(same((await W.locator('table[data-twin="ladder"] td[data-col="live"]').allTextContents()).map(Number), P.sizes) && same((await W.locator('table[data-twin="ladder"] td[data-col="stored"]').allTextContents()).map(Number), P.sizes), `${tag} BW3: the twin table: roots live = stored = ${P.sizes}`);
    if (deep) {
      for (const [n, g] of [[7, 27], [4, 6], [6, 16]]) { await W.locator(`.bzw-step[data-step="${n}"]`).click(); await pg.waitForTimeout(60);
        const d = P.dec[String(n)], ms = await W.locator('.bzw-piece').evaluateAll(es => es.map(e => +e.dataset.m));
        ok(+await attr(W.locator('[data-read]'), 'data-g1') === g && ms.length === d.length && same(ms, d.map(k => k.m)) && d.reduce((s, k) => s + k.m * k.dim, 0) === g, `${tag} BW3: step ${n}: grade-1 piece of ${g}, its stored pieces (${ms}) add up to ${g}`); }
      await W.locator('.bzw-step[data-step="8"]').click(); await pg.waitForTimeout(60);
      ok(await W.locator('[data-pieces="none"]').count() === 1 && +await attr(W.locator('[data-read]'), 'data-g1') === 56, `${tag} BW3: the 56 is not split`);
      await W.locator('[data-act="links"]').click(); await pg.waitForTimeout(60);
      ok(await attr(W.locator('[data-chain]'), 'data-chain') === P.links.join(',') && same(await W.locator('[data-link-size]').evaluateAll(es => es.map(e => +e.dataset.linkSize)), P.links.slice(1, 6)), `${tag} BW3: the second route shows the link chain ${P.links}`);
    } }
  // ---------------- BW4
  if (present.BW4) { const W = pg.locator('#ln-baez [data-widget="BW4"]').first(), t = C.bw4, sl = W.locator('input[type=range]');
    await badge(W, 'match', lang, tag + ' BW4'); await captions(W, yl ? t.capY : t.cap, tag + ' BW4');
    const rd = async () => ({ eps: +await attr(W.locator('[data-read]'), 'data-eps'), turn: +await attr(W.locator('[data-read]'), 'data-turn'), slide: +await attr(W.locator('[data-read]'), 'data-slide'), stretch: +await attr(W.locator('[data-read]'), 'data-stretch'), killing: await attr(W.locator('[data-read]'), 'data-killing'), sq: await W.locator('.bzw-move').evaluateAll(es => es.map(e => +e.dataset.sq)) });
    for (const [v, e] of [[-3, 1], [0, 0], [3, -1]]) { if (deep || v === 0) { await fill(pg, sl, v); const r = await rd(), k = E.kepler(e), s = D.P4.eps[String(e)];
      ok(r.eps === e && r.turn === s.turn && r.slide === s.slide && r.stretch === s.stretch && r.killing === s.killing.join(',') && same(r.sq, k.squares), `${tag} BW4: energy ${v / 10}: eps ${e}, ${s.turn} turn / ${s.slide} slide / ${s.stretch} stretch, Killing (${s.killing}) as engine and JSON say`);
      ok((await text(W.locator('[data-read]'))).includes(yl ? t.countY(k) : t.algs[e]), `${tag} BW4: the readout names ${yl ? 'the count' : t.algs[e]}`); } }
    if (deep) {
      await W.locator('[data-preset="1"]').click(); await pg.waitForTimeout(60); ok((await rd()).eps === 1, `${tag} BW4: the "${(yl ? t.presetsY : t.presets)[1]}" chip sets a bound orbit`);
      await sl.first().focus(); await pg.keyboard.press('ArrowRight'); await pg.keyboard.press('ArrowRight'); await pg.keyboard.press('ArrowRight'); await pg.waitForTimeout(60);
      ok((await rd()).eps === 0, `${tag} BW4: the slider moves with the keyboard (three steps right reach E = 0)`);
      if (!yl) { const live = await W.locator('table[data-twin="kepler"] td[data-col="live"]').allTextContents(), st = await W.locator('table[data-twin="kepler"] td[data-col="stored"]').allTextContents();
        ok(same(live, st) && same(live, ['1', '0', '-1'].map(e => '(' + D.P4.eps[e].killing.join(', ') + ')')), `${tag} BW4: the twin table: Killing live = stored`);
        ok(same((await W.locator('table[data-twin="shells"] td[data-col="live"]').allTextContents()).map(Number), D.P4.shells_spin), `${tag} BW4: shells 2n² = ${D.P4.shells_spin}`); }
      ok(+(await attr(W.locator('svg[data-orbit-e]'), 'data-orbit-e')) === 1, `${tag} BW4: at E = 0 the drawn conic is a parabola (e = 1)`);
    } }
  // ---------------- BW5
  if (present.BW5) { const W = pg.locator('#ln-baez [data-widget="BW5"]').first(), t = C.bw5;
    await badge(W, 'stored', lang, tag + ' BW5'); await captions(W, yl ? t.capY : t.cap, tag + ' BW5');
    ok(await W.locator('g[data-paper]').count() === 7 && await W.locator('g[data-edge]').count() === 8 && await W.locator('button[data-edge]').count() === 8, `${tag} BW5: 7 papers, 8 lines`);
    ok(same(await W.locator('g[data-edge]').evaluateAll(es => es.map(e => e.dataset.kind)), E.EDGES.map(e => e.kind)), `${tag} BW5: the lines are drawn with their kinds (3 citations, 2 computed, 2 our reading, 1 open)`);
    if (deep) for (const id of ['h', 'a', 'e']) { await W.locator(`button[data-edge="${id}"]`).click(); await pg.waitForTimeout(60);
      const items = (yl ? t.edgesY : t.edges)[id], got = await W.locator('[data-read] .eq-pt').evaluateAll(es => es.map(e => [...e.querySelectorAll('.tag')].map(x => ['standard', 'checked', 'ours', 'open'].find(k => x.classList.contains(k))).join(' ')));
      ok(await attr(W.locator('[data-read]'), 'data-edge') === id && same(got, items.map(x => x[0])), `${tag} BW5: line ${id} shows its ${items.length} tagged sentence(s): ${got}`); }
    if (deep) { await W.locator('g[data-edge="c"]').focus(); await pg.keyboard.press('Enter'); await pg.waitForTimeout(60); ok(await attr(W.locator('[data-read]'), 'data-edge') === 'c', `${tag} BW5: a line of the drawing is chosen with the keyboard`);
      if (!yl) ok(await W.locator('table[data-twin="edges"] tbody tr').count() === 8, `${tag} BW5: the twin table lists the 8 lines`); } }
  // ---------------- BW6 (optional)
  if (present.BW6) { const W = pg.locator('#ln-baez [data-widget="BW6"]').first(), t = C.bw6;
    await badge(W, 'match', lang, tag + ' BW6'); await captions(W, yl ? t.capY : t.cap, tag + ' BW6');
    for (const N of deep ? [2, 0, 1, 3, 7] : [2]) { await W.locator(`button[data-ring="${N}"]`).click(); await pg.waitForTimeout(50);
      ok(+await attr(W.locator('[data-read]'), 'data-points') === D.P5.rings[N] && +await attr(W.locator('[data-read]'), 'data-shadows') === (D.P5.shadows[String(N)] || 0), `${tag} BW6: ring ${N}: ${D.P5.rings[N]} points, ${D.P5.shadows[String(N)] || 0} shadows`); }
    if (!yl) { const tab = await W.locator('table[data-twin="rings"] tbody tr').evaluateAll(es => es.map(e => [...e.querySelectorAll('td')].slice(1).map(x => +x.textContent)));
      ok(same(tab, D.P5.rings.map((n, N) => [n, n, D.P5.shadows[String(N)] || 0, D.P5.shadows[String(N)] || 0])), `${tag} BW6: the twin table: points and shadows live = stored`); } }
  // ---------------- BW7 (optional)
  if (present.BW7) { const W = pg.locator('#ln-baez [data-widget="BW7"]').first(), t = C.bw7, sl = W.locator('input[type=range]');
    await badge(W, 'match', lang, tag + ' BW7'); await captions(W, yl ? t.capY : t.cap, tag + ' BW7');
    for (const N of deep ? [36, 37, 118, 1] : [37]) { await fill(pg, sl, N); const f = E.fillTo(N);
      ok(+await attr(W.locator('[data-read]'), 'data-row') === f.row && +await attr(W.locator('[data-read]'), 'data-closes') === f.closesAt && await attr(W.locator('[data-read]'), 'data-closed') === (f.closed ? '1' : '0'), `${tag} BW7: ${N} electrons: row ${f.row}, closes at ${f.closesAt}${f.closed ? ' (closed)' : ''}`);
      const filled = await W.locator('.bzw-sh').evaluateAll(es => es.reduce((s, e) => s + +e.dataset.fill, 0)); ok(filled === N, `${tag} BW7: the picture holds exactly ${N} electrons (${filled})`); }
    if (!yl) ok(same((await W.locator('table[data-twin="rows"] td[data-col="live"]').allTextContents()).map(Number), D.P5.madelung.closings) && same((await W.locator('table[data-twin="rows"] td[data-col="stored"]').allTextContents()).map(Number), D.P5.madelung.closings), `${tag} BW7: the twin table: closings live = stored`); }
  // ---------------- the script box
  if (present.BaezWidgetsScript) ok(await pg.locator('#ln-baez [data-widget="BaezWidgetsScript"] [data-download="selfcheck/reports/lens_baez_check.py"]').count() === 1, `${tag}: the script box offers lens_baez_check.py`);
  // ---------------- every widget: the voice, the layout
  const voices = await pg.locator('#ln-baez [data-widget] .bzw-cap').evaluateAll(es => [...new Set(es.map(e => e.dataset.voice))]);
  ok(same(voices, [yl ? 'yl' : 'formal']), `${tag}: every caption is in the ${yl ? 'plain' : 'formal'} voice: ${voices}`);
  if (yl) { const ylTxt = await pg.locator('#ln-baez [data-widget] .bzw-cap').evaluateAll(es => es.map(e => e.textContent).join(' '));
    ok(!/[=^_√⊂⊗ℂℝλεωαβ]|\b(algebra|Peirce|Casimir|Killing|lattice|reticolo|Jordan|bivector)/i.test(ylTxt), `${tag}: the Young Learner captions have no formula and no technical word`); }
  const over = await pg.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  ok(over <= 1, `${tag}: no horizontal page scroll (${over} px)`);
  const wide = await pg.locator('#ln-baez [data-widget]').evaluateAll(es => es.filter(e => e.getBoundingClientRect().right > window.innerWidth + 1).map(e => e.dataset.widget));
  ok(wide.length === 0, `${tag}: every widget fits the width: ${wide}`);
  ok(errs.length === 0, `${tag}: no page error: ${errs.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
for (const a of absent) info('optional widget not on the page: ' + a);
await b.close();
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL BAEZ WIDGET UI TESTS PASS'); process.exit(bad ? 1 : 0);
