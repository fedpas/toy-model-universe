// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML } from './paths.mjs';
import { chromium } from 'playwright';
// Playing widgets: moving a slider while a widget plays changes the inputs of the running motion (it neither stops nor restarts it);
// while a widget is paused a slider never starts it. Chain, top and orbits are live simulations (state carries on); the segment, square and spring-cube widgets
// redraw their whole curve and go on at the same time.
const URL = process.env.ATLAS_URL_RIGID || APP_HTML + '#equations/rigid';
const b = await chromium.launch(); const errs = [];
const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
const pg = await ctx.newPage();
pg.on('pageerror', e => errs.push(`pageerror: ${e.message}`)); pg.on('console', m => m.type() === 'error' && errs.push(`console: ${m.text()}`));
await pg.goto(URL); await pg.waitForTimeout(400);
const S = '#eq-rigid';
// the page opens for the Young Learner (the default audience): "hang it from a spring" is shown in plain words and the other widgets sit in the closed
// fold "for older readers" (v9), which is opened here; the widgets behave the same for every audience
await pg.evaluate(s => document.querySelectorAll(s + ' details.eq-fold').forEach(d => { d.open = true; }), S); await pg.waitForTimeout(100);
const num = s => parseFloat(String(s).replace(',', '.').replace(/[^0-9.\-]/g, ''));
const txt = async sel => (await pg.locator(`${S} ${sel}`).first().textContent());
const pressed = async sel => (await pg.locator(`${S} ${sel}`).first().getAttribute('aria-pressed')) === 'true';
const time = async W => num((await txt(`${W} .rg-time`)).split('=').pop());      // "t = 1.25", or "time 1.25" in the plain version
const set = async (sel, v) => { await pg.locator(`${S} ${sel}`).first().fill(String(v)); };

// ---- chain on springs (live simulation)
{ const W = '.rg-w-hang';
  // paused, never run: a slider only changes the starting rest state, nothing starts
  await set(`${W} .rg-gr`, 10); await pg.waitForTimeout(400);
  if (await pressed(`${W} .rg-play`)) errs.push('hang: a slider started the motion');
  if ((await time(W)) !== 0) errs.push('hang: time moved while paused');
  // tilt 0: at rest. Play, then change gravity while it plays
  await set(`${W} .rg-tilt`, 0); await set(`${W} .rg-gr`, 30);
  await pg.locator(`${W} .rg-play`).click(); await pg.waitForTimeout(700);
  const t1 = await time(W); if (!(t1 > 0.1)) errs.push(`hang: not playing (t=${t1})`);
  if (!(await txt(`${W} .rg-rest`)).includes('✓')) errs.push('hang: tilt 0 should be at rest before the change');
  const e1 = await txt(`${W} .rg-energy`);
  await set(`${W} .rg-gr`, 55); await pg.waitForTimeout(60);
  if (!(await pressed(`${W} .rg-play`))) errs.push('hang: moving gravity stopped the motion');
  const t2 = await time(W); if (!(t2 >= t1)) errs.push(`hang: moving gravity restarted the clock (${t1} -> ${t2})`);
  await pg.waitForTimeout(700);
  const t3 = await time(W); if (!(t3 > t2)) errs.push(`hang: clock did not go on after the change (${t2} -> ${t3})`);
  if (!(await pressed(`${W} .rg-play`))) errs.push('hang: stopped by itself');
  if ((await pg.locator(`${W} .rg-rest`).count()) !== 0) errs.push('hang: the rest claim is still shown after the world was changed in flight');
  if ((await txt(`${W} .rg-energy`)) === e1) errs.push('hang: the energy line ignored the new gravity');
  // the new gravity really acts: the chain that was at rest now moves (potential and spring energy change between two looks)
  const a = await txt(`${W} .rg-energy`); await pg.waitForTimeout(150); const a2 = await txt(`${W} .rg-energy`); if (a === a2) errs.push('hang: nothing moves after the change of gravity from rest');
  if (!(await txt(`${W} .rg-drift`)).includes('✓')) errs.push('hang: energy not conserved after a live change');
  await set(`${W} .rg-k`, 20); await set(`${W} .rg-al`, 4); await pg.waitForTimeout(200);
  if (!(await pressed(`${W} .rg-play`))) errs.push('hang: moving stiffness or damping stopped the motion');
  // the starting push (tilt) is a new run, still playing
  await set(`${W} .rg-tilt`, 40); await pg.waitForTimeout(60);
  if (!(await pressed(`${W} .rg-play`))) errs.push('hang: a new tilt stopped the motion');
  const t4 = await time(W); await pg.waitForTimeout(400); if (!((await time(W)) > t4)) errs.push('hang: a new tilt did not keep playing');
  // pause: a slider changes nothing visible in time
  await pg.locator(`${W} .rg-play`).click(); const tp = await time(W); await set(`${W} .rg-gr`, 5); await pg.waitForTimeout(400);
  if (await pressed(`${W} .rg-play`)) errs.push('hang: a slider restarted a paused run');
  if ((await time(W)) !== tp) errs.push('hang: time moved while paused after a slider');
  await pg.locator(`${W} .rg-play`).click(); await pg.waitForTimeout(300); if (!((await time(W)) > tp)) errs.push('hang: play after pause does not go on');
  await pg.locator(`${W} .rg-play`).click(); }

// ---- free top
{ const W = '.rg-w-top';
  await set(`${W} .rg-I0`, 40); await pg.waitForTimeout(300);
  if (await pressed(`${W} .rg-play`)) errs.push('top: a slider started the motion');
  await pg.locator(`${W} .rg-play`).click(); await pg.waitForTimeout(600);
  const t1 = await time(W); if (!(t1 > 0.05)) errs.push(`top: not playing (t=${t1})`);
  await pg.locator(`${W} .rg-play`).click(); // pause, read the momentum point, change the body, read again: L is carried over
  const dot = async () => { const d = pg.locator(`${S} ${W} .rg-dot`); return [num(await d.getAttribute('cx')), num(await d.getAttribute('cy'))]; };
  const p0 = await dot(), tp = await time(W); await set(`${W} .rg-I1`, 70); await pg.waitForTimeout(150);
  const p1 = await dot(); if (Math.hypot(p0[0] - p1[0], p0[1] - p1[1]) > 0.05) errs.push(`top: the momentum point jumped when the body changed (${p0} -> ${p1})`);
  if ((await time(W)) !== tp) errs.push('top: time moved while paused');
  if (await pressed(`${W} .rg-play`)) errs.push('top: a slider restarted a paused run');
  await pg.locator(`${W} .rg-play`).click(); await pg.waitForTimeout(400);
  if (!((await time(W)) > tp)) errs.push('top: the run did not go on after the body changed');
  await set(`${W} .rg-I2`, 90); await pg.waitForTimeout(50);
  if (!(await pressed(`${W} .rg-play`))) errs.push('top: changing the body in flight stopped it');
  const t2 = await time(W); await pg.waitForTimeout(400); if (!((await time(W)) > t2)) errs.push('top: the clock did not go on');
  if (!(await txt(`${W} .rg-cons`)).includes('✓')) errs.push('top: |L| and E are not conserved after the change in flight');
  // the starting push is a new run, still playing
  await set(`${W} .rg-eps`, 30); await pg.waitForTimeout(80); if (!(await pressed(`${W} .rg-play`))) errs.push('top: a new push stopped the motion');
  await pg.locator(`${W} .rg-play`).click(); }

// ---- the moon and the planets
{ const W = '.rg-w-orb';
  await set(`${W} .rg-dt`, 8000); await pg.waitForTimeout(300); if (await pressed(`${W} .rg-play`)) errs.push('orbits: a slider started the motion');
  await pg.locator(`${W} .eq-chip`).filter({ hasText: /^×16$/ }).click();
  await pg.locator(`${W} .rg-play`).click(); await pg.waitForTimeout(600);
  const days = async () => num((await txt(`${W} .rg-moon-now`)).match(/(?:day|giorno) ([\d.,]+)/)[1]);
  const d1 = await days(); if (!(d1 > 0.5)) errs.push(`orbits: not playing (${d1} days)`);
  await set(`${W} .rg-dt`, 20000); await pg.waitForTimeout(40);
  if (!(await pressed(`${W} .rg-play`))) errs.push('orbits: changing the step stopped the motion');
  const d2 = await days(); if (!(d2 >= d1)) errs.push(`orbits: changing the step restarted the clock (${d1} -> ${d2})`);
  await pg.waitForTimeout(400); if (!((await days()) > d2)) errs.push('orbits: the clock did not go on');
  await pg.locator(`${W} .eq-chip`).filter({ hasText: /Euler/ }).click(); await pg.waitForTimeout(40);
  if (!(await pressed(`${W} .rg-play`))) errs.push('orbits: switching the method stopped the motion');
  const d3 = await days(); await pg.waitForTimeout(300); if (!((await days()) > d3)) errs.push('orbits: the clock did not go on after the method changed');
  await pg.locator(`${W} .eq-chip`).filter({ hasText: /Runge/ }).click();
  await set(`${W} .rg-vf`, 90); await pg.waitForTimeout(40);
  if (!(await pressed(`${W} .rg-play`))) errs.push('orbits: a new starting speed stopped the motion');
  await pg.locator(`${W} .rg-play`).click(); }

// ---- the curve widgets: pressing play and moving a slider keeps the clock going, nothing resets it
for (const [W, sl] of [['.rg-w-seg', '.rg-x0'], ['.rg-w-seg', '.rg-g'], ['.rg-w-sq', '.rg-W']]) {
  if ((await pg.locator(`${S} ${W} ${sl}`).count()) === 0) continue;
  const tv = async () => num(await pg.locator(`${S} ${W} .rg-t`).inputValue());
  const was = await pressed(`${W} .rg-play`); if (was) await pg.locator(`${W} .rg-play`).click();
  await set(`${W} .rg-t`, 10); await set(`${W} ${sl}`, 15); await pg.waitForTimeout(250);
  if ((await tv()) !== 10) errs.push(`${W} ${sl}: a slider moved the clock of a paused widget`);
  await pg.locator(`${S} ${W} .rg-play`).click(); await pg.waitForTimeout(300); const a = await tv();
  await set(`${W} ${sl}`, 5); await pg.waitForTimeout(30);
  if (!(await pressed(`${W} .rg-play`))) errs.push(`${W} ${sl}: a slider stopped the play`);
  await pg.waitForTimeout(300); if (!((await tv()) !== a)) errs.push(`${W} ${sl}: the clock stopped after a slider`);
  await pg.locator(`${S} ${W} .rg-play`).click(); }

console.log(errs.length ? errs.join('\n') : 'LIVE TWEAK UI OK');
await b.close(); process.exit(errs.length ? 1 : 0);
