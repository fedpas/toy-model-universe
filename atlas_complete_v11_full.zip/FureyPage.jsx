// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import DictionarySection from './DictionarySection.jsx';
import ThreeGenSection from './ThreeGenSection.jsx';
import FureyFindings from './FureyFindings.jsx';
import FureyEarlier from './FureyEarlier.jsx';
import FureyHelp from './FureyHelp.jsx';
import { TabBar, TabPanel, useSub } from './StoryShell.jsx';
import { Tx } from './MathText.jsx';
import { isLearner } from './Formal.jsx';
import { fc } from './fureyCopy.js';

// Calibration 2 (Furey) is five tabs that read one at a time: the dictionary, her papers, her 2026 model, the board of Fig. 1 and the count of three generations, and what may help her.
// The sentence that says what a calibration is (C-021) is shown once, under the tab bar, on every tab; the line that names the full report closes the page (Physicist and Mathematician).
const STYLE = '.fy-calib{max-width:1000px;margin:10px auto 0;padding:0 16px;font-size:.88rem;opacity:.88}.fy-report{margin:18px auto 28px;overflow-wrap:anywhere}';
export default function FureyPage({ lang = 'en', profile = 'Young Learner', go }) {
  const [sub, setSub] = useSub('furey');
  const u = fc(lang === 'it' ? 'it' : 'en').ui;
  return <><TabBar lang={lang} page="furey" active={sub} onPick={setSub} />
    <style>{STYLE}</style><p className="fy-calib" data-calibration="furey"><Tx>{isLearner(profile) ? u.calibY : u.calib}</Tx></p>
    <TabPanel lang={lang} page="furey" id={sub} onPick={setSub} goMap={go}>
      {sub === 'dictionary' && <DictionarySection lang={lang} profile={profile} />}
      {sub === 'earlier' && <FureyEarlier lang={lang} profile={profile} />}
      {sub === 'findings' && <FureyFindings lang={lang} profile={profile} />}
      {sub === 'threegen' && <ThreeGenSection lang={lang} profile={profile} />}
      {sub === 'help' && <FureyHelp lang={lang} profile={profile} />}
    </TabPanel>
    {!isLearner(profile) && <p className="fy-calib fy-report" data-report="furey"><Tx>{u.report}</Tx></p>}</>;
}
