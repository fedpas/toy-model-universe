// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The engine of the widgets of the Schuller chapter (step 20, SchullerWidgets.jsx). Pure functions, no React. Everything is computed from the bit rule
// e_a e_b = s(a,b) e_(a xor b) of labelsEngine.js and plain integer arithmetic (BigInt where numbers grow), except the Floquet curves of the Kronig-Penney
// and Dirac-comb modes, which are floating point and are called numerical wherever they are shown. selfcheck/reports/lens_sch_check.py computes the same
// numbers in Python and writes them to lens_sch_check.json (embedded as schullerWidgetData.js); test_lens_schuller_widgets.mjs compares the two.
import { popcount as pc, bladeMul, sigVec, mul, TYPES } from './labelsEngine.js';

export { pc, sigVec, TYPES };
export const sigOf = (p, q, r = 0) => sigVec(p, q, r);
const sgn0 = s => (s === 0 ? 0 : s);   // -0 -> 0

// ================================================================ SW1: his chain (Fig. 1 of the report), the grades and the matrix rows they rest on
// grade: the report's Fig. 1 (E exact, S structural, A analogy), which is the best grade of the rows listed (test_lens_schuller_widgets.mjs recomputes it from
// translationMatrixData.js); checks: the ids of the shipped scripts behind the stone (none for a stone the atlas only reads).
export const STONES = [
  { id: 1, grade: 'S', rows: ['C1'], checks: [] },
  { id: 2, grade: 'E', rows: ['C2', 'C11'], checks: ['bridge·B4', 'Thm T16'] },
  { id: 3, grade: 'E', rows: ['C3', 'C12'], checks: ['bridge·B1', 'bridge·B2', 'bridge·B3', 'bridge·B5', 'scw·P1', 'Thm T18'] },
  { id: 4, grade: 'S', rows: ['C4'], checks: [] },
  { id: 5, grade: 'S', rows: ['C5'], checks: [] },
  { id: 6, grade: 'S', rows: ['C6'], checks: ['bridge·C1', 'bridge·C2', 'bridge·C3', 'bridge·C4', 'bridge·C5', 'bridge·C6'] },
  { id: 7, grade: 'A', rows: ['C7', 'C8'], checks: [] },
];

// ================================================================ SW4 and SW1: hyperbolicity (Thm T18(f)) and the symbol determinant (Thm T16)
export const lorentzian = (k, d) => k === 1 || d === 1;
export const waveKind = (k, d) => (lorentzian(k, d) ? 'hyperbolic' : Math.min(k, d) === 0 ? 'elliptic' : 'ultrahyperbolic');
// q -> B(q,h)^2 - P(h) P(q) as a matrix (S h)(S h)^T - P(h) S, for the diagonal form S
export function hypMatrix(S, h) {
  const n = S.length, Sh = h.map((x, i) => S[i] * x), Ph = h.reduce((a, x, i) => a + S[i] * x * x, 0);
  return { M: Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => Sh[i] * Sh[j] - (i === j ? Ph * S[i] : 0))), Ph };
}
// an explicit q with B(q,h)^2 - P(h)P(q) < 0, built from two generators of the sign of P(h) (null when the cell has fewer than two)
export function witness(S, h, Ph) {
  const s = Ph > 0 ? 1 : -1, I = S.map((x, i) => (x === s ? i : -1)).filter(i => i >= 0); if (I.length < 2) return null;
  const [i, j] = I, q = Array(S.length).fill(0);
  if (h[i] === 0 && h[j] === 0) q[i] = 1; else { q[i] = h[j]; q[j] = -h[i]; }
  const B = q.reduce((a, x, t) => a + S[t] * x * h[t], 0), Pq = q.reduce((a, x, t) => a + S[t] * x * x, 0);
  return B * B - Ph * Pq < 0 ? q : null;
}
// the map of the r = 0 cells, n = nMin..nMax: every Lorentzian cell with its certificate h = e_t, every other cell with a witness for every h in {-1,0,1}^n
export function hypMap(nMin = 2, nMax = 9) {
  const cells = {}; let certOk = true, witOk = true, hyp = 0;
  for (let n = nMin; n <= nMax; n++) for (let d = 0; d <= n; d++) {
    const k = n - d, S = sigVec(k, d); cells[`${k},${d}`] = waveKind(k, d);
    if (lorentzian(k, d)) {
      const h = Array(n).fill(0); h[k === 1 ? 0 : n - 1] = 1; const { M, Ph } = hypMatrix(S, h); hyp++;
      certOk = certOk && Ph !== 0 && M.every((r, i) => r.every((v, j) => (i === j ? v >= 0 : v === 0)));
    } else {
      const h = Array(n).fill(-1);
      for (;;) {
        const Ph = h.reduce((a, x, i) => a + S[i] * x * x, 0);
        if (Ph !== 0 && !witness(S, h, Ph)) witOk = false;
        let t = 0; while (t < n && h[t] === 1) { h[t] = -1; t++; } if (t === n) break; h[t]++;
      }
    }
  }
  return { cells, hyperbolic: hyp, ok: certOk && witOk };
}
// the left-regular matrix of a multivector x ({label: integer}) in the signature sq, as BigInt: column c is x e_c
export function leftMatrix(x, sq) {
  const N = 1 << sq.length, M = Array.from({ length: N }, () => Array(N).fill(0n));
  for (let c = 0; c < N; c++) for (const [a, u] of Object.entries(x)) { if (!u) continue; const [d, s] = bladeMul(+a, c, sq); if (s) M[d][c] += BigInt(s) * BigInt(u); }
  return M;
}
// exact determinant (Bareiss, fraction-free, BigInt)
export function bareissDet(M0) {
  const M = M0.map(r => r.slice()), n = M.length; let sign = 1n, prev = 1n;
  for (let k = 0; k < n - 1; k++) {
    if (M[k][k] === 0n) { let sw = -1; for (let i = k + 1; i < n; i++) if (M[i][k] !== 0n) { sw = i; break; } if (sw < 0) return 0n; [M[k], M[sw]] = [M[sw], M[k]]; sign = -sign; }
    for (let i = k + 1; i < n; i++) for (let j = k + 1; j < n; j++) M[i][j] = (M[i][j] * M[k][k] - M[i][k] * M[k][j]) / prev;
    prev = M[k][k];
  }
  return sign * M[n - 1][n - 1];
}
// P = sum mom_i e_i squared by the bit rule: its scalar part and the size of the rest (0: P^2 is a scalar)
export function squareVec(S, mom) { const X = new Float64Array(1 << S.length); mom.forEach((v, i) => { X[1 << i] = v; }); const Y = mul(X, X, S); let rest = 0; for (let a = 1; a < Y.length; a++) rest += Math.abs(Y[a]); return { scalar: Y[0], rest }; }
export const quadQ = (S, mom) => mom.reduce((a, x, i) => a + S[i] * x * x, 0);
// det(P - m) on the regular module of Cl(k,d,r), P = sum mom_i e_i, against (m^2 - Qbar)^(2^(n-1)) with Qbar = P^2 (a null momentum never enters)
export function symbolDet(S, mom, m) {
  const n = S.length, x = {}; mom.forEach((v, i) => { if (v) x[1 << i] = v; }); x[0] = (x[0] || 0) - m;
  const Q = quadQ(S, mom), det = bareissDet(leftMatrix(x, S)), exp = 2 ** (n - 1), want = (BigInt(m * m - Q)) ** BigInt(exp);
  return { Q, det, exp, want, ok: det === want };
}
// an extra generator f of square eps carrying the momentum mf: P + mf f in the signature S + [eps]; its square by the bit rule, and the determinant
export function extraGen(S, mom, mf, eps, withDet = true) {
  const n = S.length, T = [...S, eps], x = {}; mom.forEach((v, i) => { if (v) x[1 << i] = v; }); if (mf) x[1 << n] = mf;
  const X = new Float64Array(1 << (n + 1)); for (const [a, v] of Object.entries(x)) X[+a] = v;
  const Y = mul(X, X, T); let rest = 0; for (let a = 1; a < Y.length; a++) rest += Math.abs(Y[a]);
  const Q = quadQ(S, mom), want = Q + eps * mf * mf;
  const det = withDet ? bareissDet(leftMatrix(x, T)) : null, wantDet = BigInt(want) ** BigInt(2 ** n);
  return { square: Y[0], rest, Q, want, det, wantDet, ok: Y[0] === want && rest === 0 && (!withDet || det === wantDet) };
}

// ================================================================ SW2: one table, three squares
export function productTable(sq) {
  const N = 1 << sq.length; return Array.from({ length: N }, (_, a) => Array.from({ length: N }, (_, b) => { const [c, s] = bladeMul(a, b, sq); return { label: c, sign: sgn0(s) }; }));
}
export function tableStats(sq) {
  const n = sq.length, N = 1 << n, F = N - 1, T = productTable(sq); let zeros = 0, minus = 0, pair = 0, eF = 0;
  for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) { const { label, sign } = T[a][b]; if (sign === 0) zeros++; if (sign === -1) minus++; if (sign && label === F) pair++; }
  for (let a = 0; a < N; a++) if (T[F][a].sign) eF++;
  return { zeros, minus, eF_sq: T[F][F].sign, eF_rank: eF, pair };
}
export const bladeLabel = (a, n) => (a === 0 ? '1' : 'e' + Array.from({ length: n }, (_, i) => (a >> i & 1 ? String(i + 1) : '')).join(''));
export const bitString = (a, n) => Array.from({ length: n }, (_, i) => (a >> i & 1 ? '1' : '0')).join('');

// ================================================================ SW3: monomial matrices (a column is [row, sign]; sign 0: a zero column), exact ranks and commutants
export const mono = M => M.map((_, j) => { for (let i = 0; i < M.length; i++) if (M[i][j]) return [i, M[i][j]]; return [-1, 0]; });
export const mmul = (A, B) => B.map(([r, s]) => (s === 0 || A[r][1] === 0 ? [-1, 0] : [A[r][0], s * A[r][1]]));
export const mid = (N, s = 1) => Array.from({ length: N }, (_, j) => (s ? [j, s] : [-1, 0]));
export const mneg = A => A.map(([r, s]) => (s ? [r, -s] : [r, s]));
export const meq = (A, B) => A.length === B.length && A.every(([r, s], j) => s === B[j][1] && (s === 0 || r === B[j][0]));
export const mprod = (ms, N = 16) => ms.reduce((P, M) => mmul(P, M), mid(N));
export const dense = A => { const N = A.length, D = Array.from({ length: N }, () => Array(N).fill(0)); A.forEach(([r, s], j) => { if (s) D[r][j] = s; }); return D; };
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a; };
// exact rank of integer vectors (fraction-free elimination; Bareiss division keeps the entries minors, small here)
export function rankInt(rows0) {
  const rows = rows0.filter(r => r.some(Boolean)).map(r => r.slice()); if (!rows.length) return 0;
  const nc = rows[0].length; let rk = 0, prev = 1;
  for (let c = 0; c < nc && rk < rows.length; c++) {
    let p = -1; for (let i = rk; i < rows.length; i++) if (rows[i][c]) { p = i; break; } if (p < 0) continue;
    [rows[rk], rows[p]] = [rows[p], rows[rk]]; const P = rows[rk];
    for (let i = rk + 1; i < rows.length; i++) { const f = rows[i][c]; for (let j = 0; j < nc; j++) { const v = (rows[i][j] * P[c] - f * P[j]) / prev; if (!Number.isSafeInteger(v)) throw new Error('rankInt: overflow'); rows[i][j] = v; } }
    prev = P[c]; rk++;
  }
  return rk;
}
export function monoRank(mats) {
  const groups = new Map();
  for (const M of mats) { if (!M.some(([, s]) => s)) continue; const key = M.map(([r, s]) => (s ? r : -1)).join(','); if (!groups.has(key)) groups.set(key, []); groups.get(key).push(M.map(([, s]) => s)); }
  let r = 0; for (const v of groups.values()) r += rankInt(v); return r;
}
// the dimension of {X : X M = M X for every M} in M_N(Q): N*N unknowns, one sparse integer equation per entry, exact elimination (rows kept primitive)
export function commutantDim(mats, N = 16) {
  const piv = new Map();
  for (const M of mats) {
    const inv = new Map(); M.forEach(([r, s], t) => { if (s) inv.set(r, [t, s]); });
    for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
      let row = new Map(); const [rj, sj] = M[j];
      const add = (k, v) => { const w = (row.get(k) || 0) + v; if (w) row.set(k, w); else row.delete(k); };
      if (sj) add(i * N + rj, sj); if (inv.has(i)) { const [t, st] = inv.get(i); add(t * N + j, -st); }
      while (row.size) {
        const c = Math.min(...row.keys());
        if (!piv.has(c)) { let g = 0; for (const v of row.values()) g = gcd(g, v); const P = new Map(); for (const [k, v] of row) P.set(k, v / g); piv.set(c, P); break; }
        const P = piv.get(c), a = P.get(c), b = row.get(c), nr = new Map();
        for (const [k, v] of row) nr.set(k, v * a); for (const [k, v] of P) { const w = (nr.get(k) || 0) - b * v; if (w) nr.set(k, w); else nr.delete(k); }
        let g = 0; for (const v of nr.values()) g = gcd(g, v); if (g > 1) for (const [k, v] of nr) nr.set(k, v / g);
        for (const v of nr.values()) if (!Number.isSafeInteger(v)) throw new Error('commutantDim: overflow');
        row = nr;
      }
    }
  }
  return N * N - piv.size;
}
// the eight gamma matrices of fibre_check.py G3: the first 8 mutually anticommuting Kronecker words over {I, SX, SZ, EE} with square -1, in the order of the search
let GAMMAS = null;
export function gammas() {
  if (GAMMAS) return GAMMAS;
  const base = [[[1, 0], [0, 1]], [[0, 1], [1, 0]], [[1, 0], [0, -1]], [[0, 1], [-1, 0]]];
  const kron = (A, B) => { const a = A.length, b = B.length; return Array.from({ length: a * b }, (_, i) => Array.from({ length: a * b }, (_, j) => A[Math.floor(i / b)][Math.floor(j / b)] * B[i % b][j % b])); };
  const cands = [];
  for (let w = 0; w < 256; w++) {
    const word = [w >> 6 & 3, w >> 4 & 3, w >> 2 & 3, w & 3]; let M = [[1]]; for (const i of word) M = kron(M, base[i]);
    const m = mono(M); if (meq(mmul(m, m), mid(16, -1))) cands.push([word, m]);
  }
  const search = (cur, start) => { if (cur.length === 8) return cur; for (let i = start; i < cands.length; i++) if (cur.every(g => meq(mmul(cands[i][1], g[1]), mneg(mmul(g[1], cands[i][1]))))) { const r = search([...cur, cands[i]], i + 1); if (r) return r; } return null; };
  return (GAMMAS = search([], 0));
}
// keep the 8 fixed: base = the algebra of the first k gammas, fibre = its commutant in M_16(R) (fibre_check.py G3; lens_sch_check.py P3)
export function outsideInside(k) {
  const G = gammas().map(g => g[1]), base = []; for (let a = 0; a < 1 << k; a++) base.push(mprod(G.filter((_, i) => i < k && (a >> i & 1))));
  const dimB = monoRank(base), dimC = k ? commutantDim(G.slice(0, k)) : 256, om = mprod(G.slice(0, k)), m = 8 - k;
  const fg = k % 2 === 0 ? G.slice(k).map(g => mmul(om, g)) : [...G.slice(k).flatMap((g, i) => G.slice(k + i + 1).map(h => mmul(g, h))), om];
  const comm = fg.every(f => G.slice(0, k).every(b => meq(mmul(f, b), mmul(b, f))));
  const seen = new Map([[JSON.stringify(mid(16)), mid(16)]]); let front = [mid(16)];
  while (front.length) { const nw = []; for (const X of front) for (const f of fg) { const Y = mmul(X, f), key = JSON.stringify(Y); if (!seen.has(key)) { seen.set(key, Y); nw.push(Y); } } front = nw; }
  const dimF = monoRank([...seen.values()]), dimBB = fg.length ? commutantDim(fg) : 256;
  const S8 = sigVec(0, 8), Sk = sigVec(0, k); let bitc = 0, ctr = 0;
  for (let a = 0; a < 256; a++) { let c = true; for (let i = 0; i < k; i++) if (bladeMul(a, 1 << i, S8)[1] !== bladeMul(1 << i, a, S8)[1]) { c = false; break; } if (c) bitc++; }
  for (let a = 0; a < 1 << k; a++) { let c = true; for (let i = 0; i < k; i++) if (bladeMul(a, 1 << i, Sk)[1] !== bladeMul(1 << i, a, Sk)[1]) { c = false; break; } if (c) ctr++; }
  const baseType = TYPES[((-k % 8) + 8) % 8]; let fibreType, fibre;
  if (k % 2 === 0) { const hs = fg.length ? mmul(fg[0], fg[0])[0][1] : null; fibreType = m === 0 ? 'R' : TYPES[(((hs === 1 ? m : -m) % 8) + 8) % 8]; fibre = m === 0 ? 'R' : hs === 1 ? `Cl(${m},0)` : `Cl(0,${m})`; }
  else { const w2 = mmul(om, om)[0][1], inner = TYPES[((-(m - 1) % 8) + 8) % 8]; fibreType = w2 === -1 ? (inner === 'R' || inner === 'H' ? 'C' : '?') : inner + '2'; fibre = `Cl(0,${m - 1}) x ` + (w2 === -1 ? 'C' : 'R2'); }
  return { k, outside: 2 ** k, inside: 2 ** (8 - k), base_dim: dimB, fibre_dim: dimC, fibre_dim_bitrule: bitc, fibre_span: dimF, double_dim: dimBB, centre: ctr, base_type: baseType, fibre_type: fibreType, fibre, comm, gens: fg.length };
}
// left and right actions of A = Cl(p,q,r) on itself (fibre_check.py G1, G2; lens_sch_check.py P3b)
export function leftRight(p, q, r) {
  const S = sigVec(p, q, r), n = S.length, N = 1 << n;
  const L = [], R = [], Rt = [];
  for (let i = 0; i < n; i++) {
    const Li = [], Ri = [], Rti = [];
    for (let x = 0; x < N; x++) { const [c1, s1] = bladeMul(1 << i, x, S), [c2, s2] = bladeMul(x, 1 << i, S); Li.push(s1 ? [c1, s1] : [-1, 0]); Ri.push(s2 ? [c2, s2] : [-1, 0]); Rti.push(s2 ? [c2, s2 * (pc(x) & 1 ? -1 : 1)] : [-1, 0]); }
    L.push(Li); R.push(Ri); Rt.push(Rti);
  }
  let rel = true;
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) rel = rel && meq(mmul(L[i], R[j]), mmul(R[j], L[i])) && meq(mmul(L[i], Rt[j]), mneg(mmul(Rt[j], L[i])));
  for (let i = 0; i < n; i++) rel = rel && meq(mmul(L[i], L[i]), mid(N, sgn0(S[i]))) && meq(mmul(R[i], R[i]), mid(N, sgn0(S[i]))) && meq(mmul(Rt[i], Rt[i]), mid(N, sgn0(-S[i])));
  const pairs = (A, B) => { const out = []; for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) out.push(mprod([...A.filter((_, i) => a >> i & 1), ...B.filter((_, i) => b >> i & 1)], N)); return out; };
  let ctr = 0; for (let a = 0; a < N; a++) { let c = true; for (let i = 0; i < n; i++) { const x = bladeMul(a, 1 << i, S), y = bladeMul(1 << i, a, S); if (x[0] !== y[0] || sgn0(x[1]) !== sgn0(y[1])) { c = false; break; } } if (c) ctr++; }
  return { S, n, N, L, R, Rt, rel, rank_LRt: monoRank(pairs(L, Rt)), rank_LR: monoRank(pairs(L, R)), centre: ctr, Rt_eq_L: [...Array(n).keys()].filter(i => L[i].every(([r2, s], x) => meq([[r2, s]], [Rt[i][x]]))) };
}

// ================================================================ SW5: Floquet (Thm T19). Exact SL(2,Z), and the numerical Kronig-Penney / Dirac comb modes
const fracStr = (num, den) => { if (num === 0) return '0'; const g = gcd(num, den), a = num / g, b = den / g; return b === 1 ? String(a) : `${a}/${b}`; };
// M = g + x1 e1 + x2 e2 + x12 e12 in Cl(2,0) = M_2(R) with e1 = diag(1,-1), e2 = [[0,1],[1,0]], e12 = [[0,1],[-1,0]]: coordinates are halves of integers
export function sl2Class(M) {
  const [[a, b], [c, d]] = M, t = a + d, x1 = a - d, x2 = b + c, x12 = b - c, X2x4 = x1 * x1 + x2 * x2 - x12 * x12, Xzero = !x1 && !x2 && !x12;
  const cls = X2x4 < 0 ? 'band' : X2x4 > 0 ? 'gap' : Xzero ? 'scalar' : 'edge';
  return { cls, X2: fracStr(X2x4, 4), half_trace: fracStr(t, 2), det: a * d - b * c, coords: [t, x1, x2, x12], X2x4, t };
}
export const mat2 = (A, B) => [[A[0][0] * B[0][0] + A[0][1] * B[1][0], A[0][0] * B[0][1] + A[0][1] * B[1][1]], [A[1][0] * B[0][0] + A[1][1] * B[1][0], A[1][0] * B[0][1] + A[1][1] * B[1][1]]];
export function traceSeq(M, N = 6) { let P = [[1, 0], [0, 1]]; const out = []; for (let i = 0; i < N; i++) { P = mat2(P, M); out.push(P[0][0] + P[1][1]); } return out; }
export const SL2_GENS = { T: [[1, 1], [0, 1]], Ti: [[1, -1], [0, 1]], U: [[1, 0], [1, 1]], Ui: [[1, 0], [-1, 1]], S: [[0, -1], [1, 0]] };
export const wordMatrix = w => w.reduce((P, g) => mat2(P, SL2_GENS[g]), [[1, 0], [0, 1]]);
export function halfTraceComb(E, g, l) {
  if (E > 1e-12) { const k = Math.sqrt(E); return Math.cos(k * l) + g / (2 * k) * Math.sin(k * l); }
  if (E < -1e-12) { const q = Math.sqrt(-E); return Math.cosh(q * l) + g / (2 * q) * Math.sinh(q * l); }
  return 1 + g * l / 2;
}
// one piece of length l at height V, as a 2x2 matrix (the same branches as the script)
export function pieceMatrix(E, l, V) {
  const kap = E - V;
  if (kap > 1e-14) { const k = Math.sqrt(kap); return [[Math.cos(k * l), Math.sin(k * l) / k], [-k * Math.sin(k * l), Math.cos(k * l)]]; }
  if (kap < -1e-14) { const q = Math.sqrt(-kap); return [[Math.cosh(q * l), Math.sinh(q * l) / q], [q * Math.sinh(q * l), Math.cosh(q * l)]]; }
  return [[1, l], [0, 1]];
}
export function halfTraceSteps(E, cell) { let M = [[1, 0], [0, 1]]; for (const [l, V] of cell) M = mat2(pieceMatrix(E, l, V), M); return (M[0][0] + M[1][1]) / 2; }
export function bandEdges(f, lo, hi, steps) {
  const out = [], h = (hi - lo) / steps; let prev = Math.abs(f(lo)) <= 1;
  for (let i = 1; i <= steps; i++) {
    const e0 = lo + (i - 1) * h, e1 = lo + i * h, cur = Math.abs(f(e1)) <= 1;
    if (cur !== prev) { let a = e0, b = e1; for (let t = 0; t < 80; t++) { const m = (a + b) / 2; if ((Math.abs(f(m)) <= 1) === prev) a = m; else b = m; } out.push((a + b) / 2); }
    prev = cur;
  }
  return out;
}
export const G5_CELL = [[0.8, 0.0], [0.5, 5.0]];
// a 2x2 matrix as a multivector of Cl(2,0) (labels 0, e1 = 1, e2 = 2, e12 = 3) and back; products by the bit rule
export const toMv = M => { const X = new Float64Array(4); X[0] = (M[0][0] + M[1][1]) / 2; X[1] = (M[0][0] - M[1][1]) / 2; X[2] = (M[0][1] + M[1][0]) / 2; X[3] = (M[0][1] - M[1][0]) / 2; return X; };
export const mvMul2 = (X, Y) => mul(X, Y, [1, 1]);
export const xSquare = X => { const R = new Float64Array(4); R[1] = X[1]; R[2] = X[2]; R[3] = X[3]; const Y = mul(R, R, [1, 1]); return { s: Y[0], rest: Math.abs(Y[1]) + Math.abs(Y[2]) + Math.abs(Y[3]), Xnorm: Math.abs(X[1]) + Math.abs(X[2]) + Math.abs(X[3]) }; };
// the Dirac comb cell as a product of two Cl(2,0) multivectors (kick times flight): its scalar part, against the closed form
export function combCell(E, g, l) {
  const flight = toMv(pieceMatrix(E, l, 0)), kick = toMv([[1, 0], [g, 1]]), cell = mvMul2(kick, flight);
  return { flight, kick, cell, half: cell[0], closed: halfTraceComb(E, g, l), xs: xSquare(cell), xsFlight: xSquare(flight), xsKick: xSquare(kick) };
}
export const floquetClass = (half, eps = 1e-9) => (Math.abs(half) < 1 - eps ? 'band' : Math.abs(half) > 1 + eps ? 'gap' : 'edge');

// ================================================================ SW6: seats (Fock space of three modes, Cl(0,0,3) acting on the labels) and SW7: three magnets (Cl(3,0))
// putting a particle into seat k of the pattern a: the all-null bit rule e_k e_a (0 when the seat is full)
export function putParticle(a, k) { const [c, s] = bladeMul(1 << k, a, [0, 0, 0]); return s ? [c, sgn0(s)] : null; }
export function takeParticle(a, k) { if (!(a >> k & 1)) return null; for (let c = 0; c < 8; c++) { const r = putParticle(c, k); if (r && r[0] === a) return [c, r[1]]; } return null; }
export const byNumber = (n = 3) => Array.from({ length: n + 1 }, (_, j) => Array.from({ length: 1 << n }, (_, a) => a).filter(a => pc(a) === j).length);
// eps_k and iota_k (its transpose) as 8x8 integer matrices; the anticommutators and squares
export function fockMatrices(n = 3) {
  const N = 1 << n, Z = () => Array.from({ length: N }, () => Array(N).fill(0));
  const eps = [...Array(n).keys()].map(k => { const M = Z(); for (let a = 0; a < N; a++) { const r = putParticle(a, k); if (r) M[r[0]][a] = r[1]; } return M; });
  const iot = eps.map(M => M[0].map((_, j) => M.map(r => r[j])));
  const mm = (A, B) => A.map((r, i) => B[0].map((_, j) => r.reduce((s, v, t) => s + v * B[t][j], 0)));
  const ad = (A, B, s = 1) => A.map((r, i) => r.map((v, j) => v + s * B[i][j])), isI = (A, c) => A.every((r, i) => r.every((v, j) => v === (i === j ? c : 0)));
  let car = true; for (let k = 0; k < n; k++) for (let l = 0; l < n; l++) car = car && isI(ad(mm(eps[k], iot[l]), mm(iot[l], eps[k])), k === l ? 1 : 0);
  const excl = eps.every(M => isI(mm(M, M), 0)), plusMinus = eps.every((M, k) => isI(mm(ad(M, iot[k]), ad(M, iot[k])), 1) && isI(mm(ad(M, iot[k], -1), ad(M, iot[k], -1)), -1));
  let Nop = Z(); for (let k = 0; k < n; k++) Nop = ad(Nop, mm(eps[k], iot[k]));
  return { eps, iot, car, excl, plusMinus, number: Nop.map((r, i) => r[i]), numberOk: isI(Nop.map((r, i) => r.map((v, j) => (i === j ? v - pc(i) : v))), 0) };
}
// three magnets: the projector (1 + e)/2 of a direction (up-down = e3, left-right = e1, front-back = e2), probabilities exact (dyadic) by the bit rule of Cl(3,0)
export const DIRS = ['z', '-z', 'x', '-x', 'y', '-y'];
const AX = { z: 4, x: 1, y: 2 };
export const projector = d => { const P = new Float64Array(8); P[0] = 0.5; P[AX[d.slice(-1)]] = d[0] === '-' ? -0.5 : 0.5; return P; };
export function passProb(u, v) { const x = mul(projector(v), projector(u), [1, 1, 1])[0] / 0.5; return x === 1 ? '1' : x === 0.5 ? '1/2' : x === 0 ? '0' : String(x); }
export const probValue = s => (s === '1/2' ? 0.5 : +s);
export function magnets(dirs) { const steps = []; for (let i = 1; i < dirs.length; i++) steps.push(passProb(dirs[i - 1], dirs[i])); return { steps, total: steps.reduce((a, s) => a * probValue(s), 1) }; }
export function zxCommute() { const S = [1, 1, 1], z = mul(projector('z'), projector('x'), S), x = mul(projector('x'), projector('z'), S); const e31 = bladeMul(4, 1, S), e13 = bladeMul(1, 4, S); return { same: z.every((v, i) => v === x[i]), e3e1: e31, e1e3: e13 }; }
// two qubits: the 16 blades of Cl(4,0) from the Jordan-Wigner Majoranas XI, YI, ZX, ZY, as Pauli strings up to a phase (Gaussian integers, exact)
export function pauliTable() {
  const P = { I: [[[1, 0], [0, 0]], [[0, 0], [1, 0]]], X: [[[0, 0], [1, 0]], [[1, 0], [0, 0]]], Y: [[[0, 0], [0, -1]], [[0, 1], [0, 0]]], Z: [[[1, 0], [0, 0]], [[0, 0], [-1, 0]]] };
  const cm = (x, y) => [x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0]];
  const k2 = (A, B) => Array.from({ length: 4 }, (_, i) => Array.from({ length: 4 }, (_, j) => cm(A[i >> 1][j >> 1], B[i & 1][j & 1])));
  const m4 = (A, B) => A.map((r, i) => B[0].map((_, j) => r.reduce((s, v, t) => { const p = cm(v, B[t][j]); return [s[0] + p[0], s[1] + p[1]]; }, [0, 0])));
  const gam = [k2(P.X, P.I), k2(P.Y, P.I), k2(P.Z, P.X), k2(P.Z, P.Y)], PH = [[[1, 0], '1'], [[0, 1], 'i'], [[-1, 0], '-1'], [[0, -1], '-i']];
  const strings = []; for (const s1 of 'IXYZ') for (const s2 of 'IXYZ') strings.push([s1 + s2, k2(P[s1], P[s2])]);
  const out = {};
  for (let a = 0; a < 16; a++) {
    let M = Array.from({ length: 4 }, (_, i) => Array.from({ length: 4 }, (_, j) => [i === j ? 1 : 0, 0])); for (let i = 0; i < 4; i++) if (a >> i & 1) M = m4(M, gam[i]);
    const hit = []; for (const [s, Pm] of strings) for (const [ph, nm] of PH) if (M.every((r, i) => r.every((v, j) => { const w = cm(ph, Pm[i][j]); return v[0] === w[0] && v[1] === w[1]; }))) hit.push([s, nm]);
    const herm = M.every((r, i) => r.every((v, j) => v[0] === M[j][i][0] && v[1] === -M[j][i][1]));
    const sq = bladeMul(a, a, [1, 1, 1, 1])[1];
    out[a] = { pauli: hit.length === 1 ? hit[0][0] : '?', phase: hit.length === 1 ? hit[0][1] : '?', square: sq, hermitian: herm };
  }
  return out;
}
