// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { STORY } from './storyCopy.js';

// The status of a statement is shown by a badge, never by a word: one small drawn icon per flag, each with its own shape (so that colour is never the only carrier),
// the colour of the flag on top. The word stays only as the accessible name (aria-label) and as the hover text (title), and in the one legend of each page.
//   standard  an open book          textbook mathematics or physics
//   checked   a tick in a ring      a script recomputes it
//   ours      a lamp                a reading we propose
//   open      a dashed ring, "?"    not established
//   input     a plug                a datum or choice the algebra does not supply
// The wrapper keeps the classes `tag <flag>` and the attribute data-flag, so the reader filter (readerFilter.js) and the theme (theme.js) see the same selectors as before.
export const FLAGS = ['standard', 'checked', 'ours', 'open', 'input'];
// 16 x 16 box, stroke only (currentColor), round caps and joins
export const ICON_PATHS = {
  standard: ['M8 4.4v8.4', 'M8 4.4C6.6 3.3 4.5 3 2.4 3.4v8.7c2.1-.4 4.2-.1 5.6.9 1.4-1 3.5-1.3 5.6-.9V3.4C11.5 3 9.4 3.3 8 4.4z'],
  checked: ['M4.9 8.3l2.2 2.3 4.1-4.9'],
  ours: ['M8 2.1a4 4 0 0 0-2.3 7.3c.5.4.8.9.8 1.5v.3h3v-.3c0-.6.3-1.1.8-1.5A4 4 0 0 0 8 2.1z', 'M6.4 13.1h3.2', 'M7 14.8h2'],
  open: ['M6.2 6.3a1.9 1.9 0 1 1 2.7 1.7c-.6.3-.9.7-.9 1.4', 'M8 11.5v.1'],
  input: ['M5.6 2v3.2', 'M10.4 2v3.2', 'M4 5.2h8v2.2a4 4 0 0 1-8 0z', 'M8 11.4V14.2'],
};
const RING = { checked: <circle cx="8" cy="8" r="6.6" />, open: <circle cx="8" cy="8" r="6.6" strokeDasharray="2.2 1.9" /> };
// `strings` is the story record to read the words from (the Young Learner's own record has plainer help); default: STORY[lang]
export const flagWord = (flag, lang = 'en', strings) => ((strings || STORY[lang] || STORY.en).tags[flag]) || flag;
export const flagHelp = (flag, lang = 'en', strings) => ((strings || STORY[lang] || STORY.en).tagHelp[flag]) || '';

// the drawing alone (no wrapper): used inside lines that already sit in a tagged chip
export function StatusIcon({ flag, size = 15 }) {
  return <svg className="sb-ic" width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
    {RING[flag] || null}{(ICON_PATHS[flag] || []).map((d, i) => <path key={i} d={d} />)}
  </svg>;
}
// one badge: <span class="tag sb checked" role="img" aria-label="checked" title="checked: ...">
//   `label` replaces the accessible name and the hover text where a row says more than the flag word ("agrees exactly"); `cls` adds classes (the row chips of the Forque, Spin, Spring and Rigid pages)
export function StatusBadge({ flag, lang = 'en', size = 15, strings, label, cls }) {
  const w = label || flagWord(flag, lang, strings), h = label ? '' : flagHelp(flag, lang, strings);
  return <span className={'tag sb ' + flag + (cls ? ' ' + cls : '')} data-flag={flag} role="img" aria-label={w} title={h ? w + ': ' + h : w}><StatusIcon flag={flag} size={size} /></span>;
}
// the verdict of an independent verifier on a theorem: a tick (verified) or a tick with the open ring (verified, with gaps); the word is the accessible name and the hover text
export const VERDICT_FLAGS = { verified: ['checked'], gaps: ['checked', 'open'] };
export const VerdictMark = ({ v, word, size = 14 }) => <span className={'rs-ver v-' + v} data-ver={v} role="img" aria-label={word} title={word} style={{ display: 'inline-flex', gap: 2, verticalAlign: 'middle' }}>{(VERDICT_FLAGS[v] || ['open']).map(f => <StatusIcon key={f} flag={f} size={size} />)}</span>;
// a row of badges for a list of flags; `l` is accepted for the sections that name the language parameter l
export const Tags = ({ kinds, lang, l, strings }) => <>{[].concat(kinds || []).filter(Boolean).map(k => <StatusBadge key={k} flag={k} lang={lang || l || 'en'} strings={strings} />)}</>;
// the legend: one badge, its word and its meaning, per flag
export const Legend = ({ lang = 'en', flags = FLAGS, strings }) => <>{flags.map(k => <p key={k} className="sb-leg"><StatusBadge flag={k} lang={lang} strings={strings} /> <b>{flagWord(k, lang, strings)}</b> · {flagHelp(k, lang, strings)}</p>)}</>;
