// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The five widgets of the category lens (step 18: what is label 0?) and the box of their check script. Props { lang, profile } (profile: 'Young Learner',
// 'Physicist' or 'Mathematician'); each root is <div class="ln-card" data-widget="CW1"> ... and the chapter (CategorySection.jsx) places it at its own anchor.
//   CW1 the label-0 card (where does the zero hide?)   CW2 every corner has an opposite (the complement pairing, a Frobenius duality)
//   CW3 four moves between boxes                        CW4 the top of the ladder (is 8 a wall?)        CW5 two kinds of zero (paired and unpaired)
//   CW6 (optional) sign the cube: 128 ways, one gauge orbit of the bit-rule sign (cat·K1a–K1d)
//   CategoryWidgetsScript: download / copy of selfcheck/reports/lens_cat_check.py (the checks catw·P1 ... catw·P6)
// Every number is computed in the browser by categoryEngine.js (live) and, where the script covers the case, shown beside the stored output of
// lens_cat_check.py (categoryWidgetData.js, made by selfcheck/regen_lens_category_widgets.sh); the badge says live, stored or live = stored. The tagged lines
// are the fixed sentences of categoryWidgetsCopy.js (claims LNC-101 ...); the readouts with the reader's numbers carry no tag.
import React, { useId, useMemo, useState } from 'react';
import * as E from './categoryEngine.js';
import { RAILS } from './labelsEngine.js';
import { CWC, CHECK_IDS } from './categoryWidgetsCopy.js';
import STORED from './categoryWidgetData.js';
import { LENS_CAT_PY } from './categoryWidgetsSelfcheckSource.js';
import { Pts, ScriptBox } from './LensKit.jsx';
import { Tx } from './MathText.jsx';
import { stepAudience } from './steps.js';

const LG = lang => (lang === 'it' ? 'it' : 'en');
const isYL = profile => profile === 'Young Learner';
const COL = { lit: '#fbbf24', pick: '#60a5fa', opp: '#34d399', bad: '#f87171', acc: '#4aa8ff', neg: '#f87171', pos: '#34d399' };
const keyAct = f => e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); f(); } };
const sigName = ([p, q, r]) => (r ? `Cl(${p},${q},${r})` : `Cl(${p},${q})`);
const pqrArr = eps => { const x = E.pqrOf(eps); return [x.p, x.q, x.r]; };
const lab = (a, n) => (a === 0 ? '1' : 'e_{' + Array.from({ length: n }, (_, i) => (a >> i & 1 ? String(i + 1) : '')).join('') + '}');
const labPlain = (a, n) => E.labelName(a, n);
const mvTxt = (o, n) => { const ks = Object.keys(o).map(Number).sort((a, b) => a - b); if (!ks.length) return '0'; return ks.map((k, i) => { const c = o[k], s = c < 0 ? '−' : '+', m = Math.abs(c), body = k === 0 ? String(m) : `${m === 1 ? '' : m + ' '}${lab(k, n)}`; return i === 0 ? (c < 0 ? '−' : '') + body : ` ${s} ${body}`; }).join(''); };
const sameJSON = (a, b) => JSON.stringify(a) === JSON.stringify(b);

export const CW_STYLE = `
.cw h4{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 10px;margin:.1em 0 .4em}.cw .cw-lede{font-size:.92em;margin:.3em 0 .5em}
.cw .cw-sw{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0}.cw .cw-s{min-width:2.6em}.cw .cw-s b{display:inline-block;min-width:1.1ch;text-align:center;font-size:1.1em}.cw .cw-s[data-sq="0"]{border-style:dashed}
.cw .cw-pic{width:100%;max-width:460px;height:auto;display:block;margin:6px auto}.cw .cw-pic.cw-small{max-width:170px}.cw .cw-pic.cw-gram{max-width:230px;display:inline-block;margin:4px}
.cw .cw-out{font-size:.9em;margin:.35em 0}.cw .cw-row{display:flex;flex-wrap:wrap;gap:12px}.cw .cw-col{flex:1 1 250px;min-width:0}
.cw .cw-corner{cursor:pointer}.cw .cw-corner .cw-ring{pointer-events:all}.cw .cw-corner:focus{outline:none}.cw .cw-corner:focus-visible .cw-ring{stroke:#4aa8ff;stroke-width:3;stroke-opacity:1}
.cw .cw-step{display:inline-flex;align-items:center;gap:4px;margin:2px 12px 2px 0;font-size:.85em}.cw .cw-step output{min-width:2ch;text-align:center;font-family:ui-monospace,monospace}
.cw .cw-step button{min-width:2.2em;padding:2px 6px;margin:0}.cw .cw-trail{font-size:.85em;margin:.3em 0;padding-left:1.4em}.cw .cw-jam{color:#f87171;font-weight:600}
.cw .cw-hint{font-size:.8em;opacity:.8}.cw .ln-tab td,.cw .ln-tab th{padding-right:10px}.cw .cw-sub{margin:.8em 0 .3em;font-size:.9em}
.cw .ln-sl output{font-family:ui-monospace,monospace}.cw svg text{font-family:ui-monospace,monospace}
@media (prefers-reduced-motion:no-preference){.cw .cw-hand{transition:transform .25s ease}}
`;
// the badge: live, stored, or both with their agreement
function Badge({ t, kind }) {
  const B = stepAudience() === 'Young Learner' ? t.badgeY : t.badge;   // the Young Learner reads the plain words of badgeY
  const txt = { live: B.live, stored: B.stored, match: B.match, differ: B.differ, beyond: `${B.live} · ${B.beyond}` }[kind];
  const tip = kind === 'stored' ? B.storedTip : kind === 'live' || kind === 'beyond' ? B.liveTip : `${B.liveTip} · ${B.storedTip}`;
  return <span className={'ln-live cw-badge' + (kind === 'differ' ? ' ln-bad' : kind === 'match' ? ' ln-ok' : '')} data-badge={kind} title={tip}><Tx>{txt}</Tx></span>;
}
const Checks = ({ t, ids }) => <p className="ln-chk"><span className="ln-k">{t.checks}</span> {ids.map(c => <code key={c} className="ln-id">{c}</code>)}</p>;
const Prov = ({ text }) => <p className="ln-cap cw-prov"><Tx>{text}</Tx></p>;
const Root = ({ name, title, badge, children, labelId }) => <div className="ln-card cw" data-widget={name} role="group" aria-labelledby={labelId}><style>{CW_STYLE}</style>
  <h4 id={labelId}><Tx>{title}</Tx>{badge}</h4>{children}</div>;
// a twin table: rows [key, label, live, says, stored]
function Twin({ t, rows, name, says = true }) {
  return <div className="ln-wrap"><table className="ln-tab cw-twin" data-twin={name}><caption className="ln-cap" style={{ textAlign: 'left' }}><Tx>{t.twin.caption}</Tx></caption>
    <thead><tr><th scope="col"><Tx>{t.twin.qty}</Tx></th><th scope="col"><Tx>{t.twin.live}</Tx></th>{says && <th scope="col"><Tx>{t.twin.says}</Tx></th>}<th scope="col"><Tx>{t.twin.stored}</Tx></th></tr></thead>
    <tbody>{rows.map(([k, label, live, say, st]) => <tr key={k} data-row={k}><th scope="row"><Tx>{label}</Tx></th><td data-col="live"><Tx>{String(live)}</Tx></td>{says && <td data-col="says"><Tx>{say == null ? '—' : String(say)}</Tx></td>}<td data-col="stored"><Tx>{st == null ? '—' : String(st)}</Tx></td></tr>)}</tbody></table></div>;
}

// ---------------------------------------------------------------- controls
// the Young Learner's switches: each one plus, minus or zero (press to change), between min and max of them
function SwitchRow({ t, eps, setEps, min = 1, max = 5 }) {
  const word = e => (e === 1 ? t.sw.plus : e === -1 ? t.sw.minus : t.sw.zero), sym = e => (e === 1 ? '+' : e === -1 ? '−' : '0'), next = e => (e === 1 ? -1 : e === -1 ? 0 : 1);
  return <div className="cw-sw" role="group" aria-label={t.sw.group}>
    {eps.map((e, i) => <button key={i} type="button" className="ln-chip cw-s" data-switch={i} data-sq={e} aria-label={t.sw.label(i + 1, word(e))} onClick={() => setEps(eps.map((x, j) => (j === i ? next(x) : x)))}><b aria-hidden="true">{sym(e)}</b></button>)}
    <button type="button" className="ln-btn" data-add disabled={eps.length >= max} onClick={() => setEps([...eps, 1])}>{t.sw.add}</button>
    <button type="button" className="ln-btn" data-remove disabled={eps.length <= min} onClick={() => setEps(eps.slice(0, -1))}>{t.sw.remove}</button></div>;
}
// the formal reader's signature: steppers for p, q, r with n <= nmax, and preset chips
function SigPicker({ t, sig, setSig, nmax, presets }) {
  const n = sig[0] + sig[1] + sig[2], sq = ['+1', '−1', '0'];
  const step = (k, d) => { const s = [...sig]; s[k] += d; if (s[k] < 0 || s[0] + s[1] + s[2] > nmax) return; setSig(s); };
  return <div className="cw-sig"><div role="group" aria-label={t.sig.n(n)}>{['p', 'q', 'r'].map((x, k) => <span key={x} className="cw-step"><Tx>{t.sig[x]}</Tx>
    <button type="button" className="ln-btn" data-dec={x} aria-label={t.sig.fewer(sq[k])} disabled={sig[k] === 0} onClick={() => step(k, -1)}>−</button><output data-val={x} aria-live="polite">{sig[k]}</output>
    <button type="button" className="ln-btn" data-inc={x} aria-label={t.sig.more(sq[k])} disabled={n >= nmax} onClick={() => step(k, 1)}>+</button></span>)}<span className="cw-step"><Tx>{t.sig.n(n)}</Tx></span></div>
    {presets && <div className="ln-chips" role="group" aria-label={t.sig.presets}>{Object.entries(presets).map(([k, v]) => { const on = k === sig.join(','); return <button key={k} type="button" className="ln-chip" data-preset={k} aria-pressed={on} onClick={() => setSig(k.split(',').map(Number))}><Tx>{v}</Tx></button>; })}</div>}</div>;
}
const Slider = ({ label, min, max, value, onChange, name }) => <label className="ln-sl"><span><Tx>{label}</Tx></span><input type="range" min={min} max={max} step={1} value={value} data-slider={name} aria-label={label} onChange={e => onChange(+e.target.value)} /><output aria-hidden="true">{value}</output></label>;

// ---------------------------------------------------------------- the cube of labels (n <= 5 as a projected cube; n >= 6 as a grid, ordinary bits first)
const V = [[112, 0], [0, 112], [52, -44], [212, 26], [0, 212]];
function cubeLayout(eps) {
  const n = eps.length, N = 1 << n, Z = E.nullMask(eps), pos = [];
  if (n <= 5) { for (let a = 0; a < N; a++) { let x = 0, y = 0; for (let i = 0; i < n; i++) if (a >> i & 1) { x += V[i][0]; y += V[i][1]; } pos.push([x, y]); } }
  else {
    const ord = [...Array(n).keys()].filter(i => !(Z >> i & 1)), nul = [...Array(n).keys()].filter(i => Z >> i & 1), perm = [...ord, ...nul];
    for (let a = 0; a < N; a++) { let idx = 0; perm.forEach((i, k) => { if (a >> i & 1) idx |= 1 << k; }); pos.push([(idx % 16) * 17, Math.floor(idx / 16) * 17]); }
  }
  const xs = pos.map(p => p[0]), ys = pos.map(p => p[1]), m = n <= 5 ? 22 : 12, mr = n <= 3 ? 46 : m, x0 = Math.min(...xs) - m, y0 = Math.min(...ys) - m - (n <= 3 ? 8 : 0);   // n <= 3: room for the corner names
  return { n, N, Z, pos, grid: n > 5, vb: `${x0} ${y0} ${Math.max(...xs) - x0 + mr} ${Math.max(...ys) - y0 + m}` };
}
// fill(a) -> {fill, opacity, stroke}; mark(a) -> a short text inside the corner; interactive: onPick(a) and aria labels
function CubePic({ eps, label, fillOf, markOf, ariaOf, onPick, pressed, line, names, edgesOn = true }) {
  const L = useMemo(() => cubeLayout(eps), [eps]), { n, N, pos } = L, r = L.grid ? 7.5 : 9.5;
  const edges = []; if (!L.grid && edgesOn) for (let a = 0; a < N; a++) for (let i = 0; i < n; i++) if (!(a >> i & 1)) edges.push([a, a | (1 << i), eps[i] === 0]);
  return <svg className="cw-pic" viewBox={L.vb} role={onPick ? 'group' : 'img'} aria-label={label} data-n={n} data-layout={L.grid ? 'grid' : 'cube'}>
    {edges.map(([a, b, z], k) => <line key={k} x1={pos[a][0]} y1={pos[a][1]} x2={pos[b][0]} y2={pos[b][1]} stroke="currentColor" strokeOpacity={z ? 0.55 : 0.28} strokeDasharray={z ? '4 3' : undefined} />)}
    {line && <line x1={pos[line[0]][0]} y1={pos[line[0]][1]} x2={pos[line[1]][0]} y2={pos[line[1]][1]} stroke={COL.opp} strokeWidth="2.5" strokeDasharray="6 4" data-pairline />}
    {pos.map(([x, y], a) => { const f = fillOf(a), mk = markOf ? markOf(a) : null, act = !!onPick, g = <>
      {L.grid ? <rect className="cw-ring" x={x - r} y={y - r} width={2 * r} height={2 * r} rx="2" fill={f.fill} fillOpacity={f.opacity} stroke={f.stroke || 'currentColor'} strokeOpacity={f.strokeOpacity ?? 0.5} strokeWidth={f.strokeWidth || 1} />
        : <circle className="cw-ring" cx={x} cy={y} r={r} fill={f.fill} fillOpacity={f.opacity} stroke={f.stroke || 'currentColor'} strokeOpacity={f.strokeOpacity ?? 0.7} strokeWidth={f.strokeWidth || 1.5} />}
      {mk != null && <text x={x} y={y + 3.5} textAnchor="middle" fontSize="9.5" fill="currentColor" aria-hidden="true">{mk}</text>}
      <title>{ariaOf(a)}</title></>;
      return act ? <g key={a} className="cw-corner" role="button" tabIndex={0} data-corner={a} aria-label={ariaOf(a)} aria-pressed={pressed ? pressed(a) : undefined} onClick={() => onPick(a)} onKeyDown={keyAct(() => onPick(a))}>{g}</g>
        : <g key={a} data-corner={a}>{g}</g>; })}
    {names && n <= 3 && pos.map(([x, y], a) => <text key={'n' + a} x={x + (n === 1 ? 0 : 12)} y={y - 12} fontSize="10" fill="currentColor" opacity=".8" aria-hidden="true" style={{ pointerEvents: 'none' }}>{names(a)}</text>)}
  </svg>;
}
function Clock({ place, label }) {
  const R = 46, c = 60, ang = place * Math.PI / 4;
  return <svg className="cw-pic cw-small" viewBox="0 0 120 120" role="img" aria-label={label} data-place={place}>
    <circle cx={c} cy={c} r={R} fill="none" stroke="currentColor" strokeOpacity=".35" />
    {Array.from({ length: 8 }, (_, k) => { const a = k * Math.PI / 4, x = c + R * Math.sin(a), y = c - R * Math.cos(a); return <g key={k}><circle cx={x} cy={y} r={k === place ? 7 : 4.5} fill={k === place ? COL.acc : 'currentColor'} fillOpacity={k === place ? 1 : 0.35} /><text x={c + (R - 15) * Math.sin(a)} y={c - (R - 15) * Math.cos(a) + 3.5} fontSize="9" textAnchor="middle" fill="currentColor" opacity=".75">{k}</text></g>; })}
    <line className="cw-hand" x1={c} y1={c} x2={c + (R - 8) * Math.sin(ang)} y2={c - (R - 8) * Math.cos(ang)} stroke={COL.acc} strokeWidth="3" strokeLinecap="round" /></svg>;
}

// ================================================================ CW1 the label-0 card
export function CW1({ lang = 'en', profile = 'Young Learner' }) {
  const t = CWC[LG(lang)], id = useId();
  return isYL(profile) ? <CW1Plain t={t} id={id} /> : <CW1Formal t={t} id={id} />;
}
function CW1Plain({ t, id }) {
  const y = t.cw1.yl, [eps, setEps0] = useState([1, 1, 0]), [tray, setTray] = useState([]), [seed, setSeed] = useState(0);
  const setEps = e => { setEps0(e); setTray([]); };
  const n = eps.length, card = useMemo(() => E.labelCard(eps), [eps]), lit = a => !!(a & card.Z), place = E.clockPlace(eps), k = card.r + 1;
  const st = STORED.P3[[card.p, card.q, card.r].join(',')], agree = st && st.J === card.J && st.loewy === card.loewy;
  const [pm, ps] = E.trayProduct(tray, eps), name = a => E.bits(a, n);
  const fill = () => { const J = card.Jlabels; if (!J.length) return; let s = (seed * 2654435761 + 97) >>> 0; const pick = []; const pool = [...J]; while (pick.length < Math.min(k, pool.length)) { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; pick.push(pool.splice(s % pool.length, 1)[0]); } setTray(pick.sort((a, b) => a - b)); setSeed(seed + 1); };
  const res = !tray.length ? y.trayEmpty : `${tray.map(name).join(y.times)} = ${ps ? y.signed(ps, name(pm)) : y.nothing}`;
  return <Root name="CW1" labelId={id} title={y.title} badge={<Badge t={t} kind={st ? (agree ? 'match' : 'differ') : 'live'} />}>
    <p className="cw-lede"><Tx>{y.lede}</Tx></p><SwitchRow t={t} eps={eps} setEps={setEps} />
    <div className="cw-row"><div className="cw-col" style={{ flex: '2 1 280px' }}>
      <CubePic eps={eps} label={y.pic} names={a => name(a)} fillOf={a => (lit(a) ? { fill: COL.lit, opacity: 0.95, stroke: COL.lit, strokeOpacity: 1, strokeWidth: tray.includes(a) ? 3.5 : 1.5 } : { fill: 'none', opacity: 0, strokeWidth: tray.includes(a) ? 3.5 : 1.5 })}
        ariaOf={a => y.corner(name(a), lit(a))} onPick={a => { if (lit(a) && !tray.includes(a) && tray.length < 8) setTray([...tray, a]); }} pressed={a => tray.includes(a)} /></div>
      <div className="cw-col"><p className="cw-out" aria-live="polite" data-out="count" data-lit={card.J} data-all={card.dim} data-k={k}><Tx>{card.r ? y.count(card.J, card.dim, k) : y.none(card.dim)}</Tx></p>
        <p className="cw-sub"><b><Tx>{y.trayH}</Tx></b> <span className="cw-hint"><Tx>{y.trayHelp}</Tx></span></p>
        <div className="ln-chips"><button type="button" className="ln-btn" data-fill disabled={!card.r} onClick={fill}><Tx>{tray.length && tray.length === k ? y.next : y.fill(k)}</Tx></button><button type="button" className="ln-btn" data-empty onClick={() => setTray([])}><Tx>{y.empty}</Tx></button></div>
        <p className="cw-out" aria-live="polite" data-out="tray" data-size={tray.length} data-sign={tray.length ? ps : ''}><Tx>{res}</Tx></p>
        <p className="cw-sub"><b><Tx>{y.clockH}</Tx></b></p><Clock place={place} label={y.clockPic} /><p className="cw-out" aria-live="polite" data-out="clock" data-place={place}><Tx>{y.clockOut(place)}</Tx></p></div></div>
    <Pts items={y.caps} lang={t === CWC.it ? 'it' : 'en'} /></Root>;
}
const SHADE = ['none', '#fbbf24', '#fb923c', '#f87171', '#f472b6', '#c084fc', '#a78bfa', '#60a5fa', '#22d3ee'];
function CW1Formal({ t, id }) {
  const f = t.cw1.pm, lang = t === CWC.it ? 'it' : 'en', [sig, setSig] = useState([3, 0, 1]), [p, q, r] = sig, n = p + q + r;
  const eps = useMemo(() => E.sigOf(p, q, r), [p, q, r]), c = useMemo(() => E.labelCard(eps), [eps]), st = STORED.P3[sig.join(',')];
  const cmp = st && st.J === c.J && sameJSON(st.layers, c.layers) && st.loewy === c.loewy && st.sc === c.sc && st.centre === c.centre && st.type === c.type && st.clock === c.clock;
  const k = a => E.pc(a & c.Z), tyTxt = ty => (ty === 'R2' ? 'ℝ ⊕ ℝ' : ty === 'H2' ? 'ℍ ⊕ ℍ' : { R: 'ℝ', C: 'ℂ', H: 'ℍ' }[ty]), ql = `${sigName([p, q, 0])} · ${tyTxt(c.type)}`;
  const rows = [
    ['n', f.rows.n, n, null, st ? st.n : null], ['dim', f.rows.dim, c.dim, 2 ** n, st ? st.dim : null], ['J', f.rows.J, c.J, c.t2.J, st ? st.J : null],
    ['layers', f.rows.layers, c.layers.join(', '), c.t2.layers.join(', '), st ? st.layers.join(', ') : null], ['loewy', f.rows.loewy, c.loewy, c.t2.loewy, st ? st.loewy : null],
    ['sc', f.rows.sc, c.sc, c.t2.sc, st ? st.sc : null], ['centre', f.rows.centre, c.centre, f.noFormula, st ? st.centre : null],
    ['quot', f.rows.quot, ql, sigName([p, q, 0]), st ? `${sigName([...st.quotient, 0])} · ${tyTxt(st.type)}` : null], ['clock', f.rows.clock, c.clock, (p - q + 64) % 8, st ? st.clock : null],
    ['gs', f.rows.gs, c.sc === 1 ? t.yes : t.no, r === 0 ? t.yes : t.no, null],
  ];
  return <Root name="CW1" labelId={id} title={f.title} badge={<Badge t={t} kind={st ? (cmp ? 'match' : 'differ') : 'beyond'} />}>
    <p className="cw-lede"><Tx>{f.lede}</Tx></p><SigPicker t={t} sig={sig} setSig={setSig} nmax={8} presets={f.presets} />
    <div className="cw-row"><div className="cw-col" style={{ flex: '2 1 300px' }}>
      <CubePic eps={eps} label={f.pic} names={a => labPlain(a, n)} markOf={a => (k(a) ? k(a) : null)} fillOf={a => (k(a) ? { fill: SHADE[Math.min(k(a), 8)], opacity: 0.35 + 0.6 * k(a) / Math.max(1, r) } : { fill: 'none', opacity: 0 })} ariaOf={a => f.corner(labPlain(a, n), k(a))} />
      <p className="ln-cap" aria-hidden="true">{Array.from({ length: r + 1 }, (_, j) => <span key={j} style={{ marginRight: 10 }}><svg width="12" height="12" style={{ verticalAlign: 'middle' }}><circle cx="6" cy="6" r="5" fill={j ? SHADE[Math.min(j, 8)] : 'none'} fillOpacity={j ? 0.35 + 0.6 * j / Math.max(1, r) : 0} stroke="currentColor" strokeOpacity=".6" /></svg> <Tx>{f.legend(j)}</Tx></span>)}</p>
      <p className="cw-out" aria-live="polite" data-out="face" data-r={r}><Tx>{f.face(r)}</Tx></p></div>
      <div className="cw-col"><Twin t={t} rows={rows} name="CW1" /></div></div>
    <Prov text={f.prov} /><Pts items={f.caps} lang={lang} /><Checks t={t} ids={CHECK_IDS.CW1} /></Root>;
}

// ================================================================ CW2 every corner has an opposite
export function CW2({ lang = 'en', profile = 'Young Learner' }) {
  const t = CWC[LG(lang)], id = useId();
  return isYL(profile) ? <CW2Plain t={t} id={id} /> : <CW2Formal t={t} id={id} />;
}
function CW2Plain({ t, id }) {
  const y = t.cw2.yl, lang = t === CWC.it ? 'it' : 'en', [eps, setEps0] = useState([1, 1, 0]), [sel, setSel] = useState(1), [swap, setSwap] = useState(false);
  const setEps = e => { setEps0(e); setSel(1); setSwap(false); };
  const n = eps.length, F = (1 << n) - 1, fr = useMemo(() => E.frobenius(eps), [eps]), x = fr.pairs[sel], name = a => E.bits(a, n);
  const { p, q, r } = E.pqrOf(eps), st = STORED.P4[[p, q, r].join(',')], agree = st && st.fair === fr.fair && st.rank_lam === fr.rankLam;
  return <Root name="CW2" labelId={id} title={y.title} badge={<Badge t={t} kind={st ? (agree ? 'match' : 'differ') : 'live'} />}>
    <p className="cw-lede"><Tx>{y.lede}</Tx></p><SwitchRow t={t} eps={eps} setEps={setEps} />
    <div className="cw-row"><div className="cw-col" style={{ flex: '2 1 280px' }}>
      <CubePic eps={eps} label={y.pic} names={a => name(a)} line={[sel, sel ^ F]} pressed={a => a === sel} onPick={a => { setSel(a); setSwap(false); }}
        fillOf={a => (a === sel ? { fill: COL.pick, opacity: 1, stroke: COL.pick, strokeOpacity: 1 } : a === (sel ^ F) ? { fill: COL.opp, opacity: 1, stroke: COL.opp, strokeOpacity: 1 } : { fill: 'none', opacity: 0 })} ariaOf={a => y.corner(name(a), a === sel)} /></div>
      <div className="cw-col"><p className="cw-out" aria-live="polite" data-out="pair" data-a={x.a} data-b={x.b} data-sign={x.ab}><Tx>{y.pair(name(x.a), name(x.b), x.ab)}</Tx></p>
        <button type="button" className="ln-btn" data-swap aria-pressed={swap} onClick={() => setSwap(s => !s)}><Tx>{y.swap}</Tx></button>
        {swap && <p className="cw-out" aria-live="polite" data-out="swap" data-same={x.ab === x.ba ? 1 : 0}><Tx>{x.ab === x.ba ? y.same : y.flips}</Tx></p>}
        <p className="cw-out" data-out="self" data-v={fr.sq[sel]}><Tx>{y.self(name(sel), fr.sq[sel])}</Tx></p>
        <p className={'cw-out' + (fr.fair ? '' : ' cw-jam')} aria-live="polite" data-out="fair" data-fair={fr.fair ? 1 : 0}><Tx>{fr.fair ? y.fairYes : y.fairNo}</Tx></p>
        <p className="cw-hint"><Tx>{y.challenge}</Tx></p></div></div>
    <Pts items={y.caps} lang={lang} /></Root>;
}
function Gram({ N, cells, label, name }) {
  const S = 200, c = S / N;
  return <svg className="cw-pic cw-gram" viewBox={`-2 -2 ${S + 4} ${S + 4}`} role="img" aria-label={label} data-gram={name} data-nonzero={cells.length}>
    <rect x="0" y="0" width={S} height={S} fill="none" stroke="currentColor" strokeOpacity=".35" />
    {cells.map(([a, b, v]) => <rect key={a * N + b} x={b * c + c * 0.1} y={a * c + c * 0.1} width={c * 0.8} height={c * 0.8} fill={v > 0 ? COL.pos : 'none'} stroke={v > 0 ? COL.pos : COL.neg} strokeWidth={Math.max(0.6, Math.min(2, c * 0.18))} />)}</svg>;
}
function CW2Formal({ t, id }) {
  const f = t.cw2.pm, lang = t === CWC.it ? 'it' : 'en', [sig, setSig] = useState([3, 0, 1]), [p, q, r] = sig, n = p + q + r, N = 1 << n;
  const eps = useMemo(() => E.sigOf(p, q, r), [p, q, r]), fr = useMemo(() => E.frobenius(eps), [eps]), st = STORED.P4[sig.join(',')];
  const cmp = st && st.rank_lam === fr.rankLam && st.rank_0 === fr.rank0 && st.rank_ef === fr.rankEF && st.omega2 === fr.omega2 && st.reach === fr.reach && sameJSON(st.conj, fr.conj) && st.fair === fr.fair && STORED.P4_anti[n] === fr.anti && STORED.P4_nakayama[n] === fr.nak;
  const lamCells = fr.pairs.map(x => [x.a, x.b, x.ab]), zeroCells = fr.sq.map((s, a) => [a, a, s]).filter(x => x[2]);
  const names = fr.conj.map(a => lab(a, n)).join(', ');
  const rows = [
    ['rankL', f.rows.rankL, fr.rankLam, 2 ** n, st ? st.rank_lam : null], ['rank0', f.rows.rank0, fr.rank0, 2 ** (p + q), st ? st.rank_0 : null], ['rankEF', f.rows.rankEF, fr.rankEF, 2 ** (p + q), st ? st.rank_ef : null],
    ['omega2', f.rows.omega2, fr.omega2, r ? 0 : null, st ? st.omega2 : null], ['reach', f.rows.reach, fr.reach, 2 ** (p + q), st ? st.reach : null],
    ['nak', f.rows.nak, f.nakVal(!fr.nak.includes('-')), f.nakVal(n % 2 === 1 || n === 0), st ? f.nakVal(!STORED.P4_nakayama[n].includes('-')) : null],
    ['conj', f.rows.conj, fr.conj.length ? f.conjVal(names, fr.conjInJ, r === 0) : '—', null, st ? (st.conj.length ? st.conj.map(a => lab(a, n)).join(', ') : '—') : null], ['sym', f.rows.sym, f.symVal(fr.cert), n % 2 || r === 0 ? t.yes : t.no, st ? f.symVal(st.cert) : null],
  ];
  return <Root name="CW2" labelId={id} title={f.title} badge={<Badge t={t} kind={st ? (cmp ? 'match' : 'differ') : 'live'} />}>
    <p className="cw-lede"><Tx>{f.lede}</Tx></p><SigPicker t={t} sig={sig} setSig={setSig} nmax={6} presets={f.presets} />
    <div style={{ textAlign: 'center' }}><figure style={{ display: 'inline-block', margin: 4 }}><Gram N={N} cells={lamCells} label={f.gramL} name="lambda" /><figcaption className="ln-cap"><Tx>{f.gramL}</Tx></figcaption></figure>
      <figure style={{ display: 'inline-block', margin: 4 }}><Gram N={N} cells={zeroCells} label={f.gram0} name="scalar" /><figcaption className="ln-cap"><Tx>{f.gram0}</Tx></figcaption></figure></div>
    <p className="ln-cap"><Tx>{f.legend}</Tx></p>
    <p className="cw-sub"><Tx>{f.nakH}</Tx></p>
    <svg className="cw-pic" viewBox={`0 0 ${N * 14 + 4} 18`} role="img" aria-label={f.nakH} data-nak={fr.nak} style={{ maxWidth: Math.min(460, N * 14 + 4) }}>{[...fr.nak].map((s, a) => <rect key={a} x={2 + a * 14} y="3" width="11" height="11" fill={s === '+' ? COL.pos : 'none'} stroke={s === '+' ? COL.pos : COL.neg} strokeWidth="1.6"><title>{`${labPlain(a, n)}: ${s}`}</title></rect>)}</svg>
    <Twin t={t} rows={rows} name="CW2" />
    <Prov text={f.prov} /><Pts items={f.caps} lang={lang} /><Checks t={t} ids={CHECK_IDS.CW2} /></Root>;
}

// ================================================================ CW3 four moves
export function CW3({ lang = 'en', profile = 'Young Learner' }) {
  const t = CWC[LG(lang)], id = useId();
  return isYL(profile) ? <CW3Plain t={t} id={id} /> : <CW3Formal t={t} id={id} />;
}
const halveEps = (eps, t) => { const h = E.halve(eps, t); return h.ok ? h.target : null; };
function CW3Plain({ t, id }) {
  const y = t.cw3.yl, lang = t === CWC.it ? 'it' : 'en', START = [1, 0, 0];
  const [eps, setEps] = useState(START), [trail, setTrail] = useState([{ eps: START, move: 'start' }]), [msg, setMsg] = useState({ k: 'start' });
  const go = (e, move, m) => { setEps(e); setTrail(tr => [...tr, { eps: e, move }].slice(-12)); setMsg(m); };
  const join = s => (eps.length >= 7 ? setMsg({ k: 'tooBig' }) : go([...eps, s], 'join', { k: 'joined' }));
  const halve = () => { if (!eps.length) return setMsg({ k: 'emptyBox' }); const h = E.halve(eps); if (!h.ok) return setMsg({ k: 'jam', d: h.lam.dim, r: h.lam.r }); go(h.target, 'halve', { k: 'halved' }); };
  const forget = () => { const e = eps.filter(x => x !== 0); if (e.length === eps.length) return setMsg({ k: 'noZero' }); go(e, 'forget', { k: 'forgot' }); };
  const opposite = () => go(eps, 'opposite', { k: 'opposed' });
  const { p, q, r } = E.pqrOf(eps), stRow = STORED.P2.find(x => x.p === p && x.q === q && x.r === r), h = useMemo(() => E.halve(eps), [eps]);
  const agree = stRow && stRow.halves === h.ok;
  const text = msg.k === 'jam' ? y.jam(msg.d, msg.r) : msg.k === 'start' ? '' : y[msg.k];
  return <Root name="CW3" labelId={id} title={y.title} badge={<Badge t={t} kind={stRow ? (agree ? 'match' : 'differ') : 'live'} />}>
    <p className="cw-lede"><Tx>{y.lede}</Tx></p>
    <div className="ln-chips" role="group" aria-label={y.title}>
      <button type="button" className="ln-btn" data-move="join-plus" onClick={() => join(1)}><Tx>{y.joinPlus}</Tx></button><button type="button" className="ln-btn" data-move="join-minus" onClick={() => join(-1)}><Tx>{y.joinMinus}</Tx></button>
      <button type="button" className="ln-btn" data-move="join-zero" onClick={() => join(0)}><Tx>{y.joinZero}</Tx></button><button type="button" className="ln-btn" data-move="halve" onClick={halve}><Tx>{y.halve}</Tx></button>
      <button type="button" className="ln-btn" data-move="forget" onClick={forget}><Tx>{y.forget}</Tx></button><button type="button" className="ln-btn" data-move="opposite" onClick={opposite}><Tx>{y.opposite}</Tx></button>
      <button type="button" className="ln-btn" data-move="reset" onClick={() => { setEps(START); setTrail([{ eps: START, move: 'start' }]); setMsg({ k: 'start' }); }}><Tx>{y.reset}</Tx></button></div>
    <p className={'cw-out' + (msg.k === 'jam' ? ' cw-jam' : '')} aria-live="polite" data-out="move" data-msg={msg.k}><Tx>{text}</Tx></p>
    <p className="cw-sub"><b><Tx>{y.trailH}</Tx></b></p>
    <ol className="cw-trail" data-trail={trail.length}>{trail.map((x, i) => { const s = E.pqrOf(x.eps); return <li key={i} data-pqr={`${s.p},${s.q},${s.r}`} data-clock={E.clockPlace(x.eps)}><Tx>{y.trail(s.p, s.q, s.r, E.clockPlace(x.eps))}</Tx></li>; })}</ol>
    <Pts items={y.caps} lang={lang} /></Root>;
}
function CW3Formal({ t, id }) {
  const f = t.cw3.pm, lang = t === CWC.it ? 'it' : 'en', START = E.sigOf(1, 3, 0);
  const [eps, setEps0] = useState(START), [trail, setTrail] = useState([{ eps: START }]), [partner, setPartner] = useState('0,0,1'), [tsel, setT] = useState(0), [T, setTmask] = useState((1 << 4) - 1), [out, setOut] = useState(null);
  const n = eps.length, F = (1 << n) - 1;
  const setEps = e => { setEps0(e); setTrail(tr => [...tr, { eps: e }].slice(-12)); setTmask((1 << e.length) - 1); setT(Math.max(0, e.findIndex(x => x !== 0))); };
  const name = e => sigName(pqrArr(e));
  const doJoin = () => { const [pp, qq, rr] = partner.split(',').map(Number), e2 = E.sigOf(pp, qq, rr); if (n + e2.length > 7) return setOut({ k: 'big' }); const j = E.join(eps, e2); setOut({ k: 'join', s: f.joined(name(eps), name(e2), name(j.eps), j.pairs, j.koszul && j.clock === j.clockSum, E.clockPlace(eps), E.clockPlace(e2), j.clock), ok: j.koszul, small: n + e2.length <= 6 }); setEps(j.eps); };
  const doHalve = () => {
    if (!n) return; const h = E.halve(eps, tsel);
    if (!h.ok && h.jam) return setOut({ k: 'jam', s: f.jam(h.lam.r, h.lam.dim, h.lam.rad, h.lam.loewy) });
    if (h.kind === 'null') { setOut({ k: 'halve', s: f.halvedNull(h.lam.r, sigName([0, 0, h.lam.r - 1])) }); return setEps(h.target); }
    setOut({ k: 'halve', s: f.halved(name(eps), `e_{${h.t + 1}}`, eps[h.t], name(h.target), h.ok) }); setEps(h.target);
  };
  const face = useMemo(() => E.restrict(eps, T & F), [eps, T, F]);
  const doFace = () => setEps(face.eps);
  const doComp = () => setOut({ k: 'comp', s: f.comp(E.complementReverses(n)) });
  const { p, q, r } = E.pqrOf(eps), stRow = STORED.P2.find(x => x.p === p && x.q === q && x.r === r);
  const liveVia = { plus: p ? E.halveVia(E.sigOf(p, q, r), 0) : null, minus: q ? E.halveVia(E.sigOf(p, q, r), p) : null };
  const viaOK = stRow && stRow.halves === E.halve(E.sigOf(p, q, r)).ok && Object.entries(stRow.via).every(([k, tg]) => k === 'null' ? E.halve(E.sigOf(p, q, r)).ok : liveVia[k] && liveVia[k].ok && sameJSON([liveVia[k].pqr.p, liveVia[k].pqr.q, liveVia[k].pqr.r], tg));
  const faceOK = face.iota && face.pi === face.outsideNull;
  const badge = stRow ? (viaOK && faceOK ? 'match' : 'differ') : 'live';
  return <Root name="CW3" labelId={id} title={f.title} badge={<Badge t={t} kind={badge} />}>
    <p className="cw-lede"><Tx>{f.lede}</Tx></p>
    <p className="cw-out" data-out="box" data-pqr={`${p},${q},${r}`}><b><Tx>{name(eps)}</Tx></b> · <Tx>{`c = ${E.clockPlace(eps)}`}</Tx> · <span className="ln-mono">{eps.map((x, i) => `e${i + 1}²=${x > 0 ? '+1' : x < 0 ? '−1' : '0'}`).join(' ')}</span></p>
    <div className="cw-sub"><Tx>{f.joinH}</Tx> <span className="ln-chips" style={{ display: 'inline-flex' }}>{Object.entries(f.partners).map(([k, v]) => <button key={k} type="button" className="ln-chip" data-partner={k} aria-pressed={partner === k} onClick={() => setPartner(k)}><Tx>{v}</Tx></button>)}</span> <button type="button" className="ln-btn" data-move="double" onClick={doJoin}><Tx>{f.joinBtn}</Tx></button></div>
    <div className="cw-sub"><Tx>{f.halveH}</Tx> <span className="ln-chips" style={{ display: 'inline-flex' }}>{eps.map((x, i) => (x !== 0 ? <button key={i} type="button" className="ln-chip" data-t={i} aria-pressed={tsel === i} onClick={() => setT(i)}><Tx>{`e_{${i + 1}}`}</Tx></button> : null))}</span> <button type="button" className="ln-btn" data-move="halve" onClick={doHalve}><Tx>{f.halveBtn}</Tx></button></div>
    <div className="cw-sub"><Tx>{f.faceH}</Tx><div className="ln-chips">{eps.map((x, i) => <button key={i} type="button" className="ln-chip" data-face={i} aria-pressed={!!(T >> i & 1)} onClick={() => setTmask(T ^ (1 << i))}><Tx>{`e_{${i + 1}}${x === 0 ? ' (0)' : ''}`}</Tx></button>)}
      <button type="button" className="ln-btn" data-move="forget" onClick={() => setTmask(F ^ E.nullMask(eps))}><Tx>{f.forgetBtn}</Tx></button><button type="button" className="ln-btn" data-move="face" disabled={!face.pi} onClick={doFace}><Tx>{f.faceBtn}</Tx></button></div>
      <p className="cw-out" aria-live="polite" data-out="face" data-iota={face.iota ? 1 : 0} data-pi={face.pi ? 1 : 0} data-crit={face.outsideNull ? 1 : 0}><Tx>{f.face(face.iota, face.pi, face.outsideNull, face.quotient)}</Tx></p></div>
    <div className="cw-sub"><Tx>{f.compH}</Tx> <button type="button" className="ln-btn" data-move="complement" onClick={doComp}><Tx>{f.compBtn}</Tx></button> <button type="button" className="ln-btn" data-move="reset" onClick={() => { setEps0(START); setTrail([{ eps: START }]); setOut(null); setTmask(15); setT(0); }}><Tx>{f.reset}</Tx></button></div>
    {out && <p className={'cw-out' + (out.k === 'jam' ? ' cw-jam' : '')} aria-live="polite" data-out="move" data-msg={out.k}><Tx>{out.k === 'big' ? CWC[lang].cw3.yl.tooBig : out.s}</Tx>{out.k === 'join' && !out.small ? <> <Tx>{f.joinBig}</Tx></> : null}</p>}
    <p className="cw-sub"><b><Tx>{f.trailH}</Tx></b></p>
    <ol className="cw-trail" data-trail={trail.length}>{trail.map((x, i) => <li key={i} data-pqr={pqrArr(x.eps).join(',')} data-clock={E.clockPlace(x.eps)}><Tx>{f.trail(name(x.eps), E.clockPlace(x.eps))}</Tx></li>)}</ol>
    <Pts items={f.caps} lang={lang} /><Pts items={f.uses} lang={lang} />
    <p className="cw-sub"><b><Tx>{f.tableH}</Tx></b></p>
    <div className="ln-wrap"><table className="ln-tab" data-table="moves"><thead><tr>{f.head.map(h => <th key={h} scope="col"><Tx>{h}</Tx></th>)}</tr></thead><tbody>{f.table.map(row => <tr key={row[0]}>{row.map((c, i) => (i === 0 ? <th key={i} scope="row"><Tx>{c}</Tx></th> : <td key={i}>{(i === 3 || i === 4) && /^(T\d|cat|bridge)/.test(c) ? <code className="ln-id">{c}</code> : <Tx>{c}</Tx>}</td>))}</tr>)}</tbody></table></div>
    <Prov text={f.prov} /><Checks t={t} ids={CHECK_IDS.CW3} /></Root>;
}

// ================================================================ CW4 the top of the ladder
function Dynkin({ n, marks, label, compact }) {
  const g = E.enGraph(n), chain = n === 3 ? [1, 2] : [1, 2, 3, ...Array.from({ length: n - 4 }, (_, k) => 4 + k)], dx = Math.min(40, 440 / Math.max(2, chain.length)), y0 = 58, pos = {};
  chain.forEach((v, k) => { pos[v] = [20 + k * dx, y0]; }); pos[0] = n === 3 ? [20 + 2.2 * dx, y0] : [pos[3][0], y0 - 34];
  const W = Math.max(...Object.values(pos).map(p => p[0])) + 22;
  return <svg className="cw-pic" viewBox={`0 0 ${W} ${compact ? 80 : 92}`} role="img" aria-label={label} data-dots={n} data-lines={g.edges.length} style={{ maxWidth: Math.min(520, W * 1.15) }}>
    {g.edges.map(([a, b], k) => <line key={k} x1={pos[a][0]} y1={pos[a][1]} x2={pos[b][0]} y2={pos[b][1]} stroke="currentColor" strokeOpacity=".6" strokeWidth="2" />)}
    {Object.entries(pos).map(([v, [x, y]]) => <g key={v}><circle cx={x} cy={y} r="7" fill={COL.acc} fillOpacity=".85" stroke="currentColor" strokeOpacity=".6" />{marks && <text x={x} y={+v === 0 ? y - 11 : y + 21} fontSize="11" textAnchor="middle" fill="currentColor">{marks[v]}</text>}</g>)}</svg>;
}
export function CW4({ lang = 'en', profile = 'Young Learner' }) {
  const t = CWC[LG(lang)], id = useId();
  return isYL(profile) ? <CW4Plain t={t} id={id} /> : <CW4Formal t={t} id={id} />;
}
function CW4Plain({ t, id }) {
  const y = t.cw4.yl, lang = t === CWC.it ? 'it' : 'en', [n, setN] = useState(8), R = useMemo(() => E.ladderRung(n, false), [n]), st = STORED.P5.find(x => x.n === n);
  const [pos, neg, zer] = R.inertia, agree = st && sameJSON(st.inertia, R.inertia);
  return <Root name="CW4" labelId={id} title={y.title} badge={<Badge t={t} kind={st ? (agree ? 'match' : 'differ') : 'live'} />}>
    <p className="cw-lede"><Tx>{y.lede}</Tx></p><Slider label={y.slider} min={3} max={11} value={n} onChange={setN} name="rung" />
    <Dynkin n={n} label={y.pic(n)} compact />
    <p className="cw-out" aria-live="polite" data-out="rung" data-n={n} data-pos={pos} data-zero={zer} data-neg={neg}><Tx>{y.out(n, pos, zer, neg)}</Tx></p>
    <Pts items={y.caps} lang={lang} /></Root>;
}
function CW4Formal({ t, id }) {
  const f = t.cw4.pm, lang = t === CWC.it ? 'it' : 'en', [n, setN] = useState(9), R = useMemo(() => E.ladderRung(n, true), [n]), st = STORED.P5.find(x => x.n === n);
  const keys = ['det', 'type', 'q1', 'q0', 'rad', 'cl_q1', 'cl_q0', 'cl_rad'], agree = st && keys.every(k => st[k] === R[k]) && sameJSON(st.inertia, R.inertia) && (n !== 9 || sameJSON(STORED.marks9, R.marks));
  const marksTxt = R.marks ? `(${R.marks[0]}; ${R.marks.slice(1).join(',')}), ${R.marks.reduce((a, b) => a + b, 0)}` : '—';
  const rows = [
    ['det', f.rows.det, R.det, 9 - n, st ? st.det : null], ['inertia', f.rows.inertia, `(${R.inertia.join(',')})`, n <= 8 ? `(${n},0,0)` : n === 9 ? '(8,0,1)' : `(${n - 1},1,0)`, st ? `(${st.inertia.join(',')})` : null],
    ['type', f.rows.type, f.types[R.type], f.types[n <= 8 ? 'finite' : n === 9 ? 'affine' : n === 10 ? 'hyperbolic' : 'lorentzian'], st ? f.types[st.type] : null],
    ['marks', f.rows.marks, marksTxt, n === 9 ? '(3; 2,4,6,5,4,3,2,1), 30' : null, n === 9 ? `(${STORED.marks9[0]}; ${STORED.marks9.slice(1).join(',')}), ${STORED.marks9.reduce((a, b) => a + b, 0)}` : null],
    ['q1', f.rows.q1, `${R.q1} · ${R.cl_q1}`, null, st ? `${st.q1} · ${st.cl_q1}` : null], ['q0', f.rows.q0, `${R.q0} · ${R.cl_q0}`, null, st ? `${st.q0} · ${st.cl_q0}` : null],
    ['rad', f.rows.rad, `${R.rad} · ${R.cl_rad}`, null, st ? `${st.rad} · ${st.cl_rad}` : null], ['kernel', f.rows.kernel, '—', RAILS.E[n] ? RAILS.E[n][4] : null, null],
  ];
  return <Root name="CW4" labelId={id} title={f.title} badge={<Badge t={t} kind={st ? (agree ? 'match' : 'differ') : 'live'} />}>
    <p className="cw-lede"><Tx>{f.lede}</Tx></p><Slider label={f.slider} min={3} max={20} value={n} onChange={setN} name="n" />
    <Dynkin n={n} label={f.pic(n)} marks={R.marks} />
    <p className="cw-out" aria-live="polite" data-out="rung" data-n={n} data-det={R.det} data-inertia={R.inertia.join(',')} data-type={R.type}><Tx>{`E_{${n}}: det = ${R.det}, (${R.inertia.join(',')}), ${f.types[R.type]}`}</Tx></p>
    <Twin t={t} rows={rows} name="CW4" />
    <Prov text={f.prov} /><Pts items={f.caps} lang={lang} /><Checks t={t} ids={CHECK_IDS.CW4} /></Root>;
}

// ================================================================ CW5 two kinds of zero
export function CW5({ lang = 'en', profile = 'Young Learner' }) {
  const t = CWC[LG(lang)], id = useId();
  return isYL(profile) ? <CW5Plain t={t} id={id} /> : <CW5Formal t={t} id={id} />;
}
const NULLS = () => ({ paired: E.labelCard(E.sigOf(1, 1, 0)).J, unpaired: E.labelCard(E.sigOf(0, 0, 2)).J, mixed: E.labelCard(E.sigOf(1, 1, 1)).J });
function CW5Plain({ t, id }) {
  const y = t.cw5.yl, lang = t === CWC.it ? 'it' : 'en', [a, setA] = useState(2), [b, setB] = useState(1), [show, setShow] = useState(null);
  const sq = E.mixSquare(a, b)[0] || 0, pz = useMemo(E.pairedZero, []), lone = useMemo(() => E.loneZero([1, -1, 0]), []), nz = useMemo(NULLS, []);
  const agree = STORED.P3['1,1,0'].J === nz.paired && STORED.P3['0,0,2'].J === nz.unpaired;
  return <Root name="CW5" labelId={id} title={y.title} badge={<Badge t={t} kind={agree ? 'match' : 'differ'} />}>
    <p className="cw-lede"><Tx>{y.lede}</Tx></p>
    <Slider label={y.a} min={-3} max={3} value={a} onChange={setA} name="a" /><Slider label={y.b} min={-3} max={3} value={b} onChange={setB} name="b" />
    <p className={'cw-out' + (sq === 0 ? ' ln-ok' : '')} aria-live="polite" data-out="mix" data-v={sq}><Tx>{y.out(sq)}</Tx></p>
    <div className="ln-chips"><button type="button" className="ln-btn" data-show="pair" aria-pressed={show === 'pair'} onClick={() => { setShow('pair'); setA(1); setB(1); }}><Tx>{y.find}</Tx></button>
      <button type="button" className="ln-btn" data-show="lone" aria-pressed={show === 'lone'} onClick={() => setShow('lone')}><Tx>{y.lone}</Tx></button></div>
    {show === 'pair' && <p className="cw-out" aria-live="polite" data-out="pair" data-sum={pz.sum[0]}><Tx>{y.pair(pz.sum[0])}</Tx></p>}
    {show === 'lone' && <p className="cw-out" aria-live="polite" data-out="lone" data-all-zero={lone.every(x => !Object.keys(x.sum).length) ? 1 : 0}><Tx>{y.loneOut}</Tx></p>}
    <Pts items={y.caps} lang={lang} /></Root>;
}
function CW5Formal({ t, id }) {
  const f = t.cw5.pm, lang = t === CWC.it ? 'it' : 'en', [a, setA] = useState(1), [b, setB] = useState(1);
  const sq = E.mixSquare(a, b)[0] || 0, pz = useMemo(E.pairedZero, []), lone = useMemo(() => E.loneZero([1, -1, 0]), []), nz = useMemo(NULLS, []);
  const st = [STORED.P3['1,1,0'].J, STORED.P3['0,0,2'].J, STORED.P3['1,1,1'].J], agree = sameJSON(st, [nz.paired, nz.unpaired, nz.mixed]);
  const rows = [
    ['uu', f.rows.uu, mvTxt(pz.uu, 2), '0', null], ['vv', f.rows.vv, mvTxt(pz.vv, 2), '0', null], ['uv', f.rows.uv, mvTxt(pz.uv, 2), null, null], ['vu', f.rows.vu, mvTxt(pz.vu, 2), null, null],
    ['sum', f.rows.sum, mvTxt(pz.sum, 2), '4', null], ['lone', f.rows.lone, lone.map(x => mvTxt(x.sum, 3)).join(', '), '0, 0, 0', null],
    ['rad', f.rows.rad, `${nz.paired} · ${nz.unpaired} · ${nz.mixed}`, `${2 ** 2 - 2 ** 2} · ${2 ** 2 - 2 ** 0} · ${2 ** 3 - 2 ** 2}`, st.join(' · ')],
  ];
  return <Root name="CW5" labelId={id} title={f.title} badge={<Badge t={t} kind={agree ? 'match' : 'differ'} />}>
    <p className="cw-lede"><Tx>{f.lede}</Tx></p>
    <Slider label={f.a} min={-3} max={3} value={a} onChange={setA} name="a" /><Slider label={f.b} min={-3} max={3} value={b} onChange={setB} name="b" />
    <p className="cw-out" aria-live="polite" data-out="mix" data-v={sq}><Tx>{f.out(a, b, sq)}</Tx></p>
    <Twin t={t} rows={rows} name="CW5" />
    <Prov text={f.prov} /><Pts items={f.caps} lang={lang} /><Checks t={t} ids={CHECK_IDS.CW5} /></Root>;
}

// ================================================================ CW6 (optional) sign the cube
export function CW6({ lang = 'en', profile = 'Young Learner' }) {
  const t = CWC[LG(lang)], id = useId(), yl = isYL(profile), v = yl ? t.cw6.yl : t.cw6.pm, L2 = t === CWC.it ? 'it' : 'en';
  const [signs, setSigns] = useState(() => E.ruleSigns()), [corner, setCorner] = useState(null), cnt = useMemo(() => E.countAnticommuting(), []);
  const odd = E.squaresOdd(signs), k = odd.filter(Boolean).length, gauge = E.gaugeOf(signs), Lay = useMemo(() => cubeLayout([1, 1, 1]), []), pos = Lay.pos, name = a => E.bits(a, 3);
  const sq = E.cubeSquares(), edges = E.cubeEdges();
  return <Root name="CW6" labelId={id} title={v.title} badge={<Badge t={t} kind="live" />}>
    <p className="cw-lede"><Tx>{v.lede}</Tx></p>
    <svg className="cw-pic" viewBox={Lay.vb} role="group" aria-label={v.pic} data-odd={k} style={{ maxWidth: 360 }}>
      {sq.map(([a, i, j], f) => { const cs = [a, a | (1 << i), a | (1 << i) | (1 << j), a | (1 << j)], x = cs.reduce((u, c) => u + pos[c][0], 0) / 4, y = cs.reduce((u, c) => u + pos[c][1], 0) / 4;
        return <text key={'f' + f} x={x} y={y + 4} textAnchor="middle" fontSize="13" fill={odd[f] ? COL.pos : COL.bad} data-face={f} data-good={odd[f] ? 1 : 0} aria-hidden="true">{odd[f] ? '✓' : '✗'}</text>; })}
      {edges.map(([a, i]) => { const b = a | (1 << i), sg = signs[E.edgeKey(a, i)], flip = () => setSigns({ ...signs, [E.edgeKey(a, i)]: -sg }), mx = (pos[a][0] + pos[b][0]) / 2, my = (pos[a][1] + pos[b][1]) / 2;
        return <g key={a * 8 + i} className="cw-corner" role="button" tabIndex={0} data-edge={`${a},${i}`} data-sign={sg} aria-label={v.edge(name(a), name(b), sg)} onClick={flip} onKeyDown={keyAct(flip)}>
          <circle cx={mx} cy={my} r="9" fill="transparent" stroke="currentColor" strokeOpacity=".18" style={{ pointerEvents: 'all' }} />
          <line className="cw-ring" x1={pos[a][0]} y1={pos[a][1]} x2={pos[b][0]} y2={pos[b][1]} stroke={sg > 0 ? 'currentColor' : COL.bad} strokeOpacity={sg > 0 ? 0.6 : 1} strokeWidth="3" strokeDasharray={sg > 0 ? undefined : '6 4'} />
          {sg < 0 && <text x={mx + 6} y={my - 5} fontSize="12" fill={COL.bad} aria-hidden="true">−</text>}<title>{v.edge(name(a), name(b), sg)}</title></g>; })}
      {pos.map(([x, y], a) => { const pick = () => setCorner(a === corner ? null : a); return <g key={'c' + a} className="cw-corner" role="button" tabIndex={0} data-corner={a} aria-pressed={a === corner} aria-label={v.corner(name(a), a === corner)} onClick={pick} onKeyDown={keyAct(pick)}>
        <circle className="cw-ring" cx={x} cy={y} r="8" fill={a === corner ? COL.pick : 'none'} stroke={a === corner ? COL.pick : 'currentColor'} strokeOpacity=".7" strokeWidth="1.5" /><title>{v.corner(name(a), a === corner)}</title></g>; })}
      {pos.map(([x, y], a) => <text key={'n' + a} x={x + 11} y={y - 10} fontSize="10" fill="currentColor" opacity=".8" aria-hidden="true" style={{ pointerEvents: 'none' }}>{name(a)}</text>)}
    </svg>
    <div className="ln-chips"><button type="button" className="ln-btn" data-sign-rule onClick={() => setSigns(E.ruleSigns())}><Tx>{v.rule}</Tx></button>
      <button type="button" className="ln-btn" data-sign-plus onClick={() => setSigns(Object.fromEntries(edges.map(([a, i]) => [E.edgeKey(a, i), 1])))}><Tx>{v.allPlus}</Tx></button>
      <button type="button" className="ln-btn" data-sign-flip disabled={corner == null} onClick={() => setSigns(E.flipCorner(signs, corner))}><Tx>{corner == null ? v.pick : v.flip}</Tx></button></div>
    <p className="cw-out" aria-live="polite" data-out="faces" data-odd={k}><Tx>{v.faces(k)}</Tx></p>
    <p className="cw-out" aria-live="polite" data-out="gauge" data-gauge={gauge ? gauge.join(',') : 'none'}><Tx>{gauge ? v.gauge(gauge.map(name)) : v.notYet}</Tx></p>
    <p className="cw-out" data-out="count" data-count={cnt.odd} data-total={cnt.total}><Tx>{v.count(cnt.odd, cnt.total)}</Tx></p>
    <Pts items={v.caps} lang={L2} />{profile === 'Mathematician' && <Pts items={v.capsM} lang={L2} />}{!yl && <Checks t={t} ids={CHECK_IDS.CW6} />}</Root>;
}

// ================================================================ the script
export function CategoryWidgetsScript({ lang = 'en' }) {
  const L = LG(lang);
  return <div className="ln-card cw" data-widget="CategoryWidgetsScript"><ScriptBox lang={L} file="selfcheck/reports/lens_cat_check.py" text={LENS_CAT_PY} note={CWC[L].script.note} /></div>;
}
