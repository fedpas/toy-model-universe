// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Conventions tab of the Conventions page (conventionsCopy.js, ConventionsSection.jsx).
//  1. the data: 18 rows, each with one or more of the five flags; a row tagged checked names a check that exists (an id of the core table, a script of the package);
//     every file a row says it is used in exists; the 11 ideas H1 to H11; the glossary has each of the 14 terms of the vocabulary list (and calibration) once;
//     the Young Learner version is two plain sentences
//  2. the page, in a browser: English and Italian, three audiences, 1100 and 375 px: the rows, the badges, the ideas, the glossary, no sideways scroll,
//     the Young Learner reads the two sentences outside the fold and the rest inside it, the link on page 1 opens the tab
// Run: node test_conventions.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright';
import { PKG, PKG_DIST } from './paths.mjs';
import { setLang } from './ui_helpers.mjs';
import { CONV, CORE_IDS, ROWS, IDEAS, GLOSSARY, PAGE, PAGE_YL } from './conventionsCopy.js';
import { stepNo } from './steps.js';
let n = 0, bad = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const FLAGS = ['standard', 'checked', 'ours', 'open', 'input'];

// ---- 1. the data
ok(CONV.en === CONV.it, 'one English text serves both language slots (v11)');
ok(ROWS.length === 18 && ROWS.every((r, i) => r.n === i + 1), 'eighteen rows, numbered 1 to 18');
ok(ROWS.every(r => r.tags.length > 0 && r.tags.every(t => FLAGS.includes(t))), 'every row carries at least one of the five flags, and only those');
ok(ROWS.every(r => r.title && r.text && r.note), 'every row has a title, a statement and a note on its status');
// every file a row says it is used in (a name that ends in .js, .jsx or .py) is in the package
const all = []; const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { if (e.name === 'node_modules' || e.name === 'dist' || e.name.startsWith('.')) continue; const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else all.push(e.name); } };
walk(PKG);
const have = new Set(all);
const files = r => [...new Set([...(r.where || []), ...(r.scripts || [])].join(' ').match(/[A-Za-z0-9_]+\.(?:jsx|js|py)\b/g) || [])];
for (const r of ROWS) for (const f of files(r)) ok(have.has(f), `row ${r.n}: the file ${f} exists`);
// the checks: ids of the core table (read from selfcheck/core.json when it is in the package, else from the fixed list B1..B17 in conventionsCopy.js), scripts that exist
const coreFile = path.join(PKG, 'selfcheck', 'core.json');
let known = new Set(CORE_IDS), source = 'the fixed list B1 to B17';
if (fs.existsSync(coreFile)) { known = new Set(JSON.parse(fs.readFileSync(coreFile, 'utf8')).rows.map(x => x.id)); source = 'selfcheck/core.json'; }
for (const r of ROWS) for (const id of r.ids || []) ok(known.has(id), `row ${r.n}: ${id} is an id of ${source}`);
for (const r of ROWS) for (const s of r.scripts || []) ok(have.has(s), `row ${r.n}: the script ${s} exists`);
// X3: a row that carries the flag checked names at least one check (a core id or a script of the package)
for (const r of ROWS.filter(r => r.tags.includes('checked'))) ok((r.ids || []).length + (r.scripts || []).length > 0 || r.n === 2, `row ${r.n}: a checked row names a check`);
ok(ROWS[1].tags.includes('checked') && (ROWS[1].scripts || []).includes('labels_check.py'), 'row 2: the checked algebra Cl(3,1) names labels_check.py');
// the ids that the statements and notes quote in their text exist too
for (const r of ROWS) for (const id of (r.text + ' ' + r.note).match(/core·B\d+[a-z]?/g) || []) ok(known.has(id), `row ${r.n}: the text quotes ${id}, which exists`);
for (const t of [...CONV.en.lede, ...CONV.en.ledeM, ...IDEAS.flatMap(h => [h.proved, h.would, h.refute]), ...GLOSSARY.map(g => g[1])]) for (const id of t.match(/core·B\d+[a-z]?/g) || []) ok(known.has(id), `${id} exists (quoted in a text of the tab)`);
// the three conventions and the mirror state what the vocabulary says
ok(/Cl\(3,1\)/.test(ROWS[1].text) && /Cl\(1,3\)/.test(ROWS[2].text) && /Cl\(n,0,1\)/.test(ROWS[3].text), 'rows 2 to 4 are the conventions S, T and D (Cl(3,1), Cl(1,3), Cl(n,0,1))');
ok(/Q to Q \+ π/.test(ROWS[6].text) && /w to −w/.test(ROWS[6].text) && /nothing runs backwards/.test(ROWS[6].text), 'row 7 is the mirror: Q to Q + π, w to −w, nothing runs backwards');
ok(/exactly when its grade is even/.test(ROWS[7].text), 'row 8: a blade keeps its square under the mirror exactly when its grade is even');
// the present statements of the rows: the two namings are in general two algebras; doubling is stated for r = 0; the states statement is for hermitian functionals; the +1 PGA label is standard with its own script
ok(/chooses between Cl\(p,q\) and Cl\(q,p\)/.test(CONV.en.lede[1]) && /in general different algebras \(Cl\(3,1\) = M₄\(ℝ\), Cl\(1,3\) = M₂\(ℍ\)\)/.test(CONV.en.lede[1]) && /have isomorphic even parts and the same bivector squares/.test(CONV.en.lede[1]) && !/two namings of one picture|renames an algebra/.test(CONV.en.lede[1]), 'the lede says that Cl(p,q) and Cl(q,p) are in general different algebras with isomorphic even parts and the same bivector squares');
ok(/^A non-degenerate Clifford algebra A = Cl\(p,q\) \(r = 0\)/.test(ROWS[15].text) && /For r ≥ 1 the two actions of a null generator multiply to 0, so they generate only a proper subalgebra of End\(A\)/.test(ROWS[15].text) && /non-degenerate signature \(r = 0\) with n ≤ 4/.test(ROWS[15].note), 'row 16 (doubling) has its domain: r = 0, and says what happens for r ≥ 1');
ok(/Every positive hermitian functional vanishes/.test(ROWS[13].text) && /the word hermitian cannot be dropped/.test(ROWS[13].text), 'row 14: the functionals of the states statement are hermitian');
ok(/with n ≤ 6, with r = 0, 1, 2 null generators/.test(ROWS[8].note) && ROWS[8].ids.includes('core·B5b') && /core·B5b also with r = 1, 2 null generators/.test(ROWS[7].note), 'rows 8 and 9 cite B5b with its range: n ≤ 6 and r = 0, 1, 2');
ok(JSON.stringify(ROWS[10].tags) === '["checked","standard"]' && ROWS[10].scripts.includes('projective_selfcheck.py') && ROWS[10].scripts.includes('pgadyn_selfcheck.py') && /pointer, the source is not read here/.test(ROWS[10].note) && /Cl\(n,0,1\) for a \+1 base/.test(ROWS[10].note), 'row 11: the −1 and Lorentz bases are checked by projective_selfcheck.py, the +1 label is standard (pointer, source unread) with pgadyn_selfcheck.py');
{ const r5 = ROWS[4].text; for (const [id, g] of [['spin', 'eq'], ['comm', 'eq'], ['matter', 'eq'], ['spring', 'eq']]) ok(r5.includes(`step ${stepNo(g, id)})`) || r5.includes(`step ${stepNo(g, id)} `) || r5.includes(`(${stepNo(g, id)})`), `row 5 names the ${id} step (step ${stepNo(g, id)})`);
  ok(/spin step \(step \d+\) uses T for its spacetime algebra Cl\(1,3\)/.test(r5) && /state nothing that depends on the convention/.test(r5), 'row 5: the spin step uses T, the others state nothing that depends on the convention'); }
ok(!/lattice address/.test(ROWS[0].text + ROWS[0].where.join(' ')) && /Its place in the lattice of cells is \[p \+ q, p − q\]/.test(ROWS[0].text) && /“lattice address” \[p \+ q, p − q\] of a cell is something else/.test(GLOSSARY[0][1]), 'row 1 says the place in the lattice, and the glossary separates the lattice address from the address of a blade');
ok(/Three uses\./.test(GLOSSARY.find(g => g[0] === 'base / fibre')[1]) && /Three different meanings/.test(IDEAS[6].proved) && !/Used only for/.test(GLOSSARY.find(g => g[0] === 'base / fibre')[1]), 'the glossary lists the three uses of base / fibre that idea H7 counts');
ok(!/older|first assumed|previously/i.test(CONV.en.glossLede) && /uses a different word for the same thing/.test(CONV.en.glossLede), 'the glossary lede names no older word');
ok(!/proofs file/.test(IDEAS[7].proved) && /the Atlas page marks every role name as a reading we propose, not a result/.test(IDEAS[7].proved), 'H8: what is proved is stated as the page states it');
ok(/at most one spare null/.test(IDEAS[0].proved) && /Cl\(m,m\) for k = 2m and Cl\(m−1,m−1,1\) for k = 2m − 1/.test(IDEAS[0].proved) && /not a theorem/.test(IDEAS[0].proved), 'H1: the ladder of T7 has at most one spare null; more are the construction of ideas A and B');
ok(!ROWS[9].where.includes('the projective step') && ROWS[9].where.filter(w => /projectiveCopy/.test(w)).length === 1, 'row 10 lists the projective chapter once');
for (const l of ['en', 'it']) { ok(/25 cards/.test(PAGE_YL[l].before) && !/25 boxes|25 cells/.test(PAGE_YL[l].before), `${l}: the Young Learner frame says 25 cards`);
  ok(/core checks, labels_check\.py and the scripts named in each row/.test(PAGE[l].tags[0][1]) && /pgadyn_selfcheck\.py, projective_selfcheck\.py/.test(CONV[l].glance.tags[0][1]), `${l}: the frame and the glance name the scripts the checked rows stand on`); }
// the ideas
ok(IDEAS.length === 11 && IDEAS.every((h, i) => h.id === 'H' + (i + 1)), 'eleven ideas, H1 to H11');
ok(IDEAS.every(h => h.idea && h.proved && h.would && h.refute), 'every idea says what is proved, what would prove it and what would refute it');
ok(!IDEAS[3].tags.includes('checked') && /depend on n only/.test(IDEAS[3].proved), 'H4 is not tagged checked: the n-only fact is tested in test_story.mjs');
for (const h of IDEAS.filter(h => h.tags.includes('checked'))) ok(/core·B\d|check_T\d|cat_check|T\d+/.test(h.proved), `${h.id}: a checked line names its check`);
// the glossary
const TERMS = ['address', 'label −1, +1, 0', 'label 0', 'form', 'state label', 'mode', 'vertex', 'prime name', 'clock value', 'base / fibre', 'bit rule', 'mirror', 'null', 'trio'];
for (const t of [...TERMS, 'calibration']) ok(GLOSSARY.filter(g => g[0] === t).length === 1, `the glossary holds "${t}" once`);
ok(/Say “the square of a generator is −1, \+1 or 0”/.test(GLOSSARY[1][1]) && /not the empty address/.test(GLOSSARY[2][1]) && /Three objects share the word/.test(GLOSSARY[12][1]) && /Both sort a real square by its sign/.test(GLOSSARY[13][1]), 'the glossary says what label −1/+1/0 and label 0 are, the three kinds of null and the two trios');
// the Young Learner version: two plain sentences
const src = fs.readFileSync(path.join(PKG, 'test_yl_ui.mjs'), 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
ok(CONV.en.ledeY.length === 2 && CONV.en.ledeY.every(s => /^[A-Z][^.]*\.$/.test(s)), 'the Young Learner reads two sentences');
for (const s of [...CONV.en.ledeY, CONV.en.eyebrowY, CONV.en.wordsLinkY]) ok(!SYM.test(s) && !JAR.test(s), `plain words, no formula and no jargon: ${s}`);
ok(/choice of words/.test(CONV.en.ledeY[0]) && /top of the page/.test(CONV.en.ledeY[1]), 'the two sentences say that the words are a choice and that each page says which words it uses');

// ---- 2. the page, in a browser
const APP = 'file://' + (process.env.ATLAS_DIST || PKG_DIST) + '/app.html';
const b = await chromium.launch();
const txt = (pg, sel) => pg.locator(sel).first().innerText().then(t => t.replace(/\s+/g, ' ').trim());
async function open(w, hash, lang, prof, tag) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce' }), pg = await ctx.newPage();
  pg.on('pageerror', e => ok(false, `${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`));
  await pg.goto(APP + hash); await pg.waitForTimeout(300);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(200);
  return [ctx, pg];
}
for (const lang of ['en', 'it']) for (const prof of ['Physicist', 'Mathematician']) {
  const [ctx, pg] = await open(1100, '#conventions/conventions', lang, prof, `${lang}-${prof}`);
  const tag = `${lang}/${prof}`;
  ok(await pg.locator('.tabbar [role=tab]').count() === 2 && await pg.locator('.tabbar [data-tab="conventions"][aria-selected="true"]').count() === 1, `${tag}: a deep link opens the Conventions tab, the first of two`);
  ok(/^CONVENTIONS AND INVARIANTS/.test(await txt(pg, '.ls .eyebrow')), `${tag}: the eyebrow has no step number: ${await txt(pg, '.ls .eyebrow')}`);
  ok(await pg.locator('.cv-row').count() === 18 && await pg.locator('.cv-idea').count() === 11 && await pg.locator('.cv-gloss dt').count() === GLOSSARY.length, `${tag}: 18 rows, 11 ideas, ${GLOSSARY.length} glossary words`);
  ok(await pg.locator('.cv-row').evaluateAll(es => es.every(e => e.querySelectorAll('.audit-line > .tag[data-flag]').length > 0)), `${tag}: every row has a badge line (the badges are direct children of the paragraph)`);
  const flags = await pg.locator('.cv-row').evaluateAll(es => es.map(e => [...e.querySelectorAll('.audit-line > .tag[data-flag]')].map(x => x.getAttribute('data-flag')).join(' ')));
  ok(flags.every((f, i) => f.split(' ').sort().join() === [...ROWS[i].tags].sort().join()), `${tag}: the badges of each row are the flags of the data: ${flags.slice(0, 3).join(' | ')}`);
  ok(await pg.locator('.cv-row .tag[role=img]').evaluateAll(es => es.every(e => (e.getAttribute('aria-label') || '').length > 2)), `${tag}: every badge has an accessible name`);
  ok(await pg.locator('.ls-glance .tag').count() === 5, `${tag}: the glance has the five status lines`);
  ok(/core_check\.py/.test(await txt(pg, '.ls-glance')), `${tag}: the glance names the check script`);
  ok(/Convention S/.test(await txt(pg, '#cv-row-2')) && /Convention T/.test(await txt(pg, '#cv-row-3')), `${tag}: conventions S and T are rows 2 and 3`);
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${tag}: no sideways scroll at 1100 px`);
  await ctx.close();
}
{ const [ctx, pg] = await open(375, '#conventions/conventions', 'en', 'Mathematician', 'en-math-375');
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'Mathematician at 375 px: no sideways scroll');
  ok(await pg.locator('.ls .lede').count() >= 2, 'the Mathematician reads the formal introduction and the second paragraph');
  await ctx.close(); }
for (const [lang, w] of [['en', 375], ['it', 375], ['en', 1100]]) {
  const [ctx, pg] = await open(w, '#conventions/conventions', lang, 'Young Learner', `${lang}-yl-${w}`), tag = `${lang}/Young Learner/${w}`;
  ok(await pg.locator('.ls-glance').count() === 0, `${tag}: no status strip`);
  const lede = await pg.locator('.ls > .lede').allInnerTexts();
  ok(lede.length === 2 && lede.every((t, i) => t.trim() === CONV.en.ledeY[i]), `${tag}: the two sentences are the visible introduction: ${lede.join(' | ').slice(0, 90)}`);
  ok(await pg.locator('.ls > details .cv-row').count() === 18 && await pg.locator('.ls > .cv, .ls > .cv-row').count() === 0, `${tag}: the rows are inside the fold For older readers`);
  // the note under every tab (ls-cap) is read too: the Young Learner's note names no file and no language
  const outside = await pg.evaluate(() => [...document.querySelectorAll('.ls p, .ls h3, .ls dt, .ls dd, .ls .eyebrow')].filter(e => !e.closest('details')).map(e => e.textContent.replace(/\s+/g, ' ').trim()));
  ok(outside.length > 0 && outside.every(t => !SYM.test(t) && !JAR.test(t)), `${tag}: the text outside the fold has no formula and no jargon (${outside.length} blocks): ${outside.filter(t => SYM.test(t) || JAR.test(t)).join(' | ')}`);
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${tag}: no sideways scroll`);
  await ctx.close(); }
// the link on page 1 and the link on the other tabs open the tab
for (const prof of ['Physicist', 'Young Learner']) {
  const [ctx, pg] = await open(1100, '#rule', 'en', prof, 'link-' + prof);
  await pg.locator('.words-link button').click(); await pg.waitForTimeout(250);
  ok(/#conventions\/conventions$/.test(await pg.evaluate(() => location.hash)) && await pg.locator('.tabbar [data-tab="conventions"][aria-selected="true"]').count() === 1, `${prof}: the words link on page 1 opens the Conventions tab`);
  await pg.locator('.tabbar [data-tab="clock"]').click(); await pg.waitForTimeout(200);
  await pg.locator('.ls .ls-cap button').click(); await pg.waitForTimeout(200);
  ok(await pg.locator('.tabbar [data-tab="conventions"][aria-selected="true"]').count() === 1, `${prof}: the words link on the clock tab opens the Conventions tab`);
  await ctx.close(); }
await b.close();
console.log(bad ? `${bad} FAILURES of ${n}` : `ALL CONVENTIONS TESTS PASS: ${n} checks`);
process.exit(bad ? 1 : 0);
