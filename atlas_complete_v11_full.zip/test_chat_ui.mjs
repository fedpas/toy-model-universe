// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The chat page against a faked /api, in English and Italian: what a reader sees when the route streams text, stops at the token cap, sends nothing,
// reports an error half way, refuses (rate limit, daily budget, 403) or is down; that the status line is localised and cleared at the end; the live region,
// the label, aria-pressed and the privacy sentence; and that the page sends exactly one user turn (the same one to both routes under "Compare models").
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const b = await chromium.launch(); const errs = []; let n = 0; const ok = (c, m) => { n++; if (!c) errs.push(m); };
const DIST = process.env.ATLAS_DIST || PKG_DIST;          // the built page; or set ATLAS_DIST
// a fetch to /api from a file:// page is refused by the browser before it can be faked, so the built page is served over http from a throwaway server.
// The server also answers POST /api/chat-openai slowly (status, a pause, a first word, a pause, the rest), so the status line and the streaming text can be seen.
const served = [];
const srv = http.createServer((q, r) => {
  if (q.method === 'POST' && q.url === '/api/chat-openai') {
    let body = ''; q.on('data', d => { body += d; }); q.on('end', () => {
      served.push(JSON.parse(body)); r.writeHead(200, { 'content-type': 'text/event-stream' });
      r.write('data: {"type":"status","code":"reasoning"}\n\n');
      setTimeout(() => r.write('data: {"choices":[{"delta":{"content":"Do"}}]}\n\n'), 1200);
      setTimeout(() => { r.write('data: {"choices":[{"delta":{"content":"ne."}}]}\n\n'); r.end(); }, 2800);
    }); return;
  }
  // re-test V1-5: POST /api/chat (when no page route intercepts it) streams an image cut in the middle of its target, pauses, then finishes it
  if (q.method === 'POST' && q.url === '/api/chat') {
    q.on('data', () => {}); q.on('end', () => { r.writeHead(200, { 'content-type': 'text/event-stream' });
      r.write('data: ' + JSON.stringify({ type: 'content_block_delta', delta: { text: 'See ![a cat](https://evil.invalid/c' } }) + '\n\n');
      setTimeout(() => r.write('data: ' + JSON.stringify({ type: 'content_block_delta', delta: { text: '.png) and [run](javascript:al' } }) + '\n\n'), 1400);
      setTimeout(() => { r.write('data: ' + JSON.stringify({ type: 'content_block_delta', delta: { text: 'ert(1)) more.' } }) + '\n\n'); r.end(); }, 2800);
    }); return;
  }
  const f = path.join(DIST, q.url.split('?')[0].replace(/^\/+/, '') || 'app.html'); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : 'text/html' }); r.end(d); });
});
await new Promise(r => srv.listen(0, r)); const URL = `http://localhost:${srv.address().port}/app.html#ask`;
const sse = parts => parts.map(p => `data: ${JSON.stringify(p)}\n\n`).join('');
const delta = t => ({ type: 'content_block_delta', delta: { text: t } });
const W = {
  en: { un: 'Chat is unavailable.', rate1: 'Too many questions, try again in a minute.', rate3: 'Too many questions, try again in 3 minutes.', budget: 'The daily limit of this site is used up; try again tomorrow.', cut: 'The answer was cut off at this site’s length limit.', empty: 'The model sent no answer. Try again, perhaps with a shorter question.', cutEmpty: 'The model used up this site’s length limit before answering. Try a shorter or narrower question.', reasoning: 'OpenAI o3 is reasoning…', label: 'Your question', privacy: 'Your question and the settings you chose are sent through this site to Anthropic or OpenAI (to both under “Compare models”) to get the answer; do not type anything private; this site does not store questions.' },
  it: { un: 'Il servizio chat non è disponibile.', rate1: 'Troppe domande, riprova tra un minuto.', rate3: 'Troppe domande, riprova tra 3 minuti.', budget: 'Il limite giornaliero di questo sito è esaurito; riprova domani.', cut: 'La risposta è stata tagliata al limite di lunghezza di questo sito.', empty: 'Il modello non ha mandato alcuna risposta. Riprova, magari con una domanda più breve.', cutEmpty: 'Il modello ha usato tutto il limite di lunghezza di questo sito prima di rispondere. Prova con una domanda più breve o più precisa.', reasoning: 'OpenAI o3 sta ragionando…', label: 'La tua domanda', privacy: 'La domanda e le impostazioni scelte passano da questo sito ad Anthropic o a OpenAI (a entrambi con «Confronta modelli») per avere la risposta; non scrivere nulla di privato; questo sito non conserva le domande.' },
};
// [name, route, agent, status, headers, body, expected text (regex or ''), expected note key (or null)]
const CASES = [
  ['text', 'chat', 'anthropic', 200, {}, sse([delta('Hello '), delta('atlas')]), /^Hello atlas$/, null],
  ['cut at the token cap', 'chat', 'anthropic', 200, {}, sse([delta('The answer is that the'), { type: 'truncated' }]), /^The answer is that the$/, 'cut'],
  ['no answer at all', 'chat', 'anthropic', 200, {}, sse([{ type: 'message_start', message: {} }, { type: 'message_stop' }]), '', 'empty'],
  ['o3: reasoning used the whole cap', 'chat-openai', 'openai', 200, {}, sse([{ type: 'status', code: 'reasoning' }, { choices: [{ delta: {}, finish_reason: 'length' }] }, { type: 'truncated' }]), '', 'cutEmpty'],
  ['o3: status, then text', 'chat-openai', 'openai', 200, {}, sse([{ type: 'status', code: 'reasoning' }, { choices: [{ delta: { content: 'Yo' } }] }]), /^Yo$/, null],
  ['error half way', 'chat', 'anthropic', 200, {}, sse([delta('Partial'), { type: 'error', message: 'The model service was interrupted.' }]), '', 'un'],
  ['error only', 'chat-openai', 'openai', 200, {}, sse([{ type: 'error', message: 'The OpenAI model service is unavailable.' }]), '', 'un'],
  ['429 rate limit (text body)', 'chat', 'anthropic', 429, { 'retry-after': '30' }, 'Too many requests. Try again shortly.', '', 'rate1'],
  ['429 rate limit (long wait)', 'chat', 'anthropic', 429, { 'retry-after': '180', 'content-type': 'application/json' }, '{"error":"rate"}', '', 'rate3'],
  ['429 daily budget', 'chat-openai', 'openai', 429, { 'retry-after': '5000', 'content-type': 'application/json' }, '{"error":"budget"}', '', 'budget'],
  ['403', 'chat', 'anthropic', 403, {}, 'Origin not allowed.', '', 'un'],
  ['502', 'chat', 'anthropic', 502, {}, 'The model service is unavailable.', '', 'un'],
  // the answer filter (lib/answerFilter.js) on the page: images become their alt text, links that are not https:// their words; an https link stays (as Markdown text with the stand-in renderer)
  ['images and bad links filtered', 'chat', 'anthropic', 200, {}, sse([delta('See ![a cat](https://evil.invalid/c.png) and <img src="https://evil.invalid/r.png" alt="raw">, '), delta('[click](javascript:alert(1)), [plain](http://evil.invalid/p) or [docs](https://docs.example/x).')]), /^See a cat and raw, click, plain or \[docs\]\(https:\/\/docs\.example\/x\)\.$/, null],
];
const NOTEKIND = { cut: 'truncated', empty: 'empty', cutEmpty: 'truncatedEmpty', un: 'unavailable', rate1: 'rate', rate3: 'rate', budget: 'budget' };
const settled = pg => pg.waitForFunction(() => !document.querySelector('.ask-button').disabled && !document.querySelector('.match-button').disabled, null, { timeout: 8000 }).catch(() => {});
const state = pg => pg.evaluate(() => { const a = document.querySelector('article.answer'); const t = s => (s ? s.textContent : '').trim();
  return { answer: t(a), text: t(a && a.querySelector(':scope > div')), note: t(a && a.querySelector('.chat-note')), kind: a?.querySelector('.chat-note')?.dataset.note || null, status: document.querySelectorAll('.chat-status').length, live: t(document.querySelector('.chat-live')), askDisabled: document.querySelector('.ask-button').disabled }; });
async function open(lang) { const pg = await b.newPage({ viewport: { width: 1100, height: 800 } }); pg.on('pageerror', e => errs.push(`${lang}: page error ${e.message}`)); await pg.goto(URL); await pg.waitForTimeout(300); if (lang === 'it') await setLang(pg, 'it'); return pg; }

for (const lang of ['en', 'it']) {
  const w = W[lang];
  // ---- the form itself: label, aria-pressed, live region, privacy sentence
  { const pg = await open(lang);
    ok(await pg.getByLabel(w.label, { exact: true }).evaluate(e => e.tagName === 'TEXTAREA', null, { timeout: 2000 }).catch(() => false), `${lang}: the question box has the label "${w.label}"`);
    ok(await pg.locator('label[for="chat-question"]').count() === 1 && await pg.locator('textarea#chat-question').count() === 1, `${lang}: a real <label for> on the textarea`);
    const pressed = async () => (await pg.locator('.agent-selector button').evaluateAll(bs => bs.map(x => x.getAttribute('aria-pressed')))).join();
    ok(await pressed() === 'true,false', `${lang}: aria-pressed shows Claude chosen: ${await pressed()}`);
    await pg.locator('.agent-selector button', { hasText: 'OpenAI o3' }).click(); ok(await pressed() === 'false,true', `${lang}: aria-pressed follows the choice: ${await pressed()}`);
    ok(await pg.locator('.chat-live[aria-live="polite"]').count() === 1 && (await pg.locator('.chat-live').textContent()) === '', `${lang}: one polite live region, empty before any answer`);
    const priv = ((await pg.locator('.chat-privacy').textContent({ timeout: 2000 }).catch(() => '')) || '').trim(); ok(priv === w.privacy, `${lang}: the privacy sentence is "${w.privacy}", the page shows "${priv}"`);
    ok(await pg.locator('textarea').first().getAttribute('aria-describedby', { timeout: 2000 }).catch(() => null) === 'chat-privacy' && await pg.locator('#chat-privacy.chat-privacy').count() === 1, `${lang}: the privacy sentence describes the question box`);
    const box = await pg.locator('.chat-composer').boundingBox({ timeout: 2000 }).catch(() => null), pbox = await pg.locator('.chat-privacy').boundingBox({ timeout: 2000 }).catch(() => null); ok(box && pbox && pbox.y >= box.y + box.height - 1, `${lang}: the privacy sentence sits under the form`);
    await pg.close(); }
  // ---- answers, notes and refusals
  for (const [name, route, agent, status, headers, body, wantText, wantNote] of CASES) {
    const pg = await open(lang); const sent = [];
    await pg.route('**/api/' + route, r => { sent.push(r.request().postDataJSON()); r.fulfill({ status, headers, contentType: headers['content-type'] || (status === 200 ? 'text/event-stream' : 'text/plain'), body }); });
    if (agent === 'openai') await pg.locator('.agent-selector button', { hasText: 'OpenAI o3' }).click();
    await pg.locator('.chat-composer textarea').fill('What is checked?'); await pg.locator('.ask-button').click(); await settled(pg); await pg.waitForTimeout(150);
    const s = await state(pg), tag = `${lang}/${name}`;
    if (wantText) ok(wantText.test(s.text), `${tag}: expected text ${wantText}, the page shows "${s.text}"`); else ok(s.text === '', `${tag}: no answer text expected, the page shows "${s.text}"`);
    if (wantNote) ok(s.note === w[wantNote] && s.kind === NOTEKIND[wantNote], `${tag}: expected the note "${w[wantNote]}", the page shows "${s.note}" (${s.kind})`); else ok(s.note === '' && s.kind === null, `${tag}: no note expected, the page shows "${s.note}"`);
    ok(s.status === 0 && !/reasoning|ragionando/.test(s.answer), `${tag}: the status line is gone when the stream has ended (${s.status})`);
    ok(s.live === [wantText ? s.text : '', wantNote ? w[wantNote] : ''].filter(Boolean).join(' '), `${tag}: the live region carries the finished answer, "${s.live}"`);
    ok(!s.askDisabled, `${tag}: the Ask button is enabled again`);
    ok(sent.length === 1 && Array.isArray(sent[0].messages) && sent[0].messages.length === 1 && sent[0].messages[0].role === 'user' && sent[0].messages[0].content === 'What is checked?' && sent[0].spokenLang === lang && sent[0].isMatchMode === undefined, `${tag}: the page sends one user turn: ${JSON.stringify(sent[0] && sent[0].messages)}`);
    await pg.close();
  }
  // ---- the status line, localised, while o3 reasons; the live region waits for the end (served slowly by the local server)
  { const pg = await open(lang); served.length = 0; await pg.locator('.agent-selector button', { hasText: 'OpenAI o3' }).click();
    await pg.locator('.chat-composer textarea').fill('Slow one'); await pg.locator('.ask-button').click(); await pg.waitForTimeout(600);
    const mid = await state(pg), st = ((await pg.locator('.chat-status').textContent().catch(() => '')) || '').trim();
    ok(st === w.reasoning && mid.live === '' && mid.askDisabled, `${lang}: while o3 reasons the status line reads "${w.reasoning}" (shows "${st}"), the live region is still empty ("${mid.live}")`);
    await pg.waitForTimeout(1300); const mid2 = await state(pg);
    ok(mid2.text === 'Do' && mid2.status === 0 && mid2.live === '', `${lang}: the first text replaces the status line and streams visibly, while the live region waits for the end: ${JSON.stringify(mid2)}`);
    await settled(pg); await pg.waitForTimeout(150); const end = await state(pg);
    ok(end.status === 0 && end.text === 'Done.' && end.live === 'Done.' && end.note === '', `${lang}: at the end the status line is cleared and the live region carries the answer: ${JSON.stringify(end)}`);
    ok(served.length === 1 && served[0].messages.length === 1 && served[0].messages[0].content === 'Slow one', `${lang}: one user turn reached the route`);
    await pg.close(); }
  // ---- re-test V1-5: the text is filtered on every streamed prefix, not only at the end (the stand-in renderer prints what it is given, so the Markdown source would show)
  { const pg = await open(lang); await pg.locator('.chat-composer textarea').fill('Picture?'); await pg.locator('.ask-button').click(); await pg.waitForTimeout(800);
    const m1 = await state(pg); ok(m1.text === 'See a cat' && !/!\[|evil\.invalid/.test(m1.answer), `${lang}: mid-stream, inside the image target, only the alt text shows: ${JSON.stringify(m1.text)}`);
    await pg.waitForTimeout(1400); const m2 = await state(pg); ok(m2.text === 'See a cat and run' && !/javascript|evil\.invalid|!\[/.test(m2.answer), `${lang}: mid-stream, inside a javascript: target, only the words show: ${JSON.stringify(m2.text)}`);
    await settled(pg); await pg.waitForTimeout(150); const end = await state(pg); ok(end.text === 'See a cat and run more.' && end.live === 'See a cat and run more.', `${lang}: at the end the filtered text and the live region agree: ${JSON.stringify(end)}`);
    await pg.close(); }
  // ---- Compare models: one side fails or is refused, the other speaks; both get the same single question
  for (const [name, a, o, wantA, wantO] of [
    ['one side down', [200, {}, sse([delta('Claude side')])], [200, {}, sse([{ type: 'status', code: 'reasoning' }, { type: 'error', message: 'down' }])], 'Claude side', w.un],
    ['budget and a cut', [429, { 'retry-after': '100', 'content-type': 'application/json' }, '{"error":"budget"}'], [200, {}, sse([{ type: 'status', code: 'reasoning' }, { choices: [{ delta: { content: 'Half' } }] }, { type: 'truncated' }])], w.budget, 'Half' + w.cut],
  ]) {
    const pg = await open(lang); const sent = [];
    await pg.route('**/api/chat', r => { sent.push(r.request().postDataJSON()); r.fulfill({ status: a[0], headers: a[1], contentType: a[1]['content-type'] || 'text/event-stream', body: a[2] }); });
    await pg.route('**/api/chat-openai', r => { sent.push(r.request().postDataJSON()); r.fulfill({ status: o[0], headers: o[1], contentType: 'text/event-stream', body: o[2] }); });
    await pg.locator('.chat-composer textarea').fill('Compare'); await pg.locator('.match-button').click();
    await pg.waitForFunction(() => !document.querySelector('.match-button').disabled, null, { timeout: 8000 }).catch(() => {}); await pg.waitForTimeout(150);
    const cols = (await pg.locator('.agent-column').allTextContents()).map(t => t.replace(/^(ANTHROPIC · CLAUDE OPUS|OPENAI · O3)/, '').trim()), tag = `${lang}/compare ${name}`;
    ok(cols[0] === wantA, `${tag}: the Claude column shows "${cols[0]}", expected "${wantA}"`); ok(cols[1] === wantO, `${tag}: the OpenAI column shows "${cols[1]}", expected "${wantO}"`);
    ok(await pg.locator('.chat-status').count() === 0, `${tag}: no status line left`);
    const live = ((await pg.locator('.chat-live').textContent()) || '').trim(); ok(live.startsWith('Claude Opus: ') && live.includes(' OpenAI o3: ') && live.includes(wantA), `${tag}: the live region announces both answers at the end: "${live}"`);
    ok(sent.length === 2 && sent.every(p => p.isMatchMode === true && p.messages.length === 1 && p.messages[0].role === 'user' && p.messages[0].content === 'Compare') && JSON.stringify(sent[0]) === JSON.stringify(sent[1]), `${tag}: the same single question goes to both routes`);
    await pg.close();
  }
}
await b.close(); srv.close(); console.log(errs.length ? errs.join('\n') + `\n${errs.length} FAILURES of ${n}` : `ALL ${n} CHAT UI CHECKS PASS`); process.exit(errs.length ? 1 : 0);
