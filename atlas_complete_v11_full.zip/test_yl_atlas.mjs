// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder
import * as M from './matrixData.js';
import { YL_ATLAS_IDS } from './ylAtlas.js';
import { AUDITED_ATLAS, cliffordCell } from './genesis_audit_v3.js';
import { stageCells } from './genesisStory.js';
// Data test of the atlas and the Genesis ladder as the Young Learner reads them (ylAtlas.js, genesisStory.js): every one of the 25 boxes and the
// 9 stages, in both metrics (Space + and the mirror reading Time +), in English and Italian, exactly as the page gets them (matrixData.js).
//  1. a physical name (the weak force, gravity, antimatter, the Higgs field, quarks, ...) comes with a hedge in the same sentence or the next one
//     (a reading, an idea, a choice, not derived, does not come out of the box, standard physics, a fact "in nature" and not of the box, ...):
//     a reading is never stated as a fact;
//  2. "predicts / proves / explains" (prevede / dimostra / spiega) appear only denied ("not something the rule proves", "non lo dimostra");
//  3. the count 17 is "one way of counting" that we chose, and the count 34 (which no script computes) is gone (re-test T4-3);
//  4. the mirror reading says whether the mirror box comes in two halves exactly as cliffordCell says, box by box and stage by stage (T4-4);
//  5. after eight more switches the old kinds come back on a grid 16 by 16 (cliffordCell), not "sixteen times bigger" (T4-16);
//  6. no formula symbol and no technical word (the lists of test_yl_ui.mjs), including "axiom" and "quaternion" (T4-15).
// Exit 1 on any failure.  Run: node test_yl_atlas.mjs
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const Y = 'Young Learner', METRICS = ['Spatial', 'Temporal'];
const rec = (id, lang, metric) => { const r = M.getCompleteDualMetricDisplayData(id, lang, Y, metric); return [r.title, r.subtitle, r.desc].join(' ¶ '); };
const gen = (s, lang, metric) => { const r = M.getGenesisDisplayData(s, lang, Y, metric); return [r.title, r.desc].join(' ¶ '); };
const sentences = t => t.split(/(?<=[.;!?¶])\s+|¶/).map(x => x.trim()).filter(Boolean);
const PHYS = {
  en: /weak force|weak interaction|electroweak|strong force|strong interaction|gravity|antimatter|Higgs|neutrino|quark|electron|lepton|\bZ and W\b|mixing angle|universe|proton|neutron|left and right hands/i,
  it: /forza debole|interazione debole|elettrodebol|forza forte|interazione forte|gravità|antimateria|Higgs|neutrino|quark|elettron|lepton|\bZ e W\b|angolo di mescolamento|universo|proton|neutron|destra e sinistra|mano destra e la sinistra/i,
};
const HEDGE = {
  en: /\bin nature\b|\breading\b|\bidea\b|we chose|a choice|not derived|does not prove|do not prove|not something the rule proves|only bookkeeping|guess|open question|is open|are open|nobody knows|standard physics|real physics|fact about nature|does not come out|do not come out|does not explain|does not say|not a result|no law|no counting law|no edge|no weight|does not produce|do not produce|not derived|from a published paper|is still/i,
  it: /\bin natura\b|\blettura\b|\bidea\b|abbiamo scelto|una scelta|non è ricavat|non lo dimostra|non dimostra|non qualcosa che la regola dimostra|solo contabilità|ipotesi|domanda aperta|è aperto|sono aperte|nessuno lo sa|fisica standard|fisica vera|fatto della natura|non esce|non escono|non ne esce|non spiega|non dice|non un risultato|nessuna legge|nessun bordo|nessun peso|non producono|da un articolo pubblicato|continua a non|resta/i,
};
const CLAIM = { en: /\b(predicts|proves|explains|predicted|proved|explained)\b/i, it: /\b(prevede|dimostra|spiega|previsto|dimostrato|spiegato)\b/i };
const DENIED = { en: /\b(not|no|nothing|never)\b[^.;:,]{0,30}\b(predicts|proves|explains|predicted|proved|explained)\b/i, it: /\b(non|nessun\w*|nulla|mai)\b[^.;:,]{0,30}\b(prevede|dimostra|spiega|previsto|dimostrato|spiegato)\b/i };
const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
const texts = [];   // [where, lang, text]
for (const lang of ['en', 'it']) for (const metric of METRICS) {
  for (const id of YL_ATLAS_IDS) texts.push([`${id} ${metric}`, lang, rec(id, lang, metric), id, metric]);
  for (let s = 0; s < 9; s++) texts.push([`genesis ${s} ${metric}`, lang, gen(s, lang, metric), s, metric]);
}
ok(YL_ATLAS_IDS.length === AUDITED_ATLAS.length && texts.length === 2 * 2 * (YL_ATLAS_IDS.length + 9), `every box (${YL_ATLAS_IDS.length}) and stage (9) in both metrics and languages: ${texts.length} texts`);
// 1, 2, 6
let named = 0;
for (const [where, lang, t] of texts) {
  const ss = sentences(t);
  ss.forEach((x, i) => { if (!PHYS[lang].test(x)) return; named++; ok(HEDGE[lang].test(x) || (ss[i + 1] && HEDGE[lang].test(ss[i + 1])), `${lang} ${where}: "${PHYS[lang].exec(x)[0]}" is named without a hedge in the same or the next sentence: "${x.slice(0, 120)}"`); });
  for (const x of ss) if (CLAIM[lang].test(x)) ok(DENIED[lang].test(x), `${lang} ${where}: "${CLAIM[lang].exec(x)[0]}" is not denied: "${x.slice(0, 120)}"`);
  const m = SYM.exec(t.replace(/ ¶ /g, ' ')) || JAR.exec(t); ok(!m, `${lang} ${where}: a formula or technical word ("${m && m[0]}"): "${t.slice(0, 100)}"`);
}
ok(named >= 40, `the hedge rule is exercised: ${named} sentences name physics`);
// 3. the counts 17 and 34
for (const [where, lang, t] of texts) {
  ok(!/\b34\b/.test(t), `${lang} ${where}: the count 34 has no source and is gone`);
  for (const x of sentences(t)) if (/\b17\b/.test(x)) ok((lang === 'en' ? /one way of counting gives 17/i : /un modo di contare dà 17/i).test(x) && (where.startsWith('Sector_Electroweak_Unified')), `${lang} ${where}: 17 only as "one way of counting gives 17": "${x.slice(0, 120)}"`);
}
for (const lang of ['en', 'it']) for (const metric of METRICS) ok((lang === 'en' ? /we chose/ : /abbiamo scelto/).test(rec('Sector_Electroweak_Unified', lang, metric)), `${lang} ${metric}: the way of counting is ours`);
// 4. the halves of the mirror box, from cliffordCell
const halves = c => /2$/.test(c.kind), NOT = { en: 'mirror box does not come in two halves', it: 'scatola allo specchio non si divide in due metà' }, YES = { en: /mirror box comes in two halves|mirror box both come in two halves|mirror box comes in two halves too/, it: /scatola allo specchio si divide in due metà|si dividono entrambe in due metà|Anche la scatola allo specchio si divide/ };
let split = 0;
for (const [where, lang, t, key, metric] of texts) {
  if (metric !== 'Temporal') continue;
  const cells = typeof key === 'number' ? stageCells(key) : (() => { const r = AUDITED_ATLAS.find(x => x[0] === key); return r[3] === null ? null : [cliffordCell(r[3], r[4]), cliffordCell(r[4], r[3])]; })();
  if (!cells) continue;
  const [a, m] = cells, odd = typeof key !== 'number' || (key % 2 === 1 && key > 1);   // stage 1: the lone switch has no sign yet, no leftover to sign (V4-2)
  if (halves(a) && !halves(m) && odd) { split++; ok(t.includes(NOT[lang]) && !YES[lang].test(t), `${lang} ${where}: the box comes in two halves and its mirror ${m.algebra} does not: the mirror reading says so`); }
  else if (halves(m) && !halves(a)) ok(YES[lang].test(t) && !t.includes(NOT[lang]), `${lang} ${where}: the mirror ${m.algebra} comes in two halves: the mirror reading says so`);
  else ok(!t.includes(NOT[lang]) && !YES[lang].test(t), `${lang} ${where}: no claim about halves (${a.algebra} / ${m.algebra})`);
}
ok(split >= 2 * (3 + 3), `the halves rule is exercised on the boxes and stages that split: ${split}`);
// 5. eight more switches: a grid WIDE by WIDE with an old box in every square, MORE times as many pieces
{ const P8 = cliffordCell(8, 0), P0 = cliffordCell(0, 0), WIDE = P8.N / P0.N, MORE = P8.dim / P0.dim;
  for (const [where, lang, t] of texts) ok(!/sixteen times bigger|16 times bigger|sedici volte più grand|16 volte più grand/i.test(t), `${lang} ${where}: no "sixteen times bigger"`);
  // V3-5 (round 3): period 8 is never a wall, a reset or a new start: the old kinds come around again ("It is not a wall" is the one allowed use)
  for (const [where, lang, t] of texts) { const r = /\breset|\bstarts? (over|again)|\bbegins? again|\bstart over|ricominci|azzer|\bwall\b|\bmuro\b/i.exec(t.replace(/\b(It is not a wall|Non è un muro)\b/g, '')); ok(!r, `${lang} ${where}: "${r && r[0]}" reads as a reset or a wall`); }
  for (const lang of ['en', 'it']) {
    const ch = rec('Sector_Cosmic_Horizon', lang, 'Spatial'), g8 = gen(8, lang, 'Spatial');
    for (const [w, t] of [['Cosmic Horizon', ch], ['stage 8', g8]]) ok(t.includes(lang === 'en' ? `${WIDE} by ${WIDE} squares` : `${WIDE} per ${WIDE} caselle`) && t.includes(lang === 'en' ? `${MORE} times as many pieces` : `${MORE} volte più pezzi`), `${lang} ${w}: the grid is ${WIDE} by ${WIDE} and holds ${MORE} times as many pieces (cliffordCell)`);
  }
  const msrc = fs.readFileSync('./MaxwellSection.jsx', 'utf8'), mx = msrc.match(/ladKind: `[^`]*`/g) || [];
  ok(mx.length === 2 && mx.every(x => !/times bigger|volte più grand/.test(x) && /\$\{LAD_W\} (times as wide|volte più larga)/.test(x) && /\$\{LAD_P\}/.test(x) && !/\d/.test(x.replace(/\$\{[^}]*\}/g, ''))) && /const LAD_P = DICT\.why8\.minimal_period, LAD_W = cliffordCell\(LAD_P, 0\)\.N \/ cliffordCell\(0, 0\)\.N;/.test(msrc), 'the Maxwell ladder for the Young Learner: period and grid width read from the data (no typed digit), a grid wider and taller, not "times bigger"'); }
// the picture of the atlas page is named with the Young Learner's own names of the four views (V1-25), the same words as the controls of the atlas page (YLC in App.jsx)
{ const YV = (await import('./ylAtlas.js')).YL_VIEW_NAMES, app = fs.readFileSync('./App.jsx', 'utf8'), cv = fs.readFileSync('./SimplexCanvas.jsx', 'utf8');
  for (const lang of ['en', 'it']) { const m = new RegExp(`\\b${lang}:\\{views:\\{([^}]*)\\}`).exec(app), names = Object.fromEntries([...(m?.[1] || '').matchAll(/(\w+):'([^']*)'/g)].map(x => [x[1], x[2]]));
    ok(JSON.stringify(names) === JSON.stringify(YV[lang]), `${lang}: YL_VIEW_NAMES are the names on the controls of the atlas page (${JSON.stringify(names)})`);
    ok(Object.values(YV[lang]).every(w => !SYM.test(w) && !JAR.test(w)), `${lang}: the plain view names have no symbol and no jargon`); }
  ok(/stepAudience\(\) === 'Young Learner'/.test(cv) && /YL_VIEW_NAMES/.test(cv), 'SimplexCanvas names the picture with the plain view name for the Young Learner'); }
console.log(bad ? `${bad} FAILURES of ${n} checks` : `ALL YOUNG LEARNER ATLAS TESTS PASS: ${n} checks (${texts.length} texts, ${named} sentences that name physics, ${split} mirror readings of a box that splits)`);
process.exit(bad ? 1 : 0);
