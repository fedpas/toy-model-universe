// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML, SHOTS } from './paths.mjs';
import { chromium } from 'playwright';
import { setLang, tab, tabTo, focused } from './ui_helpers.mjs';
const b=await chromium.launch();const errs=[];let fails=0;
for(const [lang,w] of [['en',1100],['it',1100],['en',375],['it',375]]){
 const pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push(lang+w+': '+e.message));pg.on('console',m=>m.type()==='error'&&errs.push(lang+w+' console: '+m.text()));
 await pg.goto(APP_HTML + '#shapes');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.waitForTimeout(200);
 await tab(pg,'gosset');
 { const g=pg.locator('#sh-gosset .gs-chip'); const m=await g.count(); if(m<11) errs.push(lang+w+' gosset chips '+m);
   for(let i=0;i<m;i++){ if(i>=await g.count())break; await g.nth(i).click({timeout:3000}); }
   const sv=await pg.locator('#sh-gosset svg circle').count(); if(sv<60) errs.push(lang+w+' coxeter plane circles '+sv); }
 for(const sec of ['#sh-orth','#sh-demi']){
  await tab(pg,sec==='#sh-orth'?'orth':'demi');
  const bt=pg.locator(sec+' button').filter({hasText:/^[0-9]$/});
  const n=await bt.count();
  for(let i=0;i<n;i++){if(i>=await bt.count())break;await bt.nth(i).click({timeout:3000});}
  if(n<6){errs.push(`${lang}${w} ${sec}: only ${n} chips`);}
 }
 const ov=await pg.evaluate(()=>document.documentElement.scrollWidth-window.innerWidth);
 if(ov>2){fails++;errs.push(`${lang}${w}: horizontal overflow ${ov}px`);}
 // keyboard (v9): in the Maxwell incidence picture of the demicube step, a blade is reached with Tab and isolated with Enter
 { const P='#sh-demi svg[role=group] [role=button]';
   if(!(await tabTo(pg,'.tabbar [data-tab="demi"]',P,200)))errs.push(`${lang}${w}: no blade of the incidence picture reachable with Tab`);
   else { await pg.keyboard.press('Tab'); const lab=await focused(pg,'aria-label'); await pg.keyboard.press('Enter'); await pg.waitForTimeout(60);
     const cap=await pg.locator('#sh-demi svg[role=group] + p.sh-cap').textContent().catch(()=>''); if(await pg.locator(P+'[aria-pressed="true"]').count()!==1||!cap.includes(lab))errs.push(`${lang}${w}: Enter on blade ${lab} did not isolate it: "${cap}"`); } }
 if(w===375){await tab(pg,'gosset');await pg.locator('#sh-gosset').screenshot({path:`${SHOTS}/gs_${lang}_mobile.png`});}
 if(w===375){await tab(pg,'demi');await pg.locator('#sh-demi').screenshot({path:`${SHOTS}/sh_demi_${lang}_mobile.png`});}
 await pg.close();}
// equations page: signature chips redraw the octahedron (12 edges each), blades isolate equations
for(const lang of ['en','it']) for(const w of [1100,375]){
 const pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push('eq '+lang+w+': '+e.message));pg.on('console',m=>m.type()==='error'&&errs.push('eq '+lang+w+' console: '+m.text()));
 await pg.goto(APP_HTML + '#equations');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.waitForTimeout(200);
 await pg.locator('[data-profile="Physicist"]').click(); await pg.waitForTimeout(150);   // v9: the role table sits in a closed fold for the Young Learner (the default audience), so the formal checks run as the Physicist
 const ch=pg.locator('#eq-comm .eq-chip');
 for(let i=0;i<await ch.count();i++){await ch.nth(i).click();const ln=await pg.locator('#eq-comm svg line').count();if(ln!==12)errs.push(`eq ${lang}${w} chip ${i}: ${ln} octahedron edges`);}
 const rows=await pg.locator('#eq-comm .eq-card table').nth(1).locator('tbody tr').count(); if(rows<1)errs.push('eq role table empty');
 await tab(pg,'dirac');
 const dots=pg.locator('#eq-dirac svg g[style*="cursor"]'); if(await dots.count()!==8)errs.push('eq dirac: '+await dots.count()+' clickable equations');
 await dots.nth(3).click(); if(!(await pg.locator('#eq-dirac .eq-card p.eq-cap').first().textContent().then(x=>/5/.test(x))))errs.push('eq dirac: isolation caption');
 const nl=await pg.locator('#eq-dirac svg line').count(); if(nl!==40)errs.push('eq dirac lines '+nl);
 // keyboard (v9): the odd blades of the Dirac picture are reached with Tab; Enter isolates one, Space releases it
 if(!(await tabTo(pg,'.tabbar [data-tab="dirac"]','#eq-dirac svg [role=button]',120)))errs.push(`eq ${lang}${w}: no Dirac blade reachable with Tab`);
 else { await pg.keyboard.press('Tab'); await pg.keyboard.press('Tab'); const lab=await focused(pg,'aria-label'); await pg.keyboard.press('Enter'); await pg.waitForTimeout(60);
   const cap=await pg.locator('#eq-dirac svg[role=group] + p.eq-cap').textContent().catch(()=>''); if(await pg.locator('#eq-dirac svg [role=button][aria-pressed="true"]').count()!==1||!cap.startsWith(lab))errs.push(`eq ${lang}${w}: Enter on blade ${lab} did not isolate it: "${cap}"`);
   await pg.keyboard.press(' '); await pg.waitForTimeout(60); if(await pg.locator('#eq-dirac svg [role=button][aria-pressed="true"]').count()!==0)errs.push(`eq ${lang}${w}: Space did not release the blade`); }
 const ov=await pg.evaluate(()=>document.documentElement.scrollWidth-window.innerWidth);if(ov>2)errs.push(`eq ${lang}${w}: overflow ${ov}`);
 await pg.close();}
await b.close();console.log(errs.length?errs:'UI SMOKE OK');
process.exit(errs.length?1:0);   // v9: a failure also sets the exit code
