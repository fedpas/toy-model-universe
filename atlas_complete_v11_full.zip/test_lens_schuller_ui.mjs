// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Schuller chapter (step 20, #lenses/schuller) in a real browser, as a visitor reaches it: English and Italian, the three audiences, 1100 and 375 px,
// the dark theme and (for two views) the light one. For every view: no page error, no horizontal page scroll (also with every fold opened), the menu's
// anchors exist, the folds open, each widget container [data-widget] is there exactly for the audiences DECISIONS §3 gives, the honesty bar and the
// matrix show the counts of the data (23 / 14 / 2 / 4 of 43 rows), every statement line carries its tags; the Young Learner sees no formula, no code and
// none of the technical words outside the closed fold "For older readers". At 1100 px: the menu scrolls to its anchor, the script boxes download the
// shipped files byte for byte, the links to the Category and Baez chapters and to step 2 go there, and ?filter=known hides exactly the known-ground lines
// of the chapter and the notice counts them. Widgets are found by [data-widget] only, so the test passes with the stub widgets and with the real ones.
// Run: node test_lens_schuller_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist; ONLY=en/Physicist/1100,extras limits the run while you work: the full run has no filter)
import fs from 'node:fs';
import { PKG, PKG_DIST } from './paths.mjs';
process.chdir(PKG);
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import { COPY } from './schullerCopy.js';
import { MATRIX_ROWS } from './translationMatrixData.js';
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const LV = { 'Young Learner': 0, Physicist: 1, Mathematician: 2 }, VOICE = ['yl', 'p', 'm'];
const WIDGETS = { SW1: [0, 1, 2], SW2: [0, 1, 2], SW3: [0, 1, 2], SW4: [1, 2], SW5: [0, 1, 2], SW6: [0, 1, 2], SW7: [0, 1], SchullerWidgetsScript: [0, 1, 2] };   // DECISIONS §3
const WRAP = { SW1: 'sc-w-chain', SW2: 'sc-w-table', SW3: 'sc-w-fibre', SW4: 'sc-w-bench', SW5: 'sc-w-bands', SW6: 'sc-w-seats', SW7: 'sc-w-magnets', SchullerWidgetsScript: 'sc-w-script' };
const SEC = fs.readFileSync('SchullerSection.jsx', 'utf8'), menuIds = s => (new RegExp(`${s}: \\[([^\\]]+)\\]`).exec(SEC) || [, ''])[1].split(',').map(x => x.trim().replace(/'/g, '')).filter(Boolean);
const MENU = { 0: menuIds('yl'), 1: menuIds('formal'), 2: menuIds('formal') };
const rows = MATRIX_ROWS.filter(r => r.src === 'schuller'), best = { E: 0, S: 0, A: 0, none: 0 }; for (const r of rows) { const g = Object.values(r.cells).map(x => x.grade); best[g.includes('E') ? 'E' : g.includes('S') ? 'S' : g.includes('A') ? 'A' : 'none']++; }
const cnt = g => rows.reduce((a, r) => a + Object.values(r.cells).filter(x => x.grade === g).length, 0);
const HB = `${best.E},${best.S},${best.A},${best.none}`, LM = `${rows.length},${cnt('E')},${cnt('S')},${cnt('A')},${best.none}`;
ok(HB === '23,14,2,4' && rows.length === 43, 'the data give the counts of DECISIONS X8: ' + HB + ' of ' + rows.length);
const ylSrc = fs.readFileSync('test_yl_ui.mjs', 'utf8'), reOf = name => new RegExp(...(() => { const m = new RegExp(`^const ${name} = /(.*)/([a-z]*);`, 'm').exec(ylSrc); return [m[1], m[2]]; })());
const SYMBOLS = reOf('SYMBOLS'), JARGON = reOf('JARGON');
const FILES = ['selfcheck/reports/fibre_check.py', 'selfcheck/reports/bridge_check.py', 'selfcheck/reports/bridge_check_qm.py'];
async function open(w, lang, prof, { theme, filter } = {}) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce', acceptDownloads: true }), pg = await ctx.newPage(), tag = `${lang}/${prof}/${w}${theme ? '/' + theme : ''}${filter ? '/' + filter : ''}`;
  pg.on('pageerror', e => ok(false, `${tag}: page error ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`));
  const q = [theme && 'theme=' + theme, filter && 'filter=' + filter].filter(Boolean).join('&');
  await pg.goto(APP + (q ? '?' + q : '') + '#lenses/schuller'); await pg.waitForTimeout(300);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(300);
  return [ctx, pg, tag];
}
const ONLY = (process.env.ONLY || '').split(',').filter(Boolean), want = t => !ONLY.length || ONLY.includes(t);
if (ONLY.length) console.log('note: ONLY=' + ONLY.join(',') + ': a partial run');
const overflow = pg => pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);

// ---- 1. every language, audience and width (dark theme)
const LEDES = { en: {}, it: {} };   // the first introduction of the chapter differs between the three audiences (test_i18n_audit.mjs, rule 2)
for (const lang of ['en', 'it']) for (const prof of ['Young Learner', 'Physicist', 'Mathematician']) for (const w of [1100, 375]) {
  if (!want(`${lang}/${prof}/${w}`)) continue;
  const [ctx, pg, tag] = await open(w, lang, prof), lv = LV[prof];
  const r = await pg.evaluate(() => { const s = document.querySelector('#ln-schuller'); if (!s) return null;
    return { voice: s.dataset.voice, eyebrow: s.querySelector('.eyebrow')?.textContent || '', title: s.querySelector('h2')?.textContent || '', menu: [...s.querySelectorAll('.ln-menu [data-go]')].map(e => e.dataset.go),
      targets: [...s.querySelectorAll('.ln-menu [data-go]')].map(e => !!document.getElementById(e.dataset.go)), widgets: Object.fromEntries([...s.querySelectorAll('[data-widget]')].map(e => [e.dataset.widget, (e.closest('[id^="sc-w-"]') || {}).id || ''])),
      wcount: s.querySelectorAll('[data-widget]').length, hb: s.querySelector('[data-hb]')?.dataset.hb, lm: s.querySelector('[data-lm-counts]')?.dataset.lmCounts || null,
      lmFolded: !!s.querySelector('[data-lm-counts]')?.closest('details:not([open])'), untagged: [...s.querySelectorAll('.eq-pt')].filter(e => !e.querySelector('.tag')).length, pts: s.querySelectorAll('.eq-pt').length,
      folds: s.querySelectorAll('details').length, closed: s.querySelectorAll('details:not([open])').length, lede: (s.querySelector('.lede')?.textContent || '').trim() }; });
  ok(!!r, `${tag}: the chapter #ln-schuller is there`); if (!r) { await ctx.close(); continue; }
  ok(r.voice === VOICE[lv], `${tag}: the voice of the audience (${r.voice})`);
  LEDES[lang][prof] = r.lede;
  ok(/\b20\b/.test(r.eyebrow) && (lang === 'it' ? /PASSO/.test(r.eyebrow) : /STEP/.test(r.eyebrow)), `${tag}: the eyebrow names step 20: ${r.eyebrow}`);
  ok(r.title.replace(/\s+/g, ' ').trim() === (lv === 0 ? COPY.yl[lang].title : COPY[lang].title), `${tag}: the title in its language and voice: ${r.title.slice(0, 60)}`);
  ok(JSON.stringify(r.menu) === JSON.stringify(MENU[lv].map(x => 'sc-' + x)) && r.targets.every(Boolean), `${tag}: the menu lists the sections of the audience and each anchor exists: ${r.menu.filter((x, i) => !r.targets[i]).join(',')}`);
  for (const [wd, who] of Object.entries(WIDGETS)) { const want = who.includes(lv); ok(want ? r.widgets[wd] === WRAP[wd] : !(wd in r.widgets), `${tag}: widget ${wd} ${want ? 'is there, inside #' + WRAP[wd] : 'is not shown to this audience'} (${r.widgets[wd] ?? 'absent'})`); }
  ok(r.wcount === Object.values(WIDGETS).filter(x => x.includes(lv)).length, `${tag}: each widget once (${r.wcount})`);
  ok(r.hb === HB, `${tag}: the honesty bar counts ${HB} (${r.hb})`);
  ok(r.lm === LM && (lv === 2 ? !r.lmFolded : r.lmFolded), `${tag}: the matrix shows ${LM} and is ${lv === 2 ? 'open' : 'folded'} (${r.lm}, folded ${r.lmFolded})`);
  ok(r.pts > (lv === 0 ? 15 : 80) && r.untagged === 0, `${tag}: every statement line carries its tags (${r.pts} lines, ${r.untagged} without)`);
  ok(await overflow(pg) <= 1, `${tag}: no horizontal page scroll (${await overflow(pg)} px)`);
  // the Young Learner: nothing formal outside the closed fold "For older readers"; the fold is there and closed
  if (lv === 0) { const y = await pg.evaluate(([sym, jar]) => { const S = new RegExp(sym, 'u'), J = new RegExp(jar, 'i'), s = document.querySelector('#ln-schuller'), shut = e => !!e.closest('details:not([open])'), hits = [];
      const w = document.createTreeWalker(s, NodeFilter.SHOW_TEXT); for (let t = w.nextNode(); t; t = w.nextNode()) { const e = t.parentElement; if (!e || shut(e) || !e.getClientRects().length || e.closest('style')) continue; const x = t.nodeValue.replace(/\b[\w.\/-]+\.(py|mjs|js)\b/g, ' '); if (S.test(x) || J.test(x)) hits.push(x.trim().slice(0, 60)); }
      for (const e of s.querySelectorAll('[aria-label],[title]')) { if (shut(e)) continue; for (const a of ['aria-label', 'title']) { const v = e.getAttribute(a); if (v && (S.test(v) || J.test(v))) hits.push(a + ': ' + v.slice(0, 60)); } }
      const codes = [...s.querySelectorAll('code, pre, .katex')].filter(e => !shut(e) && e.getClientRects().length).length;
      const older = [...s.querySelectorAll(':scope > details.eq-fold')].map(d => ({ open: d.open, words: d.textContent.split(/\s+/).length }));
      return { hits, codes, older }; }, [SYMBOLS.source, JARGON.source]);
    ok(y.hits.length === 0 && y.codes === 0, `${tag}: the Young Learner sees no formula, no technical word and no code outside the fold (${y.hits.slice(0, 3).join(' | ')}; ${y.codes} code blocks)`);
    ok(y.older.length === 1 && !y.older[0].open && y.older[0].words > 200, `${tag}: one closed fold "For older readers" holds the formal findings (${JSON.stringify(y.older)})`); }
  // open every fold: they open, and the page still fits
  await pg.evaluate(() => document.querySelectorAll('#ln-schuller details').forEach(d => { d.open = true; })); await pg.waitForTimeout(150);
  ok(await pg.evaluate(() => [...document.querySelectorAll('#ln-schuller details')].every(d => d.open && d.querySelector(':scope > summary') && d.textContent.length > 40)), `${tag}: the ${r.folds} folds open (${r.closed} were closed)`);
  ok(await overflow(pg) <= 1, `${tag}: no horizontal page scroll with every fold open (${await overflow(pg)} px)`);
  if (lang === 'it') ok(await pg.evaluate(() => !!document.querySelector('#ln-schuller [data-lm-counts]')), `${tag}: the matrix is there in Italian too`);
  await ctx.close();
}

if (!ONLY.length) for (const lang of ['en', 'it']) ok(new Set(Object.values(LEDES[lang])).size === 3 && Object.values(LEDES[lang]).every(x => x.length > 40), `${lang}: the introduction of the chapter differs for the three audiences`);
// ---- 2. the menu scrolls, the script boxes download the shipped files, the links go to the other chapters and to step 2 (English, Physicist, 1100 px)
if (want('extras')) { const [ctx, pg, tag] = await open(1100, 'en', 'Physicist');
  for (const id of ['sc-bands', 'sc-honest', 'sc-fibre']) { await pg.locator(`#ln-schuller .ln-menu [data-go="${id}"]`).click(); await pg.waitForTimeout(500);
    const top = await pg.evaluate(id => document.getElementById(id).getBoundingClientRect().top, id); ok(top >= -2 && top < 240, `${tag}: the menu button scrolls ${id} to the top of the window (top ${Math.round(top)} px)`); }
  for (const f of FILES) { const [dl] = await Promise.all([pg.waitForEvent('download', { timeout: 10000 }), pg.locator(`#ln-schuller [data-download="${f}"]`).first().click()]);
    ok(dl.suggestedFilename() === f.split('/').pop() && fs.readFileSync(await dl.path(), 'utf8') === fs.readFileSync(f, 'utf8'), `${tag}: the script box downloads ${f} byte for byte (${dl.suggestedFilename()})`); }
  ok(await pg.locator('#sc-w-script [data-widget="SchullerWidgetsScript"]').count() === 1, `${tag}: the widgets' script box sits in the scripts section`);
  ok(await pg.locator('#ln-schuller [data-report-link] a').count() === 1 && await pg.locator('#ln-schuller [data-report-link] a').getAttribute('href') === 'reports/html/schuller_bridge_report.html', `${tag}: the scripts section ends with one link to the full report`);
  await pg.evaluate(() => document.querySelectorAll('#sc-table details').forEach(d => { d.open = true; })); await pg.locator('#ln-schuller [data-link="category"]').click(); await pg.waitForTimeout(500);
  ok(await pg.evaluate(() => location.hash) === '#lenses/category' && await pg.locator('#ln-category').count() === 1 && await pg.locator('#ln-schuller').count() === 0, `${tag}: the link to the complement opens the Category chapter (${await pg.evaluate(() => location.hash)})`);
  await pg.evaluate(() => { location.hash = '#lenses/schuller'; }); await pg.waitForTimeout(400);
  await pg.locator('#ln-schuller [data-link="baez"]').click(); await pg.waitForTimeout(500);
  ok(await pg.evaluate(() => location.hash) === '#lenses/baez' && await pg.locator('#ln-baez').count() === 1, `${tag}: the link to the E8 ladder opens the Baez chapter`);
  await pg.evaluate(() => { location.hash = '#lenses/schuller'; }); await pg.waitForTimeout(400);
  await pg.locator('#ln-schuller [data-link="octahedron"]').click(); await pg.waitForTimeout(500);
  ok(/^#equations\/comm/.test(await pg.evaluate(() => location.hash)) && await pg.locator('#eq-comm').count() >= 1, `${tag}: the octahedron link opens step 2 (${await pg.evaluate(() => location.hash)})`);
  await ctx.close(); }
// the Young Learner downloads from the fold for older readers (Italian)
if (want('extras')) { const [ctx, pg, tag] = await open(1100, 'it', 'Young Learner');
  await pg.evaluate(() => document.querySelectorAll('#ln-schuller > details').forEach(d => { d.open = true; })); await pg.waitForTimeout(150);
  const f = FILES[2], [dl] = await Promise.all([pg.waitForEvent('download', { timeout: 10000 }), pg.locator(`#ln-schuller [data-download="${f}"]`).first().click()]);
  ok(fs.readFileSync(await dl.path(), 'utf8') === fs.readFileSync(f, 'utf8'), `${tag}: the script in the fold for older readers downloads the shipped file`);
  await ctx.close(); }

// ---- 3. the light theme (two views)
if (want('extras')) for (const [w, prof] of [[375, 'Young Learner'], [1100, 'Mathematician']]) { const [ctx, pg, tag] = await open(w, 'en', prof, { theme: 'light' });
  ok(await pg.evaluate(() => document.documentElement.dataset.theme) === 'light' && await pg.locator('#ln-schuller').count() === 1, `${tag}: the chapter in the light theme`);
  ok(await overflow(pg) <= 1, `${tag}: no horizontal page scroll in the light theme`);
  await ctx.close(); }

// ---- 4. the reader filter: ?filter=known hides exactly the known-ground lines of the chapter, and the notice counts the lines it hides (EN and IT)
if (want('extras')) for (const lang of ['en', 'it']) { const [ctx, pg, tag] = await open(1100, lang, 'Mathematician', { filter: 'known' }); await pg.waitForTimeout(400);
  const f = await pg.evaluate(() => { const kg = k => { const s = new Set(k.split(' ')); return s.has('checked') && s.has('standard') && !s.has('ours') && !s.has('open'); };
    const pts = [...document.querySelectorAll('#ln-schuller .eq-pt[data-kinds]')], hid = e => getComputedStyle(e).display === 'none';
    const known = pts.filter(e => kg(e.dataset.kinds)), other = pts.filter(e => !kg(e.dataset.kinds));
    const nt = document.querySelector('.rf-notice'); return { known: known.length, knownHidden: known.filter(hid).length, other: other.length, otherHidden: other.filter(hid).length, notice: nt ? Number(nt.dataset.rfHidden) : -1, text: nt ? nt.textContent : '' }; });
  ok(f.known > 20 && f.knownHidden === f.known && f.otherHidden === 0, `${tag}: the filter hides the ${f.known} known-ground lines of the chapter and none of the other ${f.other} (${f.knownHidden} hidden, ${f.otherHidden} wrongly)`);
  ok(f.notice >= f.known && (lang === 'it' ? /terreno noto/.test(f.text) : /known ground/.test(f.text)), `${tag}: the notice counts them (${f.notice} on the page): ${f.text.slice(0, 80)}`);
  await ctx.close(); }
await b.close();
console.log(`${n} checks`); console.log(bad ? `${bad} FAILURES` : 'ALL SCHULLER CHAPTER UI TESTS PASS'); process.exit(bad ? 1 : 0);
