// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The words printed beside the two badges of a cell card (CellStatus.jsx). They say what each badge covers (the algebra type; the name), not how sure we are: the status is the badge.
// The tier name of the audit ("Structural Realignments") and the status id "realigned" are data identifiers; the card says "relabelled".
export const CELL_STATUS = {
  en: {
    verified: 'the algebra type of this cell',
    realigned: 'the algebra type of this cell; the labels of the cell are a choice, shown relabelled',
    name: 'the name is a reading we propose',
    speculative: 'speculative reading: what the name points to is not established',
  },
};
CELL_STATUS.it = CELL_STATUS.en;   // the Italian slot holds the English words
