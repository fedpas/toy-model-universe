// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The theorem panels (proofs.js) and the files the pages name.  Run: node test_proofs.mjs
// 1. every algebra label in the panels (Cl(p,q) ≅ type, its cell, the square of the volume element), in prose and formulas, EN and IT, against a classification computed here from the
//    bit rule alone (trace-form signature, centre, ω²), itself compared with the type table of genesis_audit_v3.js for every Cl(p,q) with p + q ≤ 8;
// 2. no proof step infers an isomorphism from a dimension alone (audit G11), the Proposition XX sentence says "same type class and same dimension" and "standard classification";
// 3. the type table and period 8 are called standard, not derived (G05); the status labels promise nothing a panel does not do (T3-8);
// 4. every script or file named by the app's sources or the chat persona exists in the package (T3-1: the Furey footer path; T3-8: the checker named in proofs.js), and the Findings
//    footer names the asserting run_all.py, never a print-only script (G07);
// 5. the two lines of every atlas card (atlasLines.js, v10.2): a theorem line (standard / checked) and a reading line (ours / open), or one line; the
//    tags are the four, in order; a line tagged ours never says derived; every algebra label, cell, chain and volume-element square in them is checked
//    against the same bit-rule classification as the panels, EN and IT naming the same algebras.
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs'; import { reachable } from './import_graph.mjs';
import { PROOFS, STATUS_LABEL, STATUS_FLAGS, PROOF_UI } from './proofs.js';
import { ATLAS_LINES, LINE_FLAGS } from './atlasLines.js';
import { cliffordCell } from './genesis_audit_v3.js';
import { FINDINGS_UI } from './findingsData.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const LANGS = ['en', 'it'];

// ---- 1. a classification from the bit rule: e_a e_b = s(a,b) e_(a xor b); generators 0..p-1 square to +1, p..p+q-1 to -1
const pop = x => { let c = 0; while (x) { c += x & 1; x >>>= 1; } return c; };
const sgn = (a, b, neg) => { let c = 0, x = a >>> 1; while (x) { c += pop(x & b); x >>>= 1; } c += pop(a & b & neg); return c % 2 ? -1 : 1; };
const SUBS = '₀₁₂₃₄₅₆₇₈₉', sub = n => String(n).split('').map(d => SUBS[+d]).join('');
const FIELD = { R: 'ℝ', C: 'ℂ', H: 'ℍ' };
function bitClass(p, q) {
  const n = p + q, N = 1 << n, neg = ((1 << q) - 1) << p, full = N - 1;
  let E = 0; for (let A = 0; A < N; A++) E += sgn(A, A, neg);                  // signature of the trace form: B(e_A, e_A) = 2^n e_A², the blades are orthogonal
  let centre = 0; for (let A = 0; A < N; A++) { let c = true; for (let i = 0; i < n && c; i++) c = sgn(A, 1 << i, neg) === sgn(1 << i, A, neg); if (c) centre++; }
  const w2 = sgn(full, full, neg);
  // M_k(R): E = k, M_k(C): E = 0, M_k(H): E = -2k; doubled with a 2-dimensional centre and ω² = +1
  let F, k, copies = 1;
  if (centre === 1) { if (E > 0) { F = 'R'; k = E; } else { F = 'H'; k = -E / 2; } }
  else if (w2 === -1) { F = 'C'; k = Math.sqrt(N / 2); if (E !== 0) k = NaN; }
  else { copies = 2; if (E > 0) { F = 'R'; k = E / 2; } else { F = 'H'; k = -E / 4; } }
  const dimF = { R: 1, C: 2, H: 4 }[F];
  if (!Number.isInteger(k) || copies * k * k * dimF !== N) throw new Error(`bit rule: no consistent type for Cl(${p},${q}) (E=${E}, centre=${centre}, w2=${w2})`);
  const one = k === 1 ? FIELD[F] : `M${sub(k)}(${FIELD[F]})`;
  return { algebra: copies === 2 ? `${one}⊕${one}` : one, w2, centre };
}
let agree = 0;
for (let n = 0; n <= 8; n++) for (let p = 0; p <= n; p++) { const q = n - p, a = bitClass(p, q), b = cliffordCell(p, q); ok(a.algebra === b.algebra && a.w2 === b.omega2 && a.centre === b.centreDim, `Cl(${p},${q}): bit rule ${a.algebra} ω²=${a.w2} centre ${a.centre}, type table ${b.algebra} ω²=${b.omega2} centre ${b.centreDim}`); agree++; }
ok(agree === 45, 'the bit-rule classification was compared with the type table on the 45 cells p + q ≤ 8');

// the labels of the panels
const TYPE = '(M[₀-₉]+\\([ℝℂℍ]\\)(?:⊕M[₀-₉]+\\([ℝℂℍ]\\))?|[ℝℂℍ](?:⊕[ℝℂℍ])?)(?![⊗\\[\\w(])';
const LABEL = new RegExp('(?<!⊗\\s*)(?<!\\w)Cl\\((\\d+),(\\d+)\\)\\s*(?:≅|=|is |è )\\s*' + TYPE + '(?:\\s*\\(?(?:cell |cella |at |lives at |in |sta in )\\[(\\d+),([+−-]?\\d+)\\])?', 'g');
const tex = s => s.replace(/\\mathrm\{Cl\}/g, 'Cl').replace(/\\cong/g, '≅').replace(/\\oplus/g, '⊕').replace(/\\otimes/g, '⊗').replace(/\\mathbb\{([RCH])\}/g, (m, f) => FIELD[f])
  .replace(/M_\{?(\d+)\}?/g, (m, d) => 'M' + sub(d)).replace(/\\text\{(?:at|in) \}/g, 'at ').replace(/\\[;,!]|\\quad|\\qquad|\\ /g, ' ').replace(/\s+/g, ' ').replace(/ ?≅ ?/g, '≅').replace(/ ?⊕ ?/g, '⊕');
const labels = s => [...s.matchAll(LABEL)].map(m => ({ p: +m[1], q: +m[2], alg: m[3], R: m[4], C: m[5], raw: m[0] }));
const W2 = /(?:volume element|elemento di volume)[^.;]*?(?:squares to|ha quadrato) ([+−-]1)/g;
let nLabels = 0, nCells = 0, nW2 = 0;
for (const [id, P] of Object.entries(PROOFS)) {
  const perLang = {};
  for (const L of LANGS) {
    const t = P[L]; ok(t && ['title', 'statement', 'eq', 'proof', 'lemmaTitle', 'lemmaEq'].every(k => typeof t[k] === 'string' && (t[k] || k === 'caveat')), `${id}.${L}: every field is there`);
    const prose = [t.statement, t.proof, t.caveat || ''].join(' '), found = [...labels(prose), ...labels(tex(t.eq)), ...labels(tex(t.lemmaEq))];
    for (const x of found) {
      const c = bitClass(x.p, x.q); nLabels++;
      ok(x.alg === c.algebra, `${id}.${L}: "${x.raw}" but the bit rule gives Cl(${x.p},${x.q}) ≅ ${c.algebra}`);
      if (x.R !== undefined) { nCells++; ok(+x.R === x.p + x.q && +x.C.replace('−', '-') === x.p - x.q, `${id}.${L}: "${x.raw}" names the wrong cell (Cl(${x.p},${x.q}) sits at [${x.p + x.q},${x.p - x.q}])`); }
    }
    const first = labels(t.statement)[0];
    for (const m of t.statement.matchAll(W2)) { nW2++; ok(first && +m[1].replace('−', '-') === bitClass(first.p, first.q).w2, `${id}.${L}: the volume element of Cl(${first?.p},${first?.q}) squares to ${first && bitClass(first.p, first.q).w2}, the statement says ${m[1]}`); }
    for (const m of tex(t.eq + ' ' + t.lemmaEq).matchAll(/\bI(?:_\d)?\^2=([+-]1)\b/g)) { nW2++; ok(first && +m[1] === bitClass(first.p, first.q).w2, `${id}.${L}: formula ${m[0]} against Cl(${first?.p},${first?.q})`); }
    perLang[L] = found.map(x => `Cl(${x.p},${x.q})=${x.alg}`).sort().join(' ');
  }
  ok(perLang.en === perLang.it, `${id}: English and Italian name the same algebras (${perLang.en} | ${perLang.it})`);
}
ok(nLabels >= 60 && nCells >= 20 && nW2 >= 20, `the parser found the labels (${nLabels} algebras, ${nCells} cells, ${nW2} volume-element squares)`);
// chains of isomorphisms (re-check V3-1): every term of "A ≅ B ⊗ C ≅ D = E", where a term is a ⊗-product of Cl(p,q) and types, is evaluated from the bit rule and all terms
// of a chain must be the same algebra (so the end of a tensor chain and a wrong tensor factor are seen); fields multiply as R⊗X = X, C⊗C = C⊕C, C⊗H = M2(C), H⊗H = M4(R)
const FAC = 'Cl\\(\\d+,\\d+\\)|M[₀-₉]+\\([ℝℂℍ]\\)(?:⊕M[₀-₉]+\\([ℝℂℍ]\\))?|[ℝℂℍ](?:⊕[ℝℂℍ])?', TERM = `(?:${FAC})(?:⊗(?:${FAC}))*`;
const CHAIN = new RegExp(`(?<![\\w⊗(])${TERM}(?:\\s?(?:≅|=)\\s?${TERM})+(?![\\w(⊗\\[^])`, 'g');
const unsub = s => +s.split('').map(c => SUBS.indexOf(c)).join(''), FLD = { 'ℝ': 'R', 'ℂ': 'C', 'ℍ': 'H' };
const typeOf = f => { if (/^Cl\(/.test(f)) { const [, p, q] = /Cl\((\d+),(\d+)\)/.exec(f); return typeOf(bitClass(+p, +q).algebra); }
  const parts = f.split('⊕'), m = /^M([₀-₉]+)\(([ℝℂℍ])\)$/.exec(parts[0]); return m ? { c: parts.length, k: unsub(m[1]), F: FLD[m[2]] } : { c: parts.length, k: 1, F: FLD[parts[0]] }; };
const FMUL = { RR: [1, 1, 'R'], RC: [1, 1, 'C'], RH: [1, 1, 'H'], CC: [2, 1, 'C'], CH: [1, 2, 'C'], HH: [1, 4, 'R'] };
const tensor = (a, b) => { const [c, k, F] = FMUL[[a.F, b.F].sort((x, y) => 'RCH'.indexOf(x) - 'RCH'.indexOf(y)).join('')]; return { c: a.c * b.c * c, k: a.k * b.k * k, F }; };
const termKey = t => { const v = t.split('⊗').map(typeOf).reduce(tensor); return `${v.c}×M${v.k}(${v.F})`; };
let nChains = 0;
for (const [id, P] of Object.entries(PROOFS)) for (const L of LANGS) { const t = P[L];
  for (const src of [t.statement, t.proof, t.caveat || '', tex(t.eq), tex(t.lemmaEq)]) for (const m of src.replace(/\s?([≅=⊗])\s?/g, '$1').matchAll(CHAIN)) {
    const terms = m[0].split(/≅|=/), keys = terms.map(termKey); if (!terms.some(x => /Cl\(/.test(x))) continue; nChains++;
    ok(keys.every(k => k === keys[0]), `${id}.${L}: the chain "${m[0]}" mixes different algebras (${keys.join(' | ')})`); } }
ok(nChains >= 60, `chains of isomorphisms read (${nChains})`);
// the period-8 shift as stated (Theorem XXIII, Proposition XX): Cl(n+8) = Cl(n) ⊗ M16(R), with M16(R) the bit rule's Cl(8,0)
const SHIFT = /Cl\(n\+8\)\s?(?:=|≅)\s?Cl\(n\)\s?⊗\s?(M[₀-₉]+\([ℝℂℍ]\))/g; let nShift = 0;
for (const [id, P] of Object.entries(PROOFS)) for (const L of LANGS) for (const src of Object.values(P[L]).map(x => tex(String(x)))) for (const m of src.matchAll(SHIFT)) { nShift++; ok(m[1] === bitClass(8, 0).algebra && m[1] === bitClass(0, 8).algebra, `${id}.${L}: "${m[0]}" but Cl(8,0) ≅ Cl(0,8) ≅ ${bitClass(8, 0).algebra}`); }
for (const L of LANGS) ok(PROOFS.Sector_Cosmic_Horizon[L].statement.includes('Cl(n+8)=Cl(n)⊗M₁₆(ℝ)') && tex(PROOFS.Sector_Cosmic_Horizon[L].eq).replace(/\s?⊗\s?/g, '⊗').includes('Cl(n+8)≅Cl(n)⊗M₁₆(ℝ)'), `Theorem XXIII (${L}): the statement and the formula say Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ)`);
ok(nShift >= 6, `the period-8 shift is stated and checked (${nShift} times)`);
// the volume-element arithmetic in the sketches: "I² = … = ±1" or "squares to … = ±1" ends with the square the bit rule gives for the panel's cell
let nArith = 0;
for (const [id, P] of Object.entries(PROOFS)) for (const L of LANGS) { const first = labels(P[L].statement)[0]; if (!first) continue;
  for (const m of P[L].proof.matchAll(/(?:\bI[₀-₉]?²\s?=|squares to|ha quadrato)\s?\(?[^.;]*?=\s?([+−-]1)\b(?!\^|[·)])/g)) { nArith++; ok(+m[1].replace('−', '-') === bitClass(first.p, first.q).w2, `${id}.${L}: "${m[0]}" but the volume element of Cl(${first.p},${first.q}) squares to ${bitClass(first.p, first.q).w2}`); } }
ok(nArith >= 20, `volume-element arithmetic read in the sketches (${nArith})`);

// ---- 2. an isomorphism is never inferred from a dimension alone (G11)
const CONCLUDES = /isomorph|isomorf|≅|hence|quindi|, each|ciascun|=\s?dim/;
const DIM = /(?:dimension|dimensione)s? ?\d|(?:of|same|real|di|stessa) dimension|dimensione reale|dim_ℝ|\bdim\b|-dimensional|dimensions agree|dimensioni coincidono/;   // the size of an algebra, not 'odd dimension'
const REASON = /type class|classe di tipo|\bclass\b|\bclasse\b|Theorems? [IVX]+|Teorem[ai] [IVX]+|copy of|copia di|⊗|Pauli|represent|rappresent|over ℂ|su ℂ|linearly independent|linearmente indipendent/;
for (const [id, P] of Object.entries(PROOFS)) for (const L of LANGS) for (const s of P[L].proof.split(/(?<=\.)\s+(?=[A-ZÈ])/)) if (DIM.test(s) && CONCLUDES.test(s)) ok(REASON.test(s), `${id}.${L}: a dimension-based conclusion names no type class, explicit map or earlier theorem: "${s}"`);
const XX = PROOFS.Sector_Electroweak_Unified;
ok(/same type class \(s≡0 mod 8\) and the same dimension 256, hence are isomorphic \(the standard classification/.test(XX.en.proof), 'Proposition XX (EN): "same type class (s≡0 mod 8) and the same dimension 256, hence are isomorphic (the standard classification"');
ok(/stessa classe di tipo \(s≡0 mod 8\) e la stessa dimensione 256, quindi sono isomorfe \(la classificazione standard/.test(XX.it.proof), 'Proposition XX (IT): "stessa classe di tipo ... stessa dimensione 256, quindi sono isomorfe (la classificazione standard"');
const ALL = Object.entries(PROOFS).flatMap(([id, P]) => LANGS.map(L => [id + '.' + L, Object.values(P[L]).join(' ')]));
for (const [w, t] of ALL) ok(!/central simple (algebra )?of (real )?dimension|centrale semplice di dimensione/.test(t), `${w}: no "central simple of dimension N, hence isomorphic"`);

// ---- 3. standard, not derived (G05, T3-8)
const OQ = PROOFS.Sector_Open_Questions;
ok(/The algebra types are the standard mod-8 classification and are also recomputed from the squares of the labels for every cell shown/.test(OQ.en.statement), 'Formal Critique (EN): the algebra types are the standard mod-8 classification, also recomputed from the squares of the labels');
ok(/I tipi di algebra sono la classificazione standard mod 8 e sono anche ricalcolati dai quadrati delle etichette per ogni cella mostrata/.test(OQ.it.statement), 'Formal Critique (IT): i tipi di algebra sono la classificazione standard mod 8, anche ricalcolati dai quadrati delle etichette');
for (const [w, t] of ALL) ok(!/derives? the (algebra )?types|derive[sd]? the period|deriva(no)? i tipi|deriva(no)? il periodo|period(o)? 8 (is|è) derivat/i.test(t), `${w}: nothing says the lattice derives the types or the period 8`);
// the status of every panel says what its proof is: a proof given in the panel that does not read the type table is derived (XVIII the strain identity, XXI the scalar part); the isomorphism read from the standard table with elementary counts is standard (XX, XXII); a baryon number and the open list stay open
{ const want = { Sector_Gravity_Strain: 'derived', Sector_Vacuum_Mass_Generation: 'derived', Sector_Electroweak_Unified: 'standard', Sector_GUT_Junction: 'standard', Sector_Baryon_Conservation: 'open', Sector_Open_Questions: 'open' };
  for (const [id, st] of Object.entries(want)) ok(PROOFS[id].status === st, `${id} (${PROOFS[id].en.title.split(':')[0]}) is ${st}, not ${PROOFS[id].status}`);
  for (const id of ['Sector_Electroweak_Unified', 'Sector_GUT_Junction']) for (const L of LANGS) ok(/class|classe/.test(PROOFS[id][L].proof), `${id}.${L}: a panel labelled standard says that it reads the type class`); }
const H = PROOFS.Sector_Cosmic_Horizon;
ok(H.status === 'standard', `Theorem XXIII (period 8) is labelled standard, not "${H.status}"`);
ok(/standard 8-fold type table, not derived/.test(H.en.proof) && /tabella standard dei tipi a 8 passi, non è derivato/.test(H.it.proof), 'Theorem XXIII: the period is read from the standard table, not derived (EN, IT)');
ok(/multiplied by 16/.test(H.en.proof) && /moltiplicato per 16/.test(H.it.proof), 'Theorem XXIII: the matrix size is multiplied by 16 (Cl(n+8) = Cl(n) ⊗ M16(R)), not "grows by 16"');
for (const L of LANGS) {
  const used = new Set(Object.values(PROOFS).map(P => P.status));
  for (const s of used) ok(typeof STATUS_LABEL[L][s] === 'string' && STATUS_LABEL[L][s], `STATUS_LABEL.${L} has a label for every status used (${s})`);
  ok(!/machine|macchina/i.test(Object.values(STATUS_LABEL[L]).join(' ')), `STATUS_LABEL.${L}: no label promises a machine check (no checker of the sketches ships)`);
  ok(/not derived|non derivato/.test(STATUS_LABEL[L].standard) && JSON.stringify(STATUS_FLAGS.standard) === '["standard"]', `STATUS_LABEL.${L}.standard says not derived, and the chip carries the standard badge`);
  ok(Object.values(STATUS_LABEL[L]).every(x => !/^(derived|derivato|standard|open|aperto|ours|nostro|checked|verificato)\b/i.test(x)), `STATUS_LABEL.${L}: no chip text starts with a status word (the badge carries it)`);
  ok(JSON.stringify(Object.keys(STATUS_FLAGS)) === JSON.stringify(Object.keys(STATUS_LABEL[L])) && JSON.stringify(STATUS_FLAGS.open) === '["open"]' && JSON.stringify(STATUS_FLAGS.interpretive) === '["ours"]' && STATUS_FLAGS.derived.length === 0, `STATUS_FLAGS: one entry for every label of ${L}; open and the interpretive reading carry their badge, a derived panel none`);
  ok(/standard/.test(STATUS_LABEL[L].interpretive) && !/^Algebra derive|^Algebra derivata/.test(STATUS_LABEL[L].interpretive), `STATUS_LABEL.${L}.interpretive does not call the algebra derived: types read from the table are standard`);
  ok(PROOF_UI[L] && PROOF_UI[L].sketch, `PROOF_UI.${L}`);
}
// a derived panel is proved by its sketch: none of them may rest on the type table
for (const [id, P] of Object.entries(PROOFS)) if (P.status === 'derived') for (const L of LANGS) ok(!/\bclass\b|\bclasse\b|type table|tabella dei tipi|classification|classificazione/.test(P[L].proof), `${id}.${L} is labelled derived but its sketch reads the type table: "${P[L].proof}"`);
// the badge of every status has a colour in App.jsx
const app = fs.readFileSync(path.join(PKG, 'App.jsx'), 'utf8'), badge = /badge = \{([^}]*)\}\[entry\.status\]/.exec(app);
ok(badge && [...new Set(Object.values(PROOFS).map(P => P.status))].every(s => new RegExp('\\b' + s + ":\\s*'#[0-9a-f]{6}'").test(badge[1])), 'App.jsx gives every status of proofs.js a badge colour: ' + (badge && badge[1]));

// ---- 5. the two lines of every atlas card (atlasLines.js): shape, tags, wording rule, and the same bit-rule check as the panels
{
  const ids = Object.keys(PROOFS), lineIds = Object.keys(ATLAS_LINES);
  ok(lineIds.length === 25 && ids.length === lineIds.length && ids.every(id => ATLAS_LINES[id]), `every theorem panel has its card lines and no more (${lineIds.length} cards)`);
  const ALLOW = { theorem: ['standard', 'checked'], reading: ['ours', 'open'], line: LINE_FLAGS };
  let nl = 0, nLab = 0, nCh = 0, nSq = 0;
  for (const [id, card] of Object.entries(ATLAS_LINES)) {
    const kinds = card.lines.map(x => x.kind).join(',');
    ok(kinds === 'theorem,reading' || kinds === 'line', `${id}: a theorem line then a reading line, or one line (${kinds})`);
    const perLang = {};
    for (const x of card.lines) {
      nl++;
      ok(Array.isArray(x.flags) && x.flags.length >= 1 && x.flags.every(f => ALLOW[x.kind].includes(f)) && x.flags.join() === LINE_FLAGS.filter(f => x.flags.includes(f)).join(), `${id} ${x.kind}: tags of its kind, from the four, in order (${x.flags})`);
      for (const L of LANGS) {
        const t = x[L]; ok(typeof t === 'string' && t.length > 20, `${id} ${x.kind}.${L}: the text is there`);
        if (x.flags.includes('ours')) ok(!/deriv/i.test(t), `${id} ${x.kind}.${L}: a line tagged ours never says derived: "${t}"`);
        for (const y of labels(t)) { const c = bitClass(y.p, y.q); nLab++; ok(y.alg === c.algebra, `${id} ${x.kind}.${L}: "${y.raw}" but the bit rule gives Cl(${y.p},${y.q}) ≅ ${c.algebra}`);
          if (y.R !== undefined) ok(+y.R === y.p + y.q && +y.C.replace('−', '-') === y.p - y.q, `${id} ${x.kind}.${L}: "${y.raw}" names the wrong cell`); }
        const first = labels(card.lines[0][L])[0];
        for (const m of t.matchAll(W2)) { nSq++; ok(first && +m[1].replace('−', '-') === bitClass(first.p, first.q).w2, `${id} ${x.kind}.${L}: the volume element of Cl(${first?.p},${first?.q}) squares to ${first && bitClass(first.p, first.q).w2}, the line says ${m[1]}`); }
        for (const m of t.replace(/\s?([≅=⊗])\s?/g, '$1').matchAll(CHAIN)) { const terms = m[0].split(/≅|=/), keys = terms.map(termKey); if (!terms.some(z => /Cl\(/.test(z))) continue; nCh++;
          ok(keys.every(k => k === keys[0]), `${id} ${x.kind}.${L}: the chain "${m[0]}" mixes different algebras (${keys.join(' | ')})`); }
        (perLang[L] ??= []).push(...labels(t).map(y => `Cl(${y.p},${y.q})=${y.alg}`));
      }
    }
    ok(perLang.en.sort().join(' ') === perLang.it.sort().join(' '), `${id}: the English and Italian lines name the same algebras`);
  }
  ok(nl >= 40 && nLab >= 30 && nCh >= 25 && nSq >= 8, `the card lines were read (${nl} lines, ${nLab} labels, ${nCh} chains, ${nSq} volume-element squares)`);
}

// ---- 4. files named by the pages exist (T3-1, T3-8) and the Findings footer names the asserting script (G07)
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => ['node_modules', 'dist', 'dist_real', '.git', '__pycache__', 'test_logs'].includes(e.name) ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const files = walk(PKG).map(f => path.relative(PKG, f).split(path.sep).join('/')), base = new Set(files.map(f => f.split('/').pop()));
const HOST = ['SimplexCanvas.jsx', 'GenesisCanvas.jsx', 'canvasFacts.js'];
const sources = new Set([...reachable('App.jsx').files, ...reachable('api/chat.js').files, ...reachable('api/chat-openai.js').files, ...reachable('api/contact.js').files].map(f => f.split(path.sep).join('/')));
const NAMED = /(?<![\w.}$/-])((?:[\w-]+\/)*[A-Za-z][\w-]*\.(?:py|mjs|cjs|sh))\b/g;
let named = 0; const missing = [];
for (const f of sources) {
  if (HOST.includes(f) || /SelfcheckSource\.js$/.test(f) || !/\.(js|jsx|mjs)$/.test(f)) continue;   // the downloadable script sources are the scripts themselves
  const src = fs.readFileSync(path.join(PKG, f), 'utf8');
  for (const m of src.matchAll(NAMED)) { named++; const n = m[1]; if (n.includes('/') ? !files.includes(n) && !files.includes('selfcheck/' + n) : !base.has(n)) missing.push(f + ': ' + n); }
}
ok(named >= 40, `the scan found the named scripts (${named})`);
ok(missing.length === 0, 'every script named by the app, its routes or the persona is in the package: ' + missing.join('; '));
for (const L of LANGS) {
  const r = FINDINGS_UI[L].repro;
  ok(/\brun_all\.py\b/.test(r) && !/furey\/run_all/.test(r), `Findings footer (${L}) names run_all.py at its real place: ${r}`);
  ok(!/peirce_test|witt_test|z2_test/.test(r), `Findings footer (${L}) names no print-only script as the checker`);
}
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL PROOFS TESTS PASS'); process.exit(bad ? 1 : 0);
