// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import * as M from './matrixData.js';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import {cliffordCell} from './genesis_audit_v3.js';
import {STORY,PAGES} from './storyCopy.js';
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}};
const P=['Young Learner','Physicist','Mathematician'];
// every Genesis node exists in every language, profile and metric
for(const lang of ['en','it'])for(const p of P)for(const mm of ['Spatial','Temporal'])for(let s=0;s<9;s++){const r=M.getGenesisDisplayData(s,lang,p,mm);ok(r&&r.title&&r.desc,`genesis ${s} ${lang} ${p} ${mm}`);}
// the algebra facts quoted in the Genesis text, against the independent Clifford engine
const norm=t=>t.replace(/[²2]$/,'');
const cell=(p,q,kind,N)=>{const c=cliffordCell(p,q);ok(c.N===N&&norm(c.kind)===norm(kind),`Cl(${p},${q}) ${c.kind}${c.N}`)};
cell(1,1,'R',2);cell(2,2,'R',4);cell(3,2,'R2',4);cell(2,3,'C',4);cell(3,3,'R',8);cell(4,3,'R2',8);cell(4,4,'R',16);cell(0,8,'R',16);
ok(cliffordCell(0,0).N===1,'Cl(0,0)=R');
// pseudoscalar facts quoted: Cl(3,2) (n=5,q=2) -> I^2=+1 central, splits; its mirror Cl(2,3) (q=3) -> -1; n=7,q=3 -> +1 central; n=8 -> +1
const I2=(n,q)=>((n*(n-1)/2+q)%2?-1:1);ok(I2(5,2)===1&&I2(5,3)===-1&&I2(7,3)===1&&I2(8,4)===1,'pseudoscalar squares quoted');
// no unsupported physical claims survive in the final text (both languages)
const banned=[/Sterile Neutrino Isomorphism/i,/ultimate origin key/i,/reflects escaping/i,/automatic involutionary/i,/forcing an automatic/i,/tree-level/i,/Hubble boundary/i,/fractional topological weight/i,/weight of 1\/3/i,/complete gauge group infrastructure/i,/required for color confinement/i,/Weak Lock/i,/blueprint for antimatter/i,/Big Reset/i,/world just resets/i,/establishes the Higgs VEV/i,/85 discrete/i];
const ids=M.MENU_SECTOR_LIST.map(x=>x.id);
for(const lang of ['en','it'])for(const p of P)for(const mm of ['Spatial','Temporal']){
 for(const id of ids){const r=M.getCompleteDualMetricDisplayData(id,lang,p,mm);const t=[r.title,r.subtitle,r.desc].join(' ');for(const b of banned)ok(!b.test(t),`${id} ${lang} ${p} ${mm} matches ${b}`)}
 for(let s=0;s<9;s++){const r=M.getGenesisDisplayData(s,lang,p,mm);const t=[r.title,r.desc].join(' ');for(const b of banned)ok(!b.test(t),`genesis ${s} ${lang} ${p} ${mm} matches ${b}`)}}
// stage 5 names the cell that two Witt pairs plus a signed generator give (Cl(3,2) and its mirror Cl(2,3)), as stages 3 and 7 do; never Cl(4,1)
for(const lang of ['en','it'])for(const p of ['Physicist','Mathematician']){const r=M.getGenesisDisplayData(5,lang,p,'Spatial'),t=r.title+' '+r.desc;ok(/Cl\(3,2\)/.test(t)&&/Cl\(2,3\)/.test(t)&&!/Cl\(4,1\)/.test(t),`stage 5 names Cl(3,2) and Cl(2,3), not Cl(4,1): ${lang} ${p}`)}
// stage 2 (Mathematician): the plane comes from the pairing {n,ñ}=1, not from anticommuting nulls alone
for(const lang of ['en','it']){const r=M.getGenesisDisplayData(2,lang,'Mathematician','Spatial');ok(/\{n, ñ\} = 1/.test(r.desc)&&!/anticommut\w+ null generators polarize|anticommutanti si polarizzano/.test(r.desc),`stage 2 Ma says paired: ${lang}`)}
// period 8 is never presented as shown closure: no "used up", no causal "so", no old grade captions; the addresses are the audited ones
const AUD=await import('./genesis_audit_v3.js');
for(const lang of ['en','it'])for(const p of P)for(const mm of ['Spatial','Temporal']){const r8=M.getGenesisDisplayData(8,lang,p,mm);ok(!/used up|budget of eight is|budget di otto è finito|esaurit|Saturated|Closure/i.test([r8.title,r8.desc,r8.grade].join(' ')),`stage 8 not a shown closure: ${lang} ${p} ${mm}`);
 for(let s=0;s<9;s++){const r=M.getGenesisDisplayData(s,lang,p,mm);ok(!/Saturated|Inversion Horizon|Fused Pair|Spectator Bit|Column=/.test(r.grade+' '+r.coordinate),`genesis ${s} ${lang} ${p} ${mm}: no retired caption`);
  if(p==='Physicist'||p==='Mathematician'||p==='Fisico'||p==='Matematico'){const a=AUD.GENESIS_METADATA[`Sector_Genesis_Node_${s}_en_Physicist_Spatial`].coordinate;ok(r.coordinate.replace(/−/g,'-').replace(/nullo/,'null').replace(/ombre con segno/,'signed shadows').replace(/le celle \[8,±8\] hanno la stessa algebra/,'≅ cells [8,±8]').replace(/the cells \[8,±8\] have the same algebra/,'≅ cells [8,±8]').replace(/\(≅ cells/,'(≅ cells')===a.replace(/\(≅ cells/,'(≅ cells'),`genesis ${s} ${lang}: address equals the audited one`)}}}
// the heading and the prose of the equations page end at the last step in steps.js, with explicit step numbers (nothing says "the last three/four steps")
import {STEP_GROUPS,NAV_NAMES,stepNo} from './steps.js';
for(const lang of ['en','it']){const e=STORY[lang].pages.equations,last=STEP_GROUPS.eq.at(-1);ok(e.h.toLowerCase().includes(NAV_NAMES[lang][last].toLowerCase()),`equations heading ends at ${last}: ${lang}`);ok(!/last (three|four)|ultimi (tre|quattro)|ultimo sale|The last climbs/i.test(e.does),`no "last N steps" in the equations text: ${lang}`);ok(e.does.includes(String(stepNo('eq','nullsurf'))),`equations text names step ${stepNo('eq','nullsurf')}: ${lang}`)}
// readings are always marked
for(const lang of ['en','it'])for(const s of [3,5,6,7,8]){const r=M.getGenesisDisplayData(s,lang,'Physicist','Spatial');ok(/Reading, not derived|Lettura, non derivata/.test(r.desc),`node ${s} reading marked`)}
// the story shell: both languages have every page, every tag kind and a bridge sentence
for(const lang of ['en','it']){const S=STORY[lang];for(const pg of PAGES){ok(S.nav[pg]&&S.pages[pg].h&&S.pages[pg].does&&S.pages[pg].tags.length,`${lang} ${pg}`);S.pages[pg].tags.forEach(([k],i)=>{const ks=k===''?[]:k.split(' ');ok(ks.every(x=>S.tags[x]&&S.tagHelp[x])&&new Set(ks).size===ks.length&&(ks.length>0||(pg==='equations'&&i===0)),`tag ${k} (${pg} ${i})`)})}
 for(const p of P)ok(S.hero[p].length===2,`hero ${p}`);ok(S.metric.Spatial&&S.metric.Temporal,'metric')}
for(let i=0;i<PAGES.length-1;i++)ok(STORY.en.pages[PAGES[i]].after,`page ${PAGES[i]} hands on`);
// every node has an audit status shown as a tag
for(const id of ids){const r=M.getCompleteDualMetricDisplayData(id,'en','Physicist','Spatial');ok(['verified','realigned','speculative'].includes(r.auditStatus),`${id} audit status`)}
// ---- the Young Learner reads the atlas, the Genesis tour and the frame of every page in plain words. The formula and jargon lists are read from
// test_yl_ui.mjs itself, so the two tests cannot drift apart. Every atlas record exists in both languages and both metrics, carries no formula,
// no technical word and no "Audit:" note; the hedged readings keep their hedges; the retired strings survive in no language and no audience.
{ const fs=await import('fs'), YT=fs.readFileSync('./test_yl_ui.mjs','utf8');
  const SYM=new RegExp(/^const SYMBOLS = \/(.+)\/;$/m.exec(YT)[1],'u'), JAR=new RegExp(/^const JARGON = \/(.+)\/i;$/m.exec(YT)[1],'i');
  const plain=(t,m)=>{const s=SYM.exec(t),j=JAR.exec(t);ok(!s&&!j&&!/\bAudit\b/.test(t),`${m}: not plain (${(s||j||['Audit'])[0]}) in "${t.slice(0,90)}"`)};
  const YA=await import('./ylAtlas.js'); ok(ids.length===25&&ids.every(id=>YA.YL_ATLAS_IDS.includes(id)),'every atlas node has a Young Learner text');
  const Y='Young Learner';
  for(const lang of ['en','it'])for(const mm of ['Spatial','Temporal'])for(const id of ids){const r=M.getCompleteDualMetricDisplayData(id,lang,Y,mm),tag=`YL atlas ${id} ${lang} ${mm}`;
   ok(r.title&&r.subtitle&&r.desc&&r.desc.length>60&&r.yl&&r.yl.place,`${tag}: title, subtitle, desc and captions`);
   plain([r.title,r.subtitle,r.desc].join(' '),tag); for(const [k,v] of Object.entries(r.yl))plain(v,`${tag} caption ${k}`);
   for(const v of ['Clifford','Prime','Simplex','Cube'])plain(YA.ylPictureCaption(id,v,lang,mm),`${tag} picture ${v}`);
   const T=[r.title,r.subtitle,r.desc].join(' ');
   if(mm==='Temporal')ok(lang==='en'?/only bookkeeping/.test(T)&&/nothing runs backwards/.test(T)&&/nothing new about the real world follows/.test(T):/solo contabilità/.test(T)&&/nulla va all’indietro/.test(T)&&/non ne segue nulla di nuovo sul mondo reale/.test(T),`${tag}: the mirror is bookkeeping, nothing runs backwards, nothing physical follows`);
   if(id==='Sector_Electroweak_Unified')ok(lang==='en'?/a way of counting that we chose/.test(T)&&/real weak interaction is not derived here/.test(T):/un modo di contare che abbiamo scelto/.test(T)&&/vera interazione debole non è ricavata qui/.test(T),`${tag}: 17/34 is a counting convention, the weak interaction is not derived`);
   if(id==='Sector_Row7_Mirror')ok((lang==='en'?/matter and antimatter[^.]*(that is|is still) a reading, not a result/:/materia e antimateria[^.]*(è|resta) una lettura, non un risultato/).test(T)&&!/antimatter (gate|twin)|gemello di antimateria/i.test(T),`${tag}: matter/antimatter is a reading`);
   if(id==='Sector_Open_Questions')ok(!/feel heavy|explain why|sembrano pesanti|spiegano perché/i.test(T)&&(lang==='en'?/no weights/.test(T):/nessun peso/.test(T)),`${tag}: says what is missing, never that the rules explain weight`);
   if(id==='Sector_Gravity_Strain'||id==='Sector_Vacuum_Mass_Generation'||id==='Sector_Trivector_Lepton')ok(/idea we try|only a reading|is a reading|un’idea che proviamo|solo una lettura|è una lettura|no law of gravity|no weight|nessuna legge|nessun peso/i.test(T),`${tag}: the reading is hedged`);}
  for(const lang of ['en','it'])for(const mm of ['Spatial','Temporal'])for(let s=0;s<9;s++){const r=M.getGenesisDisplayData(s,lang,Y,mm);plain([r.title,r.desc,r.grade,r.coordinate].join(' '),`YL genesis ${s} ${lang} ${mm}`);if(mm==='Temporal')ok(/nothing runs backwards|nulla va all’indietro/.test(r.desc),`YL genesis ${s} ${lang}: the mirror sentence`)}
  for(const lang of ['en','it'])for(const p of P)for(const mm of ['Spatial','Temporal']){for(const id of ids){const r=M.getCompleteDualMetricDisplayData(id,lang,p,mm),t=[r.title,r.subtitle,r.desc].join(' ');ok(!/Ingranage/.test(t)&&!/still 1 building blocks|restano 1\b/.test(t),`${id} ${lang} ${p} ${mm}: no "Ingranage", no "1 building blocks"`)}}
  // ... and not in the layers underneath either (the Young Learner layer covers them on the page, but the source must not keep them)
  for(const f of ['node-metadata.js','sector-translations.js','matrixData.js','storyOverrides.js','genesis_audit_v3.js','ylAtlas.js'])ok(!/Ingranage/.test(fs.readFileSync('./'+f,'utf8')),`${f}: no "Ingranage"`);
  for(const [id,mt] of Object.entries(AUD.METRIC_TEXT))for(const lang of ['en','it'])for(const [ti,de] of (mt.Temporal?.[lang]||[]))ok(!/still 1 building blocks|restano 1\b/.test(de),`METRIC_TEXT ${id} ${lang}: no "1 building blocks"`);
  for(const lang of ['en','it']){const r=M.getCompleteDualMetricDisplayData('Sector_Electroweak_Unified',lang,'Mathematician','Spatial'),t=[r.title,r.subtitle,r.desc].join(' ');ok(!/principal sub-ideals generated|sotto-ideali principali generati/.test(t)&&/Cl\(4,4\) ≅ M₁₆\(ℝ\)/.test(t)&&/(centre|centro) ℝ/.test(t)&&/(counting convention|convenzione di conteggio)/.test(t),`Electroweak Mathematician ${lang}: the simple algebra M16(R), centre R, 4/17 a convention`)}
  // the frame of every page and the Map, in plain words, with the same keys in both languages
  const {STORY_YL}=await import('./storyCopy.js'), ST=await import('./steps.js'), MC=await import('./mapCopy.js');
  for(const lang of ['en','it']){const y=STORY_YL[lang];ok(PAGES.every(pg=>y.pages[pg]&&y.pages[pg].h&&y.pages[pg].tags.length===STORY[lang].pages[pg].tags.length&&y.pages[pg].tags.every(([k],i)=>k===STORY[lang].pages[pg].tags[i][0])),`${lang}: every page has a plain frame with the same tags`);
   plain(JSON.stringify(y),`${lang} page frame`);plain(Object.values(YA.YL_STATUS[lang]).join(' | '),`${lang} status words`);plain(Object.values(ST.NAV_NAMES_YL[lang]).join(' | '),`${lang} tab names`);plain(Object.values(ST.STEP_NAMES_YL[lang]).join(' | '),`${lang} step names`);
   ok(Object.keys(ST.NAV_NAMES_YL[lang]).join()===Object.keys(ST.NAV_NAMES[lang]).join()&&Object.keys(ST.STEP_NAMES_YL[lang]).join()===Object.keys(ST.STEP_NAMES[lang]).join(),`${lang}: plain step and tab names for every step`);
   ok(Object.keys(MC.NODES_YL[lang]).join()===Object.keys(MC.NODES[lang]).join(),`${lang}: a plain map text for every branch`);
   for(const [id,[a,b]] of Object.entries(MC.NODES_YL[lang]))plain(a+' '+b,`${lang} map node ${id}`);
   plain([MC.LENS_NAMES_YL,MC.THREAD_NAMES_YL,MC.THREAD_TEXT_YL].map(o=>Object.values(o[lang]).join(' | ')).join(' | '),`${lang} lenses and threads`);
   const my=MC.MAP_YL[lang];plain([...my.statsText,my.sincePlain,...my.plain,my.treeLede,my.researchH,my.researchLede,my.springLede,my.chartH,my.chartCap,my.rowsLbl(3),my.rowsLblC(4),my.axis,...my.limits,my.nextOpen].join(' | '),`${lang} map copy`)}
  ok(Object.keys(STORY_YL.en.pages).join()===Object.keys(STORY_YL.it.pages).join(),'the plain frame has the same pages in both languages');}
// ---- re-test of v9 (T3-5, T4-13, G15-c/d): the bridges into and out of the equations page end where steps.js ends, for every audience and language
import {stepCount as nSteps,NAV_NAMES_YL as NYL} from './steps.js';
import {STORY_YL as SYL} from './storyCopy.js';
import {SHORT as SH} from './audienceCopy.js';
{ const last=STEP_GROUPS.eq.at(-1),N=stepNo('eq',last),first=STEP_GROUPS.eq[0],STALE=/ended with a (rigid|solid) body|è finita con un corpo|rigid-body dynamics and spinors|dinamica del corpo rigido e agli spinori|a solid body and things that turn twice|un corpo solido e alle cose che girano/i;
  for(const lang of ['en','it'])for(const [w,S,NN] of [['',STORY,NAV_NAMES],['Young Learner ',SYL,NYL]]){const mb=S[lang].pages.map.before,sa=S[lang].pages.shapes.after,L=NN[lang][last].toLowerCase(),F=NN[lang][first].toLowerCase();
   ok(mb.includes(String(N))&&mb.includes(L)&&!STALE.test(mb),`${w}${lang} map.before ends the equations page at step ${N}, ${L}: ${mb}`);
   ok(sa.includes(L)&&sa.includes(F)&&!STALE.test(sa),`${w}${lang} shapes.after runs from ${F} to ${L}: ${sa}`);}
  const ns=stepNo('eq','nullsurf'),rg=stepNo('eq','rigid'),sp=stepNo('eq','spin');
  ok(STORY.en.pages.equations.does.includes(`Steps ${ns} to ${rg} and step ${sp} are different`)&&STORY.en.pages.equations.does.includes(`Step ${ns} takes claims about null surfaces from a published paper`),'en equations prose: steps 13 to 16 and step 5, and the null-surfaces sentence');
  ok(STORY.it.pages.equations.does.includes(`I passi dal ${ns} al ${rg} e il passo ${sp} sono diversi`)&&STORY.it.pages.equations.does.includes(`Il passo ${ns} prende da un articolo pubblicato alcune affermazioni sulle superfici nulle`),'it equations prose: passi dal 13 al 16 e il passo 5, and the null-surfaces sentence');
  ok(SH.en.page_equations[0].includes(`Steps ${ns} to ${rg} and step ${sp} go further`)&&SH.it.page_equations[0].includes(`I passi dal ${ns} al ${rg} e il passo ${sp} vanno oltre`)&&!/last (three|four)|ultimi (tre|quattro)/i.test(SH.en.page_equations.join(' ')+SH.it.page_equations.join(' ')),'short readings of the equations page: steps 13 to 16 and step 5, never "the last three"');
  ok(SH.en.page_equations[1].includes(`${ns} null surfaces`)&&SH.it.page_equations[1].includes(`il ${ns} le superfici nulle`),'Physicist short reading names the null-surfaces step');}
// ---- every algebra label and volume-element claim in the Genesis and atlas texts (Physicist, Mathematician, EN, IT, both metrics) against the type table (T3 §4: G03-b, G03-c)
{ const T='(?:M[₀-₉]+\\([ℝℂℍ]\\)|[ℝℂℍ])',LAB=new RegExp('(?<!⊗\\s*)(?<!\\w)Cl\\((\\d+),\\s?(\\d+)\\)\\s*(?:=|≅)\\s*('+T+'(?:\\s*⊕\\s*'+T+')?)(²)?(?!\\s*⊗|[\\w(])','g');
  const norm=(a,sq)=>{a=a.replace(/\s+/g,'');return sq?a+'⊕'+a:a};let nl=0,nc=0;const recs=[];
  for(const lang of ['en','it'])for(const p of ['Physicist','Mathematician'])for(const mm of ['Spatial','Temporal']){for(let s=0;s<9;s++)recs.push([`genesis ${s} ${lang} ${p} ${mm}`,M.getGenesisDisplayData(s,lang,p,mm)]);for(const id of ids)recs.push([`${id} ${lang} ${p} ${mm}`,M.getCompleteDualMetricDisplayData(id,lang,p,mm)])}
  // a volume-element or split claim is read against the first cell the sentence names
  for(const [w,r] of recs)for(const sen of [r.title,r.subtitle,r.desc].join(' . ').split(/(?<=[.;])\s+/)){const labs=[...sen.matchAll(LAB)];
   for(const m of labs){nl++;const c=cliffordCell(+m[1],+m[2]);ok(norm(m[3],m[4])===c.algebra,`${w}: "${m[0]}" but the type table gives ${c.algebra}`)}
   const fm=/(?<!⊗\s*)(?<!\w)Cl\((\d+),\s?(\d+)\)/.exec(sen);if(!fm)continue;const c=cliffordCell(+fm[1],+fm[2]),sq=/\bI[₀-₉]?²\s?=\s?([+−-]1)/.exec(sen);
   if(sq){nc++;ok(+sq[1].replace('−','-')===c.omega2,`${w}: ${sq[0]} for Cl(${c.p},${c.q}), whose volume element squares to ${c.omega2}: ${sen}`)}
   if(/does not split|non si spezza/.test(sen)){nc++;ok(!c.algebra.includes('⊕'),`${w}: Cl(${c.p},${c.q}) = ${c.algebra} said not to split`)}else if(/\bsplits?\b|si spezza|spezzano/.test(sen)){nc++;ok(c.algebra.includes('⊕'),`${w}: Cl(${c.p},${c.q}) = ${c.algebra} said to split: ${sen}`)}}
  ok(nl>=150&&nc>=20,`labels compared: ${nl} algebras, ${nc} volume-element and split claims`);}
// ---- no closure, saturation, wall or reset at rows 7 and 8, in the atlas (all audiences) and the Genesis stages 7 and 8, unless the sentence denies it (G06-b/d, T3-7)
{ const CL=/\b(satur\w*|clos\w*|chius\w*|chiud\w*|reset|azzer\w*|wall|muro|threshold|soglia|used up|esaurit\w*)\b|Inversion Horizon|Orizzonte d.Inversione/i,
    NEG=/\b(not|no|nothing|never|non|nulla|né|nessun\w*|mai)\b[^.;:]*\b(satur|clos|chius|chiud|reset|azzer|wall|muro|threshold|soglia|used up|esaurit)/i,META=/metaphor|metafora/i;let nr=0,ns=0;
  const row=r=>+((/B\+F\s*=\s*(\d+)/.exec(r.coordinate||'')||[])[1]||0);
  for(const lang of ['en','it'])for(const p of P)for(const mm of ['Spatial','Temporal']){const rs=[...ids.map(id=>[id,M.getCompleteDualMetricDisplayData(id,lang,p,mm)]),...[7,8].map(s=>['genesis '+s,M.getGenesisDisplayData(s,lang,p,mm)])].filter(([,r])=>row(r)>=7);
   for(const [id,r] of rs){nr++;for(const f of ['title','subtitle','desc','grade'])for(const sen of String(r[f]||'').split(/(?<=[.!?])\s+/))if(CL.test(sen)){ns++;ok(!/Inversion Horizon|Orizzonte d.Inversione/i.test(sen)&&(NEG.test(sen)||META.test(sen)),`${id} ${lang} ${p} ${mm} ${f}: a closure or saturation reading at row ${row(r)}: ${sen}`)}}}
  {let ng=0;for(const lang of ['en','it'])for(const p of P)for(const mm of ['Spatial','Temporal'])for(const id of ids){const r=M.getCompleteDualMetricDisplayData(id,lang,p,mm),n=row(r);for(const g of String(r.grade||'').matchAll(/(?:Grade|Grado)\s(\d+)|Faccia-(\d+)/g)){ng++;ok(+(g[1]||g[2])<=n,`${id} ${lang} ${p} ${mm}: caption "${r.grade}" names grade ${g[1]||g[2]} in a cell with ${n} generators (re-check V3-6)`)}}ok(ng>=200,`grade captions read against the cell size (${ng})`);for(const lang of ['en','it'])for(const mm of ['Spatial','Temporal']){const g=M.getCompleteDualMetricDisplayData('Sector_Vacuum_Mass_Generation',lang,'Young Learner',mm).grade;ok(g===(lang==='en'?'Grade 0: just the number 1':'Grado 0: solo il numero 1'),`Young Learner ${lang} ${mm}: the origin cell's caption in plain words: ${g}`)}}
  ok(nr>=60&&ns>=10,`rows 7 and 8 swept (${nr} records, ${ns} sentences with a closure word, each one denying it)`);
  for(const lang of ['en','it']){const r=M.getGenesisDisplayData(8,lang,'Mathematician','Spatial');ok(lang==='en'?/so no new type appears\. That is a statement about types only; it is not shown that the construction is closed/.test(r.desc)&&!/nothing new appears|checked along the time ladder/i.test(r.desc):/quindi non compare alcun tipo nuovo\. È una frase sui tipi; non è mostrato che la costruzione sia chiusa/.test(r.desc)&&!/niente di nuovo|verificato lungo la scala/i.test(r.desc),`stage 8 Mathematician ${lang}: no new type, closure not shown`);
   const h=M.getCompleteDualMetricDisplayData('Sector_Cosmic_Horizon',lang,'Mathematician','Spatial');ok((lang==='en'?/No new type appears and nothing is reset/:/Non compare alcun tipo nuovo e nulla viene azzerato/).test(h.desc),`Cosmic Horizon Mathematician ${lang}: no new type, nothing reset`);
   for(const p of P)for(const mm of ['Spatial','Temporal'])ok(!/Inversion Horizon|Orizzonte d.Inversione/.test(M.getCompleteDualMetricDisplayData('Sector_Row7_Mirror',lang,p,mm).grade),`Row 7 ${lang} ${p} ${mm}: the old caption is gone`)}
  // the Maxwell ladder note lives in the component (MaxwellSection.jsx); its two sentences are pinned in the source
  const mx=(await import('fs')).readFileSync('./MaxwellSection.jsx','utf8');
  ok(mx.includes('(standard; the script checks the type table against its classical recursion up to k = 11). No new type at the period, only the same types again.')&&mx.includes('(standard; lo script controlla la tabella dei tipi contro la sua ricorsione classica fino a k = 11). Nessun tipo nuovo al periodo, solo gli stessi tipi di nuovo.')&&!/Nothing new at the period|\(checked up to k = 11\)|Niente di nuovo al periodo|\(verificato fino a k = 11\)/i.test(mx),'Maxwell ladder note: standard table, no new type at the period (EN, IT)');
  // the dictionary's period-8 card (T3-6): the type comes from the table the script reads (TYPES[(p-q)%8]), so the card says standard, not computed, and its heading draws no closure
  const dx=(await import('fs')).readFileSync('./DictionarySection.jsx','utf8'),dpy=(await import('fs')).readFileSync('./selfcheck/dictionary_selfcheck.py','utf8');
  ok(/TYPES\[\(p-q\)%8\]/.test(dpy)&&/assert per==8/.test(dpy)&&dx.includes("why8H: 'Why no new type appears after 8'")&&dx.includes("why8H: 'Perché dopo 8 non compare nessun tipo nuovo'")&&dx.includes('(the standard type table, not computed here: the script reads it for n = 0…16 and asserts that no shorter period fits)')&&dx.includes('(la tabella standard dei tipi, non calcolata qui: lo script la legge per n = 0…16 e verifica che nessun periodo più corto vada bene)')&&!/last new thing|ultima novità|computed to n ?= ?16|calcolata fino a n ?= ?16/i.test(dx),'dictionary period-8 card: standard table, no "last new thing" (EN, IT)');}
// ---- v11: the four views (A-21 H4, A-22), the two badges of a cell card (A-28), the chirality split against the bit rule (GEN-008, A-07)
{ const fs=await import('fs'), LE=await import('./labelsEngine.js'), CSC=await import('./cellStatusCopy.js');
  // H4: the simplex, the cube and the prime view are functions of n only: every record with the same n has the same three strings, in both metrics and both languages
  ok(AUD.simplexView.length===1&&AUD.cubeView.length===1&&AUD.primeView.length===1,'simplexView, cubeView and primeView take n only');
  for(const lang of ['en','it'])for(const mm of ['Spatial','Temporal']){const byN={};
   for(const id of ids){const r=M.getCompleteDualMetricDisplayData(id,lang,'Physicist',mm),m=/B\+F=(\d+)/.exec(r.coordinate);if(m&&r.cell)(byN[m[1]]??=[]).push(r)}   // the open-questions card has no cell and no row
   ok(Object.keys(byN).length===9,`${lang} ${mm}: the cells fall into the nine rows n = 0..8`);
   for(const [nn,rs] of Object.entries(byN))for(const k of ['simplex','cube','prime']){const f=rs.filter(r=>r[k]!==undefined);ok(f.length>0&&f.every(r=>r[k]===f[0][k]),`${lang} ${mm} n=${nn}: the ${k} view is the same for every cell of the row`);
    if(lang==='en'){const want={simplex:AUD.simplexView,cube:AUD.cubeView,prime:AUD.primeView}[k](+nn);ok(f.every(r=>r[k]===want),`${lang} ${mm} n=${nn}: the ${k} view is the function of n`);}}}
  // A-28: every one of the 25 cards has its cell (the algebra type the first badge covers) or is the open-questions card; the words beside the badges say what they cover
  for(const id of ids){const r=M.getCompleteDualMetricDisplayData(id,'en','Physicist','Spatial');ok(r.cell||id==='Sector_Open_Questions',`${id}: a cell, or the open-questions card`)}
  ok(CSC.CELL_STATUS.en.verified==='the algebra type of this cell'&&CSC.CELL_STATUS.en.realigned.startsWith('the algebra type of this cell; the labels of the cell are a choice')&&CSC.CELL_STATUS.en.name==='the name is a reading we propose'&&/speculative reading/.test(CSC.CELL_STATUS.en.speculative)&&CSC.CELL_STATUS.it===CSC.CELL_STATUS.en,'the card words: the first badge covers the algebra type of the cell, the second says the name is a reading we propose');
  { const YA=await import('./ylAtlas.js');
  ok(!/verified|checked|result|proved|established/i.test([CSC.CELL_STATUS.en.verified,CSC.CELL_STATUS.en.realigned,CSC.CELL_STATUS.en.name].join(' | '))&&!/verified|checked|result|proved|established/i.test([YA.YL_STATUS.en.verified,YA.YL_STATUS.en.realigned,YA.YL_STATUS.en.name].join(' | ')),'the words beside the checked and the ours badge say what they cover and carry no status word (the badges carry the status)');
  ok(YA.YL_STATUS.en.verified==='the kind of this box'&&YA.YL_STATUS.en.name==='the name we give this box is our own idea'&&YA.YL_STATUS.it.verified===YA.YL_STATUS.en.verified&&YA.YL_STATUS.it.name===YA.YL_STATUS.en.name&&YA.YL_STATUS.it.realigned===YA.YL_STATUS.en.realigned,'the Young Learner words: what the first badge covers (the kind of the box) and what the second says (the name is our idea), in both slots'); }
  { const cs=fs.readFileSync('./CellStatus.jsx','utf8'); ok(cs.includes("badge('checked')")&&cs.includes("badge('ours')")&&cs.includes("badge('open')")&&!/cell verified|cell realigned|cella verificata/.test(cs),'CellStatus.jsx draws the three badges (checked: the type, ours: the name, open: the speculative reading) and keeps no chip text of its own'); }
  // GEN-008 by the bit rule: the top blade of an odd-n cell is central; it squares to +1 (and splits the algebra) exactly for the signed cells with p - q = 1 mod 4 and r = 0,
  // and to 0, splitting nothing, in the null-spectator cells Cl(0,0,1), Cl(1,1,1), Cl(2,2,1)
  const top=(p,q,r)=>{const n=p+q+r,sq=[...Array(p).fill(1),...Array(q).fill(-1),...Array(r).fill(0)],t=(1<<n)-1;let central=true;for(let i=0;i<n;i++){const [m1,s1]=LE.bladeMul(t,1<<i,sq),[m2,s2]=LE.bladeMul(1<<i,t,sq);if(m1!==m2||s1!==s2)central=false}return{central,sq:LE.bladeMul(t,t,sq)[1]}};
  for(const [p,q] of [[1,0],[2,1],[3,2],[4,3]]){const t=top(p,q,0);ok(t.central&&t.sq===1,`Cl(${p},${q}): the top blade is central and squares to +1 (it splits)`)}
  for(const [p,q] of [[0,0],[1,1],[2,2]]){const t=top(p,q,1);ok(t.central&&t.sq===0,`Cl(${p},${q},1): the top blade is central and squares to 0 (it splits nothing)`)}
  const src=fs.readFileSync('./genesis_audit_v3.js','utf8');
  ok(src.includes('The same mechanism acts on the signed cells [1,+1], [3,+1], [5,+1] (Cl(1,0), Cl(2,1), Cl(3,2): the leftover switch given the sign +1); in the null-spectator algebras Cl(0,0,1), Cl(1,1,1), Cl(2,2,1) the top element is central but squares to 0 and splits nothing.'),'GEN-008: the audit text says where the split acts and where it fails');
  ok(/The Chirality Split/.test(src)&&!/zero-weight chirality/i.test(src),'GEN-008: the title stays "The Chirality Split"'); }
console.log(bad?bad+' FAILURES':'ALL STORY TESTS PASS');process.exit(bad?1:0)
