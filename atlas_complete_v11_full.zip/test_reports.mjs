// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The six research reports ship whole in reports/ and agree with themselves. (a) Data: MANIFEST.json lists every file of reports/ with its sha256 and size; each of the six
// zips unpacks (python zipfile) to exactly the report's page and its folder; html/ holds exactly the six pages and index.json, whose counts are those of the logs; no e-mail
// address or mail link in any file or zip member, and no file named like a letter, an outreach file, an erratum or a correction; every report folder has its check scripts
// (the mirrored ones byte-identical to their originals in the package), builder, test suite, README and logs; the six pages open as files, carry their headings and their
// present sentences, none of the forbidden sentences anywhere on the page, no corrections section, no erratum id, no address and none of the patterns of history of
// reports/no_history.py; the matrix json, translationMatrixData.js and the check-id table of selfcheck/reports/README.md are what their generators give. (b) Runs: the six
// report suites (without their browser parts) and the check scripts, whose ok lines must equal the recorded logs. About three minutes. reports/run_report_tests.sh runs
// everything, the browser parts and (with --mutation) the sabotage scripts included.  Needs python3 with numpy, scipy and networkx: exit 77 (skipped) without them.   Run: node test_reports.mjs
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(f, 'utf8'), sha = b => crypto.createHash('sha256').update(b).digest('hex');
const py = (args, opts = {}) => spawnSync('python3', args, { encoding: 'utf8', maxBuffer: 64 << 20, ...opts });
const pv = py(['-c', 'import numpy, scipy, networkx']);
if (pv.error || pv.status !== 0) { console.log('SKIP: test_reports needs python3 with numpy, scipy and networkx (the report scripts import them): ' + (pv.error ? 'no python3' : (pv.stderr || '').trim().split('\n').pop())); process.exit(77); }

const R = 'reports';
// folder -> [zip, page]
const FOLDERS = { category: ['category_report.zip', 'category_atlas_report.html'], baez: ['baez_report.zip', 'baez_atlas_report.html'], schuller: ['schuller_report.zip', 'schuller_bridge_report.html'],
  hestenes: ['hestenes_report.zip', 'hestenes_ldg_report.html'], furey: ['furey_report.zip', 'furey_report.html'], pumplun: ['pumplun_report.zip', 'pumplun_dictionary_report.html'] };
const ZIPS = Object.values(FOLDERS).map(x => x[0]), PAGEFILES = Object.values(FOLDERS).map(x => x[1]);
const SKIP_DIRS = new Set(['__pycache__', 'txt', '.git']), SKIP_FILE = /(\.pyc|~|\.swp|\.DS_Store)$/;
const walk = d => fs.readdirSync(d, { withFileTypes: true }).filter(e => !(e.isDirectory() && SKIP_DIRS.has(e.name))).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : SKIP_FILE.test(e.name) ? [] : [path.join(d, e.name)]);
const rel = f => path.relative(R, f).split(path.sep).join('/');
const ALL = walk(R).map(rel).sort();

// ---- (a1) the manifest: exactly the files of reports/, with their hashes and sizes; html/ holds the six pages and index.json; six zips
const M = JSON.parse(rd(path.join(R, 'MANIFEST.json')));
const listed = Object.keys(M.files).sort(), present = ALL.filter(f => f !== 'MANIFEST.json');
ok(JSON.stringify(listed) === JSON.stringify(present), 'MANIFEST.json lists exactly the files of reports/: ' + [...present.filter(f => !listed.includes(f)), ...listed.filter(f => !present.includes(f)).map(f => '-' + f)].join(', '));
const wrongHash = listed.filter(f => { const b = fs.existsSync(path.join(R, f)) ? fs.readFileSync(path.join(R, f)) : null; return !b || sha(b) !== M.files[f].sha256 || b.length !== M.files[f].bytes; });
ok(wrongHash.length === 0 && present.length > 80, 'every file has the sha256 and size the manifest gives (' + present.length + ' files): ' + wrongHash.join(', '));
ok(M.total_bytes === present.reduce((s, f) => s + fs.statSync(path.join(R, f)).size, 0) && M.total_bytes < 6e6, 'the manifest total is the sum of the sizes, and reports/ stays small (' + M.total_bytes + ' bytes)');
const htmlListed = listed.filter(f => f.startsWith('html/')), zipsListed = listed.filter(f => f.startsWith('zips/'));
ok(JSON.stringify(htmlListed) === JSON.stringify([...PAGEFILES.map(f => 'html/' + f), 'html/index.json'].sort()), 'the manifest lists html/ with exactly the six pages and index.json: ' + htmlListed.join(', '));
ok(JSON.stringify(zipsListed) === JSON.stringify(ZIPS.map(z => 'zips/' + z).sort()) && JSON.stringify(Object.keys(M.zips).sort()) === JSON.stringify([...ZIPS].sort()), 'the manifest lists exactly the six zips: ' + zipsListed.join(', '));

// ---- (a2) each zip unpacks (python zipfile) to the report's page and exactly its folder; no address inside any member
const EMAIL = '[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}';
const ZPY = `import sys, zipfile, hashlib, json, re
E = re.compile(sys.argv[1]); out = {}
for z in sys.argv[2:]:
    with zipfile.ZipFile(z) as f:
        ms = {}
        for i in f.infolist():
            if i.is_dir(): continue
            b = f.read(i.filename); t = b.decode('utf-8', 'replace')
            ms[i.filename] = [hashlib.sha256(b).hexdigest(), bool(E.search(t)) or ('mail' + 'to:') in t.lower()]
        out[z] = ms
print(json.dumps(out))`;
const zr = py(['-I', '-c', ZPY, EMAIL, ...ZIPS.map(z => path.join(R, 'zips', z))]);
const Z = zr.status === 0 ? JSON.parse(zr.stdout) : {};
ok(zr.status === 0, 'python zipfile reads the six zips: ' + (zr.stderr || '').trim().split('\n').pop());
for (const [folder, [zip, page]] of Object.entries(FOLDERS)) {
  const members = Z[path.join(R, 'zips', zip)] || {}, files = [...ALL.filter(f => f.startsWith(folder + '/')), 'html/' + page].sort();
  const same = JSON.stringify(Object.keys(members).sort()) === JSON.stringify(files) && files.every(f => members[f][0] === sha(fs.readFileSync(path.join(R, f))));
  ok(same && files.length >= 10, `zips/${zip} unpacks to exactly html/${page} and reports/${folder}/ (${files.length} files, byte for byte): ` + [...files.filter(f => !(f in members)), ...Object.keys(members).filter(m => !files.includes(m)).map(m => '+' + m)].join(', '));
  ok(Object.values(members).every(([, mail]) => !mail), `no e-mail address and no mail link in any member of zips/${zip}: ` + Object.entries(members).filter(([, v]) => v[1]).map(([k]) => k).join(', '));
}
const RESERVED = /@([A-Za-z0-9-]+\.)*(example\.(com|org|net)|[A-Za-z0-9-]+\.invalid|example|invalid|test|localhost)$/i;
const mails = ALL.filter(f => /\.(py|sh|js|mjs|md|json|html|css|log|txt)$/.test(f)).flatMap(f => { const t = rd(path.join(R, f)).replace(/<!--[\s\S]*?-->/g, ''); return [...t.matchAll(new RegExp(EMAIL, 'g'))].filter(m => !RESERVED.test(m[0].slice(m[0].indexOf('@')))).map(m => f + ': ' + m[0]).concat(t.toLowerCase().includes('mail' + 'to:') ? [f + ': mail link'] : []); });
ok(mails.length === 0, 'no e-mail address and no mail link in any file of reports/: ' + mails.slice(0, 5).join(' | '));

// ---- (a3) the folders: what each one must hold; the mirrored scripts are the ones of the package
const NEED = { category: ['cat_check.py', 'status_chips.py', 'mutate_cat.py', 'build_report_cat.py', 'test_report_cat.py', 'content_cat.py', 'figs_cat.py', 'matrix_cat.py', 'README_cat.md', 'cat_results.json', 'logs/cat_check.log', 'logs/mutation_cat.log'],
  baez: ['baez_check.py', 'status_chips.py', 'mutate_baez.py', 'build_report_baez.py', 'test_report_baez.py', 'figs_baez.py', 'matrix_baez.py', 'README_baez.md', 'logs/baez_check.log', 'logs/baez_figdata.json', 'logs/mutate_baez.log'],
  schuller: ['bridge_check.py', 'status_chips.py', 'bridge_check_qm.py', 'fibre_check.py', 'mutate_fibre.py', 'build_report.py', 'fibre_section.py', 'matrix_data.py', 'test_report.py', 'README_schuller.md', 'logs/bridge_check_final.log', 'logs/bridge_check_qm_final.log', 'logs/fibre_check_final.log', 'logs/mutation_fibre.log'],
  hestenes: ['hest_check.py', 'status_chips.py', 'gtg_check.py', 'bitcliff.py', 'stalg.py', 'hest_indep.py', 'ldg_indep.py', 'ldg_action.py', 'mutate_hestenes.py', 'build_report_hestenes.py', 'content_hestenes.py', 'figs_hestenes.py', 'test_report_hestenes.py', 'report_style.css', 'report_script.js', 'README_hestenes.md',
    'logs/hest_check.log', 'logs/gtg_check_SG.log', 'logs/mutate_hestenes.log'],
  furey: ['furey_papers_check.py', 'status_chips.py', 'furey_construction_check.py', 'threegen_selfcheck.py', 'dictionary_selfcheck.py', 'model.py', 'run_all.py', 'furey_papers.json', 'mutate_furey.py', 'build_report_furey.py', 'content_furey.py', 'figs_furey.py', 'test_report_furey.py', 'report_style.css', 'report_script.js', 'README_furey.md',
    'logs/furey_papers_check.log', 'logs/furey_construction_check.log', 'logs/mutate_furey.log'],
  pumplun: ['pumplun_checks.py', 'golden.json', 'test_report_pumplun.py', 'test_page_pumplun.mjs', 'README_pumplun.md', 'logs/pumplun_checks.log', 'logs/pumplun_checks_full.log',
    ...['build.py', 'status_chips.py', 'template.html', 'style.css', 'lib.js', 'engine.js', 'analysis.js', 'noise.js', 'widgets.js', 'main.js', 'test_engine.js', 'test_f8.js', 'package.json'].map(f => 'build/' + f)] };
for (const [folder, need] of Object.entries(NEED)) ok(need.every(f => ALL.includes(folder + '/' + f)), `reports/${folder}/ has its check scripts, builder, suite, sabotage script, logs and README: missing ` + need.filter(f => !ALL.includes(folder + '/' + f)).join(', '));
// [report folder, file, folder of the package that holds the original]
const COPIES = [['category', 'cat_check.py', 'selfcheck/reports'], ['baez', 'baez_check.py', 'selfcheck/reports'], ['schuller', 'fibre_check.py', 'selfcheck/reports'], ['schuller', 'bridge_check.py', 'selfcheck/reports'], ['schuller', 'bridge_check_qm.py', 'selfcheck/reports'],
  ['hestenes', 'gtg_check.py', 'selfcheck/steps15_17'], ['hestenes', 'bitcliff.py', 'selfcheck/steps15_17'],
  ['furey', 'furey_papers_check.py', 'selfcheck'], ['furey', 'threegen_selfcheck.py', 'selfcheck'], ['furey', 'dictionary_selfcheck.py', 'selfcheck'], ['furey', 'furey_papers.json', 'selfcheck'], ['furey', 'model.py', '.'], ['furey', 'run_all.py', '.']];
const differs = ([d, s, o]) => !fs.existsSync(path.join(o, s)) || sha(fs.readFileSync(path.join(R, d, s))) !== sha(fs.readFileSync(path.join(o, s)));
ok(COPIES.every(c => !differs(c)), `the ${COPIES.length} mirrored files in reports/ are byte-identical to their originals in the package (one script, two places): ` + COPIES.filter(differs).map(([d, s, o]) => `${d}/${s} vs ${o}/${s}`).join(', '));
// the status chips: one table of drawings (that of the atlas's own badges), one chip module in six places, one shared check
const ICONS = new Function('return ' + rd('StatusBadge.jsx').match(/export const ICON_PATHS = (\{[\s\S]*?\n\});/)[1])();
const CHIPMODS = ['category', 'baez', 'schuller', 'hestenes', 'furey', 'pumplun/build'];
const modSha = CHIPMODS.map(d => fs.existsSync(path.join(R, d, 'status_chips.py')) ? sha(fs.readFileSync(path.join(R, d, 'status_chips.py'))) : '');
ok(new Set(modSha).size === 1 && modSha[0] !== '', 'status_chips.py is one file in the six places (' + CHIPMODS.join(', ') + ')');
const drawn = [...CHIPMODS.map(d => [path.join(R, d), 'status_chips']), [R, 'status_check']].map(([d, m]) => py(['-c', 'import sys, json; sys.path.insert(0, sys.argv[1]); import ' + m + ' as S; print(json.dumps(S.ICON_PATHS))', d]));
ok(Object.keys(ICONS).join() === 'standard,checked,ours,open,input' && drawn.every(t => t.status === 0 && JSON.stringify(JSON.parse(t.stdout)) === JSON.stringify(ICONS)), 'the five drawings of status_chips.py (six places) and of status_check.py are the ICON_PATHS of StatusBadge.jsx, path for path');
ok(ALL.every(f => !/letter|outreach|researcher_emails|errata|CORRECTION/i.test(f)) && ALL.every(f => !['build_letter', 'shots.py'].some(p => f.includes(p))), 'nothing private or scratch is shipped (no letter, outreach, address-list, erratum or correction file, no screenshot helper): ' + ALL.filter(f => /letter|outreach|researcher_emails|errata|CORRECTION|shots\.py/i.test(f)).join(', '));
const SPDX = ['SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', 'Required Notice: Copyright (c) 2026 the Cascade Atlas authors', 'Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)'];
const unheaded = ALL.filter(f => /\.(py|sh|js|mjs)$/.test(f) && !SPDX.every(l => rd(path.join(R, f)).split('\n').slice(0, 6).join('\n').includes(l)));
ok(unheaded.length === 0, 'every script in reports/ carries the three-line SPDX header: ' + unheaded.join(', '));
const readme = rd(path.join(R, 'README.md'));
ok(['html/', 'html/index.json', 'zips/', 'MANIFEST.json', 'make_package.py', 'make_matrix_json.py', 'make_check_table.py', 'run_report_tests.sh', 'no_history.py', 'status_check.py', 'status_chips.py', 'translation_matrix.json', ...ZIPS, ...PAGEFILES, ...Object.keys(FOLDERS).map(f => f + '/')].every(x => readme.includes(x)),
   'reports/README.md names the six pages, the six zips and folders, the index, the generators, the runner and the matrix: ' + ['html/', 'html/index.json', 'zips/', 'MANIFEST.json', 'make_package.py', 'make_matrix_json.py', 'make_check_table.py', 'run_report_tests.sh', 'no_history.py', 'status_check.py', 'status_chips.py', 'translation_matrix.json', ...ZIPS, ...PAGEFILES, ...Object.keys(FOLDERS).map(f => f + '/')].filter(x => !readme.includes(x)).join(', '));

// ---- (a4) the six pages: headings, the present sentences, the forbidden wording nowhere, no corrections section, no erratum id, no address, no history
const PAGES = {
  'category_atlas_report.html': { h1: 'What is label 0, seen through categories?',
    right: ['an additive integer degree', 'the trace of the Born rule is a symmetric Frobenius form', 'det = 9 − n is 0 only at n = 9', 'Clifford periodicity does not cause the stop', 'the count behind the ten of the Tenfold Way (Wall, recalled)', 'fails from three generators on, and only there', 'the complement of the face of labels with none', 'the top-blade form is symmetric iff n is odd', 'the Tits form there is (6,1,1)', 'three maps and a duality'],
    forbidden: ['conserved integer degree', 'conserved charge', 'the Born rule is the Frobenius form', 'is the boundary between the definite and the Lorentzian', 'the reason for the ten', 'our reading only', 'Ladders as functors', 'three functors and a duality', 'the same pattern as the category itself', 'it is symmetric only for odd n or without null generators'] },
  'baez_atlas_report.html': { h1: 'Seven Baez papers and the atlas',
    right: ['calling that flip charge conjugation is ours', 'the standard anomaly cancellation, recomputed over the labels', 'the nested triples contain (3,2), then (3̄,1) + (1,1), then one generation, then 11 more states', 'a real representation is vector-like (standard)', 'a metric Hodge star only without null generators', 'coefficient of the empty label, the unit'],
    forbidden: ['particle to antiparticle', 'the antiparticle side', 'the labels explain', 'computed by us', 'build a generation', 'no chiral generation inside', 'Hodge complement', 'coefficient of label 0'] },
  'schuller_bridge_report.html': { h1: 'Schuller and the atlas: a translation matrix',
    right: ['product states are the null cone of det on M₂(ℝ)', 'over ℂ the condition is det = 0 on M₂(ℂ)', 'A momentum along an extra space-like direction enters as a mass', 'S, E, E, S, S, S, A', 'one Lorentzian class in two conventions, P ↔ −P', 'Cl(2,2) is the first ultrahyperbolic cell', 'M = ±I has X = 0 and bounded powers', 'the textbook elliptic/parabolic/hyperbolic split of SL(2,ℝ)', 'isomorphic as an algebra to the End(V)', 'with the indices raised', 'is a theorem: a doubly-even self-dual code of length n'],
    forbidden: ['quadric of entangled', 'Mass is a fibre momentum', 'hyperbolicity says the fibre is space-like', 'E, S, E, S, S, S, A', 'exactly two ladders', 'first excluded', 'fifth home', 'is Furey’s End(V)', 'edge: X² = 0, parabolic', 'Casimir of the spin representation = C(n,2)/4', 'not a theorem I have proved in general'] },
  'hestenes_ldg_report.html': { h1: 'Space-time algebra and gauge-theory gravity in the bit rule',
    right: ['Nothing here is a result about nature', 'which choices the physics page makes that the algebra does not', 'The Dirac equation on plane waves: two kernels, one for each sign of the energy', 'is XOR with 9', 'checks pass, 0 fail', 'deliberate sabotages of the independent scripts were caught', 'Not said: which kernel is matter'],
    forbidden: ['the Dirac equation is derived', 'the bit rule derives', 'proves that nature', 'the time direction is derived', 'gravity is derived', 'your paper'] },
  'furey_report.html': { h1: 'The division algebras and the Standard Model in the bit rule',
    right: ['This is Calibration 2 (Furey) of the atlas in its long form', 'Nothing here is a result about nature, and nothing says that a cell, a block or a product of irreps is a particle', 'the octonion table is the XOR rule with a sign that does not associate', 'the sixteen axes of V carry the extended Hamming code', 'three complete sets first fit at dimension 14 among the block structures searched', 'deliberate sabotages of the checks were caught', 'the complex structure, the partition of the axes into blocks, the hypercharges, the labels of the figure, and the family of structures searched'],
    forbidden: ['the Standard Model is derived', 'derives the three generations', 'explains the three generations', 'predicts the three generations', 'the particles are the cells', 'your paper', 'is a wall'] },
  'pumplun_dictionary_report.html': { h1: 'The bit rule in the language of crossed products and Petit algebras',
    right: ['Unreviewed and preliminary; written by the atlas authors with computer-algebra help', 'The paper was read completely', 'Associativity is the cocycle condition', 'tested against Theorem 3.2 of the paper: 0 disagreements', 'dictionary between the Cascade Atlas', 'each such point may come from a misreading of the statement or its hypotheses on our side'],
    forbidden: ['written for Susanne', 'your paper', 'your Theorem', 'Questions for you', 'we would be glad to share', 'please say so and we will update', 'hers —'] } };
const unent = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&amp;/g, '&');
const plainOf = h => unent(h.replace(/<style[\s\S]*?<\/style>|<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ');
const tipsOf = h => [...h.matchAll(/data-tip="([^"]*)"/g)].map(m => unent(m[1])).join(' ');
for (const [file, P] of Object.entries(PAGES)) {
  const f = path.join(R, 'html', file), h = fs.existsSync(f) ? rd(f) : '';
  ok(/^<!doctype html>/i.test(h.trimStart()) && h.includes('</html>') && h.includes(`<h1>${P.h1}</h1>`), `${file} opens as a self-contained file with its heading “${P.h1}”`);
  ok(!/(src|href)="https?:\/\/(?!arxiv\.org)/.test(h) && !/<script[^>]+src=|<link[^>]+href|@import|url\(http/.test(h), `${file}: no external request (links to arxiv.org only)`);
  const cs = [...h.matchAll(/<span class="chip (standard|checked|ours|open|input)" role="img" aria-label="([^"]*)" title="([^"]*)"><svg class="ic" aria-hidden="true" focusable="false"><use href="#i-\1"\/><\/svg><\/span>/g)], nspan = (h.match(/<span class="chip[ "]/g) || []).length;
  const sym = f => [...((h.match(new RegExp('<symbol id="i-' + f + '" viewBox="0 0 16 16">([\\s\\S]*?)</symbol>')) || [])[1] || '').matchAll(/<path d="([^"]*)"\/>/g)].map(m => m[1]);
  ok(cs.length >= 40 && cs.length === nspan && cs.every(c => unent(c[2]).startsWith(c[1]) && unent(c[3]).startsWith(c[1])) && !/class="tg /.test(h) && !h.includes('<i></i>') && Object.keys(ICONS).every(f => JSON.stringify(sym(f)) === JSON.stringify(ICONS[f]))
     && [...new Set(cs.map(c => c[1]))].every(f => h.includes('<b>' + f + '</b>: ')), `${file}: every status is an icon chip (role img, its word as name and hover text, no word chip; ${cs.length} of ${nspan}), the five drawings are those of the atlas badge, and the legend gives each flag in use its word and meaning`);
  const all = plainOf(h) + ' ' + tipsOf(h);
  ok(P.right.every(s => all.includes(s)), `${file}: the present sentences are on the page: missing ` + P.right.filter(s => !all.includes(s)).join(' | '));
  ok(P.forbidden.every(s => !all.includes(s)), `${file}: none of the forbidden sentences is on the page: ` + P.forbidden.filter(s => all.includes(s)).join(' | '));
  ok(!/id="corr2?"/.test(h) && !/\bE-\d{3}\b/.test(all), `${file}: no corrections section and no erratum id`);
  ok(!h.replace(/<style[\s\S]*?<\/style>/g, '').includes('@') && !h.toLowerCase().includes('mail' + 'to:'), `${file}: no @ outside the style sheet and no mail link (no address of any person)`);
}
const nh = py(['-I', path.join(R, 'no_history.py'), ...PAGEFILES.map(f => path.join(R, 'html', f))]);
ok(nh.status === 0 && PAGEFILES.every(f => (nh.stdout || '').includes(path.join(R, 'html', f) + ' 0 hits')), 'the six pages hold none of the patterns of history of reports/no_history.py (erratum, correction of ours, forbidden or struck sentence, was wrong, earlier version, version stamp): ' + (nh.stdout || nh.stderr || '').split('\n').filter(l => /^ +P|selftest|[1-9]\d* hits/.test(l)).slice(0, 4).join(' | '));
const IX = JSON.parse(rd(path.join(R, 'html', 'index.json'))).reports, okLinesIn = f => rd(path.join(R, f.replace(/^reports\//, ''))).split('\n').filter(l => /^ok  /.test(l)).length;
ok(IX.length === 6 && JSON.stringify(IX.map(r => r.file)) === JSON.stringify(Object.values(FOLDERS).map(x => 'reports/html/' + x[1])) && new Set(IX.map(r => r.id)).size === 6, 'html/index.json lists the six reports, in order, with unique ids');
ok(IX.every(r => { const h = rd(path.join(R, 'html', r.file.replace('reports/html/', ''))), t = (h.match(/<h1>(.*?)<\/h1>/) || [])[1]; return r.title === unent(t || '') && r.bytes === Buffer.byteLength(h) && r.checks === r.logs.reduce((s, l) => s + okLinesIn(l), 0) && r.scripts.every(s => fs.existsSync(s) || fs.existsSync(path.join(PKG, s))) && fs.existsSync(r.suite) && fs.existsSync(r.zip) && r.line.length > 30; }),
   'html/index.json: each title is the page heading, each size the size of the page, each count the ok lines of its logs, and the scripts, suite and zip exist (checks ' + IX.map(r => r.id + ' ' + r.checks).join(', ') + ')');

// ---- (a5) generated files are what their generators give
const gm = py([path.join(R, 'make_matrix_json.py'), '--check']);
ok(gm.status === 0, 'reports/translation_matrix.json is what make_matrix_json.py builds from the three matrix modules: ' + gm.stdout.trim());
const gd = spawnSync(process.execPath, ['make_matrix_data.mjs', path.join(R, 'translation_matrix.json'), '--check'], { encoding: 'utf8' });
ok(gd.status === 0, 'translationMatrixData.js is what make_matrix_data.mjs builds from reports/translation_matrix.json: ' + (gd.stdout + gd.stderr).trim());
const J = JSON.parse(rd(path.join(R, 'translation_matrix.json'))), best = rows => rows.reduce((c, r) => { const g = Object.values(r.cells).map(x => x.grade); c[g.includes('E') ? 0 : g.includes('S') ? 1 : g.includes('A') ? 2 : 3]++; return c; }, [0, 0, 0, 0]).join('/');
ok(['schuller', 'baez', 'category'].map(k => k + ' ' + J.matrices[k].rows.length + ' ' + best(J.matrices[k].rows)).join(', ') === 'schuller 43 23/14/2/4, baez 48 26/11/2/9, category 40 27/6/2/5' && J.columns.length === 22,
   'the matrix: 22 columns; rows and best grades Schuller 43 (23/14/2/4), Baez 48 (26/11/2/9), category 40 (27/6/2/5; W5 is standard)');
const gt = py([path.join(R, 'make_check_table.py'), '--check']);
ok(gt.status === 0, 'the check-id table of selfcheck/reports/README.md is what make_check_table.py gives from the logs: ' + gt.stdout.trim());
const gp = py([path.join(R, 'make_package.py'), '--check']);
ok(gp.status === 0, 'the zips, html/index.json and MANIFEST.json are what make_package.py builds from the folders: ' + gp.stdout.trim());

// ---- (b) the runs: the six report suites (no browser) and the check scripts against their logs
const env = { ...process.env, ATLAS_PKG: PKG, REPORT_NO_BROWSER: '1' };
// [folder, suite, the least number of tests that pass without the browser part]
for (const [folder, suite, min] of [['category', 'test_report_cat.py', 63], ['baez', 'test_report_baez.py', 40], ['schuller', 'test_report.py', 31], ['hestenes', 'test_report_hestenes.py', 39], ['furey', 'test_report_furey.py', 38], ['pumplun', 'test_report_pumplun.py', 34]]) {
  const r = py([suite], { cwd: path.join(R, folder), env }), last = (r.stdout || '').trim().split('\n').pop() || '', n = +((last.match(/(\d+) ok/) || [])[1] || 0);
  ok(r.status === 0 && /, 0 failed/.test(last) && n >= min, `reports/${folder}/${suite} passes (${last}): ` + (r.stdout || '').split('\n').filter(l => /^FAIL/.test(l)).slice(0, 3).join(' | ') + (r.stderr || '').trim().split('\n').pop());
}
const okLines = (t, norm) => t.split('\n').filter(l => /^(ok  |FAIL) /.test(l) && !/^ok   R1:/.test(l)).map(l => norm ? l.replace(/[0-9.]+e[-+][0-9]+/g, '<n>').replace(/[0-9]+\.[0-9]+/g, '<n>') : l);
// [script, folder it runs in, log, residuals normalised]: the five of the package run from selfcheck/reports/ (the originals), the others from their report folder
for (const [script, cwd, log, norm] of [['cat_check.py', 'selfcheck/reports', 'category/logs/cat_check.log'], ['baez_check.py', 'selfcheck/reports', 'baez/logs/baez_check.log'], ['fibre_check.py', 'selfcheck/reports', 'schuller/logs/fibre_check_final.log'],
    ['bridge_check.py', 'selfcheck/reports', 'schuller/logs/bridge_check_final.log'], ['bridge_check_qm.py', 'selfcheck/reports', 'schuller/logs/bridge_check_qm_final.log'],
    ['hest_check.py', 'reports/hestenes', 'hestenes/logs/hest_check.log', true], ['furey_papers_check.py', 'reports/furey', 'furey/logs/furey_papers_check.log'], ['furey_construction_check.py', 'reports/furey', 'furey/logs/furey_construction_check.log'],
    ['pumplun_checks.py', 'reports/pumplun', 'pumplun/logs/pumplun_checks.log']]) {
  const r = py([script], { cwd, env }), fresh = okLines(r.stdout || '', norm), rec = okLines(rd(path.join(R, log)), norm);
  ok(r.status === 0 && fresh.length >= 9 && JSON.stringify(fresh) === JSON.stringify(rec) && fresh.every(l => l.startsWith('ok')), `${cwd}/${script} passes and prints exactly the ok lines of reports/${log} (${fresh.length} lines${norm ? ', residuals normalised' : ''}${/^skip R1/m.test(r.stdout) ? '; R1 skipped, no texts' : ''})`);
}
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL REPORT TESTS PASS'); process.exit(bad ? 1 : 0);
