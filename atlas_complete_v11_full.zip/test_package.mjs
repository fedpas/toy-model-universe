// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The package builds from what it contains plus the named host files, and nothing in it depends on a machine: the import graph of the app and of the routes is closed (the only imports that
// leave the package are the declared host files and the declared npm packages), build.sh and BUILDING.md name the same host files, every source file is used by something, and no script or test
// carries a path of the author's machine. (Audit G01, G36, G37, G38.)  Since the re-test (T6-4): the build entry harness/harness_app.jsx is a root of the graph too, no graph leaves the package
// folder, no file imports or opens anything by absolute path (any machine's, not only the author's), and the runner's own names() line, not its comment, is what is checked.  Run: node test_package.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import { builtinModules } from 'node:module'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs'; import { reachable, ABSOLUTE_SPEC } from './import_graph.mjs';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8');
const HOST_IMPORTS = ['./SimplexCanvas', './GenesisCanvas'], HOST_FILES = ['SimplexCanvas.jsx', 'GenesisCanvas.jsx', 'canvasFacts.js'];   // the owner's files, not shipped
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => ['node_modules', 'dist', 'dist_real', '.git', '__pycache__', 'test_logs'].includes(e.name) ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const all = walk(PKG).map(f => path.relative(PKG, f)).filter(f => !HOST_FILES.includes(f));
// 1. the graph of the app: closed, apart from the host files
const app = reachable('App.jsx');
// the host files are the owner's: when they sit next to App.jsx (a build copy) the graph is closed, when they do not (the package as shipped) exactly the two host canvases are what is missing
const hostThere = HOST_IMPORTS.map(s => fs.existsSync(path.join(PKG, s + '.jsx')));
ok(app.missing.every(([, s]) => HOST_IMPORTS.includes(s)) && HOST_IMPORTS.every((s, i) => app.missing.some(([, x]) => x === s) === !hostThere[i]), 'App.jsx reaches every file it imports, except the host canvases that are not there (' + hostThere.join('/') + '): ' + JSON.stringify(app.missing));
ok(app.files.size > 100, 'and the app graph is the whole app (' + app.files.size + ' files)');
for (const r of ['api/chat.js', 'api/chat-openai.js', 'api/contact.js']) { const g = reachable(r); ok(g.missing.length === 0, r + ' reaches every file it imports: ' + JSON.stringify(g.missing)); }
// the build entry (build.sh bundles harness/harness_app.jsx): it reaches the app, and nothing else is missing than for App.jsx
const HARNESS = 'harness/harness_app.jsx', harness = reachable(HARNESS);
ok(harness.files.has('App.jsx') && harness.missing.every(([, s]) => HOST_IMPORTS.includes(s)) && HOST_IMPORTS.every((s, i) => harness.missing.some(([, x]) => x === s) === !hostThere[i]) && /^\s*\$ESB\s+harness\/harness_app\.jsx\s+--bundle\b/m.test(rd('build.sh')), HARNESS +' (the entry build.sh bundles) reaches App.jsx and every file it imports, except the host canvases that are not there: ' + JSON.stringify(harness.missing));
// no graph leaves the package folder: a relative import that climbs out of it (it would work only next to some other folder of one machine) or an import by absolute path
const leaving = [];
for (const r of ['App.jsx', HARNESS, 'api/chat.js', 'api/chat-openai.js', 'api/contact.js']) { const g = reachable(r); leaving.push(...g.outside.map(x => r + ' -> ' + x.join(': ')), ...g.absolute.map(x => r + ' -> ' + x.join(': ')), ...[...g.files].filter(f => f.startsWith('..') || path.isAbsolute(f)).map(f => r + ' -> ' + f)); }
ok(leaving.length === 0, 'no import of the app, the build entry or a route leaves the package folder: ' + leaving.join(', '));
// 2. host files: build.sh and BUILDING.md say the same as this test
const sh = rd('build.sh'), doc = fs.existsSync(path.join(PKG, 'BUILDING.md')) ? rd('BUILDING.md') : '';
const shHost = (/for f in ([^;]+); do \[ -f/.exec(sh) || [, ''])[1].trim().split(/\s+/);
ok(JSON.stringify(shHost) === JSON.stringify(HOST_FILES), 'build.sh checks exactly the host files: ' + shHost.join(' '));
ok(HOST_FILES.every(f => doc.includes(f)) && /global stylesheet/i.test(doc), 'BUILDING.md names the host files and the global stylesheet');
// T6-9: the order that works (extract next to the repository, merge package.json, then copy), the ignore note, and a script called "standard library only" imports nothing else
ok(!/extract it over/i.test(doc) && !/extract it over/i.test(sh) && /next to your repository/.test(doc) && /merge/.test(doc) && /\.gitignore/.test(doc) && ['dist/', 'dist_real/', 'test_logs/'].every(d => doc.includes('`' + d + '`')), 'BUILDING.md: extract next to the repository, merge package.json, then copy (no "extract it over"); add dist/, dist_real/, test_logs/ to .gitignore');
const stdOnly = [...doc.matchAll(/`([\w/]+\.py)` \(standard library only\)/g)].map(m => m[1]);
ok(stdOnly.length >= 1 && stdOnly.every(f => fs.existsSync(path.join(PKG, f)) && !/^\s*(?:import|from)\s+(?:numpy|scipy|sympy|matplotlib)\b/m.test(rd(f))), 'the scripts BUILDING.md calls "standard library only" import no numpy, scipy, sympy or matplotlib: ' + stdOnly.join(', '));
// 3. the packages: everything the app and the tests import by bare name is declared in package.json
const P = JSON.parse(rd('package.json')), declared = new Set([...Object.keys(P.dependencies || {}), ...Object.keys(P.peerDependencies || {}), ...Object.keys(P.devDependencies || {})]);
const pkgName = s => s.startsWith('@') ? s.split('/').slice(0, 2).join('/') : s.split('/')[0];
const bare = new Set([...app.external].map(pkgName)), testBare = new Set();
const builtin = new Set(builtinModules);
for (const f of all.filter(f => /\.(mjs|js|jsx)$/.test(f) && !f.startsWith('replication' + path.sep + 'runs'))) for (const m of rd(f).matchAll(/^\s*import\s+(?:[^'"\n;]*?\s+from\s+)?['"]([^'"./][^'"]*)['"]/gm)) if (!m[1].startsWith('node:') && !builtin.has(m[1])) testBare.add(pkgName(m[1]));
ok([...bare].every(x => declared.has(x)), 'every package the app imports is declared in package.json: ' + [...bare].filter(x => !declared.has(x)).join(','));
ok([...testBare].every(x => declared.has(x)), 'every package the tests, routes and scripts import is declared in package.json: ' + [...testBare].filter(x => !declared.has(x)).join(','));
ok(['playwright', 'esbuild', 'katex'].every(x => testBare.has(x)), 'the tests import playwright, esbuild and katex by name (no absolute path)');
// 4. no path of a machine in anything that runs
const RUNS = /\.(js|jsx|mjs|cjs|py|sh)$/, MACHINE = /\/home\/claude|\/opt\/npm-tools|\/tmp\/claude|\/Users\/|C:\\\\Users/;
const leaks = all.filter(f => RUNS.test(f) && !f.startsWith('replication' + path.sep + 'runs') && MACHINE.test(rd(f)));
ok(leaks.length === 0, 'no script, test or source file carries a path of the author\'s machine: ' + leaks.join(', '));
// ... nor any absolute path at all (T6-4: the list above names one machine; an import from a global node_modules folder or a fixed temporary folder passed it). Shebang lines and >/dev/null are the exceptions.
const CODE = all.filter(f => RUNS.test(f) && !f.startsWith('replication' + path.sep + 'runs')), absHits = [];
const IMPORTS = /(?:\bimport|\bexport)\s+(?:[^'"()]*?\s+from\s+)?['"]([^'"]+)['"]|\bimport\s*\(\s*['"`]([^'"`]+)['"`]\s*\)|\brequire\s*\(\s*['"`]([^'"`]+)['"`]\s*\)/g;
const CALL = /\b(?:readFileSync|readFile|writeFileSync|writeFile|appendFileSync|existsSync|statSync|lstatSync|readdirSync|mkdirSync|mkdtempSync|copyFileSync|cpSync|rmSync|unlinkSync|renameSync|openSync|createReadStream|createWriteStream|chdir|spawnSync|execSync|execFileSync|open|Path|listdir|import_module|load_source)\s*\(\s*(?:[rbf]?['"`])(?:\/[\w.~-]|[A-Za-z]:[\\/]|file:|~\/)|\bcwd\s*[:=]\s*['"`](?:\/|[A-Za-z]:[\\/]|~\/)|\bpathToFileURL\s*\(\s*['"`]\//;
const SYSTEM = /(?<![\w.~$}\-/!:@\\])\/(?:tmp|usr|home|opt|var|etc|Users|root|mnt|srv|private|Volumes|Library|snap|nix|media|run|workspace|data|proc|sys|bin|sbin|lib|lib64|System|Applications)\/[\w@~-]|['"`][A-Za-z]:(?:\\{1,2}|\/)[\w ]|file:\/\/\/[\w%]/;
const SH_ABS = /(?:^|[;&|]\s*|\bthen\s+|\bdo\s+)cd\s+['"]?\/|(?:^|\s)(?:\d?>>?|<)\s*['"]?\/(?!dev\/null\b)/;
for (const f of CODE) { const t = rd(f);
  if (/\.(js|jsx|mjs|cjs)$/.test(f)) for (const m of t.matchAll(IMPORTS)) { const s = m[1] || m[2] || m[3]; if (ABSOLUTE_SPEC.test(s)) absHits.push(f + ': import ' + s); }
  t.split('\n').forEach((l, i) => { if (i === 0 && l.startsWith('#!')) return;
    if (CALL.test(l) || SYSTEM.test(l) || (f.endsWith('.sh') && !/^\s*#/.test(l) && SH_ABS.test(l))) absHits.push(f + ':' + (i + 1) + ': ' + l.trim().slice(0, 90)); }); }
ok(absHits.length === 0, 'no file imports, opens, runs or names anything by an absolute path (any machine\'s): ' + absHits.slice(0, 6).join(' | ') + (absHits.length > 6 ? ' ...' : ''));
// 5. every source file is used: reached by the app or a route, or named (by file name or module name) by a test, a script or a document. The tests themselves are entry points: run_tests.sh finds them by name pattern.
// reports/MANIFEST.json is generated and lists every file of reports/ by its path, so it cannot show that a file is used: it does not count as naming one (a script of
// reports/ must be named by a README, a test or another script, like every other file of the package)
const texts = all.filter(f => /\.(js|jsx|mjs|cjs|py|sh|md|json|html|txt)$/.test(f) && f !== path.join('reports', 'MANIFEST.json')).map(f => [f, rd(f)]);
const routes = new Set([...reachable('api/chat.js').files, ...reachable('api/chat-openai.js').files, ...reachable('api/contact.js').files]);
const ENTRY = f => /^test_[\w]+\.mjs$|^layout_check\.mjs$/.test(f);
const runner = fs.existsSync(path.join(PKG, 'run_tests.sh')) ? rd('run_tests.sh') : '';
// the code of the runner, not its comments (T6-4: the comment alone satisfied the old check): names() lists by the two patterns, both groups loop over names, and running that very line lists every test
const runnerCode = runner.split('\n').filter(l => !/^\s*#/.test(l)).map(l => l.replace(/\s+#\s.*$/, '')).join('\n');
const namesBody = (/^names\(\)\s*\{(.*)\}\s*$/m.exec(runnerCode) || [, ''])[1];
ok(/^\s*ls\s+test_\*\.mjs\s+layout_check\.mjs\b/.test(namesBody) && (runnerCode.match(/\bfor t in \$\(names\b/g) || []).length === 2, 'run_tests.sh finds the tests by pattern: its names() line is  ls test_*.mjs layout_check.mjs ...  and both groups loop over names, so a new test cannot be forgotten: names() {' + namesBody + '}');
const listed = namesBody ? spawnSync('sh', ['-c', 'names() {' + namesBody + '}; names'], { cwd: PKG, encoding: 'utf8' }).stdout.trim().split('\n').sort() : [];
const tests = all.filter(ENTRY).map(f => f.replace(/\.mjs$/, '')).sort();
ok(tests.length > 50 && JSON.stringify(listed) === JSON.stringify(tests), 'and that names() line, run in the package, lists exactly the ' + tests.length + ' test files: ' + [...tests.filter(x => !listed.includes(x)), ...listed.filter(x => !tests.includes(x)).map(x => '+' + x)].join(', '));
const orphans = all.filter(f => RUNS.test(f) && !ENTRY(f)).filter(f => !app.files.has(f) && !routes.has(f)).filter(f => { const b = path.basename(f), stem = b.replace(/\.\w+$/, ''); return !texts.some(([g, t]) => g !== f && (t.includes(b) || (/\.py$/.test(b) && new RegExp('\\b' + stem + '\\b').test(t) && stem.length > 5))); });
ok(orphans.length === 0, 'every source file is reached by the app or a route, or is named by a test, script or document; orphans: ' + orphans.join(', '));
// 6. a test that names a file by a relative path (to read, list, run or bundle it) first moves to the package folder, so it runs from any folder, not only from the package root (T6-8)
const REL = /\b(?:readFileSync|existsSync|readdirSync|statSync)\(\s*['"`](?:\.\/|\.['"`]|[\w-]+\/)|\bcwd:\s*['"`]\.|\bentryPoints:|\bexecS?y?n?c?\(\s*['"`]python3\s+\w/;
const CHDIR = /^(?:(?!\/\/|\/\*)[^\n])*\bprocess\.chdir\((?:PKG|fileURLToPath\(new URL\('\.', import\.meta\.url\)\))\)/m;
const cwdBound = all.filter(ENTRY).filter(f => REL.test(rd(f)) && !CHDIR.test(rd(f)));
ok(cwdBound.length === 0 && all.filter(ENTRY).filter(f => REL.test(rd(f))).length > 20, 'every test that names files relative to the package moves to the package folder first (process.chdir(PKG)): not in ' + cwdBound.join(', '));
// esbuild takes its working folder when it is imported, before that chdir runs: every bundling call names it
const esb = all.filter(ENTRY).filter(f => /\bbuildSync\(\{/.test(rd(f))), esbFree = esb.filter(f => (rd(f).match(/\bbuildSync\(\{/g) || []).length !== (rd(f).match(/\bbuildSync\(\{\s*absWorkingDir:\s*PKG\b/g) || []).length);
ok(esbFree.length === 0, 'every esbuild call of a test bundles from the package folder (absWorkingDir: PKG): not in ' + esbFree.join(', '));
// 7. what the runner reports (T6-12): run_tests.sh, copied into a temporary folder with four made-up tests and started from another folder, says PASS, FAIL with the test's last line,
// SKIP for exit 77, and for a test that outlives TEST_TIMEOUT: FAIL with "timeout after <N>s" as the reason (the last line of such a test says nothing about why it failed). About 3 s.
{ const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-runner-'));
  try {
    fs.copyFileSync(path.join(PKG, 'run_tests.sh'), path.join(tmp, 'run_tests.sh'));
    const FAKE = { test_a_pass: "console.log('fine'); process.exit(0);", test_b_fail: "console.log('the reason'); process.exit(1);", test_c_skip: "console.log('not here'); process.exit(77);", test_d_slow: "console.log('started'); setTimeout(() => {}, 8000);" };
    for (const [n, s] of Object.entries(FAKE)) fs.writeFileSync(path.join(tmp, n + '.mjs'), s + '\n');
    const timed = spawnSync('sh', ['-c', 'command -v timeout'], { encoding: 'utf8' }).status === 0;
    const r = spawnSync('sh', [path.join(tmp, 'run_tests.sh'), '--data'], { cwd: os.tmpdir(), encoding: 'utf8', env: { ...process.env, TEST_TIMEOUT: '2' }, timeout: 60000 }), out = r.stdout || '', has = re => re.test(out);
    ok(r.status === 1 && has(/^PASS test_a_pass \(\d+s\): fine$/m) && has(/^FAIL test_b_fail \(\d+s\): the reason$/m) && has(/^SKIP test_c_skip \(\d+s\): not here$/m) && has(timed ? /^run_tests\.sh: 1 passed, 2 failed, 1 skipped$/m : /^run_tests\.sh: 2 passed, 1 failed, 1 skipped$/m), 'run_tests.sh reports PASS, FAIL with the last line, SKIP for exit 77, the counts, and exits 1: ' + JSON.stringify(out.trim().split('\n')));
    ok(!timed || has(/^FAIL test_d_slow \([23]s\): timeout after 2s\b/m), 'and a test stopped by TEST_TIMEOUT=2 is a FAIL whose reason is "timeout after 2s": ' + (out.split('\n').find(l => /test_d_slow/.test(l)) || 'no line'));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); } }
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL PACKAGE TESTS PASS'); process.exit(bad ? 1 : 0);
