// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The atlas as the Young Learner reads it: 25 boxes x Spatial/Temporal x EN/IT, in plain words.
// No formulas, no technical vocabulary (very easy arithmetic only: a count, a small sum, a power of two), no "Audit:" notes; those stay for the
// Physicist and the Mathematician and, on the atlas page, inside the closed fold "For older readers". Applied last, for the Young Learner only,
// by getCompleteDualMetricDisplayData in matrixData.js. Every sentence is true of the audited data: the box Cl(p,q) has p "plus" switches
// (multiplied by itself a plus switch gives +1) and q "minus" switches (it gives -1), 2^(p+q) pieces, and the kind given by cliffordCell().
// A physical reading is always said to be a reading. The mirror (Temporal) text says that flipping the sign rule is bookkeeping: nothing runs
// backwards and nothing physical follows. test_story.mjs checks every record (both languages, both metrics) against the formula and jargon
// lists of test_yl_ui.mjs and checks that the hedged items keep their hedges; test_yl_atlas.mjs checks that every physical name in every record
// comes with a hedge, that the halves of the mirror box follow cliffordCell, and the counts 17 (one way of counting) and 16 × 16 (period 8).
import { AUDITED_ATLAS, cliffordCell } from './genesis_audit_v3.js';
// eight more switches bring the same kinds back: a grid of P8.N by P8.N squares with an old box in every square, P8.dim times as many pieces
const P8 = cliffordCell(8, 0), P0 = cliffordCell(0, 0), WIDE = P8.N / P0.N, MORE = P8.dim / P0.dim;

// Spatial texts: id -> { en: [title, subtitle, desc], it: [...] }
const SPATIAL = {
  Sector_Vacuum_Origin: {
    en: ['The Quiet Starting Point', 'No switches yet: only the number 1.', 'Before any switch is added there is just one piece: the number 1. Multiplying by 1 changes nothing. Every other box in the grid adds switches to this starting point. This part is checked.'],
    it: ['Il Punto di Partenza Silenzioso', 'Ancora nessun interruttore: solo il numero 1.', 'Prima di aggiungere qualsiasi interruttore c’è un solo pezzo: il numero 1. Moltiplicare per 1 non cambia nulla. Ogni altra scatola della griglia aggiunge interruttori a questo punto di partenza. Questa parte è verificata.'] },
  Sector_Inject_Base_Real: {
    en: ['The First Plus Switch', 'One switch that gives +1 when you multiply it by itself.', 'One switch that gives +1 when you multiply it by itself. Its box has 2 pieces and splits into two separate rooms that never mix, each with its own copy of the ordinary numbers.'],
    it: ['Il Primo Interruttore Più', 'Un interruttore che moltiplicato per sé stesso dà +1.', 'Un interruttore che moltiplicato per sé stesso dà +1. La sua scatola ha 2 pezzi e si divide in due stanze separate che non si mescolano mai, ciascuna con la sua copia dei numeri normali.'] },
  Sector_Inject_Fiber_Clock: {
    en: ['The Turning Switch', 'One switch that gives −1 when you multiply it by itself.', 'One switch that gives −1 when you multiply it by itself. Its box has 2 pieces and makes the numbers that can turn: multiplying by the switch is a quarter turn, so doing it twice makes you face the other way. Picturing it as a little clock hand is our idea.'],
    it: ['L’Interruttore che Gira', 'Un interruttore che moltiplicato per sé stesso dà −1.', 'Un interruttore che moltiplicato per sé stesso dà −1. La sua scatola ha 2 pezzi e crea i numeri che sanno girare: moltiplicare per l’interruttore è un quarto di giro, quindi farlo due volte ti fa guardare dall’altra parte. Immaginarlo come una piccola lancetta è una nostra idea.'] },
  Sector_Quaternionic_Base: {
    en: ['The Flat Floor Tile', 'Two plus switches, and a 2 by 2 grid of numbers.', 'Two plus switches make a box with 4 pieces. It works exactly like a 2 by 2 grid of ordinary numbers, and it can turn things in a flat plane. The famous four-part numbers live in a different box, the one with two minus switches.'],
    it: ['La Piastrella del Pavimento', 'Due interruttori più e una griglia di numeri 2 per 2.', 'Due interruttori più fanno una scatola con 4 pezzi. Funziona esattamente come una griglia 2 per 2 di numeri normali e sa far girare le cose in un piano. I famosi numeri a quattro parti stanno in un’altra scatola, quella con due interruttori meno.'] },
  Sector_Quaternionic_Fiber: {
    en: ['The Four-Part Numbers', 'Two minus switches make the famous four-part numbers.', 'Two minus switches make a box with 4 pieces: the four-part numbers that the mathematician Hamilton found long ago. They describe turns in space. In Furey’s model these numbers are used to build the weak force; reading this box as the weak force is an idea, not something the rule proves.'],
    it: ['I Numeri a Quattro Parti', 'Due interruttori meno fanno i famosi numeri a quattro parti.', 'Due interruttori meno fanno una scatola con 4 pezzi: i numeri a quattro parti che il matematico Hamilton scoprì tanto tempo fa. Descrivono i giri nello spazio. Nel modello di Furey questi numeri servono a costruire la forza debole; leggere questa scatola come la forza debole è un’idea, non qualcosa che la regola dimostra.'] },
  Sector_Trivector_Base: {
    en: ['The 3D Toy Box', 'Three plus switches: height, width and depth.', 'Three plus switches give a box with 8 pieces, like the three directions of a room: height, width and depth. The piece made of all three switches gives −1 when you multiply it by itself, so it works like a little turning number in the middle of the box.'],
    it: ['La Scatola dei Giochi in 3D', 'Tre interruttori più: altezza, larghezza e profondità.', 'Tre interruttori più danno una scatola con 8 pezzi, come le tre direzioni di una stanza: altezza, larghezza e profondità. Il pezzo fatto di tutti e tre gli interruttori, moltiplicato per sé stesso, dà −1, quindi funziona come un piccolo numero che gira al centro della scatola.'] },
  Sector_Trivector_Quark: {
    en: ['The Box That Splits in Two', 'Two plus switches and one minus switch.', 'Two plus switches and one minus switch give a box with 8 pieces. The piece made of all three switches gives +1 when you multiply it by itself, so the box splits into two matching halves that never talk to each other. Quark colours do not come out of this box.'],
    it: ['La Scatola che si Divide in Due', 'Due interruttori più e un interruttore meno.', 'Due interruttori più e un interruttore meno danno una scatola con 8 pezzi. Il pezzo fatto di tutti e tre gli interruttori, moltiplicato per sé stesso, dà +1, quindi la scatola si divide in due metà uguali che non si parlano mai. I colori dei quark non escono da questa scatola.'] },
  Sector_Trivector_Lepton: {
    en: ['The Lopsided Floor', 'One plus switch and two minus switches.', 'One plus switch and two minus switches give a box with 8 pieces, of the same kind as the 3D toy box: a 2 by 2 grid of turning numbers. Using this box for electrons is a reading; the rule does not prove it.'],
    it: ['Il Pavimento Sbilenco', 'Un interruttore più e due interruttori meno.', 'Un interruttore più e due interruttori meno danno una scatola con 8 pezzi, dello stesso tipo della scatola dei giochi in 3D: una griglia 2 per 2 di numeri che girano. Usare questa scatola per gli elettroni è una lettura; la regola non lo dimostra.'] },
  Sector_STA_Euclidean_Base: {
    en: ['The Four-Way Block', 'Four plus switches and no time at all.', 'Four plus switches give a block with 16 pieces: a 2 by 2 grid of four-part numbers. All four directions are of the same kind, so there is no time in it. The box with four minus switches, at the other end of the same row, is of the same kind.'],
    it: ['Il Blocco a Quattro Vie', 'Quattro interruttori più e nessun tempo.', 'Quattro interruttori più danno un blocco con 16 pezzi: una griglia 2 per 2 di numeri a quattro parti. Le quattro direzioni sono tutte dello stesso tipo, quindi dentro non c’è tempo. La scatola con quattro interruttori meno, all’altro capo della stessa riga, è dello stesso tipo.'] },
  Sector_STA_Minkowski: {
    en: ['Space and Time Together', 'Three plus switches and one minus switch.', 'Three plus switches and one minus switch give a box with 16 pieces: a 4 by 4 grid of ordinary numbers. Reading the three as space and the one as time gives the usual picture of space and time used for light and for fast motion. That picture is standard physics; which kind we call time is a choice.'],
    it: ['Spazio e Tempo Insieme', 'Tre interruttori più e un interruttore meno.', 'Tre interruttori più e un interruttore meno danno una scatola con 16 pezzi: una griglia 4 per 4 di numeri normali. Leggere i tre come spazio e l’uno come tempo dà la solita immagine di spazio e tempo usata per la luce e per i moti veloci. Questa immagine è fisica standard; quale tipo chiamiamo tempo è una scelta.'] },
  Sector_STA_Symmetric_Core: {
    en: ['The Crossroads', 'Two plus switches and two minus switches, perfectly balanced.', 'Two plus switches and two minus switches give a box with 16 pieces: a 4 by 4 grid of ordinary numbers. Of the six ways to pair the switches up, two pairs turn things around and four pairs stretch things instead. Calling it the heart of the weak force is only a reading.'],
    it: ['L’Incrocio', 'Due interruttori più e due interruttori meno, in perfetto equilibrio.', 'Due interruttori più e due interruttori meno danno una scatola con 16 pezzi: una griglia 4 per 4 di numeri normali. Dei sei modi di accoppiare gli interruttori, due coppie fanno girare le cose e quattro coppie invece le allungano. Chiamarla il cuore della forza debole è solo una lettura.'] },
  Sector_STA_Fiber_Frame: {
    en: ['The Mirror of Space and Time', 'One plus switch and three minus switches.', 'One plus switch and three minus switches give a box with 16 pieces: a 2 by 2 grid of four-part numbers. It is the mirror image of the space-and-time box: a sibling, not a copy, because the two boxes are of different kinds.'],
    it: ['Lo Specchio di Spazio e Tempo', 'Un interruttore più e tre interruttori meno.', 'Un interruttore più e tre interruttori meno danno una scatola con 16 pezzi: una griglia 2 per 2 di numeri a quattro parti. È l’immagine allo specchio della scatola di spazio e tempo: una sorella, non una copia, perché le due scatole sono di tipo diverso.'] },
  Sector_Row5_Base: {
    en: ['The Five-Switch Box', 'Four plus switches and one minus switch.', 'Four plus switches and one minus switch give a box with 32 pieces: a 4 by 4 grid of turning numbers. In nature the weak force treats left and right hands differently. That is a fact about nature; it does not come out of this box.'],
    it: ['La Scatola a Cinque Interruttori', 'Quattro interruttori più e un interruttore meno.', 'Quattro interruttori più e un interruttore meno danno una scatola con 32 pezzi: una griglia 4 per 4 di numeri che girano. In natura la forza debole tratta in modo diverso la mano destra e la sinistra. È un fatto della natura; non esce da questa scatola.'] },
  Sector_Row6_Confinement: {
    en: ['The Six-Switch Grid', 'Four plus switches and two minus switches.', 'Six switches give a box with 64 pieces: an 8 by 8 grid of ordinary numbers, the same kind as the balanced box with three plus and three minus switches. In nature quarks are always locked together, but this box does not explain why.'],
    it: ['La Griglia a Sei Interruttori', 'Quattro interruttori più e due interruttori meno.', 'Sei interruttori danno una scatola con 64 pezzi: una griglia 8 per 8 di numeri normali, dello stesso tipo della scatola in equilibrio con tre interruttori più e tre meno. In natura i quark stanno sempre chiusi insieme, ma questa scatola non spiega perché.'] },
  Sector_Row7_Mirror: {
    en: ['The Box with Two Halves', 'Seven switches, and a box that splits in two.', 'Four plus switches and three minus switches give a box with 128 pieces. The piece made of all seven switches gives +1 when you multiply it by itself, so the box splits into two identical halves. One way to read the two halves is matter and antimatter; that is a reading, not a result. The same kind of split happens in other boxes too.'],
    it: ['La Scatola dalle Due Metà', 'Sette interruttori e una scatola che si divide in due.', 'Quattro interruttori più e tre interruttori meno danno una scatola con 128 pezzi. Il pezzo fatto di tutti e sette gli interruttori, moltiplicato per sé stesso, dà +1, quindi la scatola si divide in due metà identiche. Un modo di leggere le due metà è materia e antimateria; è una lettura, non un risultato. Lo stesso tipo di divisione avviene anche in altre scatole.'] },
  Sector_Chiral_Parity: {
    en: ['The Hidden Clock Hand', 'Two plus switches and three minus switches.', 'Two plus switches and three minus switches give a box with 32 pieces, of the same kind as the five-switch box: a 4 by 4 grid of turning numbers. The piece made of all five switches gives −1 when you multiply it by itself, like a hidden clock hand in the middle. Why left and right hands behave differently in nature does not come out of this box.'],
    it: ['La Lancetta Nascosta', 'Due interruttori più e tre interruttori meno.', 'Due interruttori più e tre interruttori meno danno una scatola con 32 pezzi, dello stesso tipo della scatola a cinque interruttori: una griglia 4 per 4 di numeri che girano. Il pezzo fatto di tutti e cinque gli interruttori, moltiplicato per sé stesso, dà −1, come una lancetta nascosta al centro. Perché in natura destra e sinistra si comportino in modo diverso non esce da questa scatola.'] },
  Sector_EM_Maxwell: {
    en: ['Light as One Equation', 'Light, with a push part and a twist part.', 'Light is a wave made of numbers: electric pushes and magnetic twists. With one line of space there is just one push. With three lines of space there are three pushes and three twists. The page “Calibration 1 · Maxwell” lets you add space and extra time one step at a time and shows every piece. This is standard physics, written with our switches.'],
    it: ['La Luce come Una Sola Equazione', 'La luce, con una parte di spinta e una di torsione.', 'La luce è un’onda fatta di numeri: spinte elettriche e torsioni magnetiche. Con una sola linea di spazio c’è una sola spinta. Con tre linee di spazio ci sono tre spinte e tre torsioni. La pagina «Calibration 1 · Maxwell» ti fa aggiungere spazio e tempo in più un passo alla volta e mostra ogni pezzo. È fisica standard, scritta con i nostri interruttori.'] },
  Sector_Gravity_Strain: {
    en: ['The Big Squeeze', 'Paths get shorter near heavy things: an idea we try.', 'Near heavy things, paths in space and time get squeezed: that is real physics, and there is a known way to write it with the same kind of numbers. Linking it to our grid of switches is an idea we try; the switch rule does not prove it.'],
    it: ['Il Grande Schiacciamento', 'Vicino alle cose pesanti i percorsi si accorciano: un’idea che proviamo.', 'Vicino alle cose pesanti i percorsi nello spazio e nel tempo si schiacciano: è fisica vera, e c’è un modo noto di scriverla con lo stesso tipo di numeri. Legarla alla nostra griglia di interruttori è un’idea che proviamo; la regola degli interruttori non lo dimostra.'] },
  Sector_Baryon_Conservation: {
    en: ['The Counting Lock', 'Keeping a count of building blocks: an open idea.', 'In nature the number of protons and neutrons almost never changes, but tiny exceptions are allowed. A toy rule says “count the building blocks and keep the count”. The grid does not prove such a rule; only the box itself, with five plus and three minus switches, is checked.'],
    it: ['Il Lucchetto del Conteggio', 'Tenere il conto dei mattoncini: un’idea aperta.', 'In natura il numero di protoni e neutroni non cambia quasi mai, ma sono ammesse piccolissime eccezioni. Una regola giocattolo dice «conta i mattoncini e mantieni il conto». La griglia non dimostra una regola così; è verificata solo la scatola stessa, con cinque interruttori più e tre meno.'] },
  Sector_Electroweak_Unified: {
    en: ['The Balanced Gearbox', 'Four plus switches and four minus switches, and a way of counting.', 'Four plus switches and four minus switches give a box with 256 pieces, perfectly balanced. One way of counting gives 17 neutral paths inside it. It is a way of counting that we chose, not a result: nothing in the rule fixes it, and the real weak interaction is not derived here. The box itself is checked.'],
    it: ['L’Ingranaggio in Equilibrio', 'Quattro interruttori più e quattro meno, e un modo di contare.', 'Quattro interruttori più e quattro interruttori meno danno una scatola con 256 pezzi, in perfetto equilibrio. Un modo di contare dà 17 percorsi neutri al suo interno. È un modo di contare che abbiamo scelto noi, non un risultato: niente nella regola lo fissa, e la vera interazione debole non è ricavata qui. La scatola stessa è verificata.'] },
  Sector_Vacuum_Mass_Generation: {
    en: ['The Invisible Origin Key', 'A quiet starting point, and a guess about what it might become.', 'Multiplying by the number 1 changes nothing, so it can sit quietly in the background. One idea in the toy model reads that quiet 1 as a ghostly particle (a sterile neutrino) and, when it acts, as the Higgs field that gives matter its weight. That is only a reading: the rules do not produce either one, and they do not give any weights. Nobody knows yet.'],
    it: ['La Chiave d’Origine Invisibile', 'Un punto di partenza silenzioso e un’ipotesi su ciò che potrebbe diventare.', 'Moltiplicare per il numero 1 non cambia nulla, quindi può restare tranquillo sullo sfondo. Un’idea del modello giocattolo legge quell’1 silenzioso come una particella fantasma (un neutrino sterile) e, quando agisce, come il campo di Higgs che dà peso alla materia. È solo una lettura: le regole non producono né l’uno né l’altro e non danno nessun peso. Nessuno lo sa ancora.'] },
  Sector_GUT_Junction: {
    en: ['The Crowded Knot', 'A number that keeps showing up, and an open question.', 'Some readings say that everything meets at the number 210, which is 2 × 3 × 5 × 7. But our boxes only grow by doubling (2, 4, 8, 16 and so on), so 3, 5 and 7 never come out of them. Whether 210 means anything is an open question. The box itself, with two plus and six minus switches, is checked.'],
    it: ['Il Nodo Affollato', 'Un numero che ritorna, e una domanda aperta.', 'Alcune letture dicono che tutto si incontra al numero 210, che è 2 × 3 × 5 × 7. Ma le nostre scatole crescono solo raddoppiando (2, 4, 8, 16 e così via), quindi 3, 5 e 7 non ne escono mai. Se 210 voglia dire qualcosa è una domanda aperta. La scatola stessa, con due interruttori più e sei meno, è verificata.'] },
  Sector_Cosmic_Horizon: {
    en: ['The Last Switch', 'All eight switches on, and then the same kinds of box come around again.', `Turn all eight switches on and you reach the biggest block, with ${P8.dim} pieces. It is not a wall. The same kinds of box simply come around again: eight more switches give the old kind of box once more, as a grid of ${WIDE} by ${WIDE} squares with an old box in every square, so ${MORE} times as many pieces.`],
    it: ['L’Ultimo Interruttore', 'Tutti gli otto interruttori accesi, e poi gli stessi tipi di scatola tornano.', `Accendi tutti e otto gli interruttori e arrivi al blocco più grande, con ${P8.dim} pezzi. Non è un muro. Gli stessi tipi di scatola tornano semplicemente: otto interruttori in più danno di nuovo il vecchio tipo di scatola, come una griglia di ${WIDE} per ${WIDE} caselle con una vecchia scatola in ogni casella, quindi ${MORE} volte più pezzi.`] },
  Sector_Open_Questions: {
    en: ['Cracks in the Toy Box', 'What the rules cannot do yet.', 'Every model has cracks, and here are ours. The rules give no weights at all: no particle mass comes out of them. The box sizes only double (1, 2, 4, 8 and so on), so the numbers 3, 5 and 7 never come out of them. The number 210 is not explained, why there are three families is not explained, and nobody has shown where the heaviest quark belongs in the grid. These questions are open.'],
    it: ['Crepe nella Scatola dei Giochi', 'Ciò che le regole non sanno ancora fare.', 'Ogni modello ha le sue crepe, e queste sono le nostre. Le regole non danno nessun peso: da esse non esce la massa di nessuna particella. Le grandezze delle scatole raddoppiano soltanto (1, 2, 4, 8 e così via), quindi i numeri 3, 5 e 7 non ne escono mai. Il numero 210 non è spiegato, perché ci siano tre famiglie non è spiegato, e nessuno ha mostrato dove stia nella griglia il quark più pesante. Queste domande sono aperte.'] },
  Sector_Furey_Ledger: {
    en: ['Furey’s Block Grid', 'A filing system for one family of particles.', 'A grid of 16 by 16 boxes is cut into blocks of sizes 2, 6, 4, 2, 1 and 1. A special key joins the last two tiny blocks into one, and the grid becomes 8 by 8 with blocks 1, 3, 2, 1 and 1. The boxes between the blocks are where the particles live. It is a clever filing system from a published paper, and it does not say where the missing heavy quark goes.'],
    it: ['La Griglia a Blocchi di Furey', 'Un sistema di archiviazione per una famiglia di particelle.', 'Una griglia di 16 per 16 caselle è tagliata in blocchi di dimensioni 2, 6, 4, 2, 1 e 1. Una chiave speciale unisce gli ultimi due blocchi minuscoli in uno, e la griglia diventa 8 per 8 con blocchi 1, 3, 2, 1 e 1. Le caselle tra i blocchi sono dove vivono le particelle. È un ingegnoso sistema di archiviazione da un articolo pubblicato, e non dice dove vada il quark pesante che manca.'] },
};

// One more sentence for the mirror reading of some boxes, so that a hedge of the Spatial text is not lost in the mirror.
const MIRROR_EXTRA = {
  Sector_Quaternionic_Fiber: ['Reading this box as the weak force is still only an idea.', 'Leggere questa scatola come la forza debole resta solo un’idea.'],
  Sector_Trivector_Quark: ['Quark colours still do not come out of it.', 'I colori dei quark continuano a non uscirne.'],
  Sector_Trivector_Lepton: ['Using this box for electrons is still only a reading.', 'Usare questa scatola per gli elettroni resta solo una lettura.'],
  Sector_STA_Minkowski: ['Which kind we call time is only a choice.', 'Quale tipo chiamiamo tempo è solo una scelta.'],
  Sector_EM_Maxwell: ['Which kind we call time is only a choice, and the equation of light does not come out of the flip.', 'Quale tipo chiamiamo tempo è solo una scelta, e l’equazione della luce non esce dallo scambio.'],
  Sector_Gravity_Strain: ['No law of gravity comes out of the flip.', 'Dallo scambio non esce nessuna legge della gravità.'],
  Sector_STA_Symmetric_Core: ['Only the two turning pairs swap places.', 'Solo le due coppie che girano si scambiano di posto.'],
  Sector_Row5_Base: ['Why the weak force treats left and right differently still does not come out of it.', 'Perché la forza debole tratti in modo diverso destra e sinistra continua a non uscirne.'],
  Sector_Chiral_Parity: ['Swapping plus and minus is not the same as swapping left and right.', 'Scambiare più e meno non è la stessa cosa che scambiare destra e sinistra.'],
  Sector_Row6_Confinement: ['Why quarks stay locked together still does not come out of it.', 'Perché i quark restino chiusi insieme continua a non uscirne.'],
  Sector_Row7_Mirror: ['So the split into two halves belongs to the box with four plus switches, not to a direction of time; reading those halves as matter and antimatter is still a reading, not a result.', 'Quindi la divisione in due metà appartiene alla scatola con quattro interruttori più, non a una direzione del tempo; leggere quelle metà come materia e antimateria resta una lettura, non un risultato.'],
  Sector_Baryon_Conservation: ['No counting law comes out of the flip.', 'Dallo scambio non esce nessuna legge del conteggio.'],
  Sector_Electroweak_Unified: ['One way of counting gives 17 neutral paths; it is still a way of counting that we chose, and the real weak interaction is not derived here.', 'Un modo di contare dà 17 percorsi neutri; resta un modo di contare che abbiamo scelto noi, e la vera interazione debole non è ricavata qui.'],
  Sector_Vacuum_Mass_Generation: ['A box with no switches has no sign to flip, and no weight for matter comes out of it.', 'Una scatola senza interruttori non ha segni da scambiare, e non ne esce nessun peso per la materia.'],
  Sector_GUT_Junction: ['The number 210 still does not come out of the boxes.', 'Il numero 210 continua a non uscire dalle scatole.'],
  Sector_Cosmic_Horizon: ['No edge of the universe comes out of it.', 'Non ne esce nessun bordo dell’universo.'],
  Sector_Furey_Ledger: ['The blocks of the grid depend only on the box, so they are the same in both readings.', 'I blocchi della griglia dipendono solo dalla scatola, quindi sono gli stessi nelle due letture.'],
};
const BOOK = ['Flipping the sign rule is only bookkeeping: nothing runs backwards, and nothing new about the real world follows from it.', 'Scambiare la regola dei segni è solo contabilità: nulla va all’indietro, e non ne segue nulla di nuovo sul mondo reale.'];
const OPEN_MIRROR = ['Swapping plus and minus does not close any crack. The rules still give no weights, the box sizes still only double, and where the heaviest quark belongs is still open.', 'Scambiare più e meno non chiude nessuna crepa. Le regole continuano a non dare nessun peso, le grandezze delle scatole continuano solo a raddoppiare, e dove stia il quark più pesante è ancora aperto.'];

const CELL = Object.fromEntries(AUDITED_ATLAS.map(([id, , status, p, q]) => [id, { status, p, q }]));
export const halves = c => /2$/.test(c.kind);
const HALVES = [
  { notMirror: 'The mirror box does not come in two halves.', onlyMirror: 'The mirror box comes in two halves, and the box itself does not.', both: 'The mirror box comes in two halves too.', '': '' },
  { notMirror: 'La scatola allo specchio non si divide in due metà.', onlyMirror: 'La scatola allo specchio si divide in due metà, e la scatola stessa no.', both: 'Anche la scatola allo specchio si divide in due metà.', '': '' },
];
const L = lang => (lang === 'it' ? 1 : 0);
// "the 3 plus switches become minus and the one minus switch becomes plus"
function swapWords(p, q, lang) {
  const en = (k, from, to) => (k === 1 ? `the one ${from} switch becomes ${to}` : `the ${k} ${from} switches become ${to}`);
  const it = (k, from, to) => (k === 1 ? `l’unico interruttore ${from} diventa ${to}` : `${k === 8 ? 'gli' : 'i'} ${k} interruttori ${from} diventano ${to}`);
  const f = lang === 'it' ? it : en, P = lang === 'it' ? ['più', 'meno'] : ['plus', 'minus'];
  return [p ? f(p, P[0], P[1]) : null, q ? f(q, P[1], P[0]) : null].filter(Boolean).join(lang === 'it' ? ' e ' : ' and ');
}
const pieces = (n, lang) => (n === 1 ? (lang === 'it' ? '1 pezzo' : '1 piece') : `${n} ${lang === 'it' ? 'pezzi' : 'pieces'}`);
function mirrorText(id, lang) {
  const i = L(lang), c = CELL[id];
  if (!c || c.p === null) return OPEN_MIRROR[i] + ' ' + BOOK[i];
  const { p, q } = c, n = p + q, a = cliffordCell(p, q), m = cliffordCell(q, p);
  const head = lang === 'it' ? 'Nella lettura allo specchio gli interruttori più e meno si scambiano il nome' : 'In the mirror reading, plus switches and minus switches swap names';
  if (n === 0) return [lang === 'it' ? `${head}. Questa scatola non ha interruttori, quindi non cambia nulla: è ancora soltanto il numero 1.` : `${head}. This box has no switches at all, so nothing changes: it is still the number 1 alone.`, MIRROR_EXTRA[id]?.[i], BOOK[i]].filter(Boolean).join(' ');
  const kind = p === q ? (lang === 'it' ? 'La scatola è l’immagine allo specchio di sé stessa: resta identica.' : 'The box is its own mirror image: it looks exactly the same.')
    : a.algebra === m.algebra ? (lang === 'it' ? 'La scatola allo specchio è un’altra scatola, ma dello stesso tipo.' : 'The mirror box is a different box, but of the same kind.')
    : (lang === 'it' ? 'La scatola allo specchio è di un tipo diverso.' : 'The mirror box is of a different kind.');
  const keep = lang === 'it' ? `La scatola ha sempre ${pieces(a.dim, 'it')}.` : `The box still has ${pieces(a.dim, 'en')}.`;
  // whether the box and its mirror come in two halves is read from cliffordCell (a kind ending in 2 is a sum of two equal blocks), never typed
  const half = HALVES[i][halves(a) === halves(m) ? (halves(a) && p !== q ? 'both' : '') : halves(a) ? 'notMirror' : 'onlyMirror'];
  return [`${head}: ${swapWords(p, q, lang)}.`, keep, kind, half, MIRROR_EXTRA[id]?.[i], BOOK[i]].filter(Boolean).join(' ');
}

// the plain captions the atlas page prints for a box: its place in the grid and one line per way of looking (Switches, Doubling, Triangles, Cube)
const times2 = n => Array.from({ length: n }, () => '2').join(' × ');
export function ylCaptions(id, lang, metric = 'Spatial') {
  const c = CELL[id], it = lang === 'it';
  if (!c || c.p === null) { const t = it ? 'nessuna scatola: domande aperte' : 'no box: open questions'; return { place: it ? 'domande aperte' : 'open questions', Clifford: t, Prime: t, Simplex: t, Cube: t }; }
  const { p, q } = c, n = p + q, dim = 2 ** n, [pp, qq] = metric === 'Temporal' ? [q, p] : [p, q];
  const pm = (x, y) => (it ? `${x} più · ${y} meno` : `${x} plus · ${y} minus`);
  return {
    place: pm(p, q),
    Clifford: pm(pp, qq) + (metric === 'Temporal' ? (it ? ' (allo specchio)' : ' (mirror)') : ''),
    Prime: n === 0 ? (it ? '1 pezzo, ancora nessun raddoppio' : '1 piece, no doubling yet') : `${times2(n)} = ${pieces(dim, lang)}`,
    Simplex: [it ? 'ancora nessun vertice' : 'no corners yet', it ? 'un solo punto' : 'a single dot', it ? 'una linea con 2 vertici' : 'a line with 2 corners', it ? 'un triangolo con 3 vertici' : 'a triangle with 3 corners', it ? 'una piramide con 4 vertici' : 'a pyramid with 4 corners'][n] || (it ? `${n} vertici, ogni coppia unita da uno spigolo` : `${n} corners, every two joined by an edge`),
    Cube: n === 0 ? (it ? 'un solo vertice' : 'a single corner') : (it ? `${dim} vertici, uno per ogni pezzo` : `${dim} corners, one for each piece`),
  };
}
// what the picture of the active box shows, in plain words (the formal legend of the picture is in the fold)
export function ylPictureCaption(id, view, lang, metric = 'Spatial') {
  const it = lang === 'it', c = CELL[id];
  if (!c || c.p === null) return it ? 'Tutti i posti della griglia. Gli anelli rossi segnano i posti dove persone diverse hanno provato a mettere il quark più pesante; nessuna di queste ipotesi è dimostrata.' : 'All the places of the grid. The red rings mark the places where different people have tried to put the heaviest quark; none of these guesses is proven.';
  const n = c.p + c.q, mirror = metric === 'Temporal' ? (it ? ' Questa è l’immagine allo specchio: più e meno si sono scambiati.' : ' This is the mirror picture: plus and minus have swapped.') : '';
  if (view === 'Clifford' && id === 'Sector_Furey_Ledger' && metric !== 'Temporal') return it ? 'Una griglia di 16 per 16 caselle. I quadrati colorati lungo la diagonale sono i blocchi; le caselle scure tra di loro sono dove stanno le particelle nel modello di Furey.' : 'A grid of 16 by 16 boxes. The coloured squares along the middle line are the blocks; the dark boxes between them are where the particles sit in Furey’s model.';
  if (n === 0) return it ? 'Ancora nessun interruttore, quindi l’immagine è quasi vuota: c’è solo il numero 1.' : 'There are no switches yet, so the picture is almost empty: just the number 1.';
  const t = {
    Clifford: it ? 'Ogni punto è un interruttore, colorato secondo il suo tipo: più o meno. Ogni coppia di interruttori è unita da una linea: dorata se i due sono dello stesso tipo, blu se no. Il segno al centro è il pezzo fatto di tutti gli interruttori insieme.' : 'Each dot is a switch, coloured by its kind: plus or minus. Every two switches are joined by a line: gold when the two are of the same kind, blue when they are not. The mark in the middle is the piece made of all the switches together.',
    Prime: it ? 'Anello dopo anello, il numero di punti raddoppia: 1, 2, 4, 8 e così via, un anello per ogni interruttore. Succede solo il raddoppio, quindi i numeri 3, 5 e 7 non compaiono mai.' : 'Ring after ring, the number of dots doubles: 1, 2, 4, 8 and so on, one ring for each switch. Only doubling happens, so the numbers 3, 5 and 7 never appear.',
    Simplex: it ? 'Ogni interruttore è un vertice. Ogni coppia di vertici è unita da uno spigolo, e ogni tre vertici formano un triangolo trasparente.' : 'Each switch is a corner. Every two corners are joined by an edge, and every three make a see-through triangle.',
    Cube: it ? 'Ogni vertice di questo cubo a più direzioni è un pezzo. Un passo lungo uno spigolo gira un interruttore. I vertici chiari sono i pezzi che, moltiplicati per sé stessi, danno +1; quelli scuri danno −1.' : 'Each corner of this many-direction cube is one piece. A step along an edge flips one switch. Bright corners are pieces that give +1 when you multiply them by themselves; dark corners give −1.',
  }[view] || '';
  return t + mirror;
}
// the four ways of looking at a box under the names the Young Learner reads on the controls of the atlas page (the picture is named with them)
export const YL_VIEW_NAMES = { en: { Clifford: 'Switches', Prime: 'Doubling', Simplex: 'Triangles', Cube: 'Cube' }, it: { Clifford: 'Interruttori', Prime: 'Raddoppi', Simplex: 'Triangoli', Cube: 'Cubo' } };
// the words beside the badges of a cell card, in plain words: what each badge covers (the kind of the box; its name), the badge itself says how sure we are
export const YL_STATUS = {
  en: { verified: 'the kind of this box', realigned: 'the kind of this box; its labels and coordinates are a choice', name: 'the name we give this box is our own idea', speculative: 'a guess or an open question, not a result' },
  it: { verified: 'the kind of this box', realigned: 'the kind of this box; its labels and coordinates are a choice', name: 'the name we give this box is our own idea', speculative: 'un’ipotesi o una domanda aperta, non un risultato' },
};

// the Young Learner record: title, subtitle and desc in plain words, plus the plain captions; nothing else of the record changes
export function ylRecord(id, lang, metric = 'Spatial') {
  const s = SPATIAL[id]; if (!s) return null;
  const i = L(lang), [title, subtitle, desc] = s[lang === 'it' ? 'it' : 'en'];
  if (metric !== 'Temporal') return { title, subtitle, desc };
  return { title: lang === 'it' ? `${title} allo specchio` : `${title} in the mirror`, subtitle: lang === 'it' ? 'La stessa scatola con più e meno scambiati: solo contabilità.' : 'The same box with plus and minus swapped: only bookkeeping.', desc: mirrorText(id, lang) };
}
export const YL_ATLAS_IDS = Object.keys(SPATIAL);
export function applyYoungLearner(id, lang, profile, metric, rec) {
  if (profile !== 'Young Learner' || !rec) return rec;
  const y = ylRecord(id, lang, metric);
  return y ? { ...rec, ...y, yl: ylCaptions(id, lang, metric) } : rec;
}
