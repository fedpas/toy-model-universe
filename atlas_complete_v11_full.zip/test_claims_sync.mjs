// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_claims_sync.mjs: the 760 statements of the claims table (the 270 audited ones, the 98 input lines of the needs strips and the 392 of the Lenses page) (claimsData.js) are exactly what the pages' copy modules say.
// claimsLocators.json points each statement (and each line of a split statement), in English and Italian, at its text and its flags in the
// copy files; make_claims_data.mjs resolves them; this test regenerates the table and compares it with the shipped claimsData.js, then checks the
// audit rules: five flags only (standard, checked, ours, open, input), a statement tagged ours says nothing like "derived", known ground means standard and checked and none of ours, open, input.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { buildClaims, FLAG_NAMES } from './make_claims_data.mjs';
import { stepNo } from './steps.js';
const HERE = path.dirname(fileURLToPath(import.meta.url));
let fails = 0, checks = 0; const ok = (c, m) => { checks++; if (!c) { fails++; console.log('FAIL ' + m); } };
const claims = await buildClaims(), shipped = (await import('./claimsData.js')).CLAIMS;
ok(FLAG_NAMES.join() === 'standard,checked,ours,open,input', 'the five flags are standard, checked, ours, open, input');
ok(claims.length === 760 && new Set(claims.map(c => c.id)).size === 760, 'the table holds 760 distinct statements');
ok(JSON.stringify(claims) === JSON.stringify(shipped), 'claimsData.js equals what the locators resolve to (run: node make_claims_data.mjs)');
const GROUPS = { ATL: 25, GEN: 9, FUR: 5, PAG: 34, LAB: 20, EQN: 20, SHP: 6, GOS: 4, CPL: 10, YM: 8, MAT: 8, GRV: 12, MIR: 6, PRJ: 6, NUL: 11, FRQ: 5, SPN: 5, SPR: 4, RIG: 6, MAP: 35, RSN: 31, INP: 98, LNP: 4, LNC: 134, LNB: 143, LNS: 111 };   // the first 21 groups are the 270 audited statements; INP holds the 98 input lines of the needs strips; LNP, LNC, LNB and LNS are the Lenses page (steps 17-20: its strip and the three chapters, text and widgets): 270 + 98 + 392 = 760
for (const [g, n] of Object.entries(GROUPS)) ok(claims.filter(c => c.group === g).length === n, `group ${g} has ${n} statements`);
// where the lines' flags differ from the audit's merged flags on purpose (each reason recorded here)
const EXCEPT = {
  'ATL-024': 'split into an open list (ours, open) and the standard classification sentence (standard, checked): the union is shown',
  'PAG-006': 'two lines: the textbook identifications (standard) and the readings (ours, open): the audit copy lists the readings only',
  'PAG-029': 'one strip entry: scripts plus the textbook curvature counts: checked and standard',
  'LAB-013': 'same strip entry as PAG-029',
  'PAG-031': 'one strip entry: theorem part standard, readings ours: union',
  'LAB-015': 'same strip entry as PAG-031',
  'GRV-001': 'split into a theorem line (standard, checked) and a reading line (ours): union',
  'ATL-020': 'split (6 Oct verification) into a theorem line (standard, checked) and a reading line (ours, open): union',
  'RSN-018': 'split into a counts line (standard, checked: the dimensions are textbook, 6 Oct verification) and a reading line (ours): union',
  'MAP-010': 'standard dropped after the 6 Oct verification: a computed finding and an open item, no textbook statement behind it',
};
for (const id of ['EQN-007', 'EQN-009', 'EQN-010', 'EQN-011', 'EQN-015', 'EQN-016', 'EQN-017', 'EQN-018', 'EQN-019']) EXCEPT[id] = 'tally row (navigation): keeps the tags it had; never filtered';
// the statements of the tally rows keep their step: EQN-006 .. EQN-020 are the rows of Maxwell and of fourteen steps; the tally rows are positional (rows[i] is the row of TALLY_IDS[i]), the locators follow the step to its row,
// so each statement names its own step by number (the gauge row, step 12, is a row of the tally that has no statement of its own)
{ const SUBJECT = ['maxwell', 'comm', 'dirac', 'coupling', 'ym', 'matter', 'grav1', 'grav2', 'mirrors', 'projective', 'forque', 'spin', 'spring', 'rigid', 'nullsurf'];
  SUBJECT.forEach((id, i) => { const c = claims.find(x => x.id === 'EQN-' + String(i + 6).padStart(3, '0'));
    ok(c && c.tally === true && c.en.length === 1 && c.it && c.it.length === 1, `tally statement ${c && c.id}: one line in both languages`);
    if (id === 'maxwell') ok(c.en[0].text.startsWith('\u2207F = J (Maxwell)'), `tally statement ${c.id}: the row of Maxwell`);
    else { const n = stepNo('eq', id); ok(c.en[0].text.includes(` \u00b7 step ${n};`) && c.it[0].text.includes(` \u00b7 passo ${n};`), `tally statement ${c.id}: the row of step ${n} (${id}): ${c.en[0].text.slice(0, 50)}`); } }); }
let diff = 0;
for (const c of claims) {
  if (c.frozen) { ok(c.en.length === 1 && c.known === false, `${c.id}: frozen genesis row is listed, never known ground`); continue; }
  ok(c.en.length >= 1, `${c.id}: has a line`);
  for (const lang of ['en', 'it']) for (const x of c[lang] || []) {
    ok(typeof x.text === 'string' && x.text.length > 3, `${c.id} ${lang}: text`);
    ok(x.flags.every(f => FLAG_NAMES.includes(f)) && new Set(x.flags).size === x.flags.length, `${c.id} ${lang}: five flags only`);
    if (x.flags.includes('ours') && !x.notShown) ok(!/\bderiv(ed|ation)\b/i.test(x.text) || /not derived|nothing is derived|is not a derivation|none of them is a derivation/i.test(x.text), `${c.id} ${lang}: a line tagged ours says nothing like "derived": ${x.text.slice(0, 80)}`);
    ok(x.known === (x.flags.includes('standard') && x.flags.includes('checked') && !x.flags.includes('ours') && !x.flags.includes('open') && !x.flags.includes('input')), `${c.id} ${lang}: known ground is standard and checked, none of ours, open, input`);
    if (x.flags.includes('input')) ok(x.known === false, `${c.id} ${lang}: a line tagged input is never known ground`);
  }
  if (c.it) ok(c.it.length === c.en.length && c.it.every((x, i) => x.label === c.en[i].label && x.flags.join() === c.en[i].flags.join()), `${c.id}: Italian lines carry the same labels and flags as the English ones`);
  if (c.group !== 'RSN' && c.id !== 'EQN-005') ok(c.it !== null, `${c.id}: has Italian text`);
  const a = c.flags.join(), b = c.flagsSpec.join();
  if (a !== b) { diff++; ok(!!EXCEPT[c.id], `${c.id}: lines carry ${a}, the audit says ${b}: record the reason in EXCEPT`); }
  else ok(!EXCEPT[c.id] || /tally/.test(EXCEPT[c.id]), `${c.id}: no exception needed`);
  if (c.known) ok(c.flags.includes('standard') && c.flags.includes('checked'), `${c.id}: known ground claim`);
  // X3: a checked tag needs a check that runs: a statement tagged checked never says that no script runs it
  if (c.flags.includes('checked')) ok(!/^none\b/i.test(c.checkedBy || ''), `${c.id}: carries checked, so its checkedBy names a check (${(c.checkedBy || '').slice(0, 60)})`);
}
// ATL-018 (the frame strain): the theorem line is textbook linear algebra and no core-check row computes it, so it carries standard only
{ const a = claims.find(c => c.id === 'ATL-018'); ok(a && JSON.stringify(a.flags) === JSON.stringify(['standard', 'ours', 'open']) && a.en[0].label === 'theorem' && JSON.stringify(a.en[0].flags) === JSON.stringify(['standard']) && JSON.stringify(a.it[0].flags) === JSON.stringify(['standard']) && !a.known, 'ATL-018: the theorem line is tagged standard only, the reading line ours and open');
  ok(!JSON.stringify(a.en.concat(a.it)).includes('"checked"') && /check_T17\.py/.test(a.checkedBy) && !/no script runs it/.test(a.checkedBy), 'ATL-018: no checked tag, and checkedBy names what runs'); }
// PAG-021 (the first line of the equations strip, "every step has a script that checks it with exact sums"): a checked statement wears the checked badge in the four strips (Young Learner and Physicist/Mathematician, English and Italian slots) and names the scripts of steps 2 to 16 that check it
{ const c = claims.find(x => x.id === 'PAG-021'), { STORY, STORY_YL } = await import('./storyCopy.js');
  ok(c && c.flags.join() === 'checked' && c.flagsSpec.join() === 'checked' && c.en[0].flags.join() === 'checked' && c.it[0].flags.join() === 'checked' && !/^see unit/.test(c.checkedBy), 'PAG-021: the statement carries the checked flag, and checkedBy names the scripts');
  for (const l of ['en', 'it']) ok(STORY[l].pages.equations.tags[0][0] === 'checked' && STORY_YL[l].pages.equations.tags[0][0] === 'checked', `${l}: the first line of the equations strip carries checked, for the Young Learner and for the other readers`);
  const have = new Set(); const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) e.isDirectory() ? walk(path.join(d, e.name)) : have.add(e.name); }; walk(path.join(HERE, 'selfcheck'));
  const named = c.checkedBy.match(/\b[a-z_]+\.py\b/g) || []; ok(named.length === 13 && named.every(f => have.has(f)), `PAG-021: the ${named.length} scripts it names are in the package (selfcheck/): ${named.filter(f => !have.has(f)).join(', ')}`); }
// the files that ship claims hold no e-mail address
for (const f of ['claimsData.js', 'claimsLocators.json', 'make_claims_data.mjs']) ok(!/[\w.+-]+@[\w-]+\.[\w.-]+|mailto:/i.test(fs.readFileSync(path.join(HERE, f), 'utf8')), `${f}: no e-mail address`);
const known = claims.filter(c => c.known).length, lines = claims.reduce((n, c) => n + c.en.filter(x => x.known).length, 0);
console.log(`${checks} checks, ${diff} statements differ from the audit's flags on purpose (listed), ${known} statements and ${lines} lines are known ground`);
console.log(fails ? `${fails} FAILURES` : 'ALL CLAIMS TESTS PASS'); process.exit(fails ? 1 : 0);
