// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Data test of selfcheck/core_check.py, the check script behind the core statements (ids core·B1 ... core·B17). No browser. Run: node test_core.mjs   (about 40 s: the script runs once, then nine sabotaged copies)
// 1. the data module (coreData.js), the embedded script (coreSelfcheckSource.js) and selfcheck/core.json agree with the script, which rebuilds the stored data (--compare), uses the standard library only and prints its verdict
// 2. the rows: exactly the ids the text cites, each tagged checked, each passing; every core·B id that any source of the package cites is a row of core.json
// 3. independent recomputation here, with a bit rule written again in JavaScript: the Z4 form w and the Gauss sum (B3), the top blade (B14), the isometry counts of Q and of (Q, pi) (B12), the determinant of E_n (B13), the Killing signatures (B16)
// 4. sabotage: nine copies of the script with one statement broken each (the mirror without the sign change, w without pi, a wrong grading group, a wrong Killing signature, a reversion that is the identity, a wrong top-blade rule, and three that break a case the ranges below claim: a null bivector in B5b, the rank at n = 4 with one plus generator in B10, the case n = 8 in B15) must each stop with a failing row of the intended id
// 5. the ranges that the text states are the ranges the script runs: the rows say r = 0, 1, 2 (B5b), r = 0 (B10, B10b), n = 2..8 (B15), and the clock line of the clock tab (labelsCopy.js, claim LAB-017) and the groups line (LAB-020) cite exactly those
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: the test runs from any folder
import { spawnSync } from 'node:child_process';
import K from './coreData.js';
import { CORE_PY } from './coreSelfcheckSource.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const SCRIPT = './selfcheck/core_check.py';
const py = (args, cwd) => spawnSync('python3', ['-I', ...args], { cwd, encoding: 'utf8', timeout: 120000 });

// ---- 1. files
const J = JSON.parse(fs.readFileSync('./selfcheck/core.json', 'utf8')), src = fs.readFileSync(SCRIPT, 'utf8');
ok(JSON.stringify(J) === JSON.stringify(K), 'data module equals selfcheck/core.json');
ok(CORE_PY === src, 'embedded script equals the file');
ok(/--compare/.test(CORE_PY) && /--write/.test(CORE_PY) && /ALL CORE CHECKS PASS/.test(CORE_PY), 'script interfaces: --write, --compare, the verdict line');
{ const imports = [...src.matchAll(/^\s*(?:import|from)\s+([\w.]+)/gm)].map(m => m[1].split('.')[0]), STD = new Set(['argparse', 'itertools', 'json', 'sys', 'fractions', 'math']);
  ok(imports.length > 0 && imports.every(x => STD.has(x)), 'the script imports the standard library only: ' + [...new Set(imports)].join(', '));
  ok(!/\bnumpy\b|\bscipy\b|\bsympy\b|\bmatplotlib\b/.test(src.replace(/^[\s\S]*?"""[\s\S]*?"""/, '')), 'no numpy, scipy, sympy or matplotlib in the code'); }
{ const r = py(['core_check.py', '--compare', 'core.json'], './selfcheck'), out = r.stdout || '';
  ok(r.status === 0, 'the script exits 0 (' + r.status + ') ' + (r.stderr || '').slice(0, 200));
  ok(new RegExp(`^${J.rows.length}/${J.rows.length} core checks hold\\.  ALL CORE CHECKS PASS$`, 'm').test(out) && J.rows.length === 25, 'it prints "25/25 core checks hold" and ALL CORE CHECKS PASS (the number changes only by adding rows)');
  ok(!/^FAIL/m.test(out), 'no FAIL line');
  ok(/stored data == rebuilt data/.test(out), 'the script rebuilds the stored data and it equals core.json');
  ok(J.rows.every(r => out.includes(`ok   ${r.id}  `)), 'every stored row has its ok line in the output'); }

// ---- 2. the rows
const IDS = ['B1', 'B2', 'B3', 'B4', 'B4b', 'B5', 'B5b', 'B5c', 'B6', 'B6b', 'B6c', 'B7', 'B7b', 'B8', 'B9', 'B10', 'B10b', 'B10c', 'B11', 'B12', 'B13', 'B14', 'B15', 'B16', 'B17'].map(x => 'core·' + x);
ok(JSON.stringify(K.rows.map(r => r.id)) === JSON.stringify(IDS), 'the rows are exactly ' + IDS.join(' ') + ': ' + K.rows.map(r => r.id).join(' '));
ok(K.rows.every(r => r.tag === 'checked' && r.ok === true && typeof r.text === 'string' && r.text.length > 60), 'every row is tagged checked, passes, and says what it computes');
ok(K.summary.rows === K.rows.length && K.summary.ok === K.rows.length, 'the summary counts the rows: ' + JSON.stringify(K.summary));
{ const ids = new Set(K.rows.map(r => r.id)), cited = new Map();
  const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => ['node_modules', 'dist', 'dist_real', '.git', 'test_logs', '__pycache__'].includes(e.name) ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
  for (const f of walk('.').filter(f => /\.(js|jsx|json)$/.test(f) && !/(^|\/)(core\.json|coreData\.js|coreSelfcheckSource\.js)$/.test(f))) { const t = fs.readFileSync(f, 'utf8'); for (const m of t.matchAll(/core·B\d+[a-z]?/g)) { if (!cited.has(m[0])) cited.set(m[0], []); cited.get(m[0]).push(f); } }
  const missing = [...cited.keys()].filter(i => !ids.has(i));
  ok(missing.length === 0, 'every core·B id that a source of the package cites is a row of core.json; missing: ' + missing.map(i => i + ' in ' + cited.get(i)[0]).join(', ')); }

{ const T = id => K.rows.find(r => r.id === id).text;
  ok(/every Cl\(p,q,r\) with r = 0, 1, 2 null generators, n <= 6/.test(T('core·B5b')), 'B5b states its range: every Cl(p,q,r) with r = 0, 1, 2 null generators, n <= 6');
  ok(/every non-degenerate Cl\(p,q\) \(r = 0\) with n <= 4/.test(T('core·B10')) && /every non-degenerate Cl\(p,q\) \(r = 0\) with n <= 4/.test(T('core·B10b')), 'B10 and B10b state their domain: every non-degenerate Cl(p,q) (r = 0) with n <= 4');
  ok(/\(n = 2\.\.8\)/.test(T('core·B15')), 'B15 states its range: n = 2..8');
  ok(/n <= 5/.test(T('core·B1')) && /n <= 6/.test(T('core·B2')) && /n <= 8 \(r = 0\)/.test(T('core·B3')) && /\(n <= 6\)/.test(T('core·B3')), 'B1 n <= 5, B2 n <= 6, B3 n <= 8 (r = 0) and n <= 6 for r = 1, 2');
  // the places of the page that cite the ranges (labelsCopy.js: the clock glance, the groups glance); both language slots hold the same English text
  const LAB = (await import('./labelsCopy.js')).default || (await import('./labelsCopy.js')).COPY;
  for (const l of ['en', 'it']) {
    const clock = LAB[l].tabs.clock.glance.tags.map(x => x[1]).find(x => /core·B1/.test(x)), groups = LAB[l].tabs.groups.glance.tags.map(x => x[1]).find(x => /core·B15/.test(x));
    ok(clock && /core·B1 for n ≤ 5, core·B2 for n ≤ 6, core·B3 for n ≤ 8; with r = 1, 2 null generators the Gauss sum is 2\^\{r\} times it, up to n ≤ 6/.test(clock), `${l}: the clock line gives the range of each of B1, B2, B3 as the script runs it`);
    ok(groups && /core·B15, n ≤ 8/.test(groups), `${l}: the groups line cites core·B15 for n ≤ 8, the range the script runs`);
  } }

// ---- 3. independent recomputation (a bit rule written again, with squares in {+1, -1, 0})
const pc = a => { let c = 0; while (a) { c += a & 1; a >>= 1; } return c; };
const sgn = (a, b, eps) => { let s = 1; for (let i = 0; i < eps.length; i++) { if ((a >> i & 1) && pc(b & ((1 << i) - 1)) % 2) s = -s; if ((a >> i & 1) && (b >> i & 1)) s *= eps[i]; } return s; };
const sig = (p, q, r = 0) => [...Array(p).fill(1), ...Array(q).fill(-1), ...Array(r).fill(0)];
const Qf = (a, eps) => sgn(a, a, eps) === -1 ? 1 : 0;
// B3: the Gauss sum of i^w over all blades is (1+i)^p (1-i)^q, for every cell up to n = 7
{ let all = true; const cmul = (x, y) => [x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0]], cpow = (x, k) => { let r = [1, 0]; for (let i = 0; i < k; i++) r = cmul(r, x); return r; }, I4 = [[1, 0], [0, 1], [-1, 0], [0, -1]];
  for (let nn = 1; nn <= 7; nn++) for (let p = 0; p <= nn; p++) { const q = nn - p, e = sig(p, q); let re = 0, im = 0;
    for (let a = 0; a < 1 << nn; a++) { const w = (pc(a) % 2 + 2 * Qf(a, e)) % 4; re += I4[w][0]; im += I4[w][1]; }
    const t = cmul(cpow([1, 1], p), cpow([1, -1], q)); if (re !== t[0] || im !== t[1]) all = false; }
  ok(all, 'B3 recomputed: the Gauss sum of i^w equals (1+i)^p (1-i)^q for all 36 cells up to n = 7'); }
// B5b: the square of the bivector e_i e_j is -eps_i eps_j for every Cl(p,q,r) with r = 0, 1, 2 null generators, n = 2..6 (the null cases are the point of the zero in the statement)
{ let all = true, count = 0, nullCases = 0;
  for (let nn = 2; nn <= 6; nn++) for (let r = 0; r <= 2; r++) for (let p = 0; p <= nn - r; p++) { const e = sig(p, nn - r - p, r);
    for (let i = 0; i < nn; i++) for (let j = 0; j < nn; j++) if (i !== j) { const b = (1 << i) | (1 << j), sq = sgn(b, b, e) + 0; count++; if (e[i] === 0 || e[j] === 0) nullCases++; if (sq !== -e[i] * e[j] + 0) all = false; } }
  ok(all && nullCases > 0, `B5b recomputed: the square of e_i e_j is -eps_i eps_j in ${count} (algebra, pair) cases with r = 0, 1, 2, ${nullCases} of them with a null generator`); }
// B14: the top blade of an odd-n algebra is central; it squares to +1 exactly when r = 0 and p - q = 1 mod 4, to -1 for the mirrors, to 0 when r >= 1
{ let all = true, count = 0;
  for (let nn = 1; nn <= 7; nn += 2) for (let r = 0; r <= nn; r++) for (let p = 0; p <= nn - r; p++) { const q = nn - r - p, e = sig(p, q, r), top = (1 << nn) - 1, sq = sgn(top, top, e), want = r ? 0 : (((p - q) % 4 + 4) % 4 === 1 ? 1 : -1);
    let central = true; for (let i = 0; i < nn; i++) if (sgn(top, 1 << i, e) !== sgn(1 << i, top, e)) central = false;
    if (!central || sq !== want || K.data.top_blade_square[`${p},${q},${r}`] !== sq) all = false; count++; }
  ok(all && count === Object.keys(K.data.top_blade_square).length, `B14 recomputed: the top blade of all ${count} algebras Cl(p,q,r), n = 1, 3, 5, 7, is central with the stored square`); }
// B12: the number of isometries of Q and of (Q, pi) on F_2^n, by listing every ordered basis image (n <= 4)
{ const count = (e, keepPi) => { const nn = e.length, N = 1 << nn, Q = Array.from({ length: N }, (_, a) => Qf(a, e)); let c = 0, T = [];
    const rec = i => { if (i === nn) { const img = new Array(N).fill(0); for (let a = 0; a < N; a++) { let v = 0; for (let k = 0; k < nn; k++) if (a >> k & 1) v ^= T[k]; img[a] = v; }
      if (new Set(img).size !== N) return; for (let a = 0; a < N; a++) { if (Q[img[a]] !== Q[a]) return; if (keepPi && pc(img[a]) % 2 !== pc(a) % 2) return; } c++; return; }
      for (let v = 0; v < N; v++) { if (Q[v] !== Q[1 << i]) continue; if (keepPi && pc(v) % 2 !== 1) continue; T[i] = v; rec(i + 1); } };
    rec(0); return c; };
  let all = true, cells = 0; for (let nn = 2; nn <= 4; nn++) for (let p = 0; p <= nn; p++) { const e = sig(p, nn - p), row = K.data.aut_V_Q_pi[`${p},${nn - p}`]; cells++;
    if (!row || row[0] !== count(e, false) || row[1] !== count(e, true)) all = false; }
  ok(all && cells === 12, 'B12 recomputed: |O(V,Q)| and |Aut(V,Q,pi)| of the 12 cells with n = 2, 3, 4 are the stored numbers');
  ok(JSON.stringify(K.data.aut_V_Q_pi['0,2']) === '[6,2]' && count(sig(0, 2), false) === 6 && count(sig(0, 2), true) === 2, 'Cl(0,2): O(Q) = S3 (6), Aut(V,Q,pi) of order 2');
  ok(Object.entries(K.data.aut_V_Q_pi).every(([k, v]) => { const [p, q] = k.split(',').map(Number); return (v[1] % 3 === 0) === (Math.max(p, q) >= 3); }), '3 divides |Aut(V,Q,pi)| exactly when max(p,q) >= 3 over the stored table (n = 2..5)'); }
// B13: det of the Cartan matrix of E_n is 9 - n (n = 3..8), and det E_10 = -1; exact, by fraction-free elimination
{ const cartan = nn => { const A = Array.from({ length: nn }, () => Array(nn).fill(0n)); for (let i = 0; i < nn; i++) A[i][i] = 2n; for (const [i, j] of [[0, 2], [1, 3], [2, 3], ...Array.from({ length: Math.max(0, nn - 4) }, (_, k) => [3 + k, 4 + k])]) if (i < nn && j < nn) A[i][j] = A[j][i] = -1n; return A; };
  const det = M => { const nn = M.length; let A = M.map(r => r.slice()), sign = 1n, prev = 1n; for (let k = 0; k < nn - 1; k++) { if (A[k][k] === 0n) { const s = A.findIndex((r, i) => i > k && r[k] !== 0n); if (s < 0) return 0n; [A[k], A[s]] = [A[s], A[k]]; sign = -sign; }
      for (let i = k + 1; i < nn; i++) for (let j = k + 1; j < nn; j++) A[i][j] = (A[i][j] * A[k][k] - A[i][k] * A[k][j]) / prev; prev = A[k][k]; } return sign * A[nn - 1][nn - 1]; };
  ok([3, 4, 5, 6, 7, 8].every(nn => det(cartan(nn)) === BigInt(9 - nn) && K.data.milgram_E[String(nn)].disc === 9 - nn && K.data.milgram_E[String(nn)].phase8 === nn % 8) && det(cartan(10)) === -1n, 'B13 recomputed: det E_n = 9 - n for n = 3..8, det E_10 = -1, and the stored discriminant and phase (n mod 8)'); }
// B16: the Killing form of the six bivectors, signature by the eigenvalues of a Jacobi iteration (floats; the script uses exact rationals)
{ const biv = nn => { const o = []; for (let i = 0; i < nn; i++) for (let j = i + 1; j < nn; j++) o.push((1 << i) | (1 << j)); return o; };
  const mul = (A, B, e) => { const o = new Map(); for (const [a, ca] of A) for (const [b, cb] of B) { const c = ca * cb * sgn(a, b, e); if (c) o.set(a ^ b, (o.get(a ^ b) || 0) + c); } return o; };
  const kill = e => { const B = biv(e.length), m = B.length, idx = new Map(B.map((b, k) => [b, k])), ad = B.map(x => { const M = Array.from({ length: m }, () => Array(m).fill(0)); for (const y of B) { const xy = mul(new Map([[x, 1]]), new Map([[y, 1]]), e), yx = mul(new Map([[y, 1]]), new Map([[x, 1]]), e); for (const z of new Set([...xy.keys(), ...yx.keys()])) { const v = (xy.get(z) || 0) - (yx.get(z) || 0); if (v) { if (!idx.has(z)) throw new Error('not closed'); M[idx.get(z)][idx.get(y)] += v; } } } return M; });
    const Kf = Array.from({ length: m }, (_, i) => Array.from({ length: m }, (_, j) => { let s = 0; for (let r = 0; r < m; r++) for (let t = 0; t < m; t++) s += ad[i][r][t] * ad[j][t][r]; return s; }));
    const A = Kf.map(r => r.slice()); for (let sweep = 0; sweep < 60; sweep++) { for (let p = 0; p < m; p++) for (let q = p + 1; q < m; q++) { if (Math.abs(A[p][q]) < 1e-14) continue; const th = (A[q][q] - A[p][p]) / (2 * A[p][q]), t = Math.sign(th || 1) / (Math.abs(th) + Math.sqrt(th * th + 1)), c = 1 / Math.sqrt(t * t + 1), s = t * c;
        for (let k = 0; k < m; k++) { const akp = A[k][p], akq = A[k][q]; A[k][p] = c * akp - s * akq; A[k][q] = s * akp + c * akq; } for (let k = 0; k < m; k++) { const apk = A[p][k], aqk = A[q][k]; A[p][k] = c * apk - s * aqk; A[q][k] = s * apk + c * aqk; } } }
    const ev = A.map((r, i) => r[i]); return [ev.filter(x => x > 1e-9).length, ev.filter(x => x < -1e-9).length, ev.filter(x => Math.abs(x) <= 1e-9).length]; };
  const want = { 1: [0, 6, 0], 0: [0, 3, 3], '-1': [3, 3, 0] };
  ok([1, 0, -1].every(e => JSON.stringify(kill([1, 1, 1, e])) === JSON.stringify(want[e]) && JSON.stringify(K.data.kepler_step9.killing_signature_baez[e]) === JSON.stringify(want[e])), 'B16 recomputed: squares (+1,+1,+1,eps) give the Killing signatures (0,6,0), (0,3,3), (3,3,0) for eps = +1, 0, -1');
  ok([-1, 0, 1].every(s => JSON.stringify(kill([-1, -1, -1, s])) === JSON.stringify(want[-s]) && JSON.stringify(K.data.kepler_step9.killing_signature_step9[s]) === JSON.stringify(want[-s])), 'B16 recomputed: squares (-1,-1,-1,s) give the same signatures with eps = -s'); }

// ---- 4. sabotage: one broken statement per copy; the script must stop (exit 1) with a FAIL line of the intended row
const SABOTAGE = [
  ['the mirror without the sign change (B4)', "            e = sig(p, q); m = [-x for x in e]\n            for a in range(1 << n):\n                if (Q(a, e) + pi(a)) % 2 != Q(a, m): ok = False", "            e = sig(p, q); m = list(e)\n            for a in range(1 << n):\n                if (Q(a, e) + pi(a)) % 2 != Q(a, m): ok = False", 'core·B4'],
  ['w = 2Q without pi (B1)', 'def w4(a, eps): return (pi(a) + 2 * Q(a, eps)) % 4', 'def w4(a, eps): return (2 * Q(a, eps)) % 4', 'core·B1'],
  ['a wrong universal grading group (B9)', 'if free != r or tors != [2] * (p + q): ok = False', 'if free != r or tors != [2] * (p + q + 1): ok = False', 'core·B9'],
  ['a wrong Killing signature (B16)', 'want = {1: (0, 6, 0), 0: (0, 3, 3), -1: (3, 3, 0)}', 'want = {1: (3, 3, 0), 0: (0, 3, 3), -1: (0, 6, 0)}', 'core·B16'],
  ['a reversion that is the identity (B17)', 'return {m: c * (-1) ** (pc(m) * (pc(m) - 1) // 2) for m, c in A.items()}', 'return {m: c for m, c in A.items()}', 'core·B17'],
  ['a wrong rule for the top blade (B14)', 'want = 0 if r else (1 if (p - q) % 4 == 1 else -1)', 'want = 0 if r else (1 if (p - q) % 4 == 3 else -1)', 'core·B14'],
  ['a null bivector that squares to a unit (B5b: the cases with null generators are run)', "!= -e[i] * e[j]: ok = False\n    row('core·B5b'", "!= -(e[i] * e[j] or 1): ok = False\n    row('core·B5b'", 'core·B5b'],
  ['a rank short by one at n = 4 with one plus generator (B10: the rank is computed for every signature)', 'if rank_mod(vecs) != 1 << (2 * n): ok2 = False', 'if rank_mod(vecs) != (1 << (2 * n)) - (1 if (n == 4 and p == 1) else 0): ok2 = False', 'core·B10'],
  ['a wrong isometry at n = 8 (B15: the case n = 8 is run)', 'if Q(b, small) != Q(a, small): ok = False', 'if Q(b, small) != Q(a, small) or n == 8: ok = False', 'core·B15'],
];
{ const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-core-')); try {
    for (const [label, from, to, id] of SABOTAGE) {
      ok(src.split(from).length === 2, label + ': the line to break is in core_check.py exactly once');
      const f = path.join(tmp, 'core_check_mut.py'); fs.writeFileSync(f, src.replace(from, () => to));
      const r = py([f], tmp), out = (r.stdout || '') + (r.stderr || '');
      ok(r.status === 1 && out.includes('FAIL ' + id + '  ') && /SOME CHECK FAILED/.test(out), `${label}: the script exits 1 and row ${id} fails` + (r.status === 1 ? '' : ' (exit ' + r.status + ')'));
    }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); } }
ok(fs.readFileSync(SCRIPT, 'utf8') === src, 'the package script was not touched');
console.log(`${n} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL CORE TESTS PASS'); process.exit(bad ? 1 : 0);
