// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Schuller chapter (step 20 of the lenses page) as data, without a browser: schullerCopy.js, SchullerSection.jsx, schullerIntegration.js,
// schullerSelfcheckSource.js and claimsLocators_lns.json against the shipped check scripts and the rules of the design round (DECISIONS §0, §3).
//  1. English and Italian have the same shape (keys, lengths, tags and checks), for the formal voice and for the Young Learner
//  2. four flags only; every line tagged checked names its checks; every check id exists in a shipped script and passes when the scripts run
//     (python3 and numpy; without them that part is skipped and said so); ids of the widgets' script (scw·) are checked against the script when it is
//     in the package, otherwise against the table of DECISIONS §4
//  3. no retired wording (DECISIONS §3 "Retired wording", X9, X10); readings (ours) never "derived"
//  4. the Young Learner text (the chapter and its Map nodes) has no formula and none of the technical words (test_yl_ui.mjs lists + DECISIONS X0)
//  5. the mirrors equal the scripts byte for byte; the Map anchors and the menu are ids of the section; the claims rows resolve, carry the union of
//     their lines' flags and follow the known-ground rule; the persona stays under 1 800 characters; no e-mail address; the three-line header
//  6. the honesty bar counts of DECISIONS X8 (23 / 14 / 2 / 4 of 43) and the order of the grades along his chain (S, E, E, S, S, S, A)
// Run: node test_lens_schuller.mjs
import fs from 'node:fs'; import path from 'node:path'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
process.chdir(PKG);   // the files below are named relative to the package folder
import { COPY, CHAIN_GRADES } from './schullerCopy.js';
import { MAP_NODES, MAP_TEXT, PERSONA } from './schullerIntegration.js';
import * as MIRROR from './schullerSelfcheckSource.js';
import { buildClaims } from './make_claims_data.mjs';
import { isKnownGround } from './readerFilter.js';
import { THEOREMS } from './researchersData.js';
import { MATRIX_ROWS } from './translationMatrixData.js';
import { LENSES, MTHREADS } from './mapData.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(f, 'utf8');
const FOUR = ['checked', 'standard', 'ours', 'open'];
const kindsOf = k => String(k || '').split(/\s+/).filter(Boolean);
// a tagged line is [kinds, text] or [kinds, text, checks], kinds being lower-case words (whether they are the four flags is checked below, so a fifth flag cannot hide a line)
const isLine = a => Array.isArray(a) && (a.length === 2 || (a.length === 3 && Array.isArray(a[2]))) && typeof a[0] === 'string' && typeof a[1] === 'string' && /^[a-z]+( [a-z]+)*$/.test(a[0]);
// every tagged line of a voice, with its path; every string, with its path
const walk = (o, p, out) => { if (isLine(o)) { out.lines.push([p, o]); out.strings.push([[...p, 1], o[1]]); return out; } if (typeof o === 'string') out.strings.push([p, o]); else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) walk(v, [...p, k], out); return out; };   // a line gives its text (its tags and check ids are not prose)
const V = { en: walk(COPY.en, ['en'], { lines: [], strings: [] }), it: walk(COPY.it, ['it'], { lines: [], strings: [] }), ylen: walk(COPY.yl.en, ['yl', 'en'], { lines: [], strings: [] }), ylit: walk(COPY.yl.it, ['yl', 'it'], { lines: [], strings: [] }) };

// ---- 1. EN / IT parity
const shape = (a, b, p, errs) => {
  if (typeof a !== typeof b || Array.isArray(a) !== Array.isArray(b)) { errs.push(p.join('.') + ': type'); return; }
  if (Array.isArray(a)) { if (a.length !== b.length) errs.push(p.join('.') + `: length ${a.length} / ${b.length}`); if (isLine(a)) { if (a[0] !== b[0]) errs.push(p.join('.') + ': tags'); if (JSON.stringify(a[2] || []) !== JSON.stringify(b[2] || [])) errs.push(p.join('.') + ': checks'); return; } }
  if (a && typeof a === 'object') { const ka = Object.keys(a).sort(), kb = Object.keys(b).sort(); if (ka.join() !== kb.join()) errs.push(p.join('.') + ': keys ' + ka.filter(k => !kb.includes(k)).concat(kb.filter(k => !ka.includes(k))).join(',')); for (const k of ka) if (k in b) shape(a[k], b[k], [...p, k], errs); }
  if (p.at(-1) === 'id' || (p.at(-1) === 'guard' && Array.isArray(a)) || p.at(-1) === 'date' || p.at(-1) === 'file') { if (JSON.stringify(a) !== JSON.stringify(b)) errs.push(p.join('.') + ': ids, dates and files are the same in both languages'); }
};
for (const [a, b, nm] of [[COPY.en, COPY.it, 'formal'], [COPY.yl.en, COPY.yl.it, 'Young Learner']]) { const errs = []; shape(a, b, [nm], errs); ok(errs.length === 0, `${nm}: English and Italian have the same keys, lengths, tags and checks: ${errs.slice(0, 6).join(' | ')}`); }
// New text of v11 is English in the Italian slots (the author's decision of 7 October 2026): these leaves of the chapter are the named exceptions of the next check, and each must really be the English text
const EN_IN_IT = ['en.first.statements.7.lines.0.1', 'en.first.statements.8.lines.0.1', 'en.quantum.items.3.1', 'en.deform.findings.0.lines.3.1', 'en.bands.findings.0.lines.4.1', 'en.honest.items.5.1', 'en.fibre.findings.0.lines.2.1', 'en.scripts.report.lead', 'en.scripts.report.title'];   // the last two: the link to the full report, new text, English in the Italian slot too
ok(EN_IN_IT.every(p => { const g = o => p.split('.').slice(1).reduce((x, k) => x?.[k], o); return typeof g(COPY.en) === 'string' && g(COPY.en) === g(COPY.it); }), 'every named English-in-Italian leaf is the English text (the list cannot go stale)');
// present statements of the lens review: the blade labels are the spinor weights (core·B10, B10b); the sorting by the square says what is squared; the convention note is about the chapter only
for (const l of ['en', 'it']) { const Fb = COPY[l].fibre, L2 = Fb.findings[0].lines[2];
  ok(L2[0] === 'checked' && /the blade labels are the weights of the spinor of so\(V ⊕ −V\)/.test(L2[1]) && /core·B10, core·B10b/.test(L2[1]) && L2[2].includes('fibre·G2a–c'), `${l}: F10 says the blade labels are the weights of the spinor of so(V ⊕ −V) (checked, fibre·G2a–c, core·B10, core·B10b)`);
  ok(!/banner|fascia/i.test(Fb.convention) && /Nothing below depends on the choice|Niente di ciò che segue/.test(Fb.convention), `${l}: the convention note is about the chapter only`);
  ok(/the three values of the generator’s square, −1, 0, \+1/.test(COPY[l].deform.findings[0].lines[3][1]) && COPY[l].deform.findings[0].lines[3][0] === 'ours', `${l}: the deformation line groups the generator's square with the other sortings as ours`);
  ok(/the sign of X², the square of an element/.test(COPY[l].bands.findings[0].lines[4][1]) && COPY[l].bands.findings[0].lines[4][0] === 'ours', `${l}: the band line says it sorts the square of an element (ours)`);
  ok(/the orbits the square of the extra generator/.test(COPY[l].honest.items[5][1]) && COPY[l].honest.items[5][0] === 'ours', `${l}: the honest list says what each place of the trio sorts (ours)`); }
for (const l of ['en', 'it']) ok(COPY[l].scripts.report && COPY[l].scripts.report.file === 'reports/html/schuller_bridge_report.html' && fs.existsSync(COPY[l].scripts.report.file), `${l}: the scripts section ends with a link to the full report (the file ships in reports/html/)`);
{ const same = V.en.strings.filter(([p, s]) => /[a-z]{4,}.*\s[a-z]{3,}/i.test(s) && !/^selfcheck\/|^cd /.test(s) && !EN_IN_IT.includes(p.join('.'))).filter(([p, s]) => { const t = p.slice(1).reduce((x, k) => x?.[k], COPY.it); return t === s; });
  ok(same.length === 0, 'every English sentence has its own Italian text: ' + same.slice(0, 3).map(x => x[0].join('.')).join(', ')); }
{ const same = V.ylen.strings.filter(([p, s]) => /\s/.test(s)).filter(([p, s]) => p.slice(2).reduce((x, k) => x?.[k], COPY.yl.it) === s);
  ok(same.length === 0, 'every Young Learner sentence has its own Italian text: ' + same.slice(0, 3).map(x => x[0].join('.')).join(', ')); }
ok(V.en.lines.length > 100 && V.ylen.lines.length >= 15, `the chapter has its tagged lines (${V.en.lines.length} formal, ${V.ylen.lines.length} for the Young Learner, in each language)`);

// ---- 2. four flags only; checked lines name checks; the ids exist and pass
const ALL_LINES = [...V.en.lines, ...V.it.lines, ...V.ylen.lines, ...V.ylit.lines];
ok(ALL_LINES.every(([, l]) => kindsOf(l[0]).every(k => FOUR.includes(k)) && new Set(kindsOf(l[0])).size === kindsOf(l[0]).length), 'four flags only, none twice');
{ const bare = ALL_LINES.filter(([, l]) => kindsOf(l[0]).includes('checked') && !(l[2] || []).length); ok(bare.length === 0, 'every line tagged checked names the checks that carry it: ' + bare.slice(0, 4).map(x => x[0].join('.')).join(', ')); }
{ const odd = ALL_LINES.filter(([, l]) => !kindsOf(l[0]).includes('checked') && (l[2] || []).length); ok(odd.length === 0, 'a line that is not tagged checked cites no check: ' + odd.slice(0, 4).map(x => x[0].join('.')).join(', ')); }
const SCRIPTS = { bridge: 'selfcheck/reports/bridge_check.py', qm: 'selfcheck/reports/bridge_check_qm.py', fibre: 'selfcheck/reports/fibre_check.py', cat: 'selfcheck/reports/cat_check.py', scw: 'selfcheck/reports/lens_sch_check.py' };
const SCW_TABLE = ['P1', 'P2', 'P3', 'P4'];   // DECISIONS §4: the ids of lens_sch_check.py that the text may cite
const defined = {}; for (const [ns, f] of Object.entries(SCRIPTS)) defined[ns] = fs.existsSync(f) ? new Set([...rd(f).matchAll(/\bchk\(\s*f?['"]([A-Z]\d*[0-9a-z]*)['"]/g)].map(m => m[1]).concat([...rd(f).matchAll(/\b(?:check|ok)\(\s*f?['"]([A-Z]\d+[a-z]?)['"]/g)].map(m => m[1]))) : null;
const scwHere = !!defined.scw && defined.scw.size > 0;
if (!scwHere) console.log('note: selfcheck/reports/lens_sch_check.py is not in this package yet: scw· ids are checked against the table of DECISIONS §4 only');
// "bridge·A1–A4" -> A1..A4; "fibre·G3a–e" -> G3a..G3e; "qm·Q9a–b"; "qm·Q5–Q7"; an id names a check, or the group of checks it prefixes (Q5 -> Q5a, Q5b)
const expand = id => { const m = /^(\w+)·([A-Z]\d*)([a-z]?)(?:–(?:([A-Z])(\d+)|([a-z])))?$/.exec(id); if (!m) return null; const [, ns, base, low, , hiNum, hiLow] = m;
  if (hiNum) { const b0 = /^([A-Z])(\d+)$/.exec(base); if (!b0) return null; const out = []; for (let i = Number(b0[2]); i <= Number(hiNum); i++) out.push(b0[1] + i); return [ns, out]; }
  if (hiLow) { const out = []; for (let c = low.charCodeAt(0); c <= hiLow.charCodeAt(0); c++) out.push(base + String.fromCharCode(c)); return [ns, out]; }
  return [ns, [base + low]]; };
const known = (ns, x) => { if (ns === 'scw' && !scwHere) return SCW_TABLE.includes(x); const s = defined[ns]; return !!s && (s.has(x) || [...s].some(y => y.startsWith(x) && /^[a-z]$/.test(y.slice(x.length)))); };
const cited = new Set(ALL_LINES.flatMap(([, l]) => l[2] || []));
const badIds = [];
for (const c of cited) {
  if (/^Thm T\d+$/.test(c)) { const t = c.slice(4); if (!THEOREMS.some(x => x.id === t) || !fs.existsSync(`researchers_checks/check_${t}.py`)) badIds.push(c); continue; }
  const e = expand(c); if (!e || !SCRIPTS[e[0]]) { badIds.push(c + ' (form)'); continue; }
  if (!e[1].every(x => known(e[0], x))) badIds.push(c);
}
ok(badIds.length === 0, `every cited check exists (${cited.size} ids: a check of a shipped script, a theorem with its check_T#.py, or a check of the widgets' script): ` + badIds.join(', '));
// run the three scripts: every cited id of them prints an ok line, and nothing fails
const PYOK = spawnSync('python3', ['-c', 'import numpy'], { encoding: 'utf8' }).status === 0, RUNS = {};
if (!PYOK) console.log('note: python3 with numpy is not available: the scripts were not run (the ids were checked in their text)');
else for (const f of ['fibre_check.py', 'bridge_check.py', 'bridge_check_qm.py']) RUNS[f] = spawnSync('python3', [f], { cwd: 'selfcheck/reports', encoding: 'utf8', timeout: 110000 });
{ if (PYOK) for (const [ns, f] of [['fibre', 'fibre_check.py'], ['bridge', 'bridge_check.py'], ['qm', 'bridge_check_qm.py']]) {
    const r = RUNS[f], out = r.stdout || '';
    const okIds = new Set([...out.matchAll(/^ok\s+([A-Z]\d*[0-9a-z]*):/gm)].map(m => m[1])), failIds = [...out.matchAll(/^FAIL\s+([A-Z]\d*[0-9a-z]*)/gm)].map(m => m[1]);
    const want = [...cited].map(expand).filter(e => e && e[0] === ns).flatMap(e => e[1]);
    const miss = want.filter(x => !okIds.has(x) && ![...okIds].some(y => y.startsWith(x) && /^[a-z]$/.test(y.slice(x.length))));
    ok(r.status === 0 && failIds.length === 0 && miss.length === 0, `${f} runs and passes (${okIds.size} ids ok) and every cited id of it prints ok: status ${r.status}, failing ${failIds.join(',')}, missing ${miss.join(',')}`);
  } }
// the counts the chapter states are the scripts'
{ const counts = {}; for (const f of ['fibre_check.py', 'bridge_check.py', 'bridge_check_qm.py']) counts[f] = (rd('selfcheck/reports/' + f).match(/\bchk\(/g) || []).length;
  ok(COPY.en.scripts.files.every(x => new RegExp(`\\b(\\d+) checks`).test(x.note)), 'each script line names its number of checks');
  const said = Object.fromEntries(COPY.en.scripts.files.map(x => [path.basename(x.file), Number(/(\d+) checks/.exec(x.note)[1])]));
  if (PYOK) for (const f of Object.keys(said)) { const out = RUNS[f].stdout || ''; const m = /: (\d+) ok, 0 failed/.exec(out); ok(m && Number(m[1]) === said[f], `${f}: the chapter says ${said[f]} checks, the script prints ${m && m[1]}`); }
  const total = Object.values(said).reduce((a, b) => a + b, 0); ok(total === 163 && COPY.en.first.full.join(' ').includes('163 in all') && COPY.it.first.full.join(' ').includes('163 in tutto'), `the three scripts hold ${total} checks, as the introduction says`); }

// ---- 3. retired wording (DECISIONS §3 "Retired wording", X9, X10)
const RETIRED = [
  [/quadric of entangled|entangled two-qubit states|stati entangled di due qubit|quadrica degli stati entangled/i, 'P2: Cl(2,2) as the quadric of entangled states'],
  [/mass is a fibre momentum|massa è un impulso della fibra|says the fibre is space-like|la fibra è di tipo spazio/i, 'F12 headline'],
  [/exactly two ladders|esattamente due scale|first excluded|prima esclusa/i, '"exactly two ladders", "first excluded"'],
  [/fifth home|quinta casa/i, 'F13 "fifth home of the trio"'],
  [/E, S, E, S, S, S, A/, 'F6\'s order of the grades'],
  [/Furey[’']s End\(V\)|End\(V\) di Furey|the type of Cl\(1,3\)|il tipo di Cl\(1,3\)/, 'F10/F11 identifications'],
  [/never name|non nominano mai|missing step|passo mancante/i, 'F1 "never name", P1 "missing step"'],
  [/XOR with 1+…1|XOR con 1+…1|Hodge star\s*=\s*XOR|stella di Hodge\s*=\s*XOR/i, '"Hodge star = XOR with 1…1"'],
  [/\bexplain|\bspieg(a|ano|herebbe)\b/i, '"explains"'], [/\bconserved\b|\bconservat[oaie]\b/i, '"conserved"'],
  [/Born rule is the Frobenius form|regola di Born è la forma di Frobenius/i, 'N10 heading'],
  [/particle to antiparticle|particella in antiparticella/i, '"particle to antiparticle"'],
  [/three 8s|tre 8|Golay|before, now, after|prima, ora, dopo|quark row|riga dei quark|24 = 3\s*[×x]\s*8/i, 'numerology (X10, F14)'],
  [/\binert\b|ramified|ramificat|ten classes|dieci classi/i, 'numerology (X10)'],
  [/\bHorizon\b|speculazione d’orizzonte/, 'the horizon speculation'],
  [/Schuller erred|Schuller ha sbagliato/i, 'F9 retold as "Schuller erred"'],
  [/\b23 of 43\b|\b23 su 43\b/, 'headline "23 of 43 exact"'],
  [/[^−\-–]C\(n,2\)\/4/, 'L13: the Casimir with a positive sign'],
  [/Majkić|Tian/, 'other chapters\' dead ends'],
];
for (const [k, v] of Object.entries(V)) for (const [re, what] of RETIRED) { const hit = v.strings.filter(([p, s]) => re.test(s)); ok(hit.length === 0, `${k}: no retired wording (${what}): ` + hit.slice(0, 2).map(([p, s]) => p.join('.') + ': ' + s.slice(0, 80)).join(' | ')); }
for (const [re, what] of RETIRED) ok(!re.test(PERSONA) && !re.test(JSON.stringify(MAP_TEXT)), `persona and Map text: no retired wording (${what})`);
// tags that DECISIONS ties to words: a reading is never "derived"; "trio" and Λ ~ −s·κ² are ours; "Carroll" only in an open line; "light cone" for ε = +1 is ours
const tieRule = (re, kind, what) => { const hit = ALL_LINES.filter(([, l]) => re.test(l[1]) && !kindsOf(l[0]).includes(kind)); ok(hit.length === 0, `${what}: ` + hit.slice(0, 3).map(([p]) => p.join('.')).join(', ')); };
tieRule(/\btrio\b|terna (di segni|−1)|stessa terna|sola terna|della terna/i, 'ours', 'every line that speaks of the trio −1, 0, +1 is tagged ours (X9)');
tieRule(/κ²/, 'ours', 'Λ ~ −s·κ² only under ours');
tieRule(/Carroll/, 'open', '"Carroll" only in an open line (P3)');
tieRule(/light cone|cono di luce/, 'ours', 'the light cone of ε = +1 is ours');
{ const hit = ALL_LINES.filter(([, l]) => kindsOf(l[0]).includes('ours') && /deriv|ricav/i.test(l[1])); ok(hit.length === 0, 'no line tagged ours says derived: ' + hit.map(([p]) => p.join('.')).join(', ')); }
{ const persona = PERSONA; ok(/\(checked/.test(persona) && /ours/.test(persona) && /\(open\)/.test(persona) && persona.length <= 1800, `the persona paragraph carries its tags and is ${persona.length} characters (at most 1 800)`); }
// the grades along his chain: the figure's order, stated in both languages
ok(CHAIN_GRADES.join('') === 'SEESSSA' && COPY.en.chain.findings[0].lines.some(l => l[1].includes('S, E, E, S, S, S, A')) && COPY.it.chain.findings[0].lines.some(l => l[1].includes('S, E, E, S, S, S, A')), 'the grades along his chain are S, E, E, S, S, S, A (the report\'s figure), in both languages');

// ---- 4. the Young Learner: no formula, no technical word
const ylSrc = rd('test_yl_ui.mjs'), reOf = name => { const m = new RegExp(`^const ${name} = (/.*/[a-z]*);`, 'm').exec(ylSrc); return m ? eval(m[1]) : null; };   // the lists of test_yl_ui.mjs, read from its source so that they stay one list
const SYMBOLS = reOf('SYMBOLS'), JARGON = reOf('JARGON');
const X0 = /\balgebra|\bradical|\bradicale|Frobenius|Jordan|Fock|Floquet|hyperbolic|iperbolic|polynomial|polinomi|commutant|fibre|fiber|\bfibra|mirror|specular|Lorentz|Clifford|Cl\(|\bdegenerate|degener/i;
ok(SYMBOLS instanceof RegExp && JARGON instanceof RegExp, 'the formula and jargon lists of test_yl_ui.mjs are read');
const ylTexts = [...V.ylen.strings, ...V.ylit.strings, ...['en', 'it'].flatMap(l => Object.entries(MAP_TEXT.yl[l]).flatMap(([k, v]) => v.map((s, i) => [['map', l, k, i], s])))];
const ylHits = ylTexts.filter(([, s]) => SYMBOLS.test(s) || JARGON.test(s) || X0.test(s));
ok(ylHits.length === 0, `the Young Learner text (chapter and Map) has no formula and no technical word (${ylTexts.length} strings): ` + ylHits.slice(0, 4).map(([p, s]) => p.join('.') + ': ' + s.slice(0, 70)).join(' | '));
ok(!/left|right|sinistr|destr/i.test(ylTexts.map(x => x[1]).join(' ')), 'the Young Learner reads outside / inside (page 1), never left / right');

// ---- 5. mirrors, anchors, menu, Map, claims, persona, headers, e-mail
const MIRRORS = { FIBRE_CHECK_PY: 'selfcheck/reports/fibre_check.py', BRIDGE_CHECK_PY: 'selfcheck/reports/bridge_check.py', QM_CHECK_PY: 'selfcheck/reports/bridge_check_qm.py' };
for (const [k, f] of Object.entries(MIRRORS)) ok(MIRROR[k] === rd(f), `${k} equals ${f} byte for byte (sh selfcheck/regen_lens_schuller.sh rebuilds it)`);
ok(Object.keys(MIRROR).sort().join() === Object.keys(MIRRORS).sort().join() && rd('schullerSelfcheckSource.js').trim().split('\n').every(l => /^export const \w+ = ".*";$/.test(l)), 'the mirror module holds exactly the three scripts, one export per line');
ok(COPY.en.scripts.files.every(x => Object.values(MIRRORS).includes(x.file)), 'every script box of the chapter has its mirror');
const SEC = rd('SchullerSection.jsx'), ids = new Set([...SEC.matchAll(/\bid="([\w-]+)"/g)].map(m => m[1]));
ok(ids.has('ln-schuller') && [...ids].filter(x => x !== 'ln-schuller').every(x => /^sc-[a-z0-9-]+$/.test(x)), 'the root is ln-schuller and every other anchor starts with sc- (lower case, hyphens)');
// SchullerSection.jsx is JSX (not importable in node): its menu and widget lists are read from its source
const menuIds = s => (new RegExp(`${s}: \\[([^\\]]+)\\]`).exec(SEC) || [, ''])[1].split(',').map(x => x.trim().replace(/'/g, '')).filter(Boolean);
for (const s of ['yl', 'formal']) { const m = menuIds(s); ok(m.length > 8 && m.every(x => ids.has('sc-' + x)), `the ${s} menu points at anchors of the section: ${m.filter(x => !ids.has('sc-' + x)).join(',')}`); ok(m.every(x => (s === 'yl' ? COPY.yl.en.menu : COPY.en.menu)[x] && (s === 'yl' ? COPY.yl.it.menu : COPY.it.menu)[x]), `the ${s} menu has its labels in both languages`); }
ok(MAP_NODES[0].id === 'schuller' && MAP_NODES[0].go.join() === 'lenses,ln-schuller' && MAP_NODES.every(x => x.go[0] === 'lenses' && ids.has(x.go[1])), 'Map: the chapter node first, every node points at an anchor of the section');
ok(MAP_NODES.every(x => x.lens.every(l => LENSES.includes(l)) && x.th.every(t => MTHREADS.includes(t)) && x.tags.length && x.tags.every(t => FOUR.includes(t))), 'Map: lenses, threads and tags are the known ones');
ok(MAP_NODES.every(x => x.script === '—' || x.script.split(', ').every(f => fs.existsSync('selfcheck/' + f))), 'Map: every script named exists');
ok(['en', 'it'].every(l => MAP_NODES.every(x => MAP_TEXT[l][x.id]?.[0]?.length > 2 && MAP_TEXT[l][x.id][1].length > 20 && MAP_TEXT.yl[l][x.id]?.[0]?.length > 2 && MAP_TEXT.yl[l][x.id][1].length > 20)) && ['en', 'it'].every(l => Object.keys(MAP_TEXT[l]).length === MAP_NODES.length && Object.keys(MAP_TEXT.yl[l]).length === MAP_NODES.length), 'Map: every node has its title and text, EN and IT, formal and plain, and no text is orphaned');
// the widgets: every export placed, with the audiences of DECISIONS §3
const W_DECISIONS = { SW1: '0,1,2', SW2: '0,1,2', SW3: '0,1,2', SW4: '1,2', SW5: '0,1,2', SW6: '0,1,2', SW7: '0,1', SchullerWidgetsScript: '0,1,2' };
{ const m = /export const WIDGETS = \{([^}]+)\}/.exec(SEC), got = m ? Object.fromEntries([...m[1].matchAll(/(\w+): \[([\d, ]*)\]/g)].map(x => [x[1], x[2].replace(/\s/g, '')])) : {};
  ok(JSON.stringify(got) === JSON.stringify(W_DECISIONS), 'the widgets and their audiences are those of DECISIONS §3: ' + JSON.stringify(got));
  for (const w of Object.keys(W_DECISIONS)) ok(new RegExp(`<${w} \\{\\.\\.\\.wp\\} />`).test(SEC), `${w} is placed in the section`);
  ok(/import \{ SW1, SW2, SW3, SW4, SW5, SW6, SW7, SchullerWidgetsScript \} from '\.\/SchullerWidgets\.jsx'/.test(SEC), 'the section imports the eight exports of SchullerWidgets.jsx'); }
// claims (this chapter's text: LNS-001 … 099; the rows 101 … 199 are the captions of the widgets, claimsLocators_lnsw.json)
const claims = (await buildClaims()).filter(c => c.group === 'LNS' && Number(c.id.slice(4)) < 100), LOC = JSON.parse(rd('claimsLocators_lns.json'));
ok(claims.length === LOC.length && claims.length >= 60 && LOC.every((r, i) => r.id === 'LNS-' + String(i + 1).padStart(3, '0')), `the claims rows LNS-001 … LNS-${String(LOC.length).padStart(3, '0')} resolve (${claims.length})`);
ok(LOC.every((r, i) => claims[i] && r.lines.every((l, j) => l.en.text === claims[i].en[j]?.text && l.it.text === claims[i].it?.[j]?.text)), 'claimsLocators_lns.json is current: the text it stores is the text its locators resolve to (rerun the generator after a change of the copy): ' + LOC.filter((r, i) => !r.lines.every((l, j) => l.en.text === claims[i]?.en[j]?.text && l.it.text === claims[i]?.it?.[j]?.text)).map(r => r.id).slice(0, 5).join(','));
ok(claims.every(c => c.it && c.it.length === c.en.length && c.en.every((x, i) => x.flags.join() === c.it[i].flags.join())), 'every claims row has its Italian lines with the same flags');
ok(claims.every(c => c.flags.join() === c.flagsSpec.join()), 'every row carries the union of its lines\' flags as flagsSpec (no exception needed in test_claims_sync)');
ok(claims.every(c => c.en.every(x => x.known === isKnownGround(x.flags)) && c.known === c.en.every(x => x.known) && c.known === isKnownGround(c.flags)), 'known ground: standard and checked, neither ours nor open (the reader filter\'s rule), for every line and for every row (a row is known ground exactly when all its lines are: test_filter_ui.mjs): ' + claims.filter(c => c.known !== isKnownGround(c.flags)).map(c => c.id).join(','));
ok(LOC.every(r => r.shown_on.page === 'lenses' && r.shown_on.tab === 'schuller' && ids.has(r.shown_on.anchor) && r.visible_to.length && r.visible_to.every(v => ['Young Learner', 'Physicist', 'Mathematician'].includes(v))), 'every row is shown at an anchor of the section, to named audiences');
{ const texts = new Set([...ALL_LINES].map(([, l]) => l[1])); ok(claims.every(c => c.en.every(x => texts.has(x.text)) && c.it.every(x => texts.has(x.text))), 'every claims line is a line of the chapter'); }
{ const inRows = new Set(claims.flatMap(c => [...c.en, ...c.it].map(x => x.text))), missing = ALL_LINES.filter(([p, l]) => !inRows.has(l[1])); ok(missing.length === 0, 'every tagged line of the chapter is in a claims row: ' + missing.slice(0, 4).map(([p]) => p.join('.')).join(', ')); }
ok(LOC.every(r => !r.lines.some(l => l.flags.includes('checked')) || /·|Thm T/.test(r.checkedBy || '')), 'every row with a checked line names the checks in checkedBy');
// files of this chapter: header and no e-mail address
const MINE = ['SchullerSection.jsx', 'schullerCopy.js', 'schullerIntegration.js', 'schullerSelfcheckSource.js', 'selfcheck/regen_lens_schuller.sh', 'claimsLocators_lns.json', 'test_lens_schuller.mjs', 'test_lens_schuller_ui.mjs'];
const SPDX = 'SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0';
for (const f of MINE) { if (!fs.existsSync(f)) { ok(false, f + ' exists'); continue; } const t = rd(f); ok(!/[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+\.[A-Za-z]{2,}/.test(t) && !t.includes('mail' + 'to:'), `${f}: no e-mail address`); if (/\.(jsx?|mjs|sh)$/.test(f)) ok(t.split('\n').slice(0, 6).join('\n').includes(SPDX), `${f}: the licence header`); }
ok(rd('selfcheck/regen_lens_schuller.sh').includes('schullerSelfcheckSource.js') && /set -e/.test(rd('selfcheck/regen_lens_schuller.sh')), 'selfcheck/regen_lens_schuller.sh writes the mirror module and stops at the first error');

// ---- 6. the honesty bar (DECISIONS X8) and the matrix rows the chapter cites
{ const rows = MATRIX_ROWS.filter(r => r.src === 'schuller'), c = { E: 0, S: 0, A: 0, none: 0 }; for (const r of rows) { const g = Object.values(r.cells).map(x => x.grade); c[g.includes('E') ? 'E' : g.includes('S') ? 'S' : g.includes('A') ? 'A' : 'none']++; }
  ok(rows.length === 43 && c.E === 23 && c.S === 14 && c.A === 2 && c.none === 4, `the Schuller rows of the matrix: 43 rows, best grades 23 / 14 / 2 / 4 (DECISIONS X8): ${rows.length} rows, ${JSON.stringify(c)}`);
  const uids = new Set(rows.map(r => r.uid)); ok(LOC.every(r => r.links.every(u => uids.has(u))), 'every claims row links to Schuller rows of the matrix');
  const gaps = rows.filter(r => !Object.keys(r.cells).length).map(r => r.id).sort().join(); ok(gaps === 'C12,L4,M10,M2', 'the four gaps are L4, C12, M2, M10, as the chapter says: ' + gaps);
  const C7 = rows.find(r => r.id === 'C7'); ok(C7 && Object.values(C7.cells).every(x => x.grade === 'A'), 'row C7 is an analogy only, as the chapter says'); }
// the chapter states each result as it stands: no corrections block, no erratum id, no struck sentence; the present statements that the old block carried are in the body
for (const l of ['en', 'it']) ok(!('corr' in COPY[l]) && !('corr' in COPY[l].menu) && !('corr' in COPY.yl[l]) && !('corr' in COPY.yl[l].menu), `${l}: the chapter has no corrections block`);
ok(!menuIds('formal').includes('corr') && !menuIds('yl').includes('corr') && !/sc-corr|<s>|ERRATA/.test(SEC), 'SchullerSection.jsx draws no corrections section and no struck sentence');
ok(!/\bE-\d{3}\b/.test(JSON.stringify(COPY)) && !/\bE-\d{3}\b/.test(PERSONA), 'no erratum id in the chapter copy or in the persona');
{ const S = COPY.en.first.statements, all = l => l.lines.map(x => x[1]).join(' ');
  ok(/band edge iff X² = 0 with X ≠ 0\. M = ±I has X = 0 and bounded powers and is not an edge\./.test(all(S[7])), 'F8: a band edge is X² = 0 with X ≠ 0; M = ±I has X = 0 and bounded powers and is not an edge (Thm T19(1))');
  ok(/the real operator γ·∂ − m has the physical shell E² = \|p\|² \+ m²\.$/.test(S[2].lines[1][1]) && /The slip is the factor i, not the cell/.test(COPY.en.notes.items[0][1]) && /settled in the algebra\.$/.test(COPY.en.quantum.items[3][1]), 'F9: the physical shell of the real operator γ·∂ − m, the slip is the factor i, the Dirac signs are settled in the algebra');
  const L15 = S[8].lines[0]; ok(/the Cartan matrices are not computed/.test(L15[1]) && /B₃ and C₃ both have 18 roots and rank 3/.test(L15[1]) && L15[2].includes('fibre·G8a–c'), 'F15: the root systems are named from root count and rank only (fibre·G8c); B₃ and C₃ both have 18 roots and rank 3'); }
{ const T = Object.fromEntries(THEOREMS.map(t => [t.id, t])); ok(['T3', 'T16', 'T18', 'T19', 'T20'].every(id => T[id] && T[id].status && T[id].verifier), 'the theorems of the chapter are on the page for researchers with a status and a verdict'); }
console.log(`${n} checks`); console.log(bad ? `${bad} FAILURES` : 'ALL SCHULLER CHAPTER TESTS PASS'); process.exit(bad ? 1 : 0);
