// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Shared helper of the browser tests: the language is chosen once in Settings (the gear at the end of the top navigation), not in the control bar.
export async function setLang(pg, lang) {
  const sum = pg.locator('.story-nav .settings > summary');
  if (!(await pg.locator('.story-nav .settings').evaluate(e => e.open))) await sum.click();
  await pg.locator(`.story-nav .settings [data-lang="${lang}"]`).click();
  await pg.waitForTimeout(120);
}
// pages with tabs (furey, shapes, equations): open one tab
export async function tab(pg, id) { await pg.locator(`.tabbar [data-tab="${id}"]`).click(); await pg.waitForTimeout(150); }
// keyboard: focus `from`, then press Tab until the focused element matches `sel` (at most `max` presses); true when it got there
export async function tabTo(pg, from, sel, max = 60) {
  await pg.locator(from).first().focus();
  for (let i = 0; i < max; i++) { await pg.keyboard.press('Tab'); if (await pg.evaluate(s => !!document.activeElement && document.activeElement.matches(s), sel)) return true; }
  return false;
}
// the data-* value (or the attribute) of the focused element
export const focused = (pg, attr) => pg.evaluate(a => document.activeElement ? document.activeElement.getAttribute(a) : null, attr);
