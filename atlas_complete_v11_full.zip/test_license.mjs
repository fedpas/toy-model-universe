// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The licence is in place and nothing has slipped out of it: LICENSE is the verbatim PolyForm Noncommercial 1.0.0 under our Required Notice line, NOTICE names what it covers and
// what it does not, package.json says the same, every script and source file carries the three-line header (the three kernel files of the speed test are the one named exception),
// the downloadable Python scripts carry it inside the app too, the app and the speed test show the notice, and no e-mail address is shipped, not even inside a shipped zip
// (the six report zips in reports/zips/ are read member by member: no address, and every script in them has the header).
// Run: node test_license.mjs
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import zlib from 'node:zlib';
import { MAP } from './mapCopy.js';
import { PKG } from './paths.mjs';
const here = PKG; let checks = 0, bad = 0;   // the package folder, from fileURLToPath (a URL's .pathname keeps %20 for a space and breaks such a path)
const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(here, f), 'utf8');
const SPDX = 'SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', NOTICE = 'Required Notice: Copyright (c) 2026 the Cascade Atlas authors';
const URL_ = 'https://polyformproject.org/licenses/noncommercial/1.0.0';
const TERMS = 'Free for noncommercial use only, not for commercial use. Terms: ' + URL_ + ' (see LICENSE)';   // the third header line, with the exact address of the licence
const KERNELS = ['pgaEngine.js', 'benchKernels.js', 'productKernels.js'];
const HOST = new Set(['SimplexCanvas.jsx', 'GenesisCanvas.jsx', 'canvasFacts.js']);   // the owner's own files: not shipped, not ours to label (a build copy has them next to the package). The build harness (harness/) is shipped and carries the header.

// 1. LICENSE: our Required Notice, a blank line, then the official text unchanged (sha256 of the official file as published at the URL above)
const L = rd('LICENSE'), lines = L.split('\n');
ok(lines[0] === NOTICE && lines[1] === '', 'LICENSE starts with the Required Notice line and a blank line');
const body = lines.slice(2).join('\n');
ok(crypto.createHash('sha256').update(body).digest('hex') === 'c0ea4a896d2c8c394b29f9427589996db826cd501c512279ff0ed3ef48fabbe5', 'LICENSE carries the official PolyForm Noncommercial 1.0.0 text, byte for byte');
ok(/^# PolyForm Noncommercial License 1\.0\.0\n/.test(body) && body.includes('<' + URL_ + '>'), 'and it names the licence and its address');
// 2. NOTICE
const N = rd('NOTICE');
ok(N.includes(NOTICE) && N.includes('PolyForm Noncommercial License 1.0.0') && N.includes(URL_), 'NOTICE has the Required Notice line, the licence and its address');
ok(KERNELS.every(k => N.includes(k)) && /WHAT THE LICENCE COVERS/.test(N) && /WHAT IT DOES NOT COVER/.test(N), 'NOTICE names the three kernel files and says what it covers and what it does not');
ok(['react', 'katex', 'streamdown', 'three', 'playwright', 'ganja.js', 'SimplexCanvas.jsx', 'GenesisCanvas.jsx'].every(x => N.includes(x)), 'NOTICE names the third-party parts and the host files it does not cover');
// 3. package.json
const P = JSON.parse(rd('package.json'));
ok(P.license === 'PolyForm-Noncommercial-1.0.0' && P.private === true, 'package.json: licence field is the SPDX id, and the package is private (not for a registry)');
// 4. every script and source file has the header (first 6 lines): all three lines, the SPDX id, the Required Notice and the terms line with the licence's address
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => ['node_modules', 'dist', 'dist_real', 'test_logs', '.git', '__pycache__'].includes(e.name) ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const all = walk(here).map(f => path.relative(here, f)), SRC = /\.(js|jsx|mjs|cjs|py|sh)$/;
const missing = [], bare = [];
for (const f of all) { if (!SRC.test(f)) continue; const head = rd(f).split('\n').slice(0, 6).join('\n'); const lines3 = [SPDX, NOTICE, TERMS].map(x => head.includes(x)), has = lines3.every(Boolean);
  if (HOST.has(f)) continue; if (KERNELS.includes(path.basename(f))) { if (lines3.some(Boolean)) bare.push(f); continue; } if (f.startsWith(path.join('replication', 'runs') + path.sep)) continue;
  if (!has) missing.push(f + (lines3[0] && lines3[1] ? ' (terms line)' : '')); }
ok(missing.length === 0, 'every source file and script has the three-line header (SPDX id, Required Notice, terms line with ' + URL_ + '): missing in ' + missing.slice(0, 8).join(', ') + (missing.length > 8 ? ' ...' : ''));
ok(bare.length === 0 && KERNELS.every(k => all.includes(k)), 'the three kernel files are exactly the files without a header (a header would change the speed test\'s fingerprint): ' + bare.join(','));
ok(all.filter(f => SRC.test(f)).length > 150, 'and the walk saw the whole tree (' + all.filter(f => SRC.test(f)).length + ' scripts and sources)');
// 5. the downloadable scripts carry the notice inside the app (the *SelfcheckSource.js mirrors hold them as strings)
const mirrors = all.filter(f => /SelfcheckSource\.js$/.test(f)), texts = [];
for (const f of mirrors) for (const l of rd(f).split('\n')) { const m = /^export const \w+ = ("(?:[^"\\]|\\.)*");?$/.exec(l); if (m) texts.push([f, JSON.parse(m[1])]); }
ok(mirrors.length === 25 && texts.length >= 26, 'twenty-five mirror modules hold the downloadable scripts (' + mirrors.length + ' modules, ' + texts.length + ' scripts)');
ok(texts.every(([, t]) => t.split('\n').slice(0, 6).join('\n').includes(SPDX) && t.includes(NOTICE) && t.includes(URL_) && t.split('\n').slice(0, 6).join('\n').includes(TERMS)),'every downloadable script carries the notice, the SPDX id and the terms address: ' + texts.filter(([, t]) => !t.includes(SPDX)).map(x => x[0]).join(','));
// the mirror equals the file it mirrors, so a download is the shipped script
const pyFiles = all.filter(f => f.endsWith('.py')).map(f => [f, rd(f)]);
ok(texts.every(([, t]) => pyFiles.some(([, p]) => p === t)), 'every mirrored script equals one of the shipped .py files: ' + texts.filter(([, t]) => !pyFiles.some(([, p]) => p === t)).map(x => x[0]).join(','));
// 6. the app shows it, in both languages
for (const l of ['en', 'it']) { const c = MAP[l].credit;
  ok(/PolyForm Noncommercial License 1\.0\.0/.test(c.licence) && /2026/.test(c.licence) && /Cascade Atlas/.test(c.licence) && /(contact form|modulo di contatto)/.test(c.licence), l + ': the Map credit states the licence, the year, the authors and where to ask');
  ok(/2026/.test(MAP[l].licenceFooter) && /Cascade Atlas/.test(MAP[l].licenceFooter) && /(noncommercial|non commerciali)/.test(MAP[l].licenceFooter), l + ': the footer line is there'); }
const app = rd('App.jsx'), ms = rd('MapSection.jsx');
ok(/licence-note/.test(app) && /licenceFooter/.test(app) && /map-licence/.test(ms) && ms.includes(URL_), 'App.jsx renders the footer line and MapSection.jsx the licence paragraph with the terms link');
// 7. the owner's address is nowhere (contact goes through the form; the address lives in the form service and in an environment variable)
const EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}/g, TEXTY = /\.(js|jsx|mjs|cjs|py|sh|md|json|html|txt|css|svg)$|^LICENSE$|^NOTICE$/;
// (addresses on the reserved example domains are test fixtures, never a person's)
const RESERVED = /@([A-Za-z0-9-]+\.)*(example\.(com|org|net)|[A-Za-z0-9-]+\.invalid|example|invalid|test|localhost)$/i;
const mails = []; for (const f of all) { if (!TEXTY.test(f)) continue; const t = rd(f); for (const m of t.matchAll(EMAIL)) if (!RESERVED.test(m[0].slice(m[0].indexOf('@')))) mails.push(f + ': ' + m[0]); }
ok(mails.length === 0, 'no e-mail address in any shipped file (apart from reserved example domains in test fixtures): ' + mails.slice(0, 5).join(' | '));
// ... nor inside a shipped zip (reports/zips/ holds the six reports, each with its page): every member is read (a small reader of the zip format, stored or deflated members),
// text members are scanned for addresses and mail links, and a script inside a zip carries the same three-line header as one outside
const readZip = file => { const b = fs.readFileSync(file), out = []; let e = b.length - 22; while (e >= 0 && b.readUInt32LE(e) !== 0x06054b50) e--; if (e < 0) return null;
  let p = b.readUInt32LE(e + 16); const n = b.readUInt16LE(e + 10);
  for (let i = 0; i < n; i++) { if (b.readUInt32LE(p) !== 0x02014b50) return null; const meth = b.readUInt16LE(p + 10), csz = b.readUInt32LE(p + 20), nl = b.readUInt16LE(p + 28), xl = b.readUInt16LE(p + 30), cl = b.readUInt16LE(p + 32), lho = b.readUInt32LE(p + 42);
    const name = b.toString('utf8', p + 46, p + 46 + nl), ds = lho + 30 + b.readUInt16LE(lho + 26) + b.readUInt16LE(lho + 28), raw = b.subarray(ds, ds + csz);
    if (!name.endsWith('/')) out.push({ name, data: meth === 8 ? zlib.inflateRawSync(raw) : meth === 0 ? raw : null }); p += 46 + nl + xl + cl; }
  return out; };
const zips = all.filter(f => f.endsWith('.zip')), zipBad = [], zipMails = [], zipBare = []; let zipMembers = 0;
for (const z of zips) { const ms = readZip(path.join(here, z)); if (!ms || ms.some(m => !m.data)) { zipBad.push(z); continue; }
  for (const m of ms) { zipMembers++; const zn = z + ':' + m.name;
    if (TEXTY.test(path.basename(m.name))) { const t = m.data.toString('utf8'); for (const x of t.matchAll(EMAIL)) if (!RESERVED.test(x[0].slice(x[0].indexOf('@')))) zipMails.push(zn + ': ' + x[0]); if (t.toLowerCase().includes('mail' + 'to:')) zipMails.push(zn + ': mail link'); }
    if (SRC.test(m.name) && ![SPDX, NOTICE, TERMS].every(x => m.data.toString('utf8').split('\n').slice(0, 6).join('\n').includes(x))) zipBare.push(zn); } }
ok(zipBad.length === 0 && (zips.length === 0 || zipMembers > 0), 'every shipped zip can be read member by member (' + zips.length + ' zips, ' + zipMembers + ' members): ' + zipBad.join(', '));
ok(zipMails.length === 0, 'no e-mail address and no mail link inside any member of a shipped zip: ' + zipMails.slice(0, 5).join(' | '));
ok(zipBare.length === 0, 'every script inside a shipped zip carries the three-line header too: ' + zipBare.slice(0, 5).join(', '));
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL LICENCE TESTS PASS'); process.exit(bad ? 1 : 0);
