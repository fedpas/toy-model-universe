// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML, SHOTS } from './paths.mjs';
import { eqNavIds, stepCount } from './steps.js';
import { chromium } from 'playwright';
import { setLang, tab, tabTo } from './ui_helpers.mjs';
const b=await chromium.launch();const errs=[];
const C=(n,k)=>{if(k<0||k>n)return 0;let r=1;for(let i=0;i<k;i++)r=r*(n-i)/(i+1);return Math.round(r);};
const CL={4:[6,12,3],5:[10,30,15],2:[1,0,0],3:[3,3,0],6:[15,60,45],7:[21,105,105],8:[28,168,210]};
for(const lang of ['en','it']) for(const w of [1100,375]){
 const pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push(`${lang}${w}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${lang}${w} console: ${m.text()}`));
 await pg.goto(APP_HTML + '#equations/grav1');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 // v9: the formal checks below run for the Physicist (the default audience is the Young Learner, whose page now keeps the tables in the
 // closed "For older readers" fold); the Young Learner has its own checks at the end of this loop
 await pg.locator('[data-profile="Physicist"]').click();
 await pg.waitForTimeout(200);
 const nav=await pg.locator('.tabbar [role=tab]').count(); if(nav!==eqNavIds().length)errs.push(`${lang}${w}: nav ${nav}`);
 // ---------- gravity I
 const r1=await pg.locator('#eq-grav1 .gv-table tbody tr').count(); if(r1!==7)errs.push(`${lang}${w}: g1 ladder rows ${r1}`);
 const i1=await pg.locator('#eq-grav1 .gv-id tbody tr').count(); if(i1!==4)errs.push(`${lang}${w}: g1 identity rows ${i1}`);
 const t1=await pg.locator('#eq-grav1 .gv-id td').filter({hasText:'✓'}).count(); if(t1!==16)errs.push(`${lang}${w}: g1 ticks ${t1}`);
 const ch=pg.locator('#eq-grav1 .gv-chip'); if(await ch.count()!==7)errs.push('g1 chips '+await ch.count());
 for(let n=2;n<=8;n++){
  await ch.nth(n-2).click();
  const v=await pg.locator('#eq-grav1 .gv-view').count(); if(v!==7)errs.push(`${lang}${w} g1 n=${n}: ${v} views`);
  const on=await pg.locator('#eq-grav1 .gv-table tbody tr.on td').first().textContent(); if(+on!==n)errs.push(`${lang}${w} g1 n=${n}: row ${on}`);
  const txt=await pg.locator('#eq-grav1').textContent(); if(/undefined|NaN|\[object/.test(txt))errs.push(`${lang}${w} g1 n=${n}: placeholder`);
  const P=C(n,2), cells=await pg.locator('#eq-grav1 .gv-cell').count(); if(cells!==P*(P+1)/2)errs.push(`${lang}${w} g1 n=${n}: ${cells} cells`);
  const [dg,one,dis]=CL[n];
  for(const [c,want] of [['diagonal',dg],['one',one],['disjoint',dis]]){ const got=await pg.locator(`#eq-grav1 .gv-cell[data-class="${c}"]`).count(); if(got!==want)errs.push(`${lang}${w} g1 n=${n}: class ${c} ${got} want ${want}`); }
  const btns=pg.locator('#eq-grav1 .gv-cls'); if(await btns.count()!==4)errs.push('class buttons');
  await btns.nth(2).click(); const hi=await pg.locator('#eq-grav1 .gv-cell[data-on="1"]').count(); if(hi!==one)errs.push(`${lang}${w} g1 n=${n}: one-class highlight ${hi} want ${one}`);
  await btns.nth(3).click(); const hd=await pg.locator('#eq-grav1 .gv-cell[data-on="1"]').count(); if(hd!==dis)errs.push(`${lang}${w} g1 n=${n}: disjoint highlight ${hd} want ${dis}`);
  await btns.nth(0).click(); const ha=await pg.locator('#eq-grav1 .gv-cell[data-on="1"]').count(); if(ha!==P*(P+1)/2)errs.push(`${lang}${w} g1 n=${n}: all highlight ${ha}`);
  const sel=pg.locator('#eq-grav1 .gv-sub');
  if(n>=4){ const no=await sel.locator('option').count(); if(no!==1+C(n,4))errs.push(`${lang}${w} g1 n=${n}: ${no} subset options want ${1+C(n,4)}`);
    await sel.selectOption({index:1}); const h3=await pg.locator('#eq-grav1 .gv-cell[data-on="1"]').count(); if(h3!==3)errs.push(`${lang}${w} g1 n=${n}: subset highlights ${h3}`);
    const cls3=await pg.locator('#eq-grav1 .gv-cell[data-on="1"][data-class="disjoint"]').count(); if(cls3!==3)errs.push(`${lang}${w} g1 n=${n}: subset cells not disjoint-class`);
    await sel.selectOption({index:no-1}); const h3b=await pg.locator('#eq-grav1 .gv-cell[data-on="1"]').count(); if(h3b!==3)errs.push(`${lang}${w} g1 n=${n}: last subset ${h3b}`);
    await sel.selectOption({index:0});
  } else if(await sel.count()!==0)errs.push(`g1 n=${n}: subset selector should be absent`);
 }
 await tab(pg,'grav2');
 // ---------- gravity II
 const r2=await pg.locator('#eq-grav2 .gv-table2 tbody tr').count(); if(r2!==7)errs.push(`${lang}${w}: g2 ladder rows ${r2}`);
 const i2=await pg.locator('#eq-grav2 .gv-id2 tbody tr').count(); if(i2!==5)errs.push(`${lang}${w}: g2 identity rows ${i2}`);
 const t2=await pg.locator('#eq-grav2 .gv-id2 td').filter({hasText:'✓'}).count(); if(t2!==8)errs.push(`${lang}${w}: g2 ticks ${t2}`);
 const d2=await pg.locator('#eq-grav2 .gv-ds tbody tr').count(); if(d2!==4)errs.push(`${lang}${w}: g2 de Sitter rows ${d2}`);
 const ch2=pg.locator('#eq-grav2 .gv-chip2'); if(await ch2.count()!==7)errs.push('g2 chips '+await ch2.count());
 for(let n=2;n<=8;n++){
  await ch2.nth(n-2).click();
  const v=await pg.locator('#eq-grav2 .gv-view2').count(); if(v!==7)errs.push(`${lang}${w} g2 n=${n}: ${v} views`);
  const on=await pg.locator('#eq-grav2 .gv-table2 tbody tr.on td').first().textContent(); if(+on!==n)errs.push(`${lang}${w} g2 n=${n}: row ${on}`);
  const txt=await pg.locator('#eq-grav2').textContent(); if(/undefined|NaN|\[object/.test(txt))errs.push(`${lang}${w} g2 n=${n}: placeholder`);
  const ed=await pg.locator('#eq-grav2 svg .gv-edge').count(), want=C(n-1,2); if(ed!==want)errs.push(`${lang}${w} g2 n=${n}: ${ed} edges want ${want}`);
  const na=await pg.locator('#eq-grav2 .gv-achip').count(); if(na!==n)errs.push(`${lang}${w} g2 n=${n}: ${na} index buttons`);
  const nn=await pg.locator('#eq-grav2 svg .gv-node').count(); if(nn!==n)errs.push(`${lang}${w} g2 n=${n}: ${nn} nodes`);
  if(want>0){ await pg.locator('#eq-grav2 .gv-edge-hit').first().dispatchEvent('click');
    const rest=await pg.locator('#eq-grav2 svg .gv-rest').count(); if(rest!==n-3)errs.push(`${lang}${w} g2 n=${n}: ${rest} tetrad axes want ${n-3}`);
    const pr=await pg.locator('#eq-grav2 svg .gv-pair').count(); if(pr!==2)errs.push(`${lang}${w} g2 n=${n}: ${pr} pair nodes`);
    const on1=await pg.locator('#eq-grav2 svg .gv-edge.on').count(); if(on1!==1)errs.push(`${lang}${w} g2 n=${n}: selected edge ${on1}`);
    await pg.locator('#eq-grav2 .gv-achip').nth(n-1).click(); const ed2=await pg.locator('#eq-grav2 svg .gv-edge').count(); if(ed2!==want)errs.push(`${lang}${w} g2 n=${n}: edges after index change ${ed2}`);
    const rest2=await pg.locator('#eq-grav2 svg .gv-rest').count(); if(rest2>n-3)errs.push('selection should not leak across index change');
  }
 }
 await tab(pg,'grav1'); await ch.nth(2).click(); await tab(pg,'grav2'); await ch2.nth(2).click();
 // keyboard (v9): an edge of the term ring is reached with Tab and chosen with Enter; a ladder row is chosen with Enter
 if(!(await tabTo(pg,'#eq-grav2 .gv-achip','#eq-grav2 .gv-edge-hit',40)))errs.push(`${lang}${w}: no edge reachable with Tab`);
 else { await pg.keyboard.press('Enter'); await pg.waitForTimeout(60); if(await pg.locator('#eq-grav2 svg .gv-edge.on').count()!==1||await pg.locator('#eq-grav2 svg .gv-pair').count()!==2)errs.push(`${lang}${w}: Enter did not choose an edge`); }
 await pg.locator('#eq-grav2 details:has(.gv-table2)').evaluate(d=>{d.open=true;});
 if(!(await tabTo(pg,'#eq-grav2 details:has(.gv-table2) > summary','#eq-grav2 .gv-table2 tbody tr',10)))errs.push(`${lang}${w}: no gravity II row reachable with Tab`);
 else { await pg.keyboard.press('Tab'); await pg.keyboard.press(' '); await pg.waitForTimeout(60); const onK=await pg.locator('#eq-grav2 .gv-table2 tbody tr.on td').first().textContent(); if(+onK!==3)errs.push(`${lang}${w}: Space on the second gravity II row chose n=${onK}`); }
 await ch2.nth(2).click();
 const ov=await pg.evaluate(()=>document.documentElement.scrollWidth-window.innerWidth);if(ov>2)errs.push(`${lang}${w}: overflow ${ov}`);
 if(w===1100&&lang==='en'){ await tab(pg,'grav1'); await ch.nth(3).click(); await pg.locator('#eq-grav1 .gv-sub').selectOption({index:3}); await pg.locator('#eq-grav1').screenshot({path:SHOTS + '/gv1_en_wide.png'}); await tab(pg,'grav2'); await ch2.nth(2).click(); await pg.locator('#eq-grav2 .gv-edge-hit').first().dispatchEvent('click'); await pg.locator('#eq-grav2').screenshot({path:SHOTS + '/gv2_en_wide.png'}); }
 // v9, Young Learner: the same pictures and clicks with plain captions, and the tables inside one closed "For older readers" fold on each step
 await pg.locator('[data-profile="Young Learner"]').click(); await pg.waitForTimeout(150);
 const ylFold=async(s,tb)=>{ const fold=await pg.evaluate(([s,tb])=>{ const ds=[...document.querySelectorAll(s+' details')].filter(d=>!d.parentElement.closest(s+' details')&&d.querySelector(tb)); return ds.length===1?[ds[0].open,ds[0].querySelector(':scope > summary').textContent]:null; },[s,tb]);
   if(!fold||fold[0]||!/older readers|lettori più grandi/.test(fold[1]))errs.push(`${lang}${w} YL ${s}: the tables should sit in one closed fold for older readers (${fold})`); };
 await tab(pg,'grav1'); await ch.nth(2).click(); await ylFold('#eq-grav1','.gv-table');
 { const cells=await pg.locator('#eq-grav1 .gv-cell').count(); if(cells!==21)errs.push(`${lang}${w} YL g1: ${cells} cells`);
   const cap=await pg.locator('#eq-grav1 .gv-cap').textContent(); if(!cap.includes('21 − 1 = 20')||/Bianchi|commutator|demicube|\(a b \|/i.test(cap))errs.push(`${lang}${w} YL g1: caption "${cap}"`);
   await pg.locator('#eq-grav1 .gv-sub').selectOption({index:1}); const h=await pg.locator('#eq-grav1 .gv-cell[data-on="1"][data-class="disjoint"]').count(); const sc=await pg.locator('#eq-grav1 .gv-selcap').textContent();
   if(h!==3||/\||R\(|=/.test(sc))errs.push(`${lang}${w} YL g1: four-direction selection ${h} cells, caption "${sc}"`); await pg.locator('#eq-grav1 .gv-sub').selectOption({index:0}); }
 await tab(pg,'grav2'); await ch2.nth(2).click(); await pg.locator('#eq-grav2 .gv-edge-hit').first().dispatchEvent('click');
 { const sc=await pg.locator('#eq-grav2 .gv-selcap').textContent(); if(await pg.locator('#eq-grav2 svg .gv-pair').count()!==2||/F\^|\{|tetrad/i.test(sc))errs.push(`${lang}${w} YL g2: selection caption "${sc}"`); }
 await ylFold('#eq-grav2','.gv-table2');
 await pg.close();}
await b.close();console.log(errs.length?errs:'GRAVITY UI OK');
process.exit(errs.length?1:0);   // v9: a failure also sets the exit code
