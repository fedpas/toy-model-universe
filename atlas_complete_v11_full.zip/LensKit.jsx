// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { STORY } from './storyCopy.js';
import { Tx } from './MathText.jsx';
import { MATRIX_ROWS } from './translationMatrixData.js';
import { Tags } from './StatusBadge.jsx';
export { Tags };

// Shared pieces of the three chapters of the lenses page (category, Baez, Schuller), so that they draw their statements, their check scripts and their
// pictures the same way. Nothing here is specific to one chapter.
//  - Tags / Pts: a tagged statement. A point is <div class="eq-pt"><div>tags</div><p>text</p></div>, the markup the reader filter (readerFilter.js, LINES) already
//    knows: a point whose tags are standard + checked and neither ours nor open is known ground and the filter can hide it. A chapter that draws a statement
//    in some other shape must still put its tags in a line the filter knows (test_filter_ui.mjs checks every tag of every page, tab and audience).
//  - Finding: a numbered finding of a report (id, tags, title, text, the ids of the checks that carry it).
//  - ScriptBox: the download / copy buttons of a check script whose text is embedded in a *SelfcheckSource.js module.
export const download = (name, text, type = 'text/plain') => { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } };
export const copyText = async (text, done) => { try { await navigator.clipboard.writeText(text); done(true); } catch (e) { done(false); } };

// kinds may be an array or a space-separated string ('checked standard')
const kindsOf = k => (Array.isArray(k) ? k : String(k || '').split(/\s+/)).filter(Boolean);
export const Pts = ({ items, lang }) => <div>{items.map(([ks, txt], i) => <div key={i} className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={kindsOf(ks)} lang={lang} /></div><p><Tx>{txt}</Tx></p></div>)}</div>;
export const Finding = ({ f, lang, label = 'Checks' }) => <div className="eq-pt ln-find" id={f.anchor || undefined} data-finding={f.id}><div style={{ minWidth: 92 }}><Tags kinds={kindsOf(f.kinds)} lang={lang} /></div>
  <div><p className="ln-ft"><code className="ln-id">{f.id}</code> <b><Tx>{f.title}</Tx></b></p><p><Tx>{f.text}</Tx></p>{f.checks && f.checks.length ? <p className="ln-chk"><span className="ln-k">{label}</span> {f.checks.map(c => <code key={c} className="ln-id">{c}</code>)}</p> : null}</div></div>;
// one line at the end of a chapter: the full report of the package, one self-contained page (reports/html/<file>.html next to the app)
export const ReportLink = ({ r }) => (r ? <p className="ln-cap" data-report-link={r.file}><Tx>{r.lead}</Tx> <a href={r.file} target="_blank" rel="noopener"><Tx>{r.title}</Tx></a> (<code>{r.file}</code>)</p> : null);
export function ScriptBox({ lang, file, text, labels, note }) {
  const [state, setState] = React.useState('');
  const L = labels || { download: lang === 'it' ? 'Scarica lo script' : 'Download the script', copy: lang === 'it' ? 'Copia' : 'Copy', copied: lang === 'it' ? 'Copiato' : 'Copied', failed: lang === 'it' ? 'Copia non riuscita' : 'Copy failed', run: lang === 'it' ? 'Eseguilo con' : 'Run it with' };
  return <div className="ln-script"><p className="ln-mono"><code>{file}</code> · {Math.round(text.length / 1000)} kB · {text.split('\n').length} {lang === 'it' ? 'righe' : 'lines'}</p>
    <button type="button" className="ln-btn" data-download={file} onClick={() => download(file.split('/').pop(), text, 'text/x-python')}>{L.download}</button>
    <button type="button" className="ln-btn" data-copy={file} onClick={() => copyText(text, ok => { setState(ok ? 'ok' : 'bad'); setTimeout(() => setState(''), 1800); })}>{L.copy}</button>
    <span className={'ln-state ' + state} role="status">{state === 'ok' ? L.copied : state === 'bad' ? L.failed : ''}</span>
    {note ? <p className="ln-cap"><Tx>{note}</Tx></p> : null}</div>;
}
// The honesty bar of a chapter: its rows of the translation matrix counted by their best grade (E exact, else S same structure, else A our reading, else nothing).
// voice 'yl' says it in plain words, 'formal' with the grades. Not a tag (the grades are not the four statuses), so no element carries a "tag" class.
export const bestGrades = source => { const c = { E: 0, S: 0, A: 0, none: 0 }; for (const r of MATRIX_ROWS.filter(x => x.src === source)) { const g = Object.values(r.cells).map(x => x.grade); c[g.includes('E') ? 'E' : g.includes('S') ? 'S' : g.includes('A') ? 'A' : 'none']++; } return c; };
const HB = {
  en: { yl: ['exactly the same', 'same shape', 'our reading', 'nothing there'], formal: ['E exact', 'S structural', 'A analogy', 'no cell (gap)'], head: n => `${n} items of the report, each counted once, by the best match it has`, headYl: n => `${n} things from the papers, each counted once by its best match` },
  it: { yl: ['esattamente uguale', 'stessa forma', 'la nostra lettura', 'niente'], formal: ['E esatta', 'S strutturale', 'A analogia', 'nessuna cella (lacuna)'], head: n => `${n} voci del rapporto, ognuna contata una volta, con il suo miglior accordo`, headYl: n => `${n} cose dei lavori, ognuna contata una volta con il suo miglior accordo` },
};
export function HonestyBar({ lang = 'en', source, voice = 'formal' }) {
  const L = lang === 'it' ? 'it' : 'en', c = bestGrades(source), n = c.E + c.S + c.A + c.none, lab = HB[L][voice === 'yl' ? 'yl' : 'formal'], cols = ['#34d399', '#60a5fa', '#fbbf24', 'rgba(128,128,128,.55)'];
  return <figure className="ln-hb" data-hb={`${c.E},${c.S},${c.A},${c.none}`} style={{ margin: '10px 0' }}>
    <figcaption className="ln-cap">{voice === 'yl' ? HB[L].headYl(n) : HB[L].head(n)}</figcaption>
    <div role="img" aria-label={['E', 'S', 'A', 'none'].map((k, i) => `${lab[i]}: ${c[k]}`).join(', ')} style={{ display: 'flex', height: 14, borderRadius: 7, overflow: 'hidden', gap: 2 }}>{['E', 'S', 'A', 'none'].map((k, i) => c[k] ? <span key={k} style={{ flex: c[k], background: cols[i] }} /> : null)}</div>
    <p className="ln-cap">{['E', 'S', 'A', 'none'].map((k, i) => <span key={k} style={{ marginRight: 12 }}><b style={{ color: cols[i] }}>{c[k]}</b> {lab[i]}</span>)}</p></figure>;
}
// common look of the three chapters; each chapter adds its own prefix (ct- category, bz- Baez, sc- Schuller) for what is specific to it
export const KIT_STYLE = `
.ln{max-width:1000px;margin:18px auto;padding:0 16px}.ln .eyebrow{margin:0 0 .3em}.ln .lede{margin:.5em 0}.ln h3{margin:1.3em 0 .4em;font-size:1.1em}.ln h4{margin:.9em 0 .3em;font-size:.95em}
.ln .eq-pt{display:flex;gap:10px;margin:8px 0}.ln .eq-pt p{margin:0 0 .3em;min-width:0;overflow-wrap:anywhere}.ln .eq-pt>div:last-child{min-width:0;flex:1}
.ln-card{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:12px 14px;margin:14px 0}.ln-card h3,.ln-card h4{margin-top:.1em}
.ln-row{display:flex;flex-wrap:wrap;gap:14px}.ln-col{flex:1 1 280px;min-width:0}.ln-wide{flex:2 1 340px;min-width:0}
.ln-svg{width:100%;max-width:520px;display:block;margin:6px auto;height:auto}
.ln-menu{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0}.ln-menu a,.ln-menu button{background:none;border:1px solid rgba(128,128,128,.45);border-radius:999px;padding:3px 11px;color:inherit;cursor:pointer;font:inherit;font-size:.85em;text-decoration:none}
.ln-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.ln-chip{background:none;border:1px solid rgba(128,128,128,.45);border-radius:999px;padding:3px 11px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}.ln-chip.on,.ln-chip[aria-pressed=true]{background:rgba(80,170,255,.22);border-color:#4aa8ff}
.ln-btn{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:5px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em;margin:4px 8px 4px 0}
.ln-menu a:focus-visible,.ln-menu button:focus-visible,.ln-chip:focus-visible,.ln-btn:focus-visible,.ln-sl input:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.ln-sl{display:grid;grid-template-columns:minmax(70px,1.2fr) 3fr 4ch;gap:8px;align-items:center;font-size:.85em;margin:4px 0}.ln-sl input{width:100%;min-width:0}
.ln-cap{font-size:.8em;opacity:.8;margin:.4em 0}.ln-mono{font-family:ui-monospace,monospace;font-size:.82em;overflow-wrap:anywhere;margin:.4em 0}.ln-state{font-size:.8em;margin-left:6px}.ln-state.ok{color:#34d399}.ln-state.bad{color:#f87171}
.ln-id{font-family:ui-monospace,monospace;font-size:.82em;margin-right:6px;overflow-wrap:anywhere}.ln-k{opacity:.7;font-size:.8em;letter-spacing:.04em;margin-right:6px}.ln-chk{font-size:.85em}
.ln-live{display:inline-block;font-size:.72em;opacity:.65;border:1px dashed rgba(128,128,128,.5);border-radius:6px;padding:0 6px;margin-top:2px}.ln-ok{color:#34d399}.ln-bad{color:#f87171}
.ln-tab{border-collapse:collapse;width:100%;font-size:.84em}.ln-tab th{text-align:left;font-weight:500;opacity:.75;padding:3px 8px 3px 0;vertical-align:top}.ln-tab td{padding:3px 0;overflow-wrap:anywhere}
.ln-wrap{overflow-x:auto;max-width:100%}
@media(max-width:560px){.ln .eq-pt{flex-direction:column;gap:2px}}
`;
