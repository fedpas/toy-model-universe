// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Step 18 of the atlas (the category lens: what is label 0?): the engine behind the five widgets CW1 ... CW5 of CategoryWidgets.jsx. No React here.
// Everything is computed in the browser from the bit rule  e_a e_b = s(a,b) e_{a xor b}  (labelsEngine.bladeMul; a generator may square to +1, -1 or 0, and a
// product that squares a null generator is 0) with exact integers (BigInt where numbers grow) and exact fractions. The reference is
// selfcheck/reports/lens_cat_check.py (checks P1 ... P6); test_lens_category_widgets.mjs compares every number below with the stored output of that script.
// Label 0 = a generator whose square is 0; the empty label (bit mask 0) is the unit 1.
import { bladeMul, popcount as pc, sigVec, clockOf, TYPES } from './labelsEngine.js';

export { pc };
// ---------------------------------------------------------------- signatures
export const sigOf = (p, q, r = 0) => sigVec(p, q, r);
export const pqrOf = eps => ({ p: eps.filter(x => x === 1).length, q: eps.filter(x => x === -1).length, r: eps.filter(x => x === 0).length });
export const nullMask = eps => eps.reduce((m, e, i) => (e === 0 ? m | (1 << i) : m), 0);
export const triples = n => { const o = []; for (let p = 0; p <= n; p++) for (let q = 0; q <= n - p; q++) o.push([p, q, n - p - q]); return o; };
export const clockPlace = eps => { const { p, q } = pqrOf(eps); return clockOf(p, q); };
export const binom = (n, k) => { if (k < 0 || k > n) return 0; let b = 1; for (let i = 1; i <= k; i++) b = b * (n - k + i) / i; return Math.round(b); };
const bm = (a, b, eps) => bladeMul(a, b, eps);   // [label, sign]; sign 0 when a shared generator squares to 0
export const labelName = (m, n) => (m === 0 ? '1' : 'e' + Array.from({ length: n }, (_, i) => (m >> i & 1 ? String(i + 1) : '')).join(''));
export const bits = (m, n) => Array.from({ length: n }, (_, i) => (m >> i & 1 ? '1' : '0')).join('');

// ---------------------------------------------------------------- exact helpers
const babs = x => (x < 0n ? -x : x);
const bgcd = (a, b) => { a = babs(a); b = babs(b); while (b) [a, b] = [b, a % b]; return a; };
// exact rank over Q of sparse integer rows (arrays of [column, value]); fraction-free elimination, each new row reduced by gcd
export function rankQ(rows) {
  const piv = new Map();
  for (const r0 of rows) {
    let r = new Map(r0.filter(([, v]) => v !== 0 && v !== 0n).map(([c, v]) => [c, BigInt(v)]));
    while (r.size) {
      const c = Math.min(...r.keys());
      if (!piv.has(c)) { let g = 0n; for (const v of r.values()) g = bgcd(g, v); if (g > 1n) for (const [k, v] of r) r.set(k, v / g); piv.set(c, r); break; }
      const P = piv.get(c), a = r.get(c), b = P.get(c), out = new Map();
      for (const [k, v] of r) out.set(k, v * b);
      for (const [k, v] of P) { const w = (out.get(k) || 0n) - v * a; if (w === 0n) out.delete(k); else out.set(k, w); }
      r = out;
    }
  }
  return piv.size;
}
// exact determinant of an integer matrix by Bareiss (BigInt)
export function bareiss(M) {
  const A = M.map(row => row.map(x => BigInt(x))), n = A.length; let sgn = 1n, prev = 1n;
  if (!n) return 1n;
  for (let k = 0; k < n - 1; k++) {
    if (A[k][k] === 0n) { const sw = A.findIndex((row, i) => i > k && row[k] !== 0n); if (sw < 0) return 0n; [A[k], A[sw]] = [A[sw], A[k]]; sgn = -sgn; }
    for (let i = k + 1; i < n; i++) for (let j = k + 1; j < n; j++) A[i][j] = (A[i][j] * A[k][k] - A[i][k] * A[k][j]) / prev;
    prev = A[k][k];
  }
  return sgn * A[n - 1][n - 1];
}
// fractions over BigInt (normalised: denominator > 0, gcd 1)
const fr = (n, d = 1n) => { if (d < 0n) { n = -n; d = -d; } const g = bgcd(n, d) || 1n; return [n / g, d / g]; };
const fsub = (x, y) => fr(x[0] * y[1] - y[0] * x[1], x[1] * y[1]);
const fadd = (x, y) => fr(x[0] * y[1] + y[0] * x[1], x[1] * y[1]);
const fmul = (x, y) => fr(x[0] * y[0], x[1] * y[1]);
const fdiv = (x, y) => fr(x[0] * y[1], x[1] * y[0]);
// exact inertia (positive, negative, zero) of a symmetric integer matrix by congruence diagonalisation (the algorithm of lens_cat_check.py)
export function inertia(G) {
  let A = G.map(row => row.map(x => fr(BigInt(x)))); let pos = 0, neg = 0, zer = 0;
  while (A.length) {
    const m = A.length; let k = A.findIndex((row, i) => row[i][0] !== 0n);
    if (k < 0) {
      let pr = null; for (let i = 0; i < m && !pr; i++) for (let j = i + 1; j < m; j++) if (A[i][j][0] !== 0n) { pr = [i, j]; break; }
      if (!pr) { zer += m; break; }
      const [i, j] = pr; for (let t = 0; t < m; t++) A[i][t] = fadd(A[i][t], A[j][t]); for (let t = 0; t < m; t++) A[t][i] = fadd(A[t][i], A[t][j]); k = i;
    }
    const pv = A[k][k]; if (pv[0] > 0n) pos++; else neg++;
    for (let i = 0; i < m; i++) if (i !== k && A[i][k][0] !== 0n) { const f = fdiv(A[i][k], pv); for (let t = 0; t < m; t++) A[i][t] = fsub(A[i][t], fmul(f, A[k][t])); for (let t = 0; t < m; t++) A[t][i] = fsub(A[t][i], fmul(f, A[t][k])); }
    A = A.filter((_, i) => i !== k).map(row => row.filter((_, j) => j !== k));
  }
  return [pos, neg, zer];
}
const rankF2 = rows => { const piv = new Map(); for (let v of rows) { while (v) { const h = 31 - Math.clz32(v); if (!piv.has(h)) { piv.set(h, v); break; } v ^= piv.get(h); } } return piv.size; };

// ================================================================ CW1: the label-0 card
// the label sets that span J, J^2, J^3, ... computed from products of labels (J is spanned by labels and a product of two labels is 0 or +- a label)
export function powers(eps, rad) {
  const out = []; let cur = new Set(rad);
  while (cur.size && out.length <= eps.length) { out.push(cur);   // a nilpotent ideal of labels dies within n + 1 steps; a longer list means it is not nilpotent
    const nx = new Set(); for (const a of cur) for (const b of rad) { const [c, s] = bm(a, b, eps); if (s) nx.add(c); } cur = nx; }
  return out;
}
// a label a is in the (super-)centre iff e_a e_i = (+-) e_i e_a for every generator i: the conditions on the coefficients do not mix labels (a -> a xor i is one-to-one),
// so both centres are spanned by labels and their dimension is the number of such labels
const commutes = (a, eps, graded) => eps.every((_, i) => { const [, s1] = bm(a, 1 << i, eps), [, s2] = bm(1 << i, a, eps); return s1 === (graded && pc(a) % 2 ? -1 : 1) * s2; });
export function labelCard(eps) {
  const n = eps.length, N = 1 << n, Z = nullMask(eps), { p, q, r } = pqrOf(eps);
  const J = []; for (let a = 0; a < N; a++) if (a & Z) J.push(a);
  const pw = powers(eps, J), layers = [N - J.length, ...pw.map((s, k) => s.size - (pw[k + 1] ? pw[k + 1].size : 0))];
  const sc = [], ce = []; for (let a = 0; a < N; a++) { if (commutes(a, eps, true)) sc.push(a); if (commutes(a, eps, false)) ce.push(a); }
  return { n, p, q, r, dim: N, Z, J: J.length, Jlabels: J, powers: pw.map(s => s.size), layers, loewy: pw.length + 1, sc: sc.length, scLabels: sc, centre: ce.length, centreLabels: ce,
    quotient: [p, q], type: TYPES[clockOf(p, q)], clock: clockOf(p, q), faceIsJ: r === 1,
    // what T2 says, beside what was computed
    t2: { J: N - 2 ** (p + q), layers: Array.from({ length: r + 1 }, (_, k) => binom(r, k) * 2 ** (p + q)), loewy: r + 1, sc: 2 ** r } };
}
// the product of the labels in the tray (in the order given): [label, sign]; sign 0 means "nothing"
export function trayProduct(labels, eps) { let m = 0, s = 1; for (const a of labels) { const [c, t] = bm(m, a, eps); m = c; s *= t; if (!s) return [c, 0]; } return [m, s]; }
// r + 1 labels holding a null bit always multiply to 0 (some null bit is used twice): every such choice among the first labels, counted (for the caption's claim)
export function trayAllZero(eps, k, limit = 4000) {
  const Z = nullMask(eps), J = []; for (let a = 0; a < (1 << eps.length); a++) if (a & Z) J.push(a);
  let tried = 0, zero = 0; const pick = (start, acc) => { if (tried >= limit) return; if (acc.length === k) { tried++; if (trayProduct(acc, eps)[1] === 0) zero++; return; } for (let i = start; i < J.length; i++) pick(i + 1, [...acc, J[i]]); };
  pick(0, []); return { tried, zero };
}

// ================================================================ CW2: every corner has an opposite (the complement pairing, a Frobenius duality)
// lambda(x) = coefficient of the full label F = 1...1
export function frobenius(eps) {
  const n = eps.length, N = 1 << n, F = N - 1, Z = nullMask(eps), { r } = pqrOf(eps);
  const lam = (a, b) => { const [c, s] = bm(a, b, eps); return c === F ? s : 0; };
  const pairs = []; for (let a = 0; a < N; a++) { const b = a ^ F; pairs.push({ a, b, ab: lam(a, b), ba: lam(b, a) }); }
  let supp = true; const lamRows = [];
  for (let a = 0; a < N; a++) { const row = []; for (let b = 0; b < N; b++) { const v = lam(a, b); if ((v !== 0) !== (b === (a ^ F))) supp = false; if (v) row.push([b, v]); } lamRows.push(row); }
  const ef = []; for (let a = 0; a < N; a++) ef.push(bm(F, a, eps));
  const sq = []; for (let a = 0; a < N; a++) sq.push(bm(a, a, eps)[1]);
  const rankLam = rankQ(lamRows), rankEF = rankQ(ef.filter(([, s]) => s).map(([c, s]) => [[c, s]])), rank0 = rankQ(sq.map((s, a) => [[a, s]]).filter(([[, s]]) => s));
  const anti = pairs.map(x => (x.ab > 0 ? '+' : '-')).join(''), nak = pairs.map(x => (x.ab * x.ba > 0 ? '+' : '-')).join('');
  const conj = []; for (let a = 0; a < N; a++) if (eps.every((_, i) => bm(a, 1 << i, eps)[1] + bm(1 << i, a, eps)[1] === 0)) conj.push(a);
  const cert = n % 2 === 1 && !nak.includes('-') && rankLam === N ? 'lambda' : r === 0 && rank0 === N ? 'scalar' : null;
  return { n, F, pairs, supp, rankLam, rankEF, rank0, omega2: bm(F, F, eps)[1], reach: ef.filter(([, s]) => s).length, anti, nak, conj, conjInJ: conj.every(a => a & Z), fair: cert !== null, cert, sq };
}

// ================================================================ CW3: four moves between boxes
// Join (double): the graded tensor product = concatenating the lists of generators; the Koszul sign rule checked on every label pair (cat K5a, here live)
export function join(e1, e2) {
  const n1 = e1.length, e = [...e1, ...e2]; let ok = true, count = 0;
  if (e.length <= 6) for (let a1 = 0; a1 < 1 << n1; a1++) for (let b1 = 0; b1 < 1 << e2.length; b1++) for (let a2 = 0; a2 < 1 << n1; a2++) for (let b2 = 0; b2 < 1 << e2.length; b2++) {
    const [x1, s1] = bm(a1, a2, e1), [x2, s2] = bm(b1, b2, e2), exp = (pc(b1) * pc(a2)) % 2 ? -s1 * s2 : s1 * s2, [c, s] = bm(a1 | (b1 << n1), a2 | (b2 << n1), e);
    count++; if (s !== exp || (exp !== 0 && c !== (x1 | (x2 << n1)))) ok = false;
  }
  return { eps: e, koszul: ok, pairs: count, clock: clockPlace(e), clockSum: (clockPlace(e1) + clockPlace(e2)) % 8 };
}
// Halve: the even part. With t of square +-1, f_i = e_i e_t (i != t) has square -eps_i eps_t and the f's generate the even part (an isomorphism, checked on all labels)
export function halveVia(eps, t) {
  const n = eps.length, others = [...Array(n).keys()].filter(i => i !== t), tgt = others.map(i => (-eps[i] * eps[t]) || 0);
  const img = b => { let s = 1, m = 0; others.forEach((i, k) => { if (b >> k & 1) { const [f, s1] = bm(1 << i, 1 << t, eps), [mm, s2] = bm(m, f, eps); m = mm; s *= s1 * s2; } }); return [s, m]; };
  const I = []; for (let b = 0; b < 1 << (n - 1); b++) I.push(img(b));
  let ok = I.every(([s, m]) => s !== 0 && pc(m) % 2 === 0) && new Set(I.map(([, m]) => m)).size === 1 << (n - 1);
  if (n <= 7) for (let x = 0; x < I.length; x++) for (let y = 0; y < I.length; y++) {
    const [c, s] = bm(x, y, tgt), [m3, s3] = bm(I[x][1], I[y][1], eps);
    if (s ? !(I[x][0] * I[y][0] * s3 === s * I[c][0] && m3 === I[c][1]) : s3 !== 0) ok = false;
  }
  return { ok, target: tgt, pqr: pqrOf(tgt) };
}
// the even part of the exterior algebra on r null generators: dimension, radical, Loewy length (from products)
export function lamEven(r) { const eps = Array(r).fill(0), ev = [], rad = []; for (let a = 0; a < 1 << r; a++) if (pc(a) % 2 === 0) { ev.push(a); if (a) rad.push(a); } return { r, dim: ev.length, rad: rad.length, loewy: powers(eps, rad).length + 1 }; }
export function halve(eps, pick = null) {
  const n = eps.length, { p, q, r } = pqrOf(eps);
  if (n === 0) return { ok: false, empty: true };
  const t = pick != null && eps[pick] !== 0 ? pick : eps.findIndex(e => e !== 0);
  if (t >= 0) { const h = halveVia(eps, t); return { ok: h.ok, t, kind: eps[t] === 1 ? 'plus' : 'minus', target: h.target, pqr: h.pqr }; }
  const L = lamEven(r);
  if (r <= 2) return { ok: true, t: null, kind: 'null', target: Array(r - 1).fill(0), pqr: { p: 0, q: 0, r: r - 1 }, lam: L };
  return { ok: false, jam: true, t: null, kind: 'null', lam: L, p, q, r };
}
// Restrict to a face T (a bit mask of generators): iota_T (inclusion of Cl(T)) and pi_T (keep the labels inside T, send the others to 0), both checked on every label pair
const compress = (a, T) => { let o = 0, k = 0; for (let i = 0; i < 31 && (T >> i); i++) if (T >> i & 1) { if (a >> i & 1) o |= 1 << k; k++; } return o; };
const expand = (b, T) => { let o = 0, k = 0; for (let i = 0; i < 31 && (T >> i); i++) if (T >> i & 1) { if (b >> k & 1) o |= 1 << i; k++; } return o; };
export function restrict(eps, T) {
  const n = eps.length, N = 1 << n, epsT = eps.filter((_, i) => T >> i & 1), NT = 1 << epsT.length; let iota = true, pi = true;
  for (let x = 0; x < NT && iota; x++) for (let y = 0; y < NT; y++) { const [c1, s1] = bm(expand(x, T), expand(y, T), eps), [c2, s2] = bm(x, y, epsT); if (s1 !== s2 || (s1 && c1 !== expand(c2, T))) { iota = false; break; } }
  const P = (c, s) => (s && !(c & ~T) ? [compress(c, T), s] : [0, 0]);
  for (let a = 0; a < N && pi; a++) for (let b = 0; b < N; b++) {
    const lhs = P(...bm(a, b, eps)), rhs = !(a & ~T) && !(b & ~T) ? (([c, s]) => (s ? [c, s] : [0, 0]))(bm(compress(a, T), compress(b, T), epsT)) : [0, 0];
    if (lhs[0] !== rhs[0] || lhs[1] !== rhs[1]) { pi = false; break; }
  }
  const outsideNull = eps.every((e, i) => (T >> i & 1) || e === 0), Z = nullMask(eps);
  return { eps: epsT, iota, pi, outsideNull, quotient: T === ((N - 1) ^ Z), kernel: N - NT };
}
// all choices of squares with n <= nmax and every face T: how often pi_T is a homomorphism, and whether that is exactly "every generator outside T is null" (catw P1)
export function restrictSurvey(nmax = 4) {
  let pairs = 0, homs = 0, agree = 0;
  for (let n = 0; n <= nmax; n++) for (let code = 0; code < 3 ** n; code++) {
    const eps = Array.from({ length: n }, (_, i) => [1, -1, 0][Math.floor(code / 3 ** i) % 3]);
    for (let T = 0; T < 1 << n; T++) { const x = restrict(eps, T); pairs++; if (x.pi) homs++; if (x.pi === x.outsideNull && x.iota) agree++; }
  }
  return { pairs, homs, agree };
}
// Opposite: a -> a xor F reverses inclusion (a inside b iff the complement of b is inside the complement of a), checked on all pairs
export function complementReverses(n) { const N = 1 << n, F = N - 1; for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) if (((a & b) === a) !== (((b ^ F) & (a ^ F)) === (b ^ F))) return false; return true; }

// ================================================================ CW4: the top of the ladder, E_3 ... E_20
// nodes: 0 = the short arm (branch); then the chain: far and near node of the two-node arm, the centre, the long arm outwards. E_3 = A2 x A1 (node 0 apart)
export function enGraph(n) { if (n === 3) return { nodes: 3, edges: [[1, 2]] }; const edges = [[1, 2], [2, 3], [0, 3]]; for (let k = 3; k < n - 1; k++) edges.push([k, k + 1]); return { nodes: n, edges }; }
export function cartanOf(nodes, edges, keep = null) {
  const K = keep || [...Array(nodes).keys()], ix = new Map(K.map((v, k) => [v, k])), C = K.map((_, i) => K.map((__, j) => (i === j ? 2 : 0)));
  for (const [i, j] of edges) if (ix.has(i) && ix.has(j)) { C[ix.get(i)][ix.get(j)] = -1; C[ix.get(j)][ix.get(i)] = -1; }
  return C;
}
const components = (keep, edges) => { const adj = new Map(keep.map(v => [v, []])); for (const [i, j] of edges) if (adj.has(i) && adj.has(j)) { adj.get(i).push(j); adj.get(j).push(i); } const seen = new Set(), out = []; for (const v of keep) { if (seen.has(v)) continue; const st = [v], cc = []; while (st.length) { const x = st.pop(); if (seen.has(x)) continue; seen.add(x); cc.push(x); st.push(...adj.get(x)); } out.push(cc.sort((a, b) => a - b)); } return out; };
const kindOf = (g, keep) => { const [a, b, c] = inertia(cartanOf(g.nodes, g.edges, keep)); return a === keep.length ? 'finite' : (a === keep.length - 1 && b === 0 && c === 1) ? 'affine' : 'indefinite'; };
export function nullRoot(C) {
  const n = C.length; let A = C.map(row => row.map(x => fr(BigInt(x)))); const piv = []; let rr = 0;
  for (let c = 0; c < n; c++) {
    const pr = A.findIndex((row, i) => i >= rr && row[c][0] !== 0n); if (pr < 0) continue;
    [A[rr], A[pr]] = [A[pr], A[rr]]; const iv = A[rr][c]; A[rr] = A[rr].map(x => fdiv(x, iv));
    for (let i = 0; i < n; i++) if (i !== rr && A[i][c][0] !== 0n) { const f = A[i][c]; A[i] = A[i].map((x, j) => fsub(x, fmul(f, A[rr][j]))); }
    piv.push(c); rr++;
  }
  const free = [...Array(n).keys()].filter(c => !piv.includes(c)); if (free.length !== 1) return null;
  const v = Array(n).fill(fr(0n)); v[free[0]] = fr(1n); piv.forEach((c, i) => { v[c] = fsub(fr(0n), A[i][free[0]]); });
  let L = 1n; for (const [, d] of v) L = L / bgcd(L, d) * d; let w = v.map(([a, d]) => a * (L / d)); let g = 0n; for (const x of w) g = bgcd(g, x); w = w.map(x => x / g); if (w[0] < 0n) w = w.map(x => -x);
  return w.map(Number);
}
// q(x) = x.x/2 mod 2 on E_n/2E_n, counted over all 2^n classes with a Gray code; radical of the mod-2 pairing
export function mod2Counts(n) {
  const g = enGraph(n), adj = Array(g.nodes).fill(0); for (const [i, j] of g.edges) { adj[i] |= 1 << j; adj[j] |= 1 << i; }
  let x = 0, qv = 0, q1 = 0, q0 = 0;
  for (let k = 1; k < 1 << g.nodes; k++) { const i = 31 - Math.clz32(k & -k); qv ^= (1 + pc(adj[i] & x)) & 1; x ^= 1 << i; if (qv) q1++; else q0++; }
  const C = cartanOf(g.nodes, g.edges), rows = C.map(row => row.reduce((m, v, j) => m | ((((v % 2) + 2) % 2) << j), 0));
  return { q1, q0, rad: g.nodes - rankF2(rows) };
}
// the same three numbers for the labels of Cl(n,0): square -1 (grade 2 or 3 mod 4), square +1 (not the unit), radical of the commutation form |a||b| + |a & b| mod 2
export function clCounts(n) { let q1 = 0; for (let k = 0; k <= n; k++) if (k % 4 === 2 || k % 4 === 3) q1 += binom(n, k); const B = []; for (let i = 0; i < n; i++) { let row = 0; for (let j = 0; j < n; j++) if ((1 + (i === j ? 1 : 0)) % 2) row |= 1 << j; B.push(row); } return { q1, q0: 2 ** n - 1 - q1, rad: n - rankF2(B) }; }
export function ladderRung(n, withMod2 = true) {
  const g = enGraph(n), C = cartanOf(g.nodes, g.edges), det = Number(bareiss(C)), s = inertia(C); let type = kindOf(g, [...Array(n).keys()]);
  if (type === 'indefinite') { let hyp = true; for (let v = 0; v < n && hyp; v++) for (const cc of components([...Array(n).keys()].filter(i => i !== v), g.edges)) if (kindOf(g, cc) === 'indefinite') { hyp = false; break; } type = hyp ? 'hyperbolic' : (s[0] === n - 1 && s[1] === 1) ? 'lorentzian' : 'indefinite'; }
  const out = { n, det, inertia: s, type, edges: g.edges, marks: n === 9 ? nullRoot(C) : null };
  if (withMod2) { const m = mod2Counts(n), c = clCounts(n); Object.assign(out, { q1: m.q1, q0: m.q0, rad: m.rad, cl_q1: c.q1, cl_q0: c.q0, cl_rad: c.rad }); }
  return out;
}
// (candidate catw P6) the null root of E_9 mod 2 and the two radicals
export function e9mod2() {
  const g = enGraph(9), C = cartanOf(9, g.edges), marks = nullRoot(C), m2 = marks.reduce((m, x, i) => m | ((x % 2) << i), 0);
  const rows = C.map(row => row.reduce((m, v, j) => m | ((((v % 2) + 2) % 2) << j), 0)), rad = [];
  for (let v = 1; v < 512; v++) if (rows.every(rw => pc(rw & v) % 2 === 0)) rad.push(v);
  const B = []; for (let i = 0; i < 9; i++) B.push(511 ^ (1 << i)); const crad = []; for (let a = 1; a < 512; a++) if (B.every(rw => pc(rw & a) % 2 === 0)) crad.push(a);
  const q = v => (pc(v) + g.edges.filter(([i, j]) => (v >> i & 1) && (v >> j & 1)).length) % 2;
  return { marks_mod2: marks.map(x => x % 2), radical: rad, cl_radical: crad, q: q(m2), Q: pc(511) % 4 >= 2 ? 1 : 0 };
}

// ================================================================ CW5: two kinds of zero
// a mix u = a e1 + b e2 in the box with one plus and one minus switch: u^2 by the bit rule (= a^2 - b^2)
const mvMul = (x, y, eps) => { const o = new Map(); for (const [a, ca] of x) for (const [b, cb] of y) { const [c, s] = bm(a, b, eps); if (s) o.set(c, (o.get(c) || 0) + s * ca * cb); } for (const [k, v] of [...o]) if (v === 0) o.delete(k); return o; };
const mvAdd = (x, y) => { const o = new Map(x); for (const [k, v] of y) { const w = (o.get(k) || 0) + v; if (w) o.set(k, w); else o.delete(k); } return o; };
export const asObj = m => Object.fromEntries([...m].sort((a, b) => a[0] - b[0]));
export function mixSquare(a, b) { const u = new Map([[1, a], [2, b]].filter(([, v]) => v)); return asObj(mvMul(u, u, [1, -1])); }
export function pairedZero() {
  const e = [1, -1], u = new Map([[1, 1], [2, 1]]), v = new Map([[1, 1], [2, -1]]), uv = mvMul(u, v, e), vu = mvMul(v, u, e);
  return { uu: asObj(mvMul(u, u, e)), vv: asObj(mvMul(v, v, e)), uv: asObj(uv), vu: asObj(vu), sum: asObj(mvAdd(uv, vu)) };
}
// a lone zero switch z (the last generator of eps, square 0) against every generator w: z w + w z is always nothing
export function loneZero(eps) { const n = eps.length, z = n - 1; return eps.map((_, i) => ({ i, sum: asObj(mvAdd(mvMul(new Map([[1 << z, 1]]), new Map([[1 << i, 1]]), eps), mvMul(new Map([[1 << i, 1]]), new Map([[1 << z, 1]]), eps))) })); }
export const STORED_SCRIPT = 'selfcheck/reports/lens_cat_check.py';

// ================================================================ CW6 (optional): sign the cube
// the 12 edges (a, i) of the 3-cube (i not in a), the 6 squares, the bit rule's own edge sign (-1)^{#bits of a below i} (cat K1b), and the gauge: an assignment
// with every square anticommuting is the rule's signs with the edges at some corners flipped (H^1 = 0, cat K1c); 128 such assignments (cat K1d)
export const cubeEdges = (n = 3) => { const E = []; for (let a = 0; a < 1 << n; a++) for (let i = 0; i < n; i++) if (!(a >> i & 1)) E.push([a, i]); return E; };
export const jwSign = (a, i) => (pc(a & ((1 << i) - 1)) % 2 ? -1 : 1);
export const cubeSquares = (n = 3) => { const S = []; for (let a = 0; a < 1 << n; a++) for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (!(a >> i & 1) && !(a >> j & 1)) S.push([a, i, j]); return S; };
const edgeKey = (a, i) => a * 8 + i;
export function squaresOdd(signs, n = 3) { const s = (a, i) => signs[edgeKey(a, i)]; return cubeSquares(n).map(([a, i, j]) => s(a, i) * s(a | (1 << i), j) * s(a, j) * s(a | (1 << j), i) === -1); }
export const ruleSigns = (n = 3) => Object.fromEntries(cubeEdges(n).map(([a, i]) => [edgeKey(a, i), jwSign(a, i)]));
// the corners whose three edges must be flipped to turn the rule's signs into these (corner 0 never flipped), or null if not every square anticommutes
export function gaugeOf(signs, n = 3) {
  if (!squaresOdd(signs, n).every(Boolean)) return null;
  const g = { 0: 1 }, st = [0];
  while (st.length) { const a = st.pop(); for (let i = 0; i < n; i++) { const b = a ^ (1 << i), lo = Math.min(a, b); if (g[b] === undefined) { g[b] = g[a] * signs[edgeKey(lo, i)] * jwSign(lo, i); st.push(b); } } }
  return cubeEdges(n).every(([a, i]) => signs[edgeKey(a, i)] === jwSign(a, i) * g[a] * g[a | (1 << i)]) ? Object.keys(g).map(Number).filter(a => g[a] === -1).sort((x, y) => x - y) : null;
}
export function countAnticommuting(n = 3) { const E = cubeEdges(n); let k = 0; for (let m = 0; m < 1 << E.length; m++) { const s = {}; E.forEach(([a, i], t) => { s[edgeKey(a, i)] = m >> t & 1 ? -1 : 1; }); if (squaresOdd(s, n).every(Boolean)) k++; } return { total: 1 << E.length, odd: k }; }
export const flipCorner = (signs, c, n = 3) => { const o = { ...signs }; for (let i = 0; i < n; i++) { const b = c ^ (1 << i), lo = Math.min(c, b); o[edgeKey(lo, i)] = -o[edgeKey(lo, i)]; } return o; };
export { edgeKey };
// the sign of e_i e_a in Cl(n,0) by the bit rule (for the check that the edge sign is the bit-rule sign)
export const bladeMulSign = (a, b, n = 3) => bm(a, b, Array(n).fill(1))[1];
