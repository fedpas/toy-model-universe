// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { spawnSync } from 'child_process';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder
import { buildSync } from 'esbuild';
import D from './fureyPapersData.js';
import T256 from './threegenData.js';
import { FUREY_PAPERS_PY } from './fureyPapersSelfcheckSource.js';
import * as E from './fureyPapersEngine.js';
import { FC, PAPERS, CHECKS_IT, checkText } from './fureyCopy.js';
import { FINDINGS, FINDINGS_UI } from './findingsData.js';
import { TREE, flat, SCRIPTS } from './mapData.js';
import { NODES, NODES_YL } from './mapCopy.js';
import { SHORT } from './audienceCopy.js';
// The Furey page (Calibration 2): the data and engine of her papers and of Fig. 1, the words of the four new tabs, and their wiring.
//  1. the check script, its stored data and its mirror in the app (30 checks: A 5, R 11, T 5, F 4, C 2, P 1, N 2); the script is run when numpy is there
//  2. the engine (fureyPapersEngine.js) gives the numbers of the data: the 20 cells, the counts of complete sets, the composite irreps, the room, the ladders, the three spaces
//  3. the numbers written in the copy are the data's
//  4. the copy: English and Italian have one shape, every statement carries tags from the five, no word about earlier versions or corrections, the plain copy holds no formula
//  5. the wiring: tabs, anchors, map nodes and their texts, the short readings, the five cards
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const canon = o => Array.isArray(o) ? o.map(canon) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, canon(o[k])])) : o;
const eq = (a, b) => JSON.stringify(canon(a)) === JSON.stringify(canon(b));   // key order does not matter
const rd = f => fs.readFileSync(f, 'utf8');

// ---------------------------------------------------------------------------------------------------------------- 1. the script and its data
{ const J = JSON.parse(rd('./selfcheck/furey_papers.json'));
  ok(eq(J, JSON.parse(JSON.stringify(D))), 'fureyPapersData.js equals selfcheck/furey_papers.json');
  ok(FUREY_PAPERS_PY === rd('./selfcheck/furey_papers_check.py'), 'the script in the app equals the file');
  ok(/--compare/.test(FUREY_PAPERS_PY) && /--write/.test(FUREY_PAPERS_PY) && /ALL FUREY-PAPER CHECKS PASS/.test(FUREY_PAPERS_PY), 'script interface');
  const grp = {}; for (const [id] of D.checks) grp[id[0]] = (grp[id[0]] || 0) + 1;
  ok(D.checks.length === 30 && eq(grp, { A: 5, R: 11, T: 5, F: 4, C: 2, P: 1, N: 2 }), 'the 30 checks: ' + JSON.stringify(grp));
  ok(new Set(D.checks.map(c => c[0])).size === 30 && D.checks.every(([id, t]) => /^[ARTFCPN]\d+$/.test(id) && t.length > 20), 'each check has its own id and a sentence');
  const np = spawnSync('python3', ['-c', 'import numpy'], { encoding: 'utf8' });
  if (np.status === 0) { const r = spawnSync('python3', ['selfcheck/furey_papers_check.py', '--compare', 'selfcheck/furey_papers.json'], { encoding: 'utf8', timeout: 240000 });
    ok(r.status === 0 && /ALL FUREY-PAPER CHECKS PASS \(30 checks\)/.test(r.stdout) && /stored data == rebuilt data/.test(r.stdout), 'the script passes all 30 checks and reproduces the stored data'); }
  else console.log('note: numpy is not installed, the script itself was not run');
  ok(SCRIPTS.numpy.includes('furey_papers_check.py') && !SCRIPTS.stdlib.includes('furey_papers_check.py'), 'the script is listed with the numpy scripts');
  ok(/furey_papers_check\.py/.test(rd('./BUILDING.md')) && /regen_furey_papers\.sh/.test(rd('./BUILDING.md')), 'BUILDING.md names the script and its regeneration');
  const sh = rd('./selfcheck/regen_furey_papers.sh'); ok(/furey_papers_check\.py --write/.test(sh) && /fureyPapersData\.js/.test(sh) && /fureyPapersSelfcheckSource\.js/.test(sh), 'the regeneration script writes the data and the mirror');
}

// ---------------------------------------------------------------------------------------------------------------- 2. the engine against the data
{ const cells = E.cellKeys(); ok(cells.length === 20 && D.fig1.cells.length === 20 && D.fig1.matched === 20 && D.fig1.of === 20 && E.matchCount() === 20, 'Fig. 1: 20 cells, every label equals the irrep of its cell');
  for (const c of D.fig1.cells) { const r = c.row, k = c.col; ok(E.fmt(E.cell(r, k)) === c.irrep && eq(E.FIG1[r + ',' + k], c.labels), `cell (${r},${k}): irrep and labels`); }
  const ch = (r, k) => Object.fromEntries(E.cellCharges(r, k).map(z => [z.q, z.n]));
  const third = q => { const a = Math.abs(q), g = a % 3 === 0 ? 3 : 1; return (q < 0 ? '-' : '') + a / g + (g === 3 ? '' : '/3'); };   // a charge in thirds, written as the data writes it
  ok(D.fig1.cells.every(c => eq(c.charges, Object.fromEntries(E.cellCharges(c.row, c.col).map(z => [third(z.q), z.n])))), 'the electric charges of each cell, as the data writes them');
  ok(E.traceY() === 18 && E.traceQ() === 9 && E.dimV() === 8, 'Tr Y = Tr Q = 3 over dimension 8 (in sixths 18, in thirds 9)');
  let cap = 0; for (let a = 0; a < 5; a++) for (let b = a + 1; b < 5; b++) cap += E.capacity(a, b); ok(cap === 48, 'the ten edges hold 48 complex dimensions');
  const C = D.counting;
  ok(eq(E.setsByType(false), C.sets_on_shell) && eq(E.setsByType(true), C.sets_doubled) && E.completeSets(false) === 1 && E.completeSets(true) === 2 && C.complete_sets_on_shell === 1 && C.complete_sets_doubled === 2, 'complete sets: one with one label per cell, two with every cell doubled');
  ok(eq(E.missingFor(3, true), C.missing_for_three_doubled) && eq(Object.keys(E.missingFor(3, true)).sort(), ['Q_L', 'nu_R', 'u_R']), 'a third set lacks exactly Q_L, u_R and nu_R');
  ok(E.surplusDim() === 8 && C.surplus_dimension_C === 8, '8 complex dimensions beyond one complete set');
  ok(E.TYPES.length === 6 && E.TYPES.reduce((a, t) => a + E.SM_DIM[t], 0) === 16, 'one set is six types, 16 complex dimensions');
  ok(D.composites.length === 3 && E.PRESETS.length === 3 && E.PRESETS.every(p => E.containsType(E.product(p.a, p.b), p.target)), 'each missing irrep is in the product of two extra ones');
  const hh = E.product(E.PRESETS[2].a, E.PRESETS[2].b); ok(hh.length === 2 && hh.some(r => r.i === 3) && hh.some(r => r.i === 1), 'nu_R comes with an isospin-triplet partner (1,3,0)');
  const R = D.room; ok(R.first_dimension_with_three_sets === 14, 'three sets first at dimension 14');
  const best = Object.fromEntries(Object.entries(R.by_dimension).map(([d, v]) => [d, v.max_S / 2])); ok(eq(best, { 8: 1, 9: 1, 10: 1, 11: 2, 12: 2, 13: 2, 14: 4 }), 'most complete sets per dimension: ' + JSON.stringify(best));
  ok(Object.keys(R.by_dimension).every(d => (d < 14) === !(6 in R.by_dimension[d].histogram_of_S)), 'a layout with three sets (S = 6) first exists at dimension 14, not before');
  ok(R.by_dimension['8'].structures === 5582 && T256.search_all.admissible_W === 5582 && R.her_frame.sets === 1 && R.her_frame.dimension === 8, '5,582 structures at dimension 8, hers holds one set');
  const L = D.roadmap; ok(eq(L.spin10_line.map(x => x.dim), [45, 21, 15, 11, 10]) && eq(L.su5_line.map(x => x.dim), [24, 12, 10, 9]) && eq([L.intersections.vector_spinor, L.intersections.three_way_O, L.intersections.four_way_no_O, L.intersections.five_way_O_H_C], [24, 12, 9, 9]), 'the ladders and the intersections');
  const sp = L.spectra_on_PsiL; ok(Object.values(sp.Y).reduce((a, b) => a + b, 0) === 16 && eq(sp.Y, { '1/6': 6, '-2/3': 3, '1/3': 3, '-1/2': 2, '1': 1, '0': 1 }), 'the spectrum of Y on one generation');
  const T = D.trialities; ok(T.e7 === 133 && T.e8 === 248 && T.tri_dims.C + T.tri_dims.H + T.tri_dims.O === 39 && T.tri_dims.H + T.tri_dims.O + 3 * 4 * 8 === 133 && 2 * T.tri_dims.O + 3 * 8 * 8 === 248, 'trialities: 133 and 248');
  ok(['+', '-', 'V'].every(k => Object.values(T.spectra[k].y).reduce((a, b) => a + b, 0) === 32), 'the three spaces have 32 real dimensions each');
  const W = T256.dimensions; ok(W.diagonal_complex === 16 && W.linear_off_diagonal_complex === 48 && W.antilinear_complex === 64 && T256.exotic.antilinear === 32, 'the 128 complex dimensions: 16 + 48 + 32 + 32');
}

// ---------------------------------------------------------------------------------------------------------------- 3. the numbers of the copy are the data's
{ const flatten = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (Array.isArray(o)) o.forEach(x => flatten(x, out)); else if (o && typeof o === 'object') Object.values(o).forEach(x => flatten(x, out)); return out; };
  const all = l => flatten(FC[l]).join('\n');
  for (const l of ['en', 'it']) {
    const t = all(l), sec = (tab, k) => flatten(FC[l][tab].secs[k]).join(' ');
    ok(/45 → 21 \(.*?\) → 15 \(.*?\) → 11 → 10/.test(sec('earlier', 'cascade')) && /24 \(su\(5\)\) → 12 \(.*\) → 10 → 9/.test(sec('earlier', 'cascade')), `${l}: the two ladders as the data has them`);
    ok(/133 = 9 \+ 28 \+ 96/.test(sec('earlier', 'triality')) && /248 = 28 \+ 28 \+ 192/.test(sec('earlier', 'triality')), `${l}: 133 and 248`);
    ok(/5[,.]582/.test(sec('threegen', 'room')) && new RegExp('dimension ' + D.room.first_dimension_with_three_sets + '|dimensione ' + D.room.first_dimension_with_three_sets).test(sec('threegen', 'room')), `${l}: the room search quotes 5,582 and dimension 14`);
    ok(/16, 48|16 \(.*\), 48|16 \(.*\) e 48|16 \(.*\) and 48/.test(sec('threegen', 'whole')) && /64/.test(sec('threegen', 'whole')), `${l}: the 128 are 16, 48 and 64`);
    ok(/24ℂ/.test(flatten(FC[l].findings.cards.edges).join(' ')) && /16ℂ/.test(flatten(FC[l].findings.cards.edges).join(' ')) && /8ℂ/.test(flatten(FC[l].findings.cards.edges).join(' ')), `${l}: the edge card says 24ℂ = 16ℂ + 8ℂ`);
    const g = {}; for (const [id] of D.checks) g[id[0]] = (g[id[0]] || 0) + 1;
    const sc = flatten(FC[l].help.secs.score.p).join(' ');
    ok(sc.includes('30') && new RegExp(['A', 'R', 'T', 'F', 'C', 'P', 'N'].map(k => `\\b${g[k]}\\b[^()]*\\(${k}\\)`).join('.*?')).test(sc), `${l}: the score line gives the counts of the checks by letter ${JSON.stringify(g)}`);
    ok(/\b30\b/.test(t) && !/\b3[1-9]\b checks|\b2[0-9] checks/.test(t), `${l}: the number of checks is 30 wherever it is quoted`);
  }
  ok(FC.en.help.secs.score.yl[0].includes('Sixteen') && FC.en.help.secs.score.yl[0].includes('five about the 2024') && FC.en.help.secs.score.yl[0].includes('nine about the 2026'), 'the plain score line: 16 + 5 + 9 = 30');
  // the Italian reading of the 30 check sentences: one for each id, not the English text, with the same numbers
  const nums = t => (t.replace(/(\d)[.,](\d{3})\b/g, '$1$2').match(/\d+/g) || []).join(' ');
  ok(eq(Object.keys(CHECKS_IT).sort(), D.checks.map(c => c[0]).sort()), 'the Italian list has the 30 ids of the checks');
  for (const [id, t] of D.checks) ok((CHECKS_IT[id] !== t || id === 'A2') && nums(CHECKS_IT[id]) === nums(t) && checkText('it', id, t) === CHECKS_IT[id] && checkText('en', id, t) === t, `check ${id}: Italian sentence with the same numbers as the English one`);
  ok(PAPERS.length === 6 && PAPERS.map(p => p.ref).join() === 'arXiv:2312.12377,arXiv:2312.12799,arXiv:2312.14207,arXiv:2409.17948,arXiv:2505.07923,arXiv:2607.18450', 'the six papers, in the order they appeared');
  // the Young Learner texts say what the board lacks: the pieces of the heaviest quark and of a neutrino partner (C2: the irreps of Q_L, u_R and nu_R lack a third copy), not "all but the heaviest quark"
  for (const l of ['en', 'it']) { const yl = FC[l].earlier.secs.fit.yl[0], sh = FC[l].threegen.short[0];
    ok(l === 'en' ? /nearly three families fit: pieces of the heaviest quark and of a neutrino partner are missing\./.test(yl) && /nearly has room for all of them, if every box is counted twice: the pieces of the heaviest quark and of a neutrino partner are missing\./.test(sh) : /quasi tre famiglie: mancano i pezzi del quark più pesante e di un partner del neutrino\./.test(yl) && /ha quasi posto per tutte, se ogni cella è contata due volte: mancano i pezzi del quark più pesante e di un partner del neutrino\./.test(sh), `${l}: the plain texts name the heaviest quark and a neutrino partner as missing, with every cell counted twice`);
    ok(!/all but the pieces|except the pieces of the heaviest|tutte tranne i pezzi|le mostra tutte/.test(yl + sh), `${l}: the plain texts do not say that the board shows all families but the heaviest quark`); }
  // the date of the newest paper is the date of its first arXiv version (20 Jul 2026, hep-ph), so the span of the six papers ends in July 2026 on every page that names it
  ok(PAPERS[5].date.en === '20 Jul 2026' && PAPERS[5].date.it === '20 lug 2026' && /DECEMBER 2023 TO JULY 2026/.test(FC.en.earlier.eyebrow) && /DA DICEMBRE 2023 A LUGLIO 2026/.test(FC.it.earlier.eyebrow) && !/AUGUST|AGOSTO/.test(JSON.stringify([FC.en.earlier.eyebrow, FC.it.earlier.eyebrow])), 'the newest paper is dated 20 Jul 2026 and the span of the papers ends in July 2026');
}

// ---------------------------------------------------------------------------------------------------------------- 4. the copy
{ const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  ok(eq(shape(FC.en), shape(FC.it)), 'English and Italian copy have the same shape');
  const KINDS = ['standard', 'checked', 'ours', 'open', 'input'], ORDER = k => k.split(' ').map(x => KINDS.indexOf(x));
  const lines = [];
  for (const l of ['en', 'it']) for (const tab of ['earlier', 'findings', 'threegen', 'help']) for (const [k, s] of Object.entries(FC[l][tab].secs)) {
    ok(typeof s.h === 'string' && s.h.length > 3 && (tab === 'findings' && ['blocks', 'edges', 'axes', 'open'].includes(k) ? true : Array.isArray(s.yl) && s.yl.length >= 1 && s.yl.every(x => x.length > 40)), `${l}.${tab}.${k}: heading and plain paragraphs`);
    for (const [kind, text] of [...(s.p || []), ...(s.m || [])]) { lines.push([l, tab, k, kind, text]); ok(kind.split(' ').every(x => KINDS.includes(x)) && eq(ORDER(kind), [...ORDER(kind)].sort((a, b) => a - b)) && text.length > 20, `${l}.${tab}.${k}: tags "${kind}" from the five, in order`); }
  }
  ok(lines.length > 40, `statements counted: ${lines.length}`);
  // no word about earlier versions or corrections anywhere on the page
  const allText = l => JSON.stringify(FC[l]) + JSON.stringify(FINDINGS.map(f => f[l])) + JSON.stringify(FINDINGS_UI[l]);
  const HIST = /errat|erratum|correction|corrected|withdrawn|retract|ritrattat|ritirat|rettific|corretto|\bmistake|\bwrong|earlier (version|claim|reading|analysis)|previous(ly)? (version|claim|reading|said)|we (had )?(said|claimed|stated|thought)|used to (say|read)|not (quite )?right (before|earlier)|re-?read (it|the paper)|sbagliat|errore|prima (dicevamo|avevamo)|in precedenza/i;
  for (const l of ['en', 'it']) { const m = HIST.exec(allText(l)); ok(!m, `${l}: no word about earlier versions or corrections on the Furey page (${m && m[0]})`); }
  for (const l of ['en', 'it']) { const t = allText(l); ok(!/ΣY³|another identification|un’altra identificazione|one generation fits; three do not in our|Higgs is not placed|Higgs non è collocat/i.test(t), `${l}: none of the removed statements is left`); }
  // the plain copy: no formula symbol and no technical word (the patterns are those of test_yl_ui.mjs)
  const src = rd('./test_yl_ui.mjs'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const plain = c => ({ titleY: c.titleY, short: c.short[0], ylw: c.ylw, secs: Object.fromEntries(Object.entries(c.secs).map(([k, s]) => [k, { hy: s.hy, yl: s.yl }])) });
  const YL = l => ({ earlier: { ...plain(FC[l].earlier), papers: Object.fromEntries(Object.entries(FC[l].earlier.papers).map(([k, p]) => [k, { yb: p.yb, yr: p.yr }])), cpDetailY: FC[l].earlier.cpDetailY },
    findings: { ...plain(FC[l].findings), cards: Object.fromEntries(Object.entries(FC[l].findings.cards).map(([k, c]) => [k, { t: c.t[0], yl: c.yl }])) },
    threegen: { ...plain(FC[l].threegen), typeName: FC[l].threegen.typeName, typeShort: FC[l].threegen.typeShort, extraShort: FC[l].threegen.extraShort, anti: FC[l].threegen.anti, compYl: FC[l].threegen.compYl },
    help: { ...plain(FC[l].help), qy: FC[l].help.qy } });
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const se = strs(YL('en')), si = strs(YL('it')); ok(se.length > 60 && se.length === si.length, `plain copy: ${se.length} EN and ${si.length} IT strings`);
  for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `plain copy: formula or technical word "${m && m[0]}": ${s.slice(0, 90)}`); }
  // v11 writes new and changed text in English and uses it in the Italian slots as well: the plain strings that are so are listed here, and nothing else is allowed to be English in the Italian copy
  const EN_IN_IT = ['We do not yet have a rule that says which box of the atlas’s own table holds which particle, so the heaviest quark has no box there.', 'We checked it: the left-right switch is one of the model’s own moves.'];
  se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || s.split(/\s+/).length <= 2 || EN_IN_IT.some(x => s.startsWith(x)),   // a single word such as neutrino is the same in both languages
   `the Italian plain copy reads as English: ${s.slice(0, 70)}`));
  ok(EN_IN_IT.every(x => se.some(s => s.startsWith(x)) && si.some(s => s.startsWith(x))), 'the English-in-Italian plain strings are present in both languages');
  ok(eq(shape(YL('en')), shape(YL('it'))), 'the plain copy has the same shape in both languages');
  // Calibration 2: the sentence that says what a calibration is (C-021), shown under the tab bar; its plain version holds no formula symbol and no technical word
  for (const l of ['en', 'it']) { const u = FC[l].ui;
    ok(u.calib.startsWith('A calibration is a run on something whose answer is known, to show which inputs the method needs; it is not a test of a new theory.') && /her octonion table as an input \(the octonion sign on the eight labels is a cochain, not a cocycle like the bit-rule sign: Thm T6\), so it cannot test the rule; it counts what fits\.$/.test(u.calib) && !/her sign/.test(u.calib), `${l}: the calibration sentence of the Furey page cites Thm T6 and says no more than T6 gives`);
    // T6 (d) is proved by check_T6.py part OCT: the Albuquerque–Majid cochain F on Z_2^3 has dF = (−1)^det (168 triples, so it is no cocycle) and the Cl(0,3) sign on the same labels is a cocycle; the cited theorem exists on the researchers page and names that script
    { const td = fs.readFileSync('./researchersData.js', 'utf8'), at = td.indexOf("id: 'T6'"), blk = td.slice(at, td.indexOf("id: 'T7'")); ok(at > 0 && /dF = \(−1\)\^\{det\(a,b,c\)\}/.test(blk) && /script: 'check_T6\.py'/.test(blk) && /the Cl\(0,3\) sign is a cocycle but not a composition sign/.test(blk), `${l}: Thm T6 states the non-cocycle octonion sign and names check_T6.py`); }
    ok(u.calibY === 'A warm-up is a run on something whose answer we already know. It shows what we had to put in.' && !/calibration/i.test(u.calibY) && !SYM.exec(u.calibY) && !JAR.exec(u.calibY), `${l}: the plain calibration sentence holds no formula and no technical word`); }
  for (const l of ['en', 'it']) ok(FC[l].ui.report === 'Full report: Furey’s six papers and the atlas (reports/html/furey_report.html).', `${l}: the line that names the full report`);
  ok(/data-report="furey"/.test(rd('./FureyPage.jsx')) && /!isLearner\(profile\) && <p className="fy-calib fy-report"/.test(rd('./FureyPage.jsx')), 'FureyPage.jsx closes the page with the report line (Physicist and Mathematician)');
  ok(/data-calibration="furey"/.test(rd('./FureyPage.jsx')) && /u\.calibY : u\.calib/.test(rd('./FureyPage.jsx')), 'FureyPage.jsx draws the calibration sentence for both readers');
  // the Italian is Italian: long statements differ from the English ones (a copy-paste would leave them equal)
  const pe = [], pi = []; for (const tab of ['earlier', 'findings', 'threegen', 'help']) for (const [k, s] of Object.entries(FC.en[tab].secs)) { pe.push(...(s.p || []).map(x => x[1])); pi.push(...(FC.it[tab].secs[k].p || []).map(x => x[1])); }
  // (v11 writes new statements in English and uses them in the Italian slots too: those listed here are the only ones that may be equal)
  const STMT_EN_IN_IT = ['The labels of the bit rule form the group (ℤ/2)ⁿ, which has no element of order 3', 'The maps of V that commute with the gauge algebra Δ_SM (31 real dimensions) form a 12-dimensional algebra'];
  ok(pe.length === pi.length && pe.every((s, i) => s !== pi[i] || STMT_EN_IN_IT.some(x => s.startsWith(x))), 'Italian statements differ from the English ones');
  ok(STMT_EN_IN_IT.every(x => pe.some(s => s.startsWith(x)) && pi.some(s => s.startsWith(x))), 'the two three-generation statements are in both languages');
  // the order-3 statement and the commutant of the gauge algebra: the numbers of the text are those of family_results.json (family_test.py)
  { const F = JSON.parse(rd('./family_results.json')), a = F.commutant_action_on_sm_edges;
    ok(F.delta_SM_real_dim === 31 && F.commutant_of_gauge_real_dim === 12 && F.commutant_off_block_real_dim === 0 && eq(Object.values(F.commutant_per_block_real_dim), [2, 2, 2, 2, 4]), 'family_results.json: the gauge commutant has real dimension 12 (2, 2, 2, 2, 4 on the blocks, nothing between them) inside the 31-dimensional gauge algebra');
    ok(['Q_L', 'u_R', 'L'].every(n => a[n].preserved_by_commutant && a[n].complex_scalars_only && !a[n].touches_last_block) && ['d_R', 'e_R', 'nu_R'].every(n => !a[n].preserved_by_commutant && a[n].touches_last_block), 'family_results.json: the commutant acts as one complex scalar on the Q_L, u_R and L edges; the d_R, e_R and nu_R edges touch the last block');
    const room = FC.en.threegen.secs.room.p; ok(eq(room.map(x => x[0]), ['ours', 'checked', 'open', 'standard open', 'checked']) && /\(ℤ\/2\)ⁿ, which has no element of order 3, so no cyclic permutation of three generations is an operation of the labels alone/.test(room[3][1]) && !/so a 3 has to come/.test(room[3][1]) && /12-dimensional algebra/.test(room[4][1]) && /family_test\.py/.test(room[4][1]), 'the room section carries the order-3 statement (standard, open) and the commutant statement (checked)'); }
}

// ---------------------------------------------------------------------------------------------------------------- 5. the wiring
{ const ss = rd('./StoryShell.jsx'), subs = /furey: \[([^\]]*)\]/.exec(ss)[1].replace(/'/g, '').split(',').map(x => x.trim());
  ok(eq(subs, ['dictionary', 'earlier', 'findings', 'threegen', 'help']), 'the Furey page has five tabs: ' + subs);
  const fp = rd('./FureyPage.jsx'); ok(subs.every(s => fp.includes(`sub === '${s}'`)), 'FureyPage.jsx draws every tab');
  const tabs = flat(TREE).filter(x => x.go[0] === 'furey'); const kids = flat(TREE).find(x => x.id === 'furey').kids.map(x => x.id);
  ok(eq(kids, subs), 'the Map tree lists the five tabs in the order of the page: ' + kids);
  const where = { earlier: 'FureyEarlier.jsx', findings: 'FureyFindings.jsx', threegen: 'ThreeGenSection.jsx', help: 'FureyHelp.jsx' };
  for (const [id, f] of Object.entries(where)) { const node = tabs.find(x => x.id === id); ok(node && rd('./' + f).includes(`id="${node.go[1]}"`), `${id}: the anchor ${node && node.go[1]} is in ${f}`); }
  for (const l of ['en', 'it']) for (const id of subs) { ok(Array.isArray(NODES[l][id]) && NODES[l][id].length === 2 && NODES[l][id][0] && NODES[l][id][1], `${l}: map text of ${id}`); ok(Array.isArray(NODES_YL[l][id]) && NODES_YL[l][id][1].length > 40, `${l}: plain map text of ${id}`); }
  for (const l of ['en', 'it']) for (const id of ['earlier', 'findings', 'threegen', 'help']) ok(SHORT[l][id] === FC[l][id].short, `${l}: the short readings of ${id} are the copy's`);
  ok(Object.keys(SHORT.en).slice(Object.keys(SHORT.en).indexOf('dictionary'), Object.keys(SHORT.en).indexOf('dictionary') + 5).join() === 'dictionary,earlier,findings,threegen,help', 'short readings in the order of the tabs');
  ok(eq(FINDINGS.map(f => f.id), ['blocks', 'edges', 'witt', 'z2', 'open']) && eq(FINDINGS.map(f => f.flags.join(' ')), ['checked input', 'checked open input', 'checked input', 'checked open', 'ours open']), 'the five cards (claims FUR-001 to FUR-005) and their tags (input on the complex structure, her labels and the partition)');
  // FUR-005: an irreducible representation is not a Clifford algebra, so no cell of the top quark is asserted: the open item is a map from irreps to cells
  for (const l of ['en', 'it']) { const o = FINDINGS.find(f => f.id === 'open')[l]; ok(/^A map from irreps to cells \(until one is defined the top quark has no cell: three cells have been tried, \[7,±1\], \[4,\+4\] and \[3,\+1\], none established\)/.test(o.Physicist[1]) && /^A map from irreps to cells/.test(o.Mathematician[1]) && !/the cell of the top quark/i.test(JSON.stringify(o)), `${l}: FUR-005 asks for a map from irreps to cells, not for the cell of the top quark`); }
  ok(FINDINGS.every(f => ['en', 'it'].every(l => ['Young Learner', 'Physicist', 'Mathematician'].every(p => Array.isArray(f[l][p]) && f[l][p].length === 2 && f[l][p][0] && f[l][p][1]))), 'every card has a title and a text for every reader in both languages');
  ok(FINDINGS_UI.en.repro.includes('furey_papers_check.py') && FINDINGS_UI.it.repro.includes('furey_papers_check.py'), 'the reproduction note names the script');
  const furey = flat(TREE).find(x => x.id === 'furey'); ok(furey.script.includes('furey_papers_check.py') && furey.script.includes('threegen_selfcheck.py'), 'the Furey node names both scripts');
}

// ---------------------------------------------------------------------------------------------------------------- 6. what the page hands out
{ const jsxModule = f => import('data:text/javascript;base64,' + Buffer.from(buildSync({ absWorkingDir: PKG, entryPoints: [f], bundle: true, write: false, format: 'esm', platform: 'node', loader: { '.js': 'jsx' }, logLevel: 'silent', alias: { streamdown: './stubs/streamdown.jsx', '@streamdown/math': './stubs/smath.js', 'react-katex': './stubs/katex.jsx' } }).outputFiles[0].text).toString('base64'));
  const W2 = await jsxModule('./FureyWidgets2.jsx'), csv = W2.cellsCsv(), rows = csv.trim().split('\n');
  ok(rows.length === 21 && rows[0] === 'row,col,row_block,col_block,irrep,dim,charges,label_1,label_2', 'the CSV: a header and 20 cells');
  ok(rows.slice(1).every((r, i) => { const c = D.fig1.cells[i]; return r.startsWith(`${c.row},${c.col},`); }) || rows.slice(1).every(r => /^\d,\d,/.test(r)), 'the CSV rows are the cells');
  ok(rows.slice(1).every(r => { const f = r.split(','); return f.length >= 9; }), 'the CSV rows have all their fields');
}
console.log(bad ? bad + ' FAILURES of ' + n : `ALL FUREY-PAPERS TESTS PASS: ${n} checks`); process.exit(bad ? 1 : 0);
