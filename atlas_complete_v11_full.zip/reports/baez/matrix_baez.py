# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The translation matrix between seven papers of John Baez and his co-authors and the atlas.
Rows: what the seven papers talk about (by paper).  Columns: where the atlas draws or checks it (the same 22 pages and steps as the Schuller matrix).
Grade of a cell:
  E  exact        the same object or identity; a check in baez_check.py computes it (check ids in the note)
  S  structural   the same structure in another generality, or a standard fact the atlas uses
  A  analogy      a reading we propose (tagged ours); nothing computes that it is the same
  .  (absent)     no counterpart
A row with no cell at all is a GAP: the atlas has nothing there."""

COLS = [  # key, short label, long label, atlas page
    ('rule', 'Rule', 'The rule: bit labels, XOR, signs', 'page 1'),
    ('cells', 'Cells', 'The atlas of cells Cl(p,q), the clock', 'page 2'),
    ('clock', '1 Clock', 'Step 1: clock and trinity', 'step 1'),
    ('maxwell', 'Maxwell', 'Calibration 1: Maxwell ∇F=J', 'page 4'),
    ('shapes', 'Shapes', 'Orthoplex, demicube, Gosset series', 'page 5'),
    ('comm', '2 Comm', 'Step 2: bivector commutators', 'step 2'),
    ('mirrors', '3 Mirr', 'Step 3: mirrors and versors', 'step 3'),
    ('dirac', '4 Dirac', 'Step 4: Dirac equation', 'step 4'),
    ('spin', '5 Spin', 'Step 5: spinors', 'step 5'),
    ('coupling', '6 Coupl', 'Step 6: coupling', 'step 6'),
    ('ym', '7 YM', 'Step 7: Yang–Mills', 'step 7'),
    ('matter', '8 Matter', 'Step 8: charged matter', 'step 8'),
    ('grav1', '9 Grav', 'Step 9: gravity, tetrad and curvature', 'step 9'),
    ('grav2', '10 Grav', 'Step 10: gravity, Einstein form', 'step 10'),
    ('projective', '11 Proj', 'Step 11: projective and conformal', 'step 11'),
    ('gauge', '12 Gauge', 'Step 12: gauge gravity', 'step 12'),
    ('null', '13 Null', 'Step 13: null surfaces', 'step 13'),
    ('forque', '14 Forq', 'Step 14: forque dynamics', 'step 14'),
    ('spring', '15 Sprg', 'Step 15: springs', 'step 15'),
    ('rigid', '16 Rigd', 'Step 16: rigid bodies', 'step 16'),
    ('furey', 'Furey', 'Calibration 2: Furey, one generation in Cl(0,8)', 'page 7'),
    ('groups', '17 Grps', 'Step 17: finite groups', 'step 17'),
]

# source: G = Baez-Schwahn, The Standard Model Gauge Group from the Exceptional Jordan Algebra (arXiv:2606.15235)
#         J = Baez-Bokor-Boyle, Jordan Pair Quantum Theory and the Standard Model (arXiv:2607.10833)
#         E = Baez, Three Generations in E7 (arXiv:2608.06271)
#         D = Baez-Pumplun, Three-Dimensional Geometry in Exceptional Mathematics (arXiv:2609.07538)
#         K = Baez, Second Quantization for the Kepler Problem (arXiv:2507.11428)
#         T = Baez, Triangulations of the Sphere (arXiv:2606.10072)
#         C = Baez, Double Categories of Open Systems: the Cospan Approach (arXiv:2509.22584; read at overview level)
ROWS = [
 ('G1', 'G', 'Octonions O = C + C^3 and the Albert algebra h3(O): 27 = 3 + 3 x 8', {
   'rule': ('E', 'The octonions are the XOR rule on 3 bits with another sign (O1a); the associator sign is (-1)^det over F2, negative for 168 triples (O1b); h3(O) on those labels satisfies the Jordan identity (O3a).'),
   'shapes': ('S', 'The 27 grade-1 roots of e7, joined at inner product 0, form srg(27,10,1,5), the intersection graph of the 27 lines on a cubic surface; its complement (inner product 1) is the Schlafli graph srg(27,16,10,8), the vertex graph of the Gosset polytope 2_21 (E2d).'),
   'furey': ('A', 'Furey\'s page builds one generation from octonion-type blocks; the identification of her blocks with the Jordan-frame split is not computed here.')}),
 ('G2', 'G', 'F4 = Aut(h3(O)), dimension 52; triality inside it', {
   'clock': ('E', 'The frame stabiliser so(8) (28) acts on the three 8-blocks irreducibly and inequivalently with equal Casimir: 8v, 8s, 8c (O3h).'),
   'groups': ('S', 'The Lie algebra f4 is computed as the 52-dimensional derivation algebra (O3c); the atlas\'s step 17 uses the F4 and E8 root systems, not the Lie algebra.')}),
 ('G3', 'G', 'Jordan subalgebras X = h2(C), B = h3(C), A = h2(O) and their stabilisers in F4', {
   'cells': ('E', 'A = h2(O) is a spin factor R + R^9: det has signature (1,9), the traceless R^9 is a Euclidean vector space of the bit-rule algebra Cl(9,0), clock 1, type R2 = M16(R) + M16(R), and its spinor 16 is the Peirce 1/2 space (O3i).'),
   'comm': ('S', 'Stabiliser dimensions inside f4: so(8) 28, su(3)+su(3) 16, spin(9) 36, so(3)+so(6) 18, SM 12 (O3e); the atlas computes commutators of bivectors, not of derivations.')}),
 ('G4', 'G', 'The Standard Model group = Stab(X) intersect Stab(B)^0 = S(U(2) x U(3)) (Theorems 1 and 2)', {
   'ym': ('S', 'Lie algebra level: 12-dimensional, centre u(1), derived algebra 11 = su(2) + su(3) (O3f, O3g); the atlas\'s step 7 builds su(2), su(3) from bivectors.'),
   'furey': ('A', 'Same gauge algebra su(3) + su(2) + u(1) as in the page on one generation; nothing here computes that the two embeddings agree.')}),
 ('G5', 'G', 'How that group acts on h3(O): self-conjugate, 27 = (1,1) + (1,8) + (3,3bar) + (3bar,3)', {
   'furey': ('S', 'The 27 real dimensions give Casimir classes 2 + 4 + 3 + 6 + 12 (S2); the E7-chain 27 gives 3 + 6 + 12 + 6 (S1, S2): the 27 = h3(O) is self-conjugate (S2) and a real representation is vector-like (standard), so the chiral 16 of the atlas page is not inside h3(O) itself; Lie-algebra level only.')}),
 ('G6', 'G', 'Qubit h2(C) and qutrit h3(C): Jordan algebras of observables; the "octonionic qutrit"', {
   'spin': ('S', 'h2(C) = R + R^3 is the Pauli algebra on its vector part (spin factor); the atlas\'s step 5 has the Pauli algebra as Cl(3,0). A check of that identification for h2(C) is not in baez_check.py.')}),
 ('G7', 'G', 'Maximal connected subgroups of F4 (Borel-de Siebenthal), Yokota\'s remark on Stab(B)', {}),
 ('G8', 'G', 'Peirce decomposition of the Jordan frame: 27 = 3 + 8 + 8 + 8', {
   'rule': ('E', 'Idempotent e1 splits h3(O) into eigenvalues 1, 1/2, 0 of dimensions 1, 16, 10 (O3b); the three 8s are xi_12, xi_23, xi_31 of the octonion labels.')}),
 ('J1', 'J', 'Hermitian Jordan triples, tripotents and the Peirce decomposition', {
   'rule': ('E', 'Peirce eigenvalue of a label x for a tripotent with label S is 1 - d(x,S)/4 on the 16 even 5-bit labels (H2a) and |x intersect S|/2 on the 2-subsets (H3e).'),
   'shapes': ('S', 'The Peirce graphs of the four triples are isomorphic to the label models: 27, 16 (demicube), 10, 6 (E2c, E2d).')}),
 ('J2', 'J', 'Triples as 3-graded Lie algebras (Tits-Kantor-Koecher): bras + operators + kets', {
   'rule': ('E', 'Five fermionic modes: ad(N) splits so(10) into 10 + 25 + 10; [[x,y+],z] equals twice the triple product of skew matrices (H3a-d).'),
   'projective': ('E', 'The dilatation bivector of the conformal ladder splits so(4,2) as 4 + 7 + 4 (K4): the same kind of 3-grading.')}),
 ('J3', 'J', 'Classification of simple triples: A III, D III, C I, BDI, E III, E VII (Table 1)', {
   'cells': ('S', 'Signature and clock of the quadratic form belong to the atlas; the six families are standard (BDI: C^n with so(n+2), n = 4 gives so(4,2), K4).'),
   'shapes': ('S', 'E III and E VII are the grade-1 pieces 16 and 27 of the E8 ladder 56, 27, 16, 10, 6 (E1b).')}),
 ('J4', 'J', 'The bi-Cayley triple, 16 complex dimensions, and the six Peirce pieces of one generation (1, 1, 6, 3, 3, 2)', {
   'rule': ('E', 'The 16 even 5-bit labels split by (weak bits, colour bits) into exactly those six pieces; Y = a/2 - b/3, Q = first weak bit - b/3 (H1, H2a-c).'),
   'matter': ('S', 'Charges are linear in bit counts and the anomaly sums vanish (H2d): a different route to charged matter than step 8.'),
   'furey': ('A', 'Furey\'s one generation has the same count; the six pieces are not matched to her projectors here.')}),
 ('J5', 'J', 'The Standard Model group as K0 of the A III triple M_{3,2}(C), S(U(3) x U(2))', {
   'rule': ('E', 'su(2) on the weak bits, su(3) on the colour bits, hypercharge N_w/2 - N_c/3: Casimirs and highest weights on the 16 labels (H3f).'),
   'ym': ('S', 'su(3) + su(2) + u(1) acting on a generation, as in step 7.')}),
 ('J6', 'J', 'Ordinary quantum mechanics rewritten with hermitian Jordan triples (Jordan pair quantum theory)', {
   'spin': ('A', 'The qubit as a triple against the Pauli algebra of step 5: the same object read two ways; no check here.')}),
 ('J7', 'J', 'Compact hermitian symmetric spaces K/K0 (Table 2) and Peirce geometry', {}),
 ('J8', 'J', 'The Albert triple (27) and the bi-Cayley triple (16) as grade-1 pieces of e7 and e6', {
   'shapes': ('E', 'From the 240 roots of E8: levels 56, 27, 16, 10, 6 and root counts 240, 126, 72, 40, 20, 8; 133, 78, 45, 24, 11 dimensions (E1a-c). The E8 end of the ladder is ours; e7 down to e3 is the E7 paper\'s Table 2.'),
   'groups': ('S', 'The same E8 root ladder is in step 17 (orthogonal systems 126, 72, 40, 20, 8).')}),
 ('J9', 'J', 'Rank r of the triples (the paper) and, from classical Jordan theory (Loos), the multiplicities (a,b) = (8,0), (6,4), (4,2), (2,1)', {
   'shapes': ('E', 'The multiplicities are not in the paper. dim = r + a r(r-1)/2 + b r and the Peirce 0, 1/2, 1 counts agree with the root counts for all four triples (E2a, E2b).')}),
 ('J10', 'J', 'The chain of triples M_{3,2} < a_5 < bi-Cayley < Albert (Table 3, eq. (77)); its su(3)+su(2) content step by step is our computation', {
   'rule': ('E', 'The chain is the paper\'s. Under su(3)+su(2) of the E7 chain the grade-1 pieces are 6 = (3,2); 10 adds (3bar,1)+(1,1); 16 adds (3bar,1)+(1,2)+(1,1); 27 adds 11 more states (S1).'),
   'furey': ('A', 'One generation built stepwise: a reading we propose for her page; not matched to her projectors.')}),
 ('E1', 'E', 'g_SM inside e7: e7 = (subalgebra containing g_SM) + three 32-dimensional subspaces; 133 = 35 + 2 + 3 x 32', {
   'rule': ('E', 'The 126 roots split 6 + 30 + 30 + 30 + 30 under the generation plane; each V_k projected to the sl6 Cartan has the weights of Lambda^even C^6 (E3a, E3e).'),
   'groups': ('S', 'e7 and its roots sit in step 17\'s E8 ladder (126 = second term).')}),
 ('E2', 'E', 'Each 32 is a copy of the exterior algebra Lambda C^5, with particles and antiparticles', {
   'rule': ('E', 'V_k = the 32 five-bit labels (the parity bit of the six-bit subsets is determined); XOR with 11111 maps even to odd labels and flips Q and Y (E3e, H1b, H2c); calling it charge conjugation is ours.')}),
 ('E3', 'E', 'The generation sl3 and its plane P; the trichotomy of Lemma 2 (shadows of roots)', {
   'shapes': ('E', 'The 126 roots of E7 are the atlas\'s own root system (page 5, step 17); their projection onto P lands on the weight lattice of A2 (the Eisenstein lattice) in shells N = 0, 1, 3 with 30, 90, 6 roots, none at N = 2 (E3a, T1b). The atlas has no page for the hexagonal picture.')}),
 ('E4', 'E', 'Three subalgebras so(12) + sl2 (Lemma 4) and 133 = 3 + 66 + 64 (Prop. 5)', {
   'rule': ('E', 'Roots orthogonal to beta_k have the profile of D6; the 32 at inner product +1 have the weights of the half-spin representation = labels of 6 bits of even weight (E3c, E3d).')}),
 ('E5', 'E', 'The series e_n: e7 > e6 > so(10) > sl5 > sl3 + sl2 (Table 2) with Levi pieces', {
   'shapes': ('E', 'Deleting alpha_8, alpha_7, ... gives 240, 126, 72, 40, 20, 8 roots and grade-1 sizes 56, 27, 16, 10, 6, equal to the Gosset vertex-figure chain (E1b, E1c); the paper\'s Table 2 starts at e7.'),
   'groups': ('S', 'Step 17: the same ladder of orthogonal systems.')}),
 ('E6', 'E', 'Chiral content of one generation with right-handed neutrinos (Table 1: the SU(5) and Spin(10) multiplets)', {
   'rule': ('E', 'Anomaly freedom is not discussed in the papers; the standard cancellation, recomputed over the labels: sum of Y, Q, Y^3 and the two mixed anomalies over the 16 even labels vanish (H2d).'),
   'matter': ('S', 'Step 8 charges; the label route reaches the same hypercharges.')}),
 ('E7', 'E', 'Nasmith and Kugo-Yanagida: the E7 generation unification (the context of the paper)', {}),
 ('D1', 'D', 'Octonions from a 3d complex inner-product space with volume form: O = C + C^3', {
   'rule': ('E', 'The derivations killing a chosen unit form su(3) acting complex-linearly on the 6-dimensional complement (O1c); the octonions are the XOR rule with a non-associative sign (O1a, O1b).')}),
 ('D2', 'D', 'Split octonions from a 3d real space with volume form: Zorn product on Lambda(R^3)', {
   'rule': ('E', 'On the 8 labels of Lambda(R^3) every Zorn product is the join, the meet or 0 (16, 16, 32 of 64); the norm has signature (4,4) (O2a, O2b).'),
   'rigid': ('S', 'Join and meet are the products of projective geometric algebra in step 16.')}),
 ('D3', 'D', 'The Zorn product on Lambda V for a 3-dimensional V with a volume form (split octonions)', {
   'rule': ('E', 'The paper uses neither the Hodge star nor Clifford conjugation; ours: the complement label x XOR 111 with the sign (-1)^(k(k+1)/2) is an automorphism of the Zorn algebra, the bare complement is not (O2d); popcount = 2 x left + right Peirce eigenvalue of pi (O2c).')}),
 ('D4', 'D', 'Bioctonions O_C = C (x) O and the complex Albert algebra h3(O_C); e6 as sl3 + sl3 + sl3 + 27 + 27bar', {
   'shapes': ('S', 'The 27 and the 16 are the grade-1 roots of e7 and e6; the three-sl3 grading of e6 is not computed here (E1b, E2d).'),
   'clock': ('A', 'Three copies of sl3 (24 = 3 x 8) against the three 8s of triality in step 1: a reading, not computed.')}),
 ('D5', 'D', 'Applications to 3-dimensional real and complex manifolds', {}),
 ('K1', 'K', 'Classical Kepler: L, e, Poisson brackets, e^2 = 1 + 2 L^2 E', {
   'rule': ('E', 'Checked at random phase-space points of both energy signs (K1a); the same algebra comes out of bit-rule bivectors (K1b).'),
   'comm': ('E', '[L,L] = L, [L,M] = M, [M,M] = eps L from bivectors of the algebra with squares (+1,+1,+1,eps) (K1b).')}),
 ('K2', 'K', 'The three energy regimes E < 0, = 0, > 0 (ellipse, parabola, hyperbola; the paper treats only E < 0, with so(4))', {
   'rule': ('E', 'e(3) and so(3,1) for E = 0, > 0 are standard, not in the paper. The trio of the fourth generator square eps = +1, 0, -1 gives Killing signatures (0,6,0), (0,3,3), (3,3,0) (K1b); eps = -sign(E).'),
   'projective': ('A', 'The same trio is the extra generator s = 0, -1, +1 of step 11 (flat, de Sitter, anti-de Sitter): a reading of ours.')}),
 ('K3', 'K', 'Hidden SU(2) x SU(2): A = (L+M)/2, B = (L-M)/2 acting on S^3 by q -> g q h^-1', {
   'comm': ('E', 'A and B commute and each closes into so(3) (K1c).'),
   'spin': ('S', 'Left and right multiplications on H = Cl(0,2) are two commuting su(2) spanning so(4) (K2a); step 5 has H as Cl(0,2).')}),
 ('K4', 'K', 'Quantum shells: V_j (x) V_j, 4A^2 + 1 = n^2, Clebsch-Gordan split, 2n^2 with spin', {
   'spin': ('E', 'Clebsch-Gordan from the spin matrices for n = 1..13; 2n^2 = n(n+1) + n(n-1): 2, 8, 18, 32, 50, 72, 98 (K2b).')}),
 ('K5', 'K', 'Spin-1/2 Kepler = Weyl equation on R x S^3; the Fock space on bound states', {
   'rule': ('S', 'The finite analogue only: fermionic Fock space on n modes = the 2^n labels, Cl(n,n) acts by real matrices, N = popcount (H3a, H3b); the infinite-dimensional Fock space of the paper is not computed.'),
   'spin': ('S', 'The Weyl equation itself is not in the atlas; only the Clifford algebra that carries its spinors.')}),
 ('K6', 'K', 'The Madelung rules and the periodic table: 2, 8, 8, 18, 18, 32, 32', {
   'rule': ('E', 'Ground state of N electrons = the first N set bits in the order n + l, then n: closures 2, 10, 18, 36, 54, 86, 118; periods 2 m^2 (K3). E here means that the counts agree exactly; no product of the bit rule is used, only bit counting.')}),
 ('K7', 'K', 'SU(2) x SU(2) inside the 15-dimensional conformal group SO(2,4) (Section 5.1)', {
   'projective': ('E', 'The 4 + 7 + 4 grading is ours, not in the paper. The 15 bivectors of Cl(4,2): hyperbolic generator gives eigenvalues +1, 0, -1 with multiplicities 4, 7, 4; elliptic gives +i, 0, -i, 4, 7, 4 and commutes with so(4) (K4).')}),
 ('K8', 'K', 'Real atoms: exceptions to Madelung, relativistic and screening corrections', {}),
 ('T1', 'T', 'The Eisenstein lattice of the stars (its theta series is ours)', {
   'shapes': ('S', 'Theta series 1, 6, 0, 6, 6, 0, 0, 12. Six units, nothing of norm 2; the same hexagonal lattice as the plane of the generation sl3 (T1a, T1b).')}),
 ('T2', 'T', 'Gauss-Bonnet: twelve cone points of valence 5, sum of (6 - valence) = 12', {
   'shapes': ('S', 'Checked on tetrahedron, octahedron, icosahedron and six random convex hulls (T2); the atlas counts faces of polytopes, not curvature.')}),
 ('T3', 'T', 'The number of triangles is a hermitian form on C^10 of signature (1,9) (the explicit formula is Engel-Smillie, Sec. 3, not read here)', {
   'cells': ('S', 'Ours: (4/sqrt3) area - sum |v|^2. The form is reproduced from the shoelace formula and has real signature (2,18) (T3); the atlas supplies what a signature means as an algebra.')}),
 ('T4', 'T', 'Is the signature (1,9) of the form a coincidence with ten-dimensional Minkowski space?', {
   'cells': ('S', 'What (1,9) is as an algebra, not an answer to the question: Cl(1,9): clock 0, type R, M32(R), pseudoscalar squares to +1, real Weyl spinors; among the 11 signatures (p,10-p) only (1,9), (5,5), (9,1) (T4). Also h2(O) = R^{1,9} (O3i). The 10 of the form is complex, the 10 of h2(O) real; no mechanism.')}),
 ('T5', 'T', 'Thurston\'s moduli space M = PC^10_+ / Gamma of flat spheres (complex dimension 9) and the bijection with lattice vectors', {}),
 ('C1', 'C', 'Open systems: composition by identifying shared variables (structured and decorated cospans)', {
   'rule': ('A', 'Shared bits are contracted with their square eps_i and the rest glued by XOR; a label-level reading of composition by shared variables (our reading; C1 tests only the forms).')}),
 ('C2', 'C', 'Commutative Frobenius monoids and the cospan category', {
   'rule': ('S', 'A finite-dimensional shadow only: the top-label form is non-degenerate for all 117 patterns of generator squares (including null ones), the scalar form only without null generators (C1). The label algebra is a non-commutative Frobenius algebra, the Frobenius monoids of the cospan category are commutative: the match is in the existence of the form only.')}),
 ('C3', 'C', 'Double categories: exoskeleton, outer shell, hypergraph double categories', {}),
 ('C4', 'C', 'Open Petri nets, open dynamical systems, Petri nets with rates', {}),
 ('C5', 'C', 'Symmetric monoidal functors between double categories; compositionality', {}),
]
ROWS = [(r[0][0] + '.' + r[0][1:],) + tuple(r[1:]) for r in ROWS]    # row ids are written G.1, J.3, ... : distinct from the findings J1-J10 and from the check ids K4, E1a, T3, C1

def stats():
    from collections import Counter
    n = len(ROWS); col = {k: Counter() for k, *_ in COLS}; per = []
    for rid, src, title, cells in ROWS:
        best = 'gap'
        order = {'E': 3, 'S': 2, 'A': 1}
        for k, (g, note) in cells.items():
            col[k][g] += 1
            if best == 'gap' or order[g] > order[best]: best = g
        per.append((rid, best))
    cnt = Counter(b for _, b in per)
    bysrc = {s: Counter(b for (rid, b), r in zip(per, ROWS) if r[1] == s) for s in 'GJEDKTC'}
    total_cells = sum(len(r[3]) for r in ROWS)
    cellg = Counter(g for r in ROWS for g, _ in r[3].values())
    return dict(n=n, best=cnt, bysrc=bysrc, col=col, total_cells=total_cells, cellg=cellg)

if __name__ == '__main__':
    s = stats()
    print('rows', s['n'], 'best grade per row', dict(s['best']), 'cells', s['total_cells'], dict(s['cellg']))
    for k, v in s['bysrc'].items(): print(k, dict(v))
    keys = [k for k, *_ in COLS]
    for k in keys:
        assert all(kk in keys for r in ROWS for kk in r[3]), 'unknown column'
    assert all(kk in keys for r in ROWS for kk in r[3])
    print('columns', {k: sum(s['col'][k].values()) for k in keys})
