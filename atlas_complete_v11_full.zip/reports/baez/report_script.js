// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
(function(){
 var tip=document.getElementById('tip');
 function show(el,x,y){var t=el.getAttribute('data-tip');if(!t)return;tip.textContent=t;tip.classList.add('on');var w=tip.offsetWidth,h=tip.offsetHeight;var nx=Math.min(x+14,window.innerWidth-w-8),ny=y+16;if(ny+h>window.innerHeight-8)ny=y-h-12;tip.style.left=Math.max(8,nx)+'px';tip.style.top=Math.max(8,ny)+'px';}
 function hide(){tip.classList.remove('on');}
 document.addEventListener('mouseover',function(e){var el=e.target.closest('[data-tip]');if(el)show(el,e.clientX,e.clientY);else hide();});
 document.addEventListener('mousemove',function(e){var el=e.target.closest('[data-tip]');if(el&&tip.classList.contains('on'))show(el,e.clientX,e.clientY);});
 document.addEventListener('focusin',function(e){var el=e.target.closest('[data-tip]');if(el){var r=el.getBoundingClientRect();show(el,r.left+r.width/2,r.bottom);}});
 document.addEventListener('focusout',hide);document.addEventListener('scroll',hide,true);document.addEventListener('keydown',function(e){if(e.key==='Escape')hide();});
 var b=document.getElementById('themebtn');
 if(b){var modes=['auto','light','dark'],i=0;b.addEventListener('click',function(){i=(i+1)%3;var m=modes[i];if(m==='auto')document.documentElement.removeAttribute('data-theme');else document.documentElement.setAttribute('data-theme',m);b.textContent='theme: '+m;});}
})();
