#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Tests that category_atlas_report.html agrees with its sources (logs, data file, matrix data) and behaves in a browser.  Run after build_report_cat.py."""
import os, re, sys, json, subprocess, html as H
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, '.'); sys.path.insert(0, '..')
import no_history as NH
import status_check as SK
ok = fail = 0
def check(name, cond, info=''):
    global ok, fail
    if cond: ok += 1
    else: fail += 1; print('FAIL', name, info)

HT = open(os.path.join('..', 'html', 'category_atlas_report.html'), encoding='utf-8').read()   # the page is built into reports/html/
LOG = open('logs/cat_check.log', encoding='utf-8').read()
MUT = open('logs/mutation_cat.log', encoding='utf-8').read()
RES = json.load(open('cat_results.json', encoding='utf-8'))
IDS = re.findall(r'^(?:ok  |FAIL) (\S+?):', LOG, re.M)
import matrix_cat as MD
import content_cat as CT
ST = MD.stats()

# --- the checks: the log, the data file, a fresh run
check('log: all pass', re.search(r'checks: (\d+) ok, 0 failed', LOG) is not None and 'FAIL' not in LOG)
nlog = int(re.search(r'checks: (\d+) ok', LOG).group(1))
check('log count = number of ok lines', nlog == len(IDS) == len(set(IDS)) == RES['nok'], (nlog, len(IDS)))
env = dict(os.environ); env['ATLAS_PKG'] = os.environ.get('ATLAS_PKG', os.path.abspath(os.path.join('..', '..')))   # the package this folder ships in
fresh = subprocess.run([sys.executable, 'cat_check.py'], capture_output=True, text=True, env=env).stdout
check('a fresh run of cat_check.py gives the same ok lines as the log', [l.split(':')[0] for l in fresh.splitlines() if l.startswith('ok')] == [l.split(':')[0] for l in LOG.splitlines() if l.startswith('ok')])
check('a fresh run passes all', ('checks: %d ok, 0 failed' % nlog) in fresh)

# --- numbers on the page = numbers in the data
def kpi(label):
    m = re.search(r'<div class="kpi"><b>([^<]+)</b><span>%s' % re.escape(label), HT); return m.group(1) if m else None
check('kpi checks', kpi('checks pass') == str(nlog), kpi('checks pass'))
mm = re.search(r'mutants caught: (\d+) of (\d+)', MUT); mo, ma = int(mm.group(1)), int(mm.group(2))
check('kpi sabotage', kpi('deliberate sabotages') == f'{mo} of {ma}', kpi('deliberate sabotages'))
check('every sabotage caught', mo == ma, (mo, ma))
check('sabotage lines = mutants', len([l for l in MUT.splitlines() if re.match(r'(caught|MISSED|ERROR|TIMEOUT)', l)]) == ma)
check('kpi matrix', kpi('notions') == '%d × 22' % ST['n'], kpi('notions'))
nq = sum(len(g[2]) for g in CT.QUESTIONS)
check('kpi questions', kpi('questions for specialists') == str(nq), kpi('questions for specialists'))
check('total in checks table', re.search(r'<td><b>%d</b></td>' % nlog, HT) is not None or re.search(r'<td class="num"><b>%d</b></td>' % nlog, HT) is not None)
blocks = re.findall(r'<tr><td><b>([A-Z])</b></td><td>[^<]*</td><td class="num">(\d+)</td></tr>', HT)
check('14 blocks', len(blocks) == 14, len(blocks))
check('block counts equal the log', all(int(n) == sum(1 for i in IDS if i[0] == b) for b, n in blocks) and sum(int(n) for _, n in blocks) == nlog)
check('mutation table rows', HT.count('<td>✓</td>') + HT.count('<td>✗</td>') == ma and '<td>✗</td>' not in HT)
check('matrix: rows and cells', HT.count('<div class="c g-') == ST['total_cells'] and len(re.findall(r'<div class="rl', HT)) == ST['n'], (HT.count('<div class="c g-'), ST['total_cells']))
check('matrix: gap rows', len(re.findall(r'<div class="rl gaprow"', HT)) == 5 == ST['best']['gap'])
check('rows by source add up', sum(sum(v.values()) for v in ST['bysrc'].values()) == ST['n'] == 40)
# the one-paragraph numbers
b = ST['best']
m = re.search(r'Of the (\d+) rows of the matrix, (\d+) have an exact counterpart, (\d+) a structural one, (\d+) an analogy, (\d+) none', HT)
check('one-paragraph matrix numbers', m and tuple(map(int, m.groups())) == (ST['n'], b['E'], b['S'], b['A'], b['gap']), m.groups() if m else None)

# --- the data quoted in the text
R = RES['res']
check('Euler form signatures', R['E'] == {'0': [1, 0, 0], '1': [2, 0, 0], '2': [4, 0, 0], '3': [6, 0, 2], '4': [14, 2, 0], '5': [20, 2, 10]} and '(6,0,2)' in HT and '(14,2,0)' in HT and '(20,2,10)' in HT)
check('Majkic Gram signatures', R['Jsig'] == {'2': [4, 0, 0], '3': [11, 0, 1], '4': [26, 4, 2]} and '(26,4,2)' in HT)
check('E_n signatures E8..E11', RES['sig_E']['8'] == [8, 0, 0] and RES['sig_E']['9'] == [8, 0, 1] and RES['sig_E']['10'] == [9, 1, 0] and RES['sig_E']['11'] == [10, 1, 0])
check('E_n determinants 9 - n in the table', all(('<td>E%d</td><td>(%d,%d,%d)</td><td>%d</td>' % ((n,) + tuple(RES['sig_E'][str(n)]) + (9 - n,))) in HT for n in range(3, 12)))
check('positive roots 36, 63, 120', RES['PR']['E6'] == 36 and RES['PR']['E7'] == 63 and RES['PR']['E8'] == 120)
check('mod-2 counts equal blade counts', all(v['q1'] == v['cl_q1'] and v['q0'] == v['cl_q0'] and v['rad'] == v['cl_rad'] for v in R['LAD'].values()))
check('quadric counts quoted', {k: (RES['WI'][k]['dims']['1'], RES['WI'][k]['count']) for k in ('4,0', '6,0', '8,0', '2,2')} == {'4,0': (5, 5), '6,0': (27, 45), '8,0': (135, 270), '2,2': (9, 6)} and '135 points and 270 solids' in HT and '27 points and 45 lines' in HT)
rr = R['R']; ff = R['F']
check('radical dim = 2^n - 2^(p+q), Loewy = r + 1, super-centre 2^r for every signature',
      all(v['rad'] == 2 ** v['n'] - 2 ** (int(k.split(',')[0]) + int(k.split(',')[1])) and (len(v['layers']) + 1 == int(k.split(',')[2]) + 1 or v['rad'] == 0) and v['sc'] == 2 ** int(k.split(',')[2]) for k, v in rr.items()))
check('Frobenius symmetric iff n odd or r = 0', all(v['symmetric'] == (v['n'] % 2 == 1 or k.endswith(',0')) for k, v in ff.items()))
check('3D PGA is Frobenius, not symmetric', ff['3,0,1']['symmetric'] is False and ff['3,0,1']['full'] and ff['3,0,1']['supp'])
check('grading rank = r', all(v == int(k.split(',')[2]) for k, v in RES['GR'].items()))
check('Tian truncations: signature (floor(k/2), floor(k/2), k mod 2)', all(RES['TS'][str(k)] == [k // 2, k // 2, k % 2] for k in range(1, 11)))
check('H2 dimensions n(n+1)/2', all(v['dimH'] == int(k) * (int(k) + 1) // 2 for k, v in RES['H2'].items()))
check('Majkic counts quoted', R['J']['2']['arrows'] == 5 and R['J']['3']['arrows'] == 19 and R['J']['2']['orth'] == 8 and R['J']['3']['orth'] == 153 and R['J']['3']['one'] == 18)

# --- every check id cited in the page exists
def expand(group):
    toks = re.findall(r'[SLRGFKTMWQEJBC]\d[a-e]?', group); return toks
cited = set()
for g in re.findall(r'<p class="ids">(?:checks )?([^<]*)</p>', HT): cited |= set(expand(g.split(';')[0]))
for g in re.findall(r'<td class="ids">([^<]*)</td>', HT): cited |= set(expand(g))
for g in re.findall(r'<span class="ids">([^<]*)</span>', HT): cited |= set(expand(g))
for rid, src, title, cells in MD.ROWS:
    for k, (g, note) in cells.items():
        for grp in re.findall(r'\(([^()]*)\)', note):
            if re.match(r'^[SLRGFKTMWQEJBC]\d', grp.strip()): cited |= set(expand(grp))
check('cited check ids exist', cited <= set(IDS), sorted(cited - set(IDS)))
check('a good number of ids cited', len(cited) >= 40, len(cited))
check('every check id is cited somewhere on the page', all(i in HT for i in IDS), [i for i in IDS if i not in HT])
# question cards
qids = re.findall(r'<span class="qid">(Q[A-E]\d)</span>', HT)
check('questions: count and unique ids', len(qids) == nq and len(set(qids)) == nq, len(qids))
check('questions: every card has checked and not checked', HT.count('<b>Checked.</b>') == nq and HT.count('<b>Not checked.</b>') == nq)
refs = set(re.findall(r'href="#(q-[a-e]\d)"', HT)); check('question links resolve', all(f'id="{r}"' in HT for r in refs), refs)
check('finding ids N1..N10 present', all(f'id="n{i}"' in HT for i in range(1, 11)))
check('in-page links resolve', all(('id="%s"' % a) in HT for a in re.findall(r'href="#([\w-]+)"', HT)), [a for a in re.findall(r'href="#([\w-]+)"', HT) if ('id="%s"' % a) not in HT][:5])
F4 = ('checked', 'standard', 'ours', 'open')
check('tags used are the four of the atlas: each status an icon chip (role img, name and hover text start with the word, the atlas badge drawing, no word chip, one legend entry per flag); the verdict labels (kept, partly, deadend, recalled) are plain words without a flag class',
      not SK.problems(HT, F4) and set(SK.kinds(HT)) == set(F4) and set(re.findall(r'<span class="vd (\w+)">', HT)) <= {'kept', 'partly', 'deadend', 'recalled'} and 'class="vd ' in HT
      and not re.search(r'<span class="chip (kept|partly|deadend|recalled)', HT), SK.problems(HT, F4)[:3])
check('every finding has at least one icon chip and an ids line', all(SK.kinds(re.search(r'id="n%d".*?class="chips">(.*?)</div>' % i, HT, re.S).group(1)) and re.search(r'id="n%d".*?class="ids"' % i, HT, re.S) for i in range(1, 11)))

# --- hygiene
check('no external resource', not re.search(r'<link |<script src|src="http|@import|url\(http', HT))
check('only arXiv links', all(re.match(r'https://arxiv\.org/abs/', u) for u in re.findall(r'href="(https?://[^"]+)"', HT)), [u for u in re.findall(r'href="(https?://[^"]+)"', HT)][:3])
check('no e-mail address, no mail link', not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', HT, flags=re.S)) and ('mail' + 'to') not in HT.lower())
check('title short', re.search(r'<title>Category Lens on the Atlas</title>', HT) is not None)
check('lang en', '<html lang="en">' in HT)
check('licence notice', 'PolyForm-Noncommercial-1.0.0' in HT)
check('svgs have role and label', all(('role="img"' in s and 'aria-label=' in s) for s in re.findall(r'<svg [^>]*class="chart[^>]*>', HT)))
check('no empty tooltips', 'data-tip=""' not in HT)
check('no unfilled placeholder', '%%' not in HT and '{E3}' not in HT and '{E4}' not in HT and '{E5}' not in HT)
check('no "TODO"', 'TODO' not in HT)

# --- the present statements: the forbidden sentences (quoted here as test strings only) are nowhere on the page, the right ones and their checks are on it
PLAIN = H.unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'<style.*?</style>|<script.*?</script>', '', HT, flags=re.S))); PLAIN = re.sub(r'\s+', ' ', PLAIN)
check('no corrections section, no struck sentence, no erratum id', 'id="corr"' not in HT and 'id="corr2"' not in HT and '<s>' not in HT and not re.search(r'\bE-\d{3}\b', PLAIN))
check('no history in the visible text of the page (shared pattern list, reports/no_history.py); every "<" in a text node is written &lt;, so the reader sees all the text', not NH.scan_page(HT) and not NH.bare_lt(HT), NH.scan_page(HT)[:3])
check('the history scan catches its planted phrases', not NH.selftest(), NH.selftest())
WRONG = ['Frobenius forms of an algebra form a torsor under its central units', 'The Frobenius forms of an algebra are a torsor under its central units: recalled', 'real part gives the type', 'The real part, 2^((n+1)/2)',
         'needs the top-blade form when null generators are present. None contradicts', 'an odd unit flips the null generators but cannot flip the others at the same time).', 'the groups are recalled.', 'The largest free abelian grading group has rank r (G1):']
check('none of the forbidden sentences is on the page', not any(w in H.unescape(HT) for w in WRONG), [w for w in WRONG if w in H.unescape(HT)])
check('the right statements are on the page', all(t in PLAIN for t in ('torsor under the whole unit group', 'Re S + Im S', 'label-homogeneous', 'never a state', 'matrix-unit degree', 'elliptic quadric', 'groups_check.py part B')))
check('the checks G2, F5, C3 exist in the log and are cited', all(i in IDS for i in ('G2', 'F5', 'C3')) and all(i in cited for i in ('G2', 'F5', 'C3')))
check('the sabotages M50 to M54 (K4c, G2, F5, C3) are listed and caught', all(('M%d ' % k) in MUT for k in (50, 51, 52, 53, 54)) and all(re.search(r'^caught\s+M%d ' % k, MUT, re.M) for k in (50, 51, 52, 53, 54)))

# --- more forbidden wording (test strings), and the right wording, which is on the page
OUTSIDE = re.sub(r'\s+', ' ', H.unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'<style.*?</style>|<script.*?</script>', '', HT, flags=re.S))))
FORBIDDEN = ['conserved integer degree', 'conserved charge', 'the Born rule is the Frobenius form', 'is the boundary between the definite and the Lorentzian', 'the reason for the ten', 'our reading only',
           'With only null generators it fails:', 'a pure label 0 cannot be peeled off', 'three functors and a duality', 'Ladders as functors', 'the same functor', 'the same pattern as the category itself',
           ': the same pattern (Fig. 5)', 'it is symmetric only for odd n or without null generators', 'In the cube of labels it is a face;', 'The radical is the half of the cube that contains the null bit.',
           'it first appears inside the cube category at n = 3 as a null direction of its Euler form', 'The yellow part is a label 0.']
check('the forbidden wording is nowhere on the page', not any(w in OUTSIDE for w in FORBIDDEN), [w for w in FORBIDDEN if w in OUTSIDE])
RIGHT = ['an additive integer degree', 'the trace of the Born rule is a symmetric Frobenius form, and the top-blade form is never a state', 'det = 9 − n is 0 only at n = 9', 'not of a spacetime',
         'Clifford periodicity does not cause the stop', 'the count behind the ten of the Tenfold Way (Wall, recalled)', 'Standard, quoted and not computed', 'fails from three generators on, and only there',
         'the complement of the face of labels with none', 'the top-blade form is symmetric iff n is odd', 'T4 (iii) gives a null bit weight 1 instead', 'the Tits form there is (6,1,1)', 'three maps and a duality']
check('the right wording is on the page', all(t in PLAIN for t in RIGHT), [t for t in RIGHT if t not in PLAIN])
check('N3 is standard (T3: proved for all n) and carries no open tag; N2 carries open (which class at which clock value)', 'standard' in SK.kinds(re.search(r'id="n3".*?class="chips">(.*?)</div>', HT, re.S).group(1)) and 'open' not in SK.kinds(re.search(r'id="n3".*?class="chips">(.*?)</div>', HT, re.S).group(1)) and 'open' in SK.kinds(re.search(r'id="n2".*?class="chips">(.*?)</div>', HT, re.S).group(1)))
W5 = [r for r in MD.ROWS if r[0] == 'W5'][0][3]['clock']
check('row W.5 is standard (quoted from the paper), grade S, and not called our reading', W5[0] == 'S' and W5[1].startswith('Standard, quoted') and 'reading ours' not in W5[1])

# --- browser behaviour (16 tests; needs playwright with Chromium). REPORT_NO_BROWSER=1 skips them: they are then reported as skipped and not counted, never as passed
# (the package's data test test_reports.mjs runs this suite that way; reports/run_report_tests.sh runs it whole).
NOBROWSER = bool(os.environ.get('REPORT_NO_BROWSER'))
if NOBROWSER:
    print('skip the 16 browser tests: REPORT_NO_BROWSER is set')
else:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1100, 'height': 900})
        errs = []; reqs = []
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.on('request', lambda r: reqs.append(r.url) if not r.url.startswith(('file:', 'data:')) else None)
        pg.goto('file://' + os.path.abspath(os.path.join('..', 'html', 'category_atlas_report.html')))
        check('no page errors', not errs, errs[:3]); check('no network requests', not reqs, reqs[:3])
        check('ladder: 31 nodes, 15 on the radical', pg.locator('#up svg.chart circle.lad-n, #up svg.chart circle.lad-nh').count() == 31 and pg.locator('#up svg.chart circle.lad-nh').count() == 15,
              (pg.locator('#up svg.chart circle.lad-n').count(), pg.locator('#up svg.chart circle.lad-nh').count()))
        check('ladder: edges 0+1+4+12+32', pg.locator('#up svg.chart line').count() == 49, pg.locator('#up svg.chart line').count())
        check('frobenius map: 6 orange cells (n even, r >= 1, n <= 5)', pg.locator('#n3 svg.chart rect.k2').count() == 6, pg.locator('#n3 svg.chart rect.k2').count())
        check('frobenius map: 20 cells (n = 1..5, r = 0..n)', pg.locator('#n3 svg.chart rect.k1, #n3 svg.chart rect.k2').count() == 20, pg.locator('#n3 svg.chart rect.k1, #n3 svg.chart rect.k2').count())
        check('clock ring has 8 sectors', pg.locator('#n2 svg.chart path').count() == 8)
        check('hub: 6 nodes and 8 edges', pg.locator('#fig1 g.nd').count() == 6 and pg.locator('#fig1 svg.chart line.ed').count() == 8, (pg.locator('#fig1 g.nd').count(), pg.locator('#fig1 svg.chart line.ed').count()))
        # tooltip on a matrix cell
        cell = pg.locator('.mx .c.g-E').first; cell.scroll_into_view_if_needed(); pg.wait_for_timeout(250)   # the page hides the tip on scroll, so settle first
        cell.hover(); pg.wait_for_timeout(150)
        check('matrix tooltip shows', pg.locator('#tip.on').count() == 1 and len(pg.inner_text('#tip')) > 30)
        nd = pg.locator('#fig1 g.nd').first; nd.scroll_into_view_if_needed(); pg.wait_for_timeout(250)
        nd.focus(); pg.wait_for_timeout(150)
        check('node tooltip on focus', pg.locator('#tip.on').count() == 1)
        pg.click('#themebtn'); check('theme button', pg.get_attribute('html', 'data-theme') == 'light')
        pg.click('#themebtn'); check('theme button dark', pg.get_attribute('html', 'data-theme') == 'dark')
        pg.locator('details.tv summary').first.click(); check('matrix table view opens', pg.locator('details.tv').first.get_attribute('open') is not None)
        check('no horizontal overflow at 1100', pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth') <= 0)
        pg.set_viewport_size({'width': 375, 'height': 800}); pg.wait_for_timeout(150)
        check('no horizontal overflow at 375', pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth') <= 0, pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth'))
        wide = pg.evaluate('''() => [...document.querySelectorAll('.finding, .qcard, .card, .answer')].filter(e => e.scrollWidth > e.clientWidth + 2 && getComputedStyle(e).overflowX === 'visible').map(e => e.id || e.className).slice(0, 5)''')
        check('no card overflows its box at 375', not wide, wide)
        b.close()
print('%d ok, %d failed' % (ok, fail) + (', 16 browser tests skipped' if NOBROWSER else '')); sys.exit(1 if fail else 0)
