# Digest: Yin Tian, "A diagrammatic categorification of a Clifford algebra", arXiv:1309.6049v1 [math.RT], 24 Sep 2013, 51 pp.
Read: all 51 pages of the text; page images (figures) inspected for pp. 4-5, 7-14. Page numbers = printed page = PDF page.
Tags: (own) = my deduction/check from the paper's formulas, NOT stated in the paper. (memory) = standard fact, not from the paper.
Quotes are plain-text transcriptions (pdftotext); *_j means "star" (contracting) operators.

## 0. Map
Sec.1 Intro pp.1-6 (1.1 main results pp.2-3; 1.2 contact motivation pp.3-5; 1.3 organization pp.5-6). Sec.2 diagrammatic DG category CL pp.6-15
(2.1 objects/diagrams/relations/differential pp.6-12; 2.2 definition of CL pp.11-13; 2.3 K0(CL), Lemma 2.9, Cor 2.10, Prop 2.1 pp.13-14;
2.4 contact topology, Conj 2.11 p.15). Sec.3 Fock rep V pp.15-17. Sec.4 diagrammatic DG category "V" (calligraphic) pp.18-30. Sec.5 DGP(R) pp.30-34.
Sec.6 categorical action pp.35-50. References p.50; author USC, Los Angeles.

## 1. The objects
### 1a. Cl_Z (p.2, Sec.1.1)
"we define the integral Clifford algebra ClZ as a Z-algebra with generators a_i for i in Z and relations:
 a_i^2 = 0;   a_i a_j = - a_j a_i if |i-j| > 1;   a_i a_{i+1} + a_{i+1} a_i = 1."
All generators are nilpotent. The Gram matrix of anticommutators {a_i,a_j} is the adjacency matrix of the bi-infinite path (own).

### 1b. The complex Clifford algebra Cl and its Fock space F (pp.1-2)
Cl: C-algebra, generators psi_j, psi*_j (j in Z): "{psi_i, psi*_j} = psi_i psi*_j + psi*_j psi_i = delta_ij,  {psi_i, psi_j} = 0,  {psi*_i, psi*_j} = 0" (p.1).
F: basis "{i1 ^ i2 ^ ... | i1 > i2 > ... are integers, i_n = i_{n-1} - 1 for n >> 0}" (semi-infinite monomials); "|k> = k ^ (k-1) ^ ..." = vacuum of charge k.
 psi_j (i1^i2^...) = 0 if j = i_k for some k;  (-1)^k i1^...^i_k^j^i_{k+1}^... if i_k > j > i_{k+1}.
 psi*_j (i1^i2^...) = 0 if j != i_k for all k;  (-1)^{k-1} i1^...^i_{k-1}^i_{k+1}^... if j = i_k.   ("wedging and contracting operators", p.2)
Occupation-pattern reading (own): a basis vector is a set S of integers containing all sufficiently negative integers (so NOT a finite subset).
 psi_j S = (-1)^{#{s in S: s>j}} (S u {j}) if j not in S, else 0;  psi*_j S = (-1)^{#{s in S: s>j}} (S \ {j}) if j in S, else 0.
 I.e. both operators carry the sign (-1)^{number of occupied sites strictly above j}. Paper cites [11, Sec.14.9] (Kac) for details.

### 1c. Homomorphism theta (p.3) and its inverse (p.16)
 theta: Cl_Z (x)_Z C -> Cl,  a_{2i} |-> psi*_i,  a_{2i-1} |-> psi_i + psi_{i-1};  "an isomorphism between suitable completions of the algebras" (p.3; completions not defined).
 Inverse (p.16, "in suitable completions ... involves infinite sums"): psi*_i |-> a_{2i};  psi_i |-> a_{2i-1} - a_{2i-3} + ... .
 So Cl_Z (x) C is not literally Cl; only after completion.

### 1d. The integral Fock space V (Sec.3, p.16) -- the one actually used
 Basis HB = "{x1 ^ x2 ^ ... | x1 < x2 < ... are even integers, x_n = x_{n-1} + 2 for n >> 0}"; HB = disjoint union of HB_k, "HB_k = {... | x_n = 2n + 2k for n >> 0}".
 Vacuum "|k> = (2k+2) ^ (2k+4) ^ (2k+6) ^ ...". V = free abelian group on HB. (Paper writes "in B" in the definition of HB_k; B is only defined on p.30 -- typo for HB.)
 Operators (p.16), j in Z:
 eta_j (x1^x2^...) = 0 if 2j = x_i for some i;  (-1)^i x1^...^x_i^(2j)^x_{i+1}^... if x_i < 2j < x_{i+1}.
 eta*_j (x1^x2^...) = 0 if 2j != x_i for all i;  (-1)^{i-1} x1^...^x_{i-1}^x_{i+1}^... if 2j = x_i.
 Action G of Cl_Z on V: "a_{2j} := eta_j,   a_{2j-1} := eta*_j + eta*_{j-1}".  Only check shown: "a_{2j} a_{2j-1} + a_{2j-1} a_{2j} = eta_j(eta*_j + eta*_{j-1}) + (eta*_j + eta*_{j-1}) eta_j = 1".
 Occupation-pattern reading (own): basis vector = set S of EVEN integers, bounded below, containing all large evens. Signs:
 eta_j S = (-1)^{#{s in S: s<2j}} (S u {2j}) if 2j not in S, else 0;  eta*_j S = (-1)^{#{s in S: s<2j}} (S \ {2j}) if 2j in S, else 0.
 Sign = (-1)^{number of occupied sites strictly BELOW the site} (opposite side to F; my gloss: V is increasing-ordered, F decreasing-ordered).
 Even generator a_{2j} = create at site 2j. Odd generator a_{2j-1} = annihilate at 2j PLUS annihilate at 2j-2; the two terms give different vectors
 (S\{2j} vs S\{2j-2}), each with its own sign (-1)^{#{s<2j}} resp. (-1)^{#{s<2j-2}}; no cancellation. Odd generators only ever remove particles.
 Remark 3.1 (p.16): "The correspondence between the representation V and the Fock space F is simply given by V in |k> <-> |k> in F, where |k> is the complement of |k>
 multiplied by 2." Only the vacua are matched; the paper does not write a basis-by-basis sign comparison V vs F (own: particle-hole complement + doubling of labels,
 consistent with theta(a_{2j}) = psi*_j; I did not verify sign-by-sign).
 Lemma 3.2 (p.16): V "is uniquely determined by: a_{2j} . v = eta_j(v) for v in HB,  a_{2j-1} . |k> = 0 for k >= j."
 (every element of HB is obtained from a vacuum by wedging operators, so the odd generators' action is forced by the relations.)
 Charge/energy (p.21-22): ch(x) = k if x_n = 2n+2k for n>>0; energy E_k(x) = (1/2) sum_i (2k + 2i - x_i) (finite sum); HB_k <-> partitions via x |-> (1/2)(vac(k) - x) (p.32).

### 1e. Finite truncations (the only place finite subsets / bit strings occur)
 Lemma 3.3 (p.17): "The representation V of ClZ is faithful." Proof: Cl_Z(n) = subalgebra generated by a_i, 1<=i<=2n; V(n) = {a.|n> : a in Cl_Z(n)} with a_{2i-1}|n> = 0 (1<=i<=n).
 Cl_n = Z-algebra on eta_i, eta*_i (1<=i<=n) with {eta_i, eta*_j} = delta_ij, {eta_i,eta_j} = 0, {eta*_i,eta*_j} = 0.
 Iso Cl_Z(n) -> Cl_n: a_{2i} |-> eta_i;  a_{2i-1} |-> eta*_i + eta*_{i-1} (i>1);  a_1 |-> eta*_1.   V_n = exterior algebra of W_n = free abelian group on e_1..e_n,
 "eta_i and eta*_i are wedging and contracting with e_i" (signs not written out for V_n). Shown by induction: "Cl_n = End_Z(V_n)" (so Cl_Z(n) = full matrix ring of size 2^n over Z, own).
 Also p.22: U(n) = Z-span of increasing sequences of even integers in {0,2,...,2n-2} (rank 2^n) = Cl(n)/J(n), Cl(n) = <a_i : 0<=i<=2n-1>, J(n) = left ideal gen. by odd a_i.

### 1f. Main theorems (p.3), and what "categorification" means here
 Notation (p.3): "Let H(A) denote the 0th homology category of a DG category A. Let K0(A) denote the Grothendieck group of H(A) if H(A) is triangulated."
 Theorem 1.1: "There exists a DG category CL such that H(CL) is triangulated. There is a monoidal functor (x) : CL x CL -> CL whose decategorification
 K0((x)) : K0(CL) x K0(CL) -> K0(CL) makes K0(CL) isomorphic to the Clifford algebra ClZ."
 Theorem 1.2: "There exists a DG category DGP(R) generated by some projective DG modules over a DG algebra R such that H(DGP(R)) is triangulated. Moreover, there is a
 categorical action F : CL x DGP(R) -> DGP(R) whose decategorification K0(F) : K0(CL) x K0(DGP(R)) -> K0(DGP(R)) makes K0(DGP(R)) isomorphic to the representation V of ClZ."
 Remark 1.3: "The main improvement over [18] is the monoidal functor on CL which is easily defined diagrammatically." Abstract/p.1: CL is a "strict monoidal" DG category.
 Concretely: objects of CL = one-sided twisted complexes (Bondal-Kapranov [4]) of elementary objects (finite integer sequences) (p.12); H(CL) triangulated by [4, Sec.4, Prop.2] (p.13);
 (x) = horizontal stacking, bi-exact so it induces the product on K0 (p.13). gamma: Cl_Z -> K0(CL), a_i |-> [i] (Prop 2.1, p.14), surjective by Cor 2.10; injective because
 the action of Cl_Z on V factors through K0(CL) (Lemma 6.12, p.49) and V is faithful (Lemma 3.3) -- "Proof of Theorems 1.1 and 1.2", p.50 (last line there writes Cl for Cl_Z).
 The action: tau: CL -> DG(R (x) R^op), monoidal DG functor, tau(empty) = R, tau(i) = T_i (DG R-bimodules); action = tensoring with T_i over R (p.35). T_{2i}(k) = (+) Hom(x,(2i).y), x in B_{k-1},
 y in B_k; T_{2i-1}(k) = (+) Hom((2i).z, y), z in B_{k+1}, y in B_k (Def 6.1, p.35). DGP(R): smallest full subcategory of DG(R) containing the projectives R.e(x), x in B, closed under [1] and cones (Def 5.6, p.33).
 K0(DGP(R)) = Z<HB> = V (Lemma 5.8 p.34, Lemma 5.9 p.34: DGP(R) equivalent to the diagrammatic category 𝒱 of Sec.4). R = (+)_k R_k, R_k = (+)_{x,y in B_k} Hom_𝒱(x,y) (p.30).
 Scope limits (own reading): morphism spaces are over F_2 only (p.6); only one (cohomological) Z-grading `gr` appears -- no q or internal grading, no mention of q anywhere in the body; what is categorified is an action of a
 monoidal DG category at the level of K0; Remark 2.6 (p.11): "we do not know if Hom((empty),(empty)) is a 1-dimensional F2-vector space generated by id" -- non-collapse is shown only via the action of Sec.6.

## 2. The diagrammatics of CL (Sec.2.1, pp.6-12)
 Ground field: "We fix F2 as the ground field for morphisms throughout the paper to simplify computations." (p.6)
 Objects ("elementary objects"): finite sequences a = (a_1,...,a_n) of integers, n >= 0, (empty) = n=0. Morphisms Hom(a,b): cochain complexes of F2-vector spaces spanned by dotted labeled planar diagrams
 in R x [0,1] from label a (bottom) to label b (top), modulo local relations; read bottom to top; composition = vertical stacking (zero if labels mismatch); (x) = horizontal stacking (strict).
 Elementary diagrams (Fig.4, p.7), strands carry integer labels:
 (1) id_i in Hom((i),(i)); (2) cup_{i,i+1} in Hom((empty),(i,i+1)); (3) cap_{i+1,i} in Hom((i+1,i),(empty)); (4) crossing cr_{i,j} in Hom((j,i),(i,j));
 (5) dot_e in Hom((e+2),(e)) or dot_{e+1} in Hom((e-1),(e+1)), "where e denotes an even integer". So a dotted strand lowers an even label by 2 / raises an odd label by 2 (Remark 2.2(3), p.10).
 Cups/caps only join labels differing by exactly 1; adjacency (Remark 2.2(2), p.10): "(i) is left adjoint to (i-1) and right adjoint to (i+1)": Hom((i)(x)a,b) = Hom(a,(i-1)(x)b); Hom(a(x)(i),b) = Hom(a,b(x)(i+1)).
 Relations R1-R6 (pp.7-9):
 R1 isotopy: (a) vertical strands idempotents, (b) zig-zag isotopy of a strand, (c) isotopy of a crossing, (d) dot through a cup/cap (defines dotted cup dup_{e+1,e} in Hom((empty),(e+1,e)) and dotted cap dap_{e-1,e} in Hom((e-1,e),(empty))), (e) disjoint diagrams commute.
 R2 "a strand with a double dot is zero". R3 "a loop with one dot is the empty diagram, i.e., the identity id_empty" (dot on top of loop (e-1,e) or at bottom of loop (e+1,e)).
 R4 double crossings (e even): (a) in Hom((e,e+1),(e,e+1)) and Hom((e,e-1),(e,e-1)) = identity; (b) in Hom((e+1,e),(e+1,e)) and Hom((e-1,e),(e-1,e)) "is a sum of two terms" -- from Fig.7 (p.9) (reading the picture):
 double crossing on (e+1,e) = id (x) id + [dotted cup dup_{e+1,e}] o [cap_{e+1,e}];  on (e-1,e) = id (x) id + [cup_{e-1,e}] o [dotted cap dap_{e-1,e}];
 (c) double crossing in Hom((i,i),(i,i)) is zero; (d) double crossing in Hom((i,j),(i,j)) is the identity if |i-j| > 1.
 R5 triple intersection (Reidemeister III) for all labels. R6 dot slide through a crossing, four versions (Fig.8, p.9), each valid only when the passing label x avoids two values
 (conditions printed: "x != e, e+1", "x != e, e-1", "x != e+1, e+2", "x != e, e+1"); Remark 2.2(5): crossings cr_{x,e+2}, cr_{x,e} have the same grading iff x != e, e+1.
 Remark 2.2(4): "The main difference from [Khovanov's Heisenberg calculus 15] is that the double crossing in Hom((i,i),(i,i)) is zero in our case."
 Lemma 2.3 (Fig.9, p.10): a crossing composed with an adjacent cap (resp. cup) between the same labels is 0, also for dotted versions; only the first equation of (A) is proved (Fig.10, uses R3, R4-a,b).
 Cohomological grading gr (p.9): zero on id, cup, cap, dots; on crossings
 "gr(cr_{i,j}) = (-1)^{i-j} if i < j;  (-1)^{i-j+1} if i >= j."  Values are +-1 (own: gr(cr_{i,j}) + gr(cr_{j,i}) = 0; gr(cr_{i,i}) = -1; gr(cr_{i,i+1}) = -1; gr(cr_{i+1,i}) = +1). Additive under stacking; both sides of every relation have equal gr.
 Differential d (Fig.11, p.11; degree +1; Leibniz for vertical and horizontal stacking; Lemma 2.4 relations preserved, Lemma 2.5 d^2 = 0):
 d(id) = d(cup) = d(cap) = 0;  d(cr_{i+1,i}) = 0;  d(cr_{i,j}) = 0 for |i-j| > 1;  d(cr_{i,i}) = id(x)id (two vertical strands);
 d(cr_{i,i+1}) = cup_{i,i+1} o cap_{i+1,i} (cap at bottom on (i+1,i), cup at top giving (i,i+1));  [Lemma 6.5, p.39 writes this as "d(cr_{2i-1,2i}) = cap_{2i,2i-1} * cup_{2i-1,2i}" in diagrammatic order]
 d(dot_e), d(dot_{e+1}) = a one-crossing curl on the same strand with a loop labelled e+1 (resp. e) -- picture only (Fig.11); in Fig.12 (R2) d(double dot) = 2 x (dotted curl) = 0 uses characteristic 2.
 Twisted complexes (Sec.2.2, p.12): objects ({a^i[m_i]}, f = sum_{i<j} f_i^j), f_i^j in Hom^1(a^i[m_i], a^j[m_j]), with sum_k f_k^j f_i^k + d(f_i^j) = 0 ("one-sided": f_i^j = 0 for i >= j);
 conventions Hom^i(a[m],b) = Hom^{i-m}(a,b), Hom^i(a,b[m]) = Hom^{i+m}(a,b). Example 2.8 (p.13): ((0,0)[2],(0,0)[1],(0,0)) with f_12 = f_23 = id, f_13 = cr_{0,0}, d(cr_{0,0}) = id.
 Key isomorphisms in H(CL) (Lemma 2.9, pp.13-14):
 (1) (i,i) ~ 0 [proof: id_{(i,i)} = d(cr_{i,i})];
 (2) (e+1,e) ~ { (empty) --cup_{e,e+1}--> (e,e+1) }, "the term (empty) is in cohomological grading 0" [maps f,g, compositions = identity by R4-a,b and Lemma 2.3, Fig.13];
 (3) (e-1,e) ~ { (e,e-1) --cap_{e,e-1}--> (empty) }, same convention; (4) (j,i) ~ (i,j)[gr(cr_{i,j})] if |i-j| > 1 [cr_{i,j}, cr_{j,i} inverse isomorphisms by R4-d].
 Cor 2.10 (p.14), in K0(CL): "[i]^2 = 0;  [i][j] = -[j][i] if |i-j| > 1;  [i][i+1] + [i+1][i] = [empty] = 1."
 WHERE THE MINUS SIGNS COME FROM (precise):
 (i) Not from the diagrams: all coefficients are F2, so no relation contains a sign (R4-b is a plain sum; "2 x ... = 0" in R2).
 (ii) From the cohomological degree of crossings: gr(cr_{i,j}) is odd (+-1) for every i,j. Lemma 2.9(4) turns the invertible crossing (R4-d: double crossing = id for |i-j|>1)
 into the isomorphism (j,i) ~ (i,j)[gr(cr_{i,j})]; a shift by an odd number acts as -1 on K0 ((memory): [X[1]] = -[X] in a triangulated K0; the paper never writes this, Cor 2.10 is stated without further derivation).
 So [j][i] = -[i][j] is "swap two strands = one odd shift".
 (iii) a_i^2 = 0: (i,i) ~ 0 because the degree -1 crossing cr_{i,i} is a null-homotopy of id_{(i,i)} (d(cr_{i,i}) = id; R4-c makes the double crossing 0).
 (iv) a_i a_{i+1} + a_{i+1} a_i = 1: from the cones in Lemma 2.9(2),(3). (own: with the shift convention above and deg(cup) = deg(cap) = 0, (2) reads (empty)[0] -> (e,e+1)[-1] and (3) reads (e,e-1)[1] -> (empty)[0],
 giving [e+1][e] = [empty] - [e][e+1] and [e-1][e] = [empty] - [e][e-1], i.e. the "+" in the anticommutator is [empty] minus a shifted term.) The null-homotopy cr_{i,i+1} with d = cup o cap is what makes the cone work.
 (v) Fock-space signs: Lemma 4.20 (p.29) "x ~ N(x)[eta(x)]", N(x) = non-decreasing rearrangement, "eta(x) = |{(i,j) : i<j, x_i > x_j}|" (number of decreasing pairs = inversions); each adjacent swap = one odd crossing = one shift.
 Lemma 6.11(1) (p.48): T_{2i}(k) (x)_k P(y) = P(N((2i).y))[eta((2i).y)]. Since y is non-decreasing, eta((2i).y) = #{m : y_m < 2i}: exactly the exponent in the formula for eta_j in Sec.3 (own matching; paper does not say it in words).
 If 2i occurs in y, the rearranged object has a repeated label and is ~ 0 (Lemma 2.9(1)-argument, p.30), matching "eta_j = 0 if 2j = x_i".
 Sec.4 category 𝒱 (pp.18-30; V-analogue of CL, labels EVEN only, objects = semi-infinite even sequences): no cups/caps; generators strand, crossing cr_{i,j}, dot_i in Hom((i+2),(i)); relations L1-L5:
 double dot = 0; double crossing = 0 on (i,i), = id on (i,j), i != j (L3); triple moves (L4); dot slide (L5) plus (LD-1),(LD-2) = 0 (Lemma 4.2); same gr as in CL; d: cr_{i,i} |-> id, other crossings |-> 0, dots defined inductively (Fig.21, pp.23-24),
 not Leibniz for horizontal stacking (Remark 4.8). Monotonicity Lemma 4.7: nonzero Hom(x,y) => E_k(x) <= E_k(y). Prop 4.18 (p.28): Hom(x,y;sigma) = F2{can(x,y;sigma)} if sigma admissible, else 0; Cor 4.19: Hom(x,y) finite-dim.
 Lemma 5.3 (p.31): for x,y in HB_k, dim Hom(x,y) = 1 if y is x with some entries lowered by 2, else 0. Prop 5.5 (p.32): H(R_k) = path algebra of quiver Gamma_k (vertices HB_k = partitions, arrows add one box) with
 "r(x,y;i) . r(y,z;i) = 0;  r(x,y;i) . r(y,w;j) = r(x,z;j) . r(z,w;i), i != j"; R formal (quasi-isomorphic to H(R)).

## 3. The earlier paper [18]
 [18] = "Y. Tian, A categorification of Uq(sl(1|1)) as an algebra, preprint 2012, arXiv:1210.5680" (reference list, p.50). NOT READ (the arXiv fetch from this sandbox failed; I do not use the garbled summary it returned).
 What THIS paper says about it, in full: (a) "This paper is a sequel to [18] in which the author categorified a finite-dimensional Clifford algebra." (p.1) -- generators and dimension are NOT given anywhere in this paper;
 (b) "The main improvement over [18] is that the categorification is done diagrammatically. In particular, the category CL is strict monoidal." (p.1); Remark 1.3: "...the monoidal functor on CL which is easily defined diagrammatically." (p.3);
 (c) goal here: infinite-dimensional Cl_Z + lift of the Fock rep V (p.1); (d) "Note that indices in Z on the left boundary of the strip is increasing from bottom to top. This assignment is different from the one in [18]." (p.4);
 (e) [18] is cited for the contact-category introduction (p.3), for construction of the subcategories DGP (p.33), and "[18, Lemma 2.29]" for Lemma 5.7 (p.33).
 Unverified (memory): [18]'s title indicates a connection with U_q(sl(1|1)); the paper does not explain how that relates to the Clifford algebra.

## 4. Nilpotent generators / quadratic form
 Plainly: the paper never mentions a quadratic form, bilinear form, hyperbolic or Witt form, signature, or orthogonal basis (searched: "quadratic|hyperbolic|Witt|bilinear|orthogonal|signature|square"; the only hit for "orthogonal" is "mutually orthogonal idempotents", p.30).
 It never uses a generator with square +1 or -1, and no non-hyperbolic form. Every generator squares to zero: a_i^2 = 0 in Cl_Z, psi_i^2 = 0 = (psi*_i)^2 in Cl (from {psi_i,psi_j} = 0 = {psi*_i,psi*_j}).
 Cl is presented by the canonical anticommutation relations {psi_i, psi*_j} = delta_ij ("the analogue of H obtained by replacing the commutation relations by the anticommutation relations", p.2) -- i.e. the split/hyperbolic pairing between
 psi's and psi*'s -- but the paper does not say so; the identification with "Clifford algebra of the hyperbolic form" is mine (own). Likewise (own): x^2 = sum_i c_i c_{i+1} for x = sum c_i a_i, so Cl_Z is the Clifford algebra over Z
 of the quadratic form q(sum c_i a_i) = sum c_i c_{i+1} (all a_i isotropic, polar form = path-graph adjacency matrix); theta changes the basis from {a_i} to {psi_j, psi*_j} only after completion (p.3, p.16).
 The paper's own phrase for the algebra: "Clifford algebra", with relations of Fock-space/fermionic type, over Z (Cl_Z), C (Cl) and, for morphisms, F2. No real/complex Clifford algebras with e^2 = +-1 (Cl_{p,q}) occur.

## 5. Motivation: contact categories and strips (Sec.1.2 pp.3-5; Sec.2.4 p.15; Fig.1-3 pp.4-5)
 - Honda's contact category C(Sigma,F) [9] (objects: dividing sets on a surface with marked boundary points F, with homotopy grading; morphisms: F2-spaces spanned by tight contact structures on Sigma x [0,1]); contractible-component dividing sets = zero object (Giroux [8]); bypass attachments [10] are the basic morphisms.
 - C_infty = strip with marked points indexed by Z on both boundaries; (x) = horizontal stacking of dividing sets/contact structures; distinguished dividing sets [empty], [i]; a triangle of three bypass attachments
 "[i+1].[i] -> [empty] -> [i].[i+1] -> [i+1].[i]" descends to a_i a_{i+1} + a_{i+1} a_i = 1. "Our diagrammatic DG category CL can be viewed as a DG realization of the contact category C_infty." (pp.4,15)
 - C_{infty 1} = Z marked points on the left, one on the right; semi-infinite monomials lift to dividing sets built from arcs L_i (label 2i on left boundary to right boundary); charge ~ Euler number; the action of Cl_Z lifts to horizontal stacking of C_infty on the left of C_{infty 1} (Fig.3).
 - Sec.2.4: elementary diagrams that are d-closed <-> tight contact structures; d(cr_{i,i}) = id gives (i,i) ~ 0 matching the contractible-component zero object; Eliashberg [7] gives dim Hom_{C_infty}(G1,G2) <= 1; Conjecture 2.11: dim H*(Hom_CL(a,b)) = 1 if b is stackable over a, 0 otherwise (open; Remark 5.4: the analogue is TRUE for 𝒱).
 - Context cited: strands algebra of Lipshitz-Ozsvath-Thurston [17] (bordered Heegaard Floer); Khovanov's categorification of half of U_q(gl(1|2)) [14]; Zarev [20] (gluing maps / contact category link); Tian [19] (U_t(sl(1|1)) and tensor products); Auroux [2] (wrapped Fukaya category of the infinite symmetric product, wedge of arcs = Lagrangians).
 Note: the paper says the triangle isomorphisms are "as in Figure 3" (p.15); the triangle is drawn in Figure 2 (p.4).

## 6. Boson-fermion correspondence, Heisenberg categorification (p.1-2, p.10)
 - p.1: "The Clifford algebra Cl and its cousin, the Heisenberg algebra H, arise from the study of commutation relations in fermionic and bosonic quantum mechanics, respectively." H: generators p_i, q_i, "[p_i,q_j] = p_i q_j - q_j p_i = delta_ij 1, [p_i,p_j] = 0, [q_i,q_j] = 0"; "The symmetric algebra of infinitely many variables indexed by I admits a natural action of H."
 - p.1: "Khovanov [15] provided a graphical calculus for a categorification of H. More generally, Cautis and Licata [5] presented a categorification H_Gamma of the Heisenberg algebra H_Gamma associated to a finite subgroup Gamma in SL2(C).
 In a later paper [6], they provided 2-representations of quantum affine algebras via complexes in the 2-representation of quantum Heisenberg algebra. The diagrammatic approach to categorification was pioneered by Lauda in [16] where he obtained a categorification of the quantum group U_q(sl2)."
 - p.2: Cl "is the analogue of H obtained by replacing the commutation relations by the anticommutation relations. The Clifford algebra Cl acts on the exterior algebra of infinitely many variables, which is called the Fock space of free fermions.
 Note that this Fock space also admits an action of the Heisenberg algebra H under the boson-fermion correspondence [11, Section 14.9]." (one sentence; no formulas)
 - p.2: "The antisymmetric property of fermions in physics can be understood in the framework of differential graded categories in mathematics." (motivation for DG signs)
 - p.10 Remark 2.2(4): R4-a,b depend on parity of labels; "There are similar relations in the graphical calculus for the Heisenberg algebra [15]. The main difference ... double crossing in Hom((i,i),(i,i)) is zero in our case."
 Nothing else: the paper does NOT categorify the boson-fermion correspondence, does not construct a Heisenberg action on V or CL, and does not use Cautis-Licata's calculus beyond the citation. Refs [5],[6],[15],[16] themselves: not read.

## 7. Twelve statements most useful for a reader who knows Clifford algebras, bit strings, XOR, exterior algebra as Fock space
 1. Cl_Z: Z-algebra on nilpotent a_i (i in Z): a_i^2=0; a_i a_j = -a_j a_i (|i-j|>1); a_i a_{i+1}+a_{i+1}a_i = 1 (p.2). Only neighbouring generators have non-zero anticommutator; nothing squares to +-1.
 2. Fock space V (p.16): basis = sets S of even integers (bounded below, all large evens present); a_{2j} = wedge at site 2j, a_{2j-1} = contract at 2j plus contract at 2j-2; every move carries (-1)^{#occupied sites below} (a Jordan-Wigner-type sign (own label)).
 3. Finite models are exterior algebras: Cl_Z(n) = Cl_n = End_Z(Lambda W_n), 2^n basis vectors (subsets of {1..n}, i.e. n-bit strings); signs in Lambda W_n are the usual wedge signs (Lemma 3.3, p.17).
 4. A basis vector = an object x (sequence of even labels, one strand per occupied site); wedge with an occupied site gives 0 <-> object with a repeated label is ~ 0 (argument of Lemma 2.9(1), applied in the V-category, p.30), i.e. the bit "already set" case.
 5. Categorification adds: each sign is a cohomological shift [1]. The sorting sign (-1)^{#inversions} becomes the isomorphism x ~ N(x)[eta(x)], eta = number of inversions (Lemma 4.20, p.29; Lemma 6.11(1), p.48).
 6. Each relation becomes explicit structure: a_i^2=0 <-> (i,i) ~ 0 via the null-homotopy cr_{i,i} (d(cr_{i,i}) = id); {a_i,a_{i+1}}=1 <-> (e+1,e) ~ cone(cup) (Lemma 2.9, pp.13-14).
 7. The minus signs are NOT in the diagram calculus (F2 coefficients, p.6); they appear only on passing to K0, from the odd degree gr(cr_{i,j}) = +-1 of crossings (p.9) and K0's rule [X[1]] = -[X] (memory; not spelled out in the paper).
 8. Operators become functors: a_{2i} <-> tensoring with T_{2i} (add a strand labelled 2i on the left); a_{2i-1} <-> tensoring with T_{2i-1}, its right adjoint (Remark 6.2, p.36); K0 of the result is V on the nose (Lemma 5.8, p.34).
 9. Combinatorics of V: HB_k <-> partitions via x |-> (1/2)(vacuum - x); Hom(x,y) has dim <= 1 per matching, nonzero exactly when y is x with some entries lowered by 2 (Lemma 5.3, p.31; Young-lattice quiver, Prop 5.5, p.32).
 10. Logical structure: K0(CL) is a quotient of Cl_Z by diagrammatics (Prop 2.1); equality needs a faithful action: V is faithful (Lemma 3.3) so gamma is injective (p.50). No independent basis of Hom_CL is known (Remark 2.6, Conj 2.11).
 11. Only one Z-grading (cohomological) occurs: no q-deformation, no Z[q,q^-1]; morphisms over F2; so this categorifies the Z-algebra Cl_Z, not a quantum or real/complex-signature Clifford algebra.
 12. Interpretation of a_i a_{i+1}+a_{i+1}a_i = 1: a triangle of three bypass attachments in the contact category of a strip (Fig.2, p.4); category CL is a DG model of that contact category (p.15).

## 8. Small inconsistencies noticed (all harmless)
 p.16 "in B" should be "in HB"; p.50 "K0(CL) = Cl" should be Cl_Z; p.15 "Figure 3" for the triangle should be Figure 2; the intro's F is decreasing-ordered, V is increasing-ordered with doubled labels, so the two sign conventions differ in direction (above vs below).

## 9. Summary of coverage
I read the full text (pp.1-51), including all definitions, relations, Lemmas 2.3-2.9, Cor 2.10, Prop 2.1, Secs.3-6, and the theorem proofs at the level of statements and proof strategy; I looked at page images of pp.4-5 and 7-14 to read Figures 1-13 (elementary diagrams, relations, differential, Lemma 2.9 isomorphisms).
Figures 14-40 (Sec.4-6) were read only through the text extraction (their captions and labels), not visually, so the picture-only identities there (Figs.17-18, 21-24, 26-40: V-relations, differential on V, bimodule maps, check computations) are summarized from the surrounding text, not verified; Secs.4.3-5.1 proofs
(canonical forms, Prop 4.18, Lemma 5.3), Lemmas 6.3-6.11 and the Sec.6.3 checks of R1-R6 are summarized, not re-derived. Not read: references [5],[6],[11],[14]-[20] (in particular [18], which question 3 asks about: the paper itself gives no generators or dimension),
and no external source was consulted. The sign statements marked (own) are my readings/deductions from the paper's formulas (e.g. the occupation-count form of the signs, the cone computation giving the anticommutator, gr values of specific crossings) and the K0 rule [X[1]] = -[X] is a standard fact (memory) that the paper uses silently.
